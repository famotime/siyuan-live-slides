"use strict";var Ac=Object.create;var Ko=Object.defineProperty;var Bc=Object.getOwnPropertyDescriptor;var Mc=Object.getOwnPropertyNames;var Dc=Object.getPrototypeOf,Lc=Object.prototype.hasOwnProperty;var Oc=(e,t,i)=>t in e?Ko(e,t,{enumerable:!0,configurable:!0,writable:!0,value:i}):e[t]=i;var Pc=(e,t,i,n)=>{if(t&&typeof t=="object"||typeof t=="function")for(let o of Mc(t))!Lc.call(e,o)&&o!==i&&Ko(e,o,{get:()=>t[o],enumerable:!(n=Bc(t,o))||n.enumerable});return e};var Gn=(e,t,i)=>(i=e!=null?Ac(Dc(e)):{},Pc(t||!e||!e.__esModule?Ko(i,"default",{value:e,enumerable:!0}):i,e));var ke=(e,t,i)=>Oc(e,typeof t!="symbol"?t+"":t,i);const me=require("siyuan");async function mt(e,t){const i=await me.fetchSyncPost(e,t);return i.code===0?i.data:null}async function Rc(){return mt("/api/notebook/lsNotebooks","")}async function Nc(e,t,i){return mt("/api/filetree/createDocWithMd",{notebook:e,path:t,markdown:i})}async function nl(e,t){const i=new FormData;i.append("assetsDirPath",e);for(const o of t)i.append("file[]",o);return mt("/api/asset/upload",i)}async function Mi(e,t,i,n,o){return mt("/api/block/insertBlock",{dataType:e,data:t,nextID:i,previousID:n,parentID:o})}async function ds(e,t,i){return mt("/api/block/appendBlock",{dataType:e,data:t,parentID:i})}async function cr(e,t,i){return mt("/api/block/updateBlock",{dataType:e,data:t,id:i})}async function ol(e){return mt("/api/block/deleteBlock",{id:e})}async function zc(e){return mt("/api/block/getBlockKramdown",{id:e})}async function fo(e){return mt("/api/block/getChildBlocks",{id:e})}async function Fc(e){return mt("/api/block/getDocBlocksOrders",{id:e})}async function Ne(e,t){return mt("/api/attr/setBlockAttrs",{id:e,attrs:t})}async function Bs(e){return mt("/api/attr/getBlockAttrs",{id:e})}async function on(e){return mt("/api/query/sql",{stmt:e})}async function us(e,t,i){const n=new FormData;return n.append("path",e),n.append("isDir",t.toString()),n.append("modTime",Math.floor(Date.now()/1e3).toString()),n.append("file",i),mt("/api/file/putFile",n)}async function sl(e){const t="/api/ai/chatGPT";try{const i=await mt(t,{msg:e});return typeof i=="string"&&i.trim().length>0?i.trim():i&&typeof i.content=="string"&&i.content.trim().length>0?i.content.trim():null}catch{return null}}async function Hc(){return mt("/api/storage/getInlineStyles","")}const rl=/\(\(([0-9a-zA-Z-]+)(?:\s*(?:'([^']*)'|"([^"]*)"|([^\)]+?)))?\s*\)\)/g;function jc(e){const t=[];if(!e)return t;const i=new RegExp(rl.source,"g");let n;for(;(n=i.exec(e))!==null;){const o=n[2]??n[3]??n[4];t.push({fullMatch:n[0],blockId:n[1],anchorText:o?o.trim():void 0})}return t}function Wc(e,t){if(!e)return"";const i=new RegExp(rl.source,"g");return e.replace(i,(n,o,s,l,r)=>{const a=(s??l??r??"").trim();if(t&&t[o]){const d=t[o].trim();return`<div class="slidev-block-ref" data-ref-id="${o}">${d}</div>`}const c=a||`Ref(${o.slice(0,8)})`;return`<a href="siyuan://blocks/${o}" data-ref-id="${o}" class="slidev-ref-tag">🔗 ${c}</a>`})}const An="custom-slidev-theme",Bn="custom-slidev-aspect-ratio",ll="custom-slidev-highlighter",Mn="custom-slidev-default-transition",al="custom-slidev-color-schema",fs="custom-slidev-spacing",Ai="custom-slidev-slide",he="custom-slidev-layout",tt="custom-slidev-transition",je="custom-slidev-background",Dt="custom-slidev-image",Ki="custom-slidev-notes",Gi="custom-slidev-class",wn="custom-slidev-spacing",yt="custom-slidev-layout-ratio",qi="custom-slidev-mask",Zi="custom-slidev-mask-ratio",Yi="custom-slidev-mask-style",Ji="custom-slidev-mask-initial",Ze="custom-slidev-click",qt="custom-slidev-motion",Ni="custom-slidev-shiki-lines",Ce="custom-slidev-slot",nt="custom-slidev-note",Ge="custom-slidev-role",Dn="custom-slidev-max-height",Bi="custom-slidev-autoplay",po="custom-slidev-loop",Vi="custom-slidev-muted",ho="custom-slidev-controls",cl="background",mo="image-left",go="image-right";function Ln(e){return e==="cols-header"||e==="two-cols-header"||e==="three-cols-header"}function Uc(e){return e.markdown&&e.markdown.trim()?e.markdown.trim():e.content&&e.content.trim()?e.content.trim():""}function Vc(e){const t={};if(!e)return t;const i=e.replace(/^\{:\s*/,"").replace(/\s*\}$/,""),n=/([\w-]+)=(?:"([^"]*)"|'([^']*)'|(\S+))/g;let o;for(;(o=n.exec(i))!==null;){const s=o[1],l=o[2]??o[3]??o[4]??"";t[s]=l}return t}function dl(e){if(!e)return!1;const t=e.trim();return t.startsWith("assets/")||t.startsWith("./assets/")||t.startsWith("/assets/")}function ul(e){const t=e.trim();return t.startsWith("./assets/")?t.slice(2):t.startsWith("/assets/")?t.slice(1):t}function Tt(e,t){if(!dl(e))return e;const i=ul(e);return t!=null&&t.base64Map&&t.base64Map[i]?t.base64Map[i]:t!=null&&t.baseUrl?`${t.baseUrl.replace(/\/+$/,"")}/${i}`:`/${i}`}function Kc(e,t){if(!e)return"";let i=e;return i=i.replace(/!\[(.*?)\]\(((?:\.\/|\/)?assets\/[^\s)]+)\)/g,(n,o,s)=>{const l=Tt(s,t);return`![${o}](${l})`}),i=i.replace(/(<(?:img|video|audio|source)\b[^>]*?\bsrc=["'])((?:\.\/|\/)?assets\/[^"']+)(["'][^>]*>)/gi,(n,o,s,l)=>{const r=Tt(s,t);return`${o}${r}${l}`}),i=i.replace(/(url\(\s*["']?)((?:\.\/|\/)?assets\/[^"')]+)(["']?\s*\))/gi,(n,o,s,l)=>{const r=Tt(s,t);return`${o}${r}${l}`}),i}/**
* @vue/shared v3.5.40
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/function Ms(e){const t=Object.create(null);for(const i of e.split(","))t[i]=1;return i=>i in t}const We={},Xi=[],Zt=()=>{},fl=()=>!1,To=e=>e.charCodeAt(0)===111&&e.charCodeAt(1)===110&&(e.charCodeAt(2)>122||e.charCodeAt(2)<97),Eo=e=>e.startsWith("onUpdate:"),dt=Object.assign,Ds=(e,t)=>{const i=e.indexOf(t);i>-1&&e.splice(i,1)},Gc=Object.prototype.hasOwnProperty,Re=(e,t)=>Gc.call(e,t),$e=Array.isArray,Qi=e=>jn(e)==="[object Map]",cn=e=>jn(e)==="[object Set]",dr=e=>jn(e)==="[object Date]",Ee=e=>typeof e=="function",it=e=>typeof e=="string",Nt=e=>typeof e=="symbol",He=e=>e!==null&&typeof e=="object",pl=e=>(He(e)||Ee(e))&&Ee(e.then)&&Ee(e.catch),hl=Object.prototype.toString,jn=e=>hl.call(e),qc=e=>jn(e).slice(8,-1),ml=e=>jn(e)==="[object Object]",Ls=e=>it(e)&&e!=="NaN"&&e[0]!=="-"&&""+parseInt(e,10)===e,xn=Ms(",key,ref,ref_for,ref_key,onVnodeBeforeMount,onVnodeMounted,onVnodeBeforeUpdate,onVnodeUpdated,onVnodeBeforeUnmount,onVnodeUnmounted"),Ao=e=>{const t=Object.create(null);return(i=>t[i]||(t[i]=e(i)))},Zc=/-\w/g,wt=Ao(e=>e.replace(Zc,t=>t.slice(1).toUpperCase())),Yc=/\B([A-Z])/g,xi=Ao(e=>e.replace(Yc,"-$1").toLowerCase()),Bo=Ao(e=>e.charAt(0).toUpperCase()+e.slice(1)),Go=Ao(e=>e?`on${Bo(e)}`:""),Kt=(e,t)=>!Object.is(e,t),io=(e,...t)=>{for(let i=0;i<e.length;i++)e[i](...t)},gl=(e,t,i,n=!1)=>{Object.defineProperty(e,t,{configurable:!0,enumerable:!1,writable:n,value:i})},Mo=e=>{const t=parseFloat(e);return isNaN(t)?e:t};let ur;const Do=()=>ur||(ur=typeof globalThis<"u"?globalThis:typeof self<"u"?self:typeof window<"u"?window:typeof global<"u"?global:{});function Gt(e){if($e(e)){const t={};for(let i=0;i<e.length;i++){const n=e[i],o=it(n)?ed(n):Gt(n);if(o)for(const s in o)t[s]=o[s]}return t}else if(it(e)||He(e))return e}const Jc=/;(?![^(]*\))/g,Xc=/:([^]+)/,Qc=/\/\*[^]*?\*\//g;function ed(e){const t={};return e.replace(Qc,"").split(Jc).forEach(i=>{if(i){const n=i.split(Xc);n.length>1&&(t[n[0].trim()]=n[1].trim())}}),t}function Se(e){let t="";if(it(e))t=e;else if($e(e))for(let i=0;i<e.length;i++){const n=Se(e[i]);n&&(t+=n+" ")}else if(He(e))for(const i in e)e[i]&&(t+=i+" ");return t.trim()}const td="itemscope,allowfullscreen,formnovalidate,ismap,nomodule,novalidate,readonly",id=Ms(td);function vl(e){return!!e||e===""}function nd(e,t){if(e.length!==t.length)return!1;let i=!0;for(let n=0;i&&n<e.length;n++)i=dn(e[n],t[n]);return i}function dn(e,t){if(e===t)return!0;let i=dr(e),n=dr(t);if(i||n)return i&&n?e.getTime()===t.getTime():!1;if(i=Nt(e),n=Nt(t),i||n)return e===t;if(i=$e(e),n=$e(t),i||n)return i&&n?nd(e,t):!1;if(i=He(e),n=He(t),i||n){if(!i||!n)return!1;const o=Object.keys(e).length,s=Object.keys(t).length;if(o!==s)return!1;for(const l in e){const r=e.hasOwnProperty(l),a=t.hasOwnProperty(l);if(r&&!a||!r&&a||!dn(e[l],t[l]))return!1}}return String(e)===String(t)}function Os(e,t){return e.findIndex(i=>dn(i,t))}const bl=e=>!!(e&&e.__v_isRef===!0),ye=e=>it(e)?e:e==null?"":$e(e)||He(e)&&(e.toString===hl||!Ee(e.toString))?bl(e)?ye(e.value):JSON.stringify(e,yl,2):String(e),yl=(e,t)=>bl(t)?yl(e,t.value):Qi(t)?{[`Map(${t.size})`]:[...t.entries()].reduce((i,[n,o],s)=>(i[qo(n,s)+" =>"]=o,i),{})}:cn(t)?{[`Set(${t.size})`]:[...t.values()].map(i=>qo(i))}:Nt(t)?qo(t):He(t)&&!$e(t)&&!ml(t)?String(t):t,qo=(e,t="")=>{var i;return Nt(e)?`Symbol(${(i=e.description)!=null?i:t})`:e};/**
* @vue/reactivity v3.5.40
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/let at;class od{constructor(t=!1){this.detached=t,this._active=!0,this._on=0,this.effects=[],this.cleanups=[],this._isPaused=!1,this._warnOnRun=!0,this.__v_skip=!0,!t&&at&&(at.active?(this.parent=at,this.index=(at.scopes||(at.scopes=[])).push(this)-1):(this._active=!1,this._warnOnRun=!1))}get active(){return this._active}pause(){if(this._active){this._isPaused=!0;let t,i;if(this.scopes){const n=this.scopes.slice();for(t=0,i=n.length;t<i;t++)n[t].pause()}for(t=0,i=this.effects.length;t<i;t++)this.effects[t].pause()}}resume(){if(this._active&&this._isPaused){this._isPaused=!1;let t,i;if(this.scopes){const o=this.scopes.slice();for(t=0,i=o.length;t<i;t++)o[t].resume()}const n=this.effects.slice();for(t=0,i=n.length;t<i;t++)n[t].resume()}}run(t){if(this._active){const i=at;try{return at=this,t()}finally{at=i}}}on(){++this._on===1&&(this.prevScope=at,at=this)}off(){if(this._on>0&&--this._on===0){if(at===this)at=this.prevScope;else{let t=at;for(;t;){if(t.prevScope===this){t.prevScope=this.prevScope;break}t=t.prevScope}}this.prevScope=void 0}}stop(t){if(this._active){this._active=!1;let i,n;for(i=0,n=this.effects.length;i<n;i++)this.effects[i].stop();for(this.effects.length=0,i=0,n=this.cleanups.length;i<n;i++)this.cleanups[i]();if(this.cleanups.length=0,this.scopes){const o=this.scopes.slice();for(i=0,n=o.length;i<n;i++)o[i].stop(!0);this.scopes.length=0}if(!this.detached&&this.parent&&!t){const o=this.parent.scopes.pop();o&&o!==this&&(this.parent.scopes[this.index]=o,o.index=this.index)}this.parent=void 0}}}function sd(){return at}let Ke;const Zo=new WeakSet;class kl{constructor(t){this.fn=t,this.deps=void 0,this.depsTail=void 0,this.flags=5,this.next=void 0,this.cleanup=void 0,this.scheduler=void 0,at&&(at.active?at.effects.push(this):this.flags&=-2)}pause(){this.flags|=64}resume(){this.flags&64&&(this.flags&=-65,Zo.has(this)&&(Zo.delete(this),this.trigger()))}notify(){this.flags&2&&!(this.flags&32)||this.flags&8||xl(this)}run(){if(!(this.flags&1))return this.fn();this.flags|=2,fr(this),Sl(this);const t=Ke,i=Pt;Ke=this,Pt=!0;try{return this.fn()}finally{_l(this),Ke=t,Pt=i,this.flags&=-3}}stop(){if(this.flags&1){for(let t=this.deps;t;t=t.nextDep)Ns(t);this.deps=this.depsTail=void 0,fr(this),this.onStop&&this.onStop(),this.flags&=-2}}trigger(){this.flags&64?Zo.add(this):this.scheduler?this.scheduler():this.runIfDirty()}runIfDirty(){ps(this)&&this.run()}get dirty(){return ps(this)}}let wl=0,Sn,_n;function xl(e,t=!1){if(e.flags|=8,t){e.next=_n,_n=e;return}e.next=Sn,Sn=e}function Ps(){wl++}function Rs(){if(--wl>0)return;if(_n){let t=_n;for(_n=void 0;t;){const i=t.next;t.next=void 0,t.flags&=-9,t=i}}let e;for(;Sn;){let t=Sn;for(Sn=void 0;t;){const i=t.next;if(t.next=void 0,t.flags&=-9,t.flags&1)try{t.trigger()}catch(n){e||(e=n)}t=i}}if(e)throw e}function Sl(e){for(let t=e.deps;t;t=t.nextDep)t.version=-1,t.prevActiveLink=t.dep.activeLink,t.dep.activeLink=t}function _l(e){let t,i=e.depsTail,n=i;for(;n;){const o=n.prevDep;n.version===-1?(n===i&&(i=o),Ns(n),rd(n)):t=n,n.dep.activeLink=n.prevActiveLink,n.prevActiveLink=void 0,n=o}e.deps=t,e.depsTail=i}function ps(e){for(let t=e.deps;t;t=t.nextDep)if(t.dep.version!==t.version||t.dep.computed&&(Cl(t.dep.computed)||t.dep.version!==t.version))return!0;return!!e._dirty}function Cl(e){if(e.flags&4&&!(e.flags&16)||(e.flags&=-17,e.globalVersion===On)||(e.globalVersion=On,!e.isSSR&&e.flags&128&&(!e.deps&&!e._dirty||!ps(e))))return;e.flags|=2;const t=e.dep,i=Ke,n=Pt;Ke=e,Pt=!0;try{Sl(e);const o=e.fn(e._value);(t.version===0||Kt(o,e._value))&&(e.flags|=128,e._value=o,t.version++)}catch(o){throw t.version++,o}finally{Ke=i,Pt=n,_l(e),e.flags&=-3}}function Ns(e,t=!1){const{dep:i,prevSub:n,nextSub:o}=e;if(n&&(n.nextSub=o,e.prevSub=void 0),o&&(o.prevSub=n,e.nextSub=void 0),i.subs===e&&(i.subs=n,!n&&i.computed)){i.computed.flags&=-5;for(let s=i.computed.deps;s;s=s.nextDep)Ns(s,!0)}!t&&!--i.sc&&i.map&&i.map.delete(i.key)}function rd(e){const{prevDep:t,nextDep:i}=e;t&&(t.nextDep=i,e.prevDep=void 0),i&&(i.prevDep=t,e.nextDep=void 0)}let Pt=!0;const $l=[];function si(){$l.push(Pt),Pt=!1}function ri(){const e=$l.pop();Pt=e===void 0?!0:e}function fr(e){const{cleanup:t}=e;if(e.cleanup=void 0,t){const i=Ke;Ke=void 0;try{t()}finally{Ke=i}}}let On=0;class ld{constructor(t,i){this.sub=t,this.dep=i,this.version=i.version,this.nextDep=this.prevDep=this.nextSub=this.prevSub=this.prevActiveLink=void 0}}class zs{constructor(t){this.computed=t,this.version=0,this.activeLink=void 0,this.subs=void 0,this.map=void 0,this.key=void 0,this.sc=0,this.__v_skip=!0}track(t){if(!Ke||!Pt||Ke===this.computed)return;let i=this.activeLink;if(i===void 0||i.sub!==Ke)i=this.activeLink=new ld(Ke,this),Ke.deps?(i.prevDep=Ke.depsTail,Ke.depsTail.nextDep=i,Ke.depsTail=i):Ke.deps=Ke.depsTail=i,Il(i);else if(i.version===-1&&(i.version=this.version,i.nextDep)){const n=i.nextDep;n.prevDep=i.prevDep,i.prevDep&&(i.prevDep.nextDep=n),i.prevDep=Ke.depsTail,i.nextDep=void 0,Ke.depsTail.nextDep=i,Ke.depsTail=i,Ke.deps===i&&(Ke.deps=n)}return i}trigger(t){this.version++,On++,this.notify(t)}notify(t){Ps();try{for(let i=this.subs;i;i=i.prevSub)i.sub.notify()&&i.sub.dep.notify()}finally{Rs()}}}function Il(e){if(e.dep.sc++,e.sub.flags&4){const t=e.dep.computed;if(t&&!e.dep.subs){t.flags|=20;for(let n=t.deps;n;n=n.nextDep)Il(n)}const i=e.dep.subs;i!==e&&(e.prevSub=i,i&&(i.nextSub=e)),e.dep.subs=e}}const hs=new WeakMap,Oi=Symbol(""),ms=Symbol(""),Pn=Symbol("");function pt(e,t,i){if(Pt&&Ke){let n=hs.get(e);n||hs.set(e,n=new Map);let o=n.get(i);o||(n.set(i,o=new zs),o.map=n,o.key=i),o.track()}}function ti(e,t,i,n,o,s){const l=hs.get(e);if(!l){On++;return}const r=a=>{a&&a.trigger()};if(Ps(),t==="clear")l.forEach(r);else{const a=$e(e),c=a&&Ls(i);if(a&&i==="length"){const d=Number(n);l.forEach((h,v)=>{(v==="length"||v===Pn||!Nt(v)&&v>=d)&&r(h)})}else switch((i!==void 0||l.has(void 0))&&r(l.get(i)),c&&r(l.get(Pn)),t){case"add":a?c&&r(l.get("length")):(r(l.get(Oi)),Qi(e)&&r(l.get(ms)));break;case"delete":a||(r(l.get(Oi)),Qi(e)&&r(l.get(ms)));break;case"set":Qi(e)&&r(l.get(Oi));break}}Rs()}function Wi(e){const t=Pe(e);return t===e?t:(pt(t,"iterate",Pn),Bt(e)?t:t.map(zt))}function Lo(e){return pt(e=Pe(e),"iterate",Pn),e}function Ut(e,t){return li(e)?sn(Pi(e)?zt(t):t):zt(t)}const ad={__proto__:null,[Symbol.iterator](){return Yo(this,Symbol.iterator,e=>Ut(this,e))},concat(...e){return Wi(this).concat(...e.map(t=>$e(t)?Wi(t):t))},entries(){return Yo(this,"entries",e=>(e[1]=Ut(this,e[1]),e))},every(e,t){return Xt(this,"every",e,t,void 0,arguments)},filter(e,t){return Xt(this,"filter",e,t,i=>i.map(n=>Ut(this,n)),arguments)},find(e,t){return Xt(this,"find",e,t,i=>Ut(this,i),arguments)},findIndex(e,t){return Xt(this,"findIndex",e,t,void 0,arguments)},findLast(e,t){return Xt(this,"findLast",e,t,i=>Ut(this,i),arguments)},findLastIndex(e,t){return Xt(this,"findLastIndex",e,t,void 0,arguments)},forEach(e,t){return Xt(this,"forEach",e,t,void 0,arguments)},includes(...e){return Jo(this,"includes",e)},indexOf(...e){return Jo(this,"indexOf",e)},join(e){return Wi(this).join(e)},lastIndexOf(...e){return Jo(this,"lastIndexOf",e)},map(e,t){return Xt(this,"map",e,t,void 0,arguments)},pop(){return gn(this,"pop")},push(...e){return gn(this,"push",e)},reduce(e,...t){return pr(this,"reduce",e,t)},reduceRight(e,...t){return pr(this,"reduceRight",e,t)},shift(){return gn(this,"shift")},some(e,t){return Xt(this,"some",e,t,void 0,arguments)},splice(...e){return gn(this,"splice",e)},toReversed(){return Wi(this).toReversed()},toSorted(e){return Wi(this).toSorted(e)},toSpliced(...e){return Wi(this).toSpliced(...e)},unshift(...e){return gn(this,"unshift",e)},values(){return Yo(this,"values",e=>Ut(this,e))}};function Yo(e,t,i){const n=Lo(e),o=n[t]();return n!==e&&!Bt(e)&&(o._next=o.next,o.next=()=>{const s=o._next();return s.done||(s.value=i(s.value)),s}),o}const cd=Array.prototype;function Xt(e,t,i,n,o,s){const l=Lo(e),r=l!==e&&!Bt(e),a=l[t];if(a!==cd[t]){const h=a.apply(e,s);return r?zt(h):h}let c=i;l!==e&&(r?c=function(h,v){return i.call(this,Ut(e,h),v,e)}:i.length>2&&(c=function(h,v){return i.call(this,h,v,e)}));const d=a.call(l,c,n);return r&&o?o(d):d}function pr(e,t,i,n){const o=Lo(e),s=o!==e&&!Bt(e);let l=i,r=!1;o!==e&&(s?(r=n.length===0,l=function(c,d,h){return r&&(r=!1,c=Ut(e,c)),i.call(this,c,Ut(e,d),h,e)}):i.length>3&&(l=function(c,d,h){return i.call(this,c,d,h,e)}));const a=o[t](l,...n);return r?Ut(e,a):a}function Jo(e,t,i){const n=Pe(e);pt(n,"iterate",Pn);const o=n[t](...i);return(o===-1||o===!1)&&js(i[0])?(i[0]=Pe(i[0]),n[t](...i)):o}function gn(e,t,i=[]){si(),Ps();const n=Pe(e)[t].apply(e,i);return Rs(),ri(),n}const dd=Ms("__proto__,__v_isRef,__isVue"),Tl=new Set(Object.getOwnPropertyNames(Symbol).filter(e=>e!=="arguments"&&e!=="caller").map(e=>Symbol[e]).filter(Nt));function ud(e){Nt(e)||(e=String(e));const t=Pe(this);return pt(t,"has",e),t.hasOwnProperty(e)}class El{constructor(t=!1,i=!1){this._isReadonly=t,this._isShallow=i}get(t,i,n){if(i==="__v_skip")return t.__v_skip;const o=this._isReadonly,s=this._isShallow;if(i==="__v_isReactive")return!o;if(i==="__v_isReadonly")return o;if(i==="__v_isShallow")return s;if(i==="__v_raw")return n===(o?s?wd:Dl:s?Ml:Bl).get(t)||Object.getPrototypeOf(t)===Object.getPrototypeOf(n)?t:void 0;const l=$e(t);if(!o){let a;if(l&&(a=ad[i]))return a;if(i==="hasOwnProperty")return ud}const r=Reflect.get(t,i,Ye(t)?t:n);if((Nt(i)?Tl.has(i):dd(i))||(o||pt(t,"get",i),s))return r;if(Ye(r)){const a=l&&Ls(i)?r:r.value;return o&&He(a)?vs(a):a}return He(r)?o?vs(r):Oo(r):r}}class Al extends El{constructor(t=!1){super(!1,t)}set(t,i,n,o){let s=t[i];const l=$e(t)&&Ls(i);if(!this._isShallow){const c=li(s);if(!Bt(n)&&!li(n)&&(s=Pe(s),n=Pe(n)),!l&&Ye(s)&&!Ye(n))return c||(s.value=n),!0}const r=l?Number(i)<t.length:Re(t,i),a=Reflect.set(t,i,n,Ye(t)?t:o);return t===Pe(o)&&a&&(r?Kt(n,s)&&ti(t,"set",i,n):ti(t,"add",i,n)),a}deleteProperty(t,i){const n=Re(t,i);t[i];const o=Reflect.deleteProperty(t,i);return o&&n&&ti(t,"delete",i,void 0),o}has(t,i){const n=Reflect.has(t,i);return(!Nt(i)||!Tl.has(i))&&pt(t,"has",i),n}ownKeys(t){return pt(t,"iterate",$e(t)?"length":Oi),Reflect.ownKeys(t)}}class fd extends El{constructor(t=!1){super(!0,t)}set(t,i){return!0}deleteProperty(t,i){return!0}}const pd=new Al,hd=new fd,md=new Al(!0);const gs=e=>e,qn=e=>Reflect.getPrototypeOf(e);function gd(e,t,i){return function(...n){const o=this.__v_raw,s=Pe(o),l=Qi(s),r=e==="entries"||e===Symbol.iterator&&l,a=e==="keys"&&l,c=o[e](...n),d=i?gs:t?sn:zt;return!t&&pt(s,"iterate",a?ms:Oi),dt(Object.create(c),{next(){const{value:h,done:v}=c.next();return v?{value:h,done:v}:{value:r?[d(h[0]),d(h[1])]:d(h),done:v}}})}}function Zn(e){return function(...t){return e==="delete"?!1:e==="clear"?void 0:this}}function vd(e,t){const i={get(o){const s=this.__v_raw,l=Pe(s),r=Pe(o);e||(Kt(o,r)&&pt(l,"get",o),pt(l,"get",r));const{has:a}=qn(l),c=t?gs:e?sn:zt;if(a.call(l,o))return c(s.get(o));if(a.call(l,r))return c(s.get(r));s!==l&&s.get(o)},get size(){const o=this.__v_raw;return!e&&pt(Pe(o),"iterate",Oi),o.size},has(o){const s=this.__v_raw,l=Pe(s),r=Pe(o);return e||(Kt(o,r)&&pt(l,"has",o),pt(l,"has",r)),o===r?s.has(o):s.has(o)||s.has(r)},forEach(o,s){const l=this,r=l.__v_raw,a=Pe(r),c=t?gs:e?sn:zt;return!e&&pt(a,"iterate",Oi),r.forEach((d,h)=>o.call(s,c(d),c(h),l))}};return dt(i,e?{add:Zn("add"),set:Zn("set"),delete:Zn("delete"),clear:Zn("clear")}:{add(o){const s=Pe(this),l=qn(s),r=Pe(o),a=!t&&!Bt(o)&&!li(o)?r:o;return l.has.call(s,a)||Kt(o,a)&&l.has.call(s,o)||Kt(r,a)&&l.has.call(s,r)||(s.add(a),ti(s,"add",a,a)),this},set(o,s){!t&&!Bt(s)&&!li(s)&&(s=Pe(s));const l=Pe(this),{has:r,get:a}=qn(l);let c=r.call(l,o);c||(o=Pe(o),c=r.call(l,o));const d=a.call(l,o);return l.set(o,s),c?Kt(s,d)&&ti(l,"set",o,s):ti(l,"add",o,s),this},delete(o){const s=Pe(this),{has:l,get:r}=qn(s);let a=l.call(s,o);a||(o=Pe(o),a=l.call(s,o)),r&&r.call(s,o);const c=s.delete(o);return a&&ti(s,"delete",o,void 0),c},clear(){const o=Pe(this),s=o.size!==0,l=o.clear();return s&&ti(o,"clear",void 0,void 0),l}}),["keys","values","entries",Symbol.iterator].forEach(o=>{i[o]=gd(o,e,t)}),i}function Fs(e,t){const i=vd(e,t);return(n,o,s)=>o==="__v_isReactive"?!e:o==="__v_isReadonly"?e:o==="__v_raw"?n:Reflect.get(Re(i,o)&&o in n?i:n,o,s)}const bd={get:Fs(!1,!1)},yd={get:Fs(!1,!0)},kd={get:Fs(!0,!1)};const Bl=new WeakMap,Ml=new WeakMap,Dl=new WeakMap,wd=new WeakMap;function xd(e){switch(e){case"Object":case"Array":return 1;case"Map":case"Set":case"WeakMap":case"WeakSet":return 2;default:return 0}}function Oo(e){return li(e)?e:Hs(e,!1,pd,bd,Bl)}function Sd(e){return Hs(e,!1,md,yd,Ml)}function vs(e){return Hs(e,!0,hd,kd,Dl)}function Hs(e,t,i,n,o){if(!He(e)||e.__v_raw&&!(t&&e.__v_isReactive)||e.__v_skip||!Object.isExtensible(e))return e;const s=o.get(e);if(s)return s;const l=xd(qc(e));if(l===0)return e;const r=new Proxy(e,l===2?n:i);return o.set(e,r),r}function Pi(e){return li(e)?Pi(e.__v_raw):!!(e&&e.__v_isReactive)}function li(e){return!!(e&&e.__v_isReadonly)}function Bt(e){return!!(e&&e.__v_isShallow)}function js(e){return e?!!e.__v_raw:!1}function Pe(e){const t=e&&e.__v_raw;return t?Pe(t):e}function _d(e){return!Re(e,"__v_skip")&&Object.isExtensible(e)&&gl(e,"__v_skip",!0),e}const zt=e=>He(e)?Oo(e):e,sn=e=>He(e)?vs(e):e;function Ye(e){return e?e.__v_isRef===!0:!1}function fe(e){return Cd(e,!1)}function Cd(e,t){return Ye(e)?e:new $d(e,t)}class $d{constructor(t,i){this.dep=new zs,this.__v_isRef=!0,this.__v_isShallow=!1,this._rawValue=i?t:Pe(t),this._value=i?t:zt(t),this.__v_isShallow=i}get value(){return this.dep.track(),this._value}set value(t){const i=this._rawValue,n=this.__v_isShallow||Bt(t)||li(t);t=n?t:Pe(t),Kt(t,i)&&(this._rawValue=t,this._value=n?t:zt(t),this.dep.trigger())}}function ve(e){return Ye(e)?e.value:e}const Id={get:(e,t,i)=>t==="__v_raw"?e:ve(Reflect.get(e,t,i)),set:(e,t,i,n)=>{const o=e[t];return Ye(o)&&!Ye(i)?(o.value=i,!0):Reflect.set(e,t,i,n)}};function Ll(e){return Pi(e)?e:new Proxy(e,Id)}class Td{constructor(t,i,n){this.fn=t,this.setter=i,this._value=void 0,this.dep=new zs(this),this.__v_isRef=!0,this.deps=void 0,this.depsTail=void 0,this.flags=16,this.globalVersion=On-1,this.next=void 0,this.effect=this,this.__v_isReadonly=!i,this.isSSR=n}notify(){if(this.flags|=16,!(this.flags&8)&&Ke!==this)return xl(this,!0),!0}get value(){const t=this.dep.track();return Cl(this),t&&(t.version=this.dep.version),this._value}set value(t){this.setter&&this.setter(t)}}function Ed(e,t,i=!1){let n,o;return Ee(e)?n=e:(n=e.get,o=e.set),new Td(n,o,i)}const Yn={},vo=new WeakMap;let Ei;function Ad(e,t=!1,i=Ei){if(i){let n=vo.get(i);n||vo.set(i,n=[]),n.push(e)}}function Bd(e,t,i=We){const{immediate:n,deep:o,once:s,scheduler:l,augmentJob:r,call:a}=i,c=A=>o?A:Bt(A)||o===!1||o===0?ii(A,1):ii(A);let d,h,v,u,m=!1,f=!1;if(Ye(e)?(h=()=>e.value,m=Bt(e)):Pi(e)?(h=()=>c(e),m=!0):$e(e)?(f=!0,m=e.some(A=>Pi(A)||Bt(A)),h=()=>e.map(A=>{if(Ye(A))return A.value;if(Pi(A))return c(A);if(Ee(A))return a?a(A,2):A()})):Ee(e)?t?h=a?()=>a(e,2):e:h=()=>{if(v){si();try{v()}finally{ri()}}const A=Ei;Ei=d;try{return a?a(e,3,[u]):e(u)}finally{Ei=A}}:h=Zt,t&&o){const A=h,D=o===!0?1/0:o;h=()=>ii(A(),D)}const b=sd(),k=()=>{d.stop(),b&&b.active&&Ds(b.effects,d)};if(s&&t){const A=t;t=(...D)=>{const T=A(...D);return k(),T}}let x=f?new Array(e.length).fill(Yn):Yn;const C=A=>{if(!(!(d.flags&1)||!d.dirty&&!A))if(t){const D=d.run();if(A||o||m||(f?D.some((T,w)=>Kt(T,x[w])):Kt(D,x))){v&&v();const T=Ei;Ei=d;try{const w=[D,x===Yn?void 0:f&&x[0]===Yn?[]:x,u];x=D,a?a(t,3,w):t(...w)}finally{Ei=T}}}else d.run()};return r&&r(C),d=new kl(h),d.scheduler=l?()=>l(C,!1):C,u=A=>Ad(A,!1,d),v=d.onStop=()=>{const A=vo.get(d);if(A){if(a)a(A,4);else for(const D of A)D();vo.delete(d)}},t?n?C(!0):x=d.run():l?l(C.bind(null,!0),!0):d.run(),k.pause=d.pause.bind(d),k.resume=d.resume.bind(d),k.stop=k,k}function ii(e,t=1/0,i){if(t<=0||!He(e)||e.__v_skip||(i=i||new Map,(i.get(e)||0)>=t))return e;if(i.set(e,t),t--,Ye(e))ii(e.value,t,i);else if($e(e))for(let n=0;n<e.length;n++)ii(e[n],t,i);else if(cn(e)||Qi(e))e.forEach(n=>{ii(n,t,i)});else if(ml(e)){for(const n in e)ii(e[n],t,i);for(const n of Object.getOwnPropertySymbols(e))Object.prototype.propertyIsEnumerable.call(e,n)&&ii(e[n],t,i)}return e}/**
* @vue/runtime-core v3.5.40
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/function Wn(e,t,i,n){try{return n?e(...n):e()}catch(o){Po(o,t,i)}}function Ft(e,t,i,n){if(Ee(e)){const o=Wn(e,t,i,n);return o&&pl(o)&&o.catch(s=>{Po(s,t,i)}),o}if($e(e)){const o=[];for(let s=0;s<e.length;s++)o.push(Ft(e[s],t,i,n));return o}}function Po(e,t,i,n=!0){const o=t?t.vnode:null,{errorHandler:s,throwUnhandledErrorInProduction:l}=t&&t.appContext.config||We;if(t){let r=t.parent;const a=t.proxy,c=`https://vuejs.org/error-reference/#runtime-${i}`;for(;r;){const d=r.ec;if(d){for(let h=0;h<d.length;h++)if(d[h](e,a,c)===!1)return}r=r.parent}if(s){si(),Wn(s,null,10,[e,a,c]),ri();return}}Md(e,i,o,n,l)}function Md(e,t,i,n=!0,o=!1){if(o)throw e;console.error(e)}const bt=[];let Wt=-1;const en=[];let hi=null,Ui=0;const Ol=Promise.resolve();let bo=null;function yo(e){const t=bo||Ol;return e?t.then(this?e.bind(this):e):t}function Dd(e){let t=Wt+1,i=bt.length;for(;t<i;){const n=t+i>>>1,o=bt[n],s=Rn(o);s<e||s===e&&o.flags&2?t=n+1:i=n}return t}function Ws(e){if(!(e.flags&1)){const t=Rn(e),i=bt[bt.length-1];!i||!(e.flags&2)&&t>=Rn(i)?bt.push(e):bt.splice(Dd(t),0,e),e.flags|=1,Pl()}}function Pl(){bo||(bo=Ol.then(Nl))}function Ld(e){$e(e)?en.push(...e):hi&&e.id===-1?hi.splice(Ui+1,0,e):e.flags&1||(en.push(e),e.flags|=1),Pl()}function hr(e,t,i=Wt+1){for(;i<bt.length;i++){const n=bt[i];if(n&&n.flags&2){if(e&&n.id!==e.uid)continue;bt.splice(i,1),i--,n.flags&4&&(n.flags&=-2),n(),n.flags&4||(n.flags&=-2)}}}function Rl(e){if(en.length){const t=[...new Set(en)].sort((i,n)=>Rn(i)-Rn(n));if(en.length=0,hi){hi.push(...t);return}for(hi=t,Ui=0;Ui<hi.length;Ui++){const i=hi[Ui];i.flags&4&&(i.flags&=-2),i.flags&8||i(),i.flags&=-2}hi=null,Ui=0}}const Rn=e=>e.id==null?e.flags&2?-1:1/0:e.id;function Nl(e){try{for(Wt=0;Wt<bt.length;Wt++){const t=bt[Wt];t&&!(t.flags&8)&&(t.flags&4&&(t.flags&=-2),Wn(t,t.i,t.i?15:14),t.flags&4||(t.flags&=-2))}}finally{for(;Wt<bt.length;Wt++){const t=bt[Wt];t&&(t.flags&=-2)}Wt=-1,bt.length=0,Rl(),bo=null,(bt.length||en.length)&&Nl()}}let ct=null,zl=null;function ko(e){const t=ct;return ct=e,zl=e&&e.type.__scopeId||null,t}function Fl(e,t=ct,i){if(!t||e._n)return e;const n=(...o)=>{n._d&&$r(-1);const s=ko(t),l=ni.length;let r;try{r=e(...o)}finally{for(let a=ni.length;a>l;a--)qs();ko(s),n._d&&$r(1)}return r};return n._n=!0,n._c=!0,n._d=!0,n}function Et(e,t){if(ct===null)return e;const i=Ho(ct),n=e.dirs||(e.dirs=[]);for(let o=0;o<t.length;o++){let[s,l,r,a=We]=t[o];s&&(Ee(s)&&(s={mounted:s,updated:s}),s.deep&&ii(l),n.push({dir:s,instance:i,value:l,oldValue:void 0,arg:r,modifiers:a}))}return e}function _i(e,t,i,n){const o=e.dirs,s=t&&t.dirs;for(let l=0;l<o.length;l++){const r=o[l];s&&(r.oldValue=s[l].value);let a=r.dir[n];a&&(si(),Ft(a,i,8,[e.el,r,e,t]),ri())}}function Od(e,t){if(ht){let i=ht.provides;const n=ht.parent&&ht.parent.provides;n===i&&(i=ht.provides=Object.create(n)),i[e]=t}}function Rt(e,t,i=!1){const n=Du();if(n||nn){let o=nn?nn._context.provides:n?n.parent==null||n.ce?n.vnode.appContext&&n.vnode.appContext.provides:n.parent.provides:void 0;if(o&&e in o)return o[e];if(arguments.length>1)return i&&Ee(t)?t.call(n&&n.proxy):t}}const Pd=Symbol.for("v-scx"),Rd=()=>Rt(Pd);function ki(e,t,i){return Hl(e,t,i)}function Hl(e,t,i=We){const{immediate:n,deep:o,flush:s,once:l}=i,r=dt({},i),a=t&&n||!t&&s!=="post";let c;if(zn){if(s==="sync"){const u=Rd();c=u.__watcherHandles||(u.__watcherHandles=[])}else if(!a){const u=()=>{};return u.stop=Zt,u.resume=Zt,u.pause=Zt,u}}const d=ht;r.call=(u,m,f)=>Ft(u,d,m,f);let h=!1;s==="post"?r.scheduler=u=>{St(u,d&&d.suspense)}:s!=="sync"&&(h=!0,r.scheduler=(u,m)=>{m?u():Ws(u)}),r.augmentJob=u=>{t&&(u.flags|=4),h&&(u.flags|=2,d&&(u.id=d.uid,u.i=d))};const v=Bd(e,t,r);return zn&&(c?c.push(v):a&&v()),v}function Nd(e,t,i){const n=this.proxy,o=it(e)?e.includes(".")?jl(n,e):()=>n[e]:e.bind(n,n);let s;Ee(t)?s=t:(s=t.handler,i=t);const l=Un(this),r=Hl(o,s.bind(n),i);return l(),r}function jl(e,t){const i=t.split(".");return()=>{let n=e;for(let o=0;o<i.length&&n;o++)n=n[i[o]];return n}}const zd=Symbol("_vte"),Fd=e=>e.__isTeleport,Xo=Symbol("_leaveCb");function Us(e,t){e.shapeFlag&6&&e.component?(e.transition=t,Us(e.component.subTree,t)):e.shapeFlag&128?(e.ssContent.transition=t.clone(e.ssContent),e.ssFallback.transition=t.clone(e.ssFallback)):e.transition=t}function xt(e,t){return Ee(e)?dt({name:e.name},t,{setup:e}):e}function Wl(e){e.ids=[e.ids[0]+e.ids[2]+++"-",0,0]}function mr(e,t){let i;return!!((i=Object.getOwnPropertyDescriptor(e,t))&&!i.configurable)}const wo=new WeakMap;function Cn(e,t,i,n,o=!1){if($e(e)){e.forEach((f,b)=>Cn(f,t&&($e(t)?t[b]:t),i,n,o));return}if(tn(n)&&!o){n.shapeFlag&512&&n.type.__asyncResolved&&n.component.subTree.component&&Cn(e,t,i,n.component.subTree);return}const s=n.shapeFlag&4?Ho(n.component):n.el,l=o?null:s,{i:r,r:a}=e,c=t&&t.r,d=r.refs===We?r.refs={}:r.refs,h=r.setupState,v=Pe(h),u=h===We?fl:f=>mr(d,f)?!1:Re(v,f),m=(f,b)=>!(b&&mr(d,b));if(c!=null&&c!==a){if(gr(t),it(c))d[c]=null,u(c)&&(h[c]=null);else if(Ye(c)){const f=t;m(c,f.k)&&(c.value=null),f.k&&(d[f.k]=null)}}if(Ee(a))Wn(a,r,12,[l,d]);else{const f=it(a),b=Ye(a);if(f||b){const k=()=>{if(e.f){const x=f?u(a)?h[a]:d[a]:m()||!e.k?a.value:d[e.k];if(o)$e(x)&&Ds(x,s);else if($e(x))x.includes(s)||x.push(s);else if(f)d[a]=[s],u(a)&&(h[a]=d[a]);else{const C=[s];m(a,e.k)&&(a.value=C),e.k&&(d[e.k]=C)}}else f?(d[a]=l,u(a)&&(h[a]=l)):b&&(m(a,e.k)&&(a.value=l),e.k&&(d[e.k]=l))};if(l){const x=()=>{k(),wo.delete(e)};x.id=-1,wo.set(e,x),St(x,i)}else gr(e),k()}}}function gr(e){const t=wo.get(e);t&&(t.flags|=8,wo.delete(e))}Do().requestIdleCallback;Do().cancelIdleCallback;const tn=e=>!!e.type.__asyncLoader,Ul=e=>e.type.__isKeepAlive;function Hd(e,t){Vl(e,"a",t)}function jd(e,t){Vl(e,"da",t)}function Vl(e,t,i=ht){const n=e.__wdc||(e.__wdc=()=>{let o=i;for(;o;){if(o.isDeactivated)return;o=o.parent}return e()});if(Ro(t,n,i),i){let o=i.parent;for(;o&&o.parent;)Ul(o.parent.vnode)&&Wd(n,t,i,o),o=o.parent}}function Wd(e,t,i,n){const o=Ro(t,e,n,!0);No(()=>{Ds(n[t],o)},i)}function Ro(e,t,i=ht,n=!1){if(i){const o=i[e]||(i[e]=[]),s=t.__weh||(t.__weh=(...l)=>{si();const r=Un(i),a=Ft(t,i,e,l);return r(),ri(),a});return n?o.unshift(s):o.push(s),s}}const ci=e=>(t,i=ht)=>{(!zn||e==="sp")&&Ro(e,(...n)=>t(...n),i)},Ud=ci("bm"),un=ci("m"),Vd=ci("bu"),Kd=ci("u"),Vs=ci("bum"),No=ci("um"),Gd=ci("sp"),qd=ci("rtg"),Zd=ci("rtc");function Yd(e,t=ht){Ro("ec",e,t)}const Jd="components";function Xd(e,t){return eu(Jd,e,!0,t)||e}const Qd=Symbol.for("v-ndc");function eu(e,t,i=!0,n=!1){const o=ct||ht;if(o){const s=o.type;{const r=Nu(s,!1);if(r&&(r===t||r===wt(t)||r===Bo(wt(t))))return s}const l=vr(o[e]||s[e],t)||vr(o.appContext[e],t);return!l&&n?s:l}}function vr(e,t){return e&&(e[t]||e[wt(t)]||e[Bo(wt(t))])}function kt(e,t,i,n){let o;const s=i,l=$e(e);if(l||it(e)){const r=l&&Pi(e);let a=!1,c=!1;r&&(a=!Bt(e),c=li(e),e=Lo(e)),o=new Array(e.length);for(let d=0,h=e.length;d<h;d++)o[d]=t(a?c?sn(zt(e[d])):zt(e[d]):e[d],d,void 0,s)}else if(typeof e=="number"){o=new Array(e);for(let r=0;r<e;r++)o[r]=t(r+1,r,void 0,s)}else if(He(e))if(e[Symbol.iterator])o=Array.from(e,(r,a)=>t(r,a,void 0,s));else{const r=Object.keys(e);o=new Array(r.length);for(let a=0,c=r.length;a<c;a++){const d=r[a];o[a]=t(e[d],d,a,s)}}else o=[];return o}function Jn(e,t,i={},n,o,s){if(ct.ce||ct.parent&&tn(ct.parent)&&ct.parent.ce){const c=i,d=Object.keys(c).length>0;return t!=="default"&&(c.name=t),Q(),Ot(Ue,null,[le("slot",c,n&&n())],d?-2:64)}let l=e[t];l&&l._c&&(l._d=!1);const r=ni.length;Q();let a;try{const c=l&&Kl(l(i)),d=i.key||s||c&&c.key;a=Ot(Ue,{key:(d&&!Nt(d)?d:`_${t}`)+(!c&&n?"_fb":"")},c||(n?n():[]),c&&e._===1?64:-2)}catch(c){for(let d=ni.length;d>r;d--)qs();throw c}finally{l&&l._c&&(l._d=!0)}return a}function Kl(e){return e.some(t=>Zs(t)?!(t.type===ai||t.type===Ue&&!Kl(t.children)):!0)?e:null}const bs=e=>e?fa(e)?Ho(e):bs(e.parent):null,$n=dt(Object.create(null),{$:e=>e,$el:e=>e.vnode.el,$data:e=>e.data,$props:e=>e.props,$attrs:e=>e.attrs,$slots:e=>e.slots,$refs:e=>e.refs,$parent:e=>bs(e.parent),$root:e=>bs(e.root),$host:e=>e.ce,$emit:e=>e.emit,$options:e=>ql(e),$forceUpdate:e=>e.f||(e.f=()=>{Ws(e.update)}),$nextTick:e=>e.n||(e.n=yo.bind(e.proxy)),$watch:e=>Nd.bind(e)}),Qo=(e,t)=>e!==We&&!e.__isScriptSetup&&Re(e,t),tu={get({_:e},t){if(t==="__v_skip")return!0;const{ctx:i,setupState:n,data:o,props:s,accessCache:l,type:r,appContext:a}=e;if(t[0]!=="$"){const v=l[t];if(v!==void 0)switch(v){case 1:return n[t];case 2:return o[t];case 4:return i[t];case 3:return s[t]}else{if(Qo(n,t))return l[t]=1,n[t];if(o!==We&&Re(o,t))return l[t]=2,o[t];if(Re(s,t))return l[t]=3,s[t];if(i!==We&&Re(i,t))return l[t]=4,i[t];ys&&(l[t]=0)}}const c=$n[t];let d,h;if(c)return t==="$attrs"&&pt(e.attrs,"get",""),c(e);if((d=r.__cssModules)&&(d=d[t]))return d;if(i!==We&&Re(i,t))return l[t]=4,i[t];if(h=a.config.globalProperties,Re(h,t))return h[t]},set({_:e},t,i){const{data:n,setupState:o,ctx:s}=e;return Qo(o,t)?(o[t]=i,!0):n!==We&&Re(n,t)?(n[t]=i,!0):Re(e.props,t)||t[0]==="$"&&t.slice(1)in e?!1:(s[t]=i,!0)},has({_:{data:e,setupState:t,accessCache:i,ctx:n,appContext:o,props:s,type:l}},r){let a;return!!(i[r]||e!==We&&r[0]!=="$"&&Re(e,r)||Qo(t,r)||Re(s,r)||Re(n,r)||Re($n,r)||Re(o.config.globalProperties,r)||(a=l.__cssModules)&&a[r])},defineProperty(e,t,i){return i.get!=null?e._.accessCache[t]=0:Re(i,"value")&&this.set(e,t,i.value,null),Reflect.defineProperty(e,t,i)}};function br(e){return $e(e)?e.reduce((t,i)=>(t[i]=null,t),{}):e}let ys=!0;function iu(e){const t=ql(e),i=e.proxy,n=e.ctx;ys=!1,t.beforeCreate&&yr(t.beforeCreate,e,"bc");const{data:o,computed:s,methods:l,watch:r,provide:a,inject:c,created:d,beforeMount:h,mounted:v,beforeUpdate:u,updated:m,activated:f,deactivated:b,beforeDestroy:k,beforeUnmount:x,destroyed:C,unmounted:A,render:D,renderTracked:T,renderTriggered:w,errorCaptured:R,serverPrefetch:N,expose:F,inheritAttrs:q,components:_,directives:L,filters:y}=t;if(c&&nu(c,n,null),l)for(const E in l){const O=l[E];Ee(O)&&(n[E]=O.bind(i))}if(o){const E=o.call(i,i);He(E)&&(e.data=Oo(E))}if(ys=!0,s)for(const E in s){const O=s[E],z=Ee(O)?O.bind(i,i):Ee(O.get)?O.get.bind(i,i):Zt,X=!Ee(O)&&Ee(O.set)?O.set.bind(i):Zt,Z=we({get:z,set:X});Object.defineProperty(n,E,{enumerable:!0,configurable:!0,get:()=>Z.value,set:W=>Z.value=W})}if(r)for(const E in r)Gl(r[E],n,i,E);if(a){const E=Ee(a)?a.call(i):a;Reflect.ownKeys(E).forEach(O=>{Od(O,E[O])})}d&&yr(d,e,"c");function H(E,O){$e(O)?O.forEach(z=>E(z.bind(i))):O&&E(O.bind(i))}if(H(Ud,h),H(un,v),H(Vd,u),H(Kd,m),H(Hd,f),H(jd,b),H(Yd,R),H(Zd,T),H(qd,w),H(Vs,x),H(No,A),H(Gd,N),$e(F))if(F.length){const E=e.exposed||(e.exposed={});F.forEach(O=>{Object.defineProperty(E,O,{get:()=>i[O],set:z=>i[O]=z,enumerable:!0})})}else e.exposed||(e.exposed={});D&&e.render===Zt&&(e.render=D),q!=null&&(e.inheritAttrs=q),_&&(e.components=_),L&&(e.directives=L),N&&Wl(e)}function nu(e,t,i=Zt){$e(e)&&(e=ks(e));for(const n in e){const o=e[n];let s;He(o)?"default"in o?s=Rt(o.from||n,o.default,!0):s=Rt(o.from||n):s=Rt(o),Ye(s)?Object.defineProperty(t,n,{enumerable:!0,configurable:!0,get:()=>s.value,set:l=>s.value=l}):t[n]=s}}function yr(e,t,i){Ft($e(e)?e.map(n=>n.bind(t.proxy)):e.bind(t.proxy),t,i)}function Gl(e,t,i,n){let o=n.includes(".")?jl(i,n):()=>i[n];if(it(e)){const s=t[e];Ee(s)&&ki(o,s)}else if(Ee(e))ki(o,e.bind(i));else if(He(e))if($e(e))e.forEach(s=>Gl(s,t,i,n));else{const s=Ee(e.handler)?e.handler.bind(i):t[e.handler];Ee(s)&&ki(o,s,e)}}function ql(e){const t=e.type,{mixins:i,extends:n}=t,{mixins:o,optionsCache:s,config:{optionMergeStrategies:l}}=e.appContext,r=s.get(t);let a;return r?a=r:!o.length&&!i&&!n?a=t:(a={},o.length&&o.forEach(c=>xo(a,c,l,!0)),xo(a,t,l)),He(t)&&s.set(t,a),a}function xo(e,t,i,n=!1){const{mixins:o,extends:s}=t;s&&xo(e,s,i,!0),o&&o.forEach(l=>xo(e,l,i,!0));for(const l in t)if(!(n&&l==="expose")){const r=ou[l]||i&&i[l];e[l]=r?r(e[l],t[l]):t[l]}return e}const ou={data:kr,props:wr,emits:wr,methods:yn,computed:yn,beforeCreate:vt,created:vt,beforeMount:vt,mounted:vt,beforeUpdate:vt,updated:vt,beforeDestroy:vt,beforeUnmount:vt,destroyed:vt,unmounted:vt,activated:vt,deactivated:vt,errorCaptured:vt,serverPrefetch:vt,components:yn,directives:yn,watch:ru,provide:kr,inject:su};function kr(e,t){return t?e?function(){return dt(Ee(e)?e.call(this,this):e,Ee(t)?t.call(this,this):t)}:t:e}function su(e,t){return yn(ks(e),ks(t))}function ks(e){if($e(e)){const t={};for(let i=0;i<e.length;i++)t[e[i]]=e[i];return t}return e}function vt(e,t){return e?[...new Set([].concat(e,t))]:t}function yn(e,t){return e?dt(Object.create(null),e,t):t}function wr(e,t){return e?$e(e)&&$e(t)?[...new Set([...e,...t])]:dt(Object.create(null),br(e),br(t??{})):t}function ru(e,t){if(!e)return t;if(!t)return e;const i=dt(Object.create(null),e);for(const n in t)i[n]=vt(e[n],t[n]);return i}function Zl(){return{app:null,config:{isNativeTag:fl,performance:!1,globalProperties:{},optionMergeStrategies:{},errorHandler:void 0,warnHandler:void 0,compilerOptions:{}},mixins:[],components:{},directives:{},provides:Object.create(null),optionsCache:new WeakMap,propsCache:new WeakMap,emitsCache:new WeakMap}}let lu=0;function au(e,t){return function(n,o=null){Ee(n)||(n=dt({},n)),o!=null&&!He(o)&&(o=null);const s=Zl(),l=new WeakSet,r=[];let a=!1;const c=s.app={_uid:lu++,_component:n,_props:o,_container:null,_context:s,_instance:null,version:Fu,get config(){return s.config},set config(d){},use(d,...h){return l.has(d)||(d&&Ee(d.install)?(l.add(d),d.install(c,...h)):Ee(d)&&(l.add(d),d(c,...h))),c},mixin(d){return s.mixins.includes(d)||s.mixins.push(d),c},component(d,h){return h?(s.components[d]=h,c):s.components[d]},directive(d,h){return h?(s.directives[d]=h,c):s.directives[d]},mount(d,h,v){if(!a){const u=c._ceVNode||le(n,o);return u.appContext=s,v===!0?v="svg":v===!1&&(v=void 0),e(u,d,v),a=!0,c._container=d,d.__vue_app__=c,Ho(u.component)}},onUnmount(d){r.push(d)},unmount(){a&&(Ft(r,c._instance,16),e(null,c._container),delete c._container.__vue_app__)},provide(d,h){return s.provides[d]=h,c},runWithContext(d){const h=nn;nn=c;try{return d()}finally{nn=h}}};return c}}let nn=null;const cu=(e,t)=>t==="modelValue"||t==="model-value"?e.modelModifiers:e[`${t}Modifiers`]||e[`${wt(t)}Modifiers`]||e[`${xi(t)}Modifiers`];function du(e,t,...i){if(e.isUnmounted)return;const n=e.vnode.props||We;let o=i;const s=t.startsWith("update:"),l=s&&cu(n,t.slice(7));l&&(l.trim&&(o=i.map(d=>it(d)?d.trim():d)),l.number&&(o=i.map(Mo)));let r,a=n[r=Go(t)]||n[r=Go(wt(t))];!a&&s&&(a=n[r=Go(xi(t))]),a&&Ft(a,e,6,o);const c=n[r+"Once"];if(c){if(!e.emitted)e.emitted={};else if(e.emitted[r])return;e.emitted[r]=!0,Ft(c,e,6,o)}}const uu=new WeakMap;function Yl(e,t,i=!1){const n=i?uu:t.emitsCache,o=n.get(e);if(o!==void 0)return o;const s=e.emits;let l={},r=!1;if(!Ee(e)){const a=c=>{const d=Yl(c,t,!0);d&&(r=!0,dt(l,d))};!i&&t.mixins.length&&t.mixins.forEach(a),e.extends&&a(e.extends),e.mixins&&e.mixins.forEach(a)}return!s&&!r?(He(e)&&n.set(e,null),null):($e(s)?s.forEach(a=>l[a]=null):dt(l,s),He(e)&&n.set(e,l),l)}function zo(e,t){return!e||!To(t)?!1:(t=t.slice(2),t=t==="Once"?t:t.replace(/Once$/,""),Re(e,t[0].toLowerCase()+t.slice(1))||Re(e,xi(t))||Re(e,t))}function xr(e){const{type:t,vnode:i,proxy:n,withProxy:o,propsOptions:[s],slots:l,attrs:r,emit:a,render:c,renderCache:d,props:h,data:v,setupState:u,ctx:m,inheritAttrs:f}=e,b=ko(e);let k,x;try{if(i.shapeFlag&4){const A=o||n,D=A;k=Vt(c.call(D,A,d,h,u,v,m)),x=r}else{const A=t;k=Vt(A.length>1?A(h,{attrs:r,slots:l,emit:a}):A(h,null)),x=t.props?r:fu(r)}}catch(A){ni.length=0,Po(A,e,1),k=le(ai)}let C=k;if(x&&f!==!1){const A=Object.keys(x),{shapeFlag:D}=C;A.length&&D&7&&(s&&A.some(Eo)&&(x=pu(x,s)),C=rn(C,x,!1,!0))}return i.dirs&&(C=rn(C,null,!1,!0),C.dirs=C.dirs?C.dirs.concat(i.dirs):i.dirs),i.transition&&Us(C,i.transition),k=C,ko(b),k}const fu=e=>{let t;for(const i in e)(i==="class"||i==="style"||To(i))&&((t||(t={}))[i]=e[i]);return t},pu=(e,t)=>{const i={};for(const n in e)(!Eo(n)||!(n.slice(9)in t))&&(i[n]=e[n]);return i};function hu(e,t,i){const{props:n,children:o,component:s}=e,{props:l,children:r,patchFlag:a}=t,c=s.emitsOptions;if(t.dirs||t.transition)return!0;if(i&&a>=0){if(a&1024)return!0;if(a&16)return n?Sr(n,l,c):!!l;if(a&8){const d=t.dynamicProps;for(let h=0;h<d.length;h++){const v=d[h];if(Jl(l,n,v)&&!zo(c,v))return!0}}}else return(o||r)&&(!r||!r.$stable)?!0:n===l?!1:n?l?Sr(n,l,c):!0:!!l;return!1}function Sr(e,t,i){const n=Object.keys(t);if(n.length!==Object.keys(e).length)return!0;for(let o=0;o<n.length;o++){const s=n[o];if(Jl(t,e,s)&&!zo(i,s))return!0}return!1}function Jl(e,t,i){const n=e[i],o=t[i];return i==="style"&&He(n)&&He(o)?!dn(n,o):n!==o}function mu({vnode:e,parent:t,suspense:i},n){for(;t;){const o=t.subTree;if(o.suspense&&o.suspense.activeBranch===e&&(o.suspense.vnode.el=o.el=n,e=o),o===e)(e=t.vnode).el=n,t=t.parent;else break}i&&i.activeBranch===e&&(i.vnode.el=n)}const Xl={},Ql=()=>Object.create(Xl),ea=e=>Object.getPrototypeOf(e)===Xl;function gu(e,t,i,n=!1){const o={},s=Ql();e.propsDefaults=Object.create(null),ta(e,t,o,s);for(const l in e.propsOptions[0])l in o||(o[l]=void 0);i?e.props=n?o:Sd(o):e.type.props?e.props=o:e.props=s,e.attrs=s}function vu(e,t,i,n){const{props:o,attrs:s,vnode:{patchFlag:l}}=e,r=Pe(o),[a]=e.propsOptions;let c=!1;if((n||l>0)&&!(l&16)){if(l&8){const d=e.vnode.dynamicProps;for(let h=0;h<d.length;h++){let v=d[h];if(zo(e.emitsOptions,v))continue;const u=t[v];if(a)if(Re(s,v))u!==s[v]&&(s[v]=u,c=!0);else{const m=wt(v);o[m]=ws(a,r,m,u,e,!1)}else u!==s[v]&&(s[v]=u,c=!0)}}}else{ta(e,t,o,s)&&(c=!0);let d;for(const h in r)(!t||!Re(t,h)&&((d=xi(h))===h||!Re(t,d)))&&(a?i&&(i[h]!==void 0||i[d]!==void 0)&&(o[h]=ws(a,r,h,void 0,e,!0)):delete o[h]);if(s!==r)for(const h in s)(!t||!Re(t,h))&&(delete s[h],c=!0)}c&&ti(e.attrs,"set","")}function ta(e,t,i,n){const[o,s]=e.propsOptions;let l=!1,r;if(t)for(let a in t){if(xn(a))continue;const c=t[a];let d;o&&Re(o,d=wt(a))?!s||!s.includes(d)?i[d]=c:(r||(r={}))[d]=c:zo(e.emitsOptions,a)||(!(a in n)||c!==n[a])&&(n[a]=c,l=!0)}if(s){const a=Pe(i),c=r||We;for(let d=0;d<s.length;d++){const h=s[d];i[h]=ws(o,a,h,c[h],e,!Re(c,h))}}return l}function ws(e,t,i,n,o,s){const l=e[i];if(l!=null){const r=Re(l,"default");if(r&&n===void 0){const a=l.default;if(l.type!==Function&&!l.skipFactory&&Ee(a)){const{propsDefaults:c}=o;if(i in c)n=c[i];else{const d=Un(o);n=c[i]=a.call(null,t),d()}}else n=a;o.ce&&o.ce._setProp(i,n)}l[0]&&(s&&!r?n=!1:l[1]&&(n===""||n===xi(i))&&(n=!0))}return n}const bu=new WeakMap;function ia(e,t,i=!1){const n=i?bu:t.propsCache,o=n.get(e);if(o)return o;const s=e.props,l={},r=[];let a=!1;if(!Ee(e)){const d=h=>{a=!0;const[v,u]=ia(h,t,!0);dt(l,v),u&&r.push(...u)};!i&&t.mixins.length&&t.mixins.forEach(d),e.extends&&d(e.extends),e.mixins&&e.mixins.forEach(d)}if(!s&&!a)return He(e)&&n.set(e,Xi),Xi;if($e(s))for(let d=0;d<s.length;d++){const h=wt(s[d]);_r(h)&&(l[h]=We)}else if(s)for(const d in s){const h=wt(d);if(_r(h)){const v=s[d],u=l[h]=$e(v)||Ee(v)?{type:v}:dt({},v),m=u.type;let f=!1,b=!0;if($e(m))for(let k=0;k<m.length;++k){const x=m[k],C=Ee(x)&&x.name;if(C==="Boolean"){f=!0;break}else C==="String"&&(b=!1)}else f=Ee(m)&&m.name==="Boolean";u[0]=f,u[1]=b,(f||Re(u,"default"))&&r.push(h)}}const c=[l,r];return He(e)&&n.set(e,c),c}function _r(e){return e[0]!=="$"&&!xn(e)}const Ks=e=>e==="_"||e==="_ctx"||e==="$stable",Gs=e=>$e(e)?e.map(Vt):[Vt(e)],yu=(e,t,i)=>{if(t._n)return t;const n=Fl((...o)=>Gs(t(...o)),i);return n._c=!1,n},na=(e,t,i)=>{const n=e._ctx;for(const o in e){if(Ks(o))continue;const s=e[o];if(Ee(s))t[o]=yu(o,s,n);else if(s!=null){const l=Gs(s);t[o]=()=>l}}},oa=(e,t)=>{const i=Gs(t);e.slots.default=()=>i},sa=(e,t,i)=>{for(const n in t)(i||!Ks(n))&&(e[n]=t[n])},ku=(e,t,i)=>{const n=e.slots=Ql();if(e.vnode.shapeFlag&32){const o=t._;o?(sa(n,t,i),i&&gl(n,"_",o,!0)):na(t,n)}else t&&oa(e,t)},wu=(e,t,i)=>{const{vnode:n,slots:o}=e;let s=!0,l=We;if(n.shapeFlag&32){const r=t._;r?i&&r===1?s=!1:sa(o,t,i):(s=!t.$stable,na(t,o)),l=t}else t&&(oa(e,t),l={default:1});if(s)for(const r in o)!Ks(r)&&l[r]==null&&delete o[r]},St=$u;function xu(e){return Su(e)}function Su(e,t){const i=Do();i.__VUE__=!0;const{insert:n,remove:o,patchProp:s,createElement:l,createText:r,createComment:a,setText:c,setElementText:d,parentNode:h,nextSibling:v,setScopeId:u=Zt,insertStaticContent:m}=e,f=(P,j,g,K=null,B=null,S=null,I=void 0,$=null,U=!!j.dynamicChildren)=>{if(P===j)return;P&&!vn(P,j)&&(K=Ie(P),W(P,B,S,!0),P=null),j.patchFlag===-2&&(U=!1,j.dynamicChildren=null);const{type:V,ref:G,shapeFlag:ee}=j;switch(V){case Fo:b(P,j,g,K);break;case ai:k(P,j,g,K);break;case no:P==null&&x(j,g,K,I);break;case Ue:_(P,j,g,K,B,S,I,$,U);break;default:ee&1?D(P,j,g,K,B,S,I,$,U):ee&6?L(P,j,g,K,B,S,I,$,U):(ee&64||ee&128)&&V.process(P,j,g,K,B,S,I,$,U,Y)}G!=null&&B?Cn(G,P&&P.ref,S,j||P,!j):G==null&&P&&P.ref!=null&&Cn(P.ref,null,S,P,!0)},b=(P,j,g,K)=>{if(P==null)n(j.el=r(j.children),g,K);else{const B=j.el=P.el;j.children!==P.children&&c(B,j.children)}},k=(P,j,g,K)=>{P==null?n(j.el=a(j.children||""),g,K):j.el=P.el},x=(P,j,g,K)=>{[P.el,P.anchor]=m(P.children,j,g,K,P.el,P.anchor)},C=({el:P,anchor:j},g,K)=>{let B;for(;P&&P!==j;)B=v(P),n(P,g,K),P=B;n(j,g,K)},A=({el:P,anchor:j})=>{let g;for(;P&&P!==j;)g=v(P),o(P),P=g;o(j)},D=(P,j,g,K,B,S,I,$,U)=>{if(j.type==="svg"?I="svg":j.type==="math"&&(I="mathml"),P==null)T(j,g,K,B,S,I,$,U);else{const V=P.el&&P.el._isVueCE?P.el:null;try{V&&V._beginPatch(),N(P,j,B,S,I,$,U)}finally{V&&V._endPatch()}}},T=(P,j,g,K,B,S,I,$)=>{let U,V;const{props:G,shapeFlag:ee,transition:oe,dirs:ne}=P;if(U=P.el=l(P.type,S,G&&G.is,G),ee&8?d(U,P.children):ee&16&&R(P.children,U,null,K,B,es(P,S),I,$),ne&&_i(P,null,K,"created"),w(U,P,P.scopeId,I,K),G){for(const _e in G)_e!=="value"&&!xn(_e)&&s(U,_e,null,G[_e],S,K);"value"in G&&s(U,"value",null,G.value,S),(V=G.onVnodeBeforeMount)&&jt(V,K,P)}ne&&_i(P,null,K,"beforeMount");const pe=_u(B,oe);pe&&oe.beforeEnter(U),n(U,j,g),((V=G&&G.onVnodeMounted)||pe||ne)&&St(()=>{try{V&&jt(V,K,P),pe&&oe.enter(U),ne&&_i(P,null,K,"mounted")}finally{}},B)},w=(P,j,g,K,B)=>{if(g&&u(P,g),K)for(let S=0;S<K.length;S++)u(P,K[S]);if(B){let S=B.subTree;if(j===S||ca(S.type)&&(S.ssContent===j||S.ssFallback===j)){const I=B.vnode;w(P,I,I.scopeId,I.slotScopeIds,B.parent)}}},R=(P,j,g,K,B,S,I,$,U=0)=>{for(let V=U;V<P.length;V++){const G=P[V]=$?ei(P[V]):Vt(P[V]);f(null,G,j,g,K,B,S,I,$)}},N=(P,j,g,K,B,S,I)=>{const $=j.el=P.el;let{patchFlag:U,dynamicChildren:V,dirs:G}=j;U|=P.patchFlag&16;const ee=P.props||We,oe=j.props||We;let ne;if(g&&Ci(g,!1),(ne=oe.onVnodeBeforeUpdate)&&jt(ne,g,j,P),G&&_i(j,P,g,"beforeUpdate"),g&&Ci(g,!0),V&&(!P.dynamicChildren||P.dynamicChildren.length!==V.length)&&(U=0,I=!1,V=null),(ee.innerHTML&&oe.innerHTML==null||ee.textContent&&oe.textContent==null)&&d($,""),V?F(P.dynamicChildren,V,$,g,K,es(j,B),S):I||O(P,j,$,null,g,K,es(j,B),S,!1),U>0){if(U&16)q($,ee,oe,g,B);else if(U&2&&ee.class!==oe.class&&s($,"class",null,oe.class,B),U&4&&s($,"style",ee.style,oe.style,B),U&8){const pe=j.dynamicProps;for(let _e=0;_e<pe.length;_e++){const xe=pe[_e],Me=ee[xe],Ve=oe[xe];(Ve!==Me||xe==="value")&&s($,xe,Me,Ve,B,g)}}U&1&&P.children!==j.children&&d($,j.children)}else!I&&V==null&&q($,ee,oe,g,B);((ne=oe.onVnodeUpdated)||G)&&St(()=>{ne&&jt(ne,g,j,P),G&&_i(j,P,g,"updated")},K)},F=(P,j,g,K,B,S,I)=>{for(let $=0;$<j.length;$++){const U=P[$],V=j[$],G=U.el&&(U.type===Ue||!vn(U,V)||U.shapeFlag&198)?h(U.el):g;f(U,V,G,null,K,B,S,I,!0)}},q=(P,j,g,K,B)=>{if(j!==g){if(j!==We)for(const S in j)!xn(S)&&!(S in g)&&s(P,S,j[S],null,B,K);for(const S in g){if(xn(S))continue;const I=g[S],$=j[S];I!==$&&S!=="value"&&s(P,S,$,I,B,K)}"value"in g&&s(P,"value",j.value,g.value,B)}},_=(P,j,g,K,B,S,I,$,U)=>{const V=j.el=P?P.el:r(""),G=j.anchor=P?P.anchor:r("");let{patchFlag:ee,dynamicChildren:oe,slotScopeIds:ne}=j;ne&&($=$?$.concat(ne):ne),P==null?(n(V,g,K),n(G,g,K),R(j.children||[],g,G,B,S,I,$,U)):ee>0&&ee&64&&oe&&P.dynamicChildren&&P.dynamicChildren.length===oe.length?(F(P.dynamicChildren,oe,g,B,S,I,$),(j.key!=null||B&&j===B.subTree)&&ra(P,j,!0)):O(P,j,g,G,B,S,I,$,U)},L=(P,j,g,K,B,S,I,$,U)=>{j.slotScopeIds=$,P==null?j.shapeFlag&512?B.ctx.activate(j,g,K,I,U):y(j,g,K,B,S,I,U):M(P,j,U)},y=(P,j,g,K,B,S,I)=>{const $=P.component=Mu(P,K,B);if(Ul(P)&&($.ctx.renderer=Y),Lu($,!1,I),$.asyncDep){if(B&&B.registerDep($,H,I),!P.el){const U=$.subTree=le(ai);k(null,U,j,g),P.placeholder=U.el}}else H($,P,j,g,B,S,I)},M=(P,j,g)=>{const K=j.component=P.component;if(hu(P,j,g))if(K.asyncDep&&!K.asyncResolved){E(K,j,g);return}else K.next=j,K.update();else j.el=P.el,K.vnode=j},H=(P,j,g,K,B,S,I)=>{const $=()=>{if(P.isMounted){let{next:ee,bu:oe,u:ne,parent:pe,vnode:_e}=P;{const Je=la(P);if(Je){ee&&(ee.el=_e.el,E(P,ee,I)),Je.asyncDep.then(()=>{St(()=>{P.isUnmounted||V()},B)});return}}let xe=ee,Me;Ci(P,!1),ee?(ee.el=_e.el,E(P,ee,I)):ee=_e,oe&&io(oe),(Me=ee.props&&ee.props.onVnodeBeforeUpdate)&&jt(Me,pe,ee,_e),Ci(P,!0);const Ve=xr(P),qe=P.subTree;P.subTree=Ve,f(qe,Ve,h(qe.el),Ie(qe),P,B,S),ee.el=Ve.el,xe===null&&mu(P,Ve.el),ne&&St(ne,B),(Me=ee.props&&ee.props.onVnodeUpdated)&&St(()=>jt(Me,pe,ee,_e),B)}else{let ee;const{el:oe,props:ne}=j,{bm:pe,m:_e,parent:xe,root:Me,type:Ve}=P,qe=tn(j);Ci(P,!1),pe&&io(pe),!qe&&(ee=ne&&ne.onVnodeBeforeMount)&&jt(ee,xe,j),Ci(P,!0);{Me.ce&&Me.ce._hasShadowRoot()&&Me.ce._injectChildStyle(Ve,P.parent?P.parent.type:void 0);const Je=P.subTree=xr(P);f(null,Je,g,K,P,B,S),j.el=Je.el}if(_e&&St(_e,B),!qe&&(ee=ne&&ne.onVnodeMounted)){const Je=j;St(()=>jt(ee,xe,Je),B)}(j.shapeFlag&256||xe&&tn(xe.vnode)&&xe.vnode.shapeFlag&256)&&P.a&&St(P.a,B),P.isMounted=!0,j=g=K=null}};P.scope.on();const U=P.effect=new kl($);P.scope.off();const V=P.update=U.run.bind(U),G=P.job=U.runIfDirty.bind(U);G.i=P,G.id=P.uid,U.scheduler=()=>Ws(G),Ci(P,!0),V()},E=(P,j,g)=>{j.component=P;const K=P.vnode.props;P.vnode=j,P.next=null,vu(P,j.props,K,g),wu(P,j.children,g),si(),hr(P),ri()},O=(P,j,g,K,B,S,I,$,U=!1)=>{const V=P&&P.children,G=P?P.shapeFlag:0,ee=j.children,{patchFlag:oe,shapeFlag:ne}=j;if(oe>0){if(oe&128){X(V,ee,g,K,B,S,I,$,U);return}else if(oe&256){z(V,ee,g,K,B,S,I,$,U);return}}ne&8?(G&16&&ue(V,B,S),ee!==V&&d(g,ee)):G&16?ne&16?X(V,ee,g,K,B,S,I,$,U):ue(V,B,S,!0):(G&8&&d(g,""),ne&16&&R(ee,g,K,B,S,I,$,U))},z=(P,j,g,K,B,S,I,$,U)=>{P=P||Xi,j=j||Xi;const V=P.length,G=j.length,ee=Math.min(V,G);let oe;for(oe=0;oe<ee;oe++){const ne=j[oe]=U?ei(j[oe]):Vt(j[oe]);f(P[oe],ne,g,null,B,S,I,$,U)}V>G?ue(P,B,S,!0,!1,ee):R(j,g,K,B,S,I,$,U,ee)},X=(P,j,g,K,B,S,I,$,U)=>{let V=0;const G=j.length;let ee=P.length-1,oe=G-1;for(;V<=ee&&V<=oe;){const ne=P[V],pe=j[V]=U?ei(j[V]):Vt(j[V]);if(vn(ne,pe))f(ne,pe,g,null,B,S,I,$,U);else break;V++}for(;V<=ee&&V<=oe;){const ne=P[ee],pe=j[oe]=U?ei(j[oe]):Vt(j[oe]);if(vn(ne,pe))f(ne,pe,g,null,B,S,I,$,U);else break;ee--,oe--}if(V>ee){if(V<=oe){const ne=oe+1,pe=ne<G?j[ne].el:K;for(;V<=oe;)f(null,j[V]=U?ei(j[V]):Vt(j[V]),g,pe,B,S,I,$,U),V++}}else if(V>oe)for(;V<=ee;)W(P[V],B,S,!0),V++;else{const ne=V,pe=V,_e=new Map;for(V=pe;V<=oe;V++){const rt=j[V]=U?ei(j[V]):Vt(j[V]);rt.key!=null&&_e.set(rt.key,V)}let xe,Me=0;const Ve=oe-pe+1;let qe=!1,Je=0;const De=new Array(Ve);for(V=0;V<Ve;V++)De[V]=0;for(V=ne;V<=ee;V++){const rt=P[V];if(Me>=Ve){W(rt,B,S,!0);continue}let Xe;if(rt.key!=null)Xe=_e.get(rt.key);else for(xe=pe;xe<=oe;xe++)if(De[xe-pe]===0&&vn(rt,j[xe])){Xe=xe;break}Xe===void 0?W(rt,B,S,!0):(De[Xe-pe]=V+1,Xe>=Je?Je=Xe:qe=!0,f(rt,j[Xe],g,null,B,S,I,$,U),Me++)}const Jt=qe?Cu(De):Xi;for(xe=Jt.length-1,V=Ve-1;V>=0;V--){const rt=pe+V,Xe=j[rt],Ht=j[rt+1],Fi=rt+1<G?Ht.el||aa(Ht):K;De[V]===0?f(null,Xe,g,Fi,B,S,I,$,U):qe&&(xe<0||V!==Jt[xe]?Z(Xe,g,Fi,2):xe--)}}},Z=(P,j,g,K,B=null)=>{const{el:S,type:I,transition:$,children:U,shapeFlag:V}=P;if(V&6){Z(P.component.subTree,j,g,K);return}if(V&128){P.suspense.move(j,g,K);return}if(V&64){I.move(P,j,g,Y);return}if(I===Ue){n(S,j,g);for(let ee=0;ee<U.length;ee++)Z(U[ee],j,g,K);n(P.anchor,j,g);return}if(I===no){C(P,j,g);return}if(K!==2&&V&1&&$)if(K===0)$.persisted&&!S[Xo]?n(S,j,g):($.beforeEnter(S),n(S,j,g),St(()=>$.enter(S),B));else{const{leave:ee,delayLeave:oe,afterLeave:ne}=$,pe=()=>{P.ctx.isUnmounted?o(S):n(S,j,g)},_e=()=>{const xe=S._isLeaving||!!S[Xo];S._isLeaving&&S[Xo](!0),$.persisted&&!xe?pe():ee(S,()=>{pe(),ne&&ne()})};oe?oe(S,pe,_e):_e()}else n(S,j,g)},W=(P,j,g,K=!1,B=!1)=>{const{type:S,props:I,ref:$,children:U,dynamicChildren:V,shapeFlag:G,patchFlag:ee,dirs:oe,cacheIndex:ne,memo:pe}=P;if(ee===-2&&(B=!1),$!=null&&(si(),Cn($,null,g,P,!0),ri()),ne!=null&&(j.renderCache[ne]=void 0),G&256){j.ctx.deactivate(P);return}const _e=G&1&&oe,xe=!tn(P);let Me;if(xe&&(Me=I&&I.onVnodeBeforeUnmount)&&jt(Me,j,P),G&6)re(P.component,g,K);else{if(G&128){P.suspense.unmount(g,K);return}_e&&_i(P,null,j,"beforeUnmount"),G&64?P.type.remove(P,j,g,Y,K):V&&!V.hasOnce&&(S!==Ue||ee>0&&ee&64)?ue(V,j,g,!1,!0):(S===Ue&&ee&384||!B&&G&16)&&ue(U,j,g),K&&ie(P)}const Ve=pe!=null&&ne==null;(xe&&(Me=I&&I.onVnodeUnmounted)||_e||Ve)&&St(()=>{Me&&jt(Me,j,P),_e&&_i(P,null,j,"unmounted"),Ve&&(P.el=null)},g)},ie=P=>{const{type:j,el:g,anchor:K,transition:B}=P;if(j===Ue){se(g,K);return}if(j===no){A(P);return}const S=()=>{o(g),B&&!B.persisted&&B.afterLeave&&B.afterLeave()};if(P.shapeFlag&1&&B&&!B.persisted){const{leave:I,delayLeave:$}=B,U=()=>I(g,S);$?$(P.el,S,U):U()}else S()},se=(P,j)=>{let g;for(;P!==j;)g=v(P),o(P),P=g;o(j)},re=(P,j,g)=>{const{bum:K,scope:B,job:S,subTree:I,um:$,m:U,a:V}=P;Cr(U),Cr(V),K&&io(K),B.stop(),S&&(S.flags|=8,W(I,P,j,g)),$&&St($,j),St(()=>{P.isUnmounted=!0},j)},ue=(P,j,g,K=!1,B=!1,S=0)=>{for(let I=S;I<P.length;I++)W(P[I],j,g,K,B)},Ie=P=>{if(P.shapeFlag&6)return Ie(P.component.subTree);if(P.shapeFlag&128)return P.suspense.next();const j=v(P.anchor||P.el),g=j&&j[zd];return g?v(g):j};let be=!1;const ae=(P,j,g)=>{let K;P==null?j._vnode&&(W(j._vnode,null,null,!0),K=j._vnode.component):f(j._vnode||null,P,j,null,null,null,g),j._vnode=P,be||(be=!0,hr(K),Rl(),be=!1)},Y={p:f,um:W,m:Z,r:ie,mt:y,mc:R,pc:O,pbc:F,n:Ie,o:e};return{render:ae,hydrate:void 0,createApp:au(ae)}}function es({type:e,props:t},i){return i==="svg"&&e==="foreignObject"||i==="mathml"&&e==="annotation-xml"&&t&&t.encoding&&t.encoding.includes("html")?void 0:i}function Ci({effect:e,job:t},i){i?(e.flags|=32,t.flags|=4):(e.flags&=-33,t.flags&=-5)}function _u(e,t){return(!e||e&&!e.pendingBranch)&&t&&!t.persisted}function ra(e,t,i=!1){const n=e.children,o=t.children;if($e(n)&&$e(o))for(let s=0;s<n.length;s++){const l=n[s];let r=o[s];r.shapeFlag&1&&!r.dynamicChildren&&((r.patchFlag<=0||r.patchFlag===32)&&(r=o[s]=ei(o[s]),r.el=l.el),!i&&r.patchFlag!==-2&&ra(l,r)),r.type===Fo&&(r.patchFlag===-1&&(r=o[s]=ei(r)),r.el=l.el),r.type===ai&&!r.el&&(r.el=l.el)}}function Cu(e){const t=e.slice(),i=[0];let n,o,s,l,r;const a=e.length;for(n=0;n<a;n++){const c=e[n];if(c!==0){if(o=i[i.length-1],e[o]<c){t[n]=o,i.push(n);continue}for(s=0,l=i.length-1;s<l;)r=s+l>>1,e[i[r]]<c?s=r+1:l=r;c<e[i[s]]&&(s>0&&(t[n]=i[s-1]),i[s]=n)}}for(s=i.length,l=i[s-1];s-- >0;)i[s]=l,l=t[l];return i}function la(e){const t=e.subTree.component;if(t)return t.asyncDep&&!t.asyncResolved?t:la(t)}function Cr(e){if(e)for(let t=0;t<e.length;t++)e[t].flags|=8}function aa(e){if(e.placeholder)return e.placeholder;const t=e.component;return t?aa(t.subTree):null}const ca=e=>e.__isSuspense;function $u(e,t){t&&t.pendingBranch?$e(e)?t.effects.push(...e):t.effects.push(e):Ld(e)}const Ue=Symbol.for("v-fgt"),Fo=Symbol.for("v-txt"),ai=Symbol.for("v-cmt"),no=Symbol.for("v-stc"),ni=[];let It=null;function Q(e=!1){ni.push(It=e?null:[])}function qs(){ni.pop(),It=ni[ni.length-1]||null}let Nn=1;function $r(e,t=!1){Nn+=e,e<0&&It&&t&&(It.hasOnce=!0)}function da(e){return e.dynamicChildren=Nn>0?It||Xi:null,qs(),Nn>0&&It&&It.push(e),e}function te(e,t,i,n,o,s){return da(p(e,t,i,n,o,s,!0))}function Ot(e,t,i,n,o){return da(le(e,t,i,n,o,!0))}function Zs(e){return e?e.__v_isVNode===!0:!1}function vn(e,t){return e.type===t.type&&e.key===t.key}const ua=({key:e})=>e??null,oo=({ref:e,ref_key:t,ref_for:i})=>(typeof e=="number"&&(e=""+e),e!=null?it(e)||Ye(e)||Ee(e)?{i:ct,r:e,k:t,f:!!i}:e:null);function p(e,t=null,i=null,n=0,o=null,s=e===Ue?0:1,l=!1,r=!1){const a={__v_isVNode:!0,__v_skip:!0,type:e,props:t,key:t&&ua(t),ref:t&&oo(t),scopeId:zl,slotScopeIds:null,children:i,component:null,suspense:null,ssContent:null,ssFallback:null,dirs:null,transition:null,el:null,anchor:null,target:null,targetStart:null,targetAnchor:null,staticCount:0,shapeFlag:s,patchFlag:n,dynamicProps:o,dynamicChildren:null,appContext:null,ctx:ct};return r?(So(a,i),s&128&&e.normalize(a)):i&&(a.shapeFlag|=it(i)?8:16),Nn>0&&!l&&It&&(a.patchFlag>0||s&6)&&a.patchFlag!==32&&It.push(a),a}const le=Iu;function Iu(e,t=null,i=null,n=0,o=null,s=!1){if((!e||e===Qd)&&(e=ai),Zs(e)){const r=rn(e,t,!0);return i&&So(r,i),Nn>0&&!s&&It&&(r.shapeFlag&6?It[It.indexOf(e)]=r:It.push(r)),r.patchFlag=-2,r}if(zu(e)&&(e=e.__vccOpts),t){t=Tu(t);let{class:r,style:a}=t;r&&!it(r)&&(t.class=Se(r)),He(a)&&(js(a)&&!$e(a)&&(a=dt({},a)),t.style=Gt(a))}const l=it(e)?1:ca(e)?128:Fd(e)?64:He(e)?4:Ee(e)?2:0;return p(e,t,i,n,o,l,s,!0)}function Tu(e){return e?js(e)||ea(e)?dt({},e):e:null}function rn(e,t,i=!1,n=!1){const{props:o,ref:s,patchFlag:l,children:r,transition:a}=e,c=t?Eu(o||{},t):o,d={__v_isVNode:!0,__v_skip:!0,type:e.type,props:c,key:c&&ua(c),ref:t&&t.ref?i&&s?$e(s)?s.concat(oo(t)):[s,oo(t)]:oo(t):s,scopeId:e.scopeId,slotScopeIds:e.slotScopeIds,children:r,target:e.target,targetStart:e.targetStart,targetAnchor:e.targetAnchor,staticCount:e.staticCount,shapeFlag:e.shapeFlag,patchFlag:t&&e.type!==Ue?l===-1?16:l|16:l,dynamicProps:e.dynamicProps,dynamicChildren:e.dynamicChildren,appContext:e.appContext,dirs:e.dirs,transition:a,component:e.component,suspense:e.suspense,ssContent:e.ssContent&&rn(e.ssContent),ssFallback:e.ssFallback&&rn(e.ssFallback),placeholder:e.placeholder,el:e.el,anchor:e.anchor,ctx:e.ctx,ce:e.ce};return a&&n&&Us(d,a.clone(d)),d}function $t(e=" ",t=0){return le(Fo,null,e,t)}function gt(e,t){const i=le(no,null,e);return i.staticCount=t,i}function Oe(e="",t=!1){return t?(Q(),Ot(ai,null,e)):le(ai,null,e)}function Vt(e){return e==null||typeof e=="boolean"?le(ai):$e(e)?le(Ue,null,e.slice()):Zs(e)?ei(e):le(Fo,null,String(e))}function ei(e){return e.el===null&&e.patchFlag!==-1||e.memo?e:rn(e)}function So(e,t){let i=0;const{shapeFlag:n}=e;if(t==null)t=null;else if($e(t))i=16;else if(typeof t=="object")if(n&65){const o=t.default;o&&(o._c&&(o._d=!1),So(e,o()),o._c&&(o._d=!0));return}else{i=32;const o=t._;!o&&!ea(t)?t._ctx=ct:o===3&&ct&&(ct.slots._===1?t._=1:(t._=2,e.patchFlag|=1024))}else if(Ee(t)){if(n&65){So(e,{default:t});return}t={default:t,_ctx:ct},i=32}else t=String(t),n&64?(i=16,t=[$t(t)]):i=8;e.children=t,e.shapeFlag|=i}function Eu(...e){const t={};for(let i=0;i<e.length;i++){const n=e[i];for(const o in n)if(o==="class")t.class!==n.class&&(t.class=Se([t.class,n.class]));else if(o==="style")t.style=Gt([t.style,n.style]);else if(To(o)){const s=t[o],l=n[o];l&&s!==l&&!($e(s)&&s.includes(l))?t[o]=s?[].concat(s,l):l:l==null&&s==null&&!Eo(o)&&(t[o]=l)}else o!==""&&(t[o]=n[o])}return t}function jt(e,t,i,n=null){Ft(e,t,7,[i,n])}const Au=Zl();let Bu=0;function Mu(e,t,i){const n=e.type,o=(t?t.appContext:e.appContext)||Au,s={uid:Bu++,vnode:e,type:n,parent:t,appContext:o,root:null,next:null,subTree:null,effect:null,update:null,job:null,scope:new od(!0),render:null,proxy:null,exposed:null,exposeProxy:null,withProxy:null,provides:t?t.provides:Object.create(o.provides),ids:t?t.ids:["",0,0],accessCache:null,renderCache:[],components:null,directives:null,propsOptions:ia(n,o),emitsOptions:Yl(n,o),emit:null,emitted:null,propsDefaults:We,inheritAttrs:n.inheritAttrs,ctx:We,data:We,props:We,attrs:We,slots:We,refs:We,setupState:We,setupContext:null,suspense:i,suspenseId:i?i.pendingId:0,asyncDep:null,asyncResolved:!1,isMounted:!1,isUnmounted:!1,isDeactivated:!1,bc:null,c:null,bm:null,m:null,bu:null,u:null,um:null,bum:null,da:null,a:null,rtg:null,rtc:null,ec:null,sp:null};return s.ctx={_:s},s.root=t?t.root:s,s.emit=du.bind(null,s),e.ce&&e.ce(s),s}let ht=null;const Du=()=>ht||ct;let _o,xs;{const e=Do(),t=(i,n)=>{let o;return(o=e[i])||(o=e[i]=[]),o.push(n),s=>{o.length>1?o.forEach(l=>l(s)):o[0](s)}};_o=t("__VUE_INSTANCE_SETTERS__",i=>ht=i),xs=t("__VUE_SSR_SETTERS__",i=>zn=i)}const Un=e=>{const t=ht;return _o(e),e.scope.on(),()=>{e.scope.off(),_o(t)}},Ir=()=>{ht&&ht.scope.off(),_o(null)};function fa(e){return e.vnode.shapeFlag&4}let zn=!1;function Lu(e,t=!1,i=!1){t&&xs(t);const{props:n,children:o}=e.vnode,s=fa(e);gu(e,n,s,t),ku(e,o,i||t);const l=s?Ou(e,t):void 0;return t&&xs(!1),l}function Ou(e,t){const i=e.type;e.accessCache=Object.create(null),e.proxy=new Proxy(e.ctx,tu);const{setup:n}=i;if(n){si();const o=e.setupContext=n.length>1?Ru(e):null,s=Un(e),l=Wn(n,e,0,[e.props,o]),r=pl(l);if(ri(),s(),(r||e.sp)&&!tn(e)&&Wl(e),r){if(l.then(Ir,Ir),t)return l.then(a=>{Tr(e,a)}).catch(a=>{Po(a,e,0)});e.asyncDep=l}else Tr(e,l)}else pa(e)}function Tr(e,t,i){Ee(t)?e.type.__ssrInlineRender?e.ssrRender=t:e.render=t:He(t)&&(e.setupState=Ll(t)),pa(e)}function pa(e,t,i){const n=e.type;e.render||(e.render=n.render||Zt);{const o=Un(e);si();try{iu(e)}finally{ri(),o()}}}const Pu={get(e,t){return pt(e,"get",""),e[t]}};function Ru(e){const t=i=>{e.exposed=i||{}};return{attrs:new Proxy(e.attrs,Pu),slots:e.slots,emit:e.emit,expose:t}}function Ho(e){return e.exposed?e.exposeProxy||(e.exposeProxy=new Proxy(Ll(_d(e.exposed)),{get(t,i){if(i in t)return t[i];if(i in $n)return $n[i](e)},has(t,i){return i in t||i in $n}})):e.proxy}function Nu(e,t=!0){return Ee(e)?e.displayName||e.name:e.name||t&&e.__name}function zu(e){return Ee(e)&&"__vccOpts"in e}const we=(e,t)=>Ed(e,t,zn),Fu="3.5.40";/**
* @vue/runtime-dom v3.5.40
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/let Ss;const Er=typeof window<"u"&&window.trustedTypes;if(Er)try{Ss=Er.createPolicy("vue",{createHTML:e=>e})}catch{}const ha=Ss?e=>Ss.createHTML(e):e=>e,Hu="http://www.w3.org/2000/svg",ju="http://www.w3.org/1998/Math/MathML",Qt=typeof document<"u"?document:null,Ar=Qt&&Qt.createElement("template"),Wu={insert:(e,t,i)=>{t.insertBefore(e,i||null)},remove:e=>{const t=e.parentNode;t&&t.removeChild(e)},createElement:(e,t,i,n)=>{const o=t==="svg"?Qt.createElementNS(Hu,e):t==="mathml"?Qt.createElementNS(ju,e):i?Qt.createElement(e,{is:i}):Qt.createElement(e);return e==="select"&&n&&n.multiple!=null&&o.setAttribute("multiple",n.multiple),o},createText:e=>Qt.createTextNode(e),createComment:e=>Qt.createComment(e),setText:(e,t)=>{e.nodeValue=t},setElementText:(e,t)=>{e.textContent=t},parentNode:e=>e.parentNode,nextSibling:e=>e.nextSibling,querySelector:e=>Qt.querySelector(e),setScopeId(e,t){e.setAttribute(t,"")},insertStaticContent(e,t,i,n,o,s){const l=i?i.previousSibling:t.lastChild;if(o&&(o===s||o.nextSibling))for(;t.insertBefore(o.cloneNode(!0),i),!(o===s||!(o=o.nextSibling)););else{Ar.innerHTML=ha(n==="svg"?`<svg>${e}</svg>`:n==="mathml"?`<math>${e}</math>`:e);const r=Ar.content;if(n==="svg"||n==="mathml"){const a=r.firstChild;for(;a.firstChild;)r.appendChild(a.firstChild);r.removeChild(a)}t.insertBefore(r,i)}return[l?l.nextSibling:t.firstChild,i?i.previousSibling:t.lastChild]}},Uu=Symbol("_vtc");function Vu(e,t,i){const n=e[Uu];n&&(t=(t?[t,...n]:[...n]).join(" ")),t==null?e.removeAttribute("class"):i?e.setAttribute("class",t):e.className=t}const Co=Symbol("_vod"),ma=Symbol("_vsh"),_s={name:"show",beforeMount(e,{value:t},{transition:i}){e[Co]=e.style.display==="none"?"":e.style.display,i&&t?i.beforeEnter(e):bn(e,t)},mounted(e,{value:t},{transition:i}){i&&t&&i.enter(e)},updated(e,{value:t,oldValue:i},{transition:n}){!t!=!i&&(n?t?(n.beforeEnter(e),bn(e,!0),n.enter(e)):n.leave(e,()=>{bn(e,!1)}):bn(e,t))},beforeUnmount(e,{value:t}){bn(e,t)}};function bn(e,t){e.style.display=t?e[Co]:"none",e[ma]=!t}const Ku=Symbol(""),Gu=/(?:^|;)\s*display\s*:/;function qu(e,t,i){const n=e.style,o=it(i);let s=!1;if(i&&!o){if(t)if(it(t))for(const l of t.split(";")){const r=l.slice(0,l.indexOf(":")).trim();i[r]==null&&kn(n,r,"")}else for(const l in t)i[l]==null&&kn(n,l,"");for(const l in i){l==="display"&&(s=!0);const r=i[l];r!=null?Yu(e,l,!it(t)&&t?t[l]:void 0,r)||kn(n,l,r):kn(n,l,"")}}else if(o){if(t!==i){const l=n[Ku];l&&(i+=";"+l),n.cssText=i,s=Gu.test(i)}}else t&&e.removeAttribute("style");Co in e&&(e[Co]=s?n.display:"",e[ma]&&(n.display="none"))}const Br=/\s*!important$/;function kn(e,t,i){if($e(i))i.forEach(n=>kn(e,t,n));else if(i==null&&(i=""),t.startsWith("--"))e.setProperty(t,i);else{const n=Zu(e,t);Br.test(i)?e.setProperty(xi(n),i.replace(Br,""),"important"):e[n]=i}}const Mr=["Webkit","Moz","ms"],ts={};function Zu(e,t){const i=ts[t];if(i)return i;let n=wt(t);if(n!=="filter"&&n in e)return ts[t]=n;n=Bo(n);for(let o=0;o<Mr.length;o++){const s=Mr[o]+n;if(s in e)return ts[t]=s}return t}function Yu(e,t,i,n){return e.tagName==="TEXTAREA"&&(t==="width"||t==="height")&&it(n)&&i===n}const Dr="http://www.w3.org/1999/xlink";function Lr(e,t,i,n,o,s=id(t)){n&&t.startsWith("xlink:")?i==null?e.removeAttributeNS(Dr,t.slice(6,t.length)):e.setAttributeNS(Dr,t,i):i==null||s&&!vl(i)?e.removeAttribute(t):e.setAttribute(t,s?"":Nt(i)?String(i):i)}function Or(e,t,i,n,o){if(t==="innerHTML"||t==="textContent"){i!=null&&(e[t]=t==="innerHTML"?ha(i):i);return}const s=e.tagName;if(t==="value"&&s!=="PROGRESS"&&!s.includes("-")){const r=s==="OPTION"?e.getAttribute("value")||"":e.value,a=i==null?e.type==="checkbox"?"on":"":String(i);(r!==a||!("_value"in e))&&(e.value=a),i==null&&e.removeAttribute(t),e._value=i;return}let l=!1;if(i===""||i==null){const r=typeof e[t];r==="boolean"?i=vl(i):i==null&&r==="string"?(i="",l=!0):r==="number"&&(i=0,l=!0)}try{e[t]=i}catch{}l&&e.removeAttribute(o||t)}function mi(e,t,i,n){e.addEventListener(t,i,n)}function Ju(e,t,i,n){e.removeEventListener(t,i,n)}const Pr=Symbol("_vei");function Xu(e,t,i,n,o=null){const s=e[Pr]||(e[Pr]={}),l=s[t];if(n&&l)l.value=n;else{const[r,a]=tf(t);if(n){const c=s[t]=sf(n,o);mi(e,r,c,a)}else l&&(Ju(e,r,l,a),s[t]=void 0)}}const Qu=/(Once|Passive|Capture)$/,ef=/^on:?(?:Once|Passive|Capture)$/;function tf(e){let t,i;for(;(i=e.match(Qu))&&!ef.test(e);)t||(t={}),e=e.slice(0,e.length-i[1].length),t[i[1].toLowerCase()]=!0;return[e[2]===":"?e.slice(3):xi(e.slice(2)),t]}let is=0;const nf=Promise.resolve(),of=()=>is||(nf.then(()=>is=0),is=Date.now());function sf(e,t){const i=n=>{if(!n._vts)n._vts=Date.now();else if(n._vts<=i.attached)return;const o=i.value;if($e(o)){const s=n.stopImmediatePropagation;n.stopImmediatePropagation=()=>{s.call(n),n._stopped=!0};const l=o.slice(),r=[n];for(let a=0;a<l.length&&!n._stopped;a++){const c=l[a];c&&Ft(c,t,5,r)}}else Ft(o,t,5,[n])};return i.value=e,i.attached=of(),i}const Rr=e=>e.charCodeAt(0)===111&&e.charCodeAt(1)===110&&e.charCodeAt(2)>96&&e.charCodeAt(2)<123,rf=(e,t,i,n,o,s)=>{const l=o==="svg";t==="class"?Vu(e,n,l):t==="style"?qu(e,i,n):To(t)?Eo(t)||Xu(e,t,i,n,s):(t[0]==="."?(t=t.slice(1),!0):t[0]==="^"?(t=t.slice(1),!1):lf(e,t,n,l))?(Or(e,t,n),!e.tagName.includes("-")&&(t==="value"||t==="checked"||t==="selected")&&Lr(e,t,n,l,s,t!=="value")):e._isVueCE&&(af(e,t)||e._def.__asyncLoader&&(/[A-Z]/.test(t)||!it(n)))?Or(e,wt(t),n,s,t):(t==="true-value"?e._trueValue=n:t==="false-value"&&(e._falseValue=n),Lr(e,t,n,l))};function lf(e,t,i,n){if(n)return!!(t==="innerHTML"||t==="textContent"||t in e&&Rr(t)&&Ee(i));if(t==="spellcheck"||t==="draggable"||t==="translate"||t==="autocorrect"||t==="sandbox"&&e.tagName==="IFRAME"||t==="form"||t==="list"&&e.tagName==="INPUT"||t==="type"&&e.tagName==="TEXTAREA")return!1;if(t==="width"||t==="height"){const o=e.tagName;if(o==="IMG"||o==="VIDEO"||o==="CANVAS"||o==="SOURCE")return!1}return Rr(t)&&it(i)?!1:t in e}function af(e,t){const i=e._def.props;if(!i)return!1;const n=wt(t);return Array.isArray(i)?i.some(o=>wt(o)===n):Object.keys(i).some(o=>wt(o)===n)}const ln=e=>{const t=e.props["onUpdate:modelValue"]||!1;return $e(t)?i=>io(t,i):t};function cf(e){e.target.composing=!0}function Nr(e){const t=e.target;t.composing&&(t.composing=!1,t.dispatchEvent(new Event("input")))}const oi=Symbol("_assign");function zr(e,t,i){return t&&(e=e.trim()),i&&(e=Mo(e)),e}const $o={created(e,{modifiers:{lazy:t,trim:i,number:n}},o){e[oi]=ln(o);const s=n||o.props&&o.props.type==="number";mi(e,t?"change":"input",l=>{l.target.composing||e[oi](zr(e.value,i,s))}),(i||s)&&mi(e,"change",()=>{e.value=zr(e.value,i,s)}),t||(mi(e,"compositionstart",cf),mi(e,"compositionend",Nr),mi(e,"change",Nr))},mounted(e,{value:t}){e.value=t??""},beforeUpdate(e,{value:t,oldValue:i,modifiers:{lazy:n,trim:o,number:s}},l){if(e[oi]=ln(l),e.composing)return;const r=(s||e.type==="number")&&!/^0\d/.test(e.value)?Mo(e.value):e.value,a=t??"";if(r===a)return;const c=e.getRootNode();(c instanceof Document||c instanceof ShadowRoot)&&c.activeElement===e&&e.type!=="range"&&(n&&t===i||o&&e.value.trim()===a)||(e.value=a)}},Xn={deep:!0,created(e,t,i){e[oi]=ln(i),mi(e,"change",()=>{const n=e._modelValue,o=Fn(e),s=e.checked,l=e[oi];if($e(n)){const r=Os(n,o),a=r!==-1;if(s&&!a)l(n.concat(o));else if(!s&&a){const c=[...n];c.splice(r,1),l(c)}}else if(cn(n)){const r=new Set(n);s?r.add(o):r.delete(o),l(r)}else l(ga(e,s))})},mounted:Fr,beforeUpdate(e,t,i){e[oi]=ln(i),Fr(e,t,i)}};function Fr(e,{value:t,oldValue:i},n){e._modelValue=t;let o;if($e(t))o=Os(t,n.props.value)>-1;else if(cn(t))o=t.has(n.props.value);else{if(t===i)return;o=dn(t,ga(e,!0))}e.checked!==o&&(e.checked=o)}const df={deep:!0,created(e,{value:t,modifiers:{number:i}},n){e._modelValue=t,mi(e,"change",()=>{const o=Array.prototype.filter.call(e.options,s=>s.selected).map(s=>i?Mo(Fn(s)):Fn(s));e[oi](e.multiple?cn(e._modelValue)?new Set(o):o:o[0]),e._assigning=!0,yo(()=>{e._assigning=!1})}),e[oi]=ln(n)},mounted(e,{value:t}){Hr(e,t)},beforeUpdate(e,{value:t},i){e._modelValue=t,e[oi]=ln(i)},updated(e,{value:t}){e._assigning||Hr(e,t)}};function Hr(e,t){const i=e.multiple,n=$e(t);if(!(i&&!n&&!cn(t))){for(let o=0,s=e.options.length;o<s;o++){const l=e.options[o],r=Fn(l);if(i)if(n){const a=typeof r;a==="string"||a==="number"?l.selected=t.some(c=>String(c)===String(r)):l.selected=Os(t,r)>-1}else l.selected=t.has(r);else if(dn(Fn(l),t)){e.selectedIndex!==o&&(e.selectedIndex=o);return}}!i&&e.selectedIndex!==-1&&(e.selectedIndex=-1)}}function Fn(e){return"_value"in e?e._value:e.value}function ga(e,t){const i=t?"_trueValue":"_falseValue";return i in e?e[i]:t}const uf=["ctrl","shift","alt","meta"],ff={stop:e=>e.stopPropagation(),prevent:e=>e.preventDefault(),self:e=>e.target!==e.currentTarget,ctrl:e=>!e.ctrlKey,shift:e=>!e.shiftKey,alt:e=>!e.altKey,meta:e=>!e.metaKey,left:e=>"button"in e&&e.button!==0,middle:e=>"button"in e&&e.button!==1,right:e=>"button"in e&&e.button!==2,exact:(e,t)=>uf.some(i=>e[`${i}Key`]&&!t.includes(i))},Lt=(e,t)=>{if(!e)return e;const i=e._withMods||(e._withMods={}),n=t.join(".");return i[n]||(i[n]=((o,...s)=>{for(let l=0;l<t.length;l++){const r=ff[t[l]];if(r&&r(o,t))return}return e(o,...s)}))},pf={esc:"escape",space:" ",up:"arrow-up",left:"arrow-left",right:"arrow-right",down:"arrow-down",delete:"backspace"},hf=(e,t)=>{const i=e._withKeys||(e._withKeys={}),n=t.join(".");return i[n]||(i[n]=(o=>{if(!("key"in o))return;const s=xi(o.key);if(t.some(l=>l===s||pf[l]===s))return e(o)}))},mf=dt({patchProp:rf},Wu);let jr;function gf(){return jr||(jr=xu(mf))}const Ys=((...e)=>{const t=gf().createApp(...e),{mount:i}=t;return t.mount=n=>{const o=bf(n);if(!o)return;const s=t._component;!Ee(s)&&!s.render&&!s.template&&(s.template=o.innerHTML),o.nodeType===1&&(o.textContent="");const l=i(o,!1,vf(o));return o instanceof Element&&(o.removeAttribute("v-cloak"),o.setAttribute("data-v-app","")),l},t});function vf(e){if(e instanceof SVGElement)return"svg";if(typeof MathMLElement=="function"&&e instanceof MathMLElement)return"mathml"}function bf(e){return it(e)?document.querySelector(e):e}const yf="slidev-config.json",an={enableWebServeJump:!1,webServeUrl:"http://127.0.0.1:6806",normalizeHeadingSizes:!1},gi=Oo({...an});function kf(e){if(!e||typeof e!="object")return{...an};const t=e;return{enableWebServeJump:!!t.enableWebServeJump,webServeUrl:typeof t.webServeUrl=="string"&&t.webServeUrl.trim()?t.webServeUrl.trim():an.webServeUrl,normalizeHeadingSizes:!!t.normalizeHeadingSizes}}function Di(e){if(!e||typeof e!="object")return{...gi};const t=e;return t.enableWebServeJump!==void 0&&(gi.enableWebServeJump=!!t.enableWebServeJump),t.webServeUrl!==void 0&&(gi.webServeUrl=String(t.webServeUrl)),t.normalizeHeadingSizes!==void 0&&(gi.normalizeHeadingSizes=!!t.normalizeHeadingSizes),{...gi}}function jo(){return{...gi}}function va(e,t,i){const n=(e||an.webServeUrl).trim(),o=n.startsWith("http://")||n.startsWith("https://")?n:`http://${n}`,s=(i==null?void 0:i.r)||Math.random().toString(36).slice(2,9).padEnd(7,"0");try{const l=new URL(o);let r=l.pathname.replace(/\/+$/,"");return r.endsWith("/stage/build/desktop")||(r=r?`${r}/stage/build/desktop`:"/stage/build/desktop"),l.pathname=`${r}/`,l.searchParams.set("id",t),i!=null&&i.focus&&l.searchParams.set("focus","1"),l.searchParams.set("r",s),l.toString()}catch{const l=i!=null&&i.focus?"&focus=1":"";return`${o.replace(/\/+$/,"")}/stage/build/desktop/?id=${t}${l}&r=${s}`}}const $i={theme:"default",aspectRatio:"16/9",highlighter:"shiki",defaultTransition:"slide-left",colorSchema:"auto",spacing:"normal",normalizeHeadingSizes:!1};function wf(e){var i,n,o,s,l,r;const t=jo();return e?{theme:((i=e[An])==null?void 0:i.trim())||$i.theme,aspectRatio:((n=e[Bn])==null?void 0:n.trim())||$i.aspectRatio,highlighter:((o=e[ll])==null?void 0:o.trim())||$i.highlighter,defaultTransition:((s=e[Mn])==null?void 0:s.trim())||$i.defaultTransition,colorSchema:((l=e[al])==null?void 0:l.trim())||$i.colorSchema,spacing:((r=e[fs])==null?void 0:r.trim())||$i.spacing,normalizeHeadingSizes:t.normalizeHeadingSizes}:{...$i,normalizeHeadingSizes:t.normalizeHeadingSizes}}function Io(e){var i,n,o,s,l;const t=(i=e.ial)==null?void 0:i[Ai];return!!(t&&(t==="true"||t==="page"||t==="cover"||t==="end")||e.type==="tb"||e.type==="thematic-break"||e.type==="NodeThematicBreak"||((n=e.markdown)==null?void 0:n.trim())==="---"||((o=e.markdown)==null?void 0:o.trim())==="***"||e.type==="b"&&(((s=e.markdown)==null?void 0:s.trim())==="---"||((l=e.content)==null?void 0:l.trim())==="---"))}function Wr(e){const t={};let i="";if(!e)return{frontmatter:t,notes:i};e[he]&&(t.layout=e[he].trim()),e[tt]&&(t.transition=e[tt].trim()),e[je]&&(t.background=e[je].trim()),e[Dt]&&(t.image=e[Dt].trim()),e[Gi]&&(t.class=e[Gi].trim()),e[wn]&&(t.spacing=e[wn].trim()),e[yt]&&(t.layoutRatio=e[yt].trim()),e[qi]&&(t.mask=e[qi].trim()),e[Zi]&&(t.maskRatio=e[Zi].trim()),e[Yi]&&(t.maskStyle=e[Yi].trim()),e[Ji]&&(t.maskInitial=e[Ji].trim()),e[Ki]&&(i=e[Ki].trim());for(const[n,o]of Object.entries(e))if(n.startsWith("custom-slidev-")&&![he,yt,qi,Zi,Yi,Ji,tt,je,Dt,Gi,wn,Ki,Ai].includes(n)){const s=n.replace(/^custom-slidev-/,"");try{t[s]=JSON.parse(o)}catch{t[s]=o}}return{frontmatter:t,notes:i}}function xf(e){const t={};if(!e)return t;const i=e[nt]??e["slidev-note"];i!=null&&i!==""&&i!=="false"&&i!=="0"&&(t.isNote=!0);const n=e[Ge]??e["slidev-role"],o=e[je]??e["slidev-background"];(n===cl||o==="true"||o==="1")&&(t.isBackground=!0);const s=e[he]??e["slidev-layout"];s===mo||s===go?t.imageLayout=s:(n===mo||n===go)&&(t.imageLayout=n);const l=e[Ze]??e["custom-slidev-clicks"]??e["slidev-click"]??e["slidev-clicks"];if(l!=null&&(t.clicks=l.trim()),e[qt])try{const r=JSON.parse(e[qt]);typeof r=="object"&&r!==null?t.motion={preset:r.preset||r.type||"fade-in",...r}:t.motion={preset:String(r).trim()}}catch{t.motion={preset:e[qt].trim()}}return e[Ni]&&(t.shikiLines=e[Ni].trim()),e[Dn]&&(t.maxHeight=e[Dn].trim()),e[Ce]&&(t.slot=e[Ce].trim()),e.style&&e.style.trim()&&(t.style=e.style.trim()),t}function wi(e,t){const i=(e||t||"").trim();if(!i)return null;const n=i.match(/!\[[\s\S]*?\]\(\s*([^\s)]+)(?:\s+(?:=["']?[^"'\s)]*["']?|["'][^"']*["']))*?\s*\)/);if(n)return n[1].trim();const o=i.match(/<img\b[^>]*?\bsrc=["']([^"']+)["']/i);if(o)return o[1].trim();const s=i.replace(/\{:[^}]*\}/g,"").trim();return/^(?:assets\/|https?:\/\/|\/|\.\.?\/)[^\s]+\.(?:png|jpe?g|gif|webp|svg|avif)(?:\?[^\s]*)?$/i.test(s)?s:null}function In(e){if(!e)return"";const t=e.split(/\r?\n/);if(t.length===0)return"";const i=t[0],n=i.match(/^(\s*)(?:[-*+]|\d+\.)\s+(.*)$/);if(!n)return e;const o=n[1].length,s=n[2].trim(),l=i.length-n[2].length;if(t.length===1)return s;const r=[s];for(let a=1;a<t.length;a++){const c=t[a];if(!c.trim()){r.push("");continue}const d=c.match(/^(\s*)/),h=d?d[1].length:0;h>=l?r.push(c.slice(l)):h>o?r.push(c.slice(h)):r.push(c)}return r.join(`
`)}function zi(e){if(!e)return!1;const t=(e.type||"").toLowerCase();if(t==="i"||t==="nodelistitem"||t==="l"||t==="nodelist")return!0;const i=(e.markdown||e.rawMarkdown||e.content||"").trim();return!!/^(?:[-*+]|\d+\.)\s+/.test(i)}function ns(e,t=2){if(!e||typeof e!="string")return`repeat(${t}, 1fr)`;const i=e.trim();if(!i)return`repeat(${t}, 1fr)`;if(i.includes(":")){const o=i.split(":").map(s=>parseFloat(s.trim())).filter(s=>!isNaN(s)&&s>0);if(o.length>=2)return o.map(s=>`${s}fr`).join(" ")}const n=i.split(/\s+/).filter(Boolean);return n.length>=2?n.join(" "):`repeat(${t}, 1fr)`}function Tn(e){if(!e)return[];if(st(e)&&Yt(e)&&!di(e)){const n=fn(e),o=[];for(const s of n)o.push(...Tn(s));return o}const t=(e.type||"").toLowerCase();if(t==="l"||t==="nodelist"||t==="list"){if(e.children&&e.children.length>0){const l=e.children.filter(zi);if(l.length>0)return l}const o=(e.markdown||e.content||"").trim().split(/\r?\n/),s=[];for(let l=0;l<o.length;l++)/^(?:[-*+]|\d+\.)\s+/.test(o[l])&&s.push(l);if(s.length>=2){const l=[];for(let r=0;r<s.length;r++){const a=s[r],c=r+1<s.length?s[r+1]:o.length,d=o.slice(a,c).join(`
`);l.push({id:`${e.id}-item-${r+1}`,type:"i",markdown:d,content:d,ial:{...e.ial||{}}})}return l}}return zi(e)?[e]:[]}function Js(e){var o;if(!e||!st(e)||!Yt(e)||di(e))return null;const t=fn(e);if(t.length===0)return null;if(t.length===1&&st(t[0])&&Yt(t[0])){const s=Js(t[0]);return s?{items:s.items,nestedSuperBlocks:[t[0],...s.nestedSuperBlocks]}:null}const i=[];for(const s of t)if(st(s)){i.push(s);const l=((o=s.children)==null?void 0:o.filter(st))||[];i.push(...l)}const n=t.map(Tn);if(n.length>=2&&n.every(s=>s.length>0)){const s=n.flat();if(s.length>=2&&s.length<=6)return{items:s,nestedSuperBlocks:i}}if(t.length===2){const s=Tn(t[0]),l=Tn(t[1]);if(s.length+l.length>=2&&s.length+l.length<=6&&(s.length>0||l.length>0))return{items:[...s,...l],nestedSuperBlocks:i}}return null}function Sf(e){if(!e||!st(e)||!Yt(e)||di(e))return null;const t=Js(e);if(!t)return null;const{items:i,nestedSuperBlocks:n}=t;if(i.length<2||i.length>6)return null;const o=Xs(e)||void 0,s=i.length;return{superBlockNode:e,nestedSuperBlocks:n,count:s,layout:"cols-header",items:i,slots:i.map((l,r)=>`col-${r+1}`),ratio:o}}function ba(e){if(!e||!st(e)||!Yt(e)||di(e))return null;const t=fn(e);if(t.length===0)return null;const i=[];for(const n of t){const o=Tn(n);if(o.length===0)return null;i.push(...o)}return i}function _f(e){if(!e||!st(e)||!Yt(e)||di(e))return null;const t=ba(e);return!t||t.length===0||t.length>=2&&t.length<=6?null:{superBlockNode:e,items:t}}function Cf(e){if(!e||!st(e)||!Yt(e)||di(e))return null;const t=Js(e);if(t&&t.items.length===4)return t.items;const i=ba(e);if(i&&i.length===4)return i;const n=fn(e);return n.length===4?n:null}function $f(e,t){if(!e||e.length===0)return null;const i=[];function n(r,a){if(st(r)){const c=Cf(r);c&&c.length===4&&i.push({sbNode:r,items:c,topLevelIndex:a})}if(r.children&&r.children.length>0)for(const c of r.children)n(c,a)}for(let r=0;r<e.length;r++)n(e[r],r);if(i.length===0)return null;let o=null;t&&(o=i.find(r=>{if(r.sbNode.id===t||r.items.some(c=>c.id===t))return!0;const a=c=>c.id===t?!0:c.children?c.children.some(a):!1;return a(r.sbNode)})||null),o||(o=i[0]);const l=e.slice(0,o.topLevelIndex).slice().reverse().find(r=>ya(r));return{superBlockNode:o.sbNode,items:o.items,headerNode:l}}function If(e,t,i){var d,h,v,u,m;const n=[],o=[],s=(i==null?void 0:i.tracked)||[],l=[];let r={pageTargetId:e,blocks:[]};l.push(r);for(let f=0;f<t.length;f++){const b=t[f];if(Io(b)){if(l.length===1&&r.blocks.length===0){r.pageTargetId=b.id,r.blocks.push(b);continue}r={pageTargetId:b.id,blocks:[b]},l.push(r)}else r.blocks.push(b)}function a(f){const b=[];for(const k of f)st(k)&&b.push(k),k.children&&k.children.length>0&&b.push(...a(k.children));return b}function c(f,b,k){const x={blockId:f,attrs:b,previousAttrs:k};n.push(x),i!=null&&i.onTagChange&&i.onTagChange(x)}for(const f of l){const b=f.pageTargetId,k=t.find(T=>T.id===b),x=s.find(T=>T.pageTargetId===b);if(f.blocks.some(T=>{var w,R;return!!(di(T)||Cs(T)&&(((w=T.ial)==null?void 0:w[he])==="image-left"||((R=T.ial)==null?void 0:R[he])==="image-right"))})){if(x){const T=x.headerId;if(T){c(T,{[Ce]:""});const w=t.find(R=>R.id===T);w!=null&&w.ial&&(w.ial[Ce]="")}for(const w of x.itemIds){c(w,{[Ce]:""});const R=t.find(N=>N.id===w);R!=null&&R.ial&&(R.ial[Ce]="")}}continue}let A=null,D=-1;for(let T=0;T<f.blocks.length;T++){const w=f.blocks[T],R=st(w)?[w,...a(w.children||[])]:w.children?a(w.children):[];for(const N of R){const F=Sf(N);if(F){A=F,D=T;break}}if(A)break}if(A){const{superBlockNode:T,layout:w,items:R,slots:N}=A,q=f.blocks.slice(0,D).find(E=>ya(E)),_=q==null?void 0:q.id,L=((d=k==null?void 0:k.ial)==null?void 0:d[he])||"",y=L==="clover",M=y?"clover":w;if(L!==M&&(c(b,{[he]:M},{[he]:L}),k&&(k.ial||(k.ial={}),k.ial[he]=M)),q){const E=((h=q.ial)==null?void 0:h[Ce])||"";E!=="header"&&(c(q.id,{[Ce]:"header"},{[Ce]:E}),q.ial||(q.ial={}),q.ial[Ce]="header")}if(x!=null&&x.headerId&&x.headerId!==_){c(x.headerId,{[Ce]:""});const E=t.find(O=>O.id===x.headerId);E&&(E.ial||(E.ial={}),E.ial[Ce]="")}const H=[];for(let E=0;E<R.length;E++){const O=R[E],z=N[E];H.push(O.id);const X=((v=O.ial)==null?void 0:v[Ce])||"";if(X!==z&&(c(O.id,{[Ce]:z},{[Ce]:X}),O.ial||(O.ial={}),O.ial[Ce]=z),O.children&&O.children.length>0)for(const Z of O.children)Z.ial||(Z.ial={}),Z.ial[Ce]!==z&&(Z.ial[Ce]=z)}if(x!=null&&x.itemIds){for(const E of x.itemIds)if(!H.includes(E)){c(E,{[Ce]:""});const O=t.find(z=>z.id===E);O&&(O.ial||(O.ial={}),O.ial[Ce]="")}}o.push({superBlockId:T.id,nestedSuperBlockIds:(u=A.nestedSuperBlocks)==null?void 0:u.map(E=>E.id),pageTargetId:b,headerId:_,itemIds:H,layout:y?"clover":w})}else{let T=!1;const w=[];for(const F of f.blocks){const q=st(F)?[F,...a(F.children||[])]:F.children?a(F.children):[];for(const _ of q){const L=_f(_);if(L){T=!0;for(const y of L.items)w.push(y.id)}}}const R=((m=k==null?void 0:k.ial)==null?void 0:m[he])||"",N=Ln(R);if(x||T&&N){c(b,{[he]:""},{[he]:R}),k&&(k.ial||(k.ial={}),k.ial[he]="");const F=x==null?void 0:x.headerId;if(F){c(F,{[Ce]:""});const _=t.find(L=>L.id===F);_&&(_.ial||(_.ial={}),_.ial[Ce]="")}const q=new Set([...(x==null?void 0:x.itemIds)||[],...w]);for(const _ of q){c(_,{[Ce]:""});const L=t.find(y=>y.id===_);L&&(L.ial||(L.ial={}),L.ial[Ce]="")}}}}return{changes:n,newTracked:o}}function st(e){if(!e)return!1;const t=(e.type||"").toLowerCase();return t==="s"||t==="sb"||t==="nodesuperblock"}function Yt(e){if(!st(e))return!1;const t=(e.subType||"").toLowerCase();if(t==="col"||t==="h"||t==="horizontal")return!0;if(t==="row"||t==="v"||t==="vertical")return!1;if(e.ial){const n=(e.ial["data-sb-layout"]||e.ial.layout||"").toLowerCase();if(n==="col"||n==="h")return!0;if(n==="row"||n==="v")return!1}if(e.children&&e.children.length>0){for(const n of e.children)if(n.type==="NodeSuperBlockLayoutMarker"||n.type==="layout-marker"){const o=(n.content||n.markdown||"").trim().toLowerCase();if(o==="col"||o==="h")return!0;if(o==="row"||o==="v")return!1}}const i=(e.markdown||e.content||"").trim();return/^\{\{\{col\b/i.test(i)?!0:!/^\{\{\{row\b/i.test(i)}function Cs(e){return!e||zi(e)||st(e)||!wi(e.markdown,e.content)?!1:(e.markdown||e.content||"").replace(/!\[.*?\]\([^)]+\)/g,"").replace(/<img\b[^>]*>/gi,"").replace(/\{:[^}]*\}/g,"").trim().length<=25}function Xs(e){var v;if(!e||!st(e)||!Yt(e))return null;const t=fn(e);if(!t||t.length<2)return null;const i=[];let n=!1;for(const u of t){const m=(((v=u.ial)==null?void 0:v.style)||u.style||"").trim();let f=null;if(m){const b=m.match(/calc\(\s*([\d.]+)%/i);if(b)f=parseFloat(b[1]);else{const k=m.match(/(?:^|;|\s)width:\s*([\d.]+)%/i);k&&(f=parseFloat(k[1]))}}f!==null&&!isNaN(f)&&f>0?(i.push(f),n=!0):i.push(null)}if(!n)return null;const o=t.length,s=i.reduce((u,m)=>u+(m||0),0),l=i.filter(u=>u===null).length,r=Math.max(0,100-s),a=l>0?r/l:100/o,c=i.map(u=>u!==null?u:a),d=c.reduce((u,m)=>u+m,0);if(d<=0)return null;const h=c.map(u=>u/d*100);if(h.length===2){const[u]=h;if(u>=48&&u<=52)return"1:1";if(u>=31&&u<=35)return"1:2";if(u>=65&&u<=69)return"2:1";if(u>=28&&u<=32)return"3:7";if(u>=68&&u<=72)return"7:3";if(u>=38&&u<=42)return"4:6";if(u>=58&&u<=62)return"6:4";if(u>=23&&u<=27)return"1:3";if(u>=73&&u<=77)return"3:1";const m=Math.round(u),f=100-m;return`${m}:${f}`}if(h.length===3){const[u,m,f]=h;if(u>=31&&u<=35&&m>=31&&m<=35&&f>=31&&f<=35)return"1:1:1";if(u>=23&&u<=27&&m>=48&&m<=52&&f>=23&&f<=27)return"1:2:1";if(u>=48&&u<=52&&m>=23&&m<=27&&f>=23&&f<=27)return"2:1:1";if(u>=23&&u<=27&&m>=23&&m<=27&&f>=48&&f<=52)return"1:1:2";if(u>=18&&u<=22&&m>=58&&m<=62&&f>=18&&f<=22)return"1:3:1";const b=Math.round(u),k=Math.round(m),x=100-b-k;return`${b}:${k}:${x}`}return h.map(u=>Math.round(u)).join(":")}function di(e){if(!e||!st(e)||!Yt(e))return null;const t=(e.children||[]).filter(s=>{const l=s.type||"";if(l==="NodeSuperBlockOpenMarker"||l==="NodeSuperBlockLayoutMarker"||l==="NodeSuperBlockCloseMarker"||l==="open-marker"||l==="layout-marker"||l==="close-marker")return!1;const r=(s.markdown||s.content||"").trim();return!(/^\{\{\{(?:col|row)?\s*$/i.test(r)||r==="}}}")});if(t.length<2)return null;const i=Cs(t[0]),n=Cs(t[t.length-1]),o=Xs(e)||void 0;if(i&&!n){const s=wi(t[0].markdown,t[0].content);if(s)return{imageNode:t[0],imageUrl:s,layout:mo,contentNodes:t.slice(1),ratio:o}}if(!i&&n){const s=wi(t[t.length-1].markdown,t[t.length-1].content);if(s)return{imageNode:t[t.length-1],imageUrl:s,layout:go,contentNodes:t.slice(0,t.length-1),ratio:o}}return null}function Tf(e,t){const i=[];function n(o){for(const s of o){const l=di(s);if(l){const{imageNode:r,layout:a,ratio:c}=l;r.ial||(r.ial={});const d=r.ial[he];if(d!==a){const v={blockId:r.id,layout:a,previousLayout:d,ratio:c};r.ial[he]=a,i.push(v),t&&t(v)}}s.children&&s.children.length>0&&n(s.children)}}return n(e),i}function fn(e){return(e.children||[]).filter(t=>{const i=t.type||"";if(i==="NodeSuperBlockOpenMarker"||i==="NodeSuperBlockLayoutMarker"||i==="NodeSuperBlockCloseMarker"||i==="open-marker"||i==="layout-marker"||i==="close-marker")return!1;const n=(t.markdown||t.content||"").trim();return!(/^\{\{\{(?:col|row)?\s*$/i.test(n)||n==="}}}")})}function ya(e){if(!e)return!1;const t=(e.type||"").toLowerCase();if(t==="h"||t==="nodeheading"||/^h[1-6]$/i.test(e.subType||""))return!0;const i=(e.markdown||e.content||"").trim();return!!/^#{1,6}\s+/.test(i)}function Ii(e,t,i){let n="",o=0;const s=/<div\b([^>]*)>/gi;for(;o<e.length;){s.lastIndex=o;let l,r=!1,a=-1,c=0;for(;(l=s.exec(e))!==null;){const k=l[1].match(/\bclass=["']([^"']*)["']/i);if(k){const x=k[1];if(typeof t=="string"?x.split(/\s+/).includes(t):t.test(x)){r=!0,a=l.index,c=l[0].length;break}}}if(!r){n+=e.slice(o);break}n+=e.slice(o,a);const d=a+c;let h=1,v=-1,u=-1;const m=/<\/?div\b[^>]*>/gi;m.lastIndex=d;let f;for(;(f=m.exec(e))!==null;)if(f[0].startsWith("</")){if(h--,h===0){v=f.index,u=f.index+f[0].length;break}}else h++;if(v!==-1&&u!==-1){const b=e.slice(d,v);n+=i(b),o=u}else n+=e.slice(a,d),o=d}return n}function Ef(e){const t=[];let i="",n=0;const o=/<div\b([^>]*)>/gi;for(;n<e.length;){o.lastIndex=n;let s,l=!1,r=-1,a=0;for(;(s=o.exec(e))!==null;){const f=s[1];if(/(?:\s@[a-zA-Z0-9_-]+=\s*["']|\s:[a-zA-Z0-9_-]+=\s*["']|\sv-[a-zA-Z0-9_.-]+|\shover:[a-zA-Z0-9_.-]+=\s*["']|\sgrid=["']~|\bclass=["'][^"']*\b(?:abs-br|slidev-icon-btn|grid\s+|grid$|grid-cols-|relative\b)\b[^"']*["']|\bstyle=["'][^"']*\bgrid-[^"']*["'])/i.test(f)){l=!0,r=s.index,a=s[0].length;break}}if(!l){i+=e.slice(n);break}i+=e.slice(n,r);const c=r+a;let d=1,h=-1,v=-1;const u=/<\/?div\b[^>]*>/gi;u.lastIndex=c;let m;for(;(m=u.exec(e))!==null;)if(m[0].startsWith("</")){if(d--,d===0){h=m.index,v=m.index+m[0].length;break}}else d++;if(h!==-1&&v!==-1){const f=e.slice(r,v),b=`__VUE_DIV_TOKEN_${t.length}__`;t.push(f),i+=b,n=v}else i+=e.slice(r,c),n=c}return{text:i,tokens:t}}function Af(e){const t=[];let i=e.replace(/(?:^[ \t]*(`{3,}|~{3,})[^\n\r]*\r?\n[\s\S]*?\r?\n[ \t]*\1(?=[ \t]*(?:\r?\n|$)))/gm,r=>{const a=`__CODE_TOKEN_${t.length}__`;return t.push(r),a});i=i.replace(/(`+)(?:[^\n\r`]|(?!\1)`)+?\1/g,r=>{const a=`__CODE_TOKEN_${t.length}__`;return t.push(r),a});const n=[];i=i.replace(/<script\b[^>]*>[\s\S]*?<\/script>/gi,r=>{const a=`__SCRIPT_TOKEN_${n.length}__`;return n.push(r),a});const{text:o,tokens:s}=Ef(i);i=o;const l=[];i=i.replace(/<(?:[A-Z][a-zA-Z0-9_-]*|[a-z0-9_-]+:[a-z0-9_-]+|v-[a-z0-9_-]+|arrow\b|div\s+h-\d+)\b[^>]*\/>/gi,r=>{const a=`__VUE_COMP_TOKEN_${l.length}__`;return l.push(r),a}),i=i.replace(/<(v-[a-z0-9_-]+|button)\b([^>]*)>([\s\S]*?)<\/\1>/gi,r=>{const a=`__VUE_COMP_TOKEN_${l.length}__`;return l.push(r),a}),i=i.replace(/<img\b[^>]*?\bv-[a-z0-9_.-]+[^>]*\/?>/gi,r=>{const a=`__VUE_COMP_TOKEN_${l.length}__`;return l.push(r),a}),i=i.replace(/<(p|span)\b([^>]*?\bv-[a-z0-9_.-]+[^>]*)>([\s\S]*?)<\/\1>/gi,r=>{const a=`__VUE_COMP_TOKEN_${l.length}__`;return l.push(r),a}),i=i.replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi,""),i=i.replace(/<div class="terminal-bar">[\s\S]*?<\/div>/gi,""),i=i.replace(/<div class="cursor-line">[\s\S]*?<\/div>/gi,""),i=i.replace(/<span class="cursor">[\s\S]*?<\/span>/gi,""),i=i.replace(/<div class="stamp">\s*([\s\S]*?)\s*<\/div>/gi,`

*[$1]*

`),i=i.replace(/<div class="arrow">\s*([→\->]+)\s*<\/div>/gi,`

$1

`),i=i.replace(/<i>\s*[→\->]+\s*<\/i>/gi,""),i=i.replace(/<div class="prompt">\s*([\s\S]*?)\s*<\/div>/gi,(r,a)=>`
\`\`\`bash
${a.trim()}
\`\`\`
`),i=i.replace(/<p>\s*<i>\$<\/i>\s*([\s\S]*?)<\/p>/gi,(r,a)=>`
\`\`\`bash
$ ${a.trim()}
\`\`\`
`),i=i.replace(/<div class="statusline">\s*([\s\S]*?)\s*<\/div>/gi,(r,a)=>`
> ${Array.from(a.matchAll(/<span>([\s\S]*?)<\/span>/gi)).map(d=>`\`${d[1].trim()}\``).join(" | ")}
`),i=i.replace(/<div class="log-panel">\s*<pre>([\s\S]*?)<\/pre>\s*<\/div>/gi,(r,a)=>`
\`\`\`log
${a.replace(/<span[^>]*>([\s\S]*?)<\/span>/gi,"$1").trim()}
\`\`\`
`),i=Ii(i,"diff-grid",r=>{const a=Array.from(r.matchAll(/<div class="diff\s+([^"]*)">\s*<span>(.*?)<\/span>\s*<pre>([\s\S]*?)<\/pre>\s*<\/div>/gi));return a.length>0?`
`+a.map(c=>{const d=c[2].trim().toUpperCase(),h=c[3].trim();return`**${d}:**
\`\`\`yaml
${h}
\`\`\``}).join(`

`)+`
`:r}),i=Ii(i,"before-after",r=>{const a=r.match(/<div class="before">[\s\S]*?<small>(.*?)<\/small>[\s\S]*?<h2>(.*?)<\/h2>[\s\S]*?<p>(.*?)<\/p>\s*<\/div>/i),c=r.match(/<div class="after">[\s\S]*?<small>(.*?)<\/small>[\s\S]*?<h2>(.*?)<\/h2>[\s\S]*?<p>(.*?)<\/p>\s*<\/div>/i);let d=`
`;return a&&(d+=`### ${a[1]}
## ${a[2]}
${a[3]}

`),c&&(d+=`### ${c[1]}
## ${c[2]}
${c[3]}
`),d.trim()?d:r}),i=i.replace(/<ul\b[^>]*>([\s\S]*?)<\/ul>/gi,(r,a)=>{const c=Array.from(a.matchAll(/<li>\s*(?:<em>)?(\[[x ]\])(?:<\/em>)?\s*([\s\S]*?)<\/li>/gi));return c.length>0?`
`+c.map(d=>`- ${d[1]} ${d[2].trim()}`).join(`
`)+`
`:a}),i=Ii(i,"timeline",r=>{const a=Array.from(r.matchAll(/<div(?:\s+class="([^"]*)")?>\s*<time>([\s\S]*?)<\/time>\s*<b>([\s\S]*?)<\/b>\s*<span>([\s\S]*?)<\/span>\s*<\/div>/gi));return a.length>0?`

`+a.map(c=>{const d=c[1]||"";let h="-";return d.includes("warn")?h="- ⚠️":d.includes("bad")?h="- ❌":d.includes("ok")&&(h="- ✅"),`${h} **${c[2].trim()}** **${c[3].trim()}** — ${c[4].trim()}`}).join(`
`)+`

`:r}),i=Ii(i,"pipeline",r=>{const a=Array.from(r.matchAll(/<div(?:\s+class="([^"]*)")?>\s*<small>([\s\S]*?)<\/small>\s*<b>([\s\S]*?)<\/b>\s*<span>([\s\S]*?)<\/span>\s*<\/div>/gi));return a.length>0?`

`+a.map((c,d)=>{const v=(c[1]||"").includes("hot")?"⚠️ ":"";return`${d+1}. ${v}**${c[3].trim()}** (*${c[4].trim()}*)`}).join(`
`)+`

`:r}),i=Ii(i,"check-grid",r=>{const a=Array.from(r.matchAll(/<div>\s*<span class="([^"]*)"><\/span>\s*<b>([\s\S]*?)<\/b>\s*<p>([\s\S]*?)<\/p>\s*<\/div>/gi));return a.length>0?`

`+a.map(c=>`- ${(c[1]||"").includes("warn")?"⚠️":"✅"} **${c[2].trim()}**: ${c[3].trim()}`).join(`
`)+`

`:r}),i=Ii(i,"manifesto",r=>{const a=Array.from(r.matchAll(/<div>\s*<span>([\s\S]*?)<\/span>\s*<h2>([\s\S]*?)<\/h2>\s*<p>([\s\S]*?)<\/p>\s*<\/div>/gi));return a.length>0?`

`+a.map(c=>`## ${c[1].trim()} ${c[2].trim()}

${c[3].trim()}`).join(`

`)+`

`:r}),i=Ii(i,"split-note",r=>{const a=Array.from(r.matchAll(/<div>\s*<b>([\s\S]*?)<\/b>\s*<p>([\s\S]*?)<\/p>\s*<\/div>/gi));return a.length>0?`

`+a.map(c=>`> **${c[1].trim()}**: ${c[2].trim()}`).join(`
>
`)+`

`:r}),i=i.replace(/<div class="mechanism">\s*<b>([\s\S]*?)<\/b>\s*<p>([\s\S]*?)<\/p>\s*<\/div>/gi,(r,a,c)=>`

> **${a.trim()}**: ${c.trim()}

`),i=i.replace(/<pre>([\s\S]*?)<\/pre>/gi,(r,a)=>`
\`\`\`text
${a.replace(/<span[^>]*>([\s\S]*?)<\/span>/gi,"$1").trim()}
\`\`\`
`),i=i.replace(/<div class="page-head">\s*<span>([\s\S]*?)<\/span>\s*<b>([\s\S]*?)<\/b>\s*<\/div>/gi,`
### $1 ($2)
`),i=i.replace(/<h1\b[^>]*>([\s\S]*?)<\/h1>/gi,`
# $1
`),i=i.replace(/<h2\b[^>]*>([\s\S]*?)<\/h2>/gi,`
## $1
`),i=i.replace(/<h3\b[^>]*>([\s\S]*?)<\/h3>/gi,`
### $1
`),i=i.replace(/<h4\b[^>]*>([\s\S]*?)<\/h4>/gi,`
#### $1
`),i=i.replace(/<p\s+class="ok">\s*●\s*([\s\S]*?)<\/p>/gi,`
✅ **$1**
`),i=i.replace(/<p\s+class="caption">\s*([\s\S]*?)<\/p>/gi,`
> *$1*
`),i=i.replace(/<p\s+class="lead">\s*([\s\S]*?)<\/p>/gi,`
*$1*
`),i=i.replace(/<p\b([^>]*)>([\s\S]*?)<\/p>/gi,(r,a,c)=>/@|v-|:|class=/i.test(a)?r:`
${c.trim()}

`),i=i.replace(/<br\s*\/?>/gi,`
`),i=i.replace(/<hr\s*\/?>/gi,`
---
`),i=i.replace(/<b\b[^>]*>([\s\S]*?)<\/b>/gi,"**$1**"),i=i.replace(/<strong\b[^>]*>([\s\S]*?)<\/strong>/gi,"**$1**"),i=i.replace(/<i\b[^>]*>([\s\S]*?)<\/i>/gi,"*$1*"),i=i.replace(/<code\b[^>]*>([\s\S]*?)<\/code>/gi,(r,a)=>{if(a.startsWith("`")&&a.endsWith("`"))return a;if(a.includes("`")){const c=(a.match(/`+/g)||[]).reduce((h,v)=>Math.max(h,v.length),0),d="`".repeat(c+1);return`${d} ${a} ${d}`}return`\`${a}\``}),i=i.replace(/<small\b[^>]*>([\s\S]*?)<\/small>/gi,"*$1*"),i=i.replace(/\*{4}/g,"** **"),i=i.replace(/<li\b[^>]*>([\s\S]*?)<\/li>/gi,`- $1
`),i=i.replace(/<ul\b[^>]*>([\s\S]*?)<\/ul>/gi,`
$1
`),i=i.replace(/<ol\b[^>]*>([\s\S]*?)<\/ol>/gi,`
$1
`),i=i.replace(/<a\b([^>]*)href=["'](.*?)["']([^>]*)>([\s\S]*?)<\/a>/gi,(r,a,c,d,h)=>{const v=h.trim();return v.includes("<")||v.includes(`
`)?r:`[${v}](${c})`}),i=i.replace(/<blockquote\b[^>]*>([\s\S]*?)<\/blockquote>/gi,(r,a)=>`
`+a.trim().split(`
`).map(c=>`> ${c.trim()}`).join(`
`)+`
`),i=i.replace(/<span\b[^>]*data-type=["']block-ref["'][^>]*data-id=["']([0-9a-zA-Z-]+)["'][^>]*>([\s\S]*?)<\/span>/gi,(r,a,c)=>{const d=c.replace(/<[^>]+>/g,"").trim();return d?`((${a} '${d}'))`:`((${a}))`}),i=i.replace(/<span\b[^>]*data-type=["']a["'][^>]*data-href=["']([^"']+)["'][^>]*>([\s\S]*?)<\/span>/gi,(r,a,c)=>`[${c.replace(/<[^>]+>/g,"").trim()}](${a})`),i=i.replace(/<\/(?:div|section|header|footer|main|article|nav|aside)\b[^>]*>/gi,`
`),i=i.replace(/<(?:div|section|header|footer|main|article|nav|aside)\b[^>]*>/gi,""),i=i.replace(/<\/?span\b[^>]*>/gi,"");for(let r=0;r<l.length;r++)i=i.replace(`__VUE_COMP_TOKEN_${r}__`,l[r]);for(let r=0;r<s.length;r++)i=i.replace(`__VUE_DIV_TOKEN_${r}__`,s[r]);for(let r=0;r<n.length;r++)i=i.replace(`__SCRIPT_TOKEN_${r}__`,n[r]);for(let r=0;r<t.length;r++)i=i.replace(`__CODE_TOKEN_${r}__`,t[r]);return i=i.replace(/\n{3,}/g,`

`).trim(),i}function ka(e){if(!e||typeof e!="string")return"";const t=[];let i=e.replace(/`([^`]+)`/g,n=>(t.push(n),`%%INLINE_CODE_${t.length-1}%%`));return i=i.replace(/(<\/[a-zA-Z0-9_-]+>)\s*\{:[^}]*\}/g,"$1"),i=i.replace(/(\[[^\]]+\]\([^)]+\))\s*\{:\s*style=["']([^"']*)["'][^}]*\}/g,'<span style="$2">$1</span>'),i=i.replace(/(\*\*[^*]+\*\*)\s*\{:\s*style=["']([^"']*)["'][^}]*\}/g,'<span style="$2">$1</span>'),i=i.replace(/(\*[^*]+\*)\s*\{:\s*style=["']([^"']*)["'][^}]*\}/g,'<span style="$2">$1</span>'),i=i.replace(/(~~[^~]+~~)\s*\{:\s*style=["']([^"']*)["'][^}]*\}/g,'<span style="$2">$1</span>'),i=i.replace(/([\p{L}\p{N}_\-]+)\s*\{:\s*style=["']([^"']*)["'][^}]*\}/gu,'<span style="$2">$1</span>'),i=i.replace(/\{:[^}]*\}/g,""),i=i.replace(/%%INLINE_CODE_(\d+)%%/g,(n,o)=>t[parseInt(o,10)]||""),i}function Bf(e){const t=Object.entries(e).filter(([n,o])=>o!=null&&o!=="");return t.length===0?"":`---
${t.map(([n,o])=>typeof o=="string"?o.includes(":")||o.includes(`
`)||o.includes("#")?`${n}: "${o.replace(/"/g,'\\"')}"`:`${n}: ${o}`:`${n}: ${JSON.stringify(o)}`).join(`
`)}
---`}function Mf(e,t){if(!t||!e.startsWith("```"))return e;const i=e.indexOf(`
`);if(i===-1)return e;const n=e.slice(0,i).trim(),o=e.slice(i);return n.includes("{")?e:`${n} {${t}}${o}`}function wa(e,t){if(t==null)return e;const i=t.trim();return i===""||i==="+1"?`<v-click>

${e}

</v-click>`:i==="hide"?`<v-click hide>

${e}

</v-click>`:`<v-click at="${i}">

${e}

</v-click>`}function Df(e){if(!e||!e.preset)return null;const t=e.preset.toLowerCase().trim();if(!t||t==="none")return null;let i={opacity:0},n={opacity:1};switch(t){case"slide-up":i={y:40,opacity:0},n={y:0,opacity:1};break;case"slide-down":i={y:-40,opacity:0},n={y:0,opacity:1};break;case"slide-left":i={x:40,opacity:0},n={x:0,opacity:1};break;case"slide-right":i={x:-40,opacity:0},n={x:0,opacity:1};break;case"zoom-in":case"pop":i={scale:.8,opacity:0},n={scale:1,opacity:1};break;case"bounce":i={y:40,opacity:0},n={y:0,opacity:1,transition:{type:"spring",damping:10,stiffness:100}};break;case"fade-in":default:i={opacity:0},n={opacity:1};break}e.initial&&typeof e.initial=="object"&&(i={...i,...e.initial}),e.enter&&typeof e.enter=="object"&&(n={...n,...e.enter});const o={...n.transition||{}};return typeof e.duration=="number"&&e.duration>0&&(o.duration=e.duration),typeof e.delay=="number"&&e.delay>0&&(o.delay=e.delay),Object.keys(o).length>0&&(n.transition=o),{initial:i,enter:n}}function Qn(e,t,i,n){const o=t!=null&&t.trim()!=="",s=Df(i),l=n==null?void 0:n.trim(),r=l!==void 0&&l!=="",a=r?` style="${l.replace(/"/g,"&quot;")}" class="slide-styled-block"`:"";if(!o&&!s)return r?`<div${a}>

${e}

</div>`:e;if(o&&!s){if(r){const m=t.trim();let f="v-click";return m==="hide"?f="v-click.hide":m!==""&&m!=="+1"&&(f=`v-click="${m}"`),`<div ${f}${a}>

${e}

</div>`}return wa(e,t)}const c=JSON.stringify(s.initial).replace(/"/g,"'"),d=JSON.stringify(s.enter).replace(/"/g,"'"),h=`v-motion :initial="${c}" :enter="${d}"`;if(!o)return`<div ${h}${a}>

${e}

</div>`;const v=t.trim();let u="v-click";return v==="hide"?u="v-click.hide":v!==""&&v!=="+1"&&(u=`v-click="${v}"`),`<div ${u} ${h}${a}>

${e}

</div>`}function xa(e){if(!e)return"";let t=e.trim();t=t.replace(/\{:[^}]*\}/g,"").trim(),t=t.replace(/^:::\s*[a-zA-Z0-9_-]*\s*\r?\n?/g,""),t=t.replace(/\r?\n?:::\s*$/g,"");let o=t.split(/\r?\n/).map(s=>s.trim().replace(/^>\s*/,"")).join(`
`).trim();return o=o.replace(/^\[!(?:NOTE|TIP|IMPORTANT|WARNING|CAUTION|[A-Za-z_-]+)\][^\r\n]*(?:\r?\n)?/i,"").trim(),o=o.replace(/^(?:💡|✏️|❗|⚠️|🚨|\s*)*(?:\*\*|__)?(?:演讲备注|演讲者提词|讲稿备注|演讲提词|备注|Notes?)(?:\*\*|__)?[:：]?\s*(?:\r?\n)?/i,"").trim(),o=o.replace(/^[-*+]\s+/,""),o=o.replace(/^\d+\.\s+/,""),o.trim()}function Lf(e){var n;if(e.subType&&/^h([1-6])$/i.test(e.subType))return parseInt(e.subType.slice(1),10);const i=(e.markdown||e.content||"").trim().match(/^(#{1,6})\s+/);return i?i[1].length:e.type==="h"?(n=e.ial)!=null&&n.subType&&/^h([1-6])$/i.test(e.ial.subType)?parseInt(e.ial.subType.slice(1),10):1:null}function Sa(e,t=2){const i=Math.max(2,t);if(!e||e.length===0)return Array.from({length:i},()=>[]);if(e.length===1&&e[0].children&&e[0].children.length>=2){const c=e[0].children,d=Array.from({length:i},()=>[]),h=Math.min(i,c.length),v=Math.floor(c.length/h),u=c.length%h;let m=0;for(let f=0;f<h;f++){const b=v+(f<u?1:0);d[f]=c.slice(m,m+b),m+=b}return d}const n=c=>{const d=(c.slot||"").trim();if(!d)return null;if(d==="left")return 1;if(d==="center")return 2;if(d==="right")return i===2?2:i;const h=d.match(/^col-(\d+)$/i);if(h){const v=parseInt(h[1],10);if(v>=1&&v<=i)return v}return null},o=e.map(n);if(o.some(c=>c!==null)){if(o.some(u=>u!==null&&u>=2)){const u=Array.from({length:i},()=>[]);let m=1;for(const f of e){const b=n(f);b!==null&&(m=b),u[m-1].push(f)}return u}const d=e.filter(u=>n(u)===1),h=e.filter(u=>n(u)===null),v=i-1;if(h.length>=v){const u=Math.floor(h.length/v),m=h.length%v,f=[d];let b=0;for(let k=0;k<v;k++){const x=u+(k<m?1:0);f.push(h.slice(b,b+x)),b+=x}return f}else if(h.length>0){const u=[d];for(let m=0;m<v;m++)u.push(m<h.length?[h[m]]:[]);return u}else return[d,...Array.from({length:v},()=>[])]}const l=c=>{if(c.type==="h"||c.subType&&/^h[1-6]$/i.test(c.subType))return!0;const d=(c.rawMarkdown||c.content||"").trim();return/^#{1,6}\s+/.test(d)},r=e.map((c,d)=>l(c)?d:-1).filter(c=>c!==-1);if(r.length>=i){const c=Array.from({length:i},()=>[]);for(let d=0;d<i;d++){const h=r[d],v=d+1<i?r[d+1]:e.length;c[d]=e.slice(h,v)}return c}if(e.length>=i){const c=Array.from({length:i},()=>[]);let d=0;for(let h=0;h<i;h++){const v=i-h,u=e.length-d,m=Math.ceil(u/v);c[h]=e.slice(d,d+m),d+=m}return c}if(e.length>1&&e.length<i){const c=Array.from({length:i},()=>[]);for(let d=0;d<e.length;d++)c[d]=[e[d]];return c}if(e.length===1){const c=e[0],d=(c.rawMarkdown||c.content||"").trim(),h=d.split(/\r?\n/),v=[];for(let f=0;f<h.length;f++)/^[ \t]*[-*+]\s+|^[ \t]*\d+\.\s+/.test(h[f])&&v.push(f);if(v.length>=i){const f=Array.from({length:i},()=>[]);let b=0;for(let k=0;k<i;k++){const x=i-k,C=v.length-b,A=Math.ceil(C/x),D=v[b],T=b+A<v.length?v[b+A]:h.length,w=h.slice(D,T).join(`
`);f[k]=[{...c,id:k===0?c.id:`${c.id}-col${k+1}`,rawMarkdown:w,content:w}],b+=A}return f}const u=d.match(/<li[\s\S]*?<\/li>/gi);if(u&&u.length>=i){const f=Array.from({length:i},()=>[]);let b=0;for(let k=0;k<i;k++){const x=i-k,C=u.length-b,A=Math.ceil(C/x),D=`<ul>
${u.slice(b,b+A).join(`
`)}
</ul>`;f[k]=[{...c,id:k===0?c.id:`${c.id}-col${k+1}`,rawMarkdown:D,content:D}],b+=A}return f}const m=d.split(/\r?\n\s*\r?\n/).filter(f=>f.trim()!=="");if(m.length>=i){const f=Array.from({length:i},()=>[]);let b=0;for(let k=0;k<i;k++){const x=i-k,C=m.length-b,A=Math.ceil(C/x),D=m.slice(b,b+A).join(`

`);f[k]=[{...c,id:k===0?c.id:`${c.id}-col${k+1}`,rawMarkdown:D,content:D}],b+=A}return f}}const a=Array.from({length:i},()=>[]);return a[0]=e,a}function Ur(e,t,i,n){var d;const o=wf(t),s=[],l=Wr(t);let r={pageIndex:1,startBlockId:e,frontmatter:{layout:l.frontmatter.layout||"cover",...l.frontmatter},notes:"",noteBlocks:[],blocks:[],rawMarkdown:"",allBlockIds:[e]};r.frontmatter.background&&(r.frontmatter.background=Tt(r.frontmatter.background,n)),r.frontmatter.image&&(r.frontmatter.image=Tt(r.frontmatter.image,n)),s.push(r);let a=[];for(const h of i){if(Io(h)){a=[];const u=Wr(h.ial);if(s.length===1&&r.blocks.length===0){r.startBlockId=h.id,r.allBlockIds||(r.allBlockIds=[]),r.allBlockIds.includes(h.id)||r.allBlockIds.push(h.id),u.frontmatter.layout&&(r.frontmatter.layout=u.frontmatter.layout),Object.assign(r.frontmatter,u.frontmatter),!u.frontmatter.image&&l.frontmatter.image&&(r.frontmatter.image=l.frontmatter.image),!u.frontmatter.background&&l.frontmatter.background&&(r.frontmatter.background=l.frontmatter.background),r.frontmatter.background&&(r.frontmatter.background=Tt(r.frontmatter.background,n)),r.frontmatter.image&&(r.frontmatter.image=Tt(r.frontmatter.image,n));continue}r={pageIndex:s.length+1,startBlockId:h.id,frontmatter:{layout:u.frontmatter.layout||"default",...u.frontmatter},notes:"",noteBlocks:[],blocks:[],rawMarkdown:"",allBlockIds:[h.id]},r.frontmatter.background&&(r.frontmatter.background=Tt(r.frontmatter.background,n)),r.frontmatter.image&&(r.frontmatter.image=Tt(r.frontmatter.image,n)),s.push(r);continue}const v=(u,m)=>{var H,E,O,z;if(r.allBlockIds||(r.allBlockIds=[]),u.id&&!r.allBlockIds.includes(u.id)&&r.allBlockIds.push(u.id),u.children&&u.children.length>0){const X=Z=>{for(const W of Z)W.id&&!r.allBlockIds.includes(W.id)&&r.allBlockIds.push(W.id),W.children&&W.children.length>0&&X(W.children)};X(u.children)}let f=Uc(u),b=u.ial?{...u.ial}:{};const k=f.match(/\{:\s*([^}]+)\s*\}\s*$/);k&&(b={...Vc(k[0]),...b},f=f.slice(0,k.index).trim()),u.type!=="c"&&!f.startsWith("```")&&(f=ka(f));let x=f.trim();if(/^\{\{\{(?:row|col)?\s*$/i.test(x)||x==="}}}")return;/^\{\{\{(?:row|col)?\s*\r?\n/i.test(x)&&/\r?\n\}\}\}$/.test(x)&&(f=x.replace(/^\{\{\{(?:row|col)?\s*\r?\n/i,"").replace(/\r?\n\}\}\}$/,"").trim(),x=f.trim());const C=xf(b);if(f=Kc(f,n),f=Wc(f,n==null?void 0:n.refContentMap),u.children&&u.children.length>0){const X=["custom-slidev-autoplay","custom-slidev-loop","custom-slidev-muted","custom-slidev-controls"],Z=W=>{for(const ie of W){if(ie.ial)for(const[se,re]of Object.entries(ie.ial))X.includes(se)&&!b[se]&&(b[se]=re);ie.children&&ie.children.length>0&&Z(ie.children)}};Z(u.children)}const A=u.type==="video"||u.type==="NodeVideo"||/<video\b/i.test(f);if(A){const X=b["custom-slidev-autoplay"]==="true",Z=b["custom-slidev-loop"]==="true",W=b["custom-slidev-muted"]==="true"||X,ie=b["custom-slidev-controls"]==="false";f=f.replace(/<video\b([^>]*)>/gi,(se,re)=>{let ue=re;return ie?ue=ue.replace(/\bcontrols(?:="[^"]*")?/gi,"").trim():/controls/i.test(ue)||(ue+=" controls"),X&&!/autoplay/i.test(ue)?ue+=" autoplay playsinline":!X&&b["custom-slidev-autoplay"]==="false"&&(ue=ue.replace(/\bautoplay\b/gi,"").replace(/\bplaysinline\b/gi,"").trim()),Z&&!/loop/i.test(ue)?ue+=" loop":!Z&&b["custom-slidev-loop"]==="false"&&(ue=ue.replace(/\bloop\b/gi,"").trim()),W&&!/muted/i.test(ue)?ue+=" muted":!W&&b["custom-slidev-muted"]==="false"&&(ue=ue.replace(/\bmuted\b/gi,"").trim()),`<video ${ue.trim()}>`})}if(C.isBackground){const X=wi(f,u.content);if(X){r.frontmatter.background=Tt(X,n);return}}const D=di(u);if(D){r.frontmatter.layout=D.layout,r.frontmatter.image=Tt(D.imageUrl,n),!r.frontmatter.layoutRatio&&D.ratio&&(r.frontmatter.layoutRatio=D.ratio);for(const X of D.contentNodes)v(X);return}if(C.imageLayout==="image-left"||C.imageLayout==="image-right"){const X=wi(f,u.content);if(X){r.frontmatter.layout=C.imageLayout,r.frontmatter.image=Tt(X,n),!r.frontmatter.layoutRatio&&((H=u.ial)!=null&&H[yt])&&(r.frontmatter.layoutRatio=u.ial[yt]);return}}if(st(u)&&u.children&&u.children.length>0){for(const X of u.children)v(X);return}const T=!!(C.slot||m!=null&&m.defaultSlot||r.frontmatter.layout==="clover"||Ln(r.frontmatter.layout)||r.frontmatter.layout==="two-cols");if((u.type==="l"||u.type==="NodeList"||u.type==="list")&&u.children&&u.children.length>0&&(u.children.some(X=>{var Z,W;return((Z=X.ial)==null?void 0:Z[Ce])||((W=X.ial)==null?void 0:W[Ze])})||C.slot||C.clicks||T)){for(const X of u.children)C.slot&&(!X.ial||!X.ial[Ce])&&(X.ial||(X.ial={}),X.ial[Ce]=C.slot),v(X,{...m,parentClicks:C.clicks||(m==null?void 0:m.parentClicks),defaultSlot:C.slot||(m==null?void 0:m.defaultSlot)});return}const w=!!(u.children&&u.children.length>=2)||!!C.clicks||!!((E=u.children)!=null&&E.some(X=>{var Z;return(Z=X.ial)==null?void 0:Z[Ze]}))||!u.markdown&&!!(u.children&&u.children.length>0);if(zi(u)&&u.children&&u.children.length>0&&(T||C.clicks||u.children.some(X=>{var Z;return(Z=X.ial)==null?void 0:Z[Ze]}))&&w){const X=!!(u.children&&u.children.length>=2),Z=u.children.find(be=>!!(be.markdown||be.content||"").trim())||u.children[0],W=((O=Z==null?void 0:Z.ial)==null?void 0:O[Ze])||((z=Z==null?void 0:Z.ial)==null?void 0:z["custom-slidev-click"]),ie=!!(!C.clicks&&X&&W),se=C.clicks||(ie?W:void 0)||(m==null?void 0:m.parentClicks),re=u.id||(m==null?void 0:m.parentContainerId),ue=C.slot||(m==null?void 0:m.defaultSlot);let Ie=!0;for(const be of u.children){ue&&(!be.ial||!be.ial[Ce])&&(be.ial||(be.ial={}),be.ial[Ce]=ue);const ae=!!(be.markdown||be.content||"").trim(),Y=Ie&&ae;Y&&(be.markdown&&(be.markdown=In(be.markdown)),be.content&&(be.content=In(be.content)),Ie=!1);let ce=be;Y&&se&&X&&(ce={...be,ial:{...be.ial||{}}},delete ce.ial[Ze],delete ce.ial["custom-slidev-click"]),v(ce,{parentClicks:se,parentContainerId:re,defaultSlot:ue})}return}if(C.isNote){const X=xa(f);X&&(r.notes?r.notes+=`

`+X:r.notes=X),r.noteBlocks||(r.noteBlocks=[]),r.noteBlocks.push({id:u.id,type:u.type,content:X||u.content||"",rawMarkdown:f,isNote:!0,attributes:u.ial});return}C.shikiLines&&(f=Mf(f,C.shikiLines)),x=f.trim();const R=(u.content||"").trim();if(x==="::right::"||R==="::right::"||/^<p>\s*::right::\s*<\/p>$/i.test(x)||x.startsWith("::right::")){r.blocks.push({id:u.id,type:u.type,content:"::right::",rawMarkdown:"::right::",slot:"slot-divider-right",attributes:u.ial});return}const F=Lf(u);let q=C.slot,_=C.clicks,L=C.motion,y={...u.ial||{}};if(F!==null){for(;a.length>0&&a[a.length-1].level>=F;)a.pop();const X=a.length>0?a[a.length-1]:void 0;!q&&(X!=null&&X.slot)&&(q=X.slot),!_&&(X!=null&&X.clicks)&&!(m!=null&&m.parentContainerId)&&(_=X.clicks),!L&&(X!=null&&X.motion)&&(L=X.motion);const Z={...(X==null?void 0:X.customAttrs)||{}};if(u.ial)for(const[W,ie]of Object.entries(u.ial))W.startsWith("custom-slidev-")&&!W.startsWith("custom-slidev-slide")&&(Z[W]=ie);m!=null&&m.parentContainerId||a.push({level:F,slot:q,clicks:_,motion:L,customAttrs:Z})}else{const X=a.length>0?a[a.length-1]:void 0;X&&(!q&&X.slot&&X.slot!=="header"&&(q=X.slot),!_&&X.clicks&&!(m!=null&&m.parentContainerId)&&(_=X.clicks),!L&&X.motion&&(L=X.motion),X.customAttrs&&(y={...X.customAttrs,...y}))}!q&&r.blocks.some(X=>X.slot==="slot-divider-right")&&(q="right"),!q&&(m!=null&&m.defaultSlot)&&(q=m.defaultSlot),q&&(y[Ce]=q),_&&!y[Ze]&&(y[Ze]=_),L&&!y[qt]&&(y[qt]=JSON.stringify(L)),(A||b["custom-slidev-autoplay"]||b["custom-slidev-muted"])&&(b["custom-slidev-autoplay"]&&(y["custom-slidev-autoplay"]=b["custom-slidev-autoplay"],b["custom-slidev-autoplay"]==="true"&&!b["custom-slidev-muted"]&&(y["custom-slidev-muted"]="true")),b["custom-slidev-loop"]&&(y["custom-slidev-loop"]=b["custom-slidev-loop"]),b["custom-slidev-muted"]&&(y["custom-slidev-muted"]=b["custom-slidev-muted"]),b["custom-slidev-controls"]&&(y["custom-slidev-controls"]=b["custom-slidev-controls"]));const M={id:u.id,type:u.type,content:u.content||"",rawMarkdown:f,clicks:_,parentClicks:m==null?void 0:m.parentClicks,parentContainerId:m==null?void 0:m.parentContainerId,motion:L,shikiLines:C.shikiLines,slot:q,attributes:y,rawNode:u};r.blocks.push(M)};v(h)}for(let h=0;h<s.length;h++){const v=s[h],u=[],m={...v.frontmatter};h===0&&(m.theme=o.theme,m.aspectRatio=o.aspectRatio,m.highlighter=o.highlighter,m.transition=v.frontmatter.transition||o.defaultTransition);const f=Bf(m);f&&u.push(f);const b=v.blocks.filter(D=>D.slot!=="slot-divider-right"),k=D=>D.filter(T=>!!(T.rawMarkdown||T.content||"").trim()).map(T=>{var w;return Qn(T.rawMarkdown,T.clicks,T.motion,(w=T.attributes)==null?void 0:w.style)}).join(`

`),x=D=>{const T=D.filter(F=>!!(F.rawMarkdown||F.content||"").trim());if(T.length===0)return;const w=T[0],R=(w.rawMarkdown||w.content||"").trim();(zi(w)||/^(?:[-*+]|\d+\.)\s+/.test(R))&&(w.rawMarkdown=In(w.rawMarkdown||w.content||""),w.content=w.rawMarkdown)},C=D=>{var F,q;if(D.length===0)return"";x(D);const T=(F=D.find(_=>_.parentClicks))==null?void 0:F.parentClicks;if(!T)return D.filter(_=>!!(_.rawMarkdown||_.content||"").trim()).map(_=>{var L;return Qn(_.rawMarkdown,_.clicks,_.motion,(L=_.attributes)==null?void 0:L.style)}).join(`

`);const w=[];let R=[];const N=()=>{if(R.length===0)return;const _=R.map(L=>(L.rawMarkdown||L.content||"").trim()).filter(Boolean).join(`

`);_&&w.push(wa(_,T)),R=[]};for(const _ of D){if(!(_.rawMarkdown||_.content||"").trim())continue;!!(_.clicks&&_.clicks.trim()!=="")?(N(),w.push(Qn(_.rawMarkdown,_.clicks,_.motion,(q=_.attributes)==null?void 0:q.style))):R.push(_)}return N(),w.join(`

`)},A=v.frontmatter.layout||"default";if(A==="clover"||Ln(A)){let D=[];const T=b.filter(_=>_.slot==="header");if(T.length>0)D=T;else if(b.length>0){const _=b.find(L=>L.type==="h"&&(!L.slot||L.slot==="default"));_&&(D=[_])}const w=b.filter(_=>!D.includes(_));let R=2;if(A==="clover")R=4;else if(A==="three-cols-header")R=3;else if(A==="two-cols-header")R=2;else{let _=0;for(const L of w){const y=(L.slot||"").match(/^col-(\d+)$/i);y&&(_=Math.max(_,parseInt(y[1],10)))}if(_>=2)R=_;else if(v.frontmatter.layoutRatio){const L=v.frontmatter.layoutRatio.trim();if(L.includes(":")){const y=L.split(":").map(M=>parseFloat(M.trim())).filter(M=>!isNaN(M)&&M>0);y.length>=2&&(R=y.length)}else{const y=L.split(/\s+/).filter(Boolean);y.length>=2&&(R=y.length)}}else w.length===1&&w[0].children&&w[0].children.length>=2&&(R=Math.min(6,w[0].children.length))}const N=Sa(w,R);N.forEach((_,L)=>{const y=`col-${L+1}`;for(const M of _)(!M.slot||M.slot==="default")&&(M.slot=y);x(_)});const F=N.flat();if(w.length===1&&F.length>1){const _=v.blocks.findIndex(L=>L.id===w[0].id);_!==-1&&v.blocks.splice(_,1,...F)}const q=k(D);if(q&&u.push(q),A==="two-cols-header"&&R===2){const _=C(N[0]||[]),L=C(N[1]||[]);_&&u.push(`::left::

${_}`),L&&u.push(`::right::

${L}`)}else N.forEach((_,L)=>{const y=C(_);y&&u.push(`::col-${L+1}::

${y}`)})}else if(A==="two-cols"){const D=b.filter(N=>N.slot==="left"),T=b.filter(N=>N.slot==="right");x(D),x(T);const w=k(D.length>0?D:b.filter(N=>N.slot!=="right")),R=k(T);u.push(w),R&&u.push(`::right::

${R}`)}else for(const D of b)u.push(Qn(D.rawMarkdown,D.clicks,D.motion,(d=D.attributes)==null?void 0:d.style));v.notes&&u.push(`<!--
${v.notes}
-->`),v.rawMarkdown=u.join(`

`).trim()}const c=s.map(h=>h.rawMarkdown).filter(Boolean).join(`

---

`);return{docId:e,config:o,slides:s,fullMarkdown:c}}const $s=`/* SiYuan Note Built-in Font & Background Styles for Slidev */
:root,
html:not(.dark),
[data-theme="light"],
[data-theme-mode="light"] {
  /* 思源基础卡片与主题色 (浅色模式 daylight) */
  --b3-card-error-color: #790600;
  --b3-card-error-background: #f5d1cf;
  --b3-card-warning-color: #8a4f00;
  --b3-card-warning-background: #ffe8c8;
  --b3-card-info-color: #005599;
  --b3-card-info-background: #d6eaf9;
  --b3-card-success-color: #006b04;
  --b3-card-success-background: #d7eed8;

  --b3-theme-primary: #3575f0;
  --b3-theme-secondary: #ff9200;
  --b3-theme-error: #d23f31;
  --b3-theme-background: #ffffff;
  --b3-theme-on-background: #222222;
  --b3-theme-on-surface: #5f6368;
  --b3-theme-surface-lighter: #e0e0e0;

  /* 13 种内置文字颜色 */
  --b3-font-color1: var(--b3-card-error-color);
  --b3-font-color2: var(--b3-card-warning-color);
  --b3-font-color3: var(--b3-card-info-color);
  --b3-font-color4: var(--b3-card-success-color);
  --b3-font-color5: var(--b3-theme-on-surface);
  --b3-font-color6: var(--b3-theme-primary);
  --b3-font-color7: var(--b3-theme-secondary);
  --b3-font-color8: var(--b3-theme-error);
  --b3-font-color9: #a40074;
  --b3-font-color10: #007080;
  --b3-font-color11: #006e2a;
  --b3-font-color12: #6b5a00;
  --b3-font-color13: var(--b3-theme-background);

  /* 13 种内置背景颜色 */
  --b3-font-background1: var(--b3-card-error-background);
  --b3-font-background2: var(--b3-card-warning-background);
  --b3-font-background3: var(--b3-card-info-background);
  --b3-font-background4: var(--b3-card-success-background);
  --b3-font-background5: #e2e3e4;
  --b3-font-background6: #acd0fc;
  --b3-font-background7: #fddaab;
  --b3-font-background8: #ffb0a9;
  --b3-font-background9: #fdbfff;
  --b3-font-background10: #b1ffff;
  --b3-font-background11: #affad1;
  --b3-font-background12: #fff88f;
  --b3-font-background13: var(--b3-theme-on-background);
}

html.dark,
[data-theme="dark"],
[data-theme-mode="dark"],
.theme-dark,
.dark {
  /* 思源基础卡片与主题色 (深色模式 midnight) */
  --b3-card-error-color: rgb(243, 153, 147);
  --b3-card-error-background: #442724;
  --b3-card-warning-color: rgb(255, 213, 153);
  --b3-card-warning-background: #554636;
  --b3-card-info-color: rgb(166, 213, 250);
  --b3-card-info-background: #28405c;
  --b3-card-success-color: rgb(183, 223, 185);
  --b3-card-success-background: #425347;

  --b3-theme-primary: #3575f0;
  --b3-theme-secondary: #ff9200;
  --b3-theme-error: #d23f31;
  --b3-theme-background: #1e1e1e;
  --b3-theme-on-background: #c8ccd6;
  --b3-theme-on-surface: #8b949e;
  --b3-theme-surface-lighter: #282a2e;

  /* 13 种内置文字颜色 */
  --b3-font-color1: var(--b3-card-error-color);
  --b3-font-color2: var(--b3-card-warning-color);
  --b3-font-color3: var(--b3-card-info-color);
  --b3-font-color4: var(--b3-card-success-color);
  --b3-font-color5: var(--b3-theme-on-surface);
  --b3-font-color6: var(--b3-theme-primary);
  --b3-font-color7: var(--b3-theme-secondary);
  --b3-font-color8: var(--b3-theme-error);
  --b3-font-color9: #f47c9c;
  --b3-font-color10: #4dd0e1;
  --b3-font-color11: #10df54;
  --b3-font-color12: #ecd424;
  --b3-font-color13: var(--b3-theme-background);

  /* 13 种内置背景颜色 */
  --b3-font-background1: var(--b3-card-error-background);
  --b3-font-background2: var(--b3-card-warning-background);
  --b3-font-background3: var(--b3-card-info-background);
  --b3-font-background4: var(--b3-card-success-background);
  --b3-font-background5: #3a3f42;
  --b3-font-background6: #031840;
  --b3-font-background7: #593905;
  --b3-font-background8: #3a0c09;
  --b3-font-background9: #4d1b40;
  --b3-font-background10: #1a5459;
  --b3-font-background11: #305415;
  --b3-font-background12: #4a4712;
  --b3-font-background13: var(--b3-theme-on-background);
}

@media (prefers-color-scheme: dark) {
  :root:not([data-theme="light"]):not([data-theme-mode="light"]):not(.light) {
    --b3-card-error-color: rgb(243, 153, 147);
    --b3-card-error-background: #442724;
    --b3-card-warning-color: rgb(255, 213, 153);
    --b3-card-warning-background: #554636;
    --b3-card-info-color: rgb(166, 213, 250);
    --b3-card-info-background: #28405c;
    --b3-card-success-color: rgb(183, 223, 185);
    --b3-card-success-background: #425347;

    --b3-theme-primary: #3575f0;
    --b3-theme-secondary: #ff9200;
    --b3-theme-error: #d23f31;
    --b3-theme-background: #1e1e1e;
    --b3-theme-on-background: #c8ccd6;
    --b3-theme-on-surface: #8b949e;
    --b3-theme-surface-lighter: #282a2e;

    --b3-font-color1: var(--b3-card-error-color);
    --b3-font-color2: var(--b3-card-warning-color);
    --b3-font-color3: var(--b3-card-info-color);
    --b3-font-color4: var(--b3-card-success-color);
    --b3-font-color5: var(--b3-theme-on-surface);
    --b3-font-color6: var(--b3-theme-primary);
    --b3-font-color7: var(--b3-theme-secondary);
    --b3-font-color8: var(--b3-theme-error);
    --b3-font-color9: #f47c9c;
    --b3-font-color10: #4dd0e1;
    --b3-font-color11: #10df54;
    --b3-font-color12: #ecd424;
    --b3-font-color13: var(--b3-theme-background);

    --b3-font-background1: var(--b3-card-error-background);
    --b3-font-background2: var(--b3-card-warning-background);
    --b3-font-background3: var(--b3-card-info-background);
    --b3-font-background4: var(--b3-card-success-background);
    --b3-font-background5: #3a3f42;
    --b3-font-background6: #031840;
    --b3-font-background7: #593905;
    --b3-font-background8: #3a0c09;
    --b3-font-background9: #4d1b40;
    --b3-font-background10: #1a5459;
    --b3-font-background11: #305415;
    --b3-font-background12: #4a4712;
    --b3-font-background13: var(--b3-theme-on-background);
  }
}

/* 演示块级样式排版增强 (带背景色时赋予呼吸内边距与舒适圆角) */
.slide-styled-block {
  border-radius: 6px;
  padding: 8px 14px;
  box-sizing: border-box;
  margin: 6px 0;
  transition: background-color 0.2s ease, color 0.2s ease;
}

/* 行内带背景色文本的精美圆角与微边距 */
span[style*="background-color"],
span[style*="background:"] {
  border-radius: 3px;
  padding: 1px 5px;
  box-decoration-break: clone;
  -webkit-box-decoration-break: clone;
}
`;function Of(e){var o,s,l,r,a,c,d,h,v,u,m,f;if(!e||typeof e!="object")return"";const t=[],i=[];if(Array.isArray(e.styles))for(const b of e.styles){if(!b||!b.id)continue;const k=`--b3-inline-style-${b.id}`;(o=b.light)!=null&&o.color&&t.push(`  ${k}-color: ${b.light.color};`),(s=b.light)!=null&&s.backgroundColor&&t.push(`  ${k}-background-color: ${b.light.backgroundColor};`),(l=b.dark)!=null&&l.color&&i.push(`  ${k}-color: ${b.dark.color};`),(r=b.dark)!=null&&r.backgroundColor&&i.push(`  ${k}-background-color: ${b.dark.backgroundColor};`)}if(e.builtin&&Array.isArray(e.builtin.colors))for(const b of e.builtin.colors){if(!b||typeof b.index!="number")continue;const k=b.index;(a=b.light)!=null&&a.color&&t.push(`  --b3-font-color${k}: ${b.light.color};`),(c=b.light)!=null&&c.backgroundColor&&t.push(`  --b3-font-background${k}: ${b.light.backgroundColor};`),(d=b.dark)!=null&&d.color&&i.push(`  --b3-font-color${k}: ${b.dark.color};`),(h=b.dark)!=null&&h.backgroundColor&&i.push(`  --b3-font-background${k}: ${b.dark.backgroundColor};`)}if(e.builtin&&Array.isArray(e.builtin.styles))for(const b of e.builtin.styles){if(!b||!b.id)continue;const k=b.id;(v=b.light)!=null&&v.color&&t.push(`  --b3-card-${k}-color: ${b.light.color};`),(u=b.light)!=null&&u.backgroundColor&&t.push(`  --b3-card-${k}-background: ${b.light.backgroundColor};`),(m=b.dark)!=null&&m.color&&i.push(`  --b3-card-${k}-color: ${b.dark.color};`),(f=b.dark)!=null&&f.backgroundColor&&i.push(`  --b3-card-${k}-background: ${b.dark.backgroundColor};`)}if(t.length===0&&i.length===0)return"";const n=[];return t.length>0&&n.push(`:root, html:not(.dark), [data-theme="light"] {
${t.join(`
`)}
}`),i.length>0&&n.push(`html.dark, [data-theme="dark"], .dark {
${i.join(`
`)}
}`),n.join(`

`)}function En(e){const t=Of(e);return t?`${$s}

/* Custom Workspace Inline Styles */
${t}`:$s}function os(e){const t={};if(!e||typeof e!="string")return t;const i=e.replace(/^\{:\s*/,"").replace(/\s*\}$/,""),n=/([\w-]+)=(?:"([^"]*)"|'([^']*)'|(\S+))/g;let o;for(;(o=n.exec(i))!==null;){const s=o[1],l=o[2]??o[3]??o[4]??"";t[s]=l}return t}function Pf(e){const t=String((e==null?void 0:e.type)||"").toLowerCase();return t==="s"||t==="sb"||t==="nodesuperblock"||t==="l"||t==="nodelist"||t==="i"||t==="nodelistitem"||t==="b"||t==="nodeblockquote"}function Rf(e,t){const i=new Map,n=[];if(!Array.isArray(t)||t.length===0)return{usable:!1,reason:"索引无行",leafPatch:i,rebuildRoots:n};const o=new Map;for(const s of t)s!=null&&s.id&&o.set(s.id,s);for(const s of e||[]){if(!(s!=null&&s.id))continue;const l=o.get(s.id);if(!l)continue;const r=s.content??"",a=s.markdown??"";(l.content??"")===r&&(l.markdown??"")===a||(Pf(l)?n.push(s.id):i.set(s.id,{content:r,markdown:a}))}return{usable:!0,reason:"",leafPatch:i,rebuildRoots:n}}function Nf(e){const t=String((e==null?void 0:e.type)||"").toLowerCase();return t==="h"||t==="nodeheading"}function Is(e){return st(e)||e.type==="l"||e.type==="NodeList"||e.type==="i"||e.type==="NodeListItem"||e.type==="b"||e.type==="NodeBlockquote"}function zf(e,t,i,n=8,o){const s=new Map;for(const v of t)v!=null&&v.id&&s.set(v.id,v);const l=v=>({id:v.id,parent_id:v.parent_id,root_id:v.root_id||e,type:v.type,subType:v.subtype??v.subType??"",content:v.content||"",markdown:v.markdown||"",ial:i(v.id,v.ial),children:[]}),r=v=>{let u=v.parent_id,m=0;for(;u&&u!==e&&m++<16;){const f=s.get(u);if(!f||!Nf(f))return u;u=f.parent_id}return u||e},a=new Map;for(const v of t){if(!(v!=null&&v.id)||v.id===e||o&&o.size>0&&!o.has(v.id))continue;const u=r(v),m=a.get(u);m?m.push(v):a.set(u,[v])}if(o&&o.size>0)for(const v of a.values())v.sort((u,m)=>(o.get(u.id)??Number.MAX_SAFE_INTEGER)-(o.get(m.id)??Number.MAX_SAFE_INTEGER));const c=new Map,d=(v,u)=>{const m=l(v);if(c.set(m.id,m),u>=n||!Is(m))return m;const f=a.get(m.id);return f&&f.length>0&&(m.children=f.map(b=>d(b,u+1))),m};return{topLevel:(a.get(e)||[]).map(v=>d(v,0)),byId:c}}const Ff={getBlockAttrs:Bs,getChildBlocks:fo,getDocBlocksOrders:Fc,setBlockAttrs:Ne,sql:on,getBaseUrl:()=>typeof location<"u"?location.origin:"",getInlineStyles:Hc};class Hf{constructor(t){ke(this,"deps");ke(this,"attrOverrides",new Map);ke(this,"trackedListSuperBlocks",new Map);ke(this,"fallbackWarnedDocId","");this.deps={...Ff,...t||{}}}setBlockAttrOverride(t,i){if(!t||!i)return;const o={...this.attrOverrides.get(t)||{}};for(const[s,l]of Object.entries(i))l===""||l===null||l===void 0?delete o[s]:o[s]=String(l);Object.keys(o).length===0?this.attrOverrides.delete(t):this.attrOverrides.set(t,o)}getBlockAttrOverride(t){return this.attrOverrides.get(t)}getAllAttrOverrides(){return new Map(this.attrOverrides)}getTrackedListSuperBlocks(t){return this.trackedListSuperBlocks.get(t)||[]}clearBlockAttrOverride(t,i){if(!t)return;if(!i){this.attrOverrides.delete(t);return}const n=this.attrOverrides.get(t);n&&(delete n[i],Object.keys(n).length===0&&this.attrOverrides.delete(t))}clearAllOverrides(){this.attrOverrides.clear(),this.trackedListSuperBlocks.clear()}async compile(t){try{const i=await this.deps.getBlockAttrs(t).catch(()=>({}))||{},n=this.attrOverrides.get(t);n&&Object.assign(i,n);const o=await this.deps.getChildBlocks(t).catch(()=>[])||[],s=this.deps.getDocBlocksOrders?await this.deps.getDocBlocksOrders(t).catch(()=>[])||[]:[],l=new Map;for(let M=0;M<s.length;M++)s[M]&&l.set(s[M],M);const r=l.size>0,a=`SELECT id, parent_id, root_id, type, subtype, content, markdown, ial, sort, created FROM blocks WHERE root_id = '${t}' AND id != '${t}' ORDER BY sort ASC, created ASC LIMIT 99999`,c=await this.deps.sql(a).catch(()=>[])||[],d=Rf(o,c),h=new Map;if(Array.isArray(c))for(const M of c)M.id&&M.ial&&h.set(M.id,os(M.ial));const v=`SELECT block_id, name, value FROM attributes WHERE root_id = '${t}' AND type = 'b' LIMIT 99999`,u=await this.deps.sql(v).catch(()=>[])||[];if(Array.isArray(u)){for(const M of u)if(M.block_id&&M.name){let H=h.get(M.block_id);H||(H={},h.set(M.block_id,H)),H[M.name]=M.value||""}}const m=(M,H)=>{const E={...h.get(M)||(H?os(H):{})},O=this.attrOverrides.get(M);return O&&Object.assign(E,O),E},f=Array.isArray(c)&&c.length>0?zf(t,c,m,8,l):null,b=o.map(M=>M.id).filter(Boolean),k=M=>({id:M.id,parent_id:M.parent_id,root_id:M.root_id||t,type:M.type,subType:M.subType,content:M.content||"",markdown:M.markdown||"",ial:m(M.id,M.ial),children:M.children}),x=async(M,H=0)=>{if(!M||H>8||!Is(M))return;const E=await this.deps.getChildBlocks(M.id).catch(()=>[])||[];if(!(!Array.isArray(E)||E.length===0)){M.children=E.filter(O=>O==null?void 0:O.id).map(O=>({id:O.id,parent_id:M.id,root_id:t,type:O.type,subType:O.subType,content:O.content||"",markdown:O.markdown||"",ial:m(O.id,O.ial),children:[]}));for(const O of M.children)await x(O,H+1)}},C=new Map;for(const M of c)M!=null&&M.id&&C.set(M.id,M);const A=b.every(M=>{const H=C.get(M);return!H||!!H.type});let D=[],T=!1;if(f&&d.usable&&r&&A){this.fallbackWarnedDocId="";for(const[H,E]of d.leafPatch){const O=f.byId.get(H);O&&(O.content=E.content,O.markdown=E.markdown)}const M=new Map;for(const H of o)H!=null&&H.id&&M.set(H.id,H);for(const H of d.rebuildRoots){const E=f.byId.get(H),O=M.get(H);E&&O&&(E.content=O.content||"",E.markdown=O.markdown||""),await x(E)}for(const H of o){if(!(H!=null&&H.id)||f.byId.has(H.id))continue;const E=k(H);await x(E),f.byId.set(E.id,E),f.topLevel.push(E)}D=f.topLevel.filter(H=>l.has(H.id)).sort((H,E)=>(l.get(H.id)??0)-(l.get(E.id)??0))}else b.length>0?(T=!0,this.fallbackWarnedDocId!==t&&(this.fallbackWarnedDocId=t,console.warn(`[DocumentCompiler] 索引结构不可用，回退逐容器查询（较慢）doc=${t} 实时顶层=${b.length} 索引行=${c.length} 文档序=${s.length} 原因=${d.reason||"缺少实时文档序"}`)),D=o.map(M=>k(M))):f&&(D=f.topLevel);const w=async(M,H=0)=>{if(!(!M||M.length===0||H>8))for(const E of M){if(Is(E)&&(!E.children||E.children.length===0)){let z=await this.deps.getChildBlocks(E.id).catch(()=>[]);if(!z||z.length===0){const X=`SELECT id, parent_id, root_id, type, subtype as subType, content, markdown, ial FROM blocks WHERE parent_id = '${E.id}' ORDER BY sort ASC, created ASC`;z=await this.deps.sql(X).catch(()=>[])||[]}if(Array.isArray(z)&&z.length>0){const X=new Set(D.map(W=>W.id)),Z=z.filter(W=>W.id!==E.id&&!X.has(W.id));Z.length>0&&(E.children=Z.map(W=>{const ie=h.get(W.id)||(W.ial?os(W.ial):{}),se=this.attrOverrides.get(W.id);return se&&Object.assign(ie,se),{id:W.id,parent_id:W.parent_id||E.id,root_id:W.root_id||t,type:W.type,subType:W.subType,content:W.content||"",markdown:W.markdown||"",ial:ie}}))}}E.children&&E.children.length>0&&await w(E.children,H+1)}};T&&await w(D);const R=M=>{var H,E;for(const O of M)if(O.children&&O.children.length>0){R(O.children);for(const z of O.children)if(z.ial)for(const[X,Z]of Object.entries(z.ial))X.startsWith("custom-slidev-")&&!((H=O.ial)!=null&&H[X])&&(O.ial||(O.ial={}),O.ial[X]=Z);if(O.ial){for(const[z,X]of Object.entries(O.ial))if(z.startsWith("custom-slidev-"))for(const Z of O.children)(Z.type==="video"||Z.type==="NodeVideo"||/<video\b/i.test(Z.markdown||Z.content||""))&&!((E=Z.ial)!=null&&E[z])&&(Z.ial||(Z.ial={}),Z.ial[z]=X)}}};R(D),Tf(D,M=>{const H={[he]:M.layout};this.setBlockAttrOverride(M.blockId,H),(this.deps.setBlockAttrs||Ne)(M.blockId,H).catch(O=>{console.warn("[DocumentCompiler] Failed to auto-tag superblock image layout:",O)})});const N=this.trackedListSuperBlocks.get(t)||[],F=If(t,D,{tracked:N,onTagChange:M=>{this.setBlockAttrOverride(M.blockId,M.attrs),M.blockId===t&&Object.assign(i,M.attrs);const H=O=>{for(const z of O)z.id===M.blockId&&(z.ial||(z.ial={}),Object.assign(z.ial,M.attrs)),z.children&&z.children.length>0&&H(z.children)};H(D),(this.deps.setBlockAttrs||Ne)(M.blockId,M.attrs).catch(O=>{console.warn("[DocumentCompiler] Failed to auto-tag list superblock attrs:",O)})}});this.trackedListSuperBlocks.set(t,F.newTracked);const q=new Set;for(const M of D){const H=M.markdown||M.content||"";if(H.includes("((")){const E=jc(H);for(const O of E)q.add(O.blockId)}}const _={};if(q.size>0){const M=Array.from(q).map(E=>`'${E}'`).join(","),H=await this.deps.sql(`SELECT id, content, markdown FROM blocks WHERE id IN (${M})`).catch(()=>[])||[];if(Array.isArray(H))for(const E of H)E.id&&(_[E.id]=E.markdown||E.content||"")}const L=this.deps.getBaseUrl?this.deps.getBaseUrl():"",y=Ur(t,i,D,{baseUrl:L,refContentMap:_});try{const M=this.deps.getInlineStyles?await this.deps.getInlineStyles().catch(()=>null):null;y.customThemeCss=En(M)}catch{y.customThemeCss=En(null)}return y}catch(i){console.error("[DocumentCompilerService] Failed to compile document:",i);const n=Ur(t,{},[],{});return n.customThemeCss=En(null),n}}}const Be=new Hf;class Qs{constructor(t){ke(this,"devServerUrl","http://localhost:3030");ke(this,"isConnected",!1);ke(this,"lastSyncTime",null);t&&(this.devServerUrl=t)}getUrl(){return this.devServerUrl}setUrl(t){this.devServerUrl=t.replace(/\/+$/,"")}isServerConnected(){return this.isConnected}getLastSyncTime(){return this.lastSyncTime}async probeServer(t=1500){try{const i=new AbortController,n=setTimeout(()=>i.abort(),t),o=await fetch(this.devServerUrl,{method:"HEAD",mode:"no-cors",signal:i.signal}).catch(()=>null);return clearTimeout(n),this.isConnected=!!o,this.isConnected}catch{return this.isConnected=!1,!1}}buildStandardSlidevMarkdown(t){const i=t.config,n=["---",`theme: ${i.theme||"default"}`,`aspectRatio: "${i.aspectRatio||"16/9"}"`,`highlighter: ${i.highlighter||"shiki"}`,`transition: ${i.defaultTransition||"slide-left"}`];i.colorSchema&&i.colorSchema!=="auto"&&n.push(`colorSchema: ${i.colorSchema}`),n.push("drawings:","  persist: false","---","");const o=n.join(`
`),s=t.slides.map((r,a)=>{const c=r.frontmatter||{},d=[],h=a===0;c.layout&&c.layout!=="default"&&d.push(`layout: ${c.layout}`),c.transition&&d.push(`transition: ${c.transition}`),c.background&&d.push(`background: ${c.background}`),c.class&&d.push(`class: "${c.class}"`);let v="";d.length>0?v=h?"":`---
${d.join(`
`)}
---

`:h||(v=`---

`);let u="";if(c.layout==="two-cols"){const f=r.blocks.filter(C=>C.slot!=="right"),b=r.blocks.filter(C=>C.slot==="right"),k=f.map(C=>C.rawMarkdown||C.content||"").join(`

`),x=b.map(C=>C.rawMarkdown||C.content||"").join(`

`);u=`${k}

::right::

${x}`}else u=r.blocks.map(f=>f.rawMarkdown||f.content||"").join(`

`);let m="";return r.notes&&r.notes.trim()&&(m=`

<!--
${r.notes.trim()}
-->`),`${v}${u}${m}`}).join(`

`);let l="";return t.config.normalizeHeadingSizes&&(l=`

<style>
/* Specific Heading Normalization */
.slidev-layout:not(.cover) > :is(h1, h2, h3, h4, h5, h6):first-child {
  font-size: 1.7rem !important;
}
.two-cols-header-top :is(h1, h2, h3, h4, h5, h6),
.cols-header-top :is(h1, h2, h3, h4, h5, h6),
.layout-header-section :is(h1, h2, h3, h4, h5, h6) {
  font-size: 1.7rem !important;
}
:is(.two-cols-left, .two-cols-right, .col, .col-1, .col-2, .col-3, .three-cols-col) > :is(h1, h2, h3, h4, h5, h6):first-child {
  font-size: 1.3rem !important;
}
</style>`),`${o}${s}${l}
`}async syncToWorkspaceFile(t,i="/data/storage/petal/siyuan-slidev/slides.md",n){const o=this.buildStandardSlidevMarkdown(t);if(this.lastSyncTime=Date.now(),n)try{const s=typeof Blob<"u"?new Blob([o],{type:"text/markdown;charset=utf-8"}):Buffer.from(o,"utf-8");return await n(i,!1,s),{success:!0,path:i}}catch(s){return{success:!1,path:i,error:String(s)}}return{success:!0,path:i}}downloadSlidesMd(t,i="slides.md"){if(typeof window>"u"||typeof document>"u")return!1;const n=this.buildStandardSlidevMarkdown(t),o=new Blob([n],{type:"text/markdown;charset=utf-8"}),s=URL.createObjectURL(o),l=document.createElement("a");return l.href=s,l.download=i,document.body.appendChild(l),l.click(),document.body.removeChild(l),URL.revokeObjectURL(s),!0}}function jf(){if(typeof window<"u"&&typeof window.require=="function")return window.require.bind(window);if(typeof globalThis<"u"&&typeof globalThis.require=="function")return globalThis.require.bind(globalThis);if(typeof require=="function")return require}function Ct(e){const t=jf();if(t)try{return t(e)}catch{try{const i=e.startsWith("node:")?e.slice(5):`node:${e}`;return t(i)}catch{}}}function er(){var t;if(typeof window<"u"&&window.process)return window.process;const e=Ct("process");return e&&e.versions?e:typeof process<"u"&&((t=process.versions)!=null&&t.node)?process:globalThis.process}function _a(){var t,i;const e=er();if(e&&((t=e.versions)!=null&&t.node))return!0;if(typeof window<"u"&&window.siyuan){const n=Ct("child_process");if(n&&typeof n.spawn=="function")return!0}return!!(typeof process<"u"&&((i=process.versions)!=null&&i.node))}function Wf(){if(typeof window>"u"||!window.location)return!1;try{return new URLSearchParams(window.location.search).get("remote")==="1"}catch{return!1}}function Hn(){const e=er();if(e!=null&&e.platform)return e.platform;if(typeof process<"u"&&process.platform)return process.platform;const t=Ct("os");if(t&&typeof t.platform=="function")return t.platform();if(typeof navigator<"u"){const i=navigator.userAgent.toLowerCase();if(i.includes("win"))return"win32";if(i.includes("mac"))return"darwin";if(i.includes("linux"))return"linux"}return"web"}function Ca(){var n,o;const e=er(),t={...(e==null?void 0:e.env)||{}};if(Hn()==="win32"){const s=["C:\\Program Files\\nodejs","C:\\Program Files (x86)\\nodejs",(n=e==null?void 0:e.env)!=null&&n.APPDATA?`${e.env.APPDATA}\\npm`:"",(o=e==null?void 0:e.env)!=null&&o.USERPROFILE?`${e.env.USERPROFILE}\\AppData\\Roaming\\npm`:""].filter(Boolean),l=Object.keys(t).find(c=>c.toLowerCase()==="path")||"PATH",a=(t[l]||"").split(";").filter(Boolean);for(const c of s)c&&!a.some(d=>d.toLowerCase()===c.toLowerCase())&&a.push(c);t[l]=a.join(";")}return t}function Ts(e){var i,n,o;if(!e)return"";if(/^[a-zA-Z]:[/\\]/.test(e))return e.replace(/\\/g,"/");let t="";if(typeof window<"u"&&((o=(n=(i=window.siyuan)==null?void 0:i.config)==null?void 0:n.system)!=null&&o.dataDir)&&(t=window.siyuan.config.system.dataDir.replace(/\\/g,"/")),t&&e.startsWith("/data/")){const s=e.slice(6);return`${t}/${s}`.replace(/\\/g,"/")}return e}function Uf(){const e=Ct("os"),t=Ct("path");if(e&&typeof e.tmpdir=="function"){const i=e.tmpdir();return t&&typeof t.join=="function"?t.join(i,"siyuan-slidev-pro").replace(/\\/g,"/"):`${i}/siyuan-slidev-pro`.replace(/\\/g,"/")}return"/data/storage/petal/siyuan-slidev/pro-workspace"}class tr{constructor(t){ke(this,"runner");this.runner=t||tr.defaultRunner}static async defaultRunner(t,i){var n;try{let o=(n=Ct("child_process"))==null?void 0:n.execFile;if(!o){const a=await import("node:child_process").catch(()=>({}));o=a==null?void 0:a.execFile}if(!o)return{code:-1,stdout:"",stderr:"child_process execFile not available"};const l=Hn()==="win32",r=Ca();return await new Promise(a=>{o(t,i,{timeout:5e3,shell:l,env:r},(c,d,h)=>{a({code:c?c.code||1:0,stdout:d?String(d).trim():"",stderr:h?String(h).trim():""})})})}catch(o){return{code:-1,stdout:"",stderr:String(o)}}}async detect(){const t=_a(),i=Hn();if(!t)return{hasNode:!1,hasSlidevCli:!1,platform:"browser",isDesktop:!1,error:"当前处于纯前端浏览器或移动端环境，无 Node.js 运行时支撑"};let n=!1,o,s=!1,l;try{const r=await this.runner("node",["-v"]);r.code===0&&r.stdout.startsWith("v")&&(n=!0,o=r.stdout)}catch{}if(n){try{const r=i==="win32"?"slidev.cmd":"slidev",a=await this.runner(r,["--version"]);a.code===0&&a.stdout&&(s=!0,l=a.stdout)}catch{}if(!s)try{const r=i==="win32"?"npx.cmd":"npx",a=await this.runner(r,["@slidev/cli","--version"]);a.code===0&&a.stdout&&(s=!0,l=a.stdout)}catch{}}return{hasNode:n,nodeVersion:o,hasSlidevCli:s,slidevVersion:l,platform:i,isDesktop:t}}}class Vf{constructor(){ke(this,"iframe",null);ke(this,"isReady",!1);ke(this,"pageChangedHandlers",[]);ke(this,"readyHandlers",[]);ke(this,"currentState",{no:1,clicks:0,total:1});this.handleWindowMessage=this.handleWindowMessage.bind(this)}getCurrentState(){return{...this.currentState}}attach(t){this.detach(),this.iframe=t,this.isReady=!1,typeof window<"u"&&window.addEventListener("message",this.handleWindowMessage)}detach(){typeof window<"u"&&window.removeEventListener("message",this.handleWindowMessage),this.iframe=null,this.isReady=!1}postMessage(t,i){var o;if(!((o=this.iframe)!=null&&o.contentWindow))return;const n={target:"slidev",sender:"siyuan",type:t,...i};try{this.iframe.contentWindow.postMessage(n,"*")}catch(s){console.warn("[NativeSlidevBridge] postMessage error:",s)}}navigateToPage(t){this.postMessage("navigate",{no:t})}next(){this.postMessage("next")}prev(){this.postMessage("prev")}nextClick(){this.postMessage("next-click")}prevClick(){this.postMessage("prev-click")}onPageChanged(t){return this.pageChangedHandlers.push(t),()=>{this.pageChangedHandlers=this.pageChangedHandlers.filter(i=>i!==t)}}onReady(t){return this.readyHandlers.push(t),()=>{this.readyHandlers=this.readyHandlers.filter(i=>i!==t)}}handleWindowMessage(t){const i=t.data;if(!(!i||i.target!=="slidev")){if(!this.isReady){this.isReady=!0;for(const n of this.readyHandlers)n()}if(i.type==="update-state"&&i.navState){const n=i.navState;this.currentState={no:n.no??this.currentState.no,clicks:n.clicks??this.currentState.clicks,total:n.total??this.currentState.total,hasNext:n.hasNext,hasPrev:n.hasPrev};for(const o of this.pageChangedHandlers)o(this.currentState.no,this.currentState.total||1,this.currentState)}else if(i.type==="navigate"&&typeof i.no=="number"){this.currentState.no=i.no;for(const n of this.pageChangedHandlers)n(i.no,this.currentState.total||1,this.currentState)}}}}class Kf{constructor(t){ke(this,"childProcess",null);ke(this,"activePort",null);ke(this,"isRunning",!1);ke(this,"defaultPort");ke(this,"maxPortRetries");ke(this,"probeTimeoutMs");ke(this,"customSpawner");ke(this,"customPortChecker");this.defaultPort=(t==null?void 0:t.defaultPort)||3030,this.maxPortRetries=(t==null?void 0:t.maxPortRetries)||20,this.probeTimeoutMs=(t==null?void 0:t.probeTimeoutMs)||1e4,this.customSpawner=t==null?void 0:t.customSpawner,this.customPortChecker=t==null?void 0:t.customPortChecker}getActivePort(){return this.activePort}getIsRunning(){return this.isRunning}async isPortAvailable(t){if(this.customPortChecker)return this.customPortChecker(t);try{let i=Ct("net");return i||(i=await import("node:net").catch(()=>({}))),i!=null&&i.createServer?await new Promise(n=>{const o=i.createServer();o.once("error",()=>n(!1)),o.once("listening",()=>{o.close(()=>n(!0))}),o.listen(t,"127.0.0.1")}):!0}catch{return!0}}async allocPort(t){const i=t||this.defaultPort;for(let n=0;n<this.maxPortRetries;n++){const o=i+n;if(await this.isPortAvailable(o))return o}return i}async pollServerReady(t,i=8e3,n=300){const o=Date.now();for(;Date.now()-o<i;){try{const s=new AbortController,l=setTimeout(()=>s.abort(),n),r=await fetch(t,{method:"HEAD",mode:"no-cors",signal:s.signal}).catch(()=>null);if(clearTimeout(l),r)return!0}catch{}await new Promise(s=>setTimeout(s,n))}return!1}async startServer(t,i){var a,c;if(this.isRunning&&this.activePort)return{success:!0,port:this.activePort,url:`http://localhost:${this.activePort}?embedded=true`};const n=await this.allocPort(i);this.activePort=n;const s=Hn()==="win32"?"npx.cmd":"npx",l=Ts(t),r=["@slidev/cli",l,"--port",String(n),"--no-open"];try{if(this.customSpawner)this.childProcess=this.customSpawner(s,r,{detached:!1});else{let h=(a=Ct("child_process"))==null?void 0:a.spawn;if(!h){const m=await import("node:child_process").catch(()=>({}));h=m==null?void 0:m.spawn}if(!h)throw new Error("child_process spawn not available in current runtime");const v=l.includes("/")||l.includes("\\")?l.replace(/[/\\][^/\\]+$/,""):void 0,u=Ca();this.childProcess=h(s,r,{cwd:v,detached:!1,shell:!0,env:{...u,FORCE_COLOR:"1"}})}this.isRunning=!0,(c=this.childProcess)!=null&&c.on&&this.childProcess.on("exit",()=>{this.isRunning=!1,this.activePort=null,this.childProcess=null});const d=`http://localhost:${n}`;return!this.customSpawner&&!await this.pollServerReady(d,this.probeTimeoutMs)?(this.stopServer(),{success:!1,port:n,url:"",error:`Slidev DevServer 启动超时 (未在 ${this.probeTimeoutMs}ms 内响应端口 ${n})`}):{success:!0,port:n,url:`${d}?embedded=true`}}catch(d){return this.stopServer(),{success:!1,port:n,url:"",error:`唤起 Slidev 进程失败: ${String(d)}`}}}stopServer(){var t;if(this.childProcess){try{if(this.childProcess.kill("SIGTERM"),Hn()==="win32"&&this.childProcess.pid&&!this.customSpawner){const n=(t=Ct("child_process"))==null?void 0:t.exec;n?n(`taskkill /pid ${this.childProcess.pid} /T /F`,()=>{}):import("node:child_process").then(({exec:o})=>{var s;o(`taskkill /pid ${(s=this.childProcess)==null?void 0:s.pid} /T /F`,()=>{})}).catch(()=>{})}}catch{}this.childProcess=null}this.isRunning=!1,this.activePort=null}}class Wo{constructor(){ke(this,"iframe",null);ke(this,"isReady",!1);ke(this,"pendingMessages",[]);ke(this,"slideChangedHandlers",[]);ke(this,"blockClickedHandlers",[]);ke(this,"openInEditorHandlers",[]);ke(this,"clientReadyHandlers",[]);ke(this,"openPeekDrawerHandlers",[]);ke(this,"toggleFullscreenHandlers",[]);ke(this,"openPresenterHandlers",[]);this.handleWindowMessage=this.handleWindowMessage.bind(this)}attach(t){this.detach(),this.iframe=t,this.isReady=!1,typeof window<"u"&&window.addEventListener("message",this.handleWindowMessage)}detach(){typeof window<"u"&&window.removeEventListener("message",this.handleWindowMessage),this.iframe=null,this.isReady=!1,this.pendingMessages=[]}postMessage(t,i){var o;const n={source:"siyuan-slidev-host",action:t,payload:i};if(!((o=this.iframe)!=null&&o.contentWindow)||!this.isReady){this.pendingMessages.push(n);return}try{this.iframe.contentWindow.postMessage(n,"*")}catch(s){console.warn("[WebSandboxBridge] postMessage error:",s)}}updateSlides(t,i,n,o){this.postMessage("UPDATE_SLIDES",{slides:t,config:i,fullMarkdown:n,customThemeCss:o})}navigatePage(t){this.postMessage("NAVIGATE_PAGE",{pageIndex:t})}highlightElement(t){this.postMessage("HIGHLIGHT_ELEMENT",{targetBlockId:t})}nextStep(){this.postMessage("NEXT_STEP",{})}prevStep(){this.postMessage("PREV_STEP",{})}freezeKeyboardNav(t){this.postMessage("FREEZE_KEYBOARD_NAV",{frozen:t})}toggleOverview(){this.postMessage("TOGGLE_OVERVIEW",{})}onSlideChanged(t){return this.slideChangedHandlers.push(t),()=>{this.slideChangedHandlers=this.slideChangedHandlers.filter(i=>i!==t)}}onBlockClicked(t){return this.blockClickedHandlers.push(t),()=>{this.blockClickedHandlers=this.blockClickedHandlers.filter(i=>i!==t)}}onOpenInEditor(t){return this.openInEditorHandlers.push(t),()=>{this.openInEditorHandlers=this.openInEditorHandlers.filter(i=>i!==t)}}onOpenPeekDrawer(t){return this.openPeekDrawerHandlers.push(t),()=>{this.openPeekDrawerHandlers=this.openPeekDrawerHandlers.filter(i=>i!==t)}}onRequestToggleFullscreen(t){return this.toggleFullscreenHandlers.push(t),()=>{this.toggleFullscreenHandlers=this.toggleFullscreenHandlers.filter(i=>i!==t)}}onOpenPresenter(t){return this.openPresenterHandlers.push(t),()=>{this.openPresenterHandlers=this.openPresenterHandlers.filter(i=>i!==t)}}onClientReady(t){return this.clientReadyHandlers.push(t),()=>{this.clientReadyHandlers=this.clientReadyHandlers.filter(i=>i!==t)}}handleWindowMessage(t){var n;const i=t.data;if(!(!i||i.source!=="siyuan-slidev-client"))switch(i.action){case"CLIENT_READY":for(this.isReady=!0;this.pendingMessages.length>0;){const o=this.pendingMessages.shift();o&&((n=this.iframe)!=null&&n.contentWindow)&&this.iframe.contentWindow.postMessage(o,"*")}for(const o of this.clientReadyHandlers)o();break;case"SLIDE_CHANGED":if(i.payload.currentPage!==void 0)for(const o of this.slideChangedHandlers)o(i.payload.currentPage,i.payload.totalPages||1,i.payload.currentBlockId||"");break;case"BLOCK_CLICKED":if(i.payload.clickedBlockId)for(const o of this.blockClickedHandlers)o(i.payload.clickedBlockId,i.payload.currentPage||1);break;case"OPEN_IN_EDITOR":if(i.payload.blockId||i.payload.clickedBlockId){const o=i.payload.blockId||i.payload.clickedBlockId||"";for(const s of this.openInEditorHandlers)s(o,i.payload.currentPage||1)}break;case"OPEN_PEEK_DRAWER":if(i.payload.peekType){const o=i.payload.blockId||i.payload.url||"",s={peekType:i.payload.peekType,target:o,title:i.payload.title};for(const l of this.openPeekDrawerHandlers)l(s)}break;case"REQUEST_TOGGLE_FULLSCREEN":for(const o of this.toggleFullscreenHandlers)o();break;case"OPEN_PRESENTER":for(const o of this.openPresenterHandlers)o();break}}}const $a={"snippets/external.ts":`// Inside ./snippets/external.ts
// #region snippet
export function emptyArray<T>(length: number) {
  return Array.from<T>({ length })
}
// #endregion snippet

export function sayHello() {
  console.log('Hello from snippets/external.ts')
}
`},Gf=`<script setup lang="ts">
import { computed, useSlots } from 'vue'

const props = defineProps({
  layoutRatio: {
    type: String,
    default: '',
  },
  cols: {
    type: [Number, String],
    default: 0,
  },
})

const slots = useSlots()

const detectedColsCount = computed(() => {
  const explicitCols = Number(props.cols)
  if (explicitCols >= 2 && explicitCols <= 6) return explicitCols
  const r = (props.layoutRatio || '').trim()
  if (r.includes(':')) {
    const parts = r.split(':').map(p => parseFloat(p.trim())).filter(n => !isNaN(n) && n > 0)
    if (parts.length >= 2) return Math.min(parts.length, 6)
  }
  const tokens = r.split(/\\s+/).filter(Boolean)
  if (tokens.length >= 2) return Math.min(tokens.length, 6)
  for (let i = 6; i >= 3; i--) {
    if (slots[\`col-\${i}\`]) return i
  }
  if (slots['col-2'] || slots['right']) return 2
  return 2
})

const gridStyle = computed(() => {
  const r = props.layoutRatio || ''
  if (r) {
    if (r.includes(':')) {
      const parts = r.split(':').map(p => parseFloat(p.trim())).filter(n => !isNaN(n) && n > 0)
      if (parts.length >= 2) {
        return { gridTemplateColumns: parts.map(n => \`\${n}fr\`).join(' ') }
      }
    }
    const tokens = r.split(/\\s+/).filter(Boolean)
    if (tokens.length >= 2) {
      return { gridTemplateColumns: tokens.join(' ') }
    }
  }
  return { gridTemplateColumns: \`repeat(\${detectedColsCount.value}, minmax(0, 1fr))\` }
})
<\/script>

<template>
  <div class="slidev-layout cols-header w-full h-full flex flex-col">
    <div class="header-section mb-4 w-full">
      <slot />
    </div>
    <div class="grid gap-6 flex-1 items-stretch" :style="gridStyle">
      <div v-if="detectedColsCount >= 1" class="col-1 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-1"><slot name="left" /></slot>
      </div>
      <div v-if="detectedColsCount >= 2" class="col-2 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-2"><slot v-if="detectedColsCount === 2" name="right" /></slot>
      </div>
      <div v-if="detectedColsCount >= 3" class="col-3 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-3" />
      </div>
      <div v-if="detectedColsCount >= 4" class="col-4 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-4" />
      </div>
      <div v-if="detectedColsCount >= 5" class="col-5 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-5" />
      </div>
      <div v-if="detectedColsCount >= 6" class="col-6 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-6" />
      </div>
    </div>
  </div>
</template>
`,qf=`<script setup lang="ts">
import { computed } from 'vue'

const props = defineProps({
  layoutRatio: {
    type: String,
    default: '',
  },
})

const gridStyle = computed(() => {
  const r = props.layoutRatio || ''
  if (!r) return {}
  if (r.includes(':')) {
    const parts = r.split(':').map(p => parseFloat(p.trim())).filter(n => !isNaN(n) && n > 0)
    if (parts.length >= 2) {
      return { gridTemplateColumns: parts.map(n => \`\${n}fr\`).join(' ') }
    }
  }
  const tokens = r.split(/\\s+/).filter(Boolean)
  if (tokens.length >= 2) {
    return { gridTemplateColumns: tokens.join(' ') }
  }
  return {}
})
<\/script>

<template>
  <div class="slidev-layout three-cols-header w-full h-full flex flex-col">
    <div class="header-section mb-4 w-full">
      <slot />
    </div>
    <div class="grid gap-6 flex-1 items-stretch" :class="gridStyle.gridTemplateColumns ? '' : 'grid-cols-3'" :style="gridStyle">
      <div class="col-1 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-1" />
      </div>
      <div class="col-2 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-2" />
      </div>
      <div class="col-3 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-3" />
      </div>
    </div>
  </div>
</template>
`,Zf=`<script setup lang="ts">
import { useSlots } from 'vue'

const slots = useSlots()
<\/script>

<template>
  <div class="slidev-layout clover w-full h-full flex flex-col">
    <div class="header-section mb-4 w-full">
      <slot />
    </div>
    <div class="grid grid-cols-2 grid-rows-2 gap-6 flex-1 items-stretch">
      <div class="col-1 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-1" />
      </div>
      <div class="col-2 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-2" />
      </div>
      <div class="col-3 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-3" />
      </div>
      <div class="col-4 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-4" />
      </div>
    </div>
  </div>
</template>
`,Yf=`// Auto-generated by SiYuan Slidev Studio
// 本地 HTML 链接（思源资产 / 工作区文件 / 绝对文件路径）速览判定
// 注意：需与 public/slidev-client/index.html 中的拦截器保持同步
function isPeekableLocalHtml(href: string): boolean {
  const clean = (href || '').trim()
  if (!clean || clean.startsWith('#') || clean.startsWith('//')) return false
  if (!/\\.html?($|[?#])/i.test(clean)) return false
  if (/^https?:\\/\\//i.test(clean)) return false
  const scheme = /^([a-z][a-z0-9+.-]*):/i.exec(clean)
  if (!scheme) return true
  const schemeName = scheme[1].toLowerCase()
  if (schemeName === 'file') return true
  // Windows 盘符路径（D:\\\\docs\\\\demo.html）并非协议前缀
  return schemeName.length === 1 && /^[a-zA-Z]:[\\\\/]/.test(clean)
}

// 本地 HTML 链接预处理：思源资产统一指向内核 /assets/ 静态服务，其余原样转交宿主归一化
// 不基于 location 绝对化，保证 Pro 模式（Slidev dev server）与沙箱模式行为完全一致
function resolvePeekHref(href: string): string {
  const clean = (href || '').trim()
  if (/^(?:\\.\\/|\\/)?assets\\//.test(clean)) {
    return '/' + clean.replace(/^(?:\\.\\/|\\/)/, '')
  }
  return clean
}

export default function() {
  if (typeof window === 'undefined') return
  window.addEventListener('click', (e: MouseEvent) => {
    const target = e.target as HTMLElement | null
    if (!target || !target.closest) return

    const refEl = target.closest('[data-ref-id]')
    if (refEl) {
      const blockId = refEl.getAttribute('data-ref-id')
      if (blockId) {
        e.preventDefault()
        e.stopPropagation()
        window.parent.postMessage({
          source: 'siyuan-slidev-client',
          action: 'OPEN_PEEK_DRAWER',
          payload: { peekType: 'siyuan', blockId, title: (refEl.innerText || refEl.title || '').trim() }
        }, '*')
        return
      }
    }

    const linkEl = target.closest('a') as HTMLAnchorElement | null
    if (linkEl) {
      const href = linkEl.getAttribute('href') || ''
      if (href.startsWith('siyuan://blocks/')) {
        e.preventDefault()
        e.stopPropagation()
        const cleanBlockId = href.replace('siyuan://blocks/', '').split('?')[0]
        window.parent.postMessage({
          source: 'siyuan-slidev-client',
          action: 'OPEN_PEEK_DRAWER',
          payload: { peekType: 'siyuan', blockId: cleanBlockId, title: (linkEl.innerText || linkEl.title || '').trim() }
        }, '*')
      } else if (/^https?:\\/\\//i.test(href)) {
        e.preventDefault()
        e.stopPropagation()
        window.parent.postMessage({
          source: 'siyuan-slidev-client',
          action: 'OPEN_PEEK_DRAWER',
          payload: { peekType: 'web', url: href, title: (linkEl.innerText || linkEl.title || '').trim() }
        }, '*')
      } else if (isPeekableLocalHtml(href)) {
        e.preventDefault()
        e.stopPropagation()
        window.parent.postMessage({
          source: 'siyuan-slidev-client',
          action: 'OPEN_PEEK_DRAWER',
          payload: { peekType: 'web', url: resolvePeekHref(href), title: (linkEl.innerText || linkEl.title || '').trim() }
        }, '*')
      }
    }
  }, true)
}
`,Jf=`${$s}

/* Auto-generated by SiYuan Slidev Studio */
.slidev-ref-tag,
a.slidev-ref-tag {
  display: inline-flex;
  align-items: center;
  background: color-mix(in srgb, var(--slidev-theme-primary, #10b981) 12%, transparent);
  color: var(--slidev-theme-primary, #10b981);
  border-radius: 4px;
  padding: 2px 8px;
  font-size: 0.88em;
  text-decoration: none;
  border: 1px solid color-mix(in srgb, var(--slidev-theme-primary, #10b981) 25%, transparent);
  cursor: pointer;
  transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
  user-select: none;
}

.slidev-ref-tag:hover,
a.slidev-ref-tag:hover {
  background: color-mix(in srgb, var(--slidev-theme-primary, #10b981) 22%, transparent);
  color: var(--slidev-theme-primary, #10b981);
  border-color: color-mix(in srgb, var(--slidev-theme-primary, #10b981) 55%, transparent);
  transform: translateY(-1px);
  box-shadow: 0 2px 8px color-mix(in srgb, var(--slidev-theme-primary, #10b981) 20%, transparent);
}

.slidev-block-ref {
  display: block;
  padding: 10px 14px;
  background: color-mix(in srgb, var(--slidev-theme-primary, #10b981) 8%, transparent);
  border-left: 3px solid var(--slidev-theme-primary, #10b981);
  border-radius: 0 6px 6px 0;
  margin: 8px 0;
  cursor: pointer;
  transition: background 0.2s ease;
}

.slidev-block-ref:hover {
  background: color-mix(in srgb, var(--slidev-theme-primary, #10b981) 15%, transparent);
}

/* 代码块自动换行与无横向滚动条 */
pre,
pre code {
  white-space: pre-wrap !important;
  word-break: break-all !important;
  overflow-wrap: anywhere !important;
  overflow-x: hidden !important;
  overflow-y: auto !important;
  max-width: 100% !important;
  box-sizing: border-box !important;
}

/* 弱提示滚动条样式 */
* {
  scrollbar-width: thin;
}
html:not(.dark) * {
  scrollbar-color: rgba(0, 0, 0, 0.15) transparent;
}
html.dark * {
  scrollbar-color: rgba(255, 255, 255, 0.20) transparent;
}
*::-webkit-scrollbar {
  width: 4px;
  height: 4px;
}
*::-webkit-scrollbar-track {
  background: transparent;
}
html:not(.dark) *::-webkit-scrollbar-thumb {
  background: rgba(0, 0, 0, 0.15);
  border-radius: 2px;
}
html:not(.dark) *:hover::-webkit-scrollbar-thumb,
html:not(.dark) *::-webkit-scrollbar-thumb:hover {
  background: rgba(0, 0, 0, 0.35);
}
html.dark *::-webkit-scrollbar-thumb {
  background: rgba(255, 255, 255, 0.20);
  border-radius: 2px;
}
html.dark *:hover::-webkit-scrollbar-thumb,
html.dark *::-webkit-scrollbar-thumb:hover {
  background: rgba(255, 255, 255, 0.45);
}

/* 多媒体（GIF动图、静态图片、MP4视频）最大化自适应且不超出视口：顶部对齐，横向居中 */
.slidev-layout img,
.slidev-layout video {
  max-width: 100% !important;
  max-height: 100% !important;
  width: auto;
  height: auto;
  object-fit: contain !important;
}
.three-cols-header video,
.two-cols-header video,
.grid-cols-3 video,
.grid-cols-2 video,
.col-1 video,
.col-2 video,
.col-3 video {
  width: auto !important;
  height: auto !important;
  max-width: 100% !important;
  max-height: 100% !important;
  object-fit: contain !important;
  display: block !important;
  margin: 0 auto !important;
}
.slide-list-media {
  display: flex !important;
  flex-direction: column !important;
  align-items: center !important;
  justify-content: flex-start !important;
  margin-top: 4px !important;
  margin-bottom: 4px !important;
  width: 100% !important;
  max-width: 100% !important;
  height: 100% !important;
  max-height: 100% !important;
  flex: 1 1 0% !important;
  overflow: hidden !important;
}
.slide-list-media img,
.slide-list-media video,
.slide-list-media .list-item-gif {
  width: auto !important;
  height: auto !important;
  max-width: 100% !important;
  max-height: 100% !important;
  object-fit: contain !important;
  border-radius: 6px !important;
  box-shadow: 0 3px 12px rgba(0, 0, 0, 0.14) !important;
  display: block !important;
  margin: 0 auto !important;
}
.slide-video-container {
  display: flex !important;
  flex-direction: column !important;
  justify-content: flex-start !important;
  align-items: center !important;
  width: 100% !important;
  max-height: 100% !important;
  margin: 6px 0 !important;
}
.slide-video-player {
  max-width: 100% !important;
  max-height: 100% !important;
  object-fit: contain !important;
  border-radius: 8px !important;
}

/* 两栏与多栏（超级块分栏）布局：紧凑自然行距，子列表保留圆点与层级缩进 */
.cols-header ul,
.three-cols-header ul,
.two-cols-header ul,
.two-cols ul,
.col-1 ul,
.col-2 ul,
.col-3 ul,
.col-4 ul,
.col-5 ul,
.col-6 ul,
.grid-cols-2 ul,
.grid-cols-3 ul {
  list-style: disc !important;
  list-style-type: disc !important;
  padding-left: 1.25em !important;
  margin-left: 0 !important;
  margin-top: 0 !important;
  margin-bottom: 8px !important;
  flex: 0 0 auto !important;
  height: auto !important;
  display: block !important;
}
.cols-header ol,
.three-cols-header ol,
.two-cols-header ol,
.two-cols ol,
.col-1 ol,
.col-2 ol,
.col-3 ol,
.col-4 ol,
.col-5 ol,
.col-6 ol,
.grid-cols-2 ol,
.grid-cols-3 ol {
  list-style: decimal !important;
  list-style-type: decimal !important;
  padding-left: 1.25em !important;
  margin-left: 0 !important;
  margin-top: 0 !important;
  margin-bottom: 8px !important;
  flex: 0 0 auto !important;
  height: auto !important;
  display: block !important;
}
.cols-header li,
.three-cols-header li,
.two-cols-header li,
.two-cols li,
.col-1 li,
.col-2 li,
.col-3 li,
.col-4 li,
.col-5 li,
.col-6 li,
.grid-cols-2 li,
.grid-cols-3 li {
  padding-left: 0.2em !important;
  margin-left: 0 !important;
  margin-bottom: 6px !important;
  flex: 0 0 auto !important;
  height: auto !important;
  display: list-item !important;
  line-height: 1.6 !important;
}
.cols-header ul ul,
.three-cols-header ul ul,
.two-cols-header ul ul,
.two-cols ul ul,
.col-1 ul ul,
.col-2 ul ul,
.col-3 ul ul,
.col-4 ul ul,
.col-5 ul ul,
.col-6 ul ul {
  list-style: circle !important;
  list-style-type: circle !important;
  padding-left: 1.25em !important;
  margin-top: 4px !important;
  margin-bottom: 4px !important;
}

/* 列表项内嵌标题与说明排版 */
.slide-list-item-title,
li > h1,
li > h2,
li > h3,
li > h4,
li > h5,
li > h6 {
  margin-top: 2px !important;
  margin-bottom: 6px !important;
  line-height: 1.35 !important;
  font-weight: 700 !important;
}
li > h1 { font-size: 1.6rem !important; }
li > h2 { font-size: 1.4rem !important; }
li > h3 { font-size: 1.22rem !important; }
li > h4 { font-size: 1.1rem !important; }
.slide-list-item-desc,
li > p {
  margin-top: 4px !important;
  margin-bottom: 6px !important;
  font-size: 1.05rem;
  line-height: 1.55;
  opacity: 0.92;
}
`;function Xf(e){var o;const t=[],i=/^[ \t]*<<<[ \t]+(?:@\/|\.\/|)([^\s#]+)(?:#[^\s]+)?/gm;let n;for(;(n=i.exec(e))!==null;){const s=(o=n[1])==null?void 0:o.trim();s&&!t.includes(s)&&t.push(s)}return t}class Qf{constructor(t){ke(this,"workspacePath");ke(this,"slidesFileName");ke(this,"cliBridge",new Qs);const i=Uf();!(t!=null&&t.workspacePath)||t.workspacePath.includes("/data/storage/petal/siyuan-slidev/pro-workspace")?this.workspacePath=i:this.workspacePath=t.workspacePath,this.slidesFileName=(t==null?void 0:t.slidesFileName)||"slides.md"}getWorkspacePath(){return this.workspacePath}getSlidesPath(){return`${this.workspacePath}/${this.slidesFileName}`}generatePackageJson(t="default"){const i={name:"siyuan-slidev-pro-workspace",type:"module",private:!0,scripts:{dev:"slidev --port 3030",build:"slidev build"},dependencies:{"@slidev/cli":"^53.0.0","@slidev/theme-default":"latest"}};return t&&t!=="default"&&(i.dependencies[`@slidev/theme-${t}`]="latest"),JSON.stringify(i,null,2)}buildSlidesMarkdown(t){return this.cliBridge.buildStandardSlidevMarkdown(t)}async scaffold(t,i){const n=this.buildSlidesMarkdown(t),o=this.generatePackageJson(t.config.theme),s=this.getSlidesPath(),l=`${this.workspacePath}/package.json`,r=Ts(s),a=Ts(l),c=Xf(n);c.includes("snippets/external.ts")||c.push("snippets/external.ts");const d=new Map;for(const C of c){const A=$a[C]||`// Auto-generated snippet placeholder for SiYuan Slidev
// #region snippet
// ${C}
// #endregion snippet
`;d.set(C,A)}t.slides.some(C=>{var A;return((A=C.frontmatter)==null?void 0:A.layout)==="cols-header"})&&d.set("layouts/cols-header.vue",Gf),t.slides.some(C=>{var A;return((A=C.frontmatter)==null?void 0:A.layout)==="three-cols-header"})&&d.set("layouts/three-cols-header.vue",qf),t.slides.some(C=>{var A;return((A=C.frontmatter)==null?void 0:A.layout)==="clover"})&&d.set("layouts/clover.vue",Zf),d.set("setup/root.ts",Yf),d.set("styles/index.css",Jf);const m=Ct("fs"),f=Ct("path");let b=!1;const k=f!=null&&f.dirname?f.dirname(r):"",x=/^[a-zA-Z]:[/\\]/.test(r)||r.includes("siyuan-slidev-pro");if(m&&f&&x)try{m.existsSync(k)||m.mkdirSync(k,{recursive:!0}),m.writeFileSync(a,o,"utf-8"),m.writeFileSync(r,n,"utf-8");for(const[C,A]of d.entries()){const D=f.join(k,C),T=f.dirname(D);m.existsSync(T)||m.mkdirSync(T,{recursive:!0}),m.existsSync(D)||m.writeFileSync(D,A,"utf-8")}b=!0}catch{}if(!b&&i)try{const C=typeof Blob<"u"?new Blob([n],{type:"text/markdown;charset=utf-8"}):Buffer.from(n,"utf-8"),A=typeof Blob<"u"?new Blob([o],{type:"application/json;charset=utf-8"}):Buffer.from(o,"utf-8");await i(l,!1,A),await i(s,!1,C);for(const[D,T]of d.entries()){const w=`${this.workspacePath}/${D}`,R=typeof Blob<"u"?new Blob([T],{type:"text/plain;charset=utf-8"}):Buffer.from(T,"utf-8");await i(w,!1,R).catch(()=>{})}return{success:!0,slidesPath:s,physicalSlidesPath:r,packageJsonPath:l}}catch(C){return{success:!1,slidesPath:s,physicalSlidesPath:r,packageJsonPath:l,error:String(C)}}return{success:!0,slidesPath:s,physicalSlidesPath:r,packageJsonPath:l}}}class ep{constructor(){ke(this,"mode","web-sandbox");ke(this,"webBridge");ke(this,"cliBridge");ke(this,"nativeBridge");ke(this,"processManager");ke(this,"scaffolder");ke(this,"envDetector");this.webBridge=new Wo,this.cliBridge=new Qs,this.nativeBridge=new Vf,this.processManager=new Kf,this.scaffolder=new Qf,this.envDetector=new tr}getMode(){return this.mode}setMode(t){this.mode=t}async startProMode(t,i){if(!(await this.envDetector.detect()).hasNode)return{success:!1,url:"",error:"当前系统未检测到 Node.js 环境，无法拉起官方 Slidev CLI，建议继续使用内置高保真引擎"};const o=await this.scaffolder.scaffold(t,i);if(!o.success)return{success:!1,url:"",error:`初始化 Slidev 临时工作空间失败: ${o.error}`};const s=o.physicalSlidesPath||o.slidesPath,l=await this.processManager.startServer(s);return l.success?(this.mode="pro-cli",{success:!0,url:l.url,port:l.port}):{success:!1,url:"",error:l.error}}stopProMode(){this.processManager.stopServer(),this.mode="web-sandbox"}destroy(){this.webBridge.detach(),this.nativeBridge.detach(),this.processManager.stopServer()}}const tp={class:"slidev-icon",style:{fill:"none !important"},viewBox:"0 0 24 24",stroke:"currentColor","stroke-width":"1.75","stroke-linecap":"round","stroke-linejoin":"round","aria-hidden":"true"},ip={key:0},np={key:1},op={key:2},sp={key:3},rp={key:4},lp={key:5},ap={key:6},cp={key:7},dp={key:8},up={key:9},fp={key:10},pp={key:11},hp={key:12},mp={key:13},gp={key:14},vp={key:15},bp={key:16},yp={key:17},kp={key:18},wp={key:19},xp={key:20},Sp={key:21},_p={key:22},Cp={key:23},$p={key:24},Ip={key:25},Tp={key:26},Ep={key:27},Ap={key:28},Bp={key:29},Mp={key:30},Dp={key:31},Lp={key:32},Op={key:33},Pp={key:34},Rp={key:35},Np={key:36},zp={key:37},Fp={key:38},Hp={key:39},jp={key:40},Wp={key:41},Up={key:42},Vp={key:43},Kp={key:44},Gp={key:45},qp={key:46},Zp={key:47},Yp={key:48},Jp={key:49},Xp={key:50},Qp={key:51},eh={key:52},th={key:53},ih={key:54},nh={key:55},oh={key:56},sh={key:57},rh={key:58},lh={key:59},ah={key:60},ch={key:61},dh={key:62},uh={key:63},fh={key:64},ph={key:65},hh={key:66},mh=xt({__name:"SlidevIcon",props:{name:{}},setup(e){return(t,i)=>(Q(),te("svg",tp,[e.name==="fullscreen"||e.name==="maximize"?(Q(),te("g",ip,[...i[0]||(i[0]=[p("polyline",{points:"15 3 21 3 21 9"},null,-1),p("polyline",{points:"9 21 3 21 3 15"},null,-1),p("polyline",{points:"21 15 21 21 15 21"},null,-1),p("polyline",{points:"3 9 3 3 9 3"},null,-1)])])):e.name==="minimize"?(Q(),te("g",np,[...i[1]||(i[1]=[p("polyline",{points:"4 14 10 14 10 20"},null,-1),p("polyline",{points:"20 10 14 10 14 4"},null,-1),p("line",{x1:"14",y1:"10",x2:"21",y2:"3"},null,-1),p("line",{x1:"3",y1:"21",x2:"10",y2:"14"},null,-1)])])):e.name==="close"||e.name==="x"?(Q(),te("g",op,[...i[2]||(i[2]=[p("line",{x1:"18",y1:"6",x2:"6",y2:"18"},null,-1),p("line",{x1:"6",y1:"6",x2:"18",y2:"18"},null,-1)])])):e.name==="edit"?(Q(),te("g",sp,[...i[3]||(i[3]=[p("path",{d:"M12 20h9"},null,-1),p("path",{d:"M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z"},null,-1)])])):e.name==="eye"?(Q(),te("g",rp,[...i[4]||(i[4]=[p("path",{d:"M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"},null,-1),p("circle",{cx:"12",cy:"12",r:"3"},null,-1)])])):e.name==="external-link"||e.name==="window"?(Q(),te("g",lp,[...i[5]||(i[5]=[p("path",{d:"M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"},null,-1),p("polyline",{points:"15 3 21 3 21 9"},null,-1),p("line",{x1:"10",y1:"14",x2:"21",y2:"3"},null,-1)])])):e.name==="arrow-left"?(Q(),te("g",ap,[...i[6]||(i[6]=[p("line",{x1:"19",y1:"12",x2:"5",y2:"12"},null,-1),p("polyline",{points:"12 19 5 12 12 5"},null,-1)])])):e.name==="arrow-right"?(Q(),te("g",cp,[...i[7]||(i[7]=[p("line",{x1:"5",y1:"12",x2:"19",y2:"12"},null,-1),p("polyline",{points:"12 5 19 12 12 19"},null,-1)])])):e.name==="plus"?(Q(),te("g",dp,[...i[8]||(i[8]=[p("line",{x1:"12",y1:"5",x2:"12",y2:"19"},null,-1),p("line",{x1:"5",y1:"12",x2:"19",y2:"12"},null,-1)])])):e.name==="minus"?(Q(),te("g",up,[...i[9]||(i[9]=[p("line",{x1:"5",y1:"12",x2:"19",y2:"12"},null,-1)])])):e.name==="split-preview"?(Q(),te("g",fp,[...i[10]||(i[10]=[p("rect",{x:"3",y:"3",width:"18",height:"18",rx:"2"},null,-1),p("path",{d:"M12 3v18"},null,-1)])])):e.name==="import"?(Q(),te("g",pp,[...i[11]||(i[11]=[p("path",{d:"M4 17v2a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-2"},null,-1),p("polyline",{points:"7 9 12 14 17 9"},null,-1),p("line",{x1:"12",y1:"14",x2:"12",y2:"3"},null,-1)])])):e.name==="presenter"?(Q(),te("g",hp,[...i[12]||(i[12]=[p("path",{d:"M2 3h20"},null,-1),p("path",{d:"M21 3v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V3"},null,-1),p("path",{d:"m7 21 5-5 5 5"},null,-1)])])):e.name==="video"?(Q(),te("g",mp,[...i[13]||(i[13]=[p("polygon",{points:"23 7 16 12 23 17 23 7"},null,-1),p("rect",{x:"1",y:"5",width:"15",height:"14",rx:"2",ry:"2"},null,-1)])])):e.name==="step"?(Q(),te("g",gp,[...i[14]||(i[14]=[p("polygon",{points:"13 2 3 14 12 14 11 22 21 10 12 10 13 2"},null,-1)])])):e.name==="motion"?(Q(),te("g",vp,[...i[15]||(i[15]=[p("path",{d:"M5 12h14"},null,-1),p("path",{d:"m12 5 7 7-7 7"},null,-1),p("path",{d:"M5 6h4"},null,-1),p("path",{d:"M5 18h4"},null,-1)])])):e.name==="columns"?(Q(),te("g",bp,[...i[16]||(i[16]=[p("rect",{x:"3",y:"3",width:"7",height:"18",rx:"1"},null,-1),p("rect",{x:"14",y:"3",width:"7",height:"18",rx:"1"},null,-1)])])):e.name==="code"?(Q(),te("g",yp,[...i[17]||(i[17]=[p("polyline",{points:"16 18 22 12 16 6"},null,-1),p("polyline",{points:"8 6 2 12 8 18"},null,-1)])])):e.name==="insert-above"?(Q(),te("g",kp,[...i[18]||(i[18]=[p("line",{x1:"12",y1:"5",x2:"12",y2:"13"},null,-1),p("line",{x1:"8",y1:"9",x2:"16",y2:"9"},null,-1),p("path",{d:"M4 19h16","stroke-dasharray":"2 2"},null,-1)])])):e.name==="insert-below"?(Q(),te("g",wp,[...i[19]||(i[19]=[p("path",{d:"M4 5h16","stroke-dasharray":"2 2"},null,-1),p("line",{x1:"12",y1:"11",x2:"12",y2:"19"},null,-1),p("line",{x1:"8",y1:"15",x2:"16",y2:"15"},null,-1)])])):e.name==="broom"?(Q(),te("g",xp,[...i[20]||(i[20]=[p("path",{d:"m18 15-6-6"},null,-1),p("path",{d:"M4 20h16"},null,-1),p("path",{d:"M6 14l8-8a2.8 2.8 0 0 1 4 4l-8 8H6v-4z"},null,-1)])])):e.name==="trash"?(Q(),te("g",Sp,[...i[21]||(i[21]=[p("path",{d:"M3 6h18"},null,-1),p("path",{d:"M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"},null,-1),p("path",{d:"M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"},null,-1)])])):e.name==="ai"||e.name==="sparkles"?(Q(),te("g",_p,[...i[22]||(i[22]=[p("path",{d:"m12 3-1.9 5.8a2 2 0 0 1-1.3 1.3L3 12l5.8 1.9a2 2 0 0 1 1.3 1.3L12 21l1.9-5.8a2 2 0 0 1 1.3-1.3L21 12l-5.8-1.9a2 2 0 0 1-1.3-1.3L12 3z"},null,-1)])])):e.name==="palette"?(Q(),te("g",Cp,[...i[23]||(i[23]=[gt('<circle cx="13.5" cy="6.5" r=".5" fill="currentColor" data-v-57969535></circle><circle cx="17.5" cy="10.5" r=".5" fill="currentColor" data-v-57969535></circle><circle cx="8.5" cy="7.5" r=".5" fill="currentColor" data-v-57969535></circle><circle cx="6.5" cy="12.5" r=".5" fill="currentColor" data-v-57969535></circle><path d="M12 2C6.5 2 2 6.5 2 12s4.5 10 10 10c.9 0 1.5-.7 1.5-1.5 0-.4-.2-.8-.4-1.1-.3-.4-.4-.8-.4-1.4 0-1.1.9-2 2-2h2.3c3.9 0 7-3.1 7-7 0-5-4.5-9-10-9z" data-v-57969535></path>',5)])])):e.name==="ratio"?(Q(),te("g",$p,[...i[24]||(i[24]=[p("rect",{x:"2",y:"5",width:"20",height:"14",rx:"2"},null,-1),p("line",{x1:"2",y1:"10",x2:"22",y2:"10","stroke-dasharray":"2 2"},null,-1)])])):e.name==="transition"?(Q(),te("g",Ip,[...i[25]||(i[25]=[p("path",{d:"M8 3 4 7l4 4"},null,-1),p("path",{d:"M4 7h16"},null,-1),p("path",{d:"m16 21 4-4-4-4"},null,-1),p("path",{d:"M20 17H4"},null,-1)])])):e.name==="export-html"?(Q(),te("g",Tp,[...i[26]||(i[26]=[p("polyline",{points:"16 16 12 12 8 16"},null,-1),p("line",{x1:"12",y1:"12",x2:"12",y2:"21"},null,-1),p("path",{d:"M20.4 16.3A5 5 0 0 0 18 7h-1.3A8 8 0 0 0 4 12.8a5 5 0 0 0 1.5 9.2"},null,-1)])])):e.name==="export-pdf"?(Q(),te("g",Ep,[...i[27]||(i[27]=[p("polyline",{points:"6 9 6 2 18 2 18 9"},null,-1),p("path",{d:"M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"},null,-1),p("rect",{x:"6",y:"14",width:"12",height:"8"},null,-1)])])):e.name==="pin"?(Q(),te("g",Ap,[...i[28]||(i[28]=[p("line",{x1:"12",y1:"17",x2:"12",y2:"22"},null,-1),p("path",{d:"M5 17h14v-2l-2-2V5l1-1V2H6v2l1 1v8l-2 2v2z"},null,-1)])])):e.name==="refresh"?(Q(),te("g",Bp,[...i[29]||(i[29]=[p("path",{d:"M3 12a9 9 0 0 1 9-9 9.75 9.75 0 0 1 6.74 2.74L21 8"},null,-1),p("path",{d:"M21 3v5h-5"},null,-1),p("path",{d:"M21 12a9 9 0 0 1-9 9 9.75 9.75 0 0 1-6.74-2.74L3 16"},null,-1),p("path",{d:"M8 16H3v5"},null,-1)])])):e.name==="alert"||e.name==="warning"?(Q(),te("g",Mp,[...i[30]||(i[30]=[p("path",{d:"M10.29 3.86 1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"},null,-1),p("line",{x1:"12",y1:"9",x2:"12",y2:"13"},null,-1),p("line",{x1:"12",y1:"17",x2:"12.01",y2:"17"},null,-1)])])):e.name==="outline"?(Q(),te("g",Dp,[...i[31]||(i[31]=[p("line",{x1:"3",y1:"6",x2:"21",y2:"6"},null,-1),p("line",{x1:"3",y1:"12",x2:"21",y2:"12"},null,-1),p("line",{x1:"3",y1:"18",x2:"21",y2:"18"},null,-1)])])):e.name==="chevron-left"?(Q(),te("g",Lp,[...i[32]||(i[32]=[p("polyline",{points:"15 18 9 12 15 6"},null,-1)])])):e.name==="chevron-right"?(Q(),te("g",Op,[...i[33]||(i[33]=[p("polyline",{points:"9 18 15 12 9 6"},null,-1)])])):e.name==="copy"?(Q(),te("g",Pp,[...i[34]||(i[34]=[p("rect",{x:"9",y:"9",width:"13",height:"13",rx:"2",ry:"2"},null,-1),p("path",{d:"M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"},null,-1)])])):e.name==="image"?(Q(),te("g",Rp,[...i[35]||(i[35]=[p("rect",{x:"3",y:"3",width:"18",height:"18",rx:"2",ry:"2"},null,-1),p("circle",{cx:"8.5",cy:"8.5",r:"1.5"},null,-1),p("polyline",{points:"21 15 16 10 5 21"},null,-1)])])):e.name==="search"?(Q(),te("g",Np,[...i[36]||(i[36]=[p("circle",{cx:"11",cy:"11",r:"7"},null,-1),p("line",{x1:"21",y1:"21",x2:"16.65",y2:"16.65"},null,-1)])])):e.name==="settings"||e.name==="gear"?(Q(),te("g",zp,[...i[37]||(i[37]=[p("circle",{cx:"12",cy:"12",r:"3"},null,-1),p("path",{d:"M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 1 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 1 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 1 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 1 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"},null,-1)])])):e.name==="notes"||e.name==="file-text"?(Q(),te("g",Fp,[...i[38]||(i[38]=[gt('<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" data-v-57969535></path><polyline points="14 2 14 8 20 8" data-v-57969535></polyline><line x1="16" y1="13" x2="8" y2="13" data-v-57969535></line><line x1="16" y1="17" x2="8" y2="17" data-v-57969535></line><line x1="10" y1="9" x2="8" y2="9" data-v-57969535></line>',5)])])):e.name==="focus"||e.name==="target"?(Q(),te("g",Hp,[...i[39]||(i[39]=[p("circle",{cx:"12",cy:"12",r:"3",fill:"currentColor"},null,-1),p("path",{d:"M12 2v4M12 18v4M2 12h4M18 12h4",stroke:"currentColor","stroke-width":"2","stroke-linecap":"round"},null,-1),p("circle",{cx:"12",cy:"12",r:"7",fill:"none",stroke:"currentColor","stroke-width":"1.8"},null,-1)])])):e.name==="layout-cover"||e.name==="cover"?(Q(),te("g",jp,[...i[40]||(i[40]=[p("rect",{x:"2",y:"4",width:"20",height:"16",rx:"2"},null,-1),p("line",{x1:"9",y1:"8",x2:"15",y2:"8"},null,-1),p("line",{x1:"5.5",y1:"11.5",x2:"18.5",y2:"11.5"},null,-1),p("line",{x1:"7.5",y1:"15",x2:"16.5",y2:"15"},null,-1)])])):e.name==="layout-default"||e.name==="default"?(Q(),te("g",Wp,[...i[41]||(i[41]=[gt('<rect x="2" y="4" width="20" height="16" rx="2" data-v-57969535></rect><line x1="5" y1="8" x2="11.5" y2="8" data-v-57969535></line><line x1="5" y1="11.5" x2="19" y2="11.5" data-v-57969535></line><line x1="5" y1="14.5" x2="19" y2="14.5" data-v-57969535></line><line x1="5" y1="17.5" x2="13.5" y2="17.5" data-v-57969535></line>',5)])])):e.name==="layout-two-cols"||e.name==="two-cols"?(Q(),te("g",Up,[...i[42]||(i[42]=[gt('<rect x="2" y="4" width="20" height="16" rx="2" data-v-57969535></rect><line x1="12" y1="4" x2="12" y2="20" stroke-dasharray="2 1.5" data-v-57969535></line><line x1="5" y1="8" x2="9.5" y2="8" data-v-57969535></line><line x1="5" y1="11.5" x2="9.5" y2="11.5" data-v-57969535></line><line x1="5" y1="15" x2="8" y2="15" data-v-57969535></line><line x1="14.5" y1="8" x2="19" y2="8" data-v-57969535></line><line x1="14.5" y1="11.5" x2="19" y2="11.5" data-v-57969535></line><line x1="14.5" y1="15" x2="17.5" y2="15" data-v-57969535></line>',8)])])):e.name==="layout-two-cols-header"||e.name==="two-cols-header"?(Q(),te("g",Vp,[...i[43]||(i[43]=[gt('<rect x="2" y="4" width="20" height="16" rx="2" data-v-57969535></rect><line x1="5" y1="7.5" x2="13" y2="7.5" data-v-57969535></line><line x1="12" y1="10.5" x2="12" y2="18.5" stroke-dasharray="1.5 1.5" data-v-57969535></line><line x1="5" y1="12" x2="9.5" y2="12" data-v-57969535></line><line x1="5" y1="15.5" x2="8.5" y2="15.5" data-v-57969535></line><line x1="14.5" y1="12" x2="19" y2="12" data-v-57969535></line><line x1="14.5" y1="15.5" x2="18" y2="15.5" data-v-57969535></line>',7)])])):e.name==="layout-cols-header"||e.name==="cols-header"||e.name==="layout-three-cols-header"||e.name==="three-cols-header"?(Q(),te("g",Kp,[...i[44]||(i[44]=[gt('<rect x="2" y="4" width="20" height="16" rx="2" data-v-57969535></rect><line x1="5" y1="7.5" x2="13" y2="7.5" data-v-57969535></line><line x1="9.3" y1="10.5" x2="9.3" y2="18.5" stroke-dasharray="1.5 1.5" data-v-57969535></line><line x1="14.7" y1="10.5" x2="14.7" y2="18.5" stroke-dasharray="1.5 1.5" data-v-57969535></line><line x1="4.5" y1="12" x2="7.5" y2="12" data-v-57969535></line><line x1="4.5" y1="15.5" x2="7" y2="15.5" data-v-57969535></line><line x1="10.5" y1="12" x2="13.5" y2="12" data-v-57969535></line><line x1="10.5" y1="15.5" x2="13.5" y2="15.5" data-v-57969535></line><line x1="16" y1="12" x2="19.5" y2="12" data-v-57969535></line><line x1="16" y1="15.5" x2="18.5" y2="15.5" data-v-57969535></line>',10)])])):e.name==="layout-clover"||e.name==="clover"?(Q(),te("g",Gp,[...i[45]||(i[45]=[gt('<rect x="2" y="4" width="20" height="16" rx="2" data-v-57969535></rect><line x1="5" y1="7" x2="13" y2="7" data-v-57969535></line><line x1="4.5" y1="13.5" x2="19.5" y2="13.5" stroke-dasharray="1.5 1.5" data-v-57969535></line><line x1="12" y1="9" x2="12" y2="18.5" stroke-dasharray="1.5 1.5" data-v-57969535></line><line x1="5" y1="11" x2="9.5" y2="11" data-v-57969535></line><line x1="14.5" y1="11" x2="19" y2="11" data-v-57969535></line><line x1="5" y1="16" x2="9.5" y2="16" data-v-57969535></line><line x1="14.5" y1="16" x2="19" y2="16" data-v-57969535></line>',8)])])):e.name==="layout-image-right"||e.name==="image-right"?(Q(),te("g",qp,[...i[46]||(i[46]=[gt('<rect x="2" y="4" width="20" height="16" rx="2" data-v-57969535></rect><line x1="12" y1="4" x2="12" y2="20" data-v-57969535></line><line x1="4.5" y1="8" x2="9.5" y2="8" data-v-57969535></line><line x1="4.5" y1="11.5" x2="10" y2="11.5" data-v-57969535></line><line x1="4.5" y1="14.5" x2="8" y2="14.5" data-v-57969535></line><circle cx="15.5" cy="8.5" r="1.2" data-v-57969535></circle><polyline points="13 17 15.5 13 18 16 19.5 14" data-v-57969535></polyline>',7)])])):e.name==="layout-image-left"||e.name==="image-left"?(Q(),te("g",Zp,[...i[47]||(i[47]=[gt('<rect x="2" y="4" width="20" height="16" rx="2" data-v-57969535></rect><line x1="12" y1="4" x2="12" y2="20" data-v-57969535></line><circle cx="6" cy="8.5" r="1.2" data-v-57969535></circle><polyline points="3.5 17 6 13 8.5 16 10 14" data-v-57969535></polyline><line x1="14.5" y1="8" x2="19.5" y2="8" data-v-57969535></line><line x1="14.5" y1="11.5" x2="20" y2="11.5" data-v-57969535></line><line x1="14.5" y1="14.5" x2="18" y2="14.5" data-v-57969535></line>',7)])])):e.name==="layout-center"||e.name==="center"?(Q(),te("g",Yp,[...i[48]||(i[48]=[p("rect",{x:"2",y:"4",width:"20",height:"16",rx:"2"},null,-1),p("line",{x1:"6.5",y1:"9",x2:"17.5",y2:"9"},null,-1),p("line",{x1:"5",y1:"12",x2:"19",y2:"12"},null,-1),p("line",{x1:"8",y1:"15",x2:"16",y2:"15"},null,-1)])])):e.name==="layout-fact"||e.name==="fact"?(Q(),te("g",Jp,[...i[49]||(i[49]=[gt('<rect x="2" y="4" width="20" height="16" rx="2" data-v-57969535></rect><circle cx="8" cy="9" r="1.5" data-v-57969535></circle><line x1="14" y1="8" x2="9" y2="14" data-v-57969535></line><circle cx="15" cy="13" r="1.5" data-v-57969535></circle><line x1="6.5" y1="17" x2="17.5" y2="17" data-v-57969535></line>',5)])])):e.name==="layout-intro"||e.name==="intro"?(Q(),te("g",Xp,[...i[50]||(i[50]=[gt('<rect x="2" y="4" width="20" height="16" rx="2" data-v-57969535></rect><circle cx="7.5" cy="9.5" r="2" data-v-57969535></circle><path d="M4.5 16.5c0-1.8 1.3-3 3-3s3 1.2 3 3" data-v-57969535></path><line x1="13" y1="9" x2="18.5" y2="9" data-v-57969535></line><line x1="13" y1="12.5" x2="19.5" y2="12.5" data-v-57969535></line><line x1="13" y1="15.5" x2="17" y2="15.5" data-v-57969535></line>',6)])])):e.name==="layout-quote"||e.name==="quote"?(Q(),te("g",Qp,[...i[51]||(i[51]=[gt('<rect x="2" y="4" width="20" height="16" rx="2" data-v-57969535></rect><path d="M6 7.5h2v2H6.5c0 1.2-.4 2-1.5 2.5" data-v-57969535></path><path d="M9.5 7.5h2v2H10c0 1.2-.4 2-1.5 2.5" data-v-57969535></path><line x1="6" y1="13.5" x2="18" y2="13.5" data-v-57969535></line><line x1="12.5" y1="16.5" x2="17.5" y2="16.5" data-v-57969535></line>',5)])])):e.name==="desktop"||e.name==="monitor"?(Q(),te("g",eh,[...i[52]||(i[52]=[p("rect",{x:"2",y:"3",width:"20",height:"14",rx:"2"},null,-1),p("line",{x1:"8",y1:"21",x2:"16",y2:"21"},null,-1),p("line",{x1:"12",y1:"17",x2:"12",y2:"21"},null,-1)])])):e.name==="mobile"||e.name==="smartphone"||e.name==="phone"?(Q(),te("g",th,[...i[53]||(i[53]=[p("rect",{x:"5",y:"2",width:"14",height:"20",rx:"2",ry:"2"},null,-1),p("line",{x1:"12",y1:"18",x2:"12.01",y2:"18","stroke-width":"2","stroke-linecap":"round"},null,-1)])])):e.name==="type"||e.name==="heading"?(Q(),te("g",ih,[...i[54]||(i[54]=[p("polyline",{points:"4 7 4 4 20 4 20 7"},null,-1),p("line",{x1:"9",y1:"20",x2:"15",y2:"20"},null,-1),p("line",{x1:"12",y1:"4",x2:"12",y2:"20"},null,-1)])])):e.name==="reset"||e.name==="undo"?(Q(),te("g",nh,[...i[55]||(i[55]=[p("path",{d:"M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8"},null,-1),p("polyline",{points:"3 3 3 8 8 8"},null,-1)])])):e.name==="repeat"||e.name==="loop"?(Q(),te("g",oh,[...i[56]||(i[56]=[p("path",{d:"m17 1 4 4-4 4"},null,-1),p("path",{d:"M3 11V9a4 4 0 0 1 4-4h14"},null,-1),p("path",{d:"m7 23-4-4 4-4"},null,-1),p("path",{d:"M21 13v2a4 4 0 0 1-4 4H3"},null,-1)])])):e.name==="volume-x"||e.name==="mute"?(Q(),te("g",sh,[...i[57]||(i[57]=[p("polygon",{points:"11 5 6 9 2 9 2 15 6 15 11 19 11 5"},null,-1),p("line",{x1:"22",y1:"9",x2:"16",y2:"15"},null,-1),p("line",{x1:"16",y1:"9",x2:"22",y2:"15"},null,-1)])])):e.name==="sliders"||e.name==="controls"?(Q(),te("g",rh,[...i[58]||(i[58]=[gt('<line x1="4" y1="21" x2="4" y2="14" data-v-57969535></line><line x1="4" y1="10" x2="4" y2="3" data-v-57969535></line><line x1="12" y1="21" x2="12" y2="12" data-v-57969535></line><line x1="12" y1="8" x2="12" y2="3" data-v-57969535></line><line x1="20" y1="21" x2="20" y2="16" data-v-57969535></line><line x1="20" y1="12" x2="20" y2="3" data-v-57969535></line><line x1="1" y1="14" x2="7" y2="14" data-v-57969535></line><line x1="9" y1="8" x2="15" y2="8" data-v-57969535></line><line x1="17" y1="16" x2="23" y2="16" data-v-57969535></line>',9)])])):e.name==="package"||e.name==="zip"||e.name==="archive"?(Q(),te("g",lh,[...i[59]||(i[59]=[p("line",{x1:"16.5",y1:"9.4",x2:"7.5",y2:"4.21"},null,-1),p("path",{d:"M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"},null,-1),p("polyline",{points:"3.27 6.96 12 12.01 20.73 6.96"},null,-1),p("line",{x1:"12",y1:"22.08",x2:"12",y2:"12"},null,-1)])])):e.name==="folder"?(Q(),te("g",ah,[...i[60]||(i[60]=[p("path",{d:"M4 20h16a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2h-7.93a2 2 0 0 1-1.66-.9l-.82-1.2A2 2 0 0 0 7.93 3H4a2 2 0 0 0-2 2v13c0 1.1.9 2 2 2Z"},null,-1)])])):e.name==="rocket"?(Q(),te("g",ch,[...i[61]||(i[61]=[p("path",{d:"M4.5 16.5c-1.5 1.26-2 5-2 5s3.74-.5 5-2c.71-.84.7-2.13-.09-2.91a2.18 2.18 0 0 0-2.91-.09z"},null,-1),p("path",{d:"m12 15-3-3a22 22 0 0 1 2-3.95A12.88 12.88 0 0 1 22 2c0 2.72-.78 7.5-6 11a22.35 22.35 0 0 1-4 2z"},null,-1),p("path",{d:"M9 12H4s.55-3.03 2-4c1.62-1.08 5 0 5 0"},null,-1),p("path",{d:"M12 15v5s3.03-.55 4-2c1.08-1.62 0-5 0-5"},null,-1)])])):e.name==="wand"||e.name==="magic"?(Q(),te("g",dh,[...i[62]||(i[62]=[p("path",{d:"m19 2 2 2-6 6-2-2Z"},null,-1),p("path",{d:"m13 8 2 2"},null,-1),p("path",{d:"m3 21 9-9"},null,-1)])])):e.name==="image-left"?(Q(),te("g",uh,[...i[63]||(i[63]=[gt('<rect x="2" y="4" width="20" height="16" rx="2" data-v-57969535></rect><rect x="4" y="6" width="6" height="12" rx="1" data-v-57969535></rect><line x1="13" y1="8" x2="19" y2="8" data-v-57969535></line><line x1="13" y1="12" x2="19" y2="12" data-v-57969535></line><line x1="13" y1="16" x2="17" y2="16" data-v-57969535></line>',5)])])):e.name==="image-right"?(Q(),te("g",fh,[...i[64]||(i[64]=[gt('<rect x="2" y="4" width="20" height="16" rx="2" data-v-57969535></rect><rect x="14" y="6" width="6" height="12" rx="1" data-v-57969535></rect><line x1="5" y1="8" x2="11" y2="8" data-v-57969535></line><line x1="5" y1="12" x2="11" y2="12" data-v-57969535></line><line x1="5" y1="16" x2="9" y2="16" data-v-57969535></line>',5)])])):e.name==="help"||e.name==="question"||e.name==="info"?(Q(),te("g",ph,[...i[65]||(i[65]=[p("circle",{cx:"12",cy:"12",r:"10"},null,-1),p("path",{d:"M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"},null,-1),p("line",{x1:"12",y1:"17",x2:"12.01",y2:"17"},null,-1)])])):(Q(),te("g",hh,[...i[66]||(i[66]=[p("rect",{x:"2",y:"3",width:"20",height:"14",rx:"2"},null,-1),p("line",{x1:"8",y1:"21",x2:"16",y2:"21"},null,-1),p("line",{x1:"12",y1:"17",x2:"12",y2:"21"},null,-1)])]))]))}}),Mt=(e,t)=>{const i=e.__vccOpts||e;for(const[n,o]of t)i[n]=o;return i},de=Mt(mh,[["__scopeId","data-v-57969535"]]);function et(e,t){var o;if(typeof document>"u"||!e)return;const i=(o=globalThis.CSS)!=null&&o.escape?globalThis.CSS.escape(e):e.replace(/"/g,'\\"'),n=document.querySelectorAll(`[data-node-id="${i}"]`);!n||n.length===0||n.forEach(s=>{for(const[l,r]of Object.entries(t))r!=null&&r!==""?s.setAttribute(l,String(r)):s.removeAttribute(l)})}function gh(e){if(typeof document>"u")return;const t=`.protyle-wysiwyg [${he}], .protyle-wysiwyg [${Ge}], .protyle-wysiwyg [custom-slidev-layout], .protyle-wysiwyg [custom-slidev-role]`,i=document.querySelectorAll(t);!i||i.length===0||i.forEach(n=>{const o=n.getAttribute("data-node-id");if(!o){n.removeAttribute(he),n.removeAttribute("custom-slidev-layout"),n.removeAttribute(Ge),n.removeAttribute("custom-slidev-role");return}const s=e.get(o),l=(s==null?void 0:s[he])||(s==null?void 0:s["custom-slidev-layout"])||"",r=n.getAttribute(he)||n.getAttribute("custom-slidev-layout");r&&r!==l&&(l?n.setAttribute(he,l):(n.removeAttribute(he),n.removeAttribute("custom-slidev-layout")));const a=(s==null?void 0:s[Ge])||(s==null?void 0:s["custom-slidev-role"])||"",c=n.getAttribute(Ge)||n.getAttribute("custom-slidev-role");c&&c!==a&&(a?n.setAttribute(Ge,a):(n.removeAttribute(Ge),n.removeAttribute("custom-slidev-role")))})}const vh={class:"spm-layout-picker"},bh={class:"spm-layout-picker__grid"},yh=["title","onClick"],kh={class:"spm-layout-icon"},wh={class:"spm-layout-label"},xh=xt({__name:"LayoutPicker",props:{modelValue:{}},emits:["update:modelValue","change"],setup(e,{emit:t}){const i=e,n=t,o=[{name:"cover",label:"封面",desc:"大标题与副标题封面页"},{name:"default",label:"标准",desc:"标题在上方，内容在下方"},{name:"two-cols",label:"双栏",desc:"左右双栏对比展示"},{name:"cols-header",label:"表头多栏",desc:"顶部通栏标题，下方自适应 2~N 栏"},{name:"clover",label:"四叶草",desc:"4 项超级块 2x2 田字型四象限卡片布局"},{name:"image-right",label:"图右",desc:"左侧为内容，右侧全屏背景图"},{name:"image-left",label:"图左",desc:"左侧全屏背景图，右侧为内容"},{name:"center",label:"居中",desc:"内容全屏垂直水平居中"},{name:"fact",label:"大字报",desc:"核心数据或指标突出展示"},{name:"intro",label:"介绍",desc:"演讲者自我介绍或章节导览"},{name:"quote",label:"引言",desc:"名人名言与强调段落"}];function s(r){return i.modelValue===r||r==="cols-header"&&(i.modelValue==="two-cols-header"||i.modelValue==="three-cols-header")}function l(r){n("update:modelValue",r),n("change",r)}return(r,a)=>(Q(),te("div",vh,[a[0]||(a[0]=p("div",{class:"spm-layout-picker__header"},"选择页面版式",-1)),p("div",bh,[(Q(),te(Ue,null,kt(o,c=>p("div",{key:c.name,class:Se(["spm-layout-item",{active:s(c.name)}]),title:c.desc,onClick:d=>l(c.name)},[p("div",kh,[le(de,{name:"layout-"+c.name},null,8,["name"])]),p("span",wh,ye(c.label),1)],10,yh)),64))])]))}}),Ia=Mt(xh,[["__scopeId","data-v-1964d02c"]]),Sh={key:0,class:"spm-transition-selector__header"},_h={class:"spm-transition-list"},Ch=["onClick"],$h={class:"spm-transition-meta"},Ih={class:"spm-transition-label"},Th={class:"spm-transition-name"},Eh={class:"spm-transition-preview-box"},Ah=xt({__name:"TransitionSelector",props:{modelValue:{},hideHeader:{type:Boolean},title:{}},emits:["update:modelValue","change"],setup(e,{emit:t}){const i=t,n=[{name:"slide-left",label:"向左滑入",desc:"向左滑入 (slide-left)：页面从右侧向左平滑推入，最通用标准的横向幻灯片动效"},{name:"slide-right",label:"向右滑入",desc:"向右滑入 (slide-right)：页面从左侧向右平滑推入，适合倒序回退或逆向章节叙述"},{name:"slide-up",label:"向上推入",desc:"向上推入 (slide-up)：页面从底部向上平滑推入，适合纵向展开或纵深层级展示"},{name:"fade",label:"淡入淡出",desc:"淡入淡出 (fade)：透明度平滑渐变过度，典雅柔和，适合学术长篇与沉浸叙事"},{name:"zoom",label:"缩放进入",desc:"缩放进入 (zoom)：页面由中心向外平滑放大，富有动感冲击力，适合聚焦重点"}];function o(s){i("update:modelValue",s),i("change",s)}return(s,l)=>(Q(),te("div",{class:Se(["spm-transition-selector",{"spm-transition-selector--no-header":e.hideHeader}])},[e.hideHeader?Oe("",!0):(Q(),te("div",Sh,ye(e.title||"转场动效"),1)),p("div",_h,[(Q(),te(Ue,null,kt(n,r=>p("div",{key:r.name,class:Se(["spm-transition-item",{active:e.modelValue===r.name}]),onClick:a=>o(r.name)},[p("div",$h,[p("span",Ih,ye(r.label),1),p("span",Th,"("+ye(r.name)+")",1)]),p("div",Eh,[p("div",{class:Se(["spm-anim-cube","anim-"+r.name])},null,2)])],10,Ch)),64))])],2))}}),ir=Mt(Ah,[["__scopeId","data-v-8597e99e"]]),Bh={class:"spm-divider-popover"},Mh={class:"spm-divider-popover__title"},Dh={class:"spm-form-item"},Lh={class:"spm-popover-footer"},Oh={class:"spm-save-hint"},Ph=xt({__name:"QuickDividerPopover",props:{blockId:{},initialAttrs:{}},emits:["close","updated"],setup(e,{emit:t}){var v,u,m;const i=e,n=t,o=fe(((v=i.initialAttrs)==null?void 0:v[he])||"default"),s=fe(((u=i.initialAttrs)==null?void 0:u[tt])||"slide-left"),l=fe(((m=i.initialAttrs)==null?void 0:m[je])||""),r=fe("");ki(()=>i.initialAttrs,f=>{o.value=(f==null?void 0:f[he])||"default",s.value=(f==null?void 0:f[tt])||"slide-left",l.value=(f==null?void 0:f[je])||""},{deep:!0});async function a(f,b){if(i.blockId){r.value="正在同步...",Be.setBlockAttrOverride(i.blockId,{[f]:b}),et(i.blockId,{[f]:b});try{await Ne(i.blockId,{[f]:b}),r.value="已同步至块属性",n("updated",{[f]:b}),setTimeout(()=>{r.value=""},1500)}catch{r.value="同步失败"}}}function c(f){a(he,f)}function d(f){a(tt,f)}function h(){a(je,l.value.trim())}return(f,b)=>(Q(),te("div",Bh,[p("div",Mh,[b[4]||(b[4]=p("span",null,"幻灯片页面设置",-1)),p("button",{class:"spm-close-btn",onClick:b[0]||(b[0]=k=>n("close"))},"✕")]),le(Ia,{modelValue:o.value,"onUpdate:modelValue":b[1]||(b[1]=k=>o.value=k),onChange:c},null,8,["modelValue"]),le(ir,{modelValue:s.value,"onUpdate:modelValue":b[2]||(b[2]=k=>s.value=k),onChange:d},null,8,["modelValue"]),p("div",Dh,[b[5]||(b[5]=p("label",{class:"spm-form-label"},"页面背景",-1)),Et(p("input",{"onUpdate:modelValue":b[3]||(b[3]=k=>l.value=k),class:"spm-input",placeholder:"assets/bg.jpg 或颜色值 (#1e1e24)",onBlur:h},null,544),[[$o,l.value]])]),p("div",Lh,[p("span",Oh,ye(r.value),1)])]))}}),Rh=Mt(Ph,[["__scopeId","data-v-e4871368"]]),Nh={class:"spm-slide-inspector"},zh={class:"spm-inspector-header"},Fh={class:"spm-inspector-list"},Hh=["onClick"],jh={class:"spm-card-top"},Wh={class:"spm-card-badge"},Uh={class:"spm-card-layout"},Vh=["onClick"],Kh={class:"spm-card-preview"},Gh={key:0,class:"spm-card-notes",title:"演讲备忘录"},qh={class:"spm-inspector-modal-content"},Zh=xt({__name:"SlideInspector",props:{slides:{},currentActivePage:{}},emits:["navigate","refresh"],setup(e,{emit:t}){const i=t,n=fe(null);function o(c){n.value=c}function s(c){const d={};return c.frontmatter.layout&&(d[he]=c.frontmatter.layout),c.frontmatter.transition&&(d[tt]=c.frontmatter.transition),c.frontmatter.background&&(d[je]=c.frontmatter.background),c.notes&&(d[Ki]=c.notes),d}function l(c){n.value&&(c[he]&&(n.value.frontmatter.layout=c[he]),c[tt]&&(n.value.frontmatter.transition=c[tt]),c[je]&&(n.value.frontmatter.background=c[je]),c[Ki]&&(n.value.notes=c[Ki]),i("refresh"))}function r(c){i("navigate",c)}function a(c){if(!c.blocks||c.blocks.length===0)return"(空白页)";const d=c.blocks[0],h=d.content||d.rawMarkdown||"";return h.slice(0,40)+(h.length>40?"...":"")}return(c,d)=>(Q(),te("div",Nh,[p("div",zh,[p("span",null,"幻灯片大纲 ("+ye(e.slides.length)+" 页)",1)]),p("div",Fh,[(Q(!0),te(Ue,null,kt(e.slides,h=>(Q(),te("div",{key:h.pageIndex,class:Se(["spm-card",{active:e.currentActivePage===h.pageIndex}]),onClick:v=>r(h.pageIndex)},[p("div",jh,[p("span",Wh,"P"+ye(h.pageIndex),1),p("span",Uh,ye(h.frontmatter.layout||"default"),1),p("button",{class:"spm-card-btn-edit",title:"配置此页版式与属性",onClick:Lt(v=>o(h),["stop"])},[le(de,{name:"settings"})],8,Vh)]),p("div",Kh,ye(a(h)),1),h.notes?(Q(),te("div",Gh,[le(de,{name:"notes",style:{"font-size":"11px","margin-right":"3px"}}),p("span",null,ye(h.notes),1)])):Oe("",!0)],10,Hh))),128))]),n.value?(Q(),te("div",{key:0,class:"spm-inspector-modal-mask",onClick:d[1]||(d[1]=Lt(h=>n.value=null,["self"]))},[p("div",qh,[le(Rh,{"block-id":n.value.startBlockId,"initial-attrs":s(n.value),onClose:d[0]||(d[0]=h=>n.value=null),onUpdated:l},null,8,["block-id","initial-attrs"])])])):Oe("",!0)]))}}),Yh=Mt(Zh,[["__scopeId","data-v-68b25edd"]]),Jh={class:"spm-immersion-header"},Xh={class:"spm-immersion-header__left"},Qh={class:"spm-immersion-title"},em={class:"spm-immersion-header__center"},tm={class:"spm-immersion-header__actions"},im=["aria-label"],nm={class:"spm-immersion-body"},om=xt({__name:"ImmersionDrawerContainer",props:{visible:{type:Boolean,default:!1},isMaximized:{type:Boolean,default:!1},title:{default:"速览"},closeOnClickMask:{type:Boolean,default:!0}},emits:["update:visible","update:isMaximized","close","toggle-maximize"],setup(e,{emit:t}){const i=e,n=t;function o(){n("update:visible",!1),n("close")}function s(){i.closeOnClickMask&&o()}function l(){n("update:isMaximized",!i.isMaximized),n("toggle-maximize")}function r(a){(a.key===" "||a.key==="ArrowLeft"||a.key==="ArrowRight"||a.key==="PageUp"||a.key==="PageDown")&&a.stopPropagation(),a.key==="Escape"&&(a.preventDefault(),a.stopPropagation(),o())}return(a,c)=>Et((Q(),te("div",{class:Se(["spm-immersion-container",{"is-maximized":e.isMaximized}]),onKeydown:Lt(r,["stop"])},[p("div",{class:"spm-immersion-mask",onClick:s}),p("div",{class:Se(["spm-immersion-drawer",{"is-maximized":e.isMaximized}])},[p("div",Jh,[p("div",Xh,[Jn(a.$slots,"header-left",{},()=>[p("span",Qh,ye(e.title),1)])]),p("div",em,[Jn(a.$slots,"header-center",{},void 0)]),p("div",tm,[Jn(a.$slots,"header-actions",{},void 0),p("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":e.isMaximized?"还原抽屉宽度 (70%)":"最大化填满视口 (100%)",onClick:l},[le(de,{name:e.isMaximized?"minimize":"maximize"},null,8,["name"])],8,im),p("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"关闭速览 (ESC)",onClick:o},[le(de,{name:"close"})])])]),p("div",nm,[Jn(a.$slots,"default",{},void 0)])],2)],34)),[[_s,e.visible]])}}),sm=Mt(om,[["__scopeId","data-v-3f1665db"]]),rm={class:"spm-protyle-drawer"},lm={class:"spm-protyle-drawer__subbar"},am={class:"spm-protyle-drawer__nav"},cm=["title"],dm={class:"spm-protyle-drawer__actions"},um=["aria-label"],fm=["aria-label"],pm=xt({__name:"ProtylePeekDrawer",props:{blockId:{},title:{},plugin:{}},emits:["external-jump"],setup(e,{emit:t}){const i=t,n=e,o=fe(n.blockId),s=fe(n.title||""),l=fe(!1),r=fe(!0),a=fe(!1),c=fe(""),d=gi,h=fe([]),v=fe(null);let u=null;ki(()=>n.blockId,w=>{w&&w!==o.value&&(o.value=w,s.value=n.title||"",h.value=[],f(w))}),un(()=>{o.value&&f(o.value)}),Vs(()=>{b()});async function m(w){try{const R=await on(`SELECT id, root_id, type, content FROM blocks WHERE id = '${w}' LIMIT 1`);if(Array.isArray(R)&&R.length>0){const N=R[0];c.value=N.root_id||"";const F=N.id===N.root_id||N.type==="d";a.value=F,r.value=!F,!s.value&&N.content&&(s.value=N.content.trim().slice(0,30));return}}catch(R){console.warn("[ProtylePeekDrawer] detectBlockType query failed:",R)}a.value=!1,r.value=!0}async function f(w,R){if(!v.value||!w)return;b(),await m(w),typeof R=="boolean"&&(r.value=!a.value&&R);let N,F;r.value&&!a.value?(N=["cb-get-all","cb-get-hl","cb-get-focus"],F={background:!1,title:!1,gutter:!0,breadcrumbDocName:!0,scroll:!0}):(N=["cb-get-context","cb-get-hl"],F={background:!0,title:!0,gutter:!0,breadcrumbDocName:!0,scroll:!0});try{u=new me.Protyle(n.plugin.app,v.value,{blockId:w,action:N,render:F}),!l.value&&u&&typeof u.disable=="function"&&u.disable()}catch(q){console.error("[ProtylePeekDrawer] Failed to instantiate Protyle:",q)}}function b(){if(u){try{typeof u.destroy=="function"&&u.destroy()}catch(w){console.warn("[ProtylePeekDrawer] Error destroying protyle:",w)}u=null}v.value&&(v.value.innerHTML="")}function k(){a.value||(r.value=!r.value,f(o.value,r.value))}function x(){l.value=!l.value,u&&(l.value?(typeof u.enable=="function"&&u.enable(),typeof u.focus=="function"&&u.focus()):typeof u.disable=="function"&&u.disable())}function C(){if(o.value)try{me.openWindow({doc:{id:o.value},alwaysOnTop:!0})}catch(w){console.warn("[ProtylePeekDrawer] openWindow failed:",w)}}function A(){var N;if(!o.value)return;const w=jo(),R=va(w.webServeUrl,o.value,{focus:!a.value});if(typeof window<"u"){const F=Ct("electron");(N=F==null?void 0:F.shell)!=null&&N.openExternal?F.shell.openExternal(R).catch(()=>{window.open(R,"_blank")}):window.open(R,"_blank")}i("external-jump",R)}function D(){if(h.value.length>0){const w=h.value.pop();w&&(o.value=w.blockId,s.value=w.title,r.value=w.isFocusMode,a.value=w.isDoc,f(w.blockId,w.isFocusMode))}}function T(w){const R=w.target;if(!R)return;const N=R.closest('[data-type="block-ref"]');if(N){const q=N.getAttribute("data-id");if(q&&q!==o.value){w.preventDefault(),w.stopPropagation(),h.value.push({blockId:o.value,title:s.value||o.value,isFocusMode:r.value,isDoc:a.value}),o.value=q,s.value=N.innerText.trim()||q,f(q);return}}const F=R.closest("a");if(F&&F.href&&F.href.startsWith("siyuan://blocks/")){w.preventDefault(),w.stopPropagation();const q=F.href.replace("siyuan://blocks/","").split("?")[0];q&&q!==o.value&&(h.value.push({blockId:o.value,title:s.value||o.value,isFocusMode:r.value,isDoc:a.value}),o.value=q,s.value=F.innerText.trim()||q,f(q))}}return(w,R)=>(Q(),te("div",rm,[p("div",lm,[p("div",am,[h.value.length>0?(Q(),te("button",{key:0,class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"返回上层引用文档或块",onClick:D},[le(de,{name:"arrow-left"}),R[0]||(R[0]=p("span",null,"返回",-1))])):Oe("",!0),p("span",{class:Se(["spm-protyle-badge",{"is-focus":r.value&&!a.value}])},ye(r.value&&!a.value?"思源块聚焦":"思源文档速览"),3),p("span",{class:"spm-protyle-id",title:s.value||o.value},ye(s.value||o.value),9,cm)]),p("div",dm,[a.value?Oe("",!0):(Q(),te("button",{key:0,class:Se(["spm-icon-btn b3-tooltips b3-tooltips__s",{"is-primary":r.value}]),"aria-label":r.value?"当前为块聚焦模式（点击展开所属文档全文）":"当前为文档全文模式（点击切回仅聚焦当前块）",onClick:k},[le(de,{name:r.value?"focus":"file-text"},null,8,["name"]),p("span",null,ye(r.value?"块聚焦":"展开全文"),1)],10,um)),p("button",{class:Se(["spm-icon-btn b3-tooltips b3-tooltips__s",{"is-primary":l.value}]),"aria-label":l.value?"当前为即时编辑模式（点击切回只读）":"当前为只读速览模式（点击解锁即时编辑）",onClick:x},[le(de,{name:l.value?"edit":"eye"},null,8,["name"]),p("span",null,ye(l.value?"编辑中":"只读"),1)],10,fm),p("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"在置顶独立窗口中打开 (保留完整侧边栏与插件)",onClick:C},[le(de,{name:"window"}),R[1]||(R[1]=p("span",null,"独立窗口",-1))]),ve(d).enableWebServeJump?(Q(),te("button",{key:1,class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"在系统默认浏览器中打开 (外跳)",onClick:A},[le(de,{name:"external-link"}),R[2]||(R[2]=p("span",null,"外跳",-1))])):Oe("",!0)])]),p("div",{ref_key:"mountEl",ref:v,class:Se(["spm-protyle-mount",{"is-focus-mode":r.value&&!a.value}]),onClick:T},null,2)]))}}),hm=Mt(pm,[["__scopeId","data-v-7e586ef3"]]),mm=/^(https?|file|data|blob|mailto|tel|ftp|ftps|siyuan|about|chrome|ws|wss):/i,gm=/\.(html?|xhtml|pdf|png|jpe?g|gif|svg|webp|avif|ico|mp4|webm|mov|mp3|wav|m4a|ogg|json|md|markdown|txt|csv|zip|tar|gz|7z|rar|js|mjs|css|xml|yaml|yml|toml|ipynb|docx?|xlsx?|pptx?)$/i;function Vr(e){let t=e||"";try{t=decodeURIComponent(t)}catch{}t=t.replace(/\\/g,"/");const i=/(?:^|\/)data\/assets\/(.+)$/i.exec(t);if(i)return`/assets/${i[1]}`;const n=/(?:^|\/)data\/plugins\/(.+)$/i.exec(t);return n?`/plugins/${n[1]}`:null}function Ta(e){const t=(e||"").replace(/^file:\/\//i,"");let i=t;try{i=decodeURIComponent(t)}catch{}if(i.startsWith("/"))return/^\/([a-zA-Z]:[\\/])/.exec(i)?i.slice(1):i;const n=i.indexOf("/");return n>=0?i.slice(n):i}function vm(e){const t=e.split(/[/?#]/)[0];return!t||gm.test(t)?!1:/^(localhost|\d{1,3}(\.\d{1,3}){3})(:\d+)?$/i.test(t)?!0:/^[a-z0-9-]+(\.[a-z0-9-]+)+(:\d+)?$/i.test(t)}function bm(e){const t=e.indexOf("#"),i=t>=0?e.slice(t):"",n=t>=0?e.slice(0,t):e,o=n.indexOf("?"),s=o>=0?n.slice(0,o):n,l=o>=0?n.slice(o+1):"";if(!/^\/?assets\/.+\.html?$/i.test(s))return e;const r=new URLSearchParams(l);return r.get("iframe")==="true"||r.get("download")==="true"?e:(r.set("iframe","true"),`${s}?${r.toString()}${i}`)}function Ea(e){const t=ym(e);return t.external||!t.url?t:{url:bm(t.url),external:!1}}function ym(e){const t=(e||"").trim();if(!t)return{url:"",external:!1};if(/^https?:\/\//i.test(t))return{url:t,external:!1};if(t.startsWith("//"))return{url:`https:${t}`,external:!1};if(/^(siyuan|data|blob|about):/i.test(t))return{url:t,external:!1};if(dl(t))return{url:`/${ul(t)}`,external:!1};if(/^file:/i.test(t)){const n=Vr(Ta(t));return n?{url:n,external:!1}:{url:t,external:!0}}if(/^[a-zA-Z]:[\\/]/.test(t)||t.startsWith("\\\\")){const n=Vr(t);return n?{url:n,external:!1}:{url:t,external:!0}}return mm.test(t)?{url:t,external:!0}:vm(t)?{url:`https://${t}`,external:!1}:{url:`/${t.replace(/^(?:\.{1,2}\/)+/,"").replace(/^\/+/,"")}`,external:!1}}const km={class:"spm-webview-drawer"},wm={class:"spm-webview-toolbar"},xm={class:"spm-webview-toolbar__nav"},Sm=["disabled"],_m=["disabled"],Cm=["aria-label"],$m={class:"spm-webview-toolbar__address"},Im=["aria-label"],Tm={class:"spm-webview-toolbar__actions"},Em=["aria-label"],Am={class:"spm-zoom-controller"},Bm=["disabled"],Mm=["disabled"],Dm={key:1,class:"spm-webview-fallback"},Lm=["src"],Om={key:2,class:"spm-load-error"},Pm={class:"spm-load-error__code"},Rm={class:"spm-load-error__code-num"},Nm={class:"spm-load-error__url"},zm={class:"spm-load-error__hint"},Fm={class:"spm-load-error__actions"},Kr="Mozilla/5.0 (iPhone; CPU iPhone OS 17_4_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.4.1 Mobile/15E148 Safari/604.1",Aa="siyuan-slidev-peek-view-mode";let Ba="desktop";function Hm(){if(typeof window<"u"&&window.localStorage)try{const e=window.localStorage.getItem(Aa);if(e==="mobile"||e==="desktop")return e}catch{}return Ba}function jm(e){if(Ba=e,typeof window<"u"&&window.localStorage)try{window.localStorage.setItem(Aa,e)}catch{}}function Wm(e){switch((e||"").toUpperCase()){case"ERR_PROXY_CONNECTION_FAILED":return"无法连接到代理服务器：请在思源「设置 → 网络代理」中填写公司代理地址，或切换为「使用系统代理」。";case"ERR_TUNNEL_CONNECTION_FAILED":return"HTTPS 代理隧道建立失败：请将思源「网络代理」的类型设为 HTTPS 并确认地址正确。";case"ERR_MANDATORY_PROXY_CONFIGURATION_FAILED":return"强制代理配置获取失败：公司 PAC 脚本不可用，请在思源「网络代理」中改为手动填写代理地址。";case"ERR_NAME_NOT_RESOLVED":case"ERR_NAME_RESOLUTION_FAILED":return"域名解析失败：内网环境访问外网通常需要配置代理或 DNS。";case"ERR_INTERNET_DISCONNECTED":return"当前网络不可用：请检查网络连接。";case"ERR_CONNECTION_TIMED_OUT":case"ERR_TIMED_OUT":return"连接超时：该地址可能需要通过代理才能访问。";case"ERR_CONNECTION_REFUSED":return"连接被拒绝：目标服务未在监听，或思源本地内核尚未启动。";case"ERR_CERT_AUTHORITY_INVALID":case"ERR_CERT_COMMON_NAME_INVALID":case"ERR_CERT_DATE_INVALID":return"证书校验失败：若公司网络使用 TLS 拦截，需将根证书导入思源所用系统的证书库。";default:return"若处于公司内网，请优先检查思源「设置 → 网络代理」是否已配置为可用代理（支持「使用系统代理」）。"}}const Um=xt({__name:"WebviewPeekDrawer",props:{url:{},title:{},visible:{type:Boolean,default:!0}},emits:["external-jump"],setup(e,{emit:t}){const i=t,n=e,o=fe(_a()&&!Wf()),s=fe(n.url),l=fe(n.url),r=n.url,a=fe(!1),c=fe(null),d=fe(!1),h=fe(!1),v=fe(1),u=fe(!1),m=fe(Hm());let f=typeof navigator<"u"&&!navigator.userAgent.includes("iPhone")?navigator.userAgent:"";const b=we(()=>m.value==="mobile"?Kr:f||void 0),k=fe(null),x=fe(null);let C=null,A=null,D=null;ki(()=>n.url,Y=>{Y&&Y!==s.value&&(s.value=Y,l.value=Y,m.value==="mobile"&&F(!1),k.value&&typeof k.value.loadURL=="function"&&k.value.loadURL(Y))}),ki(()=>n.visible,Y=>{if(Y)ie(),m.value==="mobile"&&F(!1);else if(k.value)try{typeof k.value.stop=="function"&&k.value.stop()}catch{}}),un(()=>{T(),x.value&&typeof ResizeObserver<"u"&&(C=new ResizeObserver(()=>{const Y=k.value;if(Y&&typeof Y.invalidate=="function")try{Y.invalidate()}catch{}}),C.observe(x.value)),A=Y=>{var P;const ce=Y.message||((P=Y.error)==null?void 0:P.message);if(typeof ce=="string"&&ce.includes("Invalid guestInstanceId"))return Y.preventDefault(),Y.stopImmediatePropagation(),!0},window.addEventListener("error",A,!0),D=Y=>{const ce=Y.reason,P=typeof ce=="string"?ce:ce==null?void 0:ce.message;typeof P=="string"&&P.includes("Invalid guestInstanceId")&&Y.preventDefault()},window.addEventListener("unhandledrejection",D)}),Vs(()=>{if(w(),C&&(C.disconnect(),C=null),A&&(window.removeEventListener("error",A,!0),A=null),D&&(window.removeEventListener("unhandledrejection",D),D=null),k.value)try{typeof k.value.stop=="function"&&k.value.stop()}catch{}});function T(){const Y=k.value;Y&&(Y.addEventListener("dom-ready",R),Y.addEventListener("did-start-loading",q),Y.addEventListener("did-stop-loading",y),Y.addEventListener("did-navigate",M),Y.addEventListener("did-navigate-in-page",H),Y.addEventListener("new-window",E),Y.addEventListener("did-fail-load",_),Y.addEventListener("did-fail-provisional-load",_))}function w(){const Y=k.value;if(Y)try{Y.removeEventListener("dom-ready",R),Y.removeEventListener("did-start-loading",q),Y.removeEventListener("did-stop-loading",y),Y.removeEventListener("did-navigate",M),Y.removeEventListener("did-navigate-in-page",H),Y.removeEventListener("new-window",E),Y.removeEventListener("did-fail-load",_),Y.removeEventListener("did-fail-provisional-load",_)}catch{}}function R(){const Y=k.value;if(Y&&typeof Y.getUserAgent=="function"&&!f)try{const ce=Y.getUserAgent();ce&&!ce.includes("iPhone")&&(f=ce)}catch{}m.value==="mobile"&&F(!1),ie(),O()}function N(){const Y=m.value==="mobile"?"desktop":"mobile";m.value=Y,jm(Y),F(!0)}function F(Y=!1){const ce=k.value;if(!ce)return;const P=m.value==="mobile"?Kr:f;if(typeof ce.setUserAgent=="function"&&P)try{ce.setUserAgent(P)}catch(j){console.warn("[WebviewPeekDrawer] setUserAgent error:",j)}if(Y&&typeof ce.reload=="function")try{ce.reload()}catch(j){console.warn("[WebviewPeekDrawer] reload error:",j)}}function q(){a.value=!0,c.value=null}function _(Y){if(Y&&Y.isMainFrame===!1||Y&&Number(Y.errorCode)===-3)return;const ce=String((Y==null?void 0:Y.errorDescription)||"ERR_FAILED");c.value={errorCode:Number((Y==null?void 0:Y.errorCode)??0),description:ce,validatedURL:String((Y==null?void 0:Y.validatedURL)||s.value),hint:Wm(ce)},a.value=!1}function L(){c.value=null,Z()}function y(){if(a.value=!1,O(),k.value&&typeof k.value.getURL=="function"){const Y=k.value.getURL();Y&&Y!=="about:blank"&&(s.value=Y,l.value=Y)}}function M(Y){Y!=null&&Y.url&&(s.value=Y.url,l.value=Y.url),O()}function H(Y){Y!=null&&Y.url&&(s.value=Y.url,l.value=Y.url),O()}function E(Y){Y&&Y.url&&(Y.preventDefault(),k.value&&typeof k.value.loadURL=="function"&&k.value.loadURL(Y.url))}function O(){const Y=k.value;Y&&(typeof Y.canGoBack=="function"&&(d.value=Y.canGoBack()),typeof Y.canGoForward=="function"&&(h.value=Y.canGoForward()))}function z(){k.value&&typeof k.value.goBack=="function"&&k.value.goBack()}function X(){k.value&&typeof k.value.goForward=="function"&&k.value.goForward()}function Z(){k.value&&typeof k.value.reload=="function"&&k.value.reload()}function W(){const Y=Ea(l.value);if(Y.url){if(Y.external){s.value=Y.url,ae();return}s.value=Y.url,l.value=Y.url,k.value&&typeof k.value.loadURL=="function"&&k.value.loadURL(Y.url)}}function ie(){const Y=k.value;if(Y&&typeof Y.setZoomFactor=="function")try{Y.setZoomFactor(v.value)}catch(ce){console.warn("[WebviewPeekDrawer] setZoomFactor error:",ce)}}function se(){v.value=Math.min(2.5,Math.round((v.value+.1)*10)/10),ie()}function re(){v.value=Math.max(.5,Math.round((v.value-.1)*10)/10),ie()}function ue(){v.value=1,ie()}function Ie(Y){Y.preventDefault(),Y.deltaY<0?se():Y.deltaY>0&&re()}async function be(){if(typeof navigator<"u"&&navigator.clipboard)try{await navigator.clipboard.writeText(s.value),u.value=!0,setTimeout(()=>{u.value=!1},2e3)}catch(Y){console.warn("Copy url failed:",Y)}}function ae(){var ce;const Y=s.value;if(typeof window<"u"){const P=Ct("electron");(ce=P==null?void 0:P.shell)!=null&&ce.openExternal?P.shell.openExternal(Y).catch(()=>{window.open(Y,"_blank")}):window.open(Y,"_blank")}i("external-jump",Y)}return(Y,ce)=>{const P=Xd("webview");return Q(),te("div",km,[p("div",wm,[p("div",xm,[p("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s",disabled:!d.value,"aria-label":"后退",onClick:z},[le(de,{name:"arrow-left"})],8,Sm),p("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s",disabled:!h.value,"aria-label":"前进",onClick:X},[le(de,{name:"arrow-right"})],8,_m),p("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":a.value?"正在加载...":"刷新页面",onClick:Z},[le(de,{name:"refresh"})],8,Cm)]),p("div",$m,[Et(p("input",{"onUpdate:modelValue":ce[0]||(ce[0]=j=>l.value=j),type:"text",class:"b3-text-field spm-url-input",placeholder:"https://...",spellcheck:"false",onKeydown:hf(W,["enter"])},null,544),[[$o,l.value]]),p("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":u.value?"已复制地址！":"复制网址",onClick:be},[le(de,{name:"copy"})],8,Im)]),p("div",Tm,[p("button",{class:Se(["spm-icon-btn spm-mode-toggle b3-tooltips b3-tooltips__s",{"is-active":m.value==="mobile"}]),"aria-label":m.value==="mobile"?"当前为手机视图，点击切换为桌面视图":"当前为桌面视图，点击切换为手机视图",onClick:N},[le(de,{name:m.value==="mobile"?"mobile":"desktop"},null,8,["name"])],10,Em),p("div",Am,[p("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"缩小 (Ctrl + -)",disabled:v.value<=.5,onClick:re},[le(de,{name:"minus"})],8,Bm),p("button",{class:"spm-zoom-badge b3-tooltips b3-tooltips__s","aria-label":"重置 100% (Ctrl + 0)",onClick:ue},ye(Math.round(v.value*100))+"% ",1),p("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"放大 (Ctrl + +)",disabled:v.value>=2.5,onClick:se},[le(de,{name:"plus"})],8,Mm)]),p("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"在系统默认浏览器中打开 ↗",onClick:ae},[le(de,{name:"external-link"}),ce[1]||(ce[1]=p("span",null,"外跳",-1))])])]),p("div",{ref_key:"containerEl",ref:x,class:Se(["spm-webview-body",{"is-mobile":m.value==="mobile"}]),onWheel:Lt(Ie,["ctrl"])},[p("div",{class:Se(["spm-webview-viewport",{"is-mobile":m.value==="mobile"}])},[o.value?(Q(),Ot(P,{key:0,ref_key:"webviewRef",ref:k,class:"spm-webview-frame",src:ve(r),useragent:b.value,allowpopups:"true",style:{position:"absolute",top:"0",left:"0",width:"100%",height:"100%",display:"inline-flex"}},null,8,["src","useragent"])):(Q(),te("div",Dm,[p("iframe",{class:"spm-webview-fallback-frame",src:s.value,frameborder:"0",sandbox:"allow-scripts allow-same-origin allow-forms allow-popups"},null,8,Lm),p("div",{class:"spm-fallback-bar"},[ce[2]||(ce[2]=p("span",null,"如页面受同源策略 (X-Frame-Options) 拦截无法显示，请",-1)),p("button",{class:"spm-icon-btn is-primary",onClick:ae}," 在新标签页中打开 ↗ ")])])),c.value?(Q(),te("div",Om,[le(de,{name:"alert",class:"spm-load-error__icon"}),ce[5]||(ce[5]=p("div",{class:"spm-load-error__title"},"页面加载失败",-1)),p("div",Pm,[$t(ye(c.value.description)+" ",1),p("span",Rm,"("+ye(c.value.errorCode)+")",1)]),p("div",Nm,ye(c.value.validatedURL),1),p("p",zm,ye(c.value.hint),1),p("div",Fm,[p("button",{class:"spm-icon-btn","aria-label":"重试",onClick:L},[le(de,{name:"refresh"}),ce[3]||(ce[3]=p("span",null,"重试",-1))]),p("button",{class:"spm-icon-btn is-primary","aria-label":"用系统浏览器打开",onClick:ae},[le(de,{name:"external-link"}),ce[4]||(ce[4]=p("span",null,"用系统浏览器打开 ↗",-1))])])])):Oe("",!0)],2)],34)])}}}),Vm=Mt(Um,[["__scopeId","data-v-192d3665"]]);class Km{constructor(){ke(this,"timers",new Map)}debounce(t,i,n=150){this.cancel(t);const o=setTimeout(()=>{this.timers.delete(t),i()},n);this.timers.set(t,o)}cancel(t){this.timers.has(t)&&(clearTimeout(this.timers.get(t)),this.timers.delete(t))}cancelAll(){for(const t of this.timers.values())clearTimeout(t);this.timers.clear()}hasPending(t){return this.timers.has(t)}}class Gm{constructor(t){ke(this,"blockToPageMap",new Map);ke(this,"debounceCtrl",new Km);ke(this,"activeBlockId","");ke(this,"activePageIndex",1);ke(this,"currentDocId","");ke(this,"bridge",null);t&&(this.bridge=t)}setBridge(t){this.bridge=t}setDocId(t){this.currentDocId=t}updateSlidesIndex(t){this.blockToPageMap.clear();for(const i of t){i.startBlockId&&this.blockToPageMap.set(i.startBlockId,i.pageIndex);for(const n of i.blocks)this.blockToPageMap.set(n.id,i.pageIndex)}}getPageByBlockId(t){return this.blockToPageMap.get(t)??null}onCursorFocusBlock(t){if(!t||t===this.activeBlockId)return;this.activeBlockId=t;let i=this.getPageByBlockId(t);!i&&(t===this.currentDocId||!this.currentDocId&&this.blockToPageMap.size>0)&&(i=1),i&&this.debounceCtrl.debounce("cursor-navigate",()=>{this.activePageIndex=i,this.bridge&&(this.bridge.navigatePage(i),this.bridge.highlightElement(t))},100)}getActiveBlockId(){return this.activeBlockId}setActiveBlockId(t){this.activeBlockId=t;const i=this.getPageByBlockId(t);i&&(this.activePageIndex=i)}getActivePageIndex(){return this.activePageIndex}destroy(){this.debounceCtrl.cancelAll(),this.blockToPageMap.clear(),this.bridge=null}}function Ri(e,t){var s,l;if(!e||typeof document>"u")return!1;const i=(s=globalThis.CSS)!=null&&s.escape?globalThis.CSS.escape(e):e.replace(/"/g,'\\"'),n=document.querySelector(`.protyle-wysiwyg [data-node-id="${i}"]`)||document.querySelector(`[data-node-id="${i}"]`);if(!n){if(t)try{return me.openTab({app:t,doc:{id:e,action:["cb-get-hl","cb-get-focus","cb-get-context"]}}),!0}catch(r){console.warn("[SelectionMirror] openTab fallback failed:",r)}return!1}try{n.scrollIntoView({behavior:"smooth",block:"center",inline:"nearest"})}catch{n.scrollIntoView()}try{(l=n.focus)==null||l.call(n,{preventScroll:!0})}catch{}n.classList.add("protyle-wysiwyg--select");const o=n.style.outline;return n.style.outline="2px solid #3b82f6",n.style.transition="outline 0.3s ease",setTimeout(()=>{n.classList.remove("protyle-wysiwyg--select"),n.style.outline=o},1200),!0}function qm(e){if(!e)return"";const t=e.split(`
`).map(l=>l.trim()).filter(Boolean);if(t.length===0)return"";if(!t.some(l=>/^#{1,6}\s+/.test(l)))return t.map(l=>lt(l)).join("<br/>");const n=[];let o=[];const s=()=>{if(o.length>0){const l=o.map(r=>lt(r)).join("<br/>");n.push(`<p class="slide-list-item-desc">${l}</p>`),o=[]}};for(const l of t){const r=l.match(/^(#{1,6})\s+(.*)$/);if(r){s();const a=r[1].length,c=r[2].trim();n.push(`<h${a} class="slide-list-item-title">${lt(c)}</h${a}>`)}else o.push(l)}return s(),n.join(`
`)}function Zm(e){if(e.length===0)return"";const t=[],i=e[0],n=i.match(/^(#{1,6})\s+(.*)$/);if(n){const o=n[1].length,s=n[2].trim();t.push(`<h${o} class="slide-list-item-title">${lt(s)}</h${o}>`)}else t.push(`<p class="slide-list-item-title">${lt(i)}</p>`);if(e.length>1){const o=e.slice(1);let s=[];const l=()=>{if(s.length>0){const r=s.map(a=>lt(a)).join("<br/>");t.push(`<p class="slide-list-item-desc">${r}</p>`),s=[]}};for(const r of o){const a=r.match(/^(#{1,6})\s+(.*)$/);if(a){l();const c=a[1].length,d=a[2].trim();t.push(`<h${c} class="slide-list-item-title">${lt(d)}</h${c}>`)}else s.push(r)}l()}return t.join(`
`)+(t.length>0?`
`:"")}function Ma(e,t,i){var v,u,m,f;const n=e.split(`
`);if(!n.some(b=>/^(\s*)([-*+]|\d+\.)\s+/.test(b)))return null;const s=[],l=[];let r=!1;for(let b=0;b<n.length;b++){const k=n[b];if(!k.trim())continue;const x=k.match(/^(\s*)[-*+]\s+\[([ xX])\]\s+(.*)$/);if(x){const T=x[1].length,w=Math.floor(T/2);l.push({type:"task",level:w,checked:x[2].toLowerCase()==="x",text:x[3],media:[]});continue}const C=k.match(/^(\s*)[-*+]\s+(.*)$/);if(C){const T=C[1].length,w=Math.floor(T/2);l.push({type:"unordered",level:w,text:C[2],media:[]});continue}const A=k.match(/^(\s*)\d+\.\s+(.*)$/);if(A){l.length===0&&(r=!0);const T=A[1].length,w=Math.floor(T/2);l.push({type:"ordered",level:w,text:A[2],media:[]});continue}const D=k.trim();if(!(!D||/^\{:.*?\}$/.test(D)))if(l.length>0){const T=D.match(/^!\[(.*?)\]\((.*?)\)(?:\{:?[^}]*\})?$/);if(T){const N=/\.gif(?:\?|$)/i.test(T[2])?"list-item-gif":"list-item-img";l[l.length-1].media||(l[l.length-1].media=[]),l[l.length-1].media.push(`<div class="slide-list-media"><img alt="${ot(T[1])}" src="${T[2]}" class="${N}" /></div>`);continue}if(D.match(/^<img\b[\s\S]*?\/?>$/i)){const R=D.replace(/\s+style="[^"]*"/gi,"");l[l.length-1].media||(l[l.length-1].media=[]),l[l.length-1].media.push(`<div class="slide-list-media">${R}</div>`);continue}if(/<video\b/i.test(D)){let R=D;if(!/<\/video>/i.test(R))for(;b+1<n.length&&!/<\/video>/i.test(R);)b++,R+=" "+n[b].trim();const N=((v=i==null?void 0:i.attributes)==null?void 0:v["custom-slidev-autoplay"])==="true"||/autoplay/i.test(R),F=((u=i==null?void 0:i.attributes)==null?void 0:u["custom-slidev-loop"])==="true"||/loop/i.test(R),q=((m=i==null?void 0:i.attributes)==null?void 0:m["custom-slidev-muted"])==="true"||N||/muted/i.test(R),_=((f=i==null?void 0:i.attributes)==null?void 0:f["custom-slidev-controls"])==="false",L=R.match(/\bsrc=["']([^"']+)["']/i),y=L?L[1]:"",M=['class="slide-video-player"'];_||M.push("controls"),N&&(M.push("autoplay"),M.push("playsinline")),F&&M.push("loop"),q&&M.push("muted"),M.push('preload="metadata"'),y&&M.push(`src="${y}"`);const H=R.match(/<video[^>]*>([\s\S]*?)<\/video>/i);let E=H?H[1].trim():"";!E&&y&&(E=`<source src="${y}" type="video/mp4" />您的浏览器不支持视频播放。`),l[l.length-1].media||(l[l.length-1].media=[]),l[l.length-1].media.push(`<div class="slide-list-media slide-video-container slide-media-container" data-autoplay="${N?"true":"false"}" data-muted="${q?"true":"false"}"><video ${M.join(" ")}>${E}</video></div>`);continue}l[l.length-1].text+=`
`+D}else s.push(D)}if(l.length===0)return null;const a=r?"ol":"ul",c=(t==null?void 0:t.listClassName)||(r?"pdf-list pdf-list--ordered":"pdf-list pdf-list--unordered"),d=l.map(b=>{const k=qm(b.text),x=b.media&&b.media.length>0?`
${b.media.join(`
`)}`:"",C=b.level||0,A=C>0?` style="margin-left:${(C*1.25).toFixed(2)}em;${b.type==="unordered"?`list-style-type:${C%2===1?"circle":"square"} !important;`:""}"`:"",D=C>0?" slide-list-item--nested":"";if(b.type==="task"){const w=b.checked?' checked=""':"";return`<li class="pdf-task-item${D}"${A}><label><input type="checkbox" disabled=""${w}/> <span>${k}</span></label>${x}</li>`}return`<li${D?` class="${D.trim()}"`:""}${A}>${k}${x}</li>`}).join(`
`);return`${Zm(s)}<${a} class="${c}">
${d}
</${a}>`}function Ym(e,t,i){const n=(t==null?void 0:t.containerClassName)||"pdf-block",o=e.split(/\r?\n/),s=[];let l=[];for(let c=0;c<o.length;c++){const d=o[c],h=d.trim();if(/^#{1,6}\s+/.test(h)){l.length>0&&(s.push(l.join(`
`)),l=[]),s.push(h);continue}if(!h){l.length>0&&(s.push(l.join(`
`)),l=[]);continue}if(/^!\[.*?\]\(.*?\)$/.test(h)){l.length>0&&(s.push(l.join(`
`)),l=[]),s.push(h);continue}if(/<video\b/i.test(h)){l.length>0&&(s.push(l.join(`
`)),l=[]);let v=h;if(!/<\/video>/i.test(v))for(;c+1<o.length&&!/<\/video>/i.test(v);)c++,v+=`
`+o[c];s.push(v);continue}l.push(d)}l.length>0&&s.push(l.join(`
`));let r=!0;return s.map(c=>{var m,f,b,k;const d=c.trim();if(!d)return"";const h=d.match(/^(#{1,6})\s+(.*)$/);if(h){r=!1;const x=h[1].length;return`<h${x} class="slide-list-item-title">${lt(h[2].trim())}</h${x}>`}const v=d.match(/^!\[(.*?)\]\((.*?)\)$/);if(v){const x=/\.gif(?:\?|$)/i.test(v[2]),C=(t==null?void 0:t.imageClassName)||(x?"list-item-gif":"pdf-image slide-media-img");return`<div class="${n} ${n}--image slide-media-block slide-media-container slide-list-media"><img alt="${ot(v[1])}" src="${v[2]}" class="${C}" /></div>`}if(/<video\b/i.test(d)){const x=((m=i==null?void 0:i.attributes)==null?void 0:m["custom-slidev-autoplay"])==="true"||/autoplay/i.test(d),C=((f=i==null?void 0:i.attributes)==null?void 0:f["custom-slidev-loop"])==="true"||/loop/i.test(d),A=((b=i==null?void 0:i.attributes)==null?void 0:b["custom-slidev-muted"])==="true"||x||/muted/i.test(d),D=((k=i==null?void 0:i.attributes)==null?void 0:k["custom-slidev-controls"])==="false",T=d.match(/\bsrc=["']([^"']+)["']/i),w=T?T[1]:"",R=['class="slide-video-player"'];D||R.push("controls"),x&&R.push("autoplay playsinline"),C&&R.push("loop"),A&&R.push("muted"),R.push('preload="metadata"'),w&&R.push(`src="${w}"`);const N=d.match(/<video[^>]*>([\s\S]*?)<\/video>/i);let F=N?N[1].trim():"";return!F&&w&&(F=`<source src="${w}" type="video/mp4" />您的浏览器不支持视频播放。`),`<div class="${n} ${n}--video slide-media-block slide-video-container slide-media-container" data-autoplay="${x?"true":"false"}" data-muted="${A?"true":"false"}"><video ${R.join(" ")}>${F}</video></div>`}const u=Ma(d,t,i);if(u)return r=!1,u;if(r){r=!1;const x=d.split(/\r?\n/).map(T=>T.trim()).filter(Boolean);if(x.length===1)return`<p class="slide-list-item-title">${lt(x[0])}</p>`;const C=x[0],D=x.slice(1).map(T=>lt(T)).join("<br/>");return`<p class="slide-list-item-title">${lt(C)}</p>
<p class="slide-list-item-desc">${D}</p>`}return`<p class="slide-list-item-desc">${lt(d)}</p>`}).filter(Boolean).join(`
`)}function ss(e){if(!e)return!1;if(e.type==="h"||e.type==="NodeHeading")return!0;const t=(e.rawMarkdown||e.content||"").trim();return/^#{1,6}\s+/.test(t)}function Da(e,t){var r,a,c,d,h,v,u,m;const i=((r=e.frontmatter)==null?void 0:r.layout)||"default",o=(e.blocks||[]).filter(f=>f.slot!=="slot-divider-right"),l=i==="cover"?null:o.find(ss);if(i==="two-cols"){const f=o.some(q=>q.slot==="right");let b=[],k=[];if(f)b=o.filter(q=>q.slot!=="right"),k=o.filter(q=>q.slot==="right");else{const q=Math.ceil(o.length/2);b=o.slice(0,q),k=o.slice(q)}const x=q=>{const _=q.filter(L=>!!(L.rawMarkdown||L.content||"").trim());if(_.length>0){const L=_[0],y=(L.rawMarkdown||L.content||"").trim();(zi(L)||/^(?:[-*+]|\d+\.)\s+/.test(y))&&(L.rawMarkdown=In(L.rawMarkdown||L.content||""),L.content=L.rawMarkdown)}};x(b),x(k);const C=b.map(q=>pi(q,t)).join(`
`),A=k.map(q=>pi(q,t)).join(`
`),D=(t==null?void 0:t.twoColsWrapperClass)||"pdf-two-cols-wrapper layout-two-cols-grid",T=(a=e.frontmatter)!=null&&a.layoutClass?` ${e.frontmatter.layoutClass}`:"",w=(t==null?void 0:t.leftColClass)||"pdf-col pdf-col--left",R=(t==null?void 0:t.rightColClass)||"pdf-col pdf-col--right",F=`style="grid-template-columns: ${ns((c=e.frontmatter)==null?void 0:c.layoutRatio,2)};"`;return`
      <div class="${D}${T}" ${F}>
        <div class="${w}">${C}</div>
        <div class="${R}">${A}</div>
      </div>
    `}if(i==="clover"||Ln(i)){const f=i==="clover";let b=[];const k=o.filter(M=>M.slot==="header");if(k.length>0)b=k;else if(o.length>0){const M=o.find(H=>H.type==="h"&&(!H.slot||H.slot==="default"));M&&(b=[M])}const x=o.filter(M=>!b.includes(M));let C=2;if(f)C=4;else if(i==="three-cols-header")C=3;else if(i==="two-cols-header")C=2;else{let M=0;for(const H of x){const E=(H.slot||"").match(/^col-(\d+)$/i);E&&(M=Math.max(M,parseInt(E[1],10)))}if(M>=2)C=M;else if((d=e.frontmatter)!=null&&d.layoutRatio){const H=e.frontmatter.layoutRatio.trim();if(H.includes(":")){const E=H.split(":").map(O=>parseFloat(O.trim())).filter(O=>!isNaN(O)&&O>0);E.length>=2&&(C=E.length)}else{const E=H.split(/\s+/).filter(Boolean);E.length>=2&&(C=E.length)}}else x.length===1&&x[0].children&&x[0].children.length>=2&&(C=Math.min(6,x[0].children.length))}const A=Sa(x,C),D=x.some(M=>M.slot&&/^(?:col-\d+|left|right)$/i.test(M.slot)),T=i==="clover"||i==="two-cols-header"||i==="three-cols-header"||Ln(i)&&D,w=M=>{const H=M.filter(O=>!!(O.rawMarkdown||O.content||"").trim());if(T&&H.length>0){const O=H[0],z=(O.rawMarkdown||O.content||"").trim();(zi(O)||/^(?:[-*+]|\d+\.)\s+/.test(z))&&(O.rawMarkdown=In(O.rawMarkdown||O.content||""),O.content=O.rawMarkdown),O.isColFirst=!0}const E=T?H.find(ss):null;return H.map(O=>pi(O,{...t,extraClassName:O===E?"slidev-col-first-heading-block":""})).join(`
`)},R=b.find(ss),N=b.map(M=>pi(M,{...t,extraClassName:M===R?"slidev-page-first-heading-block":""})).join(`
`),F=f?"repeat(2, minmax(0, 1fr))":ns((h=e.frontmatter)==null?void 0:h.layoutRatio,C),q=f?`style="grid-template-columns: ${F}; grid-template-rows: repeat(2, minmax(0, 1fr));"`:`style="grid-template-columns: ${F};"`,_=[f?"layout-clover-container":"layout-cols-header-container",C===2?"layout-two-cols-header-container":"",C===3?"layout-three-cols-header-container":"",`layout-${i}-container`,T?"has-superblock-cols":""].filter(Boolean).join(" "),L=[f?"layout-clover-grid pdf-clover-wrapper":"layout-cols-wrapper layout-cols-grid",C===2?"pdf-two-cols-wrapper layout-two-cols-grid":"",C===3?"pdf-three-cols-wrapper layout-three-cols-grid":"",T?"has-superblock-cols":""].filter(Boolean).join(" "),y=A.map((M,H)=>{const E=H+1;return`<div class="${["pdf-col",C===2&&E===1?"pdf-col--left":"",C===2&&E===2?"pdf-col--right":"",`pdf-col--${E}`,`col-${E}`].filter(Boolean).join(" ")}">${w(M)}</div>`}).join(`
`);return`
      <div class="${_}">
        <div class="layout-header-section">${N}</div>
        <div class="${L}" ${q}>
          ${y}
        </div>
      </div>
    `}if(i==="image-right"||i==="image-left"){const f=i==="image-right",b=o.map(T=>pi(T,t)).join(`
`),k=((v=e.frontmatter)==null?void 0:v.image)||((u=e.frontmatter)==null?void 0:u.background)||"",x=`<div class="pdf-image-col" style="background-image:url('${ot(k)}');background-size:cover;background-position:center;background-repeat:no-repeat;width:100%;height:100%;position:relative;overflow:hidden;"><img src="${ot(k)}" style="width:100%;height:100%;object-fit:cover;object-position:center;display:block;" onerror="this.style.display='none'" alt="Slide cover" /></div>`,C=`<div class="pdf-content-col" style="padding:48px 56px;display:flex;flex-direction:column;justify-content:flex-start;height:100%;box-sizing:border-box;overflow-y:auto;">${b}</div>`,A=f?`${C}
${x}`:`${x}
${C}`;return`
      <div class="layout-image-cols-grid" style="display:grid;grid-template-columns:${ns((m=e.frontmatter)==null?void 0:m.layoutRatio,2)};grid-template-rows:100%;width:100%;height:100%;position:absolute;top:0;left:0;right:0;bottom:0;box-sizing:border-box;">
        ${A}
      </div>
    `}return i==="fact"?`<div class="layout-fact-container">${o.map(b=>pi(b,t)).join(`
`)}</div>`:i==="cover"?`<div class="layout-cover-container">${o.map(b=>pi(b,t)).join(`
`)}</div>`:o.map(f=>pi(f,{...t,extraClassName:f===l?"slidev-page-first-heading-block":""})).join(`
`)}function ot(e){return e?e.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&#039;"):""}function Jm(e){if(!e||e.trim()===""||e.trim()==="all")return"all";const t=new Set,i=e.split("|");for(const n of i){const o=n.trim();if(o==="all")return"all";if(o.includes("-")){const[s,l]=o.split("-"),r=parseInt(s,10),a=parseInt(l,10);if(!isNaN(r)&&!isNaN(a))for(let c=Math.min(r,a);c<=Math.max(r,a);c++)t.add(c)}else{const s=parseInt(o,10);isNaN(s)||t.add(s)}}return t}const Xm=new Set(["kbd","mark","sub","sup","span","a","br","b","i","u","s","del","em","strong","code","small","abbr","ruby","rt","rp","v-mark","img","video","source","picture"]);function lt(e){if(!e)return"";const t=ka(e),i=[],n=t.replace(/<\/?([a-zA-Z0-9_-]+)(?:\s+[^<>]*)?\/?>/g,(s,l)=>{const r=l.toLowerCase();if(!Xm.has(r)||/on\w+\s*=|javascript:/i.test(s))return s;if(r==="v-mark"){const a=s.match(/type=["']?([a-zA-Z-]+)["']?/),c=a?a[1]:"circle";return s.startsWith("</")?i.push("</mark>"):i.push(`<mark class="v-mark v-mark--${c}">`),`%%SAFE_HTML_${i.length-1}%%`}return i.push(s),`%%SAFE_HTML_${i.length-1}%%`});let o=ot(n);return o=o.replace(/\(\(([0-9a-zA-Z-]+)(?:\s*(?:&#039;([^&#]*)&#039;|&quot;([^&]*)&quot;|'([^']*)'|"([^"]*)"|([^\)]+?)))?\s*\)\)/g,(s,l,r,a,c,d,h)=>{const u=(r??a??c??d??h??"").trim()||`Ref(${l.slice(0,8)})`;return`<a href="siyuan://blocks/${l}" data-ref-id="${l}" class="slidev-ref-tag">🔗 ${u}</a>`}),o=o.replace(/\$([^$\n]+)\$/g,'<span class="katex-inline font-math"><em>$1</em></span>'),o=o.replace(/!\[(.*?)\]\((.*?)\)/g,(s,l,r)=>{const c=/\.gif(?:\?|$)/i.test(r)?"slide-inline-img list-item-gif":"slide-inline-img";return`<img alt="${l}" src="${r}" class="${c}" />`}),o=o.replace(/\[(.*?)\]\((.*?)\)/g,(s,l,r)=>{if(r.startsWith("siyuan://blocks/")){const a=r.replace("siyuan://blocks/","").split("?")[0];return`<a href="${r}" data-ref-id="${a}" class="slidev-ref-tag">🔗 ${l}</a>`}return`<a href="${r}" target="_blank" rel="noopener noreferrer" class="slidev-link">${l}</a>`}),o=o.replace(/(^|[\s(])(siyuan:\/\/blocks\/([0-9a-zA-Z-]+)(?:\?[^\s\)]*)?)/g,(s,l,r,a)=>`${l}<a href="${r}" data-ref-id="${a}" class="slidev-ref-tag">🔗 ${r}</a>`),o=o.replace(/\*\*(.*?)\*\*/g,"<strong>$1</strong>"),o=o.replace(/\*(.*?)\*/g,"<em>$1</em>"),o=o.replace(/~~(.*?)~~/g,"<del>$1</del>"),o=o.replace(/`([^`]+)`/g,"<code>$1</code>"),o=o.replace(/%%SAFE_HTML_(\d+)%%/g,(s,l)=>{const r=parseInt(l,10);return i[r]||""}),o}function Qm(e,t="pdf-table"){if(e.length<2)return"";const i=e.map(a=>a.trim().replace(/^\|/,"").replace(/\|$/,"").split("|").map(c=>c.trim())),n=i[0];let o=[],s=1;e.length>=2&&i[1].every(a=>/^:?-+:?$/.test(a))&&(o=i[1].map(a=>a.startsWith(":")&&a.endsWith(":")?"center":a.endsWith(":")?"right":"left"),s=2);const l=`<thead><tr>${n.map((a,c)=>`<th${o[c]?` style="text-align: ${o[c]}"`:""}>${lt(a)}</th>`).join("")}</tr></thead>`,r=i.slice(s).map(a=>`<tr>${a.map((c,d)=>`<td${o[d]?` style="text-align: ${o[d]}"`:""}>${lt(c)}</td>`).join("")}</tr>`).join("");return`<table class="${t}">${l}<tbody>${r}</tbody></table>`}function rs(e){return String(e||"").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;")}function Gr(e,t="ts"){if(!e)return"";if(e.trim().startsWith("//"))return`<span class="token-comment">${rs(e)}</span>`;const i=[];function n(s,l){return i.push(`<span class="${s}">${rs(l)}</span>`),`__TOK_${i.length-1}__`}let o=e.replace(/(['"`])(.*?)\1/g,(s,l,r)=>n("token-string",`${l}${r}${l}`));return o=o.replace(/\b(import|export|from|const|let|var|function|return|default|type|interface|class|new|async|await)\b/g,s=>n("token-keyword",s)),o=o.replace(/\b(computed|ref|number|string|boolean|void|Array)\b/g,s=>n("token-type",s)),o=o.replace(/\b(\d+)\b/g,s=>n("token-number",s)),o=rs(o),o=o.replace(/__TOK_(\d+)__/g,(s,l)=>i[parseInt(l,10)]||""),o}function eg(e,t){if(!e)return null;const i=e.frontmatter||{};if(i.hideInToc===!0||i.hideInToc==="true")return null;let n=(i.title||"").trim(),o=i.level?parseInt(i.level,10):0;if(!n){const s=e.blocks||[];for(const l of s){const a=(l.rawMarkdown||l.content||"").trim().match(/^(#{1,6})\s+(.*)$/);if(a){o||(o=a[1].length),n=a[2].trim();break}}}return n?((!o||isNaN(o))&&(o=1),{pageIndex:e.pageIndex||t,title:n,level:o}):null}function tg(e,t=1,i={}){const n=i.minDepth!==void 0?Number(i.minDepth):1,o=i.maxDepth!==void 0?Number(i.maxDepth):1/0,s=[];Array.isArray(e)&&e.forEach((c,d)=>{const h=eg(c,d+1);h&&s.push(h)});const l=[];let r=null;for(const c of s){const d={...c,active:c.pageIndex===t,hasActiveChild:!1,children:[]};c.level===1||l.length===0?(l.push(d),r=d):r?(d.active&&(r.hasActiveChild=!0),r.children.push(d)):l.push(d)}function a(c,d=1){if(d>o)return[];const h=[];for(const v of c){const u=a(v.children,d+1);d>=n?h.push({...v,children:u}):h.push(...u)}return h}return a(l,1)}function ig(e,t=1,i={}){const n=tg(e,t,i),o=i.columns?Number(i.columns):1,s=o>1?` style="column-count: ${o};"`:"",l=i.textSm?" text-sm":"";function r(c,d=1){if(!c||c.length===0)return"";const h=`slidev-toc-list slidev-toc-list-level-${d}`,v=c.map(u=>{const m=u.active?" slidev-toc-item-active":u.hasActiveChild?" slidev-toc-item-parent-active":"",f=u.children&&u.children.length>0?r(u.children,d+1):"";let b=lt(u.title);return b.includes("LaTeX")&&(b=b.replace(/\$\\LaTeX\$/g,'<span class="font-math">L<sup>A</sup>T<sub>E</sub>X</span>')),`
        <li class="slidev-toc-item${m}" data-page="${u.pageIndex}">
          <a class="slidev-toc-link" href="javascript:void(0)">
            <span class="slidev-toc-title">${b}</span>
          </a>
          ${f}
        </li>
      `}).join("");return`<ol class="${h}">${v}</ol>`}const a=r(n,1);return`<div class="slidev-toc${l}"${s}>${a}</div>`}function pi(e,t){var C,A,D,T,w,R,N,F,q,_;let i="",n="",o="";const s=[];(C=e.motion)!=null&&C.preset&&e.motion.preset!=="none"&&(i=` slidev-motion-${e.motion.preset.toLowerCase()}`,typeof e.motion.duration=="number"&&e.motion.duration>0&&s.push(`--motion-duration:${e.motion.duration}ms`),typeof e.motion.delay=="number"&&e.motion.delay>0&&s.push(`--motion-delay:${e.motion.delay}ms`));const l=((A=e.attributes)==null?void 0:A.style)||"";l&&(s.push(l),o=" slide-styled-block"),s.length>0&&(n=` style="${ot(s.join(";"))}"`);const r=(t==null?void 0:t.containerClassName)||"pdf-block",a=t!=null&&t.extraClassName?` ${t.extraClassName}`:"",c=`${r}${i}${o}${a}`,d=(e.rawMarkdown||e.content||"").trim();if(!d)return`<div class="${c}"${n}></div>`;if(d.includes('class="slidev-block-ref"')||d.includes('class="slidev-ref-tag"'))return`<div class="${c}"${n}>${d}</div>`;if(d.startsWith("$$")&&d.endsWith("$$")){const L=d.slice(2,-2).trim();return`<div class="${c} katex-display-container"${n}><div class="katex-display font-math"><em>${ot(L)}</em></div></div>`}const h=d.match(/^(#{1,6})\s+(.*)$/);if(h){const L=h[1].length,y=lt(h[2]),H=!!(e.isColFirst||e.type==="i"&&((D=t==null?void 0:t.extraClassName)!=null&&D.includes("slidev-col-first-heading-block")))?' class="slide-list-item-title"':"";return`<div class="${c}"${n}><h${L}${H}>${y}</h${L}></div>`}if(d.startsWith(":::")){const L=d.split(`
`),M=L[0].replace(/^:::\s*/,"").trim()||"info",H=L.slice(1,L[L.length-1].startsWith(":::")?-1:void 0).join(`
`),E=(t==null?void 0:t.calloutClassName)||"pdf-callout";return`<div class="${c}"${n}><div class="${E} ${E}--${M}"><div class="${E}-title">${M.toUpperCase()}</div><div class="${E}-body">${lt(H)}</div></div></div>`}if(d.startsWith("<<<")){const M=`// Inside ./snippets/external.ts
export function emptyArray<T>(length: number) {
  return Array.from<T>({ length })
}`.split(`
`).map((z,X)=>`<span class="code-line shiki-focus"><span class="line-no">${X+1}</span><span class="line-content">${Gr(z,"ts")}</span></span>`).join(`
`),H=(t==null?void 0:t.codeClassName)||"pdf-code shiki-container",E=((T=e.attrs)==null?void 0:T["custom-slidev-max-height"])||e.maxHeight||"",O=E?` style="max-height:${ot(E)};overflow-y:auto;"`:"";return`<div class="${c}"${n}><pre class="${H}"${O}><span class="lang-badge">TS</span><code>${M}</code></pre></div>`}if(d.startsWith("<style")||d.startsWith("<!-- Inline style -->")||d.startsWith(`<!--
Notes`))return"";if(d.startsWith("```")){const L=d.split(`
`),y=L[0].slice(3).trim(),M=y.match(/^([^\s{\[]+)/),H=M?M[1]:"",E=y.match(/\[([^\]]+)\]/),O=E?E[1]:"",z=y.includes("twoslash"),X=e.shikiLines||((w=y.match(/\{([^}]+)\}/))==null?void 0:w[1])||"",Z=Jm(X),W=L.length>2?L[L.length-1]==="```"?L.slice(1,-1):L.slice(1):[d.slice(3).replace(/```$/,"")],ie=(t==null?void 0:t.codeClassName)||"pdf-code shiki-container",se=O?`${ie} has-filename`:ie,re=Z!=="all",ue=W.map((ce,P)=>{const j=P+1,K=Z==="all"||Z.has(j)?"code-line shiki-focus":re?"code-line shiki-dimmed":"code-line";let S=(t==null?void 0:t.highlight)===!0?Gr(ce,H):ot(ce);return z&&ce.includes("doubled.value = 2")?(S=S.replace(/(\bvalue\b)/,'<span class="twoslash-error-wavy">$1</span>'),`<span class="${K}"><span class="line-no">${j}</span><span class="line-content">${S}</span></span>
<div class="twoslash-popup-error"><span style="color:#ef4444;font-weight:bold;margin-right:4px;">✕</span> Cannot assign to 'value' because it is a read-only property.</div>`):`<span class="${K}"><span class="line-no">${j}</span><span class="line-content">${S}</span></span>`}).join(`
`),Ie=H?`<span class="lang-badge">${ot(H)}</span>`:"",be=O?`<span class="code-filename">${ot(O)}</span>`:"",ae=((R=e.attrs)==null?void 0:R["custom-slidev-max-height"])||e.maxHeight||"",Y=ae?` style="max-height:${ot(ae)};overflow-y:auto;"`:"";return`<div class="${c}"${n}><pre class="${se}"${Y}>${be}${Ie}<code>${ue}</code></pre></div>`}if(d.includes("|")&&d.split(`
`).filter(L=>L.trim().startsWith("|")).length>=2){const L=d.split(`
`).filter(M=>M.trim().startsWith("|")),y=Qm(L,t==null?void 0:t.tableClassName);return`<div class="${c}"${n}>${y}</div>`}if(d.startsWith("> ")){const L=(t==null?void 0:t.quoteClassName)||"pdf-quote";return`<div class="${c}"${n}><blockquote class="${L}"><p>${lt(d.slice(2))}</p></blockquote></div>`}const v=/<video\b/i.test(d)||e.type==="video"||e.type==="NodeVideo",u=/^(\s*)([-*+]|\d+\.)\s+/m.test(d),m=/(?:^|\n)\s*#{1,6}\s+/.test(d);if(v&&!u&&!m&&!d.includes(`
`)){const L=((N=e.attributes)==null?void 0:N["custom-slidev-autoplay"])==="true"||/autoplay/i.test(d),y=((F=e.attributes)==null?void 0:F["custom-slidev-loop"])==="true"||/loop/i.test(d),M=((q=e.attributes)==null?void 0:q["custom-slidev-muted"])==="true"||L||/muted/i.test(d),H=((_=e.attributes)==null?void 0:_["custom-slidev-controls"])==="false",E=d.match(/\bsrc=["']([^"']+)["']/i),O=E?E[1]:"",z=['class="slide-video-player"'];H||z.push("controls"),L&&(z.push("autoplay"),z.push("playsinline")),y&&z.push("loop"),M&&z.push("muted"),z.push('preload="metadata"'),O&&z.push(`src="${O}"`);const X=d.match(/<video[^>]*>([\s\S]*?)<\/video>/i);let Z=X?X[1].trim():"";return!Z&&O&&(Z=`<source src="${O}" type="video/mp4" />您的浏览器不支持视频播放。`),`<div class="${c} ${c}--video slide-media-block slide-video-container slide-media-container" data-autoplay="${L?"true":"false"}" data-muted="${M?"true":"false"}"${n}><video ${z.join(" ")}>${Z}</video></div>`}const f=d.match(/^!\[(.*?)\]\((.*?)\)$/);if(f){const L=(t==null?void 0:t.imageClassName)||"pdf-image slide-media-img";return`<div class="${c} ${c}--image slide-media-block slide-media-container"${n}><img alt="${ot(f[1])}" src="${f[2]}" class="${L}" /></div>`}const b=Ma(d,t,e);if(b)return`<div class="${c} pdf-list-item"${n}>${b}</div>`;if(/<(?:Toc|toc)\b/i.test(d)&&!d.startsWith("```")){const L=d.match(/minDepth=["']?(\d+)["']?/i),y=d.match(/maxDepth=["']?(\d+)["']?/i),M=d.match(/columns=["']?(\d+)["']?/i),H=(t==null?void 0:t.allSlides)||[];return`<div class="${c}"${n}>${ig(H,(t==null?void 0:t.currentPageIndex)||1,{minDepth:L?parseInt(L[1],10):1,maxDepth:y?parseInt(y[1],10):1/0,columns:M?parseInt(M[1],10):1,textSm:d.includes("text-sm")})}</div>`}if(d.includes(`
`)||m){const L=Ym(d,t,e);if(L)return`<div class="${c}"${n}>${L}</div>`}const x=!!e.isColFirst?' class="slide-list-item-title"':"";return`<div class="${c}"${n}><p${x}>${lt(d)}</p></div>`}function ng(e){return`
    ${En(e)}

    :root {
      --slide-bg: #ffffff;
      --slide-text: #1a1a1a;
      --slide-accent: #3b82f6;
      --slide-font: system-ui, -apple-system, sans-serif;
    }
    [data-theme="dark"] {
      --slide-bg: #121214;
      --slide-text: #e2e8f0;
      --slide-accent: #60a5fa;
    }

    /* 1. 默认科技主题 Default */
    [data-slidev-theme="default"],
    .slidev-theme-default {
      --slide-font: system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "PingFang SC", "Microsoft YaHei", sans-serif;
      --slide-accent: #10b981;
    }
    [data-theme="light"][data-slidev-theme="default"],
    [data-theme="light"] .slidev-theme-default {
      --slide-bg: #ffffff;
      --slide-text: #1e293b;
      --slide-accent: #059669;
    }
    [data-theme="dark"][data-slidev-theme="default"],
    [data-theme="dark"] .slidev-theme-default {
      --slide-bg: #121214;
      --slide-text: #e2e8f0;
      --slide-accent: #34d399;
    }
    .slidev-theme-default .layout-cover h1,
    .slidev-theme-default .layout-cover .slide-block h1 {
      font-size: 3.8rem !important;
      font-weight: 800 !important;
      line-height: 1.15 !important;
      letter-spacing: -0.025em !important;
      margin-bottom: 18px !important;
      background: linear-gradient(135deg, #10b981, #06b6d4) !important;
      -webkit-background-clip: text !important;
      -webkit-text-fill-color: transparent !important;
    }
    .slidev-theme-default .layout-cover h2,
    .slidev-theme-default .layout-cover .slide-block h2 {
      font-size: 1.85rem !important;
      font-weight: 600 !important;
      opacity: 0.85 !important;
      margin-bottom: 12px !important;
    }
    .slidev-theme-default .layout-cover p,
    .slidev-theme-default .layout-cover .slide-block p {
      font-size: 1.45rem !important;
      line-height: 1.5 !important;
      opacity: 0.85 !important;
    }

    /* 2. 优雅衬线主题 Seriph */
    [data-slidev-theme="seriph"],
    .slidev-theme-seriph {
      --slide-font: "PT Serif", "Charter", "Georgia", "Cambria", "Times New Roman", "Source Han Serif SC", "Noto Serif SC", "Songti SC", "SimSun", serif;
      --slide-accent: #b45309;
      letter-spacing: 0.015em;
    }
    [data-theme="light"][data-slidev-theme="seriph"],
    [data-theme="light"] .slidev-theme-seriph {
      --slide-bg: #fdfbf7;
      --slide-text: #2a2521;
      --slide-accent: #b45309;
    }
    [data-theme="dark"][data-slidev-theme="seriph"],
    [data-theme="dark"] .slidev-theme-seriph {
      --slide-bg: #1c1a17;
      --slide-text: #e8e3d9;
      --slide-accent: #f59e0b;
    }
    .slidev-theme-seriph,
    .slidev-theme-seriph .slide-content {
      font-family: var(--slide-font) !important;
      line-height: 1.72;
    }
    .slidev-theme-seriph h1,
    .slidev-theme-seriph h2,
    .slidev-theme-seriph h3 {
      font-family: var(--slide-font) !important;
      letter-spacing: 0.025em;
      font-weight: 700;
    }
    .slidev-theme-seriph .layout-cover h1 {
      background: none !important;
      -webkit-background-clip: initial !important;
      -webkit-text-fill-color: initial !important;
      color: var(--slide-accent) !important;
      font-size: 3.4rem !important;
      border-bottom: 2px solid var(--slide-accent);
      display: inline-block;
      padding-bottom: 10px;
    }

    /* 3. 极简发布会主题 Apple Basic */
    [data-slidev-theme="apple-basic"],
    .slidev-theme-apple-basic {
      --slide-font: -apple-system, "SF Pro Display", "SF Pro Text", BlinkMacSystemFont, "PingFang SC", "Helvetica Neue", sans-serif;
      --slide-accent: #0071e3;
    }
    [data-theme="light"][data-slidev-theme="apple-basic"],
    [data-theme="light"] .slidev-theme-apple-basic {
      --slide-bg: #ffffff;
      --slide-text: #1d1d1f;
      --slide-accent: #0071e3;
    }
    [data-theme="dark"][data-slidev-theme="apple-basic"],
    [data-theme="dark"] .slidev-theme-apple-basic {
      --slide-bg: #000000;
      --slide-text: #f5f5f7;
      --slide-accent: #2997ff;
    }
    .slidev-theme-apple-basic,
    .slidev-theme-apple-basic .slide-content {
      font-family: var(--slide-font) !important;
    }
    .slidev-theme-apple-basic h1,
    .slidev-theme-apple-basic h2,
    .slidev-theme-apple-basic h3 {
      letter-spacing: -0.035em;
      font-weight: 800;
    }
    .slidev-theme-apple-basic .layout-cover h1 {
      background: none !important;
      -webkit-background-clip: initial !important;
      -webkit-text-fill-color: initial !important;
      color: var(--slide-text) !important;
      font-size: 3.8rem !important;
      letter-spacing: -0.04em !important;
    }
    .slidev-theme-apple-basic .layout-cover p {
      color: #86868b !important;
      font-size: 1.35rem !important;
    }

    * { box-sizing: border-box; margin: 0; padding: 0; }
    html, body {
      width: 100%; height: 100%; overflow: hidden;
      background: #0f1115; font-family: var(--slide-font);
      display: flex; justify-content: center; align-items: center;
    }
    #app { width: 100%; height: 100%; position: relative; overflow: hidden; }
    .slide-viewport {
      position: absolute; left: 50%; top: 50%;
      background: var(--slide-bg); color: var(--slide-text);
      box-shadow: 0 10px 30px rgba(0,0,0,0.5); border-radius: 8px; overflow: hidden;
      display: flex; flex-direction: column; flex-shrink: 0;
      transform: translate(-50%, -50%) scale(var(--slidev-slide-scale, 1));
      transform-origin: center center; will-change: transform;
      transition: background 0.3s ease, color 0.3s ease, border-radius 0.2s ease, box-shadow 0.2s ease;
    }
    :fullscreen .slide-viewport, .is-fullscreen .slide-viewport {
      border-radius: 0 !important; box-shadow: none !important;
    }
    .slide-content {
      position: relative;
      width: 100%;
      height: 100%;
      min-height: 100%;
      flex: 1 1 0%;
      padding: var(--slidev-padding-y, 32px) var(--slidev-padding-x, 48px);
      display: flex;
      flex-direction: column;
      overflow: hidden;
      box-sizing: border-box;
    }

    /* 间距预设风格 */
    .slide-content.spacing-compact,
    .slide-viewport[data-spacing="compact"] .slide-content,
    [data-slidev-spacing="compact"] {
      --slidev-padding-y: 20px;
      --slidev-padding-x: 36px;
      --slidev-header-gap: 10px;
      --slidev-title-margin-bottom: 6px;
    }
    .slide-content.spacing-normal,
    .slide-viewport[data-spacing="normal"] .slide-content,
    [data-slidev-spacing="normal"] {
      --slidev-padding-y: 32px;
      --slidev-padding-x: 48px;
      --slidev-header-gap: 16px;
      --slidev-title-margin-bottom: 10px;
    }
    .slide-content.spacing-loose,
    .slide-viewport[data-spacing="loose"] .slide-content,
    [data-slidev-spacing="loose"] {
      --slidev-padding-y: 48px;
      --slidev-padding-x: 56px;
      --slidev-header-gap: 24px;
      --slidev-title-margin-bottom: 16px;
    }

    .layout-cover { justify-content: center; align-items: center; text-align: center; }
    .layout-cover h1, .layout-cover .slide-block h1 { font-size: 3.8rem !important; font-weight: 800 !important; line-height: 1.15 !important; letter-spacing: -0.025em !important; margin-bottom: 16px !important; }
    .layout-cover h2, .layout-cover .slide-block h2 { font-size: 1.85rem !important; font-weight: 600 !important; opacity: 0.85 !important; margin-bottom: 12px !important; }
    .layout-cover p, .layout-cover .slide-block p { font-size: 1.45rem !important; line-height: 1.5 !important; opacity: 0.85 !important; }
    .two-cols-left, .two-cols-right { min-width: 0; width: 100%; display: flex; flex-direction: column; box-sizing: border-box; overflow-wrap: break-word; word-break: break-word; }
    .pdf-two-cols-wrapper,
    .layout-two-cols-grid,
    .layout-cols-wrapper,
    .layout-cols-grid {
      display: grid;
      grid-template-columns: var(--slide-grid-cols, minmax(0, 1fr) minmax(0, 1fr));
      grid-template-rows: minmax(0, 1fr) !important;
      gap: 32px;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      overflow: hidden !important;
    }
    .layout-cols-header-container,
    .layout-two-cols-header-container,
    .layout-three-cols-header-container,
    .layout-clover-container {
      display: flex;
      flex-direction: column;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      overflow: hidden !important;
    }
    .layout-header-section {
      width: 100%;
      margin-bottom: var(--slidev-header-gap, 16px) !important;
      flex-shrink: 0;
    }
    .layout-header-section h1,
    .layout-header-section h2,
    .layout-header-section h3 {
      margin-bottom: var(--slidev-title-margin-bottom, 10px) !important;
    }
    .pdf-three-cols-wrapper,
    .layout-three-cols-grid {
      display: grid;
      grid-template-columns: var(--slide-grid-cols, minmax(0, 1fr) minmax(0, 1fr) minmax(0, 1fr));
      grid-template-rows: minmax(0, 1fr) !important;
      gap: 24px;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      box-sizing: border-box;
      overflow: hidden !important;
    }
    .pdf-clover-wrapper,
    .layout-clover-grid {
      display: grid;
      grid-template-columns: repeat(2, minmax(0, 1fr)) !important;
      grid-template-rows: repeat(2, minmax(0, 1fr)) !important;
      gap: 20px;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      box-sizing: border-box;
      overflow: hidden !important;
    }
    .layout-clover-grid .pdf-col {
      background: transparent !important;
      border: none !important;
      box-shadow: none !important;
    }
    .pdf-col {
      display: flex;
      flex-direction: column;
      gap: 14px;
      min-width: 0;
      width: 100%;
      max-width: 100%;
      height: 100%;
      max-height: 100%;
      min-height: 0;
      justify-content: flex-start;
      box-sizing: border-box;
      overflow: hidden;
      overflow-wrap: break-word;
      word-break: break-word;
      white-space: normal;
    }
    .pdf-col * {
      overflow-wrap: break-word;
      word-break: break-word;
      box-sizing: border-box;
    }
    /* 表头多栏内超级块子块首个列表项去圆点后居中显示标题/首行文本 (仅在存在超级块分栏时生效) */
    .has-superblock-cols .pdf-col > *:first-child .slide-list-item-title,
    .has-superblock-cols .pdf-col > *:first-child :is(h1, h2, h3, h4, h5, h6),
    .has-superblock-cols .pdf-col > *:first-child p.slide-list-item-title,
    .has-superblock-cols .pdf-col > *:first-child p:first-of-type,
    .has-superblock-cols .pdf-col > *:first-child p:first-child,
    .has-superblock-cols .pdf-col > *:first-child :is(ul, ol) > li:first-child,
    .has-superblock-cols .pdf-col > *:first-child .slide-list > .slide-list-item:first-child,
    .has-superblock-cols .pdf-col > *:first-child .pdf-list > li:first-child,
    .has-superblock-cols .slidev-col-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    .has-superblock-cols .slidev-col-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      list-style: none !important;
      list-style-type: none !important;
      text-align: center !important;
      margin-left: 0 !important;
      padding-left: 0 !important;
      width: 100% !important;
    }

    /* 彻底清除首个列表项的原生圆点 Marker (仅在存在超级块分栏时生效) */
    .has-superblock-cols .pdf-col > *:first-child :is(ul, ol) > li:first-child::marker {
      content: "" !important;
      display: none !important;
    }

    /* 确保首个列表项内部内联与块级元素居中 (仅在存在超级块分栏时生效) */
    .has-superblock-cols .pdf-col > *:first-child :is(ul, ol) > li:first-child * {
      text-align: center !important;
    }

    /* 栏内说明段落与列表项：左对齐，自然阅读排版 */
    .has-superblock-cols .pdf-col .slide-list-item-desc,
    .has-superblock-cols .pdf-col li:not(:first-child) {
      text-align: left !important;
    }

    /* 全局特定标题大小规范化 (除封面外页首首个标题按 H2 1.7rem，表头多栏内首个标题按 H3 1.3rem) */
    [data-normalize-headings="true"] .slidev-page-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .slidev-page-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .slide-content:not(.layout-cover) > :is(.pdf-block, .slide-block):first-child :is(h1, h2, h3, h4, h5, h6),
    [data-normalize-headings="true"] .slide-content:not(.layout-cover) > .layout-header-section :is(.pdf-block, .slide-block):first-child :is(h1, h2, h3, h4, h5, h6),
    [data-normalize-headings="true"] .slide-content:not(.layout-cover) > :not(.layout-cols-wrapper):not(.pdf-two-cols-wrapper):not(.layout-image-cols-grid):first-child :is(h1, h2, h3, h4, h5, h6) {
      font-size: 1.7rem !important;
      font-weight: 600 !important;
      line-height: 1.25 !important;
      margin-bottom: 10px !important;
    }

    [data-normalize-headings="true"] .has-superblock-cols .slidev-col-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .has-superblock-cols .slidev-col-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .has-superblock-cols .pdf-col > *:first-child :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      font-size: 1.3rem !important;
      font-weight: 600 !important;
      line-height: 1.3 !important;
      margin-bottom: 8px !important;
      text-align: center !important;
    }

    /* 图左与图右版式标题完全保留用户原始字号与默认排版，不进行任何固定大小规范化 */
    [data-normalize-headings="true"] :is(.layout-image-left, .layout-image-right, .image-left-content, .image-right-content) :is(h1, h2, h3, h4, h5, h6) {
      text-align: left !important;
    }
    .pdf-col pre,
    .two-cols-left pre,
    .two-cols-right pre,
    .image-right-content pre,
    .image-left-content pre {
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      overflow-x: hidden !important;
      overflow-y: auto !important;
      max-width: 100% !important;
      box-sizing: border-box !important;
    }
    .slide-content.layout-image-right, .slide-content.layout-image-left {
      padding: 0;
      display: grid;
      grid-template-columns: var(--slide-grid-cols, minmax(0, 1fr) minmax(0, 1fr));
      grid-template-rows: 100%;
      width: 100%;
      height: 100%;
      position: absolute;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      box-sizing: border-box;
    }
    .image-right-content, .image-left-content {
      padding: 44px 50px;
      display: flex;
      flex-direction: column;
      justify-content: flex-start;
      overflow-y: auto;
      width: 100%;
      height: 100%;
      box-sizing: border-box;
    }
    .image-right-img-container, .image-left-img-container {
      width: 100%;
      height: 100%;
      overflow: hidden;
      position: relative;
      background: #18181b;
      display: flex;
      align-items: center;
      justify-content: center;
    }
    .image-right-img, .image-left-img {
      width: 100%;
      height: 100%;
      object-fit: cover;
      object-position: center;
      display: block;
    }
    .slide-block { margin-bottom: 14px; line-height: 1.6; }
    .slide-block h1 { font-size: 2.2rem; margin-bottom: 12px; }
    .slide-block h2 { font-size: 1.7rem; margin-bottom: 10px; }
    .slide-block p { font-size: 1.15rem; }
    .slide-block ul, .slide-block ol, .pdf-list {
      padding-left: 28px;
      margin: 8px 0;
      display: flex;
      flex-direction: column;
      gap: 6px;
    }
    .slide-block li, .pdf-list li {
      font-size: 1.15rem;
      line-height: 1.6;
    }
    .pdf-task-item {
      list-style: none;
      margin-left: -20px;
      display: flex;
      align-items: center;
      gap: 8px;
    }
    .pdf-task-item input[type="checkbox"] {
      width: 1.15em;
      height: 1.15em;
      cursor: pointer;
    }

    /* 两栏与三栏及多栏（超级块分栏）布局：紧凑自然行距，子列表保留圆点与层级缩进 */
    .layout-two-cols ul,
    .layout-cols-header ul,
    .layout-two-cols-header ul,
    .layout-three-cols ul,
    .layout-three-cols-header ul,
    .two-cols-left ul,
    .two-cols-right ul,
    .three-cols-col ul,
    .col ul,
    .pdf-col ul,
    .layout-two-cols-grid .pdf-list,
    .layout-three-cols-grid .pdf-list,
    .layout-cols-grid .pdf-list,
    .layout-two-cols-grid .pdf-list--unordered,
    .layout-three-cols-grid .pdf-list--unordered,
    .layout-cols-grid .pdf-list--unordered {
      list-style: disc !important;
      list-style-type: disc !important;
      padding-left: 1.25em !important;
      margin-left: 0 !important;
      margin-top: 0 !important;
      margin-bottom: 8px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: block !important;
    }

    .layout-two-cols ol,
    .layout-cols-header ol,
    .layout-two-cols-header ol,
    .layout-three-cols ol,
    .layout-three-cols-header ol,
    .two-cols-left ol,
    .two-cols-right ol,
    .three-cols-col ol,
    .col ol,
    .pdf-col ol,
    .layout-two-cols-grid .pdf-list--ordered,
    .layout-three-cols-grid .pdf-list--ordered,
    .layout-cols-grid .pdf-list--ordered {
      list-style: decimal !important;
      list-style-type: decimal !important;
      padding-left: 1.25em !important;
      margin-left: 0 !important;
      margin-top: 0 !important;
      margin-bottom: 8px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: block !important;
    }

    .layout-two-cols li,
    .layout-cols-header li,
    .layout-two-cols-header li,
    .layout-three-cols li,
    .layout-three-cols-header li,
    .two-cols-left li,
    .two-cols-right li,
    .three-cols-col li,
    .col li,
    .pdf-col li,
    .pdf-col .pdf-list-item {
      padding-left: 0.2em !important;
      margin-left: 0 !important;
      margin-bottom: 6px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: list-item !important;
      line-height: 1.6 !important;
    }

    .layout-two-cols ul ul,
    .layout-three-cols ul ul,
    .three-cols-col ul ul,
    .pdf-col ul ul {
      list-style: circle !important;
      list-style-type: circle !important;
      padding-left: 1.25em !important;
      margin-top: 4px !important;
      margin-bottom: 4px !important;
    }

    /* 列表项内嵌标题与说明排版 */
    .slide-list-item-title,
    .pdf-list li > h1,
    .pdf-list li > h2,
    .pdf-list li > h3,
    .pdf-list li > h4,
    .pdf-list li > h5,
    .pdf-list li > h6,
    li > h1.slide-list-item-title,
    li > h2.slide-list-item-title,
    li > h3.slide-list-item-title,
    li > h4.slide-list-item-title {
      margin-top: 2px !important;
      margin-bottom: 6px !important;
      line-height: 1.35 !important;
      font-weight: 700 !important;
    }
    .pdf-list li > h1, li > h1.slide-list-item-title { font-size: 1.6rem !important; }
    .pdf-list li > h2, li > h2.slide-list-item-title { font-size: 1.4rem !important; }
    .pdf-list li > h3, li > h3.slide-list-item-title { font-size: 1.22rem !important; }
    .pdf-list li > h4, li > h4.slide-list-item-title { font-size: 1.1rem !important; }

    /* 全局特定标题大小规范化后置强力锁定 (防止被列表项内部字号覆盖) */
    [data-normalize-headings="true"] .slidev-page-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .slidev-page-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      font-size: 1.7rem !important;
      font-weight: 600 !important;
      line-height: 1.25 !important;
      margin-bottom: 10px !important;
    }
    [data-normalize-headings="true"] .slidev-col-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .slidev-col-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] :is(.layout-cols-wrapper, .pdf-two-cols-wrapper, .layout-cols-header-container, .layout-cols-grid) .pdf-col > *:first-child :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] :is(.two-cols-left, .two-cols-right, .pdf-col, .col) > *:first-child :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      font-size: 1.3rem !important;
      font-weight: 600 !important;
      line-height: 1.3 !important;
      margin-bottom: 8px !important;
      text-align: center !important;
    }
    .slide-list-item-desc,
    .pdf-list li > p {
      margin-top: 4px !important;
      margin-bottom: 6px !important;
      font-size: 1.05rem;
      line-height: 1.55;
      opacity: 0.92;
    }

    /* 多媒体（GIF动图、静态图片、MP4视频）全视口最大化自适应且不超出视口 */
    .slide-media-block,
    .slide-media-container,
    .slide-video-container,
    .slide-block--media,
    .slide-block--image,
    .slide-block--video,
    .slide-block:has(> img),
    .slide-block:has(> .slide-media-container),
    .slide-block:has(> p > img:only-child),
    .slide-block:has(> .slide-video-container),
    .slide-block:has(> video) {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      min-width: 0 !important;
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
      justify-content: center !important;
      width: 100% !important;
      height: 100% !important;
      max-height: 100% !important;
      overflow: hidden !important;
      margin: 4px 0 !important;
      box-sizing: border-box !important;
    }

    .two-cols-left > .slide-block,
    .two-cols-right > .slide-block,
    .three-cols-col > .slide-block,
    .pdf-col > .slide-block,
    .pdf-col .slide-block {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      max-height: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      width: 100% !important;
      height: 100% !important;
      box-sizing: border-box !important;
      overflow: hidden !important;
      margin-bottom: 0 !important;
    }

    /* 列内列表项的标题与段落文字：固定高度，不压缩 */
    .two-cols-left .slide-list-item-title,
    .two-cols-right .slide-list-item-title,
    .three-cols-col .slide-list-item-title,
    .pdf-col .slide-list-item-title,
    .two-cols-left h1, .two-cols-left h2, .two-cols-left h3, .two-cols-left h4, .two-cols-left h5, .two-cols-left h6,
    .two-cols-right h1, .two-cols-right h2, .two-cols-right h3, .two-cols-right h4, .two-cols-right h5, .two-cols-right h6,
    .three-cols-col h1, .three-cols-col h2, .three-cols-col h3, .three-cols-col h4, .three-cols-col h5, .three-cols-col h6,
    .pdf-col h1, .pdf-col h2, .pdf-col h3, .pdf-col h4, .pdf-col h5, .pdf-col h6,
    .three-cols-col .slide-list-item-desc,
    .pdf-col .slide-list-item-desc {
      flex: 0 0 auto !important;
      margin-top: 0 !important;
      margin-bottom: 6px !important;
    }

    /* 列内媒体容器：填满标题下方所有剩余垂直空间，纵向顶部对齐，横向居中，无溢出 */
    .two-cols-left .slide-list-media,
    .two-cols-right .slide-list-media,
    .three-cols-col .slide-list-media,
    .pdf-col .slide-list-media,
    .two-cols-left .slide-video-container,
    .two-cols-right .slide-video-container,
    .three-cols-col .slide-video-container,
    .pdf-col .slide-video-container,
    .two-cols-left .slide-media-container,
    .two-cols-right .slide-media-container,
    .three-cols-col .slide-media-container,
    .pdf-col .slide-media-container {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      min-width: 0 !important;
      width: 100% !important;
      height: 100% !important;
      max-height: 100% !important;
      max-width: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
      justify-content: flex-start !important;
      overflow: hidden !important;
      margin: 0 !important;
      padding: 0 !important;
      box-sizing: border-box !important;
    }

    /* 列内多媒体播放器：以 contain 模式等比缩放完整可见，绝对不超高超宽、不产生遮挡与滚动条 */
    .two-cols-left video,
    .two-cols-right video,
    .three-cols-col video,
    .pdf-col video,
    .two-cols-left img,
    .two-cols-right img,
    .three-cols-col img,
    .pdf-col img,
    .two-cols-left .slide-video-player,
    .two-cols-right .slide-video-player,
    .three-cols-col .slide-video-player,
    .pdf-col .slide-video-player,
    .layout-three-cols-grid video,
    .layout-two-cols-grid video,
    .layout-three-cols-grid img,
    .layout-two-cols-grid img {
      max-width: 100% !important;
      max-height: 100% !important;
      width: auto !important;
      height: auto !important;
      min-width: 0 !important;
      min-height: 0 !important;
      object-fit: contain !important;
      display: block !important;
      margin: 0 auto !important;
      cursor: zoom-in;
    }

    .slide-block img,
    .slide-media-img,
    .slide-media-container img,
    .slide-video-player,
    video.slide-video-player,
    .slide-block video {
      max-width: 100% !important;
      max-height: 100% !important;
      width: auto !important;
      height: auto !important;
      min-width: 0 !important;
      min-height: 0 !important;
      object-fit: contain !important;
      display: block !important;
      margin: 0 auto !important;
      border-radius: 8px;
      box-shadow: 0 4px 16px rgba(0, 0, 0, 0.16);
      background: transparent;
      outline: none;
      cursor: zoom-in;
    }

    .slide-list-media {
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
      justify-content: flex-start !important;
      width: 100% !important;
      max-width: 100% !important;
      height: 100% !important;
      max-height: 100% !important;
      flex: 1 1 0% !important;
      margin-top: 4px !important;
      margin-bottom: 4px !important;
      min-height: 0 !important;
      overflow: hidden !important;
      box-sizing: border-box !important;
    }
    .slide-list-media img,
    .slide-list-media video,
    .slide-list-media .list-item-gif,
    .slide-list-media .slide-video-player {
      max-width: 100% !important;
      max-height: 100% !important;
      width: auto !important;
      height: auto !important;
      min-width: 0 !important;
      min-height: 0 !important;
      object-fit: contain !important;
      border-radius: 6px !important;
      box-shadow: 0 3px 12px rgba(0, 0, 0, 0.14) !important;
      display: block !important;
      margin: 0 auto !important;
      cursor: zoom-in;
    }

    .slide-block:has(.slide-list-media) {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      height: 100% !important;
      max-height: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      overflow: hidden !important;
    }
    .slide-block:has(.slide-list-media) .pdf-list,
    .slide-block:has(.slide-list-media) ul,
    .slide-block:has(.slide-list-media) ol {
      display: block !important;
      flex: 1 1 auto;
      min-height: 0;
      max-height: 100%;
      overflow: visible !important;
      list-style: disc !important;
      list-style-type: disc !important;
    }
    .slide-block:has(.slide-list-media) li,
    .slide-block:has(.slide-list-media) .slide-list-item,
    .slide-block:has(.slide-list-media) .pdf-list-item,
    .slide-block:has(.slide-media-container) li,
    .slide-block:has(.slide-video-container) li,
    .layout-cols-wrapper li:has(.slide-list-media),
    .layout-cols-header-container li:has(.slide-list-media),
    .two-cols-left li:has(.slide-list-media),
    .two-cols-right li:has(.slide-list-media),
    .three-cols-col li:has(.slide-list-media),
    .pdf-col li:has(.slide-list-media),
    li:has(.slide-list-media),
    li:has(.slide-video-container),
    li:has(.slide-media-container) {
      display: list-item !important;
      list-style-type: disc !important;
      flex: 0 0 auto !important;
      height: auto !important;
      max-height: none !important;
      overflow: visible !important;
      margin-bottom: 6px !important;
    }

    .layout-two-cols .slide-media-block,
    .layout-two-cols .slide-video-container,
    .layout-two-cols .slide-media-container,
    .layout-three-cols .slide-media-block,
    .layout-three-cols .slide-video-container,
    .layout-three-cols .slide-media-container {
      max-width: 100% !important;
      max-height: 100% !important;
      width: 100% !important;
      height: 100% !important;
      min-width: 0 !important;
      min-height: 0 !important;
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
      justify-content: flex-start !important;
      overflow: hidden !important;
    }

    /* Lightbox 大图与视频灯箱模态窗口 */
    .slidev-lightbox {
      position: fixed;
      top: 0;
      left: 0;
      width: 100vw;
      height: 100vh;
      background: rgba(0, 0, 0, 0.88);
      backdrop-filter: blur(8px);
      z-index: 999999;
      display: none;
      align-items: center;
      justify-content: center;
      cursor: zoom-out;
      opacity: 0;
      transition: opacity 0.2s cubic-bezier(0.16, 1, 0.3, 1);
    }
    .slidev-lightbox.active {
      display: flex;
      opacity: 1;
    }
    .slidev-lightbox-content {
      position: relative;
      max-width: 92vw;
      max-height: 92vh;
      display: flex;
      align-items: center;
      justify-content: center;
      cursor: default;
    }
    .slidev-lightbox-img {
      max-width: 92vw;
      max-height: 92vh;
      object-fit: contain;
      border-radius: 8px;
      box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.75);
    }
    .slidev-lightbox-video {
      max-width: 92vw;
      max-height: 92vh;
      border-radius: 8px;
      box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.75);
    }
    .slidev-lightbox-close {
      position: absolute;
      top: 24px;
      right: 28px;
      width: 40px;
      height: 40px;
      background: rgba(255, 255, 255, 0.2);
      border: 1px solid rgba(255, 255, 255, 0.35);
      border-radius: 50%;
      color: #fff;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 22px;
      cursor: pointer;
      transition: background 0.2s, transform 0.2s;
      z-index: 1000000;
    }
    .slidev-lightbox-close:hover {
      background: rgba(255, 255, 255, 0.35);
      transform: scale(1.05);
    }

    img.slide-inline-img {
      max-width: 100% !important;
      max-height: min(320px, 40vh) !important;
      object-fit: contain !important;
      vertical-align: middle;
      border-radius: 4px;
    }
    kbd {
      display: inline-block;
      padding: 2px 7px;
      font-family: ui-monospace, SFMono-Regular, "SF Mono", Menlo, Consolas, "Liberation Mono", monospace;
      font-size: 0.85em;
      font-weight: 600;
      line-height: 1.25;
      color: inherit;
      background: rgba(125, 125, 125, 0.12);
      border: 1px solid rgba(125, 125, 125, 0.35);
      border-bottom-width: 2px;
      border-radius: 5px;
      box-shadow: 0 1px 2px rgba(0, 0, 0, 0.12);
      margin: 0 2px;
      vertical-align: middle;
      white-space: nowrap;
    }
    [data-theme="dark"] kbd, .theme-dark kbd {
      background: rgba(255, 255, 255, 0.1);
      border-color: rgba(255, 255, 255, 0.25);
      border-bottom-color: rgba(255, 255, 255, 0.4);
      color: #f1f5f9;
      box-shadow: 0 1px 2px rgba(0, 0, 0, 0.4);
    }
    .slide-block pre,
    pre {
      background: rgba(0, 0, 0, 0.1);
      padding: 12px;
      border-radius: 6px;
      font-family: "JetBrains Mono", Consolas, monospace;
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      overflow-x: hidden !important;
      overflow-y: auto !important;
      max-width: 100% !important;
      box-sizing: border-box !important;
    }
    .slide-block pre code,
    pre code {
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      display: block !important;
      width: 100% !important;
      box-sizing: border-box !important;
    }
    .code-line {
      display: flex !important;
      align-items: flex-start !important;
      width: 100% !important;
      box-sizing: border-box !important;
      line-height: 1.6;
    }
    .code-line .line-no {
      display: inline-block !important;
      flex-shrink: 0 !important;
      min-width: 2.2em !important;
      text-align: right !important;
      margin-right: 12px !important;
      user-select: none !important;
      opacity: 0.45 !important;
    }
    .code-line .line-content {
      flex: 1 1 0% !important;
      min-width: 0 !important;
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
    }
    /* 弱提示滚动条样式 */
    * {
      scrollbar-width: thin;
      scrollbar-color: rgba(255, 255, 255, 0.20) transparent;
    }
    *::-webkit-scrollbar {
      width: 4px;
      height: 4px;
    }
    *::-webkit-scrollbar-track {
      background: transparent;
    }
    *::-webkit-scrollbar-thumb {
      background: rgba(255, 255, 255, 0.20);
      border-radius: 2px;
      transition: background 0.2s ease;
    }
    *:hover::-webkit-scrollbar-thumb,
    *::-webkit-scrollbar-thumb:hover {
      background: rgba(255, 255, 255, 0.45);
    }
    /* Slidev Micro-motion Keyframes & Presets */
    @keyframes slidevMotionFadeIn { from { opacity: 0; } to { opacity: 1; } }
    @keyframes slidevMotionSlideUp { from { opacity: 0; transform: translateY(40px); } to { opacity: 1; transform: translateY(0); } }
    @keyframes slidevMotionSlideDown { from { opacity: 0; transform: translateY(-40px); } to { opacity: 1; transform: translateY(0); } }
    @keyframes slidevMotionSlideLeft { from { opacity: 0; transform: translateX(40px); } to { opacity: 1; transform: translateX(0); } }
    @keyframes slidevMotionSlideRight { from { opacity: 0; transform: translateX(-40px); } to { opacity: 1; transform: translateX(0); } }
    @keyframes slidevMotionZoomIn { from { opacity: 0; transform: scale(0.8); } to { opacity: 1; transform: scale(1); } }
    @keyframes slidevMotionBounce {
      0% { opacity: 0; transform: translateY(40px); }
      60% { opacity: 1; transform: translateY(-8px); }
      80% { transform: translateY(4px); }
      100% { transform: translateY(0); }
    }
    .slidev-motion-fade-in { animation: slidevMotionFadeIn var(--motion-duration, 0.4s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slidev-motion-slide-up { animation: slidevMotionSlideUp var(--motion-duration, 0.45s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slidev-motion-slide-down { animation: slidevMotionSlideDown var(--motion-duration, 0.45s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slidev-motion-slide-left { animation: slidevMotionSlideLeft var(--motion-duration, 0.45s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slidev-motion-slide-right { animation: slidevMotionSlideRight var(--motion-duration, 0.45s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slidev-motion-zoom-in, .slidev-motion-pop { animation: slidevMotionZoomIn var(--motion-duration, 0.4s) cubic-bezier(0.34, 1.56, 0.64, 1) var(--motion-delay, 0s) both; }
    .slidev-motion-bounce { animation: slidevMotionBounce var(--motion-duration, 0.6s) cubic-bezier(0.34, 1.56, 0.64, 1) var(--motion-delay, 0s) both; }
    .controls {
      position: absolute; bottom: 16px; display: flex; gap: 12px; align-items: center;
      background: rgba(24, 24, 27, 0.8); backdrop-filter: blur(8px);
      padding: 6px 18px; border-radius: 20px; color: #fff; font-size: 13px; z-index: 10;
      opacity: 0; pointer-events: auto;
      transition: opacity 0.3s cubic-bezier(0.16, 1, 0.3, 1), transform 0.3s cubic-bezier(0.16, 1, 0.3, 1);
    }
    .controls::before {
      content: ""; position: absolute; top: -20px; bottom: -16px; left: -24px; right: -24px;
    }
    .controls:hover, .controls:focus-within {
      opacity: 1; transform: translateY(-2px);
    }
    .controls button { background: transparent; border: none; color: inherit; cursor: pointer; padding: 2px 6px; }

    /* Slidev Native Icons & Interactive Buttons */
    .slidev-icon-btn {
      display: inline-flex !important; flex-direction: row !important; align-items: center !important; justify-content: center !important;
      padding: 0.35rem 0.5rem; border-radius: 0.375rem; background: transparent;
      border: 1px solid transparent; color: inherit; font-size: inherit; line-height: 1;
      cursor: pointer; opacity: 0.8; transition: all 0.2s ease; text-decoration: none;
      vertical-align: middle; user-select: none; margin: 0 4px;
    }
    .slidev-icon-btn:hover { opacity: 1; background: rgba(255, 255, 255, 0.12); border-color: rgba(255, 255, 255, 0.15); }

    /* 组件从上到下按顺序流式渲染，避免相互重叠 */
    .slide-block > div + div { margin-top: 14px; }

    /* 同一个 div 内的按钮/链接从左到右水平渲染 */
    .slide-block div:has(> .slidev-icon-btn),
    .slide-block div:has(> button),
    .slide-block [class*="abs-"],
    .slidev-btn-row {
      display: inline-flex !important;
      flex-direction: row !important;
      align-items: center !important;
      justify-content: center !important;
      flex-wrap: wrap !important;
      gap: 8px !important;
    }

    /* Position Shortcuts 适配：在组件流中保持从上到下排列，不脱离流产生重叠 */
    .slide-block .abs-br,
    .slide-block .abs-bl,
    .slide-block .abs-tr,
    .slide-block .abs-tl,
    .slide-block [class*="abs-"] {
      position: relative !important;
      bottom: auto !important;
      right: auto !important;
      top: auto !important;
      left: auto !important;
      margin: 0.75rem auto !important;
    }

    .slide-block--absolute { position: relative !important; margin-bottom: 14px !important; padding: 0 !important; background: transparent !important; }
    .slide-block--absolute:hover { background: transparent !important; }
    .mt-12 { margin-top: 3rem !important; }
    .py-1 { padding-top: 0.25rem !important; padding-bottom: 0.25rem !important; }
    .m-6 { margin: 1.5rem !important; }
    .text-xl { font-size: 1.25rem !important; }
    [hover\\:bg~="white"][hover\\:bg~="op-10"]:hover,
    [hover\\:bg="white op-10"]:hover { background: rgba(255, 255, 255, 0.1) !important; border-radius: 4px; }
    .cursor-pointer, [data-clickable] { cursor: pointer; }
    /* Slidev 规范链接排版 (继承正文颜色，虚线底边，Hover 时平滑点亮为主题色并转为实线) */
    .slide-content a:not(.slidev-ref-tag):not(.slidev-icon-btn):not(.slidev-toc-link),
    .slide-block a:not(.slidev-ref-tag):not(.slidev-icon-btn):not(.slidev-toc-link),
    a.slidev-link {
      color: inherit;
      text-decoration: none;
      border-bottom: 1px dashed currentColor;
      transition: color 0.2s cubic-bezier(0.4, 0, 0.2, 1),
                  border-color 0.2s cubic-bezier(0.4, 0, 0.2, 1),
                  border-bottom-style 0.2s cubic-bezier(0.4, 0, 0.2, 1);
      cursor: pointer;
    }
    .slide-content a:not(.slidev-ref-tag):not(.slidev-icon-btn):not(.slidev-toc-link):hover,
    .slide-block a:not(.slidev-ref-tag):not(.slidev-icon-btn):not(.slidev-toc-link):hover,
    a.slidev-link:hover {
      color: var(--slide-accent);
      border-bottom-style: solid;
      border-bottom-color: var(--slide-accent);
    }
    .slidev-ref-tag, a.slidev-ref-tag {
      display: inline-flex;
      align-items: center;
      background: color-mix(in srgb, var(--slide-accent) 12%, transparent);
      color: var(--slide-accent);
      border-radius: 4px;
      padding: 2px 8px;
      font-size: 0.88em;
      text-decoration: none;
      cursor: pointer;
      margin: 2px 4px 2px 0;
      border: 1px solid color-mix(in srgb, var(--slide-accent) 25%, transparent);
      transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
    }
    .slidev-ref-tag:hover, a.slidev-ref-tag:hover {
      background: color-mix(in srgb, var(--slide-accent) 22%, transparent);
      color: var(--slide-accent);
      border-color: color-mix(in srgb, var(--slide-accent) 55%, transparent);
      transform: translateY(-1px);
      box-shadow: 0 2px 8px color-mix(in srgb, var(--slide-accent) 20%, transparent);
    }
    .slidev-block-ref {
      display: block;
      padding: 10px 14px;
      background: color-mix(in srgb, var(--slide-accent) 8%, transparent);
      border-left: 3px solid var(--slide-accent);
      border-radius: 0 6px 6px 0;
      margin: 8px 0;
      cursor: pointer;
      transition: background 0.2s ease;
    }
    .slidev-block-ref:hover {
      background: color-mix(in srgb, var(--slide-accent) 15%, transparent);
    }

    /* 页面动态蒙版 (Dynamic Mask) GPU 合成器硬件加速体系 */
    .slidev-mask-body-container {
      position: relative;
      width: 100%;
      height: 100%;
      min-height: 0;
      flex: 1;
      display: flex;
      flex-direction: column;
      overflow: hidden !important;
      contain: layout paint;
      isolation: isolate;
    }
    .slidev-mask-body-container--has-mask {
      overflow: hidden !important;
      /* 向左右、向下突破父容器内边距，完全贴合幻灯片视口边缘 */
      margin-left: calc(-1 * var(--slidev-padding-x, 48px)) !important;
      margin-right: calc(-1 * var(--slidev-padding-x, 48px)) !important;
      margin-bottom: calc(-1 * var(--slidev-padding-y, 32px)) !important;
      padding-left: var(--slidev-padding-x, 48px) !important;
      padding-right: var(--slidev-padding-x, 48px) !important;
      padding-bottom: var(--slidev-padding-y, 32px) !important;
      width: calc(100% + 2 * var(--slidev-padding-x, 48px)) !important;
      box-sizing: border-box !important;
    }
    /* 无标题且首个元素即为蒙版正文容器时，向上同步扩展至顶部边缘 */
    .slide-content-wrapper > .slidev-mask-body-container--has-mask:first-child,
    .slide-content > .slidev-mask-body-container--has-mask:first-child {
      margin-top: calc(-1 * var(--slidev-padding-y, 32px)) !important;
      padding-top: var(--slidev-padding-y, 32px) !important;
    }
    /* 针对全屏零内边距特殊布局（如 image-right/image-left），重置内边距变量避免越界 */
    .slide-content-wrapper.layout-image-right,
    .slide-content-wrapper.layout-image-left,
    .slide-content.layout-image-right,
    .slide-content.layout-image-left {
      --slidev-padding-x: 0px !important;
      --slidev-padding-y: 0px !important;
    }
    /* 蒙版运动总图层：纯 GPU Compositor 硬件加速 translate3d */
    .slidev-mask-layer {
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      pointer-events: none;
      z-index: 50;
      will-change: transform, opacity;
      transform: translate3d(0, 0, 0);
      backface-visibility: hidden;
      transition: transform 0.42s cubic-bezier(0.2, 0, 0, 1),
                  opacity 0.42s cubic-bezier(0.2, 0, 0, 1);
    }
    /* 蒙版内部遮罩层：纯色或磨砂玻璃 */
    .slidev-mask-overlay {
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      pointer-events: none;
    }
    .slidev-mask-layer--solid .slidev-mask-overlay,
    .slidev-mask-overlay--solid {
      background: var(--slide-bg, #ffffff);
    }
    [data-theme="dark"] .slidev-mask-layer--solid .slidev-mask-overlay,
    [data-theme="dark"] .slidev-mask-overlay--solid {
      background: var(--slide-bg, #121214);
    }
    .slidev-mask-layer--blur .slidev-mask-overlay,
    .slidev-mask-overlay--blur {
      backdrop-filter: blur(30px) saturate(180%);
      -webkit-backdrop-filter: blur(30px) saturate(180%);
      background: color-mix(in srgb, var(--slide-bg, #ffffff) 90%, transparent);
    }
    [data-theme="dark"] .slidev-mask-layer--blur .slidev-mask-overlay,
    [data-theme="dark"] .slidev-mask-overlay--blur {
      background: color-mix(in srgb, var(--slide-bg, #121214) 90%, transparent);
    }
    /* 动态展露分界提示线：物理内嵌于蒙版边缘，相对坐标永为 0，绝对物理同步 */
    .slidev-mask-divider-line {
      position: absolute;
      pointer-events: none;
      z-index: 51;
      opacity: 0;
      transition: opacity 0.3s ease;
    }
    .slidev-mask-layer--down .slidev-mask-divider-line,
    .slidev-mask-divider-line--down {
      top: 0;
      left: 0;
      right: 0;
      height: 2.5px;
      transform: translateY(-50%);
      background: linear-gradient(90deg, transparent 0%, var(--slide-accent, #3b82f6) 6%, var(--slide-accent, #3b82f6) 94%, transparent 100%);
      box-shadow: 0 0 10px var(--slide-accent, #3b82f6), 0 0 4px var(--slide-accent, #3b82f6);
    }
    .slidev-mask-layer--right .slidev-mask-divider-line,
    .slidev-mask-divider-line--right {
      top: 0;
      bottom: 0;
      left: 0;
      width: 2.5px;
      transform: translateX(-50%);
      background: linear-gradient(180deg, transparent 0%, var(--slide-accent, #3b82f6) 6%, var(--slide-accent, #3b82f6) 94%, transparent 100%);
      box-shadow: 0 0 10px var(--slide-accent, #3b82f6), 0 0 4px var(--slide-accent, #3b82f6);
    }`}function og(){return`    (function() {
      const data = window.__SLIDEV_DATA__ || { slides: [] };
      const slides = data.slides || [];
      let currentIndex = 0;

      const container = document.getElementById("slide-container");
      const pageNum = document.getElementById("page-num");
      const btnPrev = document.getElementById("btn-prev");
      const btnNext = document.getElementById("btn-next");
      const btnFullscreen = document.getElementById("btn-fullscreen");

      // 「数字+回车」跳页输入角标：右下角悬浮显示，独立于缩放视口
      const jumpBadge = document.createElement("div");
      jumpBadge.className = "jump-page-indicator";
      jumpBadge.style.display = "none";
      document.body.appendChild(jumpBadge);
      const jumpStyle = document.createElement("style");
      jumpStyle.textContent = ".jump-page-indicator{position:fixed;right:16px;bottom:16px;z-index:1000;min-width:40px;padding:4px 12px;border-radius:18px;background:rgba(24,24,27,0.8);backdrop-filter:blur(12px);-webkit-backdrop-filter:blur(12px);border:1px solid rgba(255,255,255,0.12);color:#f4f4f5;font-size:14px;font-variant-numeric:tabular-nums;text-align:center;pointer-events:none;box-shadow:0 4px 16px rgba(0,0,0,0.35);}.jump-page-indicator.is-invalid{background:rgba(153,27,27,0.85);border-color:rgba(248,113,113,0.5);color:#fecaca;animation:jump-indicator-shake 0.4s ease;}@keyframes jump-indicator-shake{0%,100%{transform:translateX(0);}25%{transform:translateX(-4px);}50%{transform:translateX(4px);}75%{transform:translateX(-2px);}}";
      document.head.appendChild(jumpStyle);

`}function sg(){return`      // ========= 缩略图总览层（o 键呼出，方向键/数字+回车/点选跳页） =========
      const OVERVIEW_CARD_W = 236;
      let overviewOpen = false;
      let overviewFocus = 1;
      let overviewBuilt = false;
      let overviewObserver = null;
      const overviewOverlay = document.createElement("div");
      overviewOverlay.className = "slidev-overview";
      overviewOverlay.style.display = "none";
      const overviewGrid = document.createElement("div");
      overviewGrid.className = "slidev-overview-grid";
      const overviewHint = document.createElement("div");
      overviewHint.className = "slidev-overview-hint";
      overviewHint.textContent = "← → ↑ ↓ 移动 · Enter 跳转 · 数字直达 · Esc / O 关闭";
      overviewOverlay.appendChild(overviewGrid);
      overviewOverlay.appendChild(overviewHint);
      document.body.appendChild(overviewOverlay);
      overviewOverlay.addEventListener("click", (e) => {
        if (e.target === overviewOverlay) closeOverview();
      });
      const overviewStyle = document.createElement("style");
      overviewStyle.textContent = ".slidev-overview{position:fixed;inset:0;z-index:900;overflow-y:auto;background:rgba(13,16,22,0.88);backdrop-filter:blur(18px);-webkit-backdrop-filter:blur(18px);padding:36px 44px 20px;box-sizing:border-box;}.slidev-overview-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(236px,1fr));gap:18px;max-width:1440px;margin:0 auto;}.slidev-overview-card{cursor:pointer;border-radius:10px;border:2px solid rgba(255,255,255,0.12);background:rgba(255,255,255,0.04);overflow:hidden;transition:border-color 0.15s ease,transform 0.15s ease,box-shadow 0.15s ease;}.slidev-overview-card:hover{border-color:rgba(255,255,255,0.38);transform:translateY(-2px);}.slidev-overview-card.is-active{border-color:var(--slide-accent,#3b82f6);box-shadow:0 0 0 1px var(--slide-accent,#3b82f6),0 8px 24px rgba(0,0,0,0.4);}.slidev-overview-canvas-box{position:relative;overflow:hidden;background:var(--slide-bg,#ffffff);}.slidev-overview-canvas{position:absolute;top:0;left:0;transform-origin:top left;pointer-events:none;}.slidev-overview-canvas *{scrollbar-width:none;}.slidev-overview-caption{display:flex;align-items:center;gap:8px;padding:6px 10px;font-size:12px;color:rgba(255,255,255,0.72);border-top:1px solid rgba(255,255,255,0.08);background:rgba(13,16,22,0.6);}.slidev-overview-page-no{flex-shrink:0;font-variant-numeric:tabular-nums;font-weight:600;color:#f4f4f5;background:rgba(255,255,255,0.16);border-radius:8px;padding:0 7px;line-height:18px;}.slidev-overview-page-no.is-current{background:var(--slide-accent,#10b981);color:#0b1210;}.slidev-overview-title{white-space:nowrap;overflow:hidden;text-overflow:ellipsis;user-select:none;}.slidev-overview-hint{text-align:center;margin:18px 0 8px;font-size:12px;color:rgba(255,255,255,0.45);user-select:none;}";
      document.head.appendChild(overviewStyle);

      const baseWidth = 980;
      const aspectStr = (data.config && data.config.aspectRatio) || "16/9";
      let ratioNum = 16 / 9;
      if (aspectStr === "4/3") ratioNum = 4 / 3;
      else if (aspectStr === "16/10") ratioNum = 16 / 10;
      else if (typeof aspectStr === "string" && aspectStr.includes("/")) {
        const parts = aspectStr.split("/").map(Number);
        if (parts[0] && parts[1]) ratioNum = parts[0] / parts[1];
      }
      const baseHeight = Math.ceil(baseWidth / ratioNum);
      const viewport = document.getElementById("viewport");

`}function rg(){return`      function updateScale() {
        if (!viewport) return;
        const isFull = !!document.fullscreenElement;
        const padX = isFull ? 0 : 20;
        const padY = isFull ? 0 : 32;
        const availW = Math.max(100, window.innerWidth - padX);
        const availH = Math.max(100, window.innerHeight - padY);
        const scale = Math.min(availW / baseWidth, availH / baseHeight);
        viewport.style.width = baseWidth + "px";
        viewport.style.height = baseHeight + "px";
        viewport.style.transform = "translate(-50%, -50%) scale(" + scale + ")";
        viewport.style.setProperty("--slidev-slide-scale", scale);
        if (isFull) document.body.classList.add("is-fullscreen");
        else document.body.classList.remove("is-fullscreen");
      }

      window.addEventListener("resize", updateScale);
      document.addEventListener("fullscreenchange", updateScale);

      function parseMaskRatio(ratioStr) {
        if (!ratioStr || typeof ratioStr !== "string") {
          return { steps: 2, breakpoints: [50, 100] };
        }
        const clean = ratioStr.trim();
        if (!clean) return { steps: 2, breakpoints: [50, 100] };
        const parts = clean.split(":").map(p => parseFloat(p.trim())).filter(n => !isNaN(n) && n > 0);
        if (parts.length === 0) return { steps: 2, breakpoints: [50, 100] };
        if (parts.length === 1) {
          const val = Math.min(100, Math.max(1, parts[0]));
          if (val === 100) return { steps: 1, breakpoints: [100] };
          return { steps: 2, breakpoints: [Math.round(val * 100) / 100, 100] };
        }
        const isMonotonic = parts.every((val, idx) => idx === 0 || val > parts[idx - 1]);
        const maxVal = parts[parts.length - 1];
        if (isMonotonic && (maxVal === 100 || parts.some(p => p > 10))) {
          const bps = parts.map(p => Math.min(100, Math.round(p * 100) / 100));
          if (bps[bps.length - 1] < 100) bps.push(100);
          return { steps: bps.length, breakpoints: bps };
        }
        const totalWeight = parts.reduce((acc, cur) => acc + cur, 0);
        if (totalWeight <= 0) return { steps: 2, breakpoints: [50, 100] };
        let accumulated = 0;
        const bps = [];
        for (let i = 0; i < parts.length; i++) {
          accumulated += parts[i];
          if (i === parts.length - 1) {
            bps.push(100);
          } else {
            bps.push(Math.round((accumulated / totalWeight) * 10000) / 100);
          }
        }
        return { steps: bps.length, breakpoints: bps };
      }

      let currentMaskStep = 0;
      let currentMaskConfig = null;
      let maskLayerEl = null;
      let maskOverlayEl = null;
      let maskDividerEl = null;

      function updateMaskVisual() {
        if (!currentMaskConfig || !maskLayerEl) return;
        const p = (currentMaskStep <= 0)
          ? (currentMaskConfig.isInitialRevealed ? currentMaskConfig.breakpoints[0] : 0)
          : (currentMaskStep >= currentMaskConfig.totalSteps
              ? 100
              : currentMaskConfig.breakpoints[currentMaskConfig.isInitialRevealed ? currentMaskStep : (currentMaskStep - 1)]);

        const isDown = currentMaskConfig.direction === "down";
        if (p >= 100) {
          maskLayerEl.style.transform = isDown ? "translate3d(0, 100%, 0)" : "translate3d(100%, 0, 0)";
          maskLayerEl.style.opacity = "0";
          maskLayerEl.style.pointerEvents = "none";
          if (maskDividerEl) maskDividerEl.style.opacity = "0";
        } else {
          maskLayerEl.style.transform = isDown ? ("translate3d(0, " + p + "%, 0)") : ("translate3d(" + p + "%, 0, 0)");
          maskLayerEl.style.opacity = "1";
          maskLayerEl.style.pointerEvents = "none";
          if (maskDividerEl) {
            maskDividerEl.style.opacity = (p <= 0) ? "0" : "1";
          }
        }
      }

      function goNext() {
        if (currentMaskConfig && currentMaskStep < currentMaskConfig.totalSteps) {
          currentMaskStep++;
          updateMaskVisual();
          return;
        }
        renderSlide(currentIndex + 1);
      }

      function goPrev() {
        if (currentMaskConfig && currentMaskStep > (currentMaskConfig.isInitialRevealed ? 1 : 0)) {
          currentMaskStep--;
          updateMaskVisual();
          return;
        }
        renderSlide(currentIndex - 1);
      }

`}function lg(){return`      function cleanCardListItemMarkdown(rawMarkdown) {
        if (!rawMarkdown) return "";
        let cleaned = rawMarkdown.replace(/^[ 	]*[-*+]s+|^[ 	]*d+.s+/, "");
        cleaned = cleaned.replace(/
[ 	]{2,4}/g, "
");
        return cleaned.trim();
      }

      function isHeadingBlock(b) {
        if (!b) return false;
        if (b.type === "h" || b.type === "NodeHeading") return true;
        if (b.subType && /^h[1-6]$/i.test(b.subType)) return true;
        const md = (b.rawMarkdown || b.content || "").trim();
        if (/^#{1,6}s+/.test(md)) return true;
        if (/^(?:[-*+]|d+.)s+#{1,6}s+/.test(md)) return true;
        return false;
      }

      function cleanColList(blocks) {
        const valid = (blocks || []).filter(b => Boolean((b.rawMarkdown || b.content || "").trim()));
        if (valid.length === 0) return valid;
        const first = valid[0];
        const md = (first.rawMarkdown || first.content || "").trim();
        const isList = /^(?:[-*+]|d+.)s+/.test(md) || first.type === "i" || first.type === "l";
        if (isList) {
          first.rawMarkdown = cleanCardListItemMarkdown(first.rawMarkdown || first.content || "");
          first.content = first.rawMarkdown;
        }
        return valid;
      }

      function renderBlock(block, extraClass) {
        const div = document.createElement("div");
        div.className = "slide-block" + (extraClass ? " " + extraClass : "");
        if (block && block.motion && block.motion.preset && block.motion.preset !== "none") {
          div.classList.add("slidev-motion-" + block.motion.preset.toLowerCase());
          if (typeof block.motion.duration === "number" && block.motion.duration > 0) {
            div.style.setProperty("--motion-duration", block.motion.duration + "ms");
          }
          if (typeof block.motion.delay === "number" && block.motion.delay > 0) {
            div.style.setProperty("--motion-delay", block.motion.delay + "ms");
          }
        }
        const md = block.rawMarkdown || block.content || "";

        if (md.includes('class="slidev-block-ref"') || md.includes('class="slidev-ref-tag"')) {
          div.innerHTML = md;
          return div;
        }

        const CARBON_MAP = {
          'carbon:arrow-right': '<svg viewBox="0 0 32 32" width="1.2em" height="1.2em" fill="currentColor" style="display:inline-block;vertical-align:middle;"><path d="m18 6l-1.43 1.393L24.15 15H4v2h20.15l-7.58 7.573L18 26l10-10z"/></svg>',
          'carbon:arrow-left': '<svg viewBox="0 0 32 32" width="1.2em" height="1.2em" fill="currentColor" style="display:inline-block;vertical-align:middle;"><path d="m14 26l1.43-1.393L7.85 17H28v-2H7.85l7.58-7.573L14 6L4 16z"/></svg>',
          'carbon:edit': '<svg viewBox="0 0 32 32" width="1.2em" height="1.2em" fill="currentColor" style="display:inline-block;vertical-align:middle;"><path d="M2 26h28v2H2zM25.4 9c.8-.8.8-2 0-2.8l-3.6-3.6c-.8-.8-2-.8-2.8 0l-15 15V24h6.4l15-15zM20.4 4L24 7.6l-2.4 2.4l-3.6-3.6L20.4 4zM6 22v-3.6l11-11l3.6 3.6l-11 11H6z"/></svg>',
          'carbon:logo-github': '<svg viewBox="0 0 32 32" width="1.2em" height="1.2em" fill="currentColor" style="display:inline-block;vertical-align:middle;"><path fill-rule="evenodd" d="M16 2a14 14 0 0 0-4.43 27.28c.7.13 1-.3 1-.67v-2.38c-3.89.84-4.71-1.88-4.71-1.88a3.7 3.7 0 0 0-1.56-2.05c-1.27-.86.1-.85.1-.85a2.94 2.94 0 0 1 2.14 1.44a3 3 0 0 0 4.08 1.16a2.93 2.93 0 0 1 .89-1.87c-3.1-.35-6.36-1.55-6.36-6.9a5.4 5.4 0 0 1 1.44-3.75a5 5 0 0 1 .14-3.71s1.17-.38 3.85 1.43a13.3 13.3 0 0 1 7 0c2.67-1.81 3.84-1.43 3.84-1.43a5 5 0 0 1 .14 3.71a5.4 5.4 0 0 1 1.44 3.75c0 5.37-3.27 6.54-6.38 6.89a3.35 3.35 0 0 1 1.26 2.61v3.87c0 .38.26.81 1 .67A14 14 0 0 0 16 2"/></svg>'
        };

        if (/@\\w+=['"]|v-\\w+|<button|<a\\b|<carbon:|^<div/i.test(md)) {
          if (md.includes('abs-br') || md.includes('abs-bl') || md.includes('abs-tr') || md.includes('abs-tl') || md.includes('absolute')) {
            div.classList.add("slide-block--absolute");
          }
          let renderedHtml = md;
          for (const [tag, svg] of Object.entries(CARBON_MAP)) {
            const regex = new RegExp("<" + tag + "\\\\s*\\\\/?>", "gi");
            renderedHtml = renderedHtml.replace(regex, svg);
            const regexDash = new RegExp("<" + tag.replace(":", "-") + "\\\\s*\\\\/?>", "gi");
            renderedHtml = renderedHtml.replace(regexDash, svg);
          }
          div.innerHTML = renderedHtml;

          // 挂载交互事件监听
          const nextBtns = div.querySelectorAll('[\\\\@click*="nav.next"], [\\\\@click*="next"]');
          nextBtns.forEach(btn => {
            btn.style.cursor = "pointer";
            btn.addEventListener("click", (e) => {
              e.stopPropagation();
              renderSlide(currentIndex + 1);
            });
          });

          const prevBtns = div.querySelectorAll('[\\\\@click*="nav.prev"], [\\\\@click*="prev"]');
          prevBtns.forEach(btn => {
            btn.style.cursor = "pointer";
            btn.addEventListener("click", (e) => {
              e.stopPropagation();
              renderSlide(currentIndex - 1);
            });
          });

          return div;
        }

        const hasHeadingTag = /(?:^|
)s*#{1,6}s+/.test(md);
        const hMatch = md.match(/^(#{1,6})\\s+(.*)$/);

        if (hMatch) {
          const level = hMatch[1].length;
          let th = hMatch[2].trim().replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
          div.innerHTML = "<h" + level + ">" + th + "</h" + level + ">";
        }
        else if (md.startsWith("\`\`\`")) {
          const customMaxHeight = block?.attributes?.["custom-slidev-max-height"] || block?.attrs?.["custom-slidev-max-height"] || block?.maxHeight || "";
          const heightStyle = customMaxHeight ? ' style="max-height:' + customMaxHeight + ';overflow-y:auto;"' : "";
          div.innerHTML = "<pre" + heightStyle + "><code>" + md.slice(3, -3) + "</code></pre>";
        }
        else if (md.startsWith("> ")) div.innerHTML = "<blockquote><p>" + md.slice(2) + "</p></blockquote>";
        else if ((/<video\b/i.test(md) || (block && (block.type === "video" || block.type === "NodeVideo"))) && !/^(s*)([-*+]|d+.)s+/m.test(md) && !hasHeadingTag && !md.includes("
")) {
          div.classList.add("slide-video-container", "slide-media-container", "slide-media-block");
          const isAutoplay = block && block.attributes && block.attributes["custom-slidev-autoplay"] === "true";
          const isLoop = block && block.attributes && block.attributes["custom-slidev-loop"] === "true";
          const isMuted = block && block.attributes && (block.attributes["custom-slidev-muted"] === "true" || isAutoplay);
          const hideControls = block && block.attributes && block.attributes["custom-slidev-controls"] === "false";
          let videoHtml = md;
          if (hideControls) videoHtml = videoHtml.replace(/\bcontrols(?:="[^"]*")?/gi, "").trim();
          else if (!videoHtml.includes("controls")) videoHtml = videoHtml.replace("<video", "<video controls");
          if (isAutoplay && !videoHtml.includes("autoplay")) videoHtml = videoHtml.replace("<video", "<video autoplay playsinline");
          if (isLoop && !videoHtml.includes("loop")) videoHtml = videoHtml.replace("<video", "<video loop");
          if (isMuted && !videoHtml.includes("muted")) videoHtml = videoHtml.replace("<video", "<video muted");
          videoHtml = videoHtml.replace("<video", '<video class="slide-video-player"');
          div.setAttribute("data-autoplay", isAutoplay ? "true" : "false");
          div.innerHTML = videoHtml;
        }
        else if (/^(s*)([-*+]|d+.)s+/m.test(md) || (md.includes("
") && /^(s*)([-*+]|d+.)s+/m.test(md.split("
").slice(1).join("
")))) {
          div.classList.add("pdf-list-item");
          const lines = md.split("
");
          let isOrdered = false;
          const items = [];
          const leadLines = [];
          for (let i = 0; i < lines.length; i++) {
            const line = lines[i];
            const tr = line.trim();
            if (!tr || /^{:.*?}$/.test(tr)) continue;
            const um = line.match(/^(s*)[-*+]s+(.*)$/);
            const om = line.match(/^(s*)d+.s+(.*)$/);
            if (um) {
              const indent = um[1].length;
              items.push({ type: "unordered", level: Math.floor(indent / 2), text: um[2], media: [] });
              continue;
            }
            if (om) {
              if (items.length === 0) isOrdered = true;
              const indent = om[1].length;
              items.push({ type: "ordered", level: Math.floor(indent / 2), text: om[2], media: [] });
              continue;
            }
            if (items.length > 0) {
              const im = tr.match(/^![(.*?)]((.*?))(?:{:?[^}]*})?$/);
              if (im) {
                const isGif = /.gif(?:?|$)/i.test(im[2]);
                items[items.length - 1].media.push('<div class="slide-list-media"><img alt="' + im[1] + '" src="' + im[2] + '" class="' + (isGif ? 'list-item-gif' : 'list-item-img') + '" /></div>');
                continue;
              }
              const hm = tr.match(/^<img\b[sS]*?/?>$/i);
              if (hm) {
                const cleanTr = tr.replace(/s+style="[^"]*"/gi, "");
                items[items.length - 1].media.push('<div class="slide-list-media">' + cleanTr + '</div>');
                continue;
              }
              if (/<video\b/i.test(tr)) {
                let vHtml = tr;
                if (!/</video>/i.test(vHtml)) {
                  while (i + 1 < lines.length && !/</video>/i.test(vHtml)) {
                    i++;
                    vHtml += " " + lines[i].trim();
                  }
                }
                const isAutoplay = block && block.attributes && block.attributes["custom-slidev-autoplay"] === "true";
                const isLoop = block && block.attributes && block.attributes["custom-slidev-loop"] === "true";
                const isMuted = block && block.attributes && (block.attributes["custom-slidev-muted"] === "true" || isAutoplay);
                const hideControls = block && block.attributes && block.attributes["custom-slidev-controls"] === "false";
                if (hideControls) vHtml = vHtml.replace(/\bcontrols(?:="[^"]*")?/gi, "").trim();
                else if (!vHtml.includes("controls")) vHtml = vHtml.replace("<video", "<video controls");
                if (isAutoplay && !vHtml.includes("autoplay")) vHtml = vHtml.replace("<video", "<video autoplay playsinline");
                if (isLoop && !vHtml.includes("loop")) vHtml = vHtml.replace("<video", "<video loop");
                if (isMuted && !vHtml.includes("muted")) vHtml = vHtml.replace("<video", "<video muted");
                vHtml = vHtml.replace("<video", '<video class="slide-video-player"');
                items[items.length - 1].media.push('<div class="slide-list-media slide-video-container slide-media-container" data-autoplay="' + (isAutoplay ? 'true' : 'false') + '">' + vHtml + '</div>');
                continue;
              }
              items[items.length - 1].text += "
" + tr;
            } else {
              leadLines.push(tr);
            }
          }

          let leadHtml = "";
          if (leadLines.length > 0) {
            const lParts = [];
            const firstL = leadLines[0];
            const fhm = firstL.match(/^(#{1,6})s+(.*)$/);
            if (fhm) {
              const lvl = fhm[1].length;
              let th = fhm[2].trim().replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
              lParts.push('<h' + lvl + ' class="slide-list-item-title">' + th + '</h' + lvl + '>');
            } else {
              let th = firstL.trim().replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
              lParts.push('<p class="slide-list-item-title">' + th + '</p>');
            }
            if (leadLines.length > 1) {
              const dLines = leadLines.slice(1);
              let pL = [];
              const flushLeadP = () => {
                if (pL.length > 0) {
                  let txt = pL.map(l => l.replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>")).join("<br/>");
                  lParts.push('<p class="slide-list-item-desc">' + txt + '</p>');
                  pL = [];
                }
              };
              for (const l of dLines) {
                const hm = l.match(/^(#{1,6})s+(.*)$/);
                if (hm) {
                  flushLeadP();
                  const lvl = hm[1].length;
                  let th = hm[2].trim().replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
                  lParts.push('<h' + lvl + ' class="slide-list-item-title">' + th + '</h' + lvl + '>');
                } else {
                  pL.push(l);
                }
              }
              flushLeadP();
            }
            leadHtml = lParts.join("
") + "
";
          }

          const tag = isOrdered ? "ol" : "ul";
          const listCls = isOrdered ? "pdf-list pdf-list--ordered" : "pdf-list pdf-list--unordered";
          const liHtml = items.map(it => {
            const med = it.media && it.media.length ? "
" + it.media.join("
") : "";
            const lines = (it.text || "").split("
").map(l => l.trim()).filter(Boolean);
            const hasHeading = lines.some(l => /^#{1,6}s+/.test(l));
            const lvl = it.level || 0;
            const nStyle = lvl > 0 ? ' style="margin-left:' + (lvl * 1.25).toFixed(2) + 'em;' + (it.type === 'unordered' ? 'list-style-type:' + (lvl % 2 === 1 ? 'circle' : 'square') + ' !important;' : '') + '"' : "";
            const nClass = lvl > 0 ? " slide-list-item--nested" : "";
            const clsAttr = nClass ? ' class="' + nClass.trim() + '"' : "";
            if (!hasHeading) {
              let h = lines.map(l => l.replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>")).join("<br/>");
              return '<li' + clsAttr + nStyle + '>' + h + med + '</li>';
            }
            const parts = [];
            let pLines = [];
            const flushP = () => {
              if (pLines.length > 0) {
                let ph = pLines.map(l => l.replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>")).join("<br/>");
                parts.push('<p class="slide-list-item-desc">' + ph + '</p>');
                pLines = [];
              }
            };
            for (const l of lines) {
              const hm = l.match(/^(#{1,6})s+(.*)$/);
              if (hm) {
                flushP();
                const hl = hm[1].length;
                let th = hm[2].trim().replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
                parts.push('<h' + hl + ' class="slide-list-item-title">' + th + '</h' + hl + '>');
              } else {
                pLines.push(l);
              }
            }
            flushP();
            return '<li' + clsAttr + nStyle + '>' + parts.join("
") + med + '</li>';
          }).join("
");
          div.innerHTML = leadHtml + "<" + tag + " class="" + listCls + "">
" + liHtml + "
</" + tag + ">";
        }
        else {
          // 复合块（包含换行、标题或媒体）高保真解析
          const lines = md.split(/\r?
/);
          const subBlocks = [];
          let current = [];
          for (let i = 0; i < lines.length; i++) {
            const line = lines[i];
            const trimmed = line.trim();
            if (/^#{1,6}s+/.test(trimmed)) {
              if (current.length > 0) { subBlocks.push(current.join("
")); current = []; }
              subBlocks.push(trimmed);
              continue;
            }
            if (!trimmed) {
              if (current.length > 0) { subBlocks.push(current.join("
")); current = []; }
              continue;
            }
            if (/^![.*?](.*?)$/.test(trimmed)) {
              if (current.length > 0) { subBlocks.push(current.join("
")); current = []; }
              subBlocks.push(trimmed);
              continue;
            }
            if (/<video\b/i.test(trimmed)) {
              if (current.length > 0) { subBlocks.push(current.join("
")); current = []; }
              let vRaw = trimmed;
              if (!/</video>/i.test(vRaw)) {
                while (i + 1 < lines.length && !/</video>/i.test(vRaw)) {
                  i++;
                  vRaw += "
" + lines[i];
                }
              }
              subBlocks.push(vRaw);
              continue;
            }
            current.push(line);
          }
          if (current.length > 0) subBlocks.push(current.join("
"));

          if (subBlocks.length > 1 || (subBlocks.length === 1 && /^#{1,6}s+/.test(subBlocks[0].trim()))) {
            let isFirstParagraph = true;
            const htmlParts = subBlocks.map(sub => {
              const t = sub.trim();
              if (!t) return "";
              const hm = t.match(/^(#{1,6})s+(.*)$/);
              if (hm) {
                isFirstParagraph = false;
                const hl = hm[1].length;
                let th = hm[2].trim().replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
                return '<h' + hl + ' class="slide-list-item-title">' + th + '</h' + hl + '>';
              }
              const im = t.match(/^![(.*?)]((.*?))$/);
              if (im) {
                return '<div class="slide-media-block slide-media-container slide-list-media"><img alt="' + im[1] + '" src="' + im[2] + '" class="slide-media-img" /></div>';
              }
              if (/<video\b/i.test(t)) {
                return '<div class="slide-media-block slide-video-container slide-media-container">' + t + '</div>';
              }
              if (isFirstParagraph) {
                isFirstParagraph = false;
                const subLines = t.split(/\r?
/).map(l => l.trim()).filter(Boolean);
                if (subLines.length === 1) {
                  let ph = subLines[0].replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
                  return '<p class="slide-list-item-title">' + ph + '</p>';
                }
                let titleHtml = subLines[0].replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
                let descHtml = subLines.slice(1).map(l => l.replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>")).join("<br/>");
                return '<p class="slide-list-item-title">' + titleHtml + '</p>
<p class="slide-list-item-desc">' + descHtml + '</p>';
              }
              let ph = t.replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
              return '<p class="slide-list-item-desc">' + ph + '</p>';
            }).filter(Boolean);
            div.innerHTML = htmlParts.join("
");
          } else {
            const imgMatch = md.match(/!\\[(.*?)\\]\\((.*?)\\)/);
            if (imgMatch) {
              div.classList.add("slide-media-container", "slide-media-block", "slide-block--image");
              div.innerHTML = '<img alt="' + imgMatch[1] + '" src="' + imgMatch[2] + '" class="slide-media-img" />';
            } else {
              let html = md.replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
              const pCls = (block && block.isColFirst) ? ' class="slide-list-item-title"' : '';
              div.innerHTML = "<p" + pCls + ">" + html + "</p>";
            }
          }
        }
        return div;
      }

`}function ag(){return`      function renderSlide(idx) {
        if (slides.length === 0) return;
        currentIndex = Math.max(0, Math.min(idx, slides.length - 1));
        const slide = slides[currentIndex];
        pageNum.textContent = (currentIndex + 1) + " / " + slides.length;

        const pageSp = slide.frontmatter?.spacing;
        const currentSpacing = (pageSp && pageSp !== "inherit") ? pageSp : (data.config?.spacing || "normal");
        container.className = "slide-content layout-" + (slide.frontmatter?.layout || "default") + " spacing-" + currentSpacing;
        if (viewport) viewport.setAttribute("data-spacing", currentSpacing);
        container.innerHTML = "";

        const z = typeof slide.frontmatter?.zoom === "number" && slide.frontmatter.zoom > 0 ? slide.frontmatter.zoom : 1;
        if (z !== 1) {
          container.style.width = (100 / z) + "%";
          container.style.height = (100 / z) + "%";
          container.style.transformOrigin = "top left";
          container.style.transform = "scale(" + z + ")";
        } else {
          container.style.width = "100%";
          container.style.height = "100%";
          container.style.transform = "none";
        maskOverlayEl = null;
        maskDividerEl = null;
        const maskDir = slide.frontmatter?.mask;
        if (maskDir === "down" || maskDir === "right") {
          const ratioInfo = parseMaskRatio(slide.frontmatter.maskRatio);
          const isInitRev = slide.frontmatter.maskInitial === "revealed";
          currentMaskConfig = {
            direction: maskDir,
            totalSteps: isInitRev ? Math.max(0, ratioInfo.steps - 1) : ratioInfo.steps,
            rawSteps: ratioInfo.steps,
            breakpoints: ratioInfo.breakpoints,
            isInitialRevealed: isInitRev,
            style: slide.frontmatter.maskStyle || "solid",
          };
          currentMaskStep = 0;
        } else {
          currentMaskConfig = null;
          currentMaskStep = 0;
        }

        function createMaskElements() {
          if (!currentMaskConfig) return null;
          const layer = document.createElement("div");
          layer.className = "slidev-mask-layer slidev-mask-layer--" + currentMaskConfig.style + " slidev-mask-layer--" + currentMaskConfig.direction;
          const overlay = document.createElement("div");
          overlay.className = "slidev-mask-overlay";
          const divider = document.createElement("div");
          divider.className = "slidev-mask-divider-line";
          divider.style.opacity = "0";
          layer.appendChild(overlay);
          layer.appendChild(divider);
          maskLayerEl = layer;
          maskOverlayEl = overlay;
          maskDividerEl = divider;
          return { layer, overlay, divider };
        }

        if (slide.frontmatter?.layout === "two-cols") {
          const bodyWrap = document.createElement("div");
          bodyWrap.className = "slidev-mask-body-container" + (currentMaskConfig ? " slidev-mask-body-container--has-mask" : "");
          bodyWrap.style.display = "flex";
          bodyWrap.style.flexDirection = "row";
          bodyWrap.style.gap = "2rem";
          bodyWrap.style.width = "100%";
          bodyWrap.style.height = "100%";

          const leftCol = document.createElement("div");
          leftCol.className = "two-cols-left";
          const rightCol = document.createElement("div");
          rightCol.className = "two-cols-right";

          const blocks = (slide.blocks || []).filter(b => b.slot !== "slot-divider-right");
          let leftList = [];
          let rightList = [];
          for (const block of blocks) {
            if (block.slot === "right") rightList.push(block);
            else leftList.push(block);
          }
          leftList = cleanColList(leftList);
          rightList = cleanColList(rightList);
          const isCover = slide.frontmatter?.layout === "cover";
          const leftFirstH = !isCover ? leftList.find(isHeadingBlock) : null;
          const rightFirstH = !isCover ? rightList.find(isHeadingBlock) : null;
          for (const b of leftList) leftCol.appendChild(renderBlock(b, b === leftFirstH ? "slidev-col-first-heading-block" : ""));
          for (const b of rightList) rightCol.appendChild(renderBlock(b, b === rightFirstH ? "slidev-col-first-heading-block" : ""));
          bodyWrap.appendChild(leftCol);
          bodyWrap.appendChild(rightCol);

          const maskEls = createMaskElements();
          if (maskEls) {
            bodyWrap.appendChild(maskEls.layer);
          }
          container.appendChild(bodyWrap);
        } else if (slide.frontmatter?.layout === "cols-header" || slide.frontmatter?.layout === "two-cols-header" || slide.frontmatter?.layout === "three-cols-header" || slide.frontmatter?.layout === "clover") {
          const isCover = slide.frontmatter?.layout === "cover";
          const isClover = slide.frontmatter?.layout === "clover";
          const blocks = (slide.blocks || []).filter(b => b.slot !== "slot-divider-right");
          let headerBlocks = blocks.filter(b => b.slot === "header");
          if (headerBlocks.length === 0 && blocks.length > 0) {
            const candidate = blocks.find(b => b.type === "h" && (!b.slot || b.slot === "default"));
            if (candidate) headerBlocks = [candidate];
          }
          const rem = blocks.filter(b => !headerBlocks.includes(b));

          let targetCols = isClover ? 4 : 2;
          if (isClover) {
            targetCols = 4;
          } else if (slide.frontmatter?.layout === "three-cols-header") {
            targetCols = 3;
          } else if (slide.frontmatter?.layout === "two-cols-header") {
            targetCols = 2;
          } else {
            let maxCol = 0;
            for (const b of rem) {
              const m = (b.slot || "").match(/^col-(d+)$/i);
              if (m) maxCol = Math.max(maxCol, parseInt(m[1], 10));
            }
            if (maxCol >= 2) {
              targetCols = maxCol;
            } else if (slide.frontmatter?.layoutRatio) {
              const r = slide.frontmatter.layoutRatio.trim();
              if (r.includes(":")) {
                const parts = r.split(":").map(p => parseFloat(p.trim())).filter(n => !isNaN(n) && n > 0);
                if (parts.length >= 2) targetCols = parts.length;
              }
            }
          }

          const hasColSlots = rem.some(b => b.slot && /^col-d+$/i.test(b.slot));
          const isSuperBlockCols = isClover || hasColSlots;

          const containerDiv = document.createElement("div");
          containerDiv.className = (isClover ? "layout-clover-container" : ("layout-cols-header-container " + (targetCols === 2 ? "layout-two-cols-header-container" : (targetCols === 3 ? "layout-three-cols-header-container" : "")))) + (isSuperBlockCols ? " has-superblock-cols" : "");
          const headerDiv = document.createElement("div");
          headerDiv.className = "layout-header-section";
          const gridDiv = document.createElement("div");
          gridDiv.className = (isClover ? "layout-clover-grid pdf-clover-wrapper" : ("layout-cols-wrapper layout-cols-grid " + (targetCols === 2 ? "pdf-two-cols-wrapper layout-two-cols-grid" : (targetCols === 3 ? "pdf-three-cols-wrapper layout-three-cols-grid" : "")))) + (isSuperBlockCols ? " has-superblock-cols" : "") + (currentMaskConfig ? " slidev-mask-body-container slidev-mask-body-container--has-mask" : "");

          const gridCols = isClover ? "repeat(2, minmax(0, 1fr))" : parseRatioToGridCols(slide.frontmatter?.layoutRatio, targetCols);
          if (gridCols) gridDiv.style.gridTemplateColumns = gridCols;
          if (isClover) gridDiv.style.gridTemplateRows = "repeat(2, minmax(0, 1fr))";

          let colsList = [];
          for (let i = 0; i < targetCols; i++) colsList.push([]);
          const hasExplicitCols = rem.some(b => b.slot && (b.slot.startsWith("col-") || b.slot === "left" || b.slot === "right" || b.slot === "center"));
          if (hasExplicitCols) {
            for (const b of rem) {
              let idx = 0;
              if (b.slot === "left" || b.slot === "col-1") idx = 0;
              else if (b.slot === "center" || b.slot === "col-2") idx = 1;
              else if (b.slot === "right") idx = targetCols === 2 ? 1 : targetCols - 1;
              else {
                const m = (b.slot || "").match(/^col-(d+)$/i);
                if (m) idx = Math.min(targetCols - 1, Math.max(0, parseInt(m[1], 10) - 1));
              }
              colsList[idx].push(b);
            }
          } else {
            let cur = 0;
            for (let i = 0; i < targetCols; i++) {
              const remainingCols = targetCols - i;
              const remainingItems = rem.length - cur;
              const take = Math.ceil(remainingItems / remainingCols);
              colsList[i] = rem.slice(cur, cur + take);
              cur += take;
            }
          }

          const headerFirstH = !isCover ? headerBlocks.find(isHeadingBlock) : null;
          for (const b of headerBlocks) headerDiv.appendChild(renderBlock(b, b === headerFirstH ? "slidev-page-first-heading-block" : ""));
          containerDiv.appendChild(headerDiv);

          colsList.forEach((colBlocks, idx) => {
            const colDiv = document.createElement("div");
            colDiv.className = "pdf-col pdf-col--" + (idx + 1) + " col-" + (idx + 1) + (targetCols === 2 && idx === 0 ? " pdf-col--left" : "") + (targetCols === 2 && idx === 1 ? " pdf-col--right" : "");
            const cleaned = cleanColList(colBlocks);
            const colFirstH = !isCover ? (cleaned.find(isHeadingBlock) || cleaned[0]) : null;
            for (const b of cleaned) colDiv.appendChild(renderBlock(b, b === colFirstH ? "slidev-col-first-heading-block" : ""));
            gridDiv.appendChild(colDiv);
          });

          const maskEls = createMaskElements();
          if (maskEls) {
            gridDiv.appendChild(maskEls.layer);
          }

          containerDiv.appendChild(gridDiv);
          container.appendChild(containerDiv);
        } else if (slide.frontmatter?.layout === "image-right" || slide.frontmatter?.layout === "image-left") {
          const isImageRight = slide.frontmatter?.layout === "image-right";
          const isCover = slide.frontmatter?.layout === "cover";
          const allBlocks = slide.blocks || [];
          const pageFirstH = !isCover ? allBlocks.find(isHeadingBlock) : null;

          if (pageFirstH) {
            container.appendChild(renderBlock(pageFirstH, "slidev-page-first-heading-block"));
          }

          const bodyWrap = document.createElement("div");
          bodyWrap.className = "slidev-mask-body-container" + (currentMaskConfig ? " slidev-mask-body-container--has-mask" : "");
          bodyWrap.style.display = "flex";
          bodyWrap.style.flexDirection = isImageRight ? "row" : "row-reverse";
          bodyWrap.style.gap = "2rem";
          bodyWrap.style.width = "100%";
          bodyWrap.style.height = "100%";
          bodyWrap.style.minHeight = "0";
          bodyWrap.style.flex = "1";

          const contentCol = document.createElement("div");
          contentCol.className = isImageRight ? "image-right-content" : "image-left-content";

          for (const block of allBlocks) {
            if (block === pageFirstH) continue;
            contentCol.appendChild(renderBlock(block, ""));
          }

          const imgCol = document.createElement("div");
          imgCol.className = isImageRight ? "image-right-img-container" : "image-left-img-container";
          const img = document.createElement("img");
          img.className = isImageRight ? "image-right-img" : "image-left-img";
          img.src = slide.frontmatter?.image || slide.frontmatter?.background || "";
          img.alt = "Slide cover";
          img.onerror = function() {
            this.src = "https://fastly.jsdelivr.net/gh/slidevjs/slidev-covers@main/static/2HmfbSpvcos.webp";
          };
          imgCol.appendChild(img);

          bodyWrap.appendChild(contentCol);
          bodyWrap.appendChild(imgCol);

          const maskEls = createMaskElements();
          if (maskEls) {
            bodyWrap.appendChild(maskEls.layer);
          }
          container.appendChild(bodyWrap);
        } else {
          const isCover = slide.frontmatter?.layout === "cover";
          const validBlocks = (slide.blocks || []).filter(b => b.slot !== "slot-divider-right");
          const pageFirstH = !isCover ? validBlocks.find(isHeadingBlock) : null;

          if (pageFirstH) {
            container.appendChild(renderBlock(pageFirstH, "slidev-page-first-heading-block"));
          }

          const bodyWrap = document.createElement("div");
          bodyWrap.className = "slidev-mask-body-container" + (currentMaskConfig ? " slidev-mask-body-container--has-mask" : "");

          for (const block of validBlocks) {
            if (block === pageFirstH) continue;
            bodyWrap.appendChild(renderBlock(block, ""));
          }

          const maskEls = createMaskElements();
          if (maskEls) {
            bodyWrap.appendChild(maskEls.layer);
          }
          container.appendChild(bodyWrap);
        }

        updateMaskVisual();
        if (currentMaskConfig && maskLayerEl) {
          requestAnimationFrame(() => {
            if (maskLayerEl) void maskLayerEl.offsetHeight;
          });
        }

        function syncAutoplayVideos() {
          const doSync = () => {
            const videos = container.querySelectorAll("video");
            videos.forEach((v) => {
              const box = v.closest("[data-autoplay]");
              const isAuto = v.hasAttribute("autoplay") || v.autoplay || (box && box.getAttribute("data-autoplay") === "true");
              if (isAuto) {
                v.muted = true;
                v.defaultMuted = true;
                v.setAttribute("muted", "");
                v.playsInline = true;
                v.setAttribute("playsinline", "");
                const playFn = () => {
                  if (!v.paused) return;
                  v.muted = true;
                  v.defaultMuted = true;
                  const p = v.play();
                  if (p !== undefined) {
                    p.catch(() => {
                      v.muted = true;
                      v.defaultMuted = true;
                      setTimeout(() => { if (v.paused) v.play().catch(() => {}); }, 150);
                    });
                  }
                };
                playFn();
                if (!v.__autoplayBound) {
                  v.__autoplayBound = true;
                  v.addEventListener("loadedmetadata", playFn);
                  v.addEventListener("canplay", playFn);
                }
              }
            });
          };
          setTimeout(doSync, 60);
          setTimeout(doSync, 200);
        }
        syncAutoplayVideos();
      }

      // Lightbox 控制逻辑
      const lightbox = document.getElementById("slidev-lightbox");
      const lightboxContent = document.getElementById("lightbox-content");
      const lightboxClose = document.getElementById("lightbox-close");
      let isLightboxOpen = false;

`}function cg(){return`      function openLightbox(type, src, alt) {
        if (!lightbox || !lightboxContent) return;
        lightboxContent.innerHTML = "";
        if (type === "video") {
          const v = document.createElement("video");
          v.className = "slidev-lightbox-video";
          v.src = src;
          v.controls = true;
          v.autoplay = true;
          v.playsInline = true;
          lightboxContent.appendChild(v);
        } else {
          const img = document.createElement("img");
          img.className = "slidev-lightbox-img";
          img.src = src;
          img.alt = alt || "";
          lightboxContent.appendChild(img);
        }
        lightbox.classList.add("active");
        isLightboxOpen = true;
      }

      function closeLightbox() {
        if (!lightbox) return;
        const v = lightbox.querySelector("video");
        if (v) v.pause();
        lightbox.classList.remove("active");
        if (lightboxContent) lightboxContent.innerHTML = "";
        isLightboxOpen = false;
      }

      if (lightboxClose) {
        lightboxClose.addEventListener("click", (e) => {
          e.stopPropagation();
          closeLightbox();
        });
      }
      if (lightbox) {
        lightbox.addEventListener("click", (e) => {
          if (e.target === lightbox || e.target === lightboxClose) {
            e.stopPropagation();
            closeLightbox();
          }
        });
      }

      btnPrev.addEventListener("click", () => goPrev());
      btnNext.addEventListener("click", () => goNext());
      btnFullscreen.addEventListener("click", () => {
        if (!document.fullscreenElement) {
          document.documentElement.requestFullscreen().then(() => updateScale()).catch(() => {});
        } else {
          document.exitFullscreen().then(() => updateScale()).catch(() => {});
        }
      });

      // 「数字+回车」跳页输入状态：数字缓冲实时回显，Esc/超时清空，越界红色抖动提示
      let jumpDisplay = "";
      let jumpInvalid = false;
      let jumpIdleTimer = null;
      let jumpFlashTimer = null;

`}function dg(){return`      function hideJumpIndicator() {
        jumpDisplay = "";
        jumpInvalid = false;
        jumpBadge.style.display = "none";
        jumpBadge.classList.remove("is-invalid");
        if (jumpIdleTimer) { clearTimeout(jumpIdleTimer); jumpIdleTimer = null; }
        if (jumpFlashTimer) { clearTimeout(jumpFlashTimer); jumpFlashTimer = null; }
      }

      function renderJumpBadge() {
        jumpBadge.textContent = jumpDisplay;
        jumpBadge.style.display = jumpDisplay ? "block" : "none";
        jumpBadge.classList.toggle("is-invalid", jumpInvalid);
      }

      function armJumpIdleTimer() {
        if (jumpIdleTimer) clearTimeout(jumpIdleTimer);
        jumpIdleTimer = setTimeout(hideJumpIndicator, 1500);
      }

      function flashJumpInvalid() {
        if (jumpIdleTimer) { clearTimeout(jumpIdleTimer); jumpIdleTimer = null; }
        jumpInvalid = true;
        renderJumpBadge();
        if (jumpFlashTimer) clearTimeout(jumpFlashTimer);
        jumpFlashTimer = setTimeout(hideJumpIndicator, 500);
      }

      function isEditableKeyTarget(t) {
        if (!t || !t.tagName) return false;
        return t.tagName === "INPUT" || t.tagName === "TEXTAREA" || t.tagName === "SELECT" || t.isContentEditable === true;
      }

`}function ug(){return`      function getSlideOverviewTitle(slide) {
        const fm = slide?.frontmatter || {};
        if (fm.title) return String(fm.title);
        const blocks = slide?.blocks || [];
        for (const b of blocks) {
          if (b.type === "h" || /^h[1-6]$/i.test(b.subType || "")) {
            const md = (b.rawMarkdown || b.content || "").trim();
            return md.replace(/^#{1,6}s+/, "").replace(/[*_\`]/g, "").slice(0, 40);
          }
        }
        return "";
      }

      // 把任意一页渲染为静态缩略图：复用 renderBlock 与主渲染同名版式类，导出样式自动生效
      function buildOverviewThumbInto(canvas, slide) {
        const fm = slide.frontmatter || {};
        const layout = fm.layout || "default";
        const blocks = (slide.blocks || []).filter((b) => b.slot !== "slot-divider-right");
        let headerBlocks = blocks.filter((b) => b.slot === "header");
        if (headerBlocks.length === 0 && blocks.length > 0) {
          const candidate = blocks.find((b) => b.type === "h" && (!b.slot || b.slot === "default"));
          if (candidate) headerBlocks = [candidate];
        }
        const rem = blocks.filter((b) => !headerBlocks.includes(b));
        let bodyEl = null;

        if (layout === "cols-header" || layout === "two-cols-header" || layout === "three-cols-header" || layout === "clover") {
          const isClover = layout === "clover";
          let targetCols = isClover ? 4 : 2;
          if (layout === "three-cols-header") targetCols = 3;
          else if (layout === "two-cols-header") targetCols = 2;
          else if (!isClover) {
            let maxCol = 0;
            for (const b of rem) {
              const m = (b.slot || "").match(/^col-(d+)$/i);
              if (m) maxCol = Math.max(maxCol, parseInt(m[1], 10));
            }
            if (maxCol >= 2) targetCols = maxCol;
            else if (fm.layoutRatio) {
              const r = String(fm.layoutRatio).trim();
              if (r.includes(":")) {
                const parts = r.split(":").map((p) => parseFloat(p.trim())).filter((n) => !isNaN(n) && n > 0);
                if (parts.length >= 2) targetCols = parts.length;
              }
            }
          }
          const hasColSlots = rem.some((b) => b.slot && /^col-d+$/i.test(b.slot));
          const containerDiv = document.createElement("div");
          containerDiv.className = (isClover ? "layout-clover-container" : ("layout-cols-header-container " + (targetCols === 2 ? "layout-two-cols-header-container" : (targetCols === 3 ? "layout-three-cols-header-container" : "")))) + (hasColSlots || isClover ? " has-superblock-cols" : "");
          const headerDiv = document.createElement("div");
          headerDiv.className = "layout-header-section";
          for (const b of headerBlocks) headerDiv.appendChild(renderBlock(b, ""));
          containerDiv.appendChild(headerDiv);
          const gridDiv = document.createElement("div");
          gridDiv.className = (isClover ? "layout-clover-grid pdf-clover-wrapper" : ("layout-cols-wrapper layout-cols-grid " + (targetCols === 2 ? "pdf-two-cols-wrapper layout-two-cols-grid" : (targetCols === 3 ? "pdf-three-cols-wrapper layout-three-cols-grid" : "")))) + (hasColSlots || isClover ? " has-superblock-cols" : "");
          const gridCols = isClover ? "repeat(2, minmax(0, 1fr))" : parseRatioToGridCols(fm.layoutRatio, targetCols);
          if (gridCols) gridDiv.style.gridTemplateColumns = gridCols;
          if (isClover) gridDiv.style.gridTemplateRows = "repeat(2, minmax(0, 1fr))";
          let colsList = [];
          for (let i = 0; i < targetCols; i++) colsList.push([]);
          const hasExplicitCols = rem.some((b) => b.slot && (b.slot.startsWith("col-") || b.slot === "left" || b.slot === "right" || b.slot === "center"));
          if (hasExplicitCols) {
            for (const b of rem) {
              let idx = 0;
              if (b.slot === "left" || b.slot === "col-1") idx = 0;
              else if (b.slot === "center" || b.slot === "col-2") idx = 1;
              else if (b.slot === "right") idx = targetCols === 2 ? 1 : targetCols - 1;
              else {
                const m = (b.slot || "").match(/^col-(d+)$/i);
                if (m) idx = Math.min(targetCols - 1, Math.max(0, parseInt(m[1], 10) - 1));
              }
              colsList[idx].push(b);
            }
          } else {
            let cur = 0;
            for (let i = 0; i < targetCols; i++) {
              const remainingCols = targetCols - i;
              const remainingItems = rem.length - cur;
              const take = Math.ceil(remainingItems / remainingCols);
              colsList[i] = rem.slice(cur, cur + take);
              cur += take;
            }
          }
          colsList.forEach((colBlocks, idx) => {
            const colDiv = document.createElement("div");
            colDiv.className = "pdf-col pdf-col--" + (idx + 1) + " col-" + (idx + 1) + (targetCols === 2 && idx === 0 ? " pdf-col--left" : "") + (targetCols === 2 && idx === 1 ? " pdf-col--right" : "");
            const cleaned = cleanColList(colBlocks);
            for (const b of cleaned) colDiv.appendChild(renderBlock(b, ""));
            gridDiv.appendChild(colDiv);
          });
          containerDiv.appendChild(gridDiv);
          bodyEl = containerDiv;
        } else if (layout === "two-cols") {
          bodyEl = document.createElement("div");
          bodyEl.style.display = "flex";
          bodyEl.style.flexDirection = "row";
          bodyEl.style.gap = "2rem";
          bodyEl.style.width = "100%";
          bodyEl.style.flex = "1";
          bodyEl.style.minHeight = "0";
          let leftList = [];
          let rightList = [];
          for (const b of blocks) {
            if (b.slot === "right") rightList.push(b);
            else leftList.push(b);
          }
          const leftCol = document.createElement("div");
          leftCol.className = "two-cols-left";
          const rightCol = document.createElement("div");
          rightCol.className = "two-cols-right";
          for (const b of cleanColList(leftList)) leftCol.appendChild(renderBlock(b, ""));
          for (const b of cleanColList(rightList)) rightCol.appendChild(renderBlock(b, ""));
          bodyEl.appendChild(leftCol);
          bodyEl.appendChild(rightCol);
        } else if (layout === "image-right" || layout === "image-left") {
          const isImageRight = layout === "image-right";
          bodyEl = document.createElement("div");
          bodyEl.style.display = "flex";
          bodyEl.style.flexDirection = isImageRight ? "row" : "row-reverse";
          bodyEl.style.gap = "2rem";
          bodyEl.style.width = "100%";
          bodyEl.style.flex = "1";
          bodyEl.style.minHeight = "0";
          const contentCol = document.createElement("div");
          contentCol.className = isImageRight ? "image-right-content" : "image-left-content";
          for (const b of blocks) contentCol.appendChild(renderBlock(b, ""));
          const imgCol = document.createElement("div");
          imgCol.className = isImageRight ? "image-right-img-container" : "image-left-img-container";
          const url = fm.image || fm.background || "";
          if (url) {
            const img = document.createElement("img");
            img.className = isImageRight ? "image-right-img" : "image-left-img";
            img.src = url;
            img.alt = "Slide cover";
            imgCol.appendChild(img);
          }
          bodyEl.appendChild(contentCol);
          bodyEl.appendChild(imgCol);
        } else {
          bodyEl = document.createElement("div");
          for (const b of blocks) bodyEl.appendChild(renderBlock(b, ""));
        }
        canvas.appendChild(bodyEl);
      }

      function buildOverviewCards() {
        if (overviewBuilt) return;
        overviewBuilt = true;
        const scale = OVERVIEW_CARD_W / baseWidth;
        const canvasH = Math.round(baseHeight * scale);
        slides.forEach((slide, idx) => {
          const card = document.createElement("div");
          card.className = "slidev-overview-card";
          card.dataset.idx = String(idx);
          const box = document.createElement("div");
          box.className = "slidev-overview-canvas-box";
          box.style.height = canvasH + "px";
          const fm = slide.frontmatter || {};
          const spacing = (fm.spacing && fm.spacing !== "inherit") ? fm.spacing : ((data.config && data.config.spacing) || "normal");
          const canvas = document.createElement("div");
          canvas.className = "slidev-overview-canvas slide-content layout-" + (fm.layout || "default") + " spacing-" + spacing;
          canvas.style.width = baseWidth + "px";
          canvas.style.height = baseHeight + "px";
          canvas.style.transform = "scale(" + scale + ")";
          const bg = fm.background;
          if (bg) {
            if (/^(http|/|data:|assets/)/.test(bg)) {
              canvas.style.backgroundImage = 'url("' + bg + '")';
              canvas.style.backgroundSize = "cover";
              canvas.style.backgroundPosition = "center";
            } else {
              canvas.style.background = bg;
            }
          }
          box.appendChild(canvas);
          const caption = document.createElement("div");
          caption.className = "slidev-overview-caption";
          const pageNo = document.createElement("span");
          pageNo.className = "slidev-overview-page-no";
          pageNo.textContent = String(idx + 1);
          caption.appendChild(pageNo);
          const title = getSlideOverviewTitle(slide);
          if (title) {
            const titleEl = document.createElement("span");
            titleEl.className = "slidev-overview-title";
            titleEl.textContent = title;
            caption.appendChild(titleEl);
          }
          card.appendChild(box);
          card.appendChild(caption);
          card.addEventListener("click", (e) => {
            e.stopPropagation();
            goFromOverview(idx + 1);
          });
          overviewGrid.appendChild(card);
        });
        updateOverviewCurrentMark();
      }

      function renderOverviewThumb(card) {
        if (!card || card.dataset.rendered === "1") return;
        const idx = Number(card.dataset.idx);
        const slide = slides[idx];
        const canvas = card.querySelector(".slidev-overview-canvas");
        if (slide && canvas) buildOverviewThumbInto(canvas, slide);
        card.dataset.rendered = "1";
      }

      function ensureOverviewObserver() {
        if (overviewObserver || typeof window.IntersectionObserver !== "function") return;
        overviewObserver = new IntersectionObserver((entries) => {
          for (const en of entries) {
            if (!en.isIntersecting) continue;
            overviewObserver.unobserve(en.target);
            renderOverviewThumb(en.target);
          }
        }, { rootMargin: "240px" });
      }

      function observeOverviewCards() {
        if (!overviewObserver) return;
        const cards = overviewGrid.children;
        for (let i = 0; i < cards.length; i++) {
          if (cards[i].dataset.rendered !== "1") overviewObserver.observe(cards[i]);
        }
      }

      function updateOverviewCurrentMark() {
        const cards = overviewGrid.children;
        for (let i = 0; i < cards.length; i++) {
          const pageNo = cards[i].querySelector(".slidev-overview-page-no");
          if (pageNo) pageNo.classList.toggle("is-current", i === currentIndex);
        }
      }

      function setOverviewFocus(page) {
        const total = slides.length || 1;
        overviewFocus = Math.min(Math.max(1, page), total);
        const cards = overviewGrid.children;
        for (let i = 0; i < cards.length; i++) {
          cards[i].classList.toggle("is-active", i + 1 === overviewFocus);
        }
        const el = cards[overviewFocus - 1];
        if (el && el.scrollIntoView) el.scrollIntoView({ block: "nearest", behavior: "smooth" });
      }

      function getOverviewCols() {
        if (!overviewGrid || !overviewGrid.clientWidth) return 1;
        return Math.max(1, Math.round(overviewGrid.clientWidth / (OVERVIEW_CARD_W + 18)));
      }

      function goFromOverview(page) {
        const p = parseInt(page, 10);
        if (isNaN(p) || p < 1 || p > slides.length) return;
        closeOverview();
        renderSlide(p - 1);
        updateOverviewCurrentMark();
      }

      function openOverview() {
        if (slides.length === 0) return;
        buildOverviewCards();
        overviewOpen = true;
        overviewOverlay.style.display = "block";
        ensureOverviewObserver();
        if (overviewObserver) {
          observeOverviewCards();
        } else {
          const cards = overviewGrid.children;
          for (let i = 0; i < cards.length; i++) renderOverviewThumb(cards[i]);
        }
        setOverviewFocus(currentIndex + 1);
      }

      function closeOverview() {
        overviewOpen = false;
        overviewOverlay.style.display = "none";
        hideJumpIndicator();
        if (overviewObserver) {
          const cards = overviewGrid.children;
          for (let i = 0; i < cards.length; i++) overviewObserver.unobserve(cards[i]);
        }
      }

      function toggleOverview() {
        if (overviewOpen) closeOverview();
        else openOverview();
      }

      // 总览打开期间接管全部按键：修复上游总览中空格/PGUP/PGDN 仍会翻页的漏洞
      function handleOverviewKeyDown(e) {
        if (e.ctrlKey || e.metaKey || e.altKey) return;
        if (e.isComposing || isEditableKeyTarget(e.target)) return;
        if (/^[0-9]$/.test(e.key)) {
          if (!jumpInvalid && jumpDisplay.length < 4) {
            jumpDisplay += e.key;
            const p = parseInt(jumpDisplay, 10);
            if (!isNaN(p) && p >= 1 && p <= slides.length) setOverviewFocus(p);
            renderJumpBadge();
            armJumpIdleTimer();
          }
          e.preventDefault();
          return;
        }
        if (e.key === "Enter" && jumpDisplay) {
          if (!jumpInvalid) {
            const page = parseInt(jumpDisplay, 10);
            if (!isNaN(page) && page >= 1 && page <= slides.length) {
              goFromOverview(page);
            } else {
              flashJumpInvalid();
            }
          }
          e.preventDefault();
          return;
        }
        if ((e.key === "Escape" || e.key === "Esc") && (jumpDisplay || jumpInvalid)) {
          hideJumpIndicator();
          e.preventDefault();
          return;
        }
        if (e.key === "ArrowRight") {
          e.preventDefault();
          setOverviewFocus(overviewFocus + 1);
          return;
        }
        if (e.key === "ArrowLeft") {
          e.preventDefault();
          setOverviewFocus(overviewFocus - 1);
          return;
        }
        if (e.key === "ArrowDown" || e.key === "PageDown") {
          e.preventDefault();
          setOverviewFocus(overviewFocus + getOverviewCols());
          return;
        }
        if (e.key === "ArrowUp" || e.key === "PageUp") {
          e.preventDefault();
          setOverviewFocus(overviewFocus - getOverviewCols());
          return;
        }
        if (e.key === " ") {
          e.preventDefault();
          return;
        }
        if (e.key === "Enter") {
          e.preventDefault();
          goFromOverview(overviewFocus);
          return;
        }
        if (e.key === "Escape" || e.key === "Esc" || e.key === "o" || e.key === "O") {
          e.preventDefault();
          closeOverview();
        }
      }

      window.addEventListener("keydown", (e) => {
        if (e.key === "Escape" || e.key === "Esc") {
          if (isLightboxOpen) {
            closeLightbox();
            e.preventDefault();
            return;
          }
        }
        if (isLightboxOpen) return;
        // 总览打开期间全部按键由总览层接管
        if (overviewOpen) {
          handleOverviewKeyDown(e);
          return;
        }
        // 「数字+回车」跳页：可输入元素、修饰键、IME 组合输入中不拦截
        if (!e.ctrlKey && !e.metaKey && !e.altKey && !e.isComposing && !isEditableKeyTarget(e.target)) {
          if (/^[0-9]$/.test(e.key)) {
            if (!jumpInvalid && jumpDisplay.length < 4) {
              jumpDisplay += e.key;
              renderJumpBadge();
              armJumpIdleTimer();
            }
            e.preventDefault();
            return;
          }
          if (e.key === "Enter" && jumpDisplay) {
            if (!jumpInvalid) {
              const page = parseInt(jumpDisplay, 10);
              if (!isNaN(page) && page >= 1 && page <= slides.length) {
                hideJumpIndicator();
                renderSlide(page - 1);
              } else {
                flashJumpInvalid();
              }
            }
            e.preventDefault();
            return;
          }
          if ((e.key === "Escape" || e.key === "Esc") && (jumpDisplay || jumpInvalid)) {
            hideJumpIndicator();
            e.preventDefault();
            return;
          }
          if (e.key === "o" || e.key === "O") {
            e.preventDefault();
            toggleOverview();
            return;
          }
        }
        if (e.key === "ArrowRight" || e.key === " " || e.key === "ArrowDown") goNext();
        if (e.key === "ArrowLeft" || e.key === "ArrowUp") goPrev();
        if (e.key === "f" || e.key === "F") btnFullscreen.click();
      });

      // 监听鼠标滚轮上下翻页调度
      let lastWheelTime = 0;
      const WHEEL_COOLDOWN_MS = 280;
      const WHEEL_DELTA_THRESHOLD = 15;

`}function fg(){return`      function canElementScrollY(el, deltaY) {
        let cur = el;
        while (cur && cur !== document.body && cur !== document.documentElement) {
          if (cur.classList && (cur.classList.contains("slidev-viewport") || cur.classList.contains("slidev-stage") || cur.classList.contains("slide-container"))) {
            break;
          }
          const style = window.getComputedStyle(cur);
          const overflowY = style.overflowY;
          if (overflowY === "auto" || overflowY === "scroll") {
            const maxScroll = cur.scrollHeight - cur.clientHeight;
            if (maxScroll > 2) {
              if (deltaY > 0 && cur.scrollTop < maxScroll - 1) return true;
              if (deltaY < 0 && cur.scrollTop > 1) return true;
            }
          }
          cur = cur.parentElement;
        }
        return false;
      }

      window.addEventListener("wheel", (e) => {
        if (isLightboxOpen) return;
        // 总览打开时滚轮交给总览列表原生滚动，不触发翻页
        if (overviewOpen) return;
        if (Math.abs(e.deltaY) < Math.abs(e.deltaX)) return;
        if (Math.abs(e.deltaY) < WHEEL_DELTA_THRESHOLD) return;

        const target = e.target instanceof Element ? e.target : e.target?.parentElement;
        if (target && canElementScrollY(target, e.deltaY)) return;

        e.preventDefault();
        const now = Date.now();
        if (now - lastWheelTime < WHEEL_COOLDOWN_MS) return;
        lastWheelTime = now;

        if (e.deltaY > 0) {
          goNext();
        } else {
          goPrev();
        }
      }, { passive: false });

      document.addEventListener("click", (e) => {
        if (isLightboxOpen) {
          const target = e.target instanceof Element ? e.target : e.target?.parentElement;
          const isMediaItself = target && target.closest && target.closest(".slidev-lightbox-img, .slidev-lightbox-video");
          if (!isMediaItself) {
            e.stopPropagation();
            closeLightbox();
          }
          return;
        }
        // 总览打开时空白点击由总览层自身处理，不触发底层翻页
        if (overviewOpen) return;
        if (e.button !== 0) return;
        const targetEl = e.target instanceof Element ? e.target : e.target?.parentElement;
        if (!targetEl || !targetEl.closest) return;

        const refEl = targetEl.closest("[data-ref-id]");
        if (refEl) {
          const id = refEl.getAttribute("data-ref-id");
          if (id) {
            window.open("siyuan://blocks/" + id, "_blank");
            return;
          }
        }

        // 媒体点击唤起 Lightbox 放大模态
        const mediaEl = targetEl.closest(".slide-content img, .slide-content video");
        if (mediaEl && !mediaEl.closest(".controls, .controls-bar, button, a")) {
          e.stopPropagation();
          const isVideo = mediaEl.tagName.toLowerCase() === "video";
          const src = isVideo ? (mediaEl.currentSrc || mediaEl.src || mediaEl.querySelector("source")?.src) : mediaEl.src;
          if (src) {
            openLightbox(isVideo ? "video" : "image", src, mediaEl.alt || "");
            return;
          }
        }

        const selection = window.getSelection ? window.getSelection().toString().trim() : "";
        if (selection.length > 0) return;

        const isComponent = targetEl.closest(
          ".slide-block, .controls-bar, .image-right-img-container, .image-left-img-container, .controls, img, video, audio, button, a, input, textarea, select, [data-clickable], [data-ref-id], .slidev-toc, .empty-state"
        );
        if (isComponent) return;

        const isLeft = e.clientX < window.innerWidth / 2;
        if (isLeft) {
          goPrev();
        } else {
          goNext();
        }
      });

      renderSlide(0);
      updateScale();
    })();`}function pg(){return[og(),sg(),rg(),lg(),ag(),cg(),dg(),ug(),fg()].join("")}function La(e,t){const i="Slidev 演示文稿";let n=e.slides;const o=JSON.stringify(n),s=JSON.stringify(e.config);return`<!DOCTYPE html>
<html lang="zh-CN">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${ot(i)}</title>
  <style>
${ng(t==null?void 0:t.customInlineStyles)}
  </style>
  <script>
    // 注入演示数据载荷
    window.__SLIDEV_DATA__ = {
      docId: ${JSON.stringify(e.docId)},
      slides: ${o},
      config: ${s}
    };
  <\/script>
</head>
<body>
  <div id="app" data-normalize-headings="${e.config.normalizeHeadingSizes?"true":"false"}">
    <div class="slide-viewport slidev-theme-${e.config.theme||"default"}" id="viewport" data-slidev-theme="${e.config.theme||"default"}">
      <div class="slide-content" id="slide-container"></div>
    </div>
    <div class="controls">
      <button id="btn-prev">◀ 上一页</button>
      <span id="page-num">1 / 1</span>
      <button id="btn-next">下一页 ▶</button>
      <button id="btn-fullscreen">全屏</button>
    </div>
    <!-- 全屏媒体灯箱 (Lightbox) 模态窗口 -->
    <div id="slidev-lightbox" class="slidev-lightbox">
      <button class="slidev-lightbox-close" id="lightbox-close" aria-label="关闭 (Esc)">✕</button>
      <div class="slidev-lightbox-content" id="lightbox-content"></div>
    </div>
  </div>

  <script>
${pg()}
  <\/script>
</body>
</html>`}function Oa(e,t){if(typeof document>"u")return!1;const i=new Blob([t],{type:"text/html;charset=utf-8"}),n=URL.createObjectURL(i),o=document.createElement("a");return o.href=n,o.download=e.endsWith(".html")?e:`${e}.html`,document.body.appendChild(o),o.click(),document.body.removeChild(o),URL.revokeObjectURL(n),!0}function hg(e){switch(e){case"4:3":return"size: 12in 9in;";case"A4-landscape":return"size: 297mm 210mm;";case"A4-portrait":return"size: 210mm 297mm;";case"16:9":default:return"size: 16in 9in;"}}function mg(e){const t=hg(e==null?void 0:e.pageRatio);return`
    ${En(e==null?void 0:e.customInlineStyles)}

    @page {
      ${t}
      margin: 0;
    }
    * {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
      -webkit-print-color-adjust: exact !important;
      print-color-adjust: exact !important;
    }
    body {
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "PingFang SC", "Microsoft YaHei", sans-serif;
      background: #f8fafc;
      color: #1e293b;
    }
    .pdf-slide-page {
      width: 100vw;
      height: 100vh;
      page-break-after: always;
      break-after: page;
      padding: var(--slidev-padding-y, 36px) var(--slidev-padding-x, 56px);
      display: flex;
      flex-direction: column;
      position: relative;
      background: #ffffff;
      overflow: hidden;
    }
    .pdf-slide-page.spacing-compact {
      --slidev-padding-y: 20px;
      --slidev-padding-x: 36px;
      --slidev-header-gap: 10px;
      --slidev-title-margin-bottom: 6px;
    }
    .pdf-slide-page.spacing-normal {
      --slidev-padding-y: 36px;
      --slidev-padding-x: 56px;
      --slidev-header-gap: 16px;
      --slidev-title-margin-bottom: 10px;
    }
    .pdf-slide-page.spacing-loose {
      --slidev-padding-y: 48px;
      --slidev-padding-x: 64px;
      --slidev-header-gap: 24px;
      --slidev-title-margin-bottom: 16px;
    }
    .pdf-slide-page.theme-dark {
      background: #0f1117;
      color: #f1f5f9;
    }
    .pdf-slide-header {
      font-size: 13px;
      color: #64748b;
      margin-bottom: 24px;
      display: flex;
      justify-content: space-between;
      border-bottom: 1px solid #e2e8f0;
      padding-bottom: 8px;
    }
    .theme-dark .pdf-slide-header {
      border-bottom-color: #2e3346;
      color: #94a3b8;
    }
    .pdf-slide-body {
      flex: 1;
      display: flex;
      flex-direction: column;
      gap: 16px;
      font-size: 20px;
      line-height: 1.6;
      overflow: hidden;
    }
    .pdf-block h1 { font-size: 2.5rem; font-weight: 800; color: #2563eb; margin-bottom: 12px; }
    .pdf-block h2 { font-size: 1.9rem; font-weight: 700; color: #1d4ed8; margin-bottom: 10px; }
    .pdf-block h3 { font-size: 1.4rem; font-weight: 600; margin-bottom: 8px; }
    .pdf-block h4 { font-size: 1.2rem; font-weight: 600; margin-bottom: 6px; }
    .pdf-block p { font-size: 1.15rem; color: inherit; }
    .pdf-code,
    pre {
      background: #f1f5f9;
      padding: 14px 18px;
      border-radius: 6px;
      font-family: "JetBrains Mono", Consolas, monospace;
      font-size: 0.95rem;
      border-left: 4px solid #3b82f6;
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      max-width: 100% !important;
      box-sizing: border-box !important;
    }
    .pdf-code code,
    pre code {
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      display: block !important;
      width: 100% !important;
      box-sizing: border-box !important;
    }
    .code-line {
      display: flex !important;
      align-items: flex-start !important;
      width: 100% !important;
      box-sizing: border-box !important;
      line-height: 1.6;
    }
    .code-line .line-no {
      display: inline-block !important;
      flex-shrink: 0 !important;
      min-width: 2.2em !important;
      text-align: right !important;
      margin-right: 12px !important;
      user-select: none !important;
      opacity: 0.45 !important;
    }
    .code-line .line-content {
      flex: 1 1 0% !important;
      min-width: 0 !important;
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
    }
    .theme-dark .pdf-code {
      background: #1e1e24;
      border-left-color: #60a5fa;
    }
    .pdf-quote {
      border-left: 4px solid #10b981;
      background: rgba(16, 185, 129, 0.08);
      padding: 10px 16px;
      border-radius: 0 4px 4px 0;
      font-style: italic;
    }
    .pdf-image,
    .slide-media-img {
      max-width: 100% !important;
      max-height: 48vh !important;
      width: auto !important;
      height: auto !important;
      object-fit: contain !important;
      border-radius: 6px;
      margin: auto;
      display: block;
    }
    .slide-media-block,
    .slide-media-container,
    .slide-video-container {
      display: flex;
      flex-direction: column;
      justify-content: center;
      align-items: center;
      width: 100%;
      max-height: 48vh;
      margin: 8px 0;
      overflow: hidden;
    }
    .slide-list-media {
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: flex-start;
      margin-top: 8px;
      margin-bottom: 6px;
      max-width: 100%;
      overflow: hidden;
    }
    .slide-list-media img,
    .slide-list-media video,
    .slide-list-media .list-item-gif {
      max-width: 100% !important;
      max-height: min(280px, 36vh) !important;
      width: auto !important;
      height: auto !important;
      min-width: 0 !important;
      min-height: 0 !important;
      object-fit: contain !important;
      border-radius: 6px;
      display: block;
      margin: 0 auto !important;
    }
    .slide-video-player {
      max-width: 100% !important;
      max-height: 48vh !important;
      width: auto !important;
      height: auto !important;
      object-fit: contain !important;
      border-radius: 6px;
      background: #000;
      border: 1px solid #cbd5e1;
    }
    .pdf-two-cols-wrapper,
    .layout-two-cols-grid,
    .layout-cols-wrapper,
    .layout-cols-grid {
      display: grid;
      grid-template-columns: minmax(0, 1fr) minmax(0, 1fr);
      grid-template-rows: minmax(0, 1fr) !important;
      gap: 36px;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      overflow: hidden !important;
    }
    .layout-cols-header-container,
    .layout-two-cols-header-container,
    .layout-three-cols-header-container,
    .layout-clover-container {
      display: flex;
      flex-direction: column;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      overflow: hidden !important;
    }
    .layout-header-section {
      width: 100%;
      margin-bottom: var(--slidev-header-gap, 16px) !important;
      flex-shrink: 0;
    }
    .layout-header-section h1,
    .layout-header-section h2,
    .layout-header-section h3 {
      margin-bottom: var(--slidev-title-margin-bottom, 10px) !important;
    }
    .pdf-three-cols-wrapper,
    .layout-three-cols-grid {
      display: grid;
      grid-template-columns: minmax(0, 1fr) minmax(0, 1fr) minmax(0, 1fr);
      grid-template-rows: minmax(0, 1fr) !important;
      gap: 24px;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      box-sizing: border-box;
      overflow: hidden !important;
    }
    .pdf-clover-wrapper,
    .layout-clover-grid {
      display: grid;
      grid-template-columns: repeat(2, minmax(0, 1fr)) !important;
      grid-template-rows: repeat(2, minmax(0, 1fr)) !important;
      gap: 20px;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      box-sizing: border-box;
      overflow: hidden !important;
    }
    .layout-clover-grid .pdf-col {
      background: transparent !important;
      border: none !important;
      box-shadow: none !important;
    }
    .pdf-col {
      display: flex;
      flex-direction: column;
      gap: 14px;
      min-width: 0;
      width: 100%;
      max-width: 100%;
      height: 100%;
      max-height: 100%;
      min-height: 0;
      justify-content: flex-start;
      overflow: hidden;
      box-sizing: border-box;
      overflow-wrap: break-word;
      word-break: break-word;
      white-space: normal;
    }
    /* 表头多栏内超级块子块首个列表项去圆点后居中显示标题/首行文本 (仅在存在超级块分栏时生效) */
    .has-superblock-cols .pdf-col > *:first-child .slide-list-item-title,
    .has-superblock-cols .pdf-col > *:first-child :is(h1, h2, h3, h4, h5, h6),
    .has-superblock-cols .pdf-col > *:first-child p.slide-list-item-title,
    .has-superblock-cols .pdf-col > *:first-child p:first-of-type,
    .has-superblock-cols .pdf-col > *:first-child p:first-child,
    .has-superblock-cols .pdf-col > *:first-child :is(ul, ol) > li:first-child,
    .has-superblock-cols .pdf-col > *:first-child .slide-list > .slide-list-item:first-child,
    .has-superblock-cols .pdf-col > *:first-child .pdf-list > li:first-child,
    .has-superblock-cols .slidev-col-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    .has-superblock-cols .slidev-col-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      list-style: none !important;
      list-style-type: none !important;
      text-align: center !important;
      margin-left: 0 !important;
      padding-left: 0 !important;
      width: 100% !important;
    }

    /* 彻底清除首个列表项的原生圆点 Marker (仅在存在超级块分栏时生效) */
    .has-superblock-cols .pdf-col > *:first-child :is(ul, ol) > li:first-child::marker {
      content: "" !important;
      display: none !important;
    }

    /* 确保首个列表项内部内联与块级元素居中 (仅在存在超级块分栏时生效) */
    .has-superblock-cols .pdf-col > *:first-child :is(ul, ol) > li:first-child * {
      text-align: center !important;
    }

    /* 栏内说明段落与列表项：左对齐，自然阅读排版 */
    .has-superblock-cols .pdf-col .slide-list-item-desc,
    .has-superblock-cols .pdf-col li:not(:first-child) {
      text-align: left !important;
    }

    /* 全局特定标题大小规范化 (除封面外页首首个标题按 H2 1.7rem，表头多栏内首个标题按 H3 1.3rem) */
    [data-normalize-headings="true"] .slidev-page-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .slidev-page-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .pdf-slide:not(.layout-cover) > :is(.pdf-block, .slide-block):first-child :is(h1, h2, h3, h4, h5, h6),
    [data-normalize-headings="true"] .pdf-slide:not(.layout-cover) > .layout-header-section :is(.pdf-block, .slide-block):first-child :is(h1, h2, h3, h4, h5, h6),
    [data-normalize-headings="true"] .pdf-slide:not(.layout-cover) > :not(.layout-cols-wrapper):not(.pdf-two-cols-wrapper):not(.layout-image-cols-grid):first-child :is(h1, h2, h3, h4, h5, h6) {
      font-size: 1.7rem !important;
      font-weight: 600 !important;
      line-height: 1.25 !important;
      margin-bottom: 10px !important;
    }

    [data-normalize-headings="true"] .has-superblock-cols .slidev-col-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .has-superblock-cols .slidev-col-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .has-superblock-cols .pdf-col > *:first-child :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      font-size: 1.3rem !important;
      font-weight: 600 !important;
      line-height: 1.3 !important;
      margin-bottom: 8px !important;
      text-align: center !important;
    }

    /* 图左与图右版式标题完全保留用户原始字号与默认排版，不进行任何固定大小规范化 */
    [data-normalize-headings="true"] :is(.layout-image-left, .layout-image-right, .image-left-content, .image-right-content) :is(h1, h2, h3, h4, h5, h6) {
      text-align: left !important;
    }
    .pdf-col > .pdf-block,
    .pdf-col > .slide-block {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      max-height: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      width: 100% !important;
      height: 100% !important;
      box-sizing: border-box !important;
      overflow: hidden !important;
    }
    .pdf-col .slide-list-item-title,
    .pdf-col h1, .pdf-col h2, .pdf-col h3, .pdf-col h4, .pdf-col h5, .pdf-col h6,
    .pdf-col .slide-list-item-desc {
      flex: 0 0 auto !important;
      margin-top: 0 !important;
      margin-bottom: 6px !important;
    }
    .pdf-col .slide-list-media,
    .pdf-col .slide-video-container,
    .pdf-col .slide-media-container {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      min-width: 0 !important;
      width: 100% !important;
      height: 100% !important;
      max-height: 100% !important;
      max-width: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
      justify-content: flex-start !important;
      overflow: hidden !important;
      margin: 0 !important;
      padding: 0 !important;
      box-sizing: border-box !important;
    }
    .pdf-col li:has(.slide-list-media),
    .pdf-col li:has(.slide-media-container),
    .pdf-col li:has(.slide-video-container),
    .pdf-col li:has(img),
    .pdf-col li:has(video),
    .pdf-col .pdf-list-item:has(.slide-list-media),
    .pdf-col .pdf-list-item:has(.slide-media-container),
    .pdf-col .pdf-list-item:has(.slide-video-container),
    .pdf-col .pdf-list-item:has(img),
    .pdf-col .pdf-list-item:has(video) {
      display: list-item !important;
      list-style-type: disc !important;
      flex: 0 0 auto !important;
      height: auto !important;
      max-height: none !important;
      overflow: visible !important;
      margin-bottom: 6px !important;
    }
    .pdf-col video,
    .layout-three-cols-grid video,
    .layout-two-cols-grid video,
    .pdf-col img,
    .layout-three-cols-grid img,
    .layout-two-cols-grid img,
    .pdf-col .slide-video-player {
      max-width: 100% !important;
      max-height: 100% !important;
      width: auto !important;
      height: auto !important;
      min-width: 0 !important;
      min-height: 0 !important;
      object-fit: contain !important;
      display: block !important;
      margin: 0 auto !important;
    }
    .pdf-col * {
      overflow-wrap: break-word;
      word-break: break-word;
      box-sizing: border-box;
    }
    .pdf-col pre {
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      max-width: 100% !important;
      box-sizing: border-box !important;
    }
    .pdf-list-item {
      padding-left: 20px;
    }
    .pdf-list {
      padding-left: 24px;
      margin: 8px 0;
      display: flex;
      flex-direction: column;
      gap: 6px;
    }
    .pdf-list li {
      font-size: 1.15rem;
      line-height: 1.6;
    }
    .pdf-task-item {
      list-style: none;
      margin-left: -20px;
      display: flex;
      align-items: center;
      gap: 8px;
    }
    .pdf-task-item input[type="checkbox"] {
      width: 1.15em;
      height: 1.15em;
      cursor: pointer;
    }
    /* 两栏与三栏及多栏（超级块分栏）布局：紧凑自然行距，子列表保留圆点与层级缩进 */
    .layout-two-cols ul,
    .layout-cols-header ul,
    .layout-two-cols-header ul,
    .layout-three-cols ul,
    .layout-three-cols-header ul,
    .two-cols-left ul,
    .two-cols-right ul,
    .three-cols-col ul,
    .col ul,
    .pdf-two-cols-wrapper ul,
    .pdf-three-cols-wrapper ul,
    .pdf-col ul,
    .layout-two-cols-grid .pdf-list,
    .layout-three-cols-grid .pdf-list,
    .layout-cols-grid .pdf-list,
    .layout-two-cols-grid .pdf-list--unordered,
    .layout-three-cols-grid .pdf-list--unordered,
    .layout-cols-grid .pdf-list--unordered {
      list-style: disc !important;
      list-style-type: disc !important;
      padding-left: 1.25em !important;
      margin-left: 0 !important;
      margin-top: 0 !important;
      margin-bottom: 8px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: block !important;
    }
    .layout-two-cols ol,
    .layout-cols-header ol,
    .layout-two-cols-header ol,
    .layout-three-cols ol,
    .layout-three-cols-header ol,
    .two-cols-left ol,
    .two-cols-right ol,
    .three-cols-col ol,
    .col ol,
    .pdf-two-cols-wrapper ol,
    .pdf-three-cols-wrapper ol,
    .pdf-col ol,
    .layout-two-cols-grid .pdf-list--ordered,
    .layout-three-cols-grid .pdf-list--ordered,
    .layout-cols-grid .pdf-list--ordered {
      list-style: decimal !important;
      list-style-type: decimal !important;
      padding-left: 1.25em !important;
      margin-left: 0 !important;
      margin-top: 0 !important;
      margin-bottom: 8px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: block !important;
    }
    .layout-two-cols li,
    .layout-cols-header li,
    .layout-two-cols-header li,
    .layout-three-cols li,
    .layout-three-cols-header li,
    .two-cols-left li,
    .two-cols-right li,
    .three-cols-col li,
    .col li,
    .pdf-col li,
    .pdf-col .pdf-list-item {
      padding-left: 0.2em !important;
      margin-left: 0 !important;
      margin-bottom: 6px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: list-item !important;
      line-height: 1.6 !important;
    }
    .layout-two-cols ul ul,
    .layout-three-cols ul ul,
    .three-cols-col ul ul,
    .pdf-col ul ul {
      list-style: circle !important;
      list-style-type: circle !important;
      padding-left: 1.25em !important;
      margin-top: 4px !important;
      margin-bottom: 4px !important;
    }
    /* 列表项内嵌标题与说明排版 */
    .slide-list-item-title,
    .pdf-list li > h1,
    .pdf-list li > h2,
    .pdf-list li > h3,
    .pdf-list li > h4,
    .pdf-list li > h5,
    .pdf-list li > h6,
    li > h1.slide-list-item-title,
    li > h2.slide-list-item-title,
    li > h3.slide-list-item-title,
    li > h4.slide-list-item-title {
      margin-top: 2px !important;
      margin-bottom: 6px !important;
      line-height: 1.35 !important;
      font-weight: 700 !important;
    }
    .pdf-list li > h1, li > h1.slide-list-item-title { font-size: 1.6rem !important; }
    .pdf-list li > h2, li > h2.slide-list-item-title { font-size: 1.4rem !important; }
    .pdf-list li > h3, li > h3.slide-list-item-title { font-size: 1.22rem !important; }
    .pdf-list li > h4, li > h4.slide-list-item-title { font-size: 1.1rem !important; }

    /* 全局特定标题大小规范化后置强力锁定 (防止被列表项内部字号覆盖) */
    [data-normalize-headings="true"] .slidev-page-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .slidev-page-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      font-size: 1.7rem !important;
      font-weight: 600 !important;
      line-height: 1.25 !important;
      margin-bottom: 10px !important;
    }
    [data-normalize-headings="true"] .has-superblock-cols .slidev-col-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .has-superblock-cols .slidev-col-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .has-superblock-cols .pdf-col > *:first-child :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      font-size: 1.3rem !important;
      font-weight: 600 !important;
      line-height: 1.3 !important;
      margin-bottom: 8px !important;
      text-align: center !important;
    }
    .slide-list-item-desc,
    .pdf-list li > p {
      margin-top: 4px !important;
      margin-bottom: 6px !important;
      font-size: 1.05rem;
      line-height: 1.55;
      opacity: 0.92;
    }
    kbd {
      display: inline-block;
      padding: 2px 7px;
      font-family: ui-monospace, SFMono-Regular, "SF Mono", Menlo, Consolas, "Liberation Mono", monospace;
      font-size: 0.85em;
      font-weight: 600;
      line-height: 1.25;
      color: inherit;
      background: rgba(125, 125, 125, 0.12);
      border: 1px solid rgba(125, 125, 125, 0.35);
      border-bottom-width: 2px;
      border-radius: 5px;
      box-shadow: 0 1px 2px rgba(0, 0, 0, 0.12);
      margin: 0 2px;
      vertical-align: middle;
      white-space: nowrap;
    }
    .theme-dark kbd {
      background: rgba(255, 255, 255, 0.1);
      border-color: rgba(255, 255, 255, 0.25);
      border-bottom-color: rgba(255, 255, 255, 0.4);
      color: #f1f5f9;
      box-shadow: 0 1px 2px rgba(0, 0, 0, 0.4);
    }
    a {
      color: inherit;
      text-decoration: none;
      border-bottom: 1px dashed currentColor;
    }
    .slidev-ref-tag, a.slidev-ref-tag {
      display: inline-flex;
      align-items: center;
      background: rgba(16, 185, 129, 0.1);
      color: #059669;
      border: 1px solid rgba(16, 185, 129, 0.25);
      border-radius: 4px;
      padding: 2px 8px;
      font-size: 0.88em;
      text-decoration: none;
      margin: 2px 4px 2px 0;
    }
    .theme-dark .slidev-ref-tag, .theme-dark a.slidev-ref-tag {
      background: rgba(52, 211, 153, 0.15);
      color: #34d399;
      border-color: rgba(52, 211, 153, 0.3);
    }
    .slidev-block-ref, .pdf-block--ref {
      background: rgba(16, 185, 129, 0.06);
      border-left: 3px solid #059669;
      border-radius: 0 6px 6px 0;
      padding: 10px 14px;
      margin: 8px 0;
    }
    .theme-dark .slidev-block-ref, .theme-dark .pdf-block--ref {
      background: rgba(52, 211, 153, 0.08);
      border-left-color: #34d399;
    }
    .pdf-slide-notes {
      font-size: 14px;
      color: #059669;
      border-top: 1px dashed #cbd5e1;
      padding-top: 12px;
      margin-top: auto;
      line-height: 1.5;
    }
    .theme-dark .pdf-slide-notes {
      color: #34d399;
      border-top-color: #334155;
    }
    /* Layouts */
    .layout-cover .pdf-slide-body {
      justify-content: center;
      align-items: center;
      text-align: center;
    }
    .layout-cover h1 {
      font-size: 3.2rem;
    }
    .layout-center .pdf-slide-body {
      justify-content: center;
      align-items: center;
      text-align: center;
    }
    .layout-fact .pdf-slide-body {
      justify-content: center;
      align-items: center;
      text-align: center;
    }
    .layout-fact h1 {
      font-size: 4.5rem;
      color: #ef4444;
    }
    @media print {
      .slidev-motion-fade-in,
      .slidev-motion-slide-up,
      .slidev-motion-slide-down,
      .slidev-motion-slide-left,
      .slidev-motion-slide-right,
      .slidev-motion-zoom-in,
      .slidev-motion-pop,
      .slidev-motion-bounce {
        animation: none !important;
        opacity: 1 !important;
        transform: none !important;
      }
      /* PDF 打印讲义下禁用动态蒙版遮挡，保证内容 100% 完整可见 */
      .slidev-mask-layer,
      .slidev-mask-overlay,
      .slidev-mask-divider-line {
        display: none !important;
        opacity: 0 !important;
      }
      .slidev-mask-body-container {
        clip-path: none !important;
        -webkit-clip-path: none !important;
        overflow: visible !important;
      }
    }
  `}function gg(e,t){const i="Slidev 演示讲义",n="16:9",o="light",s=e.slides.map((l,r)=>{const a=l.frontmatter.layout||"default",c=l.frontmatter.spacing,d=c&&c!=="inherit"?c:e.config.spacing||"normal",h=Da(l),v=`${r+1} / ${e.slides.length}`;return`
      <section class="pdf-slide-page layout-${a} theme-${o} spacing-${d}">
        <header class="pdf-slide-header">
          <span class="pdf-doc-title">${ot(i)}</span>
          ${`<span class="pdf-page-badge">P. ${v}</span>`}
        </header>
        <div class="pdf-slide-body">
          ${h}
        </div>
        ${l.notes?`
          <footer class="pdf-slide-notes">
            <strong>演讲备注:</strong> ${ot(l.notes)}
          </footer>
        `:""}
      </section>
    `}).join(`
`);return`<!DOCTYPE html>
<html lang="zh-CN">
<head>
  <meta charset="UTF-8">
  <title>${ot(i)} - 高保真讲义</title>
  <style>
    ${mg({pageRatio:n,customInlineStyles:t==null?void 0:t.customInlineStyles})}
  </style>
</head>
<body data-normalize-headings="${e.config.normalizeHeadingSizes?"true":"false"}">
  ${s}
</body>
</html>`}function Pa(e,t){var o;if(typeof window>"u"||typeof document>"u")return!1;const i=gg(e,t);try{const s=document.createElement("iframe");s.style.position="fixed",s.style.right="0",s.style.bottom="0",s.style.width="0",s.style.height="0",s.style.border="none",s.style.visibility="hidden",document.body.appendChild(s);const l=(o=s.contentWindow)==null?void 0:o.document;if(l)return l.open(),l.write(i),l.close(),setTimeout(()=>{var r,a;try{(r=s.contentWindow)==null||r.focus(),(a=s.contentWindow)==null||a.print()}finally{setTimeout(()=>{s.remove()},2e3)}},350),!0}catch(s){console.warn("[pdf-exporter] iframe 打印模式异常，降级尝试 window.open:",s)}const n=window.open("","_blank");return n?(n.document.write(i),n.document.close(),n.focus(),setTimeout(()=>{n.print(),n.close()},350),!0):!1}const vg=1500,bg=500,yg=4,kg=new Set(["INPUT","TEXTAREA","SELECT"]);function Ra(e){const t=e;return!t||!t.tagName?!1:kg.has(t.tagName)||t.isContentEditable===!0}function wg(e){let t="",i=!1,n=null,o=null;function s(){e.onStateChange&&e.onStateChange({display:t,invalid:i})}function l(){n&&(clearTimeout(n),n=null),o&&(clearTimeout(o),o=null)}function r(){l(),t="",i=!1,s()}function a(){n&&clearTimeout(n),n=setTimeout(r,vg)}function c(){n&&(clearTimeout(n),n=null),i=!0,s(),o&&clearTimeout(o),o=setTimeout(r,bg)}function d(h){if(e.isEnabled&&!e.isEnabled()||Ra(h.target)||h.isComposing||h.ctrlKey||h.metaKey||h.altKey)return!1;if(/^[0-9]$/.test(h.key))return i||t.length>=yg||(t+=h.key,s(),a()),!0;if(h.key==="Enter"){if(!t||i)return!1;const u=parseInt(t,10),m=e.getTotalPages();return!isNaN(u)&&u>=1&&m>0&&u<=m?(r(),e.onJump(u),!0):(c(),!0)}return h.key==="Escape"&&(t||i)?(r(),!0):!1}return{handleKeydown:d,getState:()=>({display:t,invalid:i}),clear:r}}const xg={class:"spm-slidev-tab__toolbar"},Sg={class:"spm-slidev-tab__nav"},_g=["disabled"],Cg={class:"spm-page-badge"},$g=["disabled"],Ig=["aria-label"],Tg=["aria-label"],Eg={class:"spm-slidev-tab__tools"},Ag=["src"],Bg=xt({__name:"SlidevPreviewTab",setup(e,{expose:t}){const i=Rt("plugin"),n=Rt("sandboxBridge",new Wo),o=new Gm(n),s=new ep,l=fe("web-sandbox"),r=fe(3030),a=fe(null),c=fe(!1),d=fe(null),h=fe(1),v=fe(1),u=fe([]),m=fe(!1),f=fe(!1),b=fe(!1),k=fe("siyuan"),x=fe(""),C=fe(""),A=fe(""),D=fe(!1),T=fe(!1),w=fe(""),R=fe(""),N=fe(!1),F=wg({getTotalPages:()=>v.value,isEnabled:()=>!f.value,onJump:$=>L($),onStateChange:$=>{R.value=$.display,N.value=$.invalid}});function q($){if($.key==="o"||$.key==="O"){if(f.value||$.isComposing||$.ctrlKey||$.metaKey||$.altKey||Ra($.target))return;$.preventDefault(),_();return}F.handleKeydown($)&&$.preventDefault()}function _(){var $,U;if(l.value==="pro-cli"){($=d.value)==null||$.focus(),me.showMessage("Pro 模式使用官方原生总览：在画面内按 O 呼出");return}n.toggleOverview(),(U=d.value)==null||U.focus()}function L($){var U;h.value=$,l.value==="pro-cli"?s.nativeBridge.navigateToPage($):n.navigatePage($),(U=d.value)==null||U.focus()}const y=fe("/plugins/siyuan-slidev/slidev-client/index.html");let M=null,H=null,E=null,O=null,z=null,X=null,Z=null,W=null;un(()=>{d.value&&(n.attach(d.value),s.nativeBridge.attach(d.value)),M=n.onSlideChanged(($,U)=>{h.value=$,v.value=U}),H=n.onBlockClicked(($,U)=>{h.value=U,o.setActiveBlockId($),i&&typeof i.handleBlockClickedFromSlide=="function"?i.handleBlockClickedFromSlide($,U):Ri($,i==null?void 0:i.app)}),E=n.onOpenInEditor(($,U)=>{h.value=U,o.setActiveBlockId($),Ri($,i==null?void 0:i.app)}),O=s.nativeBridge.onPageChanged(($,U)=>{h.value=$,v.value=U}),z=n.onOpenPeekDrawer(async $=>{const U=jo();if($.peekType==="siyuan"&&U.enableWebServeJump){let V=!1;if(W&&W.docId===$.target)V=!0;else if(W&&W.slides&&W.slides.some(G=>{var ee;return(ee=G.blocks)==null?void 0:ee.some(oe=>oe.id===$.target)}))V=!1;else try{const G=await on(`SELECT id, root_id, type FROM blocks WHERE id = '${$.target}' LIMIT 1`);G&&G.length>0&&(V=G[0].type==="d"||G[0].id===G[0].root_id)}catch(G){console.warn("[SlidevPreviewTab] detect block type failed:",G)}k.value="web",D.value=!0,C.value=va(U.webServeUrl,$.target,{focus:!V}),A.value=$.title||`${V?"思源文档":"思源块"}: ${$.target.slice(0,8)}`,f.value=!0,n.freezeKeyboardNav(!0)}else{if(k.value=$.peekType,$.peekType==="siyuan")x.value=$.target,A.value=$.title||`块速览: ${$.target.slice(0,8)}`;else{const V=Ea($.target);if(V.external){j($.target);return}D.value=!0,C.value=V.url,A.value=$.title||V.url}f.value=!0,n.freezeKeyboardNav(!0)}}),X=n.onRequestToggleFullscreen(()=>{K()}),Z=n.onOpenPresenter(()=>{B()}),typeof document<"u"&&document.addEventListener("fullscreenchange",g)}),No(()=>{typeof document<"u"&&document.removeEventListener("fullscreenchange",g),z&&z(),X&&X(),Z&&Z(),M&&M(),H&&H(),E&&E(),O&&O(),n.detach(),F.clear(),o.destroy(),s.destroy()});async function ie(){if(l.value==="web-sandbox"){if(!W){me.showMessage("请先在主编辑区打开演示文档");return}me.showMessage("正在探测本地 Node 环境并编排 Slidev Pro 进程...");const $=await s.startProMode(W,us);if(!$.success){me.showMessage(`无法启动官方 Pro 模式：${$.error}`);return}l.value="pro-cli",r.value=$.port||3030,y.value=$.url,d.value&&s.nativeBridge.attach(d.value),me.showMessage(`🟢 已成功接入官方原生 Slidev 服务 (端口: ${r.value})`)}else s.stopProMode(),l.value="web-sandbox",y.value="/plugins/siyuan-slidev/slidev-client/index.html",d.value&&n.attach(d.value),me.showMessage("已切回内置高保真沙箱")}function se(){T.value=!T.value,T.value?(w.value=(W==null?void 0:W.docId)||"",i&&typeof i.updatePreviewTabHeader=="function"&&i.updatePreviewTabHeader("",w.value)):(w.value="",Y(),i&&typeof i.updatePreviewTabHeader=="function"&&i.updatePreviewTabHeader())}let re=0;function ue($){if(f.value||Math.abs($.deltaY)<Math.abs($.deltaX)||Math.abs($.deltaY)<15)return;const U=Date.now();U-re<280||(re=U,$.deltaY>0?be():Ie())}function Ie(){if(h.value>1){const $=h.value-1;h.value=$,l.value==="pro-cli"?s.nativeBridge.navigateToPage($):n.navigatePage($)}}function be(){if(h.value<v.value){const $=h.value+1;h.value=$,l.value==="pro-cli"?s.nativeBridge.navigateToPage($):n.navigatePage($)}}function ae($){h.value=$,l.value==="pro-cli"?s.nativeBridge.navigateToPage($):n.navigatePage($)}function Y(){i&&typeof i.compileCurrentDocument=="function"?i.compileCurrentDocument():i!=null&&i.eventBus&&typeof i.eventBus.emit=="function"&&i.eventBus.emit("slidev:request-compile")}function ce(){f.value=!1,n.freezeKeyboardNav(!1)}function P(){ce()}function j($){var ee,oe;const U=/^file:/i.test($),V=U||/^[a-zA-Z]:[\\/]/.test($),G=Ct("electron");if(V&&typeof((ee=G==null?void 0:G.shell)==null?void 0:ee.openPath)=="function"){G.shell.openPath(U?Ta($):$),me.showMessage("本地文件不在思源工作区内，已交由系统默认浏览器打开");return}typeof((oe=G==null?void 0:G.shell)==null?void 0:oe.openExternal)=="function"?G.shell.openExternal($).catch(()=>{typeof window<"u"&&window.open($,"_blank")}):typeof window<"u"&&window.open($,"_blank"),me.showMessage("该地址无法在速览抽屉内加载，已交由系统默认浏览器打开")}function g(){typeof document<"u"&&(c.value=!!document.fullscreenElement,n.postMessage("FULLSCREEN_CHANGED",{isFullscreen:c.value}))}function K(){const $=a.value||d.value;$&&(document.fullscreenElement?document.exitFullscreen().then(()=>{n.postMessage("FULLSCREEN_CHANGED",{isFullscreen:!1})}).catch(()=>{}):$.requestFullscreen().then(()=>{n.postMessage("FULLSCREEN_CHANGED",{isFullscreen:!0})}).catch(()=>{}))}function B(){i&&typeof i.openPresenterTab=="function"&&i.openPresenterTab()}function S(){if(!W){me.showMessage("请先在主编辑区打开幻灯片文档");return}const $=La(W);Oa("presentation.html",$)&&me.showMessage("已开始下载单文件离线 HTML 演示包")}function I(){if(!W){me.showMessage("请先在主编辑区打开幻灯片文档");return}Pa(W)&&me.showMessage("已唤起打印视窗，请在打印选项中选择「另存为 PDF」")}return t({updateDocument($,U){T.value&&w.value&&U&&U!==w.value||(W=$,T.value&&!w.value&&(w.value=$.docId),u.value=$.slides,v.value=$.slides.length,o.setDocId($.docId),o.updateSlidesIndex($.slides),l.value==="pro-cli"?s.scaffolder.scaffold($,us).catch(()=>{}):n.updateSlides($.slides,$.config,$.fullMarkdown,$.customThemeCss),i&&typeof i.updatePreviewTabHeader=="function"&&i.updatePreviewTabHeader("",$.docId))},navigateToBlock($){o.onCursorFocusBlock($)},isPinned:T,pinnedDocId:w,engineMode:l,toggleEngineMode:ie}),($,U)=>(Q(),te("div",{class:"spm-slidev-preview-tab",onKeydown:q},[p("div",xg,[p("div",Sg,[p("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s",disabled:h.value<=1,"aria-label":"上一页",onClick:Ie},[le(de,{name:"chevron-left"})],8,_g),p("span",Cg,ye(h.value)+" / "+ye(v.value||1),1),p("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s",disabled:h.value>=v.value,"aria-label":"下一页",onClick:be},[le(de,{name:"chevron-right"})],8,$g),p("button",{class:Se(["spm-icon-btn b3-tooltips b3-tooltips__s",{"is-primary":T.value}]),"aria-label":T.value?"已锁定当前文档（点击解除）："+w.value:"点击锁定当前文档（不随主编辑区切换）",onClick:se},[le(de,{name:"pin"}),p("span",null,ye(T.value?"已锁定":"跟随"),1)],10,Ig),p("button",{class:Se(["spm-icon-btn b3-tooltips b3-tooltips__s",{"is-primary":l.value==="pro-cli"}]),"aria-label":l.value==="pro-cli"?"当前：官方原生 Pro 模式 (localhost:"+r.value+")，点击切回沙箱":"当前：内置高保真沙箱，点击切换官方原生 Pro 模式",onClick:ie},[le(de,{name:"rocket"}),p("span",null,ye(l.value==="pro-cli"?"Pro ("+r.value+")":"沙箱"),1)],10,Tg)]),p("div",Eg,[p("button",{class:Se(["spm-icon-btn b3-tooltips b3-tooltips__s",{"is-primary":m.value}]),"aria-label":"切换幻灯片大纲抽屉",onClick:U[0]||(U[0]=V=>m.value=!m.value)},[le(de,{name:"outline"})],2),p("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"缩略图总览 (O)",onClick:_},[le(de,{name:"columns"})]),p("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"双屏演讲者视图 (Presenter Mode ⌥M)",onClick:B},[le(de,{name:"presenter"})]),p("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"导出单文件 HTML 演示包",onClick:S},[le(de,{name:"export-html"})]),p("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"导出 16:9 PDF 演示讲义",onClick:I},[le(de,{name:"export-pdf"})]),p("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"重新编译并刷新",onClick:Y},[le(de,{name:"refresh"})]),p("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"全屏放映",onClick:K},[le(de,{name:"fullscreen"})])])]),p("div",{ref_key:"fullscreenContainerRef",ref:a,class:"spm-slidev-tab__viewport spm-slidev-fullscreen-container",onWheel:ue},[p("iframe",{ref_key:"sandboxIframeRef",ref:d,class:"spm-slidev-tab__iframe",src:y.value,frameborder:"0",allow:"fullscreen; autoplay"},null,8,Ag),le(sm,{visible:f.value,"onUpdate:visible":U[1]||(U[1]=V=>f.value=V),"is-maximized":b.value,"onUpdate:isMaximized":U[2]||(U[2]=V=>b.value=V),title:A.value,onClose:ce},{default:Fl(()=>[k.value==="siyuan"&&x.value?(Q(),Ot(hm,{key:0,"block-id":x.value,title:A.value,plugin:ve(i),onExternalJump:P},null,8,["block-id","title","plugin"])):Oe("",!0),D.value?Et((Q(),Ot(Vm,{key:1,visible:f.value&&k.value==="web",url:C.value,title:A.value,onExternalJump:P},null,8,["visible","url","title"])),[[_s,k.value==="web"]]):Oe("",!0)]),_:1},8,["visible","is-maximized","title"]),Et(p("div",{class:Se(["spm-jump-badge",{"is-invalid":N.value}])},ye(R.value),3),[[_s,R.value]])],544),m.value&&u.value.length>0?(Q(),Ot(Yh,{key:0,slides:u.value,"current-active-page":h.value,onNavigate:ae,onRefresh:Y},null,8,["slides","current-active-page"])):Oe("",!0)],32))}}),Mg=Mt(Bg,[["__scopeId","data-v-3d9b9312"]]),Es=980;function Dg(e,t=Es){const i=(e||"16/9").trim();let n=16/9;if(i==="4/3"||i==="4:3")n=4/3;else if(i==="16/10"||i==="16:10")n=16/10;else if(i.includes("/")||i.includes(":")){const s=i.includes("/")?"/":":",l=i.split(s).map(r=>parseFloat(r.trim()));l.length===2&&l[0]>0&&l[1]>0&&!isNaN(l[0])&&!isNaN(l[1])&&(n=l[0]/l[1])}else{const s=parseFloat(i);!isNaN(s)&&s>.2&&s<5&&(n=s)}const o=Math.ceil(t/n);return{baseWidth:t,baseHeight:o,ratio:n}}function qr(e,t,i=Es,n=552,o=16){const s=i>0?i:Es,l=n>0?n:552,r=Math.max(0,e-o),a=Math.max(0,t-o);if(r<=0||a<=0)return{scale:.36,boxWidth:Math.round(s*.36),boxHeight:Math.round(l*.36)};const c=Math.min(r/s,a/l),d=Math.max(.08,Math.min(1.5,Number(c.toFixed(4))));return{scale:d,boxWidth:Math.max(1,Math.round(s*d)),boxHeight:Math.max(1,Math.round(l*d))}}function Lg(e){return{...e,frontmatter:{...e.frontmatter||{}},blocks:Array.isArray(e.blocks)?e.blocks.map(t=>({...t,attrs:t.attrs?{...t.attrs}:void 0,attributes:t.attributes?{...t.attributes}:void 0,motion:t.motion?{...t.motion}:void 0,children:Array.isArray(t.children)?t.children.map(i=>({...i,attrs:i.attrs?{...i.attrs}:void 0,attributes:i.attributes?{...i.attributes}:void 0})):void 0})):[]}}function Zr(e,t){if(!e)return"";const i=Lg(e),n=i.frontmatter||{},o=n.layout||"default",s=(t==null?void 0:t.config)||{};(o==="image-right"||o==="image-left")&&!n.image&&!n.background&&s.image&&(n.image=s.image);const r=Da(i,{containerClassName:"slide-block",leftColClass:"pdf-col pdf-col--left two-cols-left",rightColClass:"pdf-col pdf-col--right two-cols-right",allSlides:(t==null?void 0:t.allSlides)||[],currentPageIndex:(t==null?void 0:t.pageIndex)||i.pageIndex||1,highlight:!0}).replace(/<video\b([^>]*)>/gi,(b,k)=>{let x=k.replace(/\bcontrols\b/gi,"").trim();return/\bmuted\b/i.test(x)||(x+=" muted"),`<video ${x.trim()}>`}),a=n.spacing,c=a&&a!=="inherit"?a:s.spacing||"normal",d=["slide-content",`layout-${o}`,`spacing-${c}`,n.class||"",n.layoutClass||""].filter(Boolean).join(" "),h=[],v=(n.background||"").trim();if(v)if(/^(?:https?:\/\/|\/|data:|assets\/|\.\/assets\/)/i.test(v)){const b=v.startsWith("assets/")?`/${v}`:v.startsWith("./assets/")?v.slice(1):v;h.push(`background-image:url('${ot(b)}');background-size:cover;background-position:center;background-repeat:no-repeat;`)}else h.push(`background:${ot(v)};`);const u=typeof n.zoom=="number"?n.zoom:typeof n.zoom=="string"?parseFloat(n.zoom):1,m=!isNaN(u)&&u>0?u:1;m!==1&&h.push(`width:${(100/m).toFixed(2)}%;height:${(100/m).toFixed(2)}%;transform-origin:top left;transform:scale(${m});`);const f=h.length>0?` style="${h.join("")}"`:"";return`<div class="${ot(d)}"${f}>${r}</div>`}const Og={class:"presenter-header"},Pg={class:"presenter-title"},Rg={class:"header-timer"},Ng={class:"timer-badge"},zg={class:"timer-controls"},Fg={key:0,class:"presenter-grid"},Hg={class:"slide-panels"},jg={class:"panel-box current-slide-panel"},Wg={class:"panel-header"},Ug=["aria-label"],Vg=["data-theme","data-slidev-theme","data-normalize-headings","innerHTML"],Kg={key:1,class:"panel-fallback"},Gg=["title"],qg={class:"panel-header"},Zg={key:0},Yg={key:1},Jg=["aria-label"],Xg=["data-theme","data-slidev-theme","data-normalize-headings","innerHTML"],Qg={key:1,class:"panel-fallback"},ev={class:"notes-panel"},tv={class:"panel-header"},iv={class:"notes-size-controls"},nv={class:"notes-size-value"},ov={key:1,class:"presenter-empty"},sv={class:"presenter-actions"},rv=["disabled"],lv={class:"actions-center"},av=["disabled"],cv=280,dv=15,uv=xt({__name:"SlidevPresenterTab",setup(e,{expose:t}){const i=Rt("plugin"),n=Rt("sandboxBridge",new Wo),o=fe([]),s=fe({}),l=fe(1),r=fe(0),a=we(()=>o.value.length||r.value),c=fe(null),d=fe(null),h=fe({width:0,height:0}),v=fe({width:0,height:0}),u=we(()=>{var B;return Dg((B=s.value)==null?void 0:B.aspectRatio)}),m=we(()=>{var B;return((B=s.value)==null?void 0:B.theme)||"default"}),f=we(()=>{var B;return((B=s.value)==null?void 0:B.colorSchema)==="light"?"light":"dark"}),b=we(()=>{var B;return!!((B=s.value)!=null&&B.normalizeHeadingSizes)}),k=we(()=>qr(h.value.width,h.value.height,u.value.baseWidth,u.value.baseHeight,14)),x=we(()=>qr(v.value.width,v.value.height,u.value.baseWidth,u.value.baseHeight,14));function C(){c.value&&(h.value={width:c.value.clientWidth,height:c.value.clientHeight}),d.value&&(v.value={width:d.value.clientWidth,height:d.value.clientHeight})}let A=null;function D(){typeof window>"u"||typeof window.ResizeObserver!="function"||(A||(A=new window.ResizeObserver(()=>{C()})),A.disconnect(),c.value&&A.observe(c.value),d.value&&A.observe(d.value))}ki([c,d,a],()=>{yo(()=>{D(),C()})},{flush:"post"});const T=fe(0),w=fe(!0);let R=null;const N=we(()=>{const B=String(Math.floor(T.value/60)).padStart(2,"0"),S=String(T.value%60).padStart(2,"0");return`${B}:${S}`});function F(){w.value=!w.value}function q(){T.value=0}const _=we(()=>o.value.length===0?null:o.value[l.value-1]||null),L=we(()=>l.value>=o.value.length?null:o.value[l.value]||null),y=we(()=>Zr(_.value,{config:s.value,allSlides:o.value,pageIndex:l.value})),M=we(()=>Zr(L.value,{config:s.value,allSlides:o.value,pageIndex:l.value+1})),H=we(()=>{var S;if(!_.value)return"无内容";const B=(S=_.value.blocks)==null?void 0:S[0];return(B==null?void 0:B.content)||(B==null?void 0:B.rawMarkdown)||`第 ${l.value} 页`});function E(B){return(B||[]).slice(1).map(S=>(S.content||S.rawMarkdown||"").trim()).filter(S=>S&&!/^(image\s+)?assets\/\S*$/i.test(S)&&!/^!\[[^\]]*\]\(assets\/[^)]*\)$/.test(S)).join(" | ").slice(0,120)}const O=we(()=>{var B;return E((B=_.value)==null?void 0:B.blocks)}),z=we(()=>{var S;if(!L.value)return"演示结束";const B=(S=L.value.blocks)==null?void 0:S[0];return(B==null?void 0:B.content)||(B==null?void 0:B.rawMarkdown)||`第 ${l.value+1} 页`}),X=we(()=>L.value?E(L.value.blocks):"这是最后一页"),Z=we(()=>{var B;return((B=_.value)==null?void 0:B.notes)||""}),W=fe(20);function ie(){W.value<36&&(W.value+=2)}function se(){W.value>12&&(W.value-=2)}const re=we(()=>a.value<=1?100:Math.round(l.value/a.value*100));let ue=null;try{ue=new BroadcastChannel("siyuan-slidev-sync"),ue.onmessage=B=>{const S=B.data;S&&(S.type==="SYNC_PAGE"&&typeof S.page=="number"&&(l.value=S.page),S.type==="SYNC_SLIDES"&&Array.isArray(S.slides)&&(o.value=S.slides,S.config&&typeof S.config=="object"&&(s.value=S.config)))}}catch{ue=null}function Ie(B){const S=Number(B)||1;n.navigatePage(S);try{ue==null||ue.postMessage({type:"SYNC_PAGE",page:S})}catch{}}function be(){l.value<a.value&&(l.value++,Ie(l.value))}function ae(){l.value>1&&(l.value--,Ie(l.value))}function Y(){l.value=1,q(),Ie(1)}function ce(){const B=i;typeof(B==null?void 0:B.openBottomPreviewTab)=="function"&&B.openBottomPreviewTab()}function P(B){var S,I;B.key===" "&&((I=(S=B.target)==null?void 0:S.closest)!=null&&I.call(S,"button"))||(B.key==="ArrowRight"||B.key===" "||B.key==="PageDown"?(B.preventDefault(),be()):(B.key==="ArrowLeft"||B.key==="PageUp")&&(B.preventDefault(),ae()))}let j=0;function g(B){var $,U;if(Math.abs(B.deltaY)<dv)return;const S=(U=($=B.target)==null?void 0:$.closest)==null?void 0:U.call($,".notes-content");if(S){const V=S.scrollHeight-S.clientHeight;if(V>2&&(B.deltaY>0&&S.scrollTop<V-1||B.deltaY<0&&S.scrollTop>1))return}const I=Date.now();I-j<cv||(j=I,B.deltaY>0?be():ae())}let K=null;return un(()=>{var S;R=window.setInterval(()=>{w.value&&T.value++},1e3),K=n.onSlideChanged((I,$)=>{l.value=I,$>0&&(r.value=$)});try{ue==null||ue.postMessage({type:"REQUEST_SYNC"})}catch{}const B=i==null?void 0:i.latestCompiledDoc;(S=B==null?void 0:B.slides)!=null&&S.length&&(o.value=B.slides,B.config&&(s.value=B.config)),typeof window<"u"&&window.addEventListener("resize",C),yo(()=>{D(),C()})}),No(()=>{R&&(window.clearInterval(R),R=null),K&&K(),typeof window<"u"&&window.removeEventListener("resize",C),A&&(A.disconnect(),A=null);try{ue==null||ue.close()}catch{}ue=null}),t({updateDocument(B){var S;(S=B==null?void 0:B.slides)!=null&&S.length&&(o.value=B.slides),B!=null&&B.config&&(s.value=B.config)}}),(B,S)=>{var I,$,U;return Q(),te("div",{class:"spm-presenter-tab",tabindex:"0",onKeydown:P,onWheel:g},[p("header",Og,[p("div",Pg,[S[1]||(S[1]=p("span",{class:"title-name"},"🎤 Slidev 演讲者控制台",-1)),S[2]||(S[2]=p("span",{class:"title-divider"},"|",-1)),p("span",null,"第 "+ye(l.value)+" / "+ye(a.value||1)+" 页",1)]),p("div",Rg,[p("div",Ng,"⏱ 已演讲: "+ye(N.value),1),p("div",zg,[p("button",{onClick:F},ye(w.value?"暂停":"开始"),1),p("button",{onClick:q},"重置")])])]),a.value>0?(Q(),te("main",Fg,[p("section",Hg,[p("div",jg,[p("div",Wg,[p("span",null,"当前大屏放映 (Page "+ye(l.value)+")",1),p("span",null,"布局: "+ye((($=(I=_.value)==null?void 0:I.frontmatter)==null?void 0:$.layout)||"default"),1)]),p("div",{ref_key:"currentPreviewRef",ref:c,class:"panel-preview","aria-label":H.value},[_.value?(Q(),te("div",{key:0,class:"presenter-thumb-box",style:Gt({width:k.value.boxWidth+"px",height:k.value.boxHeight+"px"})},[p("div",{class:Se(["presenter-thumb-viewport slide-viewport","slidev-theme-"+m.value]),"data-theme":f.value,"data-slidev-theme":m.value,"data-normalize-headings":b.value?"true":"false",style:Gt({width:u.value.baseWidth+"px",height:u.value.baseHeight+"px",transform:"scale("+k.value.scale+")"}),innerHTML:y.value},null,14,Vg)],4)):(Q(),te("div",Kg,[p("h2",null,ye(H.value),1),p("p",null,ye(O.value),1)]))],8,Ug)]),p("div",{class:Se(["panel-box next-slide-panel",{"is-clickable":!!L.value}]),title:L.value?"点击翻至下一页":"",onClick:S[0]||(S[0]=V=>L.value&&be())},[p("div",qg,[p("span",null,"下一页预告 (Page "+ye(l.value+1)+")",1),l.value>=a.value?(Q(),te("span",Zg,"已到达最后一页")):L.value?(Q(),te("span",Yg,"布局: "+ye(((U=L.value.frontmatter)==null?void 0:U.layout)||"default"),1)):Oe("",!0)]),p("div",{ref_key:"nextPreviewRef",ref:d,class:"panel-preview panel-preview--dim","aria-label":z.value},[L.value?(Q(),te("div",{key:0,class:"presenter-thumb-box",style:Gt({width:x.value.boxWidth+"px",height:x.value.boxHeight+"px"})},[p("div",{class:Se(["presenter-thumb-viewport slide-viewport","slidev-theme-"+m.value]),"data-theme":f.value,"data-slidev-theme":m.value,"data-normalize-headings":b.value?"true":"false",style:Gt({width:u.value.baseWidth+"px",height:u.value.baseHeight+"px",transform:"scale("+x.value.scale+")"}),innerHTML:M.value},null,14,Xg)],4)):(Q(),te("div",Qg,[p("h2",null,ye(z.value),1),p("p",null,ye(X.value),1)]))],8,Jg)],10,Gg)]),p("section",ev,[p("div",tv,[S[3]||(S[3]=p("span",null,"📝 演讲者私有备忘录 (Speaker Notes)",-1)),p("div",iv,[p("button",{onClick:se},"A-"),p("span",nv,ye(W.value)+"px",1),p("button",{onClick:ie},"A+")])]),p("div",{class:"notes-content",style:Gt({fontSize:W.value+"px"})},ye(Z.value||"（本页未设置演讲者备忘录）"),5)])])):(Q(),te("main",ov,[S[4]||(S[4]=p("div",{class:"empty-icon"},"📡",-1)),S[5]||(S[5]=p("h2",null,"等待大屏放映数据…",-1)),S[6]||(S[6]=p("p",null,"演讲者控制台需要「演示预览」页签（大屏放映端）提供幻灯片数据。",-1)),S[7]||(S[7]=p("p",{class:"empty-hint"},"若预览页签在另一窗口放映，本控制台将自动通过广播信道接入。",-1)),p("button",{class:"btn-empty-action",onClick:ce},"打开大屏放映页签")])),p("footer",sv,[p("button",{class:"btn-nav",disabled:l.value<=1,onClick:ae},"◀ 上一页 (Left)",8,rv),p("div",lv,[p("span",null,"进度: "+ye(re.value)+"%",1),S[8]||(S[8]=p("span",{class:"hint-text"},"按空格/方向键翻页，大屏联动",-1)),p("button",{class:"btn-ghost",onClick:Y},"⏮ 重头放映")]),p("button",{class:"btn-nav",disabled:l.value>=a.value,onClick:be},"下一页 (Right) ▶",8,av)])],32)}}}),fv=Mt(uv,[["__scopeId","data-v-5c1c4f29"]]),pv={class:"spm-section spm-section--page"},hv={class:"spm-section-header"},mv={key:0,class:"spm-card-control",style:{"border-left":"3px solid var(--b3-theme-primary)",background:"rgba(var(--b3-theme-primary-rgb, 66, 133, 244), 0.06)",padding:"8px 12px","margin-top":"6px"}},gv={style:{display:"flex","align-items":"center","justify-content":"space-between",gap:"8px"}},vv={style:{"font-size":"11px",display:"flex","align-items":"center",gap:"6px",flex:"1"}},bv={key:1,class:"spm-card-control"},yv={class:"spm-control-header"},kv={class:"spm-control-title-group"},wv={class:"spm-control-title"},xv={class:"spm-quick-chips"},Sv=["onClick"],_v={style:{display:"flex",gap:"6px","align-items":"center","margin-top":"6px"}},Cv=["value"],$v=["aria-label"],Iv={key:1,class:"spm-icon-btn b3-tooltips b3-tooltips__w",disabled:"",style:{opacity:"0.45",cursor:"not-allowed",padding:"0 8px",height:"26px","font-size":"11px","white-space":"nowrap","flex-shrink":"0"},"aria-label":"当前页未检测到调整过列宽的横向超级块"},Tv={key:0,style:{"margin-top":"6px","font-size":"11px",opacity:"0.85",display:"flex","align-items":"center",gap:"4px"}},Ev={style:{background:"rgba(125, 125, 125, 0.15)",padding:"1px 4px","border-radius":"3px","font-weight":"bold"}},Av={key:1,style:{"margin-top":"6px","font-size":"11px",opacity:"0.6",display:"flex","align-items":"center",gap:"4px"}},Bv={class:"spm-card-control"},Mv={class:"spm-control-header"},Dv={class:"spm-control-title-group"},Lv={class:"spm-control-title"},Ov={class:"spm-segmented-group"},Pv={key:0,style:{"margin-top":"10px",display:"flex","flex-direction":"column",gap:"8px"}},Rv={style:{display:"flex","align-items":"center","justify-content":"space-between"}},Nv={class:"b3-tooltips b3-tooltips__w","aria-label":`输入规则：
• 权重比例（项数决定步数）：如 1:1 (2步等分)、1:1:1 (3步等分)、1:2:1 (按权重累计分段)
• 绝对百分比：如 25:75:100 或 30:80 (指定每步展开的累计百分比)
• 每次点击或按空格/向右键展露下一段，全部揭开后翻页`,style:{cursor:"help",opacity:"0.75",display:"inline-flex","align-items":"center",gap:"3px","font-size":"11px"}},zv={class:"spm-quick-chips"},Fv=["onClick"],Hv={class:"b3-tooltips b3-tooltips__n",style:{width:"100%",display:"block"},"aria-label":"输入权重比例（如 1:2:1）或绝对累计百分比断点（如 25:75:100），冒号项数决定点击步数"},jv=["value"],Wv={style:{display:"flex",gap:"8px","margin-top":"2px"}},Uv={style:{flex:"1"}},Vv={class:"spm-segmented-group"},Kv={style:{flex:"1"}},Gv={class:"spm-segmented-group"},qv={class:"spm-card-control"},Zv={class:"spm-control-header"},Yv={class:"spm-control-title-group"},Jv={class:"spm-control-title"},Xv={class:"spm-segmented-group"},Qv={class:"spm-card-control"},eb={class:"spm-control-header"},tb={class:"spm-control-title-group"},ib={class:"spm-control-title"},nb={class:"spm-quick-chips"},ob=["onClick"],sb=["value"],rb={key:2,class:"spm-card-control"},lb={class:"spm-control-header"},ab={class:"spm-control-title-group"},cb={class:"spm-control-title"},db={class:"spm-quick-chips"},ub=["onClick"],fb=["value"],pb={class:"spm-card-control"},hb={class:"spm-control-header"},mb={class:"spm-control-title-group"},gb={class:"spm-control-title"},vb={key:0,class:"spm-note-status-box"},bb=["title"],yb={class:"spm-action-grid",style:{"margin-top":"6px"}},kb={key:1,class:"spm-note-empty-box"},wb={class:"spm-batch-actions-box",style:{"margin-top":"8px","border-top":"1px dashed var(--b3-border-color, #e2e8f0)","padding-top":"8px"}},xb={class:"spm-action-grid"},Sb=["disabled"],_b=["disabled"],Cb={class:"spm-card-control"},$b={class:"spm-action-grid"},Ib=xt({__name:"PageInspectorSection",props:{pageLayout:{},pageTransition:{},pageBackground:{},pageSpacing:{},pageImage:{},pageNotes:{},pageIndex:{},pageLayoutRatio:{},pageMask:{},pageMaskRatio:{},pageMaskStyle:{},pageMaskInitial:{},detectedSbRatio:{},detectedSbInfo:{},isBatchProcessing:{type:Boolean}},emits:["update:pageLayout","update:pageTransition","update:pageBackground","update:pageSpacing","update:pageImage","update:pageLayoutRatio","update:pageMask","update:pageMaskRatio","update:pageMaskStyle","update:pageMaskInitial","applySuperBlockLayout","resetSuperblockRatio","addNoteBlock","locateNoteBlock","generateNotes","batchAppendNotes","batchDeleteNotes","insertDividerAfter","deleteDivider"],setup(e,{emit:t}){const i=e,n=t,o=[{label:"1:1 (2步)",value:"1:1"},{label:"1:1:1 (3步)",value:"1:1:1"},{label:"1:2:1 (非等宽)",value:"1:2:1"},{label:"1:1:1:1 (4步)",value:"1:1:1:1"}],s=we(()=>["two-cols","cols-header","two-cols-header","three-cols-header","image-left","image-right"].includes(i.pageLayout)),l=we(()=>{var f,b;if(i.pageLayout==="two-cols-header"||i.pageLayout==="two-cols"||i.pageLayout==="image-left"||i.pageLayout==="image-right")return 2;if(i.pageLayout==="three-cols-header")return 3;const u=(i.pageLayoutRatio||"").trim();if(u.includes(":")){const k=u.split(":").filter(Boolean).length;if(k>=2&&k<=6)return k}const m=(i.detectedSbRatio||"").trim();if(m.includes(":")){const k=m.split(":").filter(Boolean).length;if(k>=2&&k<=6)return k}if((f=i.detectedSbInfo)!=null&&f.colCount&&i.detectedSbInfo.colCount>=2)return Math.min(i.detectedSbInfo.colCount,6);if((b=i.detectedSbInfo)!=null&&b.slots&&Array.isArray(i.detectedSbInfo.slots)){const k=i.detectedSbInfo.slots.length;if(k>=2&&k<=6)return k}return 2}),r=we(()=>{const u=l.value;return u===3?[{label:"默认 1:1:1",value:""},{label:"1:2:1 (主中)",value:"1:2:1"},{label:"2:1:1 (主左)",value:"2:1:1"},{label:"1:1:2 (主右)",value:"1:1:2"},{label:"1:3:1",value:"1:3:1"}]:u===4?[{label:"默认 1:1:1:1",value:""},{label:"1:2:2:1",value:"1:2:2:1"},{label:"2:1:1:2",value:"2:1:1:2"}]:u===5?[{label:"默认 1:1:1:1:1",value:""}]:u===6?[{label:"默认 1:1:1:1:1:1",value:""}]:[{label:"默认 1:1",value:""},{label:"1:2",value:"1:2"},{label:"2:1",value:"2:1"},{label:"3:7",value:"3:7"},{label:"7:3",value:"7:3"},{label:"4:6",value:"4:6"},{label:"6:4",value:"6:4"}]}),a=we(()=>i.pageLayoutRatio||"");function c(){const u=l.value||2,m=Array(u).fill("1").join(":");n("update:pageLayoutRatio",m),n("resetSuperblockRatio")}const d=we(()=>{if(!i.pageNotes)return"";const u=i.pageNotes.replace(/[\r\n]+/g," ").trim();return u.length>50?u.slice(0,50)+"...":u}),h=[{label:"默认",value:""},{label:"暗黑 #1e1e24",value:"#1e1e24"},{label:"极夜 #0f172a",value:"#0f172a"},{label:"极简白 #ffffff",value:"#ffffff"}],v=[{label:"默认封面",value:"https://cover.sli.dev"},{label:"清空配图",value:""}];return(u,m)=>(Q(),te("div",pv,[p("div",hv,[p("span",null,"幻灯片页面设置"+ye(e.pageIndex?` (第 ${e.pageIndex} 页)`:""),1)]),le(Ia,{"model-value":e.pageLayout,onChange:m[0]||(m[0]=f=>u.$emit("update:pageLayout",f))},null,8,["model-value"]),!s.value&&e.pageLayout!=="clover"&&e.detectedSbRatio?(Q(),te("div",mv,[p("div",gv,[p("div",vv,[le(de,{name:"sparkles"}),p("span",null,[m[31]||(m[31]=$t("检测到本页横向超级块列宽比例：",-1)),p("b",null,ye(e.detectedSbRatio),1)])]),p("button",{class:"spm-btn-action b3-tooltips b3-tooltips__w","aria-label":"一键将本页版式设为分栏并应用超级块列宽",style:{padding:"2px 8px",height:"26px","font-size":"11px","flex-shrink":"0",background:"var(--b3-theme-primary)",color:"#fff",display:"inline-flex","align-items":"center",gap:"4px"},onClick:m[1]||(m[1]=f=>u.$emit("applySuperBlockLayout",e.detectedSbInfo||{recommendedLayout:"two-cols",ratio:e.detectedSbRatio}))},[le(de,{name:"columns"}),m[32]||(m[32]=p("span",null,"设为分栏",-1))])])])):Oe("",!0),s.value?(Q(),te("div",bv,[p("div",yv,[p("div",kv,[p("div",wv,[le(de,{name:"ratio"}),m[33]||(m[33]=p("span",null,"分栏比例 (Ratio)",-1))]),m[34]||(m[34]=p("span",{class:"spm-control-desc"},"设置各列横向空间占比，默认平均分配",-1))])]),p("div",xv,[(Q(!0),te(Ue,null,kt(r.value,f=>(Q(),te("button",{key:f.value,class:Se(["spm-chip",{active:a.value===f.value}]),onClick:b=>u.$emit("update:pageLayoutRatio",f.value)},ye(f.label),11,Sv))),128))]),p("div",_v,[p("input",{value:e.pageLayoutRatio||"",class:"spm-input",style:{flex:"1","min-width":"0"},placeholder:"自定义比例（如 1:2 或 30:70，留空为默认）",onInput:m[2]||(m[2]=f=>u.$emit("update:pageLayoutRatio",f.target.value)),onChange:m[3]||(m[3]=f=>u.$emit("update:pageLayoutRatio",f.target.value))},null,40,Cv),e.detectedSbRatio?(Q(),te("button",{key:0,class:"spm-icon-btn b3-tooltips b3-tooltips__w","aria-label":`从当前页思源超级块读取实际宽度比例 (${e.detectedSbRatio}) 并应用`,style:{padding:"0 8px",height:"26px","font-size":"11px","white-space":"nowrap","flex-shrink":"0"},onClick:m[4]||(m[4]=f=>u.$emit("update:pageLayoutRatio",e.detectedSbRatio))},[le(de,{name:"sparkles"}),m[35]||(m[35]=p("span",null,"读取",-1))],8,$v)):(Q(),te("button",Iv,[le(de,{name:"sparkles"}),m[36]||(m[36]=p("span",null,"读取",-1))])),p("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__w","aria-label":"重置渲染比例为平均分布，并立即重置文档中超级块内容分布比例",style:{padding:"0 8px",height:"26px","font-size":"11px","white-space":"nowrap","flex-shrink":"0"},onClick:c},[le(de,{name:"reset"}),m[37]||(m[37]=p("span",null,"重置",-1))])]),e.detectedSbRatio?(Q(),te("div",Tv,[le(de,{name:"ratio"}),m[38]||(m[38]=p("span",null,"检测到思源超级块宽度：",-1)),p("code",Ev,ye(e.detectedSbRatio),1)])):(Q(),te("div",Av,[le(de,{name:"ratio"}),m[39]||(m[39]=p("span",null,"未检测到调宽超级块（默认各列平均分配）",-1))]))])):Oe("",!0),le(ir,{"model-value":e.pageTransition,onChange:m[5]||(m[5]=f=>u.$emit("update:pageTransition",f))},null,8,["model-value"]),p("div",Bv,[p("div",Mv,[p("div",Dv,[p("div",Lv,[le(de,{name:"sparkles"}),m[40]||(m[40]=p("span",null,"页面动态蒙版 (Dynamic Mask)",-1))]),m[41]||(m[41]=p("span",{class:"spm-control-desc"},"随着点击操作分段展露正文内容",-1))])]),p("div",Ov,[p("button",{class:Se(["spm-segmented-item",{active:!e.pageMask}]),onClick:m[6]||(m[6]=f=>u.$emit("update:pageMask",""))}," 关闭 ",2),p("button",{class:Se(["spm-segmented-item",{active:e.pageMask==="down"}]),onClick:m[7]||(m[7]=f=>u.$emit("update:pageMask","down"))}," 从上至下 ",2),p("button",{class:Se(["spm-segmented-item",{active:e.pageMask==="right"}]),onClick:m[8]||(m[8]=f=>u.$emit("update:pageMask","right"))}," 从左至右 ",2)]),e.pageMask?(Q(),te("div",Pv,[p("div",Rv,[m[43]||(m[43]=p("div",{style:{"font-size":"11px",opacity:"0.85","font-weight":"500"}},"展露比例 / 断点",-1)),p("span",Nv,[le(de,{name:"help"}),m[42]||(m[42]=p("span",null,"输入规则",-1))])]),p("div",zv,[(Q(),te(Ue,null,kt(o,f=>p("button",{key:f.value,class:Se(["spm-chip",{active:(e.pageMaskRatio||"1:1")===f.value}]),onClick:b=>u.$emit("update:pageMaskRatio",f.value)},ye(f.label),11,Fv)),64))]),p("div",Hv,[p("input",{value:e.pageMaskRatio||"1:1",class:"spm-input",style:{width:"100%"},placeholder:"自定义比例或断点（如 1:2:1 或 25:75:100）",onInput:m[9]||(m[9]=f=>u.$emit("update:pageMaskRatio",f.target.value)),onChange:m[10]||(m[10]=f=>u.$emit("update:pageMaskRatio",f.target.value))},null,40,jv)]),m[46]||(m[46]=p("div",{style:{"font-size":"10.5px",opacity:"0.6","line-height":"1.35","margin-top":"-2px"}}," 提示：支持权重比（如 1:2:1）或绝对断点（如 25:75:100），冒号项数决定点击步数 ",-1)),p("div",Wv,[p("div",Uv,[m[44]||(m[44]=p("div",{style:{"font-size":"11px",opacity:"0.85","margin-bottom":"4px"}},"遮盖质感",-1)),p("div",Vv,[p("button",{class:Se(["spm-segmented-item",{active:!e.pageMaskStyle||e.pageMaskStyle==="solid"}]),onClick:m[11]||(m[11]=f=>u.$emit("update:pageMaskStyle","solid"))}," 背景同色 ",2),p("button",{class:Se(["spm-segmented-item",{active:e.pageMaskStyle==="blur"}]),onClick:m[12]||(m[12]=f=>u.$emit("update:pageMaskStyle","blur"))}," 磨砂毛玻璃 ",2)])]),p("div",Kv,[m[45]||(m[45]=p("div",{style:{"font-size":"11px",opacity:"0.85","margin-bottom":"4px"}},"初始展露",-1)),p("div",Gv,[p("button",{class:Se(["spm-segmented-item",{active:!e.pageMaskInitial||e.pageMaskInitial==="hidden"}]),onClick:m[13]||(m[13]=f=>u.$emit("update:pageMaskInitial","hidden"))}," 完全遮盖 ",2),p("button",{class:Se(["spm-segmented-item",{active:e.pageMaskInitial==="revealed"}]),onClick:m[14]||(m[14]=f=>u.$emit("update:pageMaskInitial","revealed"))}," 首段可见 ",2)])])])])):Oe("",!0)]),p("div",qv,[p("div",Zv,[p("div",Yv,[p("div",Jv,[le(de,{name:"ratio"}),m[47]||(m[47]=p("span",null,"页面间距 (Spacing)",-1))]),m[48]||(m[48]=p("span",{class:"spm-control-desc"},"覆盖本页内边距与顶部标题间距",-1))])]),p("div",Xv,[p("button",{class:Se(["spm-segmented-item",{active:!e.pageSpacing||e.pageSpacing==="inherit"}]),onClick:m[15]||(m[15]=f=>u.$emit("update:pageSpacing","inherit"))}," 继承全局 ",2),p("button",{class:Se(["spm-segmented-item",{active:e.pageSpacing==="compact"}]),onClick:m[16]||(m[16]=f=>u.$emit("update:pageSpacing","compact"))}," 紧凑 ",2),p("button",{class:Se(["spm-segmented-item",{active:e.pageSpacing==="normal"}]),onClick:m[17]||(m[17]=f=>u.$emit("update:pageSpacing","normal"))}," 标准 ",2),p("button",{class:Se(["spm-segmented-item",{active:e.pageSpacing==="loose"}]),onClick:m[18]||(m[18]=f=>u.$emit("update:pageSpacing","loose"))}," 宽松 ",2)])]),p("div",Qv,[p("div",eb,[p("div",tb,[p("div",ib,[le(de,{name:"palette"}),m[49]||(m[49]=p("span",null,"页面背景 (Background)",-1))]),m[50]||(m[50]=p("span",{class:"spm-control-desc"},"设置当前页特定底色或壁纸",-1))])]),p("div",nb,[(Q(),te(Ue,null,kt(h,f=>p("button",{key:f.value,class:Se(["spm-chip",{active:e.pageBackground===f.value}]),onClick:b=>u.$emit("update:pageBackground",f.value)},ye(f.label),11,ob)),64))]),p("input",{value:e.pageBackground,class:"spm-input",placeholder:"自定义颜色代码或资源路径",onInput:m[19]||(m[19]=f=>u.$emit("update:pageBackground",f.target.value)),onChange:m[20]||(m[20]=f=>u.$emit("update:pageBackground",f.target.value))},null,40,sb)]),e.pageLayout==="image-right"||e.pageLayout==="image-left"||e.pageImage?(Q(),te("div",rb,[p("div",lb,[p("div",ab,[p("div",cb,[le(de,{name:"image"}),m[51]||(m[51]=p("span",null,"页面图片 (Image)",-1))]),m[52]||(m[52]=p("span",{class:"spm-control-desc"},"图文分栏或页面专属配图 URL / 资源路径",-1))])]),p("div",db,[(Q(),te(Ue,null,kt(v,f=>p("button",{key:f.value,class:Se(["spm-chip",{active:e.pageImage===f.value}]),onClick:b=>u.$emit("update:pageImage",f.value)},ye(f.label),11,ub)),64))]),p("input",{value:e.pageImage,class:"spm-input",placeholder:"网络图片 URL (如 https://cover.sli.dev) 或 assets/...",onInput:m[21]||(m[21]=f=>u.$emit("update:pageImage",f.target.value)),onChange:m[22]||(m[22]=f=>u.$emit("update:pageImage",f.target.value))},null,40,fb)])):Oe("",!0),p("div",pb,[p("div",hb,[p("div",mb,[p("div",gb,[le(de,{name:"presenter"}),m[53]||(m[53]=p("span",null,"演讲者提词 (Notes)",-1))]),m[54]||(m[54]=p("span",{class:"spm-control-desc"},"正文备注块驱动 · 仅演讲者视图可见",-1))]),p("button",{class:"spm-btn-text b3-tooltips b3-tooltips__w","aria-label":"AI 自动生成本页讲稿提示块",onClick:m[23]||(m[23]=f=>u.$emit("generateNotes"))},[le(de,{name:"sparkles"}),m[55]||(m[55]=p("span",null,"AI 讲稿",-1))])]),e.pageNotes?(Q(),te("div",vb,[m[58]||(m[58]=p("div",{class:"spm-note-status-badge"},[p("span",{class:"spm-badge-dot"}),p("span",null,"已配置正文讲稿")],-1)),p("div",{class:"spm-note-preview-text",title:e.pageNotes},ye(d.value),9,bb),p("div",yb,[p("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"在正文编辑区定位并高亮此讲稿备注块",onClick:m[24]||(m[24]=f=>u.$emit("locateNoteBlock"))},[le(de,{name:"search"}),m[56]||(m[56]=p("span",null,"定位讲稿块",-1))]),p("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"在本页末尾追加新的讲稿提示块",onClick:m[25]||(m[25]=f=>u.$emit("addNoteBlock"))},[le(de,{name:"insert-below"}),m[57]||(m[57]=p("span",null,"追加讲稿块",-1))])])])):(Q(),te("div",kb,[m[60]||(m[60]=p("div",{class:"spm-note-empty-hint"},"本页暂无讲稿备注块",-1)),p("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s",style:{width:"100%","margin-top":"6px"},"aria-label":"在当前页末尾插入默认演讲备注提示块",onClick:m[26]||(m[26]=f=>u.$emit("addNoteBlock"))},[le(de,{name:"insert-below"}),m[59]||(m[59]=p("span",null,"添加讲稿备注块",-1))])])),p("div",wb,[p("div",xb,[p("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s",disabled:e.isBatchProcessing,style:Gt(e.isBatchProcessing?"opacity: 0.5; cursor: not-allowed;":""),"aria-label":"在所有尚未配置讲稿的页面末尾批量追加讲稿提示块",onClick:m[27]||(m[27]=f=>u.$emit("batchAppendNotes"))},[le(de,{name:"insert-below"}),m[61]||(m[61]=p("span",null,"全部追加",-1))],12,Sb),p("button",{class:"spm-btn-action spm-btn-danger b3-tooltips b3-tooltips__s",disabled:e.isBatchProcessing,style:Gt(e.isBatchProcessing?"opacity: 0.5; cursor: not-allowed;":""),"aria-label":"批量物理删除正文中的全部讲稿备注块（涉及全部页）",onClick:m[28]||(m[28]=f=>u.$emit("batchDeleteNotes"))},[le(de,{name:"trash"}),m[62]||(m[62]=p("span",null,"全部删除",-1))],12,_b)])])]),p("div",Cb,[m[65]||(m[65]=p("div",{class:"spm-control-header"},[p("div",{class:"spm-control-title-group"},[p("span",{class:"spm-control-title"},"分页快捷操作")])],-1)),p("div",$b,[p("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"在此分页符之后插入新的空白分页",onClick:m[29]||(m[29]=f=>u.$emit("insertDividerAfter"))},[le(de,{name:"insert-below"}),m[63]||(m[63]=p("span",null,"插入新页",-1))]),p("button",{class:"spm-btn-action spm-btn-danger b3-tooltips b3-tooltips__s","aria-label":"彻底删除当前分页符（合并前后页面）",onClick:m[30]||(m[30]=f=>u.$emit("deleteDivider"))},[le(de,{name:"trash"}),m[64]||(m[64]=p("span",null,"删除此页",-1))])])])]))}}),Tb=Mt(Ib,[["__scopeId","data-v-1f9d4630"]]),Eb={class:"spm-section spm-section--block"},Ab={key:0,class:"spm-card-control",style:{"border-left":"3px solid var(--b3-theme-primary)"}},Bb={class:"spm-control-header"},Mb={class:"spm-control-title-group"},Db={class:"spm-control-title"},Lb={style:{background:"var(--b3-theme-surface)",border:"1px solid var(--b3-theme-surface-lighter)","border-radius":"6px",padding:"10px","margin-bottom":"8px"}},Ob={style:{display:"flex","align-items":"center","justify-content":"space-between","margin-bottom":"4px"}},Pb={style:{"font-size":"12px","font-weight":"500",display:"flex","align-items":"center",gap:"4px"}},Rb={key:0},Nb={key:1},zb={style:{background:"rgba(var(--b3-theme-primary-rgb, 59, 130, 246), 0.16)",color:"var(--b3-theme-primary)",border:"1px solid rgba(var(--b3-theme-primary-rgb, 59, 130, 246), 0.3)",padding:"2px 6px","border-radius":"4px","font-weight":"bold","font-size":"12px"}},Fb={style:{"font-size":"11px",opacity:"0.75","line-height":"1.4"}},Hb={class:"spm-action-grid"},jb={class:"spm-card-control"},Wb={class:"spm-control-header"},Ub={class:"spm-control-title-group"},Vb={class:"spm-control-title"},Kb=["aria-label"],Gb=["checked"],qb={key:1,class:"spm-card-control"},Zb={class:"spm-control-header"},Yb={class:"spm-control-title-group"},Jb={class:"spm-control-title"},Xb={class:"spm-quick-chips"},Qb={key:2,class:"spm-card-control"},e1={class:"spm-control-header"},t1={class:"spm-control-title-group"},i1={class:"spm-control-title"},n1={class:"spm-video-settings-grid",style:{display:"grid","grid-template-columns":"1fr 1fr",gap:"8px","margin-top":"8px"}},o1={class:"spm-toggle-item",style:{display:"flex","align-items":"center","justify-content":"space-between",padding:"4px 6px",background:"rgba(125,125,125,0.06)","border-radius":"4px"}},s1={style:{"font-size":"11px",display:"inline-flex","align-items":"center",gap:"4px"}},r1=["aria-label"],l1=["checked"],a1={class:"spm-toggle-item",style:{display:"flex","align-items":"center","justify-content":"space-between",padding:"4px 6px",background:"rgba(125,125,125,0.06)","border-radius":"4px"}},c1={style:{"font-size":"11px",display:"inline-flex","align-items":"center",gap:"4px"}},d1=["aria-label"],u1=["checked"],f1={class:"spm-toggle-item",style:{display:"flex","align-items":"center","justify-content":"space-between",padding:"4px 6px",background:"rgba(125,125,125,0.06)","border-radius":"4px"}},p1={style:{"font-size":"11px",display:"inline-flex","align-items":"center",gap:"4px"}},h1=["aria-label"],m1=["checked"],g1={class:"spm-toggle-item",style:{display:"flex","align-items":"center","justify-content":"space-between",padding:"4px 6px",background:"rgba(125,125,125,0.06)","border-radius":"4px"}},v1={style:{"font-size":"11px",display:"inline-flex","align-items":"center",gap:"4px"}},b1=["aria-label"],y1=["checked"],k1={class:"spm-card-control"},w1={class:"spm-control-header"},x1={class:"spm-control-title-group"},S1={class:"spm-control-title"},_1=["aria-label"],C1=["checked"],$1={key:0,class:"spm-quick-chips"},I1=["onClick"],T1={key:1,class:"spm-inherit-tip",style:{"margin-top":"6px",padding:"4px 8px",background:"rgba(var(--b3-theme-primary-rgb, 59, 130, 246), 0.08)","border-radius":"4px","font-size":"11px",opacity:"0.85",display:"flex","align-items":"center",gap:"4px"}},E1={class:"spm-card-control"},A1={class:"spm-control-header"},B1={class:"spm-control-title-group"},M1={class:"spm-control-title"},D1=["aria-label"],L1=["checked"],O1={key:0,class:"spm-quick-chips"},P1=["onClick"],R1={key:1,class:"spm-motion-details",style:{display:"flex","flex-direction":"column",gap:"4px","margin-top":"4px"}},N1={style:{display:"flex",gap:"8px","justify-content":"space-between","font-size":"11px",opacity:"0.8"}},z1={style:{display:"flex",gap:"6px"}},F1=["value"],H1=["value"],j1={key:3,class:"spm-card-control"},W1={class:"spm-control-header"},U1={class:"spm-control-title-group"},V1={class:"spm-control-title"},K1={class:"spm-control-desc"},G1={class:"spm-segmented-group"},q1=["onClick"],Z1={key:4,class:"spm-card-control"},Y1={class:"spm-control-header"},J1={class:"spm-control-title-group"},X1={class:"spm-control-title"},Q1={class:"spm-quick-chips"},ey=["onClick"],ty=["value"],iy={key:5,class:"spm-card-control"},ny={class:"spm-control-header"},oy={class:"spm-control-title-group"},sy={class:"spm-control-title"},ry={class:"spm-quick-chips"},ly=["onClick"],ay=["value"],cy={class:"spm-card-control"},dy={class:"spm-action-grid"},uy=["aria-label"],fy=xt({__name:"BlockInspectorSection",props:{elemClick:{},elemMotion:{},elemSlot:{},elemShikiLines:{},elemMaxHeight:{},isCodeBlock:{type:Boolean},isImage:{type:Boolean},isVideo:{type:Boolean},videoAutoplay:{type:Boolean},videoLoop:{type:Boolean},videoMuted:{type:Boolean},videoControls:{type:Boolean},hasBlockAttrs:{type:Boolean},isNote:{type:Boolean},imageRole:{},currentSlideLayout:{},isSuperBlock:{type:Boolean},parentElemClick:{},parentContainerSlot:{},parentContainerId:{},detectedSbInfo:{}},emits:["toggleNote","toggleElemClick","update:elemClick","update:elemMotion","update:elemSlot","update:elemShikiLines","update:elemMaxHeight","applySuperBlockLayout","applySuperBlockRatio","insertDividerBefore","insertDividerAfter","setTwoColsContrast","clearBlockAttrs","update:imageRole","toggleVideoAutoplay","toggleVideoLoop","toggleVideoMuted","toggleVideoControls"],setup(e,{emit:t}){const i=e,n=we(()=>{const T=i.currentSlideLayout||"";return["col-1","col-2","col-3","col-4","col-5","col-6"].includes(i.elemSlot)?"cols-header":T}),o=we(()=>{const T=n.value;return["two-cols","cols-header","two-cols-header","three-cols-header"].includes(T)}),s=we(()=>{var w,R,N,F;if((w=i.detectedSbInfo)!=null&&w.colCount&&i.detectedSbInfo.colCount>=2)return Math.min(i.detectedSbInfo.colCount,6);const T=(R=i.elemSlot)==null?void 0:R.match(/^col-(\d+)$/);if(T){const q=parseInt(T[1],10);if(q>=2&&q<=6)return Math.max(q,3)}if(i.currentSlideLayout==="three-cols-header")return 3;if(i.currentSlideLayout==="two-cols-header"||i.currentSlideLayout==="two-cols")return 2;if((F=(N=i.detectedSbInfo)==null?void 0:N.ratio)!=null&&F.includes(":")){const q=i.detectedSbInfo.ratio.split(":").filter(Boolean);if(q.length>=2)return Math.min(q.length,6)}return 3}),l=we(()=>{const T=n.value;return T==="cols-header"?"多栏插槽归属 (Slot)":T==="three-cols-header"?"三栏插槽归属 (Slot)":T==="two-cols-header"?"带表头双栏插槽 (Slot)":"多栏插槽归属 (Slot)"}),r=we(()=>{const T=n.value;return T==="cols-header"?`在 cols-header 表头多栏（${s.value} 栏）中的内容块位置`:T==="three-cols-header"?"在 three-cols-header 版式中的内容块位置":T==="two-cols-header"?"在 two-cols-header 版式中的内容块位置":T==="two-cols"?"在 two-cols 双栏版式中的归属":"在当前分栏版式中的内容块位置"}),a=we(()=>{const T=n.value;if(T==="two-cols")return[{value:"",label:"默认 (左)"},{value:"right",label:"右栏"}];if(T==="two-cols-header")return[{value:"",label:"默认"},{value:"header",label:"表头"},{value:"left",label:"左栏"},{value:"right",label:"右栏"}];if(T==="three-cols-header")return[{value:"",label:"默认"},{value:"header",label:"表头"},{value:"col-1",label:"第 1 栏"},{value:"col-2",label:"第 2 栏"},{value:"col-3",label:"第 3 栏"}];const w=s.value,R=[{value:"",label:"默认"},{value:"header",label:"表头"}];for(let N=1;N<=w;N++)R.push({value:`col-${N}`,label:`第 ${N} 栏`});return R});function c(T){const w=i.elemSlot||"";return T?w===T||T==="col-1"&&w==="left"||T==="col-2"&&w==="center"||T==="col-3"&&w==="right"&&s.value===3||T==="col-2"&&w==="right"&&s.value===2||T==="left"&&w==="col-1"||T==="right"&&(w==="col-2"||w==="col-3"):!w||w==="default"}const d=t,h=[{label:"上浮 (slide-up)",value:"slide-up"},{label:"淡入 (fade-in)",value:"fade-in"},{label:"下沉 (slide-down)",value:"slide-down"},{label:"左滑 (slide-left)",value:"slide-left"},{label:"右滑 (slide-right)",value:"slide-right"},{label:"缩放 (zoom-in)",value:"zoom-in"},{label:"弹性 (bounce)",value:"bounce"}],v=we(()=>{if(!i.elemMotion||i.elemMotion.trim()===""||i.elemMotion.trim()==="none")return null;try{const T=JSON.parse(i.elemMotion);if(typeof T=="object"&&T!==null)return{preset:T.preset||T.type||"slide-up",duration:typeof T.duration=="number"?T.duration:0,delay:typeof T.delay=="number"?T.delay:0}}catch{}return{preset:i.elemMotion.trim(),duration:0,delay:0}}),u=we(()=>!!v.value),m=we(()=>{var T;return((T=v.value)==null?void 0:T.preset)||"slide-up"}),f=we(()=>{var T;return((T=v.value)==null?void 0:T.duration)||0}),b=we(()=>{var T;return((T=v.value)==null?void 0:T.delay)||0});function k(){u.value?d("update:elemMotion",""):d("update:elemMotion","slide-up")}function x(T){D(T,f.value,b.value)}function C(T){D(m.value,T,b.value)}function A(T){D(m.value,f.value,T)}function D(T,w,R){if(!T||T==="none"){d("update:elemMotion","");return}if(!w&&!R){d("update:elemMotion",T);return}const N={preset:T};w>0&&(N.duration=w),R>0&&(N.delay=R),d("update:elemMotion",JSON.stringify(N))}return(T,w)=>{var R,N,F,q,_,L;return Q(),te("div",Eb,[w[62]||(w[62]=p("div",{class:"spm-section-header"},[p("span",null,"元素动效与排版")],-1)),e.isSuperBlock||(R=e.detectedSbInfo)!=null&&R.hasSuperBlock?(Q(),te("div",Ab,[p("div",Bb,[p("div",Mb,[p("div",Db,[le(de,{name:"ratio"}),w[24]||(w[24]=p("span",null,"超级块列宽与布局",-1))]),w[25]||(w[25]=p("span",{class:"spm-control-desc"},"读取思源超级块列宽并一键同步到幻灯片分栏",-1))])]),p("div",Lb,[p("div",Ob,[p("div",Pb,[le(de,{name:"ratio"}),(N=e.detectedSbInfo)!=null&&N.isCustomWidth?(Q(),te("span",Rb,"已识别自定义列宽比例")):(Q(),te("span",Nb,"识别到 "+ye(((F=e.detectedSbInfo)==null?void 0:F.colCount)||2)+" 列超级块分栏",1))]),p("code",zb,ye(((q=e.detectedSbInfo)==null?void 0:q.ratio)||"1:1"),1)]),p("div",Fb,ye((_=e.detectedSbInfo)!=null&&_.isCustomWidth?"检测到已调节子块宽度，可一键应用为当前页分栏比例。":"当前超级块子列为思源默认均宽，可在思源中拖动调节或直接应用。"),1)]),p("div",Hb,[p("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"一键将当前页版式切换为对应双栏/三栏，并写入此列宽比例",style:{background:"rgba(var(--b3-theme-primary-rgb, 59, 130, 246), 0.16)",color:"var(--b3-theme-primary)","font-weight":"500",border:"1px solid rgba(var(--b3-theme-primary-rgb, 59, 130, 246), 0.3)"},onClick:w[0]||(w[0]=y=>T.$emit("applySuperBlockLayout",e.detectedSbInfo))},[le(de,{name:"sparkles"}),w[26]||(w[26]=p("span",null,"应用版式与比例",-1))]),p("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"仅将提取的比值写入当前页的分栏比例属性",onClick:w[1]||(w[1]=y=>{var M;return T.$emit("applySuperBlockRatio",((M=e.detectedSbInfo)==null?void 0:M.ratio)||"1:1")})},[le(de,{name:"check"}),p("span",null,"应用比例 ("+ye(((L=e.detectedSbInfo)==null?void 0:L.ratio)||"1:1")+")",1)])])])):Oe("",!0),p("div",jb,[p("div",Wb,[p("div",Ub,[p("div",Vb,[le(de,{name:"presenter"}),w[27]||(w[27]=p("span",null,"设为讲稿备注",-1))]),w[28]||(w[28]=p("span",{class:"spm-control-desc"},"作为当前页演讲提词，不在幻灯片中渲染",-1))]),p("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":e.isNote?"取消讲稿备注":"设为讲稿备注"},[p("input",{type:"checkbox",checked:!!e.isNote,onChange:w[2]||(w[2]=y=>T.$emit("toggleNote"))},null,40,Gb),w[29]||(w[29]=p("span",{class:"spm-switch-slider"},null,-1))],8,Kb)])]),e.isImage||e.imageRole?(Q(),te("div",qb,[p("div",Zb,[p("div",Yb,[p("div",Jb,[le(de,{name:"image"}),w[30]||(w[30]=p("span",null,"图片角色与分栏 (Image & Layout)",-1))]),w[31]||(w[31]=p("span",{class:"spm-control-desc"},"设为幻灯片背景图或图文分栏配图",-1))])]),p("div",Xb,[p("button",{class:Se(["spm-chip",{active:!e.imageRole}]),onClick:w[3]||(w[3]=y=>T.$emit("update:imageRole",""))}," 普通内容 ",2),p("button",{class:Se(["spm-chip",{active:e.imageRole==="background"}]),onClick:w[4]||(w[4]=y=>T.$emit("update:imageRole","background"))},[le(de,{name:"image"}),w[32]||(w[32]=p("span",null,"背景图",-1))],2),p("button",{class:Se(["spm-chip",{active:e.imageRole==="image-left"}]),onClick:w[5]||(w[5]=y=>T.$emit("update:imageRole","image-left"))},[le(de,{name:"image-left"}),w[33]||(w[33]=p("span",null,"图左",-1))],2),p("button",{class:Se(["spm-chip",{active:e.imageRole==="image-right"}]),onClick:w[6]||(w[6]=y=>T.$emit("update:imageRole","image-right"))},[le(de,{name:"image-right"}),w[34]||(w[34]=p("span",null,"图右",-1))],2)])])):Oe("",!0),e.isVideo?(Q(),te("div",Qb,[p("div",e1,[p("div",t1,[p("div",i1,[le(de,{name:"video"}),w[35]||(w[35]=p("span",null,"视频播放设置 (Video Playback)",-1))]),w[36]||(w[36]=p("span",{class:"spm-control-desc"},"配置播放器控制条、自动播放与循环",-1))])]),p("div",n1,[p("div",o1,[p("span",s1,[le(de,{name:"sliders"}),w[37]||(w[37]=$t(" 控制条",-1))]),p("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":e.videoControls?"关闭控制条":"开启控制条"},[p("input",{type:"checkbox",checked:!!e.videoControls,onChange:w[7]||(w[7]=y=>T.$emit("toggleVideoControls"))},null,40,l1),w[38]||(w[38]=p("span",{class:"spm-switch-slider"},null,-1))],8,r1)]),p("div",a1,[p("span",c1,[le(de,{name:"video"}),w[39]||(w[39]=$t(" 自动播放",-1))]),p("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":e.videoAutoplay?"关闭自动播放":"开启自动播放"},[p("input",{type:"checkbox",checked:!!e.videoAutoplay,onChange:w[8]||(w[8]=y=>T.$emit("toggleVideoAutoplay"))},null,40,u1),w[40]||(w[40]=p("span",{class:"spm-switch-slider"},null,-1))],8,d1)]),p("div",f1,[p("span",p1,[le(de,{name:"repeat"}),w[41]||(w[41]=$t(" 循环播放",-1))]),p("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":e.videoLoop?"关闭循环播放":"开启循环播放"},[p("input",{type:"checkbox",checked:!!e.videoLoop,onChange:w[9]||(w[9]=y=>T.$emit("toggleVideoLoop"))},null,40,m1),w[42]||(w[42]=p("span",{class:"spm-switch-slider"},null,-1))],8,h1)]),p("div",g1,[p("span",v1,[le(de,{name:"volume-x"}),w[43]||(w[43]=$t(" 静音播放",-1))]),p("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":e.videoMuted?"关闭静音":"开启静音"},[p("input",{type:"checkbox",checked:!!e.videoMuted,onChange:w[10]||(w[10]=y=>T.$emit("toggleVideoMuted"))},null,40,y1),w[44]||(w[44]=p("span",{class:"spm-switch-slider"},null,-1))],8,b1)])])])):Oe("",!0),p("div",k1,[p("div",w1,[p("div",x1,[p("div",S1,[le(de,{name:"step"}),w[45]||(w[45]=p("span",null,"逐步呈现 (v-click)",-1))]),w[46]||(w[46]=p("span",{class:"spm-control-desc"},"放映时按步长逐个呈现",-1))]),p("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":e.elemClick?"关闭逐步呈现":"开启逐步呈现 (+1)"},[p("input",{type:"checkbox",checked:!!e.elemClick,onChange:w[11]||(w[11]=y=>T.$emit("toggleElemClick"))},null,40,C1),w[47]||(w[47]=p("span",{class:"spm-switch-slider"},null,-1))],8,_1)]),e.elemClick?(Q(),te("div",$1,[(Q(),te(Ue,null,kt(["+1","1","2","hide"],y=>p("button",{key:y,class:Se(["spm-chip",{active:e.elemClick===y}]),onClick:M=>T.$emit("update:elemClick",y)},ye(y==="+1"?"顺延 (+1)":y==="hide"?"隐藏 (hide)":"第 "+y+" 步"),11,I1)),64))])):e.parentElemClick?(Q(),te("div",T1,[le(de,{name:"check"}),w[48]||(w[48]=p("span",null,"未单独开启逐步呈现：当前跟随整栏同时出现",-1))])):Oe("",!0)]),p("div",E1,[p("div",A1,[p("div",B1,[p("div",M1,[le(de,{name:"motion"}),w[49]||(w[49]=p("span",null,"入场微动效 (v-motion)",-1))]),w[50]||(w[50]=p("span",{class:"spm-control-desc"},"为当前块添加平滑位移与渐入动画",-1))]),p("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":u.value?"关闭微动效":"开启微动效 (slide-up)"},[p("input",{type:"checkbox",checked:u.value,onChange:k},null,40,L1),w[51]||(w[51]=p("span",{class:"spm-switch-slider"},null,-1))],8,D1)]),u.value?(Q(),te("div",O1,[(Q(),te(Ue,null,kt(h,y=>p("button",{key:y.value,class:Se(["spm-chip",{active:m.value===y.value}]),onClick:M=>x(y.value)},ye(y.label),11,P1)),64))])):Oe("",!0),u.value?(Q(),te("div",R1,[p("div",N1,[p("span",null,"时长: "+ye(f.value?f.value+"ms":"默认 (450ms)"),1),p("span",null,"延迟: "+ye(b.value?b.value+"ms":"0ms"),1)]),p("div",z1,[p("select",{class:"spm-select",style:{flex:"1"},value:f.value,onChange:w[12]||(w[12]=y=>C(Number(y.target.value)))},[...w[52]||(w[52]=[p("option",{value:0},"默认耗时",-1),p("option",{value:200},"极速 (200ms)",-1),p("option",{value:350},"较快 (350ms)",-1),p("option",{value:500},"平滑 (500ms)",-1),p("option",{value:800},"缓慢 (800ms)",-1)])],40,F1),p("select",{class:"spm-select",style:{flex:"1"},value:b.value,onChange:w[13]||(w[13]=y=>A(Number(y.target.value)))},[...w[53]||(w[53]=[p("option",{value:0},"无延迟",-1),p("option",{value:150},"延迟 150ms",-1),p("option",{value:300},"延迟 300ms",-1),p("option",{value:500},"延迟 500ms",-1)])],40,H1)])])):Oe("",!0)]),o.value||e.elemSlot?(Q(),te("div",j1,[p("div",W1,[p("div",U1,[p("div",V1,[le(de,{name:"columns"}),p("span",null,ye(l.value),1)]),p("span",K1,ye(r.value),1)])]),p("div",G1,[(Q(!0),te(Ue,null,kt(a.value,y=>(Q(),te("button",{key:y.value,class:Se(["spm-segmented-item",{active:c(y.value)}]),onClick:M=>T.$emit("update:elemSlot",y.value)},ye(y.label),11,q1))),128))])])):Oe("",!0),e.isCodeBlock?(Q(),te("div",Z1,[p("div",Y1,[p("div",J1,[p("div",X1,[le(de,{name:"code"}),w[54]||(w[54]=p("span",null,"代码逐行聚光 (Shiki)",-1))]),w[55]||(w[55]=p("span",{class:"spm-control-desc"},"翻页时动态聚光高亮特定行",-1))])]),p("div",Q1,[(Q(),te(Ue,null,kt(["1-3","all","1|2|3","2-5"],y=>p("button",{key:y,class:Se(["spm-chip",{active:e.elemShikiLines===y}]),onClick:M=>T.$emit("update:elemShikiLines",y)},ye(y),11,ey)),64)),e.elemShikiLines?(Q(),te("button",{key:0,class:"spm-chip spm-chip-clear",onClick:w[14]||(w[14]=y=>T.$emit("update:elemShikiLines",""))}," 清空 ")):Oe("",!0)]),p("input",{value:e.elemShikiLines,class:"spm-input",placeholder:"自定义高亮区间，如 1-3|5|all",onInput:w[15]||(w[15]=y=>T.$emit("update:elemShikiLines",y.target.value)),onChange:w[16]||(w[16]=y=>T.$emit("update:elemShikiLines",y.target.value))},null,40,ty)])):Oe("",!0),e.isCodeBlock?(Q(),te("div",iy,[p("div",ny,[p("div",oy,[p("div",sy,[le(de,{name:"code"}),w[56]||(w[56]=p("span",null,"代码块限高 (Max Height)",-1))]),w[57]||(w[57]=p("span",{class:"spm-control-desc"},"超出限高自动竖向滚动，弱提示滚动条",-1))])]),p("div",ry,[(Q(),te(Ue,null,kt(["240px","320px","400px","50vh"],y=>p("button",{key:y,class:Se(["spm-chip",{active:e.elemMaxHeight===y}]),onClick:M=>T.$emit("update:elemMaxHeight",y)},ye(y),11,ly)),64)),e.elemMaxHeight?(Q(),te("button",{key:0,class:"spm-chip spm-chip-clear",onClick:w[17]||(w[17]=y=>T.$emit("update:elemMaxHeight",""))}," 自适应 ")):Oe("",!0)]),p("input",{value:e.elemMaxHeight,class:"spm-input",placeholder:"自适应高度，或输入 350px、50vh",onInput:w[18]||(w[18]=y=>T.$emit("update:elemMaxHeight",y.target.value)),onChange:w[19]||(w[19]=y=>T.$emit("update:elemMaxHeight",y.target.value))},null,40,ay)])):Oe("",!0),p("div",cy,[w[61]||(w[61]=p("div",{class:"spm-control-header"},[p("div",{class:"spm-control-title-group"},[p("span",{class:"spm-control-title"},"快捷操作")])],-1)),p("div",dy,[p("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"在当前块上方插入幻灯片分页线 (---)",onClick:w[20]||(w[20]=y=>T.$emit("insertDividerBefore"))},[le(de,{name:"insert-above"}),w[58]||(w[58]=p("span",null,"上方分页",-1))]),p("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"在当前块下方插入幻灯片分页线 (---)",onClick:w[21]||(w[21]=y=>T.$emit("insertDividerAfter"))},[le(de,{name:"insert-below"}),w[59]||(w[59]=p("span",null,"下方分页",-1))]),p("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":n.value==="three-cols-header"?"将当前块属性设为三栏第1栏归属 (slot: col-1)":"将当前块属性设为双栏左侧归属 (slot: left)",onClick:w[22]||(w[22]=y=>T.$emit("setTwoColsContrast"))},[le(de,{name:"columns"}),p("span",null,ye(n.value==="three-cols-header"?"设为第1栏":"设为双栏"),1)],8,uy),e.hasBlockAttrs?(Q(),te("button",{key:0,class:"spm-btn-action spm-btn-danger b3-tooltips b3-tooltips__s","aria-label":"一键移除本块所有 custom-slidev 属性",onClick:w[23]||(w[23]=y=>T.$emit("clearBlockAttrs"))},[le(de,{name:"broom"}),w[60]||(w[60]=p("span",null,"清除属性",-1))])):Oe("",!0)])])])}}}),py={class:"spm-section spm-section--doc"},hy={class:"spm-card-control"},my={class:"spm-control-header"},gy={class:"spm-control-title-group"},vy={class:"spm-control-title"},by={class:"spm-segmented-group"},yy=["aria-label","onClick"],ky={class:"spm-card-control"},wy={class:"spm-control-header"},xy={class:"spm-control-title-group"},Sy={class:"spm-control-title"},_y={class:"spm-segmented-group"},Cy={class:"spm-card-control"},$y={class:"spm-control-header"},Iy={class:"spm-control-title-group"},Ty={class:"spm-control-title"},Ey={class:"spm-segmented-group"},Ay={class:"spm-card-control"},By={class:"spm-control-header"},My={class:"spm-control-title-group"},Dy={class:"spm-control-title"},Ly={class:"spm-card-control"},Oy={class:"spm-control-header"},Py={class:"spm-control-title-group"},Ry={class:"spm-control-title"},Ny=["aria-label"],zy=["checked"],Fy={key:0,class:"spm-control-body",style:{"margin-top":"8px"}},Hy=["value"],jy={class:"spm-card-control"},Wy={class:"spm-control-header"},Uy={class:"spm-control-title-group"},Vy={class:"spm-control-title"},Ky=["aria-label"],Gy=["checked"],qy={class:"spm-card-control"},Zy={class:"spm-action-grid"},Yy=xt({__name:"DocInspectorSection",props:{docTheme:{},docAspectRatio:{},docDefaultTransition:{},docSpacing:{}},emits:["update:docTheme","update:docAspectRatio","update:docDefaultTransition","update:docSpacing","openBottomPreview","openPresenter","aiAutoSplit","exportHtml","exportPdf"],setup(e){const t=Rt("plugin"),i=gi,n=[{value:"default",label:"默认 default",desc:"官方默认科技风：现代无衬线排版与清新代码语法高亮，通用汇报与技术分享首选"},{value:"seriph",label:"优雅 seriph",desc:"典雅学术衬线风：书卷学术质感、衬线字体典雅庄重，适合学术论文、人文讲座与深度阅读"},{value:"apple-basic",label:"极简 apple",desc:"苹果发布会极简风：大字号、高对比度与极致留白，适合产品发布、方案演讲与纯粹视觉呈现"}];function o(a){Di({enableWebServeJump:a}),t&&typeof t.saveGlobalSettings=="function"&&t.saveGlobalSettings({enableWebServeJump:a})}async function s(a){var c;Di({normalizeHeadingSizes:a}),t&&typeof t.saveGlobalSettings=="function"&&await t.saveGlobalSettings({normalizeHeadingSizes:a}),t&&typeof t.compileCurrentDocument=="function"&&t.compileCurrentDocument(t.currentDocId||((c=t.getActiveDocumentId)==null?void 0:c.call(t)))}function l(a){Di({webServeUrl:a})}function r(a){Di({webServeUrl:a}),t&&typeof t.saveGlobalSettings=="function"&&t.saveGlobalSettings({webServeUrl:a})}return(a,c)=>(Q(),te("div",py,[c[39]||(c[39]=p("div",{class:"spm-section-header"},[p("span",null,"全局演示配置")],-1)),p("div",hy,[p("div",my,[p("div",gy,[p("div",vy,[le(de,{name:"palette"}),c[18]||(c[18]=p("span",null,"幻灯片主题 (Theme)",-1))]),c[19]||(c[19]=p("span",{class:"spm-control-desc"},"全局 Slidev 视觉设计范式",-1))])]),p("div",by,[(Q(),te(Ue,null,kt(n,d=>p("button",{key:d.value,class:Se(["spm-segmented-item b3-tooltips b3-tooltips__s",{active:e.docTheme===d.value}]),"aria-label":d.desc,onClick:h=>a.$emit("update:docTheme",d.value)},ye(d.label),11,yy)),64))])]),p("div",ky,[p("div",wy,[p("div",xy,[p("div",Sy,[le(de,{name:"ratio"}),c[20]||(c[20]=p("span",null,"画幅比例 (Aspect Ratio)",-1))]),c[21]||(c[21]=p("span",{class:"spm-control-desc"},"演讲屏幕投影宽高比",-1))])]),p("div",_y,[p("button",{class:Se(["spm-segmented-item",{active:e.docAspectRatio==="16/9"}]),onClick:c[0]||(c[0]=d=>a.$emit("update:docAspectRatio","16/9"))}," 16 : 9 (宽屏) ",2),p("button",{class:Se(["spm-segmented-item",{active:e.docAspectRatio==="4/3"}]),onClick:c[1]||(c[1]=d=>a.$emit("update:docAspectRatio","4/3"))}," 4 : 3 (标屏) ",2),p("button",{class:Se(["spm-segmented-item",{active:e.docAspectRatio==="16/10"}]),onClick:c[2]||(c[2]=d=>a.$emit("update:docAspectRatio","16/10"))}," 16 : 10 ",2)])]),p("div",Cy,[p("div",$y,[p("div",Iy,[p("div",Ty,[le(de,{name:"ratio"}),c[22]||(c[22]=p("span",null,"间距风格 (Spacing)",-1))]),c[23]||(c[23]=p("span",{class:"spm-control-desc"},"内边距与顶部标题下边距预设",-1))])]),p("div",Ey,[p("button",{class:Se(["spm-segmented-item b3-tooltips b3-tooltips__s",{active:(e.docSpacing||"normal")==="compact"}]),"aria-label":"紧凑排版：上下 20px / 左右 36px，释放垂直空间，适配图文分栏",onClick:c[3]||(c[3]=d=>a.$emit("update:docSpacing","compact"))}," 紧凑 (Compact) ",2),p("button",{class:Se(["spm-segmented-item b3-tooltips b3-tooltips__s",{active:(e.docSpacing||"normal")==="normal"}]),"aria-label":"标准排版：上下 32px / 左右 48px，协调美观（推荐默认）",onClick:c[4]||(c[4]=d=>a.$emit("update:docSpacing","normal"))}," 标准 (Normal) ",2),p("button",{class:Se(["spm-segmented-item b3-tooltips b3-tooltips__s",{active:(e.docSpacing||"normal")==="loose"}]),"aria-label":"宽松排版：上下 48px / 左右 56px，大留白适合极简大字",onClick:c[5]||(c[5]=d=>a.$emit("update:docSpacing","loose"))}," 宽松 (Loose) ",2)])]),p("div",Ay,[p("div",By,[p("div",My,[p("div",Dy,[le(de,{name:"transition"}),c[24]||(c[24]=p("span",null,"全局默认转场",-1))]),c[25]||(c[25]=p("span",{class:"spm-control-desc"},"页面切换过渡动效（未单设转场的页面将继承此动效）",-1))])]),le(ir,{"model-value":e.docDefaultTransition,"hide-header":!0,onChange:c[6]||(c[6]=d=>a.$emit("update:docDefaultTransition",d))},null,8,["model-value"])]),p("div",Ly,[p("div",Oy,[p("div",Py,[p("div",Ry,[le(de,{name:"external-link"}),c[26]||(c[26]=p("span",null,"本地网络伺服预览 (Web Serve)",-1))]),c[27]||(c[27]=p("span",{class:"spm-control-desc"},"点击文档/块链接以 Webview 抽屉呈现，支持外跳",-1))]),p("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":ve(i).enableWebServeJump?"关闭本地网络伺服预览":"开启本地网络伺服预览"},[p("input",{type:"checkbox",checked:ve(i).enableWebServeJump,onChange:c[7]||(c[7]=d=>o(d.target.checked))},null,40,zy),c[28]||(c[28]=p("span",{class:"spm-switch-slider"},null,-1))],8,Ny)]),ve(i).enableWebServeJump?(Q(),te("div",Fy,[p("input",{value:ve(i).webServeUrl,class:"spm-input",placeholder:"http://127.0.0.1:6806",spellcheck:"false",onKeydown:c[8]||(c[8]=Lt(()=>{},["stop"])),onKeyup:c[9]||(c[9]=Lt(()=>{},["stop"])),onInput:c[10]||(c[10]=d=>l(d.target.value)),onChange:c[11]||(c[11]=d=>r(d.target.value))},null,40,Hy),c[29]||(c[29]=p("span",{class:"spm-control-desc",style:{display:"block","margin-top":"4px","font-size":"11px",opacity:"0.8"}}," 默认伺服地址为 http://127.0.0.1:6806。开启后点击块链接将在 Webview 抽屉中打开，点击抽屉顶部『外跳』可在外部浏览器打开 ",-1))])):Oe("",!0)]),p("div",jy,[p("div",Wy,[p("div",Uy,[p("div",Vy,[le(de,{name:"type"}),c[30]||(c[30]=p("span",null,"固定特定标题大小",-1))]),c[31]||(c[31]=p("span",{class:"spm-control-desc"},"除封面外页首标题按 H2、多栏内首标题按 H3 大小展示",-1))]),p("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":ve(i).normalizeHeadingSizes?"关闭固定特定标题大小":"开启固定特定标题大小"},[p("input",{type:"checkbox",checked:ve(i).normalizeHeadingSizes,onChange:c[12]||(c[12]=d=>s(d.target.checked))},null,40,Gy),c[32]||(c[32]=p("span",{class:"spm-switch-slider"},null,-1))],8,Ky)])]),p("div",qy,[c[38]||(c[38]=p("div",{class:"spm-control-header"},[p("div",{class:"spm-control-title-group"},[p("span",{class:"spm-control-title"},"演示全局操作")])],-1)),p("div",Zy,[p("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"在当前文档下方开启分屏同步预览 (Alt+P)",onClick:c[13]||(c[13]=d=>a.$emit("openBottomPreview"))},[le(de,{name:"split-preview"}),c[33]||(c[33]=p("span",null,"分屏预览",-1))]),p("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"打开双屏演讲者控制台视窗 (Alt+M)",onClick:c[14]||(c[14]=d=>a.$emit("openPresenter"))},[le(de,{name:"presenter"}),c[34]||(c[34]=p("span",null,"演讲者视图",-1))]),p("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"智能分析长文本结构并给出大纲分页插入建议",onClick:c[15]||(c[15]=d=>a.$emit("aiAutoSplit"))},[le(de,{name:"sparkles"}),c[35]||(c[35]=p("span",null,"AI 智能分页",-1))]),p("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"打包导出离线单文件 HTML 幻灯片",onClick:c[16]||(c[16]=d=>a.$emit("exportHtml"))},[le(de,{name:"export-html"}),c[36]||(c[36]=p("span",null,"导出 HTML",-1))]),p("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"打印生成 16:9 高清演示 PDF 讲义",onClick:c[17]||(c[17]=d=>a.$emit("exportPdf"))},[le(de,{name:"export-pdf"}),c[37]||(c[37]=p("span",null,"导出 PDF",-1))])])])]))}});var eo=typeof globalThis<"u"?globalThis:typeof window<"u"?window:typeof global<"u"?global:typeof self<"u"?self:{};function Jy(e){return e&&e.__esModule&&Object.prototype.hasOwnProperty.call(e,"default")?e.default:e}function to(e){throw new Error('Could not dynamically require "'+e+'". Please configure the dynamicRequireTargets or/and ignoreDynamicRequires option of @rollup/plugin-commonjs appropriately for this require call to work.')}var ls={exports:{}};/*!

JSZip v3.10.1 - A JavaScript class for generating and reading zip files
<http://stuartk.com/jszip>

(c) 2009-2016 Stuart Knightley <stuart [at] stuartk.com>
Dual licenced under the MIT license or GPLv3. See https://raw.github.com/Stuk/jszip/main/LICENSE.markdown.

JSZip uses the library pako released under the MIT license :
https://github.com/nodeca/pako/blob/main/LICENSE
*/var Yr;function Xy(){return Yr||(Yr=1,(function(e,t){(function(i){e.exports=i()})(function(){return(function i(n,o,s){function l(c,d){if(!o[c]){if(!n[c]){var h=typeof to=="function"&&to;if(!d&&h)return h(c,!0);if(r)return r(c,!0);var v=new Error("Cannot find module '"+c+"'");throw v.code="MODULE_NOT_FOUND",v}var u=o[c]={exports:{}};n[c][0].call(u.exports,function(m){var f=n[c][1][m];return l(f||m)},u,u.exports,i,n,o,s)}return o[c].exports}for(var r=typeof to=="function"&&to,a=0;a<s.length;a++)l(s[a]);return l})({1:[function(i,n,o){var s=i("./utils"),l=i("./support"),r="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";o.encode=function(a){for(var c,d,h,v,u,m,f,b=[],k=0,x=a.length,C=x,A=s.getTypeOf(a)!=="string";k<a.length;)C=x-k,h=A?(c=a[k++],d=k<x?a[k++]:0,k<x?a[k++]:0):(c=a.charCodeAt(k++),d=k<x?a.charCodeAt(k++):0,k<x?a.charCodeAt(k++):0),v=c>>2,u=(3&c)<<4|d>>4,m=1<C?(15&d)<<2|h>>6:64,f=2<C?63&h:64,b.push(r.charAt(v)+r.charAt(u)+r.charAt(m)+r.charAt(f));return b.join("")},o.decode=function(a){var c,d,h,v,u,m,f=0,b=0,k="data:";if(a.substr(0,k.length)===k)throw new Error("Invalid base64 input, it looks like a data url.");var x,C=3*(a=a.replace(/[^A-Za-z0-9+/=]/g,"")).length/4;if(a.charAt(a.length-1)===r.charAt(64)&&C--,a.charAt(a.length-2)===r.charAt(64)&&C--,C%1!=0)throw new Error("Invalid base64 input, bad content length.");for(x=l.uint8array?new Uint8Array(0|C):new Array(0|C);f<a.length;)c=r.indexOf(a.charAt(f++))<<2|(v=r.indexOf(a.charAt(f++)))>>4,d=(15&v)<<4|(u=r.indexOf(a.charAt(f++)))>>2,h=(3&u)<<6|(m=r.indexOf(a.charAt(f++))),x[b++]=c,u!==64&&(x[b++]=d),m!==64&&(x[b++]=h);return x}},{"./support":30,"./utils":32}],2:[function(i,n,o){var s=i("./external"),l=i("./stream/DataWorker"),r=i("./stream/Crc32Probe"),a=i("./stream/DataLengthProbe");function c(d,h,v,u,m){this.compressedSize=d,this.uncompressedSize=h,this.crc32=v,this.compression=u,this.compressedContent=m}c.prototype={getContentWorker:function(){var d=new l(s.Promise.resolve(this.compressedContent)).pipe(this.compression.uncompressWorker()).pipe(new a("data_length")),h=this;return d.on("end",function(){if(this.streamInfo.data_length!==h.uncompressedSize)throw new Error("Bug : uncompressed data size mismatch")}),d},getCompressedWorker:function(){return new l(s.Promise.resolve(this.compressedContent)).withStreamInfo("compressedSize",this.compressedSize).withStreamInfo("uncompressedSize",this.uncompressedSize).withStreamInfo("crc32",this.crc32).withStreamInfo("compression",this.compression)}},c.createWorkerFrom=function(d,h,v){return d.pipe(new r).pipe(new a("uncompressedSize")).pipe(h.compressWorker(v)).pipe(new a("compressedSize")).withStreamInfo("compression",h)},n.exports=c},{"./external":6,"./stream/Crc32Probe":25,"./stream/DataLengthProbe":26,"./stream/DataWorker":27}],3:[function(i,n,o){var s=i("./stream/GenericWorker");o.STORE={magic:"\0\0",compressWorker:function(){return new s("STORE compression")},uncompressWorker:function(){return new s("STORE decompression")}},o.DEFLATE=i("./flate")},{"./flate":7,"./stream/GenericWorker":28}],4:[function(i,n,o){var s=i("./utils"),l=(function(){for(var r,a=[],c=0;c<256;c++){r=c;for(var d=0;d<8;d++)r=1&r?3988292384^r>>>1:r>>>1;a[c]=r}return a})();n.exports=function(r,a){return r!==void 0&&r.length?s.getTypeOf(r)!=="string"?(function(c,d,h,v){var u=l,m=v+h;c^=-1;for(var f=v;f<m;f++)c=c>>>8^u[255&(c^d[f])];return-1^c})(0|a,r,r.length,0):(function(c,d,h,v){var u=l,m=v+h;c^=-1;for(var f=v;f<m;f++)c=c>>>8^u[255&(c^d.charCodeAt(f))];return-1^c})(0|a,r,r.length,0):0}},{"./utils":32}],5:[function(i,n,o){o.base64=!1,o.binary=!1,o.dir=!1,o.createFolders=!0,o.date=null,o.compression=null,o.compressionOptions=null,o.comment=null,o.unixPermissions=null,o.dosPermissions=null},{}],6:[function(i,n,o){var s=null;s=typeof Promise<"u"?Promise:i("lie"),n.exports={Promise:s}},{lie:37}],7:[function(i,n,o){var s=typeof Uint8Array<"u"&&typeof Uint16Array<"u"&&typeof Uint32Array<"u",l=i("pako"),r=i("./utils"),a=i("./stream/GenericWorker"),c=s?"uint8array":"array";function d(h,v){a.call(this,"FlateWorker/"+h),this._pako=null,this._pakoAction=h,this._pakoOptions=v,this.meta={}}o.magic="\b\0",r.inherits(d,a),d.prototype.processChunk=function(h){this.meta=h.meta,this._pako===null&&this._createPako(),this._pako.push(r.transformTo(c,h.data),!1)},d.prototype.flush=function(){a.prototype.flush.call(this),this._pako===null&&this._createPako(),this._pako.push([],!0)},d.prototype.cleanUp=function(){a.prototype.cleanUp.call(this),this._pako=null},d.prototype._createPako=function(){this._pako=new l[this._pakoAction]({raw:!0,level:this._pakoOptions.level||-1});var h=this;this._pako.onData=function(v){h.push({data:v,meta:h.meta})}},o.compressWorker=function(h){return new d("Deflate",h)},o.uncompressWorker=function(){return new d("Inflate",{})}},{"./stream/GenericWorker":28,"./utils":32,pako:38}],8:[function(i,n,o){function s(u,m){var f,b="";for(f=0;f<m;f++)b+=String.fromCharCode(255&u),u>>>=8;return b}function l(u,m,f,b,k,x){var C,A,D=u.file,T=u.compression,w=x!==c.utf8encode,R=r.transformTo("string",x(D.name)),N=r.transformTo("string",c.utf8encode(D.name)),F=D.comment,q=r.transformTo("string",x(F)),_=r.transformTo("string",c.utf8encode(F)),L=N.length!==D.name.length,y=_.length!==F.length,M="",H="",E="",O=D.dir,z=D.date,X={crc32:0,compressedSize:0,uncompressedSize:0};m&&!f||(X.crc32=u.crc32,X.compressedSize=u.compressedSize,X.uncompressedSize=u.uncompressedSize);var Z=0;m&&(Z|=8),w||!L&&!y||(Z|=2048);var W=0,ie=0;O&&(W|=16),k==="UNIX"?(ie=798,W|=(function(re,ue){var Ie=re;return re||(Ie=ue?16893:33204),(65535&Ie)<<16})(D.unixPermissions,O)):(ie=20,W|=(function(re){return 63&(re||0)})(D.dosPermissions)),C=z.getUTCHours(),C<<=6,C|=z.getUTCMinutes(),C<<=5,C|=z.getUTCSeconds()/2,A=z.getUTCFullYear()-1980,A<<=4,A|=z.getUTCMonth()+1,A<<=5,A|=z.getUTCDate(),L&&(H=s(1,1)+s(d(R),4)+N,M+="up"+s(H.length,2)+H),y&&(E=s(1,1)+s(d(q),4)+_,M+="uc"+s(E.length,2)+E);var se="";return se+=`
\0`,se+=s(Z,2),se+=T.magic,se+=s(C,2),se+=s(A,2),se+=s(X.crc32,4),se+=s(X.compressedSize,4),se+=s(X.uncompressedSize,4),se+=s(R.length,2),se+=s(M.length,2),{fileRecord:h.LOCAL_FILE_HEADER+se+R+M,dirRecord:h.CENTRAL_FILE_HEADER+s(ie,2)+se+s(q.length,2)+"\0\0\0\0"+s(W,4)+s(b,4)+R+M+q}}var r=i("../utils"),a=i("../stream/GenericWorker"),c=i("../utf8"),d=i("../crc32"),h=i("../signature");function v(u,m,f,b){a.call(this,"ZipFileWorker"),this.bytesWritten=0,this.zipComment=m,this.zipPlatform=f,this.encodeFileName=b,this.streamFiles=u,this.accumulate=!1,this.contentBuffer=[],this.dirRecords=[],this.currentSourceOffset=0,this.entriesCount=0,this.currentFile=null,this._sources=[]}r.inherits(v,a),v.prototype.push=function(u){var m=u.meta.percent||0,f=this.entriesCount,b=this._sources.length;this.accumulate?this.contentBuffer.push(u):(this.bytesWritten+=u.data.length,a.prototype.push.call(this,{data:u.data,meta:{currentFile:this.currentFile,percent:f?(m+100*(f-b-1))/f:100}}))},v.prototype.openedSource=function(u){this.currentSourceOffset=this.bytesWritten,this.currentFile=u.file.name;var m=this.streamFiles&&!u.file.dir;if(m){var f=l(u,m,!1,this.currentSourceOffset,this.zipPlatform,this.encodeFileName);this.push({data:f.fileRecord,meta:{percent:0}})}else this.accumulate=!0},v.prototype.closedSource=function(u){this.accumulate=!1;var m=this.streamFiles&&!u.file.dir,f=l(u,m,!0,this.currentSourceOffset,this.zipPlatform,this.encodeFileName);if(this.dirRecords.push(f.dirRecord),m)this.push({data:(function(b){return h.DATA_DESCRIPTOR+s(b.crc32,4)+s(b.compressedSize,4)+s(b.uncompressedSize,4)})(u),meta:{percent:100}});else for(this.push({data:f.fileRecord,meta:{percent:0}});this.contentBuffer.length;)this.push(this.contentBuffer.shift());this.currentFile=null},v.prototype.flush=function(){for(var u=this.bytesWritten,m=0;m<this.dirRecords.length;m++)this.push({data:this.dirRecords[m],meta:{percent:100}});var f=this.bytesWritten-u,b=(function(k,x,C,A,D){var T=r.transformTo("string",D(A));return h.CENTRAL_DIRECTORY_END+"\0\0\0\0"+s(k,2)+s(k,2)+s(x,4)+s(C,4)+s(T.length,2)+T})(this.dirRecords.length,f,u,this.zipComment,this.encodeFileName);this.push({data:b,meta:{percent:100}})},v.prototype.prepareNextSource=function(){this.previous=this._sources.shift(),this.openedSource(this.previous.streamInfo),this.isPaused?this.previous.pause():this.previous.resume()},v.prototype.registerPrevious=function(u){this._sources.push(u);var m=this;return u.on("data",function(f){m.processChunk(f)}),u.on("end",function(){m.closedSource(m.previous.streamInfo),m._sources.length?m.prepareNextSource():m.end()}),u.on("error",function(f){m.error(f)}),this},v.prototype.resume=function(){return!!a.prototype.resume.call(this)&&(!this.previous&&this._sources.length?(this.prepareNextSource(),!0):this.previous||this._sources.length||this.generatedError?void 0:(this.end(),!0))},v.prototype.error=function(u){var m=this._sources;if(!a.prototype.error.call(this,u))return!1;for(var f=0;f<m.length;f++)try{m[f].error(u)}catch{}return!0},v.prototype.lock=function(){a.prototype.lock.call(this);for(var u=this._sources,m=0;m<u.length;m++)u[m].lock()},n.exports=v},{"../crc32":4,"../signature":23,"../stream/GenericWorker":28,"../utf8":31,"../utils":32}],9:[function(i,n,o){var s=i("../compressions"),l=i("./ZipFileWorker");o.generateWorker=function(r,a,c){var d=new l(a.streamFiles,c,a.platform,a.encodeFileName),h=0;try{r.forEach(function(v,u){h++;var m=(function(x,C){var A=x||C,D=s[A];if(!D)throw new Error(A+" is not a valid compression method !");return D})(u.options.compression,a.compression),f=u.options.compressionOptions||a.compressionOptions||{},b=u.dir,k=u.date;u._compressWorker(m,f).withStreamInfo("file",{name:v,dir:b,date:k,comment:u.comment||"",unixPermissions:u.unixPermissions,dosPermissions:u.dosPermissions}).pipe(d)}),d.entriesCount=h}catch(v){d.error(v)}return d}},{"../compressions":3,"./ZipFileWorker":8}],10:[function(i,n,o){function s(){if(!(this instanceof s))return new s;if(arguments.length)throw new Error("The constructor with parameters has been removed in JSZip 3.0, please check the upgrade guide.");this.files=Object.create(null),this.comment=null,this.root="",this.clone=function(){var l=new s;for(var r in this)typeof this[r]!="function"&&(l[r]=this[r]);return l}}(s.prototype=i("./object")).loadAsync=i("./load"),s.support=i("./support"),s.defaults=i("./defaults"),s.version="3.10.1",s.loadAsync=function(l,r){return new s().loadAsync(l,r)},s.external=i("./external"),n.exports=s},{"./defaults":5,"./external":6,"./load":11,"./object":15,"./support":30}],11:[function(i,n,o){var s=i("./utils"),l=i("./external"),r=i("./utf8"),a=i("./zipEntries"),c=i("./stream/Crc32Probe"),d=i("./nodejsUtils");function h(v){return new l.Promise(function(u,m){var f=v.decompressed.getContentWorker().pipe(new c);f.on("error",function(b){m(b)}).on("end",function(){f.streamInfo.crc32!==v.decompressed.crc32?m(new Error("Corrupted zip : CRC32 mismatch")):u()}).resume()})}n.exports=function(v,u){var m=this;return u=s.extend(u||{},{base64:!1,checkCRC32:!1,optimizedBinaryString:!1,createFolders:!1,decodeFileName:r.utf8decode}),d.isNode&&d.isStream(v)?l.Promise.reject(new Error("JSZip can't accept a stream when loading a zip file.")):s.prepareContent("the loaded zip file",v,!0,u.optimizedBinaryString,u.base64).then(function(f){var b=new a(u);return b.load(f),b}).then(function(f){var b=[l.Promise.resolve(f)],k=f.files;if(u.checkCRC32)for(var x=0;x<k.length;x++)b.push(h(k[x]));return l.Promise.all(b)}).then(function(f){for(var b=f.shift(),k=b.files,x=0;x<k.length;x++){var C=k[x],A=C.fileNameStr,D=s.resolve(C.fileNameStr);m.file(D,C.decompressed,{binary:!0,optimizedBinaryString:!0,date:C.date,dir:C.dir,comment:C.fileCommentStr.length?C.fileCommentStr:null,unixPermissions:C.unixPermissions,dosPermissions:C.dosPermissions,createFolders:u.createFolders}),C.dir||(m.file(D).unsafeOriginalName=A)}return b.zipComment.length&&(m.comment=b.zipComment),m})}},{"./external":6,"./nodejsUtils":14,"./stream/Crc32Probe":25,"./utf8":31,"./utils":32,"./zipEntries":33}],12:[function(i,n,o){var s=i("../utils"),l=i("../stream/GenericWorker");function r(a,c){l.call(this,"Nodejs stream input adapter for "+a),this._upstreamEnded=!1,this._bindStream(c)}s.inherits(r,l),r.prototype._bindStream=function(a){var c=this;(this._stream=a).pause(),a.on("data",function(d){c.push({data:d,meta:{percent:0}})}).on("error",function(d){c.isPaused?this.generatedError=d:c.error(d)}).on("end",function(){c.isPaused?c._upstreamEnded=!0:c.end()})},r.prototype.pause=function(){return!!l.prototype.pause.call(this)&&(this._stream.pause(),!0)},r.prototype.resume=function(){return!!l.prototype.resume.call(this)&&(this._upstreamEnded?this.end():this._stream.resume(),!0)},n.exports=r},{"../stream/GenericWorker":28,"../utils":32}],13:[function(i,n,o){var s=i("readable-stream").Readable;function l(r,a,c){s.call(this,a),this._helper=r;var d=this;r.on("data",function(h,v){d.push(h)||d._helper.pause(),c&&c(v)}).on("error",function(h){d.emit("error",h)}).on("end",function(){d.push(null)})}i("../utils").inherits(l,s),l.prototype._read=function(){this._helper.resume()},n.exports=l},{"../utils":32,"readable-stream":16}],14:[function(i,n,o){n.exports={isNode:typeof Buffer<"u",newBufferFrom:function(s,l){if(Buffer.from&&Buffer.from!==Uint8Array.from)return Buffer.from(s,l);if(typeof s=="number")throw new Error('The "data" argument must not be a number');return new Buffer(s,l)},allocBuffer:function(s){if(Buffer.alloc)return Buffer.alloc(s);var l=new Buffer(s);return l.fill(0),l},isBuffer:function(s){return Buffer.isBuffer(s)},isStream:function(s){return s&&typeof s.on=="function"&&typeof s.pause=="function"&&typeof s.resume=="function"}}},{}],15:[function(i,n,o){function s(D,T,w){var R,N=r.getTypeOf(T),F=r.extend(w||{},d);F.date=F.date||new Date,F.compression!==null&&(F.compression=F.compression.toUpperCase()),typeof F.unixPermissions=="string"&&(F.unixPermissions=parseInt(F.unixPermissions,8)),F.unixPermissions&&16384&F.unixPermissions&&(F.dir=!0),F.dosPermissions&&16&F.dosPermissions&&(F.dir=!0),F.dir&&(D=k(D)),F.createFolders&&(R=b(D))&&x.call(this,R,!0);var q=N==="string"&&F.binary===!1&&F.base64===!1;w&&w.binary!==void 0||(F.binary=!q),(T instanceof h&&T.uncompressedSize===0||F.dir||!T||T.length===0)&&(F.base64=!1,F.binary=!0,T="",F.compression="STORE",N="string");var _=null;_=T instanceof h||T instanceof a?T:m.isNode&&m.isStream(T)?new f(D,T):r.prepareContent(D,T,F.binary,F.optimizedBinaryString,F.base64);var L=new v(D,_,F);this.files[D]=L}var l=i("./utf8"),r=i("./utils"),a=i("./stream/GenericWorker"),c=i("./stream/StreamHelper"),d=i("./defaults"),h=i("./compressedObject"),v=i("./zipObject"),u=i("./generate"),m=i("./nodejsUtils"),f=i("./nodejs/NodejsStreamInputAdapter"),b=function(D){D.slice(-1)==="/"&&(D=D.substring(0,D.length-1));var T=D.lastIndexOf("/");return 0<T?D.substring(0,T):""},k=function(D){return D.slice(-1)!=="/"&&(D+="/"),D},x=function(D,T){return T=T!==void 0?T:d.createFolders,D=k(D),this.files[D]||s.call(this,D,null,{dir:!0,createFolders:T}),this.files[D]};function C(D){return Object.prototype.toString.call(D)==="[object RegExp]"}var A={load:function(){throw new Error("This method has been removed in JSZip 3.0, please check the upgrade guide.")},forEach:function(D){var T,w,R;for(T in this.files)R=this.files[T],(w=T.slice(this.root.length,T.length))&&T.slice(0,this.root.length)===this.root&&D(w,R)},filter:function(D){var T=[];return this.forEach(function(w,R){D(w,R)&&T.push(R)}),T},file:function(D,T,w){if(arguments.length!==1)return D=this.root+D,s.call(this,D,T,w),this;if(C(D)){var R=D;return this.filter(function(F,q){return!q.dir&&R.test(F)})}var N=this.files[this.root+D];return N&&!N.dir?N:null},folder:function(D){if(!D)return this;if(C(D))return this.filter(function(N,F){return F.dir&&D.test(N)});var T=this.root+D,w=x.call(this,T),R=this.clone();return R.root=w.name,R},remove:function(D){D=this.root+D;var T=this.files[D];if(T||(D.slice(-1)!=="/"&&(D+="/"),T=this.files[D]),T&&!T.dir)delete this.files[D];else for(var w=this.filter(function(N,F){return F.name.slice(0,D.length)===D}),R=0;R<w.length;R++)delete this.files[w[R].name];return this},generate:function(){throw new Error("This method has been removed in JSZip 3.0, please check the upgrade guide.")},generateInternalStream:function(D){var T,w={};try{if((w=r.extend(D||{},{streamFiles:!1,compression:"STORE",compressionOptions:null,type:"",platform:"DOS",comment:null,mimeType:"application/zip",encodeFileName:l.utf8encode})).type=w.type.toLowerCase(),w.compression=w.compression.toUpperCase(),w.type==="binarystring"&&(w.type="string"),!w.type)throw new Error("No output type specified.");r.checkSupport(w.type),w.platform!=="darwin"&&w.platform!=="freebsd"&&w.platform!=="linux"&&w.platform!=="sunos"||(w.platform="UNIX"),w.platform==="win32"&&(w.platform="DOS");var R=w.comment||this.comment||"";T=u.generateWorker(this,w,R)}catch(N){(T=new a("error")).error(N)}return new c(T,w.type||"string",w.mimeType)},generateAsync:function(D,T){return this.generateInternalStream(D).accumulate(T)},generateNodeStream:function(D,T){return(D=D||{}).type||(D.type="nodebuffer"),this.generateInternalStream(D).toNodejsStream(T)}};n.exports=A},{"./compressedObject":2,"./defaults":5,"./generate":9,"./nodejs/NodejsStreamInputAdapter":12,"./nodejsUtils":14,"./stream/GenericWorker":28,"./stream/StreamHelper":29,"./utf8":31,"./utils":32,"./zipObject":35}],16:[function(i,n,o){n.exports=i("stream")},{stream:void 0}],17:[function(i,n,o){var s=i("./DataReader");function l(r){s.call(this,r);for(var a=0;a<this.data.length;a++)r[a]=255&r[a]}i("../utils").inherits(l,s),l.prototype.byteAt=function(r){return this.data[this.zero+r]},l.prototype.lastIndexOfSignature=function(r){for(var a=r.charCodeAt(0),c=r.charCodeAt(1),d=r.charCodeAt(2),h=r.charCodeAt(3),v=this.length-4;0<=v;--v)if(this.data[v]===a&&this.data[v+1]===c&&this.data[v+2]===d&&this.data[v+3]===h)return v-this.zero;return-1},l.prototype.readAndCheckSignature=function(r){var a=r.charCodeAt(0),c=r.charCodeAt(1),d=r.charCodeAt(2),h=r.charCodeAt(3),v=this.readData(4);return a===v[0]&&c===v[1]&&d===v[2]&&h===v[3]},l.prototype.readData=function(r){if(this.checkOffset(r),r===0)return[];var a=this.data.slice(this.zero+this.index,this.zero+this.index+r);return this.index+=r,a},n.exports=l},{"../utils":32,"./DataReader":18}],18:[function(i,n,o){var s=i("../utils");function l(r){this.data=r,this.length=r.length,this.index=0,this.zero=0}l.prototype={checkOffset:function(r){this.checkIndex(this.index+r)},checkIndex:function(r){if(this.length<this.zero+r||r<0)throw new Error("End of data reached (data length = "+this.length+", asked index = "+r+"). Corrupted zip ?")},setIndex:function(r){this.checkIndex(r),this.index=r},skip:function(r){this.setIndex(this.index+r)},byteAt:function(){},readInt:function(r){var a,c=0;for(this.checkOffset(r),a=this.index+r-1;a>=this.index;a--)c=(c<<8)+this.byteAt(a);return this.index+=r,c},readString:function(r){return s.transformTo("string",this.readData(r))},readData:function(){},lastIndexOfSignature:function(){},readAndCheckSignature:function(){},readDate:function(){var r=this.readInt(4);return new Date(Date.UTC(1980+(r>>25&127),(r>>21&15)-1,r>>16&31,r>>11&31,r>>5&63,(31&r)<<1))}},n.exports=l},{"../utils":32}],19:[function(i,n,o){var s=i("./Uint8ArrayReader");function l(r){s.call(this,r)}i("../utils").inherits(l,s),l.prototype.readData=function(r){this.checkOffset(r);var a=this.data.slice(this.zero+this.index,this.zero+this.index+r);return this.index+=r,a},n.exports=l},{"../utils":32,"./Uint8ArrayReader":21}],20:[function(i,n,o){var s=i("./DataReader");function l(r){s.call(this,r)}i("../utils").inherits(l,s),l.prototype.byteAt=function(r){return this.data.charCodeAt(this.zero+r)},l.prototype.lastIndexOfSignature=function(r){return this.data.lastIndexOf(r)-this.zero},l.prototype.readAndCheckSignature=function(r){return r===this.readData(4)},l.prototype.readData=function(r){this.checkOffset(r);var a=this.data.slice(this.zero+this.index,this.zero+this.index+r);return this.index+=r,a},n.exports=l},{"../utils":32,"./DataReader":18}],21:[function(i,n,o){var s=i("./ArrayReader");function l(r){s.call(this,r)}i("../utils").inherits(l,s),l.prototype.readData=function(r){if(this.checkOffset(r),r===0)return new Uint8Array(0);var a=this.data.subarray(this.zero+this.index,this.zero+this.index+r);return this.index+=r,a},n.exports=l},{"../utils":32,"./ArrayReader":17}],22:[function(i,n,o){var s=i("../utils"),l=i("../support"),r=i("./ArrayReader"),a=i("./StringReader"),c=i("./NodeBufferReader"),d=i("./Uint8ArrayReader");n.exports=function(h){var v=s.getTypeOf(h);return s.checkSupport(v),v!=="string"||l.uint8array?v==="nodebuffer"?new c(h):l.uint8array?new d(s.transformTo("uint8array",h)):new r(s.transformTo("array",h)):new a(h)}},{"../support":30,"../utils":32,"./ArrayReader":17,"./NodeBufferReader":19,"./StringReader":20,"./Uint8ArrayReader":21}],23:[function(i,n,o){o.LOCAL_FILE_HEADER="PK",o.CENTRAL_FILE_HEADER="PK",o.CENTRAL_DIRECTORY_END="PK",o.ZIP64_CENTRAL_DIRECTORY_LOCATOR="PK\x07",o.ZIP64_CENTRAL_DIRECTORY_END="PK",o.DATA_DESCRIPTOR="PK\x07\b"},{}],24:[function(i,n,o){var s=i("./GenericWorker"),l=i("../utils");function r(a){s.call(this,"ConvertWorker to "+a),this.destType=a}l.inherits(r,s),r.prototype.processChunk=function(a){this.push({data:l.transformTo(this.destType,a.data),meta:a.meta})},n.exports=r},{"../utils":32,"./GenericWorker":28}],25:[function(i,n,o){var s=i("./GenericWorker"),l=i("../crc32");function r(){s.call(this,"Crc32Probe"),this.withStreamInfo("crc32",0)}i("../utils").inherits(r,s),r.prototype.processChunk=function(a){this.streamInfo.crc32=l(a.data,this.streamInfo.crc32||0),this.push(a)},n.exports=r},{"../crc32":4,"../utils":32,"./GenericWorker":28}],26:[function(i,n,o){var s=i("../utils"),l=i("./GenericWorker");function r(a){l.call(this,"DataLengthProbe for "+a),this.propName=a,this.withStreamInfo(a,0)}s.inherits(r,l),r.prototype.processChunk=function(a){if(a){var c=this.streamInfo[this.propName]||0;this.streamInfo[this.propName]=c+a.data.length}l.prototype.processChunk.call(this,a)},n.exports=r},{"../utils":32,"./GenericWorker":28}],27:[function(i,n,o){var s=i("../utils"),l=i("./GenericWorker");function r(a){l.call(this,"DataWorker");var c=this;this.dataIsReady=!1,this.index=0,this.max=0,this.data=null,this.type="",this._tickScheduled=!1,a.then(function(d){c.dataIsReady=!0,c.data=d,c.max=d&&d.length||0,c.type=s.getTypeOf(d),c.isPaused||c._tickAndRepeat()},function(d){c.error(d)})}s.inherits(r,l),r.prototype.cleanUp=function(){l.prototype.cleanUp.call(this),this.data=null},r.prototype.resume=function(){return!!l.prototype.resume.call(this)&&(!this._tickScheduled&&this.dataIsReady&&(this._tickScheduled=!0,s.delay(this._tickAndRepeat,[],this)),!0)},r.prototype._tickAndRepeat=function(){this._tickScheduled=!1,this.isPaused||this.isFinished||(this._tick(),this.isFinished||(s.delay(this._tickAndRepeat,[],this),this._tickScheduled=!0))},r.prototype._tick=function(){if(this.isPaused||this.isFinished)return!1;var a=null,c=Math.min(this.max,this.index+16384);if(this.index>=this.max)return this.end();switch(this.type){case"string":a=this.data.substring(this.index,c);break;case"uint8array":a=this.data.subarray(this.index,c);break;case"array":case"nodebuffer":a=this.data.slice(this.index,c)}return this.index=c,this.push({data:a,meta:{percent:this.max?this.index/this.max*100:0}})},n.exports=r},{"../utils":32,"./GenericWorker":28}],28:[function(i,n,o){function s(l){this.name=l||"default",this.streamInfo={},this.generatedError=null,this.extraStreamInfo={},this.isPaused=!0,this.isFinished=!1,this.isLocked=!1,this._listeners={data:[],end:[],error:[]},this.previous=null}s.prototype={push:function(l){this.emit("data",l)},end:function(){if(this.isFinished)return!1;this.flush();try{this.emit("end"),this.cleanUp(),this.isFinished=!0}catch(l){this.emit("error",l)}return!0},error:function(l){return!this.isFinished&&(this.isPaused?this.generatedError=l:(this.isFinished=!0,this.emit("error",l),this.previous&&this.previous.error(l),this.cleanUp()),!0)},on:function(l,r){return this._listeners[l].push(r),this},cleanUp:function(){this.streamInfo=this.generatedError=this.extraStreamInfo=null,this._listeners=[]},emit:function(l,r){if(this._listeners[l])for(var a=0;a<this._listeners[l].length;a++)this._listeners[l][a].call(this,r)},pipe:function(l){return l.registerPrevious(this)},registerPrevious:function(l){if(this.isLocked)throw new Error("The stream '"+this+"' has already been used.");this.streamInfo=l.streamInfo,this.mergeStreamInfo(),this.previous=l;var r=this;return l.on("data",function(a){r.processChunk(a)}),l.on("end",function(){r.end()}),l.on("error",function(a){r.error(a)}),this},pause:function(){return!this.isPaused&&!this.isFinished&&(this.isPaused=!0,this.previous&&this.previous.pause(),!0)},resume:function(){if(!this.isPaused||this.isFinished)return!1;var l=this.isPaused=!1;return this.generatedError&&(this.error(this.generatedError),l=!0),this.previous&&this.previous.resume(),!l},flush:function(){},processChunk:function(l){this.push(l)},withStreamInfo:function(l,r){return this.extraStreamInfo[l]=r,this.mergeStreamInfo(),this},mergeStreamInfo:function(){for(var l in this.extraStreamInfo)Object.prototype.hasOwnProperty.call(this.extraStreamInfo,l)&&(this.streamInfo[l]=this.extraStreamInfo[l])},lock:function(){if(this.isLocked)throw new Error("The stream '"+this+"' has already been used.");this.isLocked=!0,this.previous&&this.previous.lock()},toString:function(){var l="Worker "+this.name;return this.previous?this.previous+" -> "+l:l}},n.exports=s},{}],29:[function(i,n,o){var s=i("../utils"),l=i("./ConvertWorker"),r=i("./GenericWorker"),a=i("../base64"),c=i("../support"),d=i("../external"),h=null;if(c.nodestream)try{h=i("../nodejs/NodejsStreamOutputAdapter")}catch{}function v(m,f){return new d.Promise(function(b,k){var x=[],C=m._internalType,A=m._outputType,D=m._mimeType;m.on("data",function(T,w){x.push(T),f&&f(w)}).on("error",function(T){x=[],k(T)}).on("end",function(){try{var T=(function(w,R,N){switch(w){case"blob":return s.newBlob(s.transformTo("arraybuffer",R),N);case"base64":return a.encode(R);default:return s.transformTo(w,R)}})(A,(function(w,R){var N,F=0,q=null,_=0;for(N=0;N<R.length;N++)_+=R[N].length;switch(w){case"string":return R.join("");case"array":return Array.prototype.concat.apply([],R);case"uint8array":for(q=new Uint8Array(_),N=0;N<R.length;N++)q.set(R[N],F),F+=R[N].length;return q;case"nodebuffer":return Buffer.concat(R);default:throw new Error("concat : unsupported type '"+w+"'")}})(C,x),D);b(T)}catch(w){k(w)}x=[]}).resume()})}function u(m,f,b){var k=f;switch(f){case"blob":case"arraybuffer":k="uint8array";break;case"base64":k="string"}try{this._internalType=k,this._outputType=f,this._mimeType=b,s.checkSupport(k),this._worker=m.pipe(new l(k)),m.lock()}catch(x){this._worker=new r("error"),this._worker.error(x)}}u.prototype={accumulate:function(m){return v(this,m)},on:function(m,f){var b=this;return m==="data"?this._worker.on(m,function(k){f.call(b,k.data,k.meta)}):this._worker.on(m,function(){s.delay(f,arguments,b)}),this},resume:function(){return s.delay(this._worker.resume,[],this._worker),this},pause:function(){return this._worker.pause(),this},toNodejsStream:function(m){if(s.checkSupport("nodestream"),this._outputType!=="nodebuffer")throw new Error(this._outputType+" is not supported by this method");return new h(this,{objectMode:this._outputType!=="nodebuffer"},m)}},n.exports=u},{"../base64":1,"../external":6,"../nodejs/NodejsStreamOutputAdapter":13,"../support":30,"../utils":32,"./ConvertWorker":24,"./GenericWorker":28}],30:[function(i,n,o){if(o.base64=!0,o.array=!0,o.string=!0,o.arraybuffer=typeof ArrayBuffer<"u"&&typeof Uint8Array<"u",o.nodebuffer=typeof Buffer<"u",o.uint8array=typeof Uint8Array<"u",typeof ArrayBuffer>"u")o.blob=!1;else{var s=new ArrayBuffer(0);try{o.blob=new Blob([s],{type:"application/zip"}).size===0}catch{try{var l=new(self.BlobBuilder||self.WebKitBlobBuilder||self.MozBlobBuilder||self.MSBlobBuilder);l.append(s),o.blob=l.getBlob("application/zip").size===0}catch{o.blob=!1}}}try{o.nodestream=!!i("readable-stream").Readable}catch{o.nodestream=!1}},{"readable-stream":16}],31:[function(i,n,o){for(var s=i("./utils"),l=i("./support"),r=i("./nodejsUtils"),a=i("./stream/GenericWorker"),c=new Array(256),d=0;d<256;d++)c[d]=252<=d?6:248<=d?5:240<=d?4:224<=d?3:192<=d?2:1;c[254]=c[254]=1;function h(){a.call(this,"utf-8 decode"),this.leftOver=null}function v(){a.call(this,"utf-8 encode")}o.utf8encode=function(u){return l.nodebuffer?r.newBufferFrom(u,"utf-8"):(function(m){var f,b,k,x,C,A=m.length,D=0;for(x=0;x<A;x++)(64512&(b=m.charCodeAt(x)))==55296&&x+1<A&&(64512&(k=m.charCodeAt(x+1)))==56320&&(b=65536+(b-55296<<10)+(k-56320),x++),D+=b<128?1:b<2048?2:b<65536?3:4;for(f=l.uint8array?new Uint8Array(D):new Array(D),x=C=0;C<D;x++)(64512&(b=m.charCodeAt(x)))==55296&&x+1<A&&(64512&(k=m.charCodeAt(x+1)))==56320&&(b=65536+(b-55296<<10)+(k-56320),x++),b<128?f[C++]=b:(b<2048?f[C++]=192|b>>>6:(b<65536?f[C++]=224|b>>>12:(f[C++]=240|b>>>18,f[C++]=128|b>>>12&63),f[C++]=128|b>>>6&63),f[C++]=128|63&b);return f})(u)},o.utf8decode=function(u){return l.nodebuffer?s.transformTo("nodebuffer",u).toString("utf-8"):(function(m){var f,b,k,x,C=m.length,A=new Array(2*C);for(f=b=0;f<C;)if((k=m[f++])<128)A[b++]=k;else if(4<(x=c[k]))A[b++]=65533,f+=x-1;else{for(k&=x===2?31:x===3?15:7;1<x&&f<C;)k=k<<6|63&m[f++],x--;1<x?A[b++]=65533:k<65536?A[b++]=k:(k-=65536,A[b++]=55296|k>>10&1023,A[b++]=56320|1023&k)}return A.length!==b&&(A.subarray?A=A.subarray(0,b):A.length=b),s.applyFromCharCode(A)})(u=s.transformTo(l.uint8array?"uint8array":"array",u))},s.inherits(h,a),h.prototype.processChunk=function(u){var m=s.transformTo(l.uint8array?"uint8array":"array",u.data);if(this.leftOver&&this.leftOver.length){if(l.uint8array){var f=m;(m=new Uint8Array(f.length+this.leftOver.length)).set(this.leftOver,0),m.set(f,this.leftOver.length)}else m=this.leftOver.concat(m);this.leftOver=null}var b=(function(x,C){var A;for((C=C||x.length)>x.length&&(C=x.length),A=C-1;0<=A&&(192&x[A])==128;)A--;return A<0||A===0?C:A+c[x[A]]>C?A:C})(m),k=m;b!==m.length&&(l.uint8array?(k=m.subarray(0,b),this.leftOver=m.subarray(b,m.length)):(k=m.slice(0,b),this.leftOver=m.slice(b,m.length))),this.push({data:o.utf8decode(k),meta:u.meta})},h.prototype.flush=function(){this.leftOver&&this.leftOver.length&&(this.push({data:o.utf8decode(this.leftOver),meta:{}}),this.leftOver=null)},o.Utf8DecodeWorker=h,s.inherits(v,a),v.prototype.processChunk=function(u){this.push({data:o.utf8encode(u.data),meta:u.meta})},o.Utf8EncodeWorker=v},{"./nodejsUtils":14,"./stream/GenericWorker":28,"./support":30,"./utils":32}],32:[function(i,n,o){var s=i("./support"),l=i("./base64"),r=i("./nodejsUtils"),a=i("./external");function c(f){return f}function d(f,b){for(var k=0;k<f.length;++k)b[k]=255&f.charCodeAt(k);return b}i("setimmediate"),o.newBlob=function(f,b){o.checkSupport("blob");try{return new Blob([f],{type:b})}catch{try{var k=new(self.BlobBuilder||self.WebKitBlobBuilder||self.MozBlobBuilder||self.MSBlobBuilder);return k.append(f),k.getBlob(b)}catch{throw new Error("Bug : can't construct the Blob.")}}};var h={stringifyByChunk:function(f,b,k){var x=[],C=0,A=f.length;if(A<=k)return String.fromCharCode.apply(null,f);for(;C<A;)b==="array"||b==="nodebuffer"?x.push(String.fromCharCode.apply(null,f.slice(C,Math.min(C+k,A)))):x.push(String.fromCharCode.apply(null,f.subarray(C,Math.min(C+k,A)))),C+=k;return x.join("")},stringifyByChar:function(f){for(var b="",k=0;k<f.length;k++)b+=String.fromCharCode(f[k]);return b},applyCanBeUsed:{uint8array:(function(){try{return s.uint8array&&String.fromCharCode.apply(null,new Uint8Array(1)).length===1}catch{return!1}})(),nodebuffer:(function(){try{return s.nodebuffer&&String.fromCharCode.apply(null,r.allocBuffer(1)).length===1}catch{return!1}})()}};function v(f){var b=65536,k=o.getTypeOf(f),x=!0;if(k==="uint8array"?x=h.applyCanBeUsed.uint8array:k==="nodebuffer"&&(x=h.applyCanBeUsed.nodebuffer),x)for(;1<b;)try{return h.stringifyByChunk(f,k,b)}catch{b=Math.floor(b/2)}return h.stringifyByChar(f)}function u(f,b){for(var k=0;k<f.length;k++)b[k]=f[k];return b}o.applyFromCharCode=v;var m={};m.string={string:c,array:function(f){return d(f,new Array(f.length))},arraybuffer:function(f){return m.string.uint8array(f).buffer},uint8array:function(f){return d(f,new Uint8Array(f.length))},nodebuffer:function(f){return d(f,r.allocBuffer(f.length))}},m.array={string:v,array:c,arraybuffer:function(f){return new Uint8Array(f).buffer},uint8array:function(f){return new Uint8Array(f)},nodebuffer:function(f){return r.newBufferFrom(f)}},m.arraybuffer={string:function(f){return v(new Uint8Array(f))},array:function(f){return u(new Uint8Array(f),new Array(f.byteLength))},arraybuffer:c,uint8array:function(f){return new Uint8Array(f)},nodebuffer:function(f){return r.newBufferFrom(new Uint8Array(f))}},m.uint8array={string:v,array:function(f){return u(f,new Array(f.length))},arraybuffer:function(f){return f.buffer},uint8array:c,nodebuffer:function(f){return r.newBufferFrom(f)}},m.nodebuffer={string:v,array:function(f){return u(f,new Array(f.length))},arraybuffer:function(f){return m.nodebuffer.uint8array(f).buffer},uint8array:function(f){return u(f,new Uint8Array(f.length))},nodebuffer:c},o.transformTo=function(f,b){if(b=b||"",!f)return b;o.checkSupport(f);var k=o.getTypeOf(b);return m[k][f](b)},o.resolve=function(f){for(var b=f.split("/"),k=[],x=0;x<b.length;x++){var C=b[x];C==="."||C===""&&x!==0&&x!==b.length-1||(C===".."?k.pop():k.push(C))}return k.join("/")},o.getTypeOf=function(f){return typeof f=="string"?"string":Object.prototype.toString.call(f)==="[object Array]"?"array":s.nodebuffer&&r.isBuffer(f)?"nodebuffer":s.uint8array&&f instanceof Uint8Array?"uint8array":s.arraybuffer&&f instanceof ArrayBuffer?"arraybuffer":void 0},o.checkSupport=function(f){if(!s[f.toLowerCase()])throw new Error(f+" is not supported by this platform")},o.MAX_VALUE_16BITS=65535,o.MAX_VALUE_32BITS=-1,o.pretty=function(f){var b,k,x="";for(k=0;k<(f||"").length;k++)x+="\\x"+((b=f.charCodeAt(k))<16?"0":"")+b.toString(16).toUpperCase();return x},o.delay=function(f,b,k){setImmediate(function(){f.apply(k||null,b||[])})},o.inherits=function(f,b){function k(){}k.prototype=b.prototype,f.prototype=new k},o.extend=function(){var f,b,k={};for(f=0;f<arguments.length;f++)for(b in arguments[f])Object.prototype.hasOwnProperty.call(arguments[f],b)&&k[b]===void 0&&(k[b]=arguments[f][b]);return k},o.prepareContent=function(f,b,k,x,C){return a.Promise.resolve(b).then(function(A){return s.blob&&(A instanceof Blob||["[object File]","[object Blob]"].indexOf(Object.prototype.toString.call(A))!==-1)&&typeof FileReader<"u"?new a.Promise(function(D,T){var w=new FileReader;w.onload=function(R){D(R.target.result)},w.onerror=function(R){T(R.target.error)},w.readAsArrayBuffer(A)}):A}).then(function(A){var D=o.getTypeOf(A);return D?(D==="arraybuffer"?A=o.transformTo("uint8array",A):D==="string"&&(C?A=l.decode(A):k&&x!==!0&&(A=(function(T){return d(T,s.uint8array?new Uint8Array(T.length):new Array(T.length))})(A))),A):a.Promise.reject(new Error("Can't read the data of '"+f+"'. Is it in a supported JavaScript type (String, Blob, ArrayBuffer, etc) ?"))})}},{"./base64":1,"./external":6,"./nodejsUtils":14,"./support":30,setimmediate:54}],33:[function(i,n,o){var s=i("./reader/readerFor"),l=i("./utils"),r=i("./signature"),a=i("./zipEntry"),c=i("./support");function d(h){this.files=[],this.loadOptions=h}d.prototype={checkSignature:function(h){if(!this.reader.readAndCheckSignature(h)){this.reader.index-=4;var v=this.reader.readString(4);throw new Error("Corrupted zip or bug: unexpected signature ("+l.pretty(v)+", expected "+l.pretty(h)+")")}},isSignature:function(h,v){var u=this.reader.index;this.reader.setIndex(h);var m=this.reader.readString(4)===v;return this.reader.setIndex(u),m},readBlockEndOfCentral:function(){this.diskNumber=this.reader.readInt(2),this.diskWithCentralDirStart=this.reader.readInt(2),this.centralDirRecordsOnThisDisk=this.reader.readInt(2),this.centralDirRecords=this.reader.readInt(2),this.centralDirSize=this.reader.readInt(4),this.centralDirOffset=this.reader.readInt(4),this.zipCommentLength=this.reader.readInt(2);var h=this.reader.readData(this.zipCommentLength),v=c.uint8array?"uint8array":"array",u=l.transformTo(v,h);this.zipComment=this.loadOptions.decodeFileName(u)},readBlockZip64EndOfCentral:function(){this.zip64EndOfCentralSize=this.reader.readInt(8),this.reader.skip(4),this.diskNumber=this.reader.readInt(4),this.diskWithCentralDirStart=this.reader.readInt(4),this.centralDirRecordsOnThisDisk=this.reader.readInt(8),this.centralDirRecords=this.reader.readInt(8),this.centralDirSize=this.reader.readInt(8),this.centralDirOffset=this.reader.readInt(8),this.zip64ExtensibleData={};for(var h,v,u,m=this.zip64EndOfCentralSize-44;0<m;)h=this.reader.readInt(2),v=this.reader.readInt(4),u=this.reader.readData(v),this.zip64ExtensibleData[h]={id:h,length:v,value:u}},readBlockZip64EndOfCentralLocator:function(){if(this.diskWithZip64CentralDirStart=this.reader.readInt(4),this.relativeOffsetEndOfZip64CentralDir=this.reader.readInt(8),this.disksCount=this.reader.readInt(4),1<this.disksCount)throw new Error("Multi-volumes zip are not supported")},readLocalFiles:function(){var h,v;for(h=0;h<this.files.length;h++)v=this.files[h],this.reader.setIndex(v.localHeaderOffset),this.checkSignature(r.LOCAL_FILE_HEADER),v.readLocalPart(this.reader),v.handleUTF8(),v.processAttributes()},readCentralDir:function(){var h;for(this.reader.setIndex(this.centralDirOffset);this.reader.readAndCheckSignature(r.CENTRAL_FILE_HEADER);)(h=new a({zip64:this.zip64},this.loadOptions)).readCentralPart(this.reader),this.files.push(h);if(this.centralDirRecords!==this.files.length&&this.centralDirRecords!==0&&this.files.length===0)throw new Error("Corrupted zip or bug: expected "+this.centralDirRecords+" records in central dir, got "+this.files.length)},readEndOfCentral:function(){var h=this.reader.lastIndexOfSignature(r.CENTRAL_DIRECTORY_END);if(h<0)throw this.isSignature(0,r.LOCAL_FILE_HEADER)?new Error("Corrupted zip: can't find end of central directory"):new Error("Can't find end of central directory : is this a zip file ? If it is, see https://stuk.github.io/jszip/documentation/howto/read_zip.html");this.reader.setIndex(h);var v=h;if(this.checkSignature(r.CENTRAL_DIRECTORY_END),this.readBlockEndOfCentral(),this.diskNumber===l.MAX_VALUE_16BITS||this.diskWithCentralDirStart===l.MAX_VALUE_16BITS||this.centralDirRecordsOnThisDisk===l.MAX_VALUE_16BITS||this.centralDirRecords===l.MAX_VALUE_16BITS||this.centralDirSize===l.MAX_VALUE_32BITS||this.centralDirOffset===l.MAX_VALUE_32BITS){if(this.zip64=!0,(h=this.reader.lastIndexOfSignature(r.ZIP64_CENTRAL_DIRECTORY_LOCATOR))<0)throw new Error("Corrupted zip: can't find the ZIP64 end of central directory locator");if(this.reader.setIndex(h),this.checkSignature(r.ZIP64_CENTRAL_DIRECTORY_LOCATOR),this.readBlockZip64EndOfCentralLocator(),!this.isSignature(this.relativeOffsetEndOfZip64CentralDir,r.ZIP64_CENTRAL_DIRECTORY_END)&&(this.relativeOffsetEndOfZip64CentralDir=this.reader.lastIndexOfSignature(r.ZIP64_CENTRAL_DIRECTORY_END),this.relativeOffsetEndOfZip64CentralDir<0))throw new Error("Corrupted zip: can't find the ZIP64 end of central directory");this.reader.setIndex(this.relativeOffsetEndOfZip64CentralDir),this.checkSignature(r.ZIP64_CENTRAL_DIRECTORY_END),this.readBlockZip64EndOfCentral()}var u=this.centralDirOffset+this.centralDirSize;this.zip64&&(u+=20,u+=12+this.zip64EndOfCentralSize);var m=v-u;if(0<m)this.isSignature(v,r.CENTRAL_FILE_HEADER)||(this.reader.zero=m);else if(m<0)throw new Error("Corrupted zip: missing "+Math.abs(m)+" bytes.")},prepareReader:function(h){this.reader=s(h)},load:function(h){this.prepareReader(h),this.readEndOfCentral(),this.readCentralDir(),this.readLocalFiles()}},n.exports=d},{"./reader/readerFor":22,"./signature":23,"./support":30,"./utils":32,"./zipEntry":34}],34:[function(i,n,o){var s=i("./reader/readerFor"),l=i("./utils"),r=i("./compressedObject"),a=i("./crc32"),c=i("./utf8"),d=i("./compressions"),h=i("./support");function v(u,m){this.options=u,this.loadOptions=m}v.prototype={isEncrypted:function(){return(1&this.bitFlag)==1},useUTF8:function(){return(2048&this.bitFlag)==2048},readLocalPart:function(u){var m,f;if(u.skip(22),this.fileNameLength=u.readInt(2),f=u.readInt(2),this.fileName=u.readData(this.fileNameLength),u.skip(f),this.compressedSize===-1||this.uncompressedSize===-1)throw new Error("Bug or corrupted zip : didn't get enough information from the central directory (compressedSize === -1 || uncompressedSize === -1)");if((m=(function(b){for(var k in d)if(Object.prototype.hasOwnProperty.call(d,k)&&d[k].magic===b)return d[k];return null})(this.compressionMethod))===null)throw new Error("Corrupted zip : compression "+l.pretty(this.compressionMethod)+" unknown (inner file : "+l.transformTo("string",this.fileName)+")");this.decompressed=new r(this.compressedSize,this.uncompressedSize,this.crc32,m,u.readData(this.compressedSize))},readCentralPart:function(u){this.versionMadeBy=u.readInt(2),u.skip(2),this.bitFlag=u.readInt(2),this.compressionMethod=u.readString(2),this.date=u.readDate(),this.crc32=u.readInt(4),this.compressedSize=u.readInt(4),this.uncompressedSize=u.readInt(4);var m=u.readInt(2);if(this.extraFieldsLength=u.readInt(2),this.fileCommentLength=u.readInt(2),this.diskNumberStart=u.readInt(2),this.internalFileAttributes=u.readInt(2),this.externalFileAttributes=u.readInt(4),this.localHeaderOffset=u.readInt(4),this.isEncrypted())throw new Error("Encrypted zip are not supported");u.skip(m),this.readExtraFields(u),this.parseZIP64ExtraField(u),this.fileComment=u.readData(this.fileCommentLength)},processAttributes:function(){this.unixPermissions=null,this.dosPermissions=null;var u=this.versionMadeBy>>8;this.dir=!!(16&this.externalFileAttributes),u==0&&(this.dosPermissions=63&this.externalFileAttributes),u==3&&(this.unixPermissions=this.externalFileAttributes>>16&65535),this.dir||this.fileNameStr.slice(-1)!=="/"||(this.dir=!0)},parseZIP64ExtraField:function(){if(this.extraFields[1]){var u=s(this.extraFields[1].value);this.uncompressedSize===l.MAX_VALUE_32BITS&&(this.uncompressedSize=u.readInt(8)),this.compressedSize===l.MAX_VALUE_32BITS&&(this.compressedSize=u.readInt(8)),this.localHeaderOffset===l.MAX_VALUE_32BITS&&(this.localHeaderOffset=u.readInt(8)),this.diskNumberStart===l.MAX_VALUE_32BITS&&(this.diskNumberStart=u.readInt(4))}},readExtraFields:function(u){var m,f,b,k=u.index+this.extraFieldsLength;for(this.extraFields||(this.extraFields={});u.index+4<k;)m=u.readInt(2),f=u.readInt(2),b=u.readData(f),this.extraFields[m]={id:m,length:f,value:b};u.setIndex(k)},handleUTF8:function(){var u=h.uint8array?"uint8array":"array";if(this.useUTF8())this.fileNameStr=c.utf8decode(this.fileName),this.fileCommentStr=c.utf8decode(this.fileComment);else{var m=this.findExtraFieldUnicodePath();if(m!==null)this.fileNameStr=m;else{var f=l.transformTo(u,this.fileName);this.fileNameStr=this.loadOptions.decodeFileName(f)}var b=this.findExtraFieldUnicodeComment();if(b!==null)this.fileCommentStr=b;else{var k=l.transformTo(u,this.fileComment);this.fileCommentStr=this.loadOptions.decodeFileName(k)}}},findExtraFieldUnicodePath:function(){var u=this.extraFields[28789];if(u){var m=s(u.value);return m.readInt(1)!==1||a(this.fileName)!==m.readInt(4)?null:c.utf8decode(m.readData(u.length-5))}return null},findExtraFieldUnicodeComment:function(){var u=this.extraFields[25461];if(u){var m=s(u.value);return m.readInt(1)!==1||a(this.fileComment)!==m.readInt(4)?null:c.utf8decode(m.readData(u.length-5))}return null}},n.exports=v},{"./compressedObject":2,"./compressions":3,"./crc32":4,"./reader/readerFor":22,"./support":30,"./utf8":31,"./utils":32}],35:[function(i,n,o){function s(m,f,b){this.name=m,this.dir=b.dir,this.date=b.date,this.comment=b.comment,this.unixPermissions=b.unixPermissions,this.dosPermissions=b.dosPermissions,this._data=f,this._dataBinary=b.binary,this.options={compression:b.compression,compressionOptions:b.compressionOptions}}var l=i("./stream/StreamHelper"),r=i("./stream/DataWorker"),a=i("./utf8"),c=i("./compressedObject"),d=i("./stream/GenericWorker");s.prototype={internalStream:function(m){var f=null,b="string";try{if(!m)throw new Error("No output type specified.");var k=(b=m.toLowerCase())==="string"||b==="text";b!=="binarystring"&&b!=="text"||(b="string"),f=this._decompressWorker();var x=!this._dataBinary;x&&!k&&(f=f.pipe(new a.Utf8EncodeWorker)),!x&&k&&(f=f.pipe(new a.Utf8DecodeWorker))}catch(C){(f=new d("error")).error(C)}return new l(f,b,"")},async:function(m,f){return this.internalStream(m).accumulate(f)},nodeStream:function(m,f){return this.internalStream(m||"nodebuffer").toNodejsStream(f)},_compressWorker:function(m,f){if(this._data instanceof c&&this._data.compression.magic===m.magic)return this._data.getCompressedWorker();var b=this._decompressWorker();return this._dataBinary||(b=b.pipe(new a.Utf8EncodeWorker)),c.createWorkerFrom(b,m,f)},_decompressWorker:function(){return this._data instanceof c?this._data.getContentWorker():this._data instanceof d?this._data:new r(this._data)}};for(var h=["asText","asBinary","asNodeBuffer","asUint8Array","asArrayBuffer"],v=function(){throw new Error("This method has been removed in JSZip 3.0, please check the upgrade guide.")},u=0;u<h.length;u++)s.prototype[h[u]]=v;n.exports=s},{"./compressedObject":2,"./stream/DataWorker":27,"./stream/GenericWorker":28,"./stream/StreamHelper":29,"./utf8":31}],36:[function(i,n,o){(function(s){var l,r,a=s.MutationObserver||s.WebKitMutationObserver;if(a){var c=0,d=new a(m),h=s.document.createTextNode("");d.observe(h,{characterData:!0}),l=function(){h.data=c=++c%2}}else if(s.setImmediate||s.MessageChannel===void 0)l="document"in s&&"onreadystatechange"in s.document.createElement("script")?function(){var f=s.document.createElement("script");f.onreadystatechange=function(){m(),f.onreadystatechange=null,f.parentNode.removeChild(f),f=null},s.document.documentElement.appendChild(f)}:function(){setTimeout(m,0)};else{var v=new s.MessageChannel;v.port1.onmessage=m,l=function(){v.port2.postMessage(0)}}var u=[];function m(){var f,b;r=!0;for(var k=u.length;k;){for(b=u,u=[],f=-1;++f<k;)b[f]();k=u.length}r=!1}n.exports=function(f){u.push(f)!==1||r||l()}}).call(this,typeof eo<"u"?eo:typeof self<"u"?self:typeof window<"u"?window:{})},{}],37:[function(i,n,o){var s=i("immediate");function l(){}var r={},a=["REJECTED"],c=["FULFILLED"],d=["PENDING"];function h(k){if(typeof k!="function")throw new TypeError("resolver must be a function");this.state=d,this.queue=[],this.outcome=void 0,k!==l&&f(this,k)}function v(k,x,C){this.promise=k,typeof x=="function"&&(this.onFulfilled=x,this.callFulfilled=this.otherCallFulfilled),typeof C=="function"&&(this.onRejected=C,this.callRejected=this.otherCallRejected)}function u(k,x,C){s(function(){var A;try{A=x(C)}catch(D){return r.reject(k,D)}A===k?r.reject(k,new TypeError("Cannot resolve promise with itself")):r.resolve(k,A)})}function m(k){var x=k&&k.then;if(k&&(typeof k=="object"||typeof k=="function")&&typeof x=="function")return function(){x.apply(k,arguments)}}function f(k,x){var C=!1;function A(w){C||(C=!0,r.reject(k,w))}function D(w){C||(C=!0,r.resolve(k,w))}var T=b(function(){x(D,A)});T.status==="error"&&A(T.value)}function b(k,x){var C={};try{C.value=k(x),C.status="success"}catch(A){C.status="error",C.value=A}return C}(n.exports=h).prototype.finally=function(k){if(typeof k!="function")return this;var x=this.constructor;return this.then(function(C){return x.resolve(k()).then(function(){return C})},function(C){return x.resolve(k()).then(function(){throw C})})},h.prototype.catch=function(k){return this.then(null,k)},h.prototype.then=function(k,x){if(typeof k!="function"&&this.state===c||typeof x!="function"&&this.state===a)return this;var C=new this.constructor(l);return this.state!==d?u(C,this.state===c?k:x,this.outcome):this.queue.push(new v(C,k,x)),C},v.prototype.callFulfilled=function(k){r.resolve(this.promise,k)},v.prototype.otherCallFulfilled=function(k){u(this.promise,this.onFulfilled,k)},v.prototype.callRejected=function(k){r.reject(this.promise,k)},v.prototype.otherCallRejected=function(k){u(this.promise,this.onRejected,k)},r.resolve=function(k,x){var C=b(m,x);if(C.status==="error")return r.reject(k,C.value);var A=C.value;if(A)f(k,A);else{k.state=c,k.outcome=x;for(var D=-1,T=k.queue.length;++D<T;)k.queue[D].callFulfilled(x)}return k},r.reject=function(k,x){k.state=a,k.outcome=x;for(var C=-1,A=k.queue.length;++C<A;)k.queue[C].callRejected(x);return k},h.resolve=function(k){return k instanceof this?k:r.resolve(new this(l),k)},h.reject=function(k){var x=new this(l);return r.reject(x,k)},h.all=function(k){var x=this;if(Object.prototype.toString.call(k)!=="[object Array]")return this.reject(new TypeError("must be an array"));var C=k.length,A=!1;if(!C)return this.resolve([]);for(var D=new Array(C),T=0,w=-1,R=new this(l);++w<C;)N(k[w],w);return R;function N(F,q){x.resolve(F).then(function(_){D[q]=_,++T!==C||A||(A=!0,r.resolve(R,D))},function(_){A||(A=!0,r.reject(R,_))})}},h.race=function(k){var x=this;if(Object.prototype.toString.call(k)!=="[object Array]")return this.reject(new TypeError("must be an array"));var C=k.length,A=!1;if(!C)return this.resolve([]);for(var D=-1,T=new this(l);++D<C;)w=k[D],x.resolve(w).then(function(R){A||(A=!0,r.resolve(T,R))},function(R){A||(A=!0,r.reject(T,R))});var w;return T}},{immediate:36}],38:[function(i,n,o){var s={};(0,i("./lib/utils/common").assign)(s,i("./lib/deflate"),i("./lib/inflate"),i("./lib/zlib/constants")),n.exports=s},{"./lib/deflate":39,"./lib/inflate":40,"./lib/utils/common":41,"./lib/zlib/constants":44}],39:[function(i,n,o){var s=i("./zlib/deflate"),l=i("./utils/common"),r=i("./utils/strings"),a=i("./zlib/messages"),c=i("./zlib/zstream"),d=Object.prototype.toString,h=0,v=-1,u=0,m=8;function f(k){if(!(this instanceof f))return new f(k);this.options=l.assign({level:v,method:m,chunkSize:16384,windowBits:15,memLevel:8,strategy:u,to:""},k||{});var x=this.options;x.raw&&0<x.windowBits?x.windowBits=-x.windowBits:x.gzip&&0<x.windowBits&&x.windowBits<16&&(x.windowBits+=16),this.err=0,this.msg="",this.ended=!1,this.chunks=[],this.strm=new c,this.strm.avail_out=0;var C=s.deflateInit2(this.strm,x.level,x.method,x.windowBits,x.memLevel,x.strategy);if(C!==h)throw new Error(a[C]);if(x.header&&s.deflateSetHeader(this.strm,x.header),x.dictionary){var A;if(A=typeof x.dictionary=="string"?r.string2buf(x.dictionary):d.call(x.dictionary)==="[object ArrayBuffer]"?new Uint8Array(x.dictionary):x.dictionary,(C=s.deflateSetDictionary(this.strm,A))!==h)throw new Error(a[C]);this._dict_set=!0}}function b(k,x){var C=new f(x);if(C.push(k,!0),C.err)throw C.msg||a[C.err];return C.result}f.prototype.push=function(k,x){var C,A,D=this.strm,T=this.options.chunkSize;if(this.ended)return!1;A=x===~~x?x:x===!0?4:0,typeof k=="string"?D.input=r.string2buf(k):d.call(k)==="[object ArrayBuffer]"?D.input=new Uint8Array(k):D.input=k,D.next_in=0,D.avail_in=D.input.length;do{if(D.avail_out===0&&(D.output=new l.Buf8(T),D.next_out=0,D.avail_out=T),(C=s.deflate(D,A))!==1&&C!==h)return this.onEnd(C),!(this.ended=!0);D.avail_out!==0&&(D.avail_in!==0||A!==4&&A!==2)||(this.options.to==="string"?this.onData(r.buf2binstring(l.shrinkBuf(D.output,D.next_out))):this.onData(l.shrinkBuf(D.output,D.next_out)))}while((0<D.avail_in||D.avail_out===0)&&C!==1);return A===4?(C=s.deflateEnd(this.strm),this.onEnd(C),this.ended=!0,C===h):A!==2||(this.onEnd(h),!(D.avail_out=0))},f.prototype.onData=function(k){this.chunks.push(k)},f.prototype.onEnd=function(k){k===h&&(this.options.to==="string"?this.result=this.chunks.join(""):this.result=l.flattenChunks(this.chunks)),this.chunks=[],this.err=k,this.msg=this.strm.msg},o.Deflate=f,o.deflate=b,o.deflateRaw=function(k,x){return(x=x||{}).raw=!0,b(k,x)},o.gzip=function(k,x){return(x=x||{}).gzip=!0,b(k,x)}},{"./utils/common":41,"./utils/strings":42,"./zlib/deflate":46,"./zlib/messages":51,"./zlib/zstream":53}],40:[function(i,n,o){var s=i("./zlib/inflate"),l=i("./utils/common"),r=i("./utils/strings"),a=i("./zlib/constants"),c=i("./zlib/messages"),d=i("./zlib/zstream"),h=i("./zlib/gzheader"),v=Object.prototype.toString;function u(f){if(!(this instanceof u))return new u(f);this.options=l.assign({chunkSize:16384,windowBits:0,to:""},f||{});var b=this.options;b.raw&&0<=b.windowBits&&b.windowBits<16&&(b.windowBits=-b.windowBits,b.windowBits===0&&(b.windowBits=-15)),!(0<=b.windowBits&&b.windowBits<16)||f&&f.windowBits||(b.windowBits+=32),15<b.windowBits&&b.windowBits<48&&(15&b.windowBits)==0&&(b.windowBits|=15),this.err=0,this.msg="",this.ended=!1,this.chunks=[],this.strm=new d,this.strm.avail_out=0;var k=s.inflateInit2(this.strm,b.windowBits);if(k!==a.Z_OK)throw new Error(c[k]);this.header=new h,s.inflateGetHeader(this.strm,this.header)}function m(f,b){var k=new u(b);if(k.push(f,!0),k.err)throw k.msg||c[k.err];return k.result}u.prototype.push=function(f,b){var k,x,C,A,D,T,w=this.strm,R=this.options.chunkSize,N=this.options.dictionary,F=!1;if(this.ended)return!1;x=b===~~b?b:b===!0?a.Z_FINISH:a.Z_NO_FLUSH,typeof f=="string"?w.input=r.binstring2buf(f):v.call(f)==="[object ArrayBuffer]"?w.input=new Uint8Array(f):w.input=f,w.next_in=0,w.avail_in=w.input.length;do{if(w.avail_out===0&&(w.output=new l.Buf8(R),w.next_out=0,w.avail_out=R),(k=s.inflate(w,a.Z_NO_FLUSH))===a.Z_NEED_DICT&&N&&(T=typeof N=="string"?r.string2buf(N):v.call(N)==="[object ArrayBuffer]"?new Uint8Array(N):N,k=s.inflateSetDictionary(this.strm,T)),k===a.Z_BUF_ERROR&&F===!0&&(k=a.Z_OK,F=!1),k!==a.Z_STREAM_END&&k!==a.Z_OK)return this.onEnd(k),!(this.ended=!0);w.next_out&&(w.avail_out!==0&&k!==a.Z_STREAM_END&&(w.avail_in!==0||x!==a.Z_FINISH&&x!==a.Z_SYNC_FLUSH)||(this.options.to==="string"?(C=r.utf8border(w.output,w.next_out),A=w.next_out-C,D=r.buf2string(w.output,C),w.next_out=A,w.avail_out=R-A,A&&l.arraySet(w.output,w.output,C,A,0),this.onData(D)):this.onData(l.shrinkBuf(w.output,w.next_out)))),w.avail_in===0&&w.avail_out===0&&(F=!0)}while((0<w.avail_in||w.avail_out===0)&&k!==a.Z_STREAM_END);return k===a.Z_STREAM_END&&(x=a.Z_FINISH),x===a.Z_FINISH?(k=s.inflateEnd(this.strm),this.onEnd(k),this.ended=!0,k===a.Z_OK):x!==a.Z_SYNC_FLUSH||(this.onEnd(a.Z_OK),!(w.avail_out=0))},u.prototype.onData=function(f){this.chunks.push(f)},u.prototype.onEnd=function(f){f===a.Z_OK&&(this.options.to==="string"?this.result=this.chunks.join(""):this.result=l.flattenChunks(this.chunks)),this.chunks=[],this.err=f,this.msg=this.strm.msg},o.Inflate=u,o.inflate=m,o.inflateRaw=function(f,b){return(b=b||{}).raw=!0,m(f,b)},o.ungzip=m},{"./utils/common":41,"./utils/strings":42,"./zlib/constants":44,"./zlib/gzheader":47,"./zlib/inflate":49,"./zlib/messages":51,"./zlib/zstream":53}],41:[function(i,n,o){var s=typeof Uint8Array<"u"&&typeof Uint16Array<"u"&&typeof Int32Array<"u";o.assign=function(a){for(var c=Array.prototype.slice.call(arguments,1);c.length;){var d=c.shift();if(d){if(typeof d!="object")throw new TypeError(d+"must be non-object");for(var h in d)d.hasOwnProperty(h)&&(a[h]=d[h])}}return a},o.shrinkBuf=function(a,c){return a.length===c?a:a.subarray?a.subarray(0,c):(a.length=c,a)};var l={arraySet:function(a,c,d,h,v){if(c.subarray&&a.subarray)a.set(c.subarray(d,d+h),v);else for(var u=0;u<h;u++)a[v+u]=c[d+u]},flattenChunks:function(a){var c,d,h,v,u,m;for(c=h=0,d=a.length;c<d;c++)h+=a[c].length;for(m=new Uint8Array(h),c=v=0,d=a.length;c<d;c++)u=a[c],m.set(u,v),v+=u.length;return m}},r={arraySet:function(a,c,d,h,v){for(var u=0;u<h;u++)a[v+u]=c[d+u]},flattenChunks:function(a){return[].concat.apply([],a)}};o.setTyped=function(a){a?(o.Buf8=Uint8Array,o.Buf16=Uint16Array,o.Buf32=Int32Array,o.assign(o,l)):(o.Buf8=Array,o.Buf16=Array,o.Buf32=Array,o.assign(o,r))},o.setTyped(s)},{}],42:[function(i,n,o){var s=i("./common"),l=!0,r=!0;try{String.fromCharCode.apply(null,[0])}catch{l=!1}try{String.fromCharCode.apply(null,new Uint8Array(1))}catch{r=!1}for(var a=new s.Buf8(256),c=0;c<256;c++)a[c]=252<=c?6:248<=c?5:240<=c?4:224<=c?3:192<=c?2:1;function d(h,v){if(v<65537&&(h.subarray&&r||!h.subarray&&l))return String.fromCharCode.apply(null,s.shrinkBuf(h,v));for(var u="",m=0;m<v;m++)u+=String.fromCharCode(h[m]);return u}a[254]=a[254]=1,o.string2buf=function(h){var v,u,m,f,b,k=h.length,x=0;for(f=0;f<k;f++)(64512&(u=h.charCodeAt(f)))==55296&&f+1<k&&(64512&(m=h.charCodeAt(f+1)))==56320&&(u=65536+(u-55296<<10)+(m-56320),f++),x+=u<128?1:u<2048?2:u<65536?3:4;for(v=new s.Buf8(x),f=b=0;b<x;f++)(64512&(u=h.charCodeAt(f)))==55296&&f+1<k&&(64512&(m=h.charCodeAt(f+1)))==56320&&(u=65536+(u-55296<<10)+(m-56320),f++),u<128?v[b++]=u:(u<2048?v[b++]=192|u>>>6:(u<65536?v[b++]=224|u>>>12:(v[b++]=240|u>>>18,v[b++]=128|u>>>12&63),v[b++]=128|u>>>6&63),v[b++]=128|63&u);return v},o.buf2binstring=function(h){return d(h,h.length)},o.binstring2buf=function(h){for(var v=new s.Buf8(h.length),u=0,m=v.length;u<m;u++)v[u]=h.charCodeAt(u);return v},o.buf2string=function(h,v){var u,m,f,b,k=v||h.length,x=new Array(2*k);for(u=m=0;u<k;)if((f=h[u++])<128)x[m++]=f;else if(4<(b=a[f]))x[m++]=65533,u+=b-1;else{for(f&=b===2?31:b===3?15:7;1<b&&u<k;)f=f<<6|63&h[u++],b--;1<b?x[m++]=65533:f<65536?x[m++]=f:(f-=65536,x[m++]=55296|f>>10&1023,x[m++]=56320|1023&f)}return d(x,m)},o.utf8border=function(h,v){var u;for((v=v||h.length)>h.length&&(v=h.length),u=v-1;0<=u&&(192&h[u])==128;)u--;return u<0||u===0?v:u+a[h[u]]>v?u:v}},{"./common":41}],43:[function(i,n,o){n.exports=function(s,l,r,a){for(var c=65535&s|0,d=s>>>16&65535|0,h=0;r!==0;){for(r-=h=2e3<r?2e3:r;d=d+(c=c+l[a++]|0)|0,--h;);c%=65521,d%=65521}return c|d<<16|0}},{}],44:[function(i,n,o){n.exports={Z_NO_FLUSH:0,Z_PARTIAL_FLUSH:1,Z_SYNC_FLUSH:2,Z_FULL_FLUSH:3,Z_FINISH:4,Z_BLOCK:5,Z_TREES:6,Z_OK:0,Z_STREAM_END:1,Z_NEED_DICT:2,Z_ERRNO:-1,Z_STREAM_ERROR:-2,Z_DATA_ERROR:-3,Z_BUF_ERROR:-5,Z_NO_COMPRESSION:0,Z_BEST_SPEED:1,Z_BEST_COMPRESSION:9,Z_DEFAULT_COMPRESSION:-1,Z_FILTERED:1,Z_HUFFMAN_ONLY:2,Z_RLE:3,Z_FIXED:4,Z_DEFAULT_STRATEGY:0,Z_BINARY:0,Z_TEXT:1,Z_UNKNOWN:2,Z_DEFLATED:8}},{}],45:[function(i,n,o){var s=(function(){for(var l,r=[],a=0;a<256;a++){l=a;for(var c=0;c<8;c++)l=1&l?3988292384^l>>>1:l>>>1;r[a]=l}return r})();n.exports=function(l,r,a,c){var d=s,h=c+a;l^=-1;for(var v=c;v<h;v++)l=l>>>8^d[255&(l^r[v])];return-1^l}},{}],46:[function(i,n,o){var s,l=i("../utils/common"),r=i("./trees"),a=i("./adler32"),c=i("./crc32"),d=i("./messages"),h=0,v=4,u=0,m=-2,f=-1,b=4,k=2,x=8,C=9,A=286,D=30,T=19,w=2*A+1,R=15,N=3,F=258,q=F+N+1,_=42,L=113,y=1,M=2,H=3,E=4;function O(g,K){return g.msg=d[K],K}function z(g){return(g<<1)-(4<g?9:0)}function X(g){for(var K=g.length;0<=--K;)g[K]=0}function Z(g){var K=g.state,B=K.pending;B>g.avail_out&&(B=g.avail_out),B!==0&&(l.arraySet(g.output,K.pending_buf,K.pending_out,B,g.next_out),g.next_out+=B,K.pending_out+=B,g.total_out+=B,g.avail_out-=B,K.pending-=B,K.pending===0&&(K.pending_out=0))}function W(g,K){r._tr_flush_block(g,0<=g.block_start?g.block_start:-1,g.strstart-g.block_start,K),g.block_start=g.strstart,Z(g.strm)}function ie(g,K){g.pending_buf[g.pending++]=K}function se(g,K){g.pending_buf[g.pending++]=K>>>8&255,g.pending_buf[g.pending++]=255&K}function re(g,K){var B,S,I=g.max_chain_length,$=g.strstart,U=g.prev_length,V=g.nice_match,G=g.strstart>g.w_size-q?g.strstart-(g.w_size-q):0,ee=g.window,oe=g.w_mask,ne=g.prev,pe=g.strstart+F,_e=ee[$+U-1],xe=ee[$+U];g.prev_length>=g.good_match&&(I>>=2),V>g.lookahead&&(V=g.lookahead);do if(ee[(B=K)+U]===xe&&ee[B+U-1]===_e&&ee[B]===ee[$]&&ee[++B]===ee[$+1]){$+=2,B++;do;while(ee[++$]===ee[++B]&&ee[++$]===ee[++B]&&ee[++$]===ee[++B]&&ee[++$]===ee[++B]&&ee[++$]===ee[++B]&&ee[++$]===ee[++B]&&ee[++$]===ee[++B]&&ee[++$]===ee[++B]&&$<pe);if(S=F-(pe-$),$=pe-F,U<S){if(g.match_start=K,V<=(U=S))break;_e=ee[$+U-1],xe=ee[$+U]}}while((K=ne[K&oe])>G&&--I!=0);return U<=g.lookahead?U:g.lookahead}function ue(g){var K,B,S,I,$,U,V,G,ee,oe,ne=g.w_size;do{if(I=g.window_size-g.lookahead-g.strstart,g.strstart>=ne+(ne-q)){for(l.arraySet(g.window,g.window,ne,ne,0),g.match_start-=ne,g.strstart-=ne,g.block_start-=ne,K=B=g.hash_size;S=g.head[--K],g.head[K]=ne<=S?S-ne:0,--B;);for(K=B=ne;S=g.prev[--K],g.prev[K]=ne<=S?S-ne:0,--B;);I+=ne}if(g.strm.avail_in===0)break;if(U=g.strm,V=g.window,G=g.strstart+g.lookahead,ee=I,oe=void 0,oe=U.avail_in,ee<oe&&(oe=ee),B=oe===0?0:(U.avail_in-=oe,l.arraySet(V,U.input,U.next_in,oe,G),U.state.wrap===1?U.adler=a(U.adler,V,oe,G):U.state.wrap===2&&(U.adler=c(U.adler,V,oe,G)),U.next_in+=oe,U.total_in+=oe,oe),g.lookahead+=B,g.lookahead+g.insert>=N)for($=g.strstart-g.insert,g.ins_h=g.window[$],g.ins_h=(g.ins_h<<g.hash_shift^g.window[$+1])&g.hash_mask;g.insert&&(g.ins_h=(g.ins_h<<g.hash_shift^g.window[$+N-1])&g.hash_mask,g.prev[$&g.w_mask]=g.head[g.ins_h],g.head[g.ins_h]=$,$++,g.insert--,!(g.lookahead+g.insert<N)););}while(g.lookahead<q&&g.strm.avail_in!==0)}function Ie(g,K){for(var B,S;;){if(g.lookahead<q){if(ue(g),g.lookahead<q&&K===h)return y;if(g.lookahead===0)break}if(B=0,g.lookahead>=N&&(g.ins_h=(g.ins_h<<g.hash_shift^g.window[g.strstart+N-1])&g.hash_mask,B=g.prev[g.strstart&g.w_mask]=g.head[g.ins_h],g.head[g.ins_h]=g.strstart),B!==0&&g.strstart-B<=g.w_size-q&&(g.match_length=re(g,B)),g.match_length>=N)if(S=r._tr_tally(g,g.strstart-g.match_start,g.match_length-N),g.lookahead-=g.match_length,g.match_length<=g.max_lazy_match&&g.lookahead>=N){for(g.match_length--;g.strstart++,g.ins_h=(g.ins_h<<g.hash_shift^g.window[g.strstart+N-1])&g.hash_mask,B=g.prev[g.strstart&g.w_mask]=g.head[g.ins_h],g.head[g.ins_h]=g.strstart,--g.match_length!=0;);g.strstart++}else g.strstart+=g.match_length,g.match_length=0,g.ins_h=g.window[g.strstart],g.ins_h=(g.ins_h<<g.hash_shift^g.window[g.strstart+1])&g.hash_mask;else S=r._tr_tally(g,0,g.window[g.strstart]),g.lookahead--,g.strstart++;if(S&&(W(g,!1),g.strm.avail_out===0))return y}return g.insert=g.strstart<N-1?g.strstart:N-1,K===v?(W(g,!0),g.strm.avail_out===0?H:E):g.last_lit&&(W(g,!1),g.strm.avail_out===0)?y:M}function be(g,K){for(var B,S,I;;){if(g.lookahead<q){if(ue(g),g.lookahead<q&&K===h)return y;if(g.lookahead===0)break}if(B=0,g.lookahead>=N&&(g.ins_h=(g.ins_h<<g.hash_shift^g.window[g.strstart+N-1])&g.hash_mask,B=g.prev[g.strstart&g.w_mask]=g.head[g.ins_h],g.head[g.ins_h]=g.strstart),g.prev_length=g.match_length,g.prev_match=g.match_start,g.match_length=N-1,B!==0&&g.prev_length<g.max_lazy_match&&g.strstart-B<=g.w_size-q&&(g.match_length=re(g,B),g.match_length<=5&&(g.strategy===1||g.match_length===N&&4096<g.strstart-g.match_start)&&(g.match_length=N-1)),g.prev_length>=N&&g.match_length<=g.prev_length){for(I=g.strstart+g.lookahead-N,S=r._tr_tally(g,g.strstart-1-g.prev_match,g.prev_length-N),g.lookahead-=g.prev_length-1,g.prev_length-=2;++g.strstart<=I&&(g.ins_h=(g.ins_h<<g.hash_shift^g.window[g.strstart+N-1])&g.hash_mask,B=g.prev[g.strstart&g.w_mask]=g.head[g.ins_h],g.head[g.ins_h]=g.strstart),--g.prev_length!=0;);if(g.match_available=0,g.match_length=N-1,g.strstart++,S&&(W(g,!1),g.strm.avail_out===0))return y}else if(g.match_available){if((S=r._tr_tally(g,0,g.window[g.strstart-1]))&&W(g,!1),g.strstart++,g.lookahead--,g.strm.avail_out===0)return y}else g.match_available=1,g.strstart++,g.lookahead--}return g.match_available&&(S=r._tr_tally(g,0,g.window[g.strstart-1]),g.match_available=0),g.insert=g.strstart<N-1?g.strstart:N-1,K===v?(W(g,!0),g.strm.avail_out===0?H:E):g.last_lit&&(W(g,!1),g.strm.avail_out===0)?y:M}function ae(g,K,B,S,I){this.good_length=g,this.max_lazy=K,this.nice_length=B,this.max_chain=S,this.func=I}function Y(){this.strm=null,this.status=0,this.pending_buf=null,this.pending_buf_size=0,this.pending_out=0,this.pending=0,this.wrap=0,this.gzhead=null,this.gzindex=0,this.method=x,this.last_flush=-1,this.w_size=0,this.w_bits=0,this.w_mask=0,this.window=null,this.window_size=0,this.prev=null,this.head=null,this.ins_h=0,this.hash_size=0,this.hash_bits=0,this.hash_mask=0,this.hash_shift=0,this.block_start=0,this.match_length=0,this.prev_match=0,this.match_available=0,this.strstart=0,this.match_start=0,this.lookahead=0,this.prev_length=0,this.max_chain_length=0,this.max_lazy_match=0,this.level=0,this.strategy=0,this.good_match=0,this.nice_match=0,this.dyn_ltree=new l.Buf16(2*w),this.dyn_dtree=new l.Buf16(2*(2*D+1)),this.bl_tree=new l.Buf16(2*(2*T+1)),X(this.dyn_ltree),X(this.dyn_dtree),X(this.bl_tree),this.l_desc=null,this.d_desc=null,this.bl_desc=null,this.bl_count=new l.Buf16(R+1),this.heap=new l.Buf16(2*A+1),X(this.heap),this.heap_len=0,this.heap_max=0,this.depth=new l.Buf16(2*A+1),X(this.depth),this.l_buf=0,this.lit_bufsize=0,this.last_lit=0,this.d_buf=0,this.opt_len=0,this.static_len=0,this.matches=0,this.insert=0,this.bi_buf=0,this.bi_valid=0}function ce(g){var K;return g&&g.state?(g.total_in=g.total_out=0,g.data_type=k,(K=g.state).pending=0,K.pending_out=0,K.wrap<0&&(K.wrap=-K.wrap),K.status=K.wrap?_:L,g.adler=K.wrap===2?0:1,K.last_flush=h,r._tr_init(K),u):O(g,m)}function P(g){var K=ce(g);return K===u&&(function(B){B.window_size=2*B.w_size,X(B.head),B.max_lazy_match=s[B.level].max_lazy,B.good_match=s[B.level].good_length,B.nice_match=s[B.level].nice_length,B.max_chain_length=s[B.level].max_chain,B.strstart=0,B.block_start=0,B.lookahead=0,B.insert=0,B.match_length=B.prev_length=N-1,B.match_available=0,B.ins_h=0})(g.state),K}function j(g,K,B,S,I,$){if(!g)return m;var U=1;if(K===f&&(K=6),S<0?(U=0,S=-S):15<S&&(U=2,S-=16),I<1||C<I||B!==x||S<8||15<S||K<0||9<K||$<0||b<$)return O(g,m);S===8&&(S=9);var V=new Y;return(g.state=V).strm=g,V.wrap=U,V.gzhead=null,V.w_bits=S,V.w_size=1<<V.w_bits,V.w_mask=V.w_size-1,V.hash_bits=I+7,V.hash_size=1<<V.hash_bits,V.hash_mask=V.hash_size-1,V.hash_shift=~~((V.hash_bits+N-1)/N),V.window=new l.Buf8(2*V.w_size),V.head=new l.Buf16(V.hash_size),V.prev=new l.Buf16(V.w_size),V.lit_bufsize=1<<I+6,V.pending_buf_size=4*V.lit_bufsize,V.pending_buf=new l.Buf8(V.pending_buf_size),V.d_buf=1*V.lit_bufsize,V.l_buf=3*V.lit_bufsize,V.level=K,V.strategy=$,V.method=B,P(g)}s=[new ae(0,0,0,0,function(g,K){var B=65535;for(B>g.pending_buf_size-5&&(B=g.pending_buf_size-5);;){if(g.lookahead<=1){if(ue(g),g.lookahead===0&&K===h)return y;if(g.lookahead===0)break}g.strstart+=g.lookahead,g.lookahead=0;var S=g.block_start+B;if((g.strstart===0||g.strstart>=S)&&(g.lookahead=g.strstart-S,g.strstart=S,W(g,!1),g.strm.avail_out===0)||g.strstart-g.block_start>=g.w_size-q&&(W(g,!1),g.strm.avail_out===0))return y}return g.insert=0,K===v?(W(g,!0),g.strm.avail_out===0?H:E):(g.strstart>g.block_start&&(W(g,!1),g.strm.avail_out),y)}),new ae(4,4,8,4,Ie),new ae(4,5,16,8,Ie),new ae(4,6,32,32,Ie),new ae(4,4,16,16,be),new ae(8,16,32,32,be),new ae(8,16,128,128,be),new ae(8,32,128,256,be),new ae(32,128,258,1024,be),new ae(32,258,258,4096,be)],o.deflateInit=function(g,K){return j(g,K,x,15,8,0)},o.deflateInit2=j,o.deflateReset=P,o.deflateResetKeep=ce,o.deflateSetHeader=function(g,K){return g&&g.state?g.state.wrap!==2?m:(g.state.gzhead=K,u):m},o.deflate=function(g,K){var B,S,I,$;if(!g||!g.state||5<K||K<0)return g?O(g,m):m;if(S=g.state,!g.output||!g.input&&g.avail_in!==0||S.status===666&&K!==v)return O(g,g.avail_out===0?-5:m);if(S.strm=g,B=S.last_flush,S.last_flush=K,S.status===_)if(S.wrap===2)g.adler=0,ie(S,31),ie(S,139),ie(S,8),S.gzhead?(ie(S,(S.gzhead.text?1:0)+(S.gzhead.hcrc?2:0)+(S.gzhead.extra?4:0)+(S.gzhead.name?8:0)+(S.gzhead.comment?16:0)),ie(S,255&S.gzhead.time),ie(S,S.gzhead.time>>8&255),ie(S,S.gzhead.time>>16&255),ie(S,S.gzhead.time>>24&255),ie(S,S.level===9?2:2<=S.strategy||S.level<2?4:0),ie(S,255&S.gzhead.os),S.gzhead.extra&&S.gzhead.extra.length&&(ie(S,255&S.gzhead.extra.length),ie(S,S.gzhead.extra.length>>8&255)),S.gzhead.hcrc&&(g.adler=c(g.adler,S.pending_buf,S.pending,0)),S.gzindex=0,S.status=69):(ie(S,0),ie(S,0),ie(S,0),ie(S,0),ie(S,0),ie(S,S.level===9?2:2<=S.strategy||S.level<2?4:0),ie(S,3),S.status=L);else{var U=x+(S.w_bits-8<<4)<<8;U|=(2<=S.strategy||S.level<2?0:S.level<6?1:S.level===6?2:3)<<6,S.strstart!==0&&(U|=32),U+=31-U%31,S.status=L,se(S,U),S.strstart!==0&&(se(S,g.adler>>>16),se(S,65535&g.adler)),g.adler=1}if(S.status===69)if(S.gzhead.extra){for(I=S.pending;S.gzindex<(65535&S.gzhead.extra.length)&&(S.pending!==S.pending_buf_size||(S.gzhead.hcrc&&S.pending>I&&(g.adler=c(g.adler,S.pending_buf,S.pending-I,I)),Z(g),I=S.pending,S.pending!==S.pending_buf_size));)ie(S,255&S.gzhead.extra[S.gzindex]),S.gzindex++;S.gzhead.hcrc&&S.pending>I&&(g.adler=c(g.adler,S.pending_buf,S.pending-I,I)),S.gzindex===S.gzhead.extra.length&&(S.gzindex=0,S.status=73)}else S.status=73;if(S.status===73)if(S.gzhead.name){I=S.pending;do{if(S.pending===S.pending_buf_size&&(S.gzhead.hcrc&&S.pending>I&&(g.adler=c(g.adler,S.pending_buf,S.pending-I,I)),Z(g),I=S.pending,S.pending===S.pending_buf_size)){$=1;break}$=S.gzindex<S.gzhead.name.length?255&S.gzhead.name.charCodeAt(S.gzindex++):0,ie(S,$)}while($!==0);S.gzhead.hcrc&&S.pending>I&&(g.adler=c(g.adler,S.pending_buf,S.pending-I,I)),$===0&&(S.gzindex=0,S.status=91)}else S.status=91;if(S.status===91)if(S.gzhead.comment){I=S.pending;do{if(S.pending===S.pending_buf_size&&(S.gzhead.hcrc&&S.pending>I&&(g.adler=c(g.adler,S.pending_buf,S.pending-I,I)),Z(g),I=S.pending,S.pending===S.pending_buf_size)){$=1;break}$=S.gzindex<S.gzhead.comment.length?255&S.gzhead.comment.charCodeAt(S.gzindex++):0,ie(S,$)}while($!==0);S.gzhead.hcrc&&S.pending>I&&(g.adler=c(g.adler,S.pending_buf,S.pending-I,I)),$===0&&(S.status=103)}else S.status=103;if(S.status===103&&(S.gzhead.hcrc?(S.pending+2>S.pending_buf_size&&Z(g),S.pending+2<=S.pending_buf_size&&(ie(S,255&g.adler),ie(S,g.adler>>8&255),g.adler=0,S.status=L)):S.status=L),S.pending!==0){if(Z(g),g.avail_out===0)return S.last_flush=-1,u}else if(g.avail_in===0&&z(K)<=z(B)&&K!==v)return O(g,-5);if(S.status===666&&g.avail_in!==0)return O(g,-5);if(g.avail_in!==0||S.lookahead!==0||K!==h&&S.status!==666){var V=S.strategy===2?(function(G,ee){for(var oe;;){if(G.lookahead===0&&(ue(G),G.lookahead===0)){if(ee===h)return y;break}if(G.match_length=0,oe=r._tr_tally(G,0,G.window[G.strstart]),G.lookahead--,G.strstart++,oe&&(W(G,!1),G.strm.avail_out===0))return y}return G.insert=0,ee===v?(W(G,!0),G.strm.avail_out===0?H:E):G.last_lit&&(W(G,!1),G.strm.avail_out===0)?y:M})(S,K):S.strategy===3?(function(G,ee){for(var oe,ne,pe,_e,xe=G.window;;){if(G.lookahead<=F){if(ue(G),G.lookahead<=F&&ee===h)return y;if(G.lookahead===0)break}if(G.match_length=0,G.lookahead>=N&&0<G.strstart&&(ne=xe[pe=G.strstart-1])===xe[++pe]&&ne===xe[++pe]&&ne===xe[++pe]){_e=G.strstart+F;do;while(ne===xe[++pe]&&ne===xe[++pe]&&ne===xe[++pe]&&ne===xe[++pe]&&ne===xe[++pe]&&ne===xe[++pe]&&ne===xe[++pe]&&ne===xe[++pe]&&pe<_e);G.match_length=F-(_e-pe),G.match_length>G.lookahead&&(G.match_length=G.lookahead)}if(G.match_length>=N?(oe=r._tr_tally(G,1,G.match_length-N),G.lookahead-=G.match_length,G.strstart+=G.match_length,G.match_length=0):(oe=r._tr_tally(G,0,G.window[G.strstart]),G.lookahead--,G.strstart++),oe&&(W(G,!1),G.strm.avail_out===0))return y}return G.insert=0,ee===v?(W(G,!0),G.strm.avail_out===0?H:E):G.last_lit&&(W(G,!1),G.strm.avail_out===0)?y:M})(S,K):s[S.level].func(S,K);if(V!==H&&V!==E||(S.status=666),V===y||V===H)return g.avail_out===0&&(S.last_flush=-1),u;if(V===M&&(K===1?r._tr_align(S):K!==5&&(r._tr_stored_block(S,0,0,!1),K===3&&(X(S.head),S.lookahead===0&&(S.strstart=0,S.block_start=0,S.insert=0))),Z(g),g.avail_out===0))return S.last_flush=-1,u}return K!==v?u:S.wrap<=0?1:(S.wrap===2?(ie(S,255&g.adler),ie(S,g.adler>>8&255),ie(S,g.adler>>16&255),ie(S,g.adler>>24&255),ie(S,255&g.total_in),ie(S,g.total_in>>8&255),ie(S,g.total_in>>16&255),ie(S,g.total_in>>24&255)):(se(S,g.adler>>>16),se(S,65535&g.adler)),Z(g),0<S.wrap&&(S.wrap=-S.wrap),S.pending!==0?u:1)},o.deflateEnd=function(g){var K;return g&&g.state?(K=g.state.status)!==_&&K!==69&&K!==73&&K!==91&&K!==103&&K!==L&&K!==666?O(g,m):(g.state=null,K===L?O(g,-3):u):m},o.deflateSetDictionary=function(g,K){var B,S,I,$,U,V,G,ee,oe=K.length;if(!g||!g.state||($=(B=g.state).wrap)===2||$===1&&B.status!==_||B.lookahead)return m;for($===1&&(g.adler=a(g.adler,K,oe,0)),B.wrap=0,oe>=B.w_size&&($===0&&(X(B.head),B.strstart=0,B.block_start=0,B.insert=0),ee=new l.Buf8(B.w_size),l.arraySet(ee,K,oe-B.w_size,B.w_size,0),K=ee,oe=B.w_size),U=g.avail_in,V=g.next_in,G=g.input,g.avail_in=oe,g.next_in=0,g.input=K,ue(B);B.lookahead>=N;){for(S=B.strstart,I=B.lookahead-(N-1);B.ins_h=(B.ins_h<<B.hash_shift^B.window[S+N-1])&B.hash_mask,B.prev[S&B.w_mask]=B.head[B.ins_h],B.head[B.ins_h]=S,S++,--I;);B.strstart=S,B.lookahead=N-1,ue(B)}return B.strstart+=B.lookahead,B.block_start=B.strstart,B.insert=B.lookahead,B.lookahead=0,B.match_length=B.prev_length=N-1,B.match_available=0,g.next_in=V,g.input=G,g.avail_in=U,B.wrap=$,u},o.deflateInfo="pako deflate (from Nodeca project)"},{"../utils/common":41,"./adler32":43,"./crc32":45,"./messages":51,"./trees":52}],47:[function(i,n,o){n.exports=function(){this.text=0,this.time=0,this.xflags=0,this.os=0,this.extra=null,this.extra_len=0,this.name="",this.comment="",this.hcrc=0,this.done=!1}},{}],48:[function(i,n,o){n.exports=function(s,l){var r,a,c,d,h,v,u,m,f,b,k,x,C,A,D,T,w,R,N,F,q,_,L,y,M;r=s.state,a=s.next_in,y=s.input,c=a+(s.avail_in-5),d=s.next_out,M=s.output,h=d-(l-s.avail_out),v=d+(s.avail_out-257),u=r.dmax,m=r.wsize,f=r.whave,b=r.wnext,k=r.window,x=r.hold,C=r.bits,A=r.lencode,D=r.distcode,T=(1<<r.lenbits)-1,w=(1<<r.distbits)-1;e:do{C<15&&(x+=y[a++]<<C,C+=8,x+=y[a++]<<C,C+=8),R=A[x&T];t:for(;;){if(x>>>=N=R>>>24,C-=N,(N=R>>>16&255)===0)M[d++]=65535&R;else{if(!(16&N)){if((64&N)==0){R=A[(65535&R)+(x&(1<<N)-1)];continue t}if(32&N){r.mode=12;break e}s.msg="invalid literal/length code",r.mode=30;break e}F=65535&R,(N&=15)&&(C<N&&(x+=y[a++]<<C,C+=8),F+=x&(1<<N)-1,x>>>=N,C-=N),C<15&&(x+=y[a++]<<C,C+=8,x+=y[a++]<<C,C+=8),R=D[x&w];i:for(;;){if(x>>>=N=R>>>24,C-=N,!(16&(N=R>>>16&255))){if((64&N)==0){R=D[(65535&R)+(x&(1<<N)-1)];continue i}s.msg="invalid distance code",r.mode=30;break e}if(q=65535&R,C<(N&=15)&&(x+=y[a++]<<C,(C+=8)<N&&(x+=y[a++]<<C,C+=8)),u<(q+=x&(1<<N)-1)){s.msg="invalid distance too far back",r.mode=30;break e}if(x>>>=N,C-=N,(N=d-h)<q){if(f<(N=q-N)&&r.sane){s.msg="invalid distance too far back",r.mode=30;break e}if(L=k,(_=0)===b){if(_+=m-N,N<F){for(F-=N;M[d++]=k[_++],--N;);_=d-q,L=M}}else if(b<N){if(_+=m+b-N,(N-=b)<F){for(F-=N;M[d++]=k[_++],--N;);if(_=0,b<F){for(F-=N=b;M[d++]=k[_++],--N;);_=d-q,L=M}}}else if(_+=b-N,N<F){for(F-=N;M[d++]=k[_++],--N;);_=d-q,L=M}for(;2<F;)M[d++]=L[_++],M[d++]=L[_++],M[d++]=L[_++],F-=3;F&&(M[d++]=L[_++],1<F&&(M[d++]=L[_++]))}else{for(_=d-q;M[d++]=M[_++],M[d++]=M[_++],M[d++]=M[_++],2<(F-=3););F&&(M[d++]=M[_++],1<F&&(M[d++]=M[_++]))}break}}break}}while(a<c&&d<v);a-=F=C>>3,x&=(1<<(C-=F<<3))-1,s.next_in=a,s.next_out=d,s.avail_in=a<c?c-a+5:5-(a-c),s.avail_out=d<v?v-d+257:257-(d-v),r.hold=x,r.bits=C}},{}],49:[function(i,n,o){var s=i("../utils/common"),l=i("./adler32"),r=i("./crc32"),a=i("./inffast"),c=i("./inftrees"),d=1,h=2,v=0,u=-2,m=1,f=852,b=592;function k(_){return(_>>>24&255)+(_>>>8&65280)+((65280&_)<<8)+((255&_)<<24)}function x(){this.mode=0,this.last=!1,this.wrap=0,this.havedict=!1,this.flags=0,this.dmax=0,this.check=0,this.total=0,this.head=null,this.wbits=0,this.wsize=0,this.whave=0,this.wnext=0,this.window=null,this.hold=0,this.bits=0,this.length=0,this.offset=0,this.extra=0,this.lencode=null,this.distcode=null,this.lenbits=0,this.distbits=0,this.ncode=0,this.nlen=0,this.ndist=0,this.have=0,this.next=null,this.lens=new s.Buf16(320),this.work=new s.Buf16(288),this.lendyn=null,this.distdyn=null,this.sane=0,this.back=0,this.was=0}function C(_){var L;return _&&_.state?(L=_.state,_.total_in=_.total_out=L.total=0,_.msg="",L.wrap&&(_.adler=1&L.wrap),L.mode=m,L.last=0,L.havedict=0,L.dmax=32768,L.head=null,L.hold=0,L.bits=0,L.lencode=L.lendyn=new s.Buf32(f),L.distcode=L.distdyn=new s.Buf32(b),L.sane=1,L.back=-1,v):u}function A(_){var L;return _&&_.state?((L=_.state).wsize=0,L.whave=0,L.wnext=0,C(_)):u}function D(_,L){var y,M;return _&&_.state?(M=_.state,L<0?(y=0,L=-L):(y=1+(L>>4),L<48&&(L&=15)),L&&(L<8||15<L)?u:(M.window!==null&&M.wbits!==L&&(M.window=null),M.wrap=y,M.wbits=L,A(_))):u}function T(_,L){var y,M;return _?(M=new x,(_.state=M).window=null,(y=D(_,L))!==v&&(_.state=null),y):u}var w,R,N=!0;function F(_){if(N){var L;for(w=new s.Buf32(512),R=new s.Buf32(32),L=0;L<144;)_.lens[L++]=8;for(;L<256;)_.lens[L++]=9;for(;L<280;)_.lens[L++]=7;for(;L<288;)_.lens[L++]=8;for(c(d,_.lens,0,288,w,0,_.work,{bits:9}),L=0;L<32;)_.lens[L++]=5;c(h,_.lens,0,32,R,0,_.work,{bits:5}),N=!1}_.lencode=w,_.lenbits=9,_.distcode=R,_.distbits=5}function q(_,L,y,M){var H,E=_.state;return E.window===null&&(E.wsize=1<<E.wbits,E.wnext=0,E.whave=0,E.window=new s.Buf8(E.wsize)),M>=E.wsize?(s.arraySet(E.window,L,y-E.wsize,E.wsize,0),E.wnext=0,E.whave=E.wsize):(M<(H=E.wsize-E.wnext)&&(H=M),s.arraySet(E.window,L,y-M,H,E.wnext),(M-=H)?(s.arraySet(E.window,L,y-M,M,0),E.wnext=M,E.whave=E.wsize):(E.wnext+=H,E.wnext===E.wsize&&(E.wnext=0),E.whave<E.wsize&&(E.whave+=H))),0}o.inflateReset=A,o.inflateReset2=D,o.inflateResetKeep=C,o.inflateInit=function(_){return T(_,15)},o.inflateInit2=T,o.inflate=function(_,L){var y,M,H,E,O,z,X,Z,W,ie,se,re,ue,Ie,be,ae,Y,ce,P,j,g,K,B,S,I=0,$=new s.Buf8(4),U=[16,17,18,0,8,7,9,6,10,5,11,4,12,3,13,2,14,1,15];if(!_||!_.state||!_.output||!_.input&&_.avail_in!==0)return u;(y=_.state).mode===12&&(y.mode=13),O=_.next_out,H=_.output,X=_.avail_out,E=_.next_in,M=_.input,z=_.avail_in,Z=y.hold,W=y.bits,ie=z,se=X,K=v;e:for(;;)switch(y.mode){case m:if(y.wrap===0){y.mode=13;break}for(;W<16;){if(z===0)break e;z--,Z+=M[E++]<<W,W+=8}if(2&y.wrap&&Z===35615){$[y.check=0]=255&Z,$[1]=Z>>>8&255,y.check=r(y.check,$,2,0),W=Z=0,y.mode=2;break}if(y.flags=0,y.head&&(y.head.done=!1),!(1&y.wrap)||(((255&Z)<<8)+(Z>>8))%31){_.msg="incorrect header check",y.mode=30;break}if((15&Z)!=8){_.msg="unknown compression method",y.mode=30;break}if(W-=4,g=8+(15&(Z>>>=4)),y.wbits===0)y.wbits=g;else if(g>y.wbits){_.msg="invalid window size",y.mode=30;break}y.dmax=1<<g,_.adler=y.check=1,y.mode=512&Z?10:12,W=Z=0;break;case 2:for(;W<16;){if(z===0)break e;z--,Z+=M[E++]<<W,W+=8}if(y.flags=Z,(255&y.flags)!=8){_.msg="unknown compression method",y.mode=30;break}if(57344&y.flags){_.msg="unknown header flags set",y.mode=30;break}y.head&&(y.head.text=Z>>8&1),512&y.flags&&($[0]=255&Z,$[1]=Z>>>8&255,y.check=r(y.check,$,2,0)),W=Z=0,y.mode=3;case 3:for(;W<32;){if(z===0)break e;z--,Z+=M[E++]<<W,W+=8}y.head&&(y.head.time=Z),512&y.flags&&($[0]=255&Z,$[1]=Z>>>8&255,$[2]=Z>>>16&255,$[3]=Z>>>24&255,y.check=r(y.check,$,4,0)),W=Z=0,y.mode=4;case 4:for(;W<16;){if(z===0)break e;z--,Z+=M[E++]<<W,W+=8}y.head&&(y.head.xflags=255&Z,y.head.os=Z>>8),512&y.flags&&($[0]=255&Z,$[1]=Z>>>8&255,y.check=r(y.check,$,2,0)),W=Z=0,y.mode=5;case 5:if(1024&y.flags){for(;W<16;){if(z===0)break e;z--,Z+=M[E++]<<W,W+=8}y.length=Z,y.head&&(y.head.extra_len=Z),512&y.flags&&($[0]=255&Z,$[1]=Z>>>8&255,y.check=r(y.check,$,2,0)),W=Z=0}else y.head&&(y.head.extra=null);y.mode=6;case 6:if(1024&y.flags&&(z<(re=y.length)&&(re=z),re&&(y.head&&(g=y.head.extra_len-y.length,y.head.extra||(y.head.extra=new Array(y.head.extra_len)),s.arraySet(y.head.extra,M,E,re,g)),512&y.flags&&(y.check=r(y.check,M,re,E)),z-=re,E+=re,y.length-=re),y.length))break e;y.length=0,y.mode=7;case 7:if(2048&y.flags){if(z===0)break e;for(re=0;g=M[E+re++],y.head&&g&&y.length<65536&&(y.head.name+=String.fromCharCode(g)),g&&re<z;);if(512&y.flags&&(y.check=r(y.check,M,re,E)),z-=re,E+=re,g)break e}else y.head&&(y.head.name=null);y.length=0,y.mode=8;case 8:if(4096&y.flags){if(z===0)break e;for(re=0;g=M[E+re++],y.head&&g&&y.length<65536&&(y.head.comment+=String.fromCharCode(g)),g&&re<z;);if(512&y.flags&&(y.check=r(y.check,M,re,E)),z-=re,E+=re,g)break e}else y.head&&(y.head.comment=null);y.mode=9;case 9:if(512&y.flags){for(;W<16;){if(z===0)break e;z--,Z+=M[E++]<<W,W+=8}if(Z!==(65535&y.check)){_.msg="header crc mismatch",y.mode=30;break}W=Z=0}y.head&&(y.head.hcrc=y.flags>>9&1,y.head.done=!0),_.adler=y.check=0,y.mode=12;break;case 10:for(;W<32;){if(z===0)break e;z--,Z+=M[E++]<<W,W+=8}_.adler=y.check=k(Z),W=Z=0,y.mode=11;case 11:if(y.havedict===0)return _.next_out=O,_.avail_out=X,_.next_in=E,_.avail_in=z,y.hold=Z,y.bits=W,2;_.adler=y.check=1,y.mode=12;case 12:if(L===5||L===6)break e;case 13:if(y.last){Z>>>=7&W,W-=7&W,y.mode=27;break}for(;W<3;){if(z===0)break e;z--,Z+=M[E++]<<W,W+=8}switch(y.last=1&Z,W-=1,3&(Z>>>=1)){case 0:y.mode=14;break;case 1:if(F(y),y.mode=20,L!==6)break;Z>>>=2,W-=2;break e;case 2:y.mode=17;break;case 3:_.msg="invalid block type",y.mode=30}Z>>>=2,W-=2;break;case 14:for(Z>>>=7&W,W-=7&W;W<32;){if(z===0)break e;z--,Z+=M[E++]<<W,W+=8}if((65535&Z)!=(Z>>>16^65535)){_.msg="invalid stored block lengths",y.mode=30;break}if(y.length=65535&Z,W=Z=0,y.mode=15,L===6)break e;case 15:y.mode=16;case 16:if(re=y.length){if(z<re&&(re=z),X<re&&(re=X),re===0)break e;s.arraySet(H,M,E,re,O),z-=re,E+=re,X-=re,O+=re,y.length-=re;break}y.mode=12;break;case 17:for(;W<14;){if(z===0)break e;z--,Z+=M[E++]<<W,W+=8}if(y.nlen=257+(31&Z),Z>>>=5,W-=5,y.ndist=1+(31&Z),Z>>>=5,W-=5,y.ncode=4+(15&Z),Z>>>=4,W-=4,286<y.nlen||30<y.ndist){_.msg="too many length or distance symbols",y.mode=30;break}y.have=0,y.mode=18;case 18:for(;y.have<y.ncode;){for(;W<3;){if(z===0)break e;z--,Z+=M[E++]<<W,W+=8}y.lens[U[y.have++]]=7&Z,Z>>>=3,W-=3}for(;y.have<19;)y.lens[U[y.have++]]=0;if(y.lencode=y.lendyn,y.lenbits=7,B={bits:y.lenbits},K=c(0,y.lens,0,19,y.lencode,0,y.work,B),y.lenbits=B.bits,K){_.msg="invalid code lengths set",y.mode=30;break}y.have=0,y.mode=19;case 19:for(;y.have<y.nlen+y.ndist;){for(;ae=(I=y.lencode[Z&(1<<y.lenbits)-1])>>>16&255,Y=65535&I,!((be=I>>>24)<=W);){if(z===0)break e;z--,Z+=M[E++]<<W,W+=8}if(Y<16)Z>>>=be,W-=be,y.lens[y.have++]=Y;else{if(Y===16){for(S=be+2;W<S;){if(z===0)break e;z--,Z+=M[E++]<<W,W+=8}if(Z>>>=be,W-=be,y.have===0){_.msg="invalid bit length repeat",y.mode=30;break}g=y.lens[y.have-1],re=3+(3&Z),Z>>>=2,W-=2}else if(Y===17){for(S=be+3;W<S;){if(z===0)break e;z--,Z+=M[E++]<<W,W+=8}W-=be,g=0,re=3+(7&(Z>>>=be)),Z>>>=3,W-=3}else{for(S=be+7;W<S;){if(z===0)break e;z--,Z+=M[E++]<<W,W+=8}W-=be,g=0,re=11+(127&(Z>>>=be)),Z>>>=7,W-=7}if(y.have+re>y.nlen+y.ndist){_.msg="invalid bit length repeat",y.mode=30;break}for(;re--;)y.lens[y.have++]=g}}if(y.mode===30)break;if(y.lens[256]===0){_.msg="invalid code -- missing end-of-block",y.mode=30;break}if(y.lenbits=9,B={bits:y.lenbits},K=c(d,y.lens,0,y.nlen,y.lencode,0,y.work,B),y.lenbits=B.bits,K){_.msg="invalid literal/lengths set",y.mode=30;break}if(y.distbits=6,y.distcode=y.distdyn,B={bits:y.distbits},K=c(h,y.lens,y.nlen,y.ndist,y.distcode,0,y.work,B),y.distbits=B.bits,K){_.msg="invalid distances set",y.mode=30;break}if(y.mode=20,L===6)break e;case 20:y.mode=21;case 21:if(6<=z&&258<=X){_.next_out=O,_.avail_out=X,_.next_in=E,_.avail_in=z,y.hold=Z,y.bits=W,a(_,se),O=_.next_out,H=_.output,X=_.avail_out,E=_.next_in,M=_.input,z=_.avail_in,Z=y.hold,W=y.bits,y.mode===12&&(y.back=-1);break}for(y.back=0;ae=(I=y.lencode[Z&(1<<y.lenbits)-1])>>>16&255,Y=65535&I,!((be=I>>>24)<=W);){if(z===0)break e;z--,Z+=M[E++]<<W,W+=8}if(ae&&(240&ae)==0){for(ce=be,P=ae,j=Y;ae=(I=y.lencode[j+((Z&(1<<ce+P)-1)>>ce)])>>>16&255,Y=65535&I,!(ce+(be=I>>>24)<=W);){if(z===0)break e;z--,Z+=M[E++]<<W,W+=8}Z>>>=ce,W-=ce,y.back+=ce}if(Z>>>=be,W-=be,y.back+=be,y.length=Y,ae===0){y.mode=26;break}if(32&ae){y.back=-1,y.mode=12;break}if(64&ae){_.msg="invalid literal/length code",y.mode=30;break}y.extra=15&ae,y.mode=22;case 22:if(y.extra){for(S=y.extra;W<S;){if(z===0)break e;z--,Z+=M[E++]<<W,W+=8}y.length+=Z&(1<<y.extra)-1,Z>>>=y.extra,W-=y.extra,y.back+=y.extra}y.was=y.length,y.mode=23;case 23:for(;ae=(I=y.distcode[Z&(1<<y.distbits)-1])>>>16&255,Y=65535&I,!((be=I>>>24)<=W);){if(z===0)break e;z--,Z+=M[E++]<<W,W+=8}if((240&ae)==0){for(ce=be,P=ae,j=Y;ae=(I=y.distcode[j+((Z&(1<<ce+P)-1)>>ce)])>>>16&255,Y=65535&I,!(ce+(be=I>>>24)<=W);){if(z===0)break e;z--,Z+=M[E++]<<W,W+=8}Z>>>=ce,W-=ce,y.back+=ce}if(Z>>>=be,W-=be,y.back+=be,64&ae){_.msg="invalid distance code",y.mode=30;break}y.offset=Y,y.extra=15&ae,y.mode=24;case 24:if(y.extra){for(S=y.extra;W<S;){if(z===0)break e;z--,Z+=M[E++]<<W,W+=8}y.offset+=Z&(1<<y.extra)-1,Z>>>=y.extra,W-=y.extra,y.back+=y.extra}if(y.offset>y.dmax){_.msg="invalid distance too far back",y.mode=30;break}y.mode=25;case 25:if(X===0)break e;if(re=se-X,y.offset>re){if((re=y.offset-re)>y.whave&&y.sane){_.msg="invalid distance too far back",y.mode=30;break}ue=re>y.wnext?(re-=y.wnext,y.wsize-re):y.wnext-re,re>y.length&&(re=y.length),Ie=y.window}else Ie=H,ue=O-y.offset,re=y.length;for(X<re&&(re=X),X-=re,y.length-=re;H[O++]=Ie[ue++],--re;);y.length===0&&(y.mode=21);break;case 26:if(X===0)break e;H[O++]=y.length,X--,y.mode=21;break;case 27:if(y.wrap){for(;W<32;){if(z===0)break e;z--,Z|=M[E++]<<W,W+=8}if(se-=X,_.total_out+=se,y.total+=se,se&&(_.adler=y.check=y.flags?r(y.check,H,se,O-se):l(y.check,H,se,O-se)),se=X,(y.flags?Z:k(Z))!==y.check){_.msg="incorrect data check",y.mode=30;break}W=Z=0}y.mode=28;case 28:if(y.wrap&&y.flags){for(;W<32;){if(z===0)break e;z--,Z+=M[E++]<<W,W+=8}if(Z!==(4294967295&y.total)){_.msg="incorrect length check",y.mode=30;break}W=Z=0}y.mode=29;case 29:K=1;break e;case 30:K=-3;break e;case 31:return-4;case 32:default:return u}return _.next_out=O,_.avail_out=X,_.next_in=E,_.avail_in=z,y.hold=Z,y.bits=W,(y.wsize||se!==_.avail_out&&y.mode<30&&(y.mode<27||L!==4))&&q(_,_.output,_.next_out,se-_.avail_out)?(y.mode=31,-4):(ie-=_.avail_in,se-=_.avail_out,_.total_in+=ie,_.total_out+=se,y.total+=se,y.wrap&&se&&(_.adler=y.check=y.flags?r(y.check,H,se,_.next_out-se):l(y.check,H,se,_.next_out-se)),_.data_type=y.bits+(y.last?64:0)+(y.mode===12?128:0)+(y.mode===20||y.mode===15?256:0),(ie==0&&se===0||L===4)&&K===v&&(K=-5),K)},o.inflateEnd=function(_){if(!_||!_.state)return u;var L=_.state;return L.window&&(L.window=null),_.state=null,v},o.inflateGetHeader=function(_,L){var y;return _&&_.state?(2&(y=_.state).wrap)==0?u:((y.head=L).done=!1,v):u},o.inflateSetDictionary=function(_,L){var y,M=L.length;return _&&_.state?(y=_.state).wrap!==0&&y.mode!==11?u:y.mode===11&&l(1,L,M,0)!==y.check?-3:q(_,L,M,M)?(y.mode=31,-4):(y.havedict=1,v):u},o.inflateInfo="pako inflate (from Nodeca project)"},{"../utils/common":41,"./adler32":43,"./crc32":45,"./inffast":48,"./inftrees":50}],50:[function(i,n,o){var s=i("../utils/common"),l=[3,4,5,6,7,8,9,10,11,13,15,17,19,23,27,31,35,43,51,59,67,83,99,115,131,163,195,227,258,0,0],r=[16,16,16,16,16,16,16,16,17,17,17,17,18,18,18,18,19,19,19,19,20,20,20,20,21,21,21,21,16,72,78],a=[1,2,3,4,5,7,9,13,17,25,33,49,65,97,129,193,257,385,513,769,1025,1537,2049,3073,4097,6145,8193,12289,16385,24577,0,0],c=[16,16,16,16,17,17,18,18,19,19,20,20,21,21,22,22,23,23,24,24,25,25,26,26,27,27,28,28,29,29,64,64];n.exports=function(d,h,v,u,m,f,b,k){var x,C,A,D,T,w,R,N,F,q=k.bits,_=0,L=0,y=0,M=0,H=0,E=0,O=0,z=0,X=0,Z=0,W=null,ie=0,se=new s.Buf16(16),re=new s.Buf16(16),ue=null,Ie=0;for(_=0;_<=15;_++)se[_]=0;for(L=0;L<u;L++)se[h[v+L]]++;for(H=q,M=15;1<=M&&se[M]===0;M--);if(M<H&&(H=M),M===0)return m[f++]=20971520,m[f++]=20971520,k.bits=1,0;for(y=1;y<M&&se[y]===0;y++);for(H<y&&(H=y),_=z=1;_<=15;_++)if(z<<=1,(z-=se[_])<0)return-1;if(0<z&&(d===0||M!==1))return-1;for(re[1]=0,_=1;_<15;_++)re[_+1]=re[_]+se[_];for(L=0;L<u;L++)h[v+L]!==0&&(b[re[h[v+L]]++]=L);if(w=d===0?(W=ue=b,19):d===1?(W=l,ie-=257,ue=r,Ie-=257,256):(W=a,ue=c,-1),_=y,T=f,O=L=Z=0,A=-1,D=(X=1<<(E=H))-1,d===1&&852<X||d===2&&592<X)return 1;for(;;){for(R=_-O,F=b[L]<w?(N=0,b[L]):b[L]>w?(N=ue[Ie+b[L]],W[ie+b[L]]):(N=96,0),x=1<<_-O,y=C=1<<E;m[T+(Z>>O)+(C-=x)]=R<<24|N<<16|F|0,C!==0;);for(x=1<<_-1;Z&x;)x>>=1;if(x!==0?(Z&=x-1,Z+=x):Z=0,L++,--se[_]==0){if(_===M)break;_=h[v+b[L]]}if(H<_&&(Z&D)!==A){for(O===0&&(O=H),T+=y,z=1<<(E=_-O);E+O<M&&!((z-=se[E+O])<=0);)E++,z<<=1;if(X+=1<<E,d===1&&852<X||d===2&&592<X)return 1;m[A=Z&D]=H<<24|E<<16|T-f|0}}return Z!==0&&(m[T+Z]=_-O<<24|64<<16|0),k.bits=H,0}},{"../utils/common":41}],51:[function(i,n,o){n.exports={2:"need dictionary",1:"stream end",0:"","-1":"file error","-2":"stream error","-3":"data error","-4":"insufficient memory","-5":"buffer error","-6":"incompatible version"}},{}],52:[function(i,n,o){var s=i("../utils/common"),l=0,r=1;function a(I){for(var $=I.length;0<=--$;)I[$]=0}var c=0,d=29,h=256,v=h+1+d,u=30,m=19,f=2*v+1,b=15,k=16,x=7,C=256,A=16,D=17,T=18,w=[0,0,0,0,0,0,0,0,1,1,1,1,2,2,2,2,3,3,3,3,4,4,4,4,5,5,5,5,0],R=[0,0,0,0,1,1,2,2,3,3,4,4,5,5,6,6,7,7,8,8,9,9,10,10,11,11,12,12,13,13],N=[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,2,3,7],F=[16,17,18,0,8,7,9,6,10,5,11,4,12,3,13,2,14,1,15],q=new Array(2*(v+2));a(q);var _=new Array(2*u);a(_);var L=new Array(512);a(L);var y=new Array(256);a(y);var M=new Array(d);a(M);var H,E,O,z=new Array(u);function X(I,$,U,V,G){this.static_tree=I,this.extra_bits=$,this.extra_base=U,this.elems=V,this.max_length=G,this.has_stree=I&&I.length}function Z(I,$){this.dyn_tree=I,this.max_code=0,this.stat_desc=$}function W(I){return I<256?L[I]:L[256+(I>>>7)]}function ie(I,$){I.pending_buf[I.pending++]=255&$,I.pending_buf[I.pending++]=$>>>8&255}function se(I,$,U){I.bi_valid>k-U?(I.bi_buf|=$<<I.bi_valid&65535,ie(I,I.bi_buf),I.bi_buf=$>>k-I.bi_valid,I.bi_valid+=U-k):(I.bi_buf|=$<<I.bi_valid&65535,I.bi_valid+=U)}function re(I,$,U){se(I,U[2*$],U[2*$+1])}function ue(I,$){for(var U=0;U|=1&I,I>>>=1,U<<=1,0<--$;);return U>>>1}function Ie(I,$,U){var V,G,ee=new Array(b+1),oe=0;for(V=1;V<=b;V++)ee[V]=oe=oe+U[V-1]<<1;for(G=0;G<=$;G++){var ne=I[2*G+1];ne!==0&&(I[2*G]=ue(ee[ne]++,ne))}}function be(I){var $;for($=0;$<v;$++)I.dyn_ltree[2*$]=0;for($=0;$<u;$++)I.dyn_dtree[2*$]=0;for($=0;$<m;$++)I.bl_tree[2*$]=0;I.dyn_ltree[2*C]=1,I.opt_len=I.static_len=0,I.last_lit=I.matches=0}function ae(I){8<I.bi_valid?ie(I,I.bi_buf):0<I.bi_valid&&(I.pending_buf[I.pending++]=I.bi_buf),I.bi_buf=0,I.bi_valid=0}function Y(I,$,U,V){var G=2*$,ee=2*U;return I[G]<I[ee]||I[G]===I[ee]&&V[$]<=V[U]}function ce(I,$,U){for(var V=I.heap[U],G=U<<1;G<=I.heap_len&&(G<I.heap_len&&Y($,I.heap[G+1],I.heap[G],I.depth)&&G++,!Y($,V,I.heap[G],I.depth));)I.heap[U]=I.heap[G],U=G,G<<=1;I.heap[U]=V}function P(I,$,U){var V,G,ee,oe,ne=0;if(I.last_lit!==0)for(;V=I.pending_buf[I.d_buf+2*ne]<<8|I.pending_buf[I.d_buf+2*ne+1],G=I.pending_buf[I.l_buf+ne],ne++,V===0?re(I,G,$):(re(I,(ee=y[G])+h+1,$),(oe=w[ee])!==0&&se(I,G-=M[ee],oe),re(I,ee=W(--V),U),(oe=R[ee])!==0&&se(I,V-=z[ee],oe)),ne<I.last_lit;);re(I,C,$)}function j(I,$){var U,V,G,ee=$.dyn_tree,oe=$.stat_desc.static_tree,ne=$.stat_desc.has_stree,pe=$.stat_desc.elems,_e=-1;for(I.heap_len=0,I.heap_max=f,U=0;U<pe;U++)ee[2*U]!==0?(I.heap[++I.heap_len]=_e=U,I.depth[U]=0):ee[2*U+1]=0;for(;I.heap_len<2;)ee[2*(G=I.heap[++I.heap_len]=_e<2?++_e:0)]=1,I.depth[G]=0,I.opt_len--,ne&&(I.static_len-=oe[2*G+1]);for($.max_code=_e,U=I.heap_len>>1;1<=U;U--)ce(I,ee,U);for(G=pe;U=I.heap[1],I.heap[1]=I.heap[I.heap_len--],ce(I,ee,1),V=I.heap[1],I.heap[--I.heap_max]=U,I.heap[--I.heap_max]=V,ee[2*G]=ee[2*U]+ee[2*V],I.depth[G]=(I.depth[U]>=I.depth[V]?I.depth[U]:I.depth[V])+1,ee[2*U+1]=ee[2*V+1]=G,I.heap[1]=G++,ce(I,ee,1),2<=I.heap_len;);I.heap[--I.heap_max]=I.heap[1],(function(xe,Me){var Ve,qe,Je,De,Jt,rt,Xe=Me.dyn_tree,Ht=Me.max_code,Fi=Me.stat_desc.static_tree,Uo=Me.stat_desc.has_stree,Vo=Me.stat_desc.extra_bits,Vn=Me.stat_desc.extra_base,Si=Me.stat_desc.max_length,Hi=0;for(De=0;De<=b;De++)xe.bl_count[De]=0;for(Xe[2*xe.heap[xe.heap_max]+1]=0,Ve=xe.heap_max+1;Ve<f;Ve++)Si<(De=Xe[2*Xe[2*(qe=xe.heap[Ve])+1]+1]+1)&&(De=Si,Hi++),Xe[2*qe+1]=De,Ht<qe||(xe.bl_count[De]++,Jt=0,Vn<=qe&&(Jt=Vo[qe-Vn]),rt=Xe[2*qe],xe.opt_len+=rt*(De+Jt),Uo&&(xe.static_len+=rt*(Fi[2*qe+1]+Jt)));if(Hi!==0){do{for(De=Si-1;xe.bl_count[De]===0;)De--;xe.bl_count[De]--,xe.bl_count[De+1]+=2,xe.bl_count[Si]--,Hi-=2}while(0<Hi);for(De=Si;De!==0;De--)for(qe=xe.bl_count[De];qe!==0;)Ht<(Je=xe.heap[--Ve])||(Xe[2*Je+1]!==De&&(xe.opt_len+=(De-Xe[2*Je+1])*Xe[2*Je],Xe[2*Je+1]=De),qe--)}})(I,$),Ie(ee,_e,I.bl_count)}function g(I,$,U){var V,G,ee=-1,oe=$[1],ne=0,pe=7,_e=4;for(oe===0&&(pe=138,_e=3),$[2*(U+1)+1]=65535,V=0;V<=U;V++)G=oe,oe=$[2*(V+1)+1],++ne<pe&&G===oe||(ne<_e?I.bl_tree[2*G]+=ne:G!==0?(G!==ee&&I.bl_tree[2*G]++,I.bl_tree[2*A]++):ne<=10?I.bl_tree[2*D]++:I.bl_tree[2*T]++,ee=G,_e=(ne=0)===oe?(pe=138,3):G===oe?(pe=6,3):(pe=7,4))}function K(I,$,U){var V,G,ee=-1,oe=$[1],ne=0,pe=7,_e=4;for(oe===0&&(pe=138,_e=3),V=0;V<=U;V++)if(G=oe,oe=$[2*(V+1)+1],!(++ne<pe&&G===oe)){if(ne<_e)for(;re(I,G,I.bl_tree),--ne!=0;);else G!==0?(G!==ee&&(re(I,G,I.bl_tree),ne--),re(I,A,I.bl_tree),se(I,ne-3,2)):ne<=10?(re(I,D,I.bl_tree),se(I,ne-3,3)):(re(I,T,I.bl_tree),se(I,ne-11,7));ee=G,_e=(ne=0)===oe?(pe=138,3):G===oe?(pe=6,3):(pe=7,4)}}a(z);var B=!1;function S(I,$,U,V){se(I,(c<<1)+(V?1:0),3),(function(G,ee,oe,ne){ae(G),ie(G,oe),ie(G,~oe),s.arraySet(G.pending_buf,G.window,ee,oe,G.pending),G.pending+=oe})(I,$,U)}o._tr_init=function(I){B||((function(){var $,U,V,G,ee,oe=new Array(b+1);for(G=V=0;G<d-1;G++)for(M[G]=V,$=0;$<1<<w[G];$++)y[V++]=G;for(y[V-1]=G,G=ee=0;G<16;G++)for(z[G]=ee,$=0;$<1<<R[G];$++)L[ee++]=G;for(ee>>=7;G<u;G++)for(z[G]=ee<<7,$=0;$<1<<R[G]-7;$++)L[256+ee++]=G;for(U=0;U<=b;U++)oe[U]=0;for($=0;$<=143;)q[2*$+1]=8,$++,oe[8]++;for(;$<=255;)q[2*$+1]=9,$++,oe[9]++;for(;$<=279;)q[2*$+1]=7,$++,oe[7]++;for(;$<=287;)q[2*$+1]=8,$++,oe[8]++;for(Ie(q,v+1,oe),$=0;$<u;$++)_[2*$+1]=5,_[2*$]=ue($,5);H=new X(q,w,h+1,v,b),E=new X(_,R,0,u,b),O=new X(new Array(0),N,0,m,x)})(),B=!0),I.l_desc=new Z(I.dyn_ltree,H),I.d_desc=new Z(I.dyn_dtree,E),I.bl_desc=new Z(I.bl_tree,O),I.bi_buf=0,I.bi_valid=0,be(I)},o._tr_stored_block=S,o._tr_flush_block=function(I,$,U,V){var G,ee,oe=0;0<I.level?(I.strm.data_type===2&&(I.strm.data_type=(function(ne){var pe,_e=4093624447;for(pe=0;pe<=31;pe++,_e>>>=1)if(1&_e&&ne.dyn_ltree[2*pe]!==0)return l;if(ne.dyn_ltree[18]!==0||ne.dyn_ltree[20]!==0||ne.dyn_ltree[26]!==0)return r;for(pe=32;pe<h;pe++)if(ne.dyn_ltree[2*pe]!==0)return r;return l})(I)),j(I,I.l_desc),j(I,I.d_desc),oe=(function(ne){var pe;for(g(ne,ne.dyn_ltree,ne.l_desc.max_code),g(ne,ne.dyn_dtree,ne.d_desc.max_code),j(ne,ne.bl_desc),pe=m-1;3<=pe&&ne.bl_tree[2*F[pe]+1]===0;pe--);return ne.opt_len+=3*(pe+1)+5+5+4,pe})(I),G=I.opt_len+3+7>>>3,(ee=I.static_len+3+7>>>3)<=G&&(G=ee)):G=ee=U+5,U+4<=G&&$!==-1?S(I,$,U,V):I.strategy===4||ee===G?(se(I,2+(V?1:0),3),P(I,q,_)):(se(I,4+(V?1:0),3),(function(ne,pe,_e,xe){var Me;for(se(ne,pe-257,5),se(ne,_e-1,5),se(ne,xe-4,4),Me=0;Me<xe;Me++)se(ne,ne.bl_tree[2*F[Me]+1],3);K(ne,ne.dyn_ltree,pe-1),K(ne,ne.dyn_dtree,_e-1)})(I,I.l_desc.max_code+1,I.d_desc.max_code+1,oe+1),P(I,I.dyn_ltree,I.dyn_dtree)),be(I),V&&ae(I)},o._tr_tally=function(I,$,U){return I.pending_buf[I.d_buf+2*I.last_lit]=$>>>8&255,I.pending_buf[I.d_buf+2*I.last_lit+1]=255&$,I.pending_buf[I.l_buf+I.last_lit]=255&U,I.last_lit++,$===0?I.dyn_ltree[2*U]++:(I.matches++,$--,I.dyn_ltree[2*(y[U]+h+1)]++,I.dyn_dtree[2*W($)]++),I.last_lit===I.lit_bufsize-1},o._tr_align=function(I){se(I,2,3),re(I,C,q),(function($){$.bi_valid===16?(ie($,$.bi_buf),$.bi_buf=0,$.bi_valid=0):8<=$.bi_valid&&($.pending_buf[$.pending++]=255&$.bi_buf,$.bi_buf>>=8,$.bi_valid-=8)})(I)}},{"../utils/common":41}],53:[function(i,n,o){n.exports=function(){this.input=null,this.next_in=0,this.avail_in=0,this.total_in=0,this.output=null,this.next_out=0,this.avail_out=0,this.total_out=0,this.msg="",this.state=null,this.data_type=2,this.adler=0}},{}],54:[function(i,n,o){(function(s){(function(l,r){if(!l.setImmediate){var a,c,d,h,v=1,u={},m=!1,f=l.document,b=Object.getPrototypeOf&&Object.getPrototypeOf(l);b=b&&b.setTimeout?b:l,a={}.toString.call(l.process)==="[object process]"?function(A){process.nextTick(function(){x(A)})}:(function(){if(l.postMessage&&!l.importScripts){var A=!0,D=l.onmessage;return l.onmessage=function(){A=!1},l.postMessage("","*"),l.onmessage=D,A}})()?(h="setImmediate$"+Math.random()+"$",l.addEventListener?l.addEventListener("message",C,!1):l.attachEvent("onmessage",C),function(A){l.postMessage(h+A,"*")}):l.MessageChannel?((d=new MessageChannel).port1.onmessage=function(A){x(A.data)},function(A){d.port2.postMessage(A)}):f&&"onreadystatechange"in f.createElement("script")?(c=f.documentElement,function(A){var D=f.createElement("script");D.onreadystatechange=function(){x(A),D.onreadystatechange=null,c.removeChild(D),D=null},c.appendChild(D)}):function(A){setTimeout(x,0,A)},b.setImmediate=function(A){typeof A!="function"&&(A=new Function(""+A));for(var D=new Array(arguments.length-1),T=0;T<D.length;T++)D[T]=arguments[T+1];var w={callback:A,args:D};return u[v]=w,a(v),v++},b.clearImmediate=k}function k(A){delete u[A]}function x(A){if(m)setTimeout(x,0,A);else{var D=u[A];if(D){m=!0;try{(function(T){var w=T.callback,R=T.args;switch(R.length){case 0:w();break;case 1:w(R[0]);break;case 2:w(R[0],R[1]);break;case 3:w(R[0],R[1],R[2]);break;default:w.apply(r,R)}})(D)}finally{k(A),m=!1}}}}function C(A){A.source===l&&typeof A.data=="string"&&A.data.indexOf(h)===0&&x(+A.data.slice(h.length))}})(typeof self>"u"?s===void 0?this:s:self)}).call(this,typeof eo<"u"?eo:typeof self<"u"?self:typeof window<"u"?window:{})},{}]},{},[10])(10)})})(ls)),ls.exports}var Qy=Xy();const e0=Jy(Qy),t0=/\.(?:png|jpe?g|gif|svg|webp|avif|ico|bmp|tiff?|mp4|webm|mp3|wav|ogg)$/i,i0=/\.(?:ts|js|mjs|cjs|jsx|tsx|vue|json|css|scss|less|html|py|rs|go|java|c|cpp|h|sh|bash|yaml|yml|toml)$/i;async function n0(e){const t=await e0.loadAsync(e),i={},n=[];let o="",s="";const l=[];t.forEach((a,c)=>{!c.dir&&!a.startsWith("__MACOSX")&&!a.includes("node_modules/")&&l.push({path:a,file:c})});let r=l.find(a=>a.path.toLowerCase()==="slides.md");r||(r=l.find(a=>a.path.toLowerCase().endsWith("/slides.md"))),r||(r=l.find(a=>a.path.toLowerCase().endsWith(".md"))),r&&(o=await r.file.async("string"),s=r.path);for(const a of l){const c=a.path;if(c.toLowerCase().endsWith(".md")||i0.test(c)||c.includes("snippets/")){const d=await a.file.async("string");i[c]=d;const h=c.split("/");h.length>1&&(i[h.slice(1).join("/")]=d)}else if(t0.test(c)){const d=await a.file.async("uint8array"),h=c.split("/").pop()||c,v=typeof Blob<"u"?new Blob([d]):void 0;n.push({zipPath:c,fileName:h,data:d,blob:v})}}return{entryMarkdown:o,entryMarkdownPath:s,virtualFiles:i,assets:n}}function o0(e,t){if(Object.keys(t).length===0)return e;function i(o){const s=o.trim().replace(/^['"]|['"]$/g,""),l=s.split("/").pop()||s;if(t[s])return t[s];const r=s.replace(/^\.?\//,"");return t[r]?t[r]:t[l]?t[l]:null}function n(o){let s=o;return s=s.replace(/!\[(.*?)\]\((.*?)\)/g,(l,r,a)=>{const c=i(a);return c?`![${r}](${c})`:l}),s=s.replace(/\bsrc=["'](.*?)["']/gi,(l,r)=>{const a=i(r);return a?`src="${a}"`:l}),s}for(const o of e.slides)if(o.rawMarkdown=n(o.rawMarkdown),o.pageAttrs["custom-slidev-background"]){const s=o.pageAttrs["custom-slidev-background"],l=i(s);l&&(o.pageAttrs["custom-slidev-background"]=l)}if(e.flattenedMarkdown=n(e.flattenedMarkdown),e.docRootAttrs["custom-slidev-background"]){const o=e.docRootAttrs["custom-slidev-background"],s=i(o);s&&(e.docRootAttrs["custom-slidev-background"]=s)}return e}function Na(e){try{if(typeof process<"u"&&typeof require<"u"){const t=require("fs");if(t.existsSync(e))return t.readFileSync(e,"utf-8")}}catch{}return null}function s0(e,t){const i=e.match(/^[ \t]*<<<[ \t]+([^\s]+)/);if(!i)return null;const n=i[1].trim(),o=n.indexOf("#"),s=o!==-1?n.slice(0,o):n,l=o!==-1?n.slice(o+1):"",r=s.replace(/^@\//,"").replace(/^\.\//,""),a=(t==null?void 0:t.virtualFiles)||{};let c=a[s]||a[r]||a[`./${r}`]||a[`@/${r}`];if(!c&&Object.keys(a).length>0){const u=r.split("/").pop();for(const[m,f]of Object.entries(a))if(m.endsWith(`/${r}`)||u&&m.endsWith(`/${u}`)){c=f;break}}if(!c){const u=[];if(t!=null&&t.baseDir)try{const m=require("path");u.push(m.resolve(t.baseDir,r)),u.push(m.resolve(t.baseDir,s))}catch{}try{const m=require("path");u.push(m.resolve(process.cwd(),r))}catch{}for(const m of u){const f=Na(m);if(f!==null){c=f;break}}}if(!c){const u=$a||{};if(c=u[s]||u[r]||u[`snippets/${r}`],!c){const m=r.split("/").pop();for(const[f,b]of Object.entries(u))if(f.endsWith(`/${r}`)||m&&f.endsWith(`/${m}`)){c=b;break}}}if(!c)return null;let d=c;if(l){const u=new RegExp(`(?:\\/\\/|\\/\\*|#)?\\s*#(?:region|REGION)\\s+${l}[^\\r\\n]*\\r?\\n([\\s\\S]*?)(?:\\/\\/|\\/\\*|#)?\\s*#(?:endregion|ENDREGION)\\s+${l}`,"i"),m=c.match(u);if(m){const f=c.match(/^(\/\/\s*Inside[^\r\n]+\r?\n)/i);d=(f?f[1]:"")+m[1].trimEnd()}}const h=r.match(/\.([a-zA-Z0-9]+)$/);return`\`\`\`${h?h[1]:""}
${d}
\`\`\``}function r0(e){let t=!1,i=!1;for(let n=0;n<e.length;n++){const o=e[n];if(o==="'"&&!i)t=!t;else if(o==='"'&&!t)i=!i;else if(o==="#"&&!t&&!i)return e.slice(0,n).trim()}return e.trim()}function so(e){const t={},i=e.split(/\r?\n/);let n=0;for(;n<i.length;){const o=i[n],s=o.trim();if(!s||s.startsWith("#")){n++;continue}const l=o.indexOf(":");if(l>0){const r=o.slice(0,l).trim();let a=o.slice(l+1).trim();if(a==="|"||a===">"){n++;const c=[];let d=-1;for(;n<i.length;){const h=i[n];if(!h.trim()){c.push(""),n++;continue}const u=h.match(/^(\s+)/),m=u?u[1].length:0;if(d===-1&&(d=m),m<d)break;c.push(h.slice(d)),n++}for(;c.length>0&&c[c.length-1]==="";)c.pop();t[r]=a===">"?c.join(" "):c.join(`
`);continue}if(a=r0(a),!a){let c=n+1;const d=[];let h=-1;for(;c<i.length;){const v=i[c],u=v.trim();if(!u||u.startsWith("#")){h!==-1&&d.push(""),c++;continue}const m=v.match(/^(\s+)/),f=m?m[1].length:0;if(h===-1)if(f>0)h=f;else break;if(f<h)break;d.push(v.slice(h)),c++}if(d.length>0){t[r]=so(d.join(`
`)),n=c;continue}}a.startsWith('"')&&a.endsWith('"')||a.startsWith("'")&&a.endsWith("'")?a=a.slice(1,-1):a==="true"?a=!0:a==="false"?a=!1:a==="null"?a=null:/^-?\d+(?:\.\d+)?$/.test(a)&&(a=Number(a)),t[r]=a}n++}return t}const l0=/^\s*```ya?ml([\s\S]*?)```/;function Jr(e){let t={},i=e.trim();const n=i.match(/^---[^\n\r]*\r?\n([\s\S]*?)\r?\n---(?=[ \t]*(?:\r?\n|$))/);if(n&&!n[1].includes("```")){const s=so(n[1]);if(Object.keys(s).length>0||!n[1].trim())return t=s,i=i.slice(n[0].length).trim(),{frontmatter:t,content:i}}if(i.startsWith("---")){const s=i.match(/^---[^\n\r]*(?:\r?\n|$)/);s&&(i=i.slice(s[0].length).trim())}const o=i.match(l0);if(o)t=so(o[1]),i=i.slice(o[0].length).trim();else{const s=i.split(/\r?\n/),l=[];let r=0;for(let a=0;a<s.length;a++){const c=s[a].trim();if(!c){if(l.length>0){r=a+1;break}continue}if(/^[a-zA-Z0-9_-]+\s*:\s*.*/.test(c)&&!c.startsWith("<")&&!c.startsWith("#"))l.push(c);else{r=a;break}}l.length>0&&(t=so(l.join(`
`)),i=s.slice(r).join(`
`).trim())}return{frontmatter:t,content:i}}function a0(e){const t=e.split(/\r?\n/),i=[];let n=0,o=!1;function s(l){if(n>=l)return;const r=t.slice(n,l).join(`
`).trim();r&&i.push(r),n=l+1}for(let l=0;l<t.length;l++){const a=t[l].trimEnd();if(o){a.includes("-->")&&(o=!1);continue}if(a.startsWith("<!--")){a.includes("-->")||(o=!0);continue}if(a.startsWith("---")){s(l);const c=t[l+1];if(c&&c.trim()&&a.replace(/^-+/,"").trim()==="")for(n=l,l+=1;l<t.length&&t[l].trimEnd()!=="---";l++);}else if(a.trimStart().startsWith("```")){const c=a.match(/^\s*`+/),d=c?c[0].trim():"```";let h=l+1;for(;h<t.length&&!t[h].trimStart().startsWith(d);h++);h<t.length&&(l=h)}}return n<t.length&&s(t.length),i}function ro(e,t={}){const{stripNotesFromMarkdown:i=!0,cleanVClicks:n=!0,cleanShikiLines:o=!0,cleanSlots:s=!0,isolateStyleTags:l=!0,cleanHtmlToMarkdown:r=!0,wrapSuperBlocks:a=!0,virtualFiles:c={}}=t;let d=e;d&&!d.trimStart().startsWith("---")&&(d=`---

${d.trimStart()}`);const h=a0(d),v={};let u="",m="",f=0;if(h.length>0){const F=h[0],q=Jr(F),_=Object.keys(q.frontmatter).length>0,L=q.content.length>0;_&&!L&&h.length>1?(f=1,b(q.frontmatter)):_&&b(q.frontmatter)}function b(F){u=F.title||"",F.theme&&(v[An]=String(F.theme)),F.aspectRatio&&(v[Bn]=String(F.aspectRatio)),F.highlighter&&(v[ll]=String(F.highlighter)),F.transition&&(v[Mn]=String(F.transition)),F.colorSchema&&(v[al]=String(F.colorSchema)),F.layout&&(v[he]=String(F.layout)),F.background&&(v[je]=String(F.background)),F.image&&(v[Dt]=String(F.image)),F.class&&(v[Gi]=String(F.class));for(const[q,_]of Object.entries(F))["theme","aspectRatio","highlighter","transition","colorSchema","title","layout","background","image","class"].includes(q)||(v[`custom-slidev-${q}`]=typeof _=="object"?JSON.stringify(_):String(_))}const k=[];let x=0,C=0,A=0,D=0;const T=new Set,w={};let R=1;for(let F=f;F<h.length;F++){const q=h[F],{frontmatter:_,content:L}=Jr(q),y=q.match(/^\s*(?:---\s*)?src:\s*([^\n\r]+)/m),M=_.src||(y?y[1]:void 0);if(M){const ae=String(M).trim().replace(/^['"]|['"]$/g,"");let Y=c[ae]||c[ae.replace(/^\.\//,"")]||c[`pages/${ae.replace(/^.*pages\//,"")}`];if(!Y){const P=ae.replace(/^\.\//,""),j=[];if(t.baseDir)try{const g=require("path");j.push(g.resolve(t.baseDir,P)),j.push(g.resolve(t.baseDir,ae))}catch{}try{const g=require("path");j.push(g.resolve(process.cwd(),P)),j.push(g.resolve(process.cwd(),ae))}catch{}for(const g of j){const K=Na(g);if(K!==null){Y=K;break}}}const ce={};_.layout&&(ce[he]=String(_.layout)),_.transition&&(ce[tt]=String(_.transition)),_.background&&(ce[je]=String(_.background)),_.image&&(ce[Dt]=String(_.image)),_.class&&(ce[Gi]=String(_.class));for(const[P,j]of Object.entries(_))["src","layout","transition","background","image","class"].includes(P)||(ce[`custom-slidev-${P}`]=typeof j=="object"?JSON.stringify(j):String(j));if(Y){const P=ro(Y,{...t,virtualFiles:c});for(const j of P.slides){j.pageIndex=R++,j.pageAttrs={...ce,...j.pageAttrs},k.push(j);const g=j.pageAttrs[he]||"default";w[g]=(w[g]||0)+1}continue}else{k.push({pageIndex:R++,pageAttrs:{...ce,"custom-slidev-src":ae},notes:"",rawMarkdown:`> 📄 **引入外部幻灯片页面**: \`${ae}\`
>
> *提示：如需展示该页面完整内容，请将关联子页面一同打包为 .zip 或通过本地工程导入。*`,hasVueComponent:!1,hasStyleTag:!1,assetReferences:[]});const P=ce[he]||"default";w[P]=(w[P]||0)+1;continue}}const H={};_.layout&&(H[he]=String(_.layout)),_.transition&&(H[tt]=String(_.transition)),_.background&&(H[je]=String(_.background)),_.image&&(H[Dt]=String(_.image)),_.class&&(H[Gi]=String(_.class)),_.mask&&(H[qi]=String(_.mask)),(_.maskRatio||_["mask-ratio"])&&(H[Zi]=String(_.maskRatio||_["mask-ratio"])),(_.maskStyle||_["mask-style"])&&(H[Yi]=String(_.maskStyle||_["mask-style"])),(_.maskInitial||_["mask-initial"])&&(H[Ji]=String(_.maskInitial||_["mask-initial"]));for(const[ae,Y]of Object.entries(_))["layout","transition","background","image","class","mask","maskRatio","mask-ratio","maskStyle","mask-style","maskInitial","mask-initial"].includes(ae)||(H[`custom-slidev-${ae}`]=typeof Y=="object"?JSON.stringify(Y):String(Y));let E=L;const O=[];let z=E.replace(/(?:^[ \t]*(`{3,}|~{3,})[^\n\r]*\r?\n[\s\S]*?\r?\n[ \t]*\1(?=[ \t]*(?:\r?\n|$)))/gm,ae=>{const Y=`__CODE_TOKEN_NOTE_${O.length}__`;return O.push(ae),Y});z=z.replace(/(`+)(?:[^\n\r`]|(?!\1)`)+?\1/g,ae=>{const Y=`__CODE_TOKEN_NOTE_${O.length}__`;return O.push(ae),Y});let X="";const Z=Array.from(z.matchAll(/<!--([\s\S]*?)-->/g));if(Z.length>0){const ae=Z[Z.length-1],Y=z.slice(ae.index+ae[0].length).trim();if(!Y||!Y.replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi,"").trim()){const P=ae[1].trim();P.startsWith("TODO:")||(X=P,x++),i&&(z=z.slice(0,ae.index).trimEnd()+z.slice(ae.index+ae[0].length))}}i&&(z=z.replace(/<!--(?![\s\S]*?TODO:)[\s\S]*?-->/g,"").trim());for(let ae=0;ae<O.length;ae++)z=z.replace(`__CODE_TOKEN_NOTE_${ae}__`,O[ae]);if(E=z,X){for(let ce=0;ce<O.length;ce++)X=X.replace(`__CODE_TOKEN_NOTE_${ce}__`,O[ce]);const Y=`> [!NOTE] 💡 演讲备注
${X.split(/\r?\n/).map(ce=>`> ${ce}`).join(`
`)}
{: custom-slidev-note="true"}`;E=E?`${E}

${Y}`:Y}let W=!1;if(/<style\b/i.test(E)){W=!0;const ae=E.match(/<style\b[^>]*>([\s\S]*?)<\/style>/gi);if(ae){for(const Y of ae){const ce=Y.replace(/<style\b[^>]*>|<\/style>/gi,"").trim();m=m?`${m}

${ce}`:ce}l&&(E=E.replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi,"").trim())}}const ie=E.match(/<v-click[^>]*>|<v-clicks[^>]*>|v-click=/g);ie&&(C+=ie.length);const se=E.match(/```\w+\s+\{[^}]+\}/g);se&&(A+=se.length);const re=E.match(/::\w+::|<template\s+#[^>]+>/g);if(re&&(D+=re.length),E=E.replace(/^[ \t]*<<<[ \t]+([^\n\r]+)/gm,ae=>s0(ae,{...t,virtualFiles:c})||ae),n&&(E=E.replace(/<v-click(?:\s+at="[^"]*")?(?:\s+hide)?>\s*([\s\S]*?)\s*<\/v-click>/gi,"$1")),o&&(E=E.replace(/(^```\w+(?:[ \t]+\[[^\]]*\])?)[ \t]+\{[^}]+\}(?:[ \t]+\w+)?/gm,"$1"),E=E.replace(/^\$\$\s+\{[^}]+\}/gm,()=>"$$")),s&&(E=E.replace(/^::\w+::\s*$/gm,"")),r&&(E=Af(E)),a){let ae=E.trim(),Y="";const ce=ae.lastIndexOf("> [!NOTE] 💡 演讲备注");if(ce!==-1&&(Y=ae.slice(ce),ae=ae.slice(0,ce).trim()),(_.layout==="image-left"||_.layout==="image-right")&&_.image){const P=String(_.image).trim(),j=_.layout==="image-left"?"image-left":"image-right",g=`![配图](${P})
{: custom-slidev-layout="${j}" }`;_.layout==="image-left"?ae=`{{{col

${g}

${ae}

}}}`:ae=`{{{col

${ae}

${g}

}}}`}if(_.background){const j=`![背景图](${String(_.background).trim()})
{: custom-slidev-role="background" }`;ae=ae?`${j}

${ae}`:j}E=Y?`${ae}

${Y}`:ae}const ue=c0(E);H[je]&&ue.push(H[je]),H[Dt]&&ue.push(H[Dt]);for(const ae of ue)T.add(ae);const Ie=/<[A-Z][a-zA-Z0-9]+/.test(E),be=H[he]||(R===1?v[he]||"cover":"default");w[be]=(w[be]||0)+1,k.push({pageIndex:R++,pageAttrs:H,notes:X,rawMarkdown:E,hasVueComponent:Ie,hasStyleTag:W,assetReferences:ue})}if(!u&&k.length>0){const F=k[0].rawMarkdown.match(/^#\s+(.+)$/m);F&&(u=F[1].trim())}m&&(v["custom-slidev-custom-css"]=m);let N=k.map(F=>`---

${F.rawMarkdown}`).join(`

`);return N.trimStart().startsWith("---")||(N=`---

${N.trimStart()}`),{docTitle:u||"Slidev 演示文稿",docRootAttrs:v,slides:k,totalSlides:k.length,stats:{totalNotes:x,totalVClicks:C,totalShikiHighlights:A,totalSlots:D,discoveredAssets:Array.from(T),layoutDistribution:w},flattenedMarkdown:N,customCss:m}}function c0(e){const t=[],i=/!\[.*?\]\((.*?)\)/g;let n;for(;(n=i.exec(e))!==null;){const s=n[1].split(/\s+/)[0].trim();s&&t.push(s)}const o=/<(?:img|video|source|audio)\b[^>]*src=["'](.*?)["']/gi;for(;(n=o.exec(e))!==null;){const s=n[1].trim();s&&t.push(s)}return t}function za(e){if(!e)return!1;const t=String(e.type||"").toLowerCase(),i=String(e.markdown||"").trim(),n=String(e.content||"").trim();return t==="tb"||t==="thematic-break"||t==="nodethematicbreak"||i==="---"||i==="***"||n==="---"||n==="***"}function d0(e){return(e.trim()||"Slidev 演示文稿").replace(/[\\/:*?"<>|]/g,"_")}async function u0(e,t,i=Ne){const n=e.filter(za);let o=0;if(n.length>=t.length)for(let s=0;s<t.length;s++){const l=t[s],r=n[s];r&&r.id&&Object.keys(l.pageAttrs||{}).length>0&&(await i(r.id,l.pageAttrs),o++)}else for(let s=1;s<t.length;s++){const l=t[s],r=n[s-1];r&&r.id&&Object.keys(l.pageAttrs||{}).length>0&&(await i(r.id,l.pageAttrs),o++)}return o}async function f0(e,t=Ne){let i=!1,n=0;for(const o of e){if(za(o)){i=!1;continue}const s=(o.markdown||o.content||"").trim();if(s==="::right::"||s.startsWith("::right::")){i=!0;continue}i&&o.id&&(await t(o.id,{[Ce]:"right"}).catch(()=>{}),n++)}return n}async function p0(e,t,i=nl){const n={};if(!t||t.length===0)return n;const o=[];for(const s of t){const l=new File([s.data],s.fileName,{type:"application/octet-stream"});o.push(l)}try{const s=await i("/data/assets",o);if(s!=null&&s.succMap)for(const[l,r]of Object.entries(s.succMap))n[l]=String(r)}catch(s){console.warn("上传本地静态资产失败，保留原路径:",s)}return Object.keys(n).length>0&&o0(e,n),n}async function h0(e){var A;const{presentation:t,notebookId:i,docTitle:n,extractedAssets:o=[],uploadAssets:s=!0,autoPreview:l=!0,plugin:r,api:a={}}=e,c=a.uploadFn||nl,d=a.createDocFn||Nc,h=a.setAttrsFn||Ne,v=a.getChildBlocksFn||fo,u=a.openTabFn||me.openTab,m=a.showMessageFn||me.showMessage;s&&o.length>0&&await p0(t,o,c);const f=d0(n),b=`/${f}`,k=await d(i,b,t.flattenedMarkdown);if(!k)throw new Error("思源内核创建文档失败，未返回有效 DocumentId");const x=((A=t.slides[0])==null?void 0:A.pageAttrs)||{};await h(k,{...x,...t.docRootAttrs});const C=await v(k).catch(()=>[]);return Array.isArray(C)&&C.length>0&&(await u0(C,t.slides,h),await f0(C,h)),m(`🎉 成功导入 Slidev 演示文档《${f}》！`),l&&r&&(r.currentDocId=k,await u({app:r.app,doc:{id:k}}),r.openBottomPreviewTab&&r.openBottomPreviewTab()),k}function m0(e){const t=fe("file"),i=fe(!1),n=fe(!1),o=fe(""),s=fe(null),l=fe(null),r=fe(""),a=fe(0),c=fe(""),d=fe([]),h=fe(null),v=fe(""),u=fe([]),m=fe(""),f=fe(!0),b=fe(!0),k=fe(!0),x=fe(!0),C=we(()=>{const H=a.value;if(H===0)return"0 B";const E=1024,O=["B","KB","MB","GB"],z=Math.floor(Math.log(H)/Math.log(E));return`${(H/E**z).toFixed(1)} ${O[z]}`}),A=we(()=>{var H;return((H=h.value)==null?void 0:H.docRootAttrs["custom-slidev-theme"])||"default"}),D=we(()=>{var H;return d.value.length>0?d.value.length:((H=h.value)==null?void 0:H.stats.discoveredAssets.length)||0}),T=we(()=>{var E;const H=((E=h.value)==null?void 0:E.stats.layoutDistribution)||{};return Object.entries(H).map(([O,z])=>({name:O,count:z}))});async function w(H=Rc){try{const E=await H();E!=null&&E.notebooks&&Array.isArray(E.notebooks)&&(u.value=E.notebooks.filter(O=>!O.closed),u.value.length>0&&!m.value&&(m.value=u.value[0].id))}catch(E){console.warn("获取笔记本列表失败:",E)}}function R(){var H;(H=s.value)==null||H.click()}function N(){l.value=null,r.value="",a.value=0,h.value=null,d.value=[],o.value=""}async function F(H){o.value="",l.value=H,r.value=H.name,a.value=H.size;try{if(H.name.toLowerCase().endsWith(".zip")){const O=await H.arrayBuffer(),z=await n0(O);if(!z.entryMarkdown){o.value="未在 Zip 压缩包中找到 slides.md 或任何有效的 Markdown 入口文件";return}d.value=z.assets;const X=ro(z.entryMarkdown,{stripNotesFromMarkdown:b.value,cleanHtmlToMarkdown:f.value,cleanSlots:!1,virtualFiles:z.virtualFiles});h.value=X,v.value=X.docTitle||H.name.replace(/\.zip$/i,"")}else{const O=await H.text();d.value=[];const z=H.path||"",X=z?z.replace(/[\\/][^\\/]+$/,""):"",Z=ro(O,{stripNotesFromMarkdown:b.value,cleanHtmlToMarkdown:f.value,cleanSlots:!1,baseDir:X||void 0});h.value=Z,v.value=Z.docTitle||H.name.replace(/\.md$/i,"")}}catch(E){console.error("解析文件失败:",E),o.value=`解析文件失败: ${E.message||String(E)}`}}function q(){if(o.value="",!c.value.trim()){h.value=null;return}try{const H=ro(c.value,{stripNotesFromMarkdown:b.value,cleanHtmlToMarkdown:f.value,cleanSlots:!1});h.value=H,v.value=H.docTitle||"Slidev 演示文稿"}catch(H){o.value=`解析 Markdown 源码失败: ${H.message||String(H)}`}}async function _(){l.value?await F(l.value):c.value&&q()}async function L(H){const E=H.target;E.files&&E.files[0]&&await F(E.files[0])}async function y(H){var E;i.value=!1,(E=H.dataTransfer)!=null&&E.files&&H.dataTransfer.files[0]&&await F(H.dataTransfer.files[0])}async function M(H=e){if(h.value){if(!m.value&&u.value.length>0&&(m.value=u.value[0].id),!m.value){o.value="请先选择目标笔记本";return}n.value=!0,o.value="";try{return await h0({presentation:h.value,notebookId:m.value,docTitle:v.value,extractedAssets:d.value,uploadAssets:k.value,autoPreview:x.value,plugin:H})}catch(E){console.error("导入 Slidev 演示失败:",E),o.value=`导入执行失败: ${E.message||String(E)}`}finally{n.value=!1}}}return{inputMode:t,isDragging:i,isImporting:n,errorMessage:o,fileInputRef:s,selectedFile:l,selectedFileName:r,selectedFileSize:a,rawMarkdownText:c,extractedAssets:d,parsedPresentation:h,customDocTitle:v,notebooks:u,selectedNotebookId:m,optCleanHtml:f,optStripNotes:b,optUploadAssets:k,optAutoPreview:x,formattedFileSize:C,currentTheme:A,extractedAssetsCount:D,layoutChips:T,fetchNotebooks:w,triggerFileInput:R,clearFile:N,processFile:F,onFileSelected:L,onFileDrop:y,onTextChange:q,reprocessCurrentInput:_,handleConfirmImport:M}}const g0={class:"spm-import-dialog"},v0={class:"spm-tabs-header"},b0={class:"spm-dialog-body"},y0={key:0,class:"spm-file-section"},k0={key:0,class:"spm-dropzone-prompt"},w0={class:"spm-dropzone-icon"},x0={key:1,class:"spm-dropzone-active"},S0={class:"spm-file-badge"},_0={class:"spm-file-size"},C0={key:1,class:"spm-text-section"},$0={key:2,class:"spm-error-banner"},I0={key:3,class:"spm-preview-card"},T0={class:"spm-preview-card__header"},E0={style:{display:"inline-flex","align-items":"center",gap:"4px"}},A0={class:"spm-config-grid"},B0={class:"spm-form-item"},M0={class:"spm-form-item"},D0=["value"],L0={class:"spm-stats-grid"},O0={class:"spm-stat-box"},P0={class:"spm-stat-value"},R0={class:"spm-stat-box"},N0={class:"spm-stat-value"},z0={class:"spm-stat-box"},F0={class:"spm-stat-value"},H0={class:"spm-stat-box"},j0={class:"spm-stat-value"},W0={key:0,class:"spm-chips-row"},U0={class:"spm-options-group"},V0={class:"spm-checkbox-label"},K0={class:"spm-checkbox-label"},G0={class:"spm-checkbox-label"},q0={class:"spm-checkbox-label"},Z0={class:"spm-dialog-footer"},Y0=["disabled"],J0=["disabled"],X0={key:0,style:{display:"inline-flex","align-items":"center",gap:"4px"}},Q0={key:1,style:{display:"inline-flex","align-items":"center",gap:"4px"}},ek=xt({__name:"SlidevImportDialog",emits:["close","success"],setup(e,{emit:t}){const i=t,n=Rt("plugin"),{inputMode:o,isDragging:s,isImporting:l,errorMessage:r,fileInputRef:a,selectedFileName:c,rawMarkdownText:d,extractedAssetsCount:h,parsedPresentation:v,customDocTitle:u,notebooks:m,selectedNotebookId:f,optCleanHtml:b,optStripNotes:k,optUploadAssets:x,optAutoPreview:C,formattedFileSize:A,currentTheme:D,layoutChips:T,fetchNotebooks:w,triggerFileInput:R,clearFile:N,onFileSelected:F,onFileDrop:q,onTextChange:_,reprocessCurrentInput:L,handleConfirmImport:y}=m0(n);un(async()=>{await w()});async function M(){const E=await y();E&&(i("success",{docId:E}),i("close"))}function H(){i("close")}return(E,O)=>(Q(),te("div",{class:"spm-modal-overlay",onClick:Lt(H,["self"])},[p("div",g0,[p("div",{class:"spm-dialog-header"},[O[18]||(O[18]=p("div",{class:"spm-dialog-title"},[p("svg",{class:"spm-dialog-icon","aria-hidden":"true"},[p("use",{"xlink:href":"#iconSlidev"})]),p("span",null,"导入 Slidev 演示文档")],-1)),p("button",{class:"spm-close-btn",title:"关闭",onClick:H},"✕")]),p("div",v0,[p("button",{class:Se(["spm-tab-btn",{active:ve(o)==="file"}]),onClick:O[0]||(O[0]=z=>o.value="file")},[le(de,{name:"package"}),O[19]||(O[19]=p("span",null,"文件 / 压缩包导入 (.zip / .md)",-1))],2),p("button",{class:Se(["spm-tab-btn",{active:ve(o)==="text"}]),onClick:O[1]||(O[1]=z=>o.value="text")},[le(de,{name:"notes"}),O[20]||(O[20]=p("span",null,"粘贴 Markdown 源码",-1))],2)]),p("div",b0,[ve(o)==="file"?(Q(),te("div",y0,[p("div",{class:Se(["spm-dropzone",{dragover:ve(s),"has-file":!!ve(c)}]),onDragover:O[4]||(O[4]=Lt(z=>s.value=!0,["prevent"])),onDragleave:O[5]||(O[5]=Lt(z=>s.value=!1,["prevent"])),onDrop:O[6]||(O[6]=Lt((...z)=>ve(q)&&ve(q)(...z),["prevent"])),onClick:O[7]||(O[7]=(...z)=>ve(R)&&ve(R)(...z))},[p("input",{ref_key:"fileInputRef",ref:a,type:"file",accept:".zip,.md",class:"spm-hidden-input",onChange:O[2]||(O[2]=(...z)=>ve(F)&&ve(F)(...z))},null,544),ve(c)?(Q(),te("div",x0,[p("span",S0,[le(de,{name:"notes"}),$t(" "+ye(ve(c)),1)]),p("span",_0,"("+ye(ve(A))+")",1),p("button",{class:"spm-btn-text",onClick:O[3]||(O[3]=Lt((...z)=>ve(N)&&ve(N)(...z),["stop"]))},"更换文件")])):(Q(),te("div",k0,[p("span",w0,[le(de,{name:"folder",style:{"font-size":"32px"}})]),O[21]||(O[21]=p("p",{class:"spm-dropzone-text"},"点击选择文件，或直接拖拽文件至此处",-1)),O[22]||(O[22]=p("p",{class:"spm-dropzone-hint"},[$t(" 支持 Slidev 完整工程 "),p("strong",null,".zip"),$t("（自动解包 public/ 静态素材）或单文件 "),p("strong",null,".md")],-1))]))],34)])):(Q(),te("div",C0,[Et(p("textarea",{"onUpdate:modelValue":O[8]||(O[8]=z=>Ye(d)?d.value=z:null),class:"spm-textarea spm-source-editor",rows:"8",placeholder:"在此直接粘贴包含 Frontmatter 的 Slidev slides.md 源码...",onInput:O[9]||(O[9]=(...z)=>ve(_)&&ve(_)(...z))},null,544),[[$o,ve(d)]])])),ve(r)?(Q(),te("div",$0," ⚠️ "+ye(ve(r)),1)):Oe("",!0),ve(v)?(Q(),te("div",I0,[p("div",T0,[p("span",E0,[le(de,{name:"sparkles"}),O[23]||(O[23]=$t(" 演示解析摘要",-1))]),O[24]||(O[24]=p("span",{class:"spm-badge-success"},"预检就绪",-1))]),p("div",A0,[p("div",B0,[O[25]||(O[25]=p("label",{class:"spm-form-label"},"笔记文档标题",-1)),Et(p("input",{"onUpdate:modelValue":O[10]||(O[10]=z=>Ye(u)?u.value=z:null),class:"spm-input",placeholder:"思源新文档标题"},null,512),[[$o,ve(u)]])]),p("div",M0,[O[26]||(O[26]=p("label",{class:"spm-form-label"},"存放目标笔记本",-1)),Et(p("select",{"onUpdate:modelValue":O[11]||(O[11]=z=>Ye(f)?f.value=z:null),class:"spm-select"},[(Q(!0),te(Ue,null,kt(ve(m),z=>(Q(),te("option",{key:z.id,value:z.id},ye(z.name),9,D0))),128))],512),[[df,ve(f)]])])]),p("div",L0,[p("div",O0,[p("span",P0,ye(ve(v).totalSlides),1),O[27]||(O[27]=p("span",{class:"spm-stat-label"},"幻灯片页数",-1))]),p("div",R0,[p("span",N0,ye(ve(D)),1),O[28]||(O[28]=p("span",{class:"spm-stat-label"},"演示主题",-1))]),p("div",z0,[p("span",F0,ye(ve(v).stats.totalNotes),1),O[29]||(O[29]=p("span",{class:"spm-stat-label"},"演讲者提词",-1))]),p("div",H0,[p("span",j0,ye(ve(h)),1),O[30]||(O[30]=p("span",{class:"spm-stat-label"},"关联本地素材",-1))])]),ve(T).length>0?(Q(),te("div",W0,[O[31]||(O[31]=p("span",{class:"spm-chips-label"},"页面版式分布：",-1)),(Q(!0),te(Ue,null,kt(ve(T),z=>(Q(),te("span",{key:z.name,class:"spm-chip-badge"},ye(z.name)+": "+ye(z.count),1))),128))])):Oe("",!0),p("div",U0,[p("label",V0,[Et(p("input",{"onUpdate:modelValue":O[12]||(O[12]=z=>Ye(b)?b.value=z:null),type:"checkbox",onChange:O[13]||(O[13]=(...z)=>ve(L)&&ve(L)(...z))},null,544),[[Xn,ve(b)]]),O[32]||(O[32]=p("span",null,"智能剥离展示型 HTML 容器为干净原生的 Markdown 笔记块",-1))]),p("label",K0,[Et(p("input",{"onUpdate:modelValue":O[14]||(O[14]=z=>Ye(k)?k.value=z:null),type:"checkbox",onChange:O[15]||(O[15]=(...z)=>ve(L)&&ve(L)(...z))},null,544),[[Xn,ve(k)]]),O[33]||(O[33]=p("span",null,"提取演讲者提词到块属性并保持正文笔记清爽",-1))]),p("label",G0,[Et(p("input",{"onUpdate:modelValue":O[16]||(O[16]=z=>Ye(x)?x.value=z:null),type:"checkbox"},null,512),[[Xn,ve(x)]]),O[34]||(O[34]=p("span",null,"自动上传关联素材至思源资产库并重写路径 (assets/...)",-1))]),p("label",q0,[Et(p("input",{"onUpdate:modelValue":O[17]||(O[17]=z=>Ye(C)?C.value=z:null),type:"checkbox"},null,512),[[Xn,ve(C)]]),O[35]||(O[35]=p("span",null,"导入后自动打开新文档并开启下方分屏放映预览",-1))])])])):Oe("",!0)]),p("div",Z0,[p("button",{class:"spm-btn-secondary",disabled:ve(l),onClick:H}," 取消 ",8,Y0),p("button",{class:"spm-btn-primary",disabled:!ve(v)||ve(l),onClick:M},[ve(l)?(Q(),te("span",X0,[le(de,{name:"refresh"}),O[36]||(O[36]=$t(" 正在导入生成中...",-1))])):(Q(),te("span",Q0,[le(de,{name:"rocket"}),O[37]||(O[37]=$t(" 确认导入思源笔记",-1))]))],8,J0)])])]))}}),tk=Mt(ek,[["__scopeId","data-v-2eff6f1e"]]);function nr(e){return e?e==="NodeThematicBreak"||e==="tb"||e==="thematic-break":!1}function ik(e,t){var r;if(!e||e.length===0)return null;const i=t.activeBlockId||"",n=t.currentTopBlockId||i,o=t.currentPageDividerId||"",s=t.activeBlockType||"";if(nr(s)&&i){let a=e.find(c=>c.startBlockId===i);if(a||(a=e.find(c=>{var d,h;return((h=(d=c.blocks)==null?void 0:d[0])==null?void 0:h.id)===i}),a)||(a=e.find(c=>{var d;return(d=c.allBlockIds)==null?void 0:d.includes(i)}),a))return a}if(o){let a=e.find(c=>c.startBlockId===o);if(a||(a=e.find(c=>{var d,h;return((h=(d=c.blocks)==null?void 0:d[0])==null?void 0:h.id)===o}),a))return a}if(i){let a=e.find(d=>d.startBlockId===i);if(a||(a=e.find(d=>{var h,v;return((h=d.blocks)==null?void 0:h.some(u=>u.id===i))||((v=d.allBlockIds)==null?void 0:v.includes(i))}),a)||n&&n!==i&&(a=e.find(d=>{var h,v;return((h=d.blocks)==null?void 0:h.some(u=>u.id===n))||((v=d.allBlockIds)==null?void 0:v.includes(n))}),a)||(a=e.find(d=>{var h;return(h=d.noteBlocks)==null?void 0:h.some(v=>v.id===i||v.id===n)}),a))return a;const c=(r=t.activeBlockAttrs)==null?void 0:r[Ce];if(c&&["col-1","col-2","col-3"].includes(c)&&(a=e.find(d=>{var h,v;return((h=d.frontmatter)==null?void 0:h.layout)==="three-cols-header"||((v=d.blocks)==null?void 0:v.some(u=>u.slot==="col-1"||u.slot==="col-2"||u.slot==="col-3"))}),a))return a}return e[0]||null}function nk(e,t){if(!t)return!1;if(e===t||typeof document>"u")return!0;const i=document.querySelector(`.protyle-wysiwyg [data-node-id="${t}"]`)||document.querySelector(`[data-node-id="${t}"]`);if(!i)return!1;const n=i.querySelector(":scope > [data-node-id], :scope > div > [data-node-id]");return(n==null?void 0:n.getAttribute("data-node-id"))===e}function ok(e){let t=null;function i(c="已同步"){e.saveStatus.value=c,t&&(typeof window<"u"?window.clearTimeout(t):clearTimeout(t));const d=()=>{e.saveStatus.value=""};typeof window<"u"?t=window.setTimeout(d,1200):t=setTimeout(d,1200)}async function n(c){var u;const d=e.activeBlockId.value||e.currentDocId.value;if(!d)return;for(const[m,f]of Object.entries(c))e.activeBlockAttrs.value[m]=f;Be.setBlockAttrOverride(d,c),et(d,c);const h=(u=e.parentContainerId)==null?void 0:u.value,v=!!(h&&nk(d,h));if(Ze in c&&v&&h){const m=c[Ze];e.parentContainerClicks&&(e.parentContainerClicks.value=m),Be.setBlockAttrOverride(h,{[Ze]:m}),et(h,{[Ze]:m}),Ne(h,{[Ze]:m}).catch(()=>{})}if(he in c){const m=c[he];e.currentPageDividerLayout.value=m,e.targetSlide.value&&(e.targetSlide.value.frontmatter||(e.targetSlide.value.frontmatter={}),e.targetSlide.value.frontmatter.layout=m)}if(yt in c){const m=c[yt];e.targetSlide.value&&(e.targetSlide.value.frontmatter||(e.targetSlide.value.frontmatter={}),e.targetSlide.value.frontmatter.layoutRatio=m)}i("保存中...");try{await Ne(d,c),i("已同步"),e.plugin&&await e.plugin.compileCurrentDocument()}catch{i("同步失败")}}async function o(c,d){await n({[c]:d})}function s(){const c=e.activeBlockType.value==="NodeThematicBreak"||e.activeBlockType.value==="NodeThematicBreakBlock"||e.activeBlockType.value==="hr"||e.activeBlockType.value==="thematicbreak";return e.currentPageDividerId.value||(c?e.activeBlockId.value:"")||e.currentDocId.value}async function l(c,d){const h=s();if(h){h===e.activeBlockId.value&&(e.activeBlockAttrs.value[c]=d),Be.setBlockAttrOverride(h,{[c]:d}),et(h,{[c]:d}),c===he&&(e.currentPageDividerLayout.value=d,e.targetSlide.value&&(e.targetSlide.value.frontmatter||(e.targetSlide.value.frontmatter={}),e.targetSlide.value.frontmatter.layout=d)),c===yt&&e.targetSlide.value&&(e.targetSlide.value.frontmatter||(e.targetSlide.value.frontmatter={}),e.targetSlide.value.frontmatter.layoutRatio=d),i("保存中...");try{await Ne(h,{[c]:d}),i("已同步"),e.plugin&&await e.plugin.compileCurrentDocument()}catch{i("同步失败")}}}async function r(c,d){const h=s();if(!h)return;const v={[he]:c,[yt]:d};h===e.activeBlockId.value&&(e.activeBlockAttrs.value[he]=c,e.activeBlockAttrs.value[yt]=d),e.currentPageDividerLayout.value=c,Be.setBlockAttrOverride(h,v),et(h,v),e.targetSlide.value&&(e.targetSlide.value.frontmatter||(e.targetSlide.value.frontmatter={}),e.targetSlide.value.frontmatter.layout=c,e.targetSlide.value.frontmatter.layoutRatio=d),i("应用排版中...");try{await Ne(h,v),i("已应用分栏与比例"),e.plugin&&await e.plugin.compileCurrentDocument()}catch{i("应用失败")}}async function a(c,d){var v;const h=e.currentDocId.value||e.activeBlockId.value;if(h){e.activeBlockAttrs.value[c]=d,Be.setBlockAttrOverride(h,{[c]:d}),et(h,{[c]:d}),(v=e.latestDoc.value)!=null&&v.config&&(c===An&&(e.latestDoc.value.config.theme=d),c===Bn&&(e.latestDoc.value.config.aspectRatio=d),c===Mn&&(e.latestDoc.value.config.defaultTransition=d)),i("更新中...");try{await Ne(h,{[c]:d}),i("已更新"),e.plugin&&await e.plugin.compileCurrentDocument(h)}catch{i("更新失败")}}}return{triggerSaveNotice:i,saveAttrs:n,saveAttr:o,getPageTargetBlockId:s,savePageAttr:l,applyPageLayoutAndRatio:r,saveDocAttr:a}}function Xr(e,t){const i=(e.blocks||[]).filter(l=>{const r=(l.content||l.rawMarkdown||"").trim();return r&&r!=="---"});if(i.length===0)return"本页暂无内容，建议过渡承接上下文。";const n=[],o=[];for(const l of i){const r=(l.content||l.rawMarkdown||"").trim();r&&(l.type==="h"||r.startsWith("#")?n.push(r.replace(/^#+\s*/,"")):o.push(r.slice(0,50)))}const s=[];return n.length>0&&s.push(`【核心重点】：${n.join("、")}`),o.length>0&&(s.push("【口播要点】："),o.slice(0,3).forEach((l,r)=>{s.push(`${r+1}. 讲解 ${l}`)})),s.push("【过渡提示】：注意观察听众反应，适时抛出互动提问。"),s.join(`
`)}async function Fa(e,t){const i=e.blocks&&e.blocks.length>0?e.blocks.map(n=>(n.content||n.rawMarkdown||"").trim()).filter(n=>n&&n!=="---").join(`
`):(e.rawMarkdown||"").replace(/^---\s*$/gm,"").trim();if(t&&i){const n=`你是一位专业的演讲教练。请根据以下幻灯片内容，提炼出简短精炼的演讲口播提词卡（Notes），包含核心观点与口播要点，总字数在 150 字以内：
${i}`;try{const o=await t(n);if(o&&o.trim())return{notes:o.trim(),isAiGenerated:!0}}catch(o){return{notes:Xr(e),isAiGenerated:!1,error:(o==null?void 0:o.message)||"AI 调用异常"}}}return{notes:Xr(e),isAiGenerated:!1}}async function sk(e,t){return(await Fa(e,t)).notes}function rk(e,t){const i=fe(!1),{triggerSaveNotice:n}=t;async function o(h){var A,D,T,w,R,N,F,q;const m=`> [!NOTE] 💡 演讲备注
${(h||"在此输入本页讲稿提词...").split(/\r?\n/).map(_=>`> ${_}`).join(`
`)}
{: custom-slidev-note="true"}`,f=((A=e.latestDoc.value)==null?void 0:A.slides)||[],b=e.targetSlide.value,k=b?f.findIndex(_=>_===b):-1;let x=null;if(k!==-1&&k<f.length-1){const _=f[k+1];x=await Mi("markdown",m,_.startBlockId)}else{const _=((D=b==null?void 0:b.noteBlocks)==null?void 0:D.slice(-1)[0])||((T=b==null?void 0:b.blocks)==null?void 0:T.slice(-1)[0]),L=(_==null?void 0:_.id)||(b==null?void 0:b.startBlockId);L?x=await Mi("markdown",m,void 0,L):x=await ds("markdown",m,e.currentDocId.value)}const C=((N=(R=(w=x==null?void 0:x[0])==null?void 0:w.doOperations)==null?void 0:R[0])==null?void 0:N.id)||((F=x==null?void 0:x[0])==null?void 0:F.id);return C&&(await Ne(C,{[nt]:"true"}),Be.setBlockAttrOverride(C,{[nt]:"true"}),Ri(C,(q=e.plugin)==null?void 0:q.app)),e.plugin&&await e.plugin.compileCurrentDocument(),C}async function s(){const h=e.activeBlockId.value;if(h)if(e.isNoteBlock.value){n("取消中...");try{await Ne(h,{[nt]:"","slidev-note":""}),Be.setBlockAttrOverride(h,{[nt]:"","slidev-note":""}),et(h,{[nt]:"","slidev-note":""}),delete e.activeBlockAttrs.value[nt],delete e.activeBlockAttrs.value["slidev-note"],n("已取消备注"),me.showMessage("已取消讲稿备注"),e.plugin&&await e.plugin.compileCurrentDocument()}catch(v){console.error("[SiYuanSlidev] 取消讲稿备注失败:",v),n("取消失败"),me.showMessage("取消讲稿备注失败")}}else{n("转换中...");try{let v=e.rawSnippet.value;try{const b=await zc(h);b!=null&&b.kramdown&&(v=b.kramdown)}catch{}const f=`> [!NOTE] 💡 演讲备注
${(xa(v)||v.replace(/<[^>]+>/g,"").trim()||"在此输入本页讲稿提词...").split(/\r?\n/).map(b=>`> ${b}`).join(`
`)}
{: custom-slidev-note="true"}`;await cr("markdown",f,h),await Ne(h,{[nt]:"true"}),Be.setBlockAttrOverride(h,{[nt]:"true"}),et(h,{[nt]:"true"}),e.activeBlockAttrs.value[nt]="true",e.activeBlockType.value="NodeCallout",n("已设为讲稿备注"),me.showMessage("已转为讲稿备注提示块（不在幻灯片中渲染）"),e.plugin&&await e.plugin.compileCurrentDocument()}catch(v){console.error("[SiYuanSlidev] 转换讲稿备注提示块失败:",v),n("设置失败"),me.showMessage("转为讲稿备注提示块失败")}}}async function l(){try{await o(),me.showMessage("已在正文末尾插入讲稿备注提示块")}catch(h){me.showMessage("插入讲稿备注块失败"),console.error(h)}}function r(){var u;const h=e.currentSlideNoteBlockId.value;if(!h){me.showMessage("未找到本页关联的讲稿备注块");return}Ri(h,(u=e.plugin)==null?void 0:u.app)?me.showMessage("已在编辑区定位讲稿备注块"):me.showMessage("定位讲稿备注块失败")}async function a(){var u;if(!e.currentDocId.value)return;const h=e.targetSlide.value||{startBlockId:e.activeBlockId.value||e.currentDocId.value,blocks:e.rawSnippet.value&&e.rawSnippet.value!=="---"?[{id:e.activeBlockId.value,type:e.activeBlockType.value,content:e.rawSnippet.value,rawMarkdown:""}]:[],rawMarkdown:e.rawSnippet.value&&e.rawSnippet.value!=="---"?e.rawSnippet.value:""};me.showMessage("正在调用思源 AI 提炼本页讲稿提词...");const v=await Fa(h,sl);if(v.notes){const m=e.currentSlideNoteBlockId.value;if(m){const f=`> [!NOTE] 💡 演讲备注
${v.notes.split(/\r?\n/).map(b=>`> ${b}`).join(`
`)}
{: custom-slidev-note="true"}`;await cr("markdown",f,m),await Ne(m,{[nt]:"true"}),Be.setBlockAttrOverride(m,{[nt]:"true"}),Ri(m,(u=e.plugin)==null?void 0:u.app)}else await o(v.notes);v.isAiGenerated?me.showMessage("思源 AI 演讲提词卡生成成功！"):me.showMessage("未获取到思源 AI 响应，已生成预设提词卡模板",5e3),e.plugin&&await e.plugin.compileCurrentDocument()}}async function c(){var m;if(i.value)return;const h=((m=e.latestDoc.value)==null?void 0:m.slides)||[];if(h.length===0){me.showMessage("当前文档无幻灯片页面");return}const v=h.map((f,b)=>({slide:f,idx:b})).filter(({slide:f})=>{var x;const b=Array.isArray(f.noteBlocks)&&f.noteBlocks.length>0,k=!!((x=f.notes)!=null&&x.trim());return!b&&!k});if(v.length===0){me.showMessage("所有幻灯片页面均已存在讲稿备注块，无需追加");return}const u=v.length;me.confirm("批量追加讲稿备注",`将在未配置讲稿的 ${u} 页末尾自动插入讲稿提示块，是否继续？`,async()=>{var b,k,x,C,A,D;if(i.value)return;i.value=!0,me.showMessage("正在批量追加讲稿块...");let f=0;try{const R=`> [!NOTE] 💡 演讲备注
${"在此输入本页讲稿提词...".split(/\r?\n/).map(N=>`> ${N}`).join(`
`)}
{: custom-slidev-note="true"}`;for(const{slide:N,idx:F}of v)try{let q=null;if(F<h.length-1){const L=h[F+1];q=await Mi("markdown",R,L.startBlockId)}else{const L=((b=N==null?void 0:N.noteBlocks)==null?void 0:b.slice(-1)[0])||((k=N==null?void 0:N.blocks)==null?void 0:k.slice(-1)[0]),y=(L==null?void 0:L.id)||(N==null?void 0:N.startBlockId);y?q=await Mi("markdown",R,void 0,y):q=await ds("markdown",R,e.currentDocId.value)}const _=((A=(C=(x=q==null?void 0:q[0])==null?void 0:x.doOperations)==null?void 0:C[0])==null?void 0:A.id)||((D=q==null?void 0:q[0])==null?void 0:D.id);_&&(await Ne(_,{[nt]:"true"}),Be.setBlockAttrOverride(_,{[nt]:"true"})),f++}catch(q){console.error(`[SiYuanSlidev] 为第 ${F+1} 页追加讲稿块失败:`,q)}e.plugin&&await e.plugin.compileCurrentDocument(),me.showMessage(`已成功为 ${f} 页追加讲稿备注块`)}catch(T){console.error("[SiYuanSlidev] 批量追加讲稿块失败:",T),me.showMessage("批量追加讲稿块时出现异常")}finally{i.value=!1}})}async function d(){var f;if(i.value)return;const h=((f=e.latestDoc.value)==null?void 0:f.slides)||[];if(h.length===0){me.showMessage("当前文档无幻灯片页面");return}const v=[];for(const b of h)if(b.noteBlocks&&b.noteBlocks.length>0)for(const k of b.noteBlocks)k.id&&v.push({id:k.id,pageIndex:b.pageIndex});if(v.length===0){me.showMessage("当前文档中没有讲稿备注块，无需删除");return}const u=new Set(v.map(b=>b.pageIndex)).size,m=v.length;me.confirm("危险操作：批量删除所有讲稿块",`此操作将从正文中物理删除全部 ${m} 个讲稿备注块（涉及 ${u} 页），删除后无法撤销。是否确认继续？`,async()=>{if(i.value)return;i.value=!0,me.showMessage("正在批量删除讲稿块...");let b=0;try{for(const k of v)try{await ol(k.id),Be.clearBlockAttrOverride(k.id),b++}catch(x){console.error(`[SiYuanSlidev] 删除讲稿块 ${k.id} 失败:`,x)}e.activeBlockId.value&&v.some(k=>k.id===e.activeBlockId.value)&&(delete e.activeBlockAttrs.value[nt],delete e.activeBlockAttrs.value["slidev-note"]),e.plugin&&await e.plugin.compileCurrentDocument(),me.showMessage(`已成功删除全部 ${b} 个讲稿备注块`)}catch(k){console.error("[SiYuanSlidev] 批量删除讲稿块失败:",k),me.showMessage("批量删除讲稿块时出现异常")}finally{i.value=!1}})}return{isBatchProcessing:i,createNoteBlockOnCurrentSlide:o,onToggleNoteBlock:s,onAddNoteBlock:l,onLocateNoteBlock:r,onGenerateNotesWithAI:a,onBatchAppendNotes:c,onBatchDeleteNotes:d}}function lk(e,t){const{saveAttr:i,saveAttrs:n,savePageAttr:o}=t;async function s(){(e.videoAutoplay.value?"false":"true")==="true"?(await n({[Bi]:"true",[Vi]:"true"}),e.activeBlockAttrs.value[Bi]="true",e.activeBlockAttrs.value[Vi]="true"):(await i(Bi,"false"),e.activeBlockAttrs.value[Bi]="false")}async function l(){const w=e.videoLoop.value?"false":"true";await i(po,w)}async function r(){const w=e.videoMuted.value?"false":"true";await i(Vi,w)}async function a(){const w=e.videoControls.value?"false":"true";await i(ho,w)}async function c(w){var _;const R=e.activeBlockId.value;if(!R)return;const N=e.rawSnippet.value||"",F=wi(N)||"",q=e.currentPageDividerId.value||e.currentDocId.value;if(w)if(w==="background"){const L={[Ge]:"background",[he]:""};q&&F&&(e.pageBackground.value=F,await Ne(q,{[je]:F}).catch(()=>{}),Be.setBlockAttrOverride(q,{[je]:F}),et(q,{[je]:F}),e.targetSlide.value&&(e.targetSlide.value.frontmatter||(e.targetSlide.value.frontmatter={}),e.targetSlide.value.frontmatter.background=F)),await n(L)}else(w===mo||w===go)&&await n({[he]:w,[Ge]:""});else{const L={[Ge]:"",[he]:""};if(e.activeBlockAttrs.value[je]==="true"&&(L[je]=""),q&&F&&e.pageBackground.value===F&&(e.pageBackground.value="",await Ne(q,{[je]:""}).catch(()=>{}),Be.setBlockAttrOverride(q,{[je]:""}),et(q,{[je]:""}),(_=e.targetSlide.value)!=null&&_.frontmatter&&delete e.targetSlide.value.frontmatter.background),await n(L),typeof document<"u"){const y=document.querySelector(`.protyle-wysiwyg [data-node-id="${R}"]`),M=y==null?void 0:y.closest('[data-type="NodeListItem"]'),H=M==null?void 0:M.getAttribute("data-node-id");if(H&&H!==R){const E={[he]:"",[Ge]:""};et(H,E),Be.setBlockAttrOverride(H,E),await Ne(H,E).catch(()=>{})}}}}function d(){e.elemClick.value?i(Ze,""):i(Ze,"+1")}function h(w){i(Ze,w)}function v(w){i(qt,w)}function u(w){(e.activeBlockAttrs.value[Ce]||"")===w?i(Ce,""):i(Ce,w)}function m(w){e.elemShikiLines.value=w,i(Ni,w)}function f(w){e.elemMaxHeight.value=w,i(Dn,w)}async function b(){const w=e.currentSlideLayout.value==="three-cols-header";await i(Ce,w?"col-1":"left"),me.showMessage(w?"已将当前块设置为第 1 栏 (col-1)":"已将当前块设置为双栏左栏 (left)")}async function k(){const w=e.activeBlockId.value;if(!w)return;const R={[Ze]:"",[qt]:"",[Ce]:"",[Ni]:"",[Dn]:"",[nt]:"","slidev-note":"",[he]:"",[yt]:"",[Ge]:"",[tt]:"",[je]:"",[Dt]:"",[Bi]:"",[po]:"",[Vi]:"",[ho]:""};if(et(w,R),await Ne(w,R),Be.clearBlockAttrOverride(w),typeof document<"u"){const N=document.querySelector(`.protyle-wysiwyg [data-node-id="${w}"]`),F=N==null?void 0:N.closest('[data-type="NodeListItem"]'),q=F==null?void 0:F.getAttribute("data-node-id");q&&q!==w&&(et(q,R),await Ne(q,R).catch(()=>{}),Be.clearBlockAttrOverride(q))}e.activeBlockAttrs.value={},e.elemShikiLines.value="",e.elemMaxHeight.value="",e.pageBackground.value="",e.pageImage.value="",me.showMessage("已清除本块演示属性"),e.plugin&&await e.plugin.compileCurrentDocument()}async function x(){if(e.activeBlockId.value)try{await Mi("markdown","---",e.activeBlockId.value,void 0),me.showMessage("已在上方插入分页符 (---)"),e.plugin&&e.plugin.compileCurrentDocument()}catch{me.showMessage("插入分页符失败")}}async function C(){const w=e.activeBlockId.value||e.currentDocId.value;if(w)try{await Mi("markdown","---",void 0,w),me.showMessage("已在下方插入分页符 (---)"),e.plugin&&e.plugin.compileCurrentDocument()}catch{me.showMessage("插入分页符失败")}}async function A(){if(e.activeBlockId.value)try{await ol(e.activeBlockId.value),me.showMessage("已删除该分页符"),e.activeBlockId.value="",e.activeBlockType.value="",e.plugin&&e.plugin.compileCurrentDocument()}catch{me.showMessage("删除失败")}}async function D(){var w,R;try{let N=null;if(typeof document<"u"){const q=e.activeBlockId.value;if(q){const _=document.querySelector(`.protyle-wysiwyg [data-node-id="${q}"]`);_&&(N=_.getAttribute("data-type")==="NodeSuperBlock"?_:_.closest('[data-type="NodeSuperBlock"]'))}if(!N){const _=e.currentPageDividerId.value||(e.activeBlockType.value==="hr"||e.activeBlockType.value==="NodeThematicBreak"?e.activeBlockId.value:"");if(_){const L=document.querySelector(`.protyle-wysiwyg [data-node-id="${_}"]`);if(L){let y=L.nextElementSibling;for(;y&&!(y.getAttribute("data-type")==="NodeThematicBreak"||(w=y.classList)!=null&&w.contains("protyle-wysiwyg__block--hr"));){const M=y.getAttribute("data-type")==="NodeSuperBlock"?y:y.querySelector('[data-type="NodeSuperBlock"]');if(M){N=M;break}y=y.nextElementSibling}}}else{const L=document.querySelector('.protyle-wysiwyg [data-type="NodeThematicBreak"], .protyle-wysiwyg .protyle-wysiwyg__block--hr'),y=Array.from(document.querySelectorAll('.protyle-wysiwyg [data-type="NodeSuperBlock"]'));for(const M of y)if(!L||M.compareDocumentPosition(L)&Node.DOCUMENT_POSITION_FOLLOWING){N=M;break}}}}const F=[];if(N){const q=Array.from(N.querySelectorAll(":scope > [data-node-id]"));for(const _ of q){const L=_.getAttribute("data-node-id");L&&(F.push(L),_.removeAttribute("style"))}}else if((R=e.targetSlide.value)!=null&&R.blocks){for(const q of e.targetSlide.value.blocks)if(q.children&&q.children.length>=2){for(const _ of q.children)_.id&&F.push(_.id);break}}if(F.length>0)for(const q of F)await Ne(q,{style:""}).catch(()=>{});await o(yt,""),me.showMessage("已重置超级块为平均分布比例"),e.plugin&&await e.plugin.compileCurrentDocument()}catch(N){console.error("[layout-actions] resetSuperBlockWidth error:",N),me.showMessage("重置超级块比例失败")}}async function T(){var w,R,N;try{let F=null;if(typeof document<"u"){const _=e.currentPageDividerId.value||(e.activeBlockType.value==="hr"||e.activeBlockType.value==="NodeThematicBreak"?e.activeBlockId.value:""),L=e.activeBlockId.value;let y=[];if(_){const E=document.querySelector(`.protyle-wysiwyg [data-node-id="${_}"]`);if(E){let O=E.nextElementSibling;for(;O&&!(O.getAttribute("data-type")==="NodeThematicBreak"||(w=O.classList)!=null&&w.contains("protyle-wysiwyg__block--hr"));)y.push(O),O=O.nextElementSibling}}else{const E=document.querySelector('.protyle-wysiwyg [data-type="NodeThematicBreak"], .protyle-wysiwyg .protyle-wysiwyg__block--hr'),O=Array.from(document.querySelectorAll(".protyle-wysiwyg > [data-node-id]"));for(const z of O)if(!E||z.compareDocumentPosition(E)&Node.DOCUMENT_POSITION_FOLLOWING)y.push(z);else break}const M=[];let H;for(const E of y){const O=E.getAttribute("data-type");O==="NodeHeading"&&(H=E.getAttribute("data-node-id")||void 0);const z=[];O==="NodeSuperBlock"?z.push(E):z.push(...Array.from(E.querySelectorAll('[data-type="NodeSuperBlock"]')));for(const X of z){if((X.getAttribute("data-sb-layout")||"").toLowerCase()==="row")continue;const W=X.getAttribute("data-node-id")||"";let ie=[];const se=Array.from(X.querySelectorAll('[data-type="NodeListItem"]'));if(se.length===4&&(ie=se.map(re=>re.getAttribute("data-node-id")).filter(Boolean)),ie.length!==4){const re=Array.from(X.querySelectorAll(":scope > [data-node-id]"));re.length===4&&(ie=re.map(ue=>ue.getAttribute("data-node-id")).filter(Boolean))}ie.length===4&&M.push({sbId:W,itemIds:ie,headerId:H})}}M.length>0&&(L&&(F=M.find(E=>{if(E.sbId===L||E.itemIds.includes(L))return!0;const O=document.querySelector(`.protyle-wysiwyg [data-node-id="${E.sbId}"]`),z=document.querySelector(`.protyle-wysiwyg [data-node-id="${L}"]`);return!!(O&&z&&O.contains(z))})||null),F||(F=M[0]))}if(!F&&((R=e.targetSlide.value)!=null&&R.blocks)){const _=e.targetSlide.value,L=[];for(const M of _.blocks)M.rawNode?L.push(M.rawNode):L.push({id:M.id,type:M.type,content:M.content,markdown:M.rawMarkdown,children:M.children,ial:M.attributes||M.ial||{}});const y=$f(L,e.activeBlockId.value);y&&y.items.length===4&&(F={sbId:y.superBlockNode.id,itemIds:y.items.map(M=>M.id),headerId:(N=y.headerNode)==null?void 0:N.id})}if(!F||F.itemIds.length!==4)return me.showMessage("当前页面未找到包含 4 个组件的超级块（需包含 4 个列表项或 4 个子块）",4e3,"info"),!1;const q=e.currentPageDividerId.value||e.currentDocId.value;q&&(e.currentPageDividerLayout.value="clover",e.targetSlide.value&&(e.targetSlide.value.frontmatter||(e.targetSlide.value.frontmatter={}),e.targetSlide.value.frontmatter.layout="clover"),Be.setBlockAttrOverride(q,{[he]:"clover"}),et(q,{[he]:"clover"}),await Ne(q,{[he]:"clover"}).catch(()=>{})),F.headerId&&(Be.setBlockAttrOverride(F.headerId,{[Ce]:"header"}),et(F.headerId,{[Ce]:"header"}),await Ne(F.headerId,{[Ce]:"header"}).catch(()=>{}));for(let _=0;_<4;_++){const L=F.itemIds[_],y=`col-${_+1}`;Be.setBlockAttrOverride(L,{[Ce]:y}),et(L,{[Ce]:y}),await Ne(L,{[Ce]:y}).catch(()=>{})}return me.showMessage("已将本页版式设为四叶草（田字型）布局"),e.plugin&&await e.plugin.compileCurrentDocument(),!0}catch(F){return console.error("[layout-actions] applyCloverLayout error:",F),me.showMessage("配置四叶草布局失败",4e3,"error"),!1}}return{onToggleVideoAutoplay:s,onToggleVideoLoop:l,onToggleVideoMuted:r,onToggleVideoControls:a,onImageRoleChange:c,toggleElemClick:d,onElemClickStepChange:h,onElemMotionChange:v,onElemSlotChange:u,onElemShikiLinesChange:m,onElemMaxHeightChange:f,onSetTwoColsContrast:b,onClearBlockAttrs:k,onInsertDividerBefore:x,onInsertDividerAfter:C,onDeleteCurrentBlock:A,resetSuperBlockWidth:D,applyCloverLayout:T}}function ak(e){const{triggerSaveNotice:t,saveAttrs:i,saveAttr:n,savePageAttr:o,applyPageLayoutAndRatio:s,saveDocAttr:l}=ok(e),r=rk(e,{triggerSaveNotice:t}),a=lk(e,{saveAttr:n,saveAttrs:i,savePageAttr:o});function c(){if(!e.latestDoc.value){me.showMessage("请先在主编辑区打开幻灯片文档");return}const h=La(e.latestDoc.value);Oa("presentation.html",h)&&me.showMessage("已开始下载单文件离线 HTML 演示包")}function d(){if(!e.latestDoc.value){me.showMessage("请先在主编辑区打开幻灯片文档");return}Pa(e.latestDoc.value)&&me.showMessage("已唤起打印视窗，请在打印选项中选择「另存为 PDF」")}return{triggerSaveNotice:t,saveAttrs:i,saveAttr:n,savePageAttr:o,applyPageLayoutAndRatio:s,saveDocAttr:l,onToggleVideoAutoplay:a.onToggleVideoAutoplay,onToggleVideoLoop:a.onToggleVideoLoop,onToggleVideoMuted:a.onToggleVideoMuted,onToggleVideoControls:a.onToggleVideoControls,onImageRoleChange:a.onImageRoleChange,onToggleNoteBlock:r.onToggleNoteBlock,createNoteBlockOnCurrentSlide:r.createNoteBlockOnCurrentSlide,onAddNoteBlock:r.onAddNoteBlock,onLocateNoteBlock:r.onLocateNoteBlock,onGenerateNotesWithAI:r.onGenerateNotesWithAI,isBatchProcessing:r.isBatchProcessing,onBatchAppendNotes:r.onBatchAppendNotes,onBatchDeleteNotes:r.onBatchDeleteNotes,toggleElemClick:a.toggleElemClick,onElemClickStepChange:a.onElemClickStepChange,onElemMotionChange:a.onElemMotionChange,onElemSlotChange:a.onElemSlotChange,onElemShikiLinesChange:a.onElemShikiLinesChange,onElemMaxHeightChange:a.onElemMaxHeightChange,onSetTwoColsContrast:a.onSetTwoColsContrast,onClearBlockAttrs:a.onClearBlockAttrs,onInsertDividerBefore:a.onInsertDividerBefore,onInsertDividerAfter:a.onInsertDividerAfter,onDeleteCurrentBlock:a.onDeleteCurrentBlock,resetSuperBlockWidth:a.resetSuperBlockWidth,applyCloverLayout:a.applyCloverLayout,onExportHtml:c,onExportPdf:d}}function ck(e){const t=we(()=>nr(e.activeBlockType.value));function i(n){const{attrKey:o,fallback:s,mode:l="defined"}=n,r=a=>l==="truthy"?a:a!==void 0;return we(()=>{if(t.value){const c=e.activeBlockAttrs.value[o];if(r(c))return c}const a=e.currentPageDividerId.value||(t.value?e.activeBlockId.value:"");if(a){const c=Be.getBlockAttrOverride(a);if(r(c==null?void 0:c[o]))return c[o]}return s()})}return{isDivider:t,resolvePageAttr:i}}const dk={class:"spm-slidev-inspector"},uk={class:"spm-inspector-topbar"},fk={class:"spm-inspector-title"},pk={class:"slidev-icon",style:{fill:"none !important"},"aria-hidden":"true",viewBox:"0 0 24 24"},hk={class:"spm-inspector-topbar-actions"},mk={class:"spm-target-banner"},gk={class:"spm-target-info"},vk=["aria-label"],bk={key:0,class:"spm-save-status"},yk=["title"],kk={class:"spm-inspector-body"},wk=xt({__name:"SlidevInspectorDockView",setup(e,{expose:t}){const i=Rt("plugin"),n=fe(!1);function o(J){n.value=!1,c.value=J.docId,i!=null&&i.compileCurrentDocument&&i.compileCurrentDocument(J.docId)}const s=fe(""),l=fe(""),r=fe({}),a=fe(""),c=fe(""),d=fe(""),h=fe(""),v=fe(""),u=fe(""),m=fe(""),f=fe(""),b=fe(null),k=fe(""),x=fe("");function C(){var ge;const J=s.value||c.value;J&&typeof navigator<"u"&&(ge=navigator==null?void 0:navigator.clipboard)!=null&&ge.writeText&&navigator.clipboard.writeText(J).then(()=>{x.value="已复制！",setTimeout(()=>{x.value=""},1500)}).catch(()=>{})}const A=we(()=>nr(l.value)),D=we(()=>l.value==="NodeCodeBlock"),T=fe(!1),w=we(()=>{if(T.value||Ve.value)return!0;const J=a.value||"";return!!wi(J)}),R=we(()=>{const J=l.value||"";if(J==="NodeVideo"||J==="video")return!0;const ge=a.value||"";return!!(/<video\b/i.test(ge)||/\.mp4\b/i.test(ge))}),N=we(()=>!s.value||s.value===c.value||l.value==="doc"||l.value==="NodeDocument"),F=we(()=>{const J=s.value||c.value||"";return J.length>8?J.slice(-8):J||"无"}),q=we(()=>a.value?a.value.replace(/<[^>]+>/g,"").replace(/[\r\n]+/g," ").trim().slice(0,45):""),_=we(()=>{if(A.value)return"分页符 (---)";if(N.value)return"全局文档";if(R.value)return"视频块";let J="内容块";switch(l.value){case"NodeHeading":J="标题块";break;case"NodeParagraph":J="段落块";break;case"NodeCodeBlock":J="代码块";break;case"NodeVideo":J="视频块";break;case"NodeList":case"NodeListItem":J="列表项";break;case"NodeBlockquote":J="引述块";break;case"NodeTable":J="表格块";break;case"NodeSuperBlock":case"s":case"sb":J="超级块";break;default:J="内容块";break}return u.value?m.value?`${m.value.replace(/^col-(\d+)$/,"第 $1 栏")} › ${J}`:`分栏容器 › ${J}`:J}),L=we(()=>A.value?"tag-divider":N.value?"tag-doc":"tag-block"),y=we(()=>r.value[he]||"default"),M=we(()=>r.value[tt]||"slide-left"),H=fe(""),E=fe(""),O=we(()=>r.value[wn]||"inherit"),z=we(()=>{var J;return ik((J=b.value)==null?void 0:J.slides,{activeBlockId:s.value,activeBlockType:l.value,currentTopBlockId:d.value,currentPageDividerId:h.value,activeBlockAttrs:r.value})}),X=we(()=>{var J;return((J=z.value)==null?void 0:J.notes)||""}),Z=we(()=>{var J,ge,Te;return((Te=(ge=(J=z.value)==null?void 0:J.noteBlocks)==null?void 0:ge[0])==null?void 0:Te.id)||""}),W=we(()=>{var ze,Fe,Le,ut,Kn,ui;if(A.value){const Qe=r.value[he]||r.value["custom-slidev-layout"];if(Qe)return Qe}const J=r.value[Ce]||r.value["custom-slidev-slot"];if(J&&(["col-1","col-2","col-3"].includes(J)||/^col-\d+$/.test(J)))return"cols-header";if(v.value)return v.value;const ge=h.value||(A.value?s.value:"");if(ge){const Qe=Be.getBlockAttrOverride(ge);if(Qe!=null&&Qe[he])return Qe[he]}if(ge&&((ze=b.value)!=null&&ze.slides)){const Qe=b.value.slides.find(ji=>ji.startBlockId===ge);if((Fe=Qe==null?void 0:Qe.frontmatter)!=null&&Fe.layout)return Qe.frontmatter.layout}if((ut=(Le=z.value)==null?void 0:Le.frontmatter)!=null&&ut.layout)return z.value.frontmatter.layout;if((ui=(Kn=z.value)==null?void 0:Kn.blocks)!=null&&ui.some(Qe=>Qe.slot&&(["col-1","col-2","col-3"].includes(Qe.slot)||/^col-\d+$/.test(Qe.slot))))return"cols-header";const Te=Be.getBlockAttrOverride(c.value);return Te!=null&&Te[he]?Te[he]:"default"}),ie=ck({activeBlockId:s,activeBlockType:l,activeBlockAttrs:r,currentPageDividerId:h}),se=ie.resolvePageAttr({attrKey:yt,mode:"truthy",fallback:()=>{var J,ge;return((ge=(J=z.value)==null?void 0:J.frontmatter)==null?void 0:ge.layoutRatio)||""}}),re=ie.resolvePageAttr({attrKey:qi,fallback:()=>{var J,ge;return((ge=(J=z.value)==null?void 0:J.frontmatter)==null?void 0:ge.mask)||""}}),ue=ie.resolvePageAttr({attrKey:Zi,fallback:()=>{var J,ge;return((ge=(J=z.value)==null?void 0:J.frontmatter)==null?void 0:ge.maskRatio)||""}}),Ie=ie.resolvePageAttr({attrKey:Yi,fallback:()=>{var J,ge;return((ge=(J=z.value)==null?void 0:J.frontmatter)==null?void 0:ge.maskStyle)||"solid"}}),be=ie.resolvePageAttr({attrKey:Ji,fallback:()=>{var J,ge;return((ge=(J=z.value)==null?void 0:J.frontmatter)==null?void 0:ge.maskInitial)||"hidden"}});function ae(J){if(!J||(J.getAttribute("data-sb-layout")||"").toLowerCase()!=="col")return null;const Te=Array.from(J.querySelectorAll(":scope > [data-node-id]"));if(Te.length<2)return null;const ze=Te.length,Fe=Te.map(ui=>{const Qe=ui.getAttribute("style")||"",ji=Qe.match(/calc\(\s*([\d.]+)%/);if(ji)return parseFloat(ji[1]);const hn=Qe.match(/(?:^|;|\s)width:\s*([\d.]+)%/i);return hn?parseFloat(hn[1]):null});let Le="",ut=!1;if(Fe.some(ui=>ui!==null)){ut=!0;const ui=Fe.reduce((Ae,ft)=>Ae+(ft||0),0),Qe=Fe.filter(Ae=>Ae===null).length,ji=Qe>0?Math.max(0,100-ui)/Qe:100/Te.length,hn=Fe.map(Ae=>Ae!==null?Ae:ji),Ec=hn.reduce((Ae,ft)=>Ae+ft,0)||1,mn=hn.map(Ae=>Ae/Ec*100);if(mn.length===2){const[Ae]=mn;if(Ae>=48&&Ae<=52)Le="1:1";else if(Ae>=31&&Ae<=35)Le="1:2";else if(Ae>=65&&Ae<=69)Le="2:1";else if(Ae>=28&&Ae<=32)Le="3:7";else if(Ae>=68&&Ae<=72)Le="7:3";else if(Ae>=38&&Ae<=42)Le="4:6";else if(Ae>=58&&Ae<=62)Le="6:4";else{const ft=Math.round(Ae);Le=`${ft}:${100-ft}`}}else if(mn.length===3){const[Ae,ft,fi]=mn;if(Ae>=31&&Ae<=35&&ft>=31&&ft<=35&&fi>=31&&fi<=35)Le="1:1:1";else if(Ae>=23&&Ae<=27&&ft>=48&&ft<=52&&fi>=23&&fi<=27)Le="1:2:1";else if(Ae>=48&&Ae<=52&&ft>=23&&ft<=27&&fi>=23&&fi<=27)Le="2:1:1";else if(Ae>=23&&Ae<=27&&ft>=23&&ft<=27&&fi>=48&&fi<=52)Le="1:1:2";else{const lr=Math.round(Ae),ar=Math.round(ft);Le=`${lr}:${ar}:${100-lr-ar}`}}else Le=mn.map(Ae=>Math.round(Ae)).join(":")}else ut=!1,Le=Array.from({length:ze},()=>1).join(":");const Kn=ze>=2?"cols-header":"two-cols";return{hasSuperBlock:!0,colCount:ze,ratio:Le,isCustomWidth:ut,recommendedLayout:Kn}}function Y(J){if(!(J!=null&&J.blocks))return null;for(const ge of J.blocks){const Te=ge.rawNode;if(Te&&st(Te)&&Yt(Te)){const Fe=fn(Te).length,Le=Xs(Te);return{hasSuperBlock:!0,colCount:Fe,ratio:Le||Array.from({length:Fe},()=>1).join(":"),isCustomWidth:!!Le,recommendedLayout:Fe>=2?"cols-header":"two-cols"}}}return null}const ce=we(()=>{var J;if(typeof document<"u"){const ge=s.value;if(ge){const ze=document.querySelector(`.protyle-wysiwyg [data-node-id="${ge}"]`);if(ze){const Fe=ze.getAttribute("data-type")==="NodeSuperBlock"?ze:ze.closest('[data-type="NodeSuperBlock"]');if(Fe){const Le=ae(Fe);if(Le)return Le}}}const Te=h.value||(A.value?s.value:"");if(Te){const ze=document.querySelector(`.protyle-wysiwyg [data-node-id="${Te}"]`);if(ze){let Fe=ze.nextElementSibling;for(;Fe&&!(Fe.getAttribute("data-type")==="NodeThematicBreak"||(J=Fe.classList)!=null&&J.contains("protyle-wysiwyg__block--hr"));){const Le=Fe.getAttribute("data-type")==="NodeSuperBlock"?Fe:Fe.querySelector('[data-type="NodeSuperBlock"]');if(Le){const ut=ae(Le);if(ut)return ut}Fe=Fe.nextElementSibling}}}else{const ze=document.querySelector('.protyle-wysiwyg [data-type="NodeThematicBreak"], .protyle-wysiwyg .protyle-wysiwyg__block--hr'),Fe=Array.from(document.querySelectorAll('.protyle-wysiwyg [data-type="NodeSuperBlock"]'));for(const Le of Fe)if(!ze||Le.compareDocumentPosition(ze)&Node.DOCUMENT_POSITION_FOLLOWING){const ut=ae(Le);if(ut)return ut}}}return Y(z.value)}),P=we(()=>{var J;return((J=ce.value)==null?void 0:J.ratio)||""}),j=we(()=>{const J=l.value||"";if(J==="NodeSuperBlock"||J==="s"||J==="sb")return!0;if(typeof document<"u"&&s.value){const ge=document.querySelector(`.protyle-wysiwyg [data-node-id="${s.value}"]`);if(ge!=null&&ge.closest('[data-type="NodeSuperBlock"]'))return!0}return!1}),g=we(()=>{var J;return((J=z.value)==null?void 0:J.pageIndex)||1}),K=we(()=>!!(r.value[nt]||r.value["slidev-note"]));function B(){if(!u.value)return!1;if(s.value===u.value||typeof document>"u")return!0;const J=document.querySelector(`.protyle-wysiwyg [data-node-id="${u.value}"]`)||document.querySelector(`[data-node-id="${u.value}"]`);if(!J)return!1;const ge=J.querySelector(":scope > [data-node-id], :scope > div > [data-node-id]");return(ge==null?void 0:ge.getAttribute("data-node-id"))===s.value}const S=we(()=>{var ge;if(r.value[Ze]!==void 0)return r.value[Ze]||"";if(u.value&&B())return f.value||"";if(u.value)return"";const J=s.value;if(J&&((ge=z.value)!=null&&ge.blocks)){const Te=z.value.blocks.find(ze=>ze.id===J);if(Te!=null&&Te.clicks)return Te.clicks}return""}),I=we(()=>{var ge;if(r.value[qt])return r.value[qt];const J=s.value;if(J&&((ge=z.value)!=null&&ge.blocks)){const Te=z.value.blocks.find(ze=>ze.id===J);if(Te!=null&&Te.motion)return typeof Te.motion=="string"?Te.motion:JSON.stringify(Te.motion)}return""}),$=we(()=>{var ge;if(r.value[Ce])return r.value[Ce];const J=s.value;if(J&&((ge=z.value)!=null&&ge.blocks)){const Te=z.value.blocks.find(ze=>ze.id===J);if(Te!=null&&Te.slot)return Te.slot}return""}),U=fe(""),V=fe(""),G=we(()=>r.value[Bi]==="true"),ee=we(()=>r.value[po]==="true"),oe=we(()=>r.value[Vi]==="true"),ne=we(()=>r.value[ho]!=="false"),pe=we(()=>{var J,ge;return((ge=(J=b.value)==null?void 0:J.config)==null?void 0:ge.theme)||r.value[An]||"default"}),_e=we(()=>{var J,ge;return((ge=(J=b.value)==null?void 0:J.config)==null?void 0:ge.aspectRatio)||r.value[Bn]||"16/9"}),xe=we(()=>{var J,ge;return((ge=(J=b.value)==null?void 0:J.config)==null?void 0:ge.defaultTransition)||r.value[Mn]||"slide-left"}),Me=we(()=>{var J,ge;return((ge=(J=b.value)==null?void 0:J.config)==null?void 0:ge.spacing)||r.value[fs]||"normal"}),Ve=we(()=>{var Fe,Le;if((r.value[Ge]||r.value["slidev-role"])===cl||r.value[je]==="true")return"background";const ge=r.value[he]||r.value["slidev-layout"];if(ge==="image-left"||ge==="image-right")return ge;const Te=a.value||"",ze=wi(Te);if(ze&&((Le=(Fe=z.value)==null?void 0:Fe.frontmatter)!=null&&Le.background)){const ut=z.value.frontmatter.background;if(ut===ze||ut.endsWith(ze)||ze.endsWith(ut))return"background"}return""}),qe=we(()=>!!(r.value[Ze]||r.value[qt]||r.value[Ce]||r.value[Ni]||r.value[nt]||r.value["slidev-note"]||r.value[Ge]||r.value[he]||r.value[Bi]||r.value[po]||r.value[Vi]||r.value[ho])),{saveAttr:Je,savePageAttr:De,applyPageLayoutAndRatio:Jt,applyCloverLayout:rt,resetSuperBlockWidth:Xe,saveDocAttr:Ht,onToggleVideoAutoplay:Fi,onToggleVideoLoop:Uo,onToggleVideoMuted:Vo,onToggleVideoControls:Vn,onImageRoleChange:Si,onToggleNoteBlock:Hi,onAddNoteBlock:Ga,onLocateNoteBlock:qa,onGenerateNotesWithAI:Za,isBatchProcessing:Ya,onBatchAppendNotes:Ja,onBatchDeleteNotes:Xa,toggleElemClick:Qa,onElemClickStepChange:ec,onElemMotionChange:tc,onElemSlotChange:ic,onElemShikiLinesChange:nc,onElemMaxHeightChange:oc,onSetTwoColsContrast:sc,onClearBlockAttrs:rc,onInsertDividerBefore:lc,onInsertDividerAfter:or,onDeleteCurrentBlock:ac,onExportHtml:cc,onExportPdf:dc}=ak({activeBlockId:s,activeBlockType:l,activeBlockAttrs:r,rawSnippet:a,currentDocId:c,currentPageDividerId:h,currentPageDividerLayout:v,parentContainerId:u,parentContainerClicks:f,latestDoc:b,targetSlide:z,currentSlideNoteBlockId:Z,currentSlideLayout:W,isNoteBlock:K,elemClick:S,videoAutoplay:G,videoLoop:ee,videoMuted:oe,videoControls:ne,pageBackground:H,pageImage:E,elemShikiLines:U,elemMaxHeight:V,saveStatus:k,plugin:i});async function uc(J){if(J==="clover"){if(!await rt())return}else Je(he,J)}function fc(J){De(yt,J)}function pc(J){De(qi,J)}function hc(J){De(Zi,J)}function mc(J){De(Yi,J)}function gc(J){De(Ji,J)}function sr(J){if(!J)return;const ge=J.recommendedLayout||(J.colCount&&J.colCount>=2?"cols-header":"two-cols"),Te=J.ratio||(J.colCount?Array(J.colCount).fill(1).join(":"):"1:1");Jt(ge,Te)}function vc(J){De(yt,J)}async function bc(){await Xe()}function yc(J){Je(tt,J)}function kc(J){H.value=J,Je(je,J)}function wc(J){E.value=J,Je(Dt,J)}function xc(J){Je(wn,J==="inherit"?"":J)}function Sc(J){Ht(An,J)}function _c(J){Ht(Bn,J)}function Cc(J){Ht(Mn,J)}function $c(J){Ht(fs,J)}function rr(){i!=null&&i.openBottomPreviewTab&&i.openBottomPreviewTab()}function Ic(){i!=null&&i.openPresenterTab&&i.openPresenterTab()}function Tc(){i!=null&&i.executeCommand&&i.executeCommand("slidevAiSplit")}return t({setActiveBlock(J){s.value=J.id,l.value=J.type,r.value={...J.attrs},a.value=J.content||J.markdown||"",d.value=J.topBlockId||J.id,h.value=J.pageDividerId||"",v.value=J.pageDividerLayout||"",u.value=J.parentContainerId||"",m.value=J.parentContainerSlot||"",f.value=J.parentContainerClicks||"",J.rootId?c.value=J.rootId:(J.type==="doc"||J.type==="NodeDocument")&&J.id&&(c.value=J.id),H.value=J.attrs[je]||"",E.value=J.attrs[Dt]||"",U.value=J.attrs[Ni]||"",V.value=J.attrs[Dn]||"",T.value=!!J.isImage},updateDocument(J){b.value=J,c.value=J.docId},openImportDialog(){n.value=!0},setCurrentDocId(J){c.value=J}}),(J,ge)=>(Q(),te("div",dk,[p("div",uk,[p("div",fk,[(Q(),te("svg",pk,[...ge[2]||(ge[2]=[p("rect",{x:"2",y:"3",width:"20",height:"14",rx:"2"},null,-1),p("line",{x1:"8",y1:"21",x2:"16",y2:"21"},null,-1),p("line",{x1:"12",y1:"17",x2:"12",y2:"21"},null,-1)])])),ge[3]||(ge[3]=p("span",null,"演示配置",-1))]),p("div",hk,[p("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"导入 Slidev 演示文档 (.md / .zip)",onClick:ge[0]||(ge[0]=Te=>n.value=!0)},[le(de,{name:"import"}),ge[4]||(ge[4]=p("span",null,"导入",-1))]),p("button",{class:"spm-icon-btn is-primary b3-tooltips b3-tooltips__s","aria-label":"在下方分屏开启幻灯片预览 (Alt+P)",onClick:rr},[le(de,{name:"split-preview"}),ge[5]||(ge[5]=p("span",null,"分屏预览",-1))])])]),p("div",mk,[p("div",gk,[p("span",{class:Se(["spm-target-tag",L.value])},ye(_.value),3),p("span",{class:"spm-target-id b3-tooltips b3-tooltips__s","aria-label":x.value||"点击复制 ID: "+(s.value||c.value),onClick:C},[le(de,{name:"copy"}),p("span",null,"#"+ye(F.value),1)],8,vk)]),k.value?(Q(),te("span",bk,"● "+ye(k.value),1)):Oe("",!0)]),q.value?(Q(),te("div",{key:0,class:"spm-context-quote",title:a.value},ye(q.value),9,yk)):Oe("",!0),p("div",kk,[A.value?(Q(),Ot(Tb,{key:0,"page-layout":y.value,"page-layout-ratio":ve(se),"page-mask":ve(re),"page-mask-ratio":ve(ue),"page-mask-style":ve(Ie),"page-mask-initial":ve(be),"detected-sb-ratio":P.value,"detected-sb-info":ce.value,"page-transition":M.value,"page-background":H.value,"page-spacing":O.value,"page-image":E.value,"page-notes":X.value,"page-index":g.value,"onUpdate:pageLayout":uc,"onUpdate:pageLayoutRatio":fc,"onUpdate:pageMask":pc,"onUpdate:pageMaskRatio":hc,"onUpdate:pageMaskStyle":mc,"onUpdate:pageMaskInitial":gc,onApplySuperBlockLayout:sr,onResetSuperblockRatio:bc,"onUpdate:pageTransition":yc,"onUpdate:pageBackground":kc,"onUpdate:pageSpacing":xc,"onUpdate:pageImage":wc,onAddNoteBlock:ve(Ga),onLocateNoteBlock:ve(qa),onGenerateNotes:ve(Za),onBatchAppendNotes:ve(Ja),onBatchDeleteNotes:ve(Xa),"is-batch-processing":ve(Ya),onInsertDividerAfter:ve(or),onDeleteDivider:ve(ac)},null,8,["page-layout","page-layout-ratio","page-mask","page-mask-ratio","page-mask-style","page-mask-initial","detected-sb-ratio","detected-sb-info","page-transition","page-background","page-spacing","page-image","page-notes","page-index","onAddNoteBlock","onLocateNoteBlock","onGenerateNotes","onBatchAppendNotes","onBatchDeleteNotes","is-batch-processing","onInsertDividerAfter","onDeleteDivider"])):s.value&&!N.value?(Q(),Ot(fy,{key:1,"elem-click":S.value,"elem-motion":I.value,"elem-slot":$.value,"elem-shiki-lines":U.value,"elem-max-height":V.value,"is-code-block":D.value,"is-image":w.value,"is-video":R.value,"is-super-block":j.value,"detected-sb-info":ce.value,"video-autoplay":G.value,"video-loop":ee.value,"video-muted":oe.value,"video-controls":ne.value,"has-block-attrs":qe.value,"is-note":K.value,"image-role":Ve.value,"current-slide-layout":W.value,"parent-elem-click":f.value,"parent-container-slot":m.value,"parent-container-id":u.value,onToggleNote:ve(Hi),onToggleElemClick:ve(Qa),onToggleVideoAutoplay:ve(Fi),onToggleVideoLoop:ve(Uo),onToggleVideoMuted:ve(Vo),onToggleVideoControls:ve(Vn),"onUpdate:imageRole":ve(Si),"onUpdate:elemClick":ve(ec),"onUpdate:elemMotion":ve(tc),"onUpdate:elemSlot":ve(ic),"onUpdate:elemShikiLines":ve(nc),"onUpdate:elemMaxHeight":ve(oc),onApplySuperBlockLayout:sr,onApplySuperBlockRatio:vc,onInsertDividerBefore:ve(lc),onInsertDividerAfter:ve(or),onSetTwoColsContrast:ve(sc),onClearBlockAttrs:ve(rc)},null,8,["elem-click","elem-motion","elem-slot","elem-shiki-lines","elem-max-height","is-code-block","is-image","is-video","is-super-block","detected-sb-info","video-autoplay","video-loop","video-muted","video-controls","has-block-attrs","is-note","image-role","current-slide-layout","parent-elem-click","parent-container-slot","parent-container-id","onToggleNote","onToggleElemClick","onToggleVideoAutoplay","onToggleVideoLoop","onToggleVideoMuted","onToggleVideoControls","onUpdate:imageRole","onUpdate:elemClick","onUpdate:elemMotion","onUpdate:elemSlot","onUpdate:elemShikiLines","onUpdate:elemMaxHeight","onInsertDividerBefore","onInsertDividerAfter","onSetTwoColsContrast","onClearBlockAttrs"])):(Q(),Ot(Yy,{key:2,"doc-theme":pe.value,"doc-aspect-ratio":_e.value,"doc-default-transition":xe.value,"doc-spacing":Me.value,"onUpdate:docTheme":Sc,"onUpdate:docAspectRatio":_c,"onUpdate:docDefaultTransition":Cc,"onUpdate:docSpacing":$c,onOpenBottomPreview:rr,onOpenPresenter:Ic,onAiAutoSplit:Tc,onExportHtml:ve(cc),onExportPdf:ve(dc)},null,8,["doc-theme","doc-aspect-ratio","doc-default-transition","doc-spacing","onExportHtml","onExportPdf"]))]),n.value?(Q(),Ot(tk,{key:1,onClose:ge[1]||(ge[1]=Te=>n.value=!1),onSuccess:o})):Oe("",!0)]))}}),xk=2e3,Sk=600;function _k(e){return!e||typeof e.closest!="function"?!1:!!e.closest(".fn__none")}function as(e){if(!e||typeof e.isConnected=="boolean"&&!e.isConnected)return!1;if(Qr(e))return!0;const t=e.firstElementChild;return!!(t&&Qr(t))}function Qr(e){return typeof e.getClientRects=="function"&&e.getClientRects().length>0?!0:typeof e.offsetWidth=="number"&&e.offsetWidth>0&&e.offsetHeight>0}function Ck(){const e=typeof globalThis<"u"?globalThis.IntersectionObserver:void 0;return typeof e=="function"?e:void 0}class $k{constructor(){ke(this,"consumers",new Map);ke(this,"seq",0);ke(this,"verifyTimer",null)}register(t,i,n){if(!i)return()=>{};const o=++this.seq,s=Ck(),l={kind:t,element:i,visible:!1,measureOnDemand:!s,observer:null,onVisible:n};return s?(l.observer=new s(r=>{var d;const a=r[r.length-1];if(!a)return;const c=a.isIntersecting&&!l.visible;l.visible=a.isIntersecting,c&&((d=l.onVisible)==null||d.call(l))}),l.observer.observe(i)):l.visible=as(i),this.consumers.set(o,l),()=>{var r;(r=l.observer)==null||r.disconnect(),this.consumers.delete(o),this.consumers.size===0&&this.stopVerifyTimer()}}clear(){var t;for(const i of this.consumers.values())(t=i.observer)==null||t.disconnect();this.consumers.clear(),this.stopVerifyTimer()}get size(){return this.consumers.size}getVisibility(){if(this.consumers.size===0)return"none";if(typeof document<"u"&&document.visibilityState==="hidden")return"hidden";for(const t of this.consumers.values())if(t.measureOnDemand?as(t.element):this.isRecordVisible(t))return"visible";return this.ensureVerifyTimer(),"hidden"}hasVisibleConsumer(){return this.getVisibility()==="visible"}isRecordVisible(t){return t.visible?!0:!_k(t.element)}ensureVerifyTimer(){if(this.verifyTimer!==null||typeof setTimeout!="function")return;let t=!1;for(const i of this.consumers.values())if(!i.measureOnDemand){t=!0;break}t&&(this.verifyTimer=setTimeout(()=>{var i;this.verifyTimer=null;for(const n of this.consumers.values())if(!n.visible&&as(n.element)){n.visible=!0,(i=n.onVisible)==null||i.call(n);return}},xk))}stopVerifyTimer(){this.verifyTimer!==null&&(clearTimeout(this.verifyTimer),this.verifyTimer=null)}}const lo=new $k,pn=new Wo;function Ha(e,t,i){const n=()=>{var s;try{(s=i==null?void 0:i.flushDirtyCompile)==null||s.call(i)}catch{}},o=lo.register(e,t,n);return n(),o}let vi=null,At=null,ao=null;function Ik(){return At}function Tk(e,t){vi&&ja(),vi=Ys(Mg),vi.provide("plugin",t),vi.provide("sandboxBridge",pn);const i=vi.mount(e);return At=i,ao=Ha("preview",e,t),i}function ja(e){ao&&(ao(),ao=null),vi&&(vi.unmount(),vi=null,At=null)}function Ek(){return At!==null}let bi=null,Li=null;function Ak(e,t){return bi&&Wa(),bi=Ys(fv),bi.provide("plugin",t),bi.provide("sandboxBridge",pn),Li=bi.mount(e),Li}function Wa(e){bi&&(bi.unmount(),bi=null,Li=null)}function Bk(e){try{const t=new BroadcastChannel("siyuan-slidev-sync");t.postMessage({type:"SYNC_SLIDES",slides:JSON.parse(JSON.stringify(e.slides||[])),config:JSON.parse(JSON.stringify(e.config||{}))}),t.close()}catch{}}let yi=null,_t=null,co=null;function Mk(e,t){yi&&Ua(),yi=Ys(wk),yi.provide("plugin",t),yi.provide("sandboxBridge",pn);const i=yi.mount(e);return _t=i,co=Ha("dock",e,t),i}function Ua(e){co&&(co(),co=null),yi&&(yi.unmount(),yi=null,_t=null)}function Dk(e,t){_t!=null&&_t.updateDocument&&_t.updateDocument(e),At!=null&&At.updateDocument?At.updateDocument(e,t):(pn.updateSlides(e.slides,e.config,e.fullMarkdown),Bk(e)),Li!=null&&Li.updateDocument&&Li.updateDocument(e)}function As(e){At!=null&&At.navigateToBlock?At.navigateToBlock(e):pn.highlightElement(e)}function uo(e){_t!=null&&_t.setActiveBlock&&_t.setActiveBlock(e)}function Lk(){return _t!=null&&_t.openImportDialog?(_t.openImportDialog(),!0):!1}function Ok(e,t){const i=[];let o=0;for(let s=0;s<e.length;s++){const l=e[s];if(Io(l)){o=0;continue}const r=l.markdown||l.content||"";if(!(s===0)){if(l.type==="h"&&(l.subType==="h1"||r.startsWith("# "))){i.push({blockId:l.id,recommendedLayout:"cover",reason:"检测到一级核心章节标题，建议作为新幻灯片封面/大章"}),o=0;continue}if(l.type==="h"&&(l.subType==="h2"||r.startsWith("## "))){i.push({blockId:l.id,recommendedLayout:"default",reason:"检测到二级分论点标题，建议开启新页"}),o=0;continue}}if(o++,o>=6&&s<e.length-1){const c=e[s+1];Io(c)||(i.push({blockId:c.id,recommendedLayout:"default",reason:"当前页已达容量上限 (避免信息超载)，建议在此分页"}),o=0)}}return i}const Pk=[{id:"slidev-cover",name:"幻灯片 - 封面页 (Cover)",open:!0,attrs:[{key:Ai,value:"true"},{key:he,value:"cover"},{key:tt,value:"fade"}]},{id:"slidev-two-cols",name:"幻灯片 - 双栏对比 (Two Columns)",open:!0,attrs:[{key:Ai,value:"true"},{key:he,value:"two-cols"},{key:tt,value:"slide-left"}]},{id:"slidev-fact",name:"幻灯片 - 大字报与核心指标 (Fact)",open:!0,attrs:[{key:Ai,value:"true"},{key:he,value:"fact"},{key:tt,value:"zoom"}]},{id:"slidev-intro",name:"幻灯片 - 章节导引与作者 (Intro)",open:!0,attrs:[{key:Ai,value:"true"},{key:he,value:"intro"},{key:tt,value:"slide-up"}]},{id:"slidev-quote",name:"幻灯片 - 金句与强调 (Quote)",open:!0,attrs:[{key:Ai,value:"true"},{key:he,value:"quote"},{key:tt,value:"fade"}]},{id:"slidev-elem-click",name:"元素 - 顺延逐步呈现 (v-click)",open:!0,attrs:[{key:Ze,value:"+1"}]},{id:"slidev-elem-click-hide",name:"元素 - 隐藏直到激活 (v-click:hide)",open:!0,attrs:[{key:Ze,value:"hide"}]},{id:"slidev-elem-slot-right",name:"元素 - 双栏右栏归属 (Slot: Right)",open:!0,attrs:[{key:Ce,value:"right"}]},{id:"slidev-shiki-lines",name:"代码 - 逐行聚光高亮 (Shiki)",open:!0,attrs:[{key:Ni,value:"1-3"}]}];class cs{getPresetTemplates(){return Pk}buildScanSlidevBlocksSql(t="custom-slidev-"){return`SELECT block_id, name, value FROM attributes WHERE name LIKE '${t}%' ORDER BY block_id ASC`}buildTransitionStatsSql(){return`SELECT value, count(1) as count FROM attributes WHERE name = '${tt}' GROUP BY value ORDER BY count DESC`}async batchUpdateTransitions(t,i,n,o){const s=`SELECT block_id FROM attributes WHERE name = '${tt}' AND value = '${t}'`,l=await n(s);let r=0;if(Array.isArray(l))for(const a of l){const c=a.block_id||a.blockId;c&&(await o(c,{[tt]:i}),r++)}return{updatedCount:r}}async batchUpdateLayout(t,i,n,o){const s=`SELECT block_id FROM attributes WHERE name = 'custom-slidev-layout' AND value = '${t}'`,l=await n(s);let r=0;if(Array.isArray(l))for(const a of l){const c=a.block_id||a.blockId;c&&(await o(c,{"custom-slidev-layout":i}),r++)}return{updatedCount:r}}exportTemplatesJson(){const t=this.getPresetTemplates();return JSON.stringify({templates:t,counter:t.length},null,2)}formatTransitionSummary(t){return!t||t.length===0?"全库目前暂无已设置 Slidev 转场效果的块":`全库 Slidev 转场分布统计：${t.map(n=>`${n.value}: ${n.count} 个`).join("，")}`}}function Rk(e){e.addCommand({langKey:"slidevPresentation",langText:"Slidev: 在文档下方开启分屏演示预览",hotkey:"⌥P",enabled:()=>!0,execute:()=>{e.openBottomPreviewTab()}}),e.addCommand({langKey:"slidevImport",langText:"Slidev: 导入 Slidev 演示文档 (.md / .zip)",hotkey:"⌥I",enabled:()=>!0,execute:()=>{Lk()||me.showMessage("请先在右侧栏打开「Slidev 演示配置」Dock 面板以呼起导入窗口")}}),e.addCommand({langKey:"slidevInitAttrs",langText:"Slidev: 初始化当前文档演示属性",hotkey:"",enabled:()=>!0,execute:async()=>{if(!e.currentDocId){const t=document.querySelector(".protyle-content[data-doc-id]");e.currentDocId=(t==null?void 0:t.getAttribute("data-doc-id"))||""}e.currentDocId&&(await Ne(e.currentDocId,{"custom-slidev-theme":"default","custom-slidev-aspect-ratio":"16/9","custom-slidev-default-transition":"slide-left"}),me.showMessage("已为当前文档初始化 Slidev 演示属性"),e.compileCurrentDocument(e.currentDocId))}}),e.addCommand({langKey:"slidevAiSplit",langText:"Slidev AI: 智能大纲断页建议与自动分页",hotkey:"",enabled:()=>!0,execute:async()=>{if(!e.currentDocId){const s=document.querySelector(".protyle-content[data-doc-id]");e.currentDocId=(s==null?void 0:s.getAttribute("data-doc-id"))||""}if(!e.currentDocId){me.showMessage("请先打开一篇思源笔记文档");return}const t=await fo(e.currentDocId).catch(()=>[]);if(!t||t.length===0){me.showMessage("当前文档无内容，无需断页");return}const i=t.map(s=>({id:s.id,type:s.type,subType:s.subType,content:s.content||"",markdown:s.markdown||""})),n=Ok(i);if(n.length===0){me.showMessage("AI 分析完毕：当前文档篇幅合理，暂无分页建议");return}me.showMessage(`AI 分析完毕：发现 ${n.length} 处建议分页点，正在自动插入分页分割线...`);let o=0;for(const s of n)try{await Mi("markdown","---",void 0,s.blockId),await Ne(s.blockId,{"custom-slidev-layout":s.recommendedLayout}),o++}catch(l){console.warn("Failed to insert divider:",l)}me.showMessage(`已成功在 ${o} 处插入分页线并重新编译`),e.compileCurrentDocument(e.currentDocId)}}),e.addCommand({langKey:"slidevAiNotes",langText:"Slidev AI: 自动为当前文档生成演讲者提词卡 (Notes)",hotkey:"",enabled:()=>!0,execute:async()=>{var a,c,d,h;if(!e.currentDocId){const v=document.querySelector(".protyle-content[data-doc-id]");e.currentDocId=(v==null?void 0:v.getAttribute("data-doc-id"))||""}if(!e.currentDocId){me.showMessage("请先打开一篇思源笔记文档");return}me.showMessage("正在调用思源 AI 提炼演讲者口播提词...");const t=await fo(e.currentDocId).catch(()=>[]),i={startBlockId:e.currentDocId,blocks:t.map(v=>({id:v.id,type:v.type,content:v.content||"",rawMarkdown:v.markdown||""})),rawMarkdown:""},s=`> [!NOTE] 💡 演讲备注
${(await sk(i,sl)).split(/\r?\n/).map(v=>`> ${v}`).join(`
`)}
{: custom-slidev-note="true"}`,l=await ds("markdown",s,e.currentDocId).catch(()=>null),r=((d=(c=(a=l==null?void 0:l[0])==null?void 0:a.doOperations)==null?void 0:c[0])==null?void 0:d.id)||((h=l==null?void 0:l[0])==null?void 0:h.id);r&&(await Ne(r,{"custom-slidev-note":"true"}),Be.setBlockAttrOverride(r,{"custom-slidev-note":"true"}),Ri(r,e.app)),me.showMessage("已成功生成口播提词卡并插入为正文讲稿备注块"),e.compileCurrentDocument(e.currentDocId)}}),e.addCommand({langKey:"slidevBatchTransitions",langText:"Slidev 协同: 统计全库转场效果分布",hotkey:"",enabled:()=>!0,execute:async()=>{const t=new cs,i=t.buildTransitionStatsSql(),n=await on(i).catch(()=>[]),o=t.formatTransitionSummary(n||[]);me.showMessage(o)}}),e.addCommand({langKey:"slidevExportTemplates",langText:"Slidev 协同: 复制 Slidev 预设属性模板至剪贴板",hotkey:"",enabled:()=>!0,execute:async()=>{const i=new cs().exportTemplatesJson();typeof navigator<"u"&&navigator.clipboard?(await navigator.clipboard.writeText(i),me.showMessage("已将 Slidev 属性模板 JSON 复制至剪贴板，可直接导入属性管家")):me.showMessage(`已生成模板数据（请在控制台查看）：
`+i)}}),e.addCommand({langKey:"slidevBatchReplaceTransition",langText:"Slidev 协同: 批量替换全库淡入淡出转场为滑动 (fade -> slide-left)",hotkey:"",enabled:()=>!0,execute:async()=>{const i=await new cs().batchUpdateTransitions("fade","slide-left",n=>on(n).catch(()=>[]),(n,o)=>Ne(n,o));me.showMessage(`全库批量替换完成：已将 ${i.updatedCount} 处 fade 转场更新为 slide-left`),e.compileCurrentDocument()}}),e.addCommand({langKey:"slidevPresenterMode",langText:"Slidev: 打开双屏演讲者控制台 (Presenter Mode)",hotkey:"⌥M",enabled:()=>!0,execute:()=>{e.openPresenterTab()}}),e.addCommand({langKey:"slidevExportCliMd",langText:"Slidev Pro: 导出 Slidev 标准 slides.md 文档 (下载到本地)",hotkey:"",enabled:()=>!0,execute:async()=>{if(e.latestCompiledDoc||await e.compileCurrentDocument(),!e.latestCompiledDoc){me.showMessage("请先打开并放映一篇思源笔记文档");return}e.cliBridge.downloadSlidesMd(e.latestCompiledDoc,`slides-${e.currentDocId||"demo"}.md`)&&me.showMessage("已生成标准 Slidev Markdown 并触发下载，可在本地使用 npx @slidev/cli 运行")}}),e.addCommand({langKey:"slidevProbeCliDevServer",langText:"Slidev Pro: 检测本地 Slidev CLI DevServer 状态 (localhost:3030)",hotkey:"",enabled:()=>!0,execute:async()=>{me.showMessage("正在探测本地 Slidev CLI DevServer (http://localhost:3030)..."),await e.cliBridge.probeServer(1500)?me.showMessage("🟢 本地 Slidev CLI DevServer 运行正常！可直接在浏览器访问 http://localhost:3030"):me.showMessage("⚪ 未检测到运行中的本地 Slidev CLI DevServer (端口 3030 未开启)")}}),e.addCommand({langKey:"slidevSyncToCliWorkspace",langText:"Slidev Pro: 同步 slides.md 至思源工作空间存储目录",hotkey:"",enabled:()=>!0,execute:async()=>{if(e.latestCompiledDoc||await e.compileCurrentDocument(),!e.latestCompiledDoc){me.showMessage("请先打开并放映一篇思源笔记文档");return}const t=await e.cliBridge.syncToWorkspaceFile(e.latestCompiledDoc,"/data/storage/petal/siyuan-slidev/slides.md",us);t.success?me.showMessage(`已成功同步最新 slides.md 至工作空间：${t.path}`):me.showMessage(`同步失败：${t.error}`)}})}function Va(e){const t=(e||"").trim();return t?`即现（${t}）`:"即现"}async function Ka(e,t){var i,n,o;if(!t)return"";if(typeof document<"u"){const s=document.querySelector(`.protyle-title[data-node-id="${t}"] .protyle-title__input`)||document.querySelector(`.protyle[data-doc-id="${t}"] .protyle-title__input`)||(e.getActiveDocumentId()===t?document.querySelector(".layout__wnd--active .protyle-title__input"):null)||document.querySelector(".protyle-title__input"),l=((s==null?void 0:s.innerText)||(s==null?void 0:s.textContent)||"").trim();if(l)return l}if(e.latestCompiledDoc&&e.latestCompiledDoc.docId===t){const s=(i=e.latestCompiledDoc.slides)==null?void 0:i[0],l=(n=s==null?void 0:s.blocks)==null?void 0:n.find(r=>r.type==="h"||r.type==="NodeHeading");if(l!=null&&l.content)return l.content.trim()}try{const s=await on(`SELECT content FROM blocks WHERE id = '${t}' AND type = 'd' LIMIT 1`).catch(()=>[]);if(Array.isArray(s)&&s.length>0&&((o=s[0])!=null&&o.content))return String(s[0].content).trim()}catch{}return""}async function Nk(e,t,i){var c,d,h;const n=Ik(),o=!!((c=n==null?void 0:n.isPinned)!=null&&c.value),s=String(((d=n==null?void 0:n.pinnedDocId)==null?void 0:d.value)||"");if(o&&s&&i&&i!==s)return;const l=i||(o&&s?s:e.currentDocId||e.getActiveDocumentId());let r=(t||"").trim();!r&&l&&(r=typeof e.fetchDocumentTitle=="function"?await e.fetchDocumentTitle(l):await Ka(e,l));const a=Va(r);if(e.previewTab&&typeof e.previewTab.updateTitle=="function"){e.previewTab.updateTitle(a),e.previewTab.headElement&&e.previewTab.headElement.setAttribute("title",a);return}if(typeof document<"u"){const v=Array.from(document.querySelectorAll('.layout-tab-bar .item[data-type="tab-header"]'));for(const u of v){const m=u.querySelector(".item__text"),f=((h=m==null?void 0:m.textContent)==null?void 0:h.trim())||"";if(f.includes("Slidev 演示预览")||f.startsWith("即现")){m&&(m.textContent=a),u.setAttribute("title",a);break}}}}class zk{constructor(t=400){ke(this,"entries",new Map);this.ttlMs=t}get(t,i=Date.now()){if(!t)return;const n=this.entries.get(t);if(n){if(i-n.at>this.ttlMs){this.entries.delete(t);return}return n.attrs}}set(t,i,n=Date.now()){!t||!i||this.entries.set(t,{attrs:i,at:n})}invalidate(t){t?this.entries.delete(t):this.entries.clear()}get size(){return this.entries.size}}function Fk(e){const t=new Map;if(!(e!=null&&e.slides))return t;const i=n=>{for(const o of n||[])o!=null&&o.id&&o.ial&&t.set(o.id,o.ial)};for(const n of e.slides)i(n.blocks),i(n.noteBlocks);return t}class Hk{constructor(t=150){ke(this,"lastBlockId","");ke(this,"lastAt",0);this.windowMs=t}shouldSkip(t,i=Date.now()){return t&&t===this.lastBlockId&&i-this.lastAt<this.windowMs?!0:(this.lastBlockId=t,this.lastAt=i,!1)}reset(){this.lastBlockId="",this.lastAt=0}}class jk{constructor(){ke(this,"attrCache",new zk);ke(this,"compiledIalIndex",{doc:null,map:new Map})}async resolveBlockAttrs(t,i){if(!t)return{};const n=Be.getBlockAttrOverride(t),o=this.getCompiledIal(i,t);if(n||o)return{...o||{},...n||{}};const s=this.attrCache.get(t);if(s)return s;const l=await Bs(t).catch(()=>({}))||{};return this.attrCache.set(t,l),l}getCompiledIal(t,i){if(t)return this.compiledIalIndex.doc!==t&&(this.compiledIalIndex={doc:t,map:Fk(t)}),this.compiledIalIndex.map.get(i)}invalidateAttrCache(t){this.attrCache.invalidate(t)}getActiveDocumentId(){if(typeof document>"u")return"";const t=document.querySelector(".layout__wnd--active .protyle-title[data-node-id]")||document.querySelector(".item--focus .protyle-title[data-node-id]")||document.querySelector(".protyle-title[data-node-id]"),i=t==null?void 0:t.getAttribute("data-node-id");if(i)return i;const n=document.querySelector(".protyle .protyle-title[data-node-id]"),o=n==null?void 0:n.getAttribute("data-node-id");if(o)return o;const s=document.querySelector("[data-doc-id]"),l=s==null?void 0:s.getAttribute("data-doc-id");return l||""}resolveDocIdFromElement(t,i=""){const n=t.closest(".protyle-title"),o=n==null?void 0:n.getAttribute("data-node-id");if(o)return o;const s=t.closest(".protyle"),l=s==null?void 0:s.querySelector(".protyle-title"),r=l==null?void 0:l.getAttribute("data-node-id");if(r)return r;const a=t.closest("[data-doc-id]"),c=a==null?void 0:a.getAttribute("data-doc-id");if(c)return c;const d=this.getActiveDocumentId();return d||i}async switchToDocGlobalInspector(t,i){var s;if(!t)return;let n=i||"";if(!n&&typeof document<"u"){const l=document.querySelector(`.protyle-title[data-node-id="${t}"] .protyle-title__input`)||document.querySelector(`.protyle[data-doc-id="${t}"] .protyle-title__input`)||document.querySelector(".protyle-title__input");n=((s=l==null?void 0:l.innerText)==null?void 0:s.trim())||""}const o=await this.resolveBlockAttrs(t,null);uo({id:t,rootId:t,type:"doc",content:n,attrs:o,isDivider:!1,isCode:!1}),As(t)}handleBlockClickedFromSlide(t,i,n,o){var a;if(!t)return!1;const s=Ri(t,i),l=document.querySelector(`.protyle-wysiwyg [data-node-id="${t}"]`)||document.querySelector(`[data-node-id="${t}"]`),r=(l==null?void 0:l.getAttribute("data-type"))||"";if(l)this.syncInspectorBlock(l,t,r,n,o);else{let c="",d="";if(o!=null&&o.slides){const h=o.slides.find(v=>{var u,m,f;return v.startBlockId===t||((u=v.blocks)==null?void 0:u.some(b=>b.id===t))||((m=v.allBlockIds)==null?void 0:m.includes(t))||((f=v.noteBlocks)==null?void 0:f.some(b=>b.id===t))});h!=null&&h.startBlockId&&(c=h.startBlockId),(a=h==null?void 0:h.frontmatter)!=null&&a.layout&&(d=h.frontmatter.layout)}this.resolveBlockAttrs(t,o).then(async h=>{if(c&&!d){const v=Be.getBlockAttrOverride(c);if(v!=null&&v[he]||v!=null&&v["custom-slidev-layout"])d=v[he]||v["custom-slidev-layout"]||"";else{const u=await this.resolveBlockAttrs(c,o);d=u[he]||u["custom-slidev-layout"]||"",u&&Object.keys(u).length>0&&Be.setBlockAttrOverride(c,u)}}uo({id:t,rootId:n,type:r||"NodeParagraph",attrs:h||{},pageDividerId:c,pageDividerLayout:d})}).catch(()=>{})}return s}async syncInspectorBlock(t,i,n,o,s){var M,H,E,O,z,X,Z,W;let l=t,r=i,a=n;const c=t.closest('[data-type="NodeCallout"]');if(c&&c!==t){const ie=c.getAttribute("data-node-id");if(ie){const se=await this.resolveBlockAttrs(ie,s),re=Be.getBlockAttrOverride(ie)||{},ue={...se,...re};(ue[nt]||ue["slidev-note"])&&(l=c,r=ie,a="NodeCallout")}}const d=l.closest(".protyle-wysiwyg > [data-node-id]")||l,h=(d==null?void 0:d.getAttribute("data-node-id"))||r,v=a==="NodeThematicBreak"||a==="tb"||a==="thematic-break"||(d==null?void 0:d.getAttribute("data-type"))==="NodeThematicBreak"||(d==null?void 0:d.getAttribute("data-type"))==="tb"||!!((M=d==null?void 0:d.classList)!=null&&M.contains("hr")),u=a==="NodeCodeBlock",m=((H=l.innerText)==null?void 0:H.trim())||"",f=await this.resolveBlockAttrs(r,s),b=Be.getBlockAttrOverride(r)||{},k={...f,...b};let x="",C="";if(v)x=r,C=k[he]||k["custom-slidev-layout"]||"";else{let ie=d.previousElementSibling;for(;ie;){const se=ie.getAttribute("data-type");if(se==="NodeThematicBreak"||se==="tb"||(E=ie.classList)!=null&&E.contains("hr")){x=ie.getAttribute("data-node-id")||"";break}ie=ie.previousElementSibling}}if(s!=null&&s.slides){const ie=[r,h];let se=l.parentElement;for(;se&&!se.classList.contains("protyle-wysiwyg");){const ue=se.getAttribute("data-node-id");ue&&!ie.includes(ue)&&ie.push(ue),se=se.parentElement}const re=s.slides.find(ue=>{var Ie,be,ae;return ie.includes(ue.startBlockId)||((Ie=ue.blocks)==null?void 0:Ie.some(Y=>ie.includes(Y.id)))||((be=ue.allBlockIds)==null?void 0:be.some(Y=>ie.includes(Y)))||((ae=ue.noteBlocks)==null?void 0:ae.some(Y=>ie.includes(Y.id)))});re&&(!x&&re.startBlockId&&(x=re.startBlockId),!C&&((O=re.frontmatter)!=null&&O.layout)&&(C=re.frontmatter.layout))}if(x){const ie=Be.getBlockAttrOverride(x);if(ie&&(he in ie||"custom-slidev-layout"in ie)&&(C=ie[he]||ie["custom-slidev-layout"]||""),!C&&(s!=null&&s.slides)){const se=s.slides.find(re=>re.startBlockId===x);(z=se==null?void 0:se.frontmatter)!=null&&z.layout&&(C=se.frontmatter.layout)}if(!C){const se=await this.resolveBlockAttrs(x,s);C=se[he]||se["custom-slidev-layout"]||"",se&&Object.keys(se).length>0&&Be.setBlockAttrOverride(x,se)}et(x,{[he]:C||""})}else if(o){const ie=Be.getBlockAttrOverride(o);ie&&(he in ie||"custom-slidev-layout"in ie)?C=ie[he]||ie["custom-slidev-layout"]||"":!C&&((W=(Z=(X=s==null?void 0:s.slides)==null?void 0:X[0])==null?void 0:Z.frontmatter)!=null&&W.layout)&&(C=s.slides[0].frontmatter.layout)}const A=l.getAttribute(he)||l.getAttribute("custom-slidev-layout"),D=k[he]||k["custom-slidev-layout"]||"";A&&A!==D&&et(r,{[he]:D});const T=l.getAttribute(Ge)||l.getAttribute("custom-slidev-role"),w=k[Ge]||k["custom-slidev-role"]||"";T&&T!==w&&et(r,{[Ge]:w});let R="",N="",F="";const q=l.closest('[data-type="NodeListItem"]');if(q&&q!==l){const ie=q.getAttribute("data-node-id");if(ie){R=ie;const se=await this.resolveBlockAttrs(ie,s),re=Be.getBlockAttrOverride(ie)||{},ue={...se,...re};N=ue[Ce]||"",F=ue[Ze]||"";const Ie=ue[he]||ue["custom-slidev-layout"]||"",be=q.getAttribute(he)||q.getAttribute("custom-slidev-layout");be&&be!==Ie&&et(ie,{[he]:Ie});const ae=ue[Ge]||ue["custom-slidev-role"]||"",Y=q.getAttribute(Ge)||q.getAttribute("custom-slidev-role");Y&&Y!==ae&&et(ie,{[Ge]:ae})}}const _=!!l.querySelector("img, span[data-type='img']"),L=(l.innerText||"").replace(/[\r\n\t\s]+/g," ").trim(),y=_&&L.length<=50;uo({id:r,rootId:o,type:a,content:m,attrs:k,isDivider:v,isCode:u,isImage:y,topBlockId:h,pageDividerId:x,pageDividerLayout:C,parentContainerId:R,parentContainerSlot:N,parentContainerClicks:F})}patchThematicBreakTransactions(t){if((t==null?void 0:t.cmd)==="transactions"&&Array.isArray(t.data)){for(const i of t.data)if(Array.isArray(i==null?void 0:i.doOperations)){for(const n of i.doOperations)if((n==null?void 0:n.action)==="updateAttrs"&&n.id&&n.data){const o=n.data.old||{},s=n.data.new||{},l={};for(const r of Object.keys(o))r in s||(l[r]="");for(const[r,a]of Object.entries(s))l[r]=String(a??"");et(n.id,l),Be.setBlockAttrOverride(n.id,l)}}}}purgeStaleDomSlidevAttrs(t){var o,s,l;if(typeof document>"u"||!t)return;const i=new Map;if(Array.isArray(t.slides))for(const r of t.slides){if(r.startBlockId){const a=i.get(r.startBlockId)||{};(o=r.frontmatter)!=null&&o.layout&&(a[he]=r.frontmatter.layout),i.set(r.startBlockId,a)}if(Array.isArray(r.blocks)){for(const a of r.blocks)if(a.id){const c=i.get(a.id)||{};(s=a.ial)!=null&&s[he]&&(c[he]=a.ial[he]),(l=a.ial)!=null&&l[Ge]&&(c[Ge]=a.ial[Ge]),Object.keys(c).length>0&&i.set(a.id,c)}}}const n=Be.getAllAttrOverrides();for(const[r,a]of n.entries()){const c=i.get(r)||{};a[he]!==void 0&&(c[he]=a[he]),a[Ge]!==void 0&&(c[Ge]=a[Ge]),i.set(r,c)}gh(i)}}const Ti=new jk;class Wk{constructor(){ke(this,"inFlightDocId",null);ke(this,"pendingDocId",null);ke(this,"generation",0)}get isRunning(){return this.inFlightDocId!==null}get runningDocId(){return this.inFlightDocId}get pending(){return this.pendingDocId}tryBegin(t){return this.inFlightDocId!==null?(this.pendingDocId=t,null):(this.inFlightDocId=t,++this.generation)}isStale(t){return t!==this.generation}finish(){this.inFlightDocId=null;const t=this.pendingDocId;return this.pendingDocId=null,t}reset(){this.inFlightDocId=null,this.pendingDocId=null,this.generation=0}}const Uk=150,Vk=`<symbol id="iconSlidev" viewBox="0 0 1024 1024">
  <path fill="currentColor" d="M128 160h768c35.3 0 64 28.7 64 64v480c0 35.3-28.7 64-64 64H128c-35.3 0-64-28.7-64-64V224c0-35.3 28.7-64 64-64z m64 64v480h640V224H192z m128 640h384v64H320z"/>
  <path fill="currentColor" d="M416 336l256 144-256 144z"/>
</symbol>`,Kk="slidev-dock",el="slidev-preview-tab",tl="slidev-presenter-tab",il=yf;class Gk extends me.Plugin{constructor(){super(...arguments);ke(this,"isMobile",!1);ke(this,"currentDocId","");ke(this,"previewTab",null);ke(this,"latestCompiledDoc",null);ke(this,"cliBridge",new Qs);ke(this,"debounceTimer",null);ke(this,"activeCursorBlockId","");ke(this,"compileScheduler",new Wk);ke(this,"dirtyDocId",null);ke(this,"inspectorSyncThrottle",new Hk);ke(this,"onSwitchProtyleBound",this.onSwitchProtyle.bind(this));ke(this,"onWsMainBound",this.onWsMain.bind(this));ke(this,"onBlockClickedBound",this.onBlockClickedFromSlide.bind(this));ke(this,"onEditorClickBound",this.onEditorClick.bind(this));ke(this,"onSelectionChangeBound",this.onSelectionChange.bind(this));ke(this,"onClickEditorContentBound",this.onClickEditorContent.bind(this));ke(this,"onVisibilityChangeBound",this.onVisibilityChange.bind(this))}async onload(){const i=me.getFrontend();this.isMobile=i==="mobile"||i==="browser-mobile",await this.loadGlobalSettings(),this.addIcons(Vk),this.addTopBar({id:"slidev-topbar-play",icon:"iconSlidev",title:"即现演示",position:"right",callback:()=>{this.openBottomPreviewTab()}}),Rk(this);const n=this;if(this.addTab({type:el,init(o){var r;const s=this||o;n.previewTab=(s==null?void 0:s.tab)||null,Tk(s.element,n);const l=(r=s==null?void 0:s.data)==null?void 0:r.docId;l&&!n.getActiveDocumentId()&&n.compileCurrentDocument(l,{reason:"explicit"}),n.updatePreviewTabHeader()},destroy(){n.previewTab===(this==null?void 0:this.tab)&&(n.previewTab=null),ja(this.element)}}),this.addTab({type:tl,init(o){Ak((this||o).element,n)},destroy(){Wa(this.element)}}),this.addDock({config:{position:"RightTop",size:{width:320,height:0},icon:"iconSlidev",title:"Slidev 演示配置"},data:{},type:Kk,init(){Mk(this.element,n)},destroy(){Ua(this.element)}}),this.eventBus&&typeof this.eventBus.emit!="function"&&(this.eventBus.emit=(o,s)=>{try{typeof window<"u"&&window.dispatchEvent(new CustomEvent(`siyuan-event-${o}`,{detail:s}))}catch{}}),this.eventBus.on("switch-protyle",this.onSwitchProtyleBound),this.eventBus.on("ws-main",this.onWsMainBound),this.eventBus.on("slidev:request-compile",()=>this.compileCurrentDocument()),this.eventBus.on("slidev:block-clicked",this.onBlockClickedBound),this.eventBus.on("click-editorcontent",this.onClickEditorContentBound),typeof document<"u"&&(document.addEventListener("click",this.onEditorClickBound,!0),document.addEventListener("selectionchange",this.onSelectionChangeBound),document.addEventListener("visibilitychange",this.onVisibilityChangeBound)),typeof document<"u"){const o=()=>{const s=this.getActiveDocumentId();s&&(s!==this.currentDocId&&(this.currentDocId=s,this.updatePreviewTabHeader("",s)),this.latestCompiledDoc||this.markCompileDirty(s))};setTimeout(o,300),setTimeout(o,1e3)}}async onDataChanged(i){await this.loadGlobalSettings(),this.currentDocId&&this.markCompileDirty(this.currentDocId)}async loadGlobalSettings(){try{const i=await this.loadData(il),n=kf(i);return Di(n),n}catch{return Di(an),an}}async saveGlobalSettings(i){const n=jo(),o=Di({...n,...i||{}});try{await this.saveData(il,o)}catch(l){console.error("保存 Slidev 全局配置失败",l)}const s=this.currentDocId||this.getActiveDocumentId();return s&&this.markCompileDirty(s),o}onunload(){this.debounceTimer&&(window.clearTimeout(this.debounceTimer),this.debounceTimer=null),this.compileScheduler.reset(),this.inspectorSyncThrottle.reset(),this.dirtyDocId=null,lo.clear(),this.eventBus.off("switch-protyle",this.onSwitchProtyleBound),this.eventBus.off("ws-main",this.onWsMainBound),this.eventBus.off("click-editorcontent",this.onClickEditorContentBound),typeof document<"u"&&(document.removeEventListener("click",this.onEditorClickBound,!0),document.removeEventListener("selectionchange",this.onSelectionChangeBound),document.removeEventListener("visibilitychange",this.onVisibilityChangeBound)),pn.detach()}onVisibilityChange(){typeof document<"u"&&document.visibilityState==="visible"&&this.flushDirtyCompile()}async openBottomPreviewTab(){this.currentDocId||(this.currentDocId=this.getActiveDocumentId());const i=this.currentDocId?await this.fetchDocumentTitle(this.currentDocId):"",n=this.buildPreviewTabTitle(i);await me.openTab({app:this.app,custom:{id:this.name+el,title:n,icon:"iconSlidev",data:{docId:this.currentDocId}},position:"bottom"}),this.currentDocId&&this.compileCurrentDocument(this.currentDocId),this.updatePreviewTabHeader(i,this.currentDocId)}async openPresenterTab(){Ek()||await this.openBottomPreviewTab(),await me.openTab({app:this.app,custom:{id:this.name+tl,title:"演讲者控制台",icon:"iconSlidev",data:{}},position:"right"})}async onSwitchProtyle(i){var l,r,a,c,d;const n=(l=i.detail)==null?void 0:l.protyle,o=(r=n==null?void 0:n.block)==null?void 0:r.rootID,s=((d=(c=(a=n==null?void 0:n.title)==null?void 0:a.editElement)==null?void 0:c.textContent)==null?void 0:d.trim())||"";if(o&&o!==this.currentDocId){this.currentDocId=o,this.activeCursorBlockId=o;const h=await Bs(o).catch(()=>({}));uo({id:o,rootId:o,type:"doc",attrs:h}),this.markCompileDirty(o),this.updatePreviewTabHeader(s,o)}}onClickEditorContent(i){var s,l;const n=i==null?void 0:i.detail;if(!n)return;const o=(l=(s=n.protyle)==null?void 0:s.block)==null?void 0:l.rootID;o&&(!this.currentDocId||this.currentDocId!==o)&&(this.currentDocId=o),n.event&&this.onEditorClick(n.event)}buildPreviewTabTitle(i){return Va(i)}async fetchDocumentTitle(i){return Ka(this,i)}async updatePreviewTabHeader(i,n){return Nk(this,i,n)}getActiveDocumentId(){return Ti.getActiveDocumentId()}resolveDocIdFromElement(i){return Ti.resolveDocIdFromElement(i,this.currentDocId)}async switchToDocGlobalInspector(i,n){i&&(this.activeCursorBlockId=i,this.currentDocId=i,await Ti.switchToDocGlobalInspector(i,n))}onWsMain(i){const n=i.detail;n&&n.cmd==="transactions"&&(Ti.patchThematicBreakTransactions(n),this.markCompileDirty())}markCompileDirty(i){const n=i||this.currentDocId||this.getActiveDocumentId();n&&(this.currentDocId||(this.currentDocId=n),this.dirtyDocId=n,this.scheduleDirtyCompile())}scheduleDirtyCompile(i=Uk){if(this.debounceTimer&&(window.clearTimeout(this.debounceTimer),this.debounceTimer=null),!this.dirtyDocId)return;const n=lo.getVisibility();if(n==="none")return;const o=n==="visible"?i:Math.max(i,Sk);this.debounceTimer=window.setTimeout(()=>{this.debounceTimer=null;const s=this.dirtyDocId;this.dirtyDocId=null,s&&this.compileCurrentDocument(s,{reason:"auto"})},o)}flushDirtyCompile(){this.dirtyDocId&&this.scheduleDirtyCompile(0)}handleBlockClickedFromSlide(i,n){return i?(this.activeCursorBlockId=i,Ti.handleBlockClickedFromSlide(i,this.app,this.currentDocId,this.latestCompiledDoc)):!1}onBlockClickedFromSlide(i){const n=(i==null?void 0:i.detail)||i;n!=null&&n.blockId&&this.handleBlockClickedFromSlide(n.blockId,n.page)}onEditorClick(i){const n=i.target;if(!n)return;const o=n.closest(".protyle-title")||n.closest(".protyle-background");if(!!(o||n.closest(".protyle-content")&&!n.closest(".protyle-wysiwyg")&&!n.closest(".protyle-breadcrumb")&&!n.closest(".protyle-gutters"))){const d=this.resolveDocIdFromElement(n);if(d&&this.activeCursorBlockId!==d){const h=o||document.querySelector(`.protyle-title[data-node-id="${d}"]`)||document.querySelector(`.protyle[data-doc-id="${d}"] .protyle-title`),v=h==null?void 0:h.querySelector(".protyle-title__input"),u=((v==null?void 0:v.innerText)||(h==null?void 0:h.innerText)||"").trim();this.switchToDocGlobalInspector(d,u)}return}if(!n.closest(".protyle-wysiwyg"))return;const r=n.closest("[data-node-id]");if(!r)return;const a=r.getAttribute("data-node-id"),c=r.getAttribute("data-type")||"";a&&(this.currentDocId||(this.currentDocId=this.resolveDocIdFromElement(n)||""),this.currentDocId&&!this.latestCompiledDoc&&this.markCompileDirty(this.currentDocId),a!==this.activeCursorBlockId&&(this.activeCursorBlockId=a,As(a)),this.syncInspectorBlock(r,a,c))}onSelectionChange(){if(typeof window>"u")return;const i=window.getSelection();if(!i||i.rangeCount===0)return;const n=i.anchorNode;if(!n)return;const o=n.nodeType===Node.ELEMENT_NODE?n:n.parentElement;if(!o)return;const s=o.closest(".protyle-title");if(!!(s||o.closest(".protyle-content")&&!o.closest(".protyle-wysiwyg"))){const d=this.resolveDocIdFromElement(o);if(d&&this.activeCursorBlockId!==d){const h=s||document.querySelector(`.protyle-title[data-node-id="${d}"]`)||document.querySelector(`.protyle[data-doc-id="${d}"] .protyle-title`),v=h==null?void 0:h.querySelector(".protyle-title__input"),u=((v==null?void 0:v.innerText)||(h==null?void 0:h.innerText)||"").trim();this.switchToDocGlobalInspector(d,u)}return}if(!o.closest(".protyle-wysiwyg"))return;const r=o.closest("[data-node-id]"),a=r==null?void 0:r.getAttribute("data-node-id"),c=(r==null?void 0:r.getAttribute("data-type"))||"";r&&a&&(this.currentDocId||(this.currentDocId=this.resolveDocIdFromElement(o)||""),this.currentDocId&&!this.latestCompiledDoc&&this.markCompileDirty(this.currentDocId),a!==this.activeCursorBlockId&&(this.activeCursorBlockId=a,As(a)),this.syncInspectorBlock(r,a,c))}async syncInspectorBlock(i,n,o){this.inspectorSyncThrottle.shouldSkip(n)||await Ti.syncInspectorBlock(i,n,o,this.currentDocId,this.latestCompiledDoc)}async compileCurrentDocument(i,n){const o=(n==null?void 0:n.reason)??"explicit";let s=i||this.currentDocId;if(!s){const r=this.getActiveDocumentId();if(r)this.currentDocId=r,s=r;else return}if(o==="auto"&&lo.getVisibility()==="none"){this.dirtyDocId=s;return}const l=this.compileScheduler.tryBegin(s);if(l!==null){this.dirtyDocId===s&&(this.dirtyDocId=null);try{const r=await Be.compile(s),a=!!this.currentDocId&&s!==this.currentDocId;!this.compileScheduler.isStale(l)&&!a&&(this.currentDocId||(this.currentDocId=s),this.latestCompiledDoc=r,Dk(r,s),this.updatePreviewTabHeader("",s),this.purgeStaleDomSlidevAttrs(r))}catch(r){console.error("[SiYuanSlidev] Failed to compile document:",r)}finally{const r=this.compileScheduler.finish();r&&this.markCompileDirty(r)}}}purgeStaleDomSlidevAttrs(i){Ti.purgeStaleDomSlidevAttrs(i)}}module.exports=Gk;
