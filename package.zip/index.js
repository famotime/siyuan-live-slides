"use strict";var oa=Object.create;var vs=Object.defineProperty;var ra=Object.getOwnPropertyDescriptor;var la=Object.getOwnPropertyNames;var aa=Object.getPrototypeOf,ca=Object.prototype.hasOwnProperty;var da=(t,i,e)=>i in t?vs(t,i,{enumerable:!0,configurable:!0,writable:!0,value:e}):t[i]=e;var ua=(t,i,e,n)=>{if(i&&typeof i=="object"||typeof i=="function")for(let s of la(i))!ca.call(t,s)&&s!==e&&vs(t,s,{get:()=>i[s],enumerable:!(n=ra(i,s))||n.enumerable});return t};var En=(t,i,e)=>(e=t!=null?oa(aa(t)):{},ua(i||!t||!t.__esModule?vs(e,"default",{value:t,enumerable:!0}):e,t));var kt=(t,i,e)=>da(t,typeof i!="symbol"?i+"":i,e);const vt=require("siyuan");async function ve(t,i){const e=await vt.fetchSyncPost(t,i);return e.code===0?e.data:null}async function fa(){return ve("/api/notebook/lsNotebooks","")}async function pa(t,i,e){return ve("/api/filetree/createDocWithMd",{notebook:t,path:i,markdown:e})}async function ha(t,i){const e=new FormData;e.append("assetsDirPath",t);for(const s of i)e.append("file[]",s);return ve("/api/asset/upload",e)}async function nn(t,i,e,n,s){return ve("/api/block/insertBlock",{dataType:t,data:i,nextID:e,previousID:n,parentID:s})}async function kr(t,i,e){return ve("/api/block/appendBlock",{dataType:t,data:i,parentID:e})}async function Do(t,i,e){return ve("/api/block/updateBlock",{dataType:t,data:i,id:e})}async function ma(t){return ve("/api/block/deleteBlock",{id:t})}async function ga(t){return ve("/api/block/getBlockKramdown",{id:t})}async function Vn(t){return ve("/api/block/getChildBlocks",{id:t})}async function zt(t,i){return ve("/api/attr/setBlockAttrs",{id:t,attrs:i})}async function Ge(t){return ve("/api/attr/getBlockAttrs",{id:t})}async function mn(t){return ve("/api/query/sql",{stmt:t})}async function Os(t,i,e){const n=new FormData;return n.append("path",t),n.append("isDir",i.toString()),n.append("modTime",Math.floor(Date.now()/1e3).toString()),n.append("file",e),ve("/api/file/putFile",n)}async function xr(t){const i="/api/ai/chatGPT";try{const e=await ve(i,{msg:t});return typeof e=="string"&&e.trim().length>0?e.trim():e&&typeof e.content=="string"&&e.content.trim().length>0?e.content.trim():null}catch{return null}}const rn="custom-slidev-theme",ln="custom-slidev-aspect-ratio",_r="custom-slidev-highlighter",an="custom-slidev-default-transition",Sr="custom-slidev-color-schema",xi="custom-slidev-slide",ft="custom-slidev-layout",Xt="custom-slidev-transition",Ut="custom-slidev-background",Ae="custom-slidev-image",zi="custom-slidev-notes",Ni="custom-slidev-class",Se="custom-slidev-click",He="custom-slidev-motion",Si="custom-slidev-shiki-lines",Et="custom-slidev-slot",ie="custom-slidev-note",qt="custom-slidev-role",cn="custom-slidev-max-height",vi="custom-slidev-autoplay",Tn="custom-slidev-loop",Oi="custom-slidev-muted",Mn="custom-slidev-controls",Cr="background",Ps="image-left",Ls="image-right",Pi={theme:"default",aspectRatio:"16/9",highlighter:"shiki",defaultTransition:"slide-left",colorSchema:"auto"};function va(t){var i,e,n,s,r;return t?{theme:((i=t[rn])==null?void 0:i.trim())||Pi.theme,aspectRatio:((e=t[ln])==null?void 0:e.trim())||Pi.aspectRatio,highlighter:((n=t[_r])==null?void 0:n.trim())||Pi.highlighter,defaultTransition:((s=t[an])==null?void 0:s.trim())||Pi.defaultTransition,colorSchema:((r=t[Sr])==null?void 0:r.trim())||Pi.colorSchema}:{...Pi}}function Kn(t){var e,n,s,r,l;const i=(e=t.ial)==null?void 0:e[xi];return!!(i&&(i==="true"||i==="page"||i==="cover"||i==="end")||t.type==="tb"||t.type==="thematic-break"||t.type==="NodeThematicBreak"||((n=t.markdown)==null?void 0:n.trim())==="---"||((s=t.markdown)==null?void 0:s.trim())==="***"||t.type==="b"&&(((r=t.markdown)==null?void 0:r.trim())==="---"||((l=t.content)==null?void 0:l.trim())==="---"))}function Oo(t){const i={};let e="";if(!t)return{frontmatter:i,notes:e};t[ft]&&(i.layout=t[ft].trim()),t[Xt]&&(i.transition=t[Xt].trim()),t[Ut]&&(i.background=t[Ut].trim()),t[Ae]&&(i.image=t[Ae].trim()),t[Ni]&&(i.class=t[Ni].trim()),t[zi]&&(e=t[zi].trim());for(const[n,s]of Object.entries(t))if(n.startsWith("custom-slidev-")&&![ft,Xt,Ut,Ae,Ni,zi,xi].includes(n)){const r=n.replace(/^custom-slidev-/,"");try{i[r]=JSON.parse(s)}catch{i[r]=s}}return{frontmatter:i,notes:e}}function ba(t){const i={};if(!t)return i;const e=t[ie]??t["slidev-note"];e!=null&&e!==""&&e!=="false"&&e!=="0"&&(i.isNote=!0);const n=t[qt]??t["slidev-role"],s=t[Ut]??t["slidev-background"];(n===Cr||s==="true"||s==="1")&&(i.isBackground=!0);const r=t[ft]??t["slidev-layout"];r===Ps||r===Ls?i.imageLayout=r:(n===Ps||n===Ls)&&(i.imageLayout=n);const l=t[Se]??t["custom-slidev-clicks"]??t["slidev-click"]??t["slidev-clicks"];if(l!=null&&(i.clicks=l.trim()),t[He])try{const o=JSON.parse(t[He]);typeof o=="object"&&o!==null?i.motion={preset:o.preset||o.type||"fade-in",...o}:i.motion={preset:String(o).trim()}}catch{i.motion={preset:t[He].trim()}}return t[Si]&&(i.shikiLines=t[Si].trim()),t[cn]&&(i.maxHeight=t[cn].trim()),t[Et]&&(i.slot=t[Et].trim()),i}function ya(t,i){const e=[];let s=0;for(let r=0;r<t.length;r++){const l=t[r];if(Kn(l)){s=0;continue}const o=l.markdown||l.content||"";if(!(r===0)){if(l.type==="h"&&(l.subType==="h1"||o.startsWith("# "))){e.push({blockId:l.id,recommendedLayout:"cover",reason:"检测到一级核心章节标题，建议作为新幻灯片封面/大章"}),s=0;continue}if(l.type==="h"&&(l.subType==="h2"||o.startsWith("## "))){e.push({blockId:l.id,recommendedLayout:"default",reason:"检测到二级分论点标题，建议开启新页"}),s=0;continue}}if(s++,s>=6&&r<t.length-1){const c=t[r+1];Kn(c)||(e.push({blockId:c.id,recommendedLayout:"default",reason:"当前页已达容量上限 (避免信息超载)，建议在此分页"}),s=0)}}return e}function Po(t,i){const e=(t.blocks||[]).filter(l=>{const o=(l.content||l.rawMarkdown||"").trim();return o&&o!=="---"});if(e.length===0)return"本页暂无内容，建议过渡承接上下文。";const n=[],s=[];for(const l of e){const o=(l.content||l.rawMarkdown||"").trim();o&&(l.type==="h"||o.startsWith("#")?n.push(o.replace(/^#+\s*/,"")):s.push(o.slice(0,50)))}const r=[];return n.length>0&&r.push(`【核心重点】：${n.join("、")}`),s.length>0&&(r.push("【口播要点】："),s.slice(0,3).forEach((l,o)=>{r.push(`${o+1}. 讲解 ${l}`)})),r.push("【过渡提示】：注意观察听众反应，适时抛出互动提问。"),r.join(`
`)}async function $r(t,i){const e=t.blocks&&t.blocks.length>0?t.blocks.map(n=>(n.content||n.rawMarkdown||"").trim()).filter(n=>n&&n!=="---").join(`
`):(t.rawMarkdown||"").replace(/^---\s*$/gm,"").trim();if(i&&e){const n=`你是一位专业的演讲教练。请根据以下幻灯片内容，提炼出简短精炼的演讲口播提词卡（Notes），包含核心观点与口播要点，总字数在 150 字以内：
${e}`;try{const s=await i(n);if(s&&s.trim())return{notes:s.trim(),isAiGenerated:!0}}catch(s){return{notes:Po(t),isAiGenerated:!1,error:(s==null?void 0:s.message)||"AI 调用异常"}}}return{notes:Po(t),isAiGenerated:!1}}async function wa(t,i){return(await $r(t,i)).notes}const Ir=/\(\(([0-9a-zA-Z-]+)(?:\s*(?:'([^']*)'|"([^"]*)"|([^\)]+?)))?\s*\)\)/g;function ka(t){const i=[];if(!t)return i;const e=new RegExp(Ir.source,"g");let n;for(;(n=e.exec(t))!==null;){const s=n[2]??n[3]??n[4];i.push({fullMatch:n[0],blockId:n[1],anchorText:s?s.trim():void 0})}return i}function xa(t,i){if(!t)return"";const e=new RegExp(Ir.source,"g");return t.replace(e,(n,s,r,l,o)=>{const a=(r??l??o??"").trim();if(i&&i[s]){const d=i[s].trim();return`<div class="slidev-block-ref" data-ref-id="${s}">${d}</div>`}const c=a||`Ref(${s.slice(0,8)})`;return`<a href="siyuan://blocks/${s}" data-ref-id="${s}" class="slidev-ref-tag">🔗 ${c}</a>`})}function _a(t){return t.markdown&&t.markdown.trim()?t.markdown.trim():t.content&&t.content.trim()?t.content.trim():""}function Sa(t){const i={};if(!t)return i;const e=t.replace(/^\{:\s*/,"").replace(/\s*\}$/,""),n=/([\w-]+)=(?:"([^"]*)"|'([^']*)'|(\S+))/g;let s;for(;(s=n.exec(e))!==null;){const r=s[1],l=s[2]??s[3]??s[4]??"";i[r]=l}return i}function Ca(t){if(!t)return!1;const i=t.trim();return i.startsWith("assets/")||i.startsWith("./assets/")||i.startsWith("/assets/")}function $a(t){const i=t.trim();return i.startsWith("./assets/")?i.slice(2):i.startsWith("/assets/")?i.slice(1):i}function _e(t,i){if(!Ca(t))return t;const e=$a(t);return i!=null&&i.base64Map&&i.base64Map[e]?i.base64Map[e]:i!=null&&i.baseUrl?`${i.baseUrl.replace(/\/+$/,"")}/${e}`:`/${e}`}function Ia(t,i){if(!t)return"";let e=t;return e=e.replace(/!\[(.*?)\]\(((?:\.\/|\/)?assets\/[^\s)]+)\)/g,(n,s,r)=>{const l=_e(r,i);return`![${s}](${l})`}),e=e.replace(/(<(?:img|video|audio|source)\b[^>]*?\bsrc=["'])((?:\.\/|\/)?assets\/[^"']+)(["'][^>]*>)/gi,(n,s,r,l)=>{const o=_e(r,i);return`${s}${o}${l}`}),e=e.replace(/(url\(\s*["']?)((?:\.\/|\/)?assets\/[^"')]+)(["']?\s*\))/gi,(n,s,r,l)=>{const o=_e(r,i);return`${s}${o}${l}`}),e}function fi(t,i){const e=(t||i||"").trim();if(!e)return null;const n=e.match(/!\[[\s\S]*?\]\(\s*([^\s)]+)(?:\s+(?:=["']?[^"'\s)]*["']?|["'][^"']*["']))*?\s*\)/);if(n)return n[1].trim();const s=e.match(/<img\b[^>]*?\bsrc=["']([^"']+)["']/i);if(s)return s[1].trim();const r=e.replace(/\{:[^}]*\}/g,"").trim();return/^(?:assets\/|https?:\/\/|\/|\.\.?\/)[^\s]+\.(?:png|jpe?g|gif|webp|svg|avif)(?:\?[^\s]*)?$/i.test(r)?r:null}function ce(t){if(!t)return!1;const i=(t.type||"").toLowerCase();return i==="s"||i==="sb"||i==="nodesuperblock"}function Mi(t){if(!ce(t))return!1;const i=(t.subType||"").toLowerCase();if(i==="col"||i==="h"||i==="horizontal")return!0;if(i==="row"||i==="v"||i==="vertical")return!1;if(t.ial){const n=(t.ial["data-sb-layout"]||t.ial.layout||"").toLowerCase();if(n==="col"||n==="h")return!0;if(n==="row"||n==="v")return!1}if(t.children&&t.children.length>0){for(const n of t.children)if(n.type==="NodeSuperBlockLayoutMarker"||n.type==="layout-marker"){const s=(n.content||n.markdown||"").trim().toLowerCase();if(s==="col"||s==="h")return!0;if(s==="row"||s==="v")return!1}}const e=(t.markdown||t.content||"").trim();return/^\{\{\{col\b/i.test(e)?!0:!/^\{\{\{row\b/i.test(e)}function Ki(t){if(!t)return!1;const i=(t.type||"").toLowerCase();if(i==="i"||i==="nodelistitem"||i==="l"||i==="nodelist")return!0;const e=(t.markdown||t.rawMarkdown||t.content||"").trim();return!!/^(?:[-*+]|\d+\.)\s+/.test(e)}function Rs(t){return!t||Ki(t)||ce(t)||!fi(t.markdown,t.content)?!1:(t.markdown||t.content||"").replace(/!\[.*?\]\([^)]+\)/g,"").replace(/<img\b[^>]*>/gi,"").replace(/\{:[^}]*\}/g,"").trim().length<=25}function pi(t){if(!t||!ce(t)||!Mi(t))return null;const i=(t.children||[]).filter(s=>{const r=s.type||"";if(r==="NodeSuperBlockOpenMarker"||r==="NodeSuperBlockLayoutMarker"||r==="NodeSuperBlockCloseMarker"||r==="open-marker"||r==="layout-marker"||r==="close-marker")return!1;const l=(s.markdown||s.content||"").trim();return!(/^\{\{\{(?:col|row)?\s*$/i.test(l)||l==="}}}")});if(i.length<2)return null;const e=Rs(i[0]),n=Rs(i[i.length-1]);if(e&&!n){const s=fi(i[0].markdown,i[0].content);if(s)return{imageNode:i[0],imageUrl:s,layout:Ps,contentNodes:i.slice(1)}}if(!e&&n){const s=fi(i[i.length-1].markdown,i[i.length-1].content);if(s)return{imageNode:i[i.length-1],imageUrl:s,layout:Ls,contentNodes:i.slice(0,i.length-1)}}return null}function Aa(t,i){const e=[];function n(s){for(const r of s){const l=pi(r);if(l){const{imageNode:o,layout:a}=l;o.ial||(o.ial={});const c=o.ial[ft];if(c!==a){const d={blockId:o.id,layout:a,previousLayout:c};o.ial[ft]=a,e.push(d),i&&i(d)}}r.children&&r.children.length>0&&n(r.children)}}return n(t),e}function Xs(t){return(t.children||[]).filter(i=>{const e=i.type||"";if(e==="NodeSuperBlockOpenMarker"||e==="NodeSuperBlockLayoutMarker"||e==="NodeSuperBlockCloseMarker"||e==="open-marker"||e==="layout-marker"||e==="close-marker")return!1;const n=(i.markdown||i.content||"").trim();return!(/^\{\{\{(?:col|row)?\s*$/i.test(n)||n==="}}}")})}function Ea(t){if(!t)return!1;const i=(t.type||"").toLowerCase();if(i==="h"||i==="nodeheading"||/^h[1-6]$/i.test(t.subType||""))return!0;const e=(t.markdown||t.content||"").trim();return!!/^#{1,6}\s+/.test(e)}function zs(t){if(!t)return"";const i=t.split(/\r?\n/);if(i.length===0)return"";const e=i[0],n=e.match(/^(\s*)(?:[-*+]|\d+\.)\s+(.*)$/);if(!n)return t;const s=n[1].length,r=n[2].trim(),l=e.length-n[2].length;if(i.length===1)return r;const o=[r];for(let a=1;a<i.length;a++){const c=i[a];if(!c.trim()){o.push("");continue}const d=c.match(/^(\s*)/),h=d?d[1].length:0;h>=l?o.push(c.slice(l)):h>s?o.push(c.slice(h)):o.push(c)}return o.join(`
`)}function _i(t){if(!t)return[];if(ce(t)&&Mi(t)&&!pi(t)){const n=Xs(t),s=[];for(const r of n)s.push(..._i(r));return s}const i=(t.type||"").toLowerCase();if(i==="l"||i==="nodelist"||i==="list"){if(t.children&&t.children.length>0){const l=t.children.filter(Ki);if(l.length>0)return l}const s=(t.markdown||t.content||"").trim().split(/\r?\n/),r=[];for(let l=0;l<s.length;l++)/^(?:[-*+]|\d+\.)\s+/.test(s[l])&&r.push(l);if(r.length>=2){const l=[];for(let o=0;o<r.length;o++){const a=r[o],c=o+1<r.length?r[o+1]:s.length,d=s.slice(a,c).join(`
`);l.push({id:`${t.id}-item-${o+1}`,type:"i",markdown:d,content:d,ial:{...t.ial||{}}})}return l}}return Ki(t)?[t]:[]}function Ar(t){var n;if(!t||!ce(t)||!Mi(t)||pi(t))return null;const i=Xs(t);if(i.length===0)return null;if(i.length===1&&ce(i[0])&&Mi(i[0])){const s=Ar(i[0]);return s?{items:s.items,nestedSuperBlocks:[i[0],...s.nestedSuperBlocks]}:null}const e=[];for(const s of i)if(ce(s)){e.push(s);const r=((n=s.children)==null?void 0:n.filter(ce))||[];e.push(...r)}if(i.length===3){const s=_i(i[0]),r=_i(i[1]),l=_i(i[2]);if(s.length===1&&r.length===1&&l.length===1)return{items:[s[0],r[0],l[0]],nestedSuperBlocks:e}}if(i.length===2){const s=_i(i[0]),r=_i(i[1]);if(s.length===2&&r.length===1)return{items:[s[0],s[1],r[0]],nestedSuperBlocks:e};if(s.length===1&&r.length===2)return{items:[s[0],r[0],r[1]],nestedSuperBlocks:e};if(s.length===1&&r.length===1)return{items:[s[0],r[0]],nestedSuperBlocks:e}}return null}function Ta(t){if(!t||!ce(t)||!Mi(t)||pi(t))return null;const i=Ar(t);if(!i)return null;const{items:e,nestedSuperBlocks:n}=i;return e.length!==2&&e.length!==3?null:e.length===2?{superBlockNode:t,nestedSuperBlocks:n,count:2,layout:"two-cols-header",items:e,slots:["left","right"]}:{superBlockNode:t,nestedSuperBlocks:n,count:3,layout:"three-cols-header",items:e,slots:["col-1","col-2","col-3"]}}function Ma(t){if(!t||!ce(t)||!Mi(t)||pi(t))return null;const i=Xs(t);if(i.length===0)return null;const e=[];for(const n of i){const s=_i(n);if(s.length===0)return null;e.push(...s)}return e}function Ba(t){if(!t||!ce(t)||!Mi(t)||pi(t))return null;const i=Ma(t);return!i||i.length===0||i.length===2||i.length===3?null:{superBlockNode:t,items:i}}function Da(t,i,e){var d,h,m,p,y;const n=[],s=[],r=(e==null?void 0:e.tracked)||[],l=[];let o={pageTargetId:t,blocks:[]};l.push(o);for(let f=0;f<i.length;f++){const k=i[f];if(Kn(k)){if(l.length===1&&o.blocks.length===0){o.pageTargetId=k.id,o.blocks.push(k);continue}o={pageTargetId:k.id,blocks:[k]},l.push(o)}else o.blocks.push(k)}function a(f){const k=[];for(const v of f)ce(v)&&k.push(v),v.children&&v.children.length>0&&k.push(...a(v.children));return k}function c(f,k,v){const w={blockId:f,attrs:k,previousAttrs:v};n.push(w),e!=null&&e.onTagChange&&e.onTagChange(w)}for(const f of l){const k=f.pageTargetId,v=i.find(C=>C.id===k),w=r.find(C=>C.pageTargetId===k);if(f.blocks.some(C=>{var A,B;return!!(pi(C)||Rs(C)&&(((A=C.ial)==null?void 0:A[ft])==="image-left"||((B=C.ial)==null?void 0:B[ft])==="image-right"))})){if(w){const C=w.headerId;if(C){c(C,{[Et]:""});const A=i.find(B=>B.id===C);A!=null&&A.ial&&(A.ial[Et]="")}for(const A of w.itemIds){c(A,{[Et]:""});const B=i.find(P=>P.id===A);B!=null&&B.ial&&(B.ial[Et]="")}}continue}let E=null,_=-1;for(let C=0;C<f.blocks.length;C++){const A=f.blocks[C],B=ce(A)?[A,...a(A.children||[])]:A.children?a(A.children):[];for(const P of B){const R=Ta(P);if(R){E=R,_=C;break}}if(E)break}if(E){const{superBlockNode:C,layout:A,items:B,slots:P}=E,X=f.blocks.slice(0,_).find(U=>Ea(U)),S=X==null?void 0:X.id,G=((d=v==null?void 0:v.ial)==null?void 0:d[ft])||"";if(G!==A&&(c(k,{[ft]:A},{[ft]:G}),v&&(v.ial||(v.ial={}),v.ial[ft]=A)),X){const U=((h=X.ial)==null?void 0:h[Et])||"";U!=="header"&&(c(X.id,{[Et]:"header"},{[Et]:U}),X.ial||(X.ial={}),X.ial[Et]="header")}if(w!=null&&w.headerId&&w.headerId!==S){c(w.headerId,{[Et]:""});const U=i.find(it=>it.id===w.headerId);U&&(U.ial||(U.ial={}),U.ial[Et]="")}const b=[];for(let U=0;U<B.length;U++){const it=B[U],j=P[U];b.push(it.id);const st=((m=it.ial)==null?void 0:m[Et])||"";if(st!==j&&(c(it.id,{[Et]:j},{[Et]:st}),it.ial||(it.ial={}),it.ial[Et]=j),it.children&&it.children.length>0)for(const K of it.children)K.ial||(K.ial={}),K.ial[Et]!==j&&(K.ial[Et]=j)}if(w!=null&&w.itemIds){for(const U of w.itemIds)if(!b.includes(U)){c(U,{[Et]:""});const it=i.find(j=>j.id===U);it&&(it.ial||(it.ial={}),it.ial[Et]="")}}s.push({superBlockId:C.id,nestedSuperBlockIds:(p=E.nestedSuperBlocks)==null?void 0:p.map(U=>U.id),pageTargetId:k,headerId:S,itemIds:b,layout:A})}else{let C=!1;const A=[];for(const R of f.blocks){const X=ce(R)?[R,...a(R.children||[])]:R.children?a(R.children):[];for(const S of X){const G=Ba(S);if(G){C=!0;for(const b of G.items)A.push(b.id)}}}const B=((y=v==null?void 0:v.ial)==null?void 0:y[ft])||"";if(w||C&&(B==="two-cols-header"||B==="three-cols-header")){c(k,{[ft]:""},{[ft]:B}),v&&(v.ial||(v.ial={}),v.ial[ft]="");const R=w==null?void 0:w.headerId;if(R){c(R,{[Et]:""});const S=i.find(G=>G.id===R);S&&(S.ial||(S.ial={}),S.ial[Et]="")}const X=new Set([...(w==null?void 0:w.itemIds)||[],...A]);for(const S of X){c(S,{[Et]:""});const G=i.find(b=>b.id===S);G&&(G.ial||(G.ial={}),G.ial[Et]="")}}}}return{changes:n,newTracked:s}}function Oa(t){const i=Object.entries(t).filter(([n,s])=>s!=null&&s!=="");return i.length===0?"":`---
${i.map(([n,s])=>typeof s=="string"?s.includes(":")||s.includes(`
`)||s.includes("#")?`${n}: "${s.replace(/"/g,'\\"')}"`:`${n}: ${s}`:`${n}: ${JSON.stringify(s)}`).join(`
`)}
---`}function Pa(t,i){if(!i||!t.startsWith("```"))return t;const e=t.indexOf(`
`);if(e===-1)return t;const n=t.slice(0,e).trim(),s=t.slice(e);return n.includes("{")?t:`${n} {${i}}${s}`}function La(t,i){if(i==null)return t;const e=i.trim();return e===""||e==="+1"?`<v-click>

${t}

</v-click>`:e==="hide"?`<v-click hide>

${t}

</v-click>`:`<v-click at="${e}">

${t}

</v-click>`}function Ra(t){if(!t||!t.preset)return null;const i=t.preset.toLowerCase().trim();if(!i||i==="none")return null;let e={opacity:0},n={opacity:1};switch(i){case"slide-up":e={y:40,opacity:0},n={y:0,opacity:1};break;case"slide-down":e={y:-40,opacity:0},n={y:0,opacity:1};break;case"slide-left":e={x:40,opacity:0},n={x:0,opacity:1};break;case"slide-right":e={x:-40,opacity:0},n={x:0,opacity:1};break;case"zoom-in":case"pop":e={scale:.8,opacity:0},n={scale:1,opacity:1};break;case"bounce":e={y:40,opacity:0},n={y:0,opacity:1,transition:{type:"spring",damping:10,stiffness:100}};break;case"fade-in":default:e={opacity:0},n={opacity:1};break}t.initial&&typeof t.initial=="object"&&(e={...e,...t.initial}),t.enter&&typeof t.enter=="object"&&(n={...n,...t.enter});const s={...n.transition||{}};return typeof t.duration=="number"&&t.duration>0&&(s.duration=t.duration),typeof t.delay=="number"&&t.delay>0&&(s.delay=t.delay),Object.keys(s).length>0&&(n.transition=s),{initial:e,enter:n}}function bs(t,i,e){const n=i!=null&&i.trim()!=="",s=Ra(e);if(!n&&!s)return t;if(n&&!s)return La(t,i);const r=JSON.stringify(s.initial).replace(/"/g,"'"),l=JSON.stringify(s.enter).replace(/"/g,"'"),o=`v-motion :initial="${r}" :enter="${l}"`;if(!n)return`<div ${o}>

${t}

</div>`;const a=i.trim();let c="v-click";return a==="hide"?c="v-click.hide":a!==""&&a!=="+1"&&(c=`v-click="${a}"`),`<div ${c} ${o}>

${t}

</div>`}function Er(t){if(!t)return"";let i=t.trim();i=i.replace(/\{:[^}]*\}/g,"").trim(),i=i.replace(/^:::\s*[a-zA-Z0-9_-]*\s*\r?\n?/g,""),i=i.replace(/\r?\n?:::\s*$/g,"");let s=i.split(/\r?\n/).map(r=>r.trim().replace(/^>\s*/,"")).join(`
`).trim();return s=s.replace(/^\[!(?:NOTE|TIP|IMPORTANT|WARNING|CAUTION|[A-Za-z_-]+)\][^\r\n]*(?:\r?\n)?/i,"").trim(),s=s.replace(/^(?:💡|✏️|❗|⚠️|🚨|\s*)*(?:\*\*|__)?(?:演讲备注|演讲者提词|讲稿备注|演讲提词|备注|Notes?)(?:\*\*|__)?[:：]?\s*(?:\r?\n)?/i,"").trim(),s=s.replace(/^[-*+]\s+/,""),s=s.replace(/^\d+\.\s+/,""),s.trim()}function za(t){var n;if(t.subType&&/^h([1-6])$/i.test(t.subType))return parseInt(t.subType.slice(1),10);const e=(t.markdown||t.content||"").trim().match(/^(#{1,6})\s+/);return e?e[1].length:t.type==="h"?(n=t.ial)!=null&&n.subType&&/^h([1-6])$/i.test(t.ial.subType)?parseInt(t.ial.subType.slice(1),10):1:null}function Tr(t){if(!t||t.length===0)return{col1:[],col2:[],col3:[]};if(t.length===1&&t[0].children&&t[0].children.length>=2){const l=t[0].children;if(l.length>=3){const o=Math.ceil(l.length/3),a=Math.ceil((l.length-o)/2);return{col1:l.slice(0,o),col2:l.slice(o,o+a),col3:l.slice(o+a)}}else return{col1:[l[0]],col2:[l[1]],col3:[]}}const i=l=>{const o=l.slot||"";return o==="col-1"||o==="left"?1:o==="col-2"||o==="center"?2:o==="col-3"||o==="right"?3:null},e=t.map(i);if(e.some(l=>l!==null)){const l=e.includes(2),o=e.includes(3);if(l||o){const d=[],h=[],m=[];let p=1;for(const y of t){const f=i(y);f!==null&&(p=f),p===1?d.push(y):p===2?h.push(y):m.push(y)}return{col1:d,col2:h,col3:m}}const a=t.filter(d=>i(d)===1),c=t.filter(d=>i(d)===null);if(c.length>=2){const d=Math.ceil(c.length/2);return{col1:a,col2:c.slice(0,d),col3:c.slice(d)}}else return c.length===1?{col1:a,col2:c,col3:[]}:{col1:a,col2:[],col3:[]}}const s=l=>{if(l.type==="h"||l.subType&&/^h[1-6]$/i.test(l.subType))return!0;const o=(l.rawMarkdown||l.content||"").trim();return/^#{1,6}\s+/.test(o)},r=t.map((l,o)=>s(l)?o:-1).filter(l=>l!==-1);if(r.length>=3)return{col1:t.slice(0,r[1]),col2:t.slice(r[1],r[2]),col3:t.slice(r[2])};if(t.length>=3){const l=Math.ceil(t.length/3),o=Math.ceil((t.length-l)/2);return{col1:t.slice(0,l),col2:t.slice(l,l+o),col3:t.slice(l+o)}}if(t.length===2)return{col1:[t[0]],col2:[t[1]],col3:[]};if(t.length===1){const l=t[0],o=(l.rawMarkdown||l.content||"").trim(),a=o.split(/\r?\n/),c=[];for(let m=0;m<a.length;m++)/^[ \t]*[-*+]\s+|^[ \t]*\d+\.\s+/.test(a[m])&&c.push(m);if(c.length>=3){const m=Math.ceil(c.length/3),p=Math.ceil((c.length-m)/2),y=a.slice(c[0],c[m]).join(`
`),f=a.slice(c[m],c[m+p]).join(`
`),k=a.slice(c[m+p]).join(`
`);return{col1:[{...l,rawMarkdown:y,content:y}],col2:[{...l,id:`${l.id}-col2`,rawMarkdown:f,content:f}],col3:[{...l,id:`${l.id}-col3`,rawMarkdown:k,content:k}]}}const d=o.match(/<li[\s\S]*?<\/li>/gi);if(d&&d.length>=3){const m=Math.ceil(d.length/3),p=Math.ceil((d.length-m)/2),y=`<ul>
${d.slice(0,m).join(`
`)}
</ul>`,f=`<ul>
${d.slice(m,m+p).join(`
`)}
</ul>`,k=`<ul>
${d.slice(m+p).join(`
`)}
</ul>`;return{col1:[{...l,rawMarkdown:y,content:y}],col2:[{...l,id:`${l.id}-col2`,rawMarkdown:f,content:f}],col3:[{...l,id:`${l.id}-col3`,rawMarkdown:k,content:k}]}}const h=o.split(/\r?\n\s*\r?\n/).filter(m=>m.trim()!=="");if(h.length>=3){const m=Math.ceil(h.length/3),p=Math.ceil((h.length-m)/2);return{col1:[{...l,rawMarkdown:h.slice(0,m).join(`

`),content:h.slice(0,m).join(`

`)}],col2:[{...l,id:`${l.id}-col2`,rawMarkdown:h.slice(m,m+p).join(`

`),content:h.slice(m,m+p).join(`

`)}],col3:[{...l,id:`${l.id}-col3`,rawMarkdown:h.slice(m+p).join(`

`),content:h.slice(m+p).join(`

`)}]}}}return{col1:t,col2:[],col3:[]}}function Lo(t,i,e,n){const s=va(i),r=[],l=Oo(i);let o={pageIndex:1,startBlockId:t,frontmatter:{layout:l.frontmatter.layout||"cover",...l.frontmatter},notes:"",noteBlocks:[],blocks:[],rawMarkdown:"",allBlockIds:[t]};o.frontmatter.background&&(o.frontmatter.background=_e(o.frontmatter.background,n)),o.frontmatter.image&&(o.frontmatter.image=_e(o.frontmatter.image,n)),r.push(o);let a=[];for(const d of e){if(Kn(d)){a=[];const m=Oo(d.ial);if(r.length===1&&o.blocks.length===0){o.startBlockId=d.id,o.allBlockIds||(o.allBlockIds=[]),o.allBlockIds.includes(d.id)||o.allBlockIds.push(d.id),m.frontmatter.layout&&(o.frontmatter.layout=m.frontmatter.layout),Object.assign(o.frontmatter,m.frontmatter),!m.frontmatter.image&&l.frontmatter.image&&(o.frontmatter.image=l.frontmatter.image),!m.frontmatter.background&&l.frontmatter.background&&(o.frontmatter.background=l.frontmatter.background),o.frontmatter.background&&(o.frontmatter.background=_e(o.frontmatter.background,n)),o.frontmatter.image&&(o.frontmatter.image=_e(o.frontmatter.image,n));continue}o={pageIndex:r.length+1,startBlockId:d.id,frontmatter:{layout:m.frontmatter.layout||"default",...m.frontmatter},notes:"",noteBlocks:[],blocks:[],rawMarkdown:"",allBlockIds:[d.id]},o.frontmatter.background&&(o.frontmatter.background=_e(o.frontmatter.background,n)),o.frontmatter.image&&(o.frontmatter.image=_e(o.frontmatter.image,n)),r.push(o);continue}const h=m=>{if(o.allBlockIds||(o.allBlockIds=[]),m.id&&!o.allBlockIds.includes(m.id)&&o.allBlockIds.push(m.id),m.children&&m.children.length>0){const S=G=>{for(const b of G)b.id&&!o.allBlockIds.includes(b.id)&&o.allBlockIds.push(b.id),b.children&&b.children.length>0&&S(b.children)};S(m.children)}let p=_a(m),y=m.ial?{...m.ial}:{};const f=p.match(/\{:\s*([^}]+)\s*\}\s*$/);f&&(y={...Sa(f[0]),...y},p=p.slice(0,f.index).trim());let k=p.trim();if(/^\{\{\{(?:row|col)?\s*$/i.test(k)||k==="}}}")return;/^\{\{\{(?:row|col)?\s*\r?\n/i.test(k)&&/\r?\n\}\}\}$/.test(k)&&(p=k.replace(/^\{\{\{(?:row|col)?\s*\r?\n/i,"").replace(/\r?\n\}\}\}$/,"").trim(),k=p.trim());const v=ba(y);if(p=Ia(p,n),p=xa(p,n==null?void 0:n.refContentMap),m.children&&m.children.length>0){const S=G=>{for(const b of G){if(b.ial)for(const[U,it]of Object.entries(b.ial))U.startsWith("custom-slidev-")&&!y[U]&&(y[U]=it);b.children&&b.children.length>0&&S(b.children)}};S(m.children)}const w=m.type==="video"||m.type==="NodeVideo"||/<video\b/i.test(p);if(w){const S=y["custom-slidev-autoplay"]==="true",G=y["custom-slidev-loop"]==="true",b=y["custom-slidev-muted"]==="true"||S,U=y["custom-slidev-controls"]==="false";p=p.replace(/<video\b([^>]*)>/gi,(it,j)=>{let st=j;return U?st=st.replace(/\bcontrols(?:="[^"]*")?/gi,"").trim():/controls/i.test(st)||(st+=" controls"),S&&!/autoplay/i.test(st)?st+=" autoplay playsinline":!S&&y["custom-slidev-autoplay"]==="false"&&(st=st.replace(/\bautoplay\b/gi,"").replace(/\bplaysinline\b/gi,"").trim()),G&&!/loop/i.test(st)?st+=" loop":!G&&y["custom-slidev-loop"]==="false"&&(st=st.replace(/\bloop\b/gi,"").trim()),b&&!/muted/i.test(st)?st+=" muted":!b&&y["custom-slidev-muted"]==="false"&&(st=st.replace(/\bmuted\b/gi,"").trim()),`<video ${st.trim()}>`})}if(v.isBackground){const S=fi(p,m.content);if(S){o.frontmatter.background=_e(S,n);return}}const x=pi(m);if(x){o.frontmatter.layout=x.layout,o.frontmatter.image=_e(x.imageUrl,n);for(const S of x.contentNodes)h(S);return}if(v.imageLayout==="image-left"||v.imageLayout==="image-right"){const S=fi(p,m.content);if(S){o.frontmatter.layout=v.imageLayout,o.frontmatter.image=_e(S,n);return}}if(ce(m)&&m.children&&m.children.length>0){for(const S of m.children)h(S);return}if((m.type==="l"||m.type==="NodeList"||m.type==="list")&&m.children&&m.children.length>0&&(m.children.some(S=>{var G;return(G=S.ial)==null?void 0:G[Et]})||v.slot)){for(const S of m.children)v.slot&&(!S.ial||!S.ial[Et])&&(S.ial||(S.ial={}),S.ial[Et]=v.slot),h(S);return}if(v.isNote){const S=Er(p);S&&(o.notes?o.notes+=`

`+S:o.notes=S),o.noteBlocks||(o.noteBlocks=[]),o.noteBlocks.push({id:m.id,type:m.type,content:S||m.content||"",rawMarkdown:p,isNote:!0,attributes:m.ial});return}v.shikiLines&&(p=Pa(p,v.shikiLines)),k=p.trim();const E=(m.content||"").trim();if(k==="::right::"||E==="::right::"||/^<p>\s*::right::\s*<\/p>$/i.test(k)||k.startsWith("::right::")){o.blocks.push({id:m.id,type:m.type,content:"::right::",rawMarkdown:"::right::",slot:"slot-divider-right",attributes:m.ial});return}const C=za(m);let A=v.slot,B=v.clicks,P=v.motion,R={...m.ial||{}};if(C!==null){for(;a.length>0&&a[a.length-1].level>=C;)a.pop();const S=a.length>0?a[a.length-1]:void 0;!A&&(S!=null&&S.slot)&&(A=S.slot),!B&&(S!=null&&S.clicks)&&(B=S.clicks),!P&&(S!=null&&S.motion)&&(P=S.motion);const G={...(S==null?void 0:S.customAttrs)||{}};if(m.ial)for(const[b,U]of Object.entries(m.ial))b.startsWith("custom-slidev-")&&!b.startsWith("custom-slidev-slide")&&(G[b]=U);a.push({level:C,slot:A,clicks:B,motion:P,customAttrs:G})}else{const S=a.length>0?a[a.length-1]:void 0;S&&(!A&&S.slot&&S.slot!=="header"&&(A=S.slot),!B&&S.clicks&&(B=S.clicks),!P&&S.motion&&(P=S.motion),S.customAttrs&&(R={...S.customAttrs,...R}))}!A&&o.blocks.some(S=>S.slot==="slot-divider-right")&&(A="right"),A&&(R[Et]=A),B&&!R[Se]&&(R[Se]=B),P&&!R[He]&&(R[He]=JSON.stringify(P)),(w||y["custom-slidev-autoplay"]||y["custom-slidev-muted"])&&(y["custom-slidev-autoplay"]&&(R["custom-slidev-autoplay"]=y["custom-slidev-autoplay"],y["custom-slidev-autoplay"]==="true"&&!y["custom-slidev-muted"]&&(R["custom-slidev-muted"]="true")),y["custom-slidev-loop"]&&(R["custom-slidev-loop"]=y["custom-slidev-loop"]),y["custom-slidev-muted"]&&(R["custom-slidev-muted"]=y["custom-slidev-muted"]),y["custom-slidev-controls"]&&(R["custom-slidev-controls"]=y["custom-slidev-controls"]));const X={id:m.id,type:m.type,content:m.content||"",rawMarkdown:p,clicks:B,motion:P,shikiLines:v.shikiLines,slot:A,attributes:R};o.blocks.push(X)};h(d)}for(let d=0;d<r.length;d++){const h=r[d],m=[],p={...h.frontmatter};d===0&&(p.theme=s.theme,p.aspectRatio=s.aspectRatio,p.highlighter=s.highlighter,p.transition=h.frontmatter.transition||s.defaultTransition);const y=Oa(p);y&&m.push(y);const f=h.blocks.filter(x=>x.slot!=="slot-divider-right"),k=x=>x.map(E=>bs(E.rawMarkdown,E.clicks,E.motion)).join(`

`),v=x=>{if(x.length===0)return"";if(x.length===1&&Ki(x[0])){const E=zs(x[0].rawMarkdown);return bs(E,x[0].clicks,x[0].motion)}return k(x)},w=h.frontmatter.layout||"default";if(w==="two-cols-header"){let x=[];const E=f.filter(X=>X.slot==="header");if(E.length>0)x=E;else if(f.length>0){const X=f.find(S=>S.type==="h"&&(!S.slot||S.slot==="default"));X&&(x=[X])}const _=f.filter(X=>!x.includes(X)),C=_.filter(X=>X.slot==="right"||X.slot==="col-2"),A=_.filter(X=>!C.includes(X)),B=k(x),P=v(A),R=v(C);B&&m.push(B),P&&m.push(`::left::

${P}`),R&&m.push(`::right::

${R}`)}else if(w==="three-cols-header"){let x=[];const E=f.filter(b=>b.slot==="header");if(E.length>0)x=E;else if(f.length>0){const b=f.find(U=>U.type==="h"&&(!U.slot||U.slot==="default"));b&&(x=[b])}const _=f.filter(b=>!x.includes(b)),C=Tr(_),A=C.col1,B=C.col2,P=C.col3;for(const b of A)b.slot||(b.slot="col-1");for(const b of B)b.slot||(b.slot="col-2");for(const b of P)b.slot||(b.slot="col-3");if(_.length===1&&(B.length>0||P.length>0)){const b=h.blocks.findIndex(U=>U.id===_[0].id);b!==-1&&h.blocks.splice(b,1,...A,...B,...P)}const R=k(x),X=v(A),S=v(B),G=v(P);R&&m.push(R),X&&m.push(`::col-1::

${X}`),S&&m.push(`::col-2::

${S}`),G&&m.push(`::col-3::

${G}`)}else if(w==="two-cols"){const x=f.filter(A=>A.slot==="left"),E=f.filter(A=>A.slot==="right"),_=k(x.length>0?x:f.filter(A=>A.slot!=="right")),C=k(E);m.push(_),C&&m.push(`::right::

${C}`)}else for(const x of f)m.push(bs(x.rawMarkdown,x.clicks,x.motion));h.notes&&m.push(`<!--
${h.notes}
-->`),h.rawMarkdown=m.join(`

`).trim()}const c=r.map(d=>d.rawMarkdown).filter(Boolean).join(`

---

`);return{docId:t,config:s,slides:r,fullMarkdown:c}}function ys(t){const i={};if(!t||typeof t!="string")return i;const e=t.replace(/^\{:\s*/,"").replace(/\s*\}$/,""),n=/([\w-]+)=(?:"([^"]*)"|'([^']*)'|(\S+))/g;let s;for(;(s=n.exec(e))!==null;){const r=s[1],l=s[2]??s[3]??s[4]??"";i[r]=l}return i}const Na={getBlockAttrs:Ge,getChildBlocks:Vn,setBlockAttrs:zt,sql:mn,getBaseUrl:()=>typeof location<"u"?location.origin:""};class Fa{constructor(i){kt(this,"deps");kt(this,"attrOverrides",new Map);kt(this,"trackedListSuperBlocks",new Map);this.deps={...Na,...i||{}}}setBlockAttrOverride(i,e){if(!i||!e)return;const s={...this.attrOverrides.get(i)||{}};for(const[r,l]of Object.entries(e))l===""||l===null||l===void 0?delete s[r]:s[r]=String(l);Object.keys(s).length===0?this.attrOverrides.delete(i):this.attrOverrides.set(i,s)}getBlockAttrOverride(i){return this.attrOverrides.get(i)}getAllAttrOverrides(){return new Map(this.attrOverrides)}getTrackedListSuperBlocks(i){return this.trackedListSuperBlocks.get(i)||[]}clearBlockAttrOverride(i,e){if(!i)return;if(!e){this.attrOverrides.delete(i);return}const n=this.attrOverrides.get(i);n&&(delete n[e],Object.keys(n).length===0&&this.attrOverrides.delete(i))}clearAllOverrides(){this.attrOverrides.clear(),this.trackedListSuperBlocks.clear()}async compile(i){try{const e=await this.deps.getBlockAttrs(i).catch(()=>({}))||{},n=this.attrOverrides.get(i);n&&Object.assign(e,n);let s=await this.deps.getChildBlocks(i).catch(()=>[]);const r=`SELECT id, ial FROM blocks WHERE root_id = '${i}' LIMIT 99999`,l=await this.deps.sql(r).catch(()=>[])||[],o=new Map;if(Array.isArray(l))for(const x of l)x.id&&x.ial&&o.set(x.id,ys(x.ial));const a=`SELECT block_id, name, value FROM attributes WHERE root_id = '${i}' LIMIT 99999`,c=await this.deps.sql(a).catch(()=>[])||[];if(Array.isArray(c)){for(const x of c)if(x.block_id&&x.name){let E=o.get(x.block_id);E||(E={},o.set(x.block_id,E)),E[x.name]=x.value||""}}if(!s||s.length===0){const x=`SELECT id, parent_id, root_id, type, sub_type as subType, content, markdown, ial FROM blocks WHERE root_id = '${i}' AND id != '${i}' ORDER BY created ASC LIMIT 99999`;s=await this.deps.sql(x).catch(()=>[])||[]}const d=(s||[]).map(x=>{const E=o.get(x.id)||(x.ial?ys(x.ial):{}),_=this.attrOverrides.get(x.id);return _&&Object.assign(E,_),{id:x.id,parent_id:x.parent_id,root_id:x.root_id||i,type:x.type,subType:x.subType,content:x.content||"",markdown:x.markdown||"",ial:E,children:x.children}}),h=async(x,E=0)=>{if(!(!x||x.length===0||E>8))for(const _ of x){if((ce(_)||_.type==="l"||_.type==="NodeList"||_.type==="i"||_.type==="NodeListItem"||_.type==="b"||_.type==="NodeBlockquote")&&(!_.children||_.children.length===0)){let A=await this.deps.getChildBlocks(_.id).catch(()=>[]);if(!A||A.length===0){const B=`SELECT id, parent_id, root_id, type, sub_type as subType, content, markdown, ial FROM blocks WHERE parent_id = '${_.id}' ORDER BY sort ASC, created ASC`;A=await this.deps.sql(B).catch(()=>[])||[]}Array.isArray(A)&&A.length>0&&(_.children=A.map(B=>{const P=o.get(B.id)||(B.ial?ys(B.ial):{}),R=this.attrOverrides.get(B.id);return R&&Object.assign(P,R),{id:B.id,parent_id:B.parent_id||_.id,root_id:B.root_id||i,type:B.type,subType:B.subType,content:B.content||"",markdown:B.markdown||"",ial:P}}))}_.children&&_.children.length>0&&await h(_.children,E+1)}};await h(d);const m=x=>{var E,_;for(const C of x)if(C.children&&C.children.length>0){m(C.children);for(const A of C.children)if(A.ial)for(const[B,P]of Object.entries(A.ial))B.startsWith("custom-slidev-")&&!((E=C.ial)!=null&&E[B])&&(C.ial||(C.ial={}),C.ial[B]=P);if(C.ial){for(const[A,B]of Object.entries(C.ial))if(A.startsWith("custom-slidev-"))for(const P of C.children)(P.type==="video"||P.type==="NodeVideo"||/<video\b/i.test(P.markdown||P.content||""))&&!((_=P.ial)!=null&&_[A])&&(P.ial||(P.ial={}),P.ial[A]=B)}}};m(d),Aa(d,x=>{this.setBlockAttrOverride(x.blockId,{[ft]:x.layout}),(this.deps.setBlockAttrs||zt)(x.blockId,{[ft]:x.layout}).catch(_=>{console.warn("[DocumentCompiler] Failed to auto-tag superblock image layout:",_)})});const p=this.trackedListSuperBlocks.get(i)||[],y=Da(i,d,{tracked:p,onTagChange:x=>{this.setBlockAttrOverride(x.blockId,x.attrs),x.blockId===i&&Object.assign(e,x.attrs);const E=C=>{for(const A of C)A.id===x.blockId&&(A.ial||(A.ial={}),Object.assign(A.ial,x.attrs)),A.children&&A.children.length>0&&E(A.children)};E(d),(this.deps.setBlockAttrs||zt)(x.blockId,x.attrs).catch(C=>{console.warn("[DocumentCompiler] Failed to auto-tag list superblock attrs:",C)})}});this.trackedListSuperBlocks.set(i,y.newTracked);const f=new Set;for(const x of d){const E=x.markdown||x.content||"";if(E.includes("((")){const _=ka(E);for(const C of _)f.add(C.blockId)}}const k={};if(f.size>0){const x=Array.from(f).map(_=>`'${_}'`).join(","),E=await this.deps.sql(`SELECT id, content, markdown FROM blocks WHERE id IN (${x})`).catch(()=>[])||[];if(Array.isArray(E))for(const _ of E)_.id&&(k[_.id]=_.markdown||_.content||"")}const v=this.deps.getBaseUrl?this.deps.getBaseUrl():"";return Lo(i,e,d,{baseUrl:v,refContentMap:k})}catch(e){return console.error("[DocumentCompilerService] Failed to compile document:",e),Lo(i,{},[],{})}}}const Ht=new Fa;class Qs{constructor(i){kt(this,"devServerUrl","http://localhost:3030");kt(this,"isConnected",!1);kt(this,"lastSyncTime",null);i&&(this.devServerUrl=i)}getUrl(){return this.devServerUrl}setUrl(i){this.devServerUrl=i.replace(/\/+$/,"")}isServerConnected(){return this.isConnected}getLastSyncTime(){return this.lastSyncTime}async probeServer(i=1500){try{const e=new AbortController,n=setTimeout(()=>e.abort(),i),s=await fetch(this.devServerUrl,{method:"HEAD",mode:"no-cors",signal:e.signal}).catch(()=>null);return clearTimeout(n),this.isConnected=!!s,this.isConnected}catch{return this.isConnected=!1,!1}}buildStandardSlidevMarkdown(i){const e=i.config,n=["---",`theme: ${e.theme||"default"}`,`aspectRatio: "${e.aspectRatio||"16/9"}"`,`highlighter: ${e.highlighter||"shiki"}`,`transition: ${e.defaultTransition||"slide-left"}`];e.colorSchema&&e.colorSchema!=="auto"&&n.push(`colorSchema: ${e.colorSchema}`),n.push("drawings:","  persist: false","---","");const s=n.join(`
`),r=i.slides.map((l,o)=>{const a=l.frontmatter||{},c=[],d=o===0;a.layout&&a.layout!=="default"&&c.push(`layout: ${a.layout}`),a.transition&&c.push(`transition: ${a.transition}`),a.background&&c.push(`background: ${a.background}`),a.class&&c.push(`class: "${a.class}"`);let h="";c.length>0?h=d?"":`---
${c.join(`
`)}
---

`:d||(h=`---

`);let m="";if(a.layout==="two-cols"){const y=l.blocks.filter(w=>w.slot!=="right"),f=l.blocks.filter(w=>w.slot==="right"),k=y.map(w=>w.rawMarkdown||w.content||"").join(`

`),v=f.map(w=>w.rawMarkdown||w.content||"").join(`

`);m=`${k}

::right::

${v}`}else m=l.blocks.map(y=>y.rawMarkdown||y.content||"").join(`

`);let p="";return l.notes&&l.notes.trim()&&(p=`

<!--
${l.notes.trim()}
-->`),`${h}${m}${p}`}).join(`

`);return`${s}${r}
`}async syncToWorkspaceFile(i,e="/data/storage/petal/siyuan-slidev/slides.md",n){const s=this.buildStandardSlidevMarkdown(i);if(this.lastSyncTime=Date.now(),n)try{const r=typeof Blob<"u"?new Blob([s],{type:"text/markdown;charset=utf-8"}):Buffer.from(s,"utf-8");return await n(e,!1,r),{success:!0,path:e}}catch(r){return{success:!1,path:e,error:String(r)}}return{success:!0,path:e}}downloadSlidesMd(i,e="slides.md"){if(typeof window>"u"||typeof document>"u")return!1;const n=this.buildStandardSlidevMarkdown(i),s=new Blob([n],{type:"text/markdown;charset=utf-8"}),r=URL.createObjectURL(s),l=document.createElement("a");return l.href=r,l.download=e,document.body.appendChild(l),l.click(),document.body.removeChild(l),URL.revokeObjectURL(r),!0}}/**
* @vue/shared v3.5.40
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/function to(t){const i=Object.create(null);for(const e of t.split(","))i[e]=1;return e=>e in i}const Wt={},Fi=[],Ve=()=>{},Mr=()=>!1,is=t=>t.charCodeAt(0)===111&&t.charCodeAt(1)===110&&(t.charCodeAt(2)>122||t.charCodeAt(2)<97),ns=t=>t.startsWith("onUpdate:"),re=Object.assign,eo=(t,i)=>{const e=t.indexOf(i);e>-1&&t.splice(e,1)},ja=Object.prototype.hasOwnProperty,Rt=(t,i)=>ja.call(t,i),Ct=Array.isArray,ji=t=>_n(t)==="[object Map]",Ji=t=>_n(t)==="[object Set]",Ro=t=>_n(t)==="[object Date]",It=t=>typeof t=="function",Qt=t=>typeof t=="string",De=t=>typeof t=="symbol",jt=t=>t!==null&&typeof t=="object",Br=t=>(jt(t)||It(t))&&It(t.then)&&It(t.catch),Dr=Object.prototype.toString,_n=t=>Dr.call(t),Ha=t=>_n(t).slice(8,-1),Or=t=>_n(t)==="[object Object]",io=t=>Qt(t)&&t!=="NaN"&&t[0]!=="-"&&""+parseInt(t,10)===t,dn=to(",key,ref,ref_for,ref_key,onVnodeBeforeMount,onVnodeMounted,onVnodeBeforeUpdate,onVnodeUpdated,onVnodeBeforeUnmount,onVnodeUnmounted"),ss=t=>{const i=Object.create(null);return(e=>i[e]||(i[e]=t(e)))},Ua=/-\w/g,he=ss(t=>t.replace(Ua,i=>i.slice(1).toUpperCase())),Wa=/\B([A-Z])/g,hi=ss(t=>t.replace(Wa,"-$1").toLowerCase()),os=ss(t=>t.charAt(0).toUpperCase()+t.slice(1)),ws=ss(t=>t?`on${os(t)}`:""),Ue=(t,i)=>!Object.is(t,i),Fn=(t,...i)=>{for(let e=0;e<t.length;e++)t[e](...i)},Pr=(t,i,e,n=!1)=>{Object.defineProperty(t,i,{configurable:!0,enumerable:!1,writable:n,value:e})},rs=t=>{const i=parseFloat(t);return isNaN(i)?t:i};let zo;const ls=()=>zo||(zo=typeof globalThis<"u"?globalThis:typeof self<"u"?self:typeof window<"u"?window:typeof global<"u"?global:{});function no(t){if(Ct(t)){const i={};for(let e=0;e<t.length;e++){const n=t[e],s=Qt(n)?Ga(n):no(n);if(s)for(const r in s)i[r]=s[r]}return i}else if(Qt(t)||jt(t))return t}const Va=/;(?![^(]*\))/g,Ka=/:([^]+)/,qa=/\/\*[^]*?\*\//g;function Ga(t){const i={};return t.replace(qa,"").split(Va).forEach(e=>{if(e){const n=e.split(Ka);n.length>1&&(i[n[0].trim()]=n[1].trim())}}),i}function Tt(t){let i="";if(Qt(t))i=t;else if(Ct(t))for(let e=0;e<t.length;e++){const n=Tt(t[e]);n&&(i+=n+" ")}else if(jt(t))for(const e in t)t[e]&&(i+=e+" ");return i.trim()}const Za="itemscope,allowfullscreen,formnovalidate,ismap,nomodule,novalidate,readonly",Ya=to(Za);function Lr(t){return!!t||t===""}function Ja(t,i){if(t.length!==i.length)return!1;let e=!0;for(let n=0;e&&n<t.length;n++)e=Xi(t[n],i[n]);return e}function Xi(t,i){if(t===i)return!0;let e=Ro(t),n=Ro(i);if(e||n)return e&&n?t.getTime()===i.getTime():!1;if(e=De(t),n=De(i),e||n)return t===i;if(e=Ct(t),n=Ct(i),e||n)return e&&n?Ja(t,i):!1;if(e=jt(t),n=jt(i),e||n){if(!e||!n)return!1;const s=Object.keys(t).length,r=Object.keys(i).length;if(s!==r)return!1;for(const l in t){const o=t.hasOwnProperty(l),a=i.hasOwnProperty(l);if(o&&!a||!o&&a||!Xi(t[l],i[l]))return!1}}return String(t)===String(i)}function so(t,i){return t.findIndex(e=>Xi(e,i))}const Rr=t=>!!(t&&t.__v_isRef===!0),St=t=>Qt(t)?t:t==null?"":Ct(t)||jt(t)&&(t.toString===Dr||!It(t.toString))?Rr(t)?St(t.value):JSON.stringify(t,zr,2):String(t),zr=(t,i)=>Rr(i)?zr(t,i.value):ji(i)?{[`Map(${i.size})`]:[...i.entries()].reduce((e,[n,s],r)=>(e[ks(n,r)+" =>"]=s,e),{})}:Ji(i)?{[`Set(${i.size})`]:[...i.values()].map(e=>ks(e))}:De(i)?ks(i):jt(i)&&!Ct(i)&&!Or(i)?String(i):i,ks=(t,i="")=>{var e;return De(t)?`Symbol(${(e=t.description)!=null?e:i})`:t};/**
* @vue/reactivity v3.5.40
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/let ne;class Xa{constructor(i=!1){this.detached=i,this._active=!0,this._on=0,this.effects=[],this.cleanups=[],this._isPaused=!1,this._warnOnRun=!0,this.__v_skip=!0,!i&&ne&&(ne.active?(this.parent=ne,this.index=(ne.scopes||(ne.scopes=[])).push(this)-1):(this._active=!1,this._warnOnRun=!1))}get active(){return this._active}pause(){if(this._active){this._isPaused=!0;let i,e;if(this.scopes){const n=this.scopes.slice();for(i=0,e=n.length;i<e;i++)n[i].pause()}for(i=0,e=this.effects.length;i<e;i++)this.effects[i].pause()}}resume(){if(this._active&&this._isPaused){this._isPaused=!1;let i,e;if(this.scopes){const s=this.scopes.slice();for(i=0,e=s.length;i<e;i++)s[i].resume()}const n=this.effects.slice();for(i=0,e=n.length;i<e;i++)n[i].resume()}}run(i){if(this._active){const e=ne;try{return ne=this,i()}finally{ne=e}}}on(){++this._on===1&&(this.prevScope=ne,ne=this)}off(){if(this._on>0&&--this._on===0){if(ne===this)ne=this.prevScope;else{let i=ne;for(;i;){if(i.prevScope===this){i.prevScope=this.prevScope;break}i=i.prevScope}}this.prevScope=void 0}}stop(i){if(this._active){this._active=!1;let e,n;for(e=0,n=this.effects.length;e<n;e++)this.effects[e].stop();for(this.effects.length=0,e=0,n=this.cleanups.length;e<n;e++)this.cleanups[e]();if(this.cleanups.length=0,this.scopes){const s=this.scopes.slice();for(e=0,n=s.length;e<n;e++)s[e].stop(!0);this.scopes.length=0}if(!this.detached&&this.parent&&!i){const s=this.parent.scopes.pop();s&&s!==this&&(this.parent.scopes[this.index]=s,s.index=this.index)}this.parent=void 0}}}function Qa(){return ne}let Kt;const xs=new WeakSet;class Nr{constructor(i){this.fn=i,this.deps=void 0,this.depsTail=void 0,this.flags=5,this.next=void 0,this.cleanup=void 0,this.scheduler=void 0,ne&&(ne.active?ne.effects.push(this):this.flags&=-2)}pause(){this.flags|=64}resume(){this.flags&64&&(this.flags&=-65,xs.has(this)&&(xs.delete(this),this.trigger()))}notify(){this.flags&2&&!(this.flags&32)||this.flags&8||jr(this)}run(){if(!(this.flags&1))return this.fn();this.flags|=2,No(this),Hr(this);const i=Kt,e=Be;Kt=this,Be=!0;try{return this.fn()}finally{Ur(this),Kt=i,Be=e,this.flags&=-3}}stop(){if(this.flags&1){for(let i=this.deps;i;i=i.nextDep)lo(i);this.deps=this.depsTail=void 0,No(this),this.onStop&&this.onStop(),this.flags&=-2}}trigger(){this.flags&64?xs.add(this):this.scheduler?this.scheduler():this.runIfDirty()}runIfDirty(){Ns(this)&&this.run()}get dirty(){return Ns(this)}}let Fr=0,un,fn;function jr(t,i=!1){if(t.flags|=8,i){t.next=fn,fn=t;return}t.next=un,un=t}function oo(){Fr++}function ro(){if(--Fr>0)return;if(fn){let i=fn;for(fn=void 0;i;){const e=i.next;i.next=void 0,i.flags&=-9,i=e}}let t;for(;un;){let i=un;for(un=void 0;i;){const e=i.next;if(i.next=void 0,i.flags&=-9,i.flags&1)try{i.trigger()}catch(n){t||(t=n)}i=e}}if(t)throw t}function Hr(t){for(let i=t.deps;i;i=i.nextDep)i.version=-1,i.prevActiveLink=i.dep.activeLink,i.dep.activeLink=i}function Ur(t){let i,e=t.depsTail,n=e;for(;n;){const s=n.prevDep;n.version===-1?(n===e&&(e=s),lo(n),tc(n)):i=n,n.dep.activeLink=n.prevActiveLink,n.prevActiveLink=void 0,n=s}t.deps=i,t.depsTail=e}function Ns(t){for(let i=t.deps;i;i=i.nextDep)if(i.dep.version!==i.version||i.dep.computed&&(Wr(i.dep.computed)||i.dep.version!==i.version))return!0;return!!t._dirty}function Wr(t){if(t.flags&4&&!(t.flags&16)||(t.flags&=-17,t.globalVersion===gn)||(t.globalVersion=gn,!t.isSSR&&t.flags&128&&(!t.deps&&!t._dirty||!Ns(t))))return;t.flags|=2;const i=t.dep,e=Kt,n=Be;Kt=t,Be=!0;try{Hr(t);const s=t.fn(t._value);(i.version===0||Ue(s,t._value))&&(t.flags|=128,t._value=s,i.version++)}catch(s){throw i.version++,s}finally{Kt=e,Be=n,Ur(t),t.flags&=-3}}function lo(t,i=!1){const{dep:e,prevSub:n,nextSub:s}=t;if(n&&(n.nextSub=s,t.prevSub=void 0),s&&(s.prevSub=n,t.nextSub=void 0),e.subs===t&&(e.subs=n,!n&&e.computed)){e.computed.flags&=-5;for(let r=e.computed.deps;r;r=r.nextDep)lo(r,!0)}!i&&!--e.sc&&e.map&&e.map.delete(e.key)}function tc(t){const{prevDep:i,nextDep:e}=t;i&&(i.nextDep=e,t.prevDep=void 0),e&&(e.prevDep=i,t.nextDep=void 0)}let Be=!0;const Vr=[];function ii(){Vr.push(Be),Be=!1}function ni(){const t=Vr.pop();Be=t===void 0?!0:t}function No(t){const{cleanup:i}=t;if(t.cleanup=void 0,i){const e=Kt;Kt=void 0;try{i()}finally{Kt=e}}}let gn=0;class ec{constructor(i,e){this.sub=i,this.dep=e,this.version=e.version,this.nextDep=this.prevDep=this.nextSub=this.prevSub=this.prevActiveLink=void 0}}class ao{constructor(i){this.computed=i,this.version=0,this.activeLink=void 0,this.subs=void 0,this.map=void 0,this.key=void 0,this.sc=0,this.__v_skip=!0}track(i){if(!Kt||!Be||Kt===this.computed)return;let e=this.activeLink;if(e===void 0||e.sub!==Kt)e=this.activeLink=new ec(Kt,this),Kt.deps?(e.prevDep=Kt.depsTail,Kt.depsTail.nextDep=e,Kt.depsTail=e):Kt.deps=Kt.depsTail=e,Kr(e);else if(e.version===-1&&(e.version=this.version,e.nextDep)){const n=e.nextDep;n.prevDep=e.prevDep,e.prevDep&&(e.prevDep.nextDep=n),e.prevDep=Kt.depsTail,e.nextDep=void 0,Kt.depsTail.nextDep=e,Kt.depsTail=e,Kt.deps===e&&(Kt.deps=n)}return e}trigger(i){this.version++,gn++,this.notify(i)}notify(i){oo();try{for(let e=this.subs;e;e=e.prevSub)e.sub.notify()&&e.sub.dep.notify()}finally{ro()}}}function Kr(t){if(t.dep.sc++,t.sub.flags&4){const i=t.dep.computed;if(i&&!t.dep.subs){i.flags|=20;for(let n=i.deps;n;n=n.nextDep)Kr(n)}const e=t.dep.subs;e!==t&&(t.prevSub=e,e&&(e.nextSub=t)),t.dep.subs=t}}const Fs=new WeakMap,Ii=Symbol(""),js=Symbol(""),vn=Symbol("");function le(t,i,e){if(Be&&Kt){let n=Fs.get(t);n||Fs.set(t,n=new Map);let s=n.get(e);s||(n.set(e,s=new ao),s.map=n,s.key=e),s.track()}}function Je(t,i,e,n,s,r){const l=Fs.get(t);if(!l){gn++;return}const o=a=>{a&&a.trigger()};if(oo(),i==="clear")l.forEach(o);else{const a=Ct(t),c=a&&io(e);if(a&&e==="length"){const d=Number(n);l.forEach((h,m)=>{(m==="length"||m===vn||!De(m)&&m>=d)&&o(h)})}else switch((e!==void 0||l.has(void 0))&&o(l.get(e)),c&&o(l.get(vn)),i){case"add":a?c&&o(l.get("length")):(o(l.get(Ii)),ji(t)&&o(l.get(js)));break;case"delete":a||(o(l.get(Ii)),ji(t)&&o(l.get(js)));break;case"set":ji(t)&&o(l.get(Ii));break}}ro()}function Li(t){const i=Lt(t);return i===t?i:(le(i,"iterate",vn),Ce(t)?i:i.map(Oe))}function as(t){return le(t=Lt(t),"iterate",vn),t}function Fe(t,i){return si(t)?qi(Ai(t)?Oe(i):i):Oe(i)}const ic={__proto__:null,[Symbol.iterator](){return _s(this,Symbol.iterator,t=>Fe(this,t))},concat(...t){return Li(this).concat(...t.map(i=>Ct(i)?Li(i):i))},entries(){return _s(this,"entries",t=>(t[1]=Fe(this,t[1]),t))},every(t,i){return qe(this,"every",t,i,void 0,arguments)},filter(t,i){return qe(this,"filter",t,i,e=>e.map(n=>Fe(this,n)),arguments)},find(t,i){return qe(this,"find",t,i,e=>Fe(this,e),arguments)},findIndex(t,i){return qe(this,"findIndex",t,i,void 0,arguments)},findLast(t,i){return qe(this,"findLast",t,i,e=>Fe(this,e),arguments)},findLastIndex(t,i){return qe(this,"findLastIndex",t,i,void 0,arguments)},forEach(t,i){return qe(this,"forEach",t,i,void 0,arguments)},includes(...t){return Ss(this,"includes",t)},indexOf(...t){return Ss(this,"indexOf",t)},join(t){return Li(this).join(t)},lastIndexOf(...t){return Ss(this,"lastIndexOf",t)},map(t,i){return qe(this,"map",t,i,void 0,arguments)},pop(){return Qi(this,"pop")},push(...t){return Qi(this,"push",t)},reduce(t,...i){return Fo(this,"reduce",t,i)},reduceRight(t,...i){return Fo(this,"reduceRight",t,i)},shift(){return Qi(this,"shift")},some(t,i){return qe(this,"some",t,i,void 0,arguments)},splice(...t){return Qi(this,"splice",t)},toReversed(){return Li(this).toReversed()},toSorted(t){return Li(this).toSorted(t)},toSpliced(...t){return Li(this).toSpliced(...t)},unshift(...t){return Qi(this,"unshift",t)},values(){return _s(this,"values",t=>Fe(this,t))}};function _s(t,i,e){const n=as(t),s=n[i]();return n!==t&&!Ce(t)&&(s._next=s.next,s.next=()=>{const r=s._next();return r.done||(r.value=e(r.value)),r}),s}const nc=Array.prototype;function qe(t,i,e,n,s,r){const l=as(t),o=l!==t&&!Ce(t),a=l[i];if(a!==nc[i]){const h=a.apply(t,r);return o?Oe(h):h}let c=e;l!==t&&(o?c=function(h,m){return e.call(this,Fe(t,h),m,t)}:e.length>2&&(c=function(h,m){return e.call(this,h,m,t)}));const d=a.call(l,c,n);return o&&s?s(d):d}function Fo(t,i,e,n){const s=as(t),r=s!==t&&!Ce(t);let l=e,o=!1;s!==t&&(r?(o=n.length===0,l=function(c,d,h){return o&&(o=!1,c=Fe(t,c)),e.call(this,c,Fe(t,d),h,t)}):e.length>3&&(l=function(c,d,h){return e.call(this,c,d,h,t)}));const a=s[i](l,...n);return o?Fe(t,a):a}function Ss(t,i,e){const n=Lt(t);le(n,"iterate",vn);const s=n[i](...e);return(s===-1||s===!1)&&fo(e[0])?(e[0]=Lt(e[0]),n[i](...e)):s}function Qi(t,i,e=[]){ii(),oo();const n=Lt(t)[i].apply(t,e);return ro(),ni(),n}const sc=to("__proto__,__v_isRef,__isVue"),qr=new Set(Object.getOwnPropertyNames(Symbol).filter(t=>t!=="arguments"&&t!=="caller").map(t=>Symbol[t]).filter(De));function oc(t){De(t)||(t=String(t));const i=Lt(this);return le(i,"has",t),i.hasOwnProperty(t)}class Gr{constructor(i=!1,e=!1){this._isReadonly=i,this._isShallow=e}get(i,e,n){if(e==="__v_skip")return i.__v_skip;const s=this._isReadonly,r=this._isShallow;if(e==="__v_isReactive")return!s;if(e==="__v_isReadonly")return s;if(e==="__v_isShallow")return r;if(e==="__v_raw")return n===(s?r?mc:Xr:r?Jr:Yr).get(i)||Object.getPrototypeOf(i)===Object.getPrototypeOf(n)?i:void 0;const l=Ct(i);if(!s){let a;if(l&&(a=ic[e]))return a;if(e==="hasOwnProperty")return oc}const o=Reflect.get(i,e,de(i)?i:n);if((De(e)?qr.has(e):sc(e))||(s||le(i,"get",e),r))return o;if(de(o)){const a=l&&io(e)?o:o.value;return s&&jt(a)?Us(a):a}return jt(o)?s?Us(o):cs(o):o}}class Zr extends Gr{constructor(i=!1){super(!1,i)}set(i,e,n,s){let r=i[e];const l=Ct(i)&&io(e);if(!this._isShallow){const c=si(r);if(!Ce(n)&&!si(n)&&(r=Lt(r),n=Lt(n)),!l&&de(r)&&!de(n))return c||(r.value=n),!0}const o=l?Number(e)<i.length:Rt(i,e),a=Reflect.set(i,e,n,de(i)?i:s);return i===Lt(s)&&a&&(o?Ue(n,r)&&Je(i,"set",e,n):Je(i,"add",e,n)),a}deleteProperty(i,e){const n=Rt(i,e);i[e];const s=Reflect.deleteProperty(i,e);return s&&n&&Je(i,"delete",e,void 0),s}has(i,e){const n=Reflect.has(i,e);return(!De(e)||!qr.has(e))&&le(i,"has",e),n}ownKeys(i){return le(i,"iterate",Ct(i)?"length":Ii),Reflect.ownKeys(i)}}class rc extends Gr{constructor(i=!1){super(!0,i)}set(i,e){return!0}deleteProperty(i,e){return!0}}const lc=new Zr,ac=new rc,cc=new Zr(!0);const Hs=t=>t,Bn=t=>Reflect.getPrototypeOf(t);function dc(t,i,e){return function(...n){const s=this.__v_raw,r=Lt(s),l=ji(r),o=t==="entries"||t===Symbol.iterator&&l,a=t==="keys"&&l,c=s[t](...n),d=e?Hs:i?qi:Oe;return!i&&le(r,"iterate",a?js:Ii),re(Object.create(c),{next(){const{value:h,done:m}=c.next();return m?{value:h,done:m}:{value:o?[d(h[0]),d(h[1])]:d(h),done:m}}})}}function Dn(t){return function(...i){return t==="delete"?!1:t==="clear"?void 0:this}}function uc(t,i){const e={get(s){const r=this.__v_raw,l=Lt(r),o=Lt(s);t||(Ue(s,o)&&le(l,"get",s),le(l,"get",o));const{has:a}=Bn(l),c=i?Hs:t?qi:Oe;if(a.call(l,s))return c(r.get(s));if(a.call(l,o))return c(r.get(o));r!==l&&r.get(s)},get size(){const s=this.__v_raw;return!t&&le(Lt(s),"iterate",Ii),s.size},has(s){const r=this.__v_raw,l=Lt(r),o=Lt(s);return t||(Ue(s,o)&&le(l,"has",s),le(l,"has",o)),s===o?r.has(s):r.has(s)||r.has(o)},forEach(s,r){const l=this,o=l.__v_raw,a=Lt(o),c=i?Hs:t?qi:Oe;return!t&&le(a,"iterate",Ii),o.forEach((d,h)=>s.call(r,c(d),c(h),l))}};return re(e,t?{add:Dn("add"),set:Dn("set"),delete:Dn("delete"),clear:Dn("clear")}:{add(s){const r=Lt(this),l=Bn(r),o=Lt(s),a=!i&&!Ce(s)&&!si(s)?o:s;return l.has.call(r,a)||Ue(s,a)&&l.has.call(r,s)||Ue(o,a)&&l.has.call(r,o)||(r.add(a),Je(r,"add",a,a)),this},set(s,r){!i&&!Ce(r)&&!si(r)&&(r=Lt(r));const l=Lt(this),{has:o,get:a}=Bn(l);let c=o.call(l,s);c||(s=Lt(s),c=o.call(l,s));const d=a.call(l,s);return l.set(s,r),c?Ue(r,d)&&Je(l,"set",s,r):Je(l,"add",s,r),this},delete(s){const r=Lt(this),{has:l,get:o}=Bn(r);let a=l.call(r,s);a||(s=Lt(s),a=l.call(r,s)),o&&o.call(r,s);const c=r.delete(s);return a&&Je(r,"delete",s,void 0),c},clear(){const s=Lt(this),r=s.size!==0,l=s.clear();return r&&Je(s,"clear",void 0,void 0),l}}),["keys","values","entries",Symbol.iterator].forEach(s=>{e[s]=dc(s,t,i)}),e}function co(t,i){const e=uc(t,i);return(n,s,r)=>s==="__v_isReactive"?!t:s==="__v_isReadonly"?t:s==="__v_raw"?n:Reflect.get(Rt(e,s)&&s in n?e:n,s,r)}const fc={get:co(!1,!1)},pc={get:co(!1,!0)},hc={get:co(!0,!1)};const Yr=new WeakMap,Jr=new WeakMap,Xr=new WeakMap,mc=new WeakMap;function gc(t){switch(t){case"Object":case"Array":return 1;case"Map":case"Set":case"WeakMap":case"WeakSet":return 2;default:return 0}}function cs(t){return si(t)?t:uo(t,!1,lc,fc,Yr)}function vc(t){return uo(t,!1,cc,pc,Jr)}function Us(t){return uo(t,!0,ac,hc,Xr)}function uo(t,i,e,n,s){if(!jt(t)||t.__v_raw&&!(i&&t.__v_isReactive)||t.__v_skip||!Object.isExtensible(t))return t;const r=s.get(t);if(r)return r;const l=gc(Ha(t));if(l===0)return t;const o=new Proxy(t,l===2?n:e);return s.set(t,o),o}function Ai(t){return si(t)?Ai(t.__v_raw):!!(t&&t.__v_isReactive)}function si(t){return!!(t&&t.__v_isReadonly)}function Ce(t){return!!(t&&t.__v_isShallow)}function fo(t){return t?!!t.__v_raw:!1}function Lt(t){const i=t&&t.__v_raw;return i?Lt(i):t}function bc(t){return!Rt(t,"__v_skip")&&Object.isExtensible(t)&&Pr(t,"__v_skip",!0),t}const Oe=t=>jt(t)?cs(t):t,qi=t=>jt(t)?Us(t):t;function de(t){return t?t.__v_isRef===!0:!1}function ht(t){return yc(t,!1)}function yc(t,i){return de(t)?t:new wc(t,i)}class wc{constructor(i,e){this.dep=new ao,this.__v_isRef=!0,this.__v_isShallow=!1,this._rawValue=e?i:Lt(i),this._value=e?i:Oe(i),this.__v_isShallow=e}get value(){return this.dep.track(),this._value}set value(i){const e=this._rawValue,n=this.__v_isShallow||Ce(i)||si(i);i=n?i:Lt(i),Ue(i,e)&&(this._rawValue=i,this._value=n?i:Oe(i),this.dep.trigger())}}function Ci(t){return de(t)?t.value:t}const kc={get:(t,i,e)=>i==="__v_raw"?t:Ci(Reflect.get(t,i,e)),set:(t,i,e,n)=>{const s=t[i];return de(s)&&!de(e)?(s.value=e,!0):Reflect.set(t,i,e,n)}};function Qr(t){return Ai(t)?t:new Proxy(t,kc)}class xc{constructor(i,e,n){this.fn=i,this.setter=e,this._value=void 0,this.dep=new ao(this),this.__v_isRef=!0,this.deps=void 0,this.depsTail=void 0,this.flags=16,this.globalVersion=gn-1,this.next=void 0,this.effect=this,this.__v_isReadonly=!e,this.isSSR=n}notify(){if(this.flags|=16,!(this.flags&8)&&Kt!==this)return jr(this,!0),!0}get value(){const i=this.dep.track();return Wr(this),i&&(i.version=this.dep.version),this._value}set value(i){this.setter&&this.setter(i)}}function _c(t,i,e=!1){let n,s;return It(t)?n=t:(n=t.get,s=t.set),new xc(n,s,e)}const On={},qn=new WeakMap;let ki;function Sc(t,i=!1,e=ki){if(e){let n=qn.get(e);n||qn.set(e,n=[]),n.push(t)}}function Cc(t,i,e=Wt){const{immediate:n,deep:s,once:r,scheduler:l,augmentJob:o,call:a}=e,c=E=>s?E:Ce(E)||s===!1||s===0?Xe(E,1):Xe(E);let d,h,m,p,y=!1,f=!1;if(de(t)?(h=()=>t.value,y=Ce(t)):Ai(t)?(h=()=>c(t),y=!0):Ct(t)?(f=!0,y=t.some(E=>Ai(E)||Ce(E)),h=()=>t.map(E=>{if(de(E))return E.value;if(Ai(E))return c(E);if(It(E))return a?a(E,2):E()})):It(t)?i?h=a?()=>a(t,2):t:h=()=>{if(m){ii();try{m()}finally{ni()}}const E=ki;ki=d;try{return a?a(t,3,[p]):t(p)}finally{ki=E}}:h=Ve,i&&s){const E=h,_=s===!0?1/0:s;h=()=>Xe(E(),_)}const k=Qa(),v=()=>{d.stop(),k&&k.active&&eo(k.effects,d)};if(r&&i){const E=i;i=(..._)=>{const C=E(..._);return v(),C}}let w=f?new Array(t.length).fill(On):On;const x=E=>{if(!(!(d.flags&1)||!d.dirty&&!E))if(i){const _=d.run();if(E||s||y||(f?_.some((C,A)=>Ue(C,w[A])):Ue(_,w))){m&&m();const C=ki;ki=d;try{const A=[_,w===On?void 0:f&&w[0]===On?[]:w,p];w=_,a?a(i,3,A):i(...A)}finally{ki=C}}}else d.run()};return o&&o(x),d=new Nr(h),d.scheduler=l?()=>l(x,!1):x,p=E=>Sc(E,!1,d),m=d.onStop=()=>{const E=qn.get(d);if(E){if(a)a(E,4);else for(const _ of E)_();qn.delete(d)}},i?n?x(!0):w=d.run():l?l(x.bind(null,!0),!0):d.run(),v.pause=d.pause.bind(d),v.resume=d.resume.bind(d),v.stop=v,v}function Xe(t,i=1/0,e){if(i<=0||!jt(t)||t.__v_skip||(e=e||new Map,(e.get(t)||0)>=i))return t;if(e.set(t,i),i--,de(t))Xe(t.value,i,e);else if(Ct(t))for(let n=0;n<t.length;n++)Xe(t[n],i,e);else if(Ji(t)||ji(t))t.forEach(n=>{Xe(n,i,e)});else if(Or(t)){for(const n in t)Xe(t[n],i,e);for(const n of Object.getOwnPropertySymbols(t))Object.prototype.propertyIsEnumerable.call(t,n)&&Xe(t[n],i,e)}return t}/**
* @vue/runtime-core v3.5.40
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/function Sn(t,i,e,n){try{return n?t(...n):t()}catch(s){ds(s,i,e)}}function Pe(t,i,e,n){if(It(t)){const s=Sn(t,i,e,n);return s&&Br(s)&&s.catch(r=>{ds(r,i,e)}),s}if(Ct(t)){const s=[];for(let r=0;r<t.length;r++)s.push(Pe(t[r],i,e,n));return s}}function ds(t,i,e,n=!0){const s=i?i.vnode:null,{errorHandler:r,throwUnhandledErrorInProduction:l}=i&&i.appContext.config||Wt;if(i){let o=i.parent;const a=i.proxy,c=`https://vuejs.org/error-reference/#runtime-${e}`;for(;o;){const d=o.ec;if(d){for(let h=0;h<d.length;h++)if(d[h](t,a,c)===!1)return}o=o.parent}if(r){ii(),Sn(r,null,10,[t,a,c]),ni();return}}$c(t,e,s,n,l)}function $c(t,i,e,n=!0,s=!1){if(s)throw t;console.error(t)}const pe=[];let Ne=-1;const Hi=[];let ai=null,Ri=0;const tl=Promise.resolve();let Gn=null;function el(t){const i=Gn||tl;return t?i.then(this?t.bind(this):t):i}function Ic(t){let i=Ne+1,e=pe.length;for(;i<e;){const n=i+e>>>1,s=pe[n],r=bn(s);r<t||r===t&&s.flags&2?i=n+1:e=n}return i}function po(t){if(!(t.flags&1)){const i=bn(t),e=pe[pe.length-1];!e||!(t.flags&2)&&i>=bn(e)?pe.push(t):pe.splice(Ic(i),0,t),t.flags|=1,il()}}function il(){Gn||(Gn=tl.then(sl))}function Ac(t){Ct(t)?Hi.push(...t):ai&&t.id===-1?ai.splice(Ri+1,0,t):t.flags&1||(Hi.push(t),t.flags|=1),il()}function jo(t,i,e=Ne+1){for(;e<pe.length;e++){const n=pe[e];if(n&&n.flags&2){if(t&&n.id!==t.uid)continue;pe.splice(e,1),e--,n.flags&4&&(n.flags&=-2),n(),n.flags&4||(n.flags&=-2)}}}function nl(t){if(Hi.length){const i=[...new Set(Hi)].sort((e,n)=>bn(e)-bn(n));if(Hi.length=0,ai){ai.push(...i);return}for(ai=i,Ri=0;Ri<ai.length;Ri++){const e=ai[Ri];e.flags&4&&(e.flags&=-2),e.flags&8||e(),e.flags&=-2}ai=null,Ri=0}}const bn=t=>t.id==null?t.flags&2?-1:1/0:t.id;function sl(t){try{for(Ne=0;Ne<pe.length;Ne++){const i=pe[Ne];i&&!(i.flags&8)&&(i.flags&4&&(i.flags&=-2),Sn(i,i.i,i.i?15:14),i.flags&4||(i.flags&=-2))}}finally{for(;Ne<pe.length;Ne++){const i=pe[Ne];i&&(i.flags&=-2)}Ne=-1,pe.length=0,nl(),Gn=null,(pe.length||Hi.length)&&sl()}}let oe=null,ol=null;function Zn(t){const i=oe;return oe=t,ol=t&&t.type.__scopeId||null,i}function rl(t,i=oe,e){if(!i||t._n)return t;const n=(...s)=>{n._d&&Qo(-1);const r=Zn(i),l=ti.length;let o;try{o=t(...s)}finally{for(let a=ti.length;a>l;a--)yo();Zn(r),n._d&&Qo(1)}return o};return n._n=!0,n._c=!0,n._d=!0,n}function Ie(t,i){if(oe===null)return t;const e=hs(oe),n=t.dirs||(t.dirs=[]);for(let s=0;s<i.length;s++){let[r,l,o,a=Wt]=i[s];r&&(It(r)&&(r={mounted:r,updated:r}),r.deep&&Xe(l),n.push({dir:r,instance:e,value:l,oldValue:void 0,arg:o,modifiers:a}))}return t}function bi(t,i,e,n){const s=t.dirs,r=i&&i.dirs;for(let l=0;l<s.length;l++){const o=s[l];r&&(o.oldValue=r[l].value);let a=o.dir[n];a&&(ii(),Pe(a,e,8,[t.el,o,t,i]),ni())}}function Ec(t,i){if(ae){let e=ae.provides;const n=ae.parent&&ae.parent.provides;n===e&&(e=ae.provides=Object.create(n)),e[t]=i}}function Qe(t,i,e=!1){const n=Id();if(n||Wi){let s=Wi?Wi._context.provides:n?n.parent==null||n.ce?n.vnode.appContext&&n.vnode.appContext.provides:n.parent.provides:void 0;if(s&&t in s)return s[t];if(arguments.length>1)return e&&It(i)?i.call(n&&n.proxy):i}}const Tc=Symbol.for("v-scx"),Mc=()=>Qe(Tc);function Ei(t,i,e){return ll(t,i,e)}function ll(t,i,e=Wt){const{immediate:n,deep:s,flush:r,once:l}=e,o=re({},e),a=i&&n||!i&&r!=="post";let c;if(wn){if(r==="sync"){const p=Mc();c=p.__watcherHandles||(p.__watcherHandles=[])}else if(!a){const p=()=>{};return p.stop=Ve,p.resume=Ve,p.pause=Ve,p}}const d=ae;o.call=(p,y,f)=>Pe(p,d,y,f);let h=!1;r==="post"?o.scheduler=p=>{me(p,d&&d.suspense)}:r!=="sync"&&(h=!0,o.scheduler=(p,y)=>{y?p():po(p)}),o.augmentJob=p=>{i&&(p.flags|=4),h&&(p.flags|=2,d&&(p.id=d.uid,p.i=d))};const m=Cc(t,i,o);return wn&&(c?c.push(m):a&&m()),m}function Bc(t,i,e){const n=this.proxy,s=Qt(t)?t.includes(".")?al(n,t):()=>n[t]:t.bind(n,n);let r;It(i)?r=i:(r=i.handler,e=i);const l=$n(this),o=ll(s,r.bind(n),e);return l(),o}function al(t,i){const e=i.split(".");return()=>{let n=t;for(let s=0;s<e.length&&n;s++)n=n[e[s]];return n}}const Dc=Symbol("_vte"),Oc=t=>t.__isTeleport,Cs=Symbol("_leaveCb");function ho(t,i){t.shapeFlag&6&&t.component?(t.transition=i,ho(t.component.subTree,i)):t.shapeFlag&128?(t.ssContent.transition=i.clone(t.ssContent),t.ssFallback.transition=i.clone(t.ssFallback)):t.transition=i}function be(t,i){return It(t)?re({name:t.name},i,{setup:t}):t}function cl(t){t.ids=[t.ids[0]+t.ids[2]+++"-",0,0]}function Ho(t,i){let e;return!!((e=Object.getOwnPropertyDescriptor(t,i))&&!e.configurable)}const Yn=new WeakMap;function pn(t,i,e,n,s=!1){if(Ct(t)){t.forEach((f,k)=>pn(f,i&&(Ct(i)?i[k]:i),e,n,s));return}if(Ui(n)&&!s){n.shapeFlag&512&&n.type.__asyncResolved&&n.component.subTree.component&&pn(t,i,e,n.component.subTree);return}const r=n.shapeFlag&4?hs(n.component):n.el,l=s?null:r,{i:o,r:a}=t,c=i&&i.r,d=o.refs===Wt?o.refs={}:o.refs,h=o.setupState,m=Lt(h),p=h===Wt?Mr:f=>Ho(d,f)?!1:Rt(m,f),y=(f,k)=>!(k&&Ho(d,k));if(c!=null&&c!==a){if(Uo(i),Qt(c))d[c]=null,p(c)&&(h[c]=null);else if(de(c)){const f=i;y(c,f.k)&&(c.value=null),f.k&&(d[f.k]=null)}}if(It(a))Sn(a,o,12,[l,d]);else{const f=Qt(a),k=de(a);if(f||k){const v=()=>{if(t.f){const w=f?p(a)?h[a]:d[a]:y()||!t.k?a.value:d[t.k];if(s)Ct(w)&&eo(w,r);else if(Ct(w))w.includes(r)||w.push(r);else if(f)d[a]=[r],p(a)&&(h[a]=d[a]);else{const x=[r];y(a,t.k)&&(a.value=x),t.k&&(d[t.k]=x)}}else f?(d[a]=l,p(a)&&(h[a]=l)):k&&(y(a,t.k)&&(a.value=l),t.k&&(d[t.k]=l))};if(l){const w=()=>{v(),Yn.delete(t)};w.id=-1,Yn.set(t,w),me(w,e)}else Uo(t),v()}}}function Uo(t){const i=Yn.get(t);i&&(i.flags|=8,Yn.delete(t))}ls().requestIdleCallback;ls().cancelIdleCallback;const Ui=t=>!!t.type.__asyncLoader,dl=t=>t.type.__isKeepAlive;function Pc(t,i){ul(t,"a",i)}function Lc(t,i){ul(t,"da",i)}function ul(t,i,e=ae){const n=t.__wdc||(t.__wdc=()=>{let s=e;for(;s;){if(s.isDeactivated)return;s=s.parent}return t()});if(us(i,n,e),e){let s=e.parent;for(;s&&s.parent;)dl(s.parent.vnode)&&Rc(n,i,e,s),s=s.parent}}function Rc(t,i,e,n){const s=us(i,t,n,!0);go(()=>{eo(n[i],s)},e)}function us(t,i,e=ae,n=!1){if(e){const s=e[t]||(e[t]=[]),r=i.__weh||(i.__weh=(...l)=>{ii();const o=$n(e),a=Pe(i,e,t,l);return o(),ni(),a});return n?s.unshift(r):s.push(r),r}}const ri=t=>(i,e=ae)=>{(!wn||t==="sp")&&us(t,(...n)=>i(...n),e)},zc=ri("bm"),Cn=ri("m"),Nc=ri("bu"),Fc=ri("u"),mo=ri("bum"),go=ri("um"),jc=ri("sp"),Hc=ri("rtg"),Uc=ri("rtc");function Wc(t,i=ae){us("ec",t,i)}const Vc="components";function Kc(t,i){return Gc(Vc,t,!0,i)||t}const qc=Symbol.for("v-ndc");function Gc(t,i,e=!0,n=!1){const s=oe||ae;if(s){const r=s.type;{const o=Bd(r,!1);if(o&&(o===i||o===he(i)||o===os(he(i))))return r}const l=Wo(s[t]||r[t],i)||Wo(s.appContext[t],i);return!l&&n?r:l}}function Wo(t,i){return t&&(t[i]||t[he(i)]||t[os(he(i))])}function ye(t,i,e,n){let s;const r=e,l=Ct(t);if(l||Qt(t)){const o=l&&Ai(t);let a=!1,c=!1;o&&(a=!Ce(t),c=si(t),t=as(t)),s=new Array(t.length);for(let d=0,h=t.length;d<h;d++)s[d]=i(a?c?qi(Oe(t[d])):Oe(t[d]):t[d],d,void 0,r)}else if(typeof t=="number"){s=new Array(t);for(let o=0;o<t;o++)s[o]=i(o+1,o,void 0,r)}else if(jt(t))if(t[Symbol.iterator])s=Array.from(t,(o,a)=>i(o,a,void 0,r));else{const o=Object.keys(t);s=new Array(o.length);for(let a=0,c=o.length;a<c;a++){const d=o[a];s[a]=i(t[d],d,a,r)}}else s=[];return s}function Pn(t,i,e={},n,s,r){if(oe.ce||oe.parent&&Ui(oe.parent)&&oe.parent.ce){const c=e,d=Object.keys(c).length>0;return i!=="default"&&(c.name=i),tt(),Te(Gt,null,[pt("slot",c,n&&n())],d?-2:64)}let l=t[i];l&&l._c&&(l._d=!1);const o=ti.length;tt();let a;try{const c=l&&fl(l(e)),d=e.key||r||c&&c.key;a=Te(Gt,{key:(d&&!De(d)?d:`_${i}`)+(!c&&n?"_fb":"")},c||(n?n():[]),c&&t._===1?64:-2)}catch(c){for(let d=ti.length;d>o;d--)yo();throw c}finally{l&&l._c&&(l._d=!0)}return a}function fl(t){return t.some(i=>wo(i)?!(i.type===oi||i.type===Gt&&!fl(i.children)):!0)?t:null}const Ws=t=>t?Bl(t)?hs(t):Ws(t.parent):null,hn=re(Object.create(null),{$:t=>t,$el:t=>t.vnode.el,$data:t=>t.data,$props:t=>t.props,$attrs:t=>t.attrs,$slots:t=>t.slots,$refs:t=>t.refs,$parent:t=>Ws(t.parent),$root:t=>Ws(t.root),$host:t=>t.ce,$emit:t=>t.emit,$options:t=>hl(t),$forceUpdate:t=>t.f||(t.f=()=>{po(t.update)}),$nextTick:t=>t.n||(t.n=el.bind(t.proxy)),$watch:t=>Bc.bind(t)}),$s=(t,i)=>t!==Wt&&!t.__isScriptSetup&&Rt(t,i),Zc={get({_:t},i){if(i==="__v_skip")return!0;const{ctx:e,setupState:n,data:s,props:r,accessCache:l,type:o,appContext:a}=t;if(i[0]!=="$"){const m=l[i];if(m!==void 0)switch(m){case 1:return n[i];case 2:return s[i];case 4:return e[i];case 3:return r[i]}else{if($s(n,i))return l[i]=1,n[i];if(s!==Wt&&Rt(s,i))return l[i]=2,s[i];if(Rt(r,i))return l[i]=3,r[i];if(e!==Wt&&Rt(e,i))return l[i]=4,e[i];Vs&&(l[i]=0)}}const c=hn[i];let d,h;if(c)return i==="$attrs"&&le(t.attrs,"get",""),c(t);if((d=o.__cssModules)&&(d=d[i]))return d;if(e!==Wt&&Rt(e,i))return l[i]=4,e[i];if(h=a.config.globalProperties,Rt(h,i))return h[i]},set({_:t},i,e){const{data:n,setupState:s,ctx:r}=t;return $s(s,i)?(s[i]=e,!0):n!==Wt&&Rt(n,i)?(n[i]=e,!0):Rt(t.props,i)||i[0]==="$"&&i.slice(1)in t?!1:(r[i]=e,!0)},has({_:{data:t,setupState:i,accessCache:e,ctx:n,appContext:s,props:r,type:l}},o){let a;return!!(e[o]||t!==Wt&&o[0]!=="$"&&Rt(t,o)||$s(i,o)||Rt(r,o)||Rt(n,o)||Rt(hn,o)||Rt(s.config.globalProperties,o)||(a=l.__cssModules)&&a[o])},defineProperty(t,i,e){return e.get!=null?t._.accessCache[i]=0:Rt(e,"value")&&this.set(t,i,e.value,null),Reflect.defineProperty(t,i,e)}};function Vo(t){return Ct(t)?t.reduce((i,e)=>(i[e]=null,i),{}):t}let Vs=!0;function Yc(t){const i=hl(t),e=t.proxy,n=t.ctx;Vs=!1,i.beforeCreate&&Ko(i.beforeCreate,t,"bc");const{data:s,computed:r,methods:l,watch:o,provide:a,inject:c,created:d,beforeMount:h,mounted:m,beforeUpdate:p,updated:y,activated:f,deactivated:k,beforeDestroy:v,beforeUnmount:w,destroyed:x,unmounted:E,render:_,renderTracked:C,renderTriggered:A,errorCaptured:B,serverPrefetch:P,expose:R,inheritAttrs:X,components:S,directives:G,filters:b}=i;if(c&&Jc(c,n,null),l)for(const j in l){const st=l[j];It(st)&&(n[j]=st.bind(e))}if(s){const j=s.call(e,e);jt(j)&&(t.data=cs(j))}if(Vs=!0,r)for(const j in r){const st=r[j],K=It(st)?st.bind(e,e):It(st.get)?st.get.bind(e,e):Ve,Y=!It(st)&&It(st.set)?st.set.bind(e):Ve,H=$t({get:K,set:Y});Object.defineProperty(n,j,{enumerable:!0,configurable:!0,get:()=>H.value,set:L=>H.value=L})}if(o)for(const j in o)pl(o[j],n,e,j);if(a){const j=It(a)?a.call(e):a;Reflect.ownKeys(j).forEach(st=>{Ec(st,j[st])})}d&&Ko(d,t,"c");function it(j,st){Ct(st)?st.forEach(K=>j(K.bind(e))):st&&j(st.bind(e))}if(it(zc,h),it(Cn,m),it(Nc,p),it(Fc,y),it(Pc,f),it(Lc,k),it(Wc,B),it(Uc,C),it(Hc,A),it(mo,w),it(go,E),it(jc,P),Ct(R))if(R.length){const j=t.exposed||(t.exposed={});R.forEach(st=>{Object.defineProperty(j,st,{get:()=>e[st],set:K=>e[st]=K,enumerable:!0})})}else t.exposed||(t.exposed={});_&&t.render===Ve&&(t.render=_),X!=null&&(t.inheritAttrs=X),S&&(t.components=S),G&&(t.directives=G),P&&cl(t)}function Jc(t,i,e=Ve){Ct(t)&&(t=Ks(t));for(const n in t){const s=t[n];let r;jt(s)?"default"in s?r=Qe(s.from||n,s.default,!0):r=Qe(s.from||n):r=Qe(s),de(r)?Object.defineProperty(i,n,{enumerable:!0,configurable:!0,get:()=>r.value,set:l=>r.value=l}):i[n]=r}}function Ko(t,i,e){Pe(Ct(t)?t.map(n=>n.bind(i.proxy)):t.bind(i.proxy),i,e)}function pl(t,i,e,n){let s=n.includes(".")?al(e,n):()=>e[n];if(Qt(t)){const r=i[t];It(r)&&Ei(s,r)}else if(It(t))Ei(s,t.bind(e));else if(jt(t))if(Ct(t))t.forEach(r=>pl(r,i,e,n));else{const r=It(t.handler)?t.handler.bind(e):i[t.handler];It(r)&&Ei(s,r,t)}}function hl(t){const i=t.type,{mixins:e,extends:n}=i,{mixins:s,optionsCache:r,config:{optionMergeStrategies:l}}=t.appContext,o=r.get(i);let a;return o?a=o:!s.length&&!e&&!n?a=i:(a={},s.length&&s.forEach(c=>Jn(a,c,l,!0)),Jn(a,i,l)),jt(i)&&r.set(i,a),a}function Jn(t,i,e,n=!1){const{mixins:s,extends:r}=i;r&&Jn(t,r,e,!0),s&&s.forEach(l=>Jn(t,l,e,!0));for(const l in i)if(!(n&&l==="expose")){const o=Xc[l]||e&&e[l];t[l]=o?o(t[l],i[l]):i[l]}return t}const Xc={data:qo,props:Go,emits:Go,methods:sn,computed:sn,beforeCreate:ue,created:ue,beforeMount:ue,mounted:ue,beforeUpdate:ue,updated:ue,beforeDestroy:ue,beforeUnmount:ue,destroyed:ue,unmounted:ue,activated:ue,deactivated:ue,errorCaptured:ue,serverPrefetch:ue,components:sn,directives:sn,watch:td,provide:qo,inject:Qc};function qo(t,i){return i?t?function(){return re(It(t)?t.call(this,this):t,It(i)?i.call(this,this):i)}:i:t}function Qc(t,i){return sn(Ks(t),Ks(i))}function Ks(t){if(Ct(t)){const i={};for(let e=0;e<t.length;e++)i[t[e]]=t[e];return i}return t}function ue(t,i){return t?[...new Set([].concat(t,i))]:i}function sn(t,i){return t?re(Object.create(null),t,i):i}function Go(t,i){return t?Ct(t)&&Ct(i)?[...new Set([...t,...i])]:re(Object.create(null),Vo(t),Vo(i??{})):i}function td(t,i){if(!t)return i;if(!i)return t;const e=re(Object.create(null),t);for(const n in i)e[n]=ue(t[n],i[n]);return e}function ml(){return{app:null,config:{isNativeTag:Mr,performance:!1,globalProperties:{},optionMergeStrategies:{},errorHandler:void 0,warnHandler:void 0,compilerOptions:{}},mixins:[],components:{},directives:{},provides:Object.create(null),optionsCache:new WeakMap,propsCache:new WeakMap,emitsCache:new WeakMap}}let ed=0;function id(t,i){return function(n,s=null){It(n)||(n=re({},n)),s!=null&&!jt(s)&&(s=null);const r=ml(),l=new WeakSet,o=[];let a=!1;const c=r.app={_uid:ed++,_component:n,_props:s,_container:null,_context:r,_instance:null,version:Od,get config(){return r.config},set config(d){},use(d,...h){return l.has(d)||(d&&It(d.install)?(l.add(d),d.install(c,...h)):It(d)&&(l.add(d),d(c,...h))),c},mixin(d){return r.mixins.includes(d)||r.mixins.push(d),c},component(d,h){return h?(r.components[d]=h,c):r.components[d]},directive(d,h){return h?(r.directives[d]=h,c):r.directives[d]},mount(d,h,m){if(!a){const p=c._ceVNode||pt(n,s);return p.appContext=r,m===!0?m="svg":m===!1&&(m=void 0),t(p,d,m),a=!0,c._container=d,d.__vue_app__=c,hs(p.component)}},onUnmount(d){o.push(d)},unmount(){a&&(Pe(o,c._instance,16),t(null,c._container),delete c._container.__vue_app__)},provide(d,h){return r.provides[d]=h,c},runWithContext(d){const h=Wi;Wi=c;try{return d()}finally{Wi=h}}};return c}}let Wi=null;const nd=(t,i)=>i==="modelValue"||i==="model-value"?t.modelModifiers:t[`${i}Modifiers`]||t[`${he(i)}Modifiers`]||t[`${hi(i)}Modifiers`];function sd(t,i,...e){if(t.isUnmounted)return;const n=t.vnode.props||Wt;let s=e;const r=i.startsWith("update:"),l=r&&nd(n,i.slice(7));l&&(l.trim&&(s=e.map(d=>Qt(d)?d.trim():d)),l.number&&(s=e.map(rs)));let o,a=n[o=ws(i)]||n[o=ws(he(i))];!a&&r&&(a=n[o=ws(hi(i))]),a&&Pe(a,t,6,s);const c=n[o+"Once"];if(c){if(!t.emitted)t.emitted={};else if(t.emitted[o])return;t.emitted[o]=!0,Pe(c,t,6,s)}}const od=new WeakMap;function gl(t,i,e=!1){const n=e?od:i.emitsCache,s=n.get(t);if(s!==void 0)return s;const r=t.emits;let l={},o=!1;if(!It(t)){const a=c=>{const d=gl(c,i,!0);d&&(o=!0,re(l,d))};!e&&i.mixins.length&&i.mixins.forEach(a),t.extends&&a(t.extends),t.mixins&&t.mixins.forEach(a)}return!r&&!o?(jt(t)&&n.set(t,null),null):(Ct(r)?r.forEach(a=>l[a]=null):re(l,r),jt(t)&&n.set(t,l),l)}function fs(t,i){return!t||!is(i)?!1:(i=i.slice(2),i=i==="Once"?i:i.replace(/Once$/,""),Rt(t,i[0].toLowerCase()+i.slice(1))||Rt(t,hi(i))||Rt(t,i))}function Zo(t){const{type:i,vnode:e,proxy:n,withProxy:s,propsOptions:[r],slots:l,attrs:o,emit:a,render:c,renderCache:d,props:h,data:m,setupState:p,ctx:y,inheritAttrs:f}=t,k=Zn(t);let v,w;try{if(e.shapeFlag&4){const E=s||n,_=E;v=je(c.call(_,E,d,h,p,m,y)),w=o}else{const E=i;v=je(E.length>1?E(h,{attrs:o,slots:l,emit:a}):E(h,null)),w=i.props?o:rd(o)}}catch(E){ti.length=0,ds(E,t,1),v=pt(oi)}let x=v;if(w&&f!==!1){const E=Object.keys(w),{shapeFlag:_}=x;E.length&&_&7&&(r&&E.some(ns)&&(w=ld(w,r)),x=Gi(x,w,!1,!0))}return e.dirs&&(x=Gi(x,null,!1,!0),x.dirs=x.dirs?x.dirs.concat(e.dirs):e.dirs),e.transition&&ho(x,e.transition),v=x,Zn(k),v}const rd=t=>{let i;for(const e in t)(e==="class"||e==="style"||is(e))&&((i||(i={}))[e]=t[e]);return i},ld=(t,i)=>{const e={};for(const n in t)(!ns(n)||!(n.slice(9)in i))&&(e[n]=t[n]);return e};function ad(t,i,e){const{props:n,children:s,component:r}=t,{props:l,children:o,patchFlag:a}=i,c=r.emitsOptions;if(i.dirs||i.transition)return!0;if(e&&a>=0){if(a&1024)return!0;if(a&16)return n?Yo(n,l,c):!!l;if(a&8){const d=i.dynamicProps;for(let h=0;h<d.length;h++){const m=d[h];if(vl(l,n,m)&&!fs(c,m))return!0}}}else return(s||o)&&(!o||!o.$stable)?!0:n===l?!1:n?l?Yo(n,l,c):!0:!!l;return!1}function Yo(t,i,e){const n=Object.keys(i);if(n.length!==Object.keys(t).length)return!0;for(let s=0;s<n.length;s++){const r=n[s];if(vl(i,t,r)&&!fs(e,r))return!0}return!1}function vl(t,i,e){const n=t[e],s=i[e];return e==="style"&&jt(n)&&jt(s)?!Xi(n,s):n!==s}function cd({vnode:t,parent:i,suspense:e},n){for(;i;){const s=i.subTree;if(s.suspense&&s.suspense.activeBranch===t&&(s.suspense.vnode.el=s.el=n,t=s),s===t)(t=i.vnode).el=n,i=i.parent;else break}e&&e.activeBranch===t&&(e.vnode.el=n)}const bl={},yl=()=>Object.create(bl),wl=t=>Object.getPrototypeOf(t)===bl;function dd(t,i,e,n=!1){const s={},r=yl();t.propsDefaults=Object.create(null),kl(t,i,s,r);for(const l in t.propsOptions[0])l in s||(s[l]=void 0);e?t.props=n?s:vc(s):t.type.props?t.props=s:t.props=r,t.attrs=r}function ud(t,i,e,n){const{props:s,attrs:r,vnode:{patchFlag:l}}=t,o=Lt(s),[a]=t.propsOptions;let c=!1;if((n||l>0)&&!(l&16)){if(l&8){const d=t.vnode.dynamicProps;for(let h=0;h<d.length;h++){let m=d[h];if(fs(t.emitsOptions,m))continue;const p=i[m];if(a)if(Rt(r,m))p!==r[m]&&(r[m]=p,c=!0);else{const y=he(m);s[y]=qs(a,o,y,p,t,!1)}else p!==r[m]&&(r[m]=p,c=!0)}}}else{kl(t,i,s,r)&&(c=!0);let d;for(const h in o)(!i||!Rt(i,h)&&((d=hi(h))===h||!Rt(i,d)))&&(a?e&&(e[h]!==void 0||e[d]!==void 0)&&(s[h]=qs(a,o,h,void 0,t,!0)):delete s[h]);if(r!==o)for(const h in r)(!i||!Rt(i,h))&&(delete r[h],c=!0)}c&&Je(t.attrs,"set","")}function kl(t,i,e,n){const[s,r]=t.propsOptions;let l=!1,o;if(i)for(let a in i){if(dn(a))continue;const c=i[a];let d;s&&Rt(s,d=he(a))?!r||!r.includes(d)?e[d]=c:(o||(o={}))[d]=c:fs(t.emitsOptions,a)||(!(a in n)||c!==n[a])&&(n[a]=c,l=!0)}if(r){const a=Lt(e),c=o||Wt;for(let d=0;d<r.length;d++){const h=r[d];e[h]=qs(s,a,h,c[h],t,!Rt(c,h))}}return l}function qs(t,i,e,n,s,r){const l=t[e];if(l!=null){const o=Rt(l,"default");if(o&&n===void 0){const a=l.default;if(l.type!==Function&&!l.skipFactory&&It(a)){const{propsDefaults:c}=s;if(e in c)n=c[e];else{const d=$n(s);n=c[e]=a.call(null,i),d()}}else n=a;s.ce&&s.ce._setProp(e,n)}l[0]&&(r&&!o?n=!1:l[1]&&(n===""||n===hi(e))&&(n=!0))}return n}const fd=new WeakMap;function xl(t,i,e=!1){const n=e?fd:i.propsCache,s=n.get(t);if(s)return s;const r=t.props,l={},o=[];let a=!1;if(!It(t)){const d=h=>{a=!0;const[m,p]=xl(h,i,!0);re(l,m),p&&o.push(...p)};!e&&i.mixins.length&&i.mixins.forEach(d),t.extends&&d(t.extends),t.mixins&&t.mixins.forEach(d)}if(!r&&!a)return jt(t)&&n.set(t,Fi),Fi;if(Ct(r))for(let d=0;d<r.length;d++){const h=he(r[d]);Jo(h)&&(l[h]=Wt)}else if(r)for(const d in r){const h=he(d);if(Jo(h)){const m=r[d],p=l[h]=Ct(m)||It(m)?{type:m}:re({},m),y=p.type;let f=!1,k=!0;if(Ct(y))for(let v=0;v<y.length;++v){const w=y[v],x=It(w)&&w.name;if(x==="Boolean"){f=!0;break}else x==="String"&&(k=!1)}else f=It(y)&&y.name==="Boolean";p[0]=f,p[1]=k,(f||Rt(p,"default"))&&o.push(h)}}const c=[l,o];return jt(t)&&n.set(t,c),c}function Jo(t){return t[0]!=="$"&&!dn(t)}const vo=t=>t==="_"||t==="_ctx"||t==="$stable",bo=t=>Ct(t)?t.map(je):[je(t)],pd=(t,i,e)=>{if(i._n)return i;const n=rl((...s)=>bo(i(...s)),e);return n._c=!1,n},_l=(t,i,e)=>{const n=t._ctx;for(const s in t){if(vo(s))continue;const r=t[s];if(It(r))i[s]=pd(s,r,n);else if(r!=null){const l=bo(r);i[s]=()=>l}}},Sl=(t,i)=>{const e=bo(i);t.slots.default=()=>e},Cl=(t,i,e)=>{for(const n in i)(e||!vo(n))&&(t[n]=i[n])},hd=(t,i,e)=>{const n=t.slots=yl();if(t.vnode.shapeFlag&32){const s=i._;s?(Cl(n,i,e),e&&Pr(n,"_",s,!0)):_l(i,n)}else i&&Sl(t,i)},md=(t,i,e)=>{const{vnode:n,slots:s}=t;let r=!0,l=Wt;if(n.shapeFlag&32){const o=i._;o?e&&o===1?r=!1:Cl(s,i,e):(r=!i.$stable,_l(i,s)),l=i}else i&&(Sl(t,i),l={default:1});if(r)for(const o in s)!vo(o)&&l[o]==null&&delete s[o]},me=wd;function gd(t){return vd(t)}function vd(t,i){const e=ls();e.__VUE__=!0;const{insert:n,remove:s,patchProp:r,createElement:l,createText:o,createComment:a,setText:c,setElementText:d,parentNode:h,nextSibling:m,setScopeId:p=Ve,insertStaticContent:y}=t,f=(T,O,u,z=null,D=null,$=null,I=void 0,M=null,W=!!O.dynamicChildren)=>{if(T===O)return;T&&!tn(T,O)&&(z=mt(T),L(T,D,$,!0),T=null),O.patchFlag===-2&&(W=!1,O.dynamicChildren=null);const{type:N,ref:F,shapeFlag:q}=O;switch(N){case ps:k(T,O,u,z);break;case oi:v(T,O,u,z);break;case jn:T==null&&w(O,u,z,I);break;case Gt:S(T,O,u,z,D,$,I,M,W);break;default:q&1?_(T,O,u,z,D,$,I,M,W):q&6?G(T,O,u,z,D,$,I,M,W):(q&64||q&128)&&N.process(T,O,u,z,D,$,I,M,W,lt)}F!=null&&D?pn(F,T&&T.ref,$,O||T,!O):F==null&&T&&T.ref!=null&&pn(T.ref,null,$,T,!0)},k=(T,O,u,z)=>{if(T==null)n(O.el=o(O.children),u,z);else{const D=O.el=T.el;O.children!==T.children&&c(D,O.children)}},v=(T,O,u,z)=>{T==null?n(O.el=a(O.children||""),u,z):O.el=T.el},w=(T,O,u,z)=>{[T.el,T.anchor]=y(T.children,O,u,z,T.el,T.anchor)},x=({el:T,anchor:O},u,z)=>{let D;for(;T&&T!==O;)D=m(T),n(T,u,z),T=D;n(O,u,z)},E=({el:T,anchor:O})=>{let u;for(;T&&T!==O;)u=m(T),s(T),T=u;s(O)},_=(T,O,u,z,D,$,I,M,W)=>{if(O.type==="svg"?I="svg":O.type==="math"&&(I="mathml"),T==null)C(O,u,z,D,$,I,M,W);else{const N=T.el&&T.el._isVueCE?T.el:null;try{N&&N._beginPatch(),P(T,O,D,$,I,M,W)}finally{N&&N._endPatch()}}},C=(T,O,u,z,D,$,I,M)=>{let W,N;const{props:F,shapeFlag:q,transition:et,dirs:Q}=T;if(W=T.el=l(T.type,$,F&&F.is,F),q&8?d(W,T.children):q&16&&B(T.children,W,null,z,D,Is(T,$),I,M),Q&&bi(T,null,z,"created"),A(W,T,T.scopeId,I,z),F){for(const xt in F)xt!=="value"&&!dn(xt)&&r(W,xt,null,F[xt],$,z);"value"in F&&r(W,"value",null,F.value,$),(N=F.onVnodeBeforeMount)&&ze(N,z,T)}Q&&bi(T,null,z,"beforeMount");const dt=bd(D,et);dt&&et.beforeEnter(W),n(W,O,u),((N=F&&F.onVnodeMounted)||dt||Q)&&me(()=>{try{N&&ze(N,z,T),dt&&et.enter(W),Q&&bi(T,null,z,"mounted")}finally{}},D)},A=(T,O,u,z,D)=>{if(u&&p(T,u),z)for(let $=0;$<z.length;$++)p(T,z[$]);if(D){let $=D.subTree;if(O===$||El($.type)&&($.ssContent===O||$.ssFallback===O)){const I=D.vnode;A(T,I,I.scopeId,I.slotScopeIds,D.parent)}}},B=(T,O,u,z,D,$,I,M,W=0)=>{for(let N=W;N<T.length;N++){const F=T[N]=M?Ye(T[N]):je(T[N]);f(null,F,O,u,z,D,$,I,M)}},P=(T,O,u,z,D,$,I)=>{const M=O.el=T.el;let{patchFlag:W,dynamicChildren:N,dirs:F}=O;W|=T.patchFlag&16;const q=T.props||Wt,et=O.props||Wt;let Q;if(u&&yi(u,!1),(Q=et.onVnodeBeforeUpdate)&&ze(Q,u,O,T),F&&bi(O,T,u,"beforeUpdate"),u&&yi(u,!0),N&&(!T.dynamicChildren||T.dynamicChildren.length!==N.length)&&(W=0,I=!1,N=null),(q.innerHTML&&et.innerHTML==null||q.textContent&&et.textContent==null)&&d(M,""),N?R(T.dynamicChildren,N,M,u,z,Is(O,D),$):I||st(T,O,M,null,u,z,Is(O,D),$,!1),W>0){if(W&16)X(M,q,et,u,D);else if(W&2&&q.class!==et.class&&r(M,"class",null,et.class,D),W&4&&r(M,"style",q.style,et.style,D),W&8){const dt=O.dynamicProps;for(let xt=0;xt<dt.length;xt++){const bt=dt[xt],Mt=q[bt],Vt=et[bt];(Vt!==Mt||bt==="value")&&r(M,bt,Mt,Vt,D,u)}}W&1&&T.children!==O.children&&d(M,O.children)}else!I&&N==null&&X(M,q,et,u,D);((Q=et.onVnodeUpdated)||F)&&me(()=>{Q&&ze(Q,u,O,T),F&&bi(O,T,u,"updated")},z)},R=(T,O,u,z,D,$,I)=>{for(let M=0;M<O.length;M++){const W=T[M],N=O[M],F=W.el&&(W.type===Gt||!tn(W,N)||W.shapeFlag&198)?h(W.el):u;f(W,N,F,null,z,D,$,I,!0)}},X=(T,O,u,z,D)=>{if(O!==u){if(O!==Wt)for(const $ in O)!dn($)&&!($ in u)&&r(T,$,O[$],null,D,z);for(const $ in u){if(dn($))continue;const I=u[$],M=O[$];I!==M&&$!=="value"&&r(T,$,M,I,D,z)}"value"in u&&r(T,"value",O.value,u.value,D)}},S=(T,O,u,z,D,$,I,M,W)=>{const N=O.el=T?T.el:o(""),F=O.anchor=T?T.anchor:o("");let{patchFlag:q,dynamicChildren:et,slotScopeIds:Q}=O;Q&&(M=M?M.concat(Q):Q),T==null?(n(N,u,z),n(F,u,z),B(O.children||[],u,F,D,$,I,M,W)):q>0&&q&64&&et&&T.dynamicChildren&&T.dynamicChildren.length===et.length?(R(T.dynamicChildren,et,u,D,$,I,M),(O.key!=null||D&&O===D.subTree)&&$l(T,O,!0)):st(T,O,u,F,D,$,I,M,W)},G=(T,O,u,z,D,$,I,M,W)=>{O.slotScopeIds=M,T==null?O.shapeFlag&512?D.ctx.activate(O,u,z,I,W):b(O,u,z,D,$,I,W):U(T,O,W)},b=(T,O,u,z,D,$,I)=>{const M=T.component=$d(T,z,D);if(dl(T)&&(M.ctx.renderer=lt),Ad(M,!1,I),M.asyncDep){if(D&&D.registerDep(M,it,I),!T.el){const W=M.subTree=pt(oi);v(null,W,O,u),T.placeholder=W.el}}else it(M,T,O,u,D,$,I)},U=(T,O,u)=>{const z=O.component=T.component;if(ad(T,O,u))if(z.asyncDep&&!z.asyncResolved){j(z,O,u);return}else z.next=O,z.update();else O.el=T.el,z.vnode=O},it=(T,O,u,z,D,$,I)=>{const M=()=>{if(T.isMounted){let{next:q,bu:et,u:Q,parent:dt,vnode:xt}=T;{const ee=Il(T);if(ee){q&&(q.el=xt.el,j(T,q,I)),ee.asyncDep.then(()=>{me(()=>{T.isUnmounted||N()},D)});return}}let bt=q,Mt;yi(T,!1),q?(q.el=xt.el,j(T,q,I)):q=xt,et&&Fn(et),(Mt=q.props&&q.props.onVnodeBeforeUpdate)&&ze(Mt,dt,q,xt),yi(T,!0);const Vt=Zo(T),Yt=T.subTree;T.subTree=Vt,f(Yt,Vt,h(Yt.el),mt(Yt),T,D,$),q.el=Vt.el,bt===null&&cd(T,Vt.el),Q&&me(Q,D),(Mt=q.props&&q.props.onVnodeUpdated)&&me(()=>ze(Mt,dt,q,xt),D)}else{let q;const{el:et,props:Q}=O,{bm:dt,m:xt,parent:bt,root:Mt,type:Vt}=T,Yt=Ui(O);yi(T,!1),dt&&Fn(dt),!Yt&&(q=Q&&Q.onVnodeBeforeMount)&&ze(q,bt,O),yi(T,!0);{Mt.ce&&Mt.ce._hasShadowRoot()&&Mt.ce._injectChildStyle(Vt,T.parent?T.parent.type:void 0);const ee=T.subTree=Zo(T);f(null,ee,u,z,T,D,$),O.el=ee.el}if(xt&&me(xt,D),!Yt&&(q=Q&&Q.onVnodeMounted)){const ee=O;me(()=>ze(q,bt,ee),D)}(O.shapeFlag&256||bt&&Ui(bt.vnode)&&bt.vnode.shapeFlag&256)&&T.a&&me(T.a,D),T.isMounted=!0,O=u=z=null}};T.scope.on();const W=T.effect=new Nr(M);T.scope.off();const N=T.update=W.run.bind(W),F=T.job=W.runIfDirty.bind(W);F.i=T,F.id=T.uid,W.scheduler=()=>po(F),yi(T,!0),N()},j=(T,O,u)=>{O.component=T;const z=T.vnode.props;T.vnode=O,T.next=null,ud(T,O.props,z,u),md(T,O.children,u),ii(),jo(T),ni()},st=(T,O,u,z,D,$,I,M,W=!1)=>{const N=T&&T.children,F=T?T.shapeFlag:0,q=O.children,{patchFlag:et,shapeFlag:Q}=O;if(et>0){if(et&128){Y(N,q,u,z,D,$,I,M,W);return}else if(et&256){K(N,q,u,z,D,$,I,M,W);return}}Q&8?(F&16&&J(N,D,$),q!==N&&d(u,q)):F&16?Q&16?Y(N,q,u,z,D,$,I,M,W):J(N,D,$,!0):(F&8&&d(u,""),Q&16&&B(q,u,z,D,$,I,M,W))},K=(T,O,u,z,D,$,I,M,W)=>{T=T||Fi,O=O||Fi;const N=T.length,F=O.length,q=Math.min(N,F);let et;for(et=0;et<q;et++){const Q=O[et]=W?Ye(O[et]):je(O[et]);f(T[et],Q,u,null,D,$,I,M,W)}N>F?J(T,D,$,!0,!1,q):B(O,u,z,D,$,I,M,W,q)},Y=(T,O,u,z,D,$,I,M,W)=>{let N=0;const F=O.length;let q=T.length-1,et=F-1;for(;N<=q&&N<=et;){const Q=T[N],dt=O[N]=W?Ye(O[N]):je(O[N]);if(tn(Q,dt))f(Q,dt,u,null,D,$,I,M,W);else break;N++}for(;N<=q&&N<=et;){const Q=T[q],dt=O[et]=W?Ye(O[et]):je(O[et]);if(tn(Q,dt))f(Q,dt,u,null,D,$,I,M,W);else break;q--,et--}if(N>q){if(N<=et){const Q=et+1,dt=Q<F?O[Q].el:z;for(;N<=et;)f(null,O[N]=W?Ye(O[N]):je(O[N]),u,dt,D,$,I,M,W),N++}}else if(N>et)for(;N<=q;)L(T[N],D,$,!0),N++;else{const Q=N,dt=N,xt=new Map;for(N=dt;N<=et;N++){const te=O[N]=W?Ye(O[N]):je(O[N]);te.key!=null&&xt.set(te.key,N)}let bt,Mt=0;const Vt=et-dt+1;let Yt=!1,ee=0;const Nt=new Array(Vt);for(N=0;N<Vt;N++)Nt[N]=0;for(N=Q;N<=q;N++){const te=T[N];if(Mt>=Vt){L(te,D,$,!0);continue}let Jt;if(te.key!=null)Jt=xt.get(te.key);else for(bt=dt;bt<=et;bt++)if(Nt[bt-dt]===0&&tn(te,O[bt])){Jt=bt;break}Jt===void 0?L(te,D,$,!0):(Nt[Jt-dt]=N+1,Jt>=ee?ee=Jt:Yt=!0,f(te,O[Jt],u,null,D,$,I,M,W),Mt++)}const Ke=Yt?yd(Nt):Fi;for(bt=Ke.length-1,N=Vt-1;N>=0;N--){const te=dt+N,Jt=O[te],mi=O[te+1],Bi=te+1<F?mi.el||Al(mi):z;Nt[N]===0?f(null,Jt,u,Bi,D,$,I,M,W):Yt&&(bt<0||N!==Ke[bt]?H(Jt,u,Bi,2):bt--)}}},H=(T,O,u,z,D=null)=>{const{el:$,type:I,transition:M,children:W,shapeFlag:N}=T;if(N&6){H(T.component.subTree,O,u,z);return}if(N&128){T.suspense.move(O,u,z);return}if(N&64){I.move(T,O,u,lt);return}if(I===Gt){n($,O,u);for(let q=0;q<W.length;q++)H(W[q],O,u,z);n(T.anchor,O,u);return}if(I===jn){x(T,O,u);return}if(z!==2&&N&1&&M)if(z===0)M.persisted&&!$[Cs]?n($,O,u):(M.beforeEnter($),n($,O,u),me(()=>M.enter($),D));else{const{leave:q,delayLeave:et,afterLeave:Q}=M,dt=()=>{T.ctx.isUnmounted?s($):n($,O,u)},xt=()=>{const bt=$._isLeaving||!!$[Cs];$._isLeaving&&$[Cs](!0),M.persisted&&!bt?dt():q($,()=>{dt(),Q&&Q()})};et?et($,dt,xt):xt()}else n($,O,u)},L=(T,O,u,z=!1,D=!1)=>{const{type:$,props:I,ref:M,children:W,dynamicChildren:N,shapeFlag:F,patchFlag:q,dirs:et,cacheIndex:Q,memo:dt}=T;if(q===-2&&(D=!1),M!=null&&(ii(),pn(M,null,u,T,!0),ni()),Q!=null&&(O.renderCache[Q]=void 0),F&256){O.ctx.deactivate(T);return}const xt=F&1&&et,bt=!Ui(T);let Mt;if(bt&&(Mt=I&&I.onVnodeBeforeUnmount)&&ze(Mt,O,T),F&6)ot(T.component,u,z);else{if(F&128){T.suspense.unmount(u,z);return}xt&&bi(T,null,O,"beforeUnmount"),F&64?T.type.remove(T,O,u,lt,z):N&&!N.hasOnce&&($!==Gt||q>0&&q&64)?J(N,O,u,!1,!0):($===Gt&&q&384||!D&&F&16)&&J(W,O,u),z&&ct(T)}const Vt=dt!=null&&Q==null;(bt&&(Mt=I&&I.onVnodeUnmounted)||xt||Vt)&&me(()=>{Mt&&ze(Mt,O,T),xt&&bi(T,null,O,"unmounted"),Vt&&(T.el=null)},u)},ct=T=>{const{type:O,el:u,anchor:z,transition:D}=T;if(O===Gt){rt(u,z);return}if(O===jn){E(T);return}const $=()=>{s(u),D&&!D.persisted&&D.afterLeave&&D.afterLeave()};if(T.shapeFlag&1&&D&&!D.persisted){const{leave:I,delayLeave:M}=D,W=()=>I(u,$);M?M(T.el,$,W):W()}else $()},rt=(T,O)=>{let u;for(;T!==O;)u=m(T),s(T),T=u;s(O)},ot=(T,O,u)=>{const{bum:z,scope:D,job:$,subTree:I,um:M,m:W,a:N}=T;Xo(W),Xo(N),z&&Fn(z),D.stop(),$&&($.flags|=8,L(I,T,O,u)),M&&me(M,O),me(()=>{T.isUnmounted=!0},O)},J=(T,O,u,z=!1,D=!1,$=0)=>{for(let I=$;I<T.length;I++)L(T[I],O,u,z,D)},mt=T=>{if(T.shapeFlag&6)return mt(T.component.subTree);if(T.shapeFlag&128)return T.suspense.next();const O=m(T.anchor||T.el),u=O&&O[Dc];return u?m(u):O};let gt=!1;const Z=(T,O,u)=>{let z;T==null?O._vnode&&(L(O._vnode,null,null,!0),z=O._vnode.component):f(O._vnode||null,T,O,null,null,null,u),O._vnode=T,gt||(gt=!0,jo(z),nl(),gt=!1)},lt={p:f,um:L,m:H,r:ct,mt:b,mc:B,pc:st,pbc:R,n:mt,o:t};return{render:Z,hydrate:void 0,createApp:id(Z)}}function Is({type:t,props:i},e){return e==="svg"&&t==="foreignObject"||e==="mathml"&&t==="annotation-xml"&&i&&i.encoding&&i.encoding.includes("html")?void 0:e}function yi({effect:t,job:i},e){e?(t.flags|=32,i.flags|=4):(t.flags&=-33,i.flags&=-5)}function bd(t,i){return(!t||t&&!t.pendingBranch)&&i&&!i.persisted}function $l(t,i,e=!1){const n=t.children,s=i.children;if(Ct(n)&&Ct(s))for(let r=0;r<n.length;r++){const l=n[r];let o=s[r];o.shapeFlag&1&&!o.dynamicChildren&&((o.patchFlag<=0||o.patchFlag===32)&&(o=s[r]=Ye(s[r]),o.el=l.el),!e&&o.patchFlag!==-2&&$l(l,o)),o.type===ps&&(o.patchFlag===-1&&(o=s[r]=Ye(o)),o.el=l.el),o.type===oi&&!o.el&&(o.el=l.el)}}function yd(t){const i=t.slice(),e=[0];let n,s,r,l,o;const a=t.length;for(n=0;n<a;n++){const c=t[n];if(c!==0){if(s=e[e.length-1],t[s]<c){i[n]=s,e.push(n);continue}for(r=0,l=e.length-1;r<l;)o=r+l>>1,t[e[o]]<c?r=o+1:l=o;c<t[e[r]]&&(r>0&&(i[n]=e[r-1]),e[r]=n)}}for(r=e.length,l=e[r-1];r-- >0;)e[r]=l,l=i[l];return e}function Il(t){const i=t.subTree.component;if(i)return i.asyncDep&&!i.asyncResolved?i:Il(i)}function Xo(t){if(t)for(let i=0;i<t.length;i++)t[i].flags|=8}function Al(t){if(t.placeholder)return t.placeholder;const i=t.component;return i?Al(i.subTree):null}const El=t=>t.__isSuspense;function wd(t,i){i&&i.pendingBranch?Ct(t)?i.effects.push(...t):i.effects.push(t):Ac(t)}const Gt=Symbol.for("v-fgt"),ps=Symbol.for("v-txt"),oi=Symbol.for("v-cmt"),jn=Symbol.for("v-stc"),ti=[];let we=null;function tt(t=!1){ti.push(we=t?null:[])}function yo(){ti.pop(),we=ti[ti.length-1]||null}let yn=1;function Qo(t,i=!1){yn+=t,t<0&&we&&i&&(we.hasOnce=!0)}function Tl(t){return t.dynamicChildren=yn>0?we||Fi:null,yo(),yn>0&&we&&we.push(t),t}function nt(t,i,e,n,s,r){return Tl(g(t,i,e,n,s,r,!0))}function Te(t,i,e,n,s){return Tl(pt(t,i,e,n,s,!0))}function wo(t){return t?t.__v_isVNode===!0:!1}function tn(t,i){return t.type===i.type&&t.key===i.key}const Ml=({key:t})=>t??null,Hn=({ref:t,ref_key:i,ref_for:e})=>(typeof t=="number"&&(t=""+t),t!=null?Qt(t)||de(t)||It(t)?{i:oe,r:t,k:i,f:!!e}:t:null);function g(t,i=null,e=null,n=0,s=null,r=t===Gt?0:1,l=!1,o=!1){const a={__v_isVNode:!0,__v_skip:!0,type:t,props:i,key:i&&Ml(i),ref:i&&Hn(i),scopeId:ol,slotScopeIds:null,children:e,component:null,suspense:null,ssContent:null,ssFallback:null,dirs:null,transition:null,el:null,anchor:null,target:null,targetStart:null,targetAnchor:null,staticCount:0,shapeFlag:r,patchFlag:n,dynamicProps:s,dynamicChildren:null,appContext:null,ctx:oe};return o?(Xn(a,e),r&128&&t.normalize(a)):e&&(a.shapeFlag|=Qt(e)?8:16),yn>0&&!l&&we&&(a.patchFlag>0||r&6)&&a.patchFlag!==32&&we.push(a),a}const pt=kd;function kd(t,i=null,e=null,n=0,s=null,r=!1){if((!t||t===qc)&&(t=oi),wo(t)){const o=Gi(t,i,!0);return e&&Xn(o,e),yn>0&&!r&&we&&(o.shapeFlag&6?we[we.indexOf(t)]=o:we.push(o)),o.patchFlag=-2,o}if(Dd(t)&&(t=t.__vccOpts),i){i=xd(i);let{class:o,style:a}=i;o&&!Qt(o)&&(i.class=Tt(o)),jt(a)&&(fo(a)&&!Ct(a)&&(a=re({},a)),i.style=no(a))}const l=Qt(t)?1:El(t)?128:Oc(t)?64:jt(t)?4:It(t)?2:0;return g(t,i,e,n,s,l,r,!0)}function xd(t){return t?fo(t)||wl(t)?re({},t):t:null}function Gi(t,i,e=!1,n=!1){const{props:s,ref:r,patchFlag:l,children:o,transition:a}=t,c=i?_d(s||{},i):s,d={__v_isVNode:!0,__v_skip:!0,type:t.type,props:c,key:c&&Ml(c),ref:i&&i.ref?e&&r?Ct(r)?r.concat(Hn(i)):[r,Hn(i)]:Hn(i):r,scopeId:t.scopeId,slotScopeIds:t.slotScopeIds,children:o,target:t.target,targetStart:t.targetStart,targetAnchor:t.targetAnchor,staticCount:t.staticCount,shapeFlag:t.shapeFlag,patchFlag:i&&t.type!==Gt?l===-1?16:l|16:l,dynamicProps:t.dynamicProps,dynamicChildren:t.dynamicChildren,appContext:t.appContext,dirs:t.dirs,transition:a,component:t.component,suspense:t.suspense,ssContent:t.ssContent&&Gi(t.ssContent),ssFallback:t.ssFallback&&Gi(t.ssFallback),placeholder:t.placeholder,el:t.el,anchor:t.anchor,ctx:t.ctx,ce:t.ce};return a&&n&&ho(d,a.clone(d)),d}function Gs(t=" ",i=0){return pt(ps,null,t,i)}function $e(t,i){const e=pt(jn,null,t);return e.staticCount=i,e}function Ft(t="",i=!1){return i?(tt(),Te(oi,null,t)):pt(oi,null,t)}function je(t){return t==null||typeof t=="boolean"?pt(oi):Ct(t)?pt(Gt,null,t.slice()):wo(t)?Ye(t):pt(ps,null,String(t))}function Ye(t){return t.el===null&&t.patchFlag!==-1||t.memo?t:Gi(t)}function Xn(t,i){let e=0;const{shapeFlag:n}=t;if(i==null)i=null;else if(Ct(i))e=16;else if(typeof i=="object")if(n&65){const s=i.default;s&&(s._c&&(s._d=!1),Xn(t,s()),s._c&&(s._d=!0));return}else{e=32;const s=i._;!s&&!wl(i)?i._ctx=oe:s===3&&oe&&(oe.slots._===1?i._=1:(i._=2,t.patchFlag|=1024))}else if(It(i)){if(n&65){Xn(t,{default:i});return}i={default:i,_ctx:oe},e=32}else i=String(i),n&64?(e=16,i=[Gs(i)]):e=8;t.children=i,t.shapeFlag|=e}function _d(...t){const i={};for(let e=0;e<t.length;e++){const n=t[e];for(const s in n)if(s==="class")i.class!==n.class&&(i.class=Tt([i.class,n.class]));else if(s==="style")i.style=no([i.style,n.style]);else if(is(s)){const r=i[s],l=n[s];l&&r!==l&&!(Ct(r)&&r.includes(l))?i[s]=r?[].concat(r,l):l:l==null&&r==null&&!ns(s)&&(i[s]=l)}else s!==""&&(i[s]=n[s])}return i}function ze(t,i,e,n=null){Pe(t,i,7,[e,n])}const Sd=ml();let Cd=0;function $d(t,i,e){const n=t.type,s=(i?i.appContext:t.appContext)||Sd,r={uid:Cd++,vnode:t,type:n,parent:i,appContext:s,root:null,next:null,subTree:null,effect:null,update:null,job:null,scope:new Xa(!0),render:null,proxy:null,exposed:null,exposeProxy:null,withProxy:null,provides:i?i.provides:Object.create(s.provides),ids:i?i.ids:["",0,0],accessCache:null,renderCache:[],components:null,directives:null,propsOptions:xl(n,s),emitsOptions:gl(n,s),emit:null,emitted:null,propsDefaults:Wt,inheritAttrs:n.inheritAttrs,ctx:Wt,data:Wt,props:Wt,attrs:Wt,slots:Wt,refs:Wt,setupState:Wt,setupContext:null,suspense:e,suspenseId:e?e.pendingId:0,asyncDep:null,asyncResolved:!1,isMounted:!1,isUnmounted:!1,isDeactivated:!1,bc:null,c:null,bm:null,m:null,bu:null,u:null,um:null,bum:null,da:null,a:null,rtg:null,rtc:null,ec:null,sp:null};return r.ctx={_:r},r.root=i?i.root:r,r.emit=sd.bind(null,r),t.ce&&t.ce(r),r}let ae=null;const Id=()=>ae||oe;let Qn,Zs;{const t=ls(),i=(e,n)=>{let s;return(s=t[e])||(s=t[e]=[]),s.push(n),r=>{s.length>1?s.forEach(l=>l(r)):s[0](r)}};Qn=i("__VUE_INSTANCE_SETTERS__",e=>ae=e),Zs=i("__VUE_SSR_SETTERS__",e=>wn=e)}const $n=t=>{const i=ae;return Qn(t),t.scope.on(),()=>{t.scope.off(),Qn(i)}},tr=()=>{ae&&ae.scope.off(),Qn(null)};function Bl(t){return t.vnode.shapeFlag&4}let wn=!1;function Ad(t,i=!1,e=!1){i&&Zs(i);const{props:n,children:s}=t.vnode,r=Bl(t);dd(t,n,r,i),hd(t,s,e||i);const l=r?Ed(t,i):void 0;return i&&Zs(!1),l}function Ed(t,i){const e=t.type;t.accessCache=Object.create(null),t.proxy=new Proxy(t.ctx,Zc);const{setup:n}=e;if(n){ii();const s=t.setupContext=n.length>1?Md(t):null,r=$n(t),l=Sn(n,t,0,[t.props,s]),o=Br(l);if(ni(),r(),(o||t.sp)&&!Ui(t)&&cl(t),o){if(l.then(tr,tr),i)return l.then(a=>{er(t,a)}).catch(a=>{ds(a,t,0)});t.asyncDep=l}else er(t,l)}else Dl(t)}function er(t,i,e){It(i)?t.type.__ssrInlineRender?t.ssrRender=i:t.render=i:jt(i)&&(t.setupState=Qr(i)),Dl(t)}function Dl(t,i,e){const n=t.type;t.render||(t.render=n.render||Ve);{const s=$n(t);ii();try{Yc(t)}finally{ni(),s()}}}const Td={get(t,i){return le(t,"get",""),t[i]}};function Md(t){const i=e=>{t.exposed=e||{}};return{attrs:new Proxy(t.attrs,Td),slots:t.slots,emit:t.emit,expose:i}}function hs(t){return t.exposed?t.exposeProxy||(t.exposeProxy=new Proxy(Qr(bc(t.exposed)),{get(i,e){if(e in i)return i[e];if(e in hn)return hn[e](t)},has(i,e){return e in i||e in hn}})):t.proxy}function Bd(t,i=!0){return It(t)?t.displayName||t.name:t.name||i&&t.__name}function Dd(t){return It(t)&&"__vccOpts"in t}const $t=(t,i)=>_c(t,i,wn),Od="3.5.40";/**
* @vue/runtime-dom v3.5.40
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/let Ys;const ir=typeof window<"u"&&window.trustedTypes;if(ir)try{Ys=ir.createPolicy("vue",{createHTML:t=>t})}catch{}const Ol=Ys?t=>Ys.createHTML(t):t=>t,Pd="http://www.w3.org/2000/svg",Ld="http://www.w3.org/1998/Math/MathML",Ze=typeof document<"u"?document:null,nr=Ze&&Ze.createElement("template"),Rd={insert:(t,i,e)=>{i.insertBefore(t,e||null)},remove:t=>{const i=t.parentNode;i&&i.removeChild(t)},createElement:(t,i,e,n)=>{const s=i==="svg"?Ze.createElementNS(Pd,t):i==="mathml"?Ze.createElementNS(Ld,t):e?Ze.createElement(t,{is:e}):Ze.createElement(t);return t==="select"&&n&&n.multiple!=null&&s.setAttribute("multiple",n.multiple),s},createText:t=>Ze.createTextNode(t),createComment:t=>Ze.createComment(t),setText:(t,i)=>{t.nodeValue=i},setElementText:(t,i)=>{t.textContent=i},parentNode:t=>t.parentNode,nextSibling:t=>t.nextSibling,querySelector:t=>Ze.querySelector(t),setScopeId(t,i){t.setAttribute(i,"")},insertStaticContent(t,i,e,n,s,r){const l=e?e.previousSibling:i.lastChild;if(s&&(s===r||s.nextSibling))for(;i.insertBefore(s.cloneNode(!0),e),!(s===r||!(s=s.nextSibling)););else{nr.innerHTML=Ol(n==="svg"?`<svg>${t}</svg>`:n==="mathml"?`<math>${t}</math>`:t);const o=nr.content;if(n==="svg"||n==="mathml"){const a=o.firstChild;for(;a.firstChild;)o.appendChild(a.firstChild);o.removeChild(a)}i.insertBefore(o,e)}return[l?l.nextSibling:i.firstChild,e?e.previousSibling:i.lastChild]}},zd=Symbol("_vtc");function Nd(t,i,e){const n=t[zd];n&&(i=(i?[i,...n]:[...n]).join(" ")),i==null?t.removeAttribute("class"):e?t.setAttribute("class",i):t.className=i}const ts=Symbol("_vod"),Pl=Symbol("_vsh"),Ll={name:"show",beforeMount(t,{value:i},{transition:e}){t[ts]=t.style.display==="none"?"":t.style.display,e&&i?e.beforeEnter(t):en(t,i)},mounted(t,{value:i},{transition:e}){e&&i&&e.enter(t)},updated(t,{value:i,oldValue:e},{transition:n}){!i!=!e&&(n?i?(n.beforeEnter(t),en(t,!0),n.enter(t)):n.leave(t,()=>{en(t,!1)}):en(t,i))},beforeUnmount(t,{value:i}){en(t,i)}};function en(t,i){t.style.display=i?t[ts]:"none",t[Pl]=!i}const Fd=Symbol(""),jd=/(?:^|;)\s*display\s*:/;function Hd(t,i,e){const n=t.style,s=Qt(e);let r=!1;if(e&&!s){if(i)if(Qt(i))for(const l of i.split(";")){const o=l.slice(0,l.indexOf(":")).trim();e[o]==null&&on(n,o,"")}else for(const l in i)e[l]==null&&on(n,l,"");for(const l in e){l==="display"&&(r=!0);const o=e[l];o!=null?Wd(t,l,!Qt(i)&&i?i[l]:void 0,o)||on(n,l,o):on(n,l,"")}}else if(s){if(i!==e){const l=n[Fd];l&&(e+=";"+l),n.cssText=e,r=jd.test(e)}}else i&&t.removeAttribute("style");ts in t&&(t[ts]=r?n.display:"",t[Pl]&&(n.display="none"))}const sr=/\s*!important$/;function on(t,i,e){if(Ct(e))e.forEach(n=>on(t,i,n));else if(e==null&&(e=""),i.startsWith("--"))t.setProperty(i,e);else{const n=Ud(t,i);sr.test(e)?t.setProperty(hi(n),e.replace(sr,""),"important"):t[n]=e}}const or=["Webkit","Moz","ms"],As={};function Ud(t,i){const e=As[i];if(e)return e;let n=he(i);if(n!=="filter"&&n in t)return As[i]=n;n=os(n);for(let s=0;s<or.length;s++){const r=or[s]+n;if(r in t)return As[i]=r}return i}function Wd(t,i,e,n){return t.tagName==="TEXTAREA"&&(i==="width"||i==="height")&&Qt(n)&&e===n}const rr="http://www.w3.org/1999/xlink";function lr(t,i,e,n,s,r=Ya(i)){n&&i.startsWith("xlink:")?e==null?t.removeAttributeNS(rr,i.slice(6,i.length)):t.setAttributeNS(rr,i,e):e==null||r&&!Lr(e)?t.removeAttribute(i):t.setAttribute(i,r?"":De(e)?String(e):e)}function ar(t,i,e,n,s){if(i==="innerHTML"||i==="textContent"){e!=null&&(t[i]=i==="innerHTML"?Ol(e):e);return}const r=t.tagName;if(i==="value"&&r!=="PROGRESS"&&!r.includes("-")){const o=r==="OPTION"?t.getAttribute("value")||"":t.value,a=e==null?t.type==="checkbox"?"on":"":String(e);(o!==a||!("_value"in t))&&(t.value=a),e==null&&t.removeAttribute(i),t._value=e;return}let l=!1;if(e===""||e==null){const o=typeof t[i];o==="boolean"?e=Lr(e):e==null&&o==="string"?(e="",l=!0):o==="number"&&(e=0,l=!0)}try{t[i]=e}catch{}l&&t.removeAttribute(s||i)}function ci(t,i,e,n){t.addEventListener(i,e,n)}function Vd(t,i,e,n){t.removeEventListener(i,e,n)}const cr=Symbol("_vei");function Kd(t,i,e,n,s=null){const r=t[cr]||(t[cr]={}),l=r[i];if(n&&l)l.value=n;else{const[o,a]=Zd(i);if(n){const c=r[i]=Xd(n,s);ci(t,o,c,a)}else l&&(Vd(t,o,l,a),r[i]=void 0)}}const qd=/(Once|Passive|Capture)$/,Gd=/^on:?(?:Once|Passive|Capture)$/;function Zd(t){let i,e;for(;(e=t.match(qd))&&!Gd.test(t);)i||(i={}),t=t.slice(0,t.length-e[1].length),i[e[1].toLowerCase()]=!0;return[t[2]===":"?t.slice(3):hi(t.slice(2)),i]}let Es=0;const Yd=Promise.resolve(),Jd=()=>Es||(Yd.then(()=>Es=0),Es=Date.now());function Xd(t,i){const e=n=>{if(!n._vts)n._vts=Date.now();else if(n._vts<=e.attached)return;const s=e.value;if(Ct(s)){const r=n.stopImmediatePropagation;n.stopImmediatePropagation=()=>{r.call(n),n._stopped=!0};const l=s.slice(),o=[n];for(let a=0;a<l.length&&!n._stopped;a++){const c=l[a];c&&Pe(c,i,5,o)}}else Pe(s,i,5,[n])};return e.value=t,e.attached=Jd(),e}const dr=t=>t.charCodeAt(0)===111&&t.charCodeAt(1)===110&&t.charCodeAt(2)>96&&t.charCodeAt(2)<123,Qd=(t,i,e,n,s,r)=>{const l=s==="svg";i==="class"?Nd(t,n,l):i==="style"?Hd(t,e,n):is(i)?ns(i)||Kd(t,i,e,n,r):(i[0]==="."?(i=i.slice(1),!0):i[0]==="^"?(i=i.slice(1),!1):tu(t,i,n,l))?(ar(t,i,n),!t.tagName.includes("-")&&(i==="value"||i==="checked"||i==="selected")&&lr(t,i,n,l,r,i!=="value")):t._isVueCE&&(eu(t,i)||t._def.__asyncLoader&&(/[A-Z]/.test(i)||!Qt(n)))?ar(t,he(i),n,r,i):(i==="true-value"?t._trueValue=n:i==="false-value"&&(t._falseValue=n),lr(t,i,n,l))};function tu(t,i,e,n){if(n)return!!(i==="innerHTML"||i==="textContent"||i in t&&dr(i)&&It(e));if(i==="spellcheck"||i==="draggable"||i==="translate"||i==="autocorrect"||i==="sandbox"&&t.tagName==="IFRAME"||i==="form"||i==="list"&&t.tagName==="INPUT"||i==="type"&&t.tagName==="TEXTAREA")return!1;if(i==="width"||i==="height"){const s=t.tagName;if(s==="IMG"||s==="VIDEO"||s==="CANVAS"||s==="SOURCE")return!1}return dr(i)&&Qt(e)?!1:i in t}function eu(t,i){const e=t._def.props;if(!e)return!1;const n=he(i);return Array.isArray(e)?e.some(s=>he(s)===n):Object.keys(e).some(s=>he(s)===n)}const Zi=t=>{const i=t.props["onUpdate:modelValue"]||!1;return Ct(i)?e=>Fn(i,e):i};function iu(t){t.target.composing=!0}function ur(t){const i=t.target;i.composing&&(i.composing=!1,i.dispatchEvent(new Event("input")))}const ei=Symbol("_assign");function fr(t,i,e){return i&&(t=t.trim()),e&&(t=rs(t)),t}const es={created(t,{modifiers:{lazy:i,trim:e,number:n}},s){t[ei]=Zi(s);const r=n||s.props&&s.props.type==="number";ci(t,i?"change":"input",l=>{l.target.composing||t[ei](fr(t.value,e,r))}),(e||r)&&ci(t,"change",()=>{t.value=fr(t.value,e,r)}),i||(ci(t,"compositionstart",iu),ci(t,"compositionend",ur),ci(t,"change",ur))},mounted(t,{value:i}){t.value=i??""},beforeUpdate(t,{value:i,oldValue:e,modifiers:{lazy:n,trim:s,number:r}},l){if(t[ei]=Zi(l),t.composing)return;const o=(r||t.type==="number")&&!/^0\d/.test(t.value)?rs(t.value):t.value,a=i??"";if(o===a)return;const c=t.getRootNode();(c instanceof Document||c instanceof ShadowRoot)&&c.activeElement===t&&t.type!=="range"&&(n&&i===e||s&&t.value.trim()===a)||(t.value=a)}},Ln={deep:!0,created(t,i,e){t[ei]=Zi(e),ci(t,"change",()=>{const n=t._modelValue,s=kn(t),r=t.checked,l=t[ei];if(Ct(n)){const o=so(n,s),a=o!==-1;if(r&&!a)l(n.concat(s));else if(!r&&a){const c=[...n];c.splice(o,1),l(c)}}else if(Ji(n)){const o=new Set(n);r?o.add(s):o.delete(s),l(o)}else l(Rl(t,r))})},mounted:pr,beforeUpdate(t,i,e){t[ei]=Zi(e),pr(t,i,e)}};function pr(t,{value:i,oldValue:e},n){t._modelValue=i;let s;if(Ct(i))s=so(i,n.props.value)>-1;else if(Ji(i))s=i.has(n.props.value);else{if(i===e)return;s=Xi(i,Rl(t,!0))}t.checked!==s&&(t.checked=s)}const nu={deep:!0,created(t,{value:i,modifiers:{number:e}},n){t._modelValue=i,ci(t,"change",()=>{const s=Array.prototype.filter.call(t.options,r=>r.selected).map(r=>e?rs(kn(r)):kn(r));t[ei](t.multiple?Ji(t._modelValue)?new Set(s):s:s[0]),t._assigning=!0,el(()=>{t._assigning=!1})}),t[ei]=Zi(n)},mounted(t,{value:i}){hr(t,i)},beforeUpdate(t,{value:i},e){t._modelValue=i,t[ei]=Zi(e)},updated(t,{value:i}){t._assigning||hr(t,i)}};function hr(t,i){const e=t.multiple,n=Ct(i);if(!(e&&!n&&!Ji(i))){for(let s=0,r=t.options.length;s<r;s++){const l=t.options[s],o=kn(l);if(e)if(n){const a=typeof o;a==="string"||a==="number"?l.selected=i.some(c=>String(c)===String(o)):l.selected=so(i,o)>-1}else l.selected=i.has(o);else if(Xi(kn(l),i)){t.selectedIndex!==s&&(t.selectedIndex=s);return}}!e&&t.selectedIndex!==-1&&(t.selectedIndex=-1)}}function kn(t){return"_value"in t?t._value:t.value}function Rl(t,i){const e=i?"_trueValue":"_falseValue";return e in t?t[e]:i}const su=["ctrl","shift","alt","meta"],ou={stop:t=>t.stopPropagation(),prevent:t=>t.preventDefault(),self:t=>t.target!==t.currentTarget,ctrl:t=>!t.ctrlKey,shift:t=>!t.shiftKey,alt:t=>!t.altKey,meta:t=>!t.metaKey,left:t=>"button"in t&&t.button!==0,middle:t=>"button"in t&&t.button!==1,right:t=>"button"in t&&t.button!==2,exact:(t,i)=>su.some(e=>t[`${e}Key`]&&!i.includes(e))},Ee=(t,i)=>{if(!t)return t;const e=t._withMods||(t._withMods={}),n=i.join(".");return e[n]||(e[n]=((s,...r)=>{for(let l=0;l<i.length;l++){const o=ou[i[l]];if(o&&o(s,i))return}return t(s,...r)}))},ru={esc:"escape",space:" ",up:"arrow-up",left:"arrow-left",right:"arrow-right",down:"arrow-down",delete:"backspace"},lu=(t,i)=>{const e=t._withKeys||(t._withKeys={}),n=i.join(".");return e[n]||(e[n]=(s=>{if(!("key"in s))return;const r=hi(s.key);if(i.some(l=>l===r||ru[l]===r))return t(s)}))},au=re({patchProp:Qd},Rd);let mr;function cu(){return mr||(mr=gd(au))}const zl=((...t)=>{const i=cu().createApp(...t),{mount:e}=i;return i.mount=n=>{const s=uu(n);if(!s)return;const r=i._component;!It(r)&&!r.render&&!r.template&&(r.template=s.innerHTML),s.nodeType===1&&(s.textContent="");const l=e(s,!1,du(s));return s instanceof Element&&(s.removeAttribute("v-cloak"),s.setAttribute("data-v-app","")),l},i});function du(t){if(t instanceof SVGElement)return"svg";if(typeof MathMLElement=="function"&&t instanceof MathMLElement)return"mathml"}function uu(t){return Qt(t)?document.querySelector(t):t}function fu(){if(typeof window<"u"&&typeof window.require=="function")return window.require.bind(window);if(typeof globalThis<"u"&&typeof globalThis.require=="function")return globalThis.require.bind(globalThis);if(typeof require=="function")return require}function ke(t){const i=fu();if(i)try{return i(t)}catch{try{const e=t.startsWith("node:")?t.slice(5):`node:${t}`;return i(e)}catch{}}}function ko(){var i;if(typeof window<"u"&&window.process)return window.process;const t=ke("process");return t&&t.versions?t:typeof process<"u"&&((i=process.versions)!=null&&i.node)?process:globalThis.process}function Nl(){var i,e;const t=ko();if(t&&((i=t.versions)!=null&&i.node))return!0;if(typeof window<"u"&&window.siyuan){const n=ke("child_process");if(n&&typeof n.spawn=="function")return!0}return!!(typeof process<"u"&&((e=process.versions)!=null&&e.node))}function xn(){const t=ko();if(t!=null&&t.platform)return t.platform;if(typeof process<"u"&&process.platform)return process.platform;const i=ke("os");if(i&&typeof i.platform=="function")return i.platform();if(typeof navigator<"u"){const e=navigator.userAgent.toLowerCase();if(e.includes("win"))return"win32";if(e.includes("mac"))return"darwin";if(e.includes("linux"))return"linux"}return"web"}function Fl(){var n,s;const t=ko(),i={...(t==null?void 0:t.env)||{}};if(xn()==="win32"){const r=["C:\\Program Files\\nodejs","C:\\Program Files (x86)\\nodejs",(n=t==null?void 0:t.env)!=null&&n.APPDATA?`${t.env.APPDATA}\\npm`:"",(s=t==null?void 0:t.env)!=null&&s.USERPROFILE?`${t.env.USERPROFILE}\\AppData\\Roaming\\npm`:""].filter(Boolean),l=Object.keys(i).find(c=>c.toLowerCase()==="path")||"PATH",a=(i[l]||"").split(";").filter(Boolean);for(const c of r)c&&!a.some(d=>d.toLowerCase()===c.toLowerCase())&&a.push(c);i[l]=a.join(";")}return i}function Js(t){var e,n,s;if(!t)return"";if(/^[a-zA-Z]:[/\\]/.test(t))return t.replace(/\\/g,"/");let i="";if(typeof window<"u"&&((s=(n=(e=window.siyuan)==null?void 0:e.config)==null?void 0:n.system)!=null&&s.dataDir)&&(i=window.siyuan.config.system.dataDir.replace(/\\/g,"/")),i&&t.startsWith("/data/")){const r=t.slice(6);return`${i}/${r}`.replace(/\\/g,"/")}return t}function pu(){const t=ke("os"),i=ke("path");if(t&&typeof t.tmpdir=="function"){const e=t.tmpdir();return i&&typeof i.join=="function"?i.join(e,"siyuan-slidev-pro").replace(/\\/g,"/"):`${e}/siyuan-slidev-pro`.replace(/\\/g,"/")}return"/data/storage/petal/siyuan-slidev/pro-workspace"}class xo{constructor(i){kt(this,"runner");this.runner=i||xo.defaultRunner}static async defaultRunner(i,e){var n;try{let s=(n=ke("child_process"))==null?void 0:n.execFile;if(!s){const a=await import("node:child_process").catch(()=>({}));s=a==null?void 0:a.execFile}if(!s)return{code:-1,stdout:"",stderr:"child_process execFile not available"};const l=xn()==="win32",o=Fl();return await new Promise(a=>{s(i,e,{timeout:5e3,shell:l,env:o},(c,d,h)=>{a({code:c?c.code||1:0,stdout:d?String(d).trim():"",stderr:h?String(h).trim():""})})})}catch(s){return{code:-1,stdout:"",stderr:String(s)}}}async detect(){const i=Nl(),e=xn();if(!i)return{hasNode:!1,hasSlidevCli:!1,platform:"browser",isDesktop:!1,error:"当前处于纯前端浏览器或移动端环境，无 Node.js 运行时支撑"};let n=!1,s,r=!1,l;try{const o=await this.runner("node",["-v"]);o.code===0&&o.stdout.startsWith("v")&&(n=!0,s=o.stdout)}catch{}if(n){try{const o=e==="win32"?"slidev.cmd":"slidev",a=await this.runner(o,["--version"]);a.code===0&&a.stdout&&(r=!0,l=a.stdout)}catch{}if(!r)try{const o=e==="win32"?"npx.cmd":"npx",a=await this.runner(o,["@slidev/cli","--version"]);a.code===0&&a.stdout&&(r=!0,l=a.stdout)}catch{}}return{hasNode:n,nodeVersion:s,hasSlidevCli:r,slidevVersion:l,platform:e,isDesktop:i}}}class hu{constructor(){kt(this,"iframe",null);kt(this,"isReady",!1);kt(this,"pageChangedHandlers",[]);kt(this,"readyHandlers",[]);kt(this,"currentState",{no:1,clicks:0,total:1});this.handleWindowMessage=this.handleWindowMessage.bind(this)}getCurrentState(){return{...this.currentState}}attach(i){this.detach(),this.iframe=i,this.isReady=!1,typeof window<"u"&&window.addEventListener("message",this.handleWindowMessage)}detach(){typeof window<"u"&&window.removeEventListener("message",this.handleWindowMessage),this.iframe=null,this.isReady=!1}postMessage(i,e){var s;if(!((s=this.iframe)!=null&&s.contentWindow))return;const n={target:"slidev",sender:"siyuan",type:i,...e};try{this.iframe.contentWindow.postMessage(n,"*")}catch(r){console.warn("[NativeSlidevBridge] postMessage error:",r)}}navigateToPage(i){this.postMessage("navigate",{no:i})}next(){this.postMessage("next")}prev(){this.postMessage("prev")}nextClick(){this.postMessage("next-click")}prevClick(){this.postMessage("prev-click")}onPageChanged(i){return this.pageChangedHandlers.push(i),()=>{this.pageChangedHandlers=this.pageChangedHandlers.filter(e=>e!==i)}}onReady(i){return this.readyHandlers.push(i),()=>{this.readyHandlers=this.readyHandlers.filter(e=>e!==i)}}handleWindowMessage(i){const e=i.data;if(!(!e||e.target!=="slidev")){if(!this.isReady){this.isReady=!0;for(const n of this.readyHandlers)n()}if(e.type==="update-state"&&e.navState){const n=e.navState;this.currentState={no:n.no??this.currentState.no,clicks:n.clicks??this.currentState.clicks,total:n.total??this.currentState.total,hasNext:n.hasNext,hasPrev:n.hasPrev};for(const s of this.pageChangedHandlers)s(this.currentState.no,this.currentState.total||1,this.currentState)}else if(e.type==="navigate"&&typeof e.no=="number"){this.currentState.no=e.no;for(const n of this.pageChangedHandlers)n(e.no,this.currentState.total||1,this.currentState)}}}}class mu{constructor(i){kt(this,"childProcess",null);kt(this,"activePort",null);kt(this,"isRunning",!1);kt(this,"defaultPort");kt(this,"maxPortRetries");kt(this,"probeTimeoutMs");kt(this,"customSpawner");kt(this,"customPortChecker");this.defaultPort=(i==null?void 0:i.defaultPort)||3030,this.maxPortRetries=(i==null?void 0:i.maxPortRetries)||20,this.probeTimeoutMs=(i==null?void 0:i.probeTimeoutMs)||1e4,this.customSpawner=i==null?void 0:i.customSpawner,this.customPortChecker=i==null?void 0:i.customPortChecker}getActivePort(){return this.activePort}getIsRunning(){return this.isRunning}async isPortAvailable(i){if(this.customPortChecker)return this.customPortChecker(i);try{let e=ke("net");return e||(e=await import("node:net").catch(()=>({}))),e!=null&&e.createServer?await new Promise(n=>{const s=e.createServer();s.once("error",()=>n(!1)),s.once("listening",()=>{s.close(()=>n(!0))}),s.listen(i,"127.0.0.1")}):!0}catch{return!0}}async allocPort(i){const e=i||this.defaultPort;for(let n=0;n<this.maxPortRetries;n++){const s=e+n;if(await this.isPortAvailable(s))return s}return e}async pollServerReady(i,e=8e3,n=300){const s=Date.now();for(;Date.now()-s<e;){try{const r=new AbortController,l=setTimeout(()=>r.abort(),n),o=await fetch(i,{method:"HEAD",mode:"no-cors",signal:r.signal}).catch(()=>null);if(clearTimeout(l),o)return!0}catch{}await new Promise(r=>setTimeout(r,n))}return!1}async startServer(i,e){var a,c;if(this.isRunning&&this.activePort)return{success:!0,port:this.activePort,url:`http://localhost:${this.activePort}?embedded=true`};const n=await this.allocPort(e);this.activePort=n;const r=xn()==="win32"?"npx.cmd":"npx",l=Js(i),o=["@slidev/cli",l,"--port",String(n),"--no-open"];try{if(this.customSpawner)this.childProcess=this.customSpawner(r,o,{detached:!1});else{let h=(a=ke("child_process"))==null?void 0:a.spawn;if(!h){const y=await import("node:child_process").catch(()=>({}));h=y==null?void 0:y.spawn}if(!h)throw new Error("child_process spawn not available in current runtime");const m=l.includes("/")||l.includes("\\")?l.replace(/[/\\][^/\\]+$/,""):void 0,p=Fl();this.childProcess=h(r,o,{cwd:m,detached:!1,shell:!0,env:{...p,FORCE_COLOR:"1"}})}this.isRunning=!0,(c=this.childProcess)!=null&&c.on&&this.childProcess.on("exit",()=>{this.isRunning=!1,this.activePort=null,this.childProcess=null});const d=`http://localhost:${n}`;return!this.customSpawner&&!await this.pollServerReady(d,this.probeTimeoutMs)?(this.stopServer(),{success:!1,port:n,url:"",error:`Slidev DevServer 启动超时 (未在 ${this.probeTimeoutMs}ms 内响应端口 ${n})`}):{success:!0,port:n,url:`${d}?embedded=true`}}catch(d){return this.stopServer(),{success:!1,port:n,url:"",error:`唤起 Slidev 进程失败: ${String(d)}`}}}stopServer(){var i;if(this.childProcess){try{if(this.childProcess.kill("SIGTERM"),xn()==="win32"&&this.childProcess.pid&&!this.customSpawner){const n=(i=ke("child_process"))==null?void 0:i.exec;n?n(`taskkill /pid ${this.childProcess.pid} /T /F`,()=>{}):import("node:child_process").then(({exec:s})=>{var r;s(`taskkill /pid ${(r=this.childProcess)==null?void 0:r.pid} /T /F`,()=>{})}).catch(()=>{})}}catch{}this.childProcess=null}this.isRunning=!1,this.activePort=null}}class _o{constructor(){kt(this,"iframe",null);kt(this,"isReady",!1);kt(this,"pendingMessages",[]);kt(this,"slideChangedHandlers",[]);kt(this,"blockClickedHandlers",[]);kt(this,"openInEditorHandlers",[]);kt(this,"clientReadyHandlers",[]);kt(this,"openPeekDrawerHandlers",[]);kt(this,"toggleFullscreenHandlers",[]);this.handleWindowMessage=this.handleWindowMessage.bind(this)}attach(i){this.detach(),this.iframe=i,this.isReady=!1,typeof window<"u"&&window.addEventListener("message",this.handleWindowMessage)}detach(){typeof window<"u"&&window.removeEventListener("message",this.handleWindowMessage),this.iframe=null,this.isReady=!1,this.pendingMessages=[]}postMessage(i,e){var s;const n={source:"siyuan-slidev-host",action:i,payload:e};if(!((s=this.iframe)!=null&&s.contentWindow)||!this.isReady){this.pendingMessages.push(n);return}try{this.iframe.contentWindow.postMessage(n,"*")}catch(r){console.warn("[WebSandboxBridge] postMessage error:",r)}}updateSlides(i,e,n){this.postMessage("UPDATE_SLIDES",{slides:i,config:e,fullMarkdown:n})}navigatePage(i){this.postMessage("NAVIGATE_PAGE",{pageIndex:i})}highlightElement(i){this.postMessage("HIGHLIGHT_ELEMENT",{targetBlockId:i})}nextStep(){this.postMessage("NEXT_STEP",{})}prevStep(){this.postMessage("PREV_STEP",{})}freezeKeyboardNav(i){this.postMessage("FREEZE_KEYBOARD_NAV",{frozen:i})}onSlideChanged(i){return this.slideChangedHandlers.push(i),()=>{this.slideChangedHandlers=this.slideChangedHandlers.filter(e=>e!==i)}}onBlockClicked(i){return this.blockClickedHandlers.push(i),()=>{this.blockClickedHandlers=this.blockClickedHandlers.filter(e=>e!==i)}}onOpenInEditor(i){return this.openInEditorHandlers.push(i),()=>{this.openInEditorHandlers=this.openInEditorHandlers.filter(e=>e!==i)}}onOpenPeekDrawer(i){return this.openPeekDrawerHandlers.push(i),()=>{this.openPeekDrawerHandlers=this.openPeekDrawerHandlers.filter(e=>e!==i)}}onRequestToggleFullscreen(i){return this.toggleFullscreenHandlers.push(i),()=>{this.toggleFullscreenHandlers=this.toggleFullscreenHandlers.filter(e=>e!==i)}}onClientReady(i){return this.clientReadyHandlers.push(i),()=>{this.clientReadyHandlers=this.clientReadyHandlers.filter(e=>e!==i)}}handleWindowMessage(i){var n;const e=i.data;if(!(!e||e.source!=="siyuan-slidev-client"))switch(e.action){case"CLIENT_READY":for(this.isReady=!0;this.pendingMessages.length>0;){const s=this.pendingMessages.shift();s&&((n=this.iframe)!=null&&n.contentWindow)&&this.iframe.contentWindow.postMessage(s,"*")}for(const s of this.clientReadyHandlers)s();break;case"SLIDE_CHANGED":if(e.payload.currentPage!==void 0)for(const s of this.slideChangedHandlers)s(e.payload.currentPage,e.payload.totalPages||1,e.payload.currentBlockId||"");break;case"BLOCK_CLICKED":if(e.payload.clickedBlockId)for(const s of this.blockClickedHandlers)s(e.payload.clickedBlockId,e.payload.currentPage||1);break;case"OPEN_IN_EDITOR":if(e.payload.blockId||e.payload.clickedBlockId){const s=e.payload.blockId||e.payload.clickedBlockId||"";for(const r of this.openInEditorHandlers)r(s,e.payload.currentPage||1)}break;case"OPEN_PEEK_DRAWER":if(e.payload.peekType){const s=e.payload.blockId||e.payload.url||"",r={peekType:e.payload.peekType,target:s,title:e.payload.title};for(const l of this.openPeekDrawerHandlers)l(r)}break;case"REQUEST_TOGGLE_FULLSCREEN":for(const s of this.toggleFullscreenHandlers)s();break}}}const jl={"snippets/external.ts":`// Inside ./snippets/external.ts
// #region snippet
export function emptyArray<T>(length: number) {
  return Array.from<T>({ length })
}
// #endregion snippet

export function sayHello() {
  console.log('Hello from snippets/external.ts')
}
`},gu=`<template>
  <div class="slidev-layout three-cols-header w-full h-full flex flex-col">
    <div class="header-section mb-4 w-full">
      <slot />
    </div>
    <div class="grid grid-cols-3 gap-6 flex-1 items-stretch">
      <div class="col-1 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-1" />
      </div>
      <div class="col-2 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-2" />
      </div>
      <div class="col-3 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-3" />
      </div>
    </div>
  </div>
</template>
`,vu=`// Auto-generated by SiYuan Slidev Studio
export default function() {
  if (typeof window === 'undefined') return
  window.addEventListener('click', (e: MouseEvent) => {
    const target = e.target as HTMLElement | null
    if (!target || !target.closest) return

    const refEl = target.closest('[data-ref-id]')
    if (refEl) {
      const blockId = refEl.getAttribute('data-ref-id')
      if (blockId) {
        e.preventDefault()
        e.stopPropagation()
        window.parent.postMessage({
          source: 'siyuan-slidev-client',
          action: 'OPEN_PEEK_DRAWER',
          payload: { peekType: 'siyuan', blockId, title: (refEl.innerText || refEl.title || '').trim() }
        }, '*')
        return
      }
    }

    const linkEl = target.closest('a') as HTMLAnchorElement | null
    if (linkEl) {
      const href = linkEl.getAttribute('href') || ''
      if (href.startsWith('siyuan://blocks/')) {
        e.preventDefault()
        e.stopPropagation()
        const cleanBlockId = href.replace('siyuan://blocks/', '').split('?')[0]
        window.parent.postMessage({
          source: 'siyuan-slidev-client',
          action: 'OPEN_PEEK_DRAWER',
          payload: { peekType: 'siyuan', blockId: cleanBlockId, title: (linkEl.innerText || linkEl.title || '').trim() }
        }, '*')
      } else if (/^https?:\\/\\//i.test(href)) {
        e.preventDefault()
        e.stopPropagation()
        window.parent.postMessage({
          source: 'siyuan-slidev-client',
          action: 'OPEN_PEEK_DRAWER',
          payload: { peekType: 'web', url: href, title: (linkEl.innerText || linkEl.title || '').trim() }
        }, '*')
      }
    }
  }, true)
}
`,bu=`/* Auto-generated by SiYuan Slidev Studio */
.slidev-ref-tag,
a.slidev-ref-tag {
  display: inline-flex;
  align-items: center;
  background: color-mix(in srgb, var(--slidev-theme-primary, #10b981) 12%, transparent);
  color: var(--slidev-theme-primary, #10b981);
  border-radius: 4px;
  padding: 2px 8px;
  font-size: 0.88em;
  text-decoration: none;
  border: 1px solid color-mix(in srgb, var(--slidev-theme-primary, #10b981) 25%, transparent);
  cursor: pointer;
  transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
  user-select: none;
}

.slidev-ref-tag:hover,
a.slidev-ref-tag:hover {
  background: color-mix(in srgb, var(--slidev-theme-primary, #10b981) 22%, transparent);
  color: var(--slidev-theme-primary, #10b981);
  border-color: color-mix(in srgb, var(--slidev-theme-primary, #10b981) 55%, transparent);
  transform: translateY(-1px);
  box-shadow: 0 2px 8px color-mix(in srgb, var(--slidev-theme-primary, #10b981) 20%, transparent);
}

.slidev-block-ref {
  display: block;
  padding: 10px 14px;
  background: color-mix(in srgb, var(--slidev-theme-primary, #10b981) 8%, transparent);
  border-left: 3px solid var(--slidev-theme-primary, #10b981);
  border-radius: 0 6px 6px 0;
  margin: 8px 0;
  cursor: pointer;
  transition: background 0.2s ease;
}

.slidev-block-ref:hover {
  background: color-mix(in srgb, var(--slidev-theme-primary, #10b981) 15%, transparent);
}

/* 代码块自动换行与无横向滚动条 */
pre,
pre code {
  white-space: pre-wrap !important;
  word-break: break-all !important;
  overflow-wrap: anywhere !important;
  overflow-x: hidden !important;
  overflow-y: auto !important;
  max-width: 100% !important;
  box-sizing: border-box !important;
}

/* 弱提示滚动条样式 */
* {
  scrollbar-width: thin;
}
html:not(.dark) * {
  scrollbar-color: rgba(0, 0, 0, 0.15) transparent;
}
html.dark * {
  scrollbar-color: rgba(255, 255, 255, 0.20) transparent;
}
*::-webkit-scrollbar {
  width: 4px;
  height: 4px;
}
*::-webkit-scrollbar-track {
  background: transparent;
}
html:not(.dark) *::-webkit-scrollbar-thumb {
  background: rgba(0, 0, 0, 0.15);
  border-radius: 2px;
}
html:not(.dark) *:hover::-webkit-scrollbar-thumb,
html:not(.dark) *::-webkit-scrollbar-thumb:hover {
  background: rgba(0, 0, 0, 0.35);
}
html.dark *::-webkit-scrollbar-thumb {
  background: rgba(255, 255, 255, 0.20);
  border-radius: 2px;
}
html.dark *:hover::-webkit-scrollbar-thumb,
html.dark *::-webkit-scrollbar-thumb:hover {
  background: rgba(255, 255, 255, 0.45);
}

/* 多媒体（GIF动图、静态图片、MP4视频）最大化自适应且不超出视口 */
.slidev-layout img,
.slidev-layout video {
  max-width: 100% !important;
  max-height: 100% !important;
  width: auto;
  height: auto;
  object-fit: contain !important;
}
.three-cols-header video,
.two-cols-header video,
.grid-cols-3 video,
.grid-cols-2 video,
.col-1 video,
.col-2 video,
.col-3 video {
  width: 100% !important;
  height: 100% !important;
  max-width: 100% !important;
  max-height: 100% !important;
  object-fit: contain !important;
}
.slide-list-media {
  display: flex !important;
  align-items: center !important;
  justify-content: center !important;
  margin-top: 4px !important;
  margin-bottom: 4px !important;
  width: 100% !important;
  max-width: 100% !important;
  height: 100% !important;
  max-height: 100% !important;
  flex: 1 1 0% !important;
  overflow: hidden !important;
}
.slide-list-media img,
.slide-list-media video,
.slide-list-media .list-item-gif {
  width: 100% !important;
  height: 100% !important;
  max-width: 100% !important;
  max-height: 100% !important;
  object-fit: contain !important;
  border-radius: 6px !important;
  box-shadow: 0 3px 12px rgba(0, 0, 0, 0.14) !important;
}
.slide-video-container {
  display: flex !important;
  justify-content: center !important;
  align-items: center !important;
  width: 100% !important;
  max-height: 100% !important;
  margin: 6px 0 !important;
}
.slide-video-player {
  max-width: 100% !important;
  max-height: 100% !important;
  object-fit: contain !important;
  border-radius: 8px !important;
}

/* 两栏与三栏（超级块分栏）布局：去除列表圆点标记与缩进 */
.three-cols-header ul,
.three-cols-header ol,
.two-cols-header ul,
.two-cols-header ol,
.two-cols ul,
.two-cols ol,
.col-1 ul,
.col-1 ol,
.col-2 ul,
.col-2 ol,
.col-3 ul,
.col-3 ol,
.grid-cols-2 ul,
.grid-cols-2 ol,
.grid-cols-3 ul,
.grid-cols-3 ol {
  list-style: none !important;
  list-style-type: none !important;
  padding-left: 0 !important;
  margin-left: 0 !important;
}
.three-cols-header li,
.two-cols-header li,
.two-cols li,
.col-1 li,
.col-2 li,
.col-3 li,
.grid-cols-2 li,
.grid-cols-3 li {
  list-style: none !important;
  list-style-type: none !important;
  padding-left: 0 !important;
  margin-left: 0 !important;
}
.three-cols-header li::marker,
.two-cols-header li::marker,
.two-cols li::marker,
.col-1 li::marker,
.col-2 li::marker,
.col-3 li::marker {
  content: none !important;
}

/* 列表项内嵌标题与说明排版 */
.slide-list-item-title,
li > h1,
li > h2,
li > h3,
li > h4,
li > h5,
li > h6 {
  margin-top: 2px !important;
  margin-bottom: 6px !important;
  line-height: 1.35 !important;
  font-weight: 700 !important;
}
li > h1 { font-size: 1.6rem !important; }
li > h2 { font-size: 1.4rem !important; }
li > h3 { font-size: 1.22rem !important; }
li > h4 { font-size: 1.1rem !important; }
.slide-list-item-desc,
li > p {
  margin-top: 4px !important;
  margin-bottom: 6px !important;
  font-size: 1.05rem;
  line-height: 1.55;
  opacity: 0.92;
}
`;function yu(t){var s;const i=[],e=/^[ \t]*<<<[ \t]+(?:@\/|\.\/|)([^\s#]+)(?:#[^\s]+)?/gm;let n;for(;(n=e.exec(t))!==null;){const r=(s=n[1])==null?void 0:s.trim();r&&!i.includes(r)&&i.push(r)}return i}class wu{constructor(i){kt(this,"workspacePath");kt(this,"slidesFileName");kt(this,"cliBridge",new Qs);const e=pu();!(i!=null&&i.workspacePath)||i.workspacePath.includes("/data/storage/petal/siyuan-slidev/pro-workspace")?this.workspacePath=e:this.workspacePath=i.workspacePath,this.slidesFileName=(i==null?void 0:i.slidesFileName)||"slides.md"}getWorkspacePath(){return this.workspacePath}getSlidesPath(){return`${this.workspacePath}/${this.slidesFileName}`}generatePackageJson(i="default"){const e={name:"siyuan-slidev-pro-workspace",type:"module",private:!0,scripts:{dev:"slidev --port 3030",build:"slidev build"},dependencies:{"@slidev/cli":"^53.0.0","@slidev/theme-default":"latest"}};return i&&i!=="default"&&(e.dependencies[`@slidev/theme-${i}`]="latest"),JSON.stringify(e,null,2)}buildSlidesMarkdown(i){return this.cliBridge.buildStandardSlidevMarkdown(i)}async scaffold(i,e){const n=this.buildSlidesMarkdown(i),s=this.generatePackageJson(i.config.theme),r=this.getSlidesPath(),l=`${this.workspacePath}/package.json`,o=Js(r),a=Js(l),c=yu(n);c.includes("snippets/external.ts")||c.push("snippets/external.ts");const d=new Map;for(const v of c){const w=jl[v]||`// Auto-generated snippet placeholder for SiYuan Slidev
// #region snippet
// ${v}
// #endregion snippet
`;d.set(v,w)}i.slides.some(v=>{var w;return((w=v.frontmatter)==null?void 0:w.layout)==="three-cols-header"})&&d.set("layouts/three-cols-header.vue",gu),d.set("setup/root.ts",vu),d.set("styles/index.css",bu);const m=ke("fs"),p=ke("path");let y=!1;const f=p!=null&&p.dirname?p.dirname(o):"",k=/^[a-zA-Z]:[/\\]/.test(o)||o.includes("siyuan-slidev-pro");if(m&&p&&k)try{m.existsSync(f)||m.mkdirSync(f,{recursive:!0}),m.writeFileSync(a,s,"utf-8"),m.writeFileSync(o,n,"utf-8");for(const[v,w]of d.entries()){const x=p.join(f,v),E=p.dirname(x);m.existsSync(E)||m.mkdirSync(E,{recursive:!0}),m.existsSync(x)||m.writeFileSync(x,w,"utf-8")}y=!0}catch{}if(!y&&e)try{const v=typeof Blob<"u"?new Blob([n],{type:"text/markdown;charset=utf-8"}):Buffer.from(n,"utf-8"),w=typeof Blob<"u"?new Blob([s],{type:"application/json;charset=utf-8"}):Buffer.from(s,"utf-8");await e(l,!1,w),await e(r,!1,v);for(const[x,E]of d.entries()){const _=`${this.workspacePath}/${x}`,C=typeof Blob<"u"?new Blob([E],{type:"text/plain;charset=utf-8"}):Buffer.from(E,"utf-8");await e(_,!1,C).catch(()=>{})}return{success:!0,slidesPath:r,physicalSlidesPath:o,packageJsonPath:l}}catch(v){return{success:!1,slidesPath:r,physicalSlidesPath:o,packageJsonPath:l,error:String(v)}}return{success:!0,slidesPath:r,physicalSlidesPath:o,packageJsonPath:l}}}class ku{constructor(){kt(this,"mode","web-sandbox");kt(this,"webBridge");kt(this,"cliBridge");kt(this,"nativeBridge");kt(this,"processManager");kt(this,"scaffolder");kt(this,"envDetector");this.webBridge=new _o,this.cliBridge=new Qs,this.nativeBridge=new hu,this.processManager=new mu,this.scaffolder=new wu,this.envDetector=new xo}getMode(){return this.mode}setMode(i){this.mode=i}async startProMode(i,e){if(!(await this.envDetector.detect()).hasNode)return{success:!1,url:"",error:"当前系统未检测到 Node.js 环境，无法拉起官方 Slidev CLI，建议继续使用内置高保真引擎"};const s=await this.scaffolder.scaffold(i,e);if(!s.success)return{success:!1,url:"",error:`初始化 Slidev 临时工作空间失败: ${s.error}`};const r=s.physicalSlidesPath||s.slidesPath,l=await this.processManager.startServer(r);return l.success?(this.mode="pro-cli",{success:!0,url:l.url,port:l.port}):{success:!1,url:"",error:l.error}}stopProMode(){this.processManager.stopServer(),this.mode="web-sandbox"}destroy(){this.webBridge.detach(),this.nativeBridge.detach(),this.processManager.stopServer()}}const xu={class:"slidev-icon",style:{fill:"none !important"},viewBox:"0 0 24 24",stroke:"currentColor","stroke-width":"1.75","stroke-linecap":"round","stroke-linejoin":"round","aria-hidden":"true"},_u={key:0},Su={key:1},Cu={key:2},$u={key:3},Iu={key:4},Au={key:5},Eu={key:6},Tu={key:7},Mu={key:8},Bu={key:9},Du={key:10},Ou={key:11},Pu={key:12},Lu={key:13},Ru={key:14},zu={key:15},Nu={key:16},Fu={key:17},ju={key:18},Hu={key:19},Uu={key:20},Wu={key:21},Vu={key:22},Ku={key:23},qu={key:24},Gu={key:25},Zu={key:26},Yu={key:27},Ju={key:28},Xu={key:29},Qu={key:30},tf={key:31},ef={key:32},nf={key:33},sf={key:34},of={key:35},rf={key:36},lf={key:37},af={key:38},cf={key:39},df={key:40},uf={key:41},ff={key:42},pf={key:43},hf={key:44},mf={key:45},gf={key:46},vf={key:47},bf={key:48},yf={key:49},wf={key:50},kf={key:51},xf={key:52},_f=be({__name:"SlidevIcon",props:{name:{}},setup(t){return(i,e)=>(tt(),nt("svg",xu,[t.name==="fullscreen"||t.name==="maximize"?(tt(),nt("g",_u,[...e[0]||(e[0]=[g("polyline",{points:"15 3 21 3 21 9"},null,-1),g("polyline",{points:"9 21 3 21 3 15"},null,-1),g("polyline",{points:"21 15 21 21 15 21"},null,-1),g("polyline",{points:"3 9 3 3 9 3"},null,-1)])])):t.name==="minimize"?(tt(),nt("g",Su,[...e[1]||(e[1]=[g("polyline",{points:"4 14 10 14 10 20"},null,-1),g("polyline",{points:"20 10 14 10 14 4"},null,-1),g("line",{x1:"14",y1:"10",x2:"21",y2:"3"},null,-1),g("line",{x1:"3",y1:"21",x2:"10",y2:"14"},null,-1)])])):t.name==="close"||t.name==="x"?(tt(),nt("g",Cu,[...e[2]||(e[2]=[g("line",{x1:"18",y1:"6",x2:"6",y2:"18"},null,-1),g("line",{x1:"6",y1:"6",x2:"18",y2:"18"},null,-1)])])):t.name==="edit"?(tt(),nt("g",$u,[...e[3]||(e[3]=[g("path",{d:"M12 20h9"},null,-1),g("path",{d:"M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z"},null,-1)])])):t.name==="eye"?(tt(),nt("g",Iu,[...e[4]||(e[4]=[g("path",{d:"M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"},null,-1),g("circle",{cx:"12",cy:"12",r:"3"},null,-1)])])):t.name==="external-link"||t.name==="window"?(tt(),nt("g",Au,[...e[5]||(e[5]=[g("path",{d:"M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"},null,-1),g("polyline",{points:"15 3 21 3 21 9"},null,-1),g("line",{x1:"10",y1:"14",x2:"21",y2:"3"},null,-1)])])):t.name==="arrow-left"?(tt(),nt("g",Eu,[...e[6]||(e[6]=[g("line",{x1:"19",y1:"12",x2:"5",y2:"12"},null,-1),g("polyline",{points:"12 19 5 12 12 5"},null,-1)])])):t.name==="arrow-right"?(tt(),nt("g",Tu,[...e[7]||(e[7]=[g("line",{x1:"5",y1:"12",x2:"19",y2:"12"},null,-1),g("polyline",{points:"12 5 19 12 12 19"},null,-1)])])):t.name==="plus"?(tt(),nt("g",Mu,[...e[8]||(e[8]=[g("line",{x1:"12",y1:"5",x2:"12",y2:"19"},null,-1),g("line",{x1:"5",y1:"12",x2:"19",y2:"12"},null,-1)])])):t.name==="minus"?(tt(),nt("g",Bu,[...e[9]||(e[9]=[g("line",{x1:"5",y1:"12",x2:"19",y2:"12"},null,-1)])])):t.name==="split-preview"?(tt(),nt("g",Du,[...e[10]||(e[10]=[g("rect",{x:"3",y:"3",width:"18",height:"18",rx:"2"},null,-1),g("path",{d:"M12 3v18"},null,-1)])])):t.name==="import"?(tt(),nt("g",Ou,[...e[11]||(e[11]=[g("path",{d:"M4 17v2a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-2"},null,-1),g("polyline",{points:"7 9 12 14 17 9"},null,-1),g("line",{x1:"12",y1:"14",x2:"12",y2:"3"},null,-1)])])):t.name==="presenter"?(tt(),nt("g",Pu,[...e[12]||(e[12]=[g("path",{d:"M2 3h20"},null,-1),g("path",{d:"M21 3v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V3"},null,-1),g("path",{d:"m7 21 5-5 5 5"},null,-1)])])):t.name==="video"?(tt(),nt("g",Lu,[...e[13]||(e[13]=[g("polygon",{points:"23 7 16 12 23 17 23 7"},null,-1),g("rect",{x:"1",y:"5",width:"15",height:"14",rx:"2",ry:"2"},null,-1)])])):t.name==="step"?(tt(),nt("g",Ru,[...e[14]||(e[14]=[g("polygon",{points:"13 2 3 14 12 14 11 22 21 10 12 10 13 2"},null,-1)])])):t.name==="motion"?(tt(),nt("g",zu,[...e[15]||(e[15]=[g("path",{d:"M5 12h14"},null,-1),g("path",{d:"m12 5 7 7-7 7"},null,-1),g("path",{d:"M5 6h4"},null,-1),g("path",{d:"M5 18h4"},null,-1)])])):t.name==="columns"?(tt(),nt("g",Nu,[...e[16]||(e[16]=[g("rect",{x:"3",y:"3",width:"7",height:"18",rx:"1"},null,-1),g("rect",{x:"14",y:"3",width:"7",height:"18",rx:"1"},null,-1)])])):t.name==="code"?(tt(),nt("g",Fu,[...e[17]||(e[17]=[g("polyline",{points:"16 18 22 12 16 6"},null,-1),g("polyline",{points:"8 6 2 12 8 18"},null,-1)])])):t.name==="insert-above"?(tt(),nt("g",ju,[...e[18]||(e[18]=[g("line",{x1:"12",y1:"5",x2:"12",y2:"13"},null,-1),g("line",{x1:"8",y1:"9",x2:"16",y2:"9"},null,-1),g("path",{d:"M4 19h16","stroke-dasharray":"2 2"},null,-1)])])):t.name==="insert-below"?(tt(),nt("g",Hu,[...e[19]||(e[19]=[g("path",{d:"M4 5h16","stroke-dasharray":"2 2"},null,-1),g("line",{x1:"12",y1:"11",x2:"12",y2:"19"},null,-1),g("line",{x1:"8",y1:"15",x2:"16",y2:"15"},null,-1)])])):t.name==="broom"?(tt(),nt("g",Uu,[...e[20]||(e[20]=[g("path",{d:"m18 15-6-6"},null,-1),g("path",{d:"M4 20h16"},null,-1),g("path",{d:"M6 14l8-8a2.8 2.8 0 0 1 4 4l-8 8H6v-4z"},null,-1)])])):t.name==="trash"?(tt(),nt("g",Wu,[...e[21]||(e[21]=[g("path",{d:"M3 6h18"},null,-1),g("path",{d:"M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"},null,-1),g("path",{d:"M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"},null,-1)])])):t.name==="ai"||t.name==="sparkles"?(tt(),nt("g",Vu,[...e[22]||(e[22]=[g("path",{d:"m12 3-1.9 5.8a2 2 0 0 1-1.3 1.3L3 12l5.8 1.9a2 2 0 0 1 1.3 1.3L12 21l1.9-5.8a2 2 0 0 1 1.3-1.3L21 12l-5.8-1.9a2 2 0 0 1-1.3-1.3L12 3z"},null,-1)])])):t.name==="palette"?(tt(),nt("g",Ku,[...e[23]||(e[23]=[$e('<circle cx="13.5" cy="6.5" r=".5" fill="currentColor" data-v-b8552023></circle><circle cx="17.5" cy="10.5" r=".5" fill="currentColor" data-v-b8552023></circle><circle cx="8.5" cy="7.5" r=".5" fill="currentColor" data-v-b8552023></circle><circle cx="6.5" cy="12.5" r=".5" fill="currentColor" data-v-b8552023></circle><path d="M12 2C6.5 2 2 6.5 2 12s4.5 10 10 10c.9 0 1.5-.7 1.5-1.5 0-.4-.2-.8-.4-1.1-.3-.4-.4-.8-.4-1.4 0-1.1.9-2 2-2h2.3c3.9 0 7-3.1 7-7 0-5-4.5-9-10-9z" data-v-b8552023></path>',5)])])):t.name==="ratio"?(tt(),nt("g",qu,[...e[24]||(e[24]=[g("rect",{x:"2",y:"5",width:"20",height:"14",rx:"2"},null,-1),g("line",{x1:"2",y1:"10",x2:"22",y2:"10","stroke-dasharray":"2 2"},null,-1)])])):t.name==="transition"?(tt(),nt("g",Gu,[...e[25]||(e[25]=[g("path",{d:"M8 3 4 7l4 4"},null,-1),g("path",{d:"M4 7h16"},null,-1),g("path",{d:"m16 21 4-4-4-4"},null,-1),g("path",{d:"M20 17H4"},null,-1)])])):t.name==="export-html"?(tt(),nt("g",Zu,[...e[26]||(e[26]=[g("polyline",{points:"16 16 12 12 8 16"},null,-1),g("line",{x1:"12",y1:"12",x2:"12",y2:"21"},null,-1),g("path",{d:"M20.4 16.3A5 5 0 0 0 18 7h-1.3A8 8 0 0 0 4 12.8a5 5 0 0 0 1.5 9.2"},null,-1)])])):t.name==="export-pdf"?(tt(),nt("g",Yu,[...e[27]||(e[27]=[g("polyline",{points:"6 9 6 2 18 2 18 9"},null,-1),g("path",{d:"M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"},null,-1),g("rect",{x:"6",y:"14",width:"12",height:"8"},null,-1)])])):t.name==="pin"?(tt(),nt("g",Ju,[...e[28]||(e[28]=[g("line",{x1:"12",y1:"17",x2:"12",y2:"22"},null,-1),g("path",{d:"M5 17h14v-2l-2-2V5l1-1V2H6v2l1 1v8l-2 2v2z"},null,-1)])])):t.name==="refresh"?(tt(),nt("g",Xu,[...e[29]||(e[29]=[g("path",{d:"M3 12a9 9 0 0 1 9-9 9.75 9.75 0 0 1 6.74 2.74L21 8"},null,-1),g("path",{d:"M21 3v5h-5"},null,-1),g("path",{d:"M21 12a9 9 0 0 1-9 9 9.75 9.75 0 0 1-6.74-2.74L3 16"},null,-1),g("path",{d:"M8 16H3v5"},null,-1)])])):t.name==="outline"?(tt(),nt("g",Qu,[...e[30]||(e[30]=[g("line",{x1:"3",y1:"6",x2:"21",y2:"6"},null,-1),g("line",{x1:"3",y1:"12",x2:"21",y2:"12"},null,-1),g("line",{x1:"3",y1:"18",x2:"21",y2:"18"},null,-1)])])):t.name==="chevron-left"?(tt(),nt("g",tf,[...e[31]||(e[31]=[g("polyline",{points:"15 18 9 12 15 6"},null,-1)])])):t.name==="chevron-right"?(tt(),nt("g",ef,[...e[32]||(e[32]=[g("polyline",{points:"9 18 15 12 9 6"},null,-1)])])):t.name==="copy"?(tt(),nt("g",nf,[...e[33]||(e[33]=[g("rect",{x:"9",y:"9",width:"13",height:"13",rx:"2",ry:"2"},null,-1),g("path",{d:"M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"},null,-1)])])):t.name==="image"?(tt(),nt("g",sf,[...e[34]||(e[34]=[g("rect",{x:"3",y:"3",width:"18",height:"18",rx:"2",ry:"2"},null,-1),g("circle",{cx:"8.5",cy:"8.5",r:"1.5"},null,-1),g("polyline",{points:"21 15 16 10 5 21"},null,-1)])])):t.name==="search"?(tt(),nt("g",of,[...e[35]||(e[35]=[g("circle",{cx:"11",cy:"11",r:"7"},null,-1),g("line",{x1:"21",y1:"21",x2:"16.65",y2:"16.65"},null,-1)])])):t.name==="settings"||t.name==="gear"?(tt(),nt("g",rf,[...e[36]||(e[36]=[g("circle",{cx:"12",cy:"12",r:"3"},null,-1),g("path",{d:"M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 1 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 1 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 1 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 1 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"},null,-1)])])):t.name==="notes"||t.name==="file-text"?(tt(),nt("g",lf,[...e[37]||(e[37]=[$e('<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" data-v-b8552023></path><polyline points="14 2 14 8 20 8" data-v-b8552023></polyline><line x1="16" y1="13" x2="8" y2="13" data-v-b8552023></line><line x1="16" y1="17" x2="8" y2="17" data-v-b8552023></line><line x1="10" y1="9" x2="8" y2="9" data-v-b8552023></line>',5)])])):t.name==="focus"||t.name==="target"?(tt(),nt("g",af,[...e[38]||(e[38]=[g("circle",{cx:"12",cy:"12",r:"3",fill:"currentColor"},null,-1),g("path",{d:"M12 2v4M12 18v4M2 12h4M18 12h4",stroke:"currentColor","stroke-width":"2","stroke-linecap":"round"},null,-1),g("circle",{cx:"12",cy:"12",r:"7",fill:"none",stroke:"currentColor","stroke-width":"1.8"},null,-1)])])):t.name==="layout-cover"||t.name==="cover"?(tt(),nt("g",cf,[...e[39]||(e[39]=[g("rect",{x:"2",y:"4",width:"20",height:"16",rx:"2"},null,-1),g("line",{x1:"9",y1:"8",x2:"15",y2:"8"},null,-1),g("line",{x1:"5.5",y1:"11.5",x2:"18.5",y2:"11.5"},null,-1),g("line",{x1:"7.5",y1:"15",x2:"16.5",y2:"15"},null,-1)])])):t.name==="layout-default"||t.name==="default"?(tt(),nt("g",df,[...e[40]||(e[40]=[$e('<rect x="2" y="4" width="20" height="16" rx="2" data-v-b8552023></rect><line x1="5" y1="8" x2="11.5" y2="8" data-v-b8552023></line><line x1="5" y1="11.5" x2="19" y2="11.5" data-v-b8552023></line><line x1="5" y1="14.5" x2="19" y2="14.5" data-v-b8552023></line><line x1="5" y1="17.5" x2="13.5" y2="17.5" data-v-b8552023></line>',5)])])):t.name==="layout-two-cols"||t.name==="two-cols"?(tt(),nt("g",uf,[...e[41]||(e[41]=[$e('<rect x="2" y="4" width="20" height="16" rx="2" data-v-b8552023></rect><line x1="12" y1="4" x2="12" y2="20" stroke-dasharray="2 1.5" data-v-b8552023></line><line x1="5" y1="8" x2="9.5" y2="8" data-v-b8552023></line><line x1="5" y1="11.5" x2="9.5" y2="11.5" data-v-b8552023></line><line x1="5" y1="15" x2="8" y2="15" data-v-b8552023></line><line x1="14.5" y1="8" x2="19" y2="8" data-v-b8552023></line><line x1="14.5" y1="11.5" x2="19" y2="11.5" data-v-b8552023></line><line x1="14.5" y1="15" x2="17.5" y2="15" data-v-b8552023></line>',8)])])):t.name==="layout-two-cols-header"||t.name==="two-cols-header"?(tt(),nt("g",ff,[...e[42]||(e[42]=[$e('<rect x="2" y="4" width="20" height="16" rx="2" data-v-b8552023></rect><line x1="5" y1="7.5" x2="13" y2="7.5" data-v-b8552023></line><line x1="12" y1="10.5" x2="12" y2="18.5" stroke-dasharray="1.5 1.5" data-v-b8552023></line><line x1="5" y1="12" x2="9.5" y2="12" data-v-b8552023></line><line x1="5" y1="15.5" x2="8.5" y2="15.5" data-v-b8552023></line><line x1="14.5" y1="12" x2="19" y2="12" data-v-b8552023></line><line x1="14.5" y1="15.5" x2="18" y2="15.5" data-v-b8552023></line>',7)])])):t.name==="layout-three-cols-header"||t.name==="three-cols-header"?(tt(),nt("g",pf,[...e[43]||(e[43]=[$e('<rect x="2" y="4" width="20" height="16" rx="2" data-v-b8552023></rect><line x1="5" y1="7.5" x2="13" y2="7.5" data-v-b8552023></line><line x1="9.3" y1="10.5" x2="9.3" y2="18.5" stroke-dasharray="1.5 1.5" data-v-b8552023></line><line x1="14.7" y1="10.5" x2="14.7" y2="18.5" stroke-dasharray="1.5 1.5" data-v-b8552023></line><line x1="4.5" y1="12" x2="7.5" y2="12" data-v-b8552023></line><line x1="4.5" y1="15.5" x2="7" y2="15.5" data-v-b8552023></line><line x1="10.5" y1="12" x2="13.5" y2="12" data-v-b8552023></line><line x1="10.5" y1="15.5" x2="13.5" y2="15.5" data-v-b8552023></line><line x1="16" y1="12" x2="19.5" y2="12" data-v-b8552023></line><line x1="16" y1="15.5" x2="18.5" y2="15.5" data-v-b8552023></line>',10)])])):t.name==="layout-image-right"||t.name==="image-right"?(tt(),nt("g",hf,[...e[44]||(e[44]=[$e('<rect x="2" y="4" width="20" height="16" rx="2" data-v-b8552023></rect><line x1="12" y1="4" x2="12" y2="20" data-v-b8552023></line><line x1="4.5" y1="8" x2="9.5" y2="8" data-v-b8552023></line><line x1="4.5" y1="11.5" x2="10" y2="11.5" data-v-b8552023></line><line x1="4.5" y1="14.5" x2="8" y2="14.5" data-v-b8552023></line><circle cx="15.5" cy="8.5" r="1.2" data-v-b8552023></circle><polyline points="13 17 15.5 13 18 16 19.5 14" data-v-b8552023></polyline>',7)])])):t.name==="layout-image-left"||t.name==="image-left"?(tt(),nt("g",mf,[...e[45]||(e[45]=[$e('<rect x="2" y="4" width="20" height="16" rx="2" data-v-b8552023></rect><line x1="12" y1="4" x2="12" y2="20" data-v-b8552023></line><circle cx="6" cy="8.5" r="1.2" data-v-b8552023></circle><polyline points="3.5 17 6 13 8.5 16 10 14" data-v-b8552023></polyline><line x1="14.5" y1="8" x2="19.5" y2="8" data-v-b8552023></line><line x1="14.5" y1="11.5" x2="20" y2="11.5" data-v-b8552023></line><line x1="14.5" y1="14.5" x2="18" y2="14.5" data-v-b8552023></line>',7)])])):t.name==="layout-center"||t.name==="center"?(tt(),nt("g",gf,[...e[46]||(e[46]=[g("rect",{x:"2",y:"4",width:"20",height:"16",rx:"2"},null,-1),g("line",{x1:"6.5",y1:"9",x2:"17.5",y2:"9"},null,-1),g("line",{x1:"5",y1:"12",x2:"19",y2:"12"},null,-1),g("line",{x1:"8",y1:"15",x2:"16",y2:"15"},null,-1)])])):t.name==="layout-fact"||t.name==="fact"?(tt(),nt("g",vf,[...e[47]||(e[47]=[$e('<rect x="2" y="4" width="20" height="16" rx="2" data-v-b8552023></rect><circle cx="8" cy="9" r="1.5" data-v-b8552023></circle><line x1="14" y1="8" x2="9" y2="14" data-v-b8552023></line><circle cx="15" cy="13" r="1.5" data-v-b8552023></circle><line x1="6.5" y1="17" x2="17.5" y2="17" data-v-b8552023></line>',5)])])):t.name==="layout-intro"||t.name==="intro"?(tt(),nt("g",bf,[...e[48]||(e[48]=[$e('<rect x="2" y="4" width="20" height="16" rx="2" data-v-b8552023></rect><circle cx="7.5" cy="9.5" r="2" data-v-b8552023></circle><path d="M4.5 16.5c0-1.8 1.3-3 3-3s3 1.2 3 3" data-v-b8552023></path><line x1="13" y1="9" x2="18.5" y2="9" data-v-b8552023></line><line x1="13" y1="12.5" x2="19.5" y2="12.5" data-v-b8552023></line><line x1="13" y1="15.5" x2="17" y2="15.5" data-v-b8552023></line>',6)])])):t.name==="layout-quote"||t.name==="quote"?(tt(),nt("g",yf,[...e[49]||(e[49]=[$e('<rect x="2" y="4" width="20" height="16" rx="2" data-v-b8552023></rect><path d="M6 7.5h2v2H6.5c0 1.2-.4 2-1.5 2.5" data-v-b8552023></path><path d="M9.5 7.5h2v2H10c0 1.2-.4 2-1.5 2.5" data-v-b8552023></path><line x1="6" y1="13.5" x2="18" y2="13.5" data-v-b8552023></line><line x1="12.5" y1="16.5" x2="17.5" y2="16.5" data-v-b8552023></line>',5)])])):t.name==="desktop"||t.name==="monitor"?(tt(),nt("g",wf,[...e[50]||(e[50]=[g("rect",{x:"2",y:"3",width:"20",height:"14",rx:"2"},null,-1),g("line",{x1:"8",y1:"21",x2:"16",y2:"21"},null,-1),g("line",{x1:"12",y1:"17",x2:"12",y2:"21"},null,-1)])])):t.name==="mobile"||t.name==="smartphone"||t.name==="phone"?(tt(),nt("g",kf,[...e[51]||(e[51]=[g("rect",{x:"5",y:"2",width:"14",height:"20",rx:"2",ry:"2"},null,-1),g("line",{x1:"12",y1:"18",x2:"12.01",y2:"18","stroke-width":"2","stroke-linecap":"round"},null,-1)])])):(tt(),nt("g",xf,[...e[52]||(e[52]=[g("rect",{x:"2",y:"3",width:"20",height:"14",rx:"2"},null,-1),g("line",{x1:"8",y1:"21",x2:"16",y2:"21"},null,-1),g("line",{x1:"12",y1:"17",x2:"12",y2:"21"},null,-1)])]))]))}}),Le=(t,i)=>{const e=t.__vccOpts||t;for(const[n,s]of i)e[n]=s;return e},wt=Le(_f,[["__scopeId","data-v-b8552023"]]);function se(t,i){var s;if(typeof document>"u"||!t)return;const e=(s=globalThis.CSS)!=null&&s.escape?globalThis.CSS.escape(t):t.replace(/"/g,'\\"'),n=document.querySelectorAll(`[data-node-id="${e}"]`);!n||n.length===0||n.forEach(r=>{for(const[l,o]of Object.entries(i))o!=null&&o!==""?r.setAttribute(l,String(o)):r.removeAttribute(l)})}function Sf(t){if(typeof document>"u")return;const i=`.protyle-wysiwyg [${ft}], .protyle-wysiwyg [${qt}], .protyle-wysiwyg [custom-slidev-layout], .protyle-wysiwyg [custom-slidev-role]`,e=document.querySelectorAll(i);!e||e.length===0||e.forEach(n=>{const s=n.getAttribute("data-node-id");if(!s){n.removeAttribute(ft),n.removeAttribute("custom-slidev-layout"),n.removeAttribute(qt),n.removeAttribute("custom-slidev-role");return}const r=t.get(s),l=(r==null?void 0:r[ft])||(r==null?void 0:r["custom-slidev-layout"])||"",o=n.getAttribute(ft)||n.getAttribute("custom-slidev-layout");o&&o!==l&&(l?n.setAttribute(ft,l):(n.removeAttribute(ft),n.removeAttribute("custom-slidev-layout")));const a=(r==null?void 0:r[qt])||(r==null?void 0:r["custom-slidev-role"])||"",c=n.getAttribute(qt)||n.getAttribute("custom-slidev-role");c&&c!==a&&(a?n.setAttribute(qt,a):(n.removeAttribute(qt),n.removeAttribute("custom-slidev-role")))})}const Cf={class:"spm-layout-picker"},$f={class:"spm-layout-picker__grid"},If=["title","onClick"],Af={class:"spm-layout-icon"},Ef={class:"spm-layout-label"},Tf=be({__name:"LayoutPicker",props:{modelValue:{}},emits:["update:modelValue","change"],setup(t,{emit:i}){const e=i,n=[{name:"cover",label:"封面",desc:"大标题与副标题封面页"},{name:"default",label:"标准",desc:"标题在上方，内容在下方"},{name:"two-cols",label:"双栏",desc:"左右双栏对比展示"},{name:"two-cols-header",label:"表头双栏",desc:"顶部通栏标题，下方左右双栏"},{name:"three-cols-header",label:"表头三栏",desc:"顶部通栏标题，下方等宽三栏"},{name:"image-right",label:"图右",desc:"左侧为内容，右侧全屏背景图"},{name:"image-left",label:"图左",desc:"左侧全屏背景图，右侧为内容"},{name:"center",label:"居中",desc:"内容全屏垂直水平居中"},{name:"fact",label:"大字报",desc:"核心数据或指标突出展示"},{name:"intro",label:"介绍",desc:"演讲者自我介绍或章节导览"},{name:"quote",label:"引言",desc:"名人名言与强调段落"}];function s(r){e("update:modelValue",r),e("change",r)}return(r,l)=>(tt(),nt("div",Cf,[l[0]||(l[0]=g("div",{class:"spm-layout-picker__header"},"选择页面版式",-1)),g("div",$f,[(tt(),nt(Gt,null,ye(n,o=>g("div",{key:o.name,class:Tt(["spm-layout-item",{active:t.modelValue===o.name}]),title:o.desc,onClick:a=>s(o.name)},[g("div",Af,[pt(wt,{name:"layout-"+o.name},null,8,["name"])]),g("span",Ef,St(o.label),1)],10,If)),64))])]))}}),Hl=Le(Tf,[["__scopeId","data-v-c57441d5"]]),Mf={key:0,class:"spm-transition-selector__header"},Bf={class:"spm-transition-list"},Df=["onClick"],Of={class:"spm-transition-meta"},Pf={class:"spm-transition-label"},Lf={class:"spm-transition-name"},Rf={class:"spm-transition-preview-box"},zf=be({__name:"TransitionSelector",props:{modelValue:{},hideHeader:{type:Boolean},title:{}},emits:["update:modelValue","change"],setup(t,{emit:i}){const e=i,n=[{name:"slide-left",label:"向左滑入",desc:"向左滑入 (slide-left)：页面从右侧向左平滑推入，最通用标准的横向幻灯片动效"},{name:"slide-right",label:"向右滑入",desc:"向右滑入 (slide-right)：页面从左侧向右平滑推入，适合倒序回退或逆向章节叙述"},{name:"slide-up",label:"向上推入",desc:"向上推入 (slide-up)：页面从底部向上平滑推入，适合纵向展开或纵深层级展示"},{name:"fade",label:"淡入淡出",desc:"淡入淡出 (fade)：透明度平滑渐变过度，典雅柔和，适合学术长篇与沉浸叙事"},{name:"zoom",label:"缩放进入",desc:"缩放进入 (zoom)：页面由中心向外平滑放大，富有动感冲击力，适合聚焦重点"}];function s(r){e("update:modelValue",r),e("change",r)}return(r,l)=>(tt(),nt("div",{class:Tt(["spm-transition-selector",{"spm-transition-selector--no-header":t.hideHeader}])},[t.hideHeader?Ft("",!0):(tt(),nt("div",Mf,St(t.title||"转场动效"),1)),g("div",Bf,[(tt(),nt(Gt,null,ye(n,o=>g("div",{key:o.name,class:Tt(["spm-transition-item",{active:t.modelValue===o.name}]),onClick:a=>s(o.name)},[g("div",Of,[g("span",Pf,St(o.label),1),g("span",Lf,"("+St(o.name)+")",1)]),g("div",Rf,[g("div",{class:Tt(["spm-anim-cube","anim-"+o.name])},null,2)])],10,Df)),64))])],2))}}),So=Le(zf,[["__scopeId","data-v-b0aa61ff"]]),Nf={class:"spm-divider-popover"},Ff={class:"spm-divider-popover__title"},jf={class:"spm-form-item"},Hf={class:"spm-popover-footer"},Uf={class:"spm-save-hint"},Wf=be({__name:"QuickDividerPopover",props:{blockId:{},initialAttrs:{}},emits:["close","updated"],setup(t,{emit:i}){var m,p,y;const e=t,n=i,s=ht(((m=e.initialAttrs)==null?void 0:m[ft])||"default"),r=ht(((p=e.initialAttrs)==null?void 0:p[Xt])||"slide-left"),l=ht(((y=e.initialAttrs)==null?void 0:y[Ut])||""),o=ht("");Ei(()=>e.initialAttrs,f=>{s.value=(f==null?void 0:f[ft])||"default",r.value=(f==null?void 0:f[Xt])||"slide-left",l.value=(f==null?void 0:f[Ut])||""},{deep:!0});async function a(f,k){if(e.blockId){o.value="正在同步...",Ht.setBlockAttrOverride(e.blockId,{[f]:k}),se(e.blockId,{[f]:k});try{await zt(e.blockId,{[f]:k}),o.value="已同步至块属性",n("updated",{[f]:k}),setTimeout(()=>{o.value=""},1500)}catch{o.value="同步失败"}}}function c(f){a(ft,f)}function d(f){a(Xt,f)}function h(){a(Ut,l.value.trim())}return(f,k)=>(tt(),nt("div",Nf,[g("div",Ff,[k[4]||(k[4]=g("span",null,"幻灯片页面设置",-1)),g("button",{class:"spm-close-btn",onClick:k[0]||(k[0]=v=>n("close"))},"✕")]),pt(Hl,{modelValue:s.value,"onUpdate:modelValue":k[1]||(k[1]=v=>s.value=v),onChange:c},null,8,["modelValue"]),pt(So,{modelValue:r.value,"onUpdate:modelValue":k[2]||(k[2]=v=>r.value=v),onChange:d},null,8,["modelValue"]),g("div",jf,[k[5]||(k[5]=g("label",{class:"spm-form-label"},"页面背景",-1)),Ie(g("input",{"onUpdate:modelValue":k[3]||(k[3]=v=>l.value=v),class:"spm-input",placeholder:"assets/bg.jpg 或颜色值 (#1e1e24)",onBlur:h},null,544),[[es,l.value]])]),g("div",Hf,[g("span",Uf,St(o.value),1)])]))}}),Vf=Le(Wf,[["__scopeId","data-v-e4871368"]]),Kf={class:"spm-slide-inspector"},qf={class:"spm-inspector-header"},Gf={class:"spm-inspector-list"},Zf=["onClick"],Yf={class:"spm-card-top"},Jf={class:"spm-card-badge"},Xf={class:"spm-card-layout"},Qf=["onClick"],tp={class:"spm-card-preview"},ep={key:0,class:"spm-card-notes",title:"演讲备忘录"},ip={class:"spm-inspector-modal-content"},np=be({__name:"SlideInspector",props:{slides:{},currentActivePage:{}},emits:["navigate","refresh"],setup(t,{emit:i}){const e=i,n=ht(null);function s(c){n.value=c}function r(c){const d={};return c.frontmatter.layout&&(d[ft]=c.frontmatter.layout),c.frontmatter.transition&&(d[Xt]=c.frontmatter.transition),c.frontmatter.background&&(d[Ut]=c.frontmatter.background),c.notes&&(d[zi]=c.notes),d}function l(c){n.value&&(c[ft]&&(n.value.frontmatter.layout=c[ft]),c[Xt]&&(n.value.frontmatter.transition=c[Xt]),c[Ut]&&(n.value.frontmatter.background=c[Ut]),c[zi]&&(n.value.notes=c[zi]),e("refresh"))}function o(c){e("navigate",c)}function a(c){if(!c.blocks||c.blocks.length===0)return"(空白页)";const d=c.blocks[0],h=d.content||d.rawMarkdown||"";return h.slice(0,40)+(h.length>40?"...":"")}return(c,d)=>(tt(),nt("div",Kf,[g("div",qf,[g("span",null,"幻灯片大纲 ("+St(t.slides.length)+" 页)",1)]),g("div",Gf,[(tt(!0),nt(Gt,null,ye(t.slides,h=>(tt(),nt("div",{key:h.pageIndex,class:Tt(["spm-card",{active:t.currentActivePage===h.pageIndex}]),onClick:m=>o(h.pageIndex)},[g("div",Yf,[g("span",Jf,"P"+St(h.pageIndex),1),g("span",Xf,St(h.frontmatter.layout||"default"),1),g("button",{class:"spm-card-btn-edit",title:"配置此页版式与属性",onClick:Ee(m=>s(h),["stop"])},[pt(wt,{name:"settings"})],8,Qf)]),g("div",tp,St(a(h)),1),h.notes?(tt(),nt("div",ep,[pt(wt,{name:"notes",style:{"font-size":"11px","margin-right":"3px"}}),g("span",null,St(h.notes),1)])):Ft("",!0)],10,Zf))),128))]),n.value?(tt(),nt("div",{key:0,class:"spm-inspector-modal-mask",onClick:d[1]||(d[1]=Ee(h=>n.value=null,["self"]))},[g("div",ip,[pt(Vf,{"block-id":n.value.startBlockId,"initial-attrs":r(n.value),onClose:d[0]||(d[0]=h=>n.value=null),onUpdated:l},null,8,["block-id","initial-attrs"])])])):Ft("",!0)]))}}),sp=Le(np,[["__scopeId","data-v-68b25edd"]]),op={class:"spm-immersion-header"},rp={class:"spm-immersion-header__left"},lp={class:"spm-immersion-title"},ap={class:"spm-immersion-header__center"},cp={class:"spm-immersion-header__actions"},dp=["aria-label"],up={class:"spm-immersion-body"},fp=be({__name:"ImmersionDrawerContainer",props:{visible:{type:Boolean,default:!1},isMaximized:{type:Boolean,default:!1},title:{default:"速览"},closeOnClickMask:{type:Boolean,default:!0}},emits:["update:visible","update:isMaximized","close","toggle-maximize"],setup(t,{emit:i}){const e=t,n=i;function s(){n("update:visible",!1),n("close")}function r(){e.closeOnClickMask&&s()}function l(){n("update:isMaximized",!e.isMaximized),n("toggle-maximize")}function o(a){(a.key===" "||a.key==="ArrowLeft"||a.key==="ArrowRight"||a.key==="PageUp"||a.key==="PageDown")&&a.stopPropagation(),a.key==="Escape"&&(a.preventDefault(),a.stopPropagation(),s())}return(a,c)=>Ie((tt(),nt("div",{class:Tt(["spm-immersion-container",{"is-maximized":t.isMaximized}]),onKeydown:Ee(o,["stop"])},[g("div",{class:"spm-immersion-mask",onClick:r}),g("div",{class:Tt(["spm-immersion-drawer",{"is-maximized":t.isMaximized}])},[g("div",op,[g("div",rp,[Pn(a.$slots,"header-left",{},()=>[g("span",lp,St(t.title),1)])]),g("div",ap,[Pn(a.$slots,"header-center",{},void 0)]),g("div",cp,[Pn(a.$slots,"header-actions",{},void 0),g("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":t.isMaximized?"还原抽屉宽度 (70%)":"最大化填满视口 (100%)",onClick:l},[pt(wt,{name:t.isMaximized?"minimize":"maximize"},null,8,["name"])],8,dp),g("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"关闭速览 (ESC)",onClick:s},[pt(wt,{name:"close"})])])]),g("div",up,[Pn(a.$slots,"default",{},void 0)])],2)],34)),[[Ll,t.visible]])}}),pp=Le(fp,[["__scopeId","data-v-3f1665db"]]),hp="slidev-config.json",Yi={enableWebServeJump:!1,webServeUrl:"http://127.0.0.1:6806"},$i=cs({...Yi});function mp(t){if(!t||typeof t!="object")return{...Yi};const i=t;return{enableWebServeJump:!!i.enableWebServeJump,webServeUrl:typeof i.webServeUrl=="string"&&i.webServeUrl.trim()?i.webServeUrl.trim():Yi.webServeUrl}}function Vi(t){if(!t||typeof t!="object")return{...$i};const i=t;return i.enableWebServeJump!==void 0&&($i.enableWebServeJump=!!i.enableWebServeJump),i.webServeUrl!==void 0&&($i.webServeUrl=String(i.webServeUrl)),{...$i}}function Co(){return{...$i}}function Ul(t,i,e){const n=(t||Yi.webServeUrl).trim(),s=n.startsWith("http://")||n.startsWith("https://")?n:`http://${n}`,r=(e==null?void 0:e.r)||Math.random().toString(36).slice(2,9).padEnd(7,"0");try{const l=new URL(s);let o=l.pathname.replace(/\/+$/,"");return o.endsWith("/stage/build/desktop")||(o=o?`${o}/stage/build/desktop`:"/stage/build/desktop"),l.pathname=`${o}/`,l.searchParams.set("id",i),e!=null&&e.focus&&l.searchParams.set("focus","1"),l.searchParams.set("r",r),l.toString()}catch{const l=e!=null&&e.focus?"&focus=1":"";return`${s.replace(/\/+$/,"")}/stage/build/desktop/?id=${i}${l}&r=${r}`}}const gp={class:"spm-protyle-drawer"},vp={class:"spm-protyle-drawer__subbar"},bp={class:"spm-protyle-drawer__nav"},yp=["title"],wp={class:"spm-protyle-drawer__actions"},kp=["aria-label"],xp=["aria-label"],_p=be({__name:"ProtylePeekDrawer",props:{blockId:{},title:{},plugin:{}},emits:["external-jump"],setup(t,{emit:i}){const e=i,n=t,s=ht(n.blockId),r=ht(n.title||""),l=ht(!1),o=ht(!0),a=ht(!1),c=ht(""),d=$i,h=ht([]),m=ht(null);let p=null;Ei(()=>n.blockId,A=>{A&&A!==s.value&&(s.value=A,r.value=n.title||"",h.value=[],f(A))}),Cn(()=>{s.value&&f(s.value)}),mo(()=>{k()});async function y(A){try{const B=await mn(`SELECT id, root_id, type, content FROM blocks WHERE id = '${A}' LIMIT 1`);if(Array.isArray(B)&&B.length>0){const P=B[0];c.value=P.root_id||"";const R=P.id===P.root_id||P.type==="d";a.value=R,o.value=!R,!r.value&&P.content&&(r.value=P.content.trim().slice(0,30));return}}catch(B){console.warn("[ProtylePeekDrawer] detectBlockType query failed:",B)}a.value=!1,o.value=!0}async function f(A,B){if(!m.value||!A)return;k(),await y(A),typeof B=="boolean"&&(o.value=!a.value&&B);let P,R;o.value&&!a.value?(P=["cb-get-all","cb-get-hl","cb-get-focus"],R={background:!1,title:!1,gutter:!0,breadcrumbDocName:!0,scroll:!0}):(P=["cb-get-context","cb-get-hl"],R={background:!0,title:!0,gutter:!0,breadcrumbDocName:!0,scroll:!0});try{p=new vt.Protyle(n.plugin.app,m.value,{blockId:A,action:P,render:R}),!l.value&&p&&typeof p.disable=="function"&&p.disable()}catch(X){console.error("[ProtylePeekDrawer] Failed to instantiate Protyle:",X)}}function k(){if(p){try{typeof p.destroy=="function"&&p.destroy()}catch(A){console.warn("[ProtylePeekDrawer] Error destroying protyle:",A)}p=null}m.value&&(m.value.innerHTML="")}function v(){a.value||(o.value=!o.value,f(s.value,o.value))}function w(){l.value=!l.value,p&&(l.value?(typeof p.enable=="function"&&p.enable(),typeof p.focus=="function"&&p.focus()):typeof p.disable=="function"&&p.disable())}function x(){if(s.value)try{vt.openWindow({doc:{id:s.value},alwaysOnTop:!0})}catch(A){console.warn("[ProtylePeekDrawer] openWindow failed:",A)}}function E(){var P;if(!s.value)return;const A=Co(),B=Ul(A.webServeUrl,s.value,{focus:!a.value});if(typeof window<"u"){const R=ke("electron");(P=R==null?void 0:R.shell)!=null&&P.openExternal?R.shell.openExternal(B).catch(()=>{window.open(B,"_blank")}):window.open(B,"_blank")}e("external-jump",B)}function _(){if(h.value.length>0){const A=h.value.pop();A&&(s.value=A.blockId,r.value=A.title,o.value=A.isFocusMode,a.value=A.isDoc,f(A.blockId,A.isFocusMode))}}function C(A){const B=A.target;if(!B)return;const P=B.closest('[data-type="block-ref"]');if(P){const X=P.getAttribute("data-id");if(X&&X!==s.value){A.preventDefault(),A.stopPropagation(),h.value.push({blockId:s.value,title:r.value||s.value,isFocusMode:o.value,isDoc:a.value}),s.value=X,r.value=P.innerText.trim()||X,f(X);return}}const R=B.closest("a");if(R&&R.href&&R.href.startsWith("siyuan://blocks/")){A.preventDefault(),A.stopPropagation();const X=R.href.replace("siyuan://blocks/","").split("?")[0];X&&X!==s.value&&(h.value.push({blockId:s.value,title:r.value||s.value,isFocusMode:o.value,isDoc:a.value}),s.value=X,r.value=R.innerText.trim()||X,f(X))}}return(A,B)=>(tt(),nt("div",gp,[g("div",vp,[g("div",bp,[h.value.length>0?(tt(),nt("button",{key:0,class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"返回上层引用文档或块",onClick:_},[pt(wt,{name:"arrow-left"}),B[0]||(B[0]=g("span",null,"返回",-1))])):Ft("",!0),g("span",{class:Tt(["spm-protyle-badge",{"is-focus":o.value&&!a.value}])},St(o.value&&!a.value?"思源块聚焦":"思源文档速览"),3),g("span",{class:"spm-protyle-id",title:r.value||s.value},St(r.value||s.value),9,yp)]),g("div",wp,[a.value?Ft("",!0):(tt(),nt("button",{key:0,class:Tt(["spm-icon-btn b3-tooltips b3-tooltips__s",{"is-primary":o.value}]),"aria-label":o.value?"当前为块聚焦模式（点击展开所属文档全文）":"当前为文档全文模式（点击切回仅聚焦当前块）",onClick:v},[pt(wt,{name:o.value?"focus":"file-text"},null,8,["name"]),g("span",null,St(o.value?"块聚焦":"展开全文"),1)],10,kp)),g("button",{class:Tt(["spm-icon-btn b3-tooltips b3-tooltips__s",{"is-primary":l.value}]),"aria-label":l.value?"当前为即时编辑模式（点击切回只读）":"当前为只读速览模式（点击解锁即时编辑）",onClick:w},[pt(wt,{name:l.value?"edit":"eye"},null,8,["name"]),g("span",null,St(l.value?"编辑中":"只读"),1)],10,xp),g("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"在置顶独立窗口中打开 (保留完整侧边栏与插件)",onClick:x},[pt(wt,{name:"window"}),B[1]||(B[1]=g("span",null,"独立窗口",-1))]),Ci(d).enableWebServeJump?(tt(),nt("button",{key:1,class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"在系统默认浏览器中打开 (外跳)",onClick:E},[pt(wt,{name:"external-link"}),B[2]||(B[2]=g("span",null,"外跳",-1))])):Ft("",!0)])]),g("div",{ref_key:"mountEl",ref:m,class:Tt(["spm-protyle-mount",{"is-focus-mode":o.value&&!a.value}]),onClick:C},null,2)]))}}),Sp=Le(_p,[["__scopeId","data-v-7e586ef3"]]),Cp={class:"spm-webview-drawer"},$p={class:"spm-webview-toolbar"},Ip={class:"spm-webview-toolbar__nav"},Ap=["disabled"],Ep=["disabled"],Tp=["aria-label"],Mp={class:"spm-webview-toolbar__address"},Bp=["aria-label"],Dp={class:"spm-webview-toolbar__actions"},Op=["aria-label"],Pp={class:"spm-zoom-controller"},Lp=["disabled"],Rp=["disabled"],zp={key:1,class:"spm-webview-fallback"},Np=["src"],gr="Mozilla/5.0 (iPhone; CPU iPhone OS 17_4_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.4.1 Mobile/15E148 Safari/604.1",Wl="siyuan-slidev-peek-view-mode";let Vl="desktop";function Fp(){if(typeof window<"u"&&window.localStorage)try{const t=window.localStorage.getItem(Wl);if(t==="mobile"||t==="desktop")return t}catch{}return Vl}function jp(t){if(Vl=t,typeof window<"u"&&window.localStorage)try{window.localStorage.setItem(Wl,t)}catch{}}const Hp=be({__name:"WebviewPeekDrawer",props:{url:{},title:{},visible:{type:Boolean,default:!0}},emits:["external-jump"],setup(t,{emit:i}){const e=i,n=t,s=ht(Nl()),r=ht(n.url),l=ht(n.url),o=ht(!1),a=ht(!1),c=ht(!1),d=ht(1),h=ht(!1),m=ht(Fp());let p=typeof navigator<"u"&&!navigator.userAgent.includes("iPhone")?navigator.userAgent:"";const y=$t(()=>m.value==="mobile"?gr:p||void 0),f=ht(null),k=ht(null);let v=null,w=null,x=null;Ei(()=>n.url,J=>{J&&J!==r.value&&(r.value=J,l.value=J,m.value==="mobile"&&B(!1),f.value&&typeof f.value.loadURL=="function"&&f.value.loadURL(J))}),Ei(()=>n.visible,J=>{if(J)K(),m.value==="mobile"&&B(!1);else if(f.value)try{typeof f.value.stop=="function"&&f.value.stop()}catch{}}),Cn(()=>{E(),k.value&&typeof ResizeObserver<"u"&&(v=new ResizeObserver(()=>{const J=f.value;if(J&&typeof J.invalidate=="function")try{J.invalidate()}catch{}}),v.observe(k.value)),w=J=>{var gt;const mt=J.message||((gt=J.error)==null?void 0:gt.message);if(typeof mt=="string"&&mt.includes("Invalid guestInstanceId"))return J.preventDefault(),J.stopImmediatePropagation(),!0},window.addEventListener("error",w,!0),x=J=>{const mt=J.reason,gt=typeof mt=="string"?mt:mt==null?void 0:mt.message;typeof gt=="string"&&gt.includes("Invalid guestInstanceId")&&J.preventDefault()},window.addEventListener("unhandledrejection",x)}),mo(()=>{if(_(),v&&(v.disconnect(),v=null),w&&(window.removeEventListener("error",w,!0),w=null),x&&(window.removeEventListener("unhandledrejection",x),x=null),f.value)try{typeof f.value.stop=="function"&&f.value.stop()}catch{}});function E(){const J=f.value;J&&(J.addEventListener("dom-ready",C),J.addEventListener("did-start-loading",P),J.addEventListener("did-stop-loading",R),J.addEventListener("did-navigate",X),J.addEventListener("did-navigate-in-page",S),J.addEventListener("new-window",G))}function _(){const J=f.value;if(J)try{J.removeEventListener("dom-ready",C),J.removeEventListener("did-start-loading",P),J.removeEventListener("did-stop-loading",R),J.removeEventListener("did-navigate",X),J.removeEventListener("did-navigate-in-page",S),J.removeEventListener("new-window",G)}catch{}}function C(){const J=f.value;if(J&&typeof J.getUserAgent=="function"&&!p)try{const mt=J.getUserAgent();mt&&!mt.includes("iPhone")&&(p=mt)}catch{}m.value==="mobile"&&B(!1),K(),b()}function A(){const J=m.value==="mobile"?"desktop":"mobile";m.value=J,jp(J),B(!0)}function B(J=!1){const mt=f.value;if(!mt)return;const gt=m.value==="mobile"?gr:p;if(typeof mt.setUserAgent=="function"&&gt)try{mt.setUserAgent(gt)}catch(Z){console.warn("[WebviewPeekDrawer] setUserAgent error:",Z)}if(J&&typeof mt.reload=="function")try{mt.reload()}catch(Z){console.warn("[WebviewPeekDrawer] reload error:",Z)}}function P(){o.value=!0}function R(){if(o.value=!1,b(),f.value&&typeof f.value.getURL=="function"){const J=f.value.getURL();J&&J!=="about:blank"&&(r.value=J,l.value=J)}}function X(J){J!=null&&J.url&&(r.value=J.url,l.value=J.url),b()}function S(J){J!=null&&J.url&&(r.value=J.url,l.value=J.url),b()}function G(J){J&&J.url&&(J.preventDefault(),f.value&&typeof f.value.loadURL=="function"&&f.value.loadURL(J.url))}function b(){const J=f.value;J&&(typeof J.canGoBack=="function"&&(a.value=J.canGoBack()),typeof J.canGoForward=="function"&&(c.value=J.canGoForward()))}function U(){f.value&&typeof f.value.goBack=="function"&&f.value.goBack()}function it(){f.value&&typeof f.value.goForward=="function"&&f.value.goForward()}function j(){f.value&&typeof f.value.reload=="function"&&f.value.reload()}function st(){let J=l.value.trim();J&&(/^https?:\/\//i.test(J)||(J=`https://${J}`),r.value=J,l.value=J,f.value&&typeof f.value.loadURL=="function"&&f.value.loadURL(J))}function K(){const J=f.value;if(J&&typeof J.setZoomFactor=="function")try{J.setZoomFactor(d.value)}catch(mt){console.warn("[WebviewPeekDrawer] setZoomFactor error:",mt)}}function Y(){d.value=Math.min(2.5,Math.round((d.value+.1)*10)/10),K()}function H(){d.value=Math.max(.5,Math.round((d.value-.1)*10)/10),K()}function L(){d.value=1,K()}function ct(J){J.preventDefault(),J.deltaY<0?Y():J.deltaY>0&&H()}async function rt(){if(typeof navigator<"u"&&navigator.clipboard)try{await navigator.clipboard.writeText(r.value),h.value=!0,setTimeout(()=>{h.value=!1},2e3)}catch(J){console.warn("Copy url failed:",J)}}function ot(){var mt;const J=r.value;if(typeof window<"u"){const gt=ke("electron");(mt=gt==null?void 0:gt.shell)!=null&&mt.openExternal?gt.shell.openExternal(J).catch(()=>{window.open(J,"_blank")}):window.open(J,"_blank")}e("external-jump",J)}return(J,mt)=>{const gt=Kc("webview");return tt(),nt("div",Cp,[g("div",$p,[g("div",Ip,[g("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s",disabled:!a.value,"aria-label":"后退",onClick:U},[pt(wt,{name:"arrow-left"})],8,Ap),g("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s",disabled:!c.value,"aria-label":"前进",onClick:it},[pt(wt,{name:"arrow-right"})],8,Ep),g("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":o.value?"正在加载...":"刷新页面",onClick:j},[pt(wt,{name:"refresh"})],8,Tp)]),g("div",Mp,[Ie(g("input",{"onUpdate:modelValue":mt[0]||(mt[0]=Z=>l.value=Z),type:"text",class:"b3-text-field spm-url-input",placeholder:"https://...",spellcheck:"false",onKeydown:lu(st,["enter"])},null,544),[[es,l.value]]),g("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":h.value?"已复制地址！":"复制网址",onClick:rt},[pt(wt,{name:"copy"})],8,Bp)]),g("div",Dp,[g("button",{class:Tt(["spm-icon-btn spm-mode-toggle b3-tooltips b3-tooltips__s",{"is-active":m.value==="mobile"}]),"aria-label":m.value==="mobile"?"当前为手机视图，点击切换为桌面视图":"当前为桌面视图，点击切换为手机视图",onClick:A},[pt(wt,{name:m.value==="mobile"?"mobile":"desktop"},null,8,["name"])],10,Op),g("div",Pp,[g("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"缩小 (Ctrl + -)",disabled:d.value<=.5,onClick:H},[pt(wt,{name:"minus"})],8,Lp),g("button",{class:"spm-zoom-badge b3-tooltips b3-tooltips__s","aria-label":"重置 100% (Ctrl + 0)",onClick:L},St(Math.round(d.value*100))+"% ",1),g("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"放大 (Ctrl + +)",disabled:d.value>=2.5,onClick:Y},[pt(wt,{name:"plus"})],8,Rp)]),g("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"在系统默认浏览器中打开 ↗",onClick:ot},[pt(wt,{name:"external-link"}),mt[1]||(mt[1]=g("span",null,"外跳",-1))])])]),g("div",{ref_key:"containerEl",ref:k,class:Tt(["spm-webview-body",{"is-mobile":m.value==="mobile"}]),onWheel:Ee(ct,["ctrl"])},[g("div",{class:Tt(["spm-webview-viewport",{"is-mobile":m.value==="mobile"}])},[s.value?(tt(),Te(gt,{key:0,ref_key:"webviewRef",ref:f,class:"spm-webview-frame",src:r.value,useragent:y.value,allowpopups:"true",partition:"persist:slidev-peek",style:{position:"absolute",top:"0",left:"0",width:"100%",height:"100%",display:"inline-flex"}},null,8,["src","useragent"])):(tt(),nt("div",zp,[g("iframe",{class:"spm-webview-fallback-frame",src:r.value,frameborder:"0",sandbox:"allow-scripts allow-same-origin allow-forms allow-popups"},null,8,Np),g("div",{class:"spm-fallback-bar"},[mt[2]||(mt[2]=g("span",null,"如页面受同源策略 (X-Frame-Options) 拦截无法显示，请",-1)),g("button",{class:"spm-icon-btn is-primary",onClick:ot}," 在新标签页中打开 ↗ ")])]))],2)],34)])}}}),Up=Le(Hp,[["__scopeId","data-v-40e35375"]]);class Wp{constructor(){kt(this,"timers",new Map)}debounce(i,e,n=150){this.cancel(i);const s=setTimeout(()=>{this.timers.delete(i),e()},n);this.timers.set(i,s)}cancel(i){this.timers.has(i)&&(clearTimeout(this.timers.get(i)),this.timers.delete(i))}cancelAll(){for(const i of this.timers.values())clearTimeout(i);this.timers.clear()}hasPending(i){return this.timers.has(i)}}class Vp{constructor(i){kt(this,"blockToPageMap",new Map);kt(this,"debounceCtrl",new Wp);kt(this,"activeBlockId","");kt(this,"activePageIndex",1);kt(this,"currentDocId","");kt(this,"bridge",null);i&&(this.bridge=i)}setBridge(i){this.bridge=i}setDocId(i){this.currentDocId=i}updateSlidesIndex(i){this.blockToPageMap.clear();for(const e of i){e.startBlockId&&this.blockToPageMap.set(e.startBlockId,e.pageIndex);for(const n of e.blocks)this.blockToPageMap.set(n.id,e.pageIndex)}}getPageByBlockId(i){return this.blockToPageMap.get(i)??null}onCursorFocusBlock(i){if(!i||i===this.activeBlockId)return;this.activeBlockId=i;let e=this.getPageByBlockId(i);!e&&(i===this.currentDocId||!this.currentDocId&&this.blockToPageMap.size>0)&&(e=1),e&&this.debounceCtrl.debounce("cursor-navigate",()=>{this.activePageIndex=e,this.bridge&&(this.bridge.navigatePage(e),this.bridge.highlightElement(i))},100)}getActiveBlockId(){return this.activeBlockId}setActiveBlockId(i){this.activeBlockId=i;const e=this.getPageByBlockId(i);e&&(this.activePageIndex=e)}getActivePageIndex(){return this.activePageIndex}destroy(){this.debounceCtrl.cancelAll(),this.blockToPageMap.clear(),this.bridge=null}}function Ti(t,i){var r,l;if(!t||typeof document>"u")return!1;const e=(r=globalThis.CSS)!=null&&r.escape?globalThis.CSS.escape(t):t.replace(/"/g,'\\"'),n=document.querySelector(`.protyle-wysiwyg [data-node-id="${e}"]`)||document.querySelector(`[data-node-id="${e}"]`);if(!n){if(i)try{return vt.openTab({app:i,doc:{id:t,action:["cb-get-hl","cb-get-focus","cb-get-context"]}}),!0}catch(o){console.warn("[SelectionMirror] openTab fallback failed:",o)}return!1}try{n.scrollIntoView({behavior:"smooth",block:"center",inline:"nearest"})}catch{n.scrollIntoView()}try{(l=n.focus)==null||l.call(n,{preventScroll:!0})}catch{}n.classList.add("protyle-wysiwyg--select");const s=n.style.outline;return n.style.outline="2px solid #3b82f6",n.style.transition="outline 0.3s ease",setTimeout(()=>{n.classList.remove("protyle-wysiwyg--select"),n.style.outline=s},1200),!0}function fe(t){return t?t.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&#039;"):""}function Kp(t){if(!t||t.trim()===""||t.trim()==="all")return"all";const i=new Set,e=t.split("|");for(const n of e){const s=n.trim();if(s==="all")return"all";if(s.includes("-")){const[r,l]=s.split("-"),o=parseInt(r,10),a=parseInt(l,10);if(!isNaN(o)&&!isNaN(a))for(let c=Math.min(o,a);c<=Math.max(o,a);c++)i.add(c)}else{const r=parseInt(s,10);isNaN(r)||i.add(r)}}return i}const qp=new Set(["kbd","mark","sub","sup","span","a","br","b","i","u","s","del","em","strong","code","small","abbr","ruby","rt","rp","v-mark","img","video","source","picture"]);function Me(t){if(!t)return"";const i=[],e=t.replace(/<\/?([a-zA-Z0-9_-]+)(?:\s+[^<>]*)?\/?>/g,(s,r)=>{const l=r.toLowerCase();if(!qp.has(l)||/on\w+\s*=|javascript:/i.test(s))return s;if(l==="v-mark"){const o=s.match(/type=["']?([a-zA-Z-]+)["']?/),a=o?o[1]:"circle";return s.startsWith("</")?i.push("</mark>"):i.push(`<mark class="v-mark v-mark--${a}">`),`%%SAFE_HTML_${i.length-1}%%`}return i.push(s),`%%SAFE_HTML_${i.length-1}%%`});let n=fe(e);return n=n.replace(/\(\(([0-9a-zA-Z-]+)(?:\s*(?:&#039;([^&#]*)&#039;|&quot;([^&]*)&quot;|'([^']*)'|"([^"]*)"|([^\)]+?)))?\s*\)\)/g,(s,r,l,o,a,c,d)=>{const m=(l??o??a??c??d??"").trim()||`Ref(${r.slice(0,8)})`;return`<a href="siyuan://blocks/${r}" data-ref-id="${r}" class="slidev-ref-tag">🔗 ${m}</a>`}),n=n.replace(/\$([^$\n]+)\$/g,'<span class="katex-inline font-math"><em>$1</em></span>'),n=n.replace(/!\[(.*?)\]\((.*?)\)/g,(s,r,l)=>{const a=/\.gif(?:\?|$)/i.test(l)?"slide-inline-img list-item-gif":"slide-inline-img";return`<img alt="${r}" src="${l}" class="${a}" />`}),n=n.replace(/\[(.*?)\]\((.*?)\)/g,(s,r,l)=>{if(l.startsWith("siyuan://blocks/")){const o=l.replace("siyuan://blocks/","").split("?")[0];return`<a href="${l}" data-ref-id="${o}" class="slidev-ref-tag">🔗 ${r}</a>`}return`<a href="${l}" target="_blank" rel="noopener noreferrer" class="slidev-link">${r}</a>`}),n=n.replace(/(^|[\s(])(siyuan:\/\/blocks\/([0-9a-zA-Z-]+)(?:\?[^\s\)]*)?)/g,(s,r,l,o)=>`${r}<a href="${l}" data-ref-id="${o}" class="slidev-ref-tag">🔗 ${l}</a>`),n=n.replace(/\*\*(.*?)\*\*/g,"<strong>$1</strong>"),n=n.replace(/\*(.*?)\*/g,"<em>$1</em>"),n=n.replace(/~~(.*?)~~/g,"<del>$1</del>"),n=n.replace(/`([^`]+)`/g,"<code>$1</code>"),n=n.replace(/%%SAFE_HTML_(\d+)%%/g,(s,r)=>{const l=parseInt(r,10);return i[l]||""}),n}function Gp(t,i="pdf-table"){if(t.length<2)return"";const e=t.map(a=>a.trim().replace(/^\|/,"").replace(/\|$/,"").split("|").map(c=>c.trim())),n=e[0];let s=[],r=1;t.length>=2&&e[1].every(a=>/^:?-+:?$/.test(a))&&(s=e[1].map(a=>a.startsWith(":")&&a.endsWith(":")?"center":a.endsWith(":")?"right":"left"),r=2);const l=`<thead><tr>${n.map((a,c)=>`<th${s[c]?` style="text-align: ${s[c]}"`:""}>${Me(a)}</th>`).join("")}</tr></thead>`,o=e.slice(r).map(a=>`<tr>${a.map((c,d)=>`<td${s[d]?` style="text-align: ${s[d]}"`:""}>${Me(c)}</td>`).join("")}</tr>`).join("");return`<table class="${i}">${l}<tbody>${o}</tbody></table>`}function Ts(t){return String(t||"").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;")}function Zp(t,i="ts"){if(!t)return"";if(t.trim().startsWith("//"))return`<span class="token-comment">${Ts(t)}</span>`;const e=[];function n(r,l){return e.push(`<span class="${r}">${Ts(l)}</span>`),`__TOK_${e.length-1}__`}let s=t.replace(/(['"`])(.*?)\1/g,(r,l,o)=>n("token-string",`${l}${o}${l}`));return s=s.replace(/\b(import|export|from|const|let|var|function|return|default|type|interface|class|new|async|await)\b/g,r=>n("token-keyword",r)),s=s.replace(/\b(computed|ref|number|string|boolean|void|Array)\b/g,r=>n("token-type",r)),s=s.replace(/\b(\d+)\b/g,r=>n("token-number",r)),s=Ts(s),s=s.replace(/__TOK_(\d+)__/g,(r,l)=>e[parseInt(l,10)]||""),s}function Yp(t,i){if(!t)return null;const e=t.frontmatter||{};if(e.hideInToc===!0||e.hideInToc==="true")return null;let n=(e.title||"").trim(),s=e.level?parseInt(e.level,10):0;if(!n){const r=t.blocks||[];for(const l of r){const a=(l.rawMarkdown||l.content||"").trim().match(/^(#{1,6})\s+(.*)$/);if(a){s||(s=a[1].length),n=a[2].trim();break}}}return n?((!s||isNaN(s))&&(s=1),{pageIndex:t.pageIndex||i,title:n,level:s}):null}function Jp(t,i=1,e={}){const n=e.minDepth!==void 0?Number(e.minDepth):1,s=e.maxDepth!==void 0?Number(e.maxDepth):1/0,r=[];Array.isArray(t)&&t.forEach((c,d)=>{const h=Yp(c,d+1);h&&r.push(h)});const l=[];let o=null;for(const c of r){const d={...c,active:c.pageIndex===i,hasActiveChild:!1,children:[]};c.level===1||l.length===0?(l.push(d),o=d):o?(d.active&&(o.hasActiveChild=!0),o.children.push(d)):l.push(d)}function a(c,d=1){if(d>s)return[];const h=[];for(const m of c){const p=a(m.children,d+1);d>=n?h.push({...m,children:p}):h.push(...p)}return h}return a(l,1)}function Xp(t,i=1,e={}){const n=Jp(t,i,e),s=e.columns?Number(e.columns):1,r=s>1?` style="column-count: ${s};"`:"",l=e.textSm?" text-sm":"";function o(c,d=1){if(!c||c.length===0)return"";const h=`slidev-toc-list slidev-toc-list-level-${d}`,m=c.map(p=>{const y=p.active?" slidev-toc-item-active":p.hasActiveChild?" slidev-toc-item-parent-active":"",f=p.children&&p.children.length>0?o(p.children,d+1):"";let k=Me(p.title);return k.includes("LaTeX")&&(k=k.replace(/\$\\LaTeX\$/g,'<span class="font-math">L<sup>A</sup>T<sub>E</sub>X</span>')),`
        <li class="slidev-toc-item${y}" data-page="${p.pageIndex}">
          <a class="slidev-toc-link" href="javascript:void(0)">
            <span class="slidev-toc-title">${k}</span>
          </a>
          ${f}
        </li>
      `}).join("");return`<ol class="${h}">${m}</ol>`}const a=o(n,1);return`<div class="slidev-toc${l}"${r}>${a}</div>`}function Qp(t,i,e){var p,y,f,k;const n=t.split(`
`);if(!n.some(v=>/^(\s*)([-*+]|\d+\.)\s+/.test(v)))return null;const r=[],l=[];let o=!1;for(let v=0;v<n.length;v++){const w=n[v];if(!w.trim())continue;const x=w.match(/^(\s*)[-*+]\s+\[([ xX])\]\s+(.*)$/);if(x){l.push({type:"task",checked:x[2].toLowerCase()==="x",text:x[3],media:[]});continue}const E=w.match(/^(\s*)[-*+]\s+(.*)$/);if(E){l.push({type:"unordered",text:E[2],media:[]});continue}const _=w.match(/^(\s*)\d+\.\s+(.*)$/);if(_){l.length===0&&(o=!0),l.push({type:"ordered",text:_[2],media:[]});continue}const C=w.trim();if(l.length>0){const A=C.match(/^!\[(.*?)\]\((.*?)\)$/);if(A){const R=/\.gif(?:\?|$)/i.test(A[2])?"list-item-gif":"list-item-img";l[l.length-1].media||(l[l.length-1].media=[]),l[l.length-1].media.push(`<div class="slide-list-media"><img alt="${fe(A[1])}" src="${A[2]}" class="${R}" /></div>`);continue}if(C.match(/^<img\b[\s\S]*?\/?>$/i)){l[l.length-1].media||(l[l.length-1].media=[]),l[l.length-1].media.push(`<div class="slide-list-media">${C}</div>`);continue}if(/<video\b/i.test(C)){let P=C;if(!/<\/video>/i.test(P))for(;v+1<n.length&&!/<\/video>/i.test(P);)v++,P+=" "+n[v].trim();const R=((p=e==null?void 0:e.attributes)==null?void 0:p["custom-slidev-autoplay"])==="true"||/autoplay/i.test(P),X=((y=e==null?void 0:e.attributes)==null?void 0:y["custom-slidev-loop"])==="true"||/loop/i.test(P),S=((f=e==null?void 0:e.attributes)==null?void 0:f["custom-slidev-muted"])==="true"||R||/muted/i.test(P),G=((k=e==null?void 0:e.attributes)==null?void 0:k["custom-slidev-controls"])==="false",b=P.match(/\bsrc=["']([^"']+)["']/i),U=b?b[1]:"",it=['class="slide-video-player"'];G||it.push("controls"),R&&(it.push("autoplay"),it.push("playsinline")),X&&it.push("loop"),S&&it.push("muted"),it.push('preload="metadata"'),U&&it.push(`src="${U}"`);const j=P.match(/<video[^>]*>([\s\S]*?)<\/video>/i);let st=j?j[1].trim():"";!st&&U&&(st=`<source src="${U}" type="video/mp4" />您的浏览器不支持视频播放。`),l[l.length-1].media||(l[l.length-1].media=[]),l[l.length-1].media.push(`<div class="slide-list-media slide-video-container slide-media-container" data-autoplay="${R?"true":"false"}" data-muted="${S?"true":"false"}"><video ${it.join(" ")}>${st}</video></div>`);continue}l[l.length-1].text+=`
`+C}else r.push(C)}if(l.length===0)return null;function a(v){if(!v)return"";const w=v.split(`
`).map(A=>A.trim()).filter(Boolean);if(w.length===0)return"";if(!w.some(A=>/^#{1,6}\s+/.test(A)))return Me(w.join(" "));const E=[];let _=[];const C=()=>{if(_.length>0){const A=_.join(" ");E.push(`<p class="slide-list-item-desc">${Me(A)}</p>`),_=[]}};for(const A of w){const B=A.match(/^(#{1,6})\s+(.*)$/);if(B){C();const P=B[1].length,R=B[2].trim();E.push(`<h${P} class="slide-list-item-title">${Me(R)}</h${P}>`)}else _.push(A)}return C(),E.join(`
`)}const c=o?"ol":"ul",d=o?"pdf-list pdf-list--ordered":"pdf-list pdf-list--unordered",h=l.map(v=>{const w=a(v.text),x=v.media&&v.media.length>0?`
${v.media.join(`
`)}`:"";return v.type==="task"?`<li class="pdf-task-item"><label><input type="checkbox" disabled=""${v.checked?' checked=""':""}/> <span>${w}</span></label>${x}</li>`:`<li>${w}${x}</li>`}).join(`
`);return`${r.length>0?`<p>${Me(r.join(" "))}</p>
`:""}<${c} class="${d}">
${h}
</${c}>`}function xe(t,i){var m,p,y,f,k,v,w,x;let e="",n="";if((m=t.motion)!=null&&m.preset&&t.motion.preset!=="none"){e=` slidev-motion-${t.motion.preset.toLowerCase()}`;const E=[];typeof t.motion.duration=="number"&&t.motion.duration>0&&E.push(`--motion-duration:${t.motion.duration}ms`),typeof t.motion.delay=="number"&&t.motion.delay>0&&E.push(`--motion-delay:${t.motion.delay}ms`),E.length>0&&(n=` style="${E.join(";")}"`)}const r=`pdf-block${e}`,l=(t.rawMarkdown||t.content||"").trim();if(!l)return`<div class="${r}"${n}></div>`;if(l.includes('class="slidev-block-ref"')||l.includes('class="slidev-ref-tag"'))return`<div class="${r}"${n}>${l}</div>`;if(l.startsWith("$$")&&l.endsWith("$$")){const E=l.slice(2,-2).trim();return`<div class="${r} katex-display-container"${n}><div class="katex-display font-math"><em>${fe(E)}</em></div></div>`}const o=l.match(/^(#{1,6})\s+(.*)$/);if(o){const E=o[1].length,_=Me(o[2]);return`<div class="${r}"${n}><h${E}>${_}</h${E}></div>`}if(l.startsWith(":::")){const E=l.split(`
`),C=E[0].replace(/^:::\s*/,"").trim()||"info",A=E.slice(1,E[E.length-1].startsWith(":::")?-1:void 0).join(`
`),B="pdf-callout";return`<div class="${r}"${n}><div class="${B} ${B}--${C}"><div class="${B}-title">${C.toUpperCase()}</div><div class="${B}-body">${Me(A)}</div></div></div>`}if(l.startsWith("<<<")){const C=`// Inside ./snippets/external.ts
export function emptyArray<T>(length: number) {
  return Array.from<T>({ length })
}`.split(`
`).map((R,X)=>`<span class="code-line shiki-focus"><span class="line-no">${X+1}</span><span class="line-content">${Zp(R,"ts")}</span></span>`).join(`
`),A="pdf-code shiki-container",B=((p=t.attrs)==null?void 0:p["custom-slidev-max-height"])||t.maxHeight||"",P=B?` style="max-height:${fe(B)};overflow-y:auto;"`:"";return`<div class="${r}"${n}><pre class="${A}"${P}><span class="lang-badge">TS</span><code>${C}</code></pre></div>`}if(l.startsWith("<style")||l.startsWith("<!-- Inline style -->")||l.startsWith(`<!--
Notes`))return"";if(l.startsWith("```")){const E=l.split(`
`),_=E[0].slice(3).trim(),C=_.match(/^([^\s{\[]+)/),A=C?C[1]:"",B=_.match(/\[([^\]]+)\]/),P=B?B[1]:"",R=_.includes("twoslash"),X=t.shikiLines||((y=_.match(/\{([^}]+)\}/))==null?void 0:y[1])||"",S=Kp(X),G=E.length>2?E[E.length-1]==="```"?E.slice(1,-1):E.slice(1):[l.slice(3).replace(/```$/,"")],b="pdf-code shiki-container",U=P?`${b} has-filename`:b,it=S!=="all",j=G.map((L,ct)=>{const rt=ct+1,J=S==="all"||S.has(rt)?"code-line shiki-focus":it?"code-line shiki-dimmed":"code-line";let mt=fe(L);return R&&L.includes("doubled.value = 2")?(mt=mt.replace(/(\bvalue\b)/,'<span class="twoslash-error-wavy">$1</span>'),`<span class="${J}"><span class="line-no">${rt}</span><span class="line-content">${mt}</span></span>
<div class="twoslash-popup-error"><span style="color:#ef4444;font-weight:bold;margin-right:4px;">✕</span> Cannot assign to 'value' because it is a read-only property.</div>`):`<span class="${J}"><span class="line-no">${rt}</span><span class="line-content">${mt}</span></span>`}).join(`
`),st=A?`<span class="lang-badge">${fe(A)}</span>`:"",K=P?`<span class="code-filename">${fe(P)}</span>`:"",Y=((f=t.attrs)==null?void 0:f["custom-slidev-max-height"])||t.maxHeight||"",H=Y?` style="max-height:${fe(Y)};overflow-y:auto;"`:"";return`<div class="${r}"${n}><pre class="${U}"${H}>${K}${st}<code>${j}</code></pre></div>`}if(l.includes("|")&&l.split(`
`).filter(E=>E.trim().startsWith("|")).length>=2){const E=l.split(`
`).filter(C=>C.trim().startsWith("|")),_=Gp(E,i==null?void 0:i.tableClassName);return`<div class="${r}"${n}>${_}</div>`}if(l.startsWith("> "))return`<div class="${r}"${n}><blockquote class="pdf-quote"><p>${Me(l.slice(2))}</p></blockquote></div>`;const a=/<video\b/i.test(l)||t.type==="video"||t.type==="NodeVideo",c=/^(\s*)([-*+]|\d+\.)\s+/m.test(l);if(a&&!c){const E=((k=t.attributes)==null?void 0:k["custom-slidev-autoplay"])==="true"||/autoplay/i.test(l),_=((v=t.attributes)==null?void 0:v["custom-slidev-loop"])==="true"||/loop/i.test(l),C=((w=t.attributes)==null?void 0:w["custom-slidev-muted"])==="true"||E||/muted/i.test(l),A=((x=t.attributes)==null?void 0:x["custom-slidev-controls"])==="false",B=l.match(/\bsrc=["']([^"']+)["']/i),P=B?B[1]:"",R=['class="slide-video-player"'];A||R.push("controls"),E&&(R.push("autoplay"),R.push("playsinline")),_&&R.push("loop"),C&&R.push("muted"),R.push('preload="metadata"'),P&&R.push(`src="${P}"`);const X=l.match(/<video[^>]*>([\s\S]*?)<\/video>/i);let S=X?X[1].trim():"";return!S&&P&&(S=`<source src="${P}" type="video/mp4" />您的浏览器不支持视频播放。`),`<div class="${r} ${r}--video slide-media-block slide-video-container slide-media-container" data-autoplay="${E?"true":"false"}" data-muted="${C?"true":"false"}"${n}><video ${R.join(" ")}>${S}</video></div>`}const d=l.match(/^!\[(.*?)\]\((.*?)\)$/);if(d)return`<div class="${r} ${r}--image slide-media-block slide-media-container"${n}><img alt="${fe(d[1])}" src="${d[2]}" class="pdf-image slide-media-img" /></div>`;const h=Qp(l,i,t);if(h)return`<div class="${r} pdf-list-item"${n}>${h}</div>`;if(/<(?:Toc|toc)\b/i.test(l)&&!l.startsWith("```")){const E=l.match(/minDepth=["']?(\d+)["']?/i),_=l.match(/maxDepth=["']?(\d+)["']?/i),C=l.match(/columns=["']?(\d+)["']?/i);return`<div class="${r}"${n}>${Xp([],1,{minDepth:E?parseInt(E[1],10):1,maxDepth:_?parseInt(_[1],10):1/0,columns:C?parseInt(C[1],10):1,textSm:l.includes("text-sm")})}</div>`}return`<div class="${r}"${n}><p>${Me(l)}</p></div>`}function th(t,i){var r,l,o,a;const e=((r=t.frontmatter)==null?void 0:r.layout)||"default",s=(t.blocks||[]).filter(c=>c.slot!=="slot-divider-right");if(e==="two-cols"){const c=s.some(w=>w.slot==="right");let d=[],h=[];if(c)d=s.filter(w=>w.slot!=="right"),h=s.filter(w=>w.slot==="right");else{const w=Math.ceil(s.length/2);d=s.slice(0,w),h=s.slice(w)}const m=d.map(w=>xe(w,i)).join(`
`),p=h.map(w=>xe(w,i)).join(`
`),y="pdf-two-cols-wrapper layout-two-cols-grid",f=(l=t.frontmatter)!=null&&l.layoutClass?` ${t.frontmatter.layoutClass}`:"";return`
      <div class="${y}${f}">
        <div class="pdf-col pdf-col--left">${m}</div>
        <div class="pdf-col pdf-col--right">${p}</div>
      </div>
    `}if(e==="two-cols-header"){let c=[];const d=s.filter(w=>w.slot==="header");if(d.length>0)c=d;else if(s.length>0){const w=s.find(x=>x.type==="h"&&(!x.slot||x.slot==="default"));w&&(c=[w])}const h=s.filter(w=>!c.includes(w)),m=h.filter(w=>w.slot==="right"||w.slot==="col-2"),p=h.filter(w=>!m.includes(w)),y=w=>{if(w.length===1&&Ki(w[0])){const x=zs(w[0].rawMarkdown);return xe({...w[0],rawMarkdown:x},i)}return w.map(x=>xe(x,i)).join(`
`)},f=c.map(w=>xe(w,i)).join(`
`),k=y(p),v=y(m);return`
      <div class="layout-two-cols-header-container">
        <div class="layout-header-section">${f}</div>
        <div class="pdf-two-cols-wrapper layout-two-cols-grid">
          <div class="pdf-col pdf-col--left">${k}</div>
          <div class="pdf-col pdf-col--right">${v}</div>
        </div>
      </div>
    `}if(e==="three-cols-header"){let c=[];const d=s.filter(E=>E.slot==="header");if(d.length>0)c=d;else if(s.length>0){const E=s.find(_=>_.type==="h"&&(!_.slot||_.slot==="default"));E&&(c=[E])}const h=s.filter(E=>!c.includes(E)),{col1:m,col2:p,col3:y}=Tr(h),f=E=>{if(E.length===1&&Ki(E[0])){const _=zs(E[0].rawMarkdown);return xe({...E[0],rawMarkdown:_},i)}return E.map(_=>xe(_,i)).join(`
`)},k=c.map(E=>xe(E,i)).join(`
`),v=f(m),w=f(p),x=f(y);return`
      <div class="layout-three-cols-header-container">
        <div class="layout-header-section">${k}</div>
        <div class="pdf-three-cols-wrapper layout-three-cols-grid">
          <div class="pdf-col pdf-col--1">${v}</div>
          <div class="pdf-col pdf-col--2">${w}</div>
          <div class="pdf-col pdf-col--3">${x}</div>
        </div>
      </div>
    `}if(e==="image-right"||e==="image-left"){const c=e==="image-right",d=s.map(f=>xe(f,i)).join(`
`),h=((o=t.frontmatter)==null?void 0:o.image)||((a=t.frontmatter)==null?void 0:a.background)||"",m=`<div class="pdf-image-col" style="background-image:url('${fe(h)}');background-size:cover;background-position:center;background-repeat:no-repeat;width:100%;height:100%;position:relative;overflow:hidden;"><img src="${fe(h)}" style="width:100%;height:100%;object-fit:cover;object-position:center;display:block;" onerror="this.style.display='none'" alt="Slide cover" /></div>`,p=`<div class="pdf-content-col" style="padding:48px 56px;display:flex;flex-direction:column;justify-content:flex-start;height:100%;box-sizing:border-box;overflow-y:auto;">${d}</div>`;return`
      <div class="layout-image-cols-grid" style="display:grid;grid-template-columns:1fr 1fr;grid-template-rows:100%;width:100%;height:100%;position:absolute;top:0;left:0;right:0;bottom:0;box-sizing:border-box;">
        ${c?`${p}
${m}`:`${m}
${p}`}
      </div>
    `}return e==="fact"?`<div class="layout-fact-container">${s.map(d=>xe(d,i)).join(`
`)}</div>`:e==="cover"?`<div class="layout-cover-container">${s.map(d=>xe(d,i)).join(`
`)}</div>`:s.map(c=>xe(c,i)).join(`
`)}function Kl(t,i){const e="Slidev 演示文稿";let n=t.slides;const s=JSON.stringify(n),r=JSON.stringify(t.config);return`<!DOCTYPE html>
<html lang="zh-CN">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${fe(e)}</title>
  <style>
    :root {
      --slide-bg: #ffffff;
      --slide-text: #1a1a1a;
      --slide-accent: #3b82f6;
      --slide-font: system-ui, -apple-system, sans-serif;
    }
    [data-theme="dark"] {
      --slide-bg: #121214;
      --slide-text: #e2e8f0;
      --slide-accent: #60a5fa;
    }

    /* 1. 默认科技主题 Default */
    [data-slidev-theme="default"],
    .slidev-theme-default {
      --slide-font: system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "PingFang SC", "Microsoft YaHei", sans-serif;
      --slide-accent: #10b981;
    }
    [data-theme="light"][data-slidev-theme="default"],
    [data-theme="light"] .slidev-theme-default {
      --slide-bg: #ffffff;
      --slide-text: #1e293b;
      --slide-accent: #059669;
    }
    [data-theme="dark"][data-slidev-theme="default"],
    [data-theme="dark"] .slidev-theme-default {
      --slide-bg: #121214;
      --slide-text: #e2e8f0;
      --slide-accent: #34d399;
    }
    .slidev-theme-default .layout-cover h1,
    .slidev-theme-default .layout-cover .slide-block h1 {
      font-size: 3.8rem !important;
      font-weight: 800 !important;
      line-height: 1.15 !important;
      letter-spacing: -0.025em !important;
      margin-bottom: 18px !important;
      background: linear-gradient(135deg, #10b981, #06b6d4) !important;
      -webkit-background-clip: text !important;
      -webkit-text-fill-color: transparent !important;
    }
    .slidev-theme-default .layout-cover h2,
    .slidev-theme-default .layout-cover .slide-block h2 {
      font-size: 1.85rem !important;
      font-weight: 600 !important;
      opacity: 0.85 !important;
      margin-bottom: 12px !important;
    }
    .slidev-theme-default .layout-cover p,
    .slidev-theme-default .layout-cover .slide-block p {
      font-size: 1.45rem !important;
      line-height: 1.5 !important;
      opacity: 0.85 !important;
    }

    /* 2. 优雅衬线主题 Seriph */
    [data-slidev-theme="seriph"],
    .slidev-theme-seriph {
      --slide-font: "PT Serif", "Charter", "Georgia", "Cambria", "Times New Roman", "Source Han Serif SC", "Noto Serif SC", "Songti SC", "SimSun", serif;
      --slide-accent: #b45309;
      letter-spacing: 0.015em;
    }
    [data-theme="light"][data-slidev-theme="seriph"],
    [data-theme="light"] .slidev-theme-seriph {
      --slide-bg: #fdfbf7;
      --slide-text: #2a2521;
      --slide-accent: #b45309;
    }
    [data-theme="dark"][data-slidev-theme="seriph"],
    [data-theme="dark"] .slidev-theme-seriph {
      --slide-bg: #1c1a17;
      --slide-text: #e8e3d9;
      --slide-accent: #f59e0b;
    }
    .slidev-theme-seriph,
    .slidev-theme-seriph .slide-content {
      font-family: var(--slide-font) !important;
      line-height: 1.72;
    }
    .slidev-theme-seriph h1,
    .slidev-theme-seriph h2,
    .slidev-theme-seriph h3 {
      font-family: var(--slide-font) !important;
      letter-spacing: 0.025em;
      font-weight: 700;
    }
    .slidev-theme-seriph .layout-cover h1 {
      background: none !important;
      -webkit-background-clip: initial !important;
      -webkit-text-fill-color: initial !important;
      color: var(--slide-accent) !important;
      font-size: 3.4rem !important;
      border-bottom: 2px solid var(--slide-accent);
      display: inline-block;
      padding-bottom: 10px;
    }

    /* 3. 极简发布会主题 Apple Basic */
    [data-slidev-theme="apple-basic"],
    .slidev-theme-apple-basic {
      --slide-font: -apple-system, "SF Pro Display", "SF Pro Text", BlinkMacSystemFont, "PingFang SC", "Helvetica Neue", sans-serif;
      --slide-accent: #0071e3;
    }
    [data-theme="light"][data-slidev-theme="apple-basic"],
    [data-theme="light"] .slidev-theme-apple-basic {
      --slide-bg: #ffffff;
      --slide-text: #1d1d1f;
      --slide-accent: #0071e3;
    }
    [data-theme="dark"][data-slidev-theme="apple-basic"],
    [data-theme="dark"] .slidev-theme-apple-basic {
      --slide-bg: #000000;
      --slide-text: #f5f5f7;
      --slide-accent: #2997ff;
    }
    .slidev-theme-apple-basic,
    .slidev-theme-apple-basic .slide-content {
      font-family: var(--slide-font) !important;
    }
    .slidev-theme-apple-basic h1,
    .slidev-theme-apple-basic h2,
    .slidev-theme-apple-basic h3 {
      letter-spacing: -0.035em;
      font-weight: 800;
    }
    .slidev-theme-apple-basic .layout-cover h1 {
      background: none !important;
      -webkit-background-clip: initial !important;
      -webkit-text-fill-color: initial !important;
      color: var(--slide-text) !important;
      font-size: 3.8rem !important;
      letter-spacing: -0.04em !important;
    }
    .slidev-theme-apple-basic .layout-cover p {
      color: #86868b !important;
      font-size: 1.35rem !important;
    }

    * { box-sizing: border-box; margin: 0; padding: 0; }
    html, body {
      width: 100%; height: 100%; overflow: hidden;
      background: #0f1115; font-family: var(--slide-font);
      display: flex; justify-content: center; align-items: center;
    }
    #app { width: 100%; height: 100%; position: relative; overflow: hidden; }
    .slide-viewport {
      position: absolute; left: 50%; top: 50%;
      background: var(--slide-bg); color: var(--slide-text);
      box-shadow: 0 10px 30px rgba(0,0,0,0.5); border-radius: 8px; overflow: hidden;
      display: flex; flex-direction: column; flex-shrink: 0;
      transform: translate(-50%, -50%) scale(var(--slidev-slide-scale, 1));
      transform-origin: center center; will-change: transform;
      transition: background 0.3s ease, color 0.3s ease, border-radius 0.2s ease, box-shadow 0.2s ease;
    }
    :fullscreen .slide-viewport, .is-fullscreen .slide-viewport {
      border-radius: 0 !important; box-shadow: none !important;
    }
    .layout-cover { justify-content: center; align-items: center; text-align: center; }
    .layout-cover h1, .layout-cover .slide-block h1 { font-size: 3.8rem !important; font-weight: 800 !important; line-height: 1.15 !important; letter-spacing: -0.025em !important; margin-bottom: 16px !important; }
    .layout-cover h2, .layout-cover .slide-block h2 { font-size: 1.85rem !important; font-weight: 600 !important; opacity: 0.85 !important; margin-bottom: 12px !important; }
    .layout-cover p, .layout-cover .slide-block p { font-size: 1.45rem !important; line-height: 1.5 !important; opacity: 0.85 !important; }
    .two-cols-left, .two-cols-right { min-width: 0; width: 100%; display: flex; flex-direction: column; box-sizing: border-box; overflow-wrap: break-word; word-break: break-word; }
    .pdf-two-cols-wrapper,
    .layout-two-cols-grid {
      display: grid;
      grid-template-columns: minmax(0, 1fr) minmax(0, 1fr);
      gap: 32px;
      width: 100%;
      height: 100%;
      flex: 1 1 0%;
      align-items: stretch;
    }
    .layout-two-cols-header-container,
    .layout-three-cols-header-container {
      display: flex;
      flex-direction: column;
      width: 100%;
      height: 100%;
    }
    .layout-header-section {
      width: 100%;
      margin-bottom: 24px;
      flex-shrink: 0;
    }
    .pdf-three-cols-wrapper,
    .layout-three-cols-grid {
      display: grid;
      grid-template-columns: minmax(0, 1fr) minmax(0, 1fr) minmax(0, 1fr);
      gap: 24px;
      width: 100%;
      height: 100%;
      flex: 1 1 0%;
      align-items: stretch;
      box-sizing: border-box;
    }
    .pdf-col {
      display: flex;
      flex-direction: column;
      gap: 14px;
      min-width: 0;
      width: 100%;
      max-width: 100%;
      height: 100%;
      max-height: 100%;
      min-height: 0;
      justify-content: flex-start;
      box-sizing: border-box;
      overflow: hidden;
      overflow-wrap: break-word;
      word-break: break-word;
      white-space: normal;
    }
    .pdf-col * {
      overflow-wrap: break-word;
      word-break: break-word;
      box-sizing: border-box;
    }
    .pdf-col pre,
    .two-cols-left pre,
    .two-cols-right pre,
    .image-right-content pre,
    .image-left-content pre {
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      overflow-x: hidden !important;
      overflow-y: auto !important;
      max-width: 100% !important;
      box-sizing: border-box !important;
    }
    .slide-content.layout-image-right, .slide-content.layout-image-left {
      padding: 0;
      display: grid;
      grid-template-columns: minmax(0, 1fr) minmax(0, 1fr);
      grid-template-rows: 100%;
      width: 100%;
      height: 100%;
      position: absolute;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      box-sizing: border-box;
    }
    .image-right-content, .image-left-content {
      padding: 44px 50px;
      display: flex;
      flex-direction: column;
      justify-content: flex-start;
      overflow-y: auto;
      width: 100%;
      height: 100%;
      box-sizing: border-box;
    }
    .image-right-img-container, .image-left-img-container {
      width: 100%;
      height: 100%;
      overflow: hidden;
      position: relative;
      background: #18181b;
      display: flex;
      align-items: center;
      justify-content: center;
    }
    .image-right-img, .image-left-img {
      width: 100%;
      height: 100%;
      object-fit: cover;
      object-position: center;
      display: block;
    }
    .slide-block { margin-bottom: 14px; line-height: 1.6; }
    .slide-block h1 { font-size: 2.2rem; margin-bottom: 12px; }
    .slide-block h2 { font-size: 1.7rem; margin-bottom: 10px; }
    .slide-block p { font-size: 1.15rem; }
    .slide-block ul, .slide-block ol, .pdf-list {
      padding-left: 28px;
      margin: 8px 0;
      display: flex;
      flex-direction: column;
      gap: 6px;
    }
    .slide-block li, .pdf-list li {
      font-size: 1.15rem;
      line-height: 1.6;
    }
    .pdf-task-item {
      list-style: none;
      margin-left: -20px;
      display: flex;
      align-items: center;
      gap: 8px;
    }
    .pdf-task-item input[type="checkbox"] {
      width: 1.15em;
      height: 1.15em;
      cursor: pointer;
    }

    /* 两栏与三栏（超级块分栏）布局：去除列表圆点标记与缩进 */
    .layout-two-cols ul,
    .layout-two-cols ol,
    .layout-two-cols-header ul,
    .layout-two-cols-header ol,
    .layout-three-cols ul,
    .layout-three-cols ol,
    .layout-three-cols-header ul,
    .layout-three-cols-header ol,
    .two-cols-left ul,
    .two-cols-left ol,
    .two-cols-right ul,
    .two-cols-right ol,
    .three-cols-col ul,
    .three-cols-col ol,
    .pdf-col ul,
    .pdf-col ol,
    .pdf-col .pdf-list,
    .layout-two-cols-grid .pdf-list,
    .layout-three-cols-grid .pdf-list {
      list-style: none !important;
      list-style-type: none !important;
      padding-left: 0 !important;
      margin-left: 0 !important;
    }

    .layout-two-cols li,
    .layout-two-cols-header li,
    .layout-three-cols li,
    .layout-three-cols-header li,
    .two-cols-left li,
    .two-cols-right li,
    .three-cols-col li,
    .pdf-col li,
    .pdf-col .pdf-list-item {
      list-style: none !important;
      list-style-type: none !important;
      padding-left: 0 !important;
      margin-left: 0 !important;
    }

    .layout-two-cols li::marker,
    .layout-two-cols-header li::marker,
    .layout-three-cols li::marker,
    .layout-three-cols-header li::marker,
    .two-cols-left li::marker,
    .two-cols-right li::marker,
    .pdf-col li::marker {
      content: none !important;
    }

    /* 列表项内嵌标题与说明排版 */
    .slide-list-item-title,
    .pdf-list li > h1,
    .pdf-list li > h2,
    .pdf-list li > h3,
    .pdf-list li > h4,
    .pdf-list li > h5,
    .pdf-list li > h6,
    li > h1.slide-list-item-title,
    li > h2.slide-list-item-title,
    li > h3.slide-list-item-title,
    li > h4.slide-list-item-title {
      margin-top: 2px !important;
      margin-bottom: 6px !important;
      line-height: 1.35 !important;
      font-weight: 700 !important;
    }
    .pdf-list li > h1, li > h1.slide-list-item-title { font-size: 1.6rem !important; }
    .pdf-list li > h2, li > h2.slide-list-item-title { font-size: 1.4rem !important; }
    .pdf-list li > h3, li > h3.slide-list-item-title { font-size: 1.22rem !important; }
    .pdf-list li > h4, li > h4.slide-list-item-title { font-size: 1.1rem !important; }
    .slide-list-item-desc,
    .pdf-list li > p {
      margin-top: 4px !important;
      margin-bottom: 6px !important;
      font-size: 1.05rem;
      line-height: 1.55;
      opacity: 0.92;
    }

    /* 多媒体（GIF动图、静态图片、MP4视频）全视口最大化自适应且不超出视口 */
    .slide-media-block,
    .slide-media-container,
    .slide-video-container,
    .slide-block--media,
    .slide-block--image,
    .slide-block--video,
    .slide-block:has(> img),
    .slide-block:has(> .slide-media-container),
    .slide-block:has(> p > img:only-child),
    .slide-block:has(> .slide-video-container),
    .slide-block:has(> video) {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      min-width: 0 !important;
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
      justify-content: center !important;
      width: 100% !important;
      height: 100% !important;
      max-height: 100% !important;
      overflow: hidden !important;
      margin: 4px 0 !important;
      box-sizing: border-box !important;
    }

    .slide-block img,
    .slide-media-img,
    .slide-media-container img,
    .slide-video-player,
    video.slide-video-player,
    .slide-block video {
      max-width: 100% !important;
      max-height: 100% !important;
      width: auto !important;
      height: auto !important;
      object-fit: contain !important;
      display: block !important;
      margin: auto !important;
      border-radius: 8px;
      box-shadow: 0 4px 16px rgba(0, 0, 0, 0.16);
      background: #000;
      outline: none;
    }

    .slide-list-media {
      display: flex !important;
      align-items: center !important;
      justify-content: center !important;
      width: 100% !important;
      max-width: 100% !important;
      height: 100% !important;
      max-height: 100% !important;
      flex: 1 1 0% !important;
      margin-top: 4px !important;
      margin-bottom: 4px !important;
      min-height: 0 !important;
      overflow: hidden !important;
      box-sizing: border-box !important;
    }
    .slide-list-media img,
    .slide-list-media video,
    .slide-list-media .list-item-gif,
    .slide-list-media .slide-video-player {
      max-width: 100% !important;
      max-height: 100% !important;
      width: 100% !important;
      height: 100% !important;
      min-width: 0 !important;
      min-height: 0 !important;
      object-fit: contain !important;
      border-radius: 6px !important;
      box-shadow: 0 3px 12px rgba(0, 0, 0, 0.14) !important;
      display: block !important;
      margin: auto !important;
    }

    .slide-block:has(.slide-list-media) {
      flex: 1 1 auto;
      min-height: 0;
      height: 100%;
      max-height: 100%;
      display: flex;
      flex-direction: column;
      overflow: hidden !important;
    }
    .slide-block:has(.slide-list-media) .pdf-list,
    .slide-block:has(.slide-list-media) ul,
    .slide-block:has(.slide-list-media) ol {
      flex: 1 1 auto;
      min-height: 0;
      height: 100%;
      max-height: 100%;
      overflow: hidden !important;
      overflow-y: hidden !important;
    }

    .layout-two-cols .slide-media-block,
    .layout-two-cols .slide-video-container,
    .layout-two-cols .slide-media-container,
    .layout-three-cols .slide-media-block,
    .layout-three-cols .slide-video-container,
    .layout-three-cols .slide-media-container,
    .two-cols-left img,
    .two-cols-right img,
    .two-cols-left video,
    .two-cols-right video,
    .three-cols-col video,
    .pdf-col video,
    .layout-three-cols-grid video {
      max-width: 100% !important;
      max-height: 100% !important;
      width: 100% !important;
      height: 100% !important;
      min-width: 0 !important;
      min-height: 0 !important;
      object-fit: contain !important;
      display: block !important;
      margin: auto !important;
    }

    img.slide-inline-img {
      max-width: 100% !important;
      max-height: min(320px, 40vh) !important;
      object-fit: contain !important;
      vertical-align: middle;
      border-radius: 4px;
    }
    kbd {
      display: inline-block;
      padding: 2px 7px;
      font-family: ui-monospace, SFMono-Regular, "SF Mono", Menlo, Consolas, "Liberation Mono", monospace;
      font-size: 0.85em;
      font-weight: 600;
      line-height: 1.25;
      color: inherit;
      background: rgba(125, 125, 125, 0.12);
      border: 1px solid rgba(125, 125, 125, 0.35);
      border-bottom-width: 2px;
      border-radius: 5px;
      box-shadow: 0 1px 2px rgba(0, 0, 0, 0.12);
      margin: 0 2px;
      vertical-align: middle;
      white-space: nowrap;
    }
    [data-theme="dark"] kbd, .theme-dark kbd {
      background: rgba(255, 255, 255, 0.1);
      border-color: rgba(255, 255, 255, 0.25);
      border-bottom-color: rgba(255, 255, 255, 0.4);
      color: #f1f5f9;
      box-shadow: 0 1px 2px rgba(0, 0, 0, 0.4);
    }
    .slide-block pre,
    pre {
      background: rgba(0, 0, 0, 0.1);
      padding: 12px;
      border-radius: 6px;
      font-family: "JetBrains Mono", Consolas, monospace;
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      overflow-x: hidden !important;
      overflow-y: auto !important;
      max-width: 100% !important;
      box-sizing: border-box !important;
    }
    .slide-block pre code,
    pre code {
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      display: block !important;
      width: 100% !important;
      box-sizing: border-box !important;
    }
    .code-line {
      display: flex !important;
      align-items: flex-start !important;
      width: 100% !important;
      box-sizing: border-box !important;
      line-height: 1.6;
    }
    .code-line .line-no {
      display: inline-block !important;
      flex-shrink: 0 !important;
      min-width: 2.2em !important;
      text-align: right !important;
      margin-right: 12px !important;
      user-select: none !important;
      opacity: 0.45 !important;
    }
    .code-line .line-content {
      flex: 1 1 0% !important;
      min-width: 0 !important;
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
    }
    /* 弱提示滚动条样式 */
    * {
      scrollbar-width: thin;
      scrollbar-color: rgba(255, 255, 255, 0.20) transparent;
    }
    *::-webkit-scrollbar {
      width: 4px;
      height: 4px;
    }
    *::-webkit-scrollbar-track {
      background: transparent;
    }
    *::-webkit-scrollbar-thumb {
      background: rgba(255, 255, 255, 0.20);
      border-radius: 2px;
      transition: background 0.2s ease;
    }
    *:hover::-webkit-scrollbar-thumb,
    *::-webkit-scrollbar-thumb:hover {
      background: rgba(255, 255, 255, 0.45);
    }
    /* Slidev Micro-motion Keyframes & Presets */
    @keyframes slidevMotionFadeIn { from { opacity: 0; } to { opacity: 1; } }
    @keyframes slidevMotionSlideUp { from { opacity: 0; transform: translateY(40px); } to { opacity: 1; transform: translateY(0); } }
    @keyframes slidevMotionSlideDown { from { opacity: 0; transform: translateY(-40px); } to { opacity: 1; transform: translateY(0); } }
    @keyframes slidevMotionSlideLeft { from { opacity: 0; transform: translateX(40px); } to { opacity: 1; transform: translateX(0); } }
    @keyframes slidevMotionSlideRight { from { opacity: 0; transform: translateX(-40px); } to { opacity: 1; transform: translateX(0); } }
    @keyframes slidevMotionZoomIn { from { opacity: 0; transform: scale(0.8); } to { opacity: 1; transform: scale(1); } }
    @keyframes slidevMotionBounce {
      0% { opacity: 0; transform: translateY(40px); }
      60% { opacity: 1; transform: translateY(-8px); }
      80% { transform: translateY(4px); }
      100% { transform: translateY(0); }
    }
    .slidev-motion-fade-in { animation: slidevMotionFadeIn var(--motion-duration, 0.4s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slidev-motion-slide-up { animation: slidevMotionSlideUp var(--motion-duration, 0.45s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slidev-motion-slide-down { animation: slidevMotionSlideDown var(--motion-duration, 0.45s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slidev-motion-slide-left { animation: slidevMotionSlideLeft var(--motion-duration, 0.45s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slidev-motion-slide-right { animation: slidevMotionSlideRight var(--motion-duration, 0.45s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slidev-motion-zoom-in, .slidev-motion-pop { animation: slidevMotionZoomIn var(--motion-duration, 0.4s) cubic-bezier(0.34, 1.56, 0.64, 1) var(--motion-delay, 0s) both; }
    .slidev-motion-bounce { animation: slidevMotionBounce var(--motion-duration, 0.6s) cubic-bezier(0.34, 1.56, 0.64, 1) var(--motion-delay, 0s) both; }
    .controls {
      position: absolute; bottom: 16px; display: flex; gap: 12px; align-items: center;
      background: rgba(24, 24, 27, 0.8); backdrop-filter: blur(8px);
      padding: 6px 18px; border-radius: 20px; color: #fff; font-size: 13px; z-index: 10;
    }
    .controls button { background: transparent; border: none; color: inherit; cursor: pointer; padding: 2px 6px; }

    /* Slidev Native Icons & Interactive Buttons */
    .slidev-icon-btn {
      display: inline-flex !important; flex-direction: row !important; align-items: center !important; justify-content: center !important;
      padding: 0.35rem 0.5rem; border-radius: 0.375rem; background: transparent;
      border: 1px solid transparent; color: inherit; font-size: inherit; line-height: 1;
      cursor: pointer; opacity: 0.8; transition: all 0.2s ease; text-decoration: none;
      vertical-align: middle; user-select: none; margin: 0 4px;
    }
    .slidev-icon-btn:hover { opacity: 1; background: rgba(255, 255, 255, 0.12); border-color: rgba(255, 255, 255, 0.15); }

    /* 组件从上到下按顺序流式渲染，避免相互重叠 */
    .slide-block > div + div { margin-top: 14px; }

    /* 同一个 div 内的按钮/链接从左到右水平渲染 */
    .slide-block div:has(> .slidev-icon-btn),
    .slide-block div:has(> button),
    .slide-block [class*="abs-"],
    .slidev-btn-row {
      display: inline-flex !important;
      flex-direction: row !important;
      align-items: center !important;
      justify-content: center !important;
      flex-wrap: wrap !important;
      gap: 8px !important;
    }

    /* Position Shortcuts 适配：在组件流中保持从上到下排列，不脱离流产生重叠 */
    .slide-block .abs-br,
    .slide-block .abs-bl,
    .slide-block .abs-tr,
    .slide-block .abs-tl,
    .slide-block [class*="abs-"] {
      position: relative !important;
      bottom: auto !important;
      right: auto !important;
      top: auto !important;
      left: auto !important;
      margin: 0.75rem auto !important;
    }

    .slide-block--absolute { position: relative !important; margin-bottom: 14px !important; padding: 0 !important; background: transparent !important; }
    .slide-block--absolute:hover { background: transparent !important; }
    .mt-12 { margin-top: 3rem !important; }
    .py-1 { padding-top: 0.25rem !important; padding-bottom: 0.25rem !important; }
    .m-6 { margin: 1.5rem !important; }
    .text-xl { font-size: 1.25rem !important; }
    [hover\\:bg~="white"][hover\\:bg~="op-10"]:hover,
    [hover\\:bg="white op-10"]:hover { background: rgba(255, 255, 255, 0.1) !important; border-radius: 4px; }
    .cursor-pointer, [data-clickable] { cursor: pointer; }
    /* Slidev 规范链接排版 (继承正文颜色，虚线底边，Hover 时平滑点亮为主题色并转为实线) */
    .slide-content a:not(.slidev-ref-tag):not(.slidev-icon-btn):not(.slidev-toc-link),
    .slide-block a:not(.slidev-ref-tag):not(.slidev-icon-btn):not(.slidev-toc-link),
    a.slidev-link {
      color: inherit;
      text-decoration: none;
      border-bottom: 1px dashed currentColor;
      transition: color 0.2s cubic-bezier(0.4, 0, 0.2, 1),
                  border-color 0.2s cubic-bezier(0.4, 0, 0.2, 1),
                  border-bottom-style 0.2s cubic-bezier(0.4, 0, 0.2, 1);
      cursor: pointer;
    }
    .slide-content a:not(.slidev-ref-tag):not(.slidev-icon-btn):not(.slidev-toc-link):hover,
    .slide-block a:not(.slidev-ref-tag):not(.slidev-icon-btn):not(.slidev-toc-link):hover,
    a.slidev-link:hover {
      color: var(--slide-accent);
      border-bottom-style: solid;
      border-bottom-color: var(--slide-accent);
    }
    .slidev-ref-tag, a.slidev-ref-tag {
      display: inline-flex;
      align-items: center;
      background: color-mix(in srgb, var(--slide-accent) 12%, transparent);
      color: var(--slide-accent);
      border-radius: 4px;
      padding: 2px 8px;
      font-size: 0.88em;
      text-decoration: none;
      cursor: pointer;
      margin: 2px 4px 2px 0;
      border: 1px solid color-mix(in srgb, var(--slide-accent) 25%, transparent);
      transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
    }
    .slidev-ref-tag:hover, a.slidev-ref-tag:hover {
      background: color-mix(in srgb, var(--slide-accent) 22%, transparent);
      color: var(--slide-accent);
      border-color: color-mix(in srgb, var(--slide-accent) 55%, transparent);
      transform: translateY(-1px);
      box-shadow: 0 2px 8px color-mix(in srgb, var(--slide-accent) 20%, transparent);
    }
    .slidev-block-ref {
      display: block;
      padding: 10px 14px;
      background: color-mix(in srgb, var(--slide-accent) 8%, transparent);
      border-left: 3px solid var(--slide-accent);
      border-radius: 0 6px 6px 0;
      margin: 8px 0;
      cursor: pointer;
      transition: background 0.2s ease;
    }
    .slidev-block-ref:hover {
      background: color-mix(in srgb, var(--slide-accent) 15%, transparent);
    }
  </style>
  <script>
    // 注入演示数据载荷
    window.__SLIDEV_DATA__ = {
      docId: ${JSON.stringify(t.docId)},
      slides: ${s},
      config: ${r}
    };
  <\/script>
</head>
<body>
  <div id="app">
    <div class="slide-viewport slidev-theme-${t.config.theme||"default"}" id="viewport" data-slidev-theme="${t.config.theme||"default"}">
      <div class="slide-content" id="slide-container"></div>
    </div>
    <div class="controls">
      <button id="btn-prev">◀ 上一页</button>
      <span id="page-num">1 / 1</span>
      <button id="btn-next">下一页 ▶</button>
      <button id="btn-fullscreen">⛶ 全屏</button>
    </div>
  </div>

  <script>
    (function() {
      const data = window.__SLIDEV_DATA__ || { slides: [] };
      const slides = data.slides || [];
      let currentIndex = 0;

      const container = document.getElementById("slide-container");
      const pageNum = document.getElementById("page-num");
      const btnPrev = document.getElementById("btn-prev");
      const btnNext = document.getElementById("btn-next");
      const btnFullscreen = document.getElementById("btn-fullscreen");

      const baseWidth = 980;
      const aspectStr = (data.config && data.config.aspectRatio) || "16/9";
      let ratioNum = 16 / 9;
      if (aspectStr === "4/3") ratioNum = 4 / 3;
      else if (aspectStr === "16/10") ratioNum = 16 / 10;
      else if (typeof aspectStr === "string" && aspectStr.includes("/")) {
        const parts = aspectStr.split("/").map(Number);
        if (parts[0] && parts[1]) ratioNum = parts[0] / parts[1];
      }
      const baseHeight = Math.ceil(baseWidth / ratioNum);
      const viewport = document.getElementById("viewport");

      function updateScale() {
        if (!viewport) return;
        const isFull = !!document.fullscreenElement;
        const padX = isFull ? 0 : 20;
        const padY = isFull ? 0 : 32;
        const availW = Math.max(100, window.innerWidth - padX);
        const availH = Math.max(100, window.innerHeight - padY);
        const scale = Math.min(availW / baseWidth, availH / baseHeight);
        viewport.style.width = baseWidth + "px";
        viewport.style.height = baseHeight + "px";
        viewport.style.transform = "translate(-50%, -50%) scale(" + scale + ")";
        viewport.style.setProperty("--slidev-slide-scale", scale);
        if (isFull) document.body.classList.add("is-fullscreen");
        else document.body.classList.remove("is-fullscreen");
      }

      window.addEventListener("resize", updateScale);
      document.addEventListener("fullscreenchange", updateScale);

      function renderBlock(block) {
        const div = document.createElement("div");
        div.className = "slide-block";
        if (block && block.motion && block.motion.preset && block.motion.preset !== "none") {
          div.classList.add("slidev-motion-" + block.motion.preset.toLowerCase());
          if (typeof block.motion.duration === "number" && block.motion.duration > 0) {
            div.style.setProperty("--motion-duration", block.motion.duration + "ms");
          }
          if (typeof block.motion.delay === "number" && block.motion.delay > 0) {
            div.style.setProperty("--motion-delay", block.motion.delay + "ms");
          }
        }
        const md = block.rawMarkdown || block.content || "";

        if (md.includes('class="slidev-block-ref"') || md.includes('class="slidev-ref-tag"')) {
          div.innerHTML = md;
          return div;
        }

        const CARBON_MAP = {
          'carbon:arrow-right': '<svg viewBox="0 0 32 32" width="1.2em" height="1.2em" fill="currentColor" style="display:inline-block;vertical-align:middle;"><path d="m18 6l-1.43 1.393L24.15 15H4v2h20.15l-7.58 7.573L18 26l10-10z"/></svg>',
          'carbon:arrow-left': '<svg viewBox="0 0 32 32" width="1.2em" height="1.2em" fill="currentColor" style="display:inline-block;vertical-align:middle;"><path d="m14 26l1.43-1.393L7.85 17H28v-2H7.85l7.58-7.573L14 6L4 16z"/></svg>',
          'carbon:edit': '<svg viewBox="0 0 32 32" width="1.2em" height="1.2em" fill="currentColor" style="display:inline-block;vertical-align:middle;"><path d="M2 26h28v2H2zM25.4 9c.8-.8.8-2 0-2.8l-3.6-3.6c-.8-.8-2-.8-2.8 0l-15 15V24h6.4l15-15zM20.4 4L24 7.6l-2.4 2.4l-3.6-3.6L20.4 4zM6 22v-3.6l11-11l3.6 3.6l-11 11H6z"/></svg>',
          'carbon:logo-github': '<svg viewBox="0 0 32 32" width="1.2em" height="1.2em" fill="currentColor" style="display:inline-block;vertical-align:middle;"><path fill-rule="evenodd" d="M16 2a14 14 0 0 0-4.43 27.28c.7.13 1-.3 1-.67v-2.38c-3.89.84-4.71-1.88-4.71-1.88a3.7 3.7 0 0 0-1.56-2.05c-1.27-.86.1-.85.1-.85a2.94 2.94 0 0 1 2.14 1.44a3 3 0 0 0 4.08 1.16a2.93 2.93 0 0 1 .89-1.87c-3.1-.35-6.36-1.55-6.36-6.9a5.4 5.4 0 0 1 1.44-3.75a5 5 0 0 1 .14-3.71s1.17-.38 3.85 1.43a13.3 13.3 0 0 1 7 0c2.67-1.81 3.84-1.43 3.84-1.43a5 5 0 0 1 .14 3.71a5.4 5.4 0 0 1 1.44 3.75c0 5.37-3.27 6.54-6.38 6.89a3.35 3.35 0 0 1 1.26 2.61v3.87c0 .38.26.81 1 .67A14 14 0 0 0 16 2"/></svg>'
        };

        if (/@\\w+=['"]|v-\\w+|<button|<a\\b|<carbon:|^<div/i.test(md)) {
          if (md.includes('abs-br') || md.includes('abs-bl') || md.includes('abs-tr') || md.includes('abs-tl') || md.includes('absolute')) {
            div.classList.add("slide-block--absolute");
          }
          let renderedHtml = md;
          for (const [tag, svg] of Object.entries(CARBON_MAP)) {
            const regex = new RegExp("<" + tag + "\\\\s*\\\\/?>", "gi");
            renderedHtml = renderedHtml.replace(regex, svg);
            const regexDash = new RegExp("<" + tag.replace(":", "-") + "\\\\s*\\\\/?>", "gi");
            renderedHtml = renderedHtml.replace(regexDash, svg);
          }
          div.innerHTML = renderedHtml;

          // 挂载交互事件监听
          const nextBtns = div.querySelectorAll('[\\\\@click*="nav.next"], [\\\\@click*="next"]');
          nextBtns.forEach(btn => {
            btn.style.cursor = "pointer";
            btn.addEventListener("click", (e) => {
              e.stopPropagation();
              renderSlide(currentIndex + 1);
            });
          });

          const prevBtns = div.querySelectorAll('[\\\\@click*="nav.prev"], [\\\\@click*="prev"]');
          prevBtns.forEach(btn => {
            btn.style.cursor = "pointer";
            btn.addEventListener("click", (e) => {
              e.stopPropagation();
              renderSlide(currentIndex - 1);
            });
          });

          return div;
        }

        if (md.startsWith("### ")) div.innerHTML = "<h3>" + md.slice(4) + "</h3>";
        else if (md.startsWith("## ")) div.innerHTML = "<h2>" + md.slice(3) + "</h2>";
        else if (md.startsWith("# ")) div.innerHTML = "<h1>" + md.slice(2) + "</h1>";
        else if (md.startsWith("\`\`\`")) {
          const customMaxHeight = block?.attributes?.["custom-slidev-max-height"] || block?.attrs?.["custom-slidev-max-height"] || block?.maxHeight || "";
          const heightStyle = customMaxHeight ? ' style="max-height:' + customMaxHeight + ';overflow-y:auto;"' : "";
          div.innerHTML = "<pre" + heightStyle + "><code>" + md.slice(3, -3) + "</code></pre>";
        }
        else if (md.startsWith("> ")) div.innerHTML = "<blockquote><p>" + md.slice(2) + "</p></blockquote>";
        else if ((/<video\b/i.test(md) || (block && (block.type === "video" || block.type === "NodeVideo"))) && !/^(s*)([-*+]|d+.)s+/m.test(md)) {
          div.classList.add("slide-video-container", "slide-media-container", "slide-media-block");
          const isAutoplay = block && block.attributes && block.attributes["custom-slidev-autoplay"] === "true";
          const isLoop = block && block.attributes && block.attributes["custom-slidev-loop"] === "true";
          const isMuted = block && block.attributes && (block.attributes["custom-slidev-muted"] === "true" || isAutoplay);
          const hideControls = block && block.attributes && block.attributes["custom-slidev-controls"] === "false";
          let videoHtml = md;
          if (hideControls) videoHtml = videoHtml.replace(/\bcontrols(?:="[^"]*")?/gi, "").trim();
          else if (!videoHtml.includes("controls")) videoHtml = videoHtml.replace("<video", "<video controls");
          if (isAutoplay && !videoHtml.includes("autoplay")) videoHtml = videoHtml.replace("<video", "<video autoplay playsinline");
          if (isLoop && !videoHtml.includes("loop")) videoHtml = videoHtml.replace("<video", "<video loop");
          if (isMuted && !videoHtml.includes("muted")) videoHtml = videoHtml.replace("<video", "<video muted");
          videoHtml = videoHtml.replace("<video", '<video class="slide-video-player"');
          div.setAttribute("data-autoplay", isAutoplay ? "true" : "false");
          div.innerHTML = videoHtml;
        }
        else if (/^(s*)([-*+]|d+.)s+/m.test(md)) {
          div.classList.add("pdf-list-item");
          const lines = md.split("
");
          let isOrdered = false;
          const items = [];
          for (let i = 0; i < lines.length; i++) {
            const line = lines[i];
            const tr = line.trim();
            if (!tr) continue;
            const um = line.match(/^(s*)[-*+]s+(.*)$/);
            const om = line.match(/^(s*)d+.s+(.*)$/);
            if (um) { items.push({ text: um[2], media: [] }); continue; }
            if (om) { if (items.length === 0) isOrdered = true; items.push({ text: om[2], media: [] }); continue; }
            if (items.length > 0) {
              const im = tr.match(/^![(.*?)]((.*?))$/);
              if (im) {
                const isGif = /.gif(?:?|$)/i.test(im[2]);
                items[items.length - 1].media.push('<div class="slide-list-media"><img alt="' + im[1] + '" src="' + im[2] + '" class="' + (isGif ? 'list-item-gif' : 'list-item-img') + '" /></div>');
                continue;
              }
              const hm = tr.match(/^<img\b[sS]*?/?>$/i);
              if (hm) {
                items[items.length - 1].media.push('<div class="slide-list-media">' + tr + '</div>');
                continue;
              }
              if (/<video\b/i.test(tr)) {
                let vHtml = tr;
                if (!/</video>/i.test(vHtml)) {
                  while (i + 1 < lines.length && !/</video>/i.test(vHtml)) {
                    i++;
                    vHtml += " " + lines[i].trim();
                  }
                }
                const isAutoplay = block && block.attributes && block.attributes["custom-slidev-autoplay"] === "true";
                const isLoop = block && block.attributes && block.attributes["custom-slidev-loop"] === "true";
                const isMuted = block && block.attributes && (block.attributes["custom-slidev-muted"] === "true" || isAutoplay);
                const hideControls = block && block.attributes && block.attributes["custom-slidev-controls"] === "false";
                if (hideControls) vHtml = vHtml.replace(/\bcontrols(?:="[^"]*")?/gi, "").trim();
                else if (!vHtml.includes("controls")) vHtml = vHtml.replace("<video", "<video controls");
                if (isAutoplay && !vHtml.includes("autoplay")) vHtml = vHtml.replace("<video", "<video autoplay playsinline");
                if (isLoop && !vHtml.includes("loop")) vHtml = vHtml.replace("<video", "<video loop");
                if (isMuted && !vHtml.includes("muted")) vHtml = vHtml.replace("<video", "<video muted");
                vHtml = vHtml.replace("<video", '<video class="slide-video-player"');
                items[items.length - 1].media.push('<div class="slide-list-media slide-video-container slide-media-container" data-autoplay="' + (isAutoplay ? 'true' : 'false') + '">' + vHtml + '</div>');
                continue;
              }
              items[items.length - 1].text += "
" + tr;
            }
          }
          const tag = isOrdered ? "ol" : "ul";
          const liHtml = items.map(it => {
            const med = it.media && it.media.length ? "
" + it.media.join("
") : "";
            const lines = (it.text || "").split("
").map(l => l.trim()).filter(Boolean);
            const hasHeading = lines.some(l => /^#{1,6}s+/.test(l));
            if (!hasHeading) {
              let h = it.text.replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
              return "<li>" + h + med + "</li>";
            }
            const parts = [];
            let pLines = [];
            const flushP = () => {
              if (pLines.length > 0) {
                let ph = pLines.join(" ").replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
                parts.push('<p class="slide-list-item-desc">' + ph + '</p>');
                pLines = [];
              }
            };
            for (const l of lines) {
              const hm = l.match(/^(#{1,6})s+(.*)$/);
              if (hm) {
                flushP();
                const lvl = hm[1].length;
                let th = hm[2].trim().replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
                parts.push('<h' + lvl + ' class="slide-list-item-title">' + th + '</h' + lvl + '>');
              } else {
                pLines.push(l);
              }
            }
            flushP();
            return "<li>" + parts.join("
") + med + "</li>";
          }).join("
");
          div.innerHTML = "<" + tag + " class="pdf-list">
" + liHtml + "
</" + tag + ">";
        }
        else {
          const imgMatch = md.match(/!\\[(.*?)\\]\\((.*?)\\)/);
          if (imgMatch) {
            div.classList.add("slide-media-container", "slide-media-block", "slide-block--image");
            div.innerHTML = '<img alt="' + imgMatch[1] + '" src="' + imgMatch[2] + '" class="slide-media-img" />';
          } else {
            let html = md.replace(/\\*\\*(.*?)\\*\\*/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
            div.innerHTML = "<p>" + html + "</p>";
          }
        }
        return div;
      }

      function renderSlide(idx) {
        if (slides.length === 0) return;
        currentIndex = Math.max(0, Math.min(idx, slides.length - 1));
        const slide = slides[currentIndex];
        pageNum.textContent = (currentIndex + 1) + " / " + slides.length;

        container.className = "slide-content layout-" + (slide.frontmatter?.layout || "default");
        container.innerHTML = "";

        const z = typeof slide.frontmatter?.zoom === "number" && slide.frontmatter.zoom > 0 ? slide.frontmatter.zoom : 1;
        if (z !== 1) {
          container.style.width = (100 / z) + "%";
          container.style.height = (100 / z) + "%";
          container.style.transformOrigin = "top left";
          container.style.transform = "scale(" + z + ")";
        } else {
          container.style.width = "100%";
          container.style.height = "100%";
          container.style.transform = "none";
        }

        if (slide.frontmatter?.layout === "two-cols") {
          const leftCol = document.createElement("div");
          leftCol.className = "two-cols-left";
          const rightCol = document.createElement("div");
          rightCol.className = "two-cols-right";

          for (const block of (slide.blocks || [])) {
            const el = renderBlock(block);
            if (block.slot === "right") rightCol.appendChild(el);
            else leftCol.appendChild(el);
          }
          container.appendChild(leftCol);
        } else if (slide.frontmatter?.layout === "two-cols-header") {
          const containerDiv = document.createElement("div");
          containerDiv.className = "layout-two-cols-header-container";
          const headerDiv = document.createElement("div");
          headerDiv.className = "layout-header-section";
          const gridDiv = document.createElement("div");
          gridDiv.className = "pdf-two-cols-wrapper layout-two-cols-grid";
          const leftCol = document.createElement("div");
          leftCol.className = "pdf-col pdf-col--left";
          const rightCol = document.createElement("div");
          rightCol.className = "pdf-col pdf-col--right";

          const blocks = (slide.blocks || []).filter(b => b.slot !== "slot-divider-right");
          let headerBlocks = blocks.filter(b => b.slot === "header");
          if (headerBlocks.length === 0 && blocks.length > 0) {
            const candidate = blocks.find(b => b.type === "h" && (!b.slot || b.slot === "default"));
            if (candidate) headerBlocks = [candidate];
          }
          const rem = blocks.filter(b => !headerBlocks.includes(b));
          for (const b of headerBlocks) headerDiv.appendChild(renderBlock(b));
          for (const b of rem) {
            if (b.slot === "right" || b.slot === "col-2") rightCol.appendChild(renderBlock(b));
            else leftCol.appendChild(renderBlock(b));
          }
          gridDiv.appendChild(leftCol);
          gridDiv.appendChild(rightCol);
          containerDiv.appendChild(headerDiv);
          containerDiv.appendChild(gridDiv);
          container.appendChild(containerDiv);
        } else if (slide.frontmatter?.layout === "three-cols-header") {
          const containerDiv = document.createElement("div");
          containerDiv.className = "layout-three-cols-header-container";
          const headerDiv = document.createElement("div");
          headerDiv.className = "layout-header-section";
          const gridDiv = document.createElement("div");
          gridDiv.className = "pdf-three-cols-wrapper layout-three-cols-grid";
          const col1 = document.createElement("div");
          col1.className = "pdf-col pdf-col--1";
          const col2 = document.createElement("div");
          col2.className = "pdf-col pdf-col--2";
          const col3 = document.createElement("div");
          col3.className = "pdf-col pdf-col--3";

          const blocks = (slide.blocks || []).filter(b => b.slot !== "slot-divider-right");
          let headerBlocks = blocks.filter(b => b.slot === "header");
          if (headerBlocks.length === 0 && blocks.length > 0) {
            const candidate = blocks.find(b => b.type === "h" && (!b.slot || b.slot === "default"));
            if (candidate) headerBlocks = [candidate];
          }
          const rem = blocks.filter(b => !headerBlocks.includes(b));
          let c1 = [], c2 = [], c3 = [];
          const hasExplicitCols = rem.some(b => b.slot === "col-1" || b.slot === "col-2" || b.slot === "col-3" || b.slot === "center" || b.slot === "left" || b.slot === "right");
          if (hasExplicitCols) {
            c2 = rem.filter(b => b.slot === "col-2" || b.slot === "center");
            c3 = rem.filter(b => b.slot === "col-3" || b.slot === "right");
            c1 = rem.filter(b => !c2.includes(b) && !c3.includes(b));
          } else if (rem.length >= 3) {
            const count1 = Math.ceil(rem.length / 3);
            const count2 = Math.ceil((rem.length - count1) / 2);
            c1 = rem.slice(0, count1);
            c2 = rem.slice(count1, count1 + count2);
            c3 = rem.slice(count1 + count2);
          } else if (rem.length === 2) {
            c1 = [rem[0]];
            c2 = [rem[1]];
            c3 = [];
          } else if (rem.length === 1) {
            const lines = (rem[0].rawMarkdown || rem[0].content || "").trim().split(/\r?
/);
            const itemStartIndices = [];
            for (let i = 0; i < lines.length; i++) {
              if (/^[ 	]*[-*+]s+|^[ 	]*d+.s+/.test(lines[i])) itemStartIndices.push(i);
            }
            if (itemStartIndices.length >= 3) {
              const count1 = Math.ceil(itemStartIndices.length / 3);
              const count2 = Math.ceil((itemStartIndices.length - count1) / 2);
              const items1 = lines.slice(itemStartIndices[0], itemStartIndices[count1]).join("
");
              const items2 = lines.slice(itemStartIndices[count1], itemStartIndices[count1 + count2]).join("
");
              const items3 = lines.slice(itemStartIndices[count1 + count2]).join("
");
              c1 = [{ ...rem[0], rawMarkdown: items1, content: items1 }];
              c2 = [{ ...rem[0], id: rem[0].id + "-col2", rawMarkdown: items2, content: items2 }];
              c3 = [{ ...rem[0], id: rem[0].id + "-col3", rawMarkdown: items3, content: items3 }];
            } else {
              c1 = rem;
            }
          } else {
            c1 = rem;
          }
          for (const b of headerBlocks) headerDiv.appendChild(renderBlock(b));
          for (const b of c1) col1.appendChild(renderBlock(b));
          for (const b of c2) col2.appendChild(renderBlock(b));
          for (const b of c3) col3.appendChild(renderBlock(b));
          gridDiv.appendChild(col1);
          gridDiv.appendChild(col2);
          gridDiv.appendChild(col3);
          containerDiv.appendChild(headerDiv);
          containerDiv.appendChild(gridDiv);
          container.appendChild(containerDiv);
        } else if (slide.frontmatter?.layout === "image-right" || slide.frontmatter?.layout === "image-left") {
          const isImageRight = slide.frontmatter?.layout === "image-right";
          const contentCol = document.createElement("div");
          contentCol.className = isImageRight ? "image-right-content" : "image-left-content";

          for (const block of (slide.blocks || [])) {
            contentCol.appendChild(renderBlock(block));
          }

          const imgCol = document.createElement("div");
          imgCol.className = isImageRight ? "image-right-img-container" : "image-left-img-container";
          const img = document.createElement("img");
          img.className = isImageRight ? "image-right-img" : "image-left-img";
          img.src = slide.frontmatter?.image || slide.frontmatter?.background || "";
          img.alt = "Slide cover";
          img.onerror = function() {
            this.src = "https://fastly.jsdelivr.net/gh/slidevjs/slidev-covers@main/static/2HmfbSpvcos.webp";
          };
          imgCol.appendChild(img);

          if (isImageRight) {
            container.appendChild(contentCol);
            container.appendChild(imgCol);
          } else {
            container.appendChild(imgCol);
            container.appendChild(contentCol);
          }
        } else {
          for (const block of (slide.blocks || [])) {
            container.appendChild(renderBlock(block));
          }
        }

        function syncAutoplayVideos() {
          const doSync = () => {
            const videos = container.querySelectorAll("video");
            videos.forEach((v) => {
              const box = v.closest("[data-autoplay]");
              const isAuto = v.hasAttribute("autoplay") || v.autoplay || (box && box.getAttribute("data-autoplay") === "true");
              if (isAuto) {
                v.muted = true;
                v.defaultMuted = true;
                v.setAttribute("muted", "");
                v.playsInline = true;
                v.setAttribute("playsinline", "");
                const playFn = () => {
                  if (!v.paused) return;
                  v.muted = true;
                  v.defaultMuted = true;
                  const p = v.play();
                  if (p !== undefined) {
                    p.catch(() => {
                      v.muted = true;
                      v.defaultMuted = true;
                      setTimeout(() => { if (v.paused) v.play().catch(() => {}); }, 150);
                    });
                  }
                };
                playFn();
                if (!v.__autoplayBound) {
                  v.__autoplayBound = true;
                  v.addEventListener("loadedmetadata", playFn);
                  v.addEventListener("canplay", playFn);
                }
              }
            });
          };
          setTimeout(doSync, 60);
          setTimeout(doSync, 200);
        }
        syncAutoplayVideos();
      }

      btnPrev.addEventListener("click", () => renderSlide(currentIndex - 1));
      btnNext.addEventListener("click", () => renderSlide(currentIndex + 1));
      btnFullscreen.addEventListener("click", () => {
        if (!document.fullscreenElement) {
          document.documentElement.requestFullscreen().then(() => updateScale()).catch(() => {});
        } else {
          document.exitFullscreen().then(() => updateScale()).catch(() => {});
        }
      });

      window.addEventListener("keydown", (e) => {
        if (e.key === "ArrowRight" || e.key === " ") renderSlide(currentIndex + 1);
        if (e.key === "ArrowLeft") renderSlide(currentIndex - 1);
        if (e.key === "f" || e.key === "F") btnFullscreen.click();
      });

      document.addEventListener("click", (e) => {
        if (e.button !== 0) return;
        const targetEl = e.target instanceof Element ? e.target : e.target?.parentElement;
        if (!targetEl || !targetEl.closest) return;

        const refEl = targetEl.closest("[data-ref-id]");
        if (refEl) {
          const id = refEl.getAttribute("data-ref-id");
          if (id) {
            window.open("siyuan://blocks/" + id, "_blank");
            return;
          }
        }

        const selection = window.getSelection ? window.getSelection().toString().trim() : "";
        if (selection.length > 0) return;

        const isComponent = targetEl.closest(
          ".slide-block, .controls-bar, .image-right-img-container, .image-left-img-container, img, video, audio, button, a, input, textarea, select, [data-clickable], [data-ref-id], .slidev-toc, .empty-state"
        );
        if (isComponent) return;

        const isLeft = e.clientX < window.innerWidth / 2;
        if (isLeft) {
          renderSlide(currentIndex - 1);
        } else {
          renderSlide(currentIndex + 1);
        }
      });

      renderSlide(0);
      updateScale();
    })();
  <\/script>
</body>
</html>`}function ql(t,i){if(typeof document>"u")return!1;const e=new Blob([i],{type:"text/html;charset=utf-8"}),n=URL.createObjectURL(e),s=document.createElement("a");return s.href=n,s.download=t.endsWith(".html")?t:`${t}.html`,document.body.appendChild(s),s.click(),document.body.removeChild(s),URL.revokeObjectURL(n),!0}function eh(t){switch(t){case"4:3":return"size: 12in 9in;";case"A4-landscape":return"size: 297mm 210mm;";case"A4-portrait":return"size: 210mm 297mm;";case"16:9":default:return"size: 16in 9in;"}}function ih(t,i){const e="Slidev 演示讲义",n="16:9",s="light",r=eh(n),l=t.slides.map((o,a)=>{const c=o.frontmatter.layout||"default",d=th(o),h=`${a+1} / ${t.slides.length}`;return`
      <section class="pdf-slide-page layout-${c} theme-${s}">
        <header class="pdf-slide-header">
          <span class="pdf-doc-title">${fe(e)}</span>
          ${`<span class="pdf-page-badge">P. ${h}</span>`}
        </header>
        <div class="pdf-slide-body">
          ${d}
        </div>
        ${o.notes?`
          <footer class="pdf-slide-notes">
            <strong>演讲备注:</strong> ${fe(o.notes)}
          </footer>
        `:""}
      </section>
    `}).join(`
`);return`<!DOCTYPE html>
<html lang="zh-CN">
<head>
  <meta charset="UTF-8">
  <title>${fe(e)} - 高保真讲义</title>
  <style>
    @page {
      ${r}
      margin: 0;
    }
    * {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
      -webkit-print-color-adjust: exact !important;
      print-color-adjust: exact !important;
    }
    body {
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "PingFang SC", "Microsoft YaHei", sans-serif;
      background: #f8fafc;
      color: #1e293b;
    }
    .pdf-slide-page {
      width: 100vw;
      height: 100vh;
      page-break-after: always;
      break-after: page;
      padding: 40px 60px;
      display: flex;
      flex-direction: column;
      position: relative;
      background: #ffffff;
      overflow: hidden;
    }
    .pdf-slide-page.theme-dark {
      background: #0f1117;
      color: #f1f5f9;
    }
    .pdf-slide-header {
      font-size: 13px;
      color: #64748b;
      margin-bottom: 24px;
      display: flex;
      justify-content: space-between;
      border-bottom: 1px solid #e2e8f0;
      padding-bottom: 8px;
    }
    .theme-dark .pdf-slide-header {
      border-bottom-color: #2e3346;
      color: #94a3b8;
    }
    .pdf-slide-body {
      flex: 1;
      display: flex;
      flex-direction: column;
      gap: 16px;
      font-size: 20px;
      line-height: 1.6;
      overflow: hidden;
    }
    .pdf-block h1 { font-size: 2.5rem; font-weight: 800; color: #2563eb; margin-bottom: 12px; }
    .pdf-block h2 { font-size: 1.9rem; font-weight: 700; color: #1d4ed8; margin-bottom: 10px; }
    .pdf-block h3 { font-size: 1.4rem; font-weight: 600; margin-bottom: 8px; }
    .pdf-block h4 { font-size: 1.2rem; font-weight: 600; margin-bottom: 6px; }
    .pdf-block p { font-size: 1.15rem; color: inherit; }
    .pdf-code,
    pre {
      background: #f1f5f9;
      padding: 14px 18px;
      border-radius: 6px;
      font-family: "JetBrains Mono", Consolas, monospace;
      font-size: 0.95rem;
      border-left: 4px solid #3b82f6;
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      max-width: 100% !important;
      box-sizing: border-box !important;
    }
    .pdf-code code,
    pre code {
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      display: block !important;
      width: 100% !important;
      box-sizing: border-box !important;
    }
    .code-line {
      display: flex !important;
      align-items: flex-start !important;
      width: 100% !important;
      box-sizing: border-box !important;
      line-height: 1.6;
    }
    .code-line .line-no {
      display: inline-block !important;
      flex-shrink: 0 !important;
      min-width: 2.2em !important;
      text-align: right !important;
      margin-right: 12px !important;
      user-select: none !important;
      opacity: 0.45 !important;
    }
    .code-line .line-content {
      flex: 1 1 0% !important;
      min-width: 0 !important;
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
    }
    .theme-dark .pdf-code {
      background: #1e1e24;
      border-left-color: #60a5fa;
    }
    .pdf-quote {
      border-left: 4px solid #10b981;
      background: rgba(16, 185, 129, 0.08);
      padding: 10px 16px;
      border-radius: 0 4px 4px 0;
      font-style: italic;
    }
    .pdf-image,
    .slide-media-img {
      max-width: 100% !important;
      max-height: 48vh !important;
      width: auto !important;
      height: auto !important;
      object-fit: contain !important;
      border-radius: 6px;
      margin: auto;
      display: block;
    }
    .slide-media-block,
    .slide-media-container,
    .slide-video-container {
      display: flex;
      flex-direction: column;
      justify-content: center;
      align-items: center;
      width: 100%;
      max-height: 48vh;
      margin: 8px 0;
      overflow: hidden;
    }
    .slide-list-media {
      display: flex;
      align-items: center;
      margin-top: 8px;
      margin-bottom: 6px;
      max-width: 100%;
      overflow: hidden;
    }
    .slide-list-media img,
    .slide-list-media video,
    .slide-list-media .list-item-gif {
      max-width: 100% !important;
      max-height: min(280px, 36vh) !important;
      width: auto !important;
      height: auto !important;
      object-fit: contain !important;
      border-radius: 6px;
      display: block;
    }
    .slide-video-player {
      max-width: 100% !important;
      max-height: 48vh !important;
      width: auto !important;
      height: auto !important;
      object-fit: contain !important;
      border-radius: 6px;
      background: #000;
      border: 1px solid #cbd5e1;
    }
    .pdf-two-cols-wrapper,
    .layout-two-cols-grid {
      display: grid;
      grid-template-columns: minmax(0, 1fr) minmax(0, 1fr);
      gap: 36px;
      width: 100%;
      height: 100%;
      flex: 1 1 0%;
      align-items: stretch;
    }
    .layout-two-cols-header-container,
    .layout-three-cols-header-container {
      display: flex;
      flex-direction: column;
      width: 100%;
      height: 100%;
    }
    .layout-header-section {
      width: 100%;
      margin-bottom: 24px;
      flex-shrink: 0;
    }
    .pdf-three-cols-wrapper,
    .layout-three-cols-grid {
      display: grid;
      grid-template-columns: minmax(0, 1fr) minmax(0, 1fr) minmax(0, 1fr);
      gap: 24px;
      width: 100%;
      height: 100%;
      flex: 1 1 0%;
      align-items: stretch;
      box-sizing: border-box;
    }
    .pdf-col {
      display: flex;
      flex-direction: column;
      gap: 14px;
      min-width: 0;
      width: 100%;
      max-width: 100%;
      height: 100%;
      max-height: 100%;
      min-height: 0;
      overflow: hidden;
      box-sizing: border-box;
      overflow-wrap: break-word;
      word-break: break-word;
      white-space: normal;
    }
    .pdf-col video,
    .layout-three-cols-grid video,
    .layout-two-cols-grid video {
      max-width: 100% !important;
      max-height: 100% !important;
      width: 100% !important;
      height: 100% !important;
      min-width: 0 !important;
      min-height: 0 !important;
      object-fit: contain !important;
      display: block !important;
      margin: auto !important;
    }
    .pdf-col * {
      overflow-wrap: break-word;
      word-break: break-word;
      box-sizing: border-box;
    }
    .pdf-col pre {
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      max-width: 100% !important;
      box-sizing: border-box !important;
    }
    .pdf-list-item {
      padding-left: 20px;
    }
    .pdf-list {
      padding-left: 24px;
      margin: 8px 0;
      display: flex;
      flex-direction: column;
      gap: 6px;
    }
    .pdf-list li {
      font-size: 1.15rem;
      line-height: 1.6;
    }
    .pdf-task-item {
      list-style: none;
      margin-left: -20px;
      display: flex;
      align-items: center;
      gap: 8px;
    }
    .pdf-task-item input[type="checkbox"] {
      width: 1.15em;
      height: 1.15em;
      cursor: pointer;
    }
    /* 两栏与三栏（超级块分栏）布局：去除列表圆点标记与缩进 */
    .layout-two-cols ul,
    .layout-two-cols ol,
    .layout-two-cols-header ul,
    .layout-two-cols-header ol,
    .layout-three-cols ul,
    .layout-three-cols ol,
    .layout-three-cols-header ul,
    .layout-three-cols-header ol,
    .pdf-two-cols-wrapper ul,
    .pdf-two-cols-wrapper ol,
    .pdf-three-cols-wrapper ul,
    .pdf-three-cols-wrapper ol,
    .pdf-col ul,
    .pdf-col ol,
    .pdf-col .pdf-list,
    .layout-two-cols-grid .pdf-list,
    .layout-three-cols-grid .pdf-list {
      list-style: none !important;
      list-style-type: none !important;
      padding-left: 0 !important;
      margin-left: 0 !important;
    }
    .layout-two-cols li,
    .layout-two-cols-header li,
    .layout-three-cols li,
    .layout-three-cols-header li,
    .pdf-col li,
    .pdf-col .pdf-list-item {
      list-style: none !important;
      list-style-type: none !important;
      padding-left: 0 !important;
      margin-left: 0 !important;
    }
    .layout-two-cols li::marker,
    .layout-two-cols-header li::marker,
    .layout-three-cols li::marker,
    .layout-three-cols-header li::marker,
    .pdf-col li::marker {
      content: none !important;
    }
    /* 列表项内嵌标题与说明排版 */
    .slide-list-item-title,
    .pdf-list li > h1,
    .pdf-list li > h2,
    .pdf-list li > h3,
    .pdf-list li > h4,
    .pdf-list li > h5,
    .pdf-list li > h6,
    li > h1.slide-list-item-title,
    li > h2.slide-list-item-title,
    li > h3.slide-list-item-title,
    li > h4.slide-list-item-title {
      margin-top: 2px !important;
      margin-bottom: 6px !important;
      line-height: 1.35 !important;
      font-weight: 700 !important;
    }
    .pdf-list li > h1, li > h1.slide-list-item-title { font-size: 1.6rem !important; }
    .pdf-list li > h2, li > h2.slide-list-item-title { font-size: 1.4rem !important; }
    .pdf-list li > h3, li > h3.slide-list-item-title { font-size: 1.22rem !important; }
    .pdf-list li > h4, li > h4.slide-list-item-title { font-size: 1.1rem !important; }
    .slide-list-item-desc,
    .pdf-list li > p {
      margin-top: 4px !important;
      margin-bottom: 6px !important;
      font-size: 1.05rem;
      line-height: 1.55;
      opacity: 0.92;
    }
    kbd {
      display: inline-block;
      padding: 2px 7px;
      font-family: ui-monospace, SFMono-Regular, "SF Mono", Menlo, Consolas, "Liberation Mono", monospace;
      font-size: 0.85em;
      font-weight: 600;
      line-height: 1.25;
      color: inherit;
      background: rgba(125, 125, 125, 0.12);
      border: 1px solid rgba(125, 125, 125, 0.35);
      border-bottom-width: 2px;
      border-radius: 5px;
      box-shadow: 0 1px 2px rgba(0, 0, 0, 0.12);
      margin: 0 2px;
      vertical-align: middle;
      white-space: nowrap;
    }
    .theme-dark kbd {
      background: rgba(255, 255, 255, 0.1);
      border-color: rgba(255, 255, 255, 0.25);
      border-bottom-color: rgba(255, 255, 255, 0.4);
      color: #f1f5f9;
      box-shadow: 0 1px 2px rgba(0, 0, 0, 0.4);
    }
    a {
      color: inherit;
      text-decoration: none;
      border-bottom: 1px dashed currentColor;
    }
    .slidev-ref-tag, a.slidev-ref-tag {
      display: inline-flex;
      align-items: center;
      background: rgba(16, 185, 129, 0.1);
      color: #059669;
      border: 1px solid rgba(16, 185, 129, 0.25);
      border-radius: 4px;
      padding: 2px 8px;
      font-size: 0.88em;
      text-decoration: none;
      margin: 2px 4px 2px 0;
    }
    .theme-dark .slidev-ref-tag, .theme-dark a.slidev-ref-tag {
      background: rgba(52, 211, 153, 0.15);
      color: #34d399;
      border-color: rgba(52, 211, 153, 0.3);
    }
    .slidev-block-ref, .pdf-block--ref {
      background: rgba(16, 185, 129, 0.06);
      border-left: 3px solid #059669;
      border-radius: 0 6px 6px 0;
      padding: 10px 14px;
      margin: 8px 0;
    }
    .theme-dark .slidev-block-ref, .theme-dark .pdf-block--ref {
      background: rgba(52, 211, 153, 0.08);
      border-left-color: #34d399;
    }
    .pdf-slide-notes {
      font-size: 14px;
      color: #059669;
      border-top: 1px dashed #cbd5e1;
      padding-top: 12px;
      margin-top: auto;
      line-height: 1.5;
    }
    .theme-dark .pdf-slide-notes {
      color: #34d399;
      border-top-color: #334155;
    }
    /* Layouts */
    .layout-cover .pdf-slide-body {
      justify-content: center;
      align-items: center;
      text-align: center;
    }
    .layout-cover h1 {
      font-size: 3.2rem;
    }
    .layout-center .pdf-slide-body {
      justify-content: center;
      align-items: center;
      text-align: center;
    }
    .layout-fact .pdf-slide-body {
      justify-content: center;
      align-items: center;
      text-align: center;
    }
    .layout-fact h1 {
      font-size: 4.5rem;
      color: #ef4444;
    }
    @media print {
      .slidev-motion-fade-in,
      .slidev-motion-slide-up,
      .slidev-motion-slide-down,
      .slidev-motion-slide-left,
      .slidev-motion-slide-right,
      .slidev-motion-zoom-in,
      .slidev-motion-pop,
      .slidev-motion-bounce {
        animation: none !important;
        opacity: 1 !important;
        transform: none !important;
      }
    }
  </style>
</head>
<body>
  ${l}
</body>
</html>`}function Gl(t,i){var s;if(typeof window>"u"||typeof document>"u")return!1;const e=ih(t);try{const r=document.createElement("iframe");r.style.position="fixed",r.style.right="0",r.style.bottom="0",r.style.width="0",r.style.height="0",r.style.border="none",r.style.visibility="hidden",document.body.appendChild(r);const l=(s=r.contentWindow)==null?void 0:s.document;if(l)return l.open(),l.write(e),l.close(),setTimeout(()=>{var o,a;try{(o=r.contentWindow)==null||o.focus(),(a=r.contentWindow)==null||a.print()}finally{setTimeout(()=>{r.remove()},2e3)}},350),!0}catch(r){console.warn("[pdf-exporter] iframe 打印模式异常，降级尝试 window.open:",r)}const n=window.open("","_blank");return n?(n.document.write(e),n.document.close(),n.focus(),setTimeout(()=>{n.print(),n.close()},350),!0):!1}const nh={class:"spm-slidev-preview-tab"},sh={class:"spm-slidev-tab__toolbar"},oh={class:"spm-slidev-tab__actions"},rh=["disabled"],lh={class:"spm-page-badge"},ah=["disabled"],ch=["aria-label"],dh=["aria-label"],uh=["src"],fh=be({__name:"SlidevPreviewTab",setup(t,{expose:i}){const e=Qe("plugin"),n=Qe("sandboxBridge",new _o),s=new Vp(n),r=new ku,l=ht("web-sandbox"),o=ht(3030),a=ht(null),c=ht(!1),d=ht(null),h=ht(1),m=ht(1),p=ht([]),y=ht(!1),f=ht(!1),k=ht(!1),v=ht("siyuan"),w=ht(""),x=ht(""),E=ht(""),_=ht(!1),C=ht(!1),A=ht(""),B=ht("/plugins/siyuan-slidev/slidev-client/index.html");let P=null,R=null,X=null,S=null,G=null,b=null,U=null;Cn(()=>{d.value&&(n.attach(d.value),r.nativeBridge.attach(d.value)),P=n.onSlideChanged((Z,lt)=>{h.value=Z,m.value=lt}),R=n.onBlockClicked((Z,lt)=>{h.value=lt,s.setActiveBlockId(Z),e&&typeof e.handleBlockClickedFromSlide=="function"?e.handleBlockClickedFromSlide(Z,lt):Ti(Z,e==null?void 0:e.app)}),X=n.onOpenInEditor((Z,lt)=>{h.value=lt,s.setActiveBlockId(Z),Ti(Z,e==null?void 0:e.app)}),S=r.nativeBridge.onPageChanged((Z,lt)=>{h.value=Z,m.value=lt}),G=n.onOpenPeekDrawer(async Z=>{const lt=Co();if(Z.peekType==="siyuan"&&lt.enableWebServeJump){let ut=!1;if(U&&U.docId===Z.target)ut=!0;else if(U&&U.slides&&U.slides.some(T=>{var O;return(O=T.blocks)==null?void 0:O.some(u=>u.id===Z.target)}))ut=!1;else try{const T=await mn(`SELECT id, root_id, type FROM blocks WHERE id = '${Z.target}' LIMIT 1`);T&&T.length>0&&(ut=T[0].type==="d"||T[0].id===T[0].root_id)}catch(T){console.warn("[SlidevPreviewTab] detect block type failed:",T)}v.value="web",_.value=!0,x.value=Ul(lt.webServeUrl,Z.target,{focus:!ut}),E.value=Z.title||`${ut?"思源文档":"思源块"}: ${Z.target.slice(0,8)}`,f.value=!0,n.freezeKeyboardNav(!0)}else v.value=Z.peekType,Z.peekType==="siyuan"?(w.value=Z.target,E.value=Z.title||`块速览: ${Z.target.slice(0,8)}`):(_.value=!0,x.value=Z.target,E.value=Z.title||Z.target),f.value=!0,n.freezeKeyboardNav(!0)}),b=n.onRequestToggleFullscreen(()=>{ot()}),typeof document<"u"&&document.addEventListener("fullscreenchange",rt)}),go(()=>{typeof document<"u"&&document.removeEventListener("fullscreenchange",rt),G&&G(),b&&b(),P&&P(),R&&R(),X&&X(),S&&S(),n.detach(),s.destroy(),r.destroy()});async function it(){if(l.value==="web-sandbox"){if(!U){vt.showMessage("请先在主编辑区打开演示文档");return}vt.showMessage("正在探测本地 Node 环境并编排 Slidev Pro 进程...");const Z=await r.startProMode(U,Os);if(!Z.success){vt.showMessage(`无法启动官方 Pro 模式：${Z.error}`);return}l.value="pro-cli",o.value=Z.port||3030,B.value=Z.url,d.value&&r.nativeBridge.attach(d.value),vt.showMessage(`🟢 已成功接入官方原生 Slidev 服务 (端口: ${o.value})`)}else r.stopProMode(),l.value="web-sandbox",B.value="/plugins/siyuan-slidev/slidev-client/index.html",d.value&&n.attach(d.value),vt.showMessage("已切回内置高保真沙箱")}function j(){C.value=!C.value,C.value?A.value=(U==null?void 0:U.docId)||"":(A.value="",H())}function st(){h.value>1&&(l.value==="pro-cli"?r.nativeBridge.navigateToPage(h.value-1):n.navigatePage(h.value-1))}function K(){h.value<m.value&&(l.value==="pro-cli"?r.nativeBridge.navigateToPage(h.value+1):n.navigatePage(h.value+1))}function Y(Z){h.value=Z,l.value==="pro-cli"?r.nativeBridge.navigateToPage(Z):n.navigatePage(Z)}function H(){e&&typeof e.compileCurrentDocument=="function"?e.compileCurrentDocument():e!=null&&e.eventBus&&typeof e.eventBus.emit=="function"&&e.eventBus.emit("slidev:request-compile")}function L(){f.value=!1,n.freezeKeyboardNav(!1)}function ct(){L()}function rt(){typeof document<"u"&&(c.value=!!document.fullscreenElement,n.postMessage("FULLSCREEN_CHANGED",{isFullscreen:c.value}))}function ot(){const Z=a.value||d.value;Z&&(document.fullscreenElement?document.exitFullscreen().then(()=>{n.postMessage("FULLSCREEN_CHANGED",{isFullscreen:!1})}).catch(()=>{}):Z.requestFullscreen().then(()=>{n.postMessage("FULLSCREEN_CHANGED",{isFullscreen:!0})}).catch(()=>{}))}function J(){window.open("/plugins/siyuan-slidev/slidev-client/presenter.html","SlidevPresenter","width=1200,height=800")}function mt(){if(!U){vt.showMessage("请先在主编辑区打开幻灯片文档");return}const Z=Kl(U);ql("presentation.html",Z)&&vt.showMessage("已开始下载单文件离线 HTML 演示包")}function gt(){if(!U){vt.showMessage("请先在主编辑区打开幻灯片文档");return}Gl(U)&&vt.showMessage("已唤起打印视窗，请在打印选项中选择「另存为 PDF」")}return i({updateDocument(Z,lt){C.value&&A.value&&lt&&lt!==A.value||(U=Z,C.value&&!A.value&&(A.value=Z.docId),p.value=Z.slides,m.value=Z.slides.length,s.setDocId(Z.docId),s.updateSlidesIndex(Z.slides),l.value==="pro-cli"?r.scaffolder.scaffold(Z,Os).catch(()=>{}):n.updateSlides(Z.slides,Z.config,Z.fullMarkdown))},navigateToBlock(Z){s.onCursorFocusBlock(Z)},isPinned:C,pinnedDocId:A,engineMode:l,toggleEngineMode:it}),(Z,lt)=>(tt(),nt("div",nh,[g("div",sh,[lt[4]||(lt[4]=g("div",{class:"spm-slidev-tab__title"},[g("svg",{class:"spm-slidev-tab__icon","aria-hidden":"true"},[g("use",{"xlink:href":"#iconSlidev"})]),g("span",null,"Slidev 演示预览")],-1)),g("div",oh,[g("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s",disabled:h.value<=1,"aria-label":"上一页",onClick:st},[pt(wt,{name:"chevron-left"})],8,rh),g("span",lh,St(h.value)+" / "+St(m.value||1),1),g("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s",disabled:h.value>=m.value,"aria-label":"下一页",onClick:K},[pt(wt,{name:"chevron-right"})],8,ah),g("button",{class:Tt(["spm-icon-btn b3-tooltips b3-tooltips__s",{"is-primary":C.value}]),"aria-label":C.value?"已锁定当前文档（点击解除）："+A.value:"点击锁定当前文档（不随主编辑区切换）",onClick:j},[pt(wt,{name:"pin"}),g("span",null,St(C.value?"已锁定":"跟随"),1)],10,ch),g("button",{class:Tt(["spm-icon-btn b3-tooltips b3-tooltips__s",{"is-primary":l.value==="pro-cli"}]),"aria-label":l.value==="pro-cli"?"当前：官方原生 Pro 模式 (localhost:"+o.value+")，点击切回沙箱":"当前：内置高保真沙箱，点击切换官方原生 Pro 模式",onClick:it},[pt(wt,{name:"step"}),g("span",null,St(l.value==="pro-cli"?"Pro ("+o.value+")":"沙箱"),1)],10,dh),lt[3]||(lt[3]=g("span",{class:"spm-toolbar-divider"},null,-1)),g("button",{class:Tt(["spm-icon-btn b3-tooltips b3-tooltips__s",{"is-primary":y.value}]),"aria-label":"切换幻灯片大纲抽屉",onClick:lt[0]||(lt[0]=ut=>y.value=!y.value)},[pt(wt,{name:"outline"})],2),g("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"双屏演讲者视图 (Presenter Mode ⌥M)",onClick:J},[pt(wt,{name:"presenter"})]),g("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"导出单文件 HTML 演示包",onClick:mt},[pt(wt,{name:"export-html"})]),g("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"导出 16:9 PDF 演示讲义",onClick:gt},[pt(wt,{name:"export-pdf"})]),g("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"重新编译并刷新",onClick:H},[pt(wt,{name:"refresh"})]),g("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"全屏放映",onClick:ot},[pt(wt,{name:"fullscreen"})])])]),g("div",{ref_key:"fullscreenContainerRef",ref:a,class:"spm-slidev-tab__viewport spm-slidev-fullscreen-container"},[g("iframe",{ref_key:"sandboxIframeRef",ref:d,class:"spm-slidev-tab__iframe",src:B.value,frameborder:"0",allow:"fullscreen; autoplay"},null,8,uh),pt(pp,{visible:f.value,"onUpdate:visible":lt[1]||(lt[1]=ut=>f.value=ut),"is-maximized":k.value,"onUpdate:isMaximized":lt[2]||(lt[2]=ut=>k.value=ut),title:E.value,onClose:L},{default:rl(()=>[v.value==="siyuan"&&w.value?(tt(),Te(Sp,{key:0,"block-id":w.value,title:E.value,plugin:Ci(e),onExternalJump:ct},null,8,["block-id","title","plugin"])):Ft("",!0),_.value?Ie((tt(),Te(Up,{key:1,visible:f.value&&v.value==="web",url:x.value,title:E.value,onExternalJump:ct},null,8,["visible","url","title"])),[[Ll,v.value==="web"]]):Ft("",!0)]),_:1},8,["visible","is-maximized","title"])],512),y.value&&p.value.length>0?(tt(),Te(sp,{key:0,slides:p.value,"current-active-page":h.value,onNavigate:Y,onRefresh:H},null,8,["slides","current-active-page"])):Ft("",!0)]))}}),ph=Le(fh,[["__scopeId","data-v-3a32bc1a"]]),hh={class:"spm-section spm-section--page"},mh={class:"spm-section-header"},gh={class:"spm-card-control"},vh={class:"spm-control-header"},bh={class:"spm-control-title-group"},yh={class:"spm-control-title"},wh={class:"spm-quick-chips"},kh=["onClick"],xh=["value"],_h={key:0,class:"spm-card-control"},Sh={class:"spm-control-header"},Ch={class:"spm-control-title-group"},$h={class:"spm-control-title"},Ih={class:"spm-quick-chips"},Ah=["onClick"],Eh=["value"],Th={class:"spm-card-control"},Mh={class:"spm-control-header"},Bh={class:"spm-control-title-group"},Dh={class:"spm-control-title"},Oh={key:0,class:"spm-note-status-box"},Ph=["title"],Lh={class:"spm-action-grid",style:{"margin-top":"6px"}},Rh={key:1,class:"spm-note-empty-box"},zh={class:"spm-card-control"},Nh={class:"spm-action-grid"},Fh=be({__name:"PageInspectorSection",props:{pageLayout:{},pageTransition:{},pageBackground:{},pageImage:{},pageNotes:{},pageIndex:{}},emits:["update:pageLayout","update:pageTransition","update:pageBackground","update:pageImage","addNoteBlock","locateNoteBlock","generateNotes","insertDividerAfter","deleteDivider"],setup(t,{emit:i}){const e=t,n=$t(()=>{if(!e.pageNotes)return"";const l=e.pageNotes.replace(/[\r\n]+/g," ").trim();return l.length>50?l.slice(0,50)+"...":l}),s=[{label:"默认",value:""},{label:"暗黑 #1e1e24",value:"#1e1e24"},{label:"极夜 #0f172a",value:"#0f172a"},{label:"极简白 #ffffff",value:"#ffffff"}],r=[{label:"默认封面",value:"https://cover.sli.dev"},{label:"清空配图",value:""}];return(l,o)=>(tt(),nt("div",hh,[g("div",mh,[g("span",null,"幻灯片页面设置"+St(t.pageIndex?` (第 ${t.pageIndex} 页)`:""),1)]),pt(Hl,{"model-value":t.pageLayout,onChange:o[0]||(o[0]=a=>l.$emit("update:pageLayout",a))},null,8,["model-value"]),pt(So,{"model-value":t.pageTransition,onChange:o[1]||(o[1]=a=>l.$emit("update:pageTransition",a))},null,8,["model-value"]),g("div",gh,[g("div",vh,[g("div",bh,[g("div",yh,[pt(wt,{name:"palette"}),o[12]||(o[12]=g("span",null,"页面背景 (Background)",-1))]),o[13]||(o[13]=g("span",{class:"spm-control-desc"},"设置当前页特定底色或壁纸",-1))])]),g("div",wh,[(tt(),nt(Gt,null,ye(s,a=>g("button",{key:a.value,class:Tt(["spm-chip",{active:t.pageBackground===a.value}]),onClick:c=>l.$emit("update:pageBackground",a.value)},St(a.label),11,kh)),64))]),g("input",{value:t.pageBackground,class:"spm-input",placeholder:"自定义颜色代码或资源路径",onInput:o[2]||(o[2]=a=>l.$emit("update:pageBackground",a.target.value)),onChange:o[3]||(o[3]=a=>l.$emit("update:pageBackground",a.target.value))},null,40,xh)]),t.pageLayout==="image-right"||t.pageLayout==="image-left"||t.pageImage?(tt(),nt("div",_h,[g("div",Sh,[g("div",Ch,[g("div",$h,[pt(wt,{name:"image"}),o[14]||(o[14]=g("span",null,"页面图片 (Image)",-1))]),o[15]||(o[15]=g("span",{class:"spm-control-desc"},"图文分栏或页面专属配图 URL / 资源路径",-1))])]),g("div",Ih,[(tt(),nt(Gt,null,ye(r,a=>g("button",{key:a.value,class:Tt(["spm-chip",{active:t.pageImage===a.value}]),onClick:c=>l.$emit("update:pageImage",a.value)},St(a.label),11,Ah)),64))]),g("input",{value:t.pageImage,class:"spm-input",placeholder:"网络图片 URL (如 https://cover.sli.dev) 或 assets/...",onInput:o[4]||(o[4]=a=>l.$emit("update:pageImage",a.target.value)),onChange:o[5]||(o[5]=a=>l.$emit("update:pageImage",a.target.value))},null,40,Eh)])):Ft("",!0),g("div",Th,[g("div",Mh,[g("div",Bh,[g("div",Dh,[pt(wt,{name:"presenter"}),o[16]||(o[16]=g("span",null,"演讲者提词 (Notes)",-1))]),o[17]||(o[17]=g("span",{class:"spm-control-desc"},"正文备注块驱动 · 仅演讲者视图可见",-1))]),g("button",{class:"spm-btn-text b3-tooltips b3-tooltips__w","aria-label":"AI 自动生成本页讲稿提示块",onClick:o[6]||(o[6]=a=>l.$emit("generateNotes"))},[pt(wt,{name:"sparkles"}),o[18]||(o[18]=g("span",null,"AI 讲稿",-1))])]),t.pageNotes?(tt(),nt("div",Oh,[o[21]||(o[21]=g("div",{class:"spm-note-status-badge"},[g("span",{class:"spm-badge-dot"}),g("span",null,"已配置正文讲稿")],-1)),g("div",{class:"spm-note-preview-text",title:t.pageNotes},St(n.value),9,Ph),g("div",Lh,[g("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"在正文编辑区定位并高亮此讲稿备注块",onClick:o[7]||(o[7]=a=>l.$emit("locateNoteBlock"))},[pt(wt,{name:"search"}),o[19]||(o[19]=g("span",null,"定位讲稿块",-1))]),g("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"在本页末尾追加新的讲稿提示块",onClick:o[8]||(o[8]=a=>l.$emit("addNoteBlock"))},[pt(wt,{name:"insert-below"}),o[20]||(o[20]=g("span",null,"追加讲稿块",-1))])])])):(tt(),nt("div",Rh,[o[23]||(o[23]=g("div",{class:"spm-note-empty-hint"},"本页暂无讲稿备注块",-1)),g("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s",style:{width:"100%","margin-top":"6px"},"aria-label":"在当前页末尾插入默认演讲备注提示块",onClick:o[9]||(o[9]=a=>l.$emit("addNoteBlock"))},[pt(wt,{name:"insert-below"}),o[22]||(o[22]=g("span",null,"添加讲稿备注块",-1))])]))]),g("div",zh,[o[26]||(o[26]=g("div",{class:"spm-control-header"},[g("div",{class:"spm-control-title-group"},[g("span",{class:"spm-control-title"},"分页快捷操作")])],-1)),g("div",Nh,[g("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"在此分页符之后插入新的空白分页",onClick:o[10]||(o[10]=a=>l.$emit("insertDividerAfter"))},[pt(wt,{name:"insert-below"}),o[24]||(o[24]=g("span",null,"插入新页",-1))]),g("button",{class:"spm-btn-action spm-btn-danger b3-tooltips b3-tooltips__s","aria-label":"彻底删除当前分页符（合并前后页面）",onClick:o[11]||(o[11]=a=>l.$emit("deleteDivider"))},[pt(wt,{name:"trash"}),o[25]||(o[25]=g("span",null,"删除此页",-1))])])])]))}}),jh=Le(Fh,[["__scopeId","data-v-4916b87e"]]),Hh={class:"spm-section spm-section--block"},Uh={class:"spm-card-control"},Wh={class:"spm-control-header"},Vh={class:"spm-control-title-group"},Kh={class:"spm-control-title"},qh=["aria-label"],Gh=["checked"],Zh={key:0,class:"spm-card-control"},Yh={class:"spm-control-header"},Jh={class:"spm-control-title-group"},Xh={class:"spm-control-title"},Qh={class:"spm-quick-chips"},tm={key:1,class:"spm-card-control"},em={class:"spm-control-header"},im={class:"spm-control-title-group"},nm={class:"spm-control-title"},sm={class:"spm-video-settings-grid",style:{display:"grid","grid-template-columns":"1fr 1fr",gap:"8px","margin-top":"8px"}},om={class:"spm-toggle-item",style:{display:"flex","align-items":"center","justify-content":"space-between",padding:"4px 6px",background:"rgba(125,125,125,0.06)","border-radius":"4px"}},rm=["aria-label"],lm=["checked"],am={class:"spm-toggle-item",style:{display:"flex","align-items":"center","justify-content":"space-between",padding:"4px 6px",background:"rgba(125,125,125,0.06)","border-radius":"4px"}},cm=["aria-label"],dm=["checked"],um={class:"spm-toggle-item",style:{display:"flex","align-items":"center","justify-content":"space-between",padding:"4px 6px",background:"rgba(125,125,125,0.06)","border-radius":"4px"}},fm=["aria-label"],pm=["checked"],hm={class:"spm-toggle-item",style:{display:"flex","align-items":"center","justify-content":"space-between",padding:"4px 6px",background:"rgba(125,125,125,0.06)","border-radius":"4px"}},mm=["aria-label"],gm=["checked"],vm={class:"spm-card-control"},bm={class:"spm-control-header"},ym={class:"spm-control-title-group"},wm={class:"spm-control-title"},km=["aria-label"],xm=["checked"],_m={key:0,class:"spm-quick-chips"},Sm=["onClick"],Cm={class:"spm-card-control"},$m={class:"spm-control-header"},Im={class:"spm-control-title-group"},Am={class:"spm-control-title"},Em=["aria-label"],Tm=["checked"],Mm={key:0,class:"spm-quick-chips"},Bm=["onClick"],Dm={key:1,class:"spm-motion-details",style:{display:"flex","flex-direction":"column",gap:"4px","margin-top":"4px"}},Om={style:{display:"flex",gap:"8px","justify-content":"space-between","font-size":"11px",opacity:"0.8"}},Pm={style:{display:"flex",gap:"6px"}},Lm=["value"],Rm=["value"],zm={key:2,class:"spm-card-control"},Nm={class:"spm-control-header"},Fm={class:"spm-control-title-group"},jm={class:"spm-control-title"},Hm={class:"spm-control-desc"},Um={class:"spm-segmented-group"},Wm=["onClick"],Vm={key:3,class:"spm-card-control"},Km={class:"spm-control-header"},qm={class:"spm-control-title-group"},Gm={class:"spm-control-title"},Zm={class:"spm-quick-chips"},Ym=["onClick"],Jm=["value"],Xm={key:4,class:"spm-card-control"},Qm={class:"spm-control-header"},tg={class:"spm-control-title-group"},eg={class:"spm-control-title"},ig={class:"spm-quick-chips"},ng=["onClick"],sg=["value"],og={class:"spm-card-control"},rg={class:"spm-action-grid"},lg=["aria-label"],ag=be({__name:"BlockInspectorSection",props:{elemClick:{},elemMotion:{},elemSlot:{},elemShikiLines:{},elemMaxHeight:{},isCodeBlock:{type:Boolean},isImage:{type:Boolean},isVideo:{type:Boolean},videoAutoplay:{type:Boolean},videoLoop:{type:Boolean},videoMuted:{type:Boolean},videoControls:{type:Boolean},hasBlockAttrs:{type:Boolean},isNote:{type:Boolean},imageRole:{},currentSlideLayout:{}},emits:["toggleNote","toggleElemClick","update:elemClick","update:elemMotion","update:elemSlot","update:elemShikiLines","update:elemMaxHeight","insertDividerBefore","insertDividerAfter","setTwoColsContrast","clearBlockAttrs","update:imageRole","toggleVideoAutoplay","toggleVideoLoop","toggleVideoMuted","toggleVideoControls"],setup(t,{emit:i}){const e=t,n=$t(()=>{const _=e.currentSlideLayout||"";return["col-1","col-2","col-3"].includes(e.elemSlot)?"three-cols-header":_}),s=$t(()=>{const _=n.value;return["two-cols","two-cols-header","three-cols-header"].includes(_)}),r=$t(()=>{const _=n.value;return _==="three-cols-header"?"三栏插槽归属 (Slot)":_==="two-cols-header"?"带表头双栏插槽 (Slot)":"多栏插槽归属 (Slot)"}),l=$t(()=>{const _=n.value;return _==="three-cols-header"?"在 three-cols-header 版式中的内容块位置":_==="two-cols-header"?"在 two-cols-header 版式中的内容块位置":_==="two-cols"?"在 two-cols 双栏版式中的归属":"在当前分栏版式中的内容块位置"}),o=$t(()=>{const _=n.value;return _==="three-cols-header"?[{value:"",label:"默认"},{value:"header",label:"表头"},{value:"col-1",label:"第 1 栏"},{value:"col-2",label:"第 2 栏"},{value:"col-3",label:"第 3 栏"}]:_==="two-cols-header"?[{value:"",label:"默认"},{value:"header",label:"表头"},{value:"left",label:"左栏"},{value:"right",label:"右栏"}]:_==="two-cols"?[{value:"",label:"默认 (左)"},{value:"right",label:"右栏"}]:[{value:"",label:"默认"},{value:"header",label:"表头"},{value:"left",label:"左栏"},{value:"right",label:"右栏"}]});function a(_){const C=e.elemSlot||"";return _?C===_||_==="col-1"&&C==="left"||_==="col-2"&&C==="center"||_==="col-3"&&C==="right"||_==="left"&&C==="col-1"||_==="right"&&(C==="col-2"||C==="col-3"):!C||C==="default"}const c=i,d=[{label:"上浮 (slide-up)",value:"slide-up"},{label:"淡入 (fade-in)",value:"fade-in"},{label:"下沉 (slide-down)",value:"slide-down"},{label:"左滑 (slide-left)",value:"slide-left"},{label:"右滑 (slide-right)",value:"slide-right"},{label:"缩放 (zoom-in)",value:"zoom-in"},{label:"弹性 (bounce)",value:"bounce"}],h=$t(()=>{if(!e.elemMotion||e.elemMotion.trim()===""||e.elemMotion.trim()==="none")return null;try{const _=JSON.parse(e.elemMotion);if(typeof _=="object"&&_!==null)return{preset:_.preset||_.type||"slide-up",duration:typeof _.duration=="number"?_.duration:0,delay:typeof _.delay=="number"?_.delay:0}}catch{}return{preset:e.elemMotion.trim(),duration:0,delay:0}}),m=$t(()=>!!h.value),p=$t(()=>{var _;return((_=h.value)==null?void 0:_.preset)||"slide-up"}),y=$t(()=>{var _;return((_=h.value)==null?void 0:_.duration)||0}),f=$t(()=>{var _;return((_=h.value)==null?void 0:_.delay)||0});function k(){m.value?c("update:elemMotion",""):c("update:elemMotion","slide-up")}function v(_){E(_,y.value,f.value)}function w(_){E(p.value,_,f.value)}function x(_){E(p.value,y.value,_)}function E(_,C,A){if(!_||_==="none"){c("update:elemMotion","");return}if(!C&&!A){c("update:elemMotion",_);return}const B={preset:_};C>0&&(B.duration=C),A>0&&(B.delay=A),c("update:elemMotion",JSON.stringify(B))}return(_,C)=>(tt(),nt("div",Hh,[C[53]||(C[53]=g("div",{class:"spm-section-header"},[g("span",null,"元素动效与排版")],-1)),g("div",Uh,[g("div",Wh,[g("div",Vh,[g("div",Kh,[pt(wt,{name:"presenter"}),C[22]||(C[22]=g("span",null,"设为讲稿备注 (slidev-note)",-1))]),C[23]||(C[23]=g("span",{class:"spm-control-desc"},"作为当前页演讲提词，不在幻灯片中渲染",-1))]),g("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":t.isNote?"取消讲稿备注":"设为讲稿备注"},[g("input",{type:"checkbox",checked:!!t.isNote,onChange:C[0]||(C[0]=A=>_.$emit("toggleNote"))},null,40,Gh),C[24]||(C[24]=g("span",{class:"spm-switch-slider"},null,-1))],8,qh)])]),t.isImage||t.imageRole?(tt(),nt("div",Zh,[g("div",Yh,[g("div",Jh,[g("div",Xh,[pt(wt,{name:"image"}),C[25]||(C[25]=g("span",null,"图片角色与分栏 (Image & Layout)",-1))]),C[26]||(C[26]=g("span",{class:"spm-control-desc"},"设为幻灯片背景图或图文分栏配图",-1))])]),g("div",Qh,[g("button",{class:Tt(["spm-chip",{active:!t.imageRole}]),onClick:C[1]||(C[1]=A=>_.$emit("update:imageRole",""))}," 普通内容 ",2),g("button",{class:Tt(["spm-chip",{active:t.imageRole==="background"}]),onClick:C[2]||(C[2]=A=>_.$emit("update:imageRole","background"))}," 🖼️ 背景图 ",2),g("button",{class:Tt(["spm-chip",{active:t.imageRole==="image-left"}]),onClick:C[3]||(C[3]=A=>_.$emit("update:imageRole","image-left"))}," 🎨 图左 ",2),g("button",{class:Tt(["spm-chip",{active:t.imageRole==="image-right"}]),onClick:C[4]||(C[4]=A=>_.$emit("update:imageRole","image-right"))}," 🖼️ 图右 ",2)])])):Ft("",!0),t.isVideo?(tt(),nt("div",tm,[g("div",em,[g("div",im,[g("div",nm,[pt(wt,{name:"video"}),C[27]||(C[27]=g("span",null,"视频播放设置 (Video Playback)",-1))]),C[28]||(C[28]=g("span",{class:"spm-control-desc"},"配置播放器控制条、自动播放与循环",-1))])]),g("div",sm,[g("div",om,[C[30]||(C[30]=g("span",{style:{"font-size":"11px"}},"🎛️ 控制条",-1)),g("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":t.videoControls?"关闭控制条":"开启控制条"},[g("input",{type:"checkbox",checked:!!t.videoControls,onChange:C[5]||(C[5]=A=>_.$emit("toggleVideoControls"))},null,40,lm),C[29]||(C[29]=g("span",{class:"spm-switch-slider"},null,-1))],8,rm)]),g("div",am,[C[32]||(C[32]=g("span",{style:{"font-size":"11px"}},"▶️ 自动播放",-1)),g("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":t.videoAutoplay?"关闭自动播放":"开启自动播放"},[g("input",{type:"checkbox",checked:!!t.videoAutoplay,onChange:C[6]||(C[6]=A=>_.$emit("toggleVideoAutoplay"))},null,40,dm),C[31]||(C[31]=g("span",{class:"spm-switch-slider"},null,-1))],8,cm)]),g("div",um,[C[34]||(C[34]=g("span",{style:{"font-size":"11px"}},"🔁 循环播放",-1)),g("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":t.videoLoop?"关闭循环播放":"开启循环播放"},[g("input",{type:"checkbox",checked:!!t.videoLoop,onChange:C[7]||(C[7]=A=>_.$emit("toggleVideoLoop"))},null,40,pm),C[33]||(C[33]=g("span",{class:"spm-switch-slider"},null,-1))],8,fm)]),g("div",hm,[C[36]||(C[36]=g("span",{style:{"font-size":"11px"}},"🔇 静音播放",-1)),g("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":t.videoMuted?"关闭静音":"开启静音"},[g("input",{type:"checkbox",checked:!!t.videoMuted,onChange:C[8]||(C[8]=A=>_.$emit("toggleVideoMuted"))},null,40,gm),C[35]||(C[35]=g("span",{class:"spm-switch-slider"},null,-1))],8,mm)])])])):Ft("",!0),g("div",vm,[g("div",bm,[g("div",ym,[g("div",wm,[pt(wt,{name:"step"}),C[37]||(C[37]=g("span",null,"逐步呈现 (v-click)",-1))]),C[38]||(C[38]=g("span",{class:"spm-control-desc"},"放映时按步长逐个呈现",-1))]),g("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":t.elemClick?"关闭逐步呈现":"开启逐步呈现 (+1)"},[g("input",{type:"checkbox",checked:!!t.elemClick,onChange:C[9]||(C[9]=A=>_.$emit("toggleElemClick"))},null,40,xm),C[39]||(C[39]=g("span",{class:"spm-switch-slider"},null,-1))],8,km)]),t.elemClick?(tt(),nt("div",_m,[(tt(),nt(Gt,null,ye(["+1","1","2","hide"],A=>g("button",{key:A,class:Tt(["spm-chip",{active:t.elemClick===A}]),onClick:B=>_.$emit("update:elemClick",A)},St(A==="+1"?"顺延 (+1)":A==="hide"?"隐藏 (hide)":"第 "+A+" 步"),11,Sm)),64))])):Ft("",!0)]),g("div",Cm,[g("div",$m,[g("div",Im,[g("div",Am,[pt(wt,{name:"motion"}),C[40]||(C[40]=g("span",null,"入场微动效 (v-motion)",-1))]),C[41]||(C[41]=g("span",{class:"spm-control-desc"},"为当前块添加平滑位移与渐入动画",-1))]),g("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":m.value?"关闭微动效":"开启微动效 (slide-up)"},[g("input",{type:"checkbox",checked:m.value,onChange:k},null,40,Tm),C[42]||(C[42]=g("span",{class:"spm-switch-slider"},null,-1))],8,Em)]),m.value?(tt(),nt("div",Mm,[(tt(),nt(Gt,null,ye(d,A=>g("button",{key:A.value,class:Tt(["spm-chip",{active:p.value===A.value}]),onClick:B=>v(A.value)},St(A.label),11,Bm)),64))])):Ft("",!0),m.value?(tt(),nt("div",Dm,[g("div",Om,[g("span",null,"时长: "+St(y.value?y.value+"ms":"默认 (450ms)"),1),g("span",null,"延迟: "+St(f.value?f.value+"ms":"0ms"),1)]),g("div",Pm,[g("select",{class:"spm-select",style:{flex:"1"},value:y.value,onChange:C[10]||(C[10]=A=>w(Number(A.target.value)))},[...C[43]||(C[43]=[g("option",{value:0},"默认耗时",-1),g("option",{value:200},"极速 (200ms)",-1),g("option",{value:350},"较快 (350ms)",-1),g("option",{value:500},"平滑 (500ms)",-1),g("option",{value:800},"缓慢 (800ms)",-1)])],40,Lm),g("select",{class:"spm-select",style:{flex:"1"},value:f.value,onChange:C[11]||(C[11]=A=>x(Number(A.target.value)))},[...C[44]||(C[44]=[g("option",{value:0},"无延迟",-1),g("option",{value:150},"延迟 150ms",-1),g("option",{value:300},"延迟 300ms",-1),g("option",{value:500},"延迟 500ms",-1)])],40,Rm)])])):Ft("",!0)]),s.value||t.elemSlot?(tt(),nt("div",zm,[g("div",Nm,[g("div",Fm,[g("div",jm,[pt(wt,{name:"columns"}),g("span",null,St(r.value),1)]),g("span",Hm,St(l.value),1)])]),g("div",Um,[(tt(!0),nt(Gt,null,ye(o.value,A=>(tt(),nt("button",{key:A.value,class:Tt(["spm-segmented-item",{active:a(A.value)}]),onClick:B=>_.$emit("update:elemSlot",A.value)},St(A.label),11,Wm))),128))])])):Ft("",!0),t.isCodeBlock?(tt(),nt("div",Vm,[g("div",Km,[g("div",qm,[g("div",Gm,[pt(wt,{name:"code"}),C[45]||(C[45]=g("span",null,"代码逐行聚光 (Shiki)",-1))]),C[46]||(C[46]=g("span",{class:"spm-control-desc"},"翻页时动态聚光高亮特定行",-1))])]),g("div",Zm,[(tt(),nt(Gt,null,ye(["1-3","all","1|2|3","2-5"],A=>g("button",{key:A,class:Tt(["spm-chip",{active:t.elemShikiLines===A}]),onClick:B=>_.$emit("update:elemShikiLines",A)},St(A),11,Ym)),64)),t.elemShikiLines?(tt(),nt("button",{key:0,class:"spm-chip spm-chip-clear",onClick:C[12]||(C[12]=A=>_.$emit("update:elemShikiLines",""))}," 清空 ")):Ft("",!0)]),g("input",{value:t.elemShikiLines,class:"spm-input",placeholder:"自定义高亮区间，如 1-3|5|all",onInput:C[13]||(C[13]=A=>_.$emit("update:elemShikiLines",A.target.value)),onChange:C[14]||(C[14]=A=>_.$emit("update:elemShikiLines",A.target.value))},null,40,Jm)])):Ft("",!0),t.isCodeBlock?(tt(),nt("div",Xm,[g("div",Qm,[g("div",tg,[g("div",eg,[pt(wt,{name:"code"}),C[47]||(C[47]=g("span",null,"代码块限高 (Max Height)",-1))]),C[48]||(C[48]=g("span",{class:"spm-control-desc"},"超出限高自动竖向滚动，弱提示滚动条",-1))])]),g("div",ig,[(tt(),nt(Gt,null,ye(["240px","320px","400px","50vh"],A=>g("button",{key:A,class:Tt(["spm-chip",{active:t.elemMaxHeight===A}]),onClick:B=>_.$emit("update:elemMaxHeight",A)},St(A),11,ng)),64)),t.elemMaxHeight?(tt(),nt("button",{key:0,class:"spm-chip spm-chip-clear",onClick:C[15]||(C[15]=A=>_.$emit("update:elemMaxHeight",""))}," 自适应 ")):Ft("",!0)]),g("input",{value:t.elemMaxHeight,class:"spm-input",placeholder:"自适应高度，或输入 350px、50vh",onInput:C[16]||(C[16]=A=>_.$emit("update:elemMaxHeight",A.target.value)),onChange:C[17]||(C[17]=A=>_.$emit("update:elemMaxHeight",A.target.value))},null,40,sg)])):Ft("",!0),g("div",og,[C[52]||(C[52]=g("div",{class:"spm-control-header"},[g("div",{class:"spm-control-title-group"},[g("span",{class:"spm-control-title"},"快捷操作")])],-1)),g("div",rg,[g("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"在当前块上方插入幻灯片分页线 (---)",onClick:C[18]||(C[18]=A=>_.$emit("insertDividerBefore"))},[pt(wt,{name:"insert-above"}),C[49]||(C[49]=g("span",null,"上方分页",-1))]),g("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"在当前块下方插入幻灯片分页线 (---)",onClick:C[19]||(C[19]=A=>_.$emit("insertDividerAfter"))},[pt(wt,{name:"insert-below"}),C[50]||(C[50]=g("span",null,"下方分页",-1))]),g("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":n.value==="three-cols-header"?"将当前块属性设为三栏第1栏归属 (slot: col-1)":"将当前块属性设为双栏左侧归属 (slot: left)",onClick:C[20]||(C[20]=A=>_.$emit("setTwoColsContrast"))},[pt(wt,{name:"columns"}),g("span",null,St(n.value==="three-cols-header"?"设为第1栏":"设为双栏"),1)],8,lg),t.hasBlockAttrs?(tt(),nt("button",{key:0,class:"spm-btn-action spm-btn-danger b3-tooltips b3-tooltips__s","aria-label":"一键移除本块所有 custom-slidev 属性",onClick:C[21]||(C[21]=A=>_.$emit("clearBlockAttrs"))},[pt(wt,{name:"broom"}),C[51]||(C[51]=g("span",null,"清除属性",-1))])):Ft("",!0)])])]))}}),cg={class:"spm-section spm-section--doc"},dg={class:"spm-card-control"},ug={class:"spm-control-header"},fg={class:"spm-control-title-group"},pg={class:"spm-control-title"},hg={class:"spm-segmented-group"},mg=["aria-label","onClick"],gg={class:"spm-card-control"},vg={class:"spm-control-header"},bg={class:"spm-control-title-group"},yg={class:"spm-control-title"},wg={class:"spm-segmented-group"},kg={class:"spm-card-control"},xg={class:"spm-control-header"},_g={class:"spm-control-title-group"},Sg={class:"spm-control-title"},Cg={class:"spm-card-control"},$g={class:"spm-control-header"},Ig={class:"spm-control-title-group"},Ag={class:"spm-control-title"},Eg=["aria-label"],Tg=["checked"],Mg={key:0,class:"spm-control-body",style:{"margin-top":"8px"}},Bg=["value"],Dg={class:"spm-card-control"},Og={class:"spm-action-grid"},Pg=be({__name:"DocInspectorSection",props:{docTheme:{},docAspectRatio:{},docDefaultTransition:{}},emits:["update:docTheme","update:docAspectRatio","update:docDefaultTransition","openBottomPreview","openPresenter","aiAutoSplit","exportHtml","exportPdf"],setup(t){const i=Qe("plugin"),e=$i,n=[{value:"default",label:"默认 default",desc:"官方默认科技风：现代无衬线排版与清新代码语法高亮，通用汇报与技术分享首选"},{value:"seriph",label:"优雅 seriph",desc:"典雅学术衬线风：书卷学术质感、衬线字体典雅庄重，适合学术论文、人文讲座与深度阅读"},{value:"apple-basic",label:"极简 apple",desc:"苹果发布会极简风：大字号、高对比度与极致留白，适合产品发布、方案演讲与纯粹视觉呈现"}];function s(o){Vi({enableWebServeJump:o}),i&&typeof i.saveGlobalSettings=="function"&&i.saveGlobalSettings({enableWebServeJump:o})}function r(o){Vi({webServeUrl:o})}function l(o){Vi({webServeUrl:o}),i&&typeof i.saveGlobalSettings=="function"&&i.saveGlobalSettings({webServeUrl:o})}return(o,a)=>(tt(),nt("div",cg,[a[30]||(a[30]=g("div",{class:"spm-section-header"},[g("span",null,"全局演示配置")],-1)),g("div",dg,[g("div",ug,[g("div",fg,[g("div",pg,[pt(wt,{name:"palette"}),a[14]||(a[14]=g("span",null,"幻灯片主题 (Theme)",-1))]),a[15]||(a[15]=g("span",{class:"spm-control-desc"},"全局 Slidev 视觉设计范式",-1))])]),g("div",hg,[(tt(),nt(Gt,null,ye(n,c=>g("button",{key:c.value,class:Tt(["spm-segmented-item b3-tooltips b3-tooltips__s",{active:t.docTheme===c.value}]),"aria-label":c.desc,onClick:d=>o.$emit("update:docTheme",c.value)},St(c.label),11,mg)),64))])]),g("div",gg,[g("div",vg,[g("div",bg,[g("div",yg,[pt(wt,{name:"ratio"}),a[16]||(a[16]=g("span",null,"画幅比例 (Aspect Ratio)",-1))]),a[17]||(a[17]=g("span",{class:"spm-control-desc"},"演讲屏幕投影宽高比",-1))])]),g("div",wg,[g("button",{class:Tt(["spm-segmented-item",{active:t.docAspectRatio==="16/9"}]),onClick:a[0]||(a[0]=c=>o.$emit("update:docAspectRatio","16/9"))}," 16 : 9 (宽屏) ",2),g("button",{class:Tt(["spm-segmented-item",{active:t.docAspectRatio==="4/3"}]),onClick:a[1]||(a[1]=c=>o.$emit("update:docAspectRatio","4/3"))}," 4 : 3 (标屏) ",2),g("button",{class:Tt(["spm-segmented-item",{active:t.docAspectRatio==="16/10"}]),onClick:a[2]||(a[2]=c=>o.$emit("update:docAspectRatio","16/10"))}," 16 : 10 ",2)])]),g("div",kg,[g("div",xg,[g("div",_g,[g("div",Sg,[pt(wt,{name:"transition"}),a[18]||(a[18]=g("span",null,"全局默认转场",-1))]),a[19]||(a[19]=g("span",{class:"spm-control-desc"},"页面切换过渡动效（未单设转场的页面将继承此动效）",-1))])]),pt(So,{"model-value":t.docDefaultTransition,"hide-header":!0,onChange:a[3]||(a[3]=c=>o.$emit("update:docDefaultTransition",c))},null,8,["model-value"])]),g("div",Cg,[g("div",$g,[g("div",Ig,[g("div",Ag,[pt(wt,{name:"external-link"}),a[20]||(a[20]=g("span",null,"本地网络伺服预览 (Web Serve)",-1))]),a[21]||(a[21]=g("span",{class:"spm-control-desc"},"点击文档/块链接以 Webview 抽屉呈现，支持外跳",-1))]),g("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":Ci(e).enableWebServeJump?"关闭本地网络伺服预览":"开启本地网络伺服预览"},[g("input",{type:"checkbox",checked:Ci(e).enableWebServeJump,onChange:a[4]||(a[4]=c=>s(c.target.checked))},null,40,Tg),a[22]||(a[22]=g("span",{class:"spm-switch-slider"},null,-1))],8,Eg)]),Ci(e).enableWebServeJump?(tt(),nt("div",Mg,[g("input",{value:Ci(e).webServeUrl,class:"spm-input",placeholder:"http://127.0.0.1:6806",spellcheck:"false",onKeydown:a[5]||(a[5]=Ee(()=>{},["stop"])),onKeyup:a[6]||(a[6]=Ee(()=>{},["stop"])),onInput:a[7]||(a[7]=c=>r(c.target.value)),onChange:a[8]||(a[8]=c=>l(c.target.value))},null,40,Bg),a[23]||(a[23]=g("span",{class:"spm-control-desc",style:{display:"block","margin-top":"4px","font-size":"11px",opacity:"0.8"}}," 默认伺服地址为 http://127.0.0.1:6806。开启后点击块链接将在 Webview 抽屉中打开，点击抽屉顶部『外跳』可在外部浏览器打开 ",-1))])):Ft("",!0)]),g("div",Dg,[a[29]||(a[29]=g("div",{class:"spm-control-header"},[g("div",{class:"spm-control-title-group"},[g("span",{class:"spm-control-title"},"演示全局操作")])],-1)),g("div",Og,[g("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"在当前文档下方开启分屏同步预览 (Alt+P)",onClick:a[9]||(a[9]=c=>o.$emit("openBottomPreview"))},[pt(wt,{name:"split-preview"}),a[24]||(a[24]=g("span",null,"分屏预览",-1))]),g("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"打开双屏演讲者控制台视窗 (Alt+M)",onClick:a[10]||(a[10]=c=>o.$emit("openPresenter"))},[pt(wt,{name:"presenter"}),a[25]||(a[25]=g("span",null,"演讲者视图",-1))]),g("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"智能分析长文本结构并给出大纲分页插入建议",onClick:a[11]||(a[11]=c=>o.$emit("aiAutoSplit"))},[pt(wt,{name:"sparkles"}),a[26]||(a[26]=g("span",null,"AI 智能分页",-1))]),g("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"打包导出离线单文件 HTML 幻灯片",onClick:a[12]||(a[12]=c=>o.$emit("exportHtml"))},[pt(wt,{name:"export-html"}),a[27]||(a[27]=g("span",null,"导出 HTML",-1))]),g("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"打印生成 16:9 高清演示 PDF 讲义",onClick:a[13]||(a[13]=c=>o.$emit("exportPdf"))},[pt(wt,{name:"export-pdf"}),a[28]||(a[28]=g("span",null,"导出 PDF",-1))])])])]))}});var Rn=typeof globalThis<"u"?globalThis:typeof window<"u"?window:typeof global<"u"?global:typeof self<"u"?self:{};function Lg(t){return t&&t.__esModule&&Object.prototype.hasOwnProperty.call(t,"default")?t.default:t}function zn(t){throw new Error('Could not dynamically require "'+t+'". Please configure the dynamicRequireTargets or/and ignoreDynamicRequires option of @rollup/plugin-commonjs appropriately for this require call to work.')}var Ms={exports:{}};/*!

JSZip v3.10.1 - A JavaScript class for generating and reading zip files
<http://stuartk.com/jszip>

(c) 2009-2016 Stuart Knightley <stuart [at] stuartk.com>
Dual licenced under the MIT license or GPLv3. See https://raw.github.com/Stuk/jszip/main/LICENSE.markdown.

JSZip uses the library pako released under the MIT license :
https://github.com/nodeca/pako/blob/main/LICENSE
*/var vr;function Rg(){return vr||(vr=1,(function(t,i){(function(e){t.exports=e()})(function(){return(function e(n,s,r){function l(c,d){if(!s[c]){if(!n[c]){var h=typeof zn=="function"&&zn;if(!d&&h)return h(c,!0);if(o)return o(c,!0);var m=new Error("Cannot find module '"+c+"'");throw m.code="MODULE_NOT_FOUND",m}var p=s[c]={exports:{}};n[c][0].call(p.exports,function(y){var f=n[c][1][y];return l(f||y)},p,p.exports,e,n,s,r)}return s[c].exports}for(var o=typeof zn=="function"&&zn,a=0;a<r.length;a++)l(r[a]);return l})({1:[function(e,n,s){var r=e("./utils"),l=e("./support"),o="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";s.encode=function(a){for(var c,d,h,m,p,y,f,k=[],v=0,w=a.length,x=w,E=r.getTypeOf(a)!=="string";v<a.length;)x=w-v,h=E?(c=a[v++],d=v<w?a[v++]:0,v<w?a[v++]:0):(c=a.charCodeAt(v++),d=v<w?a.charCodeAt(v++):0,v<w?a.charCodeAt(v++):0),m=c>>2,p=(3&c)<<4|d>>4,y=1<x?(15&d)<<2|h>>6:64,f=2<x?63&h:64,k.push(o.charAt(m)+o.charAt(p)+o.charAt(y)+o.charAt(f));return k.join("")},s.decode=function(a){var c,d,h,m,p,y,f=0,k=0,v="data:";if(a.substr(0,v.length)===v)throw new Error("Invalid base64 input, it looks like a data url.");var w,x=3*(a=a.replace(/[^A-Za-z0-9+/=]/g,"")).length/4;if(a.charAt(a.length-1)===o.charAt(64)&&x--,a.charAt(a.length-2)===o.charAt(64)&&x--,x%1!=0)throw new Error("Invalid base64 input, bad content length.");for(w=l.uint8array?new Uint8Array(0|x):new Array(0|x);f<a.length;)c=o.indexOf(a.charAt(f++))<<2|(m=o.indexOf(a.charAt(f++)))>>4,d=(15&m)<<4|(p=o.indexOf(a.charAt(f++)))>>2,h=(3&p)<<6|(y=o.indexOf(a.charAt(f++))),w[k++]=c,p!==64&&(w[k++]=d),y!==64&&(w[k++]=h);return w}},{"./support":30,"./utils":32}],2:[function(e,n,s){var r=e("./external"),l=e("./stream/DataWorker"),o=e("./stream/Crc32Probe"),a=e("./stream/DataLengthProbe");function c(d,h,m,p,y){this.compressedSize=d,this.uncompressedSize=h,this.crc32=m,this.compression=p,this.compressedContent=y}c.prototype={getContentWorker:function(){var d=new l(r.Promise.resolve(this.compressedContent)).pipe(this.compression.uncompressWorker()).pipe(new a("data_length")),h=this;return d.on("end",function(){if(this.streamInfo.data_length!==h.uncompressedSize)throw new Error("Bug : uncompressed data size mismatch")}),d},getCompressedWorker:function(){return new l(r.Promise.resolve(this.compressedContent)).withStreamInfo("compressedSize",this.compressedSize).withStreamInfo("uncompressedSize",this.uncompressedSize).withStreamInfo("crc32",this.crc32).withStreamInfo("compression",this.compression)}},c.createWorkerFrom=function(d,h,m){return d.pipe(new o).pipe(new a("uncompressedSize")).pipe(h.compressWorker(m)).pipe(new a("compressedSize")).withStreamInfo("compression",h)},n.exports=c},{"./external":6,"./stream/Crc32Probe":25,"./stream/DataLengthProbe":26,"./stream/DataWorker":27}],3:[function(e,n,s){var r=e("./stream/GenericWorker");s.STORE={magic:"\0\0",compressWorker:function(){return new r("STORE compression")},uncompressWorker:function(){return new r("STORE decompression")}},s.DEFLATE=e("./flate")},{"./flate":7,"./stream/GenericWorker":28}],4:[function(e,n,s){var r=e("./utils"),l=(function(){for(var o,a=[],c=0;c<256;c++){o=c;for(var d=0;d<8;d++)o=1&o?3988292384^o>>>1:o>>>1;a[c]=o}return a})();n.exports=function(o,a){return o!==void 0&&o.length?r.getTypeOf(o)!=="string"?(function(c,d,h,m){var p=l,y=m+h;c^=-1;for(var f=m;f<y;f++)c=c>>>8^p[255&(c^d[f])];return-1^c})(0|a,o,o.length,0):(function(c,d,h,m){var p=l,y=m+h;c^=-1;for(var f=m;f<y;f++)c=c>>>8^p[255&(c^d.charCodeAt(f))];return-1^c})(0|a,o,o.length,0):0}},{"./utils":32}],5:[function(e,n,s){s.base64=!1,s.binary=!1,s.dir=!1,s.createFolders=!0,s.date=null,s.compression=null,s.compressionOptions=null,s.comment=null,s.unixPermissions=null,s.dosPermissions=null},{}],6:[function(e,n,s){var r=null;r=typeof Promise<"u"?Promise:e("lie"),n.exports={Promise:r}},{lie:37}],7:[function(e,n,s){var r=typeof Uint8Array<"u"&&typeof Uint16Array<"u"&&typeof Uint32Array<"u",l=e("pako"),o=e("./utils"),a=e("./stream/GenericWorker"),c=r?"uint8array":"array";function d(h,m){a.call(this,"FlateWorker/"+h),this._pako=null,this._pakoAction=h,this._pakoOptions=m,this.meta={}}s.magic="\b\0",o.inherits(d,a),d.prototype.processChunk=function(h){this.meta=h.meta,this._pako===null&&this._createPako(),this._pako.push(o.transformTo(c,h.data),!1)},d.prototype.flush=function(){a.prototype.flush.call(this),this._pako===null&&this._createPako(),this._pako.push([],!0)},d.prototype.cleanUp=function(){a.prototype.cleanUp.call(this),this._pako=null},d.prototype._createPako=function(){this._pako=new l[this._pakoAction]({raw:!0,level:this._pakoOptions.level||-1});var h=this;this._pako.onData=function(m){h.push({data:m,meta:h.meta})}},s.compressWorker=function(h){return new d("Deflate",h)},s.uncompressWorker=function(){return new d("Inflate",{})}},{"./stream/GenericWorker":28,"./utils":32,pako:38}],8:[function(e,n,s){function r(p,y){var f,k="";for(f=0;f<y;f++)k+=String.fromCharCode(255&p),p>>>=8;return k}function l(p,y,f,k,v,w){var x,E,_=p.file,C=p.compression,A=w!==c.utf8encode,B=o.transformTo("string",w(_.name)),P=o.transformTo("string",c.utf8encode(_.name)),R=_.comment,X=o.transformTo("string",w(R)),S=o.transformTo("string",c.utf8encode(R)),G=P.length!==_.name.length,b=S.length!==R.length,U="",it="",j="",st=_.dir,K=_.date,Y={crc32:0,compressedSize:0,uncompressedSize:0};y&&!f||(Y.crc32=p.crc32,Y.compressedSize=p.compressedSize,Y.uncompressedSize=p.uncompressedSize);var H=0;y&&(H|=8),A||!G&&!b||(H|=2048);var L=0,ct=0;st&&(L|=16),v==="UNIX"?(ct=798,L|=(function(ot,J){var mt=ot;return ot||(mt=J?16893:33204),(65535&mt)<<16})(_.unixPermissions,st)):(ct=20,L|=(function(ot){return 63&(ot||0)})(_.dosPermissions)),x=K.getUTCHours(),x<<=6,x|=K.getUTCMinutes(),x<<=5,x|=K.getUTCSeconds()/2,E=K.getUTCFullYear()-1980,E<<=4,E|=K.getUTCMonth()+1,E<<=5,E|=K.getUTCDate(),G&&(it=r(1,1)+r(d(B),4)+P,U+="up"+r(it.length,2)+it),b&&(j=r(1,1)+r(d(X),4)+S,U+="uc"+r(j.length,2)+j);var rt="";return rt+=`
\0`,rt+=r(H,2),rt+=C.magic,rt+=r(x,2),rt+=r(E,2),rt+=r(Y.crc32,4),rt+=r(Y.compressedSize,4),rt+=r(Y.uncompressedSize,4),rt+=r(B.length,2),rt+=r(U.length,2),{fileRecord:h.LOCAL_FILE_HEADER+rt+B+U,dirRecord:h.CENTRAL_FILE_HEADER+r(ct,2)+rt+r(X.length,2)+"\0\0\0\0"+r(L,4)+r(k,4)+B+U+X}}var o=e("../utils"),a=e("../stream/GenericWorker"),c=e("../utf8"),d=e("../crc32"),h=e("../signature");function m(p,y,f,k){a.call(this,"ZipFileWorker"),this.bytesWritten=0,this.zipComment=y,this.zipPlatform=f,this.encodeFileName=k,this.streamFiles=p,this.accumulate=!1,this.contentBuffer=[],this.dirRecords=[],this.currentSourceOffset=0,this.entriesCount=0,this.currentFile=null,this._sources=[]}o.inherits(m,a),m.prototype.push=function(p){var y=p.meta.percent||0,f=this.entriesCount,k=this._sources.length;this.accumulate?this.contentBuffer.push(p):(this.bytesWritten+=p.data.length,a.prototype.push.call(this,{data:p.data,meta:{currentFile:this.currentFile,percent:f?(y+100*(f-k-1))/f:100}}))},m.prototype.openedSource=function(p){this.currentSourceOffset=this.bytesWritten,this.currentFile=p.file.name;var y=this.streamFiles&&!p.file.dir;if(y){var f=l(p,y,!1,this.currentSourceOffset,this.zipPlatform,this.encodeFileName);this.push({data:f.fileRecord,meta:{percent:0}})}else this.accumulate=!0},m.prototype.closedSource=function(p){this.accumulate=!1;var y=this.streamFiles&&!p.file.dir,f=l(p,y,!0,this.currentSourceOffset,this.zipPlatform,this.encodeFileName);if(this.dirRecords.push(f.dirRecord),y)this.push({data:(function(k){return h.DATA_DESCRIPTOR+r(k.crc32,4)+r(k.compressedSize,4)+r(k.uncompressedSize,4)})(p),meta:{percent:100}});else for(this.push({data:f.fileRecord,meta:{percent:0}});this.contentBuffer.length;)this.push(this.contentBuffer.shift());this.currentFile=null},m.prototype.flush=function(){for(var p=this.bytesWritten,y=0;y<this.dirRecords.length;y++)this.push({data:this.dirRecords[y],meta:{percent:100}});var f=this.bytesWritten-p,k=(function(v,w,x,E,_){var C=o.transformTo("string",_(E));return h.CENTRAL_DIRECTORY_END+"\0\0\0\0"+r(v,2)+r(v,2)+r(w,4)+r(x,4)+r(C.length,2)+C})(this.dirRecords.length,f,p,this.zipComment,this.encodeFileName);this.push({data:k,meta:{percent:100}})},m.prototype.prepareNextSource=function(){this.previous=this._sources.shift(),this.openedSource(this.previous.streamInfo),this.isPaused?this.previous.pause():this.previous.resume()},m.prototype.registerPrevious=function(p){this._sources.push(p);var y=this;return p.on("data",function(f){y.processChunk(f)}),p.on("end",function(){y.closedSource(y.previous.streamInfo),y._sources.length?y.prepareNextSource():y.end()}),p.on("error",function(f){y.error(f)}),this},m.prototype.resume=function(){return!!a.prototype.resume.call(this)&&(!this.previous&&this._sources.length?(this.prepareNextSource(),!0):this.previous||this._sources.length||this.generatedError?void 0:(this.end(),!0))},m.prototype.error=function(p){var y=this._sources;if(!a.prototype.error.call(this,p))return!1;for(var f=0;f<y.length;f++)try{y[f].error(p)}catch{}return!0},m.prototype.lock=function(){a.prototype.lock.call(this);for(var p=this._sources,y=0;y<p.length;y++)p[y].lock()},n.exports=m},{"../crc32":4,"../signature":23,"../stream/GenericWorker":28,"../utf8":31,"../utils":32}],9:[function(e,n,s){var r=e("../compressions"),l=e("./ZipFileWorker");s.generateWorker=function(o,a,c){var d=new l(a.streamFiles,c,a.platform,a.encodeFileName),h=0;try{o.forEach(function(m,p){h++;var y=(function(w,x){var E=w||x,_=r[E];if(!_)throw new Error(E+" is not a valid compression method !");return _})(p.options.compression,a.compression),f=p.options.compressionOptions||a.compressionOptions||{},k=p.dir,v=p.date;p._compressWorker(y,f).withStreamInfo("file",{name:m,dir:k,date:v,comment:p.comment||"",unixPermissions:p.unixPermissions,dosPermissions:p.dosPermissions}).pipe(d)}),d.entriesCount=h}catch(m){d.error(m)}return d}},{"../compressions":3,"./ZipFileWorker":8}],10:[function(e,n,s){function r(){if(!(this instanceof r))return new r;if(arguments.length)throw new Error("The constructor with parameters has been removed in JSZip 3.0, please check the upgrade guide.");this.files=Object.create(null),this.comment=null,this.root="",this.clone=function(){var l=new r;for(var o in this)typeof this[o]!="function"&&(l[o]=this[o]);return l}}(r.prototype=e("./object")).loadAsync=e("./load"),r.support=e("./support"),r.defaults=e("./defaults"),r.version="3.10.1",r.loadAsync=function(l,o){return new r().loadAsync(l,o)},r.external=e("./external"),n.exports=r},{"./defaults":5,"./external":6,"./load":11,"./object":15,"./support":30}],11:[function(e,n,s){var r=e("./utils"),l=e("./external"),o=e("./utf8"),a=e("./zipEntries"),c=e("./stream/Crc32Probe"),d=e("./nodejsUtils");function h(m){return new l.Promise(function(p,y){var f=m.decompressed.getContentWorker().pipe(new c);f.on("error",function(k){y(k)}).on("end",function(){f.streamInfo.crc32!==m.decompressed.crc32?y(new Error("Corrupted zip : CRC32 mismatch")):p()}).resume()})}n.exports=function(m,p){var y=this;return p=r.extend(p||{},{base64:!1,checkCRC32:!1,optimizedBinaryString:!1,createFolders:!1,decodeFileName:o.utf8decode}),d.isNode&&d.isStream(m)?l.Promise.reject(new Error("JSZip can't accept a stream when loading a zip file.")):r.prepareContent("the loaded zip file",m,!0,p.optimizedBinaryString,p.base64).then(function(f){var k=new a(p);return k.load(f),k}).then(function(f){var k=[l.Promise.resolve(f)],v=f.files;if(p.checkCRC32)for(var w=0;w<v.length;w++)k.push(h(v[w]));return l.Promise.all(k)}).then(function(f){for(var k=f.shift(),v=k.files,w=0;w<v.length;w++){var x=v[w],E=x.fileNameStr,_=r.resolve(x.fileNameStr);y.file(_,x.decompressed,{binary:!0,optimizedBinaryString:!0,date:x.date,dir:x.dir,comment:x.fileCommentStr.length?x.fileCommentStr:null,unixPermissions:x.unixPermissions,dosPermissions:x.dosPermissions,createFolders:p.createFolders}),x.dir||(y.file(_).unsafeOriginalName=E)}return k.zipComment.length&&(y.comment=k.zipComment),y})}},{"./external":6,"./nodejsUtils":14,"./stream/Crc32Probe":25,"./utf8":31,"./utils":32,"./zipEntries":33}],12:[function(e,n,s){var r=e("../utils"),l=e("../stream/GenericWorker");function o(a,c){l.call(this,"Nodejs stream input adapter for "+a),this._upstreamEnded=!1,this._bindStream(c)}r.inherits(o,l),o.prototype._bindStream=function(a){var c=this;(this._stream=a).pause(),a.on("data",function(d){c.push({data:d,meta:{percent:0}})}).on("error",function(d){c.isPaused?this.generatedError=d:c.error(d)}).on("end",function(){c.isPaused?c._upstreamEnded=!0:c.end()})},o.prototype.pause=function(){return!!l.prototype.pause.call(this)&&(this._stream.pause(),!0)},o.prototype.resume=function(){return!!l.prototype.resume.call(this)&&(this._upstreamEnded?this.end():this._stream.resume(),!0)},n.exports=o},{"../stream/GenericWorker":28,"../utils":32}],13:[function(e,n,s){var r=e("readable-stream").Readable;function l(o,a,c){r.call(this,a),this._helper=o;var d=this;o.on("data",function(h,m){d.push(h)||d._helper.pause(),c&&c(m)}).on("error",function(h){d.emit("error",h)}).on("end",function(){d.push(null)})}e("../utils").inherits(l,r),l.prototype._read=function(){this._helper.resume()},n.exports=l},{"../utils":32,"readable-stream":16}],14:[function(e,n,s){n.exports={isNode:typeof Buffer<"u",newBufferFrom:function(r,l){if(Buffer.from&&Buffer.from!==Uint8Array.from)return Buffer.from(r,l);if(typeof r=="number")throw new Error('The "data" argument must not be a number');return new Buffer(r,l)},allocBuffer:function(r){if(Buffer.alloc)return Buffer.alloc(r);var l=new Buffer(r);return l.fill(0),l},isBuffer:function(r){return Buffer.isBuffer(r)},isStream:function(r){return r&&typeof r.on=="function"&&typeof r.pause=="function"&&typeof r.resume=="function"}}},{}],15:[function(e,n,s){function r(_,C,A){var B,P=o.getTypeOf(C),R=o.extend(A||{},d);R.date=R.date||new Date,R.compression!==null&&(R.compression=R.compression.toUpperCase()),typeof R.unixPermissions=="string"&&(R.unixPermissions=parseInt(R.unixPermissions,8)),R.unixPermissions&&16384&R.unixPermissions&&(R.dir=!0),R.dosPermissions&&16&R.dosPermissions&&(R.dir=!0),R.dir&&(_=v(_)),R.createFolders&&(B=k(_))&&w.call(this,B,!0);var X=P==="string"&&R.binary===!1&&R.base64===!1;A&&A.binary!==void 0||(R.binary=!X),(C instanceof h&&C.uncompressedSize===0||R.dir||!C||C.length===0)&&(R.base64=!1,R.binary=!0,C="",R.compression="STORE",P="string");var S=null;S=C instanceof h||C instanceof a?C:y.isNode&&y.isStream(C)?new f(_,C):o.prepareContent(_,C,R.binary,R.optimizedBinaryString,R.base64);var G=new m(_,S,R);this.files[_]=G}var l=e("./utf8"),o=e("./utils"),a=e("./stream/GenericWorker"),c=e("./stream/StreamHelper"),d=e("./defaults"),h=e("./compressedObject"),m=e("./zipObject"),p=e("./generate"),y=e("./nodejsUtils"),f=e("./nodejs/NodejsStreamInputAdapter"),k=function(_){_.slice(-1)==="/"&&(_=_.substring(0,_.length-1));var C=_.lastIndexOf("/");return 0<C?_.substring(0,C):""},v=function(_){return _.slice(-1)!=="/"&&(_+="/"),_},w=function(_,C){return C=C!==void 0?C:d.createFolders,_=v(_),this.files[_]||r.call(this,_,null,{dir:!0,createFolders:C}),this.files[_]};function x(_){return Object.prototype.toString.call(_)==="[object RegExp]"}var E={load:function(){throw new Error("This method has been removed in JSZip 3.0, please check the upgrade guide.")},forEach:function(_){var C,A,B;for(C in this.files)B=this.files[C],(A=C.slice(this.root.length,C.length))&&C.slice(0,this.root.length)===this.root&&_(A,B)},filter:function(_){var C=[];return this.forEach(function(A,B){_(A,B)&&C.push(B)}),C},file:function(_,C,A){if(arguments.length!==1)return _=this.root+_,r.call(this,_,C,A),this;if(x(_)){var B=_;return this.filter(function(R,X){return!X.dir&&B.test(R)})}var P=this.files[this.root+_];return P&&!P.dir?P:null},folder:function(_){if(!_)return this;if(x(_))return this.filter(function(P,R){return R.dir&&_.test(P)});var C=this.root+_,A=w.call(this,C),B=this.clone();return B.root=A.name,B},remove:function(_){_=this.root+_;var C=this.files[_];if(C||(_.slice(-1)!=="/"&&(_+="/"),C=this.files[_]),C&&!C.dir)delete this.files[_];else for(var A=this.filter(function(P,R){return R.name.slice(0,_.length)===_}),B=0;B<A.length;B++)delete this.files[A[B].name];return this},generate:function(){throw new Error("This method has been removed in JSZip 3.0, please check the upgrade guide.")},generateInternalStream:function(_){var C,A={};try{if((A=o.extend(_||{},{streamFiles:!1,compression:"STORE",compressionOptions:null,type:"",platform:"DOS",comment:null,mimeType:"application/zip",encodeFileName:l.utf8encode})).type=A.type.toLowerCase(),A.compression=A.compression.toUpperCase(),A.type==="binarystring"&&(A.type="string"),!A.type)throw new Error("No output type specified.");o.checkSupport(A.type),A.platform!=="darwin"&&A.platform!=="freebsd"&&A.platform!=="linux"&&A.platform!=="sunos"||(A.platform="UNIX"),A.platform==="win32"&&(A.platform="DOS");var B=A.comment||this.comment||"";C=p.generateWorker(this,A,B)}catch(P){(C=new a("error")).error(P)}return new c(C,A.type||"string",A.mimeType)},generateAsync:function(_,C){return this.generateInternalStream(_).accumulate(C)},generateNodeStream:function(_,C){return(_=_||{}).type||(_.type="nodebuffer"),this.generateInternalStream(_).toNodejsStream(C)}};n.exports=E},{"./compressedObject":2,"./defaults":5,"./generate":9,"./nodejs/NodejsStreamInputAdapter":12,"./nodejsUtils":14,"./stream/GenericWorker":28,"./stream/StreamHelper":29,"./utf8":31,"./utils":32,"./zipObject":35}],16:[function(e,n,s){n.exports=e("stream")},{stream:void 0}],17:[function(e,n,s){var r=e("./DataReader");function l(o){r.call(this,o);for(var a=0;a<this.data.length;a++)o[a]=255&o[a]}e("../utils").inherits(l,r),l.prototype.byteAt=function(o){return this.data[this.zero+o]},l.prototype.lastIndexOfSignature=function(o){for(var a=o.charCodeAt(0),c=o.charCodeAt(1),d=o.charCodeAt(2),h=o.charCodeAt(3),m=this.length-4;0<=m;--m)if(this.data[m]===a&&this.data[m+1]===c&&this.data[m+2]===d&&this.data[m+3]===h)return m-this.zero;return-1},l.prototype.readAndCheckSignature=function(o){var a=o.charCodeAt(0),c=o.charCodeAt(1),d=o.charCodeAt(2),h=o.charCodeAt(3),m=this.readData(4);return a===m[0]&&c===m[1]&&d===m[2]&&h===m[3]},l.prototype.readData=function(o){if(this.checkOffset(o),o===0)return[];var a=this.data.slice(this.zero+this.index,this.zero+this.index+o);return this.index+=o,a},n.exports=l},{"../utils":32,"./DataReader":18}],18:[function(e,n,s){var r=e("../utils");function l(o){this.data=o,this.length=o.length,this.index=0,this.zero=0}l.prototype={checkOffset:function(o){this.checkIndex(this.index+o)},checkIndex:function(o){if(this.length<this.zero+o||o<0)throw new Error("End of data reached (data length = "+this.length+", asked index = "+o+"). Corrupted zip ?")},setIndex:function(o){this.checkIndex(o),this.index=o},skip:function(o){this.setIndex(this.index+o)},byteAt:function(){},readInt:function(o){var a,c=0;for(this.checkOffset(o),a=this.index+o-1;a>=this.index;a--)c=(c<<8)+this.byteAt(a);return this.index+=o,c},readString:function(o){return r.transformTo("string",this.readData(o))},readData:function(){},lastIndexOfSignature:function(){},readAndCheckSignature:function(){},readDate:function(){var o=this.readInt(4);return new Date(Date.UTC(1980+(o>>25&127),(o>>21&15)-1,o>>16&31,o>>11&31,o>>5&63,(31&o)<<1))}},n.exports=l},{"../utils":32}],19:[function(e,n,s){var r=e("./Uint8ArrayReader");function l(o){r.call(this,o)}e("../utils").inherits(l,r),l.prototype.readData=function(o){this.checkOffset(o);var a=this.data.slice(this.zero+this.index,this.zero+this.index+o);return this.index+=o,a},n.exports=l},{"../utils":32,"./Uint8ArrayReader":21}],20:[function(e,n,s){var r=e("./DataReader");function l(o){r.call(this,o)}e("../utils").inherits(l,r),l.prototype.byteAt=function(o){return this.data.charCodeAt(this.zero+o)},l.prototype.lastIndexOfSignature=function(o){return this.data.lastIndexOf(o)-this.zero},l.prototype.readAndCheckSignature=function(o){return o===this.readData(4)},l.prototype.readData=function(o){this.checkOffset(o);var a=this.data.slice(this.zero+this.index,this.zero+this.index+o);return this.index+=o,a},n.exports=l},{"../utils":32,"./DataReader":18}],21:[function(e,n,s){var r=e("./ArrayReader");function l(o){r.call(this,o)}e("../utils").inherits(l,r),l.prototype.readData=function(o){if(this.checkOffset(o),o===0)return new Uint8Array(0);var a=this.data.subarray(this.zero+this.index,this.zero+this.index+o);return this.index+=o,a},n.exports=l},{"../utils":32,"./ArrayReader":17}],22:[function(e,n,s){var r=e("../utils"),l=e("../support"),o=e("./ArrayReader"),a=e("./StringReader"),c=e("./NodeBufferReader"),d=e("./Uint8ArrayReader");n.exports=function(h){var m=r.getTypeOf(h);return r.checkSupport(m),m!=="string"||l.uint8array?m==="nodebuffer"?new c(h):l.uint8array?new d(r.transformTo("uint8array",h)):new o(r.transformTo("array",h)):new a(h)}},{"../support":30,"../utils":32,"./ArrayReader":17,"./NodeBufferReader":19,"./StringReader":20,"./Uint8ArrayReader":21}],23:[function(e,n,s){s.LOCAL_FILE_HEADER="PK",s.CENTRAL_FILE_HEADER="PK",s.CENTRAL_DIRECTORY_END="PK",s.ZIP64_CENTRAL_DIRECTORY_LOCATOR="PK\x07",s.ZIP64_CENTRAL_DIRECTORY_END="PK",s.DATA_DESCRIPTOR="PK\x07\b"},{}],24:[function(e,n,s){var r=e("./GenericWorker"),l=e("../utils");function o(a){r.call(this,"ConvertWorker to "+a),this.destType=a}l.inherits(o,r),o.prototype.processChunk=function(a){this.push({data:l.transformTo(this.destType,a.data),meta:a.meta})},n.exports=o},{"../utils":32,"./GenericWorker":28}],25:[function(e,n,s){var r=e("./GenericWorker"),l=e("../crc32");function o(){r.call(this,"Crc32Probe"),this.withStreamInfo("crc32",0)}e("../utils").inherits(o,r),o.prototype.processChunk=function(a){this.streamInfo.crc32=l(a.data,this.streamInfo.crc32||0),this.push(a)},n.exports=o},{"../crc32":4,"../utils":32,"./GenericWorker":28}],26:[function(e,n,s){var r=e("../utils"),l=e("./GenericWorker");function o(a){l.call(this,"DataLengthProbe for "+a),this.propName=a,this.withStreamInfo(a,0)}r.inherits(o,l),o.prototype.processChunk=function(a){if(a){var c=this.streamInfo[this.propName]||0;this.streamInfo[this.propName]=c+a.data.length}l.prototype.processChunk.call(this,a)},n.exports=o},{"../utils":32,"./GenericWorker":28}],27:[function(e,n,s){var r=e("../utils"),l=e("./GenericWorker");function o(a){l.call(this,"DataWorker");var c=this;this.dataIsReady=!1,this.index=0,this.max=0,this.data=null,this.type="",this._tickScheduled=!1,a.then(function(d){c.dataIsReady=!0,c.data=d,c.max=d&&d.length||0,c.type=r.getTypeOf(d),c.isPaused||c._tickAndRepeat()},function(d){c.error(d)})}r.inherits(o,l),o.prototype.cleanUp=function(){l.prototype.cleanUp.call(this),this.data=null},o.prototype.resume=function(){return!!l.prototype.resume.call(this)&&(!this._tickScheduled&&this.dataIsReady&&(this._tickScheduled=!0,r.delay(this._tickAndRepeat,[],this)),!0)},o.prototype._tickAndRepeat=function(){this._tickScheduled=!1,this.isPaused||this.isFinished||(this._tick(),this.isFinished||(r.delay(this._tickAndRepeat,[],this),this._tickScheduled=!0))},o.prototype._tick=function(){if(this.isPaused||this.isFinished)return!1;var a=null,c=Math.min(this.max,this.index+16384);if(this.index>=this.max)return this.end();switch(this.type){case"string":a=this.data.substring(this.index,c);break;case"uint8array":a=this.data.subarray(this.index,c);break;case"array":case"nodebuffer":a=this.data.slice(this.index,c)}return this.index=c,this.push({data:a,meta:{percent:this.max?this.index/this.max*100:0}})},n.exports=o},{"../utils":32,"./GenericWorker":28}],28:[function(e,n,s){function r(l){this.name=l||"default",this.streamInfo={},this.generatedError=null,this.extraStreamInfo={},this.isPaused=!0,this.isFinished=!1,this.isLocked=!1,this._listeners={data:[],end:[],error:[]},this.previous=null}r.prototype={push:function(l){this.emit("data",l)},end:function(){if(this.isFinished)return!1;this.flush();try{this.emit("end"),this.cleanUp(),this.isFinished=!0}catch(l){this.emit("error",l)}return!0},error:function(l){return!this.isFinished&&(this.isPaused?this.generatedError=l:(this.isFinished=!0,this.emit("error",l),this.previous&&this.previous.error(l),this.cleanUp()),!0)},on:function(l,o){return this._listeners[l].push(o),this},cleanUp:function(){this.streamInfo=this.generatedError=this.extraStreamInfo=null,this._listeners=[]},emit:function(l,o){if(this._listeners[l])for(var a=0;a<this._listeners[l].length;a++)this._listeners[l][a].call(this,o)},pipe:function(l){return l.registerPrevious(this)},registerPrevious:function(l){if(this.isLocked)throw new Error("The stream '"+this+"' has already been used.");this.streamInfo=l.streamInfo,this.mergeStreamInfo(),this.previous=l;var o=this;return l.on("data",function(a){o.processChunk(a)}),l.on("end",function(){o.end()}),l.on("error",function(a){o.error(a)}),this},pause:function(){return!this.isPaused&&!this.isFinished&&(this.isPaused=!0,this.previous&&this.previous.pause(),!0)},resume:function(){if(!this.isPaused||this.isFinished)return!1;var l=this.isPaused=!1;return this.generatedError&&(this.error(this.generatedError),l=!0),this.previous&&this.previous.resume(),!l},flush:function(){},processChunk:function(l){this.push(l)},withStreamInfo:function(l,o){return this.extraStreamInfo[l]=o,this.mergeStreamInfo(),this},mergeStreamInfo:function(){for(var l in this.extraStreamInfo)Object.prototype.hasOwnProperty.call(this.extraStreamInfo,l)&&(this.streamInfo[l]=this.extraStreamInfo[l])},lock:function(){if(this.isLocked)throw new Error("The stream '"+this+"' has already been used.");this.isLocked=!0,this.previous&&this.previous.lock()},toString:function(){var l="Worker "+this.name;return this.previous?this.previous+" -> "+l:l}},n.exports=r},{}],29:[function(e,n,s){var r=e("../utils"),l=e("./ConvertWorker"),o=e("./GenericWorker"),a=e("../base64"),c=e("../support"),d=e("../external"),h=null;if(c.nodestream)try{h=e("../nodejs/NodejsStreamOutputAdapter")}catch{}function m(y,f){return new d.Promise(function(k,v){var w=[],x=y._internalType,E=y._outputType,_=y._mimeType;y.on("data",function(C,A){w.push(C),f&&f(A)}).on("error",function(C){w=[],v(C)}).on("end",function(){try{var C=(function(A,B,P){switch(A){case"blob":return r.newBlob(r.transformTo("arraybuffer",B),P);case"base64":return a.encode(B);default:return r.transformTo(A,B)}})(E,(function(A,B){var P,R=0,X=null,S=0;for(P=0;P<B.length;P++)S+=B[P].length;switch(A){case"string":return B.join("");case"array":return Array.prototype.concat.apply([],B);case"uint8array":for(X=new Uint8Array(S),P=0;P<B.length;P++)X.set(B[P],R),R+=B[P].length;return X;case"nodebuffer":return Buffer.concat(B);default:throw new Error("concat : unsupported type '"+A+"'")}})(x,w),_);k(C)}catch(A){v(A)}w=[]}).resume()})}function p(y,f,k){var v=f;switch(f){case"blob":case"arraybuffer":v="uint8array";break;case"base64":v="string"}try{this._internalType=v,this._outputType=f,this._mimeType=k,r.checkSupport(v),this._worker=y.pipe(new l(v)),y.lock()}catch(w){this._worker=new o("error"),this._worker.error(w)}}p.prototype={accumulate:function(y){return m(this,y)},on:function(y,f){var k=this;return y==="data"?this._worker.on(y,function(v){f.call(k,v.data,v.meta)}):this._worker.on(y,function(){r.delay(f,arguments,k)}),this},resume:function(){return r.delay(this._worker.resume,[],this._worker),this},pause:function(){return this._worker.pause(),this},toNodejsStream:function(y){if(r.checkSupport("nodestream"),this._outputType!=="nodebuffer")throw new Error(this._outputType+" is not supported by this method");return new h(this,{objectMode:this._outputType!=="nodebuffer"},y)}},n.exports=p},{"../base64":1,"../external":6,"../nodejs/NodejsStreamOutputAdapter":13,"../support":30,"../utils":32,"./ConvertWorker":24,"./GenericWorker":28}],30:[function(e,n,s){if(s.base64=!0,s.array=!0,s.string=!0,s.arraybuffer=typeof ArrayBuffer<"u"&&typeof Uint8Array<"u",s.nodebuffer=typeof Buffer<"u",s.uint8array=typeof Uint8Array<"u",typeof ArrayBuffer>"u")s.blob=!1;else{var r=new ArrayBuffer(0);try{s.blob=new Blob([r],{type:"application/zip"}).size===0}catch{try{var l=new(self.BlobBuilder||self.WebKitBlobBuilder||self.MozBlobBuilder||self.MSBlobBuilder);l.append(r),s.blob=l.getBlob("application/zip").size===0}catch{s.blob=!1}}}try{s.nodestream=!!e("readable-stream").Readable}catch{s.nodestream=!1}},{"readable-stream":16}],31:[function(e,n,s){for(var r=e("./utils"),l=e("./support"),o=e("./nodejsUtils"),a=e("./stream/GenericWorker"),c=new Array(256),d=0;d<256;d++)c[d]=252<=d?6:248<=d?5:240<=d?4:224<=d?3:192<=d?2:1;c[254]=c[254]=1;function h(){a.call(this,"utf-8 decode"),this.leftOver=null}function m(){a.call(this,"utf-8 encode")}s.utf8encode=function(p){return l.nodebuffer?o.newBufferFrom(p,"utf-8"):(function(y){var f,k,v,w,x,E=y.length,_=0;for(w=0;w<E;w++)(64512&(k=y.charCodeAt(w)))==55296&&w+1<E&&(64512&(v=y.charCodeAt(w+1)))==56320&&(k=65536+(k-55296<<10)+(v-56320),w++),_+=k<128?1:k<2048?2:k<65536?3:4;for(f=l.uint8array?new Uint8Array(_):new Array(_),w=x=0;x<_;w++)(64512&(k=y.charCodeAt(w)))==55296&&w+1<E&&(64512&(v=y.charCodeAt(w+1)))==56320&&(k=65536+(k-55296<<10)+(v-56320),w++),k<128?f[x++]=k:(k<2048?f[x++]=192|k>>>6:(k<65536?f[x++]=224|k>>>12:(f[x++]=240|k>>>18,f[x++]=128|k>>>12&63),f[x++]=128|k>>>6&63),f[x++]=128|63&k);return f})(p)},s.utf8decode=function(p){return l.nodebuffer?r.transformTo("nodebuffer",p).toString("utf-8"):(function(y){var f,k,v,w,x=y.length,E=new Array(2*x);for(f=k=0;f<x;)if((v=y[f++])<128)E[k++]=v;else if(4<(w=c[v]))E[k++]=65533,f+=w-1;else{for(v&=w===2?31:w===3?15:7;1<w&&f<x;)v=v<<6|63&y[f++],w--;1<w?E[k++]=65533:v<65536?E[k++]=v:(v-=65536,E[k++]=55296|v>>10&1023,E[k++]=56320|1023&v)}return E.length!==k&&(E.subarray?E=E.subarray(0,k):E.length=k),r.applyFromCharCode(E)})(p=r.transformTo(l.uint8array?"uint8array":"array",p))},r.inherits(h,a),h.prototype.processChunk=function(p){var y=r.transformTo(l.uint8array?"uint8array":"array",p.data);if(this.leftOver&&this.leftOver.length){if(l.uint8array){var f=y;(y=new Uint8Array(f.length+this.leftOver.length)).set(this.leftOver,0),y.set(f,this.leftOver.length)}else y=this.leftOver.concat(y);this.leftOver=null}var k=(function(w,x){var E;for((x=x||w.length)>w.length&&(x=w.length),E=x-1;0<=E&&(192&w[E])==128;)E--;return E<0||E===0?x:E+c[w[E]]>x?E:x})(y),v=y;k!==y.length&&(l.uint8array?(v=y.subarray(0,k),this.leftOver=y.subarray(k,y.length)):(v=y.slice(0,k),this.leftOver=y.slice(k,y.length))),this.push({data:s.utf8decode(v),meta:p.meta})},h.prototype.flush=function(){this.leftOver&&this.leftOver.length&&(this.push({data:s.utf8decode(this.leftOver),meta:{}}),this.leftOver=null)},s.Utf8DecodeWorker=h,r.inherits(m,a),m.prototype.processChunk=function(p){this.push({data:s.utf8encode(p.data),meta:p.meta})},s.Utf8EncodeWorker=m},{"./nodejsUtils":14,"./stream/GenericWorker":28,"./support":30,"./utils":32}],32:[function(e,n,s){var r=e("./support"),l=e("./base64"),o=e("./nodejsUtils"),a=e("./external");function c(f){return f}function d(f,k){for(var v=0;v<f.length;++v)k[v]=255&f.charCodeAt(v);return k}e("setimmediate"),s.newBlob=function(f,k){s.checkSupport("blob");try{return new Blob([f],{type:k})}catch{try{var v=new(self.BlobBuilder||self.WebKitBlobBuilder||self.MozBlobBuilder||self.MSBlobBuilder);return v.append(f),v.getBlob(k)}catch{throw new Error("Bug : can't construct the Blob.")}}};var h={stringifyByChunk:function(f,k,v){var w=[],x=0,E=f.length;if(E<=v)return String.fromCharCode.apply(null,f);for(;x<E;)k==="array"||k==="nodebuffer"?w.push(String.fromCharCode.apply(null,f.slice(x,Math.min(x+v,E)))):w.push(String.fromCharCode.apply(null,f.subarray(x,Math.min(x+v,E)))),x+=v;return w.join("")},stringifyByChar:function(f){for(var k="",v=0;v<f.length;v++)k+=String.fromCharCode(f[v]);return k},applyCanBeUsed:{uint8array:(function(){try{return r.uint8array&&String.fromCharCode.apply(null,new Uint8Array(1)).length===1}catch{return!1}})(),nodebuffer:(function(){try{return r.nodebuffer&&String.fromCharCode.apply(null,o.allocBuffer(1)).length===1}catch{return!1}})()}};function m(f){var k=65536,v=s.getTypeOf(f),w=!0;if(v==="uint8array"?w=h.applyCanBeUsed.uint8array:v==="nodebuffer"&&(w=h.applyCanBeUsed.nodebuffer),w)for(;1<k;)try{return h.stringifyByChunk(f,v,k)}catch{k=Math.floor(k/2)}return h.stringifyByChar(f)}function p(f,k){for(var v=0;v<f.length;v++)k[v]=f[v];return k}s.applyFromCharCode=m;var y={};y.string={string:c,array:function(f){return d(f,new Array(f.length))},arraybuffer:function(f){return y.string.uint8array(f).buffer},uint8array:function(f){return d(f,new Uint8Array(f.length))},nodebuffer:function(f){return d(f,o.allocBuffer(f.length))}},y.array={string:m,array:c,arraybuffer:function(f){return new Uint8Array(f).buffer},uint8array:function(f){return new Uint8Array(f)},nodebuffer:function(f){return o.newBufferFrom(f)}},y.arraybuffer={string:function(f){return m(new Uint8Array(f))},array:function(f){return p(new Uint8Array(f),new Array(f.byteLength))},arraybuffer:c,uint8array:function(f){return new Uint8Array(f)},nodebuffer:function(f){return o.newBufferFrom(new Uint8Array(f))}},y.uint8array={string:m,array:function(f){return p(f,new Array(f.length))},arraybuffer:function(f){return f.buffer},uint8array:c,nodebuffer:function(f){return o.newBufferFrom(f)}},y.nodebuffer={string:m,array:function(f){return p(f,new Array(f.length))},arraybuffer:function(f){return y.nodebuffer.uint8array(f).buffer},uint8array:function(f){return p(f,new Uint8Array(f.length))},nodebuffer:c},s.transformTo=function(f,k){if(k=k||"",!f)return k;s.checkSupport(f);var v=s.getTypeOf(k);return y[v][f](k)},s.resolve=function(f){for(var k=f.split("/"),v=[],w=0;w<k.length;w++){var x=k[w];x==="."||x===""&&w!==0&&w!==k.length-1||(x===".."?v.pop():v.push(x))}return v.join("/")},s.getTypeOf=function(f){return typeof f=="string"?"string":Object.prototype.toString.call(f)==="[object Array]"?"array":r.nodebuffer&&o.isBuffer(f)?"nodebuffer":r.uint8array&&f instanceof Uint8Array?"uint8array":r.arraybuffer&&f instanceof ArrayBuffer?"arraybuffer":void 0},s.checkSupport=function(f){if(!r[f.toLowerCase()])throw new Error(f+" is not supported by this platform")},s.MAX_VALUE_16BITS=65535,s.MAX_VALUE_32BITS=-1,s.pretty=function(f){var k,v,w="";for(v=0;v<(f||"").length;v++)w+="\\x"+((k=f.charCodeAt(v))<16?"0":"")+k.toString(16).toUpperCase();return w},s.delay=function(f,k,v){setImmediate(function(){f.apply(v||null,k||[])})},s.inherits=function(f,k){function v(){}v.prototype=k.prototype,f.prototype=new v},s.extend=function(){var f,k,v={};for(f=0;f<arguments.length;f++)for(k in arguments[f])Object.prototype.hasOwnProperty.call(arguments[f],k)&&v[k]===void 0&&(v[k]=arguments[f][k]);return v},s.prepareContent=function(f,k,v,w,x){return a.Promise.resolve(k).then(function(E){return r.blob&&(E instanceof Blob||["[object File]","[object Blob]"].indexOf(Object.prototype.toString.call(E))!==-1)&&typeof FileReader<"u"?new a.Promise(function(_,C){var A=new FileReader;A.onload=function(B){_(B.target.result)},A.onerror=function(B){C(B.target.error)},A.readAsArrayBuffer(E)}):E}).then(function(E){var _=s.getTypeOf(E);return _?(_==="arraybuffer"?E=s.transformTo("uint8array",E):_==="string"&&(x?E=l.decode(E):v&&w!==!0&&(E=(function(C){return d(C,r.uint8array?new Uint8Array(C.length):new Array(C.length))})(E))),E):a.Promise.reject(new Error("Can't read the data of '"+f+"'. Is it in a supported JavaScript type (String, Blob, ArrayBuffer, etc) ?"))})}},{"./base64":1,"./external":6,"./nodejsUtils":14,"./support":30,setimmediate:54}],33:[function(e,n,s){var r=e("./reader/readerFor"),l=e("./utils"),o=e("./signature"),a=e("./zipEntry"),c=e("./support");function d(h){this.files=[],this.loadOptions=h}d.prototype={checkSignature:function(h){if(!this.reader.readAndCheckSignature(h)){this.reader.index-=4;var m=this.reader.readString(4);throw new Error("Corrupted zip or bug: unexpected signature ("+l.pretty(m)+", expected "+l.pretty(h)+")")}},isSignature:function(h,m){var p=this.reader.index;this.reader.setIndex(h);var y=this.reader.readString(4)===m;return this.reader.setIndex(p),y},readBlockEndOfCentral:function(){this.diskNumber=this.reader.readInt(2),this.diskWithCentralDirStart=this.reader.readInt(2),this.centralDirRecordsOnThisDisk=this.reader.readInt(2),this.centralDirRecords=this.reader.readInt(2),this.centralDirSize=this.reader.readInt(4),this.centralDirOffset=this.reader.readInt(4),this.zipCommentLength=this.reader.readInt(2);var h=this.reader.readData(this.zipCommentLength),m=c.uint8array?"uint8array":"array",p=l.transformTo(m,h);this.zipComment=this.loadOptions.decodeFileName(p)},readBlockZip64EndOfCentral:function(){this.zip64EndOfCentralSize=this.reader.readInt(8),this.reader.skip(4),this.diskNumber=this.reader.readInt(4),this.diskWithCentralDirStart=this.reader.readInt(4),this.centralDirRecordsOnThisDisk=this.reader.readInt(8),this.centralDirRecords=this.reader.readInt(8),this.centralDirSize=this.reader.readInt(8),this.centralDirOffset=this.reader.readInt(8),this.zip64ExtensibleData={};for(var h,m,p,y=this.zip64EndOfCentralSize-44;0<y;)h=this.reader.readInt(2),m=this.reader.readInt(4),p=this.reader.readData(m),this.zip64ExtensibleData[h]={id:h,length:m,value:p}},readBlockZip64EndOfCentralLocator:function(){if(this.diskWithZip64CentralDirStart=this.reader.readInt(4),this.relativeOffsetEndOfZip64CentralDir=this.reader.readInt(8),this.disksCount=this.reader.readInt(4),1<this.disksCount)throw new Error("Multi-volumes zip are not supported")},readLocalFiles:function(){var h,m;for(h=0;h<this.files.length;h++)m=this.files[h],this.reader.setIndex(m.localHeaderOffset),this.checkSignature(o.LOCAL_FILE_HEADER),m.readLocalPart(this.reader),m.handleUTF8(),m.processAttributes()},readCentralDir:function(){var h;for(this.reader.setIndex(this.centralDirOffset);this.reader.readAndCheckSignature(o.CENTRAL_FILE_HEADER);)(h=new a({zip64:this.zip64},this.loadOptions)).readCentralPart(this.reader),this.files.push(h);if(this.centralDirRecords!==this.files.length&&this.centralDirRecords!==0&&this.files.length===0)throw new Error("Corrupted zip or bug: expected "+this.centralDirRecords+" records in central dir, got "+this.files.length)},readEndOfCentral:function(){var h=this.reader.lastIndexOfSignature(o.CENTRAL_DIRECTORY_END);if(h<0)throw this.isSignature(0,o.LOCAL_FILE_HEADER)?new Error("Corrupted zip: can't find end of central directory"):new Error("Can't find end of central directory : is this a zip file ? If it is, see https://stuk.github.io/jszip/documentation/howto/read_zip.html");this.reader.setIndex(h);var m=h;if(this.checkSignature(o.CENTRAL_DIRECTORY_END),this.readBlockEndOfCentral(),this.diskNumber===l.MAX_VALUE_16BITS||this.diskWithCentralDirStart===l.MAX_VALUE_16BITS||this.centralDirRecordsOnThisDisk===l.MAX_VALUE_16BITS||this.centralDirRecords===l.MAX_VALUE_16BITS||this.centralDirSize===l.MAX_VALUE_32BITS||this.centralDirOffset===l.MAX_VALUE_32BITS){if(this.zip64=!0,(h=this.reader.lastIndexOfSignature(o.ZIP64_CENTRAL_DIRECTORY_LOCATOR))<0)throw new Error("Corrupted zip: can't find the ZIP64 end of central directory locator");if(this.reader.setIndex(h),this.checkSignature(o.ZIP64_CENTRAL_DIRECTORY_LOCATOR),this.readBlockZip64EndOfCentralLocator(),!this.isSignature(this.relativeOffsetEndOfZip64CentralDir,o.ZIP64_CENTRAL_DIRECTORY_END)&&(this.relativeOffsetEndOfZip64CentralDir=this.reader.lastIndexOfSignature(o.ZIP64_CENTRAL_DIRECTORY_END),this.relativeOffsetEndOfZip64CentralDir<0))throw new Error("Corrupted zip: can't find the ZIP64 end of central directory");this.reader.setIndex(this.relativeOffsetEndOfZip64CentralDir),this.checkSignature(o.ZIP64_CENTRAL_DIRECTORY_END),this.readBlockZip64EndOfCentral()}var p=this.centralDirOffset+this.centralDirSize;this.zip64&&(p+=20,p+=12+this.zip64EndOfCentralSize);var y=m-p;if(0<y)this.isSignature(m,o.CENTRAL_FILE_HEADER)||(this.reader.zero=y);else if(y<0)throw new Error("Corrupted zip: missing "+Math.abs(y)+" bytes.")},prepareReader:function(h){this.reader=r(h)},load:function(h){this.prepareReader(h),this.readEndOfCentral(),this.readCentralDir(),this.readLocalFiles()}},n.exports=d},{"./reader/readerFor":22,"./signature":23,"./support":30,"./utils":32,"./zipEntry":34}],34:[function(e,n,s){var r=e("./reader/readerFor"),l=e("./utils"),o=e("./compressedObject"),a=e("./crc32"),c=e("./utf8"),d=e("./compressions"),h=e("./support");function m(p,y){this.options=p,this.loadOptions=y}m.prototype={isEncrypted:function(){return(1&this.bitFlag)==1},useUTF8:function(){return(2048&this.bitFlag)==2048},readLocalPart:function(p){var y,f;if(p.skip(22),this.fileNameLength=p.readInt(2),f=p.readInt(2),this.fileName=p.readData(this.fileNameLength),p.skip(f),this.compressedSize===-1||this.uncompressedSize===-1)throw new Error("Bug or corrupted zip : didn't get enough information from the central directory (compressedSize === -1 || uncompressedSize === -1)");if((y=(function(k){for(var v in d)if(Object.prototype.hasOwnProperty.call(d,v)&&d[v].magic===k)return d[v];return null})(this.compressionMethod))===null)throw new Error("Corrupted zip : compression "+l.pretty(this.compressionMethod)+" unknown (inner file : "+l.transformTo("string",this.fileName)+")");this.decompressed=new o(this.compressedSize,this.uncompressedSize,this.crc32,y,p.readData(this.compressedSize))},readCentralPart:function(p){this.versionMadeBy=p.readInt(2),p.skip(2),this.bitFlag=p.readInt(2),this.compressionMethod=p.readString(2),this.date=p.readDate(),this.crc32=p.readInt(4),this.compressedSize=p.readInt(4),this.uncompressedSize=p.readInt(4);var y=p.readInt(2);if(this.extraFieldsLength=p.readInt(2),this.fileCommentLength=p.readInt(2),this.diskNumberStart=p.readInt(2),this.internalFileAttributes=p.readInt(2),this.externalFileAttributes=p.readInt(4),this.localHeaderOffset=p.readInt(4),this.isEncrypted())throw new Error("Encrypted zip are not supported");p.skip(y),this.readExtraFields(p),this.parseZIP64ExtraField(p),this.fileComment=p.readData(this.fileCommentLength)},processAttributes:function(){this.unixPermissions=null,this.dosPermissions=null;var p=this.versionMadeBy>>8;this.dir=!!(16&this.externalFileAttributes),p==0&&(this.dosPermissions=63&this.externalFileAttributes),p==3&&(this.unixPermissions=this.externalFileAttributes>>16&65535),this.dir||this.fileNameStr.slice(-1)!=="/"||(this.dir=!0)},parseZIP64ExtraField:function(){if(this.extraFields[1]){var p=r(this.extraFields[1].value);this.uncompressedSize===l.MAX_VALUE_32BITS&&(this.uncompressedSize=p.readInt(8)),this.compressedSize===l.MAX_VALUE_32BITS&&(this.compressedSize=p.readInt(8)),this.localHeaderOffset===l.MAX_VALUE_32BITS&&(this.localHeaderOffset=p.readInt(8)),this.diskNumberStart===l.MAX_VALUE_32BITS&&(this.diskNumberStart=p.readInt(4))}},readExtraFields:function(p){var y,f,k,v=p.index+this.extraFieldsLength;for(this.extraFields||(this.extraFields={});p.index+4<v;)y=p.readInt(2),f=p.readInt(2),k=p.readData(f),this.extraFields[y]={id:y,length:f,value:k};p.setIndex(v)},handleUTF8:function(){var p=h.uint8array?"uint8array":"array";if(this.useUTF8())this.fileNameStr=c.utf8decode(this.fileName),this.fileCommentStr=c.utf8decode(this.fileComment);else{var y=this.findExtraFieldUnicodePath();if(y!==null)this.fileNameStr=y;else{var f=l.transformTo(p,this.fileName);this.fileNameStr=this.loadOptions.decodeFileName(f)}var k=this.findExtraFieldUnicodeComment();if(k!==null)this.fileCommentStr=k;else{var v=l.transformTo(p,this.fileComment);this.fileCommentStr=this.loadOptions.decodeFileName(v)}}},findExtraFieldUnicodePath:function(){var p=this.extraFields[28789];if(p){var y=r(p.value);return y.readInt(1)!==1||a(this.fileName)!==y.readInt(4)?null:c.utf8decode(y.readData(p.length-5))}return null},findExtraFieldUnicodeComment:function(){var p=this.extraFields[25461];if(p){var y=r(p.value);return y.readInt(1)!==1||a(this.fileComment)!==y.readInt(4)?null:c.utf8decode(y.readData(p.length-5))}return null}},n.exports=m},{"./compressedObject":2,"./compressions":3,"./crc32":4,"./reader/readerFor":22,"./support":30,"./utf8":31,"./utils":32}],35:[function(e,n,s){function r(y,f,k){this.name=y,this.dir=k.dir,this.date=k.date,this.comment=k.comment,this.unixPermissions=k.unixPermissions,this.dosPermissions=k.dosPermissions,this._data=f,this._dataBinary=k.binary,this.options={compression:k.compression,compressionOptions:k.compressionOptions}}var l=e("./stream/StreamHelper"),o=e("./stream/DataWorker"),a=e("./utf8"),c=e("./compressedObject"),d=e("./stream/GenericWorker");r.prototype={internalStream:function(y){var f=null,k="string";try{if(!y)throw new Error("No output type specified.");var v=(k=y.toLowerCase())==="string"||k==="text";k!=="binarystring"&&k!=="text"||(k="string"),f=this._decompressWorker();var w=!this._dataBinary;w&&!v&&(f=f.pipe(new a.Utf8EncodeWorker)),!w&&v&&(f=f.pipe(new a.Utf8DecodeWorker))}catch(x){(f=new d("error")).error(x)}return new l(f,k,"")},async:function(y,f){return this.internalStream(y).accumulate(f)},nodeStream:function(y,f){return this.internalStream(y||"nodebuffer").toNodejsStream(f)},_compressWorker:function(y,f){if(this._data instanceof c&&this._data.compression.magic===y.magic)return this._data.getCompressedWorker();var k=this._decompressWorker();return this._dataBinary||(k=k.pipe(new a.Utf8EncodeWorker)),c.createWorkerFrom(k,y,f)},_decompressWorker:function(){return this._data instanceof c?this._data.getContentWorker():this._data instanceof d?this._data:new o(this._data)}};for(var h=["asText","asBinary","asNodeBuffer","asUint8Array","asArrayBuffer"],m=function(){throw new Error("This method has been removed in JSZip 3.0, please check the upgrade guide.")},p=0;p<h.length;p++)r.prototype[h[p]]=m;n.exports=r},{"./compressedObject":2,"./stream/DataWorker":27,"./stream/GenericWorker":28,"./stream/StreamHelper":29,"./utf8":31}],36:[function(e,n,s){(function(r){var l,o,a=r.MutationObserver||r.WebKitMutationObserver;if(a){var c=0,d=new a(y),h=r.document.createTextNode("");d.observe(h,{characterData:!0}),l=function(){h.data=c=++c%2}}else if(r.setImmediate||r.MessageChannel===void 0)l="document"in r&&"onreadystatechange"in r.document.createElement("script")?function(){var f=r.document.createElement("script");f.onreadystatechange=function(){y(),f.onreadystatechange=null,f.parentNode.removeChild(f),f=null},r.document.documentElement.appendChild(f)}:function(){setTimeout(y,0)};else{var m=new r.MessageChannel;m.port1.onmessage=y,l=function(){m.port2.postMessage(0)}}var p=[];function y(){var f,k;o=!0;for(var v=p.length;v;){for(k=p,p=[],f=-1;++f<v;)k[f]();v=p.length}o=!1}n.exports=function(f){p.push(f)!==1||o||l()}}).call(this,typeof Rn<"u"?Rn:typeof self<"u"?self:typeof window<"u"?window:{})},{}],37:[function(e,n,s){var r=e("immediate");function l(){}var o={},a=["REJECTED"],c=["FULFILLED"],d=["PENDING"];function h(v){if(typeof v!="function")throw new TypeError("resolver must be a function");this.state=d,this.queue=[],this.outcome=void 0,v!==l&&f(this,v)}function m(v,w,x){this.promise=v,typeof w=="function"&&(this.onFulfilled=w,this.callFulfilled=this.otherCallFulfilled),typeof x=="function"&&(this.onRejected=x,this.callRejected=this.otherCallRejected)}function p(v,w,x){r(function(){var E;try{E=w(x)}catch(_){return o.reject(v,_)}E===v?o.reject(v,new TypeError("Cannot resolve promise with itself")):o.resolve(v,E)})}function y(v){var w=v&&v.then;if(v&&(typeof v=="object"||typeof v=="function")&&typeof w=="function")return function(){w.apply(v,arguments)}}function f(v,w){var x=!1;function E(A){x||(x=!0,o.reject(v,A))}function _(A){x||(x=!0,o.resolve(v,A))}var C=k(function(){w(_,E)});C.status==="error"&&E(C.value)}function k(v,w){var x={};try{x.value=v(w),x.status="success"}catch(E){x.status="error",x.value=E}return x}(n.exports=h).prototype.finally=function(v){if(typeof v!="function")return this;var w=this.constructor;return this.then(function(x){return w.resolve(v()).then(function(){return x})},function(x){return w.resolve(v()).then(function(){throw x})})},h.prototype.catch=function(v){return this.then(null,v)},h.prototype.then=function(v,w){if(typeof v!="function"&&this.state===c||typeof w!="function"&&this.state===a)return this;var x=new this.constructor(l);return this.state!==d?p(x,this.state===c?v:w,this.outcome):this.queue.push(new m(x,v,w)),x},m.prototype.callFulfilled=function(v){o.resolve(this.promise,v)},m.prototype.otherCallFulfilled=function(v){p(this.promise,this.onFulfilled,v)},m.prototype.callRejected=function(v){o.reject(this.promise,v)},m.prototype.otherCallRejected=function(v){p(this.promise,this.onRejected,v)},o.resolve=function(v,w){var x=k(y,w);if(x.status==="error")return o.reject(v,x.value);var E=x.value;if(E)f(v,E);else{v.state=c,v.outcome=w;for(var _=-1,C=v.queue.length;++_<C;)v.queue[_].callFulfilled(w)}return v},o.reject=function(v,w){v.state=a,v.outcome=w;for(var x=-1,E=v.queue.length;++x<E;)v.queue[x].callRejected(w);return v},h.resolve=function(v){return v instanceof this?v:o.resolve(new this(l),v)},h.reject=function(v){var w=new this(l);return o.reject(w,v)},h.all=function(v){var w=this;if(Object.prototype.toString.call(v)!=="[object Array]")return this.reject(new TypeError("must be an array"));var x=v.length,E=!1;if(!x)return this.resolve([]);for(var _=new Array(x),C=0,A=-1,B=new this(l);++A<x;)P(v[A],A);return B;function P(R,X){w.resolve(R).then(function(S){_[X]=S,++C!==x||E||(E=!0,o.resolve(B,_))},function(S){E||(E=!0,o.reject(B,S))})}},h.race=function(v){var w=this;if(Object.prototype.toString.call(v)!=="[object Array]")return this.reject(new TypeError("must be an array"));var x=v.length,E=!1;if(!x)return this.resolve([]);for(var _=-1,C=new this(l);++_<x;)A=v[_],w.resolve(A).then(function(B){E||(E=!0,o.resolve(C,B))},function(B){E||(E=!0,o.reject(C,B))});var A;return C}},{immediate:36}],38:[function(e,n,s){var r={};(0,e("./lib/utils/common").assign)(r,e("./lib/deflate"),e("./lib/inflate"),e("./lib/zlib/constants")),n.exports=r},{"./lib/deflate":39,"./lib/inflate":40,"./lib/utils/common":41,"./lib/zlib/constants":44}],39:[function(e,n,s){var r=e("./zlib/deflate"),l=e("./utils/common"),o=e("./utils/strings"),a=e("./zlib/messages"),c=e("./zlib/zstream"),d=Object.prototype.toString,h=0,m=-1,p=0,y=8;function f(v){if(!(this instanceof f))return new f(v);this.options=l.assign({level:m,method:y,chunkSize:16384,windowBits:15,memLevel:8,strategy:p,to:""},v||{});var w=this.options;w.raw&&0<w.windowBits?w.windowBits=-w.windowBits:w.gzip&&0<w.windowBits&&w.windowBits<16&&(w.windowBits+=16),this.err=0,this.msg="",this.ended=!1,this.chunks=[],this.strm=new c,this.strm.avail_out=0;var x=r.deflateInit2(this.strm,w.level,w.method,w.windowBits,w.memLevel,w.strategy);if(x!==h)throw new Error(a[x]);if(w.header&&r.deflateSetHeader(this.strm,w.header),w.dictionary){var E;if(E=typeof w.dictionary=="string"?o.string2buf(w.dictionary):d.call(w.dictionary)==="[object ArrayBuffer]"?new Uint8Array(w.dictionary):w.dictionary,(x=r.deflateSetDictionary(this.strm,E))!==h)throw new Error(a[x]);this._dict_set=!0}}function k(v,w){var x=new f(w);if(x.push(v,!0),x.err)throw x.msg||a[x.err];return x.result}f.prototype.push=function(v,w){var x,E,_=this.strm,C=this.options.chunkSize;if(this.ended)return!1;E=w===~~w?w:w===!0?4:0,typeof v=="string"?_.input=o.string2buf(v):d.call(v)==="[object ArrayBuffer]"?_.input=new Uint8Array(v):_.input=v,_.next_in=0,_.avail_in=_.input.length;do{if(_.avail_out===0&&(_.output=new l.Buf8(C),_.next_out=0,_.avail_out=C),(x=r.deflate(_,E))!==1&&x!==h)return this.onEnd(x),!(this.ended=!0);_.avail_out!==0&&(_.avail_in!==0||E!==4&&E!==2)||(this.options.to==="string"?this.onData(o.buf2binstring(l.shrinkBuf(_.output,_.next_out))):this.onData(l.shrinkBuf(_.output,_.next_out)))}while((0<_.avail_in||_.avail_out===0)&&x!==1);return E===4?(x=r.deflateEnd(this.strm),this.onEnd(x),this.ended=!0,x===h):E!==2||(this.onEnd(h),!(_.avail_out=0))},f.prototype.onData=function(v){this.chunks.push(v)},f.prototype.onEnd=function(v){v===h&&(this.options.to==="string"?this.result=this.chunks.join(""):this.result=l.flattenChunks(this.chunks)),this.chunks=[],this.err=v,this.msg=this.strm.msg},s.Deflate=f,s.deflate=k,s.deflateRaw=function(v,w){return(w=w||{}).raw=!0,k(v,w)},s.gzip=function(v,w){return(w=w||{}).gzip=!0,k(v,w)}},{"./utils/common":41,"./utils/strings":42,"./zlib/deflate":46,"./zlib/messages":51,"./zlib/zstream":53}],40:[function(e,n,s){var r=e("./zlib/inflate"),l=e("./utils/common"),o=e("./utils/strings"),a=e("./zlib/constants"),c=e("./zlib/messages"),d=e("./zlib/zstream"),h=e("./zlib/gzheader"),m=Object.prototype.toString;function p(f){if(!(this instanceof p))return new p(f);this.options=l.assign({chunkSize:16384,windowBits:0,to:""},f||{});var k=this.options;k.raw&&0<=k.windowBits&&k.windowBits<16&&(k.windowBits=-k.windowBits,k.windowBits===0&&(k.windowBits=-15)),!(0<=k.windowBits&&k.windowBits<16)||f&&f.windowBits||(k.windowBits+=32),15<k.windowBits&&k.windowBits<48&&(15&k.windowBits)==0&&(k.windowBits|=15),this.err=0,this.msg="",this.ended=!1,this.chunks=[],this.strm=new d,this.strm.avail_out=0;var v=r.inflateInit2(this.strm,k.windowBits);if(v!==a.Z_OK)throw new Error(c[v]);this.header=new h,r.inflateGetHeader(this.strm,this.header)}function y(f,k){var v=new p(k);if(v.push(f,!0),v.err)throw v.msg||c[v.err];return v.result}p.prototype.push=function(f,k){var v,w,x,E,_,C,A=this.strm,B=this.options.chunkSize,P=this.options.dictionary,R=!1;if(this.ended)return!1;w=k===~~k?k:k===!0?a.Z_FINISH:a.Z_NO_FLUSH,typeof f=="string"?A.input=o.binstring2buf(f):m.call(f)==="[object ArrayBuffer]"?A.input=new Uint8Array(f):A.input=f,A.next_in=0,A.avail_in=A.input.length;do{if(A.avail_out===0&&(A.output=new l.Buf8(B),A.next_out=0,A.avail_out=B),(v=r.inflate(A,a.Z_NO_FLUSH))===a.Z_NEED_DICT&&P&&(C=typeof P=="string"?o.string2buf(P):m.call(P)==="[object ArrayBuffer]"?new Uint8Array(P):P,v=r.inflateSetDictionary(this.strm,C)),v===a.Z_BUF_ERROR&&R===!0&&(v=a.Z_OK,R=!1),v!==a.Z_STREAM_END&&v!==a.Z_OK)return this.onEnd(v),!(this.ended=!0);A.next_out&&(A.avail_out!==0&&v!==a.Z_STREAM_END&&(A.avail_in!==0||w!==a.Z_FINISH&&w!==a.Z_SYNC_FLUSH)||(this.options.to==="string"?(x=o.utf8border(A.output,A.next_out),E=A.next_out-x,_=o.buf2string(A.output,x),A.next_out=E,A.avail_out=B-E,E&&l.arraySet(A.output,A.output,x,E,0),this.onData(_)):this.onData(l.shrinkBuf(A.output,A.next_out)))),A.avail_in===0&&A.avail_out===0&&(R=!0)}while((0<A.avail_in||A.avail_out===0)&&v!==a.Z_STREAM_END);return v===a.Z_STREAM_END&&(w=a.Z_FINISH),w===a.Z_FINISH?(v=r.inflateEnd(this.strm),this.onEnd(v),this.ended=!0,v===a.Z_OK):w!==a.Z_SYNC_FLUSH||(this.onEnd(a.Z_OK),!(A.avail_out=0))},p.prototype.onData=function(f){this.chunks.push(f)},p.prototype.onEnd=function(f){f===a.Z_OK&&(this.options.to==="string"?this.result=this.chunks.join(""):this.result=l.flattenChunks(this.chunks)),this.chunks=[],this.err=f,this.msg=this.strm.msg},s.Inflate=p,s.inflate=y,s.inflateRaw=function(f,k){return(k=k||{}).raw=!0,y(f,k)},s.ungzip=y},{"./utils/common":41,"./utils/strings":42,"./zlib/constants":44,"./zlib/gzheader":47,"./zlib/inflate":49,"./zlib/messages":51,"./zlib/zstream":53}],41:[function(e,n,s){var r=typeof Uint8Array<"u"&&typeof Uint16Array<"u"&&typeof Int32Array<"u";s.assign=function(a){for(var c=Array.prototype.slice.call(arguments,1);c.length;){var d=c.shift();if(d){if(typeof d!="object")throw new TypeError(d+"must be non-object");for(var h in d)d.hasOwnProperty(h)&&(a[h]=d[h])}}return a},s.shrinkBuf=function(a,c){return a.length===c?a:a.subarray?a.subarray(0,c):(a.length=c,a)};var l={arraySet:function(a,c,d,h,m){if(c.subarray&&a.subarray)a.set(c.subarray(d,d+h),m);else for(var p=0;p<h;p++)a[m+p]=c[d+p]},flattenChunks:function(a){var c,d,h,m,p,y;for(c=h=0,d=a.length;c<d;c++)h+=a[c].length;for(y=new Uint8Array(h),c=m=0,d=a.length;c<d;c++)p=a[c],y.set(p,m),m+=p.length;return y}},o={arraySet:function(a,c,d,h,m){for(var p=0;p<h;p++)a[m+p]=c[d+p]},flattenChunks:function(a){return[].concat.apply([],a)}};s.setTyped=function(a){a?(s.Buf8=Uint8Array,s.Buf16=Uint16Array,s.Buf32=Int32Array,s.assign(s,l)):(s.Buf8=Array,s.Buf16=Array,s.Buf32=Array,s.assign(s,o))},s.setTyped(r)},{}],42:[function(e,n,s){var r=e("./common"),l=!0,o=!0;try{String.fromCharCode.apply(null,[0])}catch{l=!1}try{String.fromCharCode.apply(null,new Uint8Array(1))}catch{o=!1}for(var a=new r.Buf8(256),c=0;c<256;c++)a[c]=252<=c?6:248<=c?5:240<=c?4:224<=c?3:192<=c?2:1;function d(h,m){if(m<65537&&(h.subarray&&o||!h.subarray&&l))return String.fromCharCode.apply(null,r.shrinkBuf(h,m));for(var p="",y=0;y<m;y++)p+=String.fromCharCode(h[y]);return p}a[254]=a[254]=1,s.string2buf=function(h){var m,p,y,f,k,v=h.length,w=0;for(f=0;f<v;f++)(64512&(p=h.charCodeAt(f)))==55296&&f+1<v&&(64512&(y=h.charCodeAt(f+1)))==56320&&(p=65536+(p-55296<<10)+(y-56320),f++),w+=p<128?1:p<2048?2:p<65536?3:4;for(m=new r.Buf8(w),f=k=0;k<w;f++)(64512&(p=h.charCodeAt(f)))==55296&&f+1<v&&(64512&(y=h.charCodeAt(f+1)))==56320&&(p=65536+(p-55296<<10)+(y-56320),f++),p<128?m[k++]=p:(p<2048?m[k++]=192|p>>>6:(p<65536?m[k++]=224|p>>>12:(m[k++]=240|p>>>18,m[k++]=128|p>>>12&63),m[k++]=128|p>>>6&63),m[k++]=128|63&p);return m},s.buf2binstring=function(h){return d(h,h.length)},s.binstring2buf=function(h){for(var m=new r.Buf8(h.length),p=0,y=m.length;p<y;p++)m[p]=h.charCodeAt(p);return m},s.buf2string=function(h,m){var p,y,f,k,v=m||h.length,w=new Array(2*v);for(p=y=0;p<v;)if((f=h[p++])<128)w[y++]=f;else if(4<(k=a[f]))w[y++]=65533,p+=k-1;else{for(f&=k===2?31:k===3?15:7;1<k&&p<v;)f=f<<6|63&h[p++],k--;1<k?w[y++]=65533:f<65536?w[y++]=f:(f-=65536,w[y++]=55296|f>>10&1023,w[y++]=56320|1023&f)}return d(w,y)},s.utf8border=function(h,m){var p;for((m=m||h.length)>h.length&&(m=h.length),p=m-1;0<=p&&(192&h[p])==128;)p--;return p<0||p===0?m:p+a[h[p]]>m?p:m}},{"./common":41}],43:[function(e,n,s){n.exports=function(r,l,o,a){for(var c=65535&r|0,d=r>>>16&65535|0,h=0;o!==0;){for(o-=h=2e3<o?2e3:o;d=d+(c=c+l[a++]|0)|0,--h;);c%=65521,d%=65521}return c|d<<16|0}},{}],44:[function(e,n,s){n.exports={Z_NO_FLUSH:0,Z_PARTIAL_FLUSH:1,Z_SYNC_FLUSH:2,Z_FULL_FLUSH:3,Z_FINISH:4,Z_BLOCK:5,Z_TREES:6,Z_OK:0,Z_STREAM_END:1,Z_NEED_DICT:2,Z_ERRNO:-1,Z_STREAM_ERROR:-2,Z_DATA_ERROR:-3,Z_BUF_ERROR:-5,Z_NO_COMPRESSION:0,Z_BEST_SPEED:1,Z_BEST_COMPRESSION:9,Z_DEFAULT_COMPRESSION:-1,Z_FILTERED:1,Z_HUFFMAN_ONLY:2,Z_RLE:3,Z_FIXED:4,Z_DEFAULT_STRATEGY:0,Z_BINARY:0,Z_TEXT:1,Z_UNKNOWN:2,Z_DEFLATED:8}},{}],45:[function(e,n,s){var r=(function(){for(var l,o=[],a=0;a<256;a++){l=a;for(var c=0;c<8;c++)l=1&l?3988292384^l>>>1:l>>>1;o[a]=l}return o})();n.exports=function(l,o,a,c){var d=r,h=c+a;l^=-1;for(var m=c;m<h;m++)l=l>>>8^d[255&(l^o[m])];return-1^l}},{}],46:[function(e,n,s){var r,l=e("../utils/common"),o=e("./trees"),a=e("./adler32"),c=e("./crc32"),d=e("./messages"),h=0,m=4,p=0,y=-2,f=-1,k=4,v=2,w=8,x=9,E=286,_=30,C=19,A=2*E+1,B=15,P=3,R=258,X=R+P+1,S=42,G=113,b=1,U=2,it=3,j=4;function st(u,z){return u.msg=d[z],z}function K(u){return(u<<1)-(4<u?9:0)}function Y(u){for(var z=u.length;0<=--z;)u[z]=0}function H(u){var z=u.state,D=z.pending;D>u.avail_out&&(D=u.avail_out),D!==0&&(l.arraySet(u.output,z.pending_buf,z.pending_out,D,u.next_out),u.next_out+=D,z.pending_out+=D,u.total_out+=D,u.avail_out-=D,z.pending-=D,z.pending===0&&(z.pending_out=0))}function L(u,z){o._tr_flush_block(u,0<=u.block_start?u.block_start:-1,u.strstart-u.block_start,z),u.block_start=u.strstart,H(u.strm)}function ct(u,z){u.pending_buf[u.pending++]=z}function rt(u,z){u.pending_buf[u.pending++]=z>>>8&255,u.pending_buf[u.pending++]=255&z}function ot(u,z){var D,$,I=u.max_chain_length,M=u.strstart,W=u.prev_length,N=u.nice_match,F=u.strstart>u.w_size-X?u.strstart-(u.w_size-X):0,q=u.window,et=u.w_mask,Q=u.prev,dt=u.strstart+R,xt=q[M+W-1],bt=q[M+W];u.prev_length>=u.good_match&&(I>>=2),N>u.lookahead&&(N=u.lookahead);do if(q[(D=z)+W]===bt&&q[D+W-1]===xt&&q[D]===q[M]&&q[++D]===q[M+1]){M+=2,D++;do;while(q[++M]===q[++D]&&q[++M]===q[++D]&&q[++M]===q[++D]&&q[++M]===q[++D]&&q[++M]===q[++D]&&q[++M]===q[++D]&&q[++M]===q[++D]&&q[++M]===q[++D]&&M<dt);if($=R-(dt-M),M=dt-R,W<$){if(u.match_start=z,N<=(W=$))break;xt=q[M+W-1],bt=q[M+W]}}while((z=Q[z&et])>F&&--I!=0);return W<=u.lookahead?W:u.lookahead}function J(u){var z,D,$,I,M,W,N,F,q,et,Q=u.w_size;do{if(I=u.window_size-u.lookahead-u.strstart,u.strstart>=Q+(Q-X)){for(l.arraySet(u.window,u.window,Q,Q,0),u.match_start-=Q,u.strstart-=Q,u.block_start-=Q,z=D=u.hash_size;$=u.head[--z],u.head[z]=Q<=$?$-Q:0,--D;);for(z=D=Q;$=u.prev[--z],u.prev[z]=Q<=$?$-Q:0,--D;);I+=Q}if(u.strm.avail_in===0)break;if(W=u.strm,N=u.window,F=u.strstart+u.lookahead,q=I,et=void 0,et=W.avail_in,q<et&&(et=q),D=et===0?0:(W.avail_in-=et,l.arraySet(N,W.input,W.next_in,et,F),W.state.wrap===1?W.adler=a(W.adler,N,et,F):W.state.wrap===2&&(W.adler=c(W.adler,N,et,F)),W.next_in+=et,W.total_in+=et,et),u.lookahead+=D,u.lookahead+u.insert>=P)for(M=u.strstart-u.insert,u.ins_h=u.window[M],u.ins_h=(u.ins_h<<u.hash_shift^u.window[M+1])&u.hash_mask;u.insert&&(u.ins_h=(u.ins_h<<u.hash_shift^u.window[M+P-1])&u.hash_mask,u.prev[M&u.w_mask]=u.head[u.ins_h],u.head[u.ins_h]=M,M++,u.insert--,!(u.lookahead+u.insert<P)););}while(u.lookahead<X&&u.strm.avail_in!==0)}function mt(u,z){for(var D,$;;){if(u.lookahead<X){if(J(u),u.lookahead<X&&z===h)return b;if(u.lookahead===0)break}if(D=0,u.lookahead>=P&&(u.ins_h=(u.ins_h<<u.hash_shift^u.window[u.strstart+P-1])&u.hash_mask,D=u.prev[u.strstart&u.w_mask]=u.head[u.ins_h],u.head[u.ins_h]=u.strstart),D!==0&&u.strstart-D<=u.w_size-X&&(u.match_length=ot(u,D)),u.match_length>=P)if($=o._tr_tally(u,u.strstart-u.match_start,u.match_length-P),u.lookahead-=u.match_length,u.match_length<=u.max_lazy_match&&u.lookahead>=P){for(u.match_length--;u.strstart++,u.ins_h=(u.ins_h<<u.hash_shift^u.window[u.strstart+P-1])&u.hash_mask,D=u.prev[u.strstart&u.w_mask]=u.head[u.ins_h],u.head[u.ins_h]=u.strstart,--u.match_length!=0;);u.strstart++}else u.strstart+=u.match_length,u.match_length=0,u.ins_h=u.window[u.strstart],u.ins_h=(u.ins_h<<u.hash_shift^u.window[u.strstart+1])&u.hash_mask;else $=o._tr_tally(u,0,u.window[u.strstart]),u.lookahead--,u.strstart++;if($&&(L(u,!1),u.strm.avail_out===0))return b}return u.insert=u.strstart<P-1?u.strstart:P-1,z===m?(L(u,!0),u.strm.avail_out===0?it:j):u.last_lit&&(L(u,!1),u.strm.avail_out===0)?b:U}function gt(u,z){for(var D,$,I;;){if(u.lookahead<X){if(J(u),u.lookahead<X&&z===h)return b;if(u.lookahead===0)break}if(D=0,u.lookahead>=P&&(u.ins_h=(u.ins_h<<u.hash_shift^u.window[u.strstart+P-1])&u.hash_mask,D=u.prev[u.strstart&u.w_mask]=u.head[u.ins_h],u.head[u.ins_h]=u.strstart),u.prev_length=u.match_length,u.prev_match=u.match_start,u.match_length=P-1,D!==0&&u.prev_length<u.max_lazy_match&&u.strstart-D<=u.w_size-X&&(u.match_length=ot(u,D),u.match_length<=5&&(u.strategy===1||u.match_length===P&&4096<u.strstart-u.match_start)&&(u.match_length=P-1)),u.prev_length>=P&&u.match_length<=u.prev_length){for(I=u.strstart+u.lookahead-P,$=o._tr_tally(u,u.strstart-1-u.prev_match,u.prev_length-P),u.lookahead-=u.prev_length-1,u.prev_length-=2;++u.strstart<=I&&(u.ins_h=(u.ins_h<<u.hash_shift^u.window[u.strstart+P-1])&u.hash_mask,D=u.prev[u.strstart&u.w_mask]=u.head[u.ins_h],u.head[u.ins_h]=u.strstart),--u.prev_length!=0;);if(u.match_available=0,u.match_length=P-1,u.strstart++,$&&(L(u,!1),u.strm.avail_out===0))return b}else if(u.match_available){if(($=o._tr_tally(u,0,u.window[u.strstart-1]))&&L(u,!1),u.strstart++,u.lookahead--,u.strm.avail_out===0)return b}else u.match_available=1,u.strstart++,u.lookahead--}return u.match_available&&($=o._tr_tally(u,0,u.window[u.strstart-1]),u.match_available=0),u.insert=u.strstart<P-1?u.strstart:P-1,z===m?(L(u,!0),u.strm.avail_out===0?it:j):u.last_lit&&(L(u,!1),u.strm.avail_out===0)?b:U}function Z(u,z,D,$,I){this.good_length=u,this.max_lazy=z,this.nice_length=D,this.max_chain=$,this.func=I}function lt(){this.strm=null,this.status=0,this.pending_buf=null,this.pending_buf_size=0,this.pending_out=0,this.pending=0,this.wrap=0,this.gzhead=null,this.gzindex=0,this.method=w,this.last_flush=-1,this.w_size=0,this.w_bits=0,this.w_mask=0,this.window=null,this.window_size=0,this.prev=null,this.head=null,this.ins_h=0,this.hash_size=0,this.hash_bits=0,this.hash_mask=0,this.hash_shift=0,this.block_start=0,this.match_length=0,this.prev_match=0,this.match_available=0,this.strstart=0,this.match_start=0,this.lookahead=0,this.prev_length=0,this.max_chain_length=0,this.max_lazy_match=0,this.level=0,this.strategy=0,this.good_match=0,this.nice_match=0,this.dyn_ltree=new l.Buf16(2*A),this.dyn_dtree=new l.Buf16(2*(2*_+1)),this.bl_tree=new l.Buf16(2*(2*C+1)),Y(this.dyn_ltree),Y(this.dyn_dtree),Y(this.bl_tree),this.l_desc=null,this.d_desc=null,this.bl_desc=null,this.bl_count=new l.Buf16(B+1),this.heap=new l.Buf16(2*E+1),Y(this.heap),this.heap_len=0,this.heap_max=0,this.depth=new l.Buf16(2*E+1),Y(this.depth),this.l_buf=0,this.lit_bufsize=0,this.last_lit=0,this.d_buf=0,this.opt_len=0,this.static_len=0,this.matches=0,this.insert=0,this.bi_buf=0,this.bi_valid=0}function ut(u){var z;return u&&u.state?(u.total_in=u.total_out=0,u.data_type=v,(z=u.state).pending=0,z.pending_out=0,z.wrap<0&&(z.wrap=-z.wrap),z.status=z.wrap?S:G,u.adler=z.wrap===2?0:1,z.last_flush=h,o._tr_init(z),p):st(u,y)}function T(u){var z=ut(u);return z===p&&(function(D){D.window_size=2*D.w_size,Y(D.head),D.max_lazy_match=r[D.level].max_lazy,D.good_match=r[D.level].good_length,D.nice_match=r[D.level].nice_length,D.max_chain_length=r[D.level].max_chain,D.strstart=0,D.block_start=0,D.lookahead=0,D.insert=0,D.match_length=D.prev_length=P-1,D.match_available=0,D.ins_h=0})(u.state),z}function O(u,z,D,$,I,M){if(!u)return y;var W=1;if(z===f&&(z=6),$<0?(W=0,$=-$):15<$&&(W=2,$-=16),I<1||x<I||D!==w||$<8||15<$||z<0||9<z||M<0||k<M)return st(u,y);$===8&&($=9);var N=new lt;return(u.state=N).strm=u,N.wrap=W,N.gzhead=null,N.w_bits=$,N.w_size=1<<N.w_bits,N.w_mask=N.w_size-1,N.hash_bits=I+7,N.hash_size=1<<N.hash_bits,N.hash_mask=N.hash_size-1,N.hash_shift=~~((N.hash_bits+P-1)/P),N.window=new l.Buf8(2*N.w_size),N.head=new l.Buf16(N.hash_size),N.prev=new l.Buf16(N.w_size),N.lit_bufsize=1<<I+6,N.pending_buf_size=4*N.lit_bufsize,N.pending_buf=new l.Buf8(N.pending_buf_size),N.d_buf=1*N.lit_bufsize,N.l_buf=3*N.lit_bufsize,N.level=z,N.strategy=M,N.method=D,T(u)}r=[new Z(0,0,0,0,function(u,z){var D=65535;for(D>u.pending_buf_size-5&&(D=u.pending_buf_size-5);;){if(u.lookahead<=1){if(J(u),u.lookahead===0&&z===h)return b;if(u.lookahead===0)break}u.strstart+=u.lookahead,u.lookahead=0;var $=u.block_start+D;if((u.strstart===0||u.strstart>=$)&&(u.lookahead=u.strstart-$,u.strstart=$,L(u,!1),u.strm.avail_out===0)||u.strstart-u.block_start>=u.w_size-X&&(L(u,!1),u.strm.avail_out===0))return b}return u.insert=0,z===m?(L(u,!0),u.strm.avail_out===0?it:j):(u.strstart>u.block_start&&(L(u,!1),u.strm.avail_out),b)}),new Z(4,4,8,4,mt),new Z(4,5,16,8,mt),new Z(4,6,32,32,mt),new Z(4,4,16,16,gt),new Z(8,16,32,32,gt),new Z(8,16,128,128,gt),new Z(8,32,128,256,gt),new Z(32,128,258,1024,gt),new Z(32,258,258,4096,gt)],s.deflateInit=function(u,z){return O(u,z,w,15,8,0)},s.deflateInit2=O,s.deflateReset=T,s.deflateResetKeep=ut,s.deflateSetHeader=function(u,z){return u&&u.state?u.state.wrap!==2?y:(u.state.gzhead=z,p):y},s.deflate=function(u,z){var D,$,I,M;if(!u||!u.state||5<z||z<0)return u?st(u,y):y;if($=u.state,!u.output||!u.input&&u.avail_in!==0||$.status===666&&z!==m)return st(u,u.avail_out===0?-5:y);if($.strm=u,D=$.last_flush,$.last_flush=z,$.status===S)if($.wrap===2)u.adler=0,ct($,31),ct($,139),ct($,8),$.gzhead?(ct($,($.gzhead.text?1:0)+($.gzhead.hcrc?2:0)+($.gzhead.extra?4:0)+($.gzhead.name?8:0)+($.gzhead.comment?16:0)),ct($,255&$.gzhead.time),ct($,$.gzhead.time>>8&255),ct($,$.gzhead.time>>16&255),ct($,$.gzhead.time>>24&255),ct($,$.level===9?2:2<=$.strategy||$.level<2?4:0),ct($,255&$.gzhead.os),$.gzhead.extra&&$.gzhead.extra.length&&(ct($,255&$.gzhead.extra.length),ct($,$.gzhead.extra.length>>8&255)),$.gzhead.hcrc&&(u.adler=c(u.adler,$.pending_buf,$.pending,0)),$.gzindex=0,$.status=69):(ct($,0),ct($,0),ct($,0),ct($,0),ct($,0),ct($,$.level===9?2:2<=$.strategy||$.level<2?4:0),ct($,3),$.status=G);else{var W=w+($.w_bits-8<<4)<<8;W|=(2<=$.strategy||$.level<2?0:$.level<6?1:$.level===6?2:3)<<6,$.strstart!==0&&(W|=32),W+=31-W%31,$.status=G,rt($,W),$.strstart!==0&&(rt($,u.adler>>>16),rt($,65535&u.adler)),u.adler=1}if($.status===69)if($.gzhead.extra){for(I=$.pending;$.gzindex<(65535&$.gzhead.extra.length)&&($.pending!==$.pending_buf_size||($.gzhead.hcrc&&$.pending>I&&(u.adler=c(u.adler,$.pending_buf,$.pending-I,I)),H(u),I=$.pending,$.pending!==$.pending_buf_size));)ct($,255&$.gzhead.extra[$.gzindex]),$.gzindex++;$.gzhead.hcrc&&$.pending>I&&(u.adler=c(u.adler,$.pending_buf,$.pending-I,I)),$.gzindex===$.gzhead.extra.length&&($.gzindex=0,$.status=73)}else $.status=73;if($.status===73)if($.gzhead.name){I=$.pending;do{if($.pending===$.pending_buf_size&&($.gzhead.hcrc&&$.pending>I&&(u.adler=c(u.adler,$.pending_buf,$.pending-I,I)),H(u),I=$.pending,$.pending===$.pending_buf_size)){M=1;break}M=$.gzindex<$.gzhead.name.length?255&$.gzhead.name.charCodeAt($.gzindex++):0,ct($,M)}while(M!==0);$.gzhead.hcrc&&$.pending>I&&(u.adler=c(u.adler,$.pending_buf,$.pending-I,I)),M===0&&($.gzindex=0,$.status=91)}else $.status=91;if($.status===91)if($.gzhead.comment){I=$.pending;do{if($.pending===$.pending_buf_size&&($.gzhead.hcrc&&$.pending>I&&(u.adler=c(u.adler,$.pending_buf,$.pending-I,I)),H(u),I=$.pending,$.pending===$.pending_buf_size)){M=1;break}M=$.gzindex<$.gzhead.comment.length?255&$.gzhead.comment.charCodeAt($.gzindex++):0,ct($,M)}while(M!==0);$.gzhead.hcrc&&$.pending>I&&(u.adler=c(u.adler,$.pending_buf,$.pending-I,I)),M===0&&($.status=103)}else $.status=103;if($.status===103&&($.gzhead.hcrc?($.pending+2>$.pending_buf_size&&H(u),$.pending+2<=$.pending_buf_size&&(ct($,255&u.adler),ct($,u.adler>>8&255),u.adler=0,$.status=G)):$.status=G),$.pending!==0){if(H(u),u.avail_out===0)return $.last_flush=-1,p}else if(u.avail_in===0&&K(z)<=K(D)&&z!==m)return st(u,-5);if($.status===666&&u.avail_in!==0)return st(u,-5);if(u.avail_in!==0||$.lookahead!==0||z!==h&&$.status!==666){var N=$.strategy===2?(function(F,q){for(var et;;){if(F.lookahead===0&&(J(F),F.lookahead===0)){if(q===h)return b;break}if(F.match_length=0,et=o._tr_tally(F,0,F.window[F.strstart]),F.lookahead--,F.strstart++,et&&(L(F,!1),F.strm.avail_out===0))return b}return F.insert=0,q===m?(L(F,!0),F.strm.avail_out===0?it:j):F.last_lit&&(L(F,!1),F.strm.avail_out===0)?b:U})($,z):$.strategy===3?(function(F,q){for(var et,Q,dt,xt,bt=F.window;;){if(F.lookahead<=R){if(J(F),F.lookahead<=R&&q===h)return b;if(F.lookahead===0)break}if(F.match_length=0,F.lookahead>=P&&0<F.strstart&&(Q=bt[dt=F.strstart-1])===bt[++dt]&&Q===bt[++dt]&&Q===bt[++dt]){xt=F.strstart+R;do;while(Q===bt[++dt]&&Q===bt[++dt]&&Q===bt[++dt]&&Q===bt[++dt]&&Q===bt[++dt]&&Q===bt[++dt]&&Q===bt[++dt]&&Q===bt[++dt]&&dt<xt);F.match_length=R-(xt-dt),F.match_length>F.lookahead&&(F.match_length=F.lookahead)}if(F.match_length>=P?(et=o._tr_tally(F,1,F.match_length-P),F.lookahead-=F.match_length,F.strstart+=F.match_length,F.match_length=0):(et=o._tr_tally(F,0,F.window[F.strstart]),F.lookahead--,F.strstart++),et&&(L(F,!1),F.strm.avail_out===0))return b}return F.insert=0,q===m?(L(F,!0),F.strm.avail_out===0?it:j):F.last_lit&&(L(F,!1),F.strm.avail_out===0)?b:U})($,z):r[$.level].func($,z);if(N!==it&&N!==j||($.status=666),N===b||N===it)return u.avail_out===0&&($.last_flush=-1),p;if(N===U&&(z===1?o._tr_align($):z!==5&&(o._tr_stored_block($,0,0,!1),z===3&&(Y($.head),$.lookahead===0&&($.strstart=0,$.block_start=0,$.insert=0))),H(u),u.avail_out===0))return $.last_flush=-1,p}return z!==m?p:$.wrap<=0?1:($.wrap===2?(ct($,255&u.adler),ct($,u.adler>>8&255),ct($,u.adler>>16&255),ct($,u.adler>>24&255),ct($,255&u.total_in),ct($,u.total_in>>8&255),ct($,u.total_in>>16&255),ct($,u.total_in>>24&255)):(rt($,u.adler>>>16),rt($,65535&u.adler)),H(u),0<$.wrap&&($.wrap=-$.wrap),$.pending!==0?p:1)},s.deflateEnd=function(u){var z;return u&&u.state?(z=u.state.status)!==S&&z!==69&&z!==73&&z!==91&&z!==103&&z!==G&&z!==666?st(u,y):(u.state=null,z===G?st(u,-3):p):y},s.deflateSetDictionary=function(u,z){var D,$,I,M,W,N,F,q,et=z.length;if(!u||!u.state||(M=(D=u.state).wrap)===2||M===1&&D.status!==S||D.lookahead)return y;for(M===1&&(u.adler=a(u.adler,z,et,0)),D.wrap=0,et>=D.w_size&&(M===0&&(Y(D.head),D.strstart=0,D.block_start=0,D.insert=0),q=new l.Buf8(D.w_size),l.arraySet(q,z,et-D.w_size,D.w_size,0),z=q,et=D.w_size),W=u.avail_in,N=u.next_in,F=u.input,u.avail_in=et,u.next_in=0,u.input=z,J(D);D.lookahead>=P;){for($=D.strstart,I=D.lookahead-(P-1);D.ins_h=(D.ins_h<<D.hash_shift^D.window[$+P-1])&D.hash_mask,D.prev[$&D.w_mask]=D.head[D.ins_h],D.head[D.ins_h]=$,$++,--I;);D.strstart=$,D.lookahead=P-1,J(D)}return D.strstart+=D.lookahead,D.block_start=D.strstart,D.insert=D.lookahead,D.lookahead=0,D.match_length=D.prev_length=P-1,D.match_available=0,u.next_in=N,u.input=F,u.avail_in=W,D.wrap=M,p},s.deflateInfo="pako deflate (from Nodeca project)"},{"../utils/common":41,"./adler32":43,"./crc32":45,"./messages":51,"./trees":52}],47:[function(e,n,s){n.exports=function(){this.text=0,this.time=0,this.xflags=0,this.os=0,this.extra=null,this.extra_len=0,this.name="",this.comment="",this.hcrc=0,this.done=!1}},{}],48:[function(e,n,s){n.exports=function(r,l){var o,a,c,d,h,m,p,y,f,k,v,w,x,E,_,C,A,B,P,R,X,S,G,b,U;o=r.state,a=r.next_in,b=r.input,c=a+(r.avail_in-5),d=r.next_out,U=r.output,h=d-(l-r.avail_out),m=d+(r.avail_out-257),p=o.dmax,y=o.wsize,f=o.whave,k=o.wnext,v=o.window,w=o.hold,x=o.bits,E=o.lencode,_=o.distcode,C=(1<<o.lenbits)-1,A=(1<<o.distbits)-1;t:do{x<15&&(w+=b[a++]<<x,x+=8,w+=b[a++]<<x,x+=8),B=E[w&C];e:for(;;){if(w>>>=P=B>>>24,x-=P,(P=B>>>16&255)===0)U[d++]=65535&B;else{if(!(16&P)){if((64&P)==0){B=E[(65535&B)+(w&(1<<P)-1)];continue e}if(32&P){o.mode=12;break t}r.msg="invalid literal/length code",o.mode=30;break t}R=65535&B,(P&=15)&&(x<P&&(w+=b[a++]<<x,x+=8),R+=w&(1<<P)-1,w>>>=P,x-=P),x<15&&(w+=b[a++]<<x,x+=8,w+=b[a++]<<x,x+=8),B=_[w&A];i:for(;;){if(w>>>=P=B>>>24,x-=P,!(16&(P=B>>>16&255))){if((64&P)==0){B=_[(65535&B)+(w&(1<<P)-1)];continue i}r.msg="invalid distance code",o.mode=30;break t}if(X=65535&B,x<(P&=15)&&(w+=b[a++]<<x,(x+=8)<P&&(w+=b[a++]<<x,x+=8)),p<(X+=w&(1<<P)-1)){r.msg="invalid distance too far back",o.mode=30;break t}if(w>>>=P,x-=P,(P=d-h)<X){if(f<(P=X-P)&&o.sane){r.msg="invalid distance too far back",o.mode=30;break t}if(G=v,(S=0)===k){if(S+=y-P,P<R){for(R-=P;U[d++]=v[S++],--P;);S=d-X,G=U}}else if(k<P){if(S+=y+k-P,(P-=k)<R){for(R-=P;U[d++]=v[S++],--P;);if(S=0,k<R){for(R-=P=k;U[d++]=v[S++],--P;);S=d-X,G=U}}}else if(S+=k-P,P<R){for(R-=P;U[d++]=v[S++],--P;);S=d-X,G=U}for(;2<R;)U[d++]=G[S++],U[d++]=G[S++],U[d++]=G[S++],R-=3;R&&(U[d++]=G[S++],1<R&&(U[d++]=G[S++]))}else{for(S=d-X;U[d++]=U[S++],U[d++]=U[S++],U[d++]=U[S++],2<(R-=3););R&&(U[d++]=U[S++],1<R&&(U[d++]=U[S++]))}break}}break}}while(a<c&&d<m);a-=R=x>>3,w&=(1<<(x-=R<<3))-1,r.next_in=a,r.next_out=d,r.avail_in=a<c?c-a+5:5-(a-c),r.avail_out=d<m?m-d+257:257-(d-m),o.hold=w,o.bits=x}},{}],49:[function(e,n,s){var r=e("../utils/common"),l=e("./adler32"),o=e("./crc32"),a=e("./inffast"),c=e("./inftrees"),d=1,h=2,m=0,p=-2,y=1,f=852,k=592;function v(S){return(S>>>24&255)+(S>>>8&65280)+((65280&S)<<8)+((255&S)<<24)}function w(){this.mode=0,this.last=!1,this.wrap=0,this.havedict=!1,this.flags=0,this.dmax=0,this.check=0,this.total=0,this.head=null,this.wbits=0,this.wsize=0,this.whave=0,this.wnext=0,this.window=null,this.hold=0,this.bits=0,this.length=0,this.offset=0,this.extra=0,this.lencode=null,this.distcode=null,this.lenbits=0,this.distbits=0,this.ncode=0,this.nlen=0,this.ndist=0,this.have=0,this.next=null,this.lens=new r.Buf16(320),this.work=new r.Buf16(288),this.lendyn=null,this.distdyn=null,this.sane=0,this.back=0,this.was=0}function x(S){var G;return S&&S.state?(G=S.state,S.total_in=S.total_out=G.total=0,S.msg="",G.wrap&&(S.adler=1&G.wrap),G.mode=y,G.last=0,G.havedict=0,G.dmax=32768,G.head=null,G.hold=0,G.bits=0,G.lencode=G.lendyn=new r.Buf32(f),G.distcode=G.distdyn=new r.Buf32(k),G.sane=1,G.back=-1,m):p}function E(S){var G;return S&&S.state?((G=S.state).wsize=0,G.whave=0,G.wnext=0,x(S)):p}function _(S,G){var b,U;return S&&S.state?(U=S.state,G<0?(b=0,G=-G):(b=1+(G>>4),G<48&&(G&=15)),G&&(G<8||15<G)?p:(U.window!==null&&U.wbits!==G&&(U.window=null),U.wrap=b,U.wbits=G,E(S))):p}function C(S,G){var b,U;return S?(U=new w,(S.state=U).window=null,(b=_(S,G))!==m&&(S.state=null),b):p}var A,B,P=!0;function R(S){if(P){var G;for(A=new r.Buf32(512),B=new r.Buf32(32),G=0;G<144;)S.lens[G++]=8;for(;G<256;)S.lens[G++]=9;for(;G<280;)S.lens[G++]=7;for(;G<288;)S.lens[G++]=8;for(c(d,S.lens,0,288,A,0,S.work,{bits:9}),G=0;G<32;)S.lens[G++]=5;c(h,S.lens,0,32,B,0,S.work,{bits:5}),P=!1}S.lencode=A,S.lenbits=9,S.distcode=B,S.distbits=5}function X(S,G,b,U){var it,j=S.state;return j.window===null&&(j.wsize=1<<j.wbits,j.wnext=0,j.whave=0,j.window=new r.Buf8(j.wsize)),U>=j.wsize?(r.arraySet(j.window,G,b-j.wsize,j.wsize,0),j.wnext=0,j.whave=j.wsize):(U<(it=j.wsize-j.wnext)&&(it=U),r.arraySet(j.window,G,b-U,it,j.wnext),(U-=it)?(r.arraySet(j.window,G,b-U,U,0),j.wnext=U,j.whave=j.wsize):(j.wnext+=it,j.wnext===j.wsize&&(j.wnext=0),j.whave<j.wsize&&(j.whave+=it))),0}s.inflateReset=E,s.inflateReset2=_,s.inflateResetKeep=x,s.inflateInit=function(S){return C(S,15)},s.inflateInit2=C,s.inflate=function(S,G){var b,U,it,j,st,K,Y,H,L,ct,rt,ot,J,mt,gt,Z,lt,ut,T,O,u,z,D,$,I=0,M=new r.Buf8(4),W=[16,17,18,0,8,7,9,6,10,5,11,4,12,3,13,2,14,1,15];if(!S||!S.state||!S.output||!S.input&&S.avail_in!==0)return p;(b=S.state).mode===12&&(b.mode=13),st=S.next_out,it=S.output,Y=S.avail_out,j=S.next_in,U=S.input,K=S.avail_in,H=b.hold,L=b.bits,ct=K,rt=Y,z=m;t:for(;;)switch(b.mode){case y:if(b.wrap===0){b.mode=13;break}for(;L<16;){if(K===0)break t;K--,H+=U[j++]<<L,L+=8}if(2&b.wrap&&H===35615){M[b.check=0]=255&H,M[1]=H>>>8&255,b.check=o(b.check,M,2,0),L=H=0,b.mode=2;break}if(b.flags=0,b.head&&(b.head.done=!1),!(1&b.wrap)||(((255&H)<<8)+(H>>8))%31){S.msg="incorrect header check",b.mode=30;break}if((15&H)!=8){S.msg="unknown compression method",b.mode=30;break}if(L-=4,u=8+(15&(H>>>=4)),b.wbits===0)b.wbits=u;else if(u>b.wbits){S.msg="invalid window size",b.mode=30;break}b.dmax=1<<u,S.adler=b.check=1,b.mode=512&H?10:12,L=H=0;break;case 2:for(;L<16;){if(K===0)break t;K--,H+=U[j++]<<L,L+=8}if(b.flags=H,(255&b.flags)!=8){S.msg="unknown compression method",b.mode=30;break}if(57344&b.flags){S.msg="unknown header flags set",b.mode=30;break}b.head&&(b.head.text=H>>8&1),512&b.flags&&(M[0]=255&H,M[1]=H>>>8&255,b.check=o(b.check,M,2,0)),L=H=0,b.mode=3;case 3:for(;L<32;){if(K===0)break t;K--,H+=U[j++]<<L,L+=8}b.head&&(b.head.time=H),512&b.flags&&(M[0]=255&H,M[1]=H>>>8&255,M[2]=H>>>16&255,M[3]=H>>>24&255,b.check=o(b.check,M,4,0)),L=H=0,b.mode=4;case 4:for(;L<16;){if(K===0)break t;K--,H+=U[j++]<<L,L+=8}b.head&&(b.head.xflags=255&H,b.head.os=H>>8),512&b.flags&&(M[0]=255&H,M[1]=H>>>8&255,b.check=o(b.check,M,2,0)),L=H=0,b.mode=5;case 5:if(1024&b.flags){for(;L<16;){if(K===0)break t;K--,H+=U[j++]<<L,L+=8}b.length=H,b.head&&(b.head.extra_len=H),512&b.flags&&(M[0]=255&H,M[1]=H>>>8&255,b.check=o(b.check,M,2,0)),L=H=0}else b.head&&(b.head.extra=null);b.mode=6;case 6:if(1024&b.flags&&(K<(ot=b.length)&&(ot=K),ot&&(b.head&&(u=b.head.extra_len-b.length,b.head.extra||(b.head.extra=new Array(b.head.extra_len)),r.arraySet(b.head.extra,U,j,ot,u)),512&b.flags&&(b.check=o(b.check,U,ot,j)),K-=ot,j+=ot,b.length-=ot),b.length))break t;b.length=0,b.mode=7;case 7:if(2048&b.flags){if(K===0)break t;for(ot=0;u=U[j+ot++],b.head&&u&&b.length<65536&&(b.head.name+=String.fromCharCode(u)),u&&ot<K;);if(512&b.flags&&(b.check=o(b.check,U,ot,j)),K-=ot,j+=ot,u)break t}else b.head&&(b.head.name=null);b.length=0,b.mode=8;case 8:if(4096&b.flags){if(K===0)break t;for(ot=0;u=U[j+ot++],b.head&&u&&b.length<65536&&(b.head.comment+=String.fromCharCode(u)),u&&ot<K;);if(512&b.flags&&(b.check=o(b.check,U,ot,j)),K-=ot,j+=ot,u)break t}else b.head&&(b.head.comment=null);b.mode=9;case 9:if(512&b.flags){for(;L<16;){if(K===0)break t;K--,H+=U[j++]<<L,L+=8}if(H!==(65535&b.check)){S.msg="header crc mismatch",b.mode=30;break}L=H=0}b.head&&(b.head.hcrc=b.flags>>9&1,b.head.done=!0),S.adler=b.check=0,b.mode=12;break;case 10:for(;L<32;){if(K===0)break t;K--,H+=U[j++]<<L,L+=8}S.adler=b.check=v(H),L=H=0,b.mode=11;case 11:if(b.havedict===0)return S.next_out=st,S.avail_out=Y,S.next_in=j,S.avail_in=K,b.hold=H,b.bits=L,2;S.adler=b.check=1,b.mode=12;case 12:if(G===5||G===6)break t;case 13:if(b.last){H>>>=7&L,L-=7&L,b.mode=27;break}for(;L<3;){if(K===0)break t;K--,H+=U[j++]<<L,L+=8}switch(b.last=1&H,L-=1,3&(H>>>=1)){case 0:b.mode=14;break;case 1:if(R(b),b.mode=20,G!==6)break;H>>>=2,L-=2;break t;case 2:b.mode=17;break;case 3:S.msg="invalid block type",b.mode=30}H>>>=2,L-=2;break;case 14:for(H>>>=7&L,L-=7&L;L<32;){if(K===0)break t;K--,H+=U[j++]<<L,L+=8}if((65535&H)!=(H>>>16^65535)){S.msg="invalid stored block lengths",b.mode=30;break}if(b.length=65535&H,L=H=0,b.mode=15,G===6)break t;case 15:b.mode=16;case 16:if(ot=b.length){if(K<ot&&(ot=K),Y<ot&&(ot=Y),ot===0)break t;r.arraySet(it,U,j,ot,st),K-=ot,j+=ot,Y-=ot,st+=ot,b.length-=ot;break}b.mode=12;break;case 17:for(;L<14;){if(K===0)break t;K--,H+=U[j++]<<L,L+=8}if(b.nlen=257+(31&H),H>>>=5,L-=5,b.ndist=1+(31&H),H>>>=5,L-=5,b.ncode=4+(15&H),H>>>=4,L-=4,286<b.nlen||30<b.ndist){S.msg="too many length or distance symbols",b.mode=30;break}b.have=0,b.mode=18;case 18:for(;b.have<b.ncode;){for(;L<3;){if(K===0)break t;K--,H+=U[j++]<<L,L+=8}b.lens[W[b.have++]]=7&H,H>>>=3,L-=3}for(;b.have<19;)b.lens[W[b.have++]]=0;if(b.lencode=b.lendyn,b.lenbits=7,D={bits:b.lenbits},z=c(0,b.lens,0,19,b.lencode,0,b.work,D),b.lenbits=D.bits,z){S.msg="invalid code lengths set",b.mode=30;break}b.have=0,b.mode=19;case 19:for(;b.have<b.nlen+b.ndist;){for(;Z=(I=b.lencode[H&(1<<b.lenbits)-1])>>>16&255,lt=65535&I,!((gt=I>>>24)<=L);){if(K===0)break t;K--,H+=U[j++]<<L,L+=8}if(lt<16)H>>>=gt,L-=gt,b.lens[b.have++]=lt;else{if(lt===16){for($=gt+2;L<$;){if(K===0)break t;K--,H+=U[j++]<<L,L+=8}if(H>>>=gt,L-=gt,b.have===0){S.msg="invalid bit length repeat",b.mode=30;break}u=b.lens[b.have-1],ot=3+(3&H),H>>>=2,L-=2}else if(lt===17){for($=gt+3;L<$;){if(K===0)break t;K--,H+=U[j++]<<L,L+=8}L-=gt,u=0,ot=3+(7&(H>>>=gt)),H>>>=3,L-=3}else{for($=gt+7;L<$;){if(K===0)break t;K--,H+=U[j++]<<L,L+=8}L-=gt,u=0,ot=11+(127&(H>>>=gt)),H>>>=7,L-=7}if(b.have+ot>b.nlen+b.ndist){S.msg="invalid bit length repeat",b.mode=30;break}for(;ot--;)b.lens[b.have++]=u}}if(b.mode===30)break;if(b.lens[256]===0){S.msg="invalid code -- missing end-of-block",b.mode=30;break}if(b.lenbits=9,D={bits:b.lenbits},z=c(d,b.lens,0,b.nlen,b.lencode,0,b.work,D),b.lenbits=D.bits,z){S.msg="invalid literal/lengths set",b.mode=30;break}if(b.distbits=6,b.distcode=b.distdyn,D={bits:b.distbits},z=c(h,b.lens,b.nlen,b.ndist,b.distcode,0,b.work,D),b.distbits=D.bits,z){S.msg="invalid distances set",b.mode=30;break}if(b.mode=20,G===6)break t;case 20:b.mode=21;case 21:if(6<=K&&258<=Y){S.next_out=st,S.avail_out=Y,S.next_in=j,S.avail_in=K,b.hold=H,b.bits=L,a(S,rt),st=S.next_out,it=S.output,Y=S.avail_out,j=S.next_in,U=S.input,K=S.avail_in,H=b.hold,L=b.bits,b.mode===12&&(b.back=-1);break}for(b.back=0;Z=(I=b.lencode[H&(1<<b.lenbits)-1])>>>16&255,lt=65535&I,!((gt=I>>>24)<=L);){if(K===0)break t;K--,H+=U[j++]<<L,L+=8}if(Z&&(240&Z)==0){for(ut=gt,T=Z,O=lt;Z=(I=b.lencode[O+((H&(1<<ut+T)-1)>>ut)])>>>16&255,lt=65535&I,!(ut+(gt=I>>>24)<=L);){if(K===0)break t;K--,H+=U[j++]<<L,L+=8}H>>>=ut,L-=ut,b.back+=ut}if(H>>>=gt,L-=gt,b.back+=gt,b.length=lt,Z===0){b.mode=26;break}if(32&Z){b.back=-1,b.mode=12;break}if(64&Z){S.msg="invalid literal/length code",b.mode=30;break}b.extra=15&Z,b.mode=22;case 22:if(b.extra){for($=b.extra;L<$;){if(K===0)break t;K--,H+=U[j++]<<L,L+=8}b.length+=H&(1<<b.extra)-1,H>>>=b.extra,L-=b.extra,b.back+=b.extra}b.was=b.length,b.mode=23;case 23:for(;Z=(I=b.distcode[H&(1<<b.distbits)-1])>>>16&255,lt=65535&I,!((gt=I>>>24)<=L);){if(K===0)break t;K--,H+=U[j++]<<L,L+=8}if((240&Z)==0){for(ut=gt,T=Z,O=lt;Z=(I=b.distcode[O+((H&(1<<ut+T)-1)>>ut)])>>>16&255,lt=65535&I,!(ut+(gt=I>>>24)<=L);){if(K===0)break t;K--,H+=U[j++]<<L,L+=8}H>>>=ut,L-=ut,b.back+=ut}if(H>>>=gt,L-=gt,b.back+=gt,64&Z){S.msg="invalid distance code",b.mode=30;break}b.offset=lt,b.extra=15&Z,b.mode=24;case 24:if(b.extra){for($=b.extra;L<$;){if(K===0)break t;K--,H+=U[j++]<<L,L+=8}b.offset+=H&(1<<b.extra)-1,H>>>=b.extra,L-=b.extra,b.back+=b.extra}if(b.offset>b.dmax){S.msg="invalid distance too far back",b.mode=30;break}b.mode=25;case 25:if(Y===0)break t;if(ot=rt-Y,b.offset>ot){if((ot=b.offset-ot)>b.whave&&b.sane){S.msg="invalid distance too far back",b.mode=30;break}J=ot>b.wnext?(ot-=b.wnext,b.wsize-ot):b.wnext-ot,ot>b.length&&(ot=b.length),mt=b.window}else mt=it,J=st-b.offset,ot=b.length;for(Y<ot&&(ot=Y),Y-=ot,b.length-=ot;it[st++]=mt[J++],--ot;);b.length===0&&(b.mode=21);break;case 26:if(Y===0)break t;it[st++]=b.length,Y--,b.mode=21;break;case 27:if(b.wrap){for(;L<32;){if(K===0)break t;K--,H|=U[j++]<<L,L+=8}if(rt-=Y,S.total_out+=rt,b.total+=rt,rt&&(S.adler=b.check=b.flags?o(b.check,it,rt,st-rt):l(b.check,it,rt,st-rt)),rt=Y,(b.flags?H:v(H))!==b.check){S.msg="incorrect data check",b.mode=30;break}L=H=0}b.mode=28;case 28:if(b.wrap&&b.flags){for(;L<32;){if(K===0)break t;K--,H+=U[j++]<<L,L+=8}if(H!==(4294967295&b.total)){S.msg="incorrect length check",b.mode=30;break}L=H=0}b.mode=29;case 29:z=1;break t;case 30:z=-3;break t;case 31:return-4;case 32:default:return p}return S.next_out=st,S.avail_out=Y,S.next_in=j,S.avail_in=K,b.hold=H,b.bits=L,(b.wsize||rt!==S.avail_out&&b.mode<30&&(b.mode<27||G!==4))&&X(S,S.output,S.next_out,rt-S.avail_out)?(b.mode=31,-4):(ct-=S.avail_in,rt-=S.avail_out,S.total_in+=ct,S.total_out+=rt,b.total+=rt,b.wrap&&rt&&(S.adler=b.check=b.flags?o(b.check,it,rt,S.next_out-rt):l(b.check,it,rt,S.next_out-rt)),S.data_type=b.bits+(b.last?64:0)+(b.mode===12?128:0)+(b.mode===20||b.mode===15?256:0),(ct==0&&rt===0||G===4)&&z===m&&(z=-5),z)},s.inflateEnd=function(S){if(!S||!S.state)return p;var G=S.state;return G.window&&(G.window=null),S.state=null,m},s.inflateGetHeader=function(S,G){var b;return S&&S.state?(2&(b=S.state).wrap)==0?p:((b.head=G).done=!1,m):p},s.inflateSetDictionary=function(S,G){var b,U=G.length;return S&&S.state?(b=S.state).wrap!==0&&b.mode!==11?p:b.mode===11&&l(1,G,U,0)!==b.check?-3:X(S,G,U,U)?(b.mode=31,-4):(b.havedict=1,m):p},s.inflateInfo="pako inflate (from Nodeca project)"},{"../utils/common":41,"./adler32":43,"./crc32":45,"./inffast":48,"./inftrees":50}],50:[function(e,n,s){var r=e("../utils/common"),l=[3,4,5,6,7,8,9,10,11,13,15,17,19,23,27,31,35,43,51,59,67,83,99,115,131,163,195,227,258,0,0],o=[16,16,16,16,16,16,16,16,17,17,17,17,18,18,18,18,19,19,19,19,20,20,20,20,21,21,21,21,16,72,78],a=[1,2,3,4,5,7,9,13,17,25,33,49,65,97,129,193,257,385,513,769,1025,1537,2049,3073,4097,6145,8193,12289,16385,24577,0,0],c=[16,16,16,16,17,17,18,18,19,19,20,20,21,21,22,22,23,23,24,24,25,25,26,26,27,27,28,28,29,29,64,64];n.exports=function(d,h,m,p,y,f,k,v){var w,x,E,_,C,A,B,P,R,X=v.bits,S=0,G=0,b=0,U=0,it=0,j=0,st=0,K=0,Y=0,H=0,L=null,ct=0,rt=new r.Buf16(16),ot=new r.Buf16(16),J=null,mt=0;for(S=0;S<=15;S++)rt[S]=0;for(G=0;G<p;G++)rt[h[m+G]]++;for(it=X,U=15;1<=U&&rt[U]===0;U--);if(U<it&&(it=U),U===0)return y[f++]=20971520,y[f++]=20971520,v.bits=1,0;for(b=1;b<U&&rt[b]===0;b++);for(it<b&&(it=b),S=K=1;S<=15;S++)if(K<<=1,(K-=rt[S])<0)return-1;if(0<K&&(d===0||U!==1))return-1;for(ot[1]=0,S=1;S<15;S++)ot[S+1]=ot[S]+rt[S];for(G=0;G<p;G++)h[m+G]!==0&&(k[ot[h[m+G]]++]=G);if(A=d===0?(L=J=k,19):d===1?(L=l,ct-=257,J=o,mt-=257,256):(L=a,J=c,-1),S=b,C=f,st=G=H=0,E=-1,_=(Y=1<<(j=it))-1,d===1&&852<Y||d===2&&592<Y)return 1;for(;;){for(B=S-st,R=k[G]<A?(P=0,k[G]):k[G]>A?(P=J[mt+k[G]],L[ct+k[G]]):(P=96,0),w=1<<S-st,b=x=1<<j;y[C+(H>>st)+(x-=w)]=B<<24|P<<16|R|0,x!==0;);for(w=1<<S-1;H&w;)w>>=1;if(w!==0?(H&=w-1,H+=w):H=0,G++,--rt[S]==0){if(S===U)break;S=h[m+k[G]]}if(it<S&&(H&_)!==E){for(st===0&&(st=it),C+=b,K=1<<(j=S-st);j+st<U&&!((K-=rt[j+st])<=0);)j++,K<<=1;if(Y+=1<<j,d===1&&852<Y||d===2&&592<Y)return 1;y[E=H&_]=it<<24|j<<16|C-f|0}}return H!==0&&(y[C+H]=S-st<<24|64<<16|0),v.bits=it,0}},{"../utils/common":41}],51:[function(e,n,s){n.exports={2:"need dictionary",1:"stream end",0:"","-1":"file error","-2":"stream error","-3":"data error","-4":"insufficient memory","-5":"buffer error","-6":"incompatible version"}},{}],52:[function(e,n,s){var r=e("../utils/common"),l=0,o=1;function a(I){for(var M=I.length;0<=--M;)I[M]=0}var c=0,d=29,h=256,m=h+1+d,p=30,y=19,f=2*m+1,k=15,v=16,w=7,x=256,E=16,_=17,C=18,A=[0,0,0,0,0,0,0,0,1,1,1,1,2,2,2,2,3,3,3,3,4,4,4,4,5,5,5,5,0],B=[0,0,0,0,1,1,2,2,3,3,4,4,5,5,6,6,7,7,8,8,9,9,10,10,11,11,12,12,13,13],P=[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,2,3,7],R=[16,17,18,0,8,7,9,6,10,5,11,4,12,3,13,2,14,1,15],X=new Array(2*(m+2));a(X);var S=new Array(2*p);a(S);var G=new Array(512);a(G);var b=new Array(256);a(b);var U=new Array(d);a(U);var it,j,st,K=new Array(p);function Y(I,M,W,N,F){this.static_tree=I,this.extra_bits=M,this.extra_base=W,this.elems=N,this.max_length=F,this.has_stree=I&&I.length}function H(I,M){this.dyn_tree=I,this.max_code=0,this.stat_desc=M}function L(I){return I<256?G[I]:G[256+(I>>>7)]}function ct(I,M){I.pending_buf[I.pending++]=255&M,I.pending_buf[I.pending++]=M>>>8&255}function rt(I,M,W){I.bi_valid>v-W?(I.bi_buf|=M<<I.bi_valid&65535,ct(I,I.bi_buf),I.bi_buf=M>>v-I.bi_valid,I.bi_valid+=W-v):(I.bi_buf|=M<<I.bi_valid&65535,I.bi_valid+=W)}function ot(I,M,W){rt(I,W[2*M],W[2*M+1])}function J(I,M){for(var W=0;W|=1&I,I>>>=1,W<<=1,0<--M;);return W>>>1}function mt(I,M,W){var N,F,q=new Array(k+1),et=0;for(N=1;N<=k;N++)q[N]=et=et+W[N-1]<<1;for(F=0;F<=M;F++){var Q=I[2*F+1];Q!==0&&(I[2*F]=J(q[Q]++,Q))}}function gt(I){var M;for(M=0;M<m;M++)I.dyn_ltree[2*M]=0;for(M=0;M<p;M++)I.dyn_dtree[2*M]=0;for(M=0;M<y;M++)I.bl_tree[2*M]=0;I.dyn_ltree[2*x]=1,I.opt_len=I.static_len=0,I.last_lit=I.matches=0}function Z(I){8<I.bi_valid?ct(I,I.bi_buf):0<I.bi_valid&&(I.pending_buf[I.pending++]=I.bi_buf),I.bi_buf=0,I.bi_valid=0}function lt(I,M,W,N){var F=2*M,q=2*W;return I[F]<I[q]||I[F]===I[q]&&N[M]<=N[W]}function ut(I,M,W){for(var N=I.heap[W],F=W<<1;F<=I.heap_len&&(F<I.heap_len&&lt(M,I.heap[F+1],I.heap[F],I.depth)&&F++,!lt(M,N,I.heap[F],I.depth));)I.heap[W]=I.heap[F],W=F,F<<=1;I.heap[W]=N}function T(I,M,W){var N,F,q,et,Q=0;if(I.last_lit!==0)for(;N=I.pending_buf[I.d_buf+2*Q]<<8|I.pending_buf[I.d_buf+2*Q+1],F=I.pending_buf[I.l_buf+Q],Q++,N===0?ot(I,F,M):(ot(I,(q=b[F])+h+1,M),(et=A[q])!==0&&rt(I,F-=U[q],et),ot(I,q=L(--N),W),(et=B[q])!==0&&rt(I,N-=K[q],et)),Q<I.last_lit;);ot(I,x,M)}function O(I,M){var W,N,F,q=M.dyn_tree,et=M.stat_desc.static_tree,Q=M.stat_desc.has_stree,dt=M.stat_desc.elems,xt=-1;for(I.heap_len=0,I.heap_max=f,W=0;W<dt;W++)q[2*W]!==0?(I.heap[++I.heap_len]=xt=W,I.depth[W]=0):q[2*W+1]=0;for(;I.heap_len<2;)q[2*(F=I.heap[++I.heap_len]=xt<2?++xt:0)]=1,I.depth[F]=0,I.opt_len--,Q&&(I.static_len-=et[2*F+1]);for(M.max_code=xt,W=I.heap_len>>1;1<=W;W--)ut(I,q,W);for(F=dt;W=I.heap[1],I.heap[1]=I.heap[I.heap_len--],ut(I,q,1),N=I.heap[1],I.heap[--I.heap_max]=W,I.heap[--I.heap_max]=N,q[2*F]=q[2*W]+q[2*N],I.depth[F]=(I.depth[W]>=I.depth[N]?I.depth[W]:I.depth[N])+1,q[2*W+1]=q[2*N+1]=F,I.heap[1]=F++,ut(I,q,1),2<=I.heap_len;);I.heap[--I.heap_max]=I.heap[1],(function(bt,Mt){var Vt,Yt,ee,Nt,Ke,te,Jt=Mt.dyn_tree,mi=Mt.max_code,Bi=Mt.stat_desc.static_tree,ms=Mt.stat_desc.has_stree,gs=Mt.stat_desc.extra_bits,An=Mt.stat_desc.extra_base,gi=Mt.stat_desc.max_length,Di=0;for(Nt=0;Nt<=k;Nt++)bt.bl_count[Nt]=0;for(Jt[2*bt.heap[bt.heap_max]+1]=0,Vt=bt.heap_max+1;Vt<f;Vt++)gi<(Nt=Jt[2*Jt[2*(Yt=bt.heap[Vt])+1]+1]+1)&&(Nt=gi,Di++),Jt[2*Yt+1]=Nt,mi<Yt||(bt.bl_count[Nt]++,Ke=0,An<=Yt&&(Ke=gs[Yt-An]),te=Jt[2*Yt],bt.opt_len+=te*(Nt+Ke),ms&&(bt.static_len+=te*(Bi[2*Yt+1]+Ke)));if(Di!==0){do{for(Nt=gi-1;bt.bl_count[Nt]===0;)Nt--;bt.bl_count[Nt]--,bt.bl_count[Nt+1]+=2,bt.bl_count[gi]--,Di-=2}while(0<Di);for(Nt=gi;Nt!==0;Nt--)for(Yt=bt.bl_count[Nt];Yt!==0;)mi<(ee=bt.heap[--Vt])||(Jt[2*ee+1]!==Nt&&(bt.opt_len+=(Nt-Jt[2*ee+1])*Jt[2*ee],Jt[2*ee+1]=Nt),Yt--)}})(I,M),mt(q,xt,I.bl_count)}function u(I,M,W){var N,F,q=-1,et=M[1],Q=0,dt=7,xt=4;for(et===0&&(dt=138,xt=3),M[2*(W+1)+1]=65535,N=0;N<=W;N++)F=et,et=M[2*(N+1)+1],++Q<dt&&F===et||(Q<xt?I.bl_tree[2*F]+=Q:F!==0?(F!==q&&I.bl_tree[2*F]++,I.bl_tree[2*E]++):Q<=10?I.bl_tree[2*_]++:I.bl_tree[2*C]++,q=F,xt=(Q=0)===et?(dt=138,3):F===et?(dt=6,3):(dt=7,4))}function z(I,M,W){var N,F,q=-1,et=M[1],Q=0,dt=7,xt=4;for(et===0&&(dt=138,xt=3),N=0;N<=W;N++)if(F=et,et=M[2*(N+1)+1],!(++Q<dt&&F===et)){if(Q<xt)for(;ot(I,F,I.bl_tree),--Q!=0;);else F!==0?(F!==q&&(ot(I,F,I.bl_tree),Q--),ot(I,E,I.bl_tree),rt(I,Q-3,2)):Q<=10?(ot(I,_,I.bl_tree),rt(I,Q-3,3)):(ot(I,C,I.bl_tree),rt(I,Q-11,7));q=F,xt=(Q=0)===et?(dt=138,3):F===et?(dt=6,3):(dt=7,4)}}a(K);var D=!1;function $(I,M,W,N){rt(I,(c<<1)+(N?1:0),3),(function(F,q,et,Q){Z(F),ct(F,et),ct(F,~et),r.arraySet(F.pending_buf,F.window,q,et,F.pending),F.pending+=et})(I,M,W)}s._tr_init=function(I){D||((function(){var M,W,N,F,q,et=new Array(k+1);for(F=N=0;F<d-1;F++)for(U[F]=N,M=0;M<1<<A[F];M++)b[N++]=F;for(b[N-1]=F,F=q=0;F<16;F++)for(K[F]=q,M=0;M<1<<B[F];M++)G[q++]=F;for(q>>=7;F<p;F++)for(K[F]=q<<7,M=0;M<1<<B[F]-7;M++)G[256+q++]=F;for(W=0;W<=k;W++)et[W]=0;for(M=0;M<=143;)X[2*M+1]=8,M++,et[8]++;for(;M<=255;)X[2*M+1]=9,M++,et[9]++;for(;M<=279;)X[2*M+1]=7,M++,et[7]++;for(;M<=287;)X[2*M+1]=8,M++,et[8]++;for(mt(X,m+1,et),M=0;M<p;M++)S[2*M+1]=5,S[2*M]=J(M,5);it=new Y(X,A,h+1,m,k),j=new Y(S,B,0,p,k),st=new Y(new Array(0),P,0,y,w)})(),D=!0),I.l_desc=new H(I.dyn_ltree,it),I.d_desc=new H(I.dyn_dtree,j),I.bl_desc=new H(I.bl_tree,st),I.bi_buf=0,I.bi_valid=0,gt(I)},s._tr_stored_block=$,s._tr_flush_block=function(I,M,W,N){var F,q,et=0;0<I.level?(I.strm.data_type===2&&(I.strm.data_type=(function(Q){var dt,xt=4093624447;for(dt=0;dt<=31;dt++,xt>>>=1)if(1&xt&&Q.dyn_ltree[2*dt]!==0)return l;if(Q.dyn_ltree[18]!==0||Q.dyn_ltree[20]!==0||Q.dyn_ltree[26]!==0)return o;for(dt=32;dt<h;dt++)if(Q.dyn_ltree[2*dt]!==0)return o;return l})(I)),O(I,I.l_desc),O(I,I.d_desc),et=(function(Q){var dt;for(u(Q,Q.dyn_ltree,Q.l_desc.max_code),u(Q,Q.dyn_dtree,Q.d_desc.max_code),O(Q,Q.bl_desc),dt=y-1;3<=dt&&Q.bl_tree[2*R[dt]+1]===0;dt--);return Q.opt_len+=3*(dt+1)+5+5+4,dt})(I),F=I.opt_len+3+7>>>3,(q=I.static_len+3+7>>>3)<=F&&(F=q)):F=q=W+5,W+4<=F&&M!==-1?$(I,M,W,N):I.strategy===4||q===F?(rt(I,2+(N?1:0),3),T(I,X,S)):(rt(I,4+(N?1:0),3),(function(Q,dt,xt,bt){var Mt;for(rt(Q,dt-257,5),rt(Q,xt-1,5),rt(Q,bt-4,4),Mt=0;Mt<bt;Mt++)rt(Q,Q.bl_tree[2*R[Mt]+1],3);z(Q,Q.dyn_ltree,dt-1),z(Q,Q.dyn_dtree,xt-1)})(I,I.l_desc.max_code+1,I.d_desc.max_code+1,et+1),T(I,I.dyn_ltree,I.dyn_dtree)),gt(I),N&&Z(I)},s._tr_tally=function(I,M,W){return I.pending_buf[I.d_buf+2*I.last_lit]=M>>>8&255,I.pending_buf[I.d_buf+2*I.last_lit+1]=255&M,I.pending_buf[I.l_buf+I.last_lit]=255&W,I.last_lit++,M===0?I.dyn_ltree[2*W]++:(I.matches++,M--,I.dyn_ltree[2*(b[W]+h+1)]++,I.dyn_dtree[2*L(M)]++),I.last_lit===I.lit_bufsize-1},s._tr_align=function(I){rt(I,2,3),ot(I,x,X),(function(M){M.bi_valid===16?(ct(M,M.bi_buf),M.bi_buf=0,M.bi_valid=0):8<=M.bi_valid&&(M.pending_buf[M.pending++]=255&M.bi_buf,M.bi_buf>>=8,M.bi_valid-=8)})(I)}},{"../utils/common":41}],53:[function(e,n,s){n.exports=function(){this.input=null,this.next_in=0,this.avail_in=0,this.total_in=0,this.output=null,this.next_out=0,this.avail_out=0,this.total_out=0,this.msg="",this.state=null,this.data_type=2,this.adler=0}},{}],54:[function(e,n,s){(function(r){(function(l,o){if(!l.setImmediate){var a,c,d,h,m=1,p={},y=!1,f=l.document,k=Object.getPrototypeOf&&Object.getPrototypeOf(l);k=k&&k.setTimeout?k:l,a={}.toString.call(l.process)==="[object process]"?function(E){process.nextTick(function(){w(E)})}:(function(){if(l.postMessage&&!l.importScripts){var E=!0,_=l.onmessage;return l.onmessage=function(){E=!1},l.postMessage("","*"),l.onmessage=_,E}})()?(h="setImmediate$"+Math.random()+"$",l.addEventListener?l.addEventListener("message",x,!1):l.attachEvent("onmessage",x),function(E){l.postMessage(h+E,"*")}):l.MessageChannel?((d=new MessageChannel).port1.onmessage=function(E){w(E.data)},function(E){d.port2.postMessage(E)}):f&&"onreadystatechange"in f.createElement("script")?(c=f.documentElement,function(E){var _=f.createElement("script");_.onreadystatechange=function(){w(E),_.onreadystatechange=null,c.removeChild(_),_=null},c.appendChild(_)}):function(E){setTimeout(w,0,E)},k.setImmediate=function(E){typeof E!="function"&&(E=new Function(""+E));for(var _=new Array(arguments.length-1),C=0;C<_.length;C++)_[C]=arguments[C+1];var A={callback:E,args:_};return p[m]=A,a(m),m++},k.clearImmediate=v}function v(E){delete p[E]}function w(E){if(y)setTimeout(w,0,E);else{var _=p[E];if(_){y=!0;try{(function(C){var A=C.callback,B=C.args;switch(B.length){case 0:A();break;case 1:A(B[0]);break;case 2:A(B[0],B[1]);break;case 3:A(B[0],B[1],B[2]);break;default:A.apply(o,B)}})(_)}finally{v(E),y=!1}}}}function x(E){E.source===l&&typeof E.data=="string"&&E.data.indexOf(h)===0&&w(+E.data.slice(h.length))}})(typeof self>"u"?r===void 0?this:r:self)}).call(this,typeof Rn<"u"?Rn:typeof self<"u"?self:typeof window<"u"?window:{})},{}]},{},[10])(10)})})(Ms)),Ms.exports}var zg=Rg();const Ng=Lg(zg),Fg=/\.(?:png|jpe?g|gif|svg|webp|avif|ico|bmp|tiff?|mp4|webm|mp3|wav|ogg)$/i,jg=/\.(?:ts|js|mjs|cjs|jsx|tsx|vue|json|css|scss|less|html|py|rs|go|java|c|cpp|h|sh|bash|yaml|yml|toml)$/i;async function Hg(t){const i=await Ng.loadAsync(t),e={},n=[];let s="",r="";const l=[];i.forEach((a,c)=>{!c.dir&&!a.startsWith("__MACOSX")&&!a.includes("node_modules/")&&l.push({path:a,file:c})});let o=l.find(a=>a.path.toLowerCase()==="slides.md");o||(o=l.find(a=>a.path.toLowerCase().endsWith("/slides.md"))),o||(o=l.find(a=>a.path.toLowerCase().endsWith(".md"))),o&&(s=await o.file.async("string"),r=o.path);for(const a of l){const c=a.path;if(c.toLowerCase().endsWith(".md")||jg.test(c)||c.includes("snippets/")){const d=await a.file.async("string");e[c]=d;const h=c.split("/");h.length>1&&(e[h.slice(1).join("/")]=d)}else if(Fg.test(c)){const d=await a.file.async("uint8array"),h=c.split("/").pop()||c,m=typeof Blob<"u"?new Blob([d]):void 0;n.push({zipPath:c,fileName:h,data:d,blob:m})}}return{entryMarkdown:s,entryMarkdownPath:r,virtualFiles:e,assets:n}}function Ug(t,i){if(Object.keys(i).length===0)return t;function e(s){const r=s.trim().replace(/^['"]|['"]$/g,""),l=r.split("/").pop()||r;if(i[r])return i[r];const o=r.replace(/^\.?\//,"");return i[o]?i[o]:i[l]?i[l]:null}function n(s){let r=s;return r=r.replace(/!\[(.*?)\]\((.*?)\)/g,(l,o,a)=>{const c=e(a);return c?`![${o}](${c})`:l}),r=r.replace(/\bsrc=["'](.*?)["']/gi,(l,o)=>{const a=e(o);return a?`src="${a}"`:l}),r}for(const s of t.slides)if(s.rawMarkdown=n(s.rawMarkdown),s.pageAttrs["custom-slidev-background"]){const r=s.pageAttrs["custom-slidev-background"],l=e(r);l&&(s.pageAttrs["custom-slidev-background"]=l)}if(t.flattenedMarkdown=n(t.flattenedMarkdown),t.docRootAttrs["custom-slidev-background"]){const s=t.docRootAttrs["custom-slidev-background"],r=e(s);r&&(t.docRootAttrs["custom-slidev-background"]=r)}return t}function wi(t,i,e){let n="",s=0;const r=/<div\b([^>]*)>/gi;for(;s<t.length;){r.lastIndex=s;let l,o=!1,a=-1,c=0;for(;(l=r.exec(t))!==null;){const v=l[1].match(/\bclass=["']([^"']*)["']/i);if(v){const w=v[1];if(typeof i=="string"?w.split(/\s+/).includes(i):i.test(w)){o=!0,a=l.index,c=l[0].length;break}}}if(!o){n+=t.slice(s);break}n+=t.slice(s,a);const d=a+c;let h=1,m=-1,p=-1;const y=/<\/?div\b[^>]*>/gi;y.lastIndex=d;let f;for(;(f=y.exec(t))!==null;)if(f[0].startsWith("</")){if(h--,h===0){m=f.index,p=f.index+f[0].length;break}}else h++;if(m!==-1&&p!==-1){const k=t.slice(d,m);n+=e(k),s=p}else n+=t.slice(a,d),s=d}return n}function Wg(t){const i=[];let e="",n=0;const s=/<div\b([^>]*)>/gi;for(;n<t.length;){s.lastIndex=n;let r,l=!1,o=-1,a=0;for(;(r=s.exec(t))!==null;){const f=r[1];if(/(?:\s@[a-zA-Z0-9_-]+=\s*["']|\s:[a-zA-Z0-9_-]+=\s*["']|\sv-[a-zA-Z0-9_.-]+|\shover:[a-zA-Z0-9_.-]+=\s*["']|\sgrid=["']~|\bclass=["'][^"']*\b(?:abs-br|slidev-icon-btn|grid\s+|grid$|grid-cols-|relative\b)\b[^"']*["']|\bstyle=["'][^"']*\bgrid-[^"']*["'])/i.test(f)){l=!0,o=r.index,a=r[0].length;break}}if(!l){e+=t.slice(n);break}e+=t.slice(n,o);const c=o+a;let d=1,h=-1,m=-1;const p=/<\/?div\b[^>]*>/gi;p.lastIndex=c;let y;for(;(y=p.exec(t))!==null;)if(y[0].startsWith("</")){if(d--,d===0){h=y.index,m=y.index+y[0].length;break}}else d++;if(h!==-1&&m!==-1){const f=t.slice(o,m),k=`__VUE_DIV_TOKEN_${i.length}__`;i.push(f),e+=k,n=m}else e+=t.slice(o,c),n=c}return{text:e,tokens:i}}function Vg(t){const i=[];let e=t.replace(/(?:^[ \t]*(`{3,}|~{3,})[^\n\r]*\r?\n[\s\S]*?\r?\n[ \t]*\1(?=[ \t]*(?:\r?\n|$)))/gm,o=>{const a=`__CODE_TOKEN_${i.length}__`;return i.push(o),a});e=e.replace(/(`+)(?:[^\n\r`]|(?!\1)`)+?\1/g,o=>{const a=`__CODE_TOKEN_${i.length}__`;return i.push(o),a});const n=[];e=e.replace(/<script\b[^>]*>[\s\S]*?<\/script>/gi,o=>{const a=`__SCRIPT_TOKEN_${n.length}__`;return n.push(o),a});const{text:s,tokens:r}=Wg(e);e=s;const l=[];e=e.replace(/<(?:[A-Z][a-zA-Z0-9_-]*|[a-z0-9_-]+:[a-z0-9_-]+|v-[a-z0-9_-]+|arrow\b|div\s+h-\d+)\b[^>]*\/>/gi,o=>{const a=`__VUE_COMP_TOKEN_${l.length}__`;return l.push(o),a}),e=e.replace(/<(v-[a-z0-9_-]+|button)\b([^>]*)>([\s\S]*?)<\/\1>/gi,o=>{const a=`__VUE_COMP_TOKEN_${l.length}__`;return l.push(o),a}),e=e.replace(/<img\b[^>]*?\bv-[a-z0-9_.-]+[^>]*\/?>/gi,o=>{const a=`__VUE_COMP_TOKEN_${l.length}__`;return l.push(o),a}),e=e.replace(/<(p|span)\b([^>]*?\bv-[a-z0-9_.-]+[^>]*)>([\s\S]*?)<\/\1>/gi,o=>{const a=`__VUE_COMP_TOKEN_${l.length}__`;return l.push(o),a}),e=e.replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi,""),e=e.replace(/<div class="terminal-bar">[\s\S]*?<\/div>/gi,""),e=e.replace(/<div class="cursor-line">[\s\S]*?<\/div>/gi,""),e=e.replace(/<span class="cursor">[\s\S]*?<\/span>/gi,""),e=e.replace(/<div class="stamp">\s*([\s\S]*?)\s*<\/div>/gi,`

*[$1]*

`),e=e.replace(/<div class="arrow">\s*([→\->]+)\s*<\/div>/gi,`

$1

`),e=e.replace(/<i>\s*[→\->]+\s*<\/i>/gi,""),e=e.replace(/<div class="prompt">\s*([\s\S]*?)\s*<\/div>/gi,(o,a)=>`
\`\`\`bash
${a.trim()}
\`\`\`
`),e=e.replace(/<p>\s*<i>\$<\/i>\s*([\s\S]*?)<\/p>/gi,(o,a)=>`
\`\`\`bash
$ ${a.trim()}
\`\`\`
`),e=e.replace(/<div class="statusline">\s*([\s\S]*?)\s*<\/div>/gi,(o,a)=>`
> ${Array.from(a.matchAll(/<span>([\s\S]*?)<\/span>/gi)).map(d=>`\`${d[1].trim()}\``).join(" | ")}
`),e=e.replace(/<div class="log-panel">\s*<pre>([\s\S]*?)<\/pre>\s*<\/div>/gi,(o,a)=>`
\`\`\`log
${a.replace(/<span[^>]*>([\s\S]*?)<\/span>/gi,"$1").trim()}
\`\`\`
`),e=wi(e,"diff-grid",o=>{const a=Array.from(o.matchAll(/<div class="diff\s+([^"]*)">\s*<span>(.*?)<\/span>\s*<pre>([\s\S]*?)<\/pre>\s*<\/div>/gi));return a.length>0?`
`+a.map(c=>{const d=c[2].trim().toUpperCase(),h=c[3].trim();return`**${d}:**
\`\`\`yaml
${h}
\`\`\``}).join(`

`)+`
`:o}),e=wi(e,"before-after",o=>{const a=o.match(/<div class="before">[\s\S]*?<small>(.*?)<\/small>[\s\S]*?<h2>(.*?)<\/h2>[\s\S]*?<p>(.*?)<\/p>\s*<\/div>/i),c=o.match(/<div class="after">[\s\S]*?<small>(.*?)<\/small>[\s\S]*?<h2>(.*?)<\/h2>[\s\S]*?<p>(.*?)<\/p>\s*<\/div>/i);let d=`
`;return a&&(d+=`### ${a[1]}
## ${a[2]}
${a[3]}

`),c&&(d+=`### ${c[1]}
## ${c[2]}
${c[3]}
`),d.trim()?d:o}),e=e.replace(/<ul\b[^>]*>([\s\S]*?)<\/ul>/gi,(o,a)=>{const c=Array.from(a.matchAll(/<li>\s*(?:<em>)?(\[[x ]\])(?:<\/em>)?\s*([\s\S]*?)<\/li>/gi));return c.length>0?`
`+c.map(d=>`- ${d[1]} ${d[2].trim()}`).join(`
`)+`
`:a}),e=wi(e,"timeline",o=>{const a=Array.from(o.matchAll(/<div(?:\s+class="([^"]*)")?>\s*<time>([\s\S]*?)<\/time>\s*<b>([\s\S]*?)<\/b>\s*<span>([\s\S]*?)<\/span>\s*<\/div>/gi));return a.length>0?`

`+a.map(c=>{const d=c[1]||"";let h="-";return d.includes("warn")?h="- ⚠️":d.includes("bad")?h="- ❌":d.includes("ok")&&(h="- ✅"),`${h} **${c[2].trim()}** **${c[3].trim()}** — ${c[4].trim()}`}).join(`
`)+`

`:o}),e=wi(e,"pipeline",o=>{const a=Array.from(o.matchAll(/<div(?:\s+class="([^"]*)")?>\s*<small>([\s\S]*?)<\/small>\s*<b>([\s\S]*?)<\/b>\s*<span>([\s\S]*?)<\/span>\s*<\/div>/gi));return a.length>0?`

`+a.map((c,d)=>{const m=(c[1]||"").includes("hot")?"⚠️ ":"";return`${d+1}. ${m}**${c[3].trim()}** (*${c[4].trim()}*)`}).join(`
`)+`

`:o}),e=wi(e,"check-grid",o=>{const a=Array.from(o.matchAll(/<div>\s*<span class="([^"]*)"><\/span>\s*<b>([\s\S]*?)<\/b>\s*<p>([\s\S]*?)<\/p>\s*<\/div>/gi));return a.length>0?`

`+a.map(c=>`- ${(c[1]||"").includes("warn")?"⚠️":"✅"} **${c[2].trim()}**: ${c[3].trim()}`).join(`
`)+`

`:o}),e=wi(e,"manifesto",o=>{const a=Array.from(o.matchAll(/<div>\s*<span>([\s\S]*?)<\/span>\s*<h2>([\s\S]*?)<\/h2>\s*<p>([\s\S]*?)<\/p>\s*<\/div>/gi));return a.length>0?`

`+a.map(c=>`## ${c[1].trim()} ${c[2].trim()}

${c[3].trim()}`).join(`

`)+`

`:o}),e=wi(e,"split-note",o=>{const a=Array.from(o.matchAll(/<div>\s*<b>([\s\S]*?)<\/b>\s*<p>([\s\S]*?)<\/p>\s*<\/div>/gi));return a.length>0?`

`+a.map(c=>`> **${c[1].trim()}**: ${c[2].trim()}`).join(`
>
`)+`

`:o}),e=e.replace(/<div class="mechanism">\s*<b>([\s\S]*?)<\/b>\s*<p>([\s\S]*?)<\/p>\s*<\/div>/gi,(o,a,c)=>`

> **${a.trim()}**: ${c.trim()}

`),e=e.replace(/<pre>([\s\S]*?)<\/pre>/gi,(o,a)=>`
\`\`\`text
${a.replace(/<span[^>]*>([\s\S]*?)<\/span>/gi,"$1").trim()}
\`\`\`
`),e=e.replace(/<div class="page-head">\s*<span>([\s\S]*?)<\/span>\s*<b>([\s\S]*?)<\/b>\s*<\/div>/gi,`
### $1 ($2)
`),e=e.replace(/<h1\b[^>]*>([\s\S]*?)<\/h1>/gi,`
# $1
`),e=e.replace(/<h2\b[^>]*>([\s\S]*?)<\/h2>/gi,`
## $1
`),e=e.replace(/<h3\b[^>]*>([\s\S]*?)<\/h3>/gi,`
### $1
`),e=e.replace(/<h4\b[^>]*>([\s\S]*?)<\/h4>/gi,`
#### $1
`),e=e.replace(/<p\s+class="ok">\s*●\s*([\s\S]*?)<\/p>/gi,`
✅ **$1**
`),e=e.replace(/<p\s+class="caption">\s*([\s\S]*?)<\/p>/gi,`
> *$1*
`),e=e.replace(/<p\s+class="lead">\s*([\s\S]*?)<\/p>/gi,`
*$1*
`),e=e.replace(/<p\b([^>]*)>([\s\S]*?)<\/p>/gi,(o,a,c)=>/@|v-|:|class=/i.test(a)?o:`
${c.trim()}

`),e=e.replace(/<br\s*\/?>/gi,`
`),e=e.replace(/<hr\s*\/?>/gi,`
---
`),e=e.replace(/<b\b[^>]*>([\s\S]*?)<\/b>/gi,"**$1**"),e=e.replace(/<strong\b[^>]*>([\s\S]*?)<\/strong>/gi,"**$1**"),e=e.replace(/<i\b[^>]*>([\s\S]*?)<\/i>/gi,"*$1*"),e=e.replace(/<code\b[^>]*>([\s\S]*?)<\/code>/gi,(o,a)=>{if(a.startsWith("`")&&a.endsWith("`"))return a;if(a.includes("`")){const c=(a.match(/`+/g)||[]).reduce((h,m)=>Math.max(h,m.length),0),d="`".repeat(c+1);return`${d} ${a} ${d}`}return`\`${a}\``}),e=e.replace(/<small\b[^>]*>([\s\S]*?)<\/small>/gi,"*$1*"),e=e.replace(/\*{4}/g,"** **"),e=e.replace(/<li\b[^>]*>([\s\S]*?)<\/li>/gi,`- $1
`),e=e.replace(/<ul\b[^>]*>([\s\S]*?)<\/ul>/gi,`
$1
`),e=e.replace(/<ol\b[^>]*>([\s\S]*?)<\/ol>/gi,`
$1
`),e=e.replace(/<a\b([^>]*)href=["'](.*?)["']([^>]*)>([\s\S]*?)<\/a>/gi,(o,a,c,d,h)=>{const m=h.trim();return m.includes("<")||m.includes(`
`)?o:`[${m}](${c})`}),e=e.replace(/<blockquote\b[^>]*>([\s\S]*?)<\/blockquote>/gi,(o,a)=>`
`+a.trim().split(`
`).map(c=>`> ${c.trim()}`).join(`
`)+`
`),e=e.replace(/<span\b[^>]*data-type=["']block-ref["'][^>]*data-id=["']([0-9a-zA-Z-]+)["'][^>]*>([\s\S]*?)<\/span>/gi,(o,a,c)=>{const d=c.replace(/<[^>]+>/g,"").trim();return d?`((${a} '${d}'))`:`((${a}))`}),e=e.replace(/<span\b[^>]*data-type=["']a["'][^>]*data-href=["']([^"']+)["'][^>]*>([\s\S]*?)<\/span>/gi,(o,a,c)=>`[${c.replace(/<[^>]+>/g,"").trim()}](${a})`),e=e.replace(/<\/(?:div|section|header|footer|main|article|nav|aside)\b[^>]*>/gi,`
`),e=e.replace(/<(?:div|section|header|footer|main|article|nav|aside)\b[^>]*>/gi,""),e=e.replace(/<\/?span\b[^>]*>/gi,"");for(let o=0;o<l.length;o++)e=e.replace(`__VUE_COMP_TOKEN_${o}__`,l[o]);for(let o=0;o<r.length;o++)e=e.replace(`__VUE_DIV_TOKEN_${o}__`,r[o]);for(let o=0;o<n.length;o++)e=e.replace(`__SCRIPT_TOKEN_${o}__`,n[o]);for(let o=0;o<i.length;o++)e=e.replace(`__CODE_TOKEN_${o}__`,i[o]);return e=e.replace(/\n{3,}/g,`

`).trim(),e}function Zl(t){try{if(typeof process<"u"&&typeof require<"u"){const i=require("fs");if(i.existsSync(t))return i.readFileSync(t,"utf-8")}}catch{}return null}function Kg(t,i){const e=t.match(/^[ \t]*<<<[ \t]+([^\s]+)/);if(!e)return null;const n=e[1].trim(),s=n.indexOf("#"),r=s!==-1?n.slice(0,s):n,l=s!==-1?n.slice(s+1):"",o=r.replace(/^@\//,"").replace(/^\.\//,""),a=(i==null?void 0:i.virtualFiles)||{};let c=a[r]||a[o]||a[`./${o}`]||a[`@/${o}`];if(!c&&Object.keys(a).length>0){const p=o.split("/").pop();for(const[y,f]of Object.entries(a))if(y.endsWith(`/${o}`)||p&&y.endsWith(`/${p}`)){c=f;break}}if(!c){const p=[];if(i!=null&&i.baseDir)try{const y=require("path");p.push(y.resolve(i.baseDir,o)),p.push(y.resolve(i.baseDir,r))}catch{}try{const y=require("path");p.push(y.resolve(process.cwd(),o))}catch{}for(const y of p){const f=Zl(y);if(f!==null){c=f;break}}}if(!c){const p=jl||{};if(c=p[r]||p[o]||p[`snippets/${o}`],!c){const y=o.split("/").pop();for(const[f,k]of Object.entries(p))if(f.endsWith(`/${o}`)||y&&f.endsWith(`/${y}`)){c=k;break}}}if(!c)return null;let d=c;if(l){const p=new RegExp(`(?:\\/\\/|\\/\\*|#)?\\s*#(?:region|REGION)\\s+${l}[^\\r\\n]*\\r?\\n([\\s\\S]*?)(?:\\/\\/|\\/\\*|#)?\\s*#(?:endregion|ENDREGION)\\s+${l}`,"i"),y=c.match(p);if(y){const f=c.match(/^(\/\/\s*Inside[^\r\n]+\r?\n)/i);d=(f?f[1]:"")+y[1].trimEnd()}}const h=o.match(/\.([a-zA-Z0-9]+)$/);return`\`\`\`${h?h[1]:""}
${d}
\`\`\``}function qg(t){let i=!1,e=!1;for(let n=0;n<t.length;n++){const s=t[n];if(s==="'"&&!e)i=!i;else if(s==='"'&&!i)e=!e;else if(s==="#"&&!i&&!e)return t.slice(0,n).trim()}return t.trim()}function Un(t){const i={},e=t.split(/\r?\n/);let n=0;for(;n<e.length;){const s=e[n],r=s.trim();if(!r||r.startsWith("#")){n++;continue}const l=s.indexOf(":");if(l>0){const o=s.slice(0,l).trim();let a=s.slice(l+1).trim();if(a==="|"||a===">"){n++;const c=[];let d=-1;for(;n<e.length;){const h=e[n];if(!h.trim()){c.push(""),n++;continue}const p=h.match(/^(\s+)/),y=p?p[1].length:0;if(d===-1&&(d=y),y<d)break;c.push(h.slice(d)),n++}for(;c.length>0&&c[c.length-1]==="";)c.pop();i[o]=a===">"?c.join(" "):c.join(`
`);continue}if(a=qg(a),!a){let c=n+1;const d=[];let h=-1;for(;c<e.length;){const m=e[c],p=m.trim();if(!p||p.startsWith("#")){h!==-1&&d.push(""),c++;continue}const y=m.match(/^(\s+)/),f=y?y[1].length:0;if(h===-1)if(f>0)h=f;else break;if(f<h)break;d.push(m.slice(h)),c++}if(d.length>0){i[o]=Un(d.join(`
`)),n=c;continue}}a.startsWith('"')&&a.endsWith('"')||a.startsWith("'")&&a.endsWith("'")?a=a.slice(1,-1):a==="true"?a=!0:a==="false"?a=!1:a==="null"?a=null:/^-?\d+(?:\.\d+)?$/.test(a)&&(a=Number(a)),i[o]=a}n++}return i}const Gg=/^\s*```ya?ml([\s\S]*?)```/;function br(t){let i={},e=t.trim();const n=e.match(/^---[^\n\r]*\r?\n([\s\S]*?)\r?\n---(?=[ \t]*(?:\r?\n|$))/);if(n&&!n[1].includes("```")){const r=Un(n[1]);if(Object.keys(r).length>0||!n[1].trim())return i=r,e=e.slice(n[0].length).trim(),{frontmatter:i,content:e}}if(e.startsWith("---")){const r=e.match(/^---[^\n\r]*(?:\r?\n|$)/);r&&(e=e.slice(r[0].length).trim())}const s=e.match(Gg);if(s)i=Un(s[1]),e=e.slice(s[0].length).trim();else{const r=e.split(/\r?\n/),l=[];let o=0;for(let a=0;a<r.length;a++){const c=r[a].trim();if(!c){if(l.length>0){o=a+1;break}continue}if(/^[a-zA-Z0-9_-]+\s*:\s*.*/.test(c)&&!c.startsWith("<")&&!c.startsWith("#"))l.push(c);else{o=a;break}}l.length>0&&(i=Un(l.join(`
`)),e=r.slice(o).join(`
`).trim())}return{frontmatter:i,content:e}}function Zg(t){const i=t.split(/\r?\n/),e=[];let n=0,s=!1;function r(l){if(n>=l)return;const o=i.slice(n,l).join(`
`).trim();o&&e.push(o),n=l+1}for(let l=0;l<i.length;l++){const a=i[l].trimEnd();if(s){a.includes("-->")&&(s=!1);continue}if(a.startsWith("<!--")){a.includes("-->")||(s=!0);continue}if(a.startsWith("---")){r(l);const c=i[l+1];if(c&&c.trim()&&a.replace(/^-+/,"").trim()==="")for(n=l,l+=1;l<i.length&&i[l].trimEnd()!=="---";l++);}else if(a.trimStart().startsWith("```")){const c=a.match(/^\s*`+/),d=c?c[0].trim():"```";let h=l+1;for(;h<i.length&&!i[h].trimStart().startsWith(d);h++);h<i.length&&(l=h)}}return n<i.length&&r(i.length),e}function Wn(t,i={}){const{stripNotesFromMarkdown:e=!0,cleanVClicks:n=!0,cleanShikiLines:s=!0,cleanSlots:r=!0,isolateStyleTags:l=!0,cleanHtmlToMarkdown:o=!0,wrapSuperBlocks:a=!0,virtualFiles:c={}}=i;let d=t;d&&!d.trimStart().startsWith("---")&&(d=`---

${d.trimStart()}`);const h=Zg(d),m={};let p="",y="",f=0;if(h.length>0){const R=h[0],X=br(R),S=Object.keys(X.frontmatter).length>0,G=X.content.length>0;S&&!G&&h.length>1?(f=1,k(X.frontmatter)):S&&k(X.frontmatter)}function k(R){p=R.title||"",R.theme&&(m[rn]=String(R.theme)),R.aspectRatio&&(m[ln]=String(R.aspectRatio)),R.highlighter&&(m[_r]=String(R.highlighter)),R.transition&&(m[an]=String(R.transition)),R.colorSchema&&(m[Sr]=String(R.colorSchema)),R.layout&&(m[ft]=String(R.layout)),R.background&&(m[Ut]=String(R.background)),R.image&&(m[Ae]=String(R.image)),R.class&&(m[Ni]=String(R.class));for(const[X,S]of Object.entries(R))["theme","aspectRatio","highlighter","transition","colorSchema","title","layout","background","image","class"].includes(X)||(m[`custom-slidev-${X}`]=typeof S=="object"?JSON.stringify(S):String(S))}const v=[];let w=0,x=0,E=0,_=0;const C=new Set,A={};let B=1;for(let R=f;R<h.length;R++){const X=h[R],{frontmatter:S,content:G}=br(X),b=X.match(/^\s*(?:---\s*)?src:\s*([^\n\r]+)/m),U=S.src||(b?b[1]:void 0);if(U){const Z=String(U).trim().replace(/^['"]|['"]$/g,"");let lt=c[Z]||c[Z.replace(/^\.\//,"")]||c[`pages/${Z.replace(/^.*pages\//,"")}`];if(!lt){const T=Z.replace(/^\.\//,""),O=[];if(i.baseDir)try{const u=require("path");O.push(u.resolve(i.baseDir,T)),O.push(u.resolve(i.baseDir,Z))}catch{}try{const u=require("path");O.push(u.resolve(process.cwd(),T)),O.push(u.resolve(process.cwd(),Z))}catch{}for(const u of O){const z=Zl(u);if(z!==null){lt=z;break}}}const ut={};S.layout&&(ut[ft]=String(S.layout)),S.transition&&(ut[Xt]=String(S.transition)),S.background&&(ut[Ut]=String(S.background)),S.image&&(ut[Ae]=String(S.image)),S.class&&(ut[Ni]=String(S.class));for(const[T,O]of Object.entries(S))["src","layout","transition","background","image","class"].includes(T)||(ut[`custom-slidev-${T}`]=typeof O=="object"?JSON.stringify(O):String(O));if(lt){const T=Wn(lt,{...i,virtualFiles:c});for(const O of T.slides){O.pageIndex=B++,O.pageAttrs={...ut,...O.pageAttrs},v.push(O);const u=O.pageAttrs[ft]||"default";A[u]=(A[u]||0)+1}continue}else{v.push({pageIndex:B++,pageAttrs:{...ut,"custom-slidev-src":Z},notes:"",rawMarkdown:`> 📄 **引入外部幻灯片页面**: \`${Z}\`
>
> *提示：如需展示该页面完整内容，请将关联子页面一同打包为 .zip 或通过本地工程导入。*`,hasVueComponent:!1,hasStyleTag:!1,assetReferences:[]});const T=ut[ft]||"default";A[T]=(A[T]||0)+1;continue}}const it={};S.layout&&(it[ft]=String(S.layout)),S.transition&&(it[Xt]=String(S.transition)),S.background&&(it[Ut]=String(S.background)),S.image&&(it[Ae]=String(S.image)),S.class&&(it[Ni]=String(S.class));for(const[Z,lt]of Object.entries(S))["layout","transition","background","image","class"].includes(Z)||(it[`custom-slidev-${Z}`]=typeof lt=="object"?JSON.stringify(lt):String(lt));let j=G;const st=[];let K=j.replace(/(?:^[ \t]*(`{3,}|~{3,})[^\n\r]*\r?\n[\s\S]*?\r?\n[ \t]*\1(?=[ \t]*(?:\r?\n|$)))/gm,Z=>{const lt=`__CODE_TOKEN_NOTE_${st.length}__`;return st.push(Z),lt});K=K.replace(/(`+)(?:[^\n\r`]|(?!\1)`)+?\1/g,Z=>{const lt=`__CODE_TOKEN_NOTE_${st.length}__`;return st.push(Z),lt});let Y="";const H=Array.from(K.matchAll(/<!--([\s\S]*?)-->/g));if(H.length>0){const Z=H[H.length-1],lt=K.slice(Z.index+Z[0].length).trim();if(!lt||!lt.replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi,"").trim()){const T=Z[1].trim();T.startsWith("TODO:")||(Y=T,w++),e&&(K=K.slice(0,Z.index).trimEnd()+K.slice(Z.index+Z[0].length))}}e&&(K=K.replace(/<!--(?![\s\S]*?TODO:)[\s\S]*?-->/g,"").trim());for(let Z=0;Z<st.length;Z++)K=K.replace(`__CODE_TOKEN_NOTE_${Z}__`,st[Z]);if(j=K,Y){for(let ut=0;ut<st.length;ut++)Y=Y.replace(`__CODE_TOKEN_NOTE_${ut}__`,st[ut]);const lt=`> [!NOTE] 💡 演讲备注
${Y.split(/\r?\n/).map(ut=>`> ${ut}`).join(`
`)}
{: custom-slidev-note="true"}`;j=j?`${j}

${lt}`:lt}let L=!1;if(/<style\b/i.test(j)){L=!0;const Z=j.match(/<style\b[^>]*>([\s\S]*?)<\/style>/gi);if(Z){for(const lt of Z){const ut=lt.replace(/<style\b[^>]*>|<\/style>/gi,"").trim();y=y?`${y}

${ut}`:ut}l&&(j=j.replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi,"").trim())}}const ct=j.match(/<v-click[^>]*>|<v-clicks[^>]*>|v-click=/g);ct&&(x+=ct.length);const rt=j.match(/```\w+\s+\{[^}]+\}/g);rt&&(E+=rt.length);const ot=j.match(/::\w+::|<template\s+#[^>]+>/g);if(ot&&(_+=ot.length),j=j.replace(/^[ \t]*<<<[ \t]+([^\n\r]+)/gm,Z=>Kg(Z,{...i,virtualFiles:c})||Z),n&&(j=j.replace(/<v-click(?:\s+at="[^"]*")?(?:\s+hide)?>\s*([\s\S]*?)\s*<\/v-click>/gi,"$1")),s&&(j=j.replace(/(^```\w+(?:[ \t]+\[[^\]]*\])?)[ \t]+\{[^}]+\}(?:[ \t]+\w+)?/gm,"$1"),j=j.replace(/^\$\$\s+\{[^}]+\}/gm,()=>"$$")),r&&(j=j.replace(/^::\w+::\s*$/gm,"")),o&&(j=Vg(j)),a){let Z=j.trim(),lt="";const ut=Z.lastIndexOf("> [!NOTE] 💡 演讲备注");if(ut!==-1&&(lt=Z.slice(ut),Z=Z.slice(0,ut).trim()),(S.layout==="image-left"||S.layout==="image-right")&&S.image){const T=String(S.image).trim(),O=S.layout==="image-left"?"image-left":"image-right",u=`![配图](${T})
{: custom-slidev-layout="${O}" }`;S.layout==="image-left"?Z=`{{{col

${u}

${Z}

}}}`:Z=`{{{col

${Z}

${u}

}}}`}if(S.background){const O=`![背景图](${String(S.background).trim()})
{: custom-slidev-role="background" }`;Z=Z?`${O}

${Z}`:O}j=lt?`${Z}

${lt}`:Z}const J=Yg(j);it[Ut]&&J.push(it[Ut]),it[Ae]&&J.push(it[Ae]);for(const Z of J)C.add(Z);const mt=/<[A-Z][a-zA-Z0-9]+/.test(j),gt=it[ft]||(B===1?m[ft]||"cover":"default");A[gt]=(A[gt]||0)+1,v.push({pageIndex:B++,pageAttrs:it,notes:Y,rawMarkdown:j,hasVueComponent:mt,hasStyleTag:L,assetReferences:J})}if(!p&&v.length>0){const R=v[0].rawMarkdown.match(/^#\s+(.+)$/m);R&&(p=R[1].trim())}y&&(m["custom-slidev-custom-css"]=y);let P=v.map(R=>`---

${R.rawMarkdown}`).join(`

`);return P.trimStart().startsWith("---")||(P=`---

${P.trimStart()}`),{docTitle:p||"Slidev 演示文稿",docRootAttrs:m,slides:v,totalSlides:v.length,stats:{totalNotes:w,totalVClicks:x,totalShikiHighlights:E,totalSlots:_,discoveredAssets:Array.from(C),layoutDistribution:A},flattenedMarkdown:P,customCss:y}}function Yg(t){const i=[],e=/!\[.*?\]\((.*?)\)/g;let n;for(;(n=e.exec(t))!==null;){const r=n[1].split(/\s+/)[0].trim();r&&i.push(r)}const s=/<(?:img|video|source|audio)\b[^>]*src=["'](.*?)["']/gi;for(;(n=s.exec(t))!==null;){const r=n[1].trim();r&&i.push(r)}return i}const Jg={class:"spm-import-dialog"},Xg={class:"spm-tabs-header"},Qg={class:"spm-dialog-body"},tv={key:0,class:"spm-file-section"},ev={key:0,class:"spm-dropzone-prompt"},iv={key:1,class:"spm-dropzone-active"},nv={class:"spm-file-badge"},sv={class:"spm-file-size"},ov={key:1,class:"spm-text-section"},rv={key:2,class:"spm-error-banner"},lv={key:3,class:"spm-preview-card"},av={class:"spm-config-grid"},cv={class:"spm-form-item"},dv={class:"spm-form-item"},uv=["value"],fv={class:"spm-stats-grid"},pv={class:"spm-stat-box"},hv={class:"spm-stat-value"},mv={class:"spm-stat-box"},gv={class:"spm-stat-value"},vv={class:"spm-stat-box"},bv={class:"spm-stat-value"},yv={class:"spm-stat-box"},wv={class:"spm-stat-value"},kv={key:0,class:"spm-chips-row"},xv={class:"spm-options-group"},_v={class:"spm-checkbox-label"},Sv={class:"spm-checkbox-label"},Cv={class:"spm-checkbox-label"},$v={class:"spm-checkbox-label"},Iv={class:"spm-dialog-footer"},Av=["disabled"],Ev=["disabled"],Tv={key:0},Mv={key:1},Bv=be({__name:"SlidevImportDialog",emits:["close","success"],setup(t,{emit:i}){const e=i,n=Qe("plugin"),s=ht("file"),r=ht(!1),l=ht(!1),o=ht(""),a=ht(null),c=ht(null),d=ht(""),h=ht(0),m=ht(""),p=ht([]),y=ht(null),f=ht(""),k=ht([]),v=ht(""),w=ht(!0),x=ht(!0),E=ht(!0),_=ht(!0);async function C(){c.value?await U(c.value):m.value&&it()}const A=$t(()=>{const K=h.value;if(K===0)return"0 B";const Y=1024,H=["B","KB","MB","GB"],L=Math.floor(Math.log(K)/Math.log(Y));return`${(K/Y**L).toFixed(1)} ${H[L]}`}),B=$t(()=>{var K;return((K=y.value)==null?void 0:K.docRootAttrs["custom-slidev-theme"])||"default"}),P=$t(()=>{var K;return p.value.length>0?p.value.length:((K=y.value)==null?void 0:K.stats.discoveredAssets.length)||0}),R=$t(()=>{var Y;const K=((Y=y.value)==null?void 0:Y.stats.layoutDistribution)||{};return Object.entries(K).map(([H,L])=>({name:H,count:L}))});Cn(async()=>{try{const K=await fa();K!=null&&K.notebooks&&Array.isArray(K.notebooks)&&(k.value=K.notebooks.filter(Y=>!Y.closed),k.value.length>0&&(v.value=k.value[0].id))}catch(K){console.warn("获取笔记本列表失败:",K)}});function X(){var K;(K=a.value)==null||K.click()}function S(){c.value=null,d.value="",h.value=0,y.value=null,p.value=[],o.value=""}async function G(K){const Y=K.target;Y.files&&Y.files[0]&&await U(Y.files[0])}async function b(K){var Y;r.value=!1,(Y=K.dataTransfer)!=null&&Y.files&&K.dataTransfer.files[0]&&await U(K.dataTransfer.files[0])}async function U(K){o.value="",c.value=K,d.value=K.name,h.value=K.size;try{if(K.name.toLowerCase().endsWith(".zip")){const H=await K.arrayBuffer(),L=await Hg(H);if(!L.entryMarkdown){o.value="未在 Zip 压缩包中找到 slides.md 或任何有效的 Markdown 入口文件";return}p.value=L.assets;const ct=Wn(L.entryMarkdown,{stripNotesFromMarkdown:x.value,cleanHtmlToMarkdown:w.value,cleanSlots:!1,virtualFiles:L.virtualFiles});y.value=ct,f.value=ct.docTitle||K.name.replace(/\.zip$/i,"")}else{const H=await K.text();p.value=[];const L=K.path||"",ct=L?L.replace(/[\\/][^\\/]+$/,""):"",rt=Wn(H,{stripNotesFromMarkdown:x.value,cleanHtmlToMarkdown:w.value,cleanSlots:!1,baseDir:ct||void 0});y.value=rt,f.value=rt.docTitle||K.name.replace(/\.md$/i,"")}}catch(Y){console.error("解析文件失败:",Y),o.value=`解析文件失败: ${Y.message||String(Y)}`}}function it(){if(o.value="",!m.value.trim()){y.value=null;return}try{const K=Wn(m.value,{stripNotesFromMarkdown:x.value,cleanHtmlToMarkdown:w.value,cleanSlots:!1});y.value=K,f.value=K.docTitle||"Slidev 演示文稿"}catch(K){o.value=`解析 Markdown 源码失败: ${K.message||String(K)}`}}async function j(){var K;if(y.value){if(!v.value&&k.value.length>0&&(v.value=k.value[0].id),!v.value){o.value="请先选择目标笔记本";return}l.value=!0,o.value="";try{const Y=y.value,H={};if(E.value&&p.value.length>0){const lt=[];for(const ut of p.value){const T=new File([ut.data],ut.fileName,{type:"application/octet-stream"});lt.push(T)}try{const ut=await ha("/data/assets",lt);if(ut!=null&&ut.succMap)for(const[T,O]of Object.entries(ut.succMap))H[T]=String(O)}catch(ut){console.warn("上传本地静态资产失败，保留原路径:",ut)}}Object.keys(H).length>0&&Ug(Y,H);const L=(f.value.trim()||"Slidev 演示文稿").replace(/[\\/:*?"<>|]/g,"_"),ct=`/${L}`,rt=await pa(v.value,ct,Y.flattenedMarkdown);if(!rt)throw new Error("思源内核创建文档失败，未返回有效 DocumentId");const ot=((K=Y.slides[0])==null?void 0:K.pageAttrs)||{};await zt(rt,{...ot,...Y.docRootAttrs});const J=await Vn(rt).catch(()=>[]),mt=lt=>{if(!lt)return!1;const ut=String(lt.type||"").toLowerCase(),T=String(lt.markdown||"").trim(),O=String(lt.content||"").trim();return ut==="tb"||ut==="thematic-break"||ut==="nodethematicbreak"||T==="---"||T==="***"||O==="---"||O==="***"},gt=J.filter(mt);if(gt.length>=Y.slides.length)for(let lt=0;lt<Y.slides.length;lt++){const ut=Y.slides[lt],T=gt[lt];T&&T.id&&Object.keys(ut.pageAttrs).length>0&&await zt(T.id,ut.pageAttrs)}else for(let lt=1;lt<Y.slides.length;lt++){const ut=Y.slides[lt],T=gt[lt-1];T&&T.id&&Object.keys(ut.pageAttrs).length>0&&await zt(T.id,ut.pageAttrs)}let Z=!1;for(const lt of J){if(mt(lt)){Z=!1;continue}const ut=(lt.markdown||lt.content||"").trim();if(ut==="::right::"||ut.startsWith("::right::")){Z=!0;continue}Z&&lt.id&&await zt(lt.id,{[Et]:"right"}).catch(()=>{})}vt.showMessage(`🎉 成功导入 Slidev 演示文档《${L}》！`),e("success",{docId:rt}),e("close"),_.value&&n&&(n.currentDocId=rt,await vt.openTab({app:n.app,doc:{id:rt}}),n.openBottomPreviewTab&&n.openBottomPreviewTab())}catch(Y){console.error("导入 Slidev 演示失败:",Y),o.value=`导入执行失败: ${Y.message||String(Y)}`}finally{l.value=!1}}}function st(){e("close")}return(K,Y)=>(tt(),nt("div",{class:"spm-modal-overlay",onClick:Ee(st,["self"])},[g("div",Jg,[g("div",{class:"spm-dialog-header"},[Y[11]||(Y[11]=g("div",{class:"spm-dialog-title"},[g("svg",{class:"spm-dialog-icon","aria-hidden":"true"},[g("use",{"xlink:href":"#iconSlidev"})]),g("span",null,"导入 Slidev 演示文档")],-1)),g("button",{class:"spm-close-btn",title:"关闭",onClick:st},"✕")]),g("div",Xg,[g("button",{class:Tt(["spm-tab-btn",{active:s.value==="file"}]),onClick:Y[0]||(Y[0]=H=>s.value="file")}," 📦 文件 / 压缩包导入 (.zip / .md) ",2),g("button",{class:Tt(["spm-tab-btn",{active:s.value==="text"}]),onClick:Y[1]||(Y[1]=H=>s.value="text")}," 📝 粘贴 Markdown 源码 ",2)]),g("div",Qg,[s.value==="file"?(tt(),nt("div",tv,[g("div",{class:Tt(["spm-dropzone",{dragover:r.value,"has-file":!!d.value}]),onDragover:Y[2]||(Y[2]=Ee(H=>r.value=!0,["prevent"])),onDragleave:Y[3]||(Y[3]=Ee(H=>r.value=!1,["prevent"])),onDrop:Ee(b,["prevent"]),onClick:X},[g("input",{ref_key:"fileInputRef",ref:a,type:"file",accept:".zip,.md",class:"spm-hidden-input",onChange:G},null,544),d.value?(tt(),nt("div",iv,[g("span",nv,"📄 "+St(d.value),1),g("span",sv,"("+St(A.value)+")",1),g("button",{class:"spm-btn-text",onClick:Ee(S,["stop"])},"更换文件")])):(tt(),nt("div",ev,[...Y[12]||(Y[12]=[g("span",{class:"spm-dropzone-icon"},"📁",-1),g("p",{class:"spm-dropzone-text"},"点击选择文件，或直接拖拽文件至此处",-1),g("p",{class:"spm-dropzone-hint"},[Gs(" 支持 Slidev 完整工程 "),g("strong",null,".zip"),Gs("（自动解包 public/ 静态素材）或单文件 "),g("strong",null,".md")],-1)])]))],34)])):(tt(),nt("div",ov,[Ie(g("textarea",{"onUpdate:modelValue":Y[4]||(Y[4]=H=>m.value=H),class:"spm-textarea spm-source-editor",rows:"8",placeholder:"在此直接粘贴包含 Frontmatter 的 Slidev slides.md 源码...",onInput:it},null,544),[[es,m.value]])])),o.value?(tt(),nt("div",rv," ⚠️ "+St(o.value),1)):Ft("",!0),y.value?(tt(),nt("div",lv,[Y[24]||(Y[24]=g("div",{class:"spm-preview-card__header"},[g("span",null,"✨ 演示解析摘要"),g("span",{class:"spm-badge-success"},"预检就绪")],-1)),g("div",av,[g("div",cv,[Y[13]||(Y[13]=g("label",{class:"spm-form-label"},"笔记文档标题",-1)),Ie(g("input",{"onUpdate:modelValue":Y[5]||(Y[5]=H=>f.value=H),class:"spm-input",placeholder:"思源新文档标题"},null,512),[[es,f.value]])]),g("div",dv,[Y[14]||(Y[14]=g("label",{class:"spm-form-label"},"存放目标笔记本",-1)),Ie(g("select",{"onUpdate:modelValue":Y[6]||(Y[6]=H=>v.value=H),class:"spm-select"},[(tt(!0),nt(Gt,null,ye(k.value,H=>(tt(),nt("option",{key:H.id,value:H.id},St(H.name),9,uv))),128))],512),[[nu,v.value]])])]),g("div",fv,[g("div",pv,[g("span",hv,St(y.value.totalSlides),1),Y[15]||(Y[15]=g("span",{class:"spm-stat-label"},"幻灯片页数",-1))]),g("div",mv,[g("span",gv,St(B.value),1),Y[16]||(Y[16]=g("span",{class:"spm-stat-label"},"演示主题",-1))]),g("div",vv,[g("span",bv,St(y.value.stats.totalNotes),1),Y[17]||(Y[17]=g("span",{class:"spm-stat-label"},"演讲者提词",-1))]),g("div",yv,[g("span",wv,St(P.value),1),Y[18]||(Y[18]=g("span",{class:"spm-stat-label"},"关联本地素材",-1))])]),R.value.length>0?(tt(),nt("div",kv,[Y[19]||(Y[19]=g("span",{class:"spm-chips-label"},"页面版式分布：",-1)),(tt(!0),nt(Gt,null,ye(R.value,H=>(tt(),nt("span",{key:H.name,class:"spm-chip-badge"},St(H.name)+": "+St(H.count),1))),128))])):Ft("",!0),g("div",xv,[g("label",_v,[Ie(g("input",{"onUpdate:modelValue":Y[7]||(Y[7]=H=>w.value=H),type:"checkbox",onChange:C},null,544),[[Ln,w.value]]),Y[20]||(Y[20]=g("span",null,"智能剥离展示型 HTML 容器为干净原生的 Markdown 笔记块",-1))]),g("label",Sv,[Ie(g("input",{"onUpdate:modelValue":Y[8]||(Y[8]=H=>x.value=H),type:"checkbox",onChange:C},null,544),[[Ln,x.value]]),Y[21]||(Y[21]=g("span",null,"提取演讲者提词到块属性并保持正文笔记清爽",-1))]),g("label",Cv,[Ie(g("input",{"onUpdate:modelValue":Y[9]||(Y[9]=H=>E.value=H),type:"checkbox"},null,512),[[Ln,E.value]]),Y[22]||(Y[22]=g("span",null,"自动上传关联素材至思源资产库并重写路径 (assets/...)",-1))]),g("label",$v,[Ie(g("input",{"onUpdate:modelValue":Y[10]||(Y[10]=H=>_.value=H),type:"checkbox"},null,512),[[Ln,_.value]]),Y[23]||(Y[23]=g("span",null,"导入后自动打开新文档并开启下方分屏放映预览",-1))])])])):Ft("",!0)]),g("div",Iv,[g("button",{class:"spm-btn-secondary",disabled:l.value,onClick:st}," 取消 ",8,Av),g("button",{class:"spm-btn-primary",disabled:!y.value||l.value,onClick:j},[l.value?(tt(),nt("span",Tv,"⏳ 正在导入生成中...")):(tt(),nt("span",Mv,"🚀 确认导入思源笔记"))],8,Ev)])])]))}}),Dv=Le(Bv,[["__scopeId","data-v-8771dc8a"]]),Ov={class:"spm-slidev-inspector"},Pv={class:"spm-inspector-topbar"},Lv={class:"spm-inspector-title"},Rv={class:"slidev-icon",style:{fill:"none !important"},"aria-hidden":"true",viewBox:"0 0 24 24"},zv={class:"spm-inspector-topbar-actions"},Nv={class:"spm-target-banner"},Fv={class:"spm-target-info"},jv=["aria-label"],Hv={key:0,class:"spm-save-status"},Uv=["title"],Wv={class:"spm-inspector-body"},Vv=be({__name:"SlidevInspectorDockView",setup(t,{expose:i}){const e=Qe("plugin"),n=ht(!1);function s(V){n.value=!1,c.value=V.docId,e!=null&&e.compileCurrentDocument&&e.compileCurrentDocument(V.docId)}const r=ht(""),l=ht(""),o=ht({}),a=ht(""),c=ht(""),d=ht(""),h=ht(""),m=ht(""),p=ht(null),y=ht(""),f=ht("");let k=null;function v(V="已同步"){y.value=V,k&&window.clearTimeout(k),k=window.setTimeout(()=>{y.value=""},1200)}function w(){var at;const V=r.value||c.value;V&&(at=navigator==null?void 0:navigator.clipboard)!=null&&at.writeText&&navigator.clipboard.writeText(V).then(()=>{f.value="已复制！",setTimeout(()=>{f.value=""},1500)}).catch(()=>{})}const x=$t(()=>l.value==="NodeThematicBreak"),E=$t(()=>l.value==="NodeCodeBlock"),_=ht(!1),C=$t(()=>{if(_.value||M.value)return!0;const V=a.value||"";return!!fi(V)}),A=$t(()=>{const V=l.value||"";if(V==="NodeVideo"||V==="video")return!0;const at=a.value||"";return!!(/<video\b/i.test(at)||/\.mp4\b/i.test(at))}),B=$t(()=>!r.value||r.value===c.value||l.value==="doc"||l.value==="NodeDocument"),P=$t(()=>{const V=r.value||c.value||"";return V.length>8?V.slice(-8):V||"无"}),R=$t(()=>a.value?a.value.replace(/<[^>]+>/g,"").replace(/[\r\n]+/g," ").trim().slice(0,45):""),X=$t(()=>{if(x.value)return"分页符 (---)";if(B.value)return"全局文档";if(A.value)return"视频块";switch(l.value){case"NodeHeading":return"标题块";case"NodeParagraph":return"段落块";case"NodeCodeBlock":return"代码块";case"NodeVideo":return"视频块";case"NodeList":case"NodeListItem":return"列表项";case"NodeBlockquote":return"引述块";case"NodeTable":return"表格块";case"NodeSuperBlock":case"s":case"sb":return"超级块";default:return"内容块"}}),S=$t(()=>x.value?"tag-divider":B.value?"tag-doc":"tag-block"),G=$t(()=>o.value[ft]||"default"),b=$t(()=>o.value[Xt]||"slide-left"),U=ht(""),it=ht(""),j=$t(()=>{var At;if(!((At=p.value)!=null&&At.slides)||p.value.slides.length===0)return null;const V=r.value,at=d.value,yt=h.value;if(yt){let _t=p.value.slides.find(Dt=>Dt.startBlockId===yt);if(_t||(_t=p.value.slides.find(Dt=>{var Ot,Pt;return((Pt=(Ot=Dt.blocks)==null?void 0:Ot[0])==null?void 0:Pt.id)===yt}),_t))return _t}if(V){let _t=p.value.slides.find(Ot=>Ot.startBlockId===V);if(_t||(_t=p.value.slides.find(Ot=>{var Pt,Zt;return((Pt=Ot.blocks)==null?void 0:Pt.some(Bt=>Bt.id===V))||((Zt=Ot.allBlockIds)==null?void 0:Zt.includes(V))}),_t)||at&&at!==V&&(_t=p.value.slides.find(Ot=>{var Pt,Zt;return((Pt=Ot.blocks)==null?void 0:Pt.some(Bt=>Bt.id===at))||((Zt=Ot.allBlockIds)==null?void 0:Zt.includes(at))}),_t)||(_t=p.value.slides.find(Ot=>{var Pt;return(Pt=Ot.noteBlocks)==null?void 0:Pt.some(Zt=>Zt.id===V||Zt.id===at)}),_t))return _t;const Dt=o.value[Et];if(Dt&&["col-1","col-2","col-3"].includes(Dt)&&(_t=p.value.slides.find(Ot=>{var Pt,Zt;return((Pt=Ot.frontmatter)==null?void 0:Pt.layout)==="three-cols-header"||((Zt=Ot.blocks)==null?void 0:Zt.some(Bt=>Bt.slot==="col-1"||Bt.slot==="col-2"||Bt.slot==="col-3"))}),_t))return _t}return p.value.slides[0]||null}),st=$t(()=>{var V;return((V=j.value)==null?void 0:V.notes)||""}),K=$t(()=>{var V,at,yt;return((yt=(at=(V=j.value)==null?void 0:V.noteBlocks)==null?void 0:at[0])==null?void 0:yt.id)||""}),Y=$t(()=>{var At,_t,Dt,Ot,Pt,Zt;if(x.value){const Bt=o.value[ft]||o.value["custom-slidev-layout"];if(Bt)return Bt}const V=o.value[Et]||o.value["custom-slidev-slot"];if(V&&["col-1","col-2","col-3"].includes(V))return"three-cols-header";if(m.value)return m.value;const at=h.value||(x.value?r.value:"");if(at){const Bt=Ht.getBlockAttrOverride(at);if(Bt!=null&&Bt[ft])return Bt[ft]}if(at&&((At=p.value)!=null&&At.slides)){const Bt=p.value.slides.find(li=>li.startBlockId===at);if((_t=Bt==null?void 0:Bt.frontmatter)!=null&&_t.layout)return Bt.frontmatter.layout}if((Ot=(Dt=j.value)==null?void 0:Dt.frontmatter)!=null&&Ot.layout)return j.value.frontmatter.layout;if((Zt=(Pt=j.value)==null?void 0:Pt.blocks)!=null&&Zt.some(Bt=>Bt.slot==="col-1"||Bt.slot==="col-2"||Bt.slot==="col-3"))return"three-cols-header";const yt=Ht.getBlockAttrOverride(c.value);return yt!=null&&yt[ft]?yt[ft]:"default"}),H=$t(()=>{var V;return((V=j.value)==null?void 0:V.pageIndex)||1}),L=$t(()=>!!(o.value[ie]||o.value["slidev-note"])),ct=$t(()=>{var at;if(o.value[Se])return o.value[Se];const V=r.value;if(V&&((at=j.value)!=null&&at.blocks)){const yt=j.value.blocks.find(At=>At.id===V);if(yt!=null&&yt.clicks)return yt.clicks}return""}),rt=$t(()=>{var at;if(o.value[He])return o.value[He];const V=r.value;if(V&&((at=j.value)!=null&&at.blocks)){const yt=j.value.blocks.find(At=>At.id===V);if(yt!=null&&yt.motion)return typeof yt.motion=="string"?yt.motion:JSON.stringify(yt.motion)}return""}),ot=$t(()=>{var at;if(o.value[Et])return o.value[Et];const V=r.value;if(V&&((at=j.value)!=null&&at.blocks)){const yt=j.value.blocks.find(At=>At.id===V);if(yt!=null&&yt.slot)return yt.slot}return""}),J=ht(""),mt=ht(""),gt=$t(()=>o.value[vi]==="true"),Z=$t(()=>o.value[Tn]==="true"),lt=$t(()=>o.value[Oi]==="true"),ut=$t(()=>o.value[Mn]!=="false");async function T(){(gt.value?"false":"true")==="true"?(await N({[vi]:"true",[Oi]:"true"}),o.value[vi]="true",o.value[Oi]="true"):(await q(vi,"false"),o.value[vi]="false")}async function O(){const V=Z.value?"false":"true";await q(Tn,V)}async function u(){const V=lt.value?"false":"true";await q(Oi,V)}async function z(){const V=ut.value?"false":"true";await q(Mn,V)}const D=$t(()=>{var V,at;return((at=(V=p.value)==null?void 0:V.config)==null?void 0:at.theme)||o.value[rn]||"default"}),$=$t(()=>{var V,at;return((at=(V=p.value)==null?void 0:V.config)==null?void 0:at.aspectRatio)||o.value[ln]||"16/9"}),I=$t(()=>{var V,at;return((at=(V=p.value)==null?void 0:V.config)==null?void 0:at.defaultTransition)||o.value[an]||"slide-left"}),M=$t(()=>{var _t,Dt;if((o.value[qt]||o.value["slidev-role"])===Cr||o.value[Ut]==="true")return"background";const at=o.value[ft]||o.value["slidev-layout"];if(at==="image-left"||at==="image-right")return at;const yt=a.value||"",At=fi(yt);if(At&&((Dt=(_t=j.value)==null?void 0:_t.frontmatter)!=null&&Dt.background)){const Ot=j.value.frontmatter.background;if(Ot===At||Ot.endsWith(At)||At.endsWith(Ot))return"background"}return""});async function W(V){var Dt;const at=r.value;if(!at)return;const yt=a.value||"",At=fi(yt)||"",_t=h.value||c.value;if(V)if(V==="background"){const Ot={[qt]:"background",[ft]:""};_t&&At&&(U.value=At,await zt(_t,{[Ut]:At}).catch(()=>{}),Ht.setBlockAttrOverride(_t,{[Ut]:At}),se(_t,{[Ut]:At}),j.value&&(j.value.frontmatter||(j.value.frontmatter={}),j.value.frontmatter.background=At)),await N(Ot)}else(V==="image-left"||V==="image-right")&&await N({[ft]:V,[qt]:""});else{const Ot={[qt]:"",[ft]:""};if(o.value[Ut]==="true"&&(Ot[Ut]=""),_t&&At&&U.value===At&&(U.value="",await zt(_t,{[Ut]:""}).catch(()=>{}),Ht.setBlockAttrOverride(_t,{[Ut]:""}),se(_t,{[Ut]:""}),(Dt=j.value)!=null&&Dt.frontmatter&&delete j.value.frontmatter.background),await N(Ot),typeof document<"u"){const Pt=document.querySelector(`.protyle-wysiwyg [data-node-id="${at}"]`),Zt=Pt==null?void 0:Pt.closest('[data-type="NodeListItem"]'),Bt=Zt==null?void 0:Zt.getAttribute("data-node-id");if(Bt&&Bt!==at){const li={[ft]:"",[qt]:""};se(Bt,li),Ht.setBlockAttrOverride(Bt,li),await zt(Bt,li).catch(()=>{})}}}}async function N(V){const at=r.value||c.value;if(at){for(const[yt,At]of Object.entries(V))o.value[yt]=At;if(Ht.setBlockAttrOverride(at,V),se(at,V),ft in V){const yt=V[ft];m.value=yt,j.value&&(j.value.frontmatter||(j.value.frontmatter={}),j.value.frontmatter.layout=yt)}v("保存中...");try{await zt(at,V),v("已同步"),e&&await e.compileCurrentDocument()}catch{v("同步失败")}}}const F=$t(()=>!!(o.value[Se]||o.value[He]||o.value[Et]||o.value[Si]||o.value[ie]||o.value["slidev-note"]||o.value[qt]||o.value[ft]||o.value[vi]||o.value[Tn]||o.value[Oi]||o.value[Mn]));async function q(V,at){const yt=r.value||c.value;if(yt){o.value[V]=at,Ht.setBlockAttrOverride(yt,{[V]:at}),se(yt,{[V]:at}),V===ft&&(m.value=at,j.value&&(j.value.frontmatter||(j.value.frontmatter={}),j.value.frontmatter.layout=at)),v("保存中...");try{await zt(yt,{[V]:at}),v("已同步"),e&&await e.compileCurrentDocument()}catch{v("同步失败")}}}async function et(V,at){var At;const yt=c.value||r.value;if(yt){o.value[V]=at,Ht.setBlockAttrOverride(yt,{[V]:at}),se(yt,{[V]:at}),(At=p.value)!=null&&At.config&&(V===rn&&(p.value.config.theme=at),V===ln&&(p.value.config.aspectRatio=at),V===an&&(p.value.config.defaultTransition=at)),v("更新中...");try{await zt(yt,{[V]:at}),v("已更新"),e&&await e.compileCurrentDocument(yt)}catch{v("更新失败")}}}function Q(V){q(ft,V)}function dt(V){q(Xt,V)}function xt(V){U.value=V,q(Ut,V)}function bt(V){it.value=V,q(Ae,V)}async function Mt(){const V=r.value;if(V)if(L.value){v("取消中...");try{await zt(V,{[ie]:"","slidev-note":""}),Ht.setBlockAttrOverride(V,{[ie]:"","slidev-note":""}),se(V,{[ie]:"","slidev-note":""}),delete o.value[ie],delete o.value["slidev-note"],v("已取消备注"),vt.showMessage("已取消讲稿备注"),e&&await e.compileCurrentDocument()}catch(at){console.error("[SiYuanSlidev] 取消讲稿备注失败:",at),v("取消失败"),vt.showMessage("取消讲稿备注失败")}}else{v("转换中...");try{let at=a.value;try{const Dt=await ga(V);Dt!=null&&Dt.kramdown&&(at=Dt.kramdown)}catch{}const _t=`> [!NOTE] 💡 演讲备注
${(Er(at)||at.replace(/<[^>]+>/g,"").trim()||"在此输入本页讲稿提词...").split(/\r?\n/).map(Dt=>`> ${Dt}`).join(`
`)}
{: custom-slidev-note="true"}`;await Do("markdown",_t,V),await zt(V,{[ie]:"true"}),Ht.setBlockAttrOverride(V,{[ie]:"true"}),se(V,{[ie]:"true"}),o.value[ie]="true",l.value="NodeCallout",v("已设为讲稿备注"),vt.showMessage("已转为讲稿备注提示块（不在幻灯片中渲染）"),e&&await e.compileCurrentDocument()}catch(at){console.error("[SiYuanSlidev] 转换讲稿备注提示块失败:",at),v("设置失败"),vt.showMessage("转为讲稿备注提示块失败")}}}async function Vt(V){var Bt,li,Ao,Eo,To,Mo,Bo;const At=`> [!NOTE] 💡 演讲备注
${(V||"在此输入本页讲稿提词...").split(/\r?\n/).map(Re=>`> ${Re}`).join(`
`)}
{: custom-slidev-note="true"}`,_t=((Bt=p.value)==null?void 0:Bt.slides)||[],Dt=j.value,Ot=Dt?_t.findIndex(Re=>Re===Dt):-1;let Pt=null;if(Ot!==-1&&Ot<_t.length-1){const Re=_t[Ot+1];Pt=await nn("markdown",At,Re.startBlockId)}else{const Re=((li=Dt==null?void 0:Dt.noteBlocks)==null?void 0:li.slice(-1)[0])||((Ao=Dt==null?void 0:Dt.blocks)==null?void 0:Ao.slice(-1)[0]);Re!=null&&Re.id?Pt=await nn("markdown",At,void 0,Re.id):Pt=await kr("markdown",At,c.value)}const Zt=((Mo=(To=(Eo=Pt==null?void 0:Pt[0])==null?void 0:Eo.doOperations)==null?void 0:To[0])==null?void 0:Mo.id)||((Bo=Pt==null?void 0:Pt[0])==null?void 0:Bo.id);return Zt&&(await zt(Zt,{[ie]:"true"}),Ht.setBlockAttrOverride(Zt,{[ie]:"true"}),Ti(Zt,e==null?void 0:e.app)),e&&await e.compileCurrentDocument(),Zt}async function Yt(){try{await Vt(),vt.showMessage("已在正文末尾插入讲稿备注提示块")}catch(V){vt.showMessage("插入讲稿备注块失败"),console.error(V)}}function ee(){const V=K.value;if(!V){vt.showMessage("未找到本页关联的讲稿备注块");return}Ti(V,e==null?void 0:e.app)?vt.showMessage("已在编辑区定位讲稿备注块"):vt.showMessage("定位讲稿备注块失败")}async function Nt(){if(!c.value)return;const V=j.value||{startBlockId:r.value||c.value,blocks:a.value&&a.value!=="---"?[{id:r.value,type:l.value,content:a.value,rawMarkdown:""}]:[],rawMarkdown:a.value&&a.value!=="---"?a.value:""};vt.showMessage("正在调用思源 AI 提炼本页讲稿提词...");const at=await $r(V,xr);if(at.notes){const yt=K.value;if(yt){const At=`> [!NOTE] 💡 演讲备注
${at.notes.split(/\r?\n/).map(_t=>`> ${_t}`).join(`
`)}
{: custom-slidev-note="true"}`;await Do("markdown",At,yt),await zt(yt,{[ie]:"true"}),Ht.setBlockAttrOverride(yt,{[ie]:"true"}),Ti(yt,e==null?void 0:e.app)}else await Vt(at.notes);at.isAiGenerated?vt.showMessage("思源 AI 演讲提词卡生成成功！"):vt.showMessage("未获取到思源 AI 响应，已生成预设提词卡模板",5e3),e&&await e.compileCurrentDocument()}}function Ke(){ct.value?q(Se,""):q(Se,"+1")}function te(V){q(Se,V)}function Jt(V){q(He,V)}function mi(V){(o.value[Et]||"")===V?q(Et,""):q(Et,V)}function Bi(V){J.value=V,q(Si,V)}function ms(V){mt.value=V,q(cn,V)}async function gs(){const V=Y.value==="three-cols-header";await q(Et,V?"col-1":"left"),vt.showMessage(V?"已将当前块设置为第 1 栏 (col-1)":"已将当前块设置为双栏左栏 (left)")}async function An(){const V=r.value;if(!V)return;const at={[Se]:"",[He]:"",[Et]:"",[Si]:"",[cn]:"",[ie]:"","slidev-note":"",[ft]:"",[qt]:"",[Xt]:"",[Ut]:"",[Ae]:"",[vi]:"",[Tn]:"",[Oi]:"",[Mn]:""};if(se(V,at),await zt(V,at),Ht.clearBlockAttrOverride(V),typeof document<"u"){const yt=document.querySelector(`.protyle-wysiwyg [data-node-id="${V}"]`),At=yt==null?void 0:yt.closest('[data-type="NodeListItem"]'),_t=At==null?void 0:At.getAttribute("data-node-id");_t&&_t!==V&&(se(_t,at),await zt(_t,at).catch(()=>{}),Ht.clearBlockAttrOverride(_t))}o.value={},J.value="",mt.value="",U.value="",it.value="",vt.showMessage("已清除本块演示属性"),e&&await e.compileCurrentDocument()}function gi(V){et(rn,V)}function Di(V){et(ln,V)}function Xl(V){et(an,V)}async function Ql(){if(r.value)try{await nn("markdown","---",r.value,void 0),vt.showMessage("已在上方插入分页符 (---)"),e&&e.compileCurrentDocument()}catch{vt.showMessage("插入分页符失败")}}async function $o(){const V=r.value||c.value;if(V)try{await nn("markdown","---",void 0,V),vt.showMessage("已在下方插入分页符 (---)"),e&&e.compileCurrentDocument()}catch{vt.showMessage("插入分页符失败")}}async function ta(){if(r.value)try{await ma(r.value),vt.showMessage("已删除该分页符"),r.value="",l.value="",e&&e.compileCurrentDocument()}catch{vt.showMessage("删除失败")}}function Io(){e!=null&&e.openBottomPreviewTab&&e.openBottomPreviewTab()}function ea(){window.open("/plugins/siyuan-slidev/slidev-client/presenter.html","SlidevPresenter","width=1200,height=800")}function ia(){e!=null&&e.executeCommand&&e.executeCommand("slidevAiSplit")}function na(){if(!p.value){vt.showMessage("请先在主编辑区打开幻灯片文档");return}const V=Kl(p.value);ql("presentation.html",V)&&vt.showMessage("已开始下载单文件离线 HTML 演示包")}function sa(){if(!p.value){vt.showMessage("请先在主编辑区打开幻灯片文档");return}Gl(p.value)&&vt.showMessage("已唤起打印视窗，请在打印选项中选择「另存为 PDF」")}return i({setActiveBlock(V){r.value=V.id,l.value=V.type,o.value={...V.attrs},a.value=V.content||V.markdown||"",d.value=V.topBlockId||V.id,h.value=V.pageDividerId||"",m.value=V.pageDividerLayout||"",V.rootId?c.value=V.rootId:(V.type==="doc"||V.type==="NodeDocument")&&V.id&&(c.value=V.id),U.value=V.attrs[Ut]||"",it.value=V.attrs[Ae]||"",J.value=V.attrs[Si]||"",mt.value=V.attrs[cn]||"",_.value=!!V.isImage},updateDocument(V){p.value=V,c.value=V.docId},openImportDialog(){n.value=!0},setCurrentDocId(V){c.value=V}}),(V,at)=>(tt(),nt("div",Ov,[g("div",Pv,[g("div",Lv,[(tt(),nt("svg",Rv,[...at[2]||(at[2]=[g("rect",{x:"2",y:"3",width:"20",height:"14",rx:"2"},null,-1),g("line",{x1:"8",y1:"21",x2:"16",y2:"21"},null,-1),g("line",{x1:"12",y1:"17",x2:"12",y2:"21"},null,-1)])])),at[3]||(at[3]=g("span",null,"演示配置",-1))]),g("div",zv,[g("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"导入 Slidev 演示文档 (.md / .zip)",onClick:at[0]||(at[0]=yt=>n.value=!0)},[pt(wt,{name:"import"}),at[4]||(at[4]=g("span",null,"导入",-1))]),g("button",{class:"spm-icon-btn is-primary b3-tooltips b3-tooltips__s","aria-label":"在下方分屏开启幻灯片预览 (Alt+P)",onClick:Io},[pt(wt,{name:"split-preview"}),at[5]||(at[5]=g("span",null,"分屏预览",-1))])])]),g("div",Nv,[g("div",Fv,[g("span",{class:Tt(["spm-target-tag",S.value])},St(X.value),3),g("span",{class:"spm-target-id b3-tooltips b3-tooltips__s","aria-label":f.value||"点击复制 ID: "+(r.value||c.value),onClick:w},[pt(wt,{name:"copy"}),g("span",null,"#"+St(P.value),1)],8,jv)]),y.value?(tt(),nt("span",Hv,"● "+St(y.value),1)):Ft("",!0)]),R.value?(tt(),nt("div",{key:0,class:"spm-context-quote",title:a.value},St(R.value),9,Uv)):Ft("",!0),g("div",Wv,[x.value?(tt(),Te(jh,{key:0,"page-layout":G.value,"page-transition":b.value,"page-background":U.value,"page-image":it.value,"page-notes":st.value,"page-index":H.value,"onUpdate:pageLayout":Q,"onUpdate:pageTransition":dt,"onUpdate:pageBackground":xt,"onUpdate:pageImage":bt,onAddNoteBlock:Yt,onLocateNoteBlock:ee,onGenerateNotes:Nt,onInsertDividerAfter:$o,onDeleteDivider:ta},null,8,["page-layout","page-transition","page-background","page-image","page-notes","page-index"])):r.value&&!B.value?(tt(),Te(ag,{key:1,"elem-click":ct.value,"elem-motion":rt.value,"elem-slot":ot.value,"elem-shiki-lines":J.value,"elem-max-height":mt.value,"is-code-block":E.value,"is-image":C.value,"is-video":A.value,"video-autoplay":gt.value,"video-loop":Z.value,"video-muted":lt.value,"video-controls":ut.value,"has-block-attrs":F.value,"is-note":L.value,"image-role":M.value,"current-slide-layout":Y.value,onToggleNote:Mt,onToggleElemClick:Ke,onToggleVideoAutoplay:T,onToggleVideoLoop:O,onToggleVideoMuted:u,onToggleVideoControls:z,"onUpdate:imageRole":W,"onUpdate:elemClick":te,"onUpdate:elemMotion":Jt,"onUpdate:elemSlot":mi,"onUpdate:elemShikiLines":Bi,"onUpdate:elemMaxHeight":ms,onInsertDividerBefore:Ql,onInsertDividerAfter:$o,onSetTwoColsContrast:gs,onClearBlockAttrs:An},null,8,["elem-click","elem-motion","elem-slot","elem-shiki-lines","elem-max-height","is-code-block","is-image","is-video","video-autoplay","video-loop","video-muted","video-controls","has-block-attrs","is-note","image-role","current-slide-layout"])):(tt(),Te(Pg,{key:2,"doc-theme":D.value,"doc-aspect-ratio":$.value,"doc-default-transition":I.value,"onUpdate:docTheme":gi,"onUpdate:docAspectRatio":Di,"onUpdate:docDefaultTransition":Xl,onOpenBottomPreview:Io,onOpenPresenter:ea,onAiAutoSplit:ia,onExportHtml:na,onExportPdf:sa},null,8,["doc-theme","doc-aspect-ratio","doc-default-transition"]))]),n.value?(tt(),Te(Dv,{key:1,onClose:at[1]||(at[1]=yt=>n.value=!1),onSuccess:s})):Ft("",!0)]))}}),In=new _o;let di=null,We=null;function Kv(t,i){di&&Yl(),di=zl(ph),di.provide("plugin",i),di.provide("sandboxBridge",In);const e=di.mount(t);return We=e,e}function Yl(t){di&&(di.unmount(),di=null,We=null)}let ui=null,ge=null;function qv(t,i){ui&&Jl(),ui=zl(Vv),ui.provide("plugin",i),ui.provide("sandboxBridge",In);const e=ui.mount(t);return ge=e,e}function Jl(t){ui&&(ui.unmount(),ui=null,ge=null)}function Gv(t,i){ge!=null&&ge.updateDocument&&ge.updateDocument(t),We!=null&&We.updateDocument?We.updateDocument(t,i):In.updateSlides(t.slides,t.config,t.fullMarkdown)}function Bs(t){We!=null&&We.navigateToBlock?We.navigateToBlock(t):In.highlightElement(t)}function Nn(t){ge!=null&&ge.setActiveBlock&&ge.setActiveBlock(t)}function Zv(){return ge!=null&&ge.openImportDialog?(ge.openImportDialog(),!0):!1}const Yv=[{id:"slidev-cover",name:"幻灯片 - 封面页 (Cover)",open:!0,attrs:[{key:xi,value:"true"},{key:ft,value:"cover"},{key:Xt,value:"fade"}]},{id:"slidev-two-cols",name:"幻灯片 - 双栏对比 (Two Columns)",open:!0,attrs:[{key:xi,value:"true"},{key:ft,value:"two-cols"},{key:Xt,value:"slide-left"}]},{id:"slidev-fact",name:"幻灯片 - 大字报与核心指标 (Fact)",open:!0,attrs:[{key:xi,value:"true"},{key:ft,value:"fact"},{key:Xt,value:"zoom"}]},{id:"slidev-intro",name:"幻灯片 - 章节导引与作者 (Intro)",open:!0,attrs:[{key:xi,value:"true"},{key:ft,value:"intro"},{key:Xt,value:"slide-up"}]},{id:"slidev-quote",name:"幻灯片 - 金句与强调 (Quote)",open:!0,attrs:[{key:xi,value:"true"},{key:ft,value:"quote"},{key:Xt,value:"fade"}]},{id:"slidev-elem-click",name:"元素 - 顺延逐步呈现 (v-click)",open:!0,attrs:[{key:Se,value:"+1"}]},{id:"slidev-elem-click-hide",name:"元素 - 隐藏直到激活 (v-click:hide)",open:!0,attrs:[{key:Se,value:"hide"}]},{id:"slidev-elem-slot-right",name:"元素 - 双栏右栏归属 (Slot: Right)",open:!0,attrs:[{key:Et,value:"right"}]},{id:"slidev-shiki-lines",name:"代码 - 逐行聚光高亮 (Shiki)",open:!0,attrs:[{key:Si,value:"1-3"}]}];class Ds{getPresetTemplates(){return Yv}buildScanSlidevBlocksSql(i="custom-slidev-"){return`SELECT block_id, name, value FROM attributes WHERE name LIKE '${i}%' ORDER BY block_id ASC`}buildTransitionStatsSql(){return`SELECT value, count(1) as count FROM attributes WHERE name = '${Xt}' GROUP BY value ORDER BY count DESC`}async batchUpdateTransitions(i,e,n,s){const r=`SELECT block_id FROM attributes WHERE name = '${Xt}' AND value = '${i}'`,l=await n(r);let o=0;if(Array.isArray(l))for(const a of l){const c=a.block_id||a.blockId;c&&(await s(c,{[Xt]:e}),o++)}return{updatedCount:o}}async batchUpdateLayout(i,e,n,s){const r=`SELECT block_id FROM attributes WHERE name = 'custom-slidev-layout' AND value = '${i}'`,l=await n(r);let o=0;if(Array.isArray(l))for(const a of l){const c=a.block_id||a.blockId;c&&(await s(c,{"custom-slidev-layout":e}),o++)}return{updatedCount:o}}exportTemplatesJson(){const i=this.getPresetTemplates();return JSON.stringify({templates:i,counter:i.length},null,2)}formatTransitionSummary(i){return!i||i.length===0?"全库目前暂无已设置 Slidev 转场效果的块":`全库 Slidev 转场分布统计：${i.map(n=>`${n.value}: ${n.count} 个`).join("，")}`}}const Jv=`<symbol id="iconSlidev" viewBox="0 0 1024 1024">
  <path fill="currentColor" d="M128 160h768c35.3 0 64 28.7 64 64v480c0 35.3-28.7 64-64 64H128c-35.3 0-64-28.7-64-64V224c0-35.3 28.7-64 64-64z m64 64v480h640V224H192z m128 640h384v64H320z"/>
  <path fill="currentColor" d="M416 336l256 144-256 144z"/>
</symbol>`,Xv="slidev-dock",yr="slidev-preview-tab",wr=hp;class Qv extends vt.Plugin{constructor(){super(...arguments);kt(this,"isMobile",!1);kt(this,"currentDocId","");kt(this,"latestCompiledDoc",null);kt(this,"cliBridge",new Qs);kt(this,"debounceTimer",null);kt(this,"activeCursorBlockId","");kt(this,"onSwitchProtyleBound",this.onSwitchProtyle.bind(this));kt(this,"onWsMainBound",this.onWsMain.bind(this));kt(this,"onBlockClickedBound",this.onBlockClickedFromSlide.bind(this));kt(this,"onClickEditorTitleIconBound",this.onClickEditorTitleIcon.bind(this));kt(this,"onEditorClickBound",this.onEditorClick.bind(this));kt(this,"onSelectionChangeBound",this.onSelectionChange.bind(this));kt(this,"onClickEditorContentBound",this.onClickEditorContent.bind(this))}async onload(){const e=vt.getFrontend();this.isMobile=e==="mobile"||e==="browser-mobile",await this.loadGlobalSettings(),this.addIcons(Jv),this.addTopBar({id:"slidev-topbar-play",icon:"iconSlidev",title:"Slidev 演示 (下方分屏)",position:"right",callback:()=>{this.openBottomPreviewTab()}}),this.addCommand({langKey:"slidevPresentation",langText:"Slidev: 在文档下方开启分屏演示预览",hotkey:"⌥P",enabled:()=>!0,execute:()=>{this.openBottomPreviewTab()}}),this.addCommand({langKey:"slidevImport",langText:"Slidev: 导入 Slidev 演示文档 (.md / .zip)",hotkey:"⌥I",enabled:()=>!0,execute:()=>{Zv()||vt.showMessage("请先在右侧栏打开「Slidev 演示配置」Dock 面板以呼起导入窗口")}}),this.addCommand({langKey:"slidevInitAttrs",langText:"Slidev: 初始化当前文档演示属性",hotkey:"",enabled:()=>!0,execute:async()=>{if(!this.currentDocId){const s=document.querySelector(".protyle-content[data-doc-id]");this.currentDocId=(s==null?void 0:s.getAttribute("data-doc-id"))||""}this.currentDocId&&(await zt(this.currentDocId,{"custom-slidev-theme":"default","custom-slidev-aspect-ratio":"16/9","custom-slidev-default-transition":"slide-left"}),vt.showMessage("已为当前文档初始化 Slidev 演示属性"),this.compileCurrentDocument(this.currentDocId))}}),this.addCommand({langKey:"slidevAiSplit",langText:"Slidev AI: 智能大纲断页建议与自动分页",hotkey:"",enabled:()=>!0,execute:async()=>{if(!this.currentDocId){const a=document.querySelector(".protyle-content[data-doc-id]");this.currentDocId=(a==null?void 0:a.getAttribute("data-doc-id"))||""}if(!this.currentDocId){vt.showMessage("请先打开一篇思源笔记文档");return}const s=await Vn(this.currentDocId).catch(()=>[]);if(!s||s.length===0){vt.showMessage("当前文档无内容，无需断页");return}const r=s.map(a=>({id:a.id,type:a.type,subType:a.subType,content:a.content||"",markdown:a.markdown||""})),l=ya(r);if(l.length===0){vt.showMessage("AI 分析完毕：当前文档篇幅合理，暂无分页建议");return}vt.showMessage(`AI 分析完毕：发现 ${l.length} 处建议分页点，正在自动插入分页分割线...`);let o=0;for(const a of l)try{await nn("markdown","---",void 0,a.blockId),await zt(a.blockId,{"custom-slidev-layout":a.recommendedLayout}),o++}catch(c){console.warn("Failed to insert divider:",c)}vt.showMessage(`已成功在 ${o} 处插入分页线并重新编译`),this.compileCurrentDocument(this.currentDocId)}}),this.addCommand({langKey:"slidevAiNotes",langText:"Slidev AI: 自动为当前文档生成演讲者提词卡 (Notes)",hotkey:"",enabled:()=>!0,execute:async()=>{var h,m,p,y;if(!this.currentDocId){const f=document.querySelector(".protyle-content[data-doc-id]");this.currentDocId=(f==null?void 0:f.getAttribute("data-doc-id"))||""}if(!this.currentDocId){vt.showMessage("请先打开一篇思源笔记文档");return}vt.showMessage("正在调用思源 AI 提炼演讲者口播提词...");const s=await Vn(this.currentDocId).catch(()=>[]),r={startBlockId:this.currentDocId,blocks:s.map(f=>({id:f.id,type:f.type,content:f.content||"",rawMarkdown:f.markdown||""})),rawMarkdown:""},a=`> [!NOTE] 💡 演讲备注
${(await wa(r,xr)).split(/\r?\n/).map(f=>`> ${f}`).join(`
`)}
{: custom-slidev-note="true"}`,c=await kr("markdown",a,this.currentDocId).catch(()=>null),d=((p=(m=(h=c==null?void 0:c[0])==null?void 0:h.doOperations)==null?void 0:m[0])==null?void 0:p.id)||((y=c==null?void 0:c[0])==null?void 0:y.id);d&&(await zt(d,{"custom-slidev-note":"true"}),Ht.setBlockAttrOverride(d,{"custom-slidev-note":"true"}),Ti(d,this.app)),vt.showMessage("已成功生成口播提词卡并插入为正文讲稿备注块"),this.compileCurrentDocument(this.currentDocId)}}),this.addCommand({langKey:"slidevBatchTransitions",langText:"Slidev 协同: 统计全库转场效果分布",hotkey:"",enabled:()=>!0,execute:async()=>{const s=new Ds,r=s.buildTransitionStatsSql(),l=await mn(r).catch(()=>[]),o=s.formatTransitionSummary(l||[]);vt.showMessage(o)}}),this.addCommand({langKey:"slidevExportTemplates",langText:"Slidev 协同: 复制 Slidev 预设属性模板至剪贴板",hotkey:"",enabled:()=>!0,execute:async()=>{const r=new Ds().exportTemplatesJson();typeof navigator<"u"&&navigator.clipboard?(await navigator.clipboard.writeText(r),vt.showMessage("已将 Slidev 属性模板 JSON 复制至剪贴板，可直接导入属性管家")):vt.showMessage(`已生成模板数据（请在控制台查看）：
`+r)}}),this.addCommand({langKey:"slidevBatchReplaceTransition",langText:"Slidev 协同: 批量替换全库淡入淡出转场为滑动 (fade -> slide-left)",hotkey:"",enabled:()=>!0,execute:async()=>{const r=await new Ds().batchUpdateTransitions("fade","slide-left",l=>mn(l).catch(()=>[]),(l,o)=>zt(l,o));vt.showMessage(`全库批量替换完成：已将 ${r.updatedCount} 处 fade 转场更新为 slide-left`),this.compileCurrentDocument()}}),this.addCommand({langKey:"slidevPresenterMode",langText:"Slidev: 打开双屏演讲者控制台 (Presenter Mode)",hotkey:"⌥M",enabled:()=>!0,execute:()=>{typeof window<"u"&&window.open("/plugins/siyuan-slidev/slidev-client/presenter.html","SlidevPresenter","width=1200,height=800")}}),this.addCommand({langKey:"slidevExportCliMd",langText:"Slidev Pro: 导出 Slidev 标准 slides.md 文档 (下载到本地)",hotkey:"",enabled:()=>!0,execute:async()=>{if(this.latestCompiledDoc||await this.compileCurrentDocument(),!this.latestCompiledDoc){vt.showMessage("请先打开并放映一篇思源笔记文档");return}this.cliBridge.downloadSlidesMd(this.latestCompiledDoc,`slides-${this.currentDocId||"demo"}.md`)&&vt.showMessage("已生成标准 Slidev Markdown 并触发下载，可在本地使用 npx @slidev/cli 运行")}}),this.addCommand({langKey:"slidevProbeCliDevServer",langText:"Slidev Pro: 检测本地 Slidev CLI DevServer 状态 (localhost:3030)",hotkey:"",enabled:()=>!0,execute:async()=>{vt.showMessage("正在探测本地 Slidev CLI DevServer (http://localhost:3030)..."),await this.cliBridge.probeServer(1500)?vt.showMessage("🟢 本地 Slidev CLI DevServer 运行正常！可直接在浏览器访问 http://localhost:3030"):vt.showMessage("⚪ 未检测到运行中的本地 Slidev CLI DevServer (端口 3030 未开启)")}}),this.addCommand({langKey:"slidevSyncToCliWorkspace",langText:"Slidev Pro: 同步 slides.md 至思源工作空间存储目录",hotkey:"",enabled:()=>!0,execute:async()=>{if(this.latestCompiledDoc||await this.compileCurrentDocument(),!this.latestCompiledDoc){vt.showMessage("请先打开并放映一篇思源笔记文档");return}const s=await this.cliBridge.syncToWorkspaceFile(this.latestCompiledDoc,"/data/storage/petal/siyuan-slidev/slides.md",Os);s.success?vt.showMessage(`已成功同步最新 slides.md 至工作空间：${s.path}`):vt.showMessage(`同步失败：${s.error}`)}});const n=this;if(this.addTab({type:yr,init(){Kv(this.element,n)},destroy(){Yl(this.element)}}),this.addDock({config:{position:"RightTop",size:{width:320,height:0},icon:"iconSlidev",title:"Slidev 演示配置"},data:{},type:Xv,init(){qv(this.element,n)},destroy(){Jl(this.element)}}),this.eventBus&&typeof this.eventBus.emit!="function"&&(this.eventBus.emit=(s,r)=>{try{typeof window<"u"&&window.dispatchEvent(new CustomEvent(`siyuan-event-${s}`,{detail:r}))}catch{}}),this.eventBus.on("switch-protyle",this.onSwitchProtyleBound),this.eventBus.on("ws-main",this.onWsMainBound),this.eventBus.on("slidev:request-compile",()=>this.compileCurrentDocument()),this.eventBus.on("slidev:block-clicked",this.onBlockClickedBound),this.eventBus.on("click-editortitleicon",this.onClickEditorTitleIconBound),this.eventBus.on("click-editorcontent",this.onClickEditorContentBound),typeof document<"u"&&(document.addEventListener("click",this.onEditorClickBound,!0),document.addEventListener("selectionchange",this.onSelectionChangeBound)),typeof document<"u"){const s=()=>{const r=this.getActiveDocumentId();r&&(r!==this.currentDocId&&(this.currentDocId=r),this.latestCompiledDoc||this.compileCurrentDocument(r))};setTimeout(s,300),setTimeout(s,1e3)}}async onDataChanged(e){await this.loadGlobalSettings(),this.currentDocId&&await this.compileCurrentDocument(this.currentDocId)}async loadGlobalSettings(){try{const e=await this.loadData(wr),n=mp(e);return Vi(n),n}catch{return Vi(Yi),Yi}}async saveGlobalSettings(e){const n=Co(),s=Vi({...n,...e||{}});try{await this.saveData(wr,s)}catch(r){console.error("保存 Slidev 全局配置失败",r)}return s}onunload(){this.debounceTimer&&(window.clearTimeout(this.debounceTimer),this.debounceTimer=null),this.eventBus.off("switch-protyle",this.onSwitchProtyleBound),this.eventBus.off("ws-main",this.onWsMainBound),this.eventBus.off("click-editortitleicon",this.onClickEditorTitleIconBound),this.eventBus.off("click-editorcontent",this.onClickEditorContentBound),typeof document<"u"&&(document.removeEventListener("click",this.onEditorClickBound,!0),document.removeEventListener("selectionchange",this.onSelectionChangeBound)),In.detach()}async openBottomPreviewTab(){if(!this.currentDocId){const e=document.querySelector(".protyle-content[data-doc-id]");this.currentDocId=(e==null?void 0:e.getAttribute("data-doc-id"))||""}await vt.openTab({app:this.app,custom:{id:this.name+yr,title:"Slidev 演示预览",icon:"iconSlidev",data:{docId:this.currentDocId}},position:"bottom"}),this.currentDocId&&this.compileCurrentDocument(this.currentDocId)}onClickEditorTitleIcon(e){var l;const n=e.detail,s=n==null?void 0:n.menu,r=((l=n==null?void 0:n.data)==null?void 0:l.id)||this.currentDocId;!s||!r||s.addItem({icon:"iconSlidev",label:"Slidev 全局演示配置",submenu:[{label:"初始化演示属性 (custom-slidev-*)",click:async()=>{await zt(r,{"custom-slidev-theme":"default","custom-slidev-aspect-ratio":"16/9","custom-slidev-default-transition":"slide-left"}),vt.showMessage("已为当前文档初始化 Slidev 演示属性"),this.compileCurrentDocument(r)}},{type:"separator"},{label:"主题: 默认 (default)",click:async()=>{await zt(r,{"custom-slidev-theme":"default"}),vt.showMessage("已切换为 default 主题"),this.compileCurrentDocument(r)}},{label:"主题: 优雅衬线 (seriph)",click:async()=>{await zt(r,{"custom-slidev-theme":"seriph"}),vt.showMessage("已切换为 seriph 主题"),this.compileCurrentDocument(r)}},{label:"主题: 苹果极简 (apple-basic)",click:async()=>{await zt(r,{"custom-slidev-theme":"apple-basic"}),vt.showMessage("已切换为 apple-basic 主题"),this.compileCurrentDocument(r)}},{type:"separator"},{label:"画幅: 16 / 9 (宽屏)",click:async()=>{await zt(r,{"custom-slidev-aspect-ratio":"16/9"}),vt.showMessage("已切换画幅为 16/9"),this.compileCurrentDocument(r)}},{label:"画幅: 4 / 3 (标屏)",click:async()=>{await zt(r,{"custom-slidev-aspect-ratio":"4/3"}),vt.showMessage("已切换画幅为 4/3"),this.compileCurrentDocument(r)}}]})}async onSwitchProtyle(e){var r,l;const n=(r=e.detail)==null?void 0:r.protyle,s=(l=n==null?void 0:n.block)==null?void 0:l.rootID;if(s&&s!==this.currentDocId){this.currentDocId=s,this.activeCursorBlockId=s;const o=await Ge(s).catch(()=>({}));Nn({id:s,rootId:s,type:"doc",attrs:o}),this.compileCurrentDocument(s)}}onClickEditorContent(e){var r,l;const n=e==null?void 0:e.detail;if(!n)return;const s=(l=(r=n.protyle)==null?void 0:r.block)==null?void 0:l.rootID;s&&(!this.currentDocId||this.currentDocId!==s)&&(this.currentDocId=s),n.event&&this.onEditorClick(n.event)}getActiveDocumentId(){if(typeof document>"u")return"";const e=document.querySelector(".layout__wnd--active .protyle-title[data-node-id]")||document.querySelector(".item--focus .protyle-title[data-node-id]")||document.querySelector(".protyle-title[data-node-id]"),n=e==null?void 0:e.getAttribute("data-node-id");if(n)return n;const s=document.querySelector(".protyle .protyle-title[data-node-id]"),r=s==null?void 0:s.getAttribute("data-node-id");if(r)return r;const l=document.querySelector("[data-doc-id]"),o=l==null?void 0:l.getAttribute("data-doc-id");return o||""}resolveDocIdFromElement(e){const n=e.closest(".protyle-title"),s=n==null?void 0:n.getAttribute("data-node-id");if(s)return s;const r=e.closest(".protyle"),l=r==null?void 0:r.querySelector(".protyle-title"),o=l==null?void 0:l.getAttribute("data-node-id");if(o)return o;const a=e.closest("[data-doc-id]"),c=a==null?void 0:a.getAttribute("data-doc-id");if(c)return c;const d=this.getActiveDocumentId();return d||this.currentDocId}async switchToDocGlobalInspector(e,n){var l;if(!e)return;this.activeCursorBlockId=e,this.currentDocId=e;let s=n||"";if(!s&&typeof document<"u"){const o=document.querySelector(`.protyle-title[data-node-id="${e}"] .protyle-title__input`)||document.querySelector(`.protyle[data-doc-id="${e}"] .protyle-title__input`)||document.querySelector(".protyle-title__input");s=((l=o==null?void 0:o.innerText)==null?void 0:l.trim())||""}const r=await Ge(e).catch(()=>({}));Nn({id:e,rootId:e,type:"doc",content:s,attrs:r,isDivider:!1,isCode:!1}),Bs(e)}onWsMain(e){const n=e.detail;if(n){if(n.cmd==="transactions"&&Array.isArray(n.data)){for(const s of n.data)if(Array.isArray(s==null?void 0:s.doOperations)){for(const r of s.doOperations)if((r==null?void 0:r.action)==="updateAttrs"&&r.id&&r.data){const l=r.data.old||{},o=r.data.new||{},a={};for(const c of Object.keys(l))c in o||(a[c]="");for(const[c,d]of Object.entries(o))a[c]=String(d??"");se(r.id,a),Ht.setBlockAttrOverride(r.id,a)}}}this.debounceTimer&&window.clearTimeout(this.debounceTimer),this.debounceTimer=window.setTimeout(()=>{this.compileCurrentDocument()},150)}}handleBlockClickedFromSlide(e,n){var o,a;if(!e)return!1;this.activeCursorBlockId=e;const s=Ti(e,this.app),r=document.querySelector(`.protyle-wysiwyg [data-node-id="${e}"]`)||document.querySelector(`[data-node-id="${e}"]`),l=(r==null?void 0:r.getAttribute("data-type"))||"";if(r)this.syncInspectorBlock(r,e,l);else{let c="",d="";if((o=this.latestCompiledDoc)!=null&&o.slides){const h=this.latestCompiledDoc.slides.find(m=>{var p,y,f;return m.startBlockId===e||((p=m.blocks)==null?void 0:p.some(k=>k.id===e))||((y=m.allBlockIds)==null?void 0:y.includes(e))||((f=m.noteBlocks)==null?void 0:f.some(k=>k.id===e))});h!=null&&h.startBlockId&&(c=h.startBlockId),(a=h==null?void 0:h.frontmatter)!=null&&a.layout&&(d=h.frontmatter.layout)}Ge(e).then(async h=>{if(c&&!d){const m=Ht.getBlockAttrOverride(c);if(m!=null&&m[ft]||m!=null&&m["custom-slidev-layout"])d=m[ft]||m["custom-slidev-layout"]||"";else{const p=await Ge(c).catch(()=>({}))||{};d=p[ft]||p["custom-slidev-layout"]||"",p&&Object.keys(p).length>0&&Ht.setBlockAttrOverride(c,p)}}Nn({id:e,rootId:this.currentDocId,type:l||"NodeParagraph",attrs:h||{},pageDividerId:c,pageDividerLayout:d})}).catch(()=>{})}return s}onBlockClickedFromSlide(e){const n=(e==null?void 0:e.detail)||e;n!=null&&n.blockId&&this.handleBlockClickedFromSlide(n.blockId,n.page)}onEditorClick(e){const n=e.target;if(!n)return;const s=n.closest(".protyle-title")||n.closest(".protyle-background");if(!!(s||n.closest(".protyle-content")&&!n.closest(".protyle-wysiwyg")&&!n.closest(".protyle-breadcrumb")&&!n.closest(".protyle-gutters"))){const d=this.resolveDocIdFromElement(n);if(d&&this.activeCursorBlockId!==d){const h=s||document.querySelector(`.protyle-title[data-node-id="${d}"]`)||document.querySelector(`.protyle[data-doc-id="${d}"] .protyle-title`),m=h==null?void 0:h.querySelector(".protyle-title__input"),p=((m==null?void 0:m.innerText)||(h==null?void 0:h.innerText)||"").trim();this.switchToDocGlobalInspector(d,p)}return}if(!n.closest(".protyle-wysiwyg"))return;const o=n.closest("[data-node-id]");if(!o)return;const a=o.getAttribute("data-node-id"),c=o.getAttribute("data-type")||"";a&&(this.currentDocId||(this.currentDocId=this.resolveDocIdFromElement(n)||""),this.currentDocId&&!this.latestCompiledDoc&&this.compileCurrentDocument(this.currentDocId),a!==this.activeCursorBlockId&&(this.activeCursorBlockId=a,Bs(a)),this.syncInspectorBlock(o,a,c))}onSelectionChange(){if(typeof window>"u")return;const e=window.getSelection();if(!e||e.rangeCount===0)return;const n=e.anchorNode;if(!n)return;const s=n.nodeType===Node.ELEMENT_NODE?n:n.parentElement;if(!s)return;const r=s.closest(".protyle-title");if(!!(r||s.closest(".protyle-content")&&!s.closest(".protyle-wysiwyg"))){const d=this.resolveDocIdFromElement(s);if(d&&this.activeCursorBlockId!==d){const h=r||document.querySelector(`.protyle-title[data-node-id="${d}"]`)||document.querySelector(`.protyle[data-doc-id="${d}"] .protyle-title`),m=h==null?void 0:h.querySelector(".protyle-title__input"),p=((m==null?void 0:m.innerText)||(h==null?void 0:h.innerText)||"").trim();this.switchToDocGlobalInspector(d,p)}return}if(!s.closest(".protyle-wysiwyg"))return;const o=s.closest("[data-node-id]"),a=o==null?void 0:o.getAttribute("data-node-id"),c=(o==null?void 0:o.getAttribute("data-type"))||"";o&&a&&(this.currentDocId||(this.currentDocId=this.resolveDocIdFromElement(s)||""),this.currentDocId&&!this.latestCompiledDoc&&this.compileCurrentDocument(this.currentDocId),a!==this.activeCursorBlockId&&(this.activeCursorBlockId=a,Bs(a)),this.syncInspectorBlock(o,a,c))}async syncInspectorBlock(e,n,s){var S,G,b,U,it,j,st,K,Y,H;let r=e,l=n,o=s;const a=e.closest('[data-type="NodeCallout"]');if(a&&a!==e){const L=a.getAttribute("data-node-id");if(L){const ct=await Ge(L).catch(()=>({}))||{},rt=Ht.getBlockAttrOverride(L)||{},ot={...ct,...rt};(ot[ie]||ot["slidev-note"])&&(r=a,l=L,o="NodeCallout")}}const c=o==="NodeThematicBreak",d=o==="NodeCodeBlock",h=((S=r.innerText)==null?void 0:S.trim())||"",m=await Ge(l).catch(()=>({}))||{},p=Ht.getBlockAttrOverride(l)||{},y={...m,...p},f=r.closest(".protyle-wysiwyg > [data-node-id]")||r,k=(f==null?void 0:f.getAttribute("data-node-id"))||l;let v="",w="",x=f.previousElementSibling;for(;x;){const L=x.getAttribute("data-type");if(L==="NodeThematicBreak"||L==="tb"||(G=x.classList)!=null&&G.contains("hr")){v=x.getAttribute("data-node-id")||"";break}x=x.previousElementSibling}if((b=this.latestCompiledDoc)!=null&&b.slides){const L=[l,k];let ct=r.parentElement;for(;ct&&!ct.classList.contains("protyle-wysiwyg");){const ot=ct.getAttribute("data-node-id");ot&&!L.includes(ot)&&L.push(ot),ct=ct.parentElement}const rt=this.latestCompiledDoc.slides.find(ot=>{var J,mt,gt;return L.includes(ot.startBlockId)||((J=ot.blocks)==null?void 0:J.some(Z=>L.includes(Z.id)))||((mt=ot.allBlockIds)==null?void 0:mt.some(Z=>L.includes(Z)))||((gt=ot.noteBlocks)==null?void 0:gt.some(Z=>L.includes(Z.id)))});rt&&(!v&&rt.startBlockId&&(v=rt.startBlockId),!w&&((U=rt.frontmatter)!=null&&U.layout)&&(w=rt.frontmatter.layout))}if(v){const L=Ht.getBlockAttrOverride(v);if(L&&(ft in L||"custom-slidev-layout"in L)&&(w=L[ft]||L["custom-slidev-layout"]||""),!w&&((it=this.latestCompiledDoc)!=null&&it.slides)){const ct=this.latestCompiledDoc.slides.find(rt=>rt.startBlockId===v);(j=ct==null?void 0:ct.frontmatter)!=null&&j.layout&&(w=ct.frontmatter.layout)}if(!w){const ct=await Ge(v).catch(()=>({}))||{};w=ct[ft]||ct["custom-slidev-layout"]||"",ct&&Object.keys(ct).length>0&&Ht.setBlockAttrOverride(v,ct)}se(v,{[ft]:w||""})}else if(this.currentDocId){const L=Ht.getBlockAttrOverride(this.currentDocId);L&&(ft in L||"custom-slidev-layout"in L)?w=L[ft]||L["custom-slidev-layout"]||"":!w&&((H=(Y=(K=(st=this.latestCompiledDoc)==null?void 0:st.slides)==null?void 0:K[0])==null?void 0:Y.frontmatter)!=null&&H.layout)&&(w=this.latestCompiledDoc.slides[0].frontmatter.layout)}const E=r.getAttribute(ft)||r.getAttribute("custom-slidev-layout"),_=y[ft]||y["custom-slidev-layout"]||"";E&&E!==_&&se(l,{[ft]:_});const C=r.getAttribute(qt)||r.getAttribute("custom-slidev-role"),A=y[qt]||y["custom-slidev-role"]||"";C&&C!==A&&se(l,{[qt]:A});const B=r.closest('[data-type="NodeListItem"]');if(B&&B!==r){const L=B.getAttribute("data-node-id");if(L){const ct=await Ge(L).catch(()=>({}))||{},rt=Ht.getBlockAttrOverride(L)||{},ot={...ct,...rt},J=ot[ft]||ot["custom-slidev-layout"]||"",mt=B.getAttribute(ft)||B.getAttribute("custom-slidev-layout");mt&&mt!==J&&se(L,{[ft]:J});const gt=ot[qt]||ot["custom-slidev-role"]||"",Z=B.getAttribute(qt)||B.getAttribute("custom-slidev-role");Z&&Z!==gt&&se(L,{[qt]:gt})}}const P=!!r.querySelector("img, span[data-type='img']"),R=(r.innerText||"").replace(/[\r\n\t\s]+/g," ").trim(),X=P&&R.length<=50;Nn({id:l,rootId:this.currentDocId,type:o,content:h,attrs:y,isDivider:c,isCode:d,isImage:X,topBlockId:k,pageDividerId:v,pageDividerLayout:w})}async compileCurrentDocument(e){var s,r,l,o;let n=e||this.currentDocId;if(!n){const a=document.querySelector(".protyle.layout__wnd--active, .layout__wnd--active .protyle, .protyle"),c=(a==null?void 0:a.getAttribute("data-doc-id"))||((s=a==null?void 0:a.querySelector(".protyle-wysiwyg"))==null?void 0:s.getAttribute("data-doc-id"))||((r=a==null?void 0:a.querySelector(".protyle-title"))==null?void 0:r.getAttribute("data-node-id"))||((l=document.querySelector(".protyle-content[data-doc-id]"))==null?void 0:l.getAttribute("data-doc-id"))||((o=document.querySelector("[data-doc-id]"))==null?void 0:o.getAttribute("data-doc-id"));if(c)this.currentDocId=c,n=c;else return}try{const a=await Ht.compile(n);this.latestCompiledDoc=a,Gv(a,n),this.purgeStaleDomSlidevAttrs(a)}catch(a){console.error("[SiYuanSlidev] Failed to compile document:",a)}}purgeStaleDomSlidevAttrs(e){var r,l,o;if(typeof document>"u"||!e)return;const n=new Map;if(Array.isArray(e.slides))for(const a of e.slides){if(a.startBlockId){const c=n.get(a.startBlockId)||{};(r=a.frontmatter)!=null&&r.layout&&(c[ft]=a.frontmatter.layout),n.set(a.startBlockId,c)}if(Array.isArray(a.blocks)){for(const c of a.blocks)if(c.id){const d=n.get(c.id)||{};(l=c.ial)!=null&&l[ft]&&(d[ft]=c.ial[ft]),(o=c.ial)!=null&&o[qt]&&(d[qt]=c.ial[qt]),Object.keys(d).length>0&&n.set(c.id,d)}}}const s=Ht.getAllAttrOverrides();for(const[a,c]of s.entries()){const d=n.get(a)||{};c[ft]!==void 0&&(d[ft]=c[ft]),c[qt]!==void 0&&(d[qt]=c[qt]),n.set(a,d)}Sf(n)}}module.exports=Qv;
