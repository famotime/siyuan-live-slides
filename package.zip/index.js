"use strict";var tc=Object.create;var Po=Object.defineProperty;var ec=Object.getOwnPropertyDescriptor;var ic=Object.getOwnPropertyNames;var nc=Object.getPrototypeOf,oc=Object.prototype.hasOwnProperty;var sc=(t,e,i)=>e in t?Po(t,e,{enumerable:!0,configurable:!0,writable:!0,value:i}):t[e]=i;var rc=(t,e,i,n)=>{if(e&&typeof e=="object"||typeof e=="function")for(let o of ic(e))!oc.call(t,o)&&o!==i&&Po(t,o,{get:()=>e[o],enumerable:!(n=ec(e,o))||n.enumerable});return t};var jn=(t,e,i)=>(i=t!=null?tc(nc(t)):{},rc(e||!t||!t.__esModule?Po(i,"default",{value:t,enumerable:!0}):i,t));var xt=(t,e,i)=>sc(t,typeof e!="symbol"?e+"":e,i);const ft=require("siyuan");async function ke(t,e){const i=await ft.fetchSyncPost(t,e);return i.code===0?i.data:null}async function lc(){return ke("/api/notebook/lsNotebooks","")}async function ac(t,e,i){return ke("/api/filetree/createDocWithMd",{notebook:t,path:e,markdown:i})}async function Nr(t,e){const i=new FormData;i.append("assetsDirPath",t);for(const o of e)i.append("file[]",o);return ke("/api/asset/upload",i)}async function Ii(t,e,i,n,o){return ke("/api/block/insertBlock",{dataType:t,data:e,nextID:i,previousID:n,parentID:o})}async function Xo(t,e,i){return ke("/api/block/appendBlock",{dataType:t,data:e,parentID:i})}async function Ks(t,e,i){return ke("/api/block/updateBlock",{dataType:t,data:e,id:i})}async function Gs(t){return ke("/api/block/deleteBlock",{id:t})}async function cc(t){return ke("/api/block/getBlockKramdown",{id:t})}async function no(t){return ke("/api/block/getChildBlocks",{id:t})}async function Et(t,e){return ke("/api/attr/setBlockAttrs",{id:t,attrs:e})}async function Ye(t){return ke("/api/attr/getBlockAttrs",{id:t})}async function wn(t){return ke("/api/query/sql",{stmt:t})}async function Qo(t,e,i){const n=new FormData;return n.append("path",t),n.append("isDir",e.toString()),n.append("modTime",Math.floor(Date.now()/1e3).toString()),n.append("file",i),ke("/api/file/putFile",n)}async function Fr(t){const e="/api/ai/chatGPT";try{const i=await ke(e,{msg:t});return typeof i=="string"&&i.trim().length>0?i.trim():i&&typeof i.content=="string"&&i.content.trim().length>0?i.content.trim():null}catch{return null}}async function dc(){return ke("/api/storage/getInlineStyles","")}const Hr=/\(\(([0-9a-zA-Z-]+)(?:\s*(?:'([^']*)'|"([^"]*)"|([^\)]+?)))?\s*\)\)/g;function uc(t){const e=[];if(!t)return e;const i=new RegExp(Hr.source,"g");let n;for(;(n=i.exec(t))!==null;){const o=n[2]??n[3]??n[4];e.push({fullMatch:n[0],blockId:n[1],anchorText:o?o.trim():void 0})}return e}function fc(t,e){if(!t)return"";const i=new RegExp(Hr.source,"g");return t.replace(i,(n,o,s,l,r)=>{const a=(s??l??r??"").trim();if(e&&e[o]){const u=e[o].trim();return`<div class="slidev-block-ref" data-ref-id="${o}">${u}</div>`}const c=a||`Ref(${o.slice(0,8)})`;return`<a href="siyuan://blocks/${o}" data-ref-id="${o}" class="slidev-ref-tag">🔗 ${c}</a>`})}const xn="custom-slidev-theme",Sn="custom-slidev-aspect-ratio",jr="custom-slidev-highlighter",_n="custom-slidev-default-transition",Ur="custom-slidev-color-schema",ts="custom-slidev-spacing",Bi="custom-slidev-slide",ht="custom-slidev-layout",te="custom-slidev-transition",Ut="custom-slidev-background",Ee="custom-slidev-image",Wi="custom-slidev-notes",Vi="custom-slidev-class",fn="custom-slidev-spacing",le="custom-slidev-layout-ratio",jt="custom-slidev-click",Ve="custom-slidev-motion",Oi="custom-slidev-shiki-lines",Ct="custom-slidev-slot",ne="custom-slidev-note",qt="custom-slidev-role",Cn="custom-slidev-max-height",Ti="custom-slidev-autoplay",oo="custom-slidev-loop",Ui="custom-slidev-muted",so="custom-slidev-controls",Wr="background",ro="image-left",lo="image-right";function $n(t){return t==="cols-header"||t==="two-cols-header"||t==="three-cols-header"}function pc(t){return t.markdown&&t.markdown.trim()?t.markdown.trim():t.content&&t.content.trim()?t.content.trim():""}function hc(t){const e={};if(!t)return e;const i=t.replace(/^\{:\s*/,"").replace(/\s*\}$/,""),n=/([\w-]+)=(?:"([^"]*)"|'([^']*)'|(\S+))/g;let o;for(;(o=n.exec(i))!==null;){const s=o[1],l=o[2]??o[3]??o[4]??"";e[s]=l}return e}function Vr(t){if(!t)return!1;const e=t.trim();return e.startsWith("assets/")||e.startsWith("./assets/")||e.startsWith("/assets/")}function qr(t){const e=t.trim();return e.startsWith("./assets/")?e.slice(2):e.startsWith("/assets/")?e.slice(1):e}function Ie(t,e){if(!Vr(t))return t;const i=qr(t);return e!=null&&e.base64Map&&e.base64Map[i]?e.base64Map[i]:e!=null&&e.baseUrl?`${e.baseUrl.replace(/\/+$/,"")}/${i}`:`/${i}`}function mc(t,e){if(!t)return"";let i=t;return i=i.replace(/!\[(.*?)\]\(((?:\.\/|\/)?assets\/[^\s)]+)\)/g,(n,o,s)=>{const l=Ie(s,e);return`![${o}](${l})`}),i=i.replace(/(<(?:img|video|audio|source)\b[^>]*?\bsrc=["'])((?:\.\/|\/)?assets\/[^"']+)(["'][^>]*>)/gi,(n,o,s,l)=>{const r=Ie(s,e);return`${o}${r}${l}`}),i=i.replace(/(url\(\s*["']?)((?:\.\/|\/)?assets\/[^"')]+)(["']?\s*\))/gi,(n,o,s,l)=>{const r=Ie(s,e);return`${o}${r}${l}`}),i}/**
* @vue/shared v3.5.40
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/function gs(t){const e=Object.create(null);for(const i of t.split(","))e[i]=1;return i=>i in e}const Wt={},qi=[],qe=()=>{},Kr=()=>!1,yo=t=>t.charCodeAt(0)===111&&t.charCodeAt(1)===110&&(t.charCodeAt(2)>122||t.charCodeAt(2)<97),ko=t=>t.startsWith("onUpdate:"),ue=Object.assign,vs=(t,e)=>{const i=t.indexOf(e);i>-1&&t.splice(i,1)},gc=Object.prototype.hasOwnProperty,zt=(t,e)=>gc.call(t,e),$t=Array.isArray,Ki=t=>Pn(t)==="[object Map]",en=t=>Pn(t)==="[object Set]",Zs=t=>Pn(t)==="[object Date]",Bt=t=>typeof t=="function",ee=t=>typeof t=="string",Pe=t=>typeof t=="symbol",Ht=t=>t!==null&&typeof t=="object",Gr=t=>(Ht(t)||Bt(t))&&Bt(t.then)&&Bt(t.catch),Zr=Object.prototype.toString,Pn=t=>Zr.call(t),vc=t=>Pn(t).slice(8,-1),Yr=t=>Pn(t)==="[object Object]",bs=t=>ee(t)&&t!=="NaN"&&t[0]!=="-"&&""+parseInt(t,10)===t,pn=gs(",key,ref,ref_for,ref_key,onVnodeBeforeMount,onVnodeMounted,onVnodeBeforeUpdate,onVnodeUpdated,onVnodeBeforeUnmount,onVnodeUnmounted"),wo=t=>{const e=Object.create(null);return(i=>e[i]||(e[i]=t(i)))},bc=/-\w/g,ye=wo(t=>t.replace(bc,e=>e.slice(1).toUpperCase())),yc=/\B([A-Z])/g,yi=wo(t=>t.replace(yc,"-$1").toLowerCase()),xo=wo(t=>t.charAt(0).toUpperCase()+t.slice(1)),Oo=wo(t=>t?`on${xo(t)}`:""),Ue=(t,e)=>!Object.is(t,e),Jn=(t,...e)=>{for(let i=0;i<t.length;i++)t[i](...e)},Jr=(t,e,i,n=!1)=>{Object.defineProperty(t,e,{configurable:!0,enumerable:!1,writable:n,value:i})},So=t=>{const e=parseFloat(t);return isNaN(e)?t:e};let Ys;const _o=()=>Ys||(Ys=typeof globalThis<"u"?globalThis:typeof self<"u"?self:typeof window<"u"?window:typeof global<"u"?global:{});function In(t){if($t(t)){const e={};for(let i=0;i<t.length;i++){const n=t[i],o=ee(n)?Sc(n):In(n);if(o)for(const s in o)e[s]=o[s]}return e}else if(ee(t)||Ht(t))return t}const kc=/;(?![^(]*\))/g,wc=/:([^]+)/,xc=/\/\*[^]*?\*\//g;function Sc(t){const e={};return t.replace(xc,"").split(kc).forEach(i=>{if(i){const n=i.split(wc);n.length>1&&(e[n[0].trim()]=n[1].trim())}}),e}function At(t){let e="";if(ee(t))e=t;else if($t(t))for(let i=0;i<t.length;i++){const n=At(t[i]);n&&(e+=n+" ")}else if(Ht(t))for(const i in t)t[i]&&(e+=i+" ");return e.trim()}const _c="itemscope,allowfullscreen,formnovalidate,ismap,nomodule,novalidate,readonly",Cc=gs(_c);function Xr(t){return!!t||t===""}function $c(t,e){if(t.length!==e.length)return!1;let i=!0;for(let n=0;i&&n<t.length;n++)i=nn(t[n],e[n]);return i}function nn(t,e){if(t===e)return!0;let i=Zs(t),n=Zs(e);if(i||n)return i&&n?t.getTime()===e.getTime():!1;if(i=Pe(t),n=Pe(e),i||n)return t===e;if(i=$t(t),n=$t(e),i||n)return i&&n?$c(t,e):!1;if(i=Ht(t),n=Ht(e),i||n){if(!i||!n)return!1;const o=Object.keys(t).length,s=Object.keys(e).length;if(o!==s)return!1;for(const l in t){const r=t.hasOwnProperty(l),a=e.hasOwnProperty(l);if(r&&!a||!r&&a||!nn(t[l],e[l]))return!1}}return String(t)===String(e)}function ys(t,e){return t.findIndex(i=>nn(i,e))}const Qr=t=>!!(t&&t.__v_isRef===!0),_t=t=>ee(t)?t:t==null?"":$t(t)||Ht(t)&&(t.toString===Zr||!Bt(t.toString))?Qr(t)?_t(t.value):JSON.stringify(t,tl,2):String(t),tl=(t,e)=>Qr(e)?tl(t,e.value):Ki(e)?{[`Map(${e.size})`]:[...e.entries()].reduce((i,[n,o],s)=>(i[Ro(n,s)+" =>"]=o,i),{})}:en(e)?{[`Set(${e.size})`]:[...e.values()].map(i=>Ro(i))}:Pe(e)?Ro(e):Ht(e)&&!$t(e)&&!Yr(e)?String(e):e,Ro=(t,e="")=>{var i;return Pe(t)?`Symbol(${(i=t.description)!=null?i:e})`:t};/**
* @vue/reactivity v3.5.40
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/let ae;class Ic{constructor(e=!1){this.detached=e,this._active=!0,this._on=0,this.effects=[],this.cleanups=[],this._isPaused=!1,this._warnOnRun=!0,this.__v_skip=!0,!e&&ae&&(ae.active?(this.parent=ae,this.index=(ae.scopes||(ae.scopes=[])).push(this)-1):(this._active=!1,this._warnOnRun=!1))}get active(){return this._active}pause(){if(this._active){this._isPaused=!0;let e,i;if(this.scopes){const n=this.scopes.slice();for(e=0,i=n.length;e<i;e++)n[e].pause()}for(e=0,i=this.effects.length;e<i;e++)this.effects[e].pause()}}resume(){if(this._active&&this._isPaused){this._isPaused=!1;let e,i;if(this.scopes){const o=this.scopes.slice();for(e=0,i=o.length;e<i;e++)o[e].resume()}const n=this.effects.slice();for(e=0,i=n.length;e<i;e++)n[e].resume()}}run(e){if(this._active){const i=ae;try{return ae=this,e()}finally{ae=i}}}on(){++this._on===1&&(this.prevScope=ae,ae=this)}off(){if(this._on>0&&--this._on===0){if(ae===this)ae=this.prevScope;else{let e=ae;for(;e;){if(e.prevScope===this){e.prevScope=this.prevScope;break}e=e.prevScope}}this.prevScope=void 0}}stop(e){if(this._active){this._active=!1;let i,n;for(i=0,n=this.effects.length;i<n;i++)this.effects[i].stop();for(this.effects.length=0,i=0,n=this.cleanups.length;i<n;i++)this.cleanups[i]();if(this.cleanups.length=0,this.scopes){const o=this.scopes.slice();for(i=0,n=o.length;i<n;i++)o[i].stop(!0);this.scopes.length=0}if(!this.detached&&this.parent&&!e){const o=this.parent.scopes.pop();o&&o!==this&&(this.parent.scopes[this.index]=o,o.index=this.index)}this.parent=void 0}}}function Ac(){return ae}let Vt;const zo=new WeakSet;class el{constructor(e){this.fn=e,this.deps=void 0,this.depsTail=void 0,this.flags=5,this.next=void 0,this.cleanup=void 0,this.scheduler=void 0,ae&&(ae.active?ae.effects.push(this):this.flags&=-2)}pause(){this.flags|=64}resume(){this.flags&64&&(this.flags&=-65,zo.has(this)&&(zo.delete(this),this.trigger()))}notify(){this.flags&2&&!(this.flags&32)||this.flags&8||nl(this)}run(){if(!(this.flags&1))return this.fn();this.flags|=2,Js(this),ol(this);const e=Vt,i=De;Vt=this,De=!0;try{return this.fn()}finally{sl(this),Vt=e,De=i,this.flags&=-3}}stop(){if(this.flags&1){for(let e=this.deps;e;e=e.nextDep)xs(e);this.deps=this.depsTail=void 0,Js(this),this.onStop&&this.onStop(),this.flags&=-2}}trigger(){this.flags&64?zo.add(this):this.scheduler?this.scheduler():this.runIfDirty()}runIfDirty(){es(this)&&this.run()}get dirty(){return es(this)}}let il=0,hn,mn;function nl(t,e=!1){if(t.flags|=8,e){t.next=mn,mn=t;return}t.next=hn,hn=t}function ks(){il++}function ws(){if(--il>0)return;if(mn){let e=mn;for(mn=void 0;e;){const i=e.next;e.next=void 0,e.flags&=-9,e=i}}let t;for(;hn;){let e=hn;for(hn=void 0;e;){const i=e.next;if(e.next=void 0,e.flags&=-9,e.flags&1)try{e.trigger()}catch(n){t||(t=n)}e=i}}if(t)throw t}function ol(t){for(let e=t.deps;e;e=e.nextDep)e.version=-1,e.prevActiveLink=e.dep.activeLink,e.dep.activeLink=e}function sl(t){let e,i=t.depsTail,n=i;for(;n;){const o=n.prevDep;n.version===-1?(n===i&&(i=o),xs(n),Bc(n)):e=n,n.dep.activeLink=n.prevActiveLink,n.prevActiveLink=void 0,n=o}t.deps=e,t.depsTail=i}function es(t){for(let e=t.deps;e;e=e.nextDep)if(e.dep.version!==e.version||e.dep.computed&&(rl(e.dep.computed)||e.dep.version!==e.version))return!0;return!!t._dirty}function rl(t){if(t.flags&4&&!(t.flags&16)||(t.flags&=-17,t.globalVersion===An)||(t.globalVersion=An,!t.isSSR&&t.flags&128&&(!t.deps&&!t._dirty||!es(t))))return;t.flags|=2;const e=t.dep,i=Vt,n=De;Vt=t,De=!0;try{ol(t);const o=t.fn(t._value);(e.version===0||Ue(o,t._value))&&(t.flags|=128,t._value=o,e.version++)}catch(o){throw e.version++,o}finally{Vt=i,De=n,sl(t),t.flags&=-3}}function xs(t,e=!1){const{dep:i,prevSub:n,nextSub:o}=t;if(n&&(n.nextSub=o,t.prevSub=void 0),o&&(o.prevSub=n,t.nextSub=void 0),i.subs===t&&(i.subs=n,!n&&i.computed)){i.computed.flags&=-5;for(let s=i.computed.deps;s;s=s.nextDep)xs(s,!0)}!e&&!--i.sc&&i.map&&i.map.delete(i.key)}function Bc(t){const{prevDep:e,nextDep:i}=t;e&&(e.nextDep=i,t.prevDep=void 0),i&&(i.prevDep=e,t.nextDep=void 0)}let De=!0;const ll=[];function oi(){ll.push(De),De=!1}function si(){const t=ll.pop();De=t===void 0?!0:t}function Js(t){const{cleanup:e}=t;if(t.cleanup=void 0,e){const i=Vt;Vt=void 0;try{e()}finally{Vt=i}}}let An=0;class Tc{constructor(e,i){this.sub=e,this.dep=i,this.version=i.version,this.nextDep=this.prevDep=this.nextSub=this.prevSub=this.prevActiveLink=void 0}}class Ss{constructor(e){this.computed=e,this.version=0,this.activeLink=void 0,this.subs=void 0,this.map=void 0,this.key=void 0,this.sc=0,this.__v_skip=!0}track(e){if(!Vt||!De||Vt===this.computed)return;let i=this.activeLink;if(i===void 0||i.sub!==Vt)i=this.activeLink=new Tc(Vt,this),Vt.deps?(i.prevDep=Vt.depsTail,Vt.depsTail.nextDep=i,Vt.depsTail=i):Vt.deps=Vt.depsTail=i,al(i);else if(i.version===-1&&(i.version=this.version,i.nextDep)){const n=i.nextDep;n.prevDep=i.prevDep,i.prevDep&&(i.prevDep.nextDep=n),i.prevDep=Vt.depsTail,i.nextDep=void 0,Vt.depsTail.nextDep=i,Vt.depsTail=i,Vt.deps===i&&(Vt.deps=n)}return i}trigger(e){this.version++,An++,this.notify(e)}notify(e){ks();try{for(let i=this.subs;i;i=i.prevSub)i.sub.notify()&&i.sub.dep.notify()}finally{ws()}}}function al(t){if(t.dep.sc++,t.sub.flags&4){const e=t.dep.computed;if(e&&!t.dep.subs){e.flags|=20;for(let n=e.deps;n;n=n.nextDep)al(n)}const i=t.dep.subs;i!==t&&(t.prevSub=i,i&&(i.nextSub=t)),t.dep.subs=t}}const is=new WeakMap,Mi=Symbol(""),ns=Symbol(""),Bn=Symbol("");function he(t,e,i){if(De&&Vt){let n=is.get(t);n||is.set(t,n=new Map);let o=n.get(i);o||(n.set(i,o=new Ss),o.map=n,o.key=i),o.track()}}function Qe(t,e,i,n,o,s){const l=is.get(t);if(!l){An++;return}const r=a=>{a&&a.trigger()};if(ks(),e==="clear")l.forEach(r);else{const a=$t(t),c=a&&bs(i);if(a&&i==="length"){const u=Number(n);l.forEach((m,g)=>{(g==="length"||g===Bn||!Pe(g)&&g>=u)&&r(m)})}else switch((i!==void 0||l.has(void 0))&&r(l.get(i)),c&&r(l.get(Bn)),e){case"add":a?c&&r(l.get("length")):(r(l.get(Mi)),Ki(t)&&r(l.get(ns)));break;case"delete":a||(r(l.get(Mi)),Ki(t)&&r(l.get(ns)));break;case"set":Ki(t)&&r(l.get(Mi));break}}ws()}function Hi(t){const e=Rt(t);return e===t?e:(he(e,"iterate",Bn),Be(t)?e:e.map(Oe))}function Co(t){return he(t=Rt(t),"iterate",Bn),t}function He(t,e){return ri(t)?Ji(Li(t)?Oe(e):e):Oe(e)}const Ec={__proto__:null,[Symbol.iterator](){return No(this,Symbol.iterator,t=>He(this,t))},concat(...t){return Hi(this).concat(...t.map(e=>$t(e)?Hi(e):e))},entries(){return No(this,"entries",t=>(t[1]=He(this,t[1]),t))},every(t,e){return Ze(this,"every",t,e,void 0,arguments)},filter(t,e){return Ze(this,"filter",t,e,i=>i.map(n=>He(this,n)),arguments)},find(t,e){return Ze(this,"find",t,e,i=>He(this,i),arguments)},findIndex(t,e){return Ze(this,"findIndex",t,e,void 0,arguments)},findLast(t,e){return Ze(this,"findLast",t,e,i=>He(this,i),arguments)},findLastIndex(t,e){return Ze(this,"findLastIndex",t,e,void 0,arguments)},forEach(t,e){return Ze(this,"forEach",t,e,void 0,arguments)},includes(...t){return Fo(this,"includes",t)},indexOf(...t){return Fo(this,"indexOf",t)},join(t){return Hi(this).join(t)},lastIndexOf(...t){return Fo(this,"lastIndexOf",t)},map(t,e){return Ze(this,"map",t,e,void 0,arguments)},pop(){return ln(this,"pop")},push(...t){return ln(this,"push",t)},reduce(t,...e){return Xs(this,"reduce",t,e)},reduceRight(t,...e){return Xs(this,"reduceRight",t,e)},shift(){return ln(this,"shift")},some(t,e){return Ze(this,"some",t,e,void 0,arguments)},splice(...t){return ln(this,"splice",t)},toReversed(){return Hi(this).toReversed()},toSorted(t){return Hi(this).toSorted(t)},toSpliced(...t){return Hi(this).toSpliced(...t)},unshift(...t){return ln(this,"unshift",t)},values(){return No(this,"values",t=>He(this,t))}};function No(t,e,i){const n=Co(t),o=n[e]();return n!==t&&!Be(t)&&(o._next=o.next,o.next=()=>{const s=o._next();return s.done||(s.value=i(s.value)),s}),o}const Mc=Array.prototype;function Ze(t,e,i,n,o,s){const l=Co(t),r=l!==t&&!Be(t),a=l[e];if(a!==Mc[e]){const m=a.apply(t,s);return r?Oe(m):m}let c=i;l!==t&&(r?c=function(m,g){return i.call(this,He(t,m),g,t)}:i.length>2&&(c=function(m,g){return i.call(this,m,g,t)}));const u=a.call(l,c,n);return r&&o?o(u):u}function Xs(t,e,i,n){const o=Co(t),s=o!==t&&!Be(t);let l=i,r=!1;o!==t&&(s?(r=n.length===0,l=function(c,u,m){return r&&(r=!1,c=He(t,c)),i.call(this,c,He(t,u),m,t)}):i.length>3&&(l=function(c,u,m){return i.call(this,c,u,m,t)}));const a=o[e](l,...n);return r?He(t,a):a}function Fo(t,e,i){const n=Rt(t);he(n,"iterate",Bn);const o=n[e](...i);return(o===-1||o===!1)&&$s(i[0])?(i[0]=Rt(i[0]),n[e](...i)):o}function ln(t,e,i=[]){oi(),ks();const n=Rt(t)[e].apply(t,i);return ws(),si(),n}const Lc=gs("__proto__,__v_isRef,__isVue"),cl=new Set(Object.getOwnPropertyNames(Symbol).filter(t=>t!=="arguments"&&t!=="caller").map(t=>Symbol[t]).filter(Pe));function Dc(t){Pe(t)||(t=String(t));const e=Rt(this);return he(e,"has",t),e.hasOwnProperty(t)}class dl{constructor(e=!1,i=!1){this._isReadonly=e,this._isShallow=i}get(e,i,n){if(i==="__v_skip")return e.__v_skip;const o=this._isReadonly,s=this._isShallow;if(i==="__v_isReactive")return!o;if(i==="__v_isReadonly")return o;if(i==="__v_isShallow")return s;if(i==="__v_raw")return n===(o?s?Wc:hl:s?pl:fl).get(e)||Object.getPrototypeOf(e)===Object.getPrototypeOf(n)?e:void 0;const l=$t(e);if(!o){let a;if(l&&(a=Ec[i]))return a;if(i==="hasOwnProperty")return Dc}const r=Reflect.get(e,i,Jt(e)?e:n);if((Pe(i)?cl.has(i):Lc(i))||(o||he(e,"get",i),s))return r;if(Jt(r)){const a=l&&bs(i)?r:r.value;return o&&Ht(a)?ss(a):a}return Ht(r)?o?ss(r):$o(r):r}}class ul extends dl{constructor(e=!1){super(!1,e)}set(e,i,n,o){let s=e[i];const l=$t(e)&&bs(i);if(!this._isShallow){const c=ri(s);if(!Be(n)&&!ri(n)&&(s=Rt(s),n=Rt(n)),!l&&Jt(s)&&!Jt(n))return c||(s.value=n),!0}const r=l?Number(i)<e.length:zt(e,i),a=Reflect.set(e,i,n,Jt(e)?e:o);return e===Rt(o)&&a&&(r?Ue(n,s)&&Qe(e,"set",i,n):Qe(e,"add",i,n)),a}deleteProperty(e,i){const n=zt(e,i);e[i];const o=Reflect.deleteProperty(e,i);return o&&n&&Qe(e,"delete",i,void 0),o}has(e,i){const n=Reflect.has(e,i);return(!Pe(i)||!cl.has(i))&&he(e,"has",i),n}ownKeys(e){return he(e,"iterate",$t(e)?"length":Mi),Reflect.ownKeys(e)}}class Pc extends dl{constructor(e=!1){super(!0,e)}set(e,i){return!0}deleteProperty(e,i){return!0}}const Oc=new ul,Rc=new Pc,zc=new ul(!0);const os=t=>t,Un=t=>Reflect.getPrototypeOf(t);function Nc(t,e,i){return function(...n){const o=this.__v_raw,s=Rt(o),l=Ki(s),r=t==="entries"||t===Symbol.iterator&&l,a=t==="keys"&&l,c=o[t](...n),u=i?os:e?Ji:Oe;return!e&&he(s,"iterate",a?ns:Mi),ue(Object.create(c),{next(){const{value:m,done:g}=c.next();return g?{value:m,done:g}:{value:r?[u(m[0]),u(m[1])]:u(m),done:g}}})}}function Wn(t){return function(...e){return t==="delete"?!1:t==="clear"?void 0:this}}function Fc(t,e){const i={get(o){const s=this.__v_raw,l=Rt(s),r=Rt(o);t||(Ue(o,r)&&he(l,"get",o),he(l,"get",r));const{has:a}=Un(l),c=e?os:t?Ji:Oe;if(a.call(l,o))return c(s.get(o));if(a.call(l,r))return c(s.get(r));s!==l&&s.get(o)},get size(){const o=this.__v_raw;return!t&&he(Rt(o),"iterate",Mi),o.size},has(o){const s=this.__v_raw,l=Rt(s),r=Rt(o);return t||(Ue(o,r)&&he(l,"has",o),he(l,"has",r)),o===r?s.has(o):s.has(o)||s.has(r)},forEach(o,s){const l=this,r=l.__v_raw,a=Rt(r),c=e?os:t?Ji:Oe;return!t&&he(a,"iterate",Mi),r.forEach((u,m)=>o.call(s,c(u),c(m),l))}};return ue(i,t?{add:Wn("add"),set:Wn("set"),delete:Wn("delete"),clear:Wn("clear")}:{add(o){const s=Rt(this),l=Un(s),r=Rt(o),a=!e&&!Be(o)&&!ri(o)?r:o;return l.has.call(s,a)||Ue(o,a)&&l.has.call(s,o)||Ue(r,a)&&l.has.call(s,r)||(s.add(a),Qe(s,"add",a,a)),this},set(o,s){!e&&!Be(s)&&!ri(s)&&(s=Rt(s));const l=Rt(this),{has:r,get:a}=Un(l);let c=r.call(l,o);c||(o=Rt(o),c=r.call(l,o));const u=a.call(l,o);return l.set(o,s),c?Ue(s,u)&&Qe(l,"set",o,s):Qe(l,"add",o,s),this},delete(o){const s=Rt(this),{has:l,get:r}=Un(s);let a=l.call(s,o);a||(o=Rt(o),a=l.call(s,o)),r&&r.call(s,o);const c=s.delete(o);return a&&Qe(s,"delete",o,void 0),c},clear(){const o=Rt(this),s=o.size!==0,l=o.clear();return s&&Qe(o,"clear",void 0,void 0),l}}),["keys","values","entries",Symbol.iterator].forEach(o=>{i[o]=Nc(o,t,e)}),i}function _s(t,e){const i=Fc(t,e);return(n,o,s)=>o==="__v_isReactive"?!t:o==="__v_isReadonly"?t:o==="__v_raw"?n:Reflect.get(zt(i,o)&&o in n?i:n,o,s)}const Hc={get:_s(!1,!1)},jc={get:_s(!1,!0)},Uc={get:_s(!0,!1)};const fl=new WeakMap,pl=new WeakMap,hl=new WeakMap,Wc=new WeakMap;function Vc(t){switch(t){case"Object":case"Array":return 1;case"Map":case"Set":case"WeakMap":case"WeakSet":return 2;default:return 0}}function $o(t){return ri(t)?t:Cs(t,!1,Oc,Hc,fl)}function qc(t){return Cs(t,!1,zc,jc,pl)}function ss(t){return Cs(t,!0,Rc,Uc,hl)}function Cs(t,e,i,n,o){if(!Ht(t)||t.__v_raw&&!(e&&t.__v_isReactive)||t.__v_skip||!Object.isExtensible(t))return t;const s=o.get(t);if(s)return s;const l=Vc(vc(t));if(l===0)return t;const r=new Proxy(t,l===2?n:i);return o.set(t,r),r}function Li(t){return ri(t)?Li(t.__v_raw):!!(t&&t.__v_isReactive)}function ri(t){return!!(t&&t.__v_isReadonly)}function Be(t){return!!(t&&t.__v_isShallow)}function $s(t){return t?!!t.__v_raw:!1}function Rt(t){const e=t&&t.__v_raw;return e?Rt(e):t}function Kc(t){return!zt(t,"__v_skip")&&Object.isExtensible(t)&&Jr(t,"__v_skip",!0),t}const Oe=t=>Ht(t)?$o(t):t,Ji=t=>Ht(t)?ss(t):t;function Jt(t){return t?t.__v_isRef===!0:!1}function vt(t){return Gc(t,!1)}function Gc(t,e){return Jt(t)?t:new Zc(t,e)}class Zc{constructor(e,i){this.dep=new Ss,this.__v_isRef=!0,this.__v_isShallow=!1,this._rawValue=i?e:Rt(e),this._value=i?e:Oe(e),this.__v_isShallow=i}get value(){return this.dep.track(),this._value}set value(e){const i=this._rawValue,n=this.__v_isShallow||Be(e)||ri(e);e=n?e:Rt(e),Ue(e,i)&&(this._rawValue=e,this._value=n?e:Oe(e),this.dep.trigger())}}function bt(t){return Jt(t)?t.value:t}const Yc={get:(t,e,i)=>e==="__v_raw"?t:bt(Reflect.get(t,e,i)),set:(t,e,i,n)=>{const o=t[e];return Jt(o)&&!Jt(i)?(o.value=i,!0):Reflect.set(t,e,i,n)}};function ml(t){return Li(t)?t:new Proxy(t,Yc)}class Jc{constructor(e,i,n){this.fn=e,this.setter=i,this._value=void 0,this.dep=new Ss(this),this.__v_isRef=!0,this.deps=void 0,this.depsTail=void 0,this.flags=16,this.globalVersion=An-1,this.next=void 0,this.effect=this,this.__v_isReadonly=!i,this.isSSR=n}notify(){if(this.flags|=16,!(this.flags&8)&&Vt!==this)return nl(this,!0),!0}get value(){const e=this.dep.track();return rl(this),e&&(e.version=this.dep.version),this._value}set value(e){this.setter&&this.setter(e)}}function Xc(t,e,i=!1){let n,o;return Bt(t)?n=t:(n=t.get,o=t.set),new Jc(n,o,i)}const Vn={},ao=new WeakMap;let Ai;function Qc(t,e=!1,i=Ai){if(i){let n=ao.get(i);n||ao.set(i,n=[]),n.push(t)}}function td(t,e,i=Wt){const{immediate:n,deep:o,once:s,scheduler:l,augmentJob:r,call:a}=i,c=B=>o?B:Be(B)||o===!1||o===0?ti(B,1):ti(B);let u,m,g,d,b=!1,f=!1;if(Jt(t)?(m=()=>t.value,b=Be(t)):Li(t)?(m=()=>c(t),b=!0):$t(t)?(f=!0,b=t.some(B=>Li(B)||Be(B)),m=()=>t.map(B=>{if(Jt(B))return B.value;if(Li(B))return c(B);if(Bt(B))return a?a(B,2):B()})):Bt(t)?e?m=a?()=>a(t,2):t:m=()=>{if(g){oi();try{g()}finally{si()}}const B=Ai;Ai=u;try{return a?a(t,3,[d]):t(d)}finally{Ai=B}}:m=qe,e&&o){const B=m,E=o===!0?1/0:o;m=()=>ti(B(),E)}const v=Ac(),k=()=>{u.stop(),v&&v.active&&vs(v.effects,u)};if(s&&e){const B=e;e=(...E)=>{const A=B(...E);return k(),A}}let S=f?new Array(t.length).fill(Vn):Vn;const x=B=>{if(!(!(u.flags&1)||!u.dirty&&!B))if(e){const E=u.run();if(B||o||b||(f?E.some((A,w)=>Ue(A,S[w])):Ue(E,S))){g&&g();const A=Ai;Ai=u;try{const w=[E,S===Vn?void 0:f&&S[0]===Vn?[]:S,d];S=E,a?a(e,3,w):e(...w)}finally{Ai=A}}}else u.run()};return r&&r(x),u=new el(m),u.scheduler=l?()=>l(x,!1):x,d=B=>Qc(B,!1,u),g=u.onStop=()=>{const B=ao.get(u);if(B){if(a)a(B,4);else for(const E of B)E();ao.delete(u)}},e?n?x(!0):S=u.run():l?l(x.bind(null,!0),!0):u.run(),k.pause=u.pause.bind(u),k.resume=u.resume.bind(u),k.stop=k,k}function ti(t,e=1/0,i){if(e<=0||!Ht(t)||t.__v_skip||(i=i||new Map,(i.get(t)||0)>=e))return t;if(i.set(t,e),e--,Jt(t))ti(t.value,e,i);else if($t(t))for(let n=0;n<t.length;n++)ti(t[n],e,i);else if(en(t)||Ki(t))t.forEach(n=>{ti(n,e,i)});else if(Yr(t)){for(const n in t)ti(t[n],e,i);for(const n of Object.getOwnPropertySymbols(t))Object.prototype.propertyIsEnumerable.call(t,n)&&ti(t[n],e,i)}return t}/**
* @vue/runtime-core v3.5.40
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/function On(t,e,i,n){try{return n?t(...n):t()}catch(o){Io(o,e,i)}}function Re(t,e,i,n){if(Bt(t)){const o=On(t,e,i,n);return o&&Gr(o)&&o.catch(s=>{Io(s,e,i)}),o}if($t(t)){const o=[];for(let s=0;s<t.length;s++)o.push(Re(t[s],e,i,n));return o}}function Io(t,e,i,n=!0){const o=e?e.vnode:null,{errorHandler:s,throwUnhandledErrorInProduction:l}=e&&e.appContext.config||Wt;if(e){let r=e.parent;const a=e.proxy,c=`https://vuejs.org/error-reference/#runtime-${i}`;for(;r;){const u=r.ec;if(u){for(let m=0;m<u.length;m++)if(u[m](t,a,c)===!1)return}r=r.parent}if(s){oi(),On(s,null,10,[t,a,c]),si();return}}ed(t,i,o,n,l)}function ed(t,e,i,n=!0,o=!1){if(o)throw t;console.error(t)}const be=[];let Fe=-1;const Gi=[];let pi=null,ji=0;const gl=Promise.resolve();let co=null;function vl(t){const e=co||gl;return t?e.then(this?t.bind(this):t):e}function id(t){let e=Fe+1,i=be.length;for(;e<i;){const n=e+i>>>1,o=be[n],s=Tn(o);s<t||s===t&&o.flags&2?e=n+1:i=n}return e}function Is(t){if(!(t.flags&1)){const e=Tn(t),i=be[be.length-1];!i||!(t.flags&2)&&e>=Tn(i)?be.push(t):be.splice(id(e),0,t),t.flags|=1,bl()}}function bl(){co||(co=gl.then(kl))}function nd(t){$t(t)?Gi.push(...t):pi&&t.id===-1?pi.splice(ji+1,0,t):t.flags&1||(Gi.push(t),t.flags|=1),bl()}function Qs(t,e,i=Fe+1){for(;i<be.length;i++){const n=be[i];if(n&&n.flags&2){if(t&&n.id!==t.uid)continue;be.splice(i,1),i--,n.flags&4&&(n.flags&=-2),n(),n.flags&4||(n.flags&=-2)}}}function yl(t){if(Gi.length){const e=[...new Set(Gi)].sort((i,n)=>Tn(i)-Tn(n));if(Gi.length=0,pi){pi.push(...e);return}for(pi=e,ji=0;ji<pi.length;ji++){const i=pi[ji];i.flags&4&&(i.flags&=-2),i.flags&8||i(),i.flags&=-2}pi=null,ji=0}}const Tn=t=>t.id==null?t.flags&2?-1:1/0:t.id;function kl(t){try{for(Fe=0;Fe<be.length;Fe++){const e=be[Fe];e&&!(e.flags&8)&&(e.flags&4&&(e.flags&=-2),On(e,e.i,e.i?15:14),e.flags&4||(e.flags&=-2))}}finally{for(;Fe<be.length;Fe++){const e=be[Fe];e&&(e.flags&=-2)}Fe=-1,be.length=0,yl(),co=null,(be.length||Gi.length)&&kl()}}let de=null,wl=null;function uo(t){const e=de;return de=t,wl=t&&t.type.__scopeId||null,e}function xl(t,e=de,i){if(!e||t._n)return t;const n=(...o)=>{n._d&&ur(-1);const s=uo(e),l=ii.length;let r;try{r=t(...o)}finally{for(let a=ii.length;a>l;a--)Ls();uo(s),n._d&&ur(1)}return r};return n._n=!0,n._c=!0,n._d=!0,n}function Te(t,e){if(de===null)return t;const i=Eo(de),n=t.dirs||(t.dirs=[]);for(let o=0;o<e.length;o++){let[s,l,r,a=Wt]=e[o];s&&(Bt(s)&&(s={mounted:s,updated:s}),s.deep&&ti(l),n.push({dir:s,instance:i,value:l,oldValue:void 0,arg:r,modifiers:a}))}return t}function xi(t,e,i,n){const o=t.dirs,s=e&&e.dirs;for(let l=0;l<o.length;l++){const r=o[l];s&&(r.oldValue=s[l].value);let a=r.dir[n];a&&(oi(),Re(a,i,8,[t.el,r,t,e]),si())}}function od(t,e){if(me){let i=me.provides;const n=me.parent&&me.parent.provides;n===i&&(i=me.provides=Object.create(n)),i[t]=e}}function ei(t,e,i=!1){const n=iu();if(n||Yi){let o=Yi?Yi._context.provides:n?n.parent==null||n.ce?n.vnode.appContext&&n.vnode.appContext.provides:n.parent.provides:void 0;if(o&&t in o)return o[t];if(arguments.length>1)return i&&Bt(e)?e.call(n&&n.proxy):e}}const sd=Symbol.for("v-scx"),rd=()=>ei(sd);function Di(t,e,i){return Sl(t,e,i)}function Sl(t,e,i=Wt){const{immediate:n,deep:o,flush:s,once:l}=i,r=ue({},i),a=e&&n||!e&&s!=="post";let c;if(Mn){if(s==="sync"){const d=rd();c=d.__watcherHandles||(d.__watcherHandles=[])}else if(!a){const d=()=>{};return d.stop=qe,d.resume=qe,d.pause=qe,d}}const u=me;r.call=(d,b,f)=>Re(d,u,b,f);let m=!1;s==="post"?r.scheduler=d=>{we(d,u&&u.suspense)}:s!=="sync"&&(m=!0,r.scheduler=(d,b)=>{b?d():Is(d)}),r.augmentJob=d=>{e&&(d.flags|=4),m&&(d.flags|=2,u&&(d.id=u.uid,d.i=u))};const g=td(t,e,r);return Mn&&(c?c.push(g):a&&g()),g}function ld(t,e,i){const n=this.proxy,o=ee(t)?t.includes(".")?_l(n,t):()=>n[t]:t.bind(n,n);let s;Bt(e)?s=e:(s=e.handler,i=e);const l=zn(this),r=Sl(o,s.bind(n),i);return l(),r}function _l(t,e){const i=e.split(".");return()=>{let n=t;for(let o=0;o<i.length&&n;o++)n=n[i[o]];return n}}const ad=Symbol("_vte"),cd=t=>t.__isTeleport,Ho=Symbol("_leaveCb");function As(t,e){t.shapeFlag&6&&t.component?(t.transition=e,As(t.component.subTree,e)):t.shapeFlag&128?(t.ssContent.transition=e.clone(t.ssContent),t.ssFallback.transition=e.clone(t.ssFallback)):t.transition=e}function Ce(t,e){return Bt(t)?ue({name:t.name},e,{setup:t}):t}function Cl(t){t.ids=[t.ids[0]+t.ids[2]+++"-",0,0]}function tr(t,e){let i;return!!((i=Object.getOwnPropertyDescriptor(t,e))&&!i.configurable)}const fo=new WeakMap;function gn(t,e,i,n,o=!1){if($t(t)){t.forEach((f,v)=>gn(f,e&&($t(e)?e[v]:e),i,n,o));return}if(Zi(n)&&!o){n.shapeFlag&512&&n.type.__asyncResolved&&n.component.subTree.component&&gn(t,e,i,n.component.subTree);return}const s=n.shapeFlag&4?Eo(n.component):n.el,l=o?null:s,{i:r,r:a}=t,c=e&&e.r,u=r.refs===Wt?r.refs={}:r.refs,m=r.setupState,g=Rt(m),d=m===Wt?Kr:f=>tr(u,f)?!1:zt(g,f),b=(f,v)=>!(v&&tr(u,v));if(c!=null&&c!==a){if(er(e),ee(c))u[c]=null,d(c)&&(m[c]=null);else if(Jt(c)){const f=e;b(c,f.k)&&(c.value=null),f.k&&(u[f.k]=null)}}if(Bt(a))On(a,r,12,[l,u]);else{const f=ee(a),v=Jt(a);if(f||v){const k=()=>{if(t.f){const S=f?d(a)?m[a]:u[a]:b()||!t.k?a.value:u[t.k];if(o)$t(S)&&vs(S,s);else if($t(S))S.includes(s)||S.push(s);else if(f)u[a]=[s],d(a)&&(m[a]=u[a]);else{const x=[s];b(a,t.k)&&(a.value=x),t.k&&(u[t.k]=x)}}else f?(u[a]=l,d(a)&&(m[a]=l)):v&&(b(a,t.k)&&(a.value=l),t.k&&(u[t.k]=l))};if(l){const S=()=>{k(),fo.delete(t)};S.id=-1,fo.set(t,S),we(S,i)}else er(t),k()}}}function er(t){const e=fo.get(t);e&&(e.flags|=8,fo.delete(t))}_o().requestIdleCallback;_o().cancelIdleCallback;const Zi=t=>!!t.type.__asyncLoader,$l=t=>t.type.__isKeepAlive;function dd(t,e){Il(t,"a",e)}function ud(t,e){Il(t,"da",e)}function Il(t,e,i=me){const n=t.__wdc||(t.__wdc=()=>{let o=i;for(;o;){if(o.isDeactivated)return;o=o.parent}return t()});if(Ao(e,n,i),i){let o=i.parent;for(;o&&o.parent;)$l(o.parent.vnode)&&fd(n,e,i,o),o=o.parent}}function fd(t,e,i,n){const o=Ao(e,t,n,!0);Ts(()=>{vs(n[e],o)},i)}function Ao(t,e,i=me,n=!1){if(i){const o=i[t]||(i[t]=[]),s=e.__weh||(e.__weh=(...l)=>{oi();const r=zn(i),a=Re(e,i,t,l);return r(),si(),a});return n?o.unshift(s):o.push(s),s}}const ai=t=>(e,i=me)=>{(!Mn||t==="sp")&&Ao(t,(...n)=>e(...n),i)},pd=ai("bm"),Rn=ai("m"),hd=ai("bu"),md=ai("u"),Bs=ai("bum"),Ts=ai("um"),gd=ai("sp"),vd=ai("rtg"),bd=ai("rtc");function yd(t,e=me){Ao("ec",t,e)}const kd="components";function wd(t,e){return Sd(kd,t,!0,e)||t}const xd=Symbol.for("v-ndc");function Sd(t,e,i=!0,n=!1){const o=de||me;if(o){const s=o.type;{const r=lu(s,!1);if(r&&(r===e||r===ye(e)||r===xo(ye(e))))return s}const l=ir(o[t]||s[t],e)||ir(o.appContext[t],e);return!l&&n?s:l}}function ir(t,e){return t&&(t[e]||t[ye(e)]||t[xo(ye(e))])}function xe(t,e,i,n){let o;const s=i,l=$t(t);if(l||ee(t)){const r=l&&Li(t);let a=!1,c=!1;r&&(a=!Be(t),c=ri(t),t=Co(t)),o=new Array(t.length);for(let u=0,m=t.length;u<m;u++)o[u]=e(a?c?Ji(Oe(t[u])):Oe(t[u]):t[u],u,void 0,s)}else if(typeof t=="number"){o=new Array(t);for(let r=0;r<t;r++)o[r]=e(r+1,r,void 0,s)}else if(Ht(t))if(t[Symbol.iterator])o=Array.from(t,(r,a)=>e(r,a,void 0,s));else{const r=Object.keys(t);o=new Array(r.length);for(let a=0,c=r.length;a<c;a++){const u=r[a];o[a]=e(t[u],u,a,s)}}else o=[];return o}function qn(t,e,i={},n,o,s){if(de.ce||de.parent&&Zi(de.parent)&&de.parent.ce){const c=i,u=Object.keys(c).length>0;return e!=="default"&&(c.name=e),nt(),Le(Kt,null,[dt("slot",c,n&&n())],u?-2:64)}let l=t[e];l&&l._c&&(l._d=!1);const r=ii.length;nt();let a;try{const c=l&&Al(l(i)),u=i.key||s||c&&c.key;a=Le(Kt,{key:(u&&!Pe(u)?u:`_${e}`)+(!c&&n?"_fb":"")},c||(n?n():[]),c&&t._===1?64:-2)}catch(c){for(let u=ii.length;u>r;u--)Ls();throw c}finally{l&&l._c&&(l._d=!0)}return a}function Al(t){return t.some(e=>Ds(e)?!(e.type===li||e.type===Kt&&!Al(e.children)):!0)?t:null}const rs=t=>t?Gl(t)?Eo(t):rs(t.parent):null,vn=ue(Object.create(null),{$:t=>t,$el:t=>t.vnode.el,$data:t=>t.data,$props:t=>t.props,$attrs:t=>t.attrs,$slots:t=>t.slots,$refs:t=>t.refs,$parent:t=>rs(t.parent),$root:t=>rs(t.root),$host:t=>t.ce,$emit:t=>t.emit,$options:t=>Tl(t),$forceUpdate:t=>t.f||(t.f=()=>{Is(t.update)}),$nextTick:t=>t.n||(t.n=vl.bind(t.proxy)),$watch:t=>ld.bind(t)}),jo=(t,e)=>t!==Wt&&!t.__isScriptSetup&&zt(t,e),_d={get({_:t},e){if(e==="__v_skip")return!0;const{ctx:i,setupState:n,data:o,props:s,accessCache:l,type:r,appContext:a}=t;if(e[0]!=="$"){const g=l[e];if(g!==void 0)switch(g){case 1:return n[e];case 2:return o[e];case 4:return i[e];case 3:return s[e]}else{if(jo(n,e))return l[e]=1,n[e];if(o!==Wt&&zt(o,e))return l[e]=2,o[e];if(zt(s,e))return l[e]=3,s[e];if(i!==Wt&&zt(i,e))return l[e]=4,i[e];ls&&(l[e]=0)}}const c=vn[e];let u,m;if(c)return e==="$attrs"&&he(t.attrs,"get",""),c(t);if((u=r.__cssModules)&&(u=u[e]))return u;if(i!==Wt&&zt(i,e))return l[e]=4,i[e];if(m=a.config.globalProperties,zt(m,e))return m[e]},set({_:t},e,i){const{data:n,setupState:o,ctx:s}=t;return jo(o,e)?(o[e]=i,!0):n!==Wt&&zt(n,e)?(n[e]=i,!0):zt(t.props,e)||e[0]==="$"&&e.slice(1)in t?!1:(s[e]=i,!0)},has({_:{data:t,setupState:e,accessCache:i,ctx:n,appContext:o,props:s,type:l}},r){let a;return!!(i[r]||t!==Wt&&r[0]!=="$"&&zt(t,r)||jo(e,r)||zt(s,r)||zt(n,r)||zt(vn,r)||zt(o.config.globalProperties,r)||(a=l.__cssModules)&&a[r])},defineProperty(t,e,i){return i.get!=null?t._.accessCache[e]=0:zt(i,"value")&&this.set(t,e,i.value,null),Reflect.defineProperty(t,e,i)}};function nr(t){return $t(t)?t.reduce((e,i)=>(e[i]=null,e),{}):t}let ls=!0;function Cd(t){const e=Tl(t),i=t.proxy,n=t.ctx;ls=!1,e.beforeCreate&&or(e.beforeCreate,t,"bc");const{data:o,computed:s,methods:l,watch:r,provide:a,inject:c,created:u,beforeMount:m,mounted:g,beforeUpdate:d,updated:b,activated:f,deactivated:v,beforeDestroy:k,beforeUnmount:S,destroyed:x,unmounted:B,render:E,renderTracked:A,renderTriggered:w,errorCaptured:F,serverPrefetch:H,expose:j,inheritAttrs:J,components:I,directives:N,filters:y}=e;if(c&&$d(c,n,null),l)for(const R in l){const U=l[R];Bt(U)&&(n[R]=U.bind(i))}if(o){const R=o.call(i,i);Ht(R)&&(t.data=$o(R))}if(ls=!0,s)for(const R in s){const U=s[R],W=Bt(U)?U.bind(i,i):Bt(U.get)?U.get.bind(i,i):qe,tt=!Bt(U)&&Bt(U.set)?U.set.bind(i):qe,T=St({get:W,set:tt});Object.defineProperty(n,R,{enumerable:!0,configurable:!0,get:()=>T.value,set:M=>T.value=M})}if(r)for(const R in r)Bl(r[R],n,i,R);if(a){const R=Bt(a)?a.call(i):a;Reflect.ownKeys(R).forEach(U=>{od(U,R[U])})}u&&or(u,t,"c");function X(R,U){$t(U)?U.forEach(W=>R(W.bind(i))):U&&R(U.bind(i))}if(X(pd,m),X(Rn,g),X(hd,d),X(md,b),X(dd,f),X(ud,v),X(yd,F),X(bd,A),X(vd,w),X(Bs,S),X(Ts,B),X(gd,H),$t(j))if(j.length){const R=t.exposed||(t.exposed={});j.forEach(U=>{Object.defineProperty(R,U,{get:()=>i[U],set:W=>i[U]=W,enumerable:!0})})}else t.exposed||(t.exposed={});E&&t.render===qe&&(t.render=E),J!=null&&(t.inheritAttrs=J),I&&(t.components=I),N&&(t.directives=N),H&&Cl(t)}function $d(t,e,i=qe){$t(t)&&(t=as(t));for(const n in t){const o=t[n];let s;Ht(o)?"default"in o?s=ei(o.from||n,o.default,!0):s=ei(o.from||n):s=ei(o),Jt(s)?Object.defineProperty(e,n,{enumerable:!0,configurable:!0,get:()=>s.value,set:l=>s.value=l}):e[n]=s}}function or(t,e,i){Re($t(t)?t.map(n=>n.bind(e.proxy)):t.bind(e.proxy),e,i)}function Bl(t,e,i,n){let o=n.includes(".")?_l(i,n):()=>i[n];if(ee(t)){const s=e[t];Bt(s)&&Di(o,s)}else if(Bt(t))Di(o,t.bind(i));else if(Ht(t))if($t(t))t.forEach(s=>Bl(s,e,i,n));else{const s=Bt(t.handler)?t.handler.bind(i):e[t.handler];Bt(s)&&Di(o,s,t)}}function Tl(t){const e=t.type,{mixins:i,extends:n}=e,{mixins:o,optionsCache:s,config:{optionMergeStrategies:l}}=t.appContext,r=s.get(e);let a;return r?a=r:!o.length&&!i&&!n?a=e:(a={},o.length&&o.forEach(c=>po(a,c,l,!0)),po(a,e,l)),Ht(e)&&s.set(e,a),a}function po(t,e,i,n=!1){const{mixins:o,extends:s}=e;s&&po(t,s,i,!0),o&&o.forEach(l=>po(t,l,i,!0));for(const l in e)if(!(n&&l==="expose")){const r=Id[l]||i&&i[l];t[l]=r?r(t[l],e[l]):e[l]}return t}const Id={data:sr,props:rr,emits:rr,methods:dn,computed:dn,beforeCreate:ve,created:ve,beforeMount:ve,mounted:ve,beforeUpdate:ve,updated:ve,beforeDestroy:ve,beforeUnmount:ve,destroyed:ve,unmounted:ve,activated:ve,deactivated:ve,errorCaptured:ve,serverPrefetch:ve,components:dn,directives:dn,watch:Bd,provide:sr,inject:Ad};function sr(t,e){return e?t?function(){return ue(Bt(t)?t.call(this,this):t,Bt(e)?e.call(this,this):e)}:e:t}function Ad(t,e){return dn(as(t),as(e))}function as(t){if($t(t)){const e={};for(let i=0;i<t.length;i++)e[t[i]]=t[i];return e}return t}function ve(t,e){return t?[...new Set([].concat(t,e))]:e}function dn(t,e){return t?ue(Object.create(null),t,e):e}function rr(t,e){return t?$t(t)&&$t(e)?[...new Set([...t,...e])]:ue(Object.create(null),nr(t),nr(e??{})):e}function Bd(t,e){if(!t)return e;if(!e)return t;const i=ue(Object.create(null),t);for(const n in e)i[n]=ve(t[n],e[n]);return i}function El(){return{app:null,config:{isNativeTag:Kr,performance:!1,globalProperties:{},optionMergeStrategies:{},errorHandler:void 0,warnHandler:void 0,compilerOptions:{}},mixins:[],components:{},directives:{},provides:Object.create(null),optionsCache:new WeakMap,propsCache:new WeakMap,emitsCache:new WeakMap}}let Td=0;function Ed(t,e){return function(n,o=null){Bt(n)||(n=ue({},n)),o!=null&&!Ht(o)&&(o=null);const s=El(),l=new WeakSet,r=[];let a=!1;const c=s.app={_uid:Td++,_component:n,_props:o,_container:null,_context:s,_instance:null,version:cu,get config(){return s.config},set config(u){},use(u,...m){return l.has(u)||(u&&Bt(u.install)?(l.add(u),u.install(c,...m)):Bt(u)&&(l.add(u),u(c,...m))),c},mixin(u){return s.mixins.includes(u)||s.mixins.push(u),c},component(u,m){return m?(s.components[u]=m,c):s.components[u]},directive(u,m){return m?(s.directives[u]=m,c):s.directives[u]},mount(u,m,g){if(!a){const d=c._ceVNode||dt(n,o);return d.appContext=s,g===!0?g="svg":g===!1&&(g=void 0),t(d,u,g),a=!0,c._container=u,u.__vue_app__=c,Eo(d.component)}},onUnmount(u){r.push(u)},unmount(){a&&(Re(r,c._instance,16),t(null,c._container),delete c._container.__vue_app__)},provide(u,m){return s.provides[u]=m,c},runWithContext(u){const m=Yi;Yi=c;try{return u()}finally{Yi=m}}};return c}}let Yi=null;const Md=(t,e)=>e==="modelValue"||e==="model-value"?t.modelModifiers:t[`${e}Modifiers`]||t[`${ye(e)}Modifiers`]||t[`${yi(e)}Modifiers`];function Ld(t,e,...i){if(t.isUnmounted)return;const n=t.vnode.props||Wt;let o=i;const s=e.startsWith("update:"),l=s&&Md(n,e.slice(7));l&&(l.trim&&(o=i.map(u=>ee(u)?u.trim():u)),l.number&&(o=i.map(So)));let r,a=n[r=Oo(e)]||n[r=Oo(ye(e))];!a&&s&&(a=n[r=Oo(yi(e))]),a&&Re(a,t,6,o);const c=n[r+"Once"];if(c){if(!t.emitted)t.emitted={};else if(t.emitted[r])return;t.emitted[r]=!0,Re(c,t,6,o)}}const Dd=new WeakMap;function Ml(t,e,i=!1){const n=i?Dd:e.emitsCache,o=n.get(t);if(o!==void 0)return o;const s=t.emits;let l={},r=!1;if(!Bt(t)){const a=c=>{const u=Ml(c,e,!0);u&&(r=!0,ue(l,u))};!i&&e.mixins.length&&e.mixins.forEach(a),t.extends&&a(t.extends),t.mixins&&t.mixins.forEach(a)}return!s&&!r?(Ht(t)&&n.set(t,null),null):($t(s)?s.forEach(a=>l[a]=null):ue(l,s),Ht(t)&&n.set(t,l),l)}function Bo(t,e){return!t||!yo(e)?!1:(e=e.slice(2),e=e==="Once"?e:e.replace(/Once$/,""),zt(t,e[0].toLowerCase()+e.slice(1))||zt(t,yi(e))||zt(t,e))}function lr(t){const{type:e,vnode:i,proxy:n,withProxy:o,propsOptions:[s],slots:l,attrs:r,emit:a,render:c,renderCache:u,props:m,data:g,setupState:d,ctx:b,inheritAttrs:f}=t,v=uo(t);let k,S;try{if(i.shapeFlag&4){const B=o||n,E=B;k=je(c.call(E,B,u,m,d,g,b)),S=r}else{const B=e;k=je(B.length>1?B(m,{attrs:r,slots:l,emit:a}):B(m,null)),S=e.props?r:Pd(r)}}catch(B){ii.length=0,Io(B,t,1),k=dt(li)}let x=k;if(S&&f!==!1){const B=Object.keys(S),{shapeFlag:E}=x;B.length&&E&7&&(s&&B.some(ko)&&(S=Od(S,s)),x=Xi(x,S,!1,!0))}return i.dirs&&(x=Xi(x,null,!1,!0),x.dirs=x.dirs?x.dirs.concat(i.dirs):i.dirs),i.transition&&As(x,i.transition),k=x,uo(v),k}const Pd=t=>{let e;for(const i in t)(i==="class"||i==="style"||yo(i))&&((e||(e={}))[i]=t[i]);return e},Od=(t,e)=>{const i={};for(const n in t)(!ko(n)||!(n.slice(9)in e))&&(i[n]=t[n]);return i};function Rd(t,e,i){const{props:n,children:o,component:s}=t,{props:l,children:r,patchFlag:a}=e,c=s.emitsOptions;if(e.dirs||e.transition)return!0;if(i&&a>=0){if(a&1024)return!0;if(a&16)return n?ar(n,l,c):!!l;if(a&8){const u=e.dynamicProps;for(let m=0;m<u.length;m++){const g=u[m];if(Ll(l,n,g)&&!Bo(c,g))return!0}}}else return(o||r)&&(!r||!r.$stable)?!0:n===l?!1:n?l?ar(n,l,c):!0:!!l;return!1}function ar(t,e,i){const n=Object.keys(e);if(n.length!==Object.keys(t).length)return!0;for(let o=0;o<n.length;o++){const s=n[o];if(Ll(e,t,s)&&!Bo(i,s))return!0}return!1}function Ll(t,e,i){const n=t[i],o=e[i];return i==="style"&&Ht(n)&&Ht(o)?!nn(n,o):n!==o}function zd({vnode:t,parent:e,suspense:i},n){for(;e;){const o=e.subTree;if(o.suspense&&o.suspense.activeBranch===t&&(o.suspense.vnode.el=o.el=n,t=o),o===t)(t=e.vnode).el=n,e=e.parent;else break}i&&i.activeBranch===t&&(i.vnode.el=n)}const Dl={},Pl=()=>Object.create(Dl),Ol=t=>Object.getPrototypeOf(t)===Dl;function Nd(t,e,i,n=!1){const o={},s=Pl();t.propsDefaults=Object.create(null),Rl(t,e,o,s);for(const l in t.propsOptions[0])l in o||(o[l]=void 0);i?t.props=n?o:qc(o):t.type.props?t.props=o:t.props=s,t.attrs=s}function Fd(t,e,i,n){const{props:o,attrs:s,vnode:{patchFlag:l}}=t,r=Rt(o),[a]=t.propsOptions;let c=!1;if((n||l>0)&&!(l&16)){if(l&8){const u=t.vnode.dynamicProps;for(let m=0;m<u.length;m++){let g=u[m];if(Bo(t.emitsOptions,g))continue;const d=e[g];if(a)if(zt(s,g))d!==s[g]&&(s[g]=d,c=!0);else{const b=ye(g);o[b]=cs(a,r,b,d,t,!1)}else d!==s[g]&&(s[g]=d,c=!0)}}}else{Rl(t,e,o,s)&&(c=!0);let u;for(const m in r)(!e||!zt(e,m)&&((u=yi(m))===m||!zt(e,u)))&&(a?i&&(i[m]!==void 0||i[u]!==void 0)&&(o[m]=cs(a,r,m,void 0,t,!0)):delete o[m]);if(s!==r)for(const m in s)(!e||!zt(e,m))&&(delete s[m],c=!0)}c&&Qe(t.attrs,"set","")}function Rl(t,e,i,n){const[o,s]=t.propsOptions;let l=!1,r;if(e)for(let a in e){if(pn(a))continue;const c=e[a];let u;o&&zt(o,u=ye(a))?!s||!s.includes(u)?i[u]=c:(r||(r={}))[u]=c:Bo(t.emitsOptions,a)||(!(a in n)||c!==n[a])&&(n[a]=c,l=!0)}if(s){const a=Rt(i),c=r||Wt;for(let u=0;u<s.length;u++){const m=s[u];i[m]=cs(o,a,m,c[m],t,!zt(c,m))}}return l}function cs(t,e,i,n,o,s){const l=t[i];if(l!=null){const r=zt(l,"default");if(r&&n===void 0){const a=l.default;if(l.type!==Function&&!l.skipFactory&&Bt(a)){const{propsDefaults:c}=o;if(i in c)n=c[i];else{const u=zn(o);n=c[i]=a.call(null,e),u()}}else n=a;o.ce&&o.ce._setProp(i,n)}l[0]&&(s&&!r?n=!1:l[1]&&(n===""||n===yi(i))&&(n=!0))}return n}const Hd=new WeakMap;function zl(t,e,i=!1){const n=i?Hd:e.propsCache,o=n.get(t);if(o)return o;const s=t.props,l={},r=[];let a=!1;if(!Bt(t)){const u=m=>{a=!0;const[g,d]=zl(m,e,!0);ue(l,g),d&&r.push(...d)};!i&&e.mixins.length&&e.mixins.forEach(u),t.extends&&u(t.extends),t.mixins&&t.mixins.forEach(u)}if(!s&&!a)return Ht(t)&&n.set(t,qi),qi;if($t(s))for(let u=0;u<s.length;u++){const m=ye(s[u]);cr(m)&&(l[m]=Wt)}else if(s)for(const u in s){const m=ye(u);if(cr(m)){const g=s[u],d=l[m]=$t(g)||Bt(g)?{type:g}:ue({},g),b=d.type;let f=!1,v=!0;if($t(b))for(let k=0;k<b.length;++k){const S=b[k],x=Bt(S)&&S.name;if(x==="Boolean"){f=!0;break}else x==="String"&&(v=!1)}else f=Bt(b)&&b.name==="Boolean";d[0]=f,d[1]=v,(f||zt(d,"default"))&&r.push(m)}}const c=[l,r];return Ht(t)&&n.set(t,c),c}function cr(t){return t[0]!=="$"&&!pn(t)}const Es=t=>t==="_"||t==="_ctx"||t==="$stable",Ms=t=>$t(t)?t.map(je):[je(t)],jd=(t,e,i)=>{if(e._n)return e;const n=xl((...o)=>Ms(e(...o)),i);return n._c=!1,n},Nl=(t,e,i)=>{const n=t._ctx;for(const o in t){if(Es(o))continue;const s=t[o];if(Bt(s))e[o]=jd(o,s,n);else if(s!=null){const l=Ms(s);e[o]=()=>l}}},Fl=(t,e)=>{const i=Ms(e);t.slots.default=()=>i},Hl=(t,e,i)=>{for(const n in e)(i||!Es(n))&&(t[n]=e[n])},Ud=(t,e,i)=>{const n=t.slots=Pl();if(t.vnode.shapeFlag&32){const o=e._;o?(Hl(n,e,i),i&&Jr(n,"_",o,!0)):Nl(e,n)}else e&&Fl(t,e)},Wd=(t,e,i)=>{const{vnode:n,slots:o}=t;let s=!0,l=Wt;if(n.shapeFlag&32){const r=e._;r?i&&r===1?s=!1:Hl(o,e,i):(s=!e.$stable,Nl(e,o)),l=e}else e&&(Fl(t,e),l={default:1});if(s)for(const r in o)!Es(r)&&l[r]==null&&delete o[r]},we=Zd;function Vd(t){return qd(t)}function qd(t,e){const i=_o();i.__VUE__=!0;const{insert:n,remove:o,patchProp:s,createElement:l,createText:r,createComment:a,setText:c,setElementText:u,parentNode:m,nextSibling:g,setScopeId:d=qe,insertStaticContent:b}=t,f=(C,D,p,O=null,z=null,_=null,$=void 0,L=null,G=!!D.dynamicChildren)=>{if(C===D)return;C&&!an(C,D)&&(O=ct(C),M(C,z,_,!0),C=null),D.patchFlag===-2&&(G=!1,D.dynamicChildren=null);const{type:K,ref:q,shapeFlag:et}=D;switch(K){case To:v(C,D,p,O);break;case li:k(C,D,p,O);break;case Xn:C==null&&S(D,p,O,$);break;case Kt:I(C,D,p,O,z,_,$,L,G);break;default:et&1?E(C,D,p,O,z,_,$,L,G):et&6?N(C,D,p,O,z,_,$,L,G):(et&64||et&128)&&K.process(C,D,p,O,z,_,$,L,G,gt)}q!=null&&z?gn(q,C&&C.ref,_,D||C,!D):q==null&&C&&C.ref!=null&&gn(C.ref,null,_,C,!0)},v=(C,D,p,O)=>{if(C==null)n(D.el=r(D.children),p,O);else{const z=D.el=C.el;D.children!==C.children&&c(z,D.children)}},k=(C,D,p,O)=>{C==null?n(D.el=a(D.children||""),p,O):D.el=C.el},S=(C,D,p,O)=>{[C.el,C.anchor]=b(C.children,D,p,O,C.el,C.anchor)},x=({el:C,anchor:D},p,O)=>{let z;for(;C&&C!==D;)z=g(C),n(C,p,O),C=z;n(D,p,O)},B=({el:C,anchor:D})=>{let p;for(;C&&C!==D;)p=g(C),o(C),C=p;o(D)},E=(C,D,p,O,z,_,$,L,G)=>{if(D.type==="svg"?$="svg":D.type==="math"&&($="mathml"),C==null)A(D,p,O,z,_,$,L,G);else{const K=C.el&&C.el._isVueCE?C.el:null;try{K&&K._beginPatch(),H(C,D,z,_,$,L,G)}finally{K&&K._endPatch()}}},A=(C,D,p,O,z,_,$,L)=>{let G,K;const{props:q,shapeFlag:et,transition:at,dirs:lt}=C;if(G=C.el=l(C.type,_,q&&q.is,q),et&8?u(G,C.children):et&16&&F(C.children,G,null,O,z,Uo(C,_),$,L),lt&&xi(C,null,O,"created"),w(G,C,C.scopeId,$,O),q){for(const wt in q)wt!=="value"&&!pn(wt)&&s(G,wt,null,q[wt],_,O);"value"in q&&s(G,"value",null,q.value,_),(K=q.onVnodeBeforeMount)&&Ne(K,O,C)}lt&&xi(C,null,O,"beforeMount");const pt=Kd(z,at);pt&&at.beforeEnter(G),n(G,D,p),((K=q&&q.onVnodeMounted)||pt||lt)&&we(()=>{try{K&&Ne(K,O,C),pt&&at.enter(G),lt&&xi(C,null,O,"mounted")}finally{}},z)},w=(C,D,p,O,z)=>{if(p&&d(C,p),O)for(let _=0;_<O.length;_++)d(C,O[_]);if(z){let _=z.subTree;if(D===_||Vl(_.type)&&(_.ssContent===D||_.ssFallback===D)){const $=z.vnode;w(C,$,$.scopeId,$.slotScopeIds,z.parent)}}},F=(C,D,p,O,z,_,$,L,G=0)=>{for(let K=G;K<C.length;K++){const q=C[K]=L?Xe(C[K]):je(C[K]);f(null,q,D,p,O,z,_,$,L)}},H=(C,D,p,O,z,_,$)=>{const L=D.el=C.el;let{patchFlag:G,dynamicChildren:K,dirs:q}=D;G|=C.patchFlag&16;const et=C.props||Wt,at=D.props||Wt;let lt;if(p&&Si(p,!1),(lt=at.onVnodeBeforeUpdate)&&Ne(lt,p,D,C),q&&xi(D,C,p,"beforeUpdate"),p&&Si(p,!0),K&&(!C.dynamicChildren||C.dynamicChildren.length!==K.length)&&(G=0,$=!1,K=null),(et.innerHTML&&at.innerHTML==null||et.textContent&&at.textContent==null)&&u(L,""),K?j(C.dynamicChildren,K,L,p,O,Uo(D,z),_):$||U(C,D,L,null,p,O,Uo(D,z),_,!1),G>0){if(G&16)J(L,et,at,p,z);else if(G&2&&et.class!==at.class&&s(L,"class",null,at.class,z),G&4&&s(L,"style",et.style,at.style,z),G&8){const pt=D.dynamicProps;for(let wt=0;wt<pt.length;wt++){const kt=pt[wt],Dt=et[kt],Gt=at[kt];(Gt!==Dt||kt==="value")&&s(L,kt,Dt,Gt,z,p)}}G&1&&C.children!==D.children&&u(L,D.children)}else!$&&K==null&&J(L,et,at,p,z);((lt=at.onVnodeUpdated)||q)&&we(()=>{lt&&Ne(lt,p,D,C),q&&xi(D,C,p,"updated")},O)},j=(C,D,p,O,z,_,$)=>{for(let L=0;L<D.length;L++){const G=C[L],K=D[L],q=G.el&&(G.type===Kt||!an(G,K)||G.shapeFlag&198)?m(G.el):p;f(G,K,q,null,O,z,_,$,!0)}},J=(C,D,p,O,z)=>{if(D!==p){if(D!==Wt)for(const _ in D)!pn(_)&&!(_ in p)&&s(C,_,D[_],null,z,O);for(const _ in p){if(pn(_))continue;const $=p[_],L=D[_];$!==L&&_!=="value"&&s(C,_,L,$,z,O)}"value"in p&&s(C,"value",D.value,p.value,z)}},I=(C,D,p,O,z,_,$,L,G)=>{const K=D.el=C?C.el:r(""),q=D.anchor=C?C.anchor:r("");let{patchFlag:et,dynamicChildren:at,slotScopeIds:lt}=D;lt&&(L=L?L.concat(lt):lt),C==null?(n(K,p,O),n(q,p,O),F(D.children||[],p,q,z,_,$,L,G)):et>0&&et&64&&at&&C.dynamicChildren&&C.dynamicChildren.length===at.length?(j(C.dynamicChildren,at,p,z,_,$,L),(D.key!=null||z&&D===z.subTree)&&jl(C,D,!0)):U(C,D,p,q,z,_,$,L,G)},N=(C,D,p,O,z,_,$,L,G)=>{D.slotScopeIds=L,C==null?D.shapeFlag&512?z.ctx.activate(D,p,O,$,G):y(D,p,O,z,_,$,G):V(C,D,G)},y=(C,D,p,O,z,_,$)=>{const L=C.component=eu(C,O,z);if($l(C)&&(L.ctx.renderer=gt),nu(L,!1,$),L.asyncDep){if(z&&z.registerDep(L,X,$),!C.el){const G=L.subTree=dt(li);k(null,G,D,p),C.placeholder=G.el}}else X(L,C,D,p,z,_,$)},V=(C,D,p)=>{const O=D.component=C.component;if(Rd(C,D,p))if(O.asyncDep&&!O.asyncResolved){R(O,D,p);return}else O.next=D,O.update();else D.el=C.el,O.vnode=D},X=(C,D,p,O,z,_,$)=>{const L=()=>{if(C.isMounted){let{next:et,bu:at,u:lt,parent:pt,vnode:wt}=C;{const ie=Ul(C);if(ie){et&&(et.el=wt.el,R(C,et,$)),ie.asyncDep.then(()=>{we(()=>{C.isUnmounted||K()},z)});return}}let kt=et,Dt;Si(C,!1),et?(et.el=wt.el,R(C,et,$)):et=wt,at&&Jn(at),(Dt=et.props&&et.props.onVnodeBeforeUpdate)&&Ne(Dt,pt,et,wt),Si(C,!0);const Gt=lr(C),Yt=C.subTree;C.subTree=Gt,f(Yt,Gt,m(Yt.el),ct(Yt),C,z,_),et.el=Gt.el,kt===null&&zd(C,Gt.el),lt&&we(lt,z),(Dt=et.props&&et.props.onVnodeUpdated)&&we(()=>Ne(Dt,pt,et,wt),z)}else{let et;const{el:at,props:lt}=D,{bm:pt,m:wt,parent:kt,root:Dt,type:Gt}=C,Yt=Zi(D);Si(C,!1),pt&&Jn(pt),!Yt&&(et=lt&&lt.onVnodeBeforeMount)&&Ne(et,kt,D),Si(C,!0);{Dt.ce&&Dt.ce._hasShadowRoot()&&Dt.ce._injectChildStyle(Gt,C.parent?C.parent.type:void 0);const ie=C.subTree=lr(C);f(null,ie,p,O,C,z,_),D.el=ie.el}if(wt&&we(wt,z),!Yt&&(et=lt&&lt.onVnodeMounted)){const ie=D;we(()=>Ne(et,kt,ie),z)}(D.shapeFlag&256||kt&&Zi(kt.vnode)&&kt.vnode.shapeFlag&256)&&C.a&&we(C.a,z),C.isMounted=!0,D=p=O=null}};C.scope.on();const G=C.effect=new el(L);C.scope.off();const K=C.update=G.run.bind(G),q=C.job=G.runIfDirty.bind(G);q.i=C,q.id=C.uid,G.scheduler=()=>Is(q),Si(C,!0),K()},R=(C,D,p)=>{D.component=C;const O=C.vnode.props;C.vnode=D,C.next=null,Fd(C,D.props,O,p),Wd(C,D.children,p),oi(),Qs(C),si()},U=(C,D,p,O,z,_,$,L,G=!1)=>{const K=C&&C.children,q=C?C.shapeFlag:0,et=D.children,{patchFlag:at,shapeFlag:lt}=D;if(at>0){if(at&128){tt(K,et,p,O,z,_,$,L,G);return}else if(at&256){W(K,et,p,O,z,_,$,L,G);return}}lt&8?(q&16&&P(K,z,_),et!==K&&u(p,et)):q&16?lt&16?tt(K,et,p,O,z,_,$,L,G):P(K,z,_,!0):(q&8&&u(p,""),lt&16&&F(et,p,O,z,_,$,L,G))},W=(C,D,p,O,z,_,$,L,G)=>{C=C||qi,D=D||qi;const K=C.length,q=D.length,et=Math.min(K,q);let at;for(at=0;at<et;at++){const lt=D[at]=G?Xe(D[at]):je(D[at]);f(C[at],lt,p,null,z,_,$,L,G)}K>q?P(C,z,_,!0,!1,et):F(D,p,O,z,_,$,L,G,et)},tt=(C,D,p,O,z,_,$,L,G)=>{let K=0;const q=D.length;let et=C.length-1,at=q-1;for(;K<=et&&K<=at;){const lt=C[K],pt=D[K]=G?Xe(D[K]):je(D[K]);if(an(lt,pt))f(lt,pt,p,null,z,_,$,L,G);else break;K++}for(;K<=et&&K<=at;){const lt=C[et],pt=D[at]=G?Xe(D[at]):je(D[at]);if(an(lt,pt))f(lt,pt,p,null,z,_,$,L,G);else break;et--,at--}if(K>et){if(K<=at){const lt=at+1,pt=lt<q?D[lt].el:O;for(;K<=at;)f(null,D[K]=G?Xe(D[K]):je(D[K]),p,pt,z,_,$,L,G),K++}}else if(K>at)for(;K<=et;)M(C[K],z,_,!0),K++;else{const lt=K,pt=K,wt=new Map;for(K=pt;K<=at;K++){const se=D[K]=G?Xe(D[K]):je(D[K]);se.key!=null&&wt.set(se.key,K)}let kt,Dt=0;const Gt=at-pt+1;let Yt=!1,ie=0;const Nt=new Array(Gt);for(K=0;K<Gt;K++)Nt[K]=0;for(K=lt;K<=et;K++){const se=C[K];if(Dt>=Gt){M(se,z,_,!0);continue}let Xt;if(se.key!=null)Xt=wt.get(se.key);else for(kt=pt;kt<=at;kt++)if(Nt[kt-pt]===0&&an(se,D[kt])){Xt=kt;break}Xt===void 0?M(se,z,_,!0):(Nt[Xt-pt]=K+1,Xt>=ie?ie=Xt:Yt=!0,f(se,D[Xt],p,null,z,_,$,L,G),Dt++)}const Ge=Yt?Gd(Nt):qi;for(kt=Ge.length-1,K=Gt-1;K>=0;K--){const se=pt+K,Xt=D[se],ki=D[se+1],zi=se+1<q?ki.el||Wl(ki):O;Nt[K]===0?f(null,Xt,p,zi,z,_,$,L,G):Yt&&(kt<0||K!==Ge[kt]?T(Xt,p,zi,2):kt--)}}},T=(C,D,p,O,z=null)=>{const{el:_,type:$,transition:L,children:G,shapeFlag:K}=C;if(K&6){T(C.component.subTree,D,p,O);return}if(K&128){C.suspense.move(D,p,O);return}if(K&64){$.move(C,D,p,gt);return}if($===Kt){n(_,D,p);for(let et=0;et<G.length;et++)T(G[et],D,p,O);n(C.anchor,D,p);return}if($===Xn){x(C,D,p);return}if(O!==2&&K&1&&L)if(O===0)L.persisted&&!_[Ho]?n(_,D,p):(L.beforeEnter(_),n(_,D,p),we(()=>L.enter(_),z));else{const{leave:et,delayLeave:at,afterLeave:lt}=L,pt=()=>{C.ctx.isUnmounted?o(_):n(_,D,p)},wt=()=>{const kt=_._isLeaving||!!_[Ho];_._isLeaving&&_[Ho](!0),L.persisted&&!kt?pt():et(_,()=>{pt(),lt&&lt()})};at?at(_,pt,wt):wt()}else n(_,D,p)},M=(C,D,p,O=!1,z=!1)=>{const{type:_,props:$,ref:L,children:G,dynamicChildren:K,shapeFlag:q,patchFlag:et,dirs:at,cacheIndex:lt,memo:pt}=C;if(et===-2&&(z=!1),L!=null&&(oi(),gn(L,null,p,C,!0),si()),lt!=null&&(D.renderCache[lt]=void 0),q&256){D.ctx.deactivate(C);return}const wt=q&1&&at,kt=!Zi(C);let Dt;if(kt&&(Dt=$&&$.onVnodeBeforeUnmount)&&Ne(Dt,D,C),q&6)Q(C.component,p,O);else{if(q&128){C.suspense.unmount(p,O);return}wt&&xi(C,null,D,"beforeUnmount"),q&64?C.type.remove(C,D,p,gt,O):K&&!K.hasOnce&&(_!==Kt||et>0&&et&64)?P(K,D,p,!1,!0):(_===Kt&&et&384||!z&&q&16)&&P(G,D,p),O&&Y(C)}const Gt=pt!=null&&lt==null;(kt&&(Dt=$&&$.onVnodeUnmounted)||wt||Gt)&&we(()=>{Dt&&Ne(Dt,D,C),wt&&xi(C,null,D,"unmounted"),Gt&&(C.el=null)},p)},Y=C=>{const{type:D,el:p,anchor:O,transition:z}=C;if(D===Kt){Z(p,O);return}if(D===Xn){B(C);return}const _=()=>{o(p),z&&!z.persisted&&z.afterLeave&&z.afterLeave()};if(C.shapeFlag&1&&z&&!z.persisted){const{leave:$,delayLeave:L}=z,G=()=>$(p,_);L?L(C.el,_,G):G()}else _()},Z=(C,D)=>{let p;for(;C!==D;)p=g(C),o(C),C=p;o(D)},Q=(C,D,p)=>{const{bum:O,scope:z,job:_,subTree:$,um:L,m:G,a:K}=C;dr(G),dr(K),O&&Jn(O),z.stop(),_&&(_.flags|=8,M($,C,D,p)),L&&we(L,D),we(()=>{C.isUnmounted=!0},D)},P=(C,D,p,O=!1,z=!1,_=0)=>{for(let $=_;$<C.length;$++)M(C[$],D,p,O,z)},ct=C=>{if(C.shapeFlag&6)return ct(C.component.subTree);if(C.shapeFlag&128)return C.suspense.next();const D=g(C.anchor||C.el),p=D&&D[ad];return p?g(p):D};let rt=!1;const st=(C,D,p)=>{let O;C==null?D._vnode&&(M(D._vnode,null,null,!0),O=D._vnode.component):f(D._vnode||null,C,D,null,null,null,p),D._vnode=C,rt||(rt=!0,Qs(O),yl(),rt=!1)},gt={p:f,um:M,m:T,r:Y,mt:y,mc:F,pc:U,pbc:j,n:ct,o:t};return{render:st,hydrate:void 0,createApp:Ed(st)}}function Uo({type:t,props:e},i){return i==="svg"&&t==="foreignObject"||i==="mathml"&&t==="annotation-xml"&&e&&e.encoding&&e.encoding.includes("html")?void 0:i}function Si({effect:t,job:e},i){i?(t.flags|=32,e.flags|=4):(t.flags&=-33,e.flags&=-5)}function Kd(t,e){return(!t||t&&!t.pendingBranch)&&e&&!e.persisted}function jl(t,e,i=!1){const n=t.children,o=e.children;if($t(n)&&$t(o))for(let s=0;s<n.length;s++){const l=n[s];let r=o[s];r.shapeFlag&1&&!r.dynamicChildren&&((r.patchFlag<=0||r.patchFlag===32)&&(r=o[s]=Xe(o[s]),r.el=l.el),!i&&r.patchFlag!==-2&&jl(l,r)),r.type===To&&(r.patchFlag===-1&&(r=o[s]=Xe(r)),r.el=l.el),r.type===li&&!r.el&&(r.el=l.el)}}function Gd(t){const e=t.slice(),i=[0];let n,o,s,l,r;const a=t.length;for(n=0;n<a;n++){const c=t[n];if(c!==0){if(o=i[i.length-1],t[o]<c){e[n]=o,i.push(n);continue}for(s=0,l=i.length-1;s<l;)r=s+l>>1,t[i[r]]<c?s=r+1:l=r;c<t[i[s]]&&(s>0&&(e[n]=i[s-1]),i[s]=n)}}for(s=i.length,l=i[s-1];s-- >0;)i[s]=l,l=e[l];return i}function Ul(t){const e=t.subTree.component;if(e)return e.asyncDep&&!e.asyncResolved?e:Ul(e)}function dr(t){if(t)for(let e=0;e<t.length;e++)t[e].flags|=8}function Wl(t){if(t.placeholder)return t.placeholder;const e=t.component;return e?Wl(e.subTree):null}const Vl=t=>t.__isSuspense;function Zd(t,e){e&&e.pendingBranch?$t(t)?e.effects.push(...t):e.effects.push(t):nd(t)}const Kt=Symbol.for("v-fgt"),To=Symbol.for("v-txt"),li=Symbol.for("v-cmt"),Xn=Symbol.for("v-stc"),ii=[];let $e=null;function nt(t=!1){ii.push($e=t?null:[])}function Ls(){ii.pop(),$e=ii[ii.length-1]||null}let En=1;function ur(t,e=!1){En+=t,t<0&&$e&&e&&($e.hasOnce=!0)}function ql(t){return t.dynamicChildren=En>0?$e||qi:null,Ls(),En>0&&$e&&$e.push(t),t}function ot(t,e,i,n,o,s){return ql(h(t,e,i,n,o,s,!0))}function Le(t,e,i,n,o){return ql(dt(t,e,i,n,o,!0))}function Ds(t){return t?t.__v_isVNode===!0:!1}function an(t,e){return t.type===e.type&&t.key===e.key}const Kl=({key:t})=>t??null,Qn=({ref:t,ref_key:e,ref_for:i})=>(typeof t=="number"&&(t=""+t),t!=null?ee(t)||Jt(t)||Bt(t)?{i:de,r:t,k:e,f:!!i}:t:null);function h(t,e=null,i=null,n=0,o=null,s=t===Kt?0:1,l=!1,r=!1){const a={__v_isVNode:!0,__v_skip:!0,type:t,props:e,key:e&&Kl(e),ref:e&&Qn(e),scopeId:wl,slotScopeIds:null,children:i,component:null,suspense:null,ssContent:null,ssFallback:null,dirs:null,transition:null,el:null,anchor:null,target:null,targetStart:null,targetAnchor:null,staticCount:0,shapeFlag:s,patchFlag:n,dynamicProps:o,dynamicChildren:null,appContext:null,ctx:de};return r?(ho(a,i),s&128&&t.normalize(a)):i&&(a.shapeFlag|=ee(i)?8:16),En>0&&!l&&$e&&(a.patchFlag>0||s&6)&&a.patchFlag!==32&&$e.push(a),a}const dt=Yd;function Yd(t,e=null,i=null,n=0,o=null,s=!1){if((!t||t===xd)&&(t=li),Ds(t)){const r=Xi(t,e,!0);return i&&ho(r,i),En>0&&!s&&$e&&(r.shapeFlag&6?$e[$e.indexOf(t)]=r:$e.push(r)),r.patchFlag=-2,r}if(au(t)&&(t=t.__vccOpts),e){e=Jd(e);let{class:r,style:a}=e;r&&!ee(r)&&(e.class=At(r)),Ht(a)&&($s(a)&&!$t(a)&&(a=ue({},a)),e.style=In(a))}const l=ee(t)?1:Vl(t)?128:cd(t)?64:Ht(t)?4:Bt(t)?2:0;return h(t,e,i,n,o,l,s,!0)}function Jd(t){return t?$s(t)||Ol(t)?ue({},t):t:null}function Xi(t,e,i=!1,n=!1){const{props:o,ref:s,patchFlag:l,children:r,transition:a}=t,c=e?Xd(o||{},e):o,u={__v_isVNode:!0,__v_skip:!0,type:t.type,props:c,key:c&&Kl(c),ref:e&&e.ref?i&&s?$t(s)?s.concat(Qn(e)):[s,Qn(e)]:Qn(e):s,scopeId:t.scopeId,slotScopeIds:t.slotScopeIds,children:r,target:t.target,targetStart:t.targetStart,targetAnchor:t.targetAnchor,staticCount:t.staticCount,shapeFlag:t.shapeFlag,patchFlag:e&&t.type!==Kt?l===-1?16:l|16:l,dynamicProps:t.dynamicProps,dynamicChildren:t.dynamicChildren,appContext:t.appContext,dirs:t.dirs,transition:a,component:t.component,suspense:t.suspense,ssContent:t.ssContent&&Xi(t.ssContent),ssFallback:t.ssFallback&&Xi(t.ssFallback),placeholder:t.placeholder,el:t.el,anchor:t.anchor,ctx:t.ctx,ce:t.ce};return a&&n&&As(u,a.clone(u)),u}function Ae(t=" ",e=0){return dt(To,null,t,e)}function ge(t,e){const i=dt(Xn,null,t);return i.staticCount=e,i}function Ot(t="",e=!1){return e?(nt(),Le(li,null,t)):dt(li,null,t)}function je(t){return t==null||typeof t=="boolean"?dt(li):$t(t)?dt(Kt,null,t.slice()):Ds(t)?Xe(t):dt(To,null,String(t))}function Xe(t){return t.el===null&&t.patchFlag!==-1||t.memo?t:Xi(t)}function ho(t,e){let i=0;const{shapeFlag:n}=t;if(e==null)e=null;else if($t(e))i=16;else if(typeof e=="object")if(n&65){const o=e.default;o&&(o._c&&(o._d=!1),ho(t,o()),o._c&&(o._d=!0));return}else{i=32;const o=e._;!o&&!Ol(e)?e._ctx=de:o===3&&de&&(de.slots._===1?e._=1:(e._=2,t.patchFlag|=1024))}else if(Bt(e)){if(n&65){ho(t,{default:e});return}e={default:e,_ctx:de},i=32}else e=String(e),n&64?(i=16,e=[Ae(e)]):i=8;t.children=e,t.shapeFlag|=i}function Xd(...t){const e={};for(let i=0;i<t.length;i++){const n=t[i];for(const o in n)if(o==="class")e.class!==n.class&&(e.class=At([e.class,n.class]));else if(o==="style")e.style=In([e.style,n.style]);else if(yo(o)){const s=e[o],l=n[o];l&&s!==l&&!($t(s)&&s.includes(l))?e[o]=s?[].concat(s,l):l:l==null&&s==null&&!ko(o)&&(e[o]=l)}else o!==""&&(e[o]=n[o])}return e}function Ne(t,e,i,n=null){Re(t,e,7,[i,n])}const Qd=El();let tu=0;function eu(t,e,i){const n=t.type,o=(e?e.appContext:t.appContext)||Qd,s={uid:tu++,vnode:t,type:n,parent:e,appContext:o,root:null,next:null,subTree:null,effect:null,update:null,job:null,scope:new Ic(!0),render:null,proxy:null,exposed:null,exposeProxy:null,withProxy:null,provides:e?e.provides:Object.create(o.provides),ids:e?e.ids:["",0,0],accessCache:null,renderCache:[],components:null,directives:null,propsOptions:zl(n,o),emitsOptions:Ml(n,o),emit:null,emitted:null,propsDefaults:Wt,inheritAttrs:n.inheritAttrs,ctx:Wt,data:Wt,props:Wt,attrs:Wt,slots:Wt,refs:Wt,setupState:Wt,setupContext:null,suspense:i,suspenseId:i?i.pendingId:0,asyncDep:null,asyncResolved:!1,isMounted:!1,isUnmounted:!1,isDeactivated:!1,bc:null,c:null,bm:null,m:null,bu:null,u:null,um:null,bum:null,da:null,a:null,rtg:null,rtc:null,ec:null,sp:null};return s.ctx={_:s},s.root=e?e.root:s,s.emit=Ld.bind(null,s),t.ce&&t.ce(s),s}let me=null;const iu=()=>me||de;let mo,ds;{const t=_o(),e=(i,n)=>{let o;return(o=t[i])||(o=t[i]=[]),o.push(n),s=>{o.length>1?o.forEach(l=>l(s)):o[0](s)}};mo=e("__VUE_INSTANCE_SETTERS__",i=>me=i),ds=e("__VUE_SSR_SETTERS__",i=>Mn=i)}const zn=t=>{const e=me;return mo(t),t.scope.on(),()=>{t.scope.off(),mo(e)}},fr=()=>{me&&me.scope.off(),mo(null)};function Gl(t){return t.vnode.shapeFlag&4}let Mn=!1;function nu(t,e=!1,i=!1){e&&ds(e);const{props:n,children:o}=t.vnode,s=Gl(t);Nd(t,n,s,e),Ud(t,o,i||e);const l=s?ou(t,e):void 0;return e&&ds(!1),l}function ou(t,e){const i=t.type;t.accessCache=Object.create(null),t.proxy=new Proxy(t.ctx,_d);const{setup:n}=i;if(n){oi();const o=t.setupContext=n.length>1?ru(t):null,s=zn(t),l=On(n,t,0,[t.props,o]),r=Gr(l);if(si(),s(),(r||t.sp)&&!Zi(t)&&Cl(t),r){if(l.then(fr,fr),e)return l.then(a=>{pr(t,a)}).catch(a=>{Io(a,t,0)});t.asyncDep=l}else pr(t,l)}else Zl(t)}function pr(t,e,i){Bt(e)?t.type.__ssrInlineRender?t.ssrRender=e:t.render=e:Ht(e)&&(t.setupState=ml(e)),Zl(t)}function Zl(t,e,i){const n=t.type;t.render||(t.render=n.render||qe);{const o=zn(t);oi();try{Cd(t)}finally{si(),o()}}}const su={get(t,e){return he(t,"get",""),t[e]}};function ru(t){const e=i=>{t.exposed=i||{}};return{attrs:new Proxy(t.attrs,su),slots:t.slots,emit:t.emit,expose:e}}function Eo(t){return t.exposed?t.exposeProxy||(t.exposeProxy=new Proxy(ml(Kc(t.exposed)),{get(e,i){if(i in e)return e[i];if(i in vn)return vn[i](t)},has(e,i){return i in e||i in vn}})):t.proxy}function lu(t,e=!0){return Bt(t)?t.displayName||t.name:t.name||e&&t.__name}function au(t){return Bt(t)&&"__vccOpts"in t}const St=(t,e)=>Xc(t,e,Mn),cu="3.5.40";/**
* @vue/runtime-dom v3.5.40
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/let us;const hr=typeof window<"u"&&window.trustedTypes;if(hr)try{us=hr.createPolicy("vue",{createHTML:t=>t})}catch{}const Yl=us?t=>us.createHTML(t):t=>t,du="http://www.w3.org/2000/svg",uu="http://www.w3.org/1998/Math/MathML",Je=typeof document<"u"?document:null,mr=Je&&Je.createElement("template"),fu={insert:(t,e,i)=>{e.insertBefore(t,i||null)},remove:t=>{const e=t.parentNode;e&&e.removeChild(t)},createElement:(t,e,i,n)=>{const o=e==="svg"?Je.createElementNS(du,t):e==="mathml"?Je.createElementNS(uu,t):i?Je.createElement(t,{is:i}):Je.createElement(t);return t==="select"&&n&&n.multiple!=null&&o.setAttribute("multiple",n.multiple),o},createText:t=>Je.createTextNode(t),createComment:t=>Je.createComment(t),setText:(t,e)=>{t.nodeValue=e},setElementText:(t,e)=>{t.textContent=e},parentNode:t=>t.parentNode,nextSibling:t=>t.nextSibling,querySelector:t=>Je.querySelector(t),setScopeId(t,e){t.setAttribute(e,"")},insertStaticContent(t,e,i,n,o,s){const l=i?i.previousSibling:e.lastChild;if(o&&(o===s||o.nextSibling))for(;e.insertBefore(o.cloneNode(!0),i),!(o===s||!(o=o.nextSibling)););else{mr.innerHTML=Yl(n==="svg"?`<svg>${t}</svg>`:n==="mathml"?`<math>${t}</math>`:t);const r=mr.content;if(n==="svg"||n==="mathml"){const a=r.firstChild;for(;a.firstChild;)r.appendChild(a.firstChild);r.removeChild(a)}e.insertBefore(r,i)}return[l?l.nextSibling:e.firstChild,i?i.previousSibling:e.lastChild]}},pu=Symbol("_vtc");function hu(t,e,i){const n=t[pu];n&&(e=(e?[e,...n]:[...n]).join(" ")),e==null?t.removeAttribute("class"):i?t.setAttribute("class",e):t.className=e}const go=Symbol("_vod"),Jl=Symbol("_vsh"),Xl={name:"show",beforeMount(t,{value:e},{transition:i}){t[go]=t.style.display==="none"?"":t.style.display,i&&e?i.beforeEnter(t):cn(t,e)},mounted(t,{value:e},{transition:i}){i&&e&&i.enter(t)},updated(t,{value:e,oldValue:i},{transition:n}){!e!=!i&&(n?e?(n.beforeEnter(t),cn(t,!0),n.enter(t)):n.leave(t,()=>{cn(t,!1)}):cn(t,e))},beforeUnmount(t,{value:e}){cn(t,e)}};function cn(t,e){t.style.display=e?t[go]:"none",t[Jl]=!e}const mu=Symbol(""),gu=/(?:^|;)\s*display\s*:/;function vu(t,e,i){const n=t.style,o=ee(i);let s=!1;if(i&&!o){if(e)if(ee(e))for(const l of e.split(";")){const r=l.slice(0,l.indexOf(":")).trim();i[r]==null&&un(n,r,"")}else for(const l in e)i[l]==null&&un(n,l,"");for(const l in i){l==="display"&&(s=!0);const r=i[l];r!=null?yu(t,l,!ee(e)&&e?e[l]:void 0,r)||un(n,l,r):un(n,l,"")}}else if(o){if(e!==i){const l=n[mu];l&&(i+=";"+l),n.cssText=i,s=gu.test(i)}}else e&&t.removeAttribute("style");go in t&&(t[go]=s?n.display:"",t[Jl]&&(n.display="none"))}const gr=/\s*!important$/;function un(t,e,i){if($t(i))i.forEach(n=>un(t,e,n));else if(i==null&&(i=""),e.startsWith("--"))t.setProperty(e,i);else{const n=bu(t,e);gr.test(i)?t.setProperty(yi(n),i.replace(gr,""),"important"):t[n]=i}}const vr=["Webkit","Moz","ms"],Wo={};function bu(t,e){const i=Wo[e];if(i)return i;let n=ye(e);if(n!=="filter"&&n in t)return Wo[e]=n;n=xo(n);for(let o=0;o<vr.length;o++){const s=vr[o]+n;if(s in t)return Wo[e]=s}return e}function yu(t,e,i,n){return t.tagName==="TEXTAREA"&&(e==="width"||e==="height")&&ee(n)&&i===n}const br="http://www.w3.org/1999/xlink";function yr(t,e,i,n,o,s=Cc(e)){n&&e.startsWith("xlink:")?i==null?t.removeAttributeNS(br,e.slice(6,e.length)):t.setAttributeNS(br,e,i):i==null||s&&!Xr(i)?t.removeAttribute(e):t.setAttribute(e,s?"":Pe(i)?String(i):i)}function kr(t,e,i,n,o){if(e==="innerHTML"||e==="textContent"){i!=null&&(t[e]=e==="innerHTML"?Yl(i):i);return}const s=t.tagName;if(e==="value"&&s!=="PROGRESS"&&!s.includes("-")){const r=s==="OPTION"?t.getAttribute("value")||"":t.value,a=i==null?t.type==="checkbox"?"on":"":String(i);(r!==a||!("_value"in t))&&(t.value=a),i==null&&t.removeAttribute(e),t._value=i;return}let l=!1;if(i===""||i==null){const r=typeof t[e];r==="boolean"?i=Xr(i):i==null&&r==="string"?(i="",l=!0):r==="number"&&(i=0,l=!0)}try{t[e]=i}catch{}l&&t.removeAttribute(o||e)}function hi(t,e,i,n){t.addEventListener(e,i,n)}function ku(t,e,i,n){t.removeEventListener(e,i,n)}const wr=Symbol("_vei");function wu(t,e,i,n,o=null){const s=t[wr]||(t[wr]={}),l=s[e];if(n&&l)l.value=n;else{const[r,a]=_u(e);if(n){const c=s[e]=Iu(n,o);hi(t,r,c,a)}else l&&(ku(t,r,l,a),s[e]=void 0)}}const xu=/(Once|Passive|Capture)$/,Su=/^on:?(?:Once|Passive|Capture)$/;function _u(t){let e,i;for(;(i=t.match(xu))&&!Su.test(t);)e||(e={}),t=t.slice(0,t.length-i[1].length),e[i[1].toLowerCase()]=!0;return[t[2]===":"?t.slice(3):yi(t.slice(2)),e]}let Vo=0;const Cu=Promise.resolve(),$u=()=>Vo||(Cu.then(()=>Vo=0),Vo=Date.now());function Iu(t,e){const i=n=>{if(!n._vts)n._vts=Date.now();else if(n._vts<=i.attached)return;const o=i.value;if($t(o)){const s=n.stopImmediatePropagation;n.stopImmediatePropagation=()=>{s.call(n),n._stopped=!0};const l=o.slice(),r=[n];for(let a=0;a<l.length&&!n._stopped;a++){const c=l[a];c&&Re(c,e,5,r)}}else Re(o,e,5,[n])};return i.value=t,i.attached=$u(),i}const xr=t=>t.charCodeAt(0)===111&&t.charCodeAt(1)===110&&t.charCodeAt(2)>96&&t.charCodeAt(2)<123,Au=(t,e,i,n,o,s)=>{const l=o==="svg";e==="class"?hu(t,n,l):e==="style"?vu(t,i,n):yo(e)?ko(e)||wu(t,e,i,n,s):(e[0]==="."?(e=e.slice(1),!0):e[0]==="^"?(e=e.slice(1),!1):Bu(t,e,n,l))?(kr(t,e,n),!t.tagName.includes("-")&&(e==="value"||e==="checked"||e==="selected")&&yr(t,e,n,l,s,e!=="value")):t._isVueCE&&(Tu(t,e)||t._def.__asyncLoader&&(/[A-Z]/.test(e)||!ee(n)))?kr(t,ye(e),n,s,e):(e==="true-value"?t._trueValue=n:e==="false-value"&&(t._falseValue=n),yr(t,e,n,l))};function Bu(t,e,i,n){if(n)return!!(e==="innerHTML"||e==="textContent"||e in t&&xr(e)&&Bt(i));if(e==="spellcheck"||e==="draggable"||e==="translate"||e==="autocorrect"||e==="sandbox"&&t.tagName==="IFRAME"||e==="form"||e==="list"&&t.tagName==="INPUT"||e==="type"&&t.tagName==="TEXTAREA")return!1;if(e==="width"||e==="height"){const o=t.tagName;if(o==="IMG"||o==="VIDEO"||o==="CANVAS"||o==="SOURCE")return!1}return xr(e)&&ee(i)?!1:e in t}function Tu(t,e){const i=t._def.props;if(!i)return!1;const n=ye(e);return Array.isArray(i)?i.some(o=>ye(o)===n):Object.keys(i).some(o=>ye(o)===n)}const Qi=t=>{const e=t.props["onUpdate:modelValue"]||!1;return $t(e)?i=>Jn(e,i):e};function Eu(t){t.target.composing=!0}function Sr(t){const e=t.target;e.composing&&(e.composing=!1,e.dispatchEvent(new Event("input")))}const ni=Symbol("_assign");function _r(t,e,i){return e&&(t=t.trim()),i&&(t=So(t)),t}const vo={created(t,{modifiers:{lazy:e,trim:i,number:n}},o){t[ni]=Qi(o);const s=n||o.props&&o.props.type==="number";hi(t,e?"change":"input",l=>{l.target.composing||t[ni](_r(t.value,i,s))}),(i||s)&&hi(t,"change",()=>{t.value=_r(t.value,i,s)}),e||(hi(t,"compositionstart",Eu),hi(t,"compositionend",Sr),hi(t,"change",Sr))},mounted(t,{value:e}){t.value=e??""},beforeUpdate(t,{value:e,oldValue:i,modifiers:{lazy:n,trim:o,number:s}},l){if(t[ni]=Qi(l),t.composing)return;const r=(s||t.type==="number")&&!/^0\d/.test(t.value)?So(t.value):t.value,a=e??"";if(r===a)return;const c=t.getRootNode();(c instanceof Document||c instanceof ShadowRoot)&&c.activeElement===t&&t.type!=="range"&&(n&&e===i||o&&t.value.trim()===a)||(t.value=a)}},Kn={deep:!0,created(t,e,i){t[ni]=Qi(i),hi(t,"change",()=>{const n=t._modelValue,o=Ln(t),s=t.checked,l=t[ni];if($t(n)){const r=ys(n,o),a=r!==-1;if(s&&!a)l(n.concat(o));else if(!s&&a){const c=[...n];c.splice(r,1),l(c)}}else if(en(n)){const r=new Set(n);s?r.add(o):r.delete(o),l(r)}else l(Ql(t,s))})},mounted:Cr,beforeUpdate(t,e,i){t[ni]=Qi(i),Cr(t,e,i)}};function Cr(t,{value:e,oldValue:i},n){t._modelValue=e;let o;if($t(e))o=ys(e,n.props.value)>-1;else if(en(e))o=e.has(n.props.value);else{if(e===i)return;o=nn(e,Ql(t,!0))}t.checked!==o&&(t.checked=o)}const Mu={deep:!0,created(t,{value:e,modifiers:{number:i}},n){t._modelValue=e,hi(t,"change",()=>{const o=Array.prototype.filter.call(t.options,s=>s.selected).map(s=>i?So(Ln(s)):Ln(s));t[ni](t.multiple?en(t._modelValue)?new Set(o):o:o[0]),t._assigning=!0,vl(()=>{t._assigning=!1})}),t[ni]=Qi(n)},mounted(t,{value:e}){$r(t,e)},beforeUpdate(t,{value:e},i){t._modelValue=e,t[ni]=Qi(i)},updated(t,{value:e}){t._assigning||$r(t,e)}};function $r(t,e){const i=t.multiple,n=$t(e);if(!(i&&!n&&!en(e))){for(let o=0,s=t.options.length;o<s;o++){const l=t.options[o],r=Ln(l);if(i)if(n){const a=typeof r;a==="string"||a==="number"?l.selected=e.some(c=>String(c)===String(r)):l.selected=ys(e,r)>-1}else l.selected=e.has(r);else if(nn(Ln(l),e)){t.selectedIndex!==o&&(t.selectedIndex=o);return}}!i&&t.selectedIndex!==-1&&(t.selectedIndex=-1)}}function Ln(t){return"_value"in t?t._value:t.value}function Ql(t,e){const i=e?"_trueValue":"_falseValue";return i in t?t[i]:e}const Lu=["ctrl","shift","alt","meta"],Du={stop:t=>t.stopPropagation(),prevent:t=>t.preventDefault(),self:t=>t.target!==t.currentTarget,ctrl:t=>!t.ctrlKey,shift:t=>!t.shiftKey,alt:t=>!t.altKey,meta:t=>!t.metaKey,left:t=>"button"in t&&t.button!==0,middle:t=>"button"in t&&t.button!==1,right:t=>"button"in t&&t.button!==2,exact:(t,e)=>Lu.some(i=>t[`${i}Key`]&&!e.includes(i))},Me=(t,e)=>{if(!t)return t;const i=t._withMods||(t._withMods={}),n=e.join(".");return i[n]||(i[n]=((o,...s)=>{for(let l=0;l<e.length;l++){const r=Du[e[l]];if(r&&r(o,e))return}return t(o,...s)}))},Pu={esc:"escape",space:" ",up:"arrow-up",left:"arrow-left",right:"arrow-right",down:"arrow-down",delete:"backspace"},Ou=(t,e)=>{const i=t._withKeys||(t._withKeys={}),n=e.join(".");return i[n]||(i[n]=(o=>{if(!("key"in o))return;const s=yi(o.key);if(e.some(l=>l===s||Pu[l]===s))return t(o)}))},Ru=ue({patchProp:Au},fu);let Ir;function zu(){return Ir||(Ir=Vd(Ru))}const ta=((...t)=>{const e=zu().createApp(...t),{mount:i}=e;return e.mount=n=>{const o=Fu(n);if(!o)return;const s=e._component;!Bt(s)&&!s.render&&!s.template&&(s.template=o.innerHTML),o.nodeType===1&&(o.textContent="");const l=i(o,!1,Nu(o));return o instanceof Element&&(o.removeAttribute("v-cloak"),o.setAttribute("data-v-app","")),l},e});function Nu(t){if(t instanceof SVGElement)return"svg";if(typeof MathMLElement=="function"&&t instanceof MathMLElement)return"mathml"}function Fu(t){return ee(t)?document.querySelector(t):t}const Hu="slidev-config.json",tn={enableWebServeJump:!1,webServeUrl:"http://127.0.0.1:6806",normalizeHeadingSizes:!1},mi=$o({...tn});function ju(t){if(!t||typeof t!="object")return{...tn};const e=t;return{enableWebServeJump:!!e.enableWebServeJump,webServeUrl:typeof e.webServeUrl=="string"&&e.webServeUrl.trim()?e.webServeUrl.trim():tn.webServeUrl,normalizeHeadingSizes:!!e.normalizeHeadingSizes}}function Ei(t){if(!t||typeof t!="object")return{...mi};const e=t;return e.enableWebServeJump!==void 0&&(mi.enableWebServeJump=!!e.enableWebServeJump),e.webServeUrl!==void 0&&(mi.webServeUrl=String(e.webServeUrl)),e.normalizeHeadingSizes!==void 0&&(mi.normalizeHeadingSizes=!!e.normalizeHeadingSizes),{...mi}}function Mo(){return{...mi}}function ea(t,e,i){const n=(t||tn.webServeUrl).trim(),o=n.startsWith("http://")||n.startsWith("https://")?n:`http://${n}`,s=(i==null?void 0:i.r)||Math.random().toString(36).slice(2,9).padEnd(7,"0");try{const l=new URL(o);let r=l.pathname.replace(/\/+$/,"");return r.endsWith("/stage/build/desktop")||(r=r?`${r}/stage/build/desktop`:"/stage/build/desktop"),l.pathname=`${r}/`,l.searchParams.set("id",e),i!=null&&i.focus&&l.searchParams.set("focus","1"),l.searchParams.set("r",s),l.toString()}catch{const l=i!=null&&i.focus?"&focus=1":"";return`${o.replace(/\/+$/,"")}/stage/build/desktop/?id=${e}${l}&r=${s}`}}const _i={theme:"default",aspectRatio:"16/9",highlighter:"shiki",defaultTransition:"slide-left",colorSchema:"auto",spacing:"normal",normalizeHeadingSizes:!1};function Uu(t){var i,n,o,s,l,r;const e=Mo();return t?{theme:((i=t[xn])==null?void 0:i.trim())||_i.theme,aspectRatio:((n=t[Sn])==null?void 0:n.trim())||_i.aspectRatio,highlighter:((o=t[jr])==null?void 0:o.trim())||_i.highlighter,defaultTransition:((s=t[_n])==null?void 0:s.trim())||_i.defaultTransition,colorSchema:((l=t[Ur])==null?void 0:l.trim())||_i.colorSchema,spacing:((r=t[ts])==null?void 0:r.trim())||_i.spacing,normalizeHeadingSizes:e.normalizeHeadingSizes}:{..._i,normalizeHeadingSizes:e.normalizeHeadingSizes}}function bo(t){var i,n,o,s,l;const e=(i=t.ial)==null?void 0:i[Bi];return!!(e&&(e==="true"||e==="page"||e==="cover"||e==="end")||t.type==="tb"||t.type==="thematic-break"||t.type==="NodeThematicBreak"||((n=t.markdown)==null?void 0:n.trim())==="---"||((o=t.markdown)==null?void 0:o.trim())==="***"||t.type==="b"&&(((s=t.markdown)==null?void 0:s.trim())==="---"||((l=t.content)==null?void 0:l.trim())==="---"))}function Ar(t){const e={};let i="";if(!t)return{frontmatter:e,notes:i};t[ht]&&(e.layout=t[ht].trim()),t[te]&&(e.transition=t[te].trim()),t[Ut]&&(e.background=t[Ut].trim()),t[Ee]&&(e.image=t[Ee].trim()),t[Vi]&&(e.class=t[Vi].trim()),t[fn]&&(e.spacing=t[fn].trim()),t[le]&&(e.layoutRatio=t[le].trim()),t[Wi]&&(i=t[Wi].trim());for(const[n,o]of Object.entries(t))if(n.startsWith("custom-slidev-")&&![ht,le,te,Ut,Ee,Vi,fn,Wi,Bi].includes(n)){const s=n.replace(/^custom-slidev-/,"");try{e[s]=JSON.parse(o)}catch{e[s]=o}}return{frontmatter:e,notes:i}}function Wu(t){const e={};if(!t)return e;const i=t[ne]??t["slidev-note"];i!=null&&i!==""&&i!=="false"&&i!=="0"&&(e.isNote=!0);const n=t[qt]??t["slidev-role"],o=t[Ut]??t["slidev-background"];(n===Wr||o==="true"||o==="1")&&(e.isBackground=!0);const s=t[ht]??t["slidev-layout"];s===ro||s===lo?e.imageLayout=s:(n===ro||n===lo)&&(e.imageLayout=n);const l=t[jt]??t["custom-slidev-clicks"]??t["slidev-click"]??t["slidev-clicks"];if(l!=null&&(e.clicks=l.trim()),t[Ve])try{const r=JSON.parse(t[Ve]);typeof r=="object"&&r!==null?e.motion={preset:r.preset||r.type||"fade-in",...r}:e.motion={preset:String(r).trim()}}catch{e.motion={preset:t[Ve].trim()}}return t[Oi]&&(e.shikiLines=t[Oi].trim()),t[Cn]&&(e.maxHeight=t[Cn].trim()),t[Ct]&&(e.slot=t[Ct].trim()),t.style&&t.style.trim()&&(e.style=t.style.trim()),e}function bi(t,e){const i=(t||e||"").trim();if(!i)return null;const n=i.match(/!\[[\s\S]*?\]\(\s*([^\s)]+)(?:\s+(?:=["']?[^"'\s)]*["']?|["'][^"']*["']))*?\s*\)/);if(n)return n[1].trim();const o=i.match(/<img\b[^>]*?\bsrc=["']([^"']+)["']/i);if(o)return o[1].trim();const s=i.replace(/\{:[^}]*\}/g,"").trim();return/^(?:assets\/|https?:\/\/|\/|\.\.?\/)[^\s]+\.(?:png|jpe?g|gif|webp|svg|avif)(?:\?[^\s]*)?$/i.test(s)?s:null}function bn(t){if(!t)return"";const e=t.split(/\r?\n/);if(e.length===0)return"";const i=e[0],n=i.match(/^(\s*)(?:[-*+]|\d+\.)\s+(.*)$/);if(!n)return t;const o=n[1].length,s=n[2].trim(),l=i.length-n[2].length;if(e.length===1)return s;const r=[s];for(let a=1;a<e.length;a++){const c=e[a];if(!c.trim()){r.push("");continue}const u=c.match(/^(\s*)/),m=u?u[1].length:0;m>=l?r.push(c.slice(l)):m>o?r.push(c.slice(m)):r.push(c)}return r.join(`
`)}function Ri(t){if(!t)return!1;const e=(t.type||"").toLowerCase();if(e==="i"||e==="nodelistitem"||e==="l"||e==="nodelist")return!0;const i=(t.markdown||t.rawMarkdown||t.content||"").trim();return!!/^(?:[-*+]|\d+\.)\s+/.test(i)}function qo(t,e=2){if(!t||typeof t!="string")return`repeat(${e}, 1fr)`;const i=t.trim();if(!i)return`repeat(${e}, 1fr)`;if(i.includes(":")){const o=i.split(":").map(s=>parseFloat(s.trim())).filter(s=>!isNaN(s)&&s>0);if(o.length>=2)return o.map(s=>`${s}fr`).join(" ")}const n=i.split(/\s+/).filter(Boolean);return n.length>=2?n.join(" "):`repeat(${e}, 1fr)`}function yn(t){if(!t)return[];if(oe(t)&&Ke(t)&&!ci(t)){const n=on(t),o=[];for(const s of n)o.push(...yn(s));return o}const e=(t.type||"").toLowerCase();if(e==="l"||e==="nodelist"||e==="list"){if(t.children&&t.children.length>0){const l=t.children.filter(Ri);if(l.length>0)return l}const o=(t.markdown||t.content||"").trim().split(/\r?\n/),s=[];for(let l=0;l<o.length;l++)/^(?:[-*+]|\d+\.)\s+/.test(o[l])&&s.push(l);if(s.length>=2){const l=[];for(let r=0;r<s.length;r++){const a=s[r],c=r+1<s.length?s[r+1]:o.length,u=o.slice(a,c).join(`
`);l.push({id:`${t.id}-item-${r+1}`,type:"i",markdown:u,content:u,ial:{...t.ial||{}}})}return l}}return Ri(t)?[t]:[]}function Ps(t){var o;if(!t||!oe(t)||!Ke(t)||ci(t))return null;const e=on(t);if(e.length===0)return null;if(e.length===1&&oe(e[0])&&Ke(e[0])){const s=Ps(e[0]);return s?{items:s.items,nestedSuperBlocks:[e[0],...s.nestedSuperBlocks]}:null}const i=[];for(const s of e)if(oe(s)){i.push(s);const l=((o=s.children)==null?void 0:o.filter(oe))||[];i.push(...l)}const n=e.map(yn);if(n.length>=2&&n.every(s=>s.length>0)){const s=n.flat();if(s.length>=2&&s.length<=6)return{items:s,nestedSuperBlocks:i}}if(e.length===2){const s=yn(e[0]),l=yn(e[1]);if(s.length+l.length>=2&&s.length+l.length<=6&&(s.length>0||l.length>0))return{items:[...s,...l],nestedSuperBlocks:i}}return null}function Vu(t){if(!t||!oe(t)||!Ke(t)||ci(t))return null;const e=Ps(t);if(!e)return null;const{items:i,nestedSuperBlocks:n}=e;if(i.length<2||i.length>6)return null;const o=Os(t)||void 0,s=i.length;return{superBlockNode:t,nestedSuperBlocks:n,count:s,layout:"cols-header",items:i,slots:i.map((l,r)=>`col-${r+1}`),ratio:o}}function ia(t){if(!t||!oe(t)||!Ke(t)||ci(t))return null;const e=on(t);if(e.length===0)return null;const i=[];for(const n of e){const o=yn(n);if(o.length===0)return null;i.push(...o)}return i}function qu(t){if(!t||!oe(t)||!Ke(t)||ci(t))return null;const e=ia(t);return!e||e.length===0||e.length>=2&&e.length<=6?null:{superBlockNode:t,items:e}}function Ku(t){if(!t||!oe(t)||!Ke(t)||ci(t))return null;const e=Ps(t);if(e&&e.items.length===4)return e.items;const i=ia(t);if(i&&i.length===4)return i;const n=on(t);return n.length===4?n:null}function Gu(t,e){if(!t||t.length===0)return null;const i=[];function n(r,a){if(oe(r)){const c=Ku(r);c&&c.length===4&&i.push({sbNode:r,items:c,topLevelIndex:a})}if(r.children&&r.children.length>0)for(const c of r.children)n(c,a)}for(let r=0;r<t.length;r++)n(t[r],r);if(i.length===0)return null;let o=null;e&&(o=i.find(r=>{if(r.sbNode.id===e||r.items.some(c=>c.id===e))return!0;const a=c=>c.id===e?!0:c.children?c.children.some(a):!1;return a(r.sbNode)})||null),o||(o=i[0]);const l=t.slice(0,o.topLevelIndex).slice().reverse().find(r=>na(r));return{superBlockNode:o.sbNode,items:o.items,headerNode:l}}function Zu(t,e,i){var u,m,g,d,b;const n=[],o=[],s=(i==null?void 0:i.tracked)||[],l=[];let r={pageTargetId:t,blocks:[]};l.push(r);for(let f=0;f<e.length;f++){const v=e[f];if(bo(v)){if(l.length===1&&r.blocks.length===0){r.pageTargetId=v.id,r.blocks.push(v);continue}r={pageTargetId:v.id,blocks:[v]},l.push(r)}else r.blocks.push(v)}function a(f){const v=[];for(const k of f)oe(k)&&v.push(k),k.children&&k.children.length>0&&v.push(...a(k.children));return v}function c(f,v,k){const S={blockId:f,attrs:v,previousAttrs:k};n.push(S),i!=null&&i.onTagChange&&i.onTagChange(S)}for(const f of l){const v=f.pageTargetId,k=e.find(A=>A.id===v),S=s.find(A=>A.pageTargetId===v);if(f.blocks.some(A=>{var w,F;return!!(ci(A)||fs(A)&&(((w=A.ial)==null?void 0:w[ht])==="image-left"||((F=A.ial)==null?void 0:F[ht])==="image-right"))})){if(S){const A=S.headerId;if(A){c(A,{[Ct]:""});const w=e.find(F=>F.id===A);w!=null&&w.ial&&(w.ial[Ct]="")}for(const w of S.itemIds){c(w,{[Ct]:""});const F=e.find(H=>H.id===w);F!=null&&F.ial&&(F.ial[Ct]="")}}continue}let B=null,E=-1;for(let A=0;A<f.blocks.length;A++){const w=f.blocks[A],F=oe(w)?[w,...a(w.children||[])]:w.children?a(w.children):[];for(const H of F){const j=Vu(H);if(j){B=j,E=A;break}}if(B)break}if(B){const{superBlockNode:A,layout:w,items:F,slots:H}=B,J=f.blocks.slice(0,E).find(R=>na(R)),I=J==null?void 0:J.id,N=((u=k==null?void 0:k.ial)==null?void 0:u[ht])||"",y=N==="clover",V=y?"clover":w;if(N!==V&&(c(v,{[ht]:V},{[ht]:N}),k&&(k.ial||(k.ial={}),k.ial[ht]=V)),J){const R=((m=J.ial)==null?void 0:m[Ct])||"";R!=="header"&&(c(J.id,{[Ct]:"header"},{[Ct]:R}),J.ial||(J.ial={}),J.ial[Ct]="header")}if(S!=null&&S.headerId&&S.headerId!==I){c(S.headerId,{[Ct]:""});const R=e.find(U=>U.id===S.headerId);R&&(R.ial||(R.ial={}),R.ial[Ct]="")}const X=[];for(let R=0;R<F.length;R++){const U=F[R],W=H[R];X.push(U.id);const tt=((g=U.ial)==null?void 0:g[Ct])||"";if(tt!==W&&(c(U.id,{[Ct]:W},{[Ct]:tt}),U.ial||(U.ial={}),U.ial[Ct]=W),U.children&&U.children.length>0)for(const T of U.children)T.ial||(T.ial={}),T.ial[Ct]!==W&&(T.ial[Ct]=W)}if(S!=null&&S.itemIds){for(const R of S.itemIds)if(!X.includes(R)){c(R,{[Ct]:""});const U=e.find(W=>W.id===R);U&&(U.ial||(U.ial={}),U.ial[Ct]="")}}o.push({superBlockId:A.id,nestedSuperBlockIds:(d=B.nestedSuperBlocks)==null?void 0:d.map(R=>R.id),pageTargetId:v,headerId:I,itemIds:X,layout:y?"clover":w})}else{let A=!1;const w=[];for(const j of f.blocks){const J=oe(j)?[j,...a(j.children||[])]:j.children?a(j.children):[];for(const I of J){const N=qu(I);if(N){A=!0;for(const y of N.items)w.push(y.id)}}}const F=((b=k==null?void 0:k.ial)==null?void 0:b[ht])||"",H=$n(F);if(S||A&&H){c(v,{[ht]:""},{[ht]:F}),k&&(k.ial||(k.ial={}),k.ial[ht]="");const j=S==null?void 0:S.headerId;if(j){c(j,{[Ct]:""});const I=e.find(N=>N.id===j);I&&(I.ial||(I.ial={}),I.ial[Ct]="")}const J=new Set([...(S==null?void 0:S.itemIds)||[],...w]);for(const I of J){c(I,{[Ct]:""});const N=e.find(y=>y.id===I);N&&(N.ial||(N.ial={}),N.ial[Ct]="")}}}}return{changes:n,newTracked:o}}function oe(t){if(!t)return!1;const e=(t.type||"").toLowerCase();return e==="s"||e==="sb"||e==="nodesuperblock"}function Ke(t){if(!oe(t))return!1;const e=(t.subType||"").toLowerCase();if(e==="col"||e==="h"||e==="horizontal")return!0;if(e==="row"||e==="v"||e==="vertical")return!1;if(t.ial){const n=(t.ial["data-sb-layout"]||t.ial.layout||"").toLowerCase();if(n==="col"||n==="h")return!0;if(n==="row"||n==="v")return!1}if(t.children&&t.children.length>0){for(const n of t.children)if(n.type==="NodeSuperBlockLayoutMarker"||n.type==="layout-marker"){const o=(n.content||n.markdown||"").trim().toLowerCase();if(o==="col"||o==="h")return!0;if(o==="row"||o==="v")return!1}}const i=(t.markdown||t.content||"").trim();return/^\{\{\{col\b/i.test(i)?!0:!/^\{\{\{row\b/i.test(i)}function fs(t){return!t||Ri(t)||oe(t)||!bi(t.markdown,t.content)?!1:(t.markdown||t.content||"").replace(/!\[.*?\]\([^)]+\)/g,"").replace(/<img\b[^>]*>/gi,"").replace(/\{:[^}]*\}/g,"").trim().length<=25}function Os(t){var g;if(!t||!oe(t)||!Ke(t))return null;const e=on(t);if(!e||e.length<2)return null;const i=[];let n=!1;for(const d of e){const b=(((g=d.ial)==null?void 0:g.style)||d.style||"").trim();let f=null;if(b){const v=b.match(/calc\(\s*([\d.]+)%/i);if(v)f=parseFloat(v[1]);else{const k=b.match(/(?:^|;|\s)width:\s*([\d.]+)%/i);k&&(f=parseFloat(k[1]))}}f!==null&&!isNaN(f)&&f>0?(i.push(f),n=!0):i.push(null)}if(!n)return null;const o=e.length,s=i.reduce((d,b)=>d+(b||0),0),l=i.filter(d=>d===null).length,r=Math.max(0,100-s),a=l>0?r/l:100/o,c=i.map(d=>d!==null?d:a),u=c.reduce((d,b)=>d+b,0);if(u<=0)return null;const m=c.map(d=>d/u*100);if(m.length===2){const[d]=m;if(d>=48&&d<=52)return"1:1";if(d>=31&&d<=35)return"1:2";if(d>=65&&d<=69)return"2:1";if(d>=28&&d<=32)return"3:7";if(d>=68&&d<=72)return"7:3";if(d>=38&&d<=42)return"4:6";if(d>=58&&d<=62)return"6:4";if(d>=23&&d<=27)return"1:3";if(d>=73&&d<=77)return"3:1";const b=Math.round(d),f=100-b;return`${b}:${f}`}if(m.length===3){const[d,b,f]=m;if(d>=31&&d<=35&&b>=31&&b<=35&&f>=31&&f<=35)return"1:1:1";if(d>=23&&d<=27&&b>=48&&b<=52&&f>=23&&f<=27)return"1:2:1";if(d>=48&&d<=52&&b>=23&&b<=27&&f>=23&&f<=27)return"2:1:1";if(d>=23&&d<=27&&b>=23&&b<=27&&f>=48&&f<=52)return"1:1:2";if(d>=18&&d<=22&&b>=58&&b<=62&&f>=18&&f<=22)return"1:3:1";const v=Math.round(d),k=Math.round(b),S=100-v-k;return`${v}:${k}:${S}`}return m.map(d=>Math.round(d)).join(":")}function ci(t){if(!t||!oe(t)||!Ke(t))return null;const e=(t.children||[]).filter(s=>{const l=s.type||"";if(l==="NodeSuperBlockOpenMarker"||l==="NodeSuperBlockLayoutMarker"||l==="NodeSuperBlockCloseMarker"||l==="open-marker"||l==="layout-marker"||l==="close-marker")return!1;const r=(s.markdown||s.content||"").trim();return!(/^\{\{\{(?:col|row)?\s*$/i.test(r)||r==="}}}")});if(e.length<2)return null;const i=fs(e[0]),n=fs(e[e.length-1]),o=Os(t)||void 0;if(i&&!n){const s=bi(e[0].markdown,e[0].content);if(s)return{imageNode:e[0],imageUrl:s,layout:ro,contentNodes:e.slice(1),ratio:o}}if(!i&&n){const s=bi(e[e.length-1].markdown,e[e.length-1].content);if(s)return{imageNode:e[e.length-1],imageUrl:s,layout:lo,contentNodes:e.slice(0,e.length-1),ratio:o}}return null}function Yu(t,e){const i=[];function n(o){for(const s of o){const l=ci(s);if(l){const{imageNode:r,layout:a,ratio:c}=l;r.ial||(r.ial={});const u=r.ial[ht];if(u!==a){const g={blockId:r.id,layout:a,previousLayout:u,ratio:c};r.ial[ht]=a,i.push(g),e&&e(g)}}s.children&&s.children.length>0&&n(s.children)}}return n(t),i}function on(t){return(t.children||[]).filter(e=>{const i=e.type||"";if(i==="NodeSuperBlockOpenMarker"||i==="NodeSuperBlockLayoutMarker"||i==="NodeSuperBlockCloseMarker"||i==="open-marker"||i==="layout-marker"||i==="close-marker")return!1;const n=(e.markdown||e.content||"").trim();return!(/^\{\{\{(?:col|row)?\s*$/i.test(n)||n==="}}}")})}function na(t){if(!t)return!1;const e=(t.type||"").toLowerCase();if(e==="h"||e==="nodeheading"||/^h[1-6]$/i.test(t.subType||""))return!0;const i=(t.markdown||t.content||"").trim();return!!/^#{1,6}\s+/.test(i)}function Ci(t,e,i){let n="",o=0;const s=/<div\b([^>]*)>/gi;for(;o<t.length;){s.lastIndex=o;let l,r=!1,a=-1,c=0;for(;(l=s.exec(t))!==null;){const k=l[1].match(/\bclass=["']([^"']*)["']/i);if(k){const S=k[1];if(typeof e=="string"?S.split(/\s+/).includes(e):e.test(S)){r=!0,a=l.index,c=l[0].length;break}}}if(!r){n+=t.slice(o);break}n+=t.slice(o,a);const u=a+c;let m=1,g=-1,d=-1;const b=/<\/?div\b[^>]*>/gi;b.lastIndex=u;let f;for(;(f=b.exec(t))!==null;)if(f[0].startsWith("</")){if(m--,m===0){g=f.index,d=f.index+f[0].length;break}}else m++;if(g!==-1&&d!==-1){const v=t.slice(u,g);n+=i(v),o=d}else n+=t.slice(a,u),o=u}return n}function Ju(t){const e=[];let i="",n=0;const o=/<div\b([^>]*)>/gi;for(;n<t.length;){o.lastIndex=n;let s,l=!1,r=-1,a=0;for(;(s=o.exec(t))!==null;){const f=s[1];if(/(?:\s@[a-zA-Z0-9_-]+=\s*["']|\s:[a-zA-Z0-9_-]+=\s*["']|\sv-[a-zA-Z0-9_.-]+|\shover:[a-zA-Z0-9_.-]+=\s*["']|\sgrid=["']~|\bclass=["'][^"']*\b(?:abs-br|slidev-icon-btn|grid\s+|grid$|grid-cols-|relative\b)\b[^"']*["']|\bstyle=["'][^"']*\bgrid-[^"']*["'])/i.test(f)){l=!0,r=s.index,a=s[0].length;break}}if(!l){i+=t.slice(n);break}i+=t.slice(n,r);const c=r+a;let u=1,m=-1,g=-1;const d=/<\/?div\b[^>]*>/gi;d.lastIndex=c;let b;for(;(b=d.exec(t))!==null;)if(b[0].startsWith("</")){if(u--,u===0){m=b.index,g=b.index+b[0].length;break}}else u++;if(m!==-1&&g!==-1){const f=t.slice(r,g),v=`__VUE_DIV_TOKEN_${e.length}__`;e.push(f),i+=v,n=g}else i+=t.slice(r,c),n=c}return{text:i,tokens:e}}function Xu(t){const e=[];let i=t.replace(/(?:^[ \t]*(`{3,}|~{3,})[^\n\r]*\r?\n[\s\S]*?\r?\n[ \t]*\1(?=[ \t]*(?:\r?\n|$)))/gm,r=>{const a=`__CODE_TOKEN_${e.length}__`;return e.push(r),a});i=i.replace(/(`+)(?:[^\n\r`]|(?!\1)`)+?\1/g,r=>{const a=`__CODE_TOKEN_${e.length}__`;return e.push(r),a});const n=[];i=i.replace(/<script\b[^>]*>[\s\S]*?<\/script>/gi,r=>{const a=`__SCRIPT_TOKEN_${n.length}__`;return n.push(r),a});const{text:o,tokens:s}=Ju(i);i=o;const l=[];i=i.replace(/<(?:[A-Z][a-zA-Z0-9_-]*|[a-z0-9_-]+:[a-z0-9_-]+|v-[a-z0-9_-]+|arrow\b|div\s+h-\d+)\b[^>]*\/>/gi,r=>{const a=`__VUE_COMP_TOKEN_${l.length}__`;return l.push(r),a}),i=i.replace(/<(v-[a-z0-9_-]+|button)\b([^>]*)>([\s\S]*?)<\/\1>/gi,r=>{const a=`__VUE_COMP_TOKEN_${l.length}__`;return l.push(r),a}),i=i.replace(/<img\b[^>]*?\bv-[a-z0-9_.-]+[^>]*\/?>/gi,r=>{const a=`__VUE_COMP_TOKEN_${l.length}__`;return l.push(r),a}),i=i.replace(/<(p|span)\b([^>]*?\bv-[a-z0-9_.-]+[^>]*)>([\s\S]*?)<\/\1>/gi,r=>{const a=`__VUE_COMP_TOKEN_${l.length}__`;return l.push(r),a}),i=i.replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi,""),i=i.replace(/<div class="terminal-bar">[\s\S]*?<\/div>/gi,""),i=i.replace(/<div class="cursor-line">[\s\S]*?<\/div>/gi,""),i=i.replace(/<span class="cursor">[\s\S]*?<\/span>/gi,""),i=i.replace(/<div class="stamp">\s*([\s\S]*?)\s*<\/div>/gi,`

*[$1]*

`),i=i.replace(/<div class="arrow">\s*([→\->]+)\s*<\/div>/gi,`

$1

`),i=i.replace(/<i>\s*[→\->]+\s*<\/i>/gi,""),i=i.replace(/<div class="prompt">\s*([\s\S]*?)\s*<\/div>/gi,(r,a)=>`
\`\`\`bash
${a.trim()}
\`\`\`
`),i=i.replace(/<p>\s*<i>\$<\/i>\s*([\s\S]*?)<\/p>/gi,(r,a)=>`
\`\`\`bash
$ ${a.trim()}
\`\`\`
`),i=i.replace(/<div class="statusline">\s*([\s\S]*?)\s*<\/div>/gi,(r,a)=>`
> ${Array.from(a.matchAll(/<span>([\s\S]*?)<\/span>/gi)).map(u=>`\`${u[1].trim()}\``).join(" | ")}
`),i=i.replace(/<div class="log-panel">\s*<pre>([\s\S]*?)<\/pre>\s*<\/div>/gi,(r,a)=>`
\`\`\`log
${a.replace(/<span[^>]*>([\s\S]*?)<\/span>/gi,"$1").trim()}
\`\`\`
`),i=Ci(i,"diff-grid",r=>{const a=Array.from(r.matchAll(/<div class="diff\s+([^"]*)">\s*<span>(.*?)<\/span>\s*<pre>([\s\S]*?)<\/pre>\s*<\/div>/gi));return a.length>0?`
`+a.map(c=>{const u=c[2].trim().toUpperCase(),m=c[3].trim();return`**${u}:**
\`\`\`yaml
${m}
\`\`\``}).join(`

`)+`
`:r}),i=Ci(i,"before-after",r=>{const a=r.match(/<div class="before">[\s\S]*?<small>(.*?)<\/small>[\s\S]*?<h2>(.*?)<\/h2>[\s\S]*?<p>(.*?)<\/p>\s*<\/div>/i),c=r.match(/<div class="after">[\s\S]*?<small>(.*?)<\/small>[\s\S]*?<h2>(.*?)<\/h2>[\s\S]*?<p>(.*?)<\/p>\s*<\/div>/i);let u=`
`;return a&&(u+=`### ${a[1]}
## ${a[2]}
${a[3]}

`),c&&(u+=`### ${c[1]}
## ${c[2]}
${c[3]}
`),u.trim()?u:r}),i=i.replace(/<ul\b[^>]*>([\s\S]*?)<\/ul>/gi,(r,a)=>{const c=Array.from(a.matchAll(/<li>\s*(?:<em>)?(\[[x ]\])(?:<\/em>)?\s*([\s\S]*?)<\/li>/gi));return c.length>0?`
`+c.map(u=>`- ${u[1]} ${u[2].trim()}`).join(`
`)+`
`:a}),i=Ci(i,"timeline",r=>{const a=Array.from(r.matchAll(/<div(?:\s+class="([^"]*)")?>\s*<time>([\s\S]*?)<\/time>\s*<b>([\s\S]*?)<\/b>\s*<span>([\s\S]*?)<\/span>\s*<\/div>/gi));return a.length>0?`

`+a.map(c=>{const u=c[1]||"";let m="-";return u.includes("warn")?m="- ⚠️":u.includes("bad")?m="- ❌":u.includes("ok")&&(m="- ✅"),`${m} **${c[2].trim()}** **${c[3].trim()}** — ${c[4].trim()}`}).join(`
`)+`

`:r}),i=Ci(i,"pipeline",r=>{const a=Array.from(r.matchAll(/<div(?:\s+class="([^"]*)")?>\s*<small>([\s\S]*?)<\/small>\s*<b>([\s\S]*?)<\/b>\s*<span>([\s\S]*?)<\/span>\s*<\/div>/gi));return a.length>0?`

`+a.map((c,u)=>{const g=(c[1]||"").includes("hot")?"⚠️ ":"";return`${u+1}. ${g}**${c[3].trim()}** (*${c[4].trim()}*)`}).join(`
`)+`

`:r}),i=Ci(i,"check-grid",r=>{const a=Array.from(r.matchAll(/<div>\s*<span class="([^"]*)"><\/span>\s*<b>([\s\S]*?)<\/b>\s*<p>([\s\S]*?)<\/p>\s*<\/div>/gi));return a.length>0?`

`+a.map(c=>`- ${(c[1]||"").includes("warn")?"⚠️":"✅"} **${c[2].trim()}**: ${c[3].trim()}`).join(`
`)+`

`:r}),i=Ci(i,"manifesto",r=>{const a=Array.from(r.matchAll(/<div>\s*<span>([\s\S]*?)<\/span>\s*<h2>([\s\S]*?)<\/h2>\s*<p>([\s\S]*?)<\/p>\s*<\/div>/gi));return a.length>0?`

`+a.map(c=>`## ${c[1].trim()} ${c[2].trim()}

${c[3].trim()}`).join(`

`)+`

`:r}),i=Ci(i,"split-note",r=>{const a=Array.from(r.matchAll(/<div>\s*<b>([\s\S]*?)<\/b>\s*<p>([\s\S]*?)<\/p>\s*<\/div>/gi));return a.length>0?`

`+a.map(c=>`> **${c[1].trim()}**: ${c[2].trim()}`).join(`
>
`)+`

`:r}),i=i.replace(/<div class="mechanism">\s*<b>([\s\S]*?)<\/b>\s*<p>([\s\S]*?)<\/p>\s*<\/div>/gi,(r,a,c)=>`

> **${a.trim()}**: ${c.trim()}

`),i=i.replace(/<pre>([\s\S]*?)<\/pre>/gi,(r,a)=>`
\`\`\`text
${a.replace(/<span[^>]*>([\s\S]*?)<\/span>/gi,"$1").trim()}
\`\`\`
`),i=i.replace(/<div class="page-head">\s*<span>([\s\S]*?)<\/span>\s*<b>([\s\S]*?)<\/b>\s*<\/div>/gi,`
### $1 ($2)
`),i=i.replace(/<h1\b[^>]*>([\s\S]*?)<\/h1>/gi,`
# $1
`),i=i.replace(/<h2\b[^>]*>([\s\S]*?)<\/h2>/gi,`
## $1
`),i=i.replace(/<h3\b[^>]*>([\s\S]*?)<\/h3>/gi,`
### $1
`),i=i.replace(/<h4\b[^>]*>([\s\S]*?)<\/h4>/gi,`
#### $1
`),i=i.replace(/<p\s+class="ok">\s*●\s*([\s\S]*?)<\/p>/gi,`
✅ **$1**
`),i=i.replace(/<p\s+class="caption">\s*([\s\S]*?)<\/p>/gi,`
> *$1*
`),i=i.replace(/<p\s+class="lead">\s*([\s\S]*?)<\/p>/gi,`
*$1*
`),i=i.replace(/<p\b([^>]*)>([\s\S]*?)<\/p>/gi,(r,a,c)=>/@|v-|:|class=/i.test(a)?r:`
${c.trim()}

`),i=i.replace(/<br\s*\/?>/gi,`
`),i=i.replace(/<hr\s*\/?>/gi,`
---
`),i=i.replace(/<b\b[^>]*>([\s\S]*?)<\/b>/gi,"**$1**"),i=i.replace(/<strong\b[^>]*>([\s\S]*?)<\/strong>/gi,"**$1**"),i=i.replace(/<i\b[^>]*>([\s\S]*?)<\/i>/gi,"*$1*"),i=i.replace(/<code\b[^>]*>([\s\S]*?)<\/code>/gi,(r,a)=>{if(a.startsWith("`")&&a.endsWith("`"))return a;if(a.includes("`")){const c=(a.match(/`+/g)||[]).reduce((m,g)=>Math.max(m,g.length),0),u="`".repeat(c+1);return`${u} ${a} ${u}`}return`\`${a}\``}),i=i.replace(/<small\b[^>]*>([\s\S]*?)<\/small>/gi,"*$1*"),i=i.replace(/\*{4}/g,"** **"),i=i.replace(/<li\b[^>]*>([\s\S]*?)<\/li>/gi,`- $1
`),i=i.replace(/<ul\b[^>]*>([\s\S]*?)<\/ul>/gi,`
$1
`),i=i.replace(/<ol\b[^>]*>([\s\S]*?)<\/ol>/gi,`
$1
`),i=i.replace(/<a\b([^>]*)href=["'](.*?)["']([^>]*)>([\s\S]*?)<\/a>/gi,(r,a,c,u,m)=>{const g=m.trim();return g.includes("<")||g.includes(`
`)?r:`[${g}](${c})`}),i=i.replace(/<blockquote\b[^>]*>([\s\S]*?)<\/blockquote>/gi,(r,a)=>`
`+a.trim().split(`
`).map(c=>`> ${c.trim()}`).join(`
`)+`
`),i=i.replace(/<span\b[^>]*data-type=["']block-ref["'][^>]*data-id=["']([0-9a-zA-Z-]+)["'][^>]*>([\s\S]*?)<\/span>/gi,(r,a,c)=>{const u=c.replace(/<[^>]+>/g,"").trim();return u?`((${a} '${u}'))`:`((${a}))`}),i=i.replace(/<span\b[^>]*data-type=["']a["'][^>]*data-href=["']([^"']+)["'][^>]*>([\s\S]*?)<\/span>/gi,(r,a,c)=>`[${c.replace(/<[^>]+>/g,"").trim()}](${a})`),i=i.replace(/<\/(?:div|section|header|footer|main|article|nav|aside)\b[^>]*>/gi,`
`),i=i.replace(/<(?:div|section|header|footer|main|article|nav|aside)\b[^>]*>/gi,""),i=i.replace(/<\/?span\b[^>]*>/gi,"");for(let r=0;r<l.length;r++)i=i.replace(`__VUE_COMP_TOKEN_${r}__`,l[r]);for(let r=0;r<s.length;r++)i=i.replace(`__VUE_DIV_TOKEN_${r}__`,s[r]);for(let r=0;r<n.length;r++)i=i.replace(`__SCRIPT_TOKEN_${r}__`,n[r]);for(let r=0;r<e.length;r++)i=i.replace(`__CODE_TOKEN_${r}__`,e[r]);return i=i.replace(/\n{3,}/g,`

`).trim(),i}function oa(t){if(!t||typeof t!="string")return"";const e=[];let i=t.replace(/`([^`]+)`/g,n=>(e.push(n),`%%INLINE_CODE_${e.length-1}%%`));return i=i.replace(/(<\/[a-zA-Z0-9_-]+>)\s*\{:[^}]*\}/g,"$1"),i=i.replace(/(\[[^\]]+\]\([^)]+\))\s*\{:\s*style=["']([^"']*)["'][^}]*\}/g,'<span style="$2">$1</span>'),i=i.replace(/(\*\*[^*]+\*\*)\s*\{:\s*style=["']([^"']*)["'][^}]*\}/g,'<span style="$2">$1</span>'),i=i.replace(/(\*[^*]+\*)\s*\{:\s*style=["']([^"']*)["'][^}]*\}/g,'<span style="$2">$1</span>'),i=i.replace(/(~~[^~]+~~)\s*\{:\s*style=["']([^"']*)["'][^}]*\}/g,'<span style="$2">$1</span>'),i=i.replace(/([\p{L}\p{N}_\-]+)\s*\{:\s*style=["']([^"']*)["'][^}]*\}/gu,'<span style="$2">$1</span>'),i=i.replace(/\{:[^}]*\}/g,""),i=i.replace(/%%INLINE_CODE_(\d+)%%/g,(n,o)=>e[parseInt(o,10)]||""),i}function Qu(t){const e=Object.entries(t).filter(([n,o])=>o!=null&&o!=="");return e.length===0?"":`---
${e.map(([n,o])=>typeof o=="string"?o.includes(":")||o.includes(`
`)||o.includes("#")?`${n}: "${o.replace(/"/g,'\\"')}"`:`${n}: ${o}`:`${n}: ${JSON.stringify(o)}`).join(`
`)}
---`}function tf(t,e){if(!e||!t.startsWith("```"))return t;const i=t.indexOf(`
`);if(i===-1)return t;const n=t.slice(0,i).trim(),o=t.slice(i);return n.includes("{")?t:`${n} {${e}}${o}`}function sa(t,e){if(e==null)return t;const i=e.trim();return i===""||i==="+1"?`<v-click>

${t}

</v-click>`:i==="hide"?`<v-click hide>

${t}

</v-click>`:`<v-click at="${i}">

${t}

</v-click>`}function ef(t){if(!t||!t.preset)return null;const e=t.preset.toLowerCase().trim();if(!e||e==="none")return null;let i={opacity:0},n={opacity:1};switch(e){case"slide-up":i={y:40,opacity:0},n={y:0,opacity:1};break;case"slide-down":i={y:-40,opacity:0},n={y:0,opacity:1};break;case"slide-left":i={x:40,opacity:0},n={x:0,opacity:1};break;case"slide-right":i={x:-40,opacity:0},n={x:0,opacity:1};break;case"zoom-in":case"pop":i={scale:.8,opacity:0},n={scale:1,opacity:1};break;case"bounce":i={y:40,opacity:0},n={y:0,opacity:1,transition:{type:"spring",damping:10,stiffness:100}};break;case"fade-in":default:i={opacity:0},n={opacity:1};break}t.initial&&typeof t.initial=="object"&&(i={...i,...t.initial}),t.enter&&typeof t.enter=="object"&&(n={...n,...t.enter});const o={...n.transition||{}};return typeof t.duration=="number"&&t.duration>0&&(o.duration=t.duration),typeof t.delay=="number"&&t.delay>0&&(o.delay=t.delay),Object.keys(o).length>0&&(n.transition=o),{initial:i,enter:n}}function Gn(t,e,i,n){const o=e!=null&&e.trim()!=="",s=ef(i),l=n==null?void 0:n.trim(),r=l!==void 0&&l!=="",a=r?` style="${l.replace(/"/g,"&quot;")}" class="slide-styled-block"`:"";if(!o&&!s)return r?`<div${a}>

${t}

</div>`:t;if(o&&!s){if(r){const b=e.trim();let f="v-click";return b==="hide"?f="v-click.hide":b!==""&&b!=="+1"&&(f=`v-click="${b}"`),`<div ${f}${a}>

${t}

</div>`}return sa(t,e)}const c=JSON.stringify(s.initial).replace(/"/g,"'"),u=JSON.stringify(s.enter).replace(/"/g,"'"),m=`v-motion :initial="${c}" :enter="${u}"`;if(!o)return`<div ${m}${a}>

${t}

</div>`;const g=e.trim();let d="v-click";return g==="hide"?d="v-click.hide":g!==""&&g!=="+1"&&(d=`v-click="${g}"`),`<div ${d} ${m}${a}>

${t}

</div>`}function ra(t){if(!t)return"";let e=t.trim();e=e.replace(/\{:[^}]*\}/g,"").trim(),e=e.replace(/^:::\s*[a-zA-Z0-9_-]*\s*\r?\n?/g,""),e=e.replace(/\r?\n?:::\s*$/g,"");let o=e.split(/\r?\n/).map(s=>s.trim().replace(/^>\s*/,"")).join(`
`).trim();return o=o.replace(/^\[!(?:NOTE|TIP|IMPORTANT|WARNING|CAUTION|[A-Za-z_-]+)\][^\r\n]*(?:\r?\n)?/i,"").trim(),o=o.replace(/^(?:💡|✏️|❗|⚠️|🚨|\s*)*(?:\*\*|__)?(?:演讲备注|演讲者提词|讲稿备注|演讲提词|备注|Notes?)(?:\*\*|__)?[:：]?\s*(?:\r?\n)?/i,"").trim(),o=o.replace(/^[-*+]\s+/,""),o=o.replace(/^\d+\.\s+/,""),o.trim()}function nf(t){var n;if(t.subType&&/^h([1-6])$/i.test(t.subType))return parseInt(t.subType.slice(1),10);const i=(t.markdown||t.content||"").trim().match(/^(#{1,6})\s+/);return i?i[1].length:t.type==="h"?(n=t.ial)!=null&&n.subType&&/^h([1-6])$/i.test(t.ial.subType)?parseInt(t.ial.subType.slice(1),10):1:null}function la(t,e=2){const i=Math.max(2,e);if(!t||t.length===0)return Array.from({length:i},()=>[]);if(t.length===1&&t[0].children&&t[0].children.length>=2){const c=t[0].children,u=Array.from({length:i},()=>[]),m=Math.min(i,c.length),g=Math.floor(c.length/m),d=c.length%m;let b=0;for(let f=0;f<m;f++){const v=g+(f<d?1:0);u[f]=c.slice(b,b+v),b+=v}return u}const n=c=>{const u=(c.slot||"").trim();if(!u)return null;if(u==="left")return 1;if(u==="center")return 2;if(u==="right")return i===2?2:i;const m=u.match(/^col-(\d+)$/i);if(m){const g=parseInt(m[1],10);if(g>=1&&g<=i)return g}return null},o=t.map(n);if(o.some(c=>c!==null)){if(o.some(d=>d!==null&&d>=2)){const d=Array.from({length:i},()=>[]);let b=1;for(const f of t){const v=n(f);v!==null&&(b=v),d[b-1].push(f)}return d}const u=t.filter(d=>n(d)===1),m=t.filter(d=>n(d)===null),g=i-1;if(m.length>=g){const d=Math.floor(m.length/g),b=m.length%g,f=[u];let v=0;for(let k=0;k<g;k++){const S=d+(k<b?1:0);f.push(m.slice(v,v+S)),v+=S}return f}else if(m.length>0){const d=[u];for(let b=0;b<g;b++)d.push(b<m.length?[m[b]]:[]);return d}else return[u,...Array.from({length:g},()=>[])]}const l=c=>{if(c.type==="h"||c.subType&&/^h[1-6]$/i.test(c.subType))return!0;const u=(c.rawMarkdown||c.content||"").trim();return/^#{1,6}\s+/.test(u)},r=t.map((c,u)=>l(c)?u:-1).filter(c=>c!==-1);if(r.length>=i){const c=Array.from({length:i},()=>[]);for(let u=0;u<i;u++){const m=r[u],g=u+1<i?r[u+1]:t.length;c[u]=t.slice(m,g)}return c}if(t.length>=i){const c=Array.from({length:i},()=>[]);let u=0;for(let m=0;m<i;m++){const g=i-m,d=t.length-u,b=Math.ceil(d/g);c[m]=t.slice(u,u+b),u+=b}return c}if(t.length>1&&t.length<i){const c=Array.from({length:i},()=>[]);for(let u=0;u<t.length;u++)c[u]=[t[u]];return c}if(t.length===1){const c=t[0],u=(c.rawMarkdown||c.content||"").trim(),m=u.split(/\r?\n/),g=[];for(let f=0;f<m.length;f++)/^[ \t]*[-*+]\s+|^[ \t]*\d+\.\s+/.test(m[f])&&g.push(f);if(g.length>=i){const f=Array.from({length:i},()=>[]);let v=0;for(let k=0;k<i;k++){const S=i-k,x=g.length-v,B=Math.ceil(x/S),E=g[v],A=v+B<g.length?g[v+B]:m.length,w=m.slice(E,A).join(`
`);f[k]=[{...c,id:k===0?c.id:`${c.id}-col${k+1}`,rawMarkdown:w,content:w}],v+=B}return f}const d=u.match(/<li[\s\S]*?<\/li>/gi);if(d&&d.length>=i){const f=Array.from({length:i},()=>[]);let v=0;for(let k=0;k<i;k++){const S=i-k,x=d.length-v,B=Math.ceil(x/S),E=`<ul>
${d.slice(v,v+B).join(`
`)}
</ul>`;f[k]=[{...c,id:k===0?c.id:`${c.id}-col${k+1}`,rawMarkdown:E,content:E}],v+=B}return f}const b=u.split(/\r?\n\s*\r?\n/).filter(f=>f.trim()!=="");if(b.length>=i){const f=Array.from({length:i},()=>[]);let v=0;for(let k=0;k<i;k++){const S=i-k,x=b.length-v,B=Math.ceil(x/S),E=b.slice(v,v+B).join(`

`);f[k]=[{...c,id:k===0?c.id:`${c.id}-col${k+1}`,rawMarkdown:E,content:E}],v+=B}return f}}const a=Array.from({length:i},()=>[]);return a[0]=t,a}function Br(t,e,i,n){var u;const o=Uu(e),s=[],l=Ar(e);let r={pageIndex:1,startBlockId:t,frontmatter:{layout:l.frontmatter.layout||"cover",...l.frontmatter},notes:"",noteBlocks:[],blocks:[],rawMarkdown:"",allBlockIds:[t]};r.frontmatter.background&&(r.frontmatter.background=Ie(r.frontmatter.background,n)),r.frontmatter.image&&(r.frontmatter.image=Ie(r.frontmatter.image,n)),s.push(r);let a=[];for(const m of i){if(bo(m)){a=[];const d=Ar(m.ial);if(s.length===1&&r.blocks.length===0){r.startBlockId=m.id,r.allBlockIds||(r.allBlockIds=[]),r.allBlockIds.includes(m.id)||r.allBlockIds.push(m.id),d.frontmatter.layout&&(r.frontmatter.layout=d.frontmatter.layout),Object.assign(r.frontmatter,d.frontmatter),!d.frontmatter.image&&l.frontmatter.image&&(r.frontmatter.image=l.frontmatter.image),!d.frontmatter.background&&l.frontmatter.background&&(r.frontmatter.background=l.frontmatter.background),r.frontmatter.background&&(r.frontmatter.background=Ie(r.frontmatter.background,n)),r.frontmatter.image&&(r.frontmatter.image=Ie(r.frontmatter.image,n));continue}r={pageIndex:s.length+1,startBlockId:m.id,frontmatter:{layout:d.frontmatter.layout||"default",...d.frontmatter},notes:"",noteBlocks:[],blocks:[],rawMarkdown:"",allBlockIds:[m.id]},r.frontmatter.background&&(r.frontmatter.background=Ie(r.frontmatter.background,n)),r.frontmatter.image&&(r.frontmatter.image=Ie(r.frontmatter.image,n)),s.push(r);continue}const g=(d,b)=>{var X,R,U,W;if(r.allBlockIds||(r.allBlockIds=[]),d.id&&!r.allBlockIds.includes(d.id)&&r.allBlockIds.push(d.id),d.children&&d.children.length>0){const tt=T=>{for(const M of T)M.id&&!r.allBlockIds.includes(M.id)&&r.allBlockIds.push(M.id),M.children&&M.children.length>0&&tt(M.children)};tt(d.children)}let f=pc(d),v=d.ial?{...d.ial}:{};const k=f.match(/\{:\s*([^}]+)\s*\}\s*$/);k&&(v={...hc(k[0]),...v},f=f.slice(0,k.index).trim()),d.type!=="c"&&!f.startsWith("```")&&(f=oa(f));let S=f.trim();if(/^\{\{\{(?:row|col)?\s*$/i.test(S)||S==="}}}")return;/^\{\{\{(?:row|col)?\s*\r?\n/i.test(S)&&/\r?\n\}\}\}$/.test(S)&&(f=S.replace(/^\{\{\{(?:row|col)?\s*\r?\n/i,"").replace(/\r?\n\}\}\}$/,"").trim(),S=f.trim());const x=Wu(v);if(f=mc(f,n),f=fc(f,n==null?void 0:n.refContentMap),d.children&&d.children.length>0){const tt=["custom-slidev-autoplay","custom-slidev-loop","custom-slidev-muted","custom-slidev-controls"],T=M=>{for(const Y of M){if(Y.ial)for(const[Z,Q]of Object.entries(Y.ial))tt.includes(Z)&&!v[Z]&&(v[Z]=Q);Y.children&&Y.children.length>0&&T(Y.children)}};T(d.children)}const B=d.type==="video"||d.type==="NodeVideo"||/<video\b/i.test(f);if(B){const tt=v["custom-slidev-autoplay"]==="true",T=v["custom-slidev-loop"]==="true",M=v["custom-slidev-muted"]==="true"||tt,Y=v["custom-slidev-controls"]==="false";f=f.replace(/<video\b([^>]*)>/gi,(Z,Q)=>{let P=Q;return Y?P=P.replace(/\bcontrols(?:="[^"]*")?/gi,"").trim():/controls/i.test(P)||(P+=" controls"),tt&&!/autoplay/i.test(P)?P+=" autoplay playsinline":!tt&&v["custom-slidev-autoplay"]==="false"&&(P=P.replace(/\bautoplay\b/gi,"").replace(/\bplaysinline\b/gi,"").trim()),T&&!/loop/i.test(P)?P+=" loop":!T&&v["custom-slidev-loop"]==="false"&&(P=P.replace(/\bloop\b/gi,"").trim()),M&&!/muted/i.test(P)?P+=" muted":!M&&v["custom-slidev-muted"]==="false"&&(P=P.replace(/\bmuted\b/gi,"").trim()),`<video ${P.trim()}>`})}if(x.isBackground){const tt=bi(f,d.content);if(tt){r.frontmatter.background=Ie(tt,n);return}}const E=ci(d);if(E){r.frontmatter.layout=E.layout,r.frontmatter.image=Ie(E.imageUrl,n),!r.frontmatter.layoutRatio&&E.ratio&&(r.frontmatter.layoutRatio=E.ratio);for(const tt of E.contentNodes)g(tt);return}if(x.imageLayout==="image-left"||x.imageLayout==="image-right"){const tt=bi(f,d.content);if(tt){r.frontmatter.layout=x.imageLayout,r.frontmatter.image=Ie(tt,n),!r.frontmatter.layoutRatio&&((X=d.ial)!=null&&X[le])&&(r.frontmatter.layoutRatio=d.ial[le]);return}}if(oe(d)&&d.children&&d.children.length>0){for(const tt of d.children)g(tt);return}const A=!!(x.slot||b!=null&&b.defaultSlot||r.frontmatter.layout==="clover"||$n(r.frontmatter.layout)||r.frontmatter.layout==="two-cols");if((d.type==="l"||d.type==="NodeList"||d.type==="list")&&d.children&&d.children.length>0&&(d.children.some(tt=>{var T,M;return((T=tt.ial)==null?void 0:T[Ct])||((M=tt.ial)==null?void 0:M[jt])})||x.slot||x.clicks||A)){for(const tt of d.children)x.slot&&(!tt.ial||!tt.ial[Ct])&&(tt.ial||(tt.ial={}),tt.ial[Ct]=x.slot),g(tt,{...b,parentClicks:x.clicks||(b==null?void 0:b.parentClicks),defaultSlot:x.slot||(b==null?void 0:b.defaultSlot)});return}const w=!!(d.children&&d.children.length>=2)||!!x.clicks||!!((R=d.children)!=null&&R.some(tt=>{var T;return(T=tt.ial)==null?void 0:T[jt]}))||!d.markdown&&!!(d.children&&d.children.length>0);if(Ri(d)&&d.children&&d.children.length>0&&(A||x.clicks||d.children.some(tt=>{var T;return(T=tt.ial)==null?void 0:T[jt]}))&&w){const tt=!!(d.children&&d.children.length>=2),T=d.children.find(rt=>!!(rt.markdown||rt.content||"").trim())||d.children[0],M=((U=T==null?void 0:T.ial)==null?void 0:U[jt])||((W=T==null?void 0:T.ial)==null?void 0:W["custom-slidev-click"]),Y=!!(!x.clicks&&tt&&M),Z=x.clicks||(Y?M:void 0)||(b==null?void 0:b.parentClicks),Q=d.id||(b==null?void 0:b.parentContainerId),P=x.slot||(b==null?void 0:b.defaultSlot);let ct=!0;for(const rt of d.children){P&&(!rt.ial||!rt.ial[Ct])&&(rt.ial||(rt.ial={}),rt.ial[Ct]=P);const st=!!(rt.markdown||rt.content||"").trim(),gt=ct&&st;gt&&(rt.markdown&&(rt.markdown=bn(rt.markdown)),rt.content&&(rt.content=bn(rt.content)),ct=!1);let mt=rt;gt&&Z&&tt&&(mt={...rt,ial:{...rt.ial||{}}},delete mt.ial[jt],delete mt.ial["custom-slidev-click"]),g(mt,{parentClicks:Z,parentContainerId:Q,defaultSlot:P})}return}if(x.isNote){const tt=ra(f);tt&&(r.notes?r.notes+=`

`+tt:r.notes=tt),r.noteBlocks||(r.noteBlocks=[]),r.noteBlocks.push({id:d.id,type:d.type,content:tt||d.content||"",rawMarkdown:f,isNote:!0,attributes:d.ial});return}x.shikiLines&&(f=tf(f,x.shikiLines)),S=f.trim();const F=(d.content||"").trim();if(S==="::right::"||F==="::right::"||/^<p>\s*::right::\s*<\/p>$/i.test(S)||S.startsWith("::right::")){r.blocks.push({id:d.id,type:d.type,content:"::right::",rawMarkdown:"::right::",slot:"slot-divider-right",attributes:d.ial});return}const j=nf(d);let J=x.slot,I=x.clicks,N=x.motion,y={...d.ial||{}};if(j!==null){for(;a.length>0&&a[a.length-1].level>=j;)a.pop();const tt=a.length>0?a[a.length-1]:void 0;!J&&(tt!=null&&tt.slot)&&(J=tt.slot),!I&&(tt!=null&&tt.clicks)&&!(b!=null&&b.parentContainerId)&&(I=tt.clicks),!N&&(tt!=null&&tt.motion)&&(N=tt.motion);const T={...(tt==null?void 0:tt.customAttrs)||{}};if(d.ial)for(const[M,Y]of Object.entries(d.ial))M.startsWith("custom-slidev-")&&!M.startsWith("custom-slidev-slide")&&(T[M]=Y);b!=null&&b.parentContainerId||a.push({level:j,slot:J,clicks:I,motion:N,customAttrs:T})}else{const tt=a.length>0?a[a.length-1]:void 0;tt&&(!J&&tt.slot&&tt.slot!=="header"&&(J=tt.slot),!I&&tt.clicks&&!(b!=null&&b.parentContainerId)&&(I=tt.clicks),!N&&tt.motion&&(N=tt.motion),tt.customAttrs&&(y={...tt.customAttrs,...y}))}!J&&r.blocks.some(tt=>tt.slot==="slot-divider-right")&&(J="right"),!J&&(b!=null&&b.defaultSlot)&&(J=b.defaultSlot),J&&(y[Ct]=J),I&&!y[jt]&&(y[jt]=I),N&&!y[Ve]&&(y[Ve]=JSON.stringify(N)),(B||v["custom-slidev-autoplay"]||v["custom-slidev-muted"])&&(v["custom-slidev-autoplay"]&&(y["custom-slidev-autoplay"]=v["custom-slidev-autoplay"],v["custom-slidev-autoplay"]==="true"&&!v["custom-slidev-muted"]&&(y["custom-slidev-muted"]="true")),v["custom-slidev-loop"]&&(y["custom-slidev-loop"]=v["custom-slidev-loop"]),v["custom-slidev-muted"]&&(y["custom-slidev-muted"]=v["custom-slidev-muted"]),v["custom-slidev-controls"]&&(y["custom-slidev-controls"]=v["custom-slidev-controls"]));const V={id:d.id,type:d.type,content:d.content||"",rawMarkdown:f,clicks:I,parentClicks:b==null?void 0:b.parentClicks,parentContainerId:b==null?void 0:b.parentContainerId,motion:N,shikiLines:x.shikiLines,slot:J,attributes:y,rawNode:d};r.blocks.push(V)};g(m)}for(let m=0;m<s.length;m++){const g=s[m],d=[],b={...g.frontmatter};m===0&&(b.theme=o.theme,b.aspectRatio=o.aspectRatio,b.highlighter=o.highlighter,b.transition=g.frontmatter.transition||o.defaultTransition);const f=Qu(b);f&&d.push(f);const v=g.blocks.filter(E=>E.slot!=="slot-divider-right"),k=E=>E.filter(A=>!!(A.rawMarkdown||A.content||"").trim()).map(A=>{var w;return Gn(A.rawMarkdown,A.clicks,A.motion,(w=A.attributes)==null?void 0:w.style)}).join(`

`),S=E=>{const A=E.filter(j=>!!(j.rawMarkdown||j.content||"").trim());if(A.length===0)return;const w=A[0],F=(w.rawMarkdown||w.content||"").trim();(Ri(w)||/^(?:[-*+]|\d+\.)\s+/.test(F))&&(w.rawMarkdown=bn(w.rawMarkdown||w.content||""),w.content=w.rawMarkdown)},x=E=>{var j,J;if(E.length===0)return"";S(E);const A=(j=E.find(I=>I.parentClicks))==null?void 0:j.parentClicks;if(!A)return E.filter(I=>!!(I.rawMarkdown||I.content||"").trim()).map(I=>{var N;return Gn(I.rawMarkdown,I.clicks,I.motion,(N=I.attributes)==null?void 0:N.style)}).join(`

`);const w=[];let F=[];const H=()=>{if(F.length===0)return;const I=F.map(N=>(N.rawMarkdown||N.content||"").trim()).filter(Boolean).join(`

`);I&&w.push(sa(I,A)),F=[]};for(const I of E){if(!(I.rawMarkdown||I.content||"").trim())continue;!!(I.clicks&&I.clicks.trim()!=="")?(H(),w.push(Gn(I.rawMarkdown,I.clicks,I.motion,(J=I.attributes)==null?void 0:J.style))):F.push(I)}return H(),w.join(`

`)},B=g.frontmatter.layout||"default";if(B==="clover"||$n(B)){let E=[];const A=v.filter(I=>I.slot==="header");if(A.length>0)E=A;else if(v.length>0){const I=v.find(N=>N.type==="h"&&(!N.slot||N.slot==="default"));I&&(E=[I])}const w=v.filter(I=>!E.includes(I));let F=2;if(B==="clover")F=4;else if(B==="three-cols-header")F=3;else if(B==="two-cols-header")F=2;else{let I=0;for(const N of w){const y=(N.slot||"").match(/^col-(\d+)$/i);y&&(I=Math.max(I,parseInt(y[1],10)))}if(I>=2)F=I;else if(g.frontmatter.layoutRatio){const N=g.frontmatter.layoutRatio.trim();if(N.includes(":")){const y=N.split(":").map(V=>parseFloat(V.trim())).filter(V=>!isNaN(V)&&V>0);y.length>=2&&(F=y.length)}else{const y=N.split(/\s+/).filter(Boolean);y.length>=2&&(F=y.length)}}else w.length===1&&w[0].children&&w[0].children.length>=2&&(F=Math.min(6,w[0].children.length))}const H=la(w,F);H.forEach((I,N)=>{const y=`col-${N+1}`;for(const V of I)(!V.slot||V.slot==="default")&&(V.slot=y);S(I)});const j=H.flat();if(w.length===1&&j.length>1){const I=g.blocks.findIndex(N=>N.id===w[0].id);I!==-1&&g.blocks.splice(I,1,...j)}const J=k(E);if(J&&d.push(J),B==="two-cols-header"&&F===2){const I=x(H[0]||[]),N=x(H[1]||[]);I&&d.push(`::left::

${I}`),N&&d.push(`::right::

${N}`)}else H.forEach((I,N)=>{const y=x(I);y&&d.push(`::col-${N+1}::

${y}`)})}else if(B==="two-cols"){const E=v.filter(H=>H.slot==="left"),A=v.filter(H=>H.slot==="right");S(E),S(A);const w=k(E.length>0?E:v.filter(H=>H.slot!=="right")),F=k(A);d.push(w),F&&d.push(`::right::

${F}`)}else for(const E of v)d.push(Gn(E.rawMarkdown,E.clicks,E.motion,(u=E.attributes)==null?void 0:u.style));g.notes&&d.push(`<!--
${g.notes}
-->`),g.rawMarkdown=d.join(`

`).trim()}const c=s.map(m=>m.rawMarkdown).filter(Boolean).join(`

---

`);return{docId:t,config:o,slides:s,fullMarkdown:c}}const ps=`/* SiYuan Note Built-in Font & Background Styles for Slidev */
:root,
html:not(.dark),
[data-theme="light"],
[data-theme-mode="light"] {
  /* 思源基础卡片与主题色 (浅色模式 daylight) */
  --b3-card-error-color: #790600;
  --b3-card-error-background: #f5d1cf;
  --b3-card-warning-color: #8a4f00;
  --b3-card-warning-background: #ffe8c8;
  --b3-card-info-color: #005599;
  --b3-card-info-background: #d6eaf9;
  --b3-card-success-color: #006b04;
  --b3-card-success-background: #d7eed8;

  --b3-theme-primary: #3575f0;
  --b3-theme-secondary: #ff9200;
  --b3-theme-error: #d23f31;
  --b3-theme-background: #ffffff;
  --b3-theme-on-background: #222222;
  --b3-theme-on-surface: #5f6368;
  --b3-theme-surface-lighter: #e0e0e0;

  /* 13 种内置文字颜色 */
  --b3-font-color1: var(--b3-card-error-color);
  --b3-font-color2: var(--b3-card-warning-color);
  --b3-font-color3: var(--b3-card-info-color);
  --b3-font-color4: var(--b3-card-success-color);
  --b3-font-color5: var(--b3-theme-on-surface);
  --b3-font-color6: var(--b3-theme-primary);
  --b3-font-color7: var(--b3-theme-secondary);
  --b3-font-color8: var(--b3-theme-error);
  --b3-font-color9: #a40074;
  --b3-font-color10: #007080;
  --b3-font-color11: #006e2a;
  --b3-font-color12: #6b5a00;
  --b3-font-color13: var(--b3-theme-background);

  /* 13 种内置背景颜色 */
  --b3-font-background1: var(--b3-card-error-background);
  --b3-font-background2: var(--b3-card-warning-background);
  --b3-font-background3: var(--b3-card-info-background);
  --b3-font-background4: var(--b3-card-success-background);
  --b3-font-background5: #e2e3e4;
  --b3-font-background6: #acd0fc;
  --b3-font-background7: #fddaab;
  --b3-font-background8: #ffb0a9;
  --b3-font-background9: #fdbfff;
  --b3-font-background10: #b1ffff;
  --b3-font-background11: #affad1;
  --b3-font-background12: #fff88f;
  --b3-font-background13: var(--b3-theme-on-background);
}

html.dark,
[data-theme="dark"],
[data-theme-mode="dark"],
.theme-dark,
.dark {
  /* 思源基础卡片与主题色 (深色模式 midnight) */
  --b3-card-error-color: rgb(243, 153, 147);
  --b3-card-error-background: #442724;
  --b3-card-warning-color: rgb(255, 213, 153);
  --b3-card-warning-background: #554636;
  --b3-card-info-color: rgb(166, 213, 250);
  --b3-card-info-background: #28405c;
  --b3-card-success-color: rgb(183, 223, 185);
  --b3-card-success-background: #425347;

  --b3-theme-primary: #3575f0;
  --b3-theme-secondary: #ff9200;
  --b3-theme-error: #d23f31;
  --b3-theme-background: #1e1e1e;
  --b3-theme-on-background: #c8ccd6;
  --b3-theme-on-surface: #8b949e;
  --b3-theme-surface-lighter: #282a2e;

  /* 13 种内置文字颜色 */
  --b3-font-color1: var(--b3-card-error-color);
  --b3-font-color2: var(--b3-card-warning-color);
  --b3-font-color3: var(--b3-card-info-color);
  --b3-font-color4: var(--b3-card-success-color);
  --b3-font-color5: var(--b3-theme-on-surface);
  --b3-font-color6: var(--b3-theme-primary);
  --b3-font-color7: var(--b3-theme-secondary);
  --b3-font-color8: var(--b3-theme-error);
  --b3-font-color9: #f47c9c;
  --b3-font-color10: #4dd0e1;
  --b3-font-color11: #10df54;
  --b3-font-color12: #ecd424;
  --b3-font-color13: var(--b3-theme-background);

  /* 13 种内置背景颜色 */
  --b3-font-background1: var(--b3-card-error-background);
  --b3-font-background2: var(--b3-card-warning-background);
  --b3-font-background3: var(--b3-card-info-background);
  --b3-font-background4: var(--b3-card-success-background);
  --b3-font-background5: #3a3f42;
  --b3-font-background6: #031840;
  --b3-font-background7: #593905;
  --b3-font-background8: #3a0c09;
  --b3-font-background9: #4d1b40;
  --b3-font-background10: #1a5459;
  --b3-font-background11: #305415;
  --b3-font-background12: #4a4712;
  --b3-font-background13: var(--b3-theme-on-background);
}

@media (prefers-color-scheme: dark) {
  :root:not([data-theme="light"]):not([data-theme-mode="light"]):not(.light) {
    --b3-card-error-color: rgb(243, 153, 147);
    --b3-card-error-background: #442724;
    --b3-card-warning-color: rgb(255, 213, 153);
    --b3-card-warning-background: #554636;
    --b3-card-info-color: rgb(166, 213, 250);
    --b3-card-info-background: #28405c;
    --b3-card-success-color: rgb(183, 223, 185);
    --b3-card-success-background: #425347;

    --b3-theme-primary: #3575f0;
    --b3-theme-secondary: #ff9200;
    --b3-theme-error: #d23f31;
    --b3-theme-background: #1e1e1e;
    --b3-theme-on-background: #c8ccd6;
    --b3-theme-on-surface: #8b949e;
    --b3-theme-surface-lighter: #282a2e;

    --b3-font-color1: var(--b3-card-error-color);
    --b3-font-color2: var(--b3-card-warning-color);
    --b3-font-color3: var(--b3-card-info-color);
    --b3-font-color4: var(--b3-card-success-color);
    --b3-font-color5: var(--b3-theme-on-surface);
    --b3-font-color6: var(--b3-theme-primary);
    --b3-font-color7: var(--b3-theme-secondary);
    --b3-font-color8: var(--b3-theme-error);
    --b3-font-color9: #f47c9c;
    --b3-font-color10: #4dd0e1;
    --b3-font-color11: #10df54;
    --b3-font-color12: #ecd424;
    --b3-font-color13: var(--b3-theme-background);

    --b3-font-background1: var(--b3-card-error-background);
    --b3-font-background2: var(--b3-card-warning-background);
    --b3-font-background3: var(--b3-card-info-background);
    --b3-font-background4: var(--b3-card-success-background);
    --b3-font-background5: #3a3f42;
    --b3-font-background6: #031840;
    --b3-font-background7: #593905;
    --b3-font-background8: #3a0c09;
    --b3-font-background9: #4d1b40;
    --b3-font-background10: #1a5459;
    --b3-font-background11: #305415;
    --b3-font-background12: #4a4712;
    --b3-font-background13: var(--b3-theme-on-background);
  }
}

/* 演示块级样式排版增强 (带背景色时赋予呼吸内边距与舒适圆角) */
.slide-styled-block {
  border-radius: 6px;
  padding: 8px 14px;
  box-sizing: border-box;
  margin: 6px 0;
  transition: background-color 0.2s ease, color 0.2s ease;
}

/* 行内带背景色文本的精美圆角与微边距 */
span[style*="background-color"],
span[style*="background:"] {
  border-radius: 3px;
  padding: 1px 5px;
  box-decoration-break: clone;
  -webkit-box-decoration-break: clone;
}
`;function of(t){var o,s,l,r,a,c,u,m,g,d,b,f;if(!t||typeof t!="object")return"";const e=[],i=[];if(Array.isArray(t.styles))for(const v of t.styles){if(!v||!v.id)continue;const k=`--b3-inline-style-${v.id}`;(o=v.light)!=null&&o.color&&e.push(`  ${k}-color: ${v.light.color};`),(s=v.light)!=null&&s.backgroundColor&&e.push(`  ${k}-background-color: ${v.light.backgroundColor};`),(l=v.dark)!=null&&l.color&&i.push(`  ${k}-color: ${v.dark.color};`),(r=v.dark)!=null&&r.backgroundColor&&i.push(`  ${k}-background-color: ${v.dark.backgroundColor};`)}if(t.builtin&&Array.isArray(t.builtin.colors))for(const v of t.builtin.colors){if(!v||typeof v.index!="number")continue;const k=v.index;(a=v.light)!=null&&a.color&&e.push(`  --b3-font-color${k}: ${v.light.color};`),(c=v.light)!=null&&c.backgroundColor&&e.push(`  --b3-font-background${k}: ${v.light.backgroundColor};`),(u=v.dark)!=null&&u.color&&i.push(`  --b3-font-color${k}: ${v.dark.color};`),(m=v.dark)!=null&&m.backgroundColor&&i.push(`  --b3-font-background${k}: ${v.dark.backgroundColor};`)}if(t.builtin&&Array.isArray(t.builtin.styles))for(const v of t.builtin.styles){if(!v||!v.id)continue;const k=v.id;(g=v.light)!=null&&g.color&&e.push(`  --b3-card-${k}-color: ${v.light.color};`),(d=v.light)!=null&&d.backgroundColor&&e.push(`  --b3-card-${k}-background: ${v.light.backgroundColor};`),(b=v.dark)!=null&&b.color&&i.push(`  --b3-card-${k}-color: ${v.dark.color};`),(f=v.dark)!=null&&f.backgroundColor&&i.push(`  --b3-card-${k}-background: ${v.dark.backgroundColor};`)}if(e.length===0&&i.length===0)return"";const n=[];return e.length>0&&n.push(`:root, html:not(.dark), [data-theme="light"] {
${e.join(`
`)}
}`),i.length>0&&n.push(`html.dark, [data-theme="dark"], .dark {
${i.join(`
`)}
}`),n.join(`

`)}function kn(t){const e=of(t);return e?`${ps}

/* Custom Workspace Inline Styles */
${e}`:ps}function Ko(t){const e={};if(!t||typeof t!="string")return e;const i=t.replace(/^\{:\s*/,"").replace(/\s*\}$/,""),n=/([\w-]+)=(?:"([^"]*)"|'([^']*)'|(\S+))/g;let o;for(;(o=n.exec(i))!==null;){const s=o[1],l=o[2]??o[3]??o[4]??"";e[s]=l}return e}const sf={getBlockAttrs:Ye,getChildBlocks:no,setBlockAttrs:Et,sql:wn,getBaseUrl:()=>typeof location<"u"?location.origin:"",getInlineStyles:dc};class rf{constructor(e){xt(this,"deps");xt(this,"attrOverrides",new Map);xt(this,"trackedListSuperBlocks",new Map);this.deps={...sf,...e||{}}}setBlockAttrOverride(e,i){if(!e||!i)return;const o={...this.attrOverrides.get(e)||{}};for(const[s,l]of Object.entries(i))l===""||l===null||l===void 0?delete o[s]:o[s]=String(l);Object.keys(o).length===0?this.attrOverrides.delete(e):this.attrOverrides.set(e,o)}getBlockAttrOverride(e){return this.attrOverrides.get(e)}getAllAttrOverrides(){return new Map(this.attrOverrides)}getTrackedListSuperBlocks(e){return this.trackedListSuperBlocks.get(e)||[]}clearBlockAttrOverride(e,i){if(!e)return;if(!i){this.attrOverrides.delete(e);return}const n=this.attrOverrides.get(e);n&&(delete n[i],Object.keys(n).length===0&&this.attrOverrides.delete(e))}clearAllOverrides(){this.attrOverrides.clear(),this.trackedListSuperBlocks.clear()}async compile(e){try{const i=await this.deps.getBlockAttrs(e).catch(()=>({}))||{},n=this.attrOverrides.get(e);n&&Object.assign(i,n);let o=await this.deps.getChildBlocks(e).catch(()=>[]);const s=`SELECT id, ial FROM blocks WHERE root_id = '${e}' LIMIT 99999`,l=await this.deps.sql(s).catch(()=>[])||[],r=new Map;if(Array.isArray(l))for(const x of l)x.id&&x.ial&&r.set(x.id,Ko(x.ial));const a=`SELECT block_id, name, value FROM attributes WHERE root_id = '${e}' AND type = 'b' LIMIT 99999`,c=await this.deps.sql(a).catch(()=>[])||[];if(Array.isArray(c)){for(const x of c)if(x.block_id&&x.name){let B=r.get(x.block_id);B||(B={},r.set(x.block_id,B)),B[x.name]=x.value||""}}if(!o||o.length===0){const x=`SELECT id, parent_id, root_id, type, sub_type as subType, content, markdown, ial FROM blocks WHERE root_id = '${e}' AND id != '${e}' ORDER BY created ASC LIMIT 99999`;o=await this.deps.sql(x).catch(()=>[])||[]}const u=(o||[]).map(x=>{const B=r.get(x.id)||(x.ial?Ko(x.ial):{}),E=this.attrOverrides.get(x.id);return E&&Object.assign(B,E),{id:x.id,parent_id:x.parent_id,root_id:x.root_id||e,type:x.type,subType:x.subType,content:x.content||"",markdown:x.markdown||"",ial:B,children:x.children}}),m=async(x,B=0)=>{if(!(!x||x.length===0||B>8))for(const E of x){if((oe(E)||E.type==="l"||E.type==="NodeList"||E.type==="i"||E.type==="NodeListItem"||E.type==="b"||E.type==="NodeBlockquote")&&(!E.children||E.children.length===0)){let w=await this.deps.getChildBlocks(E.id).catch(()=>[]);if(!w||w.length===0){const F=`SELECT id, parent_id, root_id, type, sub_type as subType, content, markdown, ial FROM blocks WHERE parent_id = '${E.id}' ORDER BY sort ASC, created ASC`;w=await this.deps.sql(F).catch(()=>[])||[]}if(Array.isArray(w)&&w.length>0){const F=new Set(u.map(j=>j.id)),H=w.filter(j=>j.id!==E.id&&!F.has(j.id));H.length>0&&(E.children=H.map(j=>{const J=r.get(j.id)||(j.ial?Ko(j.ial):{}),I=this.attrOverrides.get(j.id);return I&&Object.assign(J,I),{id:j.id,parent_id:j.parent_id||E.id,root_id:j.root_id||e,type:j.type,subType:j.subType,content:j.content||"",markdown:j.markdown||"",ial:J}}))}}E.children&&E.children.length>0&&await m(E.children,B+1)}};await m(u);const g=x=>{var B,E;for(const A of x)if(A.children&&A.children.length>0){g(A.children);for(const w of A.children)if(w.ial)for(const[F,H]of Object.entries(w.ial))F.startsWith("custom-slidev-")&&!((B=A.ial)!=null&&B[F])&&(A.ial||(A.ial={}),A.ial[F]=H);if(A.ial){for(const[w,F]of Object.entries(A.ial))if(w.startsWith("custom-slidev-"))for(const H of A.children)(H.type==="video"||H.type==="NodeVideo"||/<video\b/i.test(H.markdown||H.content||""))&&!((E=H.ial)!=null&&E[w])&&(H.ial||(H.ial={}),H.ial[w]=F)}}};g(u),Yu(u,x=>{const B={[ht]:x.layout};this.setBlockAttrOverride(x.blockId,B),(this.deps.setBlockAttrs||Et)(x.blockId,B).catch(A=>{console.warn("[DocumentCompiler] Failed to auto-tag superblock image layout:",A)})});const d=this.trackedListSuperBlocks.get(e)||[],b=Zu(e,u,{tracked:d,onTagChange:x=>{this.setBlockAttrOverride(x.blockId,x.attrs),x.blockId===e&&Object.assign(i,x.attrs);const B=A=>{for(const w of A)w.id===x.blockId&&(w.ial||(w.ial={}),Object.assign(w.ial,x.attrs)),w.children&&w.children.length>0&&B(w.children)};B(u),(this.deps.setBlockAttrs||Et)(x.blockId,x.attrs).catch(A=>{console.warn("[DocumentCompiler] Failed to auto-tag list superblock attrs:",A)})}});this.trackedListSuperBlocks.set(e,b.newTracked);const f=new Set;for(const x of u){const B=x.markdown||x.content||"";if(B.includes("((")){const E=uc(B);for(const A of E)f.add(A.blockId)}}const v={};if(f.size>0){const x=Array.from(f).map(E=>`'${E}'`).join(","),B=await this.deps.sql(`SELECT id, content, markdown FROM blocks WHERE id IN (${x})`).catch(()=>[])||[];if(Array.isArray(B))for(const E of B)E.id&&(v[E.id]=E.markdown||E.content||"")}const k=this.deps.getBaseUrl?this.deps.getBaseUrl():"",S=Br(e,i,u,{baseUrl:k,refContentMap:v});try{const x=this.deps.getInlineStyles?await this.deps.getInlineStyles().catch(()=>null):null;S.customThemeCss=kn(x)}catch{S.customThemeCss=kn(null)}return S}catch(i){console.error("[DocumentCompilerService] Failed to compile document:",i);const n=Br(e,{},[],{});return n.customThemeCss=kn(null),n}}}const Lt=new rf;class Rs{constructor(e){xt(this,"devServerUrl","http://localhost:3030");xt(this,"isConnected",!1);xt(this,"lastSyncTime",null);e&&(this.devServerUrl=e)}getUrl(){return this.devServerUrl}setUrl(e){this.devServerUrl=e.replace(/\/+$/,"")}isServerConnected(){return this.isConnected}getLastSyncTime(){return this.lastSyncTime}async probeServer(e=1500){try{const i=new AbortController,n=setTimeout(()=>i.abort(),e),o=await fetch(this.devServerUrl,{method:"HEAD",mode:"no-cors",signal:i.signal}).catch(()=>null);return clearTimeout(n),this.isConnected=!!o,this.isConnected}catch{return this.isConnected=!1,!1}}buildStandardSlidevMarkdown(e){const i=e.config,n=["---",`theme: ${i.theme||"default"}`,`aspectRatio: "${i.aspectRatio||"16/9"}"`,`highlighter: ${i.highlighter||"shiki"}`,`transition: ${i.defaultTransition||"slide-left"}`];i.colorSchema&&i.colorSchema!=="auto"&&n.push(`colorSchema: ${i.colorSchema}`),n.push("drawings:","  persist: false","---","");const o=n.join(`
`),s=e.slides.map((r,a)=>{const c=r.frontmatter||{},u=[],m=a===0;c.layout&&c.layout!=="default"&&u.push(`layout: ${c.layout}`),c.transition&&u.push(`transition: ${c.transition}`),c.background&&u.push(`background: ${c.background}`),c.class&&u.push(`class: "${c.class}"`);let g="";u.length>0?g=m?"":`---
${u.join(`
`)}
---

`:m||(g=`---

`);let d="";if(c.layout==="two-cols"){const f=r.blocks.filter(x=>x.slot!=="right"),v=r.blocks.filter(x=>x.slot==="right"),k=f.map(x=>x.rawMarkdown||x.content||"").join(`

`),S=v.map(x=>x.rawMarkdown||x.content||"").join(`

`);d=`${k}

::right::

${S}`}else d=r.blocks.map(f=>f.rawMarkdown||f.content||"").join(`

`);let b="";return r.notes&&r.notes.trim()&&(b=`

<!--
${r.notes.trim()}
-->`),`${g}${d}${b}`}).join(`

`);let l="";return e.config.normalizeHeadingSizes&&(l=`

<style>
/* Specific Heading Normalization */
.slidev-layout:not(.cover) > :is(h1, h2, h3, h4, h5, h6):first-child {
  font-size: 1.7rem !important;
}
.two-cols-header-top :is(h1, h2, h3, h4, h5, h6),
.cols-header-top :is(h1, h2, h3, h4, h5, h6),
.layout-header-section :is(h1, h2, h3, h4, h5, h6) {
  font-size: 1.7rem !important;
}
:is(.two-cols-left, .two-cols-right, .col, .col-1, .col-2, .col-3, .three-cols-col) > :is(h1, h2, h3, h4, h5, h6):first-child {
  font-size: 1.3rem !important;
}
</style>`),`${o}${s}${l}
`}async syncToWorkspaceFile(e,i="/data/storage/petal/siyuan-slidev/slides.md",n){const o=this.buildStandardSlidevMarkdown(e);if(this.lastSyncTime=Date.now(),n)try{const s=typeof Blob<"u"?new Blob([o],{type:"text/markdown;charset=utf-8"}):Buffer.from(o,"utf-8");return await n(i,!1,s),{success:!0,path:i}}catch(s){return{success:!1,path:i,error:String(s)}}return{success:!0,path:i}}downloadSlidesMd(e,i="slides.md"){if(typeof window>"u"||typeof document>"u")return!1;const n=this.buildStandardSlidevMarkdown(e),o=new Blob([n],{type:"text/markdown;charset=utf-8"}),s=URL.createObjectURL(o),l=document.createElement("a");return l.href=s,l.download=i,document.body.appendChild(l),l.click(),document.body.removeChild(l),URL.revokeObjectURL(s),!0}}function lf(){if(typeof window<"u"&&typeof window.require=="function")return window.require.bind(window);if(typeof globalThis<"u"&&typeof globalThis.require=="function")return globalThis.require.bind(globalThis);if(typeof require=="function")return require}function _e(t){const e=lf();if(e)try{return e(t)}catch{try{const i=t.startsWith("node:")?t.slice(5):`node:${t}`;return e(i)}catch{}}}function zs(){var e;if(typeof window<"u"&&window.process)return window.process;const t=_e("process");return t&&t.versions?t:typeof process<"u"&&((e=process.versions)!=null&&e.node)?process:globalThis.process}function aa(){var e,i;const t=zs();if(t&&((e=t.versions)!=null&&e.node))return!0;if(typeof window<"u"&&window.siyuan){const n=_e("child_process");if(n&&typeof n.spawn=="function")return!0}return!!(typeof process<"u"&&((i=process.versions)!=null&&i.node))}function af(){if(typeof window>"u"||!window.location)return!1;try{return new URLSearchParams(window.location.search).get("remote")==="1"}catch{return!1}}function Dn(){const t=zs();if(t!=null&&t.platform)return t.platform;if(typeof process<"u"&&process.platform)return process.platform;const e=_e("os");if(e&&typeof e.platform=="function")return e.platform();if(typeof navigator<"u"){const i=navigator.userAgent.toLowerCase();if(i.includes("win"))return"win32";if(i.includes("mac"))return"darwin";if(i.includes("linux"))return"linux"}return"web"}function ca(){var n,o;const t=zs(),e={...(t==null?void 0:t.env)||{}};if(Dn()==="win32"){const s=["C:\\Program Files\\nodejs","C:\\Program Files (x86)\\nodejs",(n=t==null?void 0:t.env)!=null&&n.APPDATA?`${t.env.APPDATA}\\npm`:"",(o=t==null?void 0:t.env)!=null&&o.USERPROFILE?`${t.env.USERPROFILE}\\AppData\\Roaming\\npm`:""].filter(Boolean),l=Object.keys(e).find(c=>c.toLowerCase()==="path")||"PATH",a=(e[l]||"").split(";").filter(Boolean);for(const c of s)c&&!a.some(u=>u.toLowerCase()===c.toLowerCase())&&a.push(c);e[l]=a.join(";")}return e}function hs(t){var i,n,o;if(!t)return"";if(/^[a-zA-Z]:[/\\]/.test(t))return t.replace(/\\/g,"/");let e="";if(typeof window<"u"&&((o=(n=(i=window.siyuan)==null?void 0:i.config)==null?void 0:n.system)!=null&&o.dataDir)&&(e=window.siyuan.config.system.dataDir.replace(/\\/g,"/")),e&&t.startsWith("/data/")){const s=t.slice(6);return`${e}/${s}`.replace(/\\/g,"/")}return t}function cf(){const t=_e("os"),e=_e("path");if(t&&typeof t.tmpdir=="function"){const i=t.tmpdir();return e&&typeof e.join=="function"?e.join(i,"siyuan-slidev-pro").replace(/\\/g,"/"):`${i}/siyuan-slidev-pro`.replace(/\\/g,"/")}return"/data/storage/petal/siyuan-slidev/pro-workspace"}class Ns{constructor(e){xt(this,"runner");this.runner=e||Ns.defaultRunner}static async defaultRunner(e,i){var n;try{let o=(n=_e("child_process"))==null?void 0:n.execFile;if(!o){const a=await import("node:child_process").catch(()=>({}));o=a==null?void 0:a.execFile}if(!o)return{code:-1,stdout:"",stderr:"child_process execFile not available"};const l=Dn()==="win32",r=ca();return await new Promise(a=>{o(e,i,{timeout:5e3,shell:l,env:r},(c,u,m)=>{a({code:c?c.code||1:0,stdout:u?String(u).trim():"",stderr:m?String(m).trim():""})})})}catch(o){return{code:-1,stdout:"",stderr:String(o)}}}async detect(){const e=aa(),i=Dn();if(!e)return{hasNode:!1,hasSlidevCli:!1,platform:"browser",isDesktop:!1,error:"当前处于纯前端浏览器或移动端环境，无 Node.js 运行时支撑"};let n=!1,o,s=!1,l;try{const r=await this.runner("node",["-v"]);r.code===0&&r.stdout.startsWith("v")&&(n=!0,o=r.stdout)}catch{}if(n){try{const r=i==="win32"?"slidev.cmd":"slidev",a=await this.runner(r,["--version"]);a.code===0&&a.stdout&&(s=!0,l=a.stdout)}catch{}if(!s)try{const r=i==="win32"?"npx.cmd":"npx",a=await this.runner(r,["@slidev/cli","--version"]);a.code===0&&a.stdout&&(s=!0,l=a.stdout)}catch{}}return{hasNode:n,nodeVersion:o,hasSlidevCli:s,slidevVersion:l,platform:i,isDesktop:e}}}class df{constructor(){xt(this,"iframe",null);xt(this,"isReady",!1);xt(this,"pageChangedHandlers",[]);xt(this,"readyHandlers",[]);xt(this,"currentState",{no:1,clicks:0,total:1});this.handleWindowMessage=this.handleWindowMessage.bind(this)}getCurrentState(){return{...this.currentState}}attach(e){this.detach(),this.iframe=e,this.isReady=!1,typeof window<"u"&&window.addEventListener("message",this.handleWindowMessage)}detach(){typeof window<"u"&&window.removeEventListener("message",this.handleWindowMessage),this.iframe=null,this.isReady=!1}postMessage(e,i){var o;if(!((o=this.iframe)!=null&&o.contentWindow))return;const n={target:"slidev",sender:"siyuan",type:e,...i};try{this.iframe.contentWindow.postMessage(n,"*")}catch(s){console.warn("[NativeSlidevBridge] postMessage error:",s)}}navigateToPage(e){this.postMessage("navigate",{no:e})}next(){this.postMessage("next")}prev(){this.postMessage("prev")}nextClick(){this.postMessage("next-click")}prevClick(){this.postMessage("prev-click")}onPageChanged(e){return this.pageChangedHandlers.push(e),()=>{this.pageChangedHandlers=this.pageChangedHandlers.filter(i=>i!==e)}}onReady(e){return this.readyHandlers.push(e),()=>{this.readyHandlers=this.readyHandlers.filter(i=>i!==e)}}handleWindowMessage(e){const i=e.data;if(!(!i||i.target!=="slidev")){if(!this.isReady){this.isReady=!0;for(const n of this.readyHandlers)n()}if(i.type==="update-state"&&i.navState){const n=i.navState;this.currentState={no:n.no??this.currentState.no,clicks:n.clicks??this.currentState.clicks,total:n.total??this.currentState.total,hasNext:n.hasNext,hasPrev:n.hasPrev};for(const o of this.pageChangedHandlers)o(this.currentState.no,this.currentState.total||1,this.currentState)}else if(i.type==="navigate"&&typeof i.no=="number"){this.currentState.no=i.no;for(const n of this.pageChangedHandlers)n(i.no,this.currentState.total||1,this.currentState)}}}}class uf{constructor(e){xt(this,"childProcess",null);xt(this,"activePort",null);xt(this,"isRunning",!1);xt(this,"defaultPort");xt(this,"maxPortRetries");xt(this,"probeTimeoutMs");xt(this,"customSpawner");xt(this,"customPortChecker");this.defaultPort=(e==null?void 0:e.defaultPort)||3030,this.maxPortRetries=(e==null?void 0:e.maxPortRetries)||20,this.probeTimeoutMs=(e==null?void 0:e.probeTimeoutMs)||1e4,this.customSpawner=e==null?void 0:e.customSpawner,this.customPortChecker=e==null?void 0:e.customPortChecker}getActivePort(){return this.activePort}getIsRunning(){return this.isRunning}async isPortAvailable(e){if(this.customPortChecker)return this.customPortChecker(e);try{let i=_e("net");return i||(i=await import("node:net").catch(()=>({}))),i!=null&&i.createServer?await new Promise(n=>{const o=i.createServer();o.once("error",()=>n(!1)),o.once("listening",()=>{o.close(()=>n(!0))}),o.listen(e,"127.0.0.1")}):!0}catch{return!0}}async allocPort(e){const i=e||this.defaultPort;for(let n=0;n<this.maxPortRetries;n++){const o=i+n;if(await this.isPortAvailable(o))return o}return i}async pollServerReady(e,i=8e3,n=300){const o=Date.now();for(;Date.now()-o<i;){try{const s=new AbortController,l=setTimeout(()=>s.abort(),n),r=await fetch(e,{method:"HEAD",mode:"no-cors",signal:s.signal}).catch(()=>null);if(clearTimeout(l),r)return!0}catch{}await new Promise(s=>setTimeout(s,n))}return!1}async startServer(e,i){var a,c;if(this.isRunning&&this.activePort)return{success:!0,port:this.activePort,url:`http://localhost:${this.activePort}?embedded=true`};const n=await this.allocPort(i);this.activePort=n;const s=Dn()==="win32"?"npx.cmd":"npx",l=hs(e),r=["@slidev/cli",l,"--port",String(n),"--no-open"];try{if(this.customSpawner)this.childProcess=this.customSpawner(s,r,{detached:!1});else{let m=(a=_e("child_process"))==null?void 0:a.spawn;if(!m){const b=await import("node:child_process").catch(()=>({}));m=b==null?void 0:b.spawn}if(!m)throw new Error("child_process spawn not available in current runtime");const g=l.includes("/")||l.includes("\\")?l.replace(/[/\\][^/\\]+$/,""):void 0,d=ca();this.childProcess=m(s,r,{cwd:g,detached:!1,shell:!0,env:{...d,FORCE_COLOR:"1"}})}this.isRunning=!0,(c=this.childProcess)!=null&&c.on&&this.childProcess.on("exit",()=>{this.isRunning=!1,this.activePort=null,this.childProcess=null});const u=`http://localhost:${n}`;return!this.customSpawner&&!await this.pollServerReady(u,this.probeTimeoutMs)?(this.stopServer(),{success:!1,port:n,url:"",error:`Slidev DevServer 启动超时 (未在 ${this.probeTimeoutMs}ms 内响应端口 ${n})`}):{success:!0,port:n,url:`${u}?embedded=true`}}catch(u){return this.stopServer(),{success:!1,port:n,url:"",error:`唤起 Slidev 进程失败: ${String(u)}`}}}stopServer(){var e;if(this.childProcess){try{if(this.childProcess.kill("SIGTERM"),Dn()==="win32"&&this.childProcess.pid&&!this.customSpawner){const n=(e=_e("child_process"))==null?void 0:e.exec;n?n(`taskkill /pid ${this.childProcess.pid} /T /F`,()=>{}):import("node:child_process").then(({exec:o})=>{var s;o(`taskkill /pid ${(s=this.childProcess)==null?void 0:s.pid} /T /F`,()=>{})}).catch(()=>{})}}catch{}this.childProcess=null}this.isRunning=!1,this.activePort=null}}class Fs{constructor(){xt(this,"iframe",null);xt(this,"isReady",!1);xt(this,"pendingMessages",[]);xt(this,"slideChangedHandlers",[]);xt(this,"blockClickedHandlers",[]);xt(this,"openInEditorHandlers",[]);xt(this,"clientReadyHandlers",[]);xt(this,"openPeekDrawerHandlers",[]);xt(this,"toggleFullscreenHandlers",[]);this.handleWindowMessage=this.handleWindowMessage.bind(this)}attach(e){this.detach(),this.iframe=e,this.isReady=!1,typeof window<"u"&&window.addEventListener("message",this.handleWindowMessage)}detach(){typeof window<"u"&&window.removeEventListener("message",this.handleWindowMessage),this.iframe=null,this.isReady=!1,this.pendingMessages=[]}postMessage(e,i){var o;const n={source:"siyuan-slidev-host",action:e,payload:i};if(!((o=this.iframe)!=null&&o.contentWindow)||!this.isReady){this.pendingMessages.push(n);return}try{this.iframe.contentWindow.postMessage(n,"*")}catch(s){console.warn("[WebSandboxBridge] postMessage error:",s)}}updateSlides(e,i,n,o){this.postMessage("UPDATE_SLIDES",{slides:e,config:i,fullMarkdown:n,customThemeCss:o})}navigatePage(e){this.postMessage("NAVIGATE_PAGE",{pageIndex:e})}highlightElement(e){this.postMessage("HIGHLIGHT_ELEMENT",{targetBlockId:e})}nextStep(){this.postMessage("NEXT_STEP",{})}prevStep(){this.postMessage("PREV_STEP",{})}freezeKeyboardNav(e){this.postMessage("FREEZE_KEYBOARD_NAV",{frozen:e})}onSlideChanged(e){return this.slideChangedHandlers.push(e),()=>{this.slideChangedHandlers=this.slideChangedHandlers.filter(i=>i!==e)}}onBlockClicked(e){return this.blockClickedHandlers.push(e),()=>{this.blockClickedHandlers=this.blockClickedHandlers.filter(i=>i!==e)}}onOpenInEditor(e){return this.openInEditorHandlers.push(e),()=>{this.openInEditorHandlers=this.openInEditorHandlers.filter(i=>i!==e)}}onOpenPeekDrawer(e){return this.openPeekDrawerHandlers.push(e),()=>{this.openPeekDrawerHandlers=this.openPeekDrawerHandlers.filter(i=>i!==e)}}onRequestToggleFullscreen(e){return this.toggleFullscreenHandlers.push(e),()=>{this.toggleFullscreenHandlers=this.toggleFullscreenHandlers.filter(i=>i!==e)}}onClientReady(e){return this.clientReadyHandlers.push(e),()=>{this.clientReadyHandlers=this.clientReadyHandlers.filter(i=>i!==e)}}handleWindowMessage(e){var n;const i=e.data;if(!(!i||i.source!=="siyuan-slidev-client"))switch(i.action){case"CLIENT_READY":for(this.isReady=!0;this.pendingMessages.length>0;){const o=this.pendingMessages.shift();o&&((n=this.iframe)!=null&&n.contentWindow)&&this.iframe.contentWindow.postMessage(o,"*")}for(const o of this.clientReadyHandlers)o();break;case"SLIDE_CHANGED":if(i.payload.currentPage!==void 0)for(const o of this.slideChangedHandlers)o(i.payload.currentPage,i.payload.totalPages||1,i.payload.currentBlockId||"");break;case"BLOCK_CLICKED":if(i.payload.clickedBlockId)for(const o of this.blockClickedHandlers)o(i.payload.clickedBlockId,i.payload.currentPage||1);break;case"OPEN_IN_EDITOR":if(i.payload.blockId||i.payload.clickedBlockId){const o=i.payload.blockId||i.payload.clickedBlockId||"";for(const s of this.openInEditorHandlers)s(o,i.payload.currentPage||1)}break;case"OPEN_PEEK_DRAWER":if(i.payload.peekType){const o=i.payload.blockId||i.payload.url||"",s={peekType:i.payload.peekType,target:o,title:i.payload.title};for(const l of this.openPeekDrawerHandlers)l(s)}break;case"REQUEST_TOGGLE_FULLSCREEN":for(const o of this.toggleFullscreenHandlers)o();break}}}const da={"snippets/external.ts":`// Inside ./snippets/external.ts
// #region snippet
export function emptyArray<T>(length: number) {
  return Array.from<T>({ length })
}
// #endregion snippet

export function sayHello() {
  console.log('Hello from snippets/external.ts')
}
`},ff=`<script setup lang="ts">
import { computed, useSlots } from 'vue'

const props = defineProps({
  layoutRatio: {
    type: String,
    default: '',
  },
  cols: {
    type: [Number, String],
    default: 0,
  },
})

const slots = useSlots()

const detectedColsCount = computed(() => {
  const explicitCols = Number(props.cols)
  if (explicitCols >= 2 && explicitCols <= 6) return explicitCols
  const r = (props.layoutRatio || '').trim()
  if (r.includes(':')) {
    const parts = r.split(':').map(p => parseFloat(p.trim())).filter(n => !isNaN(n) && n > 0)
    if (parts.length >= 2) return Math.min(parts.length, 6)
  }
  const tokens = r.split(/\\s+/).filter(Boolean)
  if (tokens.length >= 2) return Math.min(tokens.length, 6)
  for (let i = 6; i >= 3; i--) {
    if (slots[\`col-\${i}\`]) return i
  }
  if (slots['col-2'] || slots['right']) return 2
  return 2
})

const gridStyle = computed(() => {
  const r = props.layoutRatio || ''
  if (r) {
    if (r.includes(':')) {
      const parts = r.split(':').map(p => parseFloat(p.trim())).filter(n => !isNaN(n) && n > 0)
      if (parts.length >= 2) {
        return { gridTemplateColumns: parts.map(n => \`\${n}fr\`).join(' ') }
      }
    }
    const tokens = r.split(/\\s+/).filter(Boolean)
    if (tokens.length >= 2) {
      return { gridTemplateColumns: tokens.join(' ') }
    }
  }
  return { gridTemplateColumns: \`repeat(\${detectedColsCount.value}, minmax(0, 1fr))\` }
})
<\/script>

<template>
  <div class="slidev-layout cols-header w-full h-full flex flex-col">
    <div class="header-section mb-4 w-full">
      <slot />
    </div>
    <div class="grid gap-6 flex-1 items-stretch" :style="gridStyle">
      <div v-if="detectedColsCount >= 1" class="col-1 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-1"><slot name="left" /></slot>
      </div>
      <div v-if="detectedColsCount >= 2" class="col-2 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-2"><slot v-if="detectedColsCount === 2" name="right" /></slot>
      </div>
      <div v-if="detectedColsCount >= 3" class="col-3 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-3" />
      </div>
      <div v-if="detectedColsCount >= 4" class="col-4 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-4" />
      </div>
      <div v-if="detectedColsCount >= 5" class="col-5 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-5" />
      </div>
      <div v-if="detectedColsCount >= 6" class="col-6 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-6" />
      </div>
    </div>
  </div>
</template>
`,pf=`<script setup lang="ts">
import { computed } from 'vue'

const props = defineProps({
  layoutRatio: {
    type: String,
    default: '',
  },
})

const gridStyle = computed(() => {
  const r = props.layoutRatio || ''
  if (!r) return {}
  if (r.includes(':')) {
    const parts = r.split(':').map(p => parseFloat(p.trim())).filter(n => !isNaN(n) && n > 0)
    if (parts.length >= 2) {
      return { gridTemplateColumns: parts.map(n => \`\${n}fr\`).join(' ') }
    }
  }
  const tokens = r.split(/\\s+/).filter(Boolean)
  if (tokens.length >= 2) {
    return { gridTemplateColumns: tokens.join(' ') }
  }
  return {}
})
<\/script>

<template>
  <div class="slidev-layout three-cols-header w-full h-full flex flex-col">
    <div class="header-section mb-4 w-full">
      <slot />
    </div>
    <div class="grid gap-6 flex-1 items-stretch" :class="gridStyle.gridTemplateColumns ? '' : 'grid-cols-3'" :style="gridStyle">
      <div class="col-1 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-1" />
      </div>
      <div class="col-2 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-2" />
      </div>
      <div class="col-3 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-3" />
      </div>
    </div>
  </div>
</template>
`,hf=`<script setup lang="ts">
import { useSlots } from 'vue'

const slots = useSlots()
<\/script>

<template>
  <div class="slidev-layout clover w-full h-full flex flex-col">
    <div class="header-section mb-4 w-full">
      <slot />
    </div>
    <div class="grid grid-cols-2 grid-rows-2 gap-6 flex-1 items-stretch">
      <div class="col-1 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-1" />
      </div>
      <div class="col-2 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-2" />
      </div>
      <div class="col-3 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-3" />
      </div>
      <div class="col-4 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-4" />
      </div>
    </div>
  </div>
</template>
`,mf=`// Auto-generated by SiYuan Slidev Studio
// 本地 HTML 链接（思源资产 / 工作区文件 / 绝对文件路径）速览判定
// 注意：需与 public/slidev-client/index.html 中的拦截器保持同步
function isPeekableLocalHtml(href: string): boolean {
  const clean = (href || '').trim()
  if (!clean || clean.startsWith('#') || clean.startsWith('//')) return false
  if (!/\\.html?($|[?#])/i.test(clean)) return false
  if (/^https?:\\/\\//i.test(clean)) return false
  const scheme = /^([a-z][a-z0-9+.-]*):/i.exec(clean)
  if (!scheme) return true
  const schemeName = scheme[1].toLowerCase()
  if (schemeName === 'file') return true
  // Windows 盘符路径（D:\\\\docs\\\\demo.html）并非协议前缀
  return schemeName.length === 1 && /^[a-zA-Z]:[\\\\/]/.test(clean)
}

// 本地 HTML 链接预处理：思源资产统一指向内核 /assets/ 静态服务，其余原样转交宿主归一化
// 不基于 location 绝对化，保证 Pro 模式（Slidev dev server）与沙箱模式行为完全一致
function resolvePeekHref(href: string): string {
  const clean = (href || '').trim()
  if (/^(?:\\.\\/|\\/)?assets\\//.test(clean)) {
    return '/' + clean.replace(/^(?:\\.\\/|\\/)/, '')
  }
  return clean
}

export default function() {
  if (typeof window === 'undefined') return
  window.addEventListener('click', (e: MouseEvent) => {
    const target = e.target as HTMLElement | null
    if (!target || !target.closest) return

    const refEl = target.closest('[data-ref-id]')
    if (refEl) {
      const blockId = refEl.getAttribute('data-ref-id')
      if (blockId) {
        e.preventDefault()
        e.stopPropagation()
        window.parent.postMessage({
          source: 'siyuan-slidev-client',
          action: 'OPEN_PEEK_DRAWER',
          payload: { peekType: 'siyuan', blockId, title: (refEl.innerText || refEl.title || '').trim() }
        }, '*')
        return
      }
    }

    const linkEl = target.closest('a') as HTMLAnchorElement | null
    if (linkEl) {
      const href = linkEl.getAttribute('href') || ''
      if (href.startsWith('siyuan://blocks/')) {
        e.preventDefault()
        e.stopPropagation()
        const cleanBlockId = href.replace('siyuan://blocks/', '').split('?')[0]
        window.parent.postMessage({
          source: 'siyuan-slidev-client',
          action: 'OPEN_PEEK_DRAWER',
          payload: { peekType: 'siyuan', blockId: cleanBlockId, title: (linkEl.innerText || linkEl.title || '').trim() }
        }, '*')
      } else if (/^https?:\\/\\//i.test(href)) {
        e.preventDefault()
        e.stopPropagation()
        window.parent.postMessage({
          source: 'siyuan-slidev-client',
          action: 'OPEN_PEEK_DRAWER',
          payload: { peekType: 'web', url: href, title: (linkEl.innerText || linkEl.title || '').trim() }
        }, '*')
      } else if (isPeekableLocalHtml(href)) {
        e.preventDefault()
        e.stopPropagation()
        window.parent.postMessage({
          source: 'siyuan-slidev-client',
          action: 'OPEN_PEEK_DRAWER',
          payload: { peekType: 'web', url: resolvePeekHref(href), title: (linkEl.innerText || linkEl.title || '').trim() }
        }, '*')
      }
    }
  }, true)
}
`,gf=`${ps}

/* Auto-generated by SiYuan Slidev Studio */
.slidev-ref-tag,
a.slidev-ref-tag {
  display: inline-flex;
  align-items: center;
  background: color-mix(in srgb, var(--slidev-theme-primary, #10b981) 12%, transparent);
  color: var(--slidev-theme-primary, #10b981);
  border-radius: 4px;
  padding: 2px 8px;
  font-size: 0.88em;
  text-decoration: none;
  border: 1px solid color-mix(in srgb, var(--slidev-theme-primary, #10b981) 25%, transparent);
  cursor: pointer;
  transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
  user-select: none;
}

.slidev-ref-tag:hover,
a.slidev-ref-tag:hover {
  background: color-mix(in srgb, var(--slidev-theme-primary, #10b981) 22%, transparent);
  color: var(--slidev-theme-primary, #10b981);
  border-color: color-mix(in srgb, var(--slidev-theme-primary, #10b981) 55%, transparent);
  transform: translateY(-1px);
  box-shadow: 0 2px 8px color-mix(in srgb, var(--slidev-theme-primary, #10b981) 20%, transparent);
}

.slidev-block-ref {
  display: block;
  padding: 10px 14px;
  background: color-mix(in srgb, var(--slidev-theme-primary, #10b981) 8%, transparent);
  border-left: 3px solid var(--slidev-theme-primary, #10b981);
  border-radius: 0 6px 6px 0;
  margin: 8px 0;
  cursor: pointer;
  transition: background 0.2s ease;
}

.slidev-block-ref:hover {
  background: color-mix(in srgb, var(--slidev-theme-primary, #10b981) 15%, transparent);
}

/* 代码块自动换行与无横向滚动条 */
pre,
pre code {
  white-space: pre-wrap !important;
  word-break: break-all !important;
  overflow-wrap: anywhere !important;
  overflow-x: hidden !important;
  overflow-y: auto !important;
  max-width: 100% !important;
  box-sizing: border-box !important;
}

/* 弱提示滚动条样式 */
* {
  scrollbar-width: thin;
}
html:not(.dark) * {
  scrollbar-color: rgba(0, 0, 0, 0.15) transparent;
}
html.dark * {
  scrollbar-color: rgba(255, 255, 255, 0.20) transparent;
}
*::-webkit-scrollbar {
  width: 4px;
  height: 4px;
}
*::-webkit-scrollbar-track {
  background: transparent;
}
html:not(.dark) *::-webkit-scrollbar-thumb {
  background: rgba(0, 0, 0, 0.15);
  border-radius: 2px;
}
html:not(.dark) *:hover::-webkit-scrollbar-thumb,
html:not(.dark) *::-webkit-scrollbar-thumb:hover {
  background: rgba(0, 0, 0, 0.35);
}
html.dark *::-webkit-scrollbar-thumb {
  background: rgba(255, 255, 255, 0.20);
  border-radius: 2px;
}
html.dark *:hover::-webkit-scrollbar-thumb,
html.dark *::-webkit-scrollbar-thumb:hover {
  background: rgba(255, 255, 255, 0.45);
}

/* 多媒体（GIF动图、静态图片、MP4视频）最大化自适应且不超出视口：顶部对齐，横向居中 */
.slidev-layout img,
.slidev-layout video {
  max-width: 100% !important;
  max-height: 100% !important;
  width: auto;
  height: auto;
  object-fit: contain !important;
}
.three-cols-header video,
.two-cols-header video,
.grid-cols-3 video,
.grid-cols-2 video,
.col-1 video,
.col-2 video,
.col-3 video {
  width: auto !important;
  height: auto !important;
  max-width: 100% !important;
  max-height: 100% !important;
  object-fit: contain !important;
  display: block !important;
  margin: 0 auto !important;
}
.slide-list-media {
  display: flex !important;
  flex-direction: column !important;
  align-items: center !important;
  justify-content: flex-start !important;
  margin-top: 4px !important;
  margin-bottom: 4px !important;
  width: 100% !important;
  max-width: 100% !important;
  height: 100% !important;
  max-height: 100% !important;
  flex: 1 1 0% !important;
  overflow: hidden !important;
}
.slide-list-media img,
.slide-list-media video,
.slide-list-media .list-item-gif {
  width: auto !important;
  height: auto !important;
  max-width: 100% !important;
  max-height: 100% !important;
  object-fit: contain !important;
  border-radius: 6px !important;
  box-shadow: 0 3px 12px rgba(0, 0, 0, 0.14) !important;
  display: block !important;
  margin: 0 auto !important;
}
.slide-video-container {
  display: flex !important;
  flex-direction: column !important;
  justify-content: flex-start !important;
  align-items: center !important;
  width: 100% !important;
  max-height: 100% !important;
  margin: 6px 0 !important;
}
.slide-video-player {
  max-width: 100% !important;
  max-height: 100% !important;
  object-fit: contain !important;
  border-radius: 8px !important;
}

/* 两栏与多栏（超级块分栏）布局：紧凑自然行距，子列表保留圆点与层级缩进 */
.cols-header ul,
.three-cols-header ul,
.two-cols-header ul,
.two-cols ul,
.col-1 ul,
.col-2 ul,
.col-3 ul,
.col-4 ul,
.col-5 ul,
.col-6 ul,
.grid-cols-2 ul,
.grid-cols-3 ul {
  list-style: disc !important;
  list-style-type: disc !important;
  padding-left: 1.25em !important;
  margin-left: 0 !important;
  margin-top: 0 !important;
  margin-bottom: 8px !important;
  flex: 0 0 auto !important;
  height: auto !important;
  display: block !important;
}
.cols-header ol,
.three-cols-header ol,
.two-cols-header ol,
.two-cols ol,
.col-1 ol,
.col-2 ol,
.col-3 ol,
.col-4 ol,
.col-5 ol,
.col-6 ol,
.grid-cols-2 ol,
.grid-cols-3 ol {
  list-style: decimal !important;
  list-style-type: decimal !important;
  padding-left: 1.25em !important;
  margin-left: 0 !important;
  margin-top: 0 !important;
  margin-bottom: 8px !important;
  flex: 0 0 auto !important;
  height: auto !important;
  display: block !important;
}
.cols-header li,
.three-cols-header li,
.two-cols-header li,
.two-cols li,
.col-1 li,
.col-2 li,
.col-3 li,
.col-4 li,
.col-5 li,
.col-6 li,
.grid-cols-2 li,
.grid-cols-3 li {
  padding-left: 0.2em !important;
  margin-left: 0 !important;
  margin-bottom: 6px !important;
  flex: 0 0 auto !important;
  height: auto !important;
  display: list-item !important;
  line-height: 1.6 !important;
}
.cols-header ul ul,
.three-cols-header ul ul,
.two-cols-header ul ul,
.two-cols ul ul,
.col-1 ul ul,
.col-2 ul ul,
.col-3 ul ul,
.col-4 ul ul,
.col-5 ul ul,
.col-6 ul ul {
  list-style: circle !important;
  list-style-type: circle !important;
  padding-left: 1.25em !important;
  margin-top: 4px !important;
  margin-bottom: 4px !important;
}

/* 列表项内嵌标题与说明排版 */
.slide-list-item-title,
li > h1,
li > h2,
li > h3,
li > h4,
li > h5,
li > h6 {
  margin-top: 2px !important;
  margin-bottom: 6px !important;
  line-height: 1.35 !important;
  font-weight: 700 !important;
}
li > h1 { font-size: 1.6rem !important; }
li > h2 { font-size: 1.4rem !important; }
li > h3 { font-size: 1.22rem !important; }
li > h4 { font-size: 1.1rem !important; }
.slide-list-item-desc,
li > p {
  margin-top: 4px !important;
  margin-bottom: 6px !important;
  font-size: 1.05rem;
  line-height: 1.55;
  opacity: 0.92;
}
`;function vf(t){var o;const e=[],i=/^[ \t]*<<<[ \t]+(?:@\/|\.\/|)([^\s#]+)(?:#[^\s]+)?/gm;let n;for(;(n=i.exec(t))!==null;){const s=(o=n[1])==null?void 0:o.trim();s&&!e.includes(s)&&e.push(s)}return e}class bf{constructor(e){xt(this,"workspacePath");xt(this,"slidesFileName");xt(this,"cliBridge",new Rs);const i=cf();!(e!=null&&e.workspacePath)||e.workspacePath.includes("/data/storage/petal/siyuan-slidev/pro-workspace")?this.workspacePath=i:this.workspacePath=e.workspacePath,this.slidesFileName=(e==null?void 0:e.slidesFileName)||"slides.md"}getWorkspacePath(){return this.workspacePath}getSlidesPath(){return`${this.workspacePath}/${this.slidesFileName}`}generatePackageJson(e="default"){const i={name:"siyuan-slidev-pro-workspace",type:"module",private:!0,scripts:{dev:"slidev --port 3030",build:"slidev build"},dependencies:{"@slidev/cli":"^53.0.0","@slidev/theme-default":"latest"}};return e&&e!=="default"&&(i.dependencies[`@slidev/theme-${e}`]="latest"),JSON.stringify(i,null,2)}buildSlidesMarkdown(e){return this.cliBridge.buildStandardSlidevMarkdown(e)}async scaffold(e,i){const n=this.buildSlidesMarkdown(e),o=this.generatePackageJson(e.config.theme),s=this.getSlidesPath(),l=`${this.workspacePath}/package.json`,r=hs(s),a=hs(l),c=vf(n);c.includes("snippets/external.ts")||c.push("snippets/external.ts");const u=new Map;for(const x of c){const B=da[x]||`// Auto-generated snippet placeholder for SiYuan Slidev
// #region snippet
// ${x}
// #endregion snippet
`;u.set(x,B)}e.slides.some(x=>{var B;return((B=x.frontmatter)==null?void 0:B.layout)==="cols-header"})&&u.set("layouts/cols-header.vue",ff),e.slides.some(x=>{var B;return((B=x.frontmatter)==null?void 0:B.layout)==="three-cols-header"})&&u.set("layouts/three-cols-header.vue",pf),e.slides.some(x=>{var B;return((B=x.frontmatter)==null?void 0:B.layout)==="clover"})&&u.set("layouts/clover.vue",hf),u.set("setup/root.ts",mf),u.set("styles/index.css",gf);const b=_e("fs"),f=_e("path");let v=!1;const k=f!=null&&f.dirname?f.dirname(r):"",S=/^[a-zA-Z]:[/\\]/.test(r)||r.includes("siyuan-slidev-pro");if(b&&f&&S)try{b.existsSync(k)||b.mkdirSync(k,{recursive:!0}),b.writeFileSync(a,o,"utf-8"),b.writeFileSync(r,n,"utf-8");for(const[x,B]of u.entries()){const E=f.join(k,x),A=f.dirname(E);b.existsSync(A)||b.mkdirSync(A,{recursive:!0}),b.existsSync(E)||b.writeFileSync(E,B,"utf-8")}v=!0}catch{}if(!v&&i)try{const x=typeof Blob<"u"?new Blob([n],{type:"text/markdown;charset=utf-8"}):Buffer.from(n,"utf-8"),B=typeof Blob<"u"?new Blob([o],{type:"application/json;charset=utf-8"}):Buffer.from(o,"utf-8");await i(l,!1,B),await i(s,!1,x);for(const[E,A]of u.entries()){const w=`${this.workspacePath}/${E}`,F=typeof Blob<"u"?new Blob([A],{type:"text/plain;charset=utf-8"}):Buffer.from(A,"utf-8");await i(w,!1,F).catch(()=>{})}return{success:!0,slidesPath:s,physicalSlidesPath:r,packageJsonPath:l}}catch(x){return{success:!1,slidesPath:s,physicalSlidesPath:r,packageJsonPath:l,error:String(x)}}return{success:!0,slidesPath:s,physicalSlidesPath:r,packageJsonPath:l}}}class yf{constructor(){xt(this,"mode","web-sandbox");xt(this,"webBridge");xt(this,"cliBridge");xt(this,"nativeBridge");xt(this,"processManager");xt(this,"scaffolder");xt(this,"envDetector");this.webBridge=new Fs,this.cliBridge=new Rs,this.nativeBridge=new df,this.processManager=new uf,this.scaffolder=new bf,this.envDetector=new Ns}getMode(){return this.mode}setMode(e){this.mode=e}async startProMode(e,i){if(!(await this.envDetector.detect()).hasNode)return{success:!1,url:"",error:"当前系统未检测到 Node.js 环境，无法拉起官方 Slidev CLI，建议继续使用内置高保真引擎"};const o=await this.scaffolder.scaffold(e,i);if(!o.success)return{success:!1,url:"",error:`初始化 Slidev 临时工作空间失败: ${o.error}`};const s=o.physicalSlidesPath||o.slidesPath,l=await this.processManager.startServer(s);return l.success?(this.mode="pro-cli",{success:!0,url:l.url,port:l.port}):{success:!1,url:"",error:l.error}}stopProMode(){this.processManager.stopServer(),this.mode="web-sandbox"}destroy(){this.webBridge.detach(),this.nativeBridge.detach(),this.processManager.stopServer()}}const kf={class:"slidev-icon",style:{fill:"none !important"},viewBox:"0 0 24 24",stroke:"currentColor","stroke-width":"1.75","stroke-linecap":"round","stroke-linejoin":"round","aria-hidden":"true"},wf={key:0},xf={key:1},Sf={key:2},_f={key:3},Cf={key:4},$f={key:5},If={key:6},Af={key:7},Bf={key:8},Tf={key:9},Ef={key:10},Mf={key:11},Lf={key:12},Df={key:13},Pf={key:14},Of={key:15},Rf={key:16},zf={key:17},Nf={key:18},Ff={key:19},Hf={key:20},jf={key:21},Uf={key:22},Wf={key:23},Vf={key:24},qf={key:25},Kf={key:26},Gf={key:27},Zf={key:28},Yf={key:29},Jf={key:30},Xf={key:31},Qf={key:32},tp={key:33},ep={key:34},ip={key:35},np={key:36},op={key:37},sp={key:38},rp={key:39},lp={key:40},ap={key:41},cp={key:42},dp={key:43},up={key:44},fp={key:45},pp={key:46},hp={key:47},mp={key:48},gp={key:49},vp={key:50},bp={key:51},yp={key:52},kp={key:53},wp={key:54},xp={key:55},Sp={key:56},_p={key:57},Cp={key:58},$p={key:59},Ip={key:60},Ap={key:61},Bp={key:62},Tp={key:63},Ep={key:64},Mp=Ce({__name:"SlidevIcon",props:{name:{}},setup(t){return(e,i)=>(nt(),ot("svg",kf,[t.name==="fullscreen"||t.name==="maximize"?(nt(),ot("g",wf,[...i[0]||(i[0]=[h("polyline",{points:"15 3 21 3 21 9"},null,-1),h("polyline",{points:"9 21 3 21 3 15"},null,-1),h("polyline",{points:"21 15 21 21 15 21"},null,-1),h("polyline",{points:"3 9 3 3 9 3"},null,-1)])])):t.name==="minimize"?(nt(),ot("g",xf,[...i[1]||(i[1]=[h("polyline",{points:"4 14 10 14 10 20"},null,-1),h("polyline",{points:"20 10 14 10 14 4"},null,-1),h("line",{x1:"14",y1:"10",x2:"21",y2:"3"},null,-1),h("line",{x1:"3",y1:"21",x2:"10",y2:"14"},null,-1)])])):t.name==="close"||t.name==="x"?(nt(),ot("g",Sf,[...i[2]||(i[2]=[h("line",{x1:"18",y1:"6",x2:"6",y2:"18"},null,-1),h("line",{x1:"6",y1:"6",x2:"18",y2:"18"},null,-1)])])):t.name==="edit"?(nt(),ot("g",_f,[...i[3]||(i[3]=[h("path",{d:"M12 20h9"},null,-1),h("path",{d:"M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z"},null,-1)])])):t.name==="eye"?(nt(),ot("g",Cf,[...i[4]||(i[4]=[h("path",{d:"M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"},null,-1),h("circle",{cx:"12",cy:"12",r:"3"},null,-1)])])):t.name==="external-link"||t.name==="window"?(nt(),ot("g",$f,[...i[5]||(i[5]=[h("path",{d:"M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"},null,-1),h("polyline",{points:"15 3 21 3 21 9"},null,-1),h("line",{x1:"10",y1:"14",x2:"21",y2:"3"},null,-1)])])):t.name==="arrow-left"?(nt(),ot("g",If,[...i[6]||(i[6]=[h("line",{x1:"19",y1:"12",x2:"5",y2:"12"},null,-1),h("polyline",{points:"12 19 5 12 12 5"},null,-1)])])):t.name==="arrow-right"?(nt(),ot("g",Af,[...i[7]||(i[7]=[h("line",{x1:"5",y1:"12",x2:"19",y2:"12"},null,-1),h("polyline",{points:"12 5 19 12 12 19"},null,-1)])])):t.name==="plus"?(nt(),ot("g",Bf,[...i[8]||(i[8]=[h("line",{x1:"12",y1:"5",x2:"12",y2:"19"},null,-1),h("line",{x1:"5",y1:"12",x2:"19",y2:"12"},null,-1)])])):t.name==="minus"?(nt(),ot("g",Tf,[...i[9]||(i[9]=[h("line",{x1:"5",y1:"12",x2:"19",y2:"12"},null,-1)])])):t.name==="split-preview"?(nt(),ot("g",Ef,[...i[10]||(i[10]=[h("rect",{x:"3",y:"3",width:"18",height:"18",rx:"2"},null,-1),h("path",{d:"M12 3v18"},null,-1)])])):t.name==="import"?(nt(),ot("g",Mf,[...i[11]||(i[11]=[h("path",{d:"M4 17v2a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-2"},null,-1),h("polyline",{points:"7 9 12 14 17 9"},null,-1),h("line",{x1:"12",y1:"14",x2:"12",y2:"3"},null,-1)])])):t.name==="presenter"?(nt(),ot("g",Lf,[...i[12]||(i[12]=[h("path",{d:"M2 3h20"},null,-1),h("path",{d:"M21 3v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V3"},null,-1),h("path",{d:"m7 21 5-5 5 5"},null,-1)])])):t.name==="video"?(nt(),ot("g",Df,[...i[13]||(i[13]=[h("polygon",{points:"23 7 16 12 23 17 23 7"},null,-1),h("rect",{x:"1",y:"5",width:"15",height:"14",rx:"2",ry:"2"},null,-1)])])):t.name==="step"?(nt(),ot("g",Pf,[...i[14]||(i[14]=[h("polygon",{points:"13 2 3 14 12 14 11 22 21 10 12 10 13 2"},null,-1)])])):t.name==="motion"?(nt(),ot("g",Of,[...i[15]||(i[15]=[h("path",{d:"M5 12h14"},null,-1),h("path",{d:"m12 5 7 7-7 7"},null,-1),h("path",{d:"M5 6h4"},null,-1),h("path",{d:"M5 18h4"},null,-1)])])):t.name==="columns"?(nt(),ot("g",Rf,[...i[16]||(i[16]=[h("rect",{x:"3",y:"3",width:"7",height:"18",rx:"1"},null,-1),h("rect",{x:"14",y:"3",width:"7",height:"18",rx:"1"},null,-1)])])):t.name==="code"?(nt(),ot("g",zf,[...i[17]||(i[17]=[h("polyline",{points:"16 18 22 12 16 6"},null,-1),h("polyline",{points:"8 6 2 12 8 18"},null,-1)])])):t.name==="insert-above"?(nt(),ot("g",Nf,[...i[18]||(i[18]=[h("line",{x1:"12",y1:"5",x2:"12",y2:"13"},null,-1),h("line",{x1:"8",y1:"9",x2:"16",y2:"9"},null,-1),h("path",{d:"M4 19h16","stroke-dasharray":"2 2"},null,-1)])])):t.name==="insert-below"?(nt(),ot("g",Ff,[...i[19]||(i[19]=[h("path",{d:"M4 5h16","stroke-dasharray":"2 2"},null,-1),h("line",{x1:"12",y1:"11",x2:"12",y2:"19"},null,-1),h("line",{x1:"8",y1:"15",x2:"16",y2:"15"},null,-1)])])):t.name==="broom"?(nt(),ot("g",Hf,[...i[20]||(i[20]=[h("path",{d:"m18 15-6-6"},null,-1),h("path",{d:"M4 20h16"},null,-1),h("path",{d:"M6 14l8-8a2.8 2.8 0 0 1 4 4l-8 8H6v-4z"},null,-1)])])):t.name==="trash"?(nt(),ot("g",jf,[...i[21]||(i[21]=[h("path",{d:"M3 6h18"},null,-1),h("path",{d:"M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"},null,-1),h("path",{d:"M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"},null,-1)])])):t.name==="ai"||t.name==="sparkles"?(nt(),ot("g",Uf,[...i[22]||(i[22]=[h("path",{d:"m12 3-1.9 5.8a2 2 0 0 1-1.3 1.3L3 12l5.8 1.9a2 2 0 0 1 1.3 1.3L12 21l1.9-5.8a2 2 0 0 1 1.3-1.3L21 12l-5.8-1.9a2 2 0 0 1-1.3-1.3L12 3z"},null,-1)])])):t.name==="palette"?(nt(),ot("g",Wf,[...i[23]||(i[23]=[ge('<circle cx="13.5" cy="6.5" r=".5" fill="currentColor" data-v-794a58ae></circle><circle cx="17.5" cy="10.5" r=".5" fill="currentColor" data-v-794a58ae></circle><circle cx="8.5" cy="7.5" r=".5" fill="currentColor" data-v-794a58ae></circle><circle cx="6.5" cy="12.5" r=".5" fill="currentColor" data-v-794a58ae></circle><path d="M12 2C6.5 2 2 6.5 2 12s4.5 10 10 10c.9 0 1.5-.7 1.5-1.5 0-.4-.2-.8-.4-1.1-.3-.4-.4-.8-.4-1.4 0-1.1.9-2 2-2h2.3c3.9 0 7-3.1 7-7 0-5-4.5-9-10-9z" data-v-794a58ae></path>',5)])])):t.name==="ratio"?(nt(),ot("g",Vf,[...i[24]||(i[24]=[h("rect",{x:"2",y:"5",width:"20",height:"14",rx:"2"},null,-1),h("line",{x1:"2",y1:"10",x2:"22",y2:"10","stroke-dasharray":"2 2"},null,-1)])])):t.name==="transition"?(nt(),ot("g",qf,[...i[25]||(i[25]=[h("path",{d:"M8 3 4 7l4 4"},null,-1),h("path",{d:"M4 7h16"},null,-1),h("path",{d:"m16 21 4-4-4-4"},null,-1),h("path",{d:"M20 17H4"},null,-1)])])):t.name==="export-html"?(nt(),ot("g",Kf,[...i[26]||(i[26]=[h("polyline",{points:"16 16 12 12 8 16"},null,-1),h("line",{x1:"12",y1:"12",x2:"12",y2:"21"},null,-1),h("path",{d:"M20.4 16.3A5 5 0 0 0 18 7h-1.3A8 8 0 0 0 4 12.8a5 5 0 0 0 1.5 9.2"},null,-1)])])):t.name==="export-pdf"?(nt(),ot("g",Gf,[...i[27]||(i[27]=[h("polyline",{points:"6 9 6 2 18 2 18 9"},null,-1),h("path",{d:"M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"},null,-1),h("rect",{x:"6",y:"14",width:"12",height:"8"},null,-1)])])):t.name==="pin"?(nt(),ot("g",Zf,[...i[28]||(i[28]=[h("line",{x1:"12",y1:"17",x2:"12",y2:"22"},null,-1),h("path",{d:"M5 17h14v-2l-2-2V5l1-1V2H6v2l1 1v8l-2 2v2z"},null,-1)])])):t.name==="refresh"?(nt(),ot("g",Yf,[...i[29]||(i[29]=[h("path",{d:"M3 12a9 9 0 0 1 9-9 9.75 9.75 0 0 1 6.74 2.74L21 8"},null,-1),h("path",{d:"M21 3v5h-5"},null,-1),h("path",{d:"M21 12a9 9 0 0 1-9 9 9.75 9.75 0 0 1-6.74-2.74L3 16"},null,-1),h("path",{d:"M8 16H3v5"},null,-1)])])):t.name==="outline"?(nt(),ot("g",Jf,[...i[30]||(i[30]=[h("line",{x1:"3",y1:"6",x2:"21",y2:"6"},null,-1),h("line",{x1:"3",y1:"12",x2:"21",y2:"12"},null,-1),h("line",{x1:"3",y1:"18",x2:"21",y2:"18"},null,-1)])])):t.name==="chevron-left"?(nt(),ot("g",Xf,[...i[31]||(i[31]=[h("polyline",{points:"15 18 9 12 15 6"},null,-1)])])):t.name==="chevron-right"?(nt(),ot("g",Qf,[...i[32]||(i[32]=[h("polyline",{points:"9 18 15 12 9 6"},null,-1)])])):t.name==="copy"?(nt(),ot("g",tp,[...i[33]||(i[33]=[h("rect",{x:"9",y:"9",width:"13",height:"13",rx:"2",ry:"2"},null,-1),h("path",{d:"M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"},null,-1)])])):t.name==="image"?(nt(),ot("g",ep,[...i[34]||(i[34]=[h("rect",{x:"3",y:"3",width:"18",height:"18",rx:"2",ry:"2"},null,-1),h("circle",{cx:"8.5",cy:"8.5",r:"1.5"},null,-1),h("polyline",{points:"21 15 16 10 5 21"},null,-1)])])):t.name==="search"?(nt(),ot("g",ip,[...i[35]||(i[35]=[h("circle",{cx:"11",cy:"11",r:"7"},null,-1),h("line",{x1:"21",y1:"21",x2:"16.65",y2:"16.65"},null,-1)])])):t.name==="settings"||t.name==="gear"?(nt(),ot("g",np,[...i[36]||(i[36]=[h("circle",{cx:"12",cy:"12",r:"3"},null,-1),h("path",{d:"M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 1 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 1 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 1 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 1 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"},null,-1)])])):t.name==="notes"||t.name==="file-text"?(nt(),ot("g",op,[...i[37]||(i[37]=[ge('<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" data-v-794a58ae></path><polyline points="14 2 14 8 20 8" data-v-794a58ae></polyline><line x1="16" y1="13" x2="8" y2="13" data-v-794a58ae></line><line x1="16" y1="17" x2="8" y2="17" data-v-794a58ae></line><line x1="10" y1="9" x2="8" y2="9" data-v-794a58ae></line>',5)])])):t.name==="focus"||t.name==="target"?(nt(),ot("g",sp,[...i[38]||(i[38]=[h("circle",{cx:"12",cy:"12",r:"3",fill:"currentColor"},null,-1),h("path",{d:"M12 2v4M12 18v4M2 12h4M18 12h4",stroke:"currentColor","stroke-width":"2","stroke-linecap":"round"},null,-1),h("circle",{cx:"12",cy:"12",r:"7",fill:"none",stroke:"currentColor","stroke-width":"1.8"},null,-1)])])):t.name==="layout-cover"||t.name==="cover"?(nt(),ot("g",rp,[...i[39]||(i[39]=[h("rect",{x:"2",y:"4",width:"20",height:"16",rx:"2"},null,-1),h("line",{x1:"9",y1:"8",x2:"15",y2:"8"},null,-1),h("line",{x1:"5.5",y1:"11.5",x2:"18.5",y2:"11.5"},null,-1),h("line",{x1:"7.5",y1:"15",x2:"16.5",y2:"15"},null,-1)])])):t.name==="layout-default"||t.name==="default"?(nt(),ot("g",lp,[...i[40]||(i[40]=[ge('<rect x="2" y="4" width="20" height="16" rx="2" data-v-794a58ae></rect><line x1="5" y1="8" x2="11.5" y2="8" data-v-794a58ae></line><line x1="5" y1="11.5" x2="19" y2="11.5" data-v-794a58ae></line><line x1="5" y1="14.5" x2="19" y2="14.5" data-v-794a58ae></line><line x1="5" y1="17.5" x2="13.5" y2="17.5" data-v-794a58ae></line>',5)])])):t.name==="layout-two-cols"||t.name==="two-cols"?(nt(),ot("g",ap,[...i[41]||(i[41]=[ge('<rect x="2" y="4" width="20" height="16" rx="2" data-v-794a58ae></rect><line x1="12" y1="4" x2="12" y2="20" stroke-dasharray="2 1.5" data-v-794a58ae></line><line x1="5" y1="8" x2="9.5" y2="8" data-v-794a58ae></line><line x1="5" y1="11.5" x2="9.5" y2="11.5" data-v-794a58ae></line><line x1="5" y1="15" x2="8" y2="15" data-v-794a58ae></line><line x1="14.5" y1="8" x2="19" y2="8" data-v-794a58ae></line><line x1="14.5" y1="11.5" x2="19" y2="11.5" data-v-794a58ae></line><line x1="14.5" y1="15" x2="17.5" y2="15" data-v-794a58ae></line>',8)])])):t.name==="layout-two-cols-header"||t.name==="two-cols-header"?(nt(),ot("g",cp,[...i[42]||(i[42]=[ge('<rect x="2" y="4" width="20" height="16" rx="2" data-v-794a58ae></rect><line x1="5" y1="7.5" x2="13" y2="7.5" data-v-794a58ae></line><line x1="12" y1="10.5" x2="12" y2="18.5" stroke-dasharray="1.5 1.5" data-v-794a58ae></line><line x1="5" y1="12" x2="9.5" y2="12" data-v-794a58ae></line><line x1="5" y1="15.5" x2="8.5" y2="15.5" data-v-794a58ae></line><line x1="14.5" y1="12" x2="19" y2="12" data-v-794a58ae></line><line x1="14.5" y1="15.5" x2="18" y2="15.5" data-v-794a58ae></line>',7)])])):t.name==="layout-cols-header"||t.name==="cols-header"||t.name==="layout-three-cols-header"||t.name==="three-cols-header"?(nt(),ot("g",dp,[...i[43]||(i[43]=[ge('<rect x="2" y="4" width="20" height="16" rx="2" data-v-794a58ae></rect><line x1="5" y1="7.5" x2="13" y2="7.5" data-v-794a58ae></line><line x1="9.3" y1="10.5" x2="9.3" y2="18.5" stroke-dasharray="1.5 1.5" data-v-794a58ae></line><line x1="14.7" y1="10.5" x2="14.7" y2="18.5" stroke-dasharray="1.5 1.5" data-v-794a58ae></line><line x1="4.5" y1="12" x2="7.5" y2="12" data-v-794a58ae></line><line x1="4.5" y1="15.5" x2="7" y2="15.5" data-v-794a58ae></line><line x1="10.5" y1="12" x2="13.5" y2="12" data-v-794a58ae></line><line x1="10.5" y1="15.5" x2="13.5" y2="15.5" data-v-794a58ae></line><line x1="16" y1="12" x2="19.5" y2="12" data-v-794a58ae></line><line x1="16" y1="15.5" x2="18.5" y2="15.5" data-v-794a58ae></line>',10)])])):t.name==="layout-clover"||t.name==="clover"?(nt(),ot("g",up,[...i[44]||(i[44]=[ge('<rect x="2" y="4" width="20" height="16" rx="2" data-v-794a58ae></rect><line x1="5" y1="7" x2="13" y2="7" data-v-794a58ae></line><line x1="4.5" y1="13.5" x2="19.5" y2="13.5" stroke-dasharray="1.5 1.5" data-v-794a58ae></line><line x1="12" y1="9" x2="12" y2="18.5" stroke-dasharray="1.5 1.5" data-v-794a58ae></line><line x1="5" y1="11" x2="9.5" y2="11" data-v-794a58ae></line><line x1="14.5" y1="11" x2="19" y2="11" data-v-794a58ae></line><line x1="5" y1="16" x2="9.5" y2="16" data-v-794a58ae></line><line x1="14.5" y1="16" x2="19" y2="16" data-v-794a58ae></line>',8)])])):t.name==="layout-image-right"||t.name==="image-right"?(nt(),ot("g",fp,[...i[45]||(i[45]=[ge('<rect x="2" y="4" width="20" height="16" rx="2" data-v-794a58ae></rect><line x1="12" y1="4" x2="12" y2="20" data-v-794a58ae></line><line x1="4.5" y1="8" x2="9.5" y2="8" data-v-794a58ae></line><line x1="4.5" y1="11.5" x2="10" y2="11.5" data-v-794a58ae></line><line x1="4.5" y1="14.5" x2="8" y2="14.5" data-v-794a58ae></line><circle cx="15.5" cy="8.5" r="1.2" data-v-794a58ae></circle><polyline points="13 17 15.5 13 18 16 19.5 14" data-v-794a58ae></polyline>',7)])])):t.name==="layout-image-left"||t.name==="image-left"?(nt(),ot("g",pp,[...i[46]||(i[46]=[ge('<rect x="2" y="4" width="20" height="16" rx="2" data-v-794a58ae></rect><line x1="12" y1="4" x2="12" y2="20" data-v-794a58ae></line><circle cx="6" cy="8.5" r="1.2" data-v-794a58ae></circle><polyline points="3.5 17 6 13 8.5 16 10 14" data-v-794a58ae></polyline><line x1="14.5" y1="8" x2="19.5" y2="8" data-v-794a58ae></line><line x1="14.5" y1="11.5" x2="20" y2="11.5" data-v-794a58ae></line><line x1="14.5" y1="14.5" x2="18" y2="14.5" data-v-794a58ae></line>',7)])])):t.name==="layout-center"||t.name==="center"?(nt(),ot("g",hp,[...i[47]||(i[47]=[h("rect",{x:"2",y:"4",width:"20",height:"16",rx:"2"},null,-1),h("line",{x1:"6.5",y1:"9",x2:"17.5",y2:"9"},null,-1),h("line",{x1:"5",y1:"12",x2:"19",y2:"12"},null,-1),h("line",{x1:"8",y1:"15",x2:"16",y2:"15"},null,-1)])])):t.name==="layout-fact"||t.name==="fact"?(nt(),ot("g",mp,[...i[48]||(i[48]=[ge('<rect x="2" y="4" width="20" height="16" rx="2" data-v-794a58ae></rect><circle cx="8" cy="9" r="1.5" data-v-794a58ae></circle><line x1="14" y1="8" x2="9" y2="14" data-v-794a58ae></line><circle cx="15" cy="13" r="1.5" data-v-794a58ae></circle><line x1="6.5" y1="17" x2="17.5" y2="17" data-v-794a58ae></line>',5)])])):t.name==="layout-intro"||t.name==="intro"?(nt(),ot("g",gp,[...i[49]||(i[49]=[ge('<rect x="2" y="4" width="20" height="16" rx="2" data-v-794a58ae></rect><circle cx="7.5" cy="9.5" r="2" data-v-794a58ae></circle><path d="M4.5 16.5c0-1.8 1.3-3 3-3s3 1.2 3 3" data-v-794a58ae></path><line x1="13" y1="9" x2="18.5" y2="9" data-v-794a58ae></line><line x1="13" y1="12.5" x2="19.5" y2="12.5" data-v-794a58ae></line><line x1="13" y1="15.5" x2="17" y2="15.5" data-v-794a58ae></line>',6)])])):t.name==="layout-quote"||t.name==="quote"?(nt(),ot("g",vp,[...i[50]||(i[50]=[ge('<rect x="2" y="4" width="20" height="16" rx="2" data-v-794a58ae></rect><path d="M6 7.5h2v2H6.5c0 1.2-.4 2-1.5 2.5" data-v-794a58ae></path><path d="M9.5 7.5h2v2H10c0 1.2-.4 2-1.5 2.5" data-v-794a58ae></path><line x1="6" y1="13.5" x2="18" y2="13.5" data-v-794a58ae></line><line x1="12.5" y1="16.5" x2="17.5" y2="16.5" data-v-794a58ae></line>',5)])])):t.name==="desktop"||t.name==="monitor"?(nt(),ot("g",bp,[...i[51]||(i[51]=[h("rect",{x:"2",y:"3",width:"20",height:"14",rx:"2"},null,-1),h("line",{x1:"8",y1:"21",x2:"16",y2:"21"},null,-1),h("line",{x1:"12",y1:"17",x2:"12",y2:"21"},null,-1)])])):t.name==="mobile"||t.name==="smartphone"||t.name==="phone"?(nt(),ot("g",yp,[...i[52]||(i[52]=[h("rect",{x:"5",y:"2",width:"14",height:"20",rx:"2",ry:"2"},null,-1),h("line",{x1:"12",y1:"18",x2:"12.01",y2:"18","stroke-width":"2","stroke-linecap":"round"},null,-1)])])):t.name==="type"||t.name==="heading"?(nt(),ot("g",kp,[...i[53]||(i[53]=[h("polyline",{points:"4 7 4 4 20 4 20 7"},null,-1),h("line",{x1:"9",y1:"20",x2:"15",y2:"20"},null,-1),h("line",{x1:"12",y1:"4",x2:"12",y2:"20"},null,-1)])])):t.name==="reset"||t.name==="undo"?(nt(),ot("g",wp,[...i[54]||(i[54]=[h("path",{d:"M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8"},null,-1),h("polyline",{points:"3 3 3 8 8 8"},null,-1)])])):t.name==="repeat"||t.name==="loop"?(nt(),ot("g",xp,[...i[55]||(i[55]=[h("path",{d:"m17 1 4 4-4 4"},null,-1),h("path",{d:"M3 11V9a4 4 0 0 1 4-4h14"},null,-1),h("path",{d:"m7 23-4-4 4-4"},null,-1),h("path",{d:"M21 13v2a4 4 0 0 1-4 4H3"},null,-1)])])):t.name==="volume-x"||t.name==="mute"?(nt(),ot("g",Sp,[...i[56]||(i[56]=[h("polygon",{points:"11 5 6 9 2 9 2 15 6 15 11 19 11 5"},null,-1),h("line",{x1:"22",y1:"9",x2:"16",y2:"15"},null,-1),h("line",{x1:"16",y1:"9",x2:"22",y2:"15"},null,-1)])])):t.name==="sliders"||t.name==="controls"?(nt(),ot("g",_p,[...i[57]||(i[57]=[ge('<line x1="4" y1="21" x2="4" y2="14" data-v-794a58ae></line><line x1="4" y1="10" x2="4" y2="3" data-v-794a58ae></line><line x1="12" y1="21" x2="12" y2="12" data-v-794a58ae></line><line x1="12" y1="8" x2="12" y2="3" data-v-794a58ae></line><line x1="20" y1="21" x2="20" y2="16" data-v-794a58ae></line><line x1="20" y1="12" x2="20" y2="3" data-v-794a58ae></line><line x1="1" y1="14" x2="7" y2="14" data-v-794a58ae></line><line x1="9" y1="8" x2="15" y2="8" data-v-794a58ae></line><line x1="17" y1="16" x2="23" y2="16" data-v-794a58ae></line>',9)])])):t.name==="package"||t.name==="zip"||t.name==="archive"?(nt(),ot("g",Cp,[...i[58]||(i[58]=[h("line",{x1:"16.5",y1:"9.4",x2:"7.5",y2:"4.21"},null,-1),h("path",{d:"M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"},null,-1),h("polyline",{points:"3.27 6.96 12 12.01 20.73 6.96"},null,-1),h("line",{x1:"12",y1:"22.08",x2:"12",y2:"12"},null,-1)])])):t.name==="folder"?(nt(),ot("g",$p,[...i[59]||(i[59]=[h("path",{d:"M4 20h16a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2h-7.93a2 2 0 0 1-1.66-.9l-.82-1.2A2 2 0 0 0 7.93 3H4a2 2 0 0 0-2 2v13c0 1.1.9 2 2 2Z"},null,-1)])])):t.name==="rocket"?(nt(),ot("g",Ip,[...i[60]||(i[60]=[h("path",{d:"M4.5 16.5c-1.5 1.26-2 5-2 5s3.74-.5 5-2c.71-.84.7-2.13-.09-2.91a2.18 2.18 0 0 0-2.91-.09z"},null,-1),h("path",{d:"m12 15-3-3a22 22 0 0 1 2-3.95A12.88 12.88 0 0 1 22 2c0 2.72-.78 7.5-6 11a22.35 22.35 0 0 1-4 2z"},null,-1),h("path",{d:"M9 12H4s.55-3.03 2-4c1.62-1.08 5 0 5 0"},null,-1),h("path",{d:"M12 15v5s3.03-.55 4-2c1.08-1.62 0-5 0-5"},null,-1)])])):t.name==="wand"||t.name==="magic"?(nt(),ot("g",Ap,[...i[61]||(i[61]=[h("path",{d:"m19 2 2 2-6 6-2-2Z"},null,-1),h("path",{d:"m13 8 2 2"},null,-1),h("path",{d:"m3 21 9-9"},null,-1)])])):t.name==="image-left"?(nt(),ot("g",Bp,[...i[62]||(i[62]=[ge('<rect x="2" y="4" width="20" height="16" rx="2" data-v-794a58ae></rect><rect x="4" y="6" width="6" height="12" rx="1" data-v-794a58ae></rect><line x1="13" y1="8" x2="19" y2="8" data-v-794a58ae></line><line x1="13" y1="12" x2="19" y2="12" data-v-794a58ae></line><line x1="13" y1="16" x2="17" y2="16" data-v-794a58ae></line>',5)])])):t.name==="image-right"?(nt(),ot("g",Tp,[...i[63]||(i[63]=[ge('<rect x="2" y="4" width="20" height="16" rx="2" data-v-794a58ae></rect><rect x="14" y="6" width="6" height="12" rx="1" data-v-794a58ae></rect><line x1="5" y1="8" x2="11" y2="8" data-v-794a58ae></line><line x1="5" y1="12" x2="11" y2="12" data-v-794a58ae></line><line x1="5" y1="16" x2="9" y2="16" data-v-794a58ae></line>',5)])])):(nt(),ot("g",Ep,[...i[64]||(i[64]=[h("rect",{x:"2",y:"3",width:"20",height:"14",rx:"2"},null,-1),h("line",{x1:"8",y1:"21",x2:"16",y2:"21"},null,-1),h("line",{x1:"12",y1:"17",x2:"12",y2:"21"},null,-1)])]))]))}}),ze=(t,e)=>{const i=t.__vccOpts||t;for(const[n,o]of e)i[n]=o;return i},ut=ze(Mp,[["__scopeId","data-v-794a58ae"]]);function Zt(t,e){var o;if(typeof document>"u"||!t)return;const i=(o=globalThis.CSS)!=null&&o.escape?globalThis.CSS.escape(t):t.replace(/"/g,'\\"'),n=document.querySelectorAll(`[data-node-id="${i}"]`);!n||n.length===0||n.forEach(s=>{for(const[l,r]of Object.entries(e))r!=null&&r!==""?s.setAttribute(l,String(r)):s.removeAttribute(l)})}function Lp(t){if(typeof document>"u")return;const e=`.protyle-wysiwyg [${ht}], .protyle-wysiwyg [${qt}], .protyle-wysiwyg [custom-slidev-layout], .protyle-wysiwyg [custom-slidev-role]`,i=document.querySelectorAll(e);!i||i.length===0||i.forEach(n=>{const o=n.getAttribute("data-node-id");if(!o){n.removeAttribute(ht),n.removeAttribute("custom-slidev-layout"),n.removeAttribute(qt),n.removeAttribute("custom-slidev-role");return}const s=t.get(o),l=(s==null?void 0:s[ht])||(s==null?void 0:s["custom-slidev-layout"])||"",r=n.getAttribute(ht)||n.getAttribute("custom-slidev-layout");r&&r!==l&&(l?n.setAttribute(ht,l):(n.removeAttribute(ht),n.removeAttribute("custom-slidev-layout")));const a=(s==null?void 0:s[qt])||(s==null?void 0:s["custom-slidev-role"])||"",c=n.getAttribute(qt)||n.getAttribute("custom-slidev-role");c&&c!==a&&(a?n.setAttribute(qt,a):(n.removeAttribute(qt),n.removeAttribute("custom-slidev-role")))})}const Dp={class:"spm-layout-picker"},Pp={class:"spm-layout-picker__grid"},Op=["title","onClick"],Rp={class:"spm-layout-icon"},zp={class:"spm-layout-label"},Np=Ce({__name:"LayoutPicker",props:{modelValue:{}},emits:["update:modelValue","change"],setup(t,{emit:e}){const i=t,n=e,o=[{name:"cover",label:"封面",desc:"大标题与副标题封面页"},{name:"default",label:"标准",desc:"标题在上方，内容在下方"},{name:"two-cols",label:"双栏",desc:"左右双栏对比展示"},{name:"cols-header",label:"表头多栏",desc:"顶部通栏标题，下方自适应 2~N 栏"},{name:"clover",label:"四叶草",desc:"4 项超级块 2x2 田字型四象限卡片布局"},{name:"image-right",label:"图右",desc:"左侧为内容，右侧全屏背景图"},{name:"image-left",label:"图左",desc:"左侧全屏背景图，右侧为内容"},{name:"center",label:"居中",desc:"内容全屏垂直水平居中"},{name:"fact",label:"大字报",desc:"核心数据或指标突出展示"},{name:"intro",label:"介绍",desc:"演讲者自我介绍或章节导览"},{name:"quote",label:"引言",desc:"名人名言与强调段落"}];function s(r){return i.modelValue===r||r==="cols-header"&&(i.modelValue==="two-cols-header"||i.modelValue==="three-cols-header")}function l(r){n("update:modelValue",r),n("change",r)}return(r,a)=>(nt(),ot("div",Dp,[a[0]||(a[0]=h("div",{class:"spm-layout-picker__header"},"选择页面版式",-1)),h("div",Pp,[(nt(),ot(Kt,null,xe(o,c=>h("div",{key:c.name,class:At(["spm-layout-item",{active:s(c.name)}]),title:c.desc,onClick:u=>l(c.name)},[h("div",Rp,[dt(ut,{name:"layout-"+c.name},null,8,["name"])]),h("span",zp,_t(c.label),1)],10,Op)),64))])]))}}),ua=ze(Np,[["__scopeId","data-v-3d2599ad"]]),Fp={key:0,class:"spm-transition-selector__header"},Hp={class:"spm-transition-list"},jp=["onClick"],Up={class:"spm-transition-meta"},Wp={class:"spm-transition-label"},Vp={class:"spm-transition-name"},qp={class:"spm-transition-preview-box"},Kp=Ce({__name:"TransitionSelector",props:{modelValue:{},hideHeader:{type:Boolean},title:{}},emits:["update:modelValue","change"],setup(t,{emit:e}){const i=e,n=[{name:"slide-left",label:"向左滑入",desc:"向左滑入 (slide-left)：页面从右侧向左平滑推入，最通用标准的横向幻灯片动效"},{name:"slide-right",label:"向右滑入",desc:"向右滑入 (slide-right)：页面从左侧向右平滑推入，适合倒序回退或逆向章节叙述"},{name:"slide-up",label:"向上推入",desc:"向上推入 (slide-up)：页面从底部向上平滑推入，适合纵向展开或纵深层级展示"},{name:"fade",label:"淡入淡出",desc:"淡入淡出 (fade)：透明度平滑渐变过度，典雅柔和，适合学术长篇与沉浸叙事"},{name:"zoom",label:"缩放进入",desc:"缩放进入 (zoom)：页面由中心向外平滑放大，富有动感冲击力，适合聚焦重点"}];function o(s){i("update:modelValue",s),i("change",s)}return(s,l)=>(nt(),ot("div",{class:At(["spm-transition-selector",{"spm-transition-selector--no-header":t.hideHeader}])},[t.hideHeader?Ot("",!0):(nt(),ot("div",Fp,_t(t.title||"转场动效"),1)),h("div",Hp,[(nt(),ot(Kt,null,xe(n,r=>h("div",{key:r.name,class:At(["spm-transition-item",{active:t.modelValue===r.name}]),onClick:a=>o(r.name)},[h("div",Up,[h("span",Wp,_t(r.label),1),h("span",Vp,"("+_t(r.name)+")",1)]),h("div",qp,[h("div",{class:At(["spm-anim-cube","anim-"+r.name])},null,2)])],10,jp)),64))])],2))}}),Hs=ze(Kp,[["__scopeId","data-v-b0aa61ff"]]),Gp={class:"spm-divider-popover"},Zp={class:"spm-divider-popover__title"},Yp={class:"spm-form-item"},Jp={class:"spm-popover-footer"},Xp={class:"spm-save-hint"},Qp=Ce({__name:"QuickDividerPopover",props:{blockId:{},initialAttrs:{}},emits:["close","updated"],setup(t,{emit:e}){var g,d,b;const i=t,n=e,o=vt(((g=i.initialAttrs)==null?void 0:g[ht])||"default"),s=vt(((d=i.initialAttrs)==null?void 0:d[te])||"slide-left"),l=vt(((b=i.initialAttrs)==null?void 0:b[Ut])||""),r=vt("");Di(()=>i.initialAttrs,f=>{o.value=(f==null?void 0:f[ht])||"default",s.value=(f==null?void 0:f[te])||"slide-left",l.value=(f==null?void 0:f[Ut])||""},{deep:!0});async function a(f,v){if(i.blockId){r.value="正在同步...",Lt.setBlockAttrOverride(i.blockId,{[f]:v}),Zt(i.blockId,{[f]:v});try{await Et(i.blockId,{[f]:v}),r.value="已同步至块属性",n("updated",{[f]:v}),setTimeout(()=>{r.value=""},1500)}catch{r.value="同步失败"}}}function c(f){a(ht,f)}function u(f){a(te,f)}function m(){a(Ut,l.value.trim())}return(f,v)=>(nt(),ot("div",Gp,[h("div",Zp,[v[4]||(v[4]=h("span",null,"幻灯片页面设置",-1)),h("button",{class:"spm-close-btn",onClick:v[0]||(v[0]=k=>n("close"))},"✕")]),dt(ua,{modelValue:o.value,"onUpdate:modelValue":v[1]||(v[1]=k=>o.value=k),onChange:c},null,8,["modelValue"]),dt(Hs,{modelValue:s.value,"onUpdate:modelValue":v[2]||(v[2]=k=>s.value=k),onChange:u},null,8,["modelValue"]),h("div",Yp,[v[5]||(v[5]=h("label",{class:"spm-form-label"},"页面背景",-1)),Te(h("input",{"onUpdate:modelValue":v[3]||(v[3]=k=>l.value=k),class:"spm-input",placeholder:"assets/bg.jpg 或颜色值 (#1e1e24)",onBlur:m},null,544),[[vo,l.value]])]),h("div",Jp,[h("span",Xp,_t(r.value),1)])]))}}),th=ze(Qp,[["__scopeId","data-v-e4871368"]]),eh={class:"spm-slide-inspector"},ih={class:"spm-inspector-header"},nh={class:"spm-inspector-list"},oh=["onClick"],sh={class:"spm-card-top"},rh={class:"spm-card-badge"},lh={class:"spm-card-layout"},ah=["onClick"],ch={class:"spm-card-preview"},dh={key:0,class:"spm-card-notes",title:"演讲备忘录"},uh={class:"spm-inspector-modal-content"},fh=Ce({__name:"SlideInspector",props:{slides:{},currentActivePage:{}},emits:["navigate","refresh"],setup(t,{emit:e}){const i=e,n=vt(null);function o(c){n.value=c}function s(c){const u={};return c.frontmatter.layout&&(u[ht]=c.frontmatter.layout),c.frontmatter.transition&&(u[te]=c.frontmatter.transition),c.frontmatter.background&&(u[Ut]=c.frontmatter.background),c.notes&&(u[Wi]=c.notes),u}function l(c){n.value&&(c[ht]&&(n.value.frontmatter.layout=c[ht]),c[te]&&(n.value.frontmatter.transition=c[te]),c[Ut]&&(n.value.frontmatter.background=c[Ut]),c[Wi]&&(n.value.notes=c[Wi]),i("refresh"))}function r(c){i("navigate",c)}function a(c){if(!c.blocks||c.blocks.length===0)return"(空白页)";const u=c.blocks[0],m=u.content||u.rawMarkdown||"";return m.slice(0,40)+(m.length>40?"...":"")}return(c,u)=>(nt(),ot("div",eh,[h("div",ih,[h("span",null,"幻灯片大纲 ("+_t(t.slides.length)+" 页)",1)]),h("div",nh,[(nt(!0),ot(Kt,null,xe(t.slides,m=>(nt(),ot("div",{key:m.pageIndex,class:At(["spm-card",{active:t.currentActivePage===m.pageIndex}]),onClick:g=>r(m.pageIndex)},[h("div",sh,[h("span",rh,"P"+_t(m.pageIndex),1),h("span",lh,_t(m.frontmatter.layout||"default"),1),h("button",{class:"spm-card-btn-edit",title:"配置此页版式与属性",onClick:Me(g=>o(m),["stop"])},[dt(ut,{name:"settings"})],8,ah)]),h("div",ch,_t(a(m)),1),m.notes?(nt(),ot("div",dh,[dt(ut,{name:"notes",style:{"font-size":"11px","margin-right":"3px"}}),h("span",null,_t(m.notes),1)])):Ot("",!0)],10,oh))),128))]),n.value?(nt(),ot("div",{key:0,class:"spm-inspector-modal-mask",onClick:u[1]||(u[1]=Me(m=>n.value=null,["self"]))},[h("div",uh,[dt(th,{"block-id":n.value.startBlockId,"initial-attrs":s(n.value),onClose:u[0]||(u[0]=m=>n.value=null),onUpdated:l},null,8,["block-id","initial-attrs"])])])):Ot("",!0)]))}}),ph=ze(fh,[["__scopeId","data-v-68b25edd"]]),hh={class:"spm-immersion-header"},mh={class:"spm-immersion-header__left"},gh={class:"spm-immersion-title"},vh={class:"spm-immersion-header__center"},bh={class:"spm-immersion-header__actions"},yh=["aria-label"],kh={class:"spm-immersion-body"},wh=Ce({__name:"ImmersionDrawerContainer",props:{visible:{type:Boolean,default:!1},isMaximized:{type:Boolean,default:!1},title:{default:"速览"},closeOnClickMask:{type:Boolean,default:!0}},emits:["update:visible","update:isMaximized","close","toggle-maximize"],setup(t,{emit:e}){const i=t,n=e;function o(){n("update:visible",!1),n("close")}function s(){i.closeOnClickMask&&o()}function l(){n("update:isMaximized",!i.isMaximized),n("toggle-maximize")}function r(a){(a.key===" "||a.key==="ArrowLeft"||a.key==="ArrowRight"||a.key==="PageUp"||a.key==="PageDown")&&a.stopPropagation(),a.key==="Escape"&&(a.preventDefault(),a.stopPropagation(),o())}return(a,c)=>Te((nt(),ot("div",{class:At(["spm-immersion-container",{"is-maximized":t.isMaximized}]),onKeydown:Me(r,["stop"])},[h("div",{class:"spm-immersion-mask",onClick:s}),h("div",{class:At(["spm-immersion-drawer",{"is-maximized":t.isMaximized}])},[h("div",hh,[h("div",mh,[qn(a.$slots,"header-left",{},()=>[h("span",gh,_t(t.title),1)])]),h("div",vh,[qn(a.$slots,"header-center",{},void 0)]),h("div",bh,[qn(a.$slots,"header-actions",{},void 0),h("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":t.isMaximized?"还原抽屉宽度 (70%)":"最大化填满视口 (100%)",onClick:l},[dt(ut,{name:t.isMaximized?"minimize":"maximize"},null,8,["name"])],8,yh),h("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"关闭速览 (ESC)",onClick:o},[dt(ut,{name:"close"})])])]),h("div",kh,[qn(a.$slots,"default",{},void 0)])],2)],34)),[[Xl,t.visible]])}}),xh=ze(wh,[["__scopeId","data-v-3f1665db"]]),Sh={class:"spm-protyle-drawer"},_h={class:"spm-protyle-drawer__subbar"},Ch={class:"spm-protyle-drawer__nav"},$h=["title"],Ih={class:"spm-protyle-drawer__actions"},Ah=["aria-label"],Bh=["aria-label"],Th=Ce({__name:"ProtylePeekDrawer",props:{blockId:{},title:{},plugin:{}},emits:["external-jump"],setup(t,{emit:e}){const i=e,n=t,o=vt(n.blockId),s=vt(n.title||""),l=vt(!1),r=vt(!0),a=vt(!1),c=vt(""),u=mi,m=vt([]),g=vt(null);let d=null;Di(()=>n.blockId,w=>{w&&w!==o.value&&(o.value=w,s.value=n.title||"",m.value=[],f(w))}),Rn(()=>{o.value&&f(o.value)}),Bs(()=>{v()});async function b(w){try{const F=await wn(`SELECT id, root_id, type, content FROM blocks WHERE id = '${w}' LIMIT 1`);if(Array.isArray(F)&&F.length>0){const H=F[0];c.value=H.root_id||"";const j=H.id===H.root_id||H.type==="d";a.value=j,r.value=!j,!s.value&&H.content&&(s.value=H.content.trim().slice(0,30));return}}catch(F){console.warn("[ProtylePeekDrawer] detectBlockType query failed:",F)}a.value=!1,r.value=!0}async function f(w,F){if(!g.value||!w)return;v(),await b(w),typeof F=="boolean"&&(r.value=!a.value&&F);let H,j;r.value&&!a.value?(H=["cb-get-all","cb-get-hl","cb-get-focus"],j={background:!1,title:!1,gutter:!0,breadcrumbDocName:!0,scroll:!0}):(H=["cb-get-context","cb-get-hl"],j={background:!0,title:!0,gutter:!0,breadcrumbDocName:!0,scroll:!0});try{d=new ft.Protyle(n.plugin.app,g.value,{blockId:w,action:H,render:j}),!l.value&&d&&typeof d.disable=="function"&&d.disable()}catch(J){console.error("[ProtylePeekDrawer] Failed to instantiate Protyle:",J)}}function v(){if(d){try{typeof d.destroy=="function"&&d.destroy()}catch(w){console.warn("[ProtylePeekDrawer] Error destroying protyle:",w)}d=null}g.value&&(g.value.innerHTML="")}function k(){a.value||(r.value=!r.value,f(o.value,r.value))}function S(){l.value=!l.value,d&&(l.value?(typeof d.enable=="function"&&d.enable(),typeof d.focus=="function"&&d.focus()):typeof d.disable=="function"&&d.disable())}function x(){if(o.value)try{ft.openWindow({doc:{id:o.value},alwaysOnTop:!0})}catch(w){console.warn("[ProtylePeekDrawer] openWindow failed:",w)}}function B(){var H;if(!o.value)return;const w=Mo(),F=ea(w.webServeUrl,o.value,{focus:!a.value});if(typeof window<"u"){const j=_e("electron");(H=j==null?void 0:j.shell)!=null&&H.openExternal?j.shell.openExternal(F).catch(()=>{window.open(F,"_blank")}):window.open(F,"_blank")}i("external-jump",F)}function E(){if(m.value.length>0){const w=m.value.pop();w&&(o.value=w.blockId,s.value=w.title,r.value=w.isFocusMode,a.value=w.isDoc,f(w.blockId,w.isFocusMode))}}function A(w){const F=w.target;if(!F)return;const H=F.closest('[data-type="block-ref"]');if(H){const J=H.getAttribute("data-id");if(J&&J!==o.value){w.preventDefault(),w.stopPropagation(),m.value.push({blockId:o.value,title:s.value||o.value,isFocusMode:r.value,isDoc:a.value}),o.value=J,s.value=H.innerText.trim()||J,f(J);return}}const j=F.closest("a");if(j&&j.href&&j.href.startsWith("siyuan://blocks/")){w.preventDefault(),w.stopPropagation();const J=j.href.replace("siyuan://blocks/","").split("?")[0];J&&J!==o.value&&(m.value.push({blockId:o.value,title:s.value||o.value,isFocusMode:r.value,isDoc:a.value}),o.value=J,s.value=j.innerText.trim()||J,f(J))}}return(w,F)=>(nt(),ot("div",Sh,[h("div",_h,[h("div",Ch,[m.value.length>0?(nt(),ot("button",{key:0,class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"返回上层引用文档或块",onClick:E},[dt(ut,{name:"arrow-left"}),F[0]||(F[0]=h("span",null,"返回",-1))])):Ot("",!0),h("span",{class:At(["spm-protyle-badge",{"is-focus":r.value&&!a.value}])},_t(r.value&&!a.value?"思源块聚焦":"思源文档速览"),3),h("span",{class:"spm-protyle-id",title:s.value||o.value},_t(s.value||o.value),9,$h)]),h("div",Ih,[a.value?Ot("",!0):(nt(),ot("button",{key:0,class:At(["spm-icon-btn b3-tooltips b3-tooltips__s",{"is-primary":r.value}]),"aria-label":r.value?"当前为块聚焦模式（点击展开所属文档全文）":"当前为文档全文模式（点击切回仅聚焦当前块）",onClick:k},[dt(ut,{name:r.value?"focus":"file-text"},null,8,["name"]),h("span",null,_t(r.value?"块聚焦":"展开全文"),1)],10,Ah)),h("button",{class:At(["spm-icon-btn b3-tooltips b3-tooltips__s",{"is-primary":l.value}]),"aria-label":l.value?"当前为即时编辑模式（点击切回只读）":"当前为只读速览模式（点击解锁即时编辑）",onClick:S},[dt(ut,{name:l.value?"edit":"eye"},null,8,["name"]),h("span",null,_t(l.value?"编辑中":"只读"),1)],10,Bh),h("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"在置顶独立窗口中打开 (保留完整侧边栏与插件)",onClick:x},[dt(ut,{name:"window"}),F[1]||(F[1]=h("span",null,"独立窗口",-1))]),bt(u).enableWebServeJump?(nt(),ot("button",{key:1,class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"在系统默认浏览器中打开 (外跳)",onClick:B},[dt(ut,{name:"external-link"}),F[2]||(F[2]=h("span",null,"外跳",-1))])):Ot("",!0)])]),h("div",{ref_key:"mountEl",ref:g,class:At(["spm-protyle-mount",{"is-focus-mode":r.value&&!a.value}]),onClick:A},null,2)]))}}),Eh=ze(Th,[["__scopeId","data-v-7e586ef3"]]),Mh=/^(https?|file|data|blob|mailto|tel|ftp|ftps|siyuan|about|chrome|ws|wss):/i,Lh=/\.(html?|xhtml|pdf|png|jpe?g|gif|svg|webp|avif|ico|mp4|webm|mov|mp3|wav|m4a|ogg|json|md|markdown|txt|csv|zip|tar|gz|7z|rar|js|mjs|css|xml|yaml|yml|toml|ipynb|docx?|xlsx?|pptx?)$/i;function Tr(t){let e=t||"";try{e=decodeURIComponent(e)}catch{}e=e.replace(/\\/g,"/");const i=/(?:^|\/)data\/assets\/(.+)$/i.exec(e);if(i)return`/assets/${i[1]}`;const n=/(?:^|\/)data\/plugins\/(.+)$/i.exec(e);return n?`/plugins/${n[1]}`:null}function fa(t){const e=(t||"").replace(/^file:\/\//i,"");let i=e;try{i=decodeURIComponent(e)}catch{}if(i.startsWith("/"))return/^\/([a-zA-Z]:[\\/])/.exec(i)?i.slice(1):i;const n=i.indexOf("/");return n>=0?i.slice(n):i}function Dh(t){const e=t.split(/[/?#]/)[0];return!e||Lh.test(e)?!1:/^(localhost|\d{1,3}(\.\d{1,3}){3})(:\d+)?$/i.test(e)?!0:/^[a-z0-9-]+(\.[a-z0-9-]+)+(:\d+)?$/i.test(e)}function Ph(t){const e=t.indexOf("#"),i=e>=0?t.slice(e):"",n=e>=0?t.slice(0,e):t,o=n.indexOf("?"),s=o>=0?n.slice(0,o):n,l=o>=0?n.slice(o+1):"";if(!/^\/?assets\/.+\.html?$/i.test(s))return t;const r=new URLSearchParams(l);return r.get("iframe")==="true"||r.get("download")==="true"?t:(r.set("iframe","true"),`${s}?${r.toString()}${i}`)}function pa(t){const e=Oh(t);return e.external||!e.url?e:{url:Ph(e.url),external:!1}}function Oh(t){const e=(t||"").trim();if(!e)return{url:"",external:!1};if(/^https?:\/\//i.test(e))return{url:e,external:!1};if(e.startsWith("//"))return{url:`https:${e}`,external:!1};if(/^(siyuan|data|blob|about):/i.test(e))return{url:e,external:!1};if(Vr(e))return{url:`/${qr(e)}`,external:!1};if(/^file:/i.test(e)){const n=Tr(fa(e));return n?{url:n,external:!1}:{url:e,external:!0}}if(/^[a-zA-Z]:[\\/]/.test(e)||e.startsWith("\\\\")){const n=Tr(e);return n?{url:n,external:!1}:{url:e,external:!0}}return Mh.test(e)?{url:e,external:!0}:Dh(e)?{url:`https://${e}`,external:!1}:{url:`/${e.replace(/^(?:\.{1,2}\/)+/,"").replace(/^\/+/,"")}`,external:!1}}const Rh={class:"spm-webview-drawer"},zh={class:"spm-webview-toolbar"},Nh={class:"spm-webview-toolbar__nav"},Fh=["disabled"],Hh=["disabled"],jh=["aria-label"],Uh={class:"spm-webview-toolbar__address"},Wh=["aria-label"],Vh={class:"spm-webview-toolbar__actions"},qh=["aria-label"],Kh={class:"spm-zoom-controller"},Gh=["disabled"],Zh=["disabled"],Yh={key:1,class:"spm-webview-fallback"},Jh=["src"],Er="Mozilla/5.0 (iPhone; CPU iPhone OS 17_4_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.4.1 Mobile/15E148 Safari/604.1",ha="siyuan-slidev-peek-view-mode";let ma="desktop";function Xh(){if(typeof window<"u"&&window.localStorage)try{const t=window.localStorage.getItem(ha);if(t==="mobile"||t==="desktop")return t}catch{}return ma}function Qh(t){if(ma=t,typeof window<"u"&&window.localStorage)try{window.localStorage.setItem(ha,t)}catch{}}const tm=Ce({__name:"WebviewPeekDrawer",props:{url:{},title:{},visible:{type:Boolean,default:!0}},emits:["external-jump"],setup(t,{emit:e}){const i=e,n=t,o=vt(aa()&&!af()),s=vt(n.url),l=vt(n.url),r=vt(!1),a=vt(!1),c=vt(!1),u=vt(1),m=vt(!1),g=vt(Xh());let d=typeof navigator<"u"&&!navigator.userAgent.includes("iPhone")?navigator.userAgent:"";const b=St(()=>g.value==="mobile"?Er:d||void 0),f=vt(null),v=vt(null);let k=null,S=null,x=null;Di(()=>n.url,P=>{P&&P!==s.value&&(s.value=P,l.value=P,g.value==="mobile"&&F(!1),f.value&&typeof f.value.loadURL=="function"&&f.value.loadURL(P))}),Di(()=>n.visible,P=>{if(P)W(),g.value==="mobile"&&F(!1);else if(f.value)try{typeof f.value.stop=="function"&&f.value.stop()}catch{}}),Rn(()=>{B(),v.value&&typeof ResizeObserver<"u"&&(k=new ResizeObserver(()=>{const P=f.value;if(P&&typeof P.invalidate=="function")try{P.invalidate()}catch{}}),k.observe(v.value)),S=P=>{var rt;const ct=P.message||((rt=P.error)==null?void 0:rt.message);if(typeof ct=="string"&&ct.includes("Invalid guestInstanceId"))return P.preventDefault(),P.stopImmediatePropagation(),!0},window.addEventListener("error",S,!0),x=P=>{const ct=P.reason,rt=typeof ct=="string"?ct:ct==null?void 0:ct.message;typeof rt=="string"&&rt.includes("Invalid guestInstanceId")&&P.preventDefault()},window.addEventListener("unhandledrejection",x)}),Bs(()=>{if(E(),k&&(k.disconnect(),k=null),S&&(window.removeEventListener("error",S,!0),S=null),x&&(window.removeEventListener("unhandledrejection",x),x=null),f.value)try{typeof f.value.stop=="function"&&f.value.stop()}catch{}});function B(){const P=f.value;P&&(P.addEventListener("dom-ready",A),P.addEventListener("did-start-loading",H),P.addEventListener("did-stop-loading",j),P.addEventListener("did-navigate",J),P.addEventListener("did-navigate-in-page",I),P.addEventListener("new-window",N))}function E(){const P=f.value;if(P)try{P.removeEventListener("dom-ready",A),P.removeEventListener("did-start-loading",H),P.removeEventListener("did-stop-loading",j),P.removeEventListener("did-navigate",J),P.removeEventListener("did-navigate-in-page",I),P.removeEventListener("new-window",N)}catch{}}function A(){const P=f.value;if(P&&typeof P.getUserAgent=="function"&&!d)try{const ct=P.getUserAgent();ct&&!ct.includes("iPhone")&&(d=ct)}catch{}g.value==="mobile"&&F(!1),W(),y()}function w(){const P=g.value==="mobile"?"desktop":"mobile";g.value=P,Qh(P),F(!0)}function F(P=!1){const ct=f.value;if(!ct)return;const rt=g.value==="mobile"?Er:d;if(typeof ct.setUserAgent=="function"&&rt)try{ct.setUserAgent(rt)}catch(st){console.warn("[WebviewPeekDrawer] setUserAgent error:",st)}if(P&&typeof ct.reload=="function")try{ct.reload()}catch(st){console.warn("[WebviewPeekDrawer] reload error:",st)}}function H(){r.value=!0}function j(){if(r.value=!1,y(),f.value&&typeof f.value.getURL=="function"){const P=f.value.getURL();P&&P!=="about:blank"&&(s.value=P,l.value=P)}}function J(P){P!=null&&P.url&&(s.value=P.url,l.value=P.url),y()}function I(P){P!=null&&P.url&&(s.value=P.url,l.value=P.url),y()}function N(P){P&&P.url&&(P.preventDefault(),f.value&&typeof f.value.loadURL=="function"&&f.value.loadURL(P.url))}function y(){const P=f.value;P&&(typeof P.canGoBack=="function"&&(a.value=P.canGoBack()),typeof P.canGoForward=="function"&&(c.value=P.canGoForward()))}function V(){f.value&&typeof f.value.goBack=="function"&&f.value.goBack()}function X(){f.value&&typeof f.value.goForward=="function"&&f.value.goForward()}function R(){f.value&&typeof f.value.reload=="function"&&f.value.reload()}function U(){const P=pa(l.value);if(P.url){if(P.external){s.value=P.url,Q();return}s.value=P.url,l.value=P.url,f.value&&typeof f.value.loadURL=="function"&&f.value.loadURL(P.url)}}function W(){const P=f.value;if(P&&typeof P.setZoomFactor=="function")try{P.setZoomFactor(u.value)}catch(ct){console.warn("[WebviewPeekDrawer] setZoomFactor error:",ct)}}function tt(){u.value=Math.min(2.5,Math.round((u.value+.1)*10)/10),W()}function T(){u.value=Math.max(.5,Math.round((u.value-.1)*10)/10),W()}function M(){u.value=1,W()}function Y(P){P.preventDefault(),P.deltaY<0?tt():P.deltaY>0&&T()}async function Z(){if(typeof navigator<"u"&&navigator.clipboard)try{await navigator.clipboard.writeText(s.value),m.value=!0,setTimeout(()=>{m.value=!1},2e3)}catch(P){console.warn("Copy url failed:",P)}}function Q(){var ct;const P=s.value;if(typeof window<"u"){const rt=_e("electron");(ct=rt==null?void 0:rt.shell)!=null&&ct.openExternal?rt.shell.openExternal(P).catch(()=>{window.open(P,"_blank")}):window.open(P,"_blank")}i("external-jump",P)}return(P,ct)=>{const rt=wd("webview");return nt(),ot("div",Rh,[h("div",zh,[h("div",Nh,[h("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s",disabled:!a.value,"aria-label":"后退",onClick:V},[dt(ut,{name:"arrow-left"})],8,Fh),h("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s",disabled:!c.value,"aria-label":"前进",onClick:X},[dt(ut,{name:"arrow-right"})],8,Hh),h("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":r.value?"正在加载...":"刷新页面",onClick:R},[dt(ut,{name:"refresh"})],8,jh)]),h("div",Uh,[Te(h("input",{"onUpdate:modelValue":ct[0]||(ct[0]=st=>l.value=st),type:"text",class:"b3-text-field spm-url-input",placeholder:"https://...",spellcheck:"false",onKeydown:Ou(U,["enter"])},null,544),[[vo,l.value]]),h("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":m.value?"已复制地址！":"复制网址",onClick:Z},[dt(ut,{name:"copy"})],8,Wh)]),h("div",Vh,[h("button",{class:At(["spm-icon-btn spm-mode-toggle b3-tooltips b3-tooltips__s",{"is-active":g.value==="mobile"}]),"aria-label":g.value==="mobile"?"当前为手机视图，点击切换为桌面视图":"当前为桌面视图，点击切换为手机视图",onClick:w},[dt(ut,{name:g.value==="mobile"?"mobile":"desktop"},null,8,["name"])],10,qh),h("div",Kh,[h("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"缩小 (Ctrl + -)",disabled:u.value<=.5,onClick:T},[dt(ut,{name:"minus"})],8,Gh),h("button",{class:"spm-zoom-badge b3-tooltips b3-tooltips__s","aria-label":"重置 100% (Ctrl + 0)",onClick:M},_t(Math.round(u.value*100))+"% ",1),h("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"放大 (Ctrl + +)",disabled:u.value>=2.5,onClick:tt},[dt(ut,{name:"plus"})],8,Zh)]),h("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"在系统默认浏览器中打开 ↗",onClick:Q},[dt(ut,{name:"external-link"}),ct[1]||(ct[1]=h("span",null,"外跳",-1))])])]),h("div",{ref_key:"containerEl",ref:v,class:At(["spm-webview-body",{"is-mobile":g.value==="mobile"}]),onWheel:Me(Y,["ctrl"])},[h("div",{class:At(["spm-webview-viewport",{"is-mobile":g.value==="mobile"}])},[o.value?(nt(),Le(rt,{key:0,ref_key:"webviewRef",ref:f,class:"spm-webview-frame",src:s.value,useragent:b.value,allowpopups:"true",partition:"persist:slidev-peek",style:{position:"absolute",top:"0",left:"0",width:"100%",height:"100%",display:"inline-flex"}},null,8,["src","useragent"])):(nt(),ot("div",Yh,[h("iframe",{class:"spm-webview-fallback-frame",src:s.value,frameborder:"0",sandbox:"allow-scripts allow-same-origin allow-forms allow-popups"},null,8,Jh),h("div",{class:"spm-fallback-bar"},[ct[2]||(ct[2]=h("span",null,"如页面受同源策略 (X-Frame-Options) 拦截无法显示，请",-1)),h("button",{class:"spm-icon-btn is-primary",onClick:Q}," 在新标签页中打开 ↗ ")])]))],2)],34)])}}}),em=ze(tm,[["__scopeId","data-v-ae86a3d2"]]);class im{constructor(){xt(this,"timers",new Map)}debounce(e,i,n=150){this.cancel(e);const o=setTimeout(()=>{this.timers.delete(e),i()},n);this.timers.set(e,o)}cancel(e){this.timers.has(e)&&(clearTimeout(this.timers.get(e)),this.timers.delete(e))}cancelAll(){for(const e of this.timers.values())clearTimeout(e);this.timers.clear()}hasPending(e){return this.timers.has(e)}}class nm{constructor(e){xt(this,"blockToPageMap",new Map);xt(this,"debounceCtrl",new im);xt(this,"activeBlockId","");xt(this,"activePageIndex",1);xt(this,"currentDocId","");xt(this,"bridge",null);e&&(this.bridge=e)}setBridge(e){this.bridge=e}setDocId(e){this.currentDocId=e}updateSlidesIndex(e){this.blockToPageMap.clear();for(const i of e){i.startBlockId&&this.blockToPageMap.set(i.startBlockId,i.pageIndex);for(const n of i.blocks)this.blockToPageMap.set(n.id,i.pageIndex)}}getPageByBlockId(e){return this.blockToPageMap.get(e)??null}onCursorFocusBlock(e){if(!e||e===this.activeBlockId)return;this.activeBlockId=e;let i=this.getPageByBlockId(e);!i&&(e===this.currentDocId||!this.currentDocId&&this.blockToPageMap.size>0)&&(i=1),i&&this.debounceCtrl.debounce("cursor-navigate",()=>{this.activePageIndex=i,this.bridge&&(this.bridge.navigatePage(i),this.bridge.highlightElement(e))},100)}getActiveBlockId(){return this.activeBlockId}setActiveBlockId(e){this.activeBlockId=e;const i=this.getPageByBlockId(e);i&&(this.activePageIndex=i)}getActivePageIndex(){return this.activePageIndex}destroy(){this.debounceCtrl.cancelAll(),this.blockToPageMap.clear(),this.bridge=null}}function Pi(t,e){var s,l;if(!t||typeof document>"u")return!1;const i=(s=globalThis.CSS)!=null&&s.escape?globalThis.CSS.escape(t):t.replace(/"/g,'\\"'),n=document.querySelector(`.protyle-wysiwyg [data-node-id="${i}"]`)||document.querySelector(`[data-node-id="${i}"]`);if(!n){if(e)try{return ft.openTab({app:e,doc:{id:t,action:["cb-get-hl","cb-get-focus","cb-get-context"]}}),!0}catch(r){console.warn("[SelectionMirror] openTab fallback failed:",r)}return!1}try{n.scrollIntoView({behavior:"smooth",block:"center",inline:"nearest"})}catch{n.scrollIntoView()}try{(l=n.focus)==null||l.call(n,{preventScroll:!0})}catch{}n.classList.add("protyle-wysiwyg--select");const o=n.style.outline;return n.style.outline="2px solid #3b82f6",n.style.transition="outline 0.3s ease",setTimeout(()=>{n.classList.remove("protyle-wysiwyg--select"),n.style.outline=o},1200),!0}function om(t){if(!t)return"";const e=t.split(`
`).map(l=>l.trim()).filter(Boolean);if(e.length===0)return"";if(!e.some(l=>/^#{1,6}\s+/.test(l)))return e.map(l=>re(l)).join("<br/>");const n=[];let o=[];const s=()=>{if(o.length>0){const l=o.map(r=>re(r)).join("<br/>");n.push(`<p class="slide-list-item-desc">${l}</p>`),o=[]}};for(const l of e){const r=l.match(/^(#{1,6})\s+(.*)$/);if(r){s();const a=r[1].length,c=r[2].trim();n.push(`<h${a} class="slide-list-item-title">${re(c)}</h${a}>`)}else o.push(l)}return s(),n.join(`
`)}function sm(t){if(t.length===0)return"";const e=[],i=t[0],n=i.match(/^(#{1,6})\s+(.*)$/);if(n){const o=n[1].length,s=n[2].trim();e.push(`<h${o} class="slide-list-item-title">${re(s)}</h${o}>`)}else e.push(`<p class="slide-list-item-title">${re(i)}</p>`);if(t.length>1){const o=t.slice(1);let s=[];const l=()=>{if(s.length>0){const r=s.map(a=>re(a)).join("<br/>");e.push(`<p class="slide-list-item-desc">${r}</p>`),s=[]}};for(const r of o){const a=r.match(/^(#{1,6})\s+(.*)$/);if(a){l();const c=a[1].length,u=a[2].trim();e.push(`<h${c} class="slide-list-item-title">${re(u)}</h${c}>`)}else s.push(r)}l()}return e.join(`
`)+(e.length>0?`
`:"")}function ga(t,e,i){var g,d,b,f;const n=t.split(`
`);if(!n.some(v=>/^(\s*)([-*+]|\d+\.)\s+/.test(v)))return null;const s=[],l=[];let r=!1;for(let v=0;v<n.length;v++){const k=n[v];if(!k.trim())continue;const S=k.match(/^(\s*)[-*+]\s+\[([ xX])\]\s+(.*)$/);if(S){const A=S[1].length,w=Math.floor(A/2);l.push({type:"task",level:w,checked:S[2].toLowerCase()==="x",text:S[3],media:[]});continue}const x=k.match(/^(\s*)[-*+]\s+(.*)$/);if(x){const A=x[1].length,w=Math.floor(A/2);l.push({type:"unordered",level:w,text:x[2],media:[]});continue}const B=k.match(/^(\s*)\d+\.\s+(.*)$/);if(B){l.length===0&&(r=!0);const A=B[1].length,w=Math.floor(A/2);l.push({type:"ordered",level:w,text:B[2],media:[]});continue}const E=k.trim();if(!(!E||/^\{:.*?\}$/.test(E)))if(l.length>0){const A=E.match(/^!\[(.*?)\]\((.*?)\)(?:\{:?[^}]*\})?$/);if(A){const H=/\.gif(?:\?|$)/i.test(A[2])?"list-item-gif":"list-item-img";l[l.length-1].media||(l[l.length-1].media=[]),l[l.length-1].media.push(`<div class="slide-list-media"><img alt="${ce(A[1])}" src="${A[2]}" class="${H}" /></div>`);continue}if(E.match(/^<img\b[\s\S]*?\/?>$/i)){const F=E.replace(/\s+style="[^"]*"/gi,"");l[l.length-1].media||(l[l.length-1].media=[]),l[l.length-1].media.push(`<div class="slide-list-media">${F}</div>`);continue}if(/<video\b/i.test(E)){let F=E;if(!/<\/video>/i.test(F))for(;v+1<n.length&&!/<\/video>/i.test(F);)v++,F+=" "+n[v].trim();const H=((g=i==null?void 0:i.attributes)==null?void 0:g["custom-slidev-autoplay"])==="true"||/autoplay/i.test(F),j=((d=i==null?void 0:i.attributes)==null?void 0:d["custom-slidev-loop"])==="true"||/loop/i.test(F),J=((b=i==null?void 0:i.attributes)==null?void 0:b["custom-slidev-muted"])==="true"||H||/muted/i.test(F),I=((f=i==null?void 0:i.attributes)==null?void 0:f["custom-slidev-controls"])==="false",N=F.match(/\bsrc=["']([^"']+)["']/i),y=N?N[1]:"",V=['class="slide-video-player"'];I||V.push("controls"),H&&(V.push("autoplay"),V.push("playsinline")),j&&V.push("loop"),J&&V.push("muted"),V.push('preload="metadata"'),y&&V.push(`src="${y}"`);const X=F.match(/<video[^>]*>([\s\S]*?)<\/video>/i);let R=X?X[1].trim():"";!R&&y&&(R=`<source src="${y}" type="video/mp4" />您的浏览器不支持视频播放。`),l[l.length-1].media||(l[l.length-1].media=[]),l[l.length-1].media.push(`<div class="slide-list-media slide-video-container slide-media-container" data-autoplay="${H?"true":"false"}" data-muted="${J?"true":"false"}"><video ${V.join(" ")}>${R}</video></div>`);continue}l[l.length-1].text+=`
`+E}else s.push(E)}if(l.length===0)return null;const a=r?"ol":"ul",c=(e==null?void 0:e.listClassName)||(r?"pdf-list pdf-list--ordered":"pdf-list pdf-list--unordered"),u=l.map(v=>{const k=om(v.text),S=v.media&&v.media.length>0?`
${v.media.join(`
`)}`:"",x=v.level||0,B=x>0?` style="margin-left:${(x*1.25).toFixed(2)}em;${v.type==="unordered"?`list-style-type:${x%2===1?"circle":"square"} !important;`:""}"`:"",E=x>0?" slide-list-item--nested":"";if(v.type==="task"){const w=v.checked?' checked=""':"";return`<li class="pdf-task-item${E}"${B}><label><input type="checkbox" disabled=""${w}/> <span>${k}</span></label>${S}</li>`}return`<li${E?` class="${E.trim()}"`:""}${B}>${k}${S}</li>`}).join(`
`);return`${sm(s)}<${a} class="${c}">
${u}
</${a}>`}function rm(t,e,i){const n=(e==null?void 0:e.containerClassName)||"pdf-block",o=t.split(/\r?\n/),s=[];let l=[];for(let c=0;c<o.length;c++){const u=o[c],m=u.trim();if(/^#{1,6}\s+/.test(m)){l.length>0&&(s.push(l.join(`
`)),l=[]),s.push(m);continue}if(!m){l.length>0&&(s.push(l.join(`
`)),l=[]);continue}if(/^!\[.*?\]\(.*?\)$/.test(m)){l.length>0&&(s.push(l.join(`
`)),l=[]),s.push(m);continue}if(/<video\b/i.test(m)){l.length>0&&(s.push(l.join(`
`)),l=[]);let g=m;if(!/<\/video>/i.test(g))for(;c+1<o.length&&!/<\/video>/i.test(g);)c++,g+=`
`+o[c];s.push(g);continue}l.push(u)}l.length>0&&s.push(l.join(`
`));let r=!0;return s.map(c=>{var b,f,v,k;const u=c.trim();if(!u)return"";const m=u.match(/^(#{1,6})\s+(.*)$/);if(m){r=!1;const S=m[1].length;return`<h${S} class="slide-list-item-title">${re(m[2].trim())}</h${S}>`}const g=u.match(/^!\[(.*?)\]\((.*?)\)$/);if(g){const S=/\.gif(?:\?|$)/i.test(g[2]),x=(e==null?void 0:e.imageClassName)||(S?"list-item-gif":"pdf-image slide-media-img");return`<div class="${n} ${n}--image slide-media-block slide-media-container slide-list-media"><img alt="${ce(g[1])}" src="${g[2]}" class="${x}" /></div>`}if(/<video\b/i.test(u)){const S=((b=i==null?void 0:i.attributes)==null?void 0:b["custom-slidev-autoplay"])==="true"||/autoplay/i.test(u),x=((f=i==null?void 0:i.attributes)==null?void 0:f["custom-slidev-loop"])==="true"||/loop/i.test(u),B=((v=i==null?void 0:i.attributes)==null?void 0:v["custom-slidev-muted"])==="true"||S||/muted/i.test(u),E=((k=i==null?void 0:i.attributes)==null?void 0:k["custom-slidev-controls"])==="false",A=u.match(/\bsrc=["']([^"']+)["']/i),w=A?A[1]:"",F=['class="slide-video-player"'];E||F.push("controls"),S&&F.push("autoplay playsinline"),x&&F.push("loop"),B&&F.push("muted"),F.push('preload="metadata"'),w&&F.push(`src="${w}"`);const H=u.match(/<video[^>]*>([\s\S]*?)<\/video>/i);let j=H?H[1].trim():"";return!j&&w&&(j=`<source src="${w}" type="video/mp4" />您的浏览器不支持视频播放。`),`<div class="${n} ${n}--video slide-media-block slide-video-container slide-media-container" data-autoplay="${S?"true":"false"}" data-muted="${B?"true":"false"}"><video ${F.join(" ")}>${j}</video></div>`}const d=ga(u,e,i);if(d)return r=!1,d;if(r){r=!1;const S=u.split(/\r?\n/).map(A=>A.trim()).filter(Boolean);if(S.length===1)return`<p class="slide-list-item-title">${re(S[0])}</p>`;const x=S[0],E=S.slice(1).map(A=>re(A)).join("<br/>");return`<p class="slide-list-item-title">${re(x)}</p>
<p class="slide-list-item-desc">${E}</p>`}return`<p class="slide-list-item-desc">${re(u)}</p>`}).filter(Boolean).join(`
`)}function Go(t){if(!t)return!1;if(t.type==="h"||t.type==="NodeHeading")return!0;const e=(t.rawMarkdown||t.content||"").trim();return/^#{1,6}\s+/.test(e)}function lm(t,e){var r,a,c,u,m,g,d,b;const i=((r=t.frontmatter)==null?void 0:r.layout)||"default",o=(t.blocks||[]).filter(f=>f.slot!=="slot-divider-right"),l=i==="cover"?null:o.find(Go);if(i==="two-cols"){const f=o.some(J=>J.slot==="right");let v=[],k=[];if(f)v=o.filter(J=>J.slot!=="right"),k=o.filter(J=>J.slot==="right");else{const J=Math.ceil(o.length/2);v=o.slice(0,J),k=o.slice(J)}const S=J=>{const I=J.filter(N=>!!(N.rawMarkdown||N.content||"").trim());if(I.length>0){const N=I[0],y=(N.rawMarkdown||N.content||"").trim();(Ri(N)||/^(?:[-*+]|\d+\.)\s+/.test(y))&&(N.rawMarkdown=bn(N.rawMarkdown||N.content||""),N.content=N.rawMarkdown)}};S(v),S(k);const x=v.map(J=>fi(J,e)).join(`
`),B=k.map(J=>fi(J,e)).join(`
`),E="pdf-two-cols-wrapper layout-two-cols-grid",A=(a=t.frontmatter)!=null&&a.layoutClass?` ${t.frontmatter.layoutClass}`:"",w="pdf-col pdf-col--left",F="pdf-col pdf-col--right",j=`style="grid-template-columns: ${qo((c=t.frontmatter)==null?void 0:c.layoutRatio,2)};"`;return`
      <div class="${E}${A}" ${j}>
        <div class="${w}">${x}</div>
        <div class="${F}">${B}</div>
      </div>
    `}if(i==="clover"||$n(i)){const f=i==="clover";let v=[];const k=o.filter(V=>V.slot==="header");if(k.length>0)v=k;else if(o.length>0){const V=o.find(X=>X.type==="h"&&(!X.slot||X.slot==="default"));V&&(v=[V])}const S=o.filter(V=>!v.includes(V));let x=2;if(f)x=4;else if(i==="three-cols-header")x=3;else if(i==="two-cols-header")x=2;else{let V=0;for(const X of S){const R=(X.slot||"").match(/^col-(\d+)$/i);R&&(V=Math.max(V,parseInt(R[1],10)))}if(V>=2)x=V;else if((u=t.frontmatter)!=null&&u.layoutRatio){const X=t.frontmatter.layoutRatio.trim();if(X.includes(":")){const R=X.split(":").map(U=>parseFloat(U.trim())).filter(U=>!isNaN(U)&&U>0);R.length>=2&&(x=R.length)}else{const R=X.split(/\s+/).filter(Boolean);R.length>=2&&(x=R.length)}}else S.length===1&&S[0].children&&S[0].children.length>=2&&(x=Math.min(6,S[0].children.length))}const B=la(S,x),E=S.some(V=>V.slot&&/^(?:col-\d+|left|right)$/i.test(V.slot)),A=i==="clover"||i==="two-cols-header"||i==="three-cols-header"||$n(i)&&E,w=V=>{const X=V.filter(U=>!!(U.rawMarkdown||U.content||"").trim());if(A&&X.length>0){const U=X[0],W=(U.rawMarkdown||U.content||"").trim();(Ri(U)||/^(?:[-*+]|\d+\.)\s+/.test(W))&&(U.rawMarkdown=bn(U.rawMarkdown||U.content||""),U.content=U.rawMarkdown),U.isColFirst=!0}const R=A?X.find(Go):null;return X.map(U=>fi(U,{...e,extraClassName:U===R?"slidev-col-first-heading-block":""})).join(`
`)},F=v.find(Go),H=v.map(V=>fi(V,{...e,extraClassName:V===F?"slidev-page-first-heading-block":""})).join(`
`),j=f?"repeat(2, minmax(0, 1fr))":qo((m=t.frontmatter)==null?void 0:m.layoutRatio,x),J=f?`style="grid-template-columns: ${j}; grid-template-rows: repeat(2, minmax(0, 1fr));"`:`style="grid-template-columns: ${j};"`,I=[f?"layout-clover-container":"layout-cols-header-container",x===2?"layout-two-cols-header-container":"",x===3?"layout-three-cols-header-container":"",`layout-${i}-container`,A?"has-superblock-cols":""].filter(Boolean).join(" "),N=[f?"layout-clover-grid pdf-clover-wrapper":"layout-cols-wrapper layout-cols-grid",x===2?"pdf-two-cols-wrapper layout-two-cols-grid":"",x===3?"pdf-three-cols-wrapper layout-three-cols-grid":"",A?"has-superblock-cols":""].filter(Boolean).join(" "),y=B.map((V,X)=>{const R=X+1;return`<div class="${["pdf-col",x===2&&R===1?"pdf-col--left":"",x===2&&R===2?"pdf-col--right":"",`pdf-col--${R}`,`col-${R}`].filter(Boolean).join(" ")}">${w(V)}</div>`}).join(`
`);return`
      <div class="${I}">
        <div class="layout-header-section">${H}</div>
        <div class="${N}" ${J}>
          ${y}
        </div>
      </div>
    `}if(i==="image-right"||i==="image-left"){const f=i==="image-right",v=o.map(A=>fi(A,e)).join(`
`),k=((g=t.frontmatter)==null?void 0:g.image)||((d=t.frontmatter)==null?void 0:d.background)||"",S=`<div class="pdf-image-col" style="background-image:url('${ce(k)}');background-size:cover;background-position:center;background-repeat:no-repeat;width:100%;height:100%;position:relative;overflow:hidden;"><img src="${ce(k)}" style="width:100%;height:100%;object-fit:cover;object-position:center;display:block;" onerror="this.style.display='none'" alt="Slide cover" /></div>`,x=`<div class="pdf-content-col" style="padding:48px 56px;display:flex;flex-direction:column;justify-content:flex-start;height:100%;box-sizing:border-box;overflow-y:auto;">${v}</div>`,B=f?`${x}
${S}`:`${S}
${x}`;return`
      <div class="layout-image-cols-grid" style="display:grid;grid-template-columns:${qo((b=t.frontmatter)==null?void 0:b.layoutRatio,2)};grid-template-rows:100%;width:100%;height:100%;position:absolute;top:0;left:0;right:0;bottom:0;box-sizing:border-box;">
        ${B}
      </div>
    `}return i==="fact"?`<div class="layout-fact-container">${o.map(v=>fi(v,e)).join(`
`)}</div>`:i==="cover"?`<div class="layout-cover-container">${o.map(v=>fi(v,e)).join(`
`)}</div>`:o.map(f=>fi(f,{...e,extraClassName:f===l?"slidev-page-first-heading-block":""})).join(`
`)}function ce(t){return t?t.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&#039;"):""}function am(t){if(!t||t.trim()===""||t.trim()==="all")return"all";const e=new Set,i=t.split("|");for(const n of i){const o=n.trim();if(o==="all")return"all";if(o.includes("-")){const[s,l]=o.split("-"),r=parseInt(s,10),a=parseInt(l,10);if(!isNaN(r)&&!isNaN(a))for(let c=Math.min(r,a);c<=Math.max(r,a);c++)e.add(c)}else{const s=parseInt(o,10);isNaN(s)||e.add(s)}}return e}const cm=new Set(["kbd","mark","sub","sup","span","a","br","b","i","u","s","del","em","strong","code","small","abbr","ruby","rt","rp","v-mark","img","video","source","picture"]);function re(t){if(!t)return"";const e=oa(t),i=[],n=e.replace(/<\/?([a-zA-Z0-9_-]+)(?:\s+[^<>]*)?\/?>/g,(s,l)=>{const r=l.toLowerCase();if(!cm.has(r)||/on\w+\s*=|javascript:/i.test(s))return s;if(r==="v-mark"){const a=s.match(/type=["']?([a-zA-Z-]+)["']?/),c=a?a[1]:"circle";return s.startsWith("</")?i.push("</mark>"):i.push(`<mark class="v-mark v-mark--${c}">`),`%%SAFE_HTML_${i.length-1}%%`}return i.push(s),`%%SAFE_HTML_${i.length-1}%%`});let o=ce(n);return o=o.replace(/\(\(([0-9a-zA-Z-]+)(?:\s*(?:&#039;([^&#]*)&#039;|&quot;([^&]*)&quot;|'([^']*)'|"([^"]*)"|([^\)]+?)))?\s*\)\)/g,(s,l,r,a,c,u,m)=>{const d=(r??a??c??u??m??"").trim()||`Ref(${l.slice(0,8)})`;return`<a href="siyuan://blocks/${l}" data-ref-id="${l}" class="slidev-ref-tag">🔗 ${d}</a>`}),o=o.replace(/\$([^$\n]+)\$/g,'<span class="katex-inline font-math"><em>$1</em></span>'),o=o.replace(/!\[(.*?)\]\((.*?)\)/g,(s,l,r)=>{const c=/\.gif(?:\?|$)/i.test(r)?"slide-inline-img list-item-gif":"slide-inline-img";return`<img alt="${l}" src="${r}" class="${c}" />`}),o=o.replace(/\[(.*?)\]\((.*?)\)/g,(s,l,r)=>{if(r.startsWith("siyuan://blocks/")){const a=r.replace("siyuan://blocks/","").split("?")[0];return`<a href="${r}" data-ref-id="${a}" class="slidev-ref-tag">🔗 ${l}</a>`}return`<a href="${r}" target="_blank" rel="noopener noreferrer" class="slidev-link">${l}</a>`}),o=o.replace(/(^|[\s(])(siyuan:\/\/blocks\/([0-9a-zA-Z-]+)(?:\?[^\s\)]*)?)/g,(s,l,r,a)=>`${l}<a href="${r}" data-ref-id="${a}" class="slidev-ref-tag">🔗 ${r}</a>`),o=o.replace(/\*\*(.*?)\*\*/g,"<strong>$1</strong>"),o=o.replace(/\*(.*?)\*/g,"<em>$1</em>"),o=o.replace(/~~(.*?)~~/g,"<del>$1</del>"),o=o.replace(/`([^`]+)`/g,"<code>$1</code>"),o=o.replace(/%%SAFE_HTML_(\d+)%%/g,(s,l)=>{const r=parseInt(l,10);return i[r]||""}),o}function dm(t,e="pdf-table"){if(t.length<2)return"";const i=t.map(a=>a.trim().replace(/^\|/,"").replace(/\|$/,"").split("|").map(c=>c.trim())),n=i[0];let o=[],s=1;t.length>=2&&i[1].every(a=>/^:?-+:?$/.test(a))&&(o=i[1].map(a=>a.startsWith(":")&&a.endsWith(":")?"center":a.endsWith(":")?"right":"left"),s=2);const l=`<thead><tr>${n.map((a,c)=>`<th${o[c]?` style="text-align: ${o[c]}"`:""}>${re(a)}</th>`).join("")}</tr></thead>`,r=i.slice(s).map(a=>`<tr>${a.map((c,u)=>`<td${o[u]?` style="text-align: ${o[u]}"`:""}>${re(c)}</td>`).join("")}</tr>`).join("");return`<table class="${e}">${l}<tbody>${r}</tbody></table>`}function Zo(t){return String(t||"").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;")}function Mr(t,e="ts"){if(!t)return"";if(t.trim().startsWith("//"))return`<span class="token-comment">${Zo(t)}</span>`;const i=[];function n(s,l){return i.push(`<span class="${s}">${Zo(l)}</span>`),`__TOK_${i.length-1}__`}let o=t.replace(/(['"`])(.*?)\1/g,(s,l,r)=>n("token-string",`${l}${r}${l}`));return o=o.replace(/\b(import|export|from|const|let|var|function|return|default|type|interface|class|new|async|await)\b/g,s=>n("token-keyword",s)),o=o.replace(/\b(computed|ref|number|string|boolean|void|Array)\b/g,s=>n("token-type",s)),o=o.replace(/\b(\d+)\b/g,s=>n("token-number",s)),o=Zo(o),o=o.replace(/__TOK_(\d+)__/g,(s,l)=>i[parseInt(l,10)]||""),o}function um(t,e){if(!t)return null;const i=t.frontmatter||{};if(i.hideInToc===!0||i.hideInToc==="true")return null;let n=(i.title||"").trim(),o=i.level?parseInt(i.level,10):0;if(!n){const s=t.blocks||[];for(const l of s){const a=(l.rawMarkdown||l.content||"").trim().match(/^(#{1,6})\s+(.*)$/);if(a){o||(o=a[1].length),n=a[2].trim();break}}}return n?((!o||isNaN(o))&&(o=1),{pageIndex:t.pageIndex||e,title:n,level:o}):null}function fm(t,e=1,i={}){const n=i.minDepth!==void 0?Number(i.minDepth):1,o=i.maxDepth!==void 0?Number(i.maxDepth):1/0,s=[];Array.isArray(t)&&t.forEach((c,u)=>{const m=um(c,u+1);m&&s.push(m)});const l=[];let r=null;for(const c of s){const u={...c,active:c.pageIndex===e,hasActiveChild:!1,children:[]};c.level===1||l.length===0?(l.push(u),r=u):r?(u.active&&(r.hasActiveChild=!0),r.children.push(u)):l.push(u)}function a(c,u=1){if(u>o)return[];const m=[];for(const g of c){const d=a(g.children,u+1);u>=n?m.push({...g,children:d}):m.push(...d)}return m}return a(l,1)}function pm(t,e=1,i={}){const n=fm(t,e,i),o=i.columns?Number(i.columns):1,s=o>1?` style="column-count: ${o};"`:"",l=i.textSm?" text-sm":"";function r(c,u=1){if(!c||c.length===0)return"";const m=`slidev-toc-list slidev-toc-list-level-${u}`,g=c.map(d=>{const b=d.active?" slidev-toc-item-active":d.hasActiveChild?" slidev-toc-item-parent-active":"",f=d.children&&d.children.length>0?r(d.children,u+1):"";let v=re(d.title);return v.includes("LaTeX")&&(v=v.replace(/\$\\LaTeX\$/g,'<span class="font-math">L<sup>A</sup>T<sub>E</sub>X</span>')),`
        <li class="slidev-toc-item${b}" data-page="${d.pageIndex}">
          <a class="slidev-toc-link" href="javascript:void(0)">
            <span class="slidev-toc-title">${v}</span>
          </a>
          ${f}
        </li>
      `}).join("");return`<ol class="${m}">${g}</ol>`}const a=r(n,1);return`<div class="slidev-toc${l}"${s}>${a}</div>`}function fi(t,e){var x,B,E,A,w,F,H,j,J,I;let i="",n="",o="";const s=[];(x=t.motion)!=null&&x.preset&&t.motion.preset!=="none"&&(i=` slidev-motion-${t.motion.preset.toLowerCase()}`,typeof t.motion.duration=="number"&&t.motion.duration>0&&s.push(`--motion-duration:${t.motion.duration}ms`),typeof t.motion.delay=="number"&&t.motion.delay>0&&s.push(`--motion-delay:${t.motion.delay}ms`));const l=((B=t.attributes)==null?void 0:B.style)||"";l&&(s.push(l),o=" slide-styled-block"),s.length>0&&(n=` style="${ce(s.join(";"))}"`);const r=(e==null?void 0:e.containerClassName)||"pdf-block",a=e!=null&&e.extraClassName?` ${e.extraClassName}`:"",c=`${r}${i}${o}${a}`,u=(t.rawMarkdown||t.content||"").trim();if(!u)return`<div class="${c}"${n}></div>`;if(u.includes('class="slidev-block-ref"')||u.includes('class="slidev-ref-tag"'))return`<div class="${c}"${n}>${u}</div>`;if(u.startsWith("$$")&&u.endsWith("$$")){const N=u.slice(2,-2).trim();return`<div class="${c} katex-display-container"${n}><div class="katex-display font-math"><em>${ce(N)}</em></div></div>`}const m=u.match(/^(#{1,6})\s+(.*)$/);if(m){const N=m[1].length,y=re(m[2]),X=!!(t.isColFirst||t.type==="i"&&((E=e==null?void 0:e.extraClassName)!=null&&E.includes("slidev-col-first-heading-block")))?' class="slide-list-item-title"':"";return`<div class="${c}"${n}><h${N}${X}>${y}</h${N}></div>`}if(u.startsWith(":::")){const N=u.split(`
`),V=N[0].replace(/^:::\s*/,"").trim()||"info",X=N.slice(1,N[N.length-1].startsWith(":::")?-1:void 0).join(`
`),R=(e==null?void 0:e.calloutClassName)||"pdf-callout";return`<div class="${c}"${n}><div class="${R} ${R}--${V}"><div class="${R}-title">${V.toUpperCase()}</div><div class="${R}-body">${re(X)}</div></div></div>`}if(u.startsWith("<<<")){const V=`// Inside ./snippets/external.ts
export function emptyArray<T>(length: number) {
  return Array.from<T>({ length })
}`.split(`
`).map((W,tt)=>`<span class="code-line shiki-focus"><span class="line-no">${tt+1}</span><span class="line-content">${Mr(W,"ts")}</span></span>`).join(`
`),X=(e==null?void 0:e.codeClassName)||"pdf-code shiki-container",R=((A=t.attrs)==null?void 0:A["custom-slidev-max-height"])||t.maxHeight||"",U=R?` style="max-height:${ce(R)};overflow-y:auto;"`:"";return`<div class="${c}"${n}><pre class="${X}"${U}><span class="lang-badge">TS</span><code>${V}</code></pre></div>`}if(u.startsWith("<style")||u.startsWith("<!-- Inline style -->")||u.startsWith(`<!--
Notes`))return"";if(u.startsWith("```")){const N=u.split(`
`),y=N[0].slice(3).trim(),V=y.match(/^([^\s{\[]+)/),X=V?V[1]:"",R=y.match(/\[([^\]]+)\]/),U=R?R[1]:"",W=y.includes("twoslash"),tt=t.shikiLines||((w=y.match(/\{([^}]+)\}/))==null?void 0:w[1])||"",T=am(tt),M=N.length>2?N[N.length-1]==="```"?N.slice(1,-1):N.slice(1):[u.slice(3).replace(/```$/,"")],Y=(e==null?void 0:e.codeClassName)||"pdf-code shiki-container",Z=U?`${Y} has-filename`:Y,Q=T!=="all",P=M.map((mt,C)=>{const D=C+1,O=T==="all"||T.has(D)?"code-line shiki-focus":Q?"code-line shiki-dimmed":"code-line";let _=(e==null?void 0:e.highlight)===!0?Mr(mt,X):ce(mt);return W&&mt.includes("doubled.value = 2")?(_=_.replace(/(\bvalue\b)/,'<span class="twoslash-error-wavy">$1</span>'),`<span class="${O}"><span class="line-no">${D}</span><span class="line-content">${_}</span></span>
<div class="twoslash-popup-error"><span style="color:#ef4444;font-weight:bold;margin-right:4px;">✕</span> Cannot assign to 'value' because it is a read-only property.</div>`):`<span class="${O}"><span class="line-no">${D}</span><span class="line-content">${_}</span></span>`}).join(`
`),ct=X?`<span class="lang-badge">${ce(X)}</span>`:"",rt=U?`<span class="code-filename">${ce(U)}</span>`:"",st=((F=t.attrs)==null?void 0:F["custom-slidev-max-height"])||t.maxHeight||"",gt=st?` style="max-height:${ce(st)};overflow-y:auto;"`:"";return`<div class="${c}"${n}><pre class="${Z}"${gt}>${rt}${ct}<code>${P}</code></pre></div>`}if(u.includes("|")&&u.split(`
`).filter(N=>N.trim().startsWith("|")).length>=2){const N=u.split(`
`).filter(V=>V.trim().startsWith("|")),y=dm(N,e==null?void 0:e.tableClassName);return`<div class="${c}"${n}>${y}</div>`}if(u.startsWith("> ")){const N=(e==null?void 0:e.quoteClassName)||"pdf-quote";return`<div class="${c}"${n}><blockquote class="${N}"><p>${re(u.slice(2))}</p></blockquote></div>`}const g=/<video\b/i.test(u)||t.type==="video"||t.type==="NodeVideo",d=/^(\s*)([-*+]|\d+\.)\s+/m.test(u),b=/(?:^|\n)\s*#{1,6}\s+/.test(u);if(g&&!d&&!b&&!u.includes(`
`)){const N=((H=t.attributes)==null?void 0:H["custom-slidev-autoplay"])==="true"||/autoplay/i.test(u),y=((j=t.attributes)==null?void 0:j["custom-slidev-loop"])==="true"||/loop/i.test(u),V=((J=t.attributes)==null?void 0:J["custom-slidev-muted"])==="true"||N||/muted/i.test(u),X=((I=t.attributes)==null?void 0:I["custom-slidev-controls"])==="false",R=u.match(/\bsrc=["']([^"']+)["']/i),U=R?R[1]:"",W=['class="slide-video-player"'];X||W.push("controls"),N&&(W.push("autoplay"),W.push("playsinline")),y&&W.push("loop"),V&&W.push("muted"),W.push('preload="metadata"'),U&&W.push(`src="${U}"`);const tt=u.match(/<video[^>]*>([\s\S]*?)<\/video>/i);let T=tt?tt[1].trim():"";return!T&&U&&(T=`<source src="${U}" type="video/mp4" />您的浏览器不支持视频播放。`),`<div class="${c} ${c}--video slide-media-block slide-video-container slide-media-container" data-autoplay="${N?"true":"false"}" data-muted="${V?"true":"false"}"${n}><video ${W.join(" ")}>${T}</video></div>`}const f=u.match(/^!\[(.*?)\]\((.*?)\)$/);if(f){const N=(e==null?void 0:e.imageClassName)||"pdf-image slide-media-img";return`<div class="${c} ${c}--image slide-media-block slide-media-container"${n}><img alt="${ce(f[1])}" src="${f[2]}" class="${N}" /></div>`}const v=ga(u,e,t);if(v)return`<div class="${c} pdf-list-item"${n}>${v}</div>`;if(/<(?:Toc|toc)\b/i.test(u)&&!u.startsWith("```")){const N=u.match(/minDepth=["']?(\d+)["']?/i),y=u.match(/maxDepth=["']?(\d+)["']?/i),V=u.match(/columns=["']?(\d+)["']?/i),X=(e==null?void 0:e.allSlides)||[];return`<div class="${c}"${n}>${pm(X,(e==null?void 0:e.currentPageIndex)||1,{minDepth:N?parseInt(N[1],10):1,maxDepth:y?parseInt(y[1],10):1/0,columns:V?parseInt(V[1],10):1,textSm:u.includes("text-sm")})}</div>`}if(u.includes(`
`)||b){const N=rm(u,e,t);if(N)return`<div class="${c}"${n}>${N}</div>`}const S=!!t.isColFirst?' class="slide-list-item-title"':"";return`<div class="${c}"${n}><p${S}>${re(u)}</p></div>`}function hm(t){return`
    ${kn(t)}

    :root {
      --slide-bg: #ffffff;
      --slide-text: #1a1a1a;
      --slide-accent: #3b82f6;
      --slide-font: system-ui, -apple-system, sans-serif;
    }
    [data-theme="dark"] {
      --slide-bg: #121214;
      --slide-text: #e2e8f0;
      --slide-accent: #60a5fa;
    }

    /* 1. 默认科技主题 Default */
    [data-slidev-theme="default"],
    .slidev-theme-default {
      --slide-font: system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "PingFang SC", "Microsoft YaHei", sans-serif;
      --slide-accent: #10b981;
    }
    [data-theme="light"][data-slidev-theme="default"],
    [data-theme="light"] .slidev-theme-default {
      --slide-bg: #ffffff;
      --slide-text: #1e293b;
      --slide-accent: #059669;
    }
    [data-theme="dark"][data-slidev-theme="default"],
    [data-theme="dark"] .slidev-theme-default {
      --slide-bg: #121214;
      --slide-text: #e2e8f0;
      --slide-accent: #34d399;
    }
    .slidev-theme-default .layout-cover h1,
    .slidev-theme-default .layout-cover .slide-block h1 {
      font-size: 3.8rem !important;
      font-weight: 800 !important;
      line-height: 1.15 !important;
      letter-spacing: -0.025em !important;
      margin-bottom: 18px !important;
      background: linear-gradient(135deg, #10b981, #06b6d4) !important;
      -webkit-background-clip: text !important;
      -webkit-text-fill-color: transparent !important;
    }
    .slidev-theme-default .layout-cover h2,
    .slidev-theme-default .layout-cover .slide-block h2 {
      font-size: 1.85rem !important;
      font-weight: 600 !important;
      opacity: 0.85 !important;
      margin-bottom: 12px !important;
    }
    .slidev-theme-default .layout-cover p,
    .slidev-theme-default .layout-cover .slide-block p {
      font-size: 1.45rem !important;
      line-height: 1.5 !important;
      opacity: 0.85 !important;
    }

    /* 2. 优雅衬线主题 Seriph */
    [data-slidev-theme="seriph"],
    .slidev-theme-seriph {
      --slide-font: "PT Serif", "Charter", "Georgia", "Cambria", "Times New Roman", "Source Han Serif SC", "Noto Serif SC", "Songti SC", "SimSun", serif;
      --slide-accent: #b45309;
      letter-spacing: 0.015em;
    }
    [data-theme="light"][data-slidev-theme="seriph"],
    [data-theme="light"] .slidev-theme-seriph {
      --slide-bg: #fdfbf7;
      --slide-text: #2a2521;
      --slide-accent: #b45309;
    }
    [data-theme="dark"][data-slidev-theme="seriph"],
    [data-theme="dark"] .slidev-theme-seriph {
      --slide-bg: #1c1a17;
      --slide-text: #e8e3d9;
      --slide-accent: #f59e0b;
    }
    .slidev-theme-seriph,
    .slidev-theme-seriph .slide-content {
      font-family: var(--slide-font) !important;
      line-height: 1.72;
    }
    .slidev-theme-seriph h1,
    .slidev-theme-seriph h2,
    .slidev-theme-seriph h3 {
      font-family: var(--slide-font) !important;
      letter-spacing: 0.025em;
      font-weight: 700;
    }
    .slidev-theme-seriph .layout-cover h1 {
      background: none !important;
      -webkit-background-clip: initial !important;
      -webkit-text-fill-color: initial !important;
      color: var(--slide-accent) !important;
      font-size: 3.4rem !important;
      border-bottom: 2px solid var(--slide-accent);
      display: inline-block;
      padding-bottom: 10px;
    }

    /* 3. 极简发布会主题 Apple Basic */
    [data-slidev-theme="apple-basic"],
    .slidev-theme-apple-basic {
      --slide-font: -apple-system, "SF Pro Display", "SF Pro Text", BlinkMacSystemFont, "PingFang SC", "Helvetica Neue", sans-serif;
      --slide-accent: #0071e3;
    }
    [data-theme="light"][data-slidev-theme="apple-basic"],
    [data-theme="light"] .slidev-theme-apple-basic {
      --slide-bg: #ffffff;
      --slide-text: #1d1d1f;
      --slide-accent: #0071e3;
    }
    [data-theme="dark"][data-slidev-theme="apple-basic"],
    [data-theme="dark"] .slidev-theme-apple-basic {
      --slide-bg: #000000;
      --slide-text: #f5f5f7;
      --slide-accent: #2997ff;
    }
    .slidev-theme-apple-basic,
    .slidev-theme-apple-basic .slide-content {
      font-family: var(--slide-font) !important;
    }
    .slidev-theme-apple-basic h1,
    .slidev-theme-apple-basic h2,
    .slidev-theme-apple-basic h3 {
      letter-spacing: -0.035em;
      font-weight: 800;
    }
    .slidev-theme-apple-basic .layout-cover h1 {
      background: none !important;
      -webkit-background-clip: initial !important;
      -webkit-text-fill-color: initial !important;
      color: var(--slide-text) !important;
      font-size: 3.8rem !important;
      letter-spacing: -0.04em !important;
    }
    .slidev-theme-apple-basic .layout-cover p {
      color: #86868b !important;
      font-size: 1.35rem !important;
    }

    * { box-sizing: border-box; margin: 0; padding: 0; }
    html, body {
      width: 100%; height: 100%; overflow: hidden;
      background: #0f1115; font-family: var(--slide-font);
      display: flex; justify-content: center; align-items: center;
    }
    #app { width: 100%; height: 100%; position: relative; overflow: hidden; }
    .slide-viewport {
      position: absolute; left: 50%; top: 50%;
      background: var(--slide-bg); color: var(--slide-text);
      box-shadow: 0 10px 30px rgba(0,0,0,0.5); border-radius: 8px; overflow: hidden;
      display: flex; flex-direction: column; flex-shrink: 0;
      transform: translate(-50%, -50%) scale(var(--slidev-slide-scale, 1));
      transform-origin: center center; will-change: transform;
      transition: background 0.3s ease, color 0.3s ease, border-radius 0.2s ease, box-shadow 0.2s ease;
    }
    :fullscreen .slide-viewport, .is-fullscreen .slide-viewport {
      border-radius: 0 !important; box-shadow: none !important;
    }
    .slide-content {
      position: relative;
      width: 100%;
      height: 100%;
      min-height: 100%;
      flex: 1 1 0%;
      padding: var(--slidev-padding-y, 32px) var(--slidev-padding-x, 48px);
      display: flex;
      flex-direction: column;
      overflow: hidden;
      box-sizing: border-box;
    }

    /* 间距预设风格 */
    .slide-content.spacing-compact,
    .slide-viewport[data-spacing="compact"] .slide-content,
    [data-slidev-spacing="compact"] {
      --slidev-padding-y: 20px;
      --slidev-padding-x: 36px;
      --slidev-header-gap: 10px;
      --slidev-title-margin-bottom: 6px;
    }
    .slide-content.spacing-normal,
    .slide-viewport[data-spacing="normal"] .slide-content,
    [data-slidev-spacing="normal"] {
      --slidev-padding-y: 32px;
      --slidev-padding-x: 48px;
      --slidev-header-gap: 16px;
      --slidev-title-margin-bottom: 10px;
    }
    .slide-content.spacing-loose,
    .slide-viewport[data-spacing="loose"] .slide-content,
    [data-slidev-spacing="loose"] {
      --slidev-padding-y: 48px;
      --slidev-padding-x: 56px;
      --slidev-header-gap: 24px;
      --slidev-title-margin-bottom: 16px;
    }

    .layout-cover { justify-content: center; align-items: center; text-align: center; }
    .layout-cover h1, .layout-cover .slide-block h1 { font-size: 3.8rem !important; font-weight: 800 !important; line-height: 1.15 !important; letter-spacing: -0.025em !important; margin-bottom: 16px !important; }
    .layout-cover h2, .layout-cover .slide-block h2 { font-size: 1.85rem !important; font-weight: 600 !important; opacity: 0.85 !important; margin-bottom: 12px !important; }
    .layout-cover p, .layout-cover .slide-block p { font-size: 1.45rem !important; line-height: 1.5 !important; opacity: 0.85 !important; }
    .two-cols-left, .two-cols-right { min-width: 0; width: 100%; display: flex; flex-direction: column; box-sizing: border-box; overflow-wrap: break-word; word-break: break-word; }
    .pdf-two-cols-wrapper,
    .layout-two-cols-grid,
    .layout-cols-wrapper,
    .layout-cols-grid {
      display: grid;
      grid-template-columns: var(--slide-grid-cols, minmax(0, 1fr) minmax(0, 1fr));
      grid-template-rows: minmax(0, 1fr) !important;
      gap: 32px;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      overflow: hidden !important;
    }
    .layout-cols-header-container,
    .layout-two-cols-header-container,
    .layout-three-cols-header-container,
    .layout-clover-container {
      display: flex;
      flex-direction: column;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      overflow: hidden !important;
    }
    .layout-header-section {
      width: 100%;
      margin-bottom: var(--slidev-header-gap, 16px) !important;
      flex-shrink: 0;
    }
    .layout-header-section h1,
    .layout-header-section h2,
    .layout-header-section h3 {
      margin-bottom: var(--slidev-title-margin-bottom, 10px) !important;
    }
    .pdf-three-cols-wrapper,
    .layout-three-cols-grid {
      display: grid;
      grid-template-columns: var(--slide-grid-cols, minmax(0, 1fr) minmax(0, 1fr) minmax(0, 1fr));
      grid-template-rows: minmax(0, 1fr) !important;
      gap: 24px;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      box-sizing: border-box;
      overflow: hidden !important;
    }
    .pdf-clover-wrapper,
    .layout-clover-grid {
      display: grid;
      grid-template-columns: repeat(2, minmax(0, 1fr)) !important;
      grid-template-rows: repeat(2, minmax(0, 1fr)) !important;
      gap: 20px;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      box-sizing: border-box;
      overflow: hidden !important;
    }
    .layout-clover-grid .pdf-col {
      background: transparent !important;
      border: none !important;
      box-shadow: none !important;
    }
    .pdf-col {
      display: flex;
      flex-direction: column;
      gap: 14px;
      min-width: 0;
      width: 100%;
      max-width: 100%;
      height: 100%;
      max-height: 100%;
      min-height: 0;
      justify-content: flex-start;
      box-sizing: border-box;
      overflow: hidden;
      overflow-wrap: break-word;
      word-break: break-word;
      white-space: normal;
    }
    .pdf-col * {
      overflow-wrap: break-word;
      word-break: break-word;
      box-sizing: border-box;
    }
    /* 表头多栏内超级块子块首个列表项去圆点后居中显示标题/首行文本 (仅在存在超级块分栏时生效) */
    .has-superblock-cols .pdf-col > *:first-child .slide-list-item-title,
    .has-superblock-cols .pdf-col > *:first-child :is(h1, h2, h3, h4, h5, h6),
    .has-superblock-cols .pdf-col > *:first-child p.slide-list-item-title,
    .has-superblock-cols .pdf-col > *:first-child p:first-of-type,
    .has-superblock-cols .pdf-col > *:first-child p:first-child,
    .has-superblock-cols .pdf-col > *:first-child :is(ul, ol) > li:first-child,
    .has-superblock-cols .pdf-col > *:first-child .slide-list > .slide-list-item:first-child,
    .has-superblock-cols .pdf-col > *:first-child .pdf-list > li:first-child,
    .has-superblock-cols .slidev-col-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    .has-superblock-cols .slidev-col-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      list-style: none !important;
      list-style-type: none !important;
      text-align: center !important;
      margin-left: 0 !important;
      padding-left: 0 !important;
      width: 100% !important;
    }

    /* 彻底清除首个列表项的原生圆点 Marker (仅在存在超级块分栏时生效) */
    .has-superblock-cols .pdf-col > *:first-child :is(ul, ol) > li:first-child::marker {
      content: "" !important;
      display: none !important;
    }

    /* 确保首个列表项内部内联与块级元素居中 (仅在存在超级块分栏时生效) */
    .has-superblock-cols .pdf-col > *:first-child :is(ul, ol) > li:first-child * {
      text-align: center !important;
    }

    /* 栏内说明段落与列表项：左对齐，自然阅读排版 */
    .has-superblock-cols .pdf-col .slide-list-item-desc,
    .has-superblock-cols .pdf-col li:not(:first-child) {
      text-align: left !important;
    }

    /* 全局特定标题大小规范化 (除封面外页首首个标题按 H2 1.7rem，表头多栏内首个标题按 H3 1.3rem) */
    [data-normalize-headings="true"] .slidev-page-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .slidev-page-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .slide-content:not(.layout-cover) > :is(.pdf-block, .slide-block):first-child :is(h1, h2, h3, h4, h5, h6),
    [data-normalize-headings="true"] .slide-content:not(.layout-cover) > .layout-header-section :is(.pdf-block, .slide-block):first-child :is(h1, h2, h3, h4, h5, h6),
    [data-normalize-headings="true"] .slide-content:not(.layout-cover) > :not(.layout-cols-wrapper):not(.pdf-two-cols-wrapper):not(.layout-image-cols-grid):first-child :is(h1, h2, h3, h4, h5, h6) {
      font-size: 1.7rem !important;
      font-weight: 600 !important;
      line-height: 1.25 !important;
      margin-bottom: 10px !important;
    }

    [data-normalize-headings="true"] .has-superblock-cols .slidev-col-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .has-superblock-cols .slidev-col-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .has-superblock-cols .pdf-col > *:first-child :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      font-size: 1.3rem !important;
      font-weight: 600 !important;
      line-height: 1.3 !important;
      margin-bottom: 8px !important;
      text-align: center !important;
    }

    /* 图左与图右版式标题完全保留用户原始字号与默认排版，不进行任何固定大小规范化 */
    [data-normalize-headings="true"] :is(.layout-image-left, .layout-image-right, .image-left-content, .image-right-content) :is(h1, h2, h3, h4, h5, h6) {
      text-align: left !important;
    }
    .pdf-col pre,
    .two-cols-left pre,
    .two-cols-right pre,
    .image-right-content pre,
    .image-left-content pre {
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      overflow-x: hidden !important;
      overflow-y: auto !important;
      max-width: 100% !important;
      box-sizing: border-box !important;
    }
    .slide-content.layout-image-right, .slide-content.layout-image-left {
      padding: 0;
      display: grid;
      grid-template-columns: var(--slide-grid-cols, minmax(0, 1fr) minmax(0, 1fr));
      grid-template-rows: 100%;
      width: 100%;
      height: 100%;
      position: absolute;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      box-sizing: border-box;
    }
    .image-right-content, .image-left-content {
      padding: 44px 50px;
      display: flex;
      flex-direction: column;
      justify-content: flex-start;
      overflow-y: auto;
      width: 100%;
      height: 100%;
      box-sizing: border-box;
    }
    .image-right-img-container, .image-left-img-container {
      width: 100%;
      height: 100%;
      overflow: hidden;
      position: relative;
      background: #18181b;
      display: flex;
      align-items: center;
      justify-content: center;
    }
    .image-right-img, .image-left-img {
      width: 100%;
      height: 100%;
      object-fit: cover;
      object-position: center;
      display: block;
    }
    .slide-block { margin-bottom: 14px; line-height: 1.6; }
    .slide-block h1 { font-size: 2.2rem; margin-bottom: 12px; }
    .slide-block h2 { font-size: 1.7rem; margin-bottom: 10px; }
    .slide-block p { font-size: 1.15rem; }
    .slide-block ul, .slide-block ol, .pdf-list {
      padding-left: 28px;
      margin: 8px 0;
      display: flex;
      flex-direction: column;
      gap: 6px;
    }
    .slide-block li, .pdf-list li {
      font-size: 1.15rem;
      line-height: 1.6;
    }
    .pdf-task-item {
      list-style: none;
      margin-left: -20px;
      display: flex;
      align-items: center;
      gap: 8px;
    }
    .pdf-task-item input[type="checkbox"] {
      width: 1.15em;
      height: 1.15em;
      cursor: pointer;
    }

    /* 两栏与三栏及多栏（超级块分栏）布局：紧凑自然行距，子列表保留圆点与层级缩进 */
    .layout-two-cols ul,
    .layout-cols-header ul,
    .layout-two-cols-header ul,
    .layout-three-cols ul,
    .layout-three-cols-header ul,
    .two-cols-left ul,
    .two-cols-right ul,
    .three-cols-col ul,
    .col ul,
    .pdf-col ul,
    .layout-two-cols-grid .pdf-list,
    .layout-three-cols-grid .pdf-list,
    .layout-cols-grid .pdf-list,
    .layout-two-cols-grid .pdf-list--unordered,
    .layout-three-cols-grid .pdf-list--unordered,
    .layout-cols-grid .pdf-list--unordered {
      list-style: disc !important;
      list-style-type: disc !important;
      padding-left: 1.25em !important;
      margin-left: 0 !important;
      margin-top: 0 !important;
      margin-bottom: 8px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: block !important;
    }

    .layout-two-cols ol,
    .layout-cols-header ol,
    .layout-two-cols-header ol,
    .layout-three-cols ol,
    .layout-three-cols-header ol,
    .two-cols-left ol,
    .two-cols-right ol,
    .three-cols-col ol,
    .col ol,
    .pdf-col ol,
    .layout-two-cols-grid .pdf-list--ordered,
    .layout-three-cols-grid .pdf-list--ordered,
    .layout-cols-grid .pdf-list--ordered {
      list-style: decimal !important;
      list-style-type: decimal !important;
      padding-left: 1.25em !important;
      margin-left: 0 !important;
      margin-top: 0 !important;
      margin-bottom: 8px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: block !important;
    }

    .layout-two-cols li,
    .layout-cols-header li,
    .layout-two-cols-header li,
    .layout-three-cols li,
    .layout-three-cols-header li,
    .two-cols-left li,
    .two-cols-right li,
    .three-cols-col li,
    .col li,
    .pdf-col li,
    .pdf-col .pdf-list-item {
      padding-left: 0.2em !important;
      margin-left: 0 !important;
      margin-bottom: 6px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: list-item !important;
      line-height: 1.6 !important;
    }

    .layout-two-cols ul ul,
    .layout-three-cols ul ul,
    .three-cols-col ul ul,
    .pdf-col ul ul {
      list-style: circle !important;
      list-style-type: circle !important;
      padding-left: 1.25em !important;
      margin-top: 4px !important;
      margin-bottom: 4px !important;
    }

    /* 列表项内嵌标题与说明排版 */
    .slide-list-item-title,
    .pdf-list li > h1,
    .pdf-list li > h2,
    .pdf-list li > h3,
    .pdf-list li > h4,
    .pdf-list li > h5,
    .pdf-list li > h6,
    li > h1.slide-list-item-title,
    li > h2.slide-list-item-title,
    li > h3.slide-list-item-title,
    li > h4.slide-list-item-title {
      margin-top: 2px !important;
      margin-bottom: 6px !important;
      line-height: 1.35 !important;
      font-weight: 700 !important;
    }
    .pdf-list li > h1, li > h1.slide-list-item-title { font-size: 1.6rem !important; }
    .pdf-list li > h2, li > h2.slide-list-item-title { font-size: 1.4rem !important; }
    .pdf-list li > h3, li > h3.slide-list-item-title { font-size: 1.22rem !important; }
    .pdf-list li > h4, li > h4.slide-list-item-title { font-size: 1.1rem !important; }

    /* 全局特定标题大小规范化后置强力锁定 (防止被列表项内部字号覆盖) */
    [data-normalize-headings="true"] .slidev-page-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .slidev-page-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      font-size: 1.7rem !important;
      font-weight: 600 !important;
      line-height: 1.25 !important;
      margin-bottom: 10px !important;
    }
    [data-normalize-headings="true"] .slidev-col-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .slidev-col-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] :is(.layout-cols-wrapper, .pdf-two-cols-wrapper, .layout-cols-header-container, .layout-cols-grid) .pdf-col > *:first-child :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] :is(.two-cols-left, .two-cols-right, .pdf-col, .col) > *:first-child :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      font-size: 1.3rem !important;
      font-weight: 600 !important;
      line-height: 1.3 !important;
      margin-bottom: 8px !important;
      text-align: center !important;
    }
    .slide-list-item-desc,
    .pdf-list li > p {
      margin-top: 4px !important;
      margin-bottom: 6px !important;
      font-size: 1.05rem;
      line-height: 1.55;
      opacity: 0.92;
    }

    /* 多媒体（GIF动图、静态图片、MP4视频）全视口最大化自适应且不超出视口 */
    .slide-media-block,
    .slide-media-container,
    .slide-video-container,
    .slide-block--media,
    .slide-block--image,
    .slide-block--video,
    .slide-block:has(> img),
    .slide-block:has(> .slide-media-container),
    .slide-block:has(> p > img:only-child),
    .slide-block:has(> .slide-video-container),
    .slide-block:has(> video) {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      min-width: 0 !important;
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
      justify-content: center !important;
      width: 100% !important;
      height: 100% !important;
      max-height: 100% !important;
      overflow: hidden !important;
      margin: 4px 0 !important;
      box-sizing: border-box !important;
    }

    .two-cols-left > .slide-block,
    .two-cols-right > .slide-block,
    .three-cols-col > .slide-block,
    .pdf-col > .slide-block,
    .pdf-col .slide-block {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      max-height: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      width: 100% !important;
      height: 100% !important;
      box-sizing: border-box !important;
      overflow: hidden !important;
      margin-bottom: 0 !important;
    }

    /* 列内列表项的标题与段落文字：固定高度，不压缩 */
    .two-cols-left .slide-list-item-title,
    .two-cols-right .slide-list-item-title,
    .three-cols-col .slide-list-item-title,
    .pdf-col .slide-list-item-title,
    .two-cols-left h1, .two-cols-left h2, .two-cols-left h3, .two-cols-left h4, .two-cols-left h5, .two-cols-left h6,
    .two-cols-right h1, .two-cols-right h2, .two-cols-right h3, .two-cols-right h4, .two-cols-right h5, .two-cols-right h6,
    .three-cols-col h1, .three-cols-col h2, .three-cols-col h3, .three-cols-col h4, .three-cols-col h5, .three-cols-col h6,
    .pdf-col h1, .pdf-col h2, .pdf-col h3, .pdf-col h4, .pdf-col h5, .pdf-col h6,
    .three-cols-col .slide-list-item-desc,
    .pdf-col .slide-list-item-desc {
      flex: 0 0 auto !important;
      margin-top: 0 !important;
      margin-bottom: 6px !important;
    }

    /* 列内媒体容器：填满标题下方所有剩余垂直空间，纵向顶部对齐，横向居中，无溢出 */
    .two-cols-left .slide-list-media,
    .two-cols-right .slide-list-media,
    .three-cols-col .slide-list-media,
    .pdf-col .slide-list-media,
    .two-cols-left .slide-video-container,
    .two-cols-right .slide-video-container,
    .three-cols-col .slide-video-container,
    .pdf-col .slide-video-container,
    .two-cols-left .slide-media-container,
    .two-cols-right .slide-media-container,
    .three-cols-col .slide-media-container,
    .pdf-col .slide-media-container {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      min-width: 0 !important;
      width: 100% !important;
      height: 100% !important;
      max-height: 100% !important;
      max-width: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
      justify-content: flex-start !important;
      overflow: hidden !important;
      margin: 0 !important;
      padding: 0 !important;
      box-sizing: border-box !important;
    }

    /* 列内多媒体播放器：以 contain 模式等比缩放完整可见，绝对不超高超宽、不产生遮挡与滚动条 */
    .two-cols-left video,
    .two-cols-right video,
    .three-cols-col video,
    .pdf-col video,
    .two-cols-left img,
    .two-cols-right img,
    .three-cols-col img,
    .pdf-col img,
    .two-cols-left .slide-video-player,
    .two-cols-right .slide-video-player,
    .three-cols-col .slide-video-player,
    .pdf-col .slide-video-player,
    .layout-three-cols-grid video,
    .layout-two-cols-grid video,
    .layout-three-cols-grid img,
    .layout-two-cols-grid img {
      max-width: 100% !important;
      max-height: 100% !important;
      width: auto !important;
      height: auto !important;
      min-width: 0 !important;
      min-height: 0 !important;
      object-fit: contain !important;
      display: block !important;
      margin: 0 auto !important;
      cursor: zoom-in;
    }

    .slide-block img,
    .slide-media-img,
    .slide-media-container img,
    .slide-video-player,
    video.slide-video-player,
    .slide-block video {
      max-width: 100% !important;
      max-height: 100% !important;
      width: auto !important;
      height: auto !important;
      min-width: 0 !important;
      min-height: 0 !important;
      object-fit: contain !important;
      display: block !important;
      margin: 0 auto !important;
      border-radius: 8px;
      box-shadow: 0 4px 16px rgba(0, 0, 0, 0.16);
      background: transparent;
      outline: none;
      cursor: zoom-in;
    }

    .slide-list-media {
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
      justify-content: flex-start !important;
      width: 100% !important;
      max-width: 100% !important;
      height: 100% !important;
      max-height: 100% !important;
      flex: 1 1 0% !important;
      margin-top: 4px !important;
      margin-bottom: 4px !important;
      min-height: 0 !important;
      overflow: hidden !important;
      box-sizing: border-box !important;
    }
    .slide-list-media img,
    .slide-list-media video,
    .slide-list-media .list-item-gif,
    .slide-list-media .slide-video-player {
      max-width: 100% !important;
      max-height: 100% !important;
      width: auto !important;
      height: auto !important;
      min-width: 0 !important;
      min-height: 0 !important;
      object-fit: contain !important;
      border-radius: 6px !important;
      box-shadow: 0 3px 12px rgba(0, 0, 0, 0.14) !important;
      display: block !important;
      margin: 0 auto !important;
      cursor: zoom-in;
    }

    .slide-block:has(.slide-list-media) {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      height: 100% !important;
      max-height: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      overflow: hidden !important;
    }
    .slide-block:has(.slide-list-media) .pdf-list,
    .slide-block:has(.slide-list-media) ul,
    .slide-block:has(.slide-list-media) ol {
      display: block !important;
      flex: 1 1 auto;
      min-height: 0;
      max-height: 100%;
      overflow: visible !important;
      list-style: disc !important;
      list-style-type: disc !important;
    }
    .slide-block:has(.slide-list-media) li,
    .slide-block:has(.slide-list-media) .slide-list-item,
    .slide-block:has(.slide-list-media) .pdf-list-item,
    .slide-block:has(.slide-media-container) li,
    .slide-block:has(.slide-video-container) li,
    .layout-cols-wrapper li:has(.slide-list-media),
    .layout-cols-header-container li:has(.slide-list-media),
    .two-cols-left li:has(.slide-list-media),
    .two-cols-right li:has(.slide-list-media),
    .three-cols-col li:has(.slide-list-media),
    .pdf-col li:has(.slide-list-media),
    li:has(.slide-list-media),
    li:has(.slide-video-container),
    li:has(.slide-media-container) {
      display: list-item !important;
      list-style-type: disc !important;
      flex: 0 0 auto !important;
      height: auto !important;
      max-height: none !important;
      overflow: visible !important;
      margin-bottom: 6px !important;
    }

    .layout-two-cols .slide-media-block,
    .layout-two-cols .slide-video-container,
    .layout-two-cols .slide-media-container,
    .layout-three-cols .slide-media-block,
    .layout-three-cols .slide-video-container,
    .layout-three-cols .slide-media-container {
      max-width: 100% !important;
      max-height: 100% !important;
      width: 100% !important;
      height: 100% !important;
      min-width: 0 !important;
      min-height: 0 !important;
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
      justify-content: flex-start !important;
      overflow: hidden !important;
    }

    /* Lightbox 大图与视频灯箱模态窗口 */
    .slidev-lightbox {
      position: fixed;
      top: 0;
      left: 0;
      width: 100vw;
      height: 100vh;
      background: rgba(0, 0, 0, 0.88);
      backdrop-filter: blur(8px);
      z-index: 999999;
      display: none;
      align-items: center;
      justify-content: center;
      cursor: zoom-out;
      opacity: 0;
      transition: opacity 0.2s cubic-bezier(0.16, 1, 0.3, 1);
    }
    .slidev-lightbox.active {
      display: flex;
      opacity: 1;
    }
    .slidev-lightbox-content {
      position: relative;
      max-width: 92vw;
      max-height: 92vh;
      display: flex;
      align-items: center;
      justify-content: center;
      cursor: default;
    }
    .slidev-lightbox-img {
      max-width: 92vw;
      max-height: 92vh;
      object-fit: contain;
      border-radius: 8px;
      box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.75);
    }
    .slidev-lightbox-video {
      max-width: 92vw;
      max-height: 92vh;
      border-radius: 8px;
      box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.75);
    }
    .slidev-lightbox-close {
      position: absolute;
      top: 24px;
      right: 28px;
      width: 40px;
      height: 40px;
      background: rgba(255, 255, 255, 0.2);
      border: 1px solid rgba(255, 255, 255, 0.35);
      border-radius: 50%;
      color: #fff;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 22px;
      cursor: pointer;
      transition: background 0.2s, transform 0.2s;
      z-index: 1000000;
    }
    .slidev-lightbox-close:hover {
      background: rgba(255, 255, 255, 0.35);
      transform: scale(1.05);
    }

    img.slide-inline-img {
      max-width: 100% !important;
      max-height: min(320px, 40vh) !important;
      object-fit: contain !important;
      vertical-align: middle;
      border-radius: 4px;
    }
    kbd {
      display: inline-block;
      padding: 2px 7px;
      font-family: ui-monospace, SFMono-Regular, "SF Mono", Menlo, Consolas, "Liberation Mono", monospace;
      font-size: 0.85em;
      font-weight: 600;
      line-height: 1.25;
      color: inherit;
      background: rgba(125, 125, 125, 0.12);
      border: 1px solid rgba(125, 125, 125, 0.35);
      border-bottom-width: 2px;
      border-radius: 5px;
      box-shadow: 0 1px 2px rgba(0, 0, 0, 0.12);
      margin: 0 2px;
      vertical-align: middle;
      white-space: nowrap;
    }
    [data-theme="dark"] kbd, .theme-dark kbd {
      background: rgba(255, 255, 255, 0.1);
      border-color: rgba(255, 255, 255, 0.25);
      border-bottom-color: rgba(255, 255, 255, 0.4);
      color: #f1f5f9;
      box-shadow: 0 1px 2px rgba(0, 0, 0, 0.4);
    }
    .slide-block pre,
    pre {
      background: rgba(0, 0, 0, 0.1);
      padding: 12px;
      border-radius: 6px;
      font-family: "JetBrains Mono", Consolas, monospace;
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      overflow-x: hidden !important;
      overflow-y: auto !important;
      max-width: 100% !important;
      box-sizing: border-box !important;
    }
    .slide-block pre code,
    pre code {
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      display: block !important;
      width: 100% !important;
      box-sizing: border-box !important;
    }
    .code-line {
      display: flex !important;
      align-items: flex-start !important;
      width: 100% !important;
      box-sizing: border-box !important;
      line-height: 1.6;
    }
    .code-line .line-no {
      display: inline-block !important;
      flex-shrink: 0 !important;
      min-width: 2.2em !important;
      text-align: right !important;
      margin-right: 12px !important;
      user-select: none !important;
      opacity: 0.45 !important;
    }
    .code-line .line-content {
      flex: 1 1 0% !important;
      min-width: 0 !important;
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
    }
    /* 弱提示滚动条样式 */
    * {
      scrollbar-width: thin;
      scrollbar-color: rgba(255, 255, 255, 0.20) transparent;
    }
    *::-webkit-scrollbar {
      width: 4px;
      height: 4px;
    }
    *::-webkit-scrollbar-track {
      background: transparent;
    }
    *::-webkit-scrollbar-thumb {
      background: rgba(255, 255, 255, 0.20);
      border-radius: 2px;
      transition: background 0.2s ease;
    }
    *:hover::-webkit-scrollbar-thumb,
    *::-webkit-scrollbar-thumb:hover {
      background: rgba(255, 255, 255, 0.45);
    }
    /* Slidev Micro-motion Keyframes & Presets */
    @keyframes slidevMotionFadeIn { from { opacity: 0; } to { opacity: 1; } }
    @keyframes slidevMotionSlideUp { from { opacity: 0; transform: translateY(40px); } to { opacity: 1; transform: translateY(0); } }
    @keyframes slidevMotionSlideDown { from { opacity: 0; transform: translateY(-40px); } to { opacity: 1; transform: translateY(0); } }
    @keyframes slidevMotionSlideLeft { from { opacity: 0; transform: translateX(40px); } to { opacity: 1; transform: translateX(0); } }
    @keyframes slidevMotionSlideRight { from { opacity: 0; transform: translateX(-40px); } to { opacity: 1; transform: translateX(0); } }
    @keyframes slidevMotionZoomIn { from { opacity: 0; transform: scale(0.8); } to { opacity: 1; transform: scale(1); } }
    @keyframes slidevMotionBounce {
      0% { opacity: 0; transform: translateY(40px); }
      60% { opacity: 1; transform: translateY(-8px); }
      80% { transform: translateY(4px); }
      100% { transform: translateY(0); }
    }
    .slidev-motion-fade-in { animation: slidevMotionFadeIn var(--motion-duration, 0.4s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slidev-motion-slide-up { animation: slidevMotionSlideUp var(--motion-duration, 0.45s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slidev-motion-slide-down { animation: slidevMotionSlideDown var(--motion-duration, 0.45s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slidev-motion-slide-left { animation: slidevMotionSlideLeft var(--motion-duration, 0.45s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slidev-motion-slide-right { animation: slidevMotionSlideRight var(--motion-duration, 0.45s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slidev-motion-zoom-in, .slidev-motion-pop { animation: slidevMotionZoomIn var(--motion-duration, 0.4s) cubic-bezier(0.34, 1.56, 0.64, 1) var(--motion-delay, 0s) both; }
    .slidev-motion-bounce { animation: slidevMotionBounce var(--motion-duration, 0.6s) cubic-bezier(0.34, 1.56, 0.64, 1) var(--motion-delay, 0s) both; }
    .controls {
      position: absolute; bottom: 16px; display: flex; gap: 12px; align-items: center;
      background: rgba(24, 24, 27, 0.8); backdrop-filter: blur(8px);
      padding: 6px 18px; border-radius: 20px; color: #fff; font-size: 13px; z-index: 10;
      opacity: 0; pointer-events: auto;
      transition: opacity 0.3s cubic-bezier(0.16, 1, 0.3, 1), transform 0.3s cubic-bezier(0.16, 1, 0.3, 1);
    }
    .controls::before {
      content: ""; position: absolute; top: -20px; bottom: -16px; left: -24px; right: -24px;
    }
    .controls:hover, .controls:focus-within {
      opacity: 1; transform: translateY(-2px);
    }
    .controls button { background: transparent; border: none; color: inherit; cursor: pointer; padding: 2px 6px; }

    /* Slidev Native Icons & Interactive Buttons */
    .slidev-icon-btn {
      display: inline-flex !important; flex-direction: row !important; align-items: center !important; justify-content: center !important;
      padding: 0.35rem 0.5rem; border-radius: 0.375rem; background: transparent;
      border: 1px solid transparent; color: inherit; font-size: inherit; line-height: 1;
      cursor: pointer; opacity: 0.8; transition: all 0.2s ease; text-decoration: none;
      vertical-align: middle; user-select: none; margin: 0 4px;
    }
    .slidev-icon-btn:hover { opacity: 1; background: rgba(255, 255, 255, 0.12); border-color: rgba(255, 255, 255, 0.15); }

    /* 组件从上到下按顺序流式渲染，避免相互重叠 */
    .slide-block > div + div { margin-top: 14px; }

    /* 同一个 div 内的按钮/链接从左到右水平渲染 */
    .slide-block div:has(> .slidev-icon-btn),
    .slide-block div:has(> button),
    .slide-block [class*="abs-"],
    .slidev-btn-row {
      display: inline-flex !important;
      flex-direction: row !important;
      align-items: center !important;
      justify-content: center !important;
      flex-wrap: wrap !important;
      gap: 8px !important;
    }

    /* Position Shortcuts 适配：在组件流中保持从上到下排列，不脱离流产生重叠 */
    .slide-block .abs-br,
    .slide-block .abs-bl,
    .slide-block .abs-tr,
    .slide-block .abs-tl,
    .slide-block [class*="abs-"] {
      position: relative !important;
      bottom: auto !important;
      right: auto !important;
      top: auto !important;
      left: auto !important;
      margin: 0.75rem auto !important;
    }

    .slide-block--absolute { position: relative !important; margin-bottom: 14px !important; padding: 0 !important; background: transparent !important; }
    .slide-block--absolute:hover { background: transparent !important; }
    .mt-12 { margin-top: 3rem !important; }
    .py-1 { padding-top: 0.25rem !important; padding-bottom: 0.25rem !important; }
    .m-6 { margin: 1.5rem !important; }
    .text-xl { font-size: 1.25rem !important; }
    [hover\\:bg~="white"][hover\\:bg~="op-10"]:hover,
    [hover\\:bg="white op-10"]:hover { background: rgba(255, 255, 255, 0.1) !important; border-radius: 4px; }
    .cursor-pointer, [data-clickable] { cursor: pointer; }
    /* Slidev 规范链接排版 (继承正文颜色，虚线底边，Hover 时平滑点亮为主题色并转为实线) */
    .slide-content a:not(.slidev-ref-tag):not(.slidev-icon-btn):not(.slidev-toc-link),
    .slide-block a:not(.slidev-ref-tag):not(.slidev-icon-btn):not(.slidev-toc-link),
    a.slidev-link {
      color: inherit;
      text-decoration: none;
      border-bottom: 1px dashed currentColor;
      transition: color 0.2s cubic-bezier(0.4, 0, 0.2, 1),
                  border-color 0.2s cubic-bezier(0.4, 0, 0.2, 1),
                  border-bottom-style 0.2s cubic-bezier(0.4, 0, 0.2, 1);
      cursor: pointer;
    }
    .slide-content a:not(.slidev-ref-tag):not(.slidev-icon-btn):not(.slidev-toc-link):hover,
    .slide-block a:not(.slidev-ref-tag):not(.slidev-icon-btn):not(.slidev-toc-link):hover,
    a.slidev-link:hover {
      color: var(--slide-accent);
      border-bottom-style: solid;
      border-bottom-color: var(--slide-accent);
    }
    .slidev-ref-tag, a.slidev-ref-tag {
      display: inline-flex;
      align-items: center;
      background: color-mix(in srgb, var(--slide-accent) 12%, transparent);
      color: var(--slide-accent);
      border-radius: 4px;
      padding: 2px 8px;
      font-size: 0.88em;
      text-decoration: none;
      cursor: pointer;
      margin: 2px 4px 2px 0;
      border: 1px solid color-mix(in srgb, var(--slide-accent) 25%, transparent);
      transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
    }
    .slidev-ref-tag:hover, a.slidev-ref-tag:hover {
      background: color-mix(in srgb, var(--slide-accent) 22%, transparent);
      color: var(--slide-accent);
      border-color: color-mix(in srgb, var(--slide-accent) 55%, transparent);
      transform: translateY(-1px);
      box-shadow: 0 2px 8px color-mix(in srgb, var(--slide-accent) 20%, transparent);
    }
    .slidev-block-ref {
      display: block;
      padding: 10px 14px;
      background: color-mix(in srgb, var(--slide-accent) 8%, transparent);
      border-left: 3px solid var(--slide-accent);
      border-radius: 0 6px 6px 0;
      margin: 8px 0;
      cursor: pointer;
      transition: background 0.2s ease;
    }
    .slidev-block-ref:hover {
      background: color-mix(in srgb, var(--slide-accent) 15%, transparent);
    }`}function mm(){return`    (function() {
      const data = window.__SLIDEV_DATA__ || { slides: [] };
      const slides = data.slides || [];
      let currentIndex = 0;

      const container = document.getElementById("slide-container");
      const pageNum = document.getElementById("page-num");
      const btnPrev = document.getElementById("btn-prev");
      const btnNext = document.getElementById("btn-next");
      const btnFullscreen = document.getElementById("btn-fullscreen");

      const baseWidth = 980;
      const aspectStr = (data.config && data.config.aspectRatio) || "16/9";
      let ratioNum = 16 / 9;
      if (aspectStr === "4/3") ratioNum = 4 / 3;
      else if (aspectStr === "16/10") ratioNum = 16 / 10;
      else if (typeof aspectStr === "string" && aspectStr.includes("/")) {
        const parts = aspectStr.split("/").map(Number);
        if (parts[0] && parts[1]) ratioNum = parts[0] / parts[1];
      }
      const baseHeight = Math.ceil(baseWidth / ratioNum);
      const viewport = document.getElementById("viewport");

      function updateScale() {
        if (!viewport) return;
        const isFull = !!document.fullscreenElement;
        const padX = isFull ? 0 : 20;
        const padY = isFull ? 0 : 32;
        const availW = Math.max(100, window.innerWidth - padX);
        const availH = Math.max(100, window.innerHeight - padY);
        const scale = Math.min(availW / baseWidth, availH / baseHeight);
        viewport.style.width = baseWidth + "px";
        viewport.style.height = baseHeight + "px";
        viewport.style.transform = "translate(-50%, -50%) scale(" + scale + ")";
        viewport.style.setProperty("--slidev-slide-scale", scale);
        if (isFull) document.body.classList.add("is-fullscreen");
        else document.body.classList.remove("is-fullscreen");
      }

      window.addEventListener("resize", updateScale);
      document.addEventListener("fullscreenchange", updateScale);

      function cleanCardListItemMarkdown(rawMarkdown) {
        if (!rawMarkdown) return "";
        let cleaned = rawMarkdown.replace(/^[ 	]*[-*+]s+|^[ 	]*d+.s+/, "");
        cleaned = cleaned.replace(/
[ 	]{2,4}/g, "
");
        return cleaned.trim();
      }

      function isHeadingBlock(b) {
        if (!b) return false;
        if (b.type === "h" || b.type === "NodeHeading") return true;
        if (b.subType && /^h[1-6]$/i.test(b.subType)) return true;
        const md = (b.rawMarkdown || b.content || "").trim();
        if (/^#{1,6}s+/.test(md)) return true;
        if (/^(?:[-*+]|d+.)s+#{1,6}s+/.test(md)) return true;
        return false;
      }

      function cleanColList(blocks) {
        const valid = (blocks || []).filter(b => Boolean((b.rawMarkdown || b.content || "").trim()));
        if (valid.length === 0) return valid;
        const first = valid[0];
        const md = (first.rawMarkdown || first.content || "").trim();
        const isList = /^(?:[-*+]|d+.)s+/.test(md) || first.type === "i" || first.type === "l";
        if (isList) {
          first.rawMarkdown = cleanCardListItemMarkdown(first.rawMarkdown || first.content || "");
          first.content = first.rawMarkdown;
        }
        return valid;
      }

      function renderBlock(block, extraClass) {
        const div = document.createElement("div");
        div.className = "slide-block" + (extraClass ? " " + extraClass : "");
        if (block && block.motion && block.motion.preset && block.motion.preset !== "none") {
          div.classList.add("slidev-motion-" + block.motion.preset.toLowerCase());
          if (typeof block.motion.duration === "number" && block.motion.duration > 0) {
            div.style.setProperty("--motion-duration", block.motion.duration + "ms");
          }
          if (typeof block.motion.delay === "number" && block.motion.delay > 0) {
            div.style.setProperty("--motion-delay", block.motion.delay + "ms");
          }
        }
        const md = block.rawMarkdown || block.content || "";

        if (md.includes('class="slidev-block-ref"') || md.includes('class="slidev-ref-tag"')) {
          div.innerHTML = md;
          return div;
        }

        const CARBON_MAP = {
          'carbon:arrow-right': '<svg viewBox="0 0 32 32" width="1.2em" height="1.2em" fill="currentColor" style="display:inline-block;vertical-align:middle;"><path d="m18 6l-1.43 1.393L24.15 15H4v2h20.15l-7.58 7.573L18 26l10-10z"/></svg>',
          'carbon:arrow-left': '<svg viewBox="0 0 32 32" width="1.2em" height="1.2em" fill="currentColor" style="display:inline-block;vertical-align:middle;"><path d="m14 26l1.43-1.393L7.85 17H28v-2H7.85l7.58-7.573L14 6L4 16z"/></svg>',
          'carbon:edit': '<svg viewBox="0 0 32 32" width="1.2em" height="1.2em" fill="currentColor" style="display:inline-block;vertical-align:middle;"><path d="M2 26h28v2H2zM25.4 9c.8-.8.8-2 0-2.8l-3.6-3.6c-.8-.8-2-.8-2.8 0l-15 15V24h6.4l15-15zM20.4 4L24 7.6l-2.4 2.4l-3.6-3.6L20.4 4zM6 22v-3.6l11-11l3.6 3.6l-11 11H6z"/></svg>',
          'carbon:logo-github': '<svg viewBox="0 0 32 32" width="1.2em" height="1.2em" fill="currentColor" style="display:inline-block;vertical-align:middle;"><path fill-rule="evenodd" d="M16 2a14 14 0 0 0-4.43 27.28c.7.13 1-.3 1-.67v-2.38c-3.89.84-4.71-1.88-4.71-1.88a3.7 3.7 0 0 0-1.56-2.05c-1.27-.86.1-.85.1-.85a2.94 2.94 0 0 1 2.14 1.44a3 3 0 0 0 4.08 1.16a2.93 2.93 0 0 1 .89-1.87c-3.1-.35-6.36-1.55-6.36-6.9a5.4 5.4 0 0 1 1.44-3.75a5 5 0 0 1 .14-3.71s1.17-.38 3.85 1.43a13.3 13.3 0 0 1 7 0c2.67-1.81 3.84-1.43 3.84-1.43a5 5 0 0 1 .14 3.71a5.4 5.4 0 0 1 1.44 3.75c0 5.37-3.27 6.54-6.38 6.89a3.35 3.35 0 0 1 1.26 2.61v3.87c0 .38.26.81 1 .67A14 14 0 0 0 16 2"/></svg>'
        };

        if (/@\\w+=['"]|v-\\w+|<button|<a\\b|<carbon:|^<div/i.test(md)) {
          if (md.includes('abs-br') || md.includes('abs-bl') || md.includes('abs-tr') || md.includes('abs-tl') || md.includes('absolute')) {
            div.classList.add("slide-block--absolute");
          }
          let renderedHtml = md;
          for (const [tag, svg] of Object.entries(CARBON_MAP)) {
            const regex = new RegExp("<" + tag + "\\\\s*\\\\/?>", "gi");
            renderedHtml = renderedHtml.replace(regex, svg);
            const regexDash = new RegExp("<" + tag.replace(":", "-") + "\\\\s*\\\\/?>", "gi");
            renderedHtml = renderedHtml.replace(regexDash, svg);
          }
          div.innerHTML = renderedHtml;

          // 挂载交互事件监听
          const nextBtns = div.querySelectorAll('[\\\\@click*="nav.next"], [\\\\@click*="next"]');
          nextBtns.forEach(btn => {
            btn.style.cursor = "pointer";
            btn.addEventListener("click", (e) => {
              e.stopPropagation();
              renderSlide(currentIndex + 1);
            });
          });

          const prevBtns = div.querySelectorAll('[\\\\@click*="nav.prev"], [\\\\@click*="prev"]');
          prevBtns.forEach(btn => {
            btn.style.cursor = "pointer";
            btn.addEventListener("click", (e) => {
              e.stopPropagation();
              renderSlide(currentIndex - 1);
            });
          });

          return div;
        }

        const hasHeadingTag = /(?:^|
)s*#{1,6}s+/.test(md);
        const hMatch = md.match(/^(#{1,6})\\s+(.*)$/);

        if (hMatch) {
          const level = hMatch[1].length;
          let th = hMatch[2].trim().replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
          div.innerHTML = "<h" + level + ">" + th + "</h" + level + ">";
        }
        else if (md.startsWith("\`\`\`")) {
          const customMaxHeight = block?.attributes?.["custom-slidev-max-height"] || block?.attrs?.["custom-slidev-max-height"] || block?.maxHeight || "";
          const heightStyle = customMaxHeight ? ' style="max-height:' + customMaxHeight + ';overflow-y:auto;"' : "";
          div.innerHTML = "<pre" + heightStyle + "><code>" + md.slice(3, -3) + "</code></pre>";
        }
        else if (md.startsWith("> ")) div.innerHTML = "<blockquote><p>" + md.slice(2) + "</p></blockquote>";
        else if ((/<video\b/i.test(md) || (block && (block.type === "video" || block.type === "NodeVideo"))) && !/^(s*)([-*+]|d+.)s+/m.test(md) && !hasHeadingTag && !md.includes("
")) {
          div.classList.add("slide-video-container", "slide-media-container", "slide-media-block");
          const isAutoplay = block && block.attributes && block.attributes["custom-slidev-autoplay"] === "true";
          const isLoop = block && block.attributes && block.attributes["custom-slidev-loop"] === "true";
          const isMuted = block && block.attributes && (block.attributes["custom-slidev-muted"] === "true" || isAutoplay);
          const hideControls = block && block.attributes && block.attributes["custom-slidev-controls"] === "false";
          let videoHtml = md;
          if (hideControls) videoHtml = videoHtml.replace(/\bcontrols(?:="[^"]*")?/gi, "").trim();
          else if (!videoHtml.includes("controls")) videoHtml = videoHtml.replace("<video", "<video controls");
          if (isAutoplay && !videoHtml.includes("autoplay")) videoHtml = videoHtml.replace("<video", "<video autoplay playsinline");
          if (isLoop && !videoHtml.includes("loop")) videoHtml = videoHtml.replace("<video", "<video loop");
          if (isMuted && !videoHtml.includes("muted")) videoHtml = videoHtml.replace("<video", "<video muted");
          videoHtml = videoHtml.replace("<video", '<video class="slide-video-player"');
          div.setAttribute("data-autoplay", isAutoplay ? "true" : "false");
          div.innerHTML = videoHtml;
        }
        else if (/^(s*)([-*+]|d+.)s+/m.test(md) || (md.includes("
") && /^(s*)([-*+]|d+.)s+/m.test(md.split("
").slice(1).join("
")))) {
          div.classList.add("pdf-list-item");
          const lines = md.split("
");
          let isOrdered = false;
          const items = [];
          const leadLines = [];
          for (let i = 0; i < lines.length; i++) {
            const line = lines[i];
            const tr = line.trim();
            if (!tr || /^{:.*?}$/.test(tr)) continue;
            const um = line.match(/^(s*)[-*+]s+(.*)$/);
            const om = line.match(/^(s*)d+.s+(.*)$/);
            if (um) {
              const indent = um[1].length;
              items.push({ type: "unordered", level: Math.floor(indent / 2), text: um[2], media: [] });
              continue;
            }
            if (om) {
              if (items.length === 0) isOrdered = true;
              const indent = om[1].length;
              items.push({ type: "ordered", level: Math.floor(indent / 2), text: om[2], media: [] });
              continue;
            }
            if (items.length > 0) {
              const im = tr.match(/^![(.*?)]((.*?))(?:{:?[^}]*})?$/);
              if (im) {
                const isGif = /.gif(?:?|$)/i.test(im[2]);
                items[items.length - 1].media.push('<div class="slide-list-media"><img alt="' + im[1] + '" src="' + im[2] + '" class="' + (isGif ? 'list-item-gif' : 'list-item-img') + '" /></div>');
                continue;
              }
              const hm = tr.match(/^<img\b[sS]*?/?>$/i);
              if (hm) {
                const cleanTr = tr.replace(/s+style="[^"]*"/gi, "");
                items[items.length - 1].media.push('<div class="slide-list-media">' + cleanTr + '</div>');
                continue;
              }
              if (/<video\b/i.test(tr)) {
                let vHtml = tr;
                if (!/</video>/i.test(vHtml)) {
                  while (i + 1 < lines.length && !/</video>/i.test(vHtml)) {
                    i++;
                    vHtml += " " + lines[i].trim();
                  }
                }
                const isAutoplay = block && block.attributes && block.attributes["custom-slidev-autoplay"] === "true";
                const isLoop = block && block.attributes && block.attributes["custom-slidev-loop"] === "true";
                const isMuted = block && block.attributes && (block.attributes["custom-slidev-muted"] === "true" || isAutoplay);
                const hideControls = block && block.attributes && block.attributes["custom-slidev-controls"] === "false";
                if (hideControls) vHtml = vHtml.replace(/\bcontrols(?:="[^"]*")?/gi, "").trim();
                else if (!vHtml.includes("controls")) vHtml = vHtml.replace("<video", "<video controls");
                if (isAutoplay && !vHtml.includes("autoplay")) vHtml = vHtml.replace("<video", "<video autoplay playsinline");
                if (isLoop && !vHtml.includes("loop")) vHtml = vHtml.replace("<video", "<video loop");
                if (isMuted && !vHtml.includes("muted")) vHtml = vHtml.replace("<video", "<video muted");
                vHtml = vHtml.replace("<video", '<video class="slide-video-player"');
                items[items.length - 1].media.push('<div class="slide-list-media slide-video-container slide-media-container" data-autoplay="' + (isAutoplay ? 'true' : 'false') + '">' + vHtml + '</div>');
                continue;
              }
              items[items.length - 1].text += "
" + tr;
            } else {
              leadLines.push(tr);
            }
          }

          let leadHtml = "";
          if (leadLines.length > 0) {
            const lParts = [];
            const firstL = leadLines[0];
            const fhm = firstL.match(/^(#{1,6})s+(.*)$/);
            if (fhm) {
              const lvl = fhm[1].length;
              let th = fhm[2].trim().replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
              lParts.push('<h' + lvl + ' class="slide-list-item-title">' + th + '</h' + lvl + '>');
            } else {
              let th = firstL.trim().replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
              lParts.push('<p class="slide-list-item-title">' + th + '</p>');
            }
            if (leadLines.length > 1) {
              const dLines = leadLines.slice(1);
              let pL = [];
              const flushLeadP = () => {
                if (pL.length > 0) {
                  let txt = pL.map(l => l.replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>")).join("<br/>");
                  lParts.push('<p class="slide-list-item-desc">' + txt + '</p>');
                  pL = [];
                }
              };
              for (const l of dLines) {
                const hm = l.match(/^(#{1,6})s+(.*)$/);
                if (hm) {
                  flushLeadP();
                  const lvl = hm[1].length;
                  let th = hm[2].trim().replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
                  lParts.push('<h' + lvl + ' class="slide-list-item-title">' + th + '</h' + lvl + '>');
                } else {
                  pL.push(l);
                }
              }
              flushLeadP();
            }
            leadHtml = lParts.join("
") + "
";
          }

          const tag = isOrdered ? "ol" : "ul";
          const listCls = isOrdered ? "pdf-list pdf-list--ordered" : "pdf-list pdf-list--unordered";
          const liHtml = items.map(it => {
            const med = it.media && it.media.length ? "
" + it.media.join("
") : "";
            const lines = (it.text || "").split("
").map(l => l.trim()).filter(Boolean);
            const hasHeading = lines.some(l => /^#{1,6}s+/.test(l));
            const lvl = it.level || 0;
            const nStyle = lvl > 0 ? ' style="margin-left:' + (lvl * 1.25).toFixed(2) + 'em;' + (it.type === 'unordered' ? 'list-style-type:' + (lvl % 2 === 1 ? 'circle' : 'square') + ' !important;' : '') + '"' : "";
            const nClass = lvl > 0 ? " slide-list-item--nested" : "";
            const clsAttr = nClass ? ' class="' + nClass.trim() + '"' : "";
            if (!hasHeading) {
              let h = lines.map(l => l.replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>")).join("<br/>");
              return '<li' + clsAttr + nStyle + '>' + h + med + '</li>';
            }
            const parts = [];
            let pLines = [];
            const flushP = () => {
              if (pLines.length > 0) {
                let ph = pLines.map(l => l.replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>")).join("<br/>");
                parts.push('<p class="slide-list-item-desc">' + ph + '</p>');
                pLines = [];
              }
            };
            for (const l of lines) {
              const hm = l.match(/^(#{1,6})s+(.*)$/);
              if (hm) {
                flushP();
                const hl = hm[1].length;
                let th = hm[2].trim().replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
                parts.push('<h' + hl + ' class="slide-list-item-title">' + th + '</h' + hl + '>');
              } else {
                pLines.push(l);
              }
            }
            flushP();
            return '<li' + clsAttr + nStyle + '>' + parts.join("
") + med + '</li>';
          }).join("
");
          div.innerHTML = leadHtml + "<" + tag + " class="" + listCls + "">
" + liHtml + "
</" + tag + ">";
        }
        else {
          // 复合块（包含换行、标题或媒体）高保真解析
          const lines = md.split(/\r?
/);
          const subBlocks = [];
          let current = [];
          for (let i = 0; i < lines.length; i++) {
            const line = lines[i];
            const trimmed = line.trim();
            if (/^#{1,6}s+/.test(trimmed)) {
              if (current.length > 0) { subBlocks.push(current.join("
")); current = []; }
              subBlocks.push(trimmed);
              continue;
            }
            if (!trimmed) {
              if (current.length > 0) { subBlocks.push(current.join("
")); current = []; }
              continue;
            }
            if (/^![.*?](.*?)$/.test(trimmed)) {
              if (current.length > 0) { subBlocks.push(current.join("
")); current = []; }
              subBlocks.push(trimmed);
              continue;
            }
            if (/<video\b/i.test(trimmed)) {
              if (current.length > 0) { subBlocks.push(current.join("
")); current = []; }
              let vRaw = trimmed;
              if (!/</video>/i.test(vRaw)) {
                while (i + 1 < lines.length && !/</video>/i.test(vRaw)) {
                  i++;
                  vRaw += "
" + lines[i];
                }
              }
              subBlocks.push(vRaw);
              continue;
            }
            current.push(line);
          }
          if (current.length > 0) subBlocks.push(current.join("
"));

          if (subBlocks.length > 1 || (subBlocks.length === 1 && /^#{1,6}s+/.test(subBlocks[0].trim()))) {
            let isFirstParagraph = true;
            const htmlParts = subBlocks.map(sub => {
              const t = sub.trim();
              if (!t) return "";
              const hm = t.match(/^(#{1,6})s+(.*)$/);
              if (hm) {
                isFirstParagraph = false;
                const hl = hm[1].length;
                let th = hm[2].trim().replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
                return '<h' + hl + ' class="slide-list-item-title">' + th + '</h' + hl + '>';
              }
              const im = t.match(/^![(.*?)]((.*?))$/);
              if (im) {
                return '<div class="slide-media-block slide-media-container slide-list-media"><img alt="' + im[1] + '" src="' + im[2] + '" class="slide-media-img" /></div>';
              }
              if (/<video\b/i.test(t)) {
                return '<div class="slide-media-block slide-video-container slide-media-container">' + t + '</div>';
              }
              if (isFirstParagraph) {
                isFirstParagraph = false;
                const subLines = t.split(/\r?
/).map(l => l.trim()).filter(Boolean);
                if (subLines.length === 1) {
                  let ph = subLines[0].replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
                  return '<p class="slide-list-item-title">' + ph + '</p>';
                }
                let titleHtml = subLines[0].replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
                let descHtml = subLines.slice(1).map(l => l.replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>")).join("<br/>");
                return '<p class="slide-list-item-title">' + titleHtml + '</p>
<p class="slide-list-item-desc">' + descHtml + '</p>';
              }
              let ph = t.replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
              return '<p class="slide-list-item-desc">' + ph + '</p>';
            }).filter(Boolean);
            div.innerHTML = htmlParts.join("
");
          } else {
            const imgMatch = md.match(/!\\[(.*?)\\]\\((.*?)\\)/);
            if (imgMatch) {
              div.classList.add("slide-media-container", "slide-media-block", "slide-block--image");
              div.innerHTML = '<img alt="' + imgMatch[1] + '" src="' + imgMatch[2] + '" class="slide-media-img" />';
            } else {
              let html = md.replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
              const pCls = (block && block.isColFirst) ? ' class="slide-list-item-title"' : '';
              div.innerHTML = "<p" + pCls + ">" + html + "</p>";
            }
          }
        }
        return div;
      }

      function renderSlide(idx) {
        if (slides.length === 0) return;
        currentIndex = Math.max(0, Math.min(idx, slides.length - 1));
        const slide = slides[currentIndex];
        pageNum.textContent = (currentIndex + 1) + " / " + slides.length;

        const pageSp = slide.frontmatter?.spacing;
        const currentSpacing = (pageSp && pageSp !== "inherit") ? pageSp : (data.config?.spacing || "normal");
        container.className = "slide-content layout-" + (slide.frontmatter?.layout || "default") + " spacing-" + currentSpacing;
        if (viewport) viewport.setAttribute("data-spacing", currentSpacing);
        container.innerHTML = "";

        const z = typeof slide.frontmatter?.zoom === "number" && slide.frontmatter.zoom > 0 ? slide.frontmatter.zoom : 1;
        if (z !== 1) {
          container.style.width = (100 / z) + "%";
          container.style.height = (100 / z) + "%";
          container.style.transformOrigin = "top left";
          container.style.transform = "scale(" + z + ")";
        } else {
          container.style.width = "100%";
          container.style.height = "100%";
          container.style.transform = "none";
        }

        if (slide.frontmatter?.layout === "two-cols") {
          const leftCol = document.createElement("div");
          leftCol.className = "two-cols-left";
          const rightCol = document.createElement("div");
          rightCol.className = "two-cols-right";

          const blocks = (slide.blocks || []).filter(b => b.slot !== "slot-divider-right");
          let leftList = [];
          let rightList = [];
          for (const block of blocks) {
            if (block.slot === "right") rightList.push(block);
            else leftList.push(block);
          }
          leftList = cleanColList(leftList);
          rightList = cleanColList(rightList);
          const isCover = slide.frontmatter?.layout === "cover";
          const leftFirstH = !isCover ? leftList.find(isHeadingBlock) : null;
          const rightFirstH = !isCover ? rightList.find(isHeadingBlock) : null;
          for (const b of leftList) leftCol.appendChild(renderBlock(b, b === leftFirstH ? "slidev-col-first-heading-block" : ""));
          for (const b of rightList) rightCol.appendChild(renderBlock(b, b === rightFirstH ? "slidev-col-first-heading-block" : ""));
          container.appendChild(leftCol);
          container.appendChild(rightCol);
        } else if (slide.frontmatter?.layout === "cols-header" || slide.frontmatter?.layout === "two-cols-header" || slide.frontmatter?.layout === "three-cols-header" || slide.frontmatter?.layout === "clover") {
          const isCover = slide.frontmatter?.layout === "cover";
          const isClover = slide.frontmatter?.layout === "clover";
          const blocks = (slide.blocks || []).filter(b => b.slot !== "slot-divider-right");
          let headerBlocks = blocks.filter(b => b.slot === "header");
          if (headerBlocks.length === 0 && blocks.length > 0) {
            const candidate = blocks.find(b => b.type === "h" && (!b.slot || b.slot === "default"));
            if (candidate) headerBlocks = [candidate];
          }
          const rem = blocks.filter(b => !headerBlocks.includes(b));

          let targetCols = isClover ? 4 : 2;
          if (isClover) {
            targetCols = 4;
          } else if (slide.frontmatter?.layout === "three-cols-header") {
            targetCols = 3;
          } else if (slide.frontmatter?.layout === "two-cols-header") {
            targetCols = 2;
          } else {
            let maxCol = 0;
            for (const b of rem) {
              const m = (b.slot || "").match(/^col-(d+)$/i);
              if (m) maxCol = Math.max(maxCol, parseInt(m[1], 10));
            }
            if (maxCol >= 2) {
              targetCols = maxCol;
            } else if (slide.frontmatter?.layoutRatio) {
              const r = slide.frontmatter.layoutRatio.trim();
              if (r.includes(":")) {
                const parts = r.split(":").map(p => parseFloat(p.trim())).filter(n => !isNaN(n) && n > 0);
                if (parts.length >= 2) targetCols = parts.length;
              }
            }
          }

          const hasColSlots = rem.some(b => b.slot && /^col-d+$/i.test(b.slot));
          const isSuperBlockCols = isClover || hasColSlots;

          const containerDiv = document.createElement("div");
          containerDiv.className = (isClover ? "layout-clover-container" : ("layout-cols-header-container " + (targetCols === 2 ? "layout-two-cols-header-container" : (targetCols === 3 ? "layout-three-cols-header-container" : "")))) + (isSuperBlockCols ? " has-superblock-cols" : "");
          const headerDiv = document.createElement("div");
          headerDiv.className = "layout-header-section";
          const gridDiv = document.createElement("div");
          gridDiv.className = (isClover ? "layout-clover-grid pdf-clover-wrapper" : ("layout-cols-wrapper layout-cols-grid " + (targetCols === 2 ? "pdf-two-cols-wrapper layout-two-cols-grid" : (targetCols === 3 ? "pdf-three-cols-wrapper layout-three-cols-grid" : "")))) + (isSuperBlockCols ? " has-superblock-cols" : "");

          const gridCols = isClover ? "repeat(2, minmax(0, 1fr))" : parseRatioToGridCols(slide.frontmatter?.layoutRatio, targetCols);
          if (gridCols) gridDiv.style.gridTemplateColumns = gridCols;
          if (isClover) gridDiv.style.gridTemplateRows = "repeat(2, minmax(0, 1fr))";

          let colsList = [];
          for (let i = 0; i < targetCols; i++) colsList.push([]);
          const hasExplicitCols = rem.some(b => b.slot && (b.slot.startsWith("col-") || b.slot === "left" || b.slot === "right" || b.slot === "center"));
          if (hasExplicitCols) {
            for (const b of rem) {
              let idx = 0;
              if (b.slot === "left" || b.slot === "col-1") idx = 0;
              else if (b.slot === "center" || b.slot === "col-2") idx = 1;
              else if (b.slot === "right") idx = targetCols === 2 ? 1 : targetCols - 1;
              else {
                const m = (b.slot || "").match(/^col-(d+)$/i);
                if (m) idx = Math.min(targetCols - 1, Math.max(0, parseInt(m[1], 10) - 1));
              }
              colsList[idx].push(b);
            }
          } else {
            let cur = 0;
            for (let i = 0; i < targetCols; i++) {
              const remainingCols = targetCols - i;
              const remainingItems = rem.length - cur;
              const take = Math.ceil(remainingItems / remainingCols);
              colsList[i] = rem.slice(cur, cur + take);
              cur += take;
            }
          }

          const headerFirstH = !isCover ? headerBlocks.find(isHeadingBlock) : null;
          for (const b of headerBlocks) headerDiv.appendChild(renderBlock(b, b === headerFirstH ? "slidev-page-first-heading-block" : ""));
          containerDiv.appendChild(headerDiv);

          colsList.forEach((colBlocks, idx) => {
            const colDiv = document.createElement("div");
            colDiv.className = "pdf-col pdf-col--" + (idx + 1) + " col-" + (idx + 1) + (targetCols === 2 && idx === 0 ? " pdf-col--left" : "") + (targetCols === 2 && idx === 1 ? " pdf-col--right" : "");
            const cleaned = cleanColList(colBlocks);
            const colFirstH = !isCover ? (cleaned.find(isHeadingBlock) || cleaned[0]) : null;
            for (const b of cleaned) colDiv.appendChild(renderBlock(b, b === colFirstH ? "slidev-col-first-heading-block" : ""));
            gridDiv.appendChild(colDiv);
          });
          containerDiv.appendChild(gridDiv);
          container.appendChild(containerDiv);
        } else if (slide.frontmatter?.layout === "image-right" || slide.frontmatter?.layout === "image-left") {
          const isImageRight = slide.frontmatter?.layout === "image-right";
          const contentCol = document.createElement("div");
          contentCol.className = isImageRight ? "image-right-content" : "image-left-content";

          const isCover = slide.frontmatter?.layout === "cover";
          const pageFirstH = !isCover ? (slide.blocks || []).find(isHeadingBlock) : null;
          for (const block of (slide.blocks || [])) {
            contentCol.appendChild(renderBlock(block, block === pageFirstH ? "slidev-page-first-heading-block" : ""));
          }

          const imgCol = document.createElement("div");
          imgCol.className = isImageRight ? "image-right-img-container" : "image-left-img-container";
          const img = document.createElement("img");
          img.className = isImageRight ? "image-right-img" : "image-left-img";
          img.src = slide.frontmatter?.image || slide.frontmatter?.background || "";
          img.alt = "Slide cover";
          img.onerror = function() {
            this.src = "https://fastly.jsdelivr.net/gh/slidevjs/slidev-covers@main/static/2HmfbSpvcos.webp";
          };
          imgCol.appendChild(img);

          if (isImageRight) {
            container.appendChild(contentCol);
            container.appendChild(imgCol);
          } else {
            container.appendChild(imgCol);
            container.appendChild(contentCol);
          }
        } else {
          const isCover = slide.frontmatter?.layout === "cover";
          const validBlocks = (slide.blocks || []).filter(b => b.slot !== "slot-divider-right");
          const pageFirstH = !isCover ? validBlocks.find(isHeadingBlock) : null;
          for (const block of (slide.blocks || [])) {
            container.appendChild(renderBlock(block, block === pageFirstH ? "slidev-page-first-heading-block" : ""));
          }
        }

        function syncAutoplayVideos() {
          const doSync = () => {
            const videos = container.querySelectorAll("video");
            videos.forEach((v) => {
              const box = v.closest("[data-autoplay]");
              const isAuto = v.hasAttribute("autoplay") || v.autoplay || (box && box.getAttribute("data-autoplay") === "true");
              if (isAuto) {
                v.muted = true;
                v.defaultMuted = true;
                v.setAttribute("muted", "");
                v.playsInline = true;
                v.setAttribute("playsinline", "");
                const playFn = () => {
                  if (!v.paused) return;
                  v.muted = true;
                  v.defaultMuted = true;
                  const p = v.play();
                  if (p !== undefined) {
                    p.catch(() => {
                      v.muted = true;
                      v.defaultMuted = true;
                      setTimeout(() => { if (v.paused) v.play().catch(() => {}); }, 150);
                    });
                  }
                };
                playFn();
                if (!v.__autoplayBound) {
                  v.__autoplayBound = true;
                  v.addEventListener("loadedmetadata", playFn);
                  v.addEventListener("canplay", playFn);
                }
              }
            });
          };
          setTimeout(doSync, 60);
          setTimeout(doSync, 200);
        }
        syncAutoplayVideos();
      }

      // Lightbox 控制逻辑
      const lightbox = document.getElementById("slidev-lightbox");
      const lightboxContent = document.getElementById("lightbox-content");
      const lightboxClose = document.getElementById("lightbox-close");
      let isLightboxOpen = false;

      function openLightbox(type, src, alt) {
        if (!lightbox || !lightboxContent) return;
        lightboxContent.innerHTML = "";
        if (type === "video") {
          const v = document.createElement("video");
          v.className = "slidev-lightbox-video";
          v.src = src;
          v.controls = true;
          v.autoplay = true;
          v.playsInline = true;
          lightboxContent.appendChild(v);
        } else {
          const img = document.createElement("img");
          img.className = "slidev-lightbox-img";
          img.src = src;
          img.alt = alt || "";
          lightboxContent.appendChild(img);
        }
        lightbox.classList.add("active");
        isLightboxOpen = true;
      }

      function closeLightbox() {
        if (!lightbox) return;
        const v = lightbox.querySelector("video");
        if (v) v.pause();
        lightbox.classList.remove("active");
        if (lightboxContent) lightboxContent.innerHTML = "";
        isLightboxOpen = false;
      }

      if (lightboxClose) {
        lightboxClose.addEventListener("click", (e) => {
          e.stopPropagation();
          closeLightbox();
        });
      }
      if (lightbox) {
        lightbox.addEventListener("click", (e) => {
          if (e.target === lightbox || e.target === lightboxClose) {
            e.stopPropagation();
            closeLightbox();
          }
        });
      }

      btnPrev.addEventListener("click", () => renderSlide(currentIndex - 1));
      btnNext.addEventListener("click", () => renderSlide(currentIndex + 1));
      btnFullscreen.addEventListener("click", () => {
        if (!document.fullscreenElement) {
          document.documentElement.requestFullscreen().then(() => updateScale()).catch(() => {});
        } else {
          document.exitFullscreen().then(() => updateScale()).catch(() => {});
        }
      });

      window.addEventListener("keydown", (e) => {
        if (e.key === "Escape" || e.key === "Esc") {
          if (isLightboxOpen) {
            closeLightbox();
            e.preventDefault();
            return;
          }
        }
        if (isLightboxOpen) return;
        if (e.key === "ArrowRight" || e.key === " ") renderSlide(currentIndex + 1);
        if (e.key === "ArrowLeft") renderSlide(currentIndex - 1);
        if (e.key === "f" || e.key === "F") btnFullscreen.click();
      });

      // 监听鼠标滚轮上下翻页调度
      let lastWheelTime = 0;
      const WHEEL_COOLDOWN_MS = 280;
      const WHEEL_DELTA_THRESHOLD = 15;

      function canElementScrollY(el, deltaY) {
        let cur = el;
        while (cur && cur !== document.body && cur !== document.documentElement) {
          if (cur.classList && (cur.classList.contains("slidev-viewport") || cur.classList.contains("slidev-stage") || cur.classList.contains("slide-container"))) {
            break;
          }
          const style = window.getComputedStyle(cur);
          const overflowY = style.overflowY;
          if (overflowY === "auto" || overflowY === "scroll") {
            const maxScroll = cur.scrollHeight - cur.clientHeight;
            if (maxScroll > 2) {
              if (deltaY > 0 && cur.scrollTop < maxScroll - 1) return true;
              if (deltaY < 0 && cur.scrollTop > 1) return true;
            }
          }
          cur = cur.parentElement;
        }
        return false;
      }

      window.addEventListener("wheel", (e) => {
        if (isLightboxOpen) return;
        if (Math.abs(e.deltaY) < Math.abs(e.deltaX)) return;
        if (Math.abs(e.deltaY) < WHEEL_DELTA_THRESHOLD) return;

        const target = e.target instanceof Element ? e.target : e.target?.parentElement;
        if (target && canElementScrollY(target, e.deltaY)) return;

        e.preventDefault();
        const now = Date.now();
        if (now - lastWheelTime < WHEEL_COOLDOWN_MS) return;
        lastWheelTime = now;

        if (e.deltaY > 0) {
          renderSlide(currentIndex + 1);
        } else {
          renderSlide(currentIndex - 1);
        }
      }, { passive: false });

      document.addEventListener("click", (e) => {
        if (isLightboxOpen) {
          const target = e.target instanceof Element ? e.target : e.target?.parentElement;
          const isMediaItself = target && target.closest && target.closest(".slidev-lightbox-img, .slidev-lightbox-video");
          if (!isMediaItself) {
            e.stopPropagation();
            closeLightbox();
          }
          return;
        }
        if (e.button !== 0) return;
        const targetEl = e.target instanceof Element ? e.target : e.target?.parentElement;
        if (!targetEl || !targetEl.closest) return;

        const refEl = targetEl.closest("[data-ref-id]");
        if (refEl) {
          const id = refEl.getAttribute("data-ref-id");
          if (id) {
            window.open("siyuan://blocks/" + id, "_blank");
            return;
          }
        }

        // 媒体点击唤起 Lightbox 放大模态
        const mediaEl = targetEl.closest(".slide-content img, .slide-content video");
        if (mediaEl && !mediaEl.closest(".controls, .controls-bar, button, a")) {
          e.stopPropagation();
          const isVideo = mediaEl.tagName.toLowerCase() === "video";
          const src = isVideo ? (mediaEl.currentSrc || mediaEl.src || mediaEl.querySelector("source")?.src) : mediaEl.src;
          if (src) {
            openLightbox(isVideo ? "video" : "image", src, mediaEl.alt || "");
            return;
          }
        }

        const selection = window.getSelection ? window.getSelection().toString().trim() : "";
        if (selection.length > 0) return;

        const isComponent = targetEl.closest(
          ".slide-block, .controls-bar, .image-right-img-container, .image-left-img-container, .controls, img, video, audio, button, a, input, textarea, select, [data-clickable], [data-ref-id], .slidev-toc, .empty-state"
        );
        if (isComponent) return;

        const isLeft = e.clientX < window.innerWidth / 2;
        if (isLeft) {
          renderSlide(currentIndex - 1);
        } else {
          renderSlide(currentIndex + 1);
        }
      });

      renderSlide(0);
      updateScale();
    })();`}function va(t,e){const i="Slidev 演示文稿";let n=t.slides;const o=JSON.stringify(n),s=JSON.stringify(t.config);return`<!DOCTYPE html>
<html lang="zh-CN">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${ce(i)}</title>
  <style>
${hm(e==null?void 0:e.customInlineStyles)}
  </style>
  <script>
    // 注入演示数据载荷
    window.__SLIDEV_DATA__ = {
      docId: ${JSON.stringify(t.docId)},
      slides: ${o},
      config: ${s}
    };
  <\/script>
</head>
<body>
  <div id="app" data-normalize-headings="${t.config.normalizeHeadingSizes?"true":"false"}">
    <div class="slide-viewport slidev-theme-${t.config.theme||"default"}" id="viewport" data-slidev-theme="${t.config.theme||"default"}">
      <div class="slide-content" id="slide-container"></div>
    </div>
    <div class="controls">
      <button id="btn-prev">◀ 上一页</button>
      <span id="page-num">1 / 1</span>
      <button id="btn-next">下一页 ▶</button>
      <button id="btn-fullscreen">全屏</button>
    </div>
    <!-- 全屏媒体灯箱 (Lightbox) 模态窗口 -->
    <div id="slidev-lightbox" class="slidev-lightbox">
      <button class="slidev-lightbox-close" id="lightbox-close" aria-label="关闭 (Esc)">✕</button>
      <div class="slidev-lightbox-content" id="lightbox-content"></div>
    </div>
  </div>

  <script>
${mm()}
  <\/script>
</body>
</html>`}function ba(t,e){if(typeof document>"u")return!1;const i=new Blob([e],{type:"text/html;charset=utf-8"}),n=URL.createObjectURL(i),o=document.createElement("a");return o.href=n,o.download=t.endsWith(".html")?t:`${t}.html`,document.body.appendChild(o),o.click(),document.body.removeChild(o),URL.revokeObjectURL(n),!0}function gm(t){switch(t){case"4:3":return"size: 12in 9in;";case"A4-landscape":return"size: 297mm 210mm;";case"A4-portrait":return"size: 210mm 297mm;";case"16:9":default:return"size: 16in 9in;"}}function vm(t){const e=gm(t==null?void 0:t.pageRatio);return`
    ${kn(t==null?void 0:t.customInlineStyles)}

    @page {
      ${e}
      margin: 0;
    }
    * {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
      -webkit-print-color-adjust: exact !important;
      print-color-adjust: exact !important;
    }
    body {
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "PingFang SC", "Microsoft YaHei", sans-serif;
      background: #f8fafc;
      color: #1e293b;
    }
    .pdf-slide-page {
      width: 100vw;
      height: 100vh;
      page-break-after: always;
      break-after: page;
      padding: var(--slidev-padding-y, 36px) var(--slidev-padding-x, 56px);
      display: flex;
      flex-direction: column;
      position: relative;
      background: #ffffff;
      overflow: hidden;
    }
    .pdf-slide-page.spacing-compact {
      --slidev-padding-y: 20px;
      --slidev-padding-x: 36px;
      --slidev-header-gap: 10px;
      --slidev-title-margin-bottom: 6px;
    }
    .pdf-slide-page.spacing-normal {
      --slidev-padding-y: 36px;
      --slidev-padding-x: 56px;
      --slidev-header-gap: 16px;
      --slidev-title-margin-bottom: 10px;
    }
    .pdf-slide-page.spacing-loose {
      --slidev-padding-y: 48px;
      --slidev-padding-x: 64px;
      --slidev-header-gap: 24px;
      --slidev-title-margin-bottom: 16px;
    }
    .pdf-slide-page.theme-dark {
      background: #0f1117;
      color: #f1f5f9;
    }
    .pdf-slide-header {
      font-size: 13px;
      color: #64748b;
      margin-bottom: 24px;
      display: flex;
      justify-content: space-between;
      border-bottom: 1px solid #e2e8f0;
      padding-bottom: 8px;
    }
    .theme-dark .pdf-slide-header {
      border-bottom-color: #2e3346;
      color: #94a3b8;
    }
    .pdf-slide-body {
      flex: 1;
      display: flex;
      flex-direction: column;
      gap: 16px;
      font-size: 20px;
      line-height: 1.6;
      overflow: hidden;
    }
    .pdf-block h1 { font-size: 2.5rem; font-weight: 800; color: #2563eb; margin-bottom: 12px; }
    .pdf-block h2 { font-size: 1.9rem; font-weight: 700; color: #1d4ed8; margin-bottom: 10px; }
    .pdf-block h3 { font-size: 1.4rem; font-weight: 600; margin-bottom: 8px; }
    .pdf-block h4 { font-size: 1.2rem; font-weight: 600; margin-bottom: 6px; }
    .pdf-block p { font-size: 1.15rem; color: inherit; }
    .pdf-code,
    pre {
      background: #f1f5f9;
      padding: 14px 18px;
      border-radius: 6px;
      font-family: "JetBrains Mono", Consolas, monospace;
      font-size: 0.95rem;
      border-left: 4px solid #3b82f6;
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      max-width: 100% !important;
      box-sizing: border-box !important;
    }
    .pdf-code code,
    pre code {
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      display: block !important;
      width: 100% !important;
      box-sizing: border-box !important;
    }
    .code-line {
      display: flex !important;
      align-items: flex-start !important;
      width: 100% !important;
      box-sizing: border-box !important;
      line-height: 1.6;
    }
    .code-line .line-no {
      display: inline-block !important;
      flex-shrink: 0 !important;
      min-width: 2.2em !important;
      text-align: right !important;
      margin-right: 12px !important;
      user-select: none !important;
      opacity: 0.45 !important;
    }
    .code-line .line-content {
      flex: 1 1 0% !important;
      min-width: 0 !important;
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
    }
    .theme-dark .pdf-code {
      background: #1e1e24;
      border-left-color: #60a5fa;
    }
    .pdf-quote {
      border-left: 4px solid #10b981;
      background: rgba(16, 185, 129, 0.08);
      padding: 10px 16px;
      border-radius: 0 4px 4px 0;
      font-style: italic;
    }
    .pdf-image,
    .slide-media-img {
      max-width: 100% !important;
      max-height: 48vh !important;
      width: auto !important;
      height: auto !important;
      object-fit: contain !important;
      border-radius: 6px;
      margin: auto;
      display: block;
    }
    .slide-media-block,
    .slide-media-container,
    .slide-video-container {
      display: flex;
      flex-direction: column;
      justify-content: center;
      align-items: center;
      width: 100%;
      max-height: 48vh;
      margin: 8px 0;
      overflow: hidden;
    }
    .slide-list-media {
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: flex-start;
      margin-top: 8px;
      margin-bottom: 6px;
      max-width: 100%;
      overflow: hidden;
    }
    .slide-list-media img,
    .slide-list-media video,
    .slide-list-media .list-item-gif {
      max-width: 100% !important;
      max-height: min(280px, 36vh) !important;
      width: auto !important;
      height: auto !important;
      min-width: 0 !important;
      min-height: 0 !important;
      object-fit: contain !important;
      border-radius: 6px;
      display: block;
      margin: 0 auto !important;
    }
    .slide-video-player {
      max-width: 100% !important;
      max-height: 48vh !important;
      width: auto !important;
      height: auto !important;
      object-fit: contain !important;
      border-radius: 6px;
      background: #000;
      border: 1px solid #cbd5e1;
    }
    .pdf-two-cols-wrapper,
    .layout-two-cols-grid,
    .layout-cols-wrapper,
    .layout-cols-grid {
      display: grid;
      grid-template-columns: minmax(0, 1fr) minmax(0, 1fr);
      grid-template-rows: minmax(0, 1fr) !important;
      gap: 36px;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      overflow: hidden !important;
    }
    .layout-cols-header-container,
    .layout-two-cols-header-container,
    .layout-three-cols-header-container,
    .layout-clover-container {
      display: flex;
      flex-direction: column;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      overflow: hidden !important;
    }
    .layout-header-section {
      width: 100%;
      margin-bottom: var(--slidev-header-gap, 16px) !important;
      flex-shrink: 0;
    }
    .layout-header-section h1,
    .layout-header-section h2,
    .layout-header-section h3 {
      margin-bottom: var(--slidev-title-margin-bottom, 10px) !important;
    }
    .pdf-three-cols-wrapper,
    .layout-three-cols-grid {
      display: grid;
      grid-template-columns: minmax(0, 1fr) minmax(0, 1fr) minmax(0, 1fr);
      grid-template-rows: minmax(0, 1fr) !important;
      gap: 24px;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      box-sizing: border-box;
      overflow: hidden !important;
    }
    .pdf-clover-wrapper,
    .layout-clover-grid {
      display: grid;
      grid-template-columns: repeat(2, minmax(0, 1fr)) !important;
      grid-template-rows: repeat(2, minmax(0, 1fr)) !important;
      gap: 20px;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      box-sizing: border-box;
      overflow: hidden !important;
    }
    .layout-clover-grid .pdf-col {
      background: transparent !important;
      border: none !important;
      box-shadow: none !important;
    }
    .pdf-col {
      display: flex;
      flex-direction: column;
      gap: 14px;
      min-width: 0;
      width: 100%;
      max-width: 100%;
      height: 100%;
      max-height: 100%;
      min-height: 0;
      justify-content: flex-start;
      overflow: hidden;
      box-sizing: border-box;
      overflow-wrap: break-word;
      word-break: break-word;
      white-space: normal;
    }
    /* 表头多栏内超级块子块首个列表项去圆点后居中显示标题/首行文本 (仅在存在超级块分栏时生效) */
    .has-superblock-cols .pdf-col > *:first-child .slide-list-item-title,
    .has-superblock-cols .pdf-col > *:first-child :is(h1, h2, h3, h4, h5, h6),
    .has-superblock-cols .pdf-col > *:first-child p.slide-list-item-title,
    .has-superblock-cols .pdf-col > *:first-child p:first-of-type,
    .has-superblock-cols .pdf-col > *:first-child p:first-child,
    .has-superblock-cols .pdf-col > *:first-child :is(ul, ol) > li:first-child,
    .has-superblock-cols .pdf-col > *:first-child .slide-list > .slide-list-item:first-child,
    .has-superblock-cols .pdf-col > *:first-child .pdf-list > li:first-child,
    .has-superblock-cols .slidev-col-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    .has-superblock-cols .slidev-col-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      list-style: none !important;
      list-style-type: none !important;
      text-align: center !important;
      margin-left: 0 !important;
      padding-left: 0 !important;
      width: 100% !important;
    }

    /* 彻底清除首个列表项的原生圆点 Marker (仅在存在超级块分栏时生效) */
    .has-superblock-cols .pdf-col > *:first-child :is(ul, ol) > li:first-child::marker {
      content: "" !important;
      display: none !important;
    }

    /* 确保首个列表项内部内联与块级元素居中 (仅在存在超级块分栏时生效) */
    .has-superblock-cols .pdf-col > *:first-child :is(ul, ol) > li:first-child * {
      text-align: center !important;
    }

    /* 栏内说明段落与列表项：左对齐，自然阅读排版 */
    .has-superblock-cols .pdf-col .slide-list-item-desc,
    .has-superblock-cols .pdf-col li:not(:first-child) {
      text-align: left !important;
    }

    /* 全局特定标题大小规范化 (除封面外页首首个标题按 H2 1.7rem，表头多栏内首个标题按 H3 1.3rem) */
    [data-normalize-headings="true"] .slidev-page-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .slidev-page-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .pdf-slide:not(.layout-cover) > :is(.pdf-block, .slide-block):first-child :is(h1, h2, h3, h4, h5, h6),
    [data-normalize-headings="true"] .pdf-slide:not(.layout-cover) > .layout-header-section :is(.pdf-block, .slide-block):first-child :is(h1, h2, h3, h4, h5, h6),
    [data-normalize-headings="true"] .pdf-slide:not(.layout-cover) > :not(.layout-cols-wrapper):not(.pdf-two-cols-wrapper):not(.layout-image-cols-grid):first-child :is(h1, h2, h3, h4, h5, h6) {
      font-size: 1.7rem !important;
      font-weight: 600 !important;
      line-height: 1.25 !important;
      margin-bottom: 10px !important;
    }

    [data-normalize-headings="true"] .has-superblock-cols .slidev-col-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .has-superblock-cols .slidev-col-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .has-superblock-cols .pdf-col > *:first-child :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      font-size: 1.3rem !important;
      font-weight: 600 !important;
      line-height: 1.3 !important;
      margin-bottom: 8px !important;
      text-align: center !important;
    }

    /* 图左与图右版式标题完全保留用户原始字号与默认排版，不进行任何固定大小规范化 */
    [data-normalize-headings="true"] :is(.layout-image-left, .layout-image-right, .image-left-content, .image-right-content) :is(h1, h2, h3, h4, h5, h6) {
      text-align: left !important;
    }
    .pdf-col > .pdf-block,
    .pdf-col > .slide-block {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      max-height: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      width: 100% !important;
      height: 100% !important;
      box-sizing: border-box !important;
      overflow: hidden !important;
    }
    .pdf-col .slide-list-item-title,
    .pdf-col h1, .pdf-col h2, .pdf-col h3, .pdf-col h4, .pdf-col h5, .pdf-col h6,
    .pdf-col .slide-list-item-desc {
      flex: 0 0 auto !important;
      margin-top: 0 !important;
      margin-bottom: 6px !important;
    }
    .pdf-col .slide-list-media,
    .pdf-col .slide-video-container,
    .pdf-col .slide-media-container {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      min-width: 0 !important;
      width: 100% !important;
      height: 100% !important;
      max-height: 100% !important;
      max-width: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
      justify-content: flex-start !important;
      overflow: hidden !important;
      margin: 0 !important;
      padding: 0 !important;
      box-sizing: border-box !important;
    }
    .pdf-col li:has(.slide-list-media),
    .pdf-col li:has(.slide-media-container),
    .pdf-col li:has(.slide-video-container),
    .pdf-col li:has(img),
    .pdf-col li:has(video),
    .pdf-col .pdf-list-item:has(.slide-list-media),
    .pdf-col .pdf-list-item:has(.slide-media-container),
    .pdf-col .pdf-list-item:has(.slide-video-container),
    .pdf-col .pdf-list-item:has(img),
    .pdf-col .pdf-list-item:has(video) {
      display: list-item !important;
      list-style-type: disc !important;
      flex: 0 0 auto !important;
      height: auto !important;
      max-height: none !important;
      overflow: visible !important;
      margin-bottom: 6px !important;
    }
    .pdf-col video,
    .layout-three-cols-grid video,
    .layout-two-cols-grid video,
    .pdf-col img,
    .layout-three-cols-grid img,
    .layout-two-cols-grid img,
    .pdf-col .slide-video-player {
      max-width: 100% !important;
      max-height: 100% !important;
      width: auto !important;
      height: auto !important;
      min-width: 0 !important;
      min-height: 0 !important;
      object-fit: contain !important;
      display: block !important;
      margin: 0 auto !important;
    }
    .pdf-col * {
      overflow-wrap: break-word;
      word-break: break-word;
      box-sizing: border-box;
    }
    .pdf-col pre {
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      max-width: 100% !important;
      box-sizing: border-box !important;
    }
    .pdf-list-item {
      padding-left: 20px;
    }
    .pdf-list {
      padding-left: 24px;
      margin: 8px 0;
      display: flex;
      flex-direction: column;
      gap: 6px;
    }
    .pdf-list li {
      font-size: 1.15rem;
      line-height: 1.6;
    }
    .pdf-task-item {
      list-style: none;
      margin-left: -20px;
      display: flex;
      align-items: center;
      gap: 8px;
    }
    .pdf-task-item input[type="checkbox"] {
      width: 1.15em;
      height: 1.15em;
      cursor: pointer;
    }
    /* 两栏与三栏及多栏（超级块分栏）布局：紧凑自然行距，子列表保留圆点与层级缩进 */
    .layout-two-cols ul,
    .layout-cols-header ul,
    .layout-two-cols-header ul,
    .layout-three-cols ul,
    .layout-three-cols-header ul,
    .two-cols-left ul,
    .two-cols-right ul,
    .three-cols-col ul,
    .col ul,
    .pdf-two-cols-wrapper ul,
    .pdf-three-cols-wrapper ul,
    .pdf-col ul,
    .layout-two-cols-grid .pdf-list,
    .layout-three-cols-grid .pdf-list,
    .layout-cols-grid .pdf-list,
    .layout-two-cols-grid .pdf-list--unordered,
    .layout-three-cols-grid .pdf-list--unordered,
    .layout-cols-grid .pdf-list--unordered {
      list-style: disc !important;
      list-style-type: disc !important;
      padding-left: 1.25em !important;
      margin-left: 0 !important;
      margin-top: 0 !important;
      margin-bottom: 8px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: block !important;
    }
    .layout-two-cols ol,
    .layout-cols-header ol,
    .layout-two-cols-header ol,
    .layout-three-cols ol,
    .layout-three-cols-header ol,
    .two-cols-left ol,
    .two-cols-right ol,
    .three-cols-col ol,
    .col ol,
    .pdf-two-cols-wrapper ol,
    .pdf-three-cols-wrapper ol,
    .pdf-col ol,
    .layout-two-cols-grid .pdf-list--ordered,
    .layout-three-cols-grid .pdf-list--ordered,
    .layout-cols-grid .pdf-list--ordered {
      list-style: decimal !important;
      list-style-type: decimal !important;
      padding-left: 1.25em !important;
      margin-left: 0 !important;
      margin-top: 0 !important;
      margin-bottom: 8px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: block !important;
    }
    .layout-two-cols li,
    .layout-cols-header li,
    .layout-two-cols-header li,
    .layout-three-cols li,
    .layout-three-cols-header li,
    .two-cols-left li,
    .two-cols-right li,
    .three-cols-col li,
    .col li,
    .pdf-col li,
    .pdf-col .pdf-list-item {
      padding-left: 0.2em !important;
      margin-left: 0 !important;
      margin-bottom: 6px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: list-item !important;
      line-height: 1.6 !important;
    }
    .layout-two-cols ul ul,
    .layout-three-cols ul ul,
    .three-cols-col ul ul,
    .pdf-col ul ul {
      list-style: circle !important;
      list-style-type: circle !important;
      padding-left: 1.25em !important;
      margin-top: 4px !important;
      margin-bottom: 4px !important;
    }
    /* 列表项内嵌标题与说明排版 */
    .slide-list-item-title,
    .pdf-list li > h1,
    .pdf-list li > h2,
    .pdf-list li > h3,
    .pdf-list li > h4,
    .pdf-list li > h5,
    .pdf-list li > h6,
    li > h1.slide-list-item-title,
    li > h2.slide-list-item-title,
    li > h3.slide-list-item-title,
    li > h4.slide-list-item-title {
      margin-top: 2px !important;
      margin-bottom: 6px !important;
      line-height: 1.35 !important;
      font-weight: 700 !important;
    }
    .pdf-list li > h1, li > h1.slide-list-item-title { font-size: 1.6rem !important; }
    .pdf-list li > h2, li > h2.slide-list-item-title { font-size: 1.4rem !important; }
    .pdf-list li > h3, li > h3.slide-list-item-title { font-size: 1.22rem !important; }
    .pdf-list li > h4, li > h4.slide-list-item-title { font-size: 1.1rem !important; }

    /* 全局特定标题大小规范化后置强力锁定 (防止被列表项内部字号覆盖) */
    [data-normalize-headings="true"] .slidev-page-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .slidev-page-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      font-size: 1.7rem !important;
      font-weight: 600 !important;
      line-height: 1.25 !important;
      margin-bottom: 10px !important;
    }
    [data-normalize-headings="true"] .has-superblock-cols .slidev-col-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .has-superblock-cols .slidev-col-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .has-superblock-cols .pdf-col > *:first-child :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      font-size: 1.3rem !important;
      font-weight: 600 !important;
      line-height: 1.3 !important;
      margin-bottom: 8px !important;
      text-align: center !important;
    }
    .slide-list-item-desc,
    .pdf-list li > p {
      margin-top: 4px !important;
      margin-bottom: 6px !important;
      font-size: 1.05rem;
      line-height: 1.55;
      opacity: 0.92;
    }
    kbd {
      display: inline-block;
      padding: 2px 7px;
      font-family: ui-monospace, SFMono-Regular, "SF Mono", Menlo, Consolas, "Liberation Mono", monospace;
      font-size: 0.85em;
      font-weight: 600;
      line-height: 1.25;
      color: inherit;
      background: rgba(125, 125, 125, 0.12);
      border: 1px solid rgba(125, 125, 125, 0.35);
      border-bottom-width: 2px;
      border-radius: 5px;
      box-shadow: 0 1px 2px rgba(0, 0, 0, 0.12);
      margin: 0 2px;
      vertical-align: middle;
      white-space: nowrap;
    }
    .theme-dark kbd {
      background: rgba(255, 255, 255, 0.1);
      border-color: rgba(255, 255, 255, 0.25);
      border-bottom-color: rgba(255, 255, 255, 0.4);
      color: #f1f5f9;
      box-shadow: 0 1px 2px rgba(0, 0, 0, 0.4);
    }
    a {
      color: inherit;
      text-decoration: none;
      border-bottom: 1px dashed currentColor;
    }
    .slidev-ref-tag, a.slidev-ref-tag {
      display: inline-flex;
      align-items: center;
      background: rgba(16, 185, 129, 0.1);
      color: #059669;
      border: 1px solid rgba(16, 185, 129, 0.25);
      border-radius: 4px;
      padding: 2px 8px;
      font-size: 0.88em;
      text-decoration: none;
      margin: 2px 4px 2px 0;
    }
    .theme-dark .slidev-ref-tag, .theme-dark a.slidev-ref-tag {
      background: rgba(52, 211, 153, 0.15);
      color: #34d399;
      border-color: rgba(52, 211, 153, 0.3);
    }
    .slidev-block-ref, .pdf-block--ref {
      background: rgba(16, 185, 129, 0.06);
      border-left: 3px solid #059669;
      border-radius: 0 6px 6px 0;
      padding: 10px 14px;
      margin: 8px 0;
    }
    .theme-dark .slidev-block-ref, .theme-dark .pdf-block--ref {
      background: rgba(52, 211, 153, 0.08);
      border-left-color: #34d399;
    }
    .pdf-slide-notes {
      font-size: 14px;
      color: #059669;
      border-top: 1px dashed #cbd5e1;
      padding-top: 12px;
      margin-top: auto;
      line-height: 1.5;
    }
    .theme-dark .pdf-slide-notes {
      color: #34d399;
      border-top-color: #334155;
    }
    /* Layouts */
    .layout-cover .pdf-slide-body {
      justify-content: center;
      align-items: center;
      text-align: center;
    }
    .layout-cover h1 {
      font-size: 3.2rem;
    }
    .layout-center .pdf-slide-body {
      justify-content: center;
      align-items: center;
      text-align: center;
    }
    .layout-fact .pdf-slide-body {
      justify-content: center;
      align-items: center;
      text-align: center;
    }
    .layout-fact h1 {
      font-size: 4.5rem;
      color: #ef4444;
    }
    @media print {
      .slidev-motion-fade-in,
      .slidev-motion-slide-up,
      .slidev-motion-slide-down,
      .slidev-motion-slide-left,
      .slidev-motion-slide-right,
      .slidev-motion-zoom-in,
      .slidev-motion-pop,
      .slidev-motion-bounce {
        animation: none !important;
        opacity: 1 !important;
        transform: none !important;
      }
    }
  `}function bm(t,e){const i="Slidev 演示讲义",n="16:9",o="light",s=t.slides.map((l,r)=>{const a=l.frontmatter.layout||"default",c=l.frontmatter.spacing,u=c&&c!=="inherit"?c:t.config.spacing||"normal",m=lm(l),g=`${r+1} / ${t.slides.length}`;return`
      <section class="pdf-slide-page layout-${a} theme-${o} spacing-${u}">
        <header class="pdf-slide-header">
          <span class="pdf-doc-title">${ce(i)}</span>
          ${`<span class="pdf-page-badge">P. ${g}</span>`}
        </header>
        <div class="pdf-slide-body">
          ${m}
        </div>
        ${l.notes?`
          <footer class="pdf-slide-notes">
            <strong>演讲备注:</strong> ${ce(l.notes)}
          </footer>
        `:""}
      </section>
    `}).join(`
`);return`<!DOCTYPE html>
<html lang="zh-CN">
<head>
  <meta charset="UTF-8">
  <title>${ce(i)} - 高保真讲义</title>
  <style>
    ${vm({pageRatio:n,customInlineStyles:e==null?void 0:e.customInlineStyles})}
  </style>
</head>
<body data-normalize-headings="${t.config.normalizeHeadingSizes?"true":"false"}">
  ${s}
</body>
</html>`}function ya(t,e){var o;if(typeof window>"u"||typeof document>"u")return!1;const i=bm(t,e);try{const s=document.createElement("iframe");s.style.position="fixed",s.style.right="0",s.style.bottom="0",s.style.width="0",s.style.height="0",s.style.border="none",s.style.visibility="hidden",document.body.appendChild(s);const l=(o=s.contentWindow)==null?void 0:o.document;if(l)return l.open(),l.write(i),l.close(),setTimeout(()=>{var r,a;try{(r=s.contentWindow)==null||r.focus(),(a=s.contentWindow)==null||a.print()}finally{setTimeout(()=>{s.remove()},2e3)}},350),!0}catch(s){console.warn("[pdf-exporter] iframe 打印模式异常，降级尝试 window.open:",s)}const n=window.open("","_blank");return n?(n.document.write(i),n.document.close(),n.focus(),setTimeout(()=>{n.print(),n.close()},350),!0):!1}const ym={class:"spm-slidev-preview-tab"},km={class:"spm-slidev-tab__toolbar"},wm={class:"spm-slidev-tab__actions"},xm=["disabled"],Sm={class:"spm-page-badge"},_m=["disabled"],Cm=["aria-label"],$m=["aria-label"],Im=["src"],Am=Ce({__name:"SlidevPreviewTab",setup(t,{expose:e}){const i=ei("plugin"),n=ei("sandboxBridge",new Fs),o=new nm(n),s=new yf,l=vt("web-sandbox"),r=vt(3030),a=vt(null),c=vt(!1),u=vt(null),m=vt(1),g=vt(1),d=vt([]),b=vt(!1),f=vt(!1),v=vt(!1),k=vt("siyuan"),S=vt(""),x=vt(""),B=vt(""),E=vt(!1),A=vt(!1),w=vt(""),F=vt("/plugins/siyuan-slidev/slidev-client/index.html");let H=null,j=null,J=null,I=null,N=null,y=null,V=null;Rn(()=>{u.value&&(n.attach(u.value),s.nativeBridge.attach(u.value)),H=n.onSlideChanged((C,D)=>{m.value=C,g.value=D}),j=n.onBlockClicked((C,D)=>{m.value=D,o.setActiveBlockId(C),i&&typeof i.handleBlockClickedFromSlide=="function"?i.handleBlockClickedFromSlide(C,D):Pi(C,i==null?void 0:i.app)}),J=n.onOpenInEditor((C,D)=>{m.value=D,o.setActiveBlockId(C),Pi(C,i==null?void 0:i.app)}),I=s.nativeBridge.onPageChanged((C,D)=>{m.value=C,g.value=D}),N=n.onOpenPeekDrawer(async C=>{const D=Mo();if(C.peekType==="siyuan"&&D.enableWebServeJump){let p=!1;if(V&&V.docId===C.target)p=!0;else if(V&&V.slides&&V.slides.some(O=>{var z;return(z=O.blocks)==null?void 0:z.some(_=>_.id===C.target)}))p=!1;else try{const O=await wn(`SELECT id, root_id, type FROM blocks WHERE id = '${C.target}' LIMIT 1`);O&&O.length>0&&(p=O[0].type==="d"||O[0].id===O[0].root_id)}catch(O){console.warn("[SlidevPreviewTab] detect block type failed:",O)}k.value="web",E.value=!0,x.value=ea(D.webServeUrl,C.target,{focus:!p}),B.value=C.title||`${p?"思源文档":"思源块"}: ${C.target.slice(0,8)}`,f.value=!0,n.freezeKeyboardNav(!0)}else{if(k.value=C.peekType,C.peekType==="siyuan")S.value=C.target,B.value=C.title||`块速览: ${C.target.slice(0,8)}`;else{const p=pa(C.target);if(p.external){P(C.target);return}E.value=!0,x.value=p.url,B.value=C.title||p.url}f.value=!0,n.freezeKeyboardNav(!0)}}),y=n.onRequestToggleFullscreen(()=>{rt()}),typeof document<"u"&&document.addEventListener("fullscreenchange",ct)}),Ts(()=>{typeof document<"u"&&document.removeEventListener("fullscreenchange",ct),N&&N(),y&&y(),H&&H(),j&&j(),J&&J(),I&&I(),n.detach(),o.destroy(),s.destroy()});async function X(){if(l.value==="web-sandbox"){if(!V){ft.showMessage("请先在主编辑区打开演示文档");return}ft.showMessage("正在探测本地 Node 环境并编排 Slidev Pro 进程...");const C=await s.startProMode(V,Qo);if(!C.success){ft.showMessage(`无法启动官方 Pro 模式：${C.error}`);return}l.value="pro-cli",r.value=C.port||3030,F.value=C.url,u.value&&s.nativeBridge.attach(u.value),ft.showMessage(`🟢 已成功接入官方原生 Slidev 服务 (端口: ${r.value})`)}else s.stopProMode(),l.value="web-sandbox",F.value="/plugins/siyuan-slidev/slidev-client/index.html",u.value&&n.attach(u.value),ft.showMessage("已切回内置高保真沙箱")}function R(){A.value=!A.value,A.value?w.value=(V==null?void 0:V.docId)||"":(w.value="",Y())}let U=0;function W(C){if(f.value||Math.abs(C.deltaY)<Math.abs(C.deltaX)||Math.abs(C.deltaY)<15)return;const D=Date.now();D-U<280||(U=D,C.deltaY>0?T():tt())}function tt(){if(m.value>1){const C=m.value-1;m.value=C,l.value==="pro-cli"?s.nativeBridge.navigateToPage(C):n.navigatePage(C)}}function T(){if(m.value<g.value){const C=m.value+1;m.value=C,l.value==="pro-cli"?s.nativeBridge.navigateToPage(C):n.navigatePage(C)}}function M(C){m.value=C,l.value==="pro-cli"?s.nativeBridge.navigateToPage(C):n.navigatePage(C)}function Y(){i&&typeof i.compileCurrentDocument=="function"?i.compileCurrentDocument():i!=null&&i.eventBus&&typeof i.eventBus.emit=="function"&&i.eventBus.emit("slidev:request-compile")}function Z(){f.value=!1,n.freezeKeyboardNav(!1)}function Q(){Z()}function P(C){var z,_;const D=/^file:/i.test(C),p=D||/^[a-zA-Z]:[\\/]/.test(C),O=_e("electron");if(p&&typeof((z=O==null?void 0:O.shell)==null?void 0:z.openPath)=="function"){O.shell.openPath(D?fa(C):C),ft.showMessage("本地文件不在思源工作区内，已交由系统默认浏览器打开");return}typeof((_=O==null?void 0:O.shell)==null?void 0:_.openExternal)=="function"?O.shell.openExternal(C).catch(()=>{typeof window<"u"&&window.open(C,"_blank")}):typeof window<"u"&&window.open(C,"_blank"),ft.showMessage("该地址无法在速览抽屉内加载，已交由系统默认浏览器打开")}function ct(){typeof document<"u"&&(c.value=!!document.fullscreenElement,n.postMessage("FULLSCREEN_CHANGED",{isFullscreen:c.value}))}function rt(){const C=a.value||u.value;C&&(document.fullscreenElement?document.exitFullscreen().then(()=>{n.postMessage("FULLSCREEN_CHANGED",{isFullscreen:!1})}).catch(()=>{}):C.requestFullscreen().then(()=>{n.postMessage("FULLSCREEN_CHANGED",{isFullscreen:!0})}).catch(()=>{}))}function st(){window.open("/plugins/siyuan-slidev/slidev-client/presenter.html","SlidevPresenter","width=1200,height=800")}function gt(){if(!V){ft.showMessage("请先在主编辑区打开幻灯片文档");return}const C=va(V);ba("presentation.html",C)&&ft.showMessage("已开始下载单文件离线 HTML 演示包")}function mt(){if(!V){ft.showMessage("请先在主编辑区打开幻灯片文档");return}ya(V)&&ft.showMessage("已唤起打印视窗，请在打印选项中选择「另存为 PDF」")}return e({updateDocument(C,D){A.value&&w.value&&D&&D!==w.value||(V=C,A.value&&!w.value&&(w.value=C.docId),d.value=C.slides,g.value=C.slides.length,o.setDocId(C.docId),o.updateSlidesIndex(C.slides),l.value==="pro-cli"?s.scaffolder.scaffold(C,Qo).catch(()=>{}):n.updateSlides(C.slides,C.config,C.fullMarkdown,C.customThemeCss))},navigateToBlock(C){o.onCursorFocusBlock(C)},isPinned:A,pinnedDocId:w,engineMode:l,toggleEngineMode:X}),(C,D)=>(nt(),ot("div",ym,[h("div",km,[D[4]||(D[4]=h("div",{class:"spm-slidev-tab__title"},[h("svg",{class:"spm-slidev-tab__icon","aria-hidden":"true"},[h("use",{"xlink:href":"#iconSlidev"})]),h("span",null,"Slidev 演示预览")],-1)),h("div",wm,[h("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s",disabled:m.value<=1,"aria-label":"上一页",onClick:tt},[dt(ut,{name:"chevron-left"})],8,xm),h("span",Sm,_t(m.value)+" / "+_t(g.value||1),1),h("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s",disabled:m.value>=g.value,"aria-label":"下一页",onClick:T},[dt(ut,{name:"chevron-right"})],8,_m),h("button",{class:At(["spm-icon-btn b3-tooltips b3-tooltips__s",{"is-primary":A.value}]),"aria-label":A.value?"已锁定当前文档（点击解除）："+w.value:"点击锁定当前文档（不随主编辑区切换）",onClick:R},[dt(ut,{name:"pin"}),h("span",null,_t(A.value?"已锁定":"跟随"),1)],10,Cm),h("button",{class:At(["spm-icon-btn b3-tooltips b3-tooltips__s",{"is-primary":l.value==="pro-cli"}]),"aria-label":l.value==="pro-cli"?"当前：官方原生 Pro 模式 (localhost:"+r.value+")，点击切回沙箱":"当前：内置高保真沙箱，点击切换官方原生 Pro 模式",onClick:X},[dt(ut,{name:"rocket"}),h("span",null,_t(l.value==="pro-cli"?"Pro ("+r.value+")":"沙箱"),1)],10,$m),D[3]||(D[3]=h("span",{class:"spm-toolbar-divider"},null,-1)),h("button",{class:At(["spm-icon-btn b3-tooltips b3-tooltips__s",{"is-primary":b.value}]),"aria-label":"切换幻灯片大纲抽屉",onClick:D[0]||(D[0]=p=>b.value=!b.value)},[dt(ut,{name:"outline"})],2),h("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"双屏演讲者视图 (Presenter Mode ⌥M)",onClick:st},[dt(ut,{name:"presenter"})]),h("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"导出单文件 HTML 演示包",onClick:gt},[dt(ut,{name:"export-html"})]),h("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"导出 16:9 PDF 演示讲义",onClick:mt},[dt(ut,{name:"export-pdf"})]),h("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"重新编译并刷新",onClick:Y},[dt(ut,{name:"refresh"})]),h("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"全屏放映",onClick:rt},[dt(ut,{name:"fullscreen"})])])]),h("div",{ref_key:"fullscreenContainerRef",ref:a,class:"spm-slidev-tab__viewport spm-slidev-fullscreen-container",onWheel:W},[h("iframe",{ref_key:"sandboxIframeRef",ref:u,class:"spm-slidev-tab__iframe",src:F.value,frameborder:"0",allow:"fullscreen; autoplay"},null,8,Im),dt(xh,{visible:f.value,"onUpdate:visible":D[1]||(D[1]=p=>f.value=p),"is-maximized":v.value,"onUpdate:isMaximized":D[2]||(D[2]=p=>v.value=p),title:B.value,onClose:Z},{default:xl(()=>[k.value==="siyuan"&&S.value?(nt(),Le(Eh,{key:0,"block-id":S.value,title:B.value,plugin:bt(i),onExternalJump:Q},null,8,["block-id","title","plugin"])):Ot("",!0),E.value?Te((nt(),Le(em,{key:1,visible:f.value&&k.value==="web",url:x.value,title:B.value,onExternalJump:Q},null,8,["visible","url","title"])),[[Xl,k.value==="web"]]):Ot("",!0)]),_:1},8,["visible","is-maximized","title"])],544),b.value&&d.value.length>0?(nt(),Le(ph,{key:0,slides:d.value,"current-active-page":m.value,onNavigate:M,onRefresh:Y},null,8,["slides","current-active-page"])):Ot("",!0)]))}}),Bm=ze(Am,[["__scopeId","data-v-dd3f9635"]]),Tm={class:"spm-section spm-section--page"},Em={class:"spm-section-header"},Mm={key:0,class:"spm-card-control",style:{"border-left":"3px solid var(--b3-theme-primary)",background:"rgba(var(--b3-theme-primary-rgb, 66, 133, 244), 0.06)",padding:"8px 12px","margin-top":"6px"}},Lm={style:{display:"flex","align-items":"center","justify-content":"space-between",gap:"8px"}},Dm={style:{"font-size":"11px",display:"flex","align-items":"center",gap:"6px",flex:"1"}},Pm={key:1,class:"spm-card-control"},Om={class:"spm-control-header"},Rm={class:"spm-control-title-group"},zm={class:"spm-control-title"},Nm={class:"spm-quick-chips"},Fm=["onClick"],Hm={style:{display:"flex",gap:"6px","align-items":"center","margin-top":"6px"}},jm=["value"],Um=["aria-label"],Wm={key:1,class:"spm-icon-btn b3-tooltips b3-tooltips__w",disabled:"",style:{opacity:"0.45",cursor:"not-allowed",padding:"0 8px",height:"26px","font-size":"11px","white-space":"nowrap","flex-shrink":"0"},"aria-label":"当前页未检测到调整过列宽的横向超级块"},Vm={key:0,style:{"margin-top":"6px","font-size":"11px",opacity:"0.85",display:"flex","align-items":"center",gap:"4px"}},qm={style:{background:"rgba(125, 125, 125, 0.15)",padding:"1px 4px","border-radius":"3px","font-weight":"bold"}},Km={key:1,style:{"margin-top":"6px","font-size":"11px",opacity:"0.6",display:"flex","align-items":"center",gap:"4px"}},Gm={class:"spm-card-control"},Zm={class:"spm-control-header"},Ym={class:"spm-control-title-group"},Jm={class:"spm-control-title"},Xm={class:"spm-segmented-group"},Qm={class:"spm-card-control"},tg={class:"spm-control-header"},eg={class:"spm-control-title-group"},ig={class:"spm-control-title"},ng={class:"spm-quick-chips"},og=["onClick"],sg=["value"],rg={key:2,class:"spm-card-control"},lg={class:"spm-control-header"},ag={class:"spm-control-title-group"},cg={class:"spm-control-title"},dg={class:"spm-quick-chips"},ug=["onClick"],fg=["value"],pg={class:"spm-card-control"},hg={class:"spm-control-header"},mg={class:"spm-control-title-group"},gg={class:"spm-control-title"},vg={key:0,class:"spm-note-status-box"},bg=["title"],yg={class:"spm-action-grid",style:{"margin-top":"6px"}},kg={key:1,class:"spm-note-empty-box"},wg={class:"spm-batch-actions-box",style:{"margin-top":"8px","border-top":"1px dashed var(--b3-border-color, #e2e8f0)","padding-top":"8px"}},xg={class:"spm-action-grid"},Sg=["disabled"],_g=["disabled"],Cg={class:"spm-card-control"},$g={class:"spm-action-grid"},Ig=Ce({__name:"PageInspectorSection",props:{pageLayout:{},pageTransition:{},pageBackground:{},pageSpacing:{},pageImage:{},pageNotes:{},pageIndex:{},pageLayoutRatio:{},detectedSbRatio:{},detectedSbInfo:{},isBatchProcessing:{type:Boolean}},emits:["update:pageLayout","update:pageTransition","update:pageBackground","update:pageSpacing","update:pageImage","update:pageLayoutRatio","applySuperBlockLayout","resetSuperblockRatio","addNoteBlock","locateNoteBlock","generateNotes","batchAppendNotes","batchDeleteNotes","insertDividerAfter","deleteDivider"],setup(t,{emit:e}){const i=t,n=e,o=St(()=>["two-cols","cols-header","two-cols-header","three-cols-header","image-left","image-right"].includes(i.pageLayout)),s=St(()=>{var b,f;if(i.pageLayout==="two-cols-header"||i.pageLayout==="two-cols"||i.pageLayout==="image-left"||i.pageLayout==="image-right")return 2;if(i.pageLayout==="three-cols-header")return 3;const g=(i.pageLayoutRatio||"").trim();if(g.includes(":")){const v=g.split(":").filter(Boolean).length;if(v>=2&&v<=6)return v}const d=(i.detectedSbRatio||"").trim();if(d.includes(":")){const v=d.split(":").filter(Boolean).length;if(v>=2&&v<=6)return v}if((b=i.detectedSbInfo)!=null&&b.colCount&&i.detectedSbInfo.colCount>=2)return Math.min(i.detectedSbInfo.colCount,6);if((f=i.detectedSbInfo)!=null&&f.slots&&Array.isArray(i.detectedSbInfo.slots)){const v=i.detectedSbInfo.slots.length;if(v>=2&&v<=6)return v}return 2}),l=St(()=>{const g=s.value;return g===3?[{label:"默认 1:1:1",value:""},{label:"1:2:1 (主中)",value:"1:2:1"},{label:"2:1:1 (主左)",value:"2:1:1"},{label:"1:1:2 (主右)",value:"1:1:2"},{label:"1:3:1",value:"1:3:1"}]:g===4?[{label:"默认 1:1:1:1",value:""},{label:"1:2:2:1",value:"1:2:2:1"},{label:"2:1:1:2",value:"2:1:1:2"}]:g===5?[{label:"默认 1:1:1:1:1",value:""}]:g===6?[{label:"默认 1:1:1:1:1:1",value:""}]:[{label:"默认 1:1",value:""},{label:"1:2",value:"1:2"},{label:"2:1",value:"2:1"},{label:"3:7",value:"3:7"},{label:"7:3",value:"7:3"},{label:"4:6",value:"4:6"},{label:"6:4",value:"6:4"}]}),r=St(()=>i.pageLayoutRatio||"");function a(){const g=s.value||2,d=Array(g).fill("1").join(":");n("update:pageLayoutRatio",d),n("resetSuperblockRatio")}const c=St(()=>{if(!i.pageNotes)return"";const g=i.pageNotes.replace(/[\r\n]+/g," ").trim();return g.length>50?g.slice(0,50)+"...":g}),u=[{label:"默认",value:""},{label:"暗黑 #1e1e24",value:"#1e1e24"},{label:"极夜 #0f172a",value:"#0f172a"},{label:"极简白 #ffffff",value:"#ffffff"}],m=[{label:"默认封面",value:"https://cover.sli.dev"},{label:"清空配图",value:""}];return(g,d)=>(nt(),ot("div",Tm,[h("div",Em,[h("span",null,"幻灯片页面设置"+_t(t.pageIndex?` (第 ${t.pageIndex} 页)`:""),1)]),dt(ua,{"model-value":t.pageLayout,onChange:d[0]||(d[0]=b=>g.$emit("update:pageLayout",b))},null,8,["model-value"]),!o.value&&t.pageLayout!=="clover"&&t.detectedSbRatio?(nt(),ot("div",Mm,[h("div",Lm,[h("div",Dm,[dt(ut,{name:"sparkles"}),h("span",null,[d[22]||(d[22]=Ae("检测到本页横向超级块列宽比例：",-1)),h("b",null,_t(t.detectedSbRatio),1)])]),h("button",{class:"spm-btn-action b3-tooltips b3-tooltips__w","aria-label":"一键将本页版式设为分栏并应用超级块列宽",style:{padding:"2px 8px",height:"26px","font-size":"11px","flex-shrink":"0",background:"var(--b3-theme-primary)",color:"#fff",display:"inline-flex","align-items":"center",gap:"4px"},onClick:d[1]||(d[1]=b=>g.$emit("applySuperBlockLayout",t.detectedSbInfo||{recommendedLayout:"two-cols",ratio:t.detectedSbRatio}))},[dt(ut,{name:"columns"}),d[23]||(d[23]=h("span",null,"设为分栏",-1))])])])):Ot("",!0),o.value?(nt(),ot("div",Pm,[h("div",Om,[h("div",Rm,[h("div",zm,[dt(ut,{name:"ratio"}),d[24]||(d[24]=h("span",null,"分栏比例 (Ratio)",-1))]),d[25]||(d[25]=h("span",{class:"spm-control-desc"},"设置各列横向空间占比，默认平均分配",-1))])]),h("div",Nm,[(nt(!0),ot(Kt,null,xe(l.value,b=>(nt(),ot("button",{key:b.value,class:At(["spm-chip",{active:r.value===b.value}]),onClick:f=>g.$emit("update:pageLayoutRatio",b.value)},_t(b.label),11,Fm))),128))]),h("div",Hm,[h("input",{value:t.pageLayoutRatio||"",class:"spm-input",style:{flex:"1","min-width":"0"},placeholder:"自定义比例（如 1:2 或 30:70，留空为默认）",onInput:d[2]||(d[2]=b=>g.$emit("update:pageLayoutRatio",b.target.value)),onChange:d[3]||(d[3]=b=>g.$emit("update:pageLayoutRatio",b.target.value))},null,40,jm),t.detectedSbRatio?(nt(),ot("button",{key:0,class:"spm-icon-btn b3-tooltips b3-tooltips__w","aria-label":`从当前页思源超级块读取实际宽度比例 (${t.detectedSbRatio}) 并应用`,style:{padding:"0 8px",height:"26px","font-size":"11px","white-space":"nowrap","flex-shrink":"0"},onClick:d[4]||(d[4]=b=>g.$emit("update:pageLayoutRatio",t.detectedSbRatio))},[dt(ut,{name:"sparkles"}),d[26]||(d[26]=h("span",null,"读取",-1))],8,Um)):(nt(),ot("button",Wm,[dt(ut,{name:"sparkles"}),d[27]||(d[27]=h("span",null,"读取",-1))])),h("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__w","aria-label":"重置渲染比例为平均分布，并立即重置文档中超级块内容分布比例",style:{padding:"0 8px",height:"26px","font-size":"11px","white-space":"nowrap","flex-shrink":"0"},onClick:a},[dt(ut,{name:"reset"}),d[28]||(d[28]=h("span",null,"重置",-1))])]),t.detectedSbRatio?(nt(),ot("div",Vm,[dt(ut,{name:"ratio"}),d[29]||(d[29]=h("span",null,"检测到思源超级块宽度：",-1)),h("code",qm,_t(t.detectedSbRatio),1)])):(nt(),ot("div",Km,[dt(ut,{name:"ratio"}),d[30]||(d[30]=h("span",null,"未检测到调宽超级块（默认各列平均分配）",-1))]))])):Ot("",!0),dt(Hs,{"model-value":t.pageTransition,onChange:d[5]||(d[5]=b=>g.$emit("update:pageTransition",b))},null,8,["model-value"]),h("div",Gm,[h("div",Zm,[h("div",Ym,[h("div",Jm,[dt(ut,{name:"ratio"}),d[31]||(d[31]=h("span",null,"页面间距 (Spacing)",-1))]),d[32]||(d[32]=h("span",{class:"spm-control-desc"},"覆盖本页内边距与顶部标题间距",-1))])]),h("div",Xm,[h("button",{class:At(["spm-segmented-item",{active:!t.pageSpacing||t.pageSpacing==="inherit"}]),onClick:d[6]||(d[6]=b=>g.$emit("update:pageSpacing","inherit"))}," 继承全局 ",2),h("button",{class:At(["spm-segmented-item",{active:t.pageSpacing==="compact"}]),onClick:d[7]||(d[7]=b=>g.$emit("update:pageSpacing","compact"))}," 紧凑 ",2),h("button",{class:At(["spm-segmented-item",{active:t.pageSpacing==="normal"}]),onClick:d[8]||(d[8]=b=>g.$emit("update:pageSpacing","normal"))}," 标准 ",2),h("button",{class:At(["spm-segmented-item",{active:t.pageSpacing==="loose"}]),onClick:d[9]||(d[9]=b=>g.$emit("update:pageSpacing","loose"))}," 宽松 ",2)])]),h("div",Qm,[h("div",tg,[h("div",eg,[h("div",ig,[dt(ut,{name:"palette"}),d[33]||(d[33]=h("span",null,"页面背景 (Background)",-1))]),d[34]||(d[34]=h("span",{class:"spm-control-desc"},"设置当前页特定底色或壁纸",-1))])]),h("div",ng,[(nt(),ot(Kt,null,xe(u,b=>h("button",{key:b.value,class:At(["spm-chip",{active:t.pageBackground===b.value}]),onClick:f=>g.$emit("update:pageBackground",b.value)},_t(b.label),11,og)),64))]),h("input",{value:t.pageBackground,class:"spm-input",placeholder:"自定义颜色代码或资源路径",onInput:d[10]||(d[10]=b=>g.$emit("update:pageBackground",b.target.value)),onChange:d[11]||(d[11]=b=>g.$emit("update:pageBackground",b.target.value))},null,40,sg)]),t.pageLayout==="image-right"||t.pageLayout==="image-left"||t.pageImage?(nt(),ot("div",rg,[h("div",lg,[h("div",ag,[h("div",cg,[dt(ut,{name:"image"}),d[35]||(d[35]=h("span",null,"页面图片 (Image)",-1))]),d[36]||(d[36]=h("span",{class:"spm-control-desc"},"图文分栏或页面专属配图 URL / 资源路径",-1))])]),h("div",dg,[(nt(),ot(Kt,null,xe(m,b=>h("button",{key:b.value,class:At(["spm-chip",{active:t.pageImage===b.value}]),onClick:f=>g.$emit("update:pageImage",b.value)},_t(b.label),11,ug)),64))]),h("input",{value:t.pageImage,class:"spm-input",placeholder:"网络图片 URL (如 https://cover.sli.dev) 或 assets/...",onInput:d[12]||(d[12]=b=>g.$emit("update:pageImage",b.target.value)),onChange:d[13]||(d[13]=b=>g.$emit("update:pageImage",b.target.value))},null,40,fg)])):Ot("",!0),h("div",pg,[h("div",hg,[h("div",mg,[h("div",gg,[dt(ut,{name:"presenter"}),d[37]||(d[37]=h("span",null,"演讲者提词 (Notes)",-1))]),d[38]||(d[38]=h("span",{class:"spm-control-desc"},"正文备注块驱动 · 仅演讲者视图可见",-1))]),h("button",{class:"spm-btn-text b3-tooltips b3-tooltips__w","aria-label":"AI 自动生成本页讲稿提示块",onClick:d[14]||(d[14]=b=>g.$emit("generateNotes"))},[dt(ut,{name:"sparkles"}),d[39]||(d[39]=h("span",null,"AI 讲稿",-1))])]),t.pageNotes?(nt(),ot("div",vg,[d[42]||(d[42]=h("div",{class:"spm-note-status-badge"},[h("span",{class:"spm-badge-dot"}),h("span",null,"已配置正文讲稿")],-1)),h("div",{class:"spm-note-preview-text",title:t.pageNotes},_t(c.value),9,bg),h("div",yg,[h("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"在正文编辑区定位并高亮此讲稿备注块",onClick:d[15]||(d[15]=b=>g.$emit("locateNoteBlock"))},[dt(ut,{name:"search"}),d[40]||(d[40]=h("span",null,"定位讲稿块",-1))]),h("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"在本页末尾追加新的讲稿提示块",onClick:d[16]||(d[16]=b=>g.$emit("addNoteBlock"))},[dt(ut,{name:"insert-below"}),d[41]||(d[41]=h("span",null,"追加讲稿块",-1))])])])):(nt(),ot("div",kg,[d[44]||(d[44]=h("div",{class:"spm-note-empty-hint"},"本页暂无讲稿备注块",-1)),h("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s",style:{width:"100%","margin-top":"6px"},"aria-label":"在当前页末尾插入默认演讲备注提示块",onClick:d[17]||(d[17]=b=>g.$emit("addNoteBlock"))},[dt(ut,{name:"insert-below"}),d[43]||(d[43]=h("span",null,"添加讲稿备注块",-1))])])),h("div",wg,[h("div",xg,[h("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s",disabled:t.isBatchProcessing,style:In(t.isBatchProcessing?"opacity: 0.5; cursor: not-allowed;":""),"aria-label":"在所有尚未配置讲稿的页面末尾批量追加讲稿提示块",onClick:d[18]||(d[18]=b=>g.$emit("batchAppendNotes"))},[dt(ut,{name:"insert-below"}),d[45]||(d[45]=h("span",null,"全部追加",-1))],12,Sg),h("button",{class:"spm-btn-action spm-btn-danger b3-tooltips b3-tooltips__s",disabled:t.isBatchProcessing,style:In(t.isBatchProcessing?"opacity: 0.5; cursor: not-allowed;":""),"aria-label":"批量物理删除正文中的全部讲稿备注块（涉及全部页）",onClick:d[19]||(d[19]=b=>g.$emit("batchDeleteNotes"))},[dt(ut,{name:"trash"}),d[46]||(d[46]=h("span",null,"全部删除",-1))],12,_g)])])]),h("div",Cg,[d[49]||(d[49]=h("div",{class:"spm-control-header"},[h("div",{class:"spm-control-title-group"},[h("span",{class:"spm-control-title"},"分页快捷操作")])],-1)),h("div",$g,[h("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"在此分页符之后插入新的空白分页",onClick:d[20]||(d[20]=b=>g.$emit("insertDividerAfter"))},[dt(ut,{name:"insert-below"}),d[47]||(d[47]=h("span",null,"插入新页",-1))]),h("button",{class:"spm-btn-action spm-btn-danger b3-tooltips b3-tooltips__s","aria-label":"彻底删除当前分页符（合并前后页面）",onClick:d[21]||(d[21]=b=>g.$emit("deleteDivider"))},[dt(ut,{name:"trash"}),d[48]||(d[48]=h("span",null,"删除此页",-1))])])])]))}}),Ag=ze(Ig,[["__scopeId","data-v-9c927c7c"]]),Bg={class:"spm-section spm-section--block"},Tg={key:0,class:"spm-card-control",style:{"border-left":"3px solid var(--b3-theme-primary)"}},Eg={class:"spm-control-header"},Mg={class:"spm-control-title-group"},Lg={class:"spm-control-title"},Dg={style:{background:"var(--b3-theme-surface)",border:"1px solid var(--b3-theme-surface-lighter)","border-radius":"6px",padding:"10px","margin-bottom":"8px"}},Pg={style:{display:"flex","align-items":"center","justify-content":"space-between","margin-bottom":"4px"}},Og={style:{"font-size":"12px","font-weight":"500",display:"flex","align-items":"center",gap:"4px"}},Rg={key:0},zg={key:1},Ng={style:{background:"rgba(var(--b3-theme-primary-rgb, 59, 130, 246), 0.16)",color:"var(--b3-theme-primary)",border:"1px solid rgba(var(--b3-theme-primary-rgb, 59, 130, 246), 0.3)",padding:"2px 6px","border-radius":"4px","font-weight":"bold","font-size":"12px"}},Fg={style:{"font-size":"11px",opacity:"0.75","line-height":"1.4"}},Hg={class:"spm-action-grid"},jg={class:"spm-card-control"},Ug={class:"spm-control-header"},Wg={class:"spm-control-title-group"},Vg={class:"spm-control-title"},qg=["aria-label"],Kg=["checked"],Gg={key:1,class:"spm-card-control"},Zg={class:"spm-control-header"},Yg={class:"spm-control-title-group"},Jg={class:"spm-control-title"},Xg={class:"spm-quick-chips"},Qg={key:2,class:"spm-card-control"},tv={class:"spm-control-header"},ev={class:"spm-control-title-group"},iv={class:"spm-control-title"},nv={class:"spm-video-settings-grid",style:{display:"grid","grid-template-columns":"1fr 1fr",gap:"8px","margin-top":"8px"}},ov={class:"spm-toggle-item",style:{display:"flex","align-items":"center","justify-content":"space-between",padding:"4px 6px",background:"rgba(125,125,125,0.06)","border-radius":"4px"}},sv={style:{"font-size":"11px",display:"inline-flex","align-items":"center",gap:"4px"}},rv=["aria-label"],lv=["checked"],av={class:"spm-toggle-item",style:{display:"flex","align-items":"center","justify-content":"space-between",padding:"4px 6px",background:"rgba(125,125,125,0.06)","border-radius":"4px"}},cv={style:{"font-size":"11px",display:"inline-flex","align-items":"center",gap:"4px"}},dv=["aria-label"],uv=["checked"],fv={class:"spm-toggle-item",style:{display:"flex","align-items":"center","justify-content":"space-between",padding:"4px 6px",background:"rgba(125,125,125,0.06)","border-radius":"4px"}},pv={style:{"font-size":"11px",display:"inline-flex","align-items":"center",gap:"4px"}},hv=["aria-label"],mv=["checked"],gv={class:"spm-toggle-item",style:{display:"flex","align-items":"center","justify-content":"space-between",padding:"4px 6px",background:"rgba(125,125,125,0.06)","border-radius":"4px"}},vv={style:{"font-size":"11px",display:"inline-flex","align-items":"center",gap:"4px"}},bv=["aria-label"],yv=["checked"],kv={class:"spm-card-control"},wv={class:"spm-control-header"},xv={class:"spm-control-title-group"},Sv={class:"spm-control-title"},_v=["aria-label"],Cv=["checked"],$v={key:0,class:"spm-quick-chips"},Iv=["onClick"],Av={key:1,class:"spm-inherit-tip",style:{"margin-top":"6px",padding:"4px 8px",background:"rgba(var(--b3-theme-primary-rgb, 59, 130, 246), 0.08)","border-radius":"4px","font-size":"11px",opacity:"0.85",display:"flex","align-items":"center",gap:"4px"}},Bv={class:"spm-card-control"},Tv={class:"spm-control-header"},Ev={class:"spm-control-title-group"},Mv={class:"spm-control-title"},Lv=["aria-label"],Dv=["checked"],Pv={key:0,class:"spm-quick-chips"},Ov=["onClick"],Rv={key:1,class:"spm-motion-details",style:{display:"flex","flex-direction":"column",gap:"4px","margin-top":"4px"}},zv={style:{display:"flex",gap:"8px","justify-content":"space-between","font-size":"11px",opacity:"0.8"}},Nv={style:{display:"flex",gap:"6px"}},Fv=["value"],Hv=["value"],jv={key:3,class:"spm-card-control"},Uv={class:"spm-control-header"},Wv={class:"spm-control-title-group"},Vv={class:"spm-control-title"},qv={class:"spm-control-desc"},Kv={class:"spm-segmented-group"},Gv=["onClick"],Zv={key:4,class:"spm-card-control"},Yv={class:"spm-control-header"},Jv={class:"spm-control-title-group"},Xv={class:"spm-control-title"},Qv={class:"spm-quick-chips"},t1=["onClick"],e1=["value"],i1={key:5,class:"spm-card-control"},n1={class:"spm-control-header"},o1={class:"spm-control-title-group"},s1={class:"spm-control-title"},r1={class:"spm-quick-chips"},l1=["onClick"],a1=["value"],c1={class:"spm-card-control"},d1={class:"spm-action-grid"},u1=["aria-label"],f1=Ce({__name:"BlockInspectorSection",props:{elemClick:{},elemMotion:{},elemSlot:{},elemShikiLines:{},elemMaxHeight:{},isCodeBlock:{type:Boolean},isImage:{type:Boolean},isVideo:{type:Boolean},videoAutoplay:{type:Boolean},videoLoop:{type:Boolean},videoMuted:{type:Boolean},videoControls:{type:Boolean},hasBlockAttrs:{type:Boolean},isNote:{type:Boolean},imageRole:{},currentSlideLayout:{},isSuperBlock:{type:Boolean},parentElemClick:{},parentContainerSlot:{},parentContainerId:{},detectedSbInfo:{}},emits:["toggleNote","toggleElemClick","update:elemClick","update:elemMotion","update:elemSlot","update:elemShikiLines","update:elemMaxHeight","applySuperBlockLayout","applySuperBlockRatio","insertDividerBefore","insertDividerAfter","setTwoColsContrast","clearBlockAttrs","update:imageRole","toggleVideoAutoplay","toggleVideoLoop","toggleVideoMuted","toggleVideoControls"],setup(t,{emit:e}){const i=t,n=St(()=>{const A=i.currentSlideLayout||"";return["col-1","col-2","col-3","col-4","col-5","col-6"].includes(i.elemSlot)?"cols-header":A}),o=St(()=>{const A=n.value;return["two-cols","cols-header","two-cols-header","three-cols-header"].includes(A)}),s=St(()=>{var w,F,H,j;if((w=i.detectedSbInfo)!=null&&w.colCount&&i.detectedSbInfo.colCount>=2)return Math.min(i.detectedSbInfo.colCount,6);const A=(F=i.elemSlot)==null?void 0:F.match(/^col-(\d+)$/);if(A){const J=parseInt(A[1],10);if(J>=2&&J<=6)return Math.max(J,3)}if(i.currentSlideLayout==="three-cols-header")return 3;if(i.currentSlideLayout==="two-cols-header"||i.currentSlideLayout==="two-cols")return 2;if((j=(H=i.detectedSbInfo)==null?void 0:H.ratio)!=null&&j.includes(":")){const J=i.detectedSbInfo.ratio.split(":").filter(Boolean);if(J.length>=2)return Math.min(J.length,6)}return 3}),l=St(()=>{const A=n.value;return A==="cols-header"?"多栏插槽归属 (Slot)":A==="three-cols-header"?"三栏插槽归属 (Slot)":A==="two-cols-header"?"带表头双栏插槽 (Slot)":"多栏插槽归属 (Slot)"}),r=St(()=>{const A=n.value;return A==="cols-header"?`在 cols-header 表头多栏（${s.value} 栏）中的内容块位置`:A==="three-cols-header"?"在 three-cols-header 版式中的内容块位置":A==="two-cols-header"?"在 two-cols-header 版式中的内容块位置":A==="two-cols"?"在 two-cols 双栏版式中的归属":"在当前分栏版式中的内容块位置"}),a=St(()=>{const A=n.value;if(A==="two-cols")return[{value:"",label:"默认 (左)"},{value:"right",label:"右栏"}];if(A==="two-cols-header")return[{value:"",label:"默认"},{value:"header",label:"表头"},{value:"left",label:"左栏"},{value:"right",label:"右栏"}];if(A==="three-cols-header")return[{value:"",label:"默认"},{value:"header",label:"表头"},{value:"col-1",label:"第 1 栏"},{value:"col-2",label:"第 2 栏"},{value:"col-3",label:"第 3 栏"}];const w=s.value,F=[{value:"",label:"默认"},{value:"header",label:"表头"}];for(let H=1;H<=w;H++)F.push({value:`col-${H}`,label:`第 ${H} 栏`});return F});function c(A){const w=i.elemSlot||"";return A?w===A||A==="col-1"&&w==="left"||A==="col-2"&&w==="center"||A==="col-3"&&w==="right"&&s.value===3||A==="col-2"&&w==="right"&&s.value===2||A==="left"&&w==="col-1"||A==="right"&&(w==="col-2"||w==="col-3"):!w||w==="default"}const u=e,m=[{label:"上浮 (slide-up)",value:"slide-up"},{label:"淡入 (fade-in)",value:"fade-in"},{label:"下沉 (slide-down)",value:"slide-down"},{label:"左滑 (slide-left)",value:"slide-left"},{label:"右滑 (slide-right)",value:"slide-right"},{label:"缩放 (zoom-in)",value:"zoom-in"},{label:"弹性 (bounce)",value:"bounce"}],g=St(()=>{if(!i.elemMotion||i.elemMotion.trim()===""||i.elemMotion.trim()==="none")return null;try{const A=JSON.parse(i.elemMotion);if(typeof A=="object"&&A!==null)return{preset:A.preset||A.type||"slide-up",duration:typeof A.duration=="number"?A.duration:0,delay:typeof A.delay=="number"?A.delay:0}}catch{}return{preset:i.elemMotion.trim(),duration:0,delay:0}}),d=St(()=>!!g.value),b=St(()=>{var A;return((A=g.value)==null?void 0:A.preset)||"slide-up"}),f=St(()=>{var A;return((A=g.value)==null?void 0:A.duration)||0}),v=St(()=>{var A;return((A=g.value)==null?void 0:A.delay)||0});function k(){d.value?u("update:elemMotion",""):u("update:elemMotion","slide-up")}function S(A){E(A,f.value,v.value)}function x(A){E(b.value,A,v.value)}function B(A){E(b.value,f.value,A)}function E(A,w,F){if(!A||A==="none"){u("update:elemMotion","");return}if(!w&&!F){u("update:elemMotion",A);return}const H={preset:A};w>0&&(H.duration=w),F>0&&(H.delay=F),u("update:elemMotion",JSON.stringify(H))}return(A,w)=>{var F,H,j,J,I,N;return nt(),ot("div",Bg,[w[62]||(w[62]=h("div",{class:"spm-section-header"},[h("span",null,"元素动效与排版")],-1)),t.isSuperBlock||(F=t.detectedSbInfo)!=null&&F.hasSuperBlock?(nt(),ot("div",Tg,[h("div",Eg,[h("div",Mg,[h("div",Lg,[dt(ut,{name:"ratio"}),w[24]||(w[24]=h("span",null,"超级块列宽与布局",-1))]),w[25]||(w[25]=h("span",{class:"spm-control-desc"},"读取思源超级块列宽并一键同步到幻灯片分栏",-1))])]),h("div",Dg,[h("div",Pg,[h("div",Og,[dt(ut,{name:"ratio"}),(H=t.detectedSbInfo)!=null&&H.isCustomWidth?(nt(),ot("span",Rg,"已识别自定义列宽比例")):(nt(),ot("span",zg,"识别到 "+_t(((j=t.detectedSbInfo)==null?void 0:j.colCount)||2)+" 列超级块分栏",1))]),h("code",Ng,_t(((J=t.detectedSbInfo)==null?void 0:J.ratio)||"1:1"),1)]),h("div",Fg,_t((I=t.detectedSbInfo)!=null&&I.isCustomWidth?"检测到已调节子块宽度，可一键应用为当前页分栏比例。":"当前超级块子列为思源默认均宽，可在思源中拖动调节或直接应用。"),1)]),h("div",Hg,[h("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"一键将当前页版式切换为对应双栏/三栏，并写入此列宽比例",style:{background:"rgba(var(--b3-theme-primary-rgb, 59, 130, 246), 0.16)",color:"var(--b3-theme-primary)","font-weight":"500",border:"1px solid rgba(var(--b3-theme-primary-rgb, 59, 130, 246), 0.3)"},onClick:w[0]||(w[0]=y=>A.$emit("applySuperBlockLayout",t.detectedSbInfo))},[dt(ut,{name:"sparkles"}),w[26]||(w[26]=h("span",null,"应用版式与比例",-1))]),h("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"仅将提取的比值写入当前页的分栏比例属性",onClick:w[1]||(w[1]=y=>{var V;return A.$emit("applySuperBlockRatio",((V=t.detectedSbInfo)==null?void 0:V.ratio)||"1:1")})},[dt(ut,{name:"check"}),h("span",null,"应用比例 ("+_t(((N=t.detectedSbInfo)==null?void 0:N.ratio)||"1:1")+")",1)])])])):Ot("",!0),h("div",jg,[h("div",Ug,[h("div",Wg,[h("div",Vg,[dt(ut,{name:"presenter"}),w[27]||(w[27]=h("span",null,"设为讲稿备注 (slidev-note)",-1))]),w[28]||(w[28]=h("span",{class:"spm-control-desc"},"作为当前页演讲提词，不在幻灯片中渲染",-1))]),h("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":t.isNote?"取消讲稿备注":"设为讲稿备注"},[h("input",{type:"checkbox",checked:!!t.isNote,onChange:w[2]||(w[2]=y=>A.$emit("toggleNote"))},null,40,Kg),w[29]||(w[29]=h("span",{class:"spm-switch-slider"},null,-1))],8,qg)])]),t.isImage||t.imageRole?(nt(),ot("div",Gg,[h("div",Zg,[h("div",Yg,[h("div",Jg,[dt(ut,{name:"image"}),w[30]||(w[30]=h("span",null,"图片角色与分栏 (Image & Layout)",-1))]),w[31]||(w[31]=h("span",{class:"spm-control-desc"},"设为幻灯片背景图或图文分栏配图",-1))])]),h("div",Xg,[h("button",{class:At(["spm-chip",{active:!t.imageRole}]),onClick:w[3]||(w[3]=y=>A.$emit("update:imageRole",""))}," 普通内容 ",2),h("button",{class:At(["spm-chip",{active:t.imageRole==="background"}]),onClick:w[4]||(w[4]=y=>A.$emit("update:imageRole","background"))},[dt(ut,{name:"image"}),w[32]||(w[32]=h("span",null,"背景图",-1))],2),h("button",{class:At(["spm-chip",{active:t.imageRole==="image-left"}]),onClick:w[5]||(w[5]=y=>A.$emit("update:imageRole","image-left"))},[dt(ut,{name:"image-left"}),w[33]||(w[33]=h("span",null,"图左",-1))],2),h("button",{class:At(["spm-chip",{active:t.imageRole==="image-right"}]),onClick:w[6]||(w[6]=y=>A.$emit("update:imageRole","image-right"))},[dt(ut,{name:"image-right"}),w[34]||(w[34]=h("span",null,"图右",-1))],2)])])):Ot("",!0),t.isVideo?(nt(),ot("div",Qg,[h("div",tv,[h("div",ev,[h("div",iv,[dt(ut,{name:"video"}),w[35]||(w[35]=h("span",null,"视频播放设置 (Video Playback)",-1))]),w[36]||(w[36]=h("span",{class:"spm-control-desc"},"配置播放器控制条、自动播放与循环",-1))])]),h("div",nv,[h("div",ov,[h("span",sv,[dt(ut,{name:"sliders"}),w[37]||(w[37]=Ae(" 控制条",-1))]),h("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":t.videoControls?"关闭控制条":"开启控制条"},[h("input",{type:"checkbox",checked:!!t.videoControls,onChange:w[7]||(w[7]=y=>A.$emit("toggleVideoControls"))},null,40,lv),w[38]||(w[38]=h("span",{class:"spm-switch-slider"},null,-1))],8,rv)]),h("div",av,[h("span",cv,[dt(ut,{name:"video"}),w[39]||(w[39]=Ae(" 自动播放",-1))]),h("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":t.videoAutoplay?"关闭自动播放":"开启自动播放"},[h("input",{type:"checkbox",checked:!!t.videoAutoplay,onChange:w[8]||(w[8]=y=>A.$emit("toggleVideoAutoplay"))},null,40,uv),w[40]||(w[40]=h("span",{class:"spm-switch-slider"},null,-1))],8,dv)]),h("div",fv,[h("span",pv,[dt(ut,{name:"repeat"}),w[41]||(w[41]=Ae(" 循环播放",-1))]),h("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":t.videoLoop?"关闭循环播放":"开启循环播放"},[h("input",{type:"checkbox",checked:!!t.videoLoop,onChange:w[9]||(w[9]=y=>A.$emit("toggleVideoLoop"))},null,40,mv),w[42]||(w[42]=h("span",{class:"spm-switch-slider"},null,-1))],8,hv)]),h("div",gv,[h("span",vv,[dt(ut,{name:"volume-x"}),w[43]||(w[43]=Ae(" 静音播放",-1))]),h("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":t.videoMuted?"关闭静音":"开启静音"},[h("input",{type:"checkbox",checked:!!t.videoMuted,onChange:w[10]||(w[10]=y=>A.$emit("toggleVideoMuted"))},null,40,yv),w[44]||(w[44]=h("span",{class:"spm-switch-slider"},null,-1))],8,bv)])])])):Ot("",!0),h("div",kv,[h("div",wv,[h("div",xv,[h("div",Sv,[dt(ut,{name:"step"}),w[45]||(w[45]=h("span",null,"逐步呈现 (v-click)",-1))]),w[46]||(w[46]=h("span",{class:"spm-control-desc"},"放映时按步长逐个呈现",-1))]),h("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":t.elemClick?"关闭逐步呈现":"开启逐步呈现 (+1)"},[h("input",{type:"checkbox",checked:!!t.elemClick,onChange:w[11]||(w[11]=y=>A.$emit("toggleElemClick"))},null,40,Cv),w[47]||(w[47]=h("span",{class:"spm-switch-slider"},null,-1))],8,_v)]),t.elemClick?(nt(),ot("div",$v,[(nt(),ot(Kt,null,xe(["+1","1","2","hide"],y=>h("button",{key:y,class:At(["spm-chip",{active:t.elemClick===y}]),onClick:V=>A.$emit("update:elemClick",y)},_t(y==="+1"?"顺延 (+1)":y==="hide"?"隐藏 (hide)":"第 "+y+" 步"),11,Iv)),64))])):t.parentElemClick?(nt(),ot("div",Av,[dt(ut,{name:"check"}),w[48]||(w[48]=h("span",null,"未单独开启逐步呈现：当前跟随整栏同时出现",-1))])):Ot("",!0)]),h("div",Bv,[h("div",Tv,[h("div",Ev,[h("div",Mv,[dt(ut,{name:"motion"}),w[49]||(w[49]=h("span",null,"入场微动效 (v-motion)",-1))]),w[50]||(w[50]=h("span",{class:"spm-control-desc"},"为当前块添加平滑位移与渐入动画",-1))]),h("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":d.value?"关闭微动效":"开启微动效 (slide-up)"},[h("input",{type:"checkbox",checked:d.value,onChange:k},null,40,Dv),w[51]||(w[51]=h("span",{class:"spm-switch-slider"},null,-1))],8,Lv)]),d.value?(nt(),ot("div",Pv,[(nt(),ot(Kt,null,xe(m,y=>h("button",{key:y.value,class:At(["spm-chip",{active:b.value===y.value}]),onClick:V=>S(y.value)},_t(y.label),11,Ov)),64))])):Ot("",!0),d.value?(nt(),ot("div",Rv,[h("div",zv,[h("span",null,"时长: "+_t(f.value?f.value+"ms":"默认 (450ms)"),1),h("span",null,"延迟: "+_t(v.value?v.value+"ms":"0ms"),1)]),h("div",Nv,[h("select",{class:"spm-select",style:{flex:"1"},value:f.value,onChange:w[12]||(w[12]=y=>x(Number(y.target.value)))},[...w[52]||(w[52]=[h("option",{value:0},"默认耗时",-1),h("option",{value:200},"极速 (200ms)",-1),h("option",{value:350},"较快 (350ms)",-1),h("option",{value:500},"平滑 (500ms)",-1),h("option",{value:800},"缓慢 (800ms)",-1)])],40,Fv),h("select",{class:"spm-select",style:{flex:"1"},value:v.value,onChange:w[13]||(w[13]=y=>B(Number(y.target.value)))},[...w[53]||(w[53]=[h("option",{value:0},"无延迟",-1),h("option",{value:150},"延迟 150ms",-1),h("option",{value:300},"延迟 300ms",-1),h("option",{value:500},"延迟 500ms",-1)])],40,Hv)])])):Ot("",!0)]),o.value||t.elemSlot?(nt(),ot("div",jv,[h("div",Uv,[h("div",Wv,[h("div",Vv,[dt(ut,{name:"columns"}),h("span",null,_t(l.value),1)]),h("span",qv,_t(r.value),1)])]),h("div",Kv,[(nt(!0),ot(Kt,null,xe(a.value,y=>(nt(),ot("button",{key:y.value,class:At(["spm-segmented-item",{active:c(y.value)}]),onClick:V=>A.$emit("update:elemSlot",y.value)},_t(y.label),11,Gv))),128))])])):Ot("",!0),t.isCodeBlock?(nt(),ot("div",Zv,[h("div",Yv,[h("div",Jv,[h("div",Xv,[dt(ut,{name:"code"}),w[54]||(w[54]=h("span",null,"代码逐行聚光 (Shiki)",-1))]),w[55]||(w[55]=h("span",{class:"spm-control-desc"},"翻页时动态聚光高亮特定行",-1))])]),h("div",Qv,[(nt(),ot(Kt,null,xe(["1-3","all","1|2|3","2-5"],y=>h("button",{key:y,class:At(["spm-chip",{active:t.elemShikiLines===y}]),onClick:V=>A.$emit("update:elemShikiLines",y)},_t(y),11,t1)),64)),t.elemShikiLines?(nt(),ot("button",{key:0,class:"spm-chip spm-chip-clear",onClick:w[14]||(w[14]=y=>A.$emit("update:elemShikiLines",""))}," 清空 ")):Ot("",!0)]),h("input",{value:t.elemShikiLines,class:"spm-input",placeholder:"自定义高亮区间，如 1-3|5|all",onInput:w[15]||(w[15]=y=>A.$emit("update:elemShikiLines",y.target.value)),onChange:w[16]||(w[16]=y=>A.$emit("update:elemShikiLines",y.target.value))},null,40,e1)])):Ot("",!0),t.isCodeBlock?(nt(),ot("div",i1,[h("div",n1,[h("div",o1,[h("div",s1,[dt(ut,{name:"code"}),w[56]||(w[56]=h("span",null,"代码块限高 (Max Height)",-1))]),w[57]||(w[57]=h("span",{class:"spm-control-desc"},"超出限高自动竖向滚动，弱提示滚动条",-1))])]),h("div",r1,[(nt(),ot(Kt,null,xe(["240px","320px","400px","50vh"],y=>h("button",{key:y,class:At(["spm-chip",{active:t.elemMaxHeight===y}]),onClick:V=>A.$emit("update:elemMaxHeight",y)},_t(y),11,l1)),64)),t.elemMaxHeight?(nt(),ot("button",{key:0,class:"spm-chip spm-chip-clear",onClick:w[17]||(w[17]=y=>A.$emit("update:elemMaxHeight",""))}," 自适应 ")):Ot("",!0)]),h("input",{value:t.elemMaxHeight,class:"spm-input",placeholder:"自适应高度，或输入 350px、50vh",onInput:w[18]||(w[18]=y=>A.$emit("update:elemMaxHeight",y.target.value)),onChange:w[19]||(w[19]=y=>A.$emit("update:elemMaxHeight",y.target.value))},null,40,a1)])):Ot("",!0),h("div",c1,[w[61]||(w[61]=h("div",{class:"spm-control-header"},[h("div",{class:"spm-control-title-group"},[h("span",{class:"spm-control-title"},"快捷操作")])],-1)),h("div",d1,[h("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"在当前块上方插入幻灯片分页线 (---)",onClick:w[20]||(w[20]=y=>A.$emit("insertDividerBefore"))},[dt(ut,{name:"insert-above"}),w[58]||(w[58]=h("span",null,"上方分页",-1))]),h("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"在当前块下方插入幻灯片分页线 (---)",onClick:w[21]||(w[21]=y=>A.$emit("insertDividerAfter"))},[dt(ut,{name:"insert-below"}),w[59]||(w[59]=h("span",null,"下方分页",-1))]),h("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":n.value==="three-cols-header"?"将当前块属性设为三栏第1栏归属 (slot: col-1)":"将当前块属性设为双栏左侧归属 (slot: left)",onClick:w[22]||(w[22]=y=>A.$emit("setTwoColsContrast"))},[dt(ut,{name:"columns"}),h("span",null,_t(n.value==="three-cols-header"?"设为第1栏":"设为双栏"),1)],8,u1),t.hasBlockAttrs?(nt(),ot("button",{key:0,class:"spm-btn-action spm-btn-danger b3-tooltips b3-tooltips__s","aria-label":"一键移除本块所有 custom-slidev 属性",onClick:w[23]||(w[23]=y=>A.$emit("clearBlockAttrs"))},[dt(ut,{name:"broom"}),w[60]||(w[60]=h("span",null,"清除属性",-1))])):Ot("",!0)])])])}}}),p1={class:"spm-section spm-section--doc"},h1={class:"spm-card-control"},m1={class:"spm-control-header"},g1={class:"spm-control-title-group"},v1={class:"spm-control-title"},b1={class:"spm-segmented-group"},y1=["aria-label","onClick"],k1={class:"spm-card-control"},w1={class:"spm-control-header"},x1={class:"spm-control-title-group"},S1={class:"spm-control-title"},_1={class:"spm-segmented-group"},C1={class:"spm-card-control"},$1={class:"spm-control-header"},I1={class:"spm-control-title-group"},A1={class:"spm-control-title"},B1={class:"spm-segmented-group"},T1={class:"spm-card-control"},E1={class:"spm-control-header"},M1={class:"spm-control-title-group"},L1={class:"spm-control-title"},D1={class:"spm-card-control"},P1={class:"spm-control-header"},O1={class:"spm-control-title-group"},R1={class:"spm-control-title"},z1=["aria-label"],N1=["checked"],F1={key:0,class:"spm-control-body",style:{"margin-top":"8px"}},H1=["value"],j1={class:"spm-card-control"},U1={class:"spm-control-header"},W1={class:"spm-control-title-group"},V1={class:"spm-control-title"},q1=["aria-label"],K1=["checked"],G1={class:"spm-card-control"},Z1={class:"spm-action-grid"},Y1=Ce({__name:"DocInspectorSection",props:{docTheme:{},docAspectRatio:{},docDefaultTransition:{},docSpacing:{}},emits:["update:docTheme","update:docAspectRatio","update:docDefaultTransition","update:docSpacing","openBottomPreview","openPresenter","aiAutoSplit","exportHtml","exportPdf"],setup(t){const e=ei("plugin"),i=mi,n=[{value:"default",label:"默认 default",desc:"官方默认科技风：现代无衬线排版与清新代码语法高亮，通用汇报与技术分享首选"},{value:"seriph",label:"优雅 seriph",desc:"典雅学术衬线风：书卷学术质感、衬线字体典雅庄重，适合学术论文、人文讲座与深度阅读"},{value:"apple-basic",label:"极简 apple",desc:"苹果发布会极简风：大字号、高对比度与极致留白，适合产品发布、方案演讲与纯粹视觉呈现"}];function o(a){Ei({enableWebServeJump:a}),e&&typeof e.saveGlobalSettings=="function"&&e.saveGlobalSettings({enableWebServeJump:a})}async function s(a){var c;Ei({normalizeHeadingSizes:a}),e&&typeof e.saveGlobalSettings=="function"&&await e.saveGlobalSettings({normalizeHeadingSizes:a}),e&&typeof e.compileCurrentDocument=="function"&&e.compileCurrentDocument(e.currentDocId||((c=e.getActiveDocumentId)==null?void 0:c.call(e)))}function l(a){Ei({webServeUrl:a})}function r(a){Ei({webServeUrl:a}),e&&typeof e.saveGlobalSettings=="function"&&e.saveGlobalSettings({webServeUrl:a})}return(a,c)=>(nt(),ot("div",p1,[c[39]||(c[39]=h("div",{class:"spm-section-header"},[h("span",null,"全局演示配置")],-1)),h("div",h1,[h("div",m1,[h("div",g1,[h("div",v1,[dt(ut,{name:"palette"}),c[18]||(c[18]=h("span",null,"幻灯片主题 (Theme)",-1))]),c[19]||(c[19]=h("span",{class:"spm-control-desc"},"全局 Slidev 视觉设计范式",-1))])]),h("div",b1,[(nt(),ot(Kt,null,xe(n,u=>h("button",{key:u.value,class:At(["spm-segmented-item b3-tooltips b3-tooltips__s",{active:t.docTheme===u.value}]),"aria-label":u.desc,onClick:m=>a.$emit("update:docTheme",u.value)},_t(u.label),11,y1)),64))])]),h("div",k1,[h("div",w1,[h("div",x1,[h("div",S1,[dt(ut,{name:"ratio"}),c[20]||(c[20]=h("span",null,"画幅比例 (Aspect Ratio)",-1))]),c[21]||(c[21]=h("span",{class:"spm-control-desc"},"演讲屏幕投影宽高比",-1))])]),h("div",_1,[h("button",{class:At(["spm-segmented-item",{active:t.docAspectRatio==="16/9"}]),onClick:c[0]||(c[0]=u=>a.$emit("update:docAspectRatio","16/9"))}," 16 : 9 (宽屏) ",2),h("button",{class:At(["spm-segmented-item",{active:t.docAspectRatio==="4/3"}]),onClick:c[1]||(c[1]=u=>a.$emit("update:docAspectRatio","4/3"))}," 4 : 3 (标屏) ",2),h("button",{class:At(["spm-segmented-item",{active:t.docAspectRatio==="16/10"}]),onClick:c[2]||(c[2]=u=>a.$emit("update:docAspectRatio","16/10"))}," 16 : 10 ",2)])]),h("div",C1,[h("div",$1,[h("div",I1,[h("div",A1,[dt(ut,{name:"ratio"}),c[22]||(c[22]=h("span",null,"间距风格 (Spacing)",-1))]),c[23]||(c[23]=h("span",{class:"spm-control-desc"},"内边距与顶部标题下边距预设",-1))])]),h("div",B1,[h("button",{class:At(["spm-segmented-item b3-tooltips b3-tooltips__s",{active:(t.docSpacing||"normal")==="compact"}]),"aria-label":"紧凑排版：上下 20px / 左右 36px，释放垂直空间，适配图文分栏",onClick:c[3]||(c[3]=u=>a.$emit("update:docSpacing","compact"))}," 紧凑 (Compact) ",2),h("button",{class:At(["spm-segmented-item b3-tooltips b3-tooltips__s",{active:(t.docSpacing||"normal")==="normal"}]),"aria-label":"标准排版：上下 32px / 左右 48px，协调美观（推荐默认）",onClick:c[4]||(c[4]=u=>a.$emit("update:docSpacing","normal"))}," 标准 (Normal) ",2),h("button",{class:At(["spm-segmented-item b3-tooltips b3-tooltips__s",{active:(t.docSpacing||"normal")==="loose"}]),"aria-label":"宽松排版：上下 48px / 左右 56px，大留白适合极简大字",onClick:c[5]||(c[5]=u=>a.$emit("update:docSpacing","loose"))}," 宽松 (Loose) ",2)])]),h("div",T1,[h("div",E1,[h("div",M1,[h("div",L1,[dt(ut,{name:"transition"}),c[24]||(c[24]=h("span",null,"全局默认转场",-1))]),c[25]||(c[25]=h("span",{class:"spm-control-desc"},"页面切换过渡动效（未单设转场的页面将继承此动效）",-1))])]),dt(Hs,{"model-value":t.docDefaultTransition,"hide-header":!0,onChange:c[6]||(c[6]=u=>a.$emit("update:docDefaultTransition",u))},null,8,["model-value"])]),h("div",D1,[h("div",P1,[h("div",O1,[h("div",R1,[dt(ut,{name:"external-link"}),c[26]||(c[26]=h("span",null,"本地网络伺服预览 (Web Serve)",-1))]),c[27]||(c[27]=h("span",{class:"spm-control-desc"},"点击文档/块链接以 Webview 抽屉呈现，支持外跳",-1))]),h("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":bt(i).enableWebServeJump?"关闭本地网络伺服预览":"开启本地网络伺服预览"},[h("input",{type:"checkbox",checked:bt(i).enableWebServeJump,onChange:c[7]||(c[7]=u=>o(u.target.checked))},null,40,N1),c[28]||(c[28]=h("span",{class:"spm-switch-slider"},null,-1))],8,z1)]),bt(i).enableWebServeJump?(nt(),ot("div",F1,[h("input",{value:bt(i).webServeUrl,class:"spm-input",placeholder:"http://127.0.0.1:6806",spellcheck:"false",onKeydown:c[8]||(c[8]=Me(()=>{},["stop"])),onKeyup:c[9]||(c[9]=Me(()=>{},["stop"])),onInput:c[10]||(c[10]=u=>l(u.target.value)),onChange:c[11]||(c[11]=u=>r(u.target.value))},null,40,H1),c[29]||(c[29]=h("span",{class:"spm-control-desc",style:{display:"block","margin-top":"4px","font-size":"11px",opacity:"0.8"}}," 默认伺服地址为 http://127.0.0.1:6806。开启后点击块链接将在 Webview 抽屉中打开，点击抽屉顶部『外跳』可在外部浏览器打开 ",-1))])):Ot("",!0)]),h("div",j1,[h("div",U1,[h("div",W1,[h("div",V1,[dt(ut,{name:"type"}),c[30]||(c[30]=h("span",null,"固定特定标题大小",-1))]),c[31]||(c[31]=h("span",{class:"spm-control-desc"},"除封面外页首标题按 H2、多栏内首标题按 H3 大小展示",-1))]),h("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":bt(i).normalizeHeadingSizes?"关闭固定特定标题大小":"开启固定特定标题大小"},[h("input",{type:"checkbox",checked:bt(i).normalizeHeadingSizes,onChange:c[12]||(c[12]=u=>s(u.target.checked))},null,40,K1),c[32]||(c[32]=h("span",{class:"spm-switch-slider"},null,-1))],8,q1)])]),h("div",G1,[c[38]||(c[38]=h("div",{class:"spm-control-header"},[h("div",{class:"spm-control-title-group"},[h("span",{class:"spm-control-title"},"演示全局操作")])],-1)),h("div",Z1,[h("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"在当前文档下方开启分屏同步预览 (Alt+P)",onClick:c[13]||(c[13]=u=>a.$emit("openBottomPreview"))},[dt(ut,{name:"split-preview"}),c[33]||(c[33]=h("span",null,"分屏预览",-1))]),h("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"打开双屏演讲者控制台视窗 (Alt+M)",onClick:c[14]||(c[14]=u=>a.$emit("openPresenter"))},[dt(ut,{name:"presenter"}),c[34]||(c[34]=h("span",null,"演讲者视图",-1))]),h("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"智能分析长文本结构并给出大纲分页插入建议",onClick:c[15]||(c[15]=u=>a.$emit("aiAutoSplit"))},[dt(ut,{name:"sparkles"}),c[35]||(c[35]=h("span",null,"AI 智能分页",-1))]),h("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"打包导出离线单文件 HTML 幻灯片",onClick:c[16]||(c[16]=u=>a.$emit("exportHtml"))},[dt(ut,{name:"export-html"}),c[36]||(c[36]=h("span",null,"导出 HTML",-1))]),h("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"打印生成 16:9 高清演示 PDF 讲义",onClick:c[17]||(c[17]=u=>a.$emit("exportPdf"))},[dt(ut,{name:"export-pdf"}),c[37]||(c[37]=h("span",null,"导出 PDF",-1))])])])]))}});var Zn=typeof globalThis<"u"?globalThis:typeof window<"u"?window:typeof global<"u"?global:typeof self<"u"?self:{};function J1(t){return t&&t.__esModule&&Object.prototype.hasOwnProperty.call(t,"default")?t.default:t}function Yn(t){throw new Error('Could not dynamically require "'+t+'". Please configure the dynamicRequireTargets or/and ignoreDynamicRequires option of @rollup/plugin-commonjs appropriately for this require call to work.')}var Yo={exports:{}};/*!

JSZip v3.10.1 - A JavaScript class for generating and reading zip files
<http://stuartk.com/jszip>

(c) 2009-2016 Stuart Knightley <stuart [at] stuartk.com>
Dual licenced under the MIT license or GPLv3. See https://raw.github.com/Stuk/jszip/main/LICENSE.markdown.

JSZip uses the library pako released under the MIT license :
https://github.com/nodeca/pako/blob/main/LICENSE
*/var Lr;function X1(){return Lr||(Lr=1,(function(t,e){(function(i){t.exports=i()})(function(){return(function i(n,o,s){function l(c,u){if(!o[c]){if(!n[c]){var m=typeof Yn=="function"&&Yn;if(!u&&m)return m(c,!0);if(r)return r(c,!0);var g=new Error("Cannot find module '"+c+"'");throw g.code="MODULE_NOT_FOUND",g}var d=o[c]={exports:{}};n[c][0].call(d.exports,function(b){var f=n[c][1][b];return l(f||b)},d,d.exports,i,n,o,s)}return o[c].exports}for(var r=typeof Yn=="function"&&Yn,a=0;a<s.length;a++)l(s[a]);return l})({1:[function(i,n,o){var s=i("./utils"),l=i("./support"),r="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";o.encode=function(a){for(var c,u,m,g,d,b,f,v=[],k=0,S=a.length,x=S,B=s.getTypeOf(a)!=="string";k<a.length;)x=S-k,m=B?(c=a[k++],u=k<S?a[k++]:0,k<S?a[k++]:0):(c=a.charCodeAt(k++),u=k<S?a.charCodeAt(k++):0,k<S?a.charCodeAt(k++):0),g=c>>2,d=(3&c)<<4|u>>4,b=1<x?(15&u)<<2|m>>6:64,f=2<x?63&m:64,v.push(r.charAt(g)+r.charAt(d)+r.charAt(b)+r.charAt(f));return v.join("")},o.decode=function(a){var c,u,m,g,d,b,f=0,v=0,k="data:";if(a.substr(0,k.length)===k)throw new Error("Invalid base64 input, it looks like a data url.");var S,x=3*(a=a.replace(/[^A-Za-z0-9+/=]/g,"")).length/4;if(a.charAt(a.length-1)===r.charAt(64)&&x--,a.charAt(a.length-2)===r.charAt(64)&&x--,x%1!=0)throw new Error("Invalid base64 input, bad content length.");for(S=l.uint8array?new Uint8Array(0|x):new Array(0|x);f<a.length;)c=r.indexOf(a.charAt(f++))<<2|(g=r.indexOf(a.charAt(f++)))>>4,u=(15&g)<<4|(d=r.indexOf(a.charAt(f++)))>>2,m=(3&d)<<6|(b=r.indexOf(a.charAt(f++))),S[v++]=c,d!==64&&(S[v++]=u),b!==64&&(S[v++]=m);return S}},{"./support":30,"./utils":32}],2:[function(i,n,o){var s=i("./external"),l=i("./stream/DataWorker"),r=i("./stream/Crc32Probe"),a=i("./stream/DataLengthProbe");function c(u,m,g,d,b){this.compressedSize=u,this.uncompressedSize=m,this.crc32=g,this.compression=d,this.compressedContent=b}c.prototype={getContentWorker:function(){var u=new l(s.Promise.resolve(this.compressedContent)).pipe(this.compression.uncompressWorker()).pipe(new a("data_length")),m=this;return u.on("end",function(){if(this.streamInfo.data_length!==m.uncompressedSize)throw new Error("Bug : uncompressed data size mismatch")}),u},getCompressedWorker:function(){return new l(s.Promise.resolve(this.compressedContent)).withStreamInfo("compressedSize",this.compressedSize).withStreamInfo("uncompressedSize",this.uncompressedSize).withStreamInfo("crc32",this.crc32).withStreamInfo("compression",this.compression)}},c.createWorkerFrom=function(u,m,g){return u.pipe(new r).pipe(new a("uncompressedSize")).pipe(m.compressWorker(g)).pipe(new a("compressedSize")).withStreamInfo("compression",m)},n.exports=c},{"./external":6,"./stream/Crc32Probe":25,"./stream/DataLengthProbe":26,"./stream/DataWorker":27}],3:[function(i,n,o){var s=i("./stream/GenericWorker");o.STORE={magic:"\0\0",compressWorker:function(){return new s("STORE compression")},uncompressWorker:function(){return new s("STORE decompression")}},o.DEFLATE=i("./flate")},{"./flate":7,"./stream/GenericWorker":28}],4:[function(i,n,o){var s=i("./utils"),l=(function(){for(var r,a=[],c=0;c<256;c++){r=c;for(var u=0;u<8;u++)r=1&r?3988292384^r>>>1:r>>>1;a[c]=r}return a})();n.exports=function(r,a){return r!==void 0&&r.length?s.getTypeOf(r)!=="string"?(function(c,u,m,g){var d=l,b=g+m;c^=-1;for(var f=g;f<b;f++)c=c>>>8^d[255&(c^u[f])];return-1^c})(0|a,r,r.length,0):(function(c,u,m,g){var d=l,b=g+m;c^=-1;for(var f=g;f<b;f++)c=c>>>8^d[255&(c^u.charCodeAt(f))];return-1^c})(0|a,r,r.length,0):0}},{"./utils":32}],5:[function(i,n,o){o.base64=!1,o.binary=!1,o.dir=!1,o.createFolders=!0,o.date=null,o.compression=null,o.compressionOptions=null,o.comment=null,o.unixPermissions=null,o.dosPermissions=null},{}],6:[function(i,n,o){var s=null;s=typeof Promise<"u"?Promise:i("lie"),n.exports={Promise:s}},{lie:37}],7:[function(i,n,o){var s=typeof Uint8Array<"u"&&typeof Uint16Array<"u"&&typeof Uint32Array<"u",l=i("pako"),r=i("./utils"),a=i("./stream/GenericWorker"),c=s?"uint8array":"array";function u(m,g){a.call(this,"FlateWorker/"+m),this._pako=null,this._pakoAction=m,this._pakoOptions=g,this.meta={}}o.magic="\b\0",r.inherits(u,a),u.prototype.processChunk=function(m){this.meta=m.meta,this._pako===null&&this._createPako(),this._pako.push(r.transformTo(c,m.data),!1)},u.prototype.flush=function(){a.prototype.flush.call(this),this._pako===null&&this._createPako(),this._pako.push([],!0)},u.prototype.cleanUp=function(){a.prototype.cleanUp.call(this),this._pako=null},u.prototype._createPako=function(){this._pako=new l[this._pakoAction]({raw:!0,level:this._pakoOptions.level||-1});var m=this;this._pako.onData=function(g){m.push({data:g,meta:m.meta})}},o.compressWorker=function(m){return new u("Deflate",m)},o.uncompressWorker=function(){return new u("Inflate",{})}},{"./stream/GenericWorker":28,"./utils":32,pako:38}],8:[function(i,n,o){function s(d,b){var f,v="";for(f=0;f<b;f++)v+=String.fromCharCode(255&d),d>>>=8;return v}function l(d,b,f,v,k,S){var x,B,E=d.file,A=d.compression,w=S!==c.utf8encode,F=r.transformTo("string",S(E.name)),H=r.transformTo("string",c.utf8encode(E.name)),j=E.comment,J=r.transformTo("string",S(j)),I=r.transformTo("string",c.utf8encode(j)),N=H.length!==E.name.length,y=I.length!==j.length,V="",X="",R="",U=E.dir,W=E.date,tt={crc32:0,compressedSize:0,uncompressedSize:0};b&&!f||(tt.crc32=d.crc32,tt.compressedSize=d.compressedSize,tt.uncompressedSize=d.uncompressedSize);var T=0;b&&(T|=8),w||!N&&!y||(T|=2048);var M=0,Y=0;U&&(M|=16),k==="UNIX"?(Y=798,M|=(function(Q,P){var ct=Q;return Q||(ct=P?16893:33204),(65535&ct)<<16})(E.unixPermissions,U)):(Y=20,M|=(function(Q){return 63&(Q||0)})(E.dosPermissions)),x=W.getUTCHours(),x<<=6,x|=W.getUTCMinutes(),x<<=5,x|=W.getUTCSeconds()/2,B=W.getUTCFullYear()-1980,B<<=4,B|=W.getUTCMonth()+1,B<<=5,B|=W.getUTCDate(),N&&(X=s(1,1)+s(u(F),4)+H,V+="up"+s(X.length,2)+X),y&&(R=s(1,1)+s(u(J),4)+I,V+="uc"+s(R.length,2)+R);var Z="";return Z+=`
\0`,Z+=s(T,2),Z+=A.magic,Z+=s(x,2),Z+=s(B,2),Z+=s(tt.crc32,4),Z+=s(tt.compressedSize,4),Z+=s(tt.uncompressedSize,4),Z+=s(F.length,2),Z+=s(V.length,2),{fileRecord:m.LOCAL_FILE_HEADER+Z+F+V,dirRecord:m.CENTRAL_FILE_HEADER+s(Y,2)+Z+s(J.length,2)+"\0\0\0\0"+s(M,4)+s(v,4)+F+V+J}}var r=i("../utils"),a=i("../stream/GenericWorker"),c=i("../utf8"),u=i("../crc32"),m=i("../signature");function g(d,b,f,v){a.call(this,"ZipFileWorker"),this.bytesWritten=0,this.zipComment=b,this.zipPlatform=f,this.encodeFileName=v,this.streamFiles=d,this.accumulate=!1,this.contentBuffer=[],this.dirRecords=[],this.currentSourceOffset=0,this.entriesCount=0,this.currentFile=null,this._sources=[]}r.inherits(g,a),g.prototype.push=function(d){var b=d.meta.percent||0,f=this.entriesCount,v=this._sources.length;this.accumulate?this.contentBuffer.push(d):(this.bytesWritten+=d.data.length,a.prototype.push.call(this,{data:d.data,meta:{currentFile:this.currentFile,percent:f?(b+100*(f-v-1))/f:100}}))},g.prototype.openedSource=function(d){this.currentSourceOffset=this.bytesWritten,this.currentFile=d.file.name;var b=this.streamFiles&&!d.file.dir;if(b){var f=l(d,b,!1,this.currentSourceOffset,this.zipPlatform,this.encodeFileName);this.push({data:f.fileRecord,meta:{percent:0}})}else this.accumulate=!0},g.prototype.closedSource=function(d){this.accumulate=!1;var b=this.streamFiles&&!d.file.dir,f=l(d,b,!0,this.currentSourceOffset,this.zipPlatform,this.encodeFileName);if(this.dirRecords.push(f.dirRecord),b)this.push({data:(function(v){return m.DATA_DESCRIPTOR+s(v.crc32,4)+s(v.compressedSize,4)+s(v.uncompressedSize,4)})(d),meta:{percent:100}});else for(this.push({data:f.fileRecord,meta:{percent:0}});this.contentBuffer.length;)this.push(this.contentBuffer.shift());this.currentFile=null},g.prototype.flush=function(){for(var d=this.bytesWritten,b=0;b<this.dirRecords.length;b++)this.push({data:this.dirRecords[b],meta:{percent:100}});var f=this.bytesWritten-d,v=(function(k,S,x,B,E){var A=r.transformTo("string",E(B));return m.CENTRAL_DIRECTORY_END+"\0\0\0\0"+s(k,2)+s(k,2)+s(S,4)+s(x,4)+s(A.length,2)+A})(this.dirRecords.length,f,d,this.zipComment,this.encodeFileName);this.push({data:v,meta:{percent:100}})},g.prototype.prepareNextSource=function(){this.previous=this._sources.shift(),this.openedSource(this.previous.streamInfo),this.isPaused?this.previous.pause():this.previous.resume()},g.prototype.registerPrevious=function(d){this._sources.push(d);var b=this;return d.on("data",function(f){b.processChunk(f)}),d.on("end",function(){b.closedSource(b.previous.streamInfo),b._sources.length?b.prepareNextSource():b.end()}),d.on("error",function(f){b.error(f)}),this},g.prototype.resume=function(){return!!a.prototype.resume.call(this)&&(!this.previous&&this._sources.length?(this.prepareNextSource(),!0):this.previous||this._sources.length||this.generatedError?void 0:(this.end(),!0))},g.prototype.error=function(d){var b=this._sources;if(!a.prototype.error.call(this,d))return!1;for(var f=0;f<b.length;f++)try{b[f].error(d)}catch{}return!0},g.prototype.lock=function(){a.prototype.lock.call(this);for(var d=this._sources,b=0;b<d.length;b++)d[b].lock()},n.exports=g},{"../crc32":4,"../signature":23,"../stream/GenericWorker":28,"../utf8":31,"../utils":32}],9:[function(i,n,o){var s=i("../compressions"),l=i("./ZipFileWorker");o.generateWorker=function(r,a,c){var u=new l(a.streamFiles,c,a.platform,a.encodeFileName),m=0;try{r.forEach(function(g,d){m++;var b=(function(S,x){var B=S||x,E=s[B];if(!E)throw new Error(B+" is not a valid compression method !");return E})(d.options.compression,a.compression),f=d.options.compressionOptions||a.compressionOptions||{},v=d.dir,k=d.date;d._compressWorker(b,f).withStreamInfo("file",{name:g,dir:v,date:k,comment:d.comment||"",unixPermissions:d.unixPermissions,dosPermissions:d.dosPermissions}).pipe(u)}),u.entriesCount=m}catch(g){u.error(g)}return u}},{"../compressions":3,"./ZipFileWorker":8}],10:[function(i,n,o){function s(){if(!(this instanceof s))return new s;if(arguments.length)throw new Error("The constructor with parameters has been removed in JSZip 3.0, please check the upgrade guide.");this.files=Object.create(null),this.comment=null,this.root="",this.clone=function(){var l=new s;for(var r in this)typeof this[r]!="function"&&(l[r]=this[r]);return l}}(s.prototype=i("./object")).loadAsync=i("./load"),s.support=i("./support"),s.defaults=i("./defaults"),s.version="3.10.1",s.loadAsync=function(l,r){return new s().loadAsync(l,r)},s.external=i("./external"),n.exports=s},{"./defaults":5,"./external":6,"./load":11,"./object":15,"./support":30}],11:[function(i,n,o){var s=i("./utils"),l=i("./external"),r=i("./utf8"),a=i("./zipEntries"),c=i("./stream/Crc32Probe"),u=i("./nodejsUtils");function m(g){return new l.Promise(function(d,b){var f=g.decompressed.getContentWorker().pipe(new c);f.on("error",function(v){b(v)}).on("end",function(){f.streamInfo.crc32!==g.decompressed.crc32?b(new Error("Corrupted zip : CRC32 mismatch")):d()}).resume()})}n.exports=function(g,d){var b=this;return d=s.extend(d||{},{base64:!1,checkCRC32:!1,optimizedBinaryString:!1,createFolders:!1,decodeFileName:r.utf8decode}),u.isNode&&u.isStream(g)?l.Promise.reject(new Error("JSZip can't accept a stream when loading a zip file.")):s.prepareContent("the loaded zip file",g,!0,d.optimizedBinaryString,d.base64).then(function(f){var v=new a(d);return v.load(f),v}).then(function(f){var v=[l.Promise.resolve(f)],k=f.files;if(d.checkCRC32)for(var S=0;S<k.length;S++)v.push(m(k[S]));return l.Promise.all(v)}).then(function(f){for(var v=f.shift(),k=v.files,S=0;S<k.length;S++){var x=k[S],B=x.fileNameStr,E=s.resolve(x.fileNameStr);b.file(E,x.decompressed,{binary:!0,optimizedBinaryString:!0,date:x.date,dir:x.dir,comment:x.fileCommentStr.length?x.fileCommentStr:null,unixPermissions:x.unixPermissions,dosPermissions:x.dosPermissions,createFolders:d.createFolders}),x.dir||(b.file(E).unsafeOriginalName=B)}return v.zipComment.length&&(b.comment=v.zipComment),b})}},{"./external":6,"./nodejsUtils":14,"./stream/Crc32Probe":25,"./utf8":31,"./utils":32,"./zipEntries":33}],12:[function(i,n,o){var s=i("../utils"),l=i("../stream/GenericWorker");function r(a,c){l.call(this,"Nodejs stream input adapter for "+a),this._upstreamEnded=!1,this._bindStream(c)}s.inherits(r,l),r.prototype._bindStream=function(a){var c=this;(this._stream=a).pause(),a.on("data",function(u){c.push({data:u,meta:{percent:0}})}).on("error",function(u){c.isPaused?this.generatedError=u:c.error(u)}).on("end",function(){c.isPaused?c._upstreamEnded=!0:c.end()})},r.prototype.pause=function(){return!!l.prototype.pause.call(this)&&(this._stream.pause(),!0)},r.prototype.resume=function(){return!!l.prototype.resume.call(this)&&(this._upstreamEnded?this.end():this._stream.resume(),!0)},n.exports=r},{"../stream/GenericWorker":28,"../utils":32}],13:[function(i,n,o){var s=i("readable-stream").Readable;function l(r,a,c){s.call(this,a),this._helper=r;var u=this;r.on("data",function(m,g){u.push(m)||u._helper.pause(),c&&c(g)}).on("error",function(m){u.emit("error",m)}).on("end",function(){u.push(null)})}i("../utils").inherits(l,s),l.prototype._read=function(){this._helper.resume()},n.exports=l},{"../utils":32,"readable-stream":16}],14:[function(i,n,o){n.exports={isNode:typeof Buffer<"u",newBufferFrom:function(s,l){if(Buffer.from&&Buffer.from!==Uint8Array.from)return Buffer.from(s,l);if(typeof s=="number")throw new Error('The "data" argument must not be a number');return new Buffer(s,l)},allocBuffer:function(s){if(Buffer.alloc)return Buffer.alloc(s);var l=new Buffer(s);return l.fill(0),l},isBuffer:function(s){return Buffer.isBuffer(s)},isStream:function(s){return s&&typeof s.on=="function"&&typeof s.pause=="function"&&typeof s.resume=="function"}}},{}],15:[function(i,n,o){function s(E,A,w){var F,H=r.getTypeOf(A),j=r.extend(w||{},u);j.date=j.date||new Date,j.compression!==null&&(j.compression=j.compression.toUpperCase()),typeof j.unixPermissions=="string"&&(j.unixPermissions=parseInt(j.unixPermissions,8)),j.unixPermissions&&16384&j.unixPermissions&&(j.dir=!0),j.dosPermissions&&16&j.dosPermissions&&(j.dir=!0),j.dir&&(E=k(E)),j.createFolders&&(F=v(E))&&S.call(this,F,!0);var J=H==="string"&&j.binary===!1&&j.base64===!1;w&&w.binary!==void 0||(j.binary=!J),(A instanceof m&&A.uncompressedSize===0||j.dir||!A||A.length===0)&&(j.base64=!1,j.binary=!0,A="",j.compression="STORE",H="string");var I=null;I=A instanceof m||A instanceof a?A:b.isNode&&b.isStream(A)?new f(E,A):r.prepareContent(E,A,j.binary,j.optimizedBinaryString,j.base64);var N=new g(E,I,j);this.files[E]=N}var l=i("./utf8"),r=i("./utils"),a=i("./stream/GenericWorker"),c=i("./stream/StreamHelper"),u=i("./defaults"),m=i("./compressedObject"),g=i("./zipObject"),d=i("./generate"),b=i("./nodejsUtils"),f=i("./nodejs/NodejsStreamInputAdapter"),v=function(E){E.slice(-1)==="/"&&(E=E.substring(0,E.length-1));var A=E.lastIndexOf("/");return 0<A?E.substring(0,A):""},k=function(E){return E.slice(-1)!=="/"&&(E+="/"),E},S=function(E,A){return A=A!==void 0?A:u.createFolders,E=k(E),this.files[E]||s.call(this,E,null,{dir:!0,createFolders:A}),this.files[E]};function x(E){return Object.prototype.toString.call(E)==="[object RegExp]"}var B={load:function(){throw new Error("This method has been removed in JSZip 3.0, please check the upgrade guide.")},forEach:function(E){var A,w,F;for(A in this.files)F=this.files[A],(w=A.slice(this.root.length,A.length))&&A.slice(0,this.root.length)===this.root&&E(w,F)},filter:function(E){var A=[];return this.forEach(function(w,F){E(w,F)&&A.push(F)}),A},file:function(E,A,w){if(arguments.length!==1)return E=this.root+E,s.call(this,E,A,w),this;if(x(E)){var F=E;return this.filter(function(j,J){return!J.dir&&F.test(j)})}var H=this.files[this.root+E];return H&&!H.dir?H:null},folder:function(E){if(!E)return this;if(x(E))return this.filter(function(H,j){return j.dir&&E.test(H)});var A=this.root+E,w=S.call(this,A),F=this.clone();return F.root=w.name,F},remove:function(E){E=this.root+E;var A=this.files[E];if(A||(E.slice(-1)!=="/"&&(E+="/"),A=this.files[E]),A&&!A.dir)delete this.files[E];else for(var w=this.filter(function(H,j){return j.name.slice(0,E.length)===E}),F=0;F<w.length;F++)delete this.files[w[F].name];return this},generate:function(){throw new Error("This method has been removed in JSZip 3.0, please check the upgrade guide.")},generateInternalStream:function(E){var A,w={};try{if((w=r.extend(E||{},{streamFiles:!1,compression:"STORE",compressionOptions:null,type:"",platform:"DOS",comment:null,mimeType:"application/zip",encodeFileName:l.utf8encode})).type=w.type.toLowerCase(),w.compression=w.compression.toUpperCase(),w.type==="binarystring"&&(w.type="string"),!w.type)throw new Error("No output type specified.");r.checkSupport(w.type),w.platform!=="darwin"&&w.platform!=="freebsd"&&w.platform!=="linux"&&w.platform!=="sunos"||(w.platform="UNIX"),w.platform==="win32"&&(w.platform="DOS");var F=w.comment||this.comment||"";A=d.generateWorker(this,w,F)}catch(H){(A=new a("error")).error(H)}return new c(A,w.type||"string",w.mimeType)},generateAsync:function(E,A){return this.generateInternalStream(E).accumulate(A)},generateNodeStream:function(E,A){return(E=E||{}).type||(E.type="nodebuffer"),this.generateInternalStream(E).toNodejsStream(A)}};n.exports=B},{"./compressedObject":2,"./defaults":5,"./generate":9,"./nodejs/NodejsStreamInputAdapter":12,"./nodejsUtils":14,"./stream/GenericWorker":28,"./stream/StreamHelper":29,"./utf8":31,"./utils":32,"./zipObject":35}],16:[function(i,n,o){n.exports=i("stream")},{stream:void 0}],17:[function(i,n,o){var s=i("./DataReader");function l(r){s.call(this,r);for(var a=0;a<this.data.length;a++)r[a]=255&r[a]}i("../utils").inherits(l,s),l.prototype.byteAt=function(r){return this.data[this.zero+r]},l.prototype.lastIndexOfSignature=function(r){for(var a=r.charCodeAt(0),c=r.charCodeAt(1),u=r.charCodeAt(2),m=r.charCodeAt(3),g=this.length-4;0<=g;--g)if(this.data[g]===a&&this.data[g+1]===c&&this.data[g+2]===u&&this.data[g+3]===m)return g-this.zero;return-1},l.prototype.readAndCheckSignature=function(r){var a=r.charCodeAt(0),c=r.charCodeAt(1),u=r.charCodeAt(2),m=r.charCodeAt(3),g=this.readData(4);return a===g[0]&&c===g[1]&&u===g[2]&&m===g[3]},l.prototype.readData=function(r){if(this.checkOffset(r),r===0)return[];var a=this.data.slice(this.zero+this.index,this.zero+this.index+r);return this.index+=r,a},n.exports=l},{"../utils":32,"./DataReader":18}],18:[function(i,n,o){var s=i("../utils");function l(r){this.data=r,this.length=r.length,this.index=0,this.zero=0}l.prototype={checkOffset:function(r){this.checkIndex(this.index+r)},checkIndex:function(r){if(this.length<this.zero+r||r<0)throw new Error("End of data reached (data length = "+this.length+", asked index = "+r+"). Corrupted zip ?")},setIndex:function(r){this.checkIndex(r),this.index=r},skip:function(r){this.setIndex(this.index+r)},byteAt:function(){},readInt:function(r){var a,c=0;for(this.checkOffset(r),a=this.index+r-1;a>=this.index;a--)c=(c<<8)+this.byteAt(a);return this.index+=r,c},readString:function(r){return s.transformTo("string",this.readData(r))},readData:function(){},lastIndexOfSignature:function(){},readAndCheckSignature:function(){},readDate:function(){var r=this.readInt(4);return new Date(Date.UTC(1980+(r>>25&127),(r>>21&15)-1,r>>16&31,r>>11&31,r>>5&63,(31&r)<<1))}},n.exports=l},{"../utils":32}],19:[function(i,n,o){var s=i("./Uint8ArrayReader");function l(r){s.call(this,r)}i("../utils").inherits(l,s),l.prototype.readData=function(r){this.checkOffset(r);var a=this.data.slice(this.zero+this.index,this.zero+this.index+r);return this.index+=r,a},n.exports=l},{"../utils":32,"./Uint8ArrayReader":21}],20:[function(i,n,o){var s=i("./DataReader");function l(r){s.call(this,r)}i("../utils").inherits(l,s),l.prototype.byteAt=function(r){return this.data.charCodeAt(this.zero+r)},l.prototype.lastIndexOfSignature=function(r){return this.data.lastIndexOf(r)-this.zero},l.prototype.readAndCheckSignature=function(r){return r===this.readData(4)},l.prototype.readData=function(r){this.checkOffset(r);var a=this.data.slice(this.zero+this.index,this.zero+this.index+r);return this.index+=r,a},n.exports=l},{"../utils":32,"./DataReader":18}],21:[function(i,n,o){var s=i("./ArrayReader");function l(r){s.call(this,r)}i("../utils").inherits(l,s),l.prototype.readData=function(r){if(this.checkOffset(r),r===0)return new Uint8Array(0);var a=this.data.subarray(this.zero+this.index,this.zero+this.index+r);return this.index+=r,a},n.exports=l},{"../utils":32,"./ArrayReader":17}],22:[function(i,n,o){var s=i("../utils"),l=i("../support"),r=i("./ArrayReader"),a=i("./StringReader"),c=i("./NodeBufferReader"),u=i("./Uint8ArrayReader");n.exports=function(m){var g=s.getTypeOf(m);return s.checkSupport(g),g!=="string"||l.uint8array?g==="nodebuffer"?new c(m):l.uint8array?new u(s.transformTo("uint8array",m)):new r(s.transformTo("array",m)):new a(m)}},{"../support":30,"../utils":32,"./ArrayReader":17,"./NodeBufferReader":19,"./StringReader":20,"./Uint8ArrayReader":21}],23:[function(i,n,o){o.LOCAL_FILE_HEADER="PK",o.CENTRAL_FILE_HEADER="PK",o.CENTRAL_DIRECTORY_END="PK",o.ZIP64_CENTRAL_DIRECTORY_LOCATOR="PK\x07",o.ZIP64_CENTRAL_DIRECTORY_END="PK",o.DATA_DESCRIPTOR="PK\x07\b"},{}],24:[function(i,n,o){var s=i("./GenericWorker"),l=i("../utils");function r(a){s.call(this,"ConvertWorker to "+a),this.destType=a}l.inherits(r,s),r.prototype.processChunk=function(a){this.push({data:l.transformTo(this.destType,a.data),meta:a.meta})},n.exports=r},{"../utils":32,"./GenericWorker":28}],25:[function(i,n,o){var s=i("./GenericWorker"),l=i("../crc32");function r(){s.call(this,"Crc32Probe"),this.withStreamInfo("crc32",0)}i("../utils").inherits(r,s),r.prototype.processChunk=function(a){this.streamInfo.crc32=l(a.data,this.streamInfo.crc32||0),this.push(a)},n.exports=r},{"../crc32":4,"../utils":32,"./GenericWorker":28}],26:[function(i,n,o){var s=i("../utils"),l=i("./GenericWorker");function r(a){l.call(this,"DataLengthProbe for "+a),this.propName=a,this.withStreamInfo(a,0)}s.inherits(r,l),r.prototype.processChunk=function(a){if(a){var c=this.streamInfo[this.propName]||0;this.streamInfo[this.propName]=c+a.data.length}l.prototype.processChunk.call(this,a)},n.exports=r},{"../utils":32,"./GenericWorker":28}],27:[function(i,n,o){var s=i("../utils"),l=i("./GenericWorker");function r(a){l.call(this,"DataWorker");var c=this;this.dataIsReady=!1,this.index=0,this.max=0,this.data=null,this.type="",this._tickScheduled=!1,a.then(function(u){c.dataIsReady=!0,c.data=u,c.max=u&&u.length||0,c.type=s.getTypeOf(u),c.isPaused||c._tickAndRepeat()},function(u){c.error(u)})}s.inherits(r,l),r.prototype.cleanUp=function(){l.prototype.cleanUp.call(this),this.data=null},r.prototype.resume=function(){return!!l.prototype.resume.call(this)&&(!this._tickScheduled&&this.dataIsReady&&(this._tickScheduled=!0,s.delay(this._tickAndRepeat,[],this)),!0)},r.prototype._tickAndRepeat=function(){this._tickScheduled=!1,this.isPaused||this.isFinished||(this._tick(),this.isFinished||(s.delay(this._tickAndRepeat,[],this),this._tickScheduled=!0))},r.prototype._tick=function(){if(this.isPaused||this.isFinished)return!1;var a=null,c=Math.min(this.max,this.index+16384);if(this.index>=this.max)return this.end();switch(this.type){case"string":a=this.data.substring(this.index,c);break;case"uint8array":a=this.data.subarray(this.index,c);break;case"array":case"nodebuffer":a=this.data.slice(this.index,c)}return this.index=c,this.push({data:a,meta:{percent:this.max?this.index/this.max*100:0}})},n.exports=r},{"../utils":32,"./GenericWorker":28}],28:[function(i,n,o){function s(l){this.name=l||"default",this.streamInfo={},this.generatedError=null,this.extraStreamInfo={},this.isPaused=!0,this.isFinished=!1,this.isLocked=!1,this._listeners={data:[],end:[],error:[]},this.previous=null}s.prototype={push:function(l){this.emit("data",l)},end:function(){if(this.isFinished)return!1;this.flush();try{this.emit("end"),this.cleanUp(),this.isFinished=!0}catch(l){this.emit("error",l)}return!0},error:function(l){return!this.isFinished&&(this.isPaused?this.generatedError=l:(this.isFinished=!0,this.emit("error",l),this.previous&&this.previous.error(l),this.cleanUp()),!0)},on:function(l,r){return this._listeners[l].push(r),this},cleanUp:function(){this.streamInfo=this.generatedError=this.extraStreamInfo=null,this._listeners=[]},emit:function(l,r){if(this._listeners[l])for(var a=0;a<this._listeners[l].length;a++)this._listeners[l][a].call(this,r)},pipe:function(l){return l.registerPrevious(this)},registerPrevious:function(l){if(this.isLocked)throw new Error("The stream '"+this+"' has already been used.");this.streamInfo=l.streamInfo,this.mergeStreamInfo(),this.previous=l;var r=this;return l.on("data",function(a){r.processChunk(a)}),l.on("end",function(){r.end()}),l.on("error",function(a){r.error(a)}),this},pause:function(){return!this.isPaused&&!this.isFinished&&(this.isPaused=!0,this.previous&&this.previous.pause(),!0)},resume:function(){if(!this.isPaused||this.isFinished)return!1;var l=this.isPaused=!1;return this.generatedError&&(this.error(this.generatedError),l=!0),this.previous&&this.previous.resume(),!l},flush:function(){},processChunk:function(l){this.push(l)},withStreamInfo:function(l,r){return this.extraStreamInfo[l]=r,this.mergeStreamInfo(),this},mergeStreamInfo:function(){for(var l in this.extraStreamInfo)Object.prototype.hasOwnProperty.call(this.extraStreamInfo,l)&&(this.streamInfo[l]=this.extraStreamInfo[l])},lock:function(){if(this.isLocked)throw new Error("The stream '"+this+"' has already been used.");this.isLocked=!0,this.previous&&this.previous.lock()},toString:function(){var l="Worker "+this.name;return this.previous?this.previous+" -> "+l:l}},n.exports=s},{}],29:[function(i,n,o){var s=i("../utils"),l=i("./ConvertWorker"),r=i("./GenericWorker"),a=i("../base64"),c=i("../support"),u=i("../external"),m=null;if(c.nodestream)try{m=i("../nodejs/NodejsStreamOutputAdapter")}catch{}function g(b,f){return new u.Promise(function(v,k){var S=[],x=b._internalType,B=b._outputType,E=b._mimeType;b.on("data",function(A,w){S.push(A),f&&f(w)}).on("error",function(A){S=[],k(A)}).on("end",function(){try{var A=(function(w,F,H){switch(w){case"blob":return s.newBlob(s.transformTo("arraybuffer",F),H);case"base64":return a.encode(F);default:return s.transformTo(w,F)}})(B,(function(w,F){var H,j=0,J=null,I=0;for(H=0;H<F.length;H++)I+=F[H].length;switch(w){case"string":return F.join("");case"array":return Array.prototype.concat.apply([],F);case"uint8array":for(J=new Uint8Array(I),H=0;H<F.length;H++)J.set(F[H],j),j+=F[H].length;return J;case"nodebuffer":return Buffer.concat(F);default:throw new Error("concat : unsupported type '"+w+"'")}})(x,S),E);v(A)}catch(w){k(w)}S=[]}).resume()})}function d(b,f,v){var k=f;switch(f){case"blob":case"arraybuffer":k="uint8array";break;case"base64":k="string"}try{this._internalType=k,this._outputType=f,this._mimeType=v,s.checkSupport(k),this._worker=b.pipe(new l(k)),b.lock()}catch(S){this._worker=new r("error"),this._worker.error(S)}}d.prototype={accumulate:function(b){return g(this,b)},on:function(b,f){var v=this;return b==="data"?this._worker.on(b,function(k){f.call(v,k.data,k.meta)}):this._worker.on(b,function(){s.delay(f,arguments,v)}),this},resume:function(){return s.delay(this._worker.resume,[],this._worker),this},pause:function(){return this._worker.pause(),this},toNodejsStream:function(b){if(s.checkSupport("nodestream"),this._outputType!=="nodebuffer")throw new Error(this._outputType+" is not supported by this method");return new m(this,{objectMode:this._outputType!=="nodebuffer"},b)}},n.exports=d},{"../base64":1,"../external":6,"../nodejs/NodejsStreamOutputAdapter":13,"../support":30,"../utils":32,"./ConvertWorker":24,"./GenericWorker":28}],30:[function(i,n,o){if(o.base64=!0,o.array=!0,o.string=!0,o.arraybuffer=typeof ArrayBuffer<"u"&&typeof Uint8Array<"u",o.nodebuffer=typeof Buffer<"u",o.uint8array=typeof Uint8Array<"u",typeof ArrayBuffer>"u")o.blob=!1;else{var s=new ArrayBuffer(0);try{o.blob=new Blob([s],{type:"application/zip"}).size===0}catch{try{var l=new(self.BlobBuilder||self.WebKitBlobBuilder||self.MozBlobBuilder||self.MSBlobBuilder);l.append(s),o.blob=l.getBlob("application/zip").size===0}catch{o.blob=!1}}}try{o.nodestream=!!i("readable-stream").Readable}catch{o.nodestream=!1}},{"readable-stream":16}],31:[function(i,n,o){for(var s=i("./utils"),l=i("./support"),r=i("./nodejsUtils"),a=i("./stream/GenericWorker"),c=new Array(256),u=0;u<256;u++)c[u]=252<=u?6:248<=u?5:240<=u?4:224<=u?3:192<=u?2:1;c[254]=c[254]=1;function m(){a.call(this,"utf-8 decode"),this.leftOver=null}function g(){a.call(this,"utf-8 encode")}o.utf8encode=function(d){return l.nodebuffer?r.newBufferFrom(d,"utf-8"):(function(b){var f,v,k,S,x,B=b.length,E=0;for(S=0;S<B;S++)(64512&(v=b.charCodeAt(S)))==55296&&S+1<B&&(64512&(k=b.charCodeAt(S+1)))==56320&&(v=65536+(v-55296<<10)+(k-56320),S++),E+=v<128?1:v<2048?2:v<65536?3:4;for(f=l.uint8array?new Uint8Array(E):new Array(E),S=x=0;x<E;S++)(64512&(v=b.charCodeAt(S)))==55296&&S+1<B&&(64512&(k=b.charCodeAt(S+1)))==56320&&(v=65536+(v-55296<<10)+(k-56320),S++),v<128?f[x++]=v:(v<2048?f[x++]=192|v>>>6:(v<65536?f[x++]=224|v>>>12:(f[x++]=240|v>>>18,f[x++]=128|v>>>12&63),f[x++]=128|v>>>6&63),f[x++]=128|63&v);return f})(d)},o.utf8decode=function(d){return l.nodebuffer?s.transformTo("nodebuffer",d).toString("utf-8"):(function(b){var f,v,k,S,x=b.length,B=new Array(2*x);for(f=v=0;f<x;)if((k=b[f++])<128)B[v++]=k;else if(4<(S=c[k]))B[v++]=65533,f+=S-1;else{for(k&=S===2?31:S===3?15:7;1<S&&f<x;)k=k<<6|63&b[f++],S--;1<S?B[v++]=65533:k<65536?B[v++]=k:(k-=65536,B[v++]=55296|k>>10&1023,B[v++]=56320|1023&k)}return B.length!==v&&(B.subarray?B=B.subarray(0,v):B.length=v),s.applyFromCharCode(B)})(d=s.transformTo(l.uint8array?"uint8array":"array",d))},s.inherits(m,a),m.prototype.processChunk=function(d){var b=s.transformTo(l.uint8array?"uint8array":"array",d.data);if(this.leftOver&&this.leftOver.length){if(l.uint8array){var f=b;(b=new Uint8Array(f.length+this.leftOver.length)).set(this.leftOver,0),b.set(f,this.leftOver.length)}else b=this.leftOver.concat(b);this.leftOver=null}var v=(function(S,x){var B;for((x=x||S.length)>S.length&&(x=S.length),B=x-1;0<=B&&(192&S[B])==128;)B--;return B<0||B===0?x:B+c[S[B]]>x?B:x})(b),k=b;v!==b.length&&(l.uint8array?(k=b.subarray(0,v),this.leftOver=b.subarray(v,b.length)):(k=b.slice(0,v),this.leftOver=b.slice(v,b.length))),this.push({data:o.utf8decode(k),meta:d.meta})},m.prototype.flush=function(){this.leftOver&&this.leftOver.length&&(this.push({data:o.utf8decode(this.leftOver),meta:{}}),this.leftOver=null)},o.Utf8DecodeWorker=m,s.inherits(g,a),g.prototype.processChunk=function(d){this.push({data:o.utf8encode(d.data),meta:d.meta})},o.Utf8EncodeWorker=g},{"./nodejsUtils":14,"./stream/GenericWorker":28,"./support":30,"./utils":32}],32:[function(i,n,o){var s=i("./support"),l=i("./base64"),r=i("./nodejsUtils"),a=i("./external");function c(f){return f}function u(f,v){for(var k=0;k<f.length;++k)v[k]=255&f.charCodeAt(k);return v}i("setimmediate"),o.newBlob=function(f,v){o.checkSupport("blob");try{return new Blob([f],{type:v})}catch{try{var k=new(self.BlobBuilder||self.WebKitBlobBuilder||self.MozBlobBuilder||self.MSBlobBuilder);return k.append(f),k.getBlob(v)}catch{throw new Error("Bug : can't construct the Blob.")}}};var m={stringifyByChunk:function(f,v,k){var S=[],x=0,B=f.length;if(B<=k)return String.fromCharCode.apply(null,f);for(;x<B;)v==="array"||v==="nodebuffer"?S.push(String.fromCharCode.apply(null,f.slice(x,Math.min(x+k,B)))):S.push(String.fromCharCode.apply(null,f.subarray(x,Math.min(x+k,B)))),x+=k;return S.join("")},stringifyByChar:function(f){for(var v="",k=0;k<f.length;k++)v+=String.fromCharCode(f[k]);return v},applyCanBeUsed:{uint8array:(function(){try{return s.uint8array&&String.fromCharCode.apply(null,new Uint8Array(1)).length===1}catch{return!1}})(),nodebuffer:(function(){try{return s.nodebuffer&&String.fromCharCode.apply(null,r.allocBuffer(1)).length===1}catch{return!1}})()}};function g(f){var v=65536,k=o.getTypeOf(f),S=!0;if(k==="uint8array"?S=m.applyCanBeUsed.uint8array:k==="nodebuffer"&&(S=m.applyCanBeUsed.nodebuffer),S)for(;1<v;)try{return m.stringifyByChunk(f,k,v)}catch{v=Math.floor(v/2)}return m.stringifyByChar(f)}function d(f,v){for(var k=0;k<f.length;k++)v[k]=f[k];return v}o.applyFromCharCode=g;var b={};b.string={string:c,array:function(f){return u(f,new Array(f.length))},arraybuffer:function(f){return b.string.uint8array(f).buffer},uint8array:function(f){return u(f,new Uint8Array(f.length))},nodebuffer:function(f){return u(f,r.allocBuffer(f.length))}},b.array={string:g,array:c,arraybuffer:function(f){return new Uint8Array(f).buffer},uint8array:function(f){return new Uint8Array(f)},nodebuffer:function(f){return r.newBufferFrom(f)}},b.arraybuffer={string:function(f){return g(new Uint8Array(f))},array:function(f){return d(new Uint8Array(f),new Array(f.byteLength))},arraybuffer:c,uint8array:function(f){return new Uint8Array(f)},nodebuffer:function(f){return r.newBufferFrom(new Uint8Array(f))}},b.uint8array={string:g,array:function(f){return d(f,new Array(f.length))},arraybuffer:function(f){return f.buffer},uint8array:c,nodebuffer:function(f){return r.newBufferFrom(f)}},b.nodebuffer={string:g,array:function(f){return d(f,new Array(f.length))},arraybuffer:function(f){return b.nodebuffer.uint8array(f).buffer},uint8array:function(f){return d(f,new Uint8Array(f.length))},nodebuffer:c},o.transformTo=function(f,v){if(v=v||"",!f)return v;o.checkSupport(f);var k=o.getTypeOf(v);return b[k][f](v)},o.resolve=function(f){for(var v=f.split("/"),k=[],S=0;S<v.length;S++){var x=v[S];x==="."||x===""&&S!==0&&S!==v.length-1||(x===".."?k.pop():k.push(x))}return k.join("/")},o.getTypeOf=function(f){return typeof f=="string"?"string":Object.prototype.toString.call(f)==="[object Array]"?"array":s.nodebuffer&&r.isBuffer(f)?"nodebuffer":s.uint8array&&f instanceof Uint8Array?"uint8array":s.arraybuffer&&f instanceof ArrayBuffer?"arraybuffer":void 0},o.checkSupport=function(f){if(!s[f.toLowerCase()])throw new Error(f+" is not supported by this platform")},o.MAX_VALUE_16BITS=65535,o.MAX_VALUE_32BITS=-1,o.pretty=function(f){var v,k,S="";for(k=0;k<(f||"").length;k++)S+="\\x"+((v=f.charCodeAt(k))<16?"0":"")+v.toString(16).toUpperCase();return S},o.delay=function(f,v,k){setImmediate(function(){f.apply(k||null,v||[])})},o.inherits=function(f,v){function k(){}k.prototype=v.prototype,f.prototype=new k},o.extend=function(){var f,v,k={};for(f=0;f<arguments.length;f++)for(v in arguments[f])Object.prototype.hasOwnProperty.call(arguments[f],v)&&k[v]===void 0&&(k[v]=arguments[f][v]);return k},o.prepareContent=function(f,v,k,S,x){return a.Promise.resolve(v).then(function(B){return s.blob&&(B instanceof Blob||["[object File]","[object Blob]"].indexOf(Object.prototype.toString.call(B))!==-1)&&typeof FileReader<"u"?new a.Promise(function(E,A){var w=new FileReader;w.onload=function(F){E(F.target.result)},w.onerror=function(F){A(F.target.error)},w.readAsArrayBuffer(B)}):B}).then(function(B){var E=o.getTypeOf(B);return E?(E==="arraybuffer"?B=o.transformTo("uint8array",B):E==="string"&&(x?B=l.decode(B):k&&S!==!0&&(B=(function(A){return u(A,s.uint8array?new Uint8Array(A.length):new Array(A.length))})(B))),B):a.Promise.reject(new Error("Can't read the data of '"+f+"'. Is it in a supported JavaScript type (String, Blob, ArrayBuffer, etc) ?"))})}},{"./base64":1,"./external":6,"./nodejsUtils":14,"./support":30,setimmediate:54}],33:[function(i,n,o){var s=i("./reader/readerFor"),l=i("./utils"),r=i("./signature"),a=i("./zipEntry"),c=i("./support");function u(m){this.files=[],this.loadOptions=m}u.prototype={checkSignature:function(m){if(!this.reader.readAndCheckSignature(m)){this.reader.index-=4;var g=this.reader.readString(4);throw new Error("Corrupted zip or bug: unexpected signature ("+l.pretty(g)+", expected "+l.pretty(m)+")")}},isSignature:function(m,g){var d=this.reader.index;this.reader.setIndex(m);var b=this.reader.readString(4)===g;return this.reader.setIndex(d),b},readBlockEndOfCentral:function(){this.diskNumber=this.reader.readInt(2),this.diskWithCentralDirStart=this.reader.readInt(2),this.centralDirRecordsOnThisDisk=this.reader.readInt(2),this.centralDirRecords=this.reader.readInt(2),this.centralDirSize=this.reader.readInt(4),this.centralDirOffset=this.reader.readInt(4),this.zipCommentLength=this.reader.readInt(2);var m=this.reader.readData(this.zipCommentLength),g=c.uint8array?"uint8array":"array",d=l.transformTo(g,m);this.zipComment=this.loadOptions.decodeFileName(d)},readBlockZip64EndOfCentral:function(){this.zip64EndOfCentralSize=this.reader.readInt(8),this.reader.skip(4),this.diskNumber=this.reader.readInt(4),this.diskWithCentralDirStart=this.reader.readInt(4),this.centralDirRecordsOnThisDisk=this.reader.readInt(8),this.centralDirRecords=this.reader.readInt(8),this.centralDirSize=this.reader.readInt(8),this.centralDirOffset=this.reader.readInt(8),this.zip64ExtensibleData={};for(var m,g,d,b=this.zip64EndOfCentralSize-44;0<b;)m=this.reader.readInt(2),g=this.reader.readInt(4),d=this.reader.readData(g),this.zip64ExtensibleData[m]={id:m,length:g,value:d}},readBlockZip64EndOfCentralLocator:function(){if(this.diskWithZip64CentralDirStart=this.reader.readInt(4),this.relativeOffsetEndOfZip64CentralDir=this.reader.readInt(8),this.disksCount=this.reader.readInt(4),1<this.disksCount)throw new Error("Multi-volumes zip are not supported")},readLocalFiles:function(){var m,g;for(m=0;m<this.files.length;m++)g=this.files[m],this.reader.setIndex(g.localHeaderOffset),this.checkSignature(r.LOCAL_FILE_HEADER),g.readLocalPart(this.reader),g.handleUTF8(),g.processAttributes()},readCentralDir:function(){var m;for(this.reader.setIndex(this.centralDirOffset);this.reader.readAndCheckSignature(r.CENTRAL_FILE_HEADER);)(m=new a({zip64:this.zip64},this.loadOptions)).readCentralPart(this.reader),this.files.push(m);if(this.centralDirRecords!==this.files.length&&this.centralDirRecords!==0&&this.files.length===0)throw new Error("Corrupted zip or bug: expected "+this.centralDirRecords+" records in central dir, got "+this.files.length)},readEndOfCentral:function(){var m=this.reader.lastIndexOfSignature(r.CENTRAL_DIRECTORY_END);if(m<0)throw this.isSignature(0,r.LOCAL_FILE_HEADER)?new Error("Corrupted zip: can't find end of central directory"):new Error("Can't find end of central directory : is this a zip file ? If it is, see https://stuk.github.io/jszip/documentation/howto/read_zip.html");this.reader.setIndex(m);var g=m;if(this.checkSignature(r.CENTRAL_DIRECTORY_END),this.readBlockEndOfCentral(),this.diskNumber===l.MAX_VALUE_16BITS||this.diskWithCentralDirStart===l.MAX_VALUE_16BITS||this.centralDirRecordsOnThisDisk===l.MAX_VALUE_16BITS||this.centralDirRecords===l.MAX_VALUE_16BITS||this.centralDirSize===l.MAX_VALUE_32BITS||this.centralDirOffset===l.MAX_VALUE_32BITS){if(this.zip64=!0,(m=this.reader.lastIndexOfSignature(r.ZIP64_CENTRAL_DIRECTORY_LOCATOR))<0)throw new Error("Corrupted zip: can't find the ZIP64 end of central directory locator");if(this.reader.setIndex(m),this.checkSignature(r.ZIP64_CENTRAL_DIRECTORY_LOCATOR),this.readBlockZip64EndOfCentralLocator(),!this.isSignature(this.relativeOffsetEndOfZip64CentralDir,r.ZIP64_CENTRAL_DIRECTORY_END)&&(this.relativeOffsetEndOfZip64CentralDir=this.reader.lastIndexOfSignature(r.ZIP64_CENTRAL_DIRECTORY_END),this.relativeOffsetEndOfZip64CentralDir<0))throw new Error("Corrupted zip: can't find the ZIP64 end of central directory");this.reader.setIndex(this.relativeOffsetEndOfZip64CentralDir),this.checkSignature(r.ZIP64_CENTRAL_DIRECTORY_END),this.readBlockZip64EndOfCentral()}var d=this.centralDirOffset+this.centralDirSize;this.zip64&&(d+=20,d+=12+this.zip64EndOfCentralSize);var b=g-d;if(0<b)this.isSignature(g,r.CENTRAL_FILE_HEADER)||(this.reader.zero=b);else if(b<0)throw new Error("Corrupted zip: missing "+Math.abs(b)+" bytes.")},prepareReader:function(m){this.reader=s(m)},load:function(m){this.prepareReader(m),this.readEndOfCentral(),this.readCentralDir(),this.readLocalFiles()}},n.exports=u},{"./reader/readerFor":22,"./signature":23,"./support":30,"./utils":32,"./zipEntry":34}],34:[function(i,n,o){var s=i("./reader/readerFor"),l=i("./utils"),r=i("./compressedObject"),a=i("./crc32"),c=i("./utf8"),u=i("./compressions"),m=i("./support");function g(d,b){this.options=d,this.loadOptions=b}g.prototype={isEncrypted:function(){return(1&this.bitFlag)==1},useUTF8:function(){return(2048&this.bitFlag)==2048},readLocalPart:function(d){var b,f;if(d.skip(22),this.fileNameLength=d.readInt(2),f=d.readInt(2),this.fileName=d.readData(this.fileNameLength),d.skip(f),this.compressedSize===-1||this.uncompressedSize===-1)throw new Error("Bug or corrupted zip : didn't get enough information from the central directory (compressedSize === -1 || uncompressedSize === -1)");if((b=(function(v){for(var k in u)if(Object.prototype.hasOwnProperty.call(u,k)&&u[k].magic===v)return u[k];return null})(this.compressionMethod))===null)throw new Error("Corrupted zip : compression "+l.pretty(this.compressionMethod)+" unknown (inner file : "+l.transformTo("string",this.fileName)+")");this.decompressed=new r(this.compressedSize,this.uncompressedSize,this.crc32,b,d.readData(this.compressedSize))},readCentralPart:function(d){this.versionMadeBy=d.readInt(2),d.skip(2),this.bitFlag=d.readInt(2),this.compressionMethod=d.readString(2),this.date=d.readDate(),this.crc32=d.readInt(4),this.compressedSize=d.readInt(4),this.uncompressedSize=d.readInt(4);var b=d.readInt(2);if(this.extraFieldsLength=d.readInt(2),this.fileCommentLength=d.readInt(2),this.diskNumberStart=d.readInt(2),this.internalFileAttributes=d.readInt(2),this.externalFileAttributes=d.readInt(4),this.localHeaderOffset=d.readInt(4),this.isEncrypted())throw new Error("Encrypted zip are not supported");d.skip(b),this.readExtraFields(d),this.parseZIP64ExtraField(d),this.fileComment=d.readData(this.fileCommentLength)},processAttributes:function(){this.unixPermissions=null,this.dosPermissions=null;var d=this.versionMadeBy>>8;this.dir=!!(16&this.externalFileAttributes),d==0&&(this.dosPermissions=63&this.externalFileAttributes),d==3&&(this.unixPermissions=this.externalFileAttributes>>16&65535),this.dir||this.fileNameStr.slice(-1)!=="/"||(this.dir=!0)},parseZIP64ExtraField:function(){if(this.extraFields[1]){var d=s(this.extraFields[1].value);this.uncompressedSize===l.MAX_VALUE_32BITS&&(this.uncompressedSize=d.readInt(8)),this.compressedSize===l.MAX_VALUE_32BITS&&(this.compressedSize=d.readInt(8)),this.localHeaderOffset===l.MAX_VALUE_32BITS&&(this.localHeaderOffset=d.readInt(8)),this.diskNumberStart===l.MAX_VALUE_32BITS&&(this.diskNumberStart=d.readInt(4))}},readExtraFields:function(d){var b,f,v,k=d.index+this.extraFieldsLength;for(this.extraFields||(this.extraFields={});d.index+4<k;)b=d.readInt(2),f=d.readInt(2),v=d.readData(f),this.extraFields[b]={id:b,length:f,value:v};d.setIndex(k)},handleUTF8:function(){var d=m.uint8array?"uint8array":"array";if(this.useUTF8())this.fileNameStr=c.utf8decode(this.fileName),this.fileCommentStr=c.utf8decode(this.fileComment);else{var b=this.findExtraFieldUnicodePath();if(b!==null)this.fileNameStr=b;else{var f=l.transformTo(d,this.fileName);this.fileNameStr=this.loadOptions.decodeFileName(f)}var v=this.findExtraFieldUnicodeComment();if(v!==null)this.fileCommentStr=v;else{var k=l.transformTo(d,this.fileComment);this.fileCommentStr=this.loadOptions.decodeFileName(k)}}},findExtraFieldUnicodePath:function(){var d=this.extraFields[28789];if(d){var b=s(d.value);return b.readInt(1)!==1||a(this.fileName)!==b.readInt(4)?null:c.utf8decode(b.readData(d.length-5))}return null},findExtraFieldUnicodeComment:function(){var d=this.extraFields[25461];if(d){var b=s(d.value);return b.readInt(1)!==1||a(this.fileComment)!==b.readInt(4)?null:c.utf8decode(b.readData(d.length-5))}return null}},n.exports=g},{"./compressedObject":2,"./compressions":3,"./crc32":4,"./reader/readerFor":22,"./support":30,"./utf8":31,"./utils":32}],35:[function(i,n,o){function s(b,f,v){this.name=b,this.dir=v.dir,this.date=v.date,this.comment=v.comment,this.unixPermissions=v.unixPermissions,this.dosPermissions=v.dosPermissions,this._data=f,this._dataBinary=v.binary,this.options={compression:v.compression,compressionOptions:v.compressionOptions}}var l=i("./stream/StreamHelper"),r=i("./stream/DataWorker"),a=i("./utf8"),c=i("./compressedObject"),u=i("./stream/GenericWorker");s.prototype={internalStream:function(b){var f=null,v="string";try{if(!b)throw new Error("No output type specified.");var k=(v=b.toLowerCase())==="string"||v==="text";v!=="binarystring"&&v!=="text"||(v="string"),f=this._decompressWorker();var S=!this._dataBinary;S&&!k&&(f=f.pipe(new a.Utf8EncodeWorker)),!S&&k&&(f=f.pipe(new a.Utf8DecodeWorker))}catch(x){(f=new u("error")).error(x)}return new l(f,v,"")},async:function(b,f){return this.internalStream(b).accumulate(f)},nodeStream:function(b,f){return this.internalStream(b||"nodebuffer").toNodejsStream(f)},_compressWorker:function(b,f){if(this._data instanceof c&&this._data.compression.magic===b.magic)return this._data.getCompressedWorker();var v=this._decompressWorker();return this._dataBinary||(v=v.pipe(new a.Utf8EncodeWorker)),c.createWorkerFrom(v,b,f)},_decompressWorker:function(){return this._data instanceof c?this._data.getContentWorker():this._data instanceof u?this._data:new r(this._data)}};for(var m=["asText","asBinary","asNodeBuffer","asUint8Array","asArrayBuffer"],g=function(){throw new Error("This method has been removed in JSZip 3.0, please check the upgrade guide.")},d=0;d<m.length;d++)s.prototype[m[d]]=g;n.exports=s},{"./compressedObject":2,"./stream/DataWorker":27,"./stream/GenericWorker":28,"./stream/StreamHelper":29,"./utf8":31}],36:[function(i,n,o){(function(s){var l,r,a=s.MutationObserver||s.WebKitMutationObserver;if(a){var c=0,u=new a(b),m=s.document.createTextNode("");u.observe(m,{characterData:!0}),l=function(){m.data=c=++c%2}}else if(s.setImmediate||s.MessageChannel===void 0)l="document"in s&&"onreadystatechange"in s.document.createElement("script")?function(){var f=s.document.createElement("script");f.onreadystatechange=function(){b(),f.onreadystatechange=null,f.parentNode.removeChild(f),f=null},s.document.documentElement.appendChild(f)}:function(){setTimeout(b,0)};else{var g=new s.MessageChannel;g.port1.onmessage=b,l=function(){g.port2.postMessage(0)}}var d=[];function b(){var f,v;r=!0;for(var k=d.length;k;){for(v=d,d=[],f=-1;++f<k;)v[f]();k=d.length}r=!1}n.exports=function(f){d.push(f)!==1||r||l()}}).call(this,typeof Zn<"u"?Zn:typeof self<"u"?self:typeof window<"u"?window:{})},{}],37:[function(i,n,o){var s=i("immediate");function l(){}var r={},a=["REJECTED"],c=["FULFILLED"],u=["PENDING"];function m(k){if(typeof k!="function")throw new TypeError("resolver must be a function");this.state=u,this.queue=[],this.outcome=void 0,k!==l&&f(this,k)}function g(k,S,x){this.promise=k,typeof S=="function"&&(this.onFulfilled=S,this.callFulfilled=this.otherCallFulfilled),typeof x=="function"&&(this.onRejected=x,this.callRejected=this.otherCallRejected)}function d(k,S,x){s(function(){var B;try{B=S(x)}catch(E){return r.reject(k,E)}B===k?r.reject(k,new TypeError("Cannot resolve promise with itself")):r.resolve(k,B)})}function b(k){var S=k&&k.then;if(k&&(typeof k=="object"||typeof k=="function")&&typeof S=="function")return function(){S.apply(k,arguments)}}function f(k,S){var x=!1;function B(w){x||(x=!0,r.reject(k,w))}function E(w){x||(x=!0,r.resolve(k,w))}var A=v(function(){S(E,B)});A.status==="error"&&B(A.value)}function v(k,S){var x={};try{x.value=k(S),x.status="success"}catch(B){x.status="error",x.value=B}return x}(n.exports=m).prototype.finally=function(k){if(typeof k!="function")return this;var S=this.constructor;return this.then(function(x){return S.resolve(k()).then(function(){return x})},function(x){return S.resolve(k()).then(function(){throw x})})},m.prototype.catch=function(k){return this.then(null,k)},m.prototype.then=function(k,S){if(typeof k!="function"&&this.state===c||typeof S!="function"&&this.state===a)return this;var x=new this.constructor(l);return this.state!==u?d(x,this.state===c?k:S,this.outcome):this.queue.push(new g(x,k,S)),x},g.prototype.callFulfilled=function(k){r.resolve(this.promise,k)},g.prototype.otherCallFulfilled=function(k){d(this.promise,this.onFulfilled,k)},g.prototype.callRejected=function(k){r.reject(this.promise,k)},g.prototype.otherCallRejected=function(k){d(this.promise,this.onRejected,k)},r.resolve=function(k,S){var x=v(b,S);if(x.status==="error")return r.reject(k,x.value);var B=x.value;if(B)f(k,B);else{k.state=c,k.outcome=S;for(var E=-1,A=k.queue.length;++E<A;)k.queue[E].callFulfilled(S)}return k},r.reject=function(k,S){k.state=a,k.outcome=S;for(var x=-1,B=k.queue.length;++x<B;)k.queue[x].callRejected(S);return k},m.resolve=function(k){return k instanceof this?k:r.resolve(new this(l),k)},m.reject=function(k){var S=new this(l);return r.reject(S,k)},m.all=function(k){var S=this;if(Object.prototype.toString.call(k)!=="[object Array]")return this.reject(new TypeError("must be an array"));var x=k.length,B=!1;if(!x)return this.resolve([]);for(var E=new Array(x),A=0,w=-1,F=new this(l);++w<x;)H(k[w],w);return F;function H(j,J){S.resolve(j).then(function(I){E[J]=I,++A!==x||B||(B=!0,r.resolve(F,E))},function(I){B||(B=!0,r.reject(F,I))})}},m.race=function(k){var S=this;if(Object.prototype.toString.call(k)!=="[object Array]")return this.reject(new TypeError("must be an array"));var x=k.length,B=!1;if(!x)return this.resolve([]);for(var E=-1,A=new this(l);++E<x;)w=k[E],S.resolve(w).then(function(F){B||(B=!0,r.resolve(A,F))},function(F){B||(B=!0,r.reject(A,F))});var w;return A}},{immediate:36}],38:[function(i,n,o){var s={};(0,i("./lib/utils/common").assign)(s,i("./lib/deflate"),i("./lib/inflate"),i("./lib/zlib/constants")),n.exports=s},{"./lib/deflate":39,"./lib/inflate":40,"./lib/utils/common":41,"./lib/zlib/constants":44}],39:[function(i,n,o){var s=i("./zlib/deflate"),l=i("./utils/common"),r=i("./utils/strings"),a=i("./zlib/messages"),c=i("./zlib/zstream"),u=Object.prototype.toString,m=0,g=-1,d=0,b=8;function f(k){if(!(this instanceof f))return new f(k);this.options=l.assign({level:g,method:b,chunkSize:16384,windowBits:15,memLevel:8,strategy:d,to:""},k||{});var S=this.options;S.raw&&0<S.windowBits?S.windowBits=-S.windowBits:S.gzip&&0<S.windowBits&&S.windowBits<16&&(S.windowBits+=16),this.err=0,this.msg="",this.ended=!1,this.chunks=[],this.strm=new c,this.strm.avail_out=0;var x=s.deflateInit2(this.strm,S.level,S.method,S.windowBits,S.memLevel,S.strategy);if(x!==m)throw new Error(a[x]);if(S.header&&s.deflateSetHeader(this.strm,S.header),S.dictionary){var B;if(B=typeof S.dictionary=="string"?r.string2buf(S.dictionary):u.call(S.dictionary)==="[object ArrayBuffer]"?new Uint8Array(S.dictionary):S.dictionary,(x=s.deflateSetDictionary(this.strm,B))!==m)throw new Error(a[x]);this._dict_set=!0}}function v(k,S){var x=new f(S);if(x.push(k,!0),x.err)throw x.msg||a[x.err];return x.result}f.prototype.push=function(k,S){var x,B,E=this.strm,A=this.options.chunkSize;if(this.ended)return!1;B=S===~~S?S:S===!0?4:0,typeof k=="string"?E.input=r.string2buf(k):u.call(k)==="[object ArrayBuffer]"?E.input=new Uint8Array(k):E.input=k,E.next_in=0,E.avail_in=E.input.length;do{if(E.avail_out===0&&(E.output=new l.Buf8(A),E.next_out=0,E.avail_out=A),(x=s.deflate(E,B))!==1&&x!==m)return this.onEnd(x),!(this.ended=!0);E.avail_out!==0&&(E.avail_in!==0||B!==4&&B!==2)||(this.options.to==="string"?this.onData(r.buf2binstring(l.shrinkBuf(E.output,E.next_out))):this.onData(l.shrinkBuf(E.output,E.next_out)))}while((0<E.avail_in||E.avail_out===0)&&x!==1);return B===4?(x=s.deflateEnd(this.strm),this.onEnd(x),this.ended=!0,x===m):B!==2||(this.onEnd(m),!(E.avail_out=0))},f.prototype.onData=function(k){this.chunks.push(k)},f.prototype.onEnd=function(k){k===m&&(this.options.to==="string"?this.result=this.chunks.join(""):this.result=l.flattenChunks(this.chunks)),this.chunks=[],this.err=k,this.msg=this.strm.msg},o.Deflate=f,o.deflate=v,o.deflateRaw=function(k,S){return(S=S||{}).raw=!0,v(k,S)},o.gzip=function(k,S){return(S=S||{}).gzip=!0,v(k,S)}},{"./utils/common":41,"./utils/strings":42,"./zlib/deflate":46,"./zlib/messages":51,"./zlib/zstream":53}],40:[function(i,n,o){var s=i("./zlib/inflate"),l=i("./utils/common"),r=i("./utils/strings"),a=i("./zlib/constants"),c=i("./zlib/messages"),u=i("./zlib/zstream"),m=i("./zlib/gzheader"),g=Object.prototype.toString;function d(f){if(!(this instanceof d))return new d(f);this.options=l.assign({chunkSize:16384,windowBits:0,to:""},f||{});var v=this.options;v.raw&&0<=v.windowBits&&v.windowBits<16&&(v.windowBits=-v.windowBits,v.windowBits===0&&(v.windowBits=-15)),!(0<=v.windowBits&&v.windowBits<16)||f&&f.windowBits||(v.windowBits+=32),15<v.windowBits&&v.windowBits<48&&(15&v.windowBits)==0&&(v.windowBits|=15),this.err=0,this.msg="",this.ended=!1,this.chunks=[],this.strm=new u,this.strm.avail_out=0;var k=s.inflateInit2(this.strm,v.windowBits);if(k!==a.Z_OK)throw new Error(c[k]);this.header=new m,s.inflateGetHeader(this.strm,this.header)}function b(f,v){var k=new d(v);if(k.push(f,!0),k.err)throw k.msg||c[k.err];return k.result}d.prototype.push=function(f,v){var k,S,x,B,E,A,w=this.strm,F=this.options.chunkSize,H=this.options.dictionary,j=!1;if(this.ended)return!1;S=v===~~v?v:v===!0?a.Z_FINISH:a.Z_NO_FLUSH,typeof f=="string"?w.input=r.binstring2buf(f):g.call(f)==="[object ArrayBuffer]"?w.input=new Uint8Array(f):w.input=f,w.next_in=0,w.avail_in=w.input.length;do{if(w.avail_out===0&&(w.output=new l.Buf8(F),w.next_out=0,w.avail_out=F),(k=s.inflate(w,a.Z_NO_FLUSH))===a.Z_NEED_DICT&&H&&(A=typeof H=="string"?r.string2buf(H):g.call(H)==="[object ArrayBuffer]"?new Uint8Array(H):H,k=s.inflateSetDictionary(this.strm,A)),k===a.Z_BUF_ERROR&&j===!0&&(k=a.Z_OK,j=!1),k!==a.Z_STREAM_END&&k!==a.Z_OK)return this.onEnd(k),!(this.ended=!0);w.next_out&&(w.avail_out!==0&&k!==a.Z_STREAM_END&&(w.avail_in!==0||S!==a.Z_FINISH&&S!==a.Z_SYNC_FLUSH)||(this.options.to==="string"?(x=r.utf8border(w.output,w.next_out),B=w.next_out-x,E=r.buf2string(w.output,x),w.next_out=B,w.avail_out=F-B,B&&l.arraySet(w.output,w.output,x,B,0),this.onData(E)):this.onData(l.shrinkBuf(w.output,w.next_out)))),w.avail_in===0&&w.avail_out===0&&(j=!0)}while((0<w.avail_in||w.avail_out===0)&&k!==a.Z_STREAM_END);return k===a.Z_STREAM_END&&(S=a.Z_FINISH),S===a.Z_FINISH?(k=s.inflateEnd(this.strm),this.onEnd(k),this.ended=!0,k===a.Z_OK):S!==a.Z_SYNC_FLUSH||(this.onEnd(a.Z_OK),!(w.avail_out=0))},d.prototype.onData=function(f){this.chunks.push(f)},d.prototype.onEnd=function(f){f===a.Z_OK&&(this.options.to==="string"?this.result=this.chunks.join(""):this.result=l.flattenChunks(this.chunks)),this.chunks=[],this.err=f,this.msg=this.strm.msg},o.Inflate=d,o.inflate=b,o.inflateRaw=function(f,v){return(v=v||{}).raw=!0,b(f,v)},o.ungzip=b},{"./utils/common":41,"./utils/strings":42,"./zlib/constants":44,"./zlib/gzheader":47,"./zlib/inflate":49,"./zlib/messages":51,"./zlib/zstream":53}],41:[function(i,n,o){var s=typeof Uint8Array<"u"&&typeof Uint16Array<"u"&&typeof Int32Array<"u";o.assign=function(a){for(var c=Array.prototype.slice.call(arguments,1);c.length;){var u=c.shift();if(u){if(typeof u!="object")throw new TypeError(u+"must be non-object");for(var m in u)u.hasOwnProperty(m)&&(a[m]=u[m])}}return a},o.shrinkBuf=function(a,c){return a.length===c?a:a.subarray?a.subarray(0,c):(a.length=c,a)};var l={arraySet:function(a,c,u,m,g){if(c.subarray&&a.subarray)a.set(c.subarray(u,u+m),g);else for(var d=0;d<m;d++)a[g+d]=c[u+d]},flattenChunks:function(a){var c,u,m,g,d,b;for(c=m=0,u=a.length;c<u;c++)m+=a[c].length;for(b=new Uint8Array(m),c=g=0,u=a.length;c<u;c++)d=a[c],b.set(d,g),g+=d.length;return b}},r={arraySet:function(a,c,u,m,g){for(var d=0;d<m;d++)a[g+d]=c[u+d]},flattenChunks:function(a){return[].concat.apply([],a)}};o.setTyped=function(a){a?(o.Buf8=Uint8Array,o.Buf16=Uint16Array,o.Buf32=Int32Array,o.assign(o,l)):(o.Buf8=Array,o.Buf16=Array,o.Buf32=Array,o.assign(o,r))},o.setTyped(s)},{}],42:[function(i,n,o){var s=i("./common"),l=!0,r=!0;try{String.fromCharCode.apply(null,[0])}catch{l=!1}try{String.fromCharCode.apply(null,new Uint8Array(1))}catch{r=!1}for(var a=new s.Buf8(256),c=0;c<256;c++)a[c]=252<=c?6:248<=c?5:240<=c?4:224<=c?3:192<=c?2:1;function u(m,g){if(g<65537&&(m.subarray&&r||!m.subarray&&l))return String.fromCharCode.apply(null,s.shrinkBuf(m,g));for(var d="",b=0;b<g;b++)d+=String.fromCharCode(m[b]);return d}a[254]=a[254]=1,o.string2buf=function(m){var g,d,b,f,v,k=m.length,S=0;for(f=0;f<k;f++)(64512&(d=m.charCodeAt(f)))==55296&&f+1<k&&(64512&(b=m.charCodeAt(f+1)))==56320&&(d=65536+(d-55296<<10)+(b-56320),f++),S+=d<128?1:d<2048?2:d<65536?3:4;for(g=new s.Buf8(S),f=v=0;v<S;f++)(64512&(d=m.charCodeAt(f)))==55296&&f+1<k&&(64512&(b=m.charCodeAt(f+1)))==56320&&(d=65536+(d-55296<<10)+(b-56320),f++),d<128?g[v++]=d:(d<2048?g[v++]=192|d>>>6:(d<65536?g[v++]=224|d>>>12:(g[v++]=240|d>>>18,g[v++]=128|d>>>12&63),g[v++]=128|d>>>6&63),g[v++]=128|63&d);return g},o.buf2binstring=function(m){return u(m,m.length)},o.binstring2buf=function(m){for(var g=new s.Buf8(m.length),d=0,b=g.length;d<b;d++)g[d]=m.charCodeAt(d);return g},o.buf2string=function(m,g){var d,b,f,v,k=g||m.length,S=new Array(2*k);for(d=b=0;d<k;)if((f=m[d++])<128)S[b++]=f;else if(4<(v=a[f]))S[b++]=65533,d+=v-1;else{for(f&=v===2?31:v===3?15:7;1<v&&d<k;)f=f<<6|63&m[d++],v--;1<v?S[b++]=65533:f<65536?S[b++]=f:(f-=65536,S[b++]=55296|f>>10&1023,S[b++]=56320|1023&f)}return u(S,b)},o.utf8border=function(m,g){var d;for((g=g||m.length)>m.length&&(g=m.length),d=g-1;0<=d&&(192&m[d])==128;)d--;return d<0||d===0?g:d+a[m[d]]>g?d:g}},{"./common":41}],43:[function(i,n,o){n.exports=function(s,l,r,a){for(var c=65535&s|0,u=s>>>16&65535|0,m=0;r!==0;){for(r-=m=2e3<r?2e3:r;u=u+(c=c+l[a++]|0)|0,--m;);c%=65521,u%=65521}return c|u<<16|0}},{}],44:[function(i,n,o){n.exports={Z_NO_FLUSH:0,Z_PARTIAL_FLUSH:1,Z_SYNC_FLUSH:2,Z_FULL_FLUSH:3,Z_FINISH:4,Z_BLOCK:5,Z_TREES:6,Z_OK:0,Z_STREAM_END:1,Z_NEED_DICT:2,Z_ERRNO:-1,Z_STREAM_ERROR:-2,Z_DATA_ERROR:-3,Z_BUF_ERROR:-5,Z_NO_COMPRESSION:0,Z_BEST_SPEED:1,Z_BEST_COMPRESSION:9,Z_DEFAULT_COMPRESSION:-1,Z_FILTERED:1,Z_HUFFMAN_ONLY:2,Z_RLE:3,Z_FIXED:4,Z_DEFAULT_STRATEGY:0,Z_BINARY:0,Z_TEXT:1,Z_UNKNOWN:2,Z_DEFLATED:8}},{}],45:[function(i,n,o){var s=(function(){for(var l,r=[],a=0;a<256;a++){l=a;for(var c=0;c<8;c++)l=1&l?3988292384^l>>>1:l>>>1;r[a]=l}return r})();n.exports=function(l,r,a,c){var u=s,m=c+a;l^=-1;for(var g=c;g<m;g++)l=l>>>8^u[255&(l^r[g])];return-1^l}},{}],46:[function(i,n,o){var s,l=i("../utils/common"),r=i("./trees"),a=i("./adler32"),c=i("./crc32"),u=i("./messages"),m=0,g=4,d=0,b=-2,f=-1,v=4,k=2,S=8,x=9,B=286,E=30,A=19,w=2*B+1,F=15,H=3,j=258,J=j+H+1,I=42,N=113,y=1,V=2,X=3,R=4;function U(p,O){return p.msg=u[O],O}function W(p){return(p<<1)-(4<p?9:0)}function tt(p){for(var O=p.length;0<=--O;)p[O]=0}function T(p){var O=p.state,z=O.pending;z>p.avail_out&&(z=p.avail_out),z!==0&&(l.arraySet(p.output,O.pending_buf,O.pending_out,z,p.next_out),p.next_out+=z,O.pending_out+=z,p.total_out+=z,p.avail_out-=z,O.pending-=z,O.pending===0&&(O.pending_out=0))}function M(p,O){r._tr_flush_block(p,0<=p.block_start?p.block_start:-1,p.strstart-p.block_start,O),p.block_start=p.strstart,T(p.strm)}function Y(p,O){p.pending_buf[p.pending++]=O}function Z(p,O){p.pending_buf[p.pending++]=O>>>8&255,p.pending_buf[p.pending++]=255&O}function Q(p,O){var z,_,$=p.max_chain_length,L=p.strstart,G=p.prev_length,K=p.nice_match,q=p.strstart>p.w_size-J?p.strstart-(p.w_size-J):0,et=p.window,at=p.w_mask,lt=p.prev,pt=p.strstart+j,wt=et[L+G-1],kt=et[L+G];p.prev_length>=p.good_match&&($>>=2),K>p.lookahead&&(K=p.lookahead);do if(et[(z=O)+G]===kt&&et[z+G-1]===wt&&et[z]===et[L]&&et[++z]===et[L+1]){L+=2,z++;do;while(et[++L]===et[++z]&&et[++L]===et[++z]&&et[++L]===et[++z]&&et[++L]===et[++z]&&et[++L]===et[++z]&&et[++L]===et[++z]&&et[++L]===et[++z]&&et[++L]===et[++z]&&L<pt);if(_=j-(pt-L),L=pt-j,G<_){if(p.match_start=O,K<=(G=_))break;wt=et[L+G-1],kt=et[L+G]}}while((O=lt[O&at])>q&&--$!=0);return G<=p.lookahead?G:p.lookahead}function P(p){var O,z,_,$,L,G,K,q,et,at,lt=p.w_size;do{if($=p.window_size-p.lookahead-p.strstart,p.strstart>=lt+(lt-J)){for(l.arraySet(p.window,p.window,lt,lt,0),p.match_start-=lt,p.strstart-=lt,p.block_start-=lt,O=z=p.hash_size;_=p.head[--O],p.head[O]=lt<=_?_-lt:0,--z;);for(O=z=lt;_=p.prev[--O],p.prev[O]=lt<=_?_-lt:0,--z;);$+=lt}if(p.strm.avail_in===0)break;if(G=p.strm,K=p.window,q=p.strstart+p.lookahead,et=$,at=void 0,at=G.avail_in,et<at&&(at=et),z=at===0?0:(G.avail_in-=at,l.arraySet(K,G.input,G.next_in,at,q),G.state.wrap===1?G.adler=a(G.adler,K,at,q):G.state.wrap===2&&(G.adler=c(G.adler,K,at,q)),G.next_in+=at,G.total_in+=at,at),p.lookahead+=z,p.lookahead+p.insert>=H)for(L=p.strstart-p.insert,p.ins_h=p.window[L],p.ins_h=(p.ins_h<<p.hash_shift^p.window[L+1])&p.hash_mask;p.insert&&(p.ins_h=(p.ins_h<<p.hash_shift^p.window[L+H-1])&p.hash_mask,p.prev[L&p.w_mask]=p.head[p.ins_h],p.head[p.ins_h]=L,L++,p.insert--,!(p.lookahead+p.insert<H)););}while(p.lookahead<J&&p.strm.avail_in!==0)}function ct(p,O){for(var z,_;;){if(p.lookahead<J){if(P(p),p.lookahead<J&&O===m)return y;if(p.lookahead===0)break}if(z=0,p.lookahead>=H&&(p.ins_h=(p.ins_h<<p.hash_shift^p.window[p.strstart+H-1])&p.hash_mask,z=p.prev[p.strstart&p.w_mask]=p.head[p.ins_h],p.head[p.ins_h]=p.strstart),z!==0&&p.strstart-z<=p.w_size-J&&(p.match_length=Q(p,z)),p.match_length>=H)if(_=r._tr_tally(p,p.strstart-p.match_start,p.match_length-H),p.lookahead-=p.match_length,p.match_length<=p.max_lazy_match&&p.lookahead>=H){for(p.match_length--;p.strstart++,p.ins_h=(p.ins_h<<p.hash_shift^p.window[p.strstart+H-1])&p.hash_mask,z=p.prev[p.strstart&p.w_mask]=p.head[p.ins_h],p.head[p.ins_h]=p.strstart,--p.match_length!=0;);p.strstart++}else p.strstart+=p.match_length,p.match_length=0,p.ins_h=p.window[p.strstart],p.ins_h=(p.ins_h<<p.hash_shift^p.window[p.strstart+1])&p.hash_mask;else _=r._tr_tally(p,0,p.window[p.strstart]),p.lookahead--,p.strstart++;if(_&&(M(p,!1),p.strm.avail_out===0))return y}return p.insert=p.strstart<H-1?p.strstart:H-1,O===g?(M(p,!0),p.strm.avail_out===0?X:R):p.last_lit&&(M(p,!1),p.strm.avail_out===0)?y:V}function rt(p,O){for(var z,_,$;;){if(p.lookahead<J){if(P(p),p.lookahead<J&&O===m)return y;if(p.lookahead===0)break}if(z=0,p.lookahead>=H&&(p.ins_h=(p.ins_h<<p.hash_shift^p.window[p.strstart+H-1])&p.hash_mask,z=p.prev[p.strstart&p.w_mask]=p.head[p.ins_h],p.head[p.ins_h]=p.strstart),p.prev_length=p.match_length,p.prev_match=p.match_start,p.match_length=H-1,z!==0&&p.prev_length<p.max_lazy_match&&p.strstart-z<=p.w_size-J&&(p.match_length=Q(p,z),p.match_length<=5&&(p.strategy===1||p.match_length===H&&4096<p.strstart-p.match_start)&&(p.match_length=H-1)),p.prev_length>=H&&p.match_length<=p.prev_length){for($=p.strstart+p.lookahead-H,_=r._tr_tally(p,p.strstart-1-p.prev_match,p.prev_length-H),p.lookahead-=p.prev_length-1,p.prev_length-=2;++p.strstart<=$&&(p.ins_h=(p.ins_h<<p.hash_shift^p.window[p.strstart+H-1])&p.hash_mask,z=p.prev[p.strstart&p.w_mask]=p.head[p.ins_h],p.head[p.ins_h]=p.strstart),--p.prev_length!=0;);if(p.match_available=0,p.match_length=H-1,p.strstart++,_&&(M(p,!1),p.strm.avail_out===0))return y}else if(p.match_available){if((_=r._tr_tally(p,0,p.window[p.strstart-1]))&&M(p,!1),p.strstart++,p.lookahead--,p.strm.avail_out===0)return y}else p.match_available=1,p.strstart++,p.lookahead--}return p.match_available&&(_=r._tr_tally(p,0,p.window[p.strstart-1]),p.match_available=0),p.insert=p.strstart<H-1?p.strstart:H-1,O===g?(M(p,!0),p.strm.avail_out===0?X:R):p.last_lit&&(M(p,!1),p.strm.avail_out===0)?y:V}function st(p,O,z,_,$){this.good_length=p,this.max_lazy=O,this.nice_length=z,this.max_chain=_,this.func=$}function gt(){this.strm=null,this.status=0,this.pending_buf=null,this.pending_buf_size=0,this.pending_out=0,this.pending=0,this.wrap=0,this.gzhead=null,this.gzindex=0,this.method=S,this.last_flush=-1,this.w_size=0,this.w_bits=0,this.w_mask=0,this.window=null,this.window_size=0,this.prev=null,this.head=null,this.ins_h=0,this.hash_size=0,this.hash_bits=0,this.hash_mask=0,this.hash_shift=0,this.block_start=0,this.match_length=0,this.prev_match=0,this.match_available=0,this.strstart=0,this.match_start=0,this.lookahead=0,this.prev_length=0,this.max_chain_length=0,this.max_lazy_match=0,this.level=0,this.strategy=0,this.good_match=0,this.nice_match=0,this.dyn_ltree=new l.Buf16(2*w),this.dyn_dtree=new l.Buf16(2*(2*E+1)),this.bl_tree=new l.Buf16(2*(2*A+1)),tt(this.dyn_ltree),tt(this.dyn_dtree),tt(this.bl_tree),this.l_desc=null,this.d_desc=null,this.bl_desc=null,this.bl_count=new l.Buf16(F+1),this.heap=new l.Buf16(2*B+1),tt(this.heap),this.heap_len=0,this.heap_max=0,this.depth=new l.Buf16(2*B+1),tt(this.depth),this.l_buf=0,this.lit_bufsize=0,this.last_lit=0,this.d_buf=0,this.opt_len=0,this.static_len=0,this.matches=0,this.insert=0,this.bi_buf=0,this.bi_valid=0}function mt(p){var O;return p&&p.state?(p.total_in=p.total_out=0,p.data_type=k,(O=p.state).pending=0,O.pending_out=0,O.wrap<0&&(O.wrap=-O.wrap),O.status=O.wrap?I:N,p.adler=O.wrap===2?0:1,O.last_flush=m,r._tr_init(O),d):U(p,b)}function C(p){var O=mt(p);return O===d&&(function(z){z.window_size=2*z.w_size,tt(z.head),z.max_lazy_match=s[z.level].max_lazy,z.good_match=s[z.level].good_length,z.nice_match=s[z.level].nice_length,z.max_chain_length=s[z.level].max_chain,z.strstart=0,z.block_start=0,z.lookahead=0,z.insert=0,z.match_length=z.prev_length=H-1,z.match_available=0,z.ins_h=0})(p.state),O}function D(p,O,z,_,$,L){if(!p)return b;var G=1;if(O===f&&(O=6),_<0?(G=0,_=-_):15<_&&(G=2,_-=16),$<1||x<$||z!==S||_<8||15<_||O<0||9<O||L<0||v<L)return U(p,b);_===8&&(_=9);var K=new gt;return(p.state=K).strm=p,K.wrap=G,K.gzhead=null,K.w_bits=_,K.w_size=1<<K.w_bits,K.w_mask=K.w_size-1,K.hash_bits=$+7,K.hash_size=1<<K.hash_bits,K.hash_mask=K.hash_size-1,K.hash_shift=~~((K.hash_bits+H-1)/H),K.window=new l.Buf8(2*K.w_size),K.head=new l.Buf16(K.hash_size),K.prev=new l.Buf16(K.w_size),K.lit_bufsize=1<<$+6,K.pending_buf_size=4*K.lit_bufsize,K.pending_buf=new l.Buf8(K.pending_buf_size),K.d_buf=1*K.lit_bufsize,K.l_buf=3*K.lit_bufsize,K.level=O,K.strategy=L,K.method=z,C(p)}s=[new st(0,0,0,0,function(p,O){var z=65535;for(z>p.pending_buf_size-5&&(z=p.pending_buf_size-5);;){if(p.lookahead<=1){if(P(p),p.lookahead===0&&O===m)return y;if(p.lookahead===0)break}p.strstart+=p.lookahead,p.lookahead=0;var _=p.block_start+z;if((p.strstart===0||p.strstart>=_)&&(p.lookahead=p.strstart-_,p.strstart=_,M(p,!1),p.strm.avail_out===0)||p.strstart-p.block_start>=p.w_size-J&&(M(p,!1),p.strm.avail_out===0))return y}return p.insert=0,O===g?(M(p,!0),p.strm.avail_out===0?X:R):(p.strstart>p.block_start&&(M(p,!1),p.strm.avail_out),y)}),new st(4,4,8,4,ct),new st(4,5,16,8,ct),new st(4,6,32,32,ct),new st(4,4,16,16,rt),new st(8,16,32,32,rt),new st(8,16,128,128,rt),new st(8,32,128,256,rt),new st(32,128,258,1024,rt),new st(32,258,258,4096,rt)],o.deflateInit=function(p,O){return D(p,O,S,15,8,0)},o.deflateInit2=D,o.deflateReset=C,o.deflateResetKeep=mt,o.deflateSetHeader=function(p,O){return p&&p.state?p.state.wrap!==2?b:(p.state.gzhead=O,d):b},o.deflate=function(p,O){var z,_,$,L;if(!p||!p.state||5<O||O<0)return p?U(p,b):b;if(_=p.state,!p.output||!p.input&&p.avail_in!==0||_.status===666&&O!==g)return U(p,p.avail_out===0?-5:b);if(_.strm=p,z=_.last_flush,_.last_flush=O,_.status===I)if(_.wrap===2)p.adler=0,Y(_,31),Y(_,139),Y(_,8),_.gzhead?(Y(_,(_.gzhead.text?1:0)+(_.gzhead.hcrc?2:0)+(_.gzhead.extra?4:0)+(_.gzhead.name?8:0)+(_.gzhead.comment?16:0)),Y(_,255&_.gzhead.time),Y(_,_.gzhead.time>>8&255),Y(_,_.gzhead.time>>16&255),Y(_,_.gzhead.time>>24&255),Y(_,_.level===9?2:2<=_.strategy||_.level<2?4:0),Y(_,255&_.gzhead.os),_.gzhead.extra&&_.gzhead.extra.length&&(Y(_,255&_.gzhead.extra.length),Y(_,_.gzhead.extra.length>>8&255)),_.gzhead.hcrc&&(p.adler=c(p.adler,_.pending_buf,_.pending,0)),_.gzindex=0,_.status=69):(Y(_,0),Y(_,0),Y(_,0),Y(_,0),Y(_,0),Y(_,_.level===9?2:2<=_.strategy||_.level<2?4:0),Y(_,3),_.status=N);else{var G=S+(_.w_bits-8<<4)<<8;G|=(2<=_.strategy||_.level<2?0:_.level<6?1:_.level===6?2:3)<<6,_.strstart!==0&&(G|=32),G+=31-G%31,_.status=N,Z(_,G),_.strstart!==0&&(Z(_,p.adler>>>16),Z(_,65535&p.adler)),p.adler=1}if(_.status===69)if(_.gzhead.extra){for($=_.pending;_.gzindex<(65535&_.gzhead.extra.length)&&(_.pending!==_.pending_buf_size||(_.gzhead.hcrc&&_.pending>$&&(p.adler=c(p.adler,_.pending_buf,_.pending-$,$)),T(p),$=_.pending,_.pending!==_.pending_buf_size));)Y(_,255&_.gzhead.extra[_.gzindex]),_.gzindex++;_.gzhead.hcrc&&_.pending>$&&(p.adler=c(p.adler,_.pending_buf,_.pending-$,$)),_.gzindex===_.gzhead.extra.length&&(_.gzindex=0,_.status=73)}else _.status=73;if(_.status===73)if(_.gzhead.name){$=_.pending;do{if(_.pending===_.pending_buf_size&&(_.gzhead.hcrc&&_.pending>$&&(p.adler=c(p.adler,_.pending_buf,_.pending-$,$)),T(p),$=_.pending,_.pending===_.pending_buf_size)){L=1;break}L=_.gzindex<_.gzhead.name.length?255&_.gzhead.name.charCodeAt(_.gzindex++):0,Y(_,L)}while(L!==0);_.gzhead.hcrc&&_.pending>$&&(p.adler=c(p.adler,_.pending_buf,_.pending-$,$)),L===0&&(_.gzindex=0,_.status=91)}else _.status=91;if(_.status===91)if(_.gzhead.comment){$=_.pending;do{if(_.pending===_.pending_buf_size&&(_.gzhead.hcrc&&_.pending>$&&(p.adler=c(p.adler,_.pending_buf,_.pending-$,$)),T(p),$=_.pending,_.pending===_.pending_buf_size)){L=1;break}L=_.gzindex<_.gzhead.comment.length?255&_.gzhead.comment.charCodeAt(_.gzindex++):0,Y(_,L)}while(L!==0);_.gzhead.hcrc&&_.pending>$&&(p.adler=c(p.adler,_.pending_buf,_.pending-$,$)),L===0&&(_.status=103)}else _.status=103;if(_.status===103&&(_.gzhead.hcrc?(_.pending+2>_.pending_buf_size&&T(p),_.pending+2<=_.pending_buf_size&&(Y(_,255&p.adler),Y(_,p.adler>>8&255),p.adler=0,_.status=N)):_.status=N),_.pending!==0){if(T(p),p.avail_out===0)return _.last_flush=-1,d}else if(p.avail_in===0&&W(O)<=W(z)&&O!==g)return U(p,-5);if(_.status===666&&p.avail_in!==0)return U(p,-5);if(p.avail_in!==0||_.lookahead!==0||O!==m&&_.status!==666){var K=_.strategy===2?(function(q,et){for(var at;;){if(q.lookahead===0&&(P(q),q.lookahead===0)){if(et===m)return y;break}if(q.match_length=0,at=r._tr_tally(q,0,q.window[q.strstart]),q.lookahead--,q.strstart++,at&&(M(q,!1),q.strm.avail_out===0))return y}return q.insert=0,et===g?(M(q,!0),q.strm.avail_out===0?X:R):q.last_lit&&(M(q,!1),q.strm.avail_out===0)?y:V})(_,O):_.strategy===3?(function(q,et){for(var at,lt,pt,wt,kt=q.window;;){if(q.lookahead<=j){if(P(q),q.lookahead<=j&&et===m)return y;if(q.lookahead===0)break}if(q.match_length=0,q.lookahead>=H&&0<q.strstart&&(lt=kt[pt=q.strstart-1])===kt[++pt]&&lt===kt[++pt]&&lt===kt[++pt]){wt=q.strstart+j;do;while(lt===kt[++pt]&&lt===kt[++pt]&&lt===kt[++pt]&&lt===kt[++pt]&&lt===kt[++pt]&&lt===kt[++pt]&&lt===kt[++pt]&&lt===kt[++pt]&&pt<wt);q.match_length=j-(wt-pt),q.match_length>q.lookahead&&(q.match_length=q.lookahead)}if(q.match_length>=H?(at=r._tr_tally(q,1,q.match_length-H),q.lookahead-=q.match_length,q.strstart+=q.match_length,q.match_length=0):(at=r._tr_tally(q,0,q.window[q.strstart]),q.lookahead--,q.strstart++),at&&(M(q,!1),q.strm.avail_out===0))return y}return q.insert=0,et===g?(M(q,!0),q.strm.avail_out===0?X:R):q.last_lit&&(M(q,!1),q.strm.avail_out===0)?y:V})(_,O):s[_.level].func(_,O);if(K!==X&&K!==R||(_.status=666),K===y||K===X)return p.avail_out===0&&(_.last_flush=-1),d;if(K===V&&(O===1?r._tr_align(_):O!==5&&(r._tr_stored_block(_,0,0,!1),O===3&&(tt(_.head),_.lookahead===0&&(_.strstart=0,_.block_start=0,_.insert=0))),T(p),p.avail_out===0))return _.last_flush=-1,d}return O!==g?d:_.wrap<=0?1:(_.wrap===2?(Y(_,255&p.adler),Y(_,p.adler>>8&255),Y(_,p.adler>>16&255),Y(_,p.adler>>24&255),Y(_,255&p.total_in),Y(_,p.total_in>>8&255),Y(_,p.total_in>>16&255),Y(_,p.total_in>>24&255)):(Z(_,p.adler>>>16),Z(_,65535&p.adler)),T(p),0<_.wrap&&(_.wrap=-_.wrap),_.pending!==0?d:1)},o.deflateEnd=function(p){var O;return p&&p.state?(O=p.state.status)!==I&&O!==69&&O!==73&&O!==91&&O!==103&&O!==N&&O!==666?U(p,b):(p.state=null,O===N?U(p,-3):d):b},o.deflateSetDictionary=function(p,O){var z,_,$,L,G,K,q,et,at=O.length;if(!p||!p.state||(L=(z=p.state).wrap)===2||L===1&&z.status!==I||z.lookahead)return b;for(L===1&&(p.adler=a(p.adler,O,at,0)),z.wrap=0,at>=z.w_size&&(L===0&&(tt(z.head),z.strstart=0,z.block_start=0,z.insert=0),et=new l.Buf8(z.w_size),l.arraySet(et,O,at-z.w_size,z.w_size,0),O=et,at=z.w_size),G=p.avail_in,K=p.next_in,q=p.input,p.avail_in=at,p.next_in=0,p.input=O,P(z);z.lookahead>=H;){for(_=z.strstart,$=z.lookahead-(H-1);z.ins_h=(z.ins_h<<z.hash_shift^z.window[_+H-1])&z.hash_mask,z.prev[_&z.w_mask]=z.head[z.ins_h],z.head[z.ins_h]=_,_++,--$;);z.strstart=_,z.lookahead=H-1,P(z)}return z.strstart+=z.lookahead,z.block_start=z.strstart,z.insert=z.lookahead,z.lookahead=0,z.match_length=z.prev_length=H-1,z.match_available=0,p.next_in=K,p.input=q,p.avail_in=G,z.wrap=L,d},o.deflateInfo="pako deflate (from Nodeca project)"},{"../utils/common":41,"./adler32":43,"./crc32":45,"./messages":51,"./trees":52}],47:[function(i,n,o){n.exports=function(){this.text=0,this.time=0,this.xflags=0,this.os=0,this.extra=null,this.extra_len=0,this.name="",this.comment="",this.hcrc=0,this.done=!1}},{}],48:[function(i,n,o){n.exports=function(s,l){var r,a,c,u,m,g,d,b,f,v,k,S,x,B,E,A,w,F,H,j,J,I,N,y,V;r=s.state,a=s.next_in,y=s.input,c=a+(s.avail_in-5),u=s.next_out,V=s.output,m=u-(l-s.avail_out),g=u+(s.avail_out-257),d=r.dmax,b=r.wsize,f=r.whave,v=r.wnext,k=r.window,S=r.hold,x=r.bits,B=r.lencode,E=r.distcode,A=(1<<r.lenbits)-1,w=(1<<r.distbits)-1;t:do{x<15&&(S+=y[a++]<<x,x+=8,S+=y[a++]<<x,x+=8),F=B[S&A];e:for(;;){if(S>>>=H=F>>>24,x-=H,(H=F>>>16&255)===0)V[u++]=65535&F;else{if(!(16&H)){if((64&H)==0){F=B[(65535&F)+(S&(1<<H)-1)];continue e}if(32&H){r.mode=12;break t}s.msg="invalid literal/length code",r.mode=30;break t}j=65535&F,(H&=15)&&(x<H&&(S+=y[a++]<<x,x+=8),j+=S&(1<<H)-1,S>>>=H,x-=H),x<15&&(S+=y[a++]<<x,x+=8,S+=y[a++]<<x,x+=8),F=E[S&w];i:for(;;){if(S>>>=H=F>>>24,x-=H,!(16&(H=F>>>16&255))){if((64&H)==0){F=E[(65535&F)+(S&(1<<H)-1)];continue i}s.msg="invalid distance code",r.mode=30;break t}if(J=65535&F,x<(H&=15)&&(S+=y[a++]<<x,(x+=8)<H&&(S+=y[a++]<<x,x+=8)),d<(J+=S&(1<<H)-1)){s.msg="invalid distance too far back",r.mode=30;break t}if(S>>>=H,x-=H,(H=u-m)<J){if(f<(H=J-H)&&r.sane){s.msg="invalid distance too far back",r.mode=30;break t}if(N=k,(I=0)===v){if(I+=b-H,H<j){for(j-=H;V[u++]=k[I++],--H;);I=u-J,N=V}}else if(v<H){if(I+=b+v-H,(H-=v)<j){for(j-=H;V[u++]=k[I++],--H;);if(I=0,v<j){for(j-=H=v;V[u++]=k[I++],--H;);I=u-J,N=V}}}else if(I+=v-H,H<j){for(j-=H;V[u++]=k[I++],--H;);I=u-J,N=V}for(;2<j;)V[u++]=N[I++],V[u++]=N[I++],V[u++]=N[I++],j-=3;j&&(V[u++]=N[I++],1<j&&(V[u++]=N[I++]))}else{for(I=u-J;V[u++]=V[I++],V[u++]=V[I++],V[u++]=V[I++],2<(j-=3););j&&(V[u++]=V[I++],1<j&&(V[u++]=V[I++]))}break}}break}}while(a<c&&u<g);a-=j=x>>3,S&=(1<<(x-=j<<3))-1,s.next_in=a,s.next_out=u,s.avail_in=a<c?c-a+5:5-(a-c),s.avail_out=u<g?g-u+257:257-(u-g),r.hold=S,r.bits=x}},{}],49:[function(i,n,o){var s=i("../utils/common"),l=i("./adler32"),r=i("./crc32"),a=i("./inffast"),c=i("./inftrees"),u=1,m=2,g=0,d=-2,b=1,f=852,v=592;function k(I){return(I>>>24&255)+(I>>>8&65280)+((65280&I)<<8)+((255&I)<<24)}function S(){this.mode=0,this.last=!1,this.wrap=0,this.havedict=!1,this.flags=0,this.dmax=0,this.check=0,this.total=0,this.head=null,this.wbits=0,this.wsize=0,this.whave=0,this.wnext=0,this.window=null,this.hold=0,this.bits=0,this.length=0,this.offset=0,this.extra=0,this.lencode=null,this.distcode=null,this.lenbits=0,this.distbits=0,this.ncode=0,this.nlen=0,this.ndist=0,this.have=0,this.next=null,this.lens=new s.Buf16(320),this.work=new s.Buf16(288),this.lendyn=null,this.distdyn=null,this.sane=0,this.back=0,this.was=0}function x(I){var N;return I&&I.state?(N=I.state,I.total_in=I.total_out=N.total=0,I.msg="",N.wrap&&(I.adler=1&N.wrap),N.mode=b,N.last=0,N.havedict=0,N.dmax=32768,N.head=null,N.hold=0,N.bits=0,N.lencode=N.lendyn=new s.Buf32(f),N.distcode=N.distdyn=new s.Buf32(v),N.sane=1,N.back=-1,g):d}function B(I){var N;return I&&I.state?((N=I.state).wsize=0,N.whave=0,N.wnext=0,x(I)):d}function E(I,N){var y,V;return I&&I.state?(V=I.state,N<0?(y=0,N=-N):(y=1+(N>>4),N<48&&(N&=15)),N&&(N<8||15<N)?d:(V.window!==null&&V.wbits!==N&&(V.window=null),V.wrap=y,V.wbits=N,B(I))):d}function A(I,N){var y,V;return I?(V=new S,(I.state=V).window=null,(y=E(I,N))!==g&&(I.state=null),y):d}var w,F,H=!0;function j(I){if(H){var N;for(w=new s.Buf32(512),F=new s.Buf32(32),N=0;N<144;)I.lens[N++]=8;for(;N<256;)I.lens[N++]=9;for(;N<280;)I.lens[N++]=7;for(;N<288;)I.lens[N++]=8;for(c(u,I.lens,0,288,w,0,I.work,{bits:9}),N=0;N<32;)I.lens[N++]=5;c(m,I.lens,0,32,F,0,I.work,{bits:5}),H=!1}I.lencode=w,I.lenbits=9,I.distcode=F,I.distbits=5}function J(I,N,y,V){var X,R=I.state;return R.window===null&&(R.wsize=1<<R.wbits,R.wnext=0,R.whave=0,R.window=new s.Buf8(R.wsize)),V>=R.wsize?(s.arraySet(R.window,N,y-R.wsize,R.wsize,0),R.wnext=0,R.whave=R.wsize):(V<(X=R.wsize-R.wnext)&&(X=V),s.arraySet(R.window,N,y-V,X,R.wnext),(V-=X)?(s.arraySet(R.window,N,y-V,V,0),R.wnext=V,R.whave=R.wsize):(R.wnext+=X,R.wnext===R.wsize&&(R.wnext=0),R.whave<R.wsize&&(R.whave+=X))),0}o.inflateReset=B,o.inflateReset2=E,o.inflateResetKeep=x,o.inflateInit=function(I){return A(I,15)},o.inflateInit2=A,o.inflate=function(I,N){var y,V,X,R,U,W,tt,T,M,Y,Z,Q,P,ct,rt,st,gt,mt,C,D,p,O,z,_,$=0,L=new s.Buf8(4),G=[16,17,18,0,8,7,9,6,10,5,11,4,12,3,13,2,14,1,15];if(!I||!I.state||!I.output||!I.input&&I.avail_in!==0)return d;(y=I.state).mode===12&&(y.mode=13),U=I.next_out,X=I.output,tt=I.avail_out,R=I.next_in,V=I.input,W=I.avail_in,T=y.hold,M=y.bits,Y=W,Z=tt,O=g;t:for(;;)switch(y.mode){case b:if(y.wrap===0){y.mode=13;break}for(;M<16;){if(W===0)break t;W--,T+=V[R++]<<M,M+=8}if(2&y.wrap&&T===35615){L[y.check=0]=255&T,L[1]=T>>>8&255,y.check=r(y.check,L,2,0),M=T=0,y.mode=2;break}if(y.flags=0,y.head&&(y.head.done=!1),!(1&y.wrap)||(((255&T)<<8)+(T>>8))%31){I.msg="incorrect header check",y.mode=30;break}if((15&T)!=8){I.msg="unknown compression method",y.mode=30;break}if(M-=4,p=8+(15&(T>>>=4)),y.wbits===0)y.wbits=p;else if(p>y.wbits){I.msg="invalid window size",y.mode=30;break}y.dmax=1<<p,I.adler=y.check=1,y.mode=512&T?10:12,M=T=0;break;case 2:for(;M<16;){if(W===0)break t;W--,T+=V[R++]<<M,M+=8}if(y.flags=T,(255&y.flags)!=8){I.msg="unknown compression method",y.mode=30;break}if(57344&y.flags){I.msg="unknown header flags set",y.mode=30;break}y.head&&(y.head.text=T>>8&1),512&y.flags&&(L[0]=255&T,L[1]=T>>>8&255,y.check=r(y.check,L,2,0)),M=T=0,y.mode=3;case 3:for(;M<32;){if(W===0)break t;W--,T+=V[R++]<<M,M+=8}y.head&&(y.head.time=T),512&y.flags&&(L[0]=255&T,L[1]=T>>>8&255,L[2]=T>>>16&255,L[3]=T>>>24&255,y.check=r(y.check,L,4,0)),M=T=0,y.mode=4;case 4:for(;M<16;){if(W===0)break t;W--,T+=V[R++]<<M,M+=8}y.head&&(y.head.xflags=255&T,y.head.os=T>>8),512&y.flags&&(L[0]=255&T,L[1]=T>>>8&255,y.check=r(y.check,L,2,0)),M=T=0,y.mode=5;case 5:if(1024&y.flags){for(;M<16;){if(W===0)break t;W--,T+=V[R++]<<M,M+=8}y.length=T,y.head&&(y.head.extra_len=T),512&y.flags&&(L[0]=255&T,L[1]=T>>>8&255,y.check=r(y.check,L,2,0)),M=T=0}else y.head&&(y.head.extra=null);y.mode=6;case 6:if(1024&y.flags&&(W<(Q=y.length)&&(Q=W),Q&&(y.head&&(p=y.head.extra_len-y.length,y.head.extra||(y.head.extra=new Array(y.head.extra_len)),s.arraySet(y.head.extra,V,R,Q,p)),512&y.flags&&(y.check=r(y.check,V,Q,R)),W-=Q,R+=Q,y.length-=Q),y.length))break t;y.length=0,y.mode=7;case 7:if(2048&y.flags){if(W===0)break t;for(Q=0;p=V[R+Q++],y.head&&p&&y.length<65536&&(y.head.name+=String.fromCharCode(p)),p&&Q<W;);if(512&y.flags&&(y.check=r(y.check,V,Q,R)),W-=Q,R+=Q,p)break t}else y.head&&(y.head.name=null);y.length=0,y.mode=8;case 8:if(4096&y.flags){if(W===0)break t;for(Q=0;p=V[R+Q++],y.head&&p&&y.length<65536&&(y.head.comment+=String.fromCharCode(p)),p&&Q<W;);if(512&y.flags&&(y.check=r(y.check,V,Q,R)),W-=Q,R+=Q,p)break t}else y.head&&(y.head.comment=null);y.mode=9;case 9:if(512&y.flags){for(;M<16;){if(W===0)break t;W--,T+=V[R++]<<M,M+=8}if(T!==(65535&y.check)){I.msg="header crc mismatch",y.mode=30;break}M=T=0}y.head&&(y.head.hcrc=y.flags>>9&1,y.head.done=!0),I.adler=y.check=0,y.mode=12;break;case 10:for(;M<32;){if(W===0)break t;W--,T+=V[R++]<<M,M+=8}I.adler=y.check=k(T),M=T=0,y.mode=11;case 11:if(y.havedict===0)return I.next_out=U,I.avail_out=tt,I.next_in=R,I.avail_in=W,y.hold=T,y.bits=M,2;I.adler=y.check=1,y.mode=12;case 12:if(N===5||N===6)break t;case 13:if(y.last){T>>>=7&M,M-=7&M,y.mode=27;break}for(;M<3;){if(W===0)break t;W--,T+=V[R++]<<M,M+=8}switch(y.last=1&T,M-=1,3&(T>>>=1)){case 0:y.mode=14;break;case 1:if(j(y),y.mode=20,N!==6)break;T>>>=2,M-=2;break t;case 2:y.mode=17;break;case 3:I.msg="invalid block type",y.mode=30}T>>>=2,M-=2;break;case 14:for(T>>>=7&M,M-=7&M;M<32;){if(W===0)break t;W--,T+=V[R++]<<M,M+=8}if((65535&T)!=(T>>>16^65535)){I.msg="invalid stored block lengths",y.mode=30;break}if(y.length=65535&T,M=T=0,y.mode=15,N===6)break t;case 15:y.mode=16;case 16:if(Q=y.length){if(W<Q&&(Q=W),tt<Q&&(Q=tt),Q===0)break t;s.arraySet(X,V,R,Q,U),W-=Q,R+=Q,tt-=Q,U+=Q,y.length-=Q;break}y.mode=12;break;case 17:for(;M<14;){if(W===0)break t;W--,T+=V[R++]<<M,M+=8}if(y.nlen=257+(31&T),T>>>=5,M-=5,y.ndist=1+(31&T),T>>>=5,M-=5,y.ncode=4+(15&T),T>>>=4,M-=4,286<y.nlen||30<y.ndist){I.msg="too many length or distance symbols",y.mode=30;break}y.have=0,y.mode=18;case 18:for(;y.have<y.ncode;){for(;M<3;){if(W===0)break t;W--,T+=V[R++]<<M,M+=8}y.lens[G[y.have++]]=7&T,T>>>=3,M-=3}for(;y.have<19;)y.lens[G[y.have++]]=0;if(y.lencode=y.lendyn,y.lenbits=7,z={bits:y.lenbits},O=c(0,y.lens,0,19,y.lencode,0,y.work,z),y.lenbits=z.bits,O){I.msg="invalid code lengths set",y.mode=30;break}y.have=0,y.mode=19;case 19:for(;y.have<y.nlen+y.ndist;){for(;st=($=y.lencode[T&(1<<y.lenbits)-1])>>>16&255,gt=65535&$,!((rt=$>>>24)<=M);){if(W===0)break t;W--,T+=V[R++]<<M,M+=8}if(gt<16)T>>>=rt,M-=rt,y.lens[y.have++]=gt;else{if(gt===16){for(_=rt+2;M<_;){if(W===0)break t;W--,T+=V[R++]<<M,M+=8}if(T>>>=rt,M-=rt,y.have===0){I.msg="invalid bit length repeat",y.mode=30;break}p=y.lens[y.have-1],Q=3+(3&T),T>>>=2,M-=2}else if(gt===17){for(_=rt+3;M<_;){if(W===0)break t;W--,T+=V[R++]<<M,M+=8}M-=rt,p=0,Q=3+(7&(T>>>=rt)),T>>>=3,M-=3}else{for(_=rt+7;M<_;){if(W===0)break t;W--,T+=V[R++]<<M,M+=8}M-=rt,p=0,Q=11+(127&(T>>>=rt)),T>>>=7,M-=7}if(y.have+Q>y.nlen+y.ndist){I.msg="invalid bit length repeat",y.mode=30;break}for(;Q--;)y.lens[y.have++]=p}}if(y.mode===30)break;if(y.lens[256]===0){I.msg="invalid code -- missing end-of-block",y.mode=30;break}if(y.lenbits=9,z={bits:y.lenbits},O=c(u,y.lens,0,y.nlen,y.lencode,0,y.work,z),y.lenbits=z.bits,O){I.msg="invalid literal/lengths set",y.mode=30;break}if(y.distbits=6,y.distcode=y.distdyn,z={bits:y.distbits},O=c(m,y.lens,y.nlen,y.ndist,y.distcode,0,y.work,z),y.distbits=z.bits,O){I.msg="invalid distances set",y.mode=30;break}if(y.mode=20,N===6)break t;case 20:y.mode=21;case 21:if(6<=W&&258<=tt){I.next_out=U,I.avail_out=tt,I.next_in=R,I.avail_in=W,y.hold=T,y.bits=M,a(I,Z),U=I.next_out,X=I.output,tt=I.avail_out,R=I.next_in,V=I.input,W=I.avail_in,T=y.hold,M=y.bits,y.mode===12&&(y.back=-1);break}for(y.back=0;st=($=y.lencode[T&(1<<y.lenbits)-1])>>>16&255,gt=65535&$,!((rt=$>>>24)<=M);){if(W===0)break t;W--,T+=V[R++]<<M,M+=8}if(st&&(240&st)==0){for(mt=rt,C=st,D=gt;st=($=y.lencode[D+((T&(1<<mt+C)-1)>>mt)])>>>16&255,gt=65535&$,!(mt+(rt=$>>>24)<=M);){if(W===0)break t;W--,T+=V[R++]<<M,M+=8}T>>>=mt,M-=mt,y.back+=mt}if(T>>>=rt,M-=rt,y.back+=rt,y.length=gt,st===0){y.mode=26;break}if(32&st){y.back=-1,y.mode=12;break}if(64&st){I.msg="invalid literal/length code",y.mode=30;break}y.extra=15&st,y.mode=22;case 22:if(y.extra){for(_=y.extra;M<_;){if(W===0)break t;W--,T+=V[R++]<<M,M+=8}y.length+=T&(1<<y.extra)-1,T>>>=y.extra,M-=y.extra,y.back+=y.extra}y.was=y.length,y.mode=23;case 23:for(;st=($=y.distcode[T&(1<<y.distbits)-1])>>>16&255,gt=65535&$,!((rt=$>>>24)<=M);){if(W===0)break t;W--,T+=V[R++]<<M,M+=8}if((240&st)==0){for(mt=rt,C=st,D=gt;st=($=y.distcode[D+((T&(1<<mt+C)-1)>>mt)])>>>16&255,gt=65535&$,!(mt+(rt=$>>>24)<=M);){if(W===0)break t;W--,T+=V[R++]<<M,M+=8}T>>>=mt,M-=mt,y.back+=mt}if(T>>>=rt,M-=rt,y.back+=rt,64&st){I.msg="invalid distance code",y.mode=30;break}y.offset=gt,y.extra=15&st,y.mode=24;case 24:if(y.extra){for(_=y.extra;M<_;){if(W===0)break t;W--,T+=V[R++]<<M,M+=8}y.offset+=T&(1<<y.extra)-1,T>>>=y.extra,M-=y.extra,y.back+=y.extra}if(y.offset>y.dmax){I.msg="invalid distance too far back",y.mode=30;break}y.mode=25;case 25:if(tt===0)break t;if(Q=Z-tt,y.offset>Q){if((Q=y.offset-Q)>y.whave&&y.sane){I.msg="invalid distance too far back",y.mode=30;break}P=Q>y.wnext?(Q-=y.wnext,y.wsize-Q):y.wnext-Q,Q>y.length&&(Q=y.length),ct=y.window}else ct=X,P=U-y.offset,Q=y.length;for(tt<Q&&(Q=tt),tt-=Q,y.length-=Q;X[U++]=ct[P++],--Q;);y.length===0&&(y.mode=21);break;case 26:if(tt===0)break t;X[U++]=y.length,tt--,y.mode=21;break;case 27:if(y.wrap){for(;M<32;){if(W===0)break t;W--,T|=V[R++]<<M,M+=8}if(Z-=tt,I.total_out+=Z,y.total+=Z,Z&&(I.adler=y.check=y.flags?r(y.check,X,Z,U-Z):l(y.check,X,Z,U-Z)),Z=tt,(y.flags?T:k(T))!==y.check){I.msg="incorrect data check",y.mode=30;break}M=T=0}y.mode=28;case 28:if(y.wrap&&y.flags){for(;M<32;){if(W===0)break t;W--,T+=V[R++]<<M,M+=8}if(T!==(4294967295&y.total)){I.msg="incorrect length check",y.mode=30;break}M=T=0}y.mode=29;case 29:O=1;break t;case 30:O=-3;break t;case 31:return-4;case 32:default:return d}return I.next_out=U,I.avail_out=tt,I.next_in=R,I.avail_in=W,y.hold=T,y.bits=M,(y.wsize||Z!==I.avail_out&&y.mode<30&&(y.mode<27||N!==4))&&J(I,I.output,I.next_out,Z-I.avail_out)?(y.mode=31,-4):(Y-=I.avail_in,Z-=I.avail_out,I.total_in+=Y,I.total_out+=Z,y.total+=Z,y.wrap&&Z&&(I.adler=y.check=y.flags?r(y.check,X,Z,I.next_out-Z):l(y.check,X,Z,I.next_out-Z)),I.data_type=y.bits+(y.last?64:0)+(y.mode===12?128:0)+(y.mode===20||y.mode===15?256:0),(Y==0&&Z===0||N===4)&&O===g&&(O=-5),O)},o.inflateEnd=function(I){if(!I||!I.state)return d;var N=I.state;return N.window&&(N.window=null),I.state=null,g},o.inflateGetHeader=function(I,N){var y;return I&&I.state?(2&(y=I.state).wrap)==0?d:((y.head=N).done=!1,g):d},o.inflateSetDictionary=function(I,N){var y,V=N.length;return I&&I.state?(y=I.state).wrap!==0&&y.mode!==11?d:y.mode===11&&l(1,N,V,0)!==y.check?-3:J(I,N,V,V)?(y.mode=31,-4):(y.havedict=1,g):d},o.inflateInfo="pako inflate (from Nodeca project)"},{"../utils/common":41,"./adler32":43,"./crc32":45,"./inffast":48,"./inftrees":50}],50:[function(i,n,o){var s=i("../utils/common"),l=[3,4,5,6,7,8,9,10,11,13,15,17,19,23,27,31,35,43,51,59,67,83,99,115,131,163,195,227,258,0,0],r=[16,16,16,16,16,16,16,16,17,17,17,17,18,18,18,18,19,19,19,19,20,20,20,20,21,21,21,21,16,72,78],a=[1,2,3,4,5,7,9,13,17,25,33,49,65,97,129,193,257,385,513,769,1025,1537,2049,3073,4097,6145,8193,12289,16385,24577,0,0],c=[16,16,16,16,17,17,18,18,19,19,20,20,21,21,22,22,23,23,24,24,25,25,26,26,27,27,28,28,29,29,64,64];n.exports=function(u,m,g,d,b,f,v,k){var S,x,B,E,A,w,F,H,j,J=k.bits,I=0,N=0,y=0,V=0,X=0,R=0,U=0,W=0,tt=0,T=0,M=null,Y=0,Z=new s.Buf16(16),Q=new s.Buf16(16),P=null,ct=0;for(I=0;I<=15;I++)Z[I]=0;for(N=0;N<d;N++)Z[m[g+N]]++;for(X=J,V=15;1<=V&&Z[V]===0;V--);if(V<X&&(X=V),V===0)return b[f++]=20971520,b[f++]=20971520,k.bits=1,0;for(y=1;y<V&&Z[y]===0;y++);for(X<y&&(X=y),I=W=1;I<=15;I++)if(W<<=1,(W-=Z[I])<0)return-1;if(0<W&&(u===0||V!==1))return-1;for(Q[1]=0,I=1;I<15;I++)Q[I+1]=Q[I]+Z[I];for(N=0;N<d;N++)m[g+N]!==0&&(v[Q[m[g+N]]++]=N);if(w=u===0?(M=P=v,19):u===1?(M=l,Y-=257,P=r,ct-=257,256):(M=a,P=c,-1),I=y,A=f,U=N=T=0,B=-1,E=(tt=1<<(R=X))-1,u===1&&852<tt||u===2&&592<tt)return 1;for(;;){for(F=I-U,j=v[N]<w?(H=0,v[N]):v[N]>w?(H=P[ct+v[N]],M[Y+v[N]]):(H=96,0),S=1<<I-U,y=x=1<<R;b[A+(T>>U)+(x-=S)]=F<<24|H<<16|j|0,x!==0;);for(S=1<<I-1;T&S;)S>>=1;if(S!==0?(T&=S-1,T+=S):T=0,N++,--Z[I]==0){if(I===V)break;I=m[g+v[N]]}if(X<I&&(T&E)!==B){for(U===0&&(U=X),A+=y,W=1<<(R=I-U);R+U<V&&!((W-=Z[R+U])<=0);)R++,W<<=1;if(tt+=1<<R,u===1&&852<tt||u===2&&592<tt)return 1;b[B=T&E]=X<<24|R<<16|A-f|0}}return T!==0&&(b[A+T]=I-U<<24|64<<16|0),k.bits=X,0}},{"../utils/common":41}],51:[function(i,n,o){n.exports={2:"need dictionary",1:"stream end",0:"","-1":"file error","-2":"stream error","-3":"data error","-4":"insufficient memory","-5":"buffer error","-6":"incompatible version"}},{}],52:[function(i,n,o){var s=i("../utils/common"),l=0,r=1;function a($){for(var L=$.length;0<=--L;)$[L]=0}var c=0,u=29,m=256,g=m+1+u,d=30,b=19,f=2*g+1,v=15,k=16,S=7,x=256,B=16,E=17,A=18,w=[0,0,0,0,0,0,0,0,1,1,1,1,2,2,2,2,3,3,3,3,4,4,4,4,5,5,5,5,0],F=[0,0,0,0,1,1,2,2,3,3,4,4,5,5,6,6,7,7,8,8,9,9,10,10,11,11,12,12,13,13],H=[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,2,3,7],j=[16,17,18,0,8,7,9,6,10,5,11,4,12,3,13,2,14,1,15],J=new Array(2*(g+2));a(J);var I=new Array(2*d);a(I);var N=new Array(512);a(N);var y=new Array(256);a(y);var V=new Array(u);a(V);var X,R,U,W=new Array(d);function tt($,L,G,K,q){this.static_tree=$,this.extra_bits=L,this.extra_base=G,this.elems=K,this.max_length=q,this.has_stree=$&&$.length}function T($,L){this.dyn_tree=$,this.max_code=0,this.stat_desc=L}function M($){return $<256?N[$]:N[256+($>>>7)]}function Y($,L){$.pending_buf[$.pending++]=255&L,$.pending_buf[$.pending++]=L>>>8&255}function Z($,L,G){$.bi_valid>k-G?($.bi_buf|=L<<$.bi_valid&65535,Y($,$.bi_buf),$.bi_buf=L>>k-$.bi_valid,$.bi_valid+=G-k):($.bi_buf|=L<<$.bi_valid&65535,$.bi_valid+=G)}function Q($,L,G){Z($,G[2*L],G[2*L+1])}function P($,L){for(var G=0;G|=1&$,$>>>=1,G<<=1,0<--L;);return G>>>1}function ct($,L,G){var K,q,et=new Array(v+1),at=0;for(K=1;K<=v;K++)et[K]=at=at+G[K-1]<<1;for(q=0;q<=L;q++){var lt=$[2*q+1];lt!==0&&($[2*q]=P(et[lt]++,lt))}}function rt($){var L;for(L=0;L<g;L++)$.dyn_ltree[2*L]=0;for(L=0;L<d;L++)$.dyn_dtree[2*L]=0;for(L=0;L<b;L++)$.bl_tree[2*L]=0;$.dyn_ltree[2*x]=1,$.opt_len=$.static_len=0,$.last_lit=$.matches=0}function st($){8<$.bi_valid?Y($,$.bi_buf):0<$.bi_valid&&($.pending_buf[$.pending++]=$.bi_buf),$.bi_buf=0,$.bi_valid=0}function gt($,L,G,K){var q=2*L,et=2*G;return $[q]<$[et]||$[q]===$[et]&&K[L]<=K[G]}function mt($,L,G){for(var K=$.heap[G],q=G<<1;q<=$.heap_len&&(q<$.heap_len&&gt(L,$.heap[q+1],$.heap[q],$.depth)&&q++,!gt(L,K,$.heap[q],$.depth));)$.heap[G]=$.heap[q],G=q,q<<=1;$.heap[G]=K}function C($,L,G){var K,q,et,at,lt=0;if($.last_lit!==0)for(;K=$.pending_buf[$.d_buf+2*lt]<<8|$.pending_buf[$.d_buf+2*lt+1],q=$.pending_buf[$.l_buf+lt],lt++,K===0?Q($,q,L):(Q($,(et=y[q])+m+1,L),(at=w[et])!==0&&Z($,q-=V[et],at),Q($,et=M(--K),G),(at=F[et])!==0&&Z($,K-=W[et],at)),lt<$.last_lit;);Q($,x,L)}function D($,L){var G,K,q,et=L.dyn_tree,at=L.stat_desc.static_tree,lt=L.stat_desc.has_stree,pt=L.stat_desc.elems,wt=-1;for($.heap_len=0,$.heap_max=f,G=0;G<pt;G++)et[2*G]!==0?($.heap[++$.heap_len]=wt=G,$.depth[G]=0):et[2*G+1]=0;for(;$.heap_len<2;)et[2*(q=$.heap[++$.heap_len]=wt<2?++wt:0)]=1,$.depth[q]=0,$.opt_len--,lt&&($.static_len-=at[2*q+1]);for(L.max_code=wt,G=$.heap_len>>1;1<=G;G--)mt($,et,G);for(q=pt;G=$.heap[1],$.heap[1]=$.heap[$.heap_len--],mt($,et,1),K=$.heap[1],$.heap[--$.heap_max]=G,$.heap[--$.heap_max]=K,et[2*q]=et[2*G]+et[2*K],$.depth[q]=($.depth[G]>=$.depth[K]?$.depth[G]:$.depth[K])+1,et[2*G+1]=et[2*K+1]=q,$.heap[1]=q++,mt($,et,1),2<=$.heap_len;);$.heap[--$.heap_max]=$.heap[1],(function(kt,Dt){var Gt,Yt,ie,Nt,Ge,se,Xt=Dt.dyn_tree,ki=Dt.max_code,zi=Dt.stat_desc.static_tree,Lo=Dt.stat_desc.has_stree,Do=Dt.stat_desc.extra_bits,Fn=Dt.stat_desc.extra_base,wi=Dt.stat_desc.max_length,Ni=0;for(Nt=0;Nt<=v;Nt++)kt.bl_count[Nt]=0;for(Xt[2*kt.heap[kt.heap_max]+1]=0,Gt=kt.heap_max+1;Gt<f;Gt++)wi<(Nt=Xt[2*Xt[2*(Yt=kt.heap[Gt])+1]+1]+1)&&(Nt=wi,Ni++),Xt[2*Yt+1]=Nt,ki<Yt||(kt.bl_count[Nt]++,Ge=0,Fn<=Yt&&(Ge=Do[Yt-Fn]),se=Xt[2*Yt],kt.opt_len+=se*(Nt+Ge),Lo&&(kt.static_len+=se*(zi[2*Yt+1]+Ge)));if(Ni!==0){do{for(Nt=wi-1;kt.bl_count[Nt]===0;)Nt--;kt.bl_count[Nt]--,kt.bl_count[Nt+1]+=2,kt.bl_count[wi]--,Ni-=2}while(0<Ni);for(Nt=wi;Nt!==0;Nt--)for(Yt=kt.bl_count[Nt];Yt!==0;)ki<(ie=kt.heap[--Gt])||(Xt[2*ie+1]!==Nt&&(kt.opt_len+=(Nt-Xt[2*ie+1])*Xt[2*ie],Xt[2*ie+1]=Nt),Yt--)}})($,L),ct(et,wt,$.bl_count)}function p($,L,G){var K,q,et=-1,at=L[1],lt=0,pt=7,wt=4;for(at===0&&(pt=138,wt=3),L[2*(G+1)+1]=65535,K=0;K<=G;K++)q=at,at=L[2*(K+1)+1],++lt<pt&&q===at||(lt<wt?$.bl_tree[2*q]+=lt:q!==0?(q!==et&&$.bl_tree[2*q]++,$.bl_tree[2*B]++):lt<=10?$.bl_tree[2*E]++:$.bl_tree[2*A]++,et=q,wt=(lt=0)===at?(pt=138,3):q===at?(pt=6,3):(pt=7,4))}function O($,L,G){var K,q,et=-1,at=L[1],lt=0,pt=7,wt=4;for(at===0&&(pt=138,wt=3),K=0;K<=G;K++)if(q=at,at=L[2*(K+1)+1],!(++lt<pt&&q===at)){if(lt<wt)for(;Q($,q,$.bl_tree),--lt!=0;);else q!==0?(q!==et&&(Q($,q,$.bl_tree),lt--),Q($,B,$.bl_tree),Z($,lt-3,2)):lt<=10?(Q($,E,$.bl_tree),Z($,lt-3,3)):(Q($,A,$.bl_tree),Z($,lt-11,7));et=q,wt=(lt=0)===at?(pt=138,3):q===at?(pt=6,3):(pt=7,4)}}a(W);var z=!1;function _($,L,G,K){Z($,(c<<1)+(K?1:0),3),(function(q,et,at,lt){st(q),Y(q,at),Y(q,~at),s.arraySet(q.pending_buf,q.window,et,at,q.pending),q.pending+=at})($,L,G)}o._tr_init=function($){z||((function(){var L,G,K,q,et,at=new Array(v+1);for(q=K=0;q<u-1;q++)for(V[q]=K,L=0;L<1<<w[q];L++)y[K++]=q;for(y[K-1]=q,q=et=0;q<16;q++)for(W[q]=et,L=0;L<1<<F[q];L++)N[et++]=q;for(et>>=7;q<d;q++)for(W[q]=et<<7,L=0;L<1<<F[q]-7;L++)N[256+et++]=q;for(G=0;G<=v;G++)at[G]=0;for(L=0;L<=143;)J[2*L+1]=8,L++,at[8]++;for(;L<=255;)J[2*L+1]=9,L++,at[9]++;for(;L<=279;)J[2*L+1]=7,L++,at[7]++;for(;L<=287;)J[2*L+1]=8,L++,at[8]++;for(ct(J,g+1,at),L=0;L<d;L++)I[2*L+1]=5,I[2*L]=P(L,5);X=new tt(J,w,m+1,g,v),R=new tt(I,F,0,d,v),U=new tt(new Array(0),H,0,b,S)})(),z=!0),$.l_desc=new T($.dyn_ltree,X),$.d_desc=new T($.dyn_dtree,R),$.bl_desc=new T($.bl_tree,U),$.bi_buf=0,$.bi_valid=0,rt($)},o._tr_stored_block=_,o._tr_flush_block=function($,L,G,K){var q,et,at=0;0<$.level?($.strm.data_type===2&&($.strm.data_type=(function(lt){var pt,wt=4093624447;for(pt=0;pt<=31;pt++,wt>>>=1)if(1&wt&&lt.dyn_ltree[2*pt]!==0)return l;if(lt.dyn_ltree[18]!==0||lt.dyn_ltree[20]!==0||lt.dyn_ltree[26]!==0)return r;for(pt=32;pt<m;pt++)if(lt.dyn_ltree[2*pt]!==0)return r;return l})($)),D($,$.l_desc),D($,$.d_desc),at=(function(lt){var pt;for(p(lt,lt.dyn_ltree,lt.l_desc.max_code),p(lt,lt.dyn_dtree,lt.d_desc.max_code),D(lt,lt.bl_desc),pt=b-1;3<=pt&&lt.bl_tree[2*j[pt]+1]===0;pt--);return lt.opt_len+=3*(pt+1)+5+5+4,pt})($),q=$.opt_len+3+7>>>3,(et=$.static_len+3+7>>>3)<=q&&(q=et)):q=et=G+5,G+4<=q&&L!==-1?_($,L,G,K):$.strategy===4||et===q?(Z($,2+(K?1:0),3),C($,J,I)):(Z($,4+(K?1:0),3),(function(lt,pt,wt,kt){var Dt;for(Z(lt,pt-257,5),Z(lt,wt-1,5),Z(lt,kt-4,4),Dt=0;Dt<kt;Dt++)Z(lt,lt.bl_tree[2*j[Dt]+1],3);O(lt,lt.dyn_ltree,pt-1),O(lt,lt.dyn_dtree,wt-1)})($,$.l_desc.max_code+1,$.d_desc.max_code+1,at+1),C($,$.dyn_ltree,$.dyn_dtree)),rt($),K&&st($)},o._tr_tally=function($,L,G){return $.pending_buf[$.d_buf+2*$.last_lit]=L>>>8&255,$.pending_buf[$.d_buf+2*$.last_lit+1]=255&L,$.pending_buf[$.l_buf+$.last_lit]=255&G,$.last_lit++,L===0?$.dyn_ltree[2*G]++:($.matches++,L--,$.dyn_ltree[2*(y[G]+m+1)]++,$.dyn_dtree[2*M(L)]++),$.last_lit===$.lit_bufsize-1},o._tr_align=function($){Z($,2,3),Q($,x,J),(function(L){L.bi_valid===16?(Y(L,L.bi_buf),L.bi_buf=0,L.bi_valid=0):8<=L.bi_valid&&(L.pending_buf[L.pending++]=255&L.bi_buf,L.bi_buf>>=8,L.bi_valid-=8)})($)}},{"../utils/common":41}],53:[function(i,n,o){n.exports=function(){this.input=null,this.next_in=0,this.avail_in=0,this.total_in=0,this.output=null,this.next_out=0,this.avail_out=0,this.total_out=0,this.msg="",this.state=null,this.data_type=2,this.adler=0}},{}],54:[function(i,n,o){(function(s){(function(l,r){if(!l.setImmediate){var a,c,u,m,g=1,d={},b=!1,f=l.document,v=Object.getPrototypeOf&&Object.getPrototypeOf(l);v=v&&v.setTimeout?v:l,a={}.toString.call(l.process)==="[object process]"?function(B){process.nextTick(function(){S(B)})}:(function(){if(l.postMessage&&!l.importScripts){var B=!0,E=l.onmessage;return l.onmessage=function(){B=!1},l.postMessage("","*"),l.onmessage=E,B}})()?(m="setImmediate$"+Math.random()+"$",l.addEventListener?l.addEventListener("message",x,!1):l.attachEvent("onmessage",x),function(B){l.postMessage(m+B,"*")}):l.MessageChannel?((u=new MessageChannel).port1.onmessage=function(B){S(B.data)},function(B){u.port2.postMessage(B)}):f&&"onreadystatechange"in f.createElement("script")?(c=f.documentElement,function(B){var E=f.createElement("script");E.onreadystatechange=function(){S(B),E.onreadystatechange=null,c.removeChild(E),E=null},c.appendChild(E)}):function(B){setTimeout(S,0,B)},v.setImmediate=function(B){typeof B!="function"&&(B=new Function(""+B));for(var E=new Array(arguments.length-1),A=0;A<E.length;A++)E[A]=arguments[A+1];var w={callback:B,args:E};return d[g]=w,a(g),g++},v.clearImmediate=k}function k(B){delete d[B]}function S(B){if(b)setTimeout(S,0,B);else{var E=d[B];if(E){b=!0;try{(function(A){var w=A.callback,F=A.args;switch(F.length){case 0:w();break;case 1:w(F[0]);break;case 2:w(F[0],F[1]);break;case 3:w(F[0],F[1],F[2]);break;default:w.apply(r,F)}})(E)}finally{k(B),b=!1}}}}function x(B){B.source===l&&typeof B.data=="string"&&B.data.indexOf(m)===0&&S(+B.data.slice(m.length))}})(typeof self>"u"?s===void 0?this:s:self)}).call(this,typeof Zn<"u"?Zn:typeof self<"u"?self:typeof window<"u"?window:{})},{}]},{},[10])(10)})})(Yo)),Yo.exports}var Q1=X1();const tb=J1(Q1),eb=/\.(?:png|jpe?g|gif|svg|webp|avif|ico|bmp|tiff?|mp4|webm|mp3|wav|ogg)$/i,ib=/\.(?:ts|js|mjs|cjs|jsx|tsx|vue|json|css|scss|less|html|py|rs|go|java|c|cpp|h|sh|bash|yaml|yml|toml)$/i;async function nb(t){const e=await tb.loadAsync(t),i={},n=[];let o="",s="";const l=[];e.forEach((a,c)=>{!c.dir&&!a.startsWith("__MACOSX")&&!a.includes("node_modules/")&&l.push({path:a,file:c})});let r=l.find(a=>a.path.toLowerCase()==="slides.md");r||(r=l.find(a=>a.path.toLowerCase().endsWith("/slides.md"))),r||(r=l.find(a=>a.path.toLowerCase().endsWith(".md"))),r&&(o=await r.file.async("string"),s=r.path);for(const a of l){const c=a.path;if(c.toLowerCase().endsWith(".md")||ib.test(c)||c.includes("snippets/")){const u=await a.file.async("string");i[c]=u;const m=c.split("/");m.length>1&&(i[m.slice(1).join("/")]=u)}else if(eb.test(c)){const u=await a.file.async("uint8array"),m=c.split("/").pop()||c,g=typeof Blob<"u"?new Blob([u]):void 0;n.push({zipPath:c,fileName:m,data:u,blob:g})}}return{entryMarkdown:o,entryMarkdownPath:s,virtualFiles:i,assets:n}}function ob(t,e){if(Object.keys(e).length===0)return t;function i(o){const s=o.trim().replace(/^['"]|['"]$/g,""),l=s.split("/").pop()||s;if(e[s])return e[s];const r=s.replace(/^\.?\//,"");return e[r]?e[r]:e[l]?e[l]:null}function n(o){let s=o;return s=s.replace(/!\[(.*?)\]\((.*?)\)/g,(l,r,a)=>{const c=i(a);return c?`![${r}](${c})`:l}),s=s.replace(/\bsrc=["'](.*?)["']/gi,(l,r)=>{const a=i(r);return a?`src="${a}"`:l}),s}for(const o of t.slides)if(o.rawMarkdown=n(o.rawMarkdown),o.pageAttrs["custom-slidev-background"]){const s=o.pageAttrs["custom-slidev-background"],l=i(s);l&&(o.pageAttrs["custom-slidev-background"]=l)}if(t.flattenedMarkdown=n(t.flattenedMarkdown),t.docRootAttrs["custom-slidev-background"]){const o=t.docRootAttrs["custom-slidev-background"],s=i(o);s&&(t.docRootAttrs["custom-slidev-background"]=s)}return t}function ka(t){try{if(typeof process<"u"&&typeof require<"u"){const e=require("fs");if(e.existsSync(t))return e.readFileSync(t,"utf-8")}}catch{}return null}function sb(t,e){const i=t.match(/^[ \t]*<<<[ \t]+([^\s]+)/);if(!i)return null;const n=i[1].trim(),o=n.indexOf("#"),s=o!==-1?n.slice(0,o):n,l=o!==-1?n.slice(o+1):"",r=s.replace(/^@\//,"").replace(/^\.\//,""),a=(e==null?void 0:e.virtualFiles)||{};let c=a[s]||a[r]||a[`./${r}`]||a[`@/${r}`];if(!c&&Object.keys(a).length>0){const d=r.split("/").pop();for(const[b,f]of Object.entries(a))if(b.endsWith(`/${r}`)||d&&b.endsWith(`/${d}`)){c=f;break}}if(!c){const d=[];if(e!=null&&e.baseDir)try{const b=require("path");d.push(b.resolve(e.baseDir,r)),d.push(b.resolve(e.baseDir,s))}catch{}try{const b=require("path");d.push(b.resolve(process.cwd(),r))}catch{}for(const b of d){const f=ka(b);if(f!==null){c=f;break}}}if(!c){const d=da||{};if(c=d[s]||d[r]||d[`snippets/${r}`],!c){const b=r.split("/").pop();for(const[f,v]of Object.entries(d))if(f.endsWith(`/${r}`)||b&&f.endsWith(`/${b}`)){c=v;break}}}if(!c)return null;let u=c;if(l){const d=new RegExp(`(?:\\/\\/|\\/\\*|#)?\\s*#(?:region|REGION)\\s+${l}[^\\r\\n]*\\r?\\n([\\s\\S]*?)(?:\\/\\/|\\/\\*|#)?\\s*#(?:endregion|ENDREGION)\\s+${l}`,"i"),b=c.match(d);if(b){const f=c.match(/^(\/\/\s*Inside[^\r\n]+\r?\n)/i);u=(f?f[1]:"")+b[1].trimEnd()}}const m=r.match(/\.([a-zA-Z0-9]+)$/);return`\`\`\`${m?m[1]:""}
${u}
\`\`\``}function rb(t){let e=!1,i=!1;for(let n=0;n<t.length;n++){const o=t[n];if(o==="'"&&!i)e=!e;else if(o==='"'&&!e)i=!i;else if(o==="#"&&!e&&!i)return t.slice(0,n).trim()}return t.trim()}function to(t){const e={},i=t.split(/\r?\n/);let n=0;for(;n<i.length;){const o=i[n],s=o.trim();if(!s||s.startsWith("#")){n++;continue}const l=o.indexOf(":");if(l>0){const r=o.slice(0,l).trim();let a=o.slice(l+1).trim();if(a==="|"||a===">"){n++;const c=[];let u=-1;for(;n<i.length;){const m=i[n];if(!m.trim()){c.push(""),n++;continue}const d=m.match(/^(\s+)/),b=d?d[1].length:0;if(u===-1&&(u=b),b<u)break;c.push(m.slice(u)),n++}for(;c.length>0&&c[c.length-1]==="";)c.pop();e[r]=a===">"?c.join(" "):c.join(`
`);continue}if(a=rb(a),!a){let c=n+1;const u=[];let m=-1;for(;c<i.length;){const g=i[c],d=g.trim();if(!d||d.startsWith("#")){m!==-1&&u.push(""),c++;continue}const b=g.match(/^(\s+)/),f=b?b[1].length:0;if(m===-1)if(f>0)m=f;else break;if(f<m)break;u.push(g.slice(m)),c++}if(u.length>0){e[r]=to(u.join(`
`)),n=c;continue}}a.startsWith('"')&&a.endsWith('"')||a.startsWith("'")&&a.endsWith("'")?a=a.slice(1,-1):a==="true"?a=!0:a==="false"?a=!1:a==="null"?a=null:/^-?\d+(?:\.\d+)?$/.test(a)&&(a=Number(a)),e[r]=a}n++}return e}const lb=/^\s*```ya?ml([\s\S]*?)```/;function Dr(t){let e={},i=t.trim();const n=i.match(/^---[^\n\r]*\r?\n([\s\S]*?)\r?\n---(?=[ \t]*(?:\r?\n|$))/);if(n&&!n[1].includes("```")){const s=to(n[1]);if(Object.keys(s).length>0||!n[1].trim())return e=s,i=i.slice(n[0].length).trim(),{frontmatter:e,content:i}}if(i.startsWith("---")){const s=i.match(/^---[^\n\r]*(?:\r?\n|$)/);s&&(i=i.slice(s[0].length).trim())}const o=i.match(lb);if(o)e=to(o[1]),i=i.slice(o[0].length).trim();else{const s=i.split(/\r?\n/),l=[];let r=0;for(let a=0;a<s.length;a++){const c=s[a].trim();if(!c){if(l.length>0){r=a+1;break}continue}if(/^[a-zA-Z0-9_-]+\s*:\s*.*/.test(c)&&!c.startsWith("<")&&!c.startsWith("#"))l.push(c);else{r=a;break}}l.length>0&&(e=to(l.join(`
`)),i=s.slice(r).join(`
`).trim())}return{frontmatter:e,content:i}}function ab(t){const e=t.split(/\r?\n/),i=[];let n=0,o=!1;function s(l){if(n>=l)return;const r=e.slice(n,l).join(`
`).trim();r&&i.push(r),n=l+1}for(let l=0;l<e.length;l++){const a=e[l].trimEnd();if(o){a.includes("-->")&&(o=!1);continue}if(a.startsWith("<!--")){a.includes("-->")||(o=!0);continue}if(a.startsWith("---")){s(l);const c=e[l+1];if(c&&c.trim()&&a.replace(/^-+/,"").trim()==="")for(n=l,l+=1;l<e.length&&e[l].trimEnd()!=="---";l++);}else if(a.trimStart().startsWith("```")){const c=a.match(/^\s*`+/),u=c?c[0].trim():"```";let m=l+1;for(;m<e.length&&!e[m].trimStart().startsWith(u);m++);m<e.length&&(l=m)}}return n<e.length&&s(e.length),i}function eo(t,e={}){const{stripNotesFromMarkdown:i=!0,cleanVClicks:n=!0,cleanShikiLines:o=!0,cleanSlots:s=!0,isolateStyleTags:l=!0,cleanHtmlToMarkdown:r=!0,wrapSuperBlocks:a=!0,virtualFiles:c={}}=e;let u=t;u&&!u.trimStart().startsWith("---")&&(u=`---

${u.trimStart()}`);const m=ab(u),g={};let d="",b="",f=0;if(m.length>0){const j=m[0],J=Dr(j),I=Object.keys(J.frontmatter).length>0,N=J.content.length>0;I&&!N&&m.length>1?(f=1,v(J.frontmatter)):I&&v(J.frontmatter)}function v(j){d=j.title||"",j.theme&&(g[xn]=String(j.theme)),j.aspectRatio&&(g[Sn]=String(j.aspectRatio)),j.highlighter&&(g[jr]=String(j.highlighter)),j.transition&&(g[_n]=String(j.transition)),j.colorSchema&&(g[Ur]=String(j.colorSchema)),j.layout&&(g[ht]=String(j.layout)),j.background&&(g[Ut]=String(j.background)),j.image&&(g[Ee]=String(j.image)),j.class&&(g[Vi]=String(j.class));for(const[J,I]of Object.entries(j))["theme","aspectRatio","highlighter","transition","colorSchema","title","layout","background","image","class"].includes(J)||(g[`custom-slidev-${J}`]=typeof I=="object"?JSON.stringify(I):String(I))}const k=[];let S=0,x=0,B=0,E=0;const A=new Set,w={};let F=1;for(let j=f;j<m.length;j++){const J=m[j],{frontmatter:I,content:N}=Dr(J),y=J.match(/^\s*(?:---\s*)?src:\s*([^\n\r]+)/m),V=I.src||(y?y[1]:void 0);if(V){const st=String(V).trim().replace(/^['"]|['"]$/g,"");let gt=c[st]||c[st.replace(/^\.\//,"")]||c[`pages/${st.replace(/^.*pages\//,"")}`];if(!gt){const C=st.replace(/^\.\//,""),D=[];if(e.baseDir)try{const p=require("path");D.push(p.resolve(e.baseDir,C)),D.push(p.resolve(e.baseDir,st))}catch{}try{const p=require("path");D.push(p.resolve(process.cwd(),C)),D.push(p.resolve(process.cwd(),st))}catch{}for(const p of D){const O=ka(p);if(O!==null){gt=O;break}}}const mt={};I.layout&&(mt[ht]=String(I.layout)),I.transition&&(mt[te]=String(I.transition)),I.background&&(mt[Ut]=String(I.background)),I.image&&(mt[Ee]=String(I.image)),I.class&&(mt[Vi]=String(I.class));for(const[C,D]of Object.entries(I))["src","layout","transition","background","image","class"].includes(C)||(mt[`custom-slidev-${C}`]=typeof D=="object"?JSON.stringify(D):String(D));if(gt){const C=eo(gt,{...e,virtualFiles:c});for(const D of C.slides){D.pageIndex=F++,D.pageAttrs={...mt,...D.pageAttrs},k.push(D);const p=D.pageAttrs[ht]||"default";w[p]=(w[p]||0)+1}continue}else{k.push({pageIndex:F++,pageAttrs:{...mt,"custom-slidev-src":st},notes:"",rawMarkdown:`> 📄 **引入外部幻灯片页面**: \`${st}\`
>
> *提示：如需展示该页面完整内容，请将关联子页面一同打包为 .zip 或通过本地工程导入。*`,hasVueComponent:!1,hasStyleTag:!1,assetReferences:[]});const C=mt[ht]||"default";w[C]=(w[C]||0)+1;continue}}const X={};I.layout&&(X[ht]=String(I.layout)),I.transition&&(X[te]=String(I.transition)),I.background&&(X[Ut]=String(I.background)),I.image&&(X[Ee]=String(I.image)),I.class&&(X[Vi]=String(I.class));for(const[st,gt]of Object.entries(I))["layout","transition","background","image","class"].includes(st)||(X[`custom-slidev-${st}`]=typeof gt=="object"?JSON.stringify(gt):String(gt));let R=N;const U=[];let W=R.replace(/(?:^[ \t]*(`{3,}|~{3,})[^\n\r]*\r?\n[\s\S]*?\r?\n[ \t]*\1(?=[ \t]*(?:\r?\n|$)))/gm,st=>{const gt=`__CODE_TOKEN_NOTE_${U.length}__`;return U.push(st),gt});W=W.replace(/(`+)(?:[^\n\r`]|(?!\1)`)+?\1/g,st=>{const gt=`__CODE_TOKEN_NOTE_${U.length}__`;return U.push(st),gt});let tt="";const T=Array.from(W.matchAll(/<!--([\s\S]*?)-->/g));if(T.length>0){const st=T[T.length-1],gt=W.slice(st.index+st[0].length).trim();if(!gt||!gt.replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi,"").trim()){const C=st[1].trim();C.startsWith("TODO:")||(tt=C,S++),i&&(W=W.slice(0,st.index).trimEnd()+W.slice(st.index+st[0].length))}}i&&(W=W.replace(/<!--(?![\s\S]*?TODO:)[\s\S]*?-->/g,"").trim());for(let st=0;st<U.length;st++)W=W.replace(`__CODE_TOKEN_NOTE_${st}__`,U[st]);if(R=W,tt){for(let mt=0;mt<U.length;mt++)tt=tt.replace(`__CODE_TOKEN_NOTE_${mt}__`,U[mt]);const gt=`> [!NOTE] 💡 演讲备注
${tt.split(/\r?\n/).map(mt=>`> ${mt}`).join(`
`)}
{: custom-slidev-note="true"}`;R=R?`${R}

${gt}`:gt}let M=!1;if(/<style\b/i.test(R)){M=!0;const st=R.match(/<style\b[^>]*>([\s\S]*?)<\/style>/gi);if(st){for(const gt of st){const mt=gt.replace(/<style\b[^>]*>|<\/style>/gi,"").trim();b=b?`${b}

${mt}`:mt}l&&(R=R.replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi,"").trim())}}const Y=R.match(/<v-click[^>]*>|<v-clicks[^>]*>|v-click=/g);Y&&(x+=Y.length);const Z=R.match(/```\w+\s+\{[^}]+\}/g);Z&&(B+=Z.length);const Q=R.match(/::\w+::|<template\s+#[^>]+>/g);if(Q&&(E+=Q.length),R=R.replace(/^[ \t]*<<<[ \t]+([^\n\r]+)/gm,st=>sb(st,{...e,virtualFiles:c})||st),n&&(R=R.replace(/<v-click(?:\s+at="[^"]*")?(?:\s+hide)?>\s*([\s\S]*?)\s*<\/v-click>/gi,"$1")),o&&(R=R.replace(/(^```\w+(?:[ \t]+\[[^\]]*\])?)[ \t]+\{[^}]+\}(?:[ \t]+\w+)?/gm,"$1"),R=R.replace(/^\$\$\s+\{[^}]+\}/gm,()=>"$$")),s&&(R=R.replace(/^::\w+::\s*$/gm,"")),r&&(R=Xu(R)),a){let st=R.trim(),gt="";const mt=st.lastIndexOf("> [!NOTE] 💡 演讲备注");if(mt!==-1&&(gt=st.slice(mt),st=st.slice(0,mt).trim()),(I.layout==="image-left"||I.layout==="image-right")&&I.image){const C=String(I.image).trim(),D=I.layout==="image-left"?"image-left":"image-right",p=`![配图](${C})
{: custom-slidev-layout="${D}" }`;I.layout==="image-left"?st=`{{{col

${p}

${st}

}}}`:st=`{{{col

${st}

${p}

}}}`}if(I.background){const D=`![背景图](${String(I.background).trim()})
{: custom-slidev-role="background" }`;st=st?`${D}

${st}`:D}R=gt?`${st}

${gt}`:st}const P=cb(R);X[Ut]&&P.push(X[Ut]),X[Ee]&&P.push(X[Ee]);for(const st of P)A.add(st);const ct=/<[A-Z][a-zA-Z0-9]+/.test(R),rt=X[ht]||(F===1?g[ht]||"cover":"default");w[rt]=(w[rt]||0)+1,k.push({pageIndex:F++,pageAttrs:X,notes:tt,rawMarkdown:R,hasVueComponent:ct,hasStyleTag:M,assetReferences:P})}if(!d&&k.length>0){const j=k[0].rawMarkdown.match(/^#\s+(.+)$/m);j&&(d=j[1].trim())}b&&(g["custom-slidev-custom-css"]=b);let H=k.map(j=>`---

${j.rawMarkdown}`).join(`

`);return H.trimStart().startsWith("---")||(H=`---

${H.trimStart()}`),{docTitle:d||"Slidev 演示文稿",docRootAttrs:g,slides:k,totalSlides:k.length,stats:{totalNotes:S,totalVClicks:x,totalShikiHighlights:B,totalSlots:E,discoveredAssets:Array.from(A),layoutDistribution:w},flattenedMarkdown:H,customCss:b}}function cb(t){const e=[],i=/!\[.*?\]\((.*?)\)/g;let n;for(;(n=i.exec(t))!==null;){const s=n[1].split(/\s+/)[0].trim();s&&e.push(s)}const o=/<(?:img|video|source|audio)\b[^>]*src=["'](.*?)["']/gi;for(;(n=o.exec(t))!==null;){const s=n[1].trim();s&&e.push(s)}return e}function wa(t){if(!t)return!1;const e=String(t.type||"").toLowerCase(),i=String(t.markdown||"").trim(),n=String(t.content||"").trim();return e==="tb"||e==="thematic-break"||e==="nodethematicbreak"||i==="---"||i==="***"||n==="---"||n==="***"}function db(t){return(t.trim()||"Slidev 演示文稿").replace(/[\\/:*?"<>|]/g,"_")}async function ub(t,e,i=Et){const n=t.filter(wa);let o=0;if(n.length>=e.length)for(let s=0;s<e.length;s++){const l=e[s],r=n[s];r&&r.id&&Object.keys(l.pageAttrs||{}).length>0&&(await i(r.id,l.pageAttrs),o++)}else for(let s=1;s<e.length;s++){const l=e[s],r=n[s-1];r&&r.id&&Object.keys(l.pageAttrs||{}).length>0&&(await i(r.id,l.pageAttrs),o++)}return o}async function fb(t,e=Et){let i=!1,n=0;for(const o of t){if(wa(o)){i=!1;continue}const s=(o.markdown||o.content||"").trim();if(s==="::right::"||s.startsWith("::right::")){i=!0;continue}i&&o.id&&(await e(o.id,{[Ct]:"right"}).catch(()=>{}),n++)}return n}async function pb(t,e,i=Nr){const n={};if(!e||e.length===0)return n;const o=[];for(const s of e){const l=new File([s.data],s.fileName,{type:"application/octet-stream"});o.push(l)}try{const s=await i("/data/assets",o);if(s!=null&&s.succMap)for(const[l,r]of Object.entries(s.succMap))n[l]=String(r)}catch(s){console.warn("上传本地静态资产失败，保留原路径:",s)}return Object.keys(n).length>0&&ob(t,n),n}async function hb(t){var B;const{presentation:e,notebookId:i,docTitle:n,extractedAssets:o=[],uploadAssets:s=!0,autoPreview:l=!0,plugin:r,api:a={}}=t,c=a.uploadFn||Nr,u=a.createDocFn||ac,m=a.setAttrsFn||Et,g=a.getChildBlocksFn||no,d=a.openTabFn||ft.openTab,b=a.showMessageFn||ft.showMessage;s&&o.length>0&&await pb(e,o,c);const f=db(n),v=`/${f}`,k=await u(i,v,e.flattenedMarkdown);if(!k)throw new Error("思源内核创建文档失败，未返回有效 DocumentId");const S=((B=e.slides[0])==null?void 0:B.pageAttrs)||{};await m(k,{...S,...e.docRootAttrs});const x=await g(k).catch(()=>[]);return Array.isArray(x)&&x.length>0&&(await ub(x,e.slides,m),await fb(x,m)),b(`🎉 成功导入 Slidev 演示文档《${f}》！`),l&&r&&(r.currentDocId=k,await d({app:r.app,doc:{id:k}}),r.openBottomPreviewTab&&r.openBottomPreviewTab()),k}function mb(t){const e=vt("file"),i=vt(!1),n=vt(!1),o=vt(""),s=vt(null),l=vt(null),r=vt(""),a=vt(0),c=vt(""),u=vt([]),m=vt(null),g=vt(""),d=vt([]),b=vt(""),f=vt(!0),v=vt(!0),k=vt(!0),S=vt(!0),x=St(()=>{const X=a.value;if(X===0)return"0 B";const R=1024,U=["B","KB","MB","GB"],W=Math.floor(Math.log(X)/Math.log(R));return`${(X/R**W).toFixed(1)} ${U[W]}`}),B=St(()=>{var X;return((X=m.value)==null?void 0:X.docRootAttrs["custom-slidev-theme"])||"default"}),E=St(()=>{var X;return u.value.length>0?u.value.length:((X=m.value)==null?void 0:X.stats.discoveredAssets.length)||0}),A=St(()=>{var R;const X=((R=m.value)==null?void 0:R.stats.layoutDistribution)||{};return Object.entries(X).map(([U,W])=>({name:U,count:W}))});async function w(X=lc){try{const R=await X();R!=null&&R.notebooks&&Array.isArray(R.notebooks)&&(d.value=R.notebooks.filter(U=>!U.closed),d.value.length>0&&!b.value&&(b.value=d.value[0].id))}catch(R){console.warn("获取笔记本列表失败:",R)}}function F(){var X;(X=s.value)==null||X.click()}function H(){l.value=null,r.value="",a.value=0,m.value=null,u.value=[],o.value=""}async function j(X){o.value="",l.value=X,r.value=X.name,a.value=X.size;try{if(X.name.toLowerCase().endsWith(".zip")){const U=await X.arrayBuffer(),W=await nb(U);if(!W.entryMarkdown){o.value="未在 Zip 压缩包中找到 slides.md 或任何有效的 Markdown 入口文件";return}u.value=W.assets;const tt=eo(W.entryMarkdown,{stripNotesFromMarkdown:v.value,cleanHtmlToMarkdown:f.value,cleanSlots:!1,virtualFiles:W.virtualFiles});m.value=tt,g.value=tt.docTitle||X.name.replace(/\.zip$/i,"")}else{const U=await X.text();u.value=[];const W=X.path||"",tt=W?W.replace(/[\\/][^\\/]+$/,""):"",T=eo(U,{stripNotesFromMarkdown:v.value,cleanHtmlToMarkdown:f.value,cleanSlots:!1,baseDir:tt||void 0});m.value=T,g.value=T.docTitle||X.name.replace(/\.md$/i,"")}}catch(R){console.error("解析文件失败:",R),o.value=`解析文件失败: ${R.message||String(R)}`}}function J(){if(o.value="",!c.value.trim()){m.value=null;return}try{const X=eo(c.value,{stripNotesFromMarkdown:v.value,cleanHtmlToMarkdown:f.value,cleanSlots:!1});m.value=X,g.value=X.docTitle||"Slidev 演示文稿"}catch(X){o.value=`解析 Markdown 源码失败: ${X.message||String(X)}`}}async function I(){l.value?await j(l.value):c.value&&J()}async function N(X){const R=X.target;R.files&&R.files[0]&&await j(R.files[0])}async function y(X){var R;i.value=!1,(R=X.dataTransfer)!=null&&R.files&&X.dataTransfer.files[0]&&await j(X.dataTransfer.files[0])}async function V(X=t){if(m.value){if(!b.value&&d.value.length>0&&(b.value=d.value[0].id),!b.value){o.value="请先选择目标笔记本";return}n.value=!0,o.value="";try{return await hb({presentation:m.value,notebookId:b.value,docTitle:g.value,extractedAssets:u.value,uploadAssets:k.value,autoPreview:S.value,plugin:X})}catch(R){console.error("导入 Slidev 演示失败:",R),o.value=`导入执行失败: ${R.message||String(R)}`}finally{n.value=!1}}}return{inputMode:e,isDragging:i,isImporting:n,errorMessage:o,fileInputRef:s,selectedFile:l,selectedFileName:r,selectedFileSize:a,rawMarkdownText:c,extractedAssets:u,parsedPresentation:m,customDocTitle:g,notebooks:d,selectedNotebookId:b,optCleanHtml:f,optStripNotes:v,optUploadAssets:k,optAutoPreview:S,formattedFileSize:x,currentTheme:B,extractedAssetsCount:E,layoutChips:A,fetchNotebooks:w,triggerFileInput:F,clearFile:H,processFile:j,onFileSelected:N,onFileDrop:y,onTextChange:J,reprocessCurrentInput:I,handleConfirmImport:V}}const gb={class:"spm-import-dialog"},vb={class:"spm-tabs-header"},bb={class:"spm-dialog-body"},yb={key:0,class:"spm-file-section"},kb={key:0,class:"spm-dropzone-prompt"},wb={class:"spm-dropzone-icon"},xb={key:1,class:"spm-dropzone-active"},Sb={class:"spm-file-badge"},_b={class:"spm-file-size"},Cb={key:1,class:"spm-text-section"},$b={key:2,class:"spm-error-banner"},Ib={key:3,class:"spm-preview-card"},Ab={class:"spm-preview-card__header"},Bb={style:{display:"inline-flex","align-items":"center",gap:"4px"}},Tb={class:"spm-config-grid"},Eb={class:"spm-form-item"},Mb={class:"spm-form-item"},Lb=["value"],Db={class:"spm-stats-grid"},Pb={class:"spm-stat-box"},Ob={class:"spm-stat-value"},Rb={class:"spm-stat-box"},zb={class:"spm-stat-value"},Nb={class:"spm-stat-box"},Fb={class:"spm-stat-value"},Hb={class:"spm-stat-box"},jb={class:"spm-stat-value"},Ub={key:0,class:"spm-chips-row"},Wb={class:"spm-options-group"},Vb={class:"spm-checkbox-label"},qb={class:"spm-checkbox-label"},Kb={class:"spm-checkbox-label"},Gb={class:"spm-checkbox-label"},Zb={class:"spm-dialog-footer"},Yb=["disabled"],Jb=["disabled"],Xb={key:0,style:{display:"inline-flex","align-items":"center",gap:"4px"}},Qb={key:1,style:{display:"inline-flex","align-items":"center",gap:"4px"}},ty=Ce({__name:"SlidevImportDialog",emits:["close","success"],setup(t,{emit:e}){const i=e,n=ei("plugin"),{inputMode:o,isDragging:s,isImporting:l,errorMessage:r,fileInputRef:a,selectedFileName:c,rawMarkdownText:u,extractedAssetsCount:m,parsedPresentation:g,customDocTitle:d,notebooks:b,selectedNotebookId:f,optCleanHtml:v,optStripNotes:k,optUploadAssets:S,optAutoPreview:x,formattedFileSize:B,currentTheme:E,layoutChips:A,fetchNotebooks:w,triggerFileInput:F,clearFile:H,onFileSelected:j,onFileDrop:J,onTextChange:I,reprocessCurrentInput:N,handleConfirmImport:y}=mb(n);Rn(async()=>{await w()});async function V(){const R=await y();R&&(i("success",{docId:R}),i("close"))}function X(){i("close")}return(R,U)=>(nt(),ot("div",{class:"spm-modal-overlay",onClick:Me(X,["self"])},[h("div",gb,[h("div",{class:"spm-dialog-header"},[U[18]||(U[18]=h("div",{class:"spm-dialog-title"},[h("svg",{class:"spm-dialog-icon","aria-hidden":"true"},[h("use",{"xlink:href":"#iconSlidev"})]),h("span",null,"导入 Slidev 演示文档")],-1)),h("button",{class:"spm-close-btn",title:"关闭",onClick:X},"✕")]),h("div",vb,[h("button",{class:At(["spm-tab-btn",{active:bt(o)==="file"}]),onClick:U[0]||(U[0]=W=>o.value="file")},[dt(ut,{name:"package"}),U[19]||(U[19]=h("span",null,"文件 / 压缩包导入 (.zip / .md)",-1))],2),h("button",{class:At(["spm-tab-btn",{active:bt(o)==="text"}]),onClick:U[1]||(U[1]=W=>o.value="text")},[dt(ut,{name:"notes"}),U[20]||(U[20]=h("span",null,"粘贴 Markdown 源码",-1))],2)]),h("div",bb,[bt(o)==="file"?(nt(),ot("div",yb,[h("div",{class:At(["spm-dropzone",{dragover:bt(s),"has-file":!!bt(c)}]),onDragover:U[4]||(U[4]=Me(W=>s.value=!0,["prevent"])),onDragleave:U[5]||(U[5]=Me(W=>s.value=!1,["prevent"])),onDrop:U[6]||(U[6]=Me((...W)=>bt(J)&&bt(J)(...W),["prevent"])),onClick:U[7]||(U[7]=(...W)=>bt(F)&&bt(F)(...W))},[h("input",{ref_key:"fileInputRef",ref:a,type:"file",accept:".zip,.md",class:"spm-hidden-input",onChange:U[2]||(U[2]=(...W)=>bt(j)&&bt(j)(...W))},null,544),bt(c)?(nt(),ot("div",xb,[h("span",Sb,[dt(ut,{name:"notes"}),Ae(" "+_t(bt(c)),1)]),h("span",_b,"("+_t(bt(B))+")",1),h("button",{class:"spm-btn-text",onClick:U[3]||(U[3]=Me((...W)=>bt(H)&&bt(H)(...W),["stop"]))},"更换文件")])):(nt(),ot("div",kb,[h("span",wb,[dt(ut,{name:"folder",style:{"font-size":"32px"}})]),U[21]||(U[21]=h("p",{class:"spm-dropzone-text"},"点击选择文件，或直接拖拽文件至此处",-1)),U[22]||(U[22]=h("p",{class:"spm-dropzone-hint"},[Ae(" 支持 Slidev 完整工程 "),h("strong",null,".zip"),Ae("（自动解包 public/ 静态素材）或单文件 "),h("strong",null,".md")],-1))]))],34)])):(nt(),ot("div",Cb,[Te(h("textarea",{"onUpdate:modelValue":U[8]||(U[8]=W=>Jt(u)?u.value=W:null),class:"spm-textarea spm-source-editor",rows:"8",placeholder:"在此直接粘贴包含 Frontmatter 的 Slidev slides.md 源码...",onInput:U[9]||(U[9]=(...W)=>bt(I)&&bt(I)(...W))},null,544),[[vo,bt(u)]])])),bt(r)?(nt(),ot("div",$b," ⚠️ "+_t(bt(r)),1)):Ot("",!0),bt(g)?(nt(),ot("div",Ib,[h("div",Ab,[h("span",Bb,[dt(ut,{name:"sparkles"}),U[23]||(U[23]=Ae(" 演示解析摘要",-1))]),U[24]||(U[24]=h("span",{class:"spm-badge-success"},"预检就绪",-1))]),h("div",Tb,[h("div",Eb,[U[25]||(U[25]=h("label",{class:"spm-form-label"},"笔记文档标题",-1)),Te(h("input",{"onUpdate:modelValue":U[10]||(U[10]=W=>Jt(d)?d.value=W:null),class:"spm-input",placeholder:"思源新文档标题"},null,512),[[vo,bt(d)]])]),h("div",Mb,[U[26]||(U[26]=h("label",{class:"spm-form-label"},"存放目标笔记本",-1)),Te(h("select",{"onUpdate:modelValue":U[11]||(U[11]=W=>Jt(f)?f.value=W:null),class:"spm-select"},[(nt(!0),ot(Kt,null,xe(bt(b),W=>(nt(),ot("option",{key:W.id,value:W.id},_t(W.name),9,Lb))),128))],512),[[Mu,bt(f)]])])]),h("div",Db,[h("div",Pb,[h("span",Ob,_t(bt(g).totalSlides),1),U[27]||(U[27]=h("span",{class:"spm-stat-label"},"幻灯片页数",-1))]),h("div",Rb,[h("span",zb,_t(bt(E)),1),U[28]||(U[28]=h("span",{class:"spm-stat-label"},"演示主题",-1))]),h("div",Nb,[h("span",Fb,_t(bt(g).stats.totalNotes),1),U[29]||(U[29]=h("span",{class:"spm-stat-label"},"演讲者提词",-1))]),h("div",Hb,[h("span",jb,_t(bt(m)),1),U[30]||(U[30]=h("span",{class:"spm-stat-label"},"关联本地素材",-1))])]),bt(A).length>0?(nt(),ot("div",Ub,[U[31]||(U[31]=h("span",{class:"spm-chips-label"},"页面版式分布：",-1)),(nt(!0),ot(Kt,null,xe(bt(A),W=>(nt(),ot("span",{key:W.name,class:"spm-chip-badge"},_t(W.name)+": "+_t(W.count),1))),128))])):Ot("",!0),h("div",Wb,[h("label",Vb,[Te(h("input",{"onUpdate:modelValue":U[12]||(U[12]=W=>Jt(v)?v.value=W:null),type:"checkbox",onChange:U[13]||(U[13]=(...W)=>bt(N)&&bt(N)(...W))},null,544),[[Kn,bt(v)]]),U[32]||(U[32]=h("span",null,"智能剥离展示型 HTML 容器为干净原生的 Markdown 笔记块",-1))]),h("label",qb,[Te(h("input",{"onUpdate:modelValue":U[14]||(U[14]=W=>Jt(k)?k.value=W:null),type:"checkbox",onChange:U[15]||(U[15]=(...W)=>bt(N)&&bt(N)(...W))},null,544),[[Kn,bt(k)]]),U[33]||(U[33]=h("span",null,"提取演讲者提词到块属性并保持正文笔记清爽",-1))]),h("label",Kb,[Te(h("input",{"onUpdate:modelValue":U[16]||(U[16]=W=>Jt(S)?S.value=W:null),type:"checkbox"},null,512),[[Kn,bt(S)]]),U[34]||(U[34]=h("span",null,"自动上传关联素材至思源资产库并重写路径 (assets/...)",-1))]),h("label",Gb,[Te(h("input",{"onUpdate:modelValue":U[17]||(U[17]=W=>Jt(x)?x.value=W:null),type:"checkbox"},null,512),[[Kn,bt(x)]]),U[35]||(U[35]=h("span",null,"导入后自动打开新文档并开启下方分屏放映预览",-1))])])])):Ot("",!0)]),h("div",Zb,[h("button",{class:"spm-btn-secondary",disabled:bt(l),onClick:X}," 取消 ",8,Yb),h("button",{class:"spm-btn-primary",disabled:!bt(g)||bt(l),onClick:V},[bt(l)?(nt(),ot("span",Xb,[dt(ut,{name:"refresh"}),U[36]||(U[36]=Ae(" 正在导入生成中...",-1))])):(nt(),ot("span",Qb,[dt(ut,{name:"rocket"}),U[37]||(U[37]=Ae(" 确认导入思源笔记",-1))]))],8,Jb)])])]))}}),ey=ze(ty,[["__scopeId","data-v-ce8dffdc"]]);function xa(t){return t?t==="NodeThematicBreak"||t==="tb"||t==="thematic-break":!1}function iy(t,e){var r;if(!t||t.length===0)return null;const i=e.activeBlockId||"",n=e.currentTopBlockId||i,o=e.currentPageDividerId||"",s=e.activeBlockType||"";if(xa(s)&&i){let a=t.find(c=>c.startBlockId===i);if(a||(a=t.find(c=>{var u,m;return((m=(u=c.blocks)==null?void 0:u[0])==null?void 0:m.id)===i}),a)||(a=t.find(c=>{var u;return(u=c.allBlockIds)==null?void 0:u.includes(i)}),a))return a}if(o){let a=t.find(c=>c.startBlockId===o);if(a||(a=t.find(c=>{var u,m;return((m=(u=c.blocks)==null?void 0:u[0])==null?void 0:m.id)===o}),a))return a}if(i){let a=t.find(u=>u.startBlockId===i);if(a||(a=t.find(u=>{var m,g;return((m=u.blocks)==null?void 0:m.some(d=>d.id===i))||((g=u.allBlockIds)==null?void 0:g.includes(i))}),a)||n&&n!==i&&(a=t.find(u=>{var m,g;return((m=u.blocks)==null?void 0:m.some(d=>d.id===n))||((g=u.allBlockIds)==null?void 0:g.includes(n))}),a)||(a=t.find(u=>{var m;return(m=u.noteBlocks)==null?void 0:m.some(g=>g.id===i||g.id===n)}),a))return a;const c=(r=e.activeBlockAttrs)==null?void 0:r[Ct];if(c&&["col-1","col-2","col-3"].includes(c)&&(a=t.find(u=>{var m,g;return((m=u.frontmatter)==null?void 0:m.layout)==="three-cols-header"||((g=u.blocks)==null?void 0:g.some(d=>d.slot==="col-1"||d.slot==="col-2"||d.slot==="col-3"))}),a))return a}return t[0]||null}function Pr(t,e){const i=(t.blocks||[]).filter(l=>{const r=(l.content||l.rawMarkdown||"").trim();return r&&r!=="---"});if(i.length===0)return"本页暂无内容，建议过渡承接上下文。";const n=[],o=[];for(const l of i){const r=(l.content||l.rawMarkdown||"").trim();r&&(l.type==="h"||r.startsWith("#")?n.push(r.replace(/^#+\s*/,"")):o.push(r.slice(0,50)))}const s=[];return n.length>0&&s.push(`【核心重点】：${n.join("、")}`),o.length>0&&(s.push("【口播要点】："),o.slice(0,3).forEach((l,r)=>{s.push(`${r+1}. 讲解 ${l}`)})),s.push("【过渡提示】：注意观察听众反应，适时抛出互动提问。"),s.join(`
`)}async function Sa(t,e){const i=t.blocks&&t.blocks.length>0?t.blocks.map(n=>(n.content||n.rawMarkdown||"").trim()).filter(n=>n&&n!=="---").join(`
`):(t.rawMarkdown||"").replace(/^---\s*$/gm,"").trim();if(e&&i){const n=`你是一位专业的演讲教练。请根据以下幻灯片内容，提炼出简短精炼的演讲口播提词卡（Notes），包含核心观点与口播要点，总字数在 150 字以内：
${i}`;try{const o=await e(n);if(o&&o.trim())return{notes:o.trim(),isAiGenerated:!0}}catch(o){return{notes:Pr(t),isAiGenerated:!1,error:(o==null?void 0:o.message)||"AI 调用异常"}}}return{notes:Pr(t),isAiGenerated:!1}}async function ny(t,e){return(await Sa(t,e)).notes}function Or(t,e){if(!e)return!1;if(t===e||typeof document>"u")return!0;const i=document.querySelector(`.protyle-wysiwyg [data-node-id="${e}"]`)||document.querySelector(`[data-node-id="${e}"]`);if(!i)return!1;const n=i.querySelector(":scope > [data-node-id], :scope > div > [data-node-id]");return(n==null?void 0:n.getAttribute("data-node-id"))===t}function oy(t){const e=vt(!1);let i=null;function n(T="已同步"){t.saveStatus.value=T,i&&(typeof window<"u"?window.clearTimeout(i):clearTimeout(i));const M=()=>{t.saveStatus.value=""};typeof window<"u"?i=window.setTimeout(M,1200):i=setTimeout(M,1200)}async function o(T){var Q;const M=t.activeBlockId.value||t.currentDocId.value;if(!M)return;for(const[P,ct]of Object.entries(T))t.activeBlockAttrs.value[P]=ct;Lt.setBlockAttrOverride(M,T),Zt(M,T);const Y=(Q=t.parentContainerId)==null?void 0:Q.value,Z=!!(Y&&Or(M,Y));if(jt in T&&Z&&Y){const P=T[jt];t.parentContainerClicks&&(t.parentContainerClicks.value=P),Lt.setBlockAttrOverride(Y,{[jt]:P}),Zt(Y,{[jt]:P}),Et(Y,{[jt]:P}).catch(()=>{})}if(ht in T){const P=T[ht];t.currentPageDividerLayout.value=P,t.targetSlide.value&&(t.targetSlide.value.frontmatter||(t.targetSlide.value.frontmatter={}),t.targetSlide.value.frontmatter.layout=P)}if(le in T){const P=T[le];t.targetSlide.value&&(t.targetSlide.value.frontmatter||(t.targetSlide.value.frontmatter={}),t.targetSlide.value.frontmatter.layoutRatio=P)}n("保存中...");try{await Et(M,T),n("已同步"),t.plugin&&await t.plugin.compileCurrentDocument()}catch{n("同步失败")}}async function s(T,M){var P;const Y=t.activeBlockId.value||t.currentDocId.value;if(!Y)return;t.activeBlockAttrs.value[T]=M,Lt.setBlockAttrOverride(Y,{[T]:M}),Zt(Y,{[T]:M});const Z=(P=t.parentContainerId)==null?void 0:P.value,Q=!!(Z&&Or(Y,Z));T===jt&&Q&&Z&&(t.parentContainerClicks&&(t.parentContainerClicks.value=M),Lt.setBlockAttrOverride(Z,{[jt]:M}),Zt(Z,{[jt]:M}),Et(Z,{[jt]:M}).catch(()=>{})),T===ht&&(t.currentPageDividerLayout.value=M,t.targetSlide.value&&(t.targetSlide.value.frontmatter||(t.targetSlide.value.frontmatter={}),t.targetSlide.value.frontmatter.layout=M)),T===le&&t.targetSlide.value&&(t.targetSlide.value.frontmatter||(t.targetSlide.value.frontmatter={}),t.targetSlide.value.frontmatter.layoutRatio=M),n("保存中...");try{await Et(Y,{[T]:M}),n("已同步"),t.plugin&&await t.plugin.compileCurrentDocument()}catch{n("同步失败")}}function l(){const T=t.activeBlockType.value==="NodeThematicBreak"||t.activeBlockType.value==="NodeThematicBreakBlock"||t.activeBlockType.value==="hr"||t.activeBlockType.value==="thematicbreak";return t.currentPageDividerId.value||(T?t.activeBlockId.value:"")||t.currentDocId.value}async function r(T,M){const Y=l();if(Y){Y===t.activeBlockId.value&&(t.activeBlockAttrs.value[T]=M),Lt.setBlockAttrOverride(Y,{[T]:M}),Zt(Y,{[T]:M}),T===ht&&(t.currentPageDividerLayout.value=M,t.targetSlide.value&&(t.targetSlide.value.frontmatter||(t.targetSlide.value.frontmatter={}),t.targetSlide.value.frontmatter.layout=M)),T===le&&t.targetSlide.value&&(t.targetSlide.value.frontmatter||(t.targetSlide.value.frontmatter={}),t.targetSlide.value.frontmatter.layoutRatio=M),n("保存中...");try{await Et(Y,{[T]:M}),n("已同步"),t.plugin&&await t.plugin.compileCurrentDocument()}catch{n("同步失败")}}}async function a(T,M){const Y=l();if(!Y)return;const Z={[ht]:T,[le]:M};Y===t.activeBlockId.value&&(t.activeBlockAttrs.value[ht]=T,t.activeBlockAttrs.value[le]=M),t.currentPageDividerLayout.value=T,Lt.setBlockAttrOverride(Y,Z),Zt(Y,Z),t.targetSlide.value&&(t.targetSlide.value.frontmatter||(t.targetSlide.value.frontmatter={}),t.targetSlide.value.frontmatter.layout=T,t.targetSlide.value.frontmatter.layoutRatio=M),n("应用排版中...");try{await Et(Y,Z),n("已应用分栏与比例"),t.plugin&&await t.plugin.compileCurrentDocument()}catch{n("应用失败")}}async function c(T,M){var Z;const Y=t.currentDocId.value||t.activeBlockId.value;if(Y){t.activeBlockAttrs.value[T]=M,Lt.setBlockAttrOverride(Y,{[T]:M}),Zt(Y,{[T]:M}),(Z=t.latestDoc.value)!=null&&Z.config&&(T===xn&&(t.latestDoc.value.config.theme=M),T===Sn&&(t.latestDoc.value.config.aspectRatio=M),T===_n&&(t.latestDoc.value.config.defaultTransition=M)),n("更新中...");try{await Et(Y,{[T]:M}),n("已更新"),t.plugin&&await t.plugin.compileCurrentDocument(Y)}catch{n("更新失败")}}}async function u(){(t.videoAutoplay.value?"false":"true")==="true"?(await o({[Ti]:"true",[Ui]:"true"}),t.activeBlockAttrs.value[Ti]="true",t.activeBlockAttrs.value[Ui]="true"):(await s(Ti,"false"),t.activeBlockAttrs.value[Ti]="false")}async function m(){const T=t.videoLoop.value?"false":"true";await s(oo,T)}async function g(){const T=t.videoMuted.value?"false":"true";await s(Ui,T)}async function d(){const T=t.videoControls.value?"false":"true";await s(so,T)}async function b(T){var P;const M=t.activeBlockId.value;if(!M)return;const Y=t.rawSnippet.value||"",Z=bi(Y)||"",Q=t.currentPageDividerId.value||t.currentDocId.value;if(T)if(T==="background"){const ct={[qt]:"background",[ht]:""};Q&&Z&&(t.pageBackground.value=Z,await Et(Q,{[Ut]:Z}).catch(()=>{}),Lt.setBlockAttrOverride(Q,{[Ut]:Z}),Zt(Q,{[Ut]:Z}),t.targetSlide.value&&(t.targetSlide.value.frontmatter||(t.targetSlide.value.frontmatter={}),t.targetSlide.value.frontmatter.background=Z)),await o(ct)}else(T===ro||T===lo)&&await o({[ht]:T,[qt]:""});else{const ct={[qt]:"",[ht]:""};if(t.activeBlockAttrs.value[Ut]==="true"&&(ct[Ut]=""),Q&&Z&&t.pageBackground.value===Z&&(t.pageBackground.value="",await Et(Q,{[Ut]:""}).catch(()=>{}),Lt.setBlockAttrOverride(Q,{[Ut]:""}),Zt(Q,{[Ut]:""}),(P=t.targetSlide.value)!=null&&P.frontmatter&&delete t.targetSlide.value.frontmatter.background),await o(ct),typeof document<"u"){const rt=document.querySelector(`.protyle-wysiwyg [data-node-id="${M}"]`),st=rt==null?void 0:rt.closest('[data-type="NodeListItem"]'),gt=st==null?void 0:st.getAttribute("data-node-id");if(gt&&gt!==M){const mt={[ht]:"",[qt]:""};Zt(gt,mt),Lt.setBlockAttrOverride(gt,mt),await Et(gt,mt).catch(()=>{})}}}}async function f(T){var gt,mt,C,D,p,O,z,_;const Z=`> [!NOTE] 💡 演讲备注
${(T||"在此输入本页讲稿提词...").split(/\r?\n/).map($=>`> ${$}`).join(`
`)}
{: custom-slidev-note="true"}`,Q=((gt=t.latestDoc.value)==null?void 0:gt.slides)||[],P=t.targetSlide.value,ct=P?Q.findIndex($=>$===P):-1;let rt=null;if(ct!==-1&&ct<Q.length-1){const $=Q[ct+1];rt=await Ii("markdown",Z,$.startBlockId)}else{const $=((mt=P==null?void 0:P.noteBlocks)==null?void 0:mt.slice(-1)[0])||((C=P==null?void 0:P.blocks)==null?void 0:C.slice(-1)[0]),L=($==null?void 0:$.id)||(P==null?void 0:P.startBlockId);L?rt=await Ii("markdown",Z,void 0,L):rt=await Xo("markdown",Z,t.currentDocId.value)}const st=((O=(p=(D=rt==null?void 0:rt[0])==null?void 0:D.doOperations)==null?void 0:p[0])==null?void 0:O.id)||((z=rt==null?void 0:rt[0])==null?void 0:z.id);return st&&(await Et(st,{[ne]:"true"}),Lt.setBlockAttrOverride(st,{[ne]:"true"}),Pi(st,(_=t.plugin)==null?void 0:_.app)),t.plugin&&await t.plugin.compileCurrentDocument(),st}async function v(){const T=t.activeBlockId.value;if(T)if(t.isNoteBlock.value){n("取消中...");try{await Et(T,{[ne]:"","slidev-note":""}),Lt.setBlockAttrOverride(T,{[ne]:"","slidev-note":""}),Zt(T,{[ne]:"","slidev-note":""}),delete t.activeBlockAttrs.value[ne],delete t.activeBlockAttrs.value["slidev-note"],n("已取消备注"),ft.showMessage("已取消讲稿备注"),t.plugin&&await t.plugin.compileCurrentDocument()}catch(M){console.error("[SiYuanSlidev] 取消讲稿备注失败:",M),n("取消失败"),ft.showMessage("取消讲稿备注失败")}}else{n("转换中...");try{let M=t.rawSnippet.value;try{const P=await cc(T);P!=null&&P.kramdown&&(M=P.kramdown)}catch{}const Q=`> [!NOTE] 💡 演讲备注
${(ra(M)||M.replace(/<[^>]+>/g,"").trim()||"在此输入本页讲稿提词...").split(/\r?\n/).map(P=>`> ${P}`).join(`
`)}
{: custom-slidev-note="true"}`;await Ks("markdown",Q,T),await Et(T,{[ne]:"true"}),Lt.setBlockAttrOverride(T,{[ne]:"true"}),Zt(T,{[ne]:"true"}),t.activeBlockAttrs.value[ne]="true",t.activeBlockType.value="NodeCallout",n("已设为讲稿备注"),ft.showMessage("已转为讲稿备注提示块（不在幻灯片中渲染）"),t.plugin&&await t.plugin.compileCurrentDocument()}catch(M){console.error("[SiYuanSlidev] 转换讲稿备注提示块失败:",M),n("设置失败"),ft.showMessage("转为讲稿备注提示块失败")}}}async function k(){try{await f(),ft.showMessage("已在正文末尾插入讲稿备注提示块")}catch(T){ft.showMessage("插入讲稿备注块失败"),console.error(T)}}function S(){var Y;const T=t.currentSlideNoteBlockId.value;if(!T){ft.showMessage("未找到本页关联的讲稿备注块");return}Pi(T,(Y=t.plugin)==null?void 0:Y.app)?ft.showMessage("已在编辑区定位讲稿备注块"):ft.showMessage("定位讲稿备注块失败")}async function x(){var Y;if(!t.currentDocId.value)return;const T=t.targetSlide.value||{startBlockId:t.activeBlockId.value||t.currentDocId.value,blocks:t.rawSnippet.value&&t.rawSnippet.value!=="---"?[{id:t.activeBlockId.value,type:t.activeBlockType.value,content:t.rawSnippet.value,rawMarkdown:""}]:[],rawMarkdown:t.rawSnippet.value&&t.rawSnippet.value!=="---"?t.rawSnippet.value:""};ft.showMessage("正在调用思源 AI 提炼本页讲稿提词...");const M=await Sa(T,Fr);if(M.notes){const Z=t.currentSlideNoteBlockId.value;if(Z){const Q=`> [!NOTE] 💡 演讲备注
${M.notes.split(/\r?\n/).map(P=>`> ${P}`).join(`
`)}
{: custom-slidev-note="true"}`;await Ks("markdown",Q,Z),await Et(Z,{[ne]:"true"}),Lt.setBlockAttrOverride(Z,{[ne]:"true"}),Pi(Z,(Y=t.plugin)==null?void 0:Y.app)}else await f(M.notes);M.isAiGenerated?ft.showMessage("思源 AI 演讲提词卡生成成功！"):ft.showMessage("未获取到思源 AI 响应，已生成预设提词卡模板",5e3),t.plugin&&await t.plugin.compileCurrentDocument()}}async function B(){var Z;if(e.value)return;const T=((Z=t.latestDoc.value)==null?void 0:Z.slides)||[];if(T.length===0){ft.showMessage("当前文档无幻灯片页面");return}const M=T.map((Q,P)=>({slide:Q,idx:P})).filter(({slide:Q})=>{var rt;const P=Array.isArray(Q.noteBlocks)&&Q.noteBlocks.length>0,ct=!!((rt=Q.notes)!=null&&rt.trim());return!P&&!ct});if(M.length===0){ft.showMessage("所有幻灯片页面均已存在讲稿备注块，无需追加");return}const Y=M.length;ft.confirm("批量追加讲稿备注",`将在未配置讲稿的 ${Y} 页末尾自动插入讲稿提示块，是否继续？`,async()=>{var P,ct,rt,st,gt,mt;if(e.value)return;e.value=!0,ft.showMessage("正在批量追加讲稿块...");let Q=0;try{const p=`> [!NOTE] 💡 演讲备注
${"在此输入本页讲稿提词...".split(/\r?\n/).map(O=>`> ${O}`).join(`
`)}
{: custom-slidev-note="true"}`;for(const{slide:O,idx:z}of M)try{let _=null;if(z<T.length-1){const L=T[z+1];_=await Ii("markdown",p,L.startBlockId)}else{const L=((P=O==null?void 0:O.noteBlocks)==null?void 0:P.slice(-1)[0])||((ct=O==null?void 0:O.blocks)==null?void 0:ct.slice(-1)[0]),G=(L==null?void 0:L.id)||(O==null?void 0:O.startBlockId);G?_=await Ii("markdown",p,void 0,G):_=await Xo("markdown",p,t.currentDocId.value)}const $=((gt=(st=(rt=_==null?void 0:_[0])==null?void 0:rt.doOperations)==null?void 0:st[0])==null?void 0:gt.id)||((mt=_==null?void 0:_[0])==null?void 0:mt.id);$&&(await Et($,{[ne]:"true"}),Lt.setBlockAttrOverride($,{[ne]:"true"})),Q++}catch(_){console.error(`[SiYuanSlidev] 为第 ${z+1} 页追加讲稿块失败:`,_)}t.plugin&&await t.plugin.compileCurrentDocument(),ft.showMessage(`已成功为 ${Q} 页追加讲稿备注块`)}catch(C){console.error("[SiYuanSlidev] 批量追加讲稿块失败:",C),ft.showMessage("批量追加讲稿块时出现异常")}finally{e.value=!1}})}async function E(){var Q;if(e.value)return;const T=((Q=t.latestDoc.value)==null?void 0:Q.slides)||[];if(T.length===0){ft.showMessage("当前文档无幻灯片页面");return}const M=[];for(const P of T)if(P.noteBlocks&&P.noteBlocks.length>0)for(const ct of P.noteBlocks)ct.id&&M.push({id:ct.id,pageIndex:P.pageIndex});if(M.length===0){ft.showMessage("当前文档中没有讲稿备注块，无需删除");return}const Y=new Set(M.map(P=>P.pageIndex)).size,Z=M.length;ft.confirm("危险操作：批量删除所有讲稿块",`此操作将从正文中物理删除全部 ${Z} 个讲稿备注块（涉及 ${Y} 页），删除后无法撤销。是否确认继续？`,async()=>{if(e.value)return;e.value=!0,ft.showMessage("正在批量删除讲稿块...");let P=0;try{for(const ct of M)try{await Gs(ct.id),Lt.clearBlockAttrOverride(ct.id),P++}catch(rt){console.error(`[SiYuanSlidev] 删除讲稿块 ${ct.id} 失败:`,rt)}t.activeBlockId.value&&M.some(ct=>ct.id===t.activeBlockId.value)&&(delete t.activeBlockAttrs.value[ne],delete t.activeBlockAttrs.value["slidev-note"]),t.plugin&&await t.plugin.compileCurrentDocument(),ft.showMessage(`已成功删除全部 ${P} 个讲稿备注块`)}catch(ct){console.error("[SiYuanSlidev] 批量删除讲稿块失败:",ct),ft.showMessage("批量删除讲稿块时出现异常")}finally{e.value=!1}})}function A(){t.elemClick.value?s(jt,""):s(jt,"+1")}function w(T){s(jt,T)}function F(T){s(Ve,T)}function H(T){(t.activeBlockAttrs.value[Ct]||"")===T?s(Ct,""):s(Ct,T)}function j(T){t.elemShikiLines.value=T,s(Oi,T)}function J(T){t.elemMaxHeight.value=T,s(Cn,T)}async function I(){const T=t.currentSlideLayout.value==="three-cols-header";await s(Ct,T?"col-1":"left"),ft.showMessage(T?"已将当前块设置为第 1 栏 (col-1)":"已将当前块设置为双栏左栏 (left)")}async function N(){const T=t.activeBlockId.value;if(!T)return;const M={[jt]:"",[Ve]:"",[Ct]:"",[Oi]:"",[Cn]:"",[ne]:"","slidev-note":"",[ht]:"",[le]:"",[qt]:"",[te]:"",[Ut]:"",[Ee]:"",[Ti]:"",[oo]:"",[Ui]:"",[so]:""};if(Zt(T,M),await Et(T,M),Lt.clearBlockAttrOverride(T),typeof document<"u"){const Y=document.querySelector(`.protyle-wysiwyg [data-node-id="${T}"]`),Z=Y==null?void 0:Y.closest('[data-type="NodeListItem"]'),Q=Z==null?void 0:Z.getAttribute("data-node-id");Q&&Q!==T&&(Zt(Q,M),await Et(Q,M).catch(()=>{}),Lt.clearBlockAttrOverride(Q))}t.activeBlockAttrs.value={},t.elemShikiLines.value="",t.elemMaxHeight.value="",t.pageBackground.value="",t.pageImage.value="",ft.showMessage("已清除本块演示属性"),t.plugin&&await t.plugin.compileCurrentDocument()}async function y(){if(t.activeBlockId.value)try{await Ii("markdown","---",t.activeBlockId.value,void 0),ft.showMessage("已在上方插入分页符 (---)"),t.plugin&&t.plugin.compileCurrentDocument()}catch{ft.showMessage("插入分页符失败")}}async function V(){const T=t.activeBlockId.value||t.currentDocId.value;if(T)try{await Ii("markdown","---",void 0,T),ft.showMessage("已在下方插入分页符 (---)"),t.plugin&&t.plugin.compileCurrentDocument()}catch{ft.showMessage("插入分页符失败")}}async function X(){if(t.activeBlockId.value)try{await Gs(t.activeBlockId.value),ft.showMessage("已删除该分页符"),t.activeBlockId.value="",t.activeBlockType.value="",t.plugin&&t.plugin.compileCurrentDocument()}catch{ft.showMessage("删除失败")}}function R(){if(!t.latestDoc.value){ft.showMessage("请先在主编辑区打开幻灯片文档");return}const T=va(t.latestDoc.value);ba("presentation.html",T)&&ft.showMessage("已开始下载单文件离线 HTML 演示包")}function U(){if(!t.latestDoc.value){ft.showMessage("请先在主编辑区打开幻灯片文档");return}ya(t.latestDoc.value)&&ft.showMessage("已唤起打印视窗，请在打印选项中选择「另存为 PDF」")}async function W(){var T,M;try{let Y=null;if(typeof document<"u"){const Q=t.activeBlockId.value;if(Q){const P=document.querySelector(`.protyle-wysiwyg [data-node-id="${Q}"]`);P&&(Y=P.getAttribute("data-type")==="NodeSuperBlock"?P:P.closest('[data-type="NodeSuperBlock"]'))}if(!Y){const P=t.currentPageDividerId.value||(t.activeBlockType.value==="hr"||t.activeBlockType.value==="NodeThematicBreak"?t.activeBlockId.value:"");if(P){const ct=document.querySelector(`.protyle-wysiwyg [data-node-id="${P}"]`);if(ct){let rt=ct.nextElementSibling;for(;rt&&!(rt.getAttribute("data-type")==="NodeThematicBreak"||(T=rt.classList)!=null&&T.contains("protyle-wysiwyg__block--hr"));){const st=rt.getAttribute("data-type")==="NodeSuperBlock"?rt:rt.querySelector('[data-type="NodeSuperBlock"]');if(st){Y=st;break}rt=rt.nextElementSibling}}}else{const ct=document.querySelector('.protyle-wysiwyg [data-type="NodeThematicBreak"], .protyle-wysiwyg .protyle-wysiwyg__block--hr'),rt=Array.from(document.querySelectorAll('.protyle-wysiwyg [data-type="NodeSuperBlock"]'));for(const st of rt)if(!ct||st.compareDocumentPosition(ct)&Node.DOCUMENT_POSITION_FOLLOWING){Y=st;break}}}}const Z=[];if(Y){const Q=Array.from(Y.querySelectorAll(":scope > [data-node-id]"));for(const P of Q){const ct=P.getAttribute("data-node-id");ct&&(Z.push(ct),P.removeAttribute("style"))}}else if((M=t.targetSlide.value)!=null&&M.blocks){for(const Q of t.targetSlide.value.blocks)if(Q.children&&Q.children.length>=2){for(const P of Q.children)P.id&&Z.push(P.id);break}}if(Z.length>0)for(const Q of Z)await Et(Q,{style:""}).catch(()=>{});await r(le,""),ft.showMessage("已重置超级块为平均分布比例"),t.plugin&&await t.plugin.compileCurrentDocument()}catch(Y){console.error("[useInspectorActions] resetSuperBlockWidth error:",Y),ft.showMessage("重置超级块比例失败")}}async function tt(){var T,M,Y;try{let Z=null;if(typeof document<"u"){const P=t.currentPageDividerId.value||(t.activeBlockType.value==="hr"||t.activeBlockType.value==="NodeThematicBreak"?t.activeBlockId.value:""),ct=t.activeBlockId.value;let rt=[];if(P){const mt=document.querySelector(`.protyle-wysiwyg [data-node-id="${P}"]`);if(mt){let C=mt.nextElementSibling;for(;C&&!(C.getAttribute("data-type")==="NodeThematicBreak"||(T=C.classList)!=null&&T.contains("protyle-wysiwyg__block--hr"));)rt.push(C),C=C.nextElementSibling}}else{const mt=document.querySelector('.protyle-wysiwyg [data-type="NodeThematicBreak"], .protyle-wysiwyg .protyle-wysiwyg__block--hr'),C=Array.from(document.querySelectorAll(".protyle-wysiwyg > [data-node-id]"));for(const D of C)if(!mt||D.compareDocumentPosition(mt)&Node.DOCUMENT_POSITION_FOLLOWING)rt.push(D);else break}const st=[];let gt;for(const mt of rt){const C=mt.getAttribute("data-type");C==="NodeHeading"&&(gt=mt.getAttribute("data-node-id")||void 0);const D=[];C==="NodeSuperBlock"?D.push(mt):D.push(...Array.from(mt.querySelectorAll('[data-type="NodeSuperBlock"]')));for(const p of D){if((p.getAttribute("data-sb-layout")||"").toLowerCase()==="row")continue;const z=p.getAttribute("data-node-id")||"";let _=[];const $=Array.from(p.querySelectorAll('[data-type="NodeListItem"]'));if($.length===4&&(_=$.map(L=>L.getAttribute("data-node-id")).filter(Boolean)),_.length!==4){const L=Array.from(p.querySelectorAll(":scope > [data-node-id]"));L.length===4&&(_=L.map(G=>G.getAttribute("data-node-id")).filter(Boolean))}_.length===4&&st.push({sbId:z,itemIds:_,headerId:gt})}}st.length>0&&(ct&&(Z=st.find(mt=>{if(mt.sbId===ct||mt.itemIds.includes(ct))return!0;const C=document.querySelector(`.protyle-wysiwyg [data-node-id="${mt.sbId}"]`),D=document.querySelector(`.protyle-wysiwyg [data-node-id="${ct}"]`);return!!(C&&D&&C.contains(D))})||null),Z||(Z=st[0]))}if(!Z&&((M=t.targetSlide.value)!=null&&M.blocks)){const P=t.targetSlide.value,ct=[];for(const st of P.blocks)st.rawNode?ct.push(st.rawNode):ct.push({id:st.id,type:st.type,content:st.content,markdown:st.rawMarkdown,children:st.children,ial:st.attributes||st.ial||{}});const rt=Gu(ct,t.activeBlockId.value);rt&&rt.items.length===4&&(Z={sbId:rt.superBlockNode.id,itemIds:rt.items.map(st=>st.id),headerId:(Y=rt.headerNode)==null?void 0:Y.id})}if(!Z||Z.itemIds.length!==4)return ft.showMessage("当前页面未找到包含 4 个组件的超级块（需包含 4 个列表项或 4 个子块）",4e3,"info"),!1;const Q=t.currentPageDividerId.value||t.currentDocId.value;Q&&(t.currentPageDividerLayout.value="clover",t.targetSlide.value&&(t.targetSlide.value.frontmatter||(t.targetSlide.value.frontmatter={}),t.targetSlide.value.frontmatter.layout="clover"),Lt.setBlockAttrOverride(Q,{[ht]:"clover"}),Zt(Q,{[ht]:"clover"}),await Et(Q,{[ht]:"clover"}).catch(()=>{})),Z.headerId&&(Lt.setBlockAttrOverride(Z.headerId,{[Ct]:"header"}),Zt(Z.headerId,{[Ct]:"header"}),await Et(Z.headerId,{[Ct]:"header"}).catch(()=>{}));for(let P=0;P<4;P++){const ct=Z.itemIds[P],rt=`col-${P+1}`;Lt.setBlockAttrOverride(ct,{[Ct]:rt}),Zt(ct,{[Ct]:rt}),await Et(ct,{[Ct]:rt}).catch(()=>{})}return ft.showMessage("已将本页版式设为四叶草（田字型）布局"),t.plugin&&await t.plugin.compileCurrentDocument(),!0}catch(Z){return console.error("[useInspectorActions] applyCloverLayout error:",Z),ft.showMessage("配置四叶草布局失败",4e3,"error"),!1}}return{triggerSaveNotice:n,saveAttrs:o,saveAttr:s,savePageAttr:r,applyPageLayoutAndRatio:a,applyCloverLayout:tt,resetSuperBlockWidth:W,saveDocAttr:c,onToggleVideoAutoplay:u,onToggleVideoLoop:m,onToggleVideoMuted:g,onToggleVideoControls:d,onImageRoleChange:b,onToggleNoteBlock:v,createNoteBlockOnCurrentSlide:f,onAddNoteBlock:k,onLocateNoteBlock:S,onGenerateNotesWithAI:x,isBatchProcessing:e,onBatchAppendNotes:B,onBatchDeleteNotes:E,toggleElemClick:A,onElemClickStepChange:w,onElemMotionChange:F,onElemSlotChange:H,onElemShikiLinesChange:j,onElemMaxHeightChange:J,onSetTwoColsContrast:I,onClearBlockAttrs:N,onInsertDividerBefore:y,onInsertDividerAfter:V,onDeleteCurrentBlock:X,onExportHtml:R,onExportPdf:U}}const sy={class:"spm-slidev-inspector"},ry={class:"spm-inspector-topbar"},ly={class:"spm-inspector-title"},ay={class:"slidev-icon",style:{fill:"none !important"},"aria-hidden":"true",viewBox:"0 0 24 24"},cy={class:"spm-inspector-topbar-actions"},dy={class:"spm-target-banner"},uy={class:"spm-target-info"},fy=["aria-label"],py={key:0,class:"spm-save-status"},hy=["title"],my={class:"spm-inspector-body"},gy=Ce({__name:"SlidevInspectorDockView",setup(t,{expose:e}){const i=ei("plugin"),n=vt(!1);function o(it){n.value=!1,c.value=it.docId,i!=null&&i.compileCurrentDocument&&i.compileCurrentDocument(it.docId)}const s=vt(""),l=vt(""),r=vt({}),a=vt(""),c=vt(""),u=vt(""),m=vt(""),g=vt(""),d=vt(""),b=vt(""),f=vt(""),v=vt(null),k=vt(""),S=vt("");function x(){var yt;const it=s.value||c.value;it&&typeof navigator<"u"&&(yt=navigator==null?void 0:navigator.clipboard)!=null&&yt.writeText&&navigator.clipboard.writeText(it).then(()=>{S.value="已复制！",setTimeout(()=>{S.value=""},1500)}).catch(()=>{})}const B=St(()=>xa(l.value)),E=St(()=>l.value==="NodeCodeBlock"),A=vt(!1),w=St(()=>{if(A.value||lt.value)return!0;const it=a.value||"";return!!bi(it)}),F=St(()=>{const it=l.value||"";if(it==="NodeVideo"||it==="video")return!0;const yt=a.value||"";return!!(/<video\b/i.test(yt)||/\.mp4\b/i.test(yt))}),H=St(()=>!s.value||s.value===c.value||l.value==="doc"||l.value==="NodeDocument"),j=St(()=>{const it=s.value||c.value||"";return it.length>8?it.slice(-8):it||"无"}),J=St(()=>a.value?a.value.replace(/<[^>]+>/g,"").replace(/[\r\n]+/g," ").trim().slice(0,45):""),I=St(()=>{if(B.value)return"分页符 (---)";if(H.value)return"全局文档";if(F.value)return"视频块";let it="内容块";switch(l.value){case"NodeHeading":it="标题块";break;case"NodeParagraph":it="段落块";break;case"NodeCodeBlock":it="代码块";break;case"NodeVideo":it="视频块";break;case"NodeList":case"NodeListItem":it="列表项";break;case"NodeBlockquote":it="引述块";break;case"NodeTable":it="表格块";break;case"NodeSuperBlock":case"s":case"sb":it="超级块";break;default:it="内容块";break}return d.value?b.value?`${b.value.replace(/^col-(\d+)$/,"第 $1 栏")} › ${it}`:`分栏容器 › ${it}`:it}),N=St(()=>B.value?"tag-divider":H.value?"tag-doc":"tag-block"),y=St(()=>r.value[ht]||"default"),V=St(()=>r.value[te]||"slide-left"),X=vt(""),R=vt(""),U=St(()=>r.value[fn]||"inherit"),W=St(()=>{var it;return iy((it=v.value)==null?void 0:it.slides,{activeBlockId:s.value,activeBlockType:l.value,currentTopBlockId:u.value,currentPageDividerId:m.value,activeBlockAttrs:r.value})}),tt=St(()=>{var it;return((it=W.value)==null?void 0:it.notes)||""}),T=St(()=>{var it,yt,It;return((It=(yt=(it=W.value)==null?void 0:it.noteBlocks)==null?void 0:yt[0])==null?void 0:It.id)||""}),M=St(()=>{var Mt,Ft,Pt,fe,Hn,di;if(B.value){const Qt=r.value[ht]||r.value["custom-slidev-layout"];if(Qt)return Qt}const it=r.value[Ct]||r.value["custom-slidev-slot"];if(it&&(["col-1","col-2","col-3"].includes(it)||/^col-\d+$/.test(it)))return"cols-header";if(g.value)return g.value;const yt=m.value||(B.value?s.value:"");if(yt){const Qt=Lt.getBlockAttrOverride(yt);if(Qt!=null&&Qt[ht])return Qt[ht]}if(yt&&((Mt=v.value)!=null&&Mt.slides)){const Qt=v.value.slides.find(Fi=>Fi.startBlockId===yt);if((Ft=Qt==null?void 0:Qt.frontmatter)!=null&&Ft.layout)return Qt.frontmatter.layout}if((fe=(Pt=W.value)==null?void 0:Pt.frontmatter)!=null&&fe.layout)return W.value.frontmatter.layout;if((di=(Hn=W.value)==null?void 0:Hn.blocks)!=null&&di.some(Qt=>Qt.slot&&(["col-1","col-2","col-3"].includes(Qt.slot)||/^col-\d+$/.test(Qt.slot))))return"cols-header";const It=Lt.getBlockAttrOverride(c.value);return It!=null&&It[ht]?It[ht]:"default"}),Y=St(()=>{var yt,It;if(B.value){const Mt=r.value[le]||r.value["custom-slidev-layout-ratio"];if(Mt)return Mt}const it=m.value||(B.value?s.value:"");if(it){const Mt=Lt.getBlockAttrOverride(it);if(Mt!=null&&Mt[le])return Mt[le]}return((It=(yt=W.value)==null?void 0:yt.frontmatter)==null?void 0:It.layoutRatio)||""});function Z(it){if(!it||(it.getAttribute("data-sb-layout")||"").toLowerCase()!=="col")return null;const It=Array.from(it.querySelectorAll(":scope > [data-node-id]"));if(It.length<2)return null;const Mt=It.length,Ft=It.map(di=>{const Qt=di.getAttribute("style")||"",Fi=Qt.match(/calc\(\s*([\d.]+)%/);if(Fi)return parseFloat(Fi[1]);const sn=Qt.match(/(?:^|;|\s)width:\s*([\d.]+)%/i);return sn?parseFloat(sn[1]):null});let Pt="",fe=!1;if(Ft.some(di=>di!==null)){fe=!0;const di=Ft.reduce((Tt,pe)=>Tt+(pe||0),0),Qt=Ft.filter(Tt=>Tt===null).length,Fi=Qt>0?Math.max(0,100-di)/Qt:100/It.length,sn=Ft.map(Tt=>Tt!==null?Tt:Fi),Qa=sn.reduce((Tt,pe)=>Tt+pe,0)||1,rn=sn.map(Tt=>Tt/Qa*100);if(rn.length===2){const[Tt]=rn;if(Tt>=48&&Tt<=52)Pt="1:1";else if(Tt>=31&&Tt<=35)Pt="1:2";else if(Tt>=65&&Tt<=69)Pt="2:1";else if(Tt>=28&&Tt<=32)Pt="3:7";else if(Tt>=68&&Tt<=72)Pt="7:3";else if(Tt>=38&&Tt<=42)Pt="4:6";else if(Tt>=58&&Tt<=62)Pt="6:4";else{const pe=Math.round(Tt);Pt=`${pe}:${100-pe}`}}else if(rn.length===3){const[Tt,pe,ui]=rn;if(Tt>=31&&Tt<=35&&pe>=31&&pe<=35&&ui>=31&&ui<=35)Pt="1:1:1";else if(Tt>=23&&Tt<=27&&pe>=48&&pe<=52&&ui>=23&&ui<=27)Pt="1:2:1";else if(Tt>=48&&Tt<=52&&pe>=23&&pe<=27&&ui>=23&&ui<=27)Pt="2:1:1";else if(Tt>=23&&Tt<=27&&pe>=23&&pe<=27&&ui>=48&&ui<=52)Pt="1:1:2";else{const Vs=Math.round(Tt),qs=Math.round(pe);Pt=`${Vs}:${qs}:${100-Vs-qs}`}}else Pt=rn.map(Tt=>Math.round(Tt)).join(":")}else fe=!1,Pt=Array.from({length:Mt},()=>1).join(":");const Hn=Mt>=2?"cols-header":"two-cols";return{hasSuperBlock:!0,colCount:Mt,ratio:Pt,isCustomWidth:fe,recommendedLayout:Hn}}function Q(it){if(!(it!=null&&it.blocks))return null;for(const yt of it.blocks){const It=yt.rawNode;if(It&&oe(It)&&Ke(It)){const Ft=on(It).length,Pt=Os(It);return{hasSuperBlock:!0,colCount:Ft,ratio:Pt||Array.from({length:Ft},()=>1).join(":"),isCustomWidth:!!Pt,recommendedLayout:Ft>=2?"cols-header":"two-cols"}}}return null}const P=St(()=>{var it;if(typeof document<"u"){const yt=s.value;if(yt){const Mt=document.querySelector(`.protyle-wysiwyg [data-node-id="${yt}"]`);if(Mt){const Ft=Mt.getAttribute("data-type")==="NodeSuperBlock"?Mt:Mt.closest('[data-type="NodeSuperBlock"]');if(Ft){const Pt=Z(Ft);if(Pt)return Pt}}}const It=m.value||(B.value?s.value:"");if(It){const Mt=document.querySelector(`.protyle-wysiwyg [data-node-id="${It}"]`);if(Mt){let Ft=Mt.nextElementSibling;for(;Ft&&!(Ft.getAttribute("data-type")==="NodeThematicBreak"||(it=Ft.classList)!=null&&it.contains("protyle-wysiwyg__block--hr"));){const Pt=Ft.getAttribute("data-type")==="NodeSuperBlock"?Ft:Ft.querySelector('[data-type="NodeSuperBlock"]');if(Pt){const fe=Z(Pt);if(fe)return fe}Ft=Ft.nextElementSibling}}}else{const Mt=document.querySelector('.protyle-wysiwyg [data-type="NodeThematicBreak"], .protyle-wysiwyg .protyle-wysiwyg__block--hr'),Ft=Array.from(document.querySelectorAll('.protyle-wysiwyg [data-type="NodeSuperBlock"]'));for(const Pt of Ft)if(!Mt||Pt.compareDocumentPosition(Mt)&Node.DOCUMENT_POSITION_FOLLOWING){const fe=Z(Pt);if(fe)return fe}}}return Q(W.value)}),ct=St(()=>{var it;return((it=P.value)==null?void 0:it.ratio)||""}),rt=St(()=>{const it=l.value||"";if(it==="NodeSuperBlock"||it==="s"||it==="sb")return!0;if(typeof document<"u"&&s.value){const yt=document.querySelector(`.protyle-wysiwyg [data-node-id="${s.value}"]`);if(yt!=null&&yt.closest('[data-type="NodeSuperBlock"]'))return!0}return!1}),st=St(()=>{var it;return((it=W.value)==null?void 0:it.pageIndex)||1}),gt=St(()=>!!(r.value[ne]||r.value["slidev-note"]));function mt(){if(!d.value)return!1;if(s.value===d.value||typeof document>"u")return!0;const it=document.querySelector(`.protyle-wysiwyg [data-node-id="${d.value}"]`)||document.querySelector(`[data-node-id="${d.value}"]`);if(!it)return!1;const yt=it.querySelector(":scope > [data-node-id], :scope > div > [data-node-id]");return(yt==null?void 0:yt.getAttribute("data-node-id"))===s.value}const C=St(()=>{var yt;if(r.value[jt]!==void 0)return r.value[jt]||"";if(d.value&&mt())return f.value||"";if(d.value)return"";const it=s.value;if(it&&((yt=W.value)!=null&&yt.blocks)){const It=W.value.blocks.find(Mt=>Mt.id===it);if(It!=null&&It.clicks)return It.clicks}return""}),D=St(()=>{var yt;if(r.value[Ve])return r.value[Ve];const it=s.value;if(it&&((yt=W.value)!=null&&yt.blocks)){const It=W.value.blocks.find(Mt=>Mt.id===it);if(It!=null&&It.motion)return typeof It.motion=="string"?It.motion:JSON.stringify(It.motion)}return""}),p=St(()=>{var yt;if(r.value[Ct])return r.value[Ct];const it=s.value;if(it&&((yt=W.value)!=null&&yt.blocks)){const It=W.value.blocks.find(Mt=>Mt.id===it);if(It!=null&&It.slot)return It.slot}return""}),O=vt(""),z=vt(""),_=St(()=>r.value[Ti]==="true"),$=St(()=>r.value[oo]==="true"),L=St(()=>r.value[Ui]==="true"),G=St(()=>r.value[so]!=="false"),K=St(()=>{var it,yt;return((yt=(it=v.value)==null?void 0:it.config)==null?void 0:yt.theme)||r.value[xn]||"default"}),q=St(()=>{var it,yt;return((yt=(it=v.value)==null?void 0:it.config)==null?void 0:yt.aspectRatio)||r.value[Sn]||"16/9"}),et=St(()=>{var it,yt;return((yt=(it=v.value)==null?void 0:it.config)==null?void 0:yt.defaultTransition)||r.value[_n]||"slide-left"}),at=St(()=>{var it,yt;return((yt=(it=v.value)==null?void 0:it.config)==null?void 0:yt.spacing)||r.value[ts]||"normal"}),lt=St(()=>{var Ft,Pt;if((r.value[qt]||r.value["slidev-role"])===Wr||r.value[Ut]==="true")return"background";const yt=r.value[ht]||r.value["slidev-layout"];if(yt==="image-left"||yt==="image-right")return yt;const It=a.value||"",Mt=bi(It);if(Mt&&((Pt=(Ft=W.value)==null?void 0:Ft.frontmatter)!=null&&Pt.background)){const fe=W.value.frontmatter.background;if(fe===Mt||fe.endsWith(Mt)||Mt.endsWith(fe))return"background"}return""}),pt=St(()=>!!(r.value[jt]||r.value[Ve]||r.value[Ct]||r.value[Oi]||r.value[ne]||r.value["slidev-note"]||r.value[qt]||r.value[ht]||r.value[Ti]||r.value[oo]||r.value[Ui]||r.value[so])),{saveAttr:wt,savePageAttr:kt,applyPageLayoutAndRatio:Dt,applyCloverLayout:Gt,resetSuperBlockWidth:Yt,saveDocAttr:ie,onToggleVideoAutoplay:Nt,onToggleVideoLoop:Ge,onToggleVideoMuted:se,onToggleVideoControls:Xt,onImageRoleChange:ki,onToggleNoteBlock:zi,onAddNoteBlock:Lo,onLocateNoteBlock:Do,onGenerateNotesWithAI:Fn,isBatchProcessing:wi,onBatchAppendNotes:Ni,onBatchDeleteNotes:$a,toggleElemClick:Ia,onElemClickStepChange:Aa,onElemMotionChange:Ba,onElemSlotChange:Ta,onElemShikiLinesChange:Ea,onElemMaxHeightChange:Ma,onSetTwoColsContrast:La,onClearBlockAttrs:Da,onInsertDividerBefore:Pa,onInsertDividerAfter:js,onDeleteCurrentBlock:Oa,onExportHtml:Ra,onExportPdf:za}=oy({activeBlockId:s,activeBlockType:l,activeBlockAttrs:r,rawSnippet:a,currentDocId:c,currentPageDividerId:m,currentPageDividerLayout:g,parentContainerId:d,parentContainerClicks:f,latestDoc:v,targetSlide:W,currentSlideNoteBlockId:T,currentSlideLayout:M,isNoteBlock:gt,elemClick:C,videoAutoplay:_,videoLoop:$,videoMuted:L,videoControls:G,pageBackground:X,pageImage:R,elemShikiLines:O,elemMaxHeight:z,saveStatus:k,plugin:i});async function Na(it){if(it==="clover"){if(!await Gt())return}else wt(ht,it)}function Fa(it){kt(le,it)}function Us(it){if(!it)return;const yt=it.recommendedLayout||(it.colCount&&it.colCount>=2?"cols-header":"two-cols"),It=it.ratio||(it.colCount?Array(it.colCount).fill(1).join(":"):"1:1");Dt(yt,It)}function Ha(it){kt(le,it)}async function ja(){await Yt()}function Ua(it){wt(te,it)}function Wa(it){X.value=it,wt(Ut,it)}function Va(it){R.value=it,wt(Ee,it)}function qa(it){wt(fn,it==="inherit"?"":it)}function Ka(it){ie(xn,it)}function Ga(it){ie(Sn,it)}function Za(it){ie(_n,it)}function Ya(it){ie(ts,it)}function Ws(){i!=null&&i.openBottomPreviewTab&&i.openBottomPreviewTab()}function Ja(){typeof window<"u"&&window.open("/plugins/siyuan-slidev/slidev-client/presenter.html","SlidevPresenter","width=1200,height=800")}function Xa(){i!=null&&i.executeCommand&&i.executeCommand("slidevAiSplit")}return e({setActiveBlock(it){s.value=it.id,l.value=it.type,r.value={...it.attrs},a.value=it.content||it.markdown||"",u.value=it.topBlockId||it.id,m.value=it.pageDividerId||"",g.value=it.pageDividerLayout||"",d.value=it.parentContainerId||"",b.value=it.parentContainerSlot||"",f.value=it.parentContainerClicks||"",it.rootId?c.value=it.rootId:(it.type==="doc"||it.type==="NodeDocument")&&it.id&&(c.value=it.id),X.value=it.attrs[Ut]||"",R.value=it.attrs[Ee]||"",O.value=it.attrs[Oi]||"",z.value=it.attrs[Cn]||"",A.value=!!it.isImage},updateDocument(it){v.value=it,c.value=it.docId},openImportDialog(){n.value=!0},setCurrentDocId(it){c.value=it}}),(it,yt)=>(nt(),ot("div",sy,[h("div",ry,[h("div",ly,[(nt(),ot("svg",ay,[...yt[2]||(yt[2]=[h("rect",{x:"2",y:"3",width:"20",height:"14",rx:"2"},null,-1),h("line",{x1:"8",y1:"21",x2:"16",y2:"21"},null,-1),h("line",{x1:"12",y1:"17",x2:"12",y2:"21"},null,-1)])])),yt[3]||(yt[3]=h("span",null,"演示配置",-1))]),h("div",cy,[h("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"导入 Slidev 演示文档 (.md / .zip)",onClick:yt[0]||(yt[0]=It=>n.value=!0)},[dt(ut,{name:"import"}),yt[4]||(yt[4]=h("span",null,"导入",-1))]),h("button",{class:"spm-icon-btn is-primary b3-tooltips b3-tooltips__s","aria-label":"在下方分屏开启幻灯片预览 (Alt+P)",onClick:Ws},[dt(ut,{name:"split-preview"}),yt[5]||(yt[5]=h("span",null,"分屏预览",-1))])])]),h("div",dy,[h("div",uy,[h("span",{class:At(["spm-target-tag",N.value])},_t(I.value),3),h("span",{class:"spm-target-id b3-tooltips b3-tooltips__s","aria-label":S.value||"点击复制 ID: "+(s.value||c.value),onClick:x},[dt(ut,{name:"copy"}),h("span",null,"#"+_t(j.value),1)],8,fy)]),k.value?(nt(),ot("span",py,"● "+_t(k.value),1)):Ot("",!0)]),J.value?(nt(),ot("div",{key:0,class:"spm-context-quote",title:a.value},_t(J.value),9,hy)):Ot("",!0),h("div",my,[B.value?(nt(),Le(Ag,{key:0,"page-layout":y.value,"page-layout-ratio":Y.value,"detected-sb-ratio":ct.value,"detected-sb-info":P.value,"page-transition":V.value,"page-background":X.value,"page-spacing":U.value,"page-image":R.value,"page-notes":tt.value,"page-index":st.value,"onUpdate:pageLayout":Na,"onUpdate:pageLayoutRatio":Fa,onApplySuperBlockLayout:Us,onResetSuperblockRatio:ja,"onUpdate:pageTransition":Ua,"onUpdate:pageBackground":Wa,"onUpdate:pageSpacing":qa,"onUpdate:pageImage":Va,onAddNoteBlock:bt(Lo),onLocateNoteBlock:bt(Do),onGenerateNotes:bt(Fn),onBatchAppendNotes:bt(Ni),onBatchDeleteNotes:bt($a),"is-batch-processing":bt(wi),onInsertDividerAfter:bt(js),onDeleteDivider:bt(Oa)},null,8,["page-layout","page-layout-ratio","detected-sb-ratio","detected-sb-info","page-transition","page-background","page-spacing","page-image","page-notes","page-index","onAddNoteBlock","onLocateNoteBlock","onGenerateNotes","onBatchAppendNotes","onBatchDeleteNotes","is-batch-processing","onInsertDividerAfter","onDeleteDivider"])):s.value&&!H.value?(nt(),Le(f1,{key:1,"elem-click":C.value,"elem-motion":D.value,"elem-slot":p.value,"elem-shiki-lines":O.value,"elem-max-height":z.value,"is-code-block":E.value,"is-image":w.value,"is-video":F.value,"is-super-block":rt.value,"detected-sb-info":P.value,"video-autoplay":_.value,"video-loop":$.value,"video-muted":L.value,"video-controls":G.value,"has-block-attrs":pt.value,"is-note":gt.value,"image-role":lt.value,"current-slide-layout":M.value,"parent-elem-click":f.value,"parent-container-slot":b.value,"parent-container-id":d.value,onToggleNote:bt(zi),onToggleElemClick:bt(Ia),onToggleVideoAutoplay:bt(Nt),onToggleVideoLoop:bt(Ge),onToggleVideoMuted:bt(se),onToggleVideoControls:bt(Xt),"onUpdate:imageRole":bt(ki),"onUpdate:elemClick":bt(Aa),"onUpdate:elemMotion":bt(Ba),"onUpdate:elemSlot":bt(Ta),"onUpdate:elemShikiLines":bt(Ea),"onUpdate:elemMaxHeight":bt(Ma),onApplySuperBlockLayout:Us,onApplySuperBlockRatio:Ha,onInsertDividerBefore:bt(Pa),onInsertDividerAfter:bt(js),onSetTwoColsContrast:bt(La),onClearBlockAttrs:bt(Da)},null,8,["elem-click","elem-motion","elem-slot","elem-shiki-lines","elem-max-height","is-code-block","is-image","is-video","is-super-block","detected-sb-info","video-autoplay","video-loop","video-muted","video-controls","has-block-attrs","is-note","image-role","current-slide-layout","parent-elem-click","parent-container-slot","parent-container-id","onToggleNote","onToggleElemClick","onToggleVideoAutoplay","onToggleVideoLoop","onToggleVideoMuted","onToggleVideoControls","onUpdate:imageRole","onUpdate:elemClick","onUpdate:elemMotion","onUpdate:elemSlot","onUpdate:elemShikiLines","onUpdate:elemMaxHeight","onInsertDividerBefore","onInsertDividerAfter","onSetTwoColsContrast","onClearBlockAttrs"])):(nt(),Le(Y1,{key:2,"doc-theme":K.value,"doc-aspect-ratio":q.value,"doc-default-transition":et.value,"doc-spacing":at.value,"onUpdate:docTheme":Ka,"onUpdate:docAspectRatio":Ga,"onUpdate:docDefaultTransition":Za,"onUpdate:docSpacing":Ya,onOpenBottomPreview:Ws,onOpenPresenter:Ja,onAiAutoSplit:Xa,onExportHtml:bt(Ra),onExportPdf:bt(za)},null,8,["doc-theme","doc-aspect-ratio","doc-default-transition","doc-spacing","onExportHtml","onExportPdf"]))]),n.value?(nt(),Le(ey,{key:1,onClose:yt[1]||(yt[1]=It=>n.value=!1),onSuccess:o})):Ot("",!0)]))}}),Nn=new Fs;let gi=null,We=null;function vy(t,e){gi&&_a(),gi=ta(Bm),gi.provide("plugin",e),gi.provide("sandboxBridge",Nn);const i=gi.mount(t);return We=i,i}function _a(t){gi&&(gi.unmount(),gi=null,We=null)}let vi=null,Se=null;function by(t,e){vi&&Ca(),vi=ta(gy),vi.provide("plugin",e),vi.provide("sandboxBridge",Nn);const i=vi.mount(t);return Se=i,i}function Ca(t){vi&&(vi.unmount(),vi=null,Se=null)}function yy(t,e){Se!=null&&Se.updateDocument&&Se.updateDocument(t),We!=null&&We.updateDocument?We.updateDocument(t,e):Nn.updateSlides(t.slides,t.config,t.fullMarkdown)}function ms(t){We!=null&&We.navigateToBlock?We.navigateToBlock(t):Nn.highlightElement(t)}function io(t){Se!=null&&Se.setActiveBlock&&Se.setActiveBlock(t)}function ky(){return Se!=null&&Se.openImportDialog?(Se.openImportDialog(),!0):!1}function wy(t,e){const i=[];let o=0;for(let s=0;s<t.length;s++){const l=t[s];if(bo(l)){o=0;continue}const r=l.markdown||l.content||"";if(!(s===0)){if(l.type==="h"&&(l.subType==="h1"||r.startsWith("# "))){i.push({blockId:l.id,recommendedLayout:"cover",reason:"检测到一级核心章节标题，建议作为新幻灯片封面/大章"}),o=0;continue}if(l.type==="h"&&(l.subType==="h2"||r.startsWith("## "))){i.push({blockId:l.id,recommendedLayout:"default",reason:"检测到二级分论点标题，建议开启新页"}),o=0;continue}}if(o++,o>=6&&s<t.length-1){const c=t[s+1];bo(c)||(i.push({blockId:c.id,recommendedLayout:"default",reason:"当前页已达容量上限 (避免信息超载)，建议在此分页"}),o=0)}}return i}const xy=[{id:"slidev-cover",name:"幻灯片 - 封面页 (Cover)",open:!0,attrs:[{key:Bi,value:"true"},{key:ht,value:"cover"},{key:te,value:"fade"}]},{id:"slidev-two-cols",name:"幻灯片 - 双栏对比 (Two Columns)",open:!0,attrs:[{key:Bi,value:"true"},{key:ht,value:"two-cols"},{key:te,value:"slide-left"}]},{id:"slidev-fact",name:"幻灯片 - 大字报与核心指标 (Fact)",open:!0,attrs:[{key:Bi,value:"true"},{key:ht,value:"fact"},{key:te,value:"zoom"}]},{id:"slidev-intro",name:"幻灯片 - 章节导引与作者 (Intro)",open:!0,attrs:[{key:Bi,value:"true"},{key:ht,value:"intro"},{key:te,value:"slide-up"}]},{id:"slidev-quote",name:"幻灯片 - 金句与强调 (Quote)",open:!0,attrs:[{key:Bi,value:"true"},{key:ht,value:"quote"},{key:te,value:"fade"}]},{id:"slidev-elem-click",name:"元素 - 顺延逐步呈现 (v-click)",open:!0,attrs:[{key:jt,value:"+1"}]},{id:"slidev-elem-click-hide",name:"元素 - 隐藏直到激活 (v-click:hide)",open:!0,attrs:[{key:jt,value:"hide"}]},{id:"slidev-elem-slot-right",name:"元素 - 双栏右栏归属 (Slot: Right)",open:!0,attrs:[{key:Ct,value:"right"}]},{id:"slidev-shiki-lines",name:"代码 - 逐行聚光高亮 (Shiki)",open:!0,attrs:[{key:Oi,value:"1-3"}]}];class Jo{getPresetTemplates(){return xy}buildScanSlidevBlocksSql(e="custom-slidev-"){return`SELECT block_id, name, value FROM attributes WHERE name LIKE '${e}%' ORDER BY block_id ASC`}buildTransitionStatsSql(){return`SELECT value, count(1) as count FROM attributes WHERE name = '${te}' GROUP BY value ORDER BY count DESC`}async batchUpdateTransitions(e,i,n,o){const s=`SELECT block_id FROM attributes WHERE name = '${te}' AND value = '${e}'`,l=await n(s);let r=0;if(Array.isArray(l))for(const a of l){const c=a.block_id||a.blockId;c&&(await o(c,{[te]:i}),r++)}return{updatedCount:r}}async batchUpdateLayout(e,i,n,o){const s=`SELECT block_id FROM attributes WHERE name = 'custom-slidev-layout' AND value = '${e}'`,l=await n(s);let r=0;if(Array.isArray(l))for(const a of l){const c=a.block_id||a.blockId;c&&(await o(c,{"custom-slidev-layout":i}),r++)}return{updatedCount:r}}exportTemplatesJson(){const e=this.getPresetTemplates();return JSON.stringify({templates:e,counter:e.length},null,2)}formatTransitionSummary(e){return!e||e.length===0?"全库目前暂无已设置 Slidev 转场效果的块":`全库 Slidev 转场分布统计：${e.map(n=>`${n.value}: ${n.count} 个`).join("，")}`}}function Sy(t){t.addCommand({langKey:"slidevPresentation",langText:"Slidev: 在文档下方开启分屏演示预览",hotkey:"⌥P",enabled:()=>!0,execute:()=>{t.openBottomPreviewTab()}}),t.addCommand({langKey:"slidevImport",langText:"Slidev: 导入 Slidev 演示文档 (.md / .zip)",hotkey:"⌥I",enabled:()=>!0,execute:()=>{ky()||ft.showMessage("请先在右侧栏打开「Slidev 演示配置」Dock 面板以呼起导入窗口")}}),t.addCommand({langKey:"slidevInitAttrs",langText:"Slidev: 初始化当前文档演示属性",hotkey:"",enabled:()=>!0,execute:async()=>{if(!t.currentDocId){const e=document.querySelector(".protyle-content[data-doc-id]");t.currentDocId=(e==null?void 0:e.getAttribute("data-doc-id"))||""}t.currentDocId&&(await Et(t.currentDocId,{"custom-slidev-theme":"default","custom-slidev-aspect-ratio":"16/9","custom-slidev-default-transition":"slide-left"}),ft.showMessage("已为当前文档初始化 Slidev 演示属性"),t.compileCurrentDocument(t.currentDocId))}}),t.addCommand({langKey:"slidevAiSplit",langText:"Slidev AI: 智能大纲断页建议与自动分页",hotkey:"",enabled:()=>!0,execute:async()=>{if(!t.currentDocId){const s=document.querySelector(".protyle-content[data-doc-id]");t.currentDocId=(s==null?void 0:s.getAttribute("data-doc-id"))||""}if(!t.currentDocId){ft.showMessage("请先打开一篇思源笔记文档");return}const e=await no(t.currentDocId).catch(()=>[]);if(!e||e.length===0){ft.showMessage("当前文档无内容，无需断页");return}const i=e.map(s=>({id:s.id,type:s.type,subType:s.subType,content:s.content||"",markdown:s.markdown||""})),n=wy(i);if(n.length===0){ft.showMessage("AI 分析完毕：当前文档篇幅合理，暂无分页建议");return}ft.showMessage(`AI 分析完毕：发现 ${n.length} 处建议分页点，正在自动插入分页分割线...`);let o=0;for(const s of n)try{await Ii("markdown","---",void 0,s.blockId),await Et(s.blockId,{"custom-slidev-layout":s.recommendedLayout}),o++}catch(l){console.warn("Failed to insert divider:",l)}ft.showMessage(`已成功在 ${o} 处插入分页线并重新编译`),t.compileCurrentDocument(t.currentDocId)}}),t.addCommand({langKey:"slidevAiNotes",langText:"Slidev AI: 自动为当前文档生成演讲者提词卡 (Notes)",hotkey:"",enabled:()=>!0,execute:async()=>{var a,c,u,m;if(!t.currentDocId){const g=document.querySelector(".protyle-content[data-doc-id]");t.currentDocId=(g==null?void 0:g.getAttribute("data-doc-id"))||""}if(!t.currentDocId){ft.showMessage("请先打开一篇思源笔记文档");return}ft.showMessage("正在调用思源 AI 提炼演讲者口播提词...");const e=await no(t.currentDocId).catch(()=>[]),i={startBlockId:t.currentDocId,blocks:e.map(g=>({id:g.id,type:g.type,content:g.content||"",rawMarkdown:g.markdown||""})),rawMarkdown:""},s=`> [!NOTE] 💡 演讲备注
${(await ny(i,Fr)).split(/\r?\n/).map(g=>`> ${g}`).join(`
`)}
{: custom-slidev-note="true"}`,l=await Xo("markdown",s,t.currentDocId).catch(()=>null),r=((u=(c=(a=l==null?void 0:l[0])==null?void 0:a.doOperations)==null?void 0:c[0])==null?void 0:u.id)||((m=l==null?void 0:l[0])==null?void 0:m.id);r&&(await Et(r,{"custom-slidev-note":"true"}),Lt.setBlockAttrOverride(r,{"custom-slidev-note":"true"}),Pi(r,t.app)),ft.showMessage("已成功生成口播提词卡并插入为正文讲稿备注块"),t.compileCurrentDocument(t.currentDocId)}}),t.addCommand({langKey:"slidevBatchTransitions",langText:"Slidev 协同: 统计全库转场效果分布",hotkey:"",enabled:()=>!0,execute:async()=>{const e=new Jo,i=e.buildTransitionStatsSql(),n=await wn(i).catch(()=>[]),o=e.formatTransitionSummary(n||[]);ft.showMessage(o)}}),t.addCommand({langKey:"slidevExportTemplates",langText:"Slidev 协同: 复制 Slidev 预设属性模板至剪贴板",hotkey:"",enabled:()=>!0,execute:async()=>{const i=new Jo().exportTemplatesJson();typeof navigator<"u"&&navigator.clipboard?(await navigator.clipboard.writeText(i),ft.showMessage("已将 Slidev 属性模板 JSON 复制至剪贴板，可直接导入属性管家")):ft.showMessage(`已生成模板数据（请在控制台查看）：
`+i)}}),t.addCommand({langKey:"slidevBatchReplaceTransition",langText:"Slidev 协同: 批量替换全库淡入淡出转场为滑动 (fade -> slide-left)",hotkey:"",enabled:()=>!0,execute:async()=>{const i=await new Jo().batchUpdateTransitions("fade","slide-left",n=>wn(n).catch(()=>[]),(n,o)=>Et(n,o));ft.showMessage(`全库批量替换完成：已将 ${i.updatedCount} 处 fade 转场更新为 slide-left`),t.compileCurrentDocument()}}),t.addCommand({langKey:"slidevPresenterMode",langText:"Slidev: 打开双屏演讲者控制台 (Presenter Mode)",hotkey:"⌥M",enabled:()=>!0,execute:()=>{typeof window<"u"&&window.open("/plugins/siyuan-slidev/slidev-client/presenter.html","SlidevPresenter","width=1200,height=800")}}),t.addCommand({langKey:"slidevExportCliMd",langText:"Slidev Pro: 导出 Slidev 标准 slides.md 文档 (下载到本地)",hotkey:"",enabled:()=>!0,execute:async()=>{if(t.latestCompiledDoc||await t.compileCurrentDocument(),!t.latestCompiledDoc){ft.showMessage("请先打开并放映一篇思源笔记文档");return}t.cliBridge.downloadSlidesMd(t.latestCompiledDoc,`slides-${t.currentDocId||"demo"}.md`)&&ft.showMessage("已生成标准 Slidev Markdown 并触发下载，可在本地使用 npx @slidev/cli 运行")}}),t.addCommand({langKey:"slidevProbeCliDevServer",langText:"Slidev Pro: 检测本地 Slidev CLI DevServer 状态 (localhost:3030)",hotkey:"",enabled:()=>!0,execute:async()=>{ft.showMessage("正在探测本地 Slidev CLI DevServer (http://localhost:3030)..."),await t.cliBridge.probeServer(1500)?ft.showMessage("🟢 本地 Slidev CLI DevServer 运行正常！可直接在浏览器访问 http://localhost:3030"):ft.showMessage("⚪ 未检测到运行中的本地 Slidev CLI DevServer (端口 3030 未开启)")}}),t.addCommand({langKey:"slidevSyncToCliWorkspace",langText:"Slidev Pro: 同步 slides.md 至思源工作空间存储目录",hotkey:"",enabled:()=>!0,execute:async()=>{if(t.latestCompiledDoc||await t.compileCurrentDocument(),!t.latestCompiledDoc){ft.showMessage("请先打开并放映一篇思源笔记文档");return}const e=await t.cliBridge.syncToWorkspaceFile(t.latestCompiledDoc,"/data/storage/petal/siyuan-slidev/slides.md",Qo);e.success?ft.showMessage(`已成功同步最新 slides.md 至工作空间：${e.path}`):ft.showMessage(`同步失败：${e.error}`)}})}class _y{getActiveDocumentId(){if(typeof document>"u")return"";const e=document.querySelector(".layout__wnd--active .protyle-title[data-node-id]")||document.querySelector(".item--focus .protyle-title[data-node-id]")||document.querySelector(".protyle-title[data-node-id]"),i=e==null?void 0:e.getAttribute("data-node-id");if(i)return i;const n=document.querySelector(".protyle .protyle-title[data-node-id]"),o=n==null?void 0:n.getAttribute("data-node-id");if(o)return o;const s=document.querySelector("[data-doc-id]"),l=s==null?void 0:s.getAttribute("data-doc-id");return l||""}resolveDocIdFromElement(e,i=""){const n=e.closest(".protyle-title"),o=n==null?void 0:n.getAttribute("data-node-id");if(o)return o;const s=e.closest(".protyle"),l=s==null?void 0:s.querySelector(".protyle-title"),r=l==null?void 0:l.getAttribute("data-node-id");if(r)return r;const a=e.closest("[data-doc-id]"),c=a==null?void 0:a.getAttribute("data-doc-id");if(c)return c;const u=this.getActiveDocumentId();return u||i}async switchToDocGlobalInspector(e,i){var s;if(!e)return;let n=i||"";if(!n&&typeof document<"u"){const l=document.querySelector(`.protyle-title[data-node-id="${e}"] .protyle-title__input`)||document.querySelector(`.protyle[data-doc-id="${e}"] .protyle-title__input`)||document.querySelector(".protyle-title__input");n=((s=l==null?void 0:l.innerText)==null?void 0:s.trim())||""}const o=await Ye(e).catch(()=>({}));io({id:e,rootId:e,type:"doc",content:n,attrs:o,isDivider:!1,isCode:!1}),ms(e)}handleBlockClickedFromSlide(e,i,n,o){var a;if(!e)return!1;const s=Pi(e,i),l=document.querySelector(`.protyle-wysiwyg [data-node-id="${e}"]`)||document.querySelector(`[data-node-id="${e}"]`),r=(l==null?void 0:l.getAttribute("data-type"))||"";if(l)this.syncInspectorBlock(l,e,r,n,o);else{let c="",u="";if(o!=null&&o.slides){const m=o.slides.find(g=>{var d,b,f;return g.startBlockId===e||((d=g.blocks)==null?void 0:d.some(v=>v.id===e))||((b=g.allBlockIds)==null?void 0:b.includes(e))||((f=g.noteBlocks)==null?void 0:f.some(v=>v.id===e))});m!=null&&m.startBlockId&&(c=m.startBlockId),(a=m==null?void 0:m.frontmatter)!=null&&a.layout&&(u=m.frontmatter.layout)}Ye(e).then(async m=>{if(c&&!u){const g=Lt.getBlockAttrOverride(c);if(g!=null&&g[ht]||g!=null&&g["custom-slidev-layout"])u=g[ht]||g["custom-slidev-layout"]||"";else{const d=await Ye(c).catch(()=>({}))||{};u=d[ht]||d["custom-slidev-layout"]||"",d&&Object.keys(d).length>0&&Lt.setBlockAttrOverride(c,d)}}io({id:e,rootId:n,type:r||"NodeParagraph",attrs:m||{},pageDividerId:c,pageDividerLayout:u})}).catch(()=>{})}return s}async syncInspectorBlock(e,i,n,o,s){var V,X,R,U,W,tt,T,M;let l=e,r=i,a=n;const c=e.closest('[data-type="NodeCallout"]');if(c&&c!==e){const Y=c.getAttribute("data-node-id");if(Y){const Z=await Ye(Y).catch(()=>({}))||{},Q=Lt.getBlockAttrOverride(Y)||{},P={...Z,...Q};(P[ne]||P["slidev-note"])&&(l=c,r=Y,a="NodeCallout")}}const u=l.closest(".protyle-wysiwyg > [data-node-id]")||l,m=(u==null?void 0:u.getAttribute("data-node-id"))||r,g=a==="NodeThematicBreak"||a==="tb"||a==="thematic-break"||(u==null?void 0:u.getAttribute("data-type"))==="NodeThematicBreak"||(u==null?void 0:u.getAttribute("data-type"))==="tb"||!!((V=u==null?void 0:u.classList)!=null&&V.contains("hr")),d=a==="NodeCodeBlock",b=((X=l.innerText)==null?void 0:X.trim())||"",f=await Ye(r).catch(()=>({}))||{},v=Lt.getBlockAttrOverride(r)||{},k={...f,...v};let S="",x="";if(g)S=r,x=k[ht]||k["custom-slidev-layout"]||"";else{let Y=u.previousElementSibling;for(;Y;){const Z=Y.getAttribute("data-type");if(Z==="NodeThematicBreak"||Z==="tb"||(R=Y.classList)!=null&&R.contains("hr")){S=Y.getAttribute("data-node-id")||"";break}Y=Y.previousElementSibling}}if(s!=null&&s.slides){const Y=[r,m];let Z=l.parentElement;for(;Z&&!Z.classList.contains("protyle-wysiwyg");){const P=Z.getAttribute("data-node-id");P&&!Y.includes(P)&&Y.push(P),Z=Z.parentElement}const Q=s.slides.find(P=>{var ct,rt,st;return Y.includes(P.startBlockId)||((ct=P.blocks)==null?void 0:ct.some(gt=>Y.includes(gt.id)))||((rt=P.allBlockIds)==null?void 0:rt.some(gt=>Y.includes(gt)))||((st=P.noteBlocks)==null?void 0:st.some(gt=>Y.includes(gt.id)))});Q&&(!S&&Q.startBlockId&&(S=Q.startBlockId),!x&&((U=Q.frontmatter)!=null&&U.layout)&&(x=Q.frontmatter.layout))}if(S){const Y=Lt.getBlockAttrOverride(S);if(Y&&(ht in Y||"custom-slidev-layout"in Y)&&(x=Y[ht]||Y["custom-slidev-layout"]||""),!x&&(s!=null&&s.slides)){const Z=s.slides.find(Q=>Q.startBlockId===S);(W=Z==null?void 0:Z.frontmatter)!=null&&W.layout&&(x=Z.frontmatter.layout)}if(!x){const Z=await Ye(S).catch(()=>({}))||{};x=Z[ht]||Z["custom-slidev-layout"]||"",Z&&Object.keys(Z).length>0&&Lt.setBlockAttrOverride(S,Z)}Zt(S,{[ht]:x||""})}else if(o){const Y=Lt.getBlockAttrOverride(o);Y&&(ht in Y||"custom-slidev-layout"in Y)?x=Y[ht]||Y["custom-slidev-layout"]||"":!x&&((M=(T=(tt=s==null?void 0:s.slides)==null?void 0:tt[0])==null?void 0:T.frontmatter)!=null&&M.layout)&&(x=s.slides[0].frontmatter.layout)}const B=l.getAttribute(ht)||l.getAttribute("custom-slidev-layout"),E=k[ht]||k["custom-slidev-layout"]||"";B&&B!==E&&Zt(r,{[ht]:E});const A=l.getAttribute(qt)||l.getAttribute("custom-slidev-role"),w=k[qt]||k["custom-slidev-role"]||"";A&&A!==w&&Zt(r,{[qt]:w});let F="",H="",j="";const J=l.closest('[data-type="NodeListItem"]');if(J&&J!==l){const Y=J.getAttribute("data-node-id");if(Y){F=Y;const Z=await Ye(Y).catch(()=>({}))||{},Q=Lt.getBlockAttrOverride(Y)||{},P={...Z,...Q};H=P[Ct]||"",j=P[jt]||"";const ct=P[ht]||P["custom-slidev-layout"]||"",rt=J.getAttribute(ht)||J.getAttribute("custom-slidev-layout");rt&&rt!==ct&&Zt(Y,{[ht]:ct});const st=P[qt]||P["custom-slidev-role"]||"",gt=J.getAttribute(qt)||J.getAttribute("custom-slidev-role");gt&&gt!==st&&Zt(Y,{[qt]:st})}}const I=!!l.querySelector("img, span[data-type='img']"),N=(l.innerText||"").replace(/[\r\n\t\s]+/g," ").trim(),y=I&&N.length<=50;io({id:r,rootId:o,type:a,content:b,attrs:k,isDivider:g,isCode:d,isImage:y,topBlockId:m,pageDividerId:S,pageDividerLayout:x,parentContainerId:F,parentContainerSlot:H,parentContainerClicks:j})}patchThematicBreakTransactions(e){if((e==null?void 0:e.cmd)==="transactions"&&Array.isArray(e.data)){for(const i of e.data)if(Array.isArray(i==null?void 0:i.doOperations)){for(const n of i.doOperations)if((n==null?void 0:n.action)==="updateAttrs"&&n.id&&n.data){const o=n.data.old||{},s=n.data.new||{},l={};for(const r of Object.keys(o))r in s||(l[r]="");for(const[r,a]of Object.entries(s))l[r]=String(a??"");Zt(n.id,l),Lt.setBlockAttrOverride(n.id,l)}}}}purgeStaleDomSlidevAttrs(e){var o,s,l;if(typeof document>"u"||!e)return;const i=new Map;if(Array.isArray(e.slides))for(const r of e.slides){if(r.startBlockId){const a=i.get(r.startBlockId)||{};(o=r.frontmatter)!=null&&o.layout&&(a[ht]=r.frontmatter.layout),i.set(r.startBlockId,a)}if(Array.isArray(r.blocks)){for(const a of r.blocks)if(a.id){const c=i.get(a.id)||{};(s=a.ial)!=null&&s[ht]&&(c[ht]=a.ial[ht]),(l=a.ial)!=null&&l[qt]&&(c[qt]=a.ial[qt]),Object.keys(c).length>0&&i.set(a.id,c)}}}const n=Lt.getAllAttrOverrides();for(const[r,a]of n.entries()){const c=i.get(r)||{};a[ht]!==void 0&&(c[ht]=a[ht]),a[qt]!==void 0&&(c[qt]=a[qt]),i.set(r,c)}Lp(i)}}const $i=new _y,Cy=`<symbol id="iconSlidev" viewBox="0 0 1024 1024">
  <path fill="currentColor" d="M128 160h768c35.3 0 64 28.7 64 64v480c0 35.3-28.7 64-64 64H128c-35.3 0-64-28.7-64-64V224c0-35.3 28.7-64 64-64z m64 64v480h640V224H192z m128 640h384v64H320z"/>
  <path fill="currentColor" d="M416 336l256 144-256 144z"/>
</symbol>`,$y="slidev-dock",Rr="slidev-preview-tab",zr=Hu;class Iy extends ft.Plugin{constructor(){super(...arguments);xt(this,"isMobile",!1);xt(this,"currentDocId","");xt(this,"latestCompiledDoc",null);xt(this,"cliBridge",new Rs);xt(this,"debounceTimer",null);xt(this,"activeCursorBlockId","");xt(this,"onSwitchProtyleBound",this.onSwitchProtyle.bind(this));xt(this,"onWsMainBound",this.onWsMain.bind(this));xt(this,"onBlockClickedBound",this.onBlockClickedFromSlide.bind(this));xt(this,"onClickEditorTitleIconBound",this.onClickEditorTitleIcon.bind(this));xt(this,"onEditorClickBound",this.onEditorClick.bind(this));xt(this,"onSelectionChangeBound",this.onSelectionChange.bind(this));xt(this,"onClickEditorContentBound",this.onClickEditorContent.bind(this))}async onload(){const i=ft.getFrontend();this.isMobile=i==="mobile"||i==="browser-mobile",await this.loadGlobalSettings(),this.addIcons(Cy),this.addTopBar({id:"slidev-topbar-play",icon:"iconSlidev",title:"Slidev 演示 (下方分屏)",position:"right",callback:()=>{this.openBottomPreviewTab()}}),Sy(this);const n=this;if(this.addTab({type:Rr,init(){vy(this.element,n)},destroy(){_a(this.element)}}),this.addDock({config:{position:"RightTop",size:{width:320,height:0},icon:"iconSlidev",title:"Slidev 演示配置"},data:{},type:$y,init(){by(this.element,n)},destroy(){Ca(this.element)}}),this.eventBus&&typeof this.eventBus.emit!="function"&&(this.eventBus.emit=(o,s)=>{try{typeof window<"u"&&window.dispatchEvent(new CustomEvent(`siyuan-event-${o}`,{detail:s}))}catch{}}),this.eventBus.on("switch-protyle",this.onSwitchProtyleBound),this.eventBus.on("ws-main",this.onWsMainBound),this.eventBus.on("slidev:request-compile",()=>this.compileCurrentDocument()),this.eventBus.on("slidev:block-clicked",this.onBlockClickedBound),this.eventBus.on("click-editortitleicon",this.onClickEditorTitleIconBound),this.eventBus.on("click-editorcontent",this.onClickEditorContentBound),typeof document<"u"&&(document.addEventListener("click",this.onEditorClickBound,!0),document.addEventListener("selectionchange",this.onSelectionChangeBound)),typeof document<"u"){const o=()=>{const s=this.getActiveDocumentId();s&&(s!==this.currentDocId&&(this.currentDocId=s),this.latestCompiledDoc||this.compileCurrentDocument(s))};setTimeout(o,300),setTimeout(o,1e3)}}async onDataChanged(i){await this.loadGlobalSettings(),this.currentDocId&&await this.compileCurrentDocument(this.currentDocId)}async loadGlobalSettings(){try{const i=await this.loadData(zr),n=ju(i);return Ei(n),n}catch{return Ei(tn),tn}}async saveGlobalSettings(i){const n=Mo(),o=Ei({...n,...i||{}});try{await this.saveData(zr,o)}catch(l){console.error("保存 Slidev 全局配置失败",l)}const s=this.currentDocId||this.getActiveDocumentId();return s&&await this.compileCurrentDocument(s),o}onunload(){this.debounceTimer&&(window.clearTimeout(this.debounceTimer),this.debounceTimer=null),this.eventBus.off("switch-protyle",this.onSwitchProtyleBound),this.eventBus.off("ws-main",this.onWsMainBound),this.eventBus.off("click-editortitleicon",this.onClickEditorTitleIconBound),this.eventBus.off("click-editorcontent",this.onClickEditorContentBound),typeof document<"u"&&(document.removeEventListener("click",this.onEditorClickBound,!0),document.removeEventListener("selectionchange",this.onSelectionChangeBound)),Nn.detach()}async openBottomPreviewTab(){this.currentDocId||(this.currentDocId=this.getActiveDocumentId()),await ft.openTab({app:this.app,custom:{id:this.name+Rr,title:"Slidev 演示预览",icon:"iconSlidev",data:{docId:this.currentDocId}},position:"bottom"}),this.currentDocId&&this.compileCurrentDocument(this.currentDocId)}onClickEditorTitleIcon(i){var l;const n=i.detail,o=n==null?void 0:n.menu,s=((l=n==null?void 0:n.data)==null?void 0:l.id)||this.currentDocId;!o||!s||o.addItem({icon:"iconSlidev",label:"Slidev 全局演示配置",submenu:[{label:"初始化演示属性 (custom-slidev-*)",click:async()=>{await Et(s,{"custom-slidev-theme":"default","custom-slidev-aspect-ratio":"16/9","custom-slidev-default-transition":"slide-left"}),ft.showMessage("已为当前文档初始化 Slidev 演示属性"),this.compileCurrentDocument(s)}},{type:"separator"},{label:"主题: 默认 (default)",click:async()=>{await Et(s,{"custom-slidev-theme":"default"}),ft.showMessage("已切换为 default 主题"),this.compileCurrentDocument(s)}},{label:"主题: 优雅衬线 (seriph)",click:async()=>{await Et(s,{"custom-slidev-theme":"seriph"}),ft.showMessage("已切换为 seriph 主题"),this.compileCurrentDocument(s)}},{label:"主题: 苹果极简 (apple-basic)",click:async()=>{await Et(s,{"custom-slidev-theme":"apple-basic"}),ft.showMessage("已切换为 apple-basic 主题"),this.compileCurrentDocument(s)}},{type:"separator"},{label:"画幅: 16 / 9 (宽屏)",click:async()=>{await Et(s,{"custom-slidev-aspect-ratio":"16/9"}),ft.showMessage("已切换画幅为 16/9"),this.compileCurrentDocument(s)}},{label:"画幅: 4 / 3 (标屏)",click:async()=>{await Et(s,{"custom-slidev-aspect-ratio":"4/3"}),ft.showMessage("已切换画幅为 4/3"),this.compileCurrentDocument(s)}}]})}async onSwitchProtyle(i){var s,l;const n=(s=i.detail)==null?void 0:s.protyle,o=(l=n==null?void 0:n.block)==null?void 0:l.rootID;if(o&&o!==this.currentDocId){this.currentDocId=o,this.activeCursorBlockId=o;const r=await Ye(o).catch(()=>({}));io({id:o,rootId:o,type:"doc",attrs:r}),this.compileCurrentDocument(o)}}onClickEditorContent(i){var s,l;const n=i==null?void 0:i.detail;if(!n)return;const o=(l=(s=n.protyle)==null?void 0:s.block)==null?void 0:l.rootID;o&&(!this.currentDocId||this.currentDocId!==o)&&(this.currentDocId=o),n.event&&this.onEditorClick(n.event)}getActiveDocumentId(){return $i.getActiveDocumentId()}resolveDocIdFromElement(i){return $i.resolveDocIdFromElement(i,this.currentDocId)}async switchToDocGlobalInspector(i,n){i&&(this.activeCursorBlockId=i,this.currentDocId=i,await $i.switchToDocGlobalInspector(i,n))}onWsMain(i){const n=i.detail;n&&($i.patchThematicBreakTransactions(n),this.debounceTimer&&window.clearTimeout(this.debounceTimer),this.debounceTimer=window.setTimeout(()=>{this.compileCurrentDocument()},150))}handleBlockClickedFromSlide(i,n){return i?(this.activeCursorBlockId=i,$i.handleBlockClickedFromSlide(i,this.app,this.currentDocId,this.latestCompiledDoc)):!1}onBlockClickedFromSlide(i){const n=(i==null?void 0:i.detail)||i;n!=null&&n.blockId&&this.handleBlockClickedFromSlide(n.blockId,n.page)}onEditorClick(i){const n=i.target;if(!n)return;const o=n.closest(".protyle-title")||n.closest(".protyle-background");if(!!(o||n.closest(".protyle-content")&&!n.closest(".protyle-wysiwyg")&&!n.closest(".protyle-breadcrumb")&&!n.closest(".protyle-gutters"))){const u=this.resolveDocIdFromElement(n);if(u&&this.activeCursorBlockId!==u){const m=o||document.querySelector(`.protyle-title[data-node-id="${u}"]`)||document.querySelector(`.protyle[data-doc-id="${u}"] .protyle-title`),g=m==null?void 0:m.querySelector(".protyle-title__input"),d=((g==null?void 0:g.innerText)||(m==null?void 0:m.innerText)||"").trim();this.switchToDocGlobalInspector(u,d)}return}if(!n.closest(".protyle-wysiwyg"))return;const r=n.closest("[data-node-id]");if(!r)return;const a=r.getAttribute("data-node-id"),c=r.getAttribute("data-type")||"";a&&(this.currentDocId||(this.currentDocId=this.resolveDocIdFromElement(n)||""),this.currentDocId&&!this.latestCompiledDoc&&this.compileCurrentDocument(this.currentDocId),a!==this.activeCursorBlockId&&(this.activeCursorBlockId=a,ms(a)),this.syncInspectorBlock(r,a,c))}onSelectionChange(){if(typeof window>"u")return;const i=window.getSelection();if(!i||i.rangeCount===0)return;const n=i.anchorNode;if(!n)return;const o=n.nodeType===Node.ELEMENT_NODE?n:n.parentElement;if(!o)return;const s=o.closest(".protyle-title");if(!!(s||o.closest(".protyle-content")&&!o.closest(".protyle-wysiwyg"))){const u=this.resolveDocIdFromElement(o);if(u&&this.activeCursorBlockId!==u){const m=s||document.querySelector(`.protyle-title[data-node-id="${u}"]`)||document.querySelector(`.protyle[data-doc-id="${u}"] .protyle-title`),g=m==null?void 0:m.querySelector(".protyle-title__input"),d=((g==null?void 0:g.innerText)||(m==null?void 0:m.innerText)||"").trim();this.switchToDocGlobalInspector(u,d)}return}if(!o.closest(".protyle-wysiwyg"))return;const r=o.closest("[data-node-id]"),a=r==null?void 0:r.getAttribute("data-node-id"),c=(r==null?void 0:r.getAttribute("data-type"))||"";r&&a&&(this.currentDocId||(this.currentDocId=this.resolveDocIdFromElement(o)||""),this.currentDocId&&!this.latestCompiledDoc&&this.compileCurrentDocument(this.currentDocId),a!==this.activeCursorBlockId&&(this.activeCursorBlockId=a,ms(a)),this.syncInspectorBlock(r,a,c))}async syncInspectorBlock(i,n,o){await $i.syncInspectorBlock(i,n,o,this.currentDocId,this.latestCompiledDoc)}async compileCurrentDocument(i){let n=i||this.currentDocId;if(!n){const o=this.getActiveDocumentId();if(o)this.currentDocId=o,n=o;else return}try{const o=await Lt.compile(n);this.latestCompiledDoc=o,yy(o,n),this.purgeStaleDomSlidevAttrs(o)}catch(o){console.error("[SiYuanSlidev] Failed to compile document:",o)}}purgeStaleDomSlidevAttrs(i){$i.purgeStaleDomSlidevAttrs(i)}}module.exports=Iy;
