"use strict";var xc=Object.create;var Ho=Object.defineProperty;var Sc=Object.getOwnPropertyDescriptor;var _c=Object.getOwnPropertyNames;var Cc=Object.getPrototypeOf,$c=Object.prototype.hasOwnProperty;var Ic=(e,t,i)=>t in e?Ho(e,t,{enumerable:!0,configurable:!0,writable:!0,value:i}):e[t]=i;var Ec=(e,t,i,n)=>{if(t&&typeof t=="object"||typeof t=="function")for(let o of _c(t))!$c.call(e,o)&&o!==i&&Ho(e,o,{get:()=>t[o],enumerable:!(n=Sc(t,o))||n.enumerable});return e};var Vn=(e,t,i)=>(i=e!=null?xc(Cc(e)):{},Ec(t||!e||!e.__esModule?Ho(i,"default",{value:e,enumerable:!0}):i,e));var ye=(e,t,i)=>Ic(e,typeof t!="symbol"?t+"":t,i);const me=require("siyuan");async function mt(e,t){const i=await me.fetchSyncPost(e,t);return i.code===0?i.data:null}async function Tc(){return mt("/api/notebook/lsNotebooks","")}async function Ac(e,t,i){return mt("/api/filetree/createDocWithMd",{notebook:e,path:t,markdown:i})}async function Zr(e,t){const i=new FormData;i.append("assetsDirPath",e);for(const o of t)i.append("file[]",o);return mt("/api/asset/upload",i)}async function Ti(e,t,i,n,o){return mt("/api/block/insertBlock",{dataType:e,data:t,nextID:i,previousID:n,parentID:o})}async function ss(e,t,i){return mt("/api/block/appendBlock",{dataType:e,data:t,parentID:i})}async function or(e,t,i){return mt("/api/block/updateBlock",{dataType:e,data:t,id:i})}async function Yr(e){return mt("/api/block/deleteBlock",{id:e})}async function Bc(e){return mt("/api/block/getBlockKramdown",{id:e})}async function co(e){return mt("/api/block/getChildBlocks",{id:e})}async function Mc(e){return mt("/api/block/getDocBlocksOrders",{id:e})}async function Ne(e,t){return mt("/api/attr/setBlockAttrs",{id:e,attrs:t})}async function Cs(e){return mt("/api/attr/getBlockAttrs",{id:e})}async function en(e){return mt("/api/query/sql",{stmt:e})}async function rs(e,t,i){const n=new FormData;return n.append("path",e),n.append("isDir",t.toString()),n.append("modTime",Math.floor(Date.now()/1e3).toString()),n.append("file",i),mt("/api/file/putFile",n)}async function Jr(e){const t="/api/ai/chatGPT";try{const i=await mt(t,{msg:e});return typeof i=="string"&&i.trim().length>0?i.trim():i&&typeof i.content=="string"&&i.content.trim().length>0?i.content.trim():null}catch{return null}}async function Dc(){return mt("/api/storage/getInlineStyles","")}const Xr=/\(\(([0-9a-zA-Z-]+)(?:\s*(?:'([^']*)'|"([^"]*)"|([^\)]+?)))?\s*\)\)/g;function Lc(e){const t=[];if(!e)return t;const i=new RegExp(Xr.source,"g");let n;for(;(n=i.exec(e))!==null;){const o=n[2]??n[3]??n[4];t.push({fullMatch:n[0],blockId:n[1],anchorText:o?o.trim():void 0})}return t}function Oc(e,t){if(!e)return"";const i=new RegExp(Xr.source,"g");return e.replace(i,(n,o,s,l,r)=>{const a=(s??l??r??"").trim();if(t&&t[o]){const d=t[o].trim();return`<div class="slidev-block-ref" data-ref-id="${o}">${d}</div>`}const c=a||`Ref(${o.slice(0,8)})`;return`<a href="siyuan://blocks/${o}" data-ref-id="${o}" class="slidev-ref-tag">🔗 ${c}</a>`})}const Cn="custom-slidev-theme",$n="custom-slidev-aspect-ratio",Qr="custom-slidev-highlighter",In="custom-slidev-default-transition",el="custom-slidev-color-schema",ls="custom-slidev-spacing",Ii="custom-slidev-slide",ue="custom-slidev-layout",tt="custom-slidev-transition",je="custom-slidev-background",Bt="custom-slidev-image",Wi="custom-slidev-notes",Ui="custom-slidev-class",gn="custom-slidev-spacing",yt="custom-slidev-layout-ratio",Vi="custom-slidev-mask",Ki="custom-slidev-mask-ratio",qi="custom-slidev-mask-style",Gi="custom-slidev-mask-initial",Ze="custom-slidev-click",Kt="custom-slidev-motion",Oi="custom-slidev-shiki-lines",Ce="custom-slidev-slot",nt="custom-slidev-note",qe="custom-slidev-role",En="custom-slidev-max-height",Ei="custom-slidev-autoplay",uo="custom-slidev-loop",ji="custom-slidev-muted",fo="custom-slidev-controls",tl="background",po="image-left",ho="image-right";function Tn(e){return e==="cols-header"||e==="two-cols-header"||e==="three-cols-header"}function Rc(e){return e.markdown&&e.markdown.trim()?e.markdown.trim():e.content&&e.content.trim()?e.content.trim():""}function Pc(e){const t={};if(!e)return t;const i=e.replace(/^\{:\s*/,"").replace(/\s*\}$/,""),n=/([\w-]+)=(?:"([^"]*)"|'([^']*)'|(\S+))/g;let o;for(;(o=n.exec(i))!==null;){const s=o[1],l=o[2]??o[3]??o[4]??"";t[s]=l}return t}function il(e){if(!e)return!1;const t=e.trim();return t.startsWith("assets/")||t.startsWith("./assets/")||t.startsWith("/assets/")}function nl(e){const t=e.trim();return t.startsWith("./assets/")?t.slice(2):t.startsWith("/assets/")?t.slice(1):t}function Et(e,t){if(!il(e))return e;const i=nl(e);return t!=null&&t.base64Map&&t.base64Map[i]?t.base64Map[i]:t!=null&&t.baseUrl?`${t.baseUrl.replace(/\/+$/,"")}/${i}`:`/${i}`}function Nc(e,t){if(!e)return"";let i=e;return i=i.replace(/!\[(.*?)\]\(((?:\.\/|\/)?assets\/[^\s)]+)\)/g,(n,o,s)=>{const l=Et(s,t);return`![${o}](${l})`}),i=i.replace(/(<(?:img|video|audio|source)\b[^>]*?\bsrc=["'])((?:\.\/|\/)?assets\/[^"']+)(["'][^>]*>)/gi,(n,o,s,l)=>{const r=Et(s,t);return`${o}${r}${l}`}),i=i.replace(/(url\(\s*["']?)((?:\.\/|\/)?assets\/[^"')]+)(["']?\s*\))/gi,(n,o,s,l)=>{const r=Et(s,t);return`${o}${r}${l}`}),i}/**
* @vue/shared v3.5.40
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/function $s(e){const t=Object.create(null);for(const i of e.split(","))t[i]=1;return i=>i in t}const We={},Zi=[],qt=()=>{},ol=()=>!1,Co=e=>e.charCodeAt(0)===111&&e.charCodeAt(1)===110&&(e.charCodeAt(2)>122||e.charCodeAt(2)<97),$o=e=>e.startsWith("onUpdate:"),dt=Object.assign,Is=(e,t)=>{const i=e.indexOf(t);i>-1&&e.splice(i,1)},zc=Object.prototype.hasOwnProperty,Pe=(e,t)=>zc.call(e,t),$e=Array.isArray,Yi=e=>Nn(e)==="[object Map]",rn=e=>Nn(e)==="[object Set]",sr=e=>Nn(e)==="[object Date]",Ee=e=>typeof e=="function",it=e=>typeof e=="string",Rt=e=>typeof e=="symbol",He=e=>e!==null&&typeof e=="object",sl=e=>(He(e)||Ee(e))&&Ee(e.then)&&Ee(e.catch),rl=Object.prototype.toString,Nn=e=>rl.call(e),Fc=e=>Nn(e).slice(8,-1),ll=e=>Nn(e)==="[object Object]",Es=e=>it(e)&&e!=="NaN"&&e[0]!=="-"&&""+parseInt(e,10)===e,vn=$s(",key,ref,ref_for,ref_key,onVnodeBeforeMount,onVnodeMounted,onVnodeBeforeUpdate,onVnodeUpdated,onVnodeBeforeUnmount,onVnodeUnmounted"),Io=e=>{const t=Object.create(null);return(i=>t[i]||(t[i]=e(i)))},Hc=/-\w/g,wt=Io(e=>e.replace(Hc,t=>t.slice(1).toUpperCase())),jc=/\B([A-Z])/g,yi=Io(e=>e.replace(jc,"-$1").toLowerCase()),Eo=Io(e=>e.charAt(0).toUpperCase()+e.slice(1)),jo=Io(e=>e?`on${Eo(e)}`:""),Vt=(e,t)=>!Object.is(e,t),eo=(e,...t)=>{for(let i=0;i<e.length;i++)e[i](...t)},al=(e,t,i,n=!1)=>{Object.defineProperty(e,t,{configurable:!0,enumerable:!1,writable:n,value:i})},To=e=>{const t=parseFloat(e);return isNaN(t)?e:t};let rr;const Ao=()=>rr||(rr=typeof globalThis<"u"?globalThis:typeof self<"u"?self:typeof window<"u"?window:typeof global<"u"?global:{});function An(e){if($e(e)){const t={};for(let i=0;i<e.length;i++){const n=e[i],o=it(n)?Kc(n):An(n);if(o)for(const s in o)t[s]=o[s]}return t}else if(it(e)||He(e))return e}const Wc=/;(?![^(]*\))/g,Uc=/:([^]+)/,Vc=/\/\*[^]*?\*\//g;function Kc(e){const t={};return e.replace(Vc,"").split(Wc).forEach(i=>{if(i){const n=i.split(Uc);n.length>1&&(t[n[0].trim()]=n[1].trim())}}),t}function _e(e){let t="";if(it(e))t=e;else if($e(e))for(let i=0;i<e.length;i++){const n=_e(e[i]);n&&(t+=n+" ")}else if(He(e))for(const i in e)e[i]&&(t+=i+" ");return t.trim()}const qc="itemscope,allowfullscreen,formnovalidate,ismap,nomodule,novalidate,readonly",Gc=$s(qc);function cl(e){return!!e||e===""}function Zc(e,t){if(e.length!==t.length)return!1;let i=!0;for(let n=0;i&&n<e.length;n++)i=ln(e[n],t[n]);return i}function ln(e,t){if(e===t)return!0;let i=sr(e),n=sr(t);if(i||n)return i&&n?e.getTime()===t.getTime():!1;if(i=Rt(e),n=Rt(t),i||n)return e===t;if(i=$e(e),n=$e(t),i||n)return i&&n?Zc(e,t):!1;if(i=He(e),n=He(t),i||n){if(!i||!n)return!1;const o=Object.keys(e).length,s=Object.keys(t).length;if(o!==s)return!1;for(const l in e){const r=e.hasOwnProperty(l),a=t.hasOwnProperty(l);if(r&&!a||!r&&a||!ln(e[l],t[l]))return!1}}return String(e)===String(t)}function Ts(e,t){return e.findIndex(i=>ln(i,t))}const dl=e=>!!(e&&e.__v_isRef===!0),we=e=>it(e)?e:e==null?"":$e(e)||He(e)&&(e.toString===rl||!Ee(e.toString))?dl(e)?we(e.value):JSON.stringify(e,ul,2):String(e),ul=(e,t)=>dl(t)?ul(e,t.value):Yi(t)?{[`Map(${t.size})`]:[...t.entries()].reduce((i,[n,o],s)=>(i[Wo(n,s)+" =>"]=o,i),{})}:rn(t)?{[`Set(${t.size})`]:[...t.values()].map(i=>Wo(i))}:Rt(t)?Wo(t):He(t)&&!$e(t)&&!ll(t)?String(t):t,Wo=(e,t="")=>{var i;return Rt(e)?`Symbol(${(i=e.description)!=null?i:t})`:e};/**
* @vue/reactivity v3.5.40
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/let lt;class Yc{constructor(t=!1){this.detached=t,this._active=!0,this._on=0,this.effects=[],this.cleanups=[],this._isPaused=!1,this._warnOnRun=!0,this.__v_skip=!0,!t&&lt&&(lt.active?(this.parent=lt,this.index=(lt.scopes||(lt.scopes=[])).push(this)-1):(this._active=!1,this._warnOnRun=!1))}get active(){return this._active}pause(){if(this._active){this._isPaused=!0;let t,i;if(this.scopes){const n=this.scopes.slice();for(t=0,i=n.length;t<i;t++)n[t].pause()}for(t=0,i=this.effects.length;t<i;t++)this.effects[t].pause()}}resume(){if(this._active&&this._isPaused){this._isPaused=!1;let t,i;if(this.scopes){const o=this.scopes.slice();for(t=0,i=o.length;t<i;t++)o[t].resume()}const n=this.effects.slice();for(t=0,i=n.length;t<i;t++)n[t].resume()}}run(t){if(this._active){const i=lt;try{return lt=this,t()}finally{lt=i}}}on(){++this._on===1&&(this.prevScope=lt,lt=this)}off(){if(this._on>0&&--this._on===0){if(lt===this)lt=this.prevScope;else{let t=lt;for(;t;){if(t.prevScope===this){t.prevScope=this.prevScope;break}t=t.prevScope}}this.prevScope=void 0}}stop(t){if(this._active){this._active=!1;let i,n;for(i=0,n=this.effects.length;i<n;i++)this.effects[i].stop();for(this.effects.length=0,i=0,n=this.cleanups.length;i<n;i++)this.cleanups[i]();if(this.cleanups.length=0,this.scopes){const o=this.scopes.slice();for(i=0,n=o.length;i<n;i++)o[i].stop(!0);this.scopes.length=0}if(!this.detached&&this.parent&&!t){const o=this.parent.scopes.pop();o&&o!==this&&(this.parent.scopes[this.index]=o,o.index=this.index)}this.parent=void 0}}}function Jc(){return lt}let Ke;const Uo=new WeakSet;class fl{constructor(t){this.fn=t,this.deps=void 0,this.depsTail=void 0,this.flags=5,this.next=void 0,this.cleanup=void 0,this.scheduler=void 0,lt&&(lt.active?lt.effects.push(this):this.flags&=-2)}pause(){this.flags|=64}resume(){this.flags&64&&(this.flags&=-65,Uo.has(this)&&(Uo.delete(this),this.trigger()))}notify(){this.flags&2&&!(this.flags&32)||this.flags&8||hl(this)}run(){if(!(this.flags&1))return this.fn();this.flags|=2,lr(this),ml(this);const t=Ke,i=Ot;Ke=this,Ot=!0;try{return this.fn()}finally{gl(this),Ke=t,Ot=i,this.flags&=-3}}stop(){if(this.flags&1){for(let t=this.deps;t;t=t.nextDep)Ms(t);this.deps=this.depsTail=void 0,lr(this),this.onStop&&this.onStop(),this.flags&=-2}}trigger(){this.flags&64?Uo.add(this):this.scheduler?this.scheduler():this.runIfDirty()}runIfDirty(){as(this)&&this.run()}get dirty(){return as(this)}}let pl=0,bn,yn;function hl(e,t=!1){if(e.flags|=8,t){e.next=yn,yn=e;return}e.next=bn,bn=e}function As(){pl++}function Bs(){if(--pl>0)return;if(yn){let t=yn;for(yn=void 0;t;){const i=t.next;t.next=void 0,t.flags&=-9,t=i}}let e;for(;bn;){let t=bn;for(bn=void 0;t;){const i=t.next;if(t.next=void 0,t.flags&=-9,t.flags&1)try{t.trigger()}catch(n){e||(e=n)}t=i}}if(e)throw e}function ml(e){for(let t=e.deps;t;t=t.nextDep)t.version=-1,t.prevActiveLink=t.dep.activeLink,t.dep.activeLink=t}function gl(e){let t,i=e.depsTail,n=i;for(;n;){const o=n.prevDep;n.version===-1?(n===i&&(i=o),Ms(n),Xc(n)):t=n,n.dep.activeLink=n.prevActiveLink,n.prevActiveLink=void 0,n=o}e.deps=t,e.depsTail=i}function as(e){for(let t=e.deps;t;t=t.nextDep)if(t.dep.version!==t.version||t.dep.computed&&(vl(t.dep.computed)||t.dep.version!==t.version))return!0;return!!e._dirty}function vl(e){if(e.flags&4&&!(e.flags&16)||(e.flags&=-17,e.globalVersion===Bn)||(e.globalVersion=Bn,!e.isSSR&&e.flags&128&&(!e.deps&&!e._dirty||!as(e))))return;e.flags|=2;const t=e.dep,i=Ke,n=Ot;Ke=e,Ot=!0;try{ml(e);const o=e.fn(e._value);(t.version===0||Vt(o,e._value))&&(e.flags|=128,e._value=o,t.version++)}catch(o){throw t.version++,o}finally{Ke=i,Ot=n,gl(e),e.flags&=-3}}function Ms(e,t=!1){const{dep:i,prevSub:n,nextSub:o}=e;if(n&&(n.nextSub=o,e.prevSub=void 0),o&&(o.prevSub=n,e.nextSub=void 0),i.subs===e&&(i.subs=n,!n&&i.computed)){i.computed.flags&=-5;for(let s=i.computed.deps;s;s=s.nextDep)Ms(s,!0)}!t&&!--i.sc&&i.map&&i.map.delete(i.key)}function Xc(e){const{prevDep:t,nextDep:i}=e;t&&(t.nextDep=i,e.prevDep=void 0),i&&(i.prevDep=t,e.nextDep=void 0)}let Ot=!0;const bl=[];function oi(){bl.push(Ot),Ot=!1}function si(){const e=bl.pop();Ot=e===void 0?!0:e}function lr(e){const{cleanup:t}=e;if(e.cleanup=void 0,t){const i=Ke;Ke=void 0;try{t()}finally{Ke=i}}}let Bn=0;class Qc{constructor(t,i){this.sub=t,this.dep=i,this.version=i.version,this.nextDep=this.prevDep=this.nextSub=this.prevSub=this.prevActiveLink=void 0}}class Ds{constructor(t){this.computed=t,this.version=0,this.activeLink=void 0,this.subs=void 0,this.map=void 0,this.key=void 0,this.sc=0,this.__v_skip=!0}track(t){if(!Ke||!Ot||Ke===this.computed)return;let i=this.activeLink;if(i===void 0||i.sub!==Ke)i=this.activeLink=new Qc(Ke,this),Ke.deps?(i.prevDep=Ke.depsTail,Ke.depsTail.nextDep=i,Ke.depsTail=i):Ke.deps=Ke.depsTail=i,yl(i);else if(i.version===-1&&(i.version=this.version,i.nextDep)){const n=i.nextDep;n.prevDep=i.prevDep,i.prevDep&&(i.prevDep.nextDep=n),i.prevDep=Ke.depsTail,i.nextDep=void 0,Ke.depsTail.nextDep=i,Ke.depsTail=i,Ke.deps===i&&(Ke.deps=n)}return i}trigger(t){this.version++,Bn++,this.notify(t)}notify(t){As();try{for(let i=this.subs;i;i=i.prevSub)i.sub.notify()&&i.sub.dep.notify()}finally{Bs()}}}function yl(e){if(e.dep.sc++,e.sub.flags&4){const t=e.dep.computed;if(t&&!e.dep.subs){t.flags|=20;for(let n=t.deps;n;n=n.nextDep)yl(n)}const i=e.dep.subs;i!==e&&(e.prevSub=i,i&&(i.nextSub=e)),e.dep.subs=e}}const cs=new WeakMap,Bi=Symbol(""),ds=Symbol(""),Mn=Symbol("");function pt(e,t,i){if(Ot&&Ke){let n=cs.get(e);n||cs.set(e,n=new Map);let o=n.get(i);o||(n.set(i,o=new Ds),o.map=n,o.key=i),o.track()}}function Qt(e,t,i,n,o,s){const l=cs.get(e);if(!l){Bn++;return}const r=a=>{a&&a.trigger()};if(As(),t==="clear")l.forEach(r);else{const a=$e(e),c=a&&Es(i);if(a&&i==="length"){const d=Number(n);l.forEach((p,b)=>{(b==="length"||b===Mn||!Rt(b)&&b>=d)&&r(p)})}else switch((i!==void 0||l.has(void 0))&&r(l.get(i)),c&&r(l.get(Mn)),t){case"add":a?c&&r(l.get("length")):(r(l.get(Bi)),Yi(e)&&r(l.get(ds)));break;case"delete":a||(r(l.get(Bi)),Yi(e)&&r(l.get(ds)));break;case"set":Yi(e)&&r(l.get(Bi));break}}Bs()}function Fi(e){const t=Re(e);return t===e?t:(pt(t,"iterate",Mn),At(e)?t:t.map(Pt))}function Bo(e){return pt(e=Re(e),"iterate",Mn),e}function Wt(e,t){return ri(e)?tn(Mi(e)?Pt(t):t):Pt(t)}const ed={__proto__:null,[Symbol.iterator](){return Vo(this,Symbol.iterator,e=>Wt(this,e))},concat(...e){return Fi(this).concat(...e.map(t=>$e(t)?Fi(t):t))},entries(){return Vo(this,"entries",e=>(e[1]=Wt(this,e[1]),e))},every(e,t){return Yt(this,"every",e,t,void 0,arguments)},filter(e,t){return Yt(this,"filter",e,t,i=>i.map(n=>Wt(this,n)),arguments)},find(e,t){return Yt(this,"find",e,t,i=>Wt(this,i),arguments)},findIndex(e,t){return Yt(this,"findIndex",e,t,void 0,arguments)},findLast(e,t){return Yt(this,"findLast",e,t,i=>Wt(this,i),arguments)},findLastIndex(e,t){return Yt(this,"findLastIndex",e,t,void 0,arguments)},forEach(e,t){return Yt(this,"forEach",e,t,void 0,arguments)},includes(...e){return Ko(this,"includes",e)},indexOf(...e){return Ko(this,"indexOf",e)},join(e){return Fi(this).join(e)},lastIndexOf(...e){return Ko(this,"lastIndexOf",e)},map(e,t){return Yt(this,"map",e,t,void 0,arguments)},pop(){return un(this,"pop")},push(...e){return un(this,"push",e)},reduce(e,...t){return ar(this,"reduce",e,t)},reduceRight(e,...t){return ar(this,"reduceRight",e,t)},shift(){return un(this,"shift")},some(e,t){return Yt(this,"some",e,t,void 0,arguments)},splice(...e){return un(this,"splice",e)},toReversed(){return Fi(this).toReversed()},toSorted(e){return Fi(this).toSorted(e)},toSpliced(...e){return Fi(this).toSpliced(...e)},unshift(...e){return un(this,"unshift",e)},values(){return Vo(this,"values",e=>Wt(this,e))}};function Vo(e,t,i){const n=Bo(e),o=n[t]();return n!==e&&!At(e)&&(o._next=o.next,o.next=()=>{const s=o._next();return s.done||(s.value=i(s.value)),s}),o}const td=Array.prototype;function Yt(e,t,i,n,o,s){const l=Bo(e),r=l!==e&&!At(e),a=l[t];if(a!==td[t]){const p=a.apply(e,s);return r?Pt(p):p}let c=i;l!==e&&(r?c=function(p,b){return i.call(this,Wt(e,p),b,e)}:i.length>2&&(c=function(p,b){return i.call(this,p,b,e)}));const d=a.call(l,c,n);return r&&o?o(d):d}function ar(e,t,i,n){const o=Bo(e),s=o!==e&&!At(e);let l=i,r=!1;o!==e&&(s?(r=n.length===0,l=function(c,d,p){return r&&(r=!1,c=Wt(e,c)),i.call(this,c,Wt(e,d),p,e)}):i.length>3&&(l=function(c,d,p){return i.call(this,c,d,p,e)}));const a=o[t](l,...n);return r?Wt(e,a):a}function Ko(e,t,i){const n=Re(e);pt(n,"iterate",Mn);const o=n[t](...i);return(o===-1||o===!1)&&Rs(i[0])?(i[0]=Re(i[0]),n[t](...i)):o}function un(e,t,i=[]){oi(),As();const n=Re(e)[t].apply(e,i);return Bs(),si(),n}const id=$s("__proto__,__v_isRef,__isVue"),kl=new Set(Object.getOwnPropertyNames(Symbol).filter(e=>e!=="arguments"&&e!=="caller").map(e=>Symbol[e]).filter(Rt));function nd(e){Rt(e)||(e=String(e));const t=Re(this);return pt(t,"has",e),t.hasOwnProperty(e)}class wl{constructor(t=!1,i=!1){this._isReadonly=t,this._isShallow=i}get(t,i,n){if(i==="__v_skip")return t.__v_skip;const o=this._isReadonly,s=this._isShallow;if(i==="__v_isReactive")return!o;if(i==="__v_isReadonly")return o;if(i==="__v_isShallow")return s;if(i==="__v_raw")return n===(o?s?pd:Cl:s?_l:Sl).get(t)||Object.getPrototypeOf(t)===Object.getPrototypeOf(n)?t:void 0;const l=$e(t);if(!o){let a;if(l&&(a=ed[i]))return a;if(i==="hasOwnProperty")return nd}const r=Reflect.get(t,i,Ye(t)?t:n);if((Rt(i)?kl.has(i):id(i))||(o||pt(t,"get",i),s))return r;if(Ye(r)){const a=l&&Es(i)?r:r.value;return o&&He(a)?fs(a):a}return He(r)?o?fs(r):Mo(r):r}}class xl extends wl{constructor(t=!1){super(!1,t)}set(t,i,n,o){let s=t[i];const l=$e(t)&&Es(i);if(!this._isShallow){const c=ri(s);if(!At(n)&&!ri(n)&&(s=Re(s),n=Re(n)),!l&&Ye(s)&&!Ye(n))return c||(s.value=n),!0}const r=l?Number(i)<t.length:Pe(t,i),a=Reflect.set(t,i,n,Ye(t)?t:o);return t===Re(o)&&a&&(r?Vt(n,s)&&Qt(t,"set",i,n):Qt(t,"add",i,n)),a}deleteProperty(t,i){const n=Pe(t,i);t[i];const o=Reflect.deleteProperty(t,i);return o&&n&&Qt(t,"delete",i,void 0),o}has(t,i){const n=Reflect.has(t,i);return(!Rt(i)||!kl.has(i))&&pt(t,"has",i),n}ownKeys(t){return pt(t,"iterate",$e(t)?"length":Bi),Reflect.ownKeys(t)}}class od extends wl{constructor(t=!1){super(!0,t)}set(t,i){return!0}deleteProperty(t,i){return!0}}const sd=new xl,rd=new od,ld=new xl(!0);const us=e=>e,Kn=e=>Reflect.getPrototypeOf(e);function ad(e,t,i){return function(...n){const o=this.__v_raw,s=Re(o),l=Yi(s),r=e==="entries"||e===Symbol.iterator&&l,a=e==="keys"&&l,c=o[e](...n),d=i?us:t?tn:Pt;return!t&&pt(s,"iterate",a?ds:Bi),dt(Object.create(c),{next(){const{value:p,done:b}=c.next();return b?{value:p,done:b}:{value:r?[d(p[0]),d(p[1])]:d(p),done:b}}})}}function qn(e){return function(...t){return e==="delete"?!1:e==="clear"?void 0:this}}function cd(e,t){const i={get(o){const s=this.__v_raw,l=Re(s),r=Re(o);e||(Vt(o,r)&&pt(l,"get",o),pt(l,"get",r));const{has:a}=Kn(l),c=t?us:e?tn:Pt;if(a.call(l,o))return c(s.get(o));if(a.call(l,r))return c(s.get(r));s!==l&&s.get(o)},get size(){const o=this.__v_raw;return!e&&pt(Re(o),"iterate",Bi),o.size},has(o){const s=this.__v_raw,l=Re(s),r=Re(o);return e||(Vt(o,r)&&pt(l,"has",o),pt(l,"has",r)),o===r?s.has(o):s.has(o)||s.has(r)},forEach(o,s){const l=this,r=l.__v_raw,a=Re(r),c=t?us:e?tn:Pt;return!e&&pt(a,"iterate",Bi),r.forEach((d,p)=>o.call(s,c(d),c(p),l))}};return dt(i,e?{add:qn("add"),set:qn("set"),delete:qn("delete"),clear:qn("clear")}:{add(o){const s=Re(this),l=Kn(s),r=Re(o),a=!t&&!At(o)&&!ri(o)?r:o;return l.has.call(s,a)||Vt(o,a)&&l.has.call(s,o)||Vt(r,a)&&l.has.call(s,r)||(s.add(a),Qt(s,"add",a,a)),this},set(o,s){!t&&!At(s)&&!ri(s)&&(s=Re(s));const l=Re(this),{has:r,get:a}=Kn(l);let c=r.call(l,o);c||(o=Re(o),c=r.call(l,o));const d=a.call(l,o);return l.set(o,s),c?Vt(s,d)&&Qt(l,"set",o,s):Qt(l,"add",o,s),this},delete(o){const s=Re(this),{has:l,get:r}=Kn(s);let a=l.call(s,o);a||(o=Re(o),a=l.call(s,o)),r&&r.call(s,o);const c=s.delete(o);return a&&Qt(s,"delete",o,void 0),c},clear(){const o=Re(this),s=o.size!==0,l=o.clear();return s&&Qt(o,"clear",void 0,void 0),l}}),["keys","values","entries",Symbol.iterator].forEach(o=>{i[o]=ad(o,e,t)}),i}function Ls(e,t){const i=cd(e,t);return(n,o,s)=>o==="__v_isReactive"?!e:o==="__v_isReadonly"?e:o==="__v_raw"?n:Reflect.get(Pe(i,o)&&o in n?i:n,o,s)}const dd={get:Ls(!1,!1)},ud={get:Ls(!1,!0)},fd={get:Ls(!0,!1)};const Sl=new WeakMap,_l=new WeakMap,Cl=new WeakMap,pd=new WeakMap;function hd(e){switch(e){case"Object":case"Array":return 1;case"Map":case"Set":case"WeakMap":case"WeakSet":return 2;default:return 0}}function Mo(e){return ri(e)?e:Os(e,!1,sd,dd,Sl)}function md(e){return Os(e,!1,ld,ud,_l)}function fs(e){return Os(e,!0,rd,fd,Cl)}function Os(e,t,i,n,o){if(!He(e)||e.__v_raw&&!(t&&e.__v_isReactive)||e.__v_skip||!Object.isExtensible(e))return e;const s=o.get(e);if(s)return s;const l=hd(Fc(e));if(l===0)return e;const r=new Proxy(e,l===2?n:i);return o.set(e,r),r}function Mi(e){return ri(e)?Mi(e.__v_raw):!!(e&&e.__v_isReactive)}function ri(e){return!!(e&&e.__v_isReadonly)}function At(e){return!!(e&&e.__v_isShallow)}function Rs(e){return e?!!e.__v_raw:!1}function Re(e){const t=e&&e.__v_raw;return t?Re(t):e}function gd(e){return!Pe(e,"__v_skip")&&Object.isExtensible(e)&&al(e,"__v_skip",!0),e}const Pt=e=>He(e)?Mo(e):e,tn=e=>He(e)?fs(e):e;function Ye(e){return e?e.__v_isRef===!0:!1}function fe(e){return vd(e,!1)}function vd(e,t){return Ye(e)?e:new bd(e,t)}class bd{constructor(t,i){this.dep=new Ds,this.__v_isRef=!0,this.__v_isShallow=!1,this._rawValue=i?t:Re(t),this._value=i?t:Pt(t),this.__v_isShallow=i}get value(){return this.dep.track(),this._value}set value(t){const i=this._rawValue,n=this.__v_isShallow||At(t)||ri(t);t=n?t:Re(t),Vt(t,i)&&(this._rawValue=t,this._value=n?t:Pt(t),this.dep.trigger())}}function ge(e){return Ye(e)?e.value:e}const yd={get:(e,t,i)=>t==="__v_raw"?e:ge(Reflect.get(e,t,i)),set:(e,t,i,n)=>{const o=e[t];return Ye(o)&&!Ye(i)?(o.value=i,!0):Reflect.set(e,t,i,n)}};function $l(e){return Mi(e)?e:new Proxy(e,yd)}class kd{constructor(t,i,n){this.fn=t,this.setter=i,this._value=void 0,this.dep=new Ds(this),this.__v_isRef=!0,this.deps=void 0,this.depsTail=void 0,this.flags=16,this.globalVersion=Bn-1,this.next=void 0,this.effect=this,this.__v_isReadonly=!i,this.isSSR=n}notify(){if(this.flags|=16,!(this.flags&8)&&Ke!==this)return hl(this,!0),!0}get value(){const t=this.dep.track();return vl(this),t&&(t.version=this.dep.version),this._value}set value(t){this.setter&&this.setter(t)}}function wd(e,t,i=!1){let n,o;return Ee(e)?n=e:(n=e.get,o=e.set),new kd(n,o,i)}const Gn={},mo=new WeakMap;let $i;function xd(e,t=!1,i=$i){if(i){let n=mo.get(i);n||mo.set(i,n=[]),n.push(e)}}function Sd(e,t,i=We){const{immediate:n,deep:o,once:s,scheduler:l,augmentJob:r,call:a}=i,c=T=>o?T:At(T)||o===!1||o===0?ei(T,1):ei(T);let d,p,b,u,h=!1,f=!1;if(Ye(e)?(p=()=>e.value,h=At(e)):Mi(e)?(p=()=>c(e),h=!0):$e(e)?(f=!0,h=e.some(T=>Mi(T)||At(T)),p=()=>e.map(T=>{if(Ye(T))return T.value;if(Mi(T))return c(T);if(Ee(T))return a?a(T,2):T()})):Ee(e)?t?p=a?()=>a(e,2):e:p=()=>{if(b){oi();try{b()}finally{si()}}const T=$i;$i=d;try{return a?a(e,3,[u]):e(u)}finally{$i=T}}:p=qt,t&&o){const T=p,B=o===!0?1/0:o;p=()=>ei(T(),B)}const g=Jc(),k=()=>{d.stop(),g&&g.active&&Is(g.effects,d)};if(s&&t){const T=t;t=(...B)=>{const I=T(...B);return k(),I}}let S=f?new Array(e.length).fill(Gn):Gn;const C=T=>{if(!(!(d.flags&1)||!d.dirty&&!T))if(t){const B=d.run();if(T||o||h||(f?B.some((I,w)=>Vt(I,S[w])):Vt(B,S))){b&&b();const I=$i;$i=d;try{const w=[B,S===Gn?void 0:f&&S[0]===Gn?[]:S,u];S=B,a?a(t,3,w):t(...w)}finally{$i=I}}}else d.run()};return r&&r(C),d=new fl(p),d.scheduler=l?()=>l(C,!1):C,u=T=>xd(T,!1,d),b=d.onStop=()=>{const T=mo.get(d);if(T){if(a)a(T,4);else for(const B of T)B();mo.delete(d)}},t?n?C(!0):S=d.run():l?l(C.bind(null,!0),!0):d.run(),k.pause=d.pause.bind(d),k.resume=d.resume.bind(d),k.stop=k,k}function ei(e,t=1/0,i){if(t<=0||!He(e)||e.__v_skip||(i=i||new Map,(i.get(e)||0)>=t))return e;if(i.set(e,t),t--,Ye(e))ei(e.value,t,i);else if($e(e))for(let n=0;n<e.length;n++)ei(e[n],t,i);else if(rn(e)||Yi(e))e.forEach(n=>{ei(n,t,i)});else if(ll(e)){for(const n in e)ei(e[n],t,i);for(const n of Object.getOwnPropertySymbols(e))Object.prototype.propertyIsEnumerable.call(e,n)&&ei(e[n],t,i)}return e}/**
* @vue/runtime-core v3.5.40
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/function zn(e,t,i,n){try{return n?e(...n):e()}catch(o){Do(o,t,i)}}function Nt(e,t,i,n){if(Ee(e)){const o=zn(e,t,i,n);return o&&sl(o)&&o.catch(s=>{Do(s,t,i)}),o}if($e(e)){const o=[];for(let s=0;s<e.length;s++)o.push(Nt(e[s],t,i,n));return o}}function Do(e,t,i,n=!0){const o=t?t.vnode:null,{errorHandler:s,throwUnhandledErrorInProduction:l}=t&&t.appContext.config||We;if(t){let r=t.parent;const a=t.proxy,c=`https://vuejs.org/error-reference/#runtime-${i}`;for(;r;){const d=r.ec;if(d){for(let p=0;p<d.length;p++)if(d[p](e,a,c)===!1)return}r=r.parent}if(s){oi(),zn(s,null,10,[e,a,c]),si();return}}_d(e,i,o,n,l)}function _d(e,t,i,n=!0,o=!1){if(o)throw e;console.error(e)}const bt=[];let jt=-1;const Ji=[];let pi=null,Hi=0;const Il=Promise.resolve();let go=null;function El(e){const t=go||Il;return e?t.then(this?e.bind(this):e):t}function Cd(e){let t=jt+1,i=bt.length;for(;t<i;){const n=t+i>>>1,o=bt[n],s=Dn(o);s<e||s===e&&o.flags&2?t=n+1:i=n}return t}function Ps(e){if(!(e.flags&1)){const t=Dn(e),i=bt[bt.length-1];!i||!(e.flags&2)&&t>=Dn(i)?bt.push(e):bt.splice(Cd(t),0,e),e.flags|=1,Tl()}}function Tl(){go||(go=Il.then(Bl))}function $d(e){$e(e)?Ji.push(...e):pi&&e.id===-1?pi.splice(Hi+1,0,e):e.flags&1||(Ji.push(e),e.flags|=1),Tl()}function cr(e,t,i=jt+1){for(;i<bt.length;i++){const n=bt[i];if(n&&n.flags&2){if(e&&n.id!==e.uid)continue;bt.splice(i,1),i--,n.flags&4&&(n.flags&=-2),n(),n.flags&4||(n.flags&=-2)}}}function Al(e){if(Ji.length){const t=[...new Set(Ji)].sort((i,n)=>Dn(i)-Dn(n));if(Ji.length=0,pi){pi.push(...t);return}for(pi=t,Hi=0;Hi<pi.length;Hi++){const i=pi[Hi];i.flags&4&&(i.flags&=-2),i.flags&8||i(),i.flags&=-2}pi=null,Hi=0}}const Dn=e=>e.id==null?e.flags&2?-1:1/0:e.id;function Bl(e){try{for(jt=0;jt<bt.length;jt++){const t=bt[jt];t&&!(t.flags&8)&&(t.flags&4&&(t.flags&=-2),zn(t,t.i,t.i?15:14),t.flags&4||(t.flags&=-2))}}finally{for(;jt<bt.length;jt++){const t=bt[jt];t&&(t.flags&=-2)}jt=-1,bt.length=0,Al(),go=null,(bt.length||Ji.length)&&Bl()}}let ct=null,Ml=null;function vo(e){const t=ct;return ct=e,Ml=e&&e.type.__scopeId||null,t}function Dl(e,t=ct,i){if(!t||e._n)return e;const n=(...o)=>{n._d&&wr(-1);const s=vo(t),l=ii.length;let r;try{r=e(...o)}finally{for(let a=ii.length;a>l;a--)Ws();vo(s),n._d&&wr(1)}return r};return n._n=!0,n._c=!0,n._d=!0,n}function Tt(e,t){if(ct===null)return e;const i=Po(ct),n=e.dirs||(e.dirs=[]);for(let o=0;o<t.length;o++){let[s,l,r,a=We]=t[o];s&&(Ee(s)&&(s={mounted:s,updated:s}),s.deep&&ei(l),n.push({dir:s,instance:i,value:l,oldValue:void 0,arg:r,modifiers:a}))}return e}function wi(e,t,i,n){const o=e.dirs,s=t&&t.dirs;for(let l=0;l<o.length;l++){const r=o[l];s&&(r.oldValue=s[l].value);let a=r.dir[n];a&&(oi(),Nt(a,i,8,[e.el,r,e,t]),si())}}function Id(e,t){if(ht){let i=ht.provides;const n=ht.parent&&ht.parent.provides;n===i&&(i=ht.provides=Object.create(n)),i[e]=t}}function ti(e,t,i=!1){const n=Cu();if(n||Qi){let o=Qi?Qi._context.provides:n?n.parent==null||n.ce?n.vnode.appContext&&n.vnode.appContext.provides:n.parent.provides:void 0;if(o&&e in o)return o[e];if(arguments.length>1)return i&&Ee(t)?t.call(n&&n.proxy):t}}const Ed=Symbol.for("v-scx"),Td=()=>ti(Ed);function Di(e,t,i){return Ll(e,t,i)}function Ll(e,t,i=We){const{immediate:n,deep:o,flush:s,once:l}=i,r=dt({},i),a=t&&n||!t&&s!=="post";let c;if(On){if(s==="sync"){const u=Td();c=u.__watcherHandles||(u.__watcherHandles=[])}else if(!a){const u=()=>{};return u.stop=qt,u.resume=qt,u.pause=qt,u}}const d=ht;r.call=(u,h,f)=>Nt(u,d,h,f);let p=!1;s==="post"?r.scheduler=u=>{xt(u,d&&d.suspense)}:s!=="sync"&&(p=!0,r.scheduler=(u,h)=>{h?u():Ps(u)}),r.augmentJob=u=>{t&&(u.flags|=4),p&&(u.flags|=2,d&&(u.id=d.uid,u.i=d))};const b=Sd(e,t,r);return On&&(c?c.push(b):a&&b()),b}function Ad(e,t,i){const n=this.proxy,o=it(e)?e.includes(".")?Ol(n,e):()=>n[e]:e.bind(n,n);let s;Ee(t)?s=t:(s=t.handler,i=t);const l=Hn(this),r=Ll(o,s.bind(n),i);return l(),r}function Ol(e,t){const i=t.split(".");return()=>{let n=e;for(let o=0;o<i.length&&n;o++)n=n[i[o]];return n}}const Bd=Symbol("_vte"),Md=e=>e.__isTeleport,qo=Symbol("_leaveCb");function Ns(e,t){e.shapeFlag&6&&e.component?(e.transition=t,Ns(e.component.subTree,t)):e.shapeFlag&128?(e.ssContent.transition=t.clone(e.ssContent),e.ssFallback.transition=t.clone(e.ssFallback)):e.transition=t}function Ct(e,t){return Ee(e)?dt({name:e.name},t,{setup:e}):e}function Rl(e){e.ids=[e.ids[0]+e.ids[2]+++"-",0,0]}function dr(e,t){let i;return!!((i=Object.getOwnPropertyDescriptor(e,t))&&!i.configurable)}const bo=new WeakMap;function kn(e,t,i,n,o=!1){if($e(e)){e.forEach((f,g)=>kn(f,t&&($e(t)?t[g]:t),i,n,o));return}if(Xi(n)&&!o){n.shapeFlag&512&&n.type.__asyncResolved&&n.component.subTree.component&&kn(e,t,i,n.component.subTree);return}const s=n.shapeFlag&4?Po(n.component):n.el,l=o?null:s,{i:r,r:a}=e,c=t&&t.r,d=r.refs===We?r.refs={}:r.refs,p=r.setupState,b=Re(p),u=p===We?ol:f=>dr(d,f)?!1:Pe(b,f),h=(f,g)=>!(g&&dr(d,g));if(c!=null&&c!==a){if(ur(t),it(c))d[c]=null,u(c)&&(p[c]=null);else if(Ye(c)){const f=t;h(c,f.k)&&(c.value=null),f.k&&(d[f.k]=null)}}if(Ee(a))zn(a,r,12,[l,d]);else{const f=it(a),g=Ye(a);if(f||g){const k=()=>{if(e.f){const S=f?u(a)?p[a]:d[a]:h()||!e.k?a.value:d[e.k];if(o)$e(S)&&Is(S,s);else if($e(S))S.includes(s)||S.push(s);else if(f)d[a]=[s],u(a)&&(p[a]=d[a]);else{const C=[s];h(a,e.k)&&(a.value=C),e.k&&(d[e.k]=C)}}else f?(d[a]=l,u(a)&&(p[a]=l)):g&&(h(a,e.k)&&(a.value=l),e.k&&(d[e.k]=l))};if(l){const S=()=>{k(),bo.delete(e)};S.id=-1,bo.set(e,S),xt(S,i)}else ur(e),k()}}}function ur(e){const t=bo.get(e);t&&(t.flags|=8,bo.delete(e))}Ao().requestIdleCallback;Ao().cancelIdleCallback;const Xi=e=>!!e.type.__asyncLoader,Pl=e=>e.type.__isKeepAlive;function Dd(e,t){Nl(e,"a",t)}function Ld(e,t){Nl(e,"da",t)}function Nl(e,t,i=ht){const n=e.__wdc||(e.__wdc=()=>{let o=i;for(;o;){if(o.isDeactivated)return;o=o.parent}return e()});if(Lo(t,n,i),i){let o=i.parent;for(;o&&o.parent;)Pl(o.parent.vnode)&&Od(n,t,i,o),o=o.parent}}function Od(e,t,i,n){const o=Lo(t,e,n,!0);Fs(()=>{Is(n[t],o)},i)}function Lo(e,t,i=ht,n=!1){if(i){const o=i[e]||(i[e]=[]),s=t.__weh||(t.__weh=(...l)=>{oi();const r=Hn(i),a=Nt(t,i,e,l);return r(),si(),a});return n?o.unshift(s):o.push(s),s}}const ai=e=>(t,i=ht)=>{(!On||e==="sp")&&Lo(e,(...n)=>t(...n),i)},Rd=ai("bm"),Fn=ai("m"),Pd=ai("bu"),Nd=ai("u"),zs=ai("bum"),Fs=ai("um"),zd=ai("sp"),Fd=ai("rtg"),Hd=ai("rtc");function jd(e,t=ht){Lo("ec",e,t)}const Wd="components";function Ud(e,t){return Kd(Wd,e,!0,t)||e}const Vd=Symbol.for("v-ndc");function Kd(e,t,i=!0,n=!1){const o=ct||ht;if(o){const s=o.type;{const r=Au(s,!1);if(r&&(r===t||r===wt(t)||r===Eo(wt(t))))return s}const l=fr(o[e]||s[e],t)||fr(o.appContext[e],t);return!l&&n?s:l}}function fr(e,t){return e&&(e[t]||e[wt(t)]||e[Eo(wt(t))])}function kt(e,t,i,n){let o;const s=i,l=$e(e);if(l||it(e)){const r=l&&Mi(e);let a=!1,c=!1;r&&(a=!At(e),c=ri(e),e=Bo(e)),o=new Array(e.length);for(let d=0,p=e.length;d<p;d++)o[d]=t(a?c?tn(Pt(e[d])):Pt(e[d]):e[d],d,void 0,s)}else if(typeof e=="number"){o=new Array(e);for(let r=0;r<e;r++)o[r]=t(r+1,r,void 0,s)}else if(He(e))if(e[Symbol.iterator])o=Array.from(e,(r,a)=>t(r,a,void 0,s));else{const r=Object.keys(e);o=new Array(r.length);for(let a=0,c=r.length;a<c;a++){const d=r[a];o[a]=t(e[d],d,a,s)}}else o=[];return o}function Zn(e,t,i={},n,o,s){if(ct.ce||ct.parent&&Xi(ct.parent)&&ct.parent.ce){const c=i,d=Object.keys(c).length>0;return t!=="default"&&(c.name=t),ee(),Dt(Ue,null,[re("slot",c,n&&n())],d?-2:64)}let l=e[t];l&&l._c&&(l._d=!1);const r=ii.length;ee();let a;try{const c=l&&zl(l(i)),d=i.key||s||c&&c.key;a=Dt(Ue,{key:(d&&!Rt(d)?d:`_${t}`)+(!c&&n?"_fb":"")},c||(n?n():[]),c&&e._===1?64:-2)}catch(c){for(let d=ii.length;d>r;d--)Ws();throw c}finally{l&&l._c&&(l._d=!0)}return a}function zl(e){return e.some(t=>Us(t)?!(t.type===li||t.type===Ue&&!zl(t.children)):!0)?e:null}const ps=e=>e?sa(e)?Po(e):ps(e.parent):null,wn=dt(Object.create(null),{$:e=>e,$el:e=>e.vnode.el,$data:e=>e.data,$props:e=>e.props,$attrs:e=>e.attrs,$slots:e=>e.slots,$refs:e=>e.refs,$parent:e=>ps(e.parent),$root:e=>ps(e.root),$host:e=>e.ce,$emit:e=>e.emit,$options:e=>Hl(e),$forceUpdate:e=>e.f||(e.f=()=>{Ps(e.update)}),$nextTick:e=>e.n||(e.n=El.bind(e.proxy)),$watch:e=>Ad.bind(e)}),Go=(e,t)=>e!==We&&!e.__isScriptSetup&&Pe(e,t),qd={get({_:e},t){if(t==="__v_skip")return!0;const{ctx:i,setupState:n,data:o,props:s,accessCache:l,type:r,appContext:a}=e;if(t[0]!=="$"){const b=l[t];if(b!==void 0)switch(b){case 1:return n[t];case 2:return o[t];case 4:return i[t];case 3:return s[t]}else{if(Go(n,t))return l[t]=1,n[t];if(o!==We&&Pe(o,t))return l[t]=2,o[t];if(Pe(s,t))return l[t]=3,s[t];if(i!==We&&Pe(i,t))return l[t]=4,i[t];hs&&(l[t]=0)}}const c=wn[t];let d,p;if(c)return t==="$attrs"&&pt(e.attrs,"get",""),c(e);if((d=r.__cssModules)&&(d=d[t]))return d;if(i!==We&&Pe(i,t))return l[t]=4,i[t];if(p=a.config.globalProperties,Pe(p,t))return p[t]},set({_:e},t,i){const{data:n,setupState:o,ctx:s}=e;return Go(o,t)?(o[t]=i,!0):n!==We&&Pe(n,t)?(n[t]=i,!0):Pe(e.props,t)||t[0]==="$"&&t.slice(1)in e?!1:(s[t]=i,!0)},has({_:{data:e,setupState:t,accessCache:i,ctx:n,appContext:o,props:s,type:l}},r){let a;return!!(i[r]||e!==We&&r[0]!=="$"&&Pe(e,r)||Go(t,r)||Pe(s,r)||Pe(n,r)||Pe(wn,r)||Pe(o.config.globalProperties,r)||(a=l.__cssModules)&&a[r])},defineProperty(e,t,i){return i.get!=null?e._.accessCache[t]=0:Pe(i,"value")&&this.set(e,t,i.value,null),Reflect.defineProperty(e,t,i)}};function pr(e){return $e(e)?e.reduce((t,i)=>(t[i]=null,t),{}):e}let hs=!0;function Gd(e){const t=Hl(e),i=e.proxy,n=e.ctx;hs=!1,t.beforeCreate&&hr(t.beforeCreate,e,"bc");const{data:o,computed:s,methods:l,watch:r,provide:a,inject:c,created:d,beforeMount:p,mounted:b,beforeUpdate:u,updated:h,activated:f,deactivated:g,beforeDestroy:k,beforeUnmount:S,destroyed:C,unmounted:T,render:B,renderTracked:I,renderTriggered:w,errorCaptured:P,serverPrefetch:R,expose:z,inheritAttrs:V,components:_,directives:L,filters:y}=t;if(c&&Zd(c,n,null),l)for(const E in l){const D=l[E];Ee(D)&&(n[E]=D.bind(i))}if(o){const E=o.call(i,i);He(E)&&(e.data=Mo(E))}if(hs=!0,s)for(const E in s){const D=s[E],N=Ee(D)?D.bind(i,i):Ee(D.get)?D.get.bind(i,i):qt,X=!Ee(D)&&Ee(D.set)?D.set.bind(i):qt,j=xe({get:N,set:X});Object.defineProperty(n,E,{enumerable:!0,configurable:!0,get:()=>j.value,set:G=>j.value=G})}if(r)for(const E in r)Fl(r[E],n,i,E);if(a){const E=Ee(a)?a.call(i):a;Reflect.ownKeys(E).forEach(D=>{Id(D,E[D])})}d&&hr(d,e,"c");function F(E,D){$e(D)?D.forEach(N=>E(N.bind(i))):D&&E(D.bind(i))}if(F(Rd,p),F(Fn,b),F(Pd,u),F(Nd,h),F(Dd,f),F(Ld,g),F(jd,P),F(Hd,I),F(Fd,w),F(zs,S),F(Fs,T),F(zd,R),$e(z))if(z.length){const E=e.exposed||(e.exposed={});z.forEach(D=>{Object.defineProperty(E,D,{get:()=>i[D],set:N=>i[D]=N,enumerable:!0})})}else e.exposed||(e.exposed={});B&&e.render===qt&&(e.render=B),V!=null&&(e.inheritAttrs=V),_&&(e.components=_),L&&(e.directives=L),R&&Rl(e)}function Zd(e,t,i=qt){$e(e)&&(e=ms(e));for(const n in e){const o=e[n];let s;He(o)?"default"in o?s=ti(o.from||n,o.default,!0):s=ti(o.from||n):s=ti(o),Ye(s)?Object.defineProperty(t,n,{enumerable:!0,configurable:!0,get:()=>s.value,set:l=>s.value=l}):t[n]=s}}function hr(e,t,i){Nt($e(e)?e.map(n=>n.bind(t.proxy)):e.bind(t.proxy),t,i)}function Fl(e,t,i,n){let o=n.includes(".")?Ol(i,n):()=>i[n];if(it(e)){const s=t[e];Ee(s)&&Di(o,s)}else if(Ee(e))Di(o,e.bind(i));else if(He(e))if($e(e))e.forEach(s=>Fl(s,t,i,n));else{const s=Ee(e.handler)?e.handler.bind(i):t[e.handler];Ee(s)&&Di(o,s,e)}}function Hl(e){const t=e.type,{mixins:i,extends:n}=t,{mixins:o,optionsCache:s,config:{optionMergeStrategies:l}}=e.appContext,r=s.get(t);let a;return r?a=r:!o.length&&!i&&!n?a=t:(a={},o.length&&o.forEach(c=>yo(a,c,l,!0)),yo(a,t,l)),He(t)&&s.set(t,a),a}function yo(e,t,i,n=!1){const{mixins:o,extends:s}=t;s&&yo(e,s,i,!0),o&&o.forEach(l=>yo(e,l,i,!0));for(const l in t)if(!(n&&l==="expose")){const r=Yd[l]||i&&i[l];e[l]=r?r(e[l],t[l]):t[l]}return e}const Yd={data:mr,props:gr,emits:gr,methods:hn,computed:hn,beforeCreate:vt,created:vt,beforeMount:vt,mounted:vt,beforeUpdate:vt,updated:vt,beforeDestroy:vt,beforeUnmount:vt,destroyed:vt,unmounted:vt,activated:vt,deactivated:vt,errorCaptured:vt,serverPrefetch:vt,components:hn,directives:hn,watch:Xd,provide:mr,inject:Jd};function mr(e,t){return t?e?function(){return dt(Ee(e)?e.call(this,this):e,Ee(t)?t.call(this,this):t)}:t:e}function Jd(e,t){return hn(ms(e),ms(t))}function ms(e){if($e(e)){const t={};for(let i=0;i<e.length;i++)t[e[i]]=e[i];return t}return e}function vt(e,t){return e?[...new Set([].concat(e,t))]:t}function hn(e,t){return e?dt(Object.create(null),e,t):t}function gr(e,t){return e?$e(e)&&$e(t)?[...new Set([...e,...t])]:dt(Object.create(null),pr(e),pr(t??{})):t}function Xd(e,t){if(!e)return t;if(!t)return e;const i=dt(Object.create(null),e);for(const n in t)i[n]=vt(e[n],t[n]);return i}function jl(){return{app:null,config:{isNativeTag:ol,performance:!1,globalProperties:{},optionMergeStrategies:{},errorHandler:void 0,warnHandler:void 0,compilerOptions:{}},mixins:[],components:{},directives:{},provides:Object.create(null),optionsCache:new WeakMap,propsCache:new WeakMap,emitsCache:new WeakMap}}let Qd=0;function eu(e,t){return function(n,o=null){Ee(n)||(n=dt({},n)),o!=null&&!He(o)&&(o=null);const s=jl(),l=new WeakSet,r=[];let a=!1;const c=s.app={_uid:Qd++,_component:n,_props:o,_container:null,_context:s,_instance:null,version:Mu,get config(){return s.config},set config(d){},use(d,...p){return l.has(d)||(d&&Ee(d.install)?(l.add(d),d.install(c,...p)):Ee(d)&&(l.add(d),d(c,...p))),c},mixin(d){return s.mixins.includes(d)||s.mixins.push(d),c},component(d,p){return p?(s.components[d]=p,c):s.components[d]},directive(d,p){return p?(s.directives[d]=p,c):s.directives[d]},mount(d,p,b){if(!a){const u=c._ceVNode||re(n,o);return u.appContext=s,b===!0?b="svg":b===!1&&(b=void 0),e(u,d,b),a=!0,c._container=d,d.__vue_app__=c,Po(u.component)}},onUnmount(d){r.push(d)},unmount(){a&&(Nt(r,c._instance,16),e(null,c._container),delete c._container.__vue_app__)},provide(d,p){return s.provides[d]=p,c},runWithContext(d){const p=Qi;Qi=c;try{return d()}finally{Qi=p}}};return c}}let Qi=null;const tu=(e,t)=>t==="modelValue"||t==="model-value"?e.modelModifiers:e[`${t}Modifiers`]||e[`${wt(t)}Modifiers`]||e[`${yi(t)}Modifiers`];function iu(e,t,...i){if(e.isUnmounted)return;const n=e.vnode.props||We;let o=i;const s=t.startsWith("update:"),l=s&&tu(n,t.slice(7));l&&(l.trim&&(o=i.map(d=>it(d)?d.trim():d)),l.number&&(o=i.map(To)));let r,a=n[r=jo(t)]||n[r=jo(wt(t))];!a&&s&&(a=n[r=jo(yi(t))]),a&&Nt(a,e,6,o);const c=n[r+"Once"];if(c){if(!e.emitted)e.emitted={};else if(e.emitted[r])return;e.emitted[r]=!0,Nt(c,e,6,o)}}const nu=new WeakMap;function Wl(e,t,i=!1){const n=i?nu:t.emitsCache,o=n.get(e);if(o!==void 0)return o;const s=e.emits;let l={},r=!1;if(!Ee(e)){const a=c=>{const d=Wl(c,t,!0);d&&(r=!0,dt(l,d))};!i&&t.mixins.length&&t.mixins.forEach(a),e.extends&&a(e.extends),e.mixins&&e.mixins.forEach(a)}return!s&&!r?(He(e)&&n.set(e,null),null):($e(s)?s.forEach(a=>l[a]=null):dt(l,s),He(e)&&n.set(e,l),l)}function Oo(e,t){return!e||!Co(t)?!1:(t=t.slice(2),t=t==="Once"?t:t.replace(/Once$/,""),Pe(e,t[0].toLowerCase()+t.slice(1))||Pe(e,yi(t))||Pe(e,t))}function vr(e){const{type:t,vnode:i,proxy:n,withProxy:o,propsOptions:[s],slots:l,attrs:r,emit:a,render:c,renderCache:d,props:p,data:b,setupState:u,ctx:h,inheritAttrs:f}=e,g=vo(e);let k,S;try{if(i.shapeFlag&4){const T=o||n,B=T;k=Ut(c.call(B,T,d,p,u,b,h)),S=r}else{const T=t;k=Ut(T.length>1?T(p,{attrs:r,slots:l,emit:a}):T(p,null)),S=t.props?r:ou(r)}}catch(T){ii.length=0,Do(T,e,1),k=re(li)}let C=k;if(S&&f!==!1){const T=Object.keys(S),{shapeFlag:B}=C;T.length&&B&7&&(s&&T.some($o)&&(S=su(S,s)),C=nn(C,S,!1,!0))}return i.dirs&&(C=nn(C,null,!1,!0),C.dirs=C.dirs?C.dirs.concat(i.dirs):i.dirs),i.transition&&Ns(C,i.transition),k=C,vo(g),k}const ou=e=>{let t;for(const i in e)(i==="class"||i==="style"||Co(i))&&((t||(t={}))[i]=e[i]);return t},su=(e,t)=>{const i={};for(const n in e)(!$o(n)||!(n.slice(9)in t))&&(i[n]=e[n]);return i};function ru(e,t,i){const{props:n,children:o,component:s}=e,{props:l,children:r,patchFlag:a}=t,c=s.emitsOptions;if(t.dirs||t.transition)return!0;if(i&&a>=0){if(a&1024)return!0;if(a&16)return n?br(n,l,c):!!l;if(a&8){const d=t.dynamicProps;for(let p=0;p<d.length;p++){const b=d[p];if(Ul(l,n,b)&&!Oo(c,b))return!0}}}else return(o||r)&&(!r||!r.$stable)?!0:n===l?!1:n?l?br(n,l,c):!0:!!l;return!1}function br(e,t,i){const n=Object.keys(t);if(n.length!==Object.keys(e).length)return!0;for(let o=0;o<n.length;o++){const s=n[o];if(Ul(t,e,s)&&!Oo(i,s))return!0}return!1}function Ul(e,t,i){const n=e[i],o=t[i];return i==="style"&&He(n)&&He(o)?!ln(n,o):n!==o}function lu({vnode:e,parent:t,suspense:i},n){for(;t;){const o=t.subTree;if(o.suspense&&o.suspense.activeBranch===e&&(o.suspense.vnode.el=o.el=n,e=o),o===e)(e=t.vnode).el=n,t=t.parent;else break}i&&i.activeBranch===e&&(i.vnode.el=n)}const Vl={},Kl=()=>Object.create(Vl),ql=e=>Object.getPrototypeOf(e)===Vl;function au(e,t,i,n=!1){const o={},s=Kl();e.propsDefaults=Object.create(null),Gl(e,t,o,s);for(const l in e.propsOptions[0])l in o||(o[l]=void 0);i?e.props=n?o:md(o):e.type.props?e.props=o:e.props=s,e.attrs=s}function cu(e,t,i,n){const{props:o,attrs:s,vnode:{patchFlag:l}}=e,r=Re(o),[a]=e.propsOptions;let c=!1;if((n||l>0)&&!(l&16)){if(l&8){const d=e.vnode.dynamicProps;for(let p=0;p<d.length;p++){let b=d[p];if(Oo(e.emitsOptions,b))continue;const u=t[b];if(a)if(Pe(s,b))u!==s[b]&&(s[b]=u,c=!0);else{const h=wt(b);o[h]=gs(a,r,h,u,e,!1)}else u!==s[b]&&(s[b]=u,c=!0)}}}else{Gl(e,t,o,s)&&(c=!0);let d;for(const p in r)(!t||!Pe(t,p)&&((d=yi(p))===p||!Pe(t,d)))&&(a?i&&(i[p]!==void 0||i[d]!==void 0)&&(o[p]=gs(a,r,p,void 0,e,!0)):delete o[p]);if(s!==r)for(const p in s)(!t||!Pe(t,p))&&(delete s[p],c=!0)}c&&Qt(e.attrs,"set","")}function Gl(e,t,i,n){const[o,s]=e.propsOptions;let l=!1,r;if(t)for(let a in t){if(vn(a))continue;const c=t[a];let d;o&&Pe(o,d=wt(a))?!s||!s.includes(d)?i[d]=c:(r||(r={}))[d]=c:Oo(e.emitsOptions,a)||(!(a in n)||c!==n[a])&&(n[a]=c,l=!0)}if(s){const a=Re(i),c=r||We;for(let d=0;d<s.length;d++){const p=s[d];i[p]=gs(o,a,p,c[p],e,!Pe(c,p))}}return l}function gs(e,t,i,n,o,s){const l=e[i];if(l!=null){const r=Pe(l,"default");if(r&&n===void 0){const a=l.default;if(l.type!==Function&&!l.skipFactory&&Ee(a)){const{propsDefaults:c}=o;if(i in c)n=c[i];else{const d=Hn(o);n=c[i]=a.call(null,t),d()}}else n=a;o.ce&&o.ce._setProp(i,n)}l[0]&&(s&&!r?n=!1:l[1]&&(n===""||n===yi(i))&&(n=!0))}return n}const du=new WeakMap;function Zl(e,t,i=!1){const n=i?du:t.propsCache,o=n.get(e);if(o)return o;const s=e.props,l={},r=[];let a=!1;if(!Ee(e)){const d=p=>{a=!0;const[b,u]=Zl(p,t,!0);dt(l,b),u&&r.push(...u)};!i&&t.mixins.length&&t.mixins.forEach(d),e.extends&&d(e.extends),e.mixins&&e.mixins.forEach(d)}if(!s&&!a)return He(e)&&n.set(e,Zi),Zi;if($e(s))for(let d=0;d<s.length;d++){const p=wt(s[d]);yr(p)&&(l[p]=We)}else if(s)for(const d in s){const p=wt(d);if(yr(p)){const b=s[d],u=l[p]=$e(b)||Ee(b)?{type:b}:dt({},b),h=u.type;let f=!1,g=!0;if($e(h))for(let k=0;k<h.length;++k){const S=h[k],C=Ee(S)&&S.name;if(C==="Boolean"){f=!0;break}else C==="String"&&(g=!1)}else f=Ee(h)&&h.name==="Boolean";u[0]=f,u[1]=g,(f||Pe(u,"default"))&&r.push(p)}}const c=[l,r];return He(e)&&n.set(e,c),c}function yr(e){return e[0]!=="$"&&!vn(e)}const Hs=e=>e==="_"||e==="_ctx"||e==="$stable",js=e=>$e(e)?e.map(Ut):[Ut(e)],uu=(e,t,i)=>{if(t._n)return t;const n=Dl((...o)=>js(t(...o)),i);return n._c=!1,n},Yl=(e,t,i)=>{const n=e._ctx;for(const o in e){if(Hs(o))continue;const s=e[o];if(Ee(s))t[o]=uu(o,s,n);else if(s!=null){const l=js(s);t[o]=()=>l}}},Jl=(e,t)=>{const i=js(t);e.slots.default=()=>i},Xl=(e,t,i)=>{for(const n in t)(i||!Hs(n))&&(e[n]=t[n])},fu=(e,t,i)=>{const n=e.slots=Kl();if(e.vnode.shapeFlag&32){const o=t._;o?(Xl(n,t,i),i&&al(n,"_",o,!0)):Yl(t,n)}else t&&Jl(e,t)},pu=(e,t,i)=>{const{vnode:n,slots:o}=e;let s=!0,l=We;if(n.shapeFlag&32){const r=t._;r?i&&r===1?s=!1:Xl(o,t,i):(s=!t.$stable,Yl(t,o)),l=t}else t&&(Jl(e,t),l={default:1});if(s)for(const r in o)!Hs(r)&&l[r]==null&&delete o[r]},xt=bu;function hu(e){return mu(e)}function mu(e,t){const i=Ao();i.__VUE__=!0;const{insert:n,remove:o,patchProp:s,createElement:l,createText:r,createComment:a,setText:c,setElementText:d,parentNode:p,nextSibling:b,setScopeId:u=qt,insertStaticContent:h}=e,f=(O,W,v,K=null,H=null,$=null,x=void 0,M=null,Y=!!W.dynamicChildren)=>{if(O===W)return;O&&!fn(O,W)&&(K=Te(O),G(O,H,$,!0),O=null),W.patchFlag===-2&&(Y=!1,W.dynamicChildren=null);const{type:U,ref:Z,shapeFlag:Q}=W;switch(U){case Ro:g(O,W,v,K);break;case li:k(O,W,v,K);break;case to:O==null&&S(W,v,K,x);break;case Ue:_(O,W,v,K,H,$,x,M,Y);break;default:Q&1?B(O,W,v,K,H,$,x,M,Y):Q&6?L(O,W,v,K,H,$,x,M,Y):(Q&64||Q&128)&&U.process(O,W,v,K,H,$,x,M,Y,ae)}Z!=null&&H?kn(Z,O&&O.ref,$,W||O,!W):Z==null&&O&&O.ref!=null&&kn(O.ref,null,$,O,!0)},g=(O,W,v,K)=>{if(O==null)n(W.el=r(W.children),v,K);else{const H=W.el=O.el;W.children!==O.children&&c(H,W.children)}},k=(O,W,v,K)=>{O==null?n(W.el=a(W.children||""),v,K):W.el=O.el},S=(O,W,v,K)=>{[O.el,O.anchor]=h(O.children,W,v,K,O.el,O.anchor)},C=({el:O,anchor:W},v,K)=>{let H;for(;O&&O!==W;)H=b(O),n(O,v,K),O=H;n(W,v,K)},T=({el:O,anchor:W})=>{let v;for(;O&&O!==W;)v=b(O),o(O),O=v;o(W)},B=(O,W,v,K,H,$,x,M,Y)=>{if(W.type==="svg"?x="svg":W.type==="math"&&(x="mathml"),O==null)I(W,v,K,H,$,x,M,Y);else{const U=O.el&&O.el._isVueCE?O.el:null;try{U&&U._beginPatch(),R(O,W,H,$,x,M,Y)}finally{U&&U._endPatch()}}},I=(O,W,v,K,H,$,x,M)=>{let Y,U;const{props:Z,shapeFlag:Q,transition:oe,dirs:ie}=O;if(Y=O.el=l(O.type,$,Z&&Z.is,Z),Q&8?d(Y,O.children):Q&16&&P(O.children,Y,null,K,H,Zo(O,$),x,M),ie&&wi(O,null,K,"created"),w(Y,O,O.scopeId,x,K),Z){for(const Se in Z)Se!=="value"&&!vn(Se)&&s(Y,Se,null,Z[Se],$,K);"value"in Z&&s(Y,"value",null,Z.value,$),(U=Z.onVnodeBeforeMount)&&Ht(U,K,O)}ie&&wi(O,null,K,"beforeMount");const de=gu(H,oe);de&&oe.beforeEnter(Y),n(Y,W,v),((U=Z&&Z.onVnodeMounted)||de||ie)&&xt(()=>{try{U&&Ht(U,K,O),de&&oe.enter(Y),ie&&wi(O,null,K,"mounted")}finally{}},H)},w=(O,W,v,K,H)=>{if(v&&u(O,v),K)for(let $=0;$<K.length;$++)u(O,K[$]);if(H){let $=H.subTree;if(W===$||ia($.type)&&($.ssContent===W||$.ssFallback===W)){const x=H.vnode;w(O,x,x.scopeId,x.slotScopeIds,H.parent)}}},P=(O,W,v,K,H,$,x,M,Y=0)=>{for(let U=Y;U<O.length;U++){const Z=O[U]=M?Xt(O[U]):Ut(O[U]);f(null,Z,W,v,K,H,$,x,M)}},R=(O,W,v,K,H,$,x)=>{const M=W.el=O.el;let{patchFlag:Y,dynamicChildren:U,dirs:Z}=W;Y|=O.patchFlag&16;const Q=O.props||We,oe=W.props||We;let ie;if(v&&xi(v,!1),(ie=oe.onVnodeBeforeUpdate)&&Ht(ie,v,W,O),Z&&wi(W,O,v,"beforeUpdate"),v&&xi(v,!0),U&&(!O.dynamicChildren||O.dynamicChildren.length!==U.length)&&(Y=0,x=!1,U=null),(Q.innerHTML&&oe.innerHTML==null||Q.textContent&&oe.textContent==null)&&d(M,""),U?z(O.dynamicChildren,U,M,v,K,Zo(W,H),$):x||D(O,W,M,null,v,K,Zo(W,H),$,!1),Y>0){if(Y&16)V(M,Q,oe,v,H);else if(Y&2&&Q.class!==oe.class&&s(M,"class",null,oe.class,H),Y&4&&s(M,"style",Q.style,oe.style,H),Y&8){const de=W.dynamicProps;for(let Se=0;Se<de.length;Se++){const ke=de[Se],Me=Q[ke],Ve=oe[ke];(Ve!==Me||ke==="value")&&s(M,ke,Me,Ve,H,v)}}Y&1&&O.children!==W.children&&d(M,W.children)}else!x&&U==null&&V(M,Q,oe,v,H);((ie=oe.onVnodeUpdated)||Z)&&xt(()=>{ie&&Ht(ie,v,W,O),Z&&wi(W,O,v,"updated")},K)},z=(O,W,v,K,H,$,x)=>{for(let M=0;M<W.length;M++){const Y=O[M],U=W[M],Z=Y.el&&(Y.type===Ue||!fn(Y,U)||Y.shapeFlag&198)?p(Y.el):v;f(Y,U,Z,null,K,H,$,x,!0)}},V=(O,W,v,K,H)=>{if(W!==v){if(W!==We)for(const $ in W)!vn($)&&!($ in v)&&s(O,$,W[$],null,H,K);for(const $ in v){if(vn($))continue;const x=v[$],M=W[$];x!==M&&$!=="value"&&s(O,$,M,x,H,K)}"value"in v&&s(O,"value",W.value,v.value,H)}},_=(O,W,v,K,H,$,x,M,Y)=>{const U=W.el=O?O.el:r(""),Z=W.anchor=O?O.anchor:r("");let{patchFlag:Q,dynamicChildren:oe,slotScopeIds:ie}=W;ie&&(M=M?M.concat(ie):ie),O==null?(n(U,v,K),n(Z,v,K),P(W.children||[],v,Z,H,$,x,M,Y)):Q>0&&Q&64&&oe&&O.dynamicChildren&&O.dynamicChildren.length===oe.length?(z(O.dynamicChildren,oe,v,H,$,x,M),(W.key!=null||H&&W===H.subTree)&&Ql(O,W,!0)):D(O,W,v,Z,H,$,x,M,Y)},L=(O,W,v,K,H,$,x,M,Y)=>{W.slotScopeIds=M,O==null?W.shapeFlag&512?H.ctx.activate(W,v,K,x,Y):y(W,v,K,H,$,x,Y):A(O,W,Y)},y=(O,W,v,K,H,$,x)=>{const M=O.component=_u(O,K,H);if(Pl(O)&&(M.ctx.renderer=ae),$u(M,!1,x),M.asyncDep){if(H&&H.registerDep(M,F,x),!O.el){const Y=M.subTree=re(li);k(null,Y,W,v),O.placeholder=Y.el}}else F(M,O,W,v,H,$,x)},A=(O,W,v)=>{const K=W.component=O.component;if(ru(O,W,v))if(K.asyncDep&&!K.asyncResolved){E(K,W,v);return}else K.next=W,K.update();else W.el=O.el,K.vnode=W},F=(O,W,v,K,H,$,x)=>{const M=()=>{if(O.isMounted){let{next:Q,bu:oe,u:ie,parent:de,vnode:Se}=O;{const Je=ea(O);if(Je){Q&&(Q.el=Se.el,E(O,Q,x)),Je.asyncDep.then(()=>{xt(()=>{O.isUnmounted||U()},H)});return}}let ke=Q,Me;xi(O,!1),Q?(Q.el=Se.el,E(O,Q,x)):Q=Se,oe&&eo(oe),(Me=Q.props&&Q.props.onVnodeBeforeUpdate)&&Ht(Me,de,Q,Se),xi(O,!0);const Ve=vr(O),Ge=O.subTree;O.subTree=Ve,f(Ge,Ve,p(Ge.el),Te(Ge),O,H,$),Q.el=Ve.el,ke===null&&lu(O,Ve.el),ie&&xt(ie,H),(Me=Q.props&&Q.props.onVnodeUpdated)&&xt(()=>Ht(Me,de,Q,Se),H)}else{let Q;const{el:oe,props:ie}=W,{bm:de,m:Se,parent:ke,root:Me,type:Ve}=O,Ge=Xi(W);xi(O,!1),de&&eo(de),!Ge&&(Q=ie&&ie.onVnodeBeforeMount)&&Ht(Q,ke,W),xi(O,!0);{Me.ce&&Me.ce._hasShadowRoot()&&Me.ce._injectChildStyle(Ve,O.parent?O.parent.type:void 0);const Je=O.subTree=vr(O);f(null,Je,v,K,O,H,$),W.el=Je.el}if(Se&&xt(Se,H),!Ge&&(Q=ie&&ie.onVnodeMounted)){const Je=W;xt(()=>Ht(Q,ke,Je),H)}(W.shapeFlag&256||ke&&Xi(ke.vnode)&&ke.vnode.shapeFlag&256)&&O.a&&xt(O.a,H),O.isMounted=!0,W=v=K=null}};O.scope.on();const Y=O.effect=new fl(M);O.scope.off();const U=O.update=Y.run.bind(Y),Z=O.job=Y.runIfDirty.bind(Y);Z.i=O,Z.id=O.uid,Y.scheduler=()=>Ps(Z),xi(O,!0),U()},E=(O,W,v)=>{W.component=O;const K=O.vnode.props;O.vnode=W,O.next=null,cu(O,W.props,K,v),pu(O,W.children,v),oi(),cr(O),si()},D=(O,W,v,K,H,$,x,M,Y=!1)=>{const U=O&&O.children,Z=O?O.shapeFlag:0,Q=W.children,{patchFlag:oe,shapeFlag:ie}=W;if(oe>0){if(oe&128){X(U,Q,v,K,H,$,x,M,Y);return}else if(oe&256){N(U,Q,v,K,H,$,x,M,Y);return}}ie&8?(Z&16&&pe(U,H,$),Q!==U&&d(v,Q)):Z&16?ie&16?X(U,Q,v,K,H,$,x,M,Y):pe(U,H,$,!0):(Z&8&&d(v,""),ie&16&&P(Q,v,K,H,$,x,M,Y))},N=(O,W,v,K,H,$,x,M,Y)=>{O=O||Zi,W=W||Zi;const U=O.length,Z=W.length,Q=Math.min(U,Z);let oe;for(oe=0;oe<Q;oe++){const ie=W[oe]=Y?Xt(W[oe]):Ut(W[oe]);f(O[oe],ie,v,null,H,$,x,M,Y)}U>Z?pe(O,H,$,!0,!1,Q):P(W,v,K,H,$,x,M,Y,Q)},X=(O,W,v,K,H,$,x,M,Y)=>{let U=0;const Z=W.length;let Q=O.length-1,oe=Z-1;for(;U<=Q&&U<=oe;){const ie=O[U],de=W[U]=Y?Xt(W[U]):Ut(W[U]);if(fn(ie,de))f(ie,de,v,null,H,$,x,M,Y);else break;U++}for(;U<=Q&&U<=oe;){const ie=O[Q],de=W[oe]=Y?Xt(W[oe]):Ut(W[oe]);if(fn(ie,de))f(ie,de,v,null,H,$,x,M,Y);else break;Q--,oe--}if(U>Q){if(U<=oe){const ie=oe+1,de=ie<Z?W[ie].el:K;for(;U<=oe;)f(null,W[U]=Y?Xt(W[U]):Ut(W[U]),v,de,H,$,x,M,Y),U++}}else if(U>oe)for(;U<=Q;)G(O[U],H,$,!0),U++;else{const ie=U,de=U,Se=new Map;for(U=de;U<=oe;U++){const st=W[U]=Y?Xt(W[U]):Ut(W[U]);st.key!=null&&Se.set(st.key,U)}let ke,Me=0;const Ve=oe-de+1;let Ge=!1,Je=0;const De=new Array(Ve);for(U=0;U<Ve;U++)De[U]=0;for(U=ie;U<=Q;U++){const st=O[U];if(Me>=Ve){G(st,H,$,!0);continue}let Xe;if(st.key!=null)Xe=Se.get(st.key);else for(ke=de;ke<=oe;ke++)if(De[ke-de]===0&&fn(st,W[ke])){Xe=ke;break}Xe===void 0?G(st,H,$,!0):(De[Xe-de]=U+1,Xe>=Je?Je=Xe:Ge=!0,f(st,W[Xe],v,null,H,$,x,M,Y),Me++)}const Zt=Ge?vu(De):Zi;for(ke=Zt.length-1,U=Ve-1;U>=0;U--){const st=de+U,Xe=W[st],Ft=W[st+1],Pi=st+1<Z?Ft.el||ta(Ft):K;De[U]===0?f(null,Xe,v,Pi,H,$,x,M,Y):Ge&&(ke<0||U!==Zt[ke]?j(Xe,v,Pi,2):ke--)}}},j=(O,W,v,K,H=null)=>{const{el:$,type:x,transition:M,children:Y,shapeFlag:U}=O;if(U&6){j(O.component.subTree,W,v,K);return}if(U&128){O.suspense.move(W,v,K);return}if(U&64){x.move(O,W,v,ae);return}if(x===Ue){n($,W,v);for(let Q=0;Q<Y.length;Q++)j(Y[Q],W,v,K);n(O.anchor,W,v);return}if(x===to){C(O,W,v);return}if(K!==2&&U&1&&M)if(K===0)M.persisted&&!$[qo]?n($,W,v):(M.beforeEnter($),n($,W,v),xt(()=>M.enter($),H));else{const{leave:Q,delayLeave:oe,afterLeave:ie}=M,de=()=>{O.ctx.isUnmounted?o($):n($,W,v)},Se=()=>{const ke=$._isLeaving||!!$[qo];$._isLeaving&&$[qo](!0),M.persisted&&!ke?de():Q($,()=>{de(),ie&&ie()})};oe?oe($,de,Se):Se()}else n($,W,v)},G=(O,W,v,K=!1,H=!1)=>{const{type:$,props:x,ref:M,children:Y,dynamicChildren:U,shapeFlag:Z,patchFlag:Q,dirs:oe,cacheIndex:ie,memo:de}=O;if(Q===-2&&(H=!1),M!=null&&(oi(),kn(M,null,v,O,!0),si()),ie!=null&&(W.renderCache[ie]=void 0),Z&256){W.ctx.deactivate(O);return}const Se=Z&1&&oe,ke=!Xi(O);let Me;if(ke&&(Me=x&&x.onVnodeBeforeUnmount)&&Ht(Me,W,O),Z&6)le(O.component,v,K);else{if(Z&128){O.suspense.unmount(v,K);return}Se&&wi(O,null,W,"beforeUnmount"),Z&64?O.type.remove(O,W,v,ae,K):U&&!U.hasOnce&&($!==Ue||Q>0&&Q&64)?pe(U,W,v,!1,!0):($===Ue&&Q&384||!H&&Z&16)&&pe(Y,W,v),K&&ne(O)}const Ve=de!=null&&ie==null;(ke&&(Me=x&&x.onVnodeUnmounted)||Se||Ve)&&xt(()=>{Me&&Ht(Me,W,O),Se&&wi(O,null,W,"unmounted"),Ve&&(O.el=null)},v)},ne=O=>{const{type:W,el:v,anchor:K,transition:H}=O;if(W===Ue){se(v,K);return}if(W===to){T(O);return}const $=()=>{o(v),H&&!H.persisted&&H.afterLeave&&H.afterLeave()};if(O.shapeFlag&1&&H&&!H.persisted){const{leave:x,delayLeave:M}=H,Y=()=>x(v,$);M?M(O.el,$,Y):Y()}else $()},se=(O,W)=>{let v;for(;O!==W;)v=b(O),o(O),O=v;o(W)},le=(O,W,v)=>{const{bum:K,scope:H,job:$,subTree:x,um:M,m:Y,a:U}=O;kr(Y),kr(U),K&&eo(K),H.stop(),$&&($.flags|=8,G(x,O,W,v)),M&&xt(M,W),xt(()=>{O.isUnmounted=!0},W)},pe=(O,W,v,K=!1,H=!1,$=0)=>{for(let x=$;x<O.length;x++)G(O[x],W,v,K,H)},Te=O=>{if(O.shapeFlag&6)return Te(O.component.subTree);if(O.shapeFlag&128)return O.suspense.next();const W=b(O.anchor||O.el),v=W&&W[Bd];return v?b(v):W};let be=!1;const q=(O,W,v)=>{let K;O==null?W._vnode&&(G(W._vnode,null,null,!0),K=W._vnode.component):f(W._vnode||null,O,W,null,null,null,v),W._vnode=O,be||(be=!0,cr(K),Al(),be=!1)},ae={p:f,um:G,m:j,r:ne,mt:y,mc:P,pc:D,pbc:z,n:Te,o:e};return{render:q,hydrate:void 0,createApp:eu(q)}}function Zo({type:e,props:t},i){return i==="svg"&&e==="foreignObject"||i==="mathml"&&e==="annotation-xml"&&t&&t.encoding&&t.encoding.includes("html")?void 0:i}function xi({effect:e,job:t},i){i?(e.flags|=32,t.flags|=4):(e.flags&=-33,t.flags&=-5)}function gu(e,t){return(!e||e&&!e.pendingBranch)&&t&&!t.persisted}function Ql(e,t,i=!1){const n=e.children,o=t.children;if($e(n)&&$e(o))for(let s=0;s<n.length;s++){const l=n[s];let r=o[s];r.shapeFlag&1&&!r.dynamicChildren&&((r.patchFlag<=0||r.patchFlag===32)&&(r=o[s]=Xt(o[s]),r.el=l.el),!i&&r.patchFlag!==-2&&Ql(l,r)),r.type===Ro&&(r.patchFlag===-1&&(r=o[s]=Xt(r)),r.el=l.el),r.type===li&&!r.el&&(r.el=l.el)}}function vu(e){const t=e.slice(),i=[0];let n,o,s,l,r;const a=e.length;for(n=0;n<a;n++){const c=e[n];if(c!==0){if(o=i[i.length-1],e[o]<c){t[n]=o,i.push(n);continue}for(s=0,l=i.length-1;s<l;)r=s+l>>1,e[i[r]]<c?s=r+1:l=r;c<e[i[s]]&&(s>0&&(t[n]=i[s-1]),i[s]=n)}}for(s=i.length,l=i[s-1];s-- >0;)i[s]=l,l=t[l];return i}function ea(e){const t=e.subTree.component;if(t)return t.asyncDep&&!t.asyncResolved?t:ea(t)}function kr(e){if(e)for(let t=0;t<e.length;t++)e[t].flags|=8}function ta(e){if(e.placeholder)return e.placeholder;const t=e.component;return t?ta(t.subTree):null}const ia=e=>e.__isSuspense;function bu(e,t){t&&t.pendingBranch?$e(e)?t.effects.push(...e):t.effects.push(e):$d(e)}const Ue=Symbol.for("v-fgt"),Ro=Symbol.for("v-txt"),li=Symbol.for("v-cmt"),to=Symbol.for("v-stc"),ii=[];let It=null;function ee(e=!1){ii.push(It=e?null:[])}function Ws(){ii.pop(),It=ii[ii.length-1]||null}let Ln=1;function wr(e,t=!1){Ln+=e,e<0&&It&&t&&(It.hasOnce=!0)}function na(e){return e.dynamicChildren=Ln>0?It||Zi:null,Ws(),Ln>0&&It&&It.push(e),e}function te(e,t,i,n,o,s){return na(m(e,t,i,n,o,s,!0))}function Dt(e,t,i,n,o){return na(re(e,t,i,n,o,!0))}function Us(e){return e?e.__v_isVNode===!0:!1}function fn(e,t){return e.type===t.type&&e.key===t.key}const oa=({key:e})=>e??null,io=({ref:e,ref_key:t,ref_for:i})=>(typeof e=="number"&&(e=""+e),e!=null?it(e)||Ye(e)||Ee(e)?{i:ct,r:e,k:t,f:!!i}:e:null);function m(e,t=null,i=null,n=0,o=null,s=e===Ue?0:1,l=!1,r=!1){const a={__v_isVNode:!0,__v_skip:!0,type:e,props:t,key:t&&oa(t),ref:t&&io(t),scopeId:Ml,slotScopeIds:null,children:i,component:null,suspense:null,ssContent:null,ssFallback:null,dirs:null,transition:null,el:null,anchor:null,target:null,targetStart:null,targetAnchor:null,staticCount:0,shapeFlag:s,patchFlag:n,dynamicProps:o,dynamicChildren:null,appContext:null,ctx:ct};return r?(ko(a,i),s&128&&e.normalize(a)):i&&(a.shapeFlag|=it(i)?8:16),Ln>0&&!l&&It&&(a.patchFlag>0||s&6)&&a.patchFlag!==32&&It.push(a),a}const re=yu;function yu(e,t=null,i=null,n=0,o=null,s=!1){if((!e||e===Vd)&&(e=li),Us(e)){const r=nn(e,t,!0);return i&&ko(r,i),Ln>0&&!s&&It&&(r.shapeFlag&6?It[It.indexOf(e)]=r:It.push(r)),r.patchFlag=-2,r}if(Bu(e)&&(e=e.__vccOpts),t){t=ku(t);let{class:r,style:a}=t;r&&!it(r)&&(t.class=_e(r)),He(a)&&(Rs(a)&&!$e(a)&&(a=dt({},a)),t.style=An(a))}const l=it(e)?1:ia(e)?128:Md(e)?64:He(e)?4:Ee(e)?2:0;return m(e,t,i,n,o,l,s,!0)}function ku(e){return e?Rs(e)||ql(e)?dt({},e):e:null}function nn(e,t,i=!1,n=!1){const{props:o,ref:s,patchFlag:l,children:r,transition:a}=e,c=t?wu(o||{},t):o,d={__v_isVNode:!0,__v_skip:!0,type:e.type,props:c,key:c&&oa(c),ref:t&&t.ref?i&&s?$e(s)?s.concat(io(t)):[s,io(t)]:io(t):s,scopeId:e.scopeId,slotScopeIds:e.slotScopeIds,children:r,target:e.target,targetStart:e.targetStart,targetAnchor:e.targetAnchor,staticCount:e.staticCount,shapeFlag:e.shapeFlag,patchFlag:t&&e.type!==Ue?l===-1?16:l|16:l,dynamicProps:e.dynamicProps,dynamicChildren:e.dynamicChildren,appContext:e.appContext,dirs:e.dirs,transition:a,component:e.component,suspense:e.suspense,ssContent:e.ssContent&&nn(e.ssContent),ssFallback:e.ssFallback&&nn(e.ssFallback),placeholder:e.placeholder,el:e.el,anchor:e.anchor,ctx:e.ctx,ce:e.ce};return a&&n&&Ns(d,a.clone(d)),d}function $t(e=" ",t=0){return re(Ro,null,e,t)}function gt(e,t){const i=re(to,null,e);return i.staticCount=t,i}function Oe(e="",t=!1){return t?(ee(),Dt(li,null,e)):re(li,null,e)}function Ut(e){return e==null||typeof e=="boolean"?re(li):$e(e)?re(Ue,null,e.slice()):Us(e)?Xt(e):re(Ro,null,String(e))}function Xt(e){return e.el===null&&e.patchFlag!==-1||e.memo?e:nn(e)}function ko(e,t){let i=0;const{shapeFlag:n}=e;if(t==null)t=null;else if($e(t))i=16;else if(typeof t=="object")if(n&65){const o=t.default;o&&(o._c&&(o._d=!1),ko(e,o()),o._c&&(o._d=!0));return}else{i=32;const o=t._;!o&&!ql(t)?t._ctx=ct:o===3&&ct&&(ct.slots._===1?t._=1:(t._=2,e.patchFlag|=1024))}else if(Ee(t)){if(n&65){ko(e,{default:t});return}t={default:t,_ctx:ct},i=32}else t=String(t),n&64?(i=16,t=[$t(t)]):i=8;e.children=t,e.shapeFlag|=i}function wu(...e){const t={};for(let i=0;i<e.length;i++){const n=e[i];for(const o in n)if(o==="class")t.class!==n.class&&(t.class=_e([t.class,n.class]));else if(o==="style")t.style=An([t.style,n.style]);else if(Co(o)){const s=t[o],l=n[o];l&&s!==l&&!($e(s)&&s.includes(l))?t[o]=s?[].concat(s,l):l:l==null&&s==null&&!$o(o)&&(t[o]=l)}else o!==""&&(t[o]=n[o])}return t}function Ht(e,t,i,n=null){Nt(e,t,7,[i,n])}const xu=jl();let Su=0;function _u(e,t,i){const n=e.type,o=(t?t.appContext:e.appContext)||xu,s={uid:Su++,vnode:e,type:n,parent:t,appContext:o,root:null,next:null,subTree:null,effect:null,update:null,job:null,scope:new Yc(!0),render:null,proxy:null,exposed:null,exposeProxy:null,withProxy:null,provides:t?t.provides:Object.create(o.provides),ids:t?t.ids:["",0,0],accessCache:null,renderCache:[],components:null,directives:null,propsOptions:Zl(n,o),emitsOptions:Wl(n,o),emit:null,emitted:null,propsDefaults:We,inheritAttrs:n.inheritAttrs,ctx:We,data:We,props:We,attrs:We,slots:We,refs:We,setupState:We,setupContext:null,suspense:i,suspenseId:i?i.pendingId:0,asyncDep:null,asyncResolved:!1,isMounted:!1,isUnmounted:!1,isDeactivated:!1,bc:null,c:null,bm:null,m:null,bu:null,u:null,um:null,bum:null,da:null,a:null,rtg:null,rtc:null,ec:null,sp:null};return s.ctx={_:s},s.root=t?t.root:s,s.emit=iu.bind(null,s),e.ce&&e.ce(s),s}let ht=null;const Cu=()=>ht||ct;let wo,vs;{const e=Ao(),t=(i,n)=>{let o;return(o=e[i])||(o=e[i]=[]),o.push(n),s=>{o.length>1?o.forEach(l=>l(s)):o[0](s)}};wo=t("__VUE_INSTANCE_SETTERS__",i=>ht=i),vs=t("__VUE_SSR_SETTERS__",i=>On=i)}const Hn=e=>{const t=ht;return wo(e),e.scope.on(),()=>{e.scope.off(),wo(t)}},xr=()=>{ht&&ht.scope.off(),wo(null)};function sa(e){return e.vnode.shapeFlag&4}let On=!1;function $u(e,t=!1,i=!1){t&&vs(t);const{props:n,children:o}=e.vnode,s=sa(e);au(e,n,s,t),fu(e,o,i||t);const l=s?Iu(e,t):void 0;return t&&vs(!1),l}function Iu(e,t){const i=e.type;e.accessCache=Object.create(null),e.proxy=new Proxy(e.ctx,qd);const{setup:n}=i;if(n){oi();const o=e.setupContext=n.length>1?Tu(e):null,s=Hn(e),l=zn(n,e,0,[e.props,o]),r=sl(l);if(si(),s(),(r||e.sp)&&!Xi(e)&&Rl(e),r){if(l.then(xr,xr),t)return l.then(a=>{Sr(e,a)}).catch(a=>{Do(a,e,0)});e.asyncDep=l}else Sr(e,l)}else ra(e)}function Sr(e,t,i){Ee(t)?e.type.__ssrInlineRender?e.ssrRender=t:e.render=t:He(t)&&(e.setupState=$l(t)),ra(e)}function ra(e,t,i){const n=e.type;e.render||(e.render=n.render||qt);{const o=Hn(e);oi();try{Gd(e)}finally{si(),o()}}}const Eu={get(e,t){return pt(e,"get",""),e[t]}};function Tu(e){const t=i=>{e.exposed=i||{}};return{attrs:new Proxy(e.attrs,Eu),slots:e.slots,emit:e.emit,expose:t}}function Po(e){return e.exposed?e.exposeProxy||(e.exposeProxy=new Proxy($l(gd(e.exposed)),{get(t,i){if(i in t)return t[i];if(i in wn)return wn[i](e)},has(t,i){return i in t||i in wn}})):e.proxy}function Au(e,t=!0){return Ee(e)?e.displayName||e.name:e.name||t&&e.__name}function Bu(e){return Ee(e)&&"__vccOpts"in e}const xe=(e,t)=>wd(e,t,On),Mu="3.5.40";/**
* @vue/runtime-dom v3.5.40
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/let bs;const _r=typeof window<"u"&&window.trustedTypes;if(_r)try{bs=_r.createPolicy("vue",{createHTML:e=>e})}catch{}const la=bs?e=>bs.createHTML(e):e=>e,Du="http://www.w3.org/2000/svg",Lu="http://www.w3.org/1998/Math/MathML",Jt=typeof document<"u"?document:null,Cr=Jt&&Jt.createElement("template"),Ou={insert:(e,t,i)=>{t.insertBefore(e,i||null)},remove:e=>{const t=e.parentNode;t&&t.removeChild(e)},createElement:(e,t,i,n)=>{const o=t==="svg"?Jt.createElementNS(Du,e):t==="mathml"?Jt.createElementNS(Lu,e):i?Jt.createElement(e,{is:i}):Jt.createElement(e);return e==="select"&&n&&n.multiple!=null&&o.setAttribute("multiple",n.multiple),o},createText:e=>Jt.createTextNode(e),createComment:e=>Jt.createComment(e),setText:(e,t)=>{e.nodeValue=t},setElementText:(e,t)=>{e.textContent=t},parentNode:e=>e.parentNode,nextSibling:e=>e.nextSibling,querySelector:e=>Jt.querySelector(e),setScopeId(e,t){e.setAttribute(t,"")},insertStaticContent(e,t,i,n,o,s){const l=i?i.previousSibling:t.lastChild;if(o&&(o===s||o.nextSibling))for(;t.insertBefore(o.cloneNode(!0),i),!(o===s||!(o=o.nextSibling)););else{Cr.innerHTML=la(n==="svg"?`<svg>${e}</svg>`:n==="mathml"?`<math>${e}</math>`:e);const r=Cr.content;if(n==="svg"||n==="mathml"){const a=r.firstChild;for(;a.firstChild;)r.appendChild(a.firstChild);r.removeChild(a)}t.insertBefore(r,i)}return[l?l.nextSibling:t.firstChild,i?i.previousSibling:t.lastChild]}},Ru=Symbol("_vtc");function Pu(e,t,i){const n=e[Ru];n&&(t=(t?[t,...n]:[...n]).join(" ")),t==null?e.removeAttribute("class"):i?e.setAttribute("class",t):e.className=t}const xo=Symbol("_vod"),aa=Symbol("_vsh"),ys={name:"show",beforeMount(e,{value:t},{transition:i}){e[xo]=e.style.display==="none"?"":e.style.display,i&&t?i.beforeEnter(e):pn(e,t)},mounted(e,{value:t},{transition:i}){i&&t&&i.enter(e)},updated(e,{value:t,oldValue:i},{transition:n}){!t!=!i&&(n?t?(n.beforeEnter(e),pn(e,!0),n.enter(e)):n.leave(e,()=>{pn(e,!1)}):pn(e,t))},beforeUnmount(e,{value:t}){pn(e,t)}};function pn(e,t){e.style.display=t?e[xo]:"none",e[aa]=!t}const Nu=Symbol(""),zu=/(?:^|;)\s*display\s*:/;function Fu(e,t,i){const n=e.style,o=it(i);let s=!1;if(i&&!o){if(t)if(it(t))for(const l of t.split(";")){const r=l.slice(0,l.indexOf(":")).trim();i[r]==null&&mn(n,r,"")}else for(const l in t)i[l]==null&&mn(n,l,"");for(const l in i){l==="display"&&(s=!0);const r=i[l];r!=null?ju(e,l,!it(t)&&t?t[l]:void 0,r)||mn(n,l,r):mn(n,l,"")}}else if(o){if(t!==i){const l=n[Nu];l&&(i+=";"+l),n.cssText=i,s=zu.test(i)}}else t&&e.removeAttribute("style");xo in e&&(e[xo]=s?n.display:"",e[aa]&&(n.display="none"))}const $r=/\s*!important$/;function mn(e,t,i){if($e(i))i.forEach(n=>mn(e,t,n));else if(i==null&&(i=""),t.startsWith("--"))e.setProperty(t,i);else{const n=Hu(e,t);$r.test(i)?e.setProperty(yi(n),i.replace($r,""),"important"):e[n]=i}}const Ir=["Webkit","Moz","ms"],Yo={};function Hu(e,t){const i=Yo[t];if(i)return i;let n=wt(t);if(n!=="filter"&&n in e)return Yo[t]=n;n=Eo(n);for(let o=0;o<Ir.length;o++){const s=Ir[o]+n;if(s in e)return Yo[t]=s}return t}function ju(e,t,i,n){return e.tagName==="TEXTAREA"&&(t==="width"||t==="height")&&it(n)&&i===n}const Er="http://www.w3.org/1999/xlink";function Tr(e,t,i,n,o,s=Gc(t)){n&&t.startsWith("xlink:")?i==null?e.removeAttributeNS(Er,t.slice(6,t.length)):e.setAttributeNS(Er,t,i):i==null||s&&!cl(i)?e.removeAttribute(t):e.setAttribute(t,s?"":Rt(i)?String(i):i)}function Ar(e,t,i,n,o){if(t==="innerHTML"||t==="textContent"){i!=null&&(e[t]=t==="innerHTML"?la(i):i);return}const s=e.tagName;if(t==="value"&&s!=="PROGRESS"&&!s.includes("-")){const r=s==="OPTION"?e.getAttribute("value")||"":e.value,a=i==null?e.type==="checkbox"?"on":"":String(i);(r!==a||!("_value"in e))&&(e.value=a),i==null&&e.removeAttribute(t),e._value=i;return}let l=!1;if(i===""||i==null){const r=typeof e[t];r==="boolean"?i=cl(i):i==null&&r==="string"?(i="",l=!0):r==="number"&&(i=0,l=!0)}try{e[t]=i}catch{}l&&e.removeAttribute(o||t)}function hi(e,t,i,n){e.addEventListener(t,i,n)}function Wu(e,t,i,n){e.removeEventListener(t,i,n)}const Br=Symbol("_vei");function Uu(e,t,i,n,o=null){const s=e[Br]||(e[Br]={}),l=s[t];if(n&&l)l.value=n;else{const[r,a]=qu(t);if(n){const c=s[t]=Yu(n,o);hi(e,r,c,a)}else l&&(Wu(e,r,l,a),s[t]=void 0)}}const Vu=/(Once|Passive|Capture)$/,Ku=/^on:?(?:Once|Passive|Capture)$/;function qu(e){let t,i;for(;(i=e.match(Vu))&&!Ku.test(e);)t||(t={}),e=e.slice(0,e.length-i[1].length),t[i[1].toLowerCase()]=!0;return[e[2]===":"?e.slice(3):yi(e.slice(2)),t]}let Jo=0;const Gu=Promise.resolve(),Zu=()=>Jo||(Gu.then(()=>Jo=0),Jo=Date.now());function Yu(e,t){const i=n=>{if(!n._vts)n._vts=Date.now();else if(n._vts<=i.attached)return;const o=i.value;if($e(o)){const s=n.stopImmediatePropagation;n.stopImmediatePropagation=()=>{s.call(n),n._stopped=!0};const l=o.slice(),r=[n];for(let a=0;a<l.length&&!n._stopped;a++){const c=l[a];c&&Nt(c,t,5,r)}}else Nt(o,t,5,[n])};return i.value=e,i.attached=Zu(),i}const Mr=e=>e.charCodeAt(0)===111&&e.charCodeAt(1)===110&&e.charCodeAt(2)>96&&e.charCodeAt(2)<123,Ju=(e,t,i,n,o,s)=>{const l=o==="svg";t==="class"?Pu(e,n,l):t==="style"?Fu(e,i,n):Co(t)?$o(t)||Uu(e,t,i,n,s):(t[0]==="."?(t=t.slice(1),!0):t[0]==="^"?(t=t.slice(1),!1):Xu(e,t,n,l))?(Ar(e,t,n),!e.tagName.includes("-")&&(t==="value"||t==="checked"||t==="selected")&&Tr(e,t,n,l,s,t!=="value")):e._isVueCE&&(Qu(e,t)||e._def.__asyncLoader&&(/[A-Z]/.test(t)||!it(n)))?Ar(e,wt(t),n,s,t):(t==="true-value"?e._trueValue=n:t==="false-value"&&(e._falseValue=n),Tr(e,t,n,l))};function Xu(e,t,i,n){if(n)return!!(t==="innerHTML"||t==="textContent"||t in e&&Mr(t)&&Ee(i));if(t==="spellcheck"||t==="draggable"||t==="translate"||t==="autocorrect"||t==="sandbox"&&e.tagName==="IFRAME"||t==="form"||t==="list"&&e.tagName==="INPUT"||t==="type"&&e.tagName==="TEXTAREA")return!1;if(t==="width"||t==="height"){const o=e.tagName;if(o==="IMG"||o==="VIDEO"||o==="CANVAS"||o==="SOURCE")return!1}return Mr(t)&&it(i)?!1:t in e}function Qu(e,t){const i=e._def.props;if(!i)return!1;const n=wt(t);return Array.isArray(i)?i.some(o=>wt(o)===n):Object.keys(i).some(o=>wt(o)===n)}const on=e=>{const t=e.props["onUpdate:modelValue"]||!1;return $e(t)?i=>eo(t,i):t};function ef(e){e.target.composing=!0}function Dr(e){const t=e.target;t.composing&&(t.composing=!1,t.dispatchEvent(new Event("input")))}const ni=Symbol("_assign");function Lr(e,t,i){return t&&(e=e.trim()),i&&(e=To(e)),e}const So={created(e,{modifiers:{lazy:t,trim:i,number:n}},o){e[ni]=on(o);const s=n||o.props&&o.props.type==="number";hi(e,t?"change":"input",l=>{l.target.composing||e[ni](Lr(e.value,i,s))}),(i||s)&&hi(e,"change",()=>{e.value=Lr(e.value,i,s)}),t||(hi(e,"compositionstart",ef),hi(e,"compositionend",Dr),hi(e,"change",Dr))},mounted(e,{value:t}){e.value=t??""},beforeUpdate(e,{value:t,oldValue:i,modifiers:{lazy:n,trim:o,number:s}},l){if(e[ni]=on(l),e.composing)return;const r=(s||e.type==="number")&&!/^0\d/.test(e.value)?To(e.value):e.value,a=t??"";if(r===a)return;const c=e.getRootNode();(c instanceof Document||c instanceof ShadowRoot)&&c.activeElement===e&&e.type!=="range"&&(n&&t===i||o&&e.value.trim()===a)||(e.value=a)}},Yn={deep:!0,created(e,t,i){e[ni]=on(i),hi(e,"change",()=>{const n=e._modelValue,o=Rn(e),s=e.checked,l=e[ni];if($e(n)){const r=Ts(n,o),a=r!==-1;if(s&&!a)l(n.concat(o));else if(!s&&a){const c=[...n];c.splice(r,1),l(c)}}else if(rn(n)){const r=new Set(n);s?r.add(o):r.delete(o),l(r)}else l(ca(e,s))})},mounted:Or,beforeUpdate(e,t,i){e[ni]=on(i),Or(e,t,i)}};function Or(e,{value:t,oldValue:i},n){e._modelValue=t;let o;if($e(t))o=Ts(t,n.props.value)>-1;else if(rn(t))o=t.has(n.props.value);else{if(t===i)return;o=ln(t,ca(e,!0))}e.checked!==o&&(e.checked=o)}const tf={deep:!0,created(e,{value:t,modifiers:{number:i}},n){e._modelValue=t,hi(e,"change",()=>{const o=Array.prototype.filter.call(e.options,s=>s.selected).map(s=>i?To(Rn(s)):Rn(s));e[ni](e.multiple?rn(e._modelValue)?new Set(o):o:o[0]),e._assigning=!0,El(()=>{e._assigning=!1})}),e[ni]=on(n)},mounted(e,{value:t}){Rr(e,t)},beforeUpdate(e,{value:t},i){e._modelValue=t,e[ni]=on(i)},updated(e,{value:t}){e._assigning||Rr(e,t)}};function Rr(e,t){const i=e.multiple,n=$e(t);if(!(i&&!n&&!rn(t))){for(let o=0,s=e.options.length;o<s;o++){const l=e.options[o],r=Rn(l);if(i)if(n){const a=typeof r;a==="string"||a==="number"?l.selected=t.some(c=>String(c)===String(r)):l.selected=Ts(t,r)>-1}else l.selected=t.has(r);else if(ln(Rn(l),t)){e.selectedIndex!==o&&(e.selectedIndex=o);return}}!i&&e.selectedIndex!==-1&&(e.selectedIndex=-1)}}function Rn(e){return"_value"in e?e._value:e.value}function ca(e,t){const i=t?"_trueValue":"_falseValue";return i in e?e[i]:t}const nf=["ctrl","shift","alt","meta"],of={stop:e=>e.stopPropagation(),prevent:e=>e.preventDefault(),self:e=>e.target!==e.currentTarget,ctrl:e=>!e.ctrlKey,shift:e=>!e.shiftKey,alt:e=>!e.altKey,meta:e=>!e.metaKey,left:e=>"button"in e&&e.button!==0,middle:e=>"button"in e&&e.button!==1,right:e=>"button"in e&&e.button!==2,exact:(e,t)=>nf.some(i=>e[`${i}Key`]&&!t.includes(i))},Mt=(e,t)=>{if(!e)return e;const i=e._withMods||(e._withMods={}),n=t.join(".");return i[n]||(i[n]=((o,...s)=>{for(let l=0;l<t.length;l++){const r=of[t[l]];if(r&&r(o,t))return}return e(o,...s)}))},sf={esc:"escape",space:" ",up:"arrow-up",left:"arrow-left",right:"arrow-right",down:"arrow-down",delete:"backspace"},rf=(e,t)=>{const i=e._withKeys||(e._withKeys={}),n=t.join(".");return i[n]||(i[n]=(o=>{if(!("key"in o))return;const s=yi(o.key);if(t.some(l=>l===s||sf[l]===s))return e(o)}))},lf=dt({patchProp:Ju},Ou);let Pr;function af(){return Pr||(Pr=hu(lf))}const da=((...e)=>{const t=af().createApp(...e),{mount:i}=t;return t.mount=n=>{const o=df(n);if(!o)return;const s=t._component;!Ee(s)&&!s.render&&!s.template&&(s.template=o.innerHTML),o.nodeType===1&&(o.textContent="");const l=i(o,!1,cf(o));return o instanceof Element&&(o.removeAttribute("v-cloak"),o.setAttribute("data-v-app","")),l},t});function cf(e){if(e instanceof SVGElement)return"svg";if(typeof MathMLElement=="function"&&e instanceof MathMLElement)return"mathml"}function df(e){return it(e)?document.querySelector(e):e}const uf="slidev-config.json",sn={enableWebServeJump:!1,webServeUrl:"http://127.0.0.1:6806",normalizeHeadingSizes:!1},mi=Mo({...sn});function ff(e){if(!e||typeof e!="object")return{...sn};const t=e;return{enableWebServeJump:!!t.enableWebServeJump,webServeUrl:typeof t.webServeUrl=="string"&&t.webServeUrl.trim()?t.webServeUrl.trim():sn.webServeUrl,normalizeHeadingSizes:!!t.normalizeHeadingSizes}}function Ai(e){if(!e||typeof e!="object")return{...mi};const t=e;return t.enableWebServeJump!==void 0&&(mi.enableWebServeJump=!!t.enableWebServeJump),t.webServeUrl!==void 0&&(mi.webServeUrl=String(t.webServeUrl)),t.normalizeHeadingSizes!==void 0&&(mi.normalizeHeadingSizes=!!t.normalizeHeadingSizes),{...mi}}function No(){return{...mi}}function ua(e,t,i){const n=(e||sn.webServeUrl).trim(),o=n.startsWith("http://")||n.startsWith("https://")?n:`http://${n}`,s=(i==null?void 0:i.r)||Math.random().toString(36).slice(2,9).padEnd(7,"0");try{const l=new URL(o);let r=l.pathname.replace(/\/+$/,"");return r.endsWith("/stage/build/desktop")||(r=r?`${r}/stage/build/desktop`:"/stage/build/desktop"),l.pathname=`${r}/`,l.searchParams.set("id",t),i!=null&&i.focus&&l.searchParams.set("focus","1"),l.searchParams.set("r",s),l.toString()}catch{const l=i!=null&&i.focus?"&focus=1":"";return`${o.replace(/\/+$/,"")}/stage/build/desktop/?id=${t}${l}&r=${s}`}}const Si={theme:"default",aspectRatio:"16/9",highlighter:"shiki",defaultTransition:"slide-left",colorSchema:"auto",spacing:"normal",normalizeHeadingSizes:!1};function pf(e){var i,n,o,s,l,r;const t=No();return e?{theme:((i=e[Cn])==null?void 0:i.trim())||Si.theme,aspectRatio:((n=e[$n])==null?void 0:n.trim())||Si.aspectRatio,highlighter:((o=e[Qr])==null?void 0:o.trim())||Si.highlighter,defaultTransition:((s=e[In])==null?void 0:s.trim())||Si.defaultTransition,colorSchema:((l=e[el])==null?void 0:l.trim())||Si.colorSchema,spacing:((r=e[ls])==null?void 0:r.trim())||Si.spacing,normalizeHeadingSizes:t.normalizeHeadingSizes}:{...Si,normalizeHeadingSizes:t.normalizeHeadingSizes}}function _o(e){var i,n,o,s,l;const t=(i=e.ial)==null?void 0:i[Ii];return!!(t&&(t==="true"||t==="page"||t==="cover"||t==="end")||e.type==="tb"||e.type==="thematic-break"||e.type==="NodeThematicBreak"||((n=e.markdown)==null?void 0:n.trim())==="---"||((o=e.markdown)==null?void 0:o.trim())==="***"||e.type==="b"&&(((s=e.markdown)==null?void 0:s.trim())==="---"||((l=e.content)==null?void 0:l.trim())==="---"))}function Nr(e){const t={};let i="";if(!e)return{frontmatter:t,notes:i};e[ue]&&(t.layout=e[ue].trim()),e[tt]&&(t.transition=e[tt].trim()),e[je]&&(t.background=e[je].trim()),e[Bt]&&(t.image=e[Bt].trim()),e[Ui]&&(t.class=e[Ui].trim()),e[gn]&&(t.spacing=e[gn].trim()),e[yt]&&(t.layoutRatio=e[yt].trim()),e[Vi]&&(t.mask=e[Vi].trim()),e[Ki]&&(t.maskRatio=e[Ki].trim()),e[qi]&&(t.maskStyle=e[qi].trim()),e[Gi]&&(t.maskInitial=e[Gi].trim()),e[Wi]&&(i=e[Wi].trim());for(const[n,o]of Object.entries(e))if(n.startsWith("custom-slidev-")&&![ue,yt,Vi,Ki,qi,Gi,tt,je,Bt,Ui,gn,Wi,Ii].includes(n)){const s=n.replace(/^custom-slidev-/,"");try{t[s]=JSON.parse(o)}catch{t[s]=o}}return{frontmatter:t,notes:i}}function hf(e){const t={};if(!e)return t;const i=e[nt]??e["slidev-note"];i!=null&&i!==""&&i!=="false"&&i!=="0"&&(t.isNote=!0);const n=e[qe]??e["slidev-role"],o=e[je]??e["slidev-background"];(n===tl||o==="true"||o==="1")&&(t.isBackground=!0);const s=e[ue]??e["slidev-layout"];s===po||s===ho?t.imageLayout=s:(n===po||n===ho)&&(t.imageLayout=n);const l=e[Ze]??e["custom-slidev-clicks"]??e["slidev-click"]??e["slidev-clicks"];if(l!=null&&(t.clicks=l.trim()),e[Kt])try{const r=JSON.parse(e[Kt]);typeof r=="object"&&r!==null?t.motion={preset:r.preset||r.type||"fade-in",...r}:t.motion={preset:String(r).trim()}}catch{t.motion={preset:e[Kt].trim()}}return e[Oi]&&(t.shikiLines=e[Oi].trim()),e[En]&&(t.maxHeight=e[En].trim()),e[Ce]&&(t.slot=e[Ce].trim()),e.style&&e.style.trim()&&(t.style=e.style.trim()),t}function bi(e,t){const i=(e||t||"").trim();if(!i)return null;const n=i.match(/!\[[\s\S]*?\]\(\s*([^\s)]+)(?:\s+(?:=["']?[^"'\s)]*["']?|["'][^"']*["']))*?\s*\)/);if(n)return n[1].trim();const o=i.match(/<img\b[^>]*?\bsrc=["']([^"']+)["']/i);if(o)return o[1].trim();const s=i.replace(/\{:[^}]*\}/g,"").trim();return/^(?:assets\/|https?:\/\/|\/|\.\.?\/)[^\s]+\.(?:png|jpe?g|gif|webp|svg|avif)(?:\?[^\s]*)?$/i.test(s)?s:null}function xn(e){if(!e)return"";const t=e.split(/\r?\n/);if(t.length===0)return"";const i=t[0],n=i.match(/^(\s*)(?:[-*+]|\d+\.)\s+(.*)$/);if(!n)return e;const o=n[1].length,s=n[2].trim(),l=i.length-n[2].length;if(t.length===1)return s;const r=[s];for(let a=1;a<t.length;a++){const c=t[a];if(!c.trim()){r.push("");continue}const d=c.match(/^(\s*)/),p=d?d[1].length:0;p>=l?r.push(c.slice(l)):p>o?r.push(c.slice(p)):r.push(c)}return r.join(`
`)}function Ri(e){if(!e)return!1;const t=(e.type||"").toLowerCase();if(t==="i"||t==="nodelistitem"||t==="l"||t==="nodelist")return!0;const i=(e.markdown||e.rawMarkdown||e.content||"").trim();return!!/^(?:[-*+]|\d+\.)\s+/.test(i)}function Xo(e,t=2){if(!e||typeof e!="string")return`repeat(${t}, 1fr)`;const i=e.trim();if(!i)return`repeat(${t}, 1fr)`;if(i.includes(":")){const o=i.split(":").map(s=>parseFloat(s.trim())).filter(s=>!isNaN(s)&&s>0);if(o.length>=2)return o.map(s=>`${s}fr`).join(" ")}const n=i.split(/\s+/).filter(Boolean);return n.length>=2?n.join(" "):`repeat(${t}, 1fr)`}function Sn(e){if(!e)return[];if(ot(e)&&Gt(e)&&!ci(e)){const n=an(e),o=[];for(const s of n)o.push(...Sn(s));return o}const t=(e.type||"").toLowerCase();if(t==="l"||t==="nodelist"||t==="list"){if(e.children&&e.children.length>0){const l=e.children.filter(Ri);if(l.length>0)return l}const o=(e.markdown||e.content||"").trim().split(/\r?\n/),s=[];for(let l=0;l<o.length;l++)/^(?:[-*+]|\d+\.)\s+/.test(o[l])&&s.push(l);if(s.length>=2){const l=[];for(let r=0;r<s.length;r++){const a=s[r],c=r+1<s.length?s[r+1]:o.length,d=o.slice(a,c).join(`
`);l.push({id:`${e.id}-item-${r+1}`,type:"i",markdown:d,content:d,ial:{...e.ial||{}}})}return l}}return Ri(e)?[e]:[]}function Vs(e){var o;if(!e||!ot(e)||!Gt(e)||ci(e))return null;const t=an(e);if(t.length===0)return null;if(t.length===1&&ot(t[0])&&Gt(t[0])){const s=Vs(t[0]);return s?{items:s.items,nestedSuperBlocks:[t[0],...s.nestedSuperBlocks]}:null}const i=[];for(const s of t)if(ot(s)){i.push(s);const l=((o=s.children)==null?void 0:o.filter(ot))||[];i.push(...l)}const n=t.map(Sn);if(n.length>=2&&n.every(s=>s.length>0)){const s=n.flat();if(s.length>=2&&s.length<=6)return{items:s,nestedSuperBlocks:i}}if(t.length===2){const s=Sn(t[0]),l=Sn(t[1]);if(s.length+l.length>=2&&s.length+l.length<=6&&(s.length>0||l.length>0))return{items:[...s,...l],nestedSuperBlocks:i}}return null}function mf(e){if(!e||!ot(e)||!Gt(e)||ci(e))return null;const t=Vs(e);if(!t)return null;const{items:i,nestedSuperBlocks:n}=t;if(i.length<2||i.length>6)return null;const o=Ks(e)||void 0,s=i.length;return{superBlockNode:e,nestedSuperBlocks:n,count:s,layout:"cols-header",items:i,slots:i.map((l,r)=>`col-${r+1}`),ratio:o}}function fa(e){if(!e||!ot(e)||!Gt(e)||ci(e))return null;const t=an(e);if(t.length===0)return null;const i=[];for(const n of t){const o=Sn(n);if(o.length===0)return null;i.push(...o)}return i}function gf(e){if(!e||!ot(e)||!Gt(e)||ci(e))return null;const t=fa(e);return!t||t.length===0||t.length>=2&&t.length<=6?null:{superBlockNode:e,items:t}}function vf(e){if(!e||!ot(e)||!Gt(e)||ci(e))return null;const t=Vs(e);if(t&&t.items.length===4)return t.items;const i=fa(e);if(i&&i.length===4)return i;const n=an(e);return n.length===4?n:null}function bf(e,t){if(!e||e.length===0)return null;const i=[];function n(r,a){if(ot(r)){const c=vf(r);c&&c.length===4&&i.push({sbNode:r,items:c,topLevelIndex:a})}if(r.children&&r.children.length>0)for(const c of r.children)n(c,a)}for(let r=0;r<e.length;r++)n(e[r],r);if(i.length===0)return null;let o=null;t&&(o=i.find(r=>{if(r.sbNode.id===t||r.items.some(c=>c.id===t))return!0;const a=c=>c.id===t?!0:c.children?c.children.some(a):!1;return a(r.sbNode)})||null),o||(o=i[0]);const l=e.slice(0,o.topLevelIndex).slice().reverse().find(r=>pa(r));return{superBlockNode:o.sbNode,items:o.items,headerNode:l}}function yf(e,t,i){var d,p,b,u,h;const n=[],o=[],s=(i==null?void 0:i.tracked)||[],l=[];let r={pageTargetId:e,blocks:[]};l.push(r);for(let f=0;f<t.length;f++){const g=t[f];if(_o(g)){if(l.length===1&&r.blocks.length===0){r.pageTargetId=g.id,r.blocks.push(g);continue}r={pageTargetId:g.id,blocks:[g]},l.push(r)}else r.blocks.push(g)}function a(f){const g=[];for(const k of f)ot(k)&&g.push(k),k.children&&k.children.length>0&&g.push(...a(k.children));return g}function c(f,g,k){const S={blockId:f,attrs:g,previousAttrs:k};n.push(S),i!=null&&i.onTagChange&&i.onTagChange(S)}for(const f of l){const g=f.pageTargetId,k=t.find(I=>I.id===g),S=s.find(I=>I.pageTargetId===g);if(f.blocks.some(I=>{var w,P;return!!(ci(I)||ks(I)&&(((w=I.ial)==null?void 0:w[ue])==="image-left"||((P=I.ial)==null?void 0:P[ue])==="image-right"))})){if(S){const I=S.headerId;if(I){c(I,{[Ce]:""});const w=t.find(P=>P.id===I);w!=null&&w.ial&&(w.ial[Ce]="")}for(const w of S.itemIds){c(w,{[Ce]:""});const P=t.find(R=>R.id===w);P!=null&&P.ial&&(P.ial[Ce]="")}}continue}let T=null,B=-1;for(let I=0;I<f.blocks.length;I++){const w=f.blocks[I],P=ot(w)?[w,...a(w.children||[])]:w.children?a(w.children):[];for(const R of P){const z=mf(R);if(z){T=z,B=I;break}}if(T)break}if(T){const{superBlockNode:I,layout:w,items:P,slots:R}=T,V=f.blocks.slice(0,B).find(E=>pa(E)),_=V==null?void 0:V.id,L=((d=k==null?void 0:k.ial)==null?void 0:d[ue])||"",y=L==="clover",A=y?"clover":w;if(L!==A&&(c(g,{[ue]:A},{[ue]:L}),k&&(k.ial||(k.ial={}),k.ial[ue]=A)),V){const E=((p=V.ial)==null?void 0:p[Ce])||"";E!=="header"&&(c(V.id,{[Ce]:"header"},{[Ce]:E}),V.ial||(V.ial={}),V.ial[Ce]="header")}if(S!=null&&S.headerId&&S.headerId!==_){c(S.headerId,{[Ce]:""});const E=t.find(D=>D.id===S.headerId);E&&(E.ial||(E.ial={}),E.ial[Ce]="")}const F=[];for(let E=0;E<P.length;E++){const D=P[E],N=R[E];F.push(D.id);const X=((b=D.ial)==null?void 0:b[Ce])||"";if(X!==N&&(c(D.id,{[Ce]:N},{[Ce]:X}),D.ial||(D.ial={}),D.ial[Ce]=N),D.children&&D.children.length>0)for(const j of D.children)j.ial||(j.ial={}),j.ial[Ce]!==N&&(j.ial[Ce]=N)}if(S!=null&&S.itemIds){for(const E of S.itemIds)if(!F.includes(E)){c(E,{[Ce]:""});const D=t.find(N=>N.id===E);D&&(D.ial||(D.ial={}),D.ial[Ce]="")}}o.push({superBlockId:I.id,nestedSuperBlockIds:(u=T.nestedSuperBlocks)==null?void 0:u.map(E=>E.id),pageTargetId:g,headerId:_,itemIds:F,layout:y?"clover":w})}else{let I=!1;const w=[];for(const z of f.blocks){const V=ot(z)?[z,...a(z.children||[])]:z.children?a(z.children):[];for(const _ of V){const L=gf(_);if(L){I=!0;for(const y of L.items)w.push(y.id)}}}const P=((h=k==null?void 0:k.ial)==null?void 0:h[ue])||"",R=Tn(P);if(S||I&&R){c(g,{[ue]:""},{[ue]:P}),k&&(k.ial||(k.ial={}),k.ial[ue]="");const z=S==null?void 0:S.headerId;if(z){c(z,{[Ce]:""});const _=t.find(L=>L.id===z);_&&(_.ial||(_.ial={}),_.ial[Ce]="")}const V=new Set([...(S==null?void 0:S.itemIds)||[],...w]);for(const _ of V){c(_,{[Ce]:""});const L=t.find(y=>y.id===_);L&&(L.ial||(L.ial={}),L.ial[Ce]="")}}}}return{changes:n,newTracked:o}}function ot(e){if(!e)return!1;const t=(e.type||"").toLowerCase();return t==="s"||t==="sb"||t==="nodesuperblock"}function Gt(e){if(!ot(e))return!1;const t=(e.subType||"").toLowerCase();if(t==="col"||t==="h"||t==="horizontal")return!0;if(t==="row"||t==="v"||t==="vertical")return!1;if(e.ial){const n=(e.ial["data-sb-layout"]||e.ial.layout||"").toLowerCase();if(n==="col"||n==="h")return!0;if(n==="row"||n==="v")return!1}if(e.children&&e.children.length>0){for(const n of e.children)if(n.type==="NodeSuperBlockLayoutMarker"||n.type==="layout-marker"){const o=(n.content||n.markdown||"").trim().toLowerCase();if(o==="col"||o==="h")return!0;if(o==="row"||o==="v")return!1}}const i=(e.markdown||e.content||"").trim();return/^\{\{\{col\b/i.test(i)?!0:!/^\{\{\{row\b/i.test(i)}function ks(e){return!e||Ri(e)||ot(e)||!bi(e.markdown,e.content)?!1:(e.markdown||e.content||"").replace(/!\[.*?\]\([^)]+\)/g,"").replace(/<img\b[^>]*>/gi,"").replace(/\{:[^}]*\}/g,"").trim().length<=25}function Ks(e){var b;if(!e||!ot(e)||!Gt(e))return null;const t=an(e);if(!t||t.length<2)return null;const i=[];let n=!1;for(const u of t){const h=(((b=u.ial)==null?void 0:b.style)||u.style||"").trim();let f=null;if(h){const g=h.match(/calc\(\s*([\d.]+)%/i);if(g)f=parseFloat(g[1]);else{const k=h.match(/(?:^|;|\s)width:\s*([\d.]+)%/i);k&&(f=parseFloat(k[1]))}}f!==null&&!isNaN(f)&&f>0?(i.push(f),n=!0):i.push(null)}if(!n)return null;const o=t.length,s=i.reduce((u,h)=>u+(h||0),0),l=i.filter(u=>u===null).length,r=Math.max(0,100-s),a=l>0?r/l:100/o,c=i.map(u=>u!==null?u:a),d=c.reduce((u,h)=>u+h,0);if(d<=0)return null;const p=c.map(u=>u/d*100);if(p.length===2){const[u]=p;if(u>=48&&u<=52)return"1:1";if(u>=31&&u<=35)return"1:2";if(u>=65&&u<=69)return"2:1";if(u>=28&&u<=32)return"3:7";if(u>=68&&u<=72)return"7:3";if(u>=38&&u<=42)return"4:6";if(u>=58&&u<=62)return"6:4";if(u>=23&&u<=27)return"1:3";if(u>=73&&u<=77)return"3:1";const h=Math.round(u),f=100-h;return`${h}:${f}`}if(p.length===3){const[u,h,f]=p;if(u>=31&&u<=35&&h>=31&&h<=35&&f>=31&&f<=35)return"1:1:1";if(u>=23&&u<=27&&h>=48&&h<=52&&f>=23&&f<=27)return"1:2:1";if(u>=48&&u<=52&&h>=23&&h<=27&&f>=23&&f<=27)return"2:1:1";if(u>=23&&u<=27&&h>=23&&h<=27&&f>=48&&f<=52)return"1:1:2";if(u>=18&&u<=22&&h>=58&&h<=62&&f>=18&&f<=22)return"1:3:1";const g=Math.round(u),k=Math.round(h),S=100-g-k;return`${g}:${k}:${S}`}return p.map(u=>Math.round(u)).join(":")}function ci(e){if(!e||!ot(e)||!Gt(e))return null;const t=(e.children||[]).filter(s=>{const l=s.type||"";if(l==="NodeSuperBlockOpenMarker"||l==="NodeSuperBlockLayoutMarker"||l==="NodeSuperBlockCloseMarker"||l==="open-marker"||l==="layout-marker"||l==="close-marker")return!1;const r=(s.markdown||s.content||"").trim();return!(/^\{\{\{(?:col|row)?\s*$/i.test(r)||r==="}}}")});if(t.length<2)return null;const i=ks(t[0]),n=ks(t[t.length-1]),o=Ks(e)||void 0;if(i&&!n){const s=bi(t[0].markdown,t[0].content);if(s)return{imageNode:t[0],imageUrl:s,layout:po,contentNodes:t.slice(1),ratio:o}}if(!i&&n){const s=bi(t[t.length-1].markdown,t[t.length-1].content);if(s)return{imageNode:t[t.length-1],imageUrl:s,layout:ho,contentNodes:t.slice(0,t.length-1),ratio:o}}return null}function kf(e,t){const i=[];function n(o){for(const s of o){const l=ci(s);if(l){const{imageNode:r,layout:a,ratio:c}=l;r.ial||(r.ial={});const d=r.ial[ue];if(d!==a){const b={blockId:r.id,layout:a,previousLayout:d,ratio:c};r.ial[ue]=a,i.push(b),t&&t(b)}}s.children&&s.children.length>0&&n(s.children)}}return n(e),i}function an(e){return(e.children||[]).filter(t=>{const i=t.type||"";if(i==="NodeSuperBlockOpenMarker"||i==="NodeSuperBlockLayoutMarker"||i==="NodeSuperBlockCloseMarker"||i==="open-marker"||i==="layout-marker"||i==="close-marker")return!1;const n=(t.markdown||t.content||"").trim();return!(/^\{\{\{(?:col|row)?\s*$/i.test(n)||n==="}}}")})}function pa(e){if(!e)return!1;const t=(e.type||"").toLowerCase();if(t==="h"||t==="nodeheading"||/^h[1-6]$/i.test(e.subType||""))return!0;const i=(e.markdown||e.content||"").trim();return!!/^#{1,6}\s+/.test(i)}function _i(e,t,i){let n="",o=0;const s=/<div\b([^>]*)>/gi;for(;o<e.length;){s.lastIndex=o;let l,r=!1,a=-1,c=0;for(;(l=s.exec(e))!==null;){const k=l[1].match(/\bclass=["']([^"']*)["']/i);if(k){const S=k[1];if(typeof t=="string"?S.split(/\s+/).includes(t):t.test(S)){r=!0,a=l.index,c=l[0].length;break}}}if(!r){n+=e.slice(o);break}n+=e.slice(o,a);const d=a+c;let p=1,b=-1,u=-1;const h=/<\/?div\b[^>]*>/gi;h.lastIndex=d;let f;for(;(f=h.exec(e))!==null;)if(f[0].startsWith("</")){if(p--,p===0){b=f.index,u=f.index+f[0].length;break}}else p++;if(b!==-1&&u!==-1){const g=e.slice(d,b);n+=i(g),o=u}else n+=e.slice(a,d),o=d}return n}function wf(e){const t=[];let i="",n=0;const o=/<div\b([^>]*)>/gi;for(;n<e.length;){o.lastIndex=n;let s,l=!1,r=-1,a=0;for(;(s=o.exec(e))!==null;){const f=s[1];if(/(?:\s@[a-zA-Z0-9_-]+=\s*["']|\s:[a-zA-Z0-9_-]+=\s*["']|\sv-[a-zA-Z0-9_.-]+|\shover:[a-zA-Z0-9_.-]+=\s*["']|\sgrid=["']~|\bclass=["'][^"']*\b(?:abs-br|slidev-icon-btn|grid\s+|grid$|grid-cols-|relative\b)\b[^"']*["']|\bstyle=["'][^"']*\bgrid-[^"']*["'])/i.test(f)){l=!0,r=s.index,a=s[0].length;break}}if(!l){i+=e.slice(n);break}i+=e.slice(n,r);const c=r+a;let d=1,p=-1,b=-1;const u=/<\/?div\b[^>]*>/gi;u.lastIndex=c;let h;for(;(h=u.exec(e))!==null;)if(h[0].startsWith("</")){if(d--,d===0){p=h.index,b=h.index+h[0].length;break}}else d++;if(p!==-1&&b!==-1){const f=e.slice(r,b),g=`__VUE_DIV_TOKEN_${t.length}__`;t.push(f),i+=g,n=b}else i+=e.slice(r,c),n=c}return{text:i,tokens:t}}function xf(e){const t=[];let i=e.replace(/(?:^[ \t]*(`{3,}|~{3,})[^\n\r]*\r?\n[\s\S]*?\r?\n[ \t]*\1(?=[ \t]*(?:\r?\n|$)))/gm,r=>{const a=`__CODE_TOKEN_${t.length}__`;return t.push(r),a});i=i.replace(/(`+)(?:[^\n\r`]|(?!\1)`)+?\1/g,r=>{const a=`__CODE_TOKEN_${t.length}__`;return t.push(r),a});const n=[];i=i.replace(/<script\b[^>]*>[\s\S]*?<\/script>/gi,r=>{const a=`__SCRIPT_TOKEN_${n.length}__`;return n.push(r),a});const{text:o,tokens:s}=wf(i);i=o;const l=[];i=i.replace(/<(?:[A-Z][a-zA-Z0-9_-]*|[a-z0-9_-]+:[a-z0-9_-]+|v-[a-z0-9_-]+|arrow\b|div\s+h-\d+)\b[^>]*\/>/gi,r=>{const a=`__VUE_COMP_TOKEN_${l.length}__`;return l.push(r),a}),i=i.replace(/<(v-[a-z0-9_-]+|button)\b([^>]*)>([\s\S]*?)<\/\1>/gi,r=>{const a=`__VUE_COMP_TOKEN_${l.length}__`;return l.push(r),a}),i=i.replace(/<img\b[^>]*?\bv-[a-z0-9_.-]+[^>]*\/?>/gi,r=>{const a=`__VUE_COMP_TOKEN_${l.length}__`;return l.push(r),a}),i=i.replace(/<(p|span)\b([^>]*?\bv-[a-z0-9_.-]+[^>]*)>([\s\S]*?)<\/\1>/gi,r=>{const a=`__VUE_COMP_TOKEN_${l.length}__`;return l.push(r),a}),i=i.replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi,""),i=i.replace(/<div class="terminal-bar">[\s\S]*?<\/div>/gi,""),i=i.replace(/<div class="cursor-line">[\s\S]*?<\/div>/gi,""),i=i.replace(/<span class="cursor">[\s\S]*?<\/span>/gi,""),i=i.replace(/<div class="stamp">\s*([\s\S]*?)\s*<\/div>/gi,`

*[$1]*

`),i=i.replace(/<div class="arrow">\s*([→\->]+)\s*<\/div>/gi,`

$1

`),i=i.replace(/<i>\s*[→\->]+\s*<\/i>/gi,""),i=i.replace(/<div class="prompt">\s*([\s\S]*?)\s*<\/div>/gi,(r,a)=>`
\`\`\`bash
${a.trim()}
\`\`\`
`),i=i.replace(/<p>\s*<i>\$<\/i>\s*([\s\S]*?)<\/p>/gi,(r,a)=>`
\`\`\`bash
$ ${a.trim()}
\`\`\`
`),i=i.replace(/<div class="statusline">\s*([\s\S]*?)\s*<\/div>/gi,(r,a)=>`
> ${Array.from(a.matchAll(/<span>([\s\S]*?)<\/span>/gi)).map(d=>`\`${d[1].trim()}\``).join(" | ")}
`),i=i.replace(/<div class="log-panel">\s*<pre>([\s\S]*?)<\/pre>\s*<\/div>/gi,(r,a)=>`
\`\`\`log
${a.replace(/<span[^>]*>([\s\S]*?)<\/span>/gi,"$1").trim()}
\`\`\`
`),i=_i(i,"diff-grid",r=>{const a=Array.from(r.matchAll(/<div class="diff\s+([^"]*)">\s*<span>(.*?)<\/span>\s*<pre>([\s\S]*?)<\/pre>\s*<\/div>/gi));return a.length>0?`
`+a.map(c=>{const d=c[2].trim().toUpperCase(),p=c[3].trim();return`**${d}:**
\`\`\`yaml
${p}
\`\`\``}).join(`

`)+`
`:r}),i=_i(i,"before-after",r=>{const a=r.match(/<div class="before">[\s\S]*?<small>(.*?)<\/small>[\s\S]*?<h2>(.*?)<\/h2>[\s\S]*?<p>(.*?)<\/p>\s*<\/div>/i),c=r.match(/<div class="after">[\s\S]*?<small>(.*?)<\/small>[\s\S]*?<h2>(.*?)<\/h2>[\s\S]*?<p>(.*?)<\/p>\s*<\/div>/i);let d=`
`;return a&&(d+=`### ${a[1]}
## ${a[2]}
${a[3]}

`),c&&(d+=`### ${c[1]}
## ${c[2]}
${c[3]}
`),d.trim()?d:r}),i=i.replace(/<ul\b[^>]*>([\s\S]*?)<\/ul>/gi,(r,a)=>{const c=Array.from(a.matchAll(/<li>\s*(?:<em>)?(\[[x ]\])(?:<\/em>)?\s*([\s\S]*?)<\/li>/gi));return c.length>0?`
`+c.map(d=>`- ${d[1]} ${d[2].trim()}`).join(`
`)+`
`:a}),i=_i(i,"timeline",r=>{const a=Array.from(r.matchAll(/<div(?:\s+class="([^"]*)")?>\s*<time>([\s\S]*?)<\/time>\s*<b>([\s\S]*?)<\/b>\s*<span>([\s\S]*?)<\/span>\s*<\/div>/gi));return a.length>0?`

`+a.map(c=>{const d=c[1]||"";let p="-";return d.includes("warn")?p="- ⚠️":d.includes("bad")?p="- ❌":d.includes("ok")&&(p="- ✅"),`${p} **${c[2].trim()}** **${c[3].trim()}** — ${c[4].trim()}`}).join(`
`)+`

`:r}),i=_i(i,"pipeline",r=>{const a=Array.from(r.matchAll(/<div(?:\s+class="([^"]*)")?>\s*<small>([\s\S]*?)<\/small>\s*<b>([\s\S]*?)<\/b>\s*<span>([\s\S]*?)<\/span>\s*<\/div>/gi));return a.length>0?`

`+a.map((c,d)=>{const b=(c[1]||"").includes("hot")?"⚠️ ":"";return`${d+1}. ${b}**${c[3].trim()}** (*${c[4].trim()}*)`}).join(`
`)+`

`:r}),i=_i(i,"check-grid",r=>{const a=Array.from(r.matchAll(/<div>\s*<span class="([^"]*)"><\/span>\s*<b>([\s\S]*?)<\/b>\s*<p>([\s\S]*?)<\/p>\s*<\/div>/gi));return a.length>0?`

`+a.map(c=>`- ${(c[1]||"").includes("warn")?"⚠️":"✅"} **${c[2].trim()}**: ${c[3].trim()}`).join(`
`)+`

`:r}),i=_i(i,"manifesto",r=>{const a=Array.from(r.matchAll(/<div>\s*<span>([\s\S]*?)<\/span>\s*<h2>([\s\S]*?)<\/h2>\s*<p>([\s\S]*?)<\/p>\s*<\/div>/gi));return a.length>0?`

`+a.map(c=>`## ${c[1].trim()} ${c[2].trim()}

${c[3].trim()}`).join(`

`)+`

`:r}),i=_i(i,"split-note",r=>{const a=Array.from(r.matchAll(/<div>\s*<b>([\s\S]*?)<\/b>\s*<p>([\s\S]*?)<\/p>\s*<\/div>/gi));return a.length>0?`

`+a.map(c=>`> **${c[1].trim()}**: ${c[2].trim()}`).join(`
>
`)+`

`:r}),i=i.replace(/<div class="mechanism">\s*<b>([\s\S]*?)<\/b>\s*<p>([\s\S]*?)<\/p>\s*<\/div>/gi,(r,a,c)=>`

> **${a.trim()}**: ${c.trim()}

`),i=i.replace(/<pre>([\s\S]*?)<\/pre>/gi,(r,a)=>`
\`\`\`text
${a.replace(/<span[^>]*>([\s\S]*?)<\/span>/gi,"$1").trim()}
\`\`\`
`),i=i.replace(/<div class="page-head">\s*<span>([\s\S]*?)<\/span>\s*<b>([\s\S]*?)<\/b>\s*<\/div>/gi,`
### $1 ($2)
`),i=i.replace(/<h1\b[^>]*>([\s\S]*?)<\/h1>/gi,`
# $1
`),i=i.replace(/<h2\b[^>]*>([\s\S]*?)<\/h2>/gi,`
## $1
`),i=i.replace(/<h3\b[^>]*>([\s\S]*?)<\/h3>/gi,`
### $1
`),i=i.replace(/<h4\b[^>]*>([\s\S]*?)<\/h4>/gi,`
#### $1
`),i=i.replace(/<p\s+class="ok">\s*●\s*([\s\S]*?)<\/p>/gi,`
✅ **$1**
`),i=i.replace(/<p\s+class="caption">\s*([\s\S]*?)<\/p>/gi,`
> *$1*
`),i=i.replace(/<p\s+class="lead">\s*([\s\S]*?)<\/p>/gi,`
*$1*
`),i=i.replace(/<p\b([^>]*)>([\s\S]*?)<\/p>/gi,(r,a,c)=>/@|v-|:|class=/i.test(a)?r:`
${c.trim()}

`),i=i.replace(/<br\s*\/?>/gi,`
`),i=i.replace(/<hr\s*\/?>/gi,`
---
`),i=i.replace(/<b\b[^>]*>([\s\S]*?)<\/b>/gi,"**$1**"),i=i.replace(/<strong\b[^>]*>([\s\S]*?)<\/strong>/gi,"**$1**"),i=i.replace(/<i\b[^>]*>([\s\S]*?)<\/i>/gi,"*$1*"),i=i.replace(/<code\b[^>]*>([\s\S]*?)<\/code>/gi,(r,a)=>{if(a.startsWith("`")&&a.endsWith("`"))return a;if(a.includes("`")){const c=(a.match(/`+/g)||[]).reduce((p,b)=>Math.max(p,b.length),0),d="`".repeat(c+1);return`${d} ${a} ${d}`}return`\`${a}\``}),i=i.replace(/<small\b[^>]*>([\s\S]*?)<\/small>/gi,"*$1*"),i=i.replace(/\*{4}/g,"** **"),i=i.replace(/<li\b[^>]*>([\s\S]*?)<\/li>/gi,`- $1
`),i=i.replace(/<ul\b[^>]*>([\s\S]*?)<\/ul>/gi,`
$1
`),i=i.replace(/<ol\b[^>]*>([\s\S]*?)<\/ol>/gi,`
$1
`),i=i.replace(/<a\b([^>]*)href=["'](.*?)["']([^>]*)>([\s\S]*?)<\/a>/gi,(r,a,c,d,p)=>{const b=p.trim();return b.includes("<")||b.includes(`
`)?r:`[${b}](${c})`}),i=i.replace(/<blockquote\b[^>]*>([\s\S]*?)<\/blockquote>/gi,(r,a)=>`
`+a.trim().split(`
`).map(c=>`> ${c.trim()}`).join(`
`)+`
`),i=i.replace(/<span\b[^>]*data-type=["']block-ref["'][^>]*data-id=["']([0-9a-zA-Z-]+)["'][^>]*>([\s\S]*?)<\/span>/gi,(r,a,c)=>{const d=c.replace(/<[^>]+>/g,"").trim();return d?`((${a} '${d}'))`:`((${a}))`}),i=i.replace(/<span\b[^>]*data-type=["']a["'][^>]*data-href=["']([^"']+)["'][^>]*>([\s\S]*?)<\/span>/gi,(r,a,c)=>`[${c.replace(/<[^>]+>/g,"").trim()}](${a})`),i=i.replace(/<\/(?:div|section|header|footer|main|article|nav|aside)\b[^>]*>/gi,`
`),i=i.replace(/<(?:div|section|header|footer|main|article|nav|aside)\b[^>]*>/gi,""),i=i.replace(/<\/?span\b[^>]*>/gi,"");for(let r=0;r<l.length;r++)i=i.replace(`__VUE_COMP_TOKEN_${r}__`,l[r]);for(let r=0;r<s.length;r++)i=i.replace(`__VUE_DIV_TOKEN_${r}__`,s[r]);for(let r=0;r<n.length;r++)i=i.replace(`__SCRIPT_TOKEN_${r}__`,n[r]);for(let r=0;r<t.length;r++)i=i.replace(`__CODE_TOKEN_${r}__`,t[r]);return i=i.replace(/\n{3,}/g,`

`).trim(),i}function ha(e){if(!e||typeof e!="string")return"";const t=[];let i=e.replace(/`([^`]+)`/g,n=>(t.push(n),`%%INLINE_CODE_${t.length-1}%%`));return i=i.replace(/(<\/[a-zA-Z0-9_-]+>)\s*\{:[^}]*\}/g,"$1"),i=i.replace(/(\[[^\]]+\]\([^)]+\))\s*\{:\s*style=["']([^"']*)["'][^}]*\}/g,'<span style="$2">$1</span>'),i=i.replace(/(\*\*[^*]+\*\*)\s*\{:\s*style=["']([^"']*)["'][^}]*\}/g,'<span style="$2">$1</span>'),i=i.replace(/(\*[^*]+\*)\s*\{:\s*style=["']([^"']*)["'][^}]*\}/g,'<span style="$2">$1</span>'),i=i.replace(/(~~[^~]+~~)\s*\{:\s*style=["']([^"']*)["'][^}]*\}/g,'<span style="$2">$1</span>'),i=i.replace(/([\p{L}\p{N}_\-]+)\s*\{:\s*style=["']([^"']*)["'][^}]*\}/gu,'<span style="$2">$1</span>'),i=i.replace(/\{:[^}]*\}/g,""),i=i.replace(/%%INLINE_CODE_(\d+)%%/g,(n,o)=>t[parseInt(o,10)]||""),i}function Sf(e){const t=Object.entries(e).filter(([n,o])=>o!=null&&o!=="");return t.length===0?"":`---
${t.map(([n,o])=>typeof o=="string"?o.includes(":")||o.includes(`
`)||o.includes("#")?`${n}: "${o.replace(/"/g,'\\"')}"`:`${n}: ${o}`:`${n}: ${JSON.stringify(o)}`).join(`
`)}
---`}function _f(e,t){if(!t||!e.startsWith("```"))return e;const i=e.indexOf(`
`);if(i===-1)return e;const n=e.slice(0,i).trim(),o=e.slice(i);return n.includes("{")?e:`${n} {${t}}${o}`}function ma(e,t){if(t==null)return e;const i=t.trim();return i===""||i==="+1"?`<v-click>

${e}

</v-click>`:i==="hide"?`<v-click hide>

${e}

</v-click>`:`<v-click at="${i}">

${e}

</v-click>`}function Cf(e){if(!e||!e.preset)return null;const t=e.preset.toLowerCase().trim();if(!t||t==="none")return null;let i={opacity:0},n={opacity:1};switch(t){case"slide-up":i={y:40,opacity:0},n={y:0,opacity:1};break;case"slide-down":i={y:-40,opacity:0},n={y:0,opacity:1};break;case"slide-left":i={x:40,opacity:0},n={x:0,opacity:1};break;case"slide-right":i={x:-40,opacity:0},n={x:0,opacity:1};break;case"zoom-in":case"pop":i={scale:.8,opacity:0},n={scale:1,opacity:1};break;case"bounce":i={y:40,opacity:0},n={y:0,opacity:1,transition:{type:"spring",damping:10,stiffness:100}};break;case"fade-in":default:i={opacity:0},n={opacity:1};break}e.initial&&typeof e.initial=="object"&&(i={...i,...e.initial}),e.enter&&typeof e.enter=="object"&&(n={...n,...e.enter});const o={...n.transition||{}};return typeof e.duration=="number"&&e.duration>0&&(o.duration=e.duration),typeof e.delay=="number"&&e.delay>0&&(o.delay=e.delay),Object.keys(o).length>0&&(n.transition=o),{initial:i,enter:n}}function Jn(e,t,i,n){const o=t!=null&&t.trim()!=="",s=Cf(i),l=n==null?void 0:n.trim(),r=l!==void 0&&l!=="",a=r?` style="${l.replace(/"/g,"&quot;")}" class="slide-styled-block"`:"";if(!o&&!s)return r?`<div${a}>

${e}

</div>`:e;if(o&&!s){if(r){const h=t.trim();let f="v-click";return h==="hide"?f="v-click.hide":h!==""&&h!=="+1"&&(f=`v-click="${h}"`),`<div ${f}${a}>

${e}

</div>`}return ma(e,t)}const c=JSON.stringify(s.initial).replace(/"/g,"'"),d=JSON.stringify(s.enter).replace(/"/g,"'"),p=`v-motion :initial="${c}" :enter="${d}"`;if(!o)return`<div ${p}${a}>

${e}

</div>`;const b=t.trim();let u="v-click";return b==="hide"?u="v-click.hide":b!==""&&b!=="+1"&&(u=`v-click="${b}"`),`<div ${u} ${p}${a}>

${e}

</div>`}function ga(e){if(!e)return"";let t=e.trim();t=t.replace(/\{:[^}]*\}/g,"").trim(),t=t.replace(/^:::\s*[a-zA-Z0-9_-]*\s*\r?\n?/g,""),t=t.replace(/\r?\n?:::\s*$/g,"");let o=t.split(/\r?\n/).map(s=>s.trim().replace(/^>\s*/,"")).join(`
`).trim();return o=o.replace(/^\[!(?:NOTE|TIP|IMPORTANT|WARNING|CAUTION|[A-Za-z_-]+)\][^\r\n]*(?:\r?\n)?/i,"").trim(),o=o.replace(/^(?:💡|✏️|❗|⚠️|🚨|\s*)*(?:\*\*|__)?(?:演讲备注|演讲者提词|讲稿备注|演讲提词|备注|Notes?)(?:\*\*|__)?[:：]?\s*(?:\r?\n)?/i,"").trim(),o=o.replace(/^[-*+]\s+/,""),o=o.replace(/^\d+\.\s+/,""),o.trim()}function $f(e){var n;if(e.subType&&/^h([1-6])$/i.test(e.subType))return parseInt(e.subType.slice(1),10);const i=(e.markdown||e.content||"").trim().match(/^(#{1,6})\s+/);return i?i[1].length:e.type==="h"?(n=e.ial)!=null&&n.subType&&/^h([1-6])$/i.test(e.ial.subType)?parseInt(e.ial.subType.slice(1),10):1:null}function va(e,t=2){const i=Math.max(2,t);if(!e||e.length===0)return Array.from({length:i},()=>[]);if(e.length===1&&e[0].children&&e[0].children.length>=2){const c=e[0].children,d=Array.from({length:i},()=>[]),p=Math.min(i,c.length),b=Math.floor(c.length/p),u=c.length%p;let h=0;for(let f=0;f<p;f++){const g=b+(f<u?1:0);d[f]=c.slice(h,h+g),h+=g}return d}const n=c=>{const d=(c.slot||"").trim();if(!d)return null;if(d==="left")return 1;if(d==="center")return 2;if(d==="right")return i===2?2:i;const p=d.match(/^col-(\d+)$/i);if(p){const b=parseInt(p[1],10);if(b>=1&&b<=i)return b}return null},o=e.map(n);if(o.some(c=>c!==null)){if(o.some(u=>u!==null&&u>=2)){const u=Array.from({length:i},()=>[]);let h=1;for(const f of e){const g=n(f);g!==null&&(h=g),u[h-1].push(f)}return u}const d=e.filter(u=>n(u)===1),p=e.filter(u=>n(u)===null),b=i-1;if(p.length>=b){const u=Math.floor(p.length/b),h=p.length%b,f=[d];let g=0;for(let k=0;k<b;k++){const S=u+(k<h?1:0);f.push(p.slice(g,g+S)),g+=S}return f}else if(p.length>0){const u=[d];for(let h=0;h<b;h++)u.push(h<p.length?[p[h]]:[]);return u}else return[d,...Array.from({length:b},()=>[])]}const l=c=>{if(c.type==="h"||c.subType&&/^h[1-6]$/i.test(c.subType))return!0;const d=(c.rawMarkdown||c.content||"").trim();return/^#{1,6}\s+/.test(d)},r=e.map((c,d)=>l(c)?d:-1).filter(c=>c!==-1);if(r.length>=i){const c=Array.from({length:i},()=>[]);for(let d=0;d<i;d++){const p=r[d],b=d+1<i?r[d+1]:e.length;c[d]=e.slice(p,b)}return c}if(e.length>=i){const c=Array.from({length:i},()=>[]);let d=0;for(let p=0;p<i;p++){const b=i-p,u=e.length-d,h=Math.ceil(u/b);c[p]=e.slice(d,d+h),d+=h}return c}if(e.length>1&&e.length<i){const c=Array.from({length:i},()=>[]);for(let d=0;d<e.length;d++)c[d]=[e[d]];return c}if(e.length===1){const c=e[0],d=(c.rawMarkdown||c.content||"").trim(),p=d.split(/\r?\n/),b=[];for(let f=0;f<p.length;f++)/^[ \t]*[-*+]\s+|^[ \t]*\d+\.\s+/.test(p[f])&&b.push(f);if(b.length>=i){const f=Array.from({length:i},()=>[]);let g=0;for(let k=0;k<i;k++){const S=i-k,C=b.length-g,T=Math.ceil(C/S),B=b[g],I=g+T<b.length?b[g+T]:p.length,w=p.slice(B,I).join(`
`);f[k]=[{...c,id:k===0?c.id:`${c.id}-col${k+1}`,rawMarkdown:w,content:w}],g+=T}return f}const u=d.match(/<li[\s\S]*?<\/li>/gi);if(u&&u.length>=i){const f=Array.from({length:i},()=>[]);let g=0;for(let k=0;k<i;k++){const S=i-k,C=u.length-g,T=Math.ceil(C/S),B=`<ul>
${u.slice(g,g+T).join(`
`)}
</ul>`;f[k]=[{...c,id:k===0?c.id:`${c.id}-col${k+1}`,rawMarkdown:B,content:B}],g+=T}return f}const h=d.split(/\r?\n\s*\r?\n/).filter(f=>f.trim()!=="");if(h.length>=i){const f=Array.from({length:i},()=>[]);let g=0;for(let k=0;k<i;k++){const S=i-k,C=h.length-g,T=Math.ceil(C/S),B=h.slice(g,g+T).join(`

`);f[k]=[{...c,id:k===0?c.id:`${c.id}-col${k+1}`,rawMarkdown:B,content:B}],g+=T}return f}}const a=Array.from({length:i},()=>[]);return a[0]=e,a}function zr(e,t,i,n){var d;const o=pf(t),s=[],l=Nr(t);let r={pageIndex:1,startBlockId:e,frontmatter:{layout:l.frontmatter.layout||"cover",...l.frontmatter},notes:"",noteBlocks:[],blocks:[],rawMarkdown:"",allBlockIds:[e]};r.frontmatter.background&&(r.frontmatter.background=Et(r.frontmatter.background,n)),r.frontmatter.image&&(r.frontmatter.image=Et(r.frontmatter.image,n)),s.push(r);let a=[];for(const p of i){if(_o(p)){a=[];const u=Nr(p.ial);if(s.length===1&&r.blocks.length===0){r.startBlockId=p.id,r.allBlockIds||(r.allBlockIds=[]),r.allBlockIds.includes(p.id)||r.allBlockIds.push(p.id),u.frontmatter.layout&&(r.frontmatter.layout=u.frontmatter.layout),Object.assign(r.frontmatter,u.frontmatter),!u.frontmatter.image&&l.frontmatter.image&&(r.frontmatter.image=l.frontmatter.image),!u.frontmatter.background&&l.frontmatter.background&&(r.frontmatter.background=l.frontmatter.background),r.frontmatter.background&&(r.frontmatter.background=Et(r.frontmatter.background,n)),r.frontmatter.image&&(r.frontmatter.image=Et(r.frontmatter.image,n));continue}r={pageIndex:s.length+1,startBlockId:p.id,frontmatter:{layout:u.frontmatter.layout||"default",...u.frontmatter},notes:"",noteBlocks:[],blocks:[],rawMarkdown:"",allBlockIds:[p.id]},r.frontmatter.background&&(r.frontmatter.background=Et(r.frontmatter.background,n)),r.frontmatter.image&&(r.frontmatter.image=Et(r.frontmatter.image,n)),s.push(r);continue}const b=(u,h)=>{var F,E,D,N;if(r.allBlockIds||(r.allBlockIds=[]),u.id&&!r.allBlockIds.includes(u.id)&&r.allBlockIds.push(u.id),u.children&&u.children.length>0){const X=j=>{for(const G of j)G.id&&!r.allBlockIds.includes(G.id)&&r.allBlockIds.push(G.id),G.children&&G.children.length>0&&X(G.children)};X(u.children)}let f=Rc(u),g=u.ial?{...u.ial}:{};const k=f.match(/\{:\s*([^}]+)\s*\}\s*$/);k&&(g={...Pc(k[0]),...g},f=f.slice(0,k.index).trim()),u.type!=="c"&&!f.startsWith("```")&&(f=ha(f));let S=f.trim();if(/^\{\{\{(?:row|col)?\s*$/i.test(S)||S==="}}}")return;/^\{\{\{(?:row|col)?\s*\r?\n/i.test(S)&&/\r?\n\}\}\}$/.test(S)&&(f=S.replace(/^\{\{\{(?:row|col)?\s*\r?\n/i,"").replace(/\r?\n\}\}\}$/,"").trim(),S=f.trim());const C=hf(g);if(f=Nc(f,n),f=Oc(f,n==null?void 0:n.refContentMap),u.children&&u.children.length>0){const X=["custom-slidev-autoplay","custom-slidev-loop","custom-slidev-muted","custom-slidev-controls"],j=G=>{for(const ne of G){if(ne.ial)for(const[se,le]of Object.entries(ne.ial))X.includes(se)&&!g[se]&&(g[se]=le);ne.children&&ne.children.length>0&&j(ne.children)}};j(u.children)}const T=u.type==="video"||u.type==="NodeVideo"||/<video\b/i.test(f);if(T){const X=g["custom-slidev-autoplay"]==="true",j=g["custom-slidev-loop"]==="true",G=g["custom-slidev-muted"]==="true"||X,ne=g["custom-slidev-controls"]==="false";f=f.replace(/<video\b([^>]*)>/gi,(se,le)=>{let pe=le;return ne?pe=pe.replace(/\bcontrols(?:="[^"]*")?/gi,"").trim():/controls/i.test(pe)||(pe+=" controls"),X&&!/autoplay/i.test(pe)?pe+=" autoplay playsinline":!X&&g["custom-slidev-autoplay"]==="false"&&(pe=pe.replace(/\bautoplay\b/gi,"").replace(/\bplaysinline\b/gi,"").trim()),j&&!/loop/i.test(pe)?pe+=" loop":!j&&g["custom-slidev-loop"]==="false"&&(pe=pe.replace(/\bloop\b/gi,"").trim()),G&&!/muted/i.test(pe)?pe+=" muted":!G&&g["custom-slidev-muted"]==="false"&&(pe=pe.replace(/\bmuted\b/gi,"").trim()),`<video ${pe.trim()}>`})}if(C.isBackground){const X=bi(f,u.content);if(X){r.frontmatter.background=Et(X,n);return}}const B=ci(u);if(B){r.frontmatter.layout=B.layout,r.frontmatter.image=Et(B.imageUrl,n),!r.frontmatter.layoutRatio&&B.ratio&&(r.frontmatter.layoutRatio=B.ratio);for(const X of B.contentNodes)b(X);return}if(C.imageLayout==="image-left"||C.imageLayout==="image-right"){const X=bi(f,u.content);if(X){r.frontmatter.layout=C.imageLayout,r.frontmatter.image=Et(X,n),!r.frontmatter.layoutRatio&&((F=u.ial)!=null&&F[yt])&&(r.frontmatter.layoutRatio=u.ial[yt]);return}}if(ot(u)&&u.children&&u.children.length>0){for(const X of u.children)b(X);return}const I=!!(C.slot||h!=null&&h.defaultSlot||r.frontmatter.layout==="clover"||Tn(r.frontmatter.layout)||r.frontmatter.layout==="two-cols");if((u.type==="l"||u.type==="NodeList"||u.type==="list")&&u.children&&u.children.length>0&&(u.children.some(X=>{var j,G;return((j=X.ial)==null?void 0:j[Ce])||((G=X.ial)==null?void 0:G[Ze])})||C.slot||C.clicks||I)){for(const X of u.children)C.slot&&(!X.ial||!X.ial[Ce])&&(X.ial||(X.ial={}),X.ial[Ce]=C.slot),b(X,{...h,parentClicks:C.clicks||(h==null?void 0:h.parentClicks),defaultSlot:C.slot||(h==null?void 0:h.defaultSlot)});return}const w=!!(u.children&&u.children.length>=2)||!!C.clicks||!!((E=u.children)!=null&&E.some(X=>{var j;return(j=X.ial)==null?void 0:j[Ze]}))||!u.markdown&&!!(u.children&&u.children.length>0);if(Ri(u)&&u.children&&u.children.length>0&&(I||C.clicks||u.children.some(X=>{var j;return(j=X.ial)==null?void 0:j[Ze]}))&&w){const X=!!(u.children&&u.children.length>=2),j=u.children.find(be=>!!(be.markdown||be.content||"").trim())||u.children[0],G=((D=j==null?void 0:j.ial)==null?void 0:D[Ze])||((N=j==null?void 0:j.ial)==null?void 0:N["custom-slidev-click"]),ne=!!(!C.clicks&&X&&G),se=C.clicks||(ne?G:void 0)||(h==null?void 0:h.parentClicks),le=u.id||(h==null?void 0:h.parentContainerId),pe=C.slot||(h==null?void 0:h.defaultSlot);let Te=!0;for(const be of u.children){pe&&(!be.ial||!be.ial[Ce])&&(be.ial||(be.ial={}),be.ial[Ce]=pe);const q=!!(be.markdown||be.content||"").trim(),ae=Te&&q;ae&&(be.markdown&&(be.markdown=xn(be.markdown)),be.content&&(be.content=xn(be.content)),Te=!1);let ve=be;ae&&se&&X&&(ve={...be,ial:{...be.ial||{}}},delete ve.ial[Ze],delete ve.ial["custom-slidev-click"]),b(ve,{parentClicks:se,parentContainerId:le,defaultSlot:pe})}return}if(C.isNote){const X=ga(f);X&&(r.notes?r.notes+=`

`+X:r.notes=X),r.noteBlocks||(r.noteBlocks=[]),r.noteBlocks.push({id:u.id,type:u.type,content:X||u.content||"",rawMarkdown:f,isNote:!0,attributes:u.ial});return}C.shikiLines&&(f=_f(f,C.shikiLines)),S=f.trim();const P=(u.content||"").trim();if(S==="::right::"||P==="::right::"||/^<p>\s*::right::\s*<\/p>$/i.test(S)||S.startsWith("::right::")){r.blocks.push({id:u.id,type:u.type,content:"::right::",rawMarkdown:"::right::",slot:"slot-divider-right",attributes:u.ial});return}const z=$f(u);let V=C.slot,_=C.clicks,L=C.motion,y={...u.ial||{}};if(z!==null){for(;a.length>0&&a[a.length-1].level>=z;)a.pop();const X=a.length>0?a[a.length-1]:void 0;!V&&(X!=null&&X.slot)&&(V=X.slot),!_&&(X!=null&&X.clicks)&&!(h!=null&&h.parentContainerId)&&(_=X.clicks),!L&&(X!=null&&X.motion)&&(L=X.motion);const j={...(X==null?void 0:X.customAttrs)||{}};if(u.ial)for(const[G,ne]of Object.entries(u.ial))G.startsWith("custom-slidev-")&&!G.startsWith("custom-slidev-slide")&&(j[G]=ne);h!=null&&h.parentContainerId||a.push({level:z,slot:V,clicks:_,motion:L,customAttrs:j})}else{const X=a.length>0?a[a.length-1]:void 0;X&&(!V&&X.slot&&X.slot!=="header"&&(V=X.slot),!_&&X.clicks&&!(h!=null&&h.parentContainerId)&&(_=X.clicks),!L&&X.motion&&(L=X.motion),X.customAttrs&&(y={...X.customAttrs,...y}))}!V&&r.blocks.some(X=>X.slot==="slot-divider-right")&&(V="right"),!V&&(h!=null&&h.defaultSlot)&&(V=h.defaultSlot),V&&(y[Ce]=V),_&&!y[Ze]&&(y[Ze]=_),L&&!y[Kt]&&(y[Kt]=JSON.stringify(L)),(T||g["custom-slidev-autoplay"]||g["custom-slidev-muted"])&&(g["custom-slidev-autoplay"]&&(y["custom-slidev-autoplay"]=g["custom-slidev-autoplay"],g["custom-slidev-autoplay"]==="true"&&!g["custom-slidev-muted"]&&(y["custom-slidev-muted"]="true")),g["custom-slidev-loop"]&&(y["custom-slidev-loop"]=g["custom-slidev-loop"]),g["custom-slidev-muted"]&&(y["custom-slidev-muted"]=g["custom-slidev-muted"]),g["custom-slidev-controls"]&&(y["custom-slidev-controls"]=g["custom-slidev-controls"]));const A={id:u.id,type:u.type,content:u.content||"",rawMarkdown:f,clicks:_,parentClicks:h==null?void 0:h.parentClicks,parentContainerId:h==null?void 0:h.parentContainerId,motion:L,shikiLines:C.shikiLines,slot:V,attributes:y,rawNode:u};r.blocks.push(A)};b(p)}for(let p=0;p<s.length;p++){const b=s[p],u=[],h={...b.frontmatter};p===0&&(h.theme=o.theme,h.aspectRatio=o.aspectRatio,h.highlighter=o.highlighter,h.transition=b.frontmatter.transition||o.defaultTransition);const f=Sf(h);f&&u.push(f);const g=b.blocks.filter(B=>B.slot!=="slot-divider-right"),k=B=>B.filter(I=>!!(I.rawMarkdown||I.content||"").trim()).map(I=>{var w;return Jn(I.rawMarkdown,I.clicks,I.motion,(w=I.attributes)==null?void 0:w.style)}).join(`

`),S=B=>{const I=B.filter(z=>!!(z.rawMarkdown||z.content||"").trim());if(I.length===0)return;const w=I[0],P=(w.rawMarkdown||w.content||"").trim();(Ri(w)||/^(?:[-*+]|\d+\.)\s+/.test(P))&&(w.rawMarkdown=xn(w.rawMarkdown||w.content||""),w.content=w.rawMarkdown)},C=B=>{var z,V;if(B.length===0)return"";S(B);const I=(z=B.find(_=>_.parentClicks))==null?void 0:z.parentClicks;if(!I)return B.filter(_=>!!(_.rawMarkdown||_.content||"").trim()).map(_=>{var L;return Jn(_.rawMarkdown,_.clicks,_.motion,(L=_.attributes)==null?void 0:L.style)}).join(`

`);const w=[];let P=[];const R=()=>{if(P.length===0)return;const _=P.map(L=>(L.rawMarkdown||L.content||"").trim()).filter(Boolean).join(`

`);_&&w.push(ma(_,I)),P=[]};for(const _ of B){if(!(_.rawMarkdown||_.content||"").trim())continue;!!(_.clicks&&_.clicks.trim()!=="")?(R(),w.push(Jn(_.rawMarkdown,_.clicks,_.motion,(V=_.attributes)==null?void 0:V.style))):P.push(_)}return R(),w.join(`

`)},T=b.frontmatter.layout||"default";if(T==="clover"||Tn(T)){let B=[];const I=g.filter(_=>_.slot==="header");if(I.length>0)B=I;else if(g.length>0){const _=g.find(L=>L.type==="h"&&(!L.slot||L.slot==="default"));_&&(B=[_])}const w=g.filter(_=>!B.includes(_));let P=2;if(T==="clover")P=4;else if(T==="three-cols-header")P=3;else if(T==="two-cols-header")P=2;else{let _=0;for(const L of w){const y=(L.slot||"").match(/^col-(\d+)$/i);y&&(_=Math.max(_,parseInt(y[1],10)))}if(_>=2)P=_;else if(b.frontmatter.layoutRatio){const L=b.frontmatter.layoutRatio.trim();if(L.includes(":")){const y=L.split(":").map(A=>parseFloat(A.trim())).filter(A=>!isNaN(A)&&A>0);y.length>=2&&(P=y.length)}else{const y=L.split(/\s+/).filter(Boolean);y.length>=2&&(P=y.length)}}else w.length===1&&w[0].children&&w[0].children.length>=2&&(P=Math.min(6,w[0].children.length))}const R=va(w,P);R.forEach((_,L)=>{const y=`col-${L+1}`;for(const A of _)(!A.slot||A.slot==="default")&&(A.slot=y);S(_)});const z=R.flat();if(w.length===1&&z.length>1){const _=b.blocks.findIndex(L=>L.id===w[0].id);_!==-1&&b.blocks.splice(_,1,...z)}const V=k(B);if(V&&u.push(V),T==="two-cols-header"&&P===2){const _=C(R[0]||[]),L=C(R[1]||[]);_&&u.push(`::left::

${_}`),L&&u.push(`::right::

${L}`)}else R.forEach((_,L)=>{const y=C(_);y&&u.push(`::col-${L+1}::

${y}`)})}else if(T==="two-cols"){const B=g.filter(R=>R.slot==="left"),I=g.filter(R=>R.slot==="right");S(B),S(I);const w=k(B.length>0?B:g.filter(R=>R.slot!=="right")),P=k(I);u.push(w),P&&u.push(`::right::

${P}`)}else for(const B of g)u.push(Jn(B.rawMarkdown,B.clicks,B.motion,(d=B.attributes)==null?void 0:d.style));b.notes&&u.push(`<!--
${b.notes}
-->`),b.rawMarkdown=u.join(`

`).trim()}const c=s.map(p=>p.rawMarkdown).filter(Boolean).join(`

---

`);return{docId:e,config:o,slides:s,fullMarkdown:c}}const ws=`/* SiYuan Note Built-in Font & Background Styles for Slidev */
:root,
html:not(.dark),
[data-theme="light"],
[data-theme-mode="light"] {
  /* 思源基础卡片与主题色 (浅色模式 daylight) */
  --b3-card-error-color: #790600;
  --b3-card-error-background: #f5d1cf;
  --b3-card-warning-color: #8a4f00;
  --b3-card-warning-background: #ffe8c8;
  --b3-card-info-color: #005599;
  --b3-card-info-background: #d6eaf9;
  --b3-card-success-color: #006b04;
  --b3-card-success-background: #d7eed8;

  --b3-theme-primary: #3575f0;
  --b3-theme-secondary: #ff9200;
  --b3-theme-error: #d23f31;
  --b3-theme-background: #ffffff;
  --b3-theme-on-background: #222222;
  --b3-theme-on-surface: #5f6368;
  --b3-theme-surface-lighter: #e0e0e0;

  /* 13 种内置文字颜色 */
  --b3-font-color1: var(--b3-card-error-color);
  --b3-font-color2: var(--b3-card-warning-color);
  --b3-font-color3: var(--b3-card-info-color);
  --b3-font-color4: var(--b3-card-success-color);
  --b3-font-color5: var(--b3-theme-on-surface);
  --b3-font-color6: var(--b3-theme-primary);
  --b3-font-color7: var(--b3-theme-secondary);
  --b3-font-color8: var(--b3-theme-error);
  --b3-font-color9: #a40074;
  --b3-font-color10: #007080;
  --b3-font-color11: #006e2a;
  --b3-font-color12: #6b5a00;
  --b3-font-color13: var(--b3-theme-background);

  /* 13 种内置背景颜色 */
  --b3-font-background1: var(--b3-card-error-background);
  --b3-font-background2: var(--b3-card-warning-background);
  --b3-font-background3: var(--b3-card-info-background);
  --b3-font-background4: var(--b3-card-success-background);
  --b3-font-background5: #e2e3e4;
  --b3-font-background6: #acd0fc;
  --b3-font-background7: #fddaab;
  --b3-font-background8: #ffb0a9;
  --b3-font-background9: #fdbfff;
  --b3-font-background10: #b1ffff;
  --b3-font-background11: #affad1;
  --b3-font-background12: #fff88f;
  --b3-font-background13: var(--b3-theme-on-background);
}

html.dark,
[data-theme="dark"],
[data-theme-mode="dark"],
.theme-dark,
.dark {
  /* 思源基础卡片与主题色 (深色模式 midnight) */
  --b3-card-error-color: rgb(243, 153, 147);
  --b3-card-error-background: #442724;
  --b3-card-warning-color: rgb(255, 213, 153);
  --b3-card-warning-background: #554636;
  --b3-card-info-color: rgb(166, 213, 250);
  --b3-card-info-background: #28405c;
  --b3-card-success-color: rgb(183, 223, 185);
  --b3-card-success-background: #425347;

  --b3-theme-primary: #3575f0;
  --b3-theme-secondary: #ff9200;
  --b3-theme-error: #d23f31;
  --b3-theme-background: #1e1e1e;
  --b3-theme-on-background: #c8ccd6;
  --b3-theme-on-surface: #8b949e;
  --b3-theme-surface-lighter: #282a2e;

  /* 13 种内置文字颜色 */
  --b3-font-color1: var(--b3-card-error-color);
  --b3-font-color2: var(--b3-card-warning-color);
  --b3-font-color3: var(--b3-card-info-color);
  --b3-font-color4: var(--b3-card-success-color);
  --b3-font-color5: var(--b3-theme-on-surface);
  --b3-font-color6: var(--b3-theme-primary);
  --b3-font-color7: var(--b3-theme-secondary);
  --b3-font-color8: var(--b3-theme-error);
  --b3-font-color9: #f47c9c;
  --b3-font-color10: #4dd0e1;
  --b3-font-color11: #10df54;
  --b3-font-color12: #ecd424;
  --b3-font-color13: var(--b3-theme-background);

  /* 13 种内置背景颜色 */
  --b3-font-background1: var(--b3-card-error-background);
  --b3-font-background2: var(--b3-card-warning-background);
  --b3-font-background3: var(--b3-card-info-background);
  --b3-font-background4: var(--b3-card-success-background);
  --b3-font-background5: #3a3f42;
  --b3-font-background6: #031840;
  --b3-font-background7: #593905;
  --b3-font-background8: #3a0c09;
  --b3-font-background9: #4d1b40;
  --b3-font-background10: #1a5459;
  --b3-font-background11: #305415;
  --b3-font-background12: #4a4712;
  --b3-font-background13: var(--b3-theme-on-background);
}

@media (prefers-color-scheme: dark) {
  :root:not([data-theme="light"]):not([data-theme-mode="light"]):not(.light) {
    --b3-card-error-color: rgb(243, 153, 147);
    --b3-card-error-background: #442724;
    --b3-card-warning-color: rgb(255, 213, 153);
    --b3-card-warning-background: #554636;
    --b3-card-info-color: rgb(166, 213, 250);
    --b3-card-info-background: #28405c;
    --b3-card-success-color: rgb(183, 223, 185);
    --b3-card-success-background: #425347;

    --b3-theme-primary: #3575f0;
    --b3-theme-secondary: #ff9200;
    --b3-theme-error: #d23f31;
    --b3-theme-background: #1e1e1e;
    --b3-theme-on-background: #c8ccd6;
    --b3-theme-on-surface: #8b949e;
    --b3-theme-surface-lighter: #282a2e;

    --b3-font-color1: var(--b3-card-error-color);
    --b3-font-color2: var(--b3-card-warning-color);
    --b3-font-color3: var(--b3-card-info-color);
    --b3-font-color4: var(--b3-card-success-color);
    --b3-font-color5: var(--b3-theme-on-surface);
    --b3-font-color6: var(--b3-theme-primary);
    --b3-font-color7: var(--b3-theme-secondary);
    --b3-font-color8: var(--b3-theme-error);
    --b3-font-color9: #f47c9c;
    --b3-font-color10: #4dd0e1;
    --b3-font-color11: #10df54;
    --b3-font-color12: #ecd424;
    --b3-font-color13: var(--b3-theme-background);

    --b3-font-background1: var(--b3-card-error-background);
    --b3-font-background2: var(--b3-card-warning-background);
    --b3-font-background3: var(--b3-card-info-background);
    --b3-font-background4: var(--b3-card-success-background);
    --b3-font-background5: #3a3f42;
    --b3-font-background6: #031840;
    --b3-font-background7: #593905;
    --b3-font-background8: #3a0c09;
    --b3-font-background9: #4d1b40;
    --b3-font-background10: #1a5459;
    --b3-font-background11: #305415;
    --b3-font-background12: #4a4712;
    --b3-font-background13: var(--b3-theme-on-background);
  }
}

/* 演示块级样式排版增强 (带背景色时赋予呼吸内边距与舒适圆角) */
.slide-styled-block {
  border-radius: 6px;
  padding: 8px 14px;
  box-sizing: border-box;
  margin: 6px 0;
  transition: background-color 0.2s ease, color 0.2s ease;
}

/* 行内带背景色文本的精美圆角与微边距 */
span[style*="background-color"],
span[style*="background:"] {
  border-radius: 3px;
  padding: 1px 5px;
  box-decoration-break: clone;
  -webkit-box-decoration-break: clone;
}
`;function If(e){var o,s,l,r,a,c,d,p,b,u,h,f;if(!e||typeof e!="object")return"";const t=[],i=[];if(Array.isArray(e.styles))for(const g of e.styles){if(!g||!g.id)continue;const k=`--b3-inline-style-${g.id}`;(o=g.light)!=null&&o.color&&t.push(`  ${k}-color: ${g.light.color};`),(s=g.light)!=null&&s.backgroundColor&&t.push(`  ${k}-background-color: ${g.light.backgroundColor};`),(l=g.dark)!=null&&l.color&&i.push(`  ${k}-color: ${g.dark.color};`),(r=g.dark)!=null&&r.backgroundColor&&i.push(`  ${k}-background-color: ${g.dark.backgroundColor};`)}if(e.builtin&&Array.isArray(e.builtin.colors))for(const g of e.builtin.colors){if(!g||typeof g.index!="number")continue;const k=g.index;(a=g.light)!=null&&a.color&&t.push(`  --b3-font-color${k}: ${g.light.color};`),(c=g.light)!=null&&c.backgroundColor&&t.push(`  --b3-font-background${k}: ${g.light.backgroundColor};`),(d=g.dark)!=null&&d.color&&i.push(`  --b3-font-color${k}: ${g.dark.color};`),(p=g.dark)!=null&&p.backgroundColor&&i.push(`  --b3-font-background${k}: ${g.dark.backgroundColor};`)}if(e.builtin&&Array.isArray(e.builtin.styles))for(const g of e.builtin.styles){if(!g||!g.id)continue;const k=g.id;(b=g.light)!=null&&b.color&&t.push(`  --b3-card-${k}-color: ${g.light.color};`),(u=g.light)!=null&&u.backgroundColor&&t.push(`  --b3-card-${k}-background: ${g.light.backgroundColor};`),(h=g.dark)!=null&&h.color&&i.push(`  --b3-card-${k}-color: ${g.dark.color};`),(f=g.dark)!=null&&f.backgroundColor&&i.push(`  --b3-card-${k}-background: ${g.dark.backgroundColor};`)}if(t.length===0&&i.length===0)return"";const n=[];return t.length>0&&n.push(`:root, html:not(.dark), [data-theme="light"] {
${t.join(`
`)}
}`),i.length>0&&n.push(`html.dark, [data-theme="dark"], .dark {
${i.join(`
`)}
}`),n.join(`

`)}function _n(e){const t=If(e);return t?`${ws}

/* Custom Workspace Inline Styles */
${t}`:ws}function Qo(e){const t={};if(!e||typeof e!="string")return t;const i=e.replace(/^\{:\s*/,"").replace(/\s*\}$/,""),n=/([\w-]+)=(?:"([^"]*)"|'([^']*)'|(\S+))/g;let o;for(;(o=n.exec(i))!==null;){const s=o[1],l=o[2]??o[3]??o[4]??"";t[s]=l}return t}function Ef(e){const t=String((e==null?void 0:e.type)||"").toLowerCase();return t==="s"||t==="sb"||t==="nodesuperblock"||t==="l"||t==="nodelist"||t==="i"||t==="nodelistitem"||t==="b"||t==="nodeblockquote"}function Tf(e,t){const i=new Map,n=[];if(!Array.isArray(t)||t.length===0)return{usable:!1,reason:"索引无行",leafPatch:i,rebuildRoots:n};const o=new Map;for(const s of t)s!=null&&s.id&&o.set(s.id,s);for(const s of e||[]){if(!(s!=null&&s.id))continue;const l=o.get(s.id);if(!l)continue;const r=s.content??"",a=s.markdown??"";(l.content??"")===r&&(l.markdown??"")===a||(Ef(l)?n.push(s.id):i.set(s.id,{content:r,markdown:a}))}return{usable:!0,reason:"",leafPatch:i,rebuildRoots:n}}function Af(e){const t=String((e==null?void 0:e.type)||"").toLowerCase();return t==="h"||t==="nodeheading"}function xs(e){return ot(e)||e.type==="l"||e.type==="NodeList"||e.type==="i"||e.type==="NodeListItem"||e.type==="b"||e.type==="NodeBlockquote"}function Bf(e,t,i,n=8,o){const s=new Map;for(const b of t)b!=null&&b.id&&s.set(b.id,b);const l=b=>({id:b.id,parent_id:b.parent_id,root_id:b.root_id||e,type:b.type,subType:b.subtype??b.subType??"",content:b.content||"",markdown:b.markdown||"",ial:i(b.id,b.ial),children:[]}),r=b=>{let u=b.parent_id,h=0;for(;u&&u!==e&&h++<16;){const f=s.get(u);if(!f||!Af(f))return u;u=f.parent_id}return u||e},a=new Map;for(const b of t){if(!(b!=null&&b.id)||b.id===e||o&&o.size>0&&!o.has(b.id))continue;const u=r(b),h=a.get(u);h?h.push(b):a.set(u,[b])}if(o&&o.size>0)for(const b of a.values())b.sort((u,h)=>(o.get(u.id)??Number.MAX_SAFE_INTEGER)-(o.get(h.id)??Number.MAX_SAFE_INTEGER));const c=new Map,d=(b,u)=>{const h=l(b);if(c.set(h.id,h),u>=n||!xs(h))return h;const f=a.get(h.id);return f&&f.length>0&&(h.children=f.map(g=>d(g,u+1))),h};return{topLevel:(a.get(e)||[]).map(b=>d(b,0)),byId:c}}const Mf={getBlockAttrs:Cs,getChildBlocks:co,getDocBlocksOrders:Mc,setBlockAttrs:Ne,sql:en,getBaseUrl:()=>typeof location<"u"?location.origin:"",getInlineStyles:Dc};class Df{constructor(t){ye(this,"deps");ye(this,"attrOverrides",new Map);ye(this,"trackedListSuperBlocks",new Map);ye(this,"fallbackWarnedDocId","");this.deps={...Mf,...t||{}}}setBlockAttrOverride(t,i){if(!t||!i)return;const o={...this.attrOverrides.get(t)||{}};for(const[s,l]of Object.entries(i))l===""||l===null||l===void 0?delete o[s]:o[s]=String(l);Object.keys(o).length===0?this.attrOverrides.delete(t):this.attrOverrides.set(t,o)}getBlockAttrOverride(t){return this.attrOverrides.get(t)}getAllAttrOverrides(){return new Map(this.attrOverrides)}getTrackedListSuperBlocks(t){return this.trackedListSuperBlocks.get(t)||[]}clearBlockAttrOverride(t,i){if(!t)return;if(!i){this.attrOverrides.delete(t);return}const n=this.attrOverrides.get(t);n&&(delete n[i],Object.keys(n).length===0&&this.attrOverrides.delete(t))}clearAllOverrides(){this.attrOverrides.clear(),this.trackedListSuperBlocks.clear()}async compile(t){try{const i=await this.deps.getBlockAttrs(t).catch(()=>({}))||{},n=this.attrOverrides.get(t);n&&Object.assign(i,n);const o=await this.deps.getChildBlocks(t).catch(()=>[])||[],s=this.deps.getDocBlocksOrders?await this.deps.getDocBlocksOrders(t).catch(()=>[])||[]:[],l=new Map;for(let A=0;A<s.length;A++)s[A]&&l.set(s[A],A);const r=l.size>0,a=`SELECT id, parent_id, root_id, type, subtype, content, markdown, ial, sort, created FROM blocks WHERE root_id = '${t}' AND id != '${t}' ORDER BY sort ASC, created ASC LIMIT 99999`,c=await this.deps.sql(a).catch(()=>[])||[],d=Tf(o,c),p=new Map;if(Array.isArray(c))for(const A of c)A.id&&A.ial&&p.set(A.id,Qo(A.ial));const b=`SELECT block_id, name, value FROM attributes WHERE root_id = '${t}' AND type = 'b' LIMIT 99999`,u=await this.deps.sql(b).catch(()=>[])||[];if(Array.isArray(u)){for(const A of u)if(A.block_id&&A.name){let F=p.get(A.block_id);F||(F={},p.set(A.block_id,F)),F[A.name]=A.value||""}}const h=(A,F)=>{const E={...p.get(A)||(F?Qo(F):{})},D=this.attrOverrides.get(A);return D&&Object.assign(E,D),E},f=Array.isArray(c)&&c.length>0?Bf(t,c,h,8,l):null,g=o.map(A=>A.id).filter(Boolean),k=A=>({id:A.id,parent_id:A.parent_id,root_id:A.root_id||t,type:A.type,subType:A.subType,content:A.content||"",markdown:A.markdown||"",ial:h(A.id,A.ial),children:A.children}),S=async(A,F=0)=>{if(!A||F>8||!xs(A))return;const E=await this.deps.getChildBlocks(A.id).catch(()=>[])||[];if(!(!Array.isArray(E)||E.length===0)){A.children=E.filter(D=>D==null?void 0:D.id).map(D=>({id:D.id,parent_id:A.id,root_id:t,type:D.type,subType:D.subType,content:D.content||"",markdown:D.markdown||"",ial:h(D.id,D.ial),children:[]}));for(const D of A.children)await S(D,F+1)}},C=new Map;for(const A of c)A!=null&&A.id&&C.set(A.id,A);const T=g.every(A=>{const F=C.get(A);return!F||!!F.type});let B=[],I=!1;if(f&&d.usable&&r&&T){this.fallbackWarnedDocId="";for(const[F,E]of d.leafPatch){const D=f.byId.get(F);D&&(D.content=E.content,D.markdown=E.markdown)}const A=new Map;for(const F of o)F!=null&&F.id&&A.set(F.id,F);for(const F of d.rebuildRoots){const E=f.byId.get(F),D=A.get(F);E&&D&&(E.content=D.content||"",E.markdown=D.markdown||""),await S(E)}for(const F of o){if(!(F!=null&&F.id)||f.byId.has(F.id))continue;const E=k(F);await S(E),f.byId.set(E.id,E),f.topLevel.push(E)}B=f.topLevel.filter(F=>l.has(F.id)).sort((F,E)=>(l.get(F.id)??0)-(l.get(E.id)??0))}else g.length>0?(I=!0,this.fallbackWarnedDocId!==t&&(this.fallbackWarnedDocId=t,console.warn(`[DocumentCompiler] 索引结构不可用，回退逐容器查询（较慢）doc=${t} 实时顶层=${g.length} 索引行=${c.length} 文档序=${s.length} 原因=${d.reason||"缺少实时文档序"}`)),B=o.map(A=>k(A))):f&&(B=f.topLevel);const w=async(A,F=0)=>{if(!(!A||A.length===0||F>8))for(const E of A){if(xs(E)&&(!E.children||E.children.length===0)){let N=await this.deps.getChildBlocks(E.id).catch(()=>[]);if(!N||N.length===0){const X=`SELECT id, parent_id, root_id, type, subtype as subType, content, markdown, ial FROM blocks WHERE parent_id = '${E.id}' ORDER BY sort ASC, created ASC`;N=await this.deps.sql(X).catch(()=>[])||[]}if(Array.isArray(N)&&N.length>0){const X=new Set(B.map(G=>G.id)),j=N.filter(G=>G.id!==E.id&&!X.has(G.id));j.length>0&&(E.children=j.map(G=>{const ne=p.get(G.id)||(G.ial?Qo(G.ial):{}),se=this.attrOverrides.get(G.id);return se&&Object.assign(ne,se),{id:G.id,parent_id:G.parent_id||E.id,root_id:G.root_id||t,type:G.type,subType:G.subType,content:G.content||"",markdown:G.markdown||"",ial:ne}}))}}E.children&&E.children.length>0&&await w(E.children,F+1)}};I&&await w(B);const P=A=>{var F,E;for(const D of A)if(D.children&&D.children.length>0){P(D.children);for(const N of D.children)if(N.ial)for(const[X,j]of Object.entries(N.ial))X.startsWith("custom-slidev-")&&!((F=D.ial)!=null&&F[X])&&(D.ial||(D.ial={}),D.ial[X]=j);if(D.ial){for(const[N,X]of Object.entries(D.ial))if(N.startsWith("custom-slidev-"))for(const j of D.children)(j.type==="video"||j.type==="NodeVideo"||/<video\b/i.test(j.markdown||j.content||""))&&!((E=j.ial)!=null&&E[N])&&(j.ial||(j.ial={}),j.ial[N]=X)}}};P(B),kf(B,A=>{const F={[ue]:A.layout};this.setBlockAttrOverride(A.blockId,F),(this.deps.setBlockAttrs||Ne)(A.blockId,F).catch(D=>{console.warn("[DocumentCompiler] Failed to auto-tag superblock image layout:",D)})});const R=this.trackedListSuperBlocks.get(t)||[],z=yf(t,B,{tracked:R,onTagChange:A=>{this.setBlockAttrOverride(A.blockId,A.attrs),A.blockId===t&&Object.assign(i,A.attrs);const F=D=>{for(const N of D)N.id===A.blockId&&(N.ial||(N.ial={}),Object.assign(N.ial,A.attrs)),N.children&&N.children.length>0&&F(N.children)};F(B),(this.deps.setBlockAttrs||Ne)(A.blockId,A.attrs).catch(D=>{console.warn("[DocumentCompiler] Failed to auto-tag list superblock attrs:",D)})}});this.trackedListSuperBlocks.set(t,z.newTracked);const V=new Set;for(const A of B){const F=A.markdown||A.content||"";if(F.includes("((")){const E=Lc(F);for(const D of E)V.add(D.blockId)}}const _={};if(V.size>0){const A=Array.from(V).map(E=>`'${E}'`).join(","),F=await this.deps.sql(`SELECT id, content, markdown FROM blocks WHERE id IN (${A})`).catch(()=>[])||[];if(Array.isArray(F))for(const E of F)E.id&&(_[E.id]=E.markdown||E.content||"")}const L=this.deps.getBaseUrl?this.deps.getBaseUrl():"",y=zr(t,i,B,{baseUrl:L,refContentMap:_});try{const A=this.deps.getInlineStyles?await this.deps.getInlineStyles().catch(()=>null):null;y.customThemeCss=_n(A)}catch{y.customThemeCss=_n(null)}return y}catch(i){console.error("[DocumentCompilerService] Failed to compile document:",i);const n=zr(t,{},[],{});return n.customThemeCss=_n(null),n}}}const Be=new Df;class qs{constructor(t){ye(this,"devServerUrl","http://localhost:3030");ye(this,"isConnected",!1);ye(this,"lastSyncTime",null);t&&(this.devServerUrl=t)}getUrl(){return this.devServerUrl}setUrl(t){this.devServerUrl=t.replace(/\/+$/,"")}isServerConnected(){return this.isConnected}getLastSyncTime(){return this.lastSyncTime}async probeServer(t=1500){try{const i=new AbortController,n=setTimeout(()=>i.abort(),t),o=await fetch(this.devServerUrl,{method:"HEAD",mode:"no-cors",signal:i.signal}).catch(()=>null);return clearTimeout(n),this.isConnected=!!o,this.isConnected}catch{return this.isConnected=!1,!1}}buildStandardSlidevMarkdown(t){const i=t.config,n=["---",`theme: ${i.theme||"default"}`,`aspectRatio: "${i.aspectRatio||"16/9"}"`,`highlighter: ${i.highlighter||"shiki"}`,`transition: ${i.defaultTransition||"slide-left"}`];i.colorSchema&&i.colorSchema!=="auto"&&n.push(`colorSchema: ${i.colorSchema}`),n.push("drawings:","  persist: false","---","");const o=n.join(`
`),s=t.slides.map((r,a)=>{const c=r.frontmatter||{},d=[],p=a===0;c.layout&&c.layout!=="default"&&d.push(`layout: ${c.layout}`),c.transition&&d.push(`transition: ${c.transition}`),c.background&&d.push(`background: ${c.background}`),c.class&&d.push(`class: "${c.class}"`);let b="";d.length>0?b=p?"":`---
${d.join(`
`)}
---

`:p||(b=`---

`);let u="";if(c.layout==="two-cols"){const f=r.blocks.filter(C=>C.slot!=="right"),g=r.blocks.filter(C=>C.slot==="right"),k=f.map(C=>C.rawMarkdown||C.content||"").join(`

`),S=g.map(C=>C.rawMarkdown||C.content||"").join(`

`);u=`${k}

::right::

${S}`}else u=r.blocks.map(f=>f.rawMarkdown||f.content||"").join(`

`);let h="";return r.notes&&r.notes.trim()&&(h=`

<!--
${r.notes.trim()}
-->`),`${b}${u}${h}`}).join(`

`);let l="";return t.config.normalizeHeadingSizes&&(l=`

<style>
/* Specific Heading Normalization */
.slidev-layout:not(.cover) > :is(h1, h2, h3, h4, h5, h6):first-child {
  font-size: 1.7rem !important;
}
.two-cols-header-top :is(h1, h2, h3, h4, h5, h6),
.cols-header-top :is(h1, h2, h3, h4, h5, h6),
.layout-header-section :is(h1, h2, h3, h4, h5, h6) {
  font-size: 1.7rem !important;
}
:is(.two-cols-left, .two-cols-right, .col, .col-1, .col-2, .col-3, .three-cols-col) > :is(h1, h2, h3, h4, h5, h6):first-child {
  font-size: 1.3rem !important;
}
</style>`),`${o}${s}${l}
`}async syncToWorkspaceFile(t,i="/data/storage/petal/siyuan-slidev/slides.md",n){const o=this.buildStandardSlidevMarkdown(t);if(this.lastSyncTime=Date.now(),n)try{const s=typeof Blob<"u"?new Blob([o],{type:"text/markdown;charset=utf-8"}):Buffer.from(o,"utf-8");return await n(i,!1,s),{success:!0,path:i}}catch(s){return{success:!1,path:i,error:String(s)}}return{success:!0,path:i}}downloadSlidesMd(t,i="slides.md"){if(typeof window>"u"||typeof document>"u")return!1;const n=this.buildStandardSlidevMarkdown(t),o=new Blob([n],{type:"text/markdown;charset=utf-8"}),s=URL.createObjectURL(o),l=document.createElement("a");return l.href=s,l.download=i,document.body.appendChild(l),l.click(),document.body.removeChild(l),URL.revokeObjectURL(s),!0}}function Lf(){if(typeof window<"u"&&typeof window.require=="function")return window.require.bind(window);if(typeof globalThis<"u"&&typeof globalThis.require=="function")return globalThis.require.bind(globalThis);if(typeof require=="function")return require}function _t(e){const t=Lf();if(t)try{return t(e)}catch{try{const i=e.startsWith("node:")?e.slice(5):`node:${e}`;return t(i)}catch{}}}function Gs(){var t;if(typeof window<"u"&&window.process)return window.process;const e=_t("process");return e&&e.versions?e:typeof process<"u"&&((t=process.versions)!=null&&t.node)?process:globalThis.process}function ba(){var t,i;const e=Gs();if(e&&((t=e.versions)!=null&&t.node))return!0;if(typeof window<"u"&&window.siyuan){const n=_t("child_process");if(n&&typeof n.spawn=="function")return!0}return!!(typeof process<"u"&&((i=process.versions)!=null&&i.node))}function Of(){if(typeof window>"u"||!window.location)return!1;try{return new URLSearchParams(window.location.search).get("remote")==="1"}catch{return!1}}function Pn(){const e=Gs();if(e!=null&&e.platform)return e.platform;if(typeof process<"u"&&process.platform)return process.platform;const t=_t("os");if(t&&typeof t.platform=="function")return t.platform();if(typeof navigator<"u"){const i=navigator.userAgent.toLowerCase();if(i.includes("win"))return"win32";if(i.includes("mac"))return"darwin";if(i.includes("linux"))return"linux"}return"web"}function ya(){var n,o;const e=Gs(),t={...(e==null?void 0:e.env)||{}};if(Pn()==="win32"){const s=["C:\\Program Files\\nodejs","C:\\Program Files (x86)\\nodejs",(n=e==null?void 0:e.env)!=null&&n.APPDATA?`${e.env.APPDATA}\\npm`:"",(o=e==null?void 0:e.env)!=null&&o.USERPROFILE?`${e.env.USERPROFILE}\\AppData\\Roaming\\npm`:""].filter(Boolean),l=Object.keys(t).find(c=>c.toLowerCase()==="path")||"PATH",a=(t[l]||"").split(";").filter(Boolean);for(const c of s)c&&!a.some(d=>d.toLowerCase()===c.toLowerCase())&&a.push(c);t[l]=a.join(";")}return t}function Ss(e){var i,n,o;if(!e)return"";if(/^[a-zA-Z]:[/\\]/.test(e))return e.replace(/\\/g,"/");let t="";if(typeof window<"u"&&((o=(n=(i=window.siyuan)==null?void 0:i.config)==null?void 0:n.system)!=null&&o.dataDir)&&(t=window.siyuan.config.system.dataDir.replace(/\\/g,"/")),t&&e.startsWith("/data/")){const s=e.slice(6);return`${t}/${s}`.replace(/\\/g,"/")}return e}function Rf(){const e=_t("os"),t=_t("path");if(e&&typeof e.tmpdir=="function"){const i=e.tmpdir();return t&&typeof t.join=="function"?t.join(i,"siyuan-slidev-pro").replace(/\\/g,"/"):`${i}/siyuan-slidev-pro`.replace(/\\/g,"/")}return"/data/storage/petal/siyuan-slidev/pro-workspace"}class Zs{constructor(t){ye(this,"runner");this.runner=t||Zs.defaultRunner}static async defaultRunner(t,i){var n;try{let o=(n=_t("child_process"))==null?void 0:n.execFile;if(!o){const a=await import("node:child_process").catch(()=>({}));o=a==null?void 0:a.execFile}if(!o)return{code:-1,stdout:"",stderr:"child_process execFile not available"};const l=Pn()==="win32",r=ya();return await new Promise(a=>{o(t,i,{timeout:5e3,shell:l,env:r},(c,d,p)=>{a({code:c?c.code||1:0,stdout:d?String(d).trim():"",stderr:p?String(p).trim():""})})})}catch(o){return{code:-1,stdout:"",stderr:String(o)}}}async detect(){const t=ba(),i=Pn();if(!t)return{hasNode:!1,hasSlidevCli:!1,platform:"browser",isDesktop:!1,error:"当前处于纯前端浏览器或移动端环境，无 Node.js 运行时支撑"};let n=!1,o,s=!1,l;try{const r=await this.runner("node",["-v"]);r.code===0&&r.stdout.startsWith("v")&&(n=!0,o=r.stdout)}catch{}if(n){try{const r=i==="win32"?"slidev.cmd":"slidev",a=await this.runner(r,["--version"]);a.code===0&&a.stdout&&(s=!0,l=a.stdout)}catch{}if(!s)try{const r=i==="win32"?"npx.cmd":"npx",a=await this.runner(r,["@slidev/cli","--version"]);a.code===0&&a.stdout&&(s=!0,l=a.stdout)}catch{}}return{hasNode:n,nodeVersion:o,hasSlidevCli:s,slidevVersion:l,platform:i,isDesktop:t}}}class Pf{constructor(){ye(this,"iframe",null);ye(this,"isReady",!1);ye(this,"pageChangedHandlers",[]);ye(this,"readyHandlers",[]);ye(this,"currentState",{no:1,clicks:0,total:1});this.handleWindowMessage=this.handleWindowMessage.bind(this)}getCurrentState(){return{...this.currentState}}attach(t){this.detach(),this.iframe=t,this.isReady=!1,typeof window<"u"&&window.addEventListener("message",this.handleWindowMessage)}detach(){typeof window<"u"&&window.removeEventListener("message",this.handleWindowMessage),this.iframe=null,this.isReady=!1}postMessage(t,i){var o;if(!((o=this.iframe)!=null&&o.contentWindow))return;const n={target:"slidev",sender:"siyuan",type:t,...i};try{this.iframe.contentWindow.postMessage(n,"*")}catch(s){console.warn("[NativeSlidevBridge] postMessage error:",s)}}navigateToPage(t){this.postMessage("navigate",{no:t})}next(){this.postMessage("next")}prev(){this.postMessage("prev")}nextClick(){this.postMessage("next-click")}prevClick(){this.postMessage("prev-click")}onPageChanged(t){return this.pageChangedHandlers.push(t),()=>{this.pageChangedHandlers=this.pageChangedHandlers.filter(i=>i!==t)}}onReady(t){return this.readyHandlers.push(t),()=>{this.readyHandlers=this.readyHandlers.filter(i=>i!==t)}}handleWindowMessage(t){const i=t.data;if(!(!i||i.target!=="slidev")){if(!this.isReady){this.isReady=!0;for(const n of this.readyHandlers)n()}if(i.type==="update-state"&&i.navState){const n=i.navState;this.currentState={no:n.no??this.currentState.no,clicks:n.clicks??this.currentState.clicks,total:n.total??this.currentState.total,hasNext:n.hasNext,hasPrev:n.hasPrev};for(const o of this.pageChangedHandlers)o(this.currentState.no,this.currentState.total||1,this.currentState)}else if(i.type==="navigate"&&typeof i.no=="number"){this.currentState.no=i.no;for(const n of this.pageChangedHandlers)n(i.no,this.currentState.total||1,this.currentState)}}}}class Nf{constructor(t){ye(this,"childProcess",null);ye(this,"activePort",null);ye(this,"isRunning",!1);ye(this,"defaultPort");ye(this,"maxPortRetries");ye(this,"probeTimeoutMs");ye(this,"customSpawner");ye(this,"customPortChecker");this.defaultPort=(t==null?void 0:t.defaultPort)||3030,this.maxPortRetries=(t==null?void 0:t.maxPortRetries)||20,this.probeTimeoutMs=(t==null?void 0:t.probeTimeoutMs)||1e4,this.customSpawner=t==null?void 0:t.customSpawner,this.customPortChecker=t==null?void 0:t.customPortChecker}getActivePort(){return this.activePort}getIsRunning(){return this.isRunning}async isPortAvailable(t){if(this.customPortChecker)return this.customPortChecker(t);try{let i=_t("net");return i||(i=await import("node:net").catch(()=>({}))),i!=null&&i.createServer?await new Promise(n=>{const o=i.createServer();o.once("error",()=>n(!1)),o.once("listening",()=>{o.close(()=>n(!0))}),o.listen(t,"127.0.0.1")}):!0}catch{return!0}}async allocPort(t){const i=t||this.defaultPort;for(let n=0;n<this.maxPortRetries;n++){const o=i+n;if(await this.isPortAvailable(o))return o}return i}async pollServerReady(t,i=8e3,n=300){const o=Date.now();for(;Date.now()-o<i;){try{const s=new AbortController,l=setTimeout(()=>s.abort(),n),r=await fetch(t,{method:"HEAD",mode:"no-cors",signal:s.signal}).catch(()=>null);if(clearTimeout(l),r)return!0}catch{}await new Promise(s=>setTimeout(s,n))}return!1}async startServer(t,i){var a,c;if(this.isRunning&&this.activePort)return{success:!0,port:this.activePort,url:`http://localhost:${this.activePort}?embedded=true`};const n=await this.allocPort(i);this.activePort=n;const s=Pn()==="win32"?"npx.cmd":"npx",l=Ss(t),r=["@slidev/cli",l,"--port",String(n),"--no-open"];try{if(this.customSpawner)this.childProcess=this.customSpawner(s,r,{detached:!1});else{let p=(a=_t("child_process"))==null?void 0:a.spawn;if(!p){const h=await import("node:child_process").catch(()=>({}));p=h==null?void 0:h.spawn}if(!p)throw new Error("child_process spawn not available in current runtime");const b=l.includes("/")||l.includes("\\")?l.replace(/[/\\][^/\\]+$/,""):void 0,u=ya();this.childProcess=p(s,r,{cwd:b,detached:!1,shell:!0,env:{...u,FORCE_COLOR:"1"}})}this.isRunning=!0,(c=this.childProcess)!=null&&c.on&&this.childProcess.on("exit",()=>{this.isRunning=!1,this.activePort=null,this.childProcess=null});const d=`http://localhost:${n}`;return!this.customSpawner&&!await this.pollServerReady(d,this.probeTimeoutMs)?(this.stopServer(),{success:!1,port:n,url:"",error:`Slidev DevServer 启动超时 (未在 ${this.probeTimeoutMs}ms 内响应端口 ${n})`}):{success:!0,port:n,url:`${d}?embedded=true`}}catch(d){return this.stopServer(),{success:!1,port:n,url:"",error:`唤起 Slidev 进程失败: ${String(d)}`}}}stopServer(){var t;if(this.childProcess){try{if(this.childProcess.kill("SIGTERM"),Pn()==="win32"&&this.childProcess.pid&&!this.customSpawner){const n=(t=_t("child_process"))==null?void 0:t.exec;n?n(`taskkill /pid ${this.childProcess.pid} /T /F`,()=>{}):import("node:child_process").then(({exec:o})=>{var s;o(`taskkill /pid ${(s=this.childProcess)==null?void 0:s.pid} /T /F`,()=>{})}).catch(()=>{})}}catch{}this.childProcess=null}this.isRunning=!1,this.activePort=null}}class Ys{constructor(){ye(this,"iframe",null);ye(this,"isReady",!1);ye(this,"pendingMessages",[]);ye(this,"slideChangedHandlers",[]);ye(this,"blockClickedHandlers",[]);ye(this,"openInEditorHandlers",[]);ye(this,"clientReadyHandlers",[]);ye(this,"openPeekDrawerHandlers",[]);ye(this,"toggleFullscreenHandlers",[]);this.handleWindowMessage=this.handleWindowMessage.bind(this)}attach(t){this.detach(),this.iframe=t,this.isReady=!1,typeof window<"u"&&window.addEventListener("message",this.handleWindowMessage)}detach(){typeof window<"u"&&window.removeEventListener("message",this.handleWindowMessage),this.iframe=null,this.isReady=!1,this.pendingMessages=[]}postMessage(t,i){var o;const n={source:"siyuan-slidev-host",action:t,payload:i};if(!((o=this.iframe)!=null&&o.contentWindow)||!this.isReady){this.pendingMessages.push(n);return}try{this.iframe.contentWindow.postMessage(n,"*")}catch(s){console.warn("[WebSandboxBridge] postMessage error:",s)}}updateSlides(t,i,n,o){this.postMessage("UPDATE_SLIDES",{slides:t,config:i,fullMarkdown:n,customThemeCss:o})}navigatePage(t){this.postMessage("NAVIGATE_PAGE",{pageIndex:t})}highlightElement(t){this.postMessage("HIGHLIGHT_ELEMENT",{targetBlockId:t})}nextStep(){this.postMessage("NEXT_STEP",{})}prevStep(){this.postMessage("PREV_STEP",{})}freezeKeyboardNav(t){this.postMessage("FREEZE_KEYBOARD_NAV",{frozen:t})}toggleOverview(){this.postMessage("TOGGLE_OVERVIEW",{})}onSlideChanged(t){return this.slideChangedHandlers.push(t),()=>{this.slideChangedHandlers=this.slideChangedHandlers.filter(i=>i!==t)}}onBlockClicked(t){return this.blockClickedHandlers.push(t),()=>{this.blockClickedHandlers=this.blockClickedHandlers.filter(i=>i!==t)}}onOpenInEditor(t){return this.openInEditorHandlers.push(t),()=>{this.openInEditorHandlers=this.openInEditorHandlers.filter(i=>i!==t)}}onOpenPeekDrawer(t){return this.openPeekDrawerHandlers.push(t),()=>{this.openPeekDrawerHandlers=this.openPeekDrawerHandlers.filter(i=>i!==t)}}onRequestToggleFullscreen(t){return this.toggleFullscreenHandlers.push(t),()=>{this.toggleFullscreenHandlers=this.toggleFullscreenHandlers.filter(i=>i!==t)}}onClientReady(t){return this.clientReadyHandlers.push(t),()=>{this.clientReadyHandlers=this.clientReadyHandlers.filter(i=>i!==t)}}handleWindowMessage(t){var n;const i=t.data;if(!(!i||i.source!=="siyuan-slidev-client"))switch(i.action){case"CLIENT_READY":for(this.isReady=!0;this.pendingMessages.length>0;){const o=this.pendingMessages.shift();o&&((n=this.iframe)!=null&&n.contentWindow)&&this.iframe.contentWindow.postMessage(o,"*")}for(const o of this.clientReadyHandlers)o();break;case"SLIDE_CHANGED":if(i.payload.currentPage!==void 0)for(const o of this.slideChangedHandlers)o(i.payload.currentPage,i.payload.totalPages||1,i.payload.currentBlockId||"");break;case"BLOCK_CLICKED":if(i.payload.clickedBlockId)for(const o of this.blockClickedHandlers)o(i.payload.clickedBlockId,i.payload.currentPage||1);break;case"OPEN_IN_EDITOR":if(i.payload.blockId||i.payload.clickedBlockId){const o=i.payload.blockId||i.payload.clickedBlockId||"";for(const s of this.openInEditorHandlers)s(o,i.payload.currentPage||1)}break;case"OPEN_PEEK_DRAWER":if(i.payload.peekType){const o=i.payload.blockId||i.payload.url||"",s={peekType:i.payload.peekType,target:o,title:i.payload.title};for(const l of this.openPeekDrawerHandlers)l(s)}break;case"REQUEST_TOGGLE_FULLSCREEN":for(const o of this.toggleFullscreenHandlers)o();break}}}const ka={"snippets/external.ts":`// Inside ./snippets/external.ts
// #region snippet
export function emptyArray<T>(length: number) {
  return Array.from<T>({ length })
}
// #endregion snippet

export function sayHello() {
  console.log('Hello from snippets/external.ts')
}
`},zf=`<script setup lang="ts">
import { computed, useSlots } from 'vue'

const props = defineProps({
  layoutRatio: {
    type: String,
    default: '',
  },
  cols: {
    type: [Number, String],
    default: 0,
  },
})

const slots = useSlots()

const detectedColsCount = computed(() => {
  const explicitCols = Number(props.cols)
  if (explicitCols >= 2 && explicitCols <= 6) return explicitCols
  const r = (props.layoutRatio || '').trim()
  if (r.includes(':')) {
    const parts = r.split(':').map(p => parseFloat(p.trim())).filter(n => !isNaN(n) && n > 0)
    if (parts.length >= 2) return Math.min(parts.length, 6)
  }
  const tokens = r.split(/\\s+/).filter(Boolean)
  if (tokens.length >= 2) return Math.min(tokens.length, 6)
  for (let i = 6; i >= 3; i--) {
    if (slots[\`col-\${i}\`]) return i
  }
  if (slots['col-2'] || slots['right']) return 2
  return 2
})

const gridStyle = computed(() => {
  const r = props.layoutRatio || ''
  if (r) {
    if (r.includes(':')) {
      const parts = r.split(':').map(p => parseFloat(p.trim())).filter(n => !isNaN(n) && n > 0)
      if (parts.length >= 2) {
        return { gridTemplateColumns: parts.map(n => \`\${n}fr\`).join(' ') }
      }
    }
    const tokens = r.split(/\\s+/).filter(Boolean)
    if (tokens.length >= 2) {
      return { gridTemplateColumns: tokens.join(' ') }
    }
  }
  return { gridTemplateColumns: \`repeat(\${detectedColsCount.value}, minmax(0, 1fr))\` }
})
<\/script>

<template>
  <div class="slidev-layout cols-header w-full h-full flex flex-col">
    <div class="header-section mb-4 w-full">
      <slot />
    </div>
    <div class="grid gap-6 flex-1 items-stretch" :style="gridStyle">
      <div v-if="detectedColsCount >= 1" class="col-1 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-1"><slot name="left" /></slot>
      </div>
      <div v-if="detectedColsCount >= 2" class="col-2 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-2"><slot v-if="detectedColsCount === 2" name="right" /></slot>
      </div>
      <div v-if="detectedColsCount >= 3" class="col-3 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-3" />
      </div>
      <div v-if="detectedColsCount >= 4" class="col-4 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-4" />
      </div>
      <div v-if="detectedColsCount >= 5" class="col-5 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-5" />
      </div>
      <div v-if="detectedColsCount >= 6" class="col-6 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-6" />
      </div>
    </div>
  </div>
</template>
`,Ff=`<script setup lang="ts">
import { computed } from 'vue'

const props = defineProps({
  layoutRatio: {
    type: String,
    default: '',
  },
})

const gridStyle = computed(() => {
  const r = props.layoutRatio || ''
  if (!r) return {}
  if (r.includes(':')) {
    const parts = r.split(':').map(p => parseFloat(p.trim())).filter(n => !isNaN(n) && n > 0)
    if (parts.length >= 2) {
      return { gridTemplateColumns: parts.map(n => \`\${n}fr\`).join(' ') }
    }
  }
  const tokens = r.split(/\\s+/).filter(Boolean)
  if (tokens.length >= 2) {
    return { gridTemplateColumns: tokens.join(' ') }
  }
  return {}
})
<\/script>

<template>
  <div class="slidev-layout three-cols-header w-full h-full flex flex-col">
    <div class="header-section mb-4 w-full">
      <slot />
    </div>
    <div class="grid gap-6 flex-1 items-stretch" :class="gridStyle.gridTemplateColumns ? '' : 'grid-cols-3'" :style="gridStyle">
      <div class="col-1 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-1" />
      </div>
      <div class="col-2 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-2" />
      </div>
      <div class="col-3 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-3" />
      </div>
    </div>
  </div>
</template>
`,Hf=`<script setup lang="ts">
import { useSlots } from 'vue'

const slots = useSlots()
<\/script>

<template>
  <div class="slidev-layout clover w-full h-full flex flex-col">
    <div class="header-section mb-4 w-full">
      <slot />
    </div>
    <div class="grid grid-cols-2 grid-rows-2 gap-6 flex-1 items-stretch">
      <div class="col-1 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-1" />
      </div>
      <div class="col-2 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-2" />
      </div>
      <div class="col-3 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-3" />
      </div>
      <div class="col-4 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-4" />
      </div>
    </div>
  </div>
</template>
`,jf=`// Auto-generated by SiYuan Slidev Studio
// 本地 HTML 链接（思源资产 / 工作区文件 / 绝对文件路径）速览判定
// 注意：需与 public/slidev-client/index.html 中的拦截器保持同步
function isPeekableLocalHtml(href: string): boolean {
  const clean = (href || '').trim()
  if (!clean || clean.startsWith('#') || clean.startsWith('//')) return false
  if (!/\\.html?($|[?#])/i.test(clean)) return false
  if (/^https?:\\/\\//i.test(clean)) return false
  const scheme = /^([a-z][a-z0-9+.-]*):/i.exec(clean)
  if (!scheme) return true
  const schemeName = scheme[1].toLowerCase()
  if (schemeName === 'file') return true
  // Windows 盘符路径（D:\\\\docs\\\\demo.html）并非协议前缀
  return schemeName.length === 1 && /^[a-zA-Z]:[\\\\/]/.test(clean)
}

// 本地 HTML 链接预处理：思源资产统一指向内核 /assets/ 静态服务，其余原样转交宿主归一化
// 不基于 location 绝对化，保证 Pro 模式（Slidev dev server）与沙箱模式行为完全一致
function resolvePeekHref(href: string): string {
  const clean = (href || '').trim()
  if (/^(?:\\.\\/|\\/)?assets\\//.test(clean)) {
    return '/' + clean.replace(/^(?:\\.\\/|\\/)/, '')
  }
  return clean
}

export default function() {
  if (typeof window === 'undefined') return
  window.addEventListener('click', (e: MouseEvent) => {
    const target = e.target as HTMLElement | null
    if (!target || !target.closest) return

    const refEl = target.closest('[data-ref-id]')
    if (refEl) {
      const blockId = refEl.getAttribute('data-ref-id')
      if (blockId) {
        e.preventDefault()
        e.stopPropagation()
        window.parent.postMessage({
          source: 'siyuan-slidev-client',
          action: 'OPEN_PEEK_DRAWER',
          payload: { peekType: 'siyuan', blockId, title: (refEl.innerText || refEl.title || '').trim() }
        }, '*')
        return
      }
    }

    const linkEl = target.closest('a') as HTMLAnchorElement | null
    if (linkEl) {
      const href = linkEl.getAttribute('href') || ''
      if (href.startsWith('siyuan://blocks/')) {
        e.preventDefault()
        e.stopPropagation()
        const cleanBlockId = href.replace('siyuan://blocks/', '').split('?')[0]
        window.parent.postMessage({
          source: 'siyuan-slidev-client',
          action: 'OPEN_PEEK_DRAWER',
          payload: { peekType: 'siyuan', blockId: cleanBlockId, title: (linkEl.innerText || linkEl.title || '').trim() }
        }, '*')
      } else if (/^https?:\\/\\//i.test(href)) {
        e.preventDefault()
        e.stopPropagation()
        window.parent.postMessage({
          source: 'siyuan-slidev-client',
          action: 'OPEN_PEEK_DRAWER',
          payload: { peekType: 'web', url: href, title: (linkEl.innerText || linkEl.title || '').trim() }
        }, '*')
      } else if (isPeekableLocalHtml(href)) {
        e.preventDefault()
        e.stopPropagation()
        window.parent.postMessage({
          source: 'siyuan-slidev-client',
          action: 'OPEN_PEEK_DRAWER',
          payload: { peekType: 'web', url: resolvePeekHref(href), title: (linkEl.innerText || linkEl.title || '').trim() }
        }, '*')
      }
    }
  }, true)
}
`,Wf=`${ws}

/* Auto-generated by SiYuan Slidev Studio */
.slidev-ref-tag,
a.slidev-ref-tag {
  display: inline-flex;
  align-items: center;
  background: color-mix(in srgb, var(--slidev-theme-primary, #10b981) 12%, transparent);
  color: var(--slidev-theme-primary, #10b981);
  border-radius: 4px;
  padding: 2px 8px;
  font-size: 0.88em;
  text-decoration: none;
  border: 1px solid color-mix(in srgb, var(--slidev-theme-primary, #10b981) 25%, transparent);
  cursor: pointer;
  transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
  user-select: none;
}

.slidev-ref-tag:hover,
a.slidev-ref-tag:hover {
  background: color-mix(in srgb, var(--slidev-theme-primary, #10b981) 22%, transparent);
  color: var(--slidev-theme-primary, #10b981);
  border-color: color-mix(in srgb, var(--slidev-theme-primary, #10b981) 55%, transparent);
  transform: translateY(-1px);
  box-shadow: 0 2px 8px color-mix(in srgb, var(--slidev-theme-primary, #10b981) 20%, transparent);
}

.slidev-block-ref {
  display: block;
  padding: 10px 14px;
  background: color-mix(in srgb, var(--slidev-theme-primary, #10b981) 8%, transparent);
  border-left: 3px solid var(--slidev-theme-primary, #10b981);
  border-radius: 0 6px 6px 0;
  margin: 8px 0;
  cursor: pointer;
  transition: background 0.2s ease;
}

.slidev-block-ref:hover {
  background: color-mix(in srgb, var(--slidev-theme-primary, #10b981) 15%, transparent);
}

/* 代码块自动换行与无横向滚动条 */
pre,
pre code {
  white-space: pre-wrap !important;
  word-break: break-all !important;
  overflow-wrap: anywhere !important;
  overflow-x: hidden !important;
  overflow-y: auto !important;
  max-width: 100% !important;
  box-sizing: border-box !important;
}

/* 弱提示滚动条样式 */
* {
  scrollbar-width: thin;
}
html:not(.dark) * {
  scrollbar-color: rgba(0, 0, 0, 0.15) transparent;
}
html.dark * {
  scrollbar-color: rgba(255, 255, 255, 0.20) transparent;
}
*::-webkit-scrollbar {
  width: 4px;
  height: 4px;
}
*::-webkit-scrollbar-track {
  background: transparent;
}
html:not(.dark) *::-webkit-scrollbar-thumb {
  background: rgba(0, 0, 0, 0.15);
  border-radius: 2px;
}
html:not(.dark) *:hover::-webkit-scrollbar-thumb,
html:not(.dark) *::-webkit-scrollbar-thumb:hover {
  background: rgba(0, 0, 0, 0.35);
}
html.dark *::-webkit-scrollbar-thumb {
  background: rgba(255, 255, 255, 0.20);
  border-radius: 2px;
}
html.dark *:hover::-webkit-scrollbar-thumb,
html.dark *::-webkit-scrollbar-thumb:hover {
  background: rgba(255, 255, 255, 0.45);
}

/* 多媒体（GIF动图、静态图片、MP4视频）最大化自适应且不超出视口：顶部对齐，横向居中 */
.slidev-layout img,
.slidev-layout video {
  max-width: 100% !important;
  max-height: 100% !important;
  width: auto;
  height: auto;
  object-fit: contain !important;
}
.three-cols-header video,
.two-cols-header video,
.grid-cols-3 video,
.grid-cols-2 video,
.col-1 video,
.col-2 video,
.col-3 video {
  width: auto !important;
  height: auto !important;
  max-width: 100% !important;
  max-height: 100% !important;
  object-fit: contain !important;
  display: block !important;
  margin: 0 auto !important;
}
.slide-list-media {
  display: flex !important;
  flex-direction: column !important;
  align-items: center !important;
  justify-content: flex-start !important;
  margin-top: 4px !important;
  margin-bottom: 4px !important;
  width: 100% !important;
  max-width: 100% !important;
  height: 100% !important;
  max-height: 100% !important;
  flex: 1 1 0% !important;
  overflow: hidden !important;
}
.slide-list-media img,
.slide-list-media video,
.slide-list-media .list-item-gif {
  width: auto !important;
  height: auto !important;
  max-width: 100% !important;
  max-height: 100% !important;
  object-fit: contain !important;
  border-radius: 6px !important;
  box-shadow: 0 3px 12px rgba(0, 0, 0, 0.14) !important;
  display: block !important;
  margin: 0 auto !important;
}
.slide-video-container {
  display: flex !important;
  flex-direction: column !important;
  justify-content: flex-start !important;
  align-items: center !important;
  width: 100% !important;
  max-height: 100% !important;
  margin: 6px 0 !important;
}
.slide-video-player {
  max-width: 100% !important;
  max-height: 100% !important;
  object-fit: contain !important;
  border-radius: 8px !important;
}

/* 两栏与多栏（超级块分栏）布局：紧凑自然行距，子列表保留圆点与层级缩进 */
.cols-header ul,
.three-cols-header ul,
.two-cols-header ul,
.two-cols ul,
.col-1 ul,
.col-2 ul,
.col-3 ul,
.col-4 ul,
.col-5 ul,
.col-6 ul,
.grid-cols-2 ul,
.grid-cols-3 ul {
  list-style: disc !important;
  list-style-type: disc !important;
  padding-left: 1.25em !important;
  margin-left: 0 !important;
  margin-top: 0 !important;
  margin-bottom: 8px !important;
  flex: 0 0 auto !important;
  height: auto !important;
  display: block !important;
}
.cols-header ol,
.three-cols-header ol,
.two-cols-header ol,
.two-cols ol,
.col-1 ol,
.col-2 ol,
.col-3 ol,
.col-4 ol,
.col-5 ol,
.col-6 ol,
.grid-cols-2 ol,
.grid-cols-3 ol {
  list-style: decimal !important;
  list-style-type: decimal !important;
  padding-left: 1.25em !important;
  margin-left: 0 !important;
  margin-top: 0 !important;
  margin-bottom: 8px !important;
  flex: 0 0 auto !important;
  height: auto !important;
  display: block !important;
}
.cols-header li,
.three-cols-header li,
.two-cols-header li,
.two-cols li,
.col-1 li,
.col-2 li,
.col-3 li,
.col-4 li,
.col-5 li,
.col-6 li,
.grid-cols-2 li,
.grid-cols-3 li {
  padding-left: 0.2em !important;
  margin-left: 0 !important;
  margin-bottom: 6px !important;
  flex: 0 0 auto !important;
  height: auto !important;
  display: list-item !important;
  line-height: 1.6 !important;
}
.cols-header ul ul,
.three-cols-header ul ul,
.two-cols-header ul ul,
.two-cols ul ul,
.col-1 ul ul,
.col-2 ul ul,
.col-3 ul ul,
.col-4 ul ul,
.col-5 ul ul,
.col-6 ul ul {
  list-style: circle !important;
  list-style-type: circle !important;
  padding-left: 1.25em !important;
  margin-top: 4px !important;
  margin-bottom: 4px !important;
}

/* 列表项内嵌标题与说明排版 */
.slide-list-item-title,
li > h1,
li > h2,
li > h3,
li > h4,
li > h5,
li > h6 {
  margin-top: 2px !important;
  margin-bottom: 6px !important;
  line-height: 1.35 !important;
  font-weight: 700 !important;
}
li > h1 { font-size: 1.6rem !important; }
li > h2 { font-size: 1.4rem !important; }
li > h3 { font-size: 1.22rem !important; }
li > h4 { font-size: 1.1rem !important; }
.slide-list-item-desc,
li > p {
  margin-top: 4px !important;
  margin-bottom: 6px !important;
  font-size: 1.05rem;
  line-height: 1.55;
  opacity: 0.92;
}
`;function Uf(e){var o;const t=[],i=/^[ \t]*<<<[ \t]+(?:@\/|\.\/|)([^\s#]+)(?:#[^\s]+)?/gm;let n;for(;(n=i.exec(e))!==null;){const s=(o=n[1])==null?void 0:o.trim();s&&!t.includes(s)&&t.push(s)}return t}class Vf{constructor(t){ye(this,"workspacePath");ye(this,"slidesFileName");ye(this,"cliBridge",new qs);const i=Rf();!(t!=null&&t.workspacePath)||t.workspacePath.includes("/data/storage/petal/siyuan-slidev/pro-workspace")?this.workspacePath=i:this.workspacePath=t.workspacePath,this.slidesFileName=(t==null?void 0:t.slidesFileName)||"slides.md"}getWorkspacePath(){return this.workspacePath}getSlidesPath(){return`${this.workspacePath}/${this.slidesFileName}`}generatePackageJson(t="default"){const i={name:"siyuan-slidev-pro-workspace",type:"module",private:!0,scripts:{dev:"slidev --port 3030",build:"slidev build"},dependencies:{"@slidev/cli":"^53.0.0","@slidev/theme-default":"latest"}};return t&&t!=="default"&&(i.dependencies[`@slidev/theme-${t}`]="latest"),JSON.stringify(i,null,2)}buildSlidesMarkdown(t){return this.cliBridge.buildStandardSlidevMarkdown(t)}async scaffold(t,i){const n=this.buildSlidesMarkdown(t),o=this.generatePackageJson(t.config.theme),s=this.getSlidesPath(),l=`${this.workspacePath}/package.json`,r=Ss(s),a=Ss(l),c=Uf(n);c.includes("snippets/external.ts")||c.push("snippets/external.ts");const d=new Map;for(const C of c){const T=ka[C]||`// Auto-generated snippet placeholder for SiYuan Slidev
// #region snippet
// ${C}
// #endregion snippet
`;d.set(C,T)}t.slides.some(C=>{var T;return((T=C.frontmatter)==null?void 0:T.layout)==="cols-header"})&&d.set("layouts/cols-header.vue",zf),t.slides.some(C=>{var T;return((T=C.frontmatter)==null?void 0:T.layout)==="three-cols-header"})&&d.set("layouts/three-cols-header.vue",Ff),t.slides.some(C=>{var T;return((T=C.frontmatter)==null?void 0:T.layout)==="clover"})&&d.set("layouts/clover.vue",Hf),d.set("setup/root.ts",jf),d.set("styles/index.css",Wf);const h=_t("fs"),f=_t("path");let g=!1;const k=f!=null&&f.dirname?f.dirname(r):"",S=/^[a-zA-Z]:[/\\]/.test(r)||r.includes("siyuan-slidev-pro");if(h&&f&&S)try{h.existsSync(k)||h.mkdirSync(k,{recursive:!0}),h.writeFileSync(a,o,"utf-8"),h.writeFileSync(r,n,"utf-8");for(const[C,T]of d.entries()){const B=f.join(k,C),I=f.dirname(B);h.existsSync(I)||h.mkdirSync(I,{recursive:!0}),h.existsSync(B)||h.writeFileSync(B,T,"utf-8")}g=!0}catch{}if(!g&&i)try{const C=typeof Blob<"u"?new Blob([n],{type:"text/markdown;charset=utf-8"}):Buffer.from(n,"utf-8"),T=typeof Blob<"u"?new Blob([o],{type:"application/json;charset=utf-8"}):Buffer.from(o,"utf-8");await i(l,!1,T),await i(s,!1,C);for(const[B,I]of d.entries()){const w=`${this.workspacePath}/${B}`,P=typeof Blob<"u"?new Blob([I],{type:"text/plain;charset=utf-8"}):Buffer.from(I,"utf-8");await i(w,!1,P).catch(()=>{})}return{success:!0,slidesPath:s,physicalSlidesPath:r,packageJsonPath:l}}catch(C){return{success:!1,slidesPath:s,physicalSlidesPath:r,packageJsonPath:l,error:String(C)}}return{success:!0,slidesPath:s,physicalSlidesPath:r,packageJsonPath:l}}}class Kf{constructor(){ye(this,"mode","web-sandbox");ye(this,"webBridge");ye(this,"cliBridge");ye(this,"nativeBridge");ye(this,"processManager");ye(this,"scaffolder");ye(this,"envDetector");this.webBridge=new Ys,this.cliBridge=new qs,this.nativeBridge=new Pf,this.processManager=new Nf,this.scaffolder=new Vf,this.envDetector=new Zs}getMode(){return this.mode}setMode(t){this.mode=t}async startProMode(t,i){if(!(await this.envDetector.detect()).hasNode)return{success:!1,url:"",error:"当前系统未检测到 Node.js 环境，无法拉起官方 Slidev CLI，建议继续使用内置高保真引擎"};const o=await this.scaffolder.scaffold(t,i);if(!o.success)return{success:!1,url:"",error:`初始化 Slidev 临时工作空间失败: ${o.error}`};const s=o.physicalSlidesPath||o.slidesPath,l=await this.processManager.startServer(s);return l.success?(this.mode="pro-cli",{success:!0,url:l.url,port:l.port}):{success:!1,url:"",error:l.error}}stopProMode(){this.processManager.stopServer(),this.mode="web-sandbox"}destroy(){this.webBridge.detach(),this.nativeBridge.detach(),this.processManager.stopServer()}}const qf={class:"slidev-icon",style:{fill:"none !important"},viewBox:"0 0 24 24",stroke:"currentColor","stroke-width":"1.75","stroke-linecap":"round","stroke-linejoin":"round","aria-hidden":"true"},Gf={key:0},Zf={key:1},Yf={key:2},Jf={key:3},Xf={key:4},Qf={key:5},ep={key:6},tp={key:7},ip={key:8},np={key:9},op={key:10},sp={key:11},rp={key:12},lp={key:13},ap={key:14},cp={key:15},dp={key:16},up={key:17},fp={key:18},pp={key:19},hp={key:20},mp={key:21},gp={key:22},vp={key:23},bp={key:24},yp={key:25},kp={key:26},wp={key:27},xp={key:28},Sp={key:29},_p={key:30},Cp={key:31},$p={key:32},Ip={key:33},Ep={key:34},Tp={key:35},Ap={key:36},Bp={key:37},Mp={key:38},Dp={key:39},Lp={key:40},Op={key:41},Rp={key:42},Pp={key:43},Np={key:44},zp={key:45},Fp={key:46},Hp={key:47},jp={key:48},Wp={key:49},Up={key:50},Vp={key:51},Kp={key:52},qp={key:53},Gp={key:54},Zp={key:55},Yp={key:56},Jp={key:57},Xp={key:58},Qp={key:59},eh={key:60},th={key:61},ih={key:62},nh={key:63},oh={key:64},sh={key:65},rh={key:66},lh=Ct({__name:"SlidevIcon",props:{name:{}},setup(e){return(t,i)=>(ee(),te("svg",qf,[e.name==="fullscreen"||e.name==="maximize"?(ee(),te("g",Gf,[...i[0]||(i[0]=[m("polyline",{points:"15 3 21 3 21 9"},null,-1),m("polyline",{points:"9 21 3 21 3 15"},null,-1),m("polyline",{points:"21 15 21 21 15 21"},null,-1),m("polyline",{points:"3 9 3 3 9 3"},null,-1)])])):e.name==="minimize"?(ee(),te("g",Zf,[...i[1]||(i[1]=[m("polyline",{points:"4 14 10 14 10 20"},null,-1),m("polyline",{points:"20 10 14 10 14 4"},null,-1),m("line",{x1:"14",y1:"10",x2:"21",y2:"3"},null,-1),m("line",{x1:"3",y1:"21",x2:"10",y2:"14"},null,-1)])])):e.name==="close"||e.name==="x"?(ee(),te("g",Yf,[...i[2]||(i[2]=[m("line",{x1:"18",y1:"6",x2:"6",y2:"18"},null,-1),m("line",{x1:"6",y1:"6",x2:"18",y2:"18"},null,-1)])])):e.name==="edit"?(ee(),te("g",Jf,[...i[3]||(i[3]=[m("path",{d:"M12 20h9"},null,-1),m("path",{d:"M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z"},null,-1)])])):e.name==="eye"?(ee(),te("g",Xf,[...i[4]||(i[4]=[m("path",{d:"M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"},null,-1),m("circle",{cx:"12",cy:"12",r:"3"},null,-1)])])):e.name==="external-link"||e.name==="window"?(ee(),te("g",Qf,[...i[5]||(i[5]=[m("path",{d:"M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"},null,-1),m("polyline",{points:"15 3 21 3 21 9"},null,-1),m("line",{x1:"10",y1:"14",x2:"21",y2:"3"},null,-1)])])):e.name==="arrow-left"?(ee(),te("g",ep,[...i[6]||(i[6]=[m("line",{x1:"19",y1:"12",x2:"5",y2:"12"},null,-1),m("polyline",{points:"12 19 5 12 12 5"},null,-1)])])):e.name==="arrow-right"?(ee(),te("g",tp,[...i[7]||(i[7]=[m("line",{x1:"5",y1:"12",x2:"19",y2:"12"},null,-1),m("polyline",{points:"12 5 19 12 12 19"},null,-1)])])):e.name==="plus"?(ee(),te("g",ip,[...i[8]||(i[8]=[m("line",{x1:"12",y1:"5",x2:"12",y2:"19"},null,-1),m("line",{x1:"5",y1:"12",x2:"19",y2:"12"},null,-1)])])):e.name==="minus"?(ee(),te("g",np,[...i[9]||(i[9]=[m("line",{x1:"5",y1:"12",x2:"19",y2:"12"},null,-1)])])):e.name==="split-preview"?(ee(),te("g",op,[...i[10]||(i[10]=[m("rect",{x:"3",y:"3",width:"18",height:"18",rx:"2"},null,-1),m("path",{d:"M12 3v18"},null,-1)])])):e.name==="import"?(ee(),te("g",sp,[...i[11]||(i[11]=[m("path",{d:"M4 17v2a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-2"},null,-1),m("polyline",{points:"7 9 12 14 17 9"},null,-1),m("line",{x1:"12",y1:"14",x2:"12",y2:"3"},null,-1)])])):e.name==="presenter"?(ee(),te("g",rp,[...i[12]||(i[12]=[m("path",{d:"M2 3h20"},null,-1),m("path",{d:"M21 3v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V3"},null,-1),m("path",{d:"m7 21 5-5 5 5"},null,-1)])])):e.name==="video"?(ee(),te("g",lp,[...i[13]||(i[13]=[m("polygon",{points:"23 7 16 12 23 17 23 7"},null,-1),m("rect",{x:"1",y:"5",width:"15",height:"14",rx:"2",ry:"2"},null,-1)])])):e.name==="step"?(ee(),te("g",ap,[...i[14]||(i[14]=[m("polygon",{points:"13 2 3 14 12 14 11 22 21 10 12 10 13 2"},null,-1)])])):e.name==="motion"?(ee(),te("g",cp,[...i[15]||(i[15]=[m("path",{d:"M5 12h14"},null,-1),m("path",{d:"m12 5 7 7-7 7"},null,-1),m("path",{d:"M5 6h4"},null,-1),m("path",{d:"M5 18h4"},null,-1)])])):e.name==="columns"?(ee(),te("g",dp,[...i[16]||(i[16]=[m("rect",{x:"3",y:"3",width:"7",height:"18",rx:"1"},null,-1),m("rect",{x:"14",y:"3",width:"7",height:"18",rx:"1"},null,-1)])])):e.name==="code"?(ee(),te("g",up,[...i[17]||(i[17]=[m("polyline",{points:"16 18 22 12 16 6"},null,-1),m("polyline",{points:"8 6 2 12 8 18"},null,-1)])])):e.name==="insert-above"?(ee(),te("g",fp,[...i[18]||(i[18]=[m("line",{x1:"12",y1:"5",x2:"12",y2:"13"},null,-1),m("line",{x1:"8",y1:"9",x2:"16",y2:"9"},null,-1),m("path",{d:"M4 19h16","stroke-dasharray":"2 2"},null,-1)])])):e.name==="insert-below"?(ee(),te("g",pp,[...i[19]||(i[19]=[m("path",{d:"M4 5h16","stroke-dasharray":"2 2"},null,-1),m("line",{x1:"12",y1:"11",x2:"12",y2:"19"},null,-1),m("line",{x1:"8",y1:"15",x2:"16",y2:"15"},null,-1)])])):e.name==="broom"?(ee(),te("g",hp,[...i[20]||(i[20]=[m("path",{d:"m18 15-6-6"},null,-1),m("path",{d:"M4 20h16"},null,-1),m("path",{d:"M6 14l8-8a2.8 2.8 0 0 1 4 4l-8 8H6v-4z"},null,-1)])])):e.name==="trash"?(ee(),te("g",mp,[...i[21]||(i[21]=[m("path",{d:"M3 6h18"},null,-1),m("path",{d:"M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"},null,-1),m("path",{d:"M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"},null,-1)])])):e.name==="ai"||e.name==="sparkles"?(ee(),te("g",gp,[...i[22]||(i[22]=[m("path",{d:"m12 3-1.9 5.8a2 2 0 0 1-1.3 1.3L3 12l5.8 1.9a2 2 0 0 1 1.3 1.3L12 21l1.9-5.8a2 2 0 0 1 1.3-1.3L21 12l-5.8-1.9a2 2 0 0 1-1.3-1.3L12 3z"},null,-1)])])):e.name==="palette"?(ee(),te("g",vp,[...i[23]||(i[23]=[gt('<circle cx="13.5" cy="6.5" r=".5" fill="currentColor" data-v-57969535></circle><circle cx="17.5" cy="10.5" r=".5" fill="currentColor" data-v-57969535></circle><circle cx="8.5" cy="7.5" r=".5" fill="currentColor" data-v-57969535></circle><circle cx="6.5" cy="12.5" r=".5" fill="currentColor" data-v-57969535></circle><path d="M12 2C6.5 2 2 6.5 2 12s4.5 10 10 10c.9 0 1.5-.7 1.5-1.5 0-.4-.2-.8-.4-1.1-.3-.4-.4-.8-.4-1.4 0-1.1.9-2 2-2h2.3c3.9 0 7-3.1 7-7 0-5-4.5-9-10-9z" data-v-57969535></path>',5)])])):e.name==="ratio"?(ee(),te("g",bp,[...i[24]||(i[24]=[m("rect",{x:"2",y:"5",width:"20",height:"14",rx:"2"},null,-1),m("line",{x1:"2",y1:"10",x2:"22",y2:"10","stroke-dasharray":"2 2"},null,-1)])])):e.name==="transition"?(ee(),te("g",yp,[...i[25]||(i[25]=[m("path",{d:"M8 3 4 7l4 4"},null,-1),m("path",{d:"M4 7h16"},null,-1),m("path",{d:"m16 21 4-4-4-4"},null,-1),m("path",{d:"M20 17H4"},null,-1)])])):e.name==="export-html"?(ee(),te("g",kp,[...i[26]||(i[26]=[m("polyline",{points:"16 16 12 12 8 16"},null,-1),m("line",{x1:"12",y1:"12",x2:"12",y2:"21"},null,-1),m("path",{d:"M20.4 16.3A5 5 0 0 0 18 7h-1.3A8 8 0 0 0 4 12.8a5 5 0 0 0 1.5 9.2"},null,-1)])])):e.name==="export-pdf"?(ee(),te("g",wp,[...i[27]||(i[27]=[m("polyline",{points:"6 9 6 2 18 2 18 9"},null,-1),m("path",{d:"M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"},null,-1),m("rect",{x:"6",y:"14",width:"12",height:"8"},null,-1)])])):e.name==="pin"?(ee(),te("g",xp,[...i[28]||(i[28]=[m("line",{x1:"12",y1:"17",x2:"12",y2:"22"},null,-1),m("path",{d:"M5 17h14v-2l-2-2V5l1-1V2H6v2l1 1v8l-2 2v2z"},null,-1)])])):e.name==="refresh"?(ee(),te("g",Sp,[...i[29]||(i[29]=[m("path",{d:"M3 12a9 9 0 0 1 9-9 9.75 9.75 0 0 1 6.74 2.74L21 8"},null,-1),m("path",{d:"M21 3v5h-5"},null,-1),m("path",{d:"M21 12a9 9 0 0 1-9 9 9.75 9.75 0 0 1-6.74-2.74L3 16"},null,-1),m("path",{d:"M8 16H3v5"},null,-1)])])):e.name==="alert"||e.name==="warning"?(ee(),te("g",_p,[...i[30]||(i[30]=[m("path",{d:"M10.29 3.86 1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"},null,-1),m("line",{x1:"12",y1:"9",x2:"12",y2:"13"},null,-1),m("line",{x1:"12",y1:"17",x2:"12.01",y2:"17"},null,-1)])])):e.name==="outline"?(ee(),te("g",Cp,[...i[31]||(i[31]=[m("line",{x1:"3",y1:"6",x2:"21",y2:"6"},null,-1),m("line",{x1:"3",y1:"12",x2:"21",y2:"12"},null,-1),m("line",{x1:"3",y1:"18",x2:"21",y2:"18"},null,-1)])])):e.name==="chevron-left"?(ee(),te("g",$p,[...i[32]||(i[32]=[m("polyline",{points:"15 18 9 12 15 6"},null,-1)])])):e.name==="chevron-right"?(ee(),te("g",Ip,[...i[33]||(i[33]=[m("polyline",{points:"9 18 15 12 9 6"},null,-1)])])):e.name==="copy"?(ee(),te("g",Ep,[...i[34]||(i[34]=[m("rect",{x:"9",y:"9",width:"13",height:"13",rx:"2",ry:"2"},null,-1),m("path",{d:"M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"},null,-1)])])):e.name==="image"?(ee(),te("g",Tp,[...i[35]||(i[35]=[m("rect",{x:"3",y:"3",width:"18",height:"18",rx:"2",ry:"2"},null,-1),m("circle",{cx:"8.5",cy:"8.5",r:"1.5"},null,-1),m("polyline",{points:"21 15 16 10 5 21"},null,-1)])])):e.name==="search"?(ee(),te("g",Ap,[...i[36]||(i[36]=[m("circle",{cx:"11",cy:"11",r:"7"},null,-1),m("line",{x1:"21",y1:"21",x2:"16.65",y2:"16.65"},null,-1)])])):e.name==="settings"||e.name==="gear"?(ee(),te("g",Bp,[...i[37]||(i[37]=[m("circle",{cx:"12",cy:"12",r:"3"},null,-1),m("path",{d:"M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 1 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 1 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 1 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 1 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"},null,-1)])])):e.name==="notes"||e.name==="file-text"?(ee(),te("g",Mp,[...i[38]||(i[38]=[gt('<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" data-v-57969535></path><polyline points="14 2 14 8 20 8" data-v-57969535></polyline><line x1="16" y1="13" x2="8" y2="13" data-v-57969535></line><line x1="16" y1="17" x2="8" y2="17" data-v-57969535></line><line x1="10" y1="9" x2="8" y2="9" data-v-57969535></line>',5)])])):e.name==="focus"||e.name==="target"?(ee(),te("g",Dp,[...i[39]||(i[39]=[m("circle",{cx:"12",cy:"12",r:"3",fill:"currentColor"},null,-1),m("path",{d:"M12 2v4M12 18v4M2 12h4M18 12h4",stroke:"currentColor","stroke-width":"2","stroke-linecap":"round"},null,-1),m("circle",{cx:"12",cy:"12",r:"7",fill:"none",stroke:"currentColor","stroke-width":"1.8"},null,-1)])])):e.name==="layout-cover"||e.name==="cover"?(ee(),te("g",Lp,[...i[40]||(i[40]=[m("rect",{x:"2",y:"4",width:"20",height:"16",rx:"2"},null,-1),m("line",{x1:"9",y1:"8",x2:"15",y2:"8"},null,-1),m("line",{x1:"5.5",y1:"11.5",x2:"18.5",y2:"11.5"},null,-1),m("line",{x1:"7.5",y1:"15",x2:"16.5",y2:"15"},null,-1)])])):e.name==="layout-default"||e.name==="default"?(ee(),te("g",Op,[...i[41]||(i[41]=[gt('<rect x="2" y="4" width="20" height="16" rx="2" data-v-57969535></rect><line x1="5" y1="8" x2="11.5" y2="8" data-v-57969535></line><line x1="5" y1="11.5" x2="19" y2="11.5" data-v-57969535></line><line x1="5" y1="14.5" x2="19" y2="14.5" data-v-57969535></line><line x1="5" y1="17.5" x2="13.5" y2="17.5" data-v-57969535></line>',5)])])):e.name==="layout-two-cols"||e.name==="two-cols"?(ee(),te("g",Rp,[...i[42]||(i[42]=[gt('<rect x="2" y="4" width="20" height="16" rx="2" data-v-57969535></rect><line x1="12" y1="4" x2="12" y2="20" stroke-dasharray="2 1.5" data-v-57969535></line><line x1="5" y1="8" x2="9.5" y2="8" data-v-57969535></line><line x1="5" y1="11.5" x2="9.5" y2="11.5" data-v-57969535></line><line x1="5" y1="15" x2="8" y2="15" data-v-57969535></line><line x1="14.5" y1="8" x2="19" y2="8" data-v-57969535></line><line x1="14.5" y1="11.5" x2="19" y2="11.5" data-v-57969535></line><line x1="14.5" y1="15" x2="17.5" y2="15" data-v-57969535></line>',8)])])):e.name==="layout-two-cols-header"||e.name==="two-cols-header"?(ee(),te("g",Pp,[...i[43]||(i[43]=[gt('<rect x="2" y="4" width="20" height="16" rx="2" data-v-57969535></rect><line x1="5" y1="7.5" x2="13" y2="7.5" data-v-57969535></line><line x1="12" y1="10.5" x2="12" y2="18.5" stroke-dasharray="1.5 1.5" data-v-57969535></line><line x1="5" y1="12" x2="9.5" y2="12" data-v-57969535></line><line x1="5" y1="15.5" x2="8.5" y2="15.5" data-v-57969535></line><line x1="14.5" y1="12" x2="19" y2="12" data-v-57969535></line><line x1="14.5" y1="15.5" x2="18" y2="15.5" data-v-57969535></line>',7)])])):e.name==="layout-cols-header"||e.name==="cols-header"||e.name==="layout-three-cols-header"||e.name==="three-cols-header"?(ee(),te("g",Np,[...i[44]||(i[44]=[gt('<rect x="2" y="4" width="20" height="16" rx="2" data-v-57969535></rect><line x1="5" y1="7.5" x2="13" y2="7.5" data-v-57969535></line><line x1="9.3" y1="10.5" x2="9.3" y2="18.5" stroke-dasharray="1.5 1.5" data-v-57969535></line><line x1="14.7" y1="10.5" x2="14.7" y2="18.5" stroke-dasharray="1.5 1.5" data-v-57969535></line><line x1="4.5" y1="12" x2="7.5" y2="12" data-v-57969535></line><line x1="4.5" y1="15.5" x2="7" y2="15.5" data-v-57969535></line><line x1="10.5" y1="12" x2="13.5" y2="12" data-v-57969535></line><line x1="10.5" y1="15.5" x2="13.5" y2="15.5" data-v-57969535></line><line x1="16" y1="12" x2="19.5" y2="12" data-v-57969535></line><line x1="16" y1="15.5" x2="18.5" y2="15.5" data-v-57969535></line>',10)])])):e.name==="layout-clover"||e.name==="clover"?(ee(),te("g",zp,[...i[45]||(i[45]=[gt('<rect x="2" y="4" width="20" height="16" rx="2" data-v-57969535></rect><line x1="5" y1="7" x2="13" y2="7" data-v-57969535></line><line x1="4.5" y1="13.5" x2="19.5" y2="13.5" stroke-dasharray="1.5 1.5" data-v-57969535></line><line x1="12" y1="9" x2="12" y2="18.5" stroke-dasharray="1.5 1.5" data-v-57969535></line><line x1="5" y1="11" x2="9.5" y2="11" data-v-57969535></line><line x1="14.5" y1="11" x2="19" y2="11" data-v-57969535></line><line x1="5" y1="16" x2="9.5" y2="16" data-v-57969535></line><line x1="14.5" y1="16" x2="19" y2="16" data-v-57969535></line>',8)])])):e.name==="layout-image-right"||e.name==="image-right"?(ee(),te("g",Fp,[...i[46]||(i[46]=[gt('<rect x="2" y="4" width="20" height="16" rx="2" data-v-57969535></rect><line x1="12" y1="4" x2="12" y2="20" data-v-57969535></line><line x1="4.5" y1="8" x2="9.5" y2="8" data-v-57969535></line><line x1="4.5" y1="11.5" x2="10" y2="11.5" data-v-57969535></line><line x1="4.5" y1="14.5" x2="8" y2="14.5" data-v-57969535></line><circle cx="15.5" cy="8.5" r="1.2" data-v-57969535></circle><polyline points="13 17 15.5 13 18 16 19.5 14" data-v-57969535></polyline>',7)])])):e.name==="layout-image-left"||e.name==="image-left"?(ee(),te("g",Hp,[...i[47]||(i[47]=[gt('<rect x="2" y="4" width="20" height="16" rx="2" data-v-57969535></rect><line x1="12" y1="4" x2="12" y2="20" data-v-57969535></line><circle cx="6" cy="8.5" r="1.2" data-v-57969535></circle><polyline points="3.5 17 6 13 8.5 16 10 14" data-v-57969535></polyline><line x1="14.5" y1="8" x2="19.5" y2="8" data-v-57969535></line><line x1="14.5" y1="11.5" x2="20" y2="11.5" data-v-57969535></line><line x1="14.5" y1="14.5" x2="18" y2="14.5" data-v-57969535></line>',7)])])):e.name==="layout-center"||e.name==="center"?(ee(),te("g",jp,[...i[48]||(i[48]=[m("rect",{x:"2",y:"4",width:"20",height:"16",rx:"2"},null,-1),m("line",{x1:"6.5",y1:"9",x2:"17.5",y2:"9"},null,-1),m("line",{x1:"5",y1:"12",x2:"19",y2:"12"},null,-1),m("line",{x1:"8",y1:"15",x2:"16",y2:"15"},null,-1)])])):e.name==="layout-fact"||e.name==="fact"?(ee(),te("g",Wp,[...i[49]||(i[49]=[gt('<rect x="2" y="4" width="20" height="16" rx="2" data-v-57969535></rect><circle cx="8" cy="9" r="1.5" data-v-57969535></circle><line x1="14" y1="8" x2="9" y2="14" data-v-57969535></line><circle cx="15" cy="13" r="1.5" data-v-57969535></circle><line x1="6.5" y1="17" x2="17.5" y2="17" data-v-57969535></line>',5)])])):e.name==="layout-intro"||e.name==="intro"?(ee(),te("g",Up,[...i[50]||(i[50]=[gt('<rect x="2" y="4" width="20" height="16" rx="2" data-v-57969535></rect><circle cx="7.5" cy="9.5" r="2" data-v-57969535></circle><path d="M4.5 16.5c0-1.8 1.3-3 3-3s3 1.2 3 3" data-v-57969535></path><line x1="13" y1="9" x2="18.5" y2="9" data-v-57969535></line><line x1="13" y1="12.5" x2="19.5" y2="12.5" data-v-57969535></line><line x1="13" y1="15.5" x2="17" y2="15.5" data-v-57969535></line>',6)])])):e.name==="layout-quote"||e.name==="quote"?(ee(),te("g",Vp,[...i[51]||(i[51]=[gt('<rect x="2" y="4" width="20" height="16" rx="2" data-v-57969535></rect><path d="M6 7.5h2v2H6.5c0 1.2-.4 2-1.5 2.5" data-v-57969535></path><path d="M9.5 7.5h2v2H10c0 1.2-.4 2-1.5 2.5" data-v-57969535></path><line x1="6" y1="13.5" x2="18" y2="13.5" data-v-57969535></line><line x1="12.5" y1="16.5" x2="17.5" y2="16.5" data-v-57969535></line>',5)])])):e.name==="desktop"||e.name==="monitor"?(ee(),te("g",Kp,[...i[52]||(i[52]=[m("rect",{x:"2",y:"3",width:"20",height:"14",rx:"2"},null,-1),m("line",{x1:"8",y1:"21",x2:"16",y2:"21"},null,-1),m("line",{x1:"12",y1:"17",x2:"12",y2:"21"},null,-1)])])):e.name==="mobile"||e.name==="smartphone"||e.name==="phone"?(ee(),te("g",qp,[...i[53]||(i[53]=[m("rect",{x:"5",y:"2",width:"14",height:"20",rx:"2",ry:"2"},null,-1),m("line",{x1:"12",y1:"18",x2:"12.01",y2:"18","stroke-width":"2","stroke-linecap":"round"},null,-1)])])):e.name==="type"||e.name==="heading"?(ee(),te("g",Gp,[...i[54]||(i[54]=[m("polyline",{points:"4 7 4 4 20 4 20 7"},null,-1),m("line",{x1:"9",y1:"20",x2:"15",y2:"20"},null,-1),m("line",{x1:"12",y1:"4",x2:"12",y2:"20"},null,-1)])])):e.name==="reset"||e.name==="undo"?(ee(),te("g",Zp,[...i[55]||(i[55]=[m("path",{d:"M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8"},null,-1),m("polyline",{points:"3 3 3 8 8 8"},null,-1)])])):e.name==="repeat"||e.name==="loop"?(ee(),te("g",Yp,[...i[56]||(i[56]=[m("path",{d:"m17 1 4 4-4 4"},null,-1),m("path",{d:"M3 11V9a4 4 0 0 1 4-4h14"},null,-1),m("path",{d:"m7 23-4-4 4-4"},null,-1),m("path",{d:"M21 13v2a4 4 0 0 1-4 4H3"},null,-1)])])):e.name==="volume-x"||e.name==="mute"?(ee(),te("g",Jp,[...i[57]||(i[57]=[m("polygon",{points:"11 5 6 9 2 9 2 15 6 15 11 19 11 5"},null,-1),m("line",{x1:"22",y1:"9",x2:"16",y2:"15"},null,-1),m("line",{x1:"16",y1:"9",x2:"22",y2:"15"},null,-1)])])):e.name==="sliders"||e.name==="controls"?(ee(),te("g",Xp,[...i[58]||(i[58]=[gt('<line x1="4" y1="21" x2="4" y2="14" data-v-57969535></line><line x1="4" y1="10" x2="4" y2="3" data-v-57969535></line><line x1="12" y1="21" x2="12" y2="12" data-v-57969535></line><line x1="12" y1="8" x2="12" y2="3" data-v-57969535></line><line x1="20" y1="21" x2="20" y2="16" data-v-57969535></line><line x1="20" y1="12" x2="20" y2="3" data-v-57969535></line><line x1="1" y1="14" x2="7" y2="14" data-v-57969535></line><line x1="9" y1="8" x2="15" y2="8" data-v-57969535></line><line x1="17" y1="16" x2="23" y2="16" data-v-57969535></line>',9)])])):e.name==="package"||e.name==="zip"||e.name==="archive"?(ee(),te("g",Qp,[...i[59]||(i[59]=[m("line",{x1:"16.5",y1:"9.4",x2:"7.5",y2:"4.21"},null,-1),m("path",{d:"M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"},null,-1),m("polyline",{points:"3.27 6.96 12 12.01 20.73 6.96"},null,-1),m("line",{x1:"12",y1:"22.08",x2:"12",y2:"12"},null,-1)])])):e.name==="folder"?(ee(),te("g",eh,[...i[60]||(i[60]=[m("path",{d:"M4 20h16a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2h-7.93a2 2 0 0 1-1.66-.9l-.82-1.2A2 2 0 0 0 7.93 3H4a2 2 0 0 0-2 2v13c0 1.1.9 2 2 2Z"},null,-1)])])):e.name==="rocket"?(ee(),te("g",th,[...i[61]||(i[61]=[m("path",{d:"M4.5 16.5c-1.5 1.26-2 5-2 5s3.74-.5 5-2c.71-.84.7-2.13-.09-2.91a2.18 2.18 0 0 0-2.91-.09z"},null,-1),m("path",{d:"m12 15-3-3a22 22 0 0 1 2-3.95A12.88 12.88 0 0 1 22 2c0 2.72-.78 7.5-6 11a22.35 22.35 0 0 1-4 2z"},null,-1),m("path",{d:"M9 12H4s.55-3.03 2-4c1.62-1.08 5 0 5 0"},null,-1),m("path",{d:"M12 15v5s3.03-.55 4-2c1.08-1.62 0-5 0-5"},null,-1)])])):e.name==="wand"||e.name==="magic"?(ee(),te("g",ih,[...i[62]||(i[62]=[m("path",{d:"m19 2 2 2-6 6-2-2Z"},null,-1),m("path",{d:"m13 8 2 2"},null,-1),m("path",{d:"m3 21 9-9"},null,-1)])])):e.name==="image-left"?(ee(),te("g",nh,[...i[63]||(i[63]=[gt('<rect x="2" y="4" width="20" height="16" rx="2" data-v-57969535></rect><rect x="4" y="6" width="6" height="12" rx="1" data-v-57969535></rect><line x1="13" y1="8" x2="19" y2="8" data-v-57969535></line><line x1="13" y1="12" x2="19" y2="12" data-v-57969535></line><line x1="13" y1="16" x2="17" y2="16" data-v-57969535></line>',5)])])):e.name==="image-right"?(ee(),te("g",oh,[...i[64]||(i[64]=[gt('<rect x="2" y="4" width="20" height="16" rx="2" data-v-57969535></rect><rect x="14" y="6" width="6" height="12" rx="1" data-v-57969535></rect><line x1="5" y1="8" x2="11" y2="8" data-v-57969535></line><line x1="5" y1="12" x2="11" y2="12" data-v-57969535></line><line x1="5" y1="16" x2="9" y2="16" data-v-57969535></line>',5)])])):e.name==="help"||e.name==="question"||e.name==="info"?(ee(),te("g",sh,[...i[65]||(i[65]=[m("circle",{cx:"12",cy:"12",r:"10"},null,-1),m("path",{d:"M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"},null,-1),m("line",{x1:"12",y1:"17",x2:"12.01",y2:"17"},null,-1)])])):(ee(),te("g",rh,[...i[66]||(i[66]=[m("rect",{x:"2",y:"3",width:"20",height:"14",rx:"2"},null,-1),m("line",{x1:"8",y1:"21",x2:"16",y2:"21"},null,-1),m("line",{x1:"12",y1:"17",x2:"12",y2:"21"},null,-1)])]))]))}}),zt=(e,t)=>{const i=e.__vccOpts||e;for(const[n,o]of t)i[n]=o;return i},ce=zt(lh,[["__scopeId","data-v-57969535"]]);function et(e,t){var o;if(typeof document>"u"||!e)return;const i=(o=globalThis.CSS)!=null&&o.escape?globalThis.CSS.escape(e):e.replace(/"/g,'\\"'),n=document.querySelectorAll(`[data-node-id="${i}"]`);!n||n.length===0||n.forEach(s=>{for(const[l,r]of Object.entries(t))r!=null&&r!==""?s.setAttribute(l,String(r)):s.removeAttribute(l)})}function ah(e){if(typeof document>"u")return;const t=`.protyle-wysiwyg [${ue}], .protyle-wysiwyg [${qe}], .protyle-wysiwyg [custom-slidev-layout], .protyle-wysiwyg [custom-slidev-role]`,i=document.querySelectorAll(t);!i||i.length===0||i.forEach(n=>{const o=n.getAttribute("data-node-id");if(!o){n.removeAttribute(ue),n.removeAttribute("custom-slidev-layout"),n.removeAttribute(qe),n.removeAttribute("custom-slidev-role");return}const s=e.get(o),l=(s==null?void 0:s[ue])||(s==null?void 0:s["custom-slidev-layout"])||"",r=n.getAttribute(ue)||n.getAttribute("custom-slidev-layout");r&&r!==l&&(l?n.setAttribute(ue,l):(n.removeAttribute(ue),n.removeAttribute("custom-slidev-layout")));const a=(s==null?void 0:s[qe])||(s==null?void 0:s["custom-slidev-role"])||"",c=n.getAttribute(qe)||n.getAttribute("custom-slidev-role");c&&c!==a&&(a?n.setAttribute(qe,a):(n.removeAttribute(qe),n.removeAttribute("custom-slidev-role")))})}const ch={class:"spm-layout-picker"},dh={class:"spm-layout-picker__grid"},uh=["title","onClick"],fh={class:"spm-layout-icon"},ph={class:"spm-layout-label"},hh=Ct({__name:"LayoutPicker",props:{modelValue:{}},emits:["update:modelValue","change"],setup(e,{emit:t}){const i=e,n=t,o=[{name:"cover",label:"封面",desc:"大标题与副标题封面页"},{name:"default",label:"标准",desc:"标题在上方，内容在下方"},{name:"two-cols",label:"双栏",desc:"左右双栏对比展示"},{name:"cols-header",label:"表头多栏",desc:"顶部通栏标题，下方自适应 2~N 栏"},{name:"clover",label:"四叶草",desc:"4 项超级块 2x2 田字型四象限卡片布局"},{name:"image-right",label:"图右",desc:"左侧为内容，右侧全屏背景图"},{name:"image-left",label:"图左",desc:"左侧全屏背景图，右侧为内容"},{name:"center",label:"居中",desc:"内容全屏垂直水平居中"},{name:"fact",label:"大字报",desc:"核心数据或指标突出展示"},{name:"intro",label:"介绍",desc:"演讲者自我介绍或章节导览"},{name:"quote",label:"引言",desc:"名人名言与强调段落"}];function s(r){return i.modelValue===r||r==="cols-header"&&(i.modelValue==="two-cols-header"||i.modelValue==="three-cols-header")}function l(r){n("update:modelValue",r),n("change",r)}return(r,a)=>(ee(),te("div",ch,[a[0]||(a[0]=m("div",{class:"spm-layout-picker__header"},"选择页面版式",-1)),m("div",dh,[(ee(),te(Ue,null,kt(o,c=>m("div",{key:c.name,class:_e(["spm-layout-item",{active:s(c.name)}]),title:c.desc,onClick:d=>l(c.name)},[m("div",fh,[re(ce,{name:"layout-"+c.name},null,8,["name"])]),m("span",ph,we(c.label),1)],10,uh)),64))])]))}}),wa=zt(hh,[["__scopeId","data-v-1964d02c"]]),mh={key:0,class:"spm-transition-selector__header"},gh={class:"spm-transition-list"},vh=["onClick"],bh={class:"spm-transition-meta"},yh={class:"spm-transition-label"},kh={class:"spm-transition-name"},wh={class:"spm-transition-preview-box"},xh=Ct({__name:"TransitionSelector",props:{modelValue:{},hideHeader:{type:Boolean},title:{}},emits:["update:modelValue","change"],setup(e,{emit:t}){const i=t,n=[{name:"slide-left",label:"向左滑入",desc:"向左滑入 (slide-left)：页面从右侧向左平滑推入，最通用标准的横向幻灯片动效"},{name:"slide-right",label:"向右滑入",desc:"向右滑入 (slide-right)：页面从左侧向右平滑推入，适合倒序回退或逆向章节叙述"},{name:"slide-up",label:"向上推入",desc:"向上推入 (slide-up)：页面从底部向上平滑推入，适合纵向展开或纵深层级展示"},{name:"fade",label:"淡入淡出",desc:"淡入淡出 (fade)：透明度平滑渐变过度，典雅柔和，适合学术长篇与沉浸叙事"},{name:"zoom",label:"缩放进入",desc:"缩放进入 (zoom)：页面由中心向外平滑放大，富有动感冲击力，适合聚焦重点"}];function o(s){i("update:modelValue",s),i("change",s)}return(s,l)=>(ee(),te("div",{class:_e(["spm-transition-selector",{"spm-transition-selector--no-header":e.hideHeader}])},[e.hideHeader?Oe("",!0):(ee(),te("div",mh,we(e.title||"转场动效"),1)),m("div",gh,[(ee(),te(Ue,null,kt(n,r=>m("div",{key:r.name,class:_e(["spm-transition-item",{active:e.modelValue===r.name}]),onClick:a=>o(r.name)},[m("div",bh,[m("span",yh,we(r.label),1),m("span",kh,"("+we(r.name)+")",1)]),m("div",wh,[m("div",{class:_e(["spm-anim-cube","anim-"+r.name])},null,2)])],10,vh)),64))])],2))}}),Js=zt(xh,[["__scopeId","data-v-8597e99e"]]),Sh={class:"spm-divider-popover"},_h={class:"spm-divider-popover__title"},Ch={class:"spm-form-item"},$h={class:"spm-popover-footer"},Ih={class:"spm-save-hint"},Eh=Ct({__name:"QuickDividerPopover",props:{blockId:{},initialAttrs:{}},emits:["close","updated"],setup(e,{emit:t}){var b,u,h;const i=e,n=t,o=fe(((b=i.initialAttrs)==null?void 0:b[ue])||"default"),s=fe(((u=i.initialAttrs)==null?void 0:u[tt])||"slide-left"),l=fe(((h=i.initialAttrs)==null?void 0:h[je])||""),r=fe("");Di(()=>i.initialAttrs,f=>{o.value=(f==null?void 0:f[ue])||"default",s.value=(f==null?void 0:f[tt])||"slide-left",l.value=(f==null?void 0:f[je])||""},{deep:!0});async function a(f,g){if(i.blockId){r.value="正在同步...",Be.setBlockAttrOverride(i.blockId,{[f]:g}),et(i.blockId,{[f]:g});try{await Ne(i.blockId,{[f]:g}),r.value="已同步至块属性",n("updated",{[f]:g}),setTimeout(()=>{r.value=""},1500)}catch{r.value="同步失败"}}}function c(f){a(ue,f)}function d(f){a(tt,f)}function p(){a(je,l.value.trim())}return(f,g)=>(ee(),te("div",Sh,[m("div",_h,[g[4]||(g[4]=m("span",null,"幻灯片页面设置",-1)),m("button",{class:"spm-close-btn",onClick:g[0]||(g[0]=k=>n("close"))},"✕")]),re(wa,{modelValue:o.value,"onUpdate:modelValue":g[1]||(g[1]=k=>o.value=k),onChange:c},null,8,["modelValue"]),re(Js,{modelValue:s.value,"onUpdate:modelValue":g[2]||(g[2]=k=>s.value=k),onChange:d},null,8,["modelValue"]),m("div",Ch,[g[5]||(g[5]=m("label",{class:"spm-form-label"},"页面背景",-1)),Tt(m("input",{"onUpdate:modelValue":g[3]||(g[3]=k=>l.value=k),class:"spm-input",placeholder:"assets/bg.jpg 或颜色值 (#1e1e24)",onBlur:p},null,544),[[So,l.value]])]),m("div",$h,[m("span",Ih,we(r.value),1)])]))}}),Th=zt(Eh,[["__scopeId","data-v-e4871368"]]),Ah={class:"spm-slide-inspector"},Bh={class:"spm-inspector-header"},Mh={class:"spm-inspector-list"},Dh=["onClick"],Lh={class:"spm-card-top"},Oh={class:"spm-card-badge"},Rh={class:"spm-card-layout"},Ph=["onClick"],Nh={class:"spm-card-preview"},zh={key:0,class:"spm-card-notes",title:"演讲备忘录"},Fh={class:"spm-inspector-modal-content"},Hh=Ct({__name:"SlideInspector",props:{slides:{},currentActivePage:{}},emits:["navigate","refresh"],setup(e,{emit:t}){const i=t,n=fe(null);function o(c){n.value=c}function s(c){const d={};return c.frontmatter.layout&&(d[ue]=c.frontmatter.layout),c.frontmatter.transition&&(d[tt]=c.frontmatter.transition),c.frontmatter.background&&(d[je]=c.frontmatter.background),c.notes&&(d[Wi]=c.notes),d}function l(c){n.value&&(c[ue]&&(n.value.frontmatter.layout=c[ue]),c[tt]&&(n.value.frontmatter.transition=c[tt]),c[je]&&(n.value.frontmatter.background=c[je]),c[Wi]&&(n.value.notes=c[Wi]),i("refresh"))}function r(c){i("navigate",c)}function a(c){if(!c.blocks||c.blocks.length===0)return"(空白页)";const d=c.blocks[0],p=d.content||d.rawMarkdown||"";return p.slice(0,40)+(p.length>40?"...":"")}return(c,d)=>(ee(),te("div",Ah,[m("div",Bh,[m("span",null,"幻灯片大纲 ("+we(e.slides.length)+" 页)",1)]),m("div",Mh,[(ee(!0),te(Ue,null,kt(e.slides,p=>(ee(),te("div",{key:p.pageIndex,class:_e(["spm-card",{active:e.currentActivePage===p.pageIndex}]),onClick:b=>r(p.pageIndex)},[m("div",Lh,[m("span",Oh,"P"+we(p.pageIndex),1),m("span",Rh,we(p.frontmatter.layout||"default"),1),m("button",{class:"spm-card-btn-edit",title:"配置此页版式与属性",onClick:Mt(b=>o(p),["stop"])},[re(ce,{name:"settings"})],8,Ph)]),m("div",Nh,we(a(p)),1),p.notes?(ee(),te("div",zh,[re(ce,{name:"notes",style:{"font-size":"11px","margin-right":"3px"}}),m("span",null,we(p.notes),1)])):Oe("",!0)],10,Dh))),128))]),n.value?(ee(),te("div",{key:0,class:"spm-inspector-modal-mask",onClick:d[1]||(d[1]=Mt(p=>n.value=null,["self"]))},[m("div",Fh,[re(Th,{"block-id":n.value.startBlockId,"initial-attrs":s(n.value),onClose:d[0]||(d[0]=p=>n.value=null),onUpdated:l},null,8,["block-id","initial-attrs"])])])):Oe("",!0)]))}}),jh=zt(Hh,[["__scopeId","data-v-68b25edd"]]),Wh={class:"spm-immersion-header"},Uh={class:"spm-immersion-header__left"},Vh={class:"spm-immersion-title"},Kh={class:"spm-immersion-header__center"},qh={class:"spm-immersion-header__actions"},Gh=["aria-label"],Zh={class:"spm-immersion-body"},Yh=Ct({__name:"ImmersionDrawerContainer",props:{visible:{type:Boolean,default:!1},isMaximized:{type:Boolean,default:!1},title:{default:"速览"},closeOnClickMask:{type:Boolean,default:!0}},emits:["update:visible","update:isMaximized","close","toggle-maximize"],setup(e,{emit:t}){const i=e,n=t;function o(){n("update:visible",!1),n("close")}function s(){i.closeOnClickMask&&o()}function l(){n("update:isMaximized",!i.isMaximized),n("toggle-maximize")}function r(a){(a.key===" "||a.key==="ArrowLeft"||a.key==="ArrowRight"||a.key==="PageUp"||a.key==="PageDown")&&a.stopPropagation(),a.key==="Escape"&&(a.preventDefault(),a.stopPropagation(),o())}return(a,c)=>Tt((ee(),te("div",{class:_e(["spm-immersion-container",{"is-maximized":e.isMaximized}]),onKeydown:Mt(r,["stop"])},[m("div",{class:"spm-immersion-mask",onClick:s}),m("div",{class:_e(["spm-immersion-drawer",{"is-maximized":e.isMaximized}])},[m("div",Wh,[m("div",Uh,[Zn(a.$slots,"header-left",{},()=>[m("span",Vh,we(e.title),1)])]),m("div",Kh,[Zn(a.$slots,"header-center",{},void 0)]),m("div",qh,[Zn(a.$slots,"header-actions",{},void 0),m("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":e.isMaximized?"还原抽屉宽度 (70%)":"最大化填满视口 (100%)",onClick:l},[re(ce,{name:e.isMaximized?"minimize":"maximize"},null,8,["name"])],8,Gh),m("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"关闭速览 (ESC)",onClick:o},[re(ce,{name:"close"})])])]),m("div",Zh,[Zn(a.$slots,"default",{},void 0)])],2)],34)),[[ys,e.visible]])}}),Jh=zt(Yh,[["__scopeId","data-v-3f1665db"]]),Xh={class:"spm-protyle-drawer"},Qh={class:"spm-protyle-drawer__subbar"},em={class:"spm-protyle-drawer__nav"},tm=["title"],im={class:"spm-protyle-drawer__actions"},nm=["aria-label"],om=["aria-label"],sm=Ct({__name:"ProtylePeekDrawer",props:{blockId:{},title:{},plugin:{}},emits:["external-jump"],setup(e,{emit:t}){const i=t,n=e,o=fe(n.blockId),s=fe(n.title||""),l=fe(!1),r=fe(!0),a=fe(!1),c=fe(""),d=mi,p=fe([]),b=fe(null);let u=null;Di(()=>n.blockId,w=>{w&&w!==o.value&&(o.value=w,s.value=n.title||"",p.value=[],f(w))}),Fn(()=>{o.value&&f(o.value)}),zs(()=>{g()});async function h(w){try{const P=await en(`SELECT id, root_id, type, content FROM blocks WHERE id = '${w}' LIMIT 1`);if(Array.isArray(P)&&P.length>0){const R=P[0];c.value=R.root_id||"";const z=R.id===R.root_id||R.type==="d";a.value=z,r.value=!z,!s.value&&R.content&&(s.value=R.content.trim().slice(0,30));return}}catch(P){console.warn("[ProtylePeekDrawer] detectBlockType query failed:",P)}a.value=!1,r.value=!0}async function f(w,P){if(!b.value||!w)return;g(),await h(w),typeof P=="boolean"&&(r.value=!a.value&&P);let R,z;r.value&&!a.value?(R=["cb-get-all","cb-get-hl","cb-get-focus"],z={background:!1,title:!1,gutter:!0,breadcrumbDocName:!0,scroll:!0}):(R=["cb-get-context","cb-get-hl"],z={background:!0,title:!0,gutter:!0,breadcrumbDocName:!0,scroll:!0});try{u=new me.Protyle(n.plugin.app,b.value,{blockId:w,action:R,render:z}),!l.value&&u&&typeof u.disable=="function"&&u.disable()}catch(V){console.error("[ProtylePeekDrawer] Failed to instantiate Protyle:",V)}}function g(){if(u){try{typeof u.destroy=="function"&&u.destroy()}catch(w){console.warn("[ProtylePeekDrawer] Error destroying protyle:",w)}u=null}b.value&&(b.value.innerHTML="")}function k(){a.value||(r.value=!r.value,f(o.value,r.value))}function S(){l.value=!l.value,u&&(l.value?(typeof u.enable=="function"&&u.enable(),typeof u.focus=="function"&&u.focus()):typeof u.disable=="function"&&u.disable())}function C(){if(o.value)try{me.openWindow({doc:{id:o.value},alwaysOnTop:!0})}catch(w){console.warn("[ProtylePeekDrawer] openWindow failed:",w)}}function T(){var R;if(!o.value)return;const w=No(),P=ua(w.webServeUrl,o.value,{focus:!a.value});if(typeof window<"u"){const z=_t("electron");(R=z==null?void 0:z.shell)!=null&&R.openExternal?z.shell.openExternal(P).catch(()=>{window.open(P,"_blank")}):window.open(P,"_blank")}i("external-jump",P)}function B(){if(p.value.length>0){const w=p.value.pop();w&&(o.value=w.blockId,s.value=w.title,r.value=w.isFocusMode,a.value=w.isDoc,f(w.blockId,w.isFocusMode))}}function I(w){const P=w.target;if(!P)return;const R=P.closest('[data-type="block-ref"]');if(R){const V=R.getAttribute("data-id");if(V&&V!==o.value){w.preventDefault(),w.stopPropagation(),p.value.push({blockId:o.value,title:s.value||o.value,isFocusMode:r.value,isDoc:a.value}),o.value=V,s.value=R.innerText.trim()||V,f(V);return}}const z=P.closest("a");if(z&&z.href&&z.href.startsWith("siyuan://blocks/")){w.preventDefault(),w.stopPropagation();const V=z.href.replace("siyuan://blocks/","").split("?")[0];V&&V!==o.value&&(p.value.push({blockId:o.value,title:s.value||o.value,isFocusMode:r.value,isDoc:a.value}),o.value=V,s.value=z.innerText.trim()||V,f(V))}}return(w,P)=>(ee(),te("div",Xh,[m("div",Qh,[m("div",em,[p.value.length>0?(ee(),te("button",{key:0,class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"返回上层引用文档或块",onClick:B},[re(ce,{name:"arrow-left"}),P[0]||(P[0]=m("span",null,"返回",-1))])):Oe("",!0),m("span",{class:_e(["spm-protyle-badge",{"is-focus":r.value&&!a.value}])},we(r.value&&!a.value?"思源块聚焦":"思源文档速览"),3),m("span",{class:"spm-protyle-id",title:s.value||o.value},we(s.value||o.value),9,tm)]),m("div",im,[a.value?Oe("",!0):(ee(),te("button",{key:0,class:_e(["spm-icon-btn b3-tooltips b3-tooltips__s",{"is-primary":r.value}]),"aria-label":r.value?"当前为块聚焦模式（点击展开所属文档全文）":"当前为文档全文模式（点击切回仅聚焦当前块）",onClick:k},[re(ce,{name:r.value?"focus":"file-text"},null,8,["name"]),m("span",null,we(r.value?"块聚焦":"展开全文"),1)],10,nm)),m("button",{class:_e(["spm-icon-btn b3-tooltips b3-tooltips__s",{"is-primary":l.value}]),"aria-label":l.value?"当前为即时编辑模式（点击切回只读）":"当前为只读速览模式（点击解锁即时编辑）",onClick:S},[re(ce,{name:l.value?"edit":"eye"},null,8,["name"]),m("span",null,we(l.value?"编辑中":"只读"),1)],10,om),m("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"在置顶独立窗口中打开 (保留完整侧边栏与插件)",onClick:C},[re(ce,{name:"window"}),P[1]||(P[1]=m("span",null,"独立窗口",-1))]),ge(d).enableWebServeJump?(ee(),te("button",{key:1,class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"在系统默认浏览器中打开 (外跳)",onClick:T},[re(ce,{name:"external-link"}),P[2]||(P[2]=m("span",null,"外跳",-1))])):Oe("",!0)])]),m("div",{ref_key:"mountEl",ref:b,class:_e(["spm-protyle-mount",{"is-focus-mode":r.value&&!a.value}]),onClick:I},null,2)]))}}),rm=zt(sm,[["__scopeId","data-v-7e586ef3"]]),lm=/^(https?|file|data|blob|mailto|tel|ftp|ftps|siyuan|about|chrome|ws|wss):/i,am=/\.(html?|xhtml|pdf|png|jpe?g|gif|svg|webp|avif|ico|mp4|webm|mov|mp3|wav|m4a|ogg|json|md|markdown|txt|csv|zip|tar|gz|7z|rar|js|mjs|css|xml|yaml|yml|toml|ipynb|docx?|xlsx?|pptx?)$/i;function Fr(e){let t=e||"";try{t=decodeURIComponent(t)}catch{}t=t.replace(/\\/g,"/");const i=/(?:^|\/)data\/assets\/(.+)$/i.exec(t);if(i)return`/assets/${i[1]}`;const n=/(?:^|\/)data\/plugins\/(.+)$/i.exec(t);return n?`/plugins/${n[1]}`:null}function xa(e){const t=(e||"").replace(/^file:\/\//i,"");let i=t;try{i=decodeURIComponent(t)}catch{}if(i.startsWith("/"))return/^\/([a-zA-Z]:[\\/])/.exec(i)?i.slice(1):i;const n=i.indexOf("/");return n>=0?i.slice(n):i}function cm(e){const t=e.split(/[/?#]/)[0];return!t||am.test(t)?!1:/^(localhost|\d{1,3}(\.\d{1,3}){3})(:\d+)?$/i.test(t)?!0:/^[a-z0-9-]+(\.[a-z0-9-]+)+(:\d+)?$/i.test(t)}function dm(e){const t=e.indexOf("#"),i=t>=0?e.slice(t):"",n=t>=0?e.slice(0,t):e,o=n.indexOf("?"),s=o>=0?n.slice(0,o):n,l=o>=0?n.slice(o+1):"";if(!/^\/?assets\/.+\.html?$/i.test(s))return e;const r=new URLSearchParams(l);return r.get("iframe")==="true"||r.get("download")==="true"?e:(r.set("iframe","true"),`${s}?${r.toString()}${i}`)}function Sa(e){const t=um(e);return t.external||!t.url?t:{url:dm(t.url),external:!1}}function um(e){const t=(e||"").trim();if(!t)return{url:"",external:!1};if(/^https?:\/\//i.test(t))return{url:t,external:!1};if(t.startsWith("//"))return{url:`https:${t}`,external:!1};if(/^(siyuan|data|blob|about):/i.test(t))return{url:t,external:!1};if(il(t))return{url:`/${nl(t)}`,external:!1};if(/^file:/i.test(t)){const n=Fr(xa(t));return n?{url:n,external:!1}:{url:t,external:!0}}if(/^[a-zA-Z]:[\\/]/.test(t)||t.startsWith("\\\\")){const n=Fr(t);return n?{url:n,external:!1}:{url:t,external:!0}}return lm.test(t)?{url:t,external:!0}:cm(t)?{url:`https://${t}`,external:!1}:{url:`/${t.replace(/^(?:\.{1,2}\/)+/,"").replace(/^\/+/,"")}`,external:!1}}const fm={class:"spm-webview-drawer"},pm={class:"spm-webview-toolbar"},hm={class:"spm-webview-toolbar__nav"},mm=["disabled"],gm=["disabled"],vm=["aria-label"],bm={class:"spm-webview-toolbar__address"},ym=["aria-label"],km={class:"spm-webview-toolbar__actions"},wm=["aria-label"],xm={class:"spm-zoom-controller"},Sm=["disabled"],_m=["disabled"],Cm={key:1,class:"spm-webview-fallback"},$m=["src"],Im={key:2,class:"spm-load-error"},Em={class:"spm-load-error__code"},Tm={class:"spm-load-error__code-num"},Am={class:"spm-load-error__url"},Bm={class:"spm-load-error__hint"},Mm={class:"spm-load-error__actions"},Hr="Mozilla/5.0 (iPhone; CPU iPhone OS 17_4_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.4.1 Mobile/15E148 Safari/604.1",_a="siyuan-slidev-peek-view-mode";let Ca="desktop";function Dm(){if(typeof window<"u"&&window.localStorage)try{const e=window.localStorage.getItem(_a);if(e==="mobile"||e==="desktop")return e}catch{}return Ca}function Lm(e){if(Ca=e,typeof window<"u"&&window.localStorage)try{window.localStorage.setItem(_a,e)}catch{}}function Om(e){switch((e||"").toUpperCase()){case"ERR_PROXY_CONNECTION_FAILED":return"无法连接到代理服务器：请在思源「设置 → 网络代理」中填写公司代理地址，或切换为「使用系统代理」。";case"ERR_TUNNEL_CONNECTION_FAILED":return"HTTPS 代理隧道建立失败：请将思源「网络代理」的类型设为 HTTPS 并确认地址正确。";case"ERR_MANDATORY_PROXY_CONFIGURATION_FAILED":return"强制代理配置获取失败：公司 PAC 脚本不可用，请在思源「网络代理」中改为手动填写代理地址。";case"ERR_NAME_NOT_RESOLVED":case"ERR_NAME_RESOLUTION_FAILED":return"域名解析失败：内网环境访问外网通常需要配置代理或 DNS。";case"ERR_INTERNET_DISCONNECTED":return"当前网络不可用：请检查网络连接。";case"ERR_CONNECTION_TIMED_OUT":case"ERR_TIMED_OUT":return"连接超时：该地址可能需要通过代理才能访问。";case"ERR_CONNECTION_REFUSED":return"连接被拒绝：目标服务未在监听，或思源本地内核尚未启动。";case"ERR_CERT_AUTHORITY_INVALID":case"ERR_CERT_COMMON_NAME_INVALID":case"ERR_CERT_DATE_INVALID":return"证书校验失败：若公司网络使用 TLS 拦截，需将根证书导入思源所用系统的证书库。";default:return"若处于公司内网，请优先检查思源「设置 → 网络代理」是否已配置为可用代理（支持「使用系统代理」）。"}}const Rm=Ct({__name:"WebviewPeekDrawer",props:{url:{},title:{},visible:{type:Boolean,default:!0}},emits:["external-jump"],setup(e,{emit:t}){const i=t,n=e,o=fe(ba()&&!Of()),s=fe(n.url),l=fe(n.url),r=fe(!1),a=fe(null),c=fe(!1),d=fe(!1),p=fe(1),b=fe(!1),u=fe(Dm());let h=typeof navigator<"u"&&!navigator.userAgent.includes("iPhone")?navigator.userAgent:"";const f=xe(()=>u.value==="mobile"?Hr:h||void 0),g=fe(null),k=fe(null);let S=null,C=null,T=null;Di(()=>n.url,q=>{q&&q!==s.value&&(s.value=q,l.value=q,u.value==="mobile"&&R(!1),g.value&&typeof g.value.loadURL=="function"&&g.value.loadURL(q))}),Di(()=>n.visible,q=>{if(q)G(),u.value==="mobile"&&R(!1);else if(g.value)try{typeof g.value.stop=="function"&&g.value.stop()}catch{}}),Fn(()=>{B(),k.value&&typeof ResizeObserver<"u"&&(S=new ResizeObserver(()=>{const q=g.value;if(q&&typeof q.invalidate=="function")try{q.invalidate()}catch{}}),S.observe(k.value)),C=q=>{var ve;const ae=q.message||((ve=q.error)==null?void 0:ve.message);if(typeof ae=="string"&&ae.includes("Invalid guestInstanceId"))return q.preventDefault(),q.stopImmediatePropagation(),!0},window.addEventListener("error",C,!0),T=q=>{const ae=q.reason,ve=typeof ae=="string"?ae:ae==null?void 0:ae.message;typeof ve=="string"&&ve.includes("Invalid guestInstanceId")&&q.preventDefault()},window.addEventListener("unhandledrejection",T)}),zs(()=>{if(I(),S&&(S.disconnect(),S=null),C&&(window.removeEventListener("error",C,!0),C=null),T&&(window.removeEventListener("unhandledrejection",T),T=null),g.value)try{typeof g.value.stop=="function"&&g.value.stop()}catch{}});function B(){const q=g.value;q&&(q.addEventListener("dom-ready",w),q.addEventListener("did-start-loading",z),q.addEventListener("did-stop-loading",L),q.addEventListener("did-navigate",y),q.addEventListener("did-navigate-in-page",A),q.addEventListener("new-window",F),q.addEventListener("did-fail-load",V),q.addEventListener("did-fail-provisional-load",V))}function I(){const q=g.value;if(q)try{q.removeEventListener("dom-ready",w),q.removeEventListener("did-start-loading",z),q.removeEventListener("did-stop-loading",L),q.removeEventListener("did-navigate",y),q.removeEventListener("did-navigate-in-page",A),q.removeEventListener("new-window",F),q.removeEventListener("did-fail-load",V),q.removeEventListener("did-fail-provisional-load",V)}catch{}}function w(){const q=g.value;if(q&&typeof q.getUserAgent=="function"&&!h)try{const ae=q.getUserAgent();ae&&!ae.includes("iPhone")&&(h=ae)}catch{}u.value==="mobile"&&R(!1),G(),E()}function P(){const q=u.value==="mobile"?"desktop":"mobile";u.value=q,Lm(q),R(!0)}function R(q=!1){const ae=g.value;if(!ae)return;const ve=u.value==="mobile"?Hr:h;if(typeof ae.setUserAgent=="function"&&ve)try{ae.setUserAgent(ve)}catch(O){console.warn("[WebviewPeekDrawer] setUserAgent error:",O)}if(q&&typeof ae.reload=="function")try{ae.reload()}catch(O){console.warn("[WebviewPeekDrawer] reload error:",O)}}function z(){r.value=!0,a.value=null}function V(q){if(q&&q.isMainFrame===!1||q&&Number(q.errorCode)===-3)return;const ae=String((q==null?void 0:q.errorDescription)||"ERR_FAILED");a.value={errorCode:Number((q==null?void 0:q.errorCode)??0),description:ae,validatedURL:String((q==null?void 0:q.validatedURL)||s.value),hint:Om(ae)},r.value=!1}function _(){a.value=null,X()}function L(){if(r.value=!1,E(),g.value&&typeof g.value.getURL=="function"){const q=g.value.getURL();q&&q!=="about:blank"&&(s.value=q,l.value=q)}}function y(q){q!=null&&q.url&&(s.value=q.url,l.value=q.url),E()}function A(q){q!=null&&q.url&&(s.value=q.url,l.value=q.url),E()}function F(q){q&&q.url&&(q.preventDefault(),g.value&&typeof g.value.loadURL=="function"&&g.value.loadURL(q.url))}function E(){const q=g.value;q&&(typeof q.canGoBack=="function"&&(c.value=q.canGoBack()),typeof q.canGoForward=="function"&&(d.value=q.canGoForward()))}function D(){g.value&&typeof g.value.goBack=="function"&&g.value.goBack()}function N(){g.value&&typeof g.value.goForward=="function"&&g.value.goForward()}function X(){g.value&&typeof g.value.reload=="function"&&g.value.reload()}function j(){const q=Sa(l.value);if(q.url){if(q.external){s.value=q.url,be();return}s.value=q.url,l.value=q.url,g.value&&typeof g.value.loadURL=="function"&&g.value.loadURL(q.url)}}function G(){const q=g.value;if(q&&typeof q.setZoomFactor=="function")try{q.setZoomFactor(p.value)}catch(ae){console.warn("[WebviewPeekDrawer] setZoomFactor error:",ae)}}function ne(){p.value=Math.min(2.5,Math.round((p.value+.1)*10)/10),G()}function se(){p.value=Math.max(.5,Math.round((p.value-.1)*10)/10),G()}function le(){p.value=1,G()}function pe(q){q.preventDefault(),q.deltaY<0?ne():q.deltaY>0&&se()}async function Te(){if(typeof navigator<"u"&&navigator.clipboard)try{await navigator.clipboard.writeText(s.value),b.value=!0,setTimeout(()=>{b.value=!1},2e3)}catch(q){console.warn("Copy url failed:",q)}}function be(){var ae;const q=s.value;if(typeof window<"u"){const ve=_t("electron");(ae=ve==null?void 0:ve.shell)!=null&&ae.openExternal?ve.shell.openExternal(q).catch(()=>{window.open(q,"_blank")}):window.open(q,"_blank")}i("external-jump",q)}return(q,ae)=>{const ve=Ud("webview");return ee(),te("div",fm,[m("div",pm,[m("div",hm,[m("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s",disabled:!c.value,"aria-label":"后退",onClick:D},[re(ce,{name:"arrow-left"})],8,mm),m("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s",disabled:!d.value,"aria-label":"前进",onClick:N},[re(ce,{name:"arrow-right"})],8,gm),m("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":r.value?"正在加载...":"刷新页面",onClick:X},[re(ce,{name:"refresh"})],8,vm)]),m("div",bm,[Tt(m("input",{"onUpdate:modelValue":ae[0]||(ae[0]=O=>l.value=O),type:"text",class:"b3-text-field spm-url-input",placeholder:"https://...",spellcheck:"false",onKeydown:rf(j,["enter"])},null,544),[[So,l.value]]),m("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":b.value?"已复制地址！":"复制网址",onClick:Te},[re(ce,{name:"copy"})],8,ym)]),m("div",km,[m("button",{class:_e(["spm-icon-btn spm-mode-toggle b3-tooltips b3-tooltips__s",{"is-active":u.value==="mobile"}]),"aria-label":u.value==="mobile"?"当前为手机视图，点击切换为桌面视图":"当前为桌面视图，点击切换为手机视图",onClick:P},[re(ce,{name:u.value==="mobile"?"mobile":"desktop"},null,8,["name"])],10,wm),m("div",xm,[m("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"缩小 (Ctrl + -)",disabled:p.value<=.5,onClick:se},[re(ce,{name:"minus"})],8,Sm),m("button",{class:"spm-zoom-badge b3-tooltips b3-tooltips__s","aria-label":"重置 100% (Ctrl + 0)",onClick:le},we(Math.round(p.value*100))+"% ",1),m("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"放大 (Ctrl + +)",disabled:p.value>=2.5,onClick:ne},[re(ce,{name:"plus"})],8,_m)]),m("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"在系统默认浏览器中打开 ↗",onClick:be},[re(ce,{name:"external-link"}),ae[1]||(ae[1]=m("span",null,"外跳",-1))])])]),m("div",{ref_key:"containerEl",ref:k,class:_e(["spm-webview-body",{"is-mobile":u.value==="mobile"}]),onWheel:Mt(pe,["ctrl"])},[m("div",{class:_e(["spm-webview-viewport",{"is-mobile":u.value==="mobile"}])},[o.value?(ee(),Dt(ve,{key:0,ref_key:"webviewRef",ref:g,class:"spm-webview-frame",src:s.value,useragent:f.value,allowpopups:"true",style:{position:"absolute",top:"0",left:"0",width:"100%",height:"100%",display:"inline-flex"}},null,8,["src","useragent"])):(ee(),te("div",Cm,[m("iframe",{class:"spm-webview-fallback-frame",src:s.value,frameborder:"0",sandbox:"allow-scripts allow-same-origin allow-forms allow-popups"},null,8,$m),m("div",{class:"spm-fallback-bar"},[ae[2]||(ae[2]=m("span",null,"如页面受同源策略 (X-Frame-Options) 拦截无法显示，请",-1)),m("button",{class:"spm-icon-btn is-primary",onClick:be}," 在新标签页中打开 ↗ ")])])),a.value?(ee(),te("div",Im,[re(ce,{name:"alert",class:"spm-load-error__icon"}),ae[5]||(ae[5]=m("div",{class:"spm-load-error__title"},"页面加载失败",-1)),m("div",Em,[$t(we(a.value.description)+" ",1),m("span",Tm,"("+we(a.value.errorCode)+")",1)]),m("div",Am,we(a.value.validatedURL),1),m("p",Bm,we(a.value.hint),1),m("div",Mm,[m("button",{class:"spm-icon-btn","aria-label":"重试",onClick:_},[re(ce,{name:"refresh"}),ae[3]||(ae[3]=m("span",null,"重试",-1))]),m("button",{class:"spm-icon-btn is-primary","aria-label":"用系统浏览器打开",onClick:be},[re(ce,{name:"external-link"}),ae[4]||(ae[4]=m("span",null,"用系统浏览器打开 ↗",-1))])])])):Oe("",!0)],2)],34)])}}}),Pm=zt(Rm,[["__scopeId","data-v-6c82ca68"]]);class Nm{constructor(){ye(this,"timers",new Map)}debounce(t,i,n=150){this.cancel(t);const o=setTimeout(()=>{this.timers.delete(t),i()},n);this.timers.set(t,o)}cancel(t){this.timers.has(t)&&(clearTimeout(this.timers.get(t)),this.timers.delete(t))}cancelAll(){for(const t of this.timers.values())clearTimeout(t);this.timers.clear()}hasPending(t){return this.timers.has(t)}}class zm{constructor(t){ye(this,"blockToPageMap",new Map);ye(this,"debounceCtrl",new Nm);ye(this,"activeBlockId","");ye(this,"activePageIndex",1);ye(this,"currentDocId","");ye(this,"bridge",null);t&&(this.bridge=t)}setBridge(t){this.bridge=t}setDocId(t){this.currentDocId=t}updateSlidesIndex(t){this.blockToPageMap.clear();for(const i of t){i.startBlockId&&this.blockToPageMap.set(i.startBlockId,i.pageIndex);for(const n of i.blocks)this.blockToPageMap.set(n.id,i.pageIndex)}}getPageByBlockId(t){return this.blockToPageMap.get(t)??null}onCursorFocusBlock(t){if(!t||t===this.activeBlockId)return;this.activeBlockId=t;let i=this.getPageByBlockId(t);!i&&(t===this.currentDocId||!this.currentDocId&&this.blockToPageMap.size>0)&&(i=1),i&&this.debounceCtrl.debounce("cursor-navigate",()=>{this.activePageIndex=i,this.bridge&&(this.bridge.navigatePage(i),this.bridge.highlightElement(t))},100)}getActiveBlockId(){return this.activeBlockId}setActiveBlockId(t){this.activeBlockId=t;const i=this.getPageByBlockId(t);i&&(this.activePageIndex=i)}getActivePageIndex(){return this.activePageIndex}destroy(){this.debounceCtrl.cancelAll(),this.blockToPageMap.clear(),this.bridge=null}}function Li(e,t){var s,l;if(!e||typeof document>"u")return!1;const i=(s=globalThis.CSS)!=null&&s.escape?globalThis.CSS.escape(e):e.replace(/"/g,'\\"'),n=document.querySelector(`.protyle-wysiwyg [data-node-id="${i}"]`)||document.querySelector(`[data-node-id="${i}"]`);if(!n){if(t)try{return me.openTab({app:t,doc:{id:e,action:["cb-get-hl","cb-get-focus","cb-get-context"]}}),!0}catch(r){console.warn("[SelectionMirror] openTab fallback failed:",r)}return!1}try{n.scrollIntoView({behavior:"smooth",block:"center",inline:"nearest"})}catch{n.scrollIntoView()}try{(l=n.focus)==null||l.call(n,{preventScroll:!0})}catch{}n.classList.add("protyle-wysiwyg--select");const o=n.style.outline;return n.style.outline="2px solid #3b82f6",n.style.transition="outline 0.3s ease",setTimeout(()=>{n.classList.remove("protyle-wysiwyg--select"),n.style.outline=o},1200),!0}function Fm(e){if(!e)return"";const t=e.split(`
`).map(l=>l.trim()).filter(Boolean);if(t.length===0)return"";if(!t.some(l=>/^#{1,6}\s+/.test(l)))return t.map(l=>rt(l)).join("<br/>");const n=[];let o=[];const s=()=>{if(o.length>0){const l=o.map(r=>rt(r)).join("<br/>");n.push(`<p class="slide-list-item-desc">${l}</p>`),o=[]}};for(const l of t){const r=l.match(/^(#{1,6})\s+(.*)$/);if(r){s();const a=r[1].length,c=r[2].trim();n.push(`<h${a} class="slide-list-item-title">${rt(c)}</h${a}>`)}else o.push(l)}return s(),n.join(`
`)}function Hm(e){if(e.length===0)return"";const t=[],i=e[0],n=i.match(/^(#{1,6})\s+(.*)$/);if(n){const o=n[1].length,s=n[2].trim();t.push(`<h${o} class="slide-list-item-title">${rt(s)}</h${o}>`)}else t.push(`<p class="slide-list-item-title">${rt(i)}</p>`);if(e.length>1){const o=e.slice(1);let s=[];const l=()=>{if(s.length>0){const r=s.map(a=>rt(a)).join("<br/>");t.push(`<p class="slide-list-item-desc">${r}</p>`),s=[]}};for(const r of o){const a=r.match(/^(#{1,6})\s+(.*)$/);if(a){l();const c=a[1].length,d=a[2].trim();t.push(`<h${c} class="slide-list-item-title">${rt(d)}</h${c}>`)}else s.push(r)}l()}return t.join(`
`)+(t.length>0?`
`:"")}function $a(e,t,i){var b,u,h,f;const n=e.split(`
`);if(!n.some(g=>/^(\s*)([-*+]|\d+\.)\s+/.test(g)))return null;const s=[],l=[];let r=!1;for(let g=0;g<n.length;g++){const k=n[g];if(!k.trim())continue;const S=k.match(/^(\s*)[-*+]\s+\[([ xX])\]\s+(.*)$/);if(S){const I=S[1].length,w=Math.floor(I/2);l.push({type:"task",level:w,checked:S[2].toLowerCase()==="x",text:S[3],media:[]});continue}const C=k.match(/^(\s*)[-*+]\s+(.*)$/);if(C){const I=C[1].length,w=Math.floor(I/2);l.push({type:"unordered",level:w,text:C[2],media:[]});continue}const T=k.match(/^(\s*)\d+\.\s+(.*)$/);if(T){l.length===0&&(r=!0);const I=T[1].length,w=Math.floor(I/2);l.push({type:"ordered",level:w,text:T[2],media:[]});continue}const B=k.trim();if(!(!B||/^\{:.*?\}$/.test(B)))if(l.length>0){const I=B.match(/^!\[(.*?)\]\((.*?)\)(?:\{:?[^}]*\})?$/);if(I){const R=/\.gif(?:\?|$)/i.test(I[2])?"list-item-gif":"list-item-img";l[l.length-1].media||(l[l.length-1].media=[]),l[l.length-1].media.push(`<div class="slide-list-media"><img alt="${at(I[1])}" src="${I[2]}" class="${R}" /></div>`);continue}if(B.match(/^<img\b[\s\S]*?\/?>$/i)){const P=B.replace(/\s+style="[^"]*"/gi,"");l[l.length-1].media||(l[l.length-1].media=[]),l[l.length-1].media.push(`<div class="slide-list-media">${P}</div>`);continue}if(/<video\b/i.test(B)){let P=B;if(!/<\/video>/i.test(P))for(;g+1<n.length&&!/<\/video>/i.test(P);)g++,P+=" "+n[g].trim();const R=((b=i==null?void 0:i.attributes)==null?void 0:b["custom-slidev-autoplay"])==="true"||/autoplay/i.test(P),z=((u=i==null?void 0:i.attributes)==null?void 0:u["custom-slidev-loop"])==="true"||/loop/i.test(P),V=((h=i==null?void 0:i.attributes)==null?void 0:h["custom-slidev-muted"])==="true"||R||/muted/i.test(P),_=((f=i==null?void 0:i.attributes)==null?void 0:f["custom-slidev-controls"])==="false",L=P.match(/\bsrc=["']([^"']+)["']/i),y=L?L[1]:"",A=['class="slide-video-player"'];_||A.push("controls"),R&&(A.push("autoplay"),A.push("playsinline")),z&&A.push("loop"),V&&A.push("muted"),A.push('preload="metadata"'),y&&A.push(`src="${y}"`);const F=P.match(/<video[^>]*>([\s\S]*?)<\/video>/i);let E=F?F[1].trim():"";!E&&y&&(E=`<source src="${y}" type="video/mp4" />您的浏览器不支持视频播放。`),l[l.length-1].media||(l[l.length-1].media=[]),l[l.length-1].media.push(`<div class="slide-list-media slide-video-container slide-media-container" data-autoplay="${R?"true":"false"}" data-muted="${V?"true":"false"}"><video ${A.join(" ")}>${E}</video></div>`);continue}l[l.length-1].text+=`
`+B}else s.push(B)}if(l.length===0)return null;const a=r?"ol":"ul",c=(t==null?void 0:t.listClassName)||(r?"pdf-list pdf-list--ordered":"pdf-list pdf-list--unordered"),d=l.map(g=>{const k=Fm(g.text),S=g.media&&g.media.length>0?`
${g.media.join(`
`)}`:"",C=g.level||0,T=C>0?` style="margin-left:${(C*1.25).toFixed(2)}em;${g.type==="unordered"?`list-style-type:${C%2===1?"circle":"square"} !important;`:""}"`:"",B=C>0?" slide-list-item--nested":"";if(g.type==="task"){const w=g.checked?' checked=""':"";return`<li class="pdf-task-item${B}"${T}><label><input type="checkbox" disabled=""${w}/> <span>${k}</span></label>${S}</li>`}return`<li${B?` class="${B.trim()}"`:""}${T}>${k}${S}</li>`}).join(`
`);return`${Hm(s)}<${a} class="${c}">
${d}
</${a}>`}function jm(e,t,i){const n=(t==null?void 0:t.containerClassName)||"pdf-block",o=e.split(/\r?\n/),s=[];let l=[];for(let c=0;c<o.length;c++){const d=o[c],p=d.trim();if(/^#{1,6}\s+/.test(p)){l.length>0&&(s.push(l.join(`
`)),l=[]),s.push(p);continue}if(!p){l.length>0&&(s.push(l.join(`
`)),l=[]);continue}if(/^!\[.*?\]\(.*?\)$/.test(p)){l.length>0&&(s.push(l.join(`
`)),l=[]),s.push(p);continue}if(/<video\b/i.test(p)){l.length>0&&(s.push(l.join(`
`)),l=[]);let b=p;if(!/<\/video>/i.test(b))for(;c+1<o.length&&!/<\/video>/i.test(b);)c++,b+=`
`+o[c];s.push(b);continue}l.push(d)}l.length>0&&s.push(l.join(`
`));let r=!0;return s.map(c=>{var h,f,g,k;const d=c.trim();if(!d)return"";const p=d.match(/^(#{1,6})\s+(.*)$/);if(p){r=!1;const S=p[1].length;return`<h${S} class="slide-list-item-title">${rt(p[2].trim())}</h${S}>`}const b=d.match(/^!\[(.*?)\]\((.*?)\)$/);if(b){const S=/\.gif(?:\?|$)/i.test(b[2]),C=(t==null?void 0:t.imageClassName)||(S?"list-item-gif":"pdf-image slide-media-img");return`<div class="${n} ${n}--image slide-media-block slide-media-container slide-list-media"><img alt="${at(b[1])}" src="${b[2]}" class="${C}" /></div>`}if(/<video\b/i.test(d)){const S=((h=i==null?void 0:i.attributes)==null?void 0:h["custom-slidev-autoplay"])==="true"||/autoplay/i.test(d),C=((f=i==null?void 0:i.attributes)==null?void 0:f["custom-slidev-loop"])==="true"||/loop/i.test(d),T=((g=i==null?void 0:i.attributes)==null?void 0:g["custom-slidev-muted"])==="true"||S||/muted/i.test(d),B=((k=i==null?void 0:i.attributes)==null?void 0:k["custom-slidev-controls"])==="false",I=d.match(/\bsrc=["']([^"']+)["']/i),w=I?I[1]:"",P=['class="slide-video-player"'];B||P.push("controls"),S&&P.push("autoplay playsinline"),C&&P.push("loop"),T&&P.push("muted"),P.push('preload="metadata"'),w&&P.push(`src="${w}"`);const R=d.match(/<video[^>]*>([\s\S]*?)<\/video>/i);let z=R?R[1].trim():"";return!z&&w&&(z=`<source src="${w}" type="video/mp4" />您的浏览器不支持视频播放。`),`<div class="${n} ${n}--video slide-media-block slide-video-container slide-media-container" data-autoplay="${S?"true":"false"}" data-muted="${T?"true":"false"}"><video ${P.join(" ")}>${z}</video></div>`}const u=$a(d,t,i);if(u)return r=!1,u;if(r){r=!1;const S=d.split(/\r?\n/).map(I=>I.trim()).filter(Boolean);if(S.length===1)return`<p class="slide-list-item-title">${rt(S[0])}</p>`;const C=S[0],B=S.slice(1).map(I=>rt(I)).join("<br/>");return`<p class="slide-list-item-title">${rt(C)}</p>
<p class="slide-list-item-desc">${B}</p>`}return`<p class="slide-list-item-desc">${rt(d)}</p>`}).filter(Boolean).join(`
`)}function es(e){if(!e)return!1;if(e.type==="h"||e.type==="NodeHeading")return!0;const t=(e.rawMarkdown||e.content||"").trim();return/^#{1,6}\s+/.test(t)}function Wm(e,t){var r,a,c,d,p,b,u,h;const i=((r=e.frontmatter)==null?void 0:r.layout)||"default",o=(e.blocks||[]).filter(f=>f.slot!=="slot-divider-right"),l=i==="cover"?null:o.find(es);if(i==="two-cols"){const f=o.some(V=>V.slot==="right");let g=[],k=[];if(f)g=o.filter(V=>V.slot!=="right"),k=o.filter(V=>V.slot==="right");else{const V=Math.ceil(o.length/2);g=o.slice(0,V),k=o.slice(V)}const S=V=>{const _=V.filter(L=>!!(L.rawMarkdown||L.content||"").trim());if(_.length>0){const L=_[0],y=(L.rawMarkdown||L.content||"").trim();(Ri(L)||/^(?:[-*+]|\d+\.)\s+/.test(y))&&(L.rawMarkdown=xn(L.rawMarkdown||L.content||""),L.content=L.rawMarkdown)}};S(g),S(k);const C=g.map(V=>fi(V,t)).join(`
`),T=k.map(V=>fi(V,t)).join(`
`),B="pdf-two-cols-wrapper layout-two-cols-grid",I=(a=e.frontmatter)!=null&&a.layoutClass?` ${e.frontmatter.layoutClass}`:"",w="pdf-col pdf-col--left",P="pdf-col pdf-col--right",z=`style="grid-template-columns: ${Xo((c=e.frontmatter)==null?void 0:c.layoutRatio,2)};"`;return`
      <div class="${B}${I}" ${z}>
        <div class="${w}">${C}</div>
        <div class="${P}">${T}</div>
      </div>
    `}if(i==="clover"||Tn(i)){const f=i==="clover";let g=[];const k=o.filter(A=>A.slot==="header");if(k.length>0)g=k;else if(o.length>0){const A=o.find(F=>F.type==="h"&&(!F.slot||F.slot==="default"));A&&(g=[A])}const S=o.filter(A=>!g.includes(A));let C=2;if(f)C=4;else if(i==="three-cols-header")C=3;else if(i==="two-cols-header")C=2;else{let A=0;for(const F of S){const E=(F.slot||"").match(/^col-(\d+)$/i);E&&(A=Math.max(A,parseInt(E[1],10)))}if(A>=2)C=A;else if((d=e.frontmatter)!=null&&d.layoutRatio){const F=e.frontmatter.layoutRatio.trim();if(F.includes(":")){const E=F.split(":").map(D=>parseFloat(D.trim())).filter(D=>!isNaN(D)&&D>0);E.length>=2&&(C=E.length)}else{const E=F.split(/\s+/).filter(Boolean);E.length>=2&&(C=E.length)}}else S.length===1&&S[0].children&&S[0].children.length>=2&&(C=Math.min(6,S[0].children.length))}const T=va(S,C),B=S.some(A=>A.slot&&/^(?:col-\d+|left|right)$/i.test(A.slot)),I=i==="clover"||i==="two-cols-header"||i==="three-cols-header"||Tn(i)&&B,w=A=>{const F=A.filter(D=>!!(D.rawMarkdown||D.content||"").trim());if(I&&F.length>0){const D=F[0],N=(D.rawMarkdown||D.content||"").trim();(Ri(D)||/^(?:[-*+]|\d+\.)\s+/.test(N))&&(D.rawMarkdown=xn(D.rawMarkdown||D.content||""),D.content=D.rawMarkdown),D.isColFirst=!0}const E=I?F.find(es):null;return F.map(D=>fi(D,{...t,extraClassName:D===E?"slidev-col-first-heading-block":""})).join(`
`)},P=g.find(es),R=g.map(A=>fi(A,{...t,extraClassName:A===P?"slidev-page-first-heading-block":""})).join(`
`),z=f?"repeat(2, minmax(0, 1fr))":Xo((p=e.frontmatter)==null?void 0:p.layoutRatio,C),V=f?`style="grid-template-columns: ${z}; grid-template-rows: repeat(2, minmax(0, 1fr));"`:`style="grid-template-columns: ${z};"`,_=[f?"layout-clover-container":"layout-cols-header-container",C===2?"layout-two-cols-header-container":"",C===3?"layout-three-cols-header-container":"",`layout-${i}-container`,I?"has-superblock-cols":""].filter(Boolean).join(" "),L=[f?"layout-clover-grid pdf-clover-wrapper":"layout-cols-wrapper layout-cols-grid",C===2?"pdf-two-cols-wrapper layout-two-cols-grid":"",C===3?"pdf-three-cols-wrapper layout-three-cols-grid":"",I?"has-superblock-cols":""].filter(Boolean).join(" "),y=T.map((A,F)=>{const E=F+1;return`<div class="${["pdf-col",C===2&&E===1?"pdf-col--left":"",C===2&&E===2?"pdf-col--right":"",`pdf-col--${E}`,`col-${E}`].filter(Boolean).join(" ")}">${w(A)}</div>`}).join(`
`);return`
      <div class="${_}">
        <div class="layout-header-section">${R}</div>
        <div class="${L}" ${V}>
          ${y}
        </div>
      </div>
    `}if(i==="image-right"||i==="image-left"){const f=i==="image-right",g=o.map(I=>fi(I,t)).join(`
`),k=((b=e.frontmatter)==null?void 0:b.image)||((u=e.frontmatter)==null?void 0:u.background)||"",S=`<div class="pdf-image-col" style="background-image:url('${at(k)}');background-size:cover;background-position:center;background-repeat:no-repeat;width:100%;height:100%;position:relative;overflow:hidden;"><img src="${at(k)}" style="width:100%;height:100%;object-fit:cover;object-position:center;display:block;" onerror="this.style.display='none'" alt="Slide cover" /></div>`,C=`<div class="pdf-content-col" style="padding:48px 56px;display:flex;flex-direction:column;justify-content:flex-start;height:100%;box-sizing:border-box;overflow-y:auto;">${g}</div>`,T=f?`${C}
${S}`:`${S}
${C}`;return`
      <div class="layout-image-cols-grid" style="display:grid;grid-template-columns:${Xo((h=e.frontmatter)==null?void 0:h.layoutRatio,2)};grid-template-rows:100%;width:100%;height:100%;position:absolute;top:0;left:0;right:0;bottom:0;box-sizing:border-box;">
        ${T}
      </div>
    `}return i==="fact"?`<div class="layout-fact-container">${o.map(g=>fi(g,t)).join(`
`)}</div>`:i==="cover"?`<div class="layout-cover-container">${o.map(g=>fi(g,t)).join(`
`)}</div>`:o.map(f=>fi(f,{...t,extraClassName:f===l?"slidev-page-first-heading-block":""})).join(`
`)}function at(e){return e?e.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&#039;"):""}function Um(e){if(!e||e.trim()===""||e.trim()==="all")return"all";const t=new Set,i=e.split("|");for(const n of i){const o=n.trim();if(o==="all")return"all";if(o.includes("-")){const[s,l]=o.split("-"),r=parseInt(s,10),a=parseInt(l,10);if(!isNaN(r)&&!isNaN(a))for(let c=Math.min(r,a);c<=Math.max(r,a);c++)t.add(c)}else{const s=parseInt(o,10);isNaN(s)||t.add(s)}}return t}const Vm=new Set(["kbd","mark","sub","sup","span","a","br","b","i","u","s","del","em","strong","code","small","abbr","ruby","rt","rp","v-mark","img","video","source","picture"]);function rt(e){if(!e)return"";const t=ha(e),i=[],n=t.replace(/<\/?([a-zA-Z0-9_-]+)(?:\s+[^<>]*)?\/?>/g,(s,l)=>{const r=l.toLowerCase();if(!Vm.has(r)||/on\w+\s*=|javascript:/i.test(s))return s;if(r==="v-mark"){const a=s.match(/type=["']?([a-zA-Z-]+)["']?/),c=a?a[1]:"circle";return s.startsWith("</")?i.push("</mark>"):i.push(`<mark class="v-mark v-mark--${c}">`),`%%SAFE_HTML_${i.length-1}%%`}return i.push(s),`%%SAFE_HTML_${i.length-1}%%`});let o=at(n);return o=o.replace(/\(\(([0-9a-zA-Z-]+)(?:\s*(?:&#039;([^&#]*)&#039;|&quot;([^&]*)&quot;|'([^']*)'|"([^"]*)"|([^\)]+?)))?\s*\)\)/g,(s,l,r,a,c,d,p)=>{const u=(r??a??c??d??p??"").trim()||`Ref(${l.slice(0,8)})`;return`<a href="siyuan://blocks/${l}" data-ref-id="${l}" class="slidev-ref-tag">🔗 ${u}</a>`}),o=o.replace(/\$([^$\n]+)\$/g,'<span class="katex-inline font-math"><em>$1</em></span>'),o=o.replace(/!\[(.*?)\]\((.*?)\)/g,(s,l,r)=>{const c=/\.gif(?:\?|$)/i.test(r)?"slide-inline-img list-item-gif":"slide-inline-img";return`<img alt="${l}" src="${r}" class="${c}" />`}),o=o.replace(/\[(.*?)\]\((.*?)\)/g,(s,l,r)=>{if(r.startsWith("siyuan://blocks/")){const a=r.replace("siyuan://blocks/","").split("?")[0];return`<a href="${r}" data-ref-id="${a}" class="slidev-ref-tag">🔗 ${l}</a>`}return`<a href="${r}" target="_blank" rel="noopener noreferrer" class="slidev-link">${l}</a>`}),o=o.replace(/(^|[\s(])(siyuan:\/\/blocks\/([0-9a-zA-Z-]+)(?:\?[^\s\)]*)?)/g,(s,l,r,a)=>`${l}<a href="${r}" data-ref-id="${a}" class="slidev-ref-tag">🔗 ${r}</a>`),o=o.replace(/\*\*(.*?)\*\*/g,"<strong>$1</strong>"),o=o.replace(/\*(.*?)\*/g,"<em>$1</em>"),o=o.replace(/~~(.*?)~~/g,"<del>$1</del>"),o=o.replace(/`([^`]+)`/g,"<code>$1</code>"),o=o.replace(/%%SAFE_HTML_(\d+)%%/g,(s,l)=>{const r=parseInt(l,10);return i[r]||""}),o}function Km(e,t="pdf-table"){if(e.length<2)return"";const i=e.map(a=>a.trim().replace(/^\|/,"").replace(/\|$/,"").split("|").map(c=>c.trim())),n=i[0];let o=[],s=1;e.length>=2&&i[1].every(a=>/^:?-+:?$/.test(a))&&(o=i[1].map(a=>a.startsWith(":")&&a.endsWith(":")?"center":a.endsWith(":")?"right":"left"),s=2);const l=`<thead><tr>${n.map((a,c)=>`<th${o[c]?` style="text-align: ${o[c]}"`:""}>${rt(a)}</th>`).join("")}</tr></thead>`,r=i.slice(s).map(a=>`<tr>${a.map((c,d)=>`<td${o[d]?` style="text-align: ${o[d]}"`:""}>${rt(c)}</td>`).join("")}</tr>`).join("");return`<table class="${t}">${l}<tbody>${r}</tbody></table>`}function ts(e){return String(e||"").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;")}function jr(e,t="ts"){if(!e)return"";if(e.trim().startsWith("//"))return`<span class="token-comment">${ts(e)}</span>`;const i=[];function n(s,l){return i.push(`<span class="${s}">${ts(l)}</span>`),`__TOK_${i.length-1}__`}let o=e.replace(/(['"`])(.*?)\1/g,(s,l,r)=>n("token-string",`${l}${r}${l}`));return o=o.replace(/\b(import|export|from|const|let|var|function|return|default|type|interface|class|new|async|await)\b/g,s=>n("token-keyword",s)),o=o.replace(/\b(computed|ref|number|string|boolean|void|Array)\b/g,s=>n("token-type",s)),o=o.replace(/\b(\d+)\b/g,s=>n("token-number",s)),o=ts(o),o=o.replace(/__TOK_(\d+)__/g,(s,l)=>i[parseInt(l,10)]||""),o}function qm(e,t){if(!e)return null;const i=e.frontmatter||{};if(i.hideInToc===!0||i.hideInToc==="true")return null;let n=(i.title||"").trim(),o=i.level?parseInt(i.level,10):0;if(!n){const s=e.blocks||[];for(const l of s){const a=(l.rawMarkdown||l.content||"").trim().match(/^(#{1,6})\s+(.*)$/);if(a){o||(o=a[1].length),n=a[2].trim();break}}}return n?((!o||isNaN(o))&&(o=1),{pageIndex:e.pageIndex||t,title:n,level:o}):null}function Gm(e,t=1,i={}){const n=i.minDepth!==void 0?Number(i.minDepth):1,o=i.maxDepth!==void 0?Number(i.maxDepth):1/0,s=[];Array.isArray(e)&&e.forEach((c,d)=>{const p=qm(c,d+1);p&&s.push(p)});const l=[];let r=null;for(const c of s){const d={...c,active:c.pageIndex===t,hasActiveChild:!1,children:[]};c.level===1||l.length===0?(l.push(d),r=d):r?(d.active&&(r.hasActiveChild=!0),r.children.push(d)):l.push(d)}function a(c,d=1){if(d>o)return[];const p=[];for(const b of c){const u=a(b.children,d+1);d>=n?p.push({...b,children:u}):p.push(...u)}return p}return a(l,1)}function Zm(e,t=1,i={}){const n=Gm(e,t,i),o=i.columns?Number(i.columns):1,s=o>1?` style="column-count: ${o};"`:"",l=i.textSm?" text-sm":"";function r(c,d=1){if(!c||c.length===0)return"";const p=`slidev-toc-list slidev-toc-list-level-${d}`,b=c.map(u=>{const h=u.active?" slidev-toc-item-active":u.hasActiveChild?" slidev-toc-item-parent-active":"",f=u.children&&u.children.length>0?r(u.children,d+1):"";let g=rt(u.title);return g.includes("LaTeX")&&(g=g.replace(/\$\\LaTeX\$/g,'<span class="font-math">L<sup>A</sup>T<sub>E</sub>X</span>')),`
        <li class="slidev-toc-item${h}" data-page="${u.pageIndex}">
          <a class="slidev-toc-link" href="javascript:void(0)">
            <span class="slidev-toc-title">${g}</span>
          </a>
          ${f}
        </li>
      `}).join("");return`<ol class="${p}">${b}</ol>`}const a=r(n,1);return`<div class="slidev-toc${l}"${s}>${a}</div>`}function fi(e,t){var C,T,B,I,w,P,R,z,V,_;let i="",n="",o="";const s=[];(C=e.motion)!=null&&C.preset&&e.motion.preset!=="none"&&(i=` slidev-motion-${e.motion.preset.toLowerCase()}`,typeof e.motion.duration=="number"&&e.motion.duration>0&&s.push(`--motion-duration:${e.motion.duration}ms`),typeof e.motion.delay=="number"&&e.motion.delay>0&&s.push(`--motion-delay:${e.motion.delay}ms`));const l=((T=e.attributes)==null?void 0:T.style)||"";l&&(s.push(l),o=" slide-styled-block"),s.length>0&&(n=` style="${at(s.join(";"))}"`);const r=(t==null?void 0:t.containerClassName)||"pdf-block",a=t!=null&&t.extraClassName?` ${t.extraClassName}`:"",c=`${r}${i}${o}${a}`,d=(e.rawMarkdown||e.content||"").trim();if(!d)return`<div class="${c}"${n}></div>`;if(d.includes('class="slidev-block-ref"')||d.includes('class="slidev-ref-tag"'))return`<div class="${c}"${n}>${d}</div>`;if(d.startsWith("$$")&&d.endsWith("$$")){const L=d.slice(2,-2).trim();return`<div class="${c} katex-display-container"${n}><div class="katex-display font-math"><em>${at(L)}</em></div></div>`}const p=d.match(/^(#{1,6})\s+(.*)$/);if(p){const L=p[1].length,y=rt(p[2]),F=!!(e.isColFirst||e.type==="i"&&((B=t==null?void 0:t.extraClassName)!=null&&B.includes("slidev-col-first-heading-block")))?' class="slide-list-item-title"':"";return`<div class="${c}"${n}><h${L}${F}>${y}</h${L}></div>`}if(d.startsWith(":::")){const L=d.split(`
`),A=L[0].replace(/^:::\s*/,"").trim()||"info",F=L.slice(1,L[L.length-1].startsWith(":::")?-1:void 0).join(`
`),E=(t==null?void 0:t.calloutClassName)||"pdf-callout";return`<div class="${c}"${n}><div class="${E} ${E}--${A}"><div class="${E}-title">${A.toUpperCase()}</div><div class="${E}-body">${rt(F)}</div></div></div>`}if(d.startsWith("<<<")){const A=`// Inside ./snippets/external.ts
export function emptyArray<T>(length: number) {
  return Array.from<T>({ length })
}`.split(`
`).map((N,X)=>`<span class="code-line shiki-focus"><span class="line-no">${X+1}</span><span class="line-content">${jr(N,"ts")}</span></span>`).join(`
`),F=(t==null?void 0:t.codeClassName)||"pdf-code shiki-container",E=((I=e.attrs)==null?void 0:I["custom-slidev-max-height"])||e.maxHeight||"",D=E?` style="max-height:${at(E)};overflow-y:auto;"`:"";return`<div class="${c}"${n}><pre class="${F}"${D}><span class="lang-badge">TS</span><code>${A}</code></pre></div>`}if(d.startsWith("<style")||d.startsWith("<!-- Inline style -->")||d.startsWith(`<!--
Notes`))return"";if(d.startsWith("```")){const L=d.split(`
`),y=L[0].slice(3).trim(),A=y.match(/^([^\s{\[]+)/),F=A?A[1]:"",E=y.match(/\[([^\]]+)\]/),D=E?E[1]:"",N=y.includes("twoslash"),X=e.shikiLines||((w=y.match(/\{([^}]+)\}/))==null?void 0:w[1])||"",j=Um(X),G=L.length>2?L[L.length-1]==="```"?L.slice(1,-1):L.slice(1):[d.slice(3).replace(/```$/,"")],ne=(t==null?void 0:t.codeClassName)||"pdf-code shiki-container",se=D?`${ne} has-filename`:ne,le=j!=="all",pe=G.map((ve,O)=>{const W=O+1,K=j==="all"||j.has(W)?"code-line shiki-focus":le?"code-line shiki-dimmed":"code-line";let $=(t==null?void 0:t.highlight)===!0?jr(ve,F):at(ve);return N&&ve.includes("doubled.value = 2")?($=$.replace(/(\bvalue\b)/,'<span class="twoslash-error-wavy">$1</span>'),`<span class="${K}"><span class="line-no">${W}</span><span class="line-content">${$}</span></span>
<div class="twoslash-popup-error"><span style="color:#ef4444;font-weight:bold;margin-right:4px;">✕</span> Cannot assign to 'value' because it is a read-only property.</div>`):`<span class="${K}"><span class="line-no">${W}</span><span class="line-content">${$}</span></span>`}).join(`
`),Te=F?`<span class="lang-badge">${at(F)}</span>`:"",be=D?`<span class="code-filename">${at(D)}</span>`:"",q=((P=e.attrs)==null?void 0:P["custom-slidev-max-height"])||e.maxHeight||"",ae=q?` style="max-height:${at(q)};overflow-y:auto;"`:"";return`<div class="${c}"${n}><pre class="${se}"${ae}>${be}${Te}<code>${pe}</code></pre></div>`}if(d.includes("|")&&d.split(`
`).filter(L=>L.trim().startsWith("|")).length>=2){const L=d.split(`
`).filter(A=>A.trim().startsWith("|")),y=Km(L,t==null?void 0:t.tableClassName);return`<div class="${c}"${n}>${y}</div>`}if(d.startsWith("> ")){const L=(t==null?void 0:t.quoteClassName)||"pdf-quote";return`<div class="${c}"${n}><blockquote class="${L}"><p>${rt(d.slice(2))}</p></blockquote></div>`}const b=/<video\b/i.test(d)||e.type==="video"||e.type==="NodeVideo",u=/^(\s*)([-*+]|\d+\.)\s+/m.test(d),h=/(?:^|\n)\s*#{1,6}\s+/.test(d);if(b&&!u&&!h&&!d.includes(`
`)){const L=((R=e.attributes)==null?void 0:R["custom-slidev-autoplay"])==="true"||/autoplay/i.test(d),y=((z=e.attributes)==null?void 0:z["custom-slidev-loop"])==="true"||/loop/i.test(d),A=((V=e.attributes)==null?void 0:V["custom-slidev-muted"])==="true"||L||/muted/i.test(d),F=((_=e.attributes)==null?void 0:_["custom-slidev-controls"])==="false",E=d.match(/\bsrc=["']([^"']+)["']/i),D=E?E[1]:"",N=['class="slide-video-player"'];F||N.push("controls"),L&&(N.push("autoplay"),N.push("playsinline")),y&&N.push("loop"),A&&N.push("muted"),N.push('preload="metadata"'),D&&N.push(`src="${D}"`);const X=d.match(/<video[^>]*>([\s\S]*?)<\/video>/i);let j=X?X[1].trim():"";return!j&&D&&(j=`<source src="${D}" type="video/mp4" />您的浏览器不支持视频播放。`),`<div class="${c} ${c}--video slide-media-block slide-video-container slide-media-container" data-autoplay="${L?"true":"false"}" data-muted="${A?"true":"false"}"${n}><video ${N.join(" ")}>${j}</video></div>`}const f=d.match(/^!\[(.*?)\]\((.*?)\)$/);if(f){const L=(t==null?void 0:t.imageClassName)||"pdf-image slide-media-img";return`<div class="${c} ${c}--image slide-media-block slide-media-container"${n}><img alt="${at(f[1])}" src="${f[2]}" class="${L}" /></div>`}const g=$a(d,t,e);if(g)return`<div class="${c} pdf-list-item"${n}>${g}</div>`;if(/<(?:Toc|toc)\b/i.test(d)&&!d.startsWith("```")){const L=d.match(/minDepth=["']?(\d+)["']?/i),y=d.match(/maxDepth=["']?(\d+)["']?/i),A=d.match(/columns=["']?(\d+)["']?/i),F=(t==null?void 0:t.allSlides)||[];return`<div class="${c}"${n}>${Zm(F,(t==null?void 0:t.currentPageIndex)||1,{minDepth:L?parseInt(L[1],10):1,maxDepth:y?parseInt(y[1],10):1/0,columns:A?parseInt(A[1],10):1,textSm:d.includes("text-sm")})}</div>`}if(d.includes(`
`)||h){const L=jm(d,t,e);if(L)return`<div class="${c}"${n}>${L}</div>`}const S=!!e.isColFirst?' class="slide-list-item-title"':"";return`<div class="${c}"${n}><p${S}>${rt(d)}</p></div>`}function Ym(e){return`
    ${_n(e)}

    :root {
      --slide-bg: #ffffff;
      --slide-text: #1a1a1a;
      --slide-accent: #3b82f6;
      --slide-font: system-ui, -apple-system, sans-serif;
    }
    [data-theme="dark"] {
      --slide-bg: #121214;
      --slide-text: #e2e8f0;
      --slide-accent: #60a5fa;
    }

    /* 1. 默认科技主题 Default */
    [data-slidev-theme="default"],
    .slidev-theme-default {
      --slide-font: system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "PingFang SC", "Microsoft YaHei", sans-serif;
      --slide-accent: #10b981;
    }
    [data-theme="light"][data-slidev-theme="default"],
    [data-theme="light"] .slidev-theme-default {
      --slide-bg: #ffffff;
      --slide-text: #1e293b;
      --slide-accent: #059669;
    }
    [data-theme="dark"][data-slidev-theme="default"],
    [data-theme="dark"] .slidev-theme-default {
      --slide-bg: #121214;
      --slide-text: #e2e8f0;
      --slide-accent: #34d399;
    }
    .slidev-theme-default .layout-cover h1,
    .slidev-theme-default .layout-cover .slide-block h1 {
      font-size: 3.8rem !important;
      font-weight: 800 !important;
      line-height: 1.15 !important;
      letter-spacing: -0.025em !important;
      margin-bottom: 18px !important;
      background: linear-gradient(135deg, #10b981, #06b6d4) !important;
      -webkit-background-clip: text !important;
      -webkit-text-fill-color: transparent !important;
    }
    .slidev-theme-default .layout-cover h2,
    .slidev-theme-default .layout-cover .slide-block h2 {
      font-size: 1.85rem !important;
      font-weight: 600 !important;
      opacity: 0.85 !important;
      margin-bottom: 12px !important;
    }
    .slidev-theme-default .layout-cover p,
    .slidev-theme-default .layout-cover .slide-block p {
      font-size: 1.45rem !important;
      line-height: 1.5 !important;
      opacity: 0.85 !important;
    }

    /* 2. 优雅衬线主题 Seriph */
    [data-slidev-theme="seriph"],
    .slidev-theme-seriph {
      --slide-font: "PT Serif", "Charter", "Georgia", "Cambria", "Times New Roman", "Source Han Serif SC", "Noto Serif SC", "Songti SC", "SimSun", serif;
      --slide-accent: #b45309;
      letter-spacing: 0.015em;
    }
    [data-theme="light"][data-slidev-theme="seriph"],
    [data-theme="light"] .slidev-theme-seriph {
      --slide-bg: #fdfbf7;
      --slide-text: #2a2521;
      --slide-accent: #b45309;
    }
    [data-theme="dark"][data-slidev-theme="seriph"],
    [data-theme="dark"] .slidev-theme-seriph {
      --slide-bg: #1c1a17;
      --slide-text: #e8e3d9;
      --slide-accent: #f59e0b;
    }
    .slidev-theme-seriph,
    .slidev-theme-seriph .slide-content {
      font-family: var(--slide-font) !important;
      line-height: 1.72;
    }
    .slidev-theme-seriph h1,
    .slidev-theme-seriph h2,
    .slidev-theme-seriph h3 {
      font-family: var(--slide-font) !important;
      letter-spacing: 0.025em;
      font-weight: 700;
    }
    .slidev-theme-seriph .layout-cover h1 {
      background: none !important;
      -webkit-background-clip: initial !important;
      -webkit-text-fill-color: initial !important;
      color: var(--slide-accent) !important;
      font-size: 3.4rem !important;
      border-bottom: 2px solid var(--slide-accent);
      display: inline-block;
      padding-bottom: 10px;
    }

    /* 3. 极简发布会主题 Apple Basic */
    [data-slidev-theme="apple-basic"],
    .slidev-theme-apple-basic {
      --slide-font: -apple-system, "SF Pro Display", "SF Pro Text", BlinkMacSystemFont, "PingFang SC", "Helvetica Neue", sans-serif;
      --slide-accent: #0071e3;
    }
    [data-theme="light"][data-slidev-theme="apple-basic"],
    [data-theme="light"] .slidev-theme-apple-basic {
      --slide-bg: #ffffff;
      --slide-text: #1d1d1f;
      --slide-accent: #0071e3;
    }
    [data-theme="dark"][data-slidev-theme="apple-basic"],
    [data-theme="dark"] .slidev-theme-apple-basic {
      --slide-bg: #000000;
      --slide-text: #f5f5f7;
      --slide-accent: #2997ff;
    }
    .slidev-theme-apple-basic,
    .slidev-theme-apple-basic .slide-content {
      font-family: var(--slide-font) !important;
    }
    .slidev-theme-apple-basic h1,
    .slidev-theme-apple-basic h2,
    .slidev-theme-apple-basic h3 {
      letter-spacing: -0.035em;
      font-weight: 800;
    }
    .slidev-theme-apple-basic .layout-cover h1 {
      background: none !important;
      -webkit-background-clip: initial !important;
      -webkit-text-fill-color: initial !important;
      color: var(--slide-text) !important;
      font-size: 3.8rem !important;
      letter-spacing: -0.04em !important;
    }
    .slidev-theme-apple-basic .layout-cover p {
      color: #86868b !important;
      font-size: 1.35rem !important;
    }

    * { box-sizing: border-box; margin: 0; padding: 0; }
    html, body {
      width: 100%; height: 100%; overflow: hidden;
      background: #0f1115; font-family: var(--slide-font);
      display: flex; justify-content: center; align-items: center;
    }
    #app { width: 100%; height: 100%; position: relative; overflow: hidden; }
    .slide-viewport {
      position: absolute; left: 50%; top: 50%;
      background: var(--slide-bg); color: var(--slide-text);
      box-shadow: 0 10px 30px rgba(0,0,0,0.5); border-radius: 8px; overflow: hidden;
      display: flex; flex-direction: column; flex-shrink: 0;
      transform: translate(-50%, -50%) scale(var(--slidev-slide-scale, 1));
      transform-origin: center center; will-change: transform;
      transition: background 0.3s ease, color 0.3s ease, border-radius 0.2s ease, box-shadow 0.2s ease;
    }
    :fullscreen .slide-viewport, .is-fullscreen .slide-viewport {
      border-radius: 0 !important; box-shadow: none !important;
    }
    .slide-content {
      position: relative;
      width: 100%;
      height: 100%;
      min-height: 100%;
      flex: 1 1 0%;
      padding: var(--slidev-padding-y, 32px) var(--slidev-padding-x, 48px);
      display: flex;
      flex-direction: column;
      overflow: hidden;
      box-sizing: border-box;
    }

    /* 间距预设风格 */
    .slide-content.spacing-compact,
    .slide-viewport[data-spacing="compact"] .slide-content,
    [data-slidev-spacing="compact"] {
      --slidev-padding-y: 20px;
      --slidev-padding-x: 36px;
      --slidev-header-gap: 10px;
      --slidev-title-margin-bottom: 6px;
    }
    .slide-content.spacing-normal,
    .slide-viewport[data-spacing="normal"] .slide-content,
    [data-slidev-spacing="normal"] {
      --slidev-padding-y: 32px;
      --slidev-padding-x: 48px;
      --slidev-header-gap: 16px;
      --slidev-title-margin-bottom: 10px;
    }
    .slide-content.spacing-loose,
    .slide-viewport[data-spacing="loose"] .slide-content,
    [data-slidev-spacing="loose"] {
      --slidev-padding-y: 48px;
      --slidev-padding-x: 56px;
      --slidev-header-gap: 24px;
      --slidev-title-margin-bottom: 16px;
    }

    .layout-cover { justify-content: center; align-items: center; text-align: center; }
    .layout-cover h1, .layout-cover .slide-block h1 { font-size: 3.8rem !important; font-weight: 800 !important; line-height: 1.15 !important; letter-spacing: -0.025em !important; margin-bottom: 16px !important; }
    .layout-cover h2, .layout-cover .slide-block h2 { font-size: 1.85rem !important; font-weight: 600 !important; opacity: 0.85 !important; margin-bottom: 12px !important; }
    .layout-cover p, .layout-cover .slide-block p { font-size: 1.45rem !important; line-height: 1.5 !important; opacity: 0.85 !important; }
    .two-cols-left, .two-cols-right { min-width: 0; width: 100%; display: flex; flex-direction: column; box-sizing: border-box; overflow-wrap: break-word; word-break: break-word; }
    .pdf-two-cols-wrapper,
    .layout-two-cols-grid,
    .layout-cols-wrapper,
    .layout-cols-grid {
      display: grid;
      grid-template-columns: var(--slide-grid-cols, minmax(0, 1fr) minmax(0, 1fr));
      grid-template-rows: minmax(0, 1fr) !important;
      gap: 32px;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      overflow: hidden !important;
    }
    .layout-cols-header-container,
    .layout-two-cols-header-container,
    .layout-three-cols-header-container,
    .layout-clover-container {
      display: flex;
      flex-direction: column;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      overflow: hidden !important;
    }
    .layout-header-section {
      width: 100%;
      margin-bottom: var(--slidev-header-gap, 16px) !important;
      flex-shrink: 0;
    }
    .layout-header-section h1,
    .layout-header-section h2,
    .layout-header-section h3 {
      margin-bottom: var(--slidev-title-margin-bottom, 10px) !important;
    }
    .pdf-three-cols-wrapper,
    .layout-three-cols-grid {
      display: grid;
      grid-template-columns: var(--slide-grid-cols, minmax(0, 1fr) minmax(0, 1fr) minmax(0, 1fr));
      grid-template-rows: minmax(0, 1fr) !important;
      gap: 24px;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      box-sizing: border-box;
      overflow: hidden !important;
    }
    .pdf-clover-wrapper,
    .layout-clover-grid {
      display: grid;
      grid-template-columns: repeat(2, minmax(0, 1fr)) !important;
      grid-template-rows: repeat(2, minmax(0, 1fr)) !important;
      gap: 20px;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      box-sizing: border-box;
      overflow: hidden !important;
    }
    .layout-clover-grid .pdf-col {
      background: transparent !important;
      border: none !important;
      box-shadow: none !important;
    }
    .pdf-col {
      display: flex;
      flex-direction: column;
      gap: 14px;
      min-width: 0;
      width: 100%;
      max-width: 100%;
      height: 100%;
      max-height: 100%;
      min-height: 0;
      justify-content: flex-start;
      box-sizing: border-box;
      overflow: hidden;
      overflow-wrap: break-word;
      word-break: break-word;
      white-space: normal;
    }
    .pdf-col * {
      overflow-wrap: break-word;
      word-break: break-word;
      box-sizing: border-box;
    }
    /* 表头多栏内超级块子块首个列表项去圆点后居中显示标题/首行文本 (仅在存在超级块分栏时生效) */
    .has-superblock-cols .pdf-col > *:first-child .slide-list-item-title,
    .has-superblock-cols .pdf-col > *:first-child :is(h1, h2, h3, h4, h5, h6),
    .has-superblock-cols .pdf-col > *:first-child p.slide-list-item-title,
    .has-superblock-cols .pdf-col > *:first-child p:first-of-type,
    .has-superblock-cols .pdf-col > *:first-child p:first-child,
    .has-superblock-cols .pdf-col > *:first-child :is(ul, ol) > li:first-child,
    .has-superblock-cols .pdf-col > *:first-child .slide-list > .slide-list-item:first-child,
    .has-superblock-cols .pdf-col > *:first-child .pdf-list > li:first-child,
    .has-superblock-cols .slidev-col-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    .has-superblock-cols .slidev-col-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      list-style: none !important;
      list-style-type: none !important;
      text-align: center !important;
      margin-left: 0 !important;
      padding-left: 0 !important;
      width: 100% !important;
    }

    /* 彻底清除首个列表项的原生圆点 Marker (仅在存在超级块分栏时生效) */
    .has-superblock-cols .pdf-col > *:first-child :is(ul, ol) > li:first-child::marker {
      content: "" !important;
      display: none !important;
    }

    /* 确保首个列表项内部内联与块级元素居中 (仅在存在超级块分栏时生效) */
    .has-superblock-cols .pdf-col > *:first-child :is(ul, ol) > li:first-child * {
      text-align: center !important;
    }

    /* 栏内说明段落与列表项：左对齐，自然阅读排版 */
    .has-superblock-cols .pdf-col .slide-list-item-desc,
    .has-superblock-cols .pdf-col li:not(:first-child) {
      text-align: left !important;
    }

    /* 全局特定标题大小规范化 (除封面外页首首个标题按 H2 1.7rem，表头多栏内首个标题按 H3 1.3rem) */
    [data-normalize-headings="true"] .slidev-page-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .slidev-page-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .slide-content:not(.layout-cover) > :is(.pdf-block, .slide-block):first-child :is(h1, h2, h3, h4, h5, h6),
    [data-normalize-headings="true"] .slide-content:not(.layout-cover) > .layout-header-section :is(.pdf-block, .slide-block):first-child :is(h1, h2, h3, h4, h5, h6),
    [data-normalize-headings="true"] .slide-content:not(.layout-cover) > :not(.layout-cols-wrapper):not(.pdf-two-cols-wrapper):not(.layout-image-cols-grid):first-child :is(h1, h2, h3, h4, h5, h6) {
      font-size: 1.7rem !important;
      font-weight: 600 !important;
      line-height: 1.25 !important;
      margin-bottom: 10px !important;
    }

    [data-normalize-headings="true"] .has-superblock-cols .slidev-col-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .has-superblock-cols .slidev-col-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .has-superblock-cols .pdf-col > *:first-child :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      font-size: 1.3rem !important;
      font-weight: 600 !important;
      line-height: 1.3 !important;
      margin-bottom: 8px !important;
      text-align: center !important;
    }

    /* 图左与图右版式标题完全保留用户原始字号与默认排版，不进行任何固定大小规范化 */
    [data-normalize-headings="true"] :is(.layout-image-left, .layout-image-right, .image-left-content, .image-right-content) :is(h1, h2, h3, h4, h5, h6) {
      text-align: left !important;
    }
    .pdf-col pre,
    .two-cols-left pre,
    .two-cols-right pre,
    .image-right-content pre,
    .image-left-content pre {
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      overflow-x: hidden !important;
      overflow-y: auto !important;
      max-width: 100% !important;
      box-sizing: border-box !important;
    }
    .slide-content.layout-image-right, .slide-content.layout-image-left {
      padding: 0;
      display: grid;
      grid-template-columns: var(--slide-grid-cols, minmax(0, 1fr) minmax(0, 1fr));
      grid-template-rows: 100%;
      width: 100%;
      height: 100%;
      position: absolute;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      box-sizing: border-box;
    }
    .image-right-content, .image-left-content {
      padding: 44px 50px;
      display: flex;
      flex-direction: column;
      justify-content: flex-start;
      overflow-y: auto;
      width: 100%;
      height: 100%;
      box-sizing: border-box;
    }
    .image-right-img-container, .image-left-img-container {
      width: 100%;
      height: 100%;
      overflow: hidden;
      position: relative;
      background: #18181b;
      display: flex;
      align-items: center;
      justify-content: center;
    }
    .image-right-img, .image-left-img {
      width: 100%;
      height: 100%;
      object-fit: cover;
      object-position: center;
      display: block;
    }
    .slide-block { margin-bottom: 14px; line-height: 1.6; }
    .slide-block h1 { font-size: 2.2rem; margin-bottom: 12px; }
    .slide-block h2 { font-size: 1.7rem; margin-bottom: 10px; }
    .slide-block p { font-size: 1.15rem; }
    .slide-block ul, .slide-block ol, .pdf-list {
      padding-left: 28px;
      margin: 8px 0;
      display: flex;
      flex-direction: column;
      gap: 6px;
    }
    .slide-block li, .pdf-list li {
      font-size: 1.15rem;
      line-height: 1.6;
    }
    .pdf-task-item {
      list-style: none;
      margin-left: -20px;
      display: flex;
      align-items: center;
      gap: 8px;
    }
    .pdf-task-item input[type="checkbox"] {
      width: 1.15em;
      height: 1.15em;
      cursor: pointer;
    }

    /* 两栏与三栏及多栏（超级块分栏）布局：紧凑自然行距，子列表保留圆点与层级缩进 */
    .layout-two-cols ul,
    .layout-cols-header ul,
    .layout-two-cols-header ul,
    .layout-three-cols ul,
    .layout-three-cols-header ul,
    .two-cols-left ul,
    .two-cols-right ul,
    .three-cols-col ul,
    .col ul,
    .pdf-col ul,
    .layout-two-cols-grid .pdf-list,
    .layout-three-cols-grid .pdf-list,
    .layout-cols-grid .pdf-list,
    .layout-two-cols-grid .pdf-list--unordered,
    .layout-three-cols-grid .pdf-list--unordered,
    .layout-cols-grid .pdf-list--unordered {
      list-style: disc !important;
      list-style-type: disc !important;
      padding-left: 1.25em !important;
      margin-left: 0 !important;
      margin-top: 0 !important;
      margin-bottom: 8px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: block !important;
    }

    .layout-two-cols ol,
    .layout-cols-header ol,
    .layout-two-cols-header ol,
    .layout-three-cols ol,
    .layout-three-cols-header ol,
    .two-cols-left ol,
    .two-cols-right ol,
    .three-cols-col ol,
    .col ol,
    .pdf-col ol,
    .layout-two-cols-grid .pdf-list--ordered,
    .layout-three-cols-grid .pdf-list--ordered,
    .layout-cols-grid .pdf-list--ordered {
      list-style: decimal !important;
      list-style-type: decimal !important;
      padding-left: 1.25em !important;
      margin-left: 0 !important;
      margin-top: 0 !important;
      margin-bottom: 8px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: block !important;
    }

    .layout-two-cols li,
    .layout-cols-header li,
    .layout-two-cols-header li,
    .layout-three-cols li,
    .layout-three-cols-header li,
    .two-cols-left li,
    .two-cols-right li,
    .three-cols-col li,
    .col li,
    .pdf-col li,
    .pdf-col .pdf-list-item {
      padding-left: 0.2em !important;
      margin-left: 0 !important;
      margin-bottom: 6px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: list-item !important;
      line-height: 1.6 !important;
    }

    .layout-two-cols ul ul,
    .layout-three-cols ul ul,
    .three-cols-col ul ul,
    .pdf-col ul ul {
      list-style: circle !important;
      list-style-type: circle !important;
      padding-left: 1.25em !important;
      margin-top: 4px !important;
      margin-bottom: 4px !important;
    }

    /* 列表项内嵌标题与说明排版 */
    .slide-list-item-title,
    .pdf-list li > h1,
    .pdf-list li > h2,
    .pdf-list li > h3,
    .pdf-list li > h4,
    .pdf-list li > h5,
    .pdf-list li > h6,
    li > h1.slide-list-item-title,
    li > h2.slide-list-item-title,
    li > h3.slide-list-item-title,
    li > h4.slide-list-item-title {
      margin-top: 2px !important;
      margin-bottom: 6px !important;
      line-height: 1.35 !important;
      font-weight: 700 !important;
    }
    .pdf-list li > h1, li > h1.slide-list-item-title { font-size: 1.6rem !important; }
    .pdf-list li > h2, li > h2.slide-list-item-title { font-size: 1.4rem !important; }
    .pdf-list li > h3, li > h3.slide-list-item-title { font-size: 1.22rem !important; }
    .pdf-list li > h4, li > h4.slide-list-item-title { font-size: 1.1rem !important; }

    /* 全局特定标题大小规范化后置强力锁定 (防止被列表项内部字号覆盖) */
    [data-normalize-headings="true"] .slidev-page-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .slidev-page-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      font-size: 1.7rem !important;
      font-weight: 600 !important;
      line-height: 1.25 !important;
      margin-bottom: 10px !important;
    }
    [data-normalize-headings="true"] .slidev-col-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .slidev-col-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] :is(.layout-cols-wrapper, .pdf-two-cols-wrapper, .layout-cols-header-container, .layout-cols-grid) .pdf-col > *:first-child :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] :is(.two-cols-left, .two-cols-right, .pdf-col, .col) > *:first-child :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      font-size: 1.3rem !important;
      font-weight: 600 !important;
      line-height: 1.3 !important;
      margin-bottom: 8px !important;
      text-align: center !important;
    }
    .slide-list-item-desc,
    .pdf-list li > p {
      margin-top: 4px !important;
      margin-bottom: 6px !important;
      font-size: 1.05rem;
      line-height: 1.55;
      opacity: 0.92;
    }

    /* 多媒体（GIF动图、静态图片、MP4视频）全视口最大化自适应且不超出视口 */
    .slide-media-block,
    .slide-media-container,
    .slide-video-container,
    .slide-block--media,
    .slide-block--image,
    .slide-block--video,
    .slide-block:has(> img),
    .slide-block:has(> .slide-media-container),
    .slide-block:has(> p > img:only-child),
    .slide-block:has(> .slide-video-container),
    .slide-block:has(> video) {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      min-width: 0 !important;
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
      justify-content: center !important;
      width: 100% !important;
      height: 100% !important;
      max-height: 100% !important;
      overflow: hidden !important;
      margin: 4px 0 !important;
      box-sizing: border-box !important;
    }

    .two-cols-left > .slide-block,
    .two-cols-right > .slide-block,
    .three-cols-col > .slide-block,
    .pdf-col > .slide-block,
    .pdf-col .slide-block {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      max-height: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      width: 100% !important;
      height: 100% !important;
      box-sizing: border-box !important;
      overflow: hidden !important;
      margin-bottom: 0 !important;
    }

    /* 列内列表项的标题与段落文字：固定高度，不压缩 */
    .two-cols-left .slide-list-item-title,
    .two-cols-right .slide-list-item-title,
    .three-cols-col .slide-list-item-title,
    .pdf-col .slide-list-item-title,
    .two-cols-left h1, .two-cols-left h2, .two-cols-left h3, .two-cols-left h4, .two-cols-left h5, .two-cols-left h6,
    .two-cols-right h1, .two-cols-right h2, .two-cols-right h3, .two-cols-right h4, .two-cols-right h5, .two-cols-right h6,
    .three-cols-col h1, .three-cols-col h2, .three-cols-col h3, .three-cols-col h4, .three-cols-col h5, .three-cols-col h6,
    .pdf-col h1, .pdf-col h2, .pdf-col h3, .pdf-col h4, .pdf-col h5, .pdf-col h6,
    .three-cols-col .slide-list-item-desc,
    .pdf-col .slide-list-item-desc {
      flex: 0 0 auto !important;
      margin-top: 0 !important;
      margin-bottom: 6px !important;
    }

    /* 列内媒体容器：填满标题下方所有剩余垂直空间，纵向顶部对齐，横向居中，无溢出 */
    .two-cols-left .slide-list-media,
    .two-cols-right .slide-list-media,
    .three-cols-col .slide-list-media,
    .pdf-col .slide-list-media,
    .two-cols-left .slide-video-container,
    .two-cols-right .slide-video-container,
    .three-cols-col .slide-video-container,
    .pdf-col .slide-video-container,
    .two-cols-left .slide-media-container,
    .two-cols-right .slide-media-container,
    .three-cols-col .slide-media-container,
    .pdf-col .slide-media-container {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      min-width: 0 !important;
      width: 100% !important;
      height: 100% !important;
      max-height: 100% !important;
      max-width: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
      justify-content: flex-start !important;
      overflow: hidden !important;
      margin: 0 !important;
      padding: 0 !important;
      box-sizing: border-box !important;
    }

    /* 列内多媒体播放器：以 contain 模式等比缩放完整可见，绝对不超高超宽、不产生遮挡与滚动条 */
    .two-cols-left video,
    .two-cols-right video,
    .three-cols-col video,
    .pdf-col video,
    .two-cols-left img,
    .two-cols-right img,
    .three-cols-col img,
    .pdf-col img,
    .two-cols-left .slide-video-player,
    .two-cols-right .slide-video-player,
    .three-cols-col .slide-video-player,
    .pdf-col .slide-video-player,
    .layout-three-cols-grid video,
    .layout-two-cols-grid video,
    .layout-three-cols-grid img,
    .layout-two-cols-grid img {
      max-width: 100% !important;
      max-height: 100% !important;
      width: auto !important;
      height: auto !important;
      min-width: 0 !important;
      min-height: 0 !important;
      object-fit: contain !important;
      display: block !important;
      margin: 0 auto !important;
      cursor: zoom-in;
    }

    .slide-block img,
    .slide-media-img,
    .slide-media-container img,
    .slide-video-player,
    video.slide-video-player,
    .slide-block video {
      max-width: 100% !important;
      max-height: 100% !important;
      width: auto !important;
      height: auto !important;
      min-width: 0 !important;
      min-height: 0 !important;
      object-fit: contain !important;
      display: block !important;
      margin: 0 auto !important;
      border-radius: 8px;
      box-shadow: 0 4px 16px rgba(0, 0, 0, 0.16);
      background: transparent;
      outline: none;
      cursor: zoom-in;
    }

    .slide-list-media {
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
      justify-content: flex-start !important;
      width: 100% !important;
      max-width: 100% !important;
      height: 100% !important;
      max-height: 100% !important;
      flex: 1 1 0% !important;
      margin-top: 4px !important;
      margin-bottom: 4px !important;
      min-height: 0 !important;
      overflow: hidden !important;
      box-sizing: border-box !important;
    }
    .slide-list-media img,
    .slide-list-media video,
    .slide-list-media .list-item-gif,
    .slide-list-media .slide-video-player {
      max-width: 100% !important;
      max-height: 100% !important;
      width: auto !important;
      height: auto !important;
      min-width: 0 !important;
      min-height: 0 !important;
      object-fit: contain !important;
      border-radius: 6px !important;
      box-shadow: 0 3px 12px rgba(0, 0, 0, 0.14) !important;
      display: block !important;
      margin: 0 auto !important;
      cursor: zoom-in;
    }

    .slide-block:has(.slide-list-media) {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      height: 100% !important;
      max-height: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      overflow: hidden !important;
    }
    .slide-block:has(.slide-list-media) .pdf-list,
    .slide-block:has(.slide-list-media) ul,
    .slide-block:has(.slide-list-media) ol {
      display: block !important;
      flex: 1 1 auto;
      min-height: 0;
      max-height: 100%;
      overflow: visible !important;
      list-style: disc !important;
      list-style-type: disc !important;
    }
    .slide-block:has(.slide-list-media) li,
    .slide-block:has(.slide-list-media) .slide-list-item,
    .slide-block:has(.slide-list-media) .pdf-list-item,
    .slide-block:has(.slide-media-container) li,
    .slide-block:has(.slide-video-container) li,
    .layout-cols-wrapper li:has(.slide-list-media),
    .layout-cols-header-container li:has(.slide-list-media),
    .two-cols-left li:has(.slide-list-media),
    .two-cols-right li:has(.slide-list-media),
    .three-cols-col li:has(.slide-list-media),
    .pdf-col li:has(.slide-list-media),
    li:has(.slide-list-media),
    li:has(.slide-video-container),
    li:has(.slide-media-container) {
      display: list-item !important;
      list-style-type: disc !important;
      flex: 0 0 auto !important;
      height: auto !important;
      max-height: none !important;
      overflow: visible !important;
      margin-bottom: 6px !important;
    }

    .layout-two-cols .slide-media-block,
    .layout-two-cols .slide-video-container,
    .layout-two-cols .slide-media-container,
    .layout-three-cols .slide-media-block,
    .layout-three-cols .slide-video-container,
    .layout-three-cols .slide-media-container {
      max-width: 100% !important;
      max-height: 100% !important;
      width: 100% !important;
      height: 100% !important;
      min-width: 0 !important;
      min-height: 0 !important;
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
      justify-content: flex-start !important;
      overflow: hidden !important;
    }

    /* Lightbox 大图与视频灯箱模态窗口 */
    .slidev-lightbox {
      position: fixed;
      top: 0;
      left: 0;
      width: 100vw;
      height: 100vh;
      background: rgba(0, 0, 0, 0.88);
      backdrop-filter: blur(8px);
      z-index: 999999;
      display: none;
      align-items: center;
      justify-content: center;
      cursor: zoom-out;
      opacity: 0;
      transition: opacity 0.2s cubic-bezier(0.16, 1, 0.3, 1);
    }
    .slidev-lightbox.active {
      display: flex;
      opacity: 1;
    }
    .slidev-lightbox-content {
      position: relative;
      max-width: 92vw;
      max-height: 92vh;
      display: flex;
      align-items: center;
      justify-content: center;
      cursor: default;
    }
    .slidev-lightbox-img {
      max-width: 92vw;
      max-height: 92vh;
      object-fit: contain;
      border-radius: 8px;
      box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.75);
    }
    .slidev-lightbox-video {
      max-width: 92vw;
      max-height: 92vh;
      border-radius: 8px;
      box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.75);
    }
    .slidev-lightbox-close {
      position: absolute;
      top: 24px;
      right: 28px;
      width: 40px;
      height: 40px;
      background: rgba(255, 255, 255, 0.2);
      border: 1px solid rgba(255, 255, 255, 0.35);
      border-radius: 50%;
      color: #fff;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 22px;
      cursor: pointer;
      transition: background 0.2s, transform 0.2s;
      z-index: 1000000;
    }
    .slidev-lightbox-close:hover {
      background: rgba(255, 255, 255, 0.35);
      transform: scale(1.05);
    }

    img.slide-inline-img {
      max-width: 100% !important;
      max-height: min(320px, 40vh) !important;
      object-fit: contain !important;
      vertical-align: middle;
      border-radius: 4px;
    }
    kbd {
      display: inline-block;
      padding: 2px 7px;
      font-family: ui-monospace, SFMono-Regular, "SF Mono", Menlo, Consolas, "Liberation Mono", monospace;
      font-size: 0.85em;
      font-weight: 600;
      line-height: 1.25;
      color: inherit;
      background: rgba(125, 125, 125, 0.12);
      border: 1px solid rgba(125, 125, 125, 0.35);
      border-bottom-width: 2px;
      border-radius: 5px;
      box-shadow: 0 1px 2px rgba(0, 0, 0, 0.12);
      margin: 0 2px;
      vertical-align: middle;
      white-space: nowrap;
    }
    [data-theme="dark"] kbd, .theme-dark kbd {
      background: rgba(255, 255, 255, 0.1);
      border-color: rgba(255, 255, 255, 0.25);
      border-bottom-color: rgba(255, 255, 255, 0.4);
      color: #f1f5f9;
      box-shadow: 0 1px 2px rgba(0, 0, 0, 0.4);
    }
    .slide-block pre,
    pre {
      background: rgba(0, 0, 0, 0.1);
      padding: 12px;
      border-radius: 6px;
      font-family: "JetBrains Mono", Consolas, monospace;
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      overflow-x: hidden !important;
      overflow-y: auto !important;
      max-width: 100% !important;
      box-sizing: border-box !important;
    }
    .slide-block pre code,
    pre code {
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      display: block !important;
      width: 100% !important;
      box-sizing: border-box !important;
    }
    .code-line {
      display: flex !important;
      align-items: flex-start !important;
      width: 100% !important;
      box-sizing: border-box !important;
      line-height: 1.6;
    }
    .code-line .line-no {
      display: inline-block !important;
      flex-shrink: 0 !important;
      min-width: 2.2em !important;
      text-align: right !important;
      margin-right: 12px !important;
      user-select: none !important;
      opacity: 0.45 !important;
    }
    .code-line .line-content {
      flex: 1 1 0% !important;
      min-width: 0 !important;
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
    }
    /* 弱提示滚动条样式 */
    * {
      scrollbar-width: thin;
      scrollbar-color: rgba(255, 255, 255, 0.20) transparent;
    }
    *::-webkit-scrollbar {
      width: 4px;
      height: 4px;
    }
    *::-webkit-scrollbar-track {
      background: transparent;
    }
    *::-webkit-scrollbar-thumb {
      background: rgba(255, 255, 255, 0.20);
      border-radius: 2px;
      transition: background 0.2s ease;
    }
    *:hover::-webkit-scrollbar-thumb,
    *::-webkit-scrollbar-thumb:hover {
      background: rgba(255, 255, 255, 0.45);
    }
    /* Slidev Micro-motion Keyframes & Presets */
    @keyframes slidevMotionFadeIn { from { opacity: 0; } to { opacity: 1; } }
    @keyframes slidevMotionSlideUp { from { opacity: 0; transform: translateY(40px); } to { opacity: 1; transform: translateY(0); } }
    @keyframes slidevMotionSlideDown { from { opacity: 0; transform: translateY(-40px); } to { opacity: 1; transform: translateY(0); } }
    @keyframes slidevMotionSlideLeft { from { opacity: 0; transform: translateX(40px); } to { opacity: 1; transform: translateX(0); } }
    @keyframes slidevMotionSlideRight { from { opacity: 0; transform: translateX(-40px); } to { opacity: 1; transform: translateX(0); } }
    @keyframes slidevMotionZoomIn { from { opacity: 0; transform: scale(0.8); } to { opacity: 1; transform: scale(1); } }
    @keyframes slidevMotionBounce {
      0% { opacity: 0; transform: translateY(40px); }
      60% { opacity: 1; transform: translateY(-8px); }
      80% { transform: translateY(4px); }
      100% { transform: translateY(0); }
    }
    .slidev-motion-fade-in { animation: slidevMotionFadeIn var(--motion-duration, 0.4s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slidev-motion-slide-up { animation: slidevMotionSlideUp var(--motion-duration, 0.45s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slidev-motion-slide-down { animation: slidevMotionSlideDown var(--motion-duration, 0.45s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slidev-motion-slide-left { animation: slidevMotionSlideLeft var(--motion-duration, 0.45s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slidev-motion-slide-right { animation: slidevMotionSlideRight var(--motion-duration, 0.45s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slidev-motion-zoom-in, .slidev-motion-pop { animation: slidevMotionZoomIn var(--motion-duration, 0.4s) cubic-bezier(0.34, 1.56, 0.64, 1) var(--motion-delay, 0s) both; }
    .slidev-motion-bounce { animation: slidevMotionBounce var(--motion-duration, 0.6s) cubic-bezier(0.34, 1.56, 0.64, 1) var(--motion-delay, 0s) both; }
    .controls {
      position: absolute; bottom: 16px; display: flex; gap: 12px; align-items: center;
      background: rgba(24, 24, 27, 0.8); backdrop-filter: blur(8px);
      padding: 6px 18px; border-radius: 20px; color: #fff; font-size: 13px; z-index: 10;
      opacity: 0; pointer-events: auto;
      transition: opacity 0.3s cubic-bezier(0.16, 1, 0.3, 1), transform 0.3s cubic-bezier(0.16, 1, 0.3, 1);
    }
    .controls::before {
      content: ""; position: absolute; top: -20px; bottom: -16px; left: -24px; right: -24px;
    }
    .controls:hover, .controls:focus-within {
      opacity: 1; transform: translateY(-2px);
    }
    .controls button { background: transparent; border: none; color: inherit; cursor: pointer; padding: 2px 6px; }

    /* Slidev Native Icons & Interactive Buttons */
    .slidev-icon-btn {
      display: inline-flex !important; flex-direction: row !important; align-items: center !important; justify-content: center !important;
      padding: 0.35rem 0.5rem; border-radius: 0.375rem; background: transparent;
      border: 1px solid transparent; color: inherit; font-size: inherit; line-height: 1;
      cursor: pointer; opacity: 0.8; transition: all 0.2s ease; text-decoration: none;
      vertical-align: middle; user-select: none; margin: 0 4px;
    }
    .slidev-icon-btn:hover { opacity: 1; background: rgba(255, 255, 255, 0.12); border-color: rgba(255, 255, 255, 0.15); }

    /* 组件从上到下按顺序流式渲染，避免相互重叠 */
    .slide-block > div + div { margin-top: 14px; }

    /* 同一个 div 内的按钮/链接从左到右水平渲染 */
    .slide-block div:has(> .slidev-icon-btn),
    .slide-block div:has(> button),
    .slide-block [class*="abs-"],
    .slidev-btn-row {
      display: inline-flex !important;
      flex-direction: row !important;
      align-items: center !important;
      justify-content: center !important;
      flex-wrap: wrap !important;
      gap: 8px !important;
    }

    /* Position Shortcuts 适配：在组件流中保持从上到下排列，不脱离流产生重叠 */
    .slide-block .abs-br,
    .slide-block .abs-bl,
    .slide-block .abs-tr,
    .slide-block .abs-tl,
    .slide-block [class*="abs-"] {
      position: relative !important;
      bottom: auto !important;
      right: auto !important;
      top: auto !important;
      left: auto !important;
      margin: 0.75rem auto !important;
    }

    .slide-block--absolute { position: relative !important; margin-bottom: 14px !important; padding: 0 !important; background: transparent !important; }
    .slide-block--absolute:hover { background: transparent !important; }
    .mt-12 { margin-top: 3rem !important; }
    .py-1 { padding-top: 0.25rem !important; padding-bottom: 0.25rem !important; }
    .m-6 { margin: 1.5rem !important; }
    .text-xl { font-size: 1.25rem !important; }
    [hover\\:bg~="white"][hover\\:bg~="op-10"]:hover,
    [hover\\:bg="white op-10"]:hover { background: rgba(255, 255, 255, 0.1) !important; border-radius: 4px; }
    .cursor-pointer, [data-clickable] { cursor: pointer; }
    /* Slidev 规范链接排版 (继承正文颜色，虚线底边，Hover 时平滑点亮为主题色并转为实线) */
    .slide-content a:not(.slidev-ref-tag):not(.slidev-icon-btn):not(.slidev-toc-link),
    .slide-block a:not(.slidev-ref-tag):not(.slidev-icon-btn):not(.slidev-toc-link),
    a.slidev-link {
      color: inherit;
      text-decoration: none;
      border-bottom: 1px dashed currentColor;
      transition: color 0.2s cubic-bezier(0.4, 0, 0.2, 1),
                  border-color 0.2s cubic-bezier(0.4, 0, 0.2, 1),
                  border-bottom-style 0.2s cubic-bezier(0.4, 0, 0.2, 1);
      cursor: pointer;
    }
    .slide-content a:not(.slidev-ref-tag):not(.slidev-icon-btn):not(.slidev-toc-link):hover,
    .slide-block a:not(.slidev-ref-tag):not(.slidev-icon-btn):not(.slidev-toc-link):hover,
    a.slidev-link:hover {
      color: var(--slide-accent);
      border-bottom-style: solid;
      border-bottom-color: var(--slide-accent);
    }
    .slidev-ref-tag, a.slidev-ref-tag {
      display: inline-flex;
      align-items: center;
      background: color-mix(in srgb, var(--slide-accent) 12%, transparent);
      color: var(--slide-accent);
      border-radius: 4px;
      padding: 2px 8px;
      font-size: 0.88em;
      text-decoration: none;
      cursor: pointer;
      margin: 2px 4px 2px 0;
      border: 1px solid color-mix(in srgb, var(--slide-accent) 25%, transparent);
      transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
    }
    .slidev-ref-tag:hover, a.slidev-ref-tag:hover {
      background: color-mix(in srgb, var(--slide-accent) 22%, transparent);
      color: var(--slide-accent);
      border-color: color-mix(in srgb, var(--slide-accent) 55%, transparent);
      transform: translateY(-1px);
      box-shadow: 0 2px 8px color-mix(in srgb, var(--slide-accent) 20%, transparent);
    }
    .slidev-block-ref {
      display: block;
      padding: 10px 14px;
      background: color-mix(in srgb, var(--slide-accent) 8%, transparent);
      border-left: 3px solid var(--slide-accent);
      border-radius: 0 6px 6px 0;
      margin: 8px 0;
      cursor: pointer;
      transition: background 0.2s ease;
    }
    .slidev-block-ref:hover {
      background: color-mix(in srgb, var(--slide-accent) 15%, transparent);
    }

    /* 页面动态蒙版 (Dynamic Mask) GPU 合成器硬件加速体系 */
    .slidev-mask-body-container {
      position: relative;
      width: 100%;
      height: 100%;
      min-height: 0;
      flex: 1;
      display: flex;
      flex-direction: column;
      overflow: hidden !important;
      contain: layout paint;
      isolation: isolate;
    }
    .slidev-mask-body-container--has-mask {
      overflow: hidden !important;
      /* 向左右、向下突破父容器内边距，完全贴合幻灯片视口边缘 */
      margin-left: calc(-1 * var(--slidev-padding-x, 48px)) !important;
      margin-right: calc(-1 * var(--slidev-padding-x, 48px)) !important;
      margin-bottom: calc(-1 * var(--slidev-padding-y, 32px)) !important;
      padding-left: var(--slidev-padding-x, 48px) !important;
      padding-right: var(--slidev-padding-x, 48px) !important;
      padding-bottom: var(--slidev-padding-y, 32px) !important;
      width: calc(100% + 2 * var(--slidev-padding-x, 48px)) !important;
      box-sizing: border-box !important;
    }
    /* 无标题且首个元素即为蒙版正文容器时，向上同步扩展至顶部边缘 */
    .slide-content-wrapper > .slidev-mask-body-container--has-mask:first-child,
    .slide-content > .slidev-mask-body-container--has-mask:first-child {
      margin-top: calc(-1 * var(--slidev-padding-y, 32px)) !important;
      padding-top: var(--slidev-padding-y, 32px) !important;
    }
    /* 针对全屏零内边距特殊布局（如 image-right/image-left），重置内边距变量避免越界 */
    .slide-content-wrapper.layout-image-right,
    .slide-content-wrapper.layout-image-left,
    .slide-content.layout-image-right,
    .slide-content.layout-image-left {
      --slidev-padding-x: 0px !important;
      --slidev-padding-y: 0px !important;
    }
    /* 蒙版运动总图层：纯 GPU Compositor 硬件加速 translate3d */
    .slidev-mask-layer {
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      pointer-events: none;
      z-index: 50;
      will-change: transform, opacity;
      transform: translate3d(0, 0, 0);
      backface-visibility: hidden;
      transition: transform 0.42s cubic-bezier(0.2, 0, 0, 1),
                  opacity 0.42s cubic-bezier(0.2, 0, 0, 1);
    }
    /* 蒙版内部遮罩层：纯色或磨砂玻璃 */
    .slidev-mask-overlay {
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      pointer-events: none;
    }
    .slidev-mask-layer--solid .slidev-mask-overlay,
    .slidev-mask-overlay--solid {
      background: var(--slide-bg, #ffffff);
    }
    [data-theme="dark"] .slidev-mask-layer--solid .slidev-mask-overlay,
    [data-theme="dark"] .slidev-mask-overlay--solid {
      background: var(--slide-bg, #121214);
    }
    .slidev-mask-layer--blur .slidev-mask-overlay,
    .slidev-mask-overlay--blur {
      backdrop-filter: blur(30px) saturate(180%);
      -webkit-backdrop-filter: blur(30px) saturate(180%);
      background: color-mix(in srgb, var(--slide-bg, #ffffff) 90%, transparent);
    }
    [data-theme="dark"] .slidev-mask-layer--blur .slidev-mask-overlay,
    [data-theme="dark"] .slidev-mask-overlay--blur {
      background: color-mix(in srgb, var(--slide-bg, #121214) 90%, transparent);
    }
    /* 动态展露分界提示线：物理内嵌于蒙版边缘，相对坐标永为 0，绝对物理同步 */
    .slidev-mask-divider-line {
      position: absolute;
      pointer-events: none;
      z-index: 51;
      opacity: 0;
      transition: opacity 0.3s ease;
    }
    .slidev-mask-layer--down .slidev-mask-divider-line,
    .slidev-mask-divider-line--down {
      top: 0;
      left: 0;
      right: 0;
      height: 2.5px;
      transform: translateY(-50%);
      background: linear-gradient(90deg, transparent 0%, var(--slide-accent, #3b82f6) 6%, var(--slide-accent, #3b82f6) 94%, transparent 100%);
      box-shadow: 0 0 10px var(--slide-accent, #3b82f6), 0 0 4px var(--slide-accent, #3b82f6);
    }
    .slidev-mask-layer--right .slidev-mask-divider-line,
    .slidev-mask-divider-line--right {
      top: 0;
      bottom: 0;
      left: 0;
      width: 2.5px;
      transform: translateX(-50%);
      background: linear-gradient(180deg, transparent 0%, var(--slide-accent, #3b82f6) 6%, var(--slide-accent, #3b82f6) 94%, transparent 100%);
      box-shadow: 0 0 10px var(--slide-accent, #3b82f6), 0 0 4px var(--slide-accent, #3b82f6);
    }`}function Jm(){return`    (function() {
      const data = window.__SLIDEV_DATA__ || { slides: [] };
      const slides = data.slides || [];
      let currentIndex = 0;

      const container = document.getElementById("slide-container");
      const pageNum = document.getElementById("page-num");
      const btnPrev = document.getElementById("btn-prev");
      const btnNext = document.getElementById("btn-next");
      const btnFullscreen = document.getElementById("btn-fullscreen");

      // 「数字+回车」跳页输入角标：右下角悬浮显示，独立于缩放视口
      const jumpBadge = document.createElement("div");
      jumpBadge.className = "jump-page-indicator";
      jumpBadge.style.display = "none";
      document.body.appendChild(jumpBadge);
      const jumpStyle = document.createElement("style");
      jumpStyle.textContent = ".jump-page-indicator{position:fixed;right:16px;bottom:16px;z-index:1000;min-width:40px;padding:4px 12px;border-radius:18px;background:rgba(24,24,27,0.8);backdrop-filter:blur(12px);-webkit-backdrop-filter:blur(12px);border:1px solid rgba(255,255,255,0.12);color:#f4f4f5;font-size:14px;font-variant-numeric:tabular-nums;text-align:center;pointer-events:none;box-shadow:0 4px 16px rgba(0,0,0,0.35);}.jump-page-indicator.is-invalid{background:rgba(153,27,27,0.85);border-color:rgba(248,113,113,0.5);color:#fecaca;animation:jump-indicator-shake 0.4s ease;}@keyframes jump-indicator-shake{0%,100%{transform:translateX(0);}25%{transform:translateX(-4px);}50%{transform:translateX(4px);}75%{transform:translateX(-2px);}}";
      document.head.appendChild(jumpStyle);

`}function Xm(){return`      // ========= 缩略图总览层（o 键呼出，方向键/数字+回车/点选跳页） =========
      const OVERVIEW_CARD_W = 236;
      let overviewOpen = false;
      let overviewFocus = 1;
      let overviewBuilt = false;
      let overviewObserver = null;
      const overviewOverlay = document.createElement("div");
      overviewOverlay.className = "slidev-overview";
      overviewOverlay.style.display = "none";
      const overviewGrid = document.createElement("div");
      overviewGrid.className = "slidev-overview-grid";
      const overviewHint = document.createElement("div");
      overviewHint.className = "slidev-overview-hint";
      overviewHint.textContent = "← → ↑ ↓ 移动 · Enter 跳转 · 数字直达 · Esc / O 关闭";
      overviewOverlay.appendChild(overviewGrid);
      overviewOverlay.appendChild(overviewHint);
      document.body.appendChild(overviewOverlay);
      overviewOverlay.addEventListener("click", (e) => {
        if (e.target === overviewOverlay) closeOverview();
      });
      const overviewStyle = document.createElement("style");
      overviewStyle.textContent = ".slidev-overview{position:fixed;inset:0;z-index:900;overflow-y:auto;background:rgba(13,16,22,0.88);backdrop-filter:blur(18px);-webkit-backdrop-filter:blur(18px);padding:36px 44px 20px;box-sizing:border-box;}.slidev-overview-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(236px,1fr));gap:18px;max-width:1440px;margin:0 auto;}.slidev-overview-card{cursor:pointer;border-radius:10px;border:2px solid rgba(255,255,255,0.12);background:rgba(255,255,255,0.04);overflow:hidden;transition:border-color 0.15s ease,transform 0.15s ease,box-shadow 0.15s ease;}.slidev-overview-card:hover{border-color:rgba(255,255,255,0.38);transform:translateY(-2px);}.slidev-overview-card.is-active{border-color:var(--slide-accent,#3b82f6);box-shadow:0 0 0 1px var(--slide-accent,#3b82f6),0 8px 24px rgba(0,0,0,0.4);}.slidev-overview-canvas-box{position:relative;overflow:hidden;background:var(--slide-bg,#ffffff);}.slidev-overview-canvas{position:absolute;top:0;left:0;transform-origin:top left;pointer-events:none;}.slidev-overview-canvas *{scrollbar-width:none;}.slidev-overview-caption{display:flex;align-items:center;gap:8px;padding:6px 10px;font-size:12px;color:rgba(255,255,255,0.72);border-top:1px solid rgba(255,255,255,0.08);background:rgba(13,16,22,0.6);}.slidev-overview-page-no{flex-shrink:0;font-variant-numeric:tabular-nums;font-weight:600;color:#f4f4f5;background:rgba(255,255,255,0.16);border-radius:8px;padding:0 7px;line-height:18px;}.slidev-overview-page-no.is-current{background:var(--slide-accent,#10b981);color:#0b1210;}.slidev-overview-title{white-space:nowrap;overflow:hidden;text-overflow:ellipsis;user-select:none;}.slidev-overview-hint{text-align:center;margin:18px 0 8px;font-size:12px;color:rgba(255,255,255,0.45);user-select:none;}";
      document.head.appendChild(overviewStyle);

      const baseWidth = 980;
      const aspectStr = (data.config && data.config.aspectRatio) || "16/9";
      let ratioNum = 16 / 9;
      if (aspectStr === "4/3") ratioNum = 4 / 3;
      else if (aspectStr === "16/10") ratioNum = 16 / 10;
      else if (typeof aspectStr === "string" && aspectStr.includes("/")) {
        const parts = aspectStr.split("/").map(Number);
        if (parts[0] && parts[1]) ratioNum = parts[0] / parts[1];
      }
      const baseHeight = Math.ceil(baseWidth / ratioNum);
      const viewport = document.getElementById("viewport");

`}function Qm(){return`      function updateScale() {
        if (!viewport) return;
        const isFull = !!document.fullscreenElement;
        const padX = isFull ? 0 : 20;
        const padY = isFull ? 0 : 32;
        const availW = Math.max(100, window.innerWidth - padX);
        const availH = Math.max(100, window.innerHeight - padY);
        const scale = Math.min(availW / baseWidth, availH / baseHeight);
        viewport.style.width = baseWidth + "px";
        viewport.style.height = baseHeight + "px";
        viewport.style.transform = "translate(-50%, -50%) scale(" + scale + ")";
        viewport.style.setProperty("--slidev-slide-scale", scale);
        if (isFull) document.body.classList.add("is-fullscreen");
        else document.body.classList.remove("is-fullscreen");
      }

      window.addEventListener("resize", updateScale);
      document.addEventListener("fullscreenchange", updateScale);

      function parseMaskRatio(ratioStr) {
        if (!ratioStr || typeof ratioStr !== "string") {
          return { steps: 2, breakpoints: [50, 100] };
        }
        const clean = ratioStr.trim();
        if (!clean) return { steps: 2, breakpoints: [50, 100] };
        const parts = clean.split(":").map(p => parseFloat(p.trim())).filter(n => !isNaN(n) && n > 0);
        if (parts.length === 0) return { steps: 2, breakpoints: [50, 100] };
        if (parts.length === 1) {
          const val = Math.min(100, Math.max(1, parts[0]));
          if (val === 100) return { steps: 1, breakpoints: [100] };
          return { steps: 2, breakpoints: [Math.round(val * 100) / 100, 100] };
        }
        const isMonotonic = parts.every((val, idx) => idx === 0 || val > parts[idx - 1]);
        const maxVal = parts[parts.length - 1];
        if (isMonotonic && (maxVal === 100 || parts.some(p => p > 10))) {
          const bps = parts.map(p => Math.min(100, Math.round(p * 100) / 100));
          if (bps[bps.length - 1] < 100) bps.push(100);
          return { steps: bps.length, breakpoints: bps };
        }
        const totalWeight = parts.reduce((acc, cur) => acc + cur, 0);
        if (totalWeight <= 0) return { steps: 2, breakpoints: [50, 100] };
        let accumulated = 0;
        const bps = [];
        for (let i = 0; i < parts.length; i++) {
          accumulated += parts[i];
          if (i === parts.length - 1) {
            bps.push(100);
          } else {
            bps.push(Math.round((accumulated / totalWeight) * 10000) / 100);
          }
        }
        return { steps: bps.length, breakpoints: bps };
      }

      let currentMaskStep = 0;
      let currentMaskConfig = null;
      let maskLayerEl = null;
      let maskOverlayEl = null;
      let maskDividerEl = null;

      function updateMaskVisual() {
        if (!currentMaskConfig || !maskLayerEl) return;
        const p = (currentMaskStep <= 0)
          ? (currentMaskConfig.isInitialRevealed ? currentMaskConfig.breakpoints[0] : 0)
          : (currentMaskStep >= currentMaskConfig.totalSteps
              ? 100
              : currentMaskConfig.breakpoints[currentMaskConfig.isInitialRevealed ? currentMaskStep : (currentMaskStep - 1)]);

        const isDown = currentMaskConfig.direction === "down";
        if (p >= 100) {
          maskLayerEl.style.transform = isDown ? "translate3d(0, 100%, 0)" : "translate3d(100%, 0, 0)";
          maskLayerEl.style.opacity = "0";
          maskLayerEl.style.pointerEvents = "none";
          if (maskDividerEl) maskDividerEl.style.opacity = "0";
        } else {
          maskLayerEl.style.transform = isDown ? ("translate3d(0, " + p + "%, 0)") : ("translate3d(" + p + "%, 0, 0)");
          maskLayerEl.style.opacity = "1";
          maskLayerEl.style.pointerEvents = "none";
          if (maskDividerEl) {
            maskDividerEl.style.opacity = (p <= 0) ? "0" : "1";
          }
        }
      }

      function goNext() {
        if (currentMaskConfig && currentMaskStep < currentMaskConfig.totalSteps) {
          currentMaskStep++;
          updateMaskVisual();
          return;
        }
        renderSlide(currentIndex + 1);
      }

      function goPrev() {
        if (currentMaskConfig && currentMaskStep > (currentMaskConfig.isInitialRevealed ? 1 : 0)) {
          currentMaskStep--;
          updateMaskVisual();
          return;
        }
        renderSlide(currentIndex - 1);
      }

`}function eg(){return`      function cleanCardListItemMarkdown(rawMarkdown) {
        if (!rawMarkdown) return "";
        let cleaned = rawMarkdown.replace(/^[ 	]*[-*+]s+|^[ 	]*d+.s+/, "");
        cleaned = cleaned.replace(/
[ 	]{2,4}/g, "
");
        return cleaned.trim();
      }

      function isHeadingBlock(b) {
        if (!b) return false;
        if (b.type === "h" || b.type === "NodeHeading") return true;
        if (b.subType && /^h[1-6]$/i.test(b.subType)) return true;
        const md = (b.rawMarkdown || b.content || "").trim();
        if (/^#{1,6}s+/.test(md)) return true;
        if (/^(?:[-*+]|d+.)s+#{1,6}s+/.test(md)) return true;
        return false;
      }

      function cleanColList(blocks) {
        const valid = (blocks || []).filter(b => Boolean((b.rawMarkdown || b.content || "").trim()));
        if (valid.length === 0) return valid;
        const first = valid[0];
        const md = (first.rawMarkdown || first.content || "").trim();
        const isList = /^(?:[-*+]|d+.)s+/.test(md) || first.type === "i" || first.type === "l";
        if (isList) {
          first.rawMarkdown = cleanCardListItemMarkdown(first.rawMarkdown || first.content || "");
          first.content = first.rawMarkdown;
        }
        return valid;
      }

      function renderBlock(block, extraClass) {
        const div = document.createElement("div");
        div.className = "slide-block" + (extraClass ? " " + extraClass : "");
        if (block && block.motion && block.motion.preset && block.motion.preset !== "none") {
          div.classList.add("slidev-motion-" + block.motion.preset.toLowerCase());
          if (typeof block.motion.duration === "number" && block.motion.duration > 0) {
            div.style.setProperty("--motion-duration", block.motion.duration + "ms");
          }
          if (typeof block.motion.delay === "number" && block.motion.delay > 0) {
            div.style.setProperty("--motion-delay", block.motion.delay + "ms");
          }
        }
        const md = block.rawMarkdown || block.content || "";

        if (md.includes('class="slidev-block-ref"') || md.includes('class="slidev-ref-tag"')) {
          div.innerHTML = md;
          return div;
        }

        const CARBON_MAP = {
          'carbon:arrow-right': '<svg viewBox="0 0 32 32" width="1.2em" height="1.2em" fill="currentColor" style="display:inline-block;vertical-align:middle;"><path d="m18 6l-1.43 1.393L24.15 15H4v2h20.15l-7.58 7.573L18 26l10-10z"/></svg>',
          'carbon:arrow-left': '<svg viewBox="0 0 32 32" width="1.2em" height="1.2em" fill="currentColor" style="display:inline-block;vertical-align:middle;"><path d="m14 26l1.43-1.393L7.85 17H28v-2H7.85l7.58-7.573L14 6L4 16z"/></svg>',
          'carbon:edit': '<svg viewBox="0 0 32 32" width="1.2em" height="1.2em" fill="currentColor" style="display:inline-block;vertical-align:middle;"><path d="M2 26h28v2H2zM25.4 9c.8-.8.8-2 0-2.8l-3.6-3.6c-.8-.8-2-.8-2.8 0l-15 15V24h6.4l15-15zM20.4 4L24 7.6l-2.4 2.4l-3.6-3.6L20.4 4zM6 22v-3.6l11-11l3.6 3.6l-11 11H6z"/></svg>',
          'carbon:logo-github': '<svg viewBox="0 0 32 32" width="1.2em" height="1.2em" fill="currentColor" style="display:inline-block;vertical-align:middle;"><path fill-rule="evenodd" d="M16 2a14 14 0 0 0-4.43 27.28c.7.13 1-.3 1-.67v-2.38c-3.89.84-4.71-1.88-4.71-1.88a3.7 3.7 0 0 0-1.56-2.05c-1.27-.86.1-.85.1-.85a2.94 2.94 0 0 1 2.14 1.44a3 3 0 0 0 4.08 1.16a2.93 2.93 0 0 1 .89-1.87c-3.1-.35-6.36-1.55-6.36-6.9a5.4 5.4 0 0 1 1.44-3.75a5 5 0 0 1 .14-3.71s1.17-.38 3.85 1.43a13.3 13.3 0 0 1 7 0c2.67-1.81 3.84-1.43 3.84-1.43a5 5 0 0 1 .14 3.71a5.4 5.4 0 0 1 1.44 3.75c0 5.37-3.27 6.54-6.38 6.89a3.35 3.35 0 0 1 1.26 2.61v3.87c0 .38.26.81 1 .67A14 14 0 0 0 16 2"/></svg>'
        };

        if (/@\\w+=['"]|v-\\w+|<button|<a\\b|<carbon:|^<div/i.test(md)) {
          if (md.includes('abs-br') || md.includes('abs-bl') || md.includes('abs-tr') || md.includes('abs-tl') || md.includes('absolute')) {
            div.classList.add("slide-block--absolute");
          }
          let renderedHtml = md;
          for (const [tag, svg] of Object.entries(CARBON_MAP)) {
            const regex = new RegExp("<" + tag + "\\\\s*\\\\/?>", "gi");
            renderedHtml = renderedHtml.replace(regex, svg);
            const regexDash = new RegExp("<" + tag.replace(":", "-") + "\\\\s*\\\\/?>", "gi");
            renderedHtml = renderedHtml.replace(regexDash, svg);
          }
          div.innerHTML = renderedHtml;

          // 挂载交互事件监听
          const nextBtns = div.querySelectorAll('[\\\\@click*="nav.next"], [\\\\@click*="next"]');
          nextBtns.forEach(btn => {
            btn.style.cursor = "pointer";
            btn.addEventListener("click", (e) => {
              e.stopPropagation();
              renderSlide(currentIndex + 1);
            });
          });

          const prevBtns = div.querySelectorAll('[\\\\@click*="nav.prev"], [\\\\@click*="prev"]');
          prevBtns.forEach(btn => {
            btn.style.cursor = "pointer";
            btn.addEventListener("click", (e) => {
              e.stopPropagation();
              renderSlide(currentIndex - 1);
            });
          });

          return div;
        }

        const hasHeadingTag = /(?:^|
)s*#{1,6}s+/.test(md);
        const hMatch = md.match(/^(#{1,6})\\s+(.*)$/);

        if (hMatch) {
          const level = hMatch[1].length;
          let th = hMatch[2].trim().replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
          div.innerHTML = "<h" + level + ">" + th + "</h" + level + ">";
        }
        else if (md.startsWith("\`\`\`")) {
          const customMaxHeight = block?.attributes?.["custom-slidev-max-height"] || block?.attrs?.["custom-slidev-max-height"] || block?.maxHeight || "";
          const heightStyle = customMaxHeight ? ' style="max-height:' + customMaxHeight + ';overflow-y:auto;"' : "";
          div.innerHTML = "<pre" + heightStyle + "><code>" + md.slice(3, -3) + "</code></pre>";
        }
        else if (md.startsWith("> ")) div.innerHTML = "<blockquote><p>" + md.slice(2) + "</p></blockquote>";
        else if ((/<video\b/i.test(md) || (block && (block.type === "video" || block.type === "NodeVideo"))) && !/^(s*)([-*+]|d+.)s+/m.test(md) && !hasHeadingTag && !md.includes("
")) {
          div.classList.add("slide-video-container", "slide-media-container", "slide-media-block");
          const isAutoplay = block && block.attributes && block.attributes["custom-slidev-autoplay"] === "true";
          const isLoop = block && block.attributes && block.attributes["custom-slidev-loop"] === "true";
          const isMuted = block && block.attributes && (block.attributes["custom-slidev-muted"] === "true" || isAutoplay);
          const hideControls = block && block.attributes && block.attributes["custom-slidev-controls"] === "false";
          let videoHtml = md;
          if (hideControls) videoHtml = videoHtml.replace(/\bcontrols(?:="[^"]*")?/gi, "").trim();
          else if (!videoHtml.includes("controls")) videoHtml = videoHtml.replace("<video", "<video controls");
          if (isAutoplay && !videoHtml.includes("autoplay")) videoHtml = videoHtml.replace("<video", "<video autoplay playsinline");
          if (isLoop && !videoHtml.includes("loop")) videoHtml = videoHtml.replace("<video", "<video loop");
          if (isMuted && !videoHtml.includes("muted")) videoHtml = videoHtml.replace("<video", "<video muted");
          videoHtml = videoHtml.replace("<video", '<video class="slide-video-player"');
          div.setAttribute("data-autoplay", isAutoplay ? "true" : "false");
          div.innerHTML = videoHtml;
        }
        else if (/^(s*)([-*+]|d+.)s+/m.test(md) || (md.includes("
") && /^(s*)([-*+]|d+.)s+/m.test(md.split("
").slice(1).join("
")))) {
          div.classList.add("pdf-list-item");
          const lines = md.split("
");
          let isOrdered = false;
          const items = [];
          const leadLines = [];
          for (let i = 0; i < lines.length; i++) {
            const line = lines[i];
            const tr = line.trim();
            if (!tr || /^{:.*?}$/.test(tr)) continue;
            const um = line.match(/^(s*)[-*+]s+(.*)$/);
            const om = line.match(/^(s*)d+.s+(.*)$/);
            if (um) {
              const indent = um[1].length;
              items.push({ type: "unordered", level: Math.floor(indent / 2), text: um[2], media: [] });
              continue;
            }
            if (om) {
              if (items.length === 0) isOrdered = true;
              const indent = om[1].length;
              items.push({ type: "ordered", level: Math.floor(indent / 2), text: om[2], media: [] });
              continue;
            }
            if (items.length > 0) {
              const im = tr.match(/^![(.*?)]((.*?))(?:{:?[^}]*})?$/);
              if (im) {
                const isGif = /.gif(?:?|$)/i.test(im[2]);
                items[items.length - 1].media.push('<div class="slide-list-media"><img alt="' + im[1] + '" src="' + im[2] + '" class="' + (isGif ? 'list-item-gif' : 'list-item-img') + '" /></div>');
                continue;
              }
              const hm = tr.match(/^<img\b[sS]*?/?>$/i);
              if (hm) {
                const cleanTr = tr.replace(/s+style="[^"]*"/gi, "");
                items[items.length - 1].media.push('<div class="slide-list-media">' + cleanTr + '</div>');
                continue;
              }
              if (/<video\b/i.test(tr)) {
                let vHtml = tr;
                if (!/</video>/i.test(vHtml)) {
                  while (i + 1 < lines.length && !/</video>/i.test(vHtml)) {
                    i++;
                    vHtml += " " + lines[i].trim();
                  }
                }
                const isAutoplay = block && block.attributes && block.attributes["custom-slidev-autoplay"] === "true";
                const isLoop = block && block.attributes && block.attributes["custom-slidev-loop"] === "true";
                const isMuted = block && block.attributes && (block.attributes["custom-slidev-muted"] === "true" || isAutoplay);
                const hideControls = block && block.attributes && block.attributes["custom-slidev-controls"] === "false";
                if (hideControls) vHtml = vHtml.replace(/\bcontrols(?:="[^"]*")?/gi, "").trim();
                else if (!vHtml.includes("controls")) vHtml = vHtml.replace("<video", "<video controls");
                if (isAutoplay && !vHtml.includes("autoplay")) vHtml = vHtml.replace("<video", "<video autoplay playsinline");
                if (isLoop && !vHtml.includes("loop")) vHtml = vHtml.replace("<video", "<video loop");
                if (isMuted && !vHtml.includes("muted")) vHtml = vHtml.replace("<video", "<video muted");
                vHtml = vHtml.replace("<video", '<video class="slide-video-player"');
                items[items.length - 1].media.push('<div class="slide-list-media slide-video-container slide-media-container" data-autoplay="' + (isAutoplay ? 'true' : 'false') + '">' + vHtml + '</div>');
                continue;
              }
              items[items.length - 1].text += "
" + tr;
            } else {
              leadLines.push(tr);
            }
          }

          let leadHtml = "";
          if (leadLines.length > 0) {
            const lParts = [];
            const firstL = leadLines[0];
            const fhm = firstL.match(/^(#{1,6})s+(.*)$/);
            if (fhm) {
              const lvl = fhm[1].length;
              let th = fhm[2].trim().replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
              lParts.push('<h' + lvl + ' class="slide-list-item-title">' + th + '</h' + lvl + '>');
            } else {
              let th = firstL.trim().replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
              lParts.push('<p class="slide-list-item-title">' + th + '</p>');
            }
            if (leadLines.length > 1) {
              const dLines = leadLines.slice(1);
              let pL = [];
              const flushLeadP = () => {
                if (pL.length > 0) {
                  let txt = pL.map(l => l.replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>")).join("<br/>");
                  lParts.push('<p class="slide-list-item-desc">' + txt + '</p>');
                  pL = [];
                }
              };
              for (const l of dLines) {
                const hm = l.match(/^(#{1,6})s+(.*)$/);
                if (hm) {
                  flushLeadP();
                  const lvl = hm[1].length;
                  let th = hm[2].trim().replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
                  lParts.push('<h' + lvl + ' class="slide-list-item-title">' + th + '</h' + lvl + '>');
                } else {
                  pL.push(l);
                }
              }
              flushLeadP();
            }
            leadHtml = lParts.join("
") + "
";
          }

          const tag = isOrdered ? "ol" : "ul";
          const listCls = isOrdered ? "pdf-list pdf-list--ordered" : "pdf-list pdf-list--unordered";
          const liHtml = items.map(it => {
            const med = it.media && it.media.length ? "
" + it.media.join("
") : "";
            const lines = (it.text || "").split("
").map(l => l.trim()).filter(Boolean);
            const hasHeading = lines.some(l => /^#{1,6}s+/.test(l));
            const lvl = it.level || 0;
            const nStyle = lvl > 0 ? ' style="margin-left:' + (lvl * 1.25).toFixed(2) + 'em;' + (it.type === 'unordered' ? 'list-style-type:' + (lvl % 2 === 1 ? 'circle' : 'square') + ' !important;' : '') + '"' : "";
            const nClass = lvl > 0 ? " slide-list-item--nested" : "";
            const clsAttr = nClass ? ' class="' + nClass.trim() + '"' : "";
            if (!hasHeading) {
              let h = lines.map(l => l.replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>")).join("<br/>");
              return '<li' + clsAttr + nStyle + '>' + h + med + '</li>';
            }
            const parts = [];
            let pLines = [];
            const flushP = () => {
              if (pLines.length > 0) {
                let ph = pLines.map(l => l.replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>")).join("<br/>");
                parts.push('<p class="slide-list-item-desc">' + ph + '</p>');
                pLines = [];
              }
            };
            for (const l of lines) {
              const hm = l.match(/^(#{1,6})s+(.*)$/);
              if (hm) {
                flushP();
                const hl = hm[1].length;
                let th = hm[2].trim().replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
                parts.push('<h' + hl + ' class="slide-list-item-title">' + th + '</h' + hl + '>');
              } else {
                pLines.push(l);
              }
            }
            flushP();
            return '<li' + clsAttr + nStyle + '>' + parts.join("
") + med + '</li>';
          }).join("
");
          div.innerHTML = leadHtml + "<" + tag + " class="" + listCls + "">
" + liHtml + "
</" + tag + ">";
        }
        else {
          // 复合块（包含换行、标题或媒体）高保真解析
          const lines = md.split(/\r?
/);
          const subBlocks = [];
          let current = [];
          for (let i = 0; i < lines.length; i++) {
            const line = lines[i];
            const trimmed = line.trim();
            if (/^#{1,6}s+/.test(trimmed)) {
              if (current.length > 0) { subBlocks.push(current.join("
")); current = []; }
              subBlocks.push(trimmed);
              continue;
            }
            if (!trimmed) {
              if (current.length > 0) { subBlocks.push(current.join("
")); current = []; }
              continue;
            }
            if (/^![.*?](.*?)$/.test(trimmed)) {
              if (current.length > 0) { subBlocks.push(current.join("
")); current = []; }
              subBlocks.push(trimmed);
              continue;
            }
            if (/<video\b/i.test(trimmed)) {
              if (current.length > 0) { subBlocks.push(current.join("
")); current = []; }
              let vRaw = trimmed;
              if (!/</video>/i.test(vRaw)) {
                while (i + 1 < lines.length && !/</video>/i.test(vRaw)) {
                  i++;
                  vRaw += "
" + lines[i];
                }
              }
              subBlocks.push(vRaw);
              continue;
            }
            current.push(line);
          }
          if (current.length > 0) subBlocks.push(current.join("
"));

          if (subBlocks.length > 1 || (subBlocks.length === 1 && /^#{1,6}s+/.test(subBlocks[0].trim()))) {
            let isFirstParagraph = true;
            const htmlParts = subBlocks.map(sub => {
              const t = sub.trim();
              if (!t) return "";
              const hm = t.match(/^(#{1,6})s+(.*)$/);
              if (hm) {
                isFirstParagraph = false;
                const hl = hm[1].length;
                let th = hm[2].trim().replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
                return '<h' + hl + ' class="slide-list-item-title">' + th + '</h' + hl + '>';
              }
              const im = t.match(/^![(.*?)]((.*?))$/);
              if (im) {
                return '<div class="slide-media-block slide-media-container slide-list-media"><img alt="' + im[1] + '" src="' + im[2] + '" class="slide-media-img" /></div>';
              }
              if (/<video\b/i.test(t)) {
                return '<div class="slide-media-block slide-video-container slide-media-container">' + t + '</div>';
              }
              if (isFirstParagraph) {
                isFirstParagraph = false;
                const subLines = t.split(/\r?
/).map(l => l.trim()).filter(Boolean);
                if (subLines.length === 1) {
                  let ph = subLines[0].replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
                  return '<p class="slide-list-item-title">' + ph + '</p>';
                }
                let titleHtml = subLines[0].replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
                let descHtml = subLines.slice(1).map(l => l.replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>")).join("<br/>");
                return '<p class="slide-list-item-title">' + titleHtml + '</p>
<p class="slide-list-item-desc">' + descHtml + '</p>';
              }
              let ph = t.replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
              return '<p class="slide-list-item-desc">' + ph + '</p>';
            }).filter(Boolean);
            div.innerHTML = htmlParts.join("
");
          } else {
            const imgMatch = md.match(/!\\[(.*?)\\]\\((.*?)\\)/);
            if (imgMatch) {
              div.classList.add("slide-media-container", "slide-media-block", "slide-block--image");
              div.innerHTML = '<img alt="' + imgMatch[1] + '" src="' + imgMatch[2] + '" class="slide-media-img" />';
            } else {
              let html = md.replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
              const pCls = (block && block.isColFirst) ? ' class="slide-list-item-title"' : '';
              div.innerHTML = "<p" + pCls + ">" + html + "</p>";
            }
          }
        }
        return div;
      }

`}function tg(){return`      function renderSlide(idx) {
        if (slides.length === 0) return;
        currentIndex = Math.max(0, Math.min(idx, slides.length - 1));
        const slide = slides[currentIndex];
        pageNum.textContent = (currentIndex + 1) + " / " + slides.length;

        const pageSp = slide.frontmatter?.spacing;
        const currentSpacing = (pageSp && pageSp !== "inherit") ? pageSp : (data.config?.spacing || "normal");
        container.className = "slide-content layout-" + (slide.frontmatter?.layout || "default") + " spacing-" + currentSpacing;
        if (viewport) viewport.setAttribute("data-spacing", currentSpacing);
        container.innerHTML = "";

        const z = typeof slide.frontmatter?.zoom === "number" && slide.frontmatter.zoom > 0 ? slide.frontmatter.zoom : 1;
        if (z !== 1) {
          container.style.width = (100 / z) + "%";
          container.style.height = (100 / z) + "%";
          container.style.transformOrigin = "top left";
          container.style.transform = "scale(" + z + ")";
        } else {
          container.style.width = "100%";
          container.style.height = "100%";
          container.style.transform = "none";
        maskOverlayEl = null;
        maskDividerEl = null;
        const maskDir = slide.frontmatter?.mask;
        if (maskDir === "down" || maskDir === "right") {
          const ratioInfo = parseMaskRatio(slide.frontmatter.maskRatio);
          const isInitRev = slide.frontmatter.maskInitial === "revealed";
          currentMaskConfig = {
            direction: maskDir,
            totalSteps: isInitRev ? Math.max(0, ratioInfo.steps - 1) : ratioInfo.steps,
            rawSteps: ratioInfo.steps,
            breakpoints: ratioInfo.breakpoints,
            isInitialRevealed: isInitRev,
            style: slide.frontmatter.maskStyle || "solid",
          };
          currentMaskStep = 0;
        } else {
          currentMaskConfig = null;
          currentMaskStep = 0;
        }

        function createMaskElements() {
          if (!currentMaskConfig) return null;
          const layer = document.createElement("div");
          layer.className = "slidev-mask-layer slidev-mask-layer--" + currentMaskConfig.style + " slidev-mask-layer--" + currentMaskConfig.direction;
          const overlay = document.createElement("div");
          overlay.className = "slidev-mask-overlay";
          const divider = document.createElement("div");
          divider.className = "slidev-mask-divider-line";
          divider.style.opacity = "0";
          layer.appendChild(overlay);
          layer.appendChild(divider);
          maskLayerEl = layer;
          maskOverlayEl = overlay;
          maskDividerEl = divider;
          return { layer, overlay, divider };
        }

        if (slide.frontmatter?.layout === "two-cols") {
          const bodyWrap = document.createElement("div");
          bodyWrap.className = "slidev-mask-body-container" + (currentMaskConfig ? " slidev-mask-body-container--has-mask" : "");
          bodyWrap.style.display = "flex";
          bodyWrap.style.flexDirection = "row";
          bodyWrap.style.gap = "2rem";
          bodyWrap.style.width = "100%";
          bodyWrap.style.height = "100%";

          const leftCol = document.createElement("div");
          leftCol.className = "two-cols-left";
          const rightCol = document.createElement("div");
          rightCol.className = "two-cols-right";

          const blocks = (slide.blocks || []).filter(b => b.slot !== "slot-divider-right");
          let leftList = [];
          let rightList = [];
          for (const block of blocks) {
            if (block.slot === "right") rightList.push(block);
            else leftList.push(block);
          }
          leftList = cleanColList(leftList);
          rightList = cleanColList(rightList);
          const isCover = slide.frontmatter?.layout === "cover";
          const leftFirstH = !isCover ? leftList.find(isHeadingBlock) : null;
          const rightFirstH = !isCover ? rightList.find(isHeadingBlock) : null;
          for (const b of leftList) leftCol.appendChild(renderBlock(b, b === leftFirstH ? "slidev-col-first-heading-block" : ""));
          for (const b of rightList) rightCol.appendChild(renderBlock(b, b === rightFirstH ? "slidev-col-first-heading-block" : ""));
          bodyWrap.appendChild(leftCol);
          bodyWrap.appendChild(rightCol);

          const maskEls = createMaskElements();
          if (maskEls) {
            bodyWrap.appendChild(maskEls.layer);
          }
          container.appendChild(bodyWrap);
        } else if (slide.frontmatter?.layout === "cols-header" || slide.frontmatter?.layout === "two-cols-header" || slide.frontmatter?.layout === "three-cols-header" || slide.frontmatter?.layout === "clover") {
          const isCover = slide.frontmatter?.layout === "cover";
          const isClover = slide.frontmatter?.layout === "clover";
          const blocks = (slide.blocks || []).filter(b => b.slot !== "slot-divider-right");
          let headerBlocks = blocks.filter(b => b.slot === "header");
          if (headerBlocks.length === 0 && blocks.length > 0) {
            const candidate = blocks.find(b => b.type === "h" && (!b.slot || b.slot === "default"));
            if (candidate) headerBlocks = [candidate];
          }
          const rem = blocks.filter(b => !headerBlocks.includes(b));

          let targetCols = isClover ? 4 : 2;
          if (isClover) {
            targetCols = 4;
          } else if (slide.frontmatter?.layout === "three-cols-header") {
            targetCols = 3;
          } else if (slide.frontmatter?.layout === "two-cols-header") {
            targetCols = 2;
          } else {
            let maxCol = 0;
            for (const b of rem) {
              const m = (b.slot || "").match(/^col-(d+)$/i);
              if (m) maxCol = Math.max(maxCol, parseInt(m[1], 10));
            }
            if (maxCol >= 2) {
              targetCols = maxCol;
            } else if (slide.frontmatter?.layoutRatio) {
              const r = slide.frontmatter.layoutRatio.trim();
              if (r.includes(":")) {
                const parts = r.split(":").map(p => parseFloat(p.trim())).filter(n => !isNaN(n) && n > 0);
                if (parts.length >= 2) targetCols = parts.length;
              }
            }
          }

          const hasColSlots = rem.some(b => b.slot && /^col-d+$/i.test(b.slot));
          const isSuperBlockCols = isClover || hasColSlots;

          const containerDiv = document.createElement("div");
          containerDiv.className = (isClover ? "layout-clover-container" : ("layout-cols-header-container " + (targetCols === 2 ? "layout-two-cols-header-container" : (targetCols === 3 ? "layout-three-cols-header-container" : "")))) + (isSuperBlockCols ? " has-superblock-cols" : "");
          const headerDiv = document.createElement("div");
          headerDiv.className = "layout-header-section";
          const gridDiv = document.createElement("div");
          gridDiv.className = (isClover ? "layout-clover-grid pdf-clover-wrapper" : ("layout-cols-wrapper layout-cols-grid " + (targetCols === 2 ? "pdf-two-cols-wrapper layout-two-cols-grid" : (targetCols === 3 ? "pdf-three-cols-wrapper layout-three-cols-grid" : "")))) + (isSuperBlockCols ? " has-superblock-cols" : "") + (currentMaskConfig ? " slidev-mask-body-container slidev-mask-body-container--has-mask" : "");

          const gridCols = isClover ? "repeat(2, minmax(0, 1fr))" : parseRatioToGridCols(slide.frontmatter?.layoutRatio, targetCols);
          if (gridCols) gridDiv.style.gridTemplateColumns = gridCols;
          if (isClover) gridDiv.style.gridTemplateRows = "repeat(2, minmax(0, 1fr))";

          let colsList = [];
          for (let i = 0; i < targetCols; i++) colsList.push([]);
          const hasExplicitCols = rem.some(b => b.slot && (b.slot.startsWith("col-") || b.slot === "left" || b.slot === "right" || b.slot === "center"));
          if (hasExplicitCols) {
            for (const b of rem) {
              let idx = 0;
              if (b.slot === "left" || b.slot === "col-1") idx = 0;
              else if (b.slot === "center" || b.slot === "col-2") idx = 1;
              else if (b.slot === "right") idx = targetCols === 2 ? 1 : targetCols - 1;
              else {
                const m = (b.slot || "").match(/^col-(d+)$/i);
                if (m) idx = Math.min(targetCols - 1, Math.max(0, parseInt(m[1], 10) - 1));
              }
              colsList[idx].push(b);
            }
          } else {
            let cur = 0;
            for (let i = 0; i < targetCols; i++) {
              const remainingCols = targetCols - i;
              const remainingItems = rem.length - cur;
              const take = Math.ceil(remainingItems / remainingCols);
              colsList[i] = rem.slice(cur, cur + take);
              cur += take;
            }
          }

          const headerFirstH = !isCover ? headerBlocks.find(isHeadingBlock) : null;
          for (const b of headerBlocks) headerDiv.appendChild(renderBlock(b, b === headerFirstH ? "slidev-page-first-heading-block" : ""));
          containerDiv.appendChild(headerDiv);

          colsList.forEach((colBlocks, idx) => {
            const colDiv = document.createElement("div");
            colDiv.className = "pdf-col pdf-col--" + (idx + 1) + " col-" + (idx + 1) + (targetCols === 2 && idx === 0 ? " pdf-col--left" : "") + (targetCols === 2 && idx === 1 ? " pdf-col--right" : "");
            const cleaned = cleanColList(colBlocks);
            const colFirstH = !isCover ? (cleaned.find(isHeadingBlock) || cleaned[0]) : null;
            for (const b of cleaned) colDiv.appendChild(renderBlock(b, b === colFirstH ? "slidev-col-first-heading-block" : ""));
            gridDiv.appendChild(colDiv);
          });

          const maskEls = createMaskElements();
          if (maskEls) {
            gridDiv.appendChild(maskEls.layer);
          }

          containerDiv.appendChild(gridDiv);
          container.appendChild(containerDiv);
        } else if (slide.frontmatter?.layout === "image-right" || slide.frontmatter?.layout === "image-left") {
          const isImageRight = slide.frontmatter?.layout === "image-right";
          const isCover = slide.frontmatter?.layout === "cover";
          const allBlocks = slide.blocks || [];
          const pageFirstH = !isCover ? allBlocks.find(isHeadingBlock) : null;

          if (pageFirstH) {
            container.appendChild(renderBlock(pageFirstH, "slidev-page-first-heading-block"));
          }

          const bodyWrap = document.createElement("div");
          bodyWrap.className = "slidev-mask-body-container" + (currentMaskConfig ? " slidev-mask-body-container--has-mask" : "");
          bodyWrap.style.display = "flex";
          bodyWrap.style.flexDirection = isImageRight ? "row" : "row-reverse";
          bodyWrap.style.gap = "2rem";
          bodyWrap.style.width = "100%";
          bodyWrap.style.height = "100%";
          bodyWrap.style.minHeight = "0";
          bodyWrap.style.flex = "1";

          const contentCol = document.createElement("div");
          contentCol.className = isImageRight ? "image-right-content" : "image-left-content";

          for (const block of allBlocks) {
            if (block === pageFirstH) continue;
            contentCol.appendChild(renderBlock(block, ""));
          }

          const imgCol = document.createElement("div");
          imgCol.className = isImageRight ? "image-right-img-container" : "image-left-img-container";
          const img = document.createElement("img");
          img.className = isImageRight ? "image-right-img" : "image-left-img";
          img.src = slide.frontmatter?.image || slide.frontmatter?.background || "";
          img.alt = "Slide cover";
          img.onerror = function() {
            this.src = "https://fastly.jsdelivr.net/gh/slidevjs/slidev-covers@main/static/2HmfbSpvcos.webp";
          };
          imgCol.appendChild(img);

          bodyWrap.appendChild(contentCol);
          bodyWrap.appendChild(imgCol);

          const maskEls = createMaskElements();
          if (maskEls) {
            bodyWrap.appendChild(maskEls.layer);
          }
          container.appendChild(bodyWrap);
        } else {
          const isCover = slide.frontmatter?.layout === "cover";
          const validBlocks = (slide.blocks || []).filter(b => b.slot !== "slot-divider-right");
          const pageFirstH = !isCover ? validBlocks.find(isHeadingBlock) : null;

          if (pageFirstH) {
            container.appendChild(renderBlock(pageFirstH, "slidev-page-first-heading-block"));
          }

          const bodyWrap = document.createElement("div");
          bodyWrap.className = "slidev-mask-body-container" + (currentMaskConfig ? " slidev-mask-body-container--has-mask" : "");

          for (const block of validBlocks) {
            if (block === pageFirstH) continue;
            bodyWrap.appendChild(renderBlock(block, ""));
          }

          const maskEls = createMaskElements();
          if (maskEls) {
            bodyWrap.appendChild(maskEls.layer);
          }
          container.appendChild(bodyWrap);
        }

        updateMaskVisual();
        if (currentMaskConfig && maskLayerEl) {
          requestAnimationFrame(() => {
            if (maskLayerEl) void maskLayerEl.offsetHeight;
          });
        }

        function syncAutoplayVideos() {
          const doSync = () => {
            const videos = container.querySelectorAll("video");
            videos.forEach((v) => {
              const box = v.closest("[data-autoplay]");
              const isAuto = v.hasAttribute("autoplay") || v.autoplay || (box && box.getAttribute("data-autoplay") === "true");
              if (isAuto) {
                v.muted = true;
                v.defaultMuted = true;
                v.setAttribute("muted", "");
                v.playsInline = true;
                v.setAttribute("playsinline", "");
                const playFn = () => {
                  if (!v.paused) return;
                  v.muted = true;
                  v.defaultMuted = true;
                  const p = v.play();
                  if (p !== undefined) {
                    p.catch(() => {
                      v.muted = true;
                      v.defaultMuted = true;
                      setTimeout(() => { if (v.paused) v.play().catch(() => {}); }, 150);
                    });
                  }
                };
                playFn();
                if (!v.__autoplayBound) {
                  v.__autoplayBound = true;
                  v.addEventListener("loadedmetadata", playFn);
                  v.addEventListener("canplay", playFn);
                }
              }
            });
          };
          setTimeout(doSync, 60);
          setTimeout(doSync, 200);
        }
        syncAutoplayVideos();
      }

      // Lightbox 控制逻辑
      const lightbox = document.getElementById("slidev-lightbox");
      const lightboxContent = document.getElementById("lightbox-content");
      const lightboxClose = document.getElementById("lightbox-close");
      let isLightboxOpen = false;

`}function ig(){return`      function openLightbox(type, src, alt) {
        if (!lightbox || !lightboxContent) return;
        lightboxContent.innerHTML = "";
        if (type === "video") {
          const v = document.createElement("video");
          v.className = "slidev-lightbox-video";
          v.src = src;
          v.controls = true;
          v.autoplay = true;
          v.playsInline = true;
          lightboxContent.appendChild(v);
        } else {
          const img = document.createElement("img");
          img.className = "slidev-lightbox-img";
          img.src = src;
          img.alt = alt || "";
          lightboxContent.appendChild(img);
        }
        lightbox.classList.add("active");
        isLightboxOpen = true;
      }

      function closeLightbox() {
        if (!lightbox) return;
        const v = lightbox.querySelector("video");
        if (v) v.pause();
        lightbox.classList.remove("active");
        if (lightboxContent) lightboxContent.innerHTML = "";
        isLightboxOpen = false;
      }

      if (lightboxClose) {
        lightboxClose.addEventListener("click", (e) => {
          e.stopPropagation();
          closeLightbox();
        });
      }
      if (lightbox) {
        lightbox.addEventListener("click", (e) => {
          if (e.target === lightbox || e.target === lightboxClose) {
            e.stopPropagation();
            closeLightbox();
          }
        });
      }

      btnPrev.addEventListener("click", () => goPrev());
      btnNext.addEventListener("click", () => goNext());
      btnFullscreen.addEventListener("click", () => {
        if (!document.fullscreenElement) {
          document.documentElement.requestFullscreen().then(() => updateScale()).catch(() => {});
        } else {
          document.exitFullscreen().then(() => updateScale()).catch(() => {});
        }
      });

      // 「数字+回车」跳页输入状态：数字缓冲实时回显，Esc/超时清空，越界红色抖动提示
      let jumpDisplay = "";
      let jumpInvalid = false;
      let jumpIdleTimer = null;
      let jumpFlashTimer = null;

`}function ng(){return`      function hideJumpIndicator() {
        jumpDisplay = "";
        jumpInvalid = false;
        jumpBadge.style.display = "none";
        jumpBadge.classList.remove("is-invalid");
        if (jumpIdleTimer) { clearTimeout(jumpIdleTimer); jumpIdleTimer = null; }
        if (jumpFlashTimer) { clearTimeout(jumpFlashTimer); jumpFlashTimer = null; }
      }

      function renderJumpBadge() {
        jumpBadge.textContent = jumpDisplay;
        jumpBadge.style.display = jumpDisplay ? "block" : "none";
        jumpBadge.classList.toggle("is-invalid", jumpInvalid);
      }

      function armJumpIdleTimer() {
        if (jumpIdleTimer) clearTimeout(jumpIdleTimer);
        jumpIdleTimer = setTimeout(hideJumpIndicator, 1500);
      }

      function flashJumpInvalid() {
        if (jumpIdleTimer) { clearTimeout(jumpIdleTimer); jumpIdleTimer = null; }
        jumpInvalid = true;
        renderJumpBadge();
        if (jumpFlashTimer) clearTimeout(jumpFlashTimer);
        jumpFlashTimer = setTimeout(hideJumpIndicator, 500);
      }

      function isEditableKeyTarget(t) {
        if (!t || !t.tagName) return false;
        return t.tagName === "INPUT" || t.tagName === "TEXTAREA" || t.tagName === "SELECT" || t.isContentEditable === true;
      }

`}function og(){return`      function getSlideOverviewTitle(slide) {
        const fm = slide?.frontmatter || {};
        if (fm.title) return String(fm.title);
        const blocks = slide?.blocks || [];
        for (const b of blocks) {
          if (b.type === "h" || /^h[1-6]$/i.test(b.subType || "")) {
            const md = (b.rawMarkdown || b.content || "").trim();
            return md.replace(/^#{1,6}s+/, "").replace(/[*_\`]/g, "").slice(0, 40);
          }
        }
        return "";
      }

      // 把任意一页渲染为静态缩略图：复用 renderBlock 与主渲染同名版式类，导出样式自动生效
      function buildOverviewThumbInto(canvas, slide) {
        const fm = slide.frontmatter || {};
        const layout = fm.layout || "default";
        const blocks = (slide.blocks || []).filter((b) => b.slot !== "slot-divider-right");
        let headerBlocks = blocks.filter((b) => b.slot === "header");
        if (headerBlocks.length === 0 && blocks.length > 0) {
          const candidate = blocks.find((b) => b.type === "h" && (!b.slot || b.slot === "default"));
          if (candidate) headerBlocks = [candidate];
        }
        const rem = blocks.filter((b) => !headerBlocks.includes(b));
        let bodyEl = null;

        if (layout === "cols-header" || layout === "two-cols-header" || layout === "three-cols-header" || layout === "clover") {
          const isClover = layout === "clover";
          let targetCols = isClover ? 4 : 2;
          if (layout === "three-cols-header") targetCols = 3;
          else if (layout === "two-cols-header") targetCols = 2;
          else if (!isClover) {
            let maxCol = 0;
            for (const b of rem) {
              const m = (b.slot || "").match(/^col-(d+)$/i);
              if (m) maxCol = Math.max(maxCol, parseInt(m[1], 10));
            }
            if (maxCol >= 2) targetCols = maxCol;
            else if (fm.layoutRatio) {
              const r = String(fm.layoutRatio).trim();
              if (r.includes(":")) {
                const parts = r.split(":").map((p) => parseFloat(p.trim())).filter((n) => !isNaN(n) && n > 0);
                if (parts.length >= 2) targetCols = parts.length;
              }
            }
          }
          const hasColSlots = rem.some((b) => b.slot && /^col-d+$/i.test(b.slot));
          const containerDiv = document.createElement("div");
          containerDiv.className = (isClover ? "layout-clover-container" : ("layout-cols-header-container " + (targetCols === 2 ? "layout-two-cols-header-container" : (targetCols === 3 ? "layout-three-cols-header-container" : "")))) + (hasColSlots || isClover ? " has-superblock-cols" : "");
          const headerDiv = document.createElement("div");
          headerDiv.className = "layout-header-section";
          for (const b of headerBlocks) headerDiv.appendChild(renderBlock(b, ""));
          containerDiv.appendChild(headerDiv);
          const gridDiv = document.createElement("div");
          gridDiv.className = (isClover ? "layout-clover-grid pdf-clover-wrapper" : ("layout-cols-wrapper layout-cols-grid " + (targetCols === 2 ? "pdf-two-cols-wrapper layout-two-cols-grid" : (targetCols === 3 ? "pdf-three-cols-wrapper layout-three-cols-grid" : "")))) + (hasColSlots || isClover ? " has-superblock-cols" : "");
          const gridCols = isClover ? "repeat(2, minmax(0, 1fr))" : parseRatioToGridCols(fm.layoutRatio, targetCols);
          if (gridCols) gridDiv.style.gridTemplateColumns = gridCols;
          if (isClover) gridDiv.style.gridTemplateRows = "repeat(2, minmax(0, 1fr))";
          let colsList = [];
          for (let i = 0; i < targetCols; i++) colsList.push([]);
          const hasExplicitCols = rem.some((b) => b.slot && (b.slot.startsWith("col-") || b.slot === "left" || b.slot === "right" || b.slot === "center"));
          if (hasExplicitCols) {
            for (const b of rem) {
              let idx = 0;
              if (b.slot === "left" || b.slot === "col-1") idx = 0;
              else if (b.slot === "center" || b.slot === "col-2") idx = 1;
              else if (b.slot === "right") idx = targetCols === 2 ? 1 : targetCols - 1;
              else {
                const m = (b.slot || "").match(/^col-(d+)$/i);
                if (m) idx = Math.min(targetCols - 1, Math.max(0, parseInt(m[1], 10) - 1));
              }
              colsList[idx].push(b);
            }
          } else {
            let cur = 0;
            for (let i = 0; i < targetCols; i++) {
              const remainingCols = targetCols - i;
              const remainingItems = rem.length - cur;
              const take = Math.ceil(remainingItems / remainingCols);
              colsList[i] = rem.slice(cur, cur + take);
              cur += take;
            }
          }
          colsList.forEach((colBlocks, idx) => {
            const colDiv = document.createElement("div");
            colDiv.className = "pdf-col pdf-col--" + (idx + 1) + " col-" + (idx + 1) + (targetCols === 2 && idx === 0 ? " pdf-col--left" : "") + (targetCols === 2 && idx === 1 ? " pdf-col--right" : "");
            const cleaned = cleanColList(colBlocks);
            for (const b of cleaned) colDiv.appendChild(renderBlock(b, ""));
            gridDiv.appendChild(colDiv);
          });
          containerDiv.appendChild(gridDiv);
          bodyEl = containerDiv;
        } else if (layout === "two-cols") {
          bodyEl = document.createElement("div");
          bodyEl.style.display = "flex";
          bodyEl.style.flexDirection = "row";
          bodyEl.style.gap = "2rem";
          bodyEl.style.width = "100%";
          bodyEl.style.flex = "1";
          bodyEl.style.minHeight = "0";
          let leftList = [];
          let rightList = [];
          for (const b of blocks) {
            if (b.slot === "right") rightList.push(b);
            else leftList.push(b);
          }
          const leftCol = document.createElement("div");
          leftCol.className = "two-cols-left";
          const rightCol = document.createElement("div");
          rightCol.className = "two-cols-right";
          for (const b of cleanColList(leftList)) leftCol.appendChild(renderBlock(b, ""));
          for (const b of cleanColList(rightList)) rightCol.appendChild(renderBlock(b, ""));
          bodyEl.appendChild(leftCol);
          bodyEl.appendChild(rightCol);
        } else if (layout === "image-right" || layout === "image-left") {
          const isImageRight = layout === "image-right";
          bodyEl = document.createElement("div");
          bodyEl.style.display = "flex";
          bodyEl.style.flexDirection = isImageRight ? "row" : "row-reverse";
          bodyEl.style.gap = "2rem";
          bodyEl.style.width = "100%";
          bodyEl.style.flex = "1";
          bodyEl.style.minHeight = "0";
          const contentCol = document.createElement("div");
          contentCol.className = isImageRight ? "image-right-content" : "image-left-content";
          for (const b of blocks) contentCol.appendChild(renderBlock(b, ""));
          const imgCol = document.createElement("div");
          imgCol.className = isImageRight ? "image-right-img-container" : "image-left-img-container";
          const url = fm.image || fm.background || "";
          if (url) {
            const img = document.createElement("img");
            img.className = isImageRight ? "image-right-img" : "image-left-img";
            img.src = url;
            img.alt = "Slide cover";
            imgCol.appendChild(img);
          }
          bodyEl.appendChild(contentCol);
          bodyEl.appendChild(imgCol);
        } else {
          bodyEl = document.createElement("div");
          for (const b of blocks) bodyEl.appendChild(renderBlock(b, ""));
        }
        canvas.appendChild(bodyEl);
      }

      function buildOverviewCards() {
        if (overviewBuilt) return;
        overviewBuilt = true;
        const scale = OVERVIEW_CARD_W / baseWidth;
        const canvasH = Math.round(baseHeight * scale);
        slides.forEach((slide, idx) => {
          const card = document.createElement("div");
          card.className = "slidev-overview-card";
          card.dataset.idx = String(idx);
          const box = document.createElement("div");
          box.className = "slidev-overview-canvas-box";
          box.style.height = canvasH + "px";
          const fm = slide.frontmatter || {};
          const spacing = (fm.spacing && fm.spacing !== "inherit") ? fm.spacing : ((data.config && data.config.spacing) || "normal");
          const canvas = document.createElement("div");
          canvas.className = "slidev-overview-canvas slide-content layout-" + (fm.layout || "default") + " spacing-" + spacing;
          canvas.style.width = baseWidth + "px";
          canvas.style.height = baseHeight + "px";
          canvas.style.transform = "scale(" + scale + ")";
          const bg = fm.background;
          if (bg) {
            if (/^(http|/|data:|assets/)/.test(bg)) {
              canvas.style.backgroundImage = 'url("' + bg + '")';
              canvas.style.backgroundSize = "cover";
              canvas.style.backgroundPosition = "center";
            } else {
              canvas.style.background = bg;
            }
          }
          box.appendChild(canvas);
          const caption = document.createElement("div");
          caption.className = "slidev-overview-caption";
          const pageNo = document.createElement("span");
          pageNo.className = "slidev-overview-page-no";
          pageNo.textContent = String(idx + 1);
          caption.appendChild(pageNo);
          const title = getSlideOverviewTitle(slide);
          if (title) {
            const titleEl = document.createElement("span");
            titleEl.className = "slidev-overview-title";
            titleEl.textContent = title;
            caption.appendChild(titleEl);
          }
          card.appendChild(box);
          card.appendChild(caption);
          card.addEventListener("click", (e) => {
            e.stopPropagation();
            goFromOverview(idx + 1);
          });
          overviewGrid.appendChild(card);
        });
        updateOverviewCurrentMark();
      }

      function renderOverviewThumb(card) {
        if (!card || card.dataset.rendered === "1") return;
        const idx = Number(card.dataset.idx);
        const slide = slides[idx];
        const canvas = card.querySelector(".slidev-overview-canvas");
        if (slide && canvas) buildOverviewThumbInto(canvas, slide);
        card.dataset.rendered = "1";
      }

      function ensureOverviewObserver() {
        if (overviewObserver || typeof window.IntersectionObserver !== "function") return;
        overviewObserver = new IntersectionObserver((entries) => {
          for (const en of entries) {
            if (!en.isIntersecting) continue;
            overviewObserver.unobserve(en.target);
            renderOverviewThumb(en.target);
          }
        }, { rootMargin: "240px" });
      }

      function observeOverviewCards() {
        if (!overviewObserver) return;
        const cards = overviewGrid.children;
        for (let i = 0; i < cards.length; i++) {
          if (cards[i].dataset.rendered !== "1") overviewObserver.observe(cards[i]);
        }
      }

      function updateOverviewCurrentMark() {
        const cards = overviewGrid.children;
        for (let i = 0; i < cards.length; i++) {
          const pageNo = cards[i].querySelector(".slidev-overview-page-no");
          if (pageNo) pageNo.classList.toggle("is-current", i === currentIndex);
        }
      }

      function setOverviewFocus(page) {
        const total = slides.length || 1;
        overviewFocus = Math.min(Math.max(1, page), total);
        const cards = overviewGrid.children;
        for (let i = 0; i < cards.length; i++) {
          cards[i].classList.toggle("is-active", i + 1 === overviewFocus);
        }
        const el = cards[overviewFocus - 1];
        if (el && el.scrollIntoView) el.scrollIntoView({ block: "nearest", behavior: "smooth" });
      }

      function getOverviewCols() {
        if (!overviewGrid || !overviewGrid.clientWidth) return 1;
        return Math.max(1, Math.round(overviewGrid.clientWidth / (OVERVIEW_CARD_W + 18)));
      }

      function goFromOverview(page) {
        const p = parseInt(page, 10);
        if (isNaN(p) || p < 1 || p > slides.length) return;
        closeOverview();
        renderSlide(p - 1);
        updateOverviewCurrentMark();
      }

      function openOverview() {
        if (slides.length === 0) return;
        buildOverviewCards();
        overviewOpen = true;
        overviewOverlay.style.display = "block";
        ensureOverviewObserver();
        if (overviewObserver) {
          observeOverviewCards();
        } else {
          const cards = overviewGrid.children;
          for (let i = 0; i < cards.length; i++) renderOverviewThumb(cards[i]);
        }
        setOverviewFocus(currentIndex + 1);
      }

      function closeOverview() {
        overviewOpen = false;
        overviewOverlay.style.display = "none";
        hideJumpIndicator();
        if (overviewObserver) {
          const cards = overviewGrid.children;
          for (let i = 0; i < cards.length; i++) overviewObserver.unobserve(cards[i]);
        }
      }

      function toggleOverview() {
        if (overviewOpen) closeOverview();
        else openOverview();
      }

      // 总览打开期间接管全部按键：修复上游总览中空格/PGUP/PGDN 仍会翻页的漏洞
      function handleOverviewKeyDown(e) {
        if (e.ctrlKey || e.metaKey || e.altKey) return;
        if (e.isComposing || isEditableKeyTarget(e.target)) return;
        if (/^[0-9]$/.test(e.key)) {
          if (!jumpInvalid && jumpDisplay.length < 4) {
            jumpDisplay += e.key;
            const p = parseInt(jumpDisplay, 10);
            if (!isNaN(p) && p >= 1 && p <= slides.length) setOverviewFocus(p);
            renderJumpBadge();
            armJumpIdleTimer();
          }
          e.preventDefault();
          return;
        }
        if (e.key === "Enter" && jumpDisplay) {
          if (!jumpInvalid) {
            const page = parseInt(jumpDisplay, 10);
            if (!isNaN(page) && page >= 1 && page <= slides.length) {
              goFromOverview(page);
            } else {
              flashJumpInvalid();
            }
          }
          e.preventDefault();
          return;
        }
        if ((e.key === "Escape" || e.key === "Esc") && (jumpDisplay || jumpInvalid)) {
          hideJumpIndicator();
          e.preventDefault();
          return;
        }
        if (e.key === "ArrowRight") {
          e.preventDefault();
          setOverviewFocus(overviewFocus + 1);
          return;
        }
        if (e.key === "ArrowLeft") {
          e.preventDefault();
          setOverviewFocus(overviewFocus - 1);
          return;
        }
        if (e.key === "ArrowDown" || e.key === "PageDown") {
          e.preventDefault();
          setOverviewFocus(overviewFocus + getOverviewCols());
          return;
        }
        if (e.key === "ArrowUp" || e.key === "PageUp") {
          e.preventDefault();
          setOverviewFocus(overviewFocus - getOverviewCols());
          return;
        }
        if (e.key === " ") {
          e.preventDefault();
          return;
        }
        if (e.key === "Enter") {
          e.preventDefault();
          goFromOverview(overviewFocus);
          return;
        }
        if (e.key === "Escape" || e.key === "Esc" || e.key === "o" || e.key === "O") {
          e.preventDefault();
          closeOverview();
        }
      }

      window.addEventListener("keydown", (e) => {
        if (e.key === "Escape" || e.key === "Esc") {
          if (isLightboxOpen) {
            closeLightbox();
            e.preventDefault();
            return;
          }
        }
        if (isLightboxOpen) return;
        // 总览打开期间全部按键由总览层接管
        if (overviewOpen) {
          handleOverviewKeyDown(e);
          return;
        }
        // 「数字+回车」跳页：可输入元素、修饰键、IME 组合输入中不拦截
        if (!e.ctrlKey && !e.metaKey && !e.altKey && !e.isComposing && !isEditableKeyTarget(e.target)) {
          if (/^[0-9]$/.test(e.key)) {
            if (!jumpInvalid && jumpDisplay.length < 4) {
              jumpDisplay += e.key;
              renderJumpBadge();
              armJumpIdleTimer();
            }
            e.preventDefault();
            return;
          }
          if (e.key === "Enter" && jumpDisplay) {
            if (!jumpInvalid) {
              const page = parseInt(jumpDisplay, 10);
              if (!isNaN(page) && page >= 1 && page <= slides.length) {
                hideJumpIndicator();
                renderSlide(page - 1);
              } else {
                flashJumpInvalid();
              }
            }
            e.preventDefault();
            return;
          }
          if ((e.key === "Escape" || e.key === "Esc") && (jumpDisplay || jumpInvalid)) {
            hideJumpIndicator();
            e.preventDefault();
            return;
          }
          if (e.key === "o" || e.key === "O") {
            e.preventDefault();
            toggleOverview();
            return;
          }
        }
        if (e.key === "ArrowRight" || e.key === " " || e.key === "ArrowDown") goNext();
        if (e.key === "ArrowLeft" || e.key === "ArrowUp") goPrev();
        if (e.key === "f" || e.key === "F") btnFullscreen.click();
      });

      // 监听鼠标滚轮上下翻页调度
      let lastWheelTime = 0;
      const WHEEL_COOLDOWN_MS = 280;
      const WHEEL_DELTA_THRESHOLD = 15;

`}function sg(){return`      function canElementScrollY(el, deltaY) {
        let cur = el;
        while (cur && cur !== document.body && cur !== document.documentElement) {
          if (cur.classList && (cur.classList.contains("slidev-viewport") || cur.classList.contains("slidev-stage") || cur.classList.contains("slide-container"))) {
            break;
          }
          const style = window.getComputedStyle(cur);
          const overflowY = style.overflowY;
          if (overflowY === "auto" || overflowY === "scroll") {
            const maxScroll = cur.scrollHeight - cur.clientHeight;
            if (maxScroll > 2) {
              if (deltaY > 0 && cur.scrollTop < maxScroll - 1) return true;
              if (deltaY < 0 && cur.scrollTop > 1) return true;
            }
          }
          cur = cur.parentElement;
        }
        return false;
      }

      window.addEventListener("wheel", (e) => {
        if (isLightboxOpen) return;
        // 总览打开时滚轮交给总览列表原生滚动，不触发翻页
        if (overviewOpen) return;
        if (Math.abs(e.deltaY) < Math.abs(e.deltaX)) return;
        if (Math.abs(e.deltaY) < WHEEL_DELTA_THRESHOLD) return;

        const target = e.target instanceof Element ? e.target : e.target?.parentElement;
        if (target && canElementScrollY(target, e.deltaY)) return;

        e.preventDefault();
        const now = Date.now();
        if (now - lastWheelTime < WHEEL_COOLDOWN_MS) return;
        lastWheelTime = now;

        if (e.deltaY > 0) {
          goNext();
        } else {
          goPrev();
        }
      }, { passive: false });

      document.addEventListener("click", (e) => {
        if (isLightboxOpen) {
          const target = e.target instanceof Element ? e.target : e.target?.parentElement;
          const isMediaItself = target && target.closest && target.closest(".slidev-lightbox-img, .slidev-lightbox-video");
          if (!isMediaItself) {
            e.stopPropagation();
            closeLightbox();
          }
          return;
        }
        // 总览打开时空白点击由总览层自身处理，不触发底层翻页
        if (overviewOpen) return;
        if (e.button !== 0) return;
        const targetEl = e.target instanceof Element ? e.target : e.target?.parentElement;
        if (!targetEl || !targetEl.closest) return;

        const refEl = targetEl.closest("[data-ref-id]");
        if (refEl) {
          const id = refEl.getAttribute("data-ref-id");
          if (id) {
            window.open("siyuan://blocks/" + id, "_blank");
            return;
          }
        }

        // 媒体点击唤起 Lightbox 放大模态
        const mediaEl = targetEl.closest(".slide-content img, .slide-content video");
        if (mediaEl && !mediaEl.closest(".controls, .controls-bar, button, a")) {
          e.stopPropagation();
          const isVideo = mediaEl.tagName.toLowerCase() === "video";
          const src = isVideo ? (mediaEl.currentSrc || mediaEl.src || mediaEl.querySelector("source")?.src) : mediaEl.src;
          if (src) {
            openLightbox(isVideo ? "video" : "image", src, mediaEl.alt || "");
            return;
          }
        }

        const selection = window.getSelection ? window.getSelection().toString().trim() : "";
        if (selection.length > 0) return;

        const isComponent = targetEl.closest(
          ".slide-block, .controls-bar, .image-right-img-container, .image-left-img-container, .controls, img, video, audio, button, a, input, textarea, select, [data-clickable], [data-ref-id], .slidev-toc, .empty-state"
        );
        if (isComponent) return;

        const isLeft = e.clientX < window.innerWidth / 2;
        if (isLeft) {
          goPrev();
        } else {
          goNext();
        }
      });

      renderSlide(0);
      updateScale();
    })();`}function rg(){return[Jm(),Xm(),Qm(),eg(),tg(),ig(),ng(),og(),sg()].join("")}function Ia(e,t){const i="Slidev 演示文稿";let n=e.slides;const o=JSON.stringify(n),s=JSON.stringify(e.config);return`<!DOCTYPE html>
<html lang="zh-CN">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${at(i)}</title>
  <style>
${Ym(t==null?void 0:t.customInlineStyles)}
  </style>
  <script>
    // 注入演示数据载荷
    window.__SLIDEV_DATA__ = {
      docId: ${JSON.stringify(e.docId)},
      slides: ${o},
      config: ${s}
    };
  <\/script>
</head>
<body>
  <div id="app" data-normalize-headings="${e.config.normalizeHeadingSizes?"true":"false"}">
    <div class="slide-viewport slidev-theme-${e.config.theme||"default"}" id="viewport" data-slidev-theme="${e.config.theme||"default"}">
      <div class="slide-content" id="slide-container"></div>
    </div>
    <div class="controls">
      <button id="btn-prev">◀ 上一页</button>
      <span id="page-num">1 / 1</span>
      <button id="btn-next">下一页 ▶</button>
      <button id="btn-fullscreen">全屏</button>
    </div>
    <!-- 全屏媒体灯箱 (Lightbox) 模态窗口 -->
    <div id="slidev-lightbox" class="slidev-lightbox">
      <button class="slidev-lightbox-close" id="lightbox-close" aria-label="关闭 (Esc)">✕</button>
      <div class="slidev-lightbox-content" id="lightbox-content"></div>
    </div>
  </div>

  <script>
${rg()}
  <\/script>
</body>
</html>`}function Ea(e,t){if(typeof document>"u")return!1;const i=new Blob([t],{type:"text/html;charset=utf-8"}),n=URL.createObjectURL(i),o=document.createElement("a");return o.href=n,o.download=e.endsWith(".html")?e:`${e}.html`,document.body.appendChild(o),o.click(),document.body.removeChild(o),URL.revokeObjectURL(n),!0}function lg(e){switch(e){case"4:3":return"size: 12in 9in;";case"A4-landscape":return"size: 297mm 210mm;";case"A4-portrait":return"size: 210mm 297mm;";case"16:9":default:return"size: 16in 9in;"}}function ag(e){const t=lg(e==null?void 0:e.pageRatio);return`
    ${_n(e==null?void 0:e.customInlineStyles)}

    @page {
      ${t}
      margin: 0;
    }
    * {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
      -webkit-print-color-adjust: exact !important;
      print-color-adjust: exact !important;
    }
    body {
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "PingFang SC", "Microsoft YaHei", sans-serif;
      background: #f8fafc;
      color: #1e293b;
    }
    .pdf-slide-page {
      width: 100vw;
      height: 100vh;
      page-break-after: always;
      break-after: page;
      padding: var(--slidev-padding-y, 36px) var(--slidev-padding-x, 56px);
      display: flex;
      flex-direction: column;
      position: relative;
      background: #ffffff;
      overflow: hidden;
    }
    .pdf-slide-page.spacing-compact {
      --slidev-padding-y: 20px;
      --slidev-padding-x: 36px;
      --slidev-header-gap: 10px;
      --slidev-title-margin-bottom: 6px;
    }
    .pdf-slide-page.spacing-normal {
      --slidev-padding-y: 36px;
      --slidev-padding-x: 56px;
      --slidev-header-gap: 16px;
      --slidev-title-margin-bottom: 10px;
    }
    .pdf-slide-page.spacing-loose {
      --slidev-padding-y: 48px;
      --slidev-padding-x: 64px;
      --slidev-header-gap: 24px;
      --slidev-title-margin-bottom: 16px;
    }
    .pdf-slide-page.theme-dark {
      background: #0f1117;
      color: #f1f5f9;
    }
    .pdf-slide-header {
      font-size: 13px;
      color: #64748b;
      margin-bottom: 24px;
      display: flex;
      justify-content: space-between;
      border-bottom: 1px solid #e2e8f0;
      padding-bottom: 8px;
    }
    .theme-dark .pdf-slide-header {
      border-bottom-color: #2e3346;
      color: #94a3b8;
    }
    .pdf-slide-body {
      flex: 1;
      display: flex;
      flex-direction: column;
      gap: 16px;
      font-size: 20px;
      line-height: 1.6;
      overflow: hidden;
    }
    .pdf-block h1 { font-size: 2.5rem; font-weight: 800; color: #2563eb; margin-bottom: 12px; }
    .pdf-block h2 { font-size: 1.9rem; font-weight: 700; color: #1d4ed8; margin-bottom: 10px; }
    .pdf-block h3 { font-size: 1.4rem; font-weight: 600; margin-bottom: 8px; }
    .pdf-block h4 { font-size: 1.2rem; font-weight: 600; margin-bottom: 6px; }
    .pdf-block p { font-size: 1.15rem; color: inherit; }
    .pdf-code,
    pre {
      background: #f1f5f9;
      padding: 14px 18px;
      border-radius: 6px;
      font-family: "JetBrains Mono", Consolas, monospace;
      font-size: 0.95rem;
      border-left: 4px solid #3b82f6;
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      max-width: 100% !important;
      box-sizing: border-box !important;
    }
    .pdf-code code,
    pre code {
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      display: block !important;
      width: 100% !important;
      box-sizing: border-box !important;
    }
    .code-line {
      display: flex !important;
      align-items: flex-start !important;
      width: 100% !important;
      box-sizing: border-box !important;
      line-height: 1.6;
    }
    .code-line .line-no {
      display: inline-block !important;
      flex-shrink: 0 !important;
      min-width: 2.2em !important;
      text-align: right !important;
      margin-right: 12px !important;
      user-select: none !important;
      opacity: 0.45 !important;
    }
    .code-line .line-content {
      flex: 1 1 0% !important;
      min-width: 0 !important;
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
    }
    .theme-dark .pdf-code {
      background: #1e1e24;
      border-left-color: #60a5fa;
    }
    .pdf-quote {
      border-left: 4px solid #10b981;
      background: rgba(16, 185, 129, 0.08);
      padding: 10px 16px;
      border-radius: 0 4px 4px 0;
      font-style: italic;
    }
    .pdf-image,
    .slide-media-img {
      max-width: 100% !important;
      max-height: 48vh !important;
      width: auto !important;
      height: auto !important;
      object-fit: contain !important;
      border-radius: 6px;
      margin: auto;
      display: block;
    }
    .slide-media-block,
    .slide-media-container,
    .slide-video-container {
      display: flex;
      flex-direction: column;
      justify-content: center;
      align-items: center;
      width: 100%;
      max-height: 48vh;
      margin: 8px 0;
      overflow: hidden;
    }
    .slide-list-media {
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: flex-start;
      margin-top: 8px;
      margin-bottom: 6px;
      max-width: 100%;
      overflow: hidden;
    }
    .slide-list-media img,
    .slide-list-media video,
    .slide-list-media .list-item-gif {
      max-width: 100% !important;
      max-height: min(280px, 36vh) !important;
      width: auto !important;
      height: auto !important;
      min-width: 0 !important;
      min-height: 0 !important;
      object-fit: contain !important;
      border-radius: 6px;
      display: block;
      margin: 0 auto !important;
    }
    .slide-video-player {
      max-width: 100% !important;
      max-height: 48vh !important;
      width: auto !important;
      height: auto !important;
      object-fit: contain !important;
      border-radius: 6px;
      background: #000;
      border: 1px solid #cbd5e1;
    }
    .pdf-two-cols-wrapper,
    .layout-two-cols-grid,
    .layout-cols-wrapper,
    .layout-cols-grid {
      display: grid;
      grid-template-columns: minmax(0, 1fr) minmax(0, 1fr);
      grid-template-rows: minmax(0, 1fr) !important;
      gap: 36px;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      overflow: hidden !important;
    }
    .layout-cols-header-container,
    .layout-two-cols-header-container,
    .layout-three-cols-header-container,
    .layout-clover-container {
      display: flex;
      flex-direction: column;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      overflow: hidden !important;
    }
    .layout-header-section {
      width: 100%;
      margin-bottom: var(--slidev-header-gap, 16px) !important;
      flex-shrink: 0;
    }
    .layout-header-section h1,
    .layout-header-section h2,
    .layout-header-section h3 {
      margin-bottom: var(--slidev-title-margin-bottom, 10px) !important;
    }
    .pdf-three-cols-wrapper,
    .layout-three-cols-grid {
      display: grid;
      grid-template-columns: minmax(0, 1fr) minmax(0, 1fr) minmax(0, 1fr);
      grid-template-rows: minmax(0, 1fr) !important;
      gap: 24px;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      box-sizing: border-box;
      overflow: hidden !important;
    }
    .pdf-clover-wrapper,
    .layout-clover-grid {
      display: grid;
      grid-template-columns: repeat(2, minmax(0, 1fr)) !important;
      grid-template-rows: repeat(2, minmax(0, 1fr)) !important;
      gap: 20px;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      box-sizing: border-box;
      overflow: hidden !important;
    }
    .layout-clover-grid .pdf-col {
      background: transparent !important;
      border: none !important;
      box-shadow: none !important;
    }
    .pdf-col {
      display: flex;
      flex-direction: column;
      gap: 14px;
      min-width: 0;
      width: 100%;
      max-width: 100%;
      height: 100%;
      max-height: 100%;
      min-height: 0;
      justify-content: flex-start;
      overflow: hidden;
      box-sizing: border-box;
      overflow-wrap: break-word;
      word-break: break-word;
      white-space: normal;
    }
    /* 表头多栏内超级块子块首个列表项去圆点后居中显示标题/首行文本 (仅在存在超级块分栏时生效) */
    .has-superblock-cols .pdf-col > *:first-child .slide-list-item-title,
    .has-superblock-cols .pdf-col > *:first-child :is(h1, h2, h3, h4, h5, h6),
    .has-superblock-cols .pdf-col > *:first-child p.slide-list-item-title,
    .has-superblock-cols .pdf-col > *:first-child p:first-of-type,
    .has-superblock-cols .pdf-col > *:first-child p:first-child,
    .has-superblock-cols .pdf-col > *:first-child :is(ul, ol) > li:first-child,
    .has-superblock-cols .pdf-col > *:first-child .slide-list > .slide-list-item:first-child,
    .has-superblock-cols .pdf-col > *:first-child .pdf-list > li:first-child,
    .has-superblock-cols .slidev-col-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    .has-superblock-cols .slidev-col-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      list-style: none !important;
      list-style-type: none !important;
      text-align: center !important;
      margin-left: 0 !important;
      padding-left: 0 !important;
      width: 100% !important;
    }

    /* 彻底清除首个列表项的原生圆点 Marker (仅在存在超级块分栏时生效) */
    .has-superblock-cols .pdf-col > *:first-child :is(ul, ol) > li:first-child::marker {
      content: "" !important;
      display: none !important;
    }

    /* 确保首个列表项内部内联与块级元素居中 (仅在存在超级块分栏时生效) */
    .has-superblock-cols .pdf-col > *:first-child :is(ul, ol) > li:first-child * {
      text-align: center !important;
    }

    /* 栏内说明段落与列表项：左对齐，自然阅读排版 */
    .has-superblock-cols .pdf-col .slide-list-item-desc,
    .has-superblock-cols .pdf-col li:not(:first-child) {
      text-align: left !important;
    }

    /* 全局特定标题大小规范化 (除封面外页首首个标题按 H2 1.7rem，表头多栏内首个标题按 H3 1.3rem) */
    [data-normalize-headings="true"] .slidev-page-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .slidev-page-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .pdf-slide:not(.layout-cover) > :is(.pdf-block, .slide-block):first-child :is(h1, h2, h3, h4, h5, h6),
    [data-normalize-headings="true"] .pdf-slide:not(.layout-cover) > .layout-header-section :is(.pdf-block, .slide-block):first-child :is(h1, h2, h3, h4, h5, h6),
    [data-normalize-headings="true"] .pdf-slide:not(.layout-cover) > :not(.layout-cols-wrapper):not(.pdf-two-cols-wrapper):not(.layout-image-cols-grid):first-child :is(h1, h2, h3, h4, h5, h6) {
      font-size: 1.7rem !important;
      font-weight: 600 !important;
      line-height: 1.25 !important;
      margin-bottom: 10px !important;
    }

    [data-normalize-headings="true"] .has-superblock-cols .slidev-col-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .has-superblock-cols .slidev-col-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .has-superblock-cols .pdf-col > *:first-child :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      font-size: 1.3rem !important;
      font-weight: 600 !important;
      line-height: 1.3 !important;
      margin-bottom: 8px !important;
      text-align: center !important;
    }

    /* 图左与图右版式标题完全保留用户原始字号与默认排版，不进行任何固定大小规范化 */
    [data-normalize-headings="true"] :is(.layout-image-left, .layout-image-right, .image-left-content, .image-right-content) :is(h1, h2, h3, h4, h5, h6) {
      text-align: left !important;
    }
    .pdf-col > .pdf-block,
    .pdf-col > .slide-block {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      max-height: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      width: 100% !important;
      height: 100% !important;
      box-sizing: border-box !important;
      overflow: hidden !important;
    }
    .pdf-col .slide-list-item-title,
    .pdf-col h1, .pdf-col h2, .pdf-col h3, .pdf-col h4, .pdf-col h5, .pdf-col h6,
    .pdf-col .slide-list-item-desc {
      flex: 0 0 auto !important;
      margin-top: 0 !important;
      margin-bottom: 6px !important;
    }
    .pdf-col .slide-list-media,
    .pdf-col .slide-video-container,
    .pdf-col .slide-media-container {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      min-width: 0 !important;
      width: 100% !important;
      height: 100% !important;
      max-height: 100% !important;
      max-width: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
      justify-content: flex-start !important;
      overflow: hidden !important;
      margin: 0 !important;
      padding: 0 !important;
      box-sizing: border-box !important;
    }
    .pdf-col li:has(.slide-list-media),
    .pdf-col li:has(.slide-media-container),
    .pdf-col li:has(.slide-video-container),
    .pdf-col li:has(img),
    .pdf-col li:has(video),
    .pdf-col .pdf-list-item:has(.slide-list-media),
    .pdf-col .pdf-list-item:has(.slide-media-container),
    .pdf-col .pdf-list-item:has(.slide-video-container),
    .pdf-col .pdf-list-item:has(img),
    .pdf-col .pdf-list-item:has(video) {
      display: list-item !important;
      list-style-type: disc !important;
      flex: 0 0 auto !important;
      height: auto !important;
      max-height: none !important;
      overflow: visible !important;
      margin-bottom: 6px !important;
    }
    .pdf-col video,
    .layout-three-cols-grid video,
    .layout-two-cols-grid video,
    .pdf-col img,
    .layout-three-cols-grid img,
    .layout-two-cols-grid img,
    .pdf-col .slide-video-player {
      max-width: 100% !important;
      max-height: 100% !important;
      width: auto !important;
      height: auto !important;
      min-width: 0 !important;
      min-height: 0 !important;
      object-fit: contain !important;
      display: block !important;
      margin: 0 auto !important;
    }
    .pdf-col * {
      overflow-wrap: break-word;
      word-break: break-word;
      box-sizing: border-box;
    }
    .pdf-col pre {
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      max-width: 100% !important;
      box-sizing: border-box !important;
    }
    .pdf-list-item {
      padding-left: 20px;
    }
    .pdf-list {
      padding-left: 24px;
      margin: 8px 0;
      display: flex;
      flex-direction: column;
      gap: 6px;
    }
    .pdf-list li {
      font-size: 1.15rem;
      line-height: 1.6;
    }
    .pdf-task-item {
      list-style: none;
      margin-left: -20px;
      display: flex;
      align-items: center;
      gap: 8px;
    }
    .pdf-task-item input[type="checkbox"] {
      width: 1.15em;
      height: 1.15em;
      cursor: pointer;
    }
    /* 两栏与三栏及多栏（超级块分栏）布局：紧凑自然行距，子列表保留圆点与层级缩进 */
    .layout-two-cols ul,
    .layout-cols-header ul,
    .layout-two-cols-header ul,
    .layout-three-cols ul,
    .layout-three-cols-header ul,
    .two-cols-left ul,
    .two-cols-right ul,
    .three-cols-col ul,
    .col ul,
    .pdf-two-cols-wrapper ul,
    .pdf-three-cols-wrapper ul,
    .pdf-col ul,
    .layout-two-cols-grid .pdf-list,
    .layout-three-cols-grid .pdf-list,
    .layout-cols-grid .pdf-list,
    .layout-two-cols-grid .pdf-list--unordered,
    .layout-three-cols-grid .pdf-list--unordered,
    .layout-cols-grid .pdf-list--unordered {
      list-style: disc !important;
      list-style-type: disc !important;
      padding-left: 1.25em !important;
      margin-left: 0 !important;
      margin-top: 0 !important;
      margin-bottom: 8px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: block !important;
    }
    .layout-two-cols ol,
    .layout-cols-header ol,
    .layout-two-cols-header ol,
    .layout-three-cols ol,
    .layout-three-cols-header ol,
    .two-cols-left ol,
    .two-cols-right ol,
    .three-cols-col ol,
    .col ol,
    .pdf-two-cols-wrapper ol,
    .pdf-three-cols-wrapper ol,
    .pdf-col ol,
    .layout-two-cols-grid .pdf-list--ordered,
    .layout-three-cols-grid .pdf-list--ordered,
    .layout-cols-grid .pdf-list--ordered {
      list-style: decimal !important;
      list-style-type: decimal !important;
      padding-left: 1.25em !important;
      margin-left: 0 !important;
      margin-top: 0 !important;
      margin-bottom: 8px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: block !important;
    }
    .layout-two-cols li,
    .layout-cols-header li,
    .layout-two-cols-header li,
    .layout-three-cols li,
    .layout-three-cols-header li,
    .two-cols-left li,
    .two-cols-right li,
    .three-cols-col li,
    .col li,
    .pdf-col li,
    .pdf-col .pdf-list-item {
      padding-left: 0.2em !important;
      margin-left: 0 !important;
      margin-bottom: 6px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: list-item !important;
      line-height: 1.6 !important;
    }
    .layout-two-cols ul ul,
    .layout-three-cols ul ul,
    .three-cols-col ul ul,
    .pdf-col ul ul {
      list-style: circle !important;
      list-style-type: circle !important;
      padding-left: 1.25em !important;
      margin-top: 4px !important;
      margin-bottom: 4px !important;
    }
    /* 列表项内嵌标题与说明排版 */
    .slide-list-item-title,
    .pdf-list li > h1,
    .pdf-list li > h2,
    .pdf-list li > h3,
    .pdf-list li > h4,
    .pdf-list li > h5,
    .pdf-list li > h6,
    li > h1.slide-list-item-title,
    li > h2.slide-list-item-title,
    li > h3.slide-list-item-title,
    li > h4.slide-list-item-title {
      margin-top: 2px !important;
      margin-bottom: 6px !important;
      line-height: 1.35 !important;
      font-weight: 700 !important;
    }
    .pdf-list li > h1, li > h1.slide-list-item-title { font-size: 1.6rem !important; }
    .pdf-list li > h2, li > h2.slide-list-item-title { font-size: 1.4rem !important; }
    .pdf-list li > h3, li > h3.slide-list-item-title { font-size: 1.22rem !important; }
    .pdf-list li > h4, li > h4.slide-list-item-title { font-size: 1.1rem !important; }

    /* 全局特定标题大小规范化后置强力锁定 (防止被列表项内部字号覆盖) */
    [data-normalize-headings="true"] .slidev-page-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .slidev-page-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      font-size: 1.7rem !important;
      font-weight: 600 !important;
      line-height: 1.25 !important;
      margin-bottom: 10px !important;
    }
    [data-normalize-headings="true"] .has-superblock-cols .slidev-col-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .has-superblock-cols .slidev-col-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .has-superblock-cols .pdf-col > *:first-child :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      font-size: 1.3rem !important;
      font-weight: 600 !important;
      line-height: 1.3 !important;
      margin-bottom: 8px !important;
      text-align: center !important;
    }
    .slide-list-item-desc,
    .pdf-list li > p {
      margin-top: 4px !important;
      margin-bottom: 6px !important;
      font-size: 1.05rem;
      line-height: 1.55;
      opacity: 0.92;
    }
    kbd {
      display: inline-block;
      padding: 2px 7px;
      font-family: ui-monospace, SFMono-Regular, "SF Mono", Menlo, Consolas, "Liberation Mono", monospace;
      font-size: 0.85em;
      font-weight: 600;
      line-height: 1.25;
      color: inherit;
      background: rgba(125, 125, 125, 0.12);
      border: 1px solid rgba(125, 125, 125, 0.35);
      border-bottom-width: 2px;
      border-radius: 5px;
      box-shadow: 0 1px 2px rgba(0, 0, 0, 0.12);
      margin: 0 2px;
      vertical-align: middle;
      white-space: nowrap;
    }
    .theme-dark kbd {
      background: rgba(255, 255, 255, 0.1);
      border-color: rgba(255, 255, 255, 0.25);
      border-bottom-color: rgba(255, 255, 255, 0.4);
      color: #f1f5f9;
      box-shadow: 0 1px 2px rgba(0, 0, 0, 0.4);
    }
    a {
      color: inherit;
      text-decoration: none;
      border-bottom: 1px dashed currentColor;
    }
    .slidev-ref-tag, a.slidev-ref-tag {
      display: inline-flex;
      align-items: center;
      background: rgba(16, 185, 129, 0.1);
      color: #059669;
      border: 1px solid rgba(16, 185, 129, 0.25);
      border-radius: 4px;
      padding: 2px 8px;
      font-size: 0.88em;
      text-decoration: none;
      margin: 2px 4px 2px 0;
    }
    .theme-dark .slidev-ref-tag, .theme-dark a.slidev-ref-tag {
      background: rgba(52, 211, 153, 0.15);
      color: #34d399;
      border-color: rgba(52, 211, 153, 0.3);
    }
    .slidev-block-ref, .pdf-block--ref {
      background: rgba(16, 185, 129, 0.06);
      border-left: 3px solid #059669;
      border-radius: 0 6px 6px 0;
      padding: 10px 14px;
      margin: 8px 0;
    }
    .theme-dark .slidev-block-ref, .theme-dark .pdf-block--ref {
      background: rgba(52, 211, 153, 0.08);
      border-left-color: #34d399;
    }
    .pdf-slide-notes {
      font-size: 14px;
      color: #059669;
      border-top: 1px dashed #cbd5e1;
      padding-top: 12px;
      margin-top: auto;
      line-height: 1.5;
    }
    .theme-dark .pdf-slide-notes {
      color: #34d399;
      border-top-color: #334155;
    }
    /* Layouts */
    .layout-cover .pdf-slide-body {
      justify-content: center;
      align-items: center;
      text-align: center;
    }
    .layout-cover h1 {
      font-size: 3.2rem;
    }
    .layout-center .pdf-slide-body {
      justify-content: center;
      align-items: center;
      text-align: center;
    }
    .layout-fact .pdf-slide-body {
      justify-content: center;
      align-items: center;
      text-align: center;
    }
    .layout-fact h1 {
      font-size: 4.5rem;
      color: #ef4444;
    }
    @media print {
      .slidev-motion-fade-in,
      .slidev-motion-slide-up,
      .slidev-motion-slide-down,
      .slidev-motion-slide-left,
      .slidev-motion-slide-right,
      .slidev-motion-zoom-in,
      .slidev-motion-pop,
      .slidev-motion-bounce {
        animation: none !important;
        opacity: 1 !important;
        transform: none !important;
      }
      /* PDF 打印讲义下禁用动态蒙版遮挡，保证内容 100% 完整可见 */
      .slidev-mask-layer,
      .slidev-mask-overlay,
      .slidev-mask-divider-line {
        display: none !important;
        opacity: 0 !important;
      }
      .slidev-mask-body-container {
        clip-path: none !important;
        -webkit-clip-path: none !important;
        overflow: visible !important;
      }
    }
  `}function cg(e,t){const i="Slidev 演示讲义",n="16:9",o="light",s=e.slides.map((l,r)=>{const a=l.frontmatter.layout||"default",c=l.frontmatter.spacing,d=c&&c!=="inherit"?c:e.config.spacing||"normal",p=Wm(l),b=`${r+1} / ${e.slides.length}`;return`
      <section class="pdf-slide-page layout-${a} theme-${o} spacing-${d}">
        <header class="pdf-slide-header">
          <span class="pdf-doc-title">${at(i)}</span>
          ${`<span class="pdf-page-badge">P. ${b}</span>`}
        </header>
        <div class="pdf-slide-body">
          ${p}
        </div>
        ${l.notes?`
          <footer class="pdf-slide-notes">
            <strong>演讲备注:</strong> ${at(l.notes)}
          </footer>
        `:""}
      </section>
    `}).join(`
`);return`<!DOCTYPE html>
<html lang="zh-CN">
<head>
  <meta charset="UTF-8">
  <title>${at(i)} - 高保真讲义</title>
  <style>
    ${ag({pageRatio:n,customInlineStyles:t==null?void 0:t.customInlineStyles})}
  </style>
</head>
<body data-normalize-headings="${e.config.normalizeHeadingSizes?"true":"false"}">
  ${s}
</body>
</html>`}function Ta(e,t){var o;if(typeof window>"u"||typeof document>"u")return!1;const i=cg(e,t);try{const s=document.createElement("iframe");s.style.position="fixed",s.style.right="0",s.style.bottom="0",s.style.width="0",s.style.height="0",s.style.border="none",s.style.visibility="hidden",document.body.appendChild(s);const l=(o=s.contentWindow)==null?void 0:o.document;if(l)return l.open(),l.write(i),l.close(),setTimeout(()=>{var r,a;try{(r=s.contentWindow)==null||r.focus(),(a=s.contentWindow)==null||a.print()}finally{setTimeout(()=>{s.remove()},2e3)}},350),!0}catch(s){console.warn("[pdf-exporter] iframe 打印模式异常，降级尝试 window.open:",s)}const n=window.open("","_blank");return n?(n.document.write(i),n.document.close(),n.focus(),setTimeout(()=>{n.print(),n.close()},350),!0):!1}const dg=1500,ug=500,fg=4,pg=new Set(["INPUT","TEXTAREA","SELECT"]);function Aa(e){const t=e;return!t||!t.tagName?!1:pg.has(t.tagName)||t.isContentEditable===!0}function hg(e){let t="",i=!1,n=null,o=null;function s(){e.onStateChange&&e.onStateChange({display:t,invalid:i})}function l(){n&&(clearTimeout(n),n=null),o&&(clearTimeout(o),o=null)}function r(){l(),t="",i=!1,s()}function a(){n&&clearTimeout(n),n=setTimeout(r,dg)}function c(){n&&(clearTimeout(n),n=null),i=!0,s(),o&&clearTimeout(o),o=setTimeout(r,ug)}function d(p){if(e.isEnabled&&!e.isEnabled()||Aa(p.target)||p.isComposing||p.ctrlKey||p.metaKey||p.altKey)return!1;if(/^[0-9]$/.test(p.key))return i||t.length>=fg||(t+=p.key,s(),a()),!0;if(p.key==="Enter"){if(!t||i)return!1;const u=parseInt(t,10),h=e.getTotalPages();return!isNaN(u)&&u>=1&&h>0&&u<=h?(r(),e.onJump(u),!0):(c(),!0)}return p.key==="Escape"&&(t||i)?(r(),!0):!1}return{handleKeydown:d,getState:()=>({display:t,invalid:i}),clear:r}}const mg={class:"spm-slidev-tab__toolbar"},gg={class:"spm-slidev-tab__nav"},vg=["disabled"],bg={class:"spm-page-badge"},yg=["disabled"],kg=["aria-label"],wg=["aria-label"],xg={class:"spm-slidev-tab__tools"},Sg=["src"],_g=Ct({__name:"SlidevPreviewTab",setup(e,{expose:t}){const i=ti("plugin"),n=ti("sandboxBridge",new Ys),o=new zm(n),s=new Kf,l=fe("web-sandbox"),r=fe(3030),a=fe(null),c=fe(!1),d=fe(null),p=fe(1),b=fe(1),u=fe([]),h=fe(!1),f=fe(!1),g=fe(!1),k=fe("siyuan"),S=fe(""),C=fe(""),T=fe(""),B=fe(!1),I=fe(!1),w=fe(""),P=fe(""),R=fe(!1),z=hg({getTotalPages:()=>b.value,isEnabled:()=>!f.value,onJump:x=>L(x),onStateChange:x=>{P.value=x.display,R.value=x.invalid}});function V(x){if(x.key==="o"||x.key==="O"){if(f.value||x.isComposing||x.ctrlKey||x.metaKey||x.altKey||Aa(x.target))return;x.preventDefault(),_();return}z.handleKeydown(x)&&x.preventDefault()}function _(){var x,M;if(l.value==="pro-cli"){(x=d.value)==null||x.focus(),me.showMessage("Pro 模式使用官方原生总览：在画面内按 O 呼出");return}n.toggleOverview(),(M=d.value)==null||M.focus()}function L(x){var M;p.value=x,l.value==="pro-cli"?s.nativeBridge.navigateToPage(x):n.navigatePage(x),(M=d.value)==null||M.focus()}const y=fe("/plugins/siyuan-slidev/slidev-client/index.html");let A=null,F=null,E=null,D=null,N=null,X=null,j=null;Fn(()=>{d.value&&(n.attach(d.value),s.nativeBridge.attach(d.value)),A=n.onSlideChanged((x,M)=>{p.value=x,b.value=M}),F=n.onBlockClicked((x,M)=>{p.value=M,o.setActiveBlockId(x),i&&typeof i.handleBlockClickedFromSlide=="function"?i.handleBlockClickedFromSlide(x,M):Li(x,i==null?void 0:i.app)}),E=n.onOpenInEditor((x,M)=>{p.value=M,o.setActiveBlockId(x),Li(x,i==null?void 0:i.app)}),D=s.nativeBridge.onPageChanged((x,M)=>{p.value=x,b.value=M}),N=n.onOpenPeekDrawer(async x=>{const M=No();if(x.peekType==="siyuan"&&M.enableWebServeJump){let Y=!1;if(j&&j.docId===x.target)Y=!0;else if(j&&j.slides&&j.slides.some(U=>{var Z;return(Z=U.blocks)==null?void 0:Z.some(Q=>Q.id===x.target)}))Y=!1;else try{const U=await en(`SELECT id, root_id, type FROM blocks WHERE id = '${x.target}' LIMIT 1`);U&&U.length>0&&(Y=U[0].type==="d"||U[0].id===U[0].root_id)}catch(U){console.warn("[SlidevPreviewTab] detect block type failed:",U)}k.value="web",B.value=!0,C.value=ua(M.webServeUrl,x.target,{focus:!Y}),T.value=x.title||`${Y?"思源文档":"思源块"}: ${x.target.slice(0,8)}`,f.value=!0,n.freezeKeyboardNav(!0)}else{if(k.value=x.peekType,x.peekType==="siyuan")S.value=x.target,T.value=x.title||`块速览: ${x.target.slice(0,8)}`;else{const Y=Sa(x.target);if(Y.external){O(x.target);return}B.value=!0,C.value=Y.url,T.value=x.title||Y.url}f.value=!0,n.freezeKeyboardNav(!0)}}),X=n.onRequestToggleFullscreen(()=>{v()}),typeof document<"u"&&document.addEventListener("fullscreenchange",W)}),Fs(()=>{typeof document<"u"&&document.removeEventListener("fullscreenchange",W),N&&N(),X&&X(),A&&A(),F&&F(),E&&E(),D&&D(),n.detach(),z.clear(),o.destroy(),s.destroy()});async function G(){if(l.value==="web-sandbox"){if(!j){me.showMessage("请先在主编辑区打开演示文档");return}me.showMessage("正在探测本地 Node 环境并编排 Slidev Pro 进程...");const x=await s.startProMode(j,rs);if(!x.success){me.showMessage(`无法启动官方 Pro 模式：${x.error}`);return}l.value="pro-cli",r.value=x.port||3030,y.value=x.url,d.value&&s.nativeBridge.attach(d.value),me.showMessage(`🟢 已成功接入官方原生 Slidev 服务 (端口: ${r.value})`)}else s.stopProMode(),l.value="web-sandbox",y.value="/plugins/siyuan-slidev/slidev-client/index.html",d.value&&n.attach(d.value),me.showMessage("已切回内置高保真沙箱")}function ne(){I.value=!I.value,I.value?(w.value=(j==null?void 0:j.docId)||"",i&&typeof i.updatePreviewTabHeader=="function"&&i.updatePreviewTabHeader("",w.value)):(w.value="",q(),i&&typeof i.updatePreviewTabHeader=="function"&&i.updatePreviewTabHeader())}let se=0;function le(x){if(f.value||Math.abs(x.deltaY)<Math.abs(x.deltaX)||Math.abs(x.deltaY)<15)return;const M=Date.now();M-se<280||(se=M,x.deltaY>0?Te():pe())}function pe(){if(p.value>1){const x=p.value-1;p.value=x,l.value==="pro-cli"?s.nativeBridge.navigateToPage(x):n.navigatePage(x)}}function Te(){if(p.value<b.value){const x=p.value+1;p.value=x,l.value==="pro-cli"?s.nativeBridge.navigateToPage(x):n.navigatePage(x)}}function be(x){p.value=x,l.value==="pro-cli"?s.nativeBridge.navigateToPage(x):n.navigatePage(x)}function q(){i&&typeof i.compileCurrentDocument=="function"?i.compileCurrentDocument():i!=null&&i.eventBus&&typeof i.eventBus.emit=="function"&&i.eventBus.emit("slidev:request-compile")}function ae(){f.value=!1,n.freezeKeyboardNav(!1)}function ve(){ae()}function O(x){var Z,Q;const M=/^file:/i.test(x),Y=M||/^[a-zA-Z]:[\\/]/.test(x),U=_t("electron");if(Y&&typeof((Z=U==null?void 0:U.shell)==null?void 0:Z.openPath)=="function"){U.shell.openPath(M?xa(x):x),me.showMessage("本地文件不在思源工作区内，已交由系统默认浏览器打开");return}typeof((Q=U==null?void 0:U.shell)==null?void 0:Q.openExternal)=="function"?U.shell.openExternal(x).catch(()=>{typeof window<"u"&&window.open(x,"_blank")}):typeof window<"u"&&window.open(x,"_blank"),me.showMessage("该地址无法在速览抽屉内加载，已交由系统默认浏览器打开")}function W(){typeof document<"u"&&(c.value=!!document.fullscreenElement,n.postMessage("FULLSCREEN_CHANGED",{isFullscreen:c.value}))}function v(){const x=a.value||d.value;x&&(document.fullscreenElement?document.exitFullscreen().then(()=>{n.postMessage("FULLSCREEN_CHANGED",{isFullscreen:!1})}).catch(()=>{}):x.requestFullscreen().then(()=>{n.postMessage("FULLSCREEN_CHANGED",{isFullscreen:!0})}).catch(()=>{}))}function K(){window.open("/plugins/siyuan-slidev/slidev-client/presenter.html","SlidevPresenter","width=1200,height=800")}function H(){if(!j){me.showMessage("请先在主编辑区打开幻灯片文档");return}const x=Ia(j);Ea("presentation.html",x)&&me.showMessage("已开始下载单文件离线 HTML 演示包")}function $(){if(!j){me.showMessage("请先在主编辑区打开幻灯片文档");return}Ta(j)&&me.showMessage("已唤起打印视窗，请在打印选项中选择「另存为 PDF」")}return t({updateDocument(x,M){I.value&&w.value&&M&&M!==w.value||(j=x,I.value&&!w.value&&(w.value=x.docId),u.value=x.slides,b.value=x.slides.length,o.setDocId(x.docId),o.updateSlidesIndex(x.slides),l.value==="pro-cli"?s.scaffolder.scaffold(x,rs).catch(()=>{}):n.updateSlides(x.slides,x.config,x.fullMarkdown,x.customThemeCss),i&&typeof i.updatePreviewTabHeader=="function"&&i.updatePreviewTabHeader("",x.docId))},navigateToBlock(x){o.onCursorFocusBlock(x)},isPinned:I,pinnedDocId:w,engineMode:l,toggleEngineMode:G}),(x,M)=>(ee(),te("div",{class:"spm-slidev-preview-tab",onKeydown:V},[m("div",mg,[m("div",gg,[m("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s",disabled:p.value<=1,"aria-label":"上一页",onClick:pe},[re(ce,{name:"chevron-left"})],8,vg),m("span",bg,we(p.value)+" / "+we(b.value||1),1),m("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s",disabled:p.value>=b.value,"aria-label":"下一页",onClick:Te},[re(ce,{name:"chevron-right"})],8,yg),m("button",{class:_e(["spm-icon-btn b3-tooltips b3-tooltips__s",{"is-primary":I.value}]),"aria-label":I.value?"已锁定当前文档（点击解除）："+w.value:"点击锁定当前文档（不随主编辑区切换）",onClick:ne},[re(ce,{name:"pin"}),m("span",null,we(I.value?"已锁定":"跟随"),1)],10,kg),m("button",{class:_e(["spm-icon-btn b3-tooltips b3-tooltips__s",{"is-primary":l.value==="pro-cli"}]),"aria-label":l.value==="pro-cli"?"当前：官方原生 Pro 模式 (localhost:"+r.value+")，点击切回沙箱":"当前：内置高保真沙箱，点击切换官方原生 Pro 模式",onClick:G},[re(ce,{name:"rocket"}),m("span",null,we(l.value==="pro-cli"?"Pro ("+r.value+")":"沙箱"),1)],10,wg)]),m("div",xg,[m("button",{class:_e(["spm-icon-btn b3-tooltips b3-tooltips__s",{"is-primary":h.value}]),"aria-label":"切换幻灯片大纲抽屉",onClick:M[0]||(M[0]=Y=>h.value=!h.value)},[re(ce,{name:"outline"})],2),m("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"缩略图总览 (O)",onClick:_},[re(ce,{name:"columns"})]),m("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"双屏演讲者视图 (Presenter Mode ⌥M)",onClick:K},[re(ce,{name:"presenter"})]),m("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"导出单文件 HTML 演示包",onClick:H},[re(ce,{name:"export-html"})]),m("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"导出 16:9 PDF 演示讲义",onClick:$},[re(ce,{name:"export-pdf"})]),m("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"重新编译并刷新",onClick:q},[re(ce,{name:"refresh"})]),m("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"全屏放映",onClick:v},[re(ce,{name:"fullscreen"})])])]),m("div",{ref_key:"fullscreenContainerRef",ref:a,class:"spm-slidev-tab__viewport spm-slidev-fullscreen-container",onWheel:le},[m("iframe",{ref_key:"sandboxIframeRef",ref:d,class:"spm-slidev-tab__iframe",src:y.value,frameborder:"0",allow:"fullscreen; autoplay"},null,8,Sg),re(Jh,{visible:f.value,"onUpdate:visible":M[1]||(M[1]=Y=>f.value=Y),"is-maximized":g.value,"onUpdate:isMaximized":M[2]||(M[2]=Y=>g.value=Y),title:T.value,onClose:ae},{default:Dl(()=>[k.value==="siyuan"&&S.value?(ee(),Dt(rm,{key:0,"block-id":S.value,title:T.value,plugin:ge(i),onExternalJump:ve},null,8,["block-id","title","plugin"])):Oe("",!0),B.value?Tt((ee(),Dt(Pm,{key:1,visible:f.value&&k.value==="web",url:C.value,title:T.value,onExternalJump:ve},null,8,["visible","url","title"])),[[ys,k.value==="web"]]):Oe("",!0)]),_:1},8,["visible","is-maximized","title"]),Tt(m("div",{class:_e(["spm-jump-badge",{"is-invalid":R.value}])},we(P.value),3),[[ys,P.value]])],544),h.value&&u.value.length>0?(ee(),Dt(jh,{key:0,slides:u.value,"current-active-page":p.value,onNavigate:be,onRefresh:q},null,8,["slides","current-active-page"])):Oe("",!0)],32))}}),Cg=zt(_g,[["__scopeId","data-v-1d6a7f35"]]),$g={class:"spm-section spm-section--page"},Ig={class:"spm-section-header"},Eg={key:0,class:"spm-card-control",style:{"border-left":"3px solid var(--b3-theme-primary)",background:"rgba(var(--b3-theme-primary-rgb, 66, 133, 244), 0.06)",padding:"8px 12px","margin-top":"6px"}},Tg={style:{display:"flex","align-items":"center","justify-content":"space-between",gap:"8px"}},Ag={style:{"font-size":"11px",display:"flex","align-items":"center",gap:"6px",flex:"1"}},Bg={key:1,class:"spm-card-control"},Mg={class:"spm-control-header"},Dg={class:"spm-control-title-group"},Lg={class:"spm-control-title"},Og={class:"spm-quick-chips"},Rg=["onClick"],Pg={style:{display:"flex",gap:"6px","align-items":"center","margin-top":"6px"}},Ng=["value"],zg=["aria-label"],Fg={key:1,class:"spm-icon-btn b3-tooltips b3-tooltips__w",disabled:"",style:{opacity:"0.45",cursor:"not-allowed",padding:"0 8px",height:"26px","font-size":"11px","white-space":"nowrap","flex-shrink":"0"},"aria-label":"当前页未检测到调整过列宽的横向超级块"},Hg={key:0,style:{"margin-top":"6px","font-size":"11px",opacity:"0.85",display:"flex","align-items":"center",gap:"4px"}},jg={style:{background:"rgba(125, 125, 125, 0.15)",padding:"1px 4px","border-radius":"3px","font-weight":"bold"}},Wg={key:1,style:{"margin-top":"6px","font-size":"11px",opacity:"0.6",display:"flex","align-items":"center",gap:"4px"}},Ug={class:"spm-card-control"},Vg={class:"spm-control-header"},Kg={class:"spm-control-title-group"},qg={class:"spm-control-title"},Gg={class:"spm-segmented-group"},Zg={key:0,style:{"margin-top":"10px",display:"flex","flex-direction":"column",gap:"8px"}},Yg={style:{display:"flex","align-items":"center","justify-content":"space-between"}},Jg={class:"b3-tooltips b3-tooltips__w","aria-label":`输入规则：
• 权重比例（项数决定步数）：如 1:1 (2步等分)、1:1:1 (3步等分)、1:2:1 (按权重累计分段)
• 绝对百分比：如 25:75:100 或 30:80 (指定每步展开的累计百分比)
• 每次点击或按空格/向右键展露下一段，全部揭开后翻页`,style:{cursor:"help",opacity:"0.75",display:"inline-flex","align-items":"center",gap:"3px","font-size":"11px"}},Xg={class:"spm-quick-chips"},Qg=["onClick"],ev={class:"b3-tooltips b3-tooltips__n",style:{width:"100%",display:"block"},"aria-label":"输入权重比例（如 1:2:1）或绝对累计百分比断点（如 25:75:100），冒号项数决定点击步数"},tv=["value"],iv={style:{display:"flex",gap:"8px","margin-top":"2px"}},nv={style:{flex:"1"}},ov={class:"spm-segmented-group"},sv={style:{flex:"1"}},rv={class:"spm-segmented-group"},lv={class:"spm-card-control"},av={class:"spm-control-header"},cv={class:"spm-control-title-group"},dv={class:"spm-control-title"},uv={class:"spm-segmented-group"},fv={class:"spm-card-control"},pv={class:"spm-control-header"},hv={class:"spm-control-title-group"},mv={class:"spm-control-title"},gv={class:"spm-quick-chips"},vv=["onClick"],bv=["value"],yv={key:2,class:"spm-card-control"},kv={class:"spm-control-header"},wv={class:"spm-control-title-group"},xv={class:"spm-control-title"},Sv={class:"spm-quick-chips"},_v=["onClick"],Cv=["value"],$v={class:"spm-card-control"},Iv={class:"spm-control-header"},Ev={class:"spm-control-title-group"},Tv={class:"spm-control-title"},Av={key:0,class:"spm-note-status-box"},Bv=["title"],Mv={class:"spm-action-grid",style:{"margin-top":"6px"}},Dv={key:1,class:"spm-note-empty-box"},Lv={class:"spm-batch-actions-box",style:{"margin-top":"8px","border-top":"1px dashed var(--b3-border-color, #e2e8f0)","padding-top":"8px"}},Ov={class:"spm-action-grid"},Rv=["disabled"],Pv=["disabled"],Nv={class:"spm-card-control"},zv={class:"spm-action-grid"},Fv=Ct({__name:"PageInspectorSection",props:{pageLayout:{},pageTransition:{},pageBackground:{},pageSpacing:{},pageImage:{},pageNotes:{},pageIndex:{},pageLayoutRatio:{},pageMask:{},pageMaskRatio:{},pageMaskStyle:{},pageMaskInitial:{},detectedSbRatio:{},detectedSbInfo:{},isBatchProcessing:{type:Boolean}},emits:["update:pageLayout","update:pageTransition","update:pageBackground","update:pageSpacing","update:pageImage","update:pageLayoutRatio","update:pageMask","update:pageMaskRatio","update:pageMaskStyle","update:pageMaskInitial","applySuperBlockLayout","resetSuperblockRatio","addNoteBlock","locateNoteBlock","generateNotes","batchAppendNotes","batchDeleteNotes","insertDividerAfter","deleteDivider"],setup(e,{emit:t}){const i=e,n=t,o=[{label:"1:1 (2步)",value:"1:1"},{label:"1:1:1 (3步)",value:"1:1:1"},{label:"1:2:1 (非等宽)",value:"1:2:1"},{label:"1:1:1:1 (4步)",value:"1:1:1:1"}],s=xe(()=>["two-cols","cols-header","two-cols-header","three-cols-header","image-left","image-right"].includes(i.pageLayout)),l=xe(()=>{var f,g;if(i.pageLayout==="two-cols-header"||i.pageLayout==="two-cols"||i.pageLayout==="image-left"||i.pageLayout==="image-right")return 2;if(i.pageLayout==="three-cols-header")return 3;const u=(i.pageLayoutRatio||"").trim();if(u.includes(":")){const k=u.split(":").filter(Boolean).length;if(k>=2&&k<=6)return k}const h=(i.detectedSbRatio||"").trim();if(h.includes(":")){const k=h.split(":").filter(Boolean).length;if(k>=2&&k<=6)return k}if((f=i.detectedSbInfo)!=null&&f.colCount&&i.detectedSbInfo.colCount>=2)return Math.min(i.detectedSbInfo.colCount,6);if((g=i.detectedSbInfo)!=null&&g.slots&&Array.isArray(i.detectedSbInfo.slots)){const k=i.detectedSbInfo.slots.length;if(k>=2&&k<=6)return k}return 2}),r=xe(()=>{const u=l.value;return u===3?[{label:"默认 1:1:1",value:""},{label:"1:2:1 (主中)",value:"1:2:1"},{label:"2:1:1 (主左)",value:"2:1:1"},{label:"1:1:2 (主右)",value:"1:1:2"},{label:"1:3:1",value:"1:3:1"}]:u===4?[{label:"默认 1:1:1:1",value:""},{label:"1:2:2:1",value:"1:2:2:1"},{label:"2:1:1:2",value:"2:1:1:2"}]:u===5?[{label:"默认 1:1:1:1:1",value:""}]:u===6?[{label:"默认 1:1:1:1:1:1",value:""}]:[{label:"默认 1:1",value:""},{label:"1:2",value:"1:2"},{label:"2:1",value:"2:1"},{label:"3:7",value:"3:7"},{label:"7:3",value:"7:3"},{label:"4:6",value:"4:6"},{label:"6:4",value:"6:4"}]}),a=xe(()=>i.pageLayoutRatio||"");function c(){const u=l.value||2,h=Array(u).fill("1").join(":");n("update:pageLayoutRatio",h),n("resetSuperblockRatio")}const d=xe(()=>{if(!i.pageNotes)return"";const u=i.pageNotes.replace(/[\r\n]+/g," ").trim();return u.length>50?u.slice(0,50)+"...":u}),p=[{label:"默认",value:""},{label:"暗黑 #1e1e24",value:"#1e1e24"},{label:"极夜 #0f172a",value:"#0f172a"},{label:"极简白 #ffffff",value:"#ffffff"}],b=[{label:"默认封面",value:"https://cover.sli.dev"},{label:"清空配图",value:""}];return(u,h)=>(ee(),te("div",$g,[m("div",Ig,[m("span",null,"幻灯片页面设置"+we(e.pageIndex?` (第 ${e.pageIndex} 页)`:""),1)]),re(wa,{"model-value":e.pageLayout,onChange:h[0]||(h[0]=f=>u.$emit("update:pageLayout",f))},null,8,["model-value"]),!s.value&&e.pageLayout!=="clover"&&e.detectedSbRatio?(ee(),te("div",Eg,[m("div",Tg,[m("div",Ag,[re(ce,{name:"sparkles"}),m("span",null,[h[31]||(h[31]=$t("检测到本页横向超级块列宽比例：",-1)),m("b",null,we(e.detectedSbRatio),1)])]),m("button",{class:"spm-btn-action b3-tooltips b3-tooltips__w","aria-label":"一键将本页版式设为分栏并应用超级块列宽",style:{padding:"2px 8px",height:"26px","font-size":"11px","flex-shrink":"0",background:"var(--b3-theme-primary)",color:"#fff",display:"inline-flex","align-items":"center",gap:"4px"},onClick:h[1]||(h[1]=f=>u.$emit("applySuperBlockLayout",e.detectedSbInfo||{recommendedLayout:"two-cols",ratio:e.detectedSbRatio}))},[re(ce,{name:"columns"}),h[32]||(h[32]=m("span",null,"设为分栏",-1))])])])):Oe("",!0),s.value?(ee(),te("div",Bg,[m("div",Mg,[m("div",Dg,[m("div",Lg,[re(ce,{name:"ratio"}),h[33]||(h[33]=m("span",null,"分栏比例 (Ratio)",-1))]),h[34]||(h[34]=m("span",{class:"spm-control-desc"},"设置各列横向空间占比，默认平均分配",-1))])]),m("div",Og,[(ee(!0),te(Ue,null,kt(r.value,f=>(ee(),te("button",{key:f.value,class:_e(["spm-chip",{active:a.value===f.value}]),onClick:g=>u.$emit("update:pageLayoutRatio",f.value)},we(f.label),11,Rg))),128))]),m("div",Pg,[m("input",{value:e.pageLayoutRatio||"",class:"spm-input",style:{flex:"1","min-width":"0"},placeholder:"自定义比例（如 1:2 或 30:70，留空为默认）",onInput:h[2]||(h[2]=f=>u.$emit("update:pageLayoutRatio",f.target.value)),onChange:h[3]||(h[3]=f=>u.$emit("update:pageLayoutRatio",f.target.value))},null,40,Ng),e.detectedSbRatio?(ee(),te("button",{key:0,class:"spm-icon-btn b3-tooltips b3-tooltips__w","aria-label":`从当前页思源超级块读取实际宽度比例 (${e.detectedSbRatio}) 并应用`,style:{padding:"0 8px",height:"26px","font-size":"11px","white-space":"nowrap","flex-shrink":"0"},onClick:h[4]||(h[4]=f=>u.$emit("update:pageLayoutRatio",e.detectedSbRatio))},[re(ce,{name:"sparkles"}),h[35]||(h[35]=m("span",null,"读取",-1))],8,zg)):(ee(),te("button",Fg,[re(ce,{name:"sparkles"}),h[36]||(h[36]=m("span",null,"读取",-1))])),m("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__w","aria-label":"重置渲染比例为平均分布，并立即重置文档中超级块内容分布比例",style:{padding:"0 8px",height:"26px","font-size":"11px","white-space":"nowrap","flex-shrink":"0"},onClick:c},[re(ce,{name:"reset"}),h[37]||(h[37]=m("span",null,"重置",-1))])]),e.detectedSbRatio?(ee(),te("div",Hg,[re(ce,{name:"ratio"}),h[38]||(h[38]=m("span",null,"检测到思源超级块宽度：",-1)),m("code",jg,we(e.detectedSbRatio),1)])):(ee(),te("div",Wg,[re(ce,{name:"ratio"}),h[39]||(h[39]=m("span",null,"未检测到调宽超级块（默认各列平均分配）",-1))]))])):Oe("",!0),re(Js,{"model-value":e.pageTransition,onChange:h[5]||(h[5]=f=>u.$emit("update:pageTransition",f))},null,8,["model-value"]),m("div",Ug,[m("div",Vg,[m("div",Kg,[m("div",qg,[re(ce,{name:"sparkles"}),h[40]||(h[40]=m("span",null,"页面动态蒙版 (Dynamic Mask)",-1))]),h[41]||(h[41]=m("span",{class:"spm-control-desc"},"随着点击操作分段展露正文内容",-1))])]),m("div",Gg,[m("button",{class:_e(["spm-segmented-item",{active:!e.pageMask}]),onClick:h[6]||(h[6]=f=>u.$emit("update:pageMask",""))}," 关闭 ",2),m("button",{class:_e(["spm-segmented-item",{active:e.pageMask==="down"}]),onClick:h[7]||(h[7]=f=>u.$emit("update:pageMask","down"))}," 从上至下 ",2),m("button",{class:_e(["spm-segmented-item",{active:e.pageMask==="right"}]),onClick:h[8]||(h[8]=f=>u.$emit("update:pageMask","right"))}," 从左至右 ",2)]),e.pageMask?(ee(),te("div",Zg,[m("div",Yg,[h[43]||(h[43]=m("div",{style:{"font-size":"11px",opacity:"0.85","font-weight":"500"}},"展露比例 / 断点",-1)),m("span",Jg,[re(ce,{name:"help"}),h[42]||(h[42]=m("span",null,"输入规则",-1))])]),m("div",Xg,[(ee(),te(Ue,null,kt(o,f=>m("button",{key:f.value,class:_e(["spm-chip",{active:(e.pageMaskRatio||"1:1")===f.value}]),onClick:g=>u.$emit("update:pageMaskRatio",f.value)},we(f.label),11,Qg)),64))]),m("div",ev,[m("input",{value:e.pageMaskRatio||"1:1",class:"spm-input",style:{width:"100%"},placeholder:"自定义比例或断点（如 1:2:1 或 25:75:100）",onInput:h[9]||(h[9]=f=>u.$emit("update:pageMaskRatio",f.target.value)),onChange:h[10]||(h[10]=f=>u.$emit("update:pageMaskRatio",f.target.value))},null,40,tv)]),h[46]||(h[46]=m("div",{style:{"font-size":"10.5px",opacity:"0.6","line-height":"1.35","margin-top":"-2px"}}," 提示：支持权重比（如 1:2:1）或绝对断点（如 25:75:100），冒号项数决定点击步数 ",-1)),m("div",iv,[m("div",nv,[h[44]||(h[44]=m("div",{style:{"font-size":"11px",opacity:"0.85","margin-bottom":"4px"}},"遮盖质感",-1)),m("div",ov,[m("button",{class:_e(["spm-segmented-item",{active:!e.pageMaskStyle||e.pageMaskStyle==="solid"}]),onClick:h[11]||(h[11]=f=>u.$emit("update:pageMaskStyle","solid"))}," 背景同色 ",2),m("button",{class:_e(["spm-segmented-item",{active:e.pageMaskStyle==="blur"}]),onClick:h[12]||(h[12]=f=>u.$emit("update:pageMaskStyle","blur"))}," 磨砂毛玻璃 ",2)])]),m("div",sv,[h[45]||(h[45]=m("div",{style:{"font-size":"11px",opacity:"0.85","margin-bottom":"4px"}},"初始展露",-1)),m("div",rv,[m("button",{class:_e(["spm-segmented-item",{active:!e.pageMaskInitial||e.pageMaskInitial==="hidden"}]),onClick:h[13]||(h[13]=f=>u.$emit("update:pageMaskInitial","hidden"))}," 完全遮盖 ",2),m("button",{class:_e(["spm-segmented-item",{active:e.pageMaskInitial==="revealed"}]),onClick:h[14]||(h[14]=f=>u.$emit("update:pageMaskInitial","revealed"))}," 首段可见 ",2)])])])])):Oe("",!0)]),m("div",lv,[m("div",av,[m("div",cv,[m("div",dv,[re(ce,{name:"ratio"}),h[47]||(h[47]=m("span",null,"页面间距 (Spacing)",-1))]),h[48]||(h[48]=m("span",{class:"spm-control-desc"},"覆盖本页内边距与顶部标题间距",-1))])]),m("div",uv,[m("button",{class:_e(["spm-segmented-item",{active:!e.pageSpacing||e.pageSpacing==="inherit"}]),onClick:h[15]||(h[15]=f=>u.$emit("update:pageSpacing","inherit"))}," 继承全局 ",2),m("button",{class:_e(["spm-segmented-item",{active:e.pageSpacing==="compact"}]),onClick:h[16]||(h[16]=f=>u.$emit("update:pageSpacing","compact"))}," 紧凑 ",2),m("button",{class:_e(["spm-segmented-item",{active:e.pageSpacing==="normal"}]),onClick:h[17]||(h[17]=f=>u.$emit("update:pageSpacing","normal"))}," 标准 ",2),m("button",{class:_e(["spm-segmented-item",{active:e.pageSpacing==="loose"}]),onClick:h[18]||(h[18]=f=>u.$emit("update:pageSpacing","loose"))}," 宽松 ",2)])]),m("div",fv,[m("div",pv,[m("div",hv,[m("div",mv,[re(ce,{name:"palette"}),h[49]||(h[49]=m("span",null,"页面背景 (Background)",-1))]),h[50]||(h[50]=m("span",{class:"spm-control-desc"},"设置当前页特定底色或壁纸",-1))])]),m("div",gv,[(ee(),te(Ue,null,kt(p,f=>m("button",{key:f.value,class:_e(["spm-chip",{active:e.pageBackground===f.value}]),onClick:g=>u.$emit("update:pageBackground",f.value)},we(f.label),11,vv)),64))]),m("input",{value:e.pageBackground,class:"spm-input",placeholder:"自定义颜色代码或资源路径",onInput:h[19]||(h[19]=f=>u.$emit("update:pageBackground",f.target.value)),onChange:h[20]||(h[20]=f=>u.$emit("update:pageBackground",f.target.value))},null,40,bv)]),e.pageLayout==="image-right"||e.pageLayout==="image-left"||e.pageImage?(ee(),te("div",yv,[m("div",kv,[m("div",wv,[m("div",xv,[re(ce,{name:"image"}),h[51]||(h[51]=m("span",null,"页面图片 (Image)",-1))]),h[52]||(h[52]=m("span",{class:"spm-control-desc"},"图文分栏或页面专属配图 URL / 资源路径",-1))])]),m("div",Sv,[(ee(),te(Ue,null,kt(b,f=>m("button",{key:f.value,class:_e(["spm-chip",{active:e.pageImage===f.value}]),onClick:g=>u.$emit("update:pageImage",f.value)},we(f.label),11,_v)),64))]),m("input",{value:e.pageImage,class:"spm-input",placeholder:"网络图片 URL (如 https://cover.sli.dev) 或 assets/...",onInput:h[21]||(h[21]=f=>u.$emit("update:pageImage",f.target.value)),onChange:h[22]||(h[22]=f=>u.$emit("update:pageImage",f.target.value))},null,40,Cv)])):Oe("",!0),m("div",$v,[m("div",Iv,[m("div",Ev,[m("div",Tv,[re(ce,{name:"presenter"}),h[53]||(h[53]=m("span",null,"演讲者提词 (Notes)",-1))]),h[54]||(h[54]=m("span",{class:"spm-control-desc"},"正文备注块驱动 · 仅演讲者视图可见",-1))]),m("button",{class:"spm-btn-text b3-tooltips b3-tooltips__w","aria-label":"AI 自动生成本页讲稿提示块",onClick:h[23]||(h[23]=f=>u.$emit("generateNotes"))},[re(ce,{name:"sparkles"}),h[55]||(h[55]=m("span",null,"AI 讲稿",-1))])]),e.pageNotes?(ee(),te("div",Av,[h[58]||(h[58]=m("div",{class:"spm-note-status-badge"},[m("span",{class:"spm-badge-dot"}),m("span",null,"已配置正文讲稿")],-1)),m("div",{class:"spm-note-preview-text",title:e.pageNotes},we(d.value),9,Bv),m("div",Mv,[m("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"在正文编辑区定位并高亮此讲稿备注块",onClick:h[24]||(h[24]=f=>u.$emit("locateNoteBlock"))},[re(ce,{name:"search"}),h[56]||(h[56]=m("span",null,"定位讲稿块",-1))]),m("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"在本页末尾追加新的讲稿提示块",onClick:h[25]||(h[25]=f=>u.$emit("addNoteBlock"))},[re(ce,{name:"insert-below"}),h[57]||(h[57]=m("span",null,"追加讲稿块",-1))])])])):(ee(),te("div",Dv,[h[60]||(h[60]=m("div",{class:"spm-note-empty-hint"},"本页暂无讲稿备注块",-1)),m("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s",style:{width:"100%","margin-top":"6px"},"aria-label":"在当前页末尾插入默认演讲备注提示块",onClick:h[26]||(h[26]=f=>u.$emit("addNoteBlock"))},[re(ce,{name:"insert-below"}),h[59]||(h[59]=m("span",null,"添加讲稿备注块",-1))])])),m("div",Lv,[m("div",Ov,[m("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s",disabled:e.isBatchProcessing,style:An(e.isBatchProcessing?"opacity: 0.5; cursor: not-allowed;":""),"aria-label":"在所有尚未配置讲稿的页面末尾批量追加讲稿提示块",onClick:h[27]||(h[27]=f=>u.$emit("batchAppendNotes"))},[re(ce,{name:"insert-below"}),h[61]||(h[61]=m("span",null,"全部追加",-1))],12,Rv),m("button",{class:"spm-btn-action spm-btn-danger b3-tooltips b3-tooltips__s",disabled:e.isBatchProcessing,style:An(e.isBatchProcessing?"opacity: 0.5; cursor: not-allowed;":""),"aria-label":"批量物理删除正文中的全部讲稿备注块（涉及全部页）",onClick:h[28]||(h[28]=f=>u.$emit("batchDeleteNotes"))},[re(ce,{name:"trash"}),h[62]||(h[62]=m("span",null,"全部删除",-1))],12,Pv)])])]),m("div",Nv,[h[65]||(h[65]=m("div",{class:"spm-control-header"},[m("div",{class:"spm-control-title-group"},[m("span",{class:"spm-control-title"},"分页快捷操作")])],-1)),m("div",zv,[m("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"在此分页符之后插入新的空白分页",onClick:h[29]||(h[29]=f=>u.$emit("insertDividerAfter"))},[re(ce,{name:"insert-below"}),h[63]||(h[63]=m("span",null,"插入新页",-1))]),m("button",{class:"spm-btn-action spm-btn-danger b3-tooltips b3-tooltips__s","aria-label":"彻底删除当前分页符（合并前后页面）",onClick:h[30]||(h[30]=f=>u.$emit("deleteDivider"))},[re(ce,{name:"trash"}),h[64]||(h[64]=m("span",null,"删除此页",-1))])])])]))}}),Hv=zt(Fv,[["__scopeId","data-v-1f9d4630"]]),jv={class:"spm-section spm-section--block"},Wv={key:0,class:"spm-card-control",style:{"border-left":"3px solid var(--b3-theme-primary)"}},Uv={class:"spm-control-header"},Vv={class:"spm-control-title-group"},Kv={class:"spm-control-title"},qv={style:{background:"var(--b3-theme-surface)",border:"1px solid var(--b3-theme-surface-lighter)","border-radius":"6px",padding:"10px","margin-bottom":"8px"}},Gv={style:{display:"flex","align-items":"center","justify-content":"space-between","margin-bottom":"4px"}},Zv={style:{"font-size":"12px","font-weight":"500",display:"flex","align-items":"center",gap:"4px"}},Yv={key:0},Jv={key:1},Xv={style:{background:"rgba(var(--b3-theme-primary-rgb, 59, 130, 246), 0.16)",color:"var(--b3-theme-primary)",border:"1px solid rgba(var(--b3-theme-primary-rgb, 59, 130, 246), 0.3)",padding:"2px 6px","border-radius":"4px","font-weight":"bold","font-size":"12px"}},Qv={style:{"font-size":"11px",opacity:"0.75","line-height":"1.4"}},eb={class:"spm-action-grid"},tb={class:"spm-card-control"},ib={class:"spm-control-header"},nb={class:"spm-control-title-group"},ob={class:"spm-control-title"},sb=["aria-label"],rb=["checked"],lb={key:1,class:"spm-card-control"},ab={class:"spm-control-header"},cb={class:"spm-control-title-group"},db={class:"spm-control-title"},ub={class:"spm-quick-chips"},fb={key:2,class:"spm-card-control"},pb={class:"spm-control-header"},hb={class:"spm-control-title-group"},mb={class:"spm-control-title"},gb={class:"spm-video-settings-grid",style:{display:"grid","grid-template-columns":"1fr 1fr",gap:"8px","margin-top":"8px"}},vb={class:"spm-toggle-item",style:{display:"flex","align-items":"center","justify-content":"space-between",padding:"4px 6px",background:"rgba(125,125,125,0.06)","border-radius":"4px"}},bb={style:{"font-size":"11px",display:"inline-flex","align-items":"center",gap:"4px"}},yb=["aria-label"],kb=["checked"],wb={class:"spm-toggle-item",style:{display:"flex","align-items":"center","justify-content":"space-between",padding:"4px 6px",background:"rgba(125,125,125,0.06)","border-radius":"4px"}},xb={style:{"font-size":"11px",display:"inline-flex","align-items":"center",gap:"4px"}},Sb=["aria-label"],_b=["checked"],Cb={class:"spm-toggle-item",style:{display:"flex","align-items":"center","justify-content":"space-between",padding:"4px 6px",background:"rgba(125,125,125,0.06)","border-radius":"4px"}},$b={style:{"font-size":"11px",display:"inline-flex","align-items":"center",gap:"4px"}},Ib=["aria-label"],Eb=["checked"],Tb={class:"spm-toggle-item",style:{display:"flex","align-items":"center","justify-content":"space-between",padding:"4px 6px",background:"rgba(125,125,125,0.06)","border-radius":"4px"}},Ab={style:{"font-size":"11px",display:"inline-flex","align-items":"center",gap:"4px"}},Bb=["aria-label"],Mb=["checked"],Db={class:"spm-card-control"},Lb={class:"spm-control-header"},Ob={class:"spm-control-title-group"},Rb={class:"spm-control-title"},Pb=["aria-label"],Nb=["checked"],zb={key:0,class:"spm-quick-chips"},Fb=["onClick"],Hb={key:1,class:"spm-inherit-tip",style:{"margin-top":"6px",padding:"4px 8px",background:"rgba(var(--b3-theme-primary-rgb, 59, 130, 246), 0.08)","border-radius":"4px","font-size":"11px",opacity:"0.85",display:"flex","align-items":"center",gap:"4px"}},jb={class:"spm-card-control"},Wb={class:"spm-control-header"},Ub={class:"spm-control-title-group"},Vb={class:"spm-control-title"},Kb=["aria-label"],qb=["checked"],Gb={key:0,class:"spm-quick-chips"},Zb=["onClick"],Yb={key:1,class:"spm-motion-details",style:{display:"flex","flex-direction":"column",gap:"4px","margin-top":"4px"}},Jb={style:{display:"flex",gap:"8px","justify-content":"space-between","font-size":"11px",opacity:"0.8"}},Xb={style:{display:"flex",gap:"6px"}},Qb=["value"],e1=["value"],t1={key:3,class:"spm-card-control"},i1={class:"spm-control-header"},n1={class:"spm-control-title-group"},o1={class:"spm-control-title"},s1={class:"spm-control-desc"},r1={class:"spm-segmented-group"},l1=["onClick"],a1={key:4,class:"spm-card-control"},c1={class:"spm-control-header"},d1={class:"spm-control-title-group"},u1={class:"spm-control-title"},f1={class:"spm-quick-chips"},p1=["onClick"],h1=["value"],m1={key:5,class:"spm-card-control"},g1={class:"spm-control-header"},v1={class:"spm-control-title-group"},b1={class:"spm-control-title"},y1={class:"spm-quick-chips"},k1=["onClick"],w1=["value"],x1={class:"spm-card-control"},S1={class:"spm-action-grid"},_1=["aria-label"],C1=Ct({__name:"BlockInspectorSection",props:{elemClick:{},elemMotion:{},elemSlot:{},elemShikiLines:{},elemMaxHeight:{},isCodeBlock:{type:Boolean},isImage:{type:Boolean},isVideo:{type:Boolean},videoAutoplay:{type:Boolean},videoLoop:{type:Boolean},videoMuted:{type:Boolean},videoControls:{type:Boolean},hasBlockAttrs:{type:Boolean},isNote:{type:Boolean},imageRole:{},currentSlideLayout:{},isSuperBlock:{type:Boolean},parentElemClick:{},parentContainerSlot:{},parentContainerId:{},detectedSbInfo:{}},emits:["toggleNote","toggleElemClick","update:elemClick","update:elemMotion","update:elemSlot","update:elemShikiLines","update:elemMaxHeight","applySuperBlockLayout","applySuperBlockRatio","insertDividerBefore","insertDividerAfter","setTwoColsContrast","clearBlockAttrs","update:imageRole","toggleVideoAutoplay","toggleVideoLoop","toggleVideoMuted","toggleVideoControls"],setup(e,{emit:t}){const i=e,n=xe(()=>{const I=i.currentSlideLayout||"";return["col-1","col-2","col-3","col-4","col-5","col-6"].includes(i.elemSlot)?"cols-header":I}),o=xe(()=>{const I=n.value;return["two-cols","cols-header","two-cols-header","three-cols-header"].includes(I)}),s=xe(()=>{var w,P,R,z;if((w=i.detectedSbInfo)!=null&&w.colCount&&i.detectedSbInfo.colCount>=2)return Math.min(i.detectedSbInfo.colCount,6);const I=(P=i.elemSlot)==null?void 0:P.match(/^col-(\d+)$/);if(I){const V=parseInt(I[1],10);if(V>=2&&V<=6)return Math.max(V,3)}if(i.currentSlideLayout==="three-cols-header")return 3;if(i.currentSlideLayout==="two-cols-header"||i.currentSlideLayout==="two-cols")return 2;if((z=(R=i.detectedSbInfo)==null?void 0:R.ratio)!=null&&z.includes(":")){const V=i.detectedSbInfo.ratio.split(":").filter(Boolean);if(V.length>=2)return Math.min(V.length,6)}return 3}),l=xe(()=>{const I=n.value;return I==="cols-header"?"多栏插槽归属 (Slot)":I==="three-cols-header"?"三栏插槽归属 (Slot)":I==="two-cols-header"?"带表头双栏插槽 (Slot)":"多栏插槽归属 (Slot)"}),r=xe(()=>{const I=n.value;return I==="cols-header"?`在 cols-header 表头多栏（${s.value} 栏）中的内容块位置`:I==="three-cols-header"?"在 three-cols-header 版式中的内容块位置":I==="two-cols-header"?"在 two-cols-header 版式中的内容块位置":I==="two-cols"?"在 two-cols 双栏版式中的归属":"在当前分栏版式中的内容块位置"}),a=xe(()=>{const I=n.value;if(I==="two-cols")return[{value:"",label:"默认 (左)"},{value:"right",label:"右栏"}];if(I==="two-cols-header")return[{value:"",label:"默认"},{value:"header",label:"表头"},{value:"left",label:"左栏"},{value:"right",label:"右栏"}];if(I==="three-cols-header")return[{value:"",label:"默认"},{value:"header",label:"表头"},{value:"col-1",label:"第 1 栏"},{value:"col-2",label:"第 2 栏"},{value:"col-3",label:"第 3 栏"}];const w=s.value,P=[{value:"",label:"默认"},{value:"header",label:"表头"}];for(let R=1;R<=w;R++)P.push({value:`col-${R}`,label:`第 ${R} 栏`});return P});function c(I){const w=i.elemSlot||"";return I?w===I||I==="col-1"&&w==="left"||I==="col-2"&&w==="center"||I==="col-3"&&w==="right"&&s.value===3||I==="col-2"&&w==="right"&&s.value===2||I==="left"&&w==="col-1"||I==="right"&&(w==="col-2"||w==="col-3"):!w||w==="default"}const d=t,p=[{label:"上浮 (slide-up)",value:"slide-up"},{label:"淡入 (fade-in)",value:"fade-in"},{label:"下沉 (slide-down)",value:"slide-down"},{label:"左滑 (slide-left)",value:"slide-left"},{label:"右滑 (slide-right)",value:"slide-right"},{label:"缩放 (zoom-in)",value:"zoom-in"},{label:"弹性 (bounce)",value:"bounce"}],b=xe(()=>{if(!i.elemMotion||i.elemMotion.trim()===""||i.elemMotion.trim()==="none")return null;try{const I=JSON.parse(i.elemMotion);if(typeof I=="object"&&I!==null)return{preset:I.preset||I.type||"slide-up",duration:typeof I.duration=="number"?I.duration:0,delay:typeof I.delay=="number"?I.delay:0}}catch{}return{preset:i.elemMotion.trim(),duration:0,delay:0}}),u=xe(()=>!!b.value),h=xe(()=>{var I;return((I=b.value)==null?void 0:I.preset)||"slide-up"}),f=xe(()=>{var I;return((I=b.value)==null?void 0:I.duration)||0}),g=xe(()=>{var I;return((I=b.value)==null?void 0:I.delay)||0});function k(){u.value?d("update:elemMotion",""):d("update:elemMotion","slide-up")}function S(I){B(I,f.value,g.value)}function C(I){B(h.value,I,g.value)}function T(I){B(h.value,f.value,I)}function B(I,w,P){if(!I||I==="none"){d("update:elemMotion","");return}if(!w&&!P){d("update:elemMotion",I);return}const R={preset:I};w>0&&(R.duration=w),P>0&&(R.delay=P),d("update:elemMotion",JSON.stringify(R))}return(I,w)=>{var P,R,z,V,_,L;return ee(),te("div",jv,[w[62]||(w[62]=m("div",{class:"spm-section-header"},[m("span",null,"元素动效与排版")],-1)),e.isSuperBlock||(P=e.detectedSbInfo)!=null&&P.hasSuperBlock?(ee(),te("div",Wv,[m("div",Uv,[m("div",Vv,[m("div",Kv,[re(ce,{name:"ratio"}),w[24]||(w[24]=m("span",null,"超级块列宽与布局",-1))]),w[25]||(w[25]=m("span",{class:"spm-control-desc"},"读取思源超级块列宽并一键同步到幻灯片分栏",-1))])]),m("div",qv,[m("div",Gv,[m("div",Zv,[re(ce,{name:"ratio"}),(R=e.detectedSbInfo)!=null&&R.isCustomWidth?(ee(),te("span",Yv,"已识别自定义列宽比例")):(ee(),te("span",Jv,"识别到 "+we(((z=e.detectedSbInfo)==null?void 0:z.colCount)||2)+" 列超级块分栏",1))]),m("code",Xv,we(((V=e.detectedSbInfo)==null?void 0:V.ratio)||"1:1"),1)]),m("div",Qv,we((_=e.detectedSbInfo)!=null&&_.isCustomWidth?"检测到已调节子块宽度，可一键应用为当前页分栏比例。":"当前超级块子列为思源默认均宽，可在思源中拖动调节或直接应用。"),1)]),m("div",eb,[m("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"一键将当前页版式切换为对应双栏/三栏，并写入此列宽比例",style:{background:"rgba(var(--b3-theme-primary-rgb, 59, 130, 246), 0.16)",color:"var(--b3-theme-primary)","font-weight":"500",border:"1px solid rgba(var(--b3-theme-primary-rgb, 59, 130, 246), 0.3)"},onClick:w[0]||(w[0]=y=>I.$emit("applySuperBlockLayout",e.detectedSbInfo))},[re(ce,{name:"sparkles"}),w[26]||(w[26]=m("span",null,"应用版式与比例",-1))]),m("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"仅将提取的比值写入当前页的分栏比例属性",onClick:w[1]||(w[1]=y=>{var A;return I.$emit("applySuperBlockRatio",((A=e.detectedSbInfo)==null?void 0:A.ratio)||"1:1")})},[re(ce,{name:"check"}),m("span",null,"应用比例 ("+we(((L=e.detectedSbInfo)==null?void 0:L.ratio)||"1:1")+")",1)])])])):Oe("",!0),m("div",tb,[m("div",ib,[m("div",nb,[m("div",ob,[re(ce,{name:"presenter"}),w[27]||(w[27]=m("span",null,"设为讲稿备注",-1))]),w[28]||(w[28]=m("span",{class:"spm-control-desc"},"作为当前页演讲提词，不在幻灯片中渲染",-1))]),m("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":e.isNote?"取消讲稿备注":"设为讲稿备注"},[m("input",{type:"checkbox",checked:!!e.isNote,onChange:w[2]||(w[2]=y=>I.$emit("toggleNote"))},null,40,rb),w[29]||(w[29]=m("span",{class:"spm-switch-slider"},null,-1))],8,sb)])]),e.isImage||e.imageRole?(ee(),te("div",lb,[m("div",ab,[m("div",cb,[m("div",db,[re(ce,{name:"image"}),w[30]||(w[30]=m("span",null,"图片角色与分栏 (Image & Layout)",-1))]),w[31]||(w[31]=m("span",{class:"spm-control-desc"},"设为幻灯片背景图或图文分栏配图",-1))])]),m("div",ub,[m("button",{class:_e(["spm-chip",{active:!e.imageRole}]),onClick:w[3]||(w[3]=y=>I.$emit("update:imageRole",""))}," 普通内容 ",2),m("button",{class:_e(["spm-chip",{active:e.imageRole==="background"}]),onClick:w[4]||(w[4]=y=>I.$emit("update:imageRole","background"))},[re(ce,{name:"image"}),w[32]||(w[32]=m("span",null,"背景图",-1))],2),m("button",{class:_e(["spm-chip",{active:e.imageRole==="image-left"}]),onClick:w[5]||(w[5]=y=>I.$emit("update:imageRole","image-left"))},[re(ce,{name:"image-left"}),w[33]||(w[33]=m("span",null,"图左",-1))],2),m("button",{class:_e(["spm-chip",{active:e.imageRole==="image-right"}]),onClick:w[6]||(w[6]=y=>I.$emit("update:imageRole","image-right"))},[re(ce,{name:"image-right"}),w[34]||(w[34]=m("span",null,"图右",-1))],2)])])):Oe("",!0),e.isVideo?(ee(),te("div",fb,[m("div",pb,[m("div",hb,[m("div",mb,[re(ce,{name:"video"}),w[35]||(w[35]=m("span",null,"视频播放设置 (Video Playback)",-1))]),w[36]||(w[36]=m("span",{class:"spm-control-desc"},"配置播放器控制条、自动播放与循环",-1))])]),m("div",gb,[m("div",vb,[m("span",bb,[re(ce,{name:"sliders"}),w[37]||(w[37]=$t(" 控制条",-1))]),m("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":e.videoControls?"关闭控制条":"开启控制条"},[m("input",{type:"checkbox",checked:!!e.videoControls,onChange:w[7]||(w[7]=y=>I.$emit("toggleVideoControls"))},null,40,kb),w[38]||(w[38]=m("span",{class:"spm-switch-slider"},null,-1))],8,yb)]),m("div",wb,[m("span",xb,[re(ce,{name:"video"}),w[39]||(w[39]=$t(" 自动播放",-1))]),m("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":e.videoAutoplay?"关闭自动播放":"开启自动播放"},[m("input",{type:"checkbox",checked:!!e.videoAutoplay,onChange:w[8]||(w[8]=y=>I.$emit("toggleVideoAutoplay"))},null,40,_b),w[40]||(w[40]=m("span",{class:"spm-switch-slider"},null,-1))],8,Sb)]),m("div",Cb,[m("span",$b,[re(ce,{name:"repeat"}),w[41]||(w[41]=$t(" 循环播放",-1))]),m("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":e.videoLoop?"关闭循环播放":"开启循环播放"},[m("input",{type:"checkbox",checked:!!e.videoLoop,onChange:w[9]||(w[9]=y=>I.$emit("toggleVideoLoop"))},null,40,Eb),w[42]||(w[42]=m("span",{class:"spm-switch-slider"},null,-1))],8,Ib)]),m("div",Tb,[m("span",Ab,[re(ce,{name:"volume-x"}),w[43]||(w[43]=$t(" 静音播放",-1))]),m("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":e.videoMuted?"关闭静音":"开启静音"},[m("input",{type:"checkbox",checked:!!e.videoMuted,onChange:w[10]||(w[10]=y=>I.$emit("toggleVideoMuted"))},null,40,Mb),w[44]||(w[44]=m("span",{class:"spm-switch-slider"},null,-1))],8,Bb)])])])):Oe("",!0),m("div",Db,[m("div",Lb,[m("div",Ob,[m("div",Rb,[re(ce,{name:"step"}),w[45]||(w[45]=m("span",null,"逐步呈现 (v-click)",-1))]),w[46]||(w[46]=m("span",{class:"spm-control-desc"},"放映时按步长逐个呈现",-1))]),m("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":e.elemClick?"关闭逐步呈现":"开启逐步呈现 (+1)"},[m("input",{type:"checkbox",checked:!!e.elemClick,onChange:w[11]||(w[11]=y=>I.$emit("toggleElemClick"))},null,40,Nb),w[47]||(w[47]=m("span",{class:"spm-switch-slider"},null,-1))],8,Pb)]),e.elemClick?(ee(),te("div",zb,[(ee(),te(Ue,null,kt(["+1","1","2","hide"],y=>m("button",{key:y,class:_e(["spm-chip",{active:e.elemClick===y}]),onClick:A=>I.$emit("update:elemClick",y)},we(y==="+1"?"顺延 (+1)":y==="hide"?"隐藏 (hide)":"第 "+y+" 步"),11,Fb)),64))])):e.parentElemClick?(ee(),te("div",Hb,[re(ce,{name:"check"}),w[48]||(w[48]=m("span",null,"未单独开启逐步呈现：当前跟随整栏同时出现",-1))])):Oe("",!0)]),m("div",jb,[m("div",Wb,[m("div",Ub,[m("div",Vb,[re(ce,{name:"motion"}),w[49]||(w[49]=m("span",null,"入场微动效 (v-motion)",-1))]),w[50]||(w[50]=m("span",{class:"spm-control-desc"},"为当前块添加平滑位移与渐入动画",-1))]),m("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":u.value?"关闭微动效":"开启微动效 (slide-up)"},[m("input",{type:"checkbox",checked:u.value,onChange:k},null,40,qb),w[51]||(w[51]=m("span",{class:"spm-switch-slider"},null,-1))],8,Kb)]),u.value?(ee(),te("div",Gb,[(ee(),te(Ue,null,kt(p,y=>m("button",{key:y.value,class:_e(["spm-chip",{active:h.value===y.value}]),onClick:A=>S(y.value)},we(y.label),11,Zb)),64))])):Oe("",!0),u.value?(ee(),te("div",Yb,[m("div",Jb,[m("span",null,"时长: "+we(f.value?f.value+"ms":"默认 (450ms)"),1),m("span",null,"延迟: "+we(g.value?g.value+"ms":"0ms"),1)]),m("div",Xb,[m("select",{class:"spm-select",style:{flex:"1"},value:f.value,onChange:w[12]||(w[12]=y=>C(Number(y.target.value)))},[...w[52]||(w[52]=[m("option",{value:0},"默认耗时",-1),m("option",{value:200},"极速 (200ms)",-1),m("option",{value:350},"较快 (350ms)",-1),m("option",{value:500},"平滑 (500ms)",-1),m("option",{value:800},"缓慢 (800ms)",-1)])],40,Qb),m("select",{class:"spm-select",style:{flex:"1"},value:g.value,onChange:w[13]||(w[13]=y=>T(Number(y.target.value)))},[...w[53]||(w[53]=[m("option",{value:0},"无延迟",-1),m("option",{value:150},"延迟 150ms",-1),m("option",{value:300},"延迟 300ms",-1),m("option",{value:500},"延迟 500ms",-1)])],40,e1)])])):Oe("",!0)]),o.value||e.elemSlot?(ee(),te("div",t1,[m("div",i1,[m("div",n1,[m("div",o1,[re(ce,{name:"columns"}),m("span",null,we(l.value),1)]),m("span",s1,we(r.value),1)])]),m("div",r1,[(ee(!0),te(Ue,null,kt(a.value,y=>(ee(),te("button",{key:y.value,class:_e(["spm-segmented-item",{active:c(y.value)}]),onClick:A=>I.$emit("update:elemSlot",y.value)},we(y.label),11,l1))),128))])])):Oe("",!0),e.isCodeBlock?(ee(),te("div",a1,[m("div",c1,[m("div",d1,[m("div",u1,[re(ce,{name:"code"}),w[54]||(w[54]=m("span",null,"代码逐行聚光 (Shiki)",-1))]),w[55]||(w[55]=m("span",{class:"spm-control-desc"},"翻页时动态聚光高亮特定行",-1))])]),m("div",f1,[(ee(),te(Ue,null,kt(["1-3","all","1|2|3","2-5"],y=>m("button",{key:y,class:_e(["spm-chip",{active:e.elemShikiLines===y}]),onClick:A=>I.$emit("update:elemShikiLines",y)},we(y),11,p1)),64)),e.elemShikiLines?(ee(),te("button",{key:0,class:"spm-chip spm-chip-clear",onClick:w[14]||(w[14]=y=>I.$emit("update:elemShikiLines",""))}," 清空 ")):Oe("",!0)]),m("input",{value:e.elemShikiLines,class:"spm-input",placeholder:"自定义高亮区间，如 1-3|5|all",onInput:w[15]||(w[15]=y=>I.$emit("update:elemShikiLines",y.target.value)),onChange:w[16]||(w[16]=y=>I.$emit("update:elemShikiLines",y.target.value))},null,40,h1)])):Oe("",!0),e.isCodeBlock?(ee(),te("div",m1,[m("div",g1,[m("div",v1,[m("div",b1,[re(ce,{name:"code"}),w[56]||(w[56]=m("span",null,"代码块限高 (Max Height)",-1))]),w[57]||(w[57]=m("span",{class:"spm-control-desc"},"超出限高自动竖向滚动，弱提示滚动条",-1))])]),m("div",y1,[(ee(),te(Ue,null,kt(["240px","320px","400px","50vh"],y=>m("button",{key:y,class:_e(["spm-chip",{active:e.elemMaxHeight===y}]),onClick:A=>I.$emit("update:elemMaxHeight",y)},we(y),11,k1)),64)),e.elemMaxHeight?(ee(),te("button",{key:0,class:"spm-chip spm-chip-clear",onClick:w[17]||(w[17]=y=>I.$emit("update:elemMaxHeight",""))}," 自适应 ")):Oe("",!0)]),m("input",{value:e.elemMaxHeight,class:"spm-input",placeholder:"自适应高度，或输入 350px、50vh",onInput:w[18]||(w[18]=y=>I.$emit("update:elemMaxHeight",y.target.value)),onChange:w[19]||(w[19]=y=>I.$emit("update:elemMaxHeight",y.target.value))},null,40,w1)])):Oe("",!0),m("div",x1,[w[61]||(w[61]=m("div",{class:"spm-control-header"},[m("div",{class:"spm-control-title-group"},[m("span",{class:"spm-control-title"},"快捷操作")])],-1)),m("div",S1,[m("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"在当前块上方插入幻灯片分页线 (---)",onClick:w[20]||(w[20]=y=>I.$emit("insertDividerBefore"))},[re(ce,{name:"insert-above"}),w[58]||(w[58]=m("span",null,"上方分页",-1))]),m("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"在当前块下方插入幻灯片分页线 (---)",onClick:w[21]||(w[21]=y=>I.$emit("insertDividerAfter"))},[re(ce,{name:"insert-below"}),w[59]||(w[59]=m("span",null,"下方分页",-1))]),m("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":n.value==="three-cols-header"?"将当前块属性设为三栏第1栏归属 (slot: col-1)":"将当前块属性设为双栏左侧归属 (slot: left)",onClick:w[22]||(w[22]=y=>I.$emit("setTwoColsContrast"))},[re(ce,{name:"columns"}),m("span",null,we(n.value==="three-cols-header"?"设为第1栏":"设为双栏"),1)],8,_1),e.hasBlockAttrs?(ee(),te("button",{key:0,class:"spm-btn-action spm-btn-danger b3-tooltips b3-tooltips__s","aria-label":"一键移除本块所有 custom-slidev 属性",onClick:w[23]||(w[23]=y=>I.$emit("clearBlockAttrs"))},[re(ce,{name:"broom"}),w[60]||(w[60]=m("span",null,"清除属性",-1))])):Oe("",!0)])])])}}}),$1={class:"spm-section spm-section--doc"},I1={class:"spm-card-control"},E1={class:"spm-control-header"},T1={class:"spm-control-title-group"},A1={class:"spm-control-title"},B1={class:"spm-segmented-group"},M1=["aria-label","onClick"],D1={class:"spm-card-control"},L1={class:"spm-control-header"},O1={class:"spm-control-title-group"},R1={class:"spm-control-title"},P1={class:"spm-segmented-group"},N1={class:"spm-card-control"},z1={class:"spm-control-header"},F1={class:"spm-control-title-group"},H1={class:"spm-control-title"},j1={class:"spm-segmented-group"},W1={class:"spm-card-control"},U1={class:"spm-control-header"},V1={class:"spm-control-title-group"},K1={class:"spm-control-title"},q1={class:"spm-card-control"},G1={class:"spm-control-header"},Z1={class:"spm-control-title-group"},Y1={class:"spm-control-title"},J1=["aria-label"],X1=["checked"],Q1={key:0,class:"spm-control-body",style:{"margin-top":"8px"}},ey=["value"],ty={class:"spm-card-control"},iy={class:"spm-control-header"},ny={class:"spm-control-title-group"},oy={class:"spm-control-title"},sy=["aria-label"],ry=["checked"],ly={class:"spm-card-control"},ay={class:"spm-action-grid"},cy=Ct({__name:"DocInspectorSection",props:{docTheme:{},docAspectRatio:{},docDefaultTransition:{},docSpacing:{}},emits:["update:docTheme","update:docAspectRatio","update:docDefaultTransition","update:docSpacing","openBottomPreview","openPresenter","aiAutoSplit","exportHtml","exportPdf"],setup(e){const t=ti("plugin"),i=mi,n=[{value:"default",label:"默认 default",desc:"官方默认科技风：现代无衬线排版与清新代码语法高亮，通用汇报与技术分享首选"},{value:"seriph",label:"优雅 seriph",desc:"典雅学术衬线风：书卷学术质感、衬线字体典雅庄重，适合学术论文、人文讲座与深度阅读"},{value:"apple-basic",label:"极简 apple",desc:"苹果发布会极简风：大字号、高对比度与极致留白，适合产品发布、方案演讲与纯粹视觉呈现"}];function o(a){Ai({enableWebServeJump:a}),t&&typeof t.saveGlobalSettings=="function"&&t.saveGlobalSettings({enableWebServeJump:a})}async function s(a){var c;Ai({normalizeHeadingSizes:a}),t&&typeof t.saveGlobalSettings=="function"&&await t.saveGlobalSettings({normalizeHeadingSizes:a}),t&&typeof t.compileCurrentDocument=="function"&&t.compileCurrentDocument(t.currentDocId||((c=t.getActiveDocumentId)==null?void 0:c.call(t)))}function l(a){Ai({webServeUrl:a})}function r(a){Ai({webServeUrl:a}),t&&typeof t.saveGlobalSettings=="function"&&t.saveGlobalSettings({webServeUrl:a})}return(a,c)=>(ee(),te("div",$1,[c[39]||(c[39]=m("div",{class:"spm-section-header"},[m("span",null,"全局演示配置")],-1)),m("div",I1,[m("div",E1,[m("div",T1,[m("div",A1,[re(ce,{name:"palette"}),c[18]||(c[18]=m("span",null,"幻灯片主题 (Theme)",-1))]),c[19]||(c[19]=m("span",{class:"spm-control-desc"},"全局 Slidev 视觉设计范式",-1))])]),m("div",B1,[(ee(),te(Ue,null,kt(n,d=>m("button",{key:d.value,class:_e(["spm-segmented-item b3-tooltips b3-tooltips__s",{active:e.docTheme===d.value}]),"aria-label":d.desc,onClick:p=>a.$emit("update:docTheme",d.value)},we(d.label),11,M1)),64))])]),m("div",D1,[m("div",L1,[m("div",O1,[m("div",R1,[re(ce,{name:"ratio"}),c[20]||(c[20]=m("span",null,"画幅比例 (Aspect Ratio)",-1))]),c[21]||(c[21]=m("span",{class:"spm-control-desc"},"演讲屏幕投影宽高比",-1))])]),m("div",P1,[m("button",{class:_e(["spm-segmented-item",{active:e.docAspectRatio==="16/9"}]),onClick:c[0]||(c[0]=d=>a.$emit("update:docAspectRatio","16/9"))}," 16 : 9 (宽屏) ",2),m("button",{class:_e(["spm-segmented-item",{active:e.docAspectRatio==="4/3"}]),onClick:c[1]||(c[1]=d=>a.$emit("update:docAspectRatio","4/3"))}," 4 : 3 (标屏) ",2),m("button",{class:_e(["spm-segmented-item",{active:e.docAspectRatio==="16/10"}]),onClick:c[2]||(c[2]=d=>a.$emit("update:docAspectRatio","16/10"))}," 16 : 10 ",2)])]),m("div",N1,[m("div",z1,[m("div",F1,[m("div",H1,[re(ce,{name:"ratio"}),c[22]||(c[22]=m("span",null,"间距风格 (Spacing)",-1))]),c[23]||(c[23]=m("span",{class:"spm-control-desc"},"内边距与顶部标题下边距预设",-1))])]),m("div",j1,[m("button",{class:_e(["spm-segmented-item b3-tooltips b3-tooltips__s",{active:(e.docSpacing||"normal")==="compact"}]),"aria-label":"紧凑排版：上下 20px / 左右 36px，释放垂直空间，适配图文分栏",onClick:c[3]||(c[3]=d=>a.$emit("update:docSpacing","compact"))}," 紧凑 (Compact) ",2),m("button",{class:_e(["spm-segmented-item b3-tooltips b3-tooltips__s",{active:(e.docSpacing||"normal")==="normal"}]),"aria-label":"标准排版：上下 32px / 左右 48px，协调美观（推荐默认）",onClick:c[4]||(c[4]=d=>a.$emit("update:docSpacing","normal"))}," 标准 (Normal) ",2),m("button",{class:_e(["spm-segmented-item b3-tooltips b3-tooltips__s",{active:(e.docSpacing||"normal")==="loose"}]),"aria-label":"宽松排版：上下 48px / 左右 56px，大留白适合极简大字",onClick:c[5]||(c[5]=d=>a.$emit("update:docSpacing","loose"))}," 宽松 (Loose) ",2)])]),m("div",W1,[m("div",U1,[m("div",V1,[m("div",K1,[re(ce,{name:"transition"}),c[24]||(c[24]=m("span",null,"全局默认转场",-1))]),c[25]||(c[25]=m("span",{class:"spm-control-desc"},"页面切换过渡动效（未单设转场的页面将继承此动效）",-1))])]),re(Js,{"model-value":e.docDefaultTransition,"hide-header":!0,onChange:c[6]||(c[6]=d=>a.$emit("update:docDefaultTransition",d))},null,8,["model-value"])]),m("div",q1,[m("div",G1,[m("div",Z1,[m("div",Y1,[re(ce,{name:"external-link"}),c[26]||(c[26]=m("span",null,"本地网络伺服预览 (Web Serve)",-1))]),c[27]||(c[27]=m("span",{class:"spm-control-desc"},"点击文档/块链接以 Webview 抽屉呈现，支持外跳",-1))]),m("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":ge(i).enableWebServeJump?"关闭本地网络伺服预览":"开启本地网络伺服预览"},[m("input",{type:"checkbox",checked:ge(i).enableWebServeJump,onChange:c[7]||(c[7]=d=>o(d.target.checked))},null,40,X1),c[28]||(c[28]=m("span",{class:"spm-switch-slider"},null,-1))],8,J1)]),ge(i).enableWebServeJump?(ee(),te("div",Q1,[m("input",{value:ge(i).webServeUrl,class:"spm-input",placeholder:"http://127.0.0.1:6806",spellcheck:"false",onKeydown:c[8]||(c[8]=Mt(()=>{},["stop"])),onKeyup:c[9]||(c[9]=Mt(()=>{},["stop"])),onInput:c[10]||(c[10]=d=>l(d.target.value)),onChange:c[11]||(c[11]=d=>r(d.target.value))},null,40,ey),c[29]||(c[29]=m("span",{class:"spm-control-desc",style:{display:"block","margin-top":"4px","font-size":"11px",opacity:"0.8"}}," 默认伺服地址为 http://127.0.0.1:6806。开启后点击块链接将在 Webview 抽屉中打开，点击抽屉顶部『外跳』可在外部浏览器打开 ",-1))])):Oe("",!0)]),m("div",ty,[m("div",iy,[m("div",ny,[m("div",oy,[re(ce,{name:"type"}),c[30]||(c[30]=m("span",null,"固定特定标题大小",-1))]),c[31]||(c[31]=m("span",{class:"spm-control-desc"},"除封面外页首标题按 H2、多栏内首标题按 H3 大小展示",-1))]),m("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":ge(i).normalizeHeadingSizes?"关闭固定特定标题大小":"开启固定特定标题大小"},[m("input",{type:"checkbox",checked:ge(i).normalizeHeadingSizes,onChange:c[12]||(c[12]=d=>s(d.target.checked))},null,40,ry),c[32]||(c[32]=m("span",{class:"spm-switch-slider"},null,-1))],8,sy)])]),m("div",ly,[c[38]||(c[38]=m("div",{class:"spm-control-header"},[m("div",{class:"spm-control-title-group"},[m("span",{class:"spm-control-title"},"演示全局操作")])],-1)),m("div",ay,[m("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"在当前文档下方开启分屏同步预览 (Alt+P)",onClick:c[13]||(c[13]=d=>a.$emit("openBottomPreview"))},[re(ce,{name:"split-preview"}),c[33]||(c[33]=m("span",null,"分屏预览",-1))]),m("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"打开双屏演讲者控制台视窗 (Alt+M)",onClick:c[14]||(c[14]=d=>a.$emit("openPresenter"))},[re(ce,{name:"presenter"}),c[34]||(c[34]=m("span",null,"演讲者视图",-1))]),m("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"智能分析长文本结构并给出大纲分页插入建议",onClick:c[15]||(c[15]=d=>a.$emit("aiAutoSplit"))},[re(ce,{name:"sparkles"}),c[35]||(c[35]=m("span",null,"AI 智能分页",-1))]),m("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"打包导出离线单文件 HTML 幻灯片",onClick:c[16]||(c[16]=d=>a.$emit("exportHtml"))},[re(ce,{name:"export-html"}),c[36]||(c[36]=m("span",null,"导出 HTML",-1))]),m("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"打印生成 16:9 高清演示 PDF 讲义",onClick:c[17]||(c[17]=d=>a.$emit("exportPdf"))},[re(ce,{name:"export-pdf"}),c[37]||(c[37]=m("span",null,"导出 PDF",-1))])])])]))}});var Xn=typeof globalThis<"u"?globalThis:typeof window<"u"?window:typeof global<"u"?global:typeof self<"u"?self:{};function dy(e){return e&&e.__esModule&&Object.prototype.hasOwnProperty.call(e,"default")?e.default:e}function Qn(e){throw new Error('Could not dynamically require "'+e+'". Please configure the dynamicRequireTargets or/and ignoreDynamicRequires option of @rollup/plugin-commonjs appropriately for this require call to work.')}var is={exports:{}};/*!

JSZip v3.10.1 - A JavaScript class for generating and reading zip files
<http://stuartk.com/jszip>

(c) 2009-2016 Stuart Knightley <stuart [at] stuartk.com>
Dual licenced under the MIT license or GPLv3. See https://raw.github.com/Stuk/jszip/main/LICENSE.markdown.

JSZip uses the library pako released under the MIT license :
https://github.com/nodeca/pako/blob/main/LICENSE
*/var Wr;function uy(){return Wr||(Wr=1,(function(e,t){(function(i){e.exports=i()})(function(){return(function i(n,o,s){function l(c,d){if(!o[c]){if(!n[c]){var p=typeof Qn=="function"&&Qn;if(!d&&p)return p(c,!0);if(r)return r(c,!0);var b=new Error("Cannot find module '"+c+"'");throw b.code="MODULE_NOT_FOUND",b}var u=o[c]={exports:{}};n[c][0].call(u.exports,function(h){var f=n[c][1][h];return l(f||h)},u,u.exports,i,n,o,s)}return o[c].exports}for(var r=typeof Qn=="function"&&Qn,a=0;a<s.length;a++)l(s[a]);return l})({1:[function(i,n,o){var s=i("./utils"),l=i("./support"),r="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";o.encode=function(a){for(var c,d,p,b,u,h,f,g=[],k=0,S=a.length,C=S,T=s.getTypeOf(a)!=="string";k<a.length;)C=S-k,p=T?(c=a[k++],d=k<S?a[k++]:0,k<S?a[k++]:0):(c=a.charCodeAt(k++),d=k<S?a.charCodeAt(k++):0,k<S?a.charCodeAt(k++):0),b=c>>2,u=(3&c)<<4|d>>4,h=1<C?(15&d)<<2|p>>6:64,f=2<C?63&p:64,g.push(r.charAt(b)+r.charAt(u)+r.charAt(h)+r.charAt(f));return g.join("")},o.decode=function(a){var c,d,p,b,u,h,f=0,g=0,k="data:";if(a.substr(0,k.length)===k)throw new Error("Invalid base64 input, it looks like a data url.");var S,C=3*(a=a.replace(/[^A-Za-z0-9+/=]/g,"")).length/4;if(a.charAt(a.length-1)===r.charAt(64)&&C--,a.charAt(a.length-2)===r.charAt(64)&&C--,C%1!=0)throw new Error("Invalid base64 input, bad content length.");for(S=l.uint8array?new Uint8Array(0|C):new Array(0|C);f<a.length;)c=r.indexOf(a.charAt(f++))<<2|(b=r.indexOf(a.charAt(f++)))>>4,d=(15&b)<<4|(u=r.indexOf(a.charAt(f++)))>>2,p=(3&u)<<6|(h=r.indexOf(a.charAt(f++))),S[g++]=c,u!==64&&(S[g++]=d),h!==64&&(S[g++]=p);return S}},{"./support":30,"./utils":32}],2:[function(i,n,o){var s=i("./external"),l=i("./stream/DataWorker"),r=i("./stream/Crc32Probe"),a=i("./stream/DataLengthProbe");function c(d,p,b,u,h){this.compressedSize=d,this.uncompressedSize=p,this.crc32=b,this.compression=u,this.compressedContent=h}c.prototype={getContentWorker:function(){var d=new l(s.Promise.resolve(this.compressedContent)).pipe(this.compression.uncompressWorker()).pipe(new a("data_length")),p=this;return d.on("end",function(){if(this.streamInfo.data_length!==p.uncompressedSize)throw new Error("Bug : uncompressed data size mismatch")}),d},getCompressedWorker:function(){return new l(s.Promise.resolve(this.compressedContent)).withStreamInfo("compressedSize",this.compressedSize).withStreamInfo("uncompressedSize",this.uncompressedSize).withStreamInfo("crc32",this.crc32).withStreamInfo("compression",this.compression)}},c.createWorkerFrom=function(d,p,b){return d.pipe(new r).pipe(new a("uncompressedSize")).pipe(p.compressWorker(b)).pipe(new a("compressedSize")).withStreamInfo("compression",p)},n.exports=c},{"./external":6,"./stream/Crc32Probe":25,"./stream/DataLengthProbe":26,"./stream/DataWorker":27}],3:[function(i,n,o){var s=i("./stream/GenericWorker");o.STORE={magic:"\0\0",compressWorker:function(){return new s("STORE compression")},uncompressWorker:function(){return new s("STORE decompression")}},o.DEFLATE=i("./flate")},{"./flate":7,"./stream/GenericWorker":28}],4:[function(i,n,o){var s=i("./utils"),l=(function(){for(var r,a=[],c=0;c<256;c++){r=c;for(var d=0;d<8;d++)r=1&r?3988292384^r>>>1:r>>>1;a[c]=r}return a})();n.exports=function(r,a){return r!==void 0&&r.length?s.getTypeOf(r)!=="string"?(function(c,d,p,b){var u=l,h=b+p;c^=-1;for(var f=b;f<h;f++)c=c>>>8^u[255&(c^d[f])];return-1^c})(0|a,r,r.length,0):(function(c,d,p,b){var u=l,h=b+p;c^=-1;for(var f=b;f<h;f++)c=c>>>8^u[255&(c^d.charCodeAt(f))];return-1^c})(0|a,r,r.length,0):0}},{"./utils":32}],5:[function(i,n,o){o.base64=!1,o.binary=!1,o.dir=!1,o.createFolders=!0,o.date=null,o.compression=null,o.compressionOptions=null,o.comment=null,o.unixPermissions=null,o.dosPermissions=null},{}],6:[function(i,n,o){var s=null;s=typeof Promise<"u"?Promise:i("lie"),n.exports={Promise:s}},{lie:37}],7:[function(i,n,o){var s=typeof Uint8Array<"u"&&typeof Uint16Array<"u"&&typeof Uint32Array<"u",l=i("pako"),r=i("./utils"),a=i("./stream/GenericWorker"),c=s?"uint8array":"array";function d(p,b){a.call(this,"FlateWorker/"+p),this._pako=null,this._pakoAction=p,this._pakoOptions=b,this.meta={}}o.magic="\b\0",r.inherits(d,a),d.prototype.processChunk=function(p){this.meta=p.meta,this._pako===null&&this._createPako(),this._pako.push(r.transformTo(c,p.data),!1)},d.prototype.flush=function(){a.prototype.flush.call(this),this._pako===null&&this._createPako(),this._pako.push([],!0)},d.prototype.cleanUp=function(){a.prototype.cleanUp.call(this),this._pako=null},d.prototype._createPako=function(){this._pako=new l[this._pakoAction]({raw:!0,level:this._pakoOptions.level||-1});var p=this;this._pako.onData=function(b){p.push({data:b,meta:p.meta})}},o.compressWorker=function(p){return new d("Deflate",p)},o.uncompressWorker=function(){return new d("Inflate",{})}},{"./stream/GenericWorker":28,"./utils":32,pako:38}],8:[function(i,n,o){function s(u,h){var f,g="";for(f=0;f<h;f++)g+=String.fromCharCode(255&u),u>>>=8;return g}function l(u,h,f,g,k,S){var C,T,B=u.file,I=u.compression,w=S!==c.utf8encode,P=r.transformTo("string",S(B.name)),R=r.transformTo("string",c.utf8encode(B.name)),z=B.comment,V=r.transformTo("string",S(z)),_=r.transformTo("string",c.utf8encode(z)),L=R.length!==B.name.length,y=_.length!==z.length,A="",F="",E="",D=B.dir,N=B.date,X={crc32:0,compressedSize:0,uncompressedSize:0};h&&!f||(X.crc32=u.crc32,X.compressedSize=u.compressedSize,X.uncompressedSize=u.uncompressedSize);var j=0;h&&(j|=8),w||!L&&!y||(j|=2048);var G=0,ne=0;D&&(G|=16),k==="UNIX"?(ne=798,G|=(function(le,pe){var Te=le;return le||(Te=pe?16893:33204),(65535&Te)<<16})(B.unixPermissions,D)):(ne=20,G|=(function(le){return 63&(le||0)})(B.dosPermissions)),C=N.getUTCHours(),C<<=6,C|=N.getUTCMinutes(),C<<=5,C|=N.getUTCSeconds()/2,T=N.getUTCFullYear()-1980,T<<=4,T|=N.getUTCMonth()+1,T<<=5,T|=N.getUTCDate(),L&&(F=s(1,1)+s(d(P),4)+R,A+="up"+s(F.length,2)+F),y&&(E=s(1,1)+s(d(V),4)+_,A+="uc"+s(E.length,2)+E);var se="";return se+=`
\0`,se+=s(j,2),se+=I.magic,se+=s(C,2),se+=s(T,2),se+=s(X.crc32,4),se+=s(X.compressedSize,4),se+=s(X.uncompressedSize,4),se+=s(P.length,2),se+=s(A.length,2),{fileRecord:p.LOCAL_FILE_HEADER+se+P+A,dirRecord:p.CENTRAL_FILE_HEADER+s(ne,2)+se+s(V.length,2)+"\0\0\0\0"+s(G,4)+s(g,4)+P+A+V}}var r=i("../utils"),a=i("../stream/GenericWorker"),c=i("../utf8"),d=i("../crc32"),p=i("../signature");function b(u,h,f,g){a.call(this,"ZipFileWorker"),this.bytesWritten=0,this.zipComment=h,this.zipPlatform=f,this.encodeFileName=g,this.streamFiles=u,this.accumulate=!1,this.contentBuffer=[],this.dirRecords=[],this.currentSourceOffset=0,this.entriesCount=0,this.currentFile=null,this._sources=[]}r.inherits(b,a),b.prototype.push=function(u){var h=u.meta.percent||0,f=this.entriesCount,g=this._sources.length;this.accumulate?this.contentBuffer.push(u):(this.bytesWritten+=u.data.length,a.prototype.push.call(this,{data:u.data,meta:{currentFile:this.currentFile,percent:f?(h+100*(f-g-1))/f:100}}))},b.prototype.openedSource=function(u){this.currentSourceOffset=this.bytesWritten,this.currentFile=u.file.name;var h=this.streamFiles&&!u.file.dir;if(h){var f=l(u,h,!1,this.currentSourceOffset,this.zipPlatform,this.encodeFileName);this.push({data:f.fileRecord,meta:{percent:0}})}else this.accumulate=!0},b.prototype.closedSource=function(u){this.accumulate=!1;var h=this.streamFiles&&!u.file.dir,f=l(u,h,!0,this.currentSourceOffset,this.zipPlatform,this.encodeFileName);if(this.dirRecords.push(f.dirRecord),h)this.push({data:(function(g){return p.DATA_DESCRIPTOR+s(g.crc32,4)+s(g.compressedSize,4)+s(g.uncompressedSize,4)})(u),meta:{percent:100}});else for(this.push({data:f.fileRecord,meta:{percent:0}});this.contentBuffer.length;)this.push(this.contentBuffer.shift());this.currentFile=null},b.prototype.flush=function(){for(var u=this.bytesWritten,h=0;h<this.dirRecords.length;h++)this.push({data:this.dirRecords[h],meta:{percent:100}});var f=this.bytesWritten-u,g=(function(k,S,C,T,B){var I=r.transformTo("string",B(T));return p.CENTRAL_DIRECTORY_END+"\0\0\0\0"+s(k,2)+s(k,2)+s(S,4)+s(C,4)+s(I.length,2)+I})(this.dirRecords.length,f,u,this.zipComment,this.encodeFileName);this.push({data:g,meta:{percent:100}})},b.prototype.prepareNextSource=function(){this.previous=this._sources.shift(),this.openedSource(this.previous.streamInfo),this.isPaused?this.previous.pause():this.previous.resume()},b.prototype.registerPrevious=function(u){this._sources.push(u);var h=this;return u.on("data",function(f){h.processChunk(f)}),u.on("end",function(){h.closedSource(h.previous.streamInfo),h._sources.length?h.prepareNextSource():h.end()}),u.on("error",function(f){h.error(f)}),this},b.prototype.resume=function(){return!!a.prototype.resume.call(this)&&(!this.previous&&this._sources.length?(this.prepareNextSource(),!0):this.previous||this._sources.length||this.generatedError?void 0:(this.end(),!0))},b.prototype.error=function(u){var h=this._sources;if(!a.prototype.error.call(this,u))return!1;for(var f=0;f<h.length;f++)try{h[f].error(u)}catch{}return!0},b.prototype.lock=function(){a.prototype.lock.call(this);for(var u=this._sources,h=0;h<u.length;h++)u[h].lock()},n.exports=b},{"../crc32":4,"../signature":23,"../stream/GenericWorker":28,"../utf8":31,"../utils":32}],9:[function(i,n,o){var s=i("../compressions"),l=i("./ZipFileWorker");o.generateWorker=function(r,a,c){var d=new l(a.streamFiles,c,a.platform,a.encodeFileName),p=0;try{r.forEach(function(b,u){p++;var h=(function(S,C){var T=S||C,B=s[T];if(!B)throw new Error(T+" is not a valid compression method !");return B})(u.options.compression,a.compression),f=u.options.compressionOptions||a.compressionOptions||{},g=u.dir,k=u.date;u._compressWorker(h,f).withStreamInfo("file",{name:b,dir:g,date:k,comment:u.comment||"",unixPermissions:u.unixPermissions,dosPermissions:u.dosPermissions}).pipe(d)}),d.entriesCount=p}catch(b){d.error(b)}return d}},{"../compressions":3,"./ZipFileWorker":8}],10:[function(i,n,o){function s(){if(!(this instanceof s))return new s;if(arguments.length)throw new Error("The constructor with parameters has been removed in JSZip 3.0, please check the upgrade guide.");this.files=Object.create(null),this.comment=null,this.root="",this.clone=function(){var l=new s;for(var r in this)typeof this[r]!="function"&&(l[r]=this[r]);return l}}(s.prototype=i("./object")).loadAsync=i("./load"),s.support=i("./support"),s.defaults=i("./defaults"),s.version="3.10.1",s.loadAsync=function(l,r){return new s().loadAsync(l,r)},s.external=i("./external"),n.exports=s},{"./defaults":5,"./external":6,"./load":11,"./object":15,"./support":30}],11:[function(i,n,o){var s=i("./utils"),l=i("./external"),r=i("./utf8"),a=i("./zipEntries"),c=i("./stream/Crc32Probe"),d=i("./nodejsUtils");function p(b){return new l.Promise(function(u,h){var f=b.decompressed.getContentWorker().pipe(new c);f.on("error",function(g){h(g)}).on("end",function(){f.streamInfo.crc32!==b.decompressed.crc32?h(new Error("Corrupted zip : CRC32 mismatch")):u()}).resume()})}n.exports=function(b,u){var h=this;return u=s.extend(u||{},{base64:!1,checkCRC32:!1,optimizedBinaryString:!1,createFolders:!1,decodeFileName:r.utf8decode}),d.isNode&&d.isStream(b)?l.Promise.reject(new Error("JSZip can't accept a stream when loading a zip file.")):s.prepareContent("the loaded zip file",b,!0,u.optimizedBinaryString,u.base64).then(function(f){var g=new a(u);return g.load(f),g}).then(function(f){var g=[l.Promise.resolve(f)],k=f.files;if(u.checkCRC32)for(var S=0;S<k.length;S++)g.push(p(k[S]));return l.Promise.all(g)}).then(function(f){for(var g=f.shift(),k=g.files,S=0;S<k.length;S++){var C=k[S],T=C.fileNameStr,B=s.resolve(C.fileNameStr);h.file(B,C.decompressed,{binary:!0,optimizedBinaryString:!0,date:C.date,dir:C.dir,comment:C.fileCommentStr.length?C.fileCommentStr:null,unixPermissions:C.unixPermissions,dosPermissions:C.dosPermissions,createFolders:u.createFolders}),C.dir||(h.file(B).unsafeOriginalName=T)}return g.zipComment.length&&(h.comment=g.zipComment),h})}},{"./external":6,"./nodejsUtils":14,"./stream/Crc32Probe":25,"./utf8":31,"./utils":32,"./zipEntries":33}],12:[function(i,n,o){var s=i("../utils"),l=i("../stream/GenericWorker");function r(a,c){l.call(this,"Nodejs stream input adapter for "+a),this._upstreamEnded=!1,this._bindStream(c)}s.inherits(r,l),r.prototype._bindStream=function(a){var c=this;(this._stream=a).pause(),a.on("data",function(d){c.push({data:d,meta:{percent:0}})}).on("error",function(d){c.isPaused?this.generatedError=d:c.error(d)}).on("end",function(){c.isPaused?c._upstreamEnded=!0:c.end()})},r.prototype.pause=function(){return!!l.prototype.pause.call(this)&&(this._stream.pause(),!0)},r.prototype.resume=function(){return!!l.prototype.resume.call(this)&&(this._upstreamEnded?this.end():this._stream.resume(),!0)},n.exports=r},{"../stream/GenericWorker":28,"../utils":32}],13:[function(i,n,o){var s=i("readable-stream").Readable;function l(r,a,c){s.call(this,a),this._helper=r;var d=this;r.on("data",function(p,b){d.push(p)||d._helper.pause(),c&&c(b)}).on("error",function(p){d.emit("error",p)}).on("end",function(){d.push(null)})}i("../utils").inherits(l,s),l.prototype._read=function(){this._helper.resume()},n.exports=l},{"../utils":32,"readable-stream":16}],14:[function(i,n,o){n.exports={isNode:typeof Buffer<"u",newBufferFrom:function(s,l){if(Buffer.from&&Buffer.from!==Uint8Array.from)return Buffer.from(s,l);if(typeof s=="number")throw new Error('The "data" argument must not be a number');return new Buffer(s,l)},allocBuffer:function(s){if(Buffer.alloc)return Buffer.alloc(s);var l=new Buffer(s);return l.fill(0),l},isBuffer:function(s){return Buffer.isBuffer(s)},isStream:function(s){return s&&typeof s.on=="function"&&typeof s.pause=="function"&&typeof s.resume=="function"}}},{}],15:[function(i,n,o){function s(B,I,w){var P,R=r.getTypeOf(I),z=r.extend(w||{},d);z.date=z.date||new Date,z.compression!==null&&(z.compression=z.compression.toUpperCase()),typeof z.unixPermissions=="string"&&(z.unixPermissions=parseInt(z.unixPermissions,8)),z.unixPermissions&&16384&z.unixPermissions&&(z.dir=!0),z.dosPermissions&&16&z.dosPermissions&&(z.dir=!0),z.dir&&(B=k(B)),z.createFolders&&(P=g(B))&&S.call(this,P,!0);var V=R==="string"&&z.binary===!1&&z.base64===!1;w&&w.binary!==void 0||(z.binary=!V),(I instanceof p&&I.uncompressedSize===0||z.dir||!I||I.length===0)&&(z.base64=!1,z.binary=!0,I="",z.compression="STORE",R="string");var _=null;_=I instanceof p||I instanceof a?I:h.isNode&&h.isStream(I)?new f(B,I):r.prepareContent(B,I,z.binary,z.optimizedBinaryString,z.base64);var L=new b(B,_,z);this.files[B]=L}var l=i("./utf8"),r=i("./utils"),a=i("./stream/GenericWorker"),c=i("./stream/StreamHelper"),d=i("./defaults"),p=i("./compressedObject"),b=i("./zipObject"),u=i("./generate"),h=i("./nodejsUtils"),f=i("./nodejs/NodejsStreamInputAdapter"),g=function(B){B.slice(-1)==="/"&&(B=B.substring(0,B.length-1));var I=B.lastIndexOf("/");return 0<I?B.substring(0,I):""},k=function(B){return B.slice(-1)!=="/"&&(B+="/"),B},S=function(B,I){return I=I!==void 0?I:d.createFolders,B=k(B),this.files[B]||s.call(this,B,null,{dir:!0,createFolders:I}),this.files[B]};function C(B){return Object.prototype.toString.call(B)==="[object RegExp]"}var T={load:function(){throw new Error("This method has been removed in JSZip 3.0, please check the upgrade guide.")},forEach:function(B){var I,w,P;for(I in this.files)P=this.files[I],(w=I.slice(this.root.length,I.length))&&I.slice(0,this.root.length)===this.root&&B(w,P)},filter:function(B){var I=[];return this.forEach(function(w,P){B(w,P)&&I.push(P)}),I},file:function(B,I,w){if(arguments.length!==1)return B=this.root+B,s.call(this,B,I,w),this;if(C(B)){var P=B;return this.filter(function(z,V){return!V.dir&&P.test(z)})}var R=this.files[this.root+B];return R&&!R.dir?R:null},folder:function(B){if(!B)return this;if(C(B))return this.filter(function(R,z){return z.dir&&B.test(R)});var I=this.root+B,w=S.call(this,I),P=this.clone();return P.root=w.name,P},remove:function(B){B=this.root+B;var I=this.files[B];if(I||(B.slice(-1)!=="/"&&(B+="/"),I=this.files[B]),I&&!I.dir)delete this.files[B];else for(var w=this.filter(function(R,z){return z.name.slice(0,B.length)===B}),P=0;P<w.length;P++)delete this.files[w[P].name];return this},generate:function(){throw new Error("This method has been removed in JSZip 3.0, please check the upgrade guide.")},generateInternalStream:function(B){var I,w={};try{if((w=r.extend(B||{},{streamFiles:!1,compression:"STORE",compressionOptions:null,type:"",platform:"DOS",comment:null,mimeType:"application/zip",encodeFileName:l.utf8encode})).type=w.type.toLowerCase(),w.compression=w.compression.toUpperCase(),w.type==="binarystring"&&(w.type="string"),!w.type)throw new Error("No output type specified.");r.checkSupport(w.type),w.platform!=="darwin"&&w.platform!=="freebsd"&&w.platform!=="linux"&&w.platform!=="sunos"||(w.platform="UNIX"),w.platform==="win32"&&(w.platform="DOS");var P=w.comment||this.comment||"";I=u.generateWorker(this,w,P)}catch(R){(I=new a("error")).error(R)}return new c(I,w.type||"string",w.mimeType)},generateAsync:function(B,I){return this.generateInternalStream(B).accumulate(I)},generateNodeStream:function(B,I){return(B=B||{}).type||(B.type="nodebuffer"),this.generateInternalStream(B).toNodejsStream(I)}};n.exports=T},{"./compressedObject":2,"./defaults":5,"./generate":9,"./nodejs/NodejsStreamInputAdapter":12,"./nodejsUtils":14,"./stream/GenericWorker":28,"./stream/StreamHelper":29,"./utf8":31,"./utils":32,"./zipObject":35}],16:[function(i,n,o){n.exports=i("stream")},{stream:void 0}],17:[function(i,n,o){var s=i("./DataReader");function l(r){s.call(this,r);for(var a=0;a<this.data.length;a++)r[a]=255&r[a]}i("../utils").inherits(l,s),l.prototype.byteAt=function(r){return this.data[this.zero+r]},l.prototype.lastIndexOfSignature=function(r){for(var a=r.charCodeAt(0),c=r.charCodeAt(1),d=r.charCodeAt(2),p=r.charCodeAt(3),b=this.length-4;0<=b;--b)if(this.data[b]===a&&this.data[b+1]===c&&this.data[b+2]===d&&this.data[b+3]===p)return b-this.zero;return-1},l.prototype.readAndCheckSignature=function(r){var a=r.charCodeAt(0),c=r.charCodeAt(1),d=r.charCodeAt(2),p=r.charCodeAt(3),b=this.readData(4);return a===b[0]&&c===b[1]&&d===b[2]&&p===b[3]},l.prototype.readData=function(r){if(this.checkOffset(r),r===0)return[];var a=this.data.slice(this.zero+this.index,this.zero+this.index+r);return this.index+=r,a},n.exports=l},{"../utils":32,"./DataReader":18}],18:[function(i,n,o){var s=i("../utils");function l(r){this.data=r,this.length=r.length,this.index=0,this.zero=0}l.prototype={checkOffset:function(r){this.checkIndex(this.index+r)},checkIndex:function(r){if(this.length<this.zero+r||r<0)throw new Error("End of data reached (data length = "+this.length+", asked index = "+r+"). Corrupted zip ?")},setIndex:function(r){this.checkIndex(r),this.index=r},skip:function(r){this.setIndex(this.index+r)},byteAt:function(){},readInt:function(r){var a,c=0;for(this.checkOffset(r),a=this.index+r-1;a>=this.index;a--)c=(c<<8)+this.byteAt(a);return this.index+=r,c},readString:function(r){return s.transformTo("string",this.readData(r))},readData:function(){},lastIndexOfSignature:function(){},readAndCheckSignature:function(){},readDate:function(){var r=this.readInt(4);return new Date(Date.UTC(1980+(r>>25&127),(r>>21&15)-1,r>>16&31,r>>11&31,r>>5&63,(31&r)<<1))}},n.exports=l},{"../utils":32}],19:[function(i,n,o){var s=i("./Uint8ArrayReader");function l(r){s.call(this,r)}i("../utils").inherits(l,s),l.prototype.readData=function(r){this.checkOffset(r);var a=this.data.slice(this.zero+this.index,this.zero+this.index+r);return this.index+=r,a},n.exports=l},{"../utils":32,"./Uint8ArrayReader":21}],20:[function(i,n,o){var s=i("./DataReader");function l(r){s.call(this,r)}i("../utils").inherits(l,s),l.prototype.byteAt=function(r){return this.data.charCodeAt(this.zero+r)},l.prototype.lastIndexOfSignature=function(r){return this.data.lastIndexOf(r)-this.zero},l.prototype.readAndCheckSignature=function(r){return r===this.readData(4)},l.prototype.readData=function(r){this.checkOffset(r);var a=this.data.slice(this.zero+this.index,this.zero+this.index+r);return this.index+=r,a},n.exports=l},{"../utils":32,"./DataReader":18}],21:[function(i,n,o){var s=i("./ArrayReader");function l(r){s.call(this,r)}i("../utils").inherits(l,s),l.prototype.readData=function(r){if(this.checkOffset(r),r===0)return new Uint8Array(0);var a=this.data.subarray(this.zero+this.index,this.zero+this.index+r);return this.index+=r,a},n.exports=l},{"../utils":32,"./ArrayReader":17}],22:[function(i,n,o){var s=i("../utils"),l=i("../support"),r=i("./ArrayReader"),a=i("./StringReader"),c=i("./NodeBufferReader"),d=i("./Uint8ArrayReader");n.exports=function(p){var b=s.getTypeOf(p);return s.checkSupport(b),b!=="string"||l.uint8array?b==="nodebuffer"?new c(p):l.uint8array?new d(s.transformTo("uint8array",p)):new r(s.transformTo("array",p)):new a(p)}},{"../support":30,"../utils":32,"./ArrayReader":17,"./NodeBufferReader":19,"./StringReader":20,"./Uint8ArrayReader":21}],23:[function(i,n,o){o.LOCAL_FILE_HEADER="PK",o.CENTRAL_FILE_HEADER="PK",o.CENTRAL_DIRECTORY_END="PK",o.ZIP64_CENTRAL_DIRECTORY_LOCATOR="PK\x07",o.ZIP64_CENTRAL_DIRECTORY_END="PK",o.DATA_DESCRIPTOR="PK\x07\b"},{}],24:[function(i,n,o){var s=i("./GenericWorker"),l=i("../utils");function r(a){s.call(this,"ConvertWorker to "+a),this.destType=a}l.inherits(r,s),r.prototype.processChunk=function(a){this.push({data:l.transformTo(this.destType,a.data),meta:a.meta})},n.exports=r},{"../utils":32,"./GenericWorker":28}],25:[function(i,n,o){var s=i("./GenericWorker"),l=i("../crc32");function r(){s.call(this,"Crc32Probe"),this.withStreamInfo("crc32",0)}i("../utils").inherits(r,s),r.prototype.processChunk=function(a){this.streamInfo.crc32=l(a.data,this.streamInfo.crc32||0),this.push(a)},n.exports=r},{"../crc32":4,"../utils":32,"./GenericWorker":28}],26:[function(i,n,o){var s=i("../utils"),l=i("./GenericWorker");function r(a){l.call(this,"DataLengthProbe for "+a),this.propName=a,this.withStreamInfo(a,0)}s.inherits(r,l),r.prototype.processChunk=function(a){if(a){var c=this.streamInfo[this.propName]||0;this.streamInfo[this.propName]=c+a.data.length}l.prototype.processChunk.call(this,a)},n.exports=r},{"../utils":32,"./GenericWorker":28}],27:[function(i,n,o){var s=i("../utils"),l=i("./GenericWorker");function r(a){l.call(this,"DataWorker");var c=this;this.dataIsReady=!1,this.index=0,this.max=0,this.data=null,this.type="",this._tickScheduled=!1,a.then(function(d){c.dataIsReady=!0,c.data=d,c.max=d&&d.length||0,c.type=s.getTypeOf(d),c.isPaused||c._tickAndRepeat()},function(d){c.error(d)})}s.inherits(r,l),r.prototype.cleanUp=function(){l.prototype.cleanUp.call(this),this.data=null},r.prototype.resume=function(){return!!l.prototype.resume.call(this)&&(!this._tickScheduled&&this.dataIsReady&&(this._tickScheduled=!0,s.delay(this._tickAndRepeat,[],this)),!0)},r.prototype._tickAndRepeat=function(){this._tickScheduled=!1,this.isPaused||this.isFinished||(this._tick(),this.isFinished||(s.delay(this._tickAndRepeat,[],this),this._tickScheduled=!0))},r.prototype._tick=function(){if(this.isPaused||this.isFinished)return!1;var a=null,c=Math.min(this.max,this.index+16384);if(this.index>=this.max)return this.end();switch(this.type){case"string":a=this.data.substring(this.index,c);break;case"uint8array":a=this.data.subarray(this.index,c);break;case"array":case"nodebuffer":a=this.data.slice(this.index,c)}return this.index=c,this.push({data:a,meta:{percent:this.max?this.index/this.max*100:0}})},n.exports=r},{"../utils":32,"./GenericWorker":28}],28:[function(i,n,o){function s(l){this.name=l||"default",this.streamInfo={},this.generatedError=null,this.extraStreamInfo={},this.isPaused=!0,this.isFinished=!1,this.isLocked=!1,this._listeners={data:[],end:[],error:[]},this.previous=null}s.prototype={push:function(l){this.emit("data",l)},end:function(){if(this.isFinished)return!1;this.flush();try{this.emit("end"),this.cleanUp(),this.isFinished=!0}catch(l){this.emit("error",l)}return!0},error:function(l){return!this.isFinished&&(this.isPaused?this.generatedError=l:(this.isFinished=!0,this.emit("error",l),this.previous&&this.previous.error(l),this.cleanUp()),!0)},on:function(l,r){return this._listeners[l].push(r),this},cleanUp:function(){this.streamInfo=this.generatedError=this.extraStreamInfo=null,this._listeners=[]},emit:function(l,r){if(this._listeners[l])for(var a=0;a<this._listeners[l].length;a++)this._listeners[l][a].call(this,r)},pipe:function(l){return l.registerPrevious(this)},registerPrevious:function(l){if(this.isLocked)throw new Error("The stream '"+this+"' has already been used.");this.streamInfo=l.streamInfo,this.mergeStreamInfo(),this.previous=l;var r=this;return l.on("data",function(a){r.processChunk(a)}),l.on("end",function(){r.end()}),l.on("error",function(a){r.error(a)}),this},pause:function(){return!this.isPaused&&!this.isFinished&&(this.isPaused=!0,this.previous&&this.previous.pause(),!0)},resume:function(){if(!this.isPaused||this.isFinished)return!1;var l=this.isPaused=!1;return this.generatedError&&(this.error(this.generatedError),l=!0),this.previous&&this.previous.resume(),!l},flush:function(){},processChunk:function(l){this.push(l)},withStreamInfo:function(l,r){return this.extraStreamInfo[l]=r,this.mergeStreamInfo(),this},mergeStreamInfo:function(){for(var l in this.extraStreamInfo)Object.prototype.hasOwnProperty.call(this.extraStreamInfo,l)&&(this.streamInfo[l]=this.extraStreamInfo[l])},lock:function(){if(this.isLocked)throw new Error("The stream '"+this+"' has already been used.");this.isLocked=!0,this.previous&&this.previous.lock()},toString:function(){var l="Worker "+this.name;return this.previous?this.previous+" -> "+l:l}},n.exports=s},{}],29:[function(i,n,o){var s=i("../utils"),l=i("./ConvertWorker"),r=i("./GenericWorker"),a=i("../base64"),c=i("../support"),d=i("../external"),p=null;if(c.nodestream)try{p=i("../nodejs/NodejsStreamOutputAdapter")}catch{}function b(h,f){return new d.Promise(function(g,k){var S=[],C=h._internalType,T=h._outputType,B=h._mimeType;h.on("data",function(I,w){S.push(I),f&&f(w)}).on("error",function(I){S=[],k(I)}).on("end",function(){try{var I=(function(w,P,R){switch(w){case"blob":return s.newBlob(s.transformTo("arraybuffer",P),R);case"base64":return a.encode(P);default:return s.transformTo(w,P)}})(T,(function(w,P){var R,z=0,V=null,_=0;for(R=0;R<P.length;R++)_+=P[R].length;switch(w){case"string":return P.join("");case"array":return Array.prototype.concat.apply([],P);case"uint8array":for(V=new Uint8Array(_),R=0;R<P.length;R++)V.set(P[R],z),z+=P[R].length;return V;case"nodebuffer":return Buffer.concat(P);default:throw new Error("concat : unsupported type '"+w+"'")}})(C,S),B);g(I)}catch(w){k(w)}S=[]}).resume()})}function u(h,f,g){var k=f;switch(f){case"blob":case"arraybuffer":k="uint8array";break;case"base64":k="string"}try{this._internalType=k,this._outputType=f,this._mimeType=g,s.checkSupport(k),this._worker=h.pipe(new l(k)),h.lock()}catch(S){this._worker=new r("error"),this._worker.error(S)}}u.prototype={accumulate:function(h){return b(this,h)},on:function(h,f){var g=this;return h==="data"?this._worker.on(h,function(k){f.call(g,k.data,k.meta)}):this._worker.on(h,function(){s.delay(f,arguments,g)}),this},resume:function(){return s.delay(this._worker.resume,[],this._worker),this},pause:function(){return this._worker.pause(),this},toNodejsStream:function(h){if(s.checkSupport("nodestream"),this._outputType!=="nodebuffer")throw new Error(this._outputType+" is not supported by this method");return new p(this,{objectMode:this._outputType!=="nodebuffer"},h)}},n.exports=u},{"../base64":1,"../external":6,"../nodejs/NodejsStreamOutputAdapter":13,"../support":30,"../utils":32,"./ConvertWorker":24,"./GenericWorker":28}],30:[function(i,n,o){if(o.base64=!0,o.array=!0,o.string=!0,o.arraybuffer=typeof ArrayBuffer<"u"&&typeof Uint8Array<"u",o.nodebuffer=typeof Buffer<"u",o.uint8array=typeof Uint8Array<"u",typeof ArrayBuffer>"u")o.blob=!1;else{var s=new ArrayBuffer(0);try{o.blob=new Blob([s],{type:"application/zip"}).size===0}catch{try{var l=new(self.BlobBuilder||self.WebKitBlobBuilder||self.MozBlobBuilder||self.MSBlobBuilder);l.append(s),o.blob=l.getBlob("application/zip").size===0}catch{o.blob=!1}}}try{o.nodestream=!!i("readable-stream").Readable}catch{o.nodestream=!1}},{"readable-stream":16}],31:[function(i,n,o){for(var s=i("./utils"),l=i("./support"),r=i("./nodejsUtils"),a=i("./stream/GenericWorker"),c=new Array(256),d=0;d<256;d++)c[d]=252<=d?6:248<=d?5:240<=d?4:224<=d?3:192<=d?2:1;c[254]=c[254]=1;function p(){a.call(this,"utf-8 decode"),this.leftOver=null}function b(){a.call(this,"utf-8 encode")}o.utf8encode=function(u){return l.nodebuffer?r.newBufferFrom(u,"utf-8"):(function(h){var f,g,k,S,C,T=h.length,B=0;for(S=0;S<T;S++)(64512&(g=h.charCodeAt(S)))==55296&&S+1<T&&(64512&(k=h.charCodeAt(S+1)))==56320&&(g=65536+(g-55296<<10)+(k-56320),S++),B+=g<128?1:g<2048?2:g<65536?3:4;for(f=l.uint8array?new Uint8Array(B):new Array(B),S=C=0;C<B;S++)(64512&(g=h.charCodeAt(S)))==55296&&S+1<T&&(64512&(k=h.charCodeAt(S+1)))==56320&&(g=65536+(g-55296<<10)+(k-56320),S++),g<128?f[C++]=g:(g<2048?f[C++]=192|g>>>6:(g<65536?f[C++]=224|g>>>12:(f[C++]=240|g>>>18,f[C++]=128|g>>>12&63),f[C++]=128|g>>>6&63),f[C++]=128|63&g);return f})(u)},o.utf8decode=function(u){return l.nodebuffer?s.transformTo("nodebuffer",u).toString("utf-8"):(function(h){var f,g,k,S,C=h.length,T=new Array(2*C);for(f=g=0;f<C;)if((k=h[f++])<128)T[g++]=k;else if(4<(S=c[k]))T[g++]=65533,f+=S-1;else{for(k&=S===2?31:S===3?15:7;1<S&&f<C;)k=k<<6|63&h[f++],S--;1<S?T[g++]=65533:k<65536?T[g++]=k:(k-=65536,T[g++]=55296|k>>10&1023,T[g++]=56320|1023&k)}return T.length!==g&&(T.subarray?T=T.subarray(0,g):T.length=g),s.applyFromCharCode(T)})(u=s.transformTo(l.uint8array?"uint8array":"array",u))},s.inherits(p,a),p.prototype.processChunk=function(u){var h=s.transformTo(l.uint8array?"uint8array":"array",u.data);if(this.leftOver&&this.leftOver.length){if(l.uint8array){var f=h;(h=new Uint8Array(f.length+this.leftOver.length)).set(this.leftOver,0),h.set(f,this.leftOver.length)}else h=this.leftOver.concat(h);this.leftOver=null}var g=(function(S,C){var T;for((C=C||S.length)>S.length&&(C=S.length),T=C-1;0<=T&&(192&S[T])==128;)T--;return T<0||T===0?C:T+c[S[T]]>C?T:C})(h),k=h;g!==h.length&&(l.uint8array?(k=h.subarray(0,g),this.leftOver=h.subarray(g,h.length)):(k=h.slice(0,g),this.leftOver=h.slice(g,h.length))),this.push({data:o.utf8decode(k),meta:u.meta})},p.prototype.flush=function(){this.leftOver&&this.leftOver.length&&(this.push({data:o.utf8decode(this.leftOver),meta:{}}),this.leftOver=null)},o.Utf8DecodeWorker=p,s.inherits(b,a),b.prototype.processChunk=function(u){this.push({data:o.utf8encode(u.data),meta:u.meta})},o.Utf8EncodeWorker=b},{"./nodejsUtils":14,"./stream/GenericWorker":28,"./support":30,"./utils":32}],32:[function(i,n,o){var s=i("./support"),l=i("./base64"),r=i("./nodejsUtils"),a=i("./external");function c(f){return f}function d(f,g){for(var k=0;k<f.length;++k)g[k]=255&f.charCodeAt(k);return g}i("setimmediate"),o.newBlob=function(f,g){o.checkSupport("blob");try{return new Blob([f],{type:g})}catch{try{var k=new(self.BlobBuilder||self.WebKitBlobBuilder||self.MozBlobBuilder||self.MSBlobBuilder);return k.append(f),k.getBlob(g)}catch{throw new Error("Bug : can't construct the Blob.")}}};var p={stringifyByChunk:function(f,g,k){var S=[],C=0,T=f.length;if(T<=k)return String.fromCharCode.apply(null,f);for(;C<T;)g==="array"||g==="nodebuffer"?S.push(String.fromCharCode.apply(null,f.slice(C,Math.min(C+k,T)))):S.push(String.fromCharCode.apply(null,f.subarray(C,Math.min(C+k,T)))),C+=k;return S.join("")},stringifyByChar:function(f){for(var g="",k=0;k<f.length;k++)g+=String.fromCharCode(f[k]);return g},applyCanBeUsed:{uint8array:(function(){try{return s.uint8array&&String.fromCharCode.apply(null,new Uint8Array(1)).length===1}catch{return!1}})(),nodebuffer:(function(){try{return s.nodebuffer&&String.fromCharCode.apply(null,r.allocBuffer(1)).length===1}catch{return!1}})()}};function b(f){var g=65536,k=o.getTypeOf(f),S=!0;if(k==="uint8array"?S=p.applyCanBeUsed.uint8array:k==="nodebuffer"&&(S=p.applyCanBeUsed.nodebuffer),S)for(;1<g;)try{return p.stringifyByChunk(f,k,g)}catch{g=Math.floor(g/2)}return p.stringifyByChar(f)}function u(f,g){for(var k=0;k<f.length;k++)g[k]=f[k];return g}o.applyFromCharCode=b;var h={};h.string={string:c,array:function(f){return d(f,new Array(f.length))},arraybuffer:function(f){return h.string.uint8array(f).buffer},uint8array:function(f){return d(f,new Uint8Array(f.length))},nodebuffer:function(f){return d(f,r.allocBuffer(f.length))}},h.array={string:b,array:c,arraybuffer:function(f){return new Uint8Array(f).buffer},uint8array:function(f){return new Uint8Array(f)},nodebuffer:function(f){return r.newBufferFrom(f)}},h.arraybuffer={string:function(f){return b(new Uint8Array(f))},array:function(f){return u(new Uint8Array(f),new Array(f.byteLength))},arraybuffer:c,uint8array:function(f){return new Uint8Array(f)},nodebuffer:function(f){return r.newBufferFrom(new Uint8Array(f))}},h.uint8array={string:b,array:function(f){return u(f,new Array(f.length))},arraybuffer:function(f){return f.buffer},uint8array:c,nodebuffer:function(f){return r.newBufferFrom(f)}},h.nodebuffer={string:b,array:function(f){return u(f,new Array(f.length))},arraybuffer:function(f){return h.nodebuffer.uint8array(f).buffer},uint8array:function(f){return u(f,new Uint8Array(f.length))},nodebuffer:c},o.transformTo=function(f,g){if(g=g||"",!f)return g;o.checkSupport(f);var k=o.getTypeOf(g);return h[k][f](g)},o.resolve=function(f){for(var g=f.split("/"),k=[],S=0;S<g.length;S++){var C=g[S];C==="."||C===""&&S!==0&&S!==g.length-1||(C===".."?k.pop():k.push(C))}return k.join("/")},o.getTypeOf=function(f){return typeof f=="string"?"string":Object.prototype.toString.call(f)==="[object Array]"?"array":s.nodebuffer&&r.isBuffer(f)?"nodebuffer":s.uint8array&&f instanceof Uint8Array?"uint8array":s.arraybuffer&&f instanceof ArrayBuffer?"arraybuffer":void 0},o.checkSupport=function(f){if(!s[f.toLowerCase()])throw new Error(f+" is not supported by this platform")},o.MAX_VALUE_16BITS=65535,o.MAX_VALUE_32BITS=-1,o.pretty=function(f){var g,k,S="";for(k=0;k<(f||"").length;k++)S+="\\x"+((g=f.charCodeAt(k))<16?"0":"")+g.toString(16).toUpperCase();return S},o.delay=function(f,g,k){setImmediate(function(){f.apply(k||null,g||[])})},o.inherits=function(f,g){function k(){}k.prototype=g.prototype,f.prototype=new k},o.extend=function(){var f,g,k={};for(f=0;f<arguments.length;f++)for(g in arguments[f])Object.prototype.hasOwnProperty.call(arguments[f],g)&&k[g]===void 0&&(k[g]=arguments[f][g]);return k},o.prepareContent=function(f,g,k,S,C){return a.Promise.resolve(g).then(function(T){return s.blob&&(T instanceof Blob||["[object File]","[object Blob]"].indexOf(Object.prototype.toString.call(T))!==-1)&&typeof FileReader<"u"?new a.Promise(function(B,I){var w=new FileReader;w.onload=function(P){B(P.target.result)},w.onerror=function(P){I(P.target.error)},w.readAsArrayBuffer(T)}):T}).then(function(T){var B=o.getTypeOf(T);return B?(B==="arraybuffer"?T=o.transformTo("uint8array",T):B==="string"&&(C?T=l.decode(T):k&&S!==!0&&(T=(function(I){return d(I,s.uint8array?new Uint8Array(I.length):new Array(I.length))})(T))),T):a.Promise.reject(new Error("Can't read the data of '"+f+"'. Is it in a supported JavaScript type (String, Blob, ArrayBuffer, etc) ?"))})}},{"./base64":1,"./external":6,"./nodejsUtils":14,"./support":30,setimmediate:54}],33:[function(i,n,o){var s=i("./reader/readerFor"),l=i("./utils"),r=i("./signature"),a=i("./zipEntry"),c=i("./support");function d(p){this.files=[],this.loadOptions=p}d.prototype={checkSignature:function(p){if(!this.reader.readAndCheckSignature(p)){this.reader.index-=4;var b=this.reader.readString(4);throw new Error("Corrupted zip or bug: unexpected signature ("+l.pretty(b)+", expected "+l.pretty(p)+")")}},isSignature:function(p,b){var u=this.reader.index;this.reader.setIndex(p);var h=this.reader.readString(4)===b;return this.reader.setIndex(u),h},readBlockEndOfCentral:function(){this.diskNumber=this.reader.readInt(2),this.diskWithCentralDirStart=this.reader.readInt(2),this.centralDirRecordsOnThisDisk=this.reader.readInt(2),this.centralDirRecords=this.reader.readInt(2),this.centralDirSize=this.reader.readInt(4),this.centralDirOffset=this.reader.readInt(4),this.zipCommentLength=this.reader.readInt(2);var p=this.reader.readData(this.zipCommentLength),b=c.uint8array?"uint8array":"array",u=l.transformTo(b,p);this.zipComment=this.loadOptions.decodeFileName(u)},readBlockZip64EndOfCentral:function(){this.zip64EndOfCentralSize=this.reader.readInt(8),this.reader.skip(4),this.diskNumber=this.reader.readInt(4),this.diskWithCentralDirStart=this.reader.readInt(4),this.centralDirRecordsOnThisDisk=this.reader.readInt(8),this.centralDirRecords=this.reader.readInt(8),this.centralDirSize=this.reader.readInt(8),this.centralDirOffset=this.reader.readInt(8),this.zip64ExtensibleData={};for(var p,b,u,h=this.zip64EndOfCentralSize-44;0<h;)p=this.reader.readInt(2),b=this.reader.readInt(4),u=this.reader.readData(b),this.zip64ExtensibleData[p]={id:p,length:b,value:u}},readBlockZip64EndOfCentralLocator:function(){if(this.diskWithZip64CentralDirStart=this.reader.readInt(4),this.relativeOffsetEndOfZip64CentralDir=this.reader.readInt(8),this.disksCount=this.reader.readInt(4),1<this.disksCount)throw new Error("Multi-volumes zip are not supported")},readLocalFiles:function(){var p,b;for(p=0;p<this.files.length;p++)b=this.files[p],this.reader.setIndex(b.localHeaderOffset),this.checkSignature(r.LOCAL_FILE_HEADER),b.readLocalPart(this.reader),b.handleUTF8(),b.processAttributes()},readCentralDir:function(){var p;for(this.reader.setIndex(this.centralDirOffset);this.reader.readAndCheckSignature(r.CENTRAL_FILE_HEADER);)(p=new a({zip64:this.zip64},this.loadOptions)).readCentralPart(this.reader),this.files.push(p);if(this.centralDirRecords!==this.files.length&&this.centralDirRecords!==0&&this.files.length===0)throw new Error("Corrupted zip or bug: expected "+this.centralDirRecords+" records in central dir, got "+this.files.length)},readEndOfCentral:function(){var p=this.reader.lastIndexOfSignature(r.CENTRAL_DIRECTORY_END);if(p<0)throw this.isSignature(0,r.LOCAL_FILE_HEADER)?new Error("Corrupted zip: can't find end of central directory"):new Error("Can't find end of central directory : is this a zip file ? If it is, see https://stuk.github.io/jszip/documentation/howto/read_zip.html");this.reader.setIndex(p);var b=p;if(this.checkSignature(r.CENTRAL_DIRECTORY_END),this.readBlockEndOfCentral(),this.diskNumber===l.MAX_VALUE_16BITS||this.diskWithCentralDirStart===l.MAX_VALUE_16BITS||this.centralDirRecordsOnThisDisk===l.MAX_VALUE_16BITS||this.centralDirRecords===l.MAX_VALUE_16BITS||this.centralDirSize===l.MAX_VALUE_32BITS||this.centralDirOffset===l.MAX_VALUE_32BITS){if(this.zip64=!0,(p=this.reader.lastIndexOfSignature(r.ZIP64_CENTRAL_DIRECTORY_LOCATOR))<0)throw new Error("Corrupted zip: can't find the ZIP64 end of central directory locator");if(this.reader.setIndex(p),this.checkSignature(r.ZIP64_CENTRAL_DIRECTORY_LOCATOR),this.readBlockZip64EndOfCentralLocator(),!this.isSignature(this.relativeOffsetEndOfZip64CentralDir,r.ZIP64_CENTRAL_DIRECTORY_END)&&(this.relativeOffsetEndOfZip64CentralDir=this.reader.lastIndexOfSignature(r.ZIP64_CENTRAL_DIRECTORY_END),this.relativeOffsetEndOfZip64CentralDir<0))throw new Error("Corrupted zip: can't find the ZIP64 end of central directory");this.reader.setIndex(this.relativeOffsetEndOfZip64CentralDir),this.checkSignature(r.ZIP64_CENTRAL_DIRECTORY_END),this.readBlockZip64EndOfCentral()}var u=this.centralDirOffset+this.centralDirSize;this.zip64&&(u+=20,u+=12+this.zip64EndOfCentralSize);var h=b-u;if(0<h)this.isSignature(b,r.CENTRAL_FILE_HEADER)||(this.reader.zero=h);else if(h<0)throw new Error("Corrupted zip: missing "+Math.abs(h)+" bytes.")},prepareReader:function(p){this.reader=s(p)},load:function(p){this.prepareReader(p),this.readEndOfCentral(),this.readCentralDir(),this.readLocalFiles()}},n.exports=d},{"./reader/readerFor":22,"./signature":23,"./support":30,"./utils":32,"./zipEntry":34}],34:[function(i,n,o){var s=i("./reader/readerFor"),l=i("./utils"),r=i("./compressedObject"),a=i("./crc32"),c=i("./utf8"),d=i("./compressions"),p=i("./support");function b(u,h){this.options=u,this.loadOptions=h}b.prototype={isEncrypted:function(){return(1&this.bitFlag)==1},useUTF8:function(){return(2048&this.bitFlag)==2048},readLocalPart:function(u){var h,f;if(u.skip(22),this.fileNameLength=u.readInt(2),f=u.readInt(2),this.fileName=u.readData(this.fileNameLength),u.skip(f),this.compressedSize===-1||this.uncompressedSize===-1)throw new Error("Bug or corrupted zip : didn't get enough information from the central directory (compressedSize === -1 || uncompressedSize === -1)");if((h=(function(g){for(var k in d)if(Object.prototype.hasOwnProperty.call(d,k)&&d[k].magic===g)return d[k];return null})(this.compressionMethod))===null)throw new Error("Corrupted zip : compression "+l.pretty(this.compressionMethod)+" unknown (inner file : "+l.transformTo("string",this.fileName)+")");this.decompressed=new r(this.compressedSize,this.uncompressedSize,this.crc32,h,u.readData(this.compressedSize))},readCentralPart:function(u){this.versionMadeBy=u.readInt(2),u.skip(2),this.bitFlag=u.readInt(2),this.compressionMethod=u.readString(2),this.date=u.readDate(),this.crc32=u.readInt(4),this.compressedSize=u.readInt(4),this.uncompressedSize=u.readInt(4);var h=u.readInt(2);if(this.extraFieldsLength=u.readInt(2),this.fileCommentLength=u.readInt(2),this.diskNumberStart=u.readInt(2),this.internalFileAttributes=u.readInt(2),this.externalFileAttributes=u.readInt(4),this.localHeaderOffset=u.readInt(4),this.isEncrypted())throw new Error("Encrypted zip are not supported");u.skip(h),this.readExtraFields(u),this.parseZIP64ExtraField(u),this.fileComment=u.readData(this.fileCommentLength)},processAttributes:function(){this.unixPermissions=null,this.dosPermissions=null;var u=this.versionMadeBy>>8;this.dir=!!(16&this.externalFileAttributes),u==0&&(this.dosPermissions=63&this.externalFileAttributes),u==3&&(this.unixPermissions=this.externalFileAttributes>>16&65535),this.dir||this.fileNameStr.slice(-1)!=="/"||(this.dir=!0)},parseZIP64ExtraField:function(){if(this.extraFields[1]){var u=s(this.extraFields[1].value);this.uncompressedSize===l.MAX_VALUE_32BITS&&(this.uncompressedSize=u.readInt(8)),this.compressedSize===l.MAX_VALUE_32BITS&&(this.compressedSize=u.readInt(8)),this.localHeaderOffset===l.MAX_VALUE_32BITS&&(this.localHeaderOffset=u.readInt(8)),this.diskNumberStart===l.MAX_VALUE_32BITS&&(this.diskNumberStart=u.readInt(4))}},readExtraFields:function(u){var h,f,g,k=u.index+this.extraFieldsLength;for(this.extraFields||(this.extraFields={});u.index+4<k;)h=u.readInt(2),f=u.readInt(2),g=u.readData(f),this.extraFields[h]={id:h,length:f,value:g};u.setIndex(k)},handleUTF8:function(){var u=p.uint8array?"uint8array":"array";if(this.useUTF8())this.fileNameStr=c.utf8decode(this.fileName),this.fileCommentStr=c.utf8decode(this.fileComment);else{var h=this.findExtraFieldUnicodePath();if(h!==null)this.fileNameStr=h;else{var f=l.transformTo(u,this.fileName);this.fileNameStr=this.loadOptions.decodeFileName(f)}var g=this.findExtraFieldUnicodeComment();if(g!==null)this.fileCommentStr=g;else{var k=l.transformTo(u,this.fileComment);this.fileCommentStr=this.loadOptions.decodeFileName(k)}}},findExtraFieldUnicodePath:function(){var u=this.extraFields[28789];if(u){var h=s(u.value);return h.readInt(1)!==1||a(this.fileName)!==h.readInt(4)?null:c.utf8decode(h.readData(u.length-5))}return null},findExtraFieldUnicodeComment:function(){var u=this.extraFields[25461];if(u){var h=s(u.value);return h.readInt(1)!==1||a(this.fileComment)!==h.readInt(4)?null:c.utf8decode(h.readData(u.length-5))}return null}},n.exports=b},{"./compressedObject":2,"./compressions":3,"./crc32":4,"./reader/readerFor":22,"./support":30,"./utf8":31,"./utils":32}],35:[function(i,n,o){function s(h,f,g){this.name=h,this.dir=g.dir,this.date=g.date,this.comment=g.comment,this.unixPermissions=g.unixPermissions,this.dosPermissions=g.dosPermissions,this._data=f,this._dataBinary=g.binary,this.options={compression:g.compression,compressionOptions:g.compressionOptions}}var l=i("./stream/StreamHelper"),r=i("./stream/DataWorker"),a=i("./utf8"),c=i("./compressedObject"),d=i("./stream/GenericWorker");s.prototype={internalStream:function(h){var f=null,g="string";try{if(!h)throw new Error("No output type specified.");var k=(g=h.toLowerCase())==="string"||g==="text";g!=="binarystring"&&g!=="text"||(g="string"),f=this._decompressWorker();var S=!this._dataBinary;S&&!k&&(f=f.pipe(new a.Utf8EncodeWorker)),!S&&k&&(f=f.pipe(new a.Utf8DecodeWorker))}catch(C){(f=new d("error")).error(C)}return new l(f,g,"")},async:function(h,f){return this.internalStream(h).accumulate(f)},nodeStream:function(h,f){return this.internalStream(h||"nodebuffer").toNodejsStream(f)},_compressWorker:function(h,f){if(this._data instanceof c&&this._data.compression.magic===h.magic)return this._data.getCompressedWorker();var g=this._decompressWorker();return this._dataBinary||(g=g.pipe(new a.Utf8EncodeWorker)),c.createWorkerFrom(g,h,f)},_decompressWorker:function(){return this._data instanceof c?this._data.getContentWorker():this._data instanceof d?this._data:new r(this._data)}};for(var p=["asText","asBinary","asNodeBuffer","asUint8Array","asArrayBuffer"],b=function(){throw new Error("This method has been removed in JSZip 3.0, please check the upgrade guide.")},u=0;u<p.length;u++)s.prototype[p[u]]=b;n.exports=s},{"./compressedObject":2,"./stream/DataWorker":27,"./stream/GenericWorker":28,"./stream/StreamHelper":29,"./utf8":31}],36:[function(i,n,o){(function(s){var l,r,a=s.MutationObserver||s.WebKitMutationObserver;if(a){var c=0,d=new a(h),p=s.document.createTextNode("");d.observe(p,{characterData:!0}),l=function(){p.data=c=++c%2}}else if(s.setImmediate||s.MessageChannel===void 0)l="document"in s&&"onreadystatechange"in s.document.createElement("script")?function(){var f=s.document.createElement("script");f.onreadystatechange=function(){h(),f.onreadystatechange=null,f.parentNode.removeChild(f),f=null},s.document.documentElement.appendChild(f)}:function(){setTimeout(h,0)};else{var b=new s.MessageChannel;b.port1.onmessage=h,l=function(){b.port2.postMessage(0)}}var u=[];function h(){var f,g;r=!0;for(var k=u.length;k;){for(g=u,u=[],f=-1;++f<k;)g[f]();k=u.length}r=!1}n.exports=function(f){u.push(f)!==1||r||l()}}).call(this,typeof Xn<"u"?Xn:typeof self<"u"?self:typeof window<"u"?window:{})},{}],37:[function(i,n,o){var s=i("immediate");function l(){}var r={},a=["REJECTED"],c=["FULFILLED"],d=["PENDING"];function p(k){if(typeof k!="function")throw new TypeError("resolver must be a function");this.state=d,this.queue=[],this.outcome=void 0,k!==l&&f(this,k)}function b(k,S,C){this.promise=k,typeof S=="function"&&(this.onFulfilled=S,this.callFulfilled=this.otherCallFulfilled),typeof C=="function"&&(this.onRejected=C,this.callRejected=this.otherCallRejected)}function u(k,S,C){s(function(){var T;try{T=S(C)}catch(B){return r.reject(k,B)}T===k?r.reject(k,new TypeError("Cannot resolve promise with itself")):r.resolve(k,T)})}function h(k){var S=k&&k.then;if(k&&(typeof k=="object"||typeof k=="function")&&typeof S=="function")return function(){S.apply(k,arguments)}}function f(k,S){var C=!1;function T(w){C||(C=!0,r.reject(k,w))}function B(w){C||(C=!0,r.resolve(k,w))}var I=g(function(){S(B,T)});I.status==="error"&&T(I.value)}function g(k,S){var C={};try{C.value=k(S),C.status="success"}catch(T){C.status="error",C.value=T}return C}(n.exports=p).prototype.finally=function(k){if(typeof k!="function")return this;var S=this.constructor;return this.then(function(C){return S.resolve(k()).then(function(){return C})},function(C){return S.resolve(k()).then(function(){throw C})})},p.prototype.catch=function(k){return this.then(null,k)},p.prototype.then=function(k,S){if(typeof k!="function"&&this.state===c||typeof S!="function"&&this.state===a)return this;var C=new this.constructor(l);return this.state!==d?u(C,this.state===c?k:S,this.outcome):this.queue.push(new b(C,k,S)),C},b.prototype.callFulfilled=function(k){r.resolve(this.promise,k)},b.prototype.otherCallFulfilled=function(k){u(this.promise,this.onFulfilled,k)},b.prototype.callRejected=function(k){r.reject(this.promise,k)},b.prototype.otherCallRejected=function(k){u(this.promise,this.onRejected,k)},r.resolve=function(k,S){var C=g(h,S);if(C.status==="error")return r.reject(k,C.value);var T=C.value;if(T)f(k,T);else{k.state=c,k.outcome=S;for(var B=-1,I=k.queue.length;++B<I;)k.queue[B].callFulfilled(S)}return k},r.reject=function(k,S){k.state=a,k.outcome=S;for(var C=-1,T=k.queue.length;++C<T;)k.queue[C].callRejected(S);return k},p.resolve=function(k){return k instanceof this?k:r.resolve(new this(l),k)},p.reject=function(k){var S=new this(l);return r.reject(S,k)},p.all=function(k){var S=this;if(Object.prototype.toString.call(k)!=="[object Array]")return this.reject(new TypeError("must be an array"));var C=k.length,T=!1;if(!C)return this.resolve([]);for(var B=new Array(C),I=0,w=-1,P=new this(l);++w<C;)R(k[w],w);return P;function R(z,V){S.resolve(z).then(function(_){B[V]=_,++I!==C||T||(T=!0,r.resolve(P,B))},function(_){T||(T=!0,r.reject(P,_))})}},p.race=function(k){var S=this;if(Object.prototype.toString.call(k)!=="[object Array]")return this.reject(new TypeError("must be an array"));var C=k.length,T=!1;if(!C)return this.resolve([]);for(var B=-1,I=new this(l);++B<C;)w=k[B],S.resolve(w).then(function(P){T||(T=!0,r.resolve(I,P))},function(P){T||(T=!0,r.reject(I,P))});var w;return I}},{immediate:36}],38:[function(i,n,o){var s={};(0,i("./lib/utils/common").assign)(s,i("./lib/deflate"),i("./lib/inflate"),i("./lib/zlib/constants")),n.exports=s},{"./lib/deflate":39,"./lib/inflate":40,"./lib/utils/common":41,"./lib/zlib/constants":44}],39:[function(i,n,o){var s=i("./zlib/deflate"),l=i("./utils/common"),r=i("./utils/strings"),a=i("./zlib/messages"),c=i("./zlib/zstream"),d=Object.prototype.toString,p=0,b=-1,u=0,h=8;function f(k){if(!(this instanceof f))return new f(k);this.options=l.assign({level:b,method:h,chunkSize:16384,windowBits:15,memLevel:8,strategy:u,to:""},k||{});var S=this.options;S.raw&&0<S.windowBits?S.windowBits=-S.windowBits:S.gzip&&0<S.windowBits&&S.windowBits<16&&(S.windowBits+=16),this.err=0,this.msg="",this.ended=!1,this.chunks=[],this.strm=new c,this.strm.avail_out=0;var C=s.deflateInit2(this.strm,S.level,S.method,S.windowBits,S.memLevel,S.strategy);if(C!==p)throw new Error(a[C]);if(S.header&&s.deflateSetHeader(this.strm,S.header),S.dictionary){var T;if(T=typeof S.dictionary=="string"?r.string2buf(S.dictionary):d.call(S.dictionary)==="[object ArrayBuffer]"?new Uint8Array(S.dictionary):S.dictionary,(C=s.deflateSetDictionary(this.strm,T))!==p)throw new Error(a[C]);this._dict_set=!0}}function g(k,S){var C=new f(S);if(C.push(k,!0),C.err)throw C.msg||a[C.err];return C.result}f.prototype.push=function(k,S){var C,T,B=this.strm,I=this.options.chunkSize;if(this.ended)return!1;T=S===~~S?S:S===!0?4:0,typeof k=="string"?B.input=r.string2buf(k):d.call(k)==="[object ArrayBuffer]"?B.input=new Uint8Array(k):B.input=k,B.next_in=0,B.avail_in=B.input.length;do{if(B.avail_out===0&&(B.output=new l.Buf8(I),B.next_out=0,B.avail_out=I),(C=s.deflate(B,T))!==1&&C!==p)return this.onEnd(C),!(this.ended=!0);B.avail_out!==0&&(B.avail_in!==0||T!==4&&T!==2)||(this.options.to==="string"?this.onData(r.buf2binstring(l.shrinkBuf(B.output,B.next_out))):this.onData(l.shrinkBuf(B.output,B.next_out)))}while((0<B.avail_in||B.avail_out===0)&&C!==1);return T===4?(C=s.deflateEnd(this.strm),this.onEnd(C),this.ended=!0,C===p):T!==2||(this.onEnd(p),!(B.avail_out=0))},f.prototype.onData=function(k){this.chunks.push(k)},f.prototype.onEnd=function(k){k===p&&(this.options.to==="string"?this.result=this.chunks.join(""):this.result=l.flattenChunks(this.chunks)),this.chunks=[],this.err=k,this.msg=this.strm.msg},o.Deflate=f,o.deflate=g,o.deflateRaw=function(k,S){return(S=S||{}).raw=!0,g(k,S)},o.gzip=function(k,S){return(S=S||{}).gzip=!0,g(k,S)}},{"./utils/common":41,"./utils/strings":42,"./zlib/deflate":46,"./zlib/messages":51,"./zlib/zstream":53}],40:[function(i,n,o){var s=i("./zlib/inflate"),l=i("./utils/common"),r=i("./utils/strings"),a=i("./zlib/constants"),c=i("./zlib/messages"),d=i("./zlib/zstream"),p=i("./zlib/gzheader"),b=Object.prototype.toString;function u(f){if(!(this instanceof u))return new u(f);this.options=l.assign({chunkSize:16384,windowBits:0,to:""},f||{});var g=this.options;g.raw&&0<=g.windowBits&&g.windowBits<16&&(g.windowBits=-g.windowBits,g.windowBits===0&&(g.windowBits=-15)),!(0<=g.windowBits&&g.windowBits<16)||f&&f.windowBits||(g.windowBits+=32),15<g.windowBits&&g.windowBits<48&&(15&g.windowBits)==0&&(g.windowBits|=15),this.err=0,this.msg="",this.ended=!1,this.chunks=[],this.strm=new d,this.strm.avail_out=0;var k=s.inflateInit2(this.strm,g.windowBits);if(k!==a.Z_OK)throw new Error(c[k]);this.header=new p,s.inflateGetHeader(this.strm,this.header)}function h(f,g){var k=new u(g);if(k.push(f,!0),k.err)throw k.msg||c[k.err];return k.result}u.prototype.push=function(f,g){var k,S,C,T,B,I,w=this.strm,P=this.options.chunkSize,R=this.options.dictionary,z=!1;if(this.ended)return!1;S=g===~~g?g:g===!0?a.Z_FINISH:a.Z_NO_FLUSH,typeof f=="string"?w.input=r.binstring2buf(f):b.call(f)==="[object ArrayBuffer]"?w.input=new Uint8Array(f):w.input=f,w.next_in=0,w.avail_in=w.input.length;do{if(w.avail_out===0&&(w.output=new l.Buf8(P),w.next_out=0,w.avail_out=P),(k=s.inflate(w,a.Z_NO_FLUSH))===a.Z_NEED_DICT&&R&&(I=typeof R=="string"?r.string2buf(R):b.call(R)==="[object ArrayBuffer]"?new Uint8Array(R):R,k=s.inflateSetDictionary(this.strm,I)),k===a.Z_BUF_ERROR&&z===!0&&(k=a.Z_OK,z=!1),k!==a.Z_STREAM_END&&k!==a.Z_OK)return this.onEnd(k),!(this.ended=!0);w.next_out&&(w.avail_out!==0&&k!==a.Z_STREAM_END&&(w.avail_in!==0||S!==a.Z_FINISH&&S!==a.Z_SYNC_FLUSH)||(this.options.to==="string"?(C=r.utf8border(w.output,w.next_out),T=w.next_out-C,B=r.buf2string(w.output,C),w.next_out=T,w.avail_out=P-T,T&&l.arraySet(w.output,w.output,C,T,0),this.onData(B)):this.onData(l.shrinkBuf(w.output,w.next_out)))),w.avail_in===0&&w.avail_out===0&&(z=!0)}while((0<w.avail_in||w.avail_out===0)&&k!==a.Z_STREAM_END);return k===a.Z_STREAM_END&&(S=a.Z_FINISH),S===a.Z_FINISH?(k=s.inflateEnd(this.strm),this.onEnd(k),this.ended=!0,k===a.Z_OK):S!==a.Z_SYNC_FLUSH||(this.onEnd(a.Z_OK),!(w.avail_out=0))},u.prototype.onData=function(f){this.chunks.push(f)},u.prototype.onEnd=function(f){f===a.Z_OK&&(this.options.to==="string"?this.result=this.chunks.join(""):this.result=l.flattenChunks(this.chunks)),this.chunks=[],this.err=f,this.msg=this.strm.msg},o.Inflate=u,o.inflate=h,o.inflateRaw=function(f,g){return(g=g||{}).raw=!0,h(f,g)},o.ungzip=h},{"./utils/common":41,"./utils/strings":42,"./zlib/constants":44,"./zlib/gzheader":47,"./zlib/inflate":49,"./zlib/messages":51,"./zlib/zstream":53}],41:[function(i,n,o){var s=typeof Uint8Array<"u"&&typeof Uint16Array<"u"&&typeof Int32Array<"u";o.assign=function(a){for(var c=Array.prototype.slice.call(arguments,1);c.length;){var d=c.shift();if(d){if(typeof d!="object")throw new TypeError(d+"must be non-object");for(var p in d)d.hasOwnProperty(p)&&(a[p]=d[p])}}return a},o.shrinkBuf=function(a,c){return a.length===c?a:a.subarray?a.subarray(0,c):(a.length=c,a)};var l={arraySet:function(a,c,d,p,b){if(c.subarray&&a.subarray)a.set(c.subarray(d,d+p),b);else for(var u=0;u<p;u++)a[b+u]=c[d+u]},flattenChunks:function(a){var c,d,p,b,u,h;for(c=p=0,d=a.length;c<d;c++)p+=a[c].length;for(h=new Uint8Array(p),c=b=0,d=a.length;c<d;c++)u=a[c],h.set(u,b),b+=u.length;return h}},r={arraySet:function(a,c,d,p,b){for(var u=0;u<p;u++)a[b+u]=c[d+u]},flattenChunks:function(a){return[].concat.apply([],a)}};o.setTyped=function(a){a?(o.Buf8=Uint8Array,o.Buf16=Uint16Array,o.Buf32=Int32Array,o.assign(o,l)):(o.Buf8=Array,o.Buf16=Array,o.Buf32=Array,o.assign(o,r))},o.setTyped(s)},{}],42:[function(i,n,o){var s=i("./common"),l=!0,r=!0;try{String.fromCharCode.apply(null,[0])}catch{l=!1}try{String.fromCharCode.apply(null,new Uint8Array(1))}catch{r=!1}for(var a=new s.Buf8(256),c=0;c<256;c++)a[c]=252<=c?6:248<=c?5:240<=c?4:224<=c?3:192<=c?2:1;function d(p,b){if(b<65537&&(p.subarray&&r||!p.subarray&&l))return String.fromCharCode.apply(null,s.shrinkBuf(p,b));for(var u="",h=0;h<b;h++)u+=String.fromCharCode(p[h]);return u}a[254]=a[254]=1,o.string2buf=function(p){var b,u,h,f,g,k=p.length,S=0;for(f=0;f<k;f++)(64512&(u=p.charCodeAt(f)))==55296&&f+1<k&&(64512&(h=p.charCodeAt(f+1)))==56320&&(u=65536+(u-55296<<10)+(h-56320),f++),S+=u<128?1:u<2048?2:u<65536?3:4;for(b=new s.Buf8(S),f=g=0;g<S;f++)(64512&(u=p.charCodeAt(f)))==55296&&f+1<k&&(64512&(h=p.charCodeAt(f+1)))==56320&&(u=65536+(u-55296<<10)+(h-56320),f++),u<128?b[g++]=u:(u<2048?b[g++]=192|u>>>6:(u<65536?b[g++]=224|u>>>12:(b[g++]=240|u>>>18,b[g++]=128|u>>>12&63),b[g++]=128|u>>>6&63),b[g++]=128|63&u);return b},o.buf2binstring=function(p){return d(p,p.length)},o.binstring2buf=function(p){for(var b=new s.Buf8(p.length),u=0,h=b.length;u<h;u++)b[u]=p.charCodeAt(u);return b},o.buf2string=function(p,b){var u,h,f,g,k=b||p.length,S=new Array(2*k);for(u=h=0;u<k;)if((f=p[u++])<128)S[h++]=f;else if(4<(g=a[f]))S[h++]=65533,u+=g-1;else{for(f&=g===2?31:g===3?15:7;1<g&&u<k;)f=f<<6|63&p[u++],g--;1<g?S[h++]=65533:f<65536?S[h++]=f:(f-=65536,S[h++]=55296|f>>10&1023,S[h++]=56320|1023&f)}return d(S,h)},o.utf8border=function(p,b){var u;for((b=b||p.length)>p.length&&(b=p.length),u=b-1;0<=u&&(192&p[u])==128;)u--;return u<0||u===0?b:u+a[p[u]]>b?u:b}},{"./common":41}],43:[function(i,n,o){n.exports=function(s,l,r,a){for(var c=65535&s|0,d=s>>>16&65535|0,p=0;r!==0;){for(r-=p=2e3<r?2e3:r;d=d+(c=c+l[a++]|0)|0,--p;);c%=65521,d%=65521}return c|d<<16|0}},{}],44:[function(i,n,o){n.exports={Z_NO_FLUSH:0,Z_PARTIAL_FLUSH:1,Z_SYNC_FLUSH:2,Z_FULL_FLUSH:3,Z_FINISH:4,Z_BLOCK:5,Z_TREES:6,Z_OK:0,Z_STREAM_END:1,Z_NEED_DICT:2,Z_ERRNO:-1,Z_STREAM_ERROR:-2,Z_DATA_ERROR:-3,Z_BUF_ERROR:-5,Z_NO_COMPRESSION:0,Z_BEST_SPEED:1,Z_BEST_COMPRESSION:9,Z_DEFAULT_COMPRESSION:-1,Z_FILTERED:1,Z_HUFFMAN_ONLY:2,Z_RLE:3,Z_FIXED:4,Z_DEFAULT_STRATEGY:0,Z_BINARY:0,Z_TEXT:1,Z_UNKNOWN:2,Z_DEFLATED:8}},{}],45:[function(i,n,o){var s=(function(){for(var l,r=[],a=0;a<256;a++){l=a;for(var c=0;c<8;c++)l=1&l?3988292384^l>>>1:l>>>1;r[a]=l}return r})();n.exports=function(l,r,a,c){var d=s,p=c+a;l^=-1;for(var b=c;b<p;b++)l=l>>>8^d[255&(l^r[b])];return-1^l}},{}],46:[function(i,n,o){var s,l=i("../utils/common"),r=i("./trees"),a=i("./adler32"),c=i("./crc32"),d=i("./messages"),p=0,b=4,u=0,h=-2,f=-1,g=4,k=2,S=8,C=9,T=286,B=30,I=19,w=2*T+1,P=15,R=3,z=258,V=z+R+1,_=42,L=113,y=1,A=2,F=3,E=4;function D(v,K){return v.msg=d[K],K}function N(v){return(v<<1)-(4<v?9:0)}function X(v){for(var K=v.length;0<=--K;)v[K]=0}function j(v){var K=v.state,H=K.pending;H>v.avail_out&&(H=v.avail_out),H!==0&&(l.arraySet(v.output,K.pending_buf,K.pending_out,H,v.next_out),v.next_out+=H,K.pending_out+=H,v.total_out+=H,v.avail_out-=H,K.pending-=H,K.pending===0&&(K.pending_out=0))}function G(v,K){r._tr_flush_block(v,0<=v.block_start?v.block_start:-1,v.strstart-v.block_start,K),v.block_start=v.strstart,j(v.strm)}function ne(v,K){v.pending_buf[v.pending++]=K}function se(v,K){v.pending_buf[v.pending++]=K>>>8&255,v.pending_buf[v.pending++]=255&K}function le(v,K){var H,$,x=v.max_chain_length,M=v.strstart,Y=v.prev_length,U=v.nice_match,Z=v.strstart>v.w_size-V?v.strstart-(v.w_size-V):0,Q=v.window,oe=v.w_mask,ie=v.prev,de=v.strstart+z,Se=Q[M+Y-1],ke=Q[M+Y];v.prev_length>=v.good_match&&(x>>=2),U>v.lookahead&&(U=v.lookahead);do if(Q[(H=K)+Y]===ke&&Q[H+Y-1]===Se&&Q[H]===Q[M]&&Q[++H]===Q[M+1]){M+=2,H++;do;while(Q[++M]===Q[++H]&&Q[++M]===Q[++H]&&Q[++M]===Q[++H]&&Q[++M]===Q[++H]&&Q[++M]===Q[++H]&&Q[++M]===Q[++H]&&Q[++M]===Q[++H]&&Q[++M]===Q[++H]&&M<de);if($=z-(de-M),M=de-z,Y<$){if(v.match_start=K,U<=(Y=$))break;Se=Q[M+Y-1],ke=Q[M+Y]}}while((K=ie[K&oe])>Z&&--x!=0);return Y<=v.lookahead?Y:v.lookahead}function pe(v){var K,H,$,x,M,Y,U,Z,Q,oe,ie=v.w_size;do{if(x=v.window_size-v.lookahead-v.strstart,v.strstart>=ie+(ie-V)){for(l.arraySet(v.window,v.window,ie,ie,0),v.match_start-=ie,v.strstart-=ie,v.block_start-=ie,K=H=v.hash_size;$=v.head[--K],v.head[K]=ie<=$?$-ie:0,--H;);for(K=H=ie;$=v.prev[--K],v.prev[K]=ie<=$?$-ie:0,--H;);x+=ie}if(v.strm.avail_in===0)break;if(Y=v.strm,U=v.window,Z=v.strstart+v.lookahead,Q=x,oe=void 0,oe=Y.avail_in,Q<oe&&(oe=Q),H=oe===0?0:(Y.avail_in-=oe,l.arraySet(U,Y.input,Y.next_in,oe,Z),Y.state.wrap===1?Y.adler=a(Y.adler,U,oe,Z):Y.state.wrap===2&&(Y.adler=c(Y.adler,U,oe,Z)),Y.next_in+=oe,Y.total_in+=oe,oe),v.lookahead+=H,v.lookahead+v.insert>=R)for(M=v.strstart-v.insert,v.ins_h=v.window[M],v.ins_h=(v.ins_h<<v.hash_shift^v.window[M+1])&v.hash_mask;v.insert&&(v.ins_h=(v.ins_h<<v.hash_shift^v.window[M+R-1])&v.hash_mask,v.prev[M&v.w_mask]=v.head[v.ins_h],v.head[v.ins_h]=M,M++,v.insert--,!(v.lookahead+v.insert<R)););}while(v.lookahead<V&&v.strm.avail_in!==0)}function Te(v,K){for(var H,$;;){if(v.lookahead<V){if(pe(v),v.lookahead<V&&K===p)return y;if(v.lookahead===0)break}if(H=0,v.lookahead>=R&&(v.ins_h=(v.ins_h<<v.hash_shift^v.window[v.strstart+R-1])&v.hash_mask,H=v.prev[v.strstart&v.w_mask]=v.head[v.ins_h],v.head[v.ins_h]=v.strstart),H!==0&&v.strstart-H<=v.w_size-V&&(v.match_length=le(v,H)),v.match_length>=R)if($=r._tr_tally(v,v.strstart-v.match_start,v.match_length-R),v.lookahead-=v.match_length,v.match_length<=v.max_lazy_match&&v.lookahead>=R){for(v.match_length--;v.strstart++,v.ins_h=(v.ins_h<<v.hash_shift^v.window[v.strstart+R-1])&v.hash_mask,H=v.prev[v.strstart&v.w_mask]=v.head[v.ins_h],v.head[v.ins_h]=v.strstart,--v.match_length!=0;);v.strstart++}else v.strstart+=v.match_length,v.match_length=0,v.ins_h=v.window[v.strstart],v.ins_h=(v.ins_h<<v.hash_shift^v.window[v.strstart+1])&v.hash_mask;else $=r._tr_tally(v,0,v.window[v.strstart]),v.lookahead--,v.strstart++;if($&&(G(v,!1),v.strm.avail_out===0))return y}return v.insert=v.strstart<R-1?v.strstart:R-1,K===b?(G(v,!0),v.strm.avail_out===0?F:E):v.last_lit&&(G(v,!1),v.strm.avail_out===0)?y:A}function be(v,K){for(var H,$,x;;){if(v.lookahead<V){if(pe(v),v.lookahead<V&&K===p)return y;if(v.lookahead===0)break}if(H=0,v.lookahead>=R&&(v.ins_h=(v.ins_h<<v.hash_shift^v.window[v.strstart+R-1])&v.hash_mask,H=v.prev[v.strstart&v.w_mask]=v.head[v.ins_h],v.head[v.ins_h]=v.strstart),v.prev_length=v.match_length,v.prev_match=v.match_start,v.match_length=R-1,H!==0&&v.prev_length<v.max_lazy_match&&v.strstart-H<=v.w_size-V&&(v.match_length=le(v,H),v.match_length<=5&&(v.strategy===1||v.match_length===R&&4096<v.strstart-v.match_start)&&(v.match_length=R-1)),v.prev_length>=R&&v.match_length<=v.prev_length){for(x=v.strstart+v.lookahead-R,$=r._tr_tally(v,v.strstart-1-v.prev_match,v.prev_length-R),v.lookahead-=v.prev_length-1,v.prev_length-=2;++v.strstart<=x&&(v.ins_h=(v.ins_h<<v.hash_shift^v.window[v.strstart+R-1])&v.hash_mask,H=v.prev[v.strstart&v.w_mask]=v.head[v.ins_h],v.head[v.ins_h]=v.strstart),--v.prev_length!=0;);if(v.match_available=0,v.match_length=R-1,v.strstart++,$&&(G(v,!1),v.strm.avail_out===0))return y}else if(v.match_available){if(($=r._tr_tally(v,0,v.window[v.strstart-1]))&&G(v,!1),v.strstart++,v.lookahead--,v.strm.avail_out===0)return y}else v.match_available=1,v.strstart++,v.lookahead--}return v.match_available&&($=r._tr_tally(v,0,v.window[v.strstart-1]),v.match_available=0),v.insert=v.strstart<R-1?v.strstart:R-1,K===b?(G(v,!0),v.strm.avail_out===0?F:E):v.last_lit&&(G(v,!1),v.strm.avail_out===0)?y:A}function q(v,K,H,$,x){this.good_length=v,this.max_lazy=K,this.nice_length=H,this.max_chain=$,this.func=x}function ae(){this.strm=null,this.status=0,this.pending_buf=null,this.pending_buf_size=0,this.pending_out=0,this.pending=0,this.wrap=0,this.gzhead=null,this.gzindex=0,this.method=S,this.last_flush=-1,this.w_size=0,this.w_bits=0,this.w_mask=0,this.window=null,this.window_size=0,this.prev=null,this.head=null,this.ins_h=0,this.hash_size=0,this.hash_bits=0,this.hash_mask=0,this.hash_shift=0,this.block_start=0,this.match_length=0,this.prev_match=0,this.match_available=0,this.strstart=0,this.match_start=0,this.lookahead=0,this.prev_length=0,this.max_chain_length=0,this.max_lazy_match=0,this.level=0,this.strategy=0,this.good_match=0,this.nice_match=0,this.dyn_ltree=new l.Buf16(2*w),this.dyn_dtree=new l.Buf16(2*(2*B+1)),this.bl_tree=new l.Buf16(2*(2*I+1)),X(this.dyn_ltree),X(this.dyn_dtree),X(this.bl_tree),this.l_desc=null,this.d_desc=null,this.bl_desc=null,this.bl_count=new l.Buf16(P+1),this.heap=new l.Buf16(2*T+1),X(this.heap),this.heap_len=0,this.heap_max=0,this.depth=new l.Buf16(2*T+1),X(this.depth),this.l_buf=0,this.lit_bufsize=0,this.last_lit=0,this.d_buf=0,this.opt_len=0,this.static_len=0,this.matches=0,this.insert=0,this.bi_buf=0,this.bi_valid=0}function ve(v){var K;return v&&v.state?(v.total_in=v.total_out=0,v.data_type=k,(K=v.state).pending=0,K.pending_out=0,K.wrap<0&&(K.wrap=-K.wrap),K.status=K.wrap?_:L,v.adler=K.wrap===2?0:1,K.last_flush=p,r._tr_init(K),u):D(v,h)}function O(v){var K=ve(v);return K===u&&(function(H){H.window_size=2*H.w_size,X(H.head),H.max_lazy_match=s[H.level].max_lazy,H.good_match=s[H.level].good_length,H.nice_match=s[H.level].nice_length,H.max_chain_length=s[H.level].max_chain,H.strstart=0,H.block_start=0,H.lookahead=0,H.insert=0,H.match_length=H.prev_length=R-1,H.match_available=0,H.ins_h=0})(v.state),K}function W(v,K,H,$,x,M){if(!v)return h;var Y=1;if(K===f&&(K=6),$<0?(Y=0,$=-$):15<$&&(Y=2,$-=16),x<1||C<x||H!==S||$<8||15<$||K<0||9<K||M<0||g<M)return D(v,h);$===8&&($=9);var U=new ae;return(v.state=U).strm=v,U.wrap=Y,U.gzhead=null,U.w_bits=$,U.w_size=1<<U.w_bits,U.w_mask=U.w_size-1,U.hash_bits=x+7,U.hash_size=1<<U.hash_bits,U.hash_mask=U.hash_size-1,U.hash_shift=~~((U.hash_bits+R-1)/R),U.window=new l.Buf8(2*U.w_size),U.head=new l.Buf16(U.hash_size),U.prev=new l.Buf16(U.w_size),U.lit_bufsize=1<<x+6,U.pending_buf_size=4*U.lit_bufsize,U.pending_buf=new l.Buf8(U.pending_buf_size),U.d_buf=1*U.lit_bufsize,U.l_buf=3*U.lit_bufsize,U.level=K,U.strategy=M,U.method=H,O(v)}s=[new q(0,0,0,0,function(v,K){var H=65535;for(H>v.pending_buf_size-5&&(H=v.pending_buf_size-5);;){if(v.lookahead<=1){if(pe(v),v.lookahead===0&&K===p)return y;if(v.lookahead===0)break}v.strstart+=v.lookahead,v.lookahead=0;var $=v.block_start+H;if((v.strstart===0||v.strstart>=$)&&(v.lookahead=v.strstart-$,v.strstart=$,G(v,!1),v.strm.avail_out===0)||v.strstart-v.block_start>=v.w_size-V&&(G(v,!1),v.strm.avail_out===0))return y}return v.insert=0,K===b?(G(v,!0),v.strm.avail_out===0?F:E):(v.strstart>v.block_start&&(G(v,!1),v.strm.avail_out),y)}),new q(4,4,8,4,Te),new q(4,5,16,8,Te),new q(4,6,32,32,Te),new q(4,4,16,16,be),new q(8,16,32,32,be),new q(8,16,128,128,be),new q(8,32,128,256,be),new q(32,128,258,1024,be),new q(32,258,258,4096,be)],o.deflateInit=function(v,K){return W(v,K,S,15,8,0)},o.deflateInit2=W,o.deflateReset=O,o.deflateResetKeep=ve,o.deflateSetHeader=function(v,K){return v&&v.state?v.state.wrap!==2?h:(v.state.gzhead=K,u):h},o.deflate=function(v,K){var H,$,x,M;if(!v||!v.state||5<K||K<0)return v?D(v,h):h;if($=v.state,!v.output||!v.input&&v.avail_in!==0||$.status===666&&K!==b)return D(v,v.avail_out===0?-5:h);if($.strm=v,H=$.last_flush,$.last_flush=K,$.status===_)if($.wrap===2)v.adler=0,ne($,31),ne($,139),ne($,8),$.gzhead?(ne($,($.gzhead.text?1:0)+($.gzhead.hcrc?2:0)+($.gzhead.extra?4:0)+($.gzhead.name?8:0)+($.gzhead.comment?16:0)),ne($,255&$.gzhead.time),ne($,$.gzhead.time>>8&255),ne($,$.gzhead.time>>16&255),ne($,$.gzhead.time>>24&255),ne($,$.level===9?2:2<=$.strategy||$.level<2?4:0),ne($,255&$.gzhead.os),$.gzhead.extra&&$.gzhead.extra.length&&(ne($,255&$.gzhead.extra.length),ne($,$.gzhead.extra.length>>8&255)),$.gzhead.hcrc&&(v.adler=c(v.adler,$.pending_buf,$.pending,0)),$.gzindex=0,$.status=69):(ne($,0),ne($,0),ne($,0),ne($,0),ne($,0),ne($,$.level===9?2:2<=$.strategy||$.level<2?4:0),ne($,3),$.status=L);else{var Y=S+($.w_bits-8<<4)<<8;Y|=(2<=$.strategy||$.level<2?0:$.level<6?1:$.level===6?2:3)<<6,$.strstart!==0&&(Y|=32),Y+=31-Y%31,$.status=L,se($,Y),$.strstart!==0&&(se($,v.adler>>>16),se($,65535&v.adler)),v.adler=1}if($.status===69)if($.gzhead.extra){for(x=$.pending;$.gzindex<(65535&$.gzhead.extra.length)&&($.pending!==$.pending_buf_size||($.gzhead.hcrc&&$.pending>x&&(v.adler=c(v.adler,$.pending_buf,$.pending-x,x)),j(v),x=$.pending,$.pending!==$.pending_buf_size));)ne($,255&$.gzhead.extra[$.gzindex]),$.gzindex++;$.gzhead.hcrc&&$.pending>x&&(v.adler=c(v.adler,$.pending_buf,$.pending-x,x)),$.gzindex===$.gzhead.extra.length&&($.gzindex=0,$.status=73)}else $.status=73;if($.status===73)if($.gzhead.name){x=$.pending;do{if($.pending===$.pending_buf_size&&($.gzhead.hcrc&&$.pending>x&&(v.adler=c(v.adler,$.pending_buf,$.pending-x,x)),j(v),x=$.pending,$.pending===$.pending_buf_size)){M=1;break}M=$.gzindex<$.gzhead.name.length?255&$.gzhead.name.charCodeAt($.gzindex++):0,ne($,M)}while(M!==0);$.gzhead.hcrc&&$.pending>x&&(v.adler=c(v.adler,$.pending_buf,$.pending-x,x)),M===0&&($.gzindex=0,$.status=91)}else $.status=91;if($.status===91)if($.gzhead.comment){x=$.pending;do{if($.pending===$.pending_buf_size&&($.gzhead.hcrc&&$.pending>x&&(v.adler=c(v.adler,$.pending_buf,$.pending-x,x)),j(v),x=$.pending,$.pending===$.pending_buf_size)){M=1;break}M=$.gzindex<$.gzhead.comment.length?255&$.gzhead.comment.charCodeAt($.gzindex++):0,ne($,M)}while(M!==0);$.gzhead.hcrc&&$.pending>x&&(v.adler=c(v.adler,$.pending_buf,$.pending-x,x)),M===0&&($.status=103)}else $.status=103;if($.status===103&&($.gzhead.hcrc?($.pending+2>$.pending_buf_size&&j(v),$.pending+2<=$.pending_buf_size&&(ne($,255&v.adler),ne($,v.adler>>8&255),v.adler=0,$.status=L)):$.status=L),$.pending!==0){if(j(v),v.avail_out===0)return $.last_flush=-1,u}else if(v.avail_in===0&&N(K)<=N(H)&&K!==b)return D(v,-5);if($.status===666&&v.avail_in!==0)return D(v,-5);if(v.avail_in!==0||$.lookahead!==0||K!==p&&$.status!==666){var U=$.strategy===2?(function(Z,Q){for(var oe;;){if(Z.lookahead===0&&(pe(Z),Z.lookahead===0)){if(Q===p)return y;break}if(Z.match_length=0,oe=r._tr_tally(Z,0,Z.window[Z.strstart]),Z.lookahead--,Z.strstart++,oe&&(G(Z,!1),Z.strm.avail_out===0))return y}return Z.insert=0,Q===b?(G(Z,!0),Z.strm.avail_out===0?F:E):Z.last_lit&&(G(Z,!1),Z.strm.avail_out===0)?y:A})($,K):$.strategy===3?(function(Z,Q){for(var oe,ie,de,Se,ke=Z.window;;){if(Z.lookahead<=z){if(pe(Z),Z.lookahead<=z&&Q===p)return y;if(Z.lookahead===0)break}if(Z.match_length=0,Z.lookahead>=R&&0<Z.strstart&&(ie=ke[de=Z.strstart-1])===ke[++de]&&ie===ke[++de]&&ie===ke[++de]){Se=Z.strstart+z;do;while(ie===ke[++de]&&ie===ke[++de]&&ie===ke[++de]&&ie===ke[++de]&&ie===ke[++de]&&ie===ke[++de]&&ie===ke[++de]&&ie===ke[++de]&&de<Se);Z.match_length=z-(Se-de),Z.match_length>Z.lookahead&&(Z.match_length=Z.lookahead)}if(Z.match_length>=R?(oe=r._tr_tally(Z,1,Z.match_length-R),Z.lookahead-=Z.match_length,Z.strstart+=Z.match_length,Z.match_length=0):(oe=r._tr_tally(Z,0,Z.window[Z.strstart]),Z.lookahead--,Z.strstart++),oe&&(G(Z,!1),Z.strm.avail_out===0))return y}return Z.insert=0,Q===b?(G(Z,!0),Z.strm.avail_out===0?F:E):Z.last_lit&&(G(Z,!1),Z.strm.avail_out===0)?y:A})($,K):s[$.level].func($,K);if(U!==F&&U!==E||($.status=666),U===y||U===F)return v.avail_out===0&&($.last_flush=-1),u;if(U===A&&(K===1?r._tr_align($):K!==5&&(r._tr_stored_block($,0,0,!1),K===3&&(X($.head),$.lookahead===0&&($.strstart=0,$.block_start=0,$.insert=0))),j(v),v.avail_out===0))return $.last_flush=-1,u}return K!==b?u:$.wrap<=0?1:($.wrap===2?(ne($,255&v.adler),ne($,v.adler>>8&255),ne($,v.adler>>16&255),ne($,v.adler>>24&255),ne($,255&v.total_in),ne($,v.total_in>>8&255),ne($,v.total_in>>16&255),ne($,v.total_in>>24&255)):(se($,v.adler>>>16),se($,65535&v.adler)),j(v),0<$.wrap&&($.wrap=-$.wrap),$.pending!==0?u:1)},o.deflateEnd=function(v){var K;return v&&v.state?(K=v.state.status)!==_&&K!==69&&K!==73&&K!==91&&K!==103&&K!==L&&K!==666?D(v,h):(v.state=null,K===L?D(v,-3):u):h},o.deflateSetDictionary=function(v,K){var H,$,x,M,Y,U,Z,Q,oe=K.length;if(!v||!v.state||(M=(H=v.state).wrap)===2||M===1&&H.status!==_||H.lookahead)return h;for(M===1&&(v.adler=a(v.adler,K,oe,0)),H.wrap=0,oe>=H.w_size&&(M===0&&(X(H.head),H.strstart=0,H.block_start=0,H.insert=0),Q=new l.Buf8(H.w_size),l.arraySet(Q,K,oe-H.w_size,H.w_size,0),K=Q,oe=H.w_size),Y=v.avail_in,U=v.next_in,Z=v.input,v.avail_in=oe,v.next_in=0,v.input=K,pe(H);H.lookahead>=R;){for($=H.strstart,x=H.lookahead-(R-1);H.ins_h=(H.ins_h<<H.hash_shift^H.window[$+R-1])&H.hash_mask,H.prev[$&H.w_mask]=H.head[H.ins_h],H.head[H.ins_h]=$,$++,--x;);H.strstart=$,H.lookahead=R-1,pe(H)}return H.strstart+=H.lookahead,H.block_start=H.strstart,H.insert=H.lookahead,H.lookahead=0,H.match_length=H.prev_length=R-1,H.match_available=0,v.next_in=U,v.input=Z,v.avail_in=Y,H.wrap=M,u},o.deflateInfo="pako deflate (from Nodeca project)"},{"../utils/common":41,"./adler32":43,"./crc32":45,"./messages":51,"./trees":52}],47:[function(i,n,o){n.exports=function(){this.text=0,this.time=0,this.xflags=0,this.os=0,this.extra=null,this.extra_len=0,this.name="",this.comment="",this.hcrc=0,this.done=!1}},{}],48:[function(i,n,o){n.exports=function(s,l){var r,a,c,d,p,b,u,h,f,g,k,S,C,T,B,I,w,P,R,z,V,_,L,y,A;r=s.state,a=s.next_in,y=s.input,c=a+(s.avail_in-5),d=s.next_out,A=s.output,p=d-(l-s.avail_out),b=d+(s.avail_out-257),u=r.dmax,h=r.wsize,f=r.whave,g=r.wnext,k=r.window,S=r.hold,C=r.bits,T=r.lencode,B=r.distcode,I=(1<<r.lenbits)-1,w=(1<<r.distbits)-1;e:do{C<15&&(S+=y[a++]<<C,C+=8,S+=y[a++]<<C,C+=8),P=T[S&I];t:for(;;){if(S>>>=R=P>>>24,C-=R,(R=P>>>16&255)===0)A[d++]=65535&P;else{if(!(16&R)){if((64&R)==0){P=T[(65535&P)+(S&(1<<R)-1)];continue t}if(32&R){r.mode=12;break e}s.msg="invalid literal/length code",r.mode=30;break e}z=65535&P,(R&=15)&&(C<R&&(S+=y[a++]<<C,C+=8),z+=S&(1<<R)-1,S>>>=R,C-=R),C<15&&(S+=y[a++]<<C,C+=8,S+=y[a++]<<C,C+=8),P=B[S&w];i:for(;;){if(S>>>=R=P>>>24,C-=R,!(16&(R=P>>>16&255))){if((64&R)==0){P=B[(65535&P)+(S&(1<<R)-1)];continue i}s.msg="invalid distance code",r.mode=30;break e}if(V=65535&P,C<(R&=15)&&(S+=y[a++]<<C,(C+=8)<R&&(S+=y[a++]<<C,C+=8)),u<(V+=S&(1<<R)-1)){s.msg="invalid distance too far back",r.mode=30;break e}if(S>>>=R,C-=R,(R=d-p)<V){if(f<(R=V-R)&&r.sane){s.msg="invalid distance too far back",r.mode=30;break e}if(L=k,(_=0)===g){if(_+=h-R,R<z){for(z-=R;A[d++]=k[_++],--R;);_=d-V,L=A}}else if(g<R){if(_+=h+g-R,(R-=g)<z){for(z-=R;A[d++]=k[_++],--R;);if(_=0,g<z){for(z-=R=g;A[d++]=k[_++],--R;);_=d-V,L=A}}}else if(_+=g-R,R<z){for(z-=R;A[d++]=k[_++],--R;);_=d-V,L=A}for(;2<z;)A[d++]=L[_++],A[d++]=L[_++],A[d++]=L[_++],z-=3;z&&(A[d++]=L[_++],1<z&&(A[d++]=L[_++]))}else{for(_=d-V;A[d++]=A[_++],A[d++]=A[_++],A[d++]=A[_++],2<(z-=3););z&&(A[d++]=A[_++],1<z&&(A[d++]=A[_++]))}break}}break}}while(a<c&&d<b);a-=z=C>>3,S&=(1<<(C-=z<<3))-1,s.next_in=a,s.next_out=d,s.avail_in=a<c?c-a+5:5-(a-c),s.avail_out=d<b?b-d+257:257-(d-b),r.hold=S,r.bits=C}},{}],49:[function(i,n,o){var s=i("../utils/common"),l=i("./adler32"),r=i("./crc32"),a=i("./inffast"),c=i("./inftrees"),d=1,p=2,b=0,u=-2,h=1,f=852,g=592;function k(_){return(_>>>24&255)+(_>>>8&65280)+((65280&_)<<8)+((255&_)<<24)}function S(){this.mode=0,this.last=!1,this.wrap=0,this.havedict=!1,this.flags=0,this.dmax=0,this.check=0,this.total=0,this.head=null,this.wbits=0,this.wsize=0,this.whave=0,this.wnext=0,this.window=null,this.hold=0,this.bits=0,this.length=0,this.offset=0,this.extra=0,this.lencode=null,this.distcode=null,this.lenbits=0,this.distbits=0,this.ncode=0,this.nlen=0,this.ndist=0,this.have=0,this.next=null,this.lens=new s.Buf16(320),this.work=new s.Buf16(288),this.lendyn=null,this.distdyn=null,this.sane=0,this.back=0,this.was=0}function C(_){var L;return _&&_.state?(L=_.state,_.total_in=_.total_out=L.total=0,_.msg="",L.wrap&&(_.adler=1&L.wrap),L.mode=h,L.last=0,L.havedict=0,L.dmax=32768,L.head=null,L.hold=0,L.bits=0,L.lencode=L.lendyn=new s.Buf32(f),L.distcode=L.distdyn=new s.Buf32(g),L.sane=1,L.back=-1,b):u}function T(_){var L;return _&&_.state?((L=_.state).wsize=0,L.whave=0,L.wnext=0,C(_)):u}function B(_,L){var y,A;return _&&_.state?(A=_.state,L<0?(y=0,L=-L):(y=1+(L>>4),L<48&&(L&=15)),L&&(L<8||15<L)?u:(A.window!==null&&A.wbits!==L&&(A.window=null),A.wrap=y,A.wbits=L,T(_))):u}function I(_,L){var y,A;return _?(A=new S,(_.state=A).window=null,(y=B(_,L))!==b&&(_.state=null),y):u}var w,P,R=!0;function z(_){if(R){var L;for(w=new s.Buf32(512),P=new s.Buf32(32),L=0;L<144;)_.lens[L++]=8;for(;L<256;)_.lens[L++]=9;for(;L<280;)_.lens[L++]=7;for(;L<288;)_.lens[L++]=8;for(c(d,_.lens,0,288,w,0,_.work,{bits:9}),L=0;L<32;)_.lens[L++]=5;c(p,_.lens,0,32,P,0,_.work,{bits:5}),R=!1}_.lencode=w,_.lenbits=9,_.distcode=P,_.distbits=5}function V(_,L,y,A){var F,E=_.state;return E.window===null&&(E.wsize=1<<E.wbits,E.wnext=0,E.whave=0,E.window=new s.Buf8(E.wsize)),A>=E.wsize?(s.arraySet(E.window,L,y-E.wsize,E.wsize,0),E.wnext=0,E.whave=E.wsize):(A<(F=E.wsize-E.wnext)&&(F=A),s.arraySet(E.window,L,y-A,F,E.wnext),(A-=F)?(s.arraySet(E.window,L,y-A,A,0),E.wnext=A,E.whave=E.wsize):(E.wnext+=F,E.wnext===E.wsize&&(E.wnext=0),E.whave<E.wsize&&(E.whave+=F))),0}o.inflateReset=T,o.inflateReset2=B,o.inflateResetKeep=C,o.inflateInit=function(_){return I(_,15)},o.inflateInit2=I,o.inflate=function(_,L){var y,A,F,E,D,N,X,j,G,ne,se,le,pe,Te,be,q,ae,ve,O,W,v,K,H,$,x=0,M=new s.Buf8(4),Y=[16,17,18,0,8,7,9,6,10,5,11,4,12,3,13,2,14,1,15];if(!_||!_.state||!_.output||!_.input&&_.avail_in!==0)return u;(y=_.state).mode===12&&(y.mode=13),D=_.next_out,F=_.output,X=_.avail_out,E=_.next_in,A=_.input,N=_.avail_in,j=y.hold,G=y.bits,ne=N,se=X,K=b;e:for(;;)switch(y.mode){case h:if(y.wrap===0){y.mode=13;break}for(;G<16;){if(N===0)break e;N--,j+=A[E++]<<G,G+=8}if(2&y.wrap&&j===35615){M[y.check=0]=255&j,M[1]=j>>>8&255,y.check=r(y.check,M,2,0),G=j=0,y.mode=2;break}if(y.flags=0,y.head&&(y.head.done=!1),!(1&y.wrap)||(((255&j)<<8)+(j>>8))%31){_.msg="incorrect header check",y.mode=30;break}if((15&j)!=8){_.msg="unknown compression method",y.mode=30;break}if(G-=4,v=8+(15&(j>>>=4)),y.wbits===0)y.wbits=v;else if(v>y.wbits){_.msg="invalid window size",y.mode=30;break}y.dmax=1<<v,_.adler=y.check=1,y.mode=512&j?10:12,G=j=0;break;case 2:for(;G<16;){if(N===0)break e;N--,j+=A[E++]<<G,G+=8}if(y.flags=j,(255&y.flags)!=8){_.msg="unknown compression method",y.mode=30;break}if(57344&y.flags){_.msg="unknown header flags set",y.mode=30;break}y.head&&(y.head.text=j>>8&1),512&y.flags&&(M[0]=255&j,M[1]=j>>>8&255,y.check=r(y.check,M,2,0)),G=j=0,y.mode=3;case 3:for(;G<32;){if(N===0)break e;N--,j+=A[E++]<<G,G+=8}y.head&&(y.head.time=j),512&y.flags&&(M[0]=255&j,M[1]=j>>>8&255,M[2]=j>>>16&255,M[3]=j>>>24&255,y.check=r(y.check,M,4,0)),G=j=0,y.mode=4;case 4:for(;G<16;){if(N===0)break e;N--,j+=A[E++]<<G,G+=8}y.head&&(y.head.xflags=255&j,y.head.os=j>>8),512&y.flags&&(M[0]=255&j,M[1]=j>>>8&255,y.check=r(y.check,M,2,0)),G=j=0,y.mode=5;case 5:if(1024&y.flags){for(;G<16;){if(N===0)break e;N--,j+=A[E++]<<G,G+=8}y.length=j,y.head&&(y.head.extra_len=j),512&y.flags&&(M[0]=255&j,M[1]=j>>>8&255,y.check=r(y.check,M,2,0)),G=j=0}else y.head&&(y.head.extra=null);y.mode=6;case 6:if(1024&y.flags&&(N<(le=y.length)&&(le=N),le&&(y.head&&(v=y.head.extra_len-y.length,y.head.extra||(y.head.extra=new Array(y.head.extra_len)),s.arraySet(y.head.extra,A,E,le,v)),512&y.flags&&(y.check=r(y.check,A,le,E)),N-=le,E+=le,y.length-=le),y.length))break e;y.length=0,y.mode=7;case 7:if(2048&y.flags){if(N===0)break e;for(le=0;v=A[E+le++],y.head&&v&&y.length<65536&&(y.head.name+=String.fromCharCode(v)),v&&le<N;);if(512&y.flags&&(y.check=r(y.check,A,le,E)),N-=le,E+=le,v)break e}else y.head&&(y.head.name=null);y.length=0,y.mode=8;case 8:if(4096&y.flags){if(N===0)break e;for(le=0;v=A[E+le++],y.head&&v&&y.length<65536&&(y.head.comment+=String.fromCharCode(v)),v&&le<N;);if(512&y.flags&&(y.check=r(y.check,A,le,E)),N-=le,E+=le,v)break e}else y.head&&(y.head.comment=null);y.mode=9;case 9:if(512&y.flags){for(;G<16;){if(N===0)break e;N--,j+=A[E++]<<G,G+=8}if(j!==(65535&y.check)){_.msg="header crc mismatch",y.mode=30;break}G=j=0}y.head&&(y.head.hcrc=y.flags>>9&1,y.head.done=!0),_.adler=y.check=0,y.mode=12;break;case 10:for(;G<32;){if(N===0)break e;N--,j+=A[E++]<<G,G+=8}_.adler=y.check=k(j),G=j=0,y.mode=11;case 11:if(y.havedict===0)return _.next_out=D,_.avail_out=X,_.next_in=E,_.avail_in=N,y.hold=j,y.bits=G,2;_.adler=y.check=1,y.mode=12;case 12:if(L===5||L===6)break e;case 13:if(y.last){j>>>=7&G,G-=7&G,y.mode=27;break}for(;G<3;){if(N===0)break e;N--,j+=A[E++]<<G,G+=8}switch(y.last=1&j,G-=1,3&(j>>>=1)){case 0:y.mode=14;break;case 1:if(z(y),y.mode=20,L!==6)break;j>>>=2,G-=2;break e;case 2:y.mode=17;break;case 3:_.msg="invalid block type",y.mode=30}j>>>=2,G-=2;break;case 14:for(j>>>=7&G,G-=7&G;G<32;){if(N===0)break e;N--,j+=A[E++]<<G,G+=8}if((65535&j)!=(j>>>16^65535)){_.msg="invalid stored block lengths",y.mode=30;break}if(y.length=65535&j,G=j=0,y.mode=15,L===6)break e;case 15:y.mode=16;case 16:if(le=y.length){if(N<le&&(le=N),X<le&&(le=X),le===0)break e;s.arraySet(F,A,E,le,D),N-=le,E+=le,X-=le,D+=le,y.length-=le;break}y.mode=12;break;case 17:for(;G<14;){if(N===0)break e;N--,j+=A[E++]<<G,G+=8}if(y.nlen=257+(31&j),j>>>=5,G-=5,y.ndist=1+(31&j),j>>>=5,G-=5,y.ncode=4+(15&j),j>>>=4,G-=4,286<y.nlen||30<y.ndist){_.msg="too many length or distance symbols",y.mode=30;break}y.have=0,y.mode=18;case 18:for(;y.have<y.ncode;){for(;G<3;){if(N===0)break e;N--,j+=A[E++]<<G,G+=8}y.lens[Y[y.have++]]=7&j,j>>>=3,G-=3}for(;y.have<19;)y.lens[Y[y.have++]]=0;if(y.lencode=y.lendyn,y.lenbits=7,H={bits:y.lenbits},K=c(0,y.lens,0,19,y.lencode,0,y.work,H),y.lenbits=H.bits,K){_.msg="invalid code lengths set",y.mode=30;break}y.have=0,y.mode=19;case 19:for(;y.have<y.nlen+y.ndist;){for(;q=(x=y.lencode[j&(1<<y.lenbits)-1])>>>16&255,ae=65535&x,!((be=x>>>24)<=G);){if(N===0)break e;N--,j+=A[E++]<<G,G+=8}if(ae<16)j>>>=be,G-=be,y.lens[y.have++]=ae;else{if(ae===16){for($=be+2;G<$;){if(N===0)break e;N--,j+=A[E++]<<G,G+=8}if(j>>>=be,G-=be,y.have===0){_.msg="invalid bit length repeat",y.mode=30;break}v=y.lens[y.have-1],le=3+(3&j),j>>>=2,G-=2}else if(ae===17){for($=be+3;G<$;){if(N===0)break e;N--,j+=A[E++]<<G,G+=8}G-=be,v=0,le=3+(7&(j>>>=be)),j>>>=3,G-=3}else{for($=be+7;G<$;){if(N===0)break e;N--,j+=A[E++]<<G,G+=8}G-=be,v=0,le=11+(127&(j>>>=be)),j>>>=7,G-=7}if(y.have+le>y.nlen+y.ndist){_.msg="invalid bit length repeat",y.mode=30;break}for(;le--;)y.lens[y.have++]=v}}if(y.mode===30)break;if(y.lens[256]===0){_.msg="invalid code -- missing end-of-block",y.mode=30;break}if(y.lenbits=9,H={bits:y.lenbits},K=c(d,y.lens,0,y.nlen,y.lencode,0,y.work,H),y.lenbits=H.bits,K){_.msg="invalid literal/lengths set",y.mode=30;break}if(y.distbits=6,y.distcode=y.distdyn,H={bits:y.distbits},K=c(p,y.lens,y.nlen,y.ndist,y.distcode,0,y.work,H),y.distbits=H.bits,K){_.msg="invalid distances set",y.mode=30;break}if(y.mode=20,L===6)break e;case 20:y.mode=21;case 21:if(6<=N&&258<=X){_.next_out=D,_.avail_out=X,_.next_in=E,_.avail_in=N,y.hold=j,y.bits=G,a(_,se),D=_.next_out,F=_.output,X=_.avail_out,E=_.next_in,A=_.input,N=_.avail_in,j=y.hold,G=y.bits,y.mode===12&&(y.back=-1);break}for(y.back=0;q=(x=y.lencode[j&(1<<y.lenbits)-1])>>>16&255,ae=65535&x,!((be=x>>>24)<=G);){if(N===0)break e;N--,j+=A[E++]<<G,G+=8}if(q&&(240&q)==0){for(ve=be,O=q,W=ae;q=(x=y.lencode[W+((j&(1<<ve+O)-1)>>ve)])>>>16&255,ae=65535&x,!(ve+(be=x>>>24)<=G);){if(N===0)break e;N--,j+=A[E++]<<G,G+=8}j>>>=ve,G-=ve,y.back+=ve}if(j>>>=be,G-=be,y.back+=be,y.length=ae,q===0){y.mode=26;break}if(32&q){y.back=-1,y.mode=12;break}if(64&q){_.msg="invalid literal/length code",y.mode=30;break}y.extra=15&q,y.mode=22;case 22:if(y.extra){for($=y.extra;G<$;){if(N===0)break e;N--,j+=A[E++]<<G,G+=8}y.length+=j&(1<<y.extra)-1,j>>>=y.extra,G-=y.extra,y.back+=y.extra}y.was=y.length,y.mode=23;case 23:for(;q=(x=y.distcode[j&(1<<y.distbits)-1])>>>16&255,ae=65535&x,!((be=x>>>24)<=G);){if(N===0)break e;N--,j+=A[E++]<<G,G+=8}if((240&q)==0){for(ve=be,O=q,W=ae;q=(x=y.distcode[W+((j&(1<<ve+O)-1)>>ve)])>>>16&255,ae=65535&x,!(ve+(be=x>>>24)<=G);){if(N===0)break e;N--,j+=A[E++]<<G,G+=8}j>>>=ve,G-=ve,y.back+=ve}if(j>>>=be,G-=be,y.back+=be,64&q){_.msg="invalid distance code",y.mode=30;break}y.offset=ae,y.extra=15&q,y.mode=24;case 24:if(y.extra){for($=y.extra;G<$;){if(N===0)break e;N--,j+=A[E++]<<G,G+=8}y.offset+=j&(1<<y.extra)-1,j>>>=y.extra,G-=y.extra,y.back+=y.extra}if(y.offset>y.dmax){_.msg="invalid distance too far back",y.mode=30;break}y.mode=25;case 25:if(X===0)break e;if(le=se-X,y.offset>le){if((le=y.offset-le)>y.whave&&y.sane){_.msg="invalid distance too far back",y.mode=30;break}pe=le>y.wnext?(le-=y.wnext,y.wsize-le):y.wnext-le,le>y.length&&(le=y.length),Te=y.window}else Te=F,pe=D-y.offset,le=y.length;for(X<le&&(le=X),X-=le,y.length-=le;F[D++]=Te[pe++],--le;);y.length===0&&(y.mode=21);break;case 26:if(X===0)break e;F[D++]=y.length,X--,y.mode=21;break;case 27:if(y.wrap){for(;G<32;){if(N===0)break e;N--,j|=A[E++]<<G,G+=8}if(se-=X,_.total_out+=se,y.total+=se,se&&(_.adler=y.check=y.flags?r(y.check,F,se,D-se):l(y.check,F,se,D-se)),se=X,(y.flags?j:k(j))!==y.check){_.msg="incorrect data check",y.mode=30;break}G=j=0}y.mode=28;case 28:if(y.wrap&&y.flags){for(;G<32;){if(N===0)break e;N--,j+=A[E++]<<G,G+=8}if(j!==(4294967295&y.total)){_.msg="incorrect length check",y.mode=30;break}G=j=0}y.mode=29;case 29:K=1;break e;case 30:K=-3;break e;case 31:return-4;case 32:default:return u}return _.next_out=D,_.avail_out=X,_.next_in=E,_.avail_in=N,y.hold=j,y.bits=G,(y.wsize||se!==_.avail_out&&y.mode<30&&(y.mode<27||L!==4))&&V(_,_.output,_.next_out,se-_.avail_out)?(y.mode=31,-4):(ne-=_.avail_in,se-=_.avail_out,_.total_in+=ne,_.total_out+=se,y.total+=se,y.wrap&&se&&(_.adler=y.check=y.flags?r(y.check,F,se,_.next_out-se):l(y.check,F,se,_.next_out-se)),_.data_type=y.bits+(y.last?64:0)+(y.mode===12?128:0)+(y.mode===20||y.mode===15?256:0),(ne==0&&se===0||L===4)&&K===b&&(K=-5),K)},o.inflateEnd=function(_){if(!_||!_.state)return u;var L=_.state;return L.window&&(L.window=null),_.state=null,b},o.inflateGetHeader=function(_,L){var y;return _&&_.state?(2&(y=_.state).wrap)==0?u:((y.head=L).done=!1,b):u},o.inflateSetDictionary=function(_,L){var y,A=L.length;return _&&_.state?(y=_.state).wrap!==0&&y.mode!==11?u:y.mode===11&&l(1,L,A,0)!==y.check?-3:V(_,L,A,A)?(y.mode=31,-4):(y.havedict=1,b):u},o.inflateInfo="pako inflate (from Nodeca project)"},{"../utils/common":41,"./adler32":43,"./crc32":45,"./inffast":48,"./inftrees":50}],50:[function(i,n,o){var s=i("../utils/common"),l=[3,4,5,6,7,8,9,10,11,13,15,17,19,23,27,31,35,43,51,59,67,83,99,115,131,163,195,227,258,0,0],r=[16,16,16,16,16,16,16,16,17,17,17,17,18,18,18,18,19,19,19,19,20,20,20,20,21,21,21,21,16,72,78],a=[1,2,3,4,5,7,9,13,17,25,33,49,65,97,129,193,257,385,513,769,1025,1537,2049,3073,4097,6145,8193,12289,16385,24577,0,0],c=[16,16,16,16,17,17,18,18,19,19,20,20,21,21,22,22,23,23,24,24,25,25,26,26,27,27,28,28,29,29,64,64];n.exports=function(d,p,b,u,h,f,g,k){var S,C,T,B,I,w,P,R,z,V=k.bits,_=0,L=0,y=0,A=0,F=0,E=0,D=0,N=0,X=0,j=0,G=null,ne=0,se=new s.Buf16(16),le=new s.Buf16(16),pe=null,Te=0;for(_=0;_<=15;_++)se[_]=0;for(L=0;L<u;L++)se[p[b+L]]++;for(F=V,A=15;1<=A&&se[A]===0;A--);if(A<F&&(F=A),A===0)return h[f++]=20971520,h[f++]=20971520,k.bits=1,0;for(y=1;y<A&&se[y]===0;y++);for(F<y&&(F=y),_=N=1;_<=15;_++)if(N<<=1,(N-=se[_])<0)return-1;if(0<N&&(d===0||A!==1))return-1;for(le[1]=0,_=1;_<15;_++)le[_+1]=le[_]+se[_];for(L=0;L<u;L++)p[b+L]!==0&&(g[le[p[b+L]]++]=L);if(w=d===0?(G=pe=g,19):d===1?(G=l,ne-=257,pe=r,Te-=257,256):(G=a,pe=c,-1),_=y,I=f,D=L=j=0,T=-1,B=(X=1<<(E=F))-1,d===1&&852<X||d===2&&592<X)return 1;for(;;){for(P=_-D,z=g[L]<w?(R=0,g[L]):g[L]>w?(R=pe[Te+g[L]],G[ne+g[L]]):(R=96,0),S=1<<_-D,y=C=1<<E;h[I+(j>>D)+(C-=S)]=P<<24|R<<16|z|0,C!==0;);for(S=1<<_-1;j&S;)S>>=1;if(S!==0?(j&=S-1,j+=S):j=0,L++,--se[_]==0){if(_===A)break;_=p[b+g[L]]}if(F<_&&(j&B)!==T){for(D===0&&(D=F),I+=y,N=1<<(E=_-D);E+D<A&&!((N-=se[E+D])<=0);)E++,N<<=1;if(X+=1<<E,d===1&&852<X||d===2&&592<X)return 1;h[T=j&B]=F<<24|E<<16|I-f|0}}return j!==0&&(h[I+j]=_-D<<24|64<<16|0),k.bits=F,0}},{"../utils/common":41}],51:[function(i,n,o){n.exports={2:"need dictionary",1:"stream end",0:"","-1":"file error","-2":"stream error","-3":"data error","-4":"insufficient memory","-5":"buffer error","-6":"incompatible version"}},{}],52:[function(i,n,o){var s=i("../utils/common"),l=0,r=1;function a(x){for(var M=x.length;0<=--M;)x[M]=0}var c=0,d=29,p=256,b=p+1+d,u=30,h=19,f=2*b+1,g=15,k=16,S=7,C=256,T=16,B=17,I=18,w=[0,0,0,0,0,0,0,0,1,1,1,1,2,2,2,2,3,3,3,3,4,4,4,4,5,5,5,5,0],P=[0,0,0,0,1,1,2,2,3,3,4,4,5,5,6,6,7,7,8,8,9,9,10,10,11,11,12,12,13,13],R=[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,2,3,7],z=[16,17,18,0,8,7,9,6,10,5,11,4,12,3,13,2,14,1,15],V=new Array(2*(b+2));a(V);var _=new Array(2*u);a(_);var L=new Array(512);a(L);var y=new Array(256);a(y);var A=new Array(d);a(A);var F,E,D,N=new Array(u);function X(x,M,Y,U,Z){this.static_tree=x,this.extra_bits=M,this.extra_base=Y,this.elems=U,this.max_length=Z,this.has_stree=x&&x.length}function j(x,M){this.dyn_tree=x,this.max_code=0,this.stat_desc=M}function G(x){return x<256?L[x]:L[256+(x>>>7)]}function ne(x,M){x.pending_buf[x.pending++]=255&M,x.pending_buf[x.pending++]=M>>>8&255}function se(x,M,Y){x.bi_valid>k-Y?(x.bi_buf|=M<<x.bi_valid&65535,ne(x,x.bi_buf),x.bi_buf=M>>k-x.bi_valid,x.bi_valid+=Y-k):(x.bi_buf|=M<<x.bi_valid&65535,x.bi_valid+=Y)}function le(x,M,Y){se(x,Y[2*M],Y[2*M+1])}function pe(x,M){for(var Y=0;Y|=1&x,x>>>=1,Y<<=1,0<--M;);return Y>>>1}function Te(x,M,Y){var U,Z,Q=new Array(g+1),oe=0;for(U=1;U<=g;U++)Q[U]=oe=oe+Y[U-1]<<1;for(Z=0;Z<=M;Z++){var ie=x[2*Z+1];ie!==0&&(x[2*Z]=pe(Q[ie]++,ie))}}function be(x){var M;for(M=0;M<b;M++)x.dyn_ltree[2*M]=0;for(M=0;M<u;M++)x.dyn_dtree[2*M]=0;for(M=0;M<h;M++)x.bl_tree[2*M]=0;x.dyn_ltree[2*C]=1,x.opt_len=x.static_len=0,x.last_lit=x.matches=0}function q(x){8<x.bi_valid?ne(x,x.bi_buf):0<x.bi_valid&&(x.pending_buf[x.pending++]=x.bi_buf),x.bi_buf=0,x.bi_valid=0}function ae(x,M,Y,U){var Z=2*M,Q=2*Y;return x[Z]<x[Q]||x[Z]===x[Q]&&U[M]<=U[Y]}function ve(x,M,Y){for(var U=x.heap[Y],Z=Y<<1;Z<=x.heap_len&&(Z<x.heap_len&&ae(M,x.heap[Z+1],x.heap[Z],x.depth)&&Z++,!ae(M,U,x.heap[Z],x.depth));)x.heap[Y]=x.heap[Z],Y=Z,Z<<=1;x.heap[Y]=U}function O(x,M,Y){var U,Z,Q,oe,ie=0;if(x.last_lit!==0)for(;U=x.pending_buf[x.d_buf+2*ie]<<8|x.pending_buf[x.d_buf+2*ie+1],Z=x.pending_buf[x.l_buf+ie],ie++,U===0?le(x,Z,M):(le(x,(Q=y[Z])+p+1,M),(oe=w[Q])!==0&&se(x,Z-=A[Q],oe),le(x,Q=G(--U),Y),(oe=P[Q])!==0&&se(x,U-=N[Q],oe)),ie<x.last_lit;);le(x,C,M)}function W(x,M){var Y,U,Z,Q=M.dyn_tree,oe=M.stat_desc.static_tree,ie=M.stat_desc.has_stree,de=M.stat_desc.elems,Se=-1;for(x.heap_len=0,x.heap_max=f,Y=0;Y<de;Y++)Q[2*Y]!==0?(x.heap[++x.heap_len]=Se=Y,x.depth[Y]=0):Q[2*Y+1]=0;for(;x.heap_len<2;)Q[2*(Z=x.heap[++x.heap_len]=Se<2?++Se:0)]=1,x.depth[Z]=0,x.opt_len--,ie&&(x.static_len-=oe[2*Z+1]);for(M.max_code=Se,Y=x.heap_len>>1;1<=Y;Y--)ve(x,Q,Y);for(Z=de;Y=x.heap[1],x.heap[1]=x.heap[x.heap_len--],ve(x,Q,1),U=x.heap[1],x.heap[--x.heap_max]=Y,x.heap[--x.heap_max]=U,Q[2*Z]=Q[2*Y]+Q[2*U],x.depth[Z]=(x.depth[Y]>=x.depth[U]?x.depth[Y]:x.depth[U])+1,Q[2*Y+1]=Q[2*U+1]=Z,x.heap[1]=Z++,ve(x,Q,1),2<=x.heap_len;);x.heap[--x.heap_max]=x.heap[1],(function(ke,Me){var Ve,Ge,Je,De,Zt,st,Xe=Me.dyn_tree,Ft=Me.max_code,Pi=Me.stat_desc.static_tree,zo=Me.stat_desc.has_stree,Fo=Me.stat_desc.extra_bits,Wn=Me.stat_desc.extra_base,ki=Me.stat_desc.max_length,Ni=0;for(De=0;De<=g;De++)ke.bl_count[De]=0;for(Xe[2*ke.heap[ke.heap_max]+1]=0,Ve=ke.heap_max+1;Ve<f;Ve++)ki<(De=Xe[2*Xe[2*(Ge=ke.heap[Ve])+1]+1]+1)&&(De=ki,Ni++),Xe[2*Ge+1]=De,Ft<Ge||(ke.bl_count[De]++,Zt=0,Wn<=Ge&&(Zt=Fo[Ge-Wn]),st=Xe[2*Ge],ke.opt_len+=st*(De+Zt),zo&&(ke.static_len+=st*(Pi[2*Ge+1]+Zt)));if(Ni!==0){do{for(De=ki-1;ke.bl_count[De]===0;)De--;ke.bl_count[De]--,ke.bl_count[De+1]+=2,ke.bl_count[ki]--,Ni-=2}while(0<Ni);for(De=ki;De!==0;De--)for(Ge=ke.bl_count[De];Ge!==0;)Ft<(Je=ke.heap[--Ve])||(Xe[2*Je+1]!==De&&(ke.opt_len+=(De-Xe[2*Je+1])*Xe[2*Je],Xe[2*Je+1]=De),Ge--)}})(x,M),Te(Q,Se,x.bl_count)}function v(x,M,Y){var U,Z,Q=-1,oe=M[1],ie=0,de=7,Se=4;for(oe===0&&(de=138,Se=3),M[2*(Y+1)+1]=65535,U=0;U<=Y;U++)Z=oe,oe=M[2*(U+1)+1],++ie<de&&Z===oe||(ie<Se?x.bl_tree[2*Z]+=ie:Z!==0?(Z!==Q&&x.bl_tree[2*Z]++,x.bl_tree[2*T]++):ie<=10?x.bl_tree[2*B]++:x.bl_tree[2*I]++,Q=Z,Se=(ie=0)===oe?(de=138,3):Z===oe?(de=6,3):(de=7,4))}function K(x,M,Y){var U,Z,Q=-1,oe=M[1],ie=0,de=7,Se=4;for(oe===0&&(de=138,Se=3),U=0;U<=Y;U++)if(Z=oe,oe=M[2*(U+1)+1],!(++ie<de&&Z===oe)){if(ie<Se)for(;le(x,Z,x.bl_tree),--ie!=0;);else Z!==0?(Z!==Q&&(le(x,Z,x.bl_tree),ie--),le(x,T,x.bl_tree),se(x,ie-3,2)):ie<=10?(le(x,B,x.bl_tree),se(x,ie-3,3)):(le(x,I,x.bl_tree),se(x,ie-11,7));Q=Z,Se=(ie=0)===oe?(de=138,3):Z===oe?(de=6,3):(de=7,4)}}a(N);var H=!1;function $(x,M,Y,U){se(x,(c<<1)+(U?1:0),3),(function(Z,Q,oe,ie){q(Z),ne(Z,oe),ne(Z,~oe),s.arraySet(Z.pending_buf,Z.window,Q,oe,Z.pending),Z.pending+=oe})(x,M,Y)}o._tr_init=function(x){H||((function(){var M,Y,U,Z,Q,oe=new Array(g+1);for(Z=U=0;Z<d-1;Z++)for(A[Z]=U,M=0;M<1<<w[Z];M++)y[U++]=Z;for(y[U-1]=Z,Z=Q=0;Z<16;Z++)for(N[Z]=Q,M=0;M<1<<P[Z];M++)L[Q++]=Z;for(Q>>=7;Z<u;Z++)for(N[Z]=Q<<7,M=0;M<1<<P[Z]-7;M++)L[256+Q++]=Z;for(Y=0;Y<=g;Y++)oe[Y]=0;for(M=0;M<=143;)V[2*M+1]=8,M++,oe[8]++;for(;M<=255;)V[2*M+1]=9,M++,oe[9]++;for(;M<=279;)V[2*M+1]=7,M++,oe[7]++;for(;M<=287;)V[2*M+1]=8,M++,oe[8]++;for(Te(V,b+1,oe),M=0;M<u;M++)_[2*M+1]=5,_[2*M]=pe(M,5);F=new X(V,w,p+1,b,g),E=new X(_,P,0,u,g),D=new X(new Array(0),R,0,h,S)})(),H=!0),x.l_desc=new j(x.dyn_ltree,F),x.d_desc=new j(x.dyn_dtree,E),x.bl_desc=new j(x.bl_tree,D),x.bi_buf=0,x.bi_valid=0,be(x)},o._tr_stored_block=$,o._tr_flush_block=function(x,M,Y,U){var Z,Q,oe=0;0<x.level?(x.strm.data_type===2&&(x.strm.data_type=(function(ie){var de,Se=4093624447;for(de=0;de<=31;de++,Se>>>=1)if(1&Se&&ie.dyn_ltree[2*de]!==0)return l;if(ie.dyn_ltree[18]!==0||ie.dyn_ltree[20]!==0||ie.dyn_ltree[26]!==0)return r;for(de=32;de<p;de++)if(ie.dyn_ltree[2*de]!==0)return r;return l})(x)),W(x,x.l_desc),W(x,x.d_desc),oe=(function(ie){var de;for(v(ie,ie.dyn_ltree,ie.l_desc.max_code),v(ie,ie.dyn_dtree,ie.d_desc.max_code),W(ie,ie.bl_desc),de=h-1;3<=de&&ie.bl_tree[2*z[de]+1]===0;de--);return ie.opt_len+=3*(de+1)+5+5+4,de})(x),Z=x.opt_len+3+7>>>3,(Q=x.static_len+3+7>>>3)<=Z&&(Z=Q)):Z=Q=Y+5,Y+4<=Z&&M!==-1?$(x,M,Y,U):x.strategy===4||Q===Z?(se(x,2+(U?1:0),3),O(x,V,_)):(se(x,4+(U?1:0),3),(function(ie,de,Se,ke){var Me;for(se(ie,de-257,5),se(ie,Se-1,5),se(ie,ke-4,4),Me=0;Me<ke;Me++)se(ie,ie.bl_tree[2*z[Me]+1],3);K(ie,ie.dyn_ltree,de-1),K(ie,ie.dyn_dtree,Se-1)})(x,x.l_desc.max_code+1,x.d_desc.max_code+1,oe+1),O(x,x.dyn_ltree,x.dyn_dtree)),be(x),U&&q(x)},o._tr_tally=function(x,M,Y){return x.pending_buf[x.d_buf+2*x.last_lit]=M>>>8&255,x.pending_buf[x.d_buf+2*x.last_lit+1]=255&M,x.pending_buf[x.l_buf+x.last_lit]=255&Y,x.last_lit++,M===0?x.dyn_ltree[2*Y]++:(x.matches++,M--,x.dyn_ltree[2*(y[Y]+p+1)]++,x.dyn_dtree[2*G(M)]++),x.last_lit===x.lit_bufsize-1},o._tr_align=function(x){se(x,2,3),le(x,C,V),(function(M){M.bi_valid===16?(ne(M,M.bi_buf),M.bi_buf=0,M.bi_valid=0):8<=M.bi_valid&&(M.pending_buf[M.pending++]=255&M.bi_buf,M.bi_buf>>=8,M.bi_valid-=8)})(x)}},{"../utils/common":41}],53:[function(i,n,o){n.exports=function(){this.input=null,this.next_in=0,this.avail_in=0,this.total_in=0,this.output=null,this.next_out=0,this.avail_out=0,this.total_out=0,this.msg="",this.state=null,this.data_type=2,this.adler=0}},{}],54:[function(i,n,o){(function(s){(function(l,r){if(!l.setImmediate){var a,c,d,p,b=1,u={},h=!1,f=l.document,g=Object.getPrototypeOf&&Object.getPrototypeOf(l);g=g&&g.setTimeout?g:l,a={}.toString.call(l.process)==="[object process]"?function(T){process.nextTick(function(){S(T)})}:(function(){if(l.postMessage&&!l.importScripts){var T=!0,B=l.onmessage;return l.onmessage=function(){T=!1},l.postMessage("","*"),l.onmessage=B,T}})()?(p="setImmediate$"+Math.random()+"$",l.addEventListener?l.addEventListener("message",C,!1):l.attachEvent("onmessage",C),function(T){l.postMessage(p+T,"*")}):l.MessageChannel?((d=new MessageChannel).port1.onmessage=function(T){S(T.data)},function(T){d.port2.postMessage(T)}):f&&"onreadystatechange"in f.createElement("script")?(c=f.documentElement,function(T){var B=f.createElement("script");B.onreadystatechange=function(){S(T),B.onreadystatechange=null,c.removeChild(B),B=null},c.appendChild(B)}):function(T){setTimeout(S,0,T)},g.setImmediate=function(T){typeof T!="function"&&(T=new Function(""+T));for(var B=new Array(arguments.length-1),I=0;I<B.length;I++)B[I]=arguments[I+1];var w={callback:T,args:B};return u[b]=w,a(b),b++},g.clearImmediate=k}function k(T){delete u[T]}function S(T){if(h)setTimeout(S,0,T);else{var B=u[T];if(B){h=!0;try{(function(I){var w=I.callback,P=I.args;switch(P.length){case 0:w();break;case 1:w(P[0]);break;case 2:w(P[0],P[1]);break;case 3:w(P[0],P[1],P[2]);break;default:w.apply(r,P)}})(B)}finally{k(T),h=!1}}}}function C(T){T.source===l&&typeof T.data=="string"&&T.data.indexOf(p)===0&&S(+T.data.slice(p.length))}})(typeof self>"u"?s===void 0?this:s:self)}).call(this,typeof Xn<"u"?Xn:typeof self<"u"?self:typeof window<"u"?window:{})},{}]},{},[10])(10)})})(is)),is.exports}var fy=uy();const py=dy(fy),hy=/\.(?:png|jpe?g|gif|svg|webp|avif|ico|bmp|tiff?|mp4|webm|mp3|wav|ogg)$/i,my=/\.(?:ts|js|mjs|cjs|jsx|tsx|vue|json|css|scss|less|html|py|rs|go|java|c|cpp|h|sh|bash|yaml|yml|toml)$/i;async function gy(e){const t=await py.loadAsync(e),i={},n=[];let o="",s="";const l=[];t.forEach((a,c)=>{!c.dir&&!a.startsWith("__MACOSX")&&!a.includes("node_modules/")&&l.push({path:a,file:c})});let r=l.find(a=>a.path.toLowerCase()==="slides.md");r||(r=l.find(a=>a.path.toLowerCase().endsWith("/slides.md"))),r||(r=l.find(a=>a.path.toLowerCase().endsWith(".md"))),r&&(o=await r.file.async("string"),s=r.path);for(const a of l){const c=a.path;if(c.toLowerCase().endsWith(".md")||my.test(c)||c.includes("snippets/")){const d=await a.file.async("string");i[c]=d;const p=c.split("/");p.length>1&&(i[p.slice(1).join("/")]=d)}else if(hy.test(c)){const d=await a.file.async("uint8array"),p=c.split("/").pop()||c,b=typeof Blob<"u"?new Blob([d]):void 0;n.push({zipPath:c,fileName:p,data:d,blob:b})}}return{entryMarkdown:o,entryMarkdownPath:s,virtualFiles:i,assets:n}}function vy(e,t){if(Object.keys(t).length===0)return e;function i(o){const s=o.trim().replace(/^['"]|['"]$/g,""),l=s.split("/").pop()||s;if(t[s])return t[s];const r=s.replace(/^\.?\//,"");return t[r]?t[r]:t[l]?t[l]:null}function n(o){let s=o;return s=s.replace(/!\[(.*?)\]\((.*?)\)/g,(l,r,a)=>{const c=i(a);return c?`![${r}](${c})`:l}),s=s.replace(/\bsrc=["'](.*?)["']/gi,(l,r)=>{const a=i(r);return a?`src="${a}"`:l}),s}for(const o of e.slides)if(o.rawMarkdown=n(o.rawMarkdown),o.pageAttrs["custom-slidev-background"]){const s=o.pageAttrs["custom-slidev-background"],l=i(s);l&&(o.pageAttrs["custom-slidev-background"]=l)}if(e.flattenedMarkdown=n(e.flattenedMarkdown),e.docRootAttrs["custom-slidev-background"]){const o=e.docRootAttrs["custom-slidev-background"],s=i(o);s&&(e.docRootAttrs["custom-slidev-background"]=s)}return e}function Ba(e){try{if(typeof process<"u"&&typeof require<"u"){const t=require("fs");if(t.existsSync(e))return t.readFileSync(e,"utf-8")}}catch{}return null}function by(e,t){const i=e.match(/^[ \t]*<<<[ \t]+([^\s]+)/);if(!i)return null;const n=i[1].trim(),o=n.indexOf("#"),s=o!==-1?n.slice(0,o):n,l=o!==-1?n.slice(o+1):"",r=s.replace(/^@\//,"").replace(/^\.\//,""),a=(t==null?void 0:t.virtualFiles)||{};let c=a[s]||a[r]||a[`./${r}`]||a[`@/${r}`];if(!c&&Object.keys(a).length>0){const u=r.split("/").pop();for(const[h,f]of Object.entries(a))if(h.endsWith(`/${r}`)||u&&h.endsWith(`/${u}`)){c=f;break}}if(!c){const u=[];if(t!=null&&t.baseDir)try{const h=require("path");u.push(h.resolve(t.baseDir,r)),u.push(h.resolve(t.baseDir,s))}catch{}try{const h=require("path");u.push(h.resolve(process.cwd(),r))}catch{}for(const h of u){const f=Ba(h);if(f!==null){c=f;break}}}if(!c){const u=ka||{};if(c=u[s]||u[r]||u[`snippets/${r}`],!c){const h=r.split("/").pop();for(const[f,g]of Object.entries(u))if(f.endsWith(`/${r}`)||h&&f.endsWith(`/${h}`)){c=g;break}}}if(!c)return null;let d=c;if(l){const u=new RegExp(`(?:\\/\\/|\\/\\*|#)?\\s*#(?:region|REGION)\\s+${l}[^\\r\\n]*\\r?\\n([\\s\\S]*?)(?:\\/\\/|\\/\\*|#)?\\s*#(?:endregion|ENDREGION)\\s+${l}`,"i"),h=c.match(u);if(h){const f=c.match(/^(\/\/\s*Inside[^\r\n]+\r?\n)/i);d=(f?f[1]:"")+h[1].trimEnd()}}const p=r.match(/\.([a-zA-Z0-9]+)$/);return`\`\`\`${p?p[1]:""}
${d}
\`\`\``}function yy(e){let t=!1,i=!1;for(let n=0;n<e.length;n++){const o=e[n];if(o==="'"&&!i)t=!t;else if(o==='"'&&!t)i=!i;else if(o==="#"&&!t&&!i)return e.slice(0,n).trim()}return e.trim()}function no(e){const t={},i=e.split(/\r?\n/);let n=0;for(;n<i.length;){const o=i[n],s=o.trim();if(!s||s.startsWith("#")){n++;continue}const l=o.indexOf(":");if(l>0){const r=o.slice(0,l).trim();let a=o.slice(l+1).trim();if(a==="|"||a===">"){n++;const c=[];let d=-1;for(;n<i.length;){const p=i[n];if(!p.trim()){c.push(""),n++;continue}const u=p.match(/^(\s+)/),h=u?u[1].length:0;if(d===-1&&(d=h),h<d)break;c.push(p.slice(d)),n++}for(;c.length>0&&c[c.length-1]==="";)c.pop();t[r]=a===">"?c.join(" "):c.join(`
`);continue}if(a=yy(a),!a){let c=n+1;const d=[];let p=-1;for(;c<i.length;){const b=i[c],u=b.trim();if(!u||u.startsWith("#")){p!==-1&&d.push(""),c++;continue}const h=b.match(/^(\s+)/),f=h?h[1].length:0;if(p===-1)if(f>0)p=f;else break;if(f<p)break;d.push(b.slice(p)),c++}if(d.length>0){t[r]=no(d.join(`
`)),n=c;continue}}a.startsWith('"')&&a.endsWith('"')||a.startsWith("'")&&a.endsWith("'")?a=a.slice(1,-1):a==="true"?a=!0:a==="false"?a=!1:a==="null"?a=null:/^-?\d+(?:\.\d+)?$/.test(a)&&(a=Number(a)),t[r]=a}n++}return t}const ky=/^\s*```ya?ml([\s\S]*?)```/;function Ur(e){let t={},i=e.trim();const n=i.match(/^---[^\n\r]*\r?\n([\s\S]*?)\r?\n---(?=[ \t]*(?:\r?\n|$))/);if(n&&!n[1].includes("```")){const s=no(n[1]);if(Object.keys(s).length>0||!n[1].trim())return t=s,i=i.slice(n[0].length).trim(),{frontmatter:t,content:i}}if(i.startsWith("---")){const s=i.match(/^---[^\n\r]*(?:\r?\n|$)/);s&&(i=i.slice(s[0].length).trim())}const o=i.match(ky);if(o)t=no(o[1]),i=i.slice(o[0].length).trim();else{const s=i.split(/\r?\n/),l=[];let r=0;for(let a=0;a<s.length;a++){const c=s[a].trim();if(!c){if(l.length>0){r=a+1;break}continue}if(/^[a-zA-Z0-9_-]+\s*:\s*.*/.test(c)&&!c.startsWith("<")&&!c.startsWith("#"))l.push(c);else{r=a;break}}l.length>0&&(t=no(l.join(`
`)),i=s.slice(r).join(`
`).trim())}return{frontmatter:t,content:i}}function wy(e){const t=e.split(/\r?\n/),i=[];let n=0,o=!1;function s(l){if(n>=l)return;const r=t.slice(n,l).join(`
`).trim();r&&i.push(r),n=l+1}for(let l=0;l<t.length;l++){const a=t[l].trimEnd();if(o){a.includes("-->")&&(o=!1);continue}if(a.startsWith("<!--")){a.includes("-->")||(o=!0);continue}if(a.startsWith("---")){s(l);const c=t[l+1];if(c&&c.trim()&&a.replace(/^-+/,"").trim()==="")for(n=l,l+=1;l<t.length&&t[l].trimEnd()!=="---";l++);}else if(a.trimStart().startsWith("```")){const c=a.match(/^\s*`+/),d=c?c[0].trim():"```";let p=l+1;for(;p<t.length&&!t[p].trimStart().startsWith(d);p++);p<t.length&&(l=p)}}return n<t.length&&s(t.length),i}function oo(e,t={}){const{stripNotesFromMarkdown:i=!0,cleanVClicks:n=!0,cleanShikiLines:o=!0,cleanSlots:s=!0,isolateStyleTags:l=!0,cleanHtmlToMarkdown:r=!0,wrapSuperBlocks:a=!0,virtualFiles:c={}}=t;let d=e;d&&!d.trimStart().startsWith("---")&&(d=`---

${d.trimStart()}`);const p=wy(d),b={};let u="",h="",f=0;if(p.length>0){const z=p[0],V=Ur(z),_=Object.keys(V.frontmatter).length>0,L=V.content.length>0;_&&!L&&p.length>1?(f=1,g(V.frontmatter)):_&&g(V.frontmatter)}function g(z){u=z.title||"",z.theme&&(b[Cn]=String(z.theme)),z.aspectRatio&&(b[$n]=String(z.aspectRatio)),z.highlighter&&(b[Qr]=String(z.highlighter)),z.transition&&(b[In]=String(z.transition)),z.colorSchema&&(b[el]=String(z.colorSchema)),z.layout&&(b[ue]=String(z.layout)),z.background&&(b[je]=String(z.background)),z.image&&(b[Bt]=String(z.image)),z.class&&(b[Ui]=String(z.class));for(const[V,_]of Object.entries(z))["theme","aspectRatio","highlighter","transition","colorSchema","title","layout","background","image","class"].includes(V)||(b[`custom-slidev-${V}`]=typeof _=="object"?JSON.stringify(_):String(_))}const k=[];let S=0,C=0,T=0,B=0;const I=new Set,w={};let P=1;for(let z=f;z<p.length;z++){const V=p[z],{frontmatter:_,content:L}=Ur(V),y=V.match(/^\s*(?:---\s*)?src:\s*([^\n\r]+)/m),A=_.src||(y?y[1]:void 0);if(A){const q=String(A).trim().replace(/^['"]|['"]$/g,"");let ae=c[q]||c[q.replace(/^\.\//,"")]||c[`pages/${q.replace(/^.*pages\//,"")}`];if(!ae){const O=q.replace(/^\.\//,""),W=[];if(t.baseDir)try{const v=require("path");W.push(v.resolve(t.baseDir,O)),W.push(v.resolve(t.baseDir,q))}catch{}try{const v=require("path");W.push(v.resolve(process.cwd(),O)),W.push(v.resolve(process.cwd(),q))}catch{}for(const v of W){const K=Ba(v);if(K!==null){ae=K;break}}}const ve={};_.layout&&(ve[ue]=String(_.layout)),_.transition&&(ve[tt]=String(_.transition)),_.background&&(ve[je]=String(_.background)),_.image&&(ve[Bt]=String(_.image)),_.class&&(ve[Ui]=String(_.class));for(const[O,W]of Object.entries(_))["src","layout","transition","background","image","class"].includes(O)||(ve[`custom-slidev-${O}`]=typeof W=="object"?JSON.stringify(W):String(W));if(ae){const O=oo(ae,{...t,virtualFiles:c});for(const W of O.slides){W.pageIndex=P++,W.pageAttrs={...ve,...W.pageAttrs},k.push(W);const v=W.pageAttrs[ue]||"default";w[v]=(w[v]||0)+1}continue}else{k.push({pageIndex:P++,pageAttrs:{...ve,"custom-slidev-src":q},notes:"",rawMarkdown:`> 📄 **引入外部幻灯片页面**: \`${q}\`
>
> *提示：如需展示该页面完整内容，请将关联子页面一同打包为 .zip 或通过本地工程导入。*`,hasVueComponent:!1,hasStyleTag:!1,assetReferences:[]});const O=ve[ue]||"default";w[O]=(w[O]||0)+1;continue}}const F={};_.layout&&(F[ue]=String(_.layout)),_.transition&&(F[tt]=String(_.transition)),_.background&&(F[je]=String(_.background)),_.image&&(F[Bt]=String(_.image)),_.class&&(F[Ui]=String(_.class)),_.mask&&(F[Vi]=String(_.mask)),(_.maskRatio||_["mask-ratio"])&&(F[Ki]=String(_.maskRatio||_["mask-ratio"])),(_.maskStyle||_["mask-style"])&&(F[qi]=String(_.maskStyle||_["mask-style"])),(_.maskInitial||_["mask-initial"])&&(F[Gi]=String(_.maskInitial||_["mask-initial"]));for(const[q,ae]of Object.entries(_))["layout","transition","background","image","class","mask","maskRatio","mask-ratio","maskStyle","mask-style","maskInitial","mask-initial"].includes(q)||(F[`custom-slidev-${q}`]=typeof ae=="object"?JSON.stringify(ae):String(ae));let E=L;const D=[];let N=E.replace(/(?:^[ \t]*(`{3,}|~{3,})[^\n\r]*\r?\n[\s\S]*?\r?\n[ \t]*\1(?=[ \t]*(?:\r?\n|$)))/gm,q=>{const ae=`__CODE_TOKEN_NOTE_${D.length}__`;return D.push(q),ae});N=N.replace(/(`+)(?:[^\n\r`]|(?!\1)`)+?\1/g,q=>{const ae=`__CODE_TOKEN_NOTE_${D.length}__`;return D.push(q),ae});let X="";const j=Array.from(N.matchAll(/<!--([\s\S]*?)-->/g));if(j.length>0){const q=j[j.length-1],ae=N.slice(q.index+q[0].length).trim();if(!ae||!ae.replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi,"").trim()){const O=q[1].trim();O.startsWith("TODO:")||(X=O,S++),i&&(N=N.slice(0,q.index).trimEnd()+N.slice(q.index+q[0].length))}}i&&(N=N.replace(/<!--(?![\s\S]*?TODO:)[\s\S]*?-->/g,"").trim());for(let q=0;q<D.length;q++)N=N.replace(`__CODE_TOKEN_NOTE_${q}__`,D[q]);if(E=N,X){for(let ve=0;ve<D.length;ve++)X=X.replace(`__CODE_TOKEN_NOTE_${ve}__`,D[ve]);const ae=`> [!NOTE] 💡 演讲备注
${X.split(/\r?\n/).map(ve=>`> ${ve}`).join(`
`)}
{: custom-slidev-note="true"}`;E=E?`${E}

${ae}`:ae}let G=!1;if(/<style\b/i.test(E)){G=!0;const q=E.match(/<style\b[^>]*>([\s\S]*?)<\/style>/gi);if(q){for(const ae of q){const ve=ae.replace(/<style\b[^>]*>|<\/style>/gi,"").trim();h=h?`${h}

${ve}`:ve}l&&(E=E.replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi,"").trim())}}const ne=E.match(/<v-click[^>]*>|<v-clicks[^>]*>|v-click=/g);ne&&(C+=ne.length);const se=E.match(/```\w+\s+\{[^}]+\}/g);se&&(T+=se.length);const le=E.match(/::\w+::|<template\s+#[^>]+>/g);if(le&&(B+=le.length),E=E.replace(/^[ \t]*<<<[ \t]+([^\n\r]+)/gm,q=>by(q,{...t,virtualFiles:c})||q),n&&(E=E.replace(/<v-click(?:\s+at="[^"]*")?(?:\s+hide)?>\s*([\s\S]*?)\s*<\/v-click>/gi,"$1")),o&&(E=E.replace(/(^```\w+(?:[ \t]+\[[^\]]*\])?)[ \t]+\{[^}]+\}(?:[ \t]+\w+)?/gm,"$1"),E=E.replace(/^\$\$\s+\{[^}]+\}/gm,()=>"$$")),s&&(E=E.replace(/^::\w+::\s*$/gm,"")),r&&(E=xf(E)),a){let q=E.trim(),ae="";const ve=q.lastIndexOf("> [!NOTE] 💡 演讲备注");if(ve!==-1&&(ae=q.slice(ve),q=q.slice(0,ve).trim()),(_.layout==="image-left"||_.layout==="image-right")&&_.image){const O=String(_.image).trim(),W=_.layout==="image-left"?"image-left":"image-right",v=`![配图](${O})
{: custom-slidev-layout="${W}" }`;_.layout==="image-left"?q=`{{{col

${v}

${q}

}}}`:q=`{{{col

${q}

${v}

}}}`}if(_.background){const W=`![背景图](${String(_.background).trim()})
{: custom-slidev-role="background" }`;q=q?`${W}

${q}`:W}E=ae?`${q}

${ae}`:q}const pe=xy(E);F[je]&&pe.push(F[je]),F[Bt]&&pe.push(F[Bt]);for(const q of pe)I.add(q);const Te=/<[A-Z][a-zA-Z0-9]+/.test(E),be=F[ue]||(P===1?b[ue]||"cover":"default");w[be]=(w[be]||0)+1,k.push({pageIndex:P++,pageAttrs:F,notes:X,rawMarkdown:E,hasVueComponent:Te,hasStyleTag:G,assetReferences:pe})}if(!u&&k.length>0){const z=k[0].rawMarkdown.match(/^#\s+(.+)$/m);z&&(u=z[1].trim())}h&&(b["custom-slidev-custom-css"]=h);let R=k.map(z=>`---

${z.rawMarkdown}`).join(`

`);return R.trimStart().startsWith("---")||(R=`---

${R.trimStart()}`),{docTitle:u||"Slidev 演示文稿",docRootAttrs:b,slides:k,totalSlides:k.length,stats:{totalNotes:S,totalVClicks:C,totalShikiHighlights:T,totalSlots:B,discoveredAssets:Array.from(I),layoutDistribution:w},flattenedMarkdown:R,customCss:h}}function xy(e){const t=[],i=/!\[.*?\]\((.*?)\)/g;let n;for(;(n=i.exec(e))!==null;){const s=n[1].split(/\s+/)[0].trim();s&&t.push(s)}const o=/<(?:img|video|source|audio)\b[^>]*src=["'](.*?)["']/gi;for(;(n=o.exec(e))!==null;){const s=n[1].trim();s&&t.push(s)}return t}function Ma(e){if(!e)return!1;const t=String(e.type||"").toLowerCase(),i=String(e.markdown||"").trim(),n=String(e.content||"").trim();return t==="tb"||t==="thematic-break"||t==="nodethematicbreak"||i==="---"||i==="***"||n==="---"||n==="***"}function Sy(e){return(e.trim()||"Slidev 演示文稿").replace(/[\\/:*?"<>|]/g,"_")}async function _y(e,t,i=Ne){const n=e.filter(Ma);let o=0;if(n.length>=t.length)for(let s=0;s<t.length;s++){const l=t[s],r=n[s];r&&r.id&&Object.keys(l.pageAttrs||{}).length>0&&(await i(r.id,l.pageAttrs),o++)}else for(let s=1;s<t.length;s++){const l=t[s],r=n[s-1];r&&r.id&&Object.keys(l.pageAttrs||{}).length>0&&(await i(r.id,l.pageAttrs),o++)}return o}async function Cy(e,t=Ne){let i=!1,n=0;for(const o of e){if(Ma(o)){i=!1;continue}const s=(o.markdown||o.content||"").trim();if(s==="::right::"||s.startsWith("::right::")){i=!0;continue}i&&o.id&&(await t(o.id,{[Ce]:"right"}).catch(()=>{}),n++)}return n}async function $y(e,t,i=Zr){const n={};if(!t||t.length===0)return n;const o=[];for(const s of t){const l=new File([s.data],s.fileName,{type:"application/octet-stream"});o.push(l)}try{const s=await i("/data/assets",o);if(s!=null&&s.succMap)for(const[l,r]of Object.entries(s.succMap))n[l]=String(r)}catch(s){console.warn("上传本地静态资产失败，保留原路径:",s)}return Object.keys(n).length>0&&vy(e,n),n}async function Iy(e){var T;const{presentation:t,notebookId:i,docTitle:n,extractedAssets:o=[],uploadAssets:s=!0,autoPreview:l=!0,plugin:r,api:a={}}=e,c=a.uploadFn||Zr,d=a.createDocFn||Ac,p=a.setAttrsFn||Ne,b=a.getChildBlocksFn||co,u=a.openTabFn||me.openTab,h=a.showMessageFn||me.showMessage;s&&o.length>0&&await $y(t,o,c);const f=Sy(n),g=`/${f}`,k=await d(i,g,t.flattenedMarkdown);if(!k)throw new Error("思源内核创建文档失败，未返回有效 DocumentId");const S=((T=t.slides[0])==null?void 0:T.pageAttrs)||{};await p(k,{...S,...t.docRootAttrs});const C=await b(k).catch(()=>[]);return Array.isArray(C)&&C.length>0&&(await _y(C,t.slides,p),await Cy(C,p)),h(`🎉 成功导入 Slidev 演示文档《${f}》！`),l&&r&&(r.currentDocId=k,await u({app:r.app,doc:{id:k}}),r.openBottomPreviewTab&&r.openBottomPreviewTab()),k}function Ey(e){const t=fe("file"),i=fe(!1),n=fe(!1),o=fe(""),s=fe(null),l=fe(null),r=fe(""),a=fe(0),c=fe(""),d=fe([]),p=fe(null),b=fe(""),u=fe([]),h=fe(""),f=fe(!0),g=fe(!0),k=fe(!0),S=fe(!0),C=xe(()=>{const F=a.value;if(F===0)return"0 B";const E=1024,D=["B","KB","MB","GB"],N=Math.floor(Math.log(F)/Math.log(E));return`${(F/E**N).toFixed(1)} ${D[N]}`}),T=xe(()=>{var F;return((F=p.value)==null?void 0:F.docRootAttrs["custom-slidev-theme"])||"default"}),B=xe(()=>{var F;return d.value.length>0?d.value.length:((F=p.value)==null?void 0:F.stats.discoveredAssets.length)||0}),I=xe(()=>{var E;const F=((E=p.value)==null?void 0:E.stats.layoutDistribution)||{};return Object.entries(F).map(([D,N])=>({name:D,count:N}))});async function w(F=Tc){try{const E=await F();E!=null&&E.notebooks&&Array.isArray(E.notebooks)&&(u.value=E.notebooks.filter(D=>!D.closed),u.value.length>0&&!h.value&&(h.value=u.value[0].id))}catch(E){console.warn("获取笔记本列表失败:",E)}}function P(){var F;(F=s.value)==null||F.click()}function R(){l.value=null,r.value="",a.value=0,p.value=null,d.value=[],o.value=""}async function z(F){o.value="",l.value=F,r.value=F.name,a.value=F.size;try{if(F.name.toLowerCase().endsWith(".zip")){const D=await F.arrayBuffer(),N=await gy(D);if(!N.entryMarkdown){o.value="未在 Zip 压缩包中找到 slides.md 或任何有效的 Markdown 入口文件";return}d.value=N.assets;const X=oo(N.entryMarkdown,{stripNotesFromMarkdown:g.value,cleanHtmlToMarkdown:f.value,cleanSlots:!1,virtualFiles:N.virtualFiles});p.value=X,b.value=X.docTitle||F.name.replace(/\.zip$/i,"")}else{const D=await F.text();d.value=[];const N=F.path||"",X=N?N.replace(/[\\/][^\\/]+$/,""):"",j=oo(D,{stripNotesFromMarkdown:g.value,cleanHtmlToMarkdown:f.value,cleanSlots:!1,baseDir:X||void 0});p.value=j,b.value=j.docTitle||F.name.replace(/\.md$/i,"")}}catch(E){console.error("解析文件失败:",E),o.value=`解析文件失败: ${E.message||String(E)}`}}function V(){if(o.value="",!c.value.trim()){p.value=null;return}try{const F=oo(c.value,{stripNotesFromMarkdown:g.value,cleanHtmlToMarkdown:f.value,cleanSlots:!1});p.value=F,b.value=F.docTitle||"Slidev 演示文稿"}catch(F){o.value=`解析 Markdown 源码失败: ${F.message||String(F)}`}}async function _(){l.value?await z(l.value):c.value&&V()}async function L(F){const E=F.target;E.files&&E.files[0]&&await z(E.files[0])}async function y(F){var E;i.value=!1,(E=F.dataTransfer)!=null&&E.files&&F.dataTransfer.files[0]&&await z(F.dataTransfer.files[0])}async function A(F=e){if(p.value){if(!h.value&&u.value.length>0&&(h.value=u.value[0].id),!h.value){o.value="请先选择目标笔记本";return}n.value=!0,o.value="";try{return await Iy({presentation:p.value,notebookId:h.value,docTitle:b.value,extractedAssets:d.value,uploadAssets:k.value,autoPreview:S.value,plugin:F})}catch(E){console.error("导入 Slidev 演示失败:",E),o.value=`导入执行失败: ${E.message||String(E)}`}finally{n.value=!1}}}return{inputMode:t,isDragging:i,isImporting:n,errorMessage:o,fileInputRef:s,selectedFile:l,selectedFileName:r,selectedFileSize:a,rawMarkdownText:c,extractedAssets:d,parsedPresentation:p,customDocTitle:b,notebooks:u,selectedNotebookId:h,optCleanHtml:f,optStripNotes:g,optUploadAssets:k,optAutoPreview:S,formattedFileSize:C,currentTheme:T,extractedAssetsCount:B,layoutChips:I,fetchNotebooks:w,triggerFileInput:P,clearFile:R,processFile:z,onFileSelected:L,onFileDrop:y,onTextChange:V,reprocessCurrentInput:_,handleConfirmImport:A}}const Ty={class:"spm-import-dialog"},Ay={class:"spm-tabs-header"},By={class:"spm-dialog-body"},My={key:0,class:"spm-file-section"},Dy={key:0,class:"spm-dropzone-prompt"},Ly={class:"spm-dropzone-icon"},Oy={key:1,class:"spm-dropzone-active"},Ry={class:"spm-file-badge"},Py={class:"spm-file-size"},Ny={key:1,class:"spm-text-section"},zy={key:2,class:"spm-error-banner"},Fy={key:3,class:"spm-preview-card"},Hy={class:"spm-preview-card__header"},jy={style:{display:"inline-flex","align-items":"center",gap:"4px"}},Wy={class:"spm-config-grid"},Uy={class:"spm-form-item"},Vy={class:"spm-form-item"},Ky=["value"],qy={class:"spm-stats-grid"},Gy={class:"spm-stat-box"},Zy={class:"spm-stat-value"},Yy={class:"spm-stat-box"},Jy={class:"spm-stat-value"},Xy={class:"spm-stat-box"},Qy={class:"spm-stat-value"},e0={class:"spm-stat-box"},t0={class:"spm-stat-value"},i0={key:0,class:"spm-chips-row"},n0={class:"spm-options-group"},o0={class:"spm-checkbox-label"},s0={class:"spm-checkbox-label"},r0={class:"spm-checkbox-label"},l0={class:"spm-checkbox-label"},a0={class:"spm-dialog-footer"},c0=["disabled"],d0=["disabled"],u0={key:0,style:{display:"inline-flex","align-items":"center",gap:"4px"}},f0={key:1,style:{display:"inline-flex","align-items":"center",gap:"4px"}},p0=Ct({__name:"SlidevImportDialog",emits:["close","success"],setup(e,{emit:t}){const i=t,n=ti("plugin"),{inputMode:o,isDragging:s,isImporting:l,errorMessage:r,fileInputRef:a,selectedFileName:c,rawMarkdownText:d,extractedAssetsCount:p,parsedPresentation:b,customDocTitle:u,notebooks:h,selectedNotebookId:f,optCleanHtml:g,optStripNotes:k,optUploadAssets:S,optAutoPreview:C,formattedFileSize:T,currentTheme:B,layoutChips:I,fetchNotebooks:w,triggerFileInput:P,clearFile:R,onFileSelected:z,onFileDrop:V,onTextChange:_,reprocessCurrentInput:L,handleConfirmImport:y}=Ey(n);Fn(async()=>{await w()});async function A(){const E=await y();E&&(i("success",{docId:E}),i("close"))}function F(){i("close")}return(E,D)=>(ee(),te("div",{class:"spm-modal-overlay",onClick:Mt(F,["self"])},[m("div",Ty,[m("div",{class:"spm-dialog-header"},[D[18]||(D[18]=m("div",{class:"spm-dialog-title"},[m("svg",{class:"spm-dialog-icon","aria-hidden":"true"},[m("use",{"xlink:href":"#iconSlidev"})]),m("span",null,"导入 Slidev 演示文档")],-1)),m("button",{class:"spm-close-btn",title:"关闭",onClick:F},"✕")]),m("div",Ay,[m("button",{class:_e(["spm-tab-btn",{active:ge(o)==="file"}]),onClick:D[0]||(D[0]=N=>o.value="file")},[re(ce,{name:"package"}),D[19]||(D[19]=m("span",null,"文件 / 压缩包导入 (.zip / .md)",-1))],2),m("button",{class:_e(["spm-tab-btn",{active:ge(o)==="text"}]),onClick:D[1]||(D[1]=N=>o.value="text")},[re(ce,{name:"notes"}),D[20]||(D[20]=m("span",null,"粘贴 Markdown 源码",-1))],2)]),m("div",By,[ge(o)==="file"?(ee(),te("div",My,[m("div",{class:_e(["spm-dropzone",{dragover:ge(s),"has-file":!!ge(c)}]),onDragover:D[4]||(D[4]=Mt(N=>s.value=!0,["prevent"])),onDragleave:D[5]||(D[5]=Mt(N=>s.value=!1,["prevent"])),onDrop:D[6]||(D[6]=Mt((...N)=>ge(V)&&ge(V)(...N),["prevent"])),onClick:D[7]||(D[7]=(...N)=>ge(P)&&ge(P)(...N))},[m("input",{ref_key:"fileInputRef",ref:a,type:"file",accept:".zip,.md",class:"spm-hidden-input",onChange:D[2]||(D[2]=(...N)=>ge(z)&&ge(z)(...N))},null,544),ge(c)?(ee(),te("div",Oy,[m("span",Ry,[re(ce,{name:"notes"}),$t(" "+we(ge(c)),1)]),m("span",Py,"("+we(ge(T))+")",1),m("button",{class:"spm-btn-text",onClick:D[3]||(D[3]=Mt((...N)=>ge(R)&&ge(R)(...N),["stop"]))},"更换文件")])):(ee(),te("div",Dy,[m("span",Ly,[re(ce,{name:"folder",style:{"font-size":"32px"}})]),D[21]||(D[21]=m("p",{class:"spm-dropzone-text"},"点击选择文件，或直接拖拽文件至此处",-1)),D[22]||(D[22]=m("p",{class:"spm-dropzone-hint"},[$t(" 支持 Slidev 完整工程 "),m("strong",null,".zip"),$t("（自动解包 public/ 静态素材）或单文件 "),m("strong",null,".md")],-1))]))],34)])):(ee(),te("div",Ny,[Tt(m("textarea",{"onUpdate:modelValue":D[8]||(D[8]=N=>Ye(d)?d.value=N:null),class:"spm-textarea spm-source-editor",rows:"8",placeholder:"在此直接粘贴包含 Frontmatter 的 Slidev slides.md 源码...",onInput:D[9]||(D[9]=(...N)=>ge(_)&&ge(_)(...N))},null,544),[[So,ge(d)]])])),ge(r)?(ee(),te("div",zy," ⚠️ "+we(ge(r)),1)):Oe("",!0),ge(b)?(ee(),te("div",Fy,[m("div",Hy,[m("span",jy,[re(ce,{name:"sparkles"}),D[23]||(D[23]=$t(" 演示解析摘要",-1))]),D[24]||(D[24]=m("span",{class:"spm-badge-success"},"预检就绪",-1))]),m("div",Wy,[m("div",Uy,[D[25]||(D[25]=m("label",{class:"spm-form-label"},"笔记文档标题",-1)),Tt(m("input",{"onUpdate:modelValue":D[10]||(D[10]=N=>Ye(u)?u.value=N:null),class:"spm-input",placeholder:"思源新文档标题"},null,512),[[So,ge(u)]])]),m("div",Vy,[D[26]||(D[26]=m("label",{class:"spm-form-label"},"存放目标笔记本",-1)),Tt(m("select",{"onUpdate:modelValue":D[11]||(D[11]=N=>Ye(f)?f.value=N:null),class:"spm-select"},[(ee(!0),te(Ue,null,kt(ge(h),N=>(ee(),te("option",{key:N.id,value:N.id},we(N.name),9,Ky))),128))],512),[[tf,ge(f)]])])]),m("div",qy,[m("div",Gy,[m("span",Zy,we(ge(b).totalSlides),1),D[27]||(D[27]=m("span",{class:"spm-stat-label"},"幻灯片页数",-1))]),m("div",Yy,[m("span",Jy,we(ge(B)),1),D[28]||(D[28]=m("span",{class:"spm-stat-label"},"演示主题",-1))]),m("div",Xy,[m("span",Qy,we(ge(b).stats.totalNotes),1),D[29]||(D[29]=m("span",{class:"spm-stat-label"},"演讲者提词",-1))]),m("div",e0,[m("span",t0,we(ge(p)),1),D[30]||(D[30]=m("span",{class:"spm-stat-label"},"关联本地素材",-1))])]),ge(I).length>0?(ee(),te("div",i0,[D[31]||(D[31]=m("span",{class:"spm-chips-label"},"页面版式分布：",-1)),(ee(!0),te(Ue,null,kt(ge(I),N=>(ee(),te("span",{key:N.name,class:"spm-chip-badge"},we(N.name)+": "+we(N.count),1))),128))])):Oe("",!0),m("div",n0,[m("label",o0,[Tt(m("input",{"onUpdate:modelValue":D[12]||(D[12]=N=>Ye(g)?g.value=N:null),type:"checkbox",onChange:D[13]||(D[13]=(...N)=>ge(L)&&ge(L)(...N))},null,544),[[Yn,ge(g)]]),D[32]||(D[32]=m("span",null,"智能剥离展示型 HTML 容器为干净原生的 Markdown 笔记块",-1))]),m("label",s0,[Tt(m("input",{"onUpdate:modelValue":D[14]||(D[14]=N=>Ye(k)?k.value=N:null),type:"checkbox",onChange:D[15]||(D[15]=(...N)=>ge(L)&&ge(L)(...N))},null,544),[[Yn,ge(k)]]),D[33]||(D[33]=m("span",null,"提取演讲者提词到块属性并保持正文笔记清爽",-1))]),m("label",r0,[Tt(m("input",{"onUpdate:modelValue":D[16]||(D[16]=N=>Ye(S)?S.value=N:null),type:"checkbox"},null,512),[[Yn,ge(S)]]),D[34]||(D[34]=m("span",null,"自动上传关联素材至思源资产库并重写路径 (assets/...)",-1))]),m("label",l0,[Tt(m("input",{"onUpdate:modelValue":D[17]||(D[17]=N=>Ye(C)?C.value=N:null),type:"checkbox"},null,512),[[Yn,ge(C)]]),D[35]||(D[35]=m("span",null,"导入后自动打开新文档并开启下方分屏放映预览",-1))])])])):Oe("",!0)]),m("div",a0,[m("button",{class:"spm-btn-secondary",disabled:ge(l),onClick:F}," 取消 ",8,c0),m("button",{class:"spm-btn-primary",disabled:!ge(b)||ge(l),onClick:A},[ge(l)?(ee(),te("span",u0,[re(ce,{name:"refresh"}),D[36]||(D[36]=$t(" 正在导入生成中...",-1))])):(ee(),te("span",f0,[re(ce,{name:"rocket"}),D[37]||(D[37]=$t(" 确认导入思源笔记",-1))]))],8,d0)])])]))}}),h0=zt(p0,[["__scopeId","data-v-2eff6f1e"]]);function Xs(e){return e?e==="NodeThematicBreak"||e==="tb"||e==="thematic-break":!1}function m0(e,t){var r;if(!e||e.length===0)return null;const i=t.activeBlockId||"",n=t.currentTopBlockId||i,o=t.currentPageDividerId||"",s=t.activeBlockType||"";if(Xs(s)&&i){let a=e.find(c=>c.startBlockId===i);if(a||(a=e.find(c=>{var d,p;return((p=(d=c.blocks)==null?void 0:d[0])==null?void 0:p.id)===i}),a)||(a=e.find(c=>{var d;return(d=c.allBlockIds)==null?void 0:d.includes(i)}),a))return a}if(o){let a=e.find(c=>c.startBlockId===o);if(a||(a=e.find(c=>{var d,p;return((p=(d=c.blocks)==null?void 0:d[0])==null?void 0:p.id)===o}),a))return a}if(i){let a=e.find(d=>d.startBlockId===i);if(a||(a=e.find(d=>{var p,b;return((p=d.blocks)==null?void 0:p.some(u=>u.id===i))||((b=d.allBlockIds)==null?void 0:b.includes(i))}),a)||n&&n!==i&&(a=e.find(d=>{var p,b;return((p=d.blocks)==null?void 0:p.some(u=>u.id===n))||((b=d.allBlockIds)==null?void 0:b.includes(n))}),a)||(a=e.find(d=>{var p;return(p=d.noteBlocks)==null?void 0:p.some(b=>b.id===i||b.id===n)}),a))return a;const c=(r=t.activeBlockAttrs)==null?void 0:r[Ce];if(c&&["col-1","col-2","col-3"].includes(c)&&(a=e.find(d=>{var p,b;return((p=d.frontmatter)==null?void 0:p.layout)==="three-cols-header"||((b=d.blocks)==null?void 0:b.some(u=>u.slot==="col-1"||u.slot==="col-2"||u.slot==="col-3"))}),a))return a}return e[0]||null}function g0(e,t){if(!t)return!1;if(e===t||typeof document>"u")return!0;const i=document.querySelector(`.protyle-wysiwyg [data-node-id="${t}"]`)||document.querySelector(`[data-node-id="${t}"]`);if(!i)return!1;const n=i.querySelector(":scope > [data-node-id], :scope > div > [data-node-id]");return(n==null?void 0:n.getAttribute("data-node-id"))===e}function v0(e){let t=null;function i(c="已同步"){e.saveStatus.value=c,t&&(typeof window<"u"?window.clearTimeout(t):clearTimeout(t));const d=()=>{e.saveStatus.value=""};typeof window<"u"?t=window.setTimeout(d,1200):t=setTimeout(d,1200)}async function n(c){var u;const d=e.activeBlockId.value||e.currentDocId.value;if(!d)return;for(const[h,f]of Object.entries(c))e.activeBlockAttrs.value[h]=f;Be.setBlockAttrOverride(d,c),et(d,c);const p=(u=e.parentContainerId)==null?void 0:u.value,b=!!(p&&g0(d,p));if(Ze in c&&b&&p){const h=c[Ze];e.parentContainerClicks&&(e.parentContainerClicks.value=h),Be.setBlockAttrOverride(p,{[Ze]:h}),et(p,{[Ze]:h}),Ne(p,{[Ze]:h}).catch(()=>{})}if(ue in c){const h=c[ue];e.currentPageDividerLayout.value=h,e.targetSlide.value&&(e.targetSlide.value.frontmatter||(e.targetSlide.value.frontmatter={}),e.targetSlide.value.frontmatter.layout=h)}if(yt in c){const h=c[yt];e.targetSlide.value&&(e.targetSlide.value.frontmatter||(e.targetSlide.value.frontmatter={}),e.targetSlide.value.frontmatter.layoutRatio=h)}i("保存中...");try{await Ne(d,c),i("已同步"),e.plugin&&await e.plugin.compileCurrentDocument()}catch{i("同步失败")}}async function o(c,d){await n({[c]:d})}function s(){const c=e.activeBlockType.value==="NodeThematicBreak"||e.activeBlockType.value==="NodeThematicBreakBlock"||e.activeBlockType.value==="hr"||e.activeBlockType.value==="thematicbreak";return e.currentPageDividerId.value||(c?e.activeBlockId.value:"")||e.currentDocId.value}async function l(c,d){const p=s();if(p){p===e.activeBlockId.value&&(e.activeBlockAttrs.value[c]=d),Be.setBlockAttrOverride(p,{[c]:d}),et(p,{[c]:d}),c===ue&&(e.currentPageDividerLayout.value=d,e.targetSlide.value&&(e.targetSlide.value.frontmatter||(e.targetSlide.value.frontmatter={}),e.targetSlide.value.frontmatter.layout=d)),c===yt&&e.targetSlide.value&&(e.targetSlide.value.frontmatter||(e.targetSlide.value.frontmatter={}),e.targetSlide.value.frontmatter.layoutRatio=d),i("保存中...");try{await Ne(p,{[c]:d}),i("已同步"),e.plugin&&await e.plugin.compileCurrentDocument()}catch{i("同步失败")}}}async function r(c,d){const p=s();if(!p)return;const b={[ue]:c,[yt]:d};p===e.activeBlockId.value&&(e.activeBlockAttrs.value[ue]=c,e.activeBlockAttrs.value[yt]=d),e.currentPageDividerLayout.value=c,Be.setBlockAttrOverride(p,b),et(p,b),e.targetSlide.value&&(e.targetSlide.value.frontmatter||(e.targetSlide.value.frontmatter={}),e.targetSlide.value.frontmatter.layout=c,e.targetSlide.value.frontmatter.layoutRatio=d),i("应用排版中...");try{await Ne(p,b),i("已应用分栏与比例"),e.plugin&&await e.plugin.compileCurrentDocument()}catch{i("应用失败")}}async function a(c,d){var b;const p=e.currentDocId.value||e.activeBlockId.value;if(p){e.activeBlockAttrs.value[c]=d,Be.setBlockAttrOverride(p,{[c]:d}),et(p,{[c]:d}),(b=e.latestDoc.value)!=null&&b.config&&(c===Cn&&(e.latestDoc.value.config.theme=d),c===$n&&(e.latestDoc.value.config.aspectRatio=d),c===In&&(e.latestDoc.value.config.defaultTransition=d)),i("更新中...");try{await Ne(p,{[c]:d}),i("已更新"),e.plugin&&await e.plugin.compileCurrentDocument(p)}catch{i("更新失败")}}}return{triggerSaveNotice:i,saveAttrs:n,saveAttr:o,getPageTargetBlockId:s,savePageAttr:l,applyPageLayoutAndRatio:r,saveDocAttr:a}}function Vr(e,t){const i=(e.blocks||[]).filter(l=>{const r=(l.content||l.rawMarkdown||"").trim();return r&&r!=="---"});if(i.length===0)return"本页暂无内容，建议过渡承接上下文。";const n=[],o=[];for(const l of i){const r=(l.content||l.rawMarkdown||"").trim();r&&(l.type==="h"||r.startsWith("#")?n.push(r.replace(/^#+\s*/,"")):o.push(r.slice(0,50)))}const s=[];return n.length>0&&s.push(`【核心重点】：${n.join("、")}`),o.length>0&&(s.push("【口播要点】："),o.slice(0,3).forEach((l,r)=>{s.push(`${r+1}. 讲解 ${l}`)})),s.push("【过渡提示】：注意观察听众反应，适时抛出互动提问。"),s.join(`
`)}async function Da(e,t){const i=e.blocks&&e.blocks.length>0?e.blocks.map(n=>(n.content||n.rawMarkdown||"").trim()).filter(n=>n&&n!=="---").join(`
`):(e.rawMarkdown||"").replace(/^---\s*$/gm,"").trim();if(t&&i){const n=`你是一位专业的演讲教练。请根据以下幻灯片内容，提炼出简短精炼的演讲口播提词卡（Notes），包含核心观点与口播要点，总字数在 150 字以内：
${i}`;try{const o=await t(n);if(o&&o.trim())return{notes:o.trim(),isAiGenerated:!0}}catch(o){return{notes:Vr(e),isAiGenerated:!1,error:(o==null?void 0:o.message)||"AI 调用异常"}}}return{notes:Vr(e),isAiGenerated:!1}}async function b0(e,t){return(await Da(e,t)).notes}function y0(e,t){const i=fe(!1),{triggerSaveNotice:n}=t;async function o(p){var T,B,I,w,P,R,z,V;const h=`> [!NOTE] 💡 演讲备注
${(p||"在此输入本页讲稿提词...").split(/\r?\n/).map(_=>`> ${_}`).join(`
`)}
{: custom-slidev-note="true"}`,f=((T=e.latestDoc.value)==null?void 0:T.slides)||[],g=e.targetSlide.value,k=g?f.findIndex(_=>_===g):-1;let S=null;if(k!==-1&&k<f.length-1){const _=f[k+1];S=await Ti("markdown",h,_.startBlockId)}else{const _=((B=g==null?void 0:g.noteBlocks)==null?void 0:B.slice(-1)[0])||((I=g==null?void 0:g.blocks)==null?void 0:I.slice(-1)[0]),L=(_==null?void 0:_.id)||(g==null?void 0:g.startBlockId);L?S=await Ti("markdown",h,void 0,L):S=await ss("markdown",h,e.currentDocId.value)}const C=((R=(P=(w=S==null?void 0:S[0])==null?void 0:w.doOperations)==null?void 0:P[0])==null?void 0:R.id)||((z=S==null?void 0:S[0])==null?void 0:z.id);return C&&(await Ne(C,{[nt]:"true"}),Be.setBlockAttrOverride(C,{[nt]:"true"}),Li(C,(V=e.plugin)==null?void 0:V.app)),e.plugin&&await e.plugin.compileCurrentDocument(),C}async function s(){const p=e.activeBlockId.value;if(p)if(e.isNoteBlock.value){n("取消中...");try{await Ne(p,{[nt]:"","slidev-note":""}),Be.setBlockAttrOverride(p,{[nt]:"","slidev-note":""}),et(p,{[nt]:"","slidev-note":""}),delete e.activeBlockAttrs.value[nt],delete e.activeBlockAttrs.value["slidev-note"],n("已取消备注"),me.showMessage("已取消讲稿备注"),e.plugin&&await e.plugin.compileCurrentDocument()}catch(b){console.error("[SiYuanSlidev] 取消讲稿备注失败:",b),n("取消失败"),me.showMessage("取消讲稿备注失败")}}else{n("转换中...");try{let b=e.rawSnippet.value;try{const g=await Bc(p);g!=null&&g.kramdown&&(b=g.kramdown)}catch{}const f=`> [!NOTE] 💡 演讲备注
${(ga(b)||b.replace(/<[^>]+>/g,"").trim()||"在此输入本页讲稿提词...").split(/\r?\n/).map(g=>`> ${g}`).join(`
`)}
{: custom-slidev-note="true"}`;await or("markdown",f,p),await Ne(p,{[nt]:"true"}),Be.setBlockAttrOverride(p,{[nt]:"true"}),et(p,{[nt]:"true"}),e.activeBlockAttrs.value[nt]="true",e.activeBlockType.value="NodeCallout",n("已设为讲稿备注"),me.showMessage("已转为讲稿备注提示块（不在幻灯片中渲染）"),e.plugin&&await e.plugin.compileCurrentDocument()}catch(b){console.error("[SiYuanSlidev] 转换讲稿备注提示块失败:",b),n("设置失败"),me.showMessage("转为讲稿备注提示块失败")}}}async function l(){try{await o(),me.showMessage("已在正文末尾插入讲稿备注提示块")}catch(p){me.showMessage("插入讲稿备注块失败"),console.error(p)}}function r(){var u;const p=e.currentSlideNoteBlockId.value;if(!p){me.showMessage("未找到本页关联的讲稿备注块");return}Li(p,(u=e.plugin)==null?void 0:u.app)?me.showMessage("已在编辑区定位讲稿备注块"):me.showMessage("定位讲稿备注块失败")}async function a(){var u;if(!e.currentDocId.value)return;const p=e.targetSlide.value||{startBlockId:e.activeBlockId.value||e.currentDocId.value,blocks:e.rawSnippet.value&&e.rawSnippet.value!=="---"?[{id:e.activeBlockId.value,type:e.activeBlockType.value,content:e.rawSnippet.value,rawMarkdown:""}]:[],rawMarkdown:e.rawSnippet.value&&e.rawSnippet.value!=="---"?e.rawSnippet.value:""};me.showMessage("正在调用思源 AI 提炼本页讲稿提词...");const b=await Da(p,Jr);if(b.notes){const h=e.currentSlideNoteBlockId.value;if(h){const f=`> [!NOTE] 💡 演讲备注
${b.notes.split(/\r?\n/).map(g=>`> ${g}`).join(`
`)}
{: custom-slidev-note="true"}`;await or("markdown",f,h),await Ne(h,{[nt]:"true"}),Be.setBlockAttrOverride(h,{[nt]:"true"}),Li(h,(u=e.plugin)==null?void 0:u.app)}else await o(b.notes);b.isAiGenerated?me.showMessage("思源 AI 演讲提词卡生成成功！"):me.showMessage("未获取到思源 AI 响应，已生成预设提词卡模板",5e3),e.plugin&&await e.plugin.compileCurrentDocument()}}async function c(){var h;if(i.value)return;const p=((h=e.latestDoc.value)==null?void 0:h.slides)||[];if(p.length===0){me.showMessage("当前文档无幻灯片页面");return}const b=p.map((f,g)=>({slide:f,idx:g})).filter(({slide:f})=>{var S;const g=Array.isArray(f.noteBlocks)&&f.noteBlocks.length>0,k=!!((S=f.notes)!=null&&S.trim());return!g&&!k});if(b.length===0){me.showMessage("所有幻灯片页面均已存在讲稿备注块，无需追加");return}const u=b.length;me.confirm("批量追加讲稿备注",`将在未配置讲稿的 ${u} 页末尾自动插入讲稿提示块，是否继续？`,async()=>{var g,k,S,C,T,B;if(i.value)return;i.value=!0,me.showMessage("正在批量追加讲稿块...");let f=0;try{const P=`> [!NOTE] 💡 演讲备注
${"在此输入本页讲稿提词...".split(/\r?\n/).map(R=>`> ${R}`).join(`
`)}
{: custom-slidev-note="true"}`;for(const{slide:R,idx:z}of b)try{let V=null;if(z<p.length-1){const L=p[z+1];V=await Ti("markdown",P,L.startBlockId)}else{const L=((g=R==null?void 0:R.noteBlocks)==null?void 0:g.slice(-1)[0])||((k=R==null?void 0:R.blocks)==null?void 0:k.slice(-1)[0]),y=(L==null?void 0:L.id)||(R==null?void 0:R.startBlockId);y?V=await Ti("markdown",P,void 0,y):V=await ss("markdown",P,e.currentDocId.value)}const _=((T=(C=(S=V==null?void 0:V[0])==null?void 0:S.doOperations)==null?void 0:C[0])==null?void 0:T.id)||((B=V==null?void 0:V[0])==null?void 0:B.id);_&&(await Ne(_,{[nt]:"true"}),Be.setBlockAttrOverride(_,{[nt]:"true"})),f++}catch(V){console.error(`[SiYuanSlidev] 为第 ${z+1} 页追加讲稿块失败:`,V)}e.plugin&&await e.plugin.compileCurrentDocument(),me.showMessage(`已成功为 ${f} 页追加讲稿备注块`)}catch(I){console.error("[SiYuanSlidev] 批量追加讲稿块失败:",I),me.showMessage("批量追加讲稿块时出现异常")}finally{i.value=!1}})}async function d(){var f;if(i.value)return;const p=((f=e.latestDoc.value)==null?void 0:f.slides)||[];if(p.length===0){me.showMessage("当前文档无幻灯片页面");return}const b=[];for(const g of p)if(g.noteBlocks&&g.noteBlocks.length>0)for(const k of g.noteBlocks)k.id&&b.push({id:k.id,pageIndex:g.pageIndex});if(b.length===0){me.showMessage("当前文档中没有讲稿备注块，无需删除");return}const u=new Set(b.map(g=>g.pageIndex)).size,h=b.length;me.confirm("危险操作：批量删除所有讲稿块",`此操作将从正文中物理删除全部 ${h} 个讲稿备注块（涉及 ${u} 页），删除后无法撤销。是否确认继续？`,async()=>{if(i.value)return;i.value=!0,me.showMessage("正在批量删除讲稿块...");let g=0;try{for(const k of b)try{await Yr(k.id),Be.clearBlockAttrOverride(k.id),g++}catch(S){console.error(`[SiYuanSlidev] 删除讲稿块 ${k.id} 失败:`,S)}e.activeBlockId.value&&b.some(k=>k.id===e.activeBlockId.value)&&(delete e.activeBlockAttrs.value[nt],delete e.activeBlockAttrs.value["slidev-note"]),e.plugin&&await e.plugin.compileCurrentDocument(),me.showMessage(`已成功删除全部 ${g} 个讲稿备注块`)}catch(k){console.error("[SiYuanSlidev] 批量删除讲稿块失败:",k),me.showMessage("批量删除讲稿块时出现异常")}finally{i.value=!1}})}return{isBatchProcessing:i,createNoteBlockOnCurrentSlide:o,onToggleNoteBlock:s,onAddNoteBlock:l,onLocateNoteBlock:r,onGenerateNotesWithAI:a,onBatchAppendNotes:c,onBatchDeleteNotes:d}}function k0(e,t){const{saveAttr:i,saveAttrs:n,savePageAttr:o}=t;async function s(){(e.videoAutoplay.value?"false":"true")==="true"?(await n({[Ei]:"true",[ji]:"true"}),e.activeBlockAttrs.value[Ei]="true",e.activeBlockAttrs.value[ji]="true"):(await i(Ei,"false"),e.activeBlockAttrs.value[Ei]="false")}async function l(){const w=e.videoLoop.value?"false":"true";await i(uo,w)}async function r(){const w=e.videoMuted.value?"false":"true";await i(ji,w)}async function a(){const w=e.videoControls.value?"false":"true";await i(fo,w)}async function c(w){var _;const P=e.activeBlockId.value;if(!P)return;const R=e.rawSnippet.value||"",z=bi(R)||"",V=e.currentPageDividerId.value||e.currentDocId.value;if(w)if(w==="background"){const L={[qe]:"background",[ue]:""};V&&z&&(e.pageBackground.value=z,await Ne(V,{[je]:z}).catch(()=>{}),Be.setBlockAttrOverride(V,{[je]:z}),et(V,{[je]:z}),e.targetSlide.value&&(e.targetSlide.value.frontmatter||(e.targetSlide.value.frontmatter={}),e.targetSlide.value.frontmatter.background=z)),await n(L)}else(w===po||w===ho)&&await n({[ue]:w,[qe]:""});else{const L={[qe]:"",[ue]:""};if(e.activeBlockAttrs.value[je]==="true"&&(L[je]=""),V&&z&&e.pageBackground.value===z&&(e.pageBackground.value="",await Ne(V,{[je]:""}).catch(()=>{}),Be.setBlockAttrOverride(V,{[je]:""}),et(V,{[je]:""}),(_=e.targetSlide.value)!=null&&_.frontmatter&&delete e.targetSlide.value.frontmatter.background),await n(L),typeof document<"u"){const y=document.querySelector(`.protyle-wysiwyg [data-node-id="${P}"]`),A=y==null?void 0:y.closest('[data-type="NodeListItem"]'),F=A==null?void 0:A.getAttribute("data-node-id");if(F&&F!==P){const E={[ue]:"",[qe]:""};et(F,E),Be.setBlockAttrOverride(F,E),await Ne(F,E).catch(()=>{})}}}}function d(){e.elemClick.value?i(Ze,""):i(Ze,"+1")}function p(w){i(Ze,w)}function b(w){i(Kt,w)}function u(w){(e.activeBlockAttrs.value[Ce]||"")===w?i(Ce,""):i(Ce,w)}function h(w){e.elemShikiLines.value=w,i(Oi,w)}function f(w){e.elemMaxHeight.value=w,i(En,w)}async function g(){const w=e.currentSlideLayout.value==="three-cols-header";await i(Ce,w?"col-1":"left"),me.showMessage(w?"已将当前块设置为第 1 栏 (col-1)":"已将当前块设置为双栏左栏 (left)")}async function k(){const w=e.activeBlockId.value;if(!w)return;const P={[Ze]:"",[Kt]:"",[Ce]:"",[Oi]:"",[En]:"",[nt]:"","slidev-note":"",[ue]:"",[yt]:"",[qe]:"",[tt]:"",[je]:"",[Bt]:"",[Ei]:"",[uo]:"",[ji]:"",[fo]:""};if(et(w,P),await Ne(w,P),Be.clearBlockAttrOverride(w),typeof document<"u"){const R=document.querySelector(`.protyle-wysiwyg [data-node-id="${w}"]`),z=R==null?void 0:R.closest('[data-type="NodeListItem"]'),V=z==null?void 0:z.getAttribute("data-node-id");V&&V!==w&&(et(V,P),await Ne(V,P).catch(()=>{}),Be.clearBlockAttrOverride(V))}e.activeBlockAttrs.value={},e.elemShikiLines.value="",e.elemMaxHeight.value="",e.pageBackground.value="",e.pageImage.value="",me.showMessage("已清除本块演示属性"),e.plugin&&await e.plugin.compileCurrentDocument()}async function S(){if(e.activeBlockId.value)try{await Ti("markdown","---",e.activeBlockId.value,void 0),me.showMessage("已在上方插入分页符 (---)"),e.plugin&&e.plugin.compileCurrentDocument()}catch{me.showMessage("插入分页符失败")}}async function C(){const w=e.activeBlockId.value||e.currentDocId.value;if(w)try{await Ti("markdown","---",void 0,w),me.showMessage("已在下方插入分页符 (---)"),e.plugin&&e.plugin.compileCurrentDocument()}catch{me.showMessage("插入分页符失败")}}async function T(){if(e.activeBlockId.value)try{await Yr(e.activeBlockId.value),me.showMessage("已删除该分页符"),e.activeBlockId.value="",e.activeBlockType.value="",e.plugin&&e.plugin.compileCurrentDocument()}catch{me.showMessage("删除失败")}}async function B(){var w,P;try{let R=null;if(typeof document<"u"){const V=e.activeBlockId.value;if(V){const _=document.querySelector(`.protyle-wysiwyg [data-node-id="${V}"]`);_&&(R=_.getAttribute("data-type")==="NodeSuperBlock"?_:_.closest('[data-type="NodeSuperBlock"]'))}if(!R){const _=e.currentPageDividerId.value||(e.activeBlockType.value==="hr"||e.activeBlockType.value==="NodeThematicBreak"?e.activeBlockId.value:"");if(_){const L=document.querySelector(`.protyle-wysiwyg [data-node-id="${_}"]`);if(L){let y=L.nextElementSibling;for(;y&&!(y.getAttribute("data-type")==="NodeThematicBreak"||(w=y.classList)!=null&&w.contains("protyle-wysiwyg__block--hr"));){const A=y.getAttribute("data-type")==="NodeSuperBlock"?y:y.querySelector('[data-type="NodeSuperBlock"]');if(A){R=A;break}y=y.nextElementSibling}}}else{const L=document.querySelector('.protyle-wysiwyg [data-type="NodeThematicBreak"], .protyle-wysiwyg .protyle-wysiwyg__block--hr'),y=Array.from(document.querySelectorAll('.protyle-wysiwyg [data-type="NodeSuperBlock"]'));for(const A of y)if(!L||A.compareDocumentPosition(L)&Node.DOCUMENT_POSITION_FOLLOWING){R=A;break}}}}const z=[];if(R){const V=Array.from(R.querySelectorAll(":scope > [data-node-id]"));for(const _ of V){const L=_.getAttribute("data-node-id");L&&(z.push(L),_.removeAttribute("style"))}}else if((P=e.targetSlide.value)!=null&&P.blocks){for(const V of e.targetSlide.value.blocks)if(V.children&&V.children.length>=2){for(const _ of V.children)_.id&&z.push(_.id);break}}if(z.length>0)for(const V of z)await Ne(V,{style:""}).catch(()=>{});await o(yt,""),me.showMessage("已重置超级块为平均分布比例"),e.plugin&&await e.plugin.compileCurrentDocument()}catch(R){console.error("[layout-actions] resetSuperBlockWidth error:",R),me.showMessage("重置超级块比例失败")}}async function I(){var w,P,R;try{let z=null;if(typeof document<"u"){const _=e.currentPageDividerId.value||(e.activeBlockType.value==="hr"||e.activeBlockType.value==="NodeThematicBreak"?e.activeBlockId.value:""),L=e.activeBlockId.value;let y=[];if(_){const E=document.querySelector(`.protyle-wysiwyg [data-node-id="${_}"]`);if(E){let D=E.nextElementSibling;for(;D&&!(D.getAttribute("data-type")==="NodeThematicBreak"||(w=D.classList)!=null&&w.contains("protyle-wysiwyg__block--hr"));)y.push(D),D=D.nextElementSibling}}else{const E=document.querySelector('.protyle-wysiwyg [data-type="NodeThematicBreak"], .protyle-wysiwyg .protyle-wysiwyg__block--hr'),D=Array.from(document.querySelectorAll(".protyle-wysiwyg > [data-node-id]"));for(const N of D)if(!E||N.compareDocumentPosition(E)&Node.DOCUMENT_POSITION_FOLLOWING)y.push(N);else break}const A=[];let F;for(const E of y){const D=E.getAttribute("data-type");D==="NodeHeading"&&(F=E.getAttribute("data-node-id")||void 0);const N=[];D==="NodeSuperBlock"?N.push(E):N.push(...Array.from(E.querySelectorAll('[data-type="NodeSuperBlock"]')));for(const X of N){if((X.getAttribute("data-sb-layout")||"").toLowerCase()==="row")continue;const G=X.getAttribute("data-node-id")||"";let ne=[];const se=Array.from(X.querySelectorAll('[data-type="NodeListItem"]'));if(se.length===4&&(ne=se.map(le=>le.getAttribute("data-node-id")).filter(Boolean)),ne.length!==4){const le=Array.from(X.querySelectorAll(":scope > [data-node-id]"));le.length===4&&(ne=le.map(pe=>pe.getAttribute("data-node-id")).filter(Boolean))}ne.length===4&&A.push({sbId:G,itemIds:ne,headerId:F})}}A.length>0&&(L&&(z=A.find(E=>{if(E.sbId===L||E.itemIds.includes(L))return!0;const D=document.querySelector(`.protyle-wysiwyg [data-node-id="${E.sbId}"]`),N=document.querySelector(`.protyle-wysiwyg [data-node-id="${L}"]`);return!!(D&&N&&D.contains(N))})||null),z||(z=A[0]))}if(!z&&((P=e.targetSlide.value)!=null&&P.blocks)){const _=e.targetSlide.value,L=[];for(const A of _.blocks)A.rawNode?L.push(A.rawNode):L.push({id:A.id,type:A.type,content:A.content,markdown:A.rawMarkdown,children:A.children,ial:A.attributes||A.ial||{}});const y=bf(L,e.activeBlockId.value);y&&y.items.length===4&&(z={sbId:y.superBlockNode.id,itemIds:y.items.map(A=>A.id),headerId:(R=y.headerNode)==null?void 0:R.id})}if(!z||z.itemIds.length!==4)return me.showMessage("当前页面未找到包含 4 个组件的超级块（需包含 4 个列表项或 4 个子块）",4e3,"info"),!1;const V=e.currentPageDividerId.value||e.currentDocId.value;V&&(e.currentPageDividerLayout.value="clover",e.targetSlide.value&&(e.targetSlide.value.frontmatter||(e.targetSlide.value.frontmatter={}),e.targetSlide.value.frontmatter.layout="clover"),Be.setBlockAttrOverride(V,{[ue]:"clover"}),et(V,{[ue]:"clover"}),await Ne(V,{[ue]:"clover"}).catch(()=>{})),z.headerId&&(Be.setBlockAttrOverride(z.headerId,{[Ce]:"header"}),et(z.headerId,{[Ce]:"header"}),await Ne(z.headerId,{[Ce]:"header"}).catch(()=>{}));for(let _=0;_<4;_++){const L=z.itemIds[_],y=`col-${_+1}`;Be.setBlockAttrOverride(L,{[Ce]:y}),et(L,{[Ce]:y}),await Ne(L,{[Ce]:y}).catch(()=>{})}return me.showMessage("已将本页版式设为四叶草（田字型）布局"),e.plugin&&await e.plugin.compileCurrentDocument(),!0}catch(z){return console.error("[layout-actions] applyCloverLayout error:",z),me.showMessage("配置四叶草布局失败",4e3,"error"),!1}}return{onToggleVideoAutoplay:s,onToggleVideoLoop:l,onToggleVideoMuted:r,onToggleVideoControls:a,onImageRoleChange:c,toggleElemClick:d,onElemClickStepChange:p,onElemMotionChange:b,onElemSlotChange:u,onElemShikiLinesChange:h,onElemMaxHeightChange:f,onSetTwoColsContrast:g,onClearBlockAttrs:k,onInsertDividerBefore:S,onInsertDividerAfter:C,onDeleteCurrentBlock:T,resetSuperBlockWidth:B,applyCloverLayout:I}}function w0(e){const{triggerSaveNotice:t,saveAttrs:i,saveAttr:n,savePageAttr:o,applyPageLayoutAndRatio:s,saveDocAttr:l}=v0(e),r=y0(e,{triggerSaveNotice:t}),a=k0(e,{saveAttr:n,saveAttrs:i,savePageAttr:o});function c(){if(!e.latestDoc.value){me.showMessage("请先在主编辑区打开幻灯片文档");return}const p=Ia(e.latestDoc.value);Ea("presentation.html",p)&&me.showMessage("已开始下载单文件离线 HTML 演示包")}function d(){if(!e.latestDoc.value){me.showMessage("请先在主编辑区打开幻灯片文档");return}Ta(e.latestDoc.value)&&me.showMessage("已唤起打印视窗，请在打印选项中选择「另存为 PDF」")}return{triggerSaveNotice:t,saveAttrs:i,saveAttr:n,savePageAttr:o,applyPageLayoutAndRatio:s,saveDocAttr:l,onToggleVideoAutoplay:a.onToggleVideoAutoplay,onToggleVideoLoop:a.onToggleVideoLoop,onToggleVideoMuted:a.onToggleVideoMuted,onToggleVideoControls:a.onToggleVideoControls,onImageRoleChange:a.onImageRoleChange,onToggleNoteBlock:r.onToggleNoteBlock,createNoteBlockOnCurrentSlide:r.createNoteBlockOnCurrentSlide,onAddNoteBlock:r.onAddNoteBlock,onLocateNoteBlock:r.onLocateNoteBlock,onGenerateNotesWithAI:r.onGenerateNotesWithAI,isBatchProcessing:r.isBatchProcessing,onBatchAppendNotes:r.onBatchAppendNotes,onBatchDeleteNotes:r.onBatchDeleteNotes,toggleElemClick:a.toggleElemClick,onElemClickStepChange:a.onElemClickStepChange,onElemMotionChange:a.onElemMotionChange,onElemSlotChange:a.onElemSlotChange,onElemShikiLinesChange:a.onElemShikiLinesChange,onElemMaxHeightChange:a.onElemMaxHeightChange,onSetTwoColsContrast:a.onSetTwoColsContrast,onClearBlockAttrs:a.onClearBlockAttrs,onInsertDividerBefore:a.onInsertDividerBefore,onInsertDividerAfter:a.onInsertDividerAfter,onDeleteCurrentBlock:a.onDeleteCurrentBlock,resetSuperBlockWidth:a.resetSuperBlockWidth,applyCloverLayout:a.applyCloverLayout,onExportHtml:c,onExportPdf:d}}function x0(e){const t=xe(()=>Xs(e.activeBlockType.value));function i(n){const{attrKey:o,fallback:s,mode:l="defined"}=n,r=a=>l==="truthy"?a:a!==void 0;return xe(()=>{if(t.value){const c=e.activeBlockAttrs.value[o];if(r(c))return c}const a=e.currentPageDividerId.value||(t.value?e.activeBlockId.value:"");if(a){const c=Be.getBlockAttrOverride(a);if(r(c==null?void 0:c[o]))return c[o]}return s()})}return{isDivider:t,resolvePageAttr:i}}const S0={class:"spm-slidev-inspector"},_0={class:"spm-inspector-topbar"},C0={class:"spm-inspector-title"},$0={class:"slidev-icon",style:{fill:"none !important"},"aria-hidden":"true",viewBox:"0 0 24 24"},I0={class:"spm-inspector-topbar-actions"},E0={class:"spm-target-banner"},T0={class:"spm-target-info"},A0=["aria-label"],B0={key:0,class:"spm-save-status"},M0=["title"],D0={class:"spm-inspector-body"},L0=Ct({__name:"SlidevInspectorDockView",setup(e,{expose:t}){const i=ti("plugin"),n=fe(!1);function o(J){n.value=!1,c.value=J.docId,i!=null&&i.compileCurrentDocument&&i.compileCurrentDocument(J.docId)}const s=fe(""),l=fe(""),r=fe({}),a=fe(""),c=fe(""),d=fe(""),p=fe(""),b=fe(""),u=fe(""),h=fe(""),f=fe(""),g=fe(null),k=fe(""),S=fe("");function C(){var he;const J=s.value||c.value;J&&typeof navigator<"u"&&(he=navigator==null?void 0:navigator.clipboard)!=null&&he.writeText&&navigator.clipboard.writeText(J).then(()=>{S.value="已复制！",setTimeout(()=>{S.value=""},1500)}).catch(()=>{})}const T=xe(()=>Xs(l.value)),B=xe(()=>l.value==="NodeCodeBlock"),I=fe(!1),w=xe(()=>{if(I.value||Ve.value)return!0;const J=a.value||"";return!!bi(J)}),P=xe(()=>{const J=l.value||"";if(J==="NodeVideo"||J==="video")return!0;const he=a.value||"";return!!(/<video\b/i.test(he)||/\.mp4\b/i.test(he))}),R=xe(()=>!s.value||s.value===c.value||l.value==="doc"||l.value==="NodeDocument"),z=xe(()=>{const J=s.value||c.value||"";return J.length>8?J.slice(-8):J||"无"}),V=xe(()=>a.value?a.value.replace(/<[^>]+>/g,"").replace(/[\r\n]+/g," ").trim().slice(0,45):""),_=xe(()=>{if(T.value)return"分页符 (---)";if(R.value)return"全局文档";if(P.value)return"视频块";let J="内容块";switch(l.value){case"NodeHeading":J="标题块";break;case"NodeParagraph":J="段落块";break;case"NodeCodeBlock":J="代码块";break;case"NodeVideo":J="视频块";break;case"NodeList":case"NodeListItem":J="列表项";break;case"NodeBlockquote":J="引述块";break;case"NodeTable":J="表格块";break;case"NodeSuperBlock":case"s":case"sb":J="超级块";break;default:J="内容块";break}return u.value?h.value?`${h.value.replace(/^col-(\d+)$/,"第 $1 栏")} › ${J}`:`分栏容器 › ${J}`:J}),L=xe(()=>T.value?"tag-divider":R.value?"tag-doc":"tag-block"),y=xe(()=>r.value[ue]||"default"),A=xe(()=>r.value[tt]||"slide-left"),F=fe(""),E=fe(""),D=xe(()=>r.value[gn]||"inherit"),N=xe(()=>{var J;return m0((J=g.value)==null?void 0:J.slides,{activeBlockId:s.value,activeBlockType:l.value,currentTopBlockId:d.value,currentPageDividerId:p.value,activeBlockAttrs:r.value})}),X=xe(()=>{var J;return((J=N.value)==null?void 0:J.notes)||""}),j=xe(()=>{var J,he,Ie;return((Ie=(he=(J=N.value)==null?void 0:J.noteBlocks)==null?void 0:he[0])==null?void 0:Ie.id)||""}),G=xe(()=>{var ze,Fe,Le,ut,Un,di;if(T.value){const Qe=r.value[ue]||r.value["custom-slidev-layout"];if(Qe)return Qe}const J=r.value[Ce]||r.value["custom-slidev-slot"];if(J&&(["col-1","col-2","col-3"].includes(J)||/^col-\d+$/.test(J)))return"cols-header";if(b.value)return b.value;const he=p.value||(T.value?s.value:"");if(he){const Qe=Be.getBlockAttrOverride(he);if(Qe!=null&&Qe[ue])return Qe[ue]}if(he&&((ze=g.value)!=null&&ze.slides)){const Qe=g.value.slides.find(zi=>zi.startBlockId===he);if((Fe=Qe==null?void 0:Qe.frontmatter)!=null&&Fe.layout)return Qe.frontmatter.layout}if((ut=(Le=N.value)==null?void 0:Le.frontmatter)!=null&&ut.layout)return N.value.frontmatter.layout;if((di=(Un=N.value)==null?void 0:Un.blocks)!=null&&di.some(Qe=>Qe.slot&&(["col-1","col-2","col-3"].includes(Qe.slot)||/^col-\d+$/.test(Qe.slot))))return"cols-header";const Ie=Be.getBlockAttrOverride(c.value);return Ie!=null&&Ie[ue]?Ie[ue]:"default"}),ne=x0({activeBlockId:s,activeBlockType:l,activeBlockAttrs:r,currentPageDividerId:p}),se=ne.resolvePageAttr({attrKey:yt,mode:"truthy",fallback:()=>{var J,he;return((he=(J=N.value)==null?void 0:J.frontmatter)==null?void 0:he.layoutRatio)||""}}),le=ne.resolvePageAttr({attrKey:Vi,fallback:()=>{var J,he;return((he=(J=N.value)==null?void 0:J.frontmatter)==null?void 0:he.mask)||""}}),pe=ne.resolvePageAttr({attrKey:Ki,fallback:()=>{var J,he;return((he=(J=N.value)==null?void 0:J.frontmatter)==null?void 0:he.maskRatio)||""}}),Te=ne.resolvePageAttr({attrKey:qi,fallback:()=>{var J,he;return((he=(J=N.value)==null?void 0:J.frontmatter)==null?void 0:he.maskStyle)||"solid"}}),be=ne.resolvePageAttr({attrKey:Gi,fallback:()=>{var J,he;return((he=(J=N.value)==null?void 0:J.frontmatter)==null?void 0:he.maskInitial)||"hidden"}});function q(J){if(!J||(J.getAttribute("data-sb-layout")||"").toLowerCase()!=="col")return null;const Ie=Array.from(J.querySelectorAll(":scope > [data-node-id]"));if(Ie.length<2)return null;const ze=Ie.length,Fe=Ie.map(di=>{const Qe=di.getAttribute("style")||"",zi=Qe.match(/calc\(\s*([\d.]+)%/);if(zi)return parseFloat(zi[1]);const cn=Qe.match(/(?:^|;|\s)width:\s*([\d.]+)%/i);return cn?parseFloat(cn[1]):null});let Le="",ut=!1;if(Fe.some(di=>di!==null)){ut=!0;const di=Fe.reduce((Ae,ft)=>Ae+(ft||0),0),Qe=Fe.filter(Ae=>Ae===null).length,zi=Qe>0?Math.max(0,100-di)/Qe:100/Ie.length,cn=Fe.map(Ae=>Ae!==null?Ae:zi),wc=cn.reduce((Ae,ft)=>Ae+ft,0)||1,dn=cn.map(Ae=>Ae/wc*100);if(dn.length===2){const[Ae]=dn;if(Ae>=48&&Ae<=52)Le="1:1";else if(Ae>=31&&Ae<=35)Le="1:2";else if(Ae>=65&&Ae<=69)Le="2:1";else if(Ae>=28&&Ae<=32)Le="3:7";else if(Ae>=68&&Ae<=72)Le="7:3";else if(Ae>=38&&Ae<=42)Le="4:6";else if(Ae>=58&&Ae<=62)Le="6:4";else{const ft=Math.round(Ae);Le=`${ft}:${100-ft}`}}else if(dn.length===3){const[Ae,ft,ui]=dn;if(Ae>=31&&Ae<=35&&ft>=31&&ft<=35&&ui>=31&&ui<=35)Le="1:1:1";else if(Ae>=23&&Ae<=27&&ft>=48&&ft<=52&&ui>=23&&ui<=27)Le="1:2:1";else if(Ae>=48&&Ae<=52&&ft>=23&&ft<=27&&ui>=23&&ui<=27)Le="2:1:1";else if(Ae>=23&&Ae<=27&&ft>=23&&ft<=27&&ui>=48&&ui<=52)Le="1:1:2";else{const ir=Math.round(Ae),nr=Math.round(ft);Le=`${ir}:${nr}:${100-ir-nr}`}}else Le=dn.map(Ae=>Math.round(Ae)).join(":")}else ut=!1,Le=Array.from({length:ze},()=>1).join(":");const Un=ze>=2?"cols-header":"two-cols";return{hasSuperBlock:!0,colCount:ze,ratio:Le,isCustomWidth:ut,recommendedLayout:Un}}function ae(J){if(!(J!=null&&J.blocks))return null;for(const he of J.blocks){const Ie=he.rawNode;if(Ie&&ot(Ie)&&Gt(Ie)){const Fe=an(Ie).length,Le=Ks(Ie);return{hasSuperBlock:!0,colCount:Fe,ratio:Le||Array.from({length:Fe},()=>1).join(":"),isCustomWidth:!!Le,recommendedLayout:Fe>=2?"cols-header":"two-cols"}}}return null}const ve=xe(()=>{var J;if(typeof document<"u"){const he=s.value;if(he){const ze=document.querySelector(`.protyle-wysiwyg [data-node-id="${he}"]`);if(ze){const Fe=ze.getAttribute("data-type")==="NodeSuperBlock"?ze:ze.closest('[data-type="NodeSuperBlock"]');if(Fe){const Le=q(Fe);if(Le)return Le}}}const Ie=p.value||(T.value?s.value:"");if(Ie){const ze=document.querySelector(`.protyle-wysiwyg [data-node-id="${Ie}"]`);if(ze){let Fe=ze.nextElementSibling;for(;Fe&&!(Fe.getAttribute("data-type")==="NodeThematicBreak"||(J=Fe.classList)!=null&&J.contains("protyle-wysiwyg__block--hr"));){const Le=Fe.getAttribute("data-type")==="NodeSuperBlock"?Fe:Fe.querySelector('[data-type="NodeSuperBlock"]');if(Le){const ut=q(Le);if(ut)return ut}Fe=Fe.nextElementSibling}}}else{const ze=document.querySelector('.protyle-wysiwyg [data-type="NodeThematicBreak"], .protyle-wysiwyg .protyle-wysiwyg__block--hr'),Fe=Array.from(document.querySelectorAll('.protyle-wysiwyg [data-type="NodeSuperBlock"]'));for(const Le of Fe)if(!ze||Le.compareDocumentPosition(ze)&Node.DOCUMENT_POSITION_FOLLOWING){const ut=q(Le);if(ut)return ut}}}return ae(N.value)}),O=xe(()=>{var J;return((J=ve.value)==null?void 0:J.ratio)||""}),W=xe(()=>{const J=l.value||"";if(J==="NodeSuperBlock"||J==="s"||J==="sb")return!0;if(typeof document<"u"&&s.value){const he=document.querySelector(`.protyle-wysiwyg [data-node-id="${s.value}"]`);if(he!=null&&he.closest('[data-type="NodeSuperBlock"]'))return!0}return!1}),v=xe(()=>{var J;return((J=N.value)==null?void 0:J.pageIndex)||1}),K=xe(()=>!!(r.value[nt]||r.value["slidev-note"]));function H(){if(!u.value)return!1;if(s.value===u.value||typeof document>"u")return!0;const J=document.querySelector(`.protyle-wysiwyg [data-node-id="${u.value}"]`)||document.querySelector(`[data-node-id="${u.value}"]`);if(!J)return!1;const he=J.querySelector(":scope > [data-node-id], :scope > div > [data-node-id]");return(he==null?void 0:he.getAttribute("data-node-id"))===s.value}const $=xe(()=>{var he;if(r.value[Ze]!==void 0)return r.value[Ze]||"";if(u.value&&H())return f.value||"";if(u.value)return"";const J=s.value;if(J&&((he=N.value)!=null&&he.blocks)){const Ie=N.value.blocks.find(ze=>ze.id===J);if(Ie!=null&&Ie.clicks)return Ie.clicks}return""}),x=xe(()=>{var he;if(r.value[Kt])return r.value[Kt];const J=s.value;if(J&&((he=N.value)!=null&&he.blocks)){const Ie=N.value.blocks.find(ze=>ze.id===J);if(Ie!=null&&Ie.motion)return typeof Ie.motion=="string"?Ie.motion:JSON.stringify(Ie.motion)}return""}),M=xe(()=>{var he;if(r.value[Ce])return r.value[Ce];const J=s.value;if(J&&((he=N.value)!=null&&he.blocks)){const Ie=N.value.blocks.find(ze=>ze.id===J);if(Ie!=null&&Ie.slot)return Ie.slot}return""}),Y=fe(""),U=fe(""),Z=xe(()=>r.value[Ei]==="true"),Q=xe(()=>r.value[uo]==="true"),oe=xe(()=>r.value[ji]==="true"),ie=xe(()=>r.value[fo]!=="false"),de=xe(()=>{var J,he;return((he=(J=g.value)==null?void 0:J.config)==null?void 0:he.theme)||r.value[Cn]||"default"}),Se=xe(()=>{var J,he;return((he=(J=g.value)==null?void 0:J.config)==null?void 0:he.aspectRatio)||r.value[$n]||"16/9"}),ke=xe(()=>{var J,he;return((he=(J=g.value)==null?void 0:J.config)==null?void 0:he.defaultTransition)||r.value[In]||"slide-left"}),Me=xe(()=>{var J,he;return((he=(J=g.value)==null?void 0:J.config)==null?void 0:he.spacing)||r.value[ls]||"normal"}),Ve=xe(()=>{var Fe,Le;if((r.value[qe]||r.value["slidev-role"])===tl||r.value[je]==="true")return"background";const he=r.value[ue]||r.value["slidev-layout"];if(he==="image-left"||he==="image-right")return he;const Ie=a.value||"",ze=bi(Ie);if(ze&&((Le=(Fe=N.value)==null?void 0:Fe.frontmatter)!=null&&Le.background)){const ut=N.value.frontmatter.background;if(ut===ze||ut.endsWith(ze)||ze.endsWith(ut))return"background"}return""}),Ge=xe(()=>!!(r.value[Ze]||r.value[Kt]||r.value[Ce]||r.value[Oi]||r.value[nt]||r.value["slidev-note"]||r.value[qe]||r.value[ue]||r.value[Ei]||r.value[uo]||r.value[ji]||r.value[fo])),{saveAttr:Je,savePageAttr:De,applyPageLayoutAndRatio:Zt,applyCloverLayout:st,resetSuperBlockWidth:Xe,saveDocAttr:Ft,onToggleVideoAutoplay:Pi,onToggleVideoLoop:zo,onToggleVideoMuted:Fo,onToggleVideoControls:Wn,onImageRoleChange:ki,onToggleNoteBlock:Ni,onAddNoteBlock:za,onLocateNoteBlock:Fa,onGenerateNotesWithAI:Ha,isBatchProcessing:ja,onBatchAppendNotes:Wa,onBatchDeleteNotes:Ua,toggleElemClick:Va,onElemClickStepChange:Ka,onElemMotionChange:qa,onElemSlotChange:Ga,onElemShikiLinesChange:Za,onElemMaxHeightChange:Ya,onSetTwoColsContrast:Ja,onClearBlockAttrs:Xa,onInsertDividerBefore:Qa,onInsertDividerAfter:Qs,onDeleteCurrentBlock:ec,onExportHtml:tc,onExportPdf:ic}=w0({activeBlockId:s,activeBlockType:l,activeBlockAttrs:r,rawSnippet:a,currentDocId:c,currentPageDividerId:p,currentPageDividerLayout:b,parentContainerId:u,parentContainerClicks:f,latestDoc:g,targetSlide:N,currentSlideNoteBlockId:j,currentSlideLayout:G,isNoteBlock:K,elemClick:$,videoAutoplay:Z,videoLoop:Q,videoMuted:oe,videoControls:ie,pageBackground:F,pageImage:E,elemShikiLines:Y,elemMaxHeight:U,saveStatus:k,plugin:i});async function nc(J){if(J==="clover"){if(!await st())return}else Je(ue,J)}function oc(J){De(yt,J)}function sc(J){De(Vi,J)}function rc(J){De(Ki,J)}function lc(J){De(qi,J)}function ac(J){De(Gi,J)}function er(J){if(!J)return;const he=J.recommendedLayout||(J.colCount&&J.colCount>=2?"cols-header":"two-cols"),Ie=J.ratio||(J.colCount?Array(J.colCount).fill(1).join(":"):"1:1");Zt(he,Ie)}function cc(J){De(yt,J)}async function dc(){await Xe()}function uc(J){Je(tt,J)}function fc(J){F.value=J,Je(je,J)}function pc(J){E.value=J,Je(Bt,J)}function hc(J){Je(gn,J==="inherit"?"":J)}function mc(J){Ft(Cn,J)}function gc(J){Ft($n,J)}function vc(J){Ft(In,J)}function bc(J){Ft(ls,J)}function tr(){i!=null&&i.openBottomPreviewTab&&i.openBottomPreviewTab()}function yc(){typeof window<"u"&&window.open("/plugins/siyuan-slidev/slidev-client/presenter.html","SlidevPresenter","width=1200,height=800")}function kc(){i!=null&&i.executeCommand&&i.executeCommand("slidevAiSplit")}return t({setActiveBlock(J){s.value=J.id,l.value=J.type,r.value={...J.attrs},a.value=J.content||J.markdown||"",d.value=J.topBlockId||J.id,p.value=J.pageDividerId||"",b.value=J.pageDividerLayout||"",u.value=J.parentContainerId||"",h.value=J.parentContainerSlot||"",f.value=J.parentContainerClicks||"",J.rootId?c.value=J.rootId:(J.type==="doc"||J.type==="NodeDocument")&&J.id&&(c.value=J.id),F.value=J.attrs[je]||"",E.value=J.attrs[Bt]||"",Y.value=J.attrs[Oi]||"",U.value=J.attrs[En]||"",I.value=!!J.isImage},updateDocument(J){g.value=J,c.value=J.docId},openImportDialog(){n.value=!0},setCurrentDocId(J){c.value=J}}),(J,he)=>(ee(),te("div",S0,[m("div",_0,[m("div",C0,[(ee(),te("svg",$0,[...he[2]||(he[2]=[m("rect",{x:"2",y:"3",width:"20",height:"14",rx:"2"},null,-1),m("line",{x1:"8",y1:"21",x2:"16",y2:"21"},null,-1),m("line",{x1:"12",y1:"17",x2:"12",y2:"21"},null,-1)])])),he[3]||(he[3]=m("span",null,"演示配置",-1))]),m("div",I0,[m("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"导入 Slidev 演示文档 (.md / .zip)",onClick:he[0]||(he[0]=Ie=>n.value=!0)},[re(ce,{name:"import"}),he[4]||(he[4]=m("span",null,"导入",-1))]),m("button",{class:"spm-icon-btn is-primary b3-tooltips b3-tooltips__s","aria-label":"在下方分屏开启幻灯片预览 (Alt+P)",onClick:tr},[re(ce,{name:"split-preview"}),he[5]||(he[5]=m("span",null,"分屏预览",-1))])])]),m("div",E0,[m("div",T0,[m("span",{class:_e(["spm-target-tag",L.value])},we(_.value),3),m("span",{class:"spm-target-id b3-tooltips b3-tooltips__s","aria-label":S.value||"点击复制 ID: "+(s.value||c.value),onClick:C},[re(ce,{name:"copy"}),m("span",null,"#"+we(z.value),1)],8,A0)]),k.value?(ee(),te("span",B0,"● "+we(k.value),1)):Oe("",!0)]),V.value?(ee(),te("div",{key:0,class:"spm-context-quote",title:a.value},we(V.value),9,M0)):Oe("",!0),m("div",D0,[T.value?(ee(),Dt(Hv,{key:0,"page-layout":y.value,"page-layout-ratio":ge(se),"page-mask":ge(le),"page-mask-ratio":ge(pe),"page-mask-style":ge(Te),"page-mask-initial":ge(be),"detected-sb-ratio":O.value,"detected-sb-info":ve.value,"page-transition":A.value,"page-background":F.value,"page-spacing":D.value,"page-image":E.value,"page-notes":X.value,"page-index":v.value,"onUpdate:pageLayout":nc,"onUpdate:pageLayoutRatio":oc,"onUpdate:pageMask":sc,"onUpdate:pageMaskRatio":rc,"onUpdate:pageMaskStyle":lc,"onUpdate:pageMaskInitial":ac,onApplySuperBlockLayout:er,onResetSuperblockRatio:dc,"onUpdate:pageTransition":uc,"onUpdate:pageBackground":fc,"onUpdate:pageSpacing":hc,"onUpdate:pageImage":pc,onAddNoteBlock:ge(za),onLocateNoteBlock:ge(Fa),onGenerateNotes:ge(Ha),onBatchAppendNotes:ge(Wa),onBatchDeleteNotes:ge(Ua),"is-batch-processing":ge(ja),onInsertDividerAfter:ge(Qs),onDeleteDivider:ge(ec)},null,8,["page-layout","page-layout-ratio","page-mask","page-mask-ratio","page-mask-style","page-mask-initial","detected-sb-ratio","detected-sb-info","page-transition","page-background","page-spacing","page-image","page-notes","page-index","onAddNoteBlock","onLocateNoteBlock","onGenerateNotes","onBatchAppendNotes","onBatchDeleteNotes","is-batch-processing","onInsertDividerAfter","onDeleteDivider"])):s.value&&!R.value?(ee(),Dt(C1,{key:1,"elem-click":$.value,"elem-motion":x.value,"elem-slot":M.value,"elem-shiki-lines":Y.value,"elem-max-height":U.value,"is-code-block":B.value,"is-image":w.value,"is-video":P.value,"is-super-block":W.value,"detected-sb-info":ve.value,"video-autoplay":Z.value,"video-loop":Q.value,"video-muted":oe.value,"video-controls":ie.value,"has-block-attrs":Ge.value,"is-note":K.value,"image-role":Ve.value,"current-slide-layout":G.value,"parent-elem-click":f.value,"parent-container-slot":h.value,"parent-container-id":u.value,onToggleNote:ge(Ni),onToggleElemClick:ge(Va),onToggleVideoAutoplay:ge(Pi),onToggleVideoLoop:ge(zo),onToggleVideoMuted:ge(Fo),onToggleVideoControls:ge(Wn),"onUpdate:imageRole":ge(ki),"onUpdate:elemClick":ge(Ka),"onUpdate:elemMotion":ge(qa),"onUpdate:elemSlot":ge(Ga),"onUpdate:elemShikiLines":ge(Za),"onUpdate:elemMaxHeight":ge(Ya),onApplySuperBlockLayout:er,onApplySuperBlockRatio:cc,onInsertDividerBefore:ge(Qa),onInsertDividerAfter:ge(Qs),onSetTwoColsContrast:ge(Ja),onClearBlockAttrs:ge(Xa)},null,8,["elem-click","elem-motion","elem-slot","elem-shiki-lines","elem-max-height","is-code-block","is-image","is-video","is-super-block","detected-sb-info","video-autoplay","video-loop","video-muted","video-controls","has-block-attrs","is-note","image-role","current-slide-layout","parent-elem-click","parent-container-slot","parent-container-id","onToggleNote","onToggleElemClick","onToggleVideoAutoplay","onToggleVideoLoop","onToggleVideoMuted","onToggleVideoControls","onUpdate:imageRole","onUpdate:elemClick","onUpdate:elemMotion","onUpdate:elemSlot","onUpdate:elemShikiLines","onUpdate:elemMaxHeight","onInsertDividerBefore","onInsertDividerAfter","onSetTwoColsContrast","onClearBlockAttrs"])):(ee(),Dt(cy,{key:2,"doc-theme":de.value,"doc-aspect-ratio":Se.value,"doc-default-transition":ke.value,"doc-spacing":Me.value,"onUpdate:docTheme":mc,"onUpdate:docAspectRatio":gc,"onUpdate:docDefaultTransition":vc,"onUpdate:docSpacing":bc,onOpenBottomPreview:tr,onOpenPresenter:yc,onAiAutoSplit:kc,onExportHtml:ge(tc),onExportPdf:ge(ic)},null,8,["doc-theme","doc-aspect-ratio","doc-default-transition","doc-spacing","onExportHtml","onExportPdf"]))]),n.value?(ee(),Dt(h0,{key:1,onClose:he[1]||(he[1]=Ie=>n.value=!1),onSuccess:o})):Oe("",!0)]))}}),O0=2e3,R0=600;function P0(e){return!e||typeof e.closest!="function"?!1:!!e.closest(".fn__none")}function ns(e){if(!e||typeof e.isConnected=="boolean"&&!e.isConnected)return!1;if(Kr(e))return!0;const t=e.firstElementChild;return!!(t&&Kr(t))}function Kr(e){return typeof e.getClientRects=="function"&&e.getClientRects().length>0?!0:typeof e.offsetWidth=="number"&&e.offsetWidth>0&&e.offsetHeight>0}function N0(){const e=typeof globalThis<"u"?globalThis.IntersectionObserver:void 0;return typeof e=="function"?e:void 0}class z0{constructor(){ye(this,"consumers",new Map);ye(this,"seq",0);ye(this,"verifyTimer",null)}register(t,i,n){if(!i)return()=>{};const o=++this.seq,s=N0(),l={kind:t,element:i,visible:!1,measureOnDemand:!s,observer:null,onVisible:n};return s?(l.observer=new s(r=>{var d;const a=r[r.length-1];if(!a)return;const c=a.isIntersecting&&!l.visible;l.visible=a.isIntersecting,c&&((d=l.onVisible)==null||d.call(l))}),l.observer.observe(i)):l.visible=ns(i),this.consumers.set(o,l),()=>{var r;(r=l.observer)==null||r.disconnect(),this.consumers.delete(o),this.consumers.size===0&&this.stopVerifyTimer()}}clear(){var t;for(const i of this.consumers.values())(t=i.observer)==null||t.disconnect();this.consumers.clear(),this.stopVerifyTimer()}get size(){return this.consumers.size}getVisibility(){if(this.consumers.size===0)return"none";if(typeof document<"u"&&document.visibilityState==="hidden")return"hidden";for(const t of this.consumers.values())if(t.measureOnDemand?ns(t.element):this.isRecordVisible(t))return"visible";return this.ensureVerifyTimer(),"hidden"}hasVisibleConsumer(){return this.getVisibility()==="visible"}isRecordVisible(t){return t.visible?!0:!P0(t.element)}ensureVerifyTimer(){if(this.verifyTimer!==null||typeof setTimeout!="function")return;let t=!1;for(const i of this.consumers.values())if(!i.measureOnDemand){t=!0;break}t&&(this.verifyTimer=setTimeout(()=>{var i;this.verifyTimer=null;for(const n of this.consumers.values())if(!n.visible&&ns(n.element)){n.visible=!0,(i=n.onVisible)==null||i.call(n);return}},O0))}stopVerifyTimer(){this.verifyTimer!==null&&(clearTimeout(this.verifyTimer),this.verifyTimer=null)}}const so=new z0,jn=new Ys;function La(e,t,i){const n=()=>{var s;try{(s=i==null?void 0:i.flushDirtyCompile)==null||s.call(i)}catch{}},o=so.register(e,t,n);return n(),o}let gi=null,Lt=null,ro=null;function F0(){return Lt}function H0(e,t){gi&&Oa(),gi=da(Cg),gi.provide("plugin",t),gi.provide("sandboxBridge",jn);const i=gi.mount(e);return Lt=i,ro=La("preview",e,t),i}function Oa(e){ro&&(ro(),ro=null),gi&&(gi.unmount(),gi=null,Lt=null)}let vi=null,St=null,lo=null;function j0(e,t){vi&&Ra(),vi=da(L0),vi.provide("plugin",t),vi.provide("sandboxBridge",jn);const i=vi.mount(e);return St=i,lo=La("dock",e,t),i}function Ra(e){lo&&(lo(),lo=null),vi&&(vi.unmount(),vi=null,St=null)}function W0(e,t){St!=null&&St.updateDocument&&St.updateDocument(e),Lt!=null&&Lt.updateDocument?Lt.updateDocument(e,t):jn.updateSlides(e.slides,e.config,e.fullMarkdown)}function _s(e){Lt!=null&&Lt.navigateToBlock?Lt.navigateToBlock(e):jn.highlightElement(e)}function ao(e){St!=null&&St.setActiveBlock&&St.setActiveBlock(e)}function U0(){return St!=null&&St.openImportDialog?(St.openImportDialog(),!0):!1}function V0(e,t){const i=[];let o=0;for(let s=0;s<e.length;s++){const l=e[s];if(_o(l)){o=0;continue}const r=l.markdown||l.content||"";if(!(s===0)){if(l.type==="h"&&(l.subType==="h1"||r.startsWith("# "))){i.push({blockId:l.id,recommendedLayout:"cover",reason:"检测到一级核心章节标题，建议作为新幻灯片封面/大章"}),o=0;continue}if(l.type==="h"&&(l.subType==="h2"||r.startsWith("## "))){i.push({blockId:l.id,recommendedLayout:"default",reason:"检测到二级分论点标题，建议开启新页"}),o=0;continue}}if(o++,o>=6&&s<e.length-1){const c=e[s+1];_o(c)||(i.push({blockId:c.id,recommendedLayout:"default",reason:"当前页已达容量上限 (避免信息超载)，建议在此分页"}),o=0)}}return i}const K0=[{id:"slidev-cover",name:"幻灯片 - 封面页 (Cover)",open:!0,attrs:[{key:Ii,value:"true"},{key:ue,value:"cover"},{key:tt,value:"fade"}]},{id:"slidev-two-cols",name:"幻灯片 - 双栏对比 (Two Columns)",open:!0,attrs:[{key:Ii,value:"true"},{key:ue,value:"two-cols"},{key:tt,value:"slide-left"}]},{id:"slidev-fact",name:"幻灯片 - 大字报与核心指标 (Fact)",open:!0,attrs:[{key:Ii,value:"true"},{key:ue,value:"fact"},{key:tt,value:"zoom"}]},{id:"slidev-intro",name:"幻灯片 - 章节导引与作者 (Intro)",open:!0,attrs:[{key:Ii,value:"true"},{key:ue,value:"intro"},{key:tt,value:"slide-up"}]},{id:"slidev-quote",name:"幻灯片 - 金句与强调 (Quote)",open:!0,attrs:[{key:Ii,value:"true"},{key:ue,value:"quote"},{key:tt,value:"fade"}]},{id:"slidev-elem-click",name:"元素 - 顺延逐步呈现 (v-click)",open:!0,attrs:[{key:Ze,value:"+1"}]},{id:"slidev-elem-click-hide",name:"元素 - 隐藏直到激活 (v-click:hide)",open:!0,attrs:[{key:Ze,value:"hide"}]},{id:"slidev-elem-slot-right",name:"元素 - 双栏右栏归属 (Slot: Right)",open:!0,attrs:[{key:Ce,value:"right"}]},{id:"slidev-shiki-lines",name:"代码 - 逐行聚光高亮 (Shiki)",open:!0,attrs:[{key:Oi,value:"1-3"}]}];class os{getPresetTemplates(){return K0}buildScanSlidevBlocksSql(t="custom-slidev-"){return`SELECT block_id, name, value FROM attributes WHERE name LIKE '${t}%' ORDER BY block_id ASC`}buildTransitionStatsSql(){return`SELECT value, count(1) as count FROM attributes WHERE name = '${tt}' GROUP BY value ORDER BY count DESC`}async batchUpdateTransitions(t,i,n,o){const s=`SELECT block_id FROM attributes WHERE name = '${tt}' AND value = '${t}'`,l=await n(s);let r=0;if(Array.isArray(l))for(const a of l){const c=a.block_id||a.blockId;c&&(await o(c,{[tt]:i}),r++)}return{updatedCount:r}}async batchUpdateLayout(t,i,n,o){const s=`SELECT block_id FROM attributes WHERE name = 'custom-slidev-layout' AND value = '${t}'`,l=await n(s);let r=0;if(Array.isArray(l))for(const a of l){const c=a.block_id||a.blockId;c&&(await o(c,{"custom-slidev-layout":i}),r++)}return{updatedCount:r}}exportTemplatesJson(){const t=this.getPresetTemplates();return JSON.stringify({templates:t,counter:t.length},null,2)}formatTransitionSummary(t){return!t||t.length===0?"全库目前暂无已设置 Slidev 转场效果的块":`全库 Slidev 转场分布统计：${t.map(n=>`${n.value}: ${n.count} 个`).join("，")}`}}function q0(e){e.addCommand({langKey:"slidevPresentation",langText:"Slidev: 在文档下方开启分屏演示预览",hotkey:"⌥P",enabled:()=>!0,execute:()=>{e.openBottomPreviewTab()}}),e.addCommand({langKey:"slidevImport",langText:"Slidev: 导入 Slidev 演示文档 (.md / .zip)",hotkey:"⌥I",enabled:()=>!0,execute:()=>{U0()||me.showMessage("请先在右侧栏打开「Slidev 演示配置」Dock 面板以呼起导入窗口")}}),e.addCommand({langKey:"slidevInitAttrs",langText:"Slidev: 初始化当前文档演示属性",hotkey:"",enabled:()=>!0,execute:async()=>{if(!e.currentDocId){const t=document.querySelector(".protyle-content[data-doc-id]");e.currentDocId=(t==null?void 0:t.getAttribute("data-doc-id"))||""}e.currentDocId&&(await Ne(e.currentDocId,{"custom-slidev-theme":"default","custom-slidev-aspect-ratio":"16/9","custom-slidev-default-transition":"slide-left"}),me.showMessage("已为当前文档初始化 Slidev 演示属性"),e.compileCurrentDocument(e.currentDocId))}}),e.addCommand({langKey:"slidevAiSplit",langText:"Slidev AI: 智能大纲断页建议与自动分页",hotkey:"",enabled:()=>!0,execute:async()=>{if(!e.currentDocId){const s=document.querySelector(".protyle-content[data-doc-id]");e.currentDocId=(s==null?void 0:s.getAttribute("data-doc-id"))||""}if(!e.currentDocId){me.showMessage("请先打开一篇思源笔记文档");return}const t=await co(e.currentDocId).catch(()=>[]);if(!t||t.length===0){me.showMessage("当前文档无内容，无需断页");return}const i=t.map(s=>({id:s.id,type:s.type,subType:s.subType,content:s.content||"",markdown:s.markdown||""})),n=V0(i);if(n.length===0){me.showMessage("AI 分析完毕：当前文档篇幅合理，暂无分页建议");return}me.showMessage(`AI 分析完毕：发现 ${n.length} 处建议分页点，正在自动插入分页分割线...`);let o=0;for(const s of n)try{await Ti("markdown","---",void 0,s.blockId),await Ne(s.blockId,{"custom-slidev-layout":s.recommendedLayout}),o++}catch(l){console.warn("Failed to insert divider:",l)}me.showMessage(`已成功在 ${o} 处插入分页线并重新编译`),e.compileCurrentDocument(e.currentDocId)}}),e.addCommand({langKey:"slidevAiNotes",langText:"Slidev AI: 自动为当前文档生成演讲者提词卡 (Notes)",hotkey:"",enabled:()=>!0,execute:async()=>{var a,c,d,p;if(!e.currentDocId){const b=document.querySelector(".protyle-content[data-doc-id]");e.currentDocId=(b==null?void 0:b.getAttribute("data-doc-id"))||""}if(!e.currentDocId){me.showMessage("请先打开一篇思源笔记文档");return}me.showMessage("正在调用思源 AI 提炼演讲者口播提词...");const t=await co(e.currentDocId).catch(()=>[]),i={startBlockId:e.currentDocId,blocks:t.map(b=>({id:b.id,type:b.type,content:b.content||"",rawMarkdown:b.markdown||""})),rawMarkdown:""},s=`> [!NOTE] 💡 演讲备注
${(await b0(i,Jr)).split(/\r?\n/).map(b=>`> ${b}`).join(`
`)}
{: custom-slidev-note="true"}`,l=await ss("markdown",s,e.currentDocId).catch(()=>null),r=((d=(c=(a=l==null?void 0:l[0])==null?void 0:a.doOperations)==null?void 0:c[0])==null?void 0:d.id)||((p=l==null?void 0:l[0])==null?void 0:p.id);r&&(await Ne(r,{"custom-slidev-note":"true"}),Be.setBlockAttrOverride(r,{"custom-slidev-note":"true"}),Li(r,e.app)),me.showMessage("已成功生成口播提词卡并插入为正文讲稿备注块"),e.compileCurrentDocument(e.currentDocId)}}),e.addCommand({langKey:"slidevBatchTransitions",langText:"Slidev 协同: 统计全库转场效果分布",hotkey:"",enabled:()=>!0,execute:async()=>{const t=new os,i=t.buildTransitionStatsSql(),n=await en(i).catch(()=>[]),o=t.formatTransitionSummary(n||[]);me.showMessage(o)}}),e.addCommand({langKey:"slidevExportTemplates",langText:"Slidev 协同: 复制 Slidev 预设属性模板至剪贴板",hotkey:"",enabled:()=>!0,execute:async()=>{const i=new os().exportTemplatesJson();typeof navigator<"u"&&navigator.clipboard?(await navigator.clipboard.writeText(i),me.showMessage("已将 Slidev 属性模板 JSON 复制至剪贴板，可直接导入属性管家")):me.showMessage(`已生成模板数据（请在控制台查看）：
`+i)}}),e.addCommand({langKey:"slidevBatchReplaceTransition",langText:"Slidev 协同: 批量替换全库淡入淡出转场为滑动 (fade -> slide-left)",hotkey:"",enabled:()=>!0,execute:async()=>{const i=await new os().batchUpdateTransitions("fade","slide-left",n=>en(n).catch(()=>[]),(n,o)=>Ne(n,o));me.showMessage(`全库批量替换完成：已将 ${i.updatedCount} 处 fade 转场更新为 slide-left`),e.compileCurrentDocument()}}),e.addCommand({langKey:"slidevPresenterMode",langText:"Slidev: 打开双屏演讲者控制台 (Presenter Mode)",hotkey:"⌥M",enabled:()=>!0,execute:()=>{typeof window<"u"&&window.open("/plugins/siyuan-slidev/slidev-client/presenter.html","SlidevPresenter","width=1200,height=800")}}),e.addCommand({langKey:"slidevExportCliMd",langText:"Slidev Pro: 导出 Slidev 标准 slides.md 文档 (下载到本地)",hotkey:"",enabled:()=>!0,execute:async()=>{if(e.latestCompiledDoc||await e.compileCurrentDocument(),!e.latestCompiledDoc){me.showMessage("请先打开并放映一篇思源笔记文档");return}e.cliBridge.downloadSlidesMd(e.latestCompiledDoc,`slides-${e.currentDocId||"demo"}.md`)&&me.showMessage("已生成标准 Slidev Markdown 并触发下载，可在本地使用 npx @slidev/cli 运行")}}),e.addCommand({langKey:"slidevProbeCliDevServer",langText:"Slidev Pro: 检测本地 Slidev CLI DevServer 状态 (localhost:3030)",hotkey:"",enabled:()=>!0,execute:async()=>{me.showMessage("正在探测本地 Slidev CLI DevServer (http://localhost:3030)..."),await e.cliBridge.probeServer(1500)?me.showMessage("🟢 本地 Slidev CLI DevServer 运行正常！可直接在浏览器访问 http://localhost:3030"):me.showMessage("⚪ 未检测到运行中的本地 Slidev CLI DevServer (端口 3030 未开启)")}}),e.addCommand({langKey:"slidevSyncToCliWorkspace",langText:"Slidev Pro: 同步 slides.md 至思源工作空间存储目录",hotkey:"",enabled:()=>!0,execute:async()=>{if(e.latestCompiledDoc||await e.compileCurrentDocument(),!e.latestCompiledDoc){me.showMessage("请先打开并放映一篇思源笔记文档");return}const t=await e.cliBridge.syncToWorkspaceFile(e.latestCompiledDoc,"/data/storage/petal/siyuan-slidev/slides.md",rs);t.success?me.showMessage(`已成功同步最新 slides.md 至工作空间：${t.path}`):me.showMessage(`同步失败：${t.error}`)}})}function Pa(e){const t=(e||"").trim();return t?`即现（${t}）`:"即现"}async function Na(e,t){var i,n,o;if(!t)return"";if(typeof document<"u"){const s=document.querySelector(`.protyle-title[data-node-id="${t}"] .protyle-title__input`)||document.querySelector(`.protyle[data-doc-id="${t}"] .protyle-title__input`)||(e.getActiveDocumentId()===t?document.querySelector(".layout__wnd--active .protyle-title__input"):null)||document.querySelector(".protyle-title__input"),l=((s==null?void 0:s.innerText)||(s==null?void 0:s.textContent)||"").trim();if(l)return l}if(e.latestCompiledDoc&&e.latestCompiledDoc.docId===t){const s=(i=e.latestCompiledDoc.slides)==null?void 0:i[0],l=(n=s==null?void 0:s.blocks)==null?void 0:n.find(r=>r.type==="h"||r.type==="NodeHeading");if(l!=null&&l.content)return l.content.trim()}try{const s=await en(`SELECT content FROM blocks WHERE id = '${t}' AND type = 'd' LIMIT 1`).catch(()=>[]);if(Array.isArray(s)&&s.length>0&&((o=s[0])!=null&&o.content))return String(s[0].content).trim()}catch{}return""}async function G0(e,t,i){var c,d,p;const n=F0(),o=!!((c=n==null?void 0:n.isPinned)!=null&&c.value),s=String(((d=n==null?void 0:n.pinnedDocId)==null?void 0:d.value)||"");if(o&&s&&i&&i!==s)return;const l=i||(o&&s?s:e.currentDocId||e.getActiveDocumentId());let r=(t||"").trim();!r&&l&&(r=typeof e.fetchDocumentTitle=="function"?await e.fetchDocumentTitle(l):await Na(e,l));const a=Pa(r);if(e.previewTab&&typeof e.previewTab.updateTitle=="function"){e.previewTab.updateTitle(a),e.previewTab.headElement&&e.previewTab.headElement.setAttribute("title",a);return}if(typeof document<"u"){const b=Array.from(document.querySelectorAll('.layout-tab-bar .item[data-type="tab-header"]'));for(const u of b){const h=u.querySelector(".item__text"),f=((p=h==null?void 0:h.textContent)==null?void 0:p.trim())||"";if(f.includes("Slidev 演示预览")||f.startsWith("即现")){h&&(h.textContent=a),u.setAttribute("title",a);break}}}}class Z0{constructor(t=400){ye(this,"entries",new Map);this.ttlMs=t}get(t,i=Date.now()){if(!t)return;const n=this.entries.get(t);if(n){if(i-n.at>this.ttlMs){this.entries.delete(t);return}return n.attrs}}set(t,i,n=Date.now()){!t||!i||this.entries.set(t,{attrs:i,at:n})}invalidate(t){t?this.entries.delete(t):this.entries.clear()}get size(){return this.entries.size}}function Y0(e){const t=new Map;if(!(e!=null&&e.slides))return t;const i=n=>{for(const o of n||[])o!=null&&o.id&&o.ial&&t.set(o.id,o.ial)};for(const n of e.slides)i(n.blocks),i(n.noteBlocks);return t}class J0{constructor(t=150){ye(this,"lastBlockId","");ye(this,"lastAt",0);this.windowMs=t}shouldSkip(t,i=Date.now()){return t&&t===this.lastBlockId&&i-this.lastAt<this.windowMs?!0:(this.lastBlockId=t,this.lastAt=i,!1)}reset(){this.lastBlockId="",this.lastAt=0}}class X0{constructor(){ye(this,"attrCache",new Z0);ye(this,"compiledIalIndex",{doc:null,map:new Map})}async resolveBlockAttrs(t,i){if(!t)return{};const n=Be.getBlockAttrOverride(t),o=this.getCompiledIal(i,t);if(n||o)return{...o||{},...n||{}};const s=this.attrCache.get(t);if(s)return s;const l=await Cs(t).catch(()=>({}))||{};return this.attrCache.set(t,l),l}getCompiledIal(t,i){if(t)return this.compiledIalIndex.doc!==t&&(this.compiledIalIndex={doc:t,map:Y0(t)}),this.compiledIalIndex.map.get(i)}invalidateAttrCache(t){this.attrCache.invalidate(t)}getActiveDocumentId(){if(typeof document>"u")return"";const t=document.querySelector(".layout__wnd--active .protyle-title[data-node-id]")||document.querySelector(".item--focus .protyle-title[data-node-id]")||document.querySelector(".protyle-title[data-node-id]"),i=t==null?void 0:t.getAttribute("data-node-id");if(i)return i;const n=document.querySelector(".protyle .protyle-title[data-node-id]"),o=n==null?void 0:n.getAttribute("data-node-id");if(o)return o;const s=document.querySelector("[data-doc-id]"),l=s==null?void 0:s.getAttribute("data-doc-id");return l||""}resolveDocIdFromElement(t,i=""){const n=t.closest(".protyle-title"),o=n==null?void 0:n.getAttribute("data-node-id");if(o)return o;const s=t.closest(".protyle"),l=s==null?void 0:s.querySelector(".protyle-title"),r=l==null?void 0:l.getAttribute("data-node-id");if(r)return r;const a=t.closest("[data-doc-id]"),c=a==null?void 0:a.getAttribute("data-doc-id");if(c)return c;const d=this.getActiveDocumentId();return d||i}async switchToDocGlobalInspector(t,i){var s;if(!t)return;let n=i||"";if(!n&&typeof document<"u"){const l=document.querySelector(`.protyle-title[data-node-id="${t}"] .protyle-title__input`)||document.querySelector(`.protyle[data-doc-id="${t}"] .protyle-title__input`)||document.querySelector(".protyle-title__input");n=((s=l==null?void 0:l.innerText)==null?void 0:s.trim())||""}const o=await this.resolveBlockAttrs(t,null);ao({id:t,rootId:t,type:"doc",content:n,attrs:o,isDivider:!1,isCode:!1}),_s(t)}handleBlockClickedFromSlide(t,i,n,o){var a;if(!t)return!1;const s=Li(t,i),l=document.querySelector(`.protyle-wysiwyg [data-node-id="${t}"]`)||document.querySelector(`[data-node-id="${t}"]`),r=(l==null?void 0:l.getAttribute("data-type"))||"";if(l)this.syncInspectorBlock(l,t,r,n,o);else{let c="",d="";if(o!=null&&o.slides){const p=o.slides.find(b=>{var u,h,f;return b.startBlockId===t||((u=b.blocks)==null?void 0:u.some(g=>g.id===t))||((h=b.allBlockIds)==null?void 0:h.includes(t))||((f=b.noteBlocks)==null?void 0:f.some(g=>g.id===t))});p!=null&&p.startBlockId&&(c=p.startBlockId),(a=p==null?void 0:p.frontmatter)!=null&&a.layout&&(d=p.frontmatter.layout)}this.resolveBlockAttrs(t,o).then(async p=>{if(c&&!d){const b=Be.getBlockAttrOverride(c);if(b!=null&&b[ue]||b!=null&&b["custom-slidev-layout"])d=b[ue]||b["custom-slidev-layout"]||"";else{const u=await this.resolveBlockAttrs(c,o);d=u[ue]||u["custom-slidev-layout"]||"",u&&Object.keys(u).length>0&&Be.setBlockAttrOverride(c,u)}}ao({id:t,rootId:n,type:r||"NodeParagraph",attrs:p||{},pageDividerId:c,pageDividerLayout:d})}).catch(()=>{})}return s}async syncInspectorBlock(t,i,n,o,s){var A,F,E,D,N,X,j,G;let l=t,r=i,a=n;const c=t.closest('[data-type="NodeCallout"]');if(c&&c!==t){const ne=c.getAttribute("data-node-id");if(ne){const se=await this.resolveBlockAttrs(ne,s),le=Be.getBlockAttrOverride(ne)||{},pe={...se,...le};(pe[nt]||pe["slidev-note"])&&(l=c,r=ne,a="NodeCallout")}}const d=l.closest(".protyle-wysiwyg > [data-node-id]")||l,p=(d==null?void 0:d.getAttribute("data-node-id"))||r,b=a==="NodeThematicBreak"||a==="tb"||a==="thematic-break"||(d==null?void 0:d.getAttribute("data-type"))==="NodeThematicBreak"||(d==null?void 0:d.getAttribute("data-type"))==="tb"||!!((A=d==null?void 0:d.classList)!=null&&A.contains("hr")),u=a==="NodeCodeBlock",h=((F=l.innerText)==null?void 0:F.trim())||"",f=await this.resolveBlockAttrs(r,s),g=Be.getBlockAttrOverride(r)||{},k={...f,...g};let S="",C="";if(b)S=r,C=k[ue]||k["custom-slidev-layout"]||"";else{let ne=d.previousElementSibling;for(;ne;){const se=ne.getAttribute("data-type");if(se==="NodeThematicBreak"||se==="tb"||(E=ne.classList)!=null&&E.contains("hr")){S=ne.getAttribute("data-node-id")||"";break}ne=ne.previousElementSibling}}if(s!=null&&s.slides){const ne=[r,p];let se=l.parentElement;for(;se&&!se.classList.contains("protyle-wysiwyg");){const pe=se.getAttribute("data-node-id");pe&&!ne.includes(pe)&&ne.push(pe),se=se.parentElement}const le=s.slides.find(pe=>{var Te,be,q;return ne.includes(pe.startBlockId)||((Te=pe.blocks)==null?void 0:Te.some(ae=>ne.includes(ae.id)))||((be=pe.allBlockIds)==null?void 0:be.some(ae=>ne.includes(ae)))||((q=pe.noteBlocks)==null?void 0:q.some(ae=>ne.includes(ae.id)))});le&&(!S&&le.startBlockId&&(S=le.startBlockId),!C&&((D=le.frontmatter)!=null&&D.layout)&&(C=le.frontmatter.layout))}if(S){const ne=Be.getBlockAttrOverride(S);if(ne&&(ue in ne||"custom-slidev-layout"in ne)&&(C=ne[ue]||ne["custom-slidev-layout"]||""),!C&&(s!=null&&s.slides)){const se=s.slides.find(le=>le.startBlockId===S);(N=se==null?void 0:se.frontmatter)!=null&&N.layout&&(C=se.frontmatter.layout)}if(!C){const se=await this.resolveBlockAttrs(S,s);C=se[ue]||se["custom-slidev-layout"]||"",se&&Object.keys(se).length>0&&Be.setBlockAttrOverride(S,se)}et(S,{[ue]:C||""})}else if(o){const ne=Be.getBlockAttrOverride(o);ne&&(ue in ne||"custom-slidev-layout"in ne)?C=ne[ue]||ne["custom-slidev-layout"]||"":!C&&((G=(j=(X=s==null?void 0:s.slides)==null?void 0:X[0])==null?void 0:j.frontmatter)!=null&&G.layout)&&(C=s.slides[0].frontmatter.layout)}const T=l.getAttribute(ue)||l.getAttribute("custom-slidev-layout"),B=k[ue]||k["custom-slidev-layout"]||"";T&&T!==B&&et(r,{[ue]:B});const I=l.getAttribute(qe)||l.getAttribute("custom-slidev-role"),w=k[qe]||k["custom-slidev-role"]||"";I&&I!==w&&et(r,{[qe]:w});let P="",R="",z="";const V=l.closest('[data-type="NodeListItem"]');if(V&&V!==l){const ne=V.getAttribute("data-node-id");if(ne){P=ne;const se=await this.resolveBlockAttrs(ne,s),le=Be.getBlockAttrOverride(ne)||{},pe={...se,...le};R=pe[Ce]||"",z=pe[Ze]||"";const Te=pe[ue]||pe["custom-slidev-layout"]||"",be=V.getAttribute(ue)||V.getAttribute("custom-slidev-layout");be&&be!==Te&&et(ne,{[ue]:Te});const q=pe[qe]||pe["custom-slidev-role"]||"",ae=V.getAttribute(qe)||V.getAttribute("custom-slidev-role");ae&&ae!==q&&et(ne,{[qe]:q})}}const _=!!l.querySelector("img, span[data-type='img']"),L=(l.innerText||"").replace(/[\r\n\t\s]+/g," ").trim(),y=_&&L.length<=50;ao({id:r,rootId:o,type:a,content:h,attrs:k,isDivider:b,isCode:u,isImage:y,topBlockId:p,pageDividerId:S,pageDividerLayout:C,parentContainerId:P,parentContainerSlot:R,parentContainerClicks:z})}patchThematicBreakTransactions(t){if((t==null?void 0:t.cmd)==="transactions"&&Array.isArray(t.data)){for(const i of t.data)if(Array.isArray(i==null?void 0:i.doOperations)){for(const n of i.doOperations)if((n==null?void 0:n.action)==="updateAttrs"&&n.id&&n.data){const o=n.data.old||{},s=n.data.new||{},l={};for(const r of Object.keys(o))r in s||(l[r]="");for(const[r,a]of Object.entries(s))l[r]=String(a??"");et(n.id,l),Be.setBlockAttrOverride(n.id,l)}}}}purgeStaleDomSlidevAttrs(t){var o,s,l;if(typeof document>"u"||!t)return;const i=new Map;if(Array.isArray(t.slides))for(const r of t.slides){if(r.startBlockId){const a=i.get(r.startBlockId)||{};(o=r.frontmatter)!=null&&o.layout&&(a[ue]=r.frontmatter.layout),i.set(r.startBlockId,a)}if(Array.isArray(r.blocks)){for(const a of r.blocks)if(a.id){const c=i.get(a.id)||{};(s=a.ial)!=null&&s[ue]&&(c[ue]=a.ial[ue]),(l=a.ial)!=null&&l[qe]&&(c[qe]=a.ial[qe]),Object.keys(c).length>0&&i.set(a.id,c)}}}const n=Be.getAllAttrOverrides();for(const[r,a]of n.entries()){const c=i.get(r)||{};a[ue]!==void 0&&(c[ue]=a[ue]),a[qe]!==void 0&&(c[qe]=a[qe]),i.set(r,c)}ah(i)}}const Ci=new X0;class Q0{constructor(){ye(this,"inFlightDocId",null);ye(this,"pendingDocId",null);ye(this,"generation",0)}get isRunning(){return this.inFlightDocId!==null}get runningDocId(){return this.inFlightDocId}get pending(){return this.pendingDocId}tryBegin(t){return this.inFlightDocId!==null?(this.pendingDocId=t,null):(this.inFlightDocId=t,++this.generation)}isStale(t){return t!==this.generation}finish(){this.inFlightDocId=null;const t=this.pendingDocId;return this.pendingDocId=null,t}reset(){this.inFlightDocId=null,this.pendingDocId=null,this.generation=0}}const ek=150,tk=`<symbol id="iconSlidev" viewBox="0 0 1024 1024">
  <path fill="currentColor" d="M128 160h768c35.3 0 64 28.7 64 64v480c0 35.3-28.7 64-64 64H128c-35.3 0-64-28.7-64-64V224c0-35.3 28.7-64 64-64z m64 64v480h640V224H192z m128 640h384v64H320z"/>
  <path fill="currentColor" d="M416 336l256 144-256 144z"/>
</symbol>`,ik="slidev-dock",qr="slidev-preview-tab",Gr=uf;class nk extends me.Plugin{constructor(){super(...arguments);ye(this,"isMobile",!1);ye(this,"currentDocId","");ye(this,"previewTab",null);ye(this,"latestCompiledDoc",null);ye(this,"cliBridge",new qs);ye(this,"debounceTimer",null);ye(this,"activeCursorBlockId","");ye(this,"compileScheduler",new Q0);ye(this,"dirtyDocId",null);ye(this,"inspectorSyncThrottle",new J0);ye(this,"onSwitchProtyleBound",this.onSwitchProtyle.bind(this));ye(this,"onWsMainBound",this.onWsMain.bind(this));ye(this,"onBlockClickedBound",this.onBlockClickedFromSlide.bind(this));ye(this,"onEditorClickBound",this.onEditorClick.bind(this));ye(this,"onSelectionChangeBound",this.onSelectionChange.bind(this));ye(this,"onClickEditorContentBound",this.onClickEditorContent.bind(this));ye(this,"onVisibilityChangeBound",this.onVisibilityChange.bind(this))}async onload(){const i=me.getFrontend();this.isMobile=i==="mobile"||i==="browser-mobile",await this.loadGlobalSettings(),this.addIcons(tk),this.addTopBar({id:"slidev-topbar-play",icon:"iconSlidev",title:"即现演示",position:"right",callback:()=>{this.openBottomPreviewTab()}}),q0(this);const n=this;if(this.addTab({type:qr,init(o){const s=this||o;n.previewTab=(s==null?void 0:s.tab)||null,H0(s.element,n),n.updatePreviewTabHeader()},destroy(){n.previewTab===(this==null?void 0:this.tab)&&(n.previewTab=null),Oa(this.element)}}),this.addDock({config:{position:"RightTop",size:{width:320,height:0},icon:"iconSlidev",title:"Slidev 演示配置"},data:{},type:ik,init(){j0(this.element,n)},destroy(){Ra(this.element)}}),this.eventBus&&typeof this.eventBus.emit!="function"&&(this.eventBus.emit=(o,s)=>{try{typeof window<"u"&&window.dispatchEvent(new CustomEvent(`siyuan-event-${o}`,{detail:s}))}catch{}}),this.eventBus.on("switch-protyle",this.onSwitchProtyleBound),this.eventBus.on("ws-main",this.onWsMainBound),this.eventBus.on("slidev:request-compile",()=>this.compileCurrentDocument()),this.eventBus.on("slidev:block-clicked",this.onBlockClickedBound),this.eventBus.on("click-editorcontent",this.onClickEditorContentBound),typeof document<"u"&&(document.addEventListener("click",this.onEditorClickBound,!0),document.addEventListener("selectionchange",this.onSelectionChangeBound),document.addEventListener("visibilitychange",this.onVisibilityChangeBound)),typeof document<"u"){const o=()=>{const s=this.getActiveDocumentId();s&&(s!==this.currentDocId&&(this.currentDocId=s,this.updatePreviewTabHeader("",s)),this.latestCompiledDoc||this.markCompileDirty(s))};setTimeout(o,300),setTimeout(o,1e3)}}async onDataChanged(i){await this.loadGlobalSettings(),this.currentDocId&&this.markCompileDirty(this.currentDocId)}async loadGlobalSettings(){try{const i=await this.loadData(Gr),n=ff(i);return Ai(n),n}catch{return Ai(sn),sn}}async saveGlobalSettings(i){const n=No(),o=Ai({...n,...i||{}});try{await this.saveData(Gr,o)}catch(l){console.error("保存 Slidev 全局配置失败",l)}const s=this.currentDocId||this.getActiveDocumentId();return s&&this.markCompileDirty(s),o}onunload(){this.debounceTimer&&(window.clearTimeout(this.debounceTimer),this.debounceTimer=null),this.compileScheduler.reset(),this.inspectorSyncThrottle.reset(),this.dirtyDocId=null,so.clear(),this.eventBus.off("switch-protyle",this.onSwitchProtyleBound),this.eventBus.off("ws-main",this.onWsMainBound),this.eventBus.off("click-editorcontent",this.onClickEditorContentBound),typeof document<"u"&&(document.removeEventListener("click",this.onEditorClickBound,!0),document.removeEventListener("selectionchange",this.onSelectionChangeBound),document.removeEventListener("visibilitychange",this.onVisibilityChangeBound)),jn.detach()}onVisibilityChange(){typeof document<"u"&&document.visibilityState==="visible"&&this.flushDirtyCompile()}async openBottomPreviewTab(){this.currentDocId||(this.currentDocId=this.getActiveDocumentId());const i=this.currentDocId?await this.fetchDocumentTitle(this.currentDocId):"",n=this.buildPreviewTabTitle(i);await me.openTab({app:this.app,custom:{id:this.name+qr,title:n,icon:"iconSlidev",data:{docId:this.currentDocId}},position:"bottom"}),this.currentDocId&&this.compileCurrentDocument(this.currentDocId),this.updatePreviewTabHeader(i,this.currentDocId)}async onSwitchProtyle(i){var l,r,a,c,d;const n=(l=i.detail)==null?void 0:l.protyle,o=(r=n==null?void 0:n.block)==null?void 0:r.rootID,s=((d=(c=(a=n==null?void 0:n.title)==null?void 0:a.editElement)==null?void 0:c.textContent)==null?void 0:d.trim())||"";if(o&&o!==this.currentDocId){this.currentDocId=o,this.activeCursorBlockId=o;const p=await Cs(o).catch(()=>({}));ao({id:o,rootId:o,type:"doc",attrs:p}),this.markCompileDirty(o),this.updatePreviewTabHeader(s,o)}}onClickEditorContent(i){var s,l;const n=i==null?void 0:i.detail;if(!n)return;const o=(l=(s=n.protyle)==null?void 0:s.block)==null?void 0:l.rootID;o&&(!this.currentDocId||this.currentDocId!==o)&&(this.currentDocId=o),n.event&&this.onEditorClick(n.event)}buildPreviewTabTitle(i){return Pa(i)}async fetchDocumentTitle(i){return Na(this,i)}async updatePreviewTabHeader(i,n){return G0(this,i,n)}getActiveDocumentId(){return Ci.getActiveDocumentId()}resolveDocIdFromElement(i){return Ci.resolveDocIdFromElement(i,this.currentDocId)}async switchToDocGlobalInspector(i,n){i&&(this.activeCursorBlockId=i,this.currentDocId=i,await Ci.switchToDocGlobalInspector(i,n))}onWsMain(i){const n=i.detail;n&&n.cmd==="transactions"&&(Ci.patchThematicBreakTransactions(n),this.markCompileDirty())}markCompileDirty(i){const n=i||this.currentDocId||this.getActiveDocumentId();n&&(this.currentDocId||(this.currentDocId=n),this.dirtyDocId=n,this.scheduleDirtyCompile())}scheduleDirtyCompile(i=ek){if(this.debounceTimer&&(window.clearTimeout(this.debounceTimer),this.debounceTimer=null),!this.dirtyDocId)return;const n=so.getVisibility();if(n==="none")return;const o=n==="visible"?i:Math.max(i,R0);this.debounceTimer=window.setTimeout(()=>{this.debounceTimer=null;const s=this.dirtyDocId;this.dirtyDocId=null,s&&this.compileCurrentDocument(s,{reason:"auto"})},o)}flushDirtyCompile(){this.dirtyDocId&&this.scheduleDirtyCompile(0)}handleBlockClickedFromSlide(i,n){return i?(this.activeCursorBlockId=i,Ci.handleBlockClickedFromSlide(i,this.app,this.currentDocId,this.latestCompiledDoc)):!1}onBlockClickedFromSlide(i){const n=(i==null?void 0:i.detail)||i;n!=null&&n.blockId&&this.handleBlockClickedFromSlide(n.blockId,n.page)}onEditorClick(i){const n=i.target;if(!n)return;const o=n.closest(".protyle-title")||n.closest(".protyle-background");if(!!(o||n.closest(".protyle-content")&&!n.closest(".protyle-wysiwyg")&&!n.closest(".protyle-breadcrumb")&&!n.closest(".protyle-gutters"))){const d=this.resolveDocIdFromElement(n);if(d&&this.activeCursorBlockId!==d){const p=o||document.querySelector(`.protyle-title[data-node-id="${d}"]`)||document.querySelector(`.protyle[data-doc-id="${d}"] .protyle-title`),b=p==null?void 0:p.querySelector(".protyle-title__input"),u=((b==null?void 0:b.innerText)||(p==null?void 0:p.innerText)||"").trim();this.switchToDocGlobalInspector(d,u)}return}if(!n.closest(".protyle-wysiwyg"))return;const r=n.closest("[data-node-id]");if(!r)return;const a=r.getAttribute("data-node-id"),c=r.getAttribute("data-type")||"";a&&(this.currentDocId||(this.currentDocId=this.resolveDocIdFromElement(n)||""),this.currentDocId&&!this.latestCompiledDoc&&this.markCompileDirty(this.currentDocId),a!==this.activeCursorBlockId&&(this.activeCursorBlockId=a,_s(a)),this.syncInspectorBlock(r,a,c))}onSelectionChange(){if(typeof window>"u")return;const i=window.getSelection();if(!i||i.rangeCount===0)return;const n=i.anchorNode;if(!n)return;const o=n.nodeType===Node.ELEMENT_NODE?n:n.parentElement;if(!o)return;const s=o.closest(".protyle-title");if(!!(s||o.closest(".protyle-content")&&!o.closest(".protyle-wysiwyg"))){const d=this.resolveDocIdFromElement(o);if(d&&this.activeCursorBlockId!==d){const p=s||document.querySelector(`.protyle-title[data-node-id="${d}"]`)||document.querySelector(`.protyle[data-doc-id="${d}"] .protyle-title`),b=p==null?void 0:p.querySelector(".protyle-title__input"),u=((b==null?void 0:b.innerText)||(p==null?void 0:p.innerText)||"").trim();this.switchToDocGlobalInspector(d,u)}return}if(!o.closest(".protyle-wysiwyg"))return;const r=o.closest("[data-node-id]"),a=r==null?void 0:r.getAttribute("data-node-id"),c=(r==null?void 0:r.getAttribute("data-type"))||"";r&&a&&(this.currentDocId||(this.currentDocId=this.resolveDocIdFromElement(o)||""),this.currentDocId&&!this.latestCompiledDoc&&this.markCompileDirty(this.currentDocId),a!==this.activeCursorBlockId&&(this.activeCursorBlockId=a,_s(a)),this.syncInspectorBlock(r,a,c))}async syncInspectorBlock(i,n,o){this.inspectorSyncThrottle.shouldSkip(n)||await Ci.syncInspectorBlock(i,n,o,this.currentDocId,this.latestCompiledDoc)}async compileCurrentDocument(i,n){const o=(n==null?void 0:n.reason)??"explicit";let s=i||this.currentDocId;if(!s){const r=this.getActiveDocumentId();if(r)this.currentDocId=r,s=r;else return}if(o==="auto"&&so.getVisibility()==="none"){this.dirtyDocId=s;return}const l=this.compileScheduler.tryBegin(s);if(l!==null){this.dirtyDocId===s&&(this.dirtyDocId=null);try{const r=await Be.compile(s),a=!!this.currentDocId&&s!==this.currentDocId;!this.compileScheduler.isStale(l)&&!a&&(this.currentDocId||(this.currentDocId=s),this.latestCompiledDoc=r,W0(r,s),this.updatePreviewTabHeader("",s),this.purgeStaleDomSlidevAttrs(r))}catch(r){console.error("[SiYuanSlidev] Failed to compile document:",r)}finally{const r=this.compileScheduler.finish();r&&this.markCompileDirty(r)}}}purgeStaleDomSlidevAttrs(i){Ci.purgeStaleDomSlidevAttrs(i)}}module.exports=nk;
