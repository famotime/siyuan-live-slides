"use strict";var qa=Object.create;var Ro=Object.defineProperty;var Ka=Object.getOwnPropertyDescriptor;var Ga=Object.getOwnPropertyNames;var Za=Object.getPrototypeOf,Ya=Object.prototype.hasOwnProperty;var Ja=(t,i,e)=>i in t?Ro(t,i,{enumerable:!0,configurable:!0,writable:!0,value:e}):t[i]=e;var Xa=(t,i,e,n)=>{if(i&&typeof i=="object"||typeof i=="function")for(let o of Ga(i))!Ya.call(t,o)&&o!==e&&Ro(t,o,{get:()=>i[o],enumerable:!(n=Ka(i,o))||n.enumerable});return t};var jn=(t,i,e)=>(e=t!=null?qa(Za(t)):{},Xa(i||!t||!t.__esModule?Ro(e,"default",{value:t,enumerable:!0}):e,t));var xt=(t,i,e)=>Ja(t,typeof i!="symbol"?i+"":i,e);const ht=require("siyuan");async function ye(t,i){const e=await ht.fetchSyncPost(t,i);return e.code===0?e.data:null}async function Qa(){return ye("/api/notebook/lsNotebooks","")}async function tc(t,i,e){return ye("/api/filetree/createDocWithMd",{notebook:t,path:i,markdown:e})}async function Or(t,i){const e=new FormData;e.append("assetsDirPath",t);for(const o of i)e.append("file[]",o);return ye("/api/asset/upload",e)}async function Ii(t,i,e,n,o){return ye("/api/block/insertBlock",{dataType:t,data:i,nextID:e,previousID:n,parentID:o})}async function Xo(t,i,e){return ye("/api/block/appendBlock",{dataType:t,data:i,parentID:e})}async function qs(t,i,e){return ye("/api/block/updateBlock",{dataType:t,data:i,id:e})}async function Ks(t){return ye("/api/block/deleteBlock",{id:t})}async function ec(t){return ye("/api/block/getBlockKramdown",{id:t})}async function no(t){return ye("/api/block/getChildBlocks",{id:t})}async function Dt(t,i){return ye("/api/attr/setBlockAttrs",{id:t,attrs:i})}async function Ze(t){return ye("/api/attr/getBlockAttrs",{id:t})}async function wn(t){return ye("/api/query/sql",{stmt:t})}async function Qo(t,i,e){const n=new FormData;return n.append("path",t),n.append("isDir",i.toString()),n.append("modTime",Math.floor(Date.now()/1e3).toString()),n.append("file",e),ye("/api/file/putFile",n)}async function zr(t){const i="/api/ai/chatGPT";try{const e=await ye(i,{msg:t});return typeof e=="string"&&e.trim().length>0?e.trim():e&&typeof e.content=="string"&&e.content.trim().length>0?e.content.trim():null}catch{return null}}async function ic(){return ye("/api/storage/getInlineStyles","")}const Nr=/\(\(([0-9a-zA-Z-]+)(?:\s*(?:'([^']*)'|"([^"]*)"|([^\)]+?)))?\s*\)\)/g;function nc(t){const i=[];if(!t)return i;const e=new RegExp(Nr.source,"g");let n;for(;(n=e.exec(t))!==null;){const o=n[2]??n[3]??n[4];i.push({fullMatch:n[0],blockId:n[1],anchorText:o?o.trim():void 0})}return i}function oc(t,i){if(!t)return"";const e=new RegExp(Nr.source,"g");return t.replace(e,(n,o,s,l,r)=>{const a=(s??l??r??"").trim();if(i&&i[o]){const u=i[o].trim();return`<div class="slidev-block-ref" data-ref-id="${o}">${u}</div>`}const c=a||`Ref(${o.slice(0,8)})`;return`<a href="siyuan://blocks/${o}" data-ref-id="${o}" class="slidev-ref-tag">🔗 ${c}</a>`})}const xn="custom-slidev-theme",_n="custom-slidev-aspect-ratio",Fr="custom-slidev-highlighter",Sn="custom-slidev-default-transition",Hr="custom-slidev-color-schema",ts="custom-slidev-spacing",Bi="custom-slidev-slide",mt="custom-slidev-layout",Qt="custom-slidev-transition",Ut="custom-slidev-background",Ee="custom-slidev-image",Wi="custom-slidev-notes",Vi="custom-slidev-class",fn="custom-slidev-spacing",re="custom-slidev-layout-ratio",jt="custom-slidev-click",Ve="custom-slidev-motion",Ri="custom-slidev-shiki-lines",At="custom-slidev-slot",ie="custom-slidev-note",Kt="custom-slidev-role",Cn="custom-slidev-max-height",Ti="custom-slidev-autoplay",oo="custom-slidev-loop",Ui="custom-slidev-muted",so="custom-slidev-controls",jr="background",ro="image-left",lo="image-right";function ao(t){return t==="cols-header"||t==="two-cols-header"||t==="three-cols-header"}function sc(t){return t.markdown&&t.markdown.trim()?t.markdown.trim():t.content&&t.content.trim()?t.content.trim():""}function rc(t){const i={};if(!t)return i;const e=t.replace(/^\{:\s*/,"").replace(/\s*\}$/,""),n=/([\w-]+)=(?:"([^"]*)"|'([^']*)'|(\S+))/g;let o;for(;(o=n.exec(e))!==null;){const s=o[1],l=o[2]??o[3]??o[4]??"";i[s]=l}return i}function lc(t){if(!t)return!1;const i=t.trim();return i.startsWith("assets/")||i.startsWith("./assets/")||i.startsWith("/assets/")}function ac(t){const i=t.trim();return i.startsWith("./assets/")?i.slice(2):i.startsWith("/assets/")?i.slice(1):i}function Ie(t,i){if(!lc(t))return t;const e=ac(t);return i!=null&&i.base64Map&&i.base64Map[e]?i.base64Map[e]:i!=null&&i.baseUrl?`${i.baseUrl.replace(/\/+$/,"")}/${e}`:`/${e}`}function cc(t,i){if(!t)return"";let e=t;return e=e.replace(/!\[(.*?)\]\(((?:\.\/|\/)?assets\/[^\s)]+)\)/g,(n,o,s)=>{const l=Ie(s,i);return`![${o}](${l})`}),e=e.replace(/(<(?:img|video|audio|source)\b[^>]*?\bsrc=["'])((?:\.\/|\/)?assets\/[^"']+)(["'][^>]*>)/gi,(n,o,s,l)=>{const r=Ie(s,i);return`${o}${r}${l}`}),e=e.replace(/(url\(\s*["']?)((?:\.\/|\/)?assets\/[^"')]+)(["']?\s*\))/gi,(n,o,s,l)=>{const r=Ie(s,i);return`${o}${r}${l}`}),e}/**
* @vue/shared v3.5.40
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/function gs(t){const i=Object.create(null);for(const e of t.split(","))i[e]=1;return e=>e in i}const Wt={},qi=[],qe=()=>{},Ur=()=>!1,ko=t=>t.charCodeAt(0)===111&&t.charCodeAt(1)===110&&(t.charCodeAt(2)>122||t.charCodeAt(2)<97),wo=t=>t.startsWith("onUpdate:"),ue=Object.assign,vs=(t,i)=>{const e=t.indexOf(i);e>-1&&t.splice(e,1)},dc=Object.prototype.hasOwnProperty,zt=(t,i)=>dc.call(t,i),Ct=Array.isArray,Ki=t=>Ln(t)==="[object Map]",en=t=>Ln(t)==="[object Set]",Gs=t=>Ln(t)==="[object Date]",Bt=t=>typeof t=="function",te=t=>typeof t=="string",Pe=t=>typeof t=="symbol",Ht=t=>t!==null&&typeof t=="object",Wr=t=>(Ht(t)||Bt(t))&&Bt(t.then)&&Bt(t.catch),Vr=Object.prototype.toString,Ln=t=>Vr.call(t),uc=t=>Ln(t).slice(8,-1),qr=t=>Ln(t)==="[object Object]",bs=t=>te(t)&&t!=="NaN"&&t[0]!=="-"&&""+parseInt(t,10)===t,pn=gs(",key,ref,ref_for,ref_key,onVnodeBeforeMount,onVnodeMounted,onVnodeBeforeUpdate,onVnodeUpdated,onVnodeBeforeUnmount,onVnodeUnmounted"),xo=t=>{const i=Object.create(null);return(e=>i[e]||(i[e]=t(e)))},fc=/-\w/g,be=xo(t=>t.replace(fc,i=>i.slice(1).toUpperCase())),pc=/\B([A-Z])/g,bi=xo(t=>t.replace(pc,"-$1").toLowerCase()),_o=xo(t=>t.charAt(0).toUpperCase()+t.slice(1)),Oo=xo(t=>t?`on${_o(t)}`:""),Ue=(t,i)=>!Object.is(t,i),Jn=(t,...i)=>{for(let e=0;e<t.length;e++)t[e](...i)},Kr=(t,i,e,n=!1)=>{Object.defineProperty(t,i,{configurable:!0,enumerable:!1,writable:n,value:e})},So=t=>{const i=parseFloat(t);return isNaN(i)?t:i};let Zs;const Co=()=>Zs||(Zs=typeof globalThis<"u"?globalThis:typeof self<"u"?self:typeof window<"u"?window:typeof global<"u"?global:{});function $n(t){if(Ct(t)){const i={};for(let e=0;e<t.length;e++){const n=t[e],o=te(n)?vc(n):$n(n);if(o)for(const s in o)i[s]=o[s]}return i}else if(te(t)||Ht(t))return t}const hc=/;(?![^(]*\))/g,mc=/:([^]+)/,gc=/\/\*[^]*?\*\//g;function vc(t){const i={};return t.replace(gc,"").split(hc).forEach(e=>{if(e){const n=e.split(mc);n.length>1&&(i[n[0].trim()]=n[1].trim())}}),i}function It(t){let i="";if(te(t))i=t;else if(Ct(t))for(let e=0;e<t.length;e++){const n=It(t[e]);n&&(i+=n+" ")}else if(Ht(t))for(const e in t)t[e]&&(i+=e+" ");return i.trim()}const bc="itemscope,allowfullscreen,formnovalidate,ismap,nomodule,novalidate,readonly",yc=gs(bc);function Gr(t){return!!t||t===""}function kc(t,i){if(t.length!==i.length)return!1;let e=!0;for(let n=0;e&&n<t.length;n++)e=nn(t[n],i[n]);return e}function nn(t,i){if(t===i)return!0;let e=Gs(t),n=Gs(i);if(e||n)return e&&n?t.getTime()===i.getTime():!1;if(e=Pe(t),n=Pe(i),e||n)return t===i;if(e=Ct(t),n=Ct(i),e||n)return e&&n?kc(t,i):!1;if(e=Ht(t),n=Ht(i),e||n){if(!e||!n)return!1;const o=Object.keys(t).length,s=Object.keys(i).length;if(o!==s)return!1;for(const l in t){const r=t.hasOwnProperty(l),a=i.hasOwnProperty(l);if(r&&!a||!r&&a||!nn(t[l],i[l]))return!1}}return String(t)===String(i)}function ys(t,i){return t.findIndex(e=>nn(e,i))}const Zr=t=>!!(t&&t.__v_isRef===!0),St=t=>te(t)?t:t==null?"":Ct(t)||Ht(t)&&(t.toString===Vr||!Bt(t.toString))?Zr(t)?St(t.value):JSON.stringify(t,Yr,2):String(t),Yr=(t,i)=>Zr(i)?Yr(t,i.value):Ki(i)?{[`Map(${i.size})`]:[...i.entries()].reduce((e,[n,o],s)=>(e[zo(n,s)+" =>"]=o,e),{})}:en(i)?{[`Set(${i.size})`]:[...i.values()].map(e=>zo(e))}:Pe(i)?zo(i):Ht(i)&&!Ct(i)&&!qr(i)?String(i):i,zo=(t,i="")=>{var e;return Pe(t)?`Symbol(${(e=t.description)!=null?e:i})`:t};/**
* @vue/reactivity v3.5.40
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/let ae;class wc{constructor(i=!1){this.detached=i,this._active=!0,this._on=0,this.effects=[],this.cleanups=[],this._isPaused=!1,this._warnOnRun=!0,this.__v_skip=!0,!i&&ae&&(ae.active?(this.parent=ae,this.index=(ae.scopes||(ae.scopes=[])).push(this)-1):(this._active=!1,this._warnOnRun=!1))}get active(){return this._active}pause(){if(this._active){this._isPaused=!0;let i,e;if(this.scopes){const n=this.scopes.slice();for(i=0,e=n.length;i<e;i++)n[i].pause()}for(i=0,e=this.effects.length;i<e;i++)this.effects[i].pause()}}resume(){if(this._active&&this._isPaused){this._isPaused=!1;let i,e;if(this.scopes){const o=this.scopes.slice();for(i=0,e=o.length;i<e;i++)o[i].resume()}const n=this.effects.slice();for(i=0,e=n.length;i<e;i++)n[i].resume()}}run(i){if(this._active){const e=ae;try{return ae=this,i()}finally{ae=e}}}on(){++this._on===1&&(this.prevScope=ae,ae=this)}off(){if(this._on>0&&--this._on===0){if(ae===this)ae=this.prevScope;else{let i=ae;for(;i;){if(i.prevScope===this){i.prevScope=this.prevScope;break}i=i.prevScope}}this.prevScope=void 0}}stop(i){if(this._active){this._active=!1;let e,n;for(e=0,n=this.effects.length;e<n;e++)this.effects[e].stop();for(this.effects.length=0,e=0,n=this.cleanups.length;e<n;e++)this.cleanups[e]();if(this.cleanups.length=0,this.scopes){const o=this.scopes.slice();for(e=0,n=o.length;e<n;e++)o[e].stop(!0);this.scopes.length=0}if(!this.detached&&this.parent&&!i){const o=this.parent.scopes.pop();o&&o!==this&&(this.parent.scopes[this.index]=o,o.index=this.index)}this.parent=void 0}}}function xc(){return ae}let qt;const No=new WeakSet;class Jr{constructor(i){this.fn=i,this.deps=void 0,this.depsTail=void 0,this.flags=5,this.next=void 0,this.cleanup=void 0,this.scheduler=void 0,ae&&(ae.active?ae.effects.push(this):this.flags&=-2)}pause(){this.flags|=64}resume(){this.flags&64&&(this.flags&=-65,No.has(this)&&(No.delete(this),this.trigger()))}notify(){this.flags&2&&!(this.flags&32)||this.flags&8||Qr(this)}run(){if(!(this.flags&1))return this.fn();this.flags|=2,Ys(this),tl(this);const i=qt,e=Le;qt=this,Le=!0;try{return this.fn()}finally{el(this),qt=i,Le=e,this.flags&=-3}}stop(){if(this.flags&1){for(let i=this.deps;i;i=i.nextDep)xs(i);this.deps=this.depsTail=void 0,Ys(this),this.onStop&&this.onStop(),this.flags&=-2}}trigger(){this.flags&64?No.add(this):this.scheduler?this.scheduler():this.runIfDirty()}runIfDirty(){es(this)&&this.run()}get dirty(){return es(this)}}let Xr=0,hn,mn;function Qr(t,i=!1){if(t.flags|=8,i){t.next=mn,mn=t;return}t.next=hn,hn=t}function ks(){Xr++}function ws(){if(--Xr>0)return;if(mn){let i=mn;for(mn=void 0;i;){const e=i.next;i.next=void 0,i.flags&=-9,i=e}}let t;for(;hn;){let i=hn;for(hn=void 0;i;){const e=i.next;if(i.next=void 0,i.flags&=-9,i.flags&1)try{i.trigger()}catch(n){t||(t=n)}i=e}}if(t)throw t}function tl(t){for(let i=t.deps;i;i=i.nextDep)i.version=-1,i.prevActiveLink=i.dep.activeLink,i.dep.activeLink=i}function el(t){let i,e=t.depsTail,n=e;for(;n;){const o=n.prevDep;n.version===-1?(n===e&&(e=o),xs(n),_c(n)):i=n,n.dep.activeLink=n.prevActiveLink,n.prevActiveLink=void 0,n=o}t.deps=i,t.depsTail=e}function es(t){for(let i=t.deps;i;i=i.nextDep)if(i.dep.version!==i.version||i.dep.computed&&(il(i.dep.computed)||i.dep.version!==i.version))return!0;return!!t._dirty}function il(t){if(t.flags&4&&!(t.flags&16)||(t.flags&=-17,t.globalVersion===In)||(t.globalVersion=In,!t.isSSR&&t.flags&128&&(!t.deps&&!t._dirty||!es(t))))return;t.flags|=2;const i=t.dep,e=qt,n=Le;qt=t,Le=!0;try{tl(t);const o=t.fn(t._value);(i.version===0||Ue(o,t._value))&&(t.flags|=128,t._value=o,i.version++)}catch(o){throw i.version++,o}finally{qt=e,Le=n,el(t),t.flags&=-3}}function xs(t,i=!1){const{dep:e,prevSub:n,nextSub:o}=t;if(n&&(n.nextSub=o,t.prevSub=void 0),o&&(o.prevSub=n,t.nextSub=void 0),e.subs===t&&(e.subs=n,!n&&e.computed)){e.computed.flags&=-5;for(let s=e.computed.deps;s;s=s.nextDep)xs(s,!0)}!i&&!--e.sc&&e.map&&e.map.delete(e.key)}function _c(t){const{prevDep:i,nextDep:e}=t;i&&(i.nextDep=e,t.prevDep=void 0),e&&(e.prevDep=i,t.nextDep=void 0)}let Le=!0;const nl=[];function ni(){nl.push(Le),Le=!1}function oi(){const t=nl.pop();Le=t===void 0?!0:t}function Ys(t){const{cleanup:i}=t;if(t.cleanup=void 0,i){const e=qt;qt=void 0;try{i()}finally{qt=e}}}let In=0;class Sc{constructor(i,e){this.sub=i,this.dep=e,this.version=e.version,this.nextDep=this.prevDep=this.nextSub=this.prevSub=this.prevActiveLink=void 0}}class _s{constructor(i){this.computed=i,this.version=0,this.activeLink=void 0,this.subs=void 0,this.map=void 0,this.key=void 0,this.sc=0,this.__v_skip=!0}track(i){if(!qt||!Le||qt===this.computed)return;let e=this.activeLink;if(e===void 0||e.sub!==qt)e=this.activeLink=new Sc(qt,this),qt.deps?(e.prevDep=qt.depsTail,qt.depsTail.nextDep=e,qt.depsTail=e):qt.deps=qt.depsTail=e,ol(e);else if(e.version===-1&&(e.version=this.version,e.nextDep)){const n=e.nextDep;n.prevDep=e.prevDep,e.prevDep&&(e.prevDep.nextDep=n),e.prevDep=qt.depsTail,e.nextDep=void 0,qt.depsTail.nextDep=e,qt.depsTail=e,qt.deps===e&&(qt.deps=n)}return e}trigger(i){this.version++,In++,this.notify(i)}notify(i){ks();try{for(let e=this.subs;e;e=e.prevSub)e.sub.notify()&&e.sub.dep.notify()}finally{ws()}}}function ol(t){if(t.dep.sc++,t.sub.flags&4){const i=t.dep.computed;if(i&&!t.dep.subs){i.flags|=20;for(let n=i.deps;n;n=n.nextDep)ol(n)}const e=t.dep.subs;e!==t&&(t.prevSub=e,e&&(e.nextSub=t)),t.dep.subs=t}}const is=new WeakMap,Mi=Symbol(""),ns=Symbol(""),An=Symbol("");function he(t,i,e){if(Le&&qt){let n=is.get(t);n||is.set(t,n=new Map);let o=n.get(e);o||(n.set(e,o=new _s),o.map=n,o.key=e),o.track()}}function Xe(t,i,e,n,o,s){const l=is.get(t);if(!l){In++;return}const r=a=>{a&&a.trigger()};if(ks(),i==="clear")l.forEach(r);else{const a=Ct(t),c=a&&bs(e);if(a&&e==="length"){const u=Number(n);l.forEach((m,g)=>{(g==="length"||g===An||!Pe(g)&&g>=u)&&r(m)})}else switch((e!==void 0||l.has(void 0))&&r(l.get(e)),c&&r(l.get(An)),i){case"add":a?c&&r(l.get("length")):(r(l.get(Mi)),Ki(t)&&r(l.get(ns)));break;case"delete":a||(r(l.get(Mi)),Ki(t)&&r(l.get(ns)));break;case"set":Ki(t)&&r(l.get(Mi));break}}ws()}function Hi(t){const i=Ot(t);return i===t?i:(he(i,"iterate",An),Be(t)?i:i.map(Re))}function $o(t){return he(t=Ot(t),"iterate",An),t}function He(t,i){return si(t)?Ji(Di(t)?Re(i):i):Re(i)}const Cc={__proto__:null,[Symbol.iterator](){return Fo(this,Symbol.iterator,t=>He(this,t))},concat(...t){return Hi(this).concat(...t.map(i=>Ct(i)?Hi(i):i))},entries(){return Fo(this,"entries",t=>(t[1]=He(this,t[1]),t))},every(t,i){return Ge(this,"every",t,i,void 0,arguments)},filter(t,i){return Ge(this,"filter",t,i,e=>e.map(n=>He(this,n)),arguments)},find(t,i){return Ge(this,"find",t,i,e=>He(this,e),arguments)},findIndex(t,i){return Ge(this,"findIndex",t,i,void 0,arguments)},findLast(t,i){return Ge(this,"findLast",t,i,e=>He(this,e),arguments)},findLastIndex(t,i){return Ge(this,"findLastIndex",t,i,void 0,arguments)},forEach(t,i){return Ge(this,"forEach",t,i,void 0,arguments)},includes(...t){return Ho(this,"includes",t)},indexOf(...t){return Ho(this,"indexOf",t)},join(t){return Hi(this).join(t)},lastIndexOf(...t){return Ho(this,"lastIndexOf",t)},map(t,i){return Ge(this,"map",t,i,void 0,arguments)},pop(){return rn(this,"pop")},push(...t){return rn(this,"push",t)},reduce(t,...i){return Js(this,"reduce",t,i)},reduceRight(t,...i){return Js(this,"reduceRight",t,i)},shift(){return rn(this,"shift")},some(t,i){return Ge(this,"some",t,i,void 0,arguments)},splice(...t){return rn(this,"splice",t)},toReversed(){return Hi(this).toReversed()},toSorted(t){return Hi(this).toSorted(t)},toSpliced(...t){return Hi(this).toSpliced(...t)},unshift(...t){return rn(this,"unshift",t)},values(){return Fo(this,"values",t=>He(this,t))}};function Fo(t,i,e){const n=$o(t),o=n[i]();return n!==t&&!Be(t)&&(o._next=o.next,o.next=()=>{const s=o._next();return s.done||(s.value=e(s.value)),s}),o}const $c=Array.prototype;function Ge(t,i,e,n,o,s){const l=$o(t),r=l!==t&&!Be(t),a=l[i];if(a!==$c[i]){const m=a.apply(t,s);return r?Re(m):m}let c=e;l!==t&&(r?c=function(m,g){return e.call(this,He(t,m),g,t)}:e.length>2&&(c=function(m,g){return e.call(this,m,g,t)}));const u=a.call(l,c,n);return r&&o?o(u):u}function Js(t,i,e,n){const o=$o(t),s=o!==t&&!Be(t);let l=e,r=!1;o!==t&&(s?(r=n.length===0,l=function(c,u,m){return r&&(r=!1,c=He(t,c)),e.call(this,c,He(t,u),m,t)}):e.length>3&&(l=function(c,u,m){return e.call(this,c,u,m,t)}));const a=o[i](l,...n);return r?He(t,a):a}function Ho(t,i,e){const n=Ot(t);he(n,"iterate",An);const o=n[i](...e);return(o===-1||o===!1)&&$s(e[0])?(e[0]=Ot(e[0]),n[i](...e)):o}function rn(t,i,e=[]){ni(),ks();const n=Ot(t)[i].apply(t,e);return ws(),oi(),n}const Ic=gs("__proto__,__v_isRef,__isVue"),sl=new Set(Object.getOwnPropertyNames(Symbol).filter(t=>t!=="arguments"&&t!=="caller").map(t=>Symbol[t]).filter(Pe));function Ac(t){Pe(t)||(t=String(t));const i=Ot(this);return he(i,"has",t),i.hasOwnProperty(t)}class rl{constructor(i=!1,e=!1){this._isReadonly=i,this._isShallow=e}get(i,e,n){if(e==="__v_skip")return i.__v_skip;const o=this._isReadonly,s=this._isShallow;if(e==="__v_isReactive")return!o;if(e==="__v_isReadonly")return o;if(e==="__v_isShallow")return s;if(e==="__v_raw")return n===(o?s?zc:dl:s?cl:al).get(i)||Object.getPrototypeOf(i)===Object.getPrototypeOf(n)?i:void 0;const l=Ct(i);if(!o){let a;if(l&&(a=Cc[e]))return a;if(e==="hasOwnProperty")return Ac}const r=Reflect.get(i,e,Yt(i)?i:n);if((Pe(e)?sl.has(e):Ic(e))||(o||he(i,"get",e),s))return r;if(Yt(r)){const a=l&&bs(e)?r:r.value;return o&&Ht(a)?ss(a):a}return Ht(r)?o?ss(r):Io(r):r}}class ll extends rl{constructor(i=!1){super(!1,i)}set(i,e,n,o){let s=i[e];const l=Ct(i)&&bs(e);if(!this._isShallow){const c=si(s);if(!Be(n)&&!si(n)&&(s=Ot(s),n=Ot(n)),!l&&Yt(s)&&!Yt(n))return c||(s.value=n),!0}const r=l?Number(e)<i.length:zt(i,e),a=Reflect.set(i,e,n,Yt(i)?i:o);return i===Ot(o)&&a&&(r?Ue(n,s)&&Xe(i,"set",e,n):Xe(i,"add",e,n)),a}deleteProperty(i,e){const n=zt(i,e);i[e];const o=Reflect.deleteProperty(i,e);return o&&n&&Xe(i,"delete",e,void 0),o}has(i,e){const n=Reflect.has(i,e);return(!Pe(e)||!sl.has(e))&&he(i,"has",e),n}ownKeys(i){return he(i,"iterate",Ct(i)?"length":Mi),Reflect.ownKeys(i)}}class Bc extends rl{constructor(i=!1){super(!0,i)}set(i,e){return!0}deleteProperty(i,e){return!0}}const Tc=new ll,Ec=new Bc,Mc=new ll(!0);const os=t=>t,Un=t=>Reflect.getPrototypeOf(t);function Dc(t,i,e){return function(...n){const o=this.__v_raw,s=Ot(o),l=Ki(s),r=t==="entries"||t===Symbol.iterator&&l,a=t==="keys"&&l,c=o[t](...n),u=e?os:i?Ji:Re;return!i&&he(s,"iterate",a?ns:Mi),ue(Object.create(c),{next(){const{value:m,done:g}=c.next();return g?{value:m,done:g}:{value:r?[u(m[0]),u(m[1])]:u(m),done:g}}})}}function Wn(t){return function(...i){return t==="delete"?!1:t==="clear"?void 0:this}}function Lc(t,i){const e={get(o){const s=this.__v_raw,l=Ot(s),r=Ot(o);t||(Ue(o,r)&&he(l,"get",o),he(l,"get",r));const{has:a}=Un(l),c=i?os:t?Ji:Re;if(a.call(l,o))return c(s.get(o));if(a.call(l,r))return c(s.get(r));s!==l&&s.get(o)},get size(){const o=this.__v_raw;return!t&&he(Ot(o),"iterate",Mi),o.size},has(o){const s=this.__v_raw,l=Ot(s),r=Ot(o);return t||(Ue(o,r)&&he(l,"has",o),he(l,"has",r)),o===r?s.has(o):s.has(o)||s.has(r)},forEach(o,s){const l=this,r=l.__v_raw,a=Ot(r),c=i?os:t?Ji:Re;return!t&&he(a,"iterate",Mi),r.forEach((u,m)=>o.call(s,c(u),c(m),l))}};return ue(e,t?{add:Wn("add"),set:Wn("set"),delete:Wn("delete"),clear:Wn("clear")}:{add(o){const s=Ot(this),l=Un(s),r=Ot(o),a=!i&&!Be(o)&&!si(o)?r:o;return l.has.call(s,a)||Ue(o,a)&&l.has.call(s,o)||Ue(r,a)&&l.has.call(s,r)||(s.add(a),Xe(s,"add",a,a)),this},set(o,s){!i&&!Be(s)&&!si(s)&&(s=Ot(s));const l=Ot(this),{has:r,get:a}=Un(l);let c=r.call(l,o);c||(o=Ot(o),c=r.call(l,o));const u=a.call(l,o);return l.set(o,s),c?Ue(s,u)&&Xe(l,"set",o,s):Xe(l,"add",o,s),this},delete(o){const s=Ot(this),{has:l,get:r}=Un(s);let a=l.call(s,o);a||(o=Ot(o),a=l.call(s,o)),r&&r.call(s,o);const c=s.delete(o);return a&&Xe(s,"delete",o,void 0),c},clear(){const o=Ot(this),s=o.size!==0,l=o.clear();return s&&Xe(o,"clear",void 0,void 0),l}}),["keys","values","entries",Symbol.iterator].forEach(o=>{e[o]=Dc(o,t,i)}),e}function Ss(t,i){const e=Lc(t,i);return(n,o,s)=>o==="__v_isReactive"?!t:o==="__v_isReadonly"?t:o==="__v_raw"?n:Reflect.get(zt(e,o)&&o in n?e:n,o,s)}const Pc={get:Ss(!1,!1)},Rc={get:Ss(!1,!0)},Oc={get:Ss(!0,!1)};const al=new WeakMap,cl=new WeakMap,dl=new WeakMap,zc=new WeakMap;function Nc(t){switch(t){case"Object":case"Array":return 1;case"Map":case"Set":case"WeakMap":case"WeakSet":return 2;default:return 0}}function Io(t){return si(t)?t:Cs(t,!1,Tc,Pc,al)}function Fc(t){return Cs(t,!1,Mc,Rc,cl)}function ss(t){return Cs(t,!0,Ec,Oc,dl)}function Cs(t,i,e,n,o){if(!Ht(t)||t.__v_raw&&!(i&&t.__v_isReactive)||t.__v_skip||!Object.isExtensible(t))return t;const s=o.get(t);if(s)return s;const l=Nc(uc(t));if(l===0)return t;const r=new Proxy(t,l===2?n:e);return o.set(t,r),r}function Di(t){return si(t)?Di(t.__v_raw):!!(t&&t.__v_isReactive)}function si(t){return!!(t&&t.__v_isReadonly)}function Be(t){return!!(t&&t.__v_isShallow)}function $s(t){return t?!!t.__v_raw:!1}function Ot(t){const i=t&&t.__v_raw;return i?Ot(i):t}function Hc(t){return!zt(t,"__v_skip")&&Object.isExtensible(t)&&Kr(t,"__v_skip",!0),t}const Re=t=>Ht(t)?Io(t):t,Ji=t=>Ht(t)?ss(t):t;function Yt(t){return t?t.__v_isRef===!0:!1}function gt(t){return jc(t,!1)}function jc(t,i){return Yt(t)?t:new Uc(t,i)}class Uc{constructor(i,e){this.dep=new _s,this.__v_isRef=!0,this.__v_isShallow=!1,this._rawValue=e?i:Ot(i),this._value=e?i:Re(i),this.__v_isShallow=e}get value(){return this.dep.track(),this._value}set value(i){const e=this._rawValue,n=this.__v_isShallow||Be(i)||si(i);i=n?i:Ot(i),Ue(i,e)&&(this._rawValue=i,this._value=n?i:Re(i),this.dep.trigger())}}function vt(t){return Yt(t)?t.value:t}const Wc={get:(t,i,e)=>i==="__v_raw"?t:vt(Reflect.get(t,i,e)),set:(t,i,e,n)=>{const o=t[i];return Yt(o)&&!Yt(e)?(o.value=e,!0):Reflect.set(t,i,e,n)}};function ul(t){return Di(t)?t:new Proxy(t,Wc)}class Vc{constructor(i,e,n){this.fn=i,this.setter=e,this._value=void 0,this.dep=new _s(this),this.__v_isRef=!0,this.deps=void 0,this.depsTail=void 0,this.flags=16,this.globalVersion=In-1,this.next=void 0,this.effect=this,this.__v_isReadonly=!e,this.isSSR=n}notify(){if(this.flags|=16,!(this.flags&8)&&qt!==this)return Qr(this,!0),!0}get value(){const i=this.dep.track();return il(this),i&&(i.version=this.dep.version),this._value}set value(i){this.setter&&this.setter(i)}}function qc(t,i,e=!1){let n,o;return Bt(t)?n=t:(n=t.get,o=t.set),new Vc(n,o,e)}const Vn={},co=new WeakMap;let Ai;function Kc(t,i=!1,e=Ai){if(e){let n=co.get(e);n||co.set(e,n=[]),n.push(t)}}function Gc(t,i,e=Wt){const{immediate:n,deep:o,once:s,scheduler:l,augmentJob:r,call:a}=e,c=B=>o?B:Be(B)||o===!1||o===0?Qe(B,1):Qe(B);let u,m,g,d,y=!1,f=!1;if(Yt(t)?(m=()=>t.value,y=Be(t)):Di(t)?(m=()=>c(t),y=!0):Ct(t)?(f=!0,y=t.some(B=>Di(B)||Be(B)),m=()=>t.map(B=>{if(Yt(B))return B.value;if(Di(B))return c(B);if(Bt(B))return a?a(B,2):B()})):Bt(t)?i?m=a?()=>a(t,2):t:m=()=>{if(g){ni();try{g()}finally{oi()}}const B=Ai;Ai=u;try{return a?a(t,3,[d]):t(d)}finally{Ai=B}}:m=qe,i&&o){const B=m,A=o===!0?1/0:o;m=()=>Qe(B(),A)}const v=xc(),k=()=>{u.stop(),v&&v.active&&vs(v.effects,u)};if(s&&i){const B=i;i=(...A)=>{const I=B(...A);return k(),I}}let x=f?new Array(t.length).fill(Vn):Vn;const S=B=>{if(!(!(u.flags&1)||!u.dirty&&!B))if(i){const A=u.run();if(B||o||y||(f?A.some((I,w)=>Ue(I,x[w])):Ue(A,x))){g&&g();const I=Ai;Ai=u;try{const w=[A,x===Vn?void 0:f&&x[0]===Vn?[]:x,d];x=A,a?a(i,3,w):i(...w)}finally{Ai=I}}}else u.run()};return r&&r(S),u=new Jr(m),u.scheduler=l?()=>l(S,!1):S,d=B=>Kc(B,!1,u),g=u.onStop=()=>{const B=co.get(u);if(B){if(a)a(B,4);else for(const A of B)A();co.delete(u)}},i?n?S(!0):x=u.run():l?l(S.bind(null,!0),!0):u.run(),k.pause=u.pause.bind(u),k.resume=u.resume.bind(u),k.stop=k,k}function Qe(t,i=1/0,e){if(i<=0||!Ht(t)||t.__v_skip||(e=e||new Map,(e.get(t)||0)>=i))return t;if(e.set(t,i),i--,Yt(t))Qe(t.value,i,e);else if(Ct(t))for(let n=0;n<t.length;n++)Qe(t[n],i,e);else if(en(t)||Ki(t))t.forEach(n=>{Qe(n,i,e)});else if(qr(t)){for(const n in t)Qe(t[n],i,e);for(const n of Object.getOwnPropertySymbols(t))Object.prototype.propertyIsEnumerable.call(t,n)&&Qe(t[n],i,e)}return t}/**
* @vue/runtime-core v3.5.40
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/function Pn(t,i,e,n){try{return n?t(...n):t()}catch(o){Ao(o,i,e)}}function Oe(t,i,e,n){if(Bt(t)){const o=Pn(t,i,e,n);return o&&Wr(o)&&o.catch(s=>{Ao(s,i,e)}),o}if(Ct(t)){const o=[];for(let s=0;s<t.length;s++)o.push(Oe(t[s],i,e,n));return o}}function Ao(t,i,e,n=!0){const o=i?i.vnode:null,{errorHandler:s,throwUnhandledErrorInProduction:l}=i&&i.appContext.config||Wt;if(i){let r=i.parent;const a=i.proxy,c=`https://vuejs.org/error-reference/#runtime-${e}`;for(;r;){const u=r.ec;if(u){for(let m=0;m<u.length;m++)if(u[m](t,a,c)===!1)return}r=r.parent}if(s){ni(),Pn(s,null,10,[t,a,c]),oi();return}}Zc(t,e,o,n,l)}function Zc(t,i,e,n=!0,o=!1){if(o)throw t;console.error(t)}const ve=[];let Fe=-1;const Gi=[];let fi=null,ji=0;const fl=Promise.resolve();let uo=null;function pl(t){const i=uo||fl;return t?i.then(this?t.bind(this):t):i}function Yc(t){let i=Fe+1,e=ve.length;for(;i<e;){const n=i+e>>>1,o=ve[n],s=Bn(o);s<t||s===t&&o.flags&2?i=n+1:e=n}return i}function Is(t){if(!(t.flags&1)){const i=Bn(t),e=ve[ve.length-1];!e||!(t.flags&2)&&i>=Bn(e)?ve.push(t):ve.splice(Yc(i),0,t),t.flags|=1,hl()}}function hl(){uo||(uo=fl.then(gl))}function Jc(t){Ct(t)?Gi.push(...t):fi&&t.id===-1?fi.splice(ji+1,0,t):t.flags&1||(Gi.push(t),t.flags|=1),hl()}function Xs(t,i,e=Fe+1){for(;e<ve.length;e++){const n=ve[e];if(n&&n.flags&2){if(t&&n.id!==t.uid)continue;ve.splice(e,1),e--,n.flags&4&&(n.flags&=-2),n(),n.flags&4||(n.flags&=-2)}}}function ml(t){if(Gi.length){const i=[...new Set(Gi)].sort((e,n)=>Bn(e)-Bn(n));if(Gi.length=0,fi){fi.push(...i);return}for(fi=i,ji=0;ji<fi.length;ji++){const e=fi[ji];e.flags&4&&(e.flags&=-2),e.flags&8||e(),e.flags&=-2}fi=null,ji=0}}const Bn=t=>t.id==null?t.flags&2?-1:1/0:t.id;function gl(t){try{for(Fe=0;Fe<ve.length;Fe++){const i=ve[Fe];i&&!(i.flags&8)&&(i.flags&4&&(i.flags&=-2),Pn(i,i.i,i.i?15:14),i.flags&4||(i.flags&=-2))}}finally{for(;Fe<ve.length;Fe++){const i=ve[Fe];i&&(i.flags&=-2)}Fe=-1,ve.length=0,ml(),uo=null,(ve.length||Gi.length)&&gl()}}let de=null,vl=null;function fo(t){const i=de;return de=t,vl=t&&t.type.__scopeId||null,i}function bl(t,i=de,e){if(!i||t._n)return t;const n=(...o)=>{n._d&&dr(-1);const s=fo(i),l=ei.length;let r;try{r=t(...o)}finally{for(let a=ei.length;a>l;a--)Ds();fo(s),n._d&&dr(1)}return r};return n._n=!0,n._c=!0,n._d=!0,n}function Te(t,i){if(de===null)return t;const e=Mo(de),n=t.dirs||(t.dirs=[]);for(let o=0;o<i.length;o++){let[s,l,r,a=Wt]=i[o];s&&(Bt(s)&&(s={mounted:s,updated:s}),s.deep&&Qe(l),n.push({dir:s,instance:e,value:l,oldValue:void 0,arg:r,modifiers:a}))}return t}function xi(t,i,e,n){const o=t.dirs,s=i&&i.dirs;for(let l=0;l<o.length;l++){const r=o[l];s&&(r.oldValue=s[l].value);let a=r.dir[n];a&&(ni(),Oe(a,e,8,[t.el,r,t,i]),oi())}}function Xc(t,i){if(me){let e=me.provides;const n=me.parent&&me.parent.provides;n===e&&(e=me.provides=Object.create(n)),e[t]=i}}function ti(t,i,e=!1){const n=Yd();if(n||Yi){let o=Yi?Yi._context.provides:n?n.parent==null||n.ce?n.vnode.appContext&&n.vnode.appContext.provides:n.parent.provides:void 0;if(o&&t in o)return o[t];if(arguments.length>1)return e&&Bt(i)?i.call(n&&n.proxy):i}}const Qc=Symbol.for("v-scx"),td=()=>ti(Qc);function Li(t,i,e){return yl(t,i,e)}function yl(t,i,e=Wt){const{immediate:n,deep:o,flush:s,once:l}=e,r=ue({},e),a=i&&n||!i&&s!=="post";let c;if(En){if(s==="sync"){const d=td();c=d.__watcherHandles||(d.__watcherHandles=[])}else if(!a){const d=()=>{};return d.stop=qe,d.resume=qe,d.pause=qe,d}}const u=me;r.call=(d,y,f)=>Oe(d,u,y,f);let m=!1;s==="post"?r.scheduler=d=>{we(d,u&&u.suspense)}:s!=="sync"&&(m=!0,r.scheduler=(d,y)=>{y?d():Is(d)}),r.augmentJob=d=>{i&&(d.flags|=4),m&&(d.flags|=2,u&&(d.id=u.uid,d.i=u))};const g=Gc(t,i,r);return En&&(c?c.push(g):a&&g()),g}function ed(t,i,e){const n=this.proxy,o=te(t)?t.includes(".")?kl(n,t):()=>n[t]:t.bind(n,n);let s;Bt(i)?s=i:(s=i.handler,e=i);const l=On(this),r=yl(o,s.bind(n),e);return l(),r}function kl(t,i){const e=i.split(".");return()=>{let n=t;for(let o=0;o<e.length&&n;o++)n=n[e[o]];return n}}const id=Symbol("_vte"),nd=t=>t.__isTeleport,jo=Symbol("_leaveCb");function As(t,i){t.shapeFlag&6&&t.component?(t.transition=i,As(t.component.subTree,i)):t.shapeFlag&128?(t.ssContent.transition=i.clone(t.ssContent),t.ssFallback.transition=i.clone(t.ssFallback)):t.transition=i}function Se(t,i){return Bt(t)?ue({name:t.name},i,{setup:t}):t}function wl(t){t.ids=[t.ids[0]+t.ids[2]+++"-",0,0]}function Qs(t,i){let e;return!!((e=Object.getOwnPropertyDescriptor(t,i))&&!e.configurable)}const po=new WeakMap;function gn(t,i,e,n,o=!1){if(Ct(t)){t.forEach((f,v)=>gn(f,i&&(Ct(i)?i[v]:i),e,n,o));return}if(Zi(n)&&!o){n.shapeFlag&512&&n.type.__asyncResolved&&n.component.subTree.component&&gn(t,i,e,n.component.subTree);return}const s=n.shapeFlag&4?Mo(n.component):n.el,l=o?null:s,{i:r,r:a}=t,c=i&&i.r,u=r.refs===Wt?r.refs={}:r.refs,m=r.setupState,g=Ot(m),d=m===Wt?Ur:f=>Qs(u,f)?!1:zt(g,f),y=(f,v)=>!(v&&Qs(u,v));if(c!=null&&c!==a){if(tr(i),te(c))u[c]=null,d(c)&&(m[c]=null);else if(Yt(c)){const f=i;y(c,f.k)&&(c.value=null),f.k&&(u[f.k]=null)}}if(Bt(a))Pn(a,r,12,[l,u]);else{const f=te(a),v=Yt(a);if(f||v){const k=()=>{if(t.f){const x=f?d(a)?m[a]:u[a]:y()||!t.k?a.value:u[t.k];if(o)Ct(x)&&vs(x,s);else if(Ct(x))x.includes(s)||x.push(s);else if(f)u[a]=[s],d(a)&&(m[a]=u[a]);else{const S=[s];y(a,t.k)&&(a.value=S),t.k&&(u[t.k]=S)}}else f?(u[a]=l,d(a)&&(m[a]=l)):v&&(y(a,t.k)&&(a.value=l),t.k&&(u[t.k]=l))};if(l){const x=()=>{k(),po.delete(t)};x.id=-1,po.set(t,x),we(x,e)}else tr(t),k()}}}function tr(t){const i=po.get(t);i&&(i.flags|=8,po.delete(t))}Co().requestIdleCallback;Co().cancelIdleCallback;const Zi=t=>!!t.type.__asyncLoader,xl=t=>t.type.__isKeepAlive;function od(t,i){_l(t,"a",i)}function sd(t,i){_l(t,"da",i)}function _l(t,i,e=me){const n=t.__wdc||(t.__wdc=()=>{let o=e;for(;o;){if(o.isDeactivated)return;o=o.parent}return t()});if(Bo(i,n,e),e){let o=e.parent;for(;o&&o.parent;)xl(o.parent.vnode)&&rd(n,i,e,o),o=o.parent}}function rd(t,i,e,n){const o=Bo(i,t,n,!0);Ts(()=>{vs(n[i],o)},e)}function Bo(t,i,e=me,n=!1){if(e){const o=e[t]||(e[t]=[]),s=i.__weh||(i.__weh=(...l)=>{ni();const r=On(e),a=Oe(i,e,t,l);return r(),oi(),a});return n?o.unshift(s):o.push(s),s}}const ai=t=>(i,e=me)=>{(!En||t==="sp")&&Bo(t,(...n)=>i(...n),e)},ld=ai("bm"),Rn=ai("m"),ad=ai("bu"),cd=ai("u"),Bs=ai("bum"),Ts=ai("um"),dd=ai("sp"),ud=ai("rtg"),fd=ai("rtc");function pd(t,i=me){Bo("ec",t,i)}const hd="components";function md(t,i){return vd(hd,t,!0,i)||t}const gd=Symbol.for("v-ndc");function vd(t,i,e=!0,n=!1){const o=de||me;if(o){const s=o.type;{const r=eu(s,!1);if(r&&(r===i||r===be(i)||r===_o(be(i))))return s}const l=er(o[t]||s[t],i)||er(o.appContext[t],i);return!l&&n?s:l}}function er(t,i){return t&&(t[i]||t[be(i)]||t[_o(be(i))])}function xe(t,i,e,n){let o;const s=e,l=Ct(t);if(l||te(t)){const r=l&&Di(t);let a=!1,c=!1;r&&(a=!Be(t),c=si(t),t=$o(t)),o=new Array(t.length);for(let u=0,m=t.length;u<m;u++)o[u]=i(a?c?Ji(Re(t[u])):Re(t[u]):t[u],u,void 0,s)}else if(typeof t=="number"){o=new Array(t);for(let r=0;r<t;r++)o[r]=i(r+1,r,void 0,s)}else if(Ht(t))if(t[Symbol.iterator])o=Array.from(t,(r,a)=>i(r,a,void 0,s));else{const r=Object.keys(t);o=new Array(r.length);for(let a=0,c=r.length;a<c;a++){const u=r[a];o[a]=i(t[u],u,a,s)}}else o=[];return o}function qn(t,i,e={},n,o,s){if(de.ce||de.parent&&Zi(de.parent)&&de.parent.ce){const c=e,u=Object.keys(c).length>0;return i!=="default"&&(c.name=i),ot(),De(Gt,null,[at("slot",c,n&&n())],u?-2:64)}let l=t[i];l&&l._c&&(l._d=!1);const r=ei.length;ot();let a;try{const c=l&&Sl(l(e)),u=e.key||s||c&&c.key;a=De(Gt,{key:(u&&!Pe(u)?u:`_${i}`)+(!c&&n?"_fb":"")},c||(n?n():[]),c&&t._===1?64:-2)}catch(c){for(let u=ei.length;u>r;u--)Ds();throw c}finally{l&&l._c&&(l._d=!0)}return a}function Sl(t){return t.some(i=>Ls(i)?!(i.type===ri||i.type===Gt&&!Sl(i.children)):!0)?t:null}const rs=t=>t?Wl(t)?Mo(t):rs(t.parent):null,vn=ue(Object.create(null),{$:t=>t,$el:t=>t.vnode.el,$data:t=>t.data,$props:t=>t.props,$attrs:t=>t.attrs,$slots:t=>t.slots,$refs:t=>t.refs,$parent:t=>rs(t.parent),$root:t=>rs(t.root),$host:t=>t.ce,$emit:t=>t.emit,$options:t=>$l(t),$forceUpdate:t=>t.f||(t.f=()=>{Is(t.update)}),$nextTick:t=>t.n||(t.n=pl.bind(t.proxy)),$watch:t=>ed.bind(t)}),Uo=(t,i)=>t!==Wt&&!t.__isScriptSetup&&zt(t,i),bd={get({_:t},i){if(i==="__v_skip")return!0;const{ctx:e,setupState:n,data:o,props:s,accessCache:l,type:r,appContext:a}=t;if(i[0]!=="$"){const g=l[i];if(g!==void 0)switch(g){case 1:return n[i];case 2:return o[i];case 4:return e[i];case 3:return s[i]}else{if(Uo(n,i))return l[i]=1,n[i];if(o!==Wt&&zt(o,i))return l[i]=2,o[i];if(zt(s,i))return l[i]=3,s[i];if(e!==Wt&&zt(e,i))return l[i]=4,e[i];ls&&(l[i]=0)}}const c=vn[i];let u,m;if(c)return i==="$attrs"&&he(t.attrs,"get",""),c(t);if((u=r.__cssModules)&&(u=u[i]))return u;if(e!==Wt&&zt(e,i))return l[i]=4,e[i];if(m=a.config.globalProperties,zt(m,i))return m[i]},set({_:t},i,e){const{data:n,setupState:o,ctx:s}=t;return Uo(o,i)?(o[i]=e,!0):n!==Wt&&zt(n,i)?(n[i]=e,!0):zt(t.props,i)||i[0]==="$"&&i.slice(1)in t?!1:(s[i]=e,!0)},has({_:{data:t,setupState:i,accessCache:e,ctx:n,appContext:o,props:s,type:l}},r){let a;return!!(e[r]||t!==Wt&&r[0]!=="$"&&zt(t,r)||Uo(i,r)||zt(s,r)||zt(n,r)||zt(vn,r)||zt(o.config.globalProperties,r)||(a=l.__cssModules)&&a[r])},defineProperty(t,i,e){return e.get!=null?t._.accessCache[i]=0:zt(e,"value")&&this.set(t,i,e.value,null),Reflect.defineProperty(t,i,e)}};function ir(t){return Ct(t)?t.reduce((i,e)=>(i[e]=null,i),{}):t}let ls=!0;function yd(t){const i=$l(t),e=t.proxy,n=t.ctx;ls=!1,i.beforeCreate&&nr(i.beforeCreate,t,"bc");const{data:o,computed:s,methods:l,watch:r,provide:a,inject:c,created:u,beforeMount:m,mounted:g,beforeUpdate:d,updated:y,activated:f,deactivated:v,beforeDestroy:k,beforeUnmount:x,destroyed:S,unmounted:B,render:A,renderTracked:I,renderTriggered:w,errorCaptured:z,serverPrefetch:O,expose:H,inheritAttrs:et,components:_,directives:P,filters:b}=i;if(c&&kd(c,n,null),l)for(const U in l){const G=l[U];Bt(G)&&(n[U]=G.bind(e))}if(o){const U=o.call(e,e);Ht(U)&&(t.data=Io(U))}if(ls=!0,s)for(const U in s){const G=s[U],V=Bt(G)?G.bind(e,e):Bt(G.get)?G.get.bind(e,e):qe,M=!Bt(G)&&Bt(G.set)?G.set.bind(e):qe,E=_t({get:V,set:M});Object.defineProperty(n,U,{enumerable:!0,configurable:!0,get:()=>E.value,set:R=>E.value=R})}if(r)for(const U in r)Cl(r[U],n,e,U);if(a){const U=Bt(a)?a.call(e):a;Reflect.ownKeys(U).forEach(G=>{Xc(G,U[G])})}u&&nr(u,t,"c");function J(U,G){Ct(G)?G.forEach(V=>U(V.bind(e))):G&&U(G.bind(e))}if(J(ld,m),J(Rn,g),J(ad,d),J(cd,y),J(od,f),J(sd,v),J(pd,z),J(fd,I),J(ud,w),J(Bs,x),J(Ts,B),J(dd,O),Ct(H))if(H.length){const U=t.exposed||(t.exposed={});H.forEach(G=>{Object.defineProperty(U,G,{get:()=>e[G],set:V=>e[G]=V,enumerable:!0})})}else t.exposed||(t.exposed={});A&&t.render===qe&&(t.render=A),et!=null&&(t.inheritAttrs=et),_&&(t.components=_),P&&(t.directives=P),O&&wl(t)}function kd(t,i,e=qe){Ct(t)&&(t=as(t));for(const n in t){const o=t[n];let s;Ht(o)?"default"in o?s=ti(o.from||n,o.default,!0):s=ti(o.from||n):s=ti(o),Yt(s)?Object.defineProperty(i,n,{enumerable:!0,configurable:!0,get:()=>s.value,set:l=>s.value=l}):i[n]=s}}function nr(t,i,e){Oe(Ct(t)?t.map(n=>n.bind(i.proxy)):t.bind(i.proxy),i,e)}function Cl(t,i,e,n){let o=n.includes(".")?kl(e,n):()=>e[n];if(te(t)){const s=i[t];Bt(s)&&Li(o,s)}else if(Bt(t))Li(o,t.bind(e));else if(Ht(t))if(Ct(t))t.forEach(s=>Cl(s,i,e,n));else{const s=Bt(t.handler)?t.handler.bind(e):i[t.handler];Bt(s)&&Li(o,s,t)}}function $l(t){const i=t.type,{mixins:e,extends:n}=i,{mixins:o,optionsCache:s,config:{optionMergeStrategies:l}}=t.appContext,r=s.get(i);let a;return r?a=r:!o.length&&!e&&!n?a=i:(a={},o.length&&o.forEach(c=>ho(a,c,l,!0)),ho(a,i,l)),Ht(i)&&s.set(i,a),a}function ho(t,i,e,n=!1){const{mixins:o,extends:s}=i;s&&ho(t,s,e,!0),o&&o.forEach(l=>ho(t,l,e,!0));for(const l in i)if(!(n&&l==="expose")){const r=wd[l]||e&&e[l];t[l]=r?r(t[l],i[l]):i[l]}return t}const wd={data:or,props:sr,emits:sr,methods:dn,computed:dn,beforeCreate:ge,created:ge,beforeMount:ge,mounted:ge,beforeUpdate:ge,updated:ge,beforeDestroy:ge,beforeUnmount:ge,destroyed:ge,unmounted:ge,activated:ge,deactivated:ge,errorCaptured:ge,serverPrefetch:ge,components:dn,directives:dn,watch:_d,provide:or,inject:xd};function or(t,i){return i?t?function(){return ue(Bt(t)?t.call(this,this):t,Bt(i)?i.call(this,this):i)}:i:t}function xd(t,i){return dn(as(t),as(i))}function as(t){if(Ct(t)){const i={};for(let e=0;e<t.length;e++)i[t[e]]=t[e];return i}return t}function ge(t,i){return t?[...new Set([].concat(t,i))]:i}function dn(t,i){return t?ue(Object.create(null),t,i):i}function sr(t,i){return t?Ct(t)&&Ct(i)?[...new Set([...t,...i])]:ue(Object.create(null),ir(t),ir(i??{})):i}function _d(t,i){if(!t)return i;if(!i)return t;const e=ue(Object.create(null),t);for(const n in i)e[n]=ge(t[n],i[n]);return e}function Il(){return{app:null,config:{isNativeTag:Ur,performance:!1,globalProperties:{},optionMergeStrategies:{},errorHandler:void 0,warnHandler:void 0,compilerOptions:{}},mixins:[],components:{},directives:{},provides:Object.create(null),optionsCache:new WeakMap,propsCache:new WeakMap,emitsCache:new WeakMap}}let Sd=0;function Cd(t,i){return function(n,o=null){Bt(n)||(n=ue({},n)),o!=null&&!Ht(o)&&(o=null);const s=Il(),l=new WeakSet,r=[];let a=!1;const c=s.app={_uid:Sd++,_component:n,_props:o,_container:null,_context:s,_instance:null,version:nu,get config(){return s.config},set config(u){},use(u,...m){return l.has(u)||(u&&Bt(u.install)?(l.add(u),u.install(c,...m)):Bt(u)&&(l.add(u),u(c,...m))),c},mixin(u){return s.mixins.includes(u)||s.mixins.push(u),c},component(u,m){return m?(s.components[u]=m,c):s.components[u]},directive(u,m){return m?(s.directives[u]=m,c):s.directives[u]},mount(u,m,g){if(!a){const d=c._ceVNode||at(n,o);return d.appContext=s,g===!0?g="svg":g===!1&&(g=void 0),t(d,u,g),a=!0,c._container=u,u.__vue_app__=c,Mo(d.component)}},onUnmount(u){r.push(u)},unmount(){a&&(Oe(r,c._instance,16),t(null,c._container),delete c._container.__vue_app__)},provide(u,m){return s.provides[u]=m,c},runWithContext(u){const m=Yi;Yi=c;try{return u()}finally{Yi=m}}};return c}}let Yi=null;const $d=(t,i)=>i==="modelValue"||i==="model-value"?t.modelModifiers:t[`${i}Modifiers`]||t[`${be(i)}Modifiers`]||t[`${bi(i)}Modifiers`];function Id(t,i,...e){if(t.isUnmounted)return;const n=t.vnode.props||Wt;let o=e;const s=i.startsWith("update:"),l=s&&$d(n,i.slice(7));l&&(l.trim&&(o=e.map(u=>te(u)?u.trim():u)),l.number&&(o=e.map(So)));let r,a=n[r=Oo(i)]||n[r=Oo(be(i))];!a&&s&&(a=n[r=Oo(bi(i))]),a&&Oe(a,t,6,o);const c=n[r+"Once"];if(c){if(!t.emitted)t.emitted={};else if(t.emitted[r])return;t.emitted[r]=!0,Oe(c,t,6,o)}}const Ad=new WeakMap;function Al(t,i,e=!1){const n=e?Ad:i.emitsCache,o=n.get(t);if(o!==void 0)return o;const s=t.emits;let l={},r=!1;if(!Bt(t)){const a=c=>{const u=Al(c,i,!0);u&&(r=!0,ue(l,u))};!e&&i.mixins.length&&i.mixins.forEach(a),t.extends&&a(t.extends),t.mixins&&t.mixins.forEach(a)}return!s&&!r?(Ht(t)&&n.set(t,null),null):(Ct(s)?s.forEach(a=>l[a]=null):ue(l,s),Ht(t)&&n.set(t,l),l)}function To(t,i){return!t||!ko(i)?!1:(i=i.slice(2),i=i==="Once"?i:i.replace(/Once$/,""),zt(t,i[0].toLowerCase()+i.slice(1))||zt(t,bi(i))||zt(t,i))}function rr(t){const{type:i,vnode:e,proxy:n,withProxy:o,propsOptions:[s],slots:l,attrs:r,emit:a,render:c,renderCache:u,props:m,data:g,setupState:d,ctx:y,inheritAttrs:f}=t,v=fo(t);let k,x;try{if(e.shapeFlag&4){const B=o||n,A=B;k=je(c.call(A,B,u,m,d,g,y)),x=r}else{const B=i;k=je(B.length>1?B(m,{attrs:r,slots:l,emit:a}):B(m,null)),x=i.props?r:Bd(r)}}catch(B){ei.length=0,Ao(B,t,1),k=at(ri)}let S=k;if(x&&f!==!1){const B=Object.keys(x),{shapeFlag:A}=S;B.length&&A&7&&(s&&B.some(wo)&&(x=Td(x,s)),S=Xi(S,x,!1,!0))}return e.dirs&&(S=Xi(S,null,!1,!0),S.dirs=S.dirs?S.dirs.concat(e.dirs):e.dirs),e.transition&&As(S,e.transition),k=S,fo(v),k}const Bd=t=>{let i;for(const e in t)(e==="class"||e==="style"||ko(e))&&((i||(i={}))[e]=t[e]);return i},Td=(t,i)=>{const e={};for(const n in t)(!wo(n)||!(n.slice(9)in i))&&(e[n]=t[n]);return e};function Ed(t,i,e){const{props:n,children:o,component:s}=t,{props:l,children:r,patchFlag:a}=i,c=s.emitsOptions;if(i.dirs||i.transition)return!0;if(e&&a>=0){if(a&1024)return!0;if(a&16)return n?lr(n,l,c):!!l;if(a&8){const u=i.dynamicProps;for(let m=0;m<u.length;m++){const g=u[m];if(Bl(l,n,g)&&!To(c,g))return!0}}}else return(o||r)&&(!r||!r.$stable)?!0:n===l?!1:n?l?lr(n,l,c):!0:!!l;return!1}function lr(t,i,e){const n=Object.keys(i);if(n.length!==Object.keys(t).length)return!0;for(let o=0;o<n.length;o++){const s=n[o];if(Bl(i,t,s)&&!To(e,s))return!0}return!1}function Bl(t,i,e){const n=t[e],o=i[e];return e==="style"&&Ht(n)&&Ht(o)?!nn(n,o):n!==o}function Md({vnode:t,parent:i,suspense:e},n){for(;i;){const o=i.subTree;if(o.suspense&&o.suspense.activeBranch===t&&(o.suspense.vnode.el=o.el=n,t=o),o===t)(t=i.vnode).el=n,i=i.parent;else break}e&&e.activeBranch===t&&(e.vnode.el=n)}const Tl={},El=()=>Object.create(Tl),Ml=t=>Object.getPrototypeOf(t)===Tl;function Dd(t,i,e,n=!1){const o={},s=El();t.propsDefaults=Object.create(null),Dl(t,i,o,s);for(const l in t.propsOptions[0])l in o||(o[l]=void 0);e?t.props=n?o:Fc(o):t.type.props?t.props=o:t.props=s,t.attrs=s}function Ld(t,i,e,n){const{props:o,attrs:s,vnode:{patchFlag:l}}=t,r=Ot(o),[a]=t.propsOptions;let c=!1;if((n||l>0)&&!(l&16)){if(l&8){const u=t.vnode.dynamicProps;for(let m=0;m<u.length;m++){let g=u[m];if(To(t.emitsOptions,g))continue;const d=i[g];if(a)if(zt(s,g))d!==s[g]&&(s[g]=d,c=!0);else{const y=be(g);o[y]=cs(a,r,y,d,t,!1)}else d!==s[g]&&(s[g]=d,c=!0)}}}else{Dl(t,i,o,s)&&(c=!0);let u;for(const m in r)(!i||!zt(i,m)&&((u=bi(m))===m||!zt(i,u)))&&(a?e&&(e[m]!==void 0||e[u]!==void 0)&&(o[m]=cs(a,r,m,void 0,t,!0)):delete o[m]);if(s!==r)for(const m in s)(!i||!zt(i,m))&&(delete s[m],c=!0)}c&&Xe(t.attrs,"set","")}function Dl(t,i,e,n){const[o,s]=t.propsOptions;let l=!1,r;if(i)for(let a in i){if(pn(a))continue;const c=i[a];let u;o&&zt(o,u=be(a))?!s||!s.includes(u)?e[u]=c:(r||(r={}))[u]=c:To(t.emitsOptions,a)||(!(a in n)||c!==n[a])&&(n[a]=c,l=!0)}if(s){const a=Ot(e),c=r||Wt;for(let u=0;u<s.length;u++){const m=s[u];e[m]=cs(o,a,m,c[m],t,!zt(c,m))}}return l}function cs(t,i,e,n,o,s){const l=t[e];if(l!=null){const r=zt(l,"default");if(r&&n===void 0){const a=l.default;if(l.type!==Function&&!l.skipFactory&&Bt(a)){const{propsDefaults:c}=o;if(e in c)n=c[e];else{const u=On(o);n=c[e]=a.call(null,i),u()}}else n=a;o.ce&&o.ce._setProp(e,n)}l[0]&&(s&&!r?n=!1:l[1]&&(n===""||n===bi(e))&&(n=!0))}return n}const Pd=new WeakMap;function Ll(t,i,e=!1){const n=e?Pd:i.propsCache,o=n.get(t);if(o)return o;const s=t.props,l={},r=[];let a=!1;if(!Bt(t)){const u=m=>{a=!0;const[g,d]=Ll(m,i,!0);ue(l,g),d&&r.push(...d)};!e&&i.mixins.length&&i.mixins.forEach(u),t.extends&&u(t.extends),t.mixins&&t.mixins.forEach(u)}if(!s&&!a)return Ht(t)&&n.set(t,qi),qi;if(Ct(s))for(let u=0;u<s.length;u++){const m=be(s[u]);ar(m)&&(l[m]=Wt)}else if(s)for(const u in s){const m=be(u);if(ar(m)){const g=s[u],d=l[m]=Ct(g)||Bt(g)?{type:g}:ue({},g),y=d.type;let f=!1,v=!0;if(Ct(y))for(let k=0;k<y.length;++k){const x=y[k],S=Bt(x)&&x.name;if(S==="Boolean"){f=!0;break}else S==="String"&&(v=!1)}else f=Bt(y)&&y.name==="Boolean";d[0]=f,d[1]=v,(f||zt(d,"default"))&&r.push(m)}}const c=[l,r];return Ht(t)&&n.set(t,c),c}function ar(t){return t[0]!=="$"&&!pn(t)}const Es=t=>t==="_"||t==="_ctx"||t==="$stable",Ms=t=>Ct(t)?t.map(je):[je(t)],Rd=(t,i,e)=>{if(i._n)return i;const n=bl((...o)=>Ms(i(...o)),e);return n._c=!1,n},Pl=(t,i,e)=>{const n=t._ctx;for(const o in t){if(Es(o))continue;const s=t[o];if(Bt(s))i[o]=Rd(o,s,n);else if(s!=null){const l=Ms(s);i[o]=()=>l}}},Rl=(t,i)=>{const e=Ms(i);t.slots.default=()=>e},Ol=(t,i,e)=>{for(const n in i)(e||!Es(n))&&(t[n]=i[n])},Od=(t,i,e)=>{const n=t.slots=El();if(t.vnode.shapeFlag&32){const o=i._;o?(Ol(n,i,e),e&&Kr(n,"_",o,!0)):Pl(i,n)}else i&&Rl(t,i)},zd=(t,i,e)=>{const{vnode:n,slots:o}=t;let s=!0,l=Wt;if(n.shapeFlag&32){const r=i._;r?e&&r===1?s=!1:Ol(o,i,e):(s=!i.$stable,Pl(i,o)),l=i}else i&&(Rl(t,i),l={default:1});if(s)for(const r in o)!Es(r)&&l[r]==null&&delete o[r]},we=Ud;function Nd(t){return Fd(t)}function Fd(t,i){const e=Co();e.__VUE__=!0;const{insert:n,remove:o,patchProp:s,createElement:l,createText:r,createComment:a,setText:c,setElementText:u,parentNode:m,nextSibling:g,setScopeId:d=qe,insertStaticContent:y}=t,f=(T,F,h,j=null,L=null,C=null,$=void 0,D=null,Z=!!F.dynamicChildren)=>{if(T===F)return;T&&!ln(T,F)&&(j=ut(T),R(T,L,C,!0),T=null),F.patchFlag===-2&&(Z=!1,F.dynamicChildren=null);const{type:K,ref:q,shapeFlag:it}=F;switch(K){case Eo:v(T,F,h,j);break;case ri:k(T,F,h,j);break;case Xn:T==null&&x(F,h,j,$);break;case Gt:_(T,F,h,j,L,C,$,D,Z);break;default:it&1?A(T,F,h,j,L,C,$,D,Z):it&6?P(T,F,h,j,L,C,$,D,Z):(it&64||it&128)&&K.process(T,F,h,j,L,C,$,D,Z,dt)}q!=null&&L?gn(q,T&&T.ref,C,F||T,!F):q==null&&T&&T.ref!=null&&gn(T.ref,null,C,T,!0)},v=(T,F,h,j)=>{if(T==null)n(F.el=r(F.children),h,j);else{const L=F.el=T.el;F.children!==T.children&&c(L,F.children)}},k=(T,F,h,j)=>{T==null?n(F.el=a(F.children||""),h,j):F.el=T.el},x=(T,F,h,j)=>{[T.el,T.anchor]=y(T.children,F,h,j,T.el,T.anchor)},S=({el:T,anchor:F},h,j)=>{let L;for(;T&&T!==F;)L=g(T),n(T,h,j),T=L;n(F,h,j)},B=({el:T,anchor:F})=>{let h;for(;T&&T!==F;)h=g(T),o(T),T=h;o(F)},A=(T,F,h,j,L,C,$,D,Z)=>{if(F.type==="svg"?$="svg":F.type==="math"&&($="mathml"),T==null)I(F,h,j,L,C,$,D,Z);else{const K=T.el&&T.el._isVueCE?T.el:null;try{K&&K._beginPatch(),O(T,F,L,C,$,D,Z)}finally{K&&K._endPatch()}}},I=(T,F,h,j,L,C,$,D)=>{let Z,K;const{props:q,shapeFlag:it,transition:lt,dirs:rt}=T;if(Z=T.el=l(T.type,C,q&&q.is,q),it&8?u(Z,T.children):it&16&&z(T.children,Z,null,j,L,Wo(T,C),$,D),rt&&xi(T,null,j,"created"),w(Z,T,T.scopeId,$,j),q){for(const wt in q)wt!=="value"&&!pn(wt)&&s(Z,wt,null,q[wt],C,j);"value"in q&&s(Z,"value",null,q.value,C),(K=q.onVnodeBeforeMount)&&Ne(K,j,T)}rt&&xi(T,null,j,"beforeMount");const pt=Hd(L,lt);pt&&lt.beforeEnter(Z),n(Z,F,h),((K=q&&q.onVnodeMounted)||pt||rt)&&we(()=>{try{K&&Ne(K,j,T),pt&&lt.enter(Z),rt&&xi(T,null,j,"mounted")}finally{}},L)},w=(T,F,h,j,L)=>{if(h&&d(T,h),j)for(let C=0;C<j.length;C++)d(T,j[C]);if(L){let C=L.subTree;if(F===C||Hl(C.type)&&(C.ssContent===F||C.ssFallback===F)){const $=L.vnode;w(T,$,$.scopeId,$.slotScopeIds,L.parent)}}},z=(T,F,h,j,L,C,$,D,Z=0)=>{for(let K=Z;K<T.length;K++){const q=T[K]=D?Je(T[K]):je(T[K]);f(null,q,F,h,j,L,C,$,D)}},O=(T,F,h,j,L,C,$)=>{const D=F.el=T.el;let{patchFlag:Z,dynamicChildren:K,dirs:q}=F;Z|=T.patchFlag&16;const it=T.props||Wt,lt=F.props||Wt;let rt;if(h&&_i(h,!1),(rt=lt.onVnodeBeforeUpdate)&&Ne(rt,h,F,T),q&&xi(F,T,h,"beforeUpdate"),h&&_i(h,!0),K&&(!T.dynamicChildren||T.dynamicChildren.length!==K.length)&&(Z=0,$=!1,K=null),(it.innerHTML&&lt.innerHTML==null||it.textContent&&lt.textContent==null)&&u(D,""),K?H(T.dynamicChildren,K,D,h,j,Wo(F,L),C):$||G(T,F,D,null,h,j,Wo(F,L),C,!1),Z>0){if(Z&16)et(D,it,lt,h,L);else if(Z&2&&it.class!==lt.class&&s(D,"class",null,lt.class,L),Z&4&&s(D,"style",it.style,lt.style,L),Z&8){const pt=F.dynamicProps;for(let wt=0;wt<pt.length;wt++){const kt=pt[wt],Mt=it[kt],Zt=lt[kt];(Zt!==Mt||kt==="value")&&s(D,kt,Mt,Zt,L,h)}}Z&1&&T.children!==F.children&&u(D,F.children)}else!$&&K==null&&et(D,it,lt,h,L);((rt=lt.onVnodeUpdated)||q)&&we(()=>{rt&&Ne(rt,h,F,T),q&&xi(F,T,h,"updated")},j)},H=(T,F,h,j,L,C,$)=>{for(let D=0;D<F.length;D++){const Z=T[D],K=F[D],q=Z.el&&(Z.type===Gt||!ln(Z,K)||Z.shapeFlag&198)?m(Z.el):h;f(Z,K,q,null,j,L,C,$,!0)}},et=(T,F,h,j,L)=>{if(F!==h){if(F!==Wt)for(const C in F)!pn(C)&&!(C in h)&&s(T,C,F[C],null,L,j);for(const C in h){if(pn(C))continue;const $=h[C],D=F[C];$!==D&&C!=="value"&&s(T,C,D,$,L,j)}"value"in h&&s(T,"value",F.value,h.value,L)}},_=(T,F,h,j,L,C,$,D,Z)=>{const K=F.el=T?T.el:r(""),q=F.anchor=T?T.anchor:r("");let{patchFlag:it,dynamicChildren:lt,slotScopeIds:rt}=F;rt&&(D=D?D.concat(rt):rt),T==null?(n(K,h,j),n(q,h,j),z(F.children||[],h,q,L,C,$,D,Z)):it>0&&it&64&&lt&&T.dynamicChildren&&T.dynamicChildren.length===lt.length?(H(T.dynamicChildren,lt,h,L,C,$,D),(F.key!=null||L&&F===L.subTree)&&zl(T,F,!0)):G(T,F,h,q,L,C,$,D,Z)},P=(T,F,h,j,L,C,$,D,Z)=>{F.slotScopeIds=D,T==null?F.shapeFlag&512?L.ctx.activate(F,h,j,$,Z):b(F,h,j,L,C,$,Z):N(T,F,Z)},b=(T,F,h,j,L,C,$)=>{const D=T.component=Zd(T,j,L);if(xl(T)&&(D.ctx.renderer=dt),Jd(D,!1,$),D.asyncDep){if(L&&L.registerDep(D,J,$),!T.el){const Z=D.subTree=at(ri);k(null,Z,F,h),T.placeholder=Z.el}}else J(D,T,F,h,L,C,$)},N=(T,F,h)=>{const j=F.component=T.component;if(Ed(T,F,h))if(j.asyncDep&&!j.asyncResolved){U(j,F,h);return}else j.next=F,j.update();else F.el=T.el,j.vnode=F},J=(T,F,h,j,L,C,$)=>{const D=()=>{if(T.isMounted){let{next:it,bu:lt,u:rt,parent:pt,vnode:wt}=T;{const se=Nl(T);if(se){it&&(it.el=wt.el,U(T,it,$)),se.asyncDep.then(()=>{we(()=>{T.isUnmounted||K()},L)});return}}let kt=it,Mt;_i(T,!1),it?(it.el=wt.el,U(T,it,$)):it=wt,lt&&Jn(lt),(Mt=it.props&&it.props.onVnodeBeforeUpdate)&&Ne(Mt,pt,it,wt),_i(T,!0);const Zt=rr(T),Vt=T.subTree;T.subTree=Zt,f(Vt,Zt,m(Vt.el),ut(Vt),T,L,C),it.el=Zt.el,kt===null&&Md(T,Zt.el),rt&&we(rt,L),(Mt=it.props&&it.props.onVnodeUpdated)&&we(()=>Ne(Mt,pt,it,wt),L)}else{let it;const{el:lt,props:rt}=F,{bm:pt,m:wt,parent:kt,root:Mt,type:Zt}=T,Vt=Zi(F);_i(T,!1),pt&&Jn(pt),!Vt&&(it=rt&&rt.onVnodeBeforeMount)&&Ne(it,kt,F),_i(T,!0);{Mt.ce&&Mt.ce._hasShadowRoot()&&Mt.ce._injectChildStyle(Zt,T.parent?T.parent.type:void 0);const se=T.subTree=rr(T);f(null,se,h,j,T,L,C),F.el=se.el}if(wt&&we(wt,L),!Vt&&(it=rt&&rt.onVnodeMounted)){const se=F;we(()=>Ne(it,kt,se),L)}(F.shapeFlag&256||kt&&Zi(kt.vnode)&&kt.vnode.shapeFlag&256)&&T.a&&we(T.a,L),T.isMounted=!0,F=h=j=null}};T.scope.on();const Z=T.effect=new Jr(D);T.scope.off();const K=T.update=Z.run.bind(Z),q=T.job=Z.runIfDirty.bind(Z);q.i=T,q.id=T.uid,Z.scheduler=()=>Is(q),_i(T,!0),K()},U=(T,F,h)=>{F.component=T;const j=T.vnode.props;T.vnode=F,T.next=null,Ld(T,F.props,j,h),zd(T,F.children,h),ni(),Xs(T),oi()},G=(T,F,h,j,L,C,$,D,Z=!1)=>{const K=T&&T.children,q=T?T.shapeFlag:0,it=F.children,{patchFlag:lt,shapeFlag:rt}=F;if(lt>0){if(lt&128){M(K,it,h,j,L,C,$,D,Z);return}else if(lt&256){V(K,it,h,j,L,C,$,D,Z);return}}rt&8?(q&16&&W(K,L,C),it!==K&&u(h,it)):q&16?rt&16?M(K,it,h,j,L,C,$,D,Z):W(K,L,C,!0):(q&8&&u(h,""),rt&16&&z(it,h,j,L,C,$,D,Z))},V=(T,F,h,j,L,C,$,D,Z)=>{T=T||qi,F=F||qi;const K=T.length,q=F.length,it=Math.min(K,q);let lt;for(lt=0;lt<it;lt++){const rt=F[lt]=Z?Je(F[lt]):je(F[lt]);f(T[lt],rt,h,null,L,C,$,D,Z)}K>q?W(T,L,C,!0,!1,it):z(F,h,j,L,C,$,D,Z,it)},M=(T,F,h,j,L,C,$,D,Z)=>{let K=0;const q=F.length;let it=T.length-1,lt=q-1;for(;K<=it&&K<=lt;){const rt=T[K],pt=F[K]=Z?Je(F[K]):je(F[K]);if(ln(rt,pt))f(rt,pt,h,null,L,C,$,D,Z);else break;K++}for(;K<=it&&K<=lt;){const rt=T[it],pt=F[lt]=Z?Je(F[lt]):je(F[lt]);if(ln(rt,pt))f(rt,pt,h,null,L,C,$,D,Z);else break;it--,lt--}if(K>it){if(K<=lt){const rt=lt+1,pt=rt<q?F[rt].el:j;for(;K<=lt;)f(null,F[K]=Z?Je(F[K]):je(F[K]),h,pt,L,C,$,D,Z),K++}}else if(K>lt)for(;K<=it;)R(T[K],L,C,!0),K++;else{const rt=K,pt=K,wt=new Map;for(K=pt;K<=lt;K++){const ne=F[K]=Z?Je(F[K]):je(F[K]);ne.key!=null&&wt.set(ne.key,K)}let kt,Mt=0;const Zt=lt-pt+1;let Vt=!1,se=0;const Nt=new Array(Zt);for(K=0;K<Zt;K++)Nt[K]=0;for(K=rt;K<=it;K++){const ne=T[K];if(Mt>=Zt){R(ne,L,C,!0);continue}let Jt;if(ne.key!=null)Jt=wt.get(ne.key);else for(kt=pt;kt<=lt;kt++)if(Nt[kt-pt]===0&&ln(ne,F[kt])){Jt=kt;break}Jt===void 0?R(ne,L,C,!0):(Nt[Jt-pt]=K+1,Jt>=se?se=Jt:Vt=!0,f(ne,F[Jt],h,null,L,C,$,D,Z),Mt++)}const Ke=Vt?jd(Nt):qi;for(kt=Ke.length-1,K=Zt-1;K>=0;K--){const ne=pt+K,Jt=F[ne],ki=F[ne+1],zi=ne+1<q?ki.el||Fl(ki):j;Nt[K]===0?f(null,Jt,h,zi,L,C,$,D,Z):Vt&&(kt<0||K!==Ke[kt]?E(Jt,h,zi,2):kt--)}}},E=(T,F,h,j,L=null)=>{const{el:C,type:$,transition:D,children:Z,shapeFlag:K}=T;if(K&6){E(T.component.subTree,F,h,j);return}if(K&128){T.suspense.move(F,h,j);return}if(K&64){$.move(T,F,h,dt);return}if($===Gt){n(C,F,h);for(let it=0;it<Z.length;it++)E(Z[it],F,h,j);n(T.anchor,F,h);return}if($===Xn){S(T,F,h);return}if(j!==2&&K&1&&D)if(j===0)D.persisted&&!C[jo]?n(C,F,h):(D.beforeEnter(C),n(C,F,h),we(()=>D.enter(C),L));else{const{leave:it,delayLeave:lt,afterLeave:rt}=D,pt=()=>{T.ctx.isUnmounted?o(C):n(C,F,h)},wt=()=>{const kt=C._isLeaving||!!C[jo];C._isLeaving&&C[jo](!0),D.persisted&&!kt?pt():it(C,()=>{pt(),rt&&rt()})};lt?lt(C,pt,wt):wt()}else n(C,F,h)},R=(T,F,h,j=!1,L=!1)=>{const{type:C,props:$,ref:D,children:Z,dynamicChildren:K,shapeFlag:q,patchFlag:it,dirs:lt,cacheIndex:rt,memo:pt}=T;if(it===-2&&(L=!1),D!=null&&(ni(),gn(D,null,h,T,!0),oi()),rt!=null&&(F.renderCache[rt]=void 0),q&256){F.ctx.deactivate(T);return}const wt=q&1&&lt,kt=!Zi(T);let Mt;if(kt&&(Mt=$&&$.onVnodeBeforeUnmount)&&Ne(Mt,F,T),q&6)Y(T.component,h,j);else{if(q&128){T.suspense.unmount(h,j);return}wt&&xi(T,null,F,"beforeUnmount"),q&64?T.type.remove(T,F,h,dt,j):K&&!K.hasOnce&&(C!==Gt||it>0&&it&64)?W(K,F,h,!1,!0):(C===Gt&&it&384||!L&&q&16)&&W(Z,F,h),j&&tt(T)}const Zt=pt!=null&&rt==null;(kt&&(Mt=$&&$.onVnodeUnmounted)||wt||Zt)&&we(()=>{Mt&&Ne(Mt,F,T),wt&&xi(T,null,F,"unmounted"),Zt&&(T.el=null)},h)},tt=T=>{const{type:F,el:h,anchor:j,transition:L}=T;if(F===Gt){Q(h,j);return}if(F===Xn){B(T);return}const C=()=>{o(h),L&&!L.persisted&&L.afterLeave&&L.afterLeave()};if(T.shapeFlag&1&&L&&!L.persisted){const{leave:$,delayLeave:D}=L,Z=()=>$(h,C);D?D(T.el,C,Z):Z()}else C()},Q=(T,F)=>{let h;for(;T!==F;)h=g(T),o(T),T=h;o(F)},Y=(T,F,h)=>{const{bum:j,scope:L,job:C,subTree:$,um:D,m:Z,a:K}=T;cr(Z),cr(K),j&&Jn(j),L.stop(),C&&(C.flags|=8,R($,T,F,h)),D&&we(D,F),we(()=>{T.isUnmounted=!0},F)},W=(T,F,h,j=!1,L=!1,C=0)=>{for(let $=C;$<T.length;$++)R(T[$],F,h,j,L)},ut=T=>{if(T.shapeFlag&6)return ut(T.component.subTree);if(T.shapeFlag&128)return T.suspense.next();const F=g(T.anchor||T.el),h=F&&F[id];return h?g(h):F};let ct=!1;const X=(T,F,h)=>{let j;T==null?F._vnode&&(R(F._vnode,null,null,!0),j=F._vnode.component):f(F._vnode||null,T,F,null,null,null,h),F._vnode=T,ct||(ct=!0,Xs(j),ml(),ct=!1)},dt={p:f,um:R,m:E,r:tt,mt:b,mc:z,pc:G,pbc:H,n:ut,o:t};return{render:X,hydrate:void 0,createApp:Cd(X)}}function Wo({type:t,props:i},e){return e==="svg"&&t==="foreignObject"||e==="mathml"&&t==="annotation-xml"&&i&&i.encoding&&i.encoding.includes("html")?void 0:e}function _i({effect:t,job:i},e){e?(t.flags|=32,i.flags|=4):(t.flags&=-33,i.flags&=-5)}function Hd(t,i){return(!t||t&&!t.pendingBranch)&&i&&!i.persisted}function zl(t,i,e=!1){const n=t.children,o=i.children;if(Ct(n)&&Ct(o))for(let s=0;s<n.length;s++){const l=n[s];let r=o[s];r.shapeFlag&1&&!r.dynamicChildren&&((r.patchFlag<=0||r.patchFlag===32)&&(r=o[s]=Je(o[s]),r.el=l.el),!e&&r.patchFlag!==-2&&zl(l,r)),r.type===Eo&&(r.patchFlag===-1&&(r=o[s]=Je(r)),r.el=l.el),r.type===ri&&!r.el&&(r.el=l.el)}}function jd(t){const i=t.slice(),e=[0];let n,o,s,l,r;const a=t.length;for(n=0;n<a;n++){const c=t[n];if(c!==0){if(o=e[e.length-1],t[o]<c){i[n]=o,e.push(n);continue}for(s=0,l=e.length-1;s<l;)r=s+l>>1,t[e[r]]<c?s=r+1:l=r;c<t[e[s]]&&(s>0&&(i[n]=e[s-1]),e[s]=n)}}for(s=e.length,l=e[s-1];s-- >0;)e[s]=l,l=i[l];return e}function Nl(t){const i=t.subTree.component;if(i)return i.asyncDep&&!i.asyncResolved?i:Nl(i)}function cr(t){if(t)for(let i=0;i<t.length;i++)t[i].flags|=8}function Fl(t){if(t.placeholder)return t.placeholder;const i=t.component;return i?Fl(i.subTree):null}const Hl=t=>t.__isSuspense;function Ud(t,i){i&&i.pendingBranch?Ct(t)?i.effects.push(...t):i.effects.push(t):Jc(t)}const Gt=Symbol.for("v-fgt"),Eo=Symbol.for("v-txt"),ri=Symbol.for("v-cmt"),Xn=Symbol.for("v-stc"),ei=[];let Ce=null;function ot(t=!1){ei.push(Ce=t?null:[])}function Ds(){ei.pop(),Ce=ei[ei.length-1]||null}let Tn=1;function dr(t,i=!1){Tn+=t,t<0&&Ce&&i&&(Ce.hasOnce=!0)}function jl(t){return t.dynamicChildren=Tn>0?Ce||qi:null,Ds(),Tn>0&&Ce&&Ce.push(t),t}function st(t,i,e,n,o,s){return jl(p(t,i,e,n,o,s,!0))}function De(t,i,e,n,o){return jl(at(t,i,e,n,o,!0))}function Ls(t){return t?t.__v_isVNode===!0:!1}function ln(t,i){return t.type===i.type&&t.key===i.key}const Ul=({key:t})=>t??null,Qn=({ref:t,ref_key:i,ref_for:e})=>(typeof t=="number"&&(t=""+t),t!=null?te(t)||Yt(t)||Bt(t)?{i:de,r:t,k:i,f:!!e}:t:null);function p(t,i=null,e=null,n=0,o=null,s=t===Gt?0:1,l=!1,r=!1){const a={__v_isVNode:!0,__v_skip:!0,type:t,props:i,key:i&&Ul(i),ref:i&&Qn(i),scopeId:vl,slotScopeIds:null,children:e,component:null,suspense:null,ssContent:null,ssFallback:null,dirs:null,transition:null,el:null,anchor:null,target:null,targetStart:null,targetAnchor:null,staticCount:0,shapeFlag:s,patchFlag:n,dynamicProps:o,dynamicChildren:null,appContext:null,ctx:de};return r?(mo(a,e),s&128&&t.normalize(a)):e&&(a.shapeFlag|=te(e)?8:16),Tn>0&&!l&&Ce&&(a.patchFlag>0||s&6)&&a.patchFlag!==32&&Ce.push(a),a}const at=Wd;function Wd(t,i=null,e=null,n=0,o=null,s=!1){if((!t||t===gd)&&(t=ri),Ls(t)){const r=Xi(t,i,!0);return e&&mo(r,e),Tn>0&&!s&&Ce&&(r.shapeFlag&6?Ce[Ce.indexOf(t)]=r:Ce.push(r)),r.patchFlag=-2,r}if(iu(t)&&(t=t.__vccOpts),i){i=Vd(i);let{class:r,style:a}=i;r&&!te(r)&&(i.class=It(r)),Ht(a)&&($s(a)&&!Ct(a)&&(a=ue({},a)),i.style=$n(a))}const l=te(t)?1:Hl(t)?128:nd(t)?64:Ht(t)?4:Bt(t)?2:0;return p(t,i,e,n,o,l,s,!0)}function Vd(t){return t?$s(t)||Ml(t)?ue({},t):t:null}function Xi(t,i,e=!1,n=!1){const{props:o,ref:s,patchFlag:l,children:r,transition:a}=t,c=i?qd(o||{},i):o,u={__v_isVNode:!0,__v_skip:!0,type:t.type,props:c,key:c&&Ul(c),ref:i&&i.ref?e&&s?Ct(s)?s.concat(Qn(i)):[s,Qn(i)]:Qn(i):s,scopeId:t.scopeId,slotScopeIds:t.slotScopeIds,children:r,target:t.target,targetStart:t.targetStart,targetAnchor:t.targetAnchor,staticCount:t.staticCount,shapeFlag:t.shapeFlag,patchFlag:i&&t.type!==Gt?l===-1?16:l|16:l,dynamicProps:t.dynamicProps,dynamicChildren:t.dynamicChildren,appContext:t.appContext,dirs:t.dirs,transition:a,component:t.component,suspense:t.suspense,ssContent:t.ssContent&&Xi(t.ssContent),ssFallback:t.ssFallback&&Xi(t.ssFallback),placeholder:t.placeholder,el:t.el,anchor:t.anchor,ctx:t.ctx,ce:t.ce};return a&&n&&As(u,a.clone(u)),u}function Ae(t=" ",i=0){return at(Eo,null,t,i)}function ke(t,i){const e=at(Xn,null,t);return e.staticCount=i,e}function Rt(t="",i=!1){return i?(ot(),De(ri,null,t)):at(ri,null,t)}function je(t){return t==null||typeof t=="boolean"?at(ri):Ct(t)?at(Gt,null,t.slice()):Ls(t)?Je(t):at(Eo,null,String(t))}function Je(t){return t.el===null&&t.patchFlag!==-1||t.memo?t:Xi(t)}function mo(t,i){let e=0;const{shapeFlag:n}=t;if(i==null)i=null;else if(Ct(i))e=16;else if(typeof i=="object")if(n&65){const o=i.default;o&&(o._c&&(o._d=!1),mo(t,o()),o._c&&(o._d=!0));return}else{e=32;const o=i._;!o&&!Ml(i)?i._ctx=de:o===3&&de&&(de.slots._===1?i._=1:(i._=2,t.patchFlag|=1024))}else if(Bt(i)){if(n&65){mo(t,{default:i});return}i={default:i,_ctx:de},e=32}else i=String(i),n&64?(e=16,i=[Ae(i)]):e=8;t.children=i,t.shapeFlag|=e}function qd(...t){const i={};for(let e=0;e<t.length;e++){const n=t[e];for(const o in n)if(o==="class")i.class!==n.class&&(i.class=It([i.class,n.class]));else if(o==="style")i.style=$n([i.style,n.style]);else if(ko(o)){const s=i[o],l=n[o];l&&s!==l&&!(Ct(s)&&s.includes(l))?i[o]=s?[].concat(s,l):l:l==null&&s==null&&!wo(o)&&(i[o]=l)}else o!==""&&(i[o]=n[o])}return i}function Ne(t,i,e,n=null){Oe(t,i,7,[e,n])}const Kd=Il();let Gd=0;function Zd(t,i,e){const n=t.type,o=(i?i.appContext:t.appContext)||Kd,s={uid:Gd++,vnode:t,type:n,parent:i,appContext:o,root:null,next:null,subTree:null,effect:null,update:null,job:null,scope:new wc(!0),render:null,proxy:null,exposed:null,exposeProxy:null,withProxy:null,provides:i?i.provides:Object.create(o.provides),ids:i?i.ids:["",0,0],accessCache:null,renderCache:[],components:null,directives:null,propsOptions:Ll(n,o),emitsOptions:Al(n,o),emit:null,emitted:null,propsDefaults:Wt,inheritAttrs:n.inheritAttrs,ctx:Wt,data:Wt,props:Wt,attrs:Wt,slots:Wt,refs:Wt,setupState:Wt,setupContext:null,suspense:e,suspenseId:e?e.pendingId:0,asyncDep:null,asyncResolved:!1,isMounted:!1,isUnmounted:!1,isDeactivated:!1,bc:null,c:null,bm:null,m:null,bu:null,u:null,um:null,bum:null,da:null,a:null,rtg:null,rtc:null,ec:null,sp:null};return s.ctx={_:s},s.root=i?i.root:s,s.emit=Id.bind(null,s),t.ce&&t.ce(s),s}let me=null;const Yd=()=>me||de;let go,ds;{const t=Co(),i=(e,n)=>{let o;return(o=t[e])||(o=t[e]=[]),o.push(n),s=>{o.length>1?o.forEach(l=>l(s)):o[0](s)}};go=i("__VUE_INSTANCE_SETTERS__",e=>me=e),ds=i("__VUE_SSR_SETTERS__",e=>En=e)}const On=t=>{const i=me;return go(t),t.scope.on(),()=>{t.scope.off(),go(i)}},ur=()=>{me&&me.scope.off(),go(null)};function Wl(t){return t.vnode.shapeFlag&4}let En=!1;function Jd(t,i=!1,e=!1){i&&ds(i);const{props:n,children:o}=t.vnode,s=Wl(t);Dd(t,n,s,i),Od(t,o,e||i);const l=s?Xd(t,i):void 0;return i&&ds(!1),l}function Xd(t,i){const e=t.type;t.accessCache=Object.create(null),t.proxy=new Proxy(t.ctx,bd);const{setup:n}=e;if(n){ni();const o=t.setupContext=n.length>1?tu(t):null,s=On(t),l=Pn(n,t,0,[t.props,o]),r=Wr(l);if(oi(),s(),(r||t.sp)&&!Zi(t)&&wl(t),r){if(l.then(ur,ur),i)return l.then(a=>{fr(t,a)}).catch(a=>{Ao(a,t,0)});t.asyncDep=l}else fr(t,l)}else Vl(t)}function fr(t,i,e){Bt(i)?t.type.__ssrInlineRender?t.ssrRender=i:t.render=i:Ht(i)&&(t.setupState=ul(i)),Vl(t)}function Vl(t,i,e){const n=t.type;t.render||(t.render=n.render||qe);{const o=On(t);ni();try{yd(t)}finally{oi(),o()}}}const Qd={get(t,i){return he(t,"get",""),t[i]}};function tu(t){const i=e=>{t.exposed=e||{}};return{attrs:new Proxy(t.attrs,Qd),slots:t.slots,emit:t.emit,expose:i}}function Mo(t){return t.exposed?t.exposeProxy||(t.exposeProxy=new Proxy(ul(Hc(t.exposed)),{get(i,e){if(e in i)return i[e];if(e in vn)return vn[e](t)},has(i,e){return e in i||e in vn}})):t.proxy}function eu(t,i=!0){return Bt(t)?t.displayName||t.name:t.name||i&&t.__name}function iu(t){return Bt(t)&&"__vccOpts"in t}const _t=(t,i)=>qc(t,i,En),nu="3.5.40";/**
* @vue/runtime-dom v3.5.40
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/let us;const pr=typeof window<"u"&&window.trustedTypes;if(pr)try{us=pr.createPolicy("vue",{createHTML:t=>t})}catch{}const ql=us?t=>us.createHTML(t):t=>t,ou="http://www.w3.org/2000/svg",su="http://www.w3.org/1998/Math/MathML",Ye=typeof document<"u"?document:null,hr=Ye&&Ye.createElement("template"),ru={insert:(t,i,e)=>{i.insertBefore(t,e||null)},remove:t=>{const i=t.parentNode;i&&i.removeChild(t)},createElement:(t,i,e,n)=>{const o=i==="svg"?Ye.createElementNS(ou,t):i==="mathml"?Ye.createElementNS(su,t):e?Ye.createElement(t,{is:e}):Ye.createElement(t);return t==="select"&&n&&n.multiple!=null&&o.setAttribute("multiple",n.multiple),o},createText:t=>Ye.createTextNode(t),createComment:t=>Ye.createComment(t),setText:(t,i)=>{t.nodeValue=i},setElementText:(t,i)=>{t.textContent=i},parentNode:t=>t.parentNode,nextSibling:t=>t.nextSibling,querySelector:t=>Ye.querySelector(t),setScopeId(t,i){t.setAttribute(i,"")},insertStaticContent(t,i,e,n,o,s){const l=e?e.previousSibling:i.lastChild;if(o&&(o===s||o.nextSibling))for(;i.insertBefore(o.cloneNode(!0),e),!(o===s||!(o=o.nextSibling)););else{hr.innerHTML=ql(n==="svg"?`<svg>${t}</svg>`:n==="mathml"?`<math>${t}</math>`:t);const r=hr.content;if(n==="svg"||n==="mathml"){const a=r.firstChild;for(;a.firstChild;)r.appendChild(a.firstChild);r.removeChild(a)}i.insertBefore(r,e)}return[l?l.nextSibling:i.firstChild,e?e.previousSibling:i.lastChild]}},lu=Symbol("_vtc");function au(t,i,e){const n=t[lu];n&&(i=(i?[i,...n]:[...n]).join(" ")),i==null?t.removeAttribute("class"):e?t.setAttribute("class",i):t.className=i}const vo=Symbol("_vod"),Kl=Symbol("_vsh"),Gl={name:"show",beforeMount(t,{value:i},{transition:e}){t[vo]=t.style.display==="none"?"":t.style.display,e&&i?e.beforeEnter(t):an(t,i)},mounted(t,{value:i},{transition:e}){e&&i&&e.enter(t)},updated(t,{value:i,oldValue:e},{transition:n}){!i!=!e&&(n?i?(n.beforeEnter(t),an(t,!0),n.enter(t)):n.leave(t,()=>{an(t,!1)}):an(t,i))},beforeUnmount(t,{value:i}){an(t,i)}};function an(t,i){t.style.display=i?t[vo]:"none",t[Kl]=!i}const cu=Symbol(""),du=/(?:^|;)\s*display\s*:/;function uu(t,i,e){const n=t.style,o=te(e);let s=!1;if(e&&!o){if(i)if(te(i))for(const l of i.split(";")){const r=l.slice(0,l.indexOf(":")).trim();e[r]==null&&un(n,r,"")}else for(const l in i)e[l]==null&&un(n,l,"");for(const l in e){l==="display"&&(s=!0);const r=e[l];r!=null?pu(t,l,!te(i)&&i?i[l]:void 0,r)||un(n,l,r):un(n,l,"")}}else if(o){if(i!==e){const l=n[cu];l&&(e+=";"+l),n.cssText=e,s=du.test(e)}}else i&&t.removeAttribute("style");vo in t&&(t[vo]=s?n.display:"",t[Kl]&&(n.display="none"))}const mr=/\s*!important$/;function un(t,i,e){if(Ct(e))e.forEach(n=>un(t,i,n));else if(e==null&&(e=""),i.startsWith("--"))t.setProperty(i,e);else{const n=fu(t,i);mr.test(e)?t.setProperty(bi(n),e.replace(mr,""),"important"):t[n]=e}}const gr=["Webkit","Moz","ms"],Vo={};function fu(t,i){const e=Vo[i];if(e)return e;let n=be(i);if(n!=="filter"&&n in t)return Vo[i]=n;n=_o(n);for(let o=0;o<gr.length;o++){const s=gr[o]+n;if(s in t)return Vo[i]=s}return i}function pu(t,i,e,n){return t.tagName==="TEXTAREA"&&(i==="width"||i==="height")&&te(n)&&e===n}const vr="http://www.w3.org/1999/xlink";function br(t,i,e,n,o,s=yc(i)){n&&i.startsWith("xlink:")?e==null?t.removeAttributeNS(vr,i.slice(6,i.length)):t.setAttributeNS(vr,i,e):e==null||s&&!Gr(e)?t.removeAttribute(i):t.setAttribute(i,s?"":Pe(e)?String(e):e)}function yr(t,i,e,n,o){if(i==="innerHTML"||i==="textContent"){e!=null&&(t[i]=i==="innerHTML"?ql(e):e);return}const s=t.tagName;if(i==="value"&&s!=="PROGRESS"&&!s.includes("-")){const r=s==="OPTION"?t.getAttribute("value")||"":t.value,a=e==null?t.type==="checkbox"?"on":"":String(e);(r!==a||!("_value"in t))&&(t.value=a),e==null&&t.removeAttribute(i),t._value=e;return}let l=!1;if(e===""||e==null){const r=typeof t[i];r==="boolean"?e=Gr(e):e==null&&r==="string"?(e="",l=!0):r==="number"&&(e=0,l=!0)}try{t[i]=e}catch{}l&&t.removeAttribute(o||i)}function pi(t,i,e,n){t.addEventListener(i,e,n)}function hu(t,i,e,n){t.removeEventListener(i,e,n)}const kr=Symbol("_vei");function mu(t,i,e,n,o=null){const s=t[kr]||(t[kr]={}),l=s[i];if(n&&l)l.value=n;else{const[r,a]=bu(i);if(n){const c=s[i]=wu(n,o);pi(t,r,c,a)}else l&&(hu(t,r,l,a),s[i]=void 0)}}const gu=/(Once|Passive|Capture)$/,vu=/^on:?(?:Once|Passive|Capture)$/;function bu(t){let i,e;for(;(e=t.match(gu))&&!vu.test(t);)i||(i={}),t=t.slice(0,t.length-e[1].length),i[e[1].toLowerCase()]=!0;return[t[2]===":"?t.slice(3):bi(t.slice(2)),i]}let qo=0;const yu=Promise.resolve(),ku=()=>qo||(yu.then(()=>qo=0),qo=Date.now());function wu(t,i){const e=n=>{if(!n._vts)n._vts=Date.now();else if(n._vts<=e.attached)return;const o=e.value;if(Ct(o)){const s=n.stopImmediatePropagation;n.stopImmediatePropagation=()=>{s.call(n),n._stopped=!0};const l=o.slice(),r=[n];for(let a=0;a<l.length&&!n._stopped;a++){const c=l[a];c&&Oe(c,i,5,r)}}else Oe(o,i,5,[n])};return e.value=t,e.attached=ku(),e}const wr=t=>t.charCodeAt(0)===111&&t.charCodeAt(1)===110&&t.charCodeAt(2)>96&&t.charCodeAt(2)<123,xu=(t,i,e,n,o,s)=>{const l=o==="svg";i==="class"?au(t,n,l):i==="style"?uu(t,e,n):ko(i)?wo(i)||mu(t,i,e,n,s):(i[0]==="."?(i=i.slice(1),!0):i[0]==="^"?(i=i.slice(1),!1):_u(t,i,n,l))?(yr(t,i,n),!t.tagName.includes("-")&&(i==="value"||i==="checked"||i==="selected")&&br(t,i,n,l,s,i!=="value")):t._isVueCE&&(Su(t,i)||t._def.__asyncLoader&&(/[A-Z]/.test(i)||!te(n)))?yr(t,be(i),n,s,i):(i==="true-value"?t._trueValue=n:i==="false-value"&&(t._falseValue=n),br(t,i,n,l))};function _u(t,i,e,n){if(n)return!!(i==="innerHTML"||i==="textContent"||i in t&&wr(i)&&Bt(e));if(i==="spellcheck"||i==="draggable"||i==="translate"||i==="autocorrect"||i==="sandbox"&&t.tagName==="IFRAME"||i==="form"||i==="list"&&t.tagName==="INPUT"||i==="type"&&t.tagName==="TEXTAREA")return!1;if(i==="width"||i==="height"){const o=t.tagName;if(o==="IMG"||o==="VIDEO"||o==="CANVAS"||o==="SOURCE")return!1}return wr(i)&&te(e)?!1:i in t}function Su(t,i){const e=t._def.props;if(!e)return!1;const n=be(i);return Array.isArray(e)?e.some(o=>be(o)===n):Object.keys(e).some(o=>be(o)===n)}const Qi=t=>{const i=t.props["onUpdate:modelValue"]||!1;return Ct(i)?e=>Jn(i,e):i};function Cu(t){t.target.composing=!0}function xr(t){const i=t.target;i.composing&&(i.composing=!1,i.dispatchEvent(new Event("input")))}const ii=Symbol("_assign");function _r(t,i,e){return i&&(t=t.trim()),e&&(t=So(t)),t}const bo={created(t,{modifiers:{lazy:i,trim:e,number:n}},o){t[ii]=Qi(o);const s=n||o.props&&o.props.type==="number";pi(t,i?"change":"input",l=>{l.target.composing||t[ii](_r(t.value,e,s))}),(e||s)&&pi(t,"change",()=>{t.value=_r(t.value,e,s)}),i||(pi(t,"compositionstart",Cu),pi(t,"compositionend",xr),pi(t,"change",xr))},mounted(t,{value:i}){t.value=i??""},beforeUpdate(t,{value:i,oldValue:e,modifiers:{lazy:n,trim:o,number:s}},l){if(t[ii]=Qi(l),t.composing)return;const r=(s||t.type==="number")&&!/^0\d/.test(t.value)?So(t.value):t.value,a=i??"";if(r===a)return;const c=t.getRootNode();(c instanceof Document||c instanceof ShadowRoot)&&c.activeElement===t&&t.type!=="range"&&(n&&i===e||o&&t.value.trim()===a)||(t.value=a)}},Kn={deep:!0,created(t,i,e){t[ii]=Qi(e),pi(t,"change",()=>{const n=t._modelValue,o=Mn(t),s=t.checked,l=t[ii];if(Ct(n)){const r=ys(n,o),a=r!==-1;if(s&&!a)l(n.concat(o));else if(!s&&a){const c=[...n];c.splice(r,1),l(c)}}else if(en(n)){const r=new Set(n);s?r.add(o):r.delete(o),l(r)}else l(Zl(t,s))})},mounted:Sr,beforeUpdate(t,i,e){t[ii]=Qi(e),Sr(t,i,e)}};function Sr(t,{value:i,oldValue:e},n){t._modelValue=i;let o;if(Ct(i))o=ys(i,n.props.value)>-1;else if(en(i))o=i.has(n.props.value);else{if(i===e)return;o=nn(i,Zl(t,!0))}t.checked!==o&&(t.checked=o)}const $u={deep:!0,created(t,{value:i,modifiers:{number:e}},n){t._modelValue=i,pi(t,"change",()=>{const o=Array.prototype.filter.call(t.options,s=>s.selected).map(s=>e?So(Mn(s)):Mn(s));t[ii](t.multiple?en(t._modelValue)?new Set(o):o:o[0]),t._assigning=!0,pl(()=>{t._assigning=!1})}),t[ii]=Qi(n)},mounted(t,{value:i}){Cr(t,i)},beforeUpdate(t,{value:i},e){t._modelValue=i,t[ii]=Qi(e)},updated(t,{value:i}){t._assigning||Cr(t,i)}};function Cr(t,i){const e=t.multiple,n=Ct(i);if(!(e&&!n&&!en(i))){for(let o=0,s=t.options.length;o<s;o++){const l=t.options[o],r=Mn(l);if(e)if(n){const a=typeof r;a==="string"||a==="number"?l.selected=i.some(c=>String(c)===String(r)):l.selected=ys(i,r)>-1}else l.selected=i.has(r);else if(nn(Mn(l),i)){t.selectedIndex!==o&&(t.selectedIndex=o);return}}!e&&t.selectedIndex!==-1&&(t.selectedIndex=-1)}}function Mn(t){return"_value"in t?t._value:t.value}function Zl(t,i){const e=i?"_trueValue":"_falseValue";return e in t?t[e]:i}const Iu=["ctrl","shift","alt","meta"],Au={stop:t=>t.stopPropagation(),prevent:t=>t.preventDefault(),self:t=>t.target!==t.currentTarget,ctrl:t=>!t.ctrlKey,shift:t=>!t.shiftKey,alt:t=>!t.altKey,meta:t=>!t.metaKey,left:t=>"button"in t&&t.button!==0,middle:t=>"button"in t&&t.button!==1,right:t=>"button"in t&&t.button!==2,exact:(t,i)=>Iu.some(e=>t[`${e}Key`]&&!i.includes(e))},Me=(t,i)=>{if(!t)return t;const e=t._withMods||(t._withMods={}),n=i.join(".");return e[n]||(e[n]=((o,...s)=>{for(let l=0;l<i.length;l++){const r=Au[i[l]];if(r&&r(o,i))return}return t(o,...s)}))},Bu={esc:"escape",space:" ",up:"arrow-up",left:"arrow-left",right:"arrow-right",down:"arrow-down",delete:"backspace"},Tu=(t,i)=>{const e=t._withKeys||(t._withKeys={}),n=i.join(".");return e[n]||(e[n]=(o=>{if(!("key"in o))return;const s=bi(o.key);if(i.some(l=>l===s||Bu[l]===s))return t(o)}))},Eu=ue({patchProp:xu},ru);let $r;function Mu(){return $r||($r=Nd(Eu))}const Yl=((...t)=>{const i=Mu().createApp(...t),{mount:e}=i;return i.mount=n=>{const o=Lu(n);if(!o)return;const s=i._component;!Bt(s)&&!s.render&&!s.template&&(s.template=o.innerHTML),o.nodeType===1&&(o.textContent="");const l=e(o,!1,Du(o));return o instanceof Element&&(o.removeAttribute("v-cloak"),o.setAttribute("data-v-app","")),l},i});function Du(t){if(t instanceof SVGElement)return"svg";if(typeof MathMLElement=="function"&&t instanceof MathMLElement)return"mathml"}function Lu(t){return te(t)?document.querySelector(t):t}const Pu="slidev-config.json",tn={enableWebServeJump:!1,webServeUrl:"http://127.0.0.1:6806",normalizeHeadingSizes:!1},hi=Io({...tn});function Ru(t){if(!t||typeof t!="object")return{...tn};const i=t;return{enableWebServeJump:!!i.enableWebServeJump,webServeUrl:typeof i.webServeUrl=="string"&&i.webServeUrl.trim()?i.webServeUrl.trim():tn.webServeUrl,normalizeHeadingSizes:!!i.normalizeHeadingSizes}}function Ei(t){if(!t||typeof t!="object")return{...hi};const i=t;return i.enableWebServeJump!==void 0&&(hi.enableWebServeJump=!!i.enableWebServeJump),i.webServeUrl!==void 0&&(hi.webServeUrl=String(i.webServeUrl)),i.normalizeHeadingSizes!==void 0&&(hi.normalizeHeadingSizes=!!i.normalizeHeadingSizes),{...hi}}function Do(){return{...hi}}function Jl(t,i,e){const n=(t||tn.webServeUrl).trim(),o=n.startsWith("http://")||n.startsWith("https://")?n:`http://${n}`,s=(e==null?void 0:e.r)||Math.random().toString(36).slice(2,9).padEnd(7,"0");try{const l=new URL(o);let r=l.pathname.replace(/\/+$/,"");return r.endsWith("/stage/build/desktop")||(r=r?`${r}/stage/build/desktop`:"/stage/build/desktop"),l.pathname=`${r}/`,l.searchParams.set("id",i),e!=null&&e.focus&&l.searchParams.set("focus","1"),l.searchParams.set("r",s),l.toString()}catch{const l=e!=null&&e.focus?"&focus=1":"";return`${o.replace(/\/+$/,"")}/stage/build/desktop/?id=${i}${l}&r=${s}`}}const Si={theme:"default",aspectRatio:"16/9",highlighter:"shiki",defaultTransition:"slide-left",colorSchema:"auto",spacing:"normal",normalizeHeadingSizes:!1};function Ou(t){var e,n,o,s,l,r;const i=Do();return t?{theme:((e=t[xn])==null?void 0:e.trim())||Si.theme,aspectRatio:((n=t[_n])==null?void 0:n.trim())||Si.aspectRatio,highlighter:((o=t[Fr])==null?void 0:o.trim())||Si.highlighter,defaultTransition:((s=t[Sn])==null?void 0:s.trim())||Si.defaultTransition,colorSchema:((l=t[Hr])==null?void 0:l.trim())||Si.colorSchema,spacing:((r=t[ts])==null?void 0:r.trim())||Si.spacing,normalizeHeadingSizes:i.normalizeHeadingSizes}:{...Si,normalizeHeadingSizes:i.normalizeHeadingSizes}}function yo(t){var e,n,o,s,l;const i=(e=t.ial)==null?void 0:e[Bi];return!!(i&&(i==="true"||i==="page"||i==="cover"||i==="end")||t.type==="tb"||t.type==="thematic-break"||t.type==="NodeThematicBreak"||((n=t.markdown)==null?void 0:n.trim())==="---"||((o=t.markdown)==null?void 0:o.trim())==="***"||t.type==="b"&&(((s=t.markdown)==null?void 0:s.trim())==="---"||((l=t.content)==null?void 0:l.trim())==="---"))}function Ir(t){const i={};let e="";if(!t)return{frontmatter:i,notes:e};t[mt]&&(i.layout=t[mt].trim()),t[Qt]&&(i.transition=t[Qt].trim()),t[Ut]&&(i.background=t[Ut].trim()),t[Ee]&&(i.image=t[Ee].trim()),t[Vi]&&(i.class=t[Vi].trim()),t[fn]&&(i.spacing=t[fn].trim()),t[re]&&(i.layoutRatio=t[re].trim()),t[Wi]&&(e=t[Wi].trim());for(const[n,o]of Object.entries(t))if(n.startsWith("custom-slidev-")&&![mt,re,Qt,Ut,Ee,Vi,fn,Wi,Bi].includes(n)){const s=n.replace(/^custom-slidev-/,"");try{i[s]=JSON.parse(o)}catch{i[s]=o}}return{frontmatter:i,notes:e}}function zu(t){const i={};if(!t)return i;const e=t[ie]??t["slidev-note"];e!=null&&e!==""&&e!=="false"&&e!=="0"&&(i.isNote=!0);const n=t[Kt]??t["slidev-role"],o=t[Ut]??t["slidev-background"];(n===jr||o==="true"||o==="1")&&(i.isBackground=!0);const s=t[mt]??t["slidev-layout"];s===ro||s===lo?i.imageLayout=s:(n===ro||n===lo)&&(i.imageLayout=n);const l=t[jt]??t["custom-slidev-clicks"]??t["slidev-click"]??t["slidev-clicks"];if(l!=null&&(i.clicks=l.trim()),t[Ve])try{const r=JSON.parse(t[Ve]);typeof r=="object"&&r!==null?i.motion={preset:r.preset||r.type||"fade-in",...r}:i.motion={preset:String(r).trim()}}catch{i.motion={preset:t[Ve].trim()}}return t[Ri]&&(i.shikiLines=t[Ri].trim()),t[Cn]&&(i.maxHeight=t[Cn].trim()),t[At]&&(i.slot=t[At].trim()),t.style&&t.style.trim()&&(i.style=t.style.trim()),i}function vi(t,i){const e=(t||i||"").trim();if(!e)return null;const n=e.match(/!\[[\s\S]*?\]\(\s*([^\s)]+)(?:\s+(?:=["']?[^"'\s)]*["']?|["'][^"']*["']))*?\s*\)/);if(n)return n[1].trim();const o=e.match(/<img\b[^>]*?\bsrc=["']([^"']+)["']/i);if(o)return o[1].trim();const s=e.replace(/\{:[^}]*\}/g,"").trim();return/^(?:assets\/|https?:\/\/|\/|\.\.?\/)[^\s]+\.(?:png|jpe?g|gif|webp|svg|avif)(?:\?[^\s]*)?$/i.test(s)?s:null}function bn(t){if(!t)return"";const i=t.split(/\r?\n/);if(i.length===0)return"";const e=i[0],n=e.match(/^(\s*)(?:[-*+]|\d+\.)\s+(.*)$/);if(!n)return t;const o=n[1].length,s=n[2].trim(),l=e.length-n[2].length;if(i.length===1)return s;const r=[s];for(let a=1;a<i.length;a++){const c=i[a];if(!c.trim()){r.push("");continue}const u=c.match(/^(\s*)/),m=u?u[1].length:0;m>=l?r.push(c.slice(l)):m>o?r.push(c.slice(m)):r.push(c)}return r.join(`
`)}function Oi(t){if(!t)return!1;const i=(t.type||"").toLowerCase();if(i==="i"||i==="nodelistitem"||i==="l"||i==="nodelist")return!0;const e=(t.markdown||t.rawMarkdown||t.content||"").trim();return!!/^(?:[-*+]|\d+\.)\s+/.test(e)}function Ko(t,i=2){if(!t||typeof t!="string")return`repeat(${i}, 1fr)`;const e=t.trim();if(!e)return`repeat(${i}, 1fr)`;if(e.includes(":")){const o=e.split(":").map(s=>parseFloat(s.trim())).filter(s=>!isNaN(s)&&s>0);if(o.length>=2)return o.map(s=>`${s}fr`).join(" ")}const n=e.split(/\s+/).filter(Boolean);return n.length>=2?n.join(" "):`repeat(${i}, 1fr)`}function yn(t){if(!t)return[];if(le(t)&&li(t)&&!yi(t)){const n=zn(t),o=[];for(const s of n)o.push(...yn(s));return o}const i=(t.type||"").toLowerCase();if(i==="l"||i==="nodelist"||i==="list"){if(t.children&&t.children.length>0){const l=t.children.filter(Oi);if(l.length>0)return l}const o=(t.markdown||t.content||"").trim().split(/\r?\n/),s=[];for(let l=0;l<o.length;l++)/^(?:[-*+]|\d+\.)\s+/.test(o[l])&&s.push(l);if(s.length>=2){const l=[];for(let r=0;r<s.length;r++){const a=s[r],c=r+1<s.length?s[r+1]:o.length,u=o.slice(a,c).join(`
`);l.push({id:`${t.id}-item-${r+1}`,type:"i",markdown:u,content:u,ial:{...t.ial||{}}})}return l}}return Oi(t)?[t]:[]}function Xl(t){var o;if(!t||!le(t)||!li(t)||yi(t))return null;const i=zn(t);if(i.length===0)return null;if(i.length===1&&le(i[0])&&li(i[0])){const s=Xl(i[0]);return s?{items:s.items,nestedSuperBlocks:[i[0],...s.nestedSuperBlocks]}:null}const e=[];for(const s of i)if(le(s)){e.push(s);const l=((o=s.children)==null?void 0:o.filter(le))||[];e.push(...l)}const n=i.map(yn);if(n.length>=2&&n.every(s=>s.length>0)){const s=n.flat();if(s.length>=2&&s.length<=6)return{items:s,nestedSuperBlocks:e}}if(i.length===2){const s=yn(i[0]),l=yn(i[1]);if(s.length+l.length>=2&&s.length+l.length<=6&&(s.length>0||l.length>0))return{items:[...s,...l],nestedSuperBlocks:e}}return null}function Nu(t){if(!t||!le(t)||!li(t)||yi(t))return null;const i=Xl(t);if(!i)return null;const{items:e,nestedSuperBlocks:n}=i;if(e.length<2||e.length>6)return null;const o=Ps(t)||void 0,s=e.length;return{superBlockNode:t,nestedSuperBlocks:n,count:s,layout:"cols-header",items:e,slots:e.map((l,r)=>`col-${r+1}`),ratio:o}}function Fu(t){if(!t||!le(t)||!li(t)||yi(t))return null;const i=zn(t);if(i.length===0)return null;const e=[];for(const n of i){const o=yn(n);if(o.length===0)return null;e.push(...o)}return e}function Hu(t){if(!t||!le(t)||!li(t)||yi(t))return null;const i=Fu(t);return!i||i.length===0||i.length>=2&&i.length<=6?null:{superBlockNode:t,items:i}}function ju(t,i,e){var u,m,g,d,y;const n=[],o=[],s=(e==null?void 0:e.tracked)||[],l=[];let r={pageTargetId:t,blocks:[]};l.push(r);for(let f=0;f<i.length;f++){const v=i[f];if(yo(v)){if(l.length===1&&r.blocks.length===0){r.pageTargetId=v.id,r.blocks.push(v);continue}r={pageTargetId:v.id,blocks:[v]},l.push(r)}else r.blocks.push(v)}function a(f){const v=[];for(const k of f)le(k)&&v.push(k),k.children&&k.children.length>0&&v.push(...a(k.children));return v}function c(f,v,k){const x={blockId:f,attrs:v,previousAttrs:k};n.push(x),e!=null&&e.onTagChange&&e.onTagChange(x)}for(const f of l){const v=f.pageTargetId,k=i.find(I=>I.id===v),x=s.find(I=>I.pageTargetId===v);if(f.blocks.some(I=>{var w,z;return!!(yi(I)||fs(I)&&(((w=I.ial)==null?void 0:w[mt])==="image-left"||((z=I.ial)==null?void 0:z[mt])==="image-right"))})){if(x){const I=x.headerId;if(I){c(I,{[At]:""});const w=i.find(z=>z.id===I);w!=null&&w.ial&&(w.ial[At]="")}for(const w of x.itemIds){c(w,{[At]:""});const z=i.find(O=>O.id===w);z!=null&&z.ial&&(z.ial[At]="")}}continue}let B=null,A=-1;for(let I=0;I<f.blocks.length;I++){const w=f.blocks[I],z=le(w)?[w,...a(w.children||[])]:w.children?a(w.children):[];for(const O of z){const H=Nu(O);if(H){B=H,A=I;break}}if(B)break}if(B){const{superBlockNode:I,layout:w,items:z,slots:O}=B,et=f.blocks.slice(0,A).find(N=>Wu(N)),_=et==null?void 0:et.id,P=((u=k==null?void 0:k.ial)==null?void 0:u[mt])||"";if(P!==w&&(c(v,{[mt]:w},{[mt]:P}),k&&(k.ial||(k.ial={}),k.ial[mt]=w)),et){const N=((m=et.ial)==null?void 0:m[At])||"";N!=="header"&&(c(et.id,{[At]:"header"},{[At]:N}),et.ial||(et.ial={}),et.ial[At]="header")}if(x!=null&&x.headerId&&x.headerId!==_){c(x.headerId,{[At]:""});const N=i.find(J=>J.id===x.headerId);N&&(N.ial||(N.ial={}),N.ial[At]="")}const b=[];for(let N=0;N<z.length;N++){const J=z[N],U=O[N];b.push(J.id);const G=((g=J.ial)==null?void 0:g[At])||"";if(G!==U&&(c(J.id,{[At]:U},{[At]:G}),J.ial||(J.ial={}),J.ial[At]=U),J.children&&J.children.length>0)for(const V of J.children)V.ial||(V.ial={}),V.ial[At]!==U&&(V.ial[At]=U)}if(x!=null&&x.itemIds){for(const N of x.itemIds)if(!b.includes(N)){c(N,{[At]:""});const J=i.find(U=>U.id===N);J&&(J.ial||(J.ial={}),J.ial[At]="")}}o.push({superBlockId:I.id,nestedSuperBlockIds:(d=B.nestedSuperBlocks)==null?void 0:d.map(N=>N.id),pageTargetId:v,headerId:_,itemIds:b,layout:w})}else{let I=!1;const w=[];for(const H of f.blocks){const et=le(H)?[H,...a(H.children||[])]:H.children?a(H.children):[];for(const _ of et){const P=Hu(_);if(P){I=!0;for(const b of P.items)w.push(b.id)}}}const z=((y=k==null?void 0:k.ial)==null?void 0:y[mt])||"",O=ao(z);if(x||I&&O){c(v,{[mt]:""},{[mt]:z}),k&&(k.ial||(k.ial={}),k.ial[mt]="");const H=x==null?void 0:x.headerId;if(H){c(H,{[At]:""});const _=i.find(P=>P.id===H);_&&(_.ial||(_.ial={}),_.ial[At]="")}const et=new Set([...(x==null?void 0:x.itemIds)||[],...w]);for(const _ of et){c(_,{[At]:""});const P=i.find(b=>b.id===_);P&&(P.ial||(P.ial={}),P.ial[At]="")}}}}return{changes:n,newTracked:o}}function le(t){if(!t)return!1;const i=(t.type||"").toLowerCase();return i==="s"||i==="sb"||i==="nodesuperblock"}function li(t){if(!le(t))return!1;const i=(t.subType||"").toLowerCase();if(i==="col"||i==="h"||i==="horizontal")return!0;if(i==="row"||i==="v"||i==="vertical")return!1;if(t.ial){const n=(t.ial["data-sb-layout"]||t.ial.layout||"").toLowerCase();if(n==="col"||n==="h")return!0;if(n==="row"||n==="v")return!1}if(t.children&&t.children.length>0){for(const n of t.children)if(n.type==="NodeSuperBlockLayoutMarker"||n.type==="layout-marker"){const o=(n.content||n.markdown||"").trim().toLowerCase();if(o==="col"||o==="h")return!0;if(o==="row"||o==="v")return!1}}const e=(t.markdown||t.content||"").trim();return/^\{\{\{col\b/i.test(e)?!0:!/^\{\{\{row\b/i.test(e)}function fs(t){return!t||Oi(t)||le(t)||!vi(t.markdown,t.content)?!1:(t.markdown||t.content||"").replace(/!\[.*?\]\([^)]+\)/g,"").replace(/<img\b[^>]*>/gi,"").replace(/\{:[^}]*\}/g,"").trim().length<=25}function Ps(t){var g;if(!t||!le(t)||!li(t))return null;const i=zn(t);if(!i||i.length<2)return null;const e=[];let n=!1;for(const d of i){const y=(((g=d.ial)==null?void 0:g.style)||d.style||"").trim();let f=null;if(y){const v=y.match(/calc\(\s*([\d.]+)%/i);if(v)f=parseFloat(v[1]);else{const k=y.match(/(?:^|;|\s)width:\s*([\d.]+)%/i);k&&(f=parseFloat(k[1]))}}f!==null&&!isNaN(f)&&f>0?(e.push(f),n=!0):e.push(null)}if(!n)return null;const o=i.length,s=e.reduce((d,y)=>d+(y||0),0),l=e.filter(d=>d===null).length,r=Math.max(0,100-s),a=l>0?r/l:100/o,c=e.map(d=>d!==null?d:a),u=c.reduce((d,y)=>d+y,0);if(u<=0)return null;const m=c.map(d=>d/u*100);if(m.length===2){const[d]=m;if(d>=48&&d<=52)return"1:1";if(d>=31&&d<=35)return"1:2";if(d>=65&&d<=69)return"2:1";if(d>=28&&d<=32)return"3:7";if(d>=68&&d<=72)return"7:3";if(d>=38&&d<=42)return"4:6";if(d>=58&&d<=62)return"6:4";if(d>=23&&d<=27)return"1:3";if(d>=73&&d<=77)return"3:1";const y=Math.round(d),f=100-y;return`${y}:${f}`}if(m.length===3){const[d,y,f]=m;if(d>=31&&d<=35&&y>=31&&y<=35&&f>=31&&f<=35)return"1:1:1";if(d>=23&&d<=27&&y>=48&&y<=52&&f>=23&&f<=27)return"1:2:1";if(d>=48&&d<=52&&y>=23&&y<=27&&f>=23&&f<=27)return"2:1:1";if(d>=23&&d<=27&&y>=23&&y<=27&&f>=48&&f<=52)return"1:1:2";if(d>=18&&d<=22&&y>=58&&y<=62&&f>=18&&f<=22)return"1:3:1";const v=Math.round(d),k=Math.round(y),x=100-v-k;return`${v}:${k}:${x}`}return m.map(d=>Math.round(d)).join(":")}function yi(t){if(!t||!le(t)||!li(t))return null;const i=(t.children||[]).filter(s=>{const l=s.type||"";if(l==="NodeSuperBlockOpenMarker"||l==="NodeSuperBlockLayoutMarker"||l==="NodeSuperBlockCloseMarker"||l==="open-marker"||l==="layout-marker"||l==="close-marker")return!1;const r=(s.markdown||s.content||"").trim();return!(/^\{\{\{(?:col|row)?\s*$/i.test(r)||r==="}}}")});if(i.length<2)return null;const e=fs(i[0]),n=fs(i[i.length-1]),o=Ps(t)||void 0;if(e&&!n){const s=vi(i[0].markdown,i[0].content);if(s)return{imageNode:i[0],imageUrl:s,layout:ro,contentNodes:i.slice(1),ratio:o}}if(!e&&n){const s=vi(i[i.length-1].markdown,i[i.length-1].content);if(s)return{imageNode:i[i.length-1],imageUrl:s,layout:lo,contentNodes:i.slice(0,i.length-1),ratio:o}}return null}function Uu(t,i){const e=[];function n(o){for(const s of o){const l=yi(s);if(l){const{imageNode:r,layout:a,ratio:c}=l;r.ial||(r.ial={});const u=r.ial[mt];if(u!==a){const g={blockId:r.id,layout:a,previousLayout:u,ratio:c};r.ial[mt]=a,e.push(g),i&&i(g)}}s.children&&s.children.length>0&&n(s.children)}}return n(t),e}function zn(t){return(t.children||[]).filter(i=>{const e=i.type||"";if(e==="NodeSuperBlockOpenMarker"||e==="NodeSuperBlockLayoutMarker"||e==="NodeSuperBlockCloseMarker"||e==="open-marker"||e==="layout-marker"||e==="close-marker")return!1;const n=(i.markdown||i.content||"").trim();return!(/^\{\{\{(?:col|row)?\s*$/i.test(n)||n==="}}}")})}function Wu(t){if(!t)return!1;const i=(t.type||"").toLowerCase();if(i==="h"||i==="nodeheading"||/^h[1-6]$/i.test(t.subType||""))return!0;const e=(t.markdown||t.content||"").trim();return!!/^#{1,6}\s+/.test(e)}function Ci(t,i,e){let n="",o=0;const s=/<div\b([^>]*)>/gi;for(;o<t.length;){s.lastIndex=o;let l,r=!1,a=-1,c=0;for(;(l=s.exec(t))!==null;){const k=l[1].match(/\bclass=["']([^"']*)["']/i);if(k){const x=k[1];if(typeof i=="string"?x.split(/\s+/).includes(i):i.test(x)){r=!0,a=l.index,c=l[0].length;break}}}if(!r){n+=t.slice(o);break}n+=t.slice(o,a);const u=a+c;let m=1,g=-1,d=-1;const y=/<\/?div\b[^>]*>/gi;y.lastIndex=u;let f;for(;(f=y.exec(t))!==null;)if(f[0].startsWith("</")){if(m--,m===0){g=f.index,d=f.index+f[0].length;break}}else m++;if(g!==-1&&d!==-1){const v=t.slice(u,g);n+=e(v),o=d}else n+=t.slice(a,u),o=u}return n}function Vu(t){const i=[];let e="",n=0;const o=/<div\b([^>]*)>/gi;for(;n<t.length;){o.lastIndex=n;let s,l=!1,r=-1,a=0;for(;(s=o.exec(t))!==null;){const f=s[1];if(/(?:\s@[a-zA-Z0-9_-]+=\s*["']|\s:[a-zA-Z0-9_-]+=\s*["']|\sv-[a-zA-Z0-9_.-]+|\shover:[a-zA-Z0-9_.-]+=\s*["']|\sgrid=["']~|\bclass=["'][^"']*\b(?:abs-br|slidev-icon-btn|grid\s+|grid$|grid-cols-|relative\b)\b[^"']*["']|\bstyle=["'][^"']*\bgrid-[^"']*["'])/i.test(f)){l=!0,r=s.index,a=s[0].length;break}}if(!l){e+=t.slice(n);break}e+=t.slice(n,r);const c=r+a;let u=1,m=-1,g=-1;const d=/<\/?div\b[^>]*>/gi;d.lastIndex=c;let y;for(;(y=d.exec(t))!==null;)if(y[0].startsWith("</")){if(u--,u===0){m=y.index,g=y.index+y[0].length;break}}else u++;if(m!==-1&&g!==-1){const f=t.slice(r,g),v=`__VUE_DIV_TOKEN_${i.length}__`;i.push(f),e+=v,n=g}else e+=t.slice(r,c),n=c}return{text:e,tokens:i}}function qu(t){const i=[];let e=t.replace(/(?:^[ \t]*(`{3,}|~{3,})[^\n\r]*\r?\n[\s\S]*?\r?\n[ \t]*\1(?=[ \t]*(?:\r?\n|$)))/gm,r=>{const a=`__CODE_TOKEN_${i.length}__`;return i.push(r),a});e=e.replace(/(`+)(?:[^\n\r`]|(?!\1)`)+?\1/g,r=>{const a=`__CODE_TOKEN_${i.length}__`;return i.push(r),a});const n=[];e=e.replace(/<script\b[^>]*>[\s\S]*?<\/script>/gi,r=>{const a=`__SCRIPT_TOKEN_${n.length}__`;return n.push(r),a});const{text:o,tokens:s}=Vu(e);e=o;const l=[];e=e.replace(/<(?:[A-Z][a-zA-Z0-9_-]*|[a-z0-9_-]+:[a-z0-9_-]+|v-[a-z0-9_-]+|arrow\b|div\s+h-\d+)\b[^>]*\/>/gi,r=>{const a=`__VUE_COMP_TOKEN_${l.length}__`;return l.push(r),a}),e=e.replace(/<(v-[a-z0-9_-]+|button)\b([^>]*)>([\s\S]*?)<\/\1>/gi,r=>{const a=`__VUE_COMP_TOKEN_${l.length}__`;return l.push(r),a}),e=e.replace(/<img\b[^>]*?\bv-[a-z0-9_.-]+[^>]*\/?>/gi,r=>{const a=`__VUE_COMP_TOKEN_${l.length}__`;return l.push(r),a}),e=e.replace(/<(p|span)\b([^>]*?\bv-[a-z0-9_.-]+[^>]*)>([\s\S]*?)<\/\1>/gi,r=>{const a=`__VUE_COMP_TOKEN_${l.length}__`;return l.push(r),a}),e=e.replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi,""),e=e.replace(/<div class="terminal-bar">[\s\S]*?<\/div>/gi,""),e=e.replace(/<div class="cursor-line">[\s\S]*?<\/div>/gi,""),e=e.replace(/<span class="cursor">[\s\S]*?<\/span>/gi,""),e=e.replace(/<div class="stamp">\s*([\s\S]*?)\s*<\/div>/gi,`

*[$1]*

`),e=e.replace(/<div class="arrow">\s*([→\->]+)\s*<\/div>/gi,`

$1

`),e=e.replace(/<i>\s*[→\->]+\s*<\/i>/gi,""),e=e.replace(/<div class="prompt">\s*([\s\S]*?)\s*<\/div>/gi,(r,a)=>`
\`\`\`bash
${a.trim()}
\`\`\`
`),e=e.replace(/<p>\s*<i>\$<\/i>\s*([\s\S]*?)<\/p>/gi,(r,a)=>`
\`\`\`bash
$ ${a.trim()}
\`\`\`
`),e=e.replace(/<div class="statusline">\s*([\s\S]*?)\s*<\/div>/gi,(r,a)=>`
> ${Array.from(a.matchAll(/<span>([\s\S]*?)<\/span>/gi)).map(u=>`\`${u[1].trim()}\``).join(" | ")}
`),e=e.replace(/<div class="log-panel">\s*<pre>([\s\S]*?)<\/pre>\s*<\/div>/gi,(r,a)=>`
\`\`\`log
${a.replace(/<span[^>]*>([\s\S]*?)<\/span>/gi,"$1").trim()}
\`\`\`
`),e=Ci(e,"diff-grid",r=>{const a=Array.from(r.matchAll(/<div class="diff\s+([^"]*)">\s*<span>(.*?)<\/span>\s*<pre>([\s\S]*?)<\/pre>\s*<\/div>/gi));return a.length>0?`
`+a.map(c=>{const u=c[2].trim().toUpperCase(),m=c[3].trim();return`**${u}:**
\`\`\`yaml
${m}
\`\`\``}).join(`

`)+`
`:r}),e=Ci(e,"before-after",r=>{const a=r.match(/<div class="before">[\s\S]*?<small>(.*?)<\/small>[\s\S]*?<h2>(.*?)<\/h2>[\s\S]*?<p>(.*?)<\/p>\s*<\/div>/i),c=r.match(/<div class="after">[\s\S]*?<small>(.*?)<\/small>[\s\S]*?<h2>(.*?)<\/h2>[\s\S]*?<p>(.*?)<\/p>\s*<\/div>/i);let u=`
`;return a&&(u+=`### ${a[1]}
## ${a[2]}
${a[3]}

`),c&&(u+=`### ${c[1]}
## ${c[2]}
${c[3]}
`),u.trim()?u:r}),e=e.replace(/<ul\b[^>]*>([\s\S]*?)<\/ul>/gi,(r,a)=>{const c=Array.from(a.matchAll(/<li>\s*(?:<em>)?(\[[x ]\])(?:<\/em>)?\s*([\s\S]*?)<\/li>/gi));return c.length>0?`
`+c.map(u=>`- ${u[1]} ${u[2].trim()}`).join(`
`)+`
`:a}),e=Ci(e,"timeline",r=>{const a=Array.from(r.matchAll(/<div(?:\s+class="([^"]*)")?>\s*<time>([\s\S]*?)<\/time>\s*<b>([\s\S]*?)<\/b>\s*<span>([\s\S]*?)<\/span>\s*<\/div>/gi));return a.length>0?`

`+a.map(c=>{const u=c[1]||"";let m="-";return u.includes("warn")?m="- ⚠️":u.includes("bad")?m="- ❌":u.includes("ok")&&(m="- ✅"),`${m} **${c[2].trim()}** **${c[3].trim()}** — ${c[4].trim()}`}).join(`
`)+`

`:r}),e=Ci(e,"pipeline",r=>{const a=Array.from(r.matchAll(/<div(?:\s+class="([^"]*)")?>\s*<small>([\s\S]*?)<\/small>\s*<b>([\s\S]*?)<\/b>\s*<span>([\s\S]*?)<\/span>\s*<\/div>/gi));return a.length>0?`

`+a.map((c,u)=>{const g=(c[1]||"").includes("hot")?"⚠️ ":"";return`${u+1}. ${g}**${c[3].trim()}** (*${c[4].trim()}*)`}).join(`
`)+`

`:r}),e=Ci(e,"check-grid",r=>{const a=Array.from(r.matchAll(/<div>\s*<span class="([^"]*)"><\/span>\s*<b>([\s\S]*?)<\/b>\s*<p>([\s\S]*?)<\/p>\s*<\/div>/gi));return a.length>0?`

`+a.map(c=>`- ${(c[1]||"").includes("warn")?"⚠️":"✅"} **${c[2].trim()}**: ${c[3].trim()}`).join(`
`)+`

`:r}),e=Ci(e,"manifesto",r=>{const a=Array.from(r.matchAll(/<div>\s*<span>([\s\S]*?)<\/span>\s*<h2>([\s\S]*?)<\/h2>\s*<p>([\s\S]*?)<\/p>\s*<\/div>/gi));return a.length>0?`

`+a.map(c=>`## ${c[1].trim()} ${c[2].trim()}

${c[3].trim()}`).join(`

`)+`

`:r}),e=Ci(e,"split-note",r=>{const a=Array.from(r.matchAll(/<div>\s*<b>([\s\S]*?)<\/b>\s*<p>([\s\S]*?)<\/p>\s*<\/div>/gi));return a.length>0?`

`+a.map(c=>`> **${c[1].trim()}**: ${c[2].trim()}`).join(`
>
`)+`

`:r}),e=e.replace(/<div class="mechanism">\s*<b>([\s\S]*?)<\/b>\s*<p>([\s\S]*?)<\/p>\s*<\/div>/gi,(r,a,c)=>`

> **${a.trim()}**: ${c.trim()}

`),e=e.replace(/<pre>([\s\S]*?)<\/pre>/gi,(r,a)=>`
\`\`\`text
${a.replace(/<span[^>]*>([\s\S]*?)<\/span>/gi,"$1").trim()}
\`\`\`
`),e=e.replace(/<div class="page-head">\s*<span>([\s\S]*?)<\/span>\s*<b>([\s\S]*?)<\/b>\s*<\/div>/gi,`
### $1 ($2)
`),e=e.replace(/<h1\b[^>]*>([\s\S]*?)<\/h1>/gi,`
# $1
`),e=e.replace(/<h2\b[^>]*>([\s\S]*?)<\/h2>/gi,`
## $1
`),e=e.replace(/<h3\b[^>]*>([\s\S]*?)<\/h3>/gi,`
### $1
`),e=e.replace(/<h4\b[^>]*>([\s\S]*?)<\/h4>/gi,`
#### $1
`),e=e.replace(/<p\s+class="ok">\s*●\s*([\s\S]*?)<\/p>/gi,`
✅ **$1**
`),e=e.replace(/<p\s+class="caption">\s*([\s\S]*?)<\/p>/gi,`
> *$1*
`),e=e.replace(/<p\s+class="lead">\s*([\s\S]*?)<\/p>/gi,`
*$1*
`),e=e.replace(/<p\b([^>]*)>([\s\S]*?)<\/p>/gi,(r,a,c)=>/@|v-|:|class=/i.test(a)?r:`
${c.trim()}

`),e=e.replace(/<br\s*\/?>/gi,`
`),e=e.replace(/<hr\s*\/?>/gi,`
---
`),e=e.replace(/<b\b[^>]*>([\s\S]*?)<\/b>/gi,"**$1**"),e=e.replace(/<strong\b[^>]*>([\s\S]*?)<\/strong>/gi,"**$1**"),e=e.replace(/<i\b[^>]*>([\s\S]*?)<\/i>/gi,"*$1*"),e=e.replace(/<code\b[^>]*>([\s\S]*?)<\/code>/gi,(r,a)=>{if(a.startsWith("`")&&a.endsWith("`"))return a;if(a.includes("`")){const c=(a.match(/`+/g)||[]).reduce((m,g)=>Math.max(m,g.length),0),u="`".repeat(c+1);return`${u} ${a} ${u}`}return`\`${a}\``}),e=e.replace(/<small\b[^>]*>([\s\S]*?)<\/small>/gi,"*$1*"),e=e.replace(/\*{4}/g,"** **"),e=e.replace(/<li\b[^>]*>([\s\S]*?)<\/li>/gi,`- $1
`),e=e.replace(/<ul\b[^>]*>([\s\S]*?)<\/ul>/gi,`
$1
`),e=e.replace(/<ol\b[^>]*>([\s\S]*?)<\/ol>/gi,`
$1
`),e=e.replace(/<a\b([^>]*)href=["'](.*?)["']([^>]*)>([\s\S]*?)<\/a>/gi,(r,a,c,u,m)=>{const g=m.trim();return g.includes("<")||g.includes(`
`)?r:`[${g}](${c})`}),e=e.replace(/<blockquote\b[^>]*>([\s\S]*?)<\/blockquote>/gi,(r,a)=>`
`+a.trim().split(`
`).map(c=>`> ${c.trim()}`).join(`
`)+`
`),e=e.replace(/<span\b[^>]*data-type=["']block-ref["'][^>]*data-id=["']([0-9a-zA-Z-]+)["'][^>]*>([\s\S]*?)<\/span>/gi,(r,a,c)=>{const u=c.replace(/<[^>]+>/g,"").trim();return u?`((${a} '${u}'))`:`((${a}))`}),e=e.replace(/<span\b[^>]*data-type=["']a["'][^>]*data-href=["']([^"']+)["'][^>]*>([\s\S]*?)<\/span>/gi,(r,a,c)=>`[${c.replace(/<[^>]+>/g,"").trim()}](${a})`),e=e.replace(/<\/(?:div|section|header|footer|main|article|nav|aside)\b[^>]*>/gi,`
`),e=e.replace(/<(?:div|section|header|footer|main|article|nav|aside)\b[^>]*>/gi,""),e=e.replace(/<\/?span\b[^>]*>/gi,"");for(let r=0;r<l.length;r++)e=e.replace(`__VUE_COMP_TOKEN_${r}__`,l[r]);for(let r=0;r<s.length;r++)e=e.replace(`__VUE_DIV_TOKEN_${r}__`,s[r]);for(let r=0;r<n.length;r++)e=e.replace(`__SCRIPT_TOKEN_${r}__`,n[r]);for(let r=0;r<i.length;r++)e=e.replace(`__CODE_TOKEN_${r}__`,i[r]);return e=e.replace(/\n{3,}/g,`

`).trim(),e}function Ql(t){if(!t||typeof t!="string")return"";const i=[];let e=t.replace(/`([^`]+)`/g,n=>(i.push(n),`%%INLINE_CODE_${i.length-1}%%`));return e=e.replace(/(<\/[a-zA-Z0-9_-]+>)\s*\{:[^}]*\}/g,"$1"),e=e.replace(/(\[[^\]]+\]\([^)]+\))\s*\{:\s*style=["']([^"']*)["'][^}]*\}/g,'<span style="$2">$1</span>'),e=e.replace(/(\*\*[^*]+\*\*)\s*\{:\s*style=["']([^"']*)["'][^}]*\}/g,'<span style="$2">$1</span>'),e=e.replace(/(\*[^*]+\*)\s*\{:\s*style=["']([^"']*)["'][^}]*\}/g,'<span style="$2">$1</span>'),e=e.replace(/(~~[^~]+~~)\s*\{:\s*style=["']([^"']*)["'][^}]*\}/g,'<span style="$2">$1</span>'),e=e.replace(/([\p{L}\p{N}_\-]+)\s*\{:\s*style=["']([^"']*)["'][^}]*\}/gu,'<span style="$2">$1</span>'),e=e.replace(/\{:[^}]*\}/g,""),e=e.replace(/%%INLINE_CODE_(\d+)%%/g,(n,o)=>i[parseInt(o,10)]||""),e}function Ku(t){const i=Object.entries(t).filter(([n,o])=>o!=null&&o!=="");return i.length===0?"":`---
${i.map(([n,o])=>typeof o=="string"?o.includes(":")||o.includes(`
`)||o.includes("#")?`${n}: "${o.replace(/"/g,'\\"')}"`:`${n}: ${o}`:`${n}: ${JSON.stringify(o)}`).join(`
`)}
---`}function Gu(t,i){if(!i||!t.startsWith("```"))return t;const e=t.indexOf(`
`);if(e===-1)return t;const n=t.slice(0,e).trim(),o=t.slice(e);return n.includes("{")?t:`${n} {${i}}${o}`}function ta(t,i){if(i==null)return t;const e=i.trim();return e===""||e==="+1"?`<v-click>

${t}

</v-click>`:e==="hide"?`<v-click hide>

${t}

</v-click>`:`<v-click at="${e}">

${t}

</v-click>`}function Zu(t){if(!t||!t.preset)return null;const i=t.preset.toLowerCase().trim();if(!i||i==="none")return null;let e={opacity:0},n={opacity:1};switch(i){case"slide-up":e={y:40,opacity:0},n={y:0,opacity:1};break;case"slide-down":e={y:-40,opacity:0},n={y:0,opacity:1};break;case"slide-left":e={x:40,opacity:0},n={x:0,opacity:1};break;case"slide-right":e={x:-40,opacity:0},n={x:0,opacity:1};break;case"zoom-in":case"pop":e={scale:.8,opacity:0},n={scale:1,opacity:1};break;case"bounce":e={y:40,opacity:0},n={y:0,opacity:1,transition:{type:"spring",damping:10,stiffness:100}};break;case"fade-in":default:e={opacity:0},n={opacity:1};break}t.initial&&typeof t.initial=="object"&&(e={...e,...t.initial}),t.enter&&typeof t.enter=="object"&&(n={...n,...t.enter});const o={...n.transition||{}};return typeof t.duration=="number"&&t.duration>0&&(o.duration=t.duration),typeof t.delay=="number"&&t.delay>0&&(o.delay=t.delay),Object.keys(o).length>0&&(n.transition=o),{initial:e,enter:n}}function Gn(t,i,e,n){const o=i!=null&&i.trim()!=="",s=Zu(e),l=n==null?void 0:n.trim(),r=l!==void 0&&l!=="",a=r?` style="${l.replace(/"/g,"&quot;")}" class="slide-styled-block"`:"";if(!o&&!s)return r?`<div${a}>

${t}

</div>`:t;if(o&&!s){if(r){const y=i.trim();let f="v-click";return y==="hide"?f="v-click.hide":y!==""&&y!=="+1"&&(f=`v-click="${y}"`),`<div ${f}${a}>

${t}

</div>`}return ta(t,i)}const c=JSON.stringify(s.initial).replace(/"/g,"'"),u=JSON.stringify(s.enter).replace(/"/g,"'"),m=`v-motion :initial="${c}" :enter="${u}"`;if(!o)return`<div ${m}${a}>

${t}

</div>`;const g=i.trim();let d="v-click";return g==="hide"?d="v-click.hide":g!==""&&g!=="+1"&&(d=`v-click="${g}"`),`<div ${d} ${m}${a}>

${t}

</div>`}function ea(t){if(!t)return"";let i=t.trim();i=i.replace(/\{:[^}]*\}/g,"").trim(),i=i.replace(/^:::\s*[a-zA-Z0-9_-]*\s*\r?\n?/g,""),i=i.replace(/\r?\n?:::\s*$/g,"");let o=i.split(/\r?\n/).map(s=>s.trim().replace(/^>\s*/,"")).join(`
`).trim();return o=o.replace(/^\[!(?:NOTE|TIP|IMPORTANT|WARNING|CAUTION|[A-Za-z_-]+)\][^\r\n]*(?:\r?\n)?/i,"").trim(),o=o.replace(/^(?:💡|✏️|❗|⚠️|🚨|\s*)*(?:\*\*|__)?(?:演讲备注|演讲者提词|讲稿备注|演讲提词|备注|Notes?)(?:\*\*|__)?[:：]?\s*(?:\r?\n)?/i,"").trim(),o=o.replace(/^[-*+]\s+/,""),o=o.replace(/^\d+\.\s+/,""),o.trim()}function Yu(t){var n;if(t.subType&&/^h([1-6])$/i.test(t.subType))return parseInt(t.subType.slice(1),10);const e=(t.markdown||t.content||"").trim().match(/^(#{1,6})\s+/);return e?e[1].length:t.type==="h"?(n=t.ial)!=null&&n.subType&&/^h([1-6])$/i.test(t.ial.subType)?parseInt(t.ial.subType.slice(1),10):1:null}function ia(t,i=2){const e=Math.max(2,i);if(!t||t.length===0)return Array.from({length:e},()=>[]);if(t.length===1&&t[0].children&&t[0].children.length>=2){const c=t[0].children,u=Array.from({length:e},()=>[]),m=Math.min(e,c.length),g=Math.floor(c.length/m),d=c.length%m;let y=0;for(let f=0;f<m;f++){const v=g+(f<d?1:0);u[f]=c.slice(y,y+v),y+=v}return u}const n=c=>{const u=(c.slot||"").trim();if(!u)return null;if(u==="left")return 1;if(u==="center")return 2;if(u==="right")return e===2?2:e;const m=u.match(/^col-(\d+)$/i);if(m){const g=parseInt(m[1],10);if(g>=1&&g<=e)return g}return null},o=t.map(n);if(o.some(c=>c!==null)){if(o.some(d=>d!==null&&d>=2)){const d=Array.from({length:e},()=>[]);let y=1;for(const f of t){const v=n(f);v!==null&&(y=v),d[y-1].push(f)}return d}const u=t.filter(d=>n(d)===1),m=t.filter(d=>n(d)===null),g=e-1;if(m.length>=g){const d=Math.floor(m.length/g),y=m.length%g,f=[u];let v=0;for(let k=0;k<g;k++){const x=d+(k<y?1:0);f.push(m.slice(v,v+x)),v+=x}return f}else if(m.length>0){const d=[u];for(let y=0;y<g;y++)d.push(y<m.length?[m[y]]:[]);return d}else return[u,...Array.from({length:g},()=>[])]}const l=c=>{if(c.type==="h"||c.subType&&/^h[1-6]$/i.test(c.subType))return!0;const u=(c.rawMarkdown||c.content||"").trim();return/^#{1,6}\s+/.test(u)},r=t.map((c,u)=>l(c)?u:-1).filter(c=>c!==-1);if(r.length>=e){const c=Array.from({length:e},()=>[]);for(let u=0;u<e;u++){const m=r[u],g=u+1<e?r[u+1]:t.length;c[u]=t.slice(m,g)}return c}if(t.length>=e){const c=Array.from({length:e},()=>[]);let u=0;for(let m=0;m<e;m++){const g=e-m,d=t.length-u,y=Math.ceil(d/g);c[m]=t.slice(u,u+y),u+=y}return c}if(t.length>1&&t.length<e){const c=Array.from({length:e},()=>[]);for(let u=0;u<t.length;u++)c[u]=[t[u]];return c}if(t.length===1){const c=t[0],u=(c.rawMarkdown||c.content||"").trim(),m=u.split(/\r?\n/),g=[];for(let f=0;f<m.length;f++)/^[ \t]*[-*+]\s+|^[ \t]*\d+\.\s+/.test(m[f])&&g.push(f);if(g.length>=e){const f=Array.from({length:e},()=>[]);let v=0;for(let k=0;k<e;k++){const x=e-k,S=g.length-v,B=Math.ceil(S/x),A=g[v],I=v+B<g.length?g[v+B]:m.length,w=m.slice(A,I).join(`
`);f[k]=[{...c,id:k===0?c.id:`${c.id}-col${k+1}`,rawMarkdown:w,content:w}],v+=B}return f}const d=u.match(/<li[\s\S]*?<\/li>/gi);if(d&&d.length>=e){const f=Array.from({length:e},()=>[]);let v=0;for(let k=0;k<e;k++){const x=e-k,S=d.length-v,B=Math.ceil(S/x),A=`<ul>
${d.slice(v,v+B).join(`
`)}
</ul>`;f[k]=[{...c,id:k===0?c.id:`${c.id}-col${k+1}`,rawMarkdown:A,content:A}],v+=B}return f}const y=u.split(/\r?\n\s*\r?\n/).filter(f=>f.trim()!=="");if(y.length>=e){const f=Array.from({length:e},()=>[]);let v=0;for(let k=0;k<e;k++){const x=e-k,S=y.length-v,B=Math.ceil(S/x),A=y.slice(v,v+B).join(`

`);f[k]=[{...c,id:k===0?c.id:`${c.id}-col${k+1}`,rawMarkdown:A,content:A}],v+=B}return f}}const a=Array.from({length:e},()=>[]);return a[0]=t,a}function Ar(t,i,e,n){var u;const o=Ou(i),s=[],l=Ir(i);let r={pageIndex:1,startBlockId:t,frontmatter:{layout:l.frontmatter.layout||"cover",...l.frontmatter},notes:"",noteBlocks:[],blocks:[],rawMarkdown:"",allBlockIds:[t]};r.frontmatter.background&&(r.frontmatter.background=Ie(r.frontmatter.background,n)),r.frontmatter.image&&(r.frontmatter.image=Ie(r.frontmatter.image,n)),s.push(r);let a=[];for(const m of e){if(yo(m)){a=[];const d=Ir(m.ial);if(s.length===1&&r.blocks.length===0){r.startBlockId=m.id,r.allBlockIds||(r.allBlockIds=[]),r.allBlockIds.includes(m.id)||r.allBlockIds.push(m.id),d.frontmatter.layout&&(r.frontmatter.layout=d.frontmatter.layout),Object.assign(r.frontmatter,d.frontmatter),!d.frontmatter.image&&l.frontmatter.image&&(r.frontmatter.image=l.frontmatter.image),!d.frontmatter.background&&l.frontmatter.background&&(r.frontmatter.background=l.frontmatter.background),r.frontmatter.background&&(r.frontmatter.background=Ie(r.frontmatter.background,n)),r.frontmatter.image&&(r.frontmatter.image=Ie(r.frontmatter.image,n));continue}r={pageIndex:s.length+1,startBlockId:m.id,frontmatter:{layout:d.frontmatter.layout||"default",...d.frontmatter},notes:"",noteBlocks:[],blocks:[],rawMarkdown:"",allBlockIds:[m.id]},r.frontmatter.background&&(r.frontmatter.background=Ie(r.frontmatter.background,n)),r.frontmatter.image&&(r.frontmatter.image=Ie(r.frontmatter.image,n)),s.push(r);continue}const g=(d,y)=>{var J,U,G,V;if(r.allBlockIds||(r.allBlockIds=[]),d.id&&!r.allBlockIds.includes(d.id)&&r.allBlockIds.push(d.id),d.children&&d.children.length>0){const M=E=>{for(const R of E)R.id&&!r.allBlockIds.includes(R.id)&&r.allBlockIds.push(R.id),R.children&&R.children.length>0&&M(R.children)};M(d.children)}let f=sc(d),v=d.ial?{...d.ial}:{};const k=f.match(/\{:\s*([^}]+)\s*\}\s*$/);k&&(v={...rc(k[0]),...v},f=f.slice(0,k.index).trim()),d.type!=="c"&&!f.startsWith("```")&&(f=Ql(f));let x=f.trim();if(/^\{\{\{(?:row|col)?\s*$/i.test(x)||x==="}}}")return;/^\{\{\{(?:row|col)?\s*\r?\n/i.test(x)&&/\r?\n\}\}\}$/.test(x)&&(f=x.replace(/^\{\{\{(?:row|col)?\s*\r?\n/i,"").replace(/\r?\n\}\}\}$/,"").trim(),x=f.trim());const S=zu(v);if(f=cc(f,n),f=oc(f,n==null?void 0:n.refContentMap),d.children&&d.children.length>0){const M=["custom-slidev-autoplay","custom-slidev-loop","custom-slidev-muted","custom-slidev-controls"],E=R=>{for(const tt of R){if(tt.ial)for(const[Q,Y]of Object.entries(tt.ial))M.includes(Q)&&!v[Q]&&(v[Q]=Y);tt.children&&tt.children.length>0&&E(tt.children)}};E(d.children)}const B=d.type==="video"||d.type==="NodeVideo"||/<video\b/i.test(f);if(B){const M=v["custom-slidev-autoplay"]==="true",E=v["custom-slidev-loop"]==="true",R=v["custom-slidev-muted"]==="true"||M,tt=v["custom-slidev-controls"]==="false";f=f.replace(/<video\b([^>]*)>/gi,(Q,Y)=>{let W=Y;return tt?W=W.replace(/\bcontrols(?:="[^"]*")?/gi,"").trim():/controls/i.test(W)||(W+=" controls"),M&&!/autoplay/i.test(W)?W+=" autoplay playsinline":!M&&v["custom-slidev-autoplay"]==="false"&&(W=W.replace(/\bautoplay\b/gi,"").replace(/\bplaysinline\b/gi,"").trim()),E&&!/loop/i.test(W)?W+=" loop":!E&&v["custom-slidev-loop"]==="false"&&(W=W.replace(/\bloop\b/gi,"").trim()),R&&!/muted/i.test(W)?W+=" muted":!R&&v["custom-slidev-muted"]==="false"&&(W=W.replace(/\bmuted\b/gi,"").trim()),`<video ${W.trim()}>`})}if(S.isBackground){const M=vi(f,d.content);if(M){r.frontmatter.background=Ie(M,n);return}}const A=yi(d);if(A){r.frontmatter.layout=A.layout,r.frontmatter.image=Ie(A.imageUrl,n),!r.frontmatter.layoutRatio&&A.ratio&&(r.frontmatter.layoutRatio=A.ratio);for(const M of A.contentNodes)g(M);return}if(S.imageLayout==="image-left"||S.imageLayout==="image-right"){const M=vi(f,d.content);if(M){r.frontmatter.layout=S.imageLayout,r.frontmatter.image=Ie(M,n),!r.frontmatter.layoutRatio&&((J=d.ial)!=null&&J[re])&&(r.frontmatter.layoutRatio=d.ial[re]);return}}if(le(d)&&d.children&&d.children.length>0){for(const M of d.children)g(M);return}const I=!!(S.slot||y!=null&&y.defaultSlot||ao(r.frontmatter.layout)||r.frontmatter.layout==="two-cols");if((d.type==="l"||d.type==="NodeList"||d.type==="list")&&d.children&&d.children.length>0&&(d.children.some(M=>{var E,R;return((E=M.ial)==null?void 0:E[At])||((R=M.ial)==null?void 0:R[jt])})||S.slot||S.clicks||I)){for(const M of d.children)S.slot&&(!M.ial||!M.ial[At])&&(M.ial||(M.ial={}),M.ial[At]=S.slot),g(M,{...y,parentClicks:S.clicks||(y==null?void 0:y.parentClicks),defaultSlot:S.slot||(y==null?void 0:y.defaultSlot)});return}const w=!!(d.children&&d.children.length>=2)||!!S.clicks||!!((U=d.children)!=null&&U.some(M=>{var E;return(E=M.ial)==null?void 0:E[jt]}))||!d.markdown&&!!(d.children&&d.children.length>0);if(Oi(d)&&d.children&&d.children.length>0&&(I||S.clicks||d.children.some(M=>{var E;return(E=M.ial)==null?void 0:E[jt]}))&&w){const M=!!(d.children&&d.children.length>=2),E=d.children.find(ct=>!!(ct.markdown||ct.content||"").trim())||d.children[0],R=((G=E==null?void 0:E.ial)==null?void 0:G[jt])||((V=E==null?void 0:E.ial)==null?void 0:V["custom-slidev-click"]),tt=!!(!S.clicks&&M&&R),Q=S.clicks||(tt?R:void 0)||(y==null?void 0:y.parentClicks),Y=d.id||(y==null?void 0:y.parentContainerId),W=S.slot||(y==null?void 0:y.defaultSlot);let ut=!0;for(const ct of d.children){W&&(!ct.ial||!ct.ial[At])&&(ct.ial||(ct.ial={}),ct.ial[At]=W);const X=!!(ct.markdown||ct.content||"").trim(),dt=ut&&X;dt&&(ct.markdown&&(ct.markdown=bn(ct.markdown)),ct.content&&(ct.content=bn(ct.content)),ut=!1);let bt=ct;dt&&Q&&M&&(bt={...ct,ial:{...ct.ial||{}}},delete bt.ial[jt],delete bt.ial["custom-slidev-click"]),g(bt,{parentClicks:Q,parentContainerId:Y,defaultSlot:W})}return}if(S.isNote){const M=ea(f);M&&(r.notes?r.notes+=`

`+M:r.notes=M),r.noteBlocks||(r.noteBlocks=[]),r.noteBlocks.push({id:d.id,type:d.type,content:M||d.content||"",rawMarkdown:f,isNote:!0,attributes:d.ial});return}S.shikiLines&&(f=Gu(f,S.shikiLines)),x=f.trim();const z=(d.content||"").trim();if(x==="::right::"||z==="::right::"||/^<p>\s*::right::\s*<\/p>$/i.test(x)||x.startsWith("::right::")){r.blocks.push({id:d.id,type:d.type,content:"::right::",rawMarkdown:"::right::",slot:"slot-divider-right",attributes:d.ial});return}const H=Yu(d);let et=S.slot,_=S.clicks,P=S.motion,b={...d.ial||{}};if(H!==null){for(;a.length>0&&a[a.length-1].level>=H;)a.pop();const M=a.length>0?a[a.length-1]:void 0;!et&&(M!=null&&M.slot)&&(et=M.slot),!_&&(M!=null&&M.clicks)&&!(y!=null&&y.parentContainerId)&&(_=M.clicks),!P&&(M!=null&&M.motion)&&(P=M.motion);const E={...(M==null?void 0:M.customAttrs)||{}};if(d.ial)for(const[R,tt]of Object.entries(d.ial))R.startsWith("custom-slidev-")&&!R.startsWith("custom-slidev-slide")&&(E[R]=tt);y!=null&&y.parentContainerId||a.push({level:H,slot:et,clicks:_,motion:P,customAttrs:E})}else{const M=a.length>0?a[a.length-1]:void 0;M&&(!et&&M.slot&&M.slot!=="header"&&(et=M.slot),!_&&M.clicks&&!(y!=null&&y.parentContainerId)&&(_=M.clicks),!P&&M.motion&&(P=M.motion),M.customAttrs&&(b={...M.customAttrs,...b}))}!et&&r.blocks.some(M=>M.slot==="slot-divider-right")&&(et="right"),!et&&(y!=null&&y.defaultSlot)&&(et=y.defaultSlot),et&&(b[At]=et),_&&!b[jt]&&(b[jt]=_),P&&!b[Ve]&&(b[Ve]=JSON.stringify(P)),(B||v["custom-slidev-autoplay"]||v["custom-slidev-muted"])&&(v["custom-slidev-autoplay"]&&(b["custom-slidev-autoplay"]=v["custom-slidev-autoplay"],v["custom-slidev-autoplay"]==="true"&&!v["custom-slidev-muted"]&&(b["custom-slidev-muted"]="true")),v["custom-slidev-loop"]&&(b["custom-slidev-loop"]=v["custom-slidev-loop"]),v["custom-slidev-muted"]&&(b["custom-slidev-muted"]=v["custom-slidev-muted"]),v["custom-slidev-controls"]&&(b["custom-slidev-controls"]=v["custom-slidev-controls"]));const N={id:d.id,type:d.type,content:d.content||"",rawMarkdown:f,clicks:_,parentClicks:y==null?void 0:y.parentClicks,parentContainerId:y==null?void 0:y.parentContainerId,motion:P,shikiLines:S.shikiLines,slot:et,attributes:b};r.blocks.push(N)};g(m)}for(let m=0;m<s.length;m++){const g=s[m],d=[],y={...g.frontmatter};m===0&&(y.theme=o.theme,y.aspectRatio=o.aspectRatio,y.highlighter=o.highlighter,y.transition=g.frontmatter.transition||o.defaultTransition);const f=Ku(y);f&&d.push(f);const v=g.blocks.filter(A=>A.slot!=="slot-divider-right"),k=A=>A.filter(I=>!!(I.rawMarkdown||I.content||"").trim()).map(I=>{var w;return Gn(I.rawMarkdown,I.clicks,I.motion,(w=I.attributes)==null?void 0:w.style)}).join(`

`),x=A=>{const I=A.filter(H=>!!(H.rawMarkdown||H.content||"").trim());if(I.length===0)return;const w=I[0],z=(w.rawMarkdown||w.content||"").trim();(Oi(w)||/^(?:[-*+]|\d+\.)\s+/.test(z))&&(w.rawMarkdown=bn(w.rawMarkdown||w.content||""),w.content=w.rawMarkdown)},S=A=>{var H,et;if(A.length===0)return"";x(A);const I=(H=A.find(_=>_.parentClicks))==null?void 0:H.parentClicks;if(!I)return A.filter(_=>!!(_.rawMarkdown||_.content||"").trim()).map(_=>{var P;return Gn(_.rawMarkdown,_.clicks,_.motion,(P=_.attributes)==null?void 0:P.style)}).join(`

`);const w=[];let z=[];const O=()=>{if(z.length===0)return;const _=z.map(P=>(P.rawMarkdown||P.content||"").trim()).filter(Boolean).join(`

`);_&&w.push(ta(_,I)),z=[]};for(const _ of A){if(!(_.rawMarkdown||_.content||"").trim())continue;!!(_.clicks&&_.clicks.trim()!=="")?(O(),w.push(Gn(_.rawMarkdown,_.clicks,_.motion,(et=_.attributes)==null?void 0:et.style))):z.push(_)}return O(),w.join(`

`)},B=g.frontmatter.layout||"default";if(ao(B)){let A=[];const I=v.filter(_=>_.slot==="header");if(I.length>0)A=I;else if(v.length>0){const _=v.find(P=>P.type==="h"&&(!P.slot||P.slot==="default"));_&&(A=[_])}const w=v.filter(_=>!A.includes(_));let z=2;if(B==="three-cols-header")z=3;else if(B==="two-cols-header")z=2;else{let _=0;for(const P of w){const b=(P.slot||"").match(/^col-(\d+)$/i);b&&(_=Math.max(_,parseInt(b[1],10)))}if(_>=2)z=_;else if(g.frontmatter.layoutRatio){const P=g.frontmatter.layoutRatio.trim();if(P.includes(":")){const b=P.split(":").map(N=>parseFloat(N.trim())).filter(N=>!isNaN(N)&&N>0);b.length>=2&&(z=b.length)}else{const b=P.split(/\s+/).filter(Boolean);b.length>=2&&(z=b.length)}}else w.length===1&&w[0].children&&w[0].children.length>=2&&(z=Math.min(6,w[0].children.length))}const O=ia(w,z);O.forEach((_,P)=>{const b=`col-${P+1}`;for(const N of _)(!N.slot||N.slot==="default")&&(N.slot=b);x(_)});const H=O.flat();if(w.length===1&&H.length>1){const _=g.blocks.findIndex(P=>P.id===w[0].id);_!==-1&&g.blocks.splice(_,1,...H)}const et=k(A);if(et&&d.push(et),B==="two-cols-header"&&z===2){const _=S(O[0]||[]),P=S(O[1]||[]);_&&d.push(`::left::

${_}`),P&&d.push(`::right::

${P}`)}else O.forEach((_,P)=>{const b=S(_);b&&d.push(`::col-${P+1}::

${b}`)})}else if(B==="two-cols"){const A=v.filter(O=>O.slot==="left"),I=v.filter(O=>O.slot==="right");x(A),x(I);const w=k(A.length>0?A:v.filter(O=>O.slot!=="right")),z=k(I);d.push(w),z&&d.push(`::right::

${z}`)}else for(const A of v)d.push(Gn(A.rawMarkdown,A.clicks,A.motion,(u=A.attributes)==null?void 0:u.style));g.notes&&d.push(`<!--
${g.notes}
-->`),g.rawMarkdown=d.join(`

`).trim()}const c=s.map(m=>m.rawMarkdown).filter(Boolean).join(`

---

`);return{docId:t,config:o,slides:s,fullMarkdown:c}}const ps=`/* SiYuan Note Built-in Font & Background Styles for Slidev */
:root,
html:not(.dark),
[data-theme="light"],
[data-theme-mode="light"] {
  /* 思源基础卡片与主题色 (浅色模式 daylight) */
  --b3-card-error-color: #790600;
  --b3-card-error-background: #f5d1cf;
  --b3-card-warning-color: #8a4f00;
  --b3-card-warning-background: #ffe8c8;
  --b3-card-info-color: #005599;
  --b3-card-info-background: #d6eaf9;
  --b3-card-success-color: #006b04;
  --b3-card-success-background: #d7eed8;

  --b3-theme-primary: #3575f0;
  --b3-theme-secondary: #ff9200;
  --b3-theme-error: #d23f31;
  --b3-theme-background: #ffffff;
  --b3-theme-on-background: #222222;
  --b3-theme-on-surface: #5f6368;
  --b3-theme-surface-lighter: #e0e0e0;

  /* 13 种内置文字颜色 */
  --b3-font-color1: var(--b3-card-error-color);
  --b3-font-color2: var(--b3-card-warning-color);
  --b3-font-color3: var(--b3-card-info-color);
  --b3-font-color4: var(--b3-card-success-color);
  --b3-font-color5: var(--b3-theme-on-surface);
  --b3-font-color6: var(--b3-theme-primary);
  --b3-font-color7: var(--b3-theme-secondary);
  --b3-font-color8: var(--b3-theme-error);
  --b3-font-color9: #a40074;
  --b3-font-color10: #007080;
  --b3-font-color11: #006e2a;
  --b3-font-color12: #6b5a00;
  --b3-font-color13: var(--b3-theme-background);

  /* 13 种内置背景颜色 */
  --b3-font-background1: var(--b3-card-error-background);
  --b3-font-background2: var(--b3-card-warning-background);
  --b3-font-background3: var(--b3-card-info-background);
  --b3-font-background4: var(--b3-card-success-background);
  --b3-font-background5: #e2e3e4;
  --b3-font-background6: #acd0fc;
  --b3-font-background7: #fddaab;
  --b3-font-background8: #ffb0a9;
  --b3-font-background9: #fdbfff;
  --b3-font-background10: #b1ffff;
  --b3-font-background11: #affad1;
  --b3-font-background12: #fff88f;
  --b3-font-background13: var(--b3-theme-on-background);
}

html.dark,
[data-theme="dark"],
[data-theme-mode="dark"],
.theme-dark,
.dark {
  /* 思源基础卡片与主题色 (深色模式 midnight) */
  --b3-card-error-color: rgb(243, 153, 147);
  --b3-card-error-background: #442724;
  --b3-card-warning-color: rgb(255, 213, 153);
  --b3-card-warning-background: #554636;
  --b3-card-info-color: rgb(166, 213, 250);
  --b3-card-info-background: #28405c;
  --b3-card-success-color: rgb(183, 223, 185);
  --b3-card-success-background: #425347;

  --b3-theme-primary: #3575f0;
  --b3-theme-secondary: #ff9200;
  --b3-theme-error: #d23f31;
  --b3-theme-background: #1e1e1e;
  --b3-theme-on-background: #c8ccd6;
  --b3-theme-on-surface: #8b949e;
  --b3-theme-surface-lighter: #282a2e;

  /* 13 种内置文字颜色 */
  --b3-font-color1: var(--b3-card-error-color);
  --b3-font-color2: var(--b3-card-warning-color);
  --b3-font-color3: var(--b3-card-info-color);
  --b3-font-color4: var(--b3-card-success-color);
  --b3-font-color5: var(--b3-theme-on-surface);
  --b3-font-color6: var(--b3-theme-primary);
  --b3-font-color7: var(--b3-theme-secondary);
  --b3-font-color8: var(--b3-theme-error);
  --b3-font-color9: #f47c9c;
  --b3-font-color10: #4dd0e1;
  --b3-font-color11: #10df54;
  --b3-font-color12: #ecd424;
  --b3-font-color13: var(--b3-theme-background);

  /* 13 种内置背景颜色 */
  --b3-font-background1: var(--b3-card-error-background);
  --b3-font-background2: var(--b3-card-warning-background);
  --b3-font-background3: var(--b3-card-info-background);
  --b3-font-background4: var(--b3-card-success-background);
  --b3-font-background5: #3a3f42;
  --b3-font-background6: #031840;
  --b3-font-background7: #593905;
  --b3-font-background8: #3a0c09;
  --b3-font-background9: #4d1b40;
  --b3-font-background10: #1a5459;
  --b3-font-background11: #305415;
  --b3-font-background12: #4a4712;
  --b3-font-background13: var(--b3-theme-on-background);
}

@media (prefers-color-scheme: dark) {
  :root:not([data-theme="light"]):not([data-theme-mode="light"]):not(.light) {
    --b3-card-error-color: rgb(243, 153, 147);
    --b3-card-error-background: #442724;
    --b3-card-warning-color: rgb(255, 213, 153);
    --b3-card-warning-background: #554636;
    --b3-card-info-color: rgb(166, 213, 250);
    --b3-card-info-background: #28405c;
    --b3-card-success-color: rgb(183, 223, 185);
    --b3-card-success-background: #425347;

    --b3-theme-primary: #3575f0;
    --b3-theme-secondary: #ff9200;
    --b3-theme-error: #d23f31;
    --b3-theme-background: #1e1e1e;
    --b3-theme-on-background: #c8ccd6;
    --b3-theme-on-surface: #8b949e;
    --b3-theme-surface-lighter: #282a2e;

    --b3-font-color1: var(--b3-card-error-color);
    --b3-font-color2: var(--b3-card-warning-color);
    --b3-font-color3: var(--b3-card-info-color);
    --b3-font-color4: var(--b3-card-success-color);
    --b3-font-color5: var(--b3-theme-on-surface);
    --b3-font-color6: var(--b3-theme-primary);
    --b3-font-color7: var(--b3-theme-secondary);
    --b3-font-color8: var(--b3-theme-error);
    --b3-font-color9: #f47c9c;
    --b3-font-color10: #4dd0e1;
    --b3-font-color11: #10df54;
    --b3-font-color12: #ecd424;
    --b3-font-color13: var(--b3-theme-background);

    --b3-font-background1: var(--b3-card-error-background);
    --b3-font-background2: var(--b3-card-warning-background);
    --b3-font-background3: var(--b3-card-info-background);
    --b3-font-background4: var(--b3-card-success-background);
    --b3-font-background5: #3a3f42;
    --b3-font-background6: #031840;
    --b3-font-background7: #593905;
    --b3-font-background8: #3a0c09;
    --b3-font-background9: #4d1b40;
    --b3-font-background10: #1a5459;
    --b3-font-background11: #305415;
    --b3-font-background12: #4a4712;
    --b3-font-background13: var(--b3-theme-on-background);
  }
}

/* 演示块级样式排版增强 (带背景色时赋予呼吸内边距与舒适圆角) */
.slide-styled-block {
  border-radius: 6px;
  padding: 8px 14px;
  box-sizing: border-box;
  margin: 6px 0;
  transition: background-color 0.2s ease, color 0.2s ease;
}

/* 行内带背景色文本的精美圆角与微边距 */
span[style*="background-color"],
span[style*="background:"] {
  border-radius: 3px;
  padding: 1px 5px;
  box-decoration-break: clone;
  -webkit-box-decoration-break: clone;
}
`;function Ju(t){var o,s,l,r,a,c,u,m,g,d,y,f;if(!t||typeof t!="object")return"";const i=[],e=[];if(Array.isArray(t.styles))for(const v of t.styles){if(!v||!v.id)continue;const k=`--b3-inline-style-${v.id}`;(o=v.light)!=null&&o.color&&i.push(`  ${k}-color: ${v.light.color};`),(s=v.light)!=null&&s.backgroundColor&&i.push(`  ${k}-background-color: ${v.light.backgroundColor};`),(l=v.dark)!=null&&l.color&&e.push(`  ${k}-color: ${v.dark.color};`),(r=v.dark)!=null&&r.backgroundColor&&e.push(`  ${k}-background-color: ${v.dark.backgroundColor};`)}if(t.builtin&&Array.isArray(t.builtin.colors))for(const v of t.builtin.colors){if(!v||typeof v.index!="number")continue;const k=v.index;(a=v.light)!=null&&a.color&&i.push(`  --b3-font-color${k}: ${v.light.color};`),(c=v.light)!=null&&c.backgroundColor&&i.push(`  --b3-font-background${k}: ${v.light.backgroundColor};`),(u=v.dark)!=null&&u.color&&e.push(`  --b3-font-color${k}: ${v.dark.color};`),(m=v.dark)!=null&&m.backgroundColor&&e.push(`  --b3-font-background${k}: ${v.dark.backgroundColor};`)}if(t.builtin&&Array.isArray(t.builtin.styles))for(const v of t.builtin.styles){if(!v||!v.id)continue;const k=v.id;(g=v.light)!=null&&g.color&&i.push(`  --b3-card-${k}-color: ${v.light.color};`),(d=v.light)!=null&&d.backgroundColor&&i.push(`  --b3-card-${k}-background: ${v.light.backgroundColor};`),(y=v.dark)!=null&&y.color&&e.push(`  --b3-card-${k}-color: ${v.dark.color};`),(f=v.dark)!=null&&f.backgroundColor&&e.push(`  --b3-card-${k}-background: ${v.dark.backgroundColor};`)}if(i.length===0&&e.length===0)return"";const n=[];return i.length>0&&n.push(`:root, html:not(.dark), [data-theme="light"] {
${i.join(`
`)}
}`),e.length>0&&n.push(`html.dark, [data-theme="dark"], .dark {
${e.join(`
`)}
}`),n.join(`

`)}function kn(t){const i=Ju(t);return i?`${ps}

/* Custom Workspace Inline Styles */
${i}`:ps}function Go(t){const i={};if(!t||typeof t!="string")return i;const e=t.replace(/^\{:\s*/,"").replace(/\s*\}$/,""),n=/([\w-]+)=(?:"([^"]*)"|'([^']*)'|(\S+))/g;let o;for(;(o=n.exec(e))!==null;){const s=o[1],l=o[2]??o[3]??o[4]??"";i[s]=l}return i}const Xu={getBlockAttrs:Ze,getChildBlocks:no,setBlockAttrs:Dt,sql:wn,getBaseUrl:()=>typeof location<"u"?location.origin:"",getInlineStyles:ic};class Qu{constructor(i){xt(this,"deps");xt(this,"attrOverrides",new Map);xt(this,"trackedListSuperBlocks",new Map);this.deps={...Xu,...i||{}}}setBlockAttrOverride(i,e){if(!i||!e)return;const o={...this.attrOverrides.get(i)||{}};for(const[s,l]of Object.entries(e))l===""||l===null||l===void 0?delete o[s]:o[s]=String(l);Object.keys(o).length===0?this.attrOverrides.delete(i):this.attrOverrides.set(i,o)}getBlockAttrOverride(i){return this.attrOverrides.get(i)}getAllAttrOverrides(){return new Map(this.attrOverrides)}getTrackedListSuperBlocks(i){return this.trackedListSuperBlocks.get(i)||[]}clearBlockAttrOverride(i,e){if(!i)return;if(!e){this.attrOverrides.delete(i);return}const n=this.attrOverrides.get(i);n&&(delete n[e],Object.keys(n).length===0&&this.attrOverrides.delete(i))}clearAllOverrides(){this.attrOverrides.clear(),this.trackedListSuperBlocks.clear()}async compile(i){try{const e=await this.deps.getBlockAttrs(i).catch(()=>({}))||{},n=this.attrOverrides.get(i);n&&Object.assign(e,n);let o=await this.deps.getChildBlocks(i).catch(()=>[]);const s=`SELECT id, ial FROM blocks WHERE root_id = '${i}' LIMIT 99999`,l=await this.deps.sql(s).catch(()=>[])||[],r=new Map;if(Array.isArray(l))for(const S of l)S.id&&S.ial&&r.set(S.id,Go(S.ial));const a=`SELECT block_id, name, value FROM attributes WHERE root_id = '${i}' AND type = 'b' LIMIT 99999`,c=await this.deps.sql(a).catch(()=>[])||[];if(Array.isArray(c)){for(const S of c)if(S.block_id&&S.name){let B=r.get(S.block_id);B||(B={},r.set(S.block_id,B)),B[S.name]=S.value||""}}if(!o||o.length===0){const S=`SELECT id, parent_id, root_id, type, sub_type as subType, content, markdown, ial FROM blocks WHERE root_id = '${i}' AND id != '${i}' ORDER BY created ASC LIMIT 99999`;o=await this.deps.sql(S).catch(()=>[])||[]}const u=(o||[]).map(S=>{const B=r.get(S.id)||(S.ial?Go(S.ial):{}),A=this.attrOverrides.get(S.id);return A&&Object.assign(B,A),{id:S.id,parent_id:S.parent_id,root_id:S.root_id||i,type:S.type,subType:S.subType,content:S.content||"",markdown:S.markdown||"",ial:B,children:S.children}}),m=async(S,B=0)=>{if(!(!S||S.length===0||B>8))for(const A of S){if((le(A)||A.type==="l"||A.type==="NodeList"||A.type==="i"||A.type==="NodeListItem"||A.type==="b"||A.type==="NodeBlockquote")&&(!A.children||A.children.length===0)){let w=await this.deps.getChildBlocks(A.id).catch(()=>[]);if(!w||w.length===0){const z=`SELECT id, parent_id, root_id, type, sub_type as subType, content, markdown, ial FROM blocks WHERE parent_id = '${A.id}' ORDER BY sort ASC, created ASC`;w=await this.deps.sql(z).catch(()=>[])||[]}if(Array.isArray(w)&&w.length>0){const z=new Set(u.map(H=>H.id)),O=w.filter(H=>H.id!==A.id&&!z.has(H.id));O.length>0&&(A.children=O.map(H=>{const et=r.get(H.id)||(H.ial?Go(H.ial):{}),_=this.attrOverrides.get(H.id);return _&&Object.assign(et,_),{id:H.id,parent_id:H.parent_id||A.id,root_id:H.root_id||i,type:H.type,subType:H.subType,content:H.content||"",markdown:H.markdown||"",ial:et}}))}}A.children&&A.children.length>0&&await m(A.children,B+1)}};await m(u);const g=S=>{var B,A;for(const I of S)if(I.children&&I.children.length>0){g(I.children);for(const w of I.children)if(w.ial)for(const[z,O]of Object.entries(w.ial))z.startsWith("custom-slidev-")&&!((B=I.ial)!=null&&B[z])&&(I.ial||(I.ial={}),I.ial[z]=O);if(I.ial){for(const[w,z]of Object.entries(I.ial))if(w.startsWith("custom-slidev-"))for(const O of I.children)(O.type==="video"||O.type==="NodeVideo"||/<video\b/i.test(O.markdown||O.content||""))&&!((A=O.ial)!=null&&A[w])&&(O.ial||(O.ial={}),O.ial[w]=z)}}};g(u),Uu(u,S=>{const B={[mt]:S.layout};this.setBlockAttrOverride(S.blockId,B),(this.deps.setBlockAttrs||Dt)(S.blockId,B).catch(I=>{console.warn("[DocumentCompiler] Failed to auto-tag superblock image layout:",I)})});const d=this.trackedListSuperBlocks.get(i)||[],y=ju(i,u,{tracked:d,onTagChange:S=>{this.setBlockAttrOverride(S.blockId,S.attrs),S.blockId===i&&Object.assign(e,S.attrs);const B=I=>{for(const w of I)w.id===S.blockId&&(w.ial||(w.ial={}),Object.assign(w.ial,S.attrs)),w.children&&w.children.length>0&&B(w.children)};B(u),(this.deps.setBlockAttrs||Dt)(S.blockId,S.attrs).catch(I=>{console.warn("[DocumentCompiler] Failed to auto-tag list superblock attrs:",I)})}});this.trackedListSuperBlocks.set(i,y.newTracked);const f=new Set;for(const S of u){const B=S.markdown||S.content||"";if(B.includes("((")){const A=nc(B);for(const I of A)f.add(I.blockId)}}const v={};if(f.size>0){const S=Array.from(f).map(A=>`'${A}'`).join(","),B=await this.deps.sql(`SELECT id, content, markdown FROM blocks WHERE id IN (${S})`).catch(()=>[])||[];if(Array.isArray(B))for(const A of B)A.id&&(v[A.id]=A.markdown||A.content||"")}const k=this.deps.getBaseUrl?this.deps.getBaseUrl():"",x=Ar(i,e,u,{baseUrl:k,refContentMap:v});try{const S=this.deps.getInlineStyles?await this.deps.getInlineStyles().catch(()=>null):null;x.customThemeCss=kn(S)}catch{x.customThemeCss=kn(null)}return x}catch(e){console.error("[DocumentCompilerService] Failed to compile document:",e);const n=Ar(i,{},[],{});return n.customThemeCss=kn(null),n}}}const Pt=new Qu;class Rs{constructor(i){xt(this,"devServerUrl","http://localhost:3030");xt(this,"isConnected",!1);xt(this,"lastSyncTime",null);i&&(this.devServerUrl=i)}getUrl(){return this.devServerUrl}setUrl(i){this.devServerUrl=i.replace(/\/+$/,"")}isServerConnected(){return this.isConnected}getLastSyncTime(){return this.lastSyncTime}async probeServer(i=1500){try{const e=new AbortController,n=setTimeout(()=>e.abort(),i),o=await fetch(this.devServerUrl,{method:"HEAD",mode:"no-cors",signal:e.signal}).catch(()=>null);return clearTimeout(n),this.isConnected=!!o,this.isConnected}catch{return this.isConnected=!1,!1}}buildStandardSlidevMarkdown(i){const e=i.config,n=["---",`theme: ${e.theme||"default"}`,`aspectRatio: "${e.aspectRatio||"16/9"}"`,`highlighter: ${e.highlighter||"shiki"}`,`transition: ${e.defaultTransition||"slide-left"}`];e.colorSchema&&e.colorSchema!=="auto"&&n.push(`colorSchema: ${e.colorSchema}`),n.push("drawings:","  persist: false","---","");const o=n.join(`
`),s=i.slides.map((l,r)=>{const a=l.frontmatter||{},c=[],u=r===0;a.layout&&a.layout!=="default"&&c.push(`layout: ${a.layout}`),a.transition&&c.push(`transition: ${a.transition}`),a.background&&c.push(`background: ${a.background}`),a.class&&c.push(`class: "${a.class}"`);let m="";c.length>0?m=u?"":`---
${c.join(`
`)}
---

`:u||(m=`---

`);let g="";if(a.layout==="two-cols"){const y=l.blocks.filter(x=>x.slot!=="right"),f=l.blocks.filter(x=>x.slot==="right"),v=y.map(x=>x.rawMarkdown||x.content||"").join(`

`),k=f.map(x=>x.rawMarkdown||x.content||"").join(`

`);g=`${v}

::right::

${k}`}else g=l.blocks.map(y=>y.rawMarkdown||y.content||"").join(`

`);let d="";return l.notes&&l.notes.trim()&&(d=`

<!--
${l.notes.trim()}
-->`),`${m}${g}${d}`}).join(`

`);return`${o}${s}
`}async syncToWorkspaceFile(i,e="/data/storage/petal/siyuan-slidev/slides.md",n){const o=this.buildStandardSlidevMarkdown(i);if(this.lastSyncTime=Date.now(),n)try{const s=typeof Blob<"u"?new Blob([o],{type:"text/markdown;charset=utf-8"}):Buffer.from(o,"utf-8");return await n(e,!1,s),{success:!0,path:e}}catch(s){return{success:!1,path:e,error:String(s)}}return{success:!0,path:e}}downloadSlidesMd(i,e="slides.md"){if(typeof window>"u"||typeof document>"u")return!1;const n=this.buildStandardSlidevMarkdown(i),o=new Blob([n],{type:"text/markdown;charset=utf-8"}),s=URL.createObjectURL(o),l=document.createElement("a");return l.href=s,l.download=e,document.body.appendChild(l),l.click(),document.body.removeChild(l),URL.revokeObjectURL(s),!0}}function tf(){if(typeof window<"u"&&typeof window.require=="function")return window.require.bind(window);if(typeof globalThis<"u"&&typeof globalThis.require=="function")return globalThis.require.bind(globalThis);if(typeof require=="function")return require}function $e(t){const i=tf();if(i)try{return i(t)}catch{try{const e=t.startsWith("node:")?t.slice(5):`node:${t}`;return i(e)}catch{}}}function Os(){var i;if(typeof window<"u"&&window.process)return window.process;const t=$e("process");return t&&t.versions?t:typeof process<"u"&&((i=process.versions)!=null&&i.node)?process:globalThis.process}function na(){var i,e;const t=Os();if(t&&((i=t.versions)!=null&&i.node))return!0;if(typeof window<"u"&&window.siyuan){const n=$e("child_process");if(n&&typeof n.spawn=="function")return!0}return!!(typeof process<"u"&&((e=process.versions)!=null&&e.node))}function Dn(){const t=Os();if(t!=null&&t.platform)return t.platform;if(typeof process<"u"&&process.platform)return process.platform;const i=$e("os");if(i&&typeof i.platform=="function")return i.platform();if(typeof navigator<"u"){const e=navigator.userAgent.toLowerCase();if(e.includes("win"))return"win32";if(e.includes("mac"))return"darwin";if(e.includes("linux"))return"linux"}return"web"}function oa(){var n,o;const t=Os(),i={...(t==null?void 0:t.env)||{}};if(Dn()==="win32"){const s=["C:\\Program Files\\nodejs","C:\\Program Files (x86)\\nodejs",(n=t==null?void 0:t.env)!=null&&n.APPDATA?`${t.env.APPDATA}\\npm`:"",(o=t==null?void 0:t.env)!=null&&o.USERPROFILE?`${t.env.USERPROFILE}\\AppData\\Roaming\\npm`:""].filter(Boolean),l=Object.keys(i).find(c=>c.toLowerCase()==="path")||"PATH",a=(i[l]||"").split(";").filter(Boolean);for(const c of s)c&&!a.some(u=>u.toLowerCase()===c.toLowerCase())&&a.push(c);i[l]=a.join(";")}return i}function hs(t){var e,n,o;if(!t)return"";if(/^[a-zA-Z]:[/\\]/.test(t))return t.replace(/\\/g,"/");let i="";if(typeof window<"u"&&((o=(n=(e=window.siyuan)==null?void 0:e.config)==null?void 0:n.system)!=null&&o.dataDir)&&(i=window.siyuan.config.system.dataDir.replace(/\\/g,"/")),i&&t.startsWith("/data/")){const s=t.slice(6);return`${i}/${s}`.replace(/\\/g,"/")}return t}function ef(){const t=$e("os"),i=$e("path");if(t&&typeof t.tmpdir=="function"){const e=t.tmpdir();return i&&typeof i.join=="function"?i.join(e,"siyuan-slidev-pro").replace(/\\/g,"/"):`${e}/siyuan-slidev-pro`.replace(/\\/g,"/")}return"/data/storage/petal/siyuan-slidev/pro-workspace"}class zs{constructor(i){xt(this,"runner");this.runner=i||zs.defaultRunner}static async defaultRunner(i,e){var n;try{let o=(n=$e("child_process"))==null?void 0:n.execFile;if(!o){const a=await import("node:child_process").catch(()=>({}));o=a==null?void 0:a.execFile}if(!o)return{code:-1,stdout:"",stderr:"child_process execFile not available"};const l=Dn()==="win32",r=oa();return await new Promise(a=>{o(i,e,{timeout:5e3,shell:l,env:r},(c,u,m)=>{a({code:c?c.code||1:0,stdout:u?String(u).trim():"",stderr:m?String(m).trim():""})})})}catch(o){return{code:-1,stdout:"",stderr:String(o)}}}async detect(){const i=na(),e=Dn();if(!i)return{hasNode:!1,hasSlidevCli:!1,platform:"browser",isDesktop:!1,error:"当前处于纯前端浏览器或移动端环境，无 Node.js 运行时支撑"};let n=!1,o,s=!1,l;try{const r=await this.runner("node",["-v"]);r.code===0&&r.stdout.startsWith("v")&&(n=!0,o=r.stdout)}catch{}if(n){try{const r=e==="win32"?"slidev.cmd":"slidev",a=await this.runner(r,["--version"]);a.code===0&&a.stdout&&(s=!0,l=a.stdout)}catch{}if(!s)try{const r=e==="win32"?"npx.cmd":"npx",a=await this.runner(r,["@slidev/cli","--version"]);a.code===0&&a.stdout&&(s=!0,l=a.stdout)}catch{}}return{hasNode:n,nodeVersion:o,hasSlidevCli:s,slidevVersion:l,platform:e,isDesktop:i}}}class nf{constructor(){xt(this,"iframe",null);xt(this,"isReady",!1);xt(this,"pageChangedHandlers",[]);xt(this,"readyHandlers",[]);xt(this,"currentState",{no:1,clicks:0,total:1});this.handleWindowMessage=this.handleWindowMessage.bind(this)}getCurrentState(){return{...this.currentState}}attach(i){this.detach(),this.iframe=i,this.isReady=!1,typeof window<"u"&&window.addEventListener("message",this.handleWindowMessage)}detach(){typeof window<"u"&&window.removeEventListener("message",this.handleWindowMessage),this.iframe=null,this.isReady=!1}postMessage(i,e){var o;if(!((o=this.iframe)!=null&&o.contentWindow))return;const n={target:"slidev",sender:"siyuan",type:i,...e};try{this.iframe.contentWindow.postMessage(n,"*")}catch(s){console.warn("[NativeSlidevBridge] postMessage error:",s)}}navigateToPage(i){this.postMessage("navigate",{no:i})}next(){this.postMessage("next")}prev(){this.postMessage("prev")}nextClick(){this.postMessage("next-click")}prevClick(){this.postMessage("prev-click")}onPageChanged(i){return this.pageChangedHandlers.push(i),()=>{this.pageChangedHandlers=this.pageChangedHandlers.filter(e=>e!==i)}}onReady(i){return this.readyHandlers.push(i),()=>{this.readyHandlers=this.readyHandlers.filter(e=>e!==i)}}handleWindowMessage(i){const e=i.data;if(!(!e||e.target!=="slidev")){if(!this.isReady){this.isReady=!0;for(const n of this.readyHandlers)n()}if(e.type==="update-state"&&e.navState){const n=e.navState;this.currentState={no:n.no??this.currentState.no,clicks:n.clicks??this.currentState.clicks,total:n.total??this.currentState.total,hasNext:n.hasNext,hasPrev:n.hasPrev};for(const o of this.pageChangedHandlers)o(this.currentState.no,this.currentState.total||1,this.currentState)}else if(e.type==="navigate"&&typeof e.no=="number"){this.currentState.no=e.no;for(const n of this.pageChangedHandlers)n(e.no,this.currentState.total||1,this.currentState)}}}}class of{constructor(i){xt(this,"childProcess",null);xt(this,"activePort",null);xt(this,"isRunning",!1);xt(this,"defaultPort");xt(this,"maxPortRetries");xt(this,"probeTimeoutMs");xt(this,"customSpawner");xt(this,"customPortChecker");this.defaultPort=(i==null?void 0:i.defaultPort)||3030,this.maxPortRetries=(i==null?void 0:i.maxPortRetries)||20,this.probeTimeoutMs=(i==null?void 0:i.probeTimeoutMs)||1e4,this.customSpawner=i==null?void 0:i.customSpawner,this.customPortChecker=i==null?void 0:i.customPortChecker}getActivePort(){return this.activePort}getIsRunning(){return this.isRunning}async isPortAvailable(i){if(this.customPortChecker)return this.customPortChecker(i);try{let e=$e("net");return e||(e=await import("node:net").catch(()=>({}))),e!=null&&e.createServer?await new Promise(n=>{const o=e.createServer();o.once("error",()=>n(!1)),o.once("listening",()=>{o.close(()=>n(!0))}),o.listen(i,"127.0.0.1")}):!0}catch{return!0}}async allocPort(i){const e=i||this.defaultPort;for(let n=0;n<this.maxPortRetries;n++){const o=e+n;if(await this.isPortAvailable(o))return o}return e}async pollServerReady(i,e=8e3,n=300){const o=Date.now();for(;Date.now()-o<e;){try{const s=new AbortController,l=setTimeout(()=>s.abort(),n),r=await fetch(i,{method:"HEAD",mode:"no-cors",signal:s.signal}).catch(()=>null);if(clearTimeout(l),r)return!0}catch{}await new Promise(s=>setTimeout(s,n))}return!1}async startServer(i,e){var a,c;if(this.isRunning&&this.activePort)return{success:!0,port:this.activePort,url:`http://localhost:${this.activePort}?embedded=true`};const n=await this.allocPort(e);this.activePort=n;const s=Dn()==="win32"?"npx.cmd":"npx",l=hs(i),r=["@slidev/cli",l,"--port",String(n),"--no-open"];try{if(this.customSpawner)this.childProcess=this.customSpawner(s,r,{detached:!1});else{let m=(a=$e("child_process"))==null?void 0:a.spawn;if(!m){const y=await import("node:child_process").catch(()=>({}));m=y==null?void 0:y.spawn}if(!m)throw new Error("child_process spawn not available in current runtime");const g=l.includes("/")||l.includes("\\")?l.replace(/[/\\][^/\\]+$/,""):void 0,d=oa();this.childProcess=m(s,r,{cwd:g,detached:!1,shell:!0,env:{...d,FORCE_COLOR:"1"}})}this.isRunning=!0,(c=this.childProcess)!=null&&c.on&&this.childProcess.on("exit",()=>{this.isRunning=!1,this.activePort=null,this.childProcess=null});const u=`http://localhost:${n}`;return!this.customSpawner&&!await this.pollServerReady(u,this.probeTimeoutMs)?(this.stopServer(),{success:!1,port:n,url:"",error:`Slidev DevServer 启动超时 (未在 ${this.probeTimeoutMs}ms 内响应端口 ${n})`}):{success:!0,port:n,url:`${u}?embedded=true`}}catch(u){return this.stopServer(),{success:!1,port:n,url:"",error:`唤起 Slidev 进程失败: ${String(u)}`}}}stopServer(){var i;if(this.childProcess){try{if(this.childProcess.kill("SIGTERM"),Dn()==="win32"&&this.childProcess.pid&&!this.customSpawner){const n=(i=$e("child_process"))==null?void 0:i.exec;n?n(`taskkill /pid ${this.childProcess.pid} /T /F`,()=>{}):import("node:child_process").then(({exec:o})=>{var s;o(`taskkill /pid ${(s=this.childProcess)==null?void 0:s.pid} /T /F`,()=>{})}).catch(()=>{})}}catch{}this.childProcess=null}this.isRunning=!1,this.activePort=null}}class Ns{constructor(){xt(this,"iframe",null);xt(this,"isReady",!1);xt(this,"pendingMessages",[]);xt(this,"slideChangedHandlers",[]);xt(this,"blockClickedHandlers",[]);xt(this,"openInEditorHandlers",[]);xt(this,"clientReadyHandlers",[]);xt(this,"openPeekDrawerHandlers",[]);xt(this,"toggleFullscreenHandlers",[]);this.handleWindowMessage=this.handleWindowMessage.bind(this)}attach(i){this.detach(),this.iframe=i,this.isReady=!1,typeof window<"u"&&window.addEventListener("message",this.handleWindowMessage)}detach(){typeof window<"u"&&window.removeEventListener("message",this.handleWindowMessage),this.iframe=null,this.isReady=!1,this.pendingMessages=[]}postMessage(i,e){var o;const n={source:"siyuan-slidev-host",action:i,payload:e};if(!((o=this.iframe)!=null&&o.contentWindow)||!this.isReady){this.pendingMessages.push(n);return}try{this.iframe.contentWindow.postMessage(n,"*")}catch(s){console.warn("[WebSandboxBridge] postMessage error:",s)}}updateSlides(i,e,n,o){this.postMessage("UPDATE_SLIDES",{slides:i,config:e,fullMarkdown:n,customThemeCss:o})}navigatePage(i){this.postMessage("NAVIGATE_PAGE",{pageIndex:i})}highlightElement(i){this.postMessage("HIGHLIGHT_ELEMENT",{targetBlockId:i})}nextStep(){this.postMessage("NEXT_STEP",{})}prevStep(){this.postMessage("PREV_STEP",{})}freezeKeyboardNav(i){this.postMessage("FREEZE_KEYBOARD_NAV",{frozen:i})}onSlideChanged(i){return this.slideChangedHandlers.push(i),()=>{this.slideChangedHandlers=this.slideChangedHandlers.filter(e=>e!==i)}}onBlockClicked(i){return this.blockClickedHandlers.push(i),()=>{this.blockClickedHandlers=this.blockClickedHandlers.filter(e=>e!==i)}}onOpenInEditor(i){return this.openInEditorHandlers.push(i),()=>{this.openInEditorHandlers=this.openInEditorHandlers.filter(e=>e!==i)}}onOpenPeekDrawer(i){return this.openPeekDrawerHandlers.push(i),()=>{this.openPeekDrawerHandlers=this.openPeekDrawerHandlers.filter(e=>e!==i)}}onRequestToggleFullscreen(i){return this.toggleFullscreenHandlers.push(i),()=>{this.toggleFullscreenHandlers=this.toggleFullscreenHandlers.filter(e=>e!==i)}}onClientReady(i){return this.clientReadyHandlers.push(i),()=>{this.clientReadyHandlers=this.clientReadyHandlers.filter(e=>e!==i)}}handleWindowMessage(i){var n;const e=i.data;if(!(!e||e.source!=="siyuan-slidev-client"))switch(e.action){case"CLIENT_READY":for(this.isReady=!0;this.pendingMessages.length>0;){const o=this.pendingMessages.shift();o&&((n=this.iframe)!=null&&n.contentWindow)&&this.iframe.contentWindow.postMessage(o,"*")}for(const o of this.clientReadyHandlers)o();break;case"SLIDE_CHANGED":if(e.payload.currentPage!==void 0)for(const o of this.slideChangedHandlers)o(e.payload.currentPage,e.payload.totalPages||1,e.payload.currentBlockId||"");break;case"BLOCK_CLICKED":if(e.payload.clickedBlockId)for(const o of this.blockClickedHandlers)o(e.payload.clickedBlockId,e.payload.currentPage||1);break;case"OPEN_IN_EDITOR":if(e.payload.blockId||e.payload.clickedBlockId){const o=e.payload.blockId||e.payload.clickedBlockId||"";for(const s of this.openInEditorHandlers)s(o,e.payload.currentPage||1)}break;case"OPEN_PEEK_DRAWER":if(e.payload.peekType){const o=e.payload.blockId||e.payload.url||"",s={peekType:e.payload.peekType,target:o,title:e.payload.title};for(const l of this.openPeekDrawerHandlers)l(s)}break;case"REQUEST_TOGGLE_FULLSCREEN":for(const o of this.toggleFullscreenHandlers)o();break}}}const sa={"snippets/external.ts":`// Inside ./snippets/external.ts
// #region snippet
export function emptyArray<T>(length: number) {
  return Array.from<T>({ length })
}
// #endregion snippet

export function sayHello() {
  console.log('Hello from snippets/external.ts')
}
`},sf=`<script setup lang="ts">
import { computed, useSlots } from 'vue'

const props = defineProps({
  layoutRatio: {
    type: String,
    default: '',
  },
  cols: {
    type: [Number, String],
    default: 0,
  },
})

const slots = useSlots()

const detectedColsCount = computed(() => {
  const explicitCols = Number(props.cols)
  if (explicitCols >= 2 && explicitCols <= 6) return explicitCols
  const r = (props.layoutRatio || '').trim()
  if (r.includes(':')) {
    const parts = r.split(':').map(p => parseFloat(p.trim())).filter(n => !isNaN(n) && n > 0)
    if (parts.length >= 2) return Math.min(parts.length, 6)
  }
  const tokens = r.split(/\\s+/).filter(Boolean)
  if (tokens.length >= 2) return Math.min(tokens.length, 6)
  for (let i = 6; i >= 3; i--) {
    if (slots[\`col-\${i}\`]) return i
  }
  if (slots['col-2'] || slots['right']) return 2
  return 2
})

const gridStyle = computed(() => {
  const r = props.layoutRatio || ''
  if (r) {
    if (r.includes(':')) {
      const parts = r.split(':').map(p => parseFloat(p.trim())).filter(n => !isNaN(n) && n > 0)
      if (parts.length >= 2) {
        return { gridTemplateColumns: parts.map(n => \`\${n}fr\`).join(' ') }
      }
    }
    const tokens = r.split(/\\s+/).filter(Boolean)
    if (tokens.length >= 2) {
      return { gridTemplateColumns: tokens.join(' ') }
    }
  }
  return { gridTemplateColumns: \`repeat(\${detectedColsCount.value}, minmax(0, 1fr))\` }
})
<\/script>

<template>
  <div class="slidev-layout cols-header w-full h-full flex flex-col">
    <div class="header-section mb-4 w-full">
      <slot />
    </div>
    <div class="grid gap-6 flex-1 items-stretch" :style="gridStyle">
      <div v-if="detectedColsCount >= 1" class="col-1 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-1"><slot name="left" /></slot>
      </div>
      <div v-if="detectedColsCount >= 2" class="col-2 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-2"><slot v-if="detectedColsCount === 2" name="right" /></slot>
      </div>
      <div v-if="detectedColsCount >= 3" class="col-3 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-3" />
      </div>
      <div v-if="detectedColsCount >= 4" class="col-4 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-4" />
      </div>
      <div v-if="detectedColsCount >= 5" class="col-5 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-5" />
      </div>
      <div v-if="detectedColsCount >= 6" class="col-6 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-6" />
      </div>
    </div>
  </div>
</template>
`,rf=`<script setup lang="ts">
import { computed } from 'vue'

const props = defineProps({
  layoutRatio: {
    type: String,
    default: '',
  },
})

const gridStyle = computed(() => {
  const r = props.layoutRatio || ''
  if (!r) return {}
  if (r.includes(':')) {
    const parts = r.split(':').map(p => parseFloat(p.trim())).filter(n => !isNaN(n) && n > 0)
    if (parts.length >= 2) {
      return { gridTemplateColumns: parts.map(n => \`\${n}fr\`).join(' ') }
    }
  }
  const tokens = r.split(/\\s+/).filter(Boolean)
  if (tokens.length >= 2) {
    return { gridTemplateColumns: tokens.join(' ') }
  }
  return {}
})
<\/script>

<template>
  <div class="slidev-layout three-cols-header w-full h-full flex flex-col">
    <div class="header-section mb-4 w-full">
      <slot />
    </div>
    <div class="grid gap-6 flex-1 items-stretch" :class="gridStyle.gridTemplateColumns ? '' : 'grid-cols-3'" :style="gridStyle">
      <div class="col-1 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-1" />
      </div>
      <div class="col-2 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-2" />
      </div>
      <div class="col-3 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-3" />
      </div>
    </div>
  </div>
</template>
`,lf=`// Auto-generated by SiYuan Slidev Studio
export default function() {
  if (typeof window === 'undefined') return
  window.addEventListener('click', (e: MouseEvent) => {
    const target = e.target as HTMLElement | null
    if (!target || !target.closest) return

    const refEl = target.closest('[data-ref-id]')
    if (refEl) {
      const blockId = refEl.getAttribute('data-ref-id')
      if (blockId) {
        e.preventDefault()
        e.stopPropagation()
        window.parent.postMessage({
          source: 'siyuan-slidev-client',
          action: 'OPEN_PEEK_DRAWER',
          payload: { peekType: 'siyuan', blockId, title: (refEl.innerText || refEl.title || '').trim() }
        }, '*')
        return
      }
    }

    const linkEl = target.closest('a') as HTMLAnchorElement | null
    if (linkEl) {
      const href = linkEl.getAttribute('href') || ''
      if (href.startsWith('siyuan://blocks/')) {
        e.preventDefault()
        e.stopPropagation()
        const cleanBlockId = href.replace('siyuan://blocks/', '').split('?')[0]
        window.parent.postMessage({
          source: 'siyuan-slidev-client',
          action: 'OPEN_PEEK_DRAWER',
          payload: { peekType: 'siyuan', blockId: cleanBlockId, title: (linkEl.innerText || linkEl.title || '').trim() }
        }, '*')
      } else if (/^https?:\\/\\//i.test(href)) {
        e.preventDefault()
        e.stopPropagation()
        window.parent.postMessage({
          source: 'siyuan-slidev-client',
          action: 'OPEN_PEEK_DRAWER',
          payload: { peekType: 'web', url: href, title: (linkEl.innerText || linkEl.title || '').trim() }
        }, '*')
      }
    }
  }, true)
}
`,af=`${ps}

/* Auto-generated by SiYuan Slidev Studio */
.slidev-ref-tag,
a.slidev-ref-tag {
  display: inline-flex;
  align-items: center;
  background: color-mix(in srgb, var(--slidev-theme-primary, #10b981) 12%, transparent);
  color: var(--slidev-theme-primary, #10b981);
  border-radius: 4px;
  padding: 2px 8px;
  font-size: 0.88em;
  text-decoration: none;
  border: 1px solid color-mix(in srgb, var(--slidev-theme-primary, #10b981) 25%, transparent);
  cursor: pointer;
  transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
  user-select: none;
}

.slidev-ref-tag:hover,
a.slidev-ref-tag:hover {
  background: color-mix(in srgb, var(--slidev-theme-primary, #10b981) 22%, transparent);
  color: var(--slidev-theme-primary, #10b981);
  border-color: color-mix(in srgb, var(--slidev-theme-primary, #10b981) 55%, transparent);
  transform: translateY(-1px);
  box-shadow: 0 2px 8px color-mix(in srgb, var(--slidev-theme-primary, #10b981) 20%, transparent);
}

.slidev-block-ref {
  display: block;
  padding: 10px 14px;
  background: color-mix(in srgb, var(--slidev-theme-primary, #10b981) 8%, transparent);
  border-left: 3px solid var(--slidev-theme-primary, #10b981);
  border-radius: 0 6px 6px 0;
  margin: 8px 0;
  cursor: pointer;
  transition: background 0.2s ease;
}

.slidev-block-ref:hover {
  background: color-mix(in srgb, var(--slidev-theme-primary, #10b981) 15%, transparent);
}

/* 代码块自动换行与无横向滚动条 */
pre,
pre code {
  white-space: pre-wrap !important;
  word-break: break-all !important;
  overflow-wrap: anywhere !important;
  overflow-x: hidden !important;
  overflow-y: auto !important;
  max-width: 100% !important;
  box-sizing: border-box !important;
}

/* 弱提示滚动条样式 */
* {
  scrollbar-width: thin;
}
html:not(.dark) * {
  scrollbar-color: rgba(0, 0, 0, 0.15) transparent;
}
html.dark * {
  scrollbar-color: rgba(255, 255, 255, 0.20) transparent;
}
*::-webkit-scrollbar {
  width: 4px;
  height: 4px;
}
*::-webkit-scrollbar-track {
  background: transparent;
}
html:not(.dark) *::-webkit-scrollbar-thumb {
  background: rgba(0, 0, 0, 0.15);
  border-radius: 2px;
}
html:not(.dark) *:hover::-webkit-scrollbar-thumb,
html:not(.dark) *::-webkit-scrollbar-thumb:hover {
  background: rgba(0, 0, 0, 0.35);
}
html.dark *::-webkit-scrollbar-thumb {
  background: rgba(255, 255, 255, 0.20);
  border-radius: 2px;
}
html.dark *:hover::-webkit-scrollbar-thumb,
html.dark *::-webkit-scrollbar-thumb:hover {
  background: rgba(255, 255, 255, 0.45);
}

/* 多媒体（GIF动图、静态图片、MP4视频）最大化自适应且不超出视口：顶部对齐，横向居中 */
.slidev-layout img,
.slidev-layout video {
  max-width: 100% !important;
  max-height: 100% !important;
  width: auto;
  height: auto;
  object-fit: contain !important;
}
.three-cols-header video,
.two-cols-header video,
.grid-cols-3 video,
.grid-cols-2 video,
.col-1 video,
.col-2 video,
.col-3 video {
  width: auto !important;
  height: auto !important;
  max-width: 100% !important;
  max-height: 100% !important;
  object-fit: contain !important;
  display: block !important;
  margin: 0 auto !important;
}
.slide-list-media {
  display: flex !important;
  flex-direction: column !important;
  align-items: center !important;
  justify-content: flex-start !important;
  margin-top: 4px !important;
  margin-bottom: 4px !important;
  width: 100% !important;
  max-width: 100% !important;
  height: 100% !important;
  max-height: 100% !important;
  flex: 1 1 0% !important;
  overflow: hidden !important;
}
.slide-list-media img,
.slide-list-media video,
.slide-list-media .list-item-gif {
  width: auto !important;
  height: auto !important;
  max-width: 100% !important;
  max-height: 100% !important;
  object-fit: contain !important;
  border-radius: 6px !important;
  box-shadow: 0 3px 12px rgba(0, 0, 0, 0.14) !important;
  display: block !important;
  margin: 0 auto !important;
}
.slide-video-container {
  display: flex !important;
  flex-direction: column !important;
  justify-content: flex-start !important;
  align-items: center !important;
  width: 100% !important;
  max-height: 100% !important;
  margin: 6px 0 !important;
}
.slide-video-player {
  max-width: 100% !important;
  max-height: 100% !important;
  object-fit: contain !important;
  border-radius: 8px !important;
}

/* 两栏与多栏（超级块分栏）布局：紧凑自然行距，子列表保留圆点与层级缩进 */
.cols-header ul,
.three-cols-header ul,
.two-cols-header ul,
.two-cols ul,
.col-1 ul,
.col-2 ul,
.col-3 ul,
.col-4 ul,
.col-5 ul,
.col-6 ul,
.grid-cols-2 ul,
.grid-cols-3 ul {
  list-style: disc !important;
  list-style-type: disc !important;
  padding-left: 1.25em !important;
  margin-left: 0 !important;
  margin-top: 0 !important;
  margin-bottom: 8px !important;
  flex: 0 0 auto !important;
  height: auto !important;
  display: block !important;
}
.cols-header ol,
.three-cols-header ol,
.two-cols-header ol,
.two-cols ol,
.col-1 ol,
.col-2 ol,
.col-3 ol,
.col-4 ol,
.col-5 ol,
.col-6 ol,
.grid-cols-2 ol,
.grid-cols-3 ol {
  list-style: decimal !important;
  list-style-type: decimal !important;
  padding-left: 1.25em !important;
  margin-left: 0 !important;
  margin-top: 0 !important;
  margin-bottom: 8px !important;
  flex: 0 0 auto !important;
  height: auto !important;
  display: block !important;
}
.cols-header li,
.three-cols-header li,
.two-cols-header li,
.two-cols li,
.col-1 li,
.col-2 li,
.col-3 li,
.col-4 li,
.col-5 li,
.col-6 li,
.grid-cols-2 li,
.grid-cols-3 li {
  padding-left: 0.2em !important;
  margin-left: 0 !important;
  margin-bottom: 6px !important;
  flex: 0 0 auto !important;
  height: auto !important;
  display: list-item !important;
  line-height: 1.6 !important;
}
.cols-header ul ul,
.three-cols-header ul ul,
.two-cols-header ul ul,
.two-cols ul ul,
.col-1 ul ul,
.col-2 ul ul,
.col-3 ul ul,
.col-4 ul ul,
.col-5 ul ul,
.col-6 ul ul {
  list-style: circle !important;
  list-style-type: circle !important;
  padding-left: 1.25em !important;
  margin-top: 4px !important;
  margin-bottom: 4px !important;
}

/* 列表项内嵌标题与说明排版 */
.slide-list-item-title,
li > h1,
li > h2,
li > h3,
li > h4,
li > h5,
li > h6 {
  margin-top: 2px !important;
  margin-bottom: 6px !important;
  line-height: 1.35 !important;
  font-weight: 700 !important;
}
li > h1 { font-size: 1.6rem !important; }
li > h2 { font-size: 1.4rem !important; }
li > h3 { font-size: 1.22rem !important; }
li > h4 { font-size: 1.1rem !important; }
.slide-list-item-desc,
li > p {
  margin-top: 4px !important;
  margin-bottom: 6px !important;
  font-size: 1.05rem;
  line-height: 1.55;
  opacity: 0.92;
}
`;function cf(t){var o;const i=[],e=/^[ \t]*<<<[ \t]+(?:@\/|\.\/|)([^\s#]+)(?:#[^\s]+)?/gm;let n;for(;(n=e.exec(t))!==null;){const s=(o=n[1])==null?void 0:o.trim();s&&!i.includes(s)&&i.push(s)}return i}class df{constructor(i){xt(this,"workspacePath");xt(this,"slidesFileName");xt(this,"cliBridge",new Rs);const e=ef();!(i!=null&&i.workspacePath)||i.workspacePath.includes("/data/storage/petal/siyuan-slidev/pro-workspace")?this.workspacePath=e:this.workspacePath=i.workspacePath,this.slidesFileName=(i==null?void 0:i.slidesFileName)||"slides.md"}getWorkspacePath(){return this.workspacePath}getSlidesPath(){return`${this.workspacePath}/${this.slidesFileName}`}generatePackageJson(i="default"){const e={name:"siyuan-slidev-pro-workspace",type:"module",private:!0,scripts:{dev:"slidev --port 3030",build:"slidev build"},dependencies:{"@slidev/cli":"^53.0.0","@slidev/theme-default":"latest"}};return i&&i!=="default"&&(e.dependencies[`@slidev/theme-${i}`]="latest"),JSON.stringify(e,null,2)}buildSlidesMarkdown(i){return this.cliBridge.buildStandardSlidevMarkdown(i)}async scaffold(i,e){const n=this.buildSlidesMarkdown(i),o=this.generatePackageJson(i.config.theme),s=this.getSlidesPath(),l=`${this.workspacePath}/package.json`,r=hs(s),a=hs(l),c=cf(n);c.includes("snippets/external.ts")||c.push("snippets/external.ts");const u=new Map;for(const x of c){const S=sa[x]||`// Auto-generated snippet placeholder for SiYuan Slidev
// #region snippet
// ${x}
// #endregion snippet
`;u.set(x,S)}i.slides.some(x=>{var S;return((S=x.frontmatter)==null?void 0:S.layout)==="cols-header"})&&u.set("layouts/cols-header.vue",sf),i.slides.some(x=>{var S;return((S=x.frontmatter)==null?void 0:S.layout)==="three-cols-header"})&&u.set("layouts/three-cols-header.vue",rf),u.set("setup/root.ts",lf),u.set("styles/index.css",af);const d=$e("fs"),y=$e("path");let f=!1;const v=y!=null&&y.dirname?y.dirname(r):"",k=/^[a-zA-Z]:[/\\]/.test(r)||r.includes("siyuan-slidev-pro");if(d&&y&&k)try{d.existsSync(v)||d.mkdirSync(v,{recursive:!0}),d.writeFileSync(a,o,"utf-8"),d.writeFileSync(r,n,"utf-8");for(const[x,S]of u.entries()){const B=y.join(v,x),A=y.dirname(B);d.existsSync(A)||d.mkdirSync(A,{recursive:!0}),d.existsSync(B)||d.writeFileSync(B,S,"utf-8")}f=!0}catch{}if(!f&&e)try{const x=typeof Blob<"u"?new Blob([n],{type:"text/markdown;charset=utf-8"}):Buffer.from(n,"utf-8"),S=typeof Blob<"u"?new Blob([o],{type:"application/json;charset=utf-8"}):Buffer.from(o,"utf-8");await e(l,!1,S),await e(s,!1,x);for(const[B,A]of u.entries()){const I=`${this.workspacePath}/${B}`,w=typeof Blob<"u"?new Blob([A],{type:"text/plain;charset=utf-8"}):Buffer.from(A,"utf-8");await e(I,!1,w).catch(()=>{})}return{success:!0,slidesPath:s,physicalSlidesPath:r,packageJsonPath:l}}catch(x){return{success:!1,slidesPath:s,physicalSlidesPath:r,packageJsonPath:l,error:String(x)}}return{success:!0,slidesPath:s,physicalSlidesPath:r,packageJsonPath:l}}}class uf{constructor(){xt(this,"mode","web-sandbox");xt(this,"webBridge");xt(this,"cliBridge");xt(this,"nativeBridge");xt(this,"processManager");xt(this,"scaffolder");xt(this,"envDetector");this.webBridge=new Ns,this.cliBridge=new Rs,this.nativeBridge=new nf,this.processManager=new of,this.scaffolder=new df,this.envDetector=new zs}getMode(){return this.mode}setMode(i){this.mode=i}async startProMode(i,e){if(!(await this.envDetector.detect()).hasNode)return{success:!1,url:"",error:"当前系统未检测到 Node.js 环境，无法拉起官方 Slidev CLI，建议继续使用内置高保真引擎"};const o=await this.scaffolder.scaffold(i,e);if(!o.success)return{success:!1,url:"",error:`初始化 Slidev 临时工作空间失败: ${o.error}`};const s=o.physicalSlidesPath||o.slidesPath,l=await this.processManager.startServer(s);return l.success?(this.mode="pro-cli",{success:!0,url:l.url,port:l.port}):{success:!1,url:"",error:l.error}}stopProMode(){this.processManager.stopServer(),this.mode="web-sandbox"}destroy(){this.webBridge.detach(),this.nativeBridge.detach(),this.processManager.stopServer()}}const ff={class:"slidev-icon",style:{fill:"none !important"},viewBox:"0 0 24 24",stroke:"currentColor","stroke-width":"1.75","stroke-linecap":"round","stroke-linejoin":"round","aria-hidden":"true"},pf={key:0},hf={key:1},mf={key:2},gf={key:3},vf={key:4},bf={key:5},yf={key:6},kf={key:7},wf={key:8},xf={key:9},_f={key:10},Sf={key:11},Cf={key:12},$f={key:13},If={key:14},Af={key:15},Bf={key:16},Tf={key:17},Ef={key:18},Mf={key:19},Df={key:20},Lf={key:21},Pf={key:22},Rf={key:23},Of={key:24},zf={key:25},Nf={key:26},Ff={key:27},Hf={key:28},jf={key:29},Uf={key:30},Wf={key:31},Vf={key:32},qf={key:33},Kf={key:34},Gf={key:35},Zf={key:36},Yf={key:37},Jf={key:38},Xf={key:39},Qf={key:40},tp={key:41},ep={key:42},ip={key:43},np={key:44},op={key:45},sp={key:46},rp={key:47},lp={key:48},ap={key:49},cp={key:50},dp={key:51},up={key:52},fp={key:53},pp={key:54},hp={key:55},mp={key:56},gp={key:57},vp={key:58},bp={key:59},yp={key:60},kp={key:61},wp={key:62},xp={key:63},_p=Se({__name:"SlidevIcon",props:{name:{}},setup(t){return(i,e)=>(ot(),st("svg",ff,[t.name==="fullscreen"||t.name==="maximize"?(ot(),st("g",pf,[...e[0]||(e[0]=[p("polyline",{points:"15 3 21 3 21 9"},null,-1),p("polyline",{points:"9 21 3 21 3 15"},null,-1),p("polyline",{points:"21 15 21 21 15 21"},null,-1),p("polyline",{points:"3 9 3 3 9 3"},null,-1)])])):t.name==="minimize"?(ot(),st("g",hf,[...e[1]||(e[1]=[p("polyline",{points:"4 14 10 14 10 20"},null,-1),p("polyline",{points:"20 10 14 10 14 4"},null,-1),p("line",{x1:"14",y1:"10",x2:"21",y2:"3"},null,-1),p("line",{x1:"3",y1:"21",x2:"10",y2:"14"},null,-1)])])):t.name==="close"||t.name==="x"?(ot(),st("g",mf,[...e[2]||(e[2]=[p("line",{x1:"18",y1:"6",x2:"6",y2:"18"},null,-1),p("line",{x1:"6",y1:"6",x2:"18",y2:"18"},null,-1)])])):t.name==="edit"?(ot(),st("g",gf,[...e[3]||(e[3]=[p("path",{d:"M12 20h9"},null,-1),p("path",{d:"M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z"},null,-1)])])):t.name==="eye"?(ot(),st("g",vf,[...e[4]||(e[4]=[p("path",{d:"M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"},null,-1),p("circle",{cx:"12",cy:"12",r:"3"},null,-1)])])):t.name==="external-link"||t.name==="window"?(ot(),st("g",bf,[...e[5]||(e[5]=[p("path",{d:"M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"},null,-1),p("polyline",{points:"15 3 21 3 21 9"},null,-1),p("line",{x1:"10",y1:"14",x2:"21",y2:"3"},null,-1)])])):t.name==="arrow-left"?(ot(),st("g",yf,[...e[6]||(e[6]=[p("line",{x1:"19",y1:"12",x2:"5",y2:"12"},null,-1),p("polyline",{points:"12 19 5 12 12 5"},null,-1)])])):t.name==="arrow-right"?(ot(),st("g",kf,[...e[7]||(e[7]=[p("line",{x1:"5",y1:"12",x2:"19",y2:"12"},null,-1),p("polyline",{points:"12 5 19 12 12 19"},null,-1)])])):t.name==="plus"?(ot(),st("g",wf,[...e[8]||(e[8]=[p("line",{x1:"12",y1:"5",x2:"12",y2:"19"},null,-1),p("line",{x1:"5",y1:"12",x2:"19",y2:"12"},null,-1)])])):t.name==="minus"?(ot(),st("g",xf,[...e[9]||(e[9]=[p("line",{x1:"5",y1:"12",x2:"19",y2:"12"},null,-1)])])):t.name==="split-preview"?(ot(),st("g",_f,[...e[10]||(e[10]=[p("rect",{x:"3",y:"3",width:"18",height:"18",rx:"2"},null,-1),p("path",{d:"M12 3v18"},null,-1)])])):t.name==="import"?(ot(),st("g",Sf,[...e[11]||(e[11]=[p("path",{d:"M4 17v2a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-2"},null,-1),p("polyline",{points:"7 9 12 14 17 9"},null,-1),p("line",{x1:"12",y1:"14",x2:"12",y2:"3"},null,-1)])])):t.name==="presenter"?(ot(),st("g",Cf,[...e[12]||(e[12]=[p("path",{d:"M2 3h20"},null,-1),p("path",{d:"M21 3v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V3"},null,-1),p("path",{d:"m7 21 5-5 5 5"},null,-1)])])):t.name==="video"?(ot(),st("g",$f,[...e[13]||(e[13]=[p("polygon",{points:"23 7 16 12 23 17 23 7"},null,-1),p("rect",{x:"1",y:"5",width:"15",height:"14",rx:"2",ry:"2"},null,-1)])])):t.name==="step"?(ot(),st("g",If,[...e[14]||(e[14]=[p("polygon",{points:"13 2 3 14 12 14 11 22 21 10 12 10 13 2"},null,-1)])])):t.name==="motion"?(ot(),st("g",Af,[...e[15]||(e[15]=[p("path",{d:"M5 12h14"},null,-1),p("path",{d:"m12 5 7 7-7 7"},null,-1),p("path",{d:"M5 6h4"},null,-1),p("path",{d:"M5 18h4"},null,-1)])])):t.name==="columns"?(ot(),st("g",Bf,[...e[16]||(e[16]=[p("rect",{x:"3",y:"3",width:"7",height:"18",rx:"1"},null,-1),p("rect",{x:"14",y:"3",width:"7",height:"18",rx:"1"},null,-1)])])):t.name==="code"?(ot(),st("g",Tf,[...e[17]||(e[17]=[p("polyline",{points:"16 18 22 12 16 6"},null,-1),p("polyline",{points:"8 6 2 12 8 18"},null,-1)])])):t.name==="insert-above"?(ot(),st("g",Ef,[...e[18]||(e[18]=[p("line",{x1:"12",y1:"5",x2:"12",y2:"13"},null,-1),p("line",{x1:"8",y1:"9",x2:"16",y2:"9"},null,-1),p("path",{d:"M4 19h16","stroke-dasharray":"2 2"},null,-1)])])):t.name==="insert-below"?(ot(),st("g",Mf,[...e[19]||(e[19]=[p("path",{d:"M4 5h16","stroke-dasharray":"2 2"},null,-1),p("line",{x1:"12",y1:"11",x2:"12",y2:"19"},null,-1),p("line",{x1:"8",y1:"15",x2:"16",y2:"15"},null,-1)])])):t.name==="broom"?(ot(),st("g",Df,[...e[20]||(e[20]=[p("path",{d:"m18 15-6-6"},null,-1),p("path",{d:"M4 20h16"},null,-1),p("path",{d:"M6 14l8-8a2.8 2.8 0 0 1 4 4l-8 8H6v-4z"},null,-1)])])):t.name==="trash"?(ot(),st("g",Lf,[...e[21]||(e[21]=[p("path",{d:"M3 6h18"},null,-1),p("path",{d:"M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"},null,-1),p("path",{d:"M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"},null,-1)])])):t.name==="ai"||t.name==="sparkles"?(ot(),st("g",Pf,[...e[22]||(e[22]=[p("path",{d:"m12 3-1.9 5.8a2 2 0 0 1-1.3 1.3L3 12l5.8 1.9a2 2 0 0 1 1.3 1.3L12 21l1.9-5.8a2 2 0 0 1 1.3-1.3L21 12l-5.8-1.9a2 2 0 0 1-1.3-1.3L12 3z"},null,-1)])])):t.name==="palette"?(ot(),st("g",Rf,[...e[23]||(e[23]=[ke('<circle cx="13.5" cy="6.5" r=".5" fill="currentColor" data-v-b0848a36></circle><circle cx="17.5" cy="10.5" r=".5" fill="currentColor" data-v-b0848a36></circle><circle cx="8.5" cy="7.5" r=".5" fill="currentColor" data-v-b0848a36></circle><circle cx="6.5" cy="12.5" r=".5" fill="currentColor" data-v-b0848a36></circle><path d="M12 2C6.5 2 2 6.5 2 12s4.5 10 10 10c.9 0 1.5-.7 1.5-1.5 0-.4-.2-.8-.4-1.1-.3-.4-.4-.8-.4-1.4 0-1.1.9-2 2-2h2.3c3.9 0 7-3.1 7-7 0-5-4.5-9-10-9z" data-v-b0848a36></path>',5)])])):t.name==="ratio"?(ot(),st("g",Of,[...e[24]||(e[24]=[p("rect",{x:"2",y:"5",width:"20",height:"14",rx:"2"},null,-1),p("line",{x1:"2",y1:"10",x2:"22",y2:"10","stroke-dasharray":"2 2"},null,-1)])])):t.name==="transition"?(ot(),st("g",zf,[...e[25]||(e[25]=[p("path",{d:"M8 3 4 7l4 4"},null,-1),p("path",{d:"M4 7h16"},null,-1),p("path",{d:"m16 21 4-4-4-4"},null,-1),p("path",{d:"M20 17H4"},null,-1)])])):t.name==="export-html"?(ot(),st("g",Nf,[...e[26]||(e[26]=[p("polyline",{points:"16 16 12 12 8 16"},null,-1),p("line",{x1:"12",y1:"12",x2:"12",y2:"21"},null,-1),p("path",{d:"M20.4 16.3A5 5 0 0 0 18 7h-1.3A8 8 0 0 0 4 12.8a5 5 0 0 0 1.5 9.2"},null,-1)])])):t.name==="export-pdf"?(ot(),st("g",Ff,[...e[27]||(e[27]=[p("polyline",{points:"6 9 6 2 18 2 18 9"},null,-1),p("path",{d:"M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"},null,-1),p("rect",{x:"6",y:"14",width:"12",height:"8"},null,-1)])])):t.name==="pin"?(ot(),st("g",Hf,[...e[28]||(e[28]=[p("line",{x1:"12",y1:"17",x2:"12",y2:"22"},null,-1),p("path",{d:"M5 17h14v-2l-2-2V5l1-1V2H6v2l1 1v8l-2 2v2z"},null,-1)])])):t.name==="refresh"?(ot(),st("g",jf,[...e[29]||(e[29]=[p("path",{d:"M3 12a9 9 0 0 1 9-9 9.75 9.75 0 0 1 6.74 2.74L21 8"},null,-1),p("path",{d:"M21 3v5h-5"},null,-1),p("path",{d:"M21 12a9 9 0 0 1-9 9 9.75 9.75 0 0 1-6.74-2.74L3 16"},null,-1),p("path",{d:"M8 16H3v5"},null,-1)])])):t.name==="outline"?(ot(),st("g",Uf,[...e[30]||(e[30]=[p("line",{x1:"3",y1:"6",x2:"21",y2:"6"},null,-1),p("line",{x1:"3",y1:"12",x2:"21",y2:"12"},null,-1),p("line",{x1:"3",y1:"18",x2:"21",y2:"18"},null,-1)])])):t.name==="chevron-left"?(ot(),st("g",Wf,[...e[31]||(e[31]=[p("polyline",{points:"15 18 9 12 15 6"},null,-1)])])):t.name==="chevron-right"?(ot(),st("g",Vf,[...e[32]||(e[32]=[p("polyline",{points:"9 18 15 12 9 6"},null,-1)])])):t.name==="copy"?(ot(),st("g",qf,[...e[33]||(e[33]=[p("rect",{x:"9",y:"9",width:"13",height:"13",rx:"2",ry:"2"},null,-1),p("path",{d:"M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"},null,-1)])])):t.name==="image"?(ot(),st("g",Kf,[...e[34]||(e[34]=[p("rect",{x:"3",y:"3",width:"18",height:"18",rx:"2",ry:"2"},null,-1),p("circle",{cx:"8.5",cy:"8.5",r:"1.5"},null,-1),p("polyline",{points:"21 15 16 10 5 21"},null,-1)])])):t.name==="search"?(ot(),st("g",Gf,[...e[35]||(e[35]=[p("circle",{cx:"11",cy:"11",r:"7"},null,-1),p("line",{x1:"21",y1:"21",x2:"16.65",y2:"16.65"},null,-1)])])):t.name==="settings"||t.name==="gear"?(ot(),st("g",Zf,[...e[36]||(e[36]=[p("circle",{cx:"12",cy:"12",r:"3"},null,-1),p("path",{d:"M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 1 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 1 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 1 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 1 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"},null,-1)])])):t.name==="notes"||t.name==="file-text"?(ot(),st("g",Yf,[...e[37]||(e[37]=[ke('<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" data-v-b0848a36></path><polyline points="14 2 14 8 20 8" data-v-b0848a36></polyline><line x1="16" y1="13" x2="8" y2="13" data-v-b0848a36></line><line x1="16" y1="17" x2="8" y2="17" data-v-b0848a36></line><line x1="10" y1="9" x2="8" y2="9" data-v-b0848a36></line>',5)])])):t.name==="focus"||t.name==="target"?(ot(),st("g",Jf,[...e[38]||(e[38]=[p("circle",{cx:"12",cy:"12",r:"3",fill:"currentColor"},null,-1),p("path",{d:"M12 2v4M12 18v4M2 12h4M18 12h4",stroke:"currentColor","stroke-width":"2","stroke-linecap":"round"},null,-1),p("circle",{cx:"12",cy:"12",r:"7",fill:"none",stroke:"currentColor","stroke-width":"1.8"},null,-1)])])):t.name==="layout-cover"||t.name==="cover"?(ot(),st("g",Xf,[...e[39]||(e[39]=[p("rect",{x:"2",y:"4",width:"20",height:"16",rx:"2"},null,-1),p("line",{x1:"9",y1:"8",x2:"15",y2:"8"},null,-1),p("line",{x1:"5.5",y1:"11.5",x2:"18.5",y2:"11.5"},null,-1),p("line",{x1:"7.5",y1:"15",x2:"16.5",y2:"15"},null,-1)])])):t.name==="layout-default"||t.name==="default"?(ot(),st("g",Qf,[...e[40]||(e[40]=[ke('<rect x="2" y="4" width="20" height="16" rx="2" data-v-b0848a36></rect><line x1="5" y1="8" x2="11.5" y2="8" data-v-b0848a36></line><line x1="5" y1="11.5" x2="19" y2="11.5" data-v-b0848a36></line><line x1="5" y1="14.5" x2="19" y2="14.5" data-v-b0848a36></line><line x1="5" y1="17.5" x2="13.5" y2="17.5" data-v-b0848a36></line>',5)])])):t.name==="layout-two-cols"||t.name==="two-cols"?(ot(),st("g",tp,[...e[41]||(e[41]=[ke('<rect x="2" y="4" width="20" height="16" rx="2" data-v-b0848a36></rect><line x1="12" y1="4" x2="12" y2="20" stroke-dasharray="2 1.5" data-v-b0848a36></line><line x1="5" y1="8" x2="9.5" y2="8" data-v-b0848a36></line><line x1="5" y1="11.5" x2="9.5" y2="11.5" data-v-b0848a36></line><line x1="5" y1="15" x2="8" y2="15" data-v-b0848a36></line><line x1="14.5" y1="8" x2="19" y2="8" data-v-b0848a36></line><line x1="14.5" y1="11.5" x2="19" y2="11.5" data-v-b0848a36></line><line x1="14.5" y1="15" x2="17.5" y2="15" data-v-b0848a36></line>',8)])])):t.name==="layout-two-cols-header"||t.name==="two-cols-header"?(ot(),st("g",ep,[...e[42]||(e[42]=[ke('<rect x="2" y="4" width="20" height="16" rx="2" data-v-b0848a36></rect><line x1="5" y1="7.5" x2="13" y2="7.5" data-v-b0848a36></line><line x1="12" y1="10.5" x2="12" y2="18.5" stroke-dasharray="1.5 1.5" data-v-b0848a36></line><line x1="5" y1="12" x2="9.5" y2="12" data-v-b0848a36></line><line x1="5" y1="15.5" x2="8.5" y2="15.5" data-v-b0848a36></line><line x1="14.5" y1="12" x2="19" y2="12" data-v-b0848a36></line><line x1="14.5" y1="15.5" x2="18" y2="15.5" data-v-b0848a36></line>',7)])])):t.name==="layout-cols-header"||t.name==="cols-header"||t.name==="layout-three-cols-header"||t.name==="three-cols-header"?(ot(),st("g",ip,[...e[43]||(e[43]=[ke('<rect x="2" y="4" width="20" height="16" rx="2" data-v-b0848a36></rect><line x1="5" y1="7.5" x2="13" y2="7.5" data-v-b0848a36></line><line x1="9.3" y1="10.5" x2="9.3" y2="18.5" stroke-dasharray="1.5 1.5" data-v-b0848a36></line><line x1="14.7" y1="10.5" x2="14.7" y2="18.5" stroke-dasharray="1.5 1.5" data-v-b0848a36></line><line x1="4.5" y1="12" x2="7.5" y2="12" data-v-b0848a36></line><line x1="4.5" y1="15.5" x2="7" y2="15.5" data-v-b0848a36></line><line x1="10.5" y1="12" x2="13.5" y2="12" data-v-b0848a36></line><line x1="10.5" y1="15.5" x2="13.5" y2="15.5" data-v-b0848a36></line><line x1="16" y1="12" x2="19.5" y2="12" data-v-b0848a36></line><line x1="16" y1="15.5" x2="18.5" y2="15.5" data-v-b0848a36></line>',10)])])):t.name==="layout-image-right"||t.name==="image-right"?(ot(),st("g",np,[...e[44]||(e[44]=[ke('<rect x="2" y="4" width="20" height="16" rx="2" data-v-b0848a36></rect><line x1="12" y1="4" x2="12" y2="20" data-v-b0848a36></line><line x1="4.5" y1="8" x2="9.5" y2="8" data-v-b0848a36></line><line x1="4.5" y1="11.5" x2="10" y2="11.5" data-v-b0848a36></line><line x1="4.5" y1="14.5" x2="8" y2="14.5" data-v-b0848a36></line><circle cx="15.5" cy="8.5" r="1.2" data-v-b0848a36></circle><polyline points="13 17 15.5 13 18 16 19.5 14" data-v-b0848a36></polyline>',7)])])):t.name==="layout-image-left"||t.name==="image-left"?(ot(),st("g",op,[...e[45]||(e[45]=[ke('<rect x="2" y="4" width="20" height="16" rx="2" data-v-b0848a36></rect><line x1="12" y1="4" x2="12" y2="20" data-v-b0848a36></line><circle cx="6" cy="8.5" r="1.2" data-v-b0848a36></circle><polyline points="3.5 17 6 13 8.5 16 10 14" data-v-b0848a36></polyline><line x1="14.5" y1="8" x2="19.5" y2="8" data-v-b0848a36></line><line x1="14.5" y1="11.5" x2="20" y2="11.5" data-v-b0848a36></line><line x1="14.5" y1="14.5" x2="18" y2="14.5" data-v-b0848a36></line>',7)])])):t.name==="layout-center"||t.name==="center"?(ot(),st("g",sp,[...e[46]||(e[46]=[p("rect",{x:"2",y:"4",width:"20",height:"16",rx:"2"},null,-1),p("line",{x1:"6.5",y1:"9",x2:"17.5",y2:"9"},null,-1),p("line",{x1:"5",y1:"12",x2:"19",y2:"12"},null,-1),p("line",{x1:"8",y1:"15",x2:"16",y2:"15"},null,-1)])])):t.name==="layout-fact"||t.name==="fact"?(ot(),st("g",rp,[...e[47]||(e[47]=[ke('<rect x="2" y="4" width="20" height="16" rx="2" data-v-b0848a36></rect><circle cx="8" cy="9" r="1.5" data-v-b0848a36></circle><line x1="14" y1="8" x2="9" y2="14" data-v-b0848a36></line><circle cx="15" cy="13" r="1.5" data-v-b0848a36></circle><line x1="6.5" y1="17" x2="17.5" y2="17" data-v-b0848a36></line>',5)])])):t.name==="layout-intro"||t.name==="intro"?(ot(),st("g",lp,[...e[48]||(e[48]=[ke('<rect x="2" y="4" width="20" height="16" rx="2" data-v-b0848a36></rect><circle cx="7.5" cy="9.5" r="2" data-v-b0848a36></circle><path d="M4.5 16.5c0-1.8 1.3-3 3-3s3 1.2 3 3" data-v-b0848a36></path><line x1="13" y1="9" x2="18.5" y2="9" data-v-b0848a36></line><line x1="13" y1="12.5" x2="19.5" y2="12.5" data-v-b0848a36></line><line x1="13" y1="15.5" x2="17" y2="15.5" data-v-b0848a36></line>',6)])])):t.name==="layout-quote"||t.name==="quote"?(ot(),st("g",ap,[...e[49]||(e[49]=[ke('<rect x="2" y="4" width="20" height="16" rx="2" data-v-b0848a36></rect><path d="M6 7.5h2v2H6.5c0 1.2-.4 2-1.5 2.5" data-v-b0848a36></path><path d="M9.5 7.5h2v2H10c0 1.2-.4 2-1.5 2.5" data-v-b0848a36></path><line x1="6" y1="13.5" x2="18" y2="13.5" data-v-b0848a36></line><line x1="12.5" y1="16.5" x2="17.5" y2="16.5" data-v-b0848a36></line>',5)])])):t.name==="desktop"||t.name==="monitor"?(ot(),st("g",cp,[...e[50]||(e[50]=[p("rect",{x:"2",y:"3",width:"20",height:"14",rx:"2"},null,-1),p("line",{x1:"8",y1:"21",x2:"16",y2:"21"},null,-1),p("line",{x1:"12",y1:"17",x2:"12",y2:"21"},null,-1)])])):t.name==="mobile"||t.name==="smartphone"||t.name==="phone"?(ot(),st("g",dp,[...e[51]||(e[51]=[p("rect",{x:"5",y:"2",width:"14",height:"20",rx:"2",ry:"2"},null,-1),p("line",{x1:"12",y1:"18",x2:"12.01",y2:"18","stroke-width":"2","stroke-linecap":"round"},null,-1)])])):t.name==="type"||t.name==="heading"?(ot(),st("g",up,[...e[52]||(e[52]=[p("polyline",{points:"4 7 4 4 20 4 20 7"},null,-1),p("line",{x1:"9",y1:"20",x2:"15",y2:"20"},null,-1),p("line",{x1:"12",y1:"4",x2:"12",y2:"20"},null,-1)])])):t.name==="reset"||t.name==="undo"?(ot(),st("g",fp,[...e[53]||(e[53]=[p("path",{d:"M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8"},null,-1),p("polyline",{points:"3 3 3 8 8 8"},null,-1)])])):t.name==="repeat"||t.name==="loop"?(ot(),st("g",pp,[...e[54]||(e[54]=[p("path",{d:"m17 1 4 4-4 4"},null,-1),p("path",{d:"M3 11V9a4 4 0 0 1 4-4h14"},null,-1),p("path",{d:"m7 23-4-4 4-4"},null,-1),p("path",{d:"M21 13v2a4 4 0 0 1-4 4H3"},null,-1)])])):t.name==="volume-x"||t.name==="mute"?(ot(),st("g",hp,[...e[55]||(e[55]=[p("polygon",{points:"11 5 6 9 2 9 2 15 6 15 11 19 11 5"},null,-1),p("line",{x1:"22",y1:"9",x2:"16",y2:"15"},null,-1),p("line",{x1:"16",y1:"9",x2:"22",y2:"15"},null,-1)])])):t.name==="sliders"||t.name==="controls"?(ot(),st("g",mp,[...e[56]||(e[56]=[ke('<line x1="4" y1="21" x2="4" y2="14" data-v-b0848a36></line><line x1="4" y1="10" x2="4" y2="3" data-v-b0848a36></line><line x1="12" y1="21" x2="12" y2="12" data-v-b0848a36></line><line x1="12" y1="8" x2="12" y2="3" data-v-b0848a36></line><line x1="20" y1="21" x2="20" y2="16" data-v-b0848a36></line><line x1="20" y1="12" x2="20" y2="3" data-v-b0848a36></line><line x1="1" y1="14" x2="7" y2="14" data-v-b0848a36></line><line x1="9" y1="8" x2="15" y2="8" data-v-b0848a36></line><line x1="17" y1="16" x2="23" y2="16" data-v-b0848a36></line>',9)])])):t.name==="package"||t.name==="zip"||t.name==="archive"?(ot(),st("g",gp,[...e[57]||(e[57]=[p("line",{x1:"16.5",y1:"9.4",x2:"7.5",y2:"4.21"},null,-1),p("path",{d:"M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"},null,-1),p("polyline",{points:"3.27 6.96 12 12.01 20.73 6.96"},null,-1),p("line",{x1:"12",y1:"22.08",x2:"12",y2:"12"},null,-1)])])):t.name==="folder"?(ot(),st("g",vp,[...e[58]||(e[58]=[p("path",{d:"M4 20h16a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2h-7.93a2 2 0 0 1-1.66-.9l-.82-1.2A2 2 0 0 0 7.93 3H4a2 2 0 0 0-2 2v13c0 1.1.9 2 2 2Z"},null,-1)])])):t.name==="rocket"?(ot(),st("g",bp,[...e[59]||(e[59]=[p("path",{d:"M4.5 16.5c-1.5 1.26-2 5-2 5s3.74-.5 5-2c.71-.84.7-2.13-.09-2.91a2.18 2.18 0 0 0-2.91-.09z"},null,-1),p("path",{d:"m12 15-3-3a22 22 0 0 1 2-3.95A12.88 12.88 0 0 1 22 2c0 2.72-.78 7.5-6 11a22.35 22.35 0 0 1-4 2z"},null,-1),p("path",{d:"M9 12H4s.55-3.03 2-4c1.62-1.08 5 0 5 0"},null,-1),p("path",{d:"M12 15v5s3.03-.55 4-2c1.08-1.62 0-5 0-5"},null,-1)])])):t.name==="wand"||t.name==="magic"?(ot(),st("g",yp,[...e[60]||(e[60]=[p("path",{d:"m19 2 2 2-6 6-2-2Z"},null,-1),p("path",{d:"m13 8 2 2"},null,-1),p("path",{d:"m3 21 9-9"},null,-1)])])):t.name==="image-left"?(ot(),st("g",kp,[...e[61]||(e[61]=[ke('<rect x="2" y="4" width="20" height="16" rx="2" data-v-b0848a36></rect><rect x="4" y="6" width="6" height="12" rx="1" data-v-b0848a36></rect><line x1="13" y1="8" x2="19" y2="8" data-v-b0848a36></line><line x1="13" y1="12" x2="19" y2="12" data-v-b0848a36></line><line x1="13" y1="16" x2="17" y2="16" data-v-b0848a36></line>',5)])])):t.name==="image-right"?(ot(),st("g",wp,[...e[62]||(e[62]=[ke('<rect x="2" y="4" width="20" height="16" rx="2" data-v-b0848a36></rect><rect x="14" y="6" width="6" height="12" rx="1" data-v-b0848a36></rect><line x1="5" y1="8" x2="11" y2="8" data-v-b0848a36></line><line x1="5" y1="12" x2="11" y2="12" data-v-b0848a36></line><line x1="5" y1="16" x2="9" y2="16" data-v-b0848a36></line>',5)])])):(ot(),st("g",xp,[...e[63]||(e[63]=[p("rect",{x:"2",y:"3",width:"20",height:"14",rx:"2"},null,-1),p("line",{x1:"8",y1:"21",x2:"16",y2:"21"},null,-1),p("line",{x1:"12",y1:"17",x2:"12",y2:"21"},null,-1)])]))]))}}),ze=(t,i)=>{const e=t.__vccOpts||t;for(const[n,o]of i)e[n]=o;return e},ft=ze(_p,[["__scopeId","data-v-b0848a36"]]);function ee(t,i){var o;if(typeof document>"u"||!t)return;const e=(o=globalThis.CSS)!=null&&o.escape?globalThis.CSS.escape(t):t.replace(/"/g,'\\"'),n=document.querySelectorAll(`[data-node-id="${e}"]`);!n||n.length===0||n.forEach(s=>{for(const[l,r]of Object.entries(i))r!=null&&r!==""?s.setAttribute(l,String(r)):s.removeAttribute(l)})}function Sp(t){if(typeof document>"u")return;const i=`.protyle-wysiwyg [${mt}], .protyle-wysiwyg [${Kt}], .protyle-wysiwyg [custom-slidev-layout], .protyle-wysiwyg [custom-slidev-role]`,e=document.querySelectorAll(i);!e||e.length===0||e.forEach(n=>{const o=n.getAttribute("data-node-id");if(!o){n.removeAttribute(mt),n.removeAttribute("custom-slidev-layout"),n.removeAttribute(Kt),n.removeAttribute("custom-slidev-role");return}const s=t.get(o),l=(s==null?void 0:s[mt])||(s==null?void 0:s["custom-slidev-layout"])||"",r=n.getAttribute(mt)||n.getAttribute("custom-slidev-layout");r&&r!==l&&(l?n.setAttribute(mt,l):(n.removeAttribute(mt),n.removeAttribute("custom-slidev-layout")));const a=(s==null?void 0:s[Kt])||(s==null?void 0:s["custom-slidev-role"])||"",c=n.getAttribute(Kt)||n.getAttribute("custom-slidev-role");c&&c!==a&&(a?n.setAttribute(Kt,a):(n.removeAttribute(Kt),n.removeAttribute("custom-slidev-role")))})}const Cp={class:"spm-layout-picker"},$p={class:"spm-layout-picker__grid"},Ip=["title","onClick"],Ap={class:"spm-layout-icon"},Bp={class:"spm-layout-label"},Tp=Se({__name:"LayoutPicker",props:{modelValue:{}},emits:["update:modelValue","change"],setup(t,{emit:i}){const e=t,n=i,o=[{name:"cover",label:"封面",desc:"大标题与副标题封面页"},{name:"default",label:"标准",desc:"标题在上方，内容在下方"},{name:"two-cols",label:"双栏",desc:"左右双栏对比展示"},{name:"cols-header",label:"表头多栏",desc:"顶部通栏标题，下方自适应 2~N 栏"},{name:"image-right",label:"图右",desc:"左侧为内容，右侧全屏背景图"},{name:"image-left",label:"图左",desc:"左侧全屏背景图，右侧为内容"},{name:"center",label:"居中",desc:"内容全屏垂直水平居中"},{name:"fact",label:"大字报",desc:"核心数据或指标突出展示"},{name:"intro",label:"介绍",desc:"演讲者自我介绍或章节导览"},{name:"quote",label:"引言",desc:"名人名言与强调段落"}];function s(r){return e.modelValue===r||r==="cols-header"&&(e.modelValue==="two-cols-header"||e.modelValue==="three-cols-header")}function l(r){n("update:modelValue",r),n("change",r)}return(r,a)=>(ot(),st("div",Cp,[a[0]||(a[0]=p("div",{class:"spm-layout-picker__header"},"选择页面版式",-1)),p("div",$p,[(ot(),st(Gt,null,xe(o,c=>p("div",{key:c.name,class:It(["spm-layout-item",{active:s(c.name)}]),title:c.desc,onClick:u=>l(c.name)},[p("div",Ap,[at(ft,{name:"layout-"+c.name},null,8,["name"])]),p("span",Bp,St(c.label),1)],10,Ip)),64))])]))}}),ra=ze(Tp,[["__scopeId","data-v-da9222a6"]]),Ep={key:0,class:"spm-transition-selector__header"},Mp={class:"spm-transition-list"},Dp=["onClick"],Lp={class:"spm-transition-meta"},Pp={class:"spm-transition-label"},Rp={class:"spm-transition-name"},Op={class:"spm-transition-preview-box"},zp=Se({__name:"TransitionSelector",props:{modelValue:{},hideHeader:{type:Boolean},title:{}},emits:["update:modelValue","change"],setup(t,{emit:i}){const e=i,n=[{name:"slide-left",label:"向左滑入",desc:"向左滑入 (slide-left)：页面从右侧向左平滑推入，最通用标准的横向幻灯片动效"},{name:"slide-right",label:"向右滑入",desc:"向右滑入 (slide-right)：页面从左侧向右平滑推入，适合倒序回退或逆向章节叙述"},{name:"slide-up",label:"向上推入",desc:"向上推入 (slide-up)：页面从底部向上平滑推入，适合纵向展开或纵深层级展示"},{name:"fade",label:"淡入淡出",desc:"淡入淡出 (fade)：透明度平滑渐变过度，典雅柔和，适合学术长篇与沉浸叙事"},{name:"zoom",label:"缩放进入",desc:"缩放进入 (zoom)：页面由中心向外平滑放大，富有动感冲击力，适合聚焦重点"}];function o(s){e("update:modelValue",s),e("change",s)}return(s,l)=>(ot(),st("div",{class:It(["spm-transition-selector",{"spm-transition-selector--no-header":t.hideHeader}])},[t.hideHeader?Rt("",!0):(ot(),st("div",Ep,St(t.title||"转场动效"),1)),p("div",Mp,[(ot(),st(Gt,null,xe(n,r=>p("div",{key:r.name,class:It(["spm-transition-item",{active:t.modelValue===r.name}]),onClick:a=>o(r.name)},[p("div",Lp,[p("span",Pp,St(r.label),1),p("span",Rp,"("+St(r.name)+")",1)]),p("div",Op,[p("div",{class:It(["spm-anim-cube","anim-"+r.name])},null,2)])],10,Dp)),64))])],2))}}),Fs=ze(zp,[["__scopeId","data-v-b0aa61ff"]]),Np={class:"spm-divider-popover"},Fp={class:"spm-divider-popover__title"},Hp={class:"spm-form-item"},jp={class:"spm-popover-footer"},Up={class:"spm-save-hint"},Wp=Se({__name:"QuickDividerPopover",props:{blockId:{},initialAttrs:{}},emits:["close","updated"],setup(t,{emit:i}){var g,d,y;const e=t,n=i,o=gt(((g=e.initialAttrs)==null?void 0:g[mt])||"default"),s=gt(((d=e.initialAttrs)==null?void 0:d[Qt])||"slide-left"),l=gt(((y=e.initialAttrs)==null?void 0:y[Ut])||""),r=gt("");Li(()=>e.initialAttrs,f=>{o.value=(f==null?void 0:f[mt])||"default",s.value=(f==null?void 0:f[Qt])||"slide-left",l.value=(f==null?void 0:f[Ut])||""},{deep:!0});async function a(f,v){if(e.blockId){r.value="正在同步...",Pt.setBlockAttrOverride(e.blockId,{[f]:v}),ee(e.blockId,{[f]:v});try{await Dt(e.blockId,{[f]:v}),r.value="已同步至块属性",n("updated",{[f]:v}),setTimeout(()=>{r.value=""},1500)}catch{r.value="同步失败"}}}function c(f){a(mt,f)}function u(f){a(Qt,f)}function m(){a(Ut,l.value.trim())}return(f,v)=>(ot(),st("div",Np,[p("div",Fp,[v[4]||(v[4]=p("span",null,"幻灯片页面设置",-1)),p("button",{class:"spm-close-btn",onClick:v[0]||(v[0]=k=>n("close"))},"✕")]),at(ra,{modelValue:o.value,"onUpdate:modelValue":v[1]||(v[1]=k=>o.value=k),onChange:c},null,8,["modelValue"]),at(Fs,{modelValue:s.value,"onUpdate:modelValue":v[2]||(v[2]=k=>s.value=k),onChange:u},null,8,["modelValue"]),p("div",Hp,[v[5]||(v[5]=p("label",{class:"spm-form-label"},"页面背景",-1)),Te(p("input",{"onUpdate:modelValue":v[3]||(v[3]=k=>l.value=k),class:"spm-input",placeholder:"assets/bg.jpg 或颜色值 (#1e1e24)",onBlur:m},null,544),[[bo,l.value]])]),p("div",jp,[p("span",Up,St(r.value),1)])]))}}),Vp=ze(Wp,[["__scopeId","data-v-e4871368"]]),qp={class:"spm-slide-inspector"},Kp={class:"spm-inspector-header"},Gp={class:"spm-inspector-list"},Zp=["onClick"],Yp={class:"spm-card-top"},Jp={class:"spm-card-badge"},Xp={class:"spm-card-layout"},Qp=["onClick"],th={class:"spm-card-preview"},eh={key:0,class:"spm-card-notes",title:"演讲备忘录"},ih={class:"spm-inspector-modal-content"},nh=Se({__name:"SlideInspector",props:{slides:{},currentActivePage:{}},emits:["navigate","refresh"],setup(t,{emit:i}){const e=i,n=gt(null);function o(c){n.value=c}function s(c){const u={};return c.frontmatter.layout&&(u[mt]=c.frontmatter.layout),c.frontmatter.transition&&(u[Qt]=c.frontmatter.transition),c.frontmatter.background&&(u[Ut]=c.frontmatter.background),c.notes&&(u[Wi]=c.notes),u}function l(c){n.value&&(c[mt]&&(n.value.frontmatter.layout=c[mt]),c[Qt]&&(n.value.frontmatter.transition=c[Qt]),c[Ut]&&(n.value.frontmatter.background=c[Ut]),c[Wi]&&(n.value.notes=c[Wi]),e("refresh"))}function r(c){e("navigate",c)}function a(c){if(!c.blocks||c.blocks.length===0)return"(空白页)";const u=c.blocks[0],m=u.content||u.rawMarkdown||"";return m.slice(0,40)+(m.length>40?"...":"")}return(c,u)=>(ot(),st("div",qp,[p("div",Kp,[p("span",null,"幻灯片大纲 ("+St(t.slides.length)+" 页)",1)]),p("div",Gp,[(ot(!0),st(Gt,null,xe(t.slides,m=>(ot(),st("div",{key:m.pageIndex,class:It(["spm-card",{active:t.currentActivePage===m.pageIndex}]),onClick:g=>r(m.pageIndex)},[p("div",Yp,[p("span",Jp,"P"+St(m.pageIndex),1),p("span",Xp,St(m.frontmatter.layout||"default"),1),p("button",{class:"spm-card-btn-edit",title:"配置此页版式与属性",onClick:Me(g=>o(m),["stop"])},[at(ft,{name:"settings"})],8,Qp)]),p("div",th,St(a(m)),1),m.notes?(ot(),st("div",eh,[at(ft,{name:"notes",style:{"font-size":"11px","margin-right":"3px"}}),p("span",null,St(m.notes),1)])):Rt("",!0)],10,Zp))),128))]),n.value?(ot(),st("div",{key:0,class:"spm-inspector-modal-mask",onClick:u[1]||(u[1]=Me(m=>n.value=null,["self"]))},[p("div",ih,[at(Vp,{"block-id":n.value.startBlockId,"initial-attrs":s(n.value),onClose:u[0]||(u[0]=m=>n.value=null),onUpdated:l},null,8,["block-id","initial-attrs"])])])):Rt("",!0)]))}}),oh=ze(nh,[["__scopeId","data-v-68b25edd"]]),sh={class:"spm-immersion-header"},rh={class:"spm-immersion-header__left"},lh={class:"spm-immersion-title"},ah={class:"spm-immersion-header__center"},ch={class:"spm-immersion-header__actions"},dh=["aria-label"],uh={class:"spm-immersion-body"},fh=Se({__name:"ImmersionDrawerContainer",props:{visible:{type:Boolean,default:!1},isMaximized:{type:Boolean,default:!1},title:{default:"速览"},closeOnClickMask:{type:Boolean,default:!0}},emits:["update:visible","update:isMaximized","close","toggle-maximize"],setup(t,{emit:i}){const e=t,n=i;function o(){n("update:visible",!1),n("close")}function s(){e.closeOnClickMask&&o()}function l(){n("update:isMaximized",!e.isMaximized),n("toggle-maximize")}function r(a){(a.key===" "||a.key==="ArrowLeft"||a.key==="ArrowRight"||a.key==="PageUp"||a.key==="PageDown")&&a.stopPropagation(),a.key==="Escape"&&(a.preventDefault(),a.stopPropagation(),o())}return(a,c)=>Te((ot(),st("div",{class:It(["spm-immersion-container",{"is-maximized":t.isMaximized}]),onKeydown:Me(r,["stop"])},[p("div",{class:"spm-immersion-mask",onClick:s}),p("div",{class:It(["spm-immersion-drawer",{"is-maximized":t.isMaximized}])},[p("div",sh,[p("div",rh,[qn(a.$slots,"header-left",{},()=>[p("span",lh,St(t.title),1)])]),p("div",ah,[qn(a.$slots,"header-center",{},void 0)]),p("div",ch,[qn(a.$slots,"header-actions",{},void 0),p("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":t.isMaximized?"还原抽屉宽度 (70%)":"最大化填满视口 (100%)",onClick:l},[at(ft,{name:t.isMaximized?"minimize":"maximize"},null,8,["name"])],8,dh),p("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"关闭速览 (ESC)",onClick:o},[at(ft,{name:"close"})])])]),p("div",uh,[qn(a.$slots,"default",{},void 0)])],2)],34)),[[Gl,t.visible]])}}),ph=ze(fh,[["__scopeId","data-v-3f1665db"]]),hh={class:"spm-protyle-drawer"},mh={class:"spm-protyle-drawer__subbar"},gh={class:"spm-protyle-drawer__nav"},vh=["title"],bh={class:"spm-protyle-drawer__actions"},yh=["aria-label"],kh=["aria-label"],wh=Se({__name:"ProtylePeekDrawer",props:{blockId:{},title:{},plugin:{}},emits:["external-jump"],setup(t,{emit:i}){const e=i,n=t,o=gt(n.blockId),s=gt(n.title||""),l=gt(!1),r=gt(!0),a=gt(!1),c=gt(""),u=hi,m=gt([]),g=gt(null);let d=null;Li(()=>n.blockId,w=>{w&&w!==o.value&&(o.value=w,s.value=n.title||"",m.value=[],f(w))}),Rn(()=>{o.value&&f(o.value)}),Bs(()=>{v()});async function y(w){try{const z=await wn(`SELECT id, root_id, type, content FROM blocks WHERE id = '${w}' LIMIT 1`);if(Array.isArray(z)&&z.length>0){const O=z[0];c.value=O.root_id||"";const H=O.id===O.root_id||O.type==="d";a.value=H,r.value=!H,!s.value&&O.content&&(s.value=O.content.trim().slice(0,30));return}}catch(z){console.warn("[ProtylePeekDrawer] detectBlockType query failed:",z)}a.value=!1,r.value=!0}async function f(w,z){if(!g.value||!w)return;v(),await y(w),typeof z=="boolean"&&(r.value=!a.value&&z);let O,H;r.value&&!a.value?(O=["cb-get-all","cb-get-hl","cb-get-focus"],H={background:!1,title:!1,gutter:!0,breadcrumbDocName:!0,scroll:!0}):(O=["cb-get-context","cb-get-hl"],H={background:!0,title:!0,gutter:!0,breadcrumbDocName:!0,scroll:!0});try{d=new ht.Protyle(n.plugin.app,g.value,{blockId:w,action:O,render:H}),!l.value&&d&&typeof d.disable=="function"&&d.disable()}catch(et){console.error("[ProtylePeekDrawer] Failed to instantiate Protyle:",et)}}function v(){if(d){try{typeof d.destroy=="function"&&d.destroy()}catch(w){console.warn("[ProtylePeekDrawer] Error destroying protyle:",w)}d=null}g.value&&(g.value.innerHTML="")}function k(){a.value||(r.value=!r.value,f(o.value,r.value))}function x(){l.value=!l.value,d&&(l.value?(typeof d.enable=="function"&&d.enable(),typeof d.focus=="function"&&d.focus()):typeof d.disable=="function"&&d.disable())}function S(){if(o.value)try{ht.openWindow({doc:{id:o.value},alwaysOnTop:!0})}catch(w){console.warn("[ProtylePeekDrawer] openWindow failed:",w)}}function B(){var O;if(!o.value)return;const w=Do(),z=Jl(w.webServeUrl,o.value,{focus:!a.value});if(typeof window<"u"){const H=$e("electron");(O=H==null?void 0:H.shell)!=null&&O.openExternal?H.shell.openExternal(z).catch(()=>{window.open(z,"_blank")}):window.open(z,"_blank")}e("external-jump",z)}function A(){if(m.value.length>0){const w=m.value.pop();w&&(o.value=w.blockId,s.value=w.title,r.value=w.isFocusMode,a.value=w.isDoc,f(w.blockId,w.isFocusMode))}}function I(w){const z=w.target;if(!z)return;const O=z.closest('[data-type="block-ref"]');if(O){const et=O.getAttribute("data-id");if(et&&et!==o.value){w.preventDefault(),w.stopPropagation(),m.value.push({blockId:o.value,title:s.value||o.value,isFocusMode:r.value,isDoc:a.value}),o.value=et,s.value=O.innerText.trim()||et,f(et);return}}const H=z.closest("a");if(H&&H.href&&H.href.startsWith("siyuan://blocks/")){w.preventDefault(),w.stopPropagation();const et=H.href.replace("siyuan://blocks/","").split("?")[0];et&&et!==o.value&&(m.value.push({blockId:o.value,title:s.value||o.value,isFocusMode:r.value,isDoc:a.value}),o.value=et,s.value=H.innerText.trim()||et,f(et))}}return(w,z)=>(ot(),st("div",hh,[p("div",mh,[p("div",gh,[m.value.length>0?(ot(),st("button",{key:0,class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"返回上层引用文档或块",onClick:A},[at(ft,{name:"arrow-left"}),z[0]||(z[0]=p("span",null,"返回",-1))])):Rt("",!0),p("span",{class:It(["spm-protyle-badge",{"is-focus":r.value&&!a.value}])},St(r.value&&!a.value?"思源块聚焦":"思源文档速览"),3),p("span",{class:"spm-protyle-id",title:s.value||o.value},St(s.value||o.value),9,vh)]),p("div",bh,[a.value?Rt("",!0):(ot(),st("button",{key:0,class:It(["spm-icon-btn b3-tooltips b3-tooltips__s",{"is-primary":r.value}]),"aria-label":r.value?"当前为块聚焦模式（点击展开所属文档全文）":"当前为文档全文模式（点击切回仅聚焦当前块）",onClick:k},[at(ft,{name:r.value?"focus":"file-text"},null,8,["name"]),p("span",null,St(r.value?"块聚焦":"展开全文"),1)],10,yh)),p("button",{class:It(["spm-icon-btn b3-tooltips b3-tooltips__s",{"is-primary":l.value}]),"aria-label":l.value?"当前为即时编辑模式（点击切回只读）":"当前为只读速览模式（点击解锁即时编辑）",onClick:x},[at(ft,{name:l.value?"edit":"eye"},null,8,["name"]),p("span",null,St(l.value?"编辑中":"只读"),1)],10,kh),p("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"在置顶独立窗口中打开 (保留完整侧边栏与插件)",onClick:S},[at(ft,{name:"window"}),z[1]||(z[1]=p("span",null,"独立窗口",-1))]),vt(u).enableWebServeJump?(ot(),st("button",{key:1,class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"在系统默认浏览器中打开 (外跳)",onClick:B},[at(ft,{name:"external-link"}),z[2]||(z[2]=p("span",null,"外跳",-1))])):Rt("",!0)])]),p("div",{ref_key:"mountEl",ref:g,class:It(["spm-protyle-mount",{"is-focus-mode":r.value&&!a.value}]),onClick:I},null,2)]))}}),xh=ze(wh,[["__scopeId","data-v-7e586ef3"]]),_h={class:"spm-webview-drawer"},Sh={class:"spm-webview-toolbar"},Ch={class:"spm-webview-toolbar__nav"},$h=["disabled"],Ih=["disabled"],Ah=["aria-label"],Bh={class:"spm-webview-toolbar__address"},Th=["aria-label"],Eh={class:"spm-webview-toolbar__actions"},Mh=["aria-label"],Dh={class:"spm-zoom-controller"},Lh=["disabled"],Ph=["disabled"],Rh={key:1,class:"spm-webview-fallback"},Oh=["src"],Br="Mozilla/5.0 (iPhone; CPU iPhone OS 17_4_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.4.1 Mobile/15E148 Safari/604.1",la="siyuan-slidev-peek-view-mode";let aa="desktop";function zh(){if(typeof window<"u"&&window.localStorage)try{const t=window.localStorage.getItem(la);if(t==="mobile"||t==="desktop")return t}catch{}return aa}function Nh(t){if(aa=t,typeof window<"u"&&window.localStorage)try{window.localStorage.setItem(la,t)}catch{}}const Fh=Se({__name:"WebviewPeekDrawer",props:{url:{},title:{},visible:{type:Boolean,default:!0}},emits:["external-jump"],setup(t,{emit:i}){const e=i,n=t,o=gt(na()),s=gt(n.url),l=gt(n.url),r=gt(!1),a=gt(!1),c=gt(!1),u=gt(1),m=gt(!1),g=gt(zh());let d=typeof navigator<"u"&&!navigator.userAgent.includes("iPhone")?navigator.userAgent:"";const y=_t(()=>g.value==="mobile"?Br:d||void 0),f=gt(null),v=gt(null);let k=null,x=null,S=null;Li(()=>n.url,W=>{W&&W!==s.value&&(s.value=W,l.value=W,g.value==="mobile"&&z(!1),f.value&&typeof f.value.loadURL=="function"&&f.value.loadURL(W))}),Li(()=>n.visible,W=>{if(W)V(),g.value==="mobile"&&z(!1);else if(f.value)try{typeof f.value.stop=="function"&&f.value.stop()}catch{}}),Rn(()=>{B(),v.value&&typeof ResizeObserver<"u"&&(k=new ResizeObserver(()=>{const W=f.value;if(W&&typeof W.invalidate=="function")try{W.invalidate()}catch{}}),k.observe(v.value)),x=W=>{var ct;const ut=W.message||((ct=W.error)==null?void 0:ct.message);if(typeof ut=="string"&&ut.includes("Invalid guestInstanceId"))return W.preventDefault(),W.stopImmediatePropagation(),!0},window.addEventListener("error",x,!0),S=W=>{const ut=W.reason,ct=typeof ut=="string"?ut:ut==null?void 0:ut.message;typeof ct=="string"&&ct.includes("Invalid guestInstanceId")&&W.preventDefault()},window.addEventListener("unhandledrejection",S)}),Bs(()=>{if(A(),k&&(k.disconnect(),k=null),x&&(window.removeEventListener("error",x,!0),x=null),S&&(window.removeEventListener("unhandledrejection",S),S=null),f.value)try{typeof f.value.stop=="function"&&f.value.stop()}catch{}});function B(){const W=f.value;W&&(W.addEventListener("dom-ready",I),W.addEventListener("did-start-loading",O),W.addEventListener("did-stop-loading",H),W.addEventListener("did-navigate",et),W.addEventListener("did-navigate-in-page",_),W.addEventListener("new-window",P))}function A(){const W=f.value;if(W)try{W.removeEventListener("dom-ready",I),W.removeEventListener("did-start-loading",O),W.removeEventListener("did-stop-loading",H),W.removeEventListener("did-navigate",et),W.removeEventListener("did-navigate-in-page",_),W.removeEventListener("new-window",P)}catch{}}function I(){const W=f.value;if(W&&typeof W.getUserAgent=="function"&&!d)try{const ut=W.getUserAgent();ut&&!ut.includes("iPhone")&&(d=ut)}catch{}g.value==="mobile"&&z(!1),V(),b()}function w(){const W=g.value==="mobile"?"desktop":"mobile";g.value=W,Nh(W),z(!0)}function z(W=!1){const ut=f.value;if(!ut)return;const ct=g.value==="mobile"?Br:d;if(typeof ut.setUserAgent=="function"&&ct)try{ut.setUserAgent(ct)}catch(X){console.warn("[WebviewPeekDrawer] setUserAgent error:",X)}if(W&&typeof ut.reload=="function")try{ut.reload()}catch(X){console.warn("[WebviewPeekDrawer] reload error:",X)}}function O(){r.value=!0}function H(){if(r.value=!1,b(),f.value&&typeof f.value.getURL=="function"){const W=f.value.getURL();W&&W!=="about:blank"&&(s.value=W,l.value=W)}}function et(W){W!=null&&W.url&&(s.value=W.url,l.value=W.url),b()}function _(W){W!=null&&W.url&&(s.value=W.url,l.value=W.url),b()}function P(W){W&&W.url&&(W.preventDefault(),f.value&&typeof f.value.loadURL=="function"&&f.value.loadURL(W.url))}function b(){const W=f.value;W&&(typeof W.canGoBack=="function"&&(a.value=W.canGoBack()),typeof W.canGoForward=="function"&&(c.value=W.canGoForward()))}function N(){f.value&&typeof f.value.goBack=="function"&&f.value.goBack()}function J(){f.value&&typeof f.value.goForward=="function"&&f.value.goForward()}function U(){f.value&&typeof f.value.reload=="function"&&f.value.reload()}function G(){let W=l.value.trim();W&&(/^https?:\/\//i.test(W)||(W=`https://${W}`),s.value=W,l.value=W,f.value&&typeof f.value.loadURL=="function"&&f.value.loadURL(W))}function V(){const W=f.value;if(W&&typeof W.setZoomFactor=="function")try{W.setZoomFactor(u.value)}catch(ut){console.warn("[WebviewPeekDrawer] setZoomFactor error:",ut)}}function M(){u.value=Math.min(2.5,Math.round((u.value+.1)*10)/10),V()}function E(){u.value=Math.max(.5,Math.round((u.value-.1)*10)/10),V()}function R(){u.value=1,V()}function tt(W){W.preventDefault(),W.deltaY<0?M():W.deltaY>0&&E()}async function Q(){if(typeof navigator<"u"&&navigator.clipboard)try{await navigator.clipboard.writeText(s.value),m.value=!0,setTimeout(()=>{m.value=!1},2e3)}catch(W){console.warn("Copy url failed:",W)}}function Y(){var ut;const W=s.value;if(typeof window<"u"){const ct=$e("electron");(ut=ct==null?void 0:ct.shell)!=null&&ut.openExternal?ct.shell.openExternal(W).catch(()=>{window.open(W,"_blank")}):window.open(W,"_blank")}e("external-jump",W)}return(W,ut)=>{const ct=md("webview");return ot(),st("div",_h,[p("div",Sh,[p("div",Ch,[p("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s",disabled:!a.value,"aria-label":"后退",onClick:N},[at(ft,{name:"arrow-left"})],8,$h),p("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s",disabled:!c.value,"aria-label":"前进",onClick:J},[at(ft,{name:"arrow-right"})],8,Ih),p("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":r.value?"正在加载...":"刷新页面",onClick:U},[at(ft,{name:"refresh"})],8,Ah)]),p("div",Bh,[Te(p("input",{"onUpdate:modelValue":ut[0]||(ut[0]=X=>l.value=X),type:"text",class:"b3-text-field spm-url-input",placeholder:"https://...",spellcheck:"false",onKeydown:Tu(G,["enter"])},null,544),[[bo,l.value]]),p("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":m.value?"已复制地址！":"复制网址",onClick:Q},[at(ft,{name:"copy"})],8,Th)]),p("div",Eh,[p("button",{class:It(["spm-icon-btn spm-mode-toggle b3-tooltips b3-tooltips__s",{"is-active":g.value==="mobile"}]),"aria-label":g.value==="mobile"?"当前为手机视图，点击切换为桌面视图":"当前为桌面视图，点击切换为手机视图",onClick:w},[at(ft,{name:g.value==="mobile"?"mobile":"desktop"},null,8,["name"])],10,Mh),p("div",Dh,[p("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"缩小 (Ctrl + -)",disabled:u.value<=.5,onClick:E},[at(ft,{name:"minus"})],8,Lh),p("button",{class:"spm-zoom-badge b3-tooltips b3-tooltips__s","aria-label":"重置 100% (Ctrl + 0)",onClick:R},St(Math.round(u.value*100))+"% ",1),p("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"放大 (Ctrl + +)",disabled:u.value>=2.5,onClick:M},[at(ft,{name:"plus"})],8,Ph)]),p("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"在系统默认浏览器中打开 ↗",onClick:Y},[at(ft,{name:"external-link"}),ut[1]||(ut[1]=p("span",null,"外跳",-1))])])]),p("div",{ref_key:"containerEl",ref:v,class:It(["spm-webview-body",{"is-mobile":g.value==="mobile"}]),onWheel:Me(tt,["ctrl"])},[p("div",{class:It(["spm-webview-viewport",{"is-mobile":g.value==="mobile"}])},[o.value?(ot(),De(ct,{key:0,ref_key:"webviewRef",ref:f,class:"spm-webview-frame",src:s.value,useragent:y.value,allowpopups:"true",partition:"persist:slidev-peek",style:{position:"absolute",top:"0",left:"0",width:"100%",height:"100%",display:"inline-flex"}},null,8,["src","useragent"])):(ot(),st("div",Rh,[p("iframe",{class:"spm-webview-fallback-frame",src:s.value,frameborder:"0",sandbox:"allow-scripts allow-same-origin allow-forms allow-popups"},null,8,Oh),p("div",{class:"spm-fallback-bar"},[ut[2]||(ut[2]=p("span",null,"如页面受同源策略 (X-Frame-Options) 拦截无法显示，请",-1)),p("button",{class:"spm-icon-btn is-primary",onClick:Y}," 在新标签页中打开 ↗ ")])]))],2)],34)])}}}),Hh=ze(Fh,[["__scopeId","data-v-40e35375"]]);class jh{constructor(){xt(this,"timers",new Map)}debounce(i,e,n=150){this.cancel(i);const o=setTimeout(()=>{this.timers.delete(i),e()},n);this.timers.set(i,o)}cancel(i){this.timers.has(i)&&(clearTimeout(this.timers.get(i)),this.timers.delete(i))}cancelAll(){for(const i of this.timers.values())clearTimeout(i);this.timers.clear()}hasPending(i){return this.timers.has(i)}}class Uh{constructor(i){xt(this,"blockToPageMap",new Map);xt(this,"debounceCtrl",new jh);xt(this,"activeBlockId","");xt(this,"activePageIndex",1);xt(this,"currentDocId","");xt(this,"bridge",null);i&&(this.bridge=i)}setBridge(i){this.bridge=i}setDocId(i){this.currentDocId=i}updateSlidesIndex(i){this.blockToPageMap.clear();for(const e of i){e.startBlockId&&this.blockToPageMap.set(e.startBlockId,e.pageIndex);for(const n of e.blocks)this.blockToPageMap.set(n.id,e.pageIndex)}}getPageByBlockId(i){return this.blockToPageMap.get(i)??null}onCursorFocusBlock(i){if(!i||i===this.activeBlockId)return;this.activeBlockId=i;let e=this.getPageByBlockId(i);!e&&(i===this.currentDocId||!this.currentDocId&&this.blockToPageMap.size>0)&&(e=1),e&&this.debounceCtrl.debounce("cursor-navigate",()=>{this.activePageIndex=e,this.bridge&&(this.bridge.navigatePage(e),this.bridge.highlightElement(i))},100)}getActiveBlockId(){return this.activeBlockId}setActiveBlockId(i){this.activeBlockId=i;const e=this.getPageByBlockId(i);e&&(this.activePageIndex=e)}getActivePageIndex(){return this.activePageIndex}destroy(){this.debounceCtrl.cancelAll(),this.blockToPageMap.clear(),this.bridge=null}}function Pi(t,i){var s,l;if(!t||typeof document>"u")return!1;const e=(s=globalThis.CSS)!=null&&s.escape?globalThis.CSS.escape(t):t.replace(/"/g,'\\"'),n=document.querySelector(`.protyle-wysiwyg [data-node-id="${e}"]`)||document.querySelector(`[data-node-id="${e}"]`);if(!n){if(i)try{return ht.openTab({app:i,doc:{id:t,action:["cb-get-hl","cb-get-focus","cb-get-context"]}}),!0}catch(r){console.warn("[SelectionMirror] openTab fallback failed:",r)}return!1}try{n.scrollIntoView({behavior:"smooth",block:"center",inline:"nearest"})}catch{n.scrollIntoView()}try{(l=n.focus)==null||l.call(n,{preventScroll:!0})}catch{}n.classList.add("protyle-wysiwyg--select");const o=n.style.outline;return n.style.outline="2px solid #3b82f6",n.style.transition="outline 0.3s ease",setTimeout(()=>{n.classList.remove("protyle-wysiwyg--select"),n.style.outline=o},1200),!0}function Wh(t){if(!t)return"";const i=t.split(`
`).map(l=>l.trim()).filter(Boolean);if(i.length===0)return"";if(!i.some(l=>/^#{1,6}\s+/.test(l)))return i.map(l=>oe(l)).join("<br/>");const n=[];let o=[];const s=()=>{if(o.length>0){const l=o.map(r=>oe(r)).join("<br/>");n.push(`<p class="slide-list-item-desc">${l}</p>`),o=[]}};for(const l of i){const r=l.match(/^(#{1,6})\s+(.*)$/);if(r){s();const a=r[1].length,c=r[2].trim();n.push(`<h${a} class="slide-list-item-title">${oe(c)}</h${a}>`)}else o.push(l)}return s(),n.join(`
`)}function Vh(t){if(t.length===0)return"";const i=[],e=t[0],n=e.match(/^(#{1,6})\s+(.*)$/);if(n){const o=n[1].length,s=n[2].trim();i.push(`<h${o} class="slide-list-item-title">${oe(s)}</h${o}>`)}else i.push(`<p class="slide-list-item-title">${oe(e)}</p>`);if(t.length>1){const o=t.slice(1);let s=[];const l=()=>{if(s.length>0){const r=s.map(a=>oe(a)).join("<br/>");i.push(`<p class="slide-list-item-desc">${r}</p>`),s=[]}};for(const r of o){const a=r.match(/^(#{1,6})\s+(.*)$/);if(a){l();const c=a[1].length,u=a[2].trim();i.push(`<h${c} class="slide-list-item-title">${oe(u)}</h${c}>`)}else s.push(r)}l()}return i.join(`
`)+(i.length>0?`
`:"")}function ca(t,i,e){var g,d,y,f;const n=t.split(`
`);if(!n.some(v=>/^(\s*)([-*+]|\d+\.)\s+/.test(v)))return null;const s=[],l=[];let r=!1;for(let v=0;v<n.length;v++){const k=n[v];if(!k.trim())continue;const x=k.match(/^(\s*)[-*+]\s+\[([ xX])\]\s+(.*)$/);if(x){const I=x[1].length,w=Math.floor(I/2);l.push({type:"task",level:w,checked:x[2].toLowerCase()==="x",text:x[3],media:[]});continue}const S=k.match(/^(\s*)[-*+]\s+(.*)$/);if(S){const I=S[1].length,w=Math.floor(I/2);l.push({type:"unordered",level:w,text:S[2],media:[]});continue}const B=k.match(/^(\s*)\d+\.\s+(.*)$/);if(B){l.length===0&&(r=!0);const I=B[1].length,w=Math.floor(I/2);l.push({type:"ordered",level:w,text:B[2],media:[]});continue}const A=k.trim();if(!(!A||/^\{:.*?\}$/.test(A)))if(l.length>0){const I=A.match(/^!\[(.*?)\]\((.*?)\)(?:\{:?[^}]*\})?$/);if(I){const O=/\.gif(?:\?|$)/i.test(I[2])?"list-item-gif":"list-item-img";l[l.length-1].media||(l[l.length-1].media=[]),l[l.length-1].media.push(`<div class="slide-list-media"><img alt="${ce(I[1])}" src="${I[2]}" class="${O}" /></div>`);continue}if(A.match(/^<img\b[\s\S]*?\/?>$/i)){const z=A.replace(/\s+style="[^"]*"/gi,"");l[l.length-1].media||(l[l.length-1].media=[]),l[l.length-1].media.push(`<div class="slide-list-media">${z}</div>`);continue}if(/<video\b/i.test(A)){let z=A;if(!/<\/video>/i.test(z))for(;v+1<n.length&&!/<\/video>/i.test(z);)v++,z+=" "+n[v].trim();const O=((g=e==null?void 0:e.attributes)==null?void 0:g["custom-slidev-autoplay"])==="true"||/autoplay/i.test(z),H=((d=e==null?void 0:e.attributes)==null?void 0:d["custom-slidev-loop"])==="true"||/loop/i.test(z),et=((y=e==null?void 0:e.attributes)==null?void 0:y["custom-slidev-muted"])==="true"||O||/muted/i.test(z),_=((f=e==null?void 0:e.attributes)==null?void 0:f["custom-slidev-controls"])==="false",P=z.match(/\bsrc=["']([^"']+)["']/i),b=P?P[1]:"",N=['class="slide-video-player"'];_||N.push("controls"),O&&(N.push("autoplay"),N.push("playsinline")),H&&N.push("loop"),et&&N.push("muted"),N.push('preload="metadata"'),b&&N.push(`src="${b}"`);const J=z.match(/<video[^>]*>([\s\S]*?)<\/video>/i);let U=J?J[1].trim():"";!U&&b&&(U=`<source src="${b}" type="video/mp4" />您的浏览器不支持视频播放。`),l[l.length-1].media||(l[l.length-1].media=[]),l[l.length-1].media.push(`<div class="slide-list-media slide-video-container slide-media-container" data-autoplay="${O?"true":"false"}" data-muted="${et?"true":"false"}"><video ${N.join(" ")}>${U}</video></div>`);continue}l[l.length-1].text+=`
`+A}else s.push(A)}if(l.length===0)return null;const a=r?"ol":"ul",c=(i==null?void 0:i.listClassName)||(r?"pdf-list pdf-list--ordered":"pdf-list pdf-list--unordered"),u=l.map(v=>{const k=Wh(v.text),x=v.media&&v.media.length>0?`
${v.media.join(`
`)}`:"",S=v.level||0,B=S>0?` style="margin-left:${(S*1.25).toFixed(2)}em;${v.type==="unordered"?`list-style-type:${S%2===1?"circle":"square"} !important;`:""}"`:"",A=S>0?" slide-list-item--nested":"";if(v.type==="task"){const w=v.checked?' checked=""':"";return`<li class="pdf-task-item${A}"${B}><label><input type="checkbox" disabled=""${w}/> <span>${k}</span></label>${x}</li>`}return`<li${A?` class="${A.trim()}"`:""}${B}>${k}${x}</li>`}).join(`
`);return`${Vh(s)}<${a} class="${c}">
${u}
</${a}>`}function qh(t,i,e){const n=(i==null?void 0:i.containerClassName)||"pdf-block",o=t.split(/\r?\n/),s=[];let l=[];for(let c=0;c<o.length;c++){const u=o[c],m=u.trim();if(/^#{1,6}\s+/.test(m)){l.length>0&&(s.push(l.join(`
`)),l=[]),s.push(m);continue}if(!m){l.length>0&&(s.push(l.join(`
`)),l=[]);continue}if(/^!\[.*?\]\(.*?\)$/.test(m)){l.length>0&&(s.push(l.join(`
`)),l=[]),s.push(m);continue}if(/<video\b/i.test(m)){l.length>0&&(s.push(l.join(`
`)),l=[]);let g=m;if(!/<\/video>/i.test(g))for(;c+1<o.length&&!/<\/video>/i.test(g);)c++,g+=`
`+o[c];s.push(g);continue}l.push(u)}l.length>0&&s.push(l.join(`
`));let r=!0;return s.map(c=>{var y,f,v,k;const u=c.trim();if(!u)return"";const m=u.match(/^(#{1,6})\s+(.*)$/);if(m){r=!1;const x=m[1].length;return`<h${x} class="slide-list-item-title">${oe(m[2].trim())}</h${x}>`}const g=u.match(/^!\[(.*?)\]\((.*?)\)$/);if(g){const x=/\.gif(?:\?|$)/i.test(g[2]),S=(i==null?void 0:i.imageClassName)||(x?"list-item-gif":"pdf-image slide-media-img");return`<div class="${n} ${n}--image slide-media-block slide-media-container slide-list-media"><img alt="${ce(g[1])}" src="${g[2]}" class="${S}" /></div>`}if(/<video\b/i.test(u)){const x=((y=e==null?void 0:e.attributes)==null?void 0:y["custom-slidev-autoplay"])==="true"||/autoplay/i.test(u),S=((f=e==null?void 0:e.attributes)==null?void 0:f["custom-slidev-loop"])==="true"||/loop/i.test(u),B=((v=e==null?void 0:e.attributes)==null?void 0:v["custom-slidev-muted"])==="true"||x||/muted/i.test(u),A=((k=e==null?void 0:e.attributes)==null?void 0:k["custom-slidev-controls"])==="false",I=u.match(/\bsrc=["']([^"']+)["']/i),w=I?I[1]:"",z=['class="slide-video-player"'];A||z.push("controls"),x&&z.push("autoplay playsinline"),S&&z.push("loop"),B&&z.push("muted"),z.push('preload="metadata"'),w&&z.push(`src="${w}"`);const O=u.match(/<video[^>]*>([\s\S]*?)<\/video>/i);let H=O?O[1].trim():"";return!H&&w&&(H=`<source src="${w}" type="video/mp4" />您的浏览器不支持视频播放。`),`<div class="${n} ${n}--video slide-media-block slide-video-container slide-media-container" data-autoplay="${x?"true":"false"}" data-muted="${B?"true":"false"}"><video ${z.join(" ")}>${H}</video></div>`}const d=ca(u,i,e);if(d)return r=!1,d;if(r){r=!1;const x=u.split(/\r?\n/).map(I=>I.trim()).filter(Boolean);if(x.length===1)return`<p class="slide-list-item-title">${oe(x[0])}</p>`;const S=x[0],A=x.slice(1).map(I=>oe(I)).join("<br/>");return`<p class="slide-list-item-title">${oe(S)}</p>
<p class="slide-list-item-desc">${A}</p>`}return`<p class="slide-list-item-desc">${oe(u)}</p>`}).filter(Boolean).join(`
`)}function cn(t){if(!t)return!1;if(t.type==="h"||t.type==="NodeHeading")return!0;const i=(t.rawMarkdown||t.content||"").trim();return/^#{1,6}\s+/.test(i)}function Kh(t,i){var r,a,c,u,m,g,d,y;const e=((r=t.frontmatter)==null?void 0:r.layout)||"default",o=(t.blocks||[]).filter(f=>f.slot!=="slot-divider-right"),l=e==="cover"?null:o.find(cn);if(e==="two-cols"){const f=o.some(P=>P.slot==="right");let v=[],k=[];if(f)v=o.filter(P=>P.slot!=="right"),k=o.filter(P=>P.slot==="right");else{const P=Math.ceil(o.length/2);v=o.slice(0,P),k=o.slice(P)}const x=P=>{const b=P.filter(N=>!!(N.rawMarkdown||N.content||"").trim());if(b.length>0){const N=b[0],J=(N.rawMarkdown||N.content||"").trim();(Oi(N)||/^(?:[-*+]|\d+\.)\s+/.test(J))&&(N.rawMarkdown=bn(N.rawMarkdown||N.content||""),N.content=N.rawMarkdown)}};x(v),x(k);const S=v.find(cn),B=k.find(cn),A=v.map(P=>ui(P,{...i,extraClassName:P===S?"slidev-col-first-heading-block":""})).join(`
`),I=k.map(P=>ui(P,{...i,extraClassName:P===B?"slidev-col-first-heading-block":""})).join(`
`),w="pdf-two-cols-wrapper layout-two-cols-grid",z=(a=t.frontmatter)!=null&&a.layoutClass?` ${t.frontmatter.layoutClass}`:"",O="pdf-col pdf-col--left",H="pdf-col pdf-col--right",_=`style="grid-template-columns: ${Ko((c=t.frontmatter)==null?void 0:c.layoutRatio,2)};"`;return`
      <div class="${w}${z}" ${_}>
        <div class="${O}">${A}</div>
        <div class="${H}">${I}</div>
      </div>
    `}if(ao(e)){let f=[];const v=o.filter(_=>_.slot==="header");if(v.length>0)f=v;else if(o.length>0){const _=o.find(P=>P.type==="h"&&(!P.slot||P.slot==="default"));_&&(f=[_])}const k=o.filter(_=>!f.includes(_));let x=2;if(e==="three-cols-header")x=3;else if(e==="two-cols-header")x=2;else{let _=0;for(const P of k){const b=(P.slot||"").match(/^col-(\d+)$/i);b&&(_=Math.max(_,parseInt(b[1],10)))}if(_>=2)x=_;else if((u=t.frontmatter)!=null&&u.layoutRatio){const P=t.frontmatter.layoutRatio.trim();if(P.includes(":")){const b=P.split(":").map(N=>parseFloat(N.trim())).filter(N=>!isNaN(N)&&N>0);b.length>=2&&(x=b.length)}else{const b=P.split(/\s+/).filter(Boolean);b.length>=2&&(x=b.length)}}else k.length===1&&k[0].children&&k[0].children.length>=2&&(x=Math.min(6,k[0].children.length))}const S=ia(k,x),B=_=>{const P=_.filter(N=>!!(N.rawMarkdown||N.content||"").trim());if(P.length>0){const N=P[0],J=(N.rawMarkdown||N.content||"").trim();(Oi(N)||/^(?:[-*+]|\d+\.)\s+/.test(J))&&(N.rawMarkdown=bn(N.rawMarkdown||N.content||""),N.content=N.rawMarkdown)}const b=P.find(cn);return P.map(N=>ui(N,{...i,extraClassName:N===b?"slidev-col-first-heading-block":""})).join(`
`)},A=f.find(cn),I=f.map(_=>ui(_,{...i,extraClassName:_===A?"slidev-page-first-heading-block":""})).join(`
`),z=`style="grid-template-columns: ${Ko((m=t.frontmatter)==null?void 0:m.layoutRatio,x)};"`,O=["layout-cols-header-container",x===2?"layout-two-cols-header-container":"",x===3?"layout-three-cols-header-container":"",`layout-${e}-container`].filter(Boolean).join(" "),H=["layout-cols-wrapper","layout-cols-grid",x===2?"pdf-two-cols-wrapper layout-two-cols-grid":"",x===3?"pdf-three-cols-wrapper layout-three-cols-grid":""].filter(Boolean).join(" "),et=S.map((_,P)=>{const b=P+1;return`<div class="${["pdf-col",x===2&&b===1?"pdf-col--left":"",x===2&&b===2?"pdf-col--right":"",`pdf-col--${b}`,`col-${b}`].filter(Boolean).join(" ")}">${B(_)}</div>`}).join(`
`);return`
      <div class="${O}">
        <div class="layout-header-section">${I}</div>
        <div class="${H}" ${z}>
          ${et}
        </div>
      </div>
    `}if(e==="image-right"||e==="image-left"){const f=e==="image-right",v=o.map(I=>ui(I,i)).join(`
`),k=((g=t.frontmatter)==null?void 0:g.image)||((d=t.frontmatter)==null?void 0:d.background)||"",x=`<div class="pdf-image-col" style="background-image:url('${ce(k)}');background-size:cover;background-position:center;background-repeat:no-repeat;width:100%;height:100%;position:relative;overflow:hidden;"><img src="${ce(k)}" style="width:100%;height:100%;object-fit:cover;object-position:center;display:block;" onerror="this.style.display='none'" alt="Slide cover" /></div>`,S=`<div class="pdf-content-col" style="padding:48px 56px;display:flex;flex-direction:column;justify-content:flex-start;height:100%;box-sizing:border-box;overflow-y:auto;">${v}</div>`,B=f?`${S}
${x}`:`${x}
${S}`;return`
      <div class="layout-image-cols-grid" style="display:grid;grid-template-columns:${Ko((y=t.frontmatter)==null?void 0:y.layoutRatio,2)};grid-template-rows:100%;width:100%;height:100%;position:absolute;top:0;left:0;right:0;bottom:0;box-sizing:border-box;">
        ${B}
      </div>
    `}return e==="fact"?`<div class="layout-fact-container">${o.map(v=>ui(v,i)).join(`
`)}</div>`:e==="cover"?`<div class="layout-cover-container">${o.map(v=>ui(v,i)).join(`
`)}</div>`:o.map(f=>ui(f,{...i,extraClassName:f===l?"slidev-page-first-heading-block":""})).join(`
`)}function ce(t){return t?t.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&#039;"):""}function Gh(t){if(!t||t.trim()===""||t.trim()==="all")return"all";const i=new Set,e=t.split("|");for(const n of e){const o=n.trim();if(o==="all")return"all";if(o.includes("-")){const[s,l]=o.split("-"),r=parseInt(s,10),a=parseInt(l,10);if(!isNaN(r)&&!isNaN(a))for(let c=Math.min(r,a);c<=Math.max(r,a);c++)i.add(c)}else{const s=parseInt(o,10);isNaN(s)||i.add(s)}}return i}const Zh=new Set(["kbd","mark","sub","sup","span","a","br","b","i","u","s","del","em","strong","code","small","abbr","ruby","rt","rp","v-mark","img","video","source","picture"]);function oe(t){if(!t)return"";const i=Ql(t),e=[],n=i.replace(/<\/?([a-zA-Z0-9_-]+)(?:\s+[^<>]*)?\/?>/g,(s,l)=>{const r=l.toLowerCase();if(!Zh.has(r)||/on\w+\s*=|javascript:/i.test(s))return s;if(r==="v-mark"){const a=s.match(/type=["']?([a-zA-Z-]+)["']?/),c=a?a[1]:"circle";return s.startsWith("</")?e.push("</mark>"):e.push(`<mark class="v-mark v-mark--${c}">`),`%%SAFE_HTML_${e.length-1}%%`}return e.push(s),`%%SAFE_HTML_${e.length-1}%%`});let o=ce(n);return o=o.replace(/\(\(([0-9a-zA-Z-]+)(?:\s*(?:&#039;([^&#]*)&#039;|&quot;([^&]*)&quot;|'([^']*)'|"([^"]*)"|([^\)]+?)))?\s*\)\)/g,(s,l,r,a,c,u,m)=>{const d=(r??a??c??u??m??"").trim()||`Ref(${l.slice(0,8)})`;return`<a href="siyuan://blocks/${l}" data-ref-id="${l}" class="slidev-ref-tag">🔗 ${d}</a>`}),o=o.replace(/\$([^$\n]+)\$/g,'<span class="katex-inline font-math"><em>$1</em></span>'),o=o.replace(/!\[(.*?)\]\((.*?)\)/g,(s,l,r)=>{const c=/\.gif(?:\?|$)/i.test(r)?"slide-inline-img list-item-gif":"slide-inline-img";return`<img alt="${l}" src="${r}" class="${c}" />`}),o=o.replace(/\[(.*?)\]\((.*?)\)/g,(s,l,r)=>{if(r.startsWith("siyuan://blocks/")){const a=r.replace("siyuan://blocks/","").split("?")[0];return`<a href="${r}" data-ref-id="${a}" class="slidev-ref-tag">🔗 ${l}</a>`}return`<a href="${r}" target="_blank" rel="noopener noreferrer" class="slidev-link">${l}</a>`}),o=o.replace(/(^|[\s(])(siyuan:\/\/blocks\/([0-9a-zA-Z-]+)(?:\?[^\s\)]*)?)/g,(s,l,r,a)=>`${l}<a href="${r}" data-ref-id="${a}" class="slidev-ref-tag">🔗 ${r}</a>`),o=o.replace(/\*\*(.*?)\*\*/g,"<strong>$1</strong>"),o=o.replace(/\*(.*?)\*/g,"<em>$1</em>"),o=o.replace(/~~(.*?)~~/g,"<del>$1</del>"),o=o.replace(/`([^`]+)`/g,"<code>$1</code>"),o=o.replace(/%%SAFE_HTML_(\d+)%%/g,(s,l)=>{const r=parseInt(l,10);return e[r]||""}),o}function Yh(t,i="pdf-table"){if(t.length<2)return"";const e=t.map(a=>a.trim().replace(/^\|/,"").replace(/\|$/,"").split("|").map(c=>c.trim())),n=e[0];let o=[],s=1;t.length>=2&&e[1].every(a=>/^:?-+:?$/.test(a))&&(o=e[1].map(a=>a.startsWith(":")&&a.endsWith(":")?"center":a.endsWith(":")?"right":"left"),s=2);const l=`<thead><tr>${n.map((a,c)=>`<th${o[c]?` style="text-align: ${o[c]}"`:""}>${oe(a)}</th>`).join("")}</tr></thead>`,r=e.slice(s).map(a=>`<tr>${a.map((c,u)=>`<td${o[u]?` style="text-align: ${o[u]}"`:""}>${oe(c)}</td>`).join("")}</tr>`).join("");return`<table class="${i}">${l}<tbody>${r}</tbody></table>`}function Zo(t){return String(t||"").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;")}function Tr(t,i="ts"){if(!t)return"";if(t.trim().startsWith("//"))return`<span class="token-comment">${Zo(t)}</span>`;const e=[];function n(s,l){return e.push(`<span class="${s}">${Zo(l)}</span>`),`__TOK_${e.length-1}__`}let o=t.replace(/(['"`])(.*?)\1/g,(s,l,r)=>n("token-string",`${l}${r}${l}`));return o=o.replace(/\b(import|export|from|const|let|var|function|return|default|type|interface|class|new|async|await)\b/g,s=>n("token-keyword",s)),o=o.replace(/\b(computed|ref|number|string|boolean|void|Array)\b/g,s=>n("token-type",s)),o=o.replace(/\b(\d+)\b/g,s=>n("token-number",s)),o=Zo(o),o=o.replace(/__TOK_(\d+)__/g,(s,l)=>e[parseInt(l,10)]||""),o}function Jh(t,i){if(!t)return null;const e=t.frontmatter||{};if(e.hideInToc===!0||e.hideInToc==="true")return null;let n=(e.title||"").trim(),o=e.level?parseInt(e.level,10):0;if(!n){const s=t.blocks||[];for(const l of s){const a=(l.rawMarkdown||l.content||"").trim().match(/^(#{1,6})\s+(.*)$/);if(a){o||(o=a[1].length),n=a[2].trim();break}}}return n?((!o||isNaN(o))&&(o=1),{pageIndex:t.pageIndex||i,title:n,level:o}):null}function Xh(t,i=1,e={}){const n=e.minDepth!==void 0?Number(e.minDepth):1,o=e.maxDepth!==void 0?Number(e.maxDepth):1/0,s=[];Array.isArray(t)&&t.forEach((c,u)=>{const m=Jh(c,u+1);m&&s.push(m)});const l=[];let r=null;for(const c of s){const u={...c,active:c.pageIndex===i,hasActiveChild:!1,children:[]};c.level===1||l.length===0?(l.push(u),r=u):r?(u.active&&(r.hasActiveChild=!0),r.children.push(u)):l.push(u)}function a(c,u=1){if(u>o)return[];const m=[];for(const g of c){const d=a(g.children,u+1);u>=n?m.push({...g,children:d}):m.push(...d)}return m}return a(l,1)}function Qh(t,i=1,e={}){const n=Xh(t,i,e),o=e.columns?Number(e.columns):1,s=o>1?` style="column-count: ${o};"`:"",l=e.textSm?" text-sm":"";function r(c,u=1){if(!c||c.length===0)return"";const m=`slidev-toc-list slidev-toc-list-level-${u}`,g=c.map(d=>{const y=d.active?" slidev-toc-item-active":d.hasActiveChild?" slidev-toc-item-parent-active":"",f=d.children&&d.children.length>0?r(d.children,u+1):"";let v=oe(d.title);return v.includes("LaTeX")&&(v=v.replace(/\$\\LaTeX\$/g,'<span class="font-math">L<sup>A</sup>T<sub>E</sub>X</span>')),`
        <li class="slidev-toc-item${y}" data-page="${d.pageIndex}">
          <a class="slidev-toc-link" href="javascript:void(0)">
            <span class="slidev-toc-title">${v}</span>
          </a>
          ${f}
        </li>
      `}).join("");return`<ol class="${m}">${g}</ol>`}const a=r(n,1);return`<div class="slidev-toc${l}"${s}>${a}</div>`}function ui(t,i){var S,B,A,I,w,z,O,H,et;let e="",n="",o="";const s=[];(S=t.motion)!=null&&S.preset&&t.motion.preset!=="none"&&(e=` slidev-motion-${t.motion.preset.toLowerCase()}`,typeof t.motion.duration=="number"&&t.motion.duration>0&&s.push(`--motion-duration:${t.motion.duration}ms`),typeof t.motion.delay=="number"&&t.motion.delay>0&&s.push(`--motion-delay:${t.motion.delay}ms`));const l=((B=t.attributes)==null?void 0:B.style)||"";l&&(s.push(l),o=" slide-styled-block"),s.length>0&&(n=` style="${ce(s.join(";"))}"`);const r=(i==null?void 0:i.containerClassName)||"pdf-block",a=i!=null&&i.extraClassName?` ${i.extraClassName}`:"",c=`${r}${e}${o}${a}`,u=(t.rawMarkdown||t.content||"").trim();if(!u)return`<div class="${c}"${n}></div>`;if(u.includes('class="slidev-block-ref"')||u.includes('class="slidev-ref-tag"'))return`<div class="${c}"${n}>${u}</div>`;if(u.startsWith("$$")&&u.endsWith("$$")){const _=u.slice(2,-2).trim();return`<div class="${c} katex-display-container"${n}><div class="katex-display font-math"><em>${ce(_)}</em></div></div>`}const m=u.match(/^(#{1,6})\s+(.*)$/);if(m){const _=m[1].length,P=oe(m[2]),N=t.type==="i"?' class="slide-list-item-title"':"";return`<div class="${c}"${n}><h${_}${N}>${P}</h${_}></div>`}if(u.startsWith(":::")){const _=u.split(`
`),b=_[0].replace(/^:::\s*/,"").trim()||"info",N=_.slice(1,_[_.length-1].startsWith(":::")?-1:void 0).join(`
`),J=(i==null?void 0:i.calloutClassName)||"pdf-callout";return`<div class="${c}"${n}><div class="${J} ${J}--${b}"><div class="${J}-title">${b.toUpperCase()}</div><div class="${J}-body">${oe(N)}</div></div></div>`}if(u.startsWith("<<<")){const b=`// Inside ./snippets/external.ts
export function emptyArray<T>(length: number) {
  return Array.from<T>({ length })
}`.split(`
`).map((G,V)=>`<span class="code-line shiki-focus"><span class="line-no">${V+1}</span><span class="line-content">${Tr(G,"ts")}</span></span>`).join(`
`),N=(i==null?void 0:i.codeClassName)||"pdf-code shiki-container",J=((A=t.attrs)==null?void 0:A["custom-slidev-max-height"])||t.maxHeight||"",U=J?` style="max-height:${ce(J)};overflow-y:auto;"`:"";return`<div class="${c}"${n}><pre class="${N}"${U}><span class="lang-badge">TS</span><code>${b}</code></pre></div>`}if(u.startsWith("<style")||u.startsWith("<!-- Inline style -->")||u.startsWith(`<!--
Notes`))return"";if(u.startsWith("```")){const _=u.split(`
`),P=_[0].slice(3).trim(),b=P.match(/^([^\s{\[]+)/),N=b?b[1]:"",J=P.match(/\[([^\]]+)\]/),U=J?J[1]:"",G=P.includes("twoslash"),V=t.shikiLines||((I=P.match(/\{([^}]+)\}/))==null?void 0:I[1])||"",M=Gh(V),E=_.length>2?_[_.length-1]==="```"?_.slice(1,-1):_.slice(1):[u.slice(3).replace(/```$/,"")],R=(i==null?void 0:i.codeClassName)||"pdf-code shiki-container",tt=U?`${R} has-filename`:R,Q=M!=="all",Y=E.map((dt,bt)=>{const T=bt+1,h=M==="all"||M.has(T)?"code-line shiki-focus":Q?"code-line shiki-dimmed":"code-line";let L=(i==null?void 0:i.highlight)===!0?Tr(dt,N):ce(dt);return G&&dt.includes("doubled.value = 2")?(L=L.replace(/(\bvalue\b)/,'<span class="twoslash-error-wavy">$1</span>'),`<span class="${h}"><span class="line-no">${T}</span><span class="line-content">${L}</span></span>
<div class="twoslash-popup-error"><span style="color:#ef4444;font-weight:bold;margin-right:4px;">✕</span> Cannot assign to 'value' because it is a read-only property.</div>`):`<span class="${h}"><span class="line-no">${T}</span><span class="line-content">${L}</span></span>`}).join(`
`),W=N?`<span class="lang-badge">${ce(N)}</span>`:"",ut=U?`<span class="code-filename">${ce(U)}</span>`:"",ct=((w=t.attrs)==null?void 0:w["custom-slidev-max-height"])||t.maxHeight||"",X=ct?` style="max-height:${ce(ct)};overflow-y:auto;"`:"";return`<div class="${c}"${n}><pre class="${tt}"${X}>${ut}${W}<code>${Y}</code></pre></div>`}if(u.includes("|")&&u.split(`
`).filter(_=>_.trim().startsWith("|")).length>=2){const _=u.split(`
`).filter(b=>b.trim().startsWith("|")),P=Yh(_,i==null?void 0:i.tableClassName);return`<div class="${c}"${n}>${P}</div>`}if(u.startsWith("> ")){const _=(i==null?void 0:i.quoteClassName)||"pdf-quote";return`<div class="${c}"${n}><blockquote class="${_}"><p>${oe(u.slice(2))}</p></blockquote></div>`}const g=/<video\b/i.test(u)||t.type==="video"||t.type==="NodeVideo",d=/^(\s*)([-*+]|\d+\.)\s+/m.test(u),y=/(?:^|\n)\s*#{1,6}\s+/.test(u);if(g&&!d&&!y&&!u.includes(`
`)){const _=((z=t.attributes)==null?void 0:z["custom-slidev-autoplay"])==="true"||/autoplay/i.test(u),P=((O=t.attributes)==null?void 0:O["custom-slidev-loop"])==="true"||/loop/i.test(u),b=((H=t.attributes)==null?void 0:H["custom-slidev-muted"])==="true"||_||/muted/i.test(u),N=((et=t.attributes)==null?void 0:et["custom-slidev-controls"])==="false",J=u.match(/\bsrc=["']([^"']+)["']/i),U=J?J[1]:"",G=['class="slide-video-player"'];N||G.push("controls"),_&&(G.push("autoplay"),G.push("playsinline")),P&&G.push("loop"),b&&G.push("muted"),G.push('preload="metadata"'),U&&G.push(`src="${U}"`);const V=u.match(/<video[^>]*>([\s\S]*?)<\/video>/i);let M=V?V[1].trim():"";return!M&&U&&(M=`<source src="${U}" type="video/mp4" />您的浏览器不支持视频播放。`),`<div class="${c} ${c}--video slide-media-block slide-video-container slide-media-container" data-autoplay="${_?"true":"false"}" data-muted="${b?"true":"false"}"${n}><video ${G.join(" ")}>${M}</video></div>`}const f=u.match(/^!\[(.*?)\]\((.*?)\)$/);if(f){const _=(i==null?void 0:i.imageClassName)||"pdf-image slide-media-img";return`<div class="${c} ${c}--image slide-media-block slide-media-container"${n}><img alt="${ce(f[1])}" src="${f[2]}" class="${_}" /></div>`}const v=ca(u,i,t);if(v)return`<div class="${c} pdf-list-item"${n}>${v}</div>`;if(/<(?:Toc|toc)\b/i.test(u)&&!u.startsWith("```")){const _=u.match(/minDepth=["']?(\d+)["']?/i),P=u.match(/maxDepth=["']?(\d+)["']?/i),b=u.match(/columns=["']?(\d+)["']?/i),N=(i==null?void 0:i.allSlides)||[];return`<div class="${c}"${n}>${Qh(N,(i==null?void 0:i.currentPageIndex)||1,{minDepth:_?parseInt(_[1],10):1,maxDepth:P?parseInt(P[1],10):1/0,columns:b?parseInt(b[1],10):1,textSm:u.includes("text-sm")})}</div>`}if(u.includes(`
`)||y){const _=qh(u,i,t);if(_)return`<div class="${c}"${n}>${_}</div>`}const x=t.type==="i"?' class="slide-list-item-title"':"";return`<div class="${c}"${n}><p${x}>${oe(u)}</p></div>`}function tm(t){return`
    ${kn(t)}

    :root {
      --slide-bg: #ffffff;
      --slide-text: #1a1a1a;
      --slide-accent: #3b82f6;
      --slide-font: system-ui, -apple-system, sans-serif;
    }
    [data-theme="dark"] {
      --slide-bg: #121214;
      --slide-text: #e2e8f0;
      --slide-accent: #60a5fa;
    }

    /* 1. 默认科技主题 Default */
    [data-slidev-theme="default"],
    .slidev-theme-default {
      --slide-font: system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "PingFang SC", "Microsoft YaHei", sans-serif;
      --slide-accent: #10b981;
    }
    [data-theme="light"][data-slidev-theme="default"],
    [data-theme="light"] .slidev-theme-default {
      --slide-bg: #ffffff;
      --slide-text: #1e293b;
      --slide-accent: #059669;
    }
    [data-theme="dark"][data-slidev-theme="default"],
    [data-theme="dark"] .slidev-theme-default {
      --slide-bg: #121214;
      --slide-text: #e2e8f0;
      --slide-accent: #34d399;
    }
    .slidev-theme-default .layout-cover h1,
    .slidev-theme-default .layout-cover .slide-block h1 {
      font-size: 3.8rem !important;
      font-weight: 800 !important;
      line-height: 1.15 !important;
      letter-spacing: -0.025em !important;
      margin-bottom: 18px !important;
      background: linear-gradient(135deg, #10b981, #06b6d4) !important;
      -webkit-background-clip: text !important;
      -webkit-text-fill-color: transparent !important;
    }
    .slidev-theme-default .layout-cover h2,
    .slidev-theme-default .layout-cover .slide-block h2 {
      font-size: 1.85rem !important;
      font-weight: 600 !important;
      opacity: 0.85 !important;
      margin-bottom: 12px !important;
    }
    .slidev-theme-default .layout-cover p,
    .slidev-theme-default .layout-cover .slide-block p {
      font-size: 1.45rem !important;
      line-height: 1.5 !important;
      opacity: 0.85 !important;
    }

    /* 2. 优雅衬线主题 Seriph */
    [data-slidev-theme="seriph"],
    .slidev-theme-seriph {
      --slide-font: "PT Serif", "Charter", "Georgia", "Cambria", "Times New Roman", "Source Han Serif SC", "Noto Serif SC", "Songti SC", "SimSun", serif;
      --slide-accent: #b45309;
      letter-spacing: 0.015em;
    }
    [data-theme="light"][data-slidev-theme="seriph"],
    [data-theme="light"] .slidev-theme-seriph {
      --slide-bg: #fdfbf7;
      --slide-text: #2a2521;
      --slide-accent: #b45309;
    }
    [data-theme="dark"][data-slidev-theme="seriph"],
    [data-theme="dark"] .slidev-theme-seriph {
      --slide-bg: #1c1a17;
      --slide-text: #e8e3d9;
      --slide-accent: #f59e0b;
    }
    .slidev-theme-seriph,
    .slidev-theme-seriph .slide-content {
      font-family: var(--slide-font) !important;
      line-height: 1.72;
    }
    .slidev-theme-seriph h1,
    .slidev-theme-seriph h2,
    .slidev-theme-seriph h3 {
      font-family: var(--slide-font) !important;
      letter-spacing: 0.025em;
      font-weight: 700;
    }
    .slidev-theme-seriph .layout-cover h1 {
      background: none !important;
      -webkit-background-clip: initial !important;
      -webkit-text-fill-color: initial !important;
      color: var(--slide-accent) !important;
      font-size: 3.4rem !important;
      border-bottom: 2px solid var(--slide-accent);
      display: inline-block;
      padding-bottom: 10px;
    }

    /* 3. 极简发布会主题 Apple Basic */
    [data-slidev-theme="apple-basic"],
    .slidev-theme-apple-basic {
      --slide-font: -apple-system, "SF Pro Display", "SF Pro Text", BlinkMacSystemFont, "PingFang SC", "Helvetica Neue", sans-serif;
      --slide-accent: #0071e3;
    }
    [data-theme="light"][data-slidev-theme="apple-basic"],
    [data-theme="light"] .slidev-theme-apple-basic {
      --slide-bg: #ffffff;
      --slide-text: #1d1d1f;
      --slide-accent: #0071e3;
    }
    [data-theme="dark"][data-slidev-theme="apple-basic"],
    [data-theme="dark"] .slidev-theme-apple-basic {
      --slide-bg: #000000;
      --slide-text: #f5f5f7;
      --slide-accent: #2997ff;
    }
    .slidev-theme-apple-basic,
    .slidev-theme-apple-basic .slide-content {
      font-family: var(--slide-font) !important;
    }
    .slidev-theme-apple-basic h1,
    .slidev-theme-apple-basic h2,
    .slidev-theme-apple-basic h3 {
      letter-spacing: -0.035em;
      font-weight: 800;
    }
    .slidev-theme-apple-basic .layout-cover h1 {
      background: none !important;
      -webkit-background-clip: initial !important;
      -webkit-text-fill-color: initial !important;
      color: var(--slide-text) !important;
      font-size: 3.8rem !important;
      letter-spacing: -0.04em !important;
    }
    .slidev-theme-apple-basic .layout-cover p {
      color: #86868b !important;
      font-size: 1.35rem !important;
    }

    * { box-sizing: border-box; margin: 0; padding: 0; }
    html, body {
      width: 100%; height: 100%; overflow: hidden;
      background: #0f1115; font-family: var(--slide-font);
      display: flex; justify-content: center; align-items: center;
    }
    #app { width: 100%; height: 100%; position: relative; overflow: hidden; }
    .slide-viewport {
      position: absolute; left: 50%; top: 50%;
      background: var(--slide-bg); color: var(--slide-text);
      box-shadow: 0 10px 30px rgba(0,0,0,0.5); border-radius: 8px; overflow: hidden;
      display: flex; flex-direction: column; flex-shrink: 0;
      transform: translate(-50%, -50%) scale(var(--slidev-slide-scale, 1));
      transform-origin: center center; will-change: transform;
      transition: background 0.3s ease, color 0.3s ease, border-radius 0.2s ease, box-shadow 0.2s ease;
    }
    :fullscreen .slide-viewport, .is-fullscreen .slide-viewport {
      border-radius: 0 !important; box-shadow: none !important;
    }
    .slide-content {
      position: relative;
      width: 100%;
      height: 100%;
      min-height: 100%;
      flex: 1 1 0%;
      padding: var(--slidev-padding-y, 32px) var(--slidev-padding-x, 48px);
      display: flex;
      flex-direction: column;
      overflow: hidden;
      box-sizing: border-box;
    }

    /* 间距预设风格 */
    .slide-content.spacing-compact,
    .slide-viewport[data-spacing="compact"] .slide-content,
    [data-slidev-spacing="compact"] {
      --slidev-padding-y: 20px;
      --slidev-padding-x: 36px;
      --slidev-header-gap: 10px;
      --slidev-title-margin-bottom: 6px;
    }
    .slide-content.spacing-normal,
    .slide-viewport[data-spacing="normal"] .slide-content,
    [data-slidev-spacing="normal"] {
      --slidev-padding-y: 32px;
      --slidev-padding-x: 48px;
      --slidev-header-gap: 16px;
      --slidev-title-margin-bottom: 10px;
    }
    .slide-content.spacing-loose,
    .slide-viewport[data-spacing="loose"] .slide-content,
    [data-slidev-spacing="loose"] {
      --slidev-padding-y: 48px;
      --slidev-padding-x: 56px;
      --slidev-header-gap: 24px;
      --slidev-title-margin-bottom: 16px;
    }

    .layout-cover { justify-content: center; align-items: center; text-align: center; }
    .layout-cover h1, .layout-cover .slide-block h1 { font-size: 3.8rem !important; font-weight: 800 !important; line-height: 1.15 !important; letter-spacing: -0.025em !important; margin-bottom: 16px !important; }
    .layout-cover h2, .layout-cover .slide-block h2 { font-size: 1.85rem !important; font-weight: 600 !important; opacity: 0.85 !important; margin-bottom: 12px !important; }
    .layout-cover p, .layout-cover .slide-block p { font-size: 1.45rem !important; line-height: 1.5 !important; opacity: 0.85 !important; }
    .two-cols-left, .two-cols-right { min-width: 0; width: 100%; display: flex; flex-direction: column; box-sizing: border-box; overflow-wrap: break-word; word-break: break-word; }
    .pdf-two-cols-wrapper,
    .layout-two-cols-grid,
    .layout-cols-wrapper,
    .layout-cols-grid {
      display: grid;
      grid-template-columns: var(--slide-grid-cols, minmax(0, 1fr) minmax(0, 1fr));
      grid-template-rows: minmax(0, 1fr) !important;
      gap: 32px;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      overflow: hidden !important;
    }
    .layout-cols-header-container,
    .layout-two-cols-header-container,
    .layout-three-cols-header-container {
      display: flex;
      flex-direction: column;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      overflow: hidden !important;
    }
    .layout-header-section {
      width: 100%;
      margin-bottom: var(--slidev-header-gap, 16px) !important;
      flex-shrink: 0;
    }
    .layout-header-section h1,
    .layout-header-section h2,
    .layout-header-section h3 {
      margin-bottom: var(--slidev-title-margin-bottom, 10px) !important;
    }
    .pdf-three-cols-wrapper,
    .layout-three-cols-grid {
      display: grid;
      grid-template-columns: var(--slide-grid-cols, minmax(0, 1fr) minmax(0, 1fr) minmax(0, 1fr));
      grid-template-rows: minmax(0, 1fr) !important;
      gap: 24px;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      box-sizing: border-box;
      overflow: hidden !important;
    }
    .pdf-col {
      display: flex;
      flex-direction: column;
      gap: 14px;
      min-width: 0;
      width: 100%;
      max-width: 100%;
      height: 100%;
      max-height: 100%;
      min-height: 0;
      justify-content: flex-start;
      box-sizing: border-box;
      overflow: hidden;
      overflow-wrap: break-word;
      word-break: break-word;
      white-space: normal;
    }
    .pdf-col * {
      overflow-wrap: break-word;
      word-break: break-word;
      box-sizing: border-box;
    }
    /* 表头多栏内超级块子块首个列表项去圆点后居中显示标题/首行文本 */
    .layout-cols-wrapper .pdf-col > *:first-child .slide-list-item-title,
    .layout-cols-wrapper .pdf-col > *:first-child :is(h1, h2, h3, h4, h5, h6),
    .layout-cols-wrapper .pdf-col > *:first-child p.slide-list-item-title,
    .layout-cols-wrapper .pdf-col > *:first-child p:first-of-type,
    .layout-cols-wrapper .pdf-col > *:first-child p:first-child,
    .layout-cols-wrapper .pdf-col > *:first-child :is(ul, ol) > li:first-child,
    .layout-cols-wrapper .pdf-col > *:first-child .slide-list > .slide-list-item:first-child,
    .layout-cols-wrapper .pdf-col > *:first-child .pdf-list > li:first-child,
    .layout-cols-header-container .pdf-col > *:first-child .slide-list-item-title,
    .layout-cols-header-container .pdf-col > *:first-child :is(h1, h2, h3, h4, h5, h6),
    .layout-cols-header-container .pdf-col > *:first-child p.slide-list-item-title,
    .layout-cols-header-container .pdf-col > *:first-child p:first-of-type,
    .layout-cols-header-container .pdf-col > *:first-child p:first-child,
    .layout-cols-header-container .pdf-col > *:first-child :is(ul, ol) > li:first-child,
    .layout-cols-header-container .pdf-col > *:first-child .slide-list > .slide-list-item:first-child,
    .layout-cols-header-container .pdf-col > *:first-child .pdf-list > li:first-child,
    .two-cols-left > *:first-child .slide-list-item-title,
    .two-cols-left > *:first-child :is(h1, h2, h3, h4, h5, h6),
    .two-cols-left > *:first-child p:first-of-type,
    .two-cols-left > *:first-child :is(ul, ol) > li:first-child,
    .two-cols-right > *:first-child .slide-list-item-title,
    .two-cols-right > *:first-child :is(h1, h2, h3, h4, h5, h6),
    .two-cols-right > *:first-child p:first-of-type,
    .two-cols-right > *:first-child :is(ul, ol) > li:first-child,
    .slidev-col-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    .slidev-col-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      list-style: none !important;
      list-style-type: none !important;
      text-align: center !important;
      margin-left: 0 !important;
      padding-left: 0 !important;
      width: 100% !important;
    }

    /* 彻底清除首个列表项的原生圆点 Marker */
    :is(.layout-cols-wrapper, .layout-cols-header-container) .pdf-col > *:first-child :is(ul, ol) > li:first-child::marker,
    .two-cols-left > *:first-child :is(ul, ol) > li:first-child::marker,
    .two-cols-right > *:first-child :is(ul, ol) > li:first-child::marker {
      content: "" !important;
      display: none !important;
    }

    /* 确保首个列表项内部内联与块级元素居中 */
    :is(.layout-cols-wrapper, .layout-cols-header-container) .pdf-col > *:first-child :is(ul, ol) > li:first-child *,
    .two-cols-left > *:first-child :is(ul, ol) > li:first-child *,
    .two-cols-right > *:first-child :is(ul, ol) > li:first-child * {
      text-align: center !important;
    }

    /* 栏内说明段落与列表项：左对齐，自然阅读排版 */
    .layout-cols-wrapper .pdf-col .slide-list-item-desc,
    .layout-cols-header-container .pdf-col .slide-list-item-desc,
    .two-cols-left .slide-list-item-desc,
    .two-cols-right .slide-list-item-desc,
    .layout-cols-wrapper .pdf-col li:not(:first-child),
    .layout-cols-header-container .pdf-col li:not(:first-child),
    .two-cols-left li:not(:first-child),
    .two-cols-right li:not(:first-child) {
      text-align: left !important;
    }

    /* 全局特定标题大小规范化 (除封面外页首首个标题按 H2 1.7rem，表头多栏内首个标题按 H3 1.3rem) */
    [data-normalize-headings="true"] .slidev-page-first-heading-block :is(h1, h2, h3, h4, h5, h6),
    [data-normalize-headings="true"] .slidev-page-first-heading-block:is(h1, h2, h3, h4, h5, h6),
    [data-normalize-headings="true"] .slide-content:not(.layout-cover) > .pdf-block:first-child :is(h1, h2, h3, h4, h5, h6),
    [data-normalize-headings="true"] .slide-content:not(.layout-cover) > .layout-header-section .pdf-block:first-child :is(h1, h2, h3, h4, h5, h6),
    [data-normalize-headings="true"] .slide-content:not(.layout-cover) > :not(.layout-cols-wrapper):not(.pdf-two-cols-wrapper):not(.layout-image-cols-grid):first-child :is(h1, h2, h3, h4, h5, h6) {
      font-size: 1.7rem !important;
      font-weight: 600 !important;
      line-height: 1.25 !important;
      margin-bottom: 10px !important;
    }

    [data-normalize-headings="true"] .slidev-col-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .slidev-col-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] :is(.layout-cols-wrapper, .pdf-two-cols-wrapper, .layout-cols-header-container) .pdf-col > *:first-child :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      font-size: 1.3rem !important;
      font-weight: 600 !important;
      line-height: 1.3 !important;
      margin-bottom: 8px !important;
      text-align: center !important;
    }
    .pdf-col pre,
    .two-cols-left pre,
    .two-cols-right pre,
    .image-right-content pre,
    .image-left-content pre {
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      overflow-x: hidden !important;
      overflow-y: auto !important;
      max-width: 100% !important;
      box-sizing: border-box !important;
    }
    .slide-content.layout-image-right, .slide-content.layout-image-left {
      padding: 0;
      display: grid;
      grid-template-columns: var(--slide-grid-cols, minmax(0, 1fr) minmax(0, 1fr));
      grid-template-rows: 100%;
      width: 100%;
      height: 100%;
      position: absolute;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      box-sizing: border-box;
    }
    .image-right-content, .image-left-content {
      padding: 44px 50px;
      display: flex;
      flex-direction: column;
      justify-content: flex-start;
      overflow-y: auto;
      width: 100%;
      height: 100%;
      box-sizing: border-box;
    }
    .image-right-img-container, .image-left-img-container {
      width: 100%;
      height: 100%;
      overflow: hidden;
      position: relative;
      background: #18181b;
      display: flex;
      align-items: center;
      justify-content: center;
    }
    .image-right-img, .image-left-img {
      width: 100%;
      height: 100%;
      object-fit: cover;
      object-position: center;
      display: block;
    }
    .slide-block { margin-bottom: 14px; line-height: 1.6; }
    .slide-block h1 { font-size: 2.2rem; margin-bottom: 12px; }
    .slide-block h2 { font-size: 1.7rem; margin-bottom: 10px; }
    .slide-block p { font-size: 1.15rem; }
    .slide-block ul, .slide-block ol, .pdf-list {
      padding-left: 28px;
      margin: 8px 0;
      display: flex;
      flex-direction: column;
      gap: 6px;
    }
    .slide-block li, .pdf-list li {
      font-size: 1.15rem;
      line-height: 1.6;
    }
    .pdf-task-item {
      list-style: none;
      margin-left: -20px;
      display: flex;
      align-items: center;
      gap: 8px;
    }
    .pdf-task-item input[type="checkbox"] {
      width: 1.15em;
      height: 1.15em;
      cursor: pointer;
    }

    /* 两栏与三栏及多栏（超级块分栏）布局：紧凑自然行距，子列表保留圆点与层级缩进 */
    .layout-two-cols ul,
    .layout-cols-header ul,
    .layout-two-cols-header ul,
    .layout-three-cols ul,
    .layout-three-cols-header ul,
    .two-cols-left ul,
    .two-cols-right ul,
    .three-cols-col ul,
    .col ul,
    .pdf-col ul,
    .layout-two-cols-grid .pdf-list,
    .layout-three-cols-grid .pdf-list,
    .layout-cols-grid .pdf-list,
    .layout-two-cols-grid .pdf-list--unordered,
    .layout-three-cols-grid .pdf-list--unordered,
    .layout-cols-grid .pdf-list--unordered {
      list-style: disc !important;
      list-style-type: disc !important;
      padding-left: 1.25em !important;
      margin-left: 0 !important;
      margin-top: 0 !important;
      margin-bottom: 8px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: block !important;
    }

    .layout-two-cols ol,
    .layout-cols-header ol,
    .layout-two-cols-header ol,
    .layout-three-cols ol,
    .layout-three-cols-header ol,
    .two-cols-left ol,
    .two-cols-right ol,
    .three-cols-col ol,
    .col ol,
    .pdf-col ol,
    .layout-two-cols-grid .pdf-list--ordered,
    .layout-three-cols-grid .pdf-list--ordered,
    .layout-cols-grid .pdf-list--ordered {
      list-style: decimal !important;
      list-style-type: decimal !important;
      padding-left: 1.25em !important;
      margin-left: 0 !important;
      margin-top: 0 !important;
      margin-bottom: 8px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: block !important;
    }

    .layout-two-cols li,
    .layout-cols-header li,
    .layout-two-cols-header li,
    .layout-three-cols li,
    .layout-three-cols-header li,
    .two-cols-left li,
    .two-cols-right li,
    .three-cols-col li,
    .col li,
    .pdf-col li,
    .pdf-col .pdf-list-item {
      padding-left: 0.2em !important;
      margin-left: 0 !important;
      margin-bottom: 6px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: list-item !important;
      line-height: 1.6 !important;
    }

    .layout-two-cols ul ul,
    .layout-three-cols ul ul,
    .three-cols-col ul ul,
    .pdf-col ul ul {
      list-style: circle !important;
      list-style-type: circle !important;
      padding-left: 1.25em !important;
      margin-top: 4px !important;
      margin-bottom: 4px !important;
    }

    /* 列表项内嵌标题与说明排版 */
    .slide-list-item-title,
    .pdf-list li > h1,
    .pdf-list li > h2,
    .pdf-list li > h3,
    .pdf-list li > h4,
    .pdf-list li > h5,
    .pdf-list li > h6,
    li > h1.slide-list-item-title,
    li > h2.slide-list-item-title,
    li > h3.slide-list-item-title,
    li > h4.slide-list-item-title {
      margin-top: 2px !important;
      margin-bottom: 6px !important;
      line-height: 1.35 !important;
      font-weight: 700 !important;
    }
    .pdf-list li > h1, li > h1.slide-list-item-title { font-size: 1.6rem !important; }
    .pdf-list li > h2, li > h2.slide-list-item-title { font-size: 1.4rem !important; }
    .pdf-list li > h3, li > h3.slide-list-item-title { font-size: 1.22rem !important; }
    .pdf-list li > h4, li > h4.slide-list-item-title { font-size: 1.1rem !important; }
    .slide-list-item-desc,
    .pdf-list li > p {
      margin-top: 4px !important;
      margin-bottom: 6px !important;
      font-size: 1.05rem;
      line-height: 1.55;
      opacity: 0.92;
    }

    /* 多媒体（GIF动图、静态图片、MP4视频）全视口最大化自适应且不超出视口 */
    .slide-media-block,
    .slide-media-container,
    .slide-video-container,
    .slide-block--media,
    .slide-block--image,
    .slide-block--video,
    .slide-block:has(> img),
    .slide-block:has(> .slide-media-container),
    .slide-block:has(> p > img:only-child),
    .slide-block:has(> .slide-video-container),
    .slide-block:has(> video) {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      min-width: 0 !important;
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
      justify-content: center !important;
      width: 100% !important;
      height: 100% !important;
      max-height: 100% !important;
      overflow: hidden !important;
      margin: 4px 0 !important;
      box-sizing: border-box !important;
    }

    .two-cols-left > .slide-block,
    .two-cols-right > .slide-block,
    .three-cols-col > .slide-block,
    .pdf-col > .slide-block,
    .pdf-col .slide-block {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      max-height: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      width: 100% !important;
      height: 100% !important;
      box-sizing: border-box !important;
      overflow: hidden !important;
      margin-bottom: 0 !important;
    }

    /* 列内列表项的标题与段落文字：固定高度，不压缩 */
    .two-cols-left .slide-list-item-title,
    .two-cols-right .slide-list-item-title,
    .three-cols-col .slide-list-item-title,
    .pdf-col .slide-list-item-title,
    .two-cols-left h1, .two-cols-left h2, .two-cols-left h3, .two-cols-left h4, .two-cols-left h5, .two-cols-left h6,
    .two-cols-right h1, .two-cols-right h2, .two-cols-right h3, .two-cols-right h4, .two-cols-right h5, .two-cols-right h6,
    .three-cols-col h1, .three-cols-col h2, .three-cols-col h3, .three-cols-col h4, .three-cols-col h5, .three-cols-col h6,
    .pdf-col h1, .pdf-col h2, .pdf-col h3, .pdf-col h4, .pdf-col h5, .pdf-col h6,
    .three-cols-col .slide-list-item-desc,
    .pdf-col .slide-list-item-desc {
      flex: 0 0 auto !important;
      margin-top: 0 !important;
      margin-bottom: 6px !important;
    }

    /* 列内媒体容器：填满标题下方所有剩余垂直空间，纵向顶部对齐，横向居中，无溢出 */
    .two-cols-left .slide-list-media,
    .two-cols-right .slide-list-media,
    .three-cols-col .slide-list-media,
    .pdf-col .slide-list-media,
    .two-cols-left .slide-video-container,
    .two-cols-right .slide-video-container,
    .three-cols-col .slide-video-container,
    .pdf-col .slide-video-container,
    .two-cols-left .slide-media-container,
    .two-cols-right .slide-media-container,
    .three-cols-col .slide-media-container,
    .pdf-col .slide-media-container {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      min-width: 0 !important;
      width: 100% !important;
      height: 100% !important;
      max-height: 100% !important;
      max-width: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
      justify-content: flex-start !important;
      overflow: hidden !important;
      margin: 0 !important;
      padding: 0 !important;
      box-sizing: border-box !important;
    }

    /* 列内多媒体播放器：以 contain 模式等比缩放完整可见，绝对不超高超宽、不产生遮挡与滚动条 */
    .two-cols-left video,
    .two-cols-right video,
    .three-cols-col video,
    .pdf-col video,
    .two-cols-left img,
    .two-cols-right img,
    .three-cols-col img,
    .pdf-col img,
    .two-cols-left .slide-video-player,
    .two-cols-right .slide-video-player,
    .three-cols-col .slide-video-player,
    .pdf-col .slide-video-player,
    .layout-three-cols-grid video,
    .layout-two-cols-grid video,
    .layout-three-cols-grid img,
    .layout-two-cols-grid img {
      max-width: 100% !important;
      max-height: 100% !important;
      width: auto !important;
      height: auto !important;
      min-width: 0 !important;
      min-height: 0 !important;
      object-fit: contain !important;
      display: block !important;
      margin: 0 auto !important;
      cursor: zoom-in;
    }

    .slide-block img,
    .slide-media-img,
    .slide-media-container img,
    .slide-video-player,
    video.slide-video-player,
    .slide-block video {
      max-width: 100% !important;
      max-height: 100% !important;
      width: auto !important;
      height: auto !important;
      min-width: 0 !important;
      min-height: 0 !important;
      object-fit: contain !important;
      display: block !important;
      margin: 0 auto !important;
      border-radius: 8px;
      box-shadow: 0 4px 16px rgba(0, 0, 0, 0.16);
      background: transparent;
      outline: none;
      cursor: zoom-in;
    }

    .slide-list-media {
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
      justify-content: flex-start !important;
      width: 100% !important;
      max-width: 100% !important;
      height: 100% !important;
      max-height: 100% !important;
      flex: 1 1 0% !important;
      margin-top: 4px !important;
      margin-bottom: 4px !important;
      min-height: 0 !important;
      overflow: hidden !important;
      box-sizing: border-box !important;
    }
    .slide-list-media img,
    .slide-list-media video,
    .slide-list-media .list-item-gif,
    .slide-list-media .slide-video-player {
      max-width: 100% !important;
      max-height: 100% !important;
      width: auto !important;
      height: auto !important;
      min-width: 0 !important;
      min-height: 0 !important;
      object-fit: contain !important;
      border-radius: 6px !important;
      box-shadow: 0 3px 12px rgba(0, 0, 0, 0.14) !important;
      display: block !important;
      margin: 0 auto !important;
      cursor: zoom-in;
    }

    .slide-block:has(.slide-list-media) {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      height: 100% !important;
      max-height: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      overflow: hidden !important;
    }
    .slide-block:has(.slide-list-media) .pdf-list,
    .slide-block:has(.slide-list-media) ul,
    .slide-block:has(.slide-list-media) ol {
      display: block !important;
      flex: 1 1 auto;
      min-height: 0;
      max-height: 100%;
      overflow: visible !important;
      list-style: disc !important;
      list-style-type: disc !important;
    }
    .slide-block:has(.slide-list-media) li,
    .slide-block:has(.slide-list-media) .slide-list-item,
    .slide-block:has(.slide-list-media) .pdf-list-item,
    .slide-block:has(.slide-media-container) li,
    .slide-block:has(.slide-video-container) li,
    .layout-cols-wrapper li:has(.slide-list-media),
    .layout-cols-header-container li:has(.slide-list-media),
    .two-cols-left li:has(.slide-list-media),
    .two-cols-right li:has(.slide-list-media),
    .three-cols-col li:has(.slide-list-media),
    .pdf-col li:has(.slide-list-media),
    li:has(.slide-list-media),
    li:has(.slide-video-container),
    li:has(.slide-media-container) {
      display: list-item !important;
      list-style-type: disc !important;
      flex: 0 0 auto !important;
      height: auto !important;
      max-height: none !important;
      overflow: visible !important;
      margin-bottom: 6px !important;
    }

    .layout-two-cols .slide-media-block,
    .layout-two-cols .slide-video-container,
    .layout-two-cols .slide-media-container,
    .layout-three-cols .slide-media-block,
    .layout-three-cols .slide-video-container,
    .layout-three-cols .slide-media-container {
      max-width: 100% !important;
      max-height: 100% !important;
      width: 100% !important;
      height: 100% !important;
      min-width: 0 !important;
      min-height: 0 !important;
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
      justify-content: flex-start !important;
      overflow: hidden !important;
    }

    /* Lightbox 大图与视频灯箱模态窗口 */
    .slidev-lightbox {
      position: fixed;
      top: 0;
      left: 0;
      width: 100vw;
      height: 100vh;
      background: rgba(0, 0, 0, 0.88);
      backdrop-filter: blur(8px);
      z-index: 999999;
      display: none;
      align-items: center;
      justify-content: center;
      cursor: zoom-out;
      opacity: 0;
      transition: opacity 0.2s cubic-bezier(0.16, 1, 0.3, 1);
    }
    .slidev-lightbox.active {
      display: flex;
      opacity: 1;
    }
    .slidev-lightbox-content {
      position: relative;
      max-width: 92vw;
      max-height: 92vh;
      display: flex;
      align-items: center;
      justify-content: center;
      cursor: default;
    }
    .slidev-lightbox-img {
      max-width: 92vw;
      max-height: 92vh;
      object-fit: contain;
      border-radius: 8px;
      box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.75);
    }
    .slidev-lightbox-video {
      max-width: 92vw;
      max-height: 92vh;
      border-radius: 8px;
      box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.75);
    }
    .slidev-lightbox-close {
      position: absolute;
      top: 24px;
      right: 28px;
      width: 40px;
      height: 40px;
      background: rgba(255, 255, 255, 0.2);
      border: 1px solid rgba(255, 255, 255, 0.35);
      border-radius: 50%;
      color: #fff;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 22px;
      cursor: pointer;
      transition: background 0.2s, transform 0.2s;
      z-index: 1000000;
    }
    .slidev-lightbox-close:hover {
      background: rgba(255, 255, 255, 0.35);
      transform: scale(1.05);
    }

    img.slide-inline-img {
      max-width: 100% !important;
      max-height: min(320px, 40vh) !important;
      object-fit: contain !important;
      vertical-align: middle;
      border-radius: 4px;
    }
    kbd {
      display: inline-block;
      padding: 2px 7px;
      font-family: ui-monospace, SFMono-Regular, "SF Mono", Menlo, Consolas, "Liberation Mono", monospace;
      font-size: 0.85em;
      font-weight: 600;
      line-height: 1.25;
      color: inherit;
      background: rgba(125, 125, 125, 0.12);
      border: 1px solid rgba(125, 125, 125, 0.35);
      border-bottom-width: 2px;
      border-radius: 5px;
      box-shadow: 0 1px 2px rgba(0, 0, 0, 0.12);
      margin: 0 2px;
      vertical-align: middle;
      white-space: nowrap;
    }
    [data-theme="dark"] kbd, .theme-dark kbd {
      background: rgba(255, 255, 255, 0.1);
      border-color: rgba(255, 255, 255, 0.25);
      border-bottom-color: rgba(255, 255, 255, 0.4);
      color: #f1f5f9;
      box-shadow: 0 1px 2px rgba(0, 0, 0, 0.4);
    }
    .slide-block pre,
    pre {
      background: rgba(0, 0, 0, 0.1);
      padding: 12px;
      border-radius: 6px;
      font-family: "JetBrains Mono", Consolas, monospace;
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      overflow-x: hidden !important;
      overflow-y: auto !important;
      max-width: 100% !important;
      box-sizing: border-box !important;
    }
    .slide-block pre code,
    pre code {
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      display: block !important;
      width: 100% !important;
      box-sizing: border-box !important;
    }
    .code-line {
      display: flex !important;
      align-items: flex-start !important;
      width: 100% !important;
      box-sizing: border-box !important;
      line-height: 1.6;
    }
    .code-line .line-no {
      display: inline-block !important;
      flex-shrink: 0 !important;
      min-width: 2.2em !important;
      text-align: right !important;
      margin-right: 12px !important;
      user-select: none !important;
      opacity: 0.45 !important;
    }
    .code-line .line-content {
      flex: 1 1 0% !important;
      min-width: 0 !important;
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
    }
    /* 弱提示滚动条样式 */
    * {
      scrollbar-width: thin;
      scrollbar-color: rgba(255, 255, 255, 0.20) transparent;
    }
    *::-webkit-scrollbar {
      width: 4px;
      height: 4px;
    }
    *::-webkit-scrollbar-track {
      background: transparent;
    }
    *::-webkit-scrollbar-thumb {
      background: rgba(255, 255, 255, 0.20);
      border-radius: 2px;
      transition: background 0.2s ease;
    }
    *:hover::-webkit-scrollbar-thumb,
    *::-webkit-scrollbar-thumb:hover {
      background: rgba(255, 255, 255, 0.45);
    }
    /* Slidev Micro-motion Keyframes & Presets */
    @keyframes slidevMotionFadeIn { from { opacity: 0; } to { opacity: 1; } }
    @keyframes slidevMotionSlideUp { from { opacity: 0; transform: translateY(40px); } to { opacity: 1; transform: translateY(0); } }
    @keyframes slidevMotionSlideDown { from { opacity: 0; transform: translateY(-40px); } to { opacity: 1; transform: translateY(0); } }
    @keyframes slidevMotionSlideLeft { from { opacity: 0; transform: translateX(40px); } to { opacity: 1; transform: translateX(0); } }
    @keyframes slidevMotionSlideRight { from { opacity: 0; transform: translateX(-40px); } to { opacity: 1; transform: translateX(0); } }
    @keyframes slidevMotionZoomIn { from { opacity: 0; transform: scale(0.8); } to { opacity: 1; transform: scale(1); } }
    @keyframes slidevMotionBounce {
      0% { opacity: 0; transform: translateY(40px); }
      60% { opacity: 1; transform: translateY(-8px); }
      80% { transform: translateY(4px); }
      100% { transform: translateY(0); }
    }
    .slidev-motion-fade-in { animation: slidevMotionFadeIn var(--motion-duration, 0.4s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slidev-motion-slide-up { animation: slidevMotionSlideUp var(--motion-duration, 0.45s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slidev-motion-slide-down { animation: slidevMotionSlideDown var(--motion-duration, 0.45s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slidev-motion-slide-left { animation: slidevMotionSlideLeft var(--motion-duration, 0.45s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slidev-motion-slide-right { animation: slidevMotionSlideRight var(--motion-duration, 0.45s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slidev-motion-zoom-in, .slidev-motion-pop { animation: slidevMotionZoomIn var(--motion-duration, 0.4s) cubic-bezier(0.34, 1.56, 0.64, 1) var(--motion-delay, 0s) both; }
    .slidev-motion-bounce { animation: slidevMotionBounce var(--motion-duration, 0.6s) cubic-bezier(0.34, 1.56, 0.64, 1) var(--motion-delay, 0s) both; }
    .controls {
      position: absolute; bottom: 16px; display: flex; gap: 12px; align-items: center;
      background: rgba(24, 24, 27, 0.8); backdrop-filter: blur(8px);
      padding: 6px 18px; border-radius: 20px; color: #fff; font-size: 13px; z-index: 10;
    }
    .controls button { background: transparent; border: none; color: inherit; cursor: pointer; padding: 2px 6px; }

    /* Slidev Native Icons & Interactive Buttons */
    .slidev-icon-btn {
      display: inline-flex !important; flex-direction: row !important; align-items: center !important; justify-content: center !important;
      padding: 0.35rem 0.5rem; border-radius: 0.375rem; background: transparent;
      border: 1px solid transparent; color: inherit; font-size: inherit; line-height: 1;
      cursor: pointer; opacity: 0.8; transition: all 0.2s ease; text-decoration: none;
      vertical-align: middle; user-select: none; margin: 0 4px;
    }
    .slidev-icon-btn:hover { opacity: 1; background: rgba(255, 255, 255, 0.12); border-color: rgba(255, 255, 255, 0.15); }

    /* 组件从上到下按顺序流式渲染，避免相互重叠 */
    .slide-block > div + div { margin-top: 14px; }

    /* 同一个 div 内的按钮/链接从左到右水平渲染 */
    .slide-block div:has(> .slidev-icon-btn),
    .slide-block div:has(> button),
    .slide-block [class*="abs-"],
    .slidev-btn-row {
      display: inline-flex !important;
      flex-direction: row !important;
      align-items: center !important;
      justify-content: center !important;
      flex-wrap: wrap !important;
      gap: 8px !important;
    }

    /* Position Shortcuts 适配：在组件流中保持从上到下排列，不脱离流产生重叠 */
    .slide-block .abs-br,
    .slide-block .abs-bl,
    .slide-block .abs-tr,
    .slide-block .abs-tl,
    .slide-block [class*="abs-"] {
      position: relative !important;
      bottom: auto !important;
      right: auto !important;
      top: auto !important;
      left: auto !important;
      margin: 0.75rem auto !important;
    }

    .slide-block--absolute { position: relative !important; margin-bottom: 14px !important; padding: 0 !important; background: transparent !important; }
    .slide-block--absolute:hover { background: transparent !important; }
    .mt-12 { margin-top: 3rem !important; }
    .py-1 { padding-top: 0.25rem !important; padding-bottom: 0.25rem !important; }
    .m-6 { margin: 1.5rem !important; }
    .text-xl { font-size: 1.25rem !important; }
    [hover\\:bg~="white"][hover\\:bg~="op-10"]:hover,
    [hover\\:bg="white op-10"]:hover { background: rgba(255, 255, 255, 0.1) !important; border-radius: 4px; }
    .cursor-pointer, [data-clickable] { cursor: pointer; }
    /* Slidev 规范链接排版 (继承正文颜色，虚线底边，Hover 时平滑点亮为主题色并转为实线) */
    .slide-content a:not(.slidev-ref-tag):not(.slidev-icon-btn):not(.slidev-toc-link),
    .slide-block a:not(.slidev-ref-tag):not(.slidev-icon-btn):not(.slidev-toc-link),
    a.slidev-link {
      color: inherit;
      text-decoration: none;
      border-bottom: 1px dashed currentColor;
      transition: color 0.2s cubic-bezier(0.4, 0, 0.2, 1),
                  border-color 0.2s cubic-bezier(0.4, 0, 0.2, 1),
                  border-bottom-style 0.2s cubic-bezier(0.4, 0, 0.2, 1);
      cursor: pointer;
    }
    .slide-content a:not(.slidev-ref-tag):not(.slidev-icon-btn):not(.slidev-toc-link):hover,
    .slide-block a:not(.slidev-ref-tag):not(.slidev-icon-btn):not(.slidev-toc-link):hover,
    a.slidev-link:hover {
      color: var(--slide-accent);
      border-bottom-style: solid;
      border-bottom-color: var(--slide-accent);
    }
    .slidev-ref-tag, a.slidev-ref-tag {
      display: inline-flex;
      align-items: center;
      background: color-mix(in srgb, var(--slide-accent) 12%, transparent);
      color: var(--slide-accent);
      border-radius: 4px;
      padding: 2px 8px;
      font-size: 0.88em;
      text-decoration: none;
      cursor: pointer;
      margin: 2px 4px 2px 0;
      border: 1px solid color-mix(in srgb, var(--slide-accent) 25%, transparent);
      transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
    }
    .slidev-ref-tag:hover, a.slidev-ref-tag:hover {
      background: color-mix(in srgb, var(--slide-accent) 22%, transparent);
      color: var(--slide-accent);
      border-color: color-mix(in srgb, var(--slide-accent) 55%, transparent);
      transform: translateY(-1px);
      box-shadow: 0 2px 8px color-mix(in srgb, var(--slide-accent) 20%, transparent);
    }
    .slidev-block-ref {
      display: block;
      padding: 10px 14px;
      background: color-mix(in srgb, var(--slide-accent) 8%, transparent);
      border-left: 3px solid var(--slide-accent);
      border-radius: 0 6px 6px 0;
      margin: 8px 0;
      cursor: pointer;
      transition: background 0.2s ease;
    }
    .slidev-block-ref:hover {
      background: color-mix(in srgb, var(--slide-accent) 15%, transparent);
    }`}function em(){return`    (function() {
      const data = window.__SLIDEV_DATA__ || { slides: [] };
      const slides = data.slides || [];
      let currentIndex = 0;

      const container = document.getElementById("slide-container");
      const pageNum = document.getElementById("page-num");
      const btnPrev = document.getElementById("btn-prev");
      const btnNext = document.getElementById("btn-next");
      const btnFullscreen = document.getElementById("btn-fullscreen");

      const baseWidth = 980;
      const aspectStr = (data.config && data.config.aspectRatio) || "16/9";
      let ratioNum = 16 / 9;
      if (aspectStr === "4/3") ratioNum = 4 / 3;
      else if (aspectStr === "16/10") ratioNum = 16 / 10;
      else if (typeof aspectStr === "string" && aspectStr.includes("/")) {
        const parts = aspectStr.split("/").map(Number);
        if (parts[0] && parts[1]) ratioNum = parts[0] / parts[1];
      }
      const baseHeight = Math.ceil(baseWidth / ratioNum);
      const viewport = document.getElementById("viewport");

      function updateScale() {
        if (!viewport) return;
        const isFull = !!document.fullscreenElement;
        const padX = isFull ? 0 : 20;
        const padY = isFull ? 0 : 32;
        const availW = Math.max(100, window.innerWidth - padX);
        const availH = Math.max(100, window.innerHeight - padY);
        const scale = Math.min(availW / baseWidth, availH / baseHeight);
        viewport.style.width = baseWidth + "px";
        viewport.style.height = baseHeight + "px";
        viewport.style.transform = "translate(-50%, -50%) scale(" + scale + ")";
        viewport.style.setProperty("--slidev-slide-scale", scale);
        if (isFull) document.body.classList.add("is-fullscreen");
        else document.body.classList.remove("is-fullscreen");
      }

      window.addEventListener("resize", updateScale);
      document.addEventListener("fullscreenchange", updateScale);

      function cleanCardListItemMarkdown(rawMarkdown) {
        if (!rawMarkdown) return "";
        let cleaned = rawMarkdown.replace(/^[ 	]*[-*+]s+|^[ 	]*d+.s+/, "");
        cleaned = cleaned.replace(/
[ 	]{2,4}/g, "
");
        return cleaned.trim();
      }

      function cleanColList(blocks) {
        const valid = (blocks || []).filter(b => Boolean((b.rawMarkdown || b.content || "").trim()));
        if (valid.length === 0) return valid;
        const first = valid[0];
        const md = (first.rawMarkdown || first.content || "").trim();
        const isList = /^(?:[-*+]|d+.)s+/.test(md) || first.type === "i" || first.type === "l";
        if (isList) {
          first.rawMarkdown = cleanCardListItemMarkdown(first.rawMarkdown || first.content || "");
          first.content = first.rawMarkdown;
        }
        return valid;
      }

      function renderBlock(block) {
        const div = document.createElement("div");
        div.className = "slide-block";
        if (block && block.motion && block.motion.preset && block.motion.preset !== "none") {
          div.classList.add("slidev-motion-" + block.motion.preset.toLowerCase());
          if (typeof block.motion.duration === "number" && block.motion.duration > 0) {
            div.style.setProperty("--motion-duration", block.motion.duration + "ms");
          }
          if (typeof block.motion.delay === "number" && block.motion.delay > 0) {
            div.style.setProperty("--motion-delay", block.motion.delay + "ms");
          }
        }
        const md = block.rawMarkdown || block.content || "";

        if (md.includes('class="slidev-block-ref"') || md.includes('class="slidev-ref-tag"')) {
          div.innerHTML = md;
          return div;
        }

        const CARBON_MAP = {
          'carbon:arrow-right': '<svg viewBox="0 0 32 32" width="1.2em" height="1.2em" fill="currentColor" style="display:inline-block;vertical-align:middle;"><path d="m18 6l-1.43 1.393L24.15 15H4v2h20.15l-7.58 7.573L18 26l10-10z"/></svg>',
          'carbon:arrow-left': '<svg viewBox="0 0 32 32" width="1.2em" height="1.2em" fill="currentColor" style="display:inline-block;vertical-align:middle;"><path d="m14 26l1.43-1.393L7.85 17H28v-2H7.85l7.58-7.573L14 6L4 16z"/></svg>',
          'carbon:edit': '<svg viewBox="0 0 32 32" width="1.2em" height="1.2em" fill="currentColor" style="display:inline-block;vertical-align:middle;"><path d="M2 26h28v2H2zM25.4 9c.8-.8.8-2 0-2.8l-3.6-3.6c-.8-.8-2-.8-2.8 0l-15 15V24h6.4l15-15zM20.4 4L24 7.6l-2.4 2.4l-3.6-3.6L20.4 4zM6 22v-3.6l11-11l3.6 3.6l-11 11H6z"/></svg>',
          'carbon:logo-github': '<svg viewBox="0 0 32 32" width="1.2em" height="1.2em" fill="currentColor" style="display:inline-block;vertical-align:middle;"><path fill-rule="evenodd" d="M16 2a14 14 0 0 0-4.43 27.28c.7.13 1-.3 1-.67v-2.38c-3.89.84-4.71-1.88-4.71-1.88a3.7 3.7 0 0 0-1.56-2.05c-1.27-.86.1-.85.1-.85a2.94 2.94 0 0 1 2.14 1.44a3 3 0 0 0 4.08 1.16a2.93 2.93 0 0 1 .89-1.87c-3.1-.35-6.36-1.55-6.36-6.9a5.4 5.4 0 0 1 1.44-3.75a5 5 0 0 1 .14-3.71s1.17-.38 3.85 1.43a13.3 13.3 0 0 1 7 0c2.67-1.81 3.84-1.43 3.84-1.43a5 5 0 0 1 .14 3.71a5.4 5.4 0 0 1 1.44 3.75c0 5.37-3.27 6.54-6.38 6.89a3.35 3.35 0 0 1 1.26 2.61v3.87c0 .38.26.81 1 .67A14 14 0 0 0 16 2"/></svg>'
        };

        if (/@\\w+=['"]|v-\\w+|<button|<a\\b|<carbon:|^<div/i.test(md)) {
          if (md.includes('abs-br') || md.includes('abs-bl') || md.includes('abs-tr') || md.includes('abs-tl') || md.includes('absolute')) {
            div.classList.add("slide-block--absolute");
          }
          let renderedHtml = md;
          for (const [tag, svg] of Object.entries(CARBON_MAP)) {
            const regex = new RegExp("<" + tag + "\\\\s*\\\\/?>", "gi");
            renderedHtml = renderedHtml.replace(regex, svg);
            const regexDash = new RegExp("<" + tag.replace(":", "-") + "\\\\s*\\\\/?>", "gi");
            renderedHtml = renderedHtml.replace(regexDash, svg);
          }
          div.innerHTML = renderedHtml;

          // 挂载交互事件监听
          const nextBtns = div.querySelectorAll('[\\\\@click*="nav.next"], [\\\\@click*="next"]');
          nextBtns.forEach(btn => {
            btn.style.cursor = "pointer";
            btn.addEventListener("click", (e) => {
              e.stopPropagation();
              renderSlide(currentIndex + 1);
            });
          });

          const prevBtns = div.querySelectorAll('[\\\\@click*="nav.prev"], [\\\\@click*="prev"]');
          prevBtns.forEach(btn => {
            btn.style.cursor = "pointer";
            btn.addEventListener("click", (e) => {
              e.stopPropagation();
              renderSlide(currentIndex - 1);
            });
          });

          return div;
        }

        const hasHeadingTag = /(?:^|
)s*#{1,6}s+/.test(md);

        if (md.startsWith("### ")) div.innerHTML = "<h3>" + md.slice(4) + "</h3>";
        else if (md.startsWith("## ")) div.innerHTML = "<h2>" + md.slice(3) + "</h2>";
        else if (md.startsWith("# ")) div.innerHTML = "<h1>" + md.slice(2) + "</h1>";
        else if (md.startsWith("\`\`\`")) {
          const customMaxHeight = block?.attributes?.["custom-slidev-max-height"] || block?.attrs?.["custom-slidev-max-height"] || block?.maxHeight || "";
          const heightStyle = customMaxHeight ? ' style="max-height:' + customMaxHeight + ';overflow-y:auto;"' : "";
          div.innerHTML = "<pre" + heightStyle + "><code>" + md.slice(3, -3) + "</code></pre>";
        }
        else if (md.startsWith("> ")) div.innerHTML = "<blockquote><p>" + md.slice(2) + "</p></blockquote>";
        else if ((/<video\b/i.test(md) || (block && (block.type === "video" || block.type === "NodeVideo"))) && !/^(s*)([-*+]|d+.)s+/m.test(md) && !hasHeadingTag && !md.includes("
")) {
          div.classList.add("slide-video-container", "slide-media-container", "slide-media-block");
          const isAutoplay = block && block.attributes && block.attributes["custom-slidev-autoplay"] === "true";
          const isLoop = block && block.attributes && block.attributes["custom-slidev-loop"] === "true";
          const isMuted = block && block.attributes && (block.attributes["custom-slidev-muted"] === "true" || isAutoplay);
          const hideControls = block && block.attributes && block.attributes["custom-slidev-controls"] === "false";
          let videoHtml = md;
          if (hideControls) videoHtml = videoHtml.replace(/\bcontrols(?:="[^"]*")?/gi, "").trim();
          else if (!videoHtml.includes("controls")) videoHtml = videoHtml.replace("<video", "<video controls");
          if (isAutoplay && !videoHtml.includes("autoplay")) videoHtml = videoHtml.replace("<video", "<video autoplay playsinline");
          if (isLoop && !videoHtml.includes("loop")) videoHtml = videoHtml.replace("<video", "<video loop");
          if (isMuted && !videoHtml.includes("muted")) videoHtml = videoHtml.replace("<video", "<video muted");
          videoHtml = videoHtml.replace("<video", '<video class="slide-video-player"');
          div.setAttribute("data-autoplay", isAutoplay ? "true" : "false");
          div.innerHTML = videoHtml;
        }
        else if (/^(s*)([-*+]|d+.)s+/m.test(md) || (md.includes("
") && /^(s*)([-*+]|d+.)s+/m.test(md.split("
").slice(1).join("
")))) {
          div.classList.add("pdf-list-item");
          const lines = md.split("
");
          let isOrdered = false;
          const items = [];
          const leadLines = [];
          for (let i = 0; i < lines.length; i++) {
            const line = lines[i];
            const tr = line.trim();
            if (!tr || /^{:.*?}$/.test(tr)) continue;
            const um = line.match(/^(s*)[-*+]s+(.*)$/);
            const om = line.match(/^(s*)d+.s+(.*)$/);
            if (um) {
              const indent = um[1].length;
              items.push({ type: "unordered", level: Math.floor(indent / 2), text: um[2], media: [] });
              continue;
            }
            if (om) {
              if (items.length === 0) isOrdered = true;
              const indent = om[1].length;
              items.push({ type: "ordered", level: Math.floor(indent / 2), text: om[2], media: [] });
              continue;
            }
            if (items.length > 0) {
              const im = tr.match(/^![(.*?)]((.*?))(?:{:?[^}]*})?$/);
              if (im) {
                const isGif = /.gif(?:?|$)/i.test(im[2]);
                items[items.length - 1].media.push('<div class="slide-list-media"><img alt="' + im[1] + '" src="' + im[2] + '" class="' + (isGif ? 'list-item-gif' : 'list-item-img') + '" /></div>');
                continue;
              }
              const hm = tr.match(/^<img\b[sS]*?/?>$/i);
              if (hm) {
                const cleanTr = tr.replace(/s+style="[^"]*"/gi, "");
                items[items.length - 1].media.push('<div class="slide-list-media">' + cleanTr + '</div>');
                continue;
              }
              if (/<video\b/i.test(tr)) {
                let vHtml = tr;
                if (!/</video>/i.test(vHtml)) {
                  while (i + 1 < lines.length && !/</video>/i.test(vHtml)) {
                    i++;
                    vHtml += " " + lines[i].trim();
                  }
                }
                const isAutoplay = block && block.attributes && block.attributes["custom-slidev-autoplay"] === "true";
                const isLoop = block && block.attributes && block.attributes["custom-slidev-loop"] === "true";
                const isMuted = block && block.attributes && (block.attributes["custom-slidev-muted"] === "true" || isAutoplay);
                const hideControls = block && block.attributes && block.attributes["custom-slidev-controls"] === "false";
                if (hideControls) vHtml = vHtml.replace(/\bcontrols(?:="[^"]*")?/gi, "").trim();
                else if (!vHtml.includes("controls")) vHtml = vHtml.replace("<video", "<video controls");
                if (isAutoplay && !vHtml.includes("autoplay")) vHtml = vHtml.replace("<video", "<video autoplay playsinline");
                if (isLoop && !vHtml.includes("loop")) vHtml = vHtml.replace("<video", "<video loop");
                if (isMuted && !vHtml.includes("muted")) vHtml = vHtml.replace("<video", "<video muted");
                vHtml = vHtml.replace("<video", '<video class="slide-video-player"');
                items[items.length - 1].media.push('<div class="slide-list-media slide-video-container slide-media-container" data-autoplay="' + (isAutoplay ? 'true' : 'false') + '">' + vHtml + '</div>');
                continue;
              }
              items[items.length - 1].text += "
" + tr;
            } else {
              leadLines.push(tr);
            }
          }

          let leadHtml = "";
          if (leadLines.length > 0) {
            const lParts = [];
            const firstL = leadLines[0];
            const fhm = firstL.match(/^(#{1,6})s+(.*)$/);
            if (fhm) {
              const lvl = fhm[1].length;
              let th = fhm[2].trim().replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
              lParts.push('<h' + lvl + ' class="slide-list-item-title">' + th + '</h' + lvl + '>');
            } else {
              let th = firstL.trim().replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
              lParts.push('<p class="slide-list-item-title">' + th + '</p>');
            }
            if (leadLines.length > 1) {
              const dLines = leadLines.slice(1);
              let pL = [];
              const flushLeadP = () => {
                if (pL.length > 0) {
                  let txt = pL.map(l => l.replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>")).join("<br/>");
                  lParts.push('<p class="slide-list-item-desc">' + txt + '</p>');
                  pL = [];
                }
              };
              for (const l of dLines) {
                const hm = l.match(/^(#{1,6})s+(.*)$/);
                if (hm) {
                  flushLeadP();
                  const lvl = hm[1].length;
                  let th = hm[2].trim().replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
                  lParts.push('<h' + lvl + ' class="slide-list-item-title">' + th + '</h' + lvl + '>');
                } else {
                  pL.push(l);
                }
              }
              flushLeadP();
            }
            leadHtml = lParts.join("
") + "
";
          }

          const tag = isOrdered ? "ol" : "ul";
          const listCls = isOrdered ? "pdf-list pdf-list--ordered" : "pdf-list pdf-list--unordered";
          const liHtml = items.map(it => {
            const med = it.media && it.media.length ? "
" + it.media.join("
") : "";
            const lines = (it.text || "").split("
").map(l => l.trim()).filter(Boolean);
            const hasHeading = lines.some(l => /^#{1,6}s+/.test(l));
            const lvl = it.level || 0;
            const nStyle = lvl > 0 ? ' style="margin-left:' + (lvl * 1.25).toFixed(2) + 'em;' + (it.type === 'unordered' ? 'list-style-type:' + (lvl % 2 === 1 ? 'circle' : 'square') + ' !important;' : '') + '"' : "";
            const nClass = lvl > 0 ? " slide-list-item--nested" : "";
            const clsAttr = nClass ? ' class="' + nClass.trim() + '"' : "";
            if (!hasHeading) {
              let h = lines.map(l => l.replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>")).join("<br/>");
              return '<li' + clsAttr + nStyle + '>' + h + med + '</li>';
            }
            const parts = [];
            let pLines = [];
            const flushP = () => {
              if (pLines.length > 0) {
                let ph = pLines.map(l => l.replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>")).join("<br/>");
                parts.push('<p class="slide-list-item-desc">' + ph + '</p>');
                pLines = [];
              }
            };
            for (const l of lines) {
              const hm = l.match(/^(#{1,6})s+(.*)$/);
              if (hm) {
                flushP();
                const hl = hm[1].length;
                let th = hm[2].trim().replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
                parts.push('<h' + hl + ' class="slide-list-item-title">' + th + '</h' + hl + '>');
              } else {
                pLines.push(l);
              }
            }
            flushP();
            return '<li' + clsAttr + nStyle + '>' + parts.join("
") + med + '</li>';
          }).join("
");
          div.innerHTML = leadHtml + "<" + tag + " class="" + listCls + "">
" + liHtml + "
</" + tag + ">";
        }
        else {
          // 复合块（包含换行、标题或媒体）高保真解析
          const lines = md.split(/\r?
/);
          const subBlocks = [];
          let current = [];
          for (let i = 0; i < lines.length; i++) {
            const line = lines[i];
            const trimmed = line.trim();
            if (/^#{1,6}s+/.test(trimmed)) {
              if (current.length > 0) { subBlocks.push(current.join("
")); current = []; }
              subBlocks.push(trimmed);
              continue;
            }
            if (!trimmed) {
              if (current.length > 0) { subBlocks.push(current.join("
")); current = []; }
              continue;
            }
            if (/^![.*?](.*?)$/.test(trimmed)) {
              if (current.length > 0) { subBlocks.push(current.join("
")); current = []; }
              subBlocks.push(trimmed);
              continue;
            }
            if (/<video\b/i.test(trimmed)) {
              if (current.length > 0) { subBlocks.push(current.join("
")); current = []; }
              let vRaw = trimmed;
              if (!/</video>/i.test(vRaw)) {
                while (i + 1 < lines.length && !/</video>/i.test(vRaw)) {
                  i++;
                  vRaw += "
" + lines[i];
                }
              }
              subBlocks.push(vRaw);
              continue;
            }
            current.push(line);
          }
          if (current.length > 0) subBlocks.push(current.join("
"));

          if (subBlocks.length > 1 || (subBlocks.length === 1 && /^#{1,6}s+/.test(subBlocks[0].trim()))) {
            let isFirstParagraph = true;
            const htmlParts = subBlocks.map(sub => {
              const t = sub.trim();
              if (!t) return "";
              const hm = t.match(/^(#{1,6})s+(.*)$/);
              if (hm) {
                isFirstParagraph = false;
                const hl = hm[1].length;
                let th = hm[2].trim().replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
                return '<h' + hl + ' class="slide-list-item-title">' + th + '</h' + hl + '>';
              }
              const im = t.match(/^![(.*?)]((.*?))$/);
              if (im) {
                return '<div class="slide-media-block slide-media-container slide-list-media"><img alt="' + im[1] + '" src="' + im[2] + '" class="slide-media-img" /></div>';
              }
              if (/<video\b/i.test(t)) {
                return '<div class="slide-media-block slide-video-container slide-media-container">' + t + '</div>';
              }
              if (isFirstParagraph) {
                isFirstParagraph = false;
                const subLines = t.split(/\r?
/).map(l => l.trim()).filter(Boolean);
                if (subLines.length === 1) {
                  let ph = subLines[0].replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
                  return '<p class="slide-list-item-title">' + ph + '</p>';
                }
                let titleHtml = subLines[0].replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
                let descHtml = subLines.slice(1).map(l => l.replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>")).join("<br/>");
                return '<p class="slide-list-item-title">' + titleHtml + '</p>
<p class="slide-list-item-desc">' + descHtml + '</p>';
              }
              let ph = t.replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
              return '<p class="slide-list-item-desc">' + ph + '</p>';
            }).filter(Boolean);
            div.innerHTML = htmlParts.join("
");
          } else {
            const imgMatch = md.match(/!\\[(.*?)\\]\\((.*?)\\)/);
            if (imgMatch) {
              div.classList.add("slide-media-container", "slide-media-block", "slide-block--image");
              div.innerHTML = '<img alt="' + imgMatch[1] + '" src="' + imgMatch[2] + '" class="slide-media-img" />';
            } else {
              let html = md.replace(/\\*\\*(.*?)\\*\\*/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
              const pCls = (block && (block.type === "i" || block.isColFirst)) ? ' class="slide-list-item-title"' : '';
              div.innerHTML = "<p" + pCls + ">" + html + "</p>";
            }
          }
        }
        return div;
      }

      function renderSlide(idx) {
        if (slides.length === 0) return;
        currentIndex = Math.max(0, Math.min(idx, slides.length - 1));
        const slide = slides[currentIndex];
        pageNum.textContent = (currentIndex + 1) + " / " + slides.length;

        const pageSp = slide.frontmatter?.spacing;
        const currentSpacing = (pageSp && pageSp !== "inherit") ? pageSp : (data.config?.spacing || "normal");
        container.className = "slide-content layout-" + (slide.frontmatter?.layout || "default") + " spacing-" + currentSpacing;
        if (viewport) viewport.setAttribute("data-spacing", currentSpacing);
        container.innerHTML = "";

        const z = typeof slide.frontmatter?.zoom === "number" && slide.frontmatter.zoom > 0 ? slide.frontmatter.zoom : 1;
        if (z !== 1) {
          container.style.width = (100 / z) + "%";
          container.style.height = (100 / z) + "%";
          container.style.transformOrigin = "top left";
          container.style.transform = "scale(" + z + ")";
        } else {
          container.style.width = "100%";
          container.style.height = "100%";
          container.style.transform = "none";
        }

        if (slide.frontmatter?.layout === "two-cols") {
          const leftCol = document.createElement("div");
          leftCol.className = "two-cols-left";
          const rightCol = document.createElement("div");
          rightCol.className = "two-cols-right";

          const blocks = (slide.blocks || []).filter(b => b.slot !== "slot-divider-right");
          let leftList = [];
          let rightList = [];
          for (const block of blocks) {
            if (block.slot === "right") rightList.push(block);
            else leftList.push(block);
          }
          leftList = cleanColList(leftList);
          rightList = cleanColList(rightList);
          for (const b of leftList) leftCol.appendChild(renderBlock(b));
          for (const b of rightList) rightCol.appendChild(renderBlock(b));
          container.appendChild(leftCol);
          container.appendChild(rightCol);
        } else if (slide.frontmatter?.layout === "cols-header" || slide.frontmatter?.layout === "two-cols-header" || slide.frontmatter?.layout === "three-cols-header") {
          const blocks = (slide.blocks || []).filter(b => b.slot !== "slot-divider-right");
          let headerBlocks = blocks.filter(b => b.slot === "header");
          if (headerBlocks.length === 0 && blocks.length > 0) {
            const candidate = blocks.find(b => b.type === "h" && (!b.slot || b.slot === "default"));
            if (candidate) headerBlocks = [candidate];
          }
          const rem = blocks.filter(b => !headerBlocks.includes(b));

          let targetCols = 2;
          if (slide.frontmatter?.layout === "three-cols-header") {
            targetCols = 3;
          } else if (slide.frontmatter?.layout === "two-cols-header") {
            targetCols = 2;
          } else {
            let maxCol = 0;
            for (const b of rem) {
              const m = (b.slot || "").match(/^col-(d+)$/i);
              if (m) maxCol = Math.max(maxCol, parseInt(m[1], 10));
            }
            if (maxCol >= 2) {
              targetCols = maxCol;
            } else if (slide.frontmatter?.layoutRatio) {
              const r = slide.frontmatter.layoutRatio.trim();
              if (r.includes(":")) {
                const parts = r.split(":").map(p => parseFloat(p.trim())).filter(n => !isNaN(n) && n > 0);
                if (parts.length >= 2) targetCols = parts.length;
              }
            }
          }

          const containerDiv = document.createElement("div");
          containerDiv.className = "layout-cols-header-container " + (targetCols === 2 ? "layout-two-cols-header-container" : (targetCols === 3 ? "layout-three-cols-header-container" : ""));
          const headerDiv = document.createElement("div");
          headerDiv.className = "layout-header-section";
          const gridDiv = document.createElement("div");
          gridDiv.className = "layout-cols-wrapper layout-cols-grid " + (targetCols === 2 ? "pdf-two-cols-wrapper layout-two-cols-grid" : (targetCols === 3 ? "pdf-three-cols-wrapper layout-three-cols-grid" : ""));

          const gridCols = parseRatioToGridCols(slide.frontmatter?.layoutRatio, targetCols);
          if (gridCols) gridDiv.style.gridTemplateColumns = gridCols;

          let colsList = [];
          for (let i = 0; i < targetCols; i++) colsList.push([]);
          const hasExplicitCols = rem.some(b => b.slot && (b.slot.startsWith("col-") || b.slot === "left" || b.slot === "right" || b.slot === "center"));
          if (hasExplicitCols) {
            for (const b of rem) {
              let idx = 0;
              if (b.slot === "left" || b.slot === "col-1") idx = 0;
              else if (b.slot === "center" || b.slot === "col-2") idx = 1;
              else if (b.slot === "right") idx = targetCols === 2 ? 1 : targetCols - 1;
              else {
                const m = (b.slot || "").match(/^col-(d+)$/i);
                if (m) idx = Math.min(targetCols - 1, Math.max(0, parseInt(m[1], 10) - 1));
              }
              colsList[idx].push(b);
            }
          } else {
            let cur = 0;
            for (let i = 0; i < targetCols; i++) {
              const remainingCols = targetCols - i;
              const remainingItems = rem.length - cur;
              const take = Math.ceil(remainingItems / remainingCols);
              colsList[i] = rem.slice(cur, cur + take);
              cur += take;
            }
          }

          for (const b of headerBlocks) headerDiv.appendChild(renderBlock(b));
          containerDiv.appendChild(headerDiv);

          colsList.forEach((colBlocks, idx) => {
            const colDiv = document.createElement("div");
            colDiv.className = "pdf-col pdf-col--" + (idx + 1) + " col-" + (idx + 1) + (targetCols === 2 && idx === 0 ? " pdf-col--left" : "") + (targetCols === 2 && idx === 1 ? " pdf-col--right" : "");
            const cleaned = cleanColList(colBlocks);
            for (const b of cleaned) colDiv.appendChild(renderBlock(b));
            gridDiv.appendChild(colDiv);
          });
          containerDiv.appendChild(gridDiv);
          container.appendChild(containerDiv);
        } else if (slide.frontmatter?.layout === "image-right" || slide.frontmatter?.layout === "image-left") {
          const isImageRight = slide.frontmatter?.layout === "image-right";
          const contentCol = document.createElement("div");
          contentCol.className = isImageRight ? "image-right-content" : "image-left-content";

          for (const block of (slide.blocks || [])) {
            contentCol.appendChild(renderBlock(block));
          }

          const imgCol = document.createElement("div");
          imgCol.className = isImageRight ? "image-right-img-container" : "image-left-img-container";
          const img = document.createElement("img");
          img.className = isImageRight ? "image-right-img" : "image-left-img";
          img.src = slide.frontmatter?.image || slide.frontmatter?.background || "";
          img.alt = "Slide cover";
          img.onerror = function() {
            this.src = "https://fastly.jsdelivr.net/gh/slidevjs/slidev-covers@main/static/2HmfbSpvcos.webp";
          };
          imgCol.appendChild(img);

          if (isImageRight) {
            container.appendChild(contentCol);
            container.appendChild(imgCol);
          } else {
            container.appendChild(imgCol);
            container.appendChild(contentCol);
          }
        } else {
          for (const block of (slide.blocks || [])) {
            container.appendChild(renderBlock(block));
          }
        }

        function syncAutoplayVideos() {
          const doSync = () => {
            const videos = container.querySelectorAll("video");
            videos.forEach((v) => {
              const box = v.closest("[data-autoplay]");
              const isAuto = v.hasAttribute("autoplay") || v.autoplay || (box && box.getAttribute("data-autoplay") === "true");
              if (isAuto) {
                v.muted = true;
                v.defaultMuted = true;
                v.setAttribute("muted", "");
                v.playsInline = true;
                v.setAttribute("playsinline", "");
                const playFn = () => {
                  if (!v.paused) return;
                  v.muted = true;
                  v.defaultMuted = true;
                  const p = v.play();
                  if (p !== undefined) {
                    p.catch(() => {
                      v.muted = true;
                      v.defaultMuted = true;
                      setTimeout(() => { if (v.paused) v.play().catch(() => {}); }, 150);
                    });
                  }
                };
                playFn();
                if (!v.__autoplayBound) {
                  v.__autoplayBound = true;
                  v.addEventListener("loadedmetadata", playFn);
                  v.addEventListener("canplay", playFn);
                }
              }
            });
          };
          setTimeout(doSync, 60);
          setTimeout(doSync, 200);
        }
        syncAutoplayVideos();
      }

      // Lightbox 控制逻辑
      const lightbox = document.getElementById("slidev-lightbox");
      const lightboxContent = document.getElementById("lightbox-content");
      const lightboxClose = document.getElementById("lightbox-close");
      let isLightboxOpen = false;

      function openLightbox(type, src, alt) {
        if (!lightbox || !lightboxContent) return;
        lightboxContent.innerHTML = "";
        if (type === "video") {
          const v = document.createElement("video");
          v.className = "slidev-lightbox-video";
          v.src = src;
          v.controls = true;
          v.autoplay = true;
          v.playsInline = true;
          lightboxContent.appendChild(v);
        } else {
          const img = document.createElement("img");
          img.className = "slidev-lightbox-img";
          img.src = src;
          img.alt = alt || "";
          lightboxContent.appendChild(img);
        }
        lightbox.classList.add("active");
        isLightboxOpen = true;
      }

      function closeLightbox() {
        if (!lightbox) return;
        const v = lightbox.querySelector("video");
        if (v) v.pause();
        lightbox.classList.remove("active");
        if (lightboxContent) lightboxContent.innerHTML = "";
        isLightboxOpen = false;
      }

      if (lightboxClose) {
        lightboxClose.addEventListener("click", (e) => {
          e.stopPropagation();
          closeLightbox();
        });
      }
      if (lightbox) {
        lightbox.addEventListener("click", (e) => {
          if (e.target === lightbox || e.target === lightboxClose) {
            e.stopPropagation();
            closeLightbox();
          }
        });
      }

      btnPrev.addEventListener("click", () => renderSlide(currentIndex - 1));
      btnNext.addEventListener("click", () => renderSlide(currentIndex + 1));
      btnFullscreen.addEventListener("click", () => {
        if (!document.fullscreenElement) {
          document.documentElement.requestFullscreen().then(() => updateScale()).catch(() => {});
        } else {
          document.exitFullscreen().then(() => updateScale()).catch(() => {});
        }
      });

      window.addEventListener("keydown", (e) => {
        if (e.key === "Escape" || e.key === "Esc") {
          if (isLightboxOpen) {
            closeLightbox();
            e.preventDefault();
            return;
          }
        }
        if (isLightboxOpen) return;
        if (e.key === "ArrowRight" || e.key === " ") renderSlide(currentIndex + 1);
        if (e.key === "ArrowLeft") renderSlide(currentIndex - 1);
        if (e.key === "f" || e.key === "F") btnFullscreen.click();
      });

      document.addEventListener("click", (e) => {
        if (isLightboxOpen) {
          const target = e.target instanceof Element ? e.target : e.target?.parentElement;
          const isMediaItself = target && target.closest && target.closest(".slidev-lightbox-img, .slidev-lightbox-video");
          if (!isMediaItself) {
            e.stopPropagation();
            closeLightbox();
          }
          return;
        }
        if (e.button !== 0) return;
        const targetEl = e.target instanceof Element ? e.target : e.target?.parentElement;
        if (!targetEl || !targetEl.closest) return;

        const refEl = targetEl.closest("[data-ref-id]");
        if (refEl) {
          const id = refEl.getAttribute("data-ref-id");
          if (id) {
            window.open("siyuan://blocks/" + id, "_blank");
            return;
          }
        }

        // 媒体点击唤起 Lightbox 放大模态
        const mediaEl = targetEl.closest(".slide-content img, .slide-content video");
        if (mediaEl && !mediaEl.closest(".controls, button, a")) {
          e.stopPropagation();
          const isVideo = mediaEl.tagName.toLowerCase() === "video";
          const src = isVideo ? (mediaEl.currentSrc || mediaEl.src || mediaEl.querySelector("source")?.src) : mediaEl.src;
          if (src) {
            openLightbox(isVideo ? "video" : "image", src, mediaEl.alt || "");
            return;
          }
        }

        const selection = window.getSelection ? window.getSelection().toString().trim() : "";
        if (selection.length > 0) return;

        const isComponent = targetEl.closest(
          ".slide-block, .controls-bar, .image-right-img-container, .image-left-img-container, img, video, audio, button, a, input, textarea, select, [data-clickable], [data-ref-id], .slidev-toc, .empty-state"
        );
        if (isComponent) return;

        const isLeft = e.clientX < window.innerWidth / 2;
        if (isLeft) {
          renderSlide(currentIndex - 1);
        } else {
          renderSlide(currentIndex + 1);
        }
      });

      renderSlide(0);
      updateScale();
    })();`}function da(t,i){const e="Slidev 演示文稿";let n=t.slides;const o=JSON.stringify(n),s=JSON.stringify(t.config);return`<!DOCTYPE html>
<html lang="zh-CN">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${ce(e)}</title>
  <style>
${tm(i==null?void 0:i.customInlineStyles)}
  </style>
  <script>
    // 注入演示数据载荷
    window.__SLIDEV_DATA__ = {
      docId: ${JSON.stringify(t.docId)},
      slides: ${o},
      config: ${s}
    };
  <\/script>
</head>
<body>
  <div id="app" data-normalize-headings="${t.config.normalizeHeadingSizes?"true":"false"}">
    <div class="slide-viewport slidev-theme-${t.config.theme||"default"}" id="viewport" data-slidev-theme="${t.config.theme||"default"}">
      <div class="slide-content" id="slide-container"></div>
    </div>
    <div class="controls">
      <button id="btn-prev">◀ 上一页</button>
      <span id="page-num">1 / 1</span>
      <button id="btn-next">下一页 ▶</button>
      <button id="btn-fullscreen">全屏</button>
    </div>
    <!-- 全屏媒体灯箱 (Lightbox) 模态窗口 -->
    <div id="slidev-lightbox" class="slidev-lightbox">
      <button class="slidev-lightbox-close" id="lightbox-close" aria-label="关闭 (Esc)">✕</button>
      <div class="slidev-lightbox-content" id="lightbox-content"></div>
    </div>
  </div>

  <script>
${em()}
  <\/script>
</body>
</html>`}function ua(t,i){if(typeof document>"u")return!1;const e=new Blob([i],{type:"text/html;charset=utf-8"}),n=URL.createObjectURL(e),o=document.createElement("a");return o.href=n,o.download=t.endsWith(".html")?t:`${t}.html`,document.body.appendChild(o),o.click(),document.body.removeChild(o),URL.revokeObjectURL(n),!0}function im(t){switch(t){case"4:3":return"size: 12in 9in;";case"A4-landscape":return"size: 297mm 210mm;";case"A4-portrait":return"size: 210mm 297mm;";case"16:9":default:return"size: 16in 9in;"}}function nm(t){const i=im(t==null?void 0:t.pageRatio);return`
    ${kn(t==null?void 0:t.customInlineStyles)}

    @page {
      ${i}
      margin: 0;
    }
    * {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
      -webkit-print-color-adjust: exact !important;
      print-color-adjust: exact !important;
    }
    body {
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "PingFang SC", "Microsoft YaHei", sans-serif;
      background: #f8fafc;
      color: #1e293b;
    }
    .pdf-slide-page {
      width: 100vw;
      height: 100vh;
      page-break-after: always;
      break-after: page;
      padding: var(--slidev-padding-y, 36px) var(--slidev-padding-x, 56px);
      display: flex;
      flex-direction: column;
      position: relative;
      background: #ffffff;
      overflow: hidden;
    }
    .pdf-slide-page.spacing-compact {
      --slidev-padding-y: 20px;
      --slidev-padding-x: 36px;
      --slidev-header-gap: 10px;
      --slidev-title-margin-bottom: 6px;
    }
    .pdf-slide-page.spacing-normal {
      --slidev-padding-y: 36px;
      --slidev-padding-x: 56px;
      --slidev-header-gap: 16px;
      --slidev-title-margin-bottom: 10px;
    }
    .pdf-slide-page.spacing-loose {
      --slidev-padding-y: 48px;
      --slidev-padding-x: 64px;
      --slidev-header-gap: 24px;
      --slidev-title-margin-bottom: 16px;
    }
    .pdf-slide-page.theme-dark {
      background: #0f1117;
      color: #f1f5f9;
    }
    .pdf-slide-header {
      font-size: 13px;
      color: #64748b;
      margin-bottom: 24px;
      display: flex;
      justify-content: space-between;
      border-bottom: 1px solid #e2e8f0;
      padding-bottom: 8px;
    }
    .theme-dark .pdf-slide-header {
      border-bottom-color: #2e3346;
      color: #94a3b8;
    }
    .pdf-slide-body {
      flex: 1;
      display: flex;
      flex-direction: column;
      gap: 16px;
      font-size: 20px;
      line-height: 1.6;
      overflow: hidden;
    }
    .pdf-block h1 { font-size: 2.5rem; font-weight: 800; color: #2563eb; margin-bottom: 12px; }
    .pdf-block h2 { font-size: 1.9rem; font-weight: 700; color: #1d4ed8; margin-bottom: 10px; }
    .pdf-block h3 { font-size: 1.4rem; font-weight: 600; margin-bottom: 8px; }
    .pdf-block h4 { font-size: 1.2rem; font-weight: 600; margin-bottom: 6px; }
    .pdf-block p { font-size: 1.15rem; color: inherit; }
    .pdf-code,
    pre {
      background: #f1f5f9;
      padding: 14px 18px;
      border-radius: 6px;
      font-family: "JetBrains Mono", Consolas, monospace;
      font-size: 0.95rem;
      border-left: 4px solid #3b82f6;
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      max-width: 100% !important;
      box-sizing: border-box !important;
    }
    .pdf-code code,
    pre code {
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      display: block !important;
      width: 100% !important;
      box-sizing: border-box !important;
    }
    .code-line {
      display: flex !important;
      align-items: flex-start !important;
      width: 100% !important;
      box-sizing: border-box !important;
      line-height: 1.6;
    }
    .code-line .line-no {
      display: inline-block !important;
      flex-shrink: 0 !important;
      min-width: 2.2em !important;
      text-align: right !important;
      margin-right: 12px !important;
      user-select: none !important;
      opacity: 0.45 !important;
    }
    .code-line .line-content {
      flex: 1 1 0% !important;
      min-width: 0 !important;
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
    }
    .theme-dark .pdf-code {
      background: #1e1e24;
      border-left-color: #60a5fa;
    }
    .pdf-quote {
      border-left: 4px solid #10b981;
      background: rgba(16, 185, 129, 0.08);
      padding: 10px 16px;
      border-radius: 0 4px 4px 0;
      font-style: italic;
    }
    .pdf-image,
    .slide-media-img {
      max-width: 100% !important;
      max-height: 48vh !important;
      width: auto !important;
      height: auto !important;
      object-fit: contain !important;
      border-radius: 6px;
      margin: auto;
      display: block;
    }
    .slide-media-block,
    .slide-media-container,
    .slide-video-container {
      display: flex;
      flex-direction: column;
      justify-content: center;
      align-items: center;
      width: 100%;
      max-height: 48vh;
      margin: 8px 0;
      overflow: hidden;
    }
    .slide-list-media {
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: flex-start;
      margin-top: 8px;
      margin-bottom: 6px;
      max-width: 100%;
      overflow: hidden;
    }
    .slide-list-media img,
    .slide-list-media video,
    .slide-list-media .list-item-gif {
      max-width: 100% !important;
      max-height: min(280px, 36vh) !important;
      width: auto !important;
      height: auto !important;
      min-width: 0 !important;
      min-height: 0 !important;
      object-fit: contain !important;
      border-radius: 6px;
      display: block;
      margin: 0 auto !important;
    }
    .slide-video-player {
      max-width: 100% !important;
      max-height: 48vh !important;
      width: auto !important;
      height: auto !important;
      object-fit: contain !important;
      border-radius: 6px;
      background: #000;
      border: 1px solid #cbd5e1;
    }
    .pdf-two-cols-wrapper,
    .layout-two-cols-grid,
    .layout-cols-wrapper,
    .layout-cols-grid {
      display: grid;
      grid-template-columns: minmax(0, 1fr) minmax(0, 1fr);
      grid-template-rows: minmax(0, 1fr) !important;
      gap: 36px;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      overflow: hidden !important;
    }
    .layout-cols-header-container,
    .layout-two-cols-header-container,
    .layout-three-cols-header-container {
      display: flex;
      flex-direction: column;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      overflow: hidden !important;
    }
    .layout-header-section {
      width: 100%;
      margin-bottom: var(--slidev-header-gap, 16px) !important;
      flex-shrink: 0;
    }
    .layout-header-section h1,
    .layout-header-section h2,
    .layout-header-section h3 {
      margin-bottom: var(--slidev-title-margin-bottom, 10px) !important;
    }
    .pdf-three-cols-wrapper,
    .layout-three-cols-grid {
      display: grid;
      grid-template-columns: minmax(0, 1fr) minmax(0, 1fr) minmax(0, 1fr);
      grid-template-rows: minmax(0, 1fr) !important;
      gap: 24px;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      box-sizing: border-box;
      overflow: hidden !important;
    }
    .pdf-col {
      display: flex;
      flex-direction: column;
      gap: 14px;
      min-width: 0;
      width: 100%;
      max-width: 100%;
      height: 100%;
      max-height: 100%;
      min-height: 0;
      justify-content: flex-start;
      overflow: hidden;
      box-sizing: border-box;
      overflow-wrap: break-word;
      word-break: break-word;
      white-space: normal;
    }
    /* 表头多栏内超级块子块首个列表项去圆点后居中显示标题/首行文本 */
    .layout-cols-wrapper .pdf-col > *:first-child .slide-list-item-title,
    .layout-cols-wrapper .pdf-col > *:first-child :is(h1, h2, h3, h4, h5, h6),
    .layout-cols-wrapper .pdf-col > *:first-child p.slide-list-item-title,
    .layout-cols-wrapper .pdf-col > *:first-child p:first-of-type,
    .layout-cols-wrapper .pdf-col > *:first-child p:first-child,
    .layout-cols-wrapper .pdf-col > *:first-child :is(ul, ol) > li:first-child,
    .layout-cols-wrapper .pdf-col > *:first-child .slide-list > .slide-list-item:first-child,
    .layout-cols-wrapper .pdf-col > *:first-child .pdf-list > li:first-child,
    .layout-cols-header-container .pdf-col > *:first-child .slide-list-item-title,
    .layout-cols-header-container .pdf-col > *:first-child :is(h1, h2, h3, h4, h5, h6),
    .layout-cols-header-container .pdf-col > *:first-child p.slide-list-item-title,
    .layout-cols-header-container .pdf-col > *:first-child p:first-of-type,
    .layout-cols-header-container .pdf-col > *:first-child p:first-child,
    .layout-cols-header-container .pdf-col > *:first-child :is(ul, ol) > li:first-child,
    .layout-cols-header-container .pdf-col > *:first-child .slide-list > .slide-list-item:first-child,
    .layout-cols-header-container .pdf-col > *:first-child .pdf-list > li:first-child,
    .slidev-col-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    .slidev-col-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      list-style: none !important;
      list-style-type: none !important;
      text-align: center !important;
      margin-left: 0 !important;
      padding-left: 0 !important;
      width: 100% !important;
    }

    /* 彻底清除首个列表项的原生圆点 Marker */
    :is(.layout-cols-wrapper, .layout-cols-header-container) .pdf-col > *:first-child :is(ul, ol) > li:first-child::marker {
      content: "" !important;
      display: none !important;
    }

    /* 确保首个列表项内部内联与块级元素居中 */
    :is(.layout-cols-wrapper, .layout-cols-header-container) .pdf-col > *:first-child :is(ul, ol) > li:first-child * {
      text-align: center !important;
    }

    /* 栏内说明段落与列表项：左对齐，自然阅读排版 */
    .layout-cols-wrapper .pdf-col .slide-list-item-desc,
    .layout-cols-header-container .pdf-col .slide-list-item-desc,
    .pdf-col .slide-list-item-desc,
    .layout-cols-wrapper .pdf-col li:not(:first-child),
    .layout-cols-header-container .pdf-col li:not(:first-child),
    .pdf-col li:not(:first-child) {
      text-align: left !important;
    }

    /* 全局特定标题大小规范化 (除封面外页首首个标题按 H2 1.7rem，表头多栏内首个标题按 H3 1.3rem) */
    [data-normalize-headings="true"] .slidev-page-first-heading-block :is(h1, h2, h3, h4, h5, h6),
    [data-normalize-headings="true"] .slidev-page-first-heading-block:is(h1, h2, h3, h4, h5, h6),
    [data-normalize-headings="true"] .pdf-slide:not(.layout-cover) > .pdf-block:first-child :is(h1, h2, h3, h4, h5, h6),
    [data-normalize-headings="true"] .pdf-slide:not(.layout-cover) > .layout-header-section .pdf-block:first-child :is(h1, h2, h3, h4, h5, h6),
    [data-normalize-headings="true"] .pdf-slide:not(.layout-cover) > :not(.layout-cols-wrapper):not(.pdf-two-cols-wrapper):not(.layout-image-cols-grid):first-child :is(h1, h2, h3, h4, h5, h6) {
      font-size: 1.7rem !important;
      font-weight: 600 !important;
      line-height: 1.25 !important;
      margin-bottom: 10px !important;
    }

    [data-normalize-headings="true"] .slidev-col-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .slidev-col-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] :is(.layout-cols-wrapper, .pdf-two-cols-wrapper, .layout-cols-header-container) .pdf-col > *:first-child :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      font-size: 1.3rem !important;
      font-weight: 600 !important;
      line-height: 1.3 !important;
      margin-bottom: 8px !important;
      text-align: center !important;
    }
    .pdf-col > .pdf-block,
    .pdf-col > .slide-block {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      max-height: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      width: 100% !important;
      height: 100% !important;
      box-sizing: border-box !important;
      overflow: hidden !important;
    }
    .pdf-col .slide-list-item-title,
    .pdf-col h1, .pdf-col h2, .pdf-col h3, .pdf-col h4, .pdf-col h5, .pdf-col h6,
    .pdf-col .slide-list-item-desc {
      flex: 0 0 auto !important;
      margin-top: 0 !important;
      margin-bottom: 6px !important;
    }
    .pdf-col .slide-list-media,
    .pdf-col .slide-video-container,
    .pdf-col .slide-media-container {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      min-width: 0 !important;
      width: 100% !important;
      height: 100% !important;
      max-height: 100% !important;
      max-width: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
      justify-content: flex-start !important;
      overflow: hidden !important;
      margin: 0 !important;
      padding: 0 !important;
      box-sizing: border-box !important;
    }
    .pdf-col li:has(.slide-list-media),
    .pdf-col li:has(.slide-media-container),
    .pdf-col li:has(.slide-video-container),
    .pdf-col li:has(img),
    .pdf-col li:has(video),
    .pdf-col .pdf-list-item:has(.slide-list-media),
    .pdf-col .pdf-list-item:has(.slide-media-container),
    .pdf-col .pdf-list-item:has(.slide-video-container),
    .pdf-col .pdf-list-item:has(img),
    .pdf-col .pdf-list-item:has(video) {
      display: list-item !important;
      list-style-type: disc !important;
      flex: 0 0 auto !important;
      height: auto !important;
      max-height: none !important;
      overflow: visible !important;
      margin-bottom: 6px !important;
    }
    .pdf-col video,
    .layout-three-cols-grid video,
    .layout-two-cols-grid video,
    .pdf-col img,
    .layout-three-cols-grid img,
    .layout-two-cols-grid img,
    .pdf-col .slide-video-player {
      max-width: 100% !important;
      max-height: 100% !important;
      width: auto !important;
      height: auto !important;
      min-width: 0 !important;
      min-height: 0 !important;
      object-fit: contain !important;
      display: block !important;
      margin: 0 auto !important;
    }
    .pdf-col * {
      overflow-wrap: break-word;
      word-break: break-word;
      box-sizing: border-box;
    }
    .pdf-col pre {
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      max-width: 100% !important;
      box-sizing: border-box !important;
    }
    .pdf-list-item {
      padding-left: 20px;
    }
    .pdf-list {
      padding-left: 24px;
      margin: 8px 0;
      display: flex;
      flex-direction: column;
      gap: 6px;
    }
    .pdf-list li {
      font-size: 1.15rem;
      line-height: 1.6;
    }
    .pdf-task-item {
      list-style: none;
      margin-left: -20px;
      display: flex;
      align-items: center;
      gap: 8px;
    }
    .pdf-task-item input[type="checkbox"] {
      width: 1.15em;
      height: 1.15em;
      cursor: pointer;
    }
    /* 两栏与三栏及多栏（超级块分栏）布局：紧凑自然行距，子列表保留圆点与层级缩进 */
    .layout-two-cols ul,
    .layout-cols-header ul,
    .layout-two-cols-header ul,
    .layout-three-cols ul,
    .layout-three-cols-header ul,
    .two-cols-left ul,
    .two-cols-right ul,
    .three-cols-col ul,
    .col ul,
    .pdf-two-cols-wrapper ul,
    .pdf-three-cols-wrapper ul,
    .pdf-col ul,
    .layout-two-cols-grid .pdf-list,
    .layout-three-cols-grid .pdf-list,
    .layout-cols-grid .pdf-list,
    .layout-two-cols-grid .pdf-list--unordered,
    .layout-three-cols-grid .pdf-list--unordered,
    .layout-cols-grid .pdf-list--unordered {
      list-style: disc !important;
      list-style-type: disc !important;
      padding-left: 1.25em !important;
      margin-left: 0 !important;
      margin-top: 0 !important;
      margin-bottom: 8px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: block !important;
    }
    .layout-two-cols ol,
    .layout-cols-header ol,
    .layout-two-cols-header ol,
    .layout-three-cols ol,
    .layout-three-cols-header ol,
    .two-cols-left ol,
    .two-cols-right ol,
    .three-cols-col ol,
    .col ol,
    .pdf-two-cols-wrapper ol,
    .pdf-three-cols-wrapper ol,
    .pdf-col ol,
    .layout-two-cols-grid .pdf-list--ordered,
    .layout-three-cols-grid .pdf-list--ordered,
    .layout-cols-grid .pdf-list--ordered {
      list-style: decimal !important;
      list-style-type: decimal !important;
      padding-left: 1.25em !important;
      margin-left: 0 !important;
      margin-top: 0 !important;
      margin-bottom: 8px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: block !important;
    }
    .layout-two-cols li,
    .layout-cols-header li,
    .layout-two-cols-header li,
    .layout-three-cols li,
    .layout-three-cols-header li,
    .two-cols-left li,
    .two-cols-right li,
    .three-cols-col li,
    .col li,
    .pdf-col li,
    .pdf-col .pdf-list-item {
      padding-left: 0.2em !important;
      margin-left: 0 !important;
      margin-bottom: 6px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: list-item !important;
      line-height: 1.6 !important;
    }
    .layout-two-cols ul ul,
    .layout-three-cols ul ul,
    .three-cols-col ul ul,
    .pdf-col ul ul {
      list-style: circle !important;
      list-style-type: circle !important;
      padding-left: 1.25em !important;
      margin-top: 4px !important;
      margin-bottom: 4px !important;
    }
    /* 列表项内嵌标题与说明排版 */
    .slide-list-item-title,
    .pdf-list li > h1,
    .pdf-list li > h2,
    .pdf-list li > h3,
    .pdf-list li > h4,
    .pdf-list li > h5,
    .pdf-list li > h6,
    li > h1.slide-list-item-title,
    li > h2.slide-list-item-title,
    li > h3.slide-list-item-title,
    li > h4.slide-list-item-title {
      margin-top: 2px !important;
      margin-bottom: 6px !important;
      line-height: 1.35 !important;
      font-weight: 700 !important;
    }
    .pdf-list li > h1, li > h1.slide-list-item-title { font-size: 1.6rem !important; }
    .pdf-list li > h2, li > h2.slide-list-item-title { font-size: 1.4rem !important; }
    .pdf-list li > h3, li > h3.slide-list-item-title { font-size: 1.22rem !important; }
    .pdf-list li > h4, li > h4.slide-list-item-title { font-size: 1.1rem !important; }
    .slide-list-item-desc,
    .pdf-list li > p {
      margin-top: 4px !important;
      margin-bottom: 6px !important;
      font-size: 1.05rem;
      line-height: 1.55;
      opacity: 0.92;
    }
    kbd {
      display: inline-block;
      padding: 2px 7px;
      font-family: ui-monospace, SFMono-Regular, "SF Mono", Menlo, Consolas, "Liberation Mono", monospace;
      font-size: 0.85em;
      font-weight: 600;
      line-height: 1.25;
      color: inherit;
      background: rgba(125, 125, 125, 0.12);
      border: 1px solid rgba(125, 125, 125, 0.35);
      border-bottom-width: 2px;
      border-radius: 5px;
      box-shadow: 0 1px 2px rgba(0, 0, 0, 0.12);
      margin: 0 2px;
      vertical-align: middle;
      white-space: nowrap;
    }
    .theme-dark kbd {
      background: rgba(255, 255, 255, 0.1);
      border-color: rgba(255, 255, 255, 0.25);
      border-bottom-color: rgba(255, 255, 255, 0.4);
      color: #f1f5f9;
      box-shadow: 0 1px 2px rgba(0, 0, 0, 0.4);
    }
    a {
      color: inherit;
      text-decoration: none;
      border-bottom: 1px dashed currentColor;
    }
    .slidev-ref-tag, a.slidev-ref-tag {
      display: inline-flex;
      align-items: center;
      background: rgba(16, 185, 129, 0.1);
      color: #059669;
      border: 1px solid rgba(16, 185, 129, 0.25);
      border-radius: 4px;
      padding: 2px 8px;
      font-size: 0.88em;
      text-decoration: none;
      margin: 2px 4px 2px 0;
    }
    .theme-dark .slidev-ref-tag, .theme-dark a.slidev-ref-tag {
      background: rgba(52, 211, 153, 0.15);
      color: #34d399;
      border-color: rgba(52, 211, 153, 0.3);
    }
    .slidev-block-ref, .pdf-block--ref {
      background: rgba(16, 185, 129, 0.06);
      border-left: 3px solid #059669;
      border-radius: 0 6px 6px 0;
      padding: 10px 14px;
      margin: 8px 0;
    }
    .theme-dark .slidev-block-ref, .theme-dark .pdf-block--ref {
      background: rgba(52, 211, 153, 0.08);
      border-left-color: #34d399;
    }
    .pdf-slide-notes {
      font-size: 14px;
      color: #059669;
      border-top: 1px dashed #cbd5e1;
      padding-top: 12px;
      margin-top: auto;
      line-height: 1.5;
    }
    .theme-dark .pdf-slide-notes {
      color: #34d399;
      border-top-color: #334155;
    }
    /* Layouts */
    .layout-cover .pdf-slide-body {
      justify-content: center;
      align-items: center;
      text-align: center;
    }
    .layout-cover h1 {
      font-size: 3.2rem;
    }
    .layout-center .pdf-slide-body {
      justify-content: center;
      align-items: center;
      text-align: center;
    }
    .layout-fact .pdf-slide-body {
      justify-content: center;
      align-items: center;
      text-align: center;
    }
    .layout-fact h1 {
      font-size: 4.5rem;
      color: #ef4444;
    }
    @media print {
      .slidev-motion-fade-in,
      .slidev-motion-slide-up,
      .slidev-motion-slide-down,
      .slidev-motion-slide-left,
      .slidev-motion-slide-right,
      .slidev-motion-zoom-in,
      .slidev-motion-pop,
      .slidev-motion-bounce {
        animation: none !important;
        opacity: 1 !important;
        transform: none !important;
      }
    }
  `}function om(t,i){const e="Slidev 演示讲义",n="16:9",o="light",s=t.slides.map((l,r)=>{const a=l.frontmatter.layout||"default",c=l.frontmatter.spacing,u=c&&c!=="inherit"?c:t.config.spacing||"normal",m=Kh(l),g=`${r+1} / ${t.slides.length}`;return`
      <section class="pdf-slide-page layout-${a} theme-${o} spacing-${u}">
        <header class="pdf-slide-header">
          <span class="pdf-doc-title">${ce(e)}</span>
          ${`<span class="pdf-page-badge">P. ${g}</span>`}
        </header>
        <div class="pdf-slide-body">
          ${m}
        </div>
        ${l.notes?`
          <footer class="pdf-slide-notes">
            <strong>演讲备注:</strong> ${ce(l.notes)}
          </footer>
        `:""}
      </section>
    `}).join(`
`);return`<!DOCTYPE html>
<html lang="zh-CN">
<head>
  <meta charset="UTF-8">
  <title>${ce(e)} - 高保真讲义</title>
  <style>
    ${nm({pageRatio:n,customInlineStyles:i==null?void 0:i.customInlineStyles})}
  </style>
</head>
<body data-normalize-headings="${t.config.normalizeHeadingSizes?"true":"false"}">
  ${s}
</body>
</html>`}function fa(t,i){var o;if(typeof window>"u"||typeof document>"u")return!1;const e=om(t,i);try{const s=document.createElement("iframe");s.style.position="fixed",s.style.right="0",s.style.bottom="0",s.style.width="0",s.style.height="0",s.style.border="none",s.style.visibility="hidden",document.body.appendChild(s);const l=(o=s.contentWindow)==null?void 0:o.document;if(l)return l.open(),l.write(e),l.close(),setTimeout(()=>{var r,a;try{(r=s.contentWindow)==null||r.focus(),(a=s.contentWindow)==null||a.print()}finally{setTimeout(()=>{s.remove()},2e3)}},350),!0}catch(s){console.warn("[pdf-exporter] iframe 打印模式异常，降级尝试 window.open:",s)}const n=window.open("","_blank");return n?(n.document.write(e),n.document.close(),n.focus(),setTimeout(()=>{n.print(),n.close()},350),!0):!1}const sm={class:"spm-slidev-preview-tab"},rm={class:"spm-slidev-tab__toolbar"},lm={class:"spm-slidev-tab__actions"},am=["disabled"],cm={class:"spm-page-badge"},dm=["disabled"],um=["aria-label"],fm=["aria-label"],pm=["src"],hm=Se({__name:"SlidevPreviewTab",setup(t,{expose:i}){const e=ti("plugin"),n=ti("sandboxBridge",new Ns),o=new Uh(n),s=new uf,l=gt("web-sandbox"),r=gt(3030),a=gt(null),c=gt(!1),u=gt(null),m=gt(1),g=gt(1),d=gt([]),y=gt(!1),f=gt(!1),v=gt(!1),k=gt("siyuan"),x=gt(""),S=gt(""),B=gt(""),A=gt(!1),I=gt(!1),w=gt(""),z=gt("/plugins/siyuan-slidev/slidev-client/index.html");let O=null,H=null,et=null,_=null,P=null,b=null,N=null;Rn(()=>{u.value&&(n.attach(u.value),s.nativeBridge.attach(u.value)),O=n.onSlideChanged((X,dt)=>{m.value=X,g.value=dt}),H=n.onBlockClicked((X,dt)=>{m.value=dt,o.setActiveBlockId(X),e&&typeof e.handleBlockClickedFromSlide=="function"?e.handleBlockClickedFromSlide(X,dt):Pi(X,e==null?void 0:e.app)}),et=n.onOpenInEditor((X,dt)=>{m.value=dt,o.setActiveBlockId(X),Pi(X,e==null?void 0:e.app)}),_=s.nativeBridge.onPageChanged((X,dt)=>{m.value=X,g.value=dt}),P=n.onOpenPeekDrawer(async X=>{const dt=Do();if(X.peekType==="siyuan"&&dt.enableWebServeJump){let bt=!1;if(N&&N.docId===X.target)bt=!0;else if(N&&N.slides&&N.slides.some(T=>{var F;return(F=T.blocks)==null?void 0:F.some(h=>h.id===X.target)}))bt=!1;else try{const T=await wn(`SELECT id, root_id, type FROM blocks WHERE id = '${X.target}' LIMIT 1`);T&&T.length>0&&(bt=T[0].type==="d"||T[0].id===T[0].root_id)}catch(T){console.warn("[SlidevPreviewTab] detect block type failed:",T)}k.value="web",A.value=!0,S.value=Jl(dt.webServeUrl,X.target,{focus:!bt}),B.value=X.title||`${bt?"思源文档":"思源块"}: ${X.target.slice(0,8)}`,f.value=!0,n.freezeKeyboardNav(!0)}else k.value=X.peekType,X.peekType==="siyuan"?(x.value=X.target,B.value=X.title||`块速览: ${X.target.slice(0,8)}`):(A.value=!0,S.value=X.target,B.value=X.title||X.target),f.value=!0,n.freezeKeyboardNav(!0)}),b=n.onRequestToggleFullscreen(()=>{Y()}),typeof document<"u"&&document.addEventListener("fullscreenchange",Q)}),Ts(()=>{typeof document<"u"&&document.removeEventListener("fullscreenchange",Q),P&&P(),b&&b(),O&&O(),H&&H(),et&&et(),_&&_(),n.detach(),o.destroy(),s.destroy()});async function J(){if(l.value==="web-sandbox"){if(!N){ht.showMessage("请先在主编辑区打开演示文档");return}ht.showMessage("正在探测本地 Node 环境并编排 Slidev Pro 进程...");const X=await s.startProMode(N,Qo);if(!X.success){ht.showMessage(`无法启动官方 Pro 模式：${X.error}`);return}l.value="pro-cli",r.value=X.port||3030,z.value=X.url,u.value&&s.nativeBridge.attach(u.value),ht.showMessage(`🟢 已成功接入官方原生 Slidev 服务 (端口: ${r.value})`)}else s.stopProMode(),l.value="web-sandbox",z.value="/plugins/siyuan-slidev/slidev-client/index.html",u.value&&n.attach(u.value),ht.showMessage("已切回内置高保真沙箱")}function U(){I.value=!I.value,I.value?w.value=(N==null?void 0:N.docId)||"":(w.value="",E())}function G(){m.value>1&&(l.value==="pro-cli"?s.nativeBridge.navigateToPage(m.value-1):n.navigatePage(m.value-1))}function V(){m.value<g.value&&(l.value==="pro-cli"?s.nativeBridge.navigateToPage(m.value+1):n.navigatePage(m.value+1))}function M(X){m.value=X,l.value==="pro-cli"?s.nativeBridge.navigateToPage(X):n.navigatePage(X)}function E(){e&&typeof e.compileCurrentDocument=="function"?e.compileCurrentDocument():e!=null&&e.eventBus&&typeof e.eventBus.emit=="function"&&e.eventBus.emit("slidev:request-compile")}function R(){f.value=!1,n.freezeKeyboardNav(!1)}function tt(){R()}function Q(){typeof document<"u"&&(c.value=!!document.fullscreenElement,n.postMessage("FULLSCREEN_CHANGED",{isFullscreen:c.value}))}function Y(){const X=a.value||u.value;X&&(document.fullscreenElement?document.exitFullscreen().then(()=>{n.postMessage("FULLSCREEN_CHANGED",{isFullscreen:!1})}).catch(()=>{}):X.requestFullscreen().then(()=>{n.postMessage("FULLSCREEN_CHANGED",{isFullscreen:!0})}).catch(()=>{}))}function W(){window.open("/plugins/siyuan-slidev/slidev-client/presenter.html","SlidevPresenter","width=1200,height=800")}function ut(){if(!N){ht.showMessage("请先在主编辑区打开幻灯片文档");return}const X=da(N);ua("presentation.html",X)&&ht.showMessage("已开始下载单文件离线 HTML 演示包")}function ct(){if(!N){ht.showMessage("请先在主编辑区打开幻灯片文档");return}fa(N)&&ht.showMessage("已唤起打印视窗，请在打印选项中选择「另存为 PDF」")}return i({updateDocument(X,dt){I.value&&w.value&&dt&&dt!==w.value||(N=X,I.value&&!w.value&&(w.value=X.docId),d.value=X.slides,g.value=X.slides.length,o.setDocId(X.docId),o.updateSlidesIndex(X.slides),l.value==="pro-cli"?s.scaffolder.scaffold(X,Qo).catch(()=>{}):n.updateSlides(X.slides,X.config,X.fullMarkdown,X.customThemeCss))},navigateToBlock(X){o.onCursorFocusBlock(X)},isPinned:I,pinnedDocId:w,engineMode:l,toggleEngineMode:J}),(X,dt)=>(ot(),st("div",sm,[p("div",rm,[dt[4]||(dt[4]=p("div",{class:"spm-slidev-tab__title"},[p("svg",{class:"spm-slidev-tab__icon","aria-hidden":"true"},[p("use",{"xlink:href":"#iconSlidev"})]),p("span",null,"Slidev 演示预览")],-1)),p("div",lm,[p("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s",disabled:m.value<=1,"aria-label":"上一页",onClick:G},[at(ft,{name:"chevron-left"})],8,am),p("span",cm,St(m.value)+" / "+St(g.value||1),1),p("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s",disabled:m.value>=g.value,"aria-label":"下一页",onClick:V},[at(ft,{name:"chevron-right"})],8,dm),p("button",{class:It(["spm-icon-btn b3-tooltips b3-tooltips__s",{"is-primary":I.value}]),"aria-label":I.value?"已锁定当前文档（点击解除）："+w.value:"点击锁定当前文档（不随主编辑区切换）",onClick:U},[at(ft,{name:"pin"}),p("span",null,St(I.value?"已锁定":"跟随"),1)],10,um),p("button",{class:It(["spm-icon-btn b3-tooltips b3-tooltips__s",{"is-primary":l.value==="pro-cli"}]),"aria-label":l.value==="pro-cli"?"当前：官方原生 Pro 模式 (localhost:"+r.value+")，点击切回沙箱":"当前：内置高保真沙箱，点击切换官方原生 Pro 模式",onClick:J},[at(ft,{name:"rocket"}),p("span",null,St(l.value==="pro-cli"?"Pro ("+r.value+")":"沙箱"),1)],10,fm),dt[3]||(dt[3]=p("span",{class:"spm-toolbar-divider"},null,-1)),p("button",{class:It(["spm-icon-btn b3-tooltips b3-tooltips__s",{"is-primary":y.value}]),"aria-label":"切换幻灯片大纲抽屉",onClick:dt[0]||(dt[0]=bt=>y.value=!y.value)},[at(ft,{name:"outline"})],2),p("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"双屏演讲者视图 (Presenter Mode ⌥M)",onClick:W},[at(ft,{name:"presenter"})]),p("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"导出单文件 HTML 演示包",onClick:ut},[at(ft,{name:"export-html"})]),p("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"导出 16:9 PDF 演示讲义",onClick:ct},[at(ft,{name:"export-pdf"})]),p("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"重新编译并刷新",onClick:E},[at(ft,{name:"refresh"})]),p("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"全屏放映",onClick:Y},[at(ft,{name:"fullscreen"})])])]),p("div",{ref_key:"fullscreenContainerRef",ref:a,class:"spm-slidev-tab__viewport spm-slidev-fullscreen-container"},[p("iframe",{ref_key:"sandboxIframeRef",ref:u,class:"spm-slidev-tab__iframe",src:z.value,frameborder:"0",allow:"fullscreen; autoplay"},null,8,pm),at(ph,{visible:f.value,"onUpdate:visible":dt[1]||(dt[1]=bt=>f.value=bt),"is-maximized":v.value,"onUpdate:isMaximized":dt[2]||(dt[2]=bt=>v.value=bt),title:B.value,onClose:R},{default:bl(()=>[k.value==="siyuan"&&x.value?(ot(),De(xh,{key:0,"block-id":x.value,title:B.value,plugin:vt(e),onExternalJump:tt},null,8,["block-id","title","plugin"])):Rt("",!0),A.value?Te((ot(),De(Hh,{key:1,visible:f.value&&k.value==="web",url:S.value,title:B.value,onExternalJump:tt},null,8,["visible","url","title"])),[[Gl,k.value==="web"]]):Rt("",!0)]),_:1},8,["visible","is-maximized","title"])],512),y.value&&d.value.length>0?(ot(),De(oh,{key:0,slides:d.value,"current-active-page":m.value,onNavigate:M,onRefresh:E},null,8,["slides","current-active-page"])):Rt("",!0)]))}}),mm=ze(hm,[["__scopeId","data-v-cdfa5b82"]]),gm={class:"spm-section spm-section--page"},vm={class:"spm-section-header"},bm={key:0,class:"spm-card-control",style:{"border-left":"3px solid var(--b3-theme-primary)",background:"rgba(var(--b3-theme-primary-rgb, 66, 133, 244), 0.06)",padding:"8px 12px","margin-top":"6px"}},ym={style:{display:"flex","align-items":"center","justify-content":"space-between",gap:"8px"}},km={style:{"font-size":"11px",display:"flex","align-items":"center",gap:"6px",flex:"1"}},wm={key:1,class:"spm-card-control"},xm={class:"spm-control-header"},_m={class:"spm-control-title-group"},Sm={class:"spm-control-title"},Cm={class:"spm-quick-chips"},$m=["onClick"],Im={style:{display:"flex",gap:"6px","align-items":"center","margin-top":"6px"}},Am=["value"],Bm=["aria-label"],Tm={key:1,class:"spm-icon-btn b3-tooltips b3-tooltips__w",disabled:"",style:{opacity:"0.45",cursor:"not-allowed",padding:"0 8px",height:"26px","font-size":"11px","white-space":"nowrap","flex-shrink":"0"},"aria-label":"当前页未检测到调整过列宽的横向超级块"},Em={key:0,style:{"margin-top":"6px","font-size":"11px",opacity:"0.85",display:"flex","align-items":"center",gap:"4px"}},Mm={style:{background:"rgba(125, 125, 125, 0.15)",padding:"1px 4px","border-radius":"3px","font-weight":"bold"}},Dm={key:1,style:{"margin-top":"6px","font-size":"11px",opacity:"0.6",display:"flex","align-items":"center",gap:"4px"}},Lm={class:"spm-card-control"},Pm={class:"spm-control-header"},Rm={class:"spm-control-title-group"},Om={class:"spm-control-title"},zm={class:"spm-segmented-group"},Nm={class:"spm-card-control"},Fm={class:"spm-control-header"},Hm={class:"spm-control-title-group"},jm={class:"spm-control-title"},Um={class:"spm-quick-chips"},Wm=["onClick"],Vm=["value"],qm={key:2,class:"spm-card-control"},Km={class:"spm-control-header"},Gm={class:"spm-control-title-group"},Zm={class:"spm-control-title"},Ym={class:"spm-quick-chips"},Jm=["onClick"],Xm=["value"],Qm={class:"spm-card-control"},tg={class:"spm-control-header"},eg={class:"spm-control-title-group"},ig={class:"spm-control-title"},ng={key:0,class:"spm-note-status-box"},og=["title"],sg={class:"spm-action-grid",style:{"margin-top":"6px"}},rg={key:1,class:"spm-note-empty-box"},lg={class:"spm-batch-actions-box",style:{"margin-top":"8px","border-top":"1px dashed var(--b3-border-color, #e2e8f0)","padding-top":"8px"}},ag={class:"spm-action-grid"},cg=["disabled"],dg=["disabled"],ug={class:"spm-card-control"},fg={class:"spm-action-grid"},pg=Se({__name:"PageInspectorSection",props:{pageLayout:{},pageTransition:{},pageBackground:{},pageSpacing:{},pageImage:{},pageNotes:{},pageIndex:{},pageLayoutRatio:{},detectedSbRatio:{},detectedSbInfo:{},isBatchProcessing:{type:Boolean}},emits:["update:pageLayout","update:pageTransition","update:pageBackground","update:pageSpacing","update:pageImage","update:pageLayoutRatio","applySuperBlockLayout","resetSuperblockRatio","addNoteBlock","locateNoteBlock","generateNotes","batchAppendNotes","batchDeleteNotes","insertDividerAfter","deleteDivider"],setup(t,{emit:i}){const e=t,n=i,o=_t(()=>["two-cols","cols-header","two-cols-header","three-cols-header","image-left","image-right"].includes(e.pageLayout)),s=_t(()=>{var y,f;if(e.pageLayout==="two-cols-header"||e.pageLayout==="two-cols"||e.pageLayout==="image-left"||e.pageLayout==="image-right")return 2;if(e.pageLayout==="three-cols-header")return 3;const g=(e.pageLayoutRatio||"").trim();if(g.includes(":")){const v=g.split(":").filter(Boolean).length;if(v>=2&&v<=6)return v}const d=(e.detectedSbRatio||"").trim();if(d.includes(":")){const v=d.split(":").filter(Boolean).length;if(v>=2&&v<=6)return v}if((y=e.detectedSbInfo)!=null&&y.colCount&&e.detectedSbInfo.colCount>=2)return Math.min(e.detectedSbInfo.colCount,6);if((f=e.detectedSbInfo)!=null&&f.slots&&Array.isArray(e.detectedSbInfo.slots)){const v=e.detectedSbInfo.slots.length;if(v>=2&&v<=6)return v}return 2}),l=_t(()=>{const g=s.value;return g===3?[{label:"默认 1:1:1",value:""},{label:"1:2:1 (主中)",value:"1:2:1"},{label:"2:1:1 (主左)",value:"2:1:1"},{label:"1:1:2 (主右)",value:"1:1:2"},{label:"1:3:1",value:"1:3:1"}]:g===4?[{label:"默认 1:1:1:1",value:""},{label:"1:2:2:1",value:"1:2:2:1"},{label:"2:1:1:2",value:"2:1:1:2"}]:g===5?[{label:"默认 1:1:1:1:1",value:""}]:g===6?[{label:"默认 1:1:1:1:1:1",value:""}]:[{label:"默认 1:1",value:""},{label:"1:2",value:"1:2"},{label:"2:1",value:"2:1"},{label:"3:7",value:"3:7"},{label:"7:3",value:"7:3"},{label:"4:6",value:"4:6"},{label:"6:4",value:"6:4"}]}),r=_t(()=>e.pageLayoutRatio||"");function a(){const g=s.value||2,d=Array(g).fill("1").join(":");n("update:pageLayoutRatio",d),n("resetSuperblockRatio")}const c=_t(()=>{if(!e.pageNotes)return"";const g=e.pageNotes.replace(/[\r\n]+/g," ").trim();return g.length>50?g.slice(0,50)+"...":g}),u=[{label:"默认",value:""},{label:"暗黑 #1e1e24",value:"#1e1e24"},{label:"极夜 #0f172a",value:"#0f172a"},{label:"极简白 #ffffff",value:"#ffffff"}],m=[{label:"默认封面",value:"https://cover.sli.dev"},{label:"清空配图",value:""}];return(g,d)=>(ot(),st("div",gm,[p("div",vm,[p("span",null,"幻灯片页面设置"+St(t.pageIndex?` (第 ${t.pageIndex} 页)`:""),1)]),at(ra,{"model-value":t.pageLayout,onChange:d[0]||(d[0]=y=>g.$emit("update:pageLayout",y))},null,8,["model-value"]),!o.value&&t.detectedSbRatio?(ot(),st("div",bm,[p("div",ym,[p("div",km,[at(ft,{name:"sparkles"}),p("span",null,[d[22]||(d[22]=Ae("检测到本页横向超级块列宽比例：",-1)),p("b",null,St(t.detectedSbRatio),1)])]),p("button",{class:"spm-btn-action b3-tooltips b3-tooltips__w","aria-label":"一键将本页版式设为分栏并应用超级块列宽",style:{padding:"2px 8px",height:"26px","font-size":"11px","flex-shrink":"0",background:"var(--b3-theme-primary)",color:"#fff",display:"inline-flex","align-items":"center",gap:"4px"},onClick:d[1]||(d[1]=y=>g.$emit("applySuperBlockLayout",t.detectedSbInfo||{recommendedLayout:"two-cols",ratio:t.detectedSbRatio}))},[at(ft,{name:"columns"}),d[23]||(d[23]=p("span",null,"设为分栏",-1))])])])):Rt("",!0),o.value?(ot(),st("div",wm,[p("div",xm,[p("div",_m,[p("div",Sm,[at(ft,{name:"ratio"}),d[24]||(d[24]=p("span",null,"分栏比例 (Ratio)",-1))]),d[25]||(d[25]=p("span",{class:"spm-control-desc"},"设置各列横向空间占比，默认平均分配",-1))])]),p("div",Cm,[(ot(!0),st(Gt,null,xe(l.value,y=>(ot(),st("button",{key:y.value,class:It(["spm-chip",{active:r.value===y.value}]),onClick:f=>g.$emit("update:pageLayoutRatio",y.value)},St(y.label),11,$m))),128))]),p("div",Im,[p("input",{value:t.pageLayoutRatio||"",class:"spm-input",style:{flex:"1","min-width":"0"},placeholder:"自定义比例（如 1:2 或 30:70，留空为默认）",onInput:d[2]||(d[2]=y=>g.$emit("update:pageLayoutRatio",y.target.value)),onChange:d[3]||(d[3]=y=>g.$emit("update:pageLayoutRatio",y.target.value))},null,40,Am),t.detectedSbRatio?(ot(),st("button",{key:0,class:"spm-icon-btn b3-tooltips b3-tooltips__w","aria-label":`从当前页思源超级块读取实际宽度比例 (${t.detectedSbRatio}) 并应用`,style:{padding:"0 8px",height:"26px","font-size":"11px","white-space":"nowrap","flex-shrink":"0"},onClick:d[4]||(d[4]=y=>g.$emit("update:pageLayoutRatio",t.detectedSbRatio))},[at(ft,{name:"sparkles"}),d[26]||(d[26]=p("span",null,"读取",-1))],8,Bm)):(ot(),st("button",Tm,[at(ft,{name:"sparkles"}),d[27]||(d[27]=p("span",null,"读取",-1))])),p("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__w","aria-label":"重置渲染比例为平均分布，并立即重置文档中超级块内容分布比例",style:{padding:"0 8px",height:"26px","font-size":"11px","white-space":"nowrap","flex-shrink":"0"},onClick:a},[at(ft,{name:"reset"}),d[28]||(d[28]=p("span",null,"重置",-1))])]),t.detectedSbRatio?(ot(),st("div",Em,[at(ft,{name:"ratio"}),d[29]||(d[29]=p("span",null,"检测到思源超级块宽度：",-1)),p("code",Mm,St(t.detectedSbRatio),1)])):(ot(),st("div",Dm,[at(ft,{name:"ratio"}),d[30]||(d[30]=p("span",null,"未检测到调宽超级块（默认各列平均分配）",-1))]))])):Rt("",!0),at(Fs,{"model-value":t.pageTransition,onChange:d[5]||(d[5]=y=>g.$emit("update:pageTransition",y))},null,8,["model-value"]),p("div",Lm,[p("div",Pm,[p("div",Rm,[p("div",Om,[at(ft,{name:"ratio"}),d[31]||(d[31]=p("span",null,"页面间距 (Spacing)",-1))]),d[32]||(d[32]=p("span",{class:"spm-control-desc"},"覆盖本页内边距与顶部标题间距",-1))])]),p("div",zm,[p("button",{class:It(["spm-segmented-item",{active:!t.pageSpacing||t.pageSpacing==="inherit"}]),onClick:d[6]||(d[6]=y=>g.$emit("update:pageSpacing","inherit"))}," 继承全局 ",2),p("button",{class:It(["spm-segmented-item",{active:t.pageSpacing==="compact"}]),onClick:d[7]||(d[7]=y=>g.$emit("update:pageSpacing","compact"))}," 紧凑 ",2),p("button",{class:It(["spm-segmented-item",{active:t.pageSpacing==="normal"}]),onClick:d[8]||(d[8]=y=>g.$emit("update:pageSpacing","normal"))}," 标准 ",2),p("button",{class:It(["spm-segmented-item",{active:t.pageSpacing==="loose"}]),onClick:d[9]||(d[9]=y=>g.$emit("update:pageSpacing","loose"))}," 宽松 ",2)])]),p("div",Nm,[p("div",Fm,[p("div",Hm,[p("div",jm,[at(ft,{name:"palette"}),d[33]||(d[33]=p("span",null,"页面背景 (Background)",-1))]),d[34]||(d[34]=p("span",{class:"spm-control-desc"},"设置当前页特定底色或壁纸",-1))])]),p("div",Um,[(ot(),st(Gt,null,xe(u,y=>p("button",{key:y.value,class:It(["spm-chip",{active:t.pageBackground===y.value}]),onClick:f=>g.$emit("update:pageBackground",y.value)},St(y.label),11,Wm)),64))]),p("input",{value:t.pageBackground,class:"spm-input",placeholder:"自定义颜色代码或资源路径",onInput:d[10]||(d[10]=y=>g.$emit("update:pageBackground",y.target.value)),onChange:d[11]||(d[11]=y=>g.$emit("update:pageBackground",y.target.value))},null,40,Vm)]),t.pageLayout==="image-right"||t.pageLayout==="image-left"||t.pageImage?(ot(),st("div",qm,[p("div",Km,[p("div",Gm,[p("div",Zm,[at(ft,{name:"image"}),d[35]||(d[35]=p("span",null,"页面图片 (Image)",-1))]),d[36]||(d[36]=p("span",{class:"spm-control-desc"},"图文分栏或页面专属配图 URL / 资源路径",-1))])]),p("div",Ym,[(ot(),st(Gt,null,xe(m,y=>p("button",{key:y.value,class:It(["spm-chip",{active:t.pageImage===y.value}]),onClick:f=>g.$emit("update:pageImage",y.value)},St(y.label),11,Jm)),64))]),p("input",{value:t.pageImage,class:"spm-input",placeholder:"网络图片 URL (如 https://cover.sli.dev) 或 assets/...",onInput:d[12]||(d[12]=y=>g.$emit("update:pageImage",y.target.value)),onChange:d[13]||(d[13]=y=>g.$emit("update:pageImage",y.target.value))},null,40,Xm)])):Rt("",!0),p("div",Qm,[p("div",tg,[p("div",eg,[p("div",ig,[at(ft,{name:"presenter"}),d[37]||(d[37]=p("span",null,"演讲者提词 (Notes)",-1))]),d[38]||(d[38]=p("span",{class:"spm-control-desc"},"正文备注块驱动 · 仅演讲者视图可见",-1))]),p("button",{class:"spm-btn-text b3-tooltips b3-tooltips__w","aria-label":"AI 自动生成本页讲稿提示块",onClick:d[14]||(d[14]=y=>g.$emit("generateNotes"))},[at(ft,{name:"sparkles"}),d[39]||(d[39]=p("span",null,"AI 讲稿",-1))])]),t.pageNotes?(ot(),st("div",ng,[d[42]||(d[42]=p("div",{class:"spm-note-status-badge"},[p("span",{class:"spm-badge-dot"}),p("span",null,"已配置正文讲稿")],-1)),p("div",{class:"spm-note-preview-text",title:t.pageNotes},St(c.value),9,og),p("div",sg,[p("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"在正文编辑区定位并高亮此讲稿备注块",onClick:d[15]||(d[15]=y=>g.$emit("locateNoteBlock"))},[at(ft,{name:"search"}),d[40]||(d[40]=p("span",null,"定位讲稿块",-1))]),p("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"在本页末尾追加新的讲稿提示块",onClick:d[16]||(d[16]=y=>g.$emit("addNoteBlock"))},[at(ft,{name:"insert-below"}),d[41]||(d[41]=p("span",null,"追加讲稿块",-1))])])])):(ot(),st("div",rg,[d[44]||(d[44]=p("div",{class:"spm-note-empty-hint"},"本页暂无讲稿备注块",-1)),p("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s",style:{width:"100%","margin-top":"6px"},"aria-label":"在当前页末尾插入默认演讲备注提示块",onClick:d[17]||(d[17]=y=>g.$emit("addNoteBlock"))},[at(ft,{name:"insert-below"}),d[43]||(d[43]=p("span",null,"添加讲稿备注块",-1))])])),p("div",lg,[p("div",ag,[p("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s",disabled:t.isBatchProcessing,style:$n(t.isBatchProcessing?"opacity: 0.5; cursor: not-allowed;":""),"aria-label":"在所有尚未配置讲稿的页面末尾批量追加讲稿提示块",onClick:d[18]||(d[18]=y=>g.$emit("batchAppendNotes"))},[at(ft,{name:"insert-below"}),d[45]||(d[45]=p("span",null,"全部追加",-1))],12,cg),p("button",{class:"spm-btn-action spm-btn-danger b3-tooltips b3-tooltips__s",disabled:t.isBatchProcessing,style:$n(t.isBatchProcessing?"opacity: 0.5; cursor: not-allowed;":""),"aria-label":"批量物理删除正文中的全部讲稿备注块（涉及全部页）",onClick:d[19]||(d[19]=y=>g.$emit("batchDeleteNotes"))},[at(ft,{name:"trash"}),d[46]||(d[46]=p("span",null,"全部删除",-1))],12,dg)])])]),p("div",ug,[d[49]||(d[49]=p("div",{class:"spm-control-header"},[p("div",{class:"spm-control-title-group"},[p("span",{class:"spm-control-title"},"分页快捷操作")])],-1)),p("div",fg,[p("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"在此分页符之后插入新的空白分页",onClick:d[20]||(d[20]=y=>g.$emit("insertDividerAfter"))},[at(ft,{name:"insert-below"}),d[47]||(d[47]=p("span",null,"插入新页",-1))]),p("button",{class:"spm-btn-action spm-btn-danger b3-tooltips b3-tooltips__s","aria-label":"彻底删除当前分页符（合并前后页面）",onClick:d[21]||(d[21]=y=>g.$emit("deleteDivider"))},[at(ft,{name:"trash"}),d[48]||(d[48]=p("span",null,"删除此页",-1))])])])]))}}),hg=ze(pg,[["__scopeId","data-v-246d804f"]]),mg={class:"spm-section spm-section--block"},gg={key:0,class:"spm-card-control",style:{"border-left":"3px solid var(--b3-theme-primary)"}},vg={class:"spm-control-header"},bg={class:"spm-control-title-group"},yg={class:"spm-control-title"},kg={style:{background:"var(--b3-theme-surface)",border:"1px solid var(--b3-theme-surface-lighter)","border-radius":"6px",padding:"10px","margin-bottom":"8px"}},wg={style:{display:"flex","align-items":"center","justify-content":"space-between","margin-bottom":"4px"}},xg={style:{"font-size":"12px","font-weight":"500",display:"flex","align-items":"center",gap:"4px"}},_g={key:0},Sg={key:1},Cg={style:{background:"rgba(var(--b3-theme-primary-rgb, 59, 130, 246), 0.16)",color:"var(--b3-theme-primary)",border:"1px solid rgba(var(--b3-theme-primary-rgb, 59, 130, 246), 0.3)",padding:"2px 6px","border-radius":"4px","font-weight":"bold","font-size":"12px"}},$g={style:{"font-size":"11px",opacity:"0.75","line-height":"1.4"}},Ig={class:"spm-action-grid"},Ag={class:"spm-card-control"},Bg={class:"spm-control-header"},Tg={class:"spm-control-title-group"},Eg={class:"spm-control-title"},Mg=["aria-label"],Dg=["checked"],Lg={key:1,class:"spm-card-control"},Pg={class:"spm-control-header"},Rg={class:"spm-control-title-group"},Og={class:"spm-control-title"},zg={class:"spm-quick-chips"},Ng={key:2,class:"spm-card-control"},Fg={class:"spm-control-header"},Hg={class:"spm-control-title-group"},jg={class:"spm-control-title"},Ug={class:"spm-video-settings-grid",style:{display:"grid","grid-template-columns":"1fr 1fr",gap:"8px","margin-top":"8px"}},Wg={class:"spm-toggle-item",style:{display:"flex","align-items":"center","justify-content":"space-between",padding:"4px 6px",background:"rgba(125,125,125,0.06)","border-radius":"4px"}},Vg={style:{"font-size":"11px",display:"inline-flex","align-items":"center",gap:"4px"}},qg=["aria-label"],Kg=["checked"],Gg={class:"spm-toggle-item",style:{display:"flex","align-items":"center","justify-content":"space-between",padding:"4px 6px",background:"rgba(125,125,125,0.06)","border-radius":"4px"}},Zg={style:{"font-size":"11px",display:"inline-flex","align-items":"center",gap:"4px"}},Yg=["aria-label"],Jg=["checked"],Xg={class:"spm-toggle-item",style:{display:"flex","align-items":"center","justify-content":"space-between",padding:"4px 6px",background:"rgba(125,125,125,0.06)","border-radius":"4px"}},Qg={style:{"font-size":"11px",display:"inline-flex","align-items":"center",gap:"4px"}},tv=["aria-label"],ev=["checked"],iv={class:"spm-toggle-item",style:{display:"flex","align-items":"center","justify-content":"space-between",padding:"4px 6px",background:"rgba(125,125,125,0.06)","border-radius":"4px"}},nv={style:{"font-size":"11px",display:"inline-flex","align-items":"center",gap:"4px"}},ov=["aria-label"],sv=["checked"],rv={class:"spm-card-control"},lv={class:"spm-control-header"},av={class:"spm-control-title-group"},cv={class:"spm-control-title"},dv=["aria-label"],uv=["checked"],fv={key:0,class:"spm-quick-chips"},pv=["onClick"],hv={key:1,class:"spm-inherit-tip",style:{"margin-top":"6px",padding:"4px 8px",background:"rgba(var(--b3-theme-primary-rgb, 59, 130, 246), 0.08)","border-radius":"4px","font-size":"11px",opacity:"0.85",display:"flex","align-items":"center",gap:"4px"}},mv={class:"spm-card-control"},gv={class:"spm-control-header"},vv={class:"spm-control-title-group"},bv={class:"spm-control-title"},yv=["aria-label"],kv=["checked"],wv={key:0,class:"spm-quick-chips"},xv=["onClick"],_v={key:1,class:"spm-motion-details",style:{display:"flex","flex-direction":"column",gap:"4px","margin-top":"4px"}},Sv={style:{display:"flex",gap:"8px","justify-content":"space-between","font-size":"11px",opacity:"0.8"}},Cv={style:{display:"flex",gap:"6px"}},$v=["value"],Iv=["value"],Av={key:3,class:"spm-card-control"},Bv={class:"spm-control-header"},Tv={class:"spm-control-title-group"},Ev={class:"spm-control-title"},Mv={class:"spm-control-desc"},Dv={class:"spm-segmented-group"},Lv=["onClick"],Pv={key:4,class:"spm-card-control"},Rv={class:"spm-control-header"},Ov={class:"spm-control-title-group"},zv={class:"spm-control-title"},Nv={class:"spm-quick-chips"},Fv=["onClick"],Hv=["value"],jv={key:5,class:"spm-card-control"},Uv={class:"spm-control-header"},Wv={class:"spm-control-title-group"},Vv={class:"spm-control-title"},qv={class:"spm-quick-chips"},Kv=["onClick"],Gv=["value"],Zv={class:"spm-card-control"},Yv={class:"spm-action-grid"},Jv=["aria-label"],Xv=Se({__name:"BlockInspectorSection",props:{elemClick:{},elemMotion:{},elemSlot:{},elemShikiLines:{},elemMaxHeight:{},isCodeBlock:{type:Boolean},isImage:{type:Boolean},isVideo:{type:Boolean},videoAutoplay:{type:Boolean},videoLoop:{type:Boolean},videoMuted:{type:Boolean},videoControls:{type:Boolean},hasBlockAttrs:{type:Boolean},isNote:{type:Boolean},imageRole:{},currentSlideLayout:{},isSuperBlock:{type:Boolean},parentElemClick:{},parentContainerSlot:{},parentContainerId:{},detectedSbInfo:{}},emits:["toggleNote","toggleElemClick","update:elemClick","update:elemMotion","update:elemSlot","update:elemShikiLines","update:elemMaxHeight","applySuperBlockLayout","applySuperBlockRatio","insertDividerBefore","insertDividerAfter","setTwoColsContrast","clearBlockAttrs","update:imageRole","toggleVideoAutoplay","toggleVideoLoop","toggleVideoMuted","toggleVideoControls"],setup(t,{emit:i}){const e=t,n=_t(()=>{const I=e.currentSlideLayout||"";return["col-1","col-2","col-3","col-4","col-5","col-6"].includes(e.elemSlot)?"cols-header":I}),o=_t(()=>{const I=n.value;return["two-cols","cols-header","two-cols-header","three-cols-header"].includes(I)}),s=_t(()=>{var w,z,O,H;if((w=e.detectedSbInfo)!=null&&w.colCount&&e.detectedSbInfo.colCount>=2)return Math.min(e.detectedSbInfo.colCount,6);const I=(z=e.elemSlot)==null?void 0:z.match(/^col-(\d+)$/);if(I){const et=parseInt(I[1],10);if(et>=2&&et<=6)return Math.max(et,3)}if(e.currentSlideLayout==="three-cols-header")return 3;if(e.currentSlideLayout==="two-cols-header"||e.currentSlideLayout==="two-cols")return 2;if((H=(O=e.detectedSbInfo)==null?void 0:O.ratio)!=null&&H.includes(":")){const et=e.detectedSbInfo.ratio.split(":").filter(Boolean);if(et.length>=2)return Math.min(et.length,6)}return 3}),l=_t(()=>{const I=n.value;return I==="cols-header"?"多栏插槽归属 (Slot)":I==="three-cols-header"?"三栏插槽归属 (Slot)":I==="two-cols-header"?"带表头双栏插槽 (Slot)":"多栏插槽归属 (Slot)"}),r=_t(()=>{const I=n.value;return I==="cols-header"?`在 cols-header 表头多栏（${s.value} 栏）中的内容块位置`:I==="three-cols-header"?"在 three-cols-header 版式中的内容块位置":I==="two-cols-header"?"在 two-cols-header 版式中的内容块位置":I==="two-cols"?"在 two-cols 双栏版式中的归属":"在当前分栏版式中的内容块位置"}),a=_t(()=>{const I=n.value;if(I==="two-cols")return[{value:"",label:"默认 (左)"},{value:"right",label:"右栏"}];if(I==="two-cols-header")return[{value:"",label:"默认"},{value:"header",label:"表头"},{value:"left",label:"左栏"},{value:"right",label:"右栏"}];if(I==="three-cols-header")return[{value:"",label:"默认"},{value:"header",label:"表头"},{value:"col-1",label:"第 1 栏"},{value:"col-2",label:"第 2 栏"},{value:"col-3",label:"第 3 栏"}];const w=s.value,z=[{value:"",label:"默认"},{value:"header",label:"表头"}];for(let O=1;O<=w;O++)z.push({value:`col-${O}`,label:`第 ${O} 栏`});return z});function c(I){const w=e.elemSlot||"";return I?w===I||I==="col-1"&&w==="left"||I==="col-2"&&w==="center"||I==="col-3"&&w==="right"&&s.value===3||I==="col-2"&&w==="right"&&s.value===2||I==="left"&&w==="col-1"||I==="right"&&(w==="col-2"||w==="col-3"):!w||w==="default"}const u=i,m=[{label:"上浮 (slide-up)",value:"slide-up"},{label:"淡入 (fade-in)",value:"fade-in"},{label:"下沉 (slide-down)",value:"slide-down"},{label:"左滑 (slide-left)",value:"slide-left"},{label:"右滑 (slide-right)",value:"slide-right"},{label:"缩放 (zoom-in)",value:"zoom-in"},{label:"弹性 (bounce)",value:"bounce"}],g=_t(()=>{if(!e.elemMotion||e.elemMotion.trim()===""||e.elemMotion.trim()==="none")return null;try{const I=JSON.parse(e.elemMotion);if(typeof I=="object"&&I!==null)return{preset:I.preset||I.type||"slide-up",duration:typeof I.duration=="number"?I.duration:0,delay:typeof I.delay=="number"?I.delay:0}}catch{}return{preset:e.elemMotion.trim(),duration:0,delay:0}}),d=_t(()=>!!g.value),y=_t(()=>{var I;return((I=g.value)==null?void 0:I.preset)||"slide-up"}),f=_t(()=>{var I;return((I=g.value)==null?void 0:I.duration)||0}),v=_t(()=>{var I;return((I=g.value)==null?void 0:I.delay)||0});function k(){d.value?u("update:elemMotion",""):u("update:elemMotion","slide-up")}function x(I){A(I,f.value,v.value)}function S(I){A(y.value,I,v.value)}function B(I){A(y.value,f.value,I)}function A(I,w,z){if(!I||I==="none"){u("update:elemMotion","");return}if(!w&&!z){u("update:elemMotion",I);return}const O={preset:I};w>0&&(O.duration=w),z>0&&(O.delay=z),u("update:elemMotion",JSON.stringify(O))}return(I,w)=>{var z,O,H,et,_,P;return ot(),st("div",mg,[w[62]||(w[62]=p("div",{class:"spm-section-header"},[p("span",null,"元素动效与排版")],-1)),t.isSuperBlock||(z=t.detectedSbInfo)!=null&&z.hasSuperBlock?(ot(),st("div",gg,[p("div",vg,[p("div",bg,[p("div",yg,[at(ft,{name:"ratio"}),w[24]||(w[24]=p("span",null,"超级块列宽与布局",-1))]),w[25]||(w[25]=p("span",{class:"spm-control-desc"},"读取思源超级块列宽并一键同步到幻灯片分栏",-1))])]),p("div",kg,[p("div",wg,[p("div",xg,[at(ft,{name:"ratio"}),(O=t.detectedSbInfo)!=null&&O.isCustomWidth?(ot(),st("span",_g,"已识别自定义列宽比例")):(ot(),st("span",Sg,"识别到 "+St(((H=t.detectedSbInfo)==null?void 0:H.colCount)||2)+" 列超级块分栏",1))]),p("code",Cg,St(((et=t.detectedSbInfo)==null?void 0:et.ratio)||"1:1"),1)]),p("div",$g,St((_=t.detectedSbInfo)!=null&&_.isCustomWidth?"检测到已调节子块宽度，可一键应用为当前页分栏比例。":"当前超级块子列为思源默认均宽，可在思源中拖动调节或直接应用。"),1)]),p("div",Ig,[p("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"一键将当前页版式切换为对应双栏/三栏，并写入此列宽比例",style:{background:"rgba(var(--b3-theme-primary-rgb, 59, 130, 246), 0.16)",color:"var(--b3-theme-primary)","font-weight":"500",border:"1px solid rgba(var(--b3-theme-primary-rgb, 59, 130, 246), 0.3)"},onClick:w[0]||(w[0]=b=>I.$emit("applySuperBlockLayout",t.detectedSbInfo))},[at(ft,{name:"sparkles"}),w[26]||(w[26]=p("span",null,"应用版式与比例",-1))]),p("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"仅将提取的比值写入当前页的分栏比例属性",onClick:w[1]||(w[1]=b=>{var N;return I.$emit("applySuperBlockRatio",((N=t.detectedSbInfo)==null?void 0:N.ratio)||"1:1")})},[at(ft,{name:"check"}),p("span",null,"应用比例 ("+St(((P=t.detectedSbInfo)==null?void 0:P.ratio)||"1:1")+")",1)])])])):Rt("",!0),p("div",Ag,[p("div",Bg,[p("div",Tg,[p("div",Eg,[at(ft,{name:"presenter"}),w[27]||(w[27]=p("span",null,"设为讲稿备注 (slidev-note)",-1))]),w[28]||(w[28]=p("span",{class:"spm-control-desc"},"作为当前页演讲提词，不在幻灯片中渲染",-1))]),p("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":t.isNote?"取消讲稿备注":"设为讲稿备注"},[p("input",{type:"checkbox",checked:!!t.isNote,onChange:w[2]||(w[2]=b=>I.$emit("toggleNote"))},null,40,Dg),w[29]||(w[29]=p("span",{class:"spm-switch-slider"},null,-1))],8,Mg)])]),t.isImage||t.imageRole?(ot(),st("div",Lg,[p("div",Pg,[p("div",Rg,[p("div",Og,[at(ft,{name:"image"}),w[30]||(w[30]=p("span",null,"图片角色与分栏 (Image & Layout)",-1))]),w[31]||(w[31]=p("span",{class:"spm-control-desc"},"设为幻灯片背景图或图文分栏配图",-1))])]),p("div",zg,[p("button",{class:It(["spm-chip",{active:!t.imageRole}]),onClick:w[3]||(w[3]=b=>I.$emit("update:imageRole",""))}," 普通内容 ",2),p("button",{class:It(["spm-chip",{active:t.imageRole==="background"}]),onClick:w[4]||(w[4]=b=>I.$emit("update:imageRole","background"))},[at(ft,{name:"image"}),w[32]||(w[32]=p("span",null,"背景图",-1))],2),p("button",{class:It(["spm-chip",{active:t.imageRole==="image-left"}]),onClick:w[5]||(w[5]=b=>I.$emit("update:imageRole","image-left"))},[at(ft,{name:"image-left"}),w[33]||(w[33]=p("span",null,"图左",-1))],2),p("button",{class:It(["spm-chip",{active:t.imageRole==="image-right"}]),onClick:w[6]||(w[6]=b=>I.$emit("update:imageRole","image-right"))},[at(ft,{name:"image-right"}),w[34]||(w[34]=p("span",null,"图右",-1))],2)])])):Rt("",!0),t.isVideo?(ot(),st("div",Ng,[p("div",Fg,[p("div",Hg,[p("div",jg,[at(ft,{name:"video"}),w[35]||(w[35]=p("span",null,"视频播放设置 (Video Playback)",-1))]),w[36]||(w[36]=p("span",{class:"spm-control-desc"},"配置播放器控制条、自动播放与循环",-1))])]),p("div",Ug,[p("div",Wg,[p("span",Vg,[at(ft,{name:"sliders"}),w[37]||(w[37]=Ae(" 控制条",-1))]),p("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":t.videoControls?"关闭控制条":"开启控制条"},[p("input",{type:"checkbox",checked:!!t.videoControls,onChange:w[7]||(w[7]=b=>I.$emit("toggleVideoControls"))},null,40,Kg),w[38]||(w[38]=p("span",{class:"spm-switch-slider"},null,-1))],8,qg)]),p("div",Gg,[p("span",Zg,[at(ft,{name:"video"}),w[39]||(w[39]=Ae(" 自动播放",-1))]),p("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":t.videoAutoplay?"关闭自动播放":"开启自动播放"},[p("input",{type:"checkbox",checked:!!t.videoAutoplay,onChange:w[8]||(w[8]=b=>I.$emit("toggleVideoAutoplay"))},null,40,Jg),w[40]||(w[40]=p("span",{class:"spm-switch-slider"},null,-1))],8,Yg)]),p("div",Xg,[p("span",Qg,[at(ft,{name:"repeat"}),w[41]||(w[41]=Ae(" 循环播放",-1))]),p("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":t.videoLoop?"关闭循环播放":"开启循环播放"},[p("input",{type:"checkbox",checked:!!t.videoLoop,onChange:w[9]||(w[9]=b=>I.$emit("toggleVideoLoop"))},null,40,ev),w[42]||(w[42]=p("span",{class:"spm-switch-slider"},null,-1))],8,tv)]),p("div",iv,[p("span",nv,[at(ft,{name:"volume-x"}),w[43]||(w[43]=Ae(" 静音播放",-1))]),p("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":t.videoMuted?"关闭静音":"开启静音"},[p("input",{type:"checkbox",checked:!!t.videoMuted,onChange:w[10]||(w[10]=b=>I.$emit("toggleVideoMuted"))},null,40,sv),w[44]||(w[44]=p("span",{class:"spm-switch-slider"},null,-1))],8,ov)])])])):Rt("",!0),p("div",rv,[p("div",lv,[p("div",av,[p("div",cv,[at(ft,{name:"step"}),w[45]||(w[45]=p("span",null,"逐步呈现 (v-click)",-1))]),w[46]||(w[46]=p("span",{class:"spm-control-desc"},"放映时按步长逐个呈现",-1))]),p("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":t.elemClick?"关闭逐步呈现":"开启逐步呈现 (+1)"},[p("input",{type:"checkbox",checked:!!t.elemClick,onChange:w[11]||(w[11]=b=>I.$emit("toggleElemClick"))},null,40,uv),w[47]||(w[47]=p("span",{class:"spm-switch-slider"},null,-1))],8,dv)]),t.elemClick?(ot(),st("div",fv,[(ot(),st(Gt,null,xe(["+1","1","2","hide"],b=>p("button",{key:b,class:It(["spm-chip",{active:t.elemClick===b}]),onClick:N=>I.$emit("update:elemClick",b)},St(b==="+1"?"顺延 (+1)":b==="hide"?"隐藏 (hide)":"第 "+b+" 步"),11,pv)),64))])):t.parentElemClick?(ot(),st("div",hv,[at(ft,{name:"check"}),w[48]||(w[48]=p("span",null,"未单独开启逐步呈现：当前跟随整栏同时出现",-1))])):Rt("",!0)]),p("div",mv,[p("div",gv,[p("div",vv,[p("div",bv,[at(ft,{name:"motion"}),w[49]||(w[49]=p("span",null,"入场微动效 (v-motion)",-1))]),w[50]||(w[50]=p("span",{class:"spm-control-desc"},"为当前块添加平滑位移与渐入动画",-1))]),p("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":d.value?"关闭微动效":"开启微动效 (slide-up)"},[p("input",{type:"checkbox",checked:d.value,onChange:k},null,40,kv),w[51]||(w[51]=p("span",{class:"spm-switch-slider"},null,-1))],8,yv)]),d.value?(ot(),st("div",wv,[(ot(),st(Gt,null,xe(m,b=>p("button",{key:b.value,class:It(["spm-chip",{active:y.value===b.value}]),onClick:N=>x(b.value)},St(b.label),11,xv)),64))])):Rt("",!0),d.value?(ot(),st("div",_v,[p("div",Sv,[p("span",null,"时长: "+St(f.value?f.value+"ms":"默认 (450ms)"),1),p("span",null,"延迟: "+St(v.value?v.value+"ms":"0ms"),1)]),p("div",Cv,[p("select",{class:"spm-select",style:{flex:"1"},value:f.value,onChange:w[12]||(w[12]=b=>S(Number(b.target.value)))},[...w[52]||(w[52]=[p("option",{value:0},"默认耗时",-1),p("option",{value:200},"极速 (200ms)",-1),p("option",{value:350},"较快 (350ms)",-1),p("option",{value:500},"平滑 (500ms)",-1),p("option",{value:800},"缓慢 (800ms)",-1)])],40,$v),p("select",{class:"spm-select",style:{flex:"1"},value:v.value,onChange:w[13]||(w[13]=b=>B(Number(b.target.value)))},[...w[53]||(w[53]=[p("option",{value:0},"无延迟",-1),p("option",{value:150},"延迟 150ms",-1),p("option",{value:300},"延迟 300ms",-1),p("option",{value:500},"延迟 500ms",-1)])],40,Iv)])])):Rt("",!0)]),o.value||t.elemSlot?(ot(),st("div",Av,[p("div",Bv,[p("div",Tv,[p("div",Ev,[at(ft,{name:"columns"}),p("span",null,St(l.value),1)]),p("span",Mv,St(r.value),1)])]),p("div",Dv,[(ot(!0),st(Gt,null,xe(a.value,b=>(ot(),st("button",{key:b.value,class:It(["spm-segmented-item",{active:c(b.value)}]),onClick:N=>I.$emit("update:elemSlot",b.value)},St(b.label),11,Lv))),128))])])):Rt("",!0),t.isCodeBlock?(ot(),st("div",Pv,[p("div",Rv,[p("div",Ov,[p("div",zv,[at(ft,{name:"code"}),w[54]||(w[54]=p("span",null,"代码逐行聚光 (Shiki)",-1))]),w[55]||(w[55]=p("span",{class:"spm-control-desc"},"翻页时动态聚光高亮特定行",-1))])]),p("div",Nv,[(ot(),st(Gt,null,xe(["1-3","all","1|2|3","2-5"],b=>p("button",{key:b,class:It(["spm-chip",{active:t.elemShikiLines===b}]),onClick:N=>I.$emit("update:elemShikiLines",b)},St(b),11,Fv)),64)),t.elemShikiLines?(ot(),st("button",{key:0,class:"spm-chip spm-chip-clear",onClick:w[14]||(w[14]=b=>I.$emit("update:elemShikiLines",""))}," 清空 ")):Rt("",!0)]),p("input",{value:t.elemShikiLines,class:"spm-input",placeholder:"自定义高亮区间，如 1-3|5|all",onInput:w[15]||(w[15]=b=>I.$emit("update:elemShikiLines",b.target.value)),onChange:w[16]||(w[16]=b=>I.$emit("update:elemShikiLines",b.target.value))},null,40,Hv)])):Rt("",!0),t.isCodeBlock?(ot(),st("div",jv,[p("div",Uv,[p("div",Wv,[p("div",Vv,[at(ft,{name:"code"}),w[56]||(w[56]=p("span",null,"代码块限高 (Max Height)",-1))]),w[57]||(w[57]=p("span",{class:"spm-control-desc"},"超出限高自动竖向滚动，弱提示滚动条",-1))])]),p("div",qv,[(ot(),st(Gt,null,xe(["240px","320px","400px","50vh"],b=>p("button",{key:b,class:It(["spm-chip",{active:t.elemMaxHeight===b}]),onClick:N=>I.$emit("update:elemMaxHeight",b)},St(b),11,Kv)),64)),t.elemMaxHeight?(ot(),st("button",{key:0,class:"spm-chip spm-chip-clear",onClick:w[17]||(w[17]=b=>I.$emit("update:elemMaxHeight",""))}," 自适应 ")):Rt("",!0)]),p("input",{value:t.elemMaxHeight,class:"spm-input",placeholder:"自适应高度，或输入 350px、50vh",onInput:w[18]||(w[18]=b=>I.$emit("update:elemMaxHeight",b.target.value)),onChange:w[19]||(w[19]=b=>I.$emit("update:elemMaxHeight",b.target.value))},null,40,Gv)])):Rt("",!0),p("div",Zv,[w[61]||(w[61]=p("div",{class:"spm-control-header"},[p("div",{class:"spm-control-title-group"},[p("span",{class:"spm-control-title"},"快捷操作")])],-1)),p("div",Yv,[p("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"在当前块上方插入幻灯片分页线 (---)",onClick:w[20]||(w[20]=b=>I.$emit("insertDividerBefore"))},[at(ft,{name:"insert-above"}),w[58]||(w[58]=p("span",null,"上方分页",-1))]),p("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"在当前块下方插入幻灯片分页线 (---)",onClick:w[21]||(w[21]=b=>I.$emit("insertDividerAfter"))},[at(ft,{name:"insert-below"}),w[59]||(w[59]=p("span",null,"下方分页",-1))]),p("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":n.value==="three-cols-header"?"将当前块属性设为三栏第1栏归属 (slot: col-1)":"将当前块属性设为双栏左侧归属 (slot: left)",onClick:w[22]||(w[22]=b=>I.$emit("setTwoColsContrast"))},[at(ft,{name:"columns"}),p("span",null,St(n.value==="three-cols-header"?"设为第1栏":"设为双栏"),1)],8,Jv),t.hasBlockAttrs?(ot(),st("button",{key:0,class:"spm-btn-action spm-btn-danger b3-tooltips b3-tooltips__s","aria-label":"一键移除本块所有 custom-slidev 属性",onClick:w[23]||(w[23]=b=>I.$emit("clearBlockAttrs"))},[at(ft,{name:"broom"}),w[60]||(w[60]=p("span",null,"清除属性",-1))])):Rt("",!0)])])])}}}),Qv={class:"spm-section spm-section--doc"},t1={class:"spm-card-control"},e1={class:"spm-control-header"},i1={class:"spm-control-title-group"},n1={class:"spm-control-title"},o1={class:"spm-segmented-group"},s1=["aria-label","onClick"],r1={class:"spm-card-control"},l1={class:"spm-control-header"},a1={class:"spm-control-title-group"},c1={class:"spm-control-title"},d1={class:"spm-segmented-group"},u1={class:"spm-card-control"},f1={class:"spm-control-header"},p1={class:"spm-control-title-group"},h1={class:"spm-control-title"},m1={class:"spm-segmented-group"},g1={class:"spm-card-control"},v1={class:"spm-control-header"},b1={class:"spm-control-title-group"},y1={class:"spm-control-title"},k1={class:"spm-card-control"},w1={class:"spm-control-header"},x1={class:"spm-control-title-group"},_1={class:"spm-control-title"},S1=["aria-label"],C1=["checked"],$1={key:0,class:"spm-control-body",style:{"margin-top":"8px"}},I1=["value"],A1={class:"spm-card-control"},B1={class:"spm-control-header"},T1={class:"spm-control-title-group"},E1={class:"spm-control-title"},M1=["aria-label"],D1=["checked"],L1={class:"spm-card-control"},P1={class:"spm-action-grid"},R1=Se({__name:"DocInspectorSection",props:{docTheme:{},docAspectRatio:{},docDefaultTransition:{},docSpacing:{}},emits:["update:docTheme","update:docAspectRatio","update:docDefaultTransition","update:docSpacing","openBottomPreview","openPresenter","aiAutoSplit","exportHtml","exportPdf"],setup(t){const i=ti("plugin"),e=hi,n=[{value:"default",label:"默认 default",desc:"官方默认科技风：现代无衬线排版与清新代码语法高亮，通用汇报与技术分享首选"},{value:"seriph",label:"优雅 seriph",desc:"典雅学术衬线风：书卷学术质感、衬线字体典雅庄重，适合学术论文、人文讲座与深度阅读"},{value:"apple-basic",label:"极简 apple",desc:"苹果发布会极简风：大字号、高对比度与极致留白，适合产品发布、方案演讲与纯粹视觉呈现"}];function o(a){Ei({enableWebServeJump:a}),i&&typeof i.saveGlobalSettings=="function"&&i.saveGlobalSettings({enableWebServeJump:a})}function s(a){Ei({normalizeHeadingSizes:a}),i&&typeof i.saveGlobalSettings=="function"&&i.saveGlobalSettings({normalizeHeadingSizes:a})}function l(a){Ei({webServeUrl:a})}function r(a){Ei({webServeUrl:a}),i&&typeof i.saveGlobalSettings=="function"&&i.saveGlobalSettings({webServeUrl:a})}return(a,c)=>(ot(),st("div",Qv,[c[39]||(c[39]=p("div",{class:"spm-section-header"},[p("span",null,"全局演示配置")],-1)),p("div",t1,[p("div",e1,[p("div",i1,[p("div",n1,[at(ft,{name:"palette"}),c[18]||(c[18]=p("span",null,"幻灯片主题 (Theme)",-1))]),c[19]||(c[19]=p("span",{class:"spm-control-desc"},"全局 Slidev 视觉设计范式",-1))])]),p("div",o1,[(ot(),st(Gt,null,xe(n,u=>p("button",{key:u.value,class:It(["spm-segmented-item b3-tooltips b3-tooltips__s",{active:t.docTheme===u.value}]),"aria-label":u.desc,onClick:m=>a.$emit("update:docTheme",u.value)},St(u.label),11,s1)),64))])]),p("div",r1,[p("div",l1,[p("div",a1,[p("div",c1,[at(ft,{name:"ratio"}),c[20]||(c[20]=p("span",null,"画幅比例 (Aspect Ratio)",-1))]),c[21]||(c[21]=p("span",{class:"spm-control-desc"},"演讲屏幕投影宽高比",-1))])]),p("div",d1,[p("button",{class:It(["spm-segmented-item",{active:t.docAspectRatio==="16/9"}]),onClick:c[0]||(c[0]=u=>a.$emit("update:docAspectRatio","16/9"))}," 16 : 9 (宽屏) ",2),p("button",{class:It(["spm-segmented-item",{active:t.docAspectRatio==="4/3"}]),onClick:c[1]||(c[1]=u=>a.$emit("update:docAspectRatio","4/3"))}," 4 : 3 (标屏) ",2),p("button",{class:It(["spm-segmented-item",{active:t.docAspectRatio==="16/10"}]),onClick:c[2]||(c[2]=u=>a.$emit("update:docAspectRatio","16/10"))}," 16 : 10 ",2)])]),p("div",u1,[p("div",f1,[p("div",p1,[p("div",h1,[at(ft,{name:"ratio"}),c[22]||(c[22]=p("span",null,"间距风格 (Spacing)",-1))]),c[23]||(c[23]=p("span",{class:"spm-control-desc"},"内边距与顶部标题下边距预设",-1))])]),p("div",m1,[p("button",{class:It(["spm-segmented-item b3-tooltips b3-tooltips__s",{active:(t.docSpacing||"normal")==="compact"}]),"aria-label":"紧凑排版：上下 20px / 左右 36px，释放垂直空间，适配图文分栏",onClick:c[3]||(c[3]=u=>a.$emit("update:docSpacing","compact"))}," 紧凑 (Compact) ",2),p("button",{class:It(["spm-segmented-item b3-tooltips b3-tooltips__s",{active:(t.docSpacing||"normal")==="normal"}]),"aria-label":"标准排版：上下 32px / 左右 48px，协调美观（推荐默认）",onClick:c[4]||(c[4]=u=>a.$emit("update:docSpacing","normal"))}," 标准 (Normal) ",2),p("button",{class:It(["spm-segmented-item b3-tooltips b3-tooltips__s",{active:(t.docSpacing||"normal")==="loose"}]),"aria-label":"宽松排版：上下 48px / 左右 56px，大留白适合极简大字",onClick:c[5]||(c[5]=u=>a.$emit("update:docSpacing","loose"))}," 宽松 (Loose) ",2)])]),p("div",g1,[p("div",v1,[p("div",b1,[p("div",y1,[at(ft,{name:"transition"}),c[24]||(c[24]=p("span",null,"全局默认转场",-1))]),c[25]||(c[25]=p("span",{class:"spm-control-desc"},"页面切换过渡动效（未单设转场的页面将继承此动效）",-1))])]),at(Fs,{"model-value":t.docDefaultTransition,"hide-header":!0,onChange:c[6]||(c[6]=u=>a.$emit("update:docDefaultTransition",u))},null,8,["model-value"])]),p("div",k1,[p("div",w1,[p("div",x1,[p("div",_1,[at(ft,{name:"external-link"}),c[26]||(c[26]=p("span",null,"本地网络伺服预览 (Web Serve)",-1))]),c[27]||(c[27]=p("span",{class:"spm-control-desc"},"点击文档/块链接以 Webview 抽屉呈现，支持外跳",-1))]),p("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":vt(e).enableWebServeJump?"关闭本地网络伺服预览":"开启本地网络伺服预览"},[p("input",{type:"checkbox",checked:vt(e).enableWebServeJump,onChange:c[7]||(c[7]=u=>o(u.target.checked))},null,40,C1),c[28]||(c[28]=p("span",{class:"spm-switch-slider"},null,-1))],8,S1)]),vt(e).enableWebServeJump?(ot(),st("div",$1,[p("input",{value:vt(e).webServeUrl,class:"spm-input",placeholder:"http://127.0.0.1:6806",spellcheck:"false",onKeydown:c[8]||(c[8]=Me(()=>{},["stop"])),onKeyup:c[9]||(c[9]=Me(()=>{},["stop"])),onInput:c[10]||(c[10]=u=>l(u.target.value)),onChange:c[11]||(c[11]=u=>r(u.target.value))},null,40,I1),c[29]||(c[29]=p("span",{class:"spm-control-desc",style:{display:"block","margin-top":"4px","font-size":"11px",opacity:"0.8"}}," 默认伺服地址为 http://127.0.0.1:6806。开启后点击块链接将在 Webview 抽屉中打开，点击抽屉顶部『外跳』可在外部浏览器打开 ",-1))])):Rt("",!0)]),p("div",A1,[p("div",B1,[p("div",T1,[p("div",E1,[at(ft,{name:"type"}),c[30]||(c[30]=p("span",null,"固定特定标题大小",-1))]),c[31]||(c[31]=p("span",{class:"spm-control-desc"},"除封面外页首标题按 H2、多栏内首标题按 H3 大小展示",-1))]),p("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":vt(e).normalizeHeadingSizes?"关闭固定特定标题大小":"开启固定特定标题大小"},[p("input",{type:"checkbox",checked:vt(e).normalizeHeadingSizes,onChange:c[12]||(c[12]=u=>s(u.target.checked))},null,40,D1),c[32]||(c[32]=p("span",{class:"spm-switch-slider"},null,-1))],8,M1)])]),p("div",L1,[c[38]||(c[38]=p("div",{class:"spm-control-header"},[p("div",{class:"spm-control-title-group"},[p("span",{class:"spm-control-title"},"演示全局操作")])],-1)),p("div",P1,[p("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"在当前文档下方开启分屏同步预览 (Alt+P)",onClick:c[13]||(c[13]=u=>a.$emit("openBottomPreview"))},[at(ft,{name:"split-preview"}),c[33]||(c[33]=p("span",null,"分屏预览",-1))]),p("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"打开双屏演讲者控制台视窗 (Alt+M)",onClick:c[14]||(c[14]=u=>a.$emit("openPresenter"))},[at(ft,{name:"presenter"}),c[34]||(c[34]=p("span",null,"演讲者视图",-1))]),p("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"智能分析长文本结构并给出大纲分页插入建议",onClick:c[15]||(c[15]=u=>a.$emit("aiAutoSplit"))},[at(ft,{name:"sparkles"}),c[35]||(c[35]=p("span",null,"AI 智能分页",-1))]),p("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"打包导出离线单文件 HTML 幻灯片",onClick:c[16]||(c[16]=u=>a.$emit("exportHtml"))},[at(ft,{name:"export-html"}),c[36]||(c[36]=p("span",null,"导出 HTML",-1))]),p("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"打印生成 16:9 高清演示 PDF 讲义",onClick:c[17]||(c[17]=u=>a.$emit("exportPdf"))},[at(ft,{name:"export-pdf"}),c[37]||(c[37]=p("span",null,"导出 PDF",-1))])])])]))}});var Zn=typeof globalThis<"u"?globalThis:typeof window<"u"?window:typeof global<"u"?global:typeof self<"u"?self:{};function O1(t){return t&&t.__esModule&&Object.prototype.hasOwnProperty.call(t,"default")?t.default:t}function Yn(t){throw new Error('Could not dynamically require "'+t+'". Please configure the dynamicRequireTargets or/and ignoreDynamicRequires option of @rollup/plugin-commonjs appropriately for this require call to work.')}var Yo={exports:{}};/*!

JSZip v3.10.1 - A JavaScript class for generating and reading zip files
<http://stuartk.com/jszip>

(c) 2009-2016 Stuart Knightley <stuart [at] stuartk.com>
Dual licenced under the MIT license or GPLv3. See https://raw.github.com/Stuk/jszip/main/LICENSE.markdown.

JSZip uses the library pako released under the MIT license :
https://github.com/nodeca/pako/blob/main/LICENSE
*/var Er;function z1(){return Er||(Er=1,(function(t,i){(function(e){t.exports=e()})(function(){return(function e(n,o,s){function l(c,u){if(!o[c]){if(!n[c]){var m=typeof Yn=="function"&&Yn;if(!u&&m)return m(c,!0);if(r)return r(c,!0);var g=new Error("Cannot find module '"+c+"'");throw g.code="MODULE_NOT_FOUND",g}var d=o[c]={exports:{}};n[c][0].call(d.exports,function(y){var f=n[c][1][y];return l(f||y)},d,d.exports,e,n,o,s)}return o[c].exports}for(var r=typeof Yn=="function"&&Yn,a=0;a<s.length;a++)l(s[a]);return l})({1:[function(e,n,o){var s=e("./utils"),l=e("./support"),r="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";o.encode=function(a){for(var c,u,m,g,d,y,f,v=[],k=0,x=a.length,S=x,B=s.getTypeOf(a)!=="string";k<a.length;)S=x-k,m=B?(c=a[k++],u=k<x?a[k++]:0,k<x?a[k++]:0):(c=a.charCodeAt(k++),u=k<x?a.charCodeAt(k++):0,k<x?a.charCodeAt(k++):0),g=c>>2,d=(3&c)<<4|u>>4,y=1<S?(15&u)<<2|m>>6:64,f=2<S?63&m:64,v.push(r.charAt(g)+r.charAt(d)+r.charAt(y)+r.charAt(f));return v.join("")},o.decode=function(a){var c,u,m,g,d,y,f=0,v=0,k="data:";if(a.substr(0,k.length)===k)throw new Error("Invalid base64 input, it looks like a data url.");var x,S=3*(a=a.replace(/[^A-Za-z0-9+/=]/g,"")).length/4;if(a.charAt(a.length-1)===r.charAt(64)&&S--,a.charAt(a.length-2)===r.charAt(64)&&S--,S%1!=0)throw new Error("Invalid base64 input, bad content length.");for(x=l.uint8array?new Uint8Array(0|S):new Array(0|S);f<a.length;)c=r.indexOf(a.charAt(f++))<<2|(g=r.indexOf(a.charAt(f++)))>>4,u=(15&g)<<4|(d=r.indexOf(a.charAt(f++)))>>2,m=(3&d)<<6|(y=r.indexOf(a.charAt(f++))),x[v++]=c,d!==64&&(x[v++]=u),y!==64&&(x[v++]=m);return x}},{"./support":30,"./utils":32}],2:[function(e,n,o){var s=e("./external"),l=e("./stream/DataWorker"),r=e("./stream/Crc32Probe"),a=e("./stream/DataLengthProbe");function c(u,m,g,d,y){this.compressedSize=u,this.uncompressedSize=m,this.crc32=g,this.compression=d,this.compressedContent=y}c.prototype={getContentWorker:function(){var u=new l(s.Promise.resolve(this.compressedContent)).pipe(this.compression.uncompressWorker()).pipe(new a("data_length")),m=this;return u.on("end",function(){if(this.streamInfo.data_length!==m.uncompressedSize)throw new Error("Bug : uncompressed data size mismatch")}),u},getCompressedWorker:function(){return new l(s.Promise.resolve(this.compressedContent)).withStreamInfo("compressedSize",this.compressedSize).withStreamInfo("uncompressedSize",this.uncompressedSize).withStreamInfo("crc32",this.crc32).withStreamInfo("compression",this.compression)}},c.createWorkerFrom=function(u,m,g){return u.pipe(new r).pipe(new a("uncompressedSize")).pipe(m.compressWorker(g)).pipe(new a("compressedSize")).withStreamInfo("compression",m)},n.exports=c},{"./external":6,"./stream/Crc32Probe":25,"./stream/DataLengthProbe":26,"./stream/DataWorker":27}],3:[function(e,n,o){var s=e("./stream/GenericWorker");o.STORE={magic:"\0\0",compressWorker:function(){return new s("STORE compression")},uncompressWorker:function(){return new s("STORE decompression")}},o.DEFLATE=e("./flate")},{"./flate":7,"./stream/GenericWorker":28}],4:[function(e,n,o){var s=e("./utils"),l=(function(){for(var r,a=[],c=0;c<256;c++){r=c;for(var u=0;u<8;u++)r=1&r?3988292384^r>>>1:r>>>1;a[c]=r}return a})();n.exports=function(r,a){return r!==void 0&&r.length?s.getTypeOf(r)!=="string"?(function(c,u,m,g){var d=l,y=g+m;c^=-1;for(var f=g;f<y;f++)c=c>>>8^d[255&(c^u[f])];return-1^c})(0|a,r,r.length,0):(function(c,u,m,g){var d=l,y=g+m;c^=-1;for(var f=g;f<y;f++)c=c>>>8^d[255&(c^u.charCodeAt(f))];return-1^c})(0|a,r,r.length,0):0}},{"./utils":32}],5:[function(e,n,o){o.base64=!1,o.binary=!1,o.dir=!1,o.createFolders=!0,o.date=null,o.compression=null,o.compressionOptions=null,o.comment=null,o.unixPermissions=null,o.dosPermissions=null},{}],6:[function(e,n,o){var s=null;s=typeof Promise<"u"?Promise:e("lie"),n.exports={Promise:s}},{lie:37}],7:[function(e,n,o){var s=typeof Uint8Array<"u"&&typeof Uint16Array<"u"&&typeof Uint32Array<"u",l=e("pako"),r=e("./utils"),a=e("./stream/GenericWorker"),c=s?"uint8array":"array";function u(m,g){a.call(this,"FlateWorker/"+m),this._pako=null,this._pakoAction=m,this._pakoOptions=g,this.meta={}}o.magic="\b\0",r.inherits(u,a),u.prototype.processChunk=function(m){this.meta=m.meta,this._pako===null&&this._createPako(),this._pako.push(r.transformTo(c,m.data),!1)},u.prototype.flush=function(){a.prototype.flush.call(this),this._pako===null&&this._createPako(),this._pako.push([],!0)},u.prototype.cleanUp=function(){a.prototype.cleanUp.call(this),this._pako=null},u.prototype._createPako=function(){this._pako=new l[this._pakoAction]({raw:!0,level:this._pakoOptions.level||-1});var m=this;this._pako.onData=function(g){m.push({data:g,meta:m.meta})}},o.compressWorker=function(m){return new u("Deflate",m)},o.uncompressWorker=function(){return new u("Inflate",{})}},{"./stream/GenericWorker":28,"./utils":32,pako:38}],8:[function(e,n,o){function s(d,y){var f,v="";for(f=0;f<y;f++)v+=String.fromCharCode(255&d),d>>>=8;return v}function l(d,y,f,v,k,x){var S,B,A=d.file,I=d.compression,w=x!==c.utf8encode,z=r.transformTo("string",x(A.name)),O=r.transformTo("string",c.utf8encode(A.name)),H=A.comment,et=r.transformTo("string",x(H)),_=r.transformTo("string",c.utf8encode(H)),P=O.length!==A.name.length,b=_.length!==H.length,N="",J="",U="",G=A.dir,V=A.date,M={crc32:0,compressedSize:0,uncompressedSize:0};y&&!f||(M.crc32=d.crc32,M.compressedSize=d.compressedSize,M.uncompressedSize=d.uncompressedSize);var E=0;y&&(E|=8),w||!P&&!b||(E|=2048);var R=0,tt=0;G&&(R|=16),k==="UNIX"?(tt=798,R|=(function(Y,W){var ut=Y;return Y||(ut=W?16893:33204),(65535&ut)<<16})(A.unixPermissions,G)):(tt=20,R|=(function(Y){return 63&(Y||0)})(A.dosPermissions)),S=V.getUTCHours(),S<<=6,S|=V.getUTCMinutes(),S<<=5,S|=V.getUTCSeconds()/2,B=V.getUTCFullYear()-1980,B<<=4,B|=V.getUTCMonth()+1,B<<=5,B|=V.getUTCDate(),P&&(J=s(1,1)+s(u(z),4)+O,N+="up"+s(J.length,2)+J),b&&(U=s(1,1)+s(u(et),4)+_,N+="uc"+s(U.length,2)+U);var Q="";return Q+=`
\0`,Q+=s(E,2),Q+=I.magic,Q+=s(S,2),Q+=s(B,2),Q+=s(M.crc32,4),Q+=s(M.compressedSize,4),Q+=s(M.uncompressedSize,4),Q+=s(z.length,2),Q+=s(N.length,2),{fileRecord:m.LOCAL_FILE_HEADER+Q+z+N,dirRecord:m.CENTRAL_FILE_HEADER+s(tt,2)+Q+s(et.length,2)+"\0\0\0\0"+s(R,4)+s(v,4)+z+N+et}}var r=e("../utils"),a=e("../stream/GenericWorker"),c=e("../utf8"),u=e("../crc32"),m=e("../signature");function g(d,y,f,v){a.call(this,"ZipFileWorker"),this.bytesWritten=0,this.zipComment=y,this.zipPlatform=f,this.encodeFileName=v,this.streamFiles=d,this.accumulate=!1,this.contentBuffer=[],this.dirRecords=[],this.currentSourceOffset=0,this.entriesCount=0,this.currentFile=null,this._sources=[]}r.inherits(g,a),g.prototype.push=function(d){var y=d.meta.percent||0,f=this.entriesCount,v=this._sources.length;this.accumulate?this.contentBuffer.push(d):(this.bytesWritten+=d.data.length,a.prototype.push.call(this,{data:d.data,meta:{currentFile:this.currentFile,percent:f?(y+100*(f-v-1))/f:100}}))},g.prototype.openedSource=function(d){this.currentSourceOffset=this.bytesWritten,this.currentFile=d.file.name;var y=this.streamFiles&&!d.file.dir;if(y){var f=l(d,y,!1,this.currentSourceOffset,this.zipPlatform,this.encodeFileName);this.push({data:f.fileRecord,meta:{percent:0}})}else this.accumulate=!0},g.prototype.closedSource=function(d){this.accumulate=!1;var y=this.streamFiles&&!d.file.dir,f=l(d,y,!0,this.currentSourceOffset,this.zipPlatform,this.encodeFileName);if(this.dirRecords.push(f.dirRecord),y)this.push({data:(function(v){return m.DATA_DESCRIPTOR+s(v.crc32,4)+s(v.compressedSize,4)+s(v.uncompressedSize,4)})(d),meta:{percent:100}});else for(this.push({data:f.fileRecord,meta:{percent:0}});this.contentBuffer.length;)this.push(this.contentBuffer.shift());this.currentFile=null},g.prototype.flush=function(){for(var d=this.bytesWritten,y=0;y<this.dirRecords.length;y++)this.push({data:this.dirRecords[y],meta:{percent:100}});var f=this.bytesWritten-d,v=(function(k,x,S,B,A){var I=r.transformTo("string",A(B));return m.CENTRAL_DIRECTORY_END+"\0\0\0\0"+s(k,2)+s(k,2)+s(x,4)+s(S,4)+s(I.length,2)+I})(this.dirRecords.length,f,d,this.zipComment,this.encodeFileName);this.push({data:v,meta:{percent:100}})},g.prototype.prepareNextSource=function(){this.previous=this._sources.shift(),this.openedSource(this.previous.streamInfo),this.isPaused?this.previous.pause():this.previous.resume()},g.prototype.registerPrevious=function(d){this._sources.push(d);var y=this;return d.on("data",function(f){y.processChunk(f)}),d.on("end",function(){y.closedSource(y.previous.streamInfo),y._sources.length?y.prepareNextSource():y.end()}),d.on("error",function(f){y.error(f)}),this},g.prototype.resume=function(){return!!a.prototype.resume.call(this)&&(!this.previous&&this._sources.length?(this.prepareNextSource(),!0):this.previous||this._sources.length||this.generatedError?void 0:(this.end(),!0))},g.prototype.error=function(d){var y=this._sources;if(!a.prototype.error.call(this,d))return!1;for(var f=0;f<y.length;f++)try{y[f].error(d)}catch{}return!0},g.prototype.lock=function(){a.prototype.lock.call(this);for(var d=this._sources,y=0;y<d.length;y++)d[y].lock()},n.exports=g},{"../crc32":4,"../signature":23,"../stream/GenericWorker":28,"../utf8":31,"../utils":32}],9:[function(e,n,o){var s=e("../compressions"),l=e("./ZipFileWorker");o.generateWorker=function(r,a,c){var u=new l(a.streamFiles,c,a.platform,a.encodeFileName),m=0;try{r.forEach(function(g,d){m++;var y=(function(x,S){var B=x||S,A=s[B];if(!A)throw new Error(B+" is not a valid compression method !");return A})(d.options.compression,a.compression),f=d.options.compressionOptions||a.compressionOptions||{},v=d.dir,k=d.date;d._compressWorker(y,f).withStreamInfo("file",{name:g,dir:v,date:k,comment:d.comment||"",unixPermissions:d.unixPermissions,dosPermissions:d.dosPermissions}).pipe(u)}),u.entriesCount=m}catch(g){u.error(g)}return u}},{"../compressions":3,"./ZipFileWorker":8}],10:[function(e,n,o){function s(){if(!(this instanceof s))return new s;if(arguments.length)throw new Error("The constructor with parameters has been removed in JSZip 3.0, please check the upgrade guide.");this.files=Object.create(null),this.comment=null,this.root="",this.clone=function(){var l=new s;for(var r in this)typeof this[r]!="function"&&(l[r]=this[r]);return l}}(s.prototype=e("./object")).loadAsync=e("./load"),s.support=e("./support"),s.defaults=e("./defaults"),s.version="3.10.1",s.loadAsync=function(l,r){return new s().loadAsync(l,r)},s.external=e("./external"),n.exports=s},{"./defaults":5,"./external":6,"./load":11,"./object":15,"./support":30}],11:[function(e,n,o){var s=e("./utils"),l=e("./external"),r=e("./utf8"),a=e("./zipEntries"),c=e("./stream/Crc32Probe"),u=e("./nodejsUtils");function m(g){return new l.Promise(function(d,y){var f=g.decompressed.getContentWorker().pipe(new c);f.on("error",function(v){y(v)}).on("end",function(){f.streamInfo.crc32!==g.decompressed.crc32?y(new Error("Corrupted zip : CRC32 mismatch")):d()}).resume()})}n.exports=function(g,d){var y=this;return d=s.extend(d||{},{base64:!1,checkCRC32:!1,optimizedBinaryString:!1,createFolders:!1,decodeFileName:r.utf8decode}),u.isNode&&u.isStream(g)?l.Promise.reject(new Error("JSZip can't accept a stream when loading a zip file.")):s.prepareContent("the loaded zip file",g,!0,d.optimizedBinaryString,d.base64).then(function(f){var v=new a(d);return v.load(f),v}).then(function(f){var v=[l.Promise.resolve(f)],k=f.files;if(d.checkCRC32)for(var x=0;x<k.length;x++)v.push(m(k[x]));return l.Promise.all(v)}).then(function(f){for(var v=f.shift(),k=v.files,x=0;x<k.length;x++){var S=k[x],B=S.fileNameStr,A=s.resolve(S.fileNameStr);y.file(A,S.decompressed,{binary:!0,optimizedBinaryString:!0,date:S.date,dir:S.dir,comment:S.fileCommentStr.length?S.fileCommentStr:null,unixPermissions:S.unixPermissions,dosPermissions:S.dosPermissions,createFolders:d.createFolders}),S.dir||(y.file(A).unsafeOriginalName=B)}return v.zipComment.length&&(y.comment=v.zipComment),y})}},{"./external":6,"./nodejsUtils":14,"./stream/Crc32Probe":25,"./utf8":31,"./utils":32,"./zipEntries":33}],12:[function(e,n,o){var s=e("../utils"),l=e("../stream/GenericWorker");function r(a,c){l.call(this,"Nodejs stream input adapter for "+a),this._upstreamEnded=!1,this._bindStream(c)}s.inherits(r,l),r.prototype._bindStream=function(a){var c=this;(this._stream=a).pause(),a.on("data",function(u){c.push({data:u,meta:{percent:0}})}).on("error",function(u){c.isPaused?this.generatedError=u:c.error(u)}).on("end",function(){c.isPaused?c._upstreamEnded=!0:c.end()})},r.prototype.pause=function(){return!!l.prototype.pause.call(this)&&(this._stream.pause(),!0)},r.prototype.resume=function(){return!!l.prototype.resume.call(this)&&(this._upstreamEnded?this.end():this._stream.resume(),!0)},n.exports=r},{"../stream/GenericWorker":28,"../utils":32}],13:[function(e,n,o){var s=e("readable-stream").Readable;function l(r,a,c){s.call(this,a),this._helper=r;var u=this;r.on("data",function(m,g){u.push(m)||u._helper.pause(),c&&c(g)}).on("error",function(m){u.emit("error",m)}).on("end",function(){u.push(null)})}e("../utils").inherits(l,s),l.prototype._read=function(){this._helper.resume()},n.exports=l},{"../utils":32,"readable-stream":16}],14:[function(e,n,o){n.exports={isNode:typeof Buffer<"u",newBufferFrom:function(s,l){if(Buffer.from&&Buffer.from!==Uint8Array.from)return Buffer.from(s,l);if(typeof s=="number")throw new Error('The "data" argument must not be a number');return new Buffer(s,l)},allocBuffer:function(s){if(Buffer.alloc)return Buffer.alloc(s);var l=new Buffer(s);return l.fill(0),l},isBuffer:function(s){return Buffer.isBuffer(s)},isStream:function(s){return s&&typeof s.on=="function"&&typeof s.pause=="function"&&typeof s.resume=="function"}}},{}],15:[function(e,n,o){function s(A,I,w){var z,O=r.getTypeOf(I),H=r.extend(w||{},u);H.date=H.date||new Date,H.compression!==null&&(H.compression=H.compression.toUpperCase()),typeof H.unixPermissions=="string"&&(H.unixPermissions=parseInt(H.unixPermissions,8)),H.unixPermissions&&16384&H.unixPermissions&&(H.dir=!0),H.dosPermissions&&16&H.dosPermissions&&(H.dir=!0),H.dir&&(A=k(A)),H.createFolders&&(z=v(A))&&x.call(this,z,!0);var et=O==="string"&&H.binary===!1&&H.base64===!1;w&&w.binary!==void 0||(H.binary=!et),(I instanceof m&&I.uncompressedSize===0||H.dir||!I||I.length===0)&&(H.base64=!1,H.binary=!0,I="",H.compression="STORE",O="string");var _=null;_=I instanceof m||I instanceof a?I:y.isNode&&y.isStream(I)?new f(A,I):r.prepareContent(A,I,H.binary,H.optimizedBinaryString,H.base64);var P=new g(A,_,H);this.files[A]=P}var l=e("./utf8"),r=e("./utils"),a=e("./stream/GenericWorker"),c=e("./stream/StreamHelper"),u=e("./defaults"),m=e("./compressedObject"),g=e("./zipObject"),d=e("./generate"),y=e("./nodejsUtils"),f=e("./nodejs/NodejsStreamInputAdapter"),v=function(A){A.slice(-1)==="/"&&(A=A.substring(0,A.length-1));var I=A.lastIndexOf("/");return 0<I?A.substring(0,I):""},k=function(A){return A.slice(-1)!=="/"&&(A+="/"),A},x=function(A,I){return I=I!==void 0?I:u.createFolders,A=k(A),this.files[A]||s.call(this,A,null,{dir:!0,createFolders:I}),this.files[A]};function S(A){return Object.prototype.toString.call(A)==="[object RegExp]"}var B={load:function(){throw new Error("This method has been removed in JSZip 3.0, please check the upgrade guide.")},forEach:function(A){var I,w,z;for(I in this.files)z=this.files[I],(w=I.slice(this.root.length,I.length))&&I.slice(0,this.root.length)===this.root&&A(w,z)},filter:function(A){var I=[];return this.forEach(function(w,z){A(w,z)&&I.push(z)}),I},file:function(A,I,w){if(arguments.length!==1)return A=this.root+A,s.call(this,A,I,w),this;if(S(A)){var z=A;return this.filter(function(H,et){return!et.dir&&z.test(H)})}var O=this.files[this.root+A];return O&&!O.dir?O:null},folder:function(A){if(!A)return this;if(S(A))return this.filter(function(O,H){return H.dir&&A.test(O)});var I=this.root+A,w=x.call(this,I),z=this.clone();return z.root=w.name,z},remove:function(A){A=this.root+A;var I=this.files[A];if(I||(A.slice(-1)!=="/"&&(A+="/"),I=this.files[A]),I&&!I.dir)delete this.files[A];else for(var w=this.filter(function(O,H){return H.name.slice(0,A.length)===A}),z=0;z<w.length;z++)delete this.files[w[z].name];return this},generate:function(){throw new Error("This method has been removed in JSZip 3.0, please check the upgrade guide.")},generateInternalStream:function(A){var I,w={};try{if((w=r.extend(A||{},{streamFiles:!1,compression:"STORE",compressionOptions:null,type:"",platform:"DOS",comment:null,mimeType:"application/zip",encodeFileName:l.utf8encode})).type=w.type.toLowerCase(),w.compression=w.compression.toUpperCase(),w.type==="binarystring"&&(w.type="string"),!w.type)throw new Error("No output type specified.");r.checkSupport(w.type),w.platform!=="darwin"&&w.platform!=="freebsd"&&w.platform!=="linux"&&w.platform!=="sunos"||(w.platform="UNIX"),w.platform==="win32"&&(w.platform="DOS");var z=w.comment||this.comment||"";I=d.generateWorker(this,w,z)}catch(O){(I=new a("error")).error(O)}return new c(I,w.type||"string",w.mimeType)},generateAsync:function(A,I){return this.generateInternalStream(A).accumulate(I)},generateNodeStream:function(A,I){return(A=A||{}).type||(A.type="nodebuffer"),this.generateInternalStream(A).toNodejsStream(I)}};n.exports=B},{"./compressedObject":2,"./defaults":5,"./generate":9,"./nodejs/NodejsStreamInputAdapter":12,"./nodejsUtils":14,"./stream/GenericWorker":28,"./stream/StreamHelper":29,"./utf8":31,"./utils":32,"./zipObject":35}],16:[function(e,n,o){n.exports=e("stream")},{stream:void 0}],17:[function(e,n,o){var s=e("./DataReader");function l(r){s.call(this,r);for(var a=0;a<this.data.length;a++)r[a]=255&r[a]}e("../utils").inherits(l,s),l.prototype.byteAt=function(r){return this.data[this.zero+r]},l.prototype.lastIndexOfSignature=function(r){for(var a=r.charCodeAt(0),c=r.charCodeAt(1),u=r.charCodeAt(2),m=r.charCodeAt(3),g=this.length-4;0<=g;--g)if(this.data[g]===a&&this.data[g+1]===c&&this.data[g+2]===u&&this.data[g+3]===m)return g-this.zero;return-1},l.prototype.readAndCheckSignature=function(r){var a=r.charCodeAt(0),c=r.charCodeAt(1),u=r.charCodeAt(2),m=r.charCodeAt(3),g=this.readData(4);return a===g[0]&&c===g[1]&&u===g[2]&&m===g[3]},l.prototype.readData=function(r){if(this.checkOffset(r),r===0)return[];var a=this.data.slice(this.zero+this.index,this.zero+this.index+r);return this.index+=r,a},n.exports=l},{"../utils":32,"./DataReader":18}],18:[function(e,n,o){var s=e("../utils");function l(r){this.data=r,this.length=r.length,this.index=0,this.zero=0}l.prototype={checkOffset:function(r){this.checkIndex(this.index+r)},checkIndex:function(r){if(this.length<this.zero+r||r<0)throw new Error("End of data reached (data length = "+this.length+", asked index = "+r+"). Corrupted zip ?")},setIndex:function(r){this.checkIndex(r),this.index=r},skip:function(r){this.setIndex(this.index+r)},byteAt:function(){},readInt:function(r){var a,c=0;for(this.checkOffset(r),a=this.index+r-1;a>=this.index;a--)c=(c<<8)+this.byteAt(a);return this.index+=r,c},readString:function(r){return s.transformTo("string",this.readData(r))},readData:function(){},lastIndexOfSignature:function(){},readAndCheckSignature:function(){},readDate:function(){var r=this.readInt(4);return new Date(Date.UTC(1980+(r>>25&127),(r>>21&15)-1,r>>16&31,r>>11&31,r>>5&63,(31&r)<<1))}},n.exports=l},{"../utils":32}],19:[function(e,n,o){var s=e("./Uint8ArrayReader");function l(r){s.call(this,r)}e("../utils").inherits(l,s),l.prototype.readData=function(r){this.checkOffset(r);var a=this.data.slice(this.zero+this.index,this.zero+this.index+r);return this.index+=r,a},n.exports=l},{"../utils":32,"./Uint8ArrayReader":21}],20:[function(e,n,o){var s=e("./DataReader");function l(r){s.call(this,r)}e("../utils").inherits(l,s),l.prototype.byteAt=function(r){return this.data.charCodeAt(this.zero+r)},l.prototype.lastIndexOfSignature=function(r){return this.data.lastIndexOf(r)-this.zero},l.prototype.readAndCheckSignature=function(r){return r===this.readData(4)},l.prototype.readData=function(r){this.checkOffset(r);var a=this.data.slice(this.zero+this.index,this.zero+this.index+r);return this.index+=r,a},n.exports=l},{"../utils":32,"./DataReader":18}],21:[function(e,n,o){var s=e("./ArrayReader");function l(r){s.call(this,r)}e("../utils").inherits(l,s),l.prototype.readData=function(r){if(this.checkOffset(r),r===0)return new Uint8Array(0);var a=this.data.subarray(this.zero+this.index,this.zero+this.index+r);return this.index+=r,a},n.exports=l},{"../utils":32,"./ArrayReader":17}],22:[function(e,n,o){var s=e("../utils"),l=e("../support"),r=e("./ArrayReader"),a=e("./StringReader"),c=e("./NodeBufferReader"),u=e("./Uint8ArrayReader");n.exports=function(m){var g=s.getTypeOf(m);return s.checkSupport(g),g!=="string"||l.uint8array?g==="nodebuffer"?new c(m):l.uint8array?new u(s.transformTo("uint8array",m)):new r(s.transformTo("array",m)):new a(m)}},{"../support":30,"../utils":32,"./ArrayReader":17,"./NodeBufferReader":19,"./StringReader":20,"./Uint8ArrayReader":21}],23:[function(e,n,o){o.LOCAL_FILE_HEADER="PK",o.CENTRAL_FILE_HEADER="PK",o.CENTRAL_DIRECTORY_END="PK",o.ZIP64_CENTRAL_DIRECTORY_LOCATOR="PK\x07",o.ZIP64_CENTRAL_DIRECTORY_END="PK",o.DATA_DESCRIPTOR="PK\x07\b"},{}],24:[function(e,n,o){var s=e("./GenericWorker"),l=e("../utils");function r(a){s.call(this,"ConvertWorker to "+a),this.destType=a}l.inherits(r,s),r.prototype.processChunk=function(a){this.push({data:l.transformTo(this.destType,a.data),meta:a.meta})},n.exports=r},{"../utils":32,"./GenericWorker":28}],25:[function(e,n,o){var s=e("./GenericWorker"),l=e("../crc32");function r(){s.call(this,"Crc32Probe"),this.withStreamInfo("crc32",0)}e("../utils").inherits(r,s),r.prototype.processChunk=function(a){this.streamInfo.crc32=l(a.data,this.streamInfo.crc32||0),this.push(a)},n.exports=r},{"../crc32":4,"../utils":32,"./GenericWorker":28}],26:[function(e,n,o){var s=e("../utils"),l=e("./GenericWorker");function r(a){l.call(this,"DataLengthProbe for "+a),this.propName=a,this.withStreamInfo(a,0)}s.inherits(r,l),r.prototype.processChunk=function(a){if(a){var c=this.streamInfo[this.propName]||0;this.streamInfo[this.propName]=c+a.data.length}l.prototype.processChunk.call(this,a)},n.exports=r},{"../utils":32,"./GenericWorker":28}],27:[function(e,n,o){var s=e("../utils"),l=e("./GenericWorker");function r(a){l.call(this,"DataWorker");var c=this;this.dataIsReady=!1,this.index=0,this.max=0,this.data=null,this.type="",this._tickScheduled=!1,a.then(function(u){c.dataIsReady=!0,c.data=u,c.max=u&&u.length||0,c.type=s.getTypeOf(u),c.isPaused||c._tickAndRepeat()},function(u){c.error(u)})}s.inherits(r,l),r.prototype.cleanUp=function(){l.prototype.cleanUp.call(this),this.data=null},r.prototype.resume=function(){return!!l.prototype.resume.call(this)&&(!this._tickScheduled&&this.dataIsReady&&(this._tickScheduled=!0,s.delay(this._tickAndRepeat,[],this)),!0)},r.prototype._tickAndRepeat=function(){this._tickScheduled=!1,this.isPaused||this.isFinished||(this._tick(),this.isFinished||(s.delay(this._tickAndRepeat,[],this),this._tickScheduled=!0))},r.prototype._tick=function(){if(this.isPaused||this.isFinished)return!1;var a=null,c=Math.min(this.max,this.index+16384);if(this.index>=this.max)return this.end();switch(this.type){case"string":a=this.data.substring(this.index,c);break;case"uint8array":a=this.data.subarray(this.index,c);break;case"array":case"nodebuffer":a=this.data.slice(this.index,c)}return this.index=c,this.push({data:a,meta:{percent:this.max?this.index/this.max*100:0}})},n.exports=r},{"../utils":32,"./GenericWorker":28}],28:[function(e,n,o){function s(l){this.name=l||"default",this.streamInfo={},this.generatedError=null,this.extraStreamInfo={},this.isPaused=!0,this.isFinished=!1,this.isLocked=!1,this._listeners={data:[],end:[],error:[]},this.previous=null}s.prototype={push:function(l){this.emit("data",l)},end:function(){if(this.isFinished)return!1;this.flush();try{this.emit("end"),this.cleanUp(),this.isFinished=!0}catch(l){this.emit("error",l)}return!0},error:function(l){return!this.isFinished&&(this.isPaused?this.generatedError=l:(this.isFinished=!0,this.emit("error",l),this.previous&&this.previous.error(l),this.cleanUp()),!0)},on:function(l,r){return this._listeners[l].push(r),this},cleanUp:function(){this.streamInfo=this.generatedError=this.extraStreamInfo=null,this._listeners=[]},emit:function(l,r){if(this._listeners[l])for(var a=0;a<this._listeners[l].length;a++)this._listeners[l][a].call(this,r)},pipe:function(l){return l.registerPrevious(this)},registerPrevious:function(l){if(this.isLocked)throw new Error("The stream '"+this+"' has already been used.");this.streamInfo=l.streamInfo,this.mergeStreamInfo(),this.previous=l;var r=this;return l.on("data",function(a){r.processChunk(a)}),l.on("end",function(){r.end()}),l.on("error",function(a){r.error(a)}),this},pause:function(){return!this.isPaused&&!this.isFinished&&(this.isPaused=!0,this.previous&&this.previous.pause(),!0)},resume:function(){if(!this.isPaused||this.isFinished)return!1;var l=this.isPaused=!1;return this.generatedError&&(this.error(this.generatedError),l=!0),this.previous&&this.previous.resume(),!l},flush:function(){},processChunk:function(l){this.push(l)},withStreamInfo:function(l,r){return this.extraStreamInfo[l]=r,this.mergeStreamInfo(),this},mergeStreamInfo:function(){for(var l in this.extraStreamInfo)Object.prototype.hasOwnProperty.call(this.extraStreamInfo,l)&&(this.streamInfo[l]=this.extraStreamInfo[l])},lock:function(){if(this.isLocked)throw new Error("The stream '"+this+"' has already been used.");this.isLocked=!0,this.previous&&this.previous.lock()},toString:function(){var l="Worker "+this.name;return this.previous?this.previous+" -> "+l:l}},n.exports=s},{}],29:[function(e,n,o){var s=e("../utils"),l=e("./ConvertWorker"),r=e("./GenericWorker"),a=e("../base64"),c=e("../support"),u=e("../external"),m=null;if(c.nodestream)try{m=e("../nodejs/NodejsStreamOutputAdapter")}catch{}function g(y,f){return new u.Promise(function(v,k){var x=[],S=y._internalType,B=y._outputType,A=y._mimeType;y.on("data",function(I,w){x.push(I),f&&f(w)}).on("error",function(I){x=[],k(I)}).on("end",function(){try{var I=(function(w,z,O){switch(w){case"blob":return s.newBlob(s.transformTo("arraybuffer",z),O);case"base64":return a.encode(z);default:return s.transformTo(w,z)}})(B,(function(w,z){var O,H=0,et=null,_=0;for(O=0;O<z.length;O++)_+=z[O].length;switch(w){case"string":return z.join("");case"array":return Array.prototype.concat.apply([],z);case"uint8array":for(et=new Uint8Array(_),O=0;O<z.length;O++)et.set(z[O],H),H+=z[O].length;return et;case"nodebuffer":return Buffer.concat(z);default:throw new Error("concat : unsupported type '"+w+"'")}})(S,x),A);v(I)}catch(w){k(w)}x=[]}).resume()})}function d(y,f,v){var k=f;switch(f){case"blob":case"arraybuffer":k="uint8array";break;case"base64":k="string"}try{this._internalType=k,this._outputType=f,this._mimeType=v,s.checkSupport(k),this._worker=y.pipe(new l(k)),y.lock()}catch(x){this._worker=new r("error"),this._worker.error(x)}}d.prototype={accumulate:function(y){return g(this,y)},on:function(y,f){var v=this;return y==="data"?this._worker.on(y,function(k){f.call(v,k.data,k.meta)}):this._worker.on(y,function(){s.delay(f,arguments,v)}),this},resume:function(){return s.delay(this._worker.resume,[],this._worker),this},pause:function(){return this._worker.pause(),this},toNodejsStream:function(y){if(s.checkSupport("nodestream"),this._outputType!=="nodebuffer")throw new Error(this._outputType+" is not supported by this method");return new m(this,{objectMode:this._outputType!=="nodebuffer"},y)}},n.exports=d},{"../base64":1,"../external":6,"../nodejs/NodejsStreamOutputAdapter":13,"../support":30,"../utils":32,"./ConvertWorker":24,"./GenericWorker":28}],30:[function(e,n,o){if(o.base64=!0,o.array=!0,o.string=!0,o.arraybuffer=typeof ArrayBuffer<"u"&&typeof Uint8Array<"u",o.nodebuffer=typeof Buffer<"u",o.uint8array=typeof Uint8Array<"u",typeof ArrayBuffer>"u")o.blob=!1;else{var s=new ArrayBuffer(0);try{o.blob=new Blob([s],{type:"application/zip"}).size===0}catch{try{var l=new(self.BlobBuilder||self.WebKitBlobBuilder||self.MozBlobBuilder||self.MSBlobBuilder);l.append(s),o.blob=l.getBlob("application/zip").size===0}catch{o.blob=!1}}}try{o.nodestream=!!e("readable-stream").Readable}catch{o.nodestream=!1}},{"readable-stream":16}],31:[function(e,n,o){for(var s=e("./utils"),l=e("./support"),r=e("./nodejsUtils"),a=e("./stream/GenericWorker"),c=new Array(256),u=0;u<256;u++)c[u]=252<=u?6:248<=u?5:240<=u?4:224<=u?3:192<=u?2:1;c[254]=c[254]=1;function m(){a.call(this,"utf-8 decode"),this.leftOver=null}function g(){a.call(this,"utf-8 encode")}o.utf8encode=function(d){return l.nodebuffer?r.newBufferFrom(d,"utf-8"):(function(y){var f,v,k,x,S,B=y.length,A=0;for(x=0;x<B;x++)(64512&(v=y.charCodeAt(x)))==55296&&x+1<B&&(64512&(k=y.charCodeAt(x+1)))==56320&&(v=65536+(v-55296<<10)+(k-56320),x++),A+=v<128?1:v<2048?2:v<65536?3:4;for(f=l.uint8array?new Uint8Array(A):new Array(A),x=S=0;S<A;x++)(64512&(v=y.charCodeAt(x)))==55296&&x+1<B&&(64512&(k=y.charCodeAt(x+1)))==56320&&(v=65536+(v-55296<<10)+(k-56320),x++),v<128?f[S++]=v:(v<2048?f[S++]=192|v>>>6:(v<65536?f[S++]=224|v>>>12:(f[S++]=240|v>>>18,f[S++]=128|v>>>12&63),f[S++]=128|v>>>6&63),f[S++]=128|63&v);return f})(d)},o.utf8decode=function(d){return l.nodebuffer?s.transformTo("nodebuffer",d).toString("utf-8"):(function(y){var f,v,k,x,S=y.length,B=new Array(2*S);for(f=v=0;f<S;)if((k=y[f++])<128)B[v++]=k;else if(4<(x=c[k]))B[v++]=65533,f+=x-1;else{for(k&=x===2?31:x===3?15:7;1<x&&f<S;)k=k<<6|63&y[f++],x--;1<x?B[v++]=65533:k<65536?B[v++]=k:(k-=65536,B[v++]=55296|k>>10&1023,B[v++]=56320|1023&k)}return B.length!==v&&(B.subarray?B=B.subarray(0,v):B.length=v),s.applyFromCharCode(B)})(d=s.transformTo(l.uint8array?"uint8array":"array",d))},s.inherits(m,a),m.prototype.processChunk=function(d){var y=s.transformTo(l.uint8array?"uint8array":"array",d.data);if(this.leftOver&&this.leftOver.length){if(l.uint8array){var f=y;(y=new Uint8Array(f.length+this.leftOver.length)).set(this.leftOver,0),y.set(f,this.leftOver.length)}else y=this.leftOver.concat(y);this.leftOver=null}var v=(function(x,S){var B;for((S=S||x.length)>x.length&&(S=x.length),B=S-1;0<=B&&(192&x[B])==128;)B--;return B<0||B===0?S:B+c[x[B]]>S?B:S})(y),k=y;v!==y.length&&(l.uint8array?(k=y.subarray(0,v),this.leftOver=y.subarray(v,y.length)):(k=y.slice(0,v),this.leftOver=y.slice(v,y.length))),this.push({data:o.utf8decode(k),meta:d.meta})},m.prototype.flush=function(){this.leftOver&&this.leftOver.length&&(this.push({data:o.utf8decode(this.leftOver),meta:{}}),this.leftOver=null)},o.Utf8DecodeWorker=m,s.inherits(g,a),g.prototype.processChunk=function(d){this.push({data:o.utf8encode(d.data),meta:d.meta})},o.Utf8EncodeWorker=g},{"./nodejsUtils":14,"./stream/GenericWorker":28,"./support":30,"./utils":32}],32:[function(e,n,o){var s=e("./support"),l=e("./base64"),r=e("./nodejsUtils"),a=e("./external");function c(f){return f}function u(f,v){for(var k=0;k<f.length;++k)v[k]=255&f.charCodeAt(k);return v}e("setimmediate"),o.newBlob=function(f,v){o.checkSupport("blob");try{return new Blob([f],{type:v})}catch{try{var k=new(self.BlobBuilder||self.WebKitBlobBuilder||self.MozBlobBuilder||self.MSBlobBuilder);return k.append(f),k.getBlob(v)}catch{throw new Error("Bug : can't construct the Blob.")}}};var m={stringifyByChunk:function(f,v,k){var x=[],S=0,B=f.length;if(B<=k)return String.fromCharCode.apply(null,f);for(;S<B;)v==="array"||v==="nodebuffer"?x.push(String.fromCharCode.apply(null,f.slice(S,Math.min(S+k,B)))):x.push(String.fromCharCode.apply(null,f.subarray(S,Math.min(S+k,B)))),S+=k;return x.join("")},stringifyByChar:function(f){for(var v="",k=0;k<f.length;k++)v+=String.fromCharCode(f[k]);return v},applyCanBeUsed:{uint8array:(function(){try{return s.uint8array&&String.fromCharCode.apply(null,new Uint8Array(1)).length===1}catch{return!1}})(),nodebuffer:(function(){try{return s.nodebuffer&&String.fromCharCode.apply(null,r.allocBuffer(1)).length===1}catch{return!1}})()}};function g(f){var v=65536,k=o.getTypeOf(f),x=!0;if(k==="uint8array"?x=m.applyCanBeUsed.uint8array:k==="nodebuffer"&&(x=m.applyCanBeUsed.nodebuffer),x)for(;1<v;)try{return m.stringifyByChunk(f,k,v)}catch{v=Math.floor(v/2)}return m.stringifyByChar(f)}function d(f,v){for(var k=0;k<f.length;k++)v[k]=f[k];return v}o.applyFromCharCode=g;var y={};y.string={string:c,array:function(f){return u(f,new Array(f.length))},arraybuffer:function(f){return y.string.uint8array(f).buffer},uint8array:function(f){return u(f,new Uint8Array(f.length))},nodebuffer:function(f){return u(f,r.allocBuffer(f.length))}},y.array={string:g,array:c,arraybuffer:function(f){return new Uint8Array(f).buffer},uint8array:function(f){return new Uint8Array(f)},nodebuffer:function(f){return r.newBufferFrom(f)}},y.arraybuffer={string:function(f){return g(new Uint8Array(f))},array:function(f){return d(new Uint8Array(f),new Array(f.byteLength))},arraybuffer:c,uint8array:function(f){return new Uint8Array(f)},nodebuffer:function(f){return r.newBufferFrom(new Uint8Array(f))}},y.uint8array={string:g,array:function(f){return d(f,new Array(f.length))},arraybuffer:function(f){return f.buffer},uint8array:c,nodebuffer:function(f){return r.newBufferFrom(f)}},y.nodebuffer={string:g,array:function(f){return d(f,new Array(f.length))},arraybuffer:function(f){return y.nodebuffer.uint8array(f).buffer},uint8array:function(f){return d(f,new Uint8Array(f.length))},nodebuffer:c},o.transformTo=function(f,v){if(v=v||"",!f)return v;o.checkSupport(f);var k=o.getTypeOf(v);return y[k][f](v)},o.resolve=function(f){for(var v=f.split("/"),k=[],x=0;x<v.length;x++){var S=v[x];S==="."||S===""&&x!==0&&x!==v.length-1||(S===".."?k.pop():k.push(S))}return k.join("/")},o.getTypeOf=function(f){return typeof f=="string"?"string":Object.prototype.toString.call(f)==="[object Array]"?"array":s.nodebuffer&&r.isBuffer(f)?"nodebuffer":s.uint8array&&f instanceof Uint8Array?"uint8array":s.arraybuffer&&f instanceof ArrayBuffer?"arraybuffer":void 0},o.checkSupport=function(f){if(!s[f.toLowerCase()])throw new Error(f+" is not supported by this platform")},o.MAX_VALUE_16BITS=65535,o.MAX_VALUE_32BITS=-1,o.pretty=function(f){var v,k,x="";for(k=0;k<(f||"").length;k++)x+="\\x"+((v=f.charCodeAt(k))<16?"0":"")+v.toString(16).toUpperCase();return x},o.delay=function(f,v,k){setImmediate(function(){f.apply(k||null,v||[])})},o.inherits=function(f,v){function k(){}k.prototype=v.prototype,f.prototype=new k},o.extend=function(){var f,v,k={};for(f=0;f<arguments.length;f++)for(v in arguments[f])Object.prototype.hasOwnProperty.call(arguments[f],v)&&k[v]===void 0&&(k[v]=arguments[f][v]);return k},o.prepareContent=function(f,v,k,x,S){return a.Promise.resolve(v).then(function(B){return s.blob&&(B instanceof Blob||["[object File]","[object Blob]"].indexOf(Object.prototype.toString.call(B))!==-1)&&typeof FileReader<"u"?new a.Promise(function(A,I){var w=new FileReader;w.onload=function(z){A(z.target.result)},w.onerror=function(z){I(z.target.error)},w.readAsArrayBuffer(B)}):B}).then(function(B){var A=o.getTypeOf(B);return A?(A==="arraybuffer"?B=o.transformTo("uint8array",B):A==="string"&&(S?B=l.decode(B):k&&x!==!0&&(B=(function(I){return u(I,s.uint8array?new Uint8Array(I.length):new Array(I.length))})(B))),B):a.Promise.reject(new Error("Can't read the data of '"+f+"'. Is it in a supported JavaScript type (String, Blob, ArrayBuffer, etc) ?"))})}},{"./base64":1,"./external":6,"./nodejsUtils":14,"./support":30,setimmediate:54}],33:[function(e,n,o){var s=e("./reader/readerFor"),l=e("./utils"),r=e("./signature"),a=e("./zipEntry"),c=e("./support");function u(m){this.files=[],this.loadOptions=m}u.prototype={checkSignature:function(m){if(!this.reader.readAndCheckSignature(m)){this.reader.index-=4;var g=this.reader.readString(4);throw new Error("Corrupted zip or bug: unexpected signature ("+l.pretty(g)+", expected "+l.pretty(m)+")")}},isSignature:function(m,g){var d=this.reader.index;this.reader.setIndex(m);var y=this.reader.readString(4)===g;return this.reader.setIndex(d),y},readBlockEndOfCentral:function(){this.diskNumber=this.reader.readInt(2),this.diskWithCentralDirStart=this.reader.readInt(2),this.centralDirRecordsOnThisDisk=this.reader.readInt(2),this.centralDirRecords=this.reader.readInt(2),this.centralDirSize=this.reader.readInt(4),this.centralDirOffset=this.reader.readInt(4),this.zipCommentLength=this.reader.readInt(2);var m=this.reader.readData(this.zipCommentLength),g=c.uint8array?"uint8array":"array",d=l.transformTo(g,m);this.zipComment=this.loadOptions.decodeFileName(d)},readBlockZip64EndOfCentral:function(){this.zip64EndOfCentralSize=this.reader.readInt(8),this.reader.skip(4),this.diskNumber=this.reader.readInt(4),this.diskWithCentralDirStart=this.reader.readInt(4),this.centralDirRecordsOnThisDisk=this.reader.readInt(8),this.centralDirRecords=this.reader.readInt(8),this.centralDirSize=this.reader.readInt(8),this.centralDirOffset=this.reader.readInt(8),this.zip64ExtensibleData={};for(var m,g,d,y=this.zip64EndOfCentralSize-44;0<y;)m=this.reader.readInt(2),g=this.reader.readInt(4),d=this.reader.readData(g),this.zip64ExtensibleData[m]={id:m,length:g,value:d}},readBlockZip64EndOfCentralLocator:function(){if(this.diskWithZip64CentralDirStart=this.reader.readInt(4),this.relativeOffsetEndOfZip64CentralDir=this.reader.readInt(8),this.disksCount=this.reader.readInt(4),1<this.disksCount)throw new Error("Multi-volumes zip are not supported")},readLocalFiles:function(){var m,g;for(m=0;m<this.files.length;m++)g=this.files[m],this.reader.setIndex(g.localHeaderOffset),this.checkSignature(r.LOCAL_FILE_HEADER),g.readLocalPart(this.reader),g.handleUTF8(),g.processAttributes()},readCentralDir:function(){var m;for(this.reader.setIndex(this.centralDirOffset);this.reader.readAndCheckSignature(r.CENTRAL_FILE_HEADER);)(m=new a({zip64:this.zip64},this.loadOptions)).readCentralPart(this.reader),this.files.push(m);if(this.centralDirRecords!==this.files.length&&this.centralDirRecords!==0&&this.files.length===0)throw new Error("Corrupted zip or bug: expected "+this.centralDirRecords+" records in central dir, got "+this.files.length)},readEndOfCentral:function(){var m=this.reader.lastIndexOfSignature(r.CENTRAL_DIRECTORY_END);if(m<0)throw this.isSignature(0,r.LOCAL_FILE_HEADER)?new Error("Corrupted zip: can't find end of central directory"):new Error("Can't find end of central directory : is this a zip file ? If it is, see https://stuk.github.io/jszip/documentation/howto/read_zip.html");this.reader.setIndex(m);var g=m;if(this.checkSignature(r.CENTRAL_DIRECTORY_END),this.readBlockEndOfCentral(),this.diskNumber===l.MAX_VALUE_16BITS||this.diskWithCentralDirStart===l.MAX_VALUE_16BITS||this.centralDirRecordsOnThisDisk===l.MAX_VALUE_16BITS||this.centralDirRecords===l.MAX_VALUE_16BITS||this.centralDirSize===l.MAX_VALUE_32BITS||this.centralDirOffset===l.MAX_VALUE_32BITS){if(this.zip64=!0,(m=this.reader.lastIndexOfSignature(r.ZIP64_CENTRAL_DIRECTORY_LOCATOR))<0)throw new Error("Corrupted zip: can't find the ZIP64 end of central directory locator");if(this.reader.setIndex(m),this.checkSignature(r.ZIP64_CENTRAL_DIRECTORY_LOCATOR),this.readBlockZip64EndOfCentralLocator(),!this.isSignature(this.relativeOffsetEndOfZip64CentralDir,r.ZIP64_CENTRAL_DIRECTORY_END)&&(this.relativeOffsetEndOfZip64CentralDir=this.reader.lastIndexOfSignature(r.ZIP64_CENTRAL_DIRECTORY_END),this.relativeOffsetEndOfZip64CentralDir<0))throw new Error("Corrupted zip: can't find the ZIP64 end of central directory");this.reader.setIndex(this.relativeOffsetEndOfZip64CentralDir),this.checkSignature(r.ZIP64_CENTRAL_DIRECTORY_END),this.readBlockZip64EndOfCentral()}var d=this.centralDirOffset+this.centralDirSize;this.zip64&&(d+=20,d+=12+this.zip64EndOfCentralSize);var y=g-d;if(0<y)this.isSignature(g,r.CENTRAL_FILE_HEADER)||(this.reader.zero=y);else if(y<0)throw new Error("Corrupted zip: missing "+Math.abs(y)+" bytes.")},prepareReader:function(m){this.reader=s(m)},load:function(m){this.prepareReader(m),this.readEndOfCentral(),this.readCentralDir(),this.readLocalFiles()}},n.exports=u},{"./reader/readerFor":22,"./signature":23,"./support":30,"./utils":32,"./zipEntry":34}],34:[function(e,n,o){var s=e("./reader/readerFor"),l=e("./utils"),r=e("./compressedObject"),a=e("./crc32"),c=e("./utf8"),u=e("./compressions"),m=e("./support");function g(d,y){this.options=d,this.loadOptions=y}g.prototype={isEncrypted:function(){return(1&this.bitFlag)==1},useUTF8:function(){return(2048&this.bitFlag)==2048},readLocalPart:function(d){var y,f;if(d.skip(22),this.fileNameLength=d.readInt(2),f=d.readInt(2),this.fileName=d.readData(this.fileNameLength),d.skip(f),this.compressedSize===-1||this.uncompressedSize===-1)throw new Error("Bug or corrupted zip : didn't get enough information from the central directory (compressedSize === -1 || uncompressedSize === -1)");if((y=(function(v){for(var k in u)if(Object.prototype.hasOwnProperty.call(u,k)&&u[k].magic===v)return u[k];return null})(this.compressionMethod))===null)throw new Error("Corrupted zip : compression "+l.pretty(this.compressionMethod)+" unknown (inner file : "+l.transformTo("string",this.fileName)+")");this.decompressed=new r(this.compressedSize,this.uncompressedSize,this.crc32,y,d.readData(this.compressedSize))},readCentralPart:function(d){this.versionMadeBy=d.readInt(2),d.skip(2),this.bitFlag=d.readInt(2),this.compressionMethod=d.readString(2),this.date=d.readDate(),this.crc32=d.readInt(4),this.compressedSize=d.readInt(4),this.uncompressedSize=d.readInt(4);var y=d.readInt(2);if(this.extraFieldsLength=d.readInt(2),this.fileCommentLength=d.readInt(2),this.diskNumberStart=d.readInt(2),this.internalFileAttributes=d.readInt(2),this.externalFileAttributes=d.readInt(4),this.localHeaderOffset=d.readInt(4),this.isEncrypted())throw new Error("Encrypted zip are not supported");d.skip(y),this.readExtraFields(d),this.parseZIP64ExtraField(d),this.fileComment=d.readData(this.fileCommentLength)},processAttributes:function(){this.unixPermissions=null,this.dosPermissions=null;var d=this.versionMadeBy>>8;this.dir=!!(16&this.externalFileAttributes),d==0&&(this.dosPermissions=63&this.externalFileAttributes),d==3&&(this.unixPermissions=this.externalFileAttributes>>16&65535),this.dir||this.fileNameStr.slice(-1)!=="/"||(this.dir=!0)},parseZIP64ExtraField:function(){if(this.extraFields[1]){var d=s(this.extraFields[1].value);this.uncompressedSize===l.MAX_VALUE_32BITS&&(this.uncompressedSize=d.readInt(8)),this.compressedSize===l.MAX_VALUE_32BITS&&(this.compressedSize=d.readInt(8)),this.localHeaderOffset===l.MAX_VALUE_32BITS&&(this.localHeaderOffset=d.readInt(8)),this.diskNumberStart===l.MAX_VALUE_32BITS&&(this.diskNumberStart=d.readInt(4))}},readExtraFields:function(d){var y,f,v,k=d.index+this.extraFieldsLength;for(this.extraFields||(this.extraFields={});d.index+4<k;)y=d.readInt(2),f=d.readInt(2),v=d.readData(f),this.extraFields[y]={id:y,length:f,value:v};d.setIndex(k)},handleUTF8:function(){var d=m.uint8array?"uint8array":"array";if(this.useUTF8())this.fileNameStr=c.utf8decode(this.fileName),this.fileCommentStr=c.utf8decode(this.fileComment);else{var y=this.findExtraFieldUnicodePath();if(y!==null)this.fileNameStr=y;else{var f=l.transformTo(d,this.fileName);this.fileNameStr=this.loadOptions.decodeFileName(f)}var v=this.findExtraFieldUnicodeComment();if(v!==null)this.fileCommentStr=v;else{var k=l.transformTo(d,this.fileComment);this.fileCommentStr=this.loadOptions.decodeFileName(k)}}},findExtraFieldUnicodePath:function(){var d=this.extraFields[28789];if(d){var y=s(d.value);return y.readInt(1)!==1||a(this.fileName)!==y.readInt(4)?null:c.utf8decode(y.readData(d.length-5))}return null},findExtraFieldUnicodeComment:function(){var d=this.extraFields[25461];if(d){var y=s(d.value);return y.readInt(1)!==1||a(this.fileComment)!==y.readInt(4)?null:c.utf8decode(y.readData(d.length-5))}return null}},n.exports=g},{"./compressedObject":2,"./compressions":3,"./crc32":4,"./reader/readerFor":22,"./support":30,"./utf8":31,"./utils":32}],35:[function(e,n,o){function s(y,f,v){this.name=y,this.dir=v.dir,this.date=v.date,this.comment=v.comment,this.unixPermissions=v.unixPermissions,this.dosPermissions=v.dosPermissions,this._data=f,this._dataBinary=v.binary,this.options={compression:v.compression,compressionOptions:v.compressionOptions}}var l=e("./stream/StreamHelper"),r=e("./stream/DataWorker"),a=e("./utf8"),c=e("./compressedObject"),u=e("./stream/GenericWorker");s.prototype={internalStream:function(y){var f=null,v="string";try{if(!y)throw new Error("No output type specified.");var k=(v=y.toLowerCase())==="string"||v==="text";v!=="binarystring"&&v!=="text"||(v="string"),f=this._decompressWorker();var x=!this._dataBinary;x&&!k&&(f=f.pipe(new a.Utf8EncodeWorker)),!x&&k&&(f=f.pipe(new a.Utf8DecodeWorker))}catch(S){(f=new u("error")).error(S)}return new l(f,v,"")},async:function(y,f){return this.internalStream(y).accumulate(f)},nodeStream:function(y,f){return this.internalStream(y||"nodebuffer").toNodejsStream(f)},_compressWorker:function(y,f){if(this._data instanceof c&&this._data.compression.magic===y.magic)return this._data.getCompressedWorker();var v=this._decompressWorker();return this._dataBinary||(v=v.pipe(new a.Utf8EncodeWorker)),c.createWorkerFrom(v,y,f)},_decompressWorker:function(){return this._data instanceof c?this._data.getContentWorker():this._data instanceof u?this._data:new r(this._data)}};for(var m=["asText","asBinary","asNodeBuffer","asUint8Array","asArrayBuffer"],g=function(){throw new Error("This method has been removed in JSZip 3.0, please check the upgrade guide.")},d=0;d<m.length;d++)s.prototype[m[d]]=g;n.exports=s},{"./compressedObject":2,"./stream/DataWorker":27,"./stream/GenericWorker":28,"./stream/StreamHelper":29,"./utf8":31}],36:[function(e,n,o){(function(s){var l,r,a=s.MutationObserver||s.WebKitMutationObserver;if(a){var c=0,u=new a(y),m=s.document.createTextNode("");u.observe(m,{characterData:!0}),l=function(){m.data=c=++c%2}}else if(s.setImmediate||s.MessageChannel===void 0)l="document"in s&&"onreadystatechange"in s.document.createElement("script")?function(){var f=s.document.createElement("script");f.onreadystatechange=function(){y(),f.onreadystatechange=null,f.parentNode.removeChild(f),f=null},s.document.documentElement.appendChild(f)}:function(){setTimeout(y,0)};else{var g=new s.MessageChannel;g.port1.onmessage=y,l=function(){g.port2.postMessage(0)}}var d=[];function y(){var f,v;r=!0;for(var k=d.length;k;){for(v=d,d=[],f=-1;++f<k;)v[f]();k=d.length}r=!1}n.exports=function(f){d.push(f)!==1||r||l()}}).call(this,typeof Zn<"u"?Zn:typeof self<"u"?self:typeof window<"u"?window:{})},{}],37:[function(e,n,o){var s=e("immediate");function l(){}var r={},a=["REJECTED"],c=["FULFILLED"],u=["PENDING"];function m(k){if(typeof k!="function")throw new TypeError("resolver must be a function");this.state=u,this.queue=[],this.outcome=void 0,k!==l&&f(this,k)}function g(k,x,S){this.promise=k,typeof x=="function"&&(this.onFulfilled=x,this.callFulfilled=this.otherCallFulfilled),typeof S=="function"&&(this.onRejected=S,this.callRejected=this.otherCallRejected)}function d(k,x,S){s(function(){var B;try{B=x(S)}catch(A){return r.reject(k,A)}B===k?r.reject(k,new TypeError("Cannot resolve promise with itself")):r.resolve(k,B)})}function y(k){var x=k&&k.then;if(k&&(typeof k=="object"||typeof k=="function")&&typeof x=="function")return function(){x.apply(k,arguments)}}function f(k,x){var S=!1;function B(w){S||(S=!0,r.reject(k,w))}function A(w){S||(S=!0,r.resolve(k,w))}var I=v(function(){x(A,B)});I.status==="error"&&B(I.value)}function v(k,x){var S={};try{S.value=k(x),S.status="success"}catch(B){S.status="error",S.value=B}return S}(n.exports=m).prototype.finally=function(k){if(typeof k!="function")return this;var x=this.constructor;return this.then(function(S){return x.resolve(k()).then(function(){return S})},function(S){return x.resolve(k()).then(function(){throw S})})},m.prototype.catch=function(k){return this.then(null,k)},m.prototype.then=function(k,x){if(typeof k!="function"&&this.state===c||typeof x!="function"&&this.state===a)return this;var S=new this.constructor(l);return this.state!==u?d(S,this.state===c?k:x,this.outcome):this.queue.push(new g(S,k,x)),S},g.prototype.callFulfilled=function(k){r.resolve(this.promise,k)},g.prototype.otherCallFulfilled=function(k){d(this.promise,this.onFulfilled,k)},g.prototype.callRejected=function(k){r.reject(this.promise,k)},g.prototype.otherCallRejected=function(k){d(this.promise,this.onRejected,k)},r.resolve=function(k,x){var S=v(y,x);if(S.status==="error")return r.reject(k,S.value);var B=S.value;if(B)f(k,B);else{k.state=c,k.outcome=x;for(var A=-1,I=k.queue.length;++A<I;)k.queue[A].callFulfilled(x)}return k},r.reject=function(k,x){k.state=a,k.outcome=x;for(var S=-1,B=k.queue.length;++S<B;)k.queue[S].callRejected(x);return k},m.resolve=function(k){return k instanceof this?k:r.resolve(new this(l),k)},m.reject=function(k){var x=new this(l);return r.reject(x,k)},m.all=function(k){var x=this;if(Object.prototype.toString.call(k)!=="[object Array]")return this.reject(new TypeError("must be an array"));var S=k.length,B=!1;if(!S)return this.resolve([]);for(var A=new Array(S),I=0,w=-1,z=new this(l);++w<S;)O(k[w],w);return z;function O(H,et){x.resolve(H).then(function(_){A[et]=_,++I!==S||B||(B=!0,r.resolve(z,A))},function(_){B||(B=!0,r.reject(z,_))})}},m.race=function(k){var x=this;if(Object.prototype.toString.call(k)!=="[object Array]")return this.reject(new TypeError("must be an array"));var S=k.length,B=!1;if(!S)return this.resolve([]);for(var A=-1,I=new this(l);++A<S;)w=k[A],x.resolve(w).then(function(z){B||(B=!0,r.resolve(I,z))},function(z){B||(B=!0,r.reject(I,z))});var w;return I}},{immediate:36}],38:[function(e,n,o){var s={};(0,e("./lib/utils/common").assign)(s,e("./lib/deflate"),e("./lib/inflate"),e("./lib/zlib/constants")),n.exports=s},{"./lib/deflate":39,"./lib/inflate":40,"./lib/utils/common":41,"./lib/zlib/constants":44}],39:[function(e,n,o){var s=e("./zlib/deflate"),l=e("./utils/common"),r=e("./utils/strings"),a=e("./zlib/messages"),c=e("./zlib/zstream"),u=Object.prototype.toString,m=0,g=-1,d=0,y=8;function f(k){if(!(this instanceof f))return new f(k);this.options=l.assign({level:g,method:y,chunkSize:16384,windowBits:15,memLevel:8,strategy:d,to:""},k||{});var x=this.options;x.raw&&0<x.windowBits?x.windowBits=-x.windowBits:x.gzip&&0<x.windowBits&&x.windowBits<16&&(x.windowBits+=16),this.err=0,this.msg="",this.ended=!1,this.chunks=[],this.strm=new c,this.strm.avail_out=0;var S=s.deflateInit2(this.strm,x.level,x.method,x.windowBits,x.memLevel,x.strategy);if(S!==m)throw new Error(a[S]);if(x.header&&s.deflateSetHeader(this.strm,x.header),x.dictionary){var B;if(B=typeof x.dictionary=="string"?r.string2buf(x.dictionary):u.call(x.dictionary)==="[object ArrayBuffer]"?new Uint8Array(x.dictionary):x.dictionary,(S=s.deflateSetDictionary(this.strm,B))!==m)throw new Error(a[S]);this._dict_set=!0}}function v(k,x){var S=new f(x);if(S.push(k,!0),S.err)throw S.msg||a[S.err];return S.result}f.prototype.push=function(k,x){var S,B,A=this.strm,I=this.options.chunkSize;if(this.ended)return!1;B=x===~~x?x:x===!0?4:0,typeof k=="string"?A.input=r.string2buf(k):u.call(k)==="[object ArrayBuffer]"?A.input=new Uint8Array(k):A.input=k,A.next_in=0,A.avail_in=A.input.length;do{if(A.avail_out===0&&(A.output=new l.Buf8(I),A.next_out=0,A.avail_out=I),(S=s.deflate(A,B))!==1&&S!==m)return this.onEnd(S),!(this.ended=!0);A.avail_out!==0&&(A.avail_in!==0||B!==4&&B!==2)||(this.options.to==="string"?this.onData(r.buf2binstring(l.shrinkBuf(A.output,A.next_out))):this.onData(l.shrinkBuf(A.output,A.next_out)))}while((0<A.avail_in||A.avail_out===0)&&S!==1);return B===4?(S=s.deflateEnd(this.strm),this.onEnd(S),this.ended=!0,S===m):B!==2||(this.onEnd(m),!(A.avail_out=0))},f.prototype.onData=function(k){this.chunks.push(k)},f.prototype.onEnd=function(k){k===m&&(this.options.to==="string"?this.result=this.chunks.join(""):this.result=l.flattenChunks(this.chunks)),this.chunks=[],this.err=k,this.msg=this.strm.msg},o.Deflate=f,o.deflate=v,o.deflateRaw=function(k,x){return(x=x||{}).raw=!0,v(k,x)},o.gzip=function(k,x){return(x=x||{}).gzip=!0,v(k,x)}},{"./utils/common":41,"./utils/strings":42,"./zlib/deflate":46,"./zlib/messages":51,"./zlib/zstream":53}],40:[function(e,n,o){var s=e("./zlib/inflate"),l=e("./utils/common"),r=e("./utils/strings"),a=e("./zlib/constants"),c=e("./zlib/messages"),u=e("./zlib/zstream"),m=e("./zlib/gzheader"),g=Object.prototype.toString;function d(f){if(!(this instanceof d))return new d(f);this.options=l.assign({chunkSize:16384,windowBits:0,to:""},f||{});var v=this.options;v.raw&&0<=v.windowBits&&v.windowBits<16&&(v.windowBits=-v.windowBits,v.windowBits===0&&(v.windowBits=-15)),!(0<=v.windowBits&&v.windowBits<16)||f&&f.windowBits||(v.windowBits+=32),15<v.windowBits&&v.windowBits<48&&(15&v.windowBits)==0&&(v.windowBits|=15),this.err=0,this.msg="",this.ended=!1,this.chunks=[],this.strm=new u,this.strm.avail_out=0;var k=s.inflateInit2(this.strm,v.windowBits);if(k!==a.Z_OK)throw new Error(c[k]);this.header=new m,s.inflateGetHeader(this.strm,this.header)}function y(f,v){var k=new d(v);if(k.push(f,!0),k.err)throw k.msg||c[k.err];return k.result}d.prototype.push=function(f,v){var k,x,S,B,A,I,w=this.strm,z=this.options.chunkSize,O=this.options.dictionary,H=!1;if(this.ended)return!1;x=v===~~v?v:v===!0?a.Z_FINISH:a.Z_NO_FLUSH,typeof f=="string"?w.input=r.binstring2buf(f):g.call(f)==="[object ArrayBuffer]"?w.input=new Uint8Array(f):w.input=f,w.next_in=0,w.avail_in=w.input.length;do{if(w.avail_out===0&&(w.output=new l.Buf8(z),w.next_out=0,w.avail_out=z),(k=s.inflate(w,a.Z_NO_FLUSH))===a.Z_NEED_DICT&&O&&(I=typeof O=="string"?r.string2buf(O):g.call(O)==="[object ArrayBuffer]"?new Uint8Array(O):O,k=s.inflateSetDictionary(this.strm,I)),k===a.Z_BUF_ERROR&&H===!0&&(k=a.Z_OK,H=!1),k!==a.Z_STREAM_END&&k!==a.Z_OK)return this.onEnd(k),!(this.ended=!0);w.next_out&&(w.avail_out!==0&&k!==a.Z_STREAM_END&&(w.avail_in!==0||x!==a.Z_FINISH&&x!==a.Z_SYNC_FLUSH)||(this.options.to==="string"?(S=r.utf8border(w.output,w.next_out),B=w.next_out-S,A=r.buf2string(w.output,S),w.next_out=B,w.avail_out=z-B,B&&l.arraySet(w.output,w.output,S,B,0),this.onData(A)):this.onData(l.shrinkBuf(w.output,w.next_out)))),w.avail_in===0&&w.avail_out===0&&(H=!0)}while((0<w.avail_in||w.avail_out===0)&&k!==a.Z_STREAM_END);return k===a.Z_STREAM_END&&(x=a.Z_FINISH),x===a.Z_FINISH?(k=s.inflateEnd(this.strm),this.onEnd(k),this.ended=!0,k===a.Z_OK):x!==a.Z_SYNC_FLUSH||(this.onEnd(a.Z_OK),!(w.avail_out=0))},d.prototype.onData=function(f){this.chunks.push(f)},d.prototype.onEnd=function(f){f===a.Z_OK&&(this.options.to==="string"?this.result=this.chunks.join(""):this.result=l.flattenChunks(this.chunks)),this.chunks=[],this.err=f,this.msg=this.strm.msg},o.Inflate=d,o.inflate=y,o.inflateRaw=function(f,v){return(v=v||{}).raw=!0,y(f,v)},o.ungzip=y},{"./utils/common":41,"./utils/strings":42,"./zlib/constants":44,"./zlib/gzheader":47,"./zlib/inflate":49,"./zlib/messages":51,"./zlib/zstream":53}],41:[function(e,n,o){var s=typeof Uint8Array<"u"&&typeof Uint16Array<"u"&&typeof Int32Array<"u";o.assign=function(a){for(var c=Array.prototype.slice.call(arguments,1);c.length;){var u=c.shift();if(u){if(typeof u!="object")throw new TypeError(u+"must be non-object");for(var m in u)u.hasOwnProperty(m)&&(a[m]=u[m])}}return a},o.shrinkBuf=function(a,c){return a.length===c?a:a.subarray?a.subarray(0,c):(a.length=c,a)};var l={arraySet:function(a,c,u,m,g){if(c.subarray&&a.subarray)a.set(c.subarray(u,u+m),g);else for(var d=0;d<m;d++)a[g+d]=c[u+d]},flattenChunks:function(a){var c,u,m,g,d,y;for(c=m=0,u=a.length;c<u;c++)m+=a[c].length;for(y=new Uint8Array(m),c=g=0,u=a.length;c<u;c++)d=a[c],y.set(d,g),g+=d.length;return y}},r={arraySet:function(a,c,u,m,g){for(var d=0;d<m;d++)a[g+d]=c[u+d]},flattenChunks:function(a){return[].concat.apply([],a)}};o.setTyped=function(a){a?(o.Buf8=Uint8Array,o.Buf16=Uint16Array,o.Buf32=Int32Array,o.assign(o,l)):(o.Buf8=Array,o.Buf16=Array,o.Buf32=Array,o.assign(o,r))},o.setTyped(s)},{}],42:[function(e,n,o){var s=e("./common"),l=!0,r=!0;try{String.fromCharCode.apply(null,[0])}catch{l=!1}try{String.fromCharCode.apply(null,new Uint8Array(1))}catch{r=!1}for(var a=new s.Buf8(256),c=0;c<256;c++)a[c]=252<=c?6:248<=c?5:240<=c?4:224<=c?3:192<=c?2:1;function u(m,g){if(g<65537&&(m.subarray&&r||!m.subarray&&l))return String.fromCharCode.apply(null,s.shrinkBuf(m,g));for(var d="",y=0;y<g;y++)d+=String.fromCharCode(m[y]);return d}a[254]=a[254]=1,o.string2buf=function(m){var g,d,y,f,v,k=m.length,x=0;for(f=0;f<k;f++)(64512&(d=m.charCodeAt(f)))==55296&&f+1<k&&(64512&(y=m.charCodeAt(f+1)))==56320&&(d=65536+(d-55296<<10)+(y-56320),f++),x+=d<128?1:d<2048?2:d<65536?3:4;for(g=new s.Buf8(x),f=v=0;v<x;f++)(64512&(d=m.charCodeAt(f)))==55296&&f+1<k&&(64512&(y=m.charCodeAt(f+1)))==56320&&(d=65536+(d-55296<<10)+(y-56320),f++),d<128?g[v++]=d:(d<2048?g[v++]=192|d>>>6:(d<65536?g[v++]=224|d>>>12:(g[v++]=240|d>>>18,g[v++]=128|d>>>12&63),g[v++]=128|d>>>6&63),g[v++]=128|63&d);return g},o.buf2binstring=function(m){return u(m,m.length)},o.binstring2buf=function(m){for(var g=new s.Buf8(m.length),d=0,y=g.length;d<y;d++)g[d]=m.charCodeAt(d);return g},o.buf2string=function(m,g){var d,y,f,v,k=g||m.length,x=new Array(2*k);for(d=y=0;d<k;)if((f=m[d++])<128)x[y++]=f;else if(4<(v=a[f]))x[y++]=65533,d+=v-1;else{for(f&=v===2?31:v===3?15:7;1<v&&d<k;)f=f<<6|63&m[d++],v--;1<v?x[y++]=65533:f<65536?x[y++]=f:(f-=65536,x[y++]=55296|f>>10&1023,x[y++]=56320|1023&f)}return u(x,y)},o.utf8border=function(m,g){var d;for((g=g||m.length)>m.length&&(g=m.length),d=g-1;0<=d&&(192&m[d])==128;)d--;return d<0||d===0?g:d+a[m[d]]>g?d:g}},{"./common":41}],43:[function(e,n,o){n.exports=function(s,l,r,a){for(var c=65535&s|0,u=s>>>16&65535|0,m=0;r!==0;){for(r-=m=2e3<r?2e3:r;u=u+(c=c+l[a++]|0)|0,--m;);c%=65521,u%=65521}return c|u<<16|0}},{}],44:[function(e,n,o){n.exports={Z_NO_FLUSH:0,Z_PARTIAL_FLUSH:1,Z_SYNC_FLUSH:2,Z_FULL_FLUSH:3,Z_FINISH:4,Z_BLOCK:5,Z_TREES:6,Z_OK:0,Z_STREAM_END:1,Z_NEED_DICT:2,Z_ERRNO:-1,Z_STREAM_ERROR:-2,Z_DATA_ERROR:-3,Z_BUF_ERROR:-5,Z_NO_COMPRESSION:0,Z_BEST_SPEED:1,Z_BEST_COMPRESSION:9,Z_DEFAULT_COMPRESSION:-1,Z_FILTERED:1,Z_HUFFMAN_ONLY:2,Z_RLE:3,Z_FIXED:4,Z_DEFAULT_STRATEGY:0,Z_BINARY:0,Z_TEXT:1,Z_UNKNOWN:2,Z_DEFLATED:8}},{}],45:[function(e,n,o){var s=(function(){for(var l,r=[],a=0;a<256;a++){l=a;for(var c=0;c<8;c++)l=1&l?3988292384^l>>>1:l>>>1;r[a]=l}return r})();n.exports=function(l,r,a,c){var u=s,m=c+a;l^=-1;for(var g=c;g<m;g++)l=l>>>8^u[255&(l^r[g])];return-1^l}},{}],46:[function(e,n,o){var s,l=e("../utils/common"),r=e("./trees"),a=e("./adler32"),c=e("./crc32"),u=e("./messages"),m=0,g=4,d=0,y=-2,f=-1,v=4,k=2,x=8,S=9,B=286,A=30,I=19,w=2*B+1,z=15,O=3,H=258,et=H+O+1,_=42,P=113,b=1,N=2,J=3,U=4;function G(h,j){return h.msg=u[j],j}function V(h){return(h<<1)-(4<h?9:0)}function M(h){for(var j=h.length;0<=--j;)h[j]=0}function E(h){var j=h.state,L=j.pending;L>h.avail_out&&(L=h.avail_out),L!==0&&(l.arraySet(h.output,j.pending_buf,j.pending_out,L,h.next_out),h.next_out+=L,j.pending_out+=L,h.total_out+=L,h.avail_out-=L,j.pending-=L,j.pending===0&&(j.pending_out=0))}function R(h,j){r._tr_flush_block(h,0<=h.block_start?h.block_start:-1,h.strstart-h.block_start,j),h.block_start=h.strstart,E(h.strm)}function tt(h,j){h.pending_buf[h.pending++]=j}function Q(h,j){h.pending_buf[h.pending++]=j>>>8&255,h.pending_buf[h.pending++]=255&j}function Y(h,j){var L,C,$=h.max_chain_length,D=h.strstart,Z=h.prev_length,K=h.nice_match,q=h.strstart>h.w_size-et?h.strstart-(h.w_size-et):0,it=h.window,lt=h.w_mask,rt=h.prev,pt=h.strstart+H,wt=it[D+Z-1],kt=it[D+Z];h.prev_length>=h.good_match&&($>>=2),K>h.lookahead&&(K=h.lookahead);do if(it[(L=j)+Z]===kt&&it[L+Z-1]===wt&&it[L]===it[D]&&it[++L]===it[D+1]){D+=2,L++;do;while(it[++D]===it[++L]&&it[++D]===it[++L]&&it[++D]===it[++L]&&it[++D]===it[++L]&&it[++D]===it[++L]&&it[++D]===it[++L]&&it[++D]===it[++L]&&it[++D]===it[++L]&&D<pt);if(C=H-(pt-D),D=pt-H,Z<C){if(h.match_start=j,K<=(Z=C))break;wt=it[D+Z-1],kt=it[D+Z]}}while((j=rt[j&lt])>q&&--$!=0);return Z<=h.lookahead?Z:h.lookahead}function W(h){var j,L,C,$,D,Z,K,q,it,lt,rt=h.w_size;do{if($=h.window_size-h.lookahead-h.strstart,h.strstart>=rt+(rt-et)){for(l.arraySet(h.window,h.window,rt,rt,0),h.match_start-=rt,h.strstart-=rt,h.block_start-=rt,j=L=h.hash_size;C=h.head[--j],h.head[j]=rt<=C?C-rt:0,--L;);for(j=L=rt;C=h.prev[--j],h.prev[j]=rt<=C?C-rt:0,--L;);$+=rt}if(h.strm.avail_in===0)break;if(Z=h.strm,K=h.window,q=h.strstart+h.lookahead,it=$,lt=void 0,lt=Z.avail_in,it<lt&&(lt=it),L=lt===0?0:(Z.avail_in-=lt,l.arraySet(K,Z.input,Z.next_in,lt,q),Z.state.wrap===1?Z.adler=a(Z.adler,K,lt,q):Z.state.wrap===2&&(Z.adler=c(Z.adler,K,lt,q)),Z.next_in+=lt,Z.total_in+=lt,lt),h.lookahead+=L,h.lookahead+h.insert>=O)for(D=h.strstart-h.insert,h.ins_h=h.window[D],h.ins_h=(h.ins_h<<h.hash_shift^h.window[D+1])&h.hash_mask;h.insert&&(h.ins_h=(h.ins_h<<h.hash_shift^h.window[D+O-1])&h.hash_mask,h.prev[D&h.w_mask]=h.head[h.ins_h],h.head[h.ins_h]=D,D++,h.insert--,!(h.lookahead+h.insert<O)););}while(h.lookahead<et&&h.strm.avail_in!==0)}function ut(h,j){for(var L,C;;){if(h.lookahead<et){if(W(h),h.lookahead<et&&j===m)return b;if(h.lookahead===0)break}if(L=0,h.lookahead>=O&&(h.ins_h=(h.ins_h<<h.hash_shift^h.window[h.strstart+O-1])&h.hash_mask,L=h.prev[h.strstart&h.w_mask]=h.head[h.ins_h],h.head[h.ins_h]=h.strstart),L!==0&&h.strstart-L<=h.w_size-et&&(h.match_length=Y(h,L)),h.match_length>=O)if(C=r._tr_tally(h,h.strstart-h.match_start,h.match_length-O),h.lookahead-=h.match_length,h.match_length<=h.max_lazy_match&&h.lookahead>=O){for(h.match_length--;h.strstart++,h.ins_h=(h.ins_h<<h.hash_shift^h.window[h.strstart+O-1])&h.hash_mask,L=h.prev[h.strstart&h.w_mask]=h.head[h.ins_h],h.head[h.ins_h]=h.strstart,--h.match_length!=0;);h.strstart++}else h.strstart+=h.match_length,h.match_length=0,h.ins_h=h.window[h.strstart],h.ins_h=(h.ins_h<<h.hash_shift^h.window[h.strstart+1])&h.hash_mask;else C=r._tr_tally(h,0,h.window[h.strstart]),h.lookahead--,h.strstart++;if(C&&(R(h,!1),h.strm.avail_out===0))return b}return h.insert=h.strstart<O-1?h.strstart:O-1,j===g?(R(h,!0),h.strm.avail_out===0?J:U):h.last_lit&&(R(h,!1),h.strm.avail_out===0)?b:N}function ct(h,j){for(var L,C,$;;){if(h.lookahead<et){if(W(h),h.lookahead<et&&j===m)return b;if(h.lookahead===0)break}if(L=0,h.lookahead>=O&&(h.ins_h=(h.ins_h<<h.hash_shift^h.window[h.strstart+O-1])&h.hash_mask,L=h.prev[h.strstart&h.w_mask]=h.head[h.ins_h],h.head[h.ins_h]=h.strstart),h.prev_length=h.match_length,h.prev_match=h.match_start,h.match_length=O-1,L!==0&&h.prev_length<h.max_lazy_match&&h.strstart-L<=h.w_size-et&&(h.match_length=Y(h,L),h.match_length<=5&&(h.strategy===1||h.match_length===O&&4096<h.strstart-h.match_start)&&(h.match_length=O-1)),h.prev_length>=O&&h.match_length<=h.prev_length){for($=h.strstart+h.lookahead-O,C=r._tr_tally(h,h.strstart-1-h.prev_match,h.prev_length-O),h.lookahead-=h.prev_length-1,h.prev_length-=2;++h.strstart<=$&&(h.ins_h=(h.ins_h<<h.hash_shift^h.window[h.strstart+O-1])&h.hash_mask,L=h.prev[h.strstart&h.w_mask]=h.head[h.ins_h],h.head[h.ins_h]=h.strstart),--h.prev_length!=0;);if(h.match_available=0,h.match_length=O-1,h.strstart++,C&&(R(h,!1),h.strm.avail_out===0))return b}else if(h.match_available){if((C=r._tr_tally(h,0,h.window[h.strstart-1]))&&R(h,!1),h.strstart++,h.lookahead--,h.strm.avail_out===0)return b}else h.match_available=1,h.strstart++,h.lookahead--}return h.match_available&&(C=r._tr_tally(h,0,h.window[h.strstart-1]),h.match_available=0),h.insert=h.strstart<O-1?h.strstart:O-1,j===g?(R(h,!0),h.strm.avail_out===0?J:U):h.last_lit&&(R(h,!1),h.strm.avail_out===0)?b:N}function X(h,j,L,C,$){this.good_length=h,this.max_lazy=j,this.nice_length=L,this.max_chain=C,this.func=$}function dt(){this.strm=null,this.status=0,this.pending_buf=null,this.pending_buf_size=0,this.pending_out=0,this.pending=0,this.wrap=0,this.gzhead=null,this.gzindex=0,this.method=x,this.last_flush=-1,this.w_size=0,this.w_bits=0,this.w_mask=0,this.window=null,this.window_size=0,this.prev=null,this.head=null,this.ins_h=0,this.hash_size=0,this.hash_bits=0,this.hash_mask=0,this.hash_shift=0,this.block_start=0,this.match_length=0,this.prev_match=0,this.match_available=0,this.strstart=0,this.match_start=0,this.lookahead=0,this.prev_length=0,this.max_chain_length=0,this.max_lazy_match=0,this.level=0,this.strategy=0,this.good_match=0,this.nice_match=0,this.dyn_ltree=new l.Buf16(2*w),this.dyn_dtree=new l.Buf16(2*(2*A+1)),this.bl_tree=new l.Buf16(2*(2*I+1)),M(this.dyn_ltree),M(this.dyn_dtree),M(this.bl_tree),this.l_desc=null,this.d_desc=null,this.bl_desc=null,this.bl_count=new l.Buf16(z+1),this.heap=new l.Buf16(2*B+1),M(this.heap),this.heap_len=0,this.heap_max=0,this.depth=new l.Buf16(2*B+1),M(this.depth),this.l_buf=0,this.lit_bufsize=0,this.last_lit=0,this.d_buf=0,this.opt_len=0,this.static_len=0,this.matches=0,this.insert=0,this.bi_buf=0,this.bi_valid=0}function bt(h){var j;return h&&h.state?(h.total_in=h.total_out=0,h.data_type=k,(j=h.state).pending=0,j.pending_out=0,j.wrap<0&&(j.wrap=-j.wrap),j.status=j.wrap?_:P,h.adler=j.wrap===2?0:1,j.last_flush=m,r._tr_init(j),d):G(h,y)}function T(h){var j=bt(h);return j===d&&(function(L){L.window_size=2*L.w_size,M(L.head),L.max_lazy_match=s[L.level].max_lazy,L.good_match=s[L.level].good_length,L.nice_match=s[L.level].nice_length,L.max_chain_length=s[L.level].max_chain,L.strstart=0,L.block_start=0,L.lookahead=0,L.insert=0,L.match_length=L.prev_length=O-1,L.match_available=0,L.ins_h=0})(h.state),j}function F(h,j,L,C,$,D){if(!h)return y;var Z=1;if(j===f&&(j=6),C<0?(Z=0,C=-C):15<C&&(Z=2,C-=16),$<1||S<$||L!==x||C<8||15<C||j<0||9<j||D<0||v<D)return G(h,y);C===8&&(C=9);var K=new dt;return(h.state=K).strm=h,K.wrap=Z,K.gzhead=null,K.w_bits=C,K.w_size=1<<K.w_bits,K.w_mask=K.w_size-1,K.hash_bits=$+7,K.hash_size=1<<K.hash_bits,K.hash_mask=K.hash_size-1,K.hash_shift=~~((K.hash_bits+O-1)/O),K.window=new l.Buf8(2*K.w_size),K.head=new l.Buf16(K.hash_size),K.prev=new l.Buf16(K.w_size),K.lit_bufsize=1<<$+6,K.pending_buf_size=4*K.lit_bufsize,K.pending_buf=new l.Buf8(K.pending_buf_size),K.d_buf=1*K.lit_bufsize,K.l_buf=3*K.lit_bufsize,K.level=j,K.strategy=D,K.method=L,T(h)}s=[new X(0,0,0,0,function(h,j){var L=65535;for(L>h.pending_buf_size-5&&(L=h.pending_buf_size-5);;){if(h.lookahead<=1){if(W(h),h.lookahead===0&&j===m)return b;if(h.lookahead===0)break}h.strstart+=h.lookahead,h.lookahead=0;var C=h.block_start+L;if((h.strstart===0||h.strstart>=C)&&(h.lookahead=h.strstart-C,h.strstart=C,R(h,!1),h.strm.avail_out===0)||h.strstart-h.block_start>=h.w_size-et&&(R(h,!1),h.strm.avail_out===0))return b}return h.insert=0,j===g?(R(h,!0),h.strm.avail_out===0?J:U):(h.strstart>h.block_start&&(R(h,!1),h.strm.avail_out),b)}),new X(4,4,8,4,ut),new X(4,5,16,8,ut),new X(4,6,32,32,ut),new X(4,4,16,16,ct),new X(8,16,32,32,ct),new X(8,16,128,128,ct),new X(8,32,128,256,ct),new X(32,128,258,1024,ct),new X(32,258,258,4096,ct)],o.deflateInit=function(h,j){return F(h,j,x,15,8,0)},o.deflateInit2=F,o.deflateReset=T,o.deflateResetKeep=bt,o.deflateSetHeader=function(h,j){return h&&h.state?h.state.wrap!==2?y:(h.state.gzhead=j,d):y},o.deflate=function(h,j){var L,C,$,D;if(!h||!h.state||5<j||j<0)return h?G(h,y):y;if(C=h.state,!h.output||!h.input&&h.avail_in!==0||C.status===666&&j!==g)return G(h,h.avail_out===0?-5:y);if(C.strm=h,L=C.last_flush,C.last_flush=j,C.status===_)if(C.wrap===2)h.adler=0,tt(C,31),tt(C,139),tt(C,8),C.gzhead?(tt(C,(C.gzhead.text?1:0)+(C.gzhead.hcrc?2:0)+(C.gzhead.extra?4:0)+(C.gzhead.name?8:0)+(C.gzhead.comment?16:0)),tt(C,255&C.gzhead.time),tt(C,C.gzhead.time>>8&255),tt(C,C.gzhead.time>>16&255),tt(C,C.gzhead.time>>24&255),tt(C,C.level===9?2:2<=C.strategy||C.level<2?4:0),tt(C,255&C.gzhead.os),C.gzhead.extra&&C.gzhead.extra.length&&(tt(C,255&C.gzhead.extra.length),tt(C,C.gzhead.extra.length>>8&255)),C.gzhead.hcrc&&(h.adler=c(h.adler,C.pending_buf,C.pending,0)),C.gzindex=0,C.status=69):(tt(C,0),tt(C,0),tt(C,0),tt(C,0),tt(C,0),tt(C,C.level===9?2:2<=C.strategy||C.level<2?4:0),tt(C,3),C.status=P);else{var Z=x+(C.w_bits-8<<4)<<8;Z|=(2<=C.strategy||C.level<2?0:C.level<6?1:C.level===6?2:3)<<6,C.strstart!==0&&(Z|=32),Z+=31-Z%31,C.status=P,Q(C,Z),C.strstart!==0&&(Q(C,h.adler>>>16),Q(C,65535&h.adler)),h.adler=1}if(C.status===69)if(C.gzhead.extra){for($=C.pending;C.gzindex<(65535&C.gzhead.extra.length)&&(C.pending!==C.pending_buf_size||(C.gzhead.hcrc&&C.pending>$&&(h.adler=c(h.adler,C.pending_buf,C.pending-$,$)),E(h),$=C.pending,C.pending!==C.pending_buf_size));)tt(C,255&C.gzhead.extra[C.gzindex]),C.gzindex++;C.gzhead.hcrc&&C.pending>$&&(h.adler=c(h.adler,C.pending_buf,C.pending-$,$)),C.gzindex===C.gzhead.extra.length&&(C.gzindex=0,C.status=73)}else C.status=73;if(C.status===73)if(C.gzhead.name){$=C.pending;do{if(C.pending===C.pending_buf_size&&(C.gzhead.hcrc&&C.pending>$&&(h.adler=c(h.adler,C.pending_buf,C.pending-$,$)),E(h),$=C.pending,C.pending===C.pending_buf_size)){D=1;break}D=C.gzindex<C.gzhead.name.length?255&C.gzhead.name.charCodeAt(C.gzindex++):0,tt(C,D)}while(D!==0);C.gzhead.hcrc&&C.pending>$&&(h.adler=c(h.adler,C.pending_buf,C.pending-$,$)),D===0&&(C.gzindex=0,C.status=91)}else C.status=91;if(C.status===91)if(C.gzhead.comment){$=C.pending;do{if(C.pending===C.pending_buf_size&&(C.gzhead.hcrc&&C.pending>$&&(h.adler=c(h.adler,C.pending_buf,C.pending-$,$)),E(h),$=C.pending,C.pending===C.pending_buf_size)){D=1;break}D=C.gzindex<C.gzhead.comment.length?255&C.gzhead.comment.charCodeAt(C.gzindex++):0,tt(C,D)}while(D!==0);C.gzhead.hcrc&&C.pending>$&&(h.adler=c(h.adler,C.pending_buf,C.pending-$,$)),D===0&&(C.status=103)}else C.status=103;if(C.status===103&&(C.gzhead.hcrc?(C.pending+2>C.pending_buf_size&&E(h),C.pending+2<=C.pending_buf_size&&(tt(C,255&h.adler),tt(C,h.adler>>8&255),h.adler=0,C.status=P)):C.status=P),C.pending!==0){if(E(h),h.avail_out===0)return C.last_flush=-1,d}else if(h.avail_in===0&&V(j)<=V(L)&&j!==g)return G(h,-5);if(C.status===666&&h.avail_in!==0)return G(h,-5);if(h.avail_in!==0||C.lookahead!==0||j!==m&&C.status!==666){var K=C.strategy===2?(function(q,it){for(var lt;;){if(q.lookahead===0&&(W(q),q.lookahead===0)){if(it===m)return b;break}if(q.match_length=0,lt=r._tr_tally(q,0,q.window[q.strstart]),q.lookahead--,q.strstart++,lt&&(R(q,!1),q.strm.avail_out===0))return b}return q.insert=0,it===g?(R(q,!0),q.strm.avail_out===0?J:U):q.last_lit&&(R(q,!1),q.strm.avail_out===0)?b:N})(C,j):C.strategy===3?(function(q,it){for(var lt,rt,pt,wt,kt=q.window;;){if(q.lookahead<=H){if(W(q),q.lookahead<=H&&it===m)return b;if(q.lookahead===0)break}if(q.match_length=0,q.lookahead>=O&&0<q.strstart&&(rt=kt[pt=q.strstart-1])===kt[++pt]&&rt===kt[++pt]&&rt===kt[++pt]){wt=q.strstart+H;do;while(rt===kt[++pt]&&rt===kt[++pt]&&rt===kt[++pt]&&rt===kt[++pt]&&rt===kt[++pt]&&rt===kt[++pt]&&rt===kt[++pt]&&rt===kt[++pt]&&pt<wt);q.match_length=H-(wt-pt),q.match_length>q.lookahead&&(q.match_length=q.lookahead)}if(q.match_length>=O?(lt=r._tr_tally(q,1,q.match_length-O),q.lookahead-=q.match_length,q.strstart+=q.match_length,q.match_length=0):(lt=r._tr_tally(q,0,q.window[q.strstart]),q.lookahead--,q.strstart++),lt&&(R(q,!1),q.strm.avail_out===0))return b}return q.insert=0,it===g?(R(q,!0),q.strm.avail_out===0?J:U):q.last_lit&&(R(q,!1),q.strm.avail_out===0)?b:N})(C,j):s[C.level].func(C,j);if(K!==J&&K!==U||(C.status=666),K===b||K===J)return h.avail_out===0&&(C.last_flush=-1),d;if(K===N&&(j===1?r._tr_align(C):j!==5&&(r._tr_stored_block(C,0,0,!1),j===3&&(M(C.head),C.lookahead===0&&(C.strstart=0,C.block_start=0,C.insert=0))),E(h),h.avail_out===0))return C.last_flush=-1,d}return j!==g?d:C.wrap<=0?1:(C.wrap===2?(tt(C,255&h.adler),tt(C,h.adler>>8&255),tt(C,h.adler>>16&255),tt(C,h.adler>>24&255),tt(C,255&h.total_in),tt(C,h.total_in>>8&255),tt(C,h.total_in>>16&255),tt(C,h.total_in>>24&255)):(Q(C,h.adler>>>16),Q(C,65535&h.adler)),E(h),0<C.wrap&&(C.wrap=-C.wrap),C.pending!==0?d:1)},o.deflateEnd=function(h){var j;return h&&h.state?(j=h.state.status)!==_&&j!==69&&j!==73&&j!==91&&j!==103&&j!==P&&j!==666?G(h,y):(h.state=null,j===P?G(h,-3):d):y},o.deflateSetDictionary=function(h,j){var L,C,$,D,Z,K,q,it,lt=j.length;if(!h||!h.state||(D=(L=h.state).wrap)===2||D===1&&L.status!==_||L.lookahead)return y;for(D===1&&(h.adler=a(h.adler,j,lt,0)),L.wrap=0,lt>=L.w_size&&(D===0&&(M(L.head),L.strstart=0,L.block_start=0,L.insert=0),it=new l.Buf8(L.w_size),l.arraySet(it,j,lt-L.w_size,L.w_size,0),j=it,lt=L.w_size),Z=h.avail_in,K=h.next_in,q=h.input,h.avail_in=lt,h.next_in=0,h.input=j,W(L);L.lookahead>=O;){for(C=L.strstart,$=L.lookahead-(O-1);L.ins_h=(L.ins_h<<L.hash_shift^L.window[C+O-1])&L.hash_mask,L.prev[C&L.w_mask]=L.head[L.ins_h],L.head[L.ins_h]=C,C++,--$;);L.strstart=C,L.lookahead=O-1,W(L)}return L.strstart+=L.lookahead,L.block_start=L.strstart,L.insert=L.lookahead,L.lookahead=0,L.match_length=L.prev_length=O-1,L.match_available=0,h.next_in=K,h.input=q,h.avail_in=Z,L.wrap=D,d},o.deflateInfo="pako deflate (from Nodeca project)"},{"../utils/common":41,"./adler32":43,"./crc32":45,"./messages":51,"./trees":52}],47:[function(e,n,o){n.exports=function(){this.text=0,this.time=0,this.xflags=0,this.os=0,this.extra=null,this.extra_len=0,this.name="",this.comment="",this.hcrc=0,this.done=!1}},{}],48:[function(e,n,o){n.exports=function(s,l){var r,a,c,u,m,g,d,y,f,v,k,x,S,B,A,I,w,z,O,H,et,_,P,b,N;r=s.state,a=s.next_in,b=s.input,c=a+(s.avail_in-5),u=s.next_out,N=s.output,m=u-(l-s.avail_out),g=u+(s.avail_out-257),d=r.dmax,y=r.wsize,f=r.whave,v=r.wnext,k=r.window,x=r.hold,S=r.bits,B=r.lencode,A=r.distcode,I=(1<<r.lenbits)-1,w=(1<<r.distbits)-1;t:do{S<15&&(x+=b[a++]<<S,S+=8,x+=b[a++]<<S,S+=8),z=B[x&I];e:for(;;){if(x>>>=O=z>>>24,S-=O,(O=z>>>16&255)===0)N[u++]=65535&z;else{if(!(16&O)){if((64&O)==0){z=B[(65535&z)+(x&(1<<O)-1)];continue e}if(32&O){r.mode=12;break t}s.msg="invalid literal/length code",r.mode=30;break t}H=65535&z,(O&=15)&&(S<O&&(x+=b[a++]<<S,S+=8),H+=x&(1<<O)-1,x>>>=O,S-=O),S<15&&(x+=b[a++]<<S,S+=8,x+=b[a++]<<S,S+=8),z=A[x&w];i:for(;;){if(x>>>=O=z>>>24,S-=O,!(16&(O=z>>>16&255))){if((64&O)==0){z=A[(65535&z)+(x&(1<<O)-1)];continue i}s.msg="invalid distance code",r.mode=30;break t}if(et=65535&z,S<(O&=15)&&(x+=b[a++]<<S,(S+=8)<O&&(x+=b[a++]<<S,S+=8)),d<(et+=x&(1<<O)-1)){s.msg="invalid distance too far back",r.mode=30;break t}if(x>>>=O,S-=O,(O=u-m)<et){if(f<(O=et-O)&&r.sane){s.msg="invalid distance too far back",r.mode=30;break t}if(P=k,(_=0)===v){if(_+=y-O,O<H){for(H-=O;N[u++]=k[_++],--O;);_=u-et,P=N}}else if(v<O){if(_+=y+v-O,(O-=v)<H){for(H-=O;N[u++]=k[_++],--O;);if(_=0,v<H){for(H-=O=v;N[u++]=k[_++],--O;);_=u-et,P=N}}}else if(_+=v-O,O<H){for(H-=O;N[u++]=k[_++],--O;);_=u-et,P=N}for(;2<H;)N[u++]=P[_++],N[u++]=P[_++],N[u++]=P[_++],H-=3;H&&(N[u++]=P[_++],1<H&&(N[u++]=P[_++]))}else{for(_=u-et;N[u++]=N[_++],N[u++]=N[_++],N[u++]=N[_++],2<(H-=3););H&&(N[u++]=N[_++],1<H&&(N[u++]=N[_++]))}break}}break}}while(a<c&&u<g);a-=H=S>>3,x&=(1<<(S-=H<<3))-1,s.next_in=a,s.next_out=u,s.avail_in=a<c?c-a+5:5-(a-c),s.avail_out=u<g?g-u+257:257-(u-g),r.hold=x,r.bits=S}},{}],49:[function(e,n,o){var s=e("../utils/common"),l=e("./adler32"),r=e("./crc32"),a=e("./inffast"),c=e("./inftrees"),u=1,m=2,g=0,d=-2,y=1,f=852,v=592;function k(_){return(_>>>24&255)+(_>>>8&65280)+((65280&_)<<8)+((255&_)<<24)}function x(){this.mode=0,this.last=!1,this.wrap=0,this.havedict=!1,this.flags=0,this.dmax=0,this.check=0,this.total=0,this.head=null,this.wbits=0,this.wsize=0,this.whave=0,this.wnext=0,this.window=null,this.hold=0,this.bits=0,this.length=0,this.offset=0,this.extra=0,this.lencode=null,this.distcode=null,this.lenbits=0,this.distbits=0,this.ncode=0,this.nlen=0,this.ndist=0,this.have=0,this.next=null,this.lens=new s.Buf16(320),this.work=new s.Buf16(288),this.lendyn=null,this.distdyn=null,this.sane=0,this.back=0,this.was=0}function S(_){var P;return _&&_.state?(P=_.state,_.total_in=_.total_out=P.total=0,_.msg="",P.wrap&&(_.adler=1&P.wrap),P.mode=y,P.last=0,P.havedict=0,P.dmax=32768,P.head=null,P.hold=0,P.bits=0,P.lencode=P.lendyn=new s.Buf32(f),P.distcode=P.distdyn=new s.Buf32(v),P.sane=1,P.back=-1,g):d}function B(_){var P;return _&&_.state?((P=_.state).wsize=0,P.whave=0,P.wnext=0,S(_)):d}function A(_,P){var b,N;return _&&_.state?(N=_.state,P<0?(b=0,P=-P):(b=1+(P>>4),P<48&&(P&=15)),P&&(P<8||15<P)?d:(N.window!==null&&N.wbits!==P&&(N.window=null),N.wrap=b,N.wbits=P,B(_))):d}function I(_,P){var b,N;return _?(N=new x,(_.state=N).window=null,(b=A(_,P))!==g&&(_.state=null),b):d}var w,z,O=!0;function H(_){if(O){var P;for(w=new s.Buf32(512),z=new s.Buf32(32),P=0;P<144;)_.lens[P++]=8;for(;P<256;)_.lens[P++]=9;for(;P<280;)_.lens[P++]=7;for(;P<288;)_.lens[P++]=8;for(c(u,_.lens,0,288,w,0,_.work,{bits:9}),P=0;P<32;)_.lens[P++]=5;c(m,_.lens,0,32,z,0,_.work,{bits:5}),O=!1}_.lencode=w,_.lenbits=9,_.distcode=z,_.distbits=5}function et(_,P,b,N){var J,U=_.state;return U.window===null&&(U.wsize=1<<U.wbits,U.wnext=0,U.whave=0,U.window=new s.Buf8(U.wsize)),N>=U.wsize?(s.arraySet(U.window,P,b-U.wsize,U.wsize,0),U.wnext=0,U.whave=U.wsize):(N<(J=U.wsize-U.wnext)&&(J=N),s.arraySet(U.window,P,b-N,J,U.wnext),(N-=J)?(s.arraySet(U.window,P,b-N,N,0),U.wnext=N,U.whave=U.wsize):(U.wnext+=J,U.wnext===U.wsize&&(U.wnext=0),U.whave<U.wsize&&(U.whave+=J))),0}o.inflateReset=B,o.inflateReset2=A,o.inflateResetKeep=S,o.inflateInit=function(_){return I(_,15)},o.inflateInit2=I,o.inflate=function(_,P){var b,N,J,U,G,V,M,E,R,tt,Q,Y,W,ut,ct,X,dt,bt,T,F,h,j,L,C,$=0,D=new s.Buf8(4),Z=[16,17,18,0,8,7,9,6,10,5,11,4,12,3,13,2,14,1,15];if(!_||!_.state||!_.output||!_.input&&_.avail_in!==0)return d;(b=_.state).mode===12&&(b.mode=13),G=_.next_out,J=_.output,M=_.avail_out,U=_.next_in,N=_.input,V=_.avail_in,E=b.hold,R=b.bits,tt=V,Q=M,j=g;t:for(;;)switch(b.mode){case y:if(b.wrap===0){b.mode=13;break}for(;R<16;){if(V===0)break t;V--,E+=N[U++]<<R,R+=8}if(2&b.wrap&&E===35615){D[b.check=0]=255&E,D[1]=E>>>8&255,b.check=r(b.check,D,2,0),R=E=0,b.mode=2;break}if(b.flags=0,b.head&&(b.head.done=!1),!(1&b.wrap)||(((255&E)<<8)+(E>>8))%31){_.msg="incorrect header check",b.mode=30;break}if((15&E)!=8){_.msg="unknown compression method",b.mode=30;break}if(R-=4,h=8+(15&(E>>>=4)),b.wbits===0)b.wbits=h;else if(h>b.wbits){_.msg="invalid window size",b.mode=30;break}b.dmax=1<<h,_.adler=b.check=1,b.mode=512&E?10:12,R=E=0;break;case 2:for(;R<16;){if(V===0)break t;V--,E+=N[U++]<<R,R+=8}if(b.flags=E,(255&b.flags)!=8){_.msg="unknown compression method",b.mode=30;break}if(57344&b.flags){_.msg="unknown header flags set",b.mode=30;break}b.head&&(b.head.text=E>>8&1),512&b.flags&&(D[0]=255&E,D[1]=E>>>8&255,b.check=r(b.check,D,2,0)),R=E=0,b.mode=3;case 3:for(;R<32;){if(V===0)break t;V--,E+=N[U++]<<R,R+=8}b.head&&(b.head.time=E),512&b.flags&&(D[0]=255&E,D[1]=E>>>8&255,D[2]=E>>>16&255,D[3]=E>>>24&255,b.check=r(b.check,D,4,0)),R=E=0,b.mode=4;case 4:for(;R<16;){if(V===0)break t;V--,E+=N[U++]<<R,R+=8}b.head&&(b.head.xflags=255&E,b.head.os=E>>8),512&b.flags&&(D[0]=255&E,D[1]=E>>>8&255,b.check=r(b.check,D,2,0)),R=E=0,b.mode=5;case 5:if(1024&b.flags){for(;R<16;){if(V===0)break t;V--,E+=N[U++]<<R,R+=8}b.length=E,b.head&&(b.head.extra_len=E),512&b.flags&&(D[0]=255&E,D[1]=E>>>8&255,b.check=r(b.check,D,2,0)),R=E=0}else b.head&&(b.head.extra=null);b.mode=6;case 6:if(1024&b.flags&&(V<(Y=b.length)&&(Y=V),Y&&(b.head&&(h=b.head.extra_len-b.length,b.head.extra||(b.head.extra=new Array(b.head.extra_len)),s.arraySet(b.head.extra,N,U,Y,h)),512&b.flags&&(b.check=r(b.check,N,Y,U)),V-=Y,U+=Y,b.length-=Y),b.length))break t;b.length=0,b.mode=7;case 7:if(2048&b.flags){if(V===0)break t;for(Y=0;h=N[U+Y++],b.head&&h&&b.length<65536&&(b.head.name+=String.fromCharCode(h)),h&&Y<V;);if(512&b.flags&&(b.check=r(b.check,N,Y,U)),V-=Y,U+=Y,h)break t}else b.head&&(b.head.name=null);b.length=0,b.mode=8;case 8:if(4096&b.flags){if(V===0)break t;for(Y=0;h=N[U+Y++],b.head&&h&&b.length<65536&&(b.head.comment+=String.fromCharCode(h)),h&&Y<V;);if(512&b.flags&&(b.check=r(b.check,N,Y,U)),V-=Y,U+=Y,h)break t}else b.head&&(b.head.comment=null);b.mode=9;case 9:if(512&b.flags){for(;R<16;){if(V===0)break t;V--,E+=N[U++]<<R,R+=8}if(E!==(65535&b.check)){_.msg="header crc mismatch",b.mode=30;break}R=E=0}b.head&&(b.head.hcrc=b.flags>>9&1,b.head.done=!0),_.adler=b.check=0,b.mode=12;break;case 10:for(;R<32;){if(V===0)break t;V--,E+=N[U++]<<R,R+=8}_.adler=b.check=k(E),R=E=0,b.mode=11;case 11:if(b.havedict===0)return _.next_out=G,_.avail_out=M,_.next_in=U,_.avail_in=V,b.hold=E,b.bits=R,2;_.adler=b.check=1,b.mode=12;case 12:if(P===5||P===6)break t;case 13:if(b.last){E>>>=7&R,R-=7&R,b.mode=27;break}for(;R<3;){if(V===0)break t;V--,E+=N[U++]<<R,R+=8}switch(b.last=1&E,R-=1,3&(E>>>=1)){case 0:b.mode=14;break;case 1:if(H(b),b.mode=20,P!==6)break;E>>>=2,R-=2;break t;case 2:b.mode=17;break;case 3:_.msg="invalid block type",b.mode=30}E>>>=2,R-=2;break;case 14:for(E>>>=7&R,R-=7&R;R<32;){if(V===0)break t;V--,E+=N[U++]<<R,R+=8}if((65535&E)!=(E>>>16^65535)){_.msg="invalid stored block lengths",b.mode=30;break}if(b.length=65535&E,R=E=0,b.mode=15,P===6)break t;case 15:b.mode=16;case 16:if(Y=b.length){if(V<Y&&(Y=V),M<Y&&(Y=M),Y===0)break t;s.arraySet(J,N,U,Y,G),V-=Y,U+=Y,M-=Y,G+=Y,b.length-=Y;break}b.mode=12;break;case 17:for(;R<14;){if(V===0)break t;V--,E+=N[U++]<<R,R+=8}if(b.nlen=257+(31&E),E>>>=5,R-=5,b.ndist=1+(31&E),E>>>=5,R-=5,b.ncode=4+(15&E),E>>>=4,R-=4,286<b.nlen||30<b.ndist){_.msg="too many length or distance symbols",b.mode=30;break}b.have=0,b.mode=18;case 18:for(;b.have<b.ncode;){for(;R<3;){if(V===0)break t;V--,E+=N[U++]<<R,R+=8}b.lens[Z[b.have++]]=7&E,E>>>=3,R-=3}for(;b.have<19;)b.lens[Z[b.have++]]=0;if(b.lencode=b.lendyn,b.lenbits=7,L={bits:b.lenbits},j=c(0,b.lens,0,19,b.lencode,0,b.work,L),b.lenbits=L.bits,j){_.msg="invalid code lengths set",b.mode=30;break}b.have=0,b.mode=19;case 19:for(;b.have<b.nlen+b.ndist;){for(;X=($=b.lencode[E&(1<<b.lenbits)-1])>>>16&255,dt=65535&$,!((ct=$>>>24)<=R);){if(V===0)break t;V--,E+=N[U++]<<R,R+=8}if(dt<16)E>>>=ct,R-=ct,b.lens[b.have++]=dt;else{if(dt===16){for(C=ct+2;R<C;){if(V===0)break t;V--,E+=N[U++]<<R,R+=8}if(E>>>=ct,R-=ct,b.have===0){_.msg="invalid bit length repeat",b.mode=30;break}h=b.lens[b.have-1],Y=3+(3&E),E>>>=2,R-=2}else if(dt===17){for(C=ct+3;R<C;){if(V===0)break t;V--,E+=N[U++]<<R,R+=8}R-=ct,h=0,Y=3+(7&(E>>>=ct)),E>>>=3,R-=3}else{for(C=ct+7;R<C;){if(V===0)break t;V--,E+=N[U++]<<R,R+=8}R-=ct,h=0,Y=11+(127&(E>>>=ct)),E>>>=7,R-=7}if(b.have+Y>b.nlen+b.ndist){_.msg="invalid bit length repeat",b.mode=30;break}for(;Y--;)b.lens[b.have++]=h}}if(b.mode===30)break;if(b.lens[256]===0){_.msg="invalid code -- missing end-of-block",b.mode=30;break}if(b.lenbits=9,L={bits:b.lenbits},j=c(u,b.lens,0,b.nlen,b.lencode,0,b.work,L),b.lenbits=L.bits,j){_.msg="invalid literal/lengths set",b.mode=30;break}if(b.distbits=6,b.distcode=b.distdyn,L={bits:b.distbits},j=c(m,b.lens,b.nlen,b.ndist,b.distcode,0,b.work,L),b.distbits=L.bits,j){_.msg="invalid distances set",b.mode=30;break}if(b.mode=20,P===6)break t;case 20:b.mode=21;case 21:if(6<=V&&258<=M){_.next_out=G,_.avail_out=M,_.next_in=U,_.avail_in=V,b.hold=E,b.bits=R,a(_,Q),G=_.next_out,J=_.output,M=_.avail_out,U=_.next_in,N=_.input,V=_.avail_in,E=b.hold,R=b.bits,b.mode===12&&(b.back=-1);break}for(b.back=0;X=($=b.lencode[E&(1<<b.lenbits)-1])>>>16&255,dt=65535&$,!((ct=$>>>24)<=R);){if(V===0)break t;V--,E+=N[U++]<<R,R+=8}if(X&&(240&X)==0){for(bt=ct,T=X,F=dt;X=($=b.lencode[F+((E&(1<<bt+T)-1)>>bt)])>>>16&255,dt=65535&$,!(bt+(ct=$>>>24)<=R);){if(V===0)break t;V--,E+=N[U++]<<R,R+=8}E>>>=bt,R-=bt,b.back+=bt}if(E>>>=ct,R-=ct,b.back+=ct,b.length=dt,X===0){b.mode=26;break}if(32&X){b.back=-1,b.mode=12;break}if(64&X){_.msg="invalid literal/length code",b.mode=30;break}b.extra=15&X,b.mode=22;case 22:if(b.extra){for(C=b.extra;R<C;){if(V===0)break t;V--,E+=N[U++]<<R,R+=8}b.length+=E&(1<<b.extra)-1,E>>>=b.extra,R-=b.extra,b.back+=b.extra}b.was=b.length,b.mode=23;case 23:for(;X=($=b.distcode[E&(1<<b.distbits)-1])>>>16&255,dt=65535&$,!((ct=$>>>24)<=R);){if(V===0)break t;V--,E+=N[U++]<<R,R+=8}if((240&X)==0){for(bt=ct,T=X,F=dt;X=($=b.distcode[F+((E&(1<<bt+T)-1)>>bt)])>>>16&255,dt=65535&$,!(bt+(ct=$>>>24)<=R);){if(V===0)break t;V--,E+=N[U++]<<R,R+=8}E>>>=bt,R-=bt,b.back+=bt}if(E>>>=ct,R-=ct,b.back+=ct,64&X){_.msg="invalid distance code",b.mode=30;break}b.offset=dt,b.extra=15&X,b.mode=24;case 24:if(b.extra){for(C=b.extra;R<C;){if(V===0)break t;V--,E+=N[U++]<<R,R+=8}b.offset+=E&(1<<b.extra)-1,E>>>=b.extra,R-=b.extra,b.back+=b.extra}if(b.offset>b.dmax){_.msg="invalid distance too far back",b.mode=30;break}b.mode=25;case 25:if(M===0)break t;if(Y=Q-M,b.offset>Y){if((Y=b.offset-Y)>b.whave&&b.sane){_.msg="invalid distance too far back",b.mode=30;break}W=Y>b.wnext?(Y-=b.wnext,b.wsize-Y):b.wnext-Y,Y>b.length&&(Y=b.length),ut=b.window}else ut=J,W=G-b.offset,Y=b.length;for(M<Y&&(Y=M),M-=Y,b.length-=Y;J[G++]=ut[W++],--Y;);b.length===0&&(b.mode=21);break;case 26:if(M===0)break t;J[G++]=b.length,M--,b.mode=21;break;case 27:if(b.wrap){for(;R<32;){if(V===0)break t;V--,E|=N[U++]<<R,R+=8}if(Q-=M,_.total_out+=Q,b.total+=Q,Q&&(_.adler=b.check=b.flags?r(b.check,J,Q,G-Q):l(b.check,J,Q,G-Q)),Q=M,(b.flags?E:k(E))!==b.check){_.msg="incorrect data check",b.mode=30;break}R=E=0}b.mode=28;case 28:if(b.wrap&&b.flags){for(;R<32;){if(V===0)break t;V--,E+=N[U++]<<R,R+=8}if(E!==(4294967295&b.total)){_.msg="incorrect length check",b.mode=30;break}R=E=0}b.mode=29;case 29:j=1;break t;case 30:j=-3;break t;case 31:return-4;case 32:default:return d}return _.next_out=G,_.avail_out=M,_.next_in=U,_.avail_in=V,b.hold=E,b.bits=R,(b.wsize||Q!==_.avail_out&&b.mode<30&&(b.mode<27||P!==4))&&et(_,_.output,_.next_out,Q-_.avail_out)?(b.mode=31,-4):(tt-=_.avail_in,Q-=_.avail_out,_.total_in+=tt,_.total_out+=Q,b.total+=Q,b.wrap&&Q&&(_.adler=b.check=b.flags?r(b.check,J,Q,_.next_out-Q):l(b.check,J,Q,_.next_out-Q)),_.data_type=b.bits+(b.last?64:0)+(b.mode===12?128:0)+(b.mode===20||b.mode===15?256:0),(tt==0&&Q===0||P===4)&&j===g&&(j=-5),j)},o.inflateEnd=function(_){if(!_||!_.state)return d;var P=_.state;return P.window&&(P.window=null),_.state=null,g},o.inflateGetHeader=function(_,P){var b;return _&&_.state?(2&(b=_.state).wrap)==0?d:((b.head=P).done=!1,g):d},o.inflateSetDictionary=function(_,P){var b,N=P.length;return _&&_.state?(b=_.state).wrap!==0&&b.mode!==11?d:b.mode===11&&l(1,P,N,0)!==b.check?-3:et(_,P,N,N)?(b.mode=31,-4):(b.havedict=1,g):d},o.inflateInfo="pako inflate (from Nodeca project)"},{"../utils/common":41,"./adler32":43,"./crc32":45,"./inffast":48,"./inftrees":50}],50:[function(e,n,o){var s=e("../utils/common"),l=[3,4,5,6,7,8,9,10,11,13,15,17,19,23,27,31,35,43,51,59,67,83,99,115,131,163,195,227,258,0,0],r=[16,16,16,16,16,16,16,16,17,17,17,17,18,18,18,18,19,19,19,19,20,20,20,20,21,21,21,21,16,72,78],a=[1,2,3,4,5,7,9,13,17,25,33,49,65,97,129,193,257,385,513,769,1025,1537,2049,3073,4097,6145,8193,12289,16385,24577,0,0],c=[16,16,16,16,17,17,18,18,19,19,20,20,21,21,22,22,23,23,24,24,25,25,26,26,27,27,28,28,29,29,64,64];n.exports=function(u,m,g,d,y,f,v,k){var x,S,B,A,I,w,z,O,H,et=k.bits,_=0,P=0,b=0,N=0,J=0,U=0,G=0,V=0,M=0,E=0,R=null,tt=0,Q=new s.Buf16(16),Y=new s.Buf16(16),W=null,ut=0;for(_=0;_<=15;_++)Q[_]=0;for(P=0;P<d;P++)Q[m[g+P]]++;for(J=et,N=15;1<=N&&Q[N]===0;N--);if(N<J&&(J=N),N===0)return y[f++]=20971520,y[f++]=20971520,k.bits=1,0;for(b=1;b<N&&Q[b]===0;b++);for(J<b&&(J=b),_=V=1;_<=15;_++)if(V<<=1,(V-=Q[_])<0)return-1;if(0<V&&(u===0||N!==1))return-1;for(Y[1]=0,_=1;_<15;_++)Y[_+1]=Y[_]+Q[_];for(P=0;P<d;P++)m[g+P]!==0&&(v[Y[m[g+P]]++]=P);if(w=u===0?(R=W=v,19):u===1?(R=l,tt-=257,W=r,ut-=257,256):(R=a,W=c,-1),_=b,I=f,G=P=E=0,B=-1,A=(M=1<<(U=J))-1,u===1&&852<M||u===2&&592<M)return 1;for(;;){for(z=_-G,H=v[P]<w?(O=0,v[P]):v[P]>w?(O=W[ut+v[P]],R[tt+v[P]]):(O=96,0),x=1<<_-G,b=S=1<<U;y[I+(E>>G)+(S-=x)]=z<<24|O<<16|H|0,S!==0;);for(x=1<<_-1;E&x;)x>>=1;if(x!==0?(E&=x-1,E+=x):E=0,P++,--Q[_]==0){if(_===N)break;_=m[g+v[P]]}if(J<_&&(E&A)!==B){for(G===0&&(G=J),I+=b,V=1<<(U=_-G);U+G<N&&!((V-=Q[U+G])<=0);)U++,V<<=1;if(M+=1<<U,u===1&&852<M||u===2&&592<M)return 1;y[B=E&A]=J<<24|U<<16|I-f|0}}return E!==0&&(y[I+E]=_-G<<24|64<<16|0),k.bits=J,0}},{"../utils/common":41}],51:[function(e,n,o){n.exports={2:"need dictionary",1:"stream end",0:"","-1":"file error","-2":"stream error","-3":"data error","-4":"insufficient memory","-5":"buffer error","-6":"incompatible version"}},{}],52:[function(e,n,o){var s=e("../utils/common"),l=0,r=1;function a($){for(var D=$.length;0<=--D;)$[D]=0}var c=0,u=29,m=256,g=m+1+u,d=30,y=19,f=2*g+1,v=15,k=16,x=7,S=256,B=16,A=17,I=18,w=[0,0,0,0,0,0,0,0,1,1,1,1,2,2,2,2,3,3,3,3,4,4,4,4,5,5,5,5,0],z=[0,0,0,0,1,1,2,2,3,3,4,4,5,5,6,6,7,7,8,8,9,9,10,10,11,11,12,12,13,13],O=[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,2,3,7],H=[16,17,18,0,8,7,9,6,10,5,11,4,12,3,13,2,14,1,15],et=new Array(2*(g+2));a(et);var _=new Array(2*d);a(_);var P=new Array(512);a(P);var b=new Array(256);a(b);var N=new Array(u);a(N);var J,U,G,V=new Array(d);function M($,D,Z,K,q){this.static_tree=$,this.extra_bits=D,this.extra_base=Z,this.elems=K,this.max_length=q,this.has_stree=$&&$.length}function E($,D){this.dyn_tree=$,this.max_code=0,this.stat_desc=D}function R($){return $<256?P[$]:P[256+($>>>7)]}function tt($,D){$.pending_buf[$.pending++]=255&D,$.pending_buf[$.pending++]=D>>>8&255}function Q($,D,Z){$.bi_valid>k-Z?($.bi_buf|=D<<$.bi_valid&65535,tt($,$.bi_buf),$.bi_buf=D>>k-$.bi_valid,$.bi_valid+=Z-k):($.bi_buf|=D<<$.bi_valid&65535,$.bi_valid+=Z)}function Y($,D,Z){Q($,Z[2*D],Z[2*D+1])}function W($,D){for(var Z=0;Z|=1&$,$>>>=1,Z<<=1,0<--D;);return Z>>>1}function ut($,D,Z){var K,q,it=new Array(v+1),lt=0;for(K=1;K<=v;K++)it[K]=lt=lt+Z[K-1]<<1;for(q=0;q<=D;q++){var rt=$[2*q+1];rt!==0&&($[2*q]=W(it[rt]++,rt))}}function ct($){var D;for(D=0;D<g;D++)$.dyn_ltree[2*D]=0;for(D=0;D<d;D++)$.dyn_dtree[2*D]=0;for(D=0;D<y;D++)$.bl_tree[2*D]=0;$.dyn_ltree[2*S]=1,$.opt_len=$.static_len=0,$.last_lit=$.matches=0}function X($){8<$.bi_valid?tt($,$.bi_buf):0<$.bi_valid&&($.pending_buf[$.pending++]=$.bi_buf),$.bi_buf=0,$.bi_valid=0}function dt($,D,Z,K){var q=2*D,it=2*Z;return $[q]<$[it]||$[q]===$[it]&&K[D]<=K[Z]}function bt($,D,Z){for(var K=$.heap[Z],q=Z<<1;q<=$.heap_len&&(q<$.heap_len&&dt(D,$.heap[q+1],$.heap[q],$.depth)&&q++,!dt(D,K,$.heap[q],$.depth));)$.heap[Z]=$.heap[q],Z=q,q<<=1;$.heap[Z]=K}function T($,D,Z){var K,q,it,lt,rt=0;if($.last_lit!==0)for(;K=$.pending_buf[$.d_buf+2*rt]<<8|$.pending_buf[$.d_buf+2*rt+1],q=$.pending_buf[$.l_buf+rt],rt++,K===0?Y($,q,D):(Y($,(it=b[q])+m+1,D),(lt=w[it])!==0&&Q($,q-=N[it],lt),Y($,it=R(--K),Z),(lt=z[it])!==0&&Q($,K-=V[it],lt)),rt<$.last_lit;);Y($,S,D)}function F($,D){var Z,K,q,it=D.dyn_tree,lt=D.stat_desc.static_tree,rt=D.stat_desc.has_stree,pt=D.stat_desc.elems,wt=-1;for($.heap_len=0,$.heap_max=f,Z=0;Z<pt;Z++)it[2*Z]!==0?($.heap[++$.heap_len]=wt=Z,$.depth[Z]=0):it[2*Z+1]=0;for(;$.heap_len<2;)it[2*(q=$.heap[++$.heap_len]=wt<2?++wt:0)]=1,$.depth[q]=0,$.opt_len--,rt&&($.static_len-=lt[2*q+1]);for(D.max_code=wt,Z=$.heap_len>>1;1<=Z;Z--)bt($,it,Z);for(q=pt;Z=$.heap[1],$.heap[1]=$.heap[$.heap_len--],bt($,it,1),K=$.heap[1],$.heap[--$.heap_max]=Z,$.heap[--$.heap_max]=K,it[2*q]=it[2*Z]+it[2*K],$.depth[q]=($.depth[Z]>=$.depth[K]?$.depth[Z]:$.depth[K])+1,it[2*Z+1]=it[2*K+1]=q,$.heap[1]=q++,bt($,it,1),2<=$.heap_len;);$.heap[--$.heap_max]=$.heap[1],(function(kt,Mt){var Zt,Vt,se,Nt,Ke,ne,Jt=Mt.dyn_tree,ki=Mt.max_code,zi=Mt.stat_desc.static_tree,Lo=Mt.stat_desc.has_stree,Po=Mt.stat_desc.extra_bits,Fn=Mt.stat_desc.extra_base,wi=Mt.stat_desc.max_length,Ni=0;for(Nt=0;Nt<=v;Nt++)kt.bl_count[Nt]=0;for(Jt[2*kt.heap[kt.heap_max]+1]=0,Zt=kt.heap_max+1;Zt<f;Zt++)wi<(Nt=Jt[2*Jt[2*(Vt=kt.heap[Zt])+1]+1]+1)&&(Nt=wi,Ni++),Jt[2*Vt+1]=Nt,ki<Vt||(kt.bl_count[Nt]++,Ke=0,Fn<=Vt&&(Ke=Po[Vt-Fn]),ne=Jt[2*Vt],kt.opt_len+=ne*(Nt+Ke),Lo&&(kt.static_len+=ne*(zi[2*Vt+1]+Ke)));if(Ni!==0){do{for(Nt=wi-1;kt.bl_count[Nt]===0;)Nt--;kt.bl_count[Nt]--,kt.bl_count[Nt+1]+=2,kt.bl_count[wi]--,Ni-=2}while(0<Ni);for(Nt=wi;Nt!==0;Nt--)for(Vt=kt.bl_count[Nt];Vt!==0;)ki<(se=kt.heap[--Zt])||(Jt[2*se+1]!==Nt&&(kt.opt_len+=(Nt-Jt[2*se+1])*Jt[2*se],Jt[2*se+1]=Nt),Vt--)}})($,D),ut(it,wt,$.bl_count)}function h($,D,Z){var K,q,it=-1,lt=D[1],rt=0,pt=7,wt=4;for(lt===0&&(pt=138,wt=3),D[2*(Z+1)+1]=65535,K=0;K<=Z;K++)q=lt,lt=D[2*(K+1)+1],++rt<pt&&q===lt||(rt<wt?$.bl_tree[2*q]+=rt:q!==0?(q!==it&&$.bl_tree[2*q]++,$.bl_tree[2*B]++):rt<=10?$.bl_tree[2*A]++:$.bl_tree[2*I]++,it=q,wt=(rt=0)===lt?(pt=138,3):q===lt?(pt=6,3):(pt=7,4))}function j($,D,Z){var K,q,it=-1,lt=D[1],rt=0,pt=7,wt=4;for(lt===0&&(pt=138,wt=3),K=0;K<=Z;K++)if(q=lt,lt=D[2*(K+1)+1],!(++rt<pt&&q===lt)){if(rt<wt)for(;Y($,q,$.bl_tree),--rt!=0;);else q!==0?(q!==it&&(Y($,q,$.bl_tree),rt--),Y($,B,$.bl_tree),Q($,rt-3,2)):rt<=10?(Y($,A,$.bl_tree),Q($,rt-3,3)):(Y($,I,$.bl_tree),Q($,rt-11,7));it=q,wt=(rt=0)===lt?(pt=138,3):q===lt?(pt=6,3):(pt=7,4)}}a(V);var L=!1;function C($,D,Z,K){Q($,(c<<1)+(K?1:0),3),(function(q,it,lt,rt){X(q),tt(q,lt),tt(q,~lt),s.arraySet(q.pending_buf,q.window,it,lt,q.pending),q.pending+=lt})($,D,Z)}o._tr_init=function($){L||((function(){var D,Z,K,q,it,lt=new Array(v+1);for(q=K=0;q<u-1;q++)for(N[q]=K,D=0;D<1<<w[q];D++)b[K++]=q;for(b[K-1]=q,q=it=0;q<16;q++)for(V[q]=it,D=0;D<1<<z[q];D++)P[it++]=q;for(it>>=7;q<d;q++)for(V[q]=it<<7,D=0;D<1<<z[q]-7;D++)P[256+it++]=q;for(Z=0;Z<=v;Z++)lt[Z]=0;for(D=0;D<=143;)et[2*D+1]=8,D++,lt[8]++;for(;D<=255;)et[2*D+1]=9,D++,lt[9]++;for(;D<=279;)et[2*D+1]=7,D++,lt[7]++;for(;D<=287;)et[2*D+1]=8,D++,lt[8]++;for(ut(et,g+1,lt),D=0;D<d;D++)_[2*D+1]=5,_[2*D]=W(D,5);J=new M(et,w,m+1,g,v),U=new M(_,z,0,d,v),G=new M(new Array(0),O,0,y,x)})(),L=!0),$.l_desc=new E($.dyn_ltree,J),$.d_desc=new E($.dyn_dtree,U),$.bl_desc=new E($.bl_tree,G),$.bi_buf=0,$.bi_valid=0,ct($)},o._tr_stored_block=C,o._tr_flush_block=function($,D,Z,K){var q,it,lt=0;0<$.level?($.strm.data_type===2&&($.strm.data_type=(function(rt){var pt,wt=4093624447;for(pt=0;pt<=31;pt++,wt>>>=1)if(1&wt&&rt.dyn_ltree[2*pt]!==0)return l;if(rt.dyn_ltree[18]!==0||rt.dyn_ltree[20]!==0||rt.dyn_ltree[26]!==0)return r;for(pt=32;pt<m;pt++)if(rt.dyn_ltree[2*pt]!==0)return r;return l})($)),F($,$.l_desc),F($,$.d_desc),lt=(function(rt){var pt;for(h(rt,rt.dyn_ltree,rt.l_desc.max_code),h(rt,rt.dyn_dtree,rt.d_desc.max_code),F(rt,rt.bl_desc),pt=y-1;3<=pt&&rt.bl_tree[2*H[pt]+1]===0;pt--);return rt.opt_len+=3*(pt+1)+5+5+4,pt})($),q=$.opt_len+3+7>>>3,(it=$.static_len+3+7>>>3)<=q&&(q=it)):q=it=Z+5,Z+4<=q&&D!==-1?C($,D,Z,K):$.strategy===4||it===q?(Q($,2+(K?1:0),3),T($,et,_)):(Q($,4+(K?1:0),3),(function(rt,pt,wt,kt){var Mt;for(Q(rt,pt-257,5),Q(rt,wt-1,5),Q(rt,kt-4,4),Mt=0;Mt<kt;Mt++)Q(rt,rt.bl_tree[2*H[Mt]+1],3);j(rt,rt.dyn_ltree,pt-1),j(rt,rt.dyn_dtree,wt-1)})($,$.l_desc.max_code+1,$.d_desc.max_code+1,lt+1),T($,$.dyn_ltree,$.dyn_dtree)),ct($),K&&X($)},o._tr_tally=function($,D,Z){return $.pending_buf[$.d_buf+2*$.last_lit]=D>>>8&255,$.pending_buf[$.d_buf+2*$.last_lit+1]=255&D,$.pending_buf[$.l_buf+$.last_lit]=255&Z,$.last_lit++,D===0?$.dyn_ltree[2*Z]++:($.matches++,D--,$.dyn_ltree[2*(b[Z]+m+1)]++,$.dyn_dtree[2*R(D)]++),$.last_lit===$.lit_bufsize-1},o._tr_align=function($){Q($,2,3),Y($,S,et),(function(D){D.bi_valid===16?(tt(D,D.bi_buf),D.bi_buf=0,D.bi_valid=0):8<=D.bi_valid&&(D.pending_buf[D.pending++]=255&D.bi_buf,D.bi_buf>>=8,D.bi_valid-=8)})($)}},{"../utils/common":41}],53:[function(e,n,o){n.exports=function(){this.input=null,this.next_in=0,this.avail_in=0,this.total_in=0,this.output=null,this.next_out=0,this.avail_out=0,this.total_out=0,this.msg="",this.state=null,this.data_type=2,this.adler=0}},{}],54:[function(e,n,o){(function(s){(function(l,r){if(!l.setImmediate){var a,c,u,m,g=1,d={},y=!1,f=l.document,v=Object.getPrototypeOf&&Object.getPrototypeOf(l);v=v&&v.setTimeout?v:l,a={}.toString.call(l.process)==="[object process]"?function(B){process.nextTick(function(){x(B)})}:(function(){if(l.postMessage&&!l.importScripts){var B=!0,A=l.onmessage;return l.onmessage=function(){B=!1},l.postMessage("","*"),l.onmessage=A,B}})()?(m="setImmediate$"+Math.random()+"$",l.addEventListener?l.addEventListener("message",S,!1):l.attachEvent("onmessage",S),function(B){l.postMessage(m+B,"*")}):l.MessageChannel?((u=new MessageChannel).port1.onmessage=function(B){x(B.data)},function(B){u.port2.postMessage(B)}):f&&"onreadystatechange"in f.createElement("script")?(c=f.documentElement,function(B){var A=f.createElement("script");A.onreadystatechange=function(){x(B),A.onreadystatechange=null,c.removeChild(A),A=null},c.appendChild(A)}):function(B){setTimeout(x,0,B)},v.setImmediate=function(B){typeof B!="function"&&(B=new Function(""+B));for(var A=new Array(arguments.length-1),I=0;I<A.length;I++)A[I]=arguments[I+1];var w={callback:B,args:A};return d[g]=w,a(g),g++},v.clearImmediate=k}function k(B){delete d[B]}function x(B){if(y)setTimeout(x,0,B);else{var A=d[B];if(A){y=!0;try{(function(I){var w=I.callback,z=I.args;switch(z.length){case 0:w();break;case 1:w(z[0]);break;case 2:w(z[0],z[1]);break;case 3:w(z[0],z[1],z[2]);break;default:w.apply(r,z)}})(A)}finally{k(B),y=!1}}}}function S(B){B.source===l&&typeof B.data=="string"&&B.data.indexOf(m)===0&&x(+B.data.slice(m.length))}})(typeof self>"u"?s===void 0?this:s:self)}).call(this,typeof Zn<"u"?Zn:typeof self<"u"?self:typeof window<"u"?window:{})},{}]},{},[10])(10)})})(Yo)),Yo.exports}var N1=z1();const F1=O1(N1),H1=/\.(?:png|jpe?g|gif|svg|webp|avif|ico|bmp|tiff?|mp4|webm|mp3|wav|ogg)$/i,j1=/\.(?:ts|js|mjs|cjs|jsx|tsx|vue|json|css|scss|less|html|py|rs|go|java|c|cpp|h|sh|bash|yaml|yml|toml)$/i;async function U1(t){const i=await F1.loadAsync(t),e={},n=[];let o="",s="";const l=[];i.forEach((a,c)=>{!c.dir&&!a.startsWith("__MACOSX")&&!a.includes("node_modules/")&&l.push({path:a,file:c})});let r=l.find(a=>a.path.toLowerCase()==="slides.md");r||(r=l.find(a=>a.path.toLowerCase().endsWith("/slides.md"))),r||(r=l.find(a=>a.path.toLowerCase().endsWith(".md"))),r&&(o=await r.file.async("string"),s=r.path);for(const a of l){const c=a.path;if(c.toLowerCase().endsWith(".md")||j1.test(c)||c.includes("snippets/")){const u=await a.file.async("string");e[c]=u;const m=c.split("/");m.length>1&&(e[m.slice(1).join("/")]=u)}else if(H1.test(c)){const u=await a.file.async("uint8array"),m=c.split("/").pop()||c,g=typeof Blob<"u"?new Blob([u]):void 0;n.push({zipPath:c,fileName:m,data:u,blob:g})}}return{entryMarkdown:o,entryMarkdownPath:s,virtualFiles:e,assets:n}}function W1(t,i){if(Object.keys(i).length===0)return t;function e(o){const s=o.trim().replace(/^['"]|['"]$/g,""),l=s.split("/").pop()||s;if(i[s])return i[s];const r=s.replace(/^\.?\//,"");return i[r]?i[r]:i[l]?i[l]:null}function n(o){let s=o;return s=s.replace(/!\[(.*?)\]\((.*?)\)/g,(l,r,a)=>{const c=e(a);return c?`![${r}](${c})`:l}),s=s.replace(/\bsrc=["'](.*?)["']/gi,(l,r)=>{const a=e(r);return a?`src="${a}"`:l}),s}for(const o of t.slides)if(o.rawMarkdown=n(o.rawMarkdown),o.pageAttrs["custom-slidev-background"]){const s=o.pageAttrs["custom-slidev-background"],l=e(s);l&&(o.pageAttrs["custom-slidev-background"]=l)}if(t.flattenedMarkdown=n(t.flattenedMarkdown),t.docRootAttrs["custom-slidev-background"]){const o=t.docRootAttrs["custom-slidev-background"],s=e(o);s&&(t.docRootAttrs["custom-slidev-background"]=s)}return t}function pa(t){try{if(typeof process<"u"&&typeof require<"u"){const i=require("fs");if(i.existsSync(t))return i.readFileSync(t,"utf-8")}}catch{}return null}function V1(t,i){const e=t.match(/^[ \t]*<<<[ \t]+([^\s]+)/);if(!e)return null;const n=e[1].trim(),o=n.indexOf("#"),s=o!==-1?n.slice(0,o):n,l=o!==-1?n.slice(o+1):"",r=s.replace(/^@\//,"").replace(/^\.\//,""),a=(i==null?void 0:i.virtualFiles)||{};let c=a[s]||a[r]||a[`./${r}`]||a[`@/${r}`];if(!c&&Object.keys(a).length>0){const d=r.split("/").pop();for(const[y,f]of Object.entries(a))if(y.endsWith(`/${r}`)||d&&y.endsWith(`/${d}`)){c=f;break}}if(!c){const d=[];if(i!=null&&i.baseDir)try{const y=require("path");d.push(y.resolve(i.baseDir,r)),d.push(y.resolve(i.baseDir,s))}catch{}try{const y=require("path");d.push(y.resolve(process.cwd(),r))}catch{}for(const y of d){const f=pa(y);if(f!==null){c=f;break}}}if(!c){const d=sa||{};if(c=d[s]||d[r]||d[`snippets/${r}`],!c){const y=r.split("/").pop();for(const[f,v]of Object.entries(d))if(f.endsWith(`/${r}`)||y&&f.endsWith(`/${y}`)){c=v;break}}}if(!c)return null;let u=c;if(l){const d=new RegExp(`(?:\\/\\/|\\/\\*|#)?\\s*#(?:region|REGION)\\s+${l}[^\\r\\n]*\\r?\\n([\\s\\S]*?)(?:\\/\\/|\\/\\*|#)?\\s*#(?:endregion|ENDREGION)\\s+${l}`,"i"),y=c.match(d);if(y){const f=c.match(/^(\/\/\s*Inside[^\r\n]+\r?\n)/i);u=(f?f[1]:"")+y[1].trimEnd()}}const m=r.match(/\.([a-zA-Z0-9]+)$/);return`\`\`\`${m?m[1]:""}
${u}
\`\`\``}function q1(t){let i=!1,e=!1;for(let n=0;n<t.length;n++){const o=t[n];if(o==="'"&&!e)i=!i;else if(o==='"'&&!i)e=!e;else if(o==="#"&&!i&&!e)return t.slice(0,n).trim()}return t.trim()}function to(t){const i={},e=t.split(/\r?\n/);let n=0;for(;n<e.length;){const o=e[n],s=o.trim();if(!s||s.startsWith("#")){n++;continue}const l=o.indexOf(":");if(l>0){const r=o.slice(0,l).trim();let a=o.slice(l+1).trim();if(a==="|"||a===">"){n++;const c=[];let u=-1;for(;n<e.length;){const m=e[n];if(!m.trim()){c.push(""),n++;continue}const d=m.match(/^(\s+)/),y=d?d[1].length:0;if(u===-1&&(u=y),y<u)break;c.push(m.slice(u)),n++}for(;c.length>0&&c[c.length-1]==="";)c.pop();i[r]=a===">"?c.join(" "):c.join(`
`);continue}if(a=q1(a),!a){let c=n+1;const u=[];let m=-1;for(;c<e.length;){const g=e[c],d=g.trim();if(!d||d.startsWith("#")){m!==-1&&u.push(""),c++;continue}const y=g.match(/^(\s+)/),f=y?y[1].length:0;if(m===-1)if(f>0)m=f;else break;if(f<m)break;u.push(g.slice(m)),c++}if(u.length>0){i[r]=to(u.join(`
`)),n=c;continue}}a.startsWith('"')&&a.endsWith('"')||a.startsWith("'")&&a.endsWith("'")?a=a.slice(1,-1):a==="true"?a=!0:a==="false"?a=!1:a==="null"?a=null:/^-?\d+(?:\.\d+)?$/.test(a)&&(a=Number(a)),i[r]=a}n++}return i}const K1=/^\s*```ya?ml([\s\S]*?)```/;function Mr(t){let i={},e=t.trim();const n=e.match(/^---[^\n\r]*\r?\n([\s\S]*?)\r?\n---(?=[ \t]*(?:\r?\n|$))/);if(n&&!n[1].includes("```")){const s=to(n[1]);if(Object.keys(s).length>0||!n[1].trim())return i=s,e=e.slice(n[0].length).trim(),{frontmatter:i,content:e}}if(e.startsWith("---")){const s=e.match(/^---[^\n\r]*(?:\r?\n|$)/);s&&(e=e.slice(s[0].length).trim())}const o=e.match(K1);if(o)i=to(o[1]),e=e.slice(o[0].length).trim();else{const s=e.split(/\r?\n/),l=[];let r=0;for(let a=0;a<s.length;a++){const c=s[a].trim();if(!c){if(l.length>0){r=a+1;break}continue}if(/^[a-zA-Z0-9_-]+\s*:\s*.*/.test(c)&&!c.startsWith("<")&&!c.startsWith("#"))l.push(c);else{r=a;break}}l.length>0&&(i=to(l.join(`
`)),e=s.slice(r).join(`
`).trim())}return{frontmatter:i,content:e}}function G1(t){const i=t.split(/\r?\n/),e=[];let n=0,o=!1;function s(l){if(n>=l)return;const r=i.slice(n,l).join(`
`).trim();r&&e.push(r),n=l+1}for(let l=0;l<i.length;l++){const a=i[l].trimEnd();if(o){a.includes("-->")&&(o=!1);continue}if(a.startsWith("<!--")){a.includes("-->")||(o=!0);continue}if(a.startsWith("---")){s(l);const c=i[l+1];if(c&&c.trim()&&a.replace(/^-+/,"").trim()==="")for(n=l,l+=1;l<i.length&&i[l].trimEnd()!=="---";l++);}else if(a.trimStart().startsWith("```")){const c=a.match(/^\s*`+/),u=c?c[0].trim():"```";let m=l+1;for(;m<i.length&&!i[m].trimStart().startsWith(u);m++);m<i.length&&(l=m)}}return n<i.length&&s(i.length),e}function eo(t,i={}){const{stripNotesFromMarkdown:e=!0,cleanVClicks:n=!0,cleanShikiLines:o=!0,cleanSlots:s=!0,isolateStyleTags:l=!0,cleanHtmlToMarkdown:r=!0,wrapSuperBlocks:a=!0,virtualFiles:c={}}=i;let u=t;u&&!u.trimStart().startsWith("---")&&(u=`---

${u.trimStart()}`);const m=G1(u),g={};let d="",y="",f=0;if(m.length>0){const H=m[0],et=Mr(H),_=Object.keys(et.frontmatter).length>0,P=et.content.length>0;_&&!P&&m.length>1?(f=1,v(et.frontmatter)):_&&v(et.frontmatter)}function v(H){d=H.title||"",H.theme&&(g[xn]=String(H.theme)),H.aspectRatio&&(g[_n]=String(H.aspectRatio)),H.highlighter&&(g[Fr]=String(H.highlighter)),H.transition&&(g[Sn]=String(H.transition)),H.colorSchema&&(g[Hr]=String(H.colorSchema)),H.layout&&(g[mt]=String(H.layout)),H.background&&(g[Ut]=String(H.background)),H.image&&(g[Ee]=String(H.image)),H.class&&(g[Vi]=String(H.class));for(const[et,_]of Object.entries(H))["theme","aspectRatio","highlighter","transition","colorSchema","title","layout","background","image","class"].includes(et)||(g[`custom-slidev-${et}`]=typeof _=="object"?JSON.stringify(_):String(_))}const k=[];let x=0,S=0,B=0,A=0;const I=new Set,w={};let z=1;for(let H=f;H<m.length;H++){const et=m[H],{frontmatter:_,content:P}=Mr(et),b=et.match(/^\s*(?:---\s*)?src:\s*([^\n\r]+)/m),N=_.src||(b?b[1]:void 0);if(N){const X=String(N).trim().replace(/^['"]|['"]$/g,"");let dt=c[X]||c[X.replace(/^\.\//,"")]||c[`pages/${X.replace(/^.*pages\//,"")}`];if(!dt){const T=X.replace(/^\.\//,""),F=[];if(i.baseDir)try{const h=require("path");F.push(h.resolve(i.baseDir,T)),F.push(h.resolve(i.baseDir,X))}catch{}try{const h=require("path");F.push(h.resolve(process.cwd(),T)),F.push(h.resolve(process.cwd(),X))}catch{}for(const h of F){const j=pa(h);if(j!==null){dt=j;break}}}const bt={};_.layout&&(bt[mt]=String(_.layout)),_.transition&&(bt[Qt]=String(_.transition)),_.background&&(bt[Ut]=String(_.background)),_.image&&(bt[Ee]=String(_.image)),_.class&&(bt[Vi]=String(_.class));for(const[T,F]of Object.entries(_))["src","layout","transition","background","image","class"].includes(T)||(bt[`custom-slidev-${T}`]=typeof F=="object"?JSON.stringify(F):String(F));if(dt){const T=eo(dt,{...i,virtualFiles:c});for(const F of T.slides){F.pageIndex=z++,F.pageAttrs={...bt,...F.pageAttrs},k.push(F);const h=F.pageAttrs[mt]||"default";w[h]=(w[h]||0)+1}continue}else{k.push({pageIndex:z++,pageAttrs:{...bt,"custom-slidev-src":X},notes:"",rawMarkdown:`> 📄 **引入外部幻灯片页面**: \`${X}\`
>
> *提示：如需展示该页面完整内容，请将关联子页面一同打包为 .zip 或通过本地工程导入。*`,hasVueComponent:!1,hasStyleTag:!1,assetReferences:[]});const T=bt[mt]||"default";w[T]=(w[T]||0)+1;continue}}const J={};_.layout&&(J[mt]=String(_.layout)),_.transition&&(J[Qt]=String(_.transition)),_.background&&(J[Ut]=String(_.background)),_.image&&(J[Ee]=String(_.image)),_.class&&(J[Vi]=String(_.class));for(const[X,dt]of Object.entries(_))["layout","transition","background","image","class"].includes(X)||(J[`custom-slidev-${X}`]=typeof dt=="object"?JSON.stringify(dt):String(dt));let U=P;const G=[];let V=U.replace(/(?:^[ \t]*(`{3,}|~{3,})[^\n\r]*\r?\n[\s\S]*?\r?\n[ \t]*\1(?=[ \t]*(?:\r?\n|$)))/gm,X=>{const dt=`__CODE_TOKEN_NOTE_${G.length}__`;return G.push(X),dt});V=V.replace(/(`+)(?:[^\n\r`]|(?!\1)`)+?\1/g,X=>{const dt=`__CODE_TOKEN_NOTE_${G.length}__`;return G.push(X),dt});let M="";const E=Array.from(V.matchAll(/<!--([\s\S]*?)-->/g));if(E.length>0){const X=E[E.length-1],dt=V.slice(X.index+X[0].length).trim();if(!dt||!dt.replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi,"").trim()){const T=X[1].trim();T.startsWith("TODO:")||(M=T,x++),e&&(V=V.slice(0,X.index).trimEnd()+V.slice(X.index+X[0].length))}}e&&(V=V.replace(/<!--(?![\s\S]*?TODO:)[\s\S]*?-->/g,"").trim());for(let X=0;X<G.length;X++)V=V.replace(`__CODE_TOKEN_NOTE_${X}__`,G[X]);if(U=V,M){for(let bt=0;bt<G.length;bt++)M=M.replace(`__CODE_TOKEN_NOTE_${bt}__`,G[bt]);const dt=`> [!NOTE] 💡 演讲备注
${M.split(/\r?\n/).map(bt=>`> ${bt}`).join(`
`)}
{: custom-slidev-note="true"}`;U=U?`${U}

${dt}`:dt}let R=!1;if(/<style\b/i.test(U)){R=!0;const X=U.match(/<style\b[^>]*>([\s\S]*?)<\/style>/gi);if(X){for(const dt of X){const bt=dt.replace(/<style\b[^>]*>|<\/style>/gi,"").trim();y=y?`${y}

${bt}`:bt}l&&(U=U.replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi,"").trim())}}const tt=U.match(/<v-click[^>]*>|<v-clicks[^>]*>|v-click=/g);tt&&(S+=tt.length);const Q=U.match(/```\w+\s+\{[^}]+\}/g);Q&&(B+=Q.length);const Y=U.match(/::\w+::|<template\s+#[^>]+>/g);if(Y&&(A+=Y.length),U=U.replace(/^[ \t]*<<<[ \t]+([^\n\r]+)/gm,X=>V1(X,{...i,virtualFiles:c})||X),n&&(U=U.replace(/<v-click(?:\s+at="[^"]*")?(?:\s+hide)?>\s*([\s\S]*?)\s*<\/v-click>/gi,"$1")),o&&(U=U.replace(/(^```\w+(?:[ \t]+\[[^\]]*\])?)[ \t]+\{[^}]+\}(?:[ \t]+\w+)?/gm,"$1"),U=U.replace(/^\$\$\s+\{[^}]+\}/gm,()=>"$$")),s&&(U=U.replace(/^::\w+::\s*$/gm,"")),r&&(U=qu(U)),a){let X=U.trim(),dt="";const bt=X.lastIndexOf("> [!NOTE] 💡 演讲备注");if(bt!==-1&&(dt=X.slice(bt),X=X.slice(0,bt).trim()),(_.layout==="image-left"||_.layout==="image-right")&&_.image){const T=String(_.image).trim(),F=_.layout==="image-left"?"image-left":"image-right",h=`![配图](${T})
{: custom-slidev-layout="${F}" }`;_.layout==="image-left"?X=`{{{col

${h}

${X}

}}}`:X=`{{{col

${X}

${h}

}}}`}if(_.background){const F=`![背景图](${String(_.background).trim()})
{: custom-slidev-role="background" }`;X=X?`${F}

${X}`:F}U=dt?`${X}

${dt}`:X}const W=Z1(U);J[Ut]&&W.push(J[Ut]),J[Ee]&&W.push(J[Ee]);for(const X of W)I.add(X);const ut=/<[A-Z][a-zA-Z0-9]+/.test(U),ct=J[mt]||(z===1?g[mt]||"cover":"default");w[ct]=(w[ct]||0)+1,k.push({pageIndex:z++,pageAttrs:J,notes:M,rawMarkdown:U,hasVueComponent:ut,hasStyleTag:R,assetReferences:W})}if(!d&&k.length>0){const H=k[0].rawMarkdown.match(/^#\s+(.+)$/m);H&&(d=H[1].trim())}y&&(g["custom-slidev-custom-css"]=y);let O=k.map(H=>`---

${H.rawMarkdown}`).join(`

`);return O.trimStart().startsWith("---")||(O=`---

${O.trimStart()}`),{docTitle:d||"Slidev 演示文稿",docRootAttrs:g,slides:k,totalSlides:k.length,stats:{totalNotes:x,totalVClicks:S,totalShikiHighlights:B,totalSlots:A,discoveredAssets:Array.from(I),layoutDistribution:w},flattenedMarkdown:O,customCss:y}}function Z1(t){const i=[],e=/!\[.*?\]\((.*?)\)/g;let n;for(;(n=e.exec(t))!==null;){const s=n[1].split(/\s+/)[0].trim();s&&i.push(s)}const o=/<(?:img|video|source|audio)\b[^>]*src=["'](.*?)["']/gi;for(;(n=o.exec(t))!==null;){const s=n[1].trim();s&&i.push(s)}return i}function ha(t){if(!t)return!1;const i=String(t.type||"").toLowerCase(),e=String(t.markdown||"").trim(),n=String(t.content||"").trim();return i==="tb"||i==="thematic-break"||i==="nodethematicbreak"||e==="---"||e==="***"||n==="---"||n==="***"}function Y1(t){return(t.trim()||"Slidev 演示文稿").replace(/[\\/:*?"<>|]/g,"_")}async function J1(t,i,e=Dt){const n=t.filter(ha);let o=0;if(n.length>=i.length)for(let s=0;s<i.length;s++){const l=i[s],r=n[s];r&&r.id&&Object.keys(l.pageAttrs||{}).length>0&&(await e(r.id,l.pageAttrs),o++)}else for(let s=1;s<i.length;s++){const l=i[s],r=n[s-1];r&&r.id&&Object.keys(l.pageAttrs||{}).length>0&&(await e(r.id,l.pageAttrs),o++)}return o}async function X1(t,i=Dt){let e=!1,n=0;for(const o of t){if(ha(o)){e=!1;continue}const s=(o.markdown||o.content||"").trim();if(s==="::right::"||s.startsWith("::right::")){e=!0;continue}e&&o.id&&(await i(o.id,{[At]:"right"}).catch(()=>{}),n++)}return n}async function Q1(t,i,e=Or){const n={};if(!i||i.length===0)return n;const o=[];for(const s of i){const l=new File([s.data],s.fileName,{type:"application/octet-stream"});o.push(l)}try{const s=await e("/data/assets",o);if(s!=null&&s.succMap)for(const[l,r]of Object.entries(s.succMap))n[l]=String(r)}catch(s){console.warn("上传本地静态资产失败，保留原路径:",s)}return Object.keys(n).length>0&&W1(t,n),n}async function tb(t){var B;const{presentation:i,notebookId:e,docTitle:n,extractedAssets:o=[],uploadAssets:s=!0,autoPreview:l=!0,plugin:r,api:a={}}=t,c=a.uploadFn||Or,u=a.createDocFn||tc,m=a.setAttrsFn||Dt,g=a.getChildBlocksFn||no,d=a.openTabFn||ht.openTab,y=a.showMessageFn||ht.showMessage;s&&o.length>0&&await Q1(i,o,c);const f=Y1(n),v=`/${f}`,k=await u(e,v,i.flattenedMarkdown);if(!k)throw new Error("思源内核创建文档失败，未返回有效 DocumentId");const x=((B=i.slides[0])==null?void 0:B.pageAttrs)||{};await m(k,{...x,...i.docRootAttrs});const S=await g(k).catch(()=>[]);return Array.isArray(S)&&S.length>0&&(await J1(S,i.slides,m),await X1(S,m)),y(`🎉 成功导入 Slidev 演示文档《${f}》！`),l&&r&&(r.currentDocId=k,await d({app:r.app,doc:{id:k}}),r.openBottomPreviewTab&&r.openBottomPreviewTab()),k}function eb(t){const i=gt("file"),e=gt(!1),n=gt(!1),o=gt(""),s=gt(null),l=gt(null),r=gt(""),a=gt(0),c=gt(""),u=gt([]),m=gt(null),g=gt(""),d=gt([]),y=gt(""),f=gt(!0),v=gt(!0),k=gt(!0),x=gt(!0),S=_t(()=>{const J=a.value;if(J===0)return"0 B";const U=1024,G=["B","KB","MB","GB"],V=Math.floor(Math.log(J)/Math.log(U));return`${(J/U**V).toFixed(1)} ${G[V]}`}),B=_t(()=>{var J;return((J=m.value)==null?void 0:J.docRootAttrs["custom-slidev-theme"])||"default"}),A=_t(()=>{var J;return u.value.length>0?u.value.length:((J=m.value)==null?void 0:J.stats.discoveredAssets.length)||0}),I=_t(()=>{var U;const J=((U=m.value)==null?void 0:U.stats.layoutDistribution)||{};return Object.entries(J).map(([G,V])=>({name:G,count:V}))});async function w(J=Qa){try{const U=await J();U!=null&&U.notebooks&&Array.isArray(U.notebooks)&&(d.value=U.notebooks.filter(G=>!G.closed),d.value.length>0&&!y.value&&(y.value=d.value[0].id))}catch(U){console.warn("获取笔记本列表失败:",U)}}function z(){var J;(J=s.value)==null||J.click()}function O(){l.value=null,r.value="",a.value=0,m.value=null,u.value=[],o.value=""}async function H(J){o.value="",l.value=J,r.value=J.name,a.value=J.size;try{if(J.name.toLowerCase().endsWith(".zip")){const G=await J.arrayBuffer(),V=await U1(G);if(!V.entryMarkdown){o.value="未在 Zip 压缩包中找到 slides.md 或任何有效的 Markdown 入口文件";return}u.value=V.assets;const M=eo(V.entryMarkdown,{stripNotesFromMarkdown:v.value,cleanHtmlToMarkdown:f.value,cleanSlots:!1,virtualFiles:V.virtualFiles});m.value=M,g.value=M.docTitle||J.name.replace(/\.zip$/i,"")}else{const G=await J.text();u.value=[];const V=J.path||"",M=V?V.replace(/[\\/][^\\/]+$/,""):"",E=eo(G,{stripNotesFromMarkdown:v.value,cleanHtmlToMarkdown:f.value,cleanSlots:!1,baseDir:M||void 0});m.value=E,g.value=E.docTitle||J.name.replace(/\.md$/i,"")}}catch(U){console.error("解析文件失败:",U),o.value=`解析文件失败: ${U.message||String(U)}`}}function et(){if(o.value="",!c.value.trim()){m.value=null;return}try{const J=eo(c.value,{stripNotesFromMarkdown:v.value,cleanHtmlToMarkdown:f.value,cleanSlots:!1});m.value=J,g.value=J.docTitle||"Slidev 演示文稿"}catch(J){o.value=`解析 Markdown 源码失败: ${J.message||String(J)}`}}async function _(){l.value?await H(l.value):c.value&&et()}async function P(J){const U=J.target;U.files&&U.files[0]&&await H(U.files[0])}async function b(J){var U;e.value=!1,(U=J.dataTransfer)!=null&&U.files&&J.dataTransfer.files[0]&&await H(J.dataTransfer.files[0])}async function N(J=t){if(m.value){if(!y.value&&d.value.length>0&&(y.value=d.value[0].id),!y.value){o.value="请先选择目标笔记本";return}n.value=!0,o.value="";try{return await tb({presentation:m.value,notebookId:y.value,docTitle:g.value,extractedAssets:u.value,uploadAssets:k.value,autoPreview:x.value,plugin:J})}catch(U){console.error("导入 Slidev 演示失败:",U),o.value=`导入执行失败: ${U.message||String(U)}`}finally{n.value=!1}}}return{inputMode:i,isDragging:e,isImporting:n,errorMessage:o,fileInputRef:s,selectedFile:l,selectedFileName:r,selectedFileSize:a,rawMarkdownText:c,extractedAssets:u,parsedPresentation:m,customDocTitle:g,notebooks:d,selectedNotebookId:y,optCleanHtml:f,optStripNotes:v,optUploadAssets:k,optAutoPreview:x,formattedFileSize:S,currentTheme:B,extractedAssetsCount:A,layoutChips:I,fetchNotebooks:w,triggerFileInput:z,clearFile:O,processFile:H,onFileSelected:P,onFileDrop:b,onTextChange:et,reprocessCurrentInput:_,handleConfirmImport:N}}const ib={class:"spm-import-dialog"},nb={class:"spm-tabs-header"},ob={class:"spm-dialog-body"},sb={key:0,class:"spm-file-section"},rb={key:0,class:"spm-dropzone-prompt"},lb={class:"spm-dropzone-icon"},ab={key:1,class:"spm-dropzone-active"},cb={class:"spm-file-badge"},db={class:"spm-file-size"},ub={key:1,class:"spm-text-section"},fb={key:2,class:"spm-error-banner"},pb={key:3,class:"spm-preview-card"},hb={class:"spm-preview-card__header"},mb={style:{display:"inline-flex","align-items":"center",gap:"4px"}},gb={class:"spm-config-grid"},vb={class:"spm-form-item"},bb={class:"spm-form-item"},yb=["value"],kb={class:"spm-stats-grid"},wb={class:"spm-stat-box"},xb={class:"spm-stat-value"},_b={class:"spm-stat-box"},Sb={class:"spm-stat-value"},Cb={class:"spm-stat-box"},$b={class:"spm-stat-value"},Ib={class:"spm-stat-box"},Ab={class:"spm-stat-value"},Bb={key:0,class:"spm-chips-row"},Tb={class:"spm-options-group"},Eb={class:"spm-checkbox-label"},Mb={class:"spm-checkbox-label"},Db={class:"spm-checkbox-label"},Lb={class:"spm-checkbox-label"},Pb={class:"spm-dialog-footer"},Rb=["disabled"],Ob=["disabled"],zb={key:0,style:{display:"inline-flex","align-items":"center",gap:"4px"}},Nb={key:1,style:{display:"inline-flex","align-items":"center",gap:"4px"}},Fb=Se({__name:"SlidevImportDialog",emits:["close","success"],setup(t,{emit:i}){const e=i,n=ti("plugin"),{inputMode:o,isDragging:s,isImporting:l,errorMessage:r,fileInputRef:a,selectedFileName:c,rawMarkdownText:u,extractedAssetsCount:m,parsedPresentation:g,customDocTitle:d,notebooks:y,selectedNotebookId:f,optCleanHtml:v,optStripNotes:k,optUploadAssets:x,optAutoPreview:S,formattedFileSize:B,currentTheme:A,layoutChips:I,fetchNotebooks:w,triggerFileInput:z,clearFile:O,onFileSelected:H,onFileDrop:et,onTextChange:_,reprocessCurrentInput:P,handleConfirmImport:b}=eb(n);Rn(async()=>{await w()});async function N(){const U=await b();U&&(e("success",{docId:U}),e("close"))}function J(){e("close")}return(U,G)=>(ot(),st("div",{class:"spm-modal-overlay",onClick:Me(J,["self"])},[p("div",ib,[p("div",{class:"spm-dialog-header"},[G[18]||(G[18]=p("div",{class:"spm-dialog-title"},[p("svg",{class:"spm-dialog-icon","aria-hidden":"true"},[p("use",{"xlink:href":"#iconSlidev"})]),p("span",null,"导入 Slidev 演示文档")],-1)),p("button",{class:"spm-close-btn",title:"关闭",onClick:J},"✕")]),p("div",nb,[p("button",{class:It(["spm-tab-btn",{active:vt(o)==="file"}]),onClick:G[0]||(G[0]=V=>o.value="file")},[at(ft,{name:"package"}),G[19]||(G[19]=p("span",null,"文件 / 压缩包导入 (.zip / .md)",-1))],2),p("button",{class:It(["spm-tab-btn",{active:vt(o)==="text"}]),onClick:G[1]||(G[1]=V=>o.value="text")},[at(ft,{name:"notes"}),G[20]||(G[20]=p("span",null,"粘贴 Markdown 源码",-1))],2)]),p("div",ob,[vt(o)==="file"?(ot(),st("div",sb,[p("div",{class:It(["spm-dropzone",{dragover:vt(s),"has-file":!!vt(c)}]),onDragover:G[4]||(G[4]=Me(V=>s.value=!0,["prevent"])),onDragleave:G[5]||(G[5]=Me(V=>s.value=!1,["prevent"])),onDrop:G[6]||(G[6]=Me((...V)=>vt(et)&&vt(et)(...V),["prevent"])),onClick:G[7]||(G[7]=(...V)=>vt(z)&&vt(z)(...V))},[p("input",{ref_key:"fileInputRef",ref:a,type:"file",accept:".zip,.md",class:"spm-hidden-input",onChange:G[2]||(G[2]=(...V)=>vt(H)&&vt(H)(...V))},null,544),vt(c)?(ot(),st("div",ab,[p("span",cb,[at(ft,{name:"notes"}),Ae(" "+St(vt(c)),1)]),p("span",db,"("+St(vt(B))+")",1),p("button",{class:"spm-btn-text",onClick:G[3]||(G[3]=Me((...V)=>vt(O)&&vt(O)(...V),["stop"]))},"更换文件")])):(ot(),st("div",rb,[p("span",lb,[at(ft,{name:"folder",style:{"font-size":"32px"}})]),G[21]||(G[21]=p("p",{class:"spm-dropzone-text"},"点击选择文件，或直接拖拽文件至此处",-1)),G[22]||(G[22]=p("p",{class:"spm-dropzone-hint"},[Ae(" 支持 Slidev 完整工程 "),p("strong",null,".zip"),Ae("（自动解包 public/ 静态素材）或单文件 "),p("strong",null,".md")],-1))]))],34)])):(ot(),st("div",ub,[Te(p("textarea",{"onUpdate:modelValue":G[8]||(G[8]=V=>Yt(u)?u.value=V:null),class:"spm-textarea spm-source-editor",rows:"8",placeholder:"在此直接粘贴包含 Frontmatter 的 Slidev slides.md 源码...",onInput:G[9]||(G[9]=(...V)=>vt(_)&&vt(_)(...V))},null,544),[[bo,vt(u)]])])),vt(r)?(ot(),st("div",fb," ⚠️ "+St(vt(r)),1)):Rt("",!0),vt(g)?(ot(),st("div",pb,[p("div",hb,[p("span",mb,[at(ft,{name:"sparkles"}),G[23]||(G[23]=Ae(" 演示解析摘要",-1))]),G[24]||(G[24]=p("span",{class:"spm-badge-success"},"预检就绪",-1))]),p("div",gb,[p("div",vb,[G[25]||(G[25]=p("label",{class:"spm-form-label"},"笔记文档标题",-1)),Te(p("input",{"onUpdate:modelValue":G[10]||(G[10]=V=>Yt(d)?d.value=V:null),class:"spm-input",placeholder:"思源新文档标题"},null,512),[[bo,vt(d)]])]),p("div",bb,[G[26]||(G[26]=p("label",{class:"spm-form-label"},"存放目标笔记本",-1)),Te(p("select",{"onUpdate:modelValue":G[11]||(G[11]=V=>Yt(f)?f.value=V:null),class:"spm-select"},[(ot(!0),st(Gt,null,xe(vt(y),V=>(ot(),st("option",{key:V.id,value:V.id},St(V.name),9,yb))),128))],512),[[$u,vt(f)]])])]),p("div",kb,[p("div",wb,[p("span",xb,St(vt(g).totalSlides),1),G[27]||(G[27]=p("span",{class:"spm-stat-label"},"幻灯片页数",-1))]),p("div",_b,[p("span",Sb,St(vt(A)),1),G[28]||(G[28]=p("span",{class:"spm-stat-label"},"演示主题",-1))]),p("div",Cb,[p("span",$b,St(vt(g).stats.totalNotes),1),G[29]||(G[29]=p("span",{class:"spm-stat-label"},"演讲者提词",-1))]),p("div",Ib,[p("span",Ab,St(vt(m)),1),G[30]||(G[30]=p("span",{class:"spm-stat-label"},"关联本地素材",-1))])]),vt(I).length>0?(ot(),st("div",Bb,[G[31]||(G[31]=p("span",{class:"spm-chips-label"},"页面版式分布：",-1)),(ot(!0),st(Gt,null,xe(vt(I),V=>(ot(),st("span",{key:V.name,class:"spm-chip-badge"},St(V.name)+": "+St(V.count),1))),128))])):Rt("",!0),p("div",Tb,[p("label",Eb,[Te(p("input",{"onUpdate:modelValue":G[12]||(G[12]=V=>Yt(v)?v.value=V:null),type:"checkbox",onChange:G[13]||(G[13]=(...V)=>vt(P)&&vt(P)(...V))},null,544),[[Kn,vt(v)]]),G[32]||(G[32]=p("span",null,"智能剥离展示型 HTML 容器为干净原生的 Markdown 笔记块",-1))]),p("label",Mb,[Te(p("input",{"onUpdate:modelValue":G[14]||(G[14]=V=>Yt(k)?k.value=V:null),type:"checkbox",onChange:G[15]||(G[15]=(...V)=>vt(P)&&vt(P)(...V))},null,544),[[Kn,vt(k)]]),G[33]||(G[33]=p("span",null,"提取演讲者提词到块属性并保持正文笔记清爽",-1))]),p("label",Db,[Te(p("input",{"onUpdate:modelValue":G[16]||(G[16]=V=>Yt(x)?x.value=V:null),type:"checkbox"},null,512),[[Kn,vt(x)]]),G[34]||(G[34]=p("span",null,"自动上传关联素材至思源资产库并重写路径 (assets/...)",-1))]),p("label",Lb,[Te(p("input",{"onUpdate:modelValue":G[17]||(G[17]=V=>Yt(S)?S.value=V:null),type:"checkbox"},null,512),[[Kn,vt(S)]]),G[35]||(G[35]=p("span",null,"导入后自动打开新文档并开启下方分屏放映预览",-1))])])])):Rt("",!0)]),p("div",Pb,[p("button",{class:"spm-btn-secondary",disabled:vt(l),onClick:J}," 取消 ",8,Rb),p("button",{class:"spm-btn-primary",disabled:!vt(g)||vt(l),onClick:N},[vt(l)?(ot(),st("span",zb,[at(ft,{name:"refresh"}),G[36]||(G[36]=Ae(" 正在导入生成中...",-1))])):(ot(),st("span",Nb,[at(ft,{name:"rocket"}),G[37]||(G[37]=Ae(" 确认导入思源笔记",-1))]))],8,Ob)])])]))}}),Hb=ze(Fb,[["__scopeId","data-v-ce8dffdc"]]);function ma(t){return t?t==="NodeThematicBreak"||t==="tb"||t==="thematic-break":!1}function jb(t,i){var r;if(!t||t.length===0)return null;const e=i.activeBlockId||"",n=i.currentTopBlockId||e,o=i.currentPageDividerId||"",s=i.activeBlockType||"";if(ma(s)&&e){let a=t.find(c=>c.startBlockId===e);if(a||(a=t.find(c=>{var u,m;return((m=(u=c.blocks)==null?void 0:u[0])==null?void 0:m.id)===e}),a)||(a=t.find(c=>{var u;return(u=c.allBlockIds)==null?void 0:u.includes(e)}),a))return a}if(o){let a=t.find(c=>c.startBlockId===o);if(a||(a=t.find(c=>{var u,m;return((m=(u=c.blocks)==null?void 0:u[0])==null?void 0:m.id)===o}),a))return a}if(e){let a=t.find(u=>u.startBlockId===e);if(a||(a=t.find(u=>{var m,g;return((m=u.blocks)==null?void 0:m.some(d=>d.id===e))||((g=u.allBlockIds)==null?void 0:g.includes(e))}),a)||n&&n!==e&&(a=t.find(u=>{var m,g;return((m=u.blocks)==null?void 0:m.some(d=>d.id===n))||((g=u.allBlockIds)==null?void 0:g.includes(n))}),a)||(a=t.find(u=>{var m;return(m=u.noteBlocks)==null?void 0:m.some(g=>g.id===e||g.id===n)}),a))return a;const c=(r=i.activeBlockAttrs)==null?void 0:r[At];if(c&&["col-1","col-2","col-3"].includes(c)&&(a=t.find(u=>{var m,g;return((m=u.frontmatter)==null?void 0:m.layout)==="three-cols-header"||((g=u.blocks)==null?void 0:g.some(d=>d.slot==="col-1"||d.slot==="col-2"||d.slot==="col-3"))}),a))return a}return t[0]||null}function Dr(t,i){const e=(t.blocks||[]).filter(l=>{const r=(l.content||l.rawMarkdown||"").trim();return r&&r!=="---"});if(e.length===0)return"本页暂无内容，建议过渡承接上下文。";const n=[],o=[];for(const l of e){const r=(l.content||l.rawMarkdown||"").trim();r&&(l.type==="h"||r.startsWith("#")?n.push(r.replace(/^#+\s*/,"")):o.push(r.slice(0,50)))}const s=[];return n.length>0&&s.push(`【核心重点】：${n.join("、")}`),o.length>0&&(s.push("【口播要点】："),o.slice(0,3).forEach((l,r)=>{s.push(`${r+1}. 讲解 ${l}`)})),s.push("【过渡提示】：注意观察听众反应，适时抛出互动提问。"),s.join(`
`)}async function ga(t,i){const e=t.blocks&&t.blocks.length>0?t.blocks.map(n=>(n.content||n.rawMarkdown||"").trim()).filter(n=>n&&n!=="---").join(`
`):(t.rawMarkdown||"").replace(/^---\s*$/gm,"").trim();if(i&&e){const n=`你是一位专业的演讲教练。请根据以下幻灯片内容，提炼出简短精炼的演讲口播提词卡（Notes），包含核心观点与口播要点，总字数在 150 字以内：
${e}`;try{const o=await i(n);if(o&&o.trim())return{notes:o.trim(),isAiGenerated:!0}}catch(o){return{notes:Dr(t),isAiGenerated:!1,error:(o==null?void 0:o.message)||"AI 调用异常"}}}return{notes:Dr(t),isAiGenerated:!1}}async function Ub(t,i){return(await ga(t,i)).notes}function Lr(t,i){if(!i)return!1;if(t===i||typeof document>"u")return!0;const e=document.querySelector(`.protyle-wysiwyg [data-node-id="${i}"]`)||document.querySelector(`[data-node-id="${i}"]`);if(!e)return!1;const n=e.querySelector(":scope > [data-node-id], :scope > div > [data-node-id]");return(n==null?void 0:n.getAttribute("data-node-id"))===t}function Wb(t){const i=gt(!1);let e=null;function n(M="已同步"){t.saveStatus.value=M,e&&(typeof window<"u"?window.clearTimeout(e):clearTimeout(e));const E=()=>{t.saveStatus.value=""};typeof window<"u"?e=window.setTimeout(E,1200):e=setTimeout(E,1200)}async function o(M){var Q;const E=t.activeBlockId.value||t.currentDocId.value;if(!E)return;for(const[Y,W]of Object.entries(M))t.activeBlockAttrs.value[Y]=W;Pt.setBlockAttrOverride(E,M),ee(E,M);const R=(Q=t.parentContainerId)==null?void 0:Q.value,tt=!!(R&&Lr(E,R));if(jt in M&&tt&&R){const Y=M[jt];t.parentContainerClicks&&(t.parentContainerClicks.value=Y),Pt.setBlockAttrOverride(R,{[jt]:Y}),ee(R,{[jt]:Y}),Dt(R,{[jt]:Y}).catch(()=>{})}if(mt in M){const Y=M[mt];t.currentPageDividerLayout.value=Y,t.targetSlide.value&&(t.targetSlide.value.frontmatter||(t.targetSlide.value.frontmatter={}),t.targetSlide.value.frontmatter.layout=Y)}if(re in M){const Y=M[re];t.targetSlide.value&&(t.targetSlide.value.frontmatter||(t.targetSlide.value.frontmatter={}),t.targetSlide.value.frontmatter.layoutRatio=Y)}n("保存中...");try{await Dt(E,M),n("已同步"),t.plugin&&await t.plugin.compileCurrentDocument()}catch{n("同步失败")}}async function s(M,E){var Y;const R=t.activeBlockId.value||t.currentDocId.value;if(!R)return;t.activeBlockAttrs.value[M]=E,Pt.setBlockAttrOverride(R,{[M]:E}),ee(R,{[M]:E});const tt=(Y=t.parentContainerId)==null?void 0:Y.value,Q=!!(tt&&Lr(R,tt));M===jt&&Q&&tt&&(t.parentContainerClicks&&(t.parentContainerClicks.value=E),Pt.setBlockAttrOverride(tt,{[jt]:E}),ee(tt,{[jt]:E}),Dt(tt,{[jt]:E}).catch(()=>{})),M===mt&&(t.currentPageDividerLayout.value=E,t.targetSlide.value&&(t.targetSlide.value.frontmatter||(t.targetSlide.value.frontmatter={}),t.targetSlide.value.frontmatter.layout=E)),M===re&&t.targetSlide.value&&(t.targetSlide.value.frontmatter||(t.targetSlide.value.frontmatter={}),t.targetSlide.value.frontmatter.layoutRatio=E),n("保存中...");try{await Dt(R,{[M]:E}),n("已同步"),t.plugin&&await t.plugin.compileCurrentDocument()}catch{n("同步失败")}}function l(){const M=t.activeBlockType.value==="NodeThematicBreak"||t.activeBlockType.value==="NodeThematicBreakBlock"||t.activeBlockType.value==="hr"||t.activeBlockType.value==="thematicbreak";return t.currentPageDividerId.value||(M?t.activeBlockId.value:"")||t.currentDocId.value}async function r(M,E){const R=l();if(R){R===t.activeBlockId.value&&(t.activeBlockAttrs.value[M]=E),Pt.setBlockAttrOverride(R,{[M]:E}),ee(R,{[M]:E}),M===mt&&(t.currentPageDividerLayout.value=E,t.targetSlide.value&&(t.targetSlide.value.frontmatter||(t.targetSlide.value.frontmatter={}),t.targetSlide.value.frontmatter.layout=E)),M===re&&t.targetSlide.value&&(t.targetSlide.value.frontmatter||(t.targetSlide.value.frontmatter={}),t.targetSlide.value.frontmatter.layoutRatio=E),n("保存中...");try{await Dt(R,{[M]:E}),n("已同步"),t.plugin&&await t.plugin.compileCurrentDocument()}catch{n("同步失败")}}}async function a(M,E){const R=l();if(!R)return;const tt={[mt]:M,[re]:E};R===t.activeBlockId.value&&(t.activeBlockAttrs.value[mt]=M,t.activeBlockAttrs.value[re]=E),t.currentPageDividerLayout.value=M,Pt.setBlockAttrOverride(R,tt),ee(R,tt),t.targetSlide.value&&(t.targetSlide.value.frontmatter||(t.targetSlide.value.frontmatter={}),t.targetSlide.value.frontmatter.layout=M,t.targetSlide.value.frontmatter.layoutRatio=E),n("应用排版中...");try{await Dt(R,tt),n("已应用分栏与比例"),t.plugin&&await t.plugin.compileCurrentDocument()}catch{n("应用失败")}}async function c(M,E){var tt;const R=t.currentDocId.value||t.activeBlockId.value;if(R){t.activeBlockAttrs.value[M]=E,Pt.setBlockAttrOverride(R,{[M]:E}),ee(R,{[M]:E}),(tt=t.latestDoc.value)!=null&&tt.config&&(M===xn&&(t.latestDoc.value.config.theme=E),M===_n&&(t.latestDoc.value.config.aspectRatio=E),M===Sn&&(t.latestDoc.value.config.defaultTransition=E)),n("更新中...");try{await Dt(R,{[M]:E}),n("已更新"),t.plugin&&await t.plugin.compileCurrentDocument(R)}catch{n("更新失败")}}}async function u(){(t.videoAutoplay.value?"false":"true")==="true"?(await o({[Ti]:"true",[Ui]:"true"}),t.activeBlockAttrs.value[Ti]="true",t.activeBlockAttrs.value[Ui]="true"):(await s(Ti,"false"),t.activeBlockAttrs.value[Ti]="false")}async function m(){const M=t.videoLoop.value?"false":"true";await s(oo,M)}async function g(){const M=t.videoMuted.value?"false":"true";await s(Ui,M)}async function d(){const M=t.videoControls.value?"false":"true";await s(so,M)}async function y(M){var Y;const E=t.activeBlockId.value;if(!E)return;const R=t.rawSnippet.value||"",tt=vi(R)||"",Q=t.currentPageDividerId.value||t.currentDocId.value;if(M)if(M==="background"){const W={[Kt]:"background",[mt]:""};Q&&tt&&(t.pageBackground.value=tt,await Dt(Q,{[Ut]:tt}).catch(()=>{}),Pt.setBlockAttrOverride(Q,{[Ut]:tt}),ee(Q,{[Ut]:tt}),t.targetSlide.value&&(t.targetSlide.value.frontmatter||(t.targetSlide.value.frontmatter={}),t.targetSlide.value.frontmatter.background=tt)),await o(W)}else(M===ro||M===lo)&&await o({[mt]:M,[Kt]:""});else{const W={[Kt]:"",[mt]:""};if(t.activeBlockAttrs.value[Ut]==="true"&&(W[Ut]=""),Q&&tt&&t.pageBackground.value===tt&&(t.pageBackground.value="",await Dt(Q,{[Ut]:""}).catch(()=>{}),Pt.setBlockAttrOverride(Q,{[Ut]:""}),ee(Q,{[Ut]:""}),(Y=t.targetSlide.value)!=null&&Y.frontmatter&&delete t.targetSlide.value.frontmatter.background),await o(W),typeof document<"u"){const ut=document.querySelector(`.protyle-wysiwyg [data-node-id="${E}"]`),ct=ut==null?void 0:ut.closest('[data-type="NodeListItem"]'),X=ct==null?void 0:ct.getAttribute("data-node-id");if(X&&X!==E){const dt={[mt]:"",[Kt]:""};ee(X,dt),Pt.setBlockAttrOverride(X,dt),await Dt(X,dt).catch(()=>{})}}}}async function f(M){var X,dt,bt,T,F,h,j,L;const tt=`> [!NOTE] 💡 演讲备注
${(M||"在此输入本页讲稿提词...").split(/\r?\n/).map(C=>`> ${C}`).join(`
`)}
{: custom-slidev-note="true"}`,Q=((X=t.latestDoc.value)==null?void 0:X.slides)||[],Y=t.targetSlide.value,W=Y?Q.findIndex(C=>C===Y):-1;let ut=null;if(W!==-1&&W<Q.length-1){const C=Q[W+1];ut=await Ii("markdown",tt,C.startBlockId)}else{const C=((dt=Y==null?void 0:Y.noteBlocks)==null?void 0:dt.slice(-1)[0])||((bt=Y==null?void 0:Y.blocks)==null?void 0:bt.slice(-1)[0]),$=(C==null?void 0:C.id)||(Y==null?void 0:Y.startBlockId);$?ut=await Ii("markdown",tt,void 0,$):ut=await Xo("markdown",tt,t.currentDocId.value)}const ct=((h=(F=(T=ut==null?void 0:ut[0])==null?void 0:T.doOperations)==null?void 0:F[0])==null?void 0:h.id)||((j=ut==null?void 0:ut[0])==null?void 0:j.id);return ct&&(await Dt(ct,{[ie]:"true"}),Pt.setBlockAttrOverride(ct,{[ie]:"true"}),Pi(ct,(L=t.plugin)==null?void 0:L.app)),t.plugin&&await t.plugin.compileCurrentDocument(),ct}async function v(){const M=t.activeBlockId.value;if(M)if(t.isNoteBlock.value){n("取消中...");try{await Dt(M,{[ie]:"","slidev-note":""}),Pt.setBlockAttrOverride(M,{[ie]:"","slidev-note":""}),ee(M,{[ie]:"","slidev-note":""}),delete t.activeBlockAttrs.value[ie],delete t.activeBlockAttrs.value["slidev-note"],n("已取消备注"),ht.showMessage("已取消讲稿备注"),t.plugin&&await t.plugin.compileCurrentDocument()}catch(E){console.error("[SiYuanSlidev] 取消讲稿备注失败:",E),n("取消失败"),ht.showMessage("取消讲稿备注失败")}}else{n("转换中...");try{let E=t.rawSnippet.value;try{const Y=await ec(M);Y!=null&&Y.kramdown&&(E=Y.kramdown)}catch{}const Q=`> [!NOTE] 💡 演讲备注
${(ea(E)||E.replace(/<[^>]+>/g,"").trim()||"在此输入本页讲稿提词...").split(/\r?\n/).map(Y=>`> ${Y}`).join(`
`)}
{: custom-slidev-note="true"}`;await qs("markdown",Q,M),await Dt(M,{[ie]:"true"}),Pt.setBlockAttrOverride(M,{[ie]:"true"}),ee(M,{[ie]:"true"}),t.activeBlockAttrs.value[ie]="true",t.activeBlockType.value="NodeCallout",n("已设为讲稿备注"),ht.showMessage("已转为讲稿备注提示块（不在幻灯片中渲染）"),t.plugin&&await t.plugin.compileCurrentDocument()}catch(E){console.error("[SiYuanSlidev] 转换讲稿备注提示块失败:",E),n("设置失败"),ht.showMessage("转为讲稿备注提示块失败")}}}async function k(){try{await f(),ht.showMessage("已在正文末尾插入讲稿备注提示块")}catch(M){ht.showMessage("插入讲稿备注块失败"),console.error(M)}}function x(){var R;const M=t.currentSlideNoteBlockId.value;if(!M){ht.showMessage("未找到本页关联的讲稿备注块");return}Pi(M,(R=t.plugin)==null?void 0:R.app)?ht.showMessage("已在编辑区定位讲稿备注块"):ht.showMessage("定位讲稿备注块失败")}async function S(){var R;if(!t.currentDocId.value)return;const M=t.targetSlide.value||{startBlockId:t.activeBlockId.value||t.currentDocId.value,blocks:t.rawSnippet.value&&t.rawSnippet.value!=="---"?[{id:t.activeBlockId.value,type:t.activeBlockType.value,content:t.rawSnippet.value,rawMarkdown:""}]:[],rawMarkdown:t.rawSnippet.value&&t.rawSnippet.value!=="---"?t.rawSnippet.value:""};ht.showMessage("正在调用思源 AI 提炼本页讲稿提词...");const E=await ga(M,zr);if(E.notes){const tt=t.currentSlideNoteBlockId.value;if(tt){const Q=`> [!NOTE] 💡 演讲备注
${E.notes.split(/\r?\n/).map(Y=>`> ${Y}`).join(`
`)}
{: custom-slidev-note="true"}`;await qs("markdown",Q,tt),await Dt(tt,{[ie]:"true"}),Pt.setBlockAttrOverride(tt,{[ie]:"true"}),Pi(tt,(R=t.plugin)==null?void 0:R.app)}else await f(E.notes);E.isAiGenerated?ht.showMessage("思源 AI 演讲提词卡生成成功！"):ht.showMessage("未获取到思源 AI 响应，已生成预设提词卡模板",5e3),t.plugin&&await t.plugin.compileCurrentDocument()}}async function B(){var tt;if(i.value)return;const M=((tt=t.latestDoc.value)==null?void 0:tt.slides)||[];if(M.length===0){ht.showMessage("当前文档无幻灯片页面");return}const E=M.map((Q,Y)=>({slide:Q,idx:Y})).filter(({slide:Q})=>{var ut;const Y=Array.isArray(Q.noteBlocks)&&Q.noteBlocks.length>0,W=!!((ut=Q.notes)!=null&&ut.trim());return!Y&&!W});if(E.length===0){ht.showMessage("所有幻灯片页面均已存在讲稿备注块，无需追加");return}const R=E.length;ht.confirm("批量追加讲稿备注",`将在未配置讲稿的 ${R} 页末尾自动插入讲稿提示块，是否继续？`,async()=>{var Y,W,ut,ct,X,dt;if(i.value)return;i.value=!0,ht.showMessage("正在批量追加讲稿块...");let Q=0;try{const F=`> [!NOTE] 💡 演讲备注
${"在此输入本页讲稿提词...".split(/\r?\n/).map(h=>`> ${h}`).join(`
`)}
{: custom-slidev-note="true"}`;for(const{slide:h,idx:j}of E)try{let L=null;if(j<M.length-1){const $=M[j+1];L=await Ii("markdown",F,$.startBlockId)}else{const $=((Y=h==null?void 0:h.noteBlocks)==null?void 0:Y.slice(-1)[0])||((W=h==null?void 0:h.blocks)==null?void 0:W.slice(-1)[0]),D=($==null?void 0:$.id)||(h==null?void 0:h.startBlockId);D?L=await Ii("markdown",F,void 0,D):L=await Xo("markdown",F,t.currentDocId.value)}const C=((X=(ct=(ut=L==null?void 0:L[0])==null?void 0:ut.doOperations)==null?void 0:ct[0])==null?void 0:X.id)||((dt=L==null?void 0:L[0])==null?void 0:dt.id);C&&(await Dt(C,{[ie]:"true"}),Pt.setBlockAttrOverride(C,{[ie]:"true"})),Q++}catch(L){console.error(`[SiYuanSlidev] 为第 ${j+1} 页追加讲稿块失败:`,L)}t.plugin&&await t.plugin.compileCurrentDocument(),ht.showMessage(`已成功为 ${Q} 页追加讲稿备注块`)}catch(bt){console.error("[SiYuanSlidev] 批量追加讲稿块失败:",bt),ht.showMessage("批量追加讲稿块时出现异常")}finally{i.value=!1}})}async function A(){var Q;if(i.value)return;const M=((Q=t.latestDoc.value)==null?void 0:Q.slides)||[];if(M.length===0){ht.showMessage("当前文档无幻灯片页面");return}const E=[];for(const Y of M)if(Y.noteBlocks&&Y.noteBlocks.length>0)for(const W of Y.noteBlocks)W.id&&E.push({id:W.id,pageIndex:Y.pageIndex});if(E.length===0){ht.showMessage("当前文档中没有讲稿备注块，无需删除");return}const R=new Set(E.map(Y=>Y.pageIndex)).size,tt=E.length;ht.confirm("危险操作：批量删除所有讲稿块",`此操作将从正文中物理删除全部 ${tt} 个讲稿备注块（涉及 ${R} 页），删除后无法撤销。是否确认继续？`,async()=>{if(i.value)return;i.value=!0,ht.showMessage("正在批量删除讲稿块...");let Y=0;try{for(const W of E)try{await Ks(W.id),Pt.clearBlockAttrOverride(W.id),Y++}catch(ut){console.error(`[SiYuanSlidev] 删除讲稿块 ${W.id} 失败:`,ut)}t.activeBlockId.value&&E.some(W=>W.id===t.activeBlockId.value)&&(delete t.activeBlockAttrs.value[ie],delete t.activeBlockAttrs.value["slidev-note"]),t.plugin&&await t.plugin.compileCurrentDocument(),ht.showMessage(`已成功删除全部 ${Y} 个讲稿备注块`)}catch(W){console.error("[SiYuanSlidev] 批量删除讲稿块失败:",W),ht.showMessage("批量删除讲稿块时出现异常")}finally{i.value=!1}})}function I(){t.elemClick.value?s(jt,""):s(jt,"+1")}function w(M){s(jt,M)}function z(M){s(Ve,M)}function O(M){(t.activeBlockAttrs.value[At]||"")===M?s(At,""):s(At,M)}function H(M){t.elemShikiLines.value=M,s(Ri,M)}function et(M){t.elemMaxHeight.value=M,s(Cn,M)}async function _(){const M=t.currentSlideLayout.value==="three-cols-header";await s(At,M?"col-1":"left"),ht.showMessage(M?"已将当前块设置为第 1 栏 (col-1)":"已将当前块设置为双栏左栏 (left)")}async function P(){const M=t.activeBlockId.value;if(!M)return;const E={[jt]:"",[Ve]:"",[At]:"",[Ri]:"",[Cn]:"",[ie]:"","slidev-note":"",[mt]:"",[re]:"",[Kt]:"",[Qt]:"",[Ut]:"",[Ee]:"",[Ti]:"",[oo]:"",[Ui]:"",[so]:""};if(ee(M,E),await Dt(M,E),Pt.clearBlockAttrOverride(M),typeof document<"u"){const R=document.querySelector(`.protyle-wysiwyg [data-node-id="${M}"]`),tt=R==null?void 0:R.closest('[data-type="NodeListItem"]'),Q=tt==null?void 0:tt.getAttribute("data-node-id");Q&&Q!==M&&(ee(Q,E),await Dt(Q,E).catch(()=>{}),Pt.clearBlockAttrOverride(Q))}t.activeBlockAttrs.value={},t.elemShikiLines.value="",t.elemMaxHeight.value="",t.pageBackground.value="",t.pageImage.value="",ht.showMessage("已清除本块演示属性"),t.plugin&&await t.plugin.compileCurrentDocument()}async function b(){if(t.activeBlockId.value)try{await Ii("markdown","---",t.activeBlockId.value,void 0),ht.showMessage("已在上方插入分页符 (---)"),t.plugin&&t.plugin.compileCurrentDocument()}catch{ht.showMessage("插入分页符失败")}}async function N(){const M=t.activeBlockId.value||t.currentDocId.value;if(M)try{await Ii("markdown","---",void 0,M),ht.showMessage("已在下方插入分页符 (---)"),t.plugin&&t.plugin.compileCurrentDocument()}catch{ht.showMessage("插入分页符失败")}}async function J(){if(t.activeBlockId.value)try{await Ks(t.activeBlockId.value),ht.showMessage("已删除该分页符"),t.activeBlockId.value="",t.activeBlockType.value="",t.plugin&&t.plugin.compileCurrentDocument()}catch{ht.showMessage("删除失败")}}function U(){if(!t.latestDoc.value){ht.showMessage("请先在主编辑区打开幻灯片文档");return}const M=da(t.latestDoc.value);ua("presentation.html",M)&&ht.showMessage("已开始下载单文件离线 HTML 演示包")}function G(){if(!t.latestDoc.value){ht.showMessage("请先在主编辑区打开幻灯片文档");return}fa(t.latestDoc.value)&&ht.showMessage("已唤起打印视窗，请在打印选项中选择「另存为 PDF」")}async function V(){var M,E;try{let R=null;if(typeof document<"u"){const Q=t.activeBlockId.value;if(Q){const Y=document.querySelector(`.protyle-wysiwyg [data-node-id="${Q}"]`);Y&&(R=Y.getAttribute("data-type")==="NodeSuperBlock"?Y:Y.closest('[data-type="NodeSuperBlock"]'))}if(!R){const Y=t.currentPageDividerId.value||(t.activeBlockType.value==="hr"||t.activeBlockType.value==="NodeThematicBreak"?t.activeBlockId.value:"");if(Y){const W=document.querySelector(`.protyle-wysiwyg [data-node-id="${Y}"]`);if(W){let ut=W.nextElementSibling;for(;ut&&!(ut.getAttribute("data-type")==="NodeThematicBreak"||(M=ut.classList)!=null&&M.contains("protyle-wysiwyg__block--hr"));){const ct=ut.getAttribute("data-type")==="NodeSuperBlock"?ut:ut.querySelector('[data-type="NodeSuperBlock"]');if(ct){R=ct;break}ut=ut.nextElementSibling}}}else{const W=document.querySelector('.protyle-wysiwyg [data-type="NodeThematicBreak"], .protyle-wysiwyg .protyle-wysiwyg__block--hr'),ut=Array.from(document.querySelectorAll('.protyle-wysiwyg [data-type="NodeSuperBlock"]'));for(const ct of ut)if(!W||ct.compareDocumentPosition(W)&Node.DOCUMENT_POSITION_FOLLOWING){R=ct;break}}}}const tt=[];if(R){const Q=Array.from(R.querySelectorAll(":scope > [data-node-id]"));for(const Y of Q){const W=Y.getAttribute("data-node-id");W&&(tt.push(W),Y.removeAttribute("style"))}}else if((E=t.targetSlide.value)!=null&&E.blocks){for(const Q of t.targetSlide.value.blocks)if(Q.children&&Q.children.length>=2){for(const Y of Q.children)Y.id&&tt.push(Y.id);break}}if(tt.length>0)for(const Q of tt)await Dt(Q,{style:""}).catch(()=>{});await r(re,""),ht.showMessage("已重置超级块为平均分布比例"),t.plugin&&await t.plugin.compileCurrentDocument()}catch(R){console.error("[useInspectorActions] resetSuperBlockWidth error:",R),ht.showMessage("重置超级块比例失败")}}return{triggerSaveNotice:n,saveAttrs:o,saveAttr:s,savePageAttr:r,applyPageLayoutAndRatio:a,resetSuperBlockWidth:V,saveDocAttr:c,onToggleVideoAutoplay:u,onToggleVideoLoop:m,onToggleVideoMuted:g,onToggleVideoControls:d,onImageRoleChange:y,onToggleNoteBlock:v,createNoteBlockOnCurrentSlide:f,onAddNoteBlock:k,onLocateNoteBlock:x,onGenerateNotesWithAI:S,isBatchProcessing:i,onBatchAppendNotes:B,onBatchDeleteNotes:A,toggleElemClick:I,onElemClickStepChange:w,onElemMotionChange:z,onElemSlotChange:O,onElemShikiLinesChange:H,onElemMaxHeightChange:et,onSetTwoColsContrast:_,onClearBlockAttrs:P,onInsertDividerBefore:b,onInsertDividerAfter:N,onDeleteCurrentBlock:J,onExportHtml:U,onExportPdf:G}}const Vb={class:"spm-slidev-inspector"},qb={class:"spm-inspector-topbar"},Kb={class:"spm-inspector-title"},Gb={class:"slidev-icon",style:{fill:"none !important"},"aria-hidden":"true",viewBox:"0 0 24 24"},Zb={class:"spm-inspector-topbar-actions"},Yb={class:"spm-target-banner"},Jb={class:"spm-target-info"},Xb=["aria-label"],Qb={key:0,class:"spm-save-status"},ty=["title"],ey={class:"spm-inspector-body"},iy=Se({__name:"SlidevInspectorDockView",setup(t,{expose:i}){const e=ti("plugin"),n=gt(!1);function o(nt){n.value=!1,c.value=nt.docId,e!=null&&e.compileCurrentDocument&&e.compileCurrentDocument(nt.docId)}const s=gt(""),l=gt(""),r=gt({}),a=gt(""),c=gt(""),u=gt(""),m=gt(""),g=gt(""),d=gt(""),y=gt(""),f=gt(""),v=gt(null),k=gt(""),x=gt("");function S(){var yt;const nt=s.value||c.value;nt&&typeof navigator<"u"&&(yt=navigator==null?void 0:navigator.clipboard)!=null&&yt.writeText&&navigator.clipboard.writeText(nt).then(()=>{x.value="已复制！",setTimeout(()=>{x.value=""},1500)}).catch(()=>{})}const B=_t(()=>ma(l.value)),A=_t(()=>l.value==="NodeCodeBlock"),I=gt(!1),w=_t(()=>{if(I.value||rt.value)return!0;const nt=a.value||"";return!!vi(nt)}),z=_t(()=>{const nt=l.value||"";if(nt==="NodeVideo"||nt==="video")return!0;const yt=a.value||"";return!!(/<video\b/i.test(yt)||/\.mp4\b/i.test(yt))}),O=_t(()=>!s.value||s.value===c.value||l.value==="doc"||l.value==="NodeDocument"),H=_t(()=>{const nt=s.value||c.value||"";return nt.length>8?nt.slice(-8):nt||"无"}),et=_t(()=>a.value?a.value.replace(/<[^>]+>/g,"").replace(/[\r\n]+/g," ").trim().slice(0,45):""),_=_t(()=>{if(B.value)return"分页符 (---)";if(O.value)return"全局文档";if(z.value)return"视频块";let nt="内容块";switch(l.value){case"NodeHeading":nt="标题块";break;case"NodeParagraph":nt="段落块";break;case"NodeCodeBlock":nt="代码块";break;case"NodeVideo":nt="视频块";break;case"NodeList":case"NodeListItem":nt="列表项";break;case"NodeBlockquote":nt="引述块";break;case"NodeTable":nt="表格块";break;case"NodeSuperBlock":case"s":case"sb":nt="超级块";break;default:nt="内容块";break}return d.value?y.value?`${y.value.replace(/^col-(\d+)$/,"第 $1 栏")} › ${nt}`:`分栏容器 › ${nt}`:nt}),P=_t(()=>B.value?"tag-divider":O.value?"tag-doc":"tag-block"),b=_t(()=>r.value[mt]||"default"),N=_t(()=>r.value[Qt]||"slide-left"),J=gt(""),U=gt(""),G=_t(()=>r.value[fn]||"inherit"),V=_t(()=>{var nt;return jb((nt=v.value)==null?void 0:nt.slides,{activeBlockId:s.value,activeBlockType:l.value,currentTopBlockId:u.value,currentPageDividerId:m.value,activeBlockAttrs:r.value})}),M=_t(()=>{var nt;return((nt=V.value)==null?void 0:nt.notes)||""}),E=_t(()=>{var nt,yt,$t;return(($t=(yt=(nt=V.value)==null?void 0:nt.noteBlocks)==null?void 0:yt[0])==null?void 0:$t.id)||""}),R=_t(()=>{var Et,Ft,Lt,fe,Hn,ci;if(B.value){const Xt=r.value[mt]||r.value["custom-slidev-layout"];if(Xt)return Xt}const nt=r.value[At]||r.value["custom-slidev-slot"];if(nt&&(["col-1","col-2","col-3"].includes(nt)||/^col-\d+$/.test(nt)))return"cols-header";if(g.value)return g.value;const yt=m.value||(B.value?s.value:"");if(yt){const Xt=Pt.getBlockAttrOverride(yt);if(Xt!=null&&Xt[mt])return Xt[mt]}if(yt&&((Et=v.value)!=null&&Et.slides)){const Xt=v.value.slides.find(Fi=>Fi.startBlockId===yt);if((Ft=Xt==null?void 0:Xt.frontmatter)!=null&&Ft.layout)return Xt.frontmatter.layout}if((fe=(Lt=V.value)==null?void 0:Lt.frontmatter)!=null&&fe.layout)return V.value.frontmatter.layout;if((ci=(Hn=V.value)==null?void 0:Hn.blocks)!=null&&ci.some(Xt=>Xt.slot&&(["col-1","col-2","col-3"].includes(Xt.slot)||/^col-\d+$/.test(Xt.slot))))return"cols-header";const $t=Pt.getBlockAttrOverride(c.value);return $t!=null&&$t[mt]?$t[mt]:"default"}),tt=_t(()=>{var yt,$t;if(B.value){const Et=r.value[re]||r.value["custom-slidev-layout-ratio"];if(Et)return Et}const nt=m.value||(B.value?s.value:"");if(nt){const Et=Pt.getBlockAttrOverride(nt);if(Et!=null&&Et[re])return Et[re]}return(($t=(yt=V.value)==null?void 0:yt.frontmatter)==null?void 0:$t.layoutRatio)||""});function Q(nt){if(!nt||(nt.getAttribute("data-sb-layout")||"").toLowerCase()!=="col")return null;const $t=Array.from(nt.querySelectorAll(":scope > [data-node-id]"));if($t.length<2)return null;const Et=$t.length,Ft=$t.map(ci=>{const Xt=ci.getAttribute("style")||"",Fi=Xt.match(/calc\(\s*([\d.]+)%/);if(Fi)return parseFloat(Fi[1]);const on=Xt.match(/(?:^|;|\s)width:\s*([\d.]+)%/i);return on?parseFloat(on[1]):null});let Lt="",fe=!1;if(Ft.some(ci=>ci!==null)){fe=!0;const ci=Ft.reduce((Tt,pe)=>Tt+(pe||0),0),Xt=Ft.filter(Tt=>Tt===null).length,Fi=Xt>0?Math.max(0,100-ci)/Xt:100/$t.length,on=Ft.map(Tt=>Tt!==null?Tt:Fi),Va=on.reduce((Tt,pe)=>Tt+pe,0)||1,sn=on.map(Tt=>Tt/Va*100);if(sn.length===2){const[Tt]=sn;if(Tt>=48&&Tt<=52)Lt="1:1";else if(Tt>=31&&Tt<=35)Lt="1:2";else if(Tt>=65&&Tt<=69)Lt="2:1";else if(Tt>=28&&Tt<=32)Lt="3:7";else if(Tt>=68&&Tt<=72)Lt="7:3";else if(Tt>=38&&Tt<=42)Lt="4:6";else if(Tt>=58&&Tt<=62)Lt="6:4";else{const pe=Math.round(Tt);Lt=`${pe}:${100-pe}`}}else if(sn.length===3){const[Tt,pe,di]=sn;if(Tt>=31&&Tt<=35&&pe>=31&&pe<=35&&di>=31&&di<=35)Lt="1:1:1";else if(Tt>=23&&Tt<=27&&pe>=48&&pe<=52&&di>=23&&di<=27)Lt="1:2:1";else if(Tt>=48&&Tt<=52&&pe>=23&&pe<=27&&di>=23&&di<=27)Lt="2:1:1";else if(Tt>=23&&Tt<=27&&pe>=23&&pe<=27&&di>=48&&di<=52)Lt="1:1:2";else{const Ws=Math.round(Tt),Vs=Math.round(pe);Lt=`${Ws}:${Vs}:${100-Ws-Vs}`}}else Lt=sn.map(Tt=>Math.round(Tt)).join(":")}else fe=!1,Lt=Array.from({length:Et},()=>1).join(":");const Hn=Et>=2?"cols-header":"two-cols";return{hasSuperBlock:!0,colCount:Et,ratio:Lt,isCustomWidth:fe,recommendedLayout:Hn}}function Y(nt){if(!(nt!=null&&nt.blocks))return null;for(const yt of nt.blocks){const $t=yt.rawNode;if($t&&le($t)&&li($t)){const Ft=zn($t).length,Lt=Ps($t);return{hasSuperBlock:!0,colCount:Ft,ratio:Lt||Array.from({length:Ft},()=>1).join(":"),isCustomWidth:!!Lt,recommendedLayout:Ft>=2?"cols-header":"two-cols"}}}return null}const W=_t(()=>{var nt;if(typeof document<"u"){const yt=s.value;if(yt){const Et=document.querySelector(`.protyle-wysiwyg [data-node-id="${yt}"]`);if(Et){const Ft=Et.getAttribute("data-type")==="NodeSuperBlock"?Et:Et.closest('[data-type="NodeSuperBlock"]');if(Ft){const Lt=Q(Ft);if(Lt)return Lt}}}const $t=m.value||(B.value?s.value:"");if($t){const Et=document.querySelector(`.protyle-wysiwyg [data-node-id="${$t}"]`);if(Et){let Ft=Et.nextElementSibling;for(;Ft&&!(Ft.getAttribute("data-type")==="NodeThematicBreak"||(nt=Ft.classList)!=null&&nt.contains("protyle-wysiwyg__block--hr"));){const Lt=Ft.getAttribute("data-type")==="NodeSuperBlock"?Ft:Ft.querySelector('[data-type="NodeSuperBlock"]');if(Lt){const fe=Q(Lt);if(fe)return fe}Ft=Ft.nextElementSibling}}}else{const Et=document.querySelector('.protyle-wysiwyg [data-type="NodeThematicBreak"], .protyle-wysiwyg .protyle-wysiwyg__block--hr'),Ft=Array.from(document.querySelectorAll('.protyle-wysiwyg [data-type="NodeSuperBlock"]'));for(const Lt of Ft)if(!Et||Lt.compareDocumentPosition(Et)&Node.DOCUMENT_POSITION_FOLLOWING){const fe=Q(Lt);if(fe)return fe}}}return Y(V.value)}),ut=_t(()=>{var nt;return((nt=W.value)==null?void 0:nt.ratio)||""}),ct=_t(()=>{const nt=l.value||"";if(nt==="NodeSuperBlock"||nt==="s"||nt==="sb")return!0;if(typeof document<"u"&&s.value){const yt=document.querySelector(`.protyle-wysiwyg [data-node-id="${s.value}"]`);if(yt!=null&&yt.closest('[data-type="NodeSuperBlock"]'))return!0}return!1}),X=_t(()=>{var nt;return((nt=V.value)==null?void 0:nt.pageIndex)||1}),dt=_t(()=>!!(r.value[ie]||r.value["slidev-note"]));function bt(){if(!d.value)return!1;if(s.value===d.value||typeof document>"u")return!0;const nt=document.querySelector(`.protyle-wysiwyg [data-node-id="${d.value}"]`)||document.querySelector(`[data-node-id="${d.value}"]`);if(!nt)return!1;const yt=nt.querySelector(":scope > [data-node-id], :scope > div > [data-node-id]");return(yt==null?void 0:yt.getAttribute("data-node-id"))===s.value}const T=_t(()=>{var yt;if(r.value[jt]!==void 0)return r.value[jt]||"";if(d.value&&bt())return f.value||"";if(d.value)return"";const nt=s.value;if(nt&&((yt=V.value)!=null&&yt.blocks)){const $t=V.value.blocks.find(Et=>Et.id===nt);if($t!=null&&$t.clicks)return $t.clicks}return""}),F=_t(()=>{var yt;if(r.value[Ve])return r.value[Ve];const nt=s.value;if(nt&&((yt=V.value)!=null&&yt.blocks)){const $t=V.value.blocks.find(Et=>Et.id===nt);if($t!=null&&$t.motion)return typeof $t.motion=="string"?$t.motion:JSON.stringify($t.motion)}return""}),h=_t(()=>{var yt;if(r.value[At])return r.value[At];const nt=s.value;if(nt&&((yt=V.value)!=null&&yt.blocks)){const $t=V.value.blocks.find(Et=>Et.id===nt);if($t!=null&&$t.slot)return $t.slot}return""}),j=gt(""),L=gt(""),C=_t(()=>r.value[Ti]==="true"),$=_t(()=>r.value[oo]==="true"),D=_t(()=>r.value[Ui]==="true"),Z=_t(()=>r.value[so]!=="false"),K=_t(()=>{var nt,yt;return((yt=(nt=v.value)==null?void 0:nt.config)==null?void 0:yt.theme)||r.value[xn]||"default"}),q=_t(()=>{var nt,yt;return((yt=(nt=v.value)==null?void 0:nt.config)==null?void 0:yt.aspectRatio)||r.value[_n]||"16/9"}),it=_t(()=>{var nt,yt;return((yt=(nt=v.value)==null?void 0:nt.config)==null?void 0:yt.defaultTransition)||r.value[Sn]||"slide-left"}),lt=_t(()=>{var nt,yt;return((yt=(nt=v.value)==null?void 0:nt.config)==null?void 0:yt.spacing)||r.value[ts]||"normal"}),rt=_t(()=>{var Ft,Lt;if((r.value[Kt]||r.value["slidev-role"])===jr||r.value[Ut]==="true")return"background";const yt=r.value[mt]||r.value["slidev-layout"];if(yt==="image-left"||yt==="image-right")return yt;const $t=a.value||"",Et=vi($t);if(Et&&((Lt=(Ft=V.value)==null?void 0:Ft.frontmatter)!=null&&Lt.background)){const fe=V.value.frontmatter.background;if(fe===Et||fe.endsWith(Et)||Et.endsWith(fe))return"background"}return""}),pt=_t(()=>!!(r.value[jt]||r.value[Ve]||r.value[At]||r.value[Ri]||r.value[ie]||r.value["slidev-note"]||r.value[Kt]||r.value[mt]||r.value[Ti]||r.value[oo]||r.value[Ui]||r.value[so])),{saveAttr:wt,savePageAttr:kt,applyPageLayoutAndRatio:Mt,resetSuperBlockWidth:Zt,saveDocAttr:Vt,onToggleVideoAutoplay:se,onToggleVideoLoop:Nt,onToggleVideoMuted:Ke,onToggleVideoControls:ne,onImageRoleChange:Jt,onToggleNoteBlock:ki,onAddNoteBlock:zi,onLocateNoteBlock:Lo,onGenerateNotesWithAI:Po,isBatchProcessing:Fn,onBatchAppendNotes:wi,onBatchDeleteNotes:Ni,toggleElemClick:ya,onElemClickStepChange:ka,onElemMotionChange:wa,onElemSlotChange:xa,onElemShikiLinesChange:_a,onElemMaxHeightChange:Sa,onSetTwoColsContrast:Ca,onClearBlockAttrs:$a,onInsertDividerBefore:Ia,onInsertDividerAfter:Hs,onDeleteCurrentBlock:Aa,onExportHtml:Ba,onExportPdf:Ta}=Wb({activeBlockId:s,activeBlockType:l,activeBlockAttrs:r,rawSnippet:a,currentDocId:c,currentPageDividerId:m,currentPageDividerLayout:g,parentContainerId:d,parentContainerClicks:f,latestDoc:v,targetSlide:V,currentSlideNoteBlockId:E,currentSlideLayout:R,isNoteBlock:dt,elemClick:T,videoAutoplay:C,videoLoop:$,videoMuted:D,videoControls:Z,pageBackground:J,pageImage:U,elemShikiLines:j,elemMaxHeight:L,saveStatus:k,plugin:e});function Ea(nt){wt(mt,nt)}function Ma(nt){kt(re,nt)}function js(nt){if(!nt)return;const yt=nt.recommendedLayout||(nt.colCount&&nt.colCount>=2?"cols-header":"two-cols"),$t=nt.ratio||(nt.colCount?Array(nt.colCount).fill(1).join(":"):"1:1");Mt(yt,$t)}function Da(nt){kt(re,nt)}async function La(){await Zt()}function Pa(nt){wt(Qt,nt)}function Ra(nt){J.value=nt,wt(Ut,nt)}function Oa(nt){U.value=nt,wt(Ee,nt)}function za(nt){wt(fn,nt==="inherit"?"":nt)}function Na(nt){Vt(xn,nt)}function Fa(nt){Vt(_n,nt)}function Ha(nt){Vt(Sn,nt)}function ja(nt){Vt(ts,nt)}function Us(){e!=null&&e.openBottomPreviewTab&&e.openBottomPreviewTab()}function Ua(){typeof window<"u"&&window.open("/plugins/siyuan-slidev/slidev-client/presenter.html","SlidevPresenter","width=1200,height=800")}function Wa(){e!=null&&e.executeCommand&&e.executeCommand("slidevAiSplit")}return i({setActiveBlock(nt){s.value=nt.id,l.value=nt.type,r.value={...nt.attrs},a.value=nt.content||nt.markdown||"",u.value=nt.topBlockId||nt.id,m.value=nt.pageDividerId||"",g.value=nt.pageDividerLayout||"",d.value=nt.parentContainerId||"",y.value=nt.parentContainerSlot||"",f.value=nt.parentContainerClicks||"",nt.rootId?c.value=nt.rootId:(nt.type==="doc"||nt.type==="NodeDocument")&&nt.id&&(c.value=nt.id),J.value=nt.attrs[Ut]||"",U.value=nt.attrs[Ee]||"",j.value=nt.attrs[Ri]||"",L.value=nt.attrs[Cn]||"",I.value=!!nt.isImage},updateDocument(nt){v.value=nt,c.value=nt.docId},openImportDialog(){n.value=!0},setCurrentDocId(nt){c.value=nt}}),(nt,yt)=>(ot(),st("div",Vb,[p("div",qb,[p("div",Kb,[(ot(),st("svg",Gb,[...yt[2]||(yt[2]=[p("rect",{x:"2",y:"3",width:"20",height:"14",rx:"2"},null,-1),p("line",{x1:"8",y1:"21",x2:"16",y2:"21"},null,-1),p("line",{x1:"12",y1:"17",x2:"12",y2:"21"},null,-1)])])),yt[3]||(yt[3]=p("span",null,"演示配置",-1))]),p("div",Zb,[p("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"导入 Slidev 演示文档 (.md / .zip)",onClick:yt[0]||(yt[0]=$t=>n.value=!0)},[at(ft,{name:"import"}),yt[4]||(yt[4]=p("span",null,"导入",-1))]),p("button",{class:"spm-icon-btn is-primary b3-tooltips b3-tooltips__s","aria-label":"在下方分屏开启幻灯片预览 (Alt+P)",onClick:Us},[at(ft,{name:"split-preview"}),yt[5]||(yt[5]=p("span",null,"分屏预览",-1))])])]),p("div",Yb,[p("div",Jb,[p("span",{class:It(["spm-target-tag",P.value])},St(_.value),3),p("span",{class:"spm-target-id b3-tooltips b3-tooltips__s","aria-label":x.value||"点击复制 ID: "+(s.value||c.value),onClick:S},[at(ft,{name:"copy"}),p("span",null,"#"+St(H.value),1)],8,Xb)]),k.value?(ot(),st("span",Qb,"● "+St(k.value),1)):Rt("",!0)]),et.value?(ot(),st("div",{key:0,class:"spm-context-quote",title:a.value},St(et.value),9,ty)):Rt("",!0),p("div",ey,[B.value?(ot(),De(hg,{key:0,"page-layout":b.value,"page-layout-ratio":tt.value,"detected-sb-ratio":ut.value,"detected-sb-info":W.value,"page-transition":N.value,"page-background":J.value,"page-spacing":G.value,"page-image":U.value,"page-notes":M.value,"page-index":X.value,"onUpdate:pageLayout":Ea,"onUpdate:pageLayoutRatio":Ma,onApplySuperBlockLayout:js,onResetSuperblockRatio:La,"onUpdate:pageTransition":Pa,"onUpdate:pageBackground":Ra,"onUpdate:pageSpacing":za,"onUpdate:pageImage":Oa,onAddNoteBlock:vt(zi),onLocateNoteBlock:vt(Lo),onGenerateNotes:vt(Po),onBatchAppendNotes:vt(wi),onBatchDeleteNotes:vt(Ni),"is-batch-processing":vt(Fn),onInsertDividerAfter:vt(Hs),onDeleteDivider:vt(Aa)},null,8,["page-layout","page-layout-ratio","detected-sb-ratio","detected-sb-info","page-transition","page-background","page-spacing","page-image","page-notes","page-index","onAddNoteBlock","onLocateNoteBlock","onGenerateNotes","onBatchAppendNotes","onBatchDeleteNotes","is-batch-processing","onInsertDividerAfter","onDeleteDivider"])):s.value&&!O.value?(ot(),De(Xv,{key:1,"elem-click":T.value,"elem-motion":F.value,"elem-slot":h.value,"elem-shiki-lines":j.value,"elem-max-height":L.value,"is-code-block":A.value,"is-image":w.value,"is-video":z.value,"is-super-block":ct.value,"detected-sb-info":W.value,"video-autoplay":C.value,"video-loop":$.value,"video-muted":D.value,"video-controls":Z.value,"has-block-attrs":pt.value,"is-note":dt.value,"image-role":rt.value,"current-slide-layout":R.value,"parent-elem-click":f.value,"parent-container-slot":y.value,"parent-container-id":d.value,onToggleNote:vt(ki),onToggleElemClick:vt(ya),onToggleVideoAutoplay:vt(se),onToggleVideoLoop:vt(Nt),onToggleVideoMuted:vt(Ke),onToggleVideoControls:vt(ne),"onUpdate:imageRole":vt(Jt),"onUpdate:elemClick":vt(ka),"onUpdate:elemMotion":vt(wa),"onUpdate:elemSlot":vt(xa),"onUpdate:elemShikiLines":vt(_a),"onUpdate:elemMaxHeight":vt(Sa),onApplySuperBlockLayout:js,onApplySuperBlockRatio:Da,onInsertDividerBefore:vt(Ia),onInsertDividerAfter:vt(Hs),onSetTwoColsContrast:vt(Ca),onClearBlockAttrs:vt($a)},null,8,["elem-click","elem-motion","elem-slot","elem-shiki-lines","elem-max-height","is-code-block","is-image","is-video","is-super-block","detected-sb-info","video-autoplay","video-loop","video-muted","video-controls","has-block-attrs","is-note","image-role","current-slide-layout","parent-elem-click","parent-container-slot","parent-container-id","onToggleNote","onToggleElemClick","onToggleVideoAutoplay","onToggleVideoLoop","onToggleVideoMuted","onToggleVideoControls","onUpdate:imageRole","onUpdate:elemClick","onUpdate:elemMotion","onUpdate:elemSlot","onUpdate:elemShikiLines","onUpdate:elemMaxHeight","onInsertDividerBefore","onInsertDividerAfter","onSetTwoColsContrast","onClearBlockAttrs"])):(ot(),De(R1,{key:2,"doc-theme":K.value,"doc-aspect-ratio":q.value,"doc-default-transition":it.value,"doc-spacing":lt.value,"onUpdate:docTheme":Na,"onUpdate:docAspectRatio":Fa,"onUpdate:docDefaultTransition":Ha,"onUpdate:docSpacing":ja,onOpenBottomPreview:Us,onOpenPresenter:Ua,onAiAutoSplit:Wa,onExportHtml:vt(Ba),onExportPdf:vt(Ta)},null,8,["doc-theme","doc-aspect-ratio","doc-default-transition","doc-spacing","onExportHtml","onExportPdf"]))]),n.value?(ot(),De(Hb,{key:1,onClose:yt[1]||(yt[1]=$t=>n.value=!1),onSuccess:o})):Rt("",!0)]))}}),Nn=new Ns;let mi=null,We=null;function ny(t,i){mi&&va(),mi=Yl(mm),mi.provide("plugin",i),mi.provide("sandboxBridge",Nn);const e=mi.mount(t);return We=e,e}function va(t){mi&&(mi.unmount(),mi=null,We=null)}let gi=null,_e=null;function oy(t,i){gi&&ba(),gi=Yl(iy),gi.provide("plugin",i),gi.provide("sandboxBridge",Nn);const e=gi.mount(t);return _e=e,e}function ba(t){gi&&(gi.unmount(),gi=null,_e=null)}function sy(t,i){_e!=null&&_e.updateDocument&&_e.updateDocument(t),We!=null&&We.updateDocument?We.updateDocument(t,i):Nn.updateSlides(t.slides,t.config,t.fullMarkdown)}function ms(t){We!=null&&We.navigateToBlock?We.navigateToBlock(t):Nn.highlightElement(t)}function io(t){_e!=null&&_e.setActiveBlock&&_e.setActiveBlock(t)}function ry(){return _e!=null&&_e.openImportDialog?(_e.openImportDialog(),!0):!1}function ly(t,i){const e=[];let o=0;for(let s=0;s<t.length;s++){const l=t[s];if(yo(l)){o=0;continue}const r=l.markdown||l.content||"";if(!(s===0)){if(l.type==="h"&&(l.subType==="h1"||r.startsWith("# "))){e.push({blockId:l.id,recommendedLayout:"cover",reason:"检测到一级核心章节标题，建议作为新幻灯片封面/大章"}),o=0;continue}if(l.type==="h"&&(l.subType==="h2"||r.startsWith("## "))){e.push({blockId:l.id,recommendedLayout:"default",reason:"检测到二级分论点标题，建议开启新页"}),o=0;continue}}if(o++,o>=6&&s<t.length-1){const c=t[s+1];yo(c)||(e.push({blockId:c.id,recommendedLayout:"default",reason:"当前页已达容量上限 (避免信息超载)，建议在此分页"}),o=0)}}return e}const ay=[{id:"slidev-cover",name:"幻灯片 - 封面页 (Cover)",open:!0,attrs:[{key:Bi,value:"true"},{key:mt,value:"cover"},{key:Qt,value:"fade"}]},{id:"slidev-two-cols",name:"幻灯片 - 双栏对比 (Two Columns)",open:!0,attrs:[{key:Bi,value:"true"},{key:mt,value:"two-cols"},{key:Qt,value:"slide-left"}]},{id:"slidev-fact",name:"幻灯片 - 大字报与核心指标 (Fact)",open:!0,attrs:[{key:Bi,value:"true"},{key:mt,value:"fact"},{key:Qt,value:"zoom"}]},{id:"slidev-intro",name:"幻灯片 - 章节导引与作者 (Intro)",open:!0,attrs:[{key:Bi,value:"true"},{key:mt,value:"intro"},{key:Qt,value:"slide-up"}]},{id:"slidev-quote",name:"幻灯片 - 金句与强调 (Quote)",open:!0,attrs:[{key:Bi,value:"true"},{key:mt,value:"quote"},{key:Qt,value:"fade"}]},{id:"slidev-elem-click",name:"元素 - 顺延逐步呈现 (v-click)",open:!0,attrs:[{key:jt,value:"+1"}]},{id:"slidev-elem-click-hide",name:"元素 - 隐藏直到激活 (v-click:hide)",open:!0,attrs:[{key:jt,value:"hide"}]},{id:"slidev-elem-slot-right",name:"元素 - 双栏右栏归属 (Slot: Right)",open:!0,attrs:[{key:At,value:"right"}]},{id:"slidev-shiki-lines",name:"代码 - 逐行聚光高亮 (Shiki)",open:!0,attrs:[{key:Ri,value:"1-3"}]}];class Jo{getPresetTemplates(){return ay}buildScanSlidevBlocksSql(i="custom-slidev-"){return`SELECT block_id, name, value FROM attributes WHERE name LIKE '${i}%' ORDER BY block_id ASC`}buildTransitionStatsSql(){return`SELECT value, count(1) as count FROM attributes WHERE name = '${Qt}' GROUP BY value ORDER BY count DESC`}async batchUpdateTransitions(i,e,n,o){const s=`SELECT block_id FROM attributes WHERE name = '${Qt}' AND value = '${i}'`,l=await n(s);let r=0;if(Array.isArray(l))for(const a of l){const c=a.block_id||a.blockId;c&&(await o(c,{[Qt]:e}),r++)}return{updatedCount:r}}async batchUpdateLayout(i,e,n,o){const s=`SELECT block_id FROM attributes WHERE name = 'custom-slidev-layout' AND value = '${i}'`,l=await n(s);let r=0;if(Array.isArray(l))for(const a of l){const c=a.block_id||a.blockId;c&&(await o(c,{"custom-slidev-layout":e}),r++)}return{updatedCount:r}}exportTemplatesJson(){const i=this.getPresetTemplates();return JSON.stringify({templates:i,counter:i.length},null,2)}formatTransitionSummary(i){return!i||i.length===0?"全库目前暂无已设置 Slidev 转场效果的块":`全库 Slidev 转场分布统计：${i.map(n=>`${n.value}: ${n.count} 个`).join("，")}`}}function cy(t){t.addCommand({langKey:"slidevPresentation",langText:"Slidev: 在文档下方开启分屏演示预览",hotkey:"⌥P",enabled:()=>!0,execute:()=>{t.openBottomPreviewTab()}}),t.addCommand({langKey:"slidevImport",langText:"Slidev: 导入 Slidev 演示文档 (.md / .zip)",hotkey:"⌥I",enabled:()=>!0,execute:()=>{ry()||ht.showMessage("请先在右侧栏打开「Slidev 演示配置」Dock 面板以呼起导入窗口")}}),t.addCommand({langKey:"slidevInitAttrs",langText:"Slidev: 初始化当前文档演示属性",hotkey:"",enabled:()=>!0,execute:async()=>{if(!t.currentDocId){const i=document.querySelector(".protyle-content[data-doc-id]");t.currentDocId=(i==null?void 0:i.getAttribute("data-doc-id"))||""}t.currentDocId&&(await Dt(t.currentDocId,{"custom-slidev-theme":"default","custom-slidev-aspect-ratio":"16/9","custom-slidev-default-transition":"slide-left"}),ht.showMessage("已为当前文档初始化 Slidev 演示属性"),t.compileCurrentDocument(t.currentDocId))}}),t.addCommand({langKey:"slidevAiSplit",langText:"Slidev AI: 智能大纲断页建议与自动分页",hotkey:"",enabled:()=>!0,execute:async()=>{if(!t.currentDocId){const s=document.querySelector(".protyle-content[data-doc-id]");t.currentDocId=(s==null?void 0:s.getAttribute("data-doc-id"))||""}if(!t.currentDocId){ht.showMessage("请先打开一篇思源笔记文档");return}const i=await no(t.currentDocId).catch(()=>[]);if(!i||i.length===0){ht.showMessage("当前文档无内容，无需断页");return}const e=i.map(s=>({id:s.id,type:s.type,subType:s.subType,content:s.content||"",markdown:s.markdown||""})),n=ly(e);if(n.length===0){ht.showMessage("AI 分析完毕：当前文档篇幅合理，暂无分页建议");return}ht.showMessage(`AI 分析完毕：发现 ${n.length} 处建议分页点，正在自动插入分页分割线...`);let o=0;for(const s of n)try{await Ii("markdown","---",void 0,s.blockId),await Dt(s.blockId,{"custom-slidev-layout":s.recommendedLayout}),o++}catch(l){console.warn("Failed to insert divider:",l)}ht.showMessage(`已成功在 ${o} 处插入分页线并重新编译`),t.compileCurrentDocument(t.currentDocId)}}),t.addCommand({langKey:"slidevAiNotes",langText:"Slidev AI: 自动为当前文档生成演讲者提词卡 (Notes)",hotkey:"",enabled:()=>!0,execute:async()=>{var a,c,u,m;if(!t.currentDocId){const g=document.querySelector(".protyle-content[data-doc-id]");t.currentDocId=(g==null?void 0:g.getAttribute("data-doc-id"))||""}if(!t.currentDocId){ht.showMessage("请先打开一篇思源笔记文档");return}ht.showMessage("正在调用思源 AI 提炼演讲者口播提词...");const i=await no(t.currentDocId).catch(()=>[]),e={startBlockId:t.currentDocId,blocks:i.map(g=>({id:g.id,type:g.type,content:g.content||"",rawMarkdown:g.markdown||""})),rawMarkdown:""},s=`> [!NOTE] 💡 演讲备注
${(await Ub(e,zr)).split(/\r?\n/).map(g=>`> ${g}`).join(`
`)}
{: custom-slidev-note="true"}`,l=await Xo("markdown",s,t.currentDocId).catch(()=>null),r=((u=(c=(a=l==null?void 0:l[0])==null?void 0:a.doOperations)==null?void 0:c[0])==null?void 0:u.id)||((m=l==null?void 0:l[0])==null?void 0:m.id);r&&(await Dt(r,{"custom-slidev-note":"true"}),Pt.setBlockAttrOverride(r,{"custom-slidev-note":"true"}),Pi(r,t.app)),ht.showMessage("已成功生成口播提词卡并插入为正文讲稿备注块"),t.compileCurrentDocument(t.currentDocId)}}),t.addCommand({langKey:"slidevBatchTransitions",langText:"Slidev 协同: 统计全库转场效果分布",hotkey:"",enabled:()=>!0,execute:async()=>{const i=new Jo,e=i.buildTransitionStatsSql(),n=await wn(e).catch(()=>[]),o=i.formatTransitionSummary(n||[]);ht.showMessage(o)}}),t.addCommand({langKey:"slidevExportTemplates",langText:"Slidev 协同: 复制 Slidev 预设属性模板至剪贴板",hotkey:"",enabled:()=>!0,execute:async()=>{const e=new Jo().exportTemplatesJson();typeof navigator<"u"&&navigator.clipboard?(await navigator.clipboard.writeText(e),ht.showMessage("已将 Slidev 属性模板 JSON 复制至剪贴板，可直接导入属性管家")):ht.showMessage(`已生成模板数据（请在控制台查看）：
`+e)}}),t.addCommand({langKey:"slidevBatchReplaceTransition",langText:"Slidev 协同: 批量替换全库淡入淡出转场为滑动 (fade -> slide-left)",hotkey:"",enabled:()=>!0,execute:async()=>{const e=await new Jo().batchUpdateTransitions("fade","slide-left",n=>wn(n).catch(()=>[]),(n,o)=>Dt(n,o));ht.showMessage(`全库批量替换完成：已将 ${e.updatedCount} 处 fade 转场更新为 slide-left`),t.compileCurrentDocument()}}),t.addCommand({langKey:"slidevPresenterMode",langText:"Slidev: 打开双屏演讲者控制台 (Presenter Mode)",hotkey:"⌥M",enabled:()=>!0,execute:()=>{typeof window<"u"&&window.open("/plugins/siyuan-slidev/slidev-client/presenter.html","SlidevPresenter","width=1200,height=800")}}),t.addCommand({langKey:"slidevExportCliMd",langText:"Slidev Pro: 导出 Slidev 标准 slides.md 文档 (下载到本地)",hotkey:"",enabled:()=>!0,execute:async()=>{if(t.latestCompiledDoc||await t.compileCurrentDocument(),!t.latestCompiledDoc){ht.showMessage("请先打开并放映一篇思源笔记文档");return}t.cliBridge.downloadSlidesMd(t.latestCompiledDoc,`slides-${t.currentDocId||"demo"}.md`)&&ht.showMessage("已生成标准 Slidev Markdown 并触发下载，可在本地使用 npx @slidev/cli 运行")}}),t.addCommand({langKey:"slidevProbeCliDevServer",langText:"Slidev Pro: 检测本地 Slidev CLI DevServer 状态 (localhost:3030)",hotkey:"",enabled:()=>!0,execute:async()=>{ht.showMessage("正在探测本地 Slidev CLI DevServer (http://localhost:3030)..."),await t.cliBridge.probeServer(1500)?ht.showMessage("🟢 本地 Slidev CLI DevServer 运行正常！可直接在浏览器访问 http://localhost:3030"):ht.showMessage("⚪ 未检测到运行中的本地 Slidev CLI DevServer (端口 3030 未开启)")}}),t.addCommand({langKey:"slidevSyncToCliWorkspace",langText:"Slidev Pro: 同步 slides.md 至思源工作空间存储目录",hotkey:"",enabled:()=>!0,execute:async()=>{if(t.latestCompiledDoc||await t.compileCurrentDocument(),!t.latestCompiledDoc){ht.showMessage("请先打开并放映一篇思源笔记文档");return}const i=await t.cliBridge.syncToWorkspaceFile(t.latestCompiledDoc,"/data/storage/petal/siyuan-slidev/slides.md",Qo);i.success?ht.showMessage(`已成功同步最新 slides.md 至工作空间：${i.path}`):ht.showMessage(`同步失败：${i.error}`)}})}class dy{getActiveDocumentId(){if(typeof document>"u")return"";const i=document.querySelector(".layout__wnd--active .protyle-title[data-node-id]")||document.querySelector(".item--focus .protyle-title[data-node-id]")||document.querySelector(".protyle-title[data-node-id]"),e=i==null?void 0:i.getAttribute("data-node-id");if(e)return e;const n=document.querySelector(".protyle .protyle-title[data-node-id]"),o=n==null?void 0:n.getAttribute("data-node-id");if(o)return o;const s=document.querySelector("[data-doc-id]"),l=s==null?void 0:s.getAttribute("data-doc-id");return l||""}resolveDocIdFromElement(i,e=""){const n=i.closest(".protyle-title"),o=n==null?void 0:n.getAttribute("data-node-id");if(o)return o;const s=i.closest(".protyle"),l=s==null?void 0:s.querySelector(".protyle-title"),r=l==null?void 0:l.getAttribute("data-node-id");if(r)return r;const a=i.closest("[data-doc-id]"),c=a==null?void 0:a.getAttribute("data-doc-id");if(c)return c;const u=this.getActiveDocumentId();return u||e}async switchToDocGlobalInspector(i,e){var s;if(!i)return;let n=e||"";if(!n&&typeof document<"u"){const l=document.querySelector(`.protyle-title[data-node-id="${i}"] .protyle-title__input`)||document.querySelector(`.protyle[data-doc-id="${i}"] .protyle-title__input`)||document.querySelector(".protyle-title__input");n=((s=l==null?void 0:l.innerText)==null?void 0:s.trim())||""}const o=await Ze(i).catch(()=>({}));io({id:i,rootId:i,type:"doc",content:n,attrs:o,isDivider:!1,isCode:!1}),ms(i)}handleBlockClickedFromSlide(i,e,n,o){var a;if(!i)return!1;const s=Pi(i,e),l=document.querySelector(`.protyle-wysiwyg [data-node-id="${i}"]`)||document.querySelector(`[data-node-id="${i}"]`),r=(l==null?void 0:l.getAttribute("data-type"))||"";if(l)this.syncInspectorBlock(l,i,r,n,o);else{let c="",u="";if(o!=null&&o.slides){const m=o.slides.find(g=>{var d,y,f;return g.startBlockId===i||((d=g.blocks)==null?void 0:d.some(v=>v.id===i))||((y=g.allBlockIds)==null?void 0:y.includes(i))||((f=g.noteBlocks)==null?void 0:f.some(v=>v.id===i))});m!=null&&m.startBlockId&&(c=m.startBlockId),(a=m==null?void 0:m.frontmatter)!=null&&a.layout&&(u=m.frontmatter.layout)}Ze(i).then(async m=>{if(c&&!u){const g=Pt.getBlockAttrOverride(c);if(g!=null&&g[mt]||g!=null&&g["custom-slidev-layout"])u=g[mt]||g["custom-slidev-layout"]||"";else{const d=await Ze(c).catch(()=>({}))||{};u=d[mt]||d["custom-slidev-layout"]||"",d&&Object.keys(d).length>0&&Pt.setBlockAttrOverride(c,d)}}io({id:i,rootId:n,type:r||"NodeParagraph",attrs:m||{},pageDividerId:c,pageDividerLayout:u})}).catch(()=>{})}return s}async syncInspectorBlock(i,e,n,o,s){var N,J,U,G,V,M,E,R;let l=i,r=e,a=n;const c=i.closest('[data-type="NodeCallout"]');if(c&&c!==i){const tt=c.getAttribute("data-node-id");if(tt){const Q=await Ze(tt).catch(()=>({}))||{},Y=Pt.getBlockAttrOverride(tt)||{},W={...Q,...Y};(W[ie]||W["slidev-note"])&&(l=c,r=tt,a="NodeCallout")}}const u=l.closest(".protyle-wysiwyg > [data-node-id]")||l,m=(u==null?void 0:u.getAttribute("data-node-id"))||r,g=a==="NodeThematicBreak"||a==="tb"||a==="thematic-break"||(u==null?void 0:u.getAttribute("data-type"))==="NodeThematicBreak"||(u==null?void 0:u.getAttribute("data-type"))==="tb"||!!((N=u==null?void 0:u.classList)!=null&&N.contains("hr")),d=a==="NodeCodeBlock",y=((J=l.innerText)==null?void 0:J.trim())||"",f=await Ze(r).catch(()=>({}))||{},v=Pt.getBlockAttrOverride(r)||{},k={...f,...v};let x="",S="";if(g)x=r,S=k[mt]||k["custom-slidev-layout"]||"";else{let tt=u.previousElementSibling;for(;tt;){const Q=tt.getAttribute("data-type");if(Q==="NodeThematicBreak"||Q==="tb"||(U=tt.classList)!=null&&U.contains("hr")){x=tt.getAttribute("data-node-id")||"";break}tt=tt.previousElementSibling}}if(s!=null&&s.slides){const tt=[r,m];let Q=l.parentElement;for(;Q&&!Q.classList.contains("protyle-wysiwyg");){const W=Q.getAttribute("data-node-id");W&&!tt.includes(W)&&tt.push(W),Q=Q.parentElement}const Y=s.slides.find(W=>{var ut,ct,X;return tt.includes(W.startBlockId)||((ut=W.blocks)==null?void 0:ut.some(dt=>tt.includes(dt.id)))||((ct=W.allBlockIds)==null?void 0:ct.some(dt=>tt.includes(dt)))||((X=W.noteBlocks)==null?void 0:X.some(dt=>tt.includes(dt.id)))});Y&&(!x&&Y.startBlockId&&(x=Y.startBlockId),!S&&((G=Y.frontmatter)!=null&&G.layout)&&(S=Y.frontmatter.layout))}if(x){const tt=Pt.getBlockAttrOverride(x);if(tt&&(mt in tt||"custom-slidev-layout"in tt)&&(S=tt[mt]||tt["custom-slidev-layout"]||""),!S&&(s!=null&&s.slides)){const Q=s.slides.find(Y=>Y.startBlockId===x);(V=Q==null?void 0:Q.frontmatter)!=null&&V.layout&&(S=Q.frontmatter.layout)}if(!S){const Q=await Ze(x).catch(()=>({}))||{};S=Q[mt]||Q["custom-slidev-layout"]||"",Q&&Object.keys(Q).length>0&&Pt.setBlockAttrOverride(x,Q)}ee(x,{[mt]:S||""})}else if(o){const tt=Pt.getBlockAttrOverride(o);tt&&(mt in tt||"custom-slidev-layout"in tt)?S=tt[mt]||tt["custom-slidev-layout"]||"":!S&&((R=(E=(M=s==null?void 0:s.slides)==null?void 0:M[0])==null?void 0:E.frontmatter)!=null&&R.layout)&&(S=s.slides[0].frontmatter.layout)}const B=l.getAttribute(mt)||l.getAttribute("custom-slidev-layout"),A=k[mt]||k["custom-slidev-layout"]||"";B&&B!==A&&ee(r,{[mt]:A});const I=l.getAttribute(Kt)||l.getAttribute("custom-slidev-role"),w=k[Kt]||k["custom-slidev-role"]||"";I&&I!==w&&ee(r,{[Kt]:w});let z="",O="",H="";const et=l.closest('[data-type="NodeListItem"]');if(et&&et!==l){const tt=et.getAttribute("data-node-id");if(tt){z=tt;const Q=await Ze(tt).catch(()=>({}))||{},Y=Pt.getBlockAttrOverride(tt)||{},W={...Q,...Y};O=W[At]||"",H=W[jt]||"";const ut=W[mt]||W["custom-slidev-layout"]||"",ct=et.getAttribute(mt)||et.getAttribute("custom-slidev-layout");ct&&ct!==ut&&ee(tt,{[mt]:ut});const X=W[Kt]||W["custom-slidev-role"]||"",dt=et.getAttribute(Kt)||et.getAttribute("custom-slidev-role");dt&&dt!==X&&ee(tt,{[Kt]:X})}}const _=!!l.querySelector("img, span[data-type='img']"),P=(l.innerText||"").replace(/[\r\n\t\s]+/g," ").trim(),b=_&&P.length<=50;io({id:r,rootId:o,type:a,content:y,attrs:k,isDivider:g,isCode:d,isImage:b,topBlockId:m,pageDividerId:x,pageDividerLayout:S,parentContainerId:z,parentContainerSlot:O,parentContainerClicks:H})}patchThematicBreakTransactions(i){if((i==null?void 0:i.cmd)==="transactions"&&Array.isArray(i.data)){for(const e of i.data)if(Array.isArray(e==null?void 0:e.doOperations)){for(const n of e.doOperations)if((n==null?void 0:n.action)==="updateAttrs"&&n.id&&n.data){const o=n.data.old||{},s=n.data.new||{},l={};for(const r of Object.keys(o))r in s||(l[r]="");for(const[r,a]of Object.entries(s))l[r]=String(a??"");ee(n.id,l),Pt.setBlockAttrOverride(n.id,l)}}}}purgeStaleDomSlidevAttrs(i){var o,s,l;if(typeof document>"u"||!i)return;const e=new Map;if(Array.isArray(i.slides))for(const r of i.slides){if(r.startBlockId){const a=e.get(r.startBlockId)||{};(o=r.frontmatter)!=null&&o.layout&&(a[mt]=r.frontmatter.layout),e.set(r.startBlockId,a)}if(Array.isArray(r.blocks)){for(const a of r.blocks)if(a.id){const c=e.get(a.id)||{};(s=a.ial)!=null&&s[mt]&&(c[mt]=a.ial[mt]),(l=a.ial)!=null&&l[Kt]&&(c[Kt]=a.ial[Kt]),Object.keys(c).length>0&&e.set(a.id,c)}}}const n=Pt.getAllAttrOverrides();for(const[r,a]of n.entries()){const c=e.get(r)||{};a[mt]!==void 0&&(c[mt]=a[mt]),a[Kt]!==void 0&&(c[Kt]=a[Kt]),e.set(r,c)}Sp(e)}}const $i=new dy,uy=`<symbol id="iconSlidev" viewBox="0 0 1024 1024">
  <path fill="currentColor" d="M128 160h768c35.3 0 64 28.7 64 64v480c0 35.3-28.7 64-64 64H128c-35.3 0-64-28.7-64-64V224c0-35.3 28.7-64 64-64z m64 64v480h640V224H192z m128 640h384v64H320z"/>
  <path fill="currentColor" d="M416 336l256 144-256 144z"/>
</symbol>`,fy="slidev-dock",Pr="slidev-preview-tab",Rr=Pu;class py extends ht.Plugin{constructor(){super(...arguments);xt(this,"isMobile",!1);xt(this,"currentDocId","");xt(this,"latestCompiledDoc",null);xt(this,"cliBridge",new Rs);xt(this,"debounceTimer",null);xt(this,"activeCursorBlockId","");xt(this,"onSwitchProtyleBound",this.onSwitchProtyle.bind(this));xt(this,"onWsMainBound",this.onWsMain.bind(this));xt(this,"onBlockClickedBound",this.onBlockClickedFromSlide.bind(this));xt(this,"onClickEditorTitleIconBound",this.onClickEditorTitleIcon.bind(this));xt(this,"onEditorClickBound",this.onEditorClick.bind(this));xt(this,"onSelectionChangeBound",this.onSelectionChange.bind(this));xt(this,"onClickEditorContentBound",this.onClickEditorContent.bind(this))}async onload(){const e=ht.getFrontend();this.isMobile=e==="mobile"||e==="browser-mobile",await this.loadGlobalSettings(),this.addIcons(uy),this.addTopBar({id:"slidev-topbar-play",icon:"iconSlidev",title:"Slidev 演示 (下方分屏)",position:"right",callback:()=>{this.openBottomPreviewTab()}}),cy(this);const n=this;if(this.addTab({type:Pr,init(){ny(this.element,n)},destroy(){va(this.element)}}),this.addDock({config:{position:"RightTop",size:{width:320,height:0},icon:"iconSlidev",title:"Slidev 演示配置"},data:{},type:fy,init(){oy(this.element,n)},destroy(){ba(this.element)}}),this.eventBus&&typeof this.eventBus.emit!="function"&&(this.eventBus.emit=(o,s)=>{try{typeof window<"u"&&window.dispatchEvent(new CustomEvent(`siyuan-event-${o}`,{detail:s}))}catch{}}),this.eventBus.on("switch-protyle",this.onSwitchProtyleBound),this.eventBus.on("ws-main",this.onWsMainBound),this.eventBus.on("slidev:request-compile",()=>this.compileCurrentDocument()),this.eventBus.on("slidev:block-clicked",this.onBlockClickedBound),this.eventBus.on("click-editortitleicon",this.onClickEditorTitleIconBound),this.eventBus.on("click-editorcontent",this.onClickEditorContentBound),typeof document<"u"&&(document.addEventListener("click",this.onEditorClickBound,!0),document.addEventListener("selectionchange",this.onSelectionChangeBound)),typeof document<"u"){const o=()=>{const s=this.getActiveDocumentId();s&&(s!==this.currentDocId&&(this.currentDocId=s),this.latestCompiledDoc||this.compileCurrentDocument(s))};setTimeout(o,300),setTimeout(o,1e3)}}async onDataChanged(e){await this.loadGlobalSettings(),this.currentDocId&&await this.compileCurrentDocument(this.currentDocId)}async loadGlobalSettings(){try{const e=await this.loadData(Rr),n=Ru(e);return Ei(n),n}catch{return Ei(tn),tn}}async saveGlobalSettings(e){const n=Do(),o=Ei({...n,...e||{}});try{await this.saveData(Rr,o)}catch(l){console.error("保存 Slidev 全局配置失败",l)}const s=this.currentDocId||this.getActiveDocumentId();return s&&await this.compileCurrentDocument(s),o}onunload(){this.debounceTimer&&(window.clearTimeout(this.debounceTimer),this.debounceTimer=null),this.eventBus.off("switch-protyle",this.onSwitchProtyleBound),this.eventBus.off("ws-main",this.onWsMainBound),this.eventBus.off("click-editortitleicon",this.onClickEditorTitleIconBound),this.eventBus.off("click-editorcontent",this.onClickEditorContentBound),typeof document<"u"&&(document.removeEventListener("click",this.onEditorClickBound,!0),document.removeEventListener("selectionchange",this.onSelectionChangeBound)),Nn.detach()}async openBottomPreviewTab(){this.currentDocId||(this.currentDocId=this.getActiveDocumentId()),await ht.openTab({app:this.app,custom:{id:this.name+Pr,title:"Slidev 演示预览",icon:"iconSlidev",data:{docId:this.currentDocId}},position:"bottom"}),this.currentDocId&&this.compileCurrentDocument(this.currentDocId)}onClickEditorTitleIcon(e){var l;const n=e.detail,o=n==null?void 0:n.menu,s=((l=n==null?void 0:n.data)==null?void 0:l.id)||this.currentDocId;!o||!s||o.addItem({icon:"iconSlidev",label:"Slidev 全局演示配置",submenu:[{label:"初始化演示属性 (custom-slidev-*)",click:async()=>{await Dt(s,{"custom-slidev-theme":"default","custom-slidev-aspect-ratio":"16/9","custom-slidev-default-transition":"slide-left"}),ht.showMessage("已为当前文档初始化 Slidev 演示属性"),this.compileCurrentDocument(s)}},{type:"separator"},{label:"主题: 默认 (default)",click:async()=>{await Dt(s,{"custom-slidev-theme":"default"}),ht.showMessage("已切换为 default 主题"),this.compileCurrentDocument(s)}},{label:"主题: 优雅衬线 (seriph)",click:async()=>{await Dt(s,{"custom-slidev-theme":"seriph"}),ht.showMessage("已切换为 seriph 主题"),this.compileCurrentDocument(s)}},{label:"主题: 苹果极简 (apple-basic)",click:async()=>{await Dt(s,{"custom-slidev-theme":"apple-basic"}),ht.showMessage("已切换为 apple-basic 主题"),this.compileCurrentDocument(s)}},{type:"separator"},{label:"画幅: 16 / 9 (宽屏)",click:async()=>{await Dt(s,{"custom-slidev-aspect-ratio":"16/9"}),ht.showMessage("已切换画幅为 16/9"),this.compileCurrentDocument(s)}},{label:"画幅: 4 / 3 (标屏)",click:async()=>{await Dt(s,{"custom-slidev-aspect-ratio":"4/3"}),ht.showMessage("已切换画幅为 4/3"),this.compileCurrentDocument(s)}}]})}async onSwitchProtyle(e){var s,l;const n=(s=e.detail)==null?void 0:s.protyle,o=(l=n==null?void 0:n.block)==null?void 0:l.rootID;if(o&&o!==this.currentDocId){this.currentDocId=o,this.activeCursorBlockId=o;const r=await Ze(o).catch(()=>({}));io({id:o,rootId:o,type:"doc",attrs:r}),this.compileCurrentDocument(o)}}onClickEditorContent(e){var s,l;const n=e==null?void 0:e.detail;if(!n)return;const o=(l=(s=n.protyle)==null?void 0:s.block)==null?void 0:l.rootID;o&&(!this.currentDocId||this.currentDocId!==o)&&(this.currentDocId=o),n.event&&this.onEditorClick(n.event)}getActiveDocumentId(){return $i.getActiveDocumentId()}resolveDocIdFromElement(e){return $i.resolveDocIdFromElement(e,this.currentDocId)}async switchToDocGlobalInspector(e,n){e&&(this.activeCursorBlockId=e,this.currentDocId=e,await $i.switchToDocGlobalInspector(e,n))}onWsMain(e){const n=e.detail;n&&($i.patchThematicBreakTransactions(n),this.debounceTimer&&window.clearTimeout(this.debounceTimer),this.debounceTimer=window.setTimeout(()=>{this.compileCurrentDocument()},150))}handleBlockClickedFromSlide(e,n){return e?(this.activeCursorBlockId=e,$i.handleBlockClickedFromSlide(e,this.app,this.currentDocId,this.latestCompiledDoc)):!1}onBlockClickedFromSlide(e){const n=(e==null?void 0:e.detail)||e;n!=null&&n.blockId&&this.handleBlockClickedFromSlide(n.blockId,n.page)}onEditorClick(e){const n=e.target;if(!n)return;const o=n.closest(".protyle-title")||n.closest(".protyle-background");if(!!(o||n.closest(".protyle-content")&&!n.closest(".protyle-wysiwyg")&&!n.closest(".protyle-breadcrumb")&&!n.closest(".protyle-gutters"))){const u=this.resolveDocIdFromElement(n);if(u&&this.activeCursorBlockId!==u){const m=o||document.querySelector(`.protyle-title[data-node-id="${u}"]`)||document.querySelector(`.protyle[data-doc-id="${u}"] .protyle-title`),g=m==null?void 0:m.querySelector(".protyle-title__input"),d=((g==null?void 0:g.innerText)||(m==null?void 0:m.innerText)||"").trim();this.switchToDocGlobalInspector(u,d)}return}if(!n.closest(".protyle-wysiwyg"))return;const r=n.closest("[data-node-id]");if(!r)return;const a=r.getAttribute("data-node-id"),c=r.getAttribute("data-type")||"";a&&(this.currentDocId||(this.currentDocId=this.resolveDocIdFromElement(n)||""),this.currentDocId&&!this.latestCompiledDoc&&this.compileCurrentDocument(this.currentDocId),a!==this.activeCursorBlockId&&(this.activeCursorBlockId=a,ms(a)),this.syncInspectorBlock(r,a,c))}onSelectionChange(){if(typeof window>"u")return;const e=window.getSelection();if(!e||e.rangeCount===0)return;const n=e.anchorNode;if(!n)return;const o=n.nodeType===Node.ELEMENT_NODE?n:n.parentElement;if(!o)return;const s=o.closest(".protyle-title");if(!!(s||o.closest(".protyle-content")&&!o.closest(".protyle-wysiwyg"))){const u=this.resolveDocIdFromElement(o);if(u&&this.activeCursorBlockId!==u){const m=s||document.querySelector(`.protyle-title[data-node-id="${u}"]`)||document.querySelector(`.protyle[data-doc-id="${u}"] .protyle-title`),g=m==null?void 0:m.querySelector(".protyle-title__input"),d=((g==null?void 0:g.innerText)||(m==null?void 0:m.innerText)||"").trim();this.switchToDocGlobalInspector(u,d)}return}if(!o.closest(".protyle-wysiwyg"))return;const r=o.closest("[data-node-id]"),a=r==null?void 0:r.getAttribute("data-node-id"),c=(r==null?void 0:r.getAttribute("data-type"))||"";r&&a&&(this.currentDocId||(this.currentDocId=this.resolveDocIdFromElement(o)||""),this.currentDocId&&!this.latestCompiledDoc&&this.compileCurrentDocument(this.currentDocId),a!==this.activeCursorBlockId&&(this.activeCursorBlockId=a,ms(a)),this.syncInspectorBlock(r,a,c))}async syncInspectorBlock(e,n,o){await $i.syncInspectorBlock(e,n,o,this.currentDocId,this.latestCompiledDoc)}async compileCurrentDocument(e){let n=e||this.currentDocId;if(!n){const o=this.getActiveDocumentId();if(o)this.currentDocId=o,n=o;else return}try{const o=await Pt.compile(n);this.latestCompiledDoc=o,sy(o,n),this.purgeStaleDomSlidevAttrs(o)}catch(o){console.error("[SiYuanSlidev] Failed to compile document:",o)}}purgeStaleDomSlidevAttrs(e){$i.purgeStaleDomSlidevAttrs(e)}}module.exports=py;
