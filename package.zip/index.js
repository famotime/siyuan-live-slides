"use strict";var kc=Object.create;var Ho=Object.defineProperty;var wc=Object.getOwnPropertyDescriptor;var xc=Object.getOwnPropertyNames;var Sc=Object.getPrototypeOf,_c=Object.prototype.hasOwnProperty;var Cc=(e,t,i)=>t in e?Ho(e,t,{enumerable:!0,configurable:!0,writable:!0,value:i}):e[t]=i;var $c=(e,t,i,n)=>{if(t&&typeof t=="object"||typeof t=="function")for(let o of xc(t))!_c.call(e,o)&&o!==i&&Ho(e,o,{get:()=>t[o],enumerable:!(n=wc(t,o))||n.enumerable});return e};var Vn=(e,t,i)=>(i=e!=null?kc(Sc(e)):{},$c(t||!e||!e.__esModule?Ho(i,"default",{value:e,enumerable:!0}):i,e));var ke=(e,t,i)=>Cc(e,typeof t!="symbol"?t+"":t,i);const he=require("siyuan");async function gt(e,t){const i=await he.fetchSyncPost(e,t);return i.code===0?i.data:null}async function Ic(){return gt("/api/notebook/lsNotebooks","")}async function Ec(e,t,i){return gt("/api/filetree/createDocWithMd",{notebook:e,path:t,markdown:i})}async function Yr(e,t){const i=new FormData;i.append("assetsDirPath",e);for(const o of t)i.append("file[]",o);return gt("/api/asset/upload",i)}async function Ai(e,t,i,n,o){return gt("/api/block/insertBlock",{dataType:e,data:t,nextID:i,previousID:n,parentID:o})}async function ss(e,t,i){return gt("/api/block/appendBlock",{dataType:e,data:t,parentID:i})}async function nr(e,t,i){return gt("/api/block/updateBlock",{dataType:e,data:t,id:i})}async function or(e){return gt("/api/block/deleteBlock",{id:e})}async function Tc(e){return gt("/api/block/getBlockKramdown",{id:e})}async function co(e){return gt("/api/block/getChildBlocks",{id:e})}async function Ac(e){return gt("/api/block/getDocBlocksOrders",{id:e})}async function De(e,t){return gt("/api/attr/setBlockAttrs",{id:e,attrs:t})}async function Cs(e){return gt("/api/attr/getBlockAttrs",{id:e})}async function en(e){return gt("/api/query/sql",{stmt:e})}async function rs(e,t,i){const n=new FormData;return n.append("path",e),n.append("isDir",t.toString()),n.append("modTime",Math.floor(Date.now()/1e3).toString()),n.append("file",i),gt("/api/file/putFile",n)}async function Jr(e){const t="/api/ai/chatGPT";try{const i=await gt(t,{msg:e});return typeof i=="string"&&i.trim().length>0?i.trim():i&&typeof i.content=="string"&&i.content.trim().length>0?i.content.trim():null}catch{return null}}async function Bc(){return gt("/api/storage/getInlineStyles","")}const Xr=/\(\(([0-9a-zA-Z-]+)(?:\s*(?:'([^']*)'|"([^"]*)"|([^\)]+?)))?\s*\)\)/g;function Mc(e){const t=[];if(!e)return t;const i=new RegExp(Xr.source,"g");let n;for(;(n=i.exec(e))!==null;){const o=n[2]??n[3]??n[4];t.push({fullMatch:n[0],blockId:n[1],anchorText:o?o.trim():void 0})}return t}function Dc(e,t){if(!e)return"";const i=new RegExp(Xr.source,"g");return e.replace(i,(n,o,s,l,r)=>{const a=(s??l??r??"").trim();if(t&&t[o]){const d=t[o].trim();return`<div class="slidev-block-ref" data-ref-id="${o}">${d}</div>`}const c=a||`Ref(${o.slice(0,8)})`;return`<a href="siyuan://blocks/${o}" data-ref-id="${o}" class="slidev-ref-tag">🔗 ${c}</a>`})}const Cn="custom-slidev-theme",$n="custom-slidev-aspect-ratio",Qr="custom-slidev-highlighter",In="custom-slidev-default-transition",el="custom-slidev-color-schema",ls="custom-slidev-spacing",Mi="custom-slidev-slide",ge="custom-slidev-layout",tt="custom-slidev-transition",Ue="custom-slidev-background",Bt="custom-slidev-image",qi="custom-slidev-notes",Gi="custom-slidev-class",gn="custom-slidev-spacing",lt="custom-slidev-layout-ratio",vi="custom-slidev-mask",bi="custom-slidev-mask-ratio",yi="custom-slidev-mask-style",ki="custom-slidev-mask-initial",We="custom-slidev-click",Vt="custom-slidev-motion",zi="custom-slidev-shiki-lines",Ee="custom-slidev-slot",nt="custom-slidev-note",Ge="custom-slidev-role",En="custom-slidev-max-height",Di="custom-slidev-autoplay",uo="custom-slidev-loop",Ki="custom-slidev-muted",fo="custom-slidev-controls",tl="background",po="image-left",ho="image-right";function Tn(e){return e==="cols-header"||e==="two-cols-header"||e==="three-cols-header"}function Lc(e){return e.markdown&&e.markdown.trim()?e.markdown.trim():e.content&&e.content.trim()?e.content.trim():""}function Oc(e){const t={};if(!e)return t;const i=e.replace(/^\{:\s*/,"").replace(/\s*\}$/,""),n=/([\w-]+)=(?:"([^"]*)"|'([^']*)'|(\S+))/g;let o;for(;(o=n.exec(i))!==null;){const s=o[1],l=o[2]??o[3]??o[4]??"";t[s]=l}return t}function il(e){if(!e)return!1;const t=e.trim();return t.startsWith("assets/")||t.startsWith("./assets/")||t.startsWith("/assets/")}function nl(e){const t=e.trim();return t.startsWith("./assets/")?t.slice(2):t.startsWith("/assets/")?t.slice(1):t}function Et(e,t){if(!il(e))return e;const i=nl(e);return t!=null&&t.base64Map&&t.base64Map[i]?t.base64Map[i]:t!=null&&t.baseUrl?`${t.baseUrl.replace(/\/+$/,"")}/${i}`:`/${i}`}function Rc(e,t){if(!e)return"";let i=e;return i=i.replace(/!\[(.*?)\]\(((?:\.\/|\/)?assets\/[^\s)]+)\)/g,(n,o,s)=>{const l=Et(s,t);return`![${o}](${l})`}),i=i.replace(/(<(?:img|video|audio|source)\b[^>]*?\bsrc=["'])((?:\.\/|\/)?assets\/[^"']+)(["'][^>]*>)/gi,(n,o,s,l)=>{const r=Et(s,t);return`${o}${r}${l}`}),i=i.replace(/(url\(\s*["']?)((?:\.\/|\/)?assets\/[^"')]+)(["']?\s*\))/gi,(n,o,s,l)=>{const r=Et(s,t);return`${o}${r}${l}`}),i}/**
* @vue/shared v3.5.40
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/function $s(e){const t=Object.create(null);for(const i of e.split(","))t[i]=1;return i=>i in t}const Ve={},Zi=[],Kt=()=>{},ol=()=>!1,Co=e=>e.charCodeAt(0)===111&&e.charCodeAt(1)===110&&(e.charCodeAt(2)>122||e.charCodeAt(2)<97),$o=e=>e.startsWith("onUpdate:"),ut=Object.assign,Is=(e,t)=>{const i=e.indexOf(t);i>-1&&e.splice(i,1)},Pc=Object.prototype.hasOwnProperty,Ne=(e,t)=>Pc.call(e,t),Te=Array.isArray,Yi=e=>Nn(e)==="[object Map]",rn=e=>Nn(e)==="[object Set]",sr=e=>Nn(e)==="[object Date]",Ae=e=>typeof e=="function",it=e=>typeof e=="string",Rt=e=>typeof e=="symbol",He=e=>e!==null&&typeof e=="object",sl=e=>(He(e)||Ae(e))&&Ae(e.then)&&Ae(e.catch),rl=Object.prototype.toString,Nn=e=>rl.call(e),Nc=e=>Nn(e).slice(8,-1),ll=e=>Nn(e)==="[object Object]",Es=e=>it(e)&&e!=="NaN"&&e[0]!=="-"&&""+parseInt(e,10)===e,vn=$s(",key,ref,ref_for,ref_key,onVnodeBeforeMount,onVnodeMounted,onVnodeBeforeUpdate,onVnodeUpdated,onVnodeBeforeUnmount,onVnodeUnmounted"),Io=e=>{const t=Object.create(null);return(i=>t[i]||(t[i]=e(i)))},zc=/-\w/g,wt=Io(e=>e.replace(zc,t=>t.slice(1).toUpperCase())),Fc=/\B([A-Z])/g,xi=Io(e=>e.replace(Fc,"-$1").toLowerCase()),Eo=Io(e=>e.charAt(0).toUpperCase()+e.slice(1)),jo=Io(e=>e?`on${Eo(e)}`:""),Ut=(e,t)=>!Object.is(e,t),eo=(e,...t)=>{for(let i=0;i<e.length;i++)e[i](...t)},al=(e,t,i,n=!1)=>{Object.defineProperty(e,t,{configurable:!0,enumerable:!1,writable:n,value:i})},To=e=>{const t=parseFloat(e);return isNaN(t)?e:t};let rr;const Ao=()=>rr||(rr=typeof globalThis<"u"?globalThis:typeof self<"u"?self:typeof window<"u"?window:typeof global<"u"?global:{});function An(e){if(Te(e)){const t={};for(let i=0;i<e.length;i++){const n=e[i],o=it(n)?Uc(n):An(n);if(o)for(const s in o)t[s]=o[s]}return t}else if(it(e)||He(e))return e}const Hc=/;(?![^(]*\))/g,jc=/:([^]+)/,Wc=/\/\*[^]*?\*\//g;function Uc(e){const t={};return e.replace(Wc,"").split(Hc).forEach(i=>{if(i){const n=i.split(jc);n.length>1&&(t[n[0].trim()]=n[1].trim())}}),t}function Ie(e){let t="";if(it(e))t=e;else if(Te(e))for(let i=0;i<e.length;i++){const n=Ie(e[i]);n&&(t+=n+" ")}else if(He(e))for(const i in e)e[i]&&(t+=i+" ");return t.trim()}const Vc="itemscope,allowfullscreen,formnovalidate,ismap,nomodule,novalidate,readonly",Kc=$s(Vc);function cl(e){return!!e||e===""}function qc(e,t){if(e.length!==t.length)return!1;let i=!0;for(let n=0;i&&n<e.length;n++)i=ln(e[n],t[n]);return i}function ln(e,t){if(e===t)return!0;let i=sr(e),n=sr(t);if(i||n)return i&&n?e.getTime()===t.getTime():!1;if(i=Rt(e),n=Rt(t),i||n)return e===t;if(i=Te(e),n=Te(t),i||n)return i&&n?qc(e,t):!1;if(i=He(e),n=He(t),i||n){if(!i||!n)return!1;const o=Object.keys(e).length,s=Object.keys(t).length;if(o!==s)return!1;for(const l in e){const r=e.hasOwnProperty(l),a=t.hasOwnProperty(l);if(r&&!a||!r&&a||!ln(e[l],t[l]))return!1}}return String(e)===String(t)}function Ts(e,t){return e.findIndex(i=>ln(i,t))}const dl=e=>!!(e&&e.__v_isRef===!0),Se=e=>it(e)?e:e==null?"":Te(e)||He(e)&&(e.toString===rl||!Ae(e.toString))?dl(e)?Se(e.value):JSON.stringify(e,ul,2):String(e),ul=(e,t)=>dl(t)?ul(e,t.value):Yi(t)?{[`Map(${t.size})`]:[...t.entries()].reduce((i,[n,o],s)=>(i[Wo(n,s)+" =>"]=o,i),{})}:rn(t)?{[`Set(${t.size})`]:[...t.values()].map(i=>Wo(i))}:Rt(t)?Wo(t):He(t)&&!Te(t)&&!ll(t)?String(t):t,Wo=(e,t="")=>{var i;return Rt(e)?`Symbol(${(i=e.description)!=null?i:t})`:e};/**
* @vue/reactivity v3.5.40
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/let at;class Gc{constructor(t=!1){this.detached=t,this._active=!0,this._on=0,this.effects=[],this.cleanups=[],this._isPaused=!1,this._warnOnRun=!0,this.__v_skip=!0,!t&&at&&(at.active?(this.parent=at,this.index=(at.scopes||(at.scopes=[])).push(this)-1):(this._active=!1,this._warnOnRun=!1))}get active(){return this._active}pause(){if(this._active){this._isPaused=!0;let t,i;if(this.scopes){const n=this.scopes.slice();for(t=0,i=n.length;t<i;t++)n[t].pause()}for(t=0,i=this.effects.length;t<i;t++)this.effects[t].pause()}}resume(){if(this._active&&this._isPaused){this._isPaused=!1;let t,i;if(this.scopes){const o=this.scopes.slice();for(t=0,i=o.length;t<i;t++)o[t].resume()}const n=this.effects.slice();for(t=0,i=n.length;t<i;t++)n[t].resume()}}run(t){if(this._active){const i=at;try{return at=this,t()}finally{at=i}}}on(){++this._on===1&&(this.prevScope=at,at=this)}off(){if(this._on>0&&--this._on===0){if(at===this)at=this.prevScope;else{let t=at;for(;t;){if(t.prevScope===this){t.prevScope=this.prevScope;break}t=t.prevScope}}this.prevScope=void 0}}stop(t){if(this._active){this._active=!1;let i,n;for(i=0,n=this.effects.length;i<n;i++)this.effects[i].stop();for(this.effects.length=0,i=0,n=this.cleanups.length;i<n;i++)this.cleanups[i]();if(this.cleanups.length=0,this.scopes){const o=this.scopes.slice();for(i=0,n=o.length;i<n;i++)o[i].stop(!0);this.scopes.length=0}if(!this.detached&&this.parent&&!t){const o=this.parent.scopes.pop();o&&o!==this&&(this.parent.scopes[this.index]=o,o.index=this.index)}this.parent=void 0}}}function Zc(){return at}let qe;const Uo=new WeakSet;class fl{constructor(t){this.fn=t,this.deps=void 0,this.depsTail=void 0,this.flags=5,this.next=void 0,this.cleanup=void 0,this.scheduler=void 0,at&&(at.active?at.effects.push(this):this.flags&=-2)}pause(){this.flags|=64}resume(){this.flags&64&&(this.flags&=-65,Uo.has(this)&&(Uo.delete(this),this.trigger()))}notify(){this.flags&2&&!(this.flags&32)||this.flags&8||hl(this)}run(){if(!(this.flags&1))return this.fn();this.flags|=2,lr(this),ml(this);const t=qe,i=Ot;qe=this,Ot=!0;try{return this.fn()}finally{gl(this),qe=t,Ot=i,this.flags&=-3}}stop(){if(this.flags&1){for(let t=this.deps;t;t=t.nextDep)Ms(t);this.deps=this.depsTail=void 0,lr(this),this.onStop&&this.onStop(),this.flags&=-2}}trigger(){this.flags&64?Uo.add(this):this.scheduler?this.scheduler():this.runIfDirty()}runIfDirty(){as(this)&&this.run()}get dirty(){return as(this)}}let pl=0,bn,yn;function hl(e,t=!1){if(e.flags|=8,t){e.next=yn,yn=e;return}e.next=bn,bn=e}function As(){pl++}function Bs(){if(--pl>0)return;if(yn){let t=yn;for(yn=void 0;t;){const i=t.next;t.next=void 0,t.flags&=-9,t=i}}let e;for(;bn;){let t=bn;for(bn=void 0;t;){const i=t.next;if(t.next=void 0,t.flags&=-9,t.flags&1)try{t.trigger()}catch(n){e||(e=n)}t=i}}if(e)throw e}function ml(e){for(let t=e.deps;t;t=t.nextDep)t.version=-1,t.prevActiveLink=t.dep.activeLink,t.dep.activeLink=t}function gl(e){let t,i=e.depsTail,n=i;for(;n;){const o=n.prevDep;n.version===-1?(n===i&&(i=o),Ms(n),Yc(n)):t=n,n.dep.activeLink=n.prevActiveLink,n.prevActiveLink=void 0,n=o}e.deps=t,e.depsTail=i}function as(e){for(let t=e.deps;t;t=t.nextDep)if(t.dep.version!==t.version||t.dep.computed&&(vl(t.dep.computed)||t.dep.version!==t.version))return!0;return!!e._dirty}function vl(e){if(e.flags&4&&!(e.flags&16)||(e.flags&=-17,e.globalVersion===Bn)||(e.globalVersion=Bn,!e.isSSR&&e.flags&128&&(!e.deps&&!e._dirty||!as(e))))return;e.flags|=2;const t=e.dep,i=qe,n=Ot;qe=e,Ot=!0;try{ml(e);const o=e.fn(e._value);(t.version===0||Ut(o,e._value))&&(e.flags|=128,e._value=o,t.version++)}catch(o){throw t.version++,o}finally{qe=i,Ot=n,gl(e),e.flags&=-3}}function Ms(e,t=!1){const{dep:i,prevSub:n,nextSub:o}=e;if(n&&(n.nextSub=o,e.prevSub=void 0),o&&(o.prevSub=n,e.nextSub=void 0),i.subs===e&&(i.subs=n,!n&&i.computed)){i.computed.flags&=-5;for(let s=i.computed.deps;s;s=s.nextDep)Ms(s,!0)}!t&&!--i.sc&&i.map&&i.map.delete(i.key)}function Yc(e){const{prevDep:t,nextDep:i}=e;t&&(t.nextDep=i,e.prevDep=void 0),i&&(i.prevDep=t,e.nextDep=void 0)}let Ot=!0;const bl=[];function ni(){bl.push(Ot),Ot=!1}function oi(){const e=bl.pop();Ot=e===void 0?!0:e}function lr(e){const{cleanup:t}=e;if(e.cleanup=void 0,t){const i=qe;qe=void 0;try{t()}finally{qe=i}}}let Bn=0;class Jc{constructor(t,i){this.sub=t,this.dep=i,this.version=i.version,this.nextDep=this.prevDep=this.nextSub=this.prevSub=this.prevActiveLink=void 0}}class Ds{constructor(t){this.computed=t,this.version=0,this.activeLink=void 0,this.subs=void 0,this.map=void 0,this.key=void 0,this.sc=0,this.__v_skip=!0}track(t){if(!qe||!Ot||qe===this.computed)return;let i=this.activeLink;if(i===void 0||i.sub!==qe)i=this.activeLink=new Jc(qe,this),qe.deps?(i.prevDep=qe.depsTail,qe.depsTail.nextDep=i,qe.depsTail=i):qe.deps=qe.depsTail=i,yl(i);else if(i.version===-1&&(i.version=this.version,i.nextDep)){const n=i.nextDep;n.prevDep=i.prevDep,i.prevDep&&(i.prevDep.nextDep=n),i.prevDep=qe.depsTail,i.nextDep=void 0,qe.depsTail.nextDep=i,qe.depsTail=i,qe.deps===i&&(qe.deps=n)}return i}trigger(t){this.version++,Bn++,this.notify(t)}notify(t){As();try{for(let i=this.subs;i;i=i.prevSub)i.sub.notify()&&i.sub.dep.notify()}finally{Bs()}}}function yl(e){if(e.dep.sc++,e.sub.flags&4){const t=e.dep.computed;if(t&&!e.dep.subs){t.flags|=20;for(let n=t.deps;n;n=n.nextDep)yl(n)}const i=e.dep.subs;i!==e&&(e.prevSub=i,i&&(i.nextSub=e)),e.dep.subs=e}}const cs=new WeakMap,Oi=Symbol(""),ds=Symbol(""),Mn=Symbol("");function ht(e,t,i){if(Ot&&qe){let n=cs.get(e);n||cs.set(e,n=new Map);let o=n.get(i);o||(n.set(i,o=new Ds),o.map=n,o.key=i),o.track()}}function Xt(e,t,i,n,o,s){const l=cs.get(e);if(!l){Bn++;return}const r=a=>{a&&a.trigger()};if(As(),t==="clear")l.forEach(r);else{const a=Te(e),c=a&&Es(i);if(a&&i==="length"){const d=Number(n);l.forEach((m,b)=>{(b==="length"||b===Mn||!Rt(b)&&b>=d)&&r(m)})}else switch((i!==void 0||l.has(void 0))&&r(l.get(i)),c&&r(l.get(Mn)),t){case"add":a?c&&r(l.get("length")):(r(l.get(Oi)),Yi(e)&&r(l.get(ds)));break;case"delete":a||(r(l.get(Oi)),Yi(e)&&r(l.get(ds)));break;case"set":Yi(e)&&r(l.get(Oi));break}}Bs()}function Ui(e){const t=Pe(e);return t===e?t:(ht(t,"iterate",Mn),At(e)?t:t.map(Pt))}function Bo(e){return ht(e=Pe(e),"iterate",Mn),e}function jt(e,t){return si(e)?tn(Ri(e)?Pt(t):t):Pt(t)}const Xc={__proto__:null,[Symbol.iterator](){return Vo(this,Symbol.iterator,e=>jt(this,e))},concat(...e){return Ui(this).concat(...e.map(t=>Te(t)?Ui(t):t))},entries(){return Vo(this,"entries",e=>(e[1]=jt(this,e[1]),e))},every(e,t){return Zt(this,"every",e,t,void 0,arguments)},filter(e,t){return Zt(this,"filter",e,t,i=>i.map(n=>jt(this,n)),arguments)},find(e,t){return Zt(this,"find",e,t,i=>jt(this,i),arguments)},findIndex(e,t){return Zt(this,"findIndex",e,t,void 0,arguments)},findLast(e,t){return Zt(this,"findLast",e,t,i=>jt(this,i),arguments)},findLastIndex(e,t){return Zt(this,"findLastIndex",e,t,void 0,arguments)},forEach(e,t){return Zt(this,"forEach",e,t,void 0,arguments)},includes(...e){return Ko(this,"includes",e)},indexOf(...e){return Ko(this,"indexOf",e)},join(e){return Ui(this).join(e)},lastIndexOf(...e){return Ko(this,"lastIndexOf",e)},map(e,t){return Zt(this,"map",e,t,void 0,arguments)},pop(){return un(this,"pop")},push(...e){return un(this,"push",e)},reduce(e,...t){return ar(this,"reduce",e,t)},reduceRight(e,...t){return ar(this,"reduceRight",e,t)},shift(){return un(this,"shift")},some(e,t){return Zt(this,"some",e,t,void 0,arguments)},splice(...e){return un(this,"splice",e)},toReversed(){return Ui(this).toReversed()},toSorted(e){return Ui(this).toSorted(e)},toSpliced(...e){return Ui(this).toSpliced(...e)},unshift(...e){return un(this,"unshift",e)},values(){return Vo(this,"values",e=>jt(this,e))}};function Vo(e,t,i){const n=Bo(e),o=n[t]();return n!==e&&!At(e)&&(o._next=o.next,o.next=()=>{const s=o._next();return s.done||(s.value=i(s.value)),s}),o}const Qc=Array.prototype;function Zt(e,t,i,n,o,s){const l=Bo(e),r=l!==e&&!At(e),a=l[t];if(a!==Qc[t]){const m=a.apply(e,s);return r?Pt(m):m}let c=i;l!==e&&(r?c=function(m,b){return i.call(this,jt(e,m),b,e)}:i.length>2&&(c=function(m,b){return i.call(this,m,b,e)}));const d=a.call(l,c,n);return r&&o?o(d):d}function ar(e,t,i,n){const o=Bo(e),s=o!==e&&!At(e);let l=i,r=!1;o!==e&&(s?(r=n.length===0,l=function(c,d,m){return r&&(r=!1,c=jt(e,c)),i.call(this,c,jt(e,d),m,e)}):i.length>3&&(l=function(c,d,m){return i.call(this,c,d,m,e)}));const a=o[t](l,...n);return r?jt(e,a):a}function Ko(e,t,i){const n=Pe(e);ht(n,"iterate",Mn);const o=n[t](...i);return(o===-1||o===!1)&&Rs(i[0])?(i[0]=Pe(i[0]),n[t](...i)):o}function un(e,t,i=[]){ni(),As();const n=Pe(e)[t].apply(e,i);return Bs(),oi(),n}const ed=$s("__proto__,__v_isRef,__isVue"),kl=new Set(Object.getOwnPropertyNames(Symbol).filter(e=>e!=="arguments"&&e!=="caller").map(e=>Symbol[e]).filter(Rt));function td(e){Rt(e)||(e=String(e));const t=Pe(this);return ht(t,"has",e),t.hasOwnProperty(e)}class wl{constructor(t=!1,i=!1){this._isReadonly=t,this._isShallow=i}get(t,i,n){if(i==="__v_skip")return t.__v_skip;const o=this._isReadonly,s=this._isShallow;if(i==="__v_isReactive")return!o;if(i==="__v_isReadonly")return o;if(i==="__v_isShallow")return s;if(i==="__v_raw")return n===(o?s?ud:Cl:s?_l:Sl).get(t)||Object.getPrototypeOf(t)===Object.getPrototypeOf(n)?t:void 0;const l=Te(t);if(!o){let a;if(l&&(a=Xc[i]))return a;if(i==="hasOwnProperty")return td}const r=Reflect.get(t,i,Qe(t)?t:n);if((Rt(i)?kl.has(i):ed(i))||(o||ht(t,"get",i),s))return r;if(Qe(r)){const a=l&&Es(i)?r:r.value;return o&&He(a)?fs(a):a}return He(r)?o?fs(r):Mo(r):r}}class xl extends wl{constructor(t=!1){super(!1,t)}set(t,i,n,o){let s=t[i];const l=Te(t)&&Es(i);if(!this._isShallow){const c=si(s);if(!At(n)&&!si(n)&&(s=Pe(s),n=Pe(n)),!l&&Qe(s)&&!Qe(n))return c||(s.value=n),!0}const r=l?Number(i)<t.length:Ne(t,i),a=Reflect.set(t,i,n,Qe(t)?t:o);return t===Pe(o)&&a&&(r?Ut(n,s)&&Xt(t,"set",i,n):Xt(t,"add",i,n)),a}deleteProperty(t,i){const n=Ne(t,i);t[i];const o=Reflect.deleteProperty(t,i);return o&&n&&Xt(t,"delete",i,void 0),o}has(t,i){const n=Reflect.has(t,i);return(!Rt(i)||!kl.has(i))&&ht(t,"has",i),n}ownKeys(t){return ht(t,"iterate",Te(t)?"length":Oi),Reflect.ownKeys(t)}}class id extends wl{constructor(t=!1){super(!0,t)}set(t,i){return!0}deleteProperty(t,i){return!0}}const nd=new xl,od=new id,sd=new xl(!0);const us=e=>e,Kn=e=>Reflect.getPrototypeOf(e);function rd(e,t,i){return function(...n){const o=this.__v_raw,s=Pe(o),l=Yi(s),r=e==="entries"||e===Symbol.iterator&&l,a=e==="keys"&&l,c=o[e](...n),d=i?us:t?tn:Pt;return!t&&ht(s,"iterate",a?ds:Oi),ut(Object.create(c),{next(){const{value:m,done:b}=c.next();return b?{value:m,done:b}:{value:r?[d(m[0]),d(m[1])]:d(m),done:b}}})}}function qn(e){return function(...t){return e==="delete"?!1:e==="clear"?void 0:this}}function ld(e,t){const i={get(o){const s=this.__v_raw,l=Pe(s),r=Pe(o);e||(Ut(o,r)&&ht(l,"get",o),ht(l,"get",r));const{has:a}=Kn(l),c=t?us:e?tn:Pt;if(a.call(l,o))return c(s.get(o));if(a.call(l,r))return c(s.get(r));s!==l&&s.get(o)},get size(){const o=this.__v_raw;return!e&&ht(Pe(o),"iterate",Oi),o.size},has(o){const s=this.__v_raw,l=Pe(s),r=Pe(o);return e||(Ut(o,r)&&ht(l,"has",o),ht(l,"has",r)),o===r?s.has(o):s.has(o)||s.has(r)},forEach(o,s){const l=this,r=l.__v_raw,a=Pe(r),c=t?us:e?tn:Pt;return!e&&ht(a,"iterate",Oi),r.forEach((d,m)=>o.call(s,c(d),c(m),l))}};return ut(i,e?{add:qn("add"),set:qn("set"),delete:qn("delete"),clear:qn("clear")}:{add(o){const s=Pe(this),l=Kn(s),r=Pe(o),a=!t&&!At(o)&&!si(o)?r:o;return l.has.call(s,a)||Ut(o,a)&&l.has.call(s,o)||Ut(r,a)&&l.has.call(s,r)||(s.add(a),Xt(s,"add",a,a)),this},set(o,s){!t&&!At(s)&&!si(s)&&(s=Pe(s));const l=Pe(this),{has:r,get:a}=Kn(l);let c=r.call(l,o);c||(o=Pe(o),c=r.call(l,o));const d=a.call(l,o);return l.set(o,s),c?Ut(s,d)&&Xt(l,"set",o,s):Xt(l,"add",o,s),this},delete(o){const s=Pe(this),{has:l,get:r}=Kn(s);let a=l.call(s,o);a||(o=Pe(o),a=l.call(s,o)),r&&r.call(s,o);const c=s.delete(o);return a&&Xt(s,"delete",o,void 0),c},clear(){const o=Pe(this),s=o.size!==0,l=o.clear();return s&&Xt(o,"clear",void 0,void 0),l}}),["keys","values","entries",Symbol.iterator].forEach(o=>{i[o]=rd(o,e,t)}),i}function Ls(e,t){const i=ld(e,t);return(n,o,s)=>o==="__v_isReactive"?!e:o==="__v_isReadonly"?e:o==="__v_raw"?n:Reflect.get(Ne(i,o)&&o in n?i:n,o,s)}const ad={get:Ls(!1,!1)},cd={get:Ls(!1,!0)},dd={get:Ls(!0,!1)};const Sl=new WeakMap,_l=new WeakMap,Cl=new WeakMap,ud=new WeakMap;function fd(e){switch(e){case"Object":case"Array":return 1;case"Map":case"Set":case"WeakMap":case"WeakSet":return 2;default:return 0}}function Mo(e){return si(e)?e:Os(e,!1,nd,ad,Sl)}function pd(e){return Os(e,!1,sd,cd,_l)}function fs(e){return Os(e,!0,od,dd,Cl)}function Os(e,t,i,n,o){if(!He(e)||e.__v_raw&&!(t&&e.__v_isReactive)||e.__v_skip||!Object.isExtensible(e))return e;const s=o.get(e);if(s)return s;const l=fd(Nc(e));if(l===0)return e;const r=new Proxy(e,l===2?n:i);return o.set(e,r),r}function Ri(e){return si(e)?Ri(e.__v_raw):!!(e&&e.__v_isReactive)}function si(e){return!!(e&&e.__v_isReadonly)}function At(e){return!!(e&&e.__v_isShallow)}function Rs(e){return e?!!e.__v_raw:!1}function Pe(e){const t=e&&e.__v_raw;return t?Pe(t):e}function hd(e){return!Ne(e,"__v_skip")&&Object.isExtensible(e)&&al(e,"__v_skip",!0),e}const Pt=e=>He(e)?Mo(e):e,tn=e=>He(e)?fs(e):e;function Qe(e){return e?e.__v_isRef===!0:!1}function ve(e){return md(e,!1)}function md(e,t){return Qe(e)?e:new gd(e,t)}class gd{constructor(t,i){this.dep=new Ds,this.__v_isRef=!0,this.__v_isShallow=!1,this._rawValue=i?t:Pe(t),this._value=i?t:Pt(t),this.__v_isShallow=i}get value(){return this.dep.track(),this._value}set value(t){const i=this._rawValue,n=this.__v_isShallow||At(t)||si(t);t=n?t:Pe(t),Ut(t,i)&&(this._rawValue=t,this._value=n?t:Pt(t),this.dep.trigger())}}function ye(e){return Qe(e)?e.value:e}const vd={get:(e,t,i)=>t==="__v_raw"?e:ye(Reflect.get(e,t,i)),set:(e,t,i,n)=>{const o=e[t];return Qe(o)&&!Qe(i)?(o.value=i,!0):Reflect.set(e,t,i,n)}};function $l(e){return Ri(e)?e:new Proxy(e,vd)}class bd{constructor(t,i,n){this.fn=t,this.setter=i,this._value=void 0,this.dep=new Ds(this),this.__v_isRef=!0,this.deps=void 0,this.depsTail=void 0,this.flags=16,this.globalVersion=Bn-1,this.next=void 0,this.effect=this,this.__v_isReadonly=!i,this.isSSR=n}notify(){if(this.flags|=16,!(this.flags&8)&&qe!==this)return hl(this,!0),!0}get value(){const t=this.dep.track();return vl(this),t&&(t.version=this.dep.version),this._value}set value(t){this.setter&&this.setter(t)}}function yd(e,t,i=!1){let n,o;return Ae(e)?n=e:(n=e.get,o=e.set),new bd(n,o,i)}const Gn={},mo=new WeakMap;let Bi;function kd(e,t=!1,i=Bi){if(i){let n=mo.get(i);n||mo.set(i,n=[]),n.push(e)}}function wd(e,t,i=Ve){const{immediate:n,deep:o,once:s,scheduler:l,augmentJob:r,call:a}=i,c=T=>o?T:At(T)||o===!1||o===0?Qt(T,1):Qt(T);let d,m,b,u,h=!1,f=!1;if(Qe(e)?(m=()=>e.value,h=At(e)):Ri(e)?(m=()=>c(e),h=!0):Te(e)?(f=!0,h=e.some(T=>Ri(T)||At(T)),m=()=>e.map(T=>{if(Qe(T))return T.value;if(Ri(T))return c(T);if(Ae(T))return a?a(T,2):T()})):Ae(e)?t?m=a?()=>a(e,2):e:m=()=>{if(b){ni();try{b()}finally{oi()}}const T=Bi;Bi=d;try{return a?a(e,3,[u]):e(u)}finally{Bi=T}}:m=Kt,t&&o){const T=m,D=o===!0?1/0:o;m=()=>Qt(T(),D)}const v=Zc(),k=()=>{d.stop(),v&&v.active&&Is(v.effects,d)};if(s&&t){const T=t;t=(...D)=>{const E=T(...D);return k(),E}}let S=f?new Array(e.length).fill(Gn):Gn;const $=T=>{if(!(!(d.flags&1)||!d.dirty&&!T))if(t){const D=d.run();if(T||o||h||(f?D.some((E,x)=>Ut(E,S[x])):Ut(D,S))){b&&b();const E=Bi;Bi=d;try{const x=[D,S===Gn?void 0:f&&S[0]===Gn?[]:S,u];S=D,a?a(t,3,x):t(...x)}finally{Bi=E}}}else d.run()};return r&&r($),d=new fl(m),d.scheduler=l?()=>l($,!1):$,u=T=>kd(T,!1,d),b=d.onStop=()=>{const T=mo.get(d);if(T){if(a)a(T,4);else for(const D of T)D();mo.delete(d)}},t?n?$(!0):S=d.run():l?l($.bind(null,!0),!0):d.run(),k.pause=d.pause.bind(d),k.resume=d.resume.bind(d),k.stop=k,k}function Qt(e,t=1/0,i){if(t<=0||!He(e)||e.__v_skip||(i=i||new Map,(i.get(e)||0)>=t))return e;if(i.set(e,t),t--,Qe(e))Qt(e.value,t,i);else if(Te(e))for(let n=0;n<e.length;n++)Qt(e[n],t,i);else if(rn(e)||Yi(e))e.forEach(n=>{Qt(n,t,i)});else if(ll(e)){for(const n in e)Qt(e[n],t,i);for(const n of Object.getOwnPropertySymbols(e))Object.prototype.propertyIsEnumerable.call(e,n)&&Qt(e[n],t,i)}return e}/**
* @vue/runtime-core v3.5.40
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/function zn(e,t,i,n){try{return n?e(...n):e()}catch(o){Do(o,t,i)}}function Nt(e,t,i,n){if(Ae(e)){const o=zn(e,t,i,n);return o&&sl(o)&&o.catch(s=>{Do(s,t,i)}),o}if(Te(e)){const o=[];for(let s=0;s<e.length;s++)o.push(Nt(e[s],t,i,n));return o}}function Do(e,t,i,n=!0){const o=t?t.vnode:null,{errorHandler:s,throwUnhandledErrorInProduction:l}=t&&t.appContext.config||Ve;if(t){let r=t.parent;const a=t.proxy,c=`https://vuejs.org/error-reference/#runtime-${i}`;for(;r;){const d=r.ec;if(d){for(let m=0;m<d.length;m++)if(d[m](e,a,c)===!1)return}r=r.parent}if(s){ni(),zn(s,null,10,[e,a,c]),oi();return}}xd(e,i,o,n,l)}function xd(e,t,i,n=!0,o=!1){if(o)throw e;console.error(e)}const yt=[];let Ht=-1;const Ji=[];let fi=null,Vi=0;const Il=Promise.resolve();let go=null;function El(e){const t=go||Il;return e?t.then(this?e.bind(this):e):t}function Sd(e){let t=Ht+1,i=yt.length;for(;t<i;){const n=t+i>>>1,o=yt[n],s=Dn(o);s<e||s===e&&o.flags&2?t=n+1:i=n}return t}function Ps(e){if(!(e.flags&1)){const t=Dn(e),i=yt[yt.length-1];!i||!(e.flags&2)&&t>=Dn(i)?yt.push(e):yt.splice(Sd(t),0,e),e.flags|=1,Tl()}}function Tl(){go||(go=Il.then(Bl))}function _d(e){Te(e)?Ji.push(...e):fi&&e.id===-1?fi.splice(Vi+1,0,e):e.flags&1||(Ji.push(e),e.flags|=1),Tl()}function cr(e,t,i=Ht+1){for(;i<yt.length;i++){const n=yt[i];if(n&&n.flags&2){if(e&&n.id!==e.uid)continue;yt.splice(i,1),i--,n.flags&4&&(n.flags&=-2),n(),n.flags&4||(n.flags&=-2)}}}function Al(e){if(Ji.length){const t=[...new Set(Ji)].sort((i,n)=>Dn(i)-Dn(n));if(Ji.length=0,fi){fi.push(...t);return}for(fi=t,Vi=0;Vi<fi.length;Vi++){const i=fi[Vi];i.flags&4&&(i.flags&=-2),i.flags&8||i(),i.flags&=-2}fi=null,Vi=0}}const Dn=e=>e.id==null?e.flags&2?-1:1/0:e.id;function Bl(e){try{for(Ht=0;Ht<yt.length;Ht++){const t=yt[Ht];t&&!(t.flags&8)&&(t.flags&4&&(t.flags&=-2),zn(t,t.i,t.i?15:14),t.flags&4||(t.flags&=-2))}}finally{for(;Ht<yt.length;Ht++){const t=yt[Ht];t&&(t.flags&=-2)}Ht=-1,yt.length=0,Al(),go=null,(yt.length||Ji.length)&&Bl()}}let dt=null,Ml=null;function vo(e){const t=dt;return dt=e,Ml=e&&e.type.__scopeId||null,t}function Dl(e,t=dt,i){if(!t||e._n)return e;const n=(...o)=>{n._d&&wr(-1);const s=vo(t),l=ti.length;let r;try{r=e(...o)}finally{for(let a=ti.length;a>l;a--)Ws();vo(s),n._d&&wr(1)}return r};return n._n=!0,n._c=!0,n._d=!0,n}function Tt(e,t){if(dt===null)return e;const i=Po(dt),n=e.dirs||(e.dirs=[]);for(let o=0;o<t.length;o++){let[s,l,r,a=Ve]=t[o];s&&(Ae(s)&&(s={mounted:s,updated:s}),s.deep&&Qt(l),n.push({dir:s,instance:i,value:l,oldValue:void 0,arg:r,modifiers:a}))}return e}function Ci(e,t,i,n){const o=e.dirs,s=t&&t.dirs;for(let l=0;l<o.length;l++){const r=o[l];s&&(r.oldValue=s[l].value);let a=r.dir[n];a&&(ni(),Nt(a,i,8,[e.el,r,e,t]),oi())}}function Cd(e,t){if(mt){let i=mt.provides;const n=mt.parent&&mt.parent.provides;n===i&&(i=mt.provides=Object.create(n)),i[e]=t}}function ei(e,t,i=!1){const n=Su();if(n||Qi){let o=Qi?Qi._context.provides:n?n.parent==null||n.ce?n.vnode.appContext&&n.vnode.appContext.provides:n.parent.provides:void 0;if(o&&e in o)return o[e];if(arguments.length>1)return i&&Ae(t)?t.call(n&&n.proxy):t}}const $d=Symbol.for("v-scx"),Id=()=>ei($d);function Pi(e,t,i){return Ll(e,t,i)}function Ll(e,t,i=Ve){const{immediate:n,deep:o,flush:s,once:l}=i,r=ut({},i),a=t&&n||!t&&s!=="post";let c;if(On){if(s==="sync"){const u=Id();c=u.__watcherHandles||(u.__watcherHandles=[])}else if(!a){const u=()=>{};return u.stop=Kt,u.resume=Kt,u.pause=Kt,u}}const d=mt;r.call=(u,h,f)=>Nt(u,d,h,f);let m=!1;s==="post"?r.scheduler=u=>{xt(u,d&&d.suspense)}:s!=="sync"&&(m=!0,r.scheduler=(u,h)=>{h?u():Ps(u)}),r.augmentJob=u=>{t&&(u.flags|=4),m&&(u.flags|=2,d&&(u.id=d.uid,u.i=d))};const b=wd(e,t,r);return On&&(c?c.push(b):a&&b()),b}function Ed(e,t,i){const n=this.proxy,o=it(e)?e.includes(".")?Ol(n,e):()=>n[e]:e.bind(n,n);let s;Ae(t)?s=t:(s=t.handler,i=t);const l=Hn(this),r=Ll(o,s.bind(n),i);return l(),r}function Ol(e,t){const i=t.split(".");return()=>{let n=e;for(let o=0;o<i.length&&n;o++)n=n[i[o]];return n}}const Td=Symbol("_vte"),Ad=e=>e.__isTeleport,qo=Symbol("_leaveCb");function Ns(e,t){e.shapeFlag&6&&e.component?(e.transition=t,Ns(e.component.subTree,t)):e.shapeFlag&128?(e.ssContent.transition=t.clone(e.ssContent),e.ssFallback.transition=t.clone(e.ssFallback)):e.transition=t}function Ct(e,t){return Ae(e)?ut({name:e.name},t,{setup:e}):e}function Rl(e){e.ids=[e.ids[0]+e.ids[2]+++"-",0,0]}function dr(e,t){let i;return!!((i=Object.getOwnPropertyDescriptor(e,t))&&!i.configurable)}const bo=new WeakMap;function kn(e,t,i,n,o=!1){if(Te(e)){e.forEach((f,v)=>kn(f,t&&(Te(t)?t[v]:t),i,n,o));return}if(Xi(n)&&!o){n.shapeFlag&512&&n.type.__asyncResolved&&n.component.subTree.component&&kn(e,t,i,n.component.subTree);return}const s=n.shapeFlag&4?Po(n.component):n.el,l=o?null:s,{i:r,r:a}=e,c=t&&t.r,d=r.refs===Ve?r.refs={}:r.refs,m=r.setupState,b=Pe(m),u=m===Ve?ol:f=>dr(d,f)?!1:Ne(b,f),h=(f,v)=>!(v&&dr(d,v));if(c!=null&&c!==a){if(ur(t),it(c))d[c]=null,u(c)&&(m[c]=null);else if(Qe(c)){const f=t;h(c,f.k)&&(c.value=null),f.k&&(d[f.k]=null)}}if(Ae(a))zn(a,r,12,[l,d]);else{const f=it(a),v=Qe(a);if(f||v){const k=()=>{if(e.f){const S=f?u(a)?m[a]:d[a]:h()||!e.k?a.value:d[e.k];if(o)Te(S)&&Is(S,s);else if(Te(S))S.includes(s)||S.push(s);else if(f)d[a]=[s],u(a)&&(m[a]=d[a]);else{const $=[s];h(a,e.k)&&(a.value=$),e.k&&(d[e.k]=$)}}else f?(d[a]=l,u(a)&&(m[a]=l)):v&&(h(a,e.k)&&(a.value=l),e.k&&(d[e.k]=l))};if(l){const S=()=>{k(),bo.delete(e)};S.id=-1,bo.set(e,S),xt(S,i)}else ur(e),k()}}}function ur(e){const t=bo.get(e);t&&(t.flags|=8,bo.delete(e))}Ao().requestIdleCallback;Ao().cancelIdleCallback;const Xi=e=>!!e.type.__asyncLoader,Pl=e=>e.type.__isKeepAlive;function Bd(e,t){Nl(e,"a",t)}function Md(e,t){Nl(e,"da",t)}function Nl(e,t,i=mt){const n=e.__wdc||(e.__wdc=()=>{let o=i;for(;o;){if(o.isDeactivated)return;o=o.parent}return e()});if(Lo(t,n,i),i){let o=i.parent;for(;o&&o.parent;)Pl(o.parent.vnode)&&Dd(n,t,i,o),o=o.parent}}function Dd(e,t,i,n){const o=Lo(t,e,n,!0);Fs(()=>{Is(n[t],o)},i)}function Lo(e,t,i=mt,n=!1){if(i){const o=i[e]||(i[e]=[]),s=t.__weh||(t.__weh=(...l)=>{ni();const r=Hn(i),a=Nt(t,i,e,l);return r(),oi(),a});return n?o.unshift(s):o.push(s),s}}const li=e=>(t,i=mt)=>{(!On||e==="sp")&&Lo(e,(...n)=>t(...n),i)},Ld=li("bm"),Fn=li("m"),Od=li("bu"),Rd=li("u"),zs=li("bum"),Fs=li("um"),Pd=li("sp"),Nd=li("rtg"),zd=li("rtc");function Fd(e,t=mt){Lo("ec",e,t)}const Hd="components";function jd(e,t){return Ud(Hd,e,!0,t)||e}const Wd=Symbol.for("v-ndc");function Ud(e,t,i=!0,n=!1){const o=dt||mt;if(o){const s=o.type;{const r=Eu(s,!1);if(r&&(r===t||r===wt(t)||r===Eo(wt(t))))return s}const l=fr(o[e]||s[e],t)||fr(o.appContext[e],t);return!l&&n?s:l}}function fr(e,t){return e&&(e[t]||e[wt(t)]||e[Eo(wt(t))])}function kt(e,t,i,n){let o;const s=i,l=Te(e);if(l||it(e)){const r=l&&Ri(e);let a=!1,c=!1;r&&(a=!At(e),c=si(e),e=Bo(e)),o=new Array(e.length);for(let d=0,m=e.length;d<m;d++)o[d]=t(a?c?tn(Pt(e[d])):Pt(e[d]):e[d],d,void 0,s)}else if(typeof e=="number"){o=new Array(e);for(let r=0;r<e;r++)o[r]=t(r+1,r,void 0,s)}else if(He(e))if(e[Symbol.iterator])o=Array.from(e,(r,a)=>t(r,a,void 0,s));else{const r=Object.keys(e);o=new Array(r.length);for(let a=0,c=r.length;a<c;a++){const d=r[a];o[a]=t(e[d],d,a,s)}}else o=[];return o}function Zn(e,t,i={},n,o,s){if(dt.ce||dt.parent&&Xi(dt.parent)&&dt.parent.ce){const c=i,d=Object.keys(c).length>0;return t!=="default"&&(c.name=t),oe(),Dt(Ke,null,[de("slot",c,n&&n())],d?-2:64)}let l=e[t];l&&l._c&&(l._d=!1);const r=ti.length;oe();let a;try{const c=l&&zl(l(i)),d=i.key||s||c&&c.key;a=Dt(Ke,{key:(d&&!Rt(d)?d:`_${t}`)+(!c&&n?"_fb":"")},c||(n?n():[]),c&&e._===1?64:-2)}catch(c){for(let d=ti.length;d>r;d--)Ws();throw c}finally{l&&l._c&&(l._d=!0)}return a}function zl(e){return e.some(t=>Us(t)?!(t.type===ri||t.type===Ke&&!zl(t.children)):!0)?e:null}const ps=e=>e?sa(e)?Po(e):ps(e.parent):null,wn=ut(Object.create(null),{$:e=>e,$el:e=>e.vnode.el,$data:e=>e.data,$props:e=>e.props,$attrs:e=>e.attrs,$slots:e=>e.slots,$refs:e=>e.refs,$parent:e=>ps(e.parent),$root:e=>ps(e.root),$host:e=>e.ce,$emit:e=>e.emit,$options:e=>Hl(e),$forceUpdate:e=>e.f||(e.f=()=>{Ps(e.update)}),$nextTick:e=>e.n||(e.n=El.bind(e.proxy)),$watch:e=>Ed.bind(e)}),Go=(e,t)=>e!==Ve&&!e.__isScriptSetup&&Ne(e,t),Vd={get({_:e},t){if(t==="__v_skip")return!0;const{ctx:i,setupState:n,data:o,props:s,accessCache:l,type:r,appContext:a}=e;if(t[0]!=="$"){const b=l[t];if(b!==void 0)switch(b){case 1:return n[t];case 2:return o[t];case 4:return i[t];case 3:return s[t]}else{if(Go(n,t))return l[t]=1,n[t];if(o!==Ve&&Ne(o,t))return l[t]=2,o[t];if(Ne(s,t))return l[t]=3,s[t];if(i!==Ve&&Ne(i,t))return l[t]=4,i[t];hs&&(l[t]=0)}}const c=wn[t];let d,m;if(c)return t==="$attrs"&&ht(e.attrs,"get",""),c(e);if((d=r.__cssModules)&&(d=d[t]))return d;if(i!==Ve&&Ne(i,t))return l[t]=4,i[t];if(m=a.config.globalProperties,Ne(m,t))return m[t]},set({_:e},t,i){const{data:n,setupState:o,ctx:s}=e;return Go(o,t)?(o[t]=i,!0):n!==Ve&&Ne(n,t)?(n[t]=i,!0):Ne(e.props,t)||t[0]==="$"&&t.slice(1)in e?!1:(s[t]=i,!0)},has({_:{data:e,setupState:t,accessCache:i,ctx:n,appContext:o,props:s,type:l}},r){let a;return!!(i[r]||e!==Ve&&r[0]!=="$"&&Ne(e,r)||Go(t,r)||Ne(s,r)||Ne(n,r)||Ne(wn,r)||Ne(o.config.globalProperties,r)||(a=l.__cssModules)&&a[r])},defineProperty(e,t,i){return i.get!=null?e._.accessCache[t]=0:Ne(i,"value")&&this.set(e,t,i.value,null),Reflect.defineProperty(e,t,i)}};function pr(e){return Te(e)?e.reduce((t,i)=>(t[i]=null,t),{}):e}let hs=!0;function Kd(e){const t=Hl(e),i=e.proxy,n=e.ctx;hs=!1,t.beforeCreate&&hr(t.beforeCreate,e,"bc");const{data:o,computed:s,methods:l,watch:r,provide:a,inject:c,created:d,beforeMount:m,mounted:b,beforeUpdate:u,updated:h,activated:f,deactivated:v,beforeDestroy:k,beforeUnmount:S,destroyed:$,unmounted:T,render:D,renderTracked:E,renderTriggered:x,errorCaptured:W,serverPrefetch:V,expose:G,inheritAttrs:X,components:C,directives:P,filters:y}=t;if(c&&qd(c,n,null),l)for(const B in l){const R=l[B];Ae(R)&&(n[B]=R.bind(i))}if(o){const B=o.call(i,i);He(B)&&(e.data=Mo(B))}if(hs=!0,s)for(const B in s){const R=s[B],F=Ae(R)?R.bind(i,i):Ae(R.get)?R.get.bind(i,i):Kt,ee=!Ae(R)&&Ae(R.set)?R.set.bind(i):Kt,I=_e({get:F,set:ee});Object.defineProperty(n,B,{enumerable:!0,configurable:!0,get:()=>I.value,set:M=>I.value=M})}if(r)for(const B in r)Fl(r[B],n,i,B);if(a){const B=Ae(a)?a.call(i):a;Reflect.ownKeys(B).forEach(R=>{Cd(R,B[R])})}d&&hr(d,e,"c");function U(B,R){Te(R)?R.forEach(F=>B(F.bind(i))):R&&B(R.bind(i))}if(U(Ld,m),U(Fn,b),U(Od,u),U(Rd,h),U(Bd,f),U(Md,v),U(Fd,W),U(zd,E),U(Nd,x),U(zs,S),U(Fs,T),U(Pd,V),Te(G))if(G.length){const B=e.exposed||(e.exposed={});G.forEach(R=>{Object.defineProperty(B,R,{get:()=>i[R],set:F=>i[R]=F,enumerable:!0})})}else e.exposed||(e.exposed={});D&&e.render===Kt&&(e.render=D),X!=null&&(e.inheritAttrs=X),C&&(e.components=C),P&&(e.directives=P),V&&Rl(e)}function qd(e,t,i=Kt){Te(e)&&(e=ms(e));for(const n in e){const o=e[n];let s;He(o)?"default"in o?s=ei(o.from||n,o.default,!0):s=ei(o.from||n):s=ei(o),Qe(s)?Object.defineProperty(t,n,{enumerable:!0,configurable:!0,get:()=>s.value,set:l=>s.value=l}):t[n]=s}}function hr(e,t,i){Nt(Te(e)?e.map(n=>n.bind(t.proxy)):e.bind(t.proxy),t,i)}function Fl(e,t,i,n){let o=n.includes(".")?Ol(i,n):()=>i[n];if(it(e)){const s=t[e];Ae(s)&&Pi(o,s)}else if(Ae(e))Pi(o,e.bind(i));else if(He(e))if(Te(e))e.forEach(s=>Fl(s,t,i,n));else{const s=Ae(e.handler)?e.handler.bind(i):t[e.handler];Ae(s)&&Pi(o,s,e)}}function Hl(e){const t=e.type,{mixins:i,extends:n}=t,{mixins:o,optionsCache:s,config:{optionMergeStrategies:l}}=e.appContext,r=s.get(t);let a;return r?a=r:!o.length&&!i&&!n?a=t:(a={},o.length&&o.forEach(c=>yo(a,c,l,!0)),yo(a,t,l)),He(t)&&s.set(t,a),a}function yo(e,t,i,n=!1){const{mixins:o,extends:s}=t;s&&yo(e,s,i,!0),o&&o.forEach(l=>yo(e,l,i,!0));for(const l in t)if(!(n&&l==="expose")){const r=Gd[l]||i&&i[l];e[l]=r?r(e[l],t[l]):t[l]}return e}const Gd={data:mr,props:gr,emits:gr,methods:hn,computed:hn,beforeCreate:bt,created:bt,beforeMount:bt,mounted:bt,beforeUpdate:bt,updated:bt,beforeDestroy:bt,beforeUnmount:bt,destroyed:bt,unmounted:bt,activated:bt,deactivated:bt,errorCaptured:bt,serverPrefetch:bt,components:hn,directives:hn,watch:Yd,provide:mr,inject:Zd};function mr(e,t){return t?e?function(){return ut(Ae(e)?e.call(this,this):e,Ae(t)?t.call(this,this):t)}:t:e}function Zd(e,t){return hn(ms(e),ms(t))}function ms(e){if(Te(e)){const t={};for(let i=0;i<e.length;i++)t[e[i]]=e[i];return t}return e}function bt(e,t){return e?[...new Set([].concat(e,t))]:t}function hn(e,t){return e?ut(Object.create(null),e,t):t}function gr(e,t){return e?Te(e)&&Te(t)?[...new Set([...e,...t])]:ut(Object.create(null),pr(e),pr(t??{})):t}function Yd(e,t){if(!e)return t;if(!t)return e;const i=ut(Object.create(null),e);for(const n in t)i[n]=bt(e[n],t[n]);return i}function jl(){return{app:null,config:{isNativeTag:ol,performance:!1,globalProperties:{},optionMergeStrategies:{},errorHandler:void 0,warnHandler:void 0,compilerOptions:{}},mixins:[],components:{},directives:{},provides:Object.create(null),optionsCache:new WeakMap,propsCache:new WeakMap,emitsCache:new WeakMap}}let Jd=0;function Xd(e,t){return function(n,o=null){Ae(n)||(n=ut({},n)),o!=null&&!He(o)&&(o=null);const s=jl(),l=new WeakSet,r=[];let a=!1;const c=s.app={_uid:Jd++,_component:n,_props:o,_container:null,_context:s,_instance:null,version:Au,get config(){return s.config},set config(d){},use(d,...m){return l.has(d)||(d&&Ae(d.install)?(l.add(d),d.install(c,...m)):Ae(d)&&(l.add(d),d(c,...m))),c},mixin(d){return s.mixins.includes(d)||s.mixins.push(d),c},component(d,m){return m?(s.components[d]=m,c):s.components[d]},directive(d,m){return m?(s.directives[d]=m,c):s.directives[d]},mount(d,m,b){if(!a){const u=c._ceVNode||de(n,o);return u.appContext=s,b===!0?b="svg":b===!1&&(b=void 0),e(u,d,b),a=!0,c._container=d,d.__vue_app__=c,Po(u.component)}},onUnmount(d){r.push(d)},unmount(){a&&(Nt(r,c._instance,16),e(null,c._container),delete c._container.__vue_app__)},provide(d,m){return s.provides[d]=m,c},runWithContext(d){const m=Qi;Qi=c;try{return d()}finally{Qi=m}}};return c}}let Qi=null;const Qd=(e,t)=>t==="modelValue"||t==="model-value"?e.modelModifiers:e[`${t}Modifiers`]||e[`${wt(t)}Modifiers`]||e[`${xi(t)}Modifiers`];function eu(e,t,...i){if(e.isUnmounted)return;const n=e.vnode.props||Ve;let o=i;const s=t.startsWith("update:"),l=s&&Qd(n,t.slice(7));l&&(l.trim&&(o=i.map(d=>it(d)?d.trim():d)),l.number&&(o=i.map(To)));let r,a=n[r=jo(t)]||n[r=jo(wt(t))];!a&&s&&(a=n[r=jo(xi(t))]),a&&Nt(a,e,6,o);const c=n[r+"Once"];if(c){if(!e.emitted)e.emitted={};else if(e.emitted[r])return;e.emitted[r]=!0,Nt(c,e,6,o)}}const tu=new WeakMap;function Wl(e,t,i=!1){const n=i?tu:t.emitsCache,o=n.get(e);if(o!==void 0)return o;const s=e.emits;let l={},r=!1;if(!Ae(e)){const a=c=>{const d=Wl(c,t,!0);d&&(r=!0,ut(l,d))};!i&&t.mixins.length&&t.mixins.forEach(a),e.extends&&a(e.extends),e.mixins&&e.mixins.forEach(a)}return!s&&!r?(He(e)&&n.set(e,null),null):(Te(s)?s.forEach(a=>l[a]=null):ut(l,s),He(e)&&n.set(e,l),l)}function Oo(e,t){return!e||!Co(t)?!1:(t=t.slice(2),t=t==="Once"?t:t.replace(/Once$/,""),Ne(e,t[0].toLowerCase()+t.slice(1))||Ne(e,xi(t))||Ne(e,t))}function vr(e){const{type:t,vnode:i,proxy:n,withProxy:o,propsOptions:[s],slots:l,attrs:r,emit:a,render:c,renderCache:d,props:m,data:b,setupState:u,ctx:h,inheritAttrs:f}=e,v=vo(e);let k,S;try{if(i.shapeFlag&4){const T=o||n,D=T;k=Wt(c.call(D,T,d,m,u,b,h)),S=r}else{const T=t;k=Wt(T.length>1?T(m,{attrs:r,slots:l,emit:a}):T(m,null)),S=t.props?r:iu(r)}}catch(T){ti.length=0,Do(T,e,1),k=de(ri)}let $=k;if(S&&f!==!1){const T=Object.keys(S),{shapeFlag:D}=$;T.length&&D&7&&(s&&T.some($o)&&(S=nu(S,s)),$=nn($,S,!1,!0))}return i.dirs&&($=nn($,null,!1,!0),$.dirs=$.dirs?$.dirs.concat(i.dirs):i.dirs),i.transition&&Ns($,i.transition),k=$,vo(v),k}const iu=e=>{let t;for(const i in e)(i==="class"||i==="style"||Co(i))&&((t||(t={}))[i]=e[i]);return t},nu=(e,t)=>{const i={};for(const n in e)(!$o(n)||!(n.slice(9)in t))&&(i[n]=e[n]);return i};function ou(e,t,i){const{props:n,children:o,component:s}=e,{props:l,children:r,patchFlag:a}=t,c=s.emitsOptions;if(t.dirs||t.transition)return!0;if(i&&a>=0){if(a&1024)return!0;if(a&16)return n?br(n,l,c):!!l;if(a&8){const d=t.dynamicProps;for(let m=0;m<d.length;m++){const b=d[m];if(Ul(l,n,b)&&!Oo(c,b))return!0}}}else return(o||r)&&(!r||!r.$stable)?!0:n===l?!1:n?l?br(n,l,c):!0:!!l;return!1}function br(e,t,i){const n=Object.keys(t);if(n.length!==Object.keys(e).length)return!0;for(let o=0;o<n.length;o++){const s=n[o];if(Ul(t,e,s)&&!Oo(i,s))return!0}return!1}function Ul(e,t,i){const n=e[i],o=t[i];return i==="style"&&He(n)&&He(o)?!ln(n,o):n!==o}function su({vnode:e,parent:t,suspense:i},n){for(;t;){const o=t.subTree;if(o.suspense&&o.suspense.activeBranch===e&&(o.suspense.vnode.el=o.el=n,e=o),o===e)(e=t.vnode).el=n,t=t.parent;else break}i&&i.activeBranch===e&&(i.vnode.el=n)}const Vl={},Kl=()=>Object.create(Vl),ql=e=>Object.getPrototypeOf(e)===Vl;function ru(e,t,i,n=!1){const o={},s=Kl();e.propsDefaults=Object.create(null),Gl(e,t,o,s);for(const l in e.propsOptions[0])l in o||(o[l]=void 0);i?e.props=n?o:pd(o):e.type.props?e.props=o:e.props=s,e.attrs=s}function lu(e,t,i,n){const{props:o,attrs:s,vnode:{patchFlag:l}}=e,r=Pe(o),[a]=e.propsOptions;let c=!1;if((n||l>0)&&!(l&16)){if(l&8){const d=e.vnode.dynamicProps;for(let m=0;m<d.length;m++){let b=d[m];if(Oo(e.emitsOptions,b))continue;const u=t[b];if(a)if(Ne(s,b))u!==s[b]&&(s[b]=u,c=!0);else{const h=wt(b);o[h]=gs(a,r,h,u,e,!1)}else u!==s[b]&&(s[b]=u,c=!0)}}}else{Gl(e,t,o,s)&&(c=!0);let d;for(const m in r)(!t||!Ne(t,m)&&((d=xi(m))===m||!Ne(t,d)))&&(a?i&&(i[m]!==void 0||i[d]!==void 0)&&(o[m]=gs(a,r,m,void 0,e,!0)):delete o[m]);if(s!==r)for(const m in s)(!t||!Ne(t,m))&&(delete s[m],c=!0)}c&&Xt(e.attrs,"set","")}function Gl(e,t,i,n){const[o,s]=e.propsOptions;let l=!1,r;if(t)for(let a in t){if(vn(a))continue;const c=t[a];let d;o&&Ne(o,d=wt(a))?!s||!s.includes(d)?i[d]=c:(r||(r={}))[d]=c:Oo(e.emitsOptions,a)||(!(a in n)||c!==n[a])&&(n[a]=c,l=!0)}if(s){const a=Pe(i),c=r||Ve;for(let d=0;d<s.length;d++){const m=s[d];i[m]=gs(o,a,m,c[m],e,!Ne(c,m))}}return l}function gs(e,t,i,n,o,s){const l=e[i];if(l!=null){const r=Ne(l,"default");if(r&&n===void 0){const a=l.default;if(l.type!==Function&&!l.skipFactory&&Ae(a)){const{propsDefaults:c}=o;if(i in c)n=c[i];else{const d=Hn(o);n=c[i]=a.call(null,t),d()}}else n=a;o.ce&&o.ce._setProp(i,n)}l[0]&&(s&&!r?n=!1:l[1]&&(n===""||n===xi(i))&&(n=!0))}return n}const au=new WeakMap;function Zl(e,t,i=!1){const n=i?au:t.propsCache,o=n.get(e);if(o)return o;const s=e.props,l={},r=[];let a=!1;if(!Ae(e)){const d=m=>{a=!0;const[b,u]=Zl(m,t,!0);ut(l,b),u&&r.push(...u)};!i&&t.mixins.length&&t.mixins.forEach(d),e.extends&&d(e.extends),e.mixins&&e.mixins.forEach(d)}if(!s&&!a)return He(e)&&n.set(e,Zi),Zi;if(Te(s))for(let d=0;d<s.length;d++){const m=wt(s[d]);yr(m)&&(l[m]=Ve)}else if(s)for(const d in s){const m=wt(d);if(yr(m)){const b=s[d],u=l[m]=Te(b)||Ae(b)?{type:b}:ut({},b),h=u.type;let f=!1,v=!0;if(Te(h))for(let k=0;k<h.length;++k){const S=h[k],$=Ae(S)&&S.name;if($==="Boolean"){f=!0;break}else $==="String"&&(v=!1)}else f=Ae(h)&&h.name==="Boolean";u[0]=f,u[1]=v,(f||Ne(u,"default"))&&r.push(m)}}const c=[l,r];return He(e)&&n.set(e,c),c}function yr(e){return e[0]!=="$"&&!vn(e)}const Hs=e=>e==="_"||e==="_ctx"||e==="$stable",js=e=>Te(e)?e.map(Wt):[Wt(e)],cu=(e,t,i)=>{if(t._n)return t;const n=Dl((...o)=>js(t(...o)),i);return n._c=!1,n},Yl=(e,t,i)=>{const n=e._ctx;for(const o in e){if(Hs(o))continue;const s=e[o];if(Ae(s))t[o]=cu(o,s,n);else if(s!=null){const l=js(s);t[o]=()=>l}}},Jl=(e,t)=>{const i=js(t);e.slots.default=()=>i},Xl=(e,t,i)=>{for(const n in t)(i||!Hs(n))&&(e[n]=t[n])},du=(e,t,i)=>{const n=e.slots=Kl();if(e.vnode.shapeFlag&32){const o=t._;o?(Xl(n,t,i),i&&al(n,"_",o,!0)):Yl(t,n)}else t&&Jl(e,t)},uu=(e,t,i)=>{const{vnode:n,slots:o}=e;let s=!0,l=Ve;if(n.shapeFlag&32){const r=t._;r?i&&r===1?s=!1:Xl(o,t,i):(s=!t.$stable,Yl(t,o)),l=t}else t&&(Jl(e,t),l={default:1});if(s)for(const r in o)!Hs(r)&&l[r]==null&&delete o[r]},xt=gu;function fu(e){return pu(e)}function pu(e,t){const i=Ao();i.__VUE__=!0;const{insert:n,remove:o,patchProp:s,createElement:l,createText:r,createComment:a,setText:c,setElementText:d,parentNode:m,nextSibling:b,setScopeId:u=Kt,insertStaticContent:h}=e,f=(L,H,g,j=null,z=null,_=null,w=void 0,A=null,q=!!H.dynamicChildren)=>{if(L===H)return;L&&!fn(L,H)&&(j=pe(L),M(L,z,_,!0),L=null),H.patchFlag===-2&&(q=!1,H.dynamicChildren=null);const{type:K,ref:Z,shapeFlag:ne}=H;switch(K){case Ro:v(L,H,g,j);break;case ri:k(L,H,g,j);break;case to:L==null&&S(H,g,j,w);break;case Ke:C(L,H,g,j,z,_,w,A,q);break;default:ne&1?D(L,H,g,j,z,_,w,A,q):ne&6?P(L,H,g,j,z,_,w,A,q):(ne&64||ne&128)&&K.process(L,H,g,j,z,_,w,A,q,ae)}Z!=null&&z?kn(Z,L&&L.ref,_,H||L,!H):Z==null&&L&&L.ref!=null&&kn(L.ref,null,_,L,!0)},v=(L,H,g,j)=>{if(L==null)n(H.el=r(H.children),g,j);else{const z=H.el=L.el;H.children!==L.children&&c(z,H.children)}},k=(L,H,g,j)=>{L==null?n(H.el=a(H.children||""),g,j):H.el=L.el},S=(L,H,g,j)=>{[L.el,L.anchor]=h(L.children,H,g,j,L.el,L.anchor)},$=({el:L,anchor:H},g,j)=>{let z;for(;L&&L!==H;)z=b(L),n(L,g,j),L=z;n(H,g,j)},T=({el:L,anchor:H})=>{let g;for(;L&&L!==H;)g=b(L),o(L),L=g;o(H)},D=(L,H,g,j,z,_,w,A,q)=>{if(H.type==="svg"?w="svg":H.type==="math"&&(w="mathml"),L==null)E(H,g,j,z,_,w,A,q);else{const K=L.el&&L.el._isVueCE?L.el:null;try{K&&K._beginPatch(),V(L,H,z,_,w,A,q)}finally{K&&K._endPatch()}}},E=(L,H,g,j,z,_,w,A)=>{let q,K;const{props:Z,shapeFlag:ne,transition:ce,dirs:re}=L;if(q=L.el=l(L.type,_,Z&&Z.is,Z),ne&8?d(q,L.children):ne&16&&W(L.children,q,null,j,z,Zo(L,_),w,A),re&&Ci(L,null,j,"created"),x(q,L,L.scopeId,w,j),Z){for(const $e in Z)$e!=="value"&&!vn($e)&&s(q,$e,null,Z[$e],_,j);"value"in Z&&s(q,"value",null,Z.value,_),(K=Z.onVnodeBeforeMount)&&Ft(K,j,L)}re&&Ci(L,null,j,"beforeMount");const me=hu(z,ce);me&&ce.beforeEnter(q),n(q,H,g),((K=Z&&Z.onVnodeMounted)||me||re)&&xt(()=>{try{K&&Ft(K,j,L),me&&ce.enter(q),re&&Ci(L,null,j,"mounted")}finally{}},z)},x=(L,H,g,j,z)=>{if(g&&u(L,g),j)for(let _=0;_<j.length;_++)u(L,j[_]);if(z){let _=z.subTree;if(H===_||ia(_.type)&&(_.ssContent===H||_.ssFallback===H)){const w=z.vnode;x(L,w,w.scopeId,w.slotScopeIds,z.parent)}}},W=(L,H,g,j,z,_,w,A,q=0)=>{for(let K=q;K<L.length;K++){const Z=L[K]=A?Jt(L[K]):Wt(L[K]);f(null,Z,H,g,j,z,_,w,A)}},V=(L,H,g,j,z,_,w)=>{const A=H.el=L.el;let{patchFlag:q,dynamicChildren:K,dirs:Z}=H;q|=L.patchFlag&16;const ne=L.props||Ve,ce=H.props||Ve;let re;if(g&&$i(g,!1),(re=ce.onVnodeBeforeUpdate)&&Ft(re,g,H,L),Z&&Ci(H,L,g,"beforeUpdate"),g&&$i(g,!0),K&&(!L.dynamicChildren||L.dynamicChildren.length!==K.length)&&(q=0,w=!1,K=null),(ne.innerHTML&&ce.innerHTML==null||ne.textContent&&ce.textContent==null)&&d(A,""),K?G(L.dynamicChildren,K,A,g,j,Zo(H,z),_):w||R(L,H,A,null,g,j,Zo(H,z),_,!1),q>0){if(q&16)X(A,ne,ce,g,z);else if(q&2&&ne.class!==ce.class&&s(A,"class",null,ce.class,z),q&4&&s(A,"style",ne.style,ce.style,z),q&8){const me=H.dynamicProps;for(let $e=0;$e<me.length;$e++){const xe=me[$e],Le=ne[xe],Ze=ce[xe];(Ze!==Le||xe==="value")&&s(A,xe,Le,Ze,z,g)}}q&1&&L.children!==H.children&&d(A,H.children)}else!w&&K==null&&X(A,ne,ce,g,z);((re=ce.onVnodeUpdated)||Z)&&xt(()=>{re&&Ft(re,g,H,L),Z&&Ci(H,L,g,"updated")},j)},G=(L,H,g,j,z,_,w)=>{for(let A=0;A<H.length;A++){const q=L[A],K=H[A],Z=q.el&&(q.type===Ke||!fn(q,K)||q.shapeFlag&198)?m(q.el):g;f(q,K,Z,null,j,z,_,w,!0)}},X=(L,H,g,j,z)=>{if(H!==g){if(H!==Ve)for(const _ in H)!vn(_)&&!(_ in g)&&s(L,_,H[_],null,z,j);for(const _ in g){if(vn(_))continue;const w=g[_],A=H[_];w!==A&&_!=="value"&&s(L,_,A,w,z,j)}"value"in g&&s(L,"value",H.value,g.value,z)}},C=(L,H,g,j,z,_,w,A,q)=>{const K=H.el=L?L.el:r(""),Z=H.anchor=L?L.anchor:r("");let{patchFlag:ne,dynamicChildren:ce,slotScopeIds:re}=H;re&&(A=A?A.concat(re):re),L==null?(n(K,g,j),n(Z,g,j),W(H.children||[],g,Z,z,_,w,A,q)):ne>0&&ne&64&&ce&&L.dynamicChildren&&L.dynamicChildren.length===ce.length?(G(L.dynamicChildren,ce,g,z,_,w,A),(H.key!=null||z&&H===z.subTree)&&Ql(L,H,!0)):R(L,H,g,Z,z,_,w,A,q)},P=(L,H,g,j,z,_,w,A,q)=>{H.slotScopeIds=A,L==null?H.shapeFlag&512?z.ctx.activate(H,g,j,w,q):y(H,g,j,z,_,w,q):O(L,H,q)},y=(L,H,g,j,z,_,w)=>{const A=L.component=xu(L,j,z);if(Pl(L)&&(A.ctx.renderer=ae),_u(A,!1,w),A.asyncDep){if(z&&z.registerDep(A,U,w),!L.el){const q=A.subTree=de(ri);k(null,q,H,g),L.placeholder=q.el}}else U(A,L,H,g,z,_,w)},O=(L,H,g)=>{const j=H.component=L.component;if(ou(L,H,g))if(j.asyncDep&&!j.asyncResolved){B(j,H,g);return}else j.next=H,j.update();else H.el=L.el,j.vnode=H},U=(L,H,g,j,z,_,w)=>{const A=()=>{if(L.isMounted){let{next:ne,bu:ce,u:re,parent:me,vnode:$e}=L;{const Xe=ea(L);if(Xe){ne&&(ne.el=$e.el,B(L,ne,w)),Xe.asyncDep.then(()=>{xt(()=>{L.isUnmounted||K()},z)});return}}let xe=ne,Le;$i(L,!1),ne?(ne.el=$e.el,B(L,ne,w)):ne=$e,ce&&eo(ce),(Le=ne.props&&ne.props.onVnodeBeforeUpdate)&&Ft(Le,me,ne,$e),$i(L,!0);const Ze=vr(L),je=L.subTree;L.subTree=Ze,f(je,Ze,m(je.el),pe(je),L,z,_),ne.el=Ze.el,xe===null&&su(L,Ze.el),re&&xt(re,z),(Le=ne.props&&ne.props.onVnodeUpdated)&&xt(()=>Ft(Le,me,ne,$e),z)}else{let ne;const{el:ce,props:re}=H,{bm:me,m:$e,parent:xe,root:Le,type:Ze}=L,je=Xi(H);$i(L,!1),me&&eo(me),!je&&(ne=re&&re.onVnodeBeforeMount)&&Ft(ne,xe,H),$i(L,!0);{Le.ce&&Le.ce._hasShadowRoot()&&Le.ce._injectChildStyle(Ze,L.parent?L.parent.type:void 0);const Xe=L.subTree=vr(L);f(null,Xe,g,j,L,z,_),H.el=Xe.el}if($e&&xt($e,z),!je&&(ne=re&&re.onVnodeMounted)){const Xe=H;xt(()=>Ft(ne,xe,Xe),z)}(H.shapeFlag&256||xe&&Xi(xe.vnode)&&xe.vnode.shapeFlag&256)&&L.a&&xt(L.a,z),L.isMounted=!0,H=g=j=null}};L.scope.on();const q=L.effect=new fl(A);L.scope.off();const K=L.update=q.run.bind(q),Z=L.job=q.runIfDirty.bind(q);Z.i=L,Z.id=L.uid,q.scheduler=()=>Ps(Z),$i(L,!0),K()},B=(L,H,g)=>{H.component=L;const j=L.vnode.props;L.vnode=H,L.next=null,lu(L,H.props,j,g),uu(L,H.children,g),ni(),cr(L),oi()},R=(L,H,g,j,z,_,w,A,q=!1)=>{const K=L&&L.children,Z=L?L.shapeFlag:0,ne=H.children,{patchFlag:ce,shapeFlag:re}=H;if(ce>0){if(ce&128){ee(K,ne,g,j,z,_,w,A,q);return}else if(ce&256){F(K,ne,g,j,z,_,w,A,q);return}}re&8?(Z&16&&ie(K,z,_),ne!==K&&d(g,ne)):Z&16?re&16?ee(K,ne,g,j,z,_,w,A,q):ie(K,z,_,!0):(Z&8&&d(g,""),re&16&&W(ne,g,j,z,_,w,A,q))},F=(L,H,g,j,z,_,w,A,q)=>{L=L||Zi,H=H||Zi;const K=L.length,Z=H.length,ne=Math.min(K,Z);let ce;for(ce=0;ce<ne;ce++){const re=H[ce]=q?Jt(H[ce]):Wt(H[ce]);f(L[ce],re,g,null,z,_,w,A,q)}K>Z?ie(L,z,_,!0,!1,ne):W(H,g,j,z,_,w,A,q,ne)},ee=(L,H,g,j,z,_,w,A,q)=>{let K=0;const Z=H.length;let ne=L.length-1,ce=Z-1;for(;K<=ne&&K<=ce;){const re=L[K],me=H[K]=q?Jt(H[K]):Wt(H[K]);if(fn(re,me))f(re,me,g,null,z,_,w,A,q);else break;K++}for(;K<=ne&&K<=ce;){const re=L[ne],me=H[ce]=q?Jt(H[ce]):Wt(H[ce]);if(fn(re,me))f(re,me,g,null,z,_,w,A,q);else break;ne--,ce--}if(K>ne){if(K<=ce){const re=ce+1,me=re<Z?H[re].el:j;for(;K<=ce;)f(null,H[K]=q?Jt(H[K]):Wt(H[K]),g,me,z,_,w,A,q),K++}}else if(K>ce)for(;K<=ne;)M(L[K],z,_,!0),K++;else{const re=K,me=K,$e=new Map;for(K=me;K<=ce;K++){const st=H[K]=q?Jt(H[K]):Wt(H[K]);st.key!=null&&$e.set(st.key,K)}let xe,Le=0;const Ze=ce-me+1;let je=!1,Xe=0;const ze=new Array(Ze);for(K=0;K<Ze;K++)ze[K]=0;for(K=re;K<=ne;K++){const st=L[K];if(Le>=Ze){M(st,z,_,!0);continue}let Ye;if(st.key!=null)Ye=$e.get(st.key);else for(xe=me;xe<=ce;xe++)if(ze[xe-me]===0&&fn(st,H[xe])){Ye=xe;break}Ye===void 0?M(st,z,_,!0):(ze[Ye-me]=K+1,Ye>=Xe?Xe=Ye:je=!0,f(st,H[Ye],g,null,z,_,w,A,q),Le++)}const Gt=je?mu(ze):Zi;for(xe=Gt.length-1,K=Ze-1;K>=0;K--){const st=me+K,Ye=H[st],Si=H[st+1],Hi=st+1<Z?Si.el||ta(Si):j;ze[K]===0?f(null,Ye,g,Hi,z,_,w,A,q):je&&(xe<0||K!==Gt[xe]?I(Ye,g,Hi,2):xe--)}}},I=(L,H,g,j,z=null)=>{const{el:_,type:w,transition:A,children:q,shapeFlag:K}=L;if(K&6){I(L.component.subTree,H,g,j);return}if(K&128){L.suspense.move(H,g,j);return}if(K&64){w.move(L,H,g,ae);return}if(w===Ke){n(_,H,g);for(let ne=0;ne<q.length;ne++)I(q[ne],H,g,j);n(L.anchor,H,g);return}if(w===to){$(L,H,g);return}if(j!==2&&K&1&&A)if(j===0)A.persisted&&!_[qo]?n(_,H,g):(A.beforeEnter(_),n(_,H,g),xt(()=>A.enter(_),z));else{const{leave:ne,delayLeave:ce,afterLeave:re}=A,me=()=>{L.ctx.isUnmounted?o(_):n(_,H,g)},$e=()=>{const xe=_._isLeaving||!!_[qo];_._isLeaving&&_[qo](!0),A.persisted&&!xe?me():ne(_,()=>{me(),re&&re()})};ce?ce(_,me,$e):$e()}else n(_,H,g)},M=(L,H,g,j=!1,z=!1)=>{const{type:_,props:w,ref:A,children:q,dynamicChildren:K,shapeFlag:Z,patchFlag:ne,dirs:ce,cacheIndex:re,memo:me}=L;if(ne===-2&&(z=!1),A!=null&&(ni(),kn(A,null,g,L,!0),oi()),re!=null&&(H.renderCache[re]=void 0),Z&256){H.ctx.deactivate(L);return}const $e=Z&1&&ce,xe=!Xi(L);let Le;if(xe&&(Le=w&&w.onVnodeBeforeUnmount)&&Ft(Le,H,L),Z&6)te(L.component,g,j);else{if(Z&128){L.suspense.unmount(g,j);return}$e&&Ci(L,null,H,"beforeUnmount"),Z&64?L.type.remove(L,H,g,ae,j):K&&!K.hasOnce&&(_!==Ke||ne>0&&ne&64)?ie(K,H,g,!1,!0):(_===Ke&&ne&384||!z&&Z&16)&&ie(q,H,g),j&&J(L)}const Ze=me!=null&&re==null;(xe&&(Le=w&&w.onVnodeUnmounted)||$e||Ze)&&xt(()=>{Le&&Ft(Le,H,L),$e&&Ci(L,null,H,"unmounted"),Ze&&(L.el=null)},g)},J=L=>{const{type:H,el:g,anchor:j,transition:z}=L;if(H===Ke){Y(g,j);return}if(H===to){T(L);return}const _=()=>{o(g),z&&!z.persisted&&z.afterLeave&&z.afterLeave()};if(L.shapeFlag&1&&z&&!z.persisted){const{leave:w,delayLeave:A}=z,q=()=>w(g,_);A?A(L.el,_,q):q()}else _()},Y=(L,H)=>{let g;for(;L!==H;)g=b(L),o(L),L=g;o(H)},te=(L,H,g)=>{const{bum:j,scope:z,job:_,subTree:w,um:A,m:q,a:K}=L;kr(q),kr(K),j&&eo(j),z.stop(),_&&(_.flags|=8,M(w,L,H,g)),A&&xt(A,H),xt(()=>{L.isUnmounted=!0},H)},ie=(L,H,g,j=!1,z=!1,_=0)=>{for(let w=_;w<L.length;w++)M(L[w],H,g,j,z)},pe=L=>{if(L.shapeFlag&6)return pe(L.component.subTree);if(L.shapeFlag&128)return L.suspense.next();const H=b(L.anchor||L.el),g=H&&H[Td];return g?b(g):H};let le=!1;const N=(L,H,g)=>{let j;L==null?H._vnode&&(M(H._vnode,null,null,!0),j=H._vnode.component):f(H._vnode||null,L,H,null,null,null,g),H._vnode=L,le||(le=!0,cr(j),Al(),le=!1)},ae={p:f,um:M,m:I,r:J,mt:y,mc:W,pc:R,pbc:G,n:pe,o:e};return{render:N,hydrate:void 0,createApp:Xd(N)}}function Zo({type:e,props:t},i){return i==="svg"&&e==="foreignObject"||i==="mathml"&&e==="annotation-xml"&&t&&t.encoding&&t.encoding.includes("html")?void 0:i}function $i({effect:e,job:t},i){i?(e.flags|=32,t.flags|=4):(e.flags&=-33,t.flags&=-5)}function hu(e,t){return(!e||e&&!e.pendingBranch)&&t&&!t.persisted}function Ql(e,t,i=!1){const n=e.children,o=t.children;if(Te(n)&&Te(o))for(let s=0;s<n.length;s++){const l=n[s];let r=o[s];r.shapeFlag&1&&!r.dynamicChildren&&((r.patchFlag<=0||r.patchFlag===32)&&(r=o[s]=Jt(o[s]),r.el=l.el),!i&&r.patchFlag!==-2&&Ql(l,r)),r.type===Ro&&(r.patchFlag===-1&&(r=o[s]=Jt(r)),r.el=l.el),r.type===ri&&!r.el&&(r.el=l.el)}}function mu(e){const t=e.slice(),i=[0];let n,o,s,l,r;const a=e.length;for(n=0;n<a;n++){const c=e[n];if(c!==0){if(o=i[i.length-1],e[o]<c){t[n]=o,i.push(n);continue}for(s=0,l=i.length-1;s<l;)r=s+l>>1,e[i[r]]<c?s=r+1:l=r;c<e[i[s]]&&(s>0&&(t[n]=i[s-1]),i[s]=n)}}for(s=i.length,l=i[s-1];s-- >0;)i[s]=l,l=t[l];return i}function ea(e){const t=e.subTree.component;if(t)return t.asyncDep&&!t.asyncResolved?t:ea(t)}function kr(e){if(e)for(let t=0;t<e.length;t++)e[t].flags|=8}function ta(e){if(e.placeholder)return e.placeholder;const t=e.component;return t?ta(t.subTree):null}const ia=e=>e.__isSuspense;function gu(e,t){t&&t.pendingBranch?Te(e)?t.effects.push(...e):t.effects.push(e):_d(e)}const Ke=Symbol.for("v-fgt"),Ro=Symbol.for("v-txt"),ri=Symbol.for("v-cmt"),to=Symbol.for("v-stc"),ti=[];let It=null;function oe(e=!1){ti.push(It=e?null:[])}function Ws(){ti.pop(),It=ti[ti.length-1]||null}let Ln=1;function wr(e,t=!1){Ln+=e,e<0&&It&&t&&(It.hasOnce=!0)}function na(e){return e.dynamicChildren=Ln>0?It||Zi:null,Ws(),Ln>0&&It&&It.push(e),e}function se(e,t,i,n,o,s){return na(p(e,t,i,n,o,s,!0))}function Dt(e,t,i,n,o){return na(de(e,t,i,n,o,!0))}function Us(e){return e?e.__v_isVNode===!0:!1}function fn(e,t){return e.type===t.type&&e.key===t.key}const oa=({key:e})=>e??null,io=({ref:e,ref_key:t,ref_for:i})=>(typeof e=="number"&&(e=""+e),e!=null?it(e)||Qe(e)||Ae(e)?{i:dt,r:e,k:t,f:!!i}:e:null);function p(e,t=null,i=null,n=0,o=null,s=e===Ke?0:1,l=!1,r=!1){const a={__v_isVNode:!0,__v_skip:!0,type:e,props:t,key:t&&oa(t),ref:t&&io(t),scopeId:Ml,slotScopeIds:null,children:i,component:null,suspense:null,ssContent:null,ssFallback:null,dirs:null,transition:null,el:null,anchor:null,target:null,targetStart:null,targetAnchor:null,staticCount:0,shapeFlag:s,patchFlag:n,dynamicProps:o,dynamicChildren:null,appContext:null,ctx:dt};return r?(ko(a,i),s&128&&e.normalize(a)):i&&(a.shapeFlag|=it(i)?8:16),Ln>0&&!l&&It&&(a.patchFlag>0||s&6)&&a.patchFlag!==32&&It.push(a),a}const de=vu;function vu(e,t=null,i=null,n=0,o=null,s=!1){if((!e||e===Wd)&&(e=ri),Us(e)){const r=nn(e,t,!0);return i&&ko(r,i),Ln>0&&!s&&It&&(r.shapeFlag&6?It[It.indexOf(e)]=r:It.push(r)),r.patchFlag=-2,r}if(Tu(e)&&(e=e.__vccOpts),t){t=bu(t);let{class:r,style:a}=t;r&&!it(r)&&(t.class=Ie(r)),He(a)&&(Rs(a)&&!Te(a)&&(a=ut({},a)),t.style=An(a))}const l=it(e)?1:ia(e)?128:Ad(e)?64:He(e)?4:Ae(e)?2:0;return p(e,t,i,n,o,l,s,!0)}function bu(e){return e?Rs(e)||ql(e)?ut({},e):e:null}function nn(e,t,i=!1,n=!1){const{props:o,ref:s,patchFlag:l,children:r,transition:a}=e,c=t?yu(o||{},t):o,d={__v_isVNode:!0,__v_skip:!0,type:e.type,props:c,key:c&&oa(c),ref:t&&t.ref?i&&s?Te(s)?s.concat(io(t)):[s,io(t)]:io(t):s,scopeId:e.scopeId,slotScopeIds:e.slotScopeIds,children:r,target:e.target,targetStart:e.targetStart,targetAnchor:e.targetAnchor,staticCount:e.staticCount,shapeFlag:e.shapeFlag,patchFlag:t&&e.type!==Ke?l===-1?16:l|16:l,dynamicProps:e.dynamicProps,dynamicChildren:e.dynamicChildren,appContext:e.appContext,dirs:e.dirs,transition:a,component:e.component,suspense:e.suspense,ssContent:e.ssContent&&nn(e.ssContent),ssFallback:e.ssFallback&&nn(e.ssFallback),placeholder:e.placeholder,el:e.el,anchor:e.anchor,ctx:e.ctx,ce:e.ce};return a&&n&&Ns(d,a.clone(d)),d}function $t(e=" ",t=0){return de(Ro,null,e,t)}function vt(e,t){const i=de(to,null,e);return i.staticCount=t,i}function Re(e="",t=!1){return t?(oe(),Dt(ri,null,e)):de(ri,null,e)}function Wt(e){return e==null||typeof e=="boolean"?de(ri):Te(e)?de(Ke,null,e.slice()):Us(e)?Jt(e):de(Ro,null,String(e))}function Jt(e){return e.el===null&&e.patchFlag!==-1||e.memo?e:nn(e)}function ko(e,t){let i=0;const{shapeFlag:n}=e;if(t==null)t=null;else if(Te(t))i=16;else if(typeof t=="object")if(n&65){const o=t.default;o&&(o._c&&(o._d=!1),ko(e,o()),o._c&&(o._d=!0));return}else{i=32;const o=t._;!o&&!ql(t)?t._ctx=dt:o===3&&dt&&(dt.slots._===1?t._=1:(t._=2,e.patchFlag|=1024))}else if(Ae(t)){if(n&65){ko(e,{default:t});return}t={default:t,_ctx:dt},i=32}else t=String(t),n&64?(i=16,t=[$t(t)]):i=8;e.children=t,e.shapeFlag|=i}function yu(...e){const t={};for(let i=0;i<e.length;i++){const n=e[i];for(const o in n)if(o==="class")t.class!==n.class&&(t.class=Ie([t.class,n.class]));else if(o==="style")t.style=An([t.style,n.style]);else if(Co(o)){const s=t[o],l=n[o];l&&s!==l&&!(Te(s)&&s.includes(l))?t[o]=s?[].concat(s,l):l:l==null&&s==null&&!$o(o)&&(t[o]=l)}else o!==""&&(t[o]=n[o])}return t}function Ft(e,t,i,n=null){Nt(e,t,7,[i,n])}const ku=jl();let wu=0;function xu(e,t,i){const n=e.type,o=(t?t.appContext:e.appContext)||ku,s={uid:wu++,vnode:e,type:n,parent:t,appContext:o,root:null,next:null,subTree:null,effect:null,update:null,job:null,scope:new Gc(!0),render:null,proxy:null,exposed:null,exposeProxy:null,withProxy:null,provides:t?t.provides:Object.create(o.provides),ids:t?t.ids:["",0,0],accessCache:null,renderCache:[],components:null,directives:null,propsOptions:Zl(n,o),emitsOptions:Wl(n,o),emit:null,emitted:null,propsDefaults:Ve,inheritAttrs:n.inheritAttrs,ctx:Ve,data:Ve,props:Ve,attrs:Ve,slots:Ve,refs:Ve,setupState:Ve,setupContext:null,suspense:i,suspenseId:i?i.pendingId:0,asyncDep:null,asyncResolved:!1,isMounted:!1,isUnmounted:!1,isDeactivated:!1,bc:null,c:null,bm:null,m:null,bu:null,u:null,um:null,bum:null,da:null,a:null,rtg:null,rtc:null,ec:null,sp:null};return s.ctx={_:s},s.root=t?t.root:s,s.emit=eu.bind(null,s),e.ce&&e.ce(s),s}let mt=null;const Su=()=>mt||dt;let wo,vs;{const e=Ao(),t=(i,n)=>{let o;return(o=e[i])||(o=e[i]=[]),o.push(n),s=>{o.length>1?o.forEach(l=>l(s)):o[0](s)}};wo=t("__VUE_INSTANCE_SETTERS__",i=>mt=i),vs=t("__VUE_SSR_SETTERS__",i=>On=i)}const Hn=e=>{const t=mt;return wo(e),e.scope.on(),()=>{e.scope.off(),wo(t)}},xr=()=>{mt&&mt.scope.off(),wo(null)};function sa(e){return e.vnode.shapeFlag&4}let On=!1;function _u(e,t=!1,i=!1){t&&vs(t);const{props:n,children:o}=e.vnode,s=sa(e);ru(e,n,s,t),du(e,o,i||t);const l=s?Cu(e,t):void 0;return t&&vs(!1),l}function Cu(e,t){const i=e.type;e.accessCache=Object.create(null),e.proxy=new Proxy(e.ctx,Vd);const{setup:n}=i;if(n){ni();const o=e.setupContext=n.length>1?Iu(e):null,s=Hn(e),l=zn(n,e,0,[e.props,o]),r=sl(l);if(oi(),s(),(r||e.sp)&&!Xi(e)&&Rl(e),r){if(l.then(xr,xr),t)return l.then(a=>{Sr(e,a)}).catch(a=>{Do(a,e,0)});e.asyncDep=l}else Sr(e,l)}else ra(e)}function Sr(e,t,i){Ae(t)?e.type.__ssrInlineRender?e.ssrRender=t:e.render=t:He(t)&&(e.setupState=$l(t)),ra(e)}function ra(e,t,i){const n=e.type;e.render||(e.render=n.render||Kt);{const o=Hn(e);ni();try{Kd(e)}finally{oi(),o()}}}const $u={get(e,t){return ht(e,"get",""),e[t]}};function Iu(e){const t=i=>{e.exposed=i||{}};return{attrs:new Proxy(e.attrs,$u),slots:e.slots,emit:e.emit,expose:t}}function Po(e){return e.exposed?e.exposeProxy||(e.exposeProxy=new Proxy($l(hd(e.exposed)),{get(t,i){if(i in t)return t[i];if(i in wn)return wn[i](e)},has(t,i){return i in t||i in wn}})):e.proxy}function Eu(e,t=!0){return Ae(e)?e.displayName||e.name:e.name||t&&e.__name}function Tu(e){return Ae(e)&&"__vccOpts"in e}const _e=(e,t)=>yd(e,t,On),Au="3.5.40";/**
* @vue/runtime-dom v3.5.40
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/let bs;const _r=typeof window<"u"&&window.trustedTypes;if(_r)try{bs=_r.createPolicy("vue",{createHTML:e=>e})}catch{}const la=bs?e=>bs.createHTML(e):e=>e,Bu="http://www.w3.org/2000/svg",Mu="http://www.w3.org/1998/Math/MathML",Yt=typeof document<"u"?document:null,Cr=Yt&&Yt.createElement("template"),Du={insert:(e,t,i)=>{t.insertBefore(e,i||null)},remove:e=>{const t=e.parentNode;t&&t.removeChild(e)},createElement:(e,t,i,n)=>{const o=t==="svg"?Yt.createElementNS(Bu,e):t==="mathml"?Yt.createElementNS(Mu,e):i?Yt.createElement(e,{is:i}):Yt.createElement(e);return e==="select"&&n&&n.multiple!=null&&o.setAttribute("multiple",n.multiple),o},createText:e=>Yt.createTextNode(e),createComment:e=>Yt.createComment(e),setText:(e,t)=>{e.nodeValue=t},setElementText:(e,t)=>{e.textContent=t},parentNode:e=>e.parentNode,nextSibling:e=>e.nextSibling,querySelector:e=>Yt.querySelector(e),setScopeId(e,t){e.setAttribute(t,"")},insertStaticContent(e,t,i,n,o,s){const l=i?i.previousSibling:t.lastChild;if(o&&(o===s||o.nextSibling))for(;t.insertBefore(o.cloneNode(!0),i),!(o===s||!(o=o.nextSibling)););else{Cr.innerHTML=la(n==="svg"?`<svg>${e}</svg>`:n==="mathml"?`<math>${e}</math>`:e);const r=Cr.content;if(n==="svg"||n==="mathml"){const a=r.firstChild;for(;a.firstChild;)r.appendChild(a.firstChild);r.removeChild(a)}t.insertBefore(r,i)}return[l?l.nextSibling:t.firstChild,i?i.previousSibling:t.lastChild]}},Lu=Symbol("_vtc");function Ou(e,t,i){const n=e[Lu];n&&(t=(t?[t,...n]:[...n]).join(" ")),t==null?e.removeAttribute("class"):i?e.setAttribute("class",t):e.className=t}const xo=Symbol("_vod"),aa=Symbol("_vsh"),ys={name:"show",beforeMount(e,{value:t},{transition:i}){e[xo]=e.style.display==="none"?"":e.style.display,i&&t?i.beforeEnter(e):pn(e,t)},mounted(e,{value:t},{transition:i}){i&&t&&i.enter(e)},updated(e,{value:t,oldValue:i},{transition:n}){!t!=!i&&(n?t?(n.beforeEnter(e),pn(e,!0),n.enter(e)):n.leave(e,()=>{pn(e,!1)}):pn(e,t))},beforeUnmount(e,{value:t}){pn(e,t)}};function pn(e,t){e.style.display=t?e[xo]:"none",e[aa]=!t}const Ru=Symbol(""),Pu=/(?:^|;)\s*display\s*:/;function Nu(e,t,i){const n=e.style,o=it(i);let s=!1;if(i&&!o){if(t)if(it(t))for(const l of t.split(";")){const r=l.slice(0,l.indexOf(":")).trim();i[r]==null&&mn(n,r,"")}else for(const l in t)i[l]==null&&mn(n,l,"");for(const l in i){l==="display"&&(s=!0);const r=i[l];r!=null?Fu(e,l,!it(t)&&t?t[l]:void 0,r)||mn(n,l,r):mn(n,l,"")}}else if(o){if(t!==i){const l=n[Ru];l&&(i+=";"+l),n.cssText=i,s=Pu.test(i)}}else t&&e.removeAttribute("style");xo in e&&(e[xo]=s?n.display:"",e[aa]&&(n.display="none"))}const $r=/\s*!important$/;function mn(e,t,i){if(Te(i))i.forEach(n=>mn(e,t,n));else if(i==null&&(i=""),t.startsWith("--"))e.setProperty(t,i);else{const n=zu(e,t);$r.test(i)?e.setProperty(xi(n),i.replace($r,""),"important"):e[n]=i}}const Ir=["Webkit","Moz","ms"],Yo={};function zu(e,t){const i=Yo[t];if(i)return i;let n=wt(t);if(n!=="filter"&&n in e)return Yo[t]=n;n=Eo(n);for(let o=0;o<Ir.length;o++){const s=Ir[o]+n;if(s in e)return Yo[t]=s}return t}function Fu(e,t,i,n){return e.tagName==="TEXTAREA"&&(t==="width"||t==="height")&&it(n)&&i===n}const Er="http://www.w3.org/1999/xlink";function Tr(e,t,i,n,o,s=Kc(t)){n&&t.startsWith("xlink:")?i==null?e.removeAttributeNS(Er,t.slice(6,t.length)):e.setAttributeNS(Er,t,i):i==null||s&&!cl(i)?e.removeAttribute(t):e.setAttribute(t,s?"":Rt(i)?String(i):i)}function Ar(e,t,i,n,o){if(t==="innerHTML"||t==="textContent"){i!=null&&(e[t]=t==="innerHTML"?la(i):i);return}const s=e.tagName;if(t==="value"&&s!=="PROGRESS"&&!s.includes("-")){const r=s==="OPTION"?e.getAttribute("value")||"":e.value,a=i==null?e.type==="checkbox"?"on":"":String(i);(r!==a||!("_value"in e))&&(e.value=a),i==null&&e.removeAttribute(t),e._value=i;return}let l=!1;if(i===""||i==null){const r=typeof e[t];r==="boolean"?i=cl(i):i==null&&r==="string"?(i="",l=!0):r==="number"&&(i=0,l=!0)}try{e[t]=i}catch{}l&&e.removeAttribute(o||t)}function pi(e,t,i,n){e.addEventListener(t,i,n)}function Hu(e,t,i,n){e.removeEventListener(t,i,n)}const Br=Symbol("_vei");function ju(e,t,i,n,o=null){const s=e[Br]||(e[Br]={}),l=s[t];if(n&&l)l.value=n;else{const[r,a]=Vu(t);if(n){const c=s[t]=Gu(n,o);pi(e,r,c,a)}else l&&(Hu(e,r,l,a),s[t]=void 0)}}const Wu=/(Once|Passive|Capture)$/,Uu=/^on:?(?:Once|Passive|Capture)$/;function Vu(e){let t,i;for(;(i=e.match(Wu))&&!Uu.test(e);)t||(t={}),e=e.slice(0,e.length-i[1].length),t[i[1].toLowerCase()]=!0;return[e[2]===":"?e.slice(3):xi(e.slice(2)),t]}let Jo=0;const Ku=Promise.resolve(),qu=()=>Jo||(Ku.then(()=>Jo=0),Jo=Date.now());function Gu(e,t){const i=n=>{if(!n._vts)n._vts=Date.now();else if(n._vts<=i.attached)return;const o=i.value;if(Te(o)){const s=n.stopImmediatePropagation;n.stopImmediatePropagation=()=>{s.call(n),n._stopped=!0};const l=o.slice(),r=[n];for(let a=0;a<l.length&&!n._stopped;a++){const c=l[a];c&&Nt(c,t,5,r)}}else Nt(o,t,5,[n])};return i.value=e,i.attached=qu(),i}const Mr=e=>e.charCodeAt(0)===111&&e.charCodeAt(1)===110&&e.charCodeAt(2)>96&&e.charCodeAt(2)<123,Zu=(e,t,i,n,o,s)=>{const l=o==="svg";t==="class"?Ou(e,n,l):t==="style"?Nu(e,i,n):Co(t)?$o(t)||ju(e,t,i,n,s):(t[0]==="."?(t=t.slice(1),!0):t[0]==="^"?(t=t.slice(1),!1):Yu(e,t,n,l))?(Ar(e,t,n),!e.tagName.includes("-")&&(t==="value"||t==="checked"||t==="selected")&&Tr(e,t,n,l,s,t!=="value")):e._isVueCE&&(Ju(e,t)||e._def.__asyncLoader&&(/[A-Z]/.test(t)||!it(n)))?Ar(e,wt(t),n,s,t):(t==="true-value"?e._trueValue=n:t==="false-value"&&(e._falseValue=n),Tr(e,t,n,l))};function Yu(e,t,i,n){if(n)return!!(t==="innerHTML"||t==="textContent"||t in e&&Mr(t)&&Ae(i));if(t==="spellcheck"||t==="draggable"||t==="translate"||t==="autocorrect"||t==="sandbox"&&e.tagName==="IFRAME"||t==="form"||t==="list"&&e.tagName==="INPUT"||t==="type"&&e.tagName==="TEXTAREA")return!1;if(t==="width"||t==="height"){const o=e.tagName;if(o==="IMG"||o==="VIDEO"||o==="CANVAS"||o==="SOURCE")return!1}return Mr(t)&&it(i)?!1:t in e}function Ju(e,t){const i=e._def.props;if(!i)return!1;const n=wt(t);return Array.isArray(i)?i.some(o=>wt(o)===n):Object.keys(i).some(o=>wt(o)===n)}const on=e=>{const t=e.props["onUpdate:modelValue"]||!1;return Te(t)?i=>eo(t,i):t};function Xu(e){e.target.composing=!0}function Dr(e){const t=e.target;t.composing&&(t.composing=!1,t.dispatchEvent(new Event("input")))}const ii=Symbol("_assign");function Lr(e,t,i){return t&&(e=e.trim()),i&&(e=To(e)),e}const So={created(e,{modifiers:{lazy:t,trim:i,number:n}},o){e[ii]=on(o);const s=n||o.props&&o.props.type==="number";pi(e,t?"change":"input",l=>{l.target.composing||e[ii](Lr(e.value,i,s))}),(i||s)&&pi(e,"change",()=>{e.value=Lr(e.value,i,s)}),t||(pi(e,"compositionstart",Xu),pi(e,"compositionend",Dr),pi(e,"change",Dr))},mounted(e,{value:t}){e.value=t??""},beforeUpdate(e,{value:t,oldValue:i,modifiers:{lazy:n,trim:o,number:s}},l){if(e[ii]=on(l),e.composing)return;const r=(s||e.type==="number")&&!/^0\d/.test(e.value)?To(e.value):e.value,a=t??"";if(r===a)return;const c=e.getRootNode();(c instanceof Document||c instanceof ShadowRoot)&&c.activeElement===e&&e.type!=="range"&&(n&&t===i||o&&e.value.trim()===a)||(e.value=a)}},Yn={deep:!0,created(e,t,i){e[ii]=on(i),pi(e,"change",()=>{const n=e._modelValue,o=Rn(e),s=e.checked,l=e[ii];if(Te(n)){const r=Ts(n,o),a=r!==-1;if(s&&!a)l(n.concat(o));else if(!s&&a){const c=[...n];c.splice(r,1),l(c)}}else if(rn(n)){const r=new Set(n);s?r.add(o):r.delete(o),l(r)}else l(ca(e,s))})},mounted:Or,beforeUpdate(e,t,i){e[ii]=on(i),Or(e,t,i)}};function Or(e,{value:t,oldValue:i},n){e._modelValue=t;let o;if(Te(t))o=Ts(t,n.props.value)>-1;else if(rn(t))o=t.has(n.props.value);else{if(t===i)return;o=ln(t,ca(e,!0))}e.checked!==o&&(e.checked=o)}const Qu={deep:!0,created(e,{value:t,modifiers:{number:i}},n){e._modelValue=t,pi(e,"change",()=>{const o=Array.prototype.filter.call(e.options,s=>s.selected).map(s=>i?To(Rn(s)):Rn(s));e[ii](e.multiple?rn(e._modelValue)?new Set(o):o:o[0]),e._assigning=!0,El(()=>{e._assigning=!1})}),e[ii]=on(n)},mounted(e,{value:t}){Rr(e,t)},beforeUpdate(e,{value:t},i){e._modelValue=t,e[ii]=on(i)},updated(e,{value:t}){e._assigning||Rr(e,t)}};function Rr(e,t){const i=e.multiple,n=Te(t);if(!(i&&!n&&!rn(t))){for(let o=0,s=e.options.length;o<s;o++){const l=e.options[o],r=Rn(l);if(i)if(n){const a=typeof r;a==="string"||a==="number"?l.selected=t.some(c=>String(c)===String(r)):l.selected=Ts(t,r)>-1}else l.selected=t.has(r);else if(ln(Rn(l),t)){e.selectedIndex!==o&&(e.selectedIndex=o);return}}!i&&e.selectedIndex!==-1&&(e.selectedIndex=-1)}}function Rn(e){return"_value"in e?e._value:e.value}function ca(e,t){const i=t?"_trueValue":"_falseValue";return i in e?e[i]:t}const ef=["ctrl","shift","alt","meta"],tf={stop:e=>e.stopPropagation(),prevent:e=>e.preventDefault(),self:e=>e.target!==e.currentTarget,ctrl:e=>!e.ctrlKey,shift:e=>!e.shiftKey,alt:e=>!e.altKey,meta:e=>!e.metaKey,left:e=>"button"in e&&e.button!==0,middle:e=>"button"in e&&e.button!==1,right:e=>"button"in e&&e.button!==2,exact:(e,t)=>ef.some(i=>e[`${i}Key`]&&!t.includes(i))},Mt=(e,t)=>{if(!e)return e;const i=e._withMods||(e._withMods={}),n=t.join(".");return i[n]||(i[n]=((o,...s)=>{for(let l=0;l<t.length;l++){const r=tf[t[l]];if(r&&r(o,t))return}return e(o,...s)}))},nf={esc:"escape",space:" ",up:"arrow-up",left:"arrow-left",right:"arrow-right",down:"arrow-down",delete:"backspace"},of=(e,t)=>{const i=e._withKeys||(e._withKeys={}),n=t.join(".");return i[n]||(i[n]=(o=>{if(!("key"in o))return;const s=xi(o.key);if(t.some(l=>l===s||nf[l]===s))return e(o)}))},sf=ut({patchProp:Zu},Du);let Pr;function rf(){return Pr||(Pr=fu(sf))}const da=((...e)=>{const t=rf().createApp(...e),{mount:i}=t;return t.mount=n=>{const o=af(n);if(!o)return;const s=t._component;!Ae(s)&&!s.render&&!s.template&&(s.template=o.innerHTML),o.nodeType===1&&(o.textContent="");const l=i(o,!1,lf(o));return o instanceof Element&&(o.removeAttribute("v-cloak"),o.setAttribute("data-v-app","")),l},t});function lf(e){if(e instanceof SVGElement)return"svg";if(typeof MathMLElement=="function"&&e instanceof MathMLElement)return"mathml"}function af(e){return it(e)?document.querySelector(e):e}const cf="slidev-config.json",sn={enableWebServeJump:!1,webServeUrl:"http://127.0.0.1:6806",normalizeHeadingSizes:!1},hi=Mo({...sn});function df(e){if(!e||typeof e!="object")return{...sn};const t=e;return{enableWebServeJump:!!t.enableWebServeJump,webServeUrl:typeof t.webServeUrl=="string"&&t.webServeUrl.trim()?t.webServeUrl.trim():sn.webServeUrl,normalizeHeadingSizes:!!t.normalizeHeadingSizes}}function Li(e){if(!e||typeof e!="object")return{...hi};const t=e;return t.enableWebServeJump!==void 0&&(hi.enableWebServeJump=!!t.enableWebServeJump),t.webServeUrl!==void 0&&(hi.webServeUrl=String(t.webServeUrl)),t.normalizeHeadingSizes!==void 0&&(hi.normalizeHeadingSizes=!!t.normalizeHeadingSizes),{...hi}}function No(){return{...hi}}function ua(e,t,i){const n=(e||sn.webServeUrl).trim(),o=n.startsWith("http://")||n.startsWith("https://")?n:`http://${n}`,s=(i==null?void 0:i.r)||Math.random().toString(36).slice(2,9).padEnd(7,"0");try{const l=new URL(o);let r=l.pathname.replace(/\/+$/,"");return r.endsWith("/stage/build/desktop")||(r=r?`${r}/stage/build/desktop`:"/stage/build/desktop"),l.pathname=`${r}/`,l.searchParams.set("id",t),i!=null&&i.focus&&l.searchParams.set("focus","1"),l.searchParams.set("r",s),l.toString()}catch{const l=i!=null&&i.focus?"&focus=1":"";return`${o.replace(/\/+$/,"")}/stage/build/desktop/?id=${t}${l}&r=${s}`}}const Ii={theme:"default",aspectRatio:"16/9",highlighter:"shiki",defaultTransition:"slide-left",colorSchema:"auto",spacing:"normal",normalizeHeadingSizes:!1};function uf(e){var i,n,o,s,l,r;const t=No();return e?{theme:((i=e[Cn])==null?void 0:i.trim())||Ii.theme,aspectRatio:((n=e[$n])==null?void 0:n.trim())||Ii.aspectRatio,highlighter:((o=e[Qr])==null?void 0:o.trim())||Ii.highlighter,defaultTransition:((s=e[In])==null?void 0:s.trim())||Ii.defaultTransition,colorSchema:((l=e[el])==null?void 0:l.trim())||Ii.colorSchema,spacing:((r=e[ls])==null?void 0:r.trim())||Ii.spacing,normalizeHeadingSizes:t.normalizeHeadingSizes}:{...Ii,normalizeHeadingSizes:t.normalizeHeadingSizes}}function _o(e){var i,n,o,s,l;const t=(i=e.ial)==null?void 0:i[Mi];return!!(t&&(t==="true"||t==="page"||t==="cover"||t==="end")||e.type==="tb"||e.type==="thematic-break"||e.type==="NodeThematicBreak"||((n=e.markdown)==null?void 0:n.trim())==="---"||((o=e.markdown)==null?void 0:o.trim())==="***"||e.type==="b"&&(((s=e.markdown)==null?void 0:s.trim())==="---"||((l=e.content)==null?void 0:l.trim())==="---"))}function Nr(e){const t={};let i="";if(!e)return{frontmatter:t,notes:i};e[ge]&&(t.layout=e[ge].trim()),e[tt]&&(t.transition=e[tt].trim()),e[Ue]&&(t.background=e[Ue].trim()),e[Bt]&&(t.image=e[Bt].trim()),e[Gi]&&(t.class=e[Gi].trim()),e[gn]&&(t.spacing=e[gn].trim()),e[lt]&&(t.layoutRatio=e[lt].trim()),e[vi]&&(t.mask=e[vi].trim()),e[bi]&&(t.maskRatio=e[bi].trim()),e[yi]&&(t.maskStyle=e[yi].trim()),e[ki]&&(t.maskInitial=e[ki].trim()),e[qi]&&(i=e[qi].trim());for(const[n,o]of Object.entries(e))if(n.startsWith("custom-slidev-")&&![ge,lt,vi,bi,yi,ki,tt,Ue,Bt,Gi,gn,qi,Mi].includes(n)){const s=n.replace(/^custom-slidev-/,"");try{t[s]=JSON.parse(o)}catch{t[s]=o}}return{frontmatter:t,notes:i}}function ff(e){const t={};if(!e)return t;const i=e[nt]??e["slidev-note"];i!=null&&i!==""&&i!=="false"&&i!=="0"&&(t.isNote=!0);const n=e[Ge]??e["slidev-role"],o=e[Ue]??e["slidev-background"];(n===tl||o==="true"||o==="1")&&(t.isBackground=!0);const s=e[ge]??e["slidev-layout"];s===po||s===ho?t.imageLayout=s:(n===po||n===ho)&&(t.imageLayout=n);const l=e[We]??e["custom-slidev-clicks"]??e["slidev-click"]??e["slidev-clicks"];if(l!=null&&(t.clicks=l.trim()),e[Vt])try{const r=JSON.parse(e[Vt]);typeof r=="object"&&r!==null?t.motion={preset:r.preset||r.type||"fade-in",...r}:t.motion={preset:String(r).trim()}}catch{t.motion={preset:e[Vt].trim()}}return e[zi]&&(t.shikiLines=e[zi].trim()),e[En]&&(t.maxHeight=e[En].trim()),e[Ee]&&(t.slot=e[Ee].trim()),e.style&&e.style.trim()&&(t.style=e.style.trim()),t}function wi(e,t){const i=(e||t||"").trim();if(!i)return null;const n=i.match(/!\[[\s\S]*?\]\(\s*([^\s)]+)(?:\s+(?:=["']?[^"'\s)]*["']?|["'][^"']*["']))*?\s*\)/);if(n)return n[1].trim();const o=i.match(/<img\b[^>]*?\bsrc=["']([^"']+)["']/i);if(o)return o[1].trim();const s=i.replace(/\{:[^}]*\}/g,"").trim();return/^(?:assets\/|https?:\/\/|\/|\.\.?\/)[^\s]+\.(?:png|jpe?g|gif|webp|svg|avif)(?:\?[^\s]*)?$/i.test(s)?s:null}function xn(e){if(!e)return"";const t=e.split(/\r?\n/);if(t.length===0)return"";const i=t[0],n=i.match(/^(\s*)(?:[-*+]|\d+\.)\s+(.*)$/);if(!n)return e;const o=n[1].length,s=n[2].trim(),l=i.length-n[2].length;if(t.length===1)return s;const r=[s];for(let a=1;a<t.length;a++){const c=t[a];if(!c.trim()){r.push("");continue}const d=c.match(/^(\s*)/),m=d?d[1].length:0;m>=l?r.push(c.slice(l)):m>o?r.push(c.slice(m)):r.push(c)}return r.join(`
`)}function Fi(e){if(!e)return!1;const t=(e.type||"").toLowerCase();if(t==="i"||t==="nodelistitem"||t==="l"||t==="nodelist")return!0;const i=(e.markdown||e.rawMarkdown||e.content||"").trim();return!!/^(?:[-*+]|\d+\.)\s+/.test(i)}function Xo(e,t=2){if(!e||typeof e!="string")return`repeat(${t}, 1fr)`;const i=e.trim();if(!i)return`repeat(${t}, 1fr)`;if(i.includes(":")){const o=i.split(":").map(s=>parseFloat(s.trim())).filter(s=>!isNaN(s)&&s>0);if(o.length>=2)return o.map(s=>`${s}fr`).join(" ")}const n=i.split(/\s+/).filter(Boolean);return n.length>=2?n.join(" "):`repeat(${t}, 1fr)`}function Sn(e){if(!e)return[];if(ot(e)&&qt(e)&&!ai(e)){const n=an(e),o=[];for(const s of n)o.push(...Sn(s));return o}const t=(e.type||"").toLowerCase();if(t==="l"||t==="nodelist"||t==="list"){if(e.children&&e.children.length>0){const l=e.children.filter(Fi);if(l.length>0)return l}const o=(e.markdown||e.content||"").trim().split(/\r?\n/),s=[];for(let l=0;l<o.length;l++)/^(?:[-*+]|\d+\.)\s+/.test(o[l])&&s.push(l);if(s.length>=2){const l=[];for(let r=0;r<s.length;r++){const a=s[r],c=r+1<s.length?s[r+1]:o.length,d=o.slice(a,c).join(`
`);l.push({id:`${e.id}-item-${r+1}`,type:"i",markdown:d,content:d,ial:{...e.ial||{}}})}return l}}return Fi(e)?[e]:[]}function Vs(e){var o;if(!e||!ot(e)||!qt(e)||ai(e))return null;const t=an(e);if(t.length===0)return null;if(t.length===1&&ot(t[0])&&qt(t[0])){const s=Vs(t[0]);return s?{items:s.items,nestedSuperBlocks:[t[0],...s.nestedSuperBlocks]}:null}const i=[];for(const s of t)if(ot(s)){i.push(s);const l=((o=s.children)==null?void 0:o.filter(ot))||[];i.push(...l)}const n=t.map(Sn);if(n.length>=2&&n.every(s=>s.length>0)){const s=n.flat();if(s.length>=2&&s.length<=6)return{items:s,nestedSuperBlocks:i}}if(t.length===2){const s=Sn(t[0]),l=Sn(t[1]);if(s.length+l.length>=2&&s.length+l.length<=6&&(s.length>0||l.length>0))return{items:[...s,...l],nestedSuperBlocks:i}}return null}function pf(e){if(!e||!ot(e)||!qt(e)||ai(e))return null;const t=Vs(e);if(!t)return null;const{items:i,nestedSuperBlocks:n}=t;if(i.length<2||i.length>6)return null;const o=Ks(e)||void 0,s=i.length;return{superBlockNode:e,nestedSuperBlocks:n,count:s,layout:"cols-header",items:i,slots:i.map((l,r)=>`col-${r+1}`),ratio:o}}function fa(e){if(!e||!ot(e)||!qt(e)||ai(e))return null;const t=an(e);if(t.length===0)return null;const i=[];for(const n of t){const o=Sn(n);if(o.length===0)return null;i.push(...o)}return i}function hf(e){if(!e||!ot(e)||!qt(e)||ai(e))return null;const t=fa(e);return!t||t.length===0||t.length>=2&&t.length<=6?null:{superBlockNode:e,items:t}}function mf(e){if(!e||!ot(e)||!qt(e)||ai(e))return null;const t=Vs(e);if(t&&t.items.length===4)return t.items;const i=fa(e);if(i&&i.length===4)return i;const n=an(e);return n.length===4?n:null}function gf(e,t){if(!e||e.length===0)return null;const i=[];function n(r,a){if(ot(r)){const c=mf(r);c&&c.length===4&&i.push({sbNode:r,items:c,topLevelIndex:a})}if(r.children&&r.children.length>0)for(const c of r.children)n(c,a)}for(let r=0;r<e.length;r++)n(e[r],r);if(i.length===0)return null;let o=null;t&&(o=i.find(r=>{if(r.sbNode.id===t||r.items.some(c=>c.id===t))return!0;const a=c=>c.id===t?!0:c.children?c.children.some(a):!1;return a(r.sbNode)})||null),o||(o=i[0]);const l=e.slice(0,o.topLevelIndex).slice().reverse().find(r=>pa(r));return{superBlockNode:o.sbNode,items:o.items,headerNode:l}}function vf(e,t,i){var d,m,b,u,h;const n=[],o=[],s=(i==null?void 0:i.tracked)||[],l=[];let r={pageTargetId:e,blocks:[]};l.push(r);for(let f=0;f<t.length;f++){const v=t[f];if(_o(v)){if(l.length===1&&r.blocks.length===0){r.pageTargetId=v.id,r.blocks.push(v);continue}r={pageTargetId:v.id,blocks:[v]},l.push(r)}else r.blocks.push(v)}function a(f){const v=[];for(const k of f)ot(k)&&v.push(k),k.children&&k.children.length>0&&v.push(...a(k.children));return v}function c(f,v,k){const S={blockId:f,attrs:v,previousAttrs:k};n.push(S),i!=null&&i.onTagChange&&i.onTagChange(S)}for(const f of l){const v=f.pageTargetId,k=t.find(E=>E.id===v),S=s.find(E=>E.pageTargetId===v);if(f.blocks.some(E=>{var x,W;return!!(ai(E)||ks(E)&&(((x=E.ial)==null?void 0:x[ge])==="image-left"||((W=E.ial)==null?void 0:W[ge])==="image-right"))})){if(S){const E=S.headerId;if(E){c(E,{[Ee]:""});const x=t.find(W=>W.id===E);x!=null&&x.ial&&(x.ial[Ee]="")}for(const x of S.itemIds){c(x,{[Ee]:""});const W=t.find(V=>V.id===x);W!=null&&W.ial&&(W.ial[Ee]="")}}continue}let T=null,D=-1;for(let E=0;E<f.blocks.length;E++){const x=f.blocks[E],W=ot(x)?[x,...a(x.children||[])]:x.children?a(x.children):[];for(const V of W){const G=pf(V);if(G){T=G,D=E;break}}if(T)break}if(T){const{superBlockNode:E,layout:x,items:W,slots:V}=T,X=f.blocks.slice(0,D).find(B=>pa(B)),C=X==null?void 0:X.id,P=((d=k==null?void 0:k.ial)==null?void 0:d[ge])||"",y=P==="clover",O=y?"clover":x;if(P!==O&&(c(v,{[ge]:O},{[ge]:P}),k&&(k.ial||(k.ial={}),k.ial[ge]=O)),X){const B=((m=X.ial)==null?void 0:m[Ee])||"";B!=="header"&&(c(X.id,{[Ee]:"header"},{[Ee]:B}),X.ial||(X.ial={}),X.ial[Ee]="header")}if(S!=null&&S.headerId&&S.headerId!==C){c(S.headerId,{[Ee]:""});const B=t.find(R=>R.id===S.headerId);B&&(B.ial||(B.ial={}),B.ial[Ee]="")}const U=[];for(let B=0;B<W.length;B++){const R=W[B],F=V[B];U.push(R.id);const ee=((b=R.ial)==null?void 0:b[Ee])||"";if(ee!==F&&(c(R.id,{[Ee]:F},{[Ee]:ee}),R.ial||(R.ial={}),R.ial[Ee]=F),R.children&&R.children.length>0)for(const I of R.children)I.ial||(I.ial={}),I.ial[Ee]!==F&&(I.ial[Ee]=F)}if(S!=null&&S.itemIds){for(const B of S.itemIds)if(!U.includes(B)){c(B,{[Ee]:""});const R=t.find(F=>F.id===B);R&&(R.ial||(R.ial={}),R.ial[Ee]="")}}o.push({superBlockId:E.id,nestedSuperBlockIds:(u=T.nestedSuperBlocks)==null?void 0:u.map(B=>B.id),pageTargetId:v,headerId:C,itemIds:U,layout:y?"clover":x})}else{let E=!1;const x=[];for(const G of f.blocks){const X=ot(G)?[G,...a(G.children||[])]:G.children?a(G.children):[];for(const C of X){const P=hf(C);if(P){E=!0;for(const y of P.items)x.push(y.id)}}}const W=((h=k==null?void 0:k.ial)==null?void 0:h[ge])||"",V=Tn(W);if(S||E&&V){c(v,{[ge]:""},{[ge]:W}),k&&(k.ial||(k.ial={}),k.ial[ge]="");const G=S==null?void 0:S.headerId;if(G){c(G,{[Ee]:""});const C=t.find(P=>P.id===G);C&&(C.ial||(C.ial={}),C.ial[Ee]="")}const X=new Set([...(S==null?void 0:S.itemIds)||[],...x]);for(const C of X){c(C,{[Ee]:""});const P=t.find(y=>y.id===C);P&&(P.ial||(P.ial={}),P.ial[Ee]="")}}}}return{changes:n,newTracked:o}}function ot(e){if(!e)return!1;const t=(e.type||"").toLowerCase();return t==="s"||t==="sb"||t==="nodesuperblock"}function qt(e){if(!ot(e))return!1;const t=(e.subType||"").toLowerCase();if(t==="col"||t==="h"||t==="horizontal")return!0;if(t==="row"||t==="v"||t==="vertical")return!1;if(e.ial){const n=(e.ial["data-sb-layout"]||e.ial.layout||"").toLowerCase();if(n==="col"||n==="h")return!0;if(n==="row"||n==="v")return!1}if(e.children&&e.children.length>0){for(const n of e.children)if(n.type==="NodeSuperBlockLayoutMarker"||n.type==="layout-marker"){const o=(n.content||n.markdown||"").trim().toLowerCase();if(o==="col"||o==="h")return!0;if(o==="row"||o==="v")return!1}}const i=(e.markdown||e.content||"").trim();return/^\{\{\{col\b/i.test(i)?!0:!/^\{\{\{row\b/i.test(i)}function ks(e){return!e||Fi(e)||ot(e)||!wi(e.markdown,e.content)?!1:(e.markdown||e.content||"").replace(/!\[.*?\]\([^)]+\)/g,"").replace(/<img\b[^>]*>/gi,"").replace(/\{:[^}]*\}/g,"").trim().length<=25}function Ks(e){var b;if(!e||!ot(e)||!qt(e))return null;const t=an(e);if(!t||t.length<2)return null;const i=[];let n=!1;for(const u of t){const h=(((b=u.ial)==null?void 0:b.style)||u.style||"").trim();let f=null;if(h){const v=h.match(/calc\(\s*([\d.]+)%/i);if(v)f=parseFloat(v[1]);else{const k=h.match(/(?:^|;|\s)width:\s*([\d.]+)%/i);k&&(f=parseFloat(k[1]))}}f!==null&&!isNaN(f)&&f>0?(i.push(f),n=!0):i.push(null)}if(!n)return null;const o=t.length,s=i.reduce((u,h)=>u+(h||0),0),l=i.filter(u=>u===null).length,r=Math.max(0,100-s),a=l>0?r/l:100/o,c=i.map(u=>u!==null?u:a),d=c.reduce((u,h)=>u+h,0);if(d<=0)return null;const m=c.map(u=>u/d*100);if(m.length===2){const[u]=m;if(u>=48&&u<=52)return"1:1";if(u>=31&&u<=35)return"1:2";if(u>=65&&u<=69)return"2:1";if(u>=28&&u<=32)return"3:7";if(u>=68&&u<=72)return"7:3";if(u>=38&&u<=42)return"4:6";if(u>=58&&u<=62)return"6:4";if(u>=23&&u<=27)return"1:3";if(u>=73&&u<=77)return"3:1";const h=Math.round(u),f=100-h;return`${h}:${f}`}if(m.length===3){const[u,h,f]=m;if(u>=31&&u<=35&&h>=31&&h<=35&&f>=31&&f<=35)return"1:1:1";if(u>=23&&u<=27&&h>=48&&h<=52&&f>=23&&f<=27)return"1:2:1";if(u>=48&&u<=52&&h>=23&&h<=27&&f>=23&&f<=27)return"2:1:1";if(u>=23&&u<=27&&h>=23&&h<=27&&f>=48&&f<=52)return"1:1:2";if(u>=18&&u<=22&&h>=58&&h<=62&&f>=18&&f<=22)return"1:3:1";const v=Math.round(u),k=Math.round(h),S=100-v-k;return`${v}:${k}:${S}`}return m.map(u=>Math.round(u)).join(":")}function ai(e){if(!e||!ot(e)||!qt(e))return null;const t=(e.children||[]).filter(s=>{const l=s.type||"";if(l==="NodeSuperBlockOpenMarker"||l==="NodeSuperBlockLayoutMarker"||l==="NodeSuperBlockCloseMarker"||l==="open-marker"||l==="layout-marker"||l==="close-marker")return!1;const r=(s.markdown||s.content||"").trim();return!(/^\{\{\{(?:col|row)?\s*$/i.test(r)||r==="}}}")});if(t.length<2)return null;const i=ks(t[0]),n=ks(t[t.length-1]),o=Ks(e)||void 0;if(i&&!n){const s=wi(t[0].markdown,t[0].content);if(s)return{imageNode:t[0],imageUrl:s,layout:po,contentNodes:t.slice(1),ratio:o}}if(!i&&n){const s=wi(t[t.length-1].markdown,t[t.length-1].content);if(s)return{imageNode:t[t.length-1],imageUrl:s,layout:ho,contentNodes:t.slice(0,t.length-1),ratio:o}}return null}function bf(e,t){const i=[];function n(o){for(const s of o){const l=ai(s);if(l){const{imageNode:r,layout:a,ratio:c}=l;r.ial||(r.ial={});const d=r.ial[ge];if(d!==a){const b={blockId:r.id,layout:a,previousLayout:d,ratio:c};r.ial[ge]=a,i.push(b),t&&t(b)}}s.children&&s.children.length>0&&n(s.children)}}return n(e),i}function an(e){return(e.children||[]).filter(t=>{const i=t.type||"";if(i==="NodeSuperBlockOpenMarker"||i==="NodeSuperBlockLayoutMarker"||i==="NodeSuperBlockCloseMarker"||i==="open-marker"||i==="layout-marker"||i==="close-marker")return!1;const n=(t.markdown||t.content||"").trim();return!(/^\{\{\{(?:col|row)?\s*$/i.test(n)||n==="}}}")})}function pa(e){if(!e)return!1;const t=(e.type||"").toLowerCase();if(t==="h"||t==="nodeheading"||/^h[1-6]$/i.test(e.subType||""))return!0;const i=(e.markdown||e.content||"").trim();return!!/^#{1,6}\s+/.test(i)}function Ei(e,t,i){let n="",o=0;const s=/<div\b([^>]*)>/gi;for(;o<e.length;){s.lastIndex=o;let l,r=!1,a=-1,c=0;for(;(l=s.exec(e))!==null;){const k=l[1].match(/\bclass=["']([^"']*)["']/i);if(k){const S=k[1];if(typeof t=="string"?S.split(/\s+/).includes(t):t.test(S)){r=!0,a=l.index,c=l[0].length;break}}}if(!r){n+=e.slice(o);break}n+=e.slice(o,a);const d=a+c;let m=1,b=-1,u=-1;const h=/<\/?div\b[^>]*>/gi;h.lastIndex=d;let f;for(;(f=h.exec(e))!==null;)if(f[0].startsWith("</")){if(m--,m===0){b=f.index,u=f.index+f[0].length;break}}else m++;if(b!==-1&&u!==-1){const v=e.slice(d,b);n+=i(v),o=u}else n+=e.slice(a,d),o=d}return n}function yf(e){const t=[];let i="",n=0;const o=/<div\b([^>]*)>/gi;for(;n<e.length;){o.lastIndex=n;let s,l=!1,r=-1,a=0;for(;(s=o.exec(e))!==null;){const f=s[1];if(/(?:\s@[a-zA-Z0-9_-]+=\s*["']|\s:[a-zA-Z0-9_-]+=\s*["']|\sv-[a-zA-Z0-9_.-]+|\shover:[a-zA-Z0-9_.-]+=\s*["']|\sgrid=["']~|\bclass=["'][^"']*\b(?:abs-br|slidev-icon-btn|grid\s+|grid$|grid-cols-|relative\b)\b[^"']*["']|\bstyle=["'][^"']*\bgrid-[^"']*["'])/i.test(f)){l=!0,r=s.index,a=s[0].length;break}}if(!l){i+=e.slice(n);break}i+=e.slice(n,r);const c=r+a;let d=1,m=-1,b=-1;const u=/<\/?div\b[^>]*>/gi;u.lastIndex=c;let h;for(;(h=u.exec(e))!==null;)if(h[0].startsWith("</")){if(d--,d===0){m=h.index,b=h.index+h[0].length;break}}else d++;if(m!==-1&&b!==-1){const f=e.slice(r,b),v=`__VUE_DIV_TOKEN_${t.length}__`;t.push(f),i+=v,n=b}else i+=e.slice(r,c),n=c}return{text:i,tokens:t}}function kf(e){const t=[];let i=e.replace(/(?:^[ \t]*(`{3,}|~{3,})[^\n\r]*\r?\n[\s\S]*?\r?\n[ \t]*\1(?=[ \t]*(?:\r?\n|$)))/gm,r=>{const a=`__CODE_TOKEN_${t.length}__`;return t.push(r),a});i=i.replace(/(`+)(?:[^\n\r`]|(?!\1)`)+?\1/g,r=>{const a=`__CODE_TOKEN_${t.length}__`;return t.push(r),a});const n=[];i=i.replace(/<script\b[^>]*>[\s\S]*?<\/script>/gi,r=>{const a=`__SCRIPT_TOKEN_${n.length}__`;return n.push(r),a});const{text:o,tokens:s}=yf(i);i=o;const l=[];i=i.replace(/<(?:[A-Z][a-zA-Z0-9_-]*|[a-z0-9_-]+:[a-z0-9_-]+|v-[a-z0-9_-]+|arrow\b|div\s+h-\d+)\b[^>]*\/>/gi,r=>{const a=`__VUE_COMP_TOKEN_${l.length}__`;return l.push(r),a}),i=i.replace(/<(v-[a-z0-9_-]+|button)\b([^>]*)>([\s\S]*?)<\/\1>/gi,r=>{const a=`__VUE_COMP_TOKEN_${l.length}__`;return l.push(r),a}),i=i.replace(/<img\b[^>]*?\bv-[a-z0-9_.-]+[^>]*\/?>/gi,r=>{const a=`__VUE_COMP_TOKEN_${l.length}__`;return l.push(r),a}),i=i.replace(/<(p|span)\b([^>]*?\bv-[a-z0-9_.-]+[^>]*)>([\s\S]*?)<\/\1>/gi,r=>{const a=`__VUE_COMP_TOKEN_${l.length}__`;return l.push(r),a}),i=i.replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi,""),i=i.replace(/<div class="terminal-bar">[\s\S]*?<\/div>/gi,""),i=i.replace(/<div class="cursor-line">[\s\S]*?<\/div>/gi,""),i=i.replace(/<span class="cursor">[\s\S]*?<\/span>/gi,""),i=i.replace(/<div class="stamp">\s*([\s\S]*?)\s*<\/div>/gi,`

*[$1]*

`),i=i.replace(/<div class="arrow">\s*([→\->]+)\s*<\/div>/gi,`

$1

`),i=i.replace(/<i>\s*[→\->]+\s*<\/i>/gi,""),i=i.replace(/<div class="prompt">\s*([\s\S]*?)\s*<\/div>/gi,(r,a)=>`
\`\`\`bash
${a.trim()}
\`\`\`
`),i=i.replace(/<p>\s*<i>\$<\/i>\s*([\s\S]*?)<\/p>/gi,(r,a)=>`
\`\`\`bash
$ ${a.trim()}
\`\`\`
`),i=i.replace(/<div class="statusline">\s*([\s\S]*?)\s*<\/div>/gi,(r,a)=>`
> ${Array.from(a.matchAll(/<span>([\s\S]*?)<\/span>/gi)).map(d=>`\`${d[1].trim()}\``).join(" | ")}
`),i=i.replace(/<div class="log-panel">\s*<pre>([\s\S]*?)<\/pre>\s*<\/div>/gi,(r,a)=>`
\`\`\`log
${a.replace(/<span[^>]*>([\s\S]*?)<\/span>/gi,"$1").trim()}
\`\`\`
`),i=Ei(i,"diff-grid",r=>{const a=Array.from(r.matchAll(/<div class="diff\s+([^"]*)">\s*<span>(.*?)<\/span>\s*<pre>([\s\S]*?)<\/pre>\s*<\/div>/gi));return a.length>0?`
`+a.map(c=>{const d=c[2].trim().toUpperCase(),m=c[3].trim();return`**${d}:**
\`\`\`yaml
${m}
\`\`\``}).join(`

`)+`
`:r}),i=Ei(i,"before-after",r=>{const a=r.match(/<div class="before">[\s\S]*?<small>(.*?)<\/small>[\s\S]*?<h2>(.*?)<\/h2>[\s\S]*?<p>(.*?)<\/p>\s*<\/div>/i),c=r.match(/<div class="after">[\s\S]*?<small>(.*?)<\/small>[\s\S]*?<h2>(.*?)<\/h2>[\s\S]*?<p>(.*?)<\/p>\s*<\/div>/i);let d=`
`;return a&&(d+=`### ${a[1]}
## ${a[2]}
${a[3]}

`),c&&(d+=`### ${c[1]}
## ${c[2]}
${c[3]}
`),d.trim()?d:r}),i=i.replace(/<ul\b[^>]*>([\s\S]*?)<\/ul>/gi,(r,a)=>{const c=Array.from(a.matchAll(/<li>\s*(?:<em>)?(\[[x ]\])(?:<\/em>)?\s*([\s\S]*?)<\/li>/gi));return c.length>0?`
`+c.map(d=>`- ${d[1]} ${d[2].trim()}`).join(`
`)+`
`:a}),i=Ei(i,"timeline",r=>{const a=Array.from(r.matchAll(/<div(?:\s+class="([^"]*)")?>\s*<time>([\s\S]*?)<\/time>\s*<b>([\s\S]*?)<\/b>\s*<span>([\s\S]*?)<\/span>\s*<\/div>/gi));return a.length>0?`

`+a.map(c=>{const d=c[1]||"";let m="-";return d.includes("warn")?m="- ⚠️":d.includes("bad")?m="- ❌":d.includes("ok")&&(m="- ✅"),`${m} **${c[2].trim()}** **${c[3].trim()}** — ${c[4].trim()}`}).join(`
`)+`

`:r}),i=Ei(i,"pipeline",r=>{const a=Array.from(r.matchAll(/<div(?:\s+class="([^"]*)")?>\s*<small>([\s\S]*?)<\/small>\s*<b>([\s\S]*?)<\/b>\s*<span>([\s\S]*?)<\/span>\s*<\/div>/gi));return a.length>0?`

`+a.map((c,d)=>{const b=(c[1]||"").includes("hot")?"⚠️ ":"";return`${d+1}. ${b}**${c[3].trim()}** (*${c[4].trim()}*)`}).join(`
`)+`

`:r}),i=Ei(i,"check-grid",r=>{const a=Array.from(r.matchAll(/<div>\s*<span class="([^"]*)"><\/span>\s*<b>([\s\S]*?)<\/b>\s*<p>([\s\S]*?)<\/p>\s*<\/div>/gi));return a.length>0?`

`+a.map(c=>`- ${(c[1]||"").includes("warn")?"⚠️":"✅"} **${c[2].trim()}**: ${c[3].trim()}`).join(`
`)+`

`:r}),i=Ei(i,"manifesto",r=>{const a=Array.from(r.matchAll(/<div>\s*<span>([\s\S]*?)<\/span>\s*<h2>([\s\S]*?)<\/h2>\s*<p>([\s\S]*?)<\/p>\s*<\/div>/gi));return a.length>0?`

`+a.map(c=>`## ${c[1].trim()} ${c[2].trim()}

${c[3].trim()}`).join(`

`)+`

`:r}),i=Ei(i,"split-note",r=>{const a=Array.from(r.matchAll(/<div>\s*<b>([\s\S]*?)<\/b>\s*<p>([\s\S]*?)<\/p>\s*<\/div>/gi));return a.length>0?`

`+a.map(c=>`> **${c[1].trim()}**: ${c[2].trim()}`).join(`
>
`)+`

`:r}),i=i.replace(/<div class="mechanism">\s*<b>([\s\S]*?)<\/b>\s*<p>([\s\S]*?)<\/p>\s*<\/div>/gi,(r,a,c)=>`

> **${a.trim()}**: ${c.trim()}

`),i=i.replace(/<pre>([\s\S]*?)<\/pre>/gi,(r,a)=>`
\`\`\`text
${a.replace(/<span[^>]*>([\s\S]*?)<\/span>/gi,"$1").trim()}
\`\`\`
`),i=i.replace(/<div class="page-head">\s*<span>([\s\S]*?)<\/span>\s*<b>([\s\S]*?)<\/b>\s*<\/div>/gi,`
### $1 ($2)
`),i=i.replace(/<h1\b[^>]*>([\s\S]*?)<\/h1>/gi,`
# $1
`),i=i.replace(/<h2\b[^>]*>([\s\S]*?)<\/h2>/gi,`
## $1
`),i=i.replace(/<h3\b[^>]*>([\s\S]*?)<\/h3>/gi,`
### $1
`),i=i.replace(/<h4\b[^>]*>([\s\S]*?)<\/h4>/gi,`
#### $1
`),i=i.replace(/<p\s+class="ok">\s*●\s*([\s\S]*?)<\/p>/gi,`
✅ **$1**
`),i=i.replace(/<p\s+class="caption">\s*([\s\S]*?)<\/p>/gi,`
> *$1*
`),i=i.replace(/<p\s+class="lead">\s*([\s\S]*?)<\/p>/gi,`
*$1*
`),i=i.replace(/<p\b([^>]*)>([\s\S]*?)<\/p>/gi,(r,a,c)=>/@|v-|:|class=/i.test(a)?r:`
${c.trim()}

`),i=i.replace(/<br\s*\/?>/gi,`
`),i=i.replace(/<hr\s*\/?>/gi,`
---
`),i=i.replace(/<b\b[^>]*>([\s\S]*?)<\/b>/gi,"**$1**"),i=i.replace(/<strong\b[^>]*>([\s\S]*?)<\/strong>/gi,"**$1**"),i=i.replace(/<i\b[^>]*>([\s\S]*?)<\/i>/gi,"*$1*"),i=i.replace(/<code\b[^>]*>([\s\S]*?)<\/code>/gi,(r,a)=>{if(a.startsWith("`")&&a.endsWith("`"))return a;if(a.includes("`")){const c=(a.match(/`+/g)||[]).reduce((m,b)=>Math.max(m,b.length),0),d="`".repeat(c+1);return`${d} ${a} ${d}`}return`\`${a}\``}),i=i.replace(/<small\b[^>]*>([\s\S]*?)<\/small>/gi,"*$1*"),i=i.replace(/\*{4}/g,"** **"),i=i.replace(/<li\b[^>]*>([\s\S]*?)<\/li>/gi,`- $1
`),i=i.replace(/<ul\b[^>]*>([\s\S]*?)<\/ul>/gi,`
$1
`),i=i.replace(/<ol\b[^>]*>([\s\S]*?)<\/ol>/gi,`
$1
`),i=i.replace(/<a\b([^>]*)href=["'](.*?)["']([^>]*)>([\s\S]*?)<\/a>/gi,(r,a,c,d,m)=>{const b=m.trim();return b.includes("<")||b.includes(`
`)?r:`[${b}](${c})`}),i=i.replace(/<blockquote\b[^>]*>([\s\S]*?)<\/blockquote>/gi,(r,a)=>`
`+a.trim().split(`
`).map(c=>`> ${c.trim()}`).join(`
`)+`
`),i=i.replace(/<span\b[^>]*data-type=["']block-ref["'][^>]*data-id=["']([0-9a-zA-Z-]+)["'][^>]*>([\s\S]*?)<\/span>/gi,(r,a,c)=>{const d=c.replace(/<[^>]+>/g,"").trim();return d?`((${a} '${d}'))`:`((${a}))`}),i=i.replace(/<span\b[^>]*data-type=["']a["'][^>]*data-href=["']([^"']+)["'][^>]*>([\s\S]*?)<\/span>/gi,(r,a,c)=>`[${c.replace(/<[^>]+>/g,"").trim()}](${a})`),i=i.replace(/<\/(?:div|section|header|footer|main|article|nav|aside)\b[^>]*>/gi,`
`),i=i.replace(/<(?:div|section|header|footer|main|article|nav|aside)\b[^>]*>/gi,""),i=i.replace(/<\/?span\b[^>]*>/gi,"");for(let r=0;r<l.length;r++)i=i.replace(`__VUE_COMP_TOKEN_${r}__`,l[r]);for(let r=0;r<s.length;r++)i=i.replace(`__VUE_DIV_TOKEN_${r}__`,s[r]);for(let r=0;r<n.length;r++)i=i.replace(`__SCRIPT_TOKEN_${r}__`,n[r]);for(let r=0;r<t.length;r++)i=i.replace(`__CODE_TOKEN_${r}__`,t[r]);return i=i.replace(/\n{3,}/g,`

`).trim(),i}function ha(e){if(!e||typeof e!="string")return"";const t=[];let i=e.replace(/`([^`]+)`/g,n=>(t.push(n),`%%INLINE_CODE_${t.length-1}%%`));return i=i.replace(/(<\/[a-zA-Z0-9_-]+>)\s*\{:[^}]*\}/g,"$1"),i=i.replace(/(\[[^\]]+\]\([^)]+\))\s*\{:\s*style=["']([^"']*)["'][^}]*\}/g,'<span style="$2">$1</span>'),i=i.replace(/(\*\*[^*]+\*\*)\s*\{:\s*style=["']([^"']*)["'][^}]*\}/g,'<span style="$2">$1</span>'),i=i.replace(/(\*[^*]+\*)\s*\{:\s*style=["']([^"']*)["'][^}]*\}/g,'<span style="$2">$1</span>'),i=i.replace(/(~~[^~]+~~)\s*\{:\s*style=["']([^"']*)["'][^}]*\}/g,'<span style="$2">$1</span>'),i=i.replace(/([\p{L}\p{N}_\-]+)\s*\{:\s*style=["']([^"']*)["'][^}]*\}/gu,'<span style="$2">$1</span>'),i=i.replace(/\{:[^}]*\}/g,""),i=i.replace(/%%INLINE_CODE_(\d+)%%/g,(n,o)=>t[parseInt(o,10)]||""),i}function wf(e){const t=Object.entries(e).filter(([n,o])=>o!=null&&o!=="");return t.length===0?"":`---
${t.map(([n,o])=>typeof o=="string"?o.includes(":")||o.includes(`
`)||o.includes("#")?`${n}: "${o.replace(/"/g,'\\"')}"`:`${n}: ${o}`:`${n}: ${JSON.stringify(o)}`).join(`
`)}
---`}function xf(e,t){if(!t||!e.startsWith("```"))return e;const i=e.indexOf(`
`);if(i===-1)return e;const n=e.slice(0,i).trim(),o=e.slice(i);return n.includes("{")?e:`${n} {${t}}${o}`}function ma(e,t){if(t==null)return e;const i=t.trim();return i===""||i==="+1"?`<v-click>

${e}

</v-click>`:i==="hide"?`<v-click hide>

${e}

</v-click>`:`<v-click at="${i}">

${e}

</v-click>`}function Sf(e){if(!e||!e.preset)return null;const t=e.preset.toLowerCase().trim();if(!t||t==="none")return null;let i={opacity:0},n={opacity:1};switch(t){case"slide-up":i={y:40,opacity:0},n={y:0,opacity:1};break;case"slide-down":i={y:-40,opacity:0},n={y:0,opacity:1};break;case"slide-left":i={x:40,opacity:0},n={x:0,opacity:1};break;case"slide-right":i={x:-40,opacity:0},n={x:0,opacity:1};break;case"zoom-in":case"pop":i={scale:.8,opacity:0},n={scale:1,opacity:1};break;case"bounce":i={y:40,opacity:0},n={y:0,opacity:1,transition:{type:"spring",damping:10,stiffness:100}};break;case"fade-in":default:i={opacity:0},n={opacity:1};break}e.initial&&typeof e.initial=="object"&&(i={...i,...e.initial}),e.enter&&typeof e.enter=="object"&&(n={...n,...e.enter});const o={...n.transition||{}};return typeof e.duration=="number"&&e.duration>0&&(o.duration=e.duration),typeof e.delay=="number"&&e.delay>0&&(o.delay=e.delay),Object.keys(o).length>0&&(n.transition=o),{initial:i,enter:n}}function Jn(e,t,i,n){const o=t!=null&&t.trim()!=="",s=Sf(i),l=n==null?void 0:n.trim(),r=l!==void 0&&l!=="",a=r?` style="${l.replace(/"/g,"&quot;")}" class="slide-styled-block"`:"";if(!o&&!s)return r?`<div${a}>

${e}

</div>`:e;if(o&&!s){if(r){const h=t.trim();let f="v-click";return h==="hide"?f="v-click.hide":h!==""&&h!=="+1"&&(f=`v-click="${h}"`),`<div ${f}${a}>

${e}

</div>`}return ma(e,t)}const c=JSON.stringify(s.initial).replace(/"/g,"'"),d=JSON.stringify(s.enter).replace(/"/g,"'"),m=`v-motion :initial="${c}" :enter="${d}"`;if(!o)return`<div ${m}${a}>

${e}

</div>`;const b=t.trim();let u="v-click";return b==="hide"?u="v-click.hide":b!==""&&b!=="+1"&&(u=`v-click="${b}"`),`<div ${u} ${m}${a}>

${e}

</div>`}function ga(e){if(!e)return"";let t=e.trim();t=t.replace(/\{:[^}]*\}/g,"").trim(),t=t.replace(/^:::\s*[a-zA-Z0-9_-]*\s*\r?\n?/g,""),t=t.replace(/\r?\n?:::\s*$/g,"");let o=t.split(/\r?\n/).map(s=>s.trim().replace(/^>\s*/,"")).join(`
`).trim();return o=o.replace(/^\[!(?:NOTE|TIP|IMPORTANT|WARNING|CAUTION|[A-Za-z_-]+)\][^\r\n]*(?:\r?\n)?/i,"").trim(),o=o.replace(/^(?:💡|✏️|❗|⚠️|🚨|\s*)*(?:\*\*|__)?(?:演讲备注|演讲者提词|讲稿备注|演讲提词|备注|Notes?)(?:\*\*|__)?[:：]?\s*(?:\r?\n)?/i,"").trim(),o=o.replace(/^[-*+]\s+/,""),o=o.replace(/^\d+\.\s+/,""),o.trim()}function _f(e){var n;if(e.subType&&/^h([1-6])$/i.test(e.subType))return parseInt(e.subType.slice(1),10);const i=(e.markdown||e.content||"").trim().match(/^(#{1,6})\s+/);return i?i[1].length:e.type==="h"?(n=e.ial)!=null&&n.subType&&/^h([1-6])$/i.test(e.ial.subType)?parseInt(e.ial.subType.slice(1),10):1:null}function va(e,t=2){const i=Math.max(2,t);if(!e||e.length===0)return Array.from({length:i},()=>[]);if(e.length===1&&e[0].children&&e[0].children.length>=2){const c=e[0].children,d=Array.from({length:i},()=>[]),m=Math.min(i,c.length),b=Math.floor(c.length/m),u=c.length%m;let h=0;for(let f=0;f<m;f++){const v=b+(f<u?1:0);d[f]=c.slice(h,h+v),h+=v}return d}const n=c=>{const d=(c.slot||"").trim();if(!d)return null;if(d==="left")return 1;if(d==="center")return 2;if(d==="right")return i===2?2:i;const m=d.match(/^col-(\d+)$/i);if(m){const b=parseInt(m[1],10);if(b>=1&&b<=i)return b}return null},o=e.map(n);if(o.some(c=>c!==null)){if(o.some(u=>u!==null&&u>=2)){const u=Array.from({length:i},()=>[]);let h=1;for(const f of e){const v=n(f);v!==null&&(h=v),u[h-1].push(f)}return u}const d=e.filter(u=>n(u)===1),m=e.filter(u=>n(u)===null),b=i-1;if(m.length>=b){const u=Math.floor(m.length/b),h=m.length%b,f=[d];let v=0;for(let k=0;k<b;k++){const S=u+(k<h?1:0);f.push(m.slice(v,v+S)),v+=S}return f}else if(m.length>0){const u=[d];for(let h=0;h<b;h++)u.push(h<m.length?[m[h]]:[]);return u}else return[d,...Array.from({length:b},()=>[])]}const l=c=>{if(c.type==="h"||c.subType&&/^h[1-6]$/i.test(c.subType))return!0;const d=(c.rawMarkdown||c.content||"").trim();return/^#{1,6}\s+/.test(d)},r=e.map((c,d)=>l(c)?d:-1).filter(c=>c!==-1);if(r.length>=i){const c=Array.from({length:i},()=>[]);for(let d=0;d<i;d++){const m=r[d],b=d+1<i?r[d+1]:e.length;c[d]=e.slice(m,b)}return c}if(e.length>=i){const c=Array.from({length:i},()=>[]);let d=0;for(let m=0;m<i;m++){const b=i-m,u=e.length-d,h=Math.ceil(u/b);c[m]=e.slice(d,d+h),d+=h}return c}if(e.length>1&&e.length<i){const c=Array.from({length:i},()=>[]);for(let d=0;d<e.length;d++)c[d]=[e[d]];return c}if(e.length===1){const c=e[0],d=(c.rawMarkdown||c.content||"").trim(),m=d.split(/\r?\n/),b=[];for(let f=0;f<m.length;f++)/^[ \t]*[-*+]\s+|^[ \t]*\d+\.\s+/.test(m[f])&&b.push(f);if(b.length>=i){const f=Array.from({length:i},()=>[]);let v=0;for(let k=0;k<i;k++){const S=i-k,$=b.length-v,T=Math.ceil($/S),D=b[v],E=v+T<b.length?b[v+T]:m.length,x=m.slice(D,E).join(`
`);f[k]=[{...c,id:k===0?c.id:`${c.id}-col${k+1}`,rawMarkdown:x,content:x}],v+=T}return f}const u=d.match(/<li[\s\S]*?<\/li>/gi);if(u&&u.length>=i){const f=Array.from({length:i},()=>[]);let v=0;for(let k=0;k<i;k++){const S=i-k,$=u.length-v,T=Math.ceil($/S),D=`<ul>
${u.slice(v,v+T).join(`
`)}
</ul>`;f[k]=[{...c,id:k===0?c.id:`${c.id}-col${k+1}`,rawMarkdown:D,content:D}],v+=T}return f}const h=d.split(/\r?\n\s*\r?\n/).filter(f=>f.trim()!=="");if(h.length>=i){const f=Array.from({length:i},()=>[]);let v=0;for(let k=0;k<i;k++){const S=i-k,$=h.length-v,T=Math.ceil($/S),D=h.slice(v,v+T).join(`

`);f[k]=[{...c,id:k===0?c.id:`${c.id}-col${k+1}`,rawMarkdown:D,content:D}],v+=T}return f}}const a=Array.from({length:i},()=>[]);return a[0]=e,a}function zr(e,t,i,n){var d;const o=uf(t),s=[],l=Nr(t);let r={pageIndex:1,startBlockId:e,frontmatter:{layout:l.frontmatter.layout||"cover",...l.frontmatter},notes:"",noteBlocks:[],blocks:[],rawMarkdown:"",allBlockIds:[e]};r.frontmatter.background&&(r.frontmatter.background=Et(r.frontmatter.background,n)),r.frontmatter.image&&(r.frontmatter.image=Et(r.frontmatter.image,n)),s.push(r);let a=[];for(const m of i){if(_o(m)){a=[];const u=Nr(m.ial);if(s.length===1&&r.blocks.length===0){r.startBlockId=m.id,r.allBlockIds||(r.allBlockIds=[]),r.allBlockIds.includes(m.id)||r.allBlockIds.push(m.id),u.frontmatter.layout&&(r.frontmatter.layout=u.frontmatter.layout),Object.assign(r.frontmatter,u.frontmatter),!u.frontmatter.image&&l.frontmatter.image&&(r.frontmatter.image=l.frontmatter.image),!u.frontmatter.background&&l.frontmatter.background&&(r.frontmatter.background=l.frontmatter.background),r.frontmatter.background&&(r.frontmatter.background=Et(r.frontmatter.background,n)),r.frontmatter.image&&(r.frontmatter.image=Et(r.frontmatter.image,n));continue}r={pageIndex:s.length+1,startBlockId:m.id,frontmatter:{layout:u.frontmatter.layout||"default",...u.frontmatter},notes:"",noteBlocks:[],blocks:[],rawMarkdown:"",allBlockIds:[m.id]},r.frontmatter.background&&(r.frontmatter.background=Et(r.frontmatter.background,n)),r.frontmatter.image&&(r.frontmatter.image=Et(r.frontmatter.image,n)),s.push(r);continue}const b=(u,h)=>{var U,B,R,F;if(r.allBlockIds||(r.allBlockIds=[]),u.id&&!r.allBlockIds.includes(u.id)&&r.allBlockIds.push(u.id),u.children&&u.children.length>0){const ee=I=>{for(const M of I)M.id&&!r.allBlockIds.includes(M.id)&&r.allBlockIds.push(M.id),M.children&&M.children.length>0&&ee(M.children)};ee(u.children)}let f=Lc(u),v=u.ial?{...u.ial}:{};const k=f.match(/\{:\s*([^}]+)\s*\}\s*$/);k&&(v={...Oc(k[0]),...v},f=f.slice(0,k.index).trim()),u.type!=="c"&&!f.startsWith("```")&&(f=ha(f));let S=f.trim();if(/^\{\{\{(?:row|col)?\s*$/i.test(S)||S==="}}}")return;/^\{\{\{(?:row|col)?\s*\r?\n/i.test(S)&&/\r?\n\}\}\}$/.test(S)&&(f=S.replace(/^\{\{\{(?:row|col)?\s*\r?\n/i,"").replace(/\r?\n\}\}\}$/,"").trim(),S=f.trim());const $=ff(v);if(f=Rc(f,n),f=Dc(f,n==null?void 0:n.refContentMap),u.children&&u.children.length>0){const ee=["custom-slidev-autoplay","custom-slidev-loop","custom-slidev-muted","custom-slidev-controls"],I=M=>{for(const J of M){if(J.ial)for(const[Y,te]of Object.entries(J.ial))ee.includes(Y)&&!v[Y]&&(v[Y]=te);J.children&&J.children.length>0&&I(J.children)}};I(u.children)}const T=u.type==="video"||u.type==="NodeVideo"||/<video\b/i.test(f);if(T){const ee=v["custom-slidev-autoplay"]==="true",I=v["custom-slidev-loop"]==="true",M=v["custom-slidev-muted"]==="true"||ee,J=v["custom-slidev-controls"]==="false";f=f.replace(/<video\b([^>]*)>/gi,(Y,te)=>{let ie=te;return J?ie=ie.replace(/\bcontrols(?:="[^"]*")?/gi,"").trim():/controls/i.test(ie)||(ie+=" controls"),ee&&!/autoplay/i.test(ie)?ie+=" autoplay playsinline":!ee&&v["custom-slidev-autoplay"]==="false"&&(ie=ie.replace(/\bautoplay\b/gi,"").replace(/\bplaysinline\b/gi,"").trim()),I&&!/loop/i.test(ie)?ie+=" loop":!I&&v["custom-slidev-loop"]==="false"&&(ie=ie.replace(/\bloop\b/gi,"").trim()),M&&!/muted/i.test(ie)?ie+=" muted":!M&&v["custom-slidev-muted"]==="false"&&(ie=ie.replace(/\bmuted\b/gi,"").trim()),`<video ${ie.trim()}>`})}if($.isBackground){const ee=wi(f,u.content);if(ee){r.frontmatter.background=Et(ee,n);return}}const D=ai(u);if(D){r.frontmatter.layout=D.layout,r.frontmatter.image=Et(D.imageUrl,n),!r.frontmatter.layoutRatio&&D.ratio&&(r.frontmatter.layoutRatio=D.ratio);for(const ee of D.contentNodes)b(ee);return}if($.imageLayout==="image-left"||$.imageLayout==="image-right"){const ee=wi(f,u.content);if(ee){r.frontmatter.layout=$.imageLayout,r.frontmatter.image=Et(ee,n),!r.frontmatter.layoutRatio&&((U=u.ial)!=null&&U[lt])&&(r.frontmatter.layoutRatio=u.ial[lt]);return}}if(ot(u)&&u.children&&u.children.length>0){for(const ee of u.children)b(ee);return}const E=!!($.slot||h!=null&&h.defaultSlot||r.frontmatter.layout==="clover"||Tn(r.frontmatter.layout)||r.frontmatter.layout==="two-cols");if((u.type==="l"||u.type==="NodeList"||u.type==="list")&&u.children&&u.children.length>0&&(u.children.some(ee=>{var I,M;return((I=ee.ial)==null?void 0:I[Ee])||((M=ee.ial)==null?void 0:M[We])})||$.slot||$.clicks||E)){for(const ee of u.children)$.slot&&(!ee.ial||!ee.ial[Ee])&&(ee.ial||(ee.ial={}),ee.ial[Ee]=$.slot),b(ee,{...h,parentClicks:$.clicks||(h==null?void 0:h.parentClicks),defaultSlot:$.slot||(h==null?void 0:h.defaultSlot)});return}const x=!!(u.children&&u.children.length>=2)||!!$.clicks||!!((B=u.children)!=null&&B.some(ee=>{var I;return(I=ee.ial)==null?void 0:I[We]}))||!u.markdown&&!!(u.children&&u.children.length>0);if(Fi(u)&&u.children&&u.children.length>0&&(E||$.clicks||u.children.some(ee=>{var I;return(I=ee.ial)==null?void 0:I[We]}))&&x){const ee=!!(u.children&&u.children.length>=2),I=u.children.find(le=>!!(le.markdown||le.content||"").trim())||u.children[0],M=((R=I==null?void 0:I.ial)==null?void 0:R[We])||((F=I==null?void 0:I.ial)==null?void 0:F["custom-slidev-click"]),J=!!(!$.clicks&&ee&&M),Y=$.clicks||(J?M:void 0)||(h==null?void 0:h.parentClicks),te=u.id||(h==null?void 0:h.parentContainerId),ie=$.slot||(h==null?void 0:h.defaultSlot);let pe=!0;for(const le of u.children){ie&&(!le.ial||!le.ial[Ee])&&(le.ial||(le.ial={}),le.ial[Ee]=ie);const N=!!(le.markdown||le.content||"").trim(),ae=pe&&N;ae&&(le.markdown&&(le.markdown=xn(le.markdown)),le.content&&(le.content=xn(le.content)),pe=!1);let ue=le;ae&&Y&&ee&&(ue={...le,ial:{...le.ial||{}}},delete ue.ial[We],delete ue.ial["custom-slidev-click"]),b(ue,{parentClicks:Y,parentContainerId:te,defaultSlot:ie})}return}if($.isNote){const ee=ga(f);ee&&(r.notes?r.notes+=`

`+ee:r.notes=ee),r.noteBlocks||(r.noteBlocks=[]),r.noteBlocks.push({id:u.id,type:u.type,content:ee||u.content||"",rawMarkdown:f,isNote:!0,attributes:u.ial});return}$.shikiLines&&(f=xf(f,$.shikiLines)),S=f.trim();const W=(u.content||"").trim();if(S==="::right::"||W==="::right::"||/^<p>\s*::right::\s*<\/p>$/i.test(S)||S.startsWith("::right::")){r.blocks.push({id:u.id,type:u.type,content:"::right::",rawMarkdown:"::right::",slot:"slot-divider-right",attributes:u.ial});return}const G=_f(u);let X=$.slot,C=$.clicks,P=$.motion,y={...u.ial||{}};if(G!==null){for(;a.length>0&&a[a.length-1].level>=G;)a.pop();const ee=a.length>0?a[a.length-1]:void 0;!X&&(ee!=null&&ee.slot)&&(X=ee.slot),!C&&(ee!=null&&ee.clicks)&&!(h!=null&&h.parentContainerId)&&(C=ee.clicks),!P&&(ee!=null&&ee.motion)&&(P=ee.motion);const I={...(ee==null?void 0:ee.customAttrs)||{}};if(u.ial)for(const[M,J]of Object.entries(u.ial))M.startsWith("custom-slidev-")&&!M.startsWith("custom-slidev-slide")&&(I[M]=J);h!=null&&h.parentContainerId||a.push({level:G,slot:X,clicks:C,motion:P,customAttrs:I})}else{const ee=a.length>0?a[a.length-1]:void 0;ee&&(!X&&ee.slot&&ee.slot!=="header"&&(X=ee.slot),!C&&ee.clicks&&!(h!=null&&h.parentContainerId)&&(C=ee.clicks),!P&&ee.motion&&(P=ee.motion),ee.customAttrs&&(y={...ee.customAttrs,...y}))}!X&&r.blocks.some(ee=>ee.slot==="slot-divider-right")&&(X="right"),!X&&(h!=null&&h.defaultSlot)&&(X=h.defaultSlot),X&&(y[Ee]=X),C&&!y[We]&&(y[We]=C),P&&!y[Vt]&&(y[Vt]=JSON.stringify(P)),(T||v["custom-slidev-autoplay"]||v["custom-slidev-muted"])&&(v["custom-slidev-autoplay"]&&(y["custom-slidev-autoplay"]=v["custom-slidev-autoplay"],v["custom-slidev-autoplay"]==="true"&&!v["custom-slidev-muted"]&&(y["custom-slidev-muted"]="true")),v["custom-slidev-loop"]&&(y["custom-slidev-loop"]=v["custom-slidev-loop"]),v["custom-slidev-muted"]&&(y["custom-slidev-muted"]=v["custom-slidev-muted"]),v["custom-slidev-controls"]&&(y["custom-slidev-controls"]=v["custom-slidev-controls"]));const O={id:u.id,type:u.type,content:u.content||"",rawMarkdown:f,clicks:C,parentClicks:h==null?void 0:h.parentClicks,parentContainerId:h==null?void 0:h.parentContainerId,motion:P,shikiLines:$.shikiLines,slot:X,attributes:y,rawNode:u};r.blocks.push(O)};b(m)}for(let m=0;m<s.length;m++){const b=s[m],u=[],h={...b.frontmatter};m===0&&(h.theme=o.theme,h.aspectRatio=o.aspectRatio,h.highlighter=o.highlighter,h.transition=b.frontmatter.transition||o.defaultTransition);const f=wf(h);f&&u.push(f);const v=b.blocks.filter(D=>D.slot!=="slot-divider-right"),k=D=>D.filter(E=>!!(E.rawMarkdown||E.content||"").trim()).map(E=>{var x;return Jn(E.rawMarkdown,E.clicks,E.motion,(x=E.attributes)==null?void 0:x.style)}).join(`

`),S=D=>{const E=D.filter(G=>!!(G.rawMarkdown||G.content||"").trim());if(E.length===0)return;const x=E[0],W=(x.rawMarkdown||x.content||"").trim();(Fi(x)||/^(?:[-*+]|\d+\.)\s+/.test(W))&&(x.rawMarkdown=xn(x.rawMarkdown||x.content||""),x.content=x.rawMarkdown)},$=D=>{var G,X;if(D.length===0)return"";S(D);const E=(G=D.find(C=>C.parentClicks))==null?void 0:G.parentClicks;if(!E)return D.filter(C=>!!(C.rawMarkdown||C.content||"").trim()).map(C=>{var P;return Jn(C.rawMarkdown,C.clicks,C.motion,(P=C.attributes)==null?void 0:P.style)}).join(`

`);const x=[];let W=[];const V=()=>{if(W.length===0)return;const C=W.map(P=>(P.rawMarkdown||P.content||"").trim()).filter(Boolean).join(`

`);C&&x.push(ma(C,E)),W=[]};for(const C of D){if(!(C.rawMarkdown||C.content||"").trim())continue;!!(C.clicks&&C.clicks.trim()!=="")?(V(),x.push(Jn(C.rawMarkdown,C.clicks,C.motion,(X=C.attributes)==null?void 0:X.style))):W.push(C)}return V(),x.join(`

`)},T=b.frontmatter.layout||"default";if(T==="clover"||Tn(T)){let D=[];const E=v.filter(C=>C.slot==="header");if(E.length>0)D=E;else if(v.length>0){const C=v.find(P=>P.type==="h"&&(!P.slot||P.slot==="default"));C&&(D=[C])}const x=v.filter(C=>!D.includes(C));let W=2;if(T==="clover")W=4;else if(T==="three-cols-header")W=3;else if(T==="two-cols-header")W=2;else{let C=0;for(const P of x){const y=(P.slot||"").match(/^col-(\d+)$/i);y&&(C=Math.max(C,parseInt(y[1],10)))}if(C>=2)W=C;else if(b.frontmatter.layoutRatio){const P=b.frontmatter.layoutRatio.trim();if(P.includes(":")){const y=P.split(":").map(O=>parseFloat(O.trim())).filter(O=>!isNaN(O)&&O>0);y.length>=2&&(W=y.length)}else{const y=P.split(/\s+/).filter(Boolean);y.length>=2&&(W=y.length)}}else x.length===1&&x[0].children&&x[0].children.length>=2&&(W=Math.min(6,x[0].children.length))}const V=va(x,W);V.forEach((C,P)=>{const y=`col-${P+1}`;for(const O of C)(!O.slot||O.slot==="default")&&(O.slot=y);S(C)});const G=V.flat();if(x.length===1&&G.length>1){const C=b.blocks.findIndex(P=>P.id===x[0].id);C!==-1&&b.blocks.splice(C,1,...G)}const X=k(D);if(X&&u.push(X),T==="two-cols-header"&&W===2){const C=$(V[0]||[]),P=$(V[1]||[]);C&&u.push(`::left::

${C}`),P&&u.push(`::right::

${P}`)}else V.forEach((C,P)=>{const y=$(C);y&&u.push(`::col-${P+1}::

${y}`)})}else if(T==="two-cols"){const D=v.filter(V=>V.slot==="left"),E=v.filter(V=>V.slot==="right");S(D),S(E);const x=k(D.length>0?D:v.filter(V=>V.slot!=="right")),W=k(E);u.push(x),W&&u.push(`::right::

${W}`)}else for(const D of v)u.push(Jn(D.rawMarkdown,D.clicks,D.motion,(d=D.attributes)==null?void 0:d.style));b.notes&&u.push(`<!--
${b.notes}
-->`),b.rawMarkdown=u.join(`

`).trim()}const c=s.map(m=>m.rawMarkdown).filter(Boolean).join(`

---

`);return{docId:e,config:o,slides:s,fullMarkdown:c}}const ws=`/* SiYuan Note Built-in Font & Background Styles for Slidev */
:root,
html:not(.dark),
[data-theme="light"],
[data-theme-mode="light"] {
  /* 思源基础卡片与主题色 (浅色模式 daylight) */
  --b3-card-error-color: #790600;
  --b3-card-error-background: #f5d1cf;
  --b3-card-warning-color: #8a4f00;
  --b3-card-warning-background: #ffe8c8;
  --b3-card-info-color: #005599;
  --b3-card-info-background: #d6eaf9;
  --b3-card-success-color: #006b04;
  --b3-card-success-background: #d7eed8;

  --b3-theme-primary: #3575f0;
  --b3-theme-secondary: #ff9200;
  --b3-theme-error: #d23f31;
  --b3-theme-background: #ffffff;
  --b3-theme-on-background: #222222;
  --b3-theme-on-surface: #5f6368;
  --b3-theme-surface-lighter: #e0e0e0;

  /* 13 种内置文字颜色 */
  --b3-font-color1: var(--b3-card-error-color);
  --b3-font-color2: var(--b3-card-warning-color);
  --b3-font-color3: var(--b3-card-info-color);
  --b3-font-color4: var(--b3-card-success-color);
  --b3-font-color5: var(--b3-theme-on-surface);
  --b3-font-color6: var(--b3-theme-primary);
  --b3-font-color7: var(--b3-theme-secondary);
  --b3-font-color8: var(--b3-theme-error);
  --b3-font-color9: #a40074;
  --b3-font-color10: #007080;
  --b3-font-color11: #006e2a;
  --b3-font-color12: #6b5a00;
  --b3-font-color13: var(--b3-theme-background);

  /* 13 种内置背景颜色 */
  --b3-font-background1: var(--b3-card-error-background);
  --b3-font-background2: var(--b3-card-warning-background);
  --b3-font-background3: var(--b3-card-info-background);
  --b3-font-background4: var(--b3-card-success-background);
  --b3-font-background5: #e2e3e4;
  --b3-font-background6: #acd0fc;
  --b3-font-background7: #fddaab;
  --b3-font-background8: #ffb0a9;
  --b3-font-background9: #fdbfff;
  --b3-font-background10: #b1ffff;
  --b3-font-background11: #affad1;
  --b3-font-background12: #fff88f;
  --b3-font-background13: var(--b3-theme-on-background);
}

html.dark,
[data-theme="dark"],
[data-theme-mode="dark"],
.theme-dark,
.dark {
  /* 思源基础卡片与主题色 (深色模式 midnight) */
  --b3-card-error-color: rgb(243, 153, 147);
  --b3-card-error-background: #442724;
  --b3-card-warning-color: rgb(255, 213, 153);
  --b3-card-warning-background: #554636;
  --b3-card-info-color: rgb(166, 213, 250);
  --b3-card-info-background: #28405c;
  --b3-card-success-color: rgb(183, 223, 185);
  --b3-card-success-background: #425347;

  --b3-theme-primary: #3575f0;
  --b3-theme-secondary: #ff9200;
  --b3-theme-error: #d23f31;
  --b3-theme-background: #1e1e1e;
  --b3-theme-on-background: #c8ccd6;
  --b3-theme-on-surface: #8b949e;
  --b3-theme-surface-lighter: #282a2e;

  /* 13 种内置文字颜色 */
  --b3-font-color1: var(--b3-card-error-color);
  --b3-font-color2: var(--b3-card-warning-color);
  --b3-font-color3: var(--b3-card-info-color);
  --b3-font-color4: var(--b3-card-success-color);
  --b3-font-color5: var(--b3-theme-on-surface);
  --b3-font-color6: var(--b3-theme-primary);
  --b3-font-color7: var(--b3-theme-secondary);
  --b3-font-color8: var(--b3-theme-error);
  --b3-font-color9: #f47c9c;
  --b3-font-color10: #4dd0e1;
  --b3-font-color11: #10df54;
  --b3-font-color12: #ecd424;
  --b3-font-color13: var(--b3-theme-background);

  /* 13 种内置背景颜色 */
  --b3-font-background1: var(--b3-card-error-background);
  --b3-font-background2: var(--b3-card-warning-background);
  --b3-font-background3: var(--b3-card-info-background);
  --b3-font-background4: var(--b3-card-success-background);
  --b3-font-background5: #3a3f42;
  --b3-font-background6: #031840;
  --b3-font-background7: #593905;
  --b3-font-background8: #3a0c09;
  --b3-font-background9: #4d1b40;
  --b3-font-background10: #1a5459;
  --b3-font-background11: #305415;
  --b3-font-background12: #4a4712;
  --b3-font-background13: var(--b3-theme-on-background);
}

@media (prefers-color-scheme: dark) {
  :root:not([data-theme="light"]):not([data-theme-mode="light"]):not(.light) {
    --b3-card-error-color: rgb(243, 153, 147);
    --b3-card-error-background: #442724;
    --b3-card-warning-color: rgb(255, 213, 153);
    --b3-card-warning-background: #554636;
    --b3-card-info-color: rgb(166, 213, 250);
    --b3-card-info-background: #28405c;
    --b3-card-success-color: rgb(183, 223, 185);
    --b3-card-success-background: #425347;

    --b3-theme-primary: #3575f0;
    --b3-theme-secondary: #ff9200;
    --b3-theme-error: #d23f31;
    --b3-theme-background: #1e1e1e;
    --b3-theme-on-background: #c8ccd6;
    --b3-theme-on-surface: #8b949e;
    --b3-theme-surface-lighter: #282a2e;

    --b3-font-color1: var(--b3-card-error-color);
    --b3-font-color2: var(--b3-card-warning-color);
    --b3-font-color3: var(--b3-card-info-color);
    --b3-font-color4: var(--b3-card-success-color);
    --b3-font-color5: var(--b3-theme-on-surface);
    --b3-font-color6: var(--b3-theme-primary);
    --b3-font-color7: var(--b3-theme-secondary);
    --b3-font-color8: var(--b3-theme-error);
    --b3-font-color9: #f47c9c;
    --b3-font-color10: #4dd0e1;
    --b3-font-color11: #10df54;
    --b3-font-color12: #ecd424;
    --b3-font-color13: var(--b3-theme-background);

    --b3-font-background1: var(--b3-card-error-background);
    --b3-font-background2: var(--b3-card-warning-background);
    --b3-font-background3: var(--b3-card-info-background);
    --b3-font-background4: var(--b3-card-success-background);
    --b3-font-background5: #3a3f42;
    --b3-font-background6: #031840;
    --b3-font-background7: #593905;
    --b3-font-background8: #3a0c09;
    --b3-font-background9: #4d1b40;
    --b3-font-background10: #1a5459;
    --b3-font-background11: #305415;
    --b3-font-background12: #4a4712;
    --b3-font-background13: var(--b3-theme-on-background);
  }
}

/* 演示块级样式排版增强 (带背景色时赋予呼吸内边距与舒适圆角) */
.slide-styled-block {
  border-radius: 6px;
  padding: 8px 14px;
  box-sizing: border-box;
  margin: 6px 0;
  transition: background-color 0.2s ease, color 0.2s ease;
}

/* 行内带背景色文本的精美圆角与微边距 */
span[style*="background-color"],
span[style*="background:"] {
  border-radius: 3px;
  padding: 1px 5px;
  box-decoration-break: clone;
  -webkit-box-decoration-break: clone;
}
`;function Cf(e){var o,s,l,r,a,c,d,m,b,u,h,f;if(!e||typeof e!="object")return"";const t=[],i=[];if(Array.isArray(e.styles))for(const v of e.styles){if(!v||!v.id)continue;const k=`--b3-inline-style-${v.id}`;(o=v.light)!=null&&o.color&&t.push(`  ${k}-color: ${v.light.color};`),(s=v.light)!=null&&s.backgroundColor&&t.push(`  ${k}-background-color: ${v.light.backgroundColor};`),(l=v.dark)!=null&&l.color&&i.push(`  ${k}-color: ${v.dark.color};`),(r=v.dark)!=null&&r.backgroundColor&&i.push(`  ${k}-background-color: ${v.dark.backgroundColor};`)}if(e.builtin&&Array.isArray(e.builtin.colors))for(const v of e.builtin.colors){if(!v||typeof v.index!="number")continue;const k=v.index;(a=v.light)!=null&&a.color&&t.push(`  --b3-font-color${k}: ${v.light.color};`),(c=v.light)!=null&&c.backgroundColor&&t.push(`  --b3-font-background${k}: ${v.light.backgroundColor};`),(d=v.dark)!=null&&d.color&&i.push(`  --b3-font-color${k}: ${v.dark.color};`),(m=v.dark)!=null&&m.backgroundColor&&i.push(`  --b3-font-background${k}: ${v.dark.backgroundColor};`)}if(e.builtin&&Array.isArray(e.builtin.styles))for(const v of e.builtin.styles){if(!v||!v.id)continue;const k=v.id;(b=v.light)!=null&&b.color&&t.push(`  --b3-card-${k}-color: ${v.light.color};`),(u=v.light)!=null&&u.backgroundColor&&t.push(`  --b3-card-${k}-background: ${v.light.backgroundColor};`),(h=v.dark)!=null&&h.color&&i.push(`  --b3-card-${k}-color: ${v.dark.color};`),(f=v.dark)!=null&&f.backgroundColor&&i.push(`  --b3-card-${k}-background: ${v.dark.backgroundColor};`)}if(t.length===0&&i.length===0)return"";const n=[];return t.length>0&&n.push(`:root, html:not(.dark), [data-theme="light"] {
${t.join(`
`)}
}`),i.length>0&&n.push(`html.dark, [data-theme="dark"], .dark {
${i.join(`
`)}
}`),n.join(`

`)}function _n(e){const t=Cf(e);return t?`${ws}

/* Custom Workspace Inline Styles */
${t}`:ws}function Qo(e){const t={};if(!e||typeof e!="string")return t;const i=e.replace(/^\{:\s*/,"").replace(/\s*\}$/,""),n=/([\w-]+)=(?:"([^"]*)"|'([^']*)'|(\S+))/g;let o;for(;(o=n.exec(i))!==null;){const s=o[1],l=o[2]??o[3]??o[4]??"";t[s]=l}return t}function $f(e){const t=String((e==null?void 0:e.type)||"").toLowerCase();return t==="s"||t==="sb"||t==="nodesuperblock"||t==="l"||t==="nodelist"||t==="i"||t==="nodelistitem"||t==="b"||t==="nodeblockquote"}function If(e,t){const i=new Map,n=[];if(!Array.isArray(t)||t.length===0)return{usable:!1,reason:"索引无行",leafPatch:i,rebuildRoots:n};const o=new Map;for(const s of t)s!=null&&s.id&&o.set(s.id,s);for(const s of e||[]){if(!(s!=null&&s.id))continue;const l=o.get(s.id);if(!l)continue;const r=s.content??"",a=s.markdown??"";(l.content??"")===r&&(l.markdown??"")===a||($f(l)?n.push(s.id):i.set(s.id,{content:r,markdown:a}))}return{usable:!0,reason:"",leafPatch:i,rebuildRoots:n}}function Ef(e){const t=String((e==null?void 0:e.type)||"").toLowerCase();return t==="h"||t==="nodeheading"}function xs(e){return ot(e)||e.type==="l"||e.type==="NodeList"||e.type==="i"||e.type==="NodeListItem"||e.type==="b"||e.type==="NodeBlockquote"}function Tf(e,t,i,n=8,o){const s=new Map;for(const b of t)b!=null&&b.id&&s.set(b.id,b);const l=b=>({id:b.id,parent_id:b.parent_id,root_id:b.root_id||e,type:b.type,subType:b.subtype??b.subType??"",content:b.content||"",markdown:b.markdown||"",ial:i(b.id,b.ial),children:[]}),r=b=>{let u=b.parent_id,h=0;for(;u&&u!==e&&h++<16;){const f=s.get(u);if(!f||!Ef(f))return u;u=f.parent_id}return u||e},a=new Map;for(const b of t){if(!(b!=null&&b.id)||b.id===e||o&&o.size>0&&!o.has(b.id))continue;const u=r(b),h=a.get(u);h?h.push(b):a.set(u,[b])}if(o&&o.size>0)for(const b of a.values())b.sort((u,h)=>(o.get(u.id)??Number.MAX_SAFE_INTEGER)-(o.get(h.id)??Number.MAX_SAFE_INTEGER));const c=new Map,d=(b,u)=>{const h=l(b);if(c.set(h.id,h),u>=n||!xs(h))return h;const f=a.get(h.id);return f&&f.length>0&&(h.children=f.map(v=>d(v,u+1))),h};return{topLevel:(a.get(e)||[]).map(b=>d(b,0)),byId:c}}const Af={getBlockAttrs:Cs,getChildBlocks:co,getDocBlocksOrders:Ac,setBlockAttrs:De,sql:en,getBaseUrl:()=>typeof location<"u"?location.origin:"",getInlineStyles:Bc};class Bf{constructor(t){ke(this,"deps");ke(this,"attrOverrides",new Map);ke(this,"trackedListSuperBlocks",new Map);ke(this,"fallbackWarnedDocId","");this.deps={...Af,...t||{}}}setBlockAttrOverride(t,i){if(!t||!i)return;const o={...this.attrOverrides.get(t)||{}};for(const[s,l]of Object.entries(i))l===""||l===null||l===void 0?delete o[s]:o[s]=String(l);Object.keys(o).length===0?this.attrOverrides.delete(t):this.attrOverrides.set(t,o)}getBlockAttrOverride(t){return this.attrOverrides.get(t)}getAllAttrOverrides(){return new Map(this.attrOverrides)}getTrackedListSuperBlocks(t){return this.trackedListSuperBlocks.get(t)||[]}clearBlockAttrOverride(t,i){if(!t)return;if(!i){this.attrOverrides.delete(t);return}const n=this.attrOverrides.get(t);n&&(delete n[i],Object.keys(n).length===0&&this.attrOverrides.delete(t))}clearAllOverrides(){this.attrOverrides.clear(),this.trackedListSuperBlocks.clear()}async compile(t){try{const i=await this.deps.getBlockAttrs(t).catch(()=>({}))||{},n=this.attrOverrides.get(t);n&&Object.assign(i,n);const o=await this.deps.getChildBlocks(t).catch(()=>[])||[],s=this.deps.getDocBlocksOrders?await this.deps.getDocBlocksOrders(t).catch(()=>[])||[]:[],l=new Map;for(let O=0;O<s.length;O++)s[O]&&l.set(s[O],O);const r=l.size>0,a=`SELECT id, parent_id, root_id, type, subtype, content, markdown, ial, sort, created FROM blocks WHERE root_id = '${t}' AND id != '${t}' ORDER BY sort ASC, created ASC LIMIT 99999`,c=await this.deps.sql(a).catch(()=>[])||[],d=If(o,c),m=new Map;if(Array.isArray(c))for(const O of c)O.id&&O.ial&&m.set(O.id,Qo(O.ial));const b=`SELECT block_id, name, value FROM attributes WHERE root_id = '${t}' AND type = 'b' LIMIT 99999`,u=await this.deps.sql(b).catch(()=>[])||[];if(Array.isArray(u)){for(const O of u)if(O.block_id&&O.name){let U=m.get(O.block_id);U||(U={},m.set(O.block_id,U)),U[O.name]=O.value||""}}const h=(O,U)=>{const B={...m.get(O)||(U?Qo(U):{})},R=this.attrOverrides.get(O);return R&&Object.assign(B,R),B},f=Array.isArray(c)&&c.length>0?Tf(t,c,h,8,l):null,v=o.map(O=>O.id).filter(Boolean),k=O=>({id:O.id,parent_id:O.parent_id,root_id:O.root_id||t,type:O.type,subType:O.subType,content:O.content||"",markdown:O.markdown||"",ial:h(O.id,O.ial),children:O.children}),S=async(O,U=0)=>{if(!O||U>8||!xs(O))return;const B=await this.deps.getChildBlocks(O.id).catch(()=>[])||[];if(!(!Array.isArray(B)||B.length===0)){O.children=B.filter(R=>R==null?void 0:R.id).map(R=>({id:R.id,parent_id:O.id,root_id:t,type:R.type,subType:R.subType,content:R.content||"",markdown:R.markdown||"",ial:h(R.id,R.ial),children:[]}));for(const R of O.children)await S(R,U+1)}},$=new Map;for(const O of c)O!=null&&O.id&&$.set(O.id,O);const T=v.every(O=>{const U=$.get(O);return!U||!!U.type});let D=[],E=!1;if(f&&d.usable&&r&&T){this.fallbackWarnedDocId="";for(const[U,B]of d.leafPatch){const R=f.byId.get(U);R&&(R.content=B.content,R.markdown=B.markdown)}const O=new Map;for(const U of o)U!=null&&U.id&&O.set(U.id,U);for(const U of d.rebuildRoots){const B=f.byId.get(U),R=O.get(U);B&&R&&(B.content=R.content||"",B.markdown=R.markdown||""),await S(B)}for(const U of o){if(!(U!=null&&U.id)||f.byId.has(U.id))continue;const B=k(U);await S(B),f.byId.set(B.id,B),f.topLevel.push(B)}D=f.topLevel.filter(U=>l.has(U.id)).sort((U,B)=>(l.get(U.id)??0)-(l.get(B.id)??0))}else v.length>0?(E=!0,this.fallbackWarnedDocId!==t&&(this.fallbackWarnedDocId=t,console.warn(`[DocumentCompiler] 索引结构不可用，回退逐容器查询（较慢）doc=${t} 实时顶层=${v.length} 索引行=${c.length} 文档序=${s.length} 原因=${d.reason||"缺少实时文档序"}`)),D=o.map(O=>k(O))):f&&(D=f.topLevel);const x=async(O,U=0)=>{if(!(!O||O.length===0||U>8))for(const B of O){if(xs(B)&&(!B.children||B.children.length===0)){let F=await this.deps.getChildBlocks(B.id).catch(()=>[]);if(!F||F.length===0){const ee=`SELECT id, parent_id, root_id, type, subtype as subType, content, markdown, ial FROM blocks WHERE parent_id = '${B.id}' ORDER BY sort ASC, created ASC`;F=await this.deps.sql(ee).catch(()=>[])||[]}if(Array.isArray(F)&&F.length>0){const ee=new Set(D.map(M=>M.id)),I=F.filter(M=>M.id!==B.id&&!ee.has(M.id));I.length>0&&(B.children=I.map(M=>{const J=m.get(M.id)||(M.ial?Qo(M.ial):{}),Y=this.attrOverrides.get(M.id);return Y&&Object.assign(J,Y),{id:M.id,parent_id:M.parent_id||B.id,root_id:M.root_id||t,type:M.type,subType:M.subType,content:M.content||"",markdown:M.markdown||"",ial:J}}))}}B.children&&B.children.length>0&&await x(B.children,U+1)}};E&&await x(D);const W=O=>{var U,B;for(const R of O)if(R.children&&R.children.length>0){W(R.children);for(const F of R.children)if(F.ial)for(const[ee,I]of Object.entries(F.ial))ee.startsWith("custom-slidev-")&&!((U=R.ial)!=null&&U[ee])&&(R.ial||(R.ial={}),R.ial[ee]=I);if(R.ial){for(const[F,ee]of Object.entries(R.ial))if(F.startsWith("custom-slidev-"))for(const I of R.children)(I.type==="video"||I.type==="NodeVideo"||/<video\b/i.test(I.markdown||I.content||""))&&!((B=I.ial)!=null&&B[F])&&(I.ial||(I.ial={}),I.ial[F]=ee)}}};W(D),bf(D,O=>{const U={[ge]:O.layout};this.setBlockAttrOverride(O.blockId,U),(this.deps.setBlockAttrs||De)(O.blockId,U).catch(R=>{console.warn("[DocumentCompiler] Failed to auto-tag superblock image layout:",R)})});const V=this.trackedListSuperBlocks.get(t)||[],G=vf(t,D,{tracked:V,onTagChange:O=>{this.setBlockAttrOverride(O.blockId,O.attrs),O.blockId===t&&Object.assign(i,O.attrs);const U=R=>{for(const F of R)F.id===O.blockId&&(F.ial||(F.ial={}),Object.assign(F.ial,O.attrs)),F.children&&F.children.length>0&&U(F.children)};U(D),(this.deps.setBlockAttrs||De)(O.blockId,O.attrs).catch(R=>{console.warn("[DocumentCompiler] Failed to auto-tag list superblock attrs:",R)})}});this.trackedListSuperBlocks.set(t,G.newTracked);const X=new Set;for(const O of D){const U=O.markdown||O.content||"";if(U.includes("((")){const B=Mc(U);for(const R of B)X.add(R.blockId)}}const C={};if(X.size>0){const O=Array.from(X).map(B=>`'${B}'`).join(","),U=await this.deps.sql(`SELECT id, content, markdown FROM blocks WHERE id IN (${O})`).catch(()=>[])||[];if(Array.isArray(U))for(const B of U)B.id&&(C[B.id]=B.markdown||B.content||"")}const P=this.deps.getBaseUrl?this.deps.getBaseUrl():"",y=zr(t,i,D,{baseUrl:P,refContentMap:C});try{const O=this.deps.getInlineStyles?await this.deps.getInlineStyles().catch(()=>null):null;y.customThemeCss=_n(O)}catch{y.customThemeCss=_n(null)}return y}catch(i){console.error("[DocumentCompilerService] Failed to compile document:",i);const n=zr(t,{},[],{});return n.customThemeCss=_n(null),n}}}const Be=new Bf;class qs{constructor(t){ke(this,"devServerUrl","http://localhost:3030");ke(this,"isConnected",!1);ke(this,"lastSyncTime",null);t&&(this.devServerUrl=t)}getUrl(){return this.devServerUrl}setUrl(t){this.devServerUrl=t.replace(/\/+$/,"")}isServerConnected(){return this.isConnected}getLastSyncTime(){return this.lastSyncTime}async probeServer(t=1500){try{const i=new AbortController,n=setTimeout(()=>i.abort(),t),o=await fetch(this.devServerUrl,{method:"HEAD",mode:"no-cors",signal:i.signal}).catch(()=>null);return clearTimeout(n),this.isConnected=!!o,this.isConnected}catch{return this.isConnected=!1,!1}}buildStandardSlidevMarkdown(t){const i=t.config,n=["---",`theme: ${i.theme||"default"}`,`aspectRatio: "${i.aspectRatio||"16/9"}"`,`highlighter: ${i.highlighter||"shiki"}`,`transition: ${i.defaultTransition||"slide-left"}`];i.colorSchema&&i.colorSchema!=="auto"&&n.push(`colorSchema: ${i.colorSchema}`),n.push("drawings:","  persist: false","---","");const o=n.join(`
`),s=t.slides.map((r,a)=>{const c=r.frontmatter||{},d=[],m=a===0;c.layout&&c.layout!=="default"&&d.push(`layout: ${c.layout}`),c.transition&&d.push(`transition: ${c.transition}`),c.background&&d.push(`background: ${c.background}`),c.class&&d.push(`class: "${c.class}"`);let b="";d.length>0?b=m?"":`---
${d.join(`
`)}
---

`:m||(b=`---

`);let u="";if(c.layout==="two-cols"){const f=r.blocks.filter($=>$.slot!=="right"),v=r.blocks.filter($=>$.slot==="right"),k=f.map($=>$.rawMarkdown||$.content||"").join(`

`),S=v.map($=>$.rawMarkdown||$.content||"").join(`

`);u=`${k}

::right::

${S}`}else u=r.blocks.map(f=>f.rawMarkdown||f.content||"").join(`

`);let h="";return r.notes&&r.notes.trim()&&(h=`

<!--
${r.notes.trim()}
-->`),`${b}${u}${h}`}).join(`

`);let l="";return t.config.normalizeHeadingSizes&&(l=`

<style>
/* Specific Heading Normalization */
.slidev-layout:not(.cover) > :is(h1, h2, h3, h4, h5, h6):first-child {
  font-size: 1.7rem !important;
}
.two-cols-header-top :is(h1, h2, h3, h4, h5, h6),
.cols-header-top :is(h1, h2, h3, h4, h5, h6),
.layout-header-section :is(h1, h2, h3, h4, h5, h6) {
  font-size: 1.7rem !important;
}
:is(.two-cols-left, .two-cols-right, .col, .col-1, .col-2, .col-3, .three-cols-col) > :is(h1, h2, h3, h4, h5, h6):first-child {
  font-size: 1.3rem !important;
}
</style>`),`${o}${s}${l}
`}async syncToWorkspaceFile(t,i="/data/storage/petal/siyuan-slidev/slides.md",n){const o=this.buildStandardSlidevMarkdown(t);if(this.lastSyncTime=Date.now(),n)try{const s=typeof Blob<"u"?new Blob([o],{type:"text/markdown;charset=utf-8"}):Buffer.from(o,"utf-8");return await n(i,!1,s),{success:!0,path:i}}catch(s){return{success:!1,path:i,error:String(s)}}return{success:!0,path:i}}downloadSlidesMd(t,i="slides.md"){if(typeof window>"u"||typeof document>"u")return!1;const n=this.buildStandardSlidevMarkdown(t),o=new Blob([n],{type:"text/markdown;charset=utf-8"}),s=URL.createObjectURL(o),l=document.createElement("a");return l.href=s,l.download=i,document.body.appendChild(l),l.click(),document.body.removeChild(l),URL.revokeObjectURL(s),!0}}function Mf(){if(typeof window<"u"&&typeof window.require=="function")return window.require.bind(window);if(typeof globalThis<"u"&&typeof globalThis.require=="function")return globalThis.require.bind(globalThis);if(typeof require=="function")return require}function _t(e){const t=Mf();if(t)try{return t(e)}catch{try{const i=e.startsWith("node:")?e.slice(5):`node:${e}`;return t(i)}catch{}}}function Gs(){var t;if(typeof window<"u"&&window.process)return window.process;const e=_t("process");return e&&e.versions?e:typeof process<"u"&&((t=process.versions)!=null&&t.node)?process:globalThis.process}function ba(){var t,i;const e=Gs();if(e&&((t=e.versions)!=null&&t.node))return!0;if(typeof window<"u"&&window.siyuan){const n=_t("child_process");if(n&&typeof n.spawn=="function")return!0}return!!(typeof process<"u"&&((i=process.versions)!=null&&i.node))}function Df(){if(typeof window>"u"||!window.location)return!1;try{return new URLSearchParams(window.location.search).get("remote")==="1"}catch{return!1}}function Pn(){const e=Gs();if(e!=null&&e.platform)return e.platform;if(typeof process<"u"&&process.platform)return process.platform;const t=_t("os");if(t&&typeof t.platform=="function")return t.platform();if(typeof navigator<"u"){const i=navigator.userAgent.toLowerCase();if(i.includes("win"))return"win32";if(i.includes("mac"))return"darwin";if(i.includes("linux"))return"linux"}return"web"}function ya(){var n,o;const e=Gs(),t={...(e==null?void 0:e.env)||{}};if(Pn()==="win32"){const s=["C:\\Program Files\\nodejs","C:\\Program Files (x86)\\nodejs",(n=e==null?void 0:e.env)!=null&&n.APPDATA?`${e.env.APPDATA}\\npm`:"",(o=e==null?void 0:e.env)!=null&&o.USERPROFILE?`${e.env.USERPROFILE}\\AppData\\Roaming\\npm`:""].filter(Boolean),l=Object.keys(t).find(c=>c.toLowerCase()==="path")||"PATH",a=(t[l]||"").split(";").filter(Boolean);for(const c of s)c&&!a.some(d=>d.toLowerCase()===c.toLowerCase())&&a.push(c);t[l]=a.join(";")}return t}function Ss(e){var i,n,o;if(!e)return"";if(/^[a-zA-Z]:[/\\]/.test(e))return e.replace(/\\/g,"/");let t="";if(typeof window<"u"&&((o=(n=(i=window.siyuan)==null?void 0:i.config)==null?void 0:n.system)!=null&&o.dataDir)&&(t=window.siyuan.config.system.dataDir.replace(/\\/g,"/")),t&&e.startsWith("/data/")){const s=e.slice(6);return`${t}/${s}`.replace(/\\/g,"/")}return e}function Lf(){const e=_t("os"),t=_t("path");if(e&&typeof e.tmpdir=="function"){const i=e.tmpdir();return t&&typeof t.join=="function"?t.join(i,"siyuan-slidev-pro").replace(/\\/g,"/"):`${i}/siyuan-slidev-pro`.replace(/\\/g,"/")}return"/data/storage/petal/siyuan-slidev/pro-workspace"}class Zs{constructor(t){ke(this,"runner");this.runner=t||Zs.defaultRunner}static async defaultRunner(t,i){var n;try{let o=(n=_t("child_process"))==null?void 0:n.execFile;if(!o){const a=await import("node:child_process").catch(()=>({}));o=a==null?void 0:a.execFile}if(!o)return{code:-1,stdout:"",stderr:"child_process execFile not available"};const l=Pn()==="win32",r=ya();return await new Promise(a=>{o(t,i,{timeout:5e3,shell:l,env:r},(c,d,m)=>{a({code:c?c.code||1:0,stdout:d?String(d).trim():"",stderr:m?String(m).trim():""})})})}catch(o){return{code:-1,stdout:"",stderr:String(o)}}}async detect(){const t=ba(),i=Pn();if(!t)return{hasNode:!1,hasSlidevCli:!1,platform:"browser",isDesktop:!1,error:"当前处于纯前端浏览器或移动端环境，无 Node.js 运行时支撑"};let n=!1,o,s=!1,l;try{const r=await this.runner("node",["-v"]);r.code===0&&r.stdout.startsWith("v")&&(n=!0,o=r.stdout)}catch{}if(n){try{const r=i==="win32"?"slidev.cmd":"slidev",a=await this.runner(r,["--version"]);a.code===0&&a.stdout&&(s=!0,l=a.stdout)}catch{}if(!s)try{const r=i==="win32"?"npx.cmd":"npx",a=await this.runner(r,["@slidev/cli","--version"]);a.code===0&&a.stdout&&(s=!0,l=a.stdout)}catch{}}return{hasNode:n,nodeVersion:o,hasSlidevCli:s,slidevVersion:l,platform:i,isDesktop:t}}}class Of{constructor(){ke(this,"iframe",null);ke(this,"isReady",!1);ke(this,"pageChangedHandlers",[]);ke(this,"readyHandlers",[]);ke(this,"currentState",{no:1,clicks:0,total:1});this.handleWindowMessage=this.handleWindowMessage.bind(this)}getCurrentState(){return{...this.currentState}}attach(t){this.detach(),this.iframe=t,this.isReady=!1,typeof window<"u"&&window.addEventListener("message",this.handleWindowMessage)}detach(){typeof window<"u"&&window.removeEventListener("message",this.handleWindowMessage),this.iframe=null,this.isReady=!1}postMessage(t,i){var o;if(!((o=this.iframe)!=null&&o.contentWindow))return;const n={target:"slidev",sender:"siyuan",type:t,...i};try{this.iframe.contentWindow.postMessage(n,"*")}catch(s){console.warn("[NativeSlidevBridge] postMessage error:",s)}}navigateToPage(t){this.postMessage("navigate",{no:t})}next(){this.postMessage("next")}prev(){this.postMessage("prev")}nextClick(){this.postMessage("next-click")}prevClick(){this.postMessage("prev-click")}onPageChanged(t){return this.pageChangedHandlers.push(t),()=>{this.pageChangedHandlers=this.pageChangedHandlers.filter(i=>i!==t)}}onReady(t){return this.readyHandlers.push(t),()=>{this.readyHandlers=this.readyHandlers.filter(i=>i!==t)}}handleWindowMessage(t){const i=t.data;if(!(!i||i.target!=="slidev")){if(!this.isReady){this.isReady=!0;for(const n of this.readyHandlers)n()}if(i.type==="update-state"&&i.navState){const n=i.navState;this.currentState={no:n.no??this.currentState.no,clicks:n.clicks??this.currentState.clicks,total:n.total??this.currentState.total,hasNext:n.hasNext,hasPrev:n.hasPrev};for(const o of this.pageChangedHandlers)o(this.currentState.no,this.currentState.total||1,this.currentState)}else if(i.type==="navigate"&&typeof i.no=="number"){this.currentState.no=i.no;for(const n of this.pageChangedHandlers)n(i.no,this.currentState.total||1,this.currentState)}}}}class Rf{constructor(t){ke(this,"childProcess",null);ke(this,"activePort",null);ke(this,"isRunning",!1);ke(this,"defaultPort");ke(this,"maxPortRetries");ke(this,"probeTimeoutMs");ke(this,"customSpawner");ke(this,"customPortChecker");this.defaultPort=(t==null?void 0:t.defaultPort)||3030,this.maxPortRetries=(t==null?void 0:t.maxPortRetries)||20,this.probeTimeoutMs=(t==null?void 0:t.probeTimeoutMs)||1e4,this.customSpawner=t==null?void 0:t.customSpawner,this.customPortChecker=t==null?void 0:t.customPortChecker}getActivePort(){return this.activePort}getIsRunning(){return this.isRunning}async isPortAvailable(t){if(this.customPortChecker)return this.customPortChecker(t);try{let i=_t("net");return i||(i=await import("node:net").catch(()=>({}))),i!=null&&i.createServer?await new Promise(n=>{const o=i.createServer();o.once("error",()=>n(!1)),o.once("listening",()=>{o.close(()=>n(!0))}),o.listen(t,"127.0.0.1")}):!0}catch{return!0}}async allocPort(t){const i=t||this.defaultPort;for(let n=0;n<this.maxPortRetries;n++){const o=i+n;if(await this.isPortAvailable(o))return o}return i}async pollServerReady(t,i=8e3,n=300){const o=Date.now();for(;Date.now()-o<i;){try{const s=new AbortController,l=setTimeout(()=>s.abort(),n),r=await fetch(t,{method:"HEAD",mode:"no-cors",signal:s.signal}).catch(()=>null);if(clearTimeout(l),r)return!0}catch{}await new Promise(s=>setTimeout(s,n))}return!1}async startServer(t,i){var a,c;if(this.isRunning&&this.activePort)return{success:!0,port:this.activePort,url:`http://localhost:${this.activePort}?embedded=true`};const n=await this.allocPort(i);this.activePort=n;const s=Pn()==="win32"?"npx.cmd":"npx",l=Ss(t),r=["@slidev/cli",l,"--port",String(n),"--no-open"];try{if(this.customSpawner)this.childProcess=this.customSpawner(s,r,{detached:!1});else{let m=(a=_t("child_process"))==null?void 0:a.spawn;if(!m){const h=await import("node:child_process").catch(()=>({}));m=h==null?void 0:h.spawn}if(!m)throw new Error("child_process spawn not available in current runtime");const b=l.includes("/")||l.includes("\\")?l.replace(/[/\\][^/\\]+$/,""):void 0,u=ya();this.childProcess=m(s,r,{cwd:b,detached:!1,shell:!0,env:{...u,FORCE_COLOR:"1"}})}this.isRunning=!0,(c=this.childProcess)!=null&&c.on&&this.childProcess.on("exit",()=>{this.isRunning=!1,this.activePort=null,this.childProcess=null});const d=`http://localhost:${n}`;return!this.customSpawner&&!await this.pollServerReady(d,this.probeTimeoutMs)?(this.stopServer(),{success:!1,port:n,url:"",error:`Slidev DevServer 启动超时 (未在 ${this.probeTimeoutMs}ms 内响应端口 ${n})`}):{success:!0,port:n,url:`${d}?embedded=true`}}catch(d){return this.stopServer(),{success:!1,port:n,url:"",error:`唤起 Slidev 进程失败: ${String(d)}`}}}stopServer(){var t;if(this.childProcess){try{if(this.childProcess.kill("SIGTERM"),Pn()==="win32"&&this.childProcess.pid&&!this.customSpawner){const n=(t=_t("child_process"))==null?void 0:t.exec;n?n(`taskkill /pid ${this.childProcess.pid} /T /F`,()=>{}):import("node:child_process").then(({exec:o})=>{var s;o(`taskkill /pid ${(s=this.childProcess)==null?void 0:s.pid} /T /F`,()=>{})}).catch(()=>{})}}catch{}this.childProcess=null}this.isRunning=!1,this.activePort=null}}class Ys{constructor(){ke(this,"iframe",null);ke(this,"isReady",!1);ke(this,"pendingMessages",[]);ke(this,"slideChangedHandlers",[]);ke(this,"blockClickedHandlers",[]);ke(this,"openInEditorHandlers",[]);ke(this,"clientReadyHandlers",[]);ke(this,"openPeekDrawerHandlers",[]);ke(this,"toggleFullscreenHandlers",[]);this.handleWindowMessage=this.handleWindowMessage.bind(this)}attach(t){this.detach(),this.iframe=t,this.isReady=!1,typeof window<"u"&&window.addEventListener("message",this.handleWindowMessage)}detach(){typeof window<"u"&&window.removeEventListener("message",this.handleWindowMessage),this.iframe=null,this.isReady=!1,this.pendingMessages=[]}postMessage(t,i){var o;const n={source:"siyuan-slidev-host",action:t,payload:i};if(!((o=this.iframe)!=null&&o.contentWindow)||!this.isReady){this.pendingMessages.push(n);return}try{this.iframe.contentWindow.postMessage(n,"*")}catch(s){console.warn("[WebSandboxBridge] postMessage error:",s)}}updateSlides(t,i,n,o){this.postMessage("UPDATE_SLIDES",{slides:t,config:i,fullMarkdown:n,customThemeCss:o})}navigatePage(t){this.postMessage("NAVIGATE_PAGE",{pageIndex:t})}highlightElement(t){this.postMessage("HIGHLIGHT_ELEMENT",{targetBlockId:t})}nextStep(){this.postMessage("NEXT_STEP",{})}prevStep(){this.postMessage("PREV_STEP",{})}freezeKeyboardNav(t){this.postMessage("FREEZE_KEYBOARD_NAV",{frozen:t})}toggleOverview(){this.postMessage("TOGGLE_OVERVIEW",{})}onSlideChanged(t){return this.slideChangedHandlers.push(t),()=>{this.slideChangedHandlers=this.slideChangedHandlers.filter(i=>i!==t)}}onBlockClicked(t){return this.blockClickedHandlers.push(t),()=>{this.blockClickedHandlers=this.blockClickedHandlers.filter(i=>i!==t)}}onOpenInEditor(t){return this.openInEditorHandlers.push(t),()=>{this.openInEditorHandlers=this.openInEditorHandlers.filter(i=>i!==t)}}onOpenPeekDrawer(t){return this.openPeekDrawerHandlers.push(t),()=>{this.openPeekDrawerHandlers=this.openPeekDrawerHandlers.filter(i=>i!==t)}}onRequestToggleFullscreen(t){return this.toggleFullscreenHandlers.push(t),()=>{this.toggleFullscreenHandlers=this.toggleFullscreenHandlers.filter(i=>i!==t)}}onClientReady(t){return this.clientReadyHandlers.push(t),()=>{this.clientReadyHandlers=this.clientReadyHandlers.filter(i=>i!==t)}}handleWindowMessage(t){var n;const i=t.data;if(!(!i||i.source!=="siyuan-slidev-client"))switch(i.action){case"CLIENT_READY":for(this.isReady=!0;this.pendingMessages.length>0;){const o=this.pendingMessages.shift();o&&((n=this.iframe)!=null&&n.contentWindow)&&this.iframe.contentWindow.postMessage(o,"*")}for(const o of this.clientReadyHandlers)o();break;case"SLIDE_CHANGED":if(i.payload.currentPage!==void 0)for(const o of this.slideChangedHandlers)o(i.payload.currentPage,i.payload.totalPages||1,i.payload.currentBlockId||"");break;case"BLOCK_CLICKED":if(i.payload.clickedBlockId)for(const o of this.blockClickedHandlers)o(i.payload.clickedBlockId,i.payload.currentPage||1);break;case"OPEN_IN_EDITOR":if(i.payload.blockId||i.payload.clickedBlockId){const o=i.payload.blockId||i.payload.clickedBlockId||"";for(const s of this.openInEditorHandlers)s(o,i.payload.currentPage||1)}break;case"OPEN_PEEK_DRAWER":if(i.payload.peekType){const o=i.payload.blockId||i.payload.url||"",s={peekType:i.payload.peekType,target:o,title:i.payload.title};for(const l of this.openPeekDrawerHandlers)l(s)}break;case"REQUEST_TOGGLE_FULLSCREEN":for(const o of this.toggleFullscreenHandlers)o();break}}}const ka={"snippets/external.ts":`// Inside ./snippets/external.ts
// #region snippet
export function emptyArray<T>(length: number) {
  return Array.from<T>({ length })
}
// #endregion snippet

export function sayHello() {
  console.log('Hello from snippets/external.ts')
}
`},Pf=`<script setup lang="ts">
import { computed, useSlots } from 'vue'

const props = defineProps({
  layoutRatio: {
    type: String,
    default: '',
  },
  cols: {
    type: [Number, String],
    default: 0,
  },
})

const slots = useSlots()

const detectedColsCount = computed(() => {
  const explicitCols = Number(props.cols)
  if (explicitCols >= 2 && explicitCols <= 6) return explicitCols
  const r = (props.layoutRatio || '').trim()
  if (r.includes(':')) {
    const parts = r.split(':').map(p => parseFloat(p.trim())).filter(n => !isNaN(n) && n > 0)
    if (parts.length >= 2) return Math.min(parts.length, 6)
  }
  const tokens = r.split(/\\s+/).filter(Boolean)
  if (tokens.length >= 2) return Math.min(tokens.length, 6)
  for (let i = 6; i >= 3; i--) {
    if (slots[\`col-\${i}\`]) return i
  }
  if (slots['col-2'] || slots['right']) return 2
  return 2
})

const gridStyle = computed(() => {
  const r = props.layoutRatio || ''
  if (r) {
    if (r.includes(':')) {
      const parts = r.split(':').map(p => parseFloat(p.trim())).filter(n => !isNaN(n) && n > 0)
      if (parts.length >= 2) {
        return { gridTemplateColumns: parts.map(n => \`\${n}fr\`).join(' ') }
      }
    }
    const tokens = r.split(/\\s+/).filter(Boolean)
    if (tokens.length >= 2) {
      return { gridTemplateColumns: tokens.join(' ') }
    }
  }
  return { gridTemplateColumns: \`repeat(\${detectedColsCount.value}, minmax(0, 1fr))\` }
})
<\/script>

<template>
  <div class="slidev-layout cols-header w-full h-full flex flex-col">
    <div class="header-section mb-4 w-full">
      <slot />
    </div>
    <div class="grid gap-6 flex-1 items-stretch" :style="gridStyle">
      <div v-if="detectedColsCount >= 1" class="col-1 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-1"><slot name="left" /></slot>
      </div>
      <div v-if="detectedColsCount >= 2" class="col-2 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-2"><slot v-if="detectedColsCount === 2" name="right" /></slot>
      </div>
      <div v-if="detectedColsCount >= 3" class="col-3 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-3" />
      </div>
      <div v-if="detectedColsCount >= 4" class="col-4 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-4" />
      </div>
      <div v-if="detectedColsCount >= 5" class="col-5 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-5" />
      </div>
      <div v-if="detectedColsCount >= 6" class="col-6 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-6" />
      </div>
    </div>
  </div>
</template>
`,Nf=`<script setup lang="ts">
import { computed } from 'vue'

const props = defineProps({
  layoutRatio: {
    type: String,
    default: '',
  },
})

const gridStyle = computed(() => {
  const r = props.layoutRatio || ''
  if (!r) return {}
  if (r.includes(':')) {
    const parts = r.split(':').map(p => parseFloat(p.trim())).filter(n => !isNaN(n) && n > 0)
    if (parts.length >= 2) {
      return { gridTemplateColumns: parts.map(n => \`\${n}fr\`).join(' ') }
    }
  }
  const tokens = r.split(/\\s+/).filter(Boolean)
  if (tokens.length >= 2) {
    return { gridTemplateColumns: tokens.join(' ') }
  }
  return {}
})
<\/script>

<template>
  <div class="slidev-layout three-cols-header w-full h-full flex flex-col">
    <div class="header-section mb-4 w-full">
      <slot />
    </div>
    <div class="grid gap-6 flex-1 items-stretch" :class="gridStyle.gridTemplateColumns ? '' : 'grid-cols-3'" :style="gridStyle">
      <div class="col-1 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-1" />
      </div>
      <div class="col-2 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-2" />
      </div>
      <div class="col-3 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-3" />
      </div>
    </div>
  </div>
</template>
`,zf=`<script setup lang="ts">
import { useSlots } from 'vue'

const slots = useSlots()
<\/script>

<template>
  <div class="slidev-layout clover w-full h-full flex flex-col">
    <div class="header-section mb-4 w-full">
      <slot />
    </div>
    <div class="grid grid-cols-2 grid-rows-2 gap-6 flex-1 items-stretch">
      <div class="col-1 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-1" />
      </div>
      <div class="col-2 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-2" />
      </div>
      <div class="col-3 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-3" />
      </div>
      <div class="col-4 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-4" />
      </div>
    </div>
  </div>
</template>
`,Ff=`// Auto-generated by SiYuan Slidev Studio
// 本地 HTML 链接（思源资产 / 工作区文件 / 绝对文件路径）速览判定
// 注意：需与 public/slidev-client/index.html 中的拦截器保持同步
function isPeekableLocalHtml(href: string): boolean {
  const clean = (href || '').trim()
  if (!clean || clean.startsWith('#') || clean.startsWith('//')) return false
  if (!/\\.html?($|[?#])/i.test(clean)) return false
  if (/^https?:\\/\\//i.test(clean)) return false
  const scheme = /^([a-z][a-z0-9+.-]*):/i.exec(clean)
  if (!scheme) return true
  const schemeName = scheme[1].toLowerCase()
  if (schemeName === 'file') return true
  // Windows 盘符路径（D:\\\\docs\\\\demo.html）并非协议前缀
  return schemeName.length === 1 && /^[a-zA-Z]:[\\\\/]/.test(clean)
}

// 本地 HTML 链接预处理：思源资产统一指向内核 /assets/ 静态服务，其余原样转交宿主归一化
// 不基于 location 绝对化，保证 Pro 模式（Slidev dev server）与沙箱模式行为完全一致
function resolvePeekHref(href: string): string {
  const clean = (href || '').trim()
  if (/^(?:\\.\\/|\\/)?assets\\//.test(clean)) {
    return '/' + clean.replace(/^(?:\\.\\/|\\/)/, '')
  }
  return clean
}

export default function() {
  if (typeof window === 'undefined') return
  window.addEventListener('click', (e: MouseEvent) => {
    const target = e.target as HTMLElement | null
    if (!target || !target.closest) return

    const refEl = target.closest('[data-ref-id]')
    if (refEl) {
      const blockId = refEl.getAttribute('data-ref-id')
      if (blockId) {
        e.preventDefault()
        e.stopPropagation()
        window.parent.postMessage({
          source: 'siyuan-slidev-client',
          action: 'OPEN_PEEK_DRAWER',
          payload: { peekType: 'siyuan', blockId, title: (refEl.innerText || refEl.title || '').trim() }
        }, '*')
        return
      }
    }

    const linkEl = target.closest('a') as HTMLAnchorElement | null
    if (linkEl) {
      const href = linkEl.getAttribute('href') || ''
      if (href.startsWith('siyuan://blocks/')) {
        e.preventDefault()
        e.stopPropagation()
        const cleanBlockId = href.replace('siyuan://blocks/', '').split('?')[0]
        window.parent.postMessage({
          source: 'siyuan-slidev-client',
          action: 'OPEN_PEEK_DRAWER',
          payload: { peekType: 'siyuan', blockId: cleanBlockId, title: (linkEl.innerText || linkEl.title || '').trim() }
        }, '*')
      } else if (/^https?:\\/\\//i.test(href)) {
        e.preventDefault()
        e.stopPropagation()
        window.parent.postMessage({
          source: 'siyuan-slidev-client',
          action: 'OPEN_PEEK_DRAWER',
          payload: { peekType: 'web', url: href, title: (linkEl.innerText || linkEl.title || '').trim() }
        }, '*')
      } else if (isPeekableLocalHtml(href)) {
        e.preventDefault()
        e.stopPropagation()
        window.parent.postMessage({
          source: 'siyuan-slidev-client',
          action: 'OPEN_PEEK_DRAWER',
          payload: { peekType: 'web', url: resolvePeekHref(href), title: (linkEl.innerText || linkEl.title || '').trim() }
        }, '*')
      }
    }
  }, true)
}
`,Hf=`${ws}

/* Auto-generated by SiYuan Slidev Studio */
.slidev-ref-tag,
a.slidev-ref-tag {
  display: inline-flex;
  align-items: center;
  background: color-mix(in srgb, var(--slidev-theme-primary, #10b981) 12%, transparent);
  color: var(--slidev-theme-primary, #10b981);
  border-radius: 4px;
  padding: 2px 8px;
  font-size: 0.88em;
  text-decoration: none;
  border: 1px solid color-mix(in srgb, var(--slidev-theme-primary, #10b981) 25%, transparent);
  cursor: pointer;
  transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
  user-select: none;
}

.slidev-ref-tag:hover,
a.slidev-ref-tag:hover {
  background: color-mix(in srgb, var(--slidev-theme-primary, #10b981) 22%, transparent);
  color: var(--slidev-theme-primary, #10b981);
  border-color: color-mix(in srgb, var(--slidev-theme-primary, #10b981) 55%, transparent);
  transform: translateY(-1px);
  box-shadow: 0 2px 8px color-mix(in srgb, var(--slidev-theme-primary, #10b981) 20%, transparent);
}

.slidev-block-ref {
  display: block;
  padding: 10px 14px;
  background: color-mix(in srgb, var(--slidev-theme-primary, #10b981) 8%, transparent);
  border-left: 3px solid var(--slidev-theme-primary, #10b981);
  border-radius: 0 6px 6px 0;
  margin: 8px 0;
  cursor: pointer;
  transition: background 0.2s ease;
}

.slidev-block-ref:hover {
  background: color-mix(in srgb, var(--slidev-theme-primary, #10b981) 15%, transparent);
}

/* 代码块自动换行与无横向滚动条 */
pre,
pre code {
  white-space: pre-wrap !important;
  word-break: break-all !important;
  overflow-wrap: anywhere !important;
  overflow-x: hidden !important;
  overflow-y: auto !important;
  max-width: 100% !important;
  box-sizing: border-box !important;
}

/* 弱提示滚动条样式 */
* {
  scrollbar-width: thin;
}
html:not(.dark) * {
  scrollbar-color: rgba(0, 0, 0, 0.15) transparent;
}
html.dark * {
  scrollbar-color: rgba(255, 255, 255, 0.20) transparent;
}
*::-webkit-scrollbar {
  width: 4px;
  height: 4px;
}
*::-webkit-scrollbar-track {
  background: transparent;
}
html:not(.dark) *::-webkit-scrollbar-thumb {
  background: rgba(0, 0, 0, 0.15);
  border-radius: 2px;
}
html:not(.dark) *:hover::-webkit-scrollbar-thumb,
html:not(.dark) *::-webkit-scrollbar-thumb:hover {
  background: rgba(0, 0, 0, 0.35);
}
html.dark *::-webkit-scrollbar-thumb {
  background: rgba(255, 255, 255, 0.20);
  border-radius: 2px;
}
html.dark *:hover::-webkit-scrollbar-thumb,
html.dark *::-webkit-scrollbar-thumb:hover {
  background: rgba(255, 255, 255, 0.45);
}

/* 多媒体（GIF动图、静态图片、MP4视频）最大化自适应且不超出视口：顶部对齐，横向居中 */
.slidev-layout img,
.slidev-layout video {
  max-width: 100% !important;
  max-height: 100% !important;
  width: auto;
  height: auto;
  object-fit: contain !important;
}
.three-cols-header video,
.two-cols-header video,
.grid-cols-3 video,
.grid-cols-2 video,
.col-1 video,
.col-2 video,
.col-3 video {
  width: auto !important;
  height: auto !important;
  max-width: 100% !important;
  max-height: 100% !important;
  object-fit: contain !important;
  display: block !important;
  margin: 0 auto !important;
}
.slide-list-media {
  display: flex !important;
  flex-direction: column !important;
  align-items: center !important;
  justify-content: flex-start !important;
  margin-top: 4px !important;
  margin-bottom: 4px !important;
  width: 100% !important;
  max-width: 100% !important;
  height: 100% !important;
  max-height: 100% !important;
  flex: 1 1 0% !important;
  overflow: hidden !important;
}
.slide-list-media img,
.slide-list-media video,
.slide-list-media .list-item-gif {
  width: auto !important;
  height: auto !important;
  max-width: 100% !important;
  max-height: 100% !important;
  object-fit: contain !important;
  border-radius: 6px !important;
  box-shadow: 0 3px 12px rgba(0, 0, 0, 0.14) !important;
  display: block !important;
  margin: 0 auto !important;
}
.slide-video-container {
  display: flex !important;
  flex-direction: column !important;
  justify-content: flex-start !important;
  align-items: center !important;
  width: 100% !important;
  max-height: 100% !important;
  margin: 6px 0 !important;
}
.slide-video-player {
  max-width: 100% !important;
  max-height: 100% !important;
  object-fit: contain !important;
  border-radius: 8px !important;
}

/* 两栏与多栏（超级块分栏）布局：紧凑自然行距，子列表保留圆点与层级缩进 */
.cols-header ul,
.three-cols-header ul,
.two-cols-header ul,
.two-cols ul,
.col-1 ul,
.col-2 ul,
.col-3 ul,
.col-4 ul,
.col-5 ul,
.col-6 ul,
.grid-cols-2 ul,
.grid-cols-3 ul {
  list-style: disc !important;
  list-style-type: disc !important;
  padding-left: 1.25em !important;
  margin-left: 0 !important;
  margin-top: 0 !important;
  margin-bottom: 8px !important;
  flex: 0 0 auto !important;
  height: auto !important;
  display: block !important;
}
.cols-header ol,
.three-cols-header ol,
.two-cols-header ol,
.two-cols ol,
.col-1 ol,
.col-2 ol,
.col-3 ol,
.col-4 ol,
.col-5 ol,
.col-6 ol,
.grid-cols-2 ol,
.grid-cols-3 ol {
  list-style: decimal !important;
  list-style-type: decimal !important;
  padding-left: 1.25em !important;
  margin-left: 0 !important;
  margin-top: 0 !important;
  margin-bottom: 8px !important;
  flex: 0 0 auto !important;
  height: auto !important;
  display: block !important;
}
.cols-header li,
.three-cols-header li,
.two-cols-header li,
.two-cols li,
.col-1 li,
.col-2 li,
.col-3 li,
.col-4 li,
.col-5 li,
.col-6 li,
.grid-cols-2 li,
.grid-cols-3 li {
  padding-left: 0.2em !important;
  margin-left: 0 !important;
  margin-bottom: 6px !important;
  flex: 0 0 auto !important;
  height: auto !important;
  display: list-item !important;
  line-height: 1.6 !important;
}
.cols-header ul ul,
.three-cols-header ul ul,
.two-cols-header ul ul,
.two-cols ul ul,
.col-1 ul ul,
.col-2 ul ul,
.col-3 ul ul,
.col-4 ul ul,
.col-5 ul ul,
.col-6 ul ul {
  list-style: circle !important;
  list-style-type: circle !important;
  padding-left: 1.25em !important;
  margin-top: 4px !important;
  margin-bottom: 4px !important;
}

/* 列表项内嵌标题与说明排版 */
.slide-list-item-title,
li > h1,
li > h2,
li > h3,
li > h4,
li > h5,
li > h6 {
  margin-top: 2px !important;
  margin-bottom: 6px !important;
  line-height: 1.35 !important;
  font-weight: 700 !important;
}
li > h1 { font-size: 1.6rem !important; }
li > h2 { font-size: 1.4rem !important; }
li > h3 { font-size: 1.22rem !important; }
li > h4 { font-size: 1.1rem !important; }
.slide-list-item-desc,
li > p {
  margin-top: 4px !important;
  margin-bottom: 6px !important;
  font-size: 1.05rem;
  line-height: 1.55;
  opacity: 0.92;
}
`;function jf(e){var o;const t=[],i=/^[ \t]*<<<[ \t]+(?:@\/|\.\/|)([^\s#]+)(?:#[^\s]+)?/gm;let n;for(;(n=i.exec(e))!==null;){const s=(o=n[1])==null?void 0:o.trim();s&&!t.includes(s)&&t.push(s)}return t}class Wf{constructor(t){ke(this,"workspacePath");ke(this,"slidesFileName");ke(this,"cliBridge",new qs);const i=Lf();!(t!=null&&t.workspacePath)||t.workspacePath.includes("/data/storage/petal/siyuan-slidev/pro-workspace")?this.workspacePath=i:this.workspacePath=t.workspacePath,this.slidesFileName=(t==null?void 0:t.slidesFileName)||"slides.md"}getWorkspacePath(){return this.workspacePath}getSlidesPath(){return`${this.workspacePath}/${this.slidesFileName}`}generatePackageJson(t="default"){const i={name:"siyuan-slidev-pro-workspace",type:"module",private:!0,scripts:{dev:"slidev --port 3030",build:"slidev build"},dependencies:{"@slidev/cli":"^53.0.0","@slidev/theme-default":"latest"}};return t&&t!=="default"&&(i.dependencies[`@slidev/theme-${t}`]="latest"),JSON.stringify(i,null,2)}buildSlidesMarkdown(t){return this.cliBridge.buildStandardSlidevMarkdown(t)}async scaffold(t,i){const n=this.buildSlidesMarkdown(t),o=this.generatePackageJson(t.config.theme),s=this.getSlidesPath(),l=`${this.workspacePath}/package.json`,r=Ss(s),a=Ss(l),c=jf(n);c.includes("snippets/external.ts")||c.push("snippets/external.ts");const d=new Map;for(const $ of c){const T=ka[$]||`// Auto-generated snippet placeholder for SiYuan Slidev
// #region snippet
// ${$}
// #endregion snippet
`;d.set($,T)}t.slides.some($=>{var T;return((T=$.frontmatter)==null?void 0:T.layout)==="cols-header"})&&d.set("layouts/cols-header.vue",Pf),t.slides.some($=>{var T;return((T=$.frontmatter)==null?void 0:T.layout)==="three-cols-header"})&&d.set("layouts/three-cols-header.vue",Nf),t.slides.some($=>{var T;return((T=$.frontmatter)==null?void 0:T.layout)==="clover"})&&d.set("layouts/clover.vue",zf),d.set("setup/root.ts",Ff),d.set("styles/index.css",Hf);const h=_t("fs"),f=_t("path");let v=!1;const k=f!=null&&f.dirname?f.dirname(r):"",S=/^[a-zA-Z]:[/\\]/.test(r)||r.includes("siyuan-slidev-pro");if(h&&f&&S)try{h.existsSync(k)||h.mkdirSync(k,{recursive:!0}),h.writeFileSync(a,o,"utf-8"),h.writeFileSync(r,n,"utf-8");for(const[$,T]of d.entries()){const D=f.join(k,$),E=f.dirname(D);h.existsSync(E)||h.mkdirSync(E,{recursive:!0}),h.existsSync(D)||h.writeFileSync(D,T,"utf-8")}v=!0}catch{}if(!v&&i)try{const $=typeof Blob<"u"?new Blob([n],{type:"text/markdown;charset=utf-8"}):Buffer.from(n,"utf-8"),T=typeof Blob<"u"?new Blob([o],{type:"application/json;charset=utf-8"}):Buffer.from(o,"utf-8");await i(l,!1,T),await i(s,!1,$);for(const[D,E]of d.entries()){const x=`${this.workspacePath}/${D}`,W=typeof Blob<"u"?new Blob([E],{type:"text/plain;charset=utf-8"}):Buffer.from(E,"utf-8");await i(x,!1,W).catch(()=>{})}return{success:!0,slidesPath:s,physicalSlidesPath:r,packageJsonPath:l}}catch($){return{success:!1,slidesPath:s,physicalSlidesPath:r,packageJsonPath:l,error:String($)}}return{success:!0,slidesPath:s,physicalSlidesPath:r,packageJsonPath:l}}}class Uf{constructor(){ke(this,"mode","web-sandbox");ke(this,"webBridge");ke(this,"cliBridge");ke(this,"nativeBridge");ke(this,"processManager");ke(this,"scaffolder");ke(this,"envDetector");this.webBridge=new Ys,this.cliBridge=new qs,this.nativeBridge=new Of,this.processManager=new Rf,this.scaffolder=new Wf,this.envDetector=new Zs}getMode(){return this.mode}setMode(t){this.mode=t}async startProMode(t,i){if(!(await this.envDetector.detect()).hasNode)return{success:!1,url:"",error:"当前系统未检测到 Node.js 环境，无法拉起官方 Slidev CLI，建议继续使用内置高保真引擎"};const o=await this.scaffolder.scaffold(t,i);if(!o.success)return{success:!1,url:"",error:`初始化 Slidev 临时工作空间失败: ${o.error}`};const s=o.physicalSlidesPath||o.slidesPath,l=await this.processManager.startServer(s);return l.success?(this.mode="pro-cli",{success:!0,url:l.url,port:l.port}):{success:!1,url:"",error:l.error}}stopProMode(){this.processManager.stopServer(),this.mode="web-sandbox"}destroy(){this.webBridge.detach(),this.nativeBridge.detach(),this.processManager.stopServer()}}const Vf={class:"slidev-icon",style:{fill:"none !important"},viewBox:"0 0 24 24",stroke:"currentColor","stroke-width":"1.75","stroke-linecap":"round","stroke-linejoin":"round","aria-hidden":"true"},Kf={key:0},qf={key:1},Gf={key:2},Zf={key:3},Yf={key:4},Jf={key:5},Xf={key:6},Qf={key:7},ep={key:8},tp={key:9},ip={key:10},np={key:11},op={key:12},sp={key:13},rp={key:14},lp={key:15},ap={key:16},cp={key:17},dp={key:18},up={key:19},fp={key:20},pp={key:21},hp={key:22},mp={key:23},gp={key:24},vp={key:25},bp={key:26},yp={key:27},kp={key:28},wp={key:29},xp={key:30},Sp={key:31},_p={key:32},Cp={key:33},$p={key:34},Ip={key:35},Ep={key:36},Tp={key:37},Ap={key:38},Bp={key:39},Mp={key:40},Dp={key:41},Lp={key:42},Op={key:43},Rp={key:44},Pp={key:45},Np={key:46},zp={key:47},Fp={key:48},Hp={key:49},jp={key:50},Wp={key:51},Up={key:52},Vp={key:53},Kp={key:54},qp={key:55},Gp={key:56},Zp={key:57},Yp={key:58},Jp={key:59},Xp={key:60},Qp={key:61},eh={key:62},th={key:63},ih={key:64},nh={key:65},oh={key:66},sh=Ct({__name:"SlidevIcon",props:{name:{}},setup(e){return(t,i)=>(oe(),se("svg",Vf,[e.name==="fullscreen"||e.name==="maximize"?(oe(),se("g",Kf,[...i[0]||(i[0]=[p("polyline",{points:"15 3 21 3 21 9"},null,-1),p("polyline",{points:"9 21 3 21 3 15"},null,-1),p("polyline",{points:"21 15 21 21 15 21"},null,-1),p("polyline",{points:"3 9 3 3 9 3"},null,-1)])])):e.name==="minimize"?(oe(),se("g",qf,[...i[1]||(i[1]=[p("polyline",{points:"4 14 10 14 10 20"},null,-1),p("polyline",{points:"20 10 14 10 14 4"},null,-1),p("line",{x1:"14",y1:"10",x2:"21",y2:"3"},null,-1),p("line",{x1:"3",y1:"21",x2:"10",y2:"14"},null,-1)])])):e.name==="close"||e.name==="x"?(oe(),se("g",Gf,[...i[2]||(i[2]=[p("line",{x1:"18",y1:"6",x2:"6",y2:"18"},null,-1),p("line",{x1:"6",y1:"6",x2:"18",y2:"18"},null,-1)])])):e.name==="edit"?(oe(),se("g",Zf,[...i[3]||(i[3]=[p("path",{d:"M12 20h9"},null,-1),p("path",{d:"M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z"},null,-1)])])):e.name==="eye"?(oe(),se("g",Yf,[...i[4]||(i[4]=[p("path",{d:"M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"},null,-1),p("circle",{cx:"12",cy:"12",r:"3"},null,-1)])])):e.name==="external-link"||e.name==="window"?(oe(),se("g",Jf,[...i[5]||(i[5]=[p("path",{d:"M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"},null,-1),p("polyline",{points:"15 3 21 3 21 9"},null,-1),p("line",{x1:"10",y1:"14",x2:"21",y2:"3"},null,-1)])])):e.name==="arrow-left"?(oe(),se("g",Xf,[...i[6]||(i[6]=[p("line",{x1:"19",y1:"12",x2:"5",y2:"12"},null,-1),p("polyline",{points:"12 19 5 12 12 5"},null,-1)])])):e.name==="arrow-right"?(oe(),se("g",Qf,[...i[7]||(i[7]=[p("line",{x1:"5",y1:"12",x2:"19",y2:"12"},null,-1),p("polyline",{points:"12 5 19 12 12 19"},null,-1)])])):e.name==="plus"?(oe(),se("g",ep,[...i[8]||(i[8]=[p("line",{x1:"12",y1:"5",x2:"12",y2:"19"},null,-1),p("line",{x1:"5",y1:"12",x2:"19",y2:"12"},null,-1)])])):e.name==="minus"?(oe(),se("g",tp,[...i[9]||(i[9]=[p("line",{x1:"5",y1:"12",x2:"19",y2:"12"},null,-1)])])):e.name==="split-preview"?(oe(),se("g",ip,[...i[10]||(i[10]=[p("rect",{x:"3",y:"3",width:"18",height:"18",rx:"2"},null,-1),p("path",{d:"M12 3v18"},null,-1)])])):e.name==="import"?(oe(),se("g",np,[...i[11]||(i[11]=[p("path",{d:"M4 17v2a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-2"},null,-1),p("polyline",{points:"7 9 12 14 17 9"},null,-1),p("line",{x1:"12",y1:"14",x2:"12",y2:"3"},null,-1)])])):e.name==="presenter"?(oe(),se("g",op,[...i[12]||(i[12]=[p("path",{d:"M2 3h20"},null,-1),p("path",{d:"M21 3v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V3"},null,-1),p("path",{d:"m7 21 5-5 5 5"},null,-1)])])):e.name==="video"?(oe(),se("g",sp,[...i[13]||(i[13]=[p("polygon",{points:"23 7 16 12 23 17 23 7"},null,-1),p("rect",{x:"1",y:"5",width:"15",height:"14",rx:"2",ry:"2"},null,-1)])])):e.name==="step"?(oe(),se("g",rp,[...i[14]||(i[14]=[p("polygon",{points:"13 2 3 14 12 14 11 22 21 10 12 10 13 2"},null,-1)])])):e.name==="motion"?(oe(),se("g",lp,[...i[15]||(i[15]=[p("path",{d:"M5 12h14"},null,-1),p("path",{d:"m12 5 7 7-7 7"},null,-1),p("path",{d:"M5 6h4"},null,-1),p("path",{d:"M5 18h4"},null,-1)])])):e.name==="columns"?(oe(),se("g",ap,[...i[16]||(i[16]=[p("rect",{x:"3",y:"3",width:"7",height:"18",rx:"1"},null,-1),p("rect",{x:"14",y:"3",width:"7",height:"18",rx:"1"},null,-1)])])):e.name==="code"?(oe(),se("g",cp,[...i[17]||(i[17]=[p("polyline",{points:"16 18 22 12 16 6"},null,-1),p("polyline",{points:"8 6 2 12 8 18"},null,-1)])])):e.name==="insert-above"?(oe(),se("g",dp,[...i[18]||(i[18]=[p("line",{x1:"12",y1:"5",x2:"12",y2:"13"},null,-1),p("line",{x1:"8",y1:"9",x2:"16",y2:"9"},null,-1),p("path",{d:"M4 19h16","stroke-dasharray":"2 2"},null,-1)])])):e.name==="insert-below"?(oe(),se("g",up,[...i[19]||(i[19]=[p("path",{d:"M4 5h16","stroke-dasharray":"2 2"},null,-1),p("line",{x1:"12",y1:"11",x2:"12",y2:"19"},null,-1),p("line",{x1:"8",y1:"15",x2:"16",y2:"15"},null,-1)])])):e.name==="broom"?(oe(),se("g",fp,[...i[20]||(i[20]=[p("path",{d:"m18 15-6-6"},null,-1),p("path",{d:"M4 20h16"},null,-1),p("path",{d:"M6 14l8-8a2.8 2.8 0 0 1 4 4l-8 8H6v-4z"},null,-1)])])):e.name==="trash"?(oe(),se("g",pp,[...i[21]||(i[21]=[p("path",{d:"M3 6h18"},null,-1),p("path",{d:"M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"},null,-1),p("path",{d:"M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"},null,-1)])])):e.name==="ai"||e.name==="sparkles"?(oe(),se("g",hp,[...i[22]||(i[22]=[p("path",{d:"m12 3-1.9 5.8a2 2 0 0 1-1.3 1.3L3 12l5.8 1.9a2 2 0 0 1 1.3 1.3L12 21l1.9-5.8a2 2 0 0 1 1.3-1.3L21 12l-5.8-1.9a2 2 0 0 1-1.3-1.3L12 3z"},null,-1)])])):e.name==="palette"?(oe(),se("g",mp,[...i[23]||(i[23]=[vt('<circle cx="13.5" cy="6.5" r=".5" fill="currentColor" data-v-57969535></circle><circle cx="17.5" cy="10.5" r=".5" fill="currentColor" data-v-57969535></circle><circle cx="8.5" cy="7.5" r=".5" fill="currentColor" data-v-57969535></circle><circle cx="6.5" cy="12.5" r=".5" fill="currentColor" data-v-57969535></circle><path d="M12 2C6.5 2 2 6.5 2 12s4.5 10 10 10c.9 0 1.5-.7 1.5-1.5 0-.4-.2-.8-.4-1.1-.3-.4-.4-.8-.4-1.4 0-1.1.9-2 2-2h2.3c3.9 0 7-3.1 7-7 0-5-4.5-9-10-9z" data-v-57969535></path>',5)])])):e.name==="ratio"?(oe(),se("g",gp,[...i[24]||(i[24]=[p("rect",{x:"2",y:"5",width:"20",height:"14",rx:"2"},null,-1),p("line",{x1:"2",y1:"10",x2:"22",y2:"10","stroke-dasharray":"2 2"},null,-1)])])):e.name==="transition"?(oe(),se("g",vp,[...i[25]||(i[25]=[p("path",{d:"M8 3 4 7l4 4"},null,-1),p("path",{d:"M4 7h16"},null,-1),p("path",{d:"m16 21 4-4-4-4"},null,-1),p("path",{d:"M20 17H4"},null,-1)])])):e.name==="export-html"?(oe(),se("g",bp,[...i[26]||(i[26]=[p("polyline",{points:"16 16 12 12 8 16"},null,-1),p("line",{x1:"12",y1:"12",x2:"12",y2:"21"},null,-1),p("path",{d:"M20.4 16.3A5 5 0 0 0 18 7h-1.3A8 8 0 0 0 4 12.8a5 5 0 0 0 1.5 9.2"},null,-1)])])):e.name==="export-pdf"?(oe(),se("g",yp,[...i[27]||(i[27]=[p("polyline",{points:"6 9 6 2 18 2 18 9"},null,-1),p("path",{d:"M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"},null,-1),p("rect",{x:"6",y:"14",width:"12",height:"8"},null,-1)])])):e.name==="pin"?(oe(),se("g",kp,[...i[28]||(i[28]=[p("line",{x1:"12",y1:"17",x2:"12",y2:"22"},null,-1),p("path",{d:"M5 17h14v-2l-2-2V5l1-1V2H6v2l1 1v8l-2 2v2z"},null,-1)])])):e.name==="refresh"?(oe(),se("g",wp,[...i[29]||(i[29]=[p("path",{d:"M3 12a9 9 0 0 1 9-9 9.75 9.75 0 0 1 6.74 2.74L21 8"},null,-1),p("path",{d:"M21 3v5h-5"},null,-1),p("path",{d:"M21 12a9 9 0 0 1-9 9 9.75 9.75 0 0 1-6.74-2.74L3 16"},null,-1),p("path",{d:"M8 16H3v5"},null,-1)])])):e.name==="alert"||e.name==="warning"?(oe(),se("g",xp,[...i[30]||(i[30]=[p("path",{d:"M10.29 3.86 1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"},null,-1),p("line",{x1:"12",y1:"9",x2:"12",y2:"13"},null,-1),p("line",{x1:"12",y1:"17",x2:"12.01",y2:"17"},null,-1)])])):e.name==="outline"?(oe(),se("g",Sp,[...i[31]||(i[31]=[p("line",{x1:"3",y1:"6",x2:"21",y2:"6"},null,-1),p("line",{x1:"3",y1:"12",x2:"21",y2:"12"},null,-1),p("line",{x1:"3",y1:"18",x2:"21",y2:"18"},null,-1)])])):e.name==="chevron-left"?(oe(),se("g",_p,[...i[32]||(i[32]=[p("polyline",{points:"15 18 9 12 15 6"},null,-1)])])):e.name==="chevron-right"?(oe(),se("g",Cp,[...i[33]||(i[33]=[p("polyline",{points:"9 18 15 12 9 6"},null,-1)])])):e.name==="copy"?(oe(),se("g",$p,[...i[34]||(i[34]=[p("rect",{x:"9",y:"9",width:"13",height:"13",rx:"2",ry:"2"},null,-1),p("path",{d:"M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"},null,-1)])])):e.name==="image"?(oe(),se("g",Ip,[...i[35]||(i[35]=[p("rect",{x:"3",y:"3",width:"18",height:"18",rx:"2",ry:"2"},null,-1),p("circle",{cx:"8.5",cy:"8.5",r:"1.5"},null,-1),p("polyline",{points:"21 15 16 10 5 21"},null,-1)])])):e.name==="search"?(oe(),se("g",Ep,[...i[36]||(i[36]=[p("circle",{cx:"11",cy:"11",r:"7"},null,-1),p("line",{x1:"21",y1:"21",x2:"16.65",y2:"16.65"},null,-1)])])):e.name==="settings"||e.name==="gear"?(oe(),se("g",Tp,[...i[37]||(i[37]=[p("circle",{cx:"12",cy:"12",r:"3"},null,-1),p("path",{d:"M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 1 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 1 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 1 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 1 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"},null,-1)])])):e.name==="notes"||e.name==="file-text"?(oe(),se("g",Ap,[...i[38]||(i[38]=[vt('<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" data-v-57969535></path><polyline points="14 2 14 8 20 8" data-v-57969535></polyline><line x1="16" y1="13" x2="8" y2="13" data-v-57969535></line><line x1="16" y1="17" x2="8" y2="17" data-v-57969535></line><line x1="10" y1="9" x2="8" y2="9" data-v-57969535></line>',5)])])):e.name==="focus"||e.name==="target"?(oe(),se("g",Bp,[...i[39]||(i[39]=[p("circle",{cx:"12",cy:"12",r:"3",fill:"currentColor"},null,-1),p("path",{d:"M12 2v4M12 18v4M2 12h4M18 12h4",stroke:"currentColor","stroke-width":"2","stroke-linecap":"round"},null,-1),p("circle",{cx:"12",cy:"12",r:"7",fill:"none",stroke:"currentColor","stroke-width":"1.8"},null,-1)])])):e.name==="layout-cover"||e.name==="cover"?(oe(),se("g",Mp,[...i[40]||(i[40]=[p("rect",{x:"2",y:"4",width:"20",height:"16",rx:"2"},null,-1),p("line",{x1:"9",y1:"8",x2:"15",y2:"8"},null,-1),p("line",{x1:"5.5",y1:"11.5",x2:"18.5",y2:"11.5"},null,-1),p("line",{x1:"7.5",y1:"15",x2:"16.5",y2:"15"},null,-1)])])):e.name==="layout-default"||e.name==="default"?(oe(),se("g",Dp,[...i[41]||(i[41]=[vt('<rect x="2" y="4" width="20" height="16" rx="2" data-v-57969535></rect><line x1="5" y1="8" x2="11.5" y2="8" data-v-57969535></line><line x1="5" y1="11.5" x2="19" y2="11.5" data-v-57969535></line><line x1="5" y1="14.5" x2="19" y2="14.5" data-v-57969535></line><line x1="5" y1="17.5" x2="13.5" y2="17.5" data-v-57969535></line>',5)])])):e.name==="layout-two-cols"||e.name==="two-cols"?(oe(),se("g",Lp,[...i[42]||(i[42]=[vt('<rect x="2" y="4" width="20" height="16" rx="2" data-v-57969535></rect><line x1="12" y1="4" x2="12" y2="20" stroke-dasharray="2 1.5" data-v-57969535></line><line x1="5" y1="8" x2="9.5" y2="8" data-v-57969535></line><line x1="5" y1="11.5" x2="9.5" y2="11.5" data-v-57969535></line><line x1="5" y1="15" x2="8" y2="15" data-v-57969535></line><line x1="14.5" y1="8" x2="19" y2="8" data-v-57969535></line><line x1="14.5" y1="11.5" x2="19" y2="11.5" data-v-57969535></line><line x1="14.5" y1="15" x2="17.5" y2="15" data-v-57969535></line>',8)])])):e.name==="layout-two-cols-header"||e.name==="two-cols-header"?(oe(),se("g",Op,[...i[43]||(i[43]=[vt('<rect x="2" y="4" width="20" height="16" rx="2" data-v-57969535></rect><line x1="5" y1="7.5" x2="13" y2="7.5" data-v-57969535></line><line x1="12" y1="10.5" x2="12" y2="18.5" stroke-dasharray="1.5 1.5" data-v-57969535></line><line x1="5" y1="12" x2="9.5" y2="12" data-v-57969535></line><line x1="5" y1="15.5" x2="8.5" y2="15.5" data-v-57969535></line><line x1="14.5" y1="12" x2="19" y2="12" data-v-57969535></line><line x1="14.5" y1="15.5" x2="18" y2="15.5" data-v-57969535></line>',7)])])):e.name==="layout-cols-header"||e.name==="cols-header"||e.name==="layout-three-cols-header"||e.name==="three-cols-header"?(oe(),se("g",Rp,[...i[44]||(i[44]=[vt('<rect x="2" y="4" width="20" height="16" rx="2" data-v-57969535></rect><line x1="5" y1="7.5" x2="13" y2="7.5" data-v-57969535></line><line x1="9.3" y1="10.5" x2="9.3" y2="18.5" stroke-dasharray="1.5 1.5" data-v-57969535></line><line x1="14.7" y1="10.5" x2="14.7" y2="18.5" stroke-dasharray="1.5 1.5" data-v-57969535></line><line x1="4.5" y1="12" x2="7.5" y2="12" data-v-57969535></line><line x1="4.5" y1="15.5" x2="7" y2="15.5" data-v-57969535></line><line x1="10.5" y1="12" x2="13.5" y2="12" data-v-57969535></line><line x1="10.5" y1="15.5" x2="13.5" y2="15.5" data-v-57969535></line><line x1="16" y1="12" x2="19.5" y2="12" data-v-57969535></line><line x1="16" y1="15.5" x2="18.5" y2="15.5" data-v-57969535></line>',10)])])):e.name==="layout-clover"||e.name==="clover"?(oe(),se("g",Pp,[...i[45]||(i[45]=[vt('<rect x="2" y="4" width="20" height="16" rx="2" data-v-57969535></rect><line x1="5" y1="7" x2="13" y2="7" data-v-57969535></line><line x1="4.5" y1="13.5" x2="19.5" y2="13.5" stroke-dasharray="1.5 1.5" data-v-57969535></line><line x1="12" y1="9" x2="12" y2="18.5" stroke-dasharray="1.5 1.5" data-v-57969535></line><line x1="5" y1="11" x2="9.5" y2="11" data-v-57969535></line><line x1="14.5" y1="11" x2="19" y2="11" data-v-57969535></line><line x1="5" y1="16" x2="9.5" y2="16" data-v-57969535></line><line x1="14.5" y1="16" x2="19" y2="16" data-v-57969535></line>',8)])])):e.name==="layout-image-right"||e.name==="image-right"?(oe(),se("g",Np,[...i[46]||(i[46]=[vt('<rect x="2" y="4" width="20" height="16" rx="2" data-v-57969535></rect><line x1="12" y1="4" x2="12" y2="20" data-v-57969535></line><line x1="4.5" y1="8" x2="9.5" y2="8" data-v-57969535></line><line x1="4.5" y1="11.5" x2="10" y2="11.5" data-v-57969535></line><line x1="4.5" y1="14.5" x2="8" y2="14.5" data-v-57969535></line><circle cx="15.5" cy="8.5" r="1.2" data-v-57969535></circle><polyline points="13 17 15.5 13 18 16 19.5 14" data-v-57969535></polyline>',7)])])):e.name==="layout-image-left"||e.name==="image-left"?(oe(),se("g",zp,[...i[47]||(i[47]=[vt('<rect x="2" y="4" width="20" height="16" rx="2" data-v-57969535></rect><line x1="12" y1="4" x2="12" y2="20" data-v-57969535></line><circle cx="6" cy="8.5" r="1.2" data-v-57969535></circle><polyline points="3.5 17 6 13 8.5 16 10 14" data-v-57969535></polyline><line x1="14.5" y1="8" x2="19.5" y2="8" data-v-57969535></line><line x1="14.5" y1="11.5" x2="20" y2="11.5" data-v-57969535></line><line x1="14.5" y1="14.5" x2="18" y2="14.5" data-v-57969535></line>',7)])])):e.name==="layout-center"||e.name==="center"?(oe(),se("g",Fp,[...i[48]||(i[48]=[p("rect",{x:"2",y:"4",width:"20",height:"16",rx:"2"},null,-1),p("line",{x1:"6.5",y1:"9",x2:"17.5",y2:"9"},null,-1),p("line",{x1:"5",y1:"12",x2:"19",y2:"12"},null,-1),p("line",{x1:"8",y1:"15",x2:"16",y2:"15"},null,-1)])])):e.name==="layout-fact"||e.name==="fact"?(oe(),se("g",Hp,[...i[49]||(i[49]=[vt('<rect x="2" y="4" width="20" height="16" rx="2" data-v-57969535></rect><circle cx="8" cy="9" r="1.5" data-v-57969535></circle><line x1="14" y1="8" x2="9" y2="14" data-v-57969535></line><circle cx="15" cy="13" r="1.5" data-v-57969535></circle><line x1="6.5" y1="17" x2="17.5" y2="17" data-v-57969535></line>',5)])])):e.name==="layout-intro"||e.name==="intro"?(oe(),se("g",jp,[...i[50]||(i[50]=[vt('<rect x="2" y="4" width="20" height="16" rx="2" data-v-57969535></rect><circle cx="7.5" cy="9.5" r="2" data-v-57969535></circle><path d="M4.5 16.5c0-1.8 1.3-3 3-3s3 1.2 3 3" data-v-57969535></path><line x1="13" y1="9" x2="18.5" y2="9" data-v-57969535></line><line x1="13" y1="12.5" x2="19.5" y2="12.5" data-v-57969535></line><line x1="13" y1="15.5" x2="17" y2="15.5" data-v-57969535></line>',6)])])):e.name==="layout-quote"||e.name==="quote"?(oe(),se("g",Wp,[...i[51]||(i[51]=[vt('<rect x="2" y="4" width="20" height="16" rx="2" data-v-57969535></rect><path d="M6 7.5h2v2H6.5c0 1.2-.4 2-1.5 2.5" data-v-57969535></path><path d="M9.5 7.5h2v2H10c0 1.2-.4 2-1.5 2.5" data-v-57969535></path><line x1="6" y1="13.5" x2="18" y2="13.5" data-v-57969535></line><line x1="12.5" y1="16.5" x2="17.5" y2="16.5" data-v-57969535></line>',5)])])):e.name==="desktop"||e.name==="monitor"?(oe(),se("g",Up,[...i[52]||(i[52]=[p("rect",{x:"2",y:"3",width:"20",height:"14",rx:"2"},null,-1),p("line",{x1:"8",y1:"21",x2:"16",y2:"21"},null,-1),p("line",{x1:"12",y1:"17",x2:"12",y2:"21"},null,-1)])])):e.name==="mobile"||e.name==="smartphone"||e.name==="phone"?(oe(),se("g",Vp,[...i[53]||(i[53]=[p("rect",{x:"5",y:"2",width:"14",height:"20",rx:"2",ry:"2"},null,-1),p("line",{x1:"12",y1:"18",x2:"12.01",y2:"18","stroke-width":"2","stroke-linecap":"round"},null,-1)])])):e.name==="type"||e.name==="heading"?(oe(),se("g",Kp,[...i[54]||(i[54]=[p("polyline",{points:"4 7 4 4 20 4 20 7"},null,-1),p("line",{x1:"9",y1:"20",x2:"15",y2:"20"},null,-1),p("line",{x1:"12",y1:"4",x2:"12",y2:"20"},null,-1)])])):e.name==="reset"||e.name==="undo"?(oe(),se("g",qp,[...i[55]||(i[55]=[p("path",{d:"M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8"},null,-1),p("polyline",{points:"3 3 3 8 8 8"},null,-1)])])):e.name==="repeat"||e.name==="loop"?(oe(),se("g",Gp,[...i[56]||(i[56]=[p("path",{d:"m17 1 4 4-4 4"},null,-1),p("path",{d:"M3 11V9a4 4 0 0 1 4-4h14"},null,-1),p("path",{d:"m7 23-4-4 4-4"},null,-1),p("path",{d:"M21 13v2a4 4 0 0 1-4 4H3"},null,-1)])])):e.name==="volume-x"||e.name==="mute"?(oe(),se("g",Zp,[...i[57]||(i[57]=[p("polygon",{points:"11 5 6 9 2 9 2 15 6 15 11 19 11 5"},null,-1),p("line",{x1:"22",y1:"9",x2:"16",y2:"15"},null,-1),p("line",{x1:"16",y1:"9",x2:"22",y2:"15"},null,-1)])])):e.name==="sliders"||e.name==="controls"?(oe(),se("g",Yp,[...i[58]||(i[58]=[vt('<line x1="4" y1="21" x2="4" y2="14" data-v-57969535></line><line x1="4" y1="10" x2="4" y2="3" data-v-57969535></line><line x1="12" y1="21" x2="12" y2="12" data-v-57969535></line><line x1="12" y1="8" x2="12" y2="3" data-v-57969535></line><line x1="20" y1="21" x2="20" y2="16" data-v-57969535></line><line x1="20" y1="12" x2="20" y2="3" data-v-57969535></line><line x1="1" y1="14" x2="7" y2="14" data-v-57969535></line><line x1="9" y1="8" x2="15" y2="8" data-v-57969535></line><line x1="17" y1="16" x2="23" y2="16" data-v-57969535></line>',9)])])):e.name==="package"||e.name==="zip"||e.name==="archive"?(oe(),se("g",Jp,[...i[59]||(i[59]=[p("line",{x1:"16.5",y1:"9.4",x2:"7.5",y2:"4.21"},null,-1),p("path",{d:"M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"},null,-1),p("polyline",{points:"3.27 6.96 12 12.01 20.73 6.96"},null,-1),p("line",{x1:"12",y1:"22.08",x2:"12",y2:"12"},null,-1)])])):e.name==="folder"?(oe(),se("g",Xp,[...i[60]||(i[60]=[p("path",{d:"M4 20h16a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2h-7.93a2 2 0 0 1-1.66-.9l-.82-1.2A2 2 0 0 0 7.93 3H4a2 2 0 0 0-2 2v13c0 1.1.9 2 2 2Z"},null,-1)])])):e.name==="rocket"?(oe(),se("g",Qp,[...i[61]||(i[61]=[p("path",{d:"M4.5 16.5c-1.5 1.26-2 5-2 5s3.74-.5 5-2c.71-.84.7-2.13-.09-2.91a2.18 2.18 0 0 0-2.91-.09z"},null,-1),p("path",{d:"m12 15-3-3a22 22 0 0 1 2-3.95A12.88 12.88 0 0 1 22 2c0 2.72-.78 7.5-6 11a22.35 22.35 0 0 1-4 2z"},null,-1),p("path",{d:"M9 12H4s.55-3.03 2-4c1.62-1.08 5 0 5 0"},null,-1),p("path",{d:"M12 15v5s3.03-.55 4-2c1.08-1.62 0-5 0-5"},null,-1)])])):e.name==="wand"||e.name==="magic"?(oe(),se("g",eh,[...i[62]||(i[62]=[p("path",{d:"m19 2 2 2-6 6-2-2Z"},null,-1),p("path",{d:"m13 8 2 2"},null,-1),p("path",{d:"m3 21 9-9"},null,-1)])])):e.name==="image-left"?(oe(),se("g",th,[...i[63]||(i[63]=[vt('<rect x="2" y="4" width="20" height="16" rx="2" data-v-57969535></rect><rect x="4" y="6" width="6" height="12" rx="1" data-v-57969535></rect><line x1="13" y1="8" x2="19" y2="8" data-v-57969535></line><line x1="13" y1="12" x2="19" y2="12" data-v-57969535></line><line x1="13" y1="16" x2="17" y2="16" data-v-57969535></line>',5)])])):e.name==="image-right"?(oe(),se("g",ih,[...i[64]||(i[64]=[vt('<rect x="2" y="4" width="20" height="16" rx="2" data-v-57969535></rect><rect x="14" y="6" width="6" height="12" rx="1" data-v-57969535></rect><line x1="5" y1="8" x2="11" y2="8" data-v-57969535></line><line x1="5" y1="12" x2="11" y2="12" data-v-57969535></line><line x1="5" y1="16" x2="9" y2="16" data-v-57969535></line>',5)])])):e.name==="help"||e.name==="question"||e.name==="info"?(oe(),se("g",nh,[...i[65]||(i[65]=[p("circle",{cx:"12",cy:"12",r:"10"},null,-1),p("path",{d:"M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"},null,-1),p("line",{x1:"12",y1:"17",x2:"12.01",y2:"17"},null,-1)])])):(oe(),se("g",oh,[...i[66]||(i[66]=[p("rect",{x:"2",y:"3",width:"20",height:"14",rx:"2"},null,-1),p("line",{x1:"8",y1:"21",x2:"16",y2:"21"},null,-1),p("line",{x1:"12",y1:"17",x2:"12",y2:"21"},null,-1)])]))]))}}),zt=(e,t)=>{const i=e.__vccOpts||e;for(const[n,o]of t)i[n]=o;return i},fe=zt(sh,[["__scopeId","data-v-57969535"]]);function Je(e,t){var o;if(typeof document>"u"||!e)return;const i=(o=globalThis.CSS)!=null&&o.escape?globalThis.CSS.escape(e):e.replace(/"/g,'\\"'),n=document.querySelectorAll(`[data-node-id="${i}"]`);!n||n.length===0||n.forEach(s=>{for(const[l,r]of Object.entries(t))r!=null&&r!==""?s.setAttribute(l,String(r)):s.removeAttribute(l)})}function rh(e){if(typeof document>"u")return;const t=`.protyle-wysiwyg [${ge}], .protyle-wysiwyg [${Ge}], .protyle-wysiwyg [custom-slidev-layout], .protyle-wysiwyg [custom-slidev-role]`,i=document.querySelectorAll(t);!i||i.length===0||i.forEach(n=>{const o=n.getAttribute("data-node-id");if(!o){n.removeAttribute(ge),n.removeAttribute("custom-slidev-layout"),n.removeAttribute(Ge),n.removeAttribute("custom-slidev-role");return}const s=e.get(o),l=(s==null?void 0:s[ge])||(s==null?void 0:s["custom-slidev-layout"])||"",r=n.getAttribute(ge)||n.getAttribute("custom-slidev-layout");r&&r!==l&&(l?n.setAttribute(ge,l):(n.removeAttribute(ge),n.removeAttribute("custom-slidev-layout")));const a=(s==null?void 0:s[Ge])||(s==null?void 0:s["custom-slidev-role"])||"",c=n.getAttribute(Ge)||n.getAttribute("custom-slidev-role");c&&c!==a&&(a?n.setAttribute(Ge,a):(n.removeAttribute(Ge),n.removeAttribute("custom-slidev-role")))})}const lh={class:"spm-layout-picker"},ah={class:"spm-layout-picker__grid"},ch=["title","onClick"],dh={class:"spm-layout-icon"},uh={class:"spm-layout-label"},fh=Ct({__name:"LayoutPicker",props:{modelValue:{}},emits:["update:modelValue","change"],setup(e,{emit:t}){const i=e,n=t,o=[{name:"cover",label:"封面",desc:"大标题与副标题封面页"},{name:"default",label:"标准",desc:"标题在上方，内容在下方"},{name:"two-cols",label:"双栏",desc:"左右双栏对比展示"},{name:"cols-header",label:"表头多栏",desc:"顶部通栏标题，下方自适应 2~N 栏"},{name:"clover",label:"四叶草",desc:"4 项超级块 2x2 田字型四象限卡片布局"},{name:"image-right",label:"图右",desc:"左侧为内容，右侧全屏背景图"},{name:"image-left",label:"图左",desc:"左侧全屏背景图，右侧为内容"},{name:"center",label:"居中",desc:"内容全屏垂直水平居中"},{name:"fact",label:"大字报",desc:"核心数据或指标突出展示"},{name:"intro",label:"介绍",desc:"演讲者自我介绍或章节导览"},{name:"quote",label:"引言",desc:"名人名言与强调段落"}];function s(r){return i.modelValue===r||r==="cols-header"&&(i.modelValue==="two-cols-header"||i.modelValue==="three-cols-header")}function l(r){n("update:modelValue",r),n("change",r)}return(r,a)=>(oe(),se("div",lh,[a[0]||(a[0]=p("div",{class:"spm-layout-picker__header"},"选择页面版式",-1)),p("div",ah,[(oe(),se(Ke,null,kt(o,c=>p("div",{key:c.name,class:Ie(["spm-layout-item",{active:s(c.name)}]),title:c.desc,onClick:d=>l(c.name)},[p("div",dh,[de(fe,{name:"layout-"+c.name},null,8,["name"])]),p("span",uh,Se(c.label),1)],10,ch)),64))])]))}}),wa=zt(fh,[["__scopeId","data-v-1964d02c"]]),ph={key:0,class:"spm-transition-selector__header"},hh={class:"spm-transition-list"},mh=["onClick"],gh={class:"spm-transition-meta"},vh={class:"spm-transition-label"},bh={class:"spm-transition-name"},yh={class:"spm-transition-preview-box"},kh=Ct({__name:"TransitionSelector",props:{modelValue:{},hideHeader:{type:Boolean},title:{}},emits:["update:modelValue","change"],setup(e,{emit:t}){const i=t,n=[{name:"slide-left",label:"向左滑入",desc:"向左滑入 (slide-left)：页面从右侧向左平滑推入，最通用标准的横向幻灯片动效"},{name:"slide-right",label:"向右滑入",desc:"向右滑入 (slide-right)：页面从左侧向右平滑推入，适合倒序回退或逆向章节叙述"},{name:"slide-up",label:"向上推入",desc:"向上推入 (slide-up)：页面从底部向上平滑推入，适合纵向展开或纵深层级展示"},{name:"fade",label:"淡入淡出",desc:"淡入淡出 (fade)：透明度平滑渐变过度，典雅柔和，适合学术长篇与沉浸叙事"},{name:"zoom",label:"缩放进入",desc:"缩放进入 (zoom)：页面由中心向外平滑放大，富有动感冲击力，适合聚焦重点"}];function o(s){i("update:modelValue",s),i("change",s)}return(s,l)=>(oe(),se("div",{class:Ie(["spm-transition-selector",{"spm-transition-selector--no-header":e.hideHeader}])},[e.hideHeader?Re("",!0):(oe(),se("div",ph,Se(e.title||"转场动效"),1)),p("div",hh,[(oe(),se(Ke,null,kt(n,r=>p("div",{key:r.name,class:Ie(["spm-transition-item",{active:e.modelValue===r.name}]),onClick:a=>o(r.name)},[p("div",gh,[p("span",vh,Se(r.label),1),p("span",bh,"("+Se(r.name)+")",1)]),p("div",yh,[p("div",{class:Ie(["spm-anim-cube","anim-"+r.name])},null,2)])],10,mh)),64))])],2))}}),Js=zt(kh,[["__scopeId","data-v-8597e99e"]]),wh={class:"spm-divider-popover"},xh={class:"spm-divider-popover__title"},Sh={class:"spm-form-item"},_h={class:"spm-popover-footer"},Ch={class:"spm-save-hint"},$h=Ct({__name:"QuickDividerPopover",props:{blockId:{},initialAttrs:{}},emits:["close","updated"],setup(e,{emit:t}){var b,u,h;const i=e,n=t,o=ve(((b=i.initialAttrs)==null?void 0:b[ge])||"default"),s=ve(((u=i.initialAttrs)==null?void 0:u[tt])||"slide-left"),l=ve(((h=i.initialAttrs)==null?void 0:h[Ue])||""),r=ve("");Pi(()=>i.initialAttrs,f=>{o.value=(f==null?void 0:f[ge])||"default",s.value=(f==null?void 0:f[tt])||"slide-left",l.value=(f==null?void 0:f[Ue])||""},{deep:!0});async function a(f,v){if(i.blockId){r.value="正在同步...",Be.setBlockAttrOverride(i.blockId,{[f]:v}),Je(i.blockId,{[f]:v});try{await De(i.blockId,{[f]:v}),r.value="已同步至块属性",n("updated",{[f]:v}),setTimeout(()=>{r.value=""},1500)}catch{r.value="同步失败"}}}function c(f){a(ge,f)}function d(f){a(tt,f)}function m(){a(Ue,l.value.trim())}return(f,v)=>(oe(),se("div",wh,[p("div",xh,[v[4]||(v[4]=p("span",null,"幻灯片页面设置",-1)),p("button",{class:"spm-close-btn",onClick:v[0]||(v[0]=k=>n("close"))},"✕")]),de(wa,{modelValue:o.value,"onUpdate:modelValue":v[1]||(v[1]=k=>o.value=k),onChange:c},null,8,["modelValue"]),de(Js,{modelValue:s.value,"onUpdate:modelValue":v[2]||(v[2]=k=>s.value=k),onChange:d},null,8,["modelValue"]),p("div",Sh,[v[5]||(v[5]=p("label",{class:"spm-form-label"},"页面背景",-1)),Tt(p("input",{"onUpdate:modelValue":v[3]||(v[3]=k=>l.value=k),class:"spm-input",placeholder:"assets/bg.jpg 或颜色值 (#1e1e24)",onBlur:m},null,544),[[So,l.value]])]),p("div",_h,[p("span",Ch,Se(r.value),1)])]))}}),Ih=zt($h,[["__scopeId","data-v-e4871368"]]),Eh={class:"spm-slide-inspector"},Th={class:"spm-inspector-header"},Ah={class:"spm-inspector-list"},Bh=["onClick"],Mh={class:"spm-card-top"},Dh={class:"spm-card-badge"},Lh={class:"spm-card-layout"},Oh=["onClick"],Rh={class:"spm-card-preview"},Ph={key:0,class:"spm-card-notes",title:"演讲备忘录"},Nh={class:"spm-inspector-modal-content"},zh=Ct({__name:"SlideInspector",props:{slides:{},currentActivePage:{}},emits:["navigate","refresh"],setup(e,{emit:t}){const i=t,n=ve(null);function o(c){n.value=c}function s(c){const d={};return c.frontmatter.layout&&(d[ge]=c.frontmatter.layout),c.frontmatter.transition&&(d[tt]=c.frontmatter.transition),c.frontmatter.background&&(d[Ue]=c.frontmatter.background),c.notes&&(d[qi]=c.notes),d}function l(c){n.value&&(c[ge]&&(n.value.frontmatter.layout=c[ge]),c[tt]&&(n.value.frontmatter.transition=c[tt]),c[Ue]&&(n.value.frontmatter.background=c[Ue]),c[qi]&&(n.value.notes=c[qi]),i("refresh"))}function r(c){i("navigate",c)}function a(c){if(!c.blocks||c.blocks.length===0)return"(空白页)";const d=c.blocks[0],m=d.content||d.rawMarkdown||"";return m.slice(0,40)+(m.length>40?"...":"")}return(c,d)=>(oe(),se("div",Eh,[p("div",Th,[p("span",null,"幻灯片大纲 ("+Se(e.slides.length)+" 页)",1)]),p("div",Ah,[(oe(!0),se(Ke,null,kt(e.slides,m=>(oe(),se("div",{key:m.pageIndex,class:Ie(["spm-card",{active:e.currentActivePage===m.pageIndex}]),onClick:b=>r(m.pageIndex)},[p("div",Mh,[p("span",Dh,"P"+Se(m.pageIndex),1),p("span",Lh,Se(m.frontmatter.layout||"default"),1),p("button",{class:"spm-card-btn-edit",title:"配置此页版式与属性",onClick:Mt(b=>o(m),["stop"])},[de(fe,{name:"settings"})],8,Oh)]),p("div",Rh,Se(a(m)),1),m.notes?(oe(),se("div",Ph,[de(fe,{name:"notes",style:{"font-size":"11px","margin-right":"3px"}}),p("span",null,Se(m.notes),1)])):Re("",!0)],10,Bh))),128))]),n.value?(oe(),se("div",{key:0,class:"spm-inspector-modal-mask",onClick:d[1]||(d[1]=Mt(m=>n.value=null,["self"]))},[p("div",Nh,[de(Ih,{"block-id":n.value.startBlockId,"initial-attrs":s(n.value),onClose:d[0]||(d[0]=m=>n.value=null),onUpdated:l},null,8,["block-id","initial-attrs"])])])):Re("",!0)]))}}),Fh=zt(zh,[["__scopeId","data-v-68b25edd"]]),Hh={class:"spm-immersion-header"},jh={class:"spm-immersion-header__left"},Wh={class:"spm-immersion-title"},Uh={class:"spm-immersion-header__center"},Vh={class:"spm-immersion-header__actions"},Kh=["aria-label"],qh={class:"spm-immersion-body"},Gh=Ct({__name:"ImmersionDrawerContainer",props:{visible:{type:Boolean,default:!1},isMaximized:{type:Boolean,default:!1},title:{default:"速览"},closeOnClickMask:{type:Boolean,default:!0}},emits:["update:visible","update:isMaximized","close","toggle-maximize"],setup(e,{emit:t}){const i=e,n=t;function o(){n("update:visible",!1),n("close")}function s(){i.closeOnClickMask&&o()}function l(){n("update:isMaximized",!i.isMaximized),n("toggle-maximize")}function r(a){(a.key===" "||a.key==="ArrowLeft"||a.key==="ArrowRight"||a.key==="PageUp"||a.key==="PageDown")&&a.stopPropagation(),a.key==="Escape"&&(a.preventDefault(),a.stopPropagation(),o())}return(a,c)=>Tt((oe(),se("div",{class:Ie(["spm-immersion-container",{"is-maximized":e.isMaximized}]),onKeydown:Mt(r,["stop"])},[p("div",{class:"spm-immersion-mask",onClick:s}),p("div",{class:Ie(["spm-immersion-drawer",{"is-maximized":e.isMaximized}])},[p("div",Hh,[p("div",jh,[Zn(a.$slots,"header-left",{},()=>[p("span",Wh,Se(e.title),1)])]),p("div",Uh,[Zn(a.$slots,"header-center",{},void 0)]),p("div",Vh,[Zn(a.$slots,"header-actions",{},void 0),p("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":e.isMaximized?"还原抽屉宽度 (70%)":"最大化填满视口 (100%)",onClick:l},[de(fe,{name:e.isMaximized?"minimize":"maximize"},null,8,["name"])],8,Kh),p("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"关闭速览 (ESC)",onClick:o},[de(fe,{name:"close"})])])]),p("div",qh,[Zn(a.$slots,"default",{},void 0)])],2)],34)),[[ys,e.visible]])}}),Zh=zt(Gh,[["__scopeId","data-v-3f1665db"]]),Yh={class:"spm-protyle-drawer"},Jh={class:"spm-protyle-drawer__subbar"},Xh={class:"spm-protyle-drawer__nav"},Qh=["title"],em={class:"spm-protyle-drawer__actions"},tm=["aria-label"],im=["aria-label"],nm=Ct({__name:"ProtylePeekDrawer",props:{blockId:{},title:{},plugin:{}},emits:["external-jump"],setup(e,{emit:t}){const i=t,n=e,o=ve(n.blockId),s=ve(n.title||""),l=ve(!1),r=ve(!0),a=ve(!1),c=ve(""),d=hi,m=ve([]),b=ve(null);let u=null;Pi(()=>n.blockId,x=>{x&&x!==o.value&&(o.value=x,s.value=n.title||"",m.value=[],f(x))}),Fn(()=>{o.value&&f(o.value)}),zs(()=>{v()});async function h(x){try{const W=await en(`SELECT id, root_id, type, content FROM blocks WHERE id = '${x}' LIMIT 1`);if(Array.isArray(W)&&W.length>0){const V=W[0];c.value=V.root_id||"";const G=V.id===V.root_id||V.type==="d";a.value=G,r.value=!G,!s.value&&V.content&&(s.value=V.content.trim().slice(0,30));return}}catch(W){console.warn("[ProtylePeekDrawer] detectBlockType query failed:",W)}a.value=!1,r.value=!0}async function f(x,W){if(!b.value||!x)return;v(),await h(x),typeof W=="boolean"&&(r.value=!a.value&&W);let V,G;r.value&&!a.value?(V=["cb-get-all","cb-get-hl","cb-get-focus"],G={background:!1,title:!1,gutter:!0,breadcrumbDocName:!0,scroll:!0}):(V=["cb-get-context","cb-get-hl"],G={background:!0,title:!0,gutter:!0,breadcrumbDocName:!0,scroll:!0});try{u=new he.Protyle(n.plugin.app,b.value,{blockId:x,action:V,render:G}),!l.value&&u&&typeof u.disable=="function"&&u.disable()}catch(X){console.error("[ProtylePeekDrawer] Failed to instantiate Protyle:",X)}}function v(){if(u){try{typeof u.destroy=="function"&&u.destroy()}catch(x){console.warn("[ProtylePeekDrawer] Error destroying protyle:",x)}u=null}b.value&&(b.value.innerHTML="")}function k(){a.value||(r.value=!r.value,f(o.value,r.value))}function S(){l.value=!l.value,u&&(l.value?(typeof u.enable=="function"&&u.enable(),typeof u.focus=="function"&&u.focus()):typeof u.disable=="function"&&u.disable())}function $(){if(o.value)try{he.openWindow({doc:{id:o.value},alwaysOnTop:!0})}catch(x){console.warn("[ProtylePeekDrawer] openWindow failed:",x)}}function T(){var V;if(!o.value)return;const x=No(),W=ua(x.webServeUrl,o.value,{focus:!a.value});if(typeof window<"u"){const G=_t("electron");(V=G==null?void 0:G.shell)!=null&&V.openExternal?G.shell.openExternal(W).catch(()=>{window.open(W,"_blank")}):window.open(W,"_blank")}i("external-jump",W)}function D(){if(m.value.length>0){const x=m.value.pop();x&&(o.value=x.blockId,s.value=x.title,r.value=x.isFocusMode,a.value=x.isDoc,f(x.blockId,x.isFocusMode))}}function E(x){const W=x.target;if(!W)return;const V=W.closest('[data-type="block-ref"]');if(V){const X=V.getAttribute("data-id");if(X&&X!==o.value){x.preventDefault(),x.stopPropagation(),m.value.push({blockId:o.value,title:s.value||o.value,isFocusMode:r.value,isDoc:a.value}),o.value=X,s.value=V.innerText.trim()||X,f(X);return}}const G=W.closest("a");if(G&&G.href&&G.href.startsWith("siyuan://blocks/")){x.preventDefault(),x.stopPropagation();const X=G.href.replace("siyuan://blocks/","").split("?")[0];X&&X!==o.value&&(m.value.push({blockId:o.value,title:s.value||o.value,isFocusMode:r.value,isDoc:a.value}),o.value=X,s.value=G.innerText.trim()||X,f(X))}}return(x,W)=>(oe(),se("div",Yh,[p("div",Jh,[p("div",Xh,[m.value.length>0?(oe(),se("button",{key:0,class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"返回上层引用文档或块",onClick:D},[de(fe,{name:"arrow-left"}),W[0]||(W[0]=p("span",null,"返回",-1))])):Re("",!0),p("span",{class:Ie(["spm-protyle-badge",{"is-focus":r.value&&!a.value}])},Se(r.value&&!a.value?"思源块聚焦":"思源文档速览"),3),p("span",{class:"spm-protyle-id",title:s.value||o.value},Se(s.value||o.value),9,Qh)]),p("div",em,[a.value?Re("",!0):(oe(),se("button",{key:0,class:Ie(["spm-icon-btn b3-tooltips b3-tooltips__s",{"is-primary":r.value}]),"aria-label":r.value?"当前为块聚焦模式（点击展开所属文档全文）":"当前为文档全文模式（点击切回仅聚焦当前块）",onClick:k},[de(fe,{name:r.value?"focus":"file-text"},null,8,["name"]),p("span",null,Se(r.value?"块聚焦":"展开全文"),1)],10,tm)),p("button",{class:Ie(["spm-icon-btn b3-tooltips b3-tooltips__s",{"is-primary":l.value}]),"aria-label":l.value?"当前为即时编辑模式（点击切回只读）":"当前为只读速览模式（点击解锁即时编辑）",onClick:S},[de(fe,{name:l.value?"edit":"eye"},null,8,["name"]),p("span",null,Se(l.value?"编辑中":"只读"),1)],10,im),p("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"在置顶独立窗口中打开 (保留完整侧边栏与插件)",onClick:$},[de(fe,{name:"window"}),W[1]||(W[1]=p("span",null,"独立窗口",-1))]),ye(d).enableWebServeJump?(oe(),se("button",{key:1,class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"在系统默认浏览器中打开 (外跳)",onClick:T},[de(fe,{name:"external-link"}),W[2]||(W[2]=p("span",null,"外跳",-1))])):Re("",!0)])]),p("div",{ref_key:"mountEl",ref:b,class:Ie(["spm-protyle-mount",{"is-focus-mode":r.value&&!a.value}]),onClick:E},null,2)]))}}),om=zt(nm,[["__scopeId","data-v-7e586ef3"]]),sm=/^(https?|file|data|blob|mailto|tel|ftp|ftps|siyuan|about|chrome|ws|wss):/i,rm=/\.(html?|xhtml|pdf|png|jpe?g|gif|svg|webp|avif|ico|mp4|webm|mov|mp3|wav|m4a|ogg|json|md|markdown|txt|csv|zip|tar|gz|7z|rar|js|mjs|css|xml|yaml|yml|toml|ipynb|docx?|xlsx?|pptx?)$/i;function Fr(e){let t=e||"";try{t=decodeURIComponent(t)}catch{}t=t.replace(/\\/g,"/");const i=/(?:^|\/)data\/assets\/(.+)$/i.exec(t);if(i)return`/assets/${i[1]}`;const n=/(?:^|\/)data\/plugins\/(.+)$/i.exec(t);return n?`/plugins/${n[1]}`:null}function xa(e){const t=(e||"").replace(/^file:\/\//i,"");let i=t;try{i=decodeURIComponent(t)}catch{}if(i.startsWith("/"))return/^\/([a-zA-Z]:[\\/])/.exec(i)?i.slice(1):i;const n=i.indexOf("/");return n>=0?i.slice(n):i}function lm(e){const t=e.split(/[/?#]/)[0];return!t||rm.test(t)?!1:/^(localhost|\d{1,3}(\.\d{1,3}){3})(:\d+)?$/i.test(t)?!0:/^[a-z0-9-]+(\.[a-z0-9-]+)+(:\d+)?$/i.test(t)}function am(e){const t=e.indexOf("#"),i=t>=0?e.slice(t):"",n=t>=0?e.slice(0,t):e,o=n.indexOf("?"),s=o>=0?n.slice(0,o):n,l=o>=0?n.slice(o+1):"";if(!/^\/?assets\/.+\.html?$/i.test(s))return e;const r=new URLSearchParams(l);return r.get("iframe")==="true"||r.get("download")==="true"?e:(r.set("iframe","true"),`${s}?${r.toString()}${i}`)}function Sa(e){const t=cm(e);return t.external||!t.url?t:{url:am(t.url),external:!1}}function cm(e){const t=(e||"").trim();if(!t)return{url:"",external:!1};if(/^https?:\/\//i.test(t))return{url:t,external:!1};if(t.startsWith("//"))return{url:`https:${t}`,external:!1};if(/^(siyuan|data|blob|about):/i.test(t))return{url:t,external:!1};if(il(t))return{url:`/${nl(t)}`,external:!1};if(/^file:/i.test(t)){const n=Fr(xa(t));return n?{url:n,external:!1}:{url:t,external:!0}}if(/^[a-zA-Z]:[\\/]/.test(t)||t.startsWith("\\\\")){const n=Fr(t);return n?{url:n,external:!1}:{url:t,external:!0}}return sm.test(t)?{url:t,external:!0}:lm(t)?{url:`https://${t}`,external:!1}:{url:`/${t.replace(/^(?:\.{1,2}\/)+/,"").replace(/^\/+/,"")}`,external:!1}}const dm={class:"spm-webview-drawer"},um={class:"spm-webview-toolbar"},fm={class:"spm-webview-toolbar__nav"},pm=["disabled"],hm=["disabled"],mm=["aria-label"],gm={class:"spm-webview-toolbar__address"},vm=["aria-label"],bm={class:"spm-webview-toolbar__actions"},ym=["aria-label"],km={class:"spm-zoom-controller"},wm=["disabled"],xm=["disabled"],Sm={key:1,class:"spm-webview-fallback"},_m=["src"],Cm={key:2,class:"spm-load-error"},$m={class:"spm-load-error__code"},Im={class:"spm-load-error__code-num"},Em={class:"spm-load-error__url"},Tm={class:"spm-load-error__hint"},Am={class:"spm-load-error__actions"},Hr="Mozilla/5.0 (iPhone; CPU iPhone OS 17_4_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.4.1 Mobile/15E148 Safari/604.1",_a="siyuan-slidev-peek-view-mode";let Ca="desktop";function Bm(){if(typeof window<"u"&&window.localStorage)try{const e=window.localStorage.getItem(_a);if(e==="mobile"||e==="desktop")return e}catch{}return Ca}function Mm(e){if(Ca=e,typeof window<"u"&&window.localStorage)try{window.localStorage.setItem(_a,e)}catch{}}function Dm(e){switch((e||"").toUpperCase()){case"ERR_PROXY_CONNECTION_FAILED":return"无法连接到代理服务器：请在思源「设置 → 网络代理」中填写公司代理地址，或切换为「使用系统代理」。";case"ERR_TUNNEL_CONNECTION_FAILED":return"HTTPS 代理隧道建立失败：请将思源「网络代理」的类型设为 HTTPS 并确认地址正确。";case"ERR_MANDATORY_PROXY_CONFIGURATION_FAILED":return"强制代理配置获取失败：公司 PAC 脚本不可用，请在思源「网络代理」中改为手动填写代理地址。";case"ERR_NAME_NOT_RESOLVED":case"ERR_NAME_RESOLUTION_FAILED":return"域名解析失败：内网环境访问外网通常需要配置代理或 DNS。";case"ERR_INTERNET_DISCONNECTED":return"当前网络不可用：请检查网络连接。";case"ERR_CONNECTION_TIMED_OUT":case"ERR_TIMED_OUT":return"连接超时：该地址可能需要通过代理才能访问。";case"ERR_CONNECTION_REFUSED":return"连接被拒绝：目标服务未在监听，或思源本地内核尚未启动。";case"ERR_CERT_AUTHORITY_INVALID":case"ERR_CERT_COMMON_NAME_INVALID":case"ERR_CERT_DATE_INVALID":return"证书校验失败：若公司网络使用 TLS 拦截，需将根证书导入思源所用系统的证书库。";default:return"若处于公司内网，请优先检查思源「设置 → 网络代理」是否已配置为可用代理（支持「使用系统代理」）。"}}const Lm=Ct({__name:"WebviewPeekDrawer",props:{url:{},title:{},visible:{type:Boolean,default:!0}},emits:["external-jump"],setup(e,{emit:t}){const i=t,n=e,o=ve(ba()&&!Df()),s=ve(n.url),l=ve(n.url),r=ve(!1),a=ve(null),c=ve(!1),d=ve(!1),m=ve(1),b=ve(!1),u=ve(Bm());let h=typeof navigator<"u"&&!navigator.userAgent.includes("iPhone")?navigator.userAgent:"";const f=_e(()=>u.value==="mobile"?Hr:h||void 0),v=ve(null),k=ve(null);let S=null,$=null,T=null;Pi(()=>n.url,N=>{N&&N!==s.value&&(s.value=N,l.value=N,u.value==="mobile"&&V(!1),v.value&&typeof v.value.loadURL=="function"&&v.value.loadURL(N))}),Pi(()=>n.visible,N=>{if(N)M(),u.value==="mobile"&&V(!1);else if(v.value)try{typeof v.value.stop=="function"&&v.value.stop()}catch{}}),Fn(()=>{D(),k.value&&typeof ResizeObserver<"u"&&(S=new ResizeObserver(()=>{const N=v.value;if(N&&typeof N.invalidate=="function")try{N.invalidate()}catch{}}),S.observe(k.value)),$=N=>{var ue;const ae=N.message||((ue=N.error)==null?void 0:ue.message);if(typeof ae=="string"&&ae.includes("Invalid guestInstanceId"))return N.preventDefault(),N.stopImmediatePropagation(),!0},window.addEventListener("error",$,!0),T=N=>{const ae=N.reason,ue=typeof ae=="string"?ae:ae==null?void 0:ae.message;typeof ue=="string"&&ue.includes("Invalid guestInstanceId")&&N.preventDefault()},window.addEventListener("unhandledrejection",T)}),zs(()=>{if(E(),S&&(S.disconnect(),S=null),$&&(window.removeEventListener("error",$,!0),$=null),T&&(window.removeEventListener("unhandledrejection",T),T=null),v.value)try{typeof v.value.stop=="function"&&v.value.stop()}catch{}});function D(){const N=v.value;N&&(N.addEventListener("dom-ready",x),N.addEventListener("did-start-loading",G),N.addEventListener("did-stop-loading",P),N.addEventListener("did-navigate",y),N.addEventListener("did-navigate-in-page",O),N.addEventListener("new-window",U),N.addEventListener("did-fail-load",X),N.addEventListener("did-fail-provisional-load",X))}function E(){const N=v.value;if(N)try{N.removeEventListener("dom-ready",x),N.removeEventListener("did-start-loading",G),N.removeEventListener("did-stop-loading",P),N.removeEventListener("did-navigate",y),N.removeEventListener("did-navigate-in-page",O),N.removeEventListener("new-window",U),N.removeEventListener("did-fail-load",X),N.removeEventListener("did-fail-provisional-load",X)}catch{}}function x(){const N=v.value;if(N&&typeof N.getUserAgent=="function"&&!h)try{const ae=N.getUserAgent();ae&&!ae.includes("iPhone")&&(h=ae)}catch{}u.value==="mobile"&&V(!1),M(),B()}function W(){const N=u.value==="mobile"?"desktop":"mobile";u.value=N,Mm(N),V(!0)}function V(N=!1){const ae=v.value;if(!ae)return;const ue=u.value==="mobile"?Hr:h;if(typeof ae.setUserAgent=="function"&&ue)try{ae.setUserAgent(ue)}catch(L){console.warn("[WebviewPeekDrawer] setUserAgent error:",L)}if(N&&typeof ae.reload=="function")try{ae.reload()}catch(L){console.warn("[WebviewPeekDrawer] reload error:",L)}}function G(){r.value=!0,a.value=null}function X(N){if(N&&N.isMainFrame===!1||N&&Number(N.errorCode)===-3)return;const ae=String((N==null?void 0:N.errorDescription)||"ERR_FAILED");a.value={errorCode:Number((N==null?void 0:N.errorCode)??0),description:ae,validatedURL:String((N==null?void 0:N.validatedURL)||s.value),hint:Dm(ae)},r.value=!1}function C(){a.value=null,ee()}function P(){if(r.value=!1,B(),v.value&&typeof v.value.getURL=="function"){const N=v.value.getURL();N&&N!=="about:blank"&&(s.value=N,l.value=N)}}function y(N){N!=null&&N.url&&(s.value=N.url,l.value=N.url),B()}function O(N){N!=null&&N.url&&(s.value=N.url,l.value=N.url),B()}function U(N){N&&N.url&&(N.preventDefault(),v.value&&typeof v.value.loadURL=="function"&&v.value.loadURL(N.url))}function B(){const N=v.value;N&&(typeof N.canGoBack=="function"&&(c.value=N.canGoBack()),typeof N.canGoForward=="function"&&(d.value=N.canGoForward()))}function R(){v.value&&typeof v.value.goBack=="function"&&v.value.goBack()}function F(){v.value&&typeof v.value.goForward=="function"&&v.value.goForward()}function ee(){v.value&&typeof v.value.reload=="function"&&v.value.reload()}function I(){const N=Sa(l.value);if(N.url){if(N.external){s.value=N.url,le();return}s.value=N.url,l.value=N.url,v.value&&typeof v.value.loadURL=="function"&&v.value.loadURL(N.url)}}function M(){const N=v.value;if(N&&typeof N.setZoomFactor=="function")try{N.setZoomFactor(m.value)}catch(ae){console.warn("[WebviewPeekDrawer] setZoomFactor error:",ae)}}function J(){m.value=Math.min(2.5,Math.round((m.value+.1)*10)/10),M()}function Y(){m.value=Math.max(.5,Math.round((m.value-.1)*10)/10),M()}function te(){m.value=1,M()}function ie(N){N.preventDefault(),N.deltaY<0?J():N.deltaY>0&&Y()}async function pe(){if(typeof navigator<"u"&&navigator.clipboard)try{await navigator.clipboard.writeText(s.value),b.value=!0,setTimeout(()=>{b.value=!1},2e3)}catch(N){console.warn("Copy url failed:",N)}}function le(){var ae;const N=s.value;if(typeof window<"u"){const ue=_t("electron");(ae=ue==null?void 0:ue.shell)!=null&&ae.openExternal?ue.shell.openExternal(N).catch(()=>{window.open(N,"_blank")}):window.open(N,"_blank")}i("external-jump",N)}return(N,ae)=>{const ue=jd("webview");return oe(),se("div",dm,[p("div",um,[p("div",fm,[p("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s",disabled:!c.value,"aria-label":"后退",onClick:R},[de(fe,{name:"arrow-left"})],8,pm),p("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s",disabled:!d.value,"aria-label":"前进",onClick:F},[de(fe,{name:"arrow-right"})],8,hm),p("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":r.value?"正在加载...":"刷新页面",onClick:ee},[de(fe,{name:"refresh"})],8,mm)]),p("div",gm,[Tt(p("input",{"onUpdate:modelValue":ae[0]||(ae[0]=L=>l.value=L),type:"text",class:"b3-text-field spm-url-input",placeholder:"https://...",spellcheck:"false",onKeydown:of(I,["enter"])},null,544),[[So,l.value]]),p("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":b.value?"已复制地址！":"复制网址",onClick:pe},[de(fe,{name:"copy"})],8,vm)]),p("div",bm,[p("button",{class:Ie(["spm-icon-btn spm-mode-toggle b3-tooltips b3-tooltips__s",{"is-active":u.value==="mobile"}]),"aria-label":u.value==="mobile"?"当前为手机视图，点击切换为桌面视图":"当前为桌面视图，点击切换为手机视图",onClick:W},[de(fe,{name:u.value==="mobile"?"mobile":"desktop"},null,8,["name"])],10,ym),p("div",km,[p("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"缩小 (Ctrl + -)",disabled:m.value<=.5,onClick:Y},[de(fe,{name:"minus"})],8,wm),p("button",{class:"spm-zoom-badge b3-tooltips b3-tooltips__s","aria-label":"重置 100% (Ctrl + 0)",onClick:te},Se(Math.round(m.value*100))+"% ",1),p("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"放大 (Ctrl + +)",disabled:m.value>=2.5,onClick:J},[de(fe,{name:"plus"})],8,xm)]),p("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"在系统默认浏览器中打开 ↗",onClick:le},[de(fe,{name:"external-link"}),ae[1]||(ae[1]=p("span",null,"外跳",-1))])])]),p("div",{ref_key:"containerEl",ref:k,class:Ie(["spm-webview-body",{"is-mobile":u.value==="mobile"}]),onWheel:Mt(ie,["ctrl"])},[p("div",{class:Ie(["spm-webview-viewport",{"is-mobile":u.value==="mobile"}])},[o.value?(oe(),Dt(ue,{key:0,ref_key:"webviewRef",ref:v,class:"spm-webview-frame",src:s.value,useragent:f.value,allowpopups:"true",style:{position:"absolute",top:"0",left:"0",width:"100%",height:"100%",display:"inline-flex"}},null,8,["src","useragent"])):(oe(),se("div",Sm,[p("iframe",{class:"spm-webview-fallback-frame",src:s.value,frameborder:"0",sandbox:"allow-scripts allow-same-origin allow-forms allow-popups"},null,8,_m),p("div",{class:"spm-fallback-bar"},[ae[2]||(ae[2]=p("span",null,"如页面受同源策略 (X-Frame-Options) 拦截无法显示，请",-1)),p("button",{class:"spm-icon-btn is-primary",onClick:le}," 在新标签页中打开 ↗ ")])])),a.value?(oe(),se("div",Cm,[de(fe,{name:"alert",class:"spm-load-error__icon"}),ae[5]||(ae[5]=p("div",{class:"spm-load-error__title"},"页面加载失败",-1)),p("div",$m,[$t(Se(a.value.description)+" ",1),p("span",Im,"("+Se(a.value.errorCode)+")",1)]),p("div",Em,Se(a.value.validatedURL),1),p("p",Tm,Se(a.value.hint),1),p("div",Am,[p("button",{class:"spm-icon-btn","aria-label":"重试",onClick:C},[de(fe,{name:"refresh"}),ae[3]||(ae[3]=p("span",null,"重试",-1))]),p("button",{class:"spm-icon-btn is-primary","aria-label":"用系统浏览器打开",onClick:le},[de(fe,{name:"external-link"}),ae[4]||(ae[4]=p("span",null,"用系统浏览器打开 ↗",-1))])])])):Re("",!0)],2)],34)])}}}),Om=zt(Lm,[["__scopeId","data-v-6c82ca68"]]);class Rm{constructor(){ke(this,"timers",new Map)}debounce(t,i,n=150){this.cancel(t);const o=setTimeout(()=>{this.timers.delete(t),i()},n);this.timers.set(t,o)}cancel(t){this.timers.has(t)&&(clearTimeout(this.timers.get(t)),this.timers.delete(t))}cancelAll(){for(const t of this.timers.values())clearTimeout(t);this.timers.clear()}hasPending(t){return this.timers.has(t)}}class Pm{constructor(t){ke(this,"blockToPageMap",new Map);ke(this,"debounceCtrl",new Rm);ke(this,"activeBlockId","");ke(this,"activePageIndex",1);ke(this,"currentDocId","");ke(this,"bridge",null);t&&(this.bridge=t)}setBridge(t){this.bridge=t}setDocId(t){this.currentDocId=t}updateSlidesIndex(t){this.blockToPageMap.clear();for(const i of t){i.startBlockId&&this.blockToPageMap.set(i.startBlockId,i.pageIndex);for(const n of i.blocks)this.blockToPageMap.set(n.id,i.pageIndex)}}getPageByBlockId(t){return this.blockToPageMap.get(t)??null}onCursorFocusBlock(t){if(!t||t===this.activeBlockId)return;this.activeBlockId=t;let i=this.getPageByBlockId(t);!i&&(t===this.currentDocId||!this.currentDocId&&this.blockToPageMap.size>0)&&(i=1),i&&this.debounceCtrl.debounce("cursor-navigate",()=>{this.activePageIndex=i,this.bridge&&(this.bridge.navigatePage(i),this.bridge.highlightElement(t))},100)}getActiveBlockId(){return this.activeBlockId}setActiveBlockId(t){this.activeBlockId=t;const i=this.getPageByBlockId(t);i&&(this.activePageIndex=i)}getActivePageIndex(){return this.activePageIndex}destroy(){this.debounceCtrl.cancelAll(),this.blockToPageMap.clear(),this.bridge=null}}function Ni(e,t){var s,l;if(!e||typeof document>"u")return!1;const i=(s=globalThis.CSS)!=null&&s.escape?globalThis.CSS.escape(e):e.replace(/"/g,'\\"'),n=document.querySelector(`.protyle-wysiwyg [data-node-id="${i}"]`)||document.querySelector(`[data-node-id="${i}"]`);if(!n){if(t)try{return he.openTab({app:t,doc:{id:e,action:["cb-get-hl","cb-get-focus","cb-get-context"]}}),!0}catch(r){console.warn("[SelectionMirror] openTab fallback failed:",r)}return!1}try{n.scrollIntoView({behavior:"smooth",block:"center",inline:"nearest"})}catch{n.scrollIntoView()}try{(l=n.focus)==null||l.call(n,{preventScroll:!0})}catch{}n.classList.add("protyle-wysiwyg--select");const o=n.style.outline;return n.style.outline="2px solid #3b82f6",n.style.transition="outline 0.3s ease",setTimeout(()=>{n.classList.remove("protyle-wysiwyg--select"),n.style.outline=o},1200),!0}function Nm(e){if(!e)return"";const t=e.split(`
`).map(l=>l.trim()).filter(Boolean);if(t.length===0)return"";if(!t.some(l=>/^#{1,6}\s+/.test(l)))return t.map(l=>rt(l)).join("<br/>");const n=[];let o=[];const s=()=>{if(o.length>0){const l=o.map(r=>rt(r)).join("<br/>");n.push(`<p class="slide-list-item-desc">${l}</p>`),o=[]}};for(const l of t){const r=l.match(/^(#{1,6})\s+(.*)$/);if(r){s();const a=r[1].length,c=r[2].trim();n.push(`<h${a} class="slide-list-item-title">${rt(c)}</h${a}>`)}else o.push(l)}return s(),n.join(`
`)}function zm(e){if(e.length===0)return"";const t=[],i=e[0],n=i.match(/^(#{1,6})\s+(.*)$/);if(n){const o=n[1].length,s=n[2].trim();t.push(`<h${o} class="slide-list-item-title">${rt(s)}</h${o}>`)}else t.push(`<p class="slide-list-item-title">${rt(i)}</p>`);if(e.length>1){const o=e.slice(1);let s=[];const l=()=>{if(s.length>0){const r=s.map(a=>rt(a)).join("<br/>");t.push(`<p class="slide-list-item-desc">${r}</p>`),s=[]}};for(const r of o){const a=r.match(/^(#{1,6})\s+(.*)$/);if(a){l();const c=a[1].length,d=a[2].trim();t.push(`<h${c} class="slide-list-item-title">${rt(d)}</h${c}>`)}else s.push(r)}l()}return t.join(`
`)+(t.length>0?`
`:"")}function $a(e,t,i){var b,u,h,f;const n=e.split(`
`);if(!n.some(v=>/^(\s*)([-*+]|\d+\.)\s+/.test(v)))return null;const s=[],l=[];let r=!1;for(let v=0;v<n.length;v++){const k=n[v];if(!k.trim())continue;const S=k.match(/^(\s*)[-*+]\s+\[([ xX])\]\s+(.*)$/);if(S){const E=S[1].length,x=Math.floor(E/2);l.push({type:"task",level:x,checked:S[2].toLowerCase()==="x",text:S[3],media:[]});continue}const $=k.match(/^(\s*)[-*+]\s+(.*)$/);if($){const E=$[1].length,x=Math.floor(E/2);l.push({type:"unordered",level:x,text:$[2],media:[]});continue}const T=k.match(/^(\s*)\d+\.\s+(.*)$/);if(T){l.length===0&&(r=!0);const E=T[1].length,x=Math.floor(E/2);l.push({type:"ordered",level:x,text:T[2],media:[]});continue}const D=k.trim();if(!(!D||/^\{:.*?\}$/.test(D)))if(l.length>0){const E=D.match(/^!\[(.*?)\]\((.*?)\)(?:\{:?[^}]*\})?$/);if(E){const V=/\.gif(?:\?|$)/i.test(E[2])?"list-item-gif":"list-item-img";l[l.length-1].media||(l[l.length-1].media=[]),l[l.length-1].media.push(`<div class="slide-list-media"><img alt="${ct(E[1])}" src="${E[2]}" class="${V}" /></div>`);continue}if(D.match(/^<img\b[\s\S]*?\/?>$/i)){const W=D.replace(/\s+style="[^"]*"/gi,"");l[l.length-1].media||(l[l.length-1].media=[]),l[l.length-1].media.push(`<div class="slide-list-media">${W}</div>`);continue}if(/<video\b/i.test(D)){let W=D;if(!/<\/video>/i.test(W))for(;v+1<n.length&&!/<\/video>/i.test(W);)v++,W+=" "+n[v].trim();const V=((b=i==null?void 0:i.attributes)==null?void 0:b["custom-slidev-autoplay"])==="true"||/autoplay/i.test(W),G=((u=i==null?void 0:i.attributes)==null?void 0:u["custom-slidev-loop"])==="true"||/loop/i.test(W),X=((h=i==null?void 0:i.attributes)==null?void 0:h["custom-slidev-muted"])==="true"||V||/muted/i.test(W),C=((f=i==null?void 0:i.attributes)==null?void 0:f["custom-slidev-controls"])==="false",P=W.match(/\bsrc=["']([^"']+)["']/i),y=P?P[1]:"",O=['class="slide-video-player"'];C||O.push("controls"),V&&(O.push("autoplay"),O.push("playsinline")),G&&O.push("loop"),X&&O.push("muted"),O.push('preload="metadata"'),y&&O.push(`src="${y}"`);const U=W.match(/<video[^>]*>([\s\S]*?)<\/video>/i);let B=U?U[1].trim():"";!B&&y&&(B=`<source src="${y}" type="video/mp4" />您的浏览器不支持视频播放。`),l[l.length-1].media||(l[l.length-1].media=[]),l[l.length-1].media.push(`<div class="slide-list-media slide-video-container slide-media-container" data-autoplay="${V?"true":"false"}" data-muted="${X?"true":"false"}"><video ${O.join(" ")}>${B}</video></div>`);continue}l[l.length-1].text+=`
`+D}else s.push(D)}if(l.length===0)return null;const a=r?"ol":"ul",c=(t==null?void 0:t.listClassName)||(r?"pdf-list pdf-list--ordered":"pdf-list pdf-list--unordered"),d=l.map(v=>{const k=Nm(v.text),S=v.media&&v.media.length>0?`
${v.media.join(`
`)}`:"",$=v.level||0,T=$>0?` style="margin-left:${($*1.25).toFixed(2)}em;${v.type==="unordered"?`list-style-type:${$%2===1?"circle":"square"} !important;`:""}"`:"",D=$>0?" slide-list-item--nested":"";if(v.type==="task"){const x=v.checked?' checked=""':"";return`<li class="pdf-task-item${D}"${T}><label><input type="checkbox" disabled=""${x}/> <span>${k}</span></label>${S}</li>`}return`<li${D?` class="${D.trim()}"`:""}${T}>${k}${S}</li>`}).join(`
`);return`${zm(s)}<${a} class="${c}">
${d}
</${a}>`}function Fm(e,t,i){const n=(t==null?void 0:t.containerClassName)||"pdf-block",o=e.split(/\r?\n/),s=[];let l=[];for(let c=0;c<o.length;c++){const d=o[c],m=d.trim();if(/^#{1,6}\s+/.test(m)){l.length>0&&(s.push(l.join(`
`)),l=[]),s.push(m);continue}if(!m){l.length>0&&(s.push(l.join(`
`)),l=[]);continue}if(/^!\[.*?\]\(.*?\)$/.test(m)){l.length>0&&(s.push(l.join(`
`)),l=[]),s.push(m);continue}if(/<video\b/i.test(m)){l.length>0&&(s.push(l.join(`
`)),l=[]);let b=m;if(!/<\/video>/i.test(b))for(;c+1<o.length&&!/<\/video>/i.test(b);)c++,b+=`
`+o[c];s.push(b);continue}l.push(d)}l.length>0&&s.push(l.join(`
`));let r=!0;return s.map(c=>{var h,f,v,k;const d=c.trim();if(!d)return"";const m=d.match(/^(#{1,6})\s+(.*)$/);if(m){r=!1;const S=m[1].length;return`<h${S} class="slide-list-item-title">${rt(m[2].trim())}</h${S}>`}const b=d.match(/^!\[(.*?)\]\((.*?)\)$/);if(b){const S=/\.gif(?:\?|$)/i.test(b[2]),$=(t==null?void 0:t.imageClassName)||(S?"list-item-gif":"pdf-image slide-media-img");return`<div class="${n} ${n}--image slide-media-block slide-media-container slide-list-media"><img alt="${ct(b[1])}" src="${b[2]}" class="${$}" /></div>`}if(/<video\b/i.test(d)){const S=((h=i==null?void 0:i.attributes)==null?void 0:h["custom-slidev-autoplay"])==="true"||/autoplay/i.test(d),$=((f=i==null?void 0:i.attributes)==null?void 0:f["custom-slidev-loop"])==="true"||/loop/i.test(d),T=((v=i==null?void 0:i.attributes)==null?void 0:v["custom-slidev-muted"])==="true"||S||/muted/i.test(d),D=((k=i==null?void 0:i.attributes)==null?void 0:k["custom-slidev-controls"])==="false",E=d.match(/\bsrc=["']([^"']+)["']/i),x=E?E[1]:"",W=['class="slide-video-player"'];D||W.push("controls"),S&&W.push("autoplay playsinline"),$&&W.push("loop"),T&&W.push("muted"),W.push('preload="metadata"'),x&&W.push(`src="${x}"`);const V=d.match(/<video[^>]*>([\s\S]*?)<\/video>/i);let G=V?V[1].trim():"";return!G&&x&&(G=`<source src="${x}" type="video/mp4" />您的浏览器不支持视频播放。`),`<div class="${n} ${n}--video slide-media-block slide-video-container slide-media-container" data-autoplay="${S?"true":"false"}" data-muted="${T?"true":"false"}"><video ${W.join(" ")}>${G}</video></div>`}const u=$a(d,t,i);if(u)return r=!1,u;if(r){r=!1;const S=d.split(/\r?\n/).map(E=>E.trim()).filter(Boolean);if(S.length===1)return`<p class="slide-list-item-title">${rt(S[0])}</p>`;const $=S[0],D=S.slice(1).map(E=>rt(E)).join("<br/>");return`<p class="slide-list-item-title">${rt($)}</p>
<p class="slide-list-item-desc">${D}</p>`}return`<p class="slide-list-item-desc">${rt(d)}</p>`}).filter(Boolean).join(`
`)}function es(e){if(!e)return!1;if(e.type==="h"||e.type==="NodeHeading")return!0;const t=(e.rawMarkdown||e.content||"").trim();return/^#{1,6}\s+/.test(t)}function Hm(e,t){var r,a,c,d,m,b,u,h;const i=((r=e.frontmatter)==null?void 0:r.layout)||"default",o=(e.blocks||[]).filter(f=>f.slot!=="slot-divider-right"),l=i==="cover"?null:o.find(es);if(i==="two-cols"){const f=o.some(X=>X.slot==="right");let v=[],k=[];if(f)v=o.filter(X=>X.slot!=="right"),k=o.filter(X=>X.slot==="right");else{const X=Math.ceil(o.length/2);v=o.slice(0,X),k=o.slice(X)}const S=X=>{const C=X.filter(P=>!!(P.rawMarkdown||P.content||"").trim());if(C.length>0){const P=C[0],y=(P.rawMarkdown||P.content||"").trim();(Fi(P)||/^(?:[-*+]|\d+\.)\s+/.test(y))&&(P.rawMarkdown=xn(P.rawMarkdown||P.content||""),P.content=P.rawMarkdown)}};S(v),S(k);const $=v.map(X=>ui(X,t)).join(`
`),T=k.map(X=>ui(X,t)).join(`
`),D="pdf-two-cols-wrapper layout-two-cols-grid",E=(a=e.frontmatter)!=null&&a.layoutClass?` ${e.frontmatter.layoutClass}`:"",x="pdf-col pdf-col--left",W="pdf-col pdf-col--right",G=`style="grid-template-columns: ${Xo((c=e.frontmatter)==null?void 0:c.layoutRatio,2)};"`;return`
      <div class="${D}${E}" ${G}>
        <div class="${x}">${$}</div>
        <div class="${W}">${T}</div>
      </div>
    `}if(i==="clover"||Tn(i)){const f=i==="clover";let v=[];const k=o.filter(O=>O.slot==="header");if(k.length>0)v=k;else if(o.length>0){const O=o.find(U=>U.type==="h"&&(!U.slot||U.slot==="default"));O&&(v=[O])}const S=o.filter(O=>!v.includes(O));let $=2;if(f)$=4;else if(i==="three-cols-header")$=3;else if(i==="two-cols-header")$=2;else{let O=0;for(const U of S){const B=(U.slot||"").match(/^col-(\d+)$/i);B&&(O=Math.max(O,parseInt(B[1],10)))}if(O>=2)$=O;else if((d=e.frontmatter)!=null&&d.layoutRatio){const U=e.frontmatter.layoutRatio.trim();if(U.includes(":")){const B=U.split(":").map(R=>parseFloat(R.trim())).filter(R=>!isNaN(R)&&R>0);B.length>=2&&($=B.length)}else{const B=U.split(/\s+/).filter(Boolean);B.length>=2&&($=B.length)}}else S.length===1&&S[0].children&&S[0].children.length>=2&&($=Math.min(6,S[0].children.length))}const T=va(S,$),D=S.some(O=>O.slot&&/^(?:col-\d+|left|right)$/i.test(O.slot)),E=i==="clover"||i==="two-cols-header"||i==="three-cols-header"||Tn(i)&&D,x=O=>{const U=O.filter(R=>!!(R.rawMarkdown||R.content||"").trim());if(E&&U.length>0){const R=U[0],F=(R.rawMarkdown||R.content||"").trim();(Fi(R)||/^(?:[-*+]|\d+\.)\s+/.test(F))&&(R.rawMarkdown=xn(R.rawMarkdown||R.content||""),R.content=R.rawMarkdown),R.isColFirst=!0}const B=E?U.find(es):null;return U.map(R=>ui(R,{...t,extraClassName:R===B?"slidev-col-first-heading-block":""})).join(`
`)},W=v.find(es),V=v.map(O=>ui(O,{...t,extraClassName:O===W?"slidev-page-first-heading-block":""})).join(`
`),G=f?"repeat(2, minmax(0, 1fr))":Xo((m=e.frontmatter)==null?void 0:m.layoutRatio,$),X=f?`style="grid-template-columns: ${G}; grid-template-rows: repeat(2, minmax(0, 1fr));"`:`style="grid-template-columns: ${G};"`,C=[f?"layout-clover-container":"layout-cols-header-container",$===2?"layout-two-cols-header-container":"",$===3?"layout-three-cols-header-container":"",`layout-${i}-container`,E?"has-superblock-cols":""].filter(Boolean).join(" "),P=[f?"layout-clover-grid pdf-clover-wrapper":"layout-cols-wrapper layout-cols-grid",$===2?"pdf-two-cols-wrapper layout-two-cols-grid":"",$===3?"pdf-three-cols-wrapper layout-three-cols-grid":"",E?"has-superblock-cols":""].filter(Boolean).join(" "),y=T.map((O,U)=>{const B=U+1;return`<div class="${["pdf-col",$===2&&B===1?"pdf-col--left":"",$===2&&B===2?"pdf-col--right":"",`pdf-col--${B}`,`col-${B}`].filter(Boolean).join(" ")}">${x(O)}</div>`}).join(`
`);return`
      <div class="${C}">
        <div class="layout-header-section">${V}</div>
        <div class="${P}" ${X}>
          ${y}
        </div>
      </div>
    `}if(i==="image-right"||i==="image-left"){const f=i==="image-right",v=o.map(E=>ui(E,t)).join(`
`),k=((b=e.frontmatter)==null?void 0:b.image)||((u=e.frontmatter)==null?void 0:u.background)||"",S=`<div class="pdf-image-col" style="background-image:url('${ct(k)}');background-size:cover;background-position:center;background-repeat:no-repeat;width:100%;height:100%;position:relative;overflow:hidden;"><img src="${ct(k)}" style="width:100%;height:100%;object-fit:cover;object-position:center;display:block;" onerror="this.style.display='none'" alt="Slide cover" /></div>`,$=`<div class="pdf-content-col" style="padding:48px 56px;display:flex;flex-direction:column;justify-content:flex-start;height:100%;box-sizing:border-box;overflow-y:auto;">${v}</div>`,T=f?`${$}
${S}`:`${S}
${$}`;return`
      <div class="layout-image-cols-grid" style="display:grid;grid-template-columns:${Xo((h=e.frontmatter)==null?void 0:h.layoutRatio,2)};grid-template-rows:100%;width:100%;height:100%;position:absolute;top:0;left:0;right:0;bottom:0;box-sizing:border-box;">
        ${T}
      </div>
    `}return i==="fact"?`<div class="layout-fact-container">${o.map(v=>ui(v,t)).join(`
`)}</div>`:i==="cover"?`<div class="layout-cover-container">${o.map(v=>ui(v,t)).join(`
`)}</div>`:o.map(f=>ui(f,{...t,extraClassName:f===l?"slidev-page-first-heading-block":""})).join(`
`)}function ct(e){return e?e.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&#039;"):""}function jm(e){if(!e||e.trim()===""||e.trim()==="all")return"all";const t=new Set,i=e.split("|");for(const n of i){const o=n.trim();if(o==="all")return"all";if(o.includes("-")){const[s,l]=o.split("-"),r=parseInt(s,10),a=parseInt(l,10);if(!isNaN(r)&&!isNaN(a))for(let c=Math.min(r,a);c<=Math.max(r,a);c++)t.add(c)}else{const s=parseInt(o,10);isNaN(s)||t.add(s)}}return t}const Wm=new Set(["kbd","mark","sub","sup","span","a","br","b","i","u","s","del","em","strong","code","small","abbr","ruby","rt","rp","v-mark","img","video","source","picture"]);function rt(e){if(!e)return"";const t=ha(e),i=[],n=t.replace(/<\/?([a-zA-Z0-9_-]+)(?:\s+[^<>]*)?\/?>/g,(s,l)=>{const r=l.toLowerCase();if(!Wm.has(r)||/on\w+\s*=|javascript:/i.test(s))return s;if(r==="v-mark"){const a=s.match(/type=["']?([a-zA-Z-]+)["']?/),c=a?a[1]:"circle";return s.startsWith("</")?i.push("</mark>"):i.push(`<mark class="v-mark v-mark--${c}">`),`%%SAFE_HTML_${i.length-1}%%`}return i.push(s),`%%SAFE_HTML_${i.length-1}%%`});let o=ct(n);return o=o.replace(/\(\(([0-9a-zA-Z-]+)(?:\s*(?:&#039;([^&#]*)&#039;|&quot;([^&]*)&quot;|'([^']*)'|"([^"]*)"|([^\)]+?)))?\s*\)\)/g,(s,l,r,a,c,d,m)=>{const u=(r??a??c??d??m??"").trim()||`Ref(${l.slice(0,8)})`;return`<a href="siyuan://blocks/${l}" data-ref-id="${l}" class="slidev-ref-tag">🔗 ${u}</a>`}),o=o.replace(/\$([^$\n]+)\$/g,'<span class="katex-inline font-math"><em>$1</em></span>'),o=o.replace(/!\[(.*?)\]\((.*?)\)/g,(s,l,r)=>{const c=/\.gif(?:\?|$)/i.test(r)?"slide-inline-img list-item-gif":"slide-inline-img";return`<img alt="${l}" src="${r}" class="${c}" />`}),o=o.replace(/\[(.*?)\]\((.*?)\)/g,(s,l,r)=>{if(r.startsWith("siyuan://blocks/")){const a=r.replace("siyuan://blocks/","").split("?")[0];return`<a href="${r}" data-ref-id="${a}" class="slidev-ref-tag">🔗 ${l}</a>`}return`<a href="${r}" target="_blank" rel="noopener noreferrer" class="slidev-link">${l}</a>`}),o=o.replace(/(^|[\s(])(siyuan:\/\/blocks\/([0-9a-zA-Z-]+)(?:\?[^\s\)]*)?)/g,(s,l,r,a)=>`${l}<a href="${r}" data-ref-id="${a}" class="slidev-ref-tag">🔗 ${r}</a>`),o=o.replace(/\*\*(.*?)\*\*/g,"<strong>$1</strong>"),o=o.replace(/\*(.*?)\*/g,"<em>$1</em>"),o=o.replace(/~~(.*?)~~/g,"<del>$1</del>"),o=o.replace(/`([^`]+)`/g,"<code>$1</code>"),o=o.replace(/%%SAFE_HTML_(\d+)%%/g,(s,l)=>{const r=parseInt(l,10);return i[r]||""}),o}function Um(e,t="pdf-table"){if(e.length<2)return"";const i=e.map(a=>a.trim().replace(/^\|/,"").replace(/\|$/,"").split("|").map(c=>c.trim())),n=i[0];let o=[],s=1;e.length>=2&&i[1].every(a=>/^:?-+:?$/.test(a))&&(o=i[1].map(a=>a.startsWith(":")&&a.endsWith(":")?"center":a.endsWith(":")?"right":"left"),s=2);const l=`<thead><tr>${n.map((a,c)=>`<th${o[c]?` style="text-align: ${o[c]}"`:""}>${rt(a)}</th>`).join("")}</tr></thead>`,r=i.slice(s).map(a=>`<tr>${a.map((c,d)=>`<td${o[d]?` style="text-align: ${o[d]}"`:""}>${rt(c)}</td>`).join("")}</tr>`).join("");return`<table class="${t}">${l}<tbody>${r}</tbody></table>`}function ts(e){return String(e||"").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;")}function jr(e,t="ts"){if(!e)return"";if(e.trim().startsWith("//"))return`<span class="token-comment">${ts(e)}</span>`;const i=[];function n(s,l){return i.push(`<span class="${s}">${ts(l)}</span>`),`__TOK_${i.length-1}__`}let o=e.replace(/(['"`])(.*?)\1/g,(s,l,r)=>n("token-string",`${l}${r}${l}`));return o=o.replace(/\b(import|export|from|const|let|var|function|return|default|type|interface|class|new|async|await)\b/g,s=>n("token-keyword",s)),o=o.replace(/\b(computed|ref|number|string|boolean|void|Array)\b/g,s=>n("token-type",s)),o=o.replace(/\b(\d+)\b/g,s=>n("token-number",s)),o=ts(o),o=o.replace(/__TOK_(\d+)__/g,(s,l)=>i[parseInt(l,10)]||""),o}function Vm(e,t){if(!e)return null;const i=e.frontmatter||{};if(i.hideInToc===!0||i.hideInToc==="true")return null;let n=(i.title||"").trim(),o=i.level?parseInt(i.level,10):0;if(!n){const s=e.blocks||[];for(const l of s){const a=(l.rawMarkdown||l.content||"").trim().match(/^(#{1,6})\s+(.*)$/);if(a){o||(o=a[1].length),n=a[2].trim();break}}}return n?((!o||isNaN(o))&&(o=1),{pageIndex:e.pageIndex||t,title:n,level:o}):null}function Km(e,t=1,i={}){const n=i.minDepth!==void 0?Number(i.minDepth):1,o=i.maxDepth!==void 0?Number(i.maxDepth):1/0,s=[];Array.isArray(e)&&e.forEach((c,d)=>{const m=Vm(c,d+1);m&&s.push(m)});const l=[];let r=null;for(const c of s){const d={...c,active:c.pageIndex===t,hasActiveChild:!1,children:[]};c.level===1||l.length===0?(l.push(d),r=d):r?(d.active&&(r.hasActiveChild=!0),r.children.push(d)):l.push(d)}function a(c,d=1){if(d>o)return[];const m=[];for(const b of c){const u=a(b.children,d+1);d>=n?m.push({...b,children:u}):m.push(...u)}return m}return a(l,1)}function qm(e,t=1,i={}){const n=Km(e,t,i),o=i.columns?Number(i.columns):1,s=o>1?` style="column-count: ${o};"`:"",l=i.textSm?" text-sm":"";function r(c,d=1){if(!c||c.length===0)return"";const m=`slidev-toc-list slidev-toc-list-level-${d}`,b=c.map(u=>{const h=u.active?" slidev-toc-item-active":u.hasActiveChild?" slidev-toc-item-parent-active":"",f=u.children&&u.children.length>0?r(u.children,d+1):"";let v=rt(u.title);return v.includes("LaTeX")&&(v=v.replace(/\$\\LaTeX\$/g,'<span class="font-math">L<sup>A</sup>T<sub>E</sub>X</span>')),`
        <li class="slidev-toc-item${h}" data-page="${u.pageIndex}">
          <a class="slidev-toc-link" href="javascript:void(0)">
            <span class="slidev-toc-title">${v}</span>
          </a>
          ${f}
        </li>
      `}).join("");return`<ol class="${m}">${b}</ol>`}const a=r(n,1);return`<div class="slidev-toc${l}"${s}>${a}</div>`}function ui(e,t){var $,T,D,E,x,W,V,G,X,C;let i="",n="",o="";const s=[];($=e.motion)!=null&&$.preset&&e.motion.preset!=="none"&&(i=` slidev-motion-${e.motion.preset.toLowerCase()}`,typeof e.motion.duration=="number"&&e.motion.duration>0&&s.push(`--motion-duration:${e.motion.duration}ms`),typeof e.motion.delay=="number"&&e.motion.delay>0&&s.push(`--motion-delay:${e.motion.delay}ms`));const l=((T=e.attributes)==null?void 0:T.style)||"";l&&(s.push(l),o=" slide-styled-block"),s.length>0&&(n=` style="${ct(s.join(";"))}"`);const r=(t==null?void 0:t.containerClassName)||"pdf-block",a=t!=null&&t.extraClassName?` ${t.extraClassName}`:"",c=`${r}${i}${o}${a}`,d=(e.rawMarkdown||e.content||"").trim();if(!d)return`<div class="${c}"${n}></div>`;if(d.includes('class="slidev-block-ref"')||d.includes('class="slidev-ref-tag"'))return`<div class="${c}"${n}>${d}</div>`;if(d.startsWith("$$")&&d.endsWith("$$")){const P=d.slice(2,-2).trim();return`<div class="${c} katex-display-container"${n}><div class="katex-display font-math"><em>${ct(P)}</em></div></div>`}const m=d.match(/^(#{1,6})\s+(.*)$/);if(m){const P=m[1].length,y=rt(m[2]),U=!!(e.isColFirst||e.type==="i"&&((D=t==null?void 0:t.extraClassName)!=null&&D.includes("slidev-col-first-heading-block")))?' class="slide-list-item-title"':"";return`<div class="${c}"${n}><h${P}${U}>${y}</h${P}></div>`}if(d.startsWith(":::")){const P=d.split(`
`),O=P[0].replace(/^:::\s*/,"").trim()||"info",U=P.slice(1,P[P.length-1].startsWith(":::")?-1:void 0).join(`
`),B=(t==null?void 0:t.calloutClassName)||"pdf-callout";return`<div class="${c}"${n}><div class="${B} ${B}--${O}"><div class="${B}-title">${O.toUpperCase()}</div><div class="${B}-body">${rt(U)}</div></div></div>`}if(d.startsWith("<<<")){const O=`// Inside ./snippets/external.ts
export function emptyArray<T>(length: number) {
  return Array.from<T>({ length })
}`.split(`
`).map((F,ee)=>`<span class="code-line shiki-focus"><span class="line-no">${ee+1}</span><span class="line-content">${jr(F,"ts")}</span></span>`).join(`
`),U=(t==null?void 0:t.codeClassName)||"pdf-code shiki-container",B=((E=e.attrs)==null?void 0:E["custom-slidev-max-height"])||e.maxHeight||"",R=B?` style="max-height:${ct(B)};overflow-y:auto;"`:"";return`<div class="${c}"${n}><pre class="${U}"${R}><span class="lang-badge">TS</span><code>${O}</code></pre></div>`}if(d.startsWith("<style")||d.startsWith("<!-- Inline style -->")||d.startsWith(`<!--
Notes`))return"";if(d.startsWith("```")){const P=d.split(`
`),y=P[0].slice(3).trim(),O=y.match(/^([^\s{\[]+)/),U=O?O[1]:"",B=y.match(/\[([^\]]+)\]/),R=B?B[1]:"",F=y.includes("twoslash"),ee=e.shikiLines||((x=y.match(/\{([^}]+)\}/))==null?void 0:x[1])||"",I=jm(ee),M=P.length>2?P[P.length-1]==="```"?P.slice(1,-1):P.slice(1):[d.slice(3).replace(/```$/,"")],J=(t==null?void 0:t.codeClassName)||"pdf-code shiki-container",Y=R?`${J} has-filename`:J,te=I!=="all",ie=M.map((ue,L)=>{const H=L+1,j=I==="all"||I.has(H)?"code-line shiki-focus":te?"code-line shiki-dimmed":"code-line";let _=(t==null?void 0:t.highlight)===!0?jr(ue,U):ct(ue);return F&&ue.includes("doubled.value = 2")?(_=_.replace(/(\bvalue\b)/,'<span class="twoslash-error-wavy">$1</span>'),`<span class="${j}"><span class="line-no">${H}</span><span class="line-content">${_}</span></span>
<div class="twoslash-popup-error"><span style="color:#ef4444;font-weight:bold;margin-right:4px;">✕</span> Cannot assign to 'value' because it is a read-only property.</div>`):`<span class="${j}"><span class="line-no">${H}</span><span class="line-content">${_}</span></span>`}).join(`
`),pe=U?`<span class="lang-badge">${ct(U)}</span>`:"",le=R?`<span class="code-filename">${ct(R)}</span>`:"",N=((W=e.attrs)==null?void 0:W["custom-slidev-max-height"])||e.maxHeight||"",ae=N?` style="max-height:${ct(N)};overflow-y:auto;"`:"";return`<div class="${c}"${n}><pre class="${Y}"${ae}>${le}${pe}<code>${ie}</code></pre></div>`}if(d.includes("|")&&d.split(`
`).filter(P=>P.trim().startsWith("|")).length>=2){const P=d.split(`
`).filter(O=>O.trim().startsWith("|")),y=Um(P,t==null?void 0:t.tableClassName);return`<div class="${c}"${n}>${y}</div>`}if(d.startsWith("> ")){const P=(t==null?void 0:t.quoteClassName)||"pdf-quote";return`<div class="${c}"${n}><blockquote class="${P}"><p>${rt(d.slice(2))}</p></blockquote></div>`}const b=/<video\b/i.test(d)||e.type==="video"||e.type==="NodeVideo",u=/^(\s*)([-*+]|\d+\.)\s+/m.test(d),h=/(?:^|\n)\s*#{1,6}\s+/.test(d);if(b&&!u&&!h&&!d.includes(`
`)){const P=((V=e.attributes)==null?void 0:V["custom-slidev-autoplay"])==="true"||/autoplay/i.test(d),y=((G=e.attributes)==null?void 0:G["custom-slidev-loop"])==="true"||/loop/i.test(d),O=((X=e.attributes)==null?void 0:X["custom-slidev-muted"])==="true"||P||/muted/i.test(d),U=((C=e.attributes)==null?void 0:C["custom-slidev-controls"])==="false",B=d.match(/\bsrc=["']([^"']+)["']/i),R=B?B[1]:"",F=['class="slide-video-player"'];U||F.push("controls"),P&&(F.push("autoplay"),F.push("playsinline")),y&&F.push("loop"),O&&F.push("muted"),F.push('preload="metadata"'),R&&F.push(`src="${R}"`);const ee=d.match(/<video[^>]*>([\s\S]*?)<\/video>/i);let I=ee?ee[1].trim():"";return!I&&R&&(I=`<source src="${R}" type="video/mp4" />您的浏览器不支持视频播放。`),`<div class="${c} ${c}--video slide-media-block slide-video-container slide-media-container" data-autoplay="${P?"true":"false"}" data-muted="${O?"true":"false"}"${n}><video ${F.join(" ")}>${I}</video></div>`}const f=d.match(/^!\[(.*?)\]\((.*?)\)$/);if(f){const P=(t==null?void 0:t.imageClassName)||"pdf-image slide-media-img";return`<div class="${c} ${c}--image slide-media-block slide-media-container"${n}><img alt="${ct(f[1])}" src="${f[2]}" class="${P}" /></div>`}const v=$a(d,t,e);if(v)return`<div class="${c} pdf-list-item"${n}>${v}</div>`;if(/<(?:Toc|toc)\b/i.test(d)&&!d.startsWith("```")){const P=d.match(/minDepth=["']?(\d+)["']?/i),y=d.match(/maxDepth=["']?(\d+)["']?/i),O=d.match(/columns=["']?(\d+)["']?/i),U=(t==null?void 0:t.allSlides)||[];return`<div class="${c}"${n}>${qm(U,(t==null?void 0:t.currentPageIndex)||1,{minDepth:P?parseInt(P[1],10):1,maxDepth:y?parseInt(y[1],10):1/0,columns:O?parseInt(O[1],10):1,textSm:d.includes("text-sm")})}</div>`}if(d.includes(`
`)||h){const P=Fm(d,t,e);if(P)return`<div class="${c}"${n}>${P}</div>`}const S=!!e.isColFirst?' class="slide-list-item-title"':"";return`<div class="${c}"${n}><p${S}>${rt(d)}</p></div>`}function Gm(e){return`
    ${_n(e)}

    :root {
      --slide-bg: #ffffff;
      --slide-text: #1a1a1a;
      --slide-accent: #3b82f6;
      --slide-font: system-ui, -apple-system, sans-serif;
    }
    [data-theme="dark"] {
      --slide-bg: #121214;
      --slide-text: #e2e8f0;
      --slide-accent: #60a5fa;
    }

    /* 1. 默认科技主题 Default */
    [data-slidev-theme="default"],
    .slidev-theme-default {
      --slide-font: system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "PingFang SC", "Microsoft YaHei", sans-serif;
      --slide-accent: #10b981;
    }
    [data-theme="light"][data-slidev-theme="default"],
    [data-theme="light"] .slidev-theme-default {
      --slide-bg: #ffffff;
      --slide-text: #1e293b;
      --slide-accent: #059669;
    }
    [data-theme="dark"][data-slidev-theme="default"],
    [data-theme="dark"] .slidev-theme-default {
      --slide-bg: #121214;
      --slide-text: #e2e8f0;
      --slide-accent: #34d399;
    }
    .slidev-theme-default .layout-cover h1,
    .slidev-theme-default .layout-cover .slide-block h1 {
      font-size: 3.8rem !important;
      font-weight: 800 !important;
      line-height: 1.15 !important;
      letter-spacing: -0.025em !important;
      margin-bottom: 18px !important;
      background: linear-gradient(135deg, #10b981, #06b6d4) !important;
      -webkit-background-clip: text !important;
      -webkit-text-fill-color: transparent !important;
    }
    .slidev-theme-default .layout-cover h2,
    .slidev-theme-default .layout-cover .slide-block h2 {
      font-size: 1.85rem !important;
      font-weight: 600 !important;
      opacity: 0.85 !important;
      margin-bottom: 12px !important;
    }
    .slidev-theme-default .layout-cover p,
    .slidev-theme-default .layout-cover .slide-block p {
      font-size: 1.45rem !important;
      line-height: 1.5 !important;
      opacity: 0.85 !important;
    }

    /* 2. 优雅衬线主题 Seriph */
    [data-slidev-theme="seriph"],
    .slidev-theme-seriph {
      --slide-font: "PT Serif", "Charter", "Georgia", "Cambria", "Times New Roman", "Source Han Serif SC", "Noto Serif SC", "Songti SC", "SimSun", serif;
      --slide-accent: #b45309;
      letter-spacing: 0.015em;
    }
    [data-theme="light"][data-slidev-theme="seriph"],
    [data-theme="light"] .slidev-theme-seriph {
      --slide-bg: #fdfbf7;
      --slide-text: #2a2521;
      --slide-accent: #b45309;
    }
    [data-theme="dark"][data-slidev-theme="seriph"],
    [data-theme="dark"] .slidev-theme-seriph {
      --slide-bg: #1c1a17;
      --slide-text: #e8e3d9;
      --slide-accent: #f59e0b;
    }
    .slidev-theme-seriph,
    .slidev-theme-seriph .slide-content {
      font-family: var(--slide-font) !important;
      line-height: 1.72;
    }
    .slidev-theme-seriph h1,
    .slidev-theme-seriph h2,
    .slidev-theme-seriph h3 {
      font-family: var(--slide-font) !important;
      letter-spacing: 0.025em;
      font-weight: 700;
    }
    .slidev-theme-seriph .layout-cover h1 {
      background: none !important;
      -webkit-background-clip: initial !important;
      -webkit-text-fill-color: initial !important;
      color: var(--slide-accent) !important;
      font-size: 3.4rem !important;
      border-bottom: 2px solid var(--slide-accent);
      display: inline-block;
      padding-bottom: 10px;
    }

    /* 3. 极简发布会主题 Apple Basic */
    [data-slidev-theme="apple-basic"],
    .slidev-theme-apple-basic {
      --slide-font: -apple-system, "SF Pro Display", "SF Pro Text", BlinkMacSystemFont, "PingFang SC", "Helvetica Neue", sans-serif;
      --slide-accent: #0071e3;
    }
    [data-theme="light"][data-slidev-theme="apple-basic"],
    [data-theme="light"] .slidev-theme-apple-basic {
      --slide-bg: #ffffff;
      --slide-text: #1d1d1f;
      --slide-accent: #0071e3;
    }
    [data-theme="dark"][data-slidev-theme="apple-basic"],
    [data-theme="dark"] .slidev-theme-apple-basic {
      --slide-bg: #000000;
      --slide-text: #f5f5f7;
      --slide-accent: #2997ff;
    }
    .slidev-theme-apple-basic,
    .slidev-theme-apple-basic .slide-content {
      font-family: var(--slide-font) !important;
    }
    .slidev-theme-apple-basic h1,
    .slidev-theme-apple-basic h2,
    .slidev-theme-apple-basic h3 {
      letter-spacing: -0.035em;
      font-weight: 800;
    }
    .slidev-theme-apple-basic .layout-cover h1 {
      background: none !important;
      -webkit-background-clip: initial !important;
      -webkit-text-fill-color: initial !important;
      color: var(--slide-text) !important;
      font-size: 3.8rem !important;
      letter-spacing: -0.04em !important;
    }
    .slidev-theme-apple-basic .layout-cover p {
      color: #86868b !important;
      font-size: 1.35rem !important;
    }

    * { box-sizing: border-box; margin: 0; padding: 0; }
    html, body {
      width: 100%; height: 100%; overflow: hidden;
      background: #0f1115; font-family: var(--slide-font);
      display: flex; justify-content: center; align-items: center;
    }
    #app { width: 100%; height: 100%; position: relative; overflow: hidden; }
    .slide-viewport {
      position: absolute; left: 50%; top: 50%;
      background: var(--slide-bg); color: var(--slide-text);
      box-shadow: 0 10px 30px rgba(0,0,0,0.5); border-radius: 8px; overflow: hidden;
      display: flex; flex-direction: column; flex-shrink: 0;
      transform: translate(-50%, -50%) scale(var(--slidev-slide-scale, 1));
      transform-origin: center center; will-change: transform;
      transition: background 0.3s ease, color 0.3s ease, border-radius 0.2s ease, box-shadow 0.2s ease;
    }
    :fullscreen .slide-viewport, .is-fullscreen .slide-viewport {
      border-radius: 0 !important; box-shadow: none !important;
    }
    .slide-content {
      position: relative;
      width: 100%;
      height: 100%;
      min-height: 100%;
      flex: 1 1 0%;
      padding: var(--slidev-padding-y, 32px) var(--slidev-padding-x, 48px);
      display: flex;
      flex-direction: column;
      overflow: hidden;
      box-sizing: border-box;
    }

    /* 间距预设风格 */
    .slide-content.spacing-compact,
    .slide-viewport[data-spacing="compact"] .slide-content,
    [data-slidev-spacing="compact"] {
      --slidev-padding-y: 20px;
      --slidev-padding-x: 36px;
      --slidev-header-gap: 10px;
      --slidev-title-margin-bottom: 6px;
    }
    .slide-content.spacing-normal,
    .slide-viewport[data-spacing="normal"] .slide-content,
    [data-slidev-spacing="normal"] {
      --slidev-padding-y: 32px;
      --slidev-padding-x: 48px;
      --slidev-header-gap: 16px;
      --slidev-title-margin-bottom: 10px;
    }
    .slide-content.spacing-loose,
    .slide-viewport[data-spacing="loose"] .slide-content,
    [data-slidev-spacing="loose"] {
      --slidev-padding-y: 48px;
      --slidev-padding-x: 56px;
      --slidev-header-gap: 24px;
      --slidev-title-margin-bottom: 16px;
    }

    .layout-cover { justify-content: center; align-items: center; text-align: center; }
    .layout-cover h1, .layout-cover .slide-block h1 { font-size: 3.8rem !important; font-weight: 800 !important; line-height: 1.15 !important; letter-spacing: -0.025em !important; margin-bottom: 16px !important; }
    .layout-cover h2, .layout-cover .slide-block h2 { font-size: 1.85rem !important; font-weight: 600 !important; opacity: 0.85 !important; margin-bottom: 12px !important; }
    .layout-cover p, .layout-cover .slide-block p { font-size: 1.45rem !important; line-height: 1.5 !important; opacity: 0.85 !important; }
    .two-cols-left, .two-cols-right { min-width: 0; width: 100%; display: flex; flex-direction: column; box-sizing: border-box; overflow-wrap: break-word; word-break: break-word; }
    .pdf-two-cols-wrapper,
    .layout-two-cols-grid,
    .layout-cols-wrapper,
    .layout-cols-grid {
      display: grid;
      grid-template-columns: var(--slide-grid-cols, minmax(0, 1fr) minmax(0, 1fr));
      grid-template-rows: minmax(0, 1fr) !important;
      gap: 32px;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      overflow: hidden !important;
    }
    .layout-cols-header-container,
    .layout-two-cols-header-container,
    .layout-three-cols-header-container,
    .layout-clover-container {
      display: flex;
      flex-direction: column;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      overflow: hidden !important;
    }
    .layout-header-section {
      width: 100%;
      margin-bottom: var(--slidev-header-gap, 16px) !important;
      flex-shrink: 0;
    }
    .layout-header-section h1,
    .layout-header-section h2,
    .layout-header-section h3 {
      margin-bottom: var(--slidev-title-margin-bottom, 10px) !important;
    }
    .pdf-three-cols-wrapper,
    .layout-three-cols-grid {
      display: grid;
      grid-template-columns: var(--slide-grid-cols, minmax(0, 1fr) minmax(0, 1fr) minmax(0, 1fr));
      grid-template-rows: minmax(0, 1fr) !important;
      gap: 24px;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      box-sizing: border-box;
      overflow: hidden !important;
    }
    .pdf-clover-wrapper,
    .layout-clover-grid {
      display: grid;
      grid-template-columns: repeat(2, minmax(0, 1fr)) !important;
      grid-template-rows: repeat(2, minmax(0, 1fr)) !important;
      gap: 20px;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      box-sizing: border-box;
      overflow: hidden !important;
    }
    .layout-clover-grid .pdf-col {
      background: transparent !important;
      border: none !important;
      box-shadow: none !important;
    }
    .pdf-col {
      display: flex;
      flex-direction: column;
      gap: 14px;
      min-width: 0;
      width: 100%;
      max-width: 100%;
      height: 100%;
      max-height: 100%;
      min-height: 0;
      justify-content: flex-start;
      box-sizing: border-box;
      overflow: hidden;
      overflow-wrap: break-word;
      word-break: break-word;
      white-space: normal;
    }
    .pdf-col * {
      overflow-wrap: break-word;
      word-break: break-word;
      box-sizing: border-box;
    }
    /* 表头多栏内超级块子块首个列表项去圆点后居中显示标题/首行文本 (仅在存在超级块分栏时生效) */
    .has-superblock-cols .pdf-col > *:first-child .slide-list-item-title,
    .has-superblock-cols .pdf-col > *:first-child :is(h1, h2, h3, h4, h5, h6),
    .has-superblock-cols .pdf-col > *:first-child p.slide-list-item-title,
    .has-superblock-cols .pdf-col > *:first-child p:first-of-type,
    .has-superblock-cols .pdf-col > *:first-child p:first-child,
    .has-superblock-cols .pdf-col > *:first-child :is(ul, ol) > li:first-child,
    .has-superblock-cols .pdf-col > *:first-child .slide-list > .slide-list-item:first-child,
    .has-superblock-cols .pdf-col > *:first-child .pdf-list > li:first-child,
    .has-superblock-cols .slidev-col-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    .has-superblock-cols .slidev-col-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      list-style: none !important;
      list-style-type: none !important;
      text-align: center !important;
      margin-left: 0 !important;
      padding-left: 0 !important;
      width: 100% !important;
    }

    /* 彻底清除首个列表项的原生圆点 Marker (仅在存在超级块分栏时生效) */
    .has-superblock-cols .pdf-col > *:first-child :is(ul, ol) > li:first-child::marker {
      content: "" !important;
      display: none !important;
    }

    /* 确保首个列表项内部内联与块级元素居中 (仅在存在超级块分栏时生效) */
    .has-superblock-cols .pdf-col > *:first-child :is(ul, ol) > li:first-child * {
      text-align: center !important;
    }

    /* 栏内说明段落与列表项：左对齐，自然阅读排版 */
    .has-superblock-cols .pdf-col .slide-list-item-desc,
    .has-superblock-cols .pdf-col li:not(:first-child) {
      text-align: left !important;
    }

    /* 全局特定标题大小规范化 (除封面外页首首个标题按 H2 1.7rem，表头多栏内首个标题按 H3 1.3rem) */
    [data-normalize-headings="true"] .slidev-page-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .slidev-page-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .slide-content:not(.layout-cover) > :is(.pdf-block, .slide-block):first-child :is(h1, h2, h3, h4, h5, h6),
    [data-normalize-headings="true"] .slide-content:not(.layout-cover) > .layout-header-section :is(.pdf-block, .slide-block):first-child :is(h1, h2, h3, h4, h5, h6),
    [data-normalize-headings="true"] .slide-content:not(.layout-cover) > :not(.layout-cols-wrapper):not(.pdf-two-cols-wrapper):not(.layout-image-cols-grid):first-child :is(h1, h2, h3, h4, h5, h6) {
      font-size: 1.7rem !important;
      font-weight: 600 !important;
      line-height: 1.25 !important;
      margin-bottom: 10px !important;
    }

    [data-normalize-headings="true"] .has-superblock-cols .slidev-col-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .has-superblock-cols .slidev-col-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .has-superblock-cols .pdf-col > *:first-child :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      font-size: 1.3rem !important;
      font-weight: 600 !important;
      line-height: 1.3 !important;
      margin-bottom: 8px !important;
      text-align: center !important;
    }

    /* 图左与图右版式标题完全保留用户原始字号与默认排版，不进行任何固定大小规范化 */
    [data-normalize-headings="true"] :is(.layout-image-left, .layout-image-right, .image-left-content, .image-right-content) :is(h1, h2, h3, h4, h5, h6) {
      text-align: left !important;
    }
    .pdf-col pre,
    .two-cols-left pre,
    .two-cols-right pre,
    .image-right-content pre,
    .image-left-content pre {
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      overflow-x: hidden !important;
      overflow-y: auto !important;
      max-width: 100% !important;
      box-sizing: border-box !important;
    }
    .slide-content.layout-image-right, .slide-content.layout-image-left {
      padding: 0;
      display: grid;
      grid-template-columns: var(--slide-grid-cols, minmax(0, 1fr) minmax(0, 1fr));
      grid-template-rows: 100%;
      width: 100%;
      height: 100%;
      position: absolute;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      box-sizing: border-box;
    }
    .image-right-content, .image-left-content {
      padding: 44px 50px;
      display: flex;
      flex-direction: column;
      justify-content: flex-start;
      overflow-y: auto;
      width: 100%;
      height: 100%;
      box-sizing: border-box;
    }
    .image-right-img-container, .image-left-img-container {
      width: 100%;
      height: 100%;
      overflow: hidden;
      position: relative;
      background: #18181b;
      display: flex;
      align-items: center;
      justify-content: center;
    }
    .image-right-img, .image-left-img {
      width: 100%;
      height: 100%;
      object-fit: cover;
      object-position: center;
      display: block;
    }
    .slide-block { margin-bottom: 14px; line-height: 1.6; }
    .slide-block h1 { font-size: 2.2rem; margin-bottom: 12px; }
    .slide-block h2 { font-size: 1.7rem; margin-bottom: 10px; }
    .slide-block p { font-size: 1.15rem; }
    .slide-block ul, .slide-block ol, .pdf-list {
      padding-left: 28px;
      margin: 8px 0;
      display: flex;
      flex-direction: column;
      gap: 6px;
    }
    .slide-block li, .pdf-list li {
      font-size: 1.15rem;
      line-height: 1.6;
    }
    .pdf-task-item {
      list-style: none;
      margin-left: -20px;
      display: flex;
      align-items: center;
      gap: 8px;
    }
    .pdf-task-item input[type="checkbox"] {
      width: 1.15em;
      height: 1.15em;
      cursor: pointer;
    }

    /* 两栏与三栏及多栏（超级块分栏）布局：紧凑自然行距，子列表保留圆点与层级缩进 */
    .layout-two-cols ul,
    .layout-cols-header ul,
    .layout-two-cols-header ul,
    .layout-three-cols ul,
    .layout-three-cols-header ul,
    .two-cols-left ul,
    .two-cols-right ul,
    .three-cols-col ul,
    .col ul,
    .pdf-col ul,
    .layout-two-cols-grid .pdf-list,
    .layout-three-cols-grid .pdf-list,
    .layout-cols-grid .pdf-list,
    .layout-two-cols-grid .pdf-list--unordered,
    .layout-three-cols-grid .pdf-list--unordered,
    .layout-cols-grid .pdf-list--unordered {
      list-style: disc !important;
      list-style-type: disc !important;
      padding-left: 1.25em !important;
      margin-left: 0 !important;
      margin-top: 0 !important;
      margin-bottom: 8px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: block !important;
    }

    .layout-two-cols ol,
    .layout-cols-header ol,
    .layout-two-cols-header ol,
    .layout-three-cols ol,
    .layout-three-cols-header ol,
    .two-cols-left ol,
    .two-cols-right ol,
    .three-cols-col ol,
    .col ol,
    .pdf-col ol,
    .layout-two-cols-grid .pdf-list--ordered,
    .layout-three-cols-grid .pdf-list--ordered,
    .layout-cols-grid .pdf-list--ordered {
      list-style: decimal !important;
      list-style-type: decimal !important;
      padding-left: 1.25em !important;
      margin-left: 0 !important;
      margin-top: 0 !important;
      margin-bottom: 8px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: block !important;
    }

    .layout-two-cols li,
    .layout-cols-header li,
    .layout-two-cols-header li,
    .layout-three-cols li,
    .layout-three-cols-header li,
    .two-cols-left li,
    .two-cols-right li,
    .three-cols-col li,
    .col li,
    .pdf-col li,
    .pdf-col .pdf-list-item {
      padding-left: 0.2em !important;
      margin-left: 0 !important;
      margin-bottom: 6px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: list-item !important;
      line-height: 1.6 !important;
    }

    .layout-two-cols ul ul,
    .layout-three-cols ul ul,
    .three-cols-col ul ul,
    .pdf-col ul ul {
      list-style: circle !important;
      list-style-type: circle !important;
      padding-left: 1.25em !important;
      margin-top: 4px !important;
      margin-bottom: 4px !important;
    }

    /* 列表项内嵌标题与说明排版 */
    .slide-list-item-title,
    .pdf-list li > h1,
    .pdf-list li > h2,
    .pdf-list li > h3,
    .pdf-list li > h4,
    .pdf-list li > h5,
    .pdf-list li > h6,
    li > h1.slide-list-item-title,
    li > h2.slide-list-item-title,
    li > h3.slide-list-item-title,
    li > h4.slide-list-item-title {
      margin-top: 2px !important;
      margin-bottom: 6px !important;
      line-height: 1.35 !important;
      font-weight: 700 !important;
    }
    .pdf-list li > h1, li > h1.slide-list-item-title { font-size: 1.6rem !important; }
    .pdf-list li > h2, li > h2.slide-list-item-title { font-size: 1.4rem !important; }
    .pdf-list li > h3, li > h3.slide-list-item-title { font-size: 1.22rem !important; }
    .pdf-list li > h4, li > h4.slide-list-item-title { font-size: 1.1rem !important; }

    /* 全局特定标题大小规范化后置强力锁定 (防止被列表项内部字号覆盖) */
    [data-normalize-headings="true"] .slidev-page-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .slidev-page-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      font-size: 1.7rem !important;
      font-weight: 600 !important;
      line-height: 1.25 !important;
      margin-bottom: 10px !important;
    }
    [data-normalize-headings="true"] .slidev-col-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .slidev-col-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] :is(.layout-cols-wrapper, .pdf-two-cols-wrapper, .layout-cols-header-container, .layout-cols-grid) .pdf-col > *:first-child :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] :is(.two-cols-left, .two-cols-right, .pdf-col, .col) > *:first-child :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      font-size: 1.3rem !important;
      font-weight: 600 !important;
      line-height: 1.3 !important;
      margin-bottom: 8px !important;
      text-align: center !important;
    }
    .slide-list-item-desc,
    .pdf-list li > p {
      margin-top: 4px !important;
      margin-bottom: 6px !important;
      font-size: 1.05rem;
      line-height: 1.55;
      opacity: 0.92;
    }

    /* 多媒体（GIF动图、静态图片、MP4视频）全视口最大化自适应且不超出视口 */
    .slide-media-block,
    .slide-media-container,
    .slide-video-container,
    .slide-block--media,
    .slide-block--image,
    .slide-block--video,
    .slide-block:has(> img),
    .slide-block:has(> .slide-media-container),
    .slide-block:has(> p > img:only-child),
    .slide-block:has(> .slide-video-container),
    .slide-block:has(> video) {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      min-width: 0 !important;
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
      justify-content: center !important;
      width: 100% !important;
      height: 100% !important;
      max-height: 100% !important;
      overflow: hidden !important;
      margin: 4px 0 !important;
      box-sizing: border-box !important;
    }

    .two-cols-left > .slide-block,
    .two-cols-right > .slide-block,
    .three-cols-col > .slide-block,
    .pdf-col > .slide-block,
    .pdf-col .slide-block {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      max-height: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      width: 100% !important;
      height: 100% !important;
      box-sizing: border-box !important;
      overflow: hidden !important;
      margin-bottom: 0 !important;
    }

    /* 列内列表项的标题与段落文字：固定高度，不压缩 */
    .two-cols-left .slide-list-item-title,
    .two-cols-right .slide-list-item-title,
    .three-cols-col .slide-list-item-title,
    .pdf-col .slide-list-item-title,
    .two-cols-left h1, .two-cols-left h2, .two-cols-left h3, .two-cols-left h4, .two-cols-left h5, .two-cols-left h6,
    .two-cols-right h1, .two-cols-right h2, .two-cols-right h3, .two-cols-right h4, .two-cols-right h5, .two-cols-right h6,
    .three-cols-col h1, .three-cols-col h2, .three-cols-col h3, .three-cols-col h4, .three-cols-col h5, .three-cols-col h6,
    .pdf-col h1, .pdf-col h2, .pdf-col h3, .pdf-col h4, .pdf-col h5, .pdf-col h6,
    .three-cols-col .slide-list-item-desc,
    .pdf-col .slide-list-item-desc {
      flex: 0 0 auto !important;
      margin-top: 0 !important;
      margin-bottom: 6px !important;
    }

    /* 列内媒体容器：填满标题下方所有剩余垂直空间，纵向顶部对齐，横向居中，无溢出 */
    .two-cols-left .slide-list-media,
    .two-cols-right .slide-list-media,
    .three-cols-col .slide-list-media,
    .pdf-col .slide-list-media,
    .two-cols-left .slide-video-container,
    .two-cols-right .slide-video-container,
    .three-cols-col .slide-video-container,
    .pdf-col .slide-video-container,
    .two-cols-left .slide-media-container,
    .two-cols-right .slide-media-container,
    .three-cols-col .slide-media-container,
    .pdf-col .slide-media-container {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      min-width: 0 !important;
      width: 100% !important;
      height: 100% !important;
      max-height: 100% !important;
      max-width: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
      justify-content: flex-start !important;
      overflow: hidden !important;
      margin: 0 !important;
      padding: 0 !important;
      box-sizing: border-box !important;
    }

    /* 列内多媒体播放器：以 contain 模式等比缩放完整可见，绝对不超高超宽、不产生遮挡与滚动条 */
    .two-cols-left video,
    .two-cols-right video,
    .three-cols-col video,
    .pdf-col video,
    .two-cols-left img,
    .two-cols-right img,
    .three-cols-col img,
    .pdf-col img,
    .two-cols-left .slide-video-player,
    .two-cols-right .slide-video-player,
    .three-cols-col .slide-video-player,
    .pdf-col .slide-video-player,
    .layout-three-cols-grid video,
    .layout-two-cols-grid video,
    .layout-three-cols-grid img,
    .layout-two-cols-grid img {
      max-width: 100% !important;
      max-height: 100% !important;
      width: auto !important;
      height: auto !important;
      min-width: 0 !important;
      min-height: 0 !important;
      object-fit: contain !important;
      display: block !important;
      margin: 0 auto !important;
      cursor: zoom-in;
    }

    .slide-block img,
    .slide-media-img,
    .slide-media-container img,
    .slide-video-player,
    video.slide-video-player,
    .slide-block video {
      max-width: 100% !important;
      max-height: 100% !important;
      width: auto !important;
      height: auto !important;
      min-width: 0 !important;
      min-height: 0 !important;
      object-fit: contain !important;
      display: block !important;
      margin: 0 auto !important;
      border-radius: 8px;
      box-shadow: 0 4px 16px rgba(0, 0, 0, 0.16);
      background: transparent;
      outline: none;
      cursor: zoom-in;
    }

    .slide-list-media {
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
      justify-content: flex-start !important;
      width: 100% !important;
      max-width: 100% !important;
      height: 100% !important;
      max-height: 100% !important;
      flex: 1 1 0% !important;
      margin-top: 4px !important;
      margin-bottom: 4px !important;
      min-height: 0 !important;
      overflow: hidden !important;
      box-sizing: border-box !important;
    }
    .slide-list-media img,
    .slide-list-media video,
    .slide-list-media .list-item-gif,
    .slide-list-media .slide-video-player {
      max-width: 100% !important;
      max-height: 100% !important;
      width: auto !important;
      height: auto !important;
      min-width: 0 !important;
      min-height: 0 !important;
      object-fit: contain !important;
      border-radius: 6px !important;
      box-shadow: 0 3px 12px rgba(0, 0, 0, 0.14) !important;
      display: block !important;
      margin: 0 auto !important;
      cursor: zoom-in;
    }

    .slide-block:has(.slide-list-media) {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      height: 100% !important;
      max-height: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      overflow: hidden !important;
    }
    .slide-block:has(.slide-list-media) .pdf-list,
    .slide-block:has(.slide-list-media) ul,
    .slide-block:has(.slide-list-media) ol {
      display: block !important;
      flex: 1 1 auto;
      min-height: 0;
      max-height: 100%;
      overflow: visible !important;
      list-style: disc !important;
      list-style-type: disc !important;
    }
    .slide-block:has(.slide-list-media) li,
    .slide-block:has(.slide-list-media) .slide-list-item,
    .slide-block:has(.slide-list-media) .pdf-list-item,
    .slide-block:has(.slide-media-container) li,
    .slide-block:has(.slide-video-container) li,
    .layout-cols-wrapper li:has(.slide-list-media),
    .layout-cols-header-container li:has(.slide-list-media),
    .two-cols-left li:has(.slide-list-media),
    .two-cols-right li:has(.slide-list-media),
    .three-cols-col li:has(.slide-list-media),
    .pdf-col li:has(.slide-list-media),
    li:has(.slide-list-media),
    li:has(.slide-video-container),
    li:has(.slide-media-container) {
      display: list-item !important;
      list-style-type: disc !important;
      flex: 0 0 auto !important;
      height: auto !important;
      max-height: none !important;
      overflow: visible !important;
      margin-bottom: 6px !important;
    }

    .layout-two-cols .slide-media-block,
    .layout-two-cols .slide-video-container,
    .layout-two-cols .slide-media-container,
    .layout-three-cols .slide-media-block,
    .layout-three-cols .slide-video-container,
    .layout-three-cols .slide-media-container {
      max-width: 100% !important;
      max-height: 100% !important;
      width: 100% !important;
      height: 100% !important;
      min-width: 0 !important;
      min-height: 0 !important;
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
      justify-content: flex-start !important;
      overflow: hidden !important;
    }

    /* Lightbox 大图与视频灯箱模态窗口 */
    .slidev-lightbox {
      position: fixed;
      top: 0;
      left: 0;
      width: 100vw;
      height: 100vh;
      background: rgba(0, 0, 0, 0.88);
      backdrop-filter: blur(8px);
      z-index: 999999;
      display: none;
      align-items: center;
      justify-content: center;
      cursor: zoom-out;
      opacity: 0;
      transition: opacity 0.2s cubic-bezier(0.16, 1, 0.3, 1);
    }
    .slidev-lightbox.active {
      display: flex;
      opacity: 1;
    }
    .slidev-lightbox-content {
      position: relative;
      max-width: 92vw;
      max-height: 92vh;
      display: flex;
      align-items: center;
      justify-content: center;
      cursor: default;
    }
    .slidev-lightbox-img {
      max-width: 92vw;
      max-height: 92vh;
      object-fit: contain;
      border-radius: 8px;
      box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.75);
    }
    .slidev-lightbox-video {
      max-width: 92vw;
      max-height: 92vh;
      border-radius: 8px;
      box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.75);
    }
    .slidev-lightbox-close {
      position: absolute;
      top: 24px;
      right: 28px;
      width: 40px;
      height: 40px;
      background: rgba(255, 255, 255, 0.2);
      border: 1px solid rgba(255, 255, 255, 0.35);
      border-radius: 50%;
      color: #fff;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 22px;
      cursor: pointer;
      transition: background 0.2s, transform 0.2s;
      z-index: 1000000;
    }
    .slidev-lightbox-close:hover {
      background: rgba(255, 255, 255, 0.35);
      transform: scale(1.05);
    }

    img.slide-inline-img {
      max-width: 100% !important;
      max-height: min(320px, 40vh) !important;
      object-fit: contain !important;
      vertical-align: middle;
      border-radius: 4px;
    }
    kbd {
      display: inline-block;
      padding: 2px 7px;
      font-family: ui-monospace, SFMono-Regular, "SF Mono", Menlo, Consolas, "Liberation Mono", monospace;
      font-size: 0.85em;
      font-weight: 600;
      line-height: 1.25;
      color: inherit;
      background: rgba(125, 125, 125, 0.12);
      border: 1px solid rgba(125, 125, 125, 0.35);
      border-bottom-width: 2px;
      border-radius: 5px;
      box-shadow: 0 1px 2px rgba(0, 0, 0, 0.12);
      margin: 0 2px;
      vertical-align: middle;
      white-space: nowrap;
    }
    [data-theme="dark"] kbd, .theme-dark kbd {
      background: rgba(255, 255, 255, 0.1);
      border-color: rgba(255, 255, 255, 0.25);
      border-bottom-color: rgba(255, 255, 255, 0.4);
      color: #f1f5f9;
      box-shadow: 0 1px 2px rgba(0, 0, 0, 0.4);
    }
    .slide-block pre,
    pre {
      background: rgba(0, 0, 0, 0.1);
      padding: 12px;
      border-radius: 6px;
      font-family: "JetBrains Mono", Consolas, monospace;
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      overflow-x: hidden !important;
      overflow-y: auto !important;
      max-width: 100% !important;
      box-sizing: border-box !important;
    }
    .slide-block pre code,
    pre code {
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      display: block !important;
      width: 100% !important;
      box-sizing: border-box !important;
    }
    .code-line {
      display: flex !important;
      align-items: flex-start !important;
      width: 100% !important;
      box-sizing: border-box !important;
      line-height: 1.6;
    }
    .code-line .line-no {
      display: inline-block !important;
      flex-shrink: 0 !important;
      min-width: 2.2em !important;
      text-align: right !important;
      margin-right: 12px !important;
      user-select: none !important;
      opacity: 0.45 !important;
    }
    .code-line .line-content {
      flex: 1 1 0% !important;
      min-width: 0 !important;
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
    }
    /* 弱提示滚动条样式 */
    * {
      scrollbar-width: thin;
      scrollbar-color: rgba(255, 255, 255, 0.20) transparent;
    }
    *::-webkit-scrollbar {
      width: 4px;
      height: 4px;
    }
    *::-webkit-scrollbar-track {
      background: transparent;
    }
    *::-webkit-scrollbar-thumb {
      background: rgba(255, 255, 255, 0.20);
      border-radius: 2px;
      transition: background 0.2s ease;
    }
    *:hover::-webkit-scrollbar-thumb,
    *::-webkit-scrollbar-thumb:hover {
      background: rgba(255, 255, 255, 0.45);
    }
    /* Slidev Micro-motion Keyframes & Presets */
    @keyframes slidevMotionFadeIn { from { opacity: 0; } to { opacity: 1; } }
    @keyframes slidevMotionSlideUp { from { opacity: 0; transform: translateY(40px); } to { opacity: 1; transform: translateY(0); } }
    @keyframes slidevMotionSlideDown { from { opacity: 0; transform: translateY(-40px); } to { opacity: 1; transform: translateY(0); } }
    @keyframes slidevMotionSlideLeft { from { opacity: 0; transform: translateX(40px); } to { opacity: 1; transform: translateX(0); } }
    @keyframes slidevMotionSlideRight { from { opacity: 0; transform: translateX(-40px); } to { opacity: 1; transform: translateX(0); } }
    @keyframes slidevMotionZoomIn { from { opacity: 0; transform: scale(0.8); } to { opacity: 1; transform: scale(1); } }
    @keyframes slidevMotionBounce {
      0% { opacity: 0; transform: translateY(40px); }
      60% { opacity: 1; transform: translateY(-8px); }
      80% { transform: translateY(4px); }
      100% { transform: translateY(0); }
    }
    .slidev-motion-fade-in { animation: slidevMotionFadeIn var(--motion-duration, 0.4s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slidev-motion-slide-up { animation: slidevMotionSlideUp var(--motion-duration, 0.45s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slidev-motion-slide-down { animation: slidevMotionSlideDown var(--motion-duration, 0.45s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slidev-motion-slide-left { animation: slidevMotionSlideLeft var(--motion-duration, 0.45s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slidev-motion-slide-right { animation: slidevMotionSlideRight var(--motion-duration, 0.45s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slidev-motion-zoom-in, .slidev-motion-pop { animation: slidevMotionZoomIn var(--motion-duration, 0.4s) cubic-bezier(0.34, 1.56, 0.64, 1) var(--motion-delay, 0s) both; }
    .slidev-motion-bounce { animation: slidevMotionBounce var(--motion-duration, 0.6s) cubic-bezier(0.34, 1.56, 0.64, 1) var(--motion-delay, 0s) both; }
    .controls {
      position: absolute; bottom: 16px; display: flex; gap: 12px; align-items: center;
      background: rgba(24, 24, 27, 0.8); backdrop-filter: blur(8px);
      padding: 6px 18px; border-radius: 20px; color: #fff; font-size: 13px; z-index: 10;
      opacity: 0; pointer-events: auto;
      transition: opacity 0.3s cubic-bezier(0.16, 1, 0.3, 1), transform 0.3s cubic-bezier(0.16, 1, 0.3, 1);
    }
    .controls::before {
      content: ""; position: absolute; top: -20px; bottom: -16px; left: -24px; right: -24px;
    }
    .controls:hover, .controls:focus-within {
      opacity: 1; transform: translateY(-2px);
    }
    .controls button { background: transparent; border: none; color: inherit; cursor: pointer; padding: 2px 6px; }

    /* Slidev Native Icons & Interactive Buttons */
    .slidev-icon-btn {
      display: inline-flex !important; flex-direction: row !important; align-items: center !important; justify-content: center !important;
      padding: 0.35rem 0.5rem; border-radius: 0.375rem; background: transparent;
      border: 1px solid transparent; color: inherit; font-size: inherit; line-height: 1;
      cursor: pointer; opacity: 0.8; transition: all 0.2s ease; text-decoration: none;
      vertical-align: middle; user-select: none; margin: 0 4px;
    }
    .slidev-icon-btn:hover { opacity: 1; background: rgba(255, 255, 255, 0.12); border-color: rgba(255, 255, 255, 0.15); }

    /* 组件从上到下按顺序流式渲染，避免相互重叠 */
    .slide-block > div + div { margin-top: 14px; }

    /* 同一个 div 内的按钮/链接从左到右水平渲染 */
    .slide-block div:has(> .slidev-icon-btn),
    .slide-block div:has(> button),
    .slide-block [class*="abs-"],
    .slidev-btn-row {
      display: inline-flex !important;
      flex-direction: row !important;
      align-items: center !important;
      justify-content: center !important;
      flex-wrap: wrap !important;
      gap: 8px !important;
    }

    /* Position Shortcuts 适配：在组件流中保持从上到下排列，不脱离流产生重叠 */
    .slide-block .abs-br,
    .slide-block .abs-bl,
    .slide-block .abs-tr,
    .slide-block .abs-tl,
    .slide-block [class*="abs-"] {
      position: relative !important;
      bottom: auto !important;
      right: auto !important;
      top: auto !important;
      left: auto !important;
      margin: 0.75rem auto !important;
    }

    .slide-block--absolute { position: relative !important; margin-bottom: 14px !important; padding: 0 !important; background: transparent !important; }
    .slide-block--absolute:hover { background: transparent !important; }
    .mt-12 { margin-top: 3rem !important; }
    .py-1 { padding-top: 0.25rem !important; padding-bottom: 0.25rem !important; }
    .m-6 { margin: 1.5rem !important; }
    .text-xl { font-size: 1.25rem !important; }
    [hover\\:bg~="white"][hover\\:bg~="op-10"]:hover,
    [hover\\:bg="white op-10"]:hover { background: rgba(255, 255, 255, 0.1) !important; border-radius: 4px; }
    .cursor-pointer, [data-clickable] { cursor: pointer; }
    /* Slidev 规范链接排版 (继承正文颜色，虚线底边，Hover 时平滑点亮为主题色并转为实线) */
    .slide-content a:not(.slidev-ref-tag):not(.slidev-icon-btn):not(.slidev-toc-link),
    .slide-block a:not(.slidev-ref-tag):not(.slidev-icon-btn):not(.slidev-toc-link),
    a.slidev-link {
      color: inherit;
      text-decoration: none;
      border-bottom: 1px dashed currentColor;
      transition: color 0.2s cubic-bezier(0.4, 0, 0.2, 1),
                  border-color 0.2s cubic-bezier(0.4, 0, 0.2, 1),
                  border-bottom-style 0.2s cubic-bezier(0.4, 0, 0.2, 1);
      cursor: pointer;
    }
    .slide-content a:not(.slidev-ref-tag):not(.slidev-icon-btn):not(.slidev-toc-link):hover,
    .slide-block a:not(.slidev-ref-tag):not(.slidev-icon-btn):not(.slidev-toc-link):hover,
    a.slidev-link:hover {
      color: var(--slide-accent);
      border-bottom-style: solid;
      border-bottom-color: var(--slide-accent);
    }
    .slidev-ref-tag, a.slidev-ref-tag {
      display: inline-flex;
      align-items: center;
      background: color-mix(in srgb, var(--slide-accent) 12%, transparent);
      color: var(--slide-accent);
      border-radius: 4px;
      padding: 2px 8px;
      font-size: 0.88em;
      text-decoration: none;
      cursor: pointer;
      margin: 2px 4px 2px 0;
      border: 1px solid color-mix(in srgb, var(--slide-accent) 25%, transparent);
      transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
    }
    .slidev-ref-tag:hover, a.slidev-ref-tag:hover {
      background: color-mix(in srgb, var(--slide-accent) 22%, transparent);
      color: var(--slide-accent);
      border-color: color-mix(in srgb, var(--slide-accent) 55%, transparent);
      transform: translateY(-1px);
      box-shadow: 0 2px 8px color-mix(in srgb, var(--slide-accent) 20%, transparent);
    }
    .slidev-block-ref {
      display: block;
      padding: 10px 14px;
      background: color-mix(in srgb, var(--slide-accent) 8%, transparent);
      border-left: 3px solid var(--slide-accent);
      border-radius: 0 6px 6px 0;
      margin: 8px 0;
      cursor: pointer;
      transition: background 0.2s ease;
    }
    .slidev-block-ref:hover {
      background: color-mix(in srgb, var(--slide-accent) 15%, transparent);
    }

    /* 页面动态蒙版 (Dynamic Mask) GPU 合成器硬件加速体系 */
    .slidev-mask-body-container {
      position: relative;
      width: 100%;
      height: 100%;
      min-height: 0;
      flex: 1;
      display: flex;
      flex-direction: column;
      overflow: hidden !important;
      contain: layout paint;
      isolation: isolate;
    }
    .slidev-mask-body-container--has-mask {
      overflow: hidden !important;
      /* 向左右、向下突破父容器内边距，完全贴合幻灯片视口边缘 */
      margin-left: calc(-1 * var(--slidev-padding-x, 48px)) !important;
      margin-right: calc(-1 * var(--slidev-padding-x, 48px)) !important;
      margin-bottom: calc(-1 * var(--slidev-padding-y, 32px)) !important;
      padding-left: var(--slidev-padding-x, 48px) !important;
      padding-right: var(--slidev-padding-x, 48px) !important;
      padding-bottom: var(--slidev-padding-y, 32px) !important;
      width: calc(100% + 2 * var(--slidev-padding-x, 48px)) !important;
      box-sizing: border-box !important;
    }
    /* 无标题且首个元素即为蒙版正文容器时，向上同步扩展至顶部边缘 */
    .slide-content-wrapper > .slidev-mask-body-container--has-mask:first-child,
    .slide-content > .slidev-mask-body-container--has-mask:first-child {
      margin-top: calc(-1 * var(--slidev-padding-y, 32px)) !important;
      padding-top: var(--slidev-padding-y, 32px) !important;
    }
    /* 针对全屏零内边距特殊布局（如 image-right/image-left），重置内边距变量避免越界 */
    .slide-content-wrapper.layout-image-right,
    .slide-content-wrapper.layout-image-left,
    .slide-content.layout-image-right,
    .slide-content.layout-image-left {
      --slidev-padding-x: 0px !important;
      --slidev-padding-y: 0px !important;
    }
    /* 蒙版运动总图层：纯 GPU Compositor 硬件加速 translate3d */
    .slidev-mask-layer {
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      pointer-events: none;
      z-index: 50;
      will-change: transform, opacity;
      transform: translate3d(0, 0, 0);
      backface-visibility: hidden;
      transition: transform 0.42s cubic-bezier(0.2, 0, 0, 1),
                  opacity 0.42s cubic-bezier(0.2, 0, 0, 1);
    }
    /* 蒙版内部遮罩层：纯色或磨砂玻璃 */
    .slidev-mask-overlay {
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      pointer-events: none;
    }
    .slidev-mask-layer--solid .slidev-mask-overlay,
    .slidev-mask-overlay--solid {
      background: var(--slide-bg, #ffffff);
    }
    [data-theme="dark"] .slidev-mask-layer--solid .slidev-mask-overlay,
    [data-theme="dark"] .slidev-mask-overlay--solid {
      background: var(--slide-bg, #121214);
    }
    .slidev-mask-layer--blur .slidev-mask-overlay,
    .slidev-mask-overlay--blur {
      backdrop-filter: blur(30px) saturate(180%);
      -webkit-backdrop-filter: blur(30px) saturate(180%);
      background: color-mix(in srgb, var(--slide-bg, #ffffff) 90%, transparent);
    }
    [data-theme="dark"] .slidev-mask-layer--blur .slidev-mask-overlay,
    [data-theme="dark"] .slidev-mask-overlay--blur {
      background: color-mix(in srgb, var(--slide-bg, #121214) 90%, transparent);
    }
    /* 动态展露分界提示线：物理内嵌于蒙版边缘，相对坐标永为 0，绝对物理同步 */
    .slidev-mask-divider-line {
      position: absolute;
      pointer-events: none;
      z-index: 51;
      opacity: 0;
      transition: opacity 0.3s ease;
    }
    .slidev-mask-layer--down .slidev-mask-divider-line,
    .slidev-mask-divider-line--down {
      top: 0;
      left: 0;
      right: 0;
      height: 2.5px;
      transform: translateY(-50%);
      background: linear-gradient(90deg, transparent 0%, var(--slide-accent, #3b82f6) 6%, var(--slide-accent, #3b82f6) 94%, transparent 100%);
      box-shadow: 0 0 10px var(--slide-accent, #3b82f6), 0 0 4px var(--slide-accent, #3b82f6);
    }
    .slidev-mask-layer--right .slidev-mask-divider-line,
    .slidev-mask-divider-line--right {
      top: 0;
      bottom: 0;
      left: 0;
      width: 2.5px;
      transform: translateX(-50%);
      background: linear-gradient(180deg, transparent 0%, var(--slide-accent, #3b82f6) 6%, var(--slide-accent, #3b82f6) 94%, transparent 100%);
      box-shadow: 0 0 10px var(--slide-accent, #3b82f6), 0 0 4px var(--slide-accent, #3b82f6);
    }`}function Zm(){return`    (function() {
      const data = window.__SLIDEV_DATA__ || { slides: [] };
      const slides = data.slides || [];
      let currentIndex = 0;

      const container = document.getElementById("slide-container");
      const pageNum = document.getElementById("page-num");
      const btnPrev = document.getElementById("btn-prev");
      const btnNext = document.getElementById("btn-next");
      const btnFullscreen = document.getElementById("btn-fullscreen");

      // 「数字+回车」跳页输入角标：右下角悬浮显示，独立于缩放视口
      const jumpBadge = document.createElement("div");
      jumpBadge.className = "jump-page-indicator";
      jumpBadge.style.display = "none";
      document.body.appendChild(jumpBadge);
      const jumpStyle = document.createElement("style");
      jumpStyle.textContent = ".jump-page-indicator{position:fixed;right:16px;bottom:16px;z-index:1000;min-width:40px;padding:4px 12px;border-radius:18px;background:rgba(24,24,27,0.8);backdrop-filter:blur(12px);-webkit-backdrop-filter:blur(12px);border:1px solid rgba(255,255,255,0.12);color:#f4f4f5;font-size:14px;font-variant-numeric:tabular-nums;text-align:center;pointer-events:none;box-shadow:0 4px 16px rgba(0,0,0,0.35);}.jump-page-indicator.is-invalid{background:rgba(153,27,27,0.85);border-color:rgba(248,113,113,0.5);color:#fecaca;animation:jump-indicator-shake 0.4s ease;}@keyframes jump-indicator-shake{0%,100%{transform:translateX(0);}25%{transform:translateX(-4px);}50%{transform:translateX(4px);}75%{transform:translateX(-2px);}}";
      document.head.appendChild(jumpStyle);

      // ========= 缩略图总览层（o 键呼出，方向键/数字+回车/点选跳页） =========
      const OVERVIEW_CARD_W = 236;
      let overviewOpen = false;
      let overviewFocus = 1;
      let overviewBuilt = false;
      let overviewObserver = null;
      const overviewOverlay = document.createElement("div");
      overviewOverlay.className = "slidev-overview";
      overviewOverlay.style.display = "none";
      const overviewGrid = document.createElement("div");
      overviewGrid.className = "slidev-overview-grid";
      const overviewHint = document.createElement("div");
      overviewHint.className = "slidev-overview-hint";
      overviewHint.textContent = "← → ↑ ↓ 移动 · Enter 跳转 · 数字直达 · Esc / O 关闭";
      overviewOverlay.appendChild(overviewGrid);
      overviewOverlay.appendChild(overviewHint);
      document.body.appendChild(overviewOverlay);
      overviewOverlay.addEventListener("click", (e) => {
        if (e.target === overviewOverlay) closeOverview();
      });
      const overviewStyle = document.createElement("style");
      overviewStyle.textContent = ".slidev-overview{position:fixed;inset:0;z-index:900;overflow-y:auto;background:rgba(13,16,22,0.88);backdrop-filter:blur(18px);-webkit-backdrop-filter:blur(18px);padding:36px 44px 20px;box-sizing:border-box;}.slidev-overview-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(236px,1fr));gap:18px;max-width:1440px;margin:0 auto;}.slidev-overview-card{cursor:pointer;border-radius:10px;border:2px solid rgba(255,255,255,0.12);background:rgba(255,255,255,0.04);overflow:hidden;transition:border-color 0.15s ease,transform 0.15s ease,box-shadow 0.15s ease;}.slidev-overview-card:hover{border-color:rgba(255,255,255,0.38);transform:translateY(-2px);}.slidev-overview-card.is-active{border-color:var(--slide-accent,#3b82f6);box-shadow:0 0 0 1px var(--slide-accent,#3b82f6),0 8px 24px rgba(0,0,0,0.4);}.slidev-overview-canvas-box{position:relative;overflow:hidden;background:var(--slide-bg,#ffffff);}.slidev-overview-canvas{position:absolute;top:0;left:0;transform-origin:top left;pointer-events:none;}.slidev-overview-canvas *{scrollbar-width:none;}.slidev-overview-caption{display:flex;align-items:center;gap:8px;padding:6px 10px;font-size:12px;color:rgba(255,255,255,0.72);border-top:1px solid rgba(255,255,255,0.08);background:rgba(13,16,22,0.6);}.slidev-overview-page-no{flex-shrink:0;font-variant-numeric:tabular-nums;font-weight:600;color:#f4f4f5;background:rgba(255,255,255,0.16);border-radius:8px;padding:0 7px;line-height:18px;}.slidev-overview-page-no.is-current{background:var(--slide-accent,#10b981);color:#0b1210;}.slidev-overview-title{white-space:nowrap;overflow:hidden;text-overflow:ellipsis;user-select:none;}.slidev-overview-hint{text-align:center;margin:18px 0 8px;font-size:12px;color:rgba(255,255,255,0.45);user-select:none;}";
      document.head.appendChild(overviewStyle);

      const baseWidth = 980;
      const aspectStr = (data.config && data.config.aspectRatio) || "16/9";
      let ratioNum = 16 / 9;
      if (aspectStr === "4/3") ratioNum = 4 / 3;
      else if (aspectStr === "16/10") ratioNum = 16 / 10;
      else if (typeof aspectStr === "string" && aspectStr.includes("/")) {
        const parts = aspectStr.split("/").map(Number);
        if (parts[0] && parts[1]) ratioNum = parts[0] / parts[1];
      }
      const baseHeight = Math.ceil(baseWidth / ratioNum);
      const viewport = document.getElementById("viewport");

      function updateScale() {
        if (!viewport) return;
        const isFull = !!document.fullscreenElement;
        const padX = isFull ? 0 : 20;
        const padY = isFull ? 0 : 32;
        const availW = Math.max(100, window.innerWidth - padX);
        const availH = Math.max(100, window.innerHeight - padY);
        const scale = Math.min(availW / baseWidth, availH / baseHeight);
        viewport.style.width = baseWidth + "px";
        viewport.style.height = baseHeight + "px";
        viewport.style.transform = "translate(-50%, -50%) scale(" + scale + ")";
        viewport.style.setProperty("--slidev-slide-scale", scale);
        if (isFull) document.body.classList.add("is-fullscreen");
        else document.body.classList.remove("is-fullscreen");
      }

      window.addEventListener("resize", updateScale);
      document.addEventListener("fullscreenchange", updateScale);

      function parseMaskRatio(ratioStr) {
        if (!ratioStr || typeof ratioStr !== "string") {
          return { steps: 2, breakpoints: [50, 100] };
        }
        const clean = ratioStr.trim();
        if (!clean) return { steps: 2, breakpoints: [50, 100] };
        const parts = clean.split(":").map(p => parseFloat(p.trim())).filter(n => !isNaN(n) && n > 0);
        if (parts.length === 0) return { steps: 2, breakpoints: [50, 100] };
        if (parts.length === 1) {
          const val = Math.min(100, Math.max(1, parts[0]));
          if (val === 100) return { steps: 1, breakpoints: [100] };
          return { steps: 2, breakpoints: [Math.round(val * 100) / 100, 100] };
        }
        const isMonotonic = parts.every((val, idx) => idx === 0 || val > parts[idx - 1]);
        const maxVal = parts[parts.length - 1];
        if (isMonotonic && (maxVal === 100 || parts.some(p => p > 10))) {
          const bps = parts.map(p => Math.min(100, Math.round(p * 100) / 100));
          if (bps[bps.length - 1] < 100) bps.push(100);
          return { steps: bps.length, breakpoints: bps };
        }
        const totalWeight = parts.reduce((acc, cur) => acc + cur, 0);
        if (totalWeight <= 0) return { steps: 2, breakpoints: [50, 100] };
        let accumulated = 0;
        const bps = [];
        for (let i = 0; i < parts.length; i++) {
          accumulated += parts[i];
          if (i === parts.length - 1) {
            bps.push(100);
          } else {
            bps.push(Math.round((accumulated / totalWeight) * 10000) / 100);
          }
        }
        return { steps: bps.length, breakpoints: bps };
      }

      let currentMaskStep = 0;
      let currentMaskConfig = null;
      let maskLayerEl = null;
      let maskOverlayEl = null;
      let maskDividerEl = null;

      function updateMaskVisual() {
        if (!currentMaskConfig || !maskLayerEl) return;
        const p = (currentMaskStep <= 0)
          ? (currentMaskConfig.isInitialRevealed ? currentMaskConfig.breakpoints[0] : 0)
          : (currentMaskStep >= currentMaskConfig.totalSteps
              ? 100
              : currentMaskConfig.breakpoints[currentMaskConfig.isInitialRevealed ? currentMaskStep : (currentMaskStep - 1)]);

        const isDown = currentMaskConfig.direction === "down";
        if (p >= 100) {
          maskLayerEl.style.transform = isDown ? "translate3d(0, 100%, 0)" : "translate3d(100%, 0, 0)";
          maskLayerEl.style.opacity = "0";
          maskLayerEl.style.pointerEvents = "none";
          if (maskDividerEl) maskDividerEl.style.opacity = "0";
        } else {
          maskLayerEl.style.transform = isDown ? ("translate3d(0, " + p + "%, 0)") : ("translate3d(" + p + "%, 0, 0)");
          maskLayerEl.style.opacity = "1";
          maskLayerEl.style.pointerEvents = "none";
          if (maskDividerEl) {
            maskDividerEl.style.opacity = (p <= 0) ? "0" : "1";
          }
        }
      }

      function goNext() {
        if (currentMaskConfig && currentMaskStep < currentMaskConfig.totalSteps) {
          currentMaskStep++;
          updateMaskVisual();
          return;
        }
        renderSlide(currentIndex + 1);
      }

      function goPrev() {
        if (currentMaskConfig && currentMaskStep > (currentMaskConfig.isInitialRevealed ? 1 : 0)) {
          currentMaskStep--;
          updateMaskVisual();
          return;
        }
        renderSlide(currentIndex - 1);
      }

      function cleanCardListItemMarkdown(rawMarkdown) {
        if (!rawMarkdown) return "";
        let cleaned = rawMarkdown.replace(/^[ 	]*[-*+]s+|^[ 	]*d+.s+/, "");
        cleaned = cleaned.replace(/
[ 	]{2,4}/g, "
");
        return cleaned.trim();
      }

      function isHeadingBlock(b) {
        if (!b) return false;
        if (b.type === "h" || b.type === "NodeHeading") return true;
        if (b.subType && /^h[1-6]$/i.test(b.subType)) return true;
        const md = (b.rawMarkdown || b.content || "").trim();
        if (/^#{1,6}s+/.test(md)) return true;
        if (/^(?:[-*+]|d+.)s+#{1,6}s+/.test(md)) return true;
        return false;
      }

      function cleanColList(blocks) {
        const valid = (blocks || []).filter(b => Boolean((b.rawMarkdown || b.content || "").trim()));
        if (valid.length === 0) return valid;
        const first = valid[0];
        const md = (first.rawMarkdown || first.content || "").trim();
        const isList = /^(?:[-*+]|d+.)s+/.test(md) || first.type === "i" || first.type === "l";
        if (isList) {
          first.rawMarkdown = cleanCardListItemMarkdown(first.rawMarkdown || first.content || "");
          first.content = first.rawMarkdown;
        }
        return valid;
      }

      function renderBlock(block, extraClass) {
        const div = document.createElement("div");
        div.className = "slide-block" + (extraClass ? " " + extraClass : "");
        if (block && block.motion && block.motion.preset && block.motion.preset !== "none") {
          div.classList.add("slidev-motion-" + block.motion.preset.toLowerCase());
          if (typeof block.motion.duration === "number" && block.motion.duration > 0) {
            div.style.setProperty("--motion-duration", block.motion.duration + "ms");
          }
          if (typeof block.motion.delay === "number" && block.motion.delay > 0) {
            div.style.setProperty("--motion-delay", block.motion.delay + "ms");
          }
        }
        const md = block.rawMarkdown || block.content || "";

        if (md.includes('class="slidev-block-ref"') || md.includes('class="slidev-ref-tag"')) {
          div.innerHTML = md;
          return div;
        }

        const CARBON_MAP = {
          'carbon:arrow-right': '<svg viewBox="0 0 32 32" width="1.2em" height="1.2em" fill="currentColor" style="display:inline-block;vertical-align:middle;"><path d="m18 6l-1.43 1.393L24.15 15H4v2h20.15l-7.58 7.573L18 26l10-10z"/></svg>',
          'carbon:arrow-left': '<svg viewBox="0 0 32 32" width="1.2em" height="1.2em" fill="currentColor" style="display:inline-block;vertical-align:middle;"><path d="m14 26l1.43-1.393L7.85 17H28v-2H7.85l7.58-7.573L14 6L4 16z"/></svg>',
          'carbon:edit': '<svg viewBox="0 0 32 32" width="1.2em" height="1.2em" fill="currentColor" style="display:inline-block;vertical-align:middle;"><path d="M2 26h28v2H2zM25.4 9c.8-.8.8-2 0-2.8l-3.6-3.6c-.8-.8-2-.8-2.8 0l-15 15V24h6.4l15-15zM20.4 4L24 7.6l-2.4 2.4l-3.6-3.6L20.4 4zM6 22v-3.6l11-11l3.6 3.6l-11 11H6z"/></svg>',
          'carbon:logo-github': '<svg viewBox="0 0 32 32" width="1.2em" height="1.2em" fill="currentColor" style="display:inline-block;vertical-align:middle;"><path fill-rule="evenodd" d="M16 2a14 14 0 0 0-4.43 27.28c.7.13 1-.3 1-.67v-2.38c-3.89.84-4.71-1.88-4.71-1.88a3.7 3.7 0 0 0-1.56-2.05c-1.27-.86.1-.85.1-.85a2.94 2.94 0 0 1 2.14 1.44a3 3 0 0 0 4.08 1.16a2.93 2.93 0 0 1 .89-1.87c-3.1-.35-6.36-1.55-6.36-6.9a5.4 5.4 0 0 1 1.44-3.75a5 5 0 0 1 .14-3.71s1.17-.38 3.85 1.43a13.3 13.3 0 0 1 7 0c2.67-1.81 3.84-1.43 3.84-1.43a5 5 0 0 1 .14 3.71a5.4 5.4 0 0 1 1.44 3.75c0 5.37-3.27 6.54-6.38 6.89a3.35 3.35 0 0 1 1.26 2.61v3.87c0 .38.26.81 1 .67A14 14 0 0 0 16 2"/></svg>'
        };

        if (/@\\w+=['"]|v-\\w+|<button|<a\\b|<carbon:|^<div/i.test(md)) {
          if (md.includes('abs-br') || md.includes('abs-bl') || md.includes('abs-tr') || md.includes('abs-tl') || md.includes('absolute')) {
            div.classList.add("slide-block--absolute");
          }
          let renderedHtml = md;
          for (const [tag, svg] of Object.entries(CARBON_MAP)) {
            const regex = new RegExp("<" + tag + "\\\\s*\\\\/?>", "gi");
            renderedHtml = renderedHtml.replace(regex, svg);
            const regexDash = new RegExp("<" + tag.replace(":", "-") + "\\\\s*\\\\/?>", "gi");
            renderedHtml = renderedHtml.replace(regexDash, svg);
          }
          div.innerHTML = renderedHtml;

          // 挂载交互事件监听
          const nextBtns = div.querySelectorAll('[\\\\@click*="nav.next"], [\\\\@click*="next"]');
          nextBtns.forEach(btn => {
            btn.style.cursor = "pointer";
            btn.addEventListener("click", (e) => {
              e.stopPropagation();
              renderSlide(currentIndex + 1);
            });
          });

          const prevBtns = div.querySelectorAll('[\\\\@click*="nav.prev"], [\\\\@click*="prev"]');
          prevBtns.forEach(btn => {
            btn.style.cursor = "pointer";
            btn.addEventListener("click", (e) => {
              e.stopPropagation();
              renderSlide(currentIndex - 1);
            });
          });

          return div;
        }

        const hasHeadingTag = /(?:^|
)s*#{1,6}s+/.test(md);
        const hMatch = md.match(/^(#{1,6})\\s+(.*)$/);

        if (hMatch) {
          const level = hMatch[1].length;
          let th = hMatch[2].trim().replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
          div.innerHTML = "<h" + level + ">" + th + "</h" + level + ">";
        }
        else if (md.startsWith("\`\`\`")) {
          const customMaxHeight = block?.attributes?.["custom-slidev-max-height"] || block?.attrs?.["custom-slidev-max-height"] || block?.maxHeight || "";
          const heightStyle = customMaxHeight ? ' style="max-height:' + customMaxHeight + ';overflow-y:auto;"' : "";
          div.innerHTML = "<pre" + heightStyle + "><code>" + md.slice(3, -3) + "</code></pre>";
        }
        else if (md.startsWith("> ")) div.innerHTML = "<blockquote><p>" + md.slice(2) + "</p></blockquote>";
        else if ((/<video\b/i.test(md) || (block && (block.type === "video" || block.type === "NodeVideo"))) && !/^(s*)([-*+]|d+.)s+/m.test(md) && !hasHeadingTag && !md.includes("
")) {
          div.classList.add("slide-video-container", "slide-media-container", "slide-media-block");
          const isAutoplay = block && block.attributes && block.attributes["custom-slidev-autoplay"] === "true";
          const isLoop = block && block.attributes && block.attributes["custom-slidev-loop"] === "true";
          const isMuted = block && block.attributes && (block.attributes["custom-slidev-muted"] === "true" || isAutoplay);
          const hideControls = block && block.attributes && block.attributes["custom-slidev-controls"] === "false";
          let videoHtml = md;
          if (hideControls) videoHtml = videoHtml.replace(/\bcontrols(?:="[^"]*")?/gi, "").trim();
          else if (!videoHtml.includes("controls")) videoHtml = videoHtml.replace("<video", "<video controls");
          if (isAutoplay && !videoHtml.includes("autoplay")) videoHtml = videoHtml.replace("<video", "<video autoplay playsinline");
          if (isLoop && !videoHtml.includes("loop")) videoHtml = videoHtml.replace("<video", "<video loop");
          if (isMuted && !videoHtml.includes("muted")) videoHtml = videoHtml.replace("<video", "<video muted");
          videoHtml = videoHtml.replace("<video", '<video class="slide-video-player"');
          div.setAttribute("data-autoplay", isAutoplay ? "true" : "false");
          div.innerHTML = videoHtml;
        }
        else if (/^(s*)([-*+]|d+.)s+/m.test(md) || (md.includes("
") && /^(s*)([-*+]|d+.)s+/m.test(md.split("
").slice(1).join("
")))) {
          div.classList.add("pdf-list-item");
          const lines = md.split("
");
          let isOrdered = false;
          const items = [];
          const leadLines = [];
          for (let i = 0; i < lines.length; i++) {
            const line = lines[i];
            const tr = line.trim();
            if (!tr || /^{:.*?}$/.test(tr)) continue;
            const um = line.match(/^(s*)[-*+]s+(.*)$/);
            const om = line.match(/^(s*)d+.s+(.*)$/);
            if (um) {
              const indent = um[1].length;
              items.push({ type: "unordered", level: Math.floor(indent / 2), text: um[2], media: [] });
              continue;
            }
            if (om) {
              if (items.length === 0) isOrdered = true;
              const indent = om[1].length;
              items.push({ type: "ordered", level: Math.floor(indent / 2), text: om[2], media: [] });
              continue;
            }
            if (items.length > 0) {
              const im = tr.match(/^![(.*?)]((.*?))(?:{:?[^}]*})?$/);
              if (im) {
                const isGif = /.gif(?:?|$)/i.test(im[2]);
                items[items.length - 1].media.push('<div class="slide-list-media"><img alt="' + im[1] + '" src="' + im[2] + '" class="' + (isGif ? 'list-item-gif' : 'list-item-img') + '" /></div>');
                continue;
              }
              const hm = tr.match(/^<img\b[sS]*?/?>$/i);
              if (hm) {
                const cleanTr = tr.replace(/s+style="[^"]*"/gi, "");
                items[items.length - 1].media.push('<div class="slide-list-media">' + cleanTr + '</div>');
                continue;
              }
              if (/<video\b/i.test(tr)) {
                let vHtml = tr;
                if (!/</video>/i.test(vHtml)) {
                  while (i + 1 < lines.length && !/</video>/i.test(vHtml)) {
                    i++;
                    vHtml += " " + lines[i].trim();
                  }
                }
                const isAutoplay = block && block.attributes && block.attributes["custom-slidev-autoplay"] === "true";
                const isLoop = block && block.attributes && block.attributes["custom-slidev-loop"] === "true";
                const isMuted = block && block.attributes && (block.attributes["custom-slidev-muted"] === "true" || isAutoplay);
                const hideControls = block && block.attributes && block.attributes["custom-slidev-controls"] === "false";
                if (hideControls) vHtml = vHtml.replace(/\bcontrols(?:="[^"]*")?/gi, "").trim();
                else if (!vHtml.includes("controls")) vHtml = vHtml.replace("<video", "<video controls");
                if (isAutoplay && !vHtml.includes("autoplay")) vHtml = vHtml.replace("<video", "<video autoplay playsinline");
                if (isLoop && !vHtml.includes("loop")) vHtml = vHtml.replace("<video", "<video loop");
                if (isMuted && !vHtml.includes("muted")) vHtml = vHtml.replace("<video", "<video muted");
                vHtml = vHtml.replace("<video", '<video class="slide-video-player"');
                items[items.length - 1].media.push('<div class="slide-list-media slide-video-container slide-media-container" data-autoplay="' + (isAutoplay ? 'true' : 'false') + '">' + vHtml + '</div>');
                continue;
              }
              items[items.length - 1].text += "
" + tr;
            } else {
              leadLines.push(tr);
            }
          }

          let leadHtml = "";
          if (leadLines.length > 0) {
            const lParts = [];
            const firstL = leadLines[0];
            const fhm = firstL.match(/^(#{1,6})s+(.*)$/);
            if (fhm) {
              const lvl = fhm[1].length;
              let th = fhm[2].trim().replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
              lParts.push('<h' + lvl + ' class="slide-list-item-title">' + th + '</h' + lvl + '>');
            } else {
              let th = firstL.trim().replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
              lParts.push('<p class="slide-list-item-title">' + th + '</p>');
            }
            if (leadLines.length > 1) {
              const dLines = leadLines.slice(1);
              let pL = [];
              const flushLeadP = () => {
                if (pL.length > 0) {
                  let txt = pL.map(l => l.replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>")).join("<br/>");
                  lParts.push('<p class="slide-list-item-desc">' + txt + '</p>');
                  pL = [];
                }
              };
              for (const l of dLines) {
                const hm = l.match(/^(#{1,6})s+(.*)$/);
                if (hm) {
                  flushLeadP();
                  const lvl = hm[1].length;
                  let th = hm[2].trim().replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
                  lParts.push('<h' + lvl + ' class="slide-list-item-title">' + th + '</h' + lvl + '>');
                } else {
                  pL.push(l);
                }
              }
              flushLeadP();
            }
            leadHtml = lParts.join("
") + "
";
          }

          const tag = isOrdered ? "ol" : "ul";
          const listCls = isOrdered ? "pdf-list pdf-list--ordered" : "pdf-list pdf-list--unordered";
          const liHtml = items.map(it => {
            const med = it.media && it.media.length ? "
" + it.media.join("
") : "";
            const lines = (it.text || "").split("
").map(l => l.trim()).filter(Boolean);
            const hasHeading = lines.some(l => /^#{1,6}s+/.test(l));
            const lvl = it.level || 0;
            const nStyle = lvl > 0 ? ' style="margin-left:' + (lvl * 1.25).toFixed(2) + 'em;' + (it.type === 'unordered' ? 'list-style-type:' + (lvl % 2 === 1 ? 'circle' : 'square') + ' !important;' : '') + '"' : "";
            const nClass = lvl > 0 ? " slide-list-item--nested" : "";
            const clsAttr = nClass ? ' class="' + nClass.trim() + '"' : "";
            if (!hasHeading) {
              let h = lines.map(l => l.replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>")).join("<br/>");
              return '<li' + clsAttr + nStyle + '>' + h + med + '</li>';
            }
            const parts = [];
            let pLines = [];
            const flushP = () => {
              if (pLines.length > 0) {
                let ph = pLines.map(l => l.replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>")).join("<br/>");
                parts.push('<p class="slide-list-item-desc">' + ph + '</p>');
                pLines = [];
              }
            };
            for (const l of lines) {
              const hm = l.match(/^(#{1,6})s+(.*)$/);
              if (hm) {
                flushP();
                const hl = hm[1].length;
                let th = hm[2].trim().replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
                parts.push('<h' + hl + ' class="slide-list-item-title">' + th + '</h' + hl + '>');
              } else {
                pLines.push(l);
              }
            }
            flushP();
            return '<li' + clsAttr + nStyle + '>' + parts.join("
") + med + '</li>';
          }).join("
");
          div.innerHTML = leadHtml + "<" + tag + " class="" + listCls + "">
" + liHtml + "
</" + tag + ">";
        }
        else {
          // 复合块（包含换行、标题或媒体）高保真解析
          const lines = md.split(/\r?
/);
          const subBlocks = [];
          let current = [];
          for (let i = 0; i < lines.length; i++) {
            const line = lines[i];
            const trimmed = line.trim();
            if (/^#{1,6}s+/.test(trimmed)) {
              if (current.length > 0) { subBlocks.push(current.join("
")); current = []; }
              subBlocks.push(trimmed);
              continue;
            }
            if (!trimmed) {
              if (current.length > 0) { subBlocks.push(current.join("
")); current = []; }
              continue;
            }
            if (/^![.*?](.*?)$/.test(trimmed)) {
              if (current.length > 0) { subBlocks.push(current.join("
")); current = []; }
              subBlocks.push(trimmed);
              continue;
            }
            if (/<video\b/i.test(trimmed)) {
              if (current.length > 0) { subBlocks.push(current.join("
")); current = []; }
              let vRaw = trimmed;
              if (!/</video>/i.test(vRaw)) {
                while (i + 1 < lines.length && !/</video>/i.test(vRaw)) {
                  i++;
                  vRaw += "
" + lines[i];
                }
              }
              subBlocks.push(vRaw);
              continue;
            }
            current.push(line);
          }
          if (current.length > 0) subBlocks.push(current.join("
"));

          if (subBlocks.length > 1 || (subBlocks.length === 1 && /^#{1,6}s+/.test(subBlocks[0].trim()))) {
            let isFirstParagraph = true;
            const htmlParts = subBlocks.map(sub => {
              const t = sub.trim();
              if (!t) return "";
              const hm = t.match(/^(#{1,6})s+(.*)$/);
              if (hm) {
                isFirstParagraph = false;
                const hl = hm[1].length;
                let th = hm[2].trim().replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
                return '<h' + hl + ' class="slide-list-item-title">' + th + '</h' + hl + '>';
              }
              const im = t.match(/^![(.*?)]((.*?))$/);
              if (im) {
                return '<div class="slide-media-block slide-media-container slide-list-media"><img alt="' + im[1] + '" src="' + im[2] + '" class="slide-media-img" /></div>';
              }
              if (/<video\b/i.test(t)) {
                return '<div class="slide-media-block slide-video-container slide-media-container">' + t + '</div>';
              }
              if (isFirstParagraph) {
                isFirstParagraph = false;
                const subLines = t.split(/\r?
/).map(l => l.trim()).filter(Boolean);
                if (subLines.length === 1) {
                  let ph = subLines[0].replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
                  return '<p class="slide-list-item-title">' + ph + '</p>';
                }
                let titleHtml = subLines[0].replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
                let descHtml = subLines.slice(1).map(l => l.replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>")).join("<br/>");
                return '<p class="slide-list-item-title">' + titleHtml + '</p>
<p class="slide-list-item-desc">' + descHtml + '</p>';
              }
              let ph = t.replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
              return '<p class="slide-list-item-desc">' + ph + '</p>';
            }).filter(Boolean);
            div.innerHTML = htmlParts.join("
");
          } else {
            const imgMatch = md.match(/!\\[(.*?)\\]\\((.*?)\\)/);
            if (imgMatch) {
              div.classList.add("slide-media-container", "slide-media-block", "slide-block--image");
              div.innerHTML = '<img alt="' + imgMatch[1] + '" src="' + imgMatch[2] + '" class="slide-media-img" />';
            } else {
              let html = md.replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
              const pCls = (block && block.isColFirst) ? ' class="slide-list-item-title"' : '';
              div.innerHTML = "<p" + pCls + ">" + html + "</p>";
            }
          }
        }
        return div;
      }

      function renderSlide(idx) {
        if (slides.length === 0) return;
        currentIndex = Math.max(0, Math.min(idx, slides.length - 1));
        const slide = slides[currentIndex];
        pageNum.textContent = (currentIndex + 1) + " / " + slides.length;

        const pageSp = slide.frontmatter?.spacing;
        const currentSpacing = (pageSp && pageSp !== "inherit") ? pageSp : (data.config?.spacing || "normal");
        container.className = "slide-content layout-" + (slide.frontmatter?.layout || "default") + " spacing-" + currentSpacing;
        if (viewport) viewport.setAttribute("data-spacing", currentSpacing);
        container.innerHTML = "";

        const z = typeof slide.frontmatter?.zoom === "number" && slide.frontmatter.zoom > 0 ? slide.frontmatter.zoom : 1;
        if (z !== 1) {
          container.style.width = (100 / z) + "%";
          container.style.height = (100 / z) + "%";
          container.style.transformOrigin = "top left";
          container.style.transform = "scale(" + z + ")";
        } else {
          container.style.width = "100%";
          container.style.height = "100%";
          container.style.transform = "none";
        maskOverlayEl = null;
        maskDividerEl = null;
        const maskDir = slide.frontmatter?.mask;
        if (maskDir === "down" || maskDir === "right") {
          const ratioInfo = parseMaskRatio(slide.frontmatter.maskRatio);
          const isInitRev = slide.frontmatter.maskInitial === "revealed";
          currentMaskConfig = {
            direction: maskDir,
            totalSteps: isInitRev ? Math.max(0, ratioInfo.steps - 1) : ratioInfo.steps,
            rawSteps: ratioInfo.steps,
            breakpoints: ratioInfo.breakpoints,
            isInitialRevealed: isInitRev,
            style: slide.frontmatter.maskStyle || "solid",
          };
          currentMaskStep = 0;
        } else {
          currentMaskConfig = null;
          currentMaskStep = 0;
        }

        function createMaskElements() {
          if (!currentMaskConfig) return null;
          const layer = document.createElement("div");
          layer.className = "slidev-mask-layer slidev-mask-layer--" + currentMaskConfig.style + " slidev-mask-layer--" + currentMaskConfig.direction;
          const overlay = document.createElement("div");
          overlay.className = "slidev-mask-overlay";
          const divider = document.createElement("div");
          divider.className = "slidev-mask-divider-line";
          divider.style.opacity = "0";
          layer.appendChild(overlay);
          layer.appendChild(divider);
          maskLayerEl = layer;
          maskOverlayEl = overlay;
          maskDividerEl = divider;
          return { layer, overlay, divider };
        }

        if (slide.frontmatter?.layout === "two-cols") {
          const bodyWrap = document.createElement("div");
          bodyWrap.className = "slidev-mask-body-container" + (currentMaskConfig ? " slidev-mask-body-container--has-mask" : "");
          bodyWrap.style.display = "flex";
          bodyWrap.style.flexDirection = "row";
          bodyWrap.style.gap = "2rem";
          bodyWrap.style.width = "100%";
          bodyWrap.style.height = "100%";

          const leftCol = document.createElement("div");
          leftCol.className = "two-cols-left";
          const rightCol = document.createElement("div");
          rightCol.className = "two-cols-right";

          const blocks = (slide.blocks || []).filter(b => b.slot !== "slot-divider-right");
          let leftList = [];
          let rightList = [];
          for (const block of blocks) {
            if (block.slot === "right") rightList.push(block);
            else leftList.push(block);
          }
          leftList = cleanColList(leftList);
          rightList = cleanColList(rightList);
          const isCover = slide.frontmatter?.layout === "cover";
          const leftFirstH = !isCover ? leftList.find(isHeadingBlock) : null;
          const rightFirstH = !isCover ? rightList.find(isHeadingBlock) : null;
          for (const b of leftList) leftCol.appendChild(renderBlock(b, b === leftFirstH ? "slidev-col-first-heading-block" : ""));
          for (const b of rightList) rightCol.appendChild(renderBlock(b, b === rightFirstH ? "slidev-col-first-heading-block" : ""));
          bodyWrap.appendChild(leftCol);
          bodyWrap.appendChild(rightCol);

          const maskEls = createMaskElements();
          if (maskEls) {
            bodyWrap.appendChild(maskEls.layer);
          }
          container.appendChild(bodyWrap);
        } else if (slide.frontmatter?.layout === "cols-header" || slide.frontmatter?.layout === "two-cols-header" || slide.frontmatter?.layout === "three-cols-header" || slide.frontmatter?.layout === "clover") {
          const isCover = slide.frontmatter?.layout === "cover";
          const isClover = slide.frontmatter?.layout === "clover";
          const blocks = (slide.blocks || []).filter(b => b.slot !== "slot-divider-right");
          let headerBlocks = blocks.filter(b => b.slot === "header");
          if (headerBlocks.length === 0 && blocks.length > 0) {
            const candidate = blocks.find(b => b.type === "h" && (!b.slot || b.slot === "default"));
            if (candidate) headerBlocks = [candidate];
          }
          const rem = blocks.filter(b => !headerBlocks.includes(b));

          let targetCols = isClover ? 4 : 2;
          if (isClover) {
            targetCols = 4;
          } else if (slide.frontmatter?.layout === "three-cols-header") {
            targetCols = 3;
          } else if (slide.frontmatter?.layout === "two-cols-header") {
            targetCols = 2;
          } else {
            let maxCol = 0;
            for (const b of rem) {
              const m = (b.slot || "").match(/^col-(d+)$/i);
              if (m) maxCol = Math.max(maxCol, parseInt(m[1], 10));
            }
            if (maxCol >= 2) {
              targetCols = maxCol;
            } else if (slide.frontmatter?.layoutRatio) {
              const r = slide.frontmatter.layoutRatio.trim();
              if (r.includes(":")) {
                const parts = r.split(":").map(p => parseFloat(p.trim())).filter(n => !isNaN(n) && n > 0);
                if (parts.length >= 2) targetCols = parts.length;
              }
            }
          }

          const hasColSlots = rem.some(b => b.slot && /^col-d+$/i.test(b.slot));
          const isSuperBlockCols = isClover || hasColSlots;

          const containerDiv = document.createElement("div");
          containerDiv.className = (isClover ? "layout-clover-container" : ("layout-cols-header-container " + (targetCols === 2 ? "layout-two-cols-header-container" : (targetCols === 3 ? "layout-three-cols-header-container" : "")))) + (isSuperBlockCols ? " has-superblock-cols" : "");
          const headerDiv = document.createElement("div");
          headerDiv.className = "layout-header-section";
          const gridDiv = document.createElement("div");
          gridDiv.className = (isClover ? "layout-clover-grid pdf-clover-wrapper" : ("layout-cols-wrapper layout-cols-grid " + (targetCols === 2 ? "pdf-two-cols-wrapper layout-two-cols-grid" : (targetCols === 3 ? "pdf-three-cols-wrapper layout-three-cols-grid" : "")))) + (isSuperBlockCols ? " has-superblock-cols" : "") + (currentMaskConfig ? " slidev-mask-body-container slidev-mask-body-container--has-mask" : "");

          const gridCols = isClover ? "repeat(2, minmax(0, 1fr))" : parseRatioToGridCols(slide.frontmatter?.layoutRatio, targetCols);
          if (gridCols) gridDiv.style.gridTemplateColumns = gridCols;
          if (isClover) gridDiv.style.gridTemplateRows = "repeat(2, minmax(0, 1fr))";

          let colsList = [];
          for (let i = 0; i < targetCols; i++) colsList.push([]);
          const hasExplicitCols = rem.some(b => b.slot && (b.slot.startsWith("col-") || b.slot === "left" || b.slot === "right" || b.slot === "center"));
          if (hasExplicitCols) {
            for (const b of rem) {
              let idx = 0;
              if (b.slot === "left" || b.slot === "col-1") idx = 0;
              else if (b.slot === "center" || b.slot === "col-2") idx = 1;
              else if (b.slot === "right") idx = targetCols === 2 ? 1 : targetCols - 1;
              else {
                const m = (b.slot || "").match(/^col-(d+)$/i);
                if (m) idx = Math.min(targetCols - 1, Math.max(0, parseInt(m[1], 10) - 1));
              }
              colsList[idx].push(b);
            }
          } else {
            let cur = 0;
            for (let i = 0; i < targetCols; i++) {
              const remainingCols = targetCols - i;
              const remainingItems = rem.length - cur;
              const take = Math.ceil(remainingItems / remainingCols);
              colsList[i] = rem.slice(cur, cur + take);
              cur += take;
            }
          }

          const headerFirstH = !isCover ? headerBlocks.find(isHeadingBlock) : null;
          for (const b of headerBlocks) headerDiv.appendChild(renderBlock(b, b === headerFirstH ? "slidev-page-first-heading-block" : ""));
          containerDiv.appendChild(headerDiv);

          colsList.forEach((colBlocks, idx) => {
            const colDiv = document.createElement("div");
            colDiv.className = "pdf-col pdf-col--" + (idx + 1) + " col-" + (idx + 1) + (targetCols === 2 && idx === 0 ? " pdf-col--left" : "") + (targetCols === 2 && idx === 1 ? " pdf-col--right" : "");
            const cleaned = cleanColList(colBlocks);
            const colFirstH = !isCover ? (cleaned.find(isHeadingBlock) || cleaned[0]) : null;
            for (const b of cleaned) colDiv.appendChild(renderBlock(b, b === colFirstH ? "slidev-col-first-heading-block" : ""));
            gridDiv.appendChild(colDiv);
          });

          const maskEls = createMaskElements();
          if (maskEls) {
            gridDiv.appendChild(maskEls.layer);
          }

          containerDiv.appendChild(gridDiv);
          container.appendChild(containerDiv);
        } else if (slide.frontmatter?.layout === "image-right" || slide.frontmatter?.layout === "image-left") {
          const isImageRight = slide.frontmatter?.layout === "image-right";
          const isCover = slide.frontmatter?.layout === "cover";
          const allBlocks = slide.blocks || [];
          const pageFirstH = !isCover ? allBlocks.find(isHeadingBlock) : null;

          if (pageFirstH) {
            container.appendChild(renderBlock(pageFirstH, "slidev-page-first-heading-block"));
          }

          const bodyWrap = document.createElement("div");
          bodyWrap.className = "slidev-mask-body-container" + (currentMaskConfig ? " slidev-mask-body-container--has-mask" : "");
          bodyWrap.style.display = "flex";
          bodyWrap.style.flexDirection = isImageRight ? "row" : "row-reverse";
          bodyWrap.style.gap = "2rem";
          bodyWrap.style.width = "100%";
          bodyWrap.style.height = "100%";
          bodyWrap.style.minHeight = "0";
          bodyWrap.style.flex = "1";

          const contentCol = document.createElement("div");
          contentCol.className = isImageRight ? "image-right-content" : "image-left-content";

          for (const block of allBlocks) {
            if (block === pageFirstH) continue;
            contentCol.appendChild(renderBlock(block, ""));
          }

          const imgCol = document.createElement("div");
          imgCol.className = isImageRight ? "image-right-img-container" : "image-left-img-container";
          const img = document.createElement("img");
          img.className = isImageRight ? "image-right-img" : "image-left-img";
          img.src = slide.frontmatter?.image || slide.frontmatter?.background || "";
          img.alt = "Slide cover";
          img.onerror = function() {
            this.src = "https://fastly.jsdelivr.net/gh/slidevjs/slidev-covers@main/static/2HmfbSpvcos.webp";
          };
          imgCol.appendChild(img);

          bodyWrap.appendChild(contentCol);
          bodyWrap.appendChild(imgCol);

          const maskEls = createMaskElements();
          if (maskEls) {
            bodyWrap.appendChild(maskEls.layer);
          }
          container.appendChild(bodyWrap);
        } else {
          const isCover = slide.frontmatter?.layout === "cover";
          const validBlocks = (slide.blocks || []).filter(b => b.slot !== "slot-divider-right");
          const pageFirstH = !isCover ? validBlocks.find(isHeadingBlock) : null;

          if (pageFirstH) {
            container.appendChild(renderBlock(pageFirstH, "slidev-page-first-heading-block"));
          }

          const bodyWrap = document.createElement("div");
          bodyWrap.className = "slidev-mask-body-container" + (currentMaskConfig ? " slidev-mask-body-container--has-mask" : "");

          for (const block of validBlocks) {
            if (block === pageFirstH) continue;
            bodyWrap.appendChild(renderBlock(block, ""));
          }

          const maskEls = createMaskElements();
          if (maskEls) {
            bodyWrap.appendChild(maskEls.layer);
          }
          container.appendChild(bodyWrap);
        }

        updateMaskVisual();
        if (currentMaskConfig && maskLayerEl) {
          requestAnimationFrame(() => {
            if (maskLayerEl) void maskLayerEl.offsetHeight;
          });
        }

        function syncAutoplayVideos() {
          const doSync = () => {
            const videos = container.querySelectorAll("video");
            videos.forEach((v) => {
              const box = v.closest("[data-autoplay]");
              const isAuto = v.hasAttribute("autoplay") || v.autoplay || (box && box.getAttribute("data-autoplay") === "true");
              if (isAuto) {
                v.muted = true;
                v.defaultMuted = true;
                v.setAttribute("muted", "");
                v.playsInline = true;
                v.setAttribute("playsinline", "");
                const playFn = () => {
                  if (!v.paused) return;
                  v.muted = true;
                  v.defaultMuted = true;
                  const p = v.play();
                  if (p !== undefined) {
                    p.catch(() => {
                      v.muted = true;
                      v.defaultMuted = true;
                      setTimeout(() => { if (v.paused) v.play().catch(() => {}); }, 150);
                    });
                  }
                };
                playFn();
                if (!v.__autoplayBound) {
                  v.__autoplayBound = true;
                  v.addEventListener("loadedmetadata", playFn);
                  v.addEventListener("canplay", playFn);
                }
              }
            });
          };
          setTimeout(doSync, 60);
          setTimeout(doSync, 200);
        }
        syncAutoplayVideos();
      }

      // Lightbox 控制逻辑
      const lightbox = document.getElementById("slidev-lightbox");
      const lightboxContent = document.getElementById("lightbox-content");
      const lightboxClose = document.getElementById("lightbox-close");
      let isLightboxOpen = false;

      function openLightbox(type, src, alt) {
        if (!lightbox || !lightboxContent) return;
        lightboxContent.innerHTML = "";
        if (type === "video") {
          const v = document.createElement("video");
          v.className = "slidev-lightbox-video";
          v.src = src;
          v.controls = true;
          v.autoplay = true;
          v.playsInline = true;
          lightboxContent.appendChild(v);
        } else {
          const img = document.createElement("img");
          img.className = "slidev-lightbox-img";
          img.src = src;
          img.alt = alt || "";
          lightboxContent.appendChild(img);
        }
        lightbox.classList.add("active");
        isLightboxOpen = true;
      }

      function closeLightbox() {
        if (!lightbox) return;
        const v = lightbox.querySelector("video");
        if (v) v.pause();
        lightbox.classList.remove("active");
        if (lightboxContent) lightboxContent.innerHTML = "";
        isLightboxOpen = false;
      }

      if (lightboxClose) {
        lightboxClose.addEventListener("click", (e) => {
          e.stopPropagation();
          closeLightbox();
        });
      }
      if (lightbox) {
        lightbox.addEventListener("click", (e) => {
          if (e.target === lightbox || e.target === lightboxClose) {
            e.stopPropagation();
            closeLightbox();
          }
        });
      }

      btnPrev.addEventListener("click", () => goPrev());
      btnNext.addEventListener("click", () => goNext());
      btnFullscreen.addEventListener("click", () => {
        if (!document.fullscreenElement) {
          document.documentElement.requestFullscreen().then(() => updateScale()).catch(() => {});
        } else {
          document.exitFullscreen().then(() => updateScale()).catch(() => {});
        }
      });

      // 「数字+回车」跳页输入状态：数字缓冲实时回显，Esc/超时清空，越界红色抖动提示
      let jumpDisplay = "";
      let jumpInvalid = false;
      let jumpIdleTimer = null;
      let jumpFlashTimer = null;

      function hideJumpIndicator() {
        jumpDisplay = "";
        jumpInvalid = false;
        jumpBadge.style.display = "none";
        jumpBadge.classList.remove("is-invalid");
        if (jumpIdleTimer) { clearTimeout(jumpIdleTimer); jumpIdleTimer = null; }
        if (jumpFlashTimer) { clearTimeout(jumpFlashTimer); jumpFlashTimer = null; }
      }

      function renderJumpBadge() {
        jumpBadge.textContent = jumpDisplay;
        jumpBadge.style.display = jumpDisplay ? "block" : "none";
        jumpBadge.classList.toggle("is-invalid", jumpInvalid);
      }

      function armJumpIdleTimer() {
        if (jumpIdleTimer) clearTimeout(jumpIdleTimer);
        jumpIdleTimer = setTimeout(hideJumpIndicator, 1500);
      }

      function flashJumpInvalid() {
        if (jumpIdleTimer) { clearTimeout(jumpIdleTimer); jumpIdleTimer = null; }
        jumpInvalid = true;
        renderJumpBadge();
        if (jumpFlashTimer) clearTimeout(jumpFlashTimer);
        jumpFlashTimer = setTimeout(hideJumpIndicator, 500);
      }

      function isEditableKeyTarget(t) {
        if (!t || !t.tagName) return false;
        return t.tagName === "INPUT" || t.tagName === "TEXTAREA" || t.tagName === "SELECT" || t.isContentEditable === true;
      }

      function getSlideOverviewTitle(slide) {
        const fm = slide?.frontmatter || {};
        if (fm.title) return String(fm.title);
        const blocks = slide?.blocks || [];
        for (const b of blocks) {
          if (b.type === "h" || /^h[1-6]$/i.test(b.subType || "")) {
            const md = (b.rawMarkdown || b.content || "").trim();
            return md.replace(/^#{1,6}s+/, "").replace(/[*_\`]/g, "").slice(0, 40);
          }
        }
        return "";
      }

      // 把任意一页渲染为静态缩略图：复用 renderBlock 与主渲染同名版式类，导出样式自动生效
      function buildOverviewThumbInto(canvas, slide) {
        const fm = slide.frontmatter || {};
        const layout = fm.layout || "default";
        const blocks = (slide.blocks || []).filter((b) => b.slot !== "slot-divider-right");
        let headerBlocks = blocks.filter((b) => b.slot === "header");
        if (headerBlocks.length === 0 && blocks.length > 0) {
          const candidate = blocks.find((b) => b.type === "h" && (!b.slot || b.slot === "default"));
          if (candidate) headerBlocks = [candidate];
        }
        const rem = blocks.filter((b) => !headerBlocks.includes(b));
        let bodyEl = null;

        if (layout === "cols-header" || layout === "two-cols-header" || layout === "three-cols-header" || layout === "clover") {
          const isClover = layout === "clover";
          let targetCols = isClover ? 4 : 2;
          if (layout === "three-cols-header") targetCols = 3;
          else if (layout === "two-cols-header") targetCols = 2;
          else if (!isClover) {
            let maxCol = 0;
            for (const b of rem) {
              const m = (b.slot || "").match(/^col-(d+)$/i);
              if (m) maxCol = Math.max(maxCol, parseInt(m[1], 10));
            }
            if (maxCol >= 2) targetCols = maxCol;
            else if (fm.layoutRatio) {
              const r = String(fm.layoutRatio).trim();
              if (r.includes(":")) {
                const parts = r.split(":").map((p) => parseFloat(p.trim())).filter((n) => !isNaN(n) && n > 0);
                if (parts.length >= 2) targetCols = parts.length;
              }
            }
          }
          const hasColSlots = rem.some((b) => b.slot && /^col-d+$/i.test(b.slot));
          const containerDiv = document.createElement("div");
          containerDiv.className = (isClover ? "layout-clover-container" : ("layout-cols-header-container " + (targetCols === 2 ? "layout-two-cols-header-container" : (targetCols === 3 ? "layout-three-cols-header-container" : "")))) + (hasColSlots || isClover ? " has-superblock-cols" : "");
          const headerDiv = document.createElement("div");
          headerDiv.className = "layout-header-section";
          for (const b of headerBlocks) headerDiv.appendChild(renderBlock(b, ""));
          containerDiv.appendChild(headerDiv);
          const gridDiv = document.createElement("div");
          gridDiv.className = (isClover ? "layout-clover-grid pdf-clover-wrapper" : ("layout-cols-wrapper layout-cols-grid " + (targetCols === 2 ? "pdf-two-cols-wrapper layout-two-cols-grid" : (targetCols === 3 ? "pdf-three-cols-wrapper layout-three-cols-grid" : "")))) + (hasColSlots || isClover ? " has-superblock-cols" : "");
          const gridCols = isClover ? "repeat(2, minmax(0, 1fr))" : parseRatioToGridCols(fm.layoutRatio, targetCols);
          if (gridCols) gridDiv.style.gridTemplateColumns = gridCols;
          if (isClover) gridDiv.style.gridTemplateRows = "repeat(2, minmax(0, 1fr))";
          let colsList = [];
          for (let i = 0; i < targetCols; i++) colsList.push([]);
          const hasExplicitCols = rem.some((b) => b.slot && (b.slot.startsWith("col-") || b.slot === "left" || b.slot === "right" || b.slot === "center"));
          if (hasExplicitCols) {
            for (const b of rem) {
              let idx = 0;
              if (b.slot === "left" || b.slot === "col-1") idx = 0;
              else if (b.slot === "center" || b.slot === "col-2") idx = 1;
              else if (b.slot === "right") idx = targetCols === 2 ? 1 : targetCols - 1;
              else {
                const m = (b.slot || "").match(/^col-(d+)$/i);
                if (m) idx = Math.min(targetCols - 1, Math.max(0, parseInt(m[1], 10) - 1));
              }
              colsList[idx].push(b);
            }
          } else {
            let cur = 0;
            for (let i = 0; i < targetCols; i++) {
              const remainingCols = targetCols - i;
              const remainingItems = rem.length - cur;
              const take = Math.ceil(remainingItems / remainingCols);
              colsList[i] = rem.slice(cur, cur + take);
              cur += take;
            }
          }
          colsList.forEach((colBlocks, idx) => {
            const colDiv = document.createElement("div");
            colDiv.className = "pdf-col pdf-col--" + (idx + 1) + " col-" + (idx + 1) + (targetCols === 2 && idx === 0 ? " pdf-col--left" : "") + (targetCols === 2 && idx === 1 ? " pdf-col--right" : "");
            const cleaned = cleanColList(colBlocks);
            for (const b of cleaned) colDiv.appendChild(renderBlock(b, ""));
            gridDiv.appendChild(colDiv);
          });
          containerDiv.appendChild(gridDiv);
          bodyEl = containerDiv;
        } else if (layout === "two-cols") {
          bodyEl = document.createElement("div");
          bodyEl.style.display = "flex";
          bodyEl.style.flexDirection = "row";
          bodyEl.style.gap = "2rem";
          bodyEl.style.width = "100%";
          bodyEl.style.flex = "1";
          bodyEl.style.minHeight = "0";
          let leftList = [];
          let rightList = [];
          for (const b of blocks) {
            if (b.slot === "right") rightList.push(b);
            else leftList.push(b);
          }
          const leftCol = document.createElement("div");
          leftCol.className = "two-cols-left";
          const rightCol = document.createElement("div");
          rightCol.className = "two-cols-right";
          for (const b of cleanColList(leftList)) leftCol.appendChild(renderBlock(b, ""));
          for (const b of cleanColList(rightList)) rightCol.appendChild(renderBlock(b, ""));
          bodyEl.appendChild(leftCol);
          bodyEl.appendChild(rightCol);
        } else if (layout === "image-right" || layout === "image-left") {
          const isImageRight = layout === "image-right";
          bodyEl = document.createElement("div");
          bodyEl.style.display = "flex";
          bodyEl.style.flexDirection = isImageRight ? "row" : "row-reverse";
          bodyEl.style.gap = "2rem";
          bodyEl.style.width = "100%";
          bodyEl.style.flex = "1";
          bodyEl.style.minHeight = "0";
          const contentCol = document.createElement("div");
          contentCol.className = isImageRight ? "image-right-content" : "image-left-content";
          for (const b of blocks) contentCol.appendChild(renderBlock(b, ""));
          const imgCol = document.createElement("div");
          imgCol.className = isImageRight ? "image-right-img-container" : "image-left-img-container";
          const url = fm.image || fm.background || "";
          if (url) {
            const img = document.createElement("img");
            img.className = isImageRight ? "image-right-img" : "image-left-img";
            img.src = url;
            img.alt = "Slide cover";
            imgCol.appendChild(img);
          }
          bodyEl.appendChild(contentCol);
          bodyEl.appendChild(imgCol);
        } else {
          bodyEl = document.createElement("div");
          for (const b of blocks) bodyEl.appendChild(renderBlock(b, ""));
        }
        canvas.appendChild(bodyEl);
      }

      function buildOverviewCards() {
        if (overviewBuilt) return;
        overviewBuilt = true;
        const scale = OVERVIEW_CARD_W / baseWidth;
        const canvasH = Math.round(baseHeight * scale);
        slides.forEach((slide, idx) => {
          const card = document.createElement("div");
          card.className = "slidev-overview-card";
          card.dataset.idx = String(idx);
          const box = document.createElement("div");
          box.className = "slidev-overview-canvas-box";
          box.style.height = canvasH + "px";
          const fm = slide.frontmatter || {};
          const spacing = (fm.spacing && fm.spacing !== "inherit") ? fm.spacing : ((data.config && data.config.spacing) || "normal");
          const canvas = document.createElement("div");
          canvas.className = "slidev-overview-canvas slide-content layout-" + (fm.layout || "default") + " spacing-" + spacing;
          canvas.style.width = baseWidth + "px";
          canvas.style.height = baseHeight + "px";
          canvas.style.transform = "scale(" + scale + ")";
          const bg = fm.background;
          if (bg) {
            if (/^(http|/|data:|assets/)/.test(bg)) {
              canvas.style.backgroundImage = 'url("' + bg + '")';
              canvas.style.backgroundSize = "cover";
              canvas.style.backgroundPosition = "center";
            } else {
              canvas.style.background = bg;
            }
          }
          box.appendChild(canvas);
          const caption = document.createElement("div");
          caption.className = "slidev-overview-caption";
          const pageNo = document.createElement("span");
          pageNo.className = "slidev-overview-page-no";
          pageNo.textContent = String(idx + 1);
          caption.appendChild(pageNo);
          const title = getSlideOverviewTitle(slide);
          if (title) {
            const titleEl = document.createElement("span");
            titleEl.className = "slidev-overview-title";
            titleEl.textContent = title;
            caption.appendChild(titleEl);
          }
          card.appendChild(box);
          card.appendChild(caption);
          card.addEventListener("click", (e) => {
            e.stopPropagation();
            goFromOverview(idx + 1);
          });
          overviewGrid.appendChild(card);
        });
        updateOverviewCurrentMark();
      }

      function renderOverviewThumb(card) {
        if (!card || card.dataset.rendered === "1") return;
        const idx = Number(card.dataset.idx);
        const slide = slides[idx];
        const canvas = card.querySelector(".slidev-overview-canvas");
        if (slide && canvas) buildOverviewThumbInto(canvas, slide);
        card.dataset.rendered = "1";
      }

      function ensureOverviewObserver() {
        if (overviewObserver || typeof window.IntersectionObserver !== "function") return;
        overviewObserver = new IntersectionObserver((entries) => {
          for (const en of entries) {
            if (!en.isIntersecting) continue;
            overviewObserver.unobserve(en.target);
            renderOverviewThumb(en.target);
          }
        }, { rootMargin: "240px" });
      }

      function observeOverviewCards() {
        if (!overviewObserver) return;
        const cards = overviewGrid.children;
        for (let i = 0; i < cards.length; i++) {
          if (cards[i].dataset.rendered !== "1") overviewObserver.observe(cards[i]);
        }
      }

      function updateOverviewCurrentMark() {
        const cards = overviewGrid.children;
        for (let i = 0; i < cards.length; i++) {
          const pageNo = cards[i].querySelector(".slidev-overview-page-no");
          if (pageNo) pageNo.classList.toggle("is-current", i === currentIndex);
        }
      }

      function setOverviewFocus(page) {
        const total = slides.length || 1;
        overviewFocus = Math.min(Math.max(1, page), total);
        const cards = overviewGrid.children;
        for (let i = 0; i < cards.length; i++) {
          cards[i].classList.toggle("is-active", i + 1 === overviewFocus);
        }
        const el = cards[overviewFocus - 1];
        if (el && el.scrollIntoView) el.scrollIntoView({ block: "nearest", behavior: "smooth" });
      }

      function getOverviewCols() {
        if (!overviewGrid || !overviewGrid.clientWidth) return 1;
        return Math.max(1, Math.round(overviewGrid.clientWidth / (OVERVIEW_CARD_W + 18)));
      }

      function goFromOverview(page) {
        const p = parseInt(page, 10);
        if (isNaN(p) || p < 1 || p > slides.length) return;
        closeOverview();
        renderSlide(p - 1);
        updateOverviewCurrentMark();
      }

      function openOverview() {
        if (slides.length === 0) return;
        buildOverviewCards();
        overviewOpen = true;
        overviewOverlay.style.display = "block";
        ensureOverviewObserver();
        if (overviewObserver) {
          observeOverviewCards();
        } else {
          const cards = overviewGrid.children;
          for (let i = 0; i < cards.length; i++) renderOverviewThumb(cards[i]);
        }
        setOverviewFocus(currentIndex + 1);
      }

      function closeOverview() {
        overviewOpen = false;
        overviewOverlay.style.display = "none";
        hideJumpIndicator();
        if (overviewObserver) {
          const cards = overviewGrid.children;
          for (let i = 0; i < cards.length; i++) overviewObserver.unobserve(cards[i]);
        }
      }

      function toggleOverview() {
        if (overviewOpen) closeOverview();
        else openOverview();
      }

      // 总览打开期间接管全部按键：修复上游总览中空格/PGUP/PGDN 仍会翻页的漏洞
      function handleOverviewKeyDown(e) {
        if (e.ctrlKey || e.metaKey || e.altKey) return;
        if (e.isComposing || isEditableKeyTarget(e.target)) return;
        if (/^[0-9]$/.test(e.key)) {
          if (!jumpInvalid && jumpDisplay.length < 4) {
            jumpDisplay += e.key;
            const p = parseInt(jumpDisplay, 10);
            if (!isNaN(p) && p >= 1 && p <= slides.length) setOverviewFocus(p);
            renderJumpBadge();
            armJumpIdleTimer();
          }
          e.preventDefault();
          return;
        }
        if (e.key === "Enter" && jumpDisplay) {
          if (!jumpInvalid) {
            const page = parseInt(jumpDisplay, 10);
            if (!isNaN(page) && page >= 1 && page <= slides.length) {
              goFromOverview(page);
            } else {
              flashJumpInvalid();
            }
          }
          e.preventDefault();
          return;
        }
        if ((e.key === "Escape" || e.key === "Esc") && (jumpDisplay || jumpInvalid)) {
          hideJumpIndicator();
          e.preventDefault();
          return;
        }
        if (e.key === "ArrowRight") {
          e.preventDefault();
          setOverviewFocus(overviewFocus + 1);
          return;
        }
        if (e.key === "ArrowLeft") {
          e.preventDefault();
          setOverviewFocus(overviewFocus - 1);
          return;
        }
        if (e.key === "ArrowDown" || e.key === "PageDown") {
          e.preventDefault();
          setOverviewFocus(overviewFocus + getOverviewCols());
          return;
        }
        if (e.key === "ArrowUp" || e.key === "PageUp") {
          e.preventDefault();
          setOverviewFocus(overviewFocus - getOverviewCols());
          return;
        }
        if (e.key === " ") {
          e.preventDefault();
          return;
        }
        if (e.key === "Enter") {
          e.preventDefault();
          goFromOverview(overviewFocus);
          return;
        }
        if (e.key === "Escape" || e.key === "Esc" || e.key === "o" || e.key === "O") {
          e.preventDefault();
          closeOverview();
        }
      }

      window.addEventListener("keydown", (e) => {
        if (e.key === "Escape" || e.key === "Esc") {
          if (isLightboxOpen) {
            closeLightbox();
            e.preventDefault();
            return;
          }
        }
        if (isLightboxOpen) return;
        // 总览打开期间全部按键由总览层接管
        if (overviewOpen) {
          handleOverviewKeyDown(e);
          return;
        }
        // 「数字+回车」跳页：可输入元素、修饰键、IME 组合输入中不拦截
        if (!e.ctrlKey && !e.metaKey && !e.altKey && !e.isComposing && !isEditableKeyTarget(e.target)) {
          if (/^[0-9]$/.test(e.key)) {
            if (!jumpInvalid && jumpDisplay.length < 4) {
              jumpDisplay += e.key;
              renderJumpBadge();
              armJumpIdleTimer();
            }
            e.preventDefault();
            return;
          }
          if (e.key === "Enter" && jumpDisplay) {
            if (!jumpInvalid) {
              const page = parseInt(jumpDisplay, 10);
              if (!isNaN(page) && page >= 1 && page <= slides.length) {
                hideJumpIndicator();
                renderSlide(page - 1);
              } else {
                flashJumpInvalid();
              }
            }
            e.preventDefault();
            return;
          }
          if ((e.key === "Escape" || e.key === "Esc") && (jumpDisplay || jumpInvalid)) {
            hideJumpIndicator();
            e.preventDefault();
            return;
          }
          if (e.key === "o" || e.key === "O") {
            e.preventDefault();
            toggleOverview();
            return;
          }
        }
        if (e.key === "ArrowRight" || e.key === " " || e.key === "ArrowDown") goNext();
        if (e.key === "ArrowLeft" || e.key === "ArrowUp") goPrev();
        if (e.key === "f" || e.key === "F") btnFullscreen.click();
      });

      // 监听鼠标滚轮上下翻页调度
      let lastWheelTime = 0;
      const WHEEL_COOLDOWN_MS = 280;
      const WHEEL_DELTA_THRESHOLD = 15;

      function canElementScrollY(el, deltaY) {
        let cur = el;
        while (cur && cur !== document.body && cur !== document.documentElement) {
          if (cur.classList && (cur.classList.contains("slidev-viewport") || cur.classList.contains("slidev-stage") || cur.classList.contains("slide-container"))) {
            break;
          }
          const style = window.getComputedStyle(cur);
          const overflowY = style.overflowY;
          if (overflowY === "auto" || overflowY === "scroll") {
            const maxScroll = cur.scrollHeight - cur.clientHeight;
            if (maxScroll > 2) {
              if (deltaY > 0 && cur.scrollTop < maxScroll - 1) return true;
              if (deltaY < 0 && cur.scrollTop > 1) return true;
            }
          }
          cur = cur.parentElement;
        }
        return false;
      }

      window.addEventListener("wheel", (e) => {
        if (isLightboxOpen) return;
        // 总览打开时滚轮交给总览列表原生滚动，不触发翻页
        if (overviewOpen) return;
        if (Math.abs(e.deltaY) < Math.abs(e.deltaX)) return;
        if (Math.abs(e.deltaY) < WHEEL_DELTA_THRESHOLD) return;

        const target = e.target instanceof Element ? e.target : e.target?.parentElement;
        if (target && canElementScrollY(target, e.deltaY)) return;

        e.preventDefault();
        const now = Date.now();
        if (now - lastWheelTime < WHEEL_COOLDOWN_MS) return;
        lastWheelTime = now;

        if (e.deltaY > 0) {
          goNext();
        } else {
          goPrev();
        }
      }, { passive: false });

      document.addEventListener("click", (e) => {
        if (isLightboxOpen) {
          const target = e.target instanceof Element ? e.target : e.target?.parentElement;
          const isMediaItself = target && target.closest && target.closest(".slidev-lightbox-img, .slidev-lightbox-video");
          if (!isMediaItself) {
            e.stopPropagation();
            closeLightbox();
          }
          return;
        }
        // 总览打开时空白点击由总览层自身处理，不触发底层翻页
        if (overviewOpen) return;
        if (e.button !== 0) return;
        const targetEl = e.target instanceof Element ? e.target : e.target?.parentElement;
        if (!targetEl || !targetEl.closest) return;

        const refEl = targetEl.closest("[data-ref-id]");
        if (refEl) {
          const id = refEl.getAttribute("data-ref-id");
          if (id) {
            window.open("siyuan://blocks/" + id, "_blank");
            return;
          }
        }

        // 媒体点击唤起 Lightbox 放大模态
        const mediaEl = targetEl.closest(".slide-content img, .slide-content video");
        if (mediaEl && !mediaEl.closest(".controls, .controls-bar, button, a")) {
          e.stopPropagation();
          const isVideo = mediaEl.tagName.toLowerCase() === "video";
          const src = isVideo ? (mediaEl.currentSrc || mediaEl.src || mediaEl.querySelector("source")?.src) : mediaEl.src;
          if (src) {
            openLightbox(isVideo ? "video" : "image", src, mediaEl.alt || "");
            return;
          }
        }

        const selection = window.getSelection ? window.getSelection().toString().trim() : "";
        if (selection.length > 0) return;

        const isComponent = targetEl.closest(
          ".slide-block, .controls-bar, .image-right-img-container, .image-left-img-container, .controls, img, video, audio, button, a, input, textarea, select, [data-clickable], [data-ref-id], .slidev-toc, .empty-state"
        );
        if (isComponent) return;

        const isLeft = e.clientX < window.innerWidth / 2;
        if (isLeft) {
          goPrev();
        } else {
          goNext();
        }
      });

      renderSlide(0);
      updateScale();
    })();`}function Ia(e,t){const i="Slidev 演示文稿";let n=e.slides;const o=JSON.stringify(n),s=JSON.stringify(e.config);return`<!DOCTYPE html>
<html lang="zh-CN">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${ct(i)}</title>
  <style>
${Gm(t==null?void 0:t.customInlineStyles)}
  </style>
  <script>
    // 注入演示数据载荷
    window.__SLIDEV_DATA__ = {
      docId: ${JSON.stringify(e.docId)},
      slides: ${o},
      config: ${s}
    };
  <\/script>
</head>
<body>
  <div id="app" data-normalize-headings="${e.config.normalizeHeadingSizes?"true":"false"}">
    <div class="slide-viewport slidev-theme-${e.config.theme||"default"}" id="viewport" data-slidev-theme="${e.config.theme||"default"}">
      <div class="slide-content" id="slide-container"></div>
    </div>
    <div class="controls">
      <button id="btn-prev">◀ 上一页</button>
      <span id="page-num">1 / 1</span>
      <button id="btn-next">下一页 ▶</button>
      <button id="btn-fullscreen">全屏</button>
    </div>
    <!-- 全屏媒体灯箱 (Lightbox) 模态窗口 -->
    <div id="slidev-lightbox" class="slidev-lightbox">
      <button class="slidev-lightbox-close" id="lightbox-close" aria-label="关闭 (Esc)">✕</button>
      <div class="slidev-lightbox-content" id="lightbox-content"></div>
    </div>
  </div>

  <script>
${Zm()}
  <\/script>
</body>
</html>`}function Ea(e,t){if(typeof document>"u")return!1;const i=new Blob([t],{type:"text/html;charset=utf-8"}),n=URL.createObjectURL(i),o=document.createElement("a");return o.href=n,o.download=e.endsWith(".html")?e:`${e}.html`,document.body.appendChild(o),o.click(),document.body.removeChild(o),URL.revokeObjectURL(n),!0}function Ym(e){switch(e){case"4:3":return"size: 12in 9in;";case"A4-landscape":return"size: 297mm 210mm;";case"A4-portrait":return"size: 210mm 297mm;";case"16:9":default:return"size: 16in 9in;"}}function Jm(e){const t=Ym(e==null?void 0:e.pageRatio);return`
    ${_n(e==null?void 0:e.customInlineStyles)}

    @page {
      ${t}
      margin: 0;
    }
    * {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
      -webkit-print-color-adjust: exact !important;
      print-color-adjust: exact !important;
    }
    body {
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "PingFang SC", "Microsoft YaHei", sans-serif;
      background: #f8fafc;
      color: #1e293b;
    }
    .pdf-slide-page {
      width: 100vw;
      height: 100vh;
      page-break-after: always;
      break-after: page;
      padding: var(--slidev-padding-y, 36px) var(--slidev-padding-x, 56px);
      display: flex;
      flex-direction: column;
      position: relative;
      background: #ffffff;
      overflow: hidden;
    }
    .pdf-slide-page.spacing-compact {
      --slidev-padding-y: 20px;
      --slidev-padding-x: 36px;
      --slidev-header-gap: 10px;
      --slidev-title-margin-bottom: 6px;
    }
    .pdf-slide-page.spacing-normal {
      --slidev-padding-y: 36px;
      --slidev-padding-x: 56px;
      --slidev-header-gap: 16px;
      --slidev-title-margin-bottom: 10px;
    }
    .pdf-slide-page.spacing-loose {
      --slidev-padding-y: 48px;
      --slidev-padding-x: 64px;
      --slidev-header-gap: 24px;
      --slidev-title-margin-bottom: 16px;
    }
    .pdf-slide-page.theme-dark {
      background: #0f1117;
      color: #f1f5f9;
    }
    .pdf-slide-header {
      font-size: 13px;
      color: #64748b;
      margin-bottom: 24px;
      display: flex;
      justify-content: space-between;
      border-bottom: 1px solid #e2e8f0;
      padding-bottom: 8px;
    }
    .theme-dark .pdf-slide-header {
      border-bottom-color: #2e3346;
      color: #94a3b8;
    }
    .pdf-slide-body {
      flex: 1;
      display: flex;
      flex-direction: column;
      gap: 16px;
      font-size: 20px;
      line-height: 1.6;
      overflow: hidden;
    }
    .pdf-block h1 { font-size: 2.5rem; font-weight: 800; color: #2563eb; margin-bottom: 12px; }
    .pdf-block h2 { font-size: 1.9rem; font-weight: 700; color: #1d4ed8; margin-bottom: 10px; }
    .pdf-block h3 { font-size: 1.4rem; font-weight: 600; margin-bottom: 8px; }
    .pdf-block h4 { font-size: 1.2rem; font-weight: 600; margin-bottom: 6px; }
    .pdf-block p { font-size: 1.15rem; color: inherit; }
    .pdf-code,
    pre {
      background: #f1f5f9;
      padding: 14px 18px;
      border-radius: 6px;
      font-family: "JetBrains Mono", Consolas, monospace;
      font-size: 0.95rem;
      border-left: 4px solid #3b82f6;
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      max-width: 100% !important;
      box-sizing: border-box !important;
    }
    .pdf-code code,
    pre code {
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      display: block !important;
      width: 100% !important;
      box-sizing: border-box !important;
    }
    .code-line {
      display: flex !important;
      align-items: flex-start !important;
      width: 100% !important;
      box-sizing: border-box !important;
      line-height: 1.6;
    }
    .code-line .line-no {
      display: inline-block !important;
      flex-shrink: 0 !important;
      min-width: 2.2em !important;
      text-align: right !important;
      margin-right: 12px !important;
      user-select: none !important;
      opacity: 0.45 !important;
    }
    .code-line .line-content {
      flex: 1 1 0% !important;
      min-width: 0 !important;
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
    }
    .theme-dark .pdf-code {
      background: #1e1e24;
      border-left-color: #60a5fa;
    }
    .pdf-quote {
      border-left: 4px solid #10b981;
      background: rgba(16, 185, 129, 0.08);
      padding: 10px 16px;
      border-radius: 0 4px 4px 0;
      font-style: italic;
    }
    .pdf-image,
    .slide-media-img {
      max-width: 100% !important;
      max-height: 48vh !important;
      width: auto !important;
      height: auto !important;
      object-fit: contain !important;
      border-radius: 6px;
      margin: auto;
      display: block;
    }
    .slide-media-block,
    .slide-media-container,
    .slide-video-container {
      display: flex;
      flex-direction: column;
      justify-content: center;
      align-items: center;
      width: 100%;
      max-height: 48vh;
      margin: 8px 0;
      overflow: hidden;
    }
    .slide-list-media {
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: flex-start;
      margin-top: 8px;
      margin-bottom: 6px;
      max-width: 100%;
      overflow: hidden;
    }
    .slide-list-media img,
    .slide-list-media video,
    .slide-list-media .list-item-gif {
      max-width: 100% !important;
      max-height: min(280px, 36vh) !important;
      width: auto !important;
      height: auto !important;
      min-width: 0 !important;
      min-height: 0 !important;
      object-fit: contain !important;
      border-radius: 6px;
      display: block;
      margin: 0 auto !important;
    }
    .slide-video-player {
      max-width: 100% !important;
      max-height: 48vh !important;
      width: auto !important;
      height: auto !important;
      object-fit: contain !important;
      border-radius: 6px;
      background: #000;
      border: 1px solid #cbd5e1;
    }
    .pdf-two-cols-wrapper,
    .layout-two-cols-grid,
    .layout-cols-wrapper,
    .layout-cols-grid {
      display: grid;
      grid-template-columns: minmax(0, 1fr) minmax(0, 1fr);
      grid-template-rows: minmax(0, 1fr) !important;
      gap: 36px;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      overflow: hidden !important;
    }
    .layout-cols-header-container,
    .layout-two-cols-header-container,
    .layout-three-cols-header-container,
    .layout-clover-container {
      display: flex;
      flex-direction: column;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      overflow: hidden !important;
    }
    .layout-header-section {
      width: 100%;
      margin-bottom: var(--slidev-header-gap, 16px) !important;
      flex-shrink: 0;
    }
    .layout-header-section h1,
    .layout-header-section h2,
    .layout-header-section h3 {
      margin-bottom: var(--slidev-title-margin-bottom, 10px) !important;
    }
    .pdf-three-cols-wrapper,
    .layout-three-cols-grid {
      display: grid;
      grid-template-columns: minmax(0, 1fr) minmax(0, 1fr) minmax(0, 1fr);
      grid-template-rows: minmax(0, 1fr) !important;
      gap: 24px;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      box-sizing: border-box;
      overflow: hidden !important;
    }
    .pdf-clover-wrapper,
    .layout-clover-grid {
      display: grid;
      grid-template-columns: repeat(2, minmax(0, 1fr)) !important;
      grid-template-rows: repeat(2, minmax(0, 1fr)) !important;
      gap: 20px;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      box-sizing: border-box;
      overflow: hidden !important;
    }
    .layout-clover-grid .pdf-col {
      background: transparent !important;
      border: none !important;
      box-shadow: none !important;
    }
    .pdf-col {
      display: flex;
      flex-direction: column;
      gap: 14px;
      min-width: 0;
      width: 100%;
      max-width: 100%;
      height: 100%;
      max-height: 100%;
      min-height: 0;
      justify-content: flex-start;
      overflow: hidden;
      box-sizing: border-box;
      overflow-wrap: break-word;
      word-break: break-word;
      white-space: normal;
    }
    /* 表头多栏内超级块子块首个列表项去圆点后居中显示标题/首行文本 (仅在存在超级块分栏时生效) */
    .has-superblock-cols .pdf-col > *:first-child .slide-list-item-title,
    .has-superblock-cols .pdf-col > *:first-child :is(h1, h2, h3, h4, h5, h6),
    .has-superblock-cols .pdf-col > *:first-child p.slide-list-item-title,
    .has-superblock-cols .pdf-col > *:first-child p:first-of-type,
    .has-superblock-cols .pdf-col > *:first-child p:first-child,
    .has-superblock-cols .pdf-col > *:first-child :is(ul, ol) > li:first-child,
    .has-superblock-cols .pdf-col > *:first-child .slide-list > .slide-list-item:first-child,
    .has-superblock-cols .pdf-col > *:first-child .pdf-list > li:first-child,
    .has-superblock-cols .slidev-col-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    .has-superblock-cols .slidev-col-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      list-style: none !important;
      list-style-type: none !important;
      text-align: center !important;
      margin-left: 0 !important;
      padding-left: 0 !important;
      width: 100% !important;
    }

    /* 彻底清除首个列表项的原生圆点 Marker (仅在存在超级块分栏时生效) */
    .has-superblock-cols .pdf-col > *:first-child :is(ul, ol) > li:first-child::marker {
      content: "" !important;
      display: none !important;
    }

    /* 确保首个列表项内部内联与块级元素居中 (仅在存在超级块分栏时生效) */
    .has-superblock-cols .pdf-col > *:first-child :is(ul, ol) > li:first-child * {
      text-align: center !important;
    }

    /* 栏内说明段落与列表项：左对齐，自然阅读排版 */
    .has-superblock-cols .pdf-col .slide-list-item-desc,
    .has-superblock-cols .pdf-col li:not(:first-child) {
      text-align: left !important;
    }

    /* 全局特定标题大小规范化 (除封面外页首首个标题按 H2 1.7rem，表头多栏内首个标题按 H3 1.3rem) */
    [data-normalize-headings="true"] .slidev-page-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .slidev-page-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .pdf-slide:not(.layout-cover) > :is(.pdf-block, .slide-block):first-child :is(h1, h2, h3, h4, h5, h6),
    [data-normalize-headings="true"] .pdf-slide:not(.layout-cover) > .layout-header-section :is(.pdf-block, .slide-block):first-child :is(h1, h2, h3, h4, h5, h6),
    [data-normalize-headings="true"] .pdf-slide:not(.layout-cover) > :not(.layout-cols-wrapper):not(.pdf-two-cols-wrapper):not(.layout-image-cols-grid):first-child :is(h1, h2, h3, h4, h5, h6) {
      font-size: 1.7rem !important;
      font-weight: 600 !important;
      line-height: 1.25 !important;
      margin-bottom: 10px !important;
    }

    [data-normalize-headings="true"] .has-superblock-cols .slidev-col-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .has-superblock-cols .slidev-col-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .has-superblock-cols .pdf-col > *:first-child :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      font-size: 1.3rem !important;
      font-weight: 600 !important;
      line-height: 1.3 !important;
      margin-bottom: 8px !important;
      text-align: center !important;
    }

    /* 图左与图右版式标题完全保留用户原始字号与默认排版，不进行任何固定大小规范化 */
    [data-normalize-headings="true"] :is(.layout-image-left, .layout-image-right, .image-left-content, .image-right-content) :is(h1, h2, h3, h4, h5, h6) {
      text-align: left !important;
    }
    .pdf-col > .pdf-block,
    .pdf-col > .slide-block {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      max-height: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      width: 100% !important;
      height: 100% !important;
      box-sizing: border-box !important;
      overflow: hidden !important;
    }
    .pdf-col .slide-list-item-title,
    .pdf-col h1, .pdf-col h2, .pdf-col h3, .pdf-col h4, .pdf-col h5, .pdf-col h6,
    .pdf-col .slide-list-item-desc {
      flex: 0 0 auto !important;
      margin-top: 0 !important;
      margin-bottom: 6px !important;
    }
    .pdf-col .slide-list-media,
    .pdf-col .slide-video-container,
    .pdf-col .slide-media-container {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      min-width: 0 !important;
      width: 100% !important;
      height: 100% !important;
      max-height: 100% !important;
      max-width: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
      justify-content: flex-start !important;
      overflow: hidden !important;
      margin: 0 !important;
      padding: 0 !important;
      box-sizing: border-box !important;
    }
    .pdf-col li:has(.slide-list-media),
    .pdf-col li:has(.slide-media-container),
    .pdf-col li:has(.slide-video-container),
    .pdf-col li:has(img),
    .pdf-col li:has(video),
    .pdf-col .pdf-list-item:has(.slide-list-media),
    .pdf-col .pdf-list-item:has(.slide-media-container),
    .pdf-col .pdf-list-item:has(.slide-video-container),
    .pdf-col .pdf-list-item:has(img),
    .pdf-col .pdf-list-item:has(video) {
      display: list-item !important;
      list-style-type: disc !important;
      flex: 0 0 auto !important;
      height: auto !important;
      max-height: none !important;
      overflow: visible !important;
      margin-bottom: 6px !important;
    }
    .pdf-col video,
    .layout-three-cols-grid video,
    .layout-two-cols-grid video,
    .pdf-col img,
    .layout-three-cols-grid img,
    .layout-two-cols-grid img,
    .pdf-col .slide-video-player {
      max-width: 100% !important;
      max-height: 100% !important;
      width: auto !important;
      height: auto !important;
      min-width: 0 !important;
      min-height: 0 !important;
      object-fit: contain !important;
      display: block !important;
      margin: 0 auto !important;
    }
    .pdf-col * {
      overflow-wrap: break-word;
      word-break: break-word;
      box-sizing: border-box;
    }
    .pdf-col pre {
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      max-width: 100% !important;
      box-sizing: border-box !important;
    }
    .pdf-list-item {
      padding-left: 20px;
    }
    .pdf-list {
      padding-left: 24px;
      margin: 8px 0;
      display: flex;
      flex-direction: column;
      gap: 6px;
    }
    .pdf-list li {
      font-size: 1.15rem;
      line-height: 1.6;
    }
    .pdf-task-item {
      list-style: none;
      margin-left: -20px;
      display: flex;
      align-items: center;
      gap: 8px;
    }
    .pdf-task-item input[type="checkbox"] {
      width: 1.15em;
      height: 1.15em;
      cursor: pointer;
    }
    /* 两栏与三栏及多栏（超级块分栏）布局：紧凑自然行距，子列表保留圆点与层级缩进 */
    .layout-two-cols ul,
    .layout-cols-header ul,
    .layout-two-cols-header ul,
    .layout-three-cols ul,
    .layout-three-cols-header ul,
    .two-cols-left ul,
    .two-cols-right ul,
    .three-cols-col ul,
    .col ul,
    .pdf-two-cols-wrapper ul,
    .pdf-three-cols-wrapper ul,
    .pdf-col ul,
    .layout-two-cols-grid .pdf-list,
    .layout-three-cols-grid .pdf-list,
    .layout-cols-grid .pdf-list,
    .layout-two-cols-grid .pdf-list--unordered,
    .layout-three-cols-grid .pdf-list--unordered,
    .layout-cols-grid .pdf-list--unordered {
      list-style: disc !important;
      list-style-type: disc !important;
      padding-left: 1.25em !important;
      margin-left: 0 !important;
      margin-top: 0 !important;
      margin-bottom: 8px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: block !important;
    }
    .layout-two-cols ol,
    .layout-cols-header ol,
    .layout-two-cols-header ol,
    .layout-three-cols ol,
    .layout-three-cols-header ol,
    .two-cols-left ol,
    .two-cols-right ol,
    .three-cols-col ol,
    .col ol,
    .pdf-two-cols-wrapper ol,
    .pdf-three-cols-wrapper ol,
    .pdf-col ol,
    .layout-two-cols-grid .pdf-list--ordered,
    .layout-three-cols-grid .pdf-list--ordered,
    .layout-cols-grid .pdf-list--ordered {
      list-style: decimal !important;
      list-style-type: decimal !important;
      padding-left: 1.25em !important;
      margin-left: 0 !important;
      margin-top: 0 !important;
      margin-bottom: 8px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: block !important;
    }
    .layout-two-cols li,
    .layout-cols-header li,
    .layout-two-cols-header li,
    .layout-three-cols li,
    .layout-three-cols-header li,
    .two-cols-left li,
    .two-cols-right li,
    .three-cols-col li,
    .col li,
    .pdf-col li,
    .pdf-col .pdf-list-item {
      padding-left: 0.2em !important;
      margin-left: 0 !important;
      margin-bottom: 6px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: list-item !important;
      line-height: 1.6 !important;
    }
    .layout-two-cols ul ul,
    .layout-three-cols ul ul,
    .three-cols-col ul ul,
    .pdf-col ul ul {
      list-style: circle !important;
      list-style-type: circle !important;
      padding-left: 1.25em !important;
      margin-top: 4px !important;
      margin-bottom: 4px !important;
    }
    /* 列表项内嵌标题与说明排版 */
    .slide-list-item-title,
    .pdf-list li > h1,
    .pdf-list li > h2,
    .pdf-list li > h3,
    .pdf-list li > h4,
    .pdf-list li > h5,
    .pdf-list li > h6,
    li > h1.slide-list-item-title,
    li > h2.slide-list-item-title,
    li > h3.slide-list-item-title,
    li > h4.slide-list-item-title {
      margin-top: 2px !important;
      margin-bottom: 6px !important;
      line-height: 1.35 !important;
      font-weight: 700 !important;
    }
    .pdf-list li > h1, li > h1.slide-list-item-title { font-size: 1.6rem !important; }
    .pdf-list li > h2, li > h2.slide-list-item-title { font-size: 1.4rem !important; }
    .pdf-list li > h3, li > h3.slide-list-item-title { font-size: 1.22rem !important; }
    .pdf-list li > h4, li > h4.slide-list-item-title { font-size: 1.1rem !important; }

    /* 全局特定标题大小规范化后置强力锁定 (防止被列表项内部字号覆盖) */
    [data-normalize-headings="true"] .slidev-page-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .slidev-page-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      font-size: 1.7rem !important;
      font-weight: 600 !important;
      line-height: 1.25 !important;
      margin-bottom: 10px !important;
    }
    [data-normalize-headings="true"] .has-superblock-cols .slidev-col-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .has-superblock-cols .slidev-col-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .has-superblock-cols .pdf-col > *:first-child :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      font-size: 1.3rem !important;
      font-weight: 600 !important;
      line-height: 1.3 !important;
      margin-bottom: 8px !important;
      text-align: center !important;
    }
    .slide-list-item-desc,
    .pdf-list li > p {
      margin-top: 4px !important;
      margin-bottom: 6px !important;
      font-size: 1.05rem;
      line-height: 1.55;
      opacity: 0.92;
    }
    kbd {
      display: inline-block;
      padding: 2px 7px;
      font-family: ui-monospace, SFMono-Regular, "SF Mono", Menlo, Consolas, "Liberation Mono", monospace;
      font-size: 0.85em;
      font-weight: 600;
      line-height: 1.25;
      color: inherit;
      background: rgba(125, 125, 125, 0.12);
      border: 1px solid rgba(125, 125, 125, 0.35);
      border-bottom-width: 2px;
      border-radius: 5px;
      box-shadow: 0 1px 2px rgba(0, 0, 0, 0.12);
      margin: 0 2px;
      vertical-align: middle;
      white-space: nowrap;
    }
    .theme-dark kbd {
      background: rgba(255, 255, 255, 0.1);
      border-color: rgba(255, 255, 255, 0.25);
      border-bottom-color: rgba(255, 255, 255, 0.4);
      color: #f1f5f9;
      box-shadow: 0 1px 2px rgba(0, 0, 0, 0.4);
    }
    a {
      color: inherit;
      text-decoration: none;
      border-bottom: 1px dashed currentColor;
    }
    .slidev-ref-tag, a.slidev-ref-tag {
      display: inline-flex;
      align-items: center;
      background: rgba(16, 185, 129, 0.1);
      color: #059669;
      border: 1px solid rgba(16, 185, 129, 0.25);
      border-radius: 4px;
      padding: 2px 8px;
      font-size: 0.88em;
      text-decoration: none;
      margin: 2px 4px 2px 0;
    }
    .theme-dark .slidev-ref-tag, .theme-dark a.slidev-ref-tag {
      background: rgba(52, 211, 153, 0.15);
      color: #34d399;
      border-color: rgba(52, 211, 153, 0.3);
    }
    .slidev-block-ref, .pdf-block--ref {
      background: rgba(16, 185, 129, 0.06);
      border-left: 3px solid #059669;
      border-radius: 0 6px 6px 0;
      padding: 10px 14px;
      margin: 8px 0;
    }
    .theme-dark .slidev-block-ref, .theme-dark .pdf-block--ref {
      background: rgba(52, 211, 153, 0.08);
      border-left-color: #34d399;
    }
    .pdf-slide-notes {
      font-size: 14px;
      color: #059669;
      border-top: 1px dashed #cbd5e1;
      padding-top: 12px;
      margin-top: auto;
      line-height: 1.5;
    }
    .theme-dark .pdf-slide-notes {
      color: #34d399;
      border-top-color: #334155;
    }
    /* Layouts */
    .layout-cover .pdf-slide-body {
      justify-content: center;
      align-items: center;
      text-align: center;
    }
    .layout-cover h1 {
      font-size: 3.2rem;
    }
    .layout-center .pdf-slide-body {
      justify-content: center;
      align-items: center;
      text-align: center;
    }
    .layout-fact .pdf-slide-body {
      justify-content: center;
      align-items: center;
      text-align: center;
    }
    .layout-fact h1 {
      font-size: 4.5rem;
      color: #ef4444;
    }
    @media print {
      .slidev-motion-fade-in,
      .slidev-motion-slide-up,
      .slidev-motion-slide-down,
      .slidev-motion-slide-left,
      .slidev-motion-slide-right,
      .slidev-motion-zoom-in,
      .slidev-motion-pop,
      .slidev-motion-bounce {
        animation: none !important;
        opacity: 1 !important;
        transform: none !important;
      }
      /* PDF 打印讲义下禁用动态蒙版遮挡，保证内容 100% 完整可见 */
      .slidev-mask-layer,
      .slidev-mask-overlay,
      .slidev-mask-divider-line {
        display: none !important;
        opacity: 0 !important;
      }
      .slidev-mask-body-container {
        clip-path: none !important;
        -webkit-clip-path: none !important;
        overflow: visible !important;
      }
    }
  `}function Xm(e,t){const i="Slidev 演示讲义",n="16:9",o="light",s=e.slides.map((l,r)=>{const a=l.frontmatter.layout||"default",c=l.frontmatter.spacing,d=c&&c!=="inherit"?c:e.config.spacing||"normal",m=Hm(l),b=`${r+1} / ${e.slides.length}`;return`
      <section class="pdf-slide-page layout-${a} theme-${o} spacing-${d}">
        <header class="pdf-slide-header">
          <span class="pdf-doc-title">${ct(i)}</span>
          ${`<span class="pdf-page-badge">P. ${b}</span>`}
        </header>
        <div class="pdf-slide-body">
          ${m}
        </div>
        ${l.notes?`
          <footer class="pdf-slide-notes">
            <strong>演讲备注:</strong> ${ct(l.notes)}
          </footer>
        `:""}
      </section>
    `}).join(`
`);return`<!DOCTYPE html>
<html lang="zh-CN">
<head>
  <meta charset="UTF-8">
  <title>${ct(i)} - 高保真讲义</title>
  <style>
    ${Jm({pageRatio:n,customInlineStyles:t==null?void 0:t.customInlineStyles})}
  </style>
</head>
<body data-normalize-headings="${e.config.normalizeHeadingSizes?"true":"false"}">
  ${s}
</body>
</html>`}function Ta(e,t){var o;if(typeof window>"u"||typeof document>"u")return!1;const i=Xm(e,t);try{const s=document.createElement("iframe");s.style.position="fixed",s.style.right="0",s.style.bottom="0",s.style.width="0",s.style.height="0",s.style.border="none",s.style.visibility="hidden",document.body.appendChild(s);const l=(o=s.contentWindow)==null?void 0:o.document;if(l)return l.open(),l.write(i),l.close(),setTimeout(()=>{var r,a;try{(r=s.contentWindow)==null||r.focus(),(a=s.contentWindow)==null||a.print()}finally{setTimeout(()=>{s.remove()},2e3)}},350),!0}catch(s){console.warn("[pdf-exporter] iframe 打印模式异常，降级尝试 window.open:",s)}const n=window.open("","_blank");return n?(n.document.write(i),n.document.close(),n.focus(),setTimeout(()=>{n.print(),n.close()},350),!0):!1}const Qm=1500,eg=500,tg=4,ig=new Set(["INPUT","TEXTAREA","SELECT"]);function Aa(e){const t=e;return!t||!t.tagName?!1:ig.has(t.tagName)||t.isContentEditable===!0}function ng(e){let t="",i=!1,n=null,o=null;function s(){e.onStateChange&&e.onStateChange({display:t,invalid:i})}function l(){n&&(clearTimeout(n),n=null),o&&(clearTimeout(o),o=null)}function r(){l(),t="",i=!1,s()}function a(){n&&clearTimeout(n),n=setTimeout(r,Qm)}function c(){n&&(clearTimeout(n),n=null),i=!0,s(),o&&clearTimeout(o),o=setTimeout(r,eg)}function d(m){if(e.isEnabled&&!e.isEnabled()||Aa(m.target)||m.isComposing||m.ctrlKey||m.metaKey||m.altKey)return!1;if(/^[0-9]$/.test(m.key))return i||t.length>=tg||(t+=m.key,s(),a()),!0;if(m.key==="Enter"){if(!t||i)return!1;const u=parseInt(t,10),h=e.getTotalPages();return!isNaN(u)&&u>=1&&h>0&&u<=h?(r(),e.onJump(u),!0):(c(),!0)}return m.key==="Escape"&&(t||i)?(r(),!0):!1}return{handleKeydown:d,getState:()=>({display:t,invalid:i}),clear:r}}const og={class:"spm-slidev-tab__toolbar"},sg={class:"spm-slidev-tab__nav"},rg=["disabled"],lg={class:"spm-page-badge"},ag=["disabled"],cg=["aria-label"],dg=["aria-label"],ug={class:"spm-slidev-tab__tools"},fg=["src"],pg=Ct({__name:"SlidevPreviewTab",setup(e,{expose:t}){const i=ei("plugin"),n=ei("sandboxBridge",new Ys),o=new Pm(n),s=new Uf,l=ve("web-sandbox"),r=ve(3030),a=ve(null),c=ve(!1),d=ve(null),m=ve(1),b=ve(1),u=ve([]),h=ve(!1),f=ve(!1),v=ve(!1),k=ve("siyuan"),S=ve(""),$=ve(""),T=ve(""),D=ve(!1),E=ve(!1),x=ve(""),W=ve(""),V=ve(!1),G=ng({getTotalPages:()=>b.value,isEnabled:()=>!f.value,onJump:w=>P(w),onStateChange:w=>{W.value=w.display,V.value=w.invalid}});function X(w){if(w.key==="o"||w.key==="O"){if(f.value||w.isComposing||w.ctrlKey||w.metaKey||w.altKey||Aa(w.target))return;w.preventDefault(),C();return}G.handleKeydown(w)&&w.preventDefault()}function C(){var w,A;if(l.value==="pro-cli"){(w=d.value)==null||w.focus(),he.showMessage("Pro 模式使用官方原生总览：在画面内按 O 呼出");return}n.toggleOverview(),(A=d.value)==null||A.focus()}function P(w){var A;m.value=w,l.value==="pro-cli"?s.nativeBridge.navigateToPage(w):n.navigatePage(w),(A=d.value)==null||A.focus()}const y=ve("/plugins/siyuan-slidev/slidev-client/index.html");let O=null,U=null,B=null,R=null,F=null,ee=null,I=null;Fn(()=>{d.value&&(n.attach(d.value),s.nativeBridge.attach(d.value)),O=n.onSlideChanged((w,A)=>{m.value=w,b.value=A}),U=n.onBlockClicked((w,A)=>{m.value=A,o.setActiveBlockId(w),i&&typeof i.handleBlockClickedFromSlide=="function"?i.handleBlockClickedFromSlide(w,A):Ni(w,i==null?void 0:i.app)}),B=n.onOpenInEditor((w,A)=>{m.value=A,o.setActiveBlockId(w),Ni(w,i==null?void 0:i.app)}),R=s.nativeBridge.onPageChanged((w,A)=>{m.value=w,b.value=A}),F=n.onOpenPeekDrawer(async w=>{const A=No();if(w.peekType==="siyuan"&&A.enableWebServeJump){let q=!1;if(I&&I.docId===w.target)q=!0;else if(I&&I.slides&&I.slides.some(K=>{var Z;return(Z=K.blocks)==null?void 0:Z.some(ne=>ne.id===w.target)}))q=!1;else try{const K=await en(`SELECT id, root_id, type FROM blocks WHERE id = '${w.target}' LIMIT 1`);K&&K.length>0&&(q=K[0].type==="d"||K[0].id===K[0].root_id)}catch(K){console.warn("[SlidevPreviewTab] detect block type failed:",K)}k.value="web",D.value=!0,$.value=ua(A.webServeUrl,w.target,{focus:!q}),T.value=w.title||`${q?"思源文档":"思源块"}: ${w.target.slice(0,8)}`,f.value=!0,n.freezeKeyboardNav(!0)}else{if(k.value=w.peekType,w.peekType==="siyuan")S.value=w.target,T.value=w.title||`块速览: ${w.target.slice(0,8)}`;else{const q=Sa(w.target);if(q.external){L(w.target);return}D.value=!0,$.value=q.url,T.value=w.title||q.url}f.value=!0,n.freezeKeyboardNav(!0)}}),ee=n.onRequestToggleFullscreen(()=>{g()}),typeof document<"u"&&document.addEventListener("fullscreenchange",H)}),Fs(()=>{typeof document<"u"&&document.removeEventListener("fullscreenchange",H),F&&F(),ee&&ee(),O&&O(),U&&U(),B&&B(),R&&R(),n.detach(),G.clear(),o.destroy(),s.destroy()});async function M(){if(l.value==="web-sandbox"){if(!I){he.showMessage("请先在主编辑区打开演示文档");return}he.showMessage("正在探测本地 Node 环境并编排 Slidev Pro 进程...");const w=await s.startProMode(I,rs);if(!w.success){he.showMessage(`无法启动官方 Pro 模式：${w.error}`);return}l.value="pro-cli",r.value=w.port||3030,y.value=w.url,d.value&&s.nativeBridge.attach(d.value),he.showMessage(`🟢 已成功接入官方原生 Slidev 服务 (端口: ${r.value})`)}else s.stopProMode(),l.value="web-sandbox",y.value="/plugins/siyuan-slidev/slidev-client/index.html",d.value&&n.attach(d.value),he.showMessage("已切回内置高保真沙箱")}function J(){E.value=!E.value,E.value?(x.value=(I==null?void 0:I.docId)||"",i&&typeof i.updatePreviewTabHeader=="function"&&i.updatePreviewTabHeader("",x.value)):(x.value="",N(),i&&typeof i.updatePreviewTabHeader=="function"&&i.updatePreviewTabHeader())}let Y=0;function te(w){if(f.value||Math.abs(w.deltaY)<Math.abs(w.deltaX)||Math.abs(w.deltaY)<15)return;const A=Date.now();A-Y<280||(Y=A,w.deltaY>0?pe():ie())}function ie(){if(m.value>1){const w=m.value-1;m.value=w,l.value==="pro-cli"?s.nativeBridge.navigateToPage(w):n.navigatePage(w)}}function pe(){if(m.value<b.value){const w=m.value+1;m.value=w,l.value==="pro-cli"?s.nativeBridge.navigateToPage(w):n.navigatePage(w)}}function le(w){m.value=w,l.value==="pro-cli"?s.nativeBridge.navigateToPage(w):n.navigatePage(w)}function N(){i&&typeof i.compileCurrentDocument=="function"?i.compileCurrentDocument():i!=null&&i.eventBus&&typeof i.eventBus.emit=="function"&&i.eventBus.emit("slidev:request-compile")}function ae(){f.value=!1,n.freezeKeyboardNav(!1)}function ue(){ae()}function L(w){var Z,ne;const A=/^file:/i.test(w),q=A||/^[a-zA-Z]:[\\/]/.test(w),K=_t("electron");if(q&&typeof((Z=K==null?void 0:K.shell)==null?void 0:Z.openPath)=="function"){K.shell.openPath(A?xa(w):w),he.showMessage("本地文件不在思源工作区内，已交由系统默认浏览器打开");return}typeof((ne=K==null?void 0:K.shell)==null?void 0:ne.openExternal)=="function"?K.shell.openExternal(w).catch(()=>{typeof window<"u"&&window.open(w,"_blank")}):typeof window<"u"&&window.open(w,"_blank"),he.showMessage("该地址无法在速览抽屉内加载，已交由系统默认浏览器打开")}function H(){typeof document<"u"&&(c.value=!!document.fullscreenElement,n.postMessage("FULLSCREEN_CHANGED",{isFullscreen:c.value}))}function g(){const w=a.value||d.value;w&&(document.fullscreenElement?document.exitFullscreen().then(()=>{n.postMessage("FULLSCREEN_CHANGED",{isFullscreen:!1})}).catch(()=>{}):w.requestFullscreen().then(()=>{n.postMessage("FULLSCREEN_CHANGED",{isFullscreen:!0})}).catch(()=>{}))}function j(){window.open("/plugins/siyuan-slidev/slidev-client/presenter.html","SlidevPresenter","width=1200,height=800")}function z(){if(!I){he.showMessage("请先在主编辑区打开幻灯片文档");return}const w=Ia(I);Ea("presentation.html",w)&&he.showMessage("已开始下载单文件离线 HTML 演示包")}function _(){if(!I){he.showMessage("请先在主编辑区打开幻灯片文档");return}Ta(I)&&he.showMessage("已唤起打印视窗，请在打印选项中选择「另存为 PDF」")}return t({updateDocument(w,A){E.value&&x.value&&A&&A!==x.value||(I=w,E.value&&!x.value&&(x.value=w.docId),u.value=w.slides,b.value=w.slides.length,o.setDocId(w.docId),o.updateSlidesIndex(w.slides),l.value==="pro-cli"?s.scaffolder.scaffold(w,rs).catch(()=>{}):n.updateSlides(w.slides,w.config,w.fullMarkdown,w.customThemeCss),i&&typeof i.updatePreviewTabHeader=="function"&&i.updatePreviewTabHeader("",w.docId))},navigateToBlock(w){o.onCursorFocusBlock(w)},isPinned:E,pinnedDocId:x,engineMode:l,toggleEngineMode:M}),(w,A)=>(oe(),se("div",{class:"spm-slidev-preview-tab",onKeydown:X},[p("div",og,[p("div",sg,[p("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s",disabled:m.value<=1,"aria-label":"上一页",onClick:ie},[de(fe,{name:"chevron-left"})],8,rg),p("span",lg,Se(m.value)+" / "+Se(b.value||1),1),p("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s",disabled:m.value>=b.value,"aria-label":"下一页",onClick:pe},[de(fe,{name:"chevron-right"})],8,ag),p("button",{class:Ie(["spm-icon-btn b3-tooltips b3-tooltips__s",{"is-primary":E.value}]),"aria-label":E.value?"已锁定当前文档（点击解除）："+x.value:"点击锁定当前文档（不随主编辑区切换）",onClick:J},[de(fe,{name:"pin"}),p("span",null,Se(E.value?"已锁定":"跟随"),1)],10,cg),p("button",{class:Ie(["spm-icon-btn b3-tooltips b3-tooltips__s",{"is-primary":l.value==="pro-cli"}]),"aria-label":l.value==="pro-cli"?"当前：官方原生 Pro 模式 (localhost:"+r.value+")，点击切回沙箱":"当前：内置高保真沙箱，点击切换官方原生 Pro 模式",onClick:M},[de(fe,{name:"rocket"}),p("span",null,Se(l.value==="pro-cli"?"Pro ("+r.value+")":"沙箱"),1)],10,dg)]),p("div",ug,[p("button",{class:Ie(["spm-icon-btn b3-tooltips b3-tooltips__s",{"is-primary":h.value}]),"aria-label":"切换幻灯片大纲抽屉",onClick:A[0]||(A[0]=q=>h.value=!h.value)},[de(fe,{name:"outline"})],2),p("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"缩略图总览 (O)",onClick:C},[de(fe,{name:"columns"})]),p("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"双屏演讲者视图 (Presenter Mode ⌥M)",onClick:j},[de(fe,{name:"presenter"})]),p("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"导出单文件 HTML 演示包",onClick:z},[de(fe,{name:"export-html"})]),p("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"导出 16:9 PDF 演示讲义",onClick:_},[de(fe,{name:"export-pdf"})]),p("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"重新编译并刷新",onClick:N},[de(fe,{name:"refresh"})]),p("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"全屏放映",onClick:g},[de(fe,{name:"fullscreen"})])])]),p("div",{ref_key:"fullscreenContainerRef",ref:a,class:"spm-slidev-tab__viewport spm-slidev-fullscreen-container",onWheel:te},[p("iframe",{ref_key:"sandboxIframeRef",ref:d,class:"spm-slidev-tab__iframe",src:y.value,frameborder:"0",allow:"fullscreen; autoplay"},null,8,fg),de(Zh,{visible:f.value,"onUpdate:visible":A[1]||(A[1]=q=>f.value=q),"is-maximized":v.value,"onUpdate:isMaximized":A[2]||(A[2]=q=>v.value=q),title:T.value,onClose:ae},{default:Dl(()=>[k.value==="siyuan"&&S.value?(oe(),Dt(om,{key:0,"block-id":S.value,title:T.value,plugin:ye(i),onExternalJump:ue},null,8,["block-id","title","plugin"])):Re("",!0),D.value?Tt((oe(),Dt(Om,{key:1,visible:f.value&&k.value==="web",url:$.value,title:T.value,onExternalJump:ue},null,8,["visible","url","title"])),[[ys,k.value==="web"]]):Re("",!0)]),_:1},8,["visible","is-maximized","title"]),Tt(p("div",{class:Ie(["spm-jump-badge",{"is-invalid":V.value}])},Se(W.value),3),[[ys,W.value]])],544),h.value&&u.value.length>0?(oe(),Dt(Fh,{key:0,slides:u.value,"current-active-page":m.value,onNavigate:le,onRefresh:N},null,8,["slides","current-active-page"])):Re("",!0)],32))}}),hg=zt(pg,[["__scopeId","data-v-1d6a7f35"]]),mg={class:"spm-section spm-section--page"},gg={class:"spm-section-header"},vg={key:0,class:"spm-card-control",style:{"border-left":"3px solid var(--b3-theme-primary)",background:"rgba(var(--b3-theme-primary-rgb, 66, 133, 244), 0.06)",padding:"8px 12px","margin-top":"6px"}},bg={style:{display:"flex","align-items":"center","justify-content":"space-between",gap:"8px"}},yg={style:{"font-size":"11px",display:"flex","align-items":"center",gap:"6px",flex:"1"}},kg={key:1,class:"spm-card-control"},wg={class:"spm-control-header"},xg={class:"spm-control-title-group"},Sg={class:"spm-control-title"},_g={class:"spm-quick-chips"},Cg=["onClick"],$g={style:{display:"flex",gap:"6px","align-items":"center","margin-top":"6px"}},Ig=["value"],Eg=["aria-label"],Tg={key:1,class:"spm-icon-btn b3-tooltips b3-tooltips__w",disabled:"",style:{opacity:"0.45",cursor:"not-allowed",padding:"0 8px",height:"26px","font-size":"11px","white-space":"nowrap","flex-shrink":"0"},"aria-label":"当前页未检测到调整过列宽的横向超级块"},Ag={key:0,style:{"margin-top":"6px","font-size":"11px",opacity:"0.85",display:"flex","align-items":"center",gap:"4px"}},Bg={style:{background:"rgba(125, 125, 125, 0.15)",padding:"1px 4px","border-radius":"3px","font-weight":"bold"}},Mg={key:1,style:{"margin-top":"6px","font-size":"11px",opacity:"0.6",display:"flex","align-items":"center",gap:"4px"}},Dg={class:"spm-card-control"},Lg={class:"spm-control-header"},Og={class:"spm-control-title-group"},Rg={class:"spm-control-title"},Pg={class:"spm-segmented-group"},Ng={key:0,style:{"margin-top":"10px",display:"flex","flex-direction":"column",gap:"8px"}},zg={style:{display:"flex","align-items":"center","justify-content":"space-between"}},Fg={class:"b3-tooltips b3-tooltips__w","aria-label":`输入规则：
• 权重比例（项数决定步数）：如 1:1 (2步等分)、1:1:1 (3步等分)、1:2:1 (按权重累计分段)
• 绝对百分比：如 25:75:100 或 30:80 (指定每步展开的累计百分比)
• 每次点击或按空格/向右键展露下一段，全部揭开后翻页`,style:{cursor:"help",opacity:"0.75",display:"inline-flex","align-items":"center",gap:"3px","font-size":"11px"}},Hg={class:"spm-quick-chips"},jg=["onClick"],Wg={class:"b3-tooltips b3-tooltips__n",style:{width:"100%",display:"block"},"aria-label":"输入权重比例（如 1:2:1）或绝对累计百分比断点（如 25:75:100），冒号项数决定点击步数"},Ug=["value"],Vg={style:{display:"flex",gap:"8px","margin-top":"2px"}},Kg={style:{flex:"1"}},qg={class:"spm-segmented-group"},Gg={style:{flex:"1"}},Zg={class:"spm-segmented-group"},Yg={class:"spm-card-control"},Jg={class:"spm-control-header"},Xg={class:"spm-control-title-group"},Qg={class:"spm-control-title"},ev={class:"spm-segmented-group"},tv={class:"spm-card-control"},iv={class:"spm-control-header"},nv={class:"spm-control-title-group"},ov={class:"spm-control-title"},sv={class:"spm-quick-chips"},rv=["onClick"],lv=["value"],av={key:2,class:"spm-card-control"},cv={class:"spm-control-header"},dv={class:"spm-control-title-group"},uv={class:"spm-control-title"},fv={class:"spm-quick-chips"},pv=["onClick"],hv=["value"],mv={class:"spm-card-control"},gv={class:"spm-control-header"},vv={class:"spm-control-title-group"},bv={class:"spm-control-title"},yv={key:0,class:"spm-note-status-box"},kv=["title"],wv={class:"spm-action-grid",style:{"margin-top":"6px"}},xv={key:1,class:"spm-note-empty-box"},Sv={class:"spm-batch-actions-box",style:{"margin-top":"8px","border-top":"1px dashed var(--b3-border-color, #e2e8f0)","padding-top":"8px"}},_v={class:"spm-action-grid"},Cv=["disabled"],$v=["disabled"],Iv={class:"spm-card-control"},Ev={class:"spm-action-grid"},Tv=Ct({__name:"PageInspectorSection",props:{pageLayout:{},pageTransition:{},pageBackground:{},pageSpacing:{},pageImage:{},pageNotes:{},pageIndex:{},pageLayoutRatio:{},pageMask:{},pageMaskRatio:{},pageMaskStyle:{},pageMaskInitial:{},detectedSbRatio:{},detectedSbInfo:{},isBatchProcessing:{type:Boolean}},emits:["update:pageLayout","update:pageTransition","update:pageBackground","update:pageSpacing","update:pageImage","update:pageLayoutRatio","update:pageMask","update:pageMaskRatio","update:pageMaskStyle","update:pageMaskInitial","applySuperBlockLayout","resetSuperblockRatio","addNoteBlock","locateNoteBlock","generateNotes","batchAppendNotes","batchDeleteNotes","insertDividerAfter","deleteDivider"],setup(e,{emit:t}){const i=e,n=t,o=[{label:"1:1 (2步)",value:"1:1"},{label:"1:1:1 (3步)",value:"1:1:1"},{label:"1:2:1 (非等宽)",value:"1:2:1"},{label:"1:1:1:1 (4步)",value:"1:1:1:1"}],s=_e(()=>["two-cols","cols-header","two-cols-header","three-cols-header","image-left","image-right"].includes(i.pageLayout)),l=_e(()=>{var f,v;if(i.pageLayout==="two-cols-header"||i.pageLayout==="two-cols"||i.pageLayout==="image-left"||i.pageLayout==="image-right")return 2;if(i.pageLayout==="three-cols-header")return 3;const u=(i.pageLayoutRatio||"").trim();if(u.includes(":")){const k=u.split(":").filter(Boolean).length;if(k>=2&&k<=6)return k}const h=(i.detectedSbRatio||"").trim();if(h.includes(":")){const k=h.split(":").filter(Boolean).length;if(k>=2&&k<=6)return k}if((f=i.detectedSbInfo)!=null&&f.colCount&&i.detectedSbInfo.colCount>=2)return Math.min(i.detectedSbInfo.colCount,6);if((v=i.detectedSbInfo)!=null&&v.slots&&Array.isArray(i.detectedSbInfo.slots)){const k=i.detectedSbInfo.slots.length;if(k>=2&&k<=6)return k}return 2}),r=_e(()=>{const u=l.value;return u===3?[{label:"默认 1:1:1",value:""},{label:"1:2:1 (主中)",value:"1:2:1"},{label:"2:1:1 (主左)",value:"2:1:1"},{label:"1:1:2 (主右)",value:"1:1:2"},{label:"1:3:1",value:"1:3:1"}]:u===4?[{label:"默认 1:1:1:1",value:""},{label:"1:2:2:1",value:"1:2:2:1"},{label:"2:1:1:2",value:"2:1:1:2"}]:u===5?[{label:"默认 1:1:1:1:1",value:""}]:u===6?[{label:"默认 1:1:1:1:1:1",value:""}]:[{label:"默认 1:1",value:""},{label:"1:2",value:"1:2"},{label:"2:1",value:"2:1"},{label:"3:7",value:"3:7"},{label:"7:3",value:"7:3"},{label:"4:6",value:"4:6"},{label:"6:4",value:"6:4"}]}),a=_e(()=>i.pageLayoutRatio||"");function c(){const u=l.value||2,h=Array(u).fill("1").join(":");n("update:pageLayoutRatio",h),n("resetSuperblockRatio")}const d=_e(()=>{if(!i.pageNotes)return"";const u=i.pageNotes.replace(/[\r\n]+/g," ").trim();return u.length>50?u.slice(0,50)+"...":u}),m=[{label:"默认",value:""},{label:"暗黑 #1e1e24",value:"#1e1e24"},{label:"极夜 #0f172a",value:"#0f172a"},{label:"极简白 #ffffff",value:"#ffffff"}],b=[{label:"默认封面",value:"https://cover.sli.dev"},{label:"清空配图",value:""}];return(u,h)=>(oe(),se("div",mg,[p("div",gg,[p("span",null,"幻灯片页面设置"+Se(e.pageIndex?` (第 ${e.pageIndex} 页)`:""),1)]),de(wa,{"model-value":e.pageLayout,onChange:h[0]||(h[0]=f=>u.$emit("update:pageLayout",f))},null,8,["model-value"]),!s.value&&e.pageLayout!=="clover"&&e.detectedSbRatio?(oe(),se("div",vg,[p("div",bg,[p("div",yg,[de(fe,{name:"sparkles"}),p("span",null,[h[31]||(h[31]=$t("检测到本页横向超级块列宽比例：",-1)),p("b",null,Se(e.detectedSbRatio),1)])]),p("button",{class:"spm-btn-action b3-tooltips b3-tooltips__w","aria-label":"一键将本页版式设为分栏并应用超级块列宽",style:{padding:"2px 8px",height:"26px","font-size":"11px","flex-shrink":"0",background:"var(--b3-theme-primary)",color:"#fff",display:"inline-flex","align-items":"center",gap:"4px"},onClick:h[1]||(h[1]=f=>u.$emit("applySuperBlockLayout",e.detectedSbInfo||{recommendedLayout:"two-cols",ratio:e.detectedSbRatio}))},[de(fe,{name:"columns"}),h[32]||(h[32]=p("span",null,"设为分栏",-1))])])])):Re("",!0),s.value?(oe(),se("div",kg,[p("div",wg,[p("div",xg,[p("div",Sg,[de(fe,{name:"ratio"}),h[33]||(h[33]=p("span",null,"分栏比例 (Ratio)",-1))]),h[34]||(h[34]=p("span",{class:"spm-control-desc"},"设置各列横向空间占比，默认平均分配",-1))])]),p("div",_g,[(oe(!0),se(Ke,null,kt(r.value,f=>(oe(),se("button",{key:f.value,class:Ie(["spm-chip",{active:a.value===f.value}]),onClick:v=>u.$emit("update:pageLayoutRatio",f.value)},Se(f.label),11,Cg))),128))]),p("div",$g,[p("input",{value:e.pageLayoutRatio||"",class:"spm-input",style:{flex:"1","min-width":"0"},placeholder:"自定义比例（如 1:2 或 30:70，留空为默认）",onInput:h[2]||(h[2]=f=>u.$emit("update:pageLayoutRatio",f.target.value)),onChange:h[3]||(h[3]=f=>u.$emit("update:pageLayoutRatio",f.target.value))},null,40,Ig),e.detectedSbRatio?(oe(),se("button",{key:0,class:"spm-icon-btn b3-tooltips b3-tooltips__w","aria-label":`从当前页思源超级块读取实际宽度比例 (${e.detectedSbRatio}) 并应用`,style:{padding:"0 8px",height:"26px","font-size":"11px","white-space":"nowrap","flex-shrink":"0"},onClick:h[4]||(h[4]=f=>u.$emit("update:pageLayoutRatio",e.detectedSbRatio))},[de(fe,{name:"sparkles"}),h[35]||(h[35]=p("span",null,"读取",-1))],8,Eg)):(oe(),se("button",Tg,[de(fe,{name:"sparkles"}),h[36]||(h[36]=p("span",null,"读取",-1))])),p("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__w","aria-label":"重置渲染比例为平均分布，并立即重置文档中超级块内容分布比例",style:{padding:"0 8px",height:"26px","font-size":"11px","white-space":"nowrap","flex-shrink":"0"},onClick:c},[de(fe,{name:"reset"}),h[37]||(h[37]=p("span",null,"重置",-1))])]),e.detectedSbRatio?(oe(),se("div",Ag,[de(fe,{name:"ratio"}),h[38]||(h[38]=p("span",null,"检测到思源超级块宽度：",-1)),p("code",Bg,Se(e.detectedSbRatio),1)])):(oe(),se("div",Mg,[de(fe,{name:"ratio"}),h[39]||(h[39]=p("span",null,"未检测到调宽超级块（默认各列平均分配）",-1))]))])):Re("",!0),de(Js,{"model-value":e.pageTransition,onChange:h[5]||(h[5]=f=>u.$emit("update:pageTransition",f))},null,8,["model-value"]),p("div",Dg,[p("div",Lg,[p("div",Og,[p("div",Rg,[de(fe,{name:"sparkles"}),h[40]||(h[40]=p("span",null,"页面动态蒙版 (Dynamic Mask)",-1))]),h[41]||(h[41]=p("span",{class:"spm-control-desc"},"随着点击操作分段展露正文内容",-1))])]),p("div",Pg,[p("button",{class:Ie(["spm-segmented-item",{active:!e.pageMask}]),onClick:h[6]||(h[6]=f=>u.$emit("update:pageMask",""))}," 关闭 ",2),p("button",{class:Ie(["spm-segmented-item",{active:e.pageMask==="down"}]),onClick:h[7]||(h[7]=f=>u.$emit("update:pageMask","down"))}," 从上至下 ",2),p("button",{class:Ie(["spm-segmented-item",{active:e.pageMask==="right"}]),onClick:h[8]||(h[8]=f=>u.$emit("update:pageMask","right"))}," 从左至右 ",2)]),e.pageMask?(oe(),se("div",Ng,[p("div",zg,[h[43]||(h[43]=p("div",{style:{"font-size":"11px",opacity:"0.85","font-weight":"500"}},"展露比例 / 断点",-1)),p("span",Fg,[de(fe,{name:"help"}),h[42]||(h[42]=p("span",null,"输入规则",-1))])]),p("div",Hg,[(oe(),se(Ke,null,kt(o,f=>p("button",{key:f.value,class:Ie(["spm-chip",{active:(e.pageMaskRatio||"1:1")===f.value}]),onClick:v=>u.$emit("update:pageMaskRatio",f.value)},Se(f.label),11,jg)),64))]),p("div",Wg,[p("input",{value:e.pageMaskRatio||"1:1",class:"spm-input",style:{width:"100%"},placeholder:"自定义比例或断点（如 1:2:1 或 25:75:100）",onInput:h[9]||(h[9]=f=>u.$emit("update:pageMaskRatio",f.target.value)),onChange:h[10]||(h[10]=f=>u.$emit("update:pageMaskRatio",f.target.value))},null,40,Ug)]),h[46]||(h[46]=p("div",{style:{"font-size":"10.5px",opacity:"0.6","line-height":"1.35","margin-top":"-2px"}}," 提示：支持权重比（如 1:2:1）或绝对断点（如 25:75:100），冒号项数决定点击步数 ",-1)),p("div",Vg,[p("div",Kg,[h[44]||(h[44]=p("div",{style:{"font-size":"11px",opacity:"0.85","margin-bottom":"4px"}},"遮盖质感",-1)),p("div",qg,[p("button",{class:Ie(["spm-segmented-item",{active:!e.pageMaskStyle||e.pageMaskStyle==="solid"}]),onClick:h[11]||(h[11]=f=>u.$emit("update:pageMaskStyle","solid"))}," 背景同色 ",2),p("button",{class:Ie(["spm-segmented-item",{active:e.pageMaskStyle==="blur"}]),onClick:h[12]||(h[12]=f=>u.$emit("update:pageMaskStyle","blur"))}," 磨砂毛玻璃 ",2)])]),p("div",Gg,[h[45]||(h[45]=p("div",{style:{"font-size":"11px",opacity:"0.85","margin-bottom":"4px"}},"初始展露",-1)),p("div",Zg,[p("button",{class:Ie(["spm-segmented-item",{active:!e.pageMaskInitial||e.pageMaskInitial==="hidden"}]),onClick:h[13]||(h[13]=f=>u.$emit("update:pageMaskInitial","hidden"))}," 完全遮盖 ",2),p("button",{class:Ie(["spm-segmented-item",{active:e.pageMaskInitial==="revealed"}]),onClick:h[14]||(h[14]=f=>u.$emit("update:pageMaskInitial","revealed"))}," 首段可见 ",2)])])])])):Re("",!0)]),p("div",Yg,[p("div",Jg,[p("div",Xg,[p("div",Qg,[de(fe,{name:"ratio"}),h[47]||(h[47]=p("span",null,"页面间距 (Spacing)",-1))]),h[48]||(h[48]=p("span",{class:"spm-control-desc"},"覆盖本页内边距与顶部标题间距",-1))])]),p("div",ev,[p("button",{class:Ie(["spm-segmented-item",{active:!e.pageSpacing||e.pageSpacing==="inherit"}]),onClick:h[15]||(h[15]=f=>u.$emit("update:pageSpacing","inherit"))}," 继承全局 ",2),p("button",{class:Ie(["spm-segmented-item",{active:e.pageSpacing==="compact"}]),onClick:h[16]||(h[16]=f=>u.$emit("update:pageSpacing","compact"))}," 紧凑 ",2),p("button",{class:Ie(["spm-segmented-item",{active:e.pageSpacing==="normal"}]),onClick:h[17]||(h[17]=f=>u.$emit("update:pageSpacing","normal"))}," 标准 ",2),p("button",{class:Ie(["spm-segmented-item",{active:e.pageSpacing==="loose"}]),onClick:h[18]||(h[18]=f=>u.$emit("update:pageSpacing","loose"))}," 宽松 ",2)])]),p("div",tv,[p("div",iv,[p("div",nv,[p("div",ov,[de(fe,{name:"palette"}),h[49]||(h[49]=p("span",null,"页面背景 (Background)",-1))]),h[50]||(h[50]=p("span",{class:"spm-control-desc"},"设置当前页特定底色或壁纸",-1))])]),p("div",sv,[(oe(),se(Ke,null,kt(m,f=>p("button",{key:f.value,class:Ie(["spm-chip",{active:e.pageBackground===f.value}]),onClick:v=>u.$emit("update:pageBackground",f.value)},Se(f.label),11,rv)),64))]),p("input",{value:e.pageBackground,class:"spm-input",placeholder:"自定义颜色代码或资源路径",onInput:h[19]||(h[19]=f=>u.$emit("update:pageBackground",f.target.value)),onChange:h[20]||(h[20]=f=>u.$emit("update:pageBackground",f.target.value))},null,40,lv)]),e.pageLayout==="image-right"||e.pageLayout==="image-left"||e.pageImage?(oe(),se("div",av,[p("div",cv,[p("div",dv,[p("div",uv,[de(fe,{name:"image"}),h[51]||(h[51]=p("span",null,"页面图片 (Image)",-1))]),h[52]||(h[52]=p("span",{class:"spm-control-desc"},"图文分栏或页面专属配图 URL / 资源路径",-1))])]),p("div",fv,[(oe(),se(Ke,null,kt(b,f=>p("button",{key:f.value,class:Ie(["spm-chip",{active:e.pageImage===f.value}]),onClick:v=>u.$emit("update:pageImage",f.value)},Se(f.label),11,pv)),64))]),p("input",{value:e.pageImage,class:"spm-input",placeholder:"网络图片 URL (如 https://cover.sli.dev) 或 assets/...",onInput:h[21]||(h[21]=f=>u.$emit("update:pageImage",f.target.value)),onChange:h[22]||(h[22]=f=>u.$emit("update:pageImage",f.target.value))},null,40,hv)])):Re("",!0),p("div",mv,[p("div",gv,[p("div",vv,[p("div",bv,[de(fe,{name:"presenter"}),h[53]||(h[53]=p("span",null,"演讲者提词 (Notes)",-1))]),h[54]||(h[54]=p("span",{class:"spm-control-desc"},"正文备注块驱动 · 仅演讲者视图可见",-1))]),p("button",{class:"spm-btn-text b3-tooltips b3-tooltips__w","aria-label":"AI 自动生成本页讲稿提示块",onClick:h[23]||(h[23]=f=>u.$emit("generateNotes"))},[de(fe,{name:"sparkles"}),h[55]||(h[55]=p("span",null,"AI 讲稿",-1))])]),e.pageNotes?(oe(),se("div",yv,[h[58]||(h[58]=p("div",{class:"spm-note-status-badge"},[p("span",{class:"spm-badge-dot"}),p("span",null,"已配置正文讲稿")],-1)),p("div",{class:"spm-note-preview-text",title:e.pageNotes},Se(d.value),9,kv),p("div",wv,[p("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"在正文编辑区定位并高亮此讲稿备注块",onClick:h[24]||(h[24]=f=>u.$emit("locateNoteBlock"))},[de(fe,{name:"search"}),h[56]||(h[56]=p("span",null,"定位讲稿块",-1))]),p("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"在本页末尾追加新的讲稿提示块",onClick:h[25]||(h[25]=f=>u.$emit("addNoteBlock"))},[de(fe,{name:"insert-below"}),h[57]||(h[57]=p("span",null,"追加讲稿块",-1))])])])):(oe(),se("div",xv,[h[60]||(h[60]=p("div",{class:"spm-note-empty-hint"},"本页暂无讲稿备注块",-1)),p("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s",style:{width:"100%","margin-top":"6px"},"aria-label":"在当前页末尾插入默认演讲备注提示块",onClick:h[26]||(h[26]=f=>u.$emit("addNoteBlock"))},[de(fe,{name:"insert-below"}),h[59]||(h[59]=p("span",null,"添加讲稿备注块",-1))])])),p("div",Sv,[p("div",_v,[p("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s",disabled:e.isBatchProcessing,style:An(e.isBatchProcessing?"opacity: 0.5; cursor: not-allowed;":""),"aria-label":"在所有尚未配置讲稿的页面末尾批量追加讲稿提示块",onClick:h[27]||(h[27]=f=>u.$emit("batchAppendNotes"))},[de(fe,{name:"insert-below"}),h[61]||(h[61]=p("span",null,"全部追加",-1))],12,Cv),p("button",{class:"spm-btn-action spm-btn-danger b3-tooltips b3-tooltips__s",disabled:e.isBatchProcessing,style:An(e.isBatchProcessing?"opacity: 0.5; cursor: not-allowed;":""),"aria-label":"批量物理删除正文中的全部讲稿备注块（涉及全部页）",onClick:h[28]||(h[28]=f=>u.$emit("batchDeleteNotes"))},[de(fe,{name:"trash"}),h[62]||(h[62]=p("span",null,"全部删除",-1))],12,$v)])])]),p("div",Iv,[h[65]||(h[65]=p("div",{class:"spm-control-header"},[p("div",{class:"spm-control-title-group"},[p("span",{class:"spm-control-title"},"分页快捷操作")])],-1)),p("div",Ev,[p("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"在此分页符之后插入新的空白分页",onClick:h[29]||(h[29]=f=>u.$emit("insertDividerAfter"))},[de(fe,{name:"insert-below"}),h[63]||(h[63]=p("span",null,"插入新页",-1))]),p("button",{class:"spm-btn-action spm-btn-danger b3-tooltips b3-tooltips__s","aria-label":"彻底删除当前分页符（合并前后页面）",onClick:h[30]||(h[30]=f=>u.$emit("deleteDivider"))},[de(fe,{name:"trash"}),h[64]||(h[64]=p("span",null,"删除此页",-1))])])])]))}}),Av=zt(Tv,[["__scopeId","data-v-1f9d4630"]]),Bv={class:"spm-section spm-section--block"},Mv={key:0,class:"spm-card-control",style:{"border-left":"3px solid var(--b3-theme-primary)"}},Dv={class:"spm-control-header"},Lv={class:"spm-control-title-group"},Ov={class:"spm-control-title"},Rv={style:{background:"var(--b3-theme-surface)",border:"1px solid var(--b3-theme-surface-lighter)","border-radius":"6px",padding:"10px","margin-bottom":"8px"}},Pv={style:{display:"flex","align-items":"center","justify-content":"space-between","margin-bottom":"4px"}},Nv={style:{"font-size":"12px","font-weight":"500",display:"flex","align-items":"center",gap:"4px"}},zv={key:0},Fv={key:1},Hv={style:{background:"rgba(var(--b3-theme-primary-rgb, 59, 130, 246), 0.16)",color:"var(--b3-theme-primary)",border:"1px solid rgba(var(--b3-theme-primary-rgb, 59, 130, 246), 0.3)",padding:"2px 6px","border-radius":"4px","font-weight":"bold","font-size":"12px"}},jv={style:{"font-size":"11px",opacity:"0.75","line-height":"1.4"}},Wv={class:"spm-action-grid"},Uv={class:"spm-card-control"},Vv={class:"spm-control-header"},Kv={class:"spm-control-title-group"},qv={class:"spm-control-title"},Gv=["aria-label"],Zv=["checked"],Yv={key:1,class:"spm-card-control"},Jv={class:"spm-control-header"},Xv={class:"spm-control-title-group"},Qv={class:"spm-control-title"},eb={class:"spm-quick-chips"},tb={key:2,class:"spm-card-control"},ib={class:"spm-control-header"},nb={class:"spm-control-title-group"},ob={class:"spm-control-title"},sb={class:"spm-video-settings-grid",style:{display:"grid","grid-template-columns":"1fr 1fr",gap:"8px","margin-top":"8px"}},rb={class:"spm-toggle-item",style:{display:"flex","align-items":"center","justify-content":"space-between",padding:"4px 6px",background:"rgba(125,125,125,0.06)","border-radius":"4px"}},lb={style:{"font-size":"11px",display:"inline-flex","align-items":"center",gap:"4px"}},ab=["aria-label"],cb=["checked"],db={class:"spm-toggle-item",style:{display:"flex","align-items":"center","justify-content":"space-between",padding:"4px 6px",background:"rgba(125,125,125,0.06)","border-radius":"4px"}},ub={style:{"font-size":"11px",display:"inline-flex","align-items":"center",gap:"4px"}},fb=["aria-label"],pb=["checked"],hb={class:"spm-toggle-item",style:{display:"flex","align-items":"center","justify-content":"space-between",padding:"4px 6px",background:"rgba(125,125,125,0.06)","border-radius":"4px"}},mb={style:{"font-size":"11px",display:"inline-flex","align-items":"center",gap:"4px"}},gb=["aria-label"],vb=["checked"],bb={class:"spm-toggle-item",style:{display:"flex","align-items":"center","justify-content":"space-between",padding:"4px 6px",background:"rgba(125,125,125,0.06)","border-radius":"4px"}},yb={style:{"font-size":"11px",display:"inline-flex","align-items":"center",gap:"4px"}},kb=["aria-label"],wb=["checked"],xb={class:"spm-card-control"},Sb={class:"spm-control-header"},_b={class:"spm-control-title-group"},Cb={class:"spm-control-title"},$b=["aria-label"],Ib=["checked"],Eb={key:0,class:"spm-quick-chips"},Tb=["onClick"],Ab={key:1,class:"spm-inherit-tip",style:{"margin-top":"6px",padding:"4px 8px",background:"rgba(var(--b3-theme-primary-rgb, 59, 130, 246), 0.08)","border-radius":"4px","font-size":"11px",opacity:"0.85",display:"flex","align-items":"center",gap:"4px"}},Bb={class:"spm-card-control"},Mb={class:"spm-control-header"},Db={class:"spm-control-title-group"},Lb={class:"spm-control-title"},Ob=["aria-label"],Rb=["checked"],Pb={key:0,class:"spm-quick-chips"},Nb=["onClick"],zb={key:1,class:"spm-motion-details",style:{display:"flex","flex-direction":"column",gap:"4px","margin-top":"4px"}},Fb={style:{display:"flex",gap:"8px","justify-content":"space-between","font-size":"11px",opacity:"0.8"}},Hb={style:{display:"flex",gap:"6px"}},jb=["value"],Wb=["value"],Ub={key:3,class:"spm-card-control"},Vb={class:"spm-control-header"},Kb={class:"spm-control-title-group"},qb={class:"spm-control-title"},Gb={class:"spm-control-desc"},Zb={class:"spm-segmented-group"},Yb=["onClick"],Jb={key:4,class:"spm-card-control"},Xb={class:"spm-control-header"},Qb={class:"spm-control-title-group"},e1={class:"spm-control-title"},t1={class:"spm-quick-chips"},i1=["onClick"],n1=["value"],o1={key:5,class:"spm-card-control"},s1={class:"spm-control-header"},r1={class:"spm-control-title-group"},l1={class:"spm-control-title"},a1={class:"spm-quick-chips"},c1=["onClick"],d1=["value"],u1={class:"spm-card-control"},f1={class:"spm-action-grid"},p1=["aria-label"],h1=Ct({__name:"BlockInspectorSection",props:{elemClick:{},elemMotion:{},elemSlot:{},elemShikiLines:{},elemMaxHeight:{},isCodeBlock:{type:Boolean},isImage:{type:Boolean},isVideo:{type:Boolean},videoAutoplay:{type:Boolean},videoLoop:{type:Boolean},videoMuted:{type:Boolean},videoControls:{type:Boolean},hasBlockAttrs:{type:Boolean},isNote:{type:Boolean},imageRole:{},currentSlideLayout:{},isSuperBlock:{type:Boolean},parentElemClick:{},parentContainerSlot:{},parentContainerId:{},detectedSbInfo:{}},emits:["toggleNote","toggleElemClick","update:elemClick","update:elemMotion","update:elemSlot","update:elemShikiLines","update:elemMaxHeight","applySuperBlockLayout","applySuperBlockRatio","insertDividerBefore","insertDividerAfter","setTwoColsContrast","clearBlockAttrs","update:imageRole","toggleVideoAutoplay","toggleVideoLoop","toggleVideoMuted","toggleVideoControls"],setup(e,{emit:t}){const i=e,n=_e(()=>{const E=i.currentSlideLayout||"";return["col-1","col-2","col-3","col-4","col-5","col-6"].includes(i.elemSlot)?"cols-header":E}),o=_e(()=>{const E=n.value;return["two-cols","cols-header","two-cols-header","three-cols-header"].includes(E)}),s=_e(()=>{var x,W,V,G;if((x=i.detectedSbInfo)!=null&&x.colCount&&i.detectedSbInfo.colCount>=2)return Math.min(i.detectedSbInfo.colCount,6);const E=(W=i.elemSlot)==null?void 0:W.match(/^col-(\d+)$/);if(E){const X=parseInt(E[1],10);if(X>=2&&X<=6)return Math.max(X,3)}if(i.currentSlideLayout==="three-cols-header")return 3;if(i.currentSlideLayout==="two-cols-header"||i.currentSlideLayout==="two-cols")return 2;if((G=(V=i.detectedSbInfo)==null?void 0:V.ratio)!=null&&G.includes(":")){const X=i.detectedSbInfo.ratio.split(":").filter(Boolean);if(X.length>=2)return Math.min(X.length,6)}return 3}),l=_e(()=>{const E=n.value;return E==="cols-header"?"多栏插槽归属 (Slot)":E==="three-cols-header"?"三栏插槽归属 (Slot)":E==="two-cols-header"?"带表头双栏插槽 (Slot)":"多栏插槽归属 (Slot)"}),r=_e(()=>{const E=n.value;return E==="cols-header"?`在 cols-header 表头多栏（${s.value} 栏）中的内容块位置`:E==="three-cols-header"?"在 three-cols-header 版式中的内容块位置":E==="two-cols-header"?"在 two-cols-header 版式中的内容块位置":E==="two-cols"?"在 two-cols 双栏版式中的归属":"在当前分栏版式中的内容块位置"}),a=_e(()=>{const E=n.value;if(E==="two-cols")return[{value:"",label:"默认 (左)"},{value:"right",label:"右栏"}];if(E==="two-cols-header")return[{value:"",label:"默认"},{value:"header",label:"表头"},{value:"left",label:"左栏"},{value:"right",label:"右栏"}];if(E==="three-cols-header")return[{value:"",label:"默认"},{value:"header",label:"表头"},{value:"col-1",label:"第 1 栏"},{value:"col-2",label:"第 2 栏"},{value:"col-3",label:"第 3 栏"}];const x=s.value,W=[{value:"",label:"默认"},{value:"header",label:"表头"}];for(let V=1;V<=x;V++)W.push({value:`col-${V}`,label:`第 ${V} 栏`});return W});function c(E){const x=i.elemSlot||"";return E?x===E||E==="col-1"&&x==="left"||E==="col-2"&&x==="center"||E==="col-3"&&x==="right"&&s.value===3||E==="col-2"&&x==="right"&&s.value===2||E==="left"&&x==="col-1"||E==="right"&&(x==="col-2"||x==="col-3"):!x||x==="default"}const d=t,m=[{label:"上浮 (slide-up)",value:"slide-up"},{label:"淡入 (fade-in)",value:"fade-in"},{label:"下沉 (slide-down)",value:"slide-down"},{label:"左滑 (slide-left)",value:"slide-left"},{label:"右滑 (slide-right)",value:"slide-right"},{label:"缩放 (zoom-in)",value:"zoom-in"},{label:"弹性 (bounce)",value:"bounce"}],b=_e(()=>{if(!i.elemMotion||i.elemMotion.trim()===""||i.elemMotion.trim()==="none")return null;try{const E=JSON.parse(i.elemMotion);if(typeof E=="object"&&E!==null)return{preset:E.preset||E.type||"slide-up",duration:typeof E.duration=="number"?E.duration:0,delay:typeof E.delay=="number"?E.delay:0}}catch{}return{preset:i.elemMotion.trim(),duration:0,delay:0}}),u=_e(()=>!!b.value),h=_e(()=>{var E;return((E=b.value)==null?void 0:E.preset)||"slide-up"}),f=_e(()=>{var E;return((E=b.value)==null?void 0:E.duration)||0}),v=_e(()=>{var E;return((E=b.value)==null?void 0:E.delay)||0});function k(){u.value?d("update:elemMotion",""):d("update:elemMotion","slide-up")}function S(E){D(E,f.value,v.value)}function $(E){D(h.value,E,v.value)}function T(E){D(h.value,f.value,E)}function D(E,x,W){if(!E||E==="none"){d("update:elemMotion","");return}if(!x&&!W){d("update:elemMotion",E);return}const V={preset:E};x>0&&(V.duration=x),W>0&&(V.delay=W),d("update:elemMotion",JSON.stringify(V))}return(E,x)=>{var W,V,G,X,C,P;return oe(),se("div",Bv,[x[62]||(x[62]=p("div",{class:"spm-section-header"},[p("span",null,"元素动效与排版")],-1)),e.isSuperBlock||(W=e.detectedSbInfo)!=null&&W.hasSuperBlock?(oe(),se("div",Mv,[p("div",Dv,[p("div",Lv,[p("div",Ov,[de(fe,{name:"ratio"}),x[24]||(x[24]=p("span",null,"超级块列宽与布局",-1))]),x[25]||(x[25]=p("span",{class:"spm-control-desc"},"读取思源超级块列宽并一键同步到幻灯片分栏",-1))])]),p("div",Rv,[p("div",Pv,[p("div",Nv,[de(fe,{name:"ratio"}),(V=e.detectedSbInfo)!=null&&V.isCustomWidth?(oe(),se("span",zv,"已识别自定义列宽比例")):(oe(),se("span",Fv,"识别到 "+Se(((G=e.detectedSbInfo)==null?void 0:G.colCount)||2)+" 列超级块分栏",1))]),p("code",Hv,Se(((X=e.detectedSbInfo)==null?void 0:X.ratio)||"1:1"),1)]),p("div",jv,Se((C=e.detectedSbInfo)!=null&&C.isCustomWidth?"检测到已调节子块宽度，可一键应用为当前页分栏比例。":"当前超级块子列为思源默认均宽，可在思源中拖动调节或直接应用。"),1)]),p("div",Wv,[p("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"一键将当前页版式切换为对应双栏/三栏，并写入此列宽比例",style:{background:"rgba(var(--b3-theme-primary-rgb, 59, 130, 246), 0.16)",color:"var(--b3-theme-primary)","font-weight":"500",border:"1px solid rgba(var(--b3-theme-primary-rgb, 59, 130, 246), 0.3)"},onClick:x[0]||(x[0]=y=>E.$emit("applySuperBlockLayout",e.detectedSbInfo))},[de(fe,{name:"sparkles"}),x[26]||(x[26]=p("span",null,"应用版式与比例",-1))]),p("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"仅将提取的比值写入当前页的分栏比例属性",onClick:x[1]||(x[1]=y=>{var O;return E.$emit("applySuperBlockRatio",((O=e.detectedSbInfo)==null?void 0:O.ratio)||"1:1")})},[de(fe,{name:"check"}),p("span",null,"应用比例 ("+Se(((P=e.detectedSbInfo)==null?void 0:P.ratio)||"1:1")+")",1)])])])):Re("",!0),p("div",Uv,[p("div",Vv,[p("div",Kv,[p("div",qv,[de(fe,{name:"presenter"}),x[27]||(x[27]=p("span",null,"设为讲稿备注",-1))]),x[28]||(x[28]=p("span",{class:"spm-control-desc"},"作为当前页演讲提词，不在幻灯片中渲染",-1))]),p("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":e.isNote?"取消讲稿备注":"设为讲稿备注"},[p("input",{type:"checkbox",checked:!!e.isNote,onChange:x[2]||(x[2]=y=>E.$emit("toggleNote"))},null,40,Zv),x[29]||(x[29]=p("span",{class:"spm-switch-slider"},null,-1))],8,Gv)])]),e.isImage||e.imageRole?(oe(),se("div",Yv,[p("div",Jv,[p("div",Xv,[p("div",Qv,[de(fe,{name:"image"}),x[30]||(x[30]=p("span",null,"图片角色与分栏 (Image & Layout)",-1))]),x[31]||(x[31]=p("span",{class:"spm-control-desc"},"设为幻灯片背景图或图文分栏配图",-1))])]),p("div",eb,[p("button",{class:Ie(["spm-chip",{active:!e.imageRole}]),onClick:x[3]||(x[3]=y=>E.$emit("update:imageRole",""))}," 普通内容 ",2),p("button",{class:Ie(["spm-chip",{active:e.imageRole==="background"}]),onClick:x[4]||(x[4]=y=>E.$emit("update:imageRole","background"))},[de(fe,{name:"image"}),x[32]||(x[32]=p("span",null,"背景图",-1))],2),p("button",{class:Ie(["spm-chip",{active:e.imageRole==="image-left"}]),onClick:x[5]||(x[5]=y=>E.$emit("update:imageRole","image-left"))},[de(fe,{name:"image-left"}),x[33]||(x[33]=p("span",null,"图左",-1))],2),p("button",{class:Ie(["spm-chip",{active:e.imageRole==="image-right"}]),onClick:x[6]||(x[6]=y=>E.$emit("update:imageRole","image-right"))},[de(fe,{name:"image-right"}),x[34]||(x[34]=p("span",null,"图右",-1))],2)])])):Re("",!0),e.isVideo?(oe(),se("div",tb,[p("div",ib,[p("div",nb,[p("div",ob,[de(fe,{name:"video"}),x[35]||(x[35]=p("span",null,"视频播放设置 (Video Playback)",-1))]),x[36]||(x[36]=p("span",{class:"spm-control-desc"},"配置播放器控制条、自动播放与循环",-1))])]),p("div",sb,[p("div",rb,[p("span",lb,[de(fe,{name:"sliders"}),x[37]||(x[37]=$t(" 控制条",-1))]),p("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":e.videoControls?"关闭控制条":"开启控制条"},[p("input",{type:"checkbox",checked:!!e.videoControls,onChange:x[7]||(x[7]=y=>E.$emit("toggleVideoControls"))},null,40,cb),x[38]||(x[38]=p("span",{class:"spm-switch-slider"},null,-1))],8,ab)]),p("div",db,[p("span",ub,[de(fe,{name:"video"}),x[39]||(x[39]=$t(" 自动播放",-1))]),p("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":e.videoAutoplay?"关闭自动播放":"开启自动播放"},[p("input",{type:"checkbox",checked:!!e.videoAutoplay,onChange:x[8]||(x[8]=y=>E.$emit("toggleVideoAutoplay"))},null,40,pb),x[40]||(x[40]=p("span",{class:"spm-switch-slider"},null,-1))],8,fb)]),p("div",hb,[p("span",mb,[de(fe,{name:"repeat"}),x[41]||(x[41]=$t(" 循环播放",-1))]),p("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":e.videoLoop?"关闭循环播放":"开启循环播放"},[p("input",{type:"checkbox",checked:!!e.videoLoop,onChange:x[9]||(x[9]=y=>E.$emit("toggleVideoLoop"))},null,40,vb),x[42]||(x[42]=p("span",{class:"spm-switch-slider"},null,-1))],8,gb)]),p("div",bb,[p("span",yb,[de(fe,{name:"volume-x"}),x[43]||(x[43]=$t(" 静音播放",-1))]),p("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":e.videoMuted?"关闭静音":"开启静音"},[p("input",{type:"checkbox",checked:!!e.videoMuted,onChange:x[10]||(x[10]=y=>E.$emit("toggleVideoMuted"))},null,40,wb),x[44]||(x[44]=p("span",{class:"spm-switch-slider"},null,-1))],8,kb)])])])):Re("",!0),p("div",xb,[p("div",Sb,[p("div",_b,[p("div",Cb,[de(fe,{name:"step"}),x[45]||(x[45]=p("span",null,"逐步呈现 (v-click)",-1))]),x[46]||(x[46]=p("span",{class:"spm-control-desc"},"放映时按步长逐个呈现",-1))]),p("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":e.elemClick?"关闭逐步呈现":"开启逐步呈现 (+1)"},[p("input",{type:"checkbox",checked:!!e.elemClick,onChange:x[11]||(x[11]=y=>E.$emit("toggleElemClick"))},null,40,Ib),x[47]||(x[47]=p("span",{class:"spm-switch-slider"},null,-1))],8,$b)]),e.elemClick?(oe(),se("div",Eb,[(oe(),se(Ke,null,kt(["+1","1","2","hide"],y=>p("button",{key:y,class:Ie(["spm-chip",{active:e.elemClick===y}]),onClick:O=>E.$emit("update:elemClick",y)},Se(y==="+1"?"顺延 (+1)":y==="hide"?"隐藏 (hide)":"第 "+y+" 步"),11,Tb)),64))])):e.parentElemClick?(oe(),se("div",Ab,[de(fe,{name:"check"}),x[48]||(x[48]=p("span",null,"未单独开启逐步呈现：当前跟随整栏同时出现",-1))])):Re("",!0)]),p("div",Bb,[p("div",Mb,[p("div",Db,[p("div",Lb,[de(fe,{name:"motion"}),x[49]||(x[49]=p("span",null,"入场微动效 (v-motion)",-1))]),x[50]||(x[50]=p("span",{class:"spm-control-desc"},"为当前块添加平滑位移与渐入动画",-1))]),p("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":u.value?"关闭微动效":"开启微动效 (slide-up)"},[p("input",{type:"checkbox",checked:u.value,onChange:k},null,40,Rb),x[51]||(x[51]=p("span",{class:"spm-switch-slider"},null,-1))],8,Ob)]),u.value?(oe(),se("div",Pb,[(oe(),se(Ke,null,kt(m,y=>p("button",{key:y.value,class:Ie(["spm-chip",{active:h.value===y.value}]),onClick:O=>S(y.value)},Se(y.label),11,Nb)),64))])):Re("",!0),u.value?(oe(),se("div",zb,[p("div",Fb,[p("span",null,"时长: "+Se(f.value?f.value+"ms":"默认 (450ms)"),1),p("span",null,"延迟: "+Se(v.value?v.value+"ms":"0ms"),1)]),p("div",Hb,[p("select",{class:"spm-select",style:{flex:"1"},value:f.value,onChange:x[12]||(x[12]=y=>$(Number(y.target.value)))},[...x[52]||(x[52]=[p("option",{value:0},"默认耗时",-1),p("option",{value:200},"极速 (200ms)",-1),p("option",{value:350},"较快 (350ms)",-1),p("option",{value:500},"平滑 (500ms)",-1),p("option",{value:800},"缓慢 (800ms)",-1)])],40,jb),p("select",{class:"spm-select",style:{flex:"1"},value:v.value,onChange:x[13]||(x[13]=y=>T(Number(y.target.value)))},[...x[53]||(x[53]=[p("option",{value:0},"无延迟",-1),p("option",{value:150},"延迟 150ms",-1),p("option",{value:300},"延迟 300ms",-1),p("option",{value:500},"延迟 500ms",-1)])],40,Wb)])])):Re("",!0)]),o.value||e.elemSlot?(oe(),se("div",Ub,[p("div",Vb,[p("div",Kb,[p("div",qb,[de(fe,{name:"columns"}),p("span",null,Se(l.value),1)]),p("span",Gb,Se(r.value),1)])]),p("div",Zb,[(oe(!0),se(Ke,null,kt(a.value,y=>(oe(),se("button",{key:y.value,class:Ie(["spm-segmented-item",{active:c(y.value)}]),onClick:O=>E.$emit("update:elemSlot",y.value)},Se(y.label),11,Yb))),128))])])):Re("",!0),e.isCodeBlock?(oe(),se("div",Jb,[p("div",Xb,[p("div",Qb,[p("div",e1,[de(fe,{name:"code"}),x[54]||(x[54]=p("span",null,"代码逐行聚光 (Shiki)",-1))]),x[55]||(x[55]=p("span",{class:"spm-control-desc"},"翻页时动态聚光高亮特定行",-1))])]),p("div",t1,[(oe(),se(Ke,null,kt(["1-3","all","1|2|3","2-5"],y=>p("button",{key:y,class:Ie(["spm-chip",{active:e.elemShikiLines===y}]),onClick:O=>E.$emit("update:elemShikiLines",y)},Se(y),11,i1)),64)),e.elemShikiLines?(oe(),se("button",{key:0,class:"spm-chip spm-chip-clear",onClick:x[14]||(x[14]=y=>E.$emit("update:elemShikiLines",""))}," 清空 ")):Re("",!0)]),p("input",{value:e.elemShikiLines,class:"spm-input",placeholder:"自定义高亮区间，如 1-3|5|all",onInput:x[15]||(x[15]=y=>E.$emit("update:elemShikiLines",y.target.value)),onChange:x[16]||(x[16]=y=>E.$emit("update:elemShikiLines",y.target.value))},null,40,n1)])):Re("",!0),e.isCodeBlock?(oe(),se("div",o1,[p("div",s1,[p("div",r1,[p("div",l1,[de(fe,{name:"code"}),x[56]||(x[56]=p("span",null,"代码块限高 (Max Height)",-1))]),x[57]||(x[57]=p("span",{class:"spm-control-desc"},"超出限高自动竖向滚动，弱提示滚动条",-1))])]),p("div",a1,[(oe(),se(Ke,null,kt(["240px","320px","400px","50vh"],y=>p("button",{key:y,class:Ie(["spm-chip",{active:e.elemMaxHeight===y}]),onClick:O=>E.$emit("update:elemMaxHeight",y)},Se(y),11,c1)),64)),e.elemMaxHeight?(oe(),se("button",{key:0,class:"spm-chip spm-chip-clear",onClick:x[17]||(x[17]=y=>E.$emit("update:elemMaxHeight",""))}," 自适应 ")):Re("",!0)]),p("input",{value:e.elemMaxHeight,class:"spm-input",placeholder:"自适应高度，或输入 350px、50vh",onInput:x[18]||(x[18]=y=>E.$emit("update:elemMaxHeight",y.target.value)),onChange:x[19]||(x[19]=y=>E.$emit("update:elemMaxHeight",y.target.value))},null,40,d1)])):Re("",!0),p("div",u1,[x[61]||(x[61]=p("div",{class:"spm-control-header"},[p("div",{class:"spm-control-title-group"},[p("span",{class:"spm-control-title"},"快捷操作")])],-1)),p("div",f1,[p("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"在当前块上方插入幻灯片分页线 (---)",onClick:x[20]||(x[20]=y=>E.$emit("insertDividerBefore"))},[de(fe,{name:"insert-above"}),x[58]||(x[58]=p("span",null,"上方分页",-1))]),p("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"在当前块下方插入幻灯片分页线 (---)",onClick:x[21]||(x[21]=y=>E.$emit("insertDividerAfter"))},[de(fe,{name:"insert-below"}),x[59]||(x[59]=p("span",null,"下方分页",-1))]),p("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":n.value==="three-cols-header"?"将当前块属性设为三栏第1栏归属 (slot: col-1)":"将当前块属性设为双栏左侧归属 (slot: left)",onClick:x[22]||(x[22]=y=>E.$emit("setTwoColsContrast"))},[de(fe,{name:"columns"}),p("span",null,Se(n.value==="three-cols-header"?"设为第1栏":"设为双栏"),1)],8,p1),e.hasBlockAttrs?(oe(),se("button",{key:0,class:"spm-btn-action spm-btn-danger b3-tooltips b3-tooltips__s","aria-label":"一键移除本块所有 custom-slidev 属性",onClick:x[23]||(x[23]=y=>E.$emit("clearBlockAttrs"))},[de(fe,{name:"broom"}),x[60]||(x[60]=p("span",null,"清除属性",-1))])):Re("",!0)])])])}}}),m1={class:"spm-section spm-section--doc"},g1={class:"spm-card-control"},v1={class:"spm-control-header"},b1={class:"spm-control-title-group"},y1={class:"spm-control-title"},k1={class:"spm-segmented-group"},w1=["aria-label","onClick"],x1={class:"spm-card-control"},S1={class:"spm-control-header"},_1={class:"spm-control-title-group"},C1={class:"spm-control-title"},$1={class:"spm-segmented-group"},I1={class:"spm-card-control"},E1={class:"spm-control-header"},T1={class:"spm-control-title-group"},A1={class:"spm-control-title"},B1={class:"spm-segmented-group"},M1={class:"spm-card-control"},D1={class:"spm-control-header"},L1={class:"spm-control-title-group"},O1={class:"spm-control-title"},R1={class:"spm-card-control"},P1={class:"spm-control-header"},N1={class:"spm-control-title-group"},z1={class:"spm-control-title"},F1=["aria-label"],H1=["checked"],j1={key:0,class:"spm-control-body",style:{"margin-top":"8px"}},W1=["value"],U1={class:"spm-card-control"},V1={class:"spm-control-header"},K1={class:"spm-control-title-group"},q1={class:"spm-control-title"},G1=["aria-label"],Z1=["checked"],Y1={class:"spm-card-control"},J1={class:"spm-action-grid"},X1=Ct({__name:"DocInspectorSection",props:{docTheme:{},docAspectRatio:{},docDefaultTransition:{},docSpacing:{}},emits:["update:docTheme","update:docAspectRatio","update:docDefaultTransition","update:docSpacing","openBottomPreview","openPresenter","aiAutoSplit","exportHtml","exportPdf"],setup(e){const t=ei("plugin"),i=hi,n=[{value:"default",label:"默认 default",desc:"官方默认科技风：现代无衬线排版与清新代码语法高亮，通用汇报与技术分享首选"},{value:"seriph",label:"优雅 seriph",desc:"典雅学术衬线风：书卷学术质感、衬线字体典雅庄重，适合学术论文、人文讲座与深度阅读"},{value:"apple-basic",label:"极简 apple",desc:"苹果发布会极简风：大字号、高对比度与极致留白，适合产品发布、方案演讲与纯粹视觉呈现"}];function o(a){Li({enableWebServeJump:a}),t&&typeof t.saveGlobalSettings=="function"&&t.saveGlobalSettings({enableWebServeJump:a})}async function s(a){var c;Li({normalizeHeadingSizes:a}),t&&typeof t.saveGlobalSettings=="function"&&await t.saveGlobalSettings({normalizeHeadingSizes:a}),t&&typeof t.compileCurrentDocument=="function"&&t.compileCurrentDocument(t.currentDocId||((c=t.getActiveDocumentId)==null?void 0:c.call(t)))}function l(a){Li({webServeUrl:a})}function r(a){Li({webServeUrl:a}),t&&typeof t.saveGlobalSettings=="function"&&t.saveGlobalSettings({webServeUrl:a})}return(a,c)=>(oe(),se("div",m1,[c[39]||(c[39]=p("div",{class:"spm-section-header"},[p("span",null,"全局演示配置")],-1)),p("div",g1,[p("div",v1,[p("div",b1,[p("div",y1,[de(fe,{name:"palette"}),c[18]||(c[18]=p("span",null,"幻灯片主题 (Theme)",-1))]),c[19]||(c[19]=p("span",{class:"spm-control-desc"},"全局 Slidev 视觉设计范式",-1))])]),p("div",k1,[(oe(),se(Ke,null,kt(n,d=>p("button",{key:d.value,class:Ie(["spm-segmented-item b3-tooltips b3-tooltips__s",{active:e.docTheme===d.value}]),"aria-label":d.desc,onClick:m=>a.$emit("update:docTheme",d.value)},Se(d.label),11,w1)),64))])]),p("div",x1,[p("div",S1,[p("div",_1,[p("div",C1,[de(fe,{name:"ratio"}),c[20]||(c[20]=p("span",null,"画幅比例 (Aspect Ratio)",-1))]),c[21]||(c[21]=p("span",{class:"spm-control-desc"},"演讲屏幕投影宽高比",-1))])]),p("div",$1,[p("button",{class:Ie(["spm-segmented-item",{active:e.docAspectRatio==="16/9"}]),onClick:c[0]||(c[0]=d=>a.$emit("update:docAspectRatio","16/9"))}," 16 : 9 (宽屏) ",2),p("button",{class:Ie(["spm-segmented-item",{active:e.docAspectRatio==="4/3"}]),onClick:c[1]||(c[1]=d=>a.$emit("update:docAspectRatio","4/3"))}," 4 : 3 (标屏) ",2),p("button",{class:Ie(["spm-segmented-item",{active:e.docAspectRatio==="16/10"}]),onClick:c[2]||(c[2]=d=>a.$emit("update:docAspectRatio","16/10"))}," 16 : 10 ",2)])]),p("div",I1,[p("div",E1,[p("div",T1,[p("div",A1,[de(fe,{name:"ratio"}),c[22]||(c[22]=p("span",null,"间距风格 (Spacing)",-1))]),c[23]||(c[23]=p("span",{class:"spm-control-desc"},"内边距与顶部标题下边距预设",-1))])]),p("div",B1,[p("button",{class:Ie(["spm-segmented-item b3-tooltips b3-tooltips__s",{active:(e.docSpacing||"normal")==="compact"}]),"aria-label":"紧凑排版：上下 20px / 左右 36px，释放垂直空间，适配图文分栏",onClick:c[3]||(c[3]=d=>a.$emit("update:docSpacing","compact"))}," 紧凑 (Compact) ",2),p("button",{class:Ie(["spm-segmented-item b3-tooltips b3-tooltips__s",{active:(e.docSpacing||"normal")==="normal"}]),"aria-label":"标准排版：上下 32px / 左右 48px，协调美观（推荐默认）",onClick:c[4]||(c[4]=d=>a.$emit("update:docSpacing","normal"))}," 标准 (Normal) ",2),p("button",{class:Ie(["spm-segmented-item b3-tooltips b3-tooltips__s",{active:(e.docSpacing||"normal")==="loose"}]),"aria-label":"宽松排版：上下 48px / 左右 56px，大留白适合极简大字",onClick:c[5]||(c[5]=d=>a.$emit("update:docSpacing","loose"))}," 宽松 (Loose) ",2)])]),p("div",M1,[p("div",D1,[p("div",L1,[p("div",O1,[de(fe,{name:"transition"}),c[24]||(c[24]=p("span",null,"全局默认转场",-1))]),c[25]||(c[25]=p("span",{class:"spm-control-desc"},"页面切换过渡动效（未单设转场的页面将继承此动效）",-1))])]),de(Js,{"model-value":e.docDefaultTransition,"hide-header":!0,onChange:c[6]||(c[6]=d=>a.$emit("update:docDefaultTransition",d))},null,8,["model-value"])]),p("div",R1,[p("div",P1,[p("div",N1,[p("div",z1,[de(fe,{name:"external-link"}),c[26]||(c[26]=p("span",null,"本地网络伺服预览 (Web Serve)",-1))]),c[27]||(c[27]=p("span",{class:"spm-control-desc"},"点击文档/块链接以 Webview 抽屉呈现，支持外跳",-1))]),p("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":ye(i).enableWebServeJump?"关闭本地网络伺服预览":"开启本地网络伺服预览"},[p("input",{type:"checkbox",checked:ye(i).enableWebServeJump,onChange:c[7]||(c[7]=d=>o(d.target.checked))},null,40,H1),c[28]||(c[28]=p("span",{class:"spm-switch-slider"},null,-1))],8,F1)]),ye(i).enableWebServeJump?(oe(),se("div",j1,[p("input",{value:ye(i).webServeUrl,class:"spm-input",placeholder:"http://127.0.0.1:6806",spellcheck:"false",onKeydown:c[8]||(c[8]=Mt(()=>{},["stop"])),onKeyup:c[9]||(c[9]=Mt(()=>{},["stop"])),onInput:c[10]||(c[10]=d=>l(d.target.value)),onChange:c[11]||(c[11]=d=>r(d.target.value))},null,40,W1),c[29]||(c[29]=p("span",{class:"spm-control-desc",style:{display:"block","margin-top":"4px","font-size":"11px",opacity:"0.8"}}," 默认伺服地址为 http://127.0.0.1:6806。开启后点击块链接将在 Webview 抽屉中打开，点击抽屉顶部『外跳』可在外部浏览器打开 ",-1))])):Re("",!0)]),p("div",U1,[p("div",V1,[p("div",K1,[p("div",q1,[de(fe,{name:"type"}),c[30]||(c[30]=p("span",null,"固定特定标题大小",-1))]),c[31]||(c[31]=p("span",{class:"spm-control-desc"},"除封面外页首标题按 H2、多栏内首标题按 H3 大小展示",-1))]),p("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":ye(i).normalizeHeadingSizes?"关闭固定特定标题大小":"开启固定特定标题大小"},[p("input",{type:"checkbox",checked:ye(i).normalizeHeadingSizes,onChange:c[12]||(c[12]=d=>s(d.target.checked))},null,40,Z1),c[32]||(c[32]=p("span",{class:"spm-switch-slider"},null,-1))],8,G1)])]),p("div",Y1,[c[38]||(c[38]=p("div",{class:"spm-control-header"},[p("div",{class:"spm-control-title-group"},[p("span",{class:"spm-control-title"},"演示全局操作")])],-1)),p("div",J1,[p("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"在当前文档下方开启分屏同步预览 (Alt+P)",onClick:c[13]||(c[13]=d=>a.$emit("openBottomPreview"))},[de(fe,{name:"split-preview"}),c[33]||(c[33]=p("span",null,"分屏预览",-1))]),p("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"打开双屏演讲者控制台视窗 (Alt+M)",onClick:c[14]||(c[14]=d=>a.$emit("openPresenter"))},[de(fe,{name:"presenter"}),c[34]||(c[34]=p("span",null,"演讲者视图",-1))]),p("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"智能分析长文本结构并给出大纲分页插入建议",onClick:c[15]||(c[15]=d=>a.$emit("aiAutoSplit"))},[de(fe,{name:"sparkles"}),c[35]||(c[35]=p("span",null,"AI 智能分页",-1))]),p("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"打包导出离线单文件 HTML 幻灯片",onClick:c[16]||(c[16]=d=>a.$emit("exportHtml"))},[de(fe,{name:"export-html"}),c[36]||(c[36]=p("span",null,"导出 HTML",-1))]),p("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"打印生成 16:9 高清演示 PDF 讲义",onClick:c[17]||(c[17]=d=>a.$emit("exportPdf"))},[de(fe,{name:"export-pdf"}),c[37]||(c[37]=p("span",null,"导出 PDF",-1))])])])]))}});var Xn=typeof globalThis<"u"?globalThis:typeof window<"u"?window:typeof global<"u"?global:typeof self<"u"?self:{};function Q1(e){return e&&e.__esModule&&Object.prototype.hasOwnProperty.call(e,"default")?e.default:e}function Qn(e){throw new Error('Could not dynamically require "'+e+'". Please configure the dynamicRequireTargets or/and ignoreDynamicRequires option of @rollup/plugin-commonjs appropriately for this require call to work.')}var is={exports:{}};/*!

JSZip v3.10.1 - A JavaScript class for generating and reading zip files
<http://stuartk.com/jszip>

(c) 2009-2016 Stuart Knightley <stuart [at] stuartk.com>
Dual licenced under the MIT license or GPLv3. See https://raw.github.com/Stuk/jszip/main/LICENSE.markdown.

JSZip uses the library pako released under the MIT license :
https://github.com/nodeca/pako/blob/main/LICENSE
*/var Wr;function ey(){return Wr||(Wr=1,(function(e,t){(function(i){e.exports=i()})(function(){return(function i(n,o,s){function l(c,d){if(!o[c]){if(!n[c]){var m=typeof Qn=="function"&&Qn;if(!d&&m)return m(c,!0);if(r)return r(c,!0);var b=new Error("Cannot find module '"+c+"'");throw b.code="MODULE_NOT_FOUND",b}var u=o[c]={exports:{}};n[c][0].call(u.exports,function(h){var f=n[c][1][h];return l(f||h)},u,u.exports,i,n,o,s)}return o[c].exports}for(var r=typeof Qn=="function"&&Qn,a=0;a<s.length;a++)l(s[a]);return l})({1:[function(i,n,o){var s=i("./utils"),l=i("./support"),r="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";o.encode=function(a){for(var c,d,m,b,u,h,f,v=[],k=0,S=a.length,$=S,T=s.getTypeOf(a)!=="string";k<a.length;)$=S-k,m=T?(c=a[k++],d=k<S?a[k++]:0,k<S?a[k++]:0):(c=a.charCodeAt(k++),d=k<S?a.charCodeAt(k++):0,k<S?a.charCodeAt(k++):0),b=c>>2,u=(3&c)<<4|d>>4,h=1<$?(15&d)<<2|m>>6:64,f=2<$?63&m:64,v.push(r.charAt(b)+r.charAt(u)+r.charAt(h)+r.charAt(f));return v.join("")},o.decode=function(a){var c,d,m,b,u,h,f=0,v=0,k="data:";if(a.substr(0,k.length)===k)throw new Error("Invalid base64 input, it looks like a data url.");var S,$=3*(a=a.replace(/[^A-Za-z0-9+/=]/g,"")).length/4;if(a.charAt(a.length-1)===r.charAt(64)&&$--,a.charAt(a.length-2)===r.charAt(64)&&$--,$%1!=0)throw new Error("Invalid base64 input, bad content length.");for(S=l.uint8array?new Uint8Array(0|$):new Array(0|$);f<a.length;)c=r.indexOf(a.charAt(f++))<<2|(b=r.indexOf(a.charAt(f++)))>>4,d=(15&b)<<4|(u=r.indexOf(a.charAt(f++)))>>2,m=(3&u)<<6|(h=r.indexOf(a.charAt(f++))),S[v++]=c,u!==64&&(S[v++]=d),h!==64&&(S[v++]=m);return S}},{"./support":30,"./utils":32}],2:[function(i,n,o){var s=i("./external"),l=i("./stream/DataWorker"),r=i("./stream/Crc32Probe"),a=i("./stream/DataLengthProbe");function c(d,m,b,u,h){this.compressedSize=d,this.uncompressedSize=m,this.crc32=b,this.compression=u,this.compressedContent=h}c.prototype={getContentWorker:function(){var d=new l(s.Promise.resolve(this.compressedContent)).pipe(this.compression.uncompressWorker()).pipe(new a("data_length")),m=this;return d.on("end",function(){if(this.streamInfo.data_length!==m.uncompressedSize)throw new Error("Bug : uncompressed data size mismatch")}),d},getCompressedWorker:function(){return new l(s.Promise.resolve(this.compressedContent)).withStreamInfo("compressedSize",this.compressedSize).withStreamInfo("uncompressedSize",this.uncompressedSize).withStreamInfo("crc32",this.crc32).withStreamInfo("compression",this.compression)}},c.createWorkerFrom=function(d,m,b){return d.pipe(new r).pipe(new a("uncompressedSize")).pipe(m.compressWorker(b)).pipe(new a("compressedSize")).withStreamInfo("compression",m)},n.exports=c},{"./external":6,"./stream/Crc32Probe":25,"./stream/DataLengthProbe":26,"./stream/DataWorker":27}],3:[function(i,n,o){var s=i("./stream/GenericWorker");o.STORE={magic:"\0\0",compressWorker:function(){return new s("STORE compression")},uncompressWorker:function(){return new s("STORE decompression")}},o.DEFLATE=i("./flate")},{"./flate":7,"./stream/GenericWorker":28}],4:[function(i,n,o){var s=i("./utils"),l=(function(){for(var r,a=[],c=0;c<256;c++){r=c;for(var d=0;d<8;d++)r=1&r?3988292384^r>>>1:r>>>1;a[c]=r}return a})();n.exports=function(r,a){return r!==void 0&&r.length?s.getTypeOf(r)!=="string"?(function(c,d,m,b){var u=l,h=b+m;c^=-1;for(var f=b;f<h;f++)c=c>>>8^u[255&(c^d[f])];return-1^c})(0|a,r,r.length,0):(function(c,d,m,b){var u=l,h=b+m;c^=-1;for(var f=b;f<h;f++)c=c>>>8^u[255&(c^d.charCodeAt(f))];return-1^c})(0|a,r,r.length,0):0}},{"./utils":32}],5:[function(i,n,o){o.base64=!1,o.binary=!1,o.dir=!1,o.createFolders=!0,o.date=null,o.compression=null,o.compressionOptions=null,o.comment=null,o.unixPermissions=null,o.dosPermissions=null},{}],6:[function(i,n,o){var s=null;s=typeof Promise<"u"?Promise:i("lie"),n.exports={Promise:s}},{lie:37}],7:[function(i,n,o){var s=typeof Uint8Array<"u"&&typeof Uint16Array<"u"&&typeof Uint32Array<"u",l=i("pako"),r=i("./utils"),a=i("./stream/GenericWorker"),c=s?"uint8array":"array";function d(m,b){a.call(this,"FlateWorker/"+m),this._pako=null,this._pakoAction=m,this._pakoOptions=b,this.meta={}}o.magic="\b\0",r.inherits(d,a),d.prototype.processChunk=function(m){this.meta=m.meta,this._pako===null&&this._createPako(),this._pako.push(r.transformTo(c,m.data),!1)},d.prototype.flush=function(){a.prototype.flush.call(this),this._pako===null&&this._createPako(),this._pako.push([],!0)},d.prototype.cleanUp=function(){a.prototype.cleanUp.call(this),this._pako=null},d.prototype._createPako=function(){this._pako=new l[this._pakoAction]({raw:!0,level:this._pakoOptions.level||-1});var m=this;this._pako.onData=function(b){m.push({data:b,meta:m.meta})}},o.compressWorker=function(m){return new d("Deflate",m)},o.uncompressWorker=function(){return new d("Inflate",{})}},{"./stream/GenericWorker":28,"./utils":32,pako:38}],8:[function(i,n,o){function s(u,h){var f,v="";for(f=0;f<h;f++)v+=String.fromCharCode(255&u),u>>>=8;return v}function l(u,h,f,v,k,S){var $,T,D=u.file,E=u.compression,x=S!==c.utf8encode,W=r.transformTo("string",S(D.name)),V=r.transformTo("string",c.utf8encode(D.name)),G=D.comment,X=r.transformTo("string",S(G)),C=r.transformTo("string",c.utf8encode(G)),P=V.length!==D.name.length,y=C.length!==G.length,O="",U="",B="",R=D.dir,F=D.date,ee={crc32:0,compressedSize:0,uncompressedSize:0};h&&!f||(ee.crc32=u.crc32,ee.compressedSize=u.compressedSize,ee.uncompressedSize=u.uncompressedSize);var I=0;h&&(I|=8),x||!P&&!y||(I|=2048);var M=0,J=0;R&&(M|=16),k==="UNIX"?(J=798,M|=(function(te,ie){var pe=te;return te||(pe=ie?16893:33204),(65535&pe)<<16})(D.unixPermissions,R)):(J=20,M|=(function(te){return 63&(te||0)})(D.dosPermissions)),$=F.getUTCHours(),$<<=6,$|=F.getUTCMinutes(),$<<=5,$|=F.getUTCSeconds()/2,T=F.getUTCFullYear()-1980,T<<=4,T|=F.getUTCMonth()+1,T<<=5,T|=F.getUTCDate(),P&&(U=s(1,1)+s(d(W),4)+V,O+="up"+s(U.length,2)+U),y&&(B=s(1,1)+s(d(X),4)+C,O+="uc"+s(B.length,2)+B);var Y="";return Y+=`
\0`,Y+=s(I,2),Y+=E.magic,Y+=s($,2),Y+=s(T,2),Y+=s(ee.crc32,4),Y+=s(ee.compressedSize,4),Y+=s(ee.uncompressedSize,4),Y+=s(W.length,2),Y+=s(O.length,2),{fileRecord:m.LOCAL_FILE_HEADER+Y+W+O,dirRecord:m.CENTRAL_FILE_HEADER+s(J,2)+Y+s(X.length,2)+"\0\0\0\0"+s(M,4)+s(v,4)+W+O+X}}var r=i("../utils"),a=i("../stream/GenericWorker"),c=i("../utf8"),d=i("../crc32"),m=i("../signature");function b(u,h,f,v){a.call(this,"ZipFileWorker"),this.bytesWritten=0,this.zipComment=h,this.zipPlatform=f,this.encodeFileName=v,this.streamFiles=u,this.accumulate=!1,this.contentBuffer=[],this.dirRecords=[],this.currentSourceOffset=0,this.entriesCount=0,this.currentFile=null,this._sources=[]}r.inherits(b,a),b.prototype.push=function(u){var h=u.meta.percent||0,f=this.entriesCount,v=this._sources.length;this.accumulate?this.contentBuffer.push(u):(this.bytesWritten+=u.data.length,a.prototype.push.call(this,{data:u.data,meta:{currentFile:this.currentFile,percent:f?(h+100*(f-v-1))/f:100}}))},b.prototype.openedSource=function(u){this.currentSourceOffset=this.bytesWritten,this.currentFile=u.file.name;var h=this.streamFiles&&!u.file.dir;if(h){var f=l(u,h,!1,this.currentSourceOffset,this.zipPlatform,this.encodeFileName);this.push({data:f.fileRecord,meta:{percent:0}})}else this.accumulate=!0},b.prototype.closedSource=function(u){this.accumulate=!1;var h=this.streamFiles&&!u.file.dir,f=l(u,h,!0,this.currentSourceOffset,this.zipPlatform,this.encodeFileName);if(this.dirRecords.push(f.dirRecord),h)this.push({data:(function(v){return m.DATA_DESCRIPTOR+s(v.crc32,4)+s(v.compressedSize,4)+s(v.uncompressedSize,4)})(u),meta:{percent:100}});else for(this.push({data:f.fileRecord,meta:{percent:0}});this.contentBuffer.length;)this.push(this.contentBuffer.shift());this.currentFile=null},b.prototype.flush=function(){for(var u=this.bytesWritten,h=0;h<this.dirRecords.length;h++)this.push({data:this.dirRecords[h],meta:{percent:100}});var f=this.bytesWritten-u,v=(function(k,S,$,T,D){var E=r.transformTo("string",D(T));return m.CENTRAL_DIRECTORY_END+"\0\0\0\0"+s(k,2)+s(k,2)+s(S,4)+s($,4)+s(E.length,2)+E})(this.dirRecords.length,f,u,this.zipComment,this.encodeFileName);this.push({data:v,meta:{percent:100}})},b.prototype.prepareNextSource=function(){this.previous=this._sources.shift(),this.openedSource(this.previous.streamInfo),this.isPaused?this.previous.pause():this.previous.resume()},b.prototype.registerPrevious=function(u){this._sources.push(u);var h=this;return u.on("data",function(f){h.processChunk(f)}),u.on("end",function(){h.closedSource(h.previous.streamInfo),h._sources.length?h.prepareNextSource():h.end()}),u.on("error",function(f){h.error(f)}),this},b.prototype.resume=function(){return!!a.prototype.resume.call(this)&&(!this.previous&&this._sources.length?(this.prepareNextSource(),!0):this.previous||this._sources.length||this.generatedError?void 0:(this.end(),!0))},b.prototype.error=function(u){var h=this._sources;if(!a.prototype.error.call(this,u))return!1;for(var f=0;f<h.length;f++)try{h[f].error(u)}catch{}return!0},b.prototype.lock=function(){a.prototype.lock.call(this);for(var u=this._sources,h=0;h<u.length;h++)u[h].lock()},n.exports=b},{"../crc32":4,"../signature":23,"../stream/GenericWorker":28,"../utf8":31,"../utils":32}],9:[function(i,n,o){var s=i("../compressions"),l=i("./ZipFileWorker");o.generateWorker=function(r,a,c){var d=new l(a.streamFiles,c,a.platform,a.encodeFileName),m=0;try{r.forEach(function(b,u){m++;var h=(function(S,$){var T=S||$,D=s[T];if(!D)throw new Error(T+" is not a valid compression method !");return D})(u.options.compression,a.compression),f=u.options.compressionOptions||a.compressionOptions||{},v=u.dir,k=u.date;u._compressWorker(h,f).withStreamInfo("file",{name:b,dir:v,date:k,comment:u.comment||"",unixPermissions:u.unixPermissions,dosPermissions:u.dosPermissions}).pipe(d)}),d.entriesCount=m}catch(b){d.error(b)}return d}},{"../compressions":3,"./ZipFileWorker":8}],10:[function(i,n,o){function s(){if(!(this instanceof s))return new s;if(arguments.length)throw new Error("The constructor with parameters has been removed in JSZip 3.0, please check the upgrade guide.");this.files=Object.create(null),this.comment=null,this.root="",this.clone=function(){var l=new s;for(var r in this)typeof this[r]!="function"&&(l[r]=this[r]);return l}}(s.prototype=i("./object")).loadAsync=i("./load"),s.support=i("./support"),s.defaults=i("./defaults"),s.version="3.10.1",s.loadAsync=function(l,r){return new s().loadAsync(l,r)},s.external=i("./external"),n.exports=s},{"./defaults":5,"./external":6,"./load":11,"./object":15,"./support":30}],11:[function(i,n,o){var s=i("./utils"),l=i("./external"),r=i("./utf8"),a=i("./zipEntries"),c=i("./stream/Crc32Probe"),d=i("./nodejsUtils");function m(b){return new l.Promise(function(u,h){var f=b.decompressed.getContentWorker().pipe(new c);f.on("error",function(v){h(v)}).on("end",function(){f.streamInfo.crc32!==b.decompressed.crc32?h(new Error("Corrupted zip : CRC32 mismatch")):u()}).resume()})}n.exports=function(b,u){var h=this;return u=s.extend(u||{},{base64:!1,checkCRC32:!1,optimizedBinaryString:!1,createFolders:!1,decodeFileName:r.utf8decode}),d.isNode&&d.isStream(b)?l.Promise.reject(new Error("JSZip can't accept a stream when loading a zip file.")):s.prepareContent("the loaded zip file",b,!0,u.optimizedBinaryString,u.base64).then(function(f){var v=new a(u);return v.load(f),v}).then(function(f){var v=[l.Promise.resolve(f)],k=f.files;if(u.checkCRC32)for(var S=0;S<k.length;S++)v.push(m(k[S]));return l.Promise.all(v)}).then(function(f){for(var v=f.shift(),k=v.files,S=0;S<k.length;S++){var $=k[S],T=$.fileNameStr,D=s.resolve($.fileNameStr);h.file(D,$.decompressed,{binary:!0,optimizedBinaryString:!0,date:$.date,dir:$.dir,comment:$.fileCommentStr.length?$.fileCommentStr:null,unixPermissions:$.unixPermissions,dosPermissions:$.dosPermissions,createFolders:u.createFolders}),$.dir||(h.file(D).unsafeOriginalName=T)}return v.zipComment.length&&(h.comment=v.zipComment),h})}},{"./external":6,"./nodejsUtils":14,"./stream/Crc32Probe":25,"./utf8":31,"./utils":32,"./zipEntries":33}],12:[function(i,n,o){var s=i("../utils"),l=i("../stream/GenericWorker");function r(a,c){l.call(this,"Nodejs stream input adapter for "+a),this._upstreamEnded=!1,this._bindStream(c)}s.inherits(r,l),r.prototype._bindStream=function(a){var c=this;(this._stream=a).pause(),a.on("data",function(d){c.push({data:d,meta:{percent:0}})}).on("error",function(d){c.isPaused?this.generatedError=d:c.error(d)}).on("end",function(){c.isPaused?c._upstreamEnded=!0:c.end()})},r.prototype.pause=function(){return!!l.prototype.pause.call(this)&&(this._stream.pause(),!0)},r.prototype.resume=function(){return!!l.prototype.resume.call(this)&&(this._upstreamEnded?this.end():this._stream.resume(),!0)},n.exports=r},{"../stream/GenericWorker":28,"../utils":32}],13:[function(i,n,o){var s=i("readable-stream").Readable;function l(r,a,c){s.call(this,a),this._helper=r;var d=this;r.on("data",function(m,b){d.push(m)||d._helper.pause(),c&&c(b)}).on("error",function(m){d.emit("error",m)}).on("end",function(){d.push(null)})}i("../utils").inherits(l,s),l.prototype._read=function(){this._helper.resume()},n.exports=l},{"../utils":32,"readable-stream":16}],14:[function(i,n,o){n.exports={isNode:typeof Buffer<"u",newBufferFrom:function(s,l){if(Buffer.from&&Buffer.from!==Uint8Array.from)return Buffer.from(s,l);if(typeof s=="number")throw new Error('The "data" argument must not be a number');return new Buffer(s,l)},allocBuffer:function(s){if(Buffer.alloc)return Buffer.alloc(s);var l=new Buffer(s);return l.fill(0),l},isBuffer:function(s){return Buffer.isBuffer(s)},isStream:function(s){return s&&typeof s.on=="function"&&typeof s.pause=="function"&&typeof s.resume=="function"}}},{}],15:[function(i,n,o){function s(D,E,x){var W,V=r.getTypeOf(E),G=r.extend(x||{},d);G.date=G.date||new Date,G.compression!==null&&(G.compression=G.compression.toUpperCase()),typeof G.unixPermissions=="string"&&(G.unixPermissions=parseInt(G.unixPermissions,8)),G.unixPermissions&&16384&G.unixPermissions&&(G.dir=!0),G.dosPermissions&&16&G.dosPermissions&&(G.dir=!0),G.dir&&(D=k(D)),G.createFolders&&(W=v(D))&&S.call(this,W,!0);var X=V==="string"&&G.binary===!1&&G.base64===!1;x&&x.binary!==void 0||(G.binary=!X),(E instanceof m&&E.uncompressedSize===0||G.dir||!E||E.length===0)&&(G.base64=!1,G.binary=!0,E="",G.compression="STORE",V="string");var C=null;C=E instanceof m||E instanceof a?E:h.isNode&&h.isStream(E)?new f(D,E):r.prepareContent(D,E,G.binary,G.optimizedBinaryString,G.base64);var P=new b(D,C,G);this.files[D]=P}var l=i("./utf8"),r=i("./utils"),a=i("./stream/GenericWorker"),c=i("./stream/StreamHelper"),d=i("./defaults"),m=i("./compressedObject"),b=i("./zipObject"),u=i("./generate"),h=i("./nodejsUtils"),f=i("./nodejs/NodejsStreamInputAdapter"),v=function(D){D.slice(-1)==="/"&&(D=D.substring(0,D.length-1));var E=D.lastIndexOf("/");return 0<E?D.substring(0,E):""},k=function(D){return D.slice(-1)!=="/"&&(D+="/"),D},S=function(D,E){return E=E!==void 0?E:d.createFolders,D=k(D),this.files[D]||s.call(this,D,null,{dir:!0,createFolders:E}),this.files[D]};function $(D){return Object.prototype.toString.call(D)==="[object RegExp]"}var T={load:function(){throw new Error("This method has been removed in JSZip 3.0, please check the upgrade guide.")},forEach:function(D){var E,x,W;for(E in this.files)W=this.files[E],(x=E.slice(this.root.length,E.length))&&E.slice(0,this.root.length)===this.root&&D(x,W)},filter:function(D){var E=[];return this.forEach(function(x,W){D(x,W)&&E.push(W)}),E},file:function(D,E,x){if(arguments.length!==1)return D=this.root+D,s.call(this,D,E,x),this;if($(D)){var W=D;return this.filter(function(G,X){return!X.dir&&W.test(G)})}var V=this.files[this.root+D];return V&&!V.dir?V:null},folder:function(D){if(!D)return this;if($(D))return this.filter(function(V,G){return G.dir&&D.test(V)});var E=this.root+D,x=S.call(this,E),W=this.clone();return W.root=x.name,W},remove:function(D){D=this.root+D;var E=this.files[D];if(E||(D.slice(-1)!=="/"&&(D+="/"),E=this.files[D]),E&&!E.dir)delete this.files[D];else for(var x=this.filter(function(V,G){return G.name.slice(0,D.length)===D}),W=0;W<x.length;W++)delete this.files[x[W].name];return this},generate:function(){throw new Error("This method has been removed in JSZip 3.0, please check the upgrade guide.")},generateInternalStream:function(D){var E,x={};try{if((x=r.extend(D||{},{streamFiles:!1,compression:"STORE",compressionOptions:null,type:"",platform:"DOS",comment:null,mimeType:"application/zip",encodeFileName:l.utf8encode})).type=x.type.toLowerCase(),x.compression=x.compression.toUpperCase(),x.type==="binarystring"&&(x.type="string"),!x.type)throw new Error("No output type specified.");r.checkSupport(x.type),x.platform!=="darwin"&&x.platform!=="freebsd"&&x.platform!=="linux"&&x.platform!=="sunos"||(x.platform="UNIX"),x.platform==="win32"&&(x.platform="DOS");var W=x.comment||this.comment||"";E=u.generateWorker(this,x,W)}catch(V){(E=new a("error")).error(V)}return new c(E,x.type||"string",x.mimeType)},generateAsync:function(D,E){return this.generateInternalStream(D).accumulate(E)},generateNodeStream:function(D,E){return(D=D||{}).type||(D.type="nodebuffer"),this.generateInternalStream(D).toNodejsStream(E)}};n.exports=T},{"./compressedObject":2,"./defaults":5,"./generate":9,"./nodejs/NodejsStreamInputAdapter":12,"./nodejsUtils":14,"./stream/GenericWorker":28,"./stream/StreamHelper":29,"./utf8":31,"./utils":32,"./zipObject":35}],16:[function(i,n,o){n.exports=i("stream")},{stream:void 0}],17:[function(i,n,o){var s=i("./DataReader");function l(r){s.call(this,r);for(var a=0;a<this.data.length;a++)r[a]=255&r[a]}i("../utils").inherits(l,s),l.prototype.byteAt=function(r){return this.data[this.zero+r]},l.prototype.lastIndexOfSignature=function(r){for(var a=r.charCodeAt(0),c=r.charCodeAt(1),d=r.charCodeAt(2),m=r.charCodeAt(3),b=this.length-4;0<=b;--b)if(this.data[b]===a&&this.data[b+1]===c&&this.data[b+2]===d&&this.data[b+3]===m)return b-this.zero;return-1},l.prototype.readAndCheckSignature=function(r){var a=r.charCodeAt(0),c=r.charCodeAt(1),d=r.charCodeAt(2),m=r.charCodeAt(3),b=this.readData(4);return a===b[0]&&c===b[1]&&d===b[2]&&m===b[3]},l.prototype.readData=function(r){if(this.checkOffset(r),r===0)return[];var a=this.data.slice(this.zero+this.index,this.zero+this.index+r);return this.index+=r,a},n.exports=l},{"../utils":32,"./DataReader":18}],18:[function(i,n,o){var s=i("../utils");function l(r){this.data=r,this.length=r.length,this.index=0,this.zero=0}l.prototype={checkOffset:function(r){this.checkIndex(this.index+r)},checkIndex:function(r){if(this.length<this.zero+r||r<0)throw new Error("End of data reached (data length = "+this.length+", asked index = "+r+"). Corrupted zip ?")},setIndex:function(r){this.checkIndex(r),this.index=r},skip:function(r){this.setIndex(this.index+r)},byteAt:function(){},readInt:function(r){var a,c=0;for(this.checkOffset(r),a=this.index+r-1;a>=this.index;a--)c=(c<<8)+this.byteAt(a);return this.index+=r,c},readString:function(r){return s.transformTo("string",this.readData(r))},readData:function(){},lastIndexOfSignature:function(){},readAndCheckSignature:function(){},readDate:function(){var r=this.readInt(4);return new Date(Date.UTC(1980+(r>>25&127),(r>>21&15)-1,r>>16&31,r>>11&31,r>>5&63,(31&r)<<1))}},n.exports=l},{"../utils":32}],19:[function(i,n,o){var s=i("./Uint8ArrayReader");function l(r){s.call(this,r)}i("../utils").inherits(l,s),l.prototype.readData=function(r){this.checkOffset(r);var a=this.data.slice(this.zero+this.index,this.zero+this.index+r);return this.index+=r,a},n.exports=l},{"../utils":32,"./Uint8ArrayReader":21}],20:[function(i,n,o){var s=i("./DataReader");function l(r){s.call(this,r)}i("../utils").inherits(l,s),l.prototype.byteAt=function(r){return this.data.charCodeAt(this.zero+r)},l.prototype.lastIndexOfSignature=function(r){return this.data.lastIndexOf(r)-this.zero},l.prototype.readAndCheckSignature=function(r){return r===this.readData(4)},l.prototype.readData=function(r){this.checkOffset(r);var a=this.data.slice(this.zero+this.index,this.zero+this.index+r);return this.index+=r,a},n.exports=l},{"../utils":32,"./DataReader":18}],21:[function(i,n,o){var s=i("./ArrayReader");function l(r){s.call(this,r)}i("../utils").inherits(l,s),l.prototype.readData=function(r){if(this.checkOffset(r),r===0)return new Uint8Array(0);var a=this.data.subarray(this.zero+this.index,this.zero+this.index+r);return this.index+=r,a},n.exports=l},{"../utils":32,"./ArrayReader":17}],22:[function(i,n,o){var s=i("../utils"),l=i("../support"),r=i("./ArrayReader"),a=i("./StringReader"),c=i("./NodeBufferReader"),d=i("./Uint8ArrayReader");n.exports=function(m){var b=s.getTypeOf(m);return s.checkSupport(b),b!=="string"||l.uint8array?b==="nodebuffer"?new c(m):l.uint8array?new d(s.transformTo("uint8array",m)):new r(s.transformTo("array",m)):new a(m)}},{"../support":30,"../utils":32,"./ArrayReader":17,"./NodeBufferReader":19,"./StringReader":20,"./Uint8ArrayReader":21}],23:[function(i,n,o){o.LOCAL_FILE_HEADER="PK",o.CENTRAL_FILE_HEADER="PK",o.CENTRAL_DIRECTORY_END="PK",o.ZIP64_CENTRAL_DIRECTORY_LOCATOR="PK\x07",o.ZIP64_CENTRAL_DIRECTORY_END="PK",o.DATA_DESCRIPTOR="PK\x07\b"},{}],24:[function(i,n,o){var s=i("./GenericWorker"),l=i("../utils");function r(a){s.call(this,"ConvertWorker to "+a),this.destType=a}l.inherits(r,s),r.prototype.processChunk=function(a){this.push({data:l.transformTo(this.destType,a.data),meta:a.meta})},n.exports=r},{"../utils":32,"./GenericWorker":28}],25:[function(i,n,o){var s=i("./GenericWorker"),l=i("../crc32");function r(){s.call(this,"Crc32Probe"),this.withStreamInfo("crc32",0)}i("../utils").inherits(r,s),r.prototype.processChunk=function(a){this.streamInfo.crc32=l(a.data,this.streamInfo.crc32||0),this.push(a)},n.exports=r},{"../crc32":4,"../utils":32,"./GenericWorker":28}],26:[function(i,n,o){var s=i("../utils"),l=i("./GenericWorker");function r(a){l.call(this,"DataLengthProbe for "+a),this.propName=a,this.withStreamInfo(a,0)}s.inherits(r,l),r.prototype.processChunk=function(a){if(a){var c=this.streamInfo[this.propName]||0;this.streamInfo[this.propName]=c+a.data.length}l.prototype.processChunk.call(this,a)},n.exports=r},{"../utils":32,"./GenericWorker":28}],27:[function(i,n,o){var s=i("../utils"),l=i("./GenericWorker");function r(a){l.call(this,"DataWorker");var c=this;this.dataIsReady=!1,this.index=0,this.max=0,this.data=null,this.type="",this._tickScheduled=!1,a.then(function(d){c.dataIsReady=!0,c.data=d,c.max=d&&d.length||0,c.type=s.getTypeOf(d),c.isPaused||c._tickAndRepeat()},function(d){c.error(d)})}s.inherits(r,l),r.prototype.cleanUp=function(){l.prototype.cleanUp.call(this),this.data=null},r.prototype.resume=function(){return!!l.prototype.resume.call(this)&&(!this._tickScheduled&&this.dataIsReady&&(this._tickScheduled=!0,s.delay(this._tickAndRepeat,[],this)),!0)},r.prototype._tickAndRepeat=function(){this._tickScheduled=!1,this.isPaused||this.isFinished||(this._tick(),this.isFinished||(s.delay(this._tickAndRepeat,[],this),this._tickScheduled=!0))},r.prototype._tick=function(){if(this.isPaused||this.isFinished)return!1;var a=null,c=Math.min(this.max,this.index+16384);if(this.index>=this.max)return this.end();switch(this.type){case"string":a=this.data.substring(this.index,c);break;case"uint8array":a=this.data.subarray(this.index,c);break;case"array":case"nodebuffer":a=this.data.slice(this.index,c)}return this.index=c,this.push({data:a,meta:{percent:this.max?this.index/this.max*100:0}})},n.exports=r},{"../utils":32,"./GenericWorker":28}],28:[function(i,n,o){function s(l){this.name=l||"default",this.streamInfo={},this.generatedError=null,this.extraStreamInfo={},this.isPaused=!0,this.isFinished=!1,this.isLocked=!1,this._listeners={data:[],end:[],error:[]},this.previous=null}s.prototype={push:function(l){this.emit("data",l)},end:function(){if(this.isFinished)return!1;this.flush();try{this.emit("end"),this.cleanUp(),this.isFinished=!0}catch(l){this.emit("error",l)}return!0},error:function(l){return!this.isFinished&&(this.isPaused?this.generatedError=l:(this.isFinished=!0,this.emit("error",l),this.previous&&this.previous.error(l),this.cleanUp()),!0)},on:function(l,r){return this._listeners[l].push(r),this},cleanUp:function(){this.streamInfo=this.generatedError=this.extraStreamInfo=null,this._listeners=[]},emit:function(l,r){if(this._listeners[l])for(var a=0;a<this._listeners[l].length;a++)this._listeners[l][a].call(this,r)},pipe:function(l){return l.registerPrevious(this)},registerPrevious:function(l){if(this.isLocked)throw new Error("The stream '"+this+"' has already been used.");this.streamInfo=l.streamInfo,this.mergeStreamInfo(),this.previous=l;var r=this;return l.on("data",function(a){r.processChunk(a)}),l.on("end",function(){r.end()}),l.on("error",function(a){r.error(a)}),this},pause:function(){return!this.isPaused&&!this.isFinished&&(this.isPaused=!0,this.previous&&this.previous.pause(),!0)},resume:function(){if(!this.isPaused||this.isFinished)return!1;var l=this.isPaused=!1;return this.generatedError&&(this.error(this.generatedError),l=!0),this.previous&&this.previous.resume(),!l},flush:function(){},processChunk:function(l){this.push(l)},withStreamInfo:function(l,r){return this.extraStreamInfo[l]=r,this.mergeStreamInfo(),this},mergeStreamInfo:function(){for(var l in this.extraStreamInfo)Object.prototype.hasOwnProperty.call(this.extraStreamInfo,l)&&(this.streamInfo[l]=this.extraStreamInfo[l])},lock:function(){if(this.isLocked)throw new Error("The stream '"+this+"' has already been used.");this.isLocked=!0,this.previous&&this.previous.lock()},toString:function(){var l="Worker "+this.name;return this.previous?this.previous+" -> "+l:l}},n.exports=s},{}],29:[function(i,n,o){var s=i("../utils"),l=i("./ConvertWorker"),r=i("./GenericWorker"),a=i("../base64"),c=i("../support"),d=i("../external"),m=null;if(c.nodestream)try{m=i("../nodejs/NodejsStreamOutputAdapter")}catch{}function b(h,f){return new d.Promise(function(v,k){var S=[],$=h._internalType,T=h._outputType,D=h._mimeType;h.on("data",function(E,x){S.push(E),f&&f(x)}).on("error",function(E){S=[],k(E)}).on("end",function(){try{var E=(function(x,W,V){switch(x){case"blob":return s.newBlob(s.transformTo("arraybuffer",W),V);case"base64":return a.encode(W);default:return s.transformTo(x,W)}})(T,(function(x,W){var V,G=0,X=null,C=0;for(V=0;V<W.length;V++)C+=W[V].length;switch(x){case"string":return W.join("");case"array":return Array.prototype.concat.apply([],W);case"uint8array":for(X=new Uint8Array(C),V=0;V<W.length;V++)X.set(W[V],G),G+=W[V].length;return X;case"nodebuffer":return Buffer.concat(W);default:throw new Error("concat : unsupported type '"+x+"'")}})($,S),D);v(E)}catch(x){k(x)}S=[]}).resume()})}function u(h,f,v){var k=f;switch(f){case"blob":case"arraybuffer":k="uint8array";break;case"base64":k="string"}try{this._internalType=k,this._outputType=f,this._mimeType=v,s.checkSupport(k),this._worker=h.pipe(new l(k)),h.lock()}catch(S){this._worker=new r("error"),this._worker.error(S)}}u.prototype={accumulate:function(h){return b(this,h)},on:function(h,f){var v=this;return h==="data"?this._worker.on(h,function(k){f.call(v,k.data,k.meta)}):this._worker.on(h,function(){s.delay(f,arguments,v)}),this},resume:function(){return s.delay(this._worker.resume,[],this._worker),this},pause:function(){return this._worker.pause(),this},toNodejsStream:function(h){if(s.checkSupport("nodestream"),this._outputType!=="nodebuffer")throw new Error(this._outputType+" is not supported by this method");return new m(this,{objectMode:this._outputType!=="nodebuffer"},h)}},n.exports=u},{"../base64":1,"../external":6,"../nodejs/NodejsStreamOutputAdapter":13,"../support":30,"../utils":32,"./ConvertWorker":24,"./GenericWorker":28}],30:[function(i,n,o){if(o.base64=!0,o.array=!0,o.string=!0,o.arraybuffer=typeof ArrayBuffer<"u"&&typeof Uint8Array<"u",o.nodebuffer=typeof Buffer<"u",o.uint8array=typeof Uint8Array<"u",typeof ArrayBuffer>"u")o.blob=!1;else{var s=new ArrayBuffer(0);try{o.blob=new Blob([s],{type:"application/zip"}).size===0}catch{try{var l=new(self.BlobBuilder||self.WebKitBlobBuilder||self.MozBlobBuilder||self.MSBlobBuilder);l.append(s),o.blob=l.getBlob("application/zip").size===0}catch{o.blob=!1}}}try{o.nodestream=!!i("readable-stream").Readable}catch{o.nodestream=!1}},{"readable-stream":16}],31:[function(i,n,o){for(var s=i("./utils"),l=i("./support"),r=i("./nodejsUtils"),a=i("./stream/GenericWorker"),c=new Array(256),d=0;d<256;d++)c[d]=252<=d?6:248<=d?5:240<=d?4:224<=d?3:192<=d?2:1;c[254]=c[254]=1;function m(){a.call(this,"utf-8 decode"),this.leftOver=null}function b(){a.call(this,"utf-8 encode")}o.utf8encode=function(u){return l.nodebuffer?r.newBufferFrom(u,"utf-8"):(function(h){var f,v,k,S,$,T=h.length,D=0;for(S=0;S<T;S++)(64512&(v=h.charCodeAt(S)))==55296&&S+1<T&&(64512&(k=h.charCodeAt(S+1)))==56320&&(v=65536+(v-55296<<10)+(k-56320),S++),D+=v<128?1:v<2048?2:v<65536?3:4;for(f=l.uint8array?new Uint8Array(D):new Array(D),S=$=0;$<D;S++)(64512&(v=h.charCodeAt(S)))==55296&&S+1<T&&(64512&(k=h.charCodeAt(S+1)))==56320&&(v=65536+(v-55296<<10)+(k-56320),S++),v<128?f[$++]=v:(v<2048?f[$++]=192|v>>>6:(v<65536?f[$++]=224|v>>>12:(f[$++]=240|v>>>18,f[$++]=128|v>>>12&63),f[$++]=128|v>>>6&63),f[$++]=128|63&v);return f})(u)},o.utf8decode=function(u){return l.nodebuffer?s.transformTo("nodebuffer",u).toString("utf-8"):(function(h){var f,v,k,S,$=h.length,T=new Array(2*$);for(f=v=0;f<$;)if((k=h[f++])<128)T[v++]=k;else if(4<(S=c[k]))T[v++]=65533,f+=S-1;else{for(k&=S===2?31:S===3?15:7;1<S&&f<$;)k=k<<6|63&h[f++],S--;1<S?T[v++]=65533:k<65536?T[v++]=k:(k-=65536,T[v++]=55296|k>>10&1023,T[v++]=56320|1023&k)}return T.length!==v&&(T.subarray?T=T.subarray(0,v):T.length=v),s.applyFromCharCode(T)})(u=s.transformTo(l.uint8array?"uint8array":"array",u))},s.inherits(m,a),m.prototype.processChunk=function(u){var h=s.transformTo(l.uint8array?"uint8array":"array",u.data);if(this.leftOver&&this.leftOver.length){if(l.uint8array){var f=h;(h=new Uint8Array(f.length+this.leftOver.length)).set(this.leftOver,0),h.set(f,this.leftOver.length)}else h=this.leftOver.concat(h);this.leftOver=null}var v=(function(S,$){var T;for(($=$||S.length)>S.length&&($=S.length),T=$-1;0<=T&&(192&S[T])==128;)T--;return T<0||T===0?$:T+c[S[T]]>$?T:$})(h),k=h;v!==h.length&&(l.uint8array?(k=h.subarray(0,v),this.leftOver=h.subarray(v,h.length)):(k=h.slice(0,v),this.leftOver=h.slice(v,h.length))),this.push({data:o.utf8decode(k),meta:u.meta})},m.prototype.flush=function(){this.leftOver&&this.leftOver.length&&(this.push({data:o.utf8decode(this.leftOver),meta:{}}),this.leftOver=null)},o.Utf8DecodeWorker=m,s.inherits(b,a),b.prototype.processChunk=function(u){this.push({data:o.utf8encode(u.data),meta:u.meta})},o.Utf8EncodeWorker=b},{"./nodejsUtils":14,"./stream/GenericWorker":28,"./support":30,"./utils":32}],32:[function(i,n,o){var s=i("./support"),l=i("./base64"),r=i("./nodejsUtils"),a=i("./external");function c(f){return f}function d(f,v){for(var k=0;k<f.length;++k)v[k]=255&f.charCodeAt(k);return v}i("setimmediate"),o.newBlob=function(f,v){o.checkSupport("blob");try{return new Blob([f],{type:v})}catch{try{var k=new(self.BlobBuilder||self.WebKitBlobBuilder||self.MozBlobBuilder||self.MSBlobBuilder);return k.append(f),k.getBlob(v)}catch{throw new Error("Bug : can't construct the Blob.")}}};var m={stringifyByChunk:function(f,v,k){var S=[],$=0,T=f.length;if(T<=k)return String.fromCharCode.apply(null,f);for(;$<T;)v==="array"||v==="nodebuffer"?S.push(String.fromCharCode.apply(null,f.slice($,Math.min($+k,T)))):S.push(String.fromCharCode.apply(null,f.subarray($,Math.min($+k,T)))),$+=k;return S.join("")},stringifyByChar:function(f){for(var v="",k=0;k<f.length;k++)v+=String.fromCharCode(f[k]);return v},applyCanBeUsed:{uint8array:(function(){try{return s.uint8array&&String.fromCharCode.apply(null,new Uint8Array(1)).length===1}catch{return!1}})(),nodebuffer:(function(){try{return s.nodebuffer&&String.fromCharCode.apply(null,r.allocBuffer(1)).length===1}catch{return!1}})()}};function b(f){var v=65536,k=o.getTypeOf(f),S=!0;if(k==="uint8array"?S=m.applyCanBeUsed.uint8array:k==="nodebuffer"&&(S=m.applyCanBeUsed.nodebuffer),S)for(;1<v;)try{return m.stringifyByChunk(f,k,v)}catch{v=Math.floor(v/2)}return m.stringifyByChar(f)}function u(f,v){for(var k=0;k<f.length;k++)v[k]=f[k];return v}o.applyFromCharCode=b;var h={};h.string={string:c,array:function(f){return d(f,new Array(f.length))},arraybuffer:function(f){return h.string.uint8array(f).buffer},uint8array:function(f){return d(f,new Uint8Array(f.length))},nodebuffer:function(f){return d(f,r.allocBuffer(f.length))}},h.array={string:b,array:c,arraybuffer:function(f){return new Uint8Array(f).buffer},uint8array:function(f){return new Uint8Array(f)},nodebuffer:function(f){return r.newBufferFrom(f)}},h.arraybuffer={string:function(f){return b(new Uint8Array(f))},array:function(f){return u(new Uint8Array(f),new Array(f.byteLength))},arraybuffer:c,uint8array:function(f){return new Uint8Array(f)},nodebuffer:function(f){return r.newBufferFrom(new Uint8Array(f))}},h.uint8array={string:b,array:function(f){return u(f,new Array(f.length))},arraybuffer:function(f){return f.buffer},uint8array:c,nodebuffer:function(f){return r.newBufferFrom(f)}},h.nodebuffer={string:b,array:function(f){return u(f,new Array(f.length))},arraybuffer:function(f){return h.nodebuffer.uint8array(f).buffer},uint8array:function(f){return u(f,new Uint8Array(f.length))},nodebuffer:c},o.transformTo=function(f,v){if(v=v||"",!f)return v;o.checkSupport(f);var k=o.getTypeOf(v);return h[k][f](v)},o.resolve=function(f){for(var v=f.split("/"),k=[],S=0;S<v.length;S++){var $=v[S];$==="."||$===""&&S!==0&&S!==v.length-1||($===".."?k.pop():k.push($))}return k.join("/")},o.getTypeOf=function(f){return typeof f=="string"?"string":Object.prototype.toString.call(f)==="[object Array]"?"array":s.nodebuffer&&r.isBuffer(f)?"nodebuffer":s.uint8array&&f instanceof Uint8Array?"uint8array":s.arraybuffer&&f instanceof ArrayBuffer?"arraybuffer":void 0},o.checkSupport=function(f){if(!s[f.toLowerCase()])throw new Error(f+" is not supported by this platform")},o.MAX_VALUE_16BITS=65535,o.MAX_VALUE_32BITS=-1,o.pretty=function(f){var v,k,S="";for(k=0;k<(f||"").length;k++)S+="\\x"+((v=f.charCodeAt(k))<16?"0":"")+v.toString(16).toUpperCase();return S},o.delay=function(f,v,k){setImmediate(function(){f.apply(k||null,v||[])})},o.inherits=function(f,v){function k(){}k.prototype=v.prototype,f.prototype=new k},o.extend=function(){var f,v,k={};for(f=0;f<arguments.length;f++)for(v in arguments[f])Object.prototype.hasOwnProperty.call(arguments[f],v)&&k[v]===void 0&&(k[v]=arguments[f][v]);return k},o.prepareContent=function(f,v,k,S,$){return a.Promise.resolve(v).then(function(T){return s.blob&&(T instanceof Blob||["[object File]","[object Blob]"].indexOf(Object.prototype.toString.call(T))!==-1)&&typeof FileReader<"u"?new a.Promise(function(D,E){var x=new FileReader;x.onload=function(W){D(W.target.result)},x.onerror=function(W){E(W.target.error)},x.readAsArrayBuffer(T)}):T}).then(function(T){var D=o.getTypeOf(T);return D?(D==="arraybuffer"?T=o.transformTo("uint8array",T):D==="string"&&($?T=l.decode(T):k&&S!==!0&&(T=(function(E){return d(E,s.uint8array?new Uint8Array(E.length):new Array(E.length))})(T))),T):a.Promise.reject(new Error("Can't read the data of '"+f+"'. Is it in a supported JavaScript type (String, Blob, ArrayBuffer, etc) ?"))})}},{"./base64":1,"./external":6,"./nodejsUtils":14,"./support":30,setimmediate:54}],33:[function(i,n,o){var s=i("./reader/readerFor"),l=i("./utils"),r=i("./signature"),a=i("./zipEntry"),c=i("./support");function d(m){this.files=[],this.loadOptions=m}d.prototype={checkSignature:function(m){if(!this.reader.readAndCheckSignature(m)){this.reader.index-=4;var b=this.reader.readString(4);throw new Error("Corrupted zip or bug: unexpected signature ("+l.pretty(b)+", expected "+l.pretty(m)+")")}},isSignature:function(m,b){var u=this.reader.index;this.reader.setIndex(m);var h=this.reader.readString(4)===b;return this.reader.setIndex(u),h},readBlockEndOfCentral:function(){this.diskNumber=this.reader.readInt(2),this.diskWithCentralDirStart=this.reader.readInt(2),this.centralDirRecordsOnThisDisk=this.reader.readInt(2),this.centralDirRecords=this.reader.readInt(2),this.centralDirSize=this.reader.readInt(4),this.centralDirOffset=this.reader.readInt(4),this.zipCommentLength=this.reader.readInt(2);var m=this.reader.readData(this.zipCommentLength),b=c.uint8array?"uint8array":"array",u=l.transformTo(b,m);this.zipComment=this.loadOptions.decodeFileName(u)},readBlockZip64EndOfCentral:function(){this.zip64EndOfCentralSize=this.reader.readInt(8),this.reader.skip(4),this.diskNumber=this.reader.readInt(4),this.diskWithCentralDirStart=this.reader.readInt(4),this.centralDirRecordsOnThisDisk=this.reader.readInt(8),this.centralDirRecords=this.reader.readInt(8),this.centralDirSize=this.reader.readInt(8),this.centralDirOffset=this.reader.readInt(8),this.zip64ExtensibleData={};for(var m,b,u,h=this.zip64EndOfCentralSize-44;0<h;)m=this.reader.readInt(2),b=this.reader.readInt(4),u=this.reader.readData(b),this.zip64ExtensibleData[m]={id:m,length:b,value:u}},readBlockZip64EndOfCentralLocator:function(){if(this.diskWithZip64CentralDirStart=this.reader.readInt(4),this.relativeOffsetEndOfZip64CentralDir=this.reader.readInt(8),this.disksCount=this.reader.readInt(4),1<this.disksCount)throw new Error("Multi-volumes zip are not supported")},readLocalFiles:function(){var m,b;for(m=0;m<this.files.length;m++)b=this.files[m],this.reader.setIndex(b.localHeaderOffset),this.checkSignature(r.LOCAL_FILE_HEADER),b.readLocalPart(this.reader),b.handleUTF8(),b.processAttributes()},readCentralDir:function(){var m;for(this.reader.setIndex(this.centralDirOffset);this.reader.readAndCheckSignature(r.CENTRAL_FILE_HEADER);)(m=new a({zip64:this.zip64},this.loadOptions)).readCentralPart(this.reader),this.files.push(m);if(this.centralDirRecords!==this.files.length&&this.centralDirRecords!==0&&this.files.length===0)throw new Error("Corrupted zip or bug: expected "+this.centralDirRecords+" records in central dir, got "+this.files.length)},readEndOfCentral:function(){var m=this.reader.lastIndexOfSignature(r.CENTRAL_DIRECTORY_END);if(m<0)throw this.isSignature(0,r.LOCAL_FILE_HEADER)?new Error("Corrupted zip: can't find end of central directory"):new Error("Can't find end of central directory : is this a zip file ? If it is, see https://stuk.github.io/jszip/documentation/howto/read_zip.html");this.reader.setIndex(m);var b=m;if(this.checkSignature(r.CENTRAL_DIRECTORY_END),this.readBlockEndOfCentral(),this.diskNumber===l.MAX_VALUE_16BITS||this.diskWithCentralDirStart===l.MAX_VALUE_16BITS||this.centralDirRecordsOnThisDisk===l.MAX_VALUE_16BITS||this.centralDirRecords===l.MAX_VALUE_16BITS||this.centralDirSize===l.MAX_VALUE_32BITS||this.centralDirOffset===l.MAX_VALUE_32BITS){if(this.zip64=!0,(m=this.reader.lastIndexOfSignature(r.ZIP64_CENTRAL_DIRECTORY_LOCATOR))<0)throw new Error("Corrupted zip: can't find the ZIP64 end of central directory locator");if(this.reader.setIndex(m),this.checkSignature(r.ZIP64_CENTRAL_DIRECTORY_LOCATOR),this.readBlockZip64EndOfCentralLocator(),!this.isSignature(this.relativeOffsetEndOfZip64CentralDir,r.ZIP64_CENTRAL_DIRECTORY_END)&&(this.relativeOffsetEndOfZip64CentralDir=this.reader.lastIndexOfSignature(r.ZIP64_CENTRAL_DIRECTORY_END),this.relativeOffsetEndOfZip64CentralDir<0))throw new Error("Corrupted zip: can't find the ZIP64 end of central directory");this.reader.setIndex(this.relativeOffsetEndOfZip64CentralDir),this.checkSignature(r.ZIP64_CENTRAL_DIRECTORY_END),this.readBlockZip64EndOfCentral()}var u=this.centralDirOffset+this.centralDirSize;this.zip64&&(u+=20,u+=12+this.zip64EndOfCentralSize);var h=b-u;if(0<h)this.isSignature(b,r.CENTRAL_FILE_HEADER)||(this.reader.zero=h);else if(h<0)throw new Error("Corrupted zip: missing "+Math.abs(h)+" bytes.")},prepareReader:function(m){this.reader=s(m)},load:function(m){this.prepareReader(m),this.readEndOfCentral(),this.readCentralDir(),this.readLocalFiles()}},n.exports=d},{"./reader/readerFor":22,"./signature":23,"./support":30,"./utils":32,"./zipEntry":34}],34:[function(i,n,o){var s=i("./reader/readerFor"),l=i("./utils"),r=i("./compressedObject"),a=i("./crc32"),c=i("./utf8"),d=i("./compressions"),m=i("./support");function b(u,h){this.options=u,this.loadOptions=h}b.prototype={isEncrypted:function(){return(1&this.bitFlag)==1},useUTF8:function(){return(2048&this.bitFlag)==2048},readLocalPart:function(u){var h,f;if(u.skip(22),this.fileNameLength=u.readInt(2),f=u.readInt(2),this.fileName=u.readData(this.fileNameLength),u.skip(f),this.compressedSize===-1||this.uncompressedSize===-1)throw new Error("Bug or corrupted zip : didn't get enough information from the central directory (compressedSize === -1 || uncompressedSize === -1)");if((h=(function(v){for(var k in d)if(Object.prototype.hasOwnProperty.call(d,k)&&d[k].magic===v)return d[k];return null})(this.compressionMethod))===null)throw new Error("Corrupted zip : compression "+l.pretty(this.compressionMethod)+" unknown (inner file : "+l.transformTo("string",this.fileName)+")");this.decompressed=new r(this.compressedSize,this.uncompressedSize,this.crc32,h,u.readData(this.compressedSize))},readCentralPart:function(u){this.versionMadeBy=u.readInt(2),u.skip(2),this.bitFlag=u.readInt(2),this.compressionMethod=u.readString(2),this.date=u.readDate(),this.crc32=u.readInt(4),this.compressedSize=u.readInt(4),this.uncompressedSize=u.readInt(4);var h=u.readInt(2);if(this.extraFieldsLength=u.readInt(2),this.fileCommentLength=u.readInt(2),this.diskNumberStart=u.readInt(2),this.internalFileAttributes=u.readInt(2),this.externalFileAttributes=u.readInt(4),this.localHeaderOffset=u.readInt(4),this.isEncrypted())throw new Error("Encrypted zip are not supported");u.skip(h),this.readExtraFields(u),this.parseZIP64ExtraField(u),this.fileComment=u.readData(this.fileCommentLength)},processAttributes:function(){this.unixPermissions=null,this.dosPermissions=null;var u=this.versionMadeBy>>8;this.dir=!!(16&this.externalFileAttributes),u==0&&(this.dosPermissions=63&this.externalFileAttributes),u==3&&(this.unixPermissions=this.externalFileAttributes>>16&65535),this.dir||this.fileNameStr.slice(-1)!=="/"||(this.dir=!0)},parseZIP64ExtraField:function(){if(this.extraFields[1]){var u=s(this.extraFields[1].value);this.uncompressedSize===l.MAX_VALUE_32BITS&&(this.uncompressedSize=u.readInt(8)),this.compressedSize===l.MAX_VALUE_32BITS&&(this.compressedSize=u.readInt(8)),this.localHeaderOffset===l.MAX_VALUE_32BITS&&(this.localHeaderOffset=u.readInt(8)),this.diskNumberStart===l.MAX_VALUE_32BITS&&(this.diskNumberStart=u.readInt(4))}},readExtraFields:function(u){var h,f,v,k=u.index+this.extraFieldsLength;for(this.extraFields||(this.extraFields={});u.index+4<k;)h=u.readInt(2),f=u.readInt(2),v=u.readData(f),this.extraFields[h]={id:h,length:f,value:v};u.setIndex(k)},handleUTF8:function(){var u=m.uint8array?"uint8array":"array";if(this.useUTF8())this.fileNameStr=c.utf8decode(this.fileName),this.fileCommentStr=c.utf8decode(this.fileComment);else{var h=this.findExtraFieldUnicodePath();if(h!==null)this.fileNameStr=h;else{var f=l.transformTo(u,this.fileName);this.fileNameStr=this.loadOptions.decodeFileName(f)}var v=this.findExtraFieldUnicodeComment();if(v!==null)this.fileCommentStr=v;else{var k=l.transformTo(u,this.fileComment);this.fileCommentStr=this.loadOptions.decodeFileName(k)}}},findExtraFieldUnicodePath:function(){var u=this.extraFields[28789];if(u){var h=s(u.value);return h.readInt(1)!==1||a(this.fileName)!==h.readInt(4)?null:c.utf8decode(h.readData(u.length-5))}return null},findExtraFieldUnicodeComment:function(){var u=this.extraFields[25461];if(u){var h=s(u.value);return h.readInt(1)!==1||a(this.fileComment)!==h.readInt(4)?null:c.utf8decode(h.readData(u.length-5))}return null}},n.exports=b},{"./compressedObject":2,"./compressions":3,"./crc32":4,"./reader/readerFor":22,"./support":30,"./utf8":31,"./utils":32}],35:[function(i,n,o){function s(h,f,v){this.name=h,this.dir=v.dir,this.date=v.date,this.comment=v.comment,this.unixPermissions=v.unixPermissions,this.dosPermissions=v.dosPermissions,this._data=f,this._dataBinary=v.binary,this.options={compression:v.compression,compressionOptions:v.compressionOptions}}var l=i("./stream/StreamHelper"),r=i("./stream/DataWorker"),a=i("./utf8"),c=i("./compressedObject"),d=i("./stream/GenericWorker");s.prototype={internalStream:function(h){var f=null,v="string";try{if(!h)throw new Error("No output type specified.");var k=(v=h.toLowerCase())==="string"||v==="text";v!=="binarystring"&&v!=="text"||(v="string"),f=this._decompressWorker();var S=!this._dataBinary;S&&!k&&(f=f.pipe(new a.Utf8EncodeWorker)),!S&&k&&(f=f.pipe(new a.Utf8DecodeWorker))}catch($){(f=new d("error")).error($)}return new l(f,v,"")},async:function(h,f){return this.internalStream(h).accumulate(f)},nodeStream:function(h,f){return this.internalStream(h||"nodebuffer").toNodejsStream(f)},_compressWorker:function(h,f){if(this._data instanceof c&&this._data.compression.magic===h.magic)return this._data.getCompressedWorker();var v=this._decompressWorker();return this._dataBinary||(v=v.pipe(new a.Utf8EncodeWorker)),c.createWorkerFrom(v,h,f)},_decompressWorker:function(){return this._data instanceof c?this._data.getContentWorker():this._data instanceof d?this._data:new r(this._data)}};for(var m=["asText","asBinary","asNodeBuffer","asUint8Array","asArrayBuffer"],b=function(){throw new Error("This method has been removed in JSZip 3.0, please check the upgrade guide.")},u=0;u<m.length;u++)s.prototype[m[u]]=b;n.exports=s},{"./compressedObject":2,"./stream/DataWorker":27,"./stream/GenericWorker":28,"./stream/StreamHelper":29,"./utf8":31}],36:[function(i,n,o){(function(s){var l,r,a=s.MutationObserver||s.WebKitMutationObserver;if(a){var c=0,d=new a(h),m=s.document.createTextNode("");d.observe(m,{characterData:!0}),l=function(){m.data=c=++c%2}}else if(s.setImmediate||s.MessageChannel===void 0)l="document"in s&&"onreadystatechange"in s.document.createElement("script")?function(){var f=s.document.createElement("script");f.onreadystatechange=function(){h(),f.onreadystatechange=null,f.parentNode.removeChild(f),f=null},s.document.documentElement.appendChild(f)}:function(){setTimeout(h,0)};else{var b=new s.MessageChannel;b.port1.onmessage=h,l=function(){b.port2.postMessage(0)}}var u=[];function h(){var f,v;r=!0;for(var k=u.length;k;){for(v=u,u=[],f=-1;++f<k;)v[f]();k=u.length}r=!1}n.exports=function(f){u.push(f)!==1||r||l()}}).call(this,typeof Xn<"u"?Xn:typeof self<"u"?self:typeof window<"u"?window:{})},{}],37:[function(i,n,o){var s=i("immediate");function l(){}var r={},a=["REJECTED"],c=["FULFILLED"],d=["PENDING"];function m(k){if(typeof k!="function")throw new TypeError("resolver must be a function");this.state=d,this.queue=[],this.outcome=void 0,k!==l&&f(this,k)}function b(k,S,$){this.promise=k,typeof S=="function"&&(this.onFulfilled=S,this.callFulfilled=this.otherCallFulfilled),typeof $=="function"&&(this.onRejected=$,this.callRejected=this.otherCallRejected)}function u(k,S,$){s(function(){var T;try{T=S($)}catch(D){return r.reject(k,D)}T===k?r.reject(k,new TypeError("Cannot resolve promise with itself")):r.resolve(k,T)})}function h(k){var S=k&&k.then;if(k&&(typeof k=="object"||typeof k=="function")&&typeof S=="function")return function(){S.apply(k,arguments)}}function f(k,S){var $=!1;function T(x){$||($=!0,r.reject(k,x))}function D(x){$||($=!0,r.resolve(k,x))}var E=v(function(){S(D,T)});E.status==="error"&&T(E.value)}function v(k,S){var $={};try{$.value=k(S),$.status="success"}catch(T){$.status="error",$.value=T}return $}(n.exports=m).prototype.finally=function(k){if(typeof k!="function")return this;var S=this.constructor;return this.then(function($){return S.resolve(k()).then(function(){return $})},function($){return S.resolve(k()).then(function(){throw $})})},m.prototype.catch=function(k){return this.then(null,k)},m.prototype.then=function(k,S){if(typeof k!="function"&&this.state===c||typeof S!="function"&&this.state===a)return this;var $=new this.constructor(l);return this.state!==d?u($,this.state===c?k:S,this.outcome):this.queue.push(new b($,k,S)),$},b.prototype.callFulfilled=function(k){r.resolve(this.promise,k)},b.prototype.otherCallFulfilled=function(k){u(this.promise,this.onFulfilled,k)},b.prototype.callRejected=function(k){r.reject(this.promise,k)},b.prototype.otherCallRejected=function(k){u(this.promise,this.onRejected,k)},r.resolve=function(k,S){var $=v(h,S);if($.status==="error")return r.reject(k,$.value);var T=$.value;if(T)f(k,T);else{k.state=c,k.outcome=S;for(var D=-1,E=k.queue.length;++D<E;)k.queue[D].callFulfilled(S)}return k},r.reject=function(k,S){k.state=a,k.outcome=S;for(var $=-1,T=k.queue.length;++$<T;)k.queue[$].callRejected(S);return k},m.resolve=function(k){return k instanceof this?k:r.resolve(new this(l),k)},m.reject=function(k){var S=new this(l);return r.reject(S,k)},m.all=function(k){var S=this;if(Object.prototype.toString.call(k)!=="[object Array]")return this.reject(new TypeError("must be an array"));var $=k.length,T=!1;if(!$)return this.resolve([]);for(var D=new Array($),E=0,x=-1,W=new this(l);++x<$;)V(k[x],x);return W;function V(G,X){S.resolve(G).then(function(C){D[X]=C,++E!==$||T||(T=!0,r.resolve(W,D))},function(C){T||(T=!0,r.reject(W,C))})}},m.race=function(k){var S=this;if(Object.prototype.toString.call(k)!=="[object Array]")return this.reject(new TypeError("must be an array"));var $=k.length,T=!1;if(!$)return this.resolve([]);for(var D=-1,E=new this(l);++D<$;)x=k[D],S.resolve(x).then(function(W){T||(T=!0,r.resolve(E,W))},function(W){T||(T=!0,r.reject(E,W))});var x;return E}},{immediate:36}],38:[function(i,n,o){var s={};(0,i("./lib/utils/common").assign)(s,i("./lib/deflate"),i("./lib/inflate"),i("./lib/zlib/constants")),n.exports=s},{"./lib/deflate":39,"./lib/inflate":40,"./lib/utils/common":41,"./lib/zlib/constants":44}],39:[function(i,n,o){var s=i("./zlib/deflate"),l=i("./utils/common"),r=i("./utils/strings"),a=i("./zlib/messages"),c=i("./zlib/zstream"),d=Object.prototype.toString,m=0,b=-1,u=0,h=8;function f(k){if(!(this instanceof f))return new f(k);this.options=l.assign({level:b,method:h,chunkSize:16384,windowBits:15,memLevel:8,strategy:u,to:""},k||{});var S=this.options;S.raw&&0<S.windowBits?S.windowBits=-S.windowBits:S.gzip&&0<S.windowBits&&S.windowBits<16&&(S.windowBits+=16),this.err=0,this.msg="",this.ended=!1,this.chunks=[],this.strm=new c,this.strm.avail_out=0;var $=s.deflateInit2(this.strm,S.level,S.method,S.windowBits,S.memLevel,S.strategy);if($!==m)throw new Error(a[$]);if(S.header&&s.deflateSetHeader(this.strm,S.header),S.dictionary){var T;if(T=typeof S.dictionary=="string"?r.string2buf(S.dictionary):d.call(S.dictionary)==="[object ArrayBuffer]"?new Uint8Array(S.dictionary):S.dictionary,($=s.deflateSetDictionary(this.strm,T))!==m)throw new Error(a[$]);this._dict_set=!0}}function v(k,S){var $=new f(S);if($.push(k,!0),$.err)throw $.msg||a[$.err];return $.result}f.prototype.push=function(k,S){var $,T,D=this.strm,E=this.options.chunkSize;if(this.ended)return!1;T=S===~~S?S:S===!0?4:0,typeof k=="string"?D.input=r.string2buf(k):d.call(k)==="[object ArrayBuffer]"?D.input=new Uint8Array(k):D.input=k,D.next_in=0,D.avail_in=D.input.length;do{if(D.avail_out===0&&(D.output=new l.Buf8(E),D.next_out=0,D.avail_out=E),($=s.deflate(D,T))!==1&&$!==m)return this.onEnd($),!(this.ended=!0);D.avail_out!==0&&(D.avail_in!==0||T!==4&&T!==2)||(this.options.to==="string"?this.onData(r.buf2binstring(l.shrinkBuf(D.output,D.next_out))):this.onData(l.shrinkBuf(D.output,D.next_out)))}while((0<D.avail_in||D.avail_out===0)&&$!==1);return T===4?($=s.deflateEnd(this.strm),this.onEnd($),this.ended=!0,$===m):T!==2||(this.onEnd(m),!(D.avail_out=0))},f.prototype.onData=function(k){this.chunks.push(k)},f.prototype.onEnd=function(k){k===m&&(this.options.to==="string"?this.result=this.chunks.join(""):this.result=l.flattenChunks(this.chunks)),this.chunks=[],this.err=k,this.msg=this.strm.msg},o.Deflate=f,o.deflate=v,o.deflateRaw=function(k,S){return(S=S||{}).raw=!0,v(k,S)},o.gzip=function(k,S){return(S=S||{}).gzip=!0,v(k,S)}},{"./utils/common":41,"./utils/strings":42,"./zlib/deflate":46,"./zlib/messages":51,"./zlib/zstream":53}],40:[function(i,n,o){var s=i("./zlib/inflate"),l=i("./utils/common"),r=i("./utils/strings"),a=i("./zlib/constants"),c=i("./zlib/messages"),d=i("./zlib/zstream"),m=i("./zlib/gzheader"),b=Object.prototype.toString;function u(f){if(!(this instanceof u))return new u(f);this.options=l.assign({chunkSize:16384,windowBits:0,to:""},f||{});var v=this.options;v.raw&&0<=v.windowBits&&v.windowBits<16&&(v.windowBits=-v.windowBits,v.windowBits===0&&(v.windowBits=-15)),!(0<=v.windowBits&&v.windowBits<16)||f&&f.windowBits||(v.windowBits+=32),15<v.windowBits&&v.windowBits<48&&(15&v.windowBits)==0&&(v.windowBits|=15),this.err=0,this.msg="",this.ended=!1,this.chunks=[],this.strm=new d,this.strm.avail_out=0;var k=s.inflateInit2(this.strm,v.windowBits);if(k!==a.Z_OK)throw new Error(c[k]);this.header=new m,s.inflateGetHeader(this.strm,this.header)}function h(f,v){var k=new u(v);if(k.push(f,!0),k.err)throw k.msg||c[k.err];return k.result}u.prototype.push=function(f,v){var k,S,$,T,D,E,x=this.strm,W=this.options.chunkSize,V=this.options.dictionary,G=!1;if(this.ended)return!1;S=v===~~v?v:v===!0?a.Z_FINISH:a.Z_NO_FLUSH,typeof f=="string"?x.input=r.binstring2buf(f):b.call(f)==="[object ArrayBuffer]"?x.input=new Uint8Array(f):x.input=f,x.next_in=0,x.avail_in=x.input.length;do{if(x.avail_out===0&&(x.output=new l.Buf8(W),x.next_out=0,x.avail_out=W),(k=s.inflate(x,a.Z_NO_FLUSH))===a.Z_NEED_DICT&&V&&(E=typeof V=="string"?r.string2buf(V):b.call(V)==="[object ArrayBuffer]"?new Uint8Array(V):V,k=s.inflateSetDictionary(this.strm,E)),k===a.Z_BUF_ERROR&&G===!0&&(k=a.Z_OK,G=!1),k!==a.Z_STREAM_END&&k!==a.Z_OK)return this.onEnd(k),!(this.ended=!0);x.next_out&&(x.avail_out!==0&&k!==a.Z_STREAM_END&&(x.avail_in!==0||S!==a.Z_FINISH&&S!==a.Z_SYNC_FLUSH)||(this.options.to==="string"?($=r.utf8border(x.output,x.next_out),T=x.next_out-$,D=r.buf2string(x.output,$),x.next_out=T,x.avail_out=W-T,T&&l.arraySet(x.output,x.output,$,T,0),this.onData(D)):this.onData(l.shrinkBuf(x.output,x.next_out)))),x.avail_in===0&&x.avail_out===0&&(G=!0)}while((0<x.avail_in||x.avail_out===0)&&k!==a.Z_STREAM_END);return k===a.Z_STREAM_END&&(S=a.Z_FINISH),S===a.Z_FINISH?(k=s.inflateEnd(this.strm),this.onEnd(k),this.ended=!0,k===a.Z_OK):S!==a.Z_SYNC_FLUSH||(this.onEnd(a.Z_OK),!(x.avail_out=0))},u.prototype.onData=function(f){this.chunks.push(f)},u.prototype.onEnd=function(f){f===a.Z_OK&&(this.options.to==="string"?this.result=this.chunks.join(""):this.result=l.flattenChunks(this.chunks)),this.chunks=[],this.err=f,this.msg=this.strm.msg},o.Inflate=u,o.inflate=h,o.inflateRaw=function(f,v){return(v=v||{}).raw=!0,h(f,v)},o.ungzip=h},{"./utils/common":41,"./utils/strings":42,"./zlib/constants":44,"./zlib/gzheader":47,"./zlib/inflate":49,"./zlib/messages":51,"./zlib/zstream":53}],41:[function(i,n,o){var s=typeof Uint8Array<"u"&&typeof Uint16Array<"u"&&typeof Int32Array<"u";o.assign=function(a){for(var c=Array.prototype.slice.call(arguments,1);c.length;){var d=c.shift();if(d){if(typeof d!="object")throw new TypeError(d+"must be non-object");for(var m in d)d.hasOwnProperty(m)&&(a[m]=d[m])}}return a},o.shrinkBuf=function(a,c){return a.length===c?a:a.subarray?a.subarray(0,c):(a.length=c,a)};var l={arraySet:function(a,c,d,m,b){if(c.subarray&&a.subarray)a.set(c.subarray(d,d+m),b);else for(var u=0;u<m;u++)a[b+u]=c[d+u]},flattenChunks:function(a){var c,d,m,b,u,h;for(c=m=0,d=a.length;c<d;c++)m+=a[c].length;for(h=new Uint8Array(m),c=b=0,d=a.length;c<d;c++)u=a[c],h.set(u,b),b+=u.length;return h}},r={arraySet:function(a,c,d,m,b){for(var u=0;u<m;u++)a[b+u]=c[d+u]},flattenChunks:function(a){return[].concat.apply([],a)}};o.setTyped=function(a){a?(o.Buf8=Uint8Array,o.Buf16=Uint16Array,o.Buf32=Int32Array,o.assign(o,l)):(o.Buf8=Array,o.Buf16=Array,o.Buf32=Array,o.assign(o,r))},o.setTyped(s)},{}],42:[function(i,n,o){var s=i("./common"),l=!0,r=!0;try{String.fromCharCode.apply(null,[0])}catch{l=!1}try{String.fromCharCode.apply(null,new Uint8Array(1))}catch{r=!1}for(var a=new s.Buf8(256),c=0;c<256;c++)a[c]=252<=c?6:248<=c?5:240<=c?4:224<=c?3:192<=c?2:1;function d(m,b){if(b<65537&&(m.subarray&&r||!m.subarray&&l))return String.fromCharCode.apply(null,s.shrinkBuf(m,b));for(var u="",h=0;h<b;h++)u+=String.fromCharCode(m[h]);return u}a[254]=a[254]=1,o.string2buf=function(m){var b,u,h,f,v,k=m.length,S=0;for(f=0;f<k;f++)(64512&(u=m.charCodeAt(f)))==55296&&f+1<k&&(64512&(h=m.charCodeAt(f+1)))==56320&&(u=65536+(u-55296<<10)+(h-56320),f++),S+=u<128?1:u<2048?2:u<65536?3:4;for(b=new s.Buf8(S),f=v=0;v<S;f++)(64512&(u=m.charCodeAt(f)))==55296&&f+1<k&&(64512&(h=m.charCodeAt(f+1)))==56320&&(u=65536+(u-55296<<10)+(h-56320),f++),u<128?b[v++]=u:(u<2048?b[v++]=192|u>>>6:(u<65536?b[v++]=224|u>>>12:(b[v++]=240|u>>>18,b[v++]=128|u>>>12&63),b[v++]=128|u>>>6&63),b[v++]=128|63&u);return b},o.buf2binstring=function(m){return d(m,m.length)},o.binstring2buf=function(m){for(var b=new s.Buf8(m.length),u=0,h=b.length;u<h;u++)b[u]=m.charCodeAt(u);return b},o.buf2string=function(m,b){var u,h,f,v,k=b||m.length,S=new Array(2*k);for(u=h=0;u<k;)if((f=m[u++])<128)S[h++]=f;else if(4<(v=a[f]))S[h++]=65533,u+=v-1;else{for(f&=v===2?31:v===3?15:7;1<v&&u<k;)f=f<<6|63&m[u++],v--;1<v?S[h++]=65533:f<65536?S[h++]=f:(f-=65536,S[h++]=55296|f>>10&1023,S[h++]=56320|1023&f)}return d(S,h)},o.utf8border=function(m,b){var u;for((b=b||m.length)>m.length&&(b=m.length),u=b-1;0<=u&&(192&m[u])==128;)u--;return u<0||u===0?b:u+a[m[u]]>b?u:b}},{"./common":41}],43:[function(i,n,o){n.exports=function(s,l,r,a){for(var c=65535&s|0,d=s>>>16&65535|0,m=0;r!==0;){for(r-=m=2e3<r?2e3:r;d=d+(c=c+l[a++]|0)|0,--m;);c%=65521,d%=65521}return c|d<<16|0}},{}],44:[function(i,n,o){n.exports={Z_NO_FLUSH:0,Z_PARTIAL_FLUSH:1,Z_SYNC_FLUSH:2,Z_FULL_FLUSH:3,Z_FINISH:4,Z_BLOCK:5,Z_TREES:6,Z_OK:0,Z_STREAM_END:1,Z_NEED_DICT:2,Z_ERRNO:-1,Z_STREAM_ERROR:-2,Z_DATA_ERROR:-3,Z_BUF_ERROR:-5,Z_NO_COMPRESSION:0,Z_BEST_SPEED:1,Z_BEST_COMPRESSION:9,Z_DEFAULT_COMPRESSION:-1,Z_FILTERED:1,Z_HUFFMAN_ONLY:2,Z_RLE:3,Z_FIXED:4,Z_DEFAULT_STRATEGY:0,Z_BINARY:0,Z_TEXT:1,Z_UNKNOWN:2,Z_DEFLATED:8}},{}],45:[function(i,n,o){var s=(function(){for(var l,r=[],a=0;a<256;a++){l=a;for(var c=0;c<8;c++)l=1&l?3988292384^l>>>1:l>>>1;r[a]=l}return r})();n.exports=function(l,r,a,c){var d=s,m=c+a;l^=-1;for(var b=c;b<m;b++)l=l>>>8^d[255&(l^r[b])];return-1^l}},{}],46:[function(i,n,o){var s,l=i("../utils/common"),r=i("./trees"),a=i("./adler32"),c=i("./crc32"),d=i("./messages"),m=0,b=4,u=0,h=-2,f=-1,v=4,k=2,S=8,$=9,T=286,D=30,E=19,x=2*T+1,W=15,V=3,G=258,X=G+V+1,C=42,P=113,y=1,O=2,U=3,B=4;function R(g,j){return g.msg=d[j],j}function F(g){return(g<<1)-(4<g?9:0)}function ee(g){for(var j=g.length;0<=--j;)g[j]=0}function I(g){var j=g.state,z=j.pending;z>g.avail_out&&(z=g.avail_out),z!==0&&(l.arraySet(g.output,j.pending_buf,j.pending_out,z,g.next_out),g.next_out+=z,j.pending_out+=z,g.total_out+=z,g.avail_out-=z,j.pending-=z,j.pending===0&&(j.pending_out=0))}function M(g,j){r._tr_flush_block(g,0<=g.block_start?g.block_start:-1,g.strstart-g.block_start,j),g.block_start=g.strstart,I(g.strm)}function J(g,j){g.pending_buf[g.pending++]=j}function Y(g,j){g.pending_buf[g.pending++]=j>>>8&255,g.pending_buf[g.pending++]=255&j}function te(g,j){var z,_,w=g.max_chain_length,A=g.strstart,q=g.prev_length,K=g.nice_match,Z=g.strstart>g.w_size-X?g.strstart-(g.w_size-X):0,ne=g.window,ce=g.w_mask,re=g.prev,me=g.strstart+G,$e=ne[A+q-1],xe=ne[A+q];g.prev_length>=g.good_match&&(w>>=2),K>g.lookahead&&(K=g.lookahead);do if(ne[(z=j)+q]===xe&&ne[z+q-1]===$e&&ne[z]===ne[A]&&ne[++z]===ne[A+1]){A+=2,z++;do;while(ne[++A]===ne[++z]&&ne[++A]===ne[++z]&&ne[++A]===ne[++z]&&ne[++A]===ne[++z]&&ne[++A]===ne[++z]&&ne[++A]===ne[++z]&&ne[++A]===ne[++z]&&ne[++A]===ne[++z]&&A<me);if(_=G-(me-A),A=me-G,q<_){if(g.match_start=j,K<=(q=_))break;$e=ne[A+q-1],xe=ne[A+q]}}while((j=re[j&ce])>Z&&--w!=0);return q<=g.lookahead?q:g.lookahead}function ie(g){var j,z,_,w,A,q,K,Z,ne,ce,re=g.w_size;do{if(w=g.window_size-g.lookahead-g.strstart,g.strstart>=re+(re-X)){for(l.arraySet(g.window,g.window,re,re,0),g.match_start-=re,g.strstart-=re,g.block_start-=re,j=z=g.hash_size;_=g.head[--j],g.head[j]=re<=_?_-re:0,--z;);for(j=z=re;_=g.prev[--j],g.prev[j]=re<=_?_-re:0,--z;);w+=re}if(g.strm.avail_in===0)break;if(q=g.strm,K=g.window,Z=g.strstart+g.lookahead,ne=w,ce=void 0,ce=q.avail_in,ne<ce&&(ce=ne),z=ce===0?0:(q.avail_in-=ce,l.arraySet(K,q.input,q.next_in,ce,Z),q.state.wrap===1?q.adler=a(q.adler,K,ce,Z):q.state.wrap===2&&(q.adler=c(q.adler,K,ce,Z)),q.next_in+=ce,q.total_in+=ce,ce),g.lookahead+=z,g.lookahead+g.insert>=V)for(A=g.strstart-g.insert,g.ins_h=g.window[A],g.ins_h=(g.ins_h<<g.hash_shift^g.window[A+1])&g.hash_mask;g.insert&&(g.ins_h=(g.ins_h<<g.hash_shift^g.window[A+V-1])&g.hash_mask,g.prev[A&g.w_mask]=g.head[g.ins_h],g.head[g.ins_h]=A,A++,g.insert--,!(g.lookahead+g.insert<V)););}while(g.lookahead<X&&g.strm.avail_in!==0)}function pe(g,j){for(var z,_;;){if(g.lookahead<X){if(ie(g),g.lookahead<X&&j===m)return y;if(g.lookahead===0)break}if(z=0,g.lookahead>=V&&(g.ins_h=(g.ins_h<<g.hash_shift^g.window[g.strstart+V-1])&g.hash_mask,z=g.prev[g.strstart&g.w_mask]=g.head[g.ins_h],g.head[g.ins_h]=g.strstart),z!==0&&g.strstart-z<=g.w_size-X&&(g.match_length=te(g,z)),g.match_length>=V)if(_=r._tr_tally(g,g.strstart-g.match_start,g.match_length-V),g.lookahead-=g.match_length,g.match_length<=g.max_lazy_match&&g.lookahead>=V){for(g.match_length--;g.strstart++,g.ins_h=(g.ins_h<<g.hash_shift^g.window[g.strstart+V-1])&g.hash_mask,z=g.prev[g.strstart&g.w_mask]=g.head[g.ins_h],g.head[g.ins_h]=g.strstart,--g.match_length!=0;);g.strstart++}else g.strstart+=g.match_length,g.match_length=0,g.ins_h=g.window[g.strstart],g.ins_h=(g.ins_h<<g.hash_shift^g.window[g.strstart+1])&g.hash_mask;else _=r._tr_tally(g,0,g.window[g.strstart]),g.lookahead--,g.strstart++;if(_&&(M(g,!1),g.strm.avail_out===0))return y}return g.insert=g.strstart<V-1?g.strstart:V-1,j===b?(M(g,!0),g.strm.avail_out===0?U:B):g.last_lit&&(M(g,!1),g.strm.avail_out===0)?y:O}function le(g,j){for(var z,_,w;;){if(g.lookahead<X){if(ie(g),g.lookahead<X&&j===m)return y;if(g.lookahead===0)break}if(z=0,g.lookahead>=V&&(g.ins_h=(g.ins_h<<g.hash_shift^g.window[g.strstart+V-1])&g.hash_mask,z=g.prev[g.strstart&g.w_mask]=g.head[g.ins_h],g.head[g.ins_h]=g.strstart),g.prev_length=g.match_length,g.prev_match=g.match_start,g.match_length=V-1,z!==0&&g.prev_length<g.max_lazy_match&&g.strstart-z<=g.w_size-X&&(g.match_length=te(g,z),g.match_length<=5&&(g.strategy===1||g.match_length===V&&4096<g.strstart-g.match_start)&&(g.match_length=V-1)),g.prev_length>=V&&g.match_length<=g.prev_length){for(w=g.strstart+g.lookahead-V,_=r._tr_tally(g,g.strstart-1-g.prev_match,g.prev_length-V),g.lookahead-=g.prev_length-1,g.prev_length-=2;++g.strstart<=w&&(g.ins_h=(g.ins_h<<g.hash_shift^g.window[g.strstart+V-1])&g.hash_mask,z=g.prev[g.strstart&g.w_mask]=g.head[g.ins_h],g.head[g.ins_h]=g.strstart),--g.prev_length!=0;);if(g.match_available=0,g.match_length=V-1,g.strstart++,_&&(M(g,!1),g.strm.avail_out===0))return y}else if(g.match_available){if((_=r._tr_tally(g,0,g.window[g.strstart-1]))&&M(g,!1),g.strstart++,g.lookahead--,g.strm.avail_out===0)return y}else g.match_available=1,g.strstart++,g.lookahead--}return g.match_available&&(_=r._tr_tally(g,0,g.window[g.strstart-1]),g.match_available=0),g.insert=g.strstart<V-1?g.strstart:V-1,j===b?(M(g,!0),g.strm.avail_out===0?U:B):g.last_lit&&(M(g,!1),g.strm.avail_out===0)?y:O}function N(g,j,z,_,w){this.good_length=g,this.max_lazy=j,this.nice_length=z,this.max_chain=_,this.func=w}function ae(){this.strm=null,this.status=0,this.pending_buf=null,this.pending_buf_size=0,this.pending_out=0,this.pending=0,this.wrap=0,this.gzhead=null,this.gzindex=0,this.method=S,this.last_flush=-1,this.w_size=0,this.w_bits=0,this.w_mask=0,this.window=null,this.window_size=0,this.prev=null,this.head=null,this.ins_h=0,this.hash_size=0,this.hash_bits=0,this.hash_mask=0,this.hash_shift=0,this.block_start=0,this.match_length=0,this.prev_match=0,this.match_available=0,this.strstart=0,this.match_start=0,this.lookahead=0,this.prev_length=0,this.max_chain_length=0,this.max_lazy_match=0,this.level=0,this.strategy=0,this.good_match=0,this.nice_match=0,this.dyn_ltree=new l.Buf16(2*x),this.dyn_dtree=new l.Buf16(2*(2*D+1)),this.bl_tree=new l.Buf16(2*(2*E+1)),ee(this.dyn_ltree),ee(this.dyn_dtree),ee(this.bl_tree),this.l_desc=null,this.d_desc=null,this.bl_desc=null,this.bl_count=new l.Buf16(W+1),this.heap=new l.Buf16(2*T+1),ee(this.heap),this.heap_len=0,this.heap_max=0,this.depth=new l.Buf16(2*T+1),ee(this.depth),this.l_buf=0,this.lit_bufsize=0,this.last_lit=0,this.d_buf=0,this.opt_len=0,this.static_len=0,this.matches=0,this.insert=0,this.bi_buf=0,this.bi_valid=0}function ue(g){var j;return g&&g.state?(g.total_in=g.total_out=0,g.data_type=k,(j=g.state).pending=0,j.pending_out=0,j.wrap<0&&(j.wrap=-j.wrap),j.status=j.wrap?C:P,g.adler=j.wrap===2?0:1,j.last_flush=m,r._tr_init(j),u):R(g,h)}function L(g){var j=ue(g);return j===u&&(function(z){z.window_size=2*z.w_size,ee(z.head),z.max_lazy_match=s[z.level].max_lazy,z.good_match=s[z.level].good_length,z.nice_match=s[z.level].nice_length,z.max_chain_length=s[z.level].max_chain,z.strstart=0,z.block_start=0,z.lookahead=0,z.insert=0,z.match_length=z.prev_length=V-1,z.match_available=0,z.ins_h=0})(g.state),j}function H(g,j,z,_,w,A){if(!g)return h;var q=1;if(j===f&&(j=6),_<0?(q=0,_=-_):15<_&&(q=2,_-=16),w<1||$<w||z!==S||_<8||15<_||j<0||9<j||A<0||v<A)return R(g,h);_===8&&(_=9);var K=new ae;return(g.state=K).strm=g,K.wrap=q,K.gzhead=null,K.w_bits=_,K.w_size=1<<K.w_bits,K.w_mask=K.w_size-1,K.hash_bits=w+7,K.hash_size=1<<K.hash_bits,K.hash_mask=K.hash_size-1,K.hash_shift=~~((K.hash_bits+V-1)/V),K.window=new l.Buf8(2*K.w_size),K.head=new l.Buf16(K.hash_size),K.prev=new l.Buf16(K.w_size),K.lit_bufsize=1<<w+6,K.pending_buf_size=4*K.lit_bufsize,K.pending_buf=new l.Buf8(K.pending_buf_size),K.d_buf=1*K.lit_bufsize,K.l_buf=3*K.lit_bufsize,K.level=j,K.strategy=A,K.method=z,L(g)}s=[new N(0,0,0,0,function(g,j){var z=65535;for(z>g.pending_buf_size-5&&(z=g.pending_buf_size-5);;){if(g.lookahead<=1){if(ie(g),g.lookahead===0&&j===m)return y;if(g.lookahead===0)break}g.strstart+=g.lookahead,g.lookahead=0;var _=g.block_start+z;if((g.strstart===0||g.strstart>=_)&&(g.lookahead=g.strstart-_,g.strstart=_,M(g,!1),g.strm.avail_out===0)||g.strstart-g.block_start>=g.w_size-X&&(M(g,!1),g.strm.avail_out===0))return y}return g.insert=0,j===b?(M(g,!0),g.strm.avail_out===0?U:B):(g.strstart>g.block_start&&(M(g,!1),g.strm.avail_out),y)}),new N(4,4,8,4,pe),new N(4,5,16,8,pe),new N(4,6,32,32,pe),new N(4,4,16,16,le),new N(8,16,32,32,le),new N(8,16,128,128,le),new N(8,32,128,256,le),new N(32,128,258,1024,le),new N(32,258,258,4096,le)],o.deflateInit=function(g,j){return H(g,j,S,15,8,0)},o.deflateInit2=H,o.deflateReset=L,o.deflateResetKeep=ue,o.deflateSetHeader=function(g,j){return g&&g.state?g.state.wrap!==2?h:(g.state.gzhead=j,u):h},o.deflate=function(g,j){var z,_,w,A;if(!g||!g.state||5<j||j<0)return g?R(g,h):h;if(_=g.state,!g.output||!g.input&&g.avail_in!==0||_.status===666&&j!==b)return R(g,g.avail_out===0?-5:h);if(_.strm=g,z=_.last_flush,_.last_flush=j,_.status===C)if(_.wrap===2)g.adler=0,J(_,31),J(_,139),J(_,8),_.gzhead?(J(_,(_.gzhead.text?1:0)+(_.gzhead.hcrc?2:0)+(_.gzhead.extra?4:0)+(_.gzhead.name?8:0)+(_.gzhead.comment?16:0)),J(_,255&_.gzhead.time),J(_,_.gzhead.time>>8&255),J(_,_.gzhead.time>>16&255),J(_,_.gzhead.time>>24&255),J(_,_.level===9?2:2<=_.strategy||_.level<2?4:0),J(_,255&_.gzhead.os),_.gzhead.extra&&_.gzhead.extra.length&&(J(_,255&_.gzhead.extra.length),J(_,_.gzhead.extra.length>>8&255)),_.gzhead.hcrc&&(g.adler=c(g.adler,_.pending_buf,_.pending,0)),_.gzindex=0,_.status=69):(J(_,0),J(_,0),J(_,0),J(_,0),J(_,0),J(_,_.level===9?2:2<=_.strategy||_.level<2?4:0),J(_,3),_.status=P);else{var q=S+(_.w_bits-8<<4)<<8;q|=(2<=_.strategy||_.level<2?0:_.level<6?1:_.level===6?2:3)<<6,_.strstart!==0&&(q|=32),q+=31-q%31,_.status=P,Y(_,q),_.strstart!==0&&(Y(_,g.adler>>>16),Y(_,65535&g.adler)),g.adler=1}if(_.status===69)if(_.gzhead.extra){for(w=_.pending;_.gzindex<(65535&_.gzhead.extra.length)&&(_.pending!==_.pending_buf_size||(_.gzhead.hcrc&&_.pending>w&&(g.adler=c(g.adler,_.pending_buf,_.pending-w,w)),I(g),w=_.pending,_.pending!==_.pending_buf_size));)J(_,255&_.gzhead.extra[_.gzindex]),_.gzindex++;_.gzhead.hcrc&&_.pending>w&&(g.adler=c(g.adler,_.pending_buf,_.pending-w,w)),_.gzindex===_.gzhead.extra.length&&(_.gzindex=0,_.status=73)}else _.status=73;if(_.status===73)if(_.gzhead.name){w=_.pending;do{if(_.pending===_.pending_buf_size&&(_.gzhead.hcrc&&_.pending>w&&(g.adler=c(g.adler,_.pending_buf,_.pending-w,w)),I(g),w=_.pending,_.pending===_.pending_buf_size)){A=1;break}A=_.gzindex<_.gzhead.name.length?255&_.gzhead.name.charCodeAt(_.gzindex++):0,J(_,A)}while(A!==0);_.gzhead.hcrc&&_.pending>w&&(g.adler=c(g.adler,_.pending_buf,_.pending-w,w)),A===0&&(_.gzindex=0,_.status=91)}else _.status=91;if(_.status===91)if(_.gzhead.comment){w=_.pending;do{if(_.pending===_.pending_buf_size&&(_.gzhead.hcrc&&_.pending>w&&(g.adler=c(g.adler,_.pending_buf,_.pending-w,w)),I(g),w=_.pending,_.pending===_.pending_buf_size)){A=1;break}A=_.gzindex<_.gzhead.comment.length?255&_.gzhead.comment.charCodeAt(_.gzindex++):0,J(_,A)}while(A!==0);_.gzhead.hcrc&&_.pending>w&&(g.adler=c(g.adler,_.pending_buf,_.pending-w,w)),A===0&&(_.status=103)}else _.status=103;if(_.status===103&&(_.gzhead.hcrc?(_.pending+2>_.pending_buf_size&&I(g),_.pending+2<=_.pending_buf_size&&(J(_,255&g.adler),J(_,g.adler>>8&255),g.adler=0,_.status=P)):_.status=P),_.pending!==0){if(I(g),g.avail_out===0)return _.last_flush=-1,u}else if(g.avail_in===0&&F(j)<=F(z)&&j!==b)return R(g,-5);if(_.status===666&&g.avail_in!==0)return R(g,-5);if(g.avail_in!==0||_.lookahead!==0||j!==m&&_.status!==666){var K=_.strategy===2?(function(Z,ne){for(var ce;;){if(Z.lookahead===0&&(ie(Z),Z.lookahead===0)){if(ne===m)return y;break}if(Z.match_length=0,ce=r._tr_tally(Z,0,Z.window[Z.strstart]),Z.lookahead--,Z.strstart++,ce&&(M(Z,!1),Z.strm.avail_out===0))return y}return Z.insert=0,ne===b?(M(Z,!0),Z.strm.avail_out===0?U:B):Z.last_lit&&(M(Z,!1),Z.strm.avail_out===0)?y:O})(_,j):_.strategy===3?(function(Z,ne){for(var ce,re,me,$e,xe=Z.window;;){if(Z.lookahead<=G){if(ie(Z),Z.lookahead<=G&&ne===m)return y;if(Z.lookahead===0)break}if(Z.match_length=0,Z.lookahead>=V&&0<Z.strstart&&(re=xe[me=Z.strstart-1])===xe[++me]&&re===xe[++me]&&re===xe[++me]){$e=Z.strstart+G;do;while(re===xe[++me]&&re===xe[++me]&&re===xe[++me]&&re===xe[++me]&&re===xe[++me]&&re===xe[++me]&&re===xe[++me]&&re===xe[++me]&&me<$e);Z.match_length=G-($e-me),Z.match_length>Z.lookahead&&(Z.match_length=Z.lookahead)}if(Z.match_length>=V?(ce=r._tr_tally(Z,1,Z.match_length-V),Z.lookahead-=Z.match_length,Z.strstart+=Z.match_length,Z.match_length=0):(ce=r._tr_tally(Z,0,Z.window[Z.strstart]),Z.lookahead--,Z.strstart++),ce&&(M(Z,!1),Z.strm.avail_out===0))return y}return Z.insert=0,ne===b?(M(Z,!0),Z.strm.avail_out===0?U:B):Z.last_lit&&(M(Z,!1),Z.strm.avail_out===0)?y:O})(_,j):s[_.level].func(_,j);if(K!==U&&K!==B||(_.status=666),K===y||K===U)return g.avail_out===0&&(_.last_flush=-1),u;if(K===O&&(j===1?r._tr_align(_):j!==5&&(r._tr_stored_block(_,0,0,!1),j===3&&(ee(_.head),_.lookahead===0&&(_.strstart=0,_.block_start=0,_.insert=0))),I(g),g.avail_out===0))return _.last_flush=-1,u}return j!==b?u:_.wrap<=0?1:(_.wrap===2?(J(_,255&g.adler),J(_,g.adler>>8&255),J(_,g.adler>>16&255),J(_,g.adler>>24&255),J(_,255&g.total_in),J(_,g.total_in>>8&255),J(_,g.total_in>>16&255),J(_,g.total_in>>24&255)):(Y(_,g.adler>>>16),Y(_,65535&g.adler)),I(g),0<_.wrap&&(_.wrap=-_.wrap),_.pending!==0?u:1)},o.deflateEnd=function(g){var j;return g&&g.state?(j=g.state.status)!==C&&j!==69&&j!==73&&j!==91&&j!==103&&j!==P&&j!==666?R(g,h):(g.state=null,j===P?R(g,-3):u):h},o.deflateSetDictionary=function(g,j){var z,_,w,A,q,K,Z,ne,ce=j.length;if(!g||!g.state||(A=(z=g.state).wrap)===2||A===1&&z.status!==C||z.lookahead)return h;for(A===1&&(g.adler=a(g.adler,j,ce,0)),z.wrap=0,ce>=z.w_size&&(A===0&&(ee(z.head),z.strstart=0,z.block_start=0,z.insert=0),ne=new l.Buf8(z.w_size),l.arraySet(ne,j,ce-z.w_size,z.w_size,0),j=ne,ce=z.w_size),q=g.avail_in,K=g.next_in,Z=g.input,g.avail_in=ce,g.next_in=0,g.input=j,ie(z);z.lookahead>=V;){for(_=z.strstart,w=z.lookahead-(V-1);z.ins_h=(z.ins_h<<z.hash_shift^z.window[_+V-1])&z.hash_mask,z.prev[_&z.w_mask]=z.head[z.ins_h],z.head[z.ins_h]=_,_++,--w;);z.strstart=_,z.lookahead=V-1,ie(z)}return z.strstart+=z.lookahead,z.block_start=z.strstart,z.insert=z.lookahead,z.lookahead=0,z.match_length=z.prev_length=V-1,z.match_available=0,g.next_in=K,g.input=Z,g.avail_in=q,z.wrap=A,u},o.deflateInfo="pako deflate (from Nodeca project)"},{"../utils/common":41,"./adler32":43,"./crc32":45,"./messages":51,"./trees":52}],47:[function(i,n,o){n.exports=function(){this.text=0,this.time=0,this.xflags=0,this.os=0,this.extra=null,this.extra_len=0,this.name="",this.comment="",this.hcrc=0,this.done=!1}},{}],48:[function(i,n,o){n.exports=function(s,l){var r,a,c,d,m,b,u,h,f,v,k,S,$,T,D,E,x,W,V,G,X,C,P,y,O;r=s.state,a=s.next_in,y=s.input,c=a+(s.avail_in-5),d=s.next_out,O=s.output,m=d-(l-s.avail_out),b=d+(s.avail_out-257),u=r.dmax,h=r.wsize,f=r.whave,v=r.wnext,k=r.window,S=r.hold,$=r.bits,T=r.lencode,D=r.distcode,E=(1<<r.lenbits)-1,x=(1<<r.distbits)-1;e:do{$<15&&(S+=y[a++]<<$,$+=8,S+=y[a++]<<$,$+=8),W=T[S&E];t:for(;;){if(S>>>=V=W>>>24,$-=V,(V=W>>>16&255)===0)O[d++]=65535&W;else{if(!(16&V)){if((64&V)==0){W=T[(65535&W)+(S&(1<<V)-1)];continue t}if(32&V){r.mode=12;break e}s.msg="invalid literal/length code",r.mode=30;break e}G=65535&W,(V&=15)&&($<V&&(S+=y[a++]<<$,$+=8),G+=S&(1<<V)-1,S>>>=V,$-=V),$<15&&(S+=y[a++]<<$,$+=8,S+=y[a++]<<$,$+=8),W=D[S&x];i:for(;;){if(S>>>=V=W>>>24,$-=V,!(16&(V=W>>>16&255))){if((64&V)==0){W=D[(65535&W)+(S&(1<<V)-1)];continue i}s.msg="invalid distance code",r.mode=30;break e}if(X=65535&W,$<(V&=15)&&(S+=y[a++]<<$,($+=8)<V&&(S+=y[a++]<<$,$+=8)),u<(X+=S&(1<<V)-1)){s.msg="invalid distance too far back",r.mode=30;break e}if(S>>>=V,$-=V,(V=d-m)<X){if(f<(V=X-V)&&r.sane){s.msg="invalid distance too far back",r.mode=30;break e}if(P=k,(C=0)===v){if(C+=h-V,V<G){for(G-=V;O[d++]=k[C++],--V;);C=d-X,P=O}}else if(v<V){if(C+=h+v-V,(V-=v)<G){for(G-=V;O[d++]=k[C++],--V;);if(C=0,v<G){for(G-=V=v;O[d++]=k[C++],--V;);C=d-X,P=O}}}else if(C+=v-V,V<G){for(G-=V;O[d++]=k[C++],--V;);C=d-X,P=O}for(;2<G;)O[d++]=P[C++],O[d++]=P[C++],O[d++]=P[C++],G-=3;G&&(O[d++]=P[C++],1<G&&(O[d++]=P[C++]))}else{for(C=d-X;O[d++]=O[C++],O[d++]=O[C++],O[d++]=O[C++],2<(G-=3););G&&(O[d++]=O[C++],1<G&&(O[d++]=O[C++]))}break}}break}}while(a<c&&d<b);a-=G=$>>3,S&=(1<<($-=G<<3))-1,s.next_in=a,s.next_out=d,s.avail_in=a<c?c-a+5:5-(a-c),s.avail_out=d<b?b-d+257:257-(d-b),r.hold=S,r.bits=$}},{}],49:[function(i,n,o){var s=i("../utils/common"),l=i("./adler32"),r=i("./crc32"),a=i("./inffast"),c=i("./inftrees"),d=1,m=2,b=0,u=-2,h=1,f=852,v=592;function k(C){return(C>>>24&255)+(C>>>8&65280)+((65280&C)<<8)+((255&C)<<24)}function S(){this.mode=0,this.last=!1,this.wrap=0,this.havedict=!1,this.flags=0,this.dmax=0,this.check=0,this.total=0,this.head=null,this.wbits=0,this.wsize=0,this.whave=0,this.wnext=0,this.window=null,this.hold=0,this.bits=0,this.length=0,this.offset=0,this.extra=0,this.lencode=null,this.distcode=null,this.lenbits=0,this.distbits=0,this.ncode=0,this.nlen=0,this.ndist=0,this.have=0,this.next=null,this.lens=new s.Buf16(320),this.work=new s.Buf16(288),this.lendyn=null,this.distdyn=null,this.sane=0,this.back=0,this.was=0}function $(C){var P;return C&&C.state?(P=C.state,C.total_in=C.total_out=P.total=0,C.msg="",P.wrap&&(C.adler=1&P.wrap),P.mode=h,P.last=0,P.havedict=0,P.dmax=32768,P.head=null,P.hold=0,P.bits=0,P.lencode=P.lendyn=new s.Buf32(f),P.distcode=P.distdyn=new s.Buf32(v),P.sane=1,P.back=-1,b):u}function T(C){var P;return C&&C.state?((P=C.state).wsize=0,P.whave=0,P.wnext=0,$(C)):u}function D(C,P){var y,O;return C&&C.state?(O=C.state,P<0?(y=0,P=-P):(y=1+(P>>4),P<48&&(P&=15)),P&&(P<8||15<P)?u:(O.window!==null&&O.wbits!==P&&(O.window=null),O.wrap=y,O.wbits=P,T(C))):u}function E(C,P){var y,O;return C?(O=new S,(C.state=O).window=null,(y=D(C,P))!==b&&(C.state=null),y):u}var x,W,V=!0;function G(C){if(V){var P;for(x=new s.Buf32(512),W=new s.Buf32(32),P=0;P<144;)C.lens[P++]=8;for(;P<256;)C.lens[P++]=9;for(;P<280;)C.lens[P++]=7;for(;P<288;)C.lens[P++]=8;for(c(d,C.lens,0,288,x,0,C.work,{bits:9}),P=0;P<32;)C.lens[P++]=5;c(m,C.lens,0,32,W,0,C.work,{bits:5}),V=!1}C.lencode=x,C.lenbits=9,C.distcode=W,C.distbits=5}function X(C,P,y,O){var U,B=C.state;return B.window===null&&(B.wsize=1<<B.wbits,B.wnext=0,B.whave=0,B.window=new s.Buf8(B.wsize)),O>=B.wsize?(s.arraySet(B.window,P,y-B.wsize,B.wsize,0),B.wnext=0,B.whave=B.wsize):(O<(U=B.wsize-B.wnext)&&(U=O),s.arraySet(B.window,P,y-O,U,B.wnext),(O-=U)?(s.arraySet(B.window,P,y-O,O,0),B.wnext=O,B.whave=B.wsize):(B.wnext+=U,B.wnext===B.wsize&&(B.wnext=0),B.whave<B.wsize&&(B.whave+=U))),0}o.inflateReset=T,o.inflateReset2=D,o.inflateResetKeep=$,o.inflateInit=function(C){return E(C,15)},o.inflateInit2=E,o.inflate=function(C,P){var y,O,U,B,R,F,ee,I,M,J,Y,te,ie,pe,le,N,ae,ue,L,H,g,j,z,_,w=0,A=new s.Buf8(4),q=[16,17,18,0,8,7,9,6,10,5,11,4,12,3,13,2,14,1,15];if(!C||!C.state||!C.output||!C.input&&C.avail_in!==0)return u;(y=C.state).mode===12&&(y.mode=13),R=C.next_out,U=C.output,ee=C.avail_out,B=C.next_in,O=C.input,F=C.avail_in,I=y.hold,M=y.bits,J=F,Y=ee,j=b;e:for(;;)switch(y.mode){case h:if(y.wrap===0){y.mode=13;break}for(;M<16;){if(F===0)break e;F--,I+=O[B++]<<M,M+=8}if(2&y.wrap&&I===35615){A[y.check=0]=255&I,A[1]=I>>>8&255,y.check=r(y.check,A,2,0),M=I=0,y.mode=2;break}if(y.flags=0,y.head&&(y.head.done=!1),!(1&y.wrap)||(((255&I)<<8)+(I>>8))%31){C.msg="incorrect header check",y.mode=30;break}if((15&I)!=8){C.msg="unknown compression method",y.mode=30;break}if(M-=4,g=8+(15&(I>>>=4)),y.wbits===0)y.wbits=g;else if(g>y.wbits){C.msg="invalid window size",y.mode=30;break}y.dmax=1<<g,C.adler=y.check=1,y.mode=512&I?10:12,M=I=0;break;case 2:for(;M<16;){if(F===0)break e;F--,I+=O[B++]<<M,M+=8}if(y.flags=I,(255&y.flags)!=8){C.msg="unknown compression method",y.mode=30;break}if(57344&y.flags){C.msg="unknown header flags set",y.mode=30;break}y.head&&(y.head.text=I>>8&1),512&y.flags&&(A[0]=255&I,A[1]=I>>>8&255,y.check=r(y.check,A,2,0)),M=I=0,y.mode=3;case 3:for(;M<32;){if(F===0)break e;F--,I+=O[B++]<<M,M+=8}y.head&&(y.head.time=I),512&y.flags&&(A[0]=255&I,A[1]=I>>>8&255,A[2]=I>>>16&255,A[3]=I>>>24&255,y.check=r(y.check,A,4,0)),M=I=0,y.mode=4;case 4:for(;M<16;){if(F===0)break e;F--,I+=O[B++]<<M,M+=8}y.head&&(y.head.xflags=255&I,y.head.os=I>>8),512&y.flags&&(A[0]=255&I,A[1]=I>>>8&255,y.check=r(y.check,A,2,0)),M=I=0,y.mode=5;case 5:if(1024&y.flags){for(;M<16;){if(F===0)break e;F--,I+=O[B++]<<M,M+=8}y.length=I,y.head&&(y.head.extra_len=I),512&y.flags&&(A[0]=255&I,A[1]=I>>>8&255,y.check=r(y.check,A,2,0)),M=I=0}else y.head&&(y.head.extra=null);y.mode=6;case 6:if(1024&y.flags&&(F<(te=y.length)&&(te=F),te&&(y.head&&(g=y.head.extra_len-y.length,y.head.extra||(y.head.extra=new Array(y.head.extra_len)),s.arraySet(y.head.extra,O,B,te,g)),512&y.flags&&(y.check=r(y.check,O,te,B)),F-=te,B+=te,y.length-=te),y.length))break e;y.length=0,y.mode=7;case 7:if(2048&y.flags){if(F===0)break e;for(te=0;g=O[B+te++],y.head&&g&&y.length<65536&&(y.head.name+=String.fromCharCode(g)),g&&te<F;);if(512&y.flags&&(y.check=r(y.check,O,te,B)),F-=te,B+=te,g)break e}else y.head&&(y.head.name=null);y.length=0,y.mode=8;case 8:if(4096&y.flags){if(F===0)break e;for(te=0;g=O[B+te++],y.head&&g&&y.length<65536&&(y.head.comment+=String.fromCharCode(g)),g&&te<F;);if(512&y.flags&&(y.check=r(y.check,O,te,B)),F-=te,B+=te,g)break e}else y.head&&(y.head.comment=null);y.mode=9;case 9:if(512&y.flags){for(;M<16;){if(F===0)break e;F--,I+=O[B++]<<M,M+=8}if(I!==(65535&y.check)){C.msg="header crc mismatch",y.mode=30;break}M=I=0}y.head&&(y.head.hcrc=y.flags>>9&1,y.head.done=!0),C.adler=y.check=0,y.mode=12;break;case 10:for(;M<32;){if(F===0)break e;F--,I+=O[B++]<<M,M+=8}C.adler=y.check=k(I),M=I=0,y.mode=11;case 11:if(y.havedict===0)return C.next_out=R,C.avail_out=ee,C.next_in=B,C.avail_in=F,y.hold=I,y.bits=M,2;C.adler=y.check=1,y.mode=12;case 12:if(P===5||P===6)break e;case 13:if(y.last){I>>>=7&M,M-=7&M,y.mode=27;break}for(;M<3;){if(F===0)break e;F--,I+=O[B++]<<M,M+=8}switch(y.last=1&I,M-=1,3&(I>>>=1)){case 0:y.mode=14;break;case 1:if(G(y),y.mode=20,P!==6)break;I>>>=2,M-=2;break e;case 2:y.mode=17;break;case 3:C.msg="invalid block type",y.mode=30}I>>>=2,M-=2;break;case 14:for(I>>>=7&M,M-=7&M;M<32;){if(F===0)break e;F--,I+=O[B++]<<M,M+=8}if((65535&I)!=(I>>>16^65535)){C.msg="invalid stored block lengths",y.mode=30;break}if(y.length=65535&I,M=I=0,y.mode=15,P===6)break e;case 15:y.mode=16;case 16:if(te=y.length){if(F<te&&(te=F),ee<te&&(te=ee),te===0)break e;s.arraySet(U,O,B,te,R),F-=te,B+=te,ee-=te,R+=te,y.length-=te;break}y.mode=12;break;case 17:for(;M<14;){if(F===0)break e;F--,I+=O[B++]<<M,M+=8}if(y.nlen=257+(31&I),I>>>=5,M-=5,y.ndist=1+(31&I),I>>>=5,M-=5,y.ncode=4+(15&I),I>>>=4,M-=4,286<y.nlen||30<y.ndist){C.msg="too many length or distance symbols",y.mode=30;break}y.have=0,y.mode=18;case 18:for(;y.have<y.ncode;){for(;M<3;){if(F===0)break e;F--,I+=O[B++]<<M,M+=8}y.lens[q[y.have++]]=7&I,I>>>=3,M-=3}for(;y.have<19;)y.lens[q[y.have++]]=0;if(y.lencode=y.lendyn,y.lenbits=7,z={bits:y.lenbits},j=c(0,y.lens,0,19,y.lencode,0,y.work,z),y.lenbits=z.bits,j){C.msg="invalid code lengths set",y.mode=30;break}y.have=0,y.mode=19;case 19:for(;y.have<y.nlen+y.ndist;){for(;N=(w=y.lencode[I&(1<<y.lenbits)-1])>>>16&255,ae=65535&w,!((le=w>>>24)<=M);){if(F===0)break e;F--,I+=O[B++]<<M,M+=8}if(ae<16)I>>>=le,M-=le,y.lens[y.have++]=ae;else{if(ae===16){for(_=le+2;M<_;){if(F===0)break e;F--,I+=O[B++]<<M,M+=8}if(I>>>=le,M-=le,y.have===0){C.msg="invalid bit length repeat",y.mode=30;break}g=y.lens[y.have-1],te=3+(3&I),I>>>=2,M-=2}else if(ae===17){for(_=le+3;M<_;){if(F===0)break e;F--,I+=O[B++]<<M,M+=8}M-=le,g=0,te=3+(7&(I>>>=le)),I>>>=3,M-=3}else{for(_=le+7;M<_;){if(F===0)break e;F--,I+=O[B++]<<M,M+=8}M-=le,g=0,te=11+(127&(I>>>=le)),I>>>=7,M-=7}if(y.have+te>y.nlen+y.ndist){C.msg="invalid bit length repeat",y.mode=30;break}for(;te--;)y.lens[y.have++]=g}}if(y.mode===30)break;if(y.lens[256]===0){C.msg="invalid code -- missing end-of-block",y.mode=30;break}if(y.lenbits=9,z={bits:y.lenbits},j=c(d,y.lens,0,y.nlen,y.lencode,0,y.work,z),y.lenbits=z.bits,j){C.msg="invalid literal/lengths set",y.mode=30;break}if(y.distbits=6,y.distcode=y.distdyn,z={bits:y.distbits},j=c(m,y.lens,y.nlen,y.ndist,y.distcode,0,y.work,z),y.distbits=z.bits,j){C.msg="invalid distances set",y.mode=30;break}if(y.mode=20,P===6)break e;case 20:y.mode=21;case 21:if(6<=F&&258<=ee){C.next_out=R,C.avail_out=ee,C.next_in=B,C.avail_in=F,y.hold=I,y.bits=M,a(C,Y),R=C.next_out,U=C.output,ee=C.avail_out,B=C.next_in,O=C.input,F=C.avail_in,I=y.hold,M=y.bits,y.mode===12&&(y.back=-1);break}for(y.back=0;N=(w=y.lencode[I&(1<<y.lenbits)-1])>>>16&255,ae=65535&w,!((le=w>>>24)<=M);){if(F===0)break e;F--,I+=O[B++]<<M,M+=8}if(N&&(240&N)==0){for(ue=le,L=N,H=ae;N=(w=y.lencode[H+((I&(1<<ue+L)-1)>>ue)])>>>16&255,ae=65535&w,!(ue+(le=w>>>24)<=M);){if(F===0)break e;F--,I+=O[B++]<<M,M+=8}I>>>=ue,M-=ue,y.back+=ue}if(I>>>=le,M-=le,y.back+=le,y.length=ae,N===0){y.mode=26;break}if(32&N){y.back=-1,y.mode=12;break}if(64&N){C.msg="invalid literal/length code",y.mode=30;break}y.extra=15&N,y.mode=22;case 22:if(y.extra){for(_=y.extra;M<_;){if(F===0)break e;F--,I+=O[B++]<<M,M+=8}y.length+=I&(1<<y.extra)-1,I>>>=y.extra,M-=y.extra,y.back+=y.extra}y.was=y.length,y.mode=23;case 23:for(;N=(w=y.distcode[I&(1<<y.distbits)-1])>>>16&255,ae=65535&w,!((le=w>>>24)<=M);){if(F===0)break e;F--,I+=O[B++]<<M,M+=8}if((240&N)==0){for(ue=le,L=N,H=ae;N=(w=y.distcode[H+((I&(1<<ue+L)-1)>>ue)])>>>16&255,ae=65535&w,!(ue+(le=w>>>24)<=M);){if(F===0)break e;F--,I+=O[B++]<<M,M+=8}I>>>=ue,M-=ue,y.back+=ue}if(I>>>=le,M-=le,y.back+=le,64&N){C.msg="invalid distance code",y.mode=30;break}y.offset=ae,y.extra=15&N,y.mode=24;case 24:if(y.extra){for(_=y.extra;M<_;){if(F===0)break e;F--,I+=O[B++]<<M,M+=8}y.offset+=I&(1<<y.extra)-1,I>>>=y.extra,M-=y.extra,y.back+=y.extra}if(y.offset>y.dmax){C.msg="invalid distance too far back",y.mode=30;break}y.mode=25;case 25:if(ee===0)break e;if(te=Y-ee,y.offset>te){if((te=y.offset-te)>y.whave&&y.sane){C.msg="invalid distance too far back",y.mode=30;break}ie=te>y.wnext?(te-=y.wnext,y.wsize-te):y.wnext-te,te>y.length&&(te=y.length),pe=y.window}else pe=U,ie=R-y.offset,te=y.length;for(ee<te&&(te=ee),ee-=te,y.length-=te;U[R++]=pe[ie++],--te;);y.length===0&&(y.mode=21);break;case 26:if(ee===0)break e;U[R++]=y.length,ee--,y.mode=21;break;case 27:if(y.wrap){for(;M<32;){if(F===0)break e;F--,I|=O[B++]<<M,M+=8}if(Y-=ee,C.total_out+=Y,y.total+=Y,Y&&(C.adler=y.check=y.flags?r(y.check,U,Y,R-Y):l(y.check,U,Y,R-Y)),Y=ee,(y.flags?I:k(I))!==y.check){C.msg="incorrect data check",y.mode=30;break}M=I=0}y.mode=28;case 28:if(y.wrap&&y.flags){for(;M<32;){if(F===0)break e;F--,I+=O[B++]<<M,M+=8}if(I!==(4294967295&y.total)){C.msg="incorrect length check",y.mode=30;break}M=I=0}y.mode=29;case 29:j=1;break e;case 30:j=-3;break e;case 31:return-4;case 32:default:return u}return C.next_out=R,C.avail_out=ee,C.next_in=B,C.avail_in=F,y.hold=I,y.bits=M,(y.wsize||Y!==C.avail_out&&y.mode<30&&(y.mode<27||P!==4))&&X(C,C.output,C.next_out,Y-C.avail_out)?(y.mode=31,-4):(J-=C.avail_in,Y-=C.avail_out,C.total_in+=J,C.total_out+=Y,y.total+=Y,y.wrap&&Y&&(C.adler=y.check=y.flags?r(y.check,U,Y,C.next_out-Y):l(y.check,U,Y,C.next_out-Y)),C.data_type=y.bits+(y.last?64:0)+(y.mode===12?128:0)+(y.mode===20||y.mode===15?256:0),(J==0&&Y===0||P===4)&&j===b&&(j=-5),j)},o.inflateEnd=function(C){if(!C||!C.state)return u;var P=C.state;return P.window&&(P.window=null),C.state=null,b},o.inflateGetHeader=function(C,P){var y;return C&&C.state?(2&(y=C.state).wrap)==0?u:((y.head=P).done=!1,b):u},o.inflateSetDictionary=function(C,P){var y,O=P.length;return C&&C.state?(y=C.state).wrap!==0&&y.mode!==11?u:y.mode===11&&l(1,P,O,0)!==y.check?-3:X(C,P,O,O)?(y.mode=31,-4):(y.havedict=1,b):u},o.inflateInfo="pako inflate (from Nodeca project)"},{"../utils/common":41,"./adler32":43,"./crc32":45,"./inffast":48,"./inftrees":50}],50:[function(i,n,o){var s=i("../utils/common"),l=[3,4,5,6,7,8,9,10,11,13,15,17,19,23,27,31,35,43,51,59,67,83,99,115,131,163,195,227,258,0,0],r=[16,16,16,16,16,16,16,16,17,17,17,17,18,18,18,18,19,19,19,19,20,20,20,20,21,21,21,21,16,72,78],a=[1,2,3,4,5,7,9,13,17,25,33,49,65,97,129,193,257,385,513,769,1025,1537,2049,3073,4097,6145,8193,12289,16385,24577,0,0],c=[16,16,16,16,17,17,18,18,19,19,20,20,21,21,22,22,23,23,24,24,25,25,26,26,27,27,28,28,29,29,64,64];n.exports=function(d,m,b,u,h,f,v,k){var S,$,T,D,E,x,W,V,G,X=k.bits,C=0,P=0,y=0,O=0,U=0,B=0,R=0,F=0,ee=0,I=0,M=null,J=0,Y=new s.Buf16(16),te=new s.Buf16(16),ie=null,pe=0;for(C=0;C<=15;C++)Y[C]=0;for(P=0;P<u;P++)Y[m[b+P]]++;for(U=X,O=15;1<=O&&Y[O]===0;O--);if(O<U&&(U=O),O===0)return h[f++]=20971520,h[f++]=20971520,k.bits=1,0;for(y=1;y<O&&Y[y]===0;y++);for(U<y&&(U=y),C=F=1;C<=15;C++)if(F<<=1,(F-=Y[C])<0)return-1;if(0<F&&(d===0||O!==1))return-1;for(te[1]=0,C=1;C<15;C++)te[C+1]=te[C]+Y[C];for(P=0;P<u;P++)m[b+P]!==0&&(v[te[m[b+P]]++]=P);if(x=d===0?(M=ie=v,19):d===1?(M=l,J-=257,ie=r,pe-=257,256):(M=a,ie=c,-1),C=y,E=f,R=P=I=0,T=-1,D=(ee=1<<(B=U))-1,d===1&&852<ee||d===2&&592<ee)return 1;for(;;){for(W=C-R,G=v[P]<x?(V=0,v[P]):v[P]>x?(V=ie[pe+v[P]],M[J+v[P]]):(V=96,0),S=1<<C-R,y=$=1<<B;h[E+(I>>R)+($-=S)]=W<<24|V<<16|G|0,$!==0;);for(S=1<<C-1;I&S;)S>>=1;if(S!==0?(I&=S-1,I+=S):I=0,P++,--Y[C]==0){if(C===O)break;C=m[b+v[P]]}if(U<C&&(I&D)!==T){for(R===0&&(R=U),E+=y,F=1<<(B=C-R);B+R<O&&!((F-=Y[B+R])<=0);)B++,F<<=1;if(ee+=1<<B,d===1&&852<ee||d===2&&592<ee)return 1;h[T=I&D]=U<<24|B<<16|E-f|0}}return I!==0&&(h[E+I]=C-R<<24|64<<16|0),k.bits=U,0}},{"../utils/common":41}],51:[function(i,n,o){n.exports={2:"need dictionary",1:"stream end",0:"","-1":"file error","-2":"stream error","-3":"data error","-4":"insufficient memory","-5":"buffer error","-6":"incompatible version"}},{}],52:[function(i,n,o){var s=i("../utils/common"),l=0,r=1;function a(w){for(var A=w.length;0<=--A;)w[A]=0}var c=0,d=29,m=256,b=m+1+d,u=30,h=19,f=2*b+1,v=15,k=16,S=7,$=256,T=16,D=17,E=18,x=[0,0,0,0,0,0,0,0,1,1,1,1,2,2,2,2,3,3,3,3,4,4,4,4,5,5,5,5,0],W=[0,0,0,0,1,1,2,2,3,3,4,4,5,5,6,6,7,7,8,8,9,9,10,10,11,11,12,12,13,13],V=[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,2,3,7],G=[16,17,18,0,8,7,9,6,10,5,11,4,12,3,13,2,14,1,15],X=new Array(2*(b+2));a(X);var C=new Array(2*u);a(C);var P=new Array(512);a(P);var y=new Array(256);a(y);var O=new Array(d);a(O);var U,B,R,F=new Array(u);function ee(w,A,q,K,Z){this.static_tree=w,this.extra_bits=A,this.extra_base=q,this.elems=K,this.max_length=Z,this.has_stree=w&&w.length}function I(w,A){this.dyn_tree=w,this.max_code=0,this.stat_desc=A}function M(w){return w<256?P[w]:P[256+(w>>>7)]}function J(w,A){w.pending_buf[w.pending++]=255&A,w.pending_buf[w.pending++]=A>>>8&255}function Y(w,A,q){w.bi_valid>k-q?(w.bi_buf|=A<<w.bi_valid&65535,J(w,w.bi_buf),w.bi_buf=A>>k-w.bi_valid,w.bi_valid+=q-k):(w.bi_buf|=A<<w.bi_valid&65535,w.bi_valid+=q)}function te(w,A,q){Y(w,q[2*A],q[2*A+1])}function ie(w,A){for(var q=0;q|=1&w,w>>>=1,q<<=1,0<--A;);return q>>>1}function pe(w,A,q){var K,Z,ne=new Array(v+1),ce=0;for(K=1;K<=v;K++)ne[K]=ce=ce+q[K-1]<<1;for(Z=0;Z<=A;Z++){var re=w[2*Z+1];re!==0&&(w[2*Z]=ie(ne[re]++,re))}}function le(w){var A;for(A=0;A<b;A++)w.dyn_ltree[2*A]=0;for(A=0;A<u;A++)w.dyn_dtree[2*A]=0;for(A=0;A<h;A++)w.bl_tree[2*A]=0;w.dyn_ltree[2*$]=1,w.opt_len=w.static_len=0,w.last_lit=w.matches=0}function N(w){8<w.bi_valid?J(w,w.bi_buf):0<w.bi_valid&&(w.pending_buf[w.pending++]=w.bi_buf),w.bi_buf=0,w.bi_valid=0}function ae(w,A,q,K){var Z=2*A,ne=2*q;return w[Z]<w[ne]||w[Z]===w[ne]&&K[A]<=K[q]}function ue(w,A,q){for(var K=w.heap[q],Z=q<<1;Z<=w.heap_len&&(Z<w.heap_len&&ae(A,w.heap[Z+1],w.heap[Z],w.depth)&&Z++,!ae(A,K,w.heap[Z],w.depth));)w.heap[q]=w.heap[Z],q=Z,Z<<=1;w.heap[q]=K}function L(w,A,q){var K,Z,ne,ce,re=0;if(w.last_lit!==0)for(;K=w.pending_buf[w.d_buf+2*re]<<8|w.pending_buf[w.d_buf+2*re+1],Z=w.pending_buf[w.l_buf+re],re++,K===0?te(w,Z,A):(te(w,(ne=y[Z])+m+1,A),(ce=x[ne])!==0&&Y(w,Z-=O[ne],ce),te(w,ne=M(--K),q),(ce=W[ne])!==0&&Y(w,K-=F[ne],ce)),re<w.last_lit;);te(w,$,A)}function H(w,A){var q,K,Z,ne=A.dyn_tree,ce=A.stat_desc.static_tree,re=A.stat_desc.has_stree,me=A.stat_desc.elems,$e=-1;for(w.heap_len=0,w.heap_max=f,q=0;q<me;q++)ne[2*q]!==0?(w.heap[++w.heap_len]=$e=q,w.depth[q]=0):ne[2*q+1]=0;for(;w.heap_len<2;)ne[2*(Z=w.heap[++w.heap_len]=$e<2?++$e:0)]=1,w.depth[Z]=0,w.opt_len--,re&&(w.static_len-=ce[2*Z+1]);for(A.max_code=$e,q=w.heap_len>>1;1<=q;q--)ue(w,ne,q);for(Z=me;q=w.heap[1],w.heap[1]=w.heap[w.heap_len--],ue(w,ne,1),K=w.heap[1],w.heap[--w.heap_max]=q,w.heap[--w.heap_max]=K,ne[2*Z]=ne[2*q]+ne[2*K],w.depth[Z]=(w.depth[q]>=w.depth[K]?w.depth[q]:w.depth[K])+1,ne[2*q+1]=ne[2*K+1]=Z,w.heap[1]=Z++,ue(w,ne,1),2<=w.heap_len;);w.heap[--w.heap_max]=w.heap[1],(function(xe,Le){var Ze,je,Xe,ze,Gt,st,Ye=Le.dyn_tree,Si=Le.max_code,Hi=Le.stat_desc.static_tree,zo=Le.stat_desc.has_stree,Fo=Le.stat_desc.extra_bits,Wn=Le.stat_desc.extra_base,_i=Le.stat_desc.max_length,ji=0;for(ze=0;ze<=v;ze++)xe.bl_count[ze]=0;for(Ye[2*xe.heap[xe.heap_max]+1]=0,Ze=xe.heap_max+1;Ze<f;Ze++)_i<(ze=Ye[2*Ye[2*(je=xe.heap[Ze])+1]+1]+1)&&(ze=_i,ji++),Ye[2*je+1]=ze,Si<je||(xe.bl_count[ze]++,Gt=0,Wn<=je&&(Gt=Fo[je-Wn]),st=Ye[2*je],xe.opt_len+=st*(ze+Gt),zo&&(xe.static_len+=st*(Hi[2*je+1]+Gt)));if(ji!==0){do{for(ze=_i-1;xe.bl_count[ze]===0;)ze--;xe.bl_count[ze]--,xe.bl_count[ze+1]+=2,xe.bl_count[_i]--,ji-=2}while(0<ji);for(ze=_i;ze!==0;ze--)for(je=xe.bl_count[ze];je!==0;)Si<(Xe=xe.heap[--Ze])||(Ye[2*Xe+1]!==ze&&(xe.opt_len+=(ze-Ye[2*Xe+1])*Ye[2*Xe],Ye[2*Xe+1]=ze),je--)}})(w,A),pe(ne,$e,w.bl_count)}function g(w,A,q){var K,Z,ne=-1,ce=A[1],re=0,me=7,$e=4;for(ce===0&&(me=138,$e=3),A[2*(q+1)+1]=65535,K=0;K<=q;K++)Z=ce,ce=A[2*(K+1)+1],++re<me&&Z===ce||(re<$e?w.bl_tree[2*Z]+=re:Z!==0?(Z!==ne&&w.bl_tree[2*Z]++,w.bl_tree[2*T]++):re<=10?w.bl_tree[2*D]++:w.bl_tree[2*E]++,ne=Z,$e=(re=0)===ce?(me=138,3):Z===ce?(me=6,3):(me=7,4))}function j(w,A,q){var K,Z,ne=-1,ce=A[1],re=0,me=7,$e=4;for(ce===0&&(me=138,$e=3),K=0;K<=q;K++)if(Z=ce,ce=A[2*(K+1)+1],!(++re<me&&Z===ce)){if(re<$e)for(;te(w,Z,w.bl_tree),--re!=0;);else Z!==0?(Z!==ne&&(te(w,Z,w.bl_tree),re--),te(w,T,w.bl_tree),Y(w,re-3,2)):re<=10?(te(w,D,w.bl_tree),Y(w,re-3,3)):(te(w,E,w.bl_tree),Y(w,re-11,7));ne=Z,$e=(re=0)===ce?(me=138,3):Z===ce?(me=6,3):(me=7,4)}}a(F);var z=!1;function _(w,A,q,K){Y(w,(c<<1)+(K?1:0),3),(function(Z,ne,ce,re){N(Z),J(Z,ce),J(Z,~ce),s.arraySet(Z.pending_buf,Z.window,ne,ce,Z.pending),Z.pending+=ce})(w,A,q)}o._tr_init=function(w){z||((function(){var A,q,K,Z,ne,ce=new Array(v+1);for(Z=K=0;Z<d-1;Z++)for(O[Z]=K,A=0;A<1<<x[Z];A++)y[K++]=Z;for(y[K-1]=Z,Z=ne=0;Z<16;Z++)for(F[Z]=ne,A=0;A<1<<W[Z];A++)P[ne++]=Z;for(ne>>=7;Z<u;Z++)for(F[Z]=ne<<7,A=0;A<1<<W[Z]-7;A++)P[256+ne++]=Z;for(q=0;q<=v;q++)ce[q]=0;for(A=0;A<=143;)X[2*A+1]=8,A++,ce[8]++;for(;A<=255;)X[2*A+1]=9,A++,ce[9]++;for(;A<=279;)X[2*A+1]=7,A++,ce[7]++;for(;A<=287;)X[2*A+1]=8,A++,ce[8]++;for(pe(X,b+1,ce),A=0;A<u;A++)C[2*A+1]=5,C[2*A]=ie(A,5);U=new ee(X,x,m+1,b,v),B=new ee(C,W,0,u,v),R=new ee(new Array(0),V,0,h,S)})(),z=!0),w.l_desc=new I(w.dyn_ltree,U),w.d_desc=new I(w.dyn_dtree,B),w.bl_desc=new I(w.bl_tree,R),w.bi_buf=0,w.bi_valid=0,le(w)},o._tr_stored_block=_,o._tr_flush_block=function(w,A,q,K){var Z,ne,ce=0;0<w.level?(w.strm.data_type===2&&(w.strm.data_type=(function(re){var me,$e=4093624447;for(me=0;me<=31;me++,$e>>>=1)if(1&$e&&re.dyn_ltree[2*me]!==0)return l;if(re.dyn_ltree[18]!==0||re.dyn_ltree[20]!==0||re.dyn_ltree[26]!==0)return r;for(me=32;me<m;me++)if(re.dyn_ltree[2*me]!==0)return r;return l})(w)),H(w,w.l_desc),H(w,w.d_desc),ce=(function(re){var me;for(g(re,re.dyn_ltree,re.l_desc.max_code),g(re,re.dyn_dtree,re.d_desc.max_code),H(re,re.bl_desc),me=h-1;3<=me&&re.bl_tree[2*G[me]+1]===0;me--);return re.opt_len+=3*(me+1)+5+5+4,me})(w),Z=w.opt_len+3+7>>>3,(ne=w.static_len+3+7>>>3)<=Z&&(Z=ne)):Z=ne=q+5,q+4<=Z&&A!==-1?_(w,A,q,K):w.strategy===4||ne===Z?(Y(w,2+(K?1:0),3),L(w,X,C)):(Y(w,4+(K?1:0),3),(function(re,me,$e,xe){var Le;for(Y(re,me-257,5),Y(re,$e-1,5),Y(re,xe-4,4),Le=0;Le<xe;Le++)Y(re,re.bl_tree[2*G[Le]+1],3);j(re,re.dyn_ltree,me-1),j(re,re.dyn_dtree,$e-1)})(w,w.l_desc.max_code+1,w.d_desc.max_code+1,ce+1),L(w,w.dyn_ltree,w.dyn_dtree)),le(w),K&&N(w)},o._tr_tally=function(w,A,q){return w.pending_buf[w.d_buf+2*w.last_lit]=A>>>8&255,w.pending_buf[w.d_buf+2*w.last_lit+1]=255&A,w.pending_buf[w.l_buf+w.last_lit]=255&q,w.last_lit++,A===0?w.dyn_ltree[2*q]++:(w.matches++,A--,w.dyn_ltree[2*(y[q]+m+1)]++,w.dyn_dtree[2*M(A)]++),w.last_lit===w.lit_bufsize-1},o._tr_align=function(w){Y(w,2,3),te(w,$,X),(function(A){A.bi_valid===16?(J(A,A.bi_buf),A.bi_buf=0,A.bi_valid=0):8<=A.bi_valid&&(A.pending_buf[A.pending++]=255&A.bi_buf,A.bi_buf>>=8,A.bi_valid-=8)})(w)}},{"../utils/common":41}],53:[function(i,n,o){n.exports=function(){this.input=null,this.next_in=0,this.avail_in=0,this.total_in=0,this.output=null,this.next_out=0,this.avail_out=0,this.total_out=0,this.msg="",this.state=null,this.data_type=2,this.adler=0}},{}],54:[function(i,n,o){(function(s){(function(l,r){if(!l.setImmediate){var a,c,d,m,b=1,u={},h=!1,f=l.document,v=Object.getPrototypeOf&&Object.getPrototypeOf(l);v=v&&v.setTimeout?v:l,a={}.toString.call(l.process)==="[object process]"?function(T){process.nextTick(function(){S(T)})}:(function(){if(l.postMessage&&!l.importScripts){var T=!0,D=l.onmessage;return l.onmessage=function(){T=!1},l.postMessage("","*"),l.onmessage=D,T}})()?(m="setImmediate$"+Math.random()+"$",l.addEventListener?l.addEventListener("message",$,!1):l.attachEvent("onmessage",$),function(T){l.postMessage(m+T,"*")}):l.MessageChannel?((d=new MessageChannel).port1.onmessage=function(T){S(T.data)},function(T){d.port2.postMessage(T)}):f&&"onreadystatechange"in f.createElement("script")?(c=f.documentElement,function(T){var D=f.createElement("script");D.onreadystatechange=function(){S(T),D.onreadystatechange=null,c.removeChild(D),D=null},c.appendChild(D)}):function(T){setTimeout(S,0,T)},v.setImmediate=function(T){typeof T!="function"&&(T=new Function(""+T));for(var D=new Array(arguments.length-1),E=0;E<D.length;E++)D[E]=arguments[E+1];var x={callback:T,args:D};return u[b]=x,a(b),b++},v.clearImmediate=k}function k(T){delete u[T]}function S(T){if(h)setTimeout(S,0,T);else{var D=u[T];if(D){h=!0;try{(function(E){var x=E.callback,W=E.args;switch(W.length){case 0:x();break;case 1:x(W[0]);break;case 2:x(W[0],W[1]);break;case 3:x(W[0],W[1],W[2]);break;default:x.apply(r,W)}})(D)}finally{k(T),h=!1}}}}function $(T){T.source===l&&typeof T.data=="string"&&T.data.indexOf(m)===0&&S(+T.data.slice(m.length))}})(typeof self>"u"?s===void 0?this:s:self)}).call(this,typeof Xn<"u"?Xn:typeof self<"u"?self:typeof window<"u"?window:{})},{}]},{},[10])(10)})})(is)),is.exports}var ty=ey();const iy=Q1(ty),ny=/\.(?:png|jpe?g|gif|svg|webp|avif|ico|bmp|tiff?|mp4|webm|mp3|wav|ogg)$/i,oy=/\.(?:ts|js|mjs|cjs|jsx|tsx|vue|json|css|scss|less|html|py|rs|go|java|c|cpp|h|sh|bash|yaml|yml|toml)$/i;async function sy(e){const t=await iy.loadAsync(e),i={},n=[];let o="",s="";const l=[];t.forEach((a,c)=>{!c.dir&&!a.startsWith("__MACOSX")&&!a.includes("node_modules/")&&l.push({path:a,file:c})});let r=l.find(a=>a.path.toLowerCase()==="slides.md");r||(r=l.find(a=>a.path.toLowerCase().endsWith("/slides.md"))),r||(r=l.find(a=>a.path.toLowerCase().endsWith(".md"))),r&&(o=await r.file.async("string"),s=r.path);for(const a of l){const c=a.path;if(c.toLowerCase().endsWith(".md")||oy.test(c)||c.includes("snippets/")){const d=await a.file.async("string");i[c]=d;const m=c.split("/");m.length>1&&(i[m.slice(1).join("/")]=d)}else if(ny.test(c)){const d=await a.file.async("uint8array"),m=c.split("/").pop()||c,b=typeof Blob<"u"?new Blob([d]):void 0;n.push({zipPath:c,fileName:m,data:d,blob:b})}}return{entryMarkdown:o,entryMarkdownPath:s,virtualFiles:i,assets:n}}function ry(e,t){if(Object.keys(t).length===0)return e;function i(o){const s=o.trim().replace(/^['"]|['"]$/g,""),l=s.split("/").pop()||s;if(t[s])return t[s];const r=s.replace(/^\.?\//,"");return t[r]?t[r]:t[l]?t[l]:null}function n(o){let s=o;return s=s.replace(/!\[(.*?)\]\((.*?)\)/g,(l,r,a)=>{const c=i(a);return c?`![${r}](${c})`:l}),s=s.replace(/\bsrc=["'](.*?)["']/gi,(l,r)=>{const a=i(r);return a?`src="${a}"`:l}),s}for(const o of e.slides)if(o.rawMarkdown=n(o.rawMarkdown),o.pageAttrs["custom-slidev-background"]){const s=o.pageAttrs["custom-slidev-background"],l=i(s);l&&(o.pageAttrs["custom-slidev-background"]=l)}if(e.flattenedMarkdown=n(e.flattenedMarkdown),e.docRootAttrs["custom-slidev-background"]){const o=e.docRootAttrs["custom-slidev-background"],s=i(o);s&&(e.docRootAttrs["custom-slidev-background"]=s)}return e}function Ba(e){try{if(typeof process<"u"&&typeof require<"u"){const t=require("fs");if(t.existsSync(e))return t.readFileSync(e,"utf-8")}}catch{}return null}function ly(e,t){const i=e.match(/^[ \t]*<<<[ \t]+([^\s]+)/);if(!i)return null;const n=i[1].trim(),o=n.indexOf("#"),s=o!==-1?n.slice(0,o):n,l=o!==-1?n.slice(o+1):"",r=s.replace(/^@\//,"").replace(/^\.\//,""),a=(t==null?void 0:t.virtualFiles)||{};let c=a[s]||a[r]||a[`./${r}`]||a[`@/${r}`];if(!c&&Object.keys(a).length>0){const u=r.split("/").pop();for(const[h,f]of Object.entries(a))if(h.endsWith(`/${r}`)||u&&h.endsWith(`/${u}`)){c=f;break}}if(!c){const u=[];if(t!=null&&t.baseDir)try{const h=require("path");u.push(h.resolve(t.baseDir,r)),u.push(h.resolve(t.baseDir,s))}catch{}try{const h=require("path");u.push(h.resolve(process.cwd(),r))}catch{}for(const h of u){const f=Ba(h);if(f!==null){c=f;break}}}if(!c){const u=ka||{};if(c=u[s]||u[r]||u[`snippets/${r}`],!c){const h=r.split("/").pop();for(const[f,v]of Object.entries(u))if(f.endsWith(`/${r}`)||h&&f.endsWith(`/${h}`)){c=v;break}}}if(!c)return null;let d=c;if(l){const u=new RegExp(`(?:\\/\\/|\\/\\*|#)?\\s*#(?:region|REGION)\\s+${l}[^\\r\\n]*\\r?\\n([\\s\\S]*?)(?:\\/\\/|\\/\\*|#)?\\s*#(?:endregion|ENDREGION)\\s+${l}`,"i"),h=c.match(u);if(h){const f=c.match(/^(\/\/\s*Inside[^\r\n]+\r?\n)/i);d=(f?f[1]:"")+h[1].trimEnd()}}const m=r.match(/\.([a-zA-Z0-9]+)$/);return`\`\`\`${m?m[1]:""}
${d}
\`\`\``}function ay(e){let t=!1,i=!1;for(let n=0;n<e.length;n++){const o=e[n];if(o==="'"&&!i)t=!t;else if(o==='"'&&!t)i=!i;else if(o==="#"&&!t&&!i)return e.slice(0,n).trim()}return e.trim()}function no(e){const t={},i=e.split(/\r?\n/);let n=0;for(;n<i.length;){const o=i[n],s=o.trim();if(!s||s.startsWith("#")){n++;continue}const l=o.indexOf(":");if(l>0){const r=o.slice(0,l).trim();let a=o.slice(l+1).trim();if(a==="|"||a===">"){n++;const c=[];let d=-1;for(;n<i.length;){const m=i[n];if(!m.trim()){c.push(""),n++;continue}const u=m.match(/^(\s+)/),h=u?u[1].length:0;if(d===-1&&(d=h),h<d)break;c.push(m.slice(d)),n++}for(;c.length>0&&c[c.length-1]==="";)c.pop();t[r]=a===">"?c.join(" "):c.join(`
`);continue}if(a=ay(a),!a){let c=n+1;const d=[];let m=-1;for(;c<i.length;){const b=i[c],u=b.trim();if(!u||u.startsWith("#")){m!==-1&&d.push(""),c++;continue}const h=b.match(/^(\s+)/),f=h?h[1].length:0;if(m===-1)if(f>0)m=f;else break;if(f<m)break;d.push(b.slice(m)),c++}if(d.length>0){t[r]=no(d.join(`
`)),n=c;continue}}a.startsWith('"')&&a.endsWith('"')||a.startsWith("'")&&a.endsWith("'")?a=a.slice(1,-1):a==="true"?a=!0:a==="false"?a=!1:a==="null"?a=null:/^-?\d+(?:\.\d+)?$/.test(a)&&(a=Number(a)),t[r]=a}n++}return t}const cy=/^\s*```ya?ml([\s\S]*?)```/;function Ur(e){let t={},i=e.trim();const n=i.match(/^---[^\n\r]*\r?\n([\s\S]*?)\r?\n---(?=[ \t]*(?:\r?\n|$))/);if(n&&!n[1].includes("```")){const s=no(n[1]);if(Object.keys(s).length>0||!n[1].trim())return t=s,i=i.slice(n[0].length).trim(),{frontmatter:t,content:i}}if(i.startsWith("---")){const s=i.match(/^---[^\n\r]*(?:\r?\n|$)/);s&&(i=i.slice(s[0].length).trim())}const o=i.match(cy);if(o)t=no(o[1]),i=i.slice(o[0].length).trim();else{const s=i.split(/\r?\n/),l=[];let r=0;for(let a=0;a<s.length;a++){const c=s[a].trim();if(!c){if(l.length>0){r=a+1;break}continue}if(/^[a-zA-Z0-9_-]+\s*:\s*.*/.test(c)&&!c.startsWith("<")&&!c.startsWith("#"))l.push(c);else{r=a;break}}l.length>0&&(t=no(l.join(`
`)),i=s.slice(r).join(`
`).trim())}return{frontmatter:t,content:i}}function dy(e){const t=e.split(/\r?\n/),i=[];let n=0,o=!1;function s(l){if(n>=l)return;const r=t.slice(n,l).join(`
`).trim();r&&i.push(r),n=l+1}for(let l=0;l<t.length;l++){const a=t[l].trimEnd();if(o){a.includes("-->")&&(o=!1);continue}if(a.startsWith("<!--")){a.includes("-->")||(o=!0);continue}if(a.startsWith("---")){s(l);const c=t[l+1];if(c&&c.trim()&&a.replace(/^-+/,"").trim()==="")for(n=l,l+=1;l<t.length&&t[l].trimEnd()!=="---";l++);}else if(a.trimStart().startsWith("```")){const c=a.match(/^\s*`+/),d=c?c[0].trim():"```";let m=l+1;for(;m<t.length&&!t[m].trimStart().startsWith(d);m++);m<t.length&&(l=m)}}return n<t.length&&s(t.length),i}function oo(e,t={}){const{stripNotesFromMarkdown:i=!0,cleanVClicks:n=!0,cleanShikiLines:o=!0,cleanSlots:s=!0,isolateStyleTags:l=!0,cleanHtmlToMarkdown:r=!0,wrapSuperBlocks:a=!0,virtualFiles:c={}}=t;let d=e;d&&!d.trimStart().startsWith("---")&&(d=`---

${d.trimStart()}`);const m=dy(d),b={};let u="",h="",f=0;if(m.length>0){const G=m[0],X=Ur(G),C=Object.keys(X.frontmatter).length>0,P=X.content.length>0;C&&!P&&m.length>1?(f=1,v(X.frontmatter)):C&&v(X.frontmatter)}function v(G){u=G.title||"",G.theme&&(b[Cn]=String(G.theme)),G.aspectRatio&&(b[$n]=String(G.aspectRatio)),G.highlighter&&(b[Qr]=String(G.highlighter)),G.transition&&(b[In]=String(G.transition)),G.colorSchema&&(b[el]=String(G.colorSchema)),G.layout&&(b[ge]=String(G.layout)),G.background&&(b[Ue]=String(G.background)),G.image&&(b[Bt]=String(G.image)),G.class&&(b[Gi]=String(G.class));for(const[X,C]of Object.entries(G))["theme","aspectRatio","highlighter","transition","colorSchema","title","layout","background","image","class"].includes(X)||(b[`custom-slidev-${X}`]=typeof C=="object"?JSON.stringify(C):String(C))}const k=[];let S=0,$=0,T=0,D=0;const E=new Set,x={};let W=1;for(let G=f;G<m.length;G++){const X=m[G],{frontmatter:C,content:P}=Ur(X),y=X.match(/^\s*(?:---\s*)?src:\s*([^\n\r]+)/m),O=C.src||(y?y[1]:void 0);if(O){const N=String(O).trim().replace(/^['"]|['"]$/g,"");let ae=c[N]||c[N.replace(/^\.\//,"")]||c[`pages/${N.replace(/^.*pages\//,"")}`];if(!ae){const L=N.replace(/^\.\//,""),H=[];if(t.baseDir)try{const g=require("path");H.push(g.resolve(t.baseDir,L)),H.push(g.resolve(t.baseDir,N))}catch{}try{const g=require("path");H.push(g.resolve(process.cwd(),L)),H.push(g.resolve(process.cwd(),N))}catch{}for(const g of H){const j=Ba(g);if(j!==null){ae=j;break}}}const ue={};C.layout&&(ue[ge]=String(C.layout)),C.transition&&(ue[tt]=String(C.transition)),C.background&&(ue[Ue]=String(C.background)),C.image&&(ue[Bt]=String(C.image)),C.class&&(ue[Gi]=String(C.class));for(const[L,H]of Object.entries(C))["src","layout","transition","background","image","class"].includes(L)||(ue[`custom-slidev-${L}`]=typeof H=="object"?JSON.stringify(H):String(H));if(ae){const L=oo(ae,{...t,virtualFiles:c});for(const H of L.slides){H.pageIndex=W++,H.pageAttrs={...ue,...H.pageAttrs},k.push(H);const g=H.pageAttrs[ge]||"default";x[g]=(x[g]||0)+1}continue}else{k.push({pageIndex:W++,pageAttrs:{...ue,"custom-slidev-src":N},notes:"",rawMarkdown:`> 📄 **引入外部幻灯片页面**: \`${N}\`
>
> *提示：如需展示该页面完整内容，请将关联子页面一同打包为 .zip 或通过本地工程导入。*`,hasVueComponent:!1,hasStyleTag:!1,assetReferences:[]});const L=ue[ge]||"default";x[L]=(x[L]||0)+1;continue}}const U={};C.layout&&(U[ge]=String(C.layout)),C.transition&&(U[tt]=String(C.transition)),C.background&&(U[Ue]=String(C.background)),C.image&&(U[Bt]=String(C.image)),C.class&&(U[Gi]=String(C.class)),C.mask&&(U[vi]=String(C.mask)),(C.maskRatio||C["mask-ratio"])&&(U[bi]=String(C.maskRatio||C["mask-ratio"])),(C.maskStyle||C["mask-style"])&&(U[yi]=String(C.maskStyle||C["mask-style"])),(C.maskInitial||C["mask-initial"])&&(U[ki]=String(C.maskInitial||C["mask-initial"]));for(const[N,ae]of Object.entries(C))["layout","transition","background","image","class","mask","maskRatio","mask-ratio","maskStyle","mask-style","maskInitial","mask-initial"].includes(N)||(U[`custom-slidev-${N}`]=typeof ae=="object"?JSON.stringify(ae):String(ae));let B=P;const R=[];let F=B.replace(/(?:^[ \t]*(`{3,}|~{3,})[^\n\r]*\r?\n[\s\S]*?\r?\n[ \t]*\1(?=[ \t]*(?:\r?\n|$)))/gm,N=>{const ae=`__CODE_TOKEN_NOTE_${R.length}__`;return R.push(N),ae});F=F.replace(/(`+)(?:[^\n\r`]|(?!\1)`)+?\1/g,N=>{const ae=`__CODE_TOKEN_NOTE_${R.length}__`;return R.push(N),ae});let ee="";const I=Array.from(F.matchAll(/<!--([\s\S]*?)-->/g));if(I.length>0){const N=I[I.length-1],ae=F.slice(N.index+N[0].length).trim();if(!ae||!ae.replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi,"").trim()){const L=N[1].trim();L.startsWith("TODO:")||(ee=L,S++),i&&(F=F.slice(0,N.index).trimEnd()+F.slice(N.index+N[0].length))}}i&&(F=F.replace(/<!--(?![\s\S]*?TODO:)[\s\S]*?-->/g,"").trim());for(let N=0;N<R.length;N++)F=F.replace(`__CODE_TOKEN_NOTE_${N}__`,R[N]);if(B=F,ee){for(let ue=0;ue<R.length;ue++)ee=ee.replace(`__CODE_TOKEN_NOTE_${ue}__`,R[ue]);const ae=`> [!NOTE] 💡 演讲备注
${ee.split(/\r?\n/).map(ue=>`> ${ue}`).join(`
`)}
{: custom-slidev-note="true"}`;B=B?`${B}

${ae}`:ae}let M=!1;if(/<style\b/i.test(B)){M=!0;const N=B.match(/<style\b[^>]*>([\s\S]*?)<\/style>/gi);if(N){for(const ae of N){const ue=ae.replace(/<style\b[^>]*>|<\/style>/gi,"").trim();h=h?`${h}

${ue}`:ue}l&&(B=B.replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi,"").trim())}}const J=B.match(/<v-click[^>]*>|<v-clicks[^>]*>|v-click=/g);J&&($+=J.length);const Y=B.match(/```\w+\s+\{[^}]+\}/g);Y&&(T+=Y.length);const te=B.match(/::\w+::|<template\s+#[^>]+>/g);if(te&&(D+=te.length),B=B.replace(/^[ \t]*<<<[ \t]+([^\n\r]+)/gm,N=>ly(N,{...t,virtualFiles:c})||N),n&&(B=B.replace(/<v-click(?:\s+at="[^"]*")?(?:\s+hide)?>\s*([\s\S]*?)\s*<\/v-click>/gi,"$1")),o&&(B=B.replace(/(^```\w+(?:[ \t]+\[[^\]]*\])?)[ \t]+\{[^}]+\}(?:[ \t]+\w+)?/gm,"$1"),B=B.replace(/^\$\$\s+\{[^}]+\}/gm,()=>"$$")),s&&(B=B.replace(/^::\w+::\s*$/gm,"")),r&&(B=kf(B)),a){let N=B.trim(),ae="";const ue=N.lastIndexOf("> [!NOTE] 💡 演讲备注");if(ue!==-1&&(ae=N.slice(ue),N=N.slice(0,ue).trim()),(C.layout==="image-left"||C.layout==="image-right")&&C.image){const L=String(C.image).trim(),H=C.layout==="image-left"?"image-left":"image-right",g=`![配图](${L})
{: custom-slidev-layout="${H}" }`;C.layout==="image-left"?N=`{{{col

${g}

${N}

}}}`:N=`{{{col

${N}

${g}

}}}`}if(C.background){const H=`![背景图](${String(C.background).trim()})
{: custom-slidev-role="background" }`;N=N?`${H}

${N}`:H}B=ae?`${N}

${ae}`:N}const ie=uy(B);U[Ue]&&ie.push(U[Ue]),U[Bt]&&ie.push(U[Bt]);for(const N of ie)E.add(N);const pe=/<[A-Z][a-zA-Z0-9]+/.test(B),le=U[ge]||(W===1?b[ge]||"cover":"default");x[le]=(x[le]||0)+1,k.push({pageIndex:W++,pageAttrs:U,notes:ee,rawMarkdown:B,hasVueComponent:pe,hasStyleTag:M,assetReferences:ie})}if(!u&&k.length>0){const G=k[0].rawMarkdown.match(/^#\s+(.+)$/m);G&&(u=G[1].trim())}h&&(b["custom-slidev-custom-css"]=h);let V=k.map(G=>`---

${G.rawMarkdown}`).join(`

`);return V.trimStart().startsWith("---")||(V=`---

${V.trimStart()}`),{docTitle:u||"Slidev 演示文稿",docRootAttrs:b,slides:k,totalSlides:k.length,stats:{totalNotes:S,totalVClicks:$,totalShikiHighlights:T,totalSlots:D,discoveredAssets:Array.from(E),layoutDistribution:x},flattenedMarkdown:V,customCss:h}}function uy(e){const t=[],i=/!\[.*?\]\((.*?)\)/g;let n;for(;(n=i.exec(e))!==null;){const s=n[1].split(/\s+/)[0].trim();s&&t.push(s)}const o=/<(?:img|video|source|audio)\b[^>]*src=["'](.*?)["']/gi;for(;(n=o.exec(e))!==null;){const s=n[1].trim();s&&t.push(s)}return t}function Ma(e){if(!e)return!1;const t=String(e.type||"").toLowerCase(),i=String(e.markdown||"").trim(),n=String(e.content||"").trim();return t==="tb"||t==="thematic-break"||t==="nodethematicbreak"||i==="---"||i==="***"||n==="---"||n==="***"}function fy(e){return(e.trim()||"Slidev 演示文稿").replace(/[\\/:*?"<>|]/g,"_")}async function py(e,t,i=De){const n=e.filter(Ma);let o=0;if(n.length>=t.length)for(let s=0;s<t.length;s++){const l=t[s],r=n[s];r&&r.id&&Object.keys(l.pageAttrs||{}).length>0&&(await i(r.id,l.pageAttrs),o++)}else for(let s=1;s<t.length;s++){const l=t[s],r=n[s-1];r&&r.id&&Object.keys(l.pageAttrs||{}).length>0&&(await i(r.id,l.pageAttrs),o++)}return o}async function hy(e,t=De){let i=!1,n=0;for(const o of e){if(Ma(o)){i=!1;continue}const s=(o.markdown||o.content||"").trim();if(s==="::right::"||s.startsWith("::right::")){i=!0;continue}i&&o.id&&(await t(o.id,{[Ee]:"right"}).catch(()=>{}),n++)}return n}async function my(e,t,i=Yr){const n={};if(!t||t.length===0)return n;const o=[];for(const s of t){const l=new File([s.data],s.fileName,{type:"application/octet-stream"});o.push(l)}try{const s=await i("/data/assets",o);if(s!=null&&s.succMap)for(const[l,r]of Object.entries(s.succMap))n[l]=String(r)}catch(s){console.warn("上传本地静态资产失败，保留原路径:",s)}return Object.keys(n).length>0&&ry(e,n),n}async function gy(e){var T;const{presentation:t,notebookId:i,docTitle:n,extractedAssets:o=[],uploadAssets:s=!0,autoPreview:l=!0,plugin:r,api:a={}}=e,c=a.uploadFn||Yr,d=a.createDocFn||Ec,m=a.setAttrsFn||De,b=a.getChildBlocksFn||co,u=a.openTabFn||he.openTab,h=a.showMessageFn||he.showMessage;s&&o.length>0&&await my(t,o,c);const f=fy(n),v=`/${f}`,k=await d(i,v,t.flattenedMarkdown);if(!k)throw new Error("思源内核创建文档失败，未返回有效 DocumentId");const S=((T=t.slides[0])==null?void 0:T.pageAttrs)||{};await m(k,{...S,...t.docRootAttrs});const $=await b(k).catch(()=>[]);return Array.isArray($)&&$.length>0&&(await py($,t.slides,m),await hy($,m)),h(`🎉 成功导入 Slidev 演示文档《${f}》！`),l&&r&&(r.currentDocId=k,await u({app:r.app,doc:{id:k}}),r.openBottomPreviewTab&&r.openBottomPreviewTab()),k}function vy(e){const t=ve("file"),i=ve(!1),n=ve(!1),o=ve(""),s=ve(null),l=ve(null),r=ve(""),a=ve(0),c=ve(""),d=ve([]),m=ve(null),b=ve(""),u=ve([]),h=ve(""),f=ve(!0),v=ve(!0),k=ve(!0),S=ve(!0),$=_e(()=>{const U=a.value;if(U===0)return"0 B";const B=1024,R=["B","KB","MB","GB"],F=Math.floor(Math.log(U)/Math.log(B));return`${(U/B**F).toFixed(1)} ${R[F]}`}),T=_e(()=>{var U;return((U=m.value)==null?void 0:U.docRootAttrs["custom-slidev-theme"])||"default"}),D=_e(()=>{var U;return d.value.length>0?d.value.length:((U=m.value)==null?void 0:U.stats.discoveredAssets.length)||0}),E=_e(()=>{var B;const U=((B=m.value)==null?void 0:B.stats.layoutDistribution)||{};return Object.entries(U).map(([R,F])=>({name:R,count:F}))});async function x(U=Ic){try{const B=await U();B!=null&&B.notebooks&&Array.isArray(B.notebooks)&&(u.value=B.notebooks.filter(R=>!R.closed),u.value.length>0&&!h.value&&(h.value=u.value[0].id))}catch(B){console.warn("获取笔记本列表失败:",B)}}function W(){var U;(U=s.value)==null||U.click()}function V(){l.value=null,r.value="",a.value=0,m.value=null,d.value=[],o.value=""}async function G(U){o.value="",l.value=U,r.value=U.name,a.value=U.size;try{if(U.name.toLowerCase().endsWith(".zip")){const R=await U.arrayBuffer(),F=await sy(R);if(!F.entryMarkdown){o.value="未在 Zip 压缩包中找到 slides.md 或任何有效的 Markdown 入口文件";return}d.value=F.assets;const ee=oo(F.entryMarkdown,{stripNotesFromMarkdown:v.value,cleanHtmlToMarkdown:f.value,cleanSlots:!1,virtualFiles:F.virtualFiles});m.value=ee,b.value=ee.docTitle||U.name.replace(/\.zip$/i,"")}else{const R=await U.text();d.value=[];const F=U.path||"",ee=F?F.replace(/[\\/][^\\/]+$/,""):"",I=oo(R,{stripNotesFromMarkdown:v.value,cleanHtmlToMarkdown:f.value,cleanSlots:!1,baseDir:ee||void 0});m.value=I,b.value=I.docTitle||U.name.replace(/\.md$/i,"")}}catch(B){console.error("解析文件失败:",B),o.value=`解析文件失败: ${B.message||String(B)}`}}function X(){if(o.value="",!c.value.trim()){m.value=null;return}try{const U=oo(c.value,{stripNotesFromMarkdown:v.value,cleanHtmlToMarkdown:f.value,cleanSlots:!1});m.value=U,b.value=U.docTitle||"Slidev 演示文稿"}catch(U){o.value=`解析 Markdown 源码失败: ${U.message||String(U)}`}}async function C(){l.value?await G(l.value):c.value&&X()}async function P(U){const B=U.target;B.files&&B.files[0]&&await G(B.files[0])}async function y(U){var B;i.value=!1,(B=U.dataTransfer)!=null&&B.files&&U.dataTransfer.files[0]&&await G(U.dataTransfer.files[0])}async function O(U=e){if(m.value){if(!h.value&&u.value.length>0&&(h.value=u.value[0].id),!h.value){o.value="请先选择目标笔记本";return}n.value=!0,o.value="";try{return await gy({presentation:m.value,notebookId:h.value,docTitle:b.value,extractedAssets:d.value,uploadAssets:k.value,autoPreview:S.value,plugin:U})}catch(B){console.error("导入 Slidev 演示失败:",B),o.value=`导入执行失败: ${B.message||String(B)}`}finally{n.value=!1}}}return{inputMode:t,isDragging:i,isImporting:n,errorMessage:o,fileInputRef:s,selectedFile:l,selectedFileName:r,selectedFileSize:a,rawMarkdownText:c,extractedAssets:d,parsedPresentation:m,customDocTitle:b,notebooks:u,selectedNotebookId:h,optCleanHtml:f,optStripNotes:v,optUploadAssets:k,optAutoPreview:S,formattedFileSize:$,currentTheme:T,extractedAssetsCount:D,layoutChips:E,fetchNotebooks:x,triggerFileInput:W,clearFile:V,processFile:G,onFileSelected:P,onFileDrop:y,onTextChange:X,reprocessCurrentInput:C,handleConfirmImport:O}}const by={class:"spm-import-dialog"},yy={class:"spm-tabs-header"},ky={class:"spm-dialog-body"},wy={key:0,class:"spm-file-section"},xy={key:0,class:"spm-dropzone-prompt"},Sy={class:"spm-dropzone-icon"},_y={key:1,class:"spm-dropzone-active"},Cy={class:"spm-file-badge"},$y={class:"spm-file-size"},Iy={key:1,class:"spm-text-section"},Ey={key:2,class:"spm-error-banner"},Ty={key:3,class:"spm-preview-card"},Ay={class:"spm-preview-card__header"},By={style:{display:"inline-flex","align-items":"center",gap:"4px"}},My={class:"spm-config-grid"},Dy={class:"spm-form-item"},Ly={class:"spm-form-item"},Oy=["value"],Ry={class:"spm-stats-grid"},Py={class:"spm-stat-box"},Ny={class:"spm-stat-value"},zy={class:"spm-stat-box"},Fy={class:"spm-stat-value"},Hy={class:"spm-stat-box"},jy={class:"spm-stat-value"},Wy={class:"spm-stat-box"},Uy={class:"spm-stat-value"},Vy={key:0,class:"spm-chips-row"},Ky={class:"spm-options-group"},qy={class:"spm-checkbox-label"},Gy={class:"spm-checkbox-label"},Zy={class:"spm-checkbox-label"},Yy={class:"spm-checkbox-label"},Jy={class:"spm-dialog-footer"},Xy=["disabled"],Qy=["disabled"],e0={key:0,style:{display:"inline-flex","align-items":"center",gap:"4px"}},t0={key:1,style:{display:"inline-flex","align-items":"center",gap:"4px"}},i0=Ct({__name:"SlidevImportDialog",emits:["close","success"],setup(e,{emit:t}){const i=t,n=ei("plugin"),{inputMode:o,isDragging:s,isImporting:l,errorMessage:r,fileInputRef:a,selectedFileName:c,rawMarkdownText:d,extractedAssetsCount:m,parsedPresentation:b,customDocTitle:u,notebooks:h,selectedNotebookId:f,optCleanHtml:v,optStripNotes:k,optUploadAssets:S,optAutoPreview:$,formattedFileSize:T,currentTheme:D,layoutChips:E,fetchNotebooks:x,triggerFileInput:W,clearFile:V,onFileSelected:G,onFileDrop:X,onTextChange:C,reprocessCurrentInput:P,handleConfirmImport:y}=vy(n);Fn(async()=>{await x()});async function O(){const B=await y();B&&(i("success",{docId:B}),i("close"))}function U(){i("close")}return(B,R)=>(oe(),se("div",{class:"spm-modal-overlay",onClick:Mt(U,["self"])},[p("div",by,[p("div",{class:"spm-dialog-header"},[R[18]||(R[18]=p("div",{class:"spm-dialog-title"},[p("svg",{class:"spm-dialog-icon","aria-hidden":"true"},[p("use",{"xlink:href":"#iconSlidev"})]),p("span",null,"导入 Slidev 演示文档")],-1)),p("button",{class:"spm-close-btn",title:"关闭",onClick:U},"✕")]),p("div",yy,[p("button",{class:Ie(["spm-tab-btn",{active:ye(o)==="file"}]),onClick:R[0]||(R[0]=F=>o.value="file")},[de(fe,{name:"package"}),R[19]||(R[19]=p("span",null,"文件 / 压缩包导入 (.zip / .md)",-1))],2),p("button",{class:Ie(["spm-tab-btn",{active:ye(o)==="text"}]),onClick:R[1]||(R[1]=F=>o.value="text")},[de(fe,{name:"notes"}),R[20]||(R[20]=p("span",null,"粘贴 Markdown 源码",-1))],2)]),p("div",ky,[ye(o)==="file"?(oe(),se("div",wy,[p("div",{class:Ie(["spm-dropzone",{dragover:ye(s),"has-file":!!ye(c)}]),onDragover:R[4]||(R[4]=Mt(F=>s.value=!0,["prevent"])),onDragleave:R[5]||(R[5]=Mt(F=>s.value=!1,["prevent"])),onDrop:R[6]||(R[6]=Mt((...F)=>ye(X)&&ye(X)(...F),["prevent"])),onClick:R[7]||(R[7]=(...F)=>ye(W)&&ye(W)(...F))},[p("input",{ref_key:"fileInputRef",ref:a,type:"file",accept:".zip,.md",class:"spm-hidden-input",onChange:R[2]||(R[2]=(...F)=>ye(G)&&ye(G)(...F))},null,544),ye(c)?(oe(),se("div",_y,[p("span",Cy,[de(fe,{name:"notes"}),$t(" "+Se(ye(c)),1)]),p("span",$y,"("+Se(ye(T))+")",1),p("button",{class:"spm-btn-text",onClick:R[3]||(R[3]=Mt((...F)=>ye(V)&&ye(V)(...F),["stop"]))},"更换文件")])):(oe(),se("div",xy,[p("span",Sy,[de(fe,{name:"folder",style:{"font-size":"32px"}})]),R[21]||(R[21]=p("p",{class:"spm-dropzone-text"},"点击选择文件，或直接拖拽文件至此处",-1)),R[22]||(R[22]=p("p",{class:"spm-dropzone-hint"},[$t(" 支持 Slidev 完整工程 "),p("strong",null,".zip"),$t("（自动解包 public/ 静态素材）或单文件 "),p("strong",null,".md")],-1))]))],34)])):(oe(),se("div",Iy,[Tt(p("textarea",{"onUpdate:modelValue":R[8]||(R[8]=F=>Qe(d)?d.value=F:null),class:"spm-textarea spm-source-editor",rows:"8",placeholder:"在此直接粘贴包含 Frontmatter 的 Slidev slides.md 源码...",onInput:R[9]||(R[9]=(...F)=>ye(C)&&ye(C)(...F))},null,544),[[So,ye(d)]])])),ye(r)?(oe(),se("div",Ey," ⚠️ "+Se(ye(r)),1)):Re("",!0),ye(b)?(oe(),se("div",Ty,[p("div",Ay,[p("span",By,[de(fe,{name:"sparkles"}),R[23]||(R[23]=$t(" 演示解析摘要",-1))]),R[24]||(R[24]=p("span",{class:"spm-badge-success"},"预检就绪",-1))]),p("div",My,[p("div",Dy,[R[25]||(R[25]=p("label",{class:"spm-form-label"},"笔记文档标题",-1)),Tt(p("input",{"onUpdate:modelValue":R[10]||(R[10]=F=>Qe(u)?u.value=F:null),class:"spm-input",placeholder:"思源新文档标题"},null,512),[[So,ye(u)]])]),p("div",Ly,[R[26]||(R[26]=p("label",{class:"spm-form-label"},"存放目标笔记本",-1)),Tt(p("select",{"onUpdate:modelValue":R[11]||(R[11]=F=>Qe(f)?f.value=F:null),class:"spm-select"},[(oe(!0),se(Ke,null,kt(ye(h),F=>(oe(),se("option",{key:F.id,value:F.id},Se(F.name),9,Oy))),128))],512),[[Qu,ye(f)]])])]),p("div",Ry,[p("div",Py,[p("span",Ny,Se(ye(b).totalSlides),1),R[27]||(R[27]=p("span",{class:"spm-stat-label"},"幻灯片页数",-1))]),p("div",zy,[p("span",Fy,Se(ye(D)),1),R[28]||(R[28]=p("span",{class:"spm-stat-label"},"演示主题",-1))]),p("div",Hy,[p("span",jy,Se(ye(b).stats.totalNotes),1),R[29]||(R[29]=p("span",{class:"spm-stat-label"},"演讲者提词",-1))]),p("div",Wy,[p("span",Uy,Se(ye(m)),1),R[30]||(R[30]=p("span",{class:"spm-stat-label"},"关联本地素材",-1))])]),ye(E).length>0?(oe(),se("div",Vy,[R[31]||(R[31]=p("span",{class:"spm-chips-label"},"页面版式分布：",-1)),(oe(!0),se(Ke,null,kt(ye(E),F=>(oe(),se("span",{key:F.name,class:"spm-chip-badge"},Se(F.name)+": "+Se(F.count),1))),128))])):Re("",!0),p("div",Ky,[p("label",qy,[Tt(p("input",{"onUpdate:modelValue":R[12]||(R[12]=F=>Qe(v)?v.value=F:null),type:"checkbox",onChange:R[13]||(R[13]=(...F)=>ye(P)&&ye(P)(...F))},null,544),[[Yn,ye(v)]]),R[32]||(R[32]=p("span",null,"智能剥离展示型 HTML 容器为干净原生的 Markdown 笔记块",-1))]),p("label",Gy,[Tt(p("input",{"onUpdate:modelValue":R[14]||(R[14]=F=>Qe(k)?k.value=F:null),type:"checkbox",onChange:R[15]||(R[15]=(...F)=>ye(P)&&ye(P)(...F))},null,544),[[Yn,ye(k)]]),R[33]||(R[33]=p("span",null,"提取演讲者提词到块属性并保持正文笔记清爽",-1))]),p("label",Zy,[Tt(p("input",{"onUpdate:modelValue":R[16]||(R[16]=F=>Qe(S)?S.value=F:null),type:"checkbox"},null,512),[[Yn,ye(S)]]),R[34]||(R[34]=p("span",null,"自动上传关联素材至思源资产库并重写路径 (assets/...)",-1))]),p("label",Yy,[Tt(p("input",{"onUpdate:modelValue":R[17]||(R[17]=F=>Qe($)?$.value=F:null),type:"checkbox"},null,512),[[Yn,ye($)]]),R[35]||(R[35]=p("span",null,"导入后自动打开新文档并开启下方分屏放映预览",-1))])])])):Re("",!0)]),p("div",Jy,[p("button",{class:"spm-btn-secondary",disabled:ye(l),onClick:U}," 取消 ",8,Xy),p("button",{class:"spm-btn-primary",disabled:!ye(b)||ye(l),onClick:O},[ye(l)?(oe(),se("span",e0,[de(fe,{name:"refresh"}),R[36]||(R[36]=$t(" 正在导入生成中...",-1))])):(oe(),se("span",t0,[de(fe,{name:"rocket"}),R[37]||(R[37]=$t(" 确认导入思源笔记",-1))]))],8,Qy)])])]))}}),n0=zt(i0,[["__scopeId","data-v-2eff6f1e"]]);function Da(e){return e?e==="NodeThematicBreak"||e==="tb"||e==="thematic-break":!1}function o0(e,t){var r;if(!e||e.length===0)return null;const i=t.activeBlockId||"",n=t.currentTopBlockId||i,o=t.currentPageDividerId||"",s=t.activeBlockType||"";if(Da(s)&&i){let a=e.find(c=>c.startBlockId===i);if(a||(a=e.find(c=>{var d,m;return((m=(d=c.blocks)==null?void 0:d[0])==null?void 0:m.id)===i}),a)||(a=e.find(c=>{var d;return(d=c.allBlockIds)==null?void 0:d.includes(i)}),a))return a}if(o){let a=e.find(c=>c.startBlockId===o);if(a||(a=e.find(c=>{var d,m;return((m=(d=c.blocks)==null?void 0:d[0])==null?void 0:m.id)===o}),a))return a}if(i){let a=e.find(d=>d.startBlockId===i);if(a||(a=e.find(d=>{var m,b;return((m=d.blocks)==null?void 0:m.some(u=>u.id===i))||((b=d.allBlockIds)==null?void 0:b.includes(i))}),a)||n&&n!==i&&(a=e.find(d=>{var m,b;return((m=d.blocks)==null?void 0:m.some(u=>u.id===n))||((b=d.allBlockIds)==null?void 0:b.includes(n))}),a)||(a=e.find(d=>{var m;return(m=d.noteBlocks)==null?void 0:m.some(b=>b.id===i||b.id===n)}),a))return a;const c=(r=t.activeBlockAttrs)==null?void 0:r[Ee];if(c&&["col-1","col-2","col-3"].includes(c)&&(a=e.find(d=>{var m,b;return((m=d.frontmatter)==null?void 0:m.layout)==="three-cols-header"||((b=d.blocks)==null?void 0:b.some(u=>u.slot==="col-1"||u.slot==="col-2"||u.slot==="col-3"))}),a))return a}return e[0]||null}function Vr(e,t){const i=(e.blocks||[]).filter(l=>{const r=(l.content||l.rawMarkdown||"").trim();return r&&r!=="---"});if(i.length===0)return"本页暂无内容，建议过渡承接上下文。";const n=[],o=[];for(const l of i){const r=(l.content||l.rawMarkdown||"").trim();r&&(l.type==="h"||r.startsWith("#")?n.push(r.replace(/^#+\s*/,"")):o.push(r.slice(0,50)))}const s=[];return n.length>0&&s.push(`【核心重点】：${n.join("、")}`),o.length>0&&(s.push("【口播要点】："),o.slice(0,3).forEach((l,r)=>{s.push(`${r+1}. 讲解 ${l}`)})),s.push("【过渡提示】：注意观察听众反应，适时抛出互动提问。"),s.join(`
`)}async function La(e,t){const i=e.blocks&&e.blocks.length>0?e.blocks.map(n=>(n.content||n.rawMarkdown||"").trim()).filter(n=>n&&n!=="---").join(`
`):(e.rawMarkdown||"").replace(/^---\s*$/gm,"").trim();if(t&&i){const n=`你是一位专业的演讲教练。请根据以下幻灯片内容，提炼出简短精炼的演讲口播提词卡（Notes），包含核心观点与口播要点，总字数在 150 字以内：
${i}`;try{const o=await t(n);if(o&&o.trim())return{notes:o.trim(),isAiGenerated:!0}}catch(o){return{notes:Vr(e),isAiGenerated:!1,error:(o==null?void 0:o.message)||"AI 调用异常"}}}return{notes:Vr(e),isAiGenerated:!1}}async function s0(e,t){return(await La(e,t)).notes}function Kr(e,t){if(!t)return!1;if(e===t||typeof document>"u")return!0;const i=document.querySelector(`.protyle-wysiwyg [data-node-id="${t}"]`)||document.querySelector(`[data-node-id="${t}"]`);if(!i)return!1;const n=i.querySelector(":scope > [data-node-id], :scope > div > [data-node-id]");return(n==null?void 0:n.getAttribute("data-node-id"))===e}function r0(e){const t=ve(!1);let i=null;function n(I="已同步"){e.saveStatus.value=I,i&&(typeof window<"u"?window.clearTimeout(i):clearTimeout(i));const M=()=>{e.saveStatus.value=""};typeof window<"u"?i=window.setTimeout(M,1200):i=setTimeout(M,1200)}async function o(I){var te;const M=e.activeBlockId.value||e.currentDocId.value;if(!M)return;for(const[ie,pe]of Object.entries(I))e.activeBlockAttrs.value[ie]=pe;Be.setBlockAttrOverride(M,I),Je(M,I);const J=(te=e.parentContainerId)==null?void 0:te.value,Y=!!(J&&Kr(M,J));if(We in I&&Y&&J){const ie=I[We];e.parentContainerClicks&&(e.parentContainerClicks.value=ie),Be.setBlockAttrOverride(J,{[We]:ie}),Je(J,{[We]:ie}),De(J,{[We]:ie}).catch(()=>{})}if(ge in I){const ie=I[ge];e.currentPageDividerLayout.value=ie,e.targetSlide.value&&(e.targetSlide.value.frontmatter||(e.targetSlide.value.frontmatter={}),e.targetSlide.value.frontmatter.layout=ie)}if(lt in I){const ie=I[lt];e.targetSlide.value&&(e.targetSlide.value.frontmatter||(e.targetSlide.value.frontmatter={}),e.targetSlide.value.frontmatter.layoutRatio=ie)}n("保存中...");try{await De(M,I),n("已同步"),e.plugin&&await e.plugin.compileCurrentDocument()}catch{n("同步失败")}}async function s(I,M){var ie;const J=e.activeBlockId.value||e.currentDocId.value;if(!J)return;e.activeBlockAttrs.value[I]=M,Be.setBlockAttrOverride(J,{[I]:M}),Je(J,{[I]:M});const Y=(ie=e.parentContainerId)==null?void 0:ie.value,te=!!(Y&&Kr(J,Y));I===We&&te&&Y&&(e.parentContainerClicks&&(e.parentContainerClicks.value=M),Be.setBlockAttrOverride(Y,{[We]:M}),Je(Y,{[We]:M}),De(Y,{[We]:M}).catch(()=>{})),I===ge&&(e.currentPageDividerLayout.value=M,e.targetSlide.value&&(e.targetSlide.value.frontmatter||(e.targetSlide.value.frontmatter={}),e.targetSlide.value.frontmatter.layout=M)),I===lt&&e.targetSlide.value&&(e.targetSlide.value.frontmatter||(e.targetSlide.value.frontmatter={}),e.targetSlide.value.frontmatter.layoutRatio=M),n("保存中...");try{await De(J,{[I]:M}),n("已同步"),e.plugin&&await e.plugin.compileCurrentDocument()}catch{n("同步失败")}}function l(){const I=e.activeBlockType.value==="NodeThematicBreak"||e.activeBlockType.value==="NodeThematicBreakBlock"||e.activeBlockType.value==="hr"||e.activeBlockType.value==="thematicbreak";return e.currentPageDividerId.value||(I?e.activeBlockId.value:"")||e.currentDocId.value}async function r(I,M){const J=l();if(J){J===e.activeBlockId.value&&(e.activeBlockAttrs.value[I]=M),Be.setBlockAttrOverride(J,{[I]:M}),Je(J,{[I]:M}),I===ge&&(e.currentPageDividerLayout.value=M,e.targetSlide.value&&(e.targetSlide.value.frontmatter||(e.targetSlide.value.frontmatter={}),e.targetSlide.value.frontmatter.layout=M)),I===lt&&e.targetSlide.value&&(e.targetSlide.value.frontmatter||(e.targetSlide.value.frontmatter={}),e.targetSlide.value.frontmatter.layoutRatio=M),n("保存中...");try{await De(J,{[I]:M}),n("已同步"),e.plugin&&await e.plugin.compileCurrentDocument()}catch{n("同步失败")}}}async function a(I,M){const J=l();if(!J)return;const Y={[ge]:I,[lt]:M};J===e.activeBlockId.value&&(e.activeBlockAttrs.value[ge]=I,e.activeBlockAttrs.value[lt]=M),e.currentPageDividerLayout.value=I,Be.setBlockAttrOverride(J,Y),Je(J,Y),e.targetSlide.value&&(e.targetSlide.value.frontmatter||(e.targetSlide.value.frontmatter={}),e.targetSlide.value.frontmatter.layout=I,e.targetSlide.value.frontmatter.layoutRatio=M),n("应用排版中...");try{await De(J,Y),n("已应用分栏与比例"),e.plugin&&await e.plugin.compileCurrentDocument()}catch{n("应用失败")}}async function c(I,M){var Y;const J=e.currentDocId.value||e.activeBlockId.value;if(J){e.activeBlockAttrs.value[I]=M,Be.setBlockAttrOverride(J,{[I]:M}),Je(J,{[I]:M}),(Y=e.latestDoc.value)!=null&&Y.config&&(I===Cn&&(e.latestDoc.value.config.theme=M),I===$n&&(e.latestDoc.value.config.aspectRatio=M),I===In&&(e.latestDoc.value.config.defaultTransition=M)),n("更新中...");try{await De(J,{[I]:M}),n("已更新"),e.plugin&&await e.plugin.compileCurrentDocument(J)}catch{n("更新失败")}}}async function d(){(e.videoAutoplay.value?"false":"true")==="true"?(await o({[Di]:"true",[Ki]:"true"}),e.activeBlockAttrs.value[Di]="true",e.activeBlockAttrs.value[Ki]="true"):(await s(Di,"false"),e.activeBlockAttrs.value[Di]="false")}async function m(){const I=e.videoLoop.value?"false":"true";await s(uo,I)}async function b(){const I=e.videoMuted.value?"false":"true";await s(Ki,I)}async function u(){const I=e.videoControls.value?"false":"true";await s(fo,I)}async function h(I){var ie;const M=e.activeBlockId.value;if(!M)return;const J=e.rawSnippet.value||"",Y=wi(J)||"",te=e.currentPageDividerId.value||e.currentDocId.value;if(I)if(I==="background"){const pe={[Ge]:"background",[ge]:""};te&&Y&&(e.pageBackground.value=Y,await De(te,{[Ue]:Y}).catch(()=>{}),Be.setBlockAttrOverride(te,{[Ue]:Y}),Je(te,{[Ue]:Y}),e.targetSlide.value&&(e.targetSlide.value.frontmatter||(e.targetSlide.value.frontmatter={}),e.targetSlide.value.frontmatter.background=Y)),await o(pe)}else(I===po||I===ho)&&await o({[ge]:I,[Ge]:""});else{const pe={[Ge]:"",[ge]:""};if(e.activeBlockAttrs.value[Ue]==="true"&&(pe[Ue]=""),te&&Y&&e.pageBackground.value===Y&&(e.pageBackground.value="",await De(te,{[Ue]:""}).catch(()=>{}),Be.setBlockAttrOverride(te,{[Ue]:""}),Je(te,{[Ue]:""}),(ie=e.targetSlide.value)!=null&&ie.frontmatter&&delete e.targetSlide.value.frontmatter.background),await o(pe),typeof document<"u"){const le=document.querySelector(`.protyle-wysiwyg [data-node-id="${M}"]`),N=le==null?void 0:le.closest('[data-type="NodeListItem"]'),ae=N==null?void 0:N.getAttribute("data-node-id");if(ae&&ae!==M){const ue={[ge]:"",[Ge]:""};Je(ae,ue),Be.setBlockAttrOverride(ae,ue),await De(ae,ue).catch(()=>{})}}}}async function f(I){var ae,ue,L,H,g,j,z,_;const Y=`> [!NOTE] 💡 演讲备注
${(I||"在此输入本页讲稿提词...").split(/\r?\n/).map(w=>`> ${w}`).join(`
`)}
{: custom-slidev-note="true"}`,te=((ae=e.latestDoc.value)==null?void 0:ae.slides)||[],ie=e.targetSlide.value,pe=ie?te.findIndex(w=>w===ie):-1;let le=null;if(pe!==-1&&pe<te.length-1){const w=te[pe+1];le=await Ai("markdown",Y,w.startBlockId)}else{const w=((ue=ie==null?void 0:ie.noteBlocks)==null?void 0:ue.slice(-1)[0])||((L=ie==null?void 0:ie.blocks)==null?void 0:L.slice(-1)[0]),A=(w==null?void 0:w.id)||(ie==null?void 0:ie.startBlockId);A?le=await Ai("markdown",Y,void 0,A):le=await ss("markdown",Y,e.currentDocId.value)}const N=((j=(g=(H=le==null?void 0:le[0])==null?void 0:H.doOperations)==null?void 0:g[0])==null?void 0:j.id)||((z=le==null?void 0:le[0])==null?void 0:z.id);return N&&(await De(N,{[nt]:"true"}),Be.setBlockAttrOverride(N,{[nt]:"true"}),Ni(N,(_=e.plugin)==null?void 0:_.app)),e.plugin&&await e.plugin.compileCurrentDocument(),N}async function v(){const I=e.activeBlockId.value;if(I)if(e.isNoteBlock.value){n("取消中...");try{await De(I,{[nt]:"","slidev-note":""}),Be.setBlockAttrOverride(I,{[nt]:"","slidev-note":""}),Je(I,{[nt]:"","slidev-note":""}),delete e.activeBlockAttrs.value[nt],delete e.activeBlockAttrs.value["slidev-note"],n("已取消备注"),he.showMessage("已取消讲稿备注"),e.plugin&&await e.plugin.compileCurrentDocument()}catch(M){console.error("[SiYuanSlidev] 取消讲稿备注失败:",M),n("取消失败"),he.showMessage("取消讲稿备注失败")}}else{n("转换中...");try{let M=e.rawSnippet.value;try{const ie=await Tc(I);ie!=null&&ie.kramdown&&(M=ie.kramdown)}catch{}const te=`> [!NOTE] 💡 演讲备注
${(ga(M)||M.replace(/<[^>]+>/g,"").trim()||"在此输入本页讲稿提词...").split(/\r?\n/).map(ie=>`> ${ie}`).join(`
`)}
{: custom-slidev-note="true"}`;await nr("markdown",te,I),await De(I,{[nt]:"true"}),Be.setBlockAttrOverride(I,{[nt]:"true"}),Je(I,{[nt]:"true"}),e.activeBlockAttrs.value[nt]="true",e.activeBlockType.value="NodeCallout",n("已设为讲稿备注"),he.showMessage("已转为讲稿备注提示块（不在幻灯片中渲染）"),e.plugin&&await e.plugin.compileCurrentDocument()}catch(M){console.error("[SiYuanSlidev] 转换讲稿备注提示块失败:",M),n("设置失败"),he.showMessage("转为讲稿备注提示块失败")}}}async function k(){try{await f(),he.showMessage("已在正文末尾插入讲稿备注提示块")}catch(I){he.showMessage("插入讲稿备注块失败"),console.error(I)}}function S(){var J;const I=e.currentSlideNoteBlockId.value;if(!I){he.showMessage("未找到本页关联的讲稿备注块");return}Ni(I,(J=e.plugin)==null?void 0:J.app)?he.showMessage("已在编辑区定位讲稿备注块"):he.showMessage("定位讲稿备注块失败")}async function $(){var J;if(!e.currentDocId.value)return;const I=e.targetSlide.value||{startBlockId:e.activeBlockId.value||e.currentDocId.value,blocks:e.rawSnippet.value&&e.rawSnippet.value!=="---"?[{id:e.activeBlockId.value,type:e.activeBlockType.value,content:e.rawSnippet.value,rawMarkdown:""}]:[],rawMarkdown:e.rawSnippet.value&&e.rawSnippet.value!=="---"?e.rawSnippet.value:""};he.showMessage("正在调用思源 AI 提炼本页讲稿提词...");const M=await La(I,Jr);if(M.notes){const Y=e.currentSlideNoteBlockId.value;if(Y){const te=`> [!NOTE] 💡 演讲备注
${M.notes.split(/\r?\n/).map(ie=>`> ${ie}`).join(`
`)}
{: custom-slidev-note="true"}`;await nr("markdown",te,Y),await De(Y,{[nt]:"true"}),Be.setBlockAttrOverride(Y,{[nt]:"true"}),Ni(Y,(J=e.plugin)==null?void 0:J.app)}else await f(M.notes);M.isAiGenerated?he.showMessage("思源 AI 演讲提词卡生成成功！"):he.showMessage("未获取到思源 AI 响应，已生成预设提词卡模板",5e3),e.plugin&&await e.plugin.compileCurrentDocument()}}async function T(){var Y;if(t.value)return;const I=((Y=e.latestDoc.value)==null?void 0:Y.slides)||[];if(I.length===0){he.showMessage("当前文档无幻灯片页面");return}const M=I.map((te,ie)=>({slide:te,idx:ie})).filter(({slide:te})=>{var le;const ie=Array.isArray(te.noteBlocks)&&te.noteBlocks.length>0,pe=!!((le=te.notes)!=null&&le.trim());return!ie&&!pe});if(M.length===0){he.showMessage("所有幻灯片页面均已存在讲稿备注块，无需追加");return}const J=M.length;he.confirm("批量追加讲稿备注",`将在未配置讲稿的 ${J} 页末尾自动插入讲稿提示块，是否继续？`,async()=>{var ie,pe,le,N,ae,ue;if(t.value)return;t.value=!0,he.showMessage("正在批量追加讲稿块...");let te=0;try{const g=`> [!NOTE] 💡 演讲备注
${"在此输入本页讲稿提词...".split(/\r?\n/).map(j=>`> ${j}`).join(`
`)}
{: custom-slidev-note="true"}`;for(const{slide:j,idx:z}of M)try{let _=null;if(z<I.length-1){const A=I[z+1];_=await Ai("markdown",g,A.startBlockId)}else{const A=((ie=j==null?void 0:j.noteBlocks)==null?void 0:ie.slice(-1)[0])||((pe=j==null?void 0:j.blocks)==null?void 0:pe.slice(-1)[0]),q=(A==null?void 0:A.id)||(j==null?void 0:j.startBlockId);q?_=await Ai("markdown",g,void 0,q):_=await ss("markdown",g,e.currentDocId.value)}const w=((ae=(N=(le=_==null?void 0:_[0])==null?void 0:le.doOperations)==null?void 0:N[0])==null?void 0:ae.id)||((ue=_==null?void 0:_[0])==null?void 0:ue.id);w&&(await De(w,{[nt]:"true"}),Be.setBlockAttrOverride(w,{[nt]:"true"})),te++}catch(_){console.error(`[SiYuanSlidev] 为第 ${z+1} 页追加讲稿块失败:`,_)}e.plugin&&await e.plugin.compileCurrentDocument(),he.showMessage(`已成功为 ${te} 页追加讲稿备注块`)}catch(L){console.error("[SiYuanSlidev] 批量追加讲稿块失败:",L),he.showMessage("批量追加讲稿块时出现异常")}finally{t.value=!1}})}async function D(){var te;if(t.value)return;const I=((te=e.latestDoc.value)==null?void 0:te.slides)||[];if(I.length===0){he.showMessage("当前文档无幻灯片页面");return}const M=[];for(const ie of I)if(ie.noteBlocks&&ie.noteBlocks.length>0)for(const pe of ie.noteBlocks)pe.id&&M.push({id:pe.id,pageIndex:ie.pageIndex});if(M.length===0){he.showMessage("当前文档中没有讲稿备注块，无需删除");return}const J=new Set(M.map(ie=>ie.pageIndex)).size,Y=M.length;he.confirm("危险操作：批量删除所有讲稿块",`此操作将从正文中物理删除全部 ${Y} 个讲稿备注块（涉及 ${J} 页），删除后无法撤销。是否确认继续？`,async()=>{if(t.value)return;t.value=!0,he.showMessage("正在批量删除讲稿块...");let ie=0;try{for(const pe of M)try{await or(pe.id),Be.clearBlockAttrOverride(pe.id),ie++}catch(le){console.error(`[SiYuanSlidev] 删除讲稿块 ${pe.id} 失败:`,le)}e.activeBlockId.value&&M.some(pe=>pe.id===e.activeBlockId.value)&&(delete e.activeBlockAttrs.value[nt],delete e.activeBlockAttrs.value["slidev-note"]),e.plugin&&await e.plugin.compileCurrentDocument(),he.showMessage(`已成功删除全部 ${ie} 个讲稿备注块`)}catch(pe){console.error("[SiYuanSlidev] 批量删除讲稿块失败:",pe),he.showMessage("批量删除讲稿块时出现异常")}finally{t.value=!1}})}function E(){e.elemClick.value?s(We,""):s(We,"+1")}function x(I){s(We,I)}function W(I){s(Vt,I)}function V(I){(e.activeBlockAttrs.value[Ee]||"")===I?s(Ee,""):s(Ee,I)}function G(I){e.elemShikiLines.value=I,s(zi,I)}function X(I){e.elemMaxHeight.value=I,s(En,I)}async function C(){const I=e.currentSlideLayout.value==="three-cols-header";await s(Ee,I?"col-1":"left"),he.showMessage(I?"已将当前块设置为第 1 栏 (col-1)":"已将当前块设置为双栏左栏 (left)")}async function P(){const I=e.activeBlockId.value;if(!I)return;const M={[We]:"",[Vt]:"",[Ee]:"",[zi]:"",[En]:"",[nt]:"","slidev-note":"",[ge]:"",[lt]:"",[Ge]:"",[tt]:"",[Ue]:"",[Bt]:"",[Di]:"",[uo]:"",[Ki]:"",[fo]:""};if(Je(I,M),await De(I,M),Be.clearBlockAttrOverride(I),typeof document<"u"){const J=document.querySelector(`.protyle-wysiwyg [data-node-id="${I}"]`),Y=J==null?void 0:J.closest('[data-type="NodeListItem"]'),te=Y==null?void 0:Y.getAttribute("data-node-id");te&&te!==I&&(Je(te,M),await De(te,M).catch(()=>{}),Be.clearBlockAttrOverride(te))}e.activeBlockAttrs.value={},e.elemShikiLines.value="",e.elemMaxHeight.value="",e.pageBackground.value="",e.pageImage.value="",he.showMessage("已清除本块演示属性"),e.plugin&&await e.plugin.compileCurrentDocument()}async function y(){if(e.activeBlockId.value)try{await Ai("markdown","---",e.activeBlockId.value,void 0),he.showMessage("已在上方插入分页符 (---)"),e.plugin&&e.plugin.compileCurrentDocument()}catch{he.showMessage("插入分页符失败")}}async function O(){const I=e.activeBlockId.value||e.currentDocId.value;if(I)try{await Ai("markdown","---",void 0,I),he.showMessage("已在下方插入分页符 (---)"),e.plugin&&e.plugin.compileCurrentDocument()}catch{he.showMessage("插入分页符失败")}}async function U(){if(e.activeBlockId.value)try{await or(e.activeBlockId.value),he.showMessage("已删除该分页符"),e.activeBlockId.value="",e.activeBlockType.value="",e.plugin&&e.plugin.compileCurrentDocument()}catch{he.showMessage("删除失败")}}function B(){if(!e.latestDoc.value){he.showMessage("请先在主编辑区打开幻灯片文档");return}const I=Ia(e.latestDoc.value);Ea("presentation.html",I)&&he.showMessage("已开始下载单文件离线 HTML 演示包")}function R(){if(!e.latestDoc.value){he.showMessage("请先在主编辑区打开幻灯片文档");return}Ta(e.latestDoc.value)&&he.showMessage("已唤起打印视窗，请在打印选项中选择「另存为 PDF」")}async function F(){var I,M;try{let J=null;if(typeof document<"u"){const te=e.activeBlockId.value;if(te){const ie=document.querySelector(`.protyle-wysiwyg [data-node-id="${te}"]`);ie&&(J=ie.getAttribute("data-type")==="NodeSuperBlock"?ie:ie.closest('[data-type="NodeSuperBlock"]'))}if(!J){const ie=e.currentPageDividerId.value||(e.activeBlockType.value==="hr"||e.activeBlockType.value==="NodeThematicBreak"?e.activeBlockId.value:"");if(ie){const pe=document.querySelector(`.protyle-wysiwyg [data-node-id="${ie}"]`);if(pe){let le=pe.nextElementSibling;for(;le&&!(le.getAttribute("data-type")==="NodeThematicBreak"||(I=le.classList)!=null&&I.contains("protyle-wysiwyg__block--hr"));){const N=le.getAttribute("data-type")==="NodeSuperBlock"?le:le.querySelector('[data-type="NodeSuperBlock"]');if(N){J=N;break}le=le.nextElementSibling}}}else{const pe=document.querySelector('.protyle-wysiwyg [data-type="NodeThematicBreak"], .protyle-wysiwyg .protyle-wysiwyg__block--hr'),le=Array.from(document.querySelectorAll('.protyle-wysiwyg [data-type="NodeSuperBlock"]'));for(const N of le)if(!pe||N.compareDocumentPosition(pe)&Node.DOCUMENT_POSITION_FOLLOWING){J=N;break}}}}const Y=[];if(J){const te=Array.from(J.querySelectorAll(":scope > [data-node-id]"));for(const ie of te){const pe=ie.getAttribute("data-node-id");pe&&(Y.push(pe),ie.removeAttribute("style"))}}else if((M=e.targetSlide.value)!=null&&M.blocks){for(const te of e.targetSlide.value.blocks)if(te.children&&te.children.length>=2){for(const ie of te.children)ie.id&&Y.push(ie.id);break}}if(Y.length>0)for(const te of Y)await De(te,{style:""}).catch(()=>{});await r(lt,""),he.showMessage("已重置超级块为平均分布比例"),e.plugin&&await e.plugin.compileCurrentDocument()}catch(J){console.error("[useInspectorActions] resetSuperBlockWidth error:",J),he.showMessage("重置超级块比例失败")}}async function ee(){var I,M,J;try{let Y=null;if(typeof document<"u"){const ie=e.currentPageDividerId.value||(e.activeBlockType.value==="hr"||e.activeBlockType.value==="NodeThematicBreak"?e.activeBlockId.value:""),pe=e.activeBlockId.value;let le=[];if(ie){const ue=document.querySelector(`.protyle-wysiwyg [data-node-id="${ie}"]`);if(ue){let L=ue.nextElementSibling;for(;L&&!(L.getAttribute("data-type")==="NodeThematicBreak"||(I=L.classList)!=null&&I.contains("protyle-wysiwyg__block--hr"));)le.push(L),L=L.nextElementSibling}}else{const ue=document.querySelector('.protyle-wysiwyg [data-type="NodeThematicBreak"], .protyle-wysiwyg .protyle-wysiwyg__block--hr'),L=Array.from(document.querySelectorAll(".protyle-wysiwyg > [data-node-id]"));for(const H of L)if(!ue||H.compareDocumentPosition(ue)&Node.DOCUMENT_POSITION_FOLLOWING)le.push(H);else break}const N=[];let ae;for(const ue of le){const L=ue.getAttribute("data-type");L==="NodeHeading"&&(ae=ue.getAttribute("data-node-id")||void 0);const H=[];L==="NodeSuperBlock"?H.push(ue):H.push(...Array.from(ue.querySelectorAll('[data-type="NodeSuperBlock"]')));for(const g of H){if((g.getAttribute("data-sb-layout")||"").toLowerCase()==="row")continue;const z=g.getAttribute("data-node-id")||"";let _=[];const w=Array.from(g.querySelectorAll('[data-type="NodeListItem"]'));if(w.length===4&&(_=w.map(A=>A.getAttribute("data-node-id")).filter(Boolean)),_.length!==4){const A=Array.from(g.querySelectorAll(":scope > [data-node-id]"));A.length===4&&(_=A.map(q=>q.getAttribute("data-node-id")).filter(Boolean))}_.length===4&&N.push({sbId:z,itemIds:_,headerId:ae})}}N.length>0&&(pe&&(Y=N.find(ue=>{if(ue.sbId===pe||ue.itemIds.includes(pe))return!0;const L=document.querySelector(`.protyle-wysiwyg [data-node-id="${ue.sbId}"]`),H=document.querySelector(`.protyle-wysiwyg [data-node-id="${pe}"]`);return!!(L&&H&&L.contains(H))})||null),Y||(Y=N[0]))}if(!Y&&((M=e.targetSlide.value)!=null&&M.blocks)){const ie=e.targetSlide.value,pe=[];for(const N of ie.blocks)N.rawNode?pe.push(N.rawNode):pe.push({id:N.id,type:N.type,content:N.content,markdown:N.rawMarkdown,children:N.children,ial:N.attributes||N.ial||{}});const le=gf(pe,e.activeBlockId.value);le&&le.items.length===4&&(Y={sbId:le.superBlockNode.id,itemIds:le.items.map(N=>N.id),headerId:(J=le.headerNode)==null?void 0:J.id})}if(!Y||Y.itemIds.length!==4)return he.showMessage("当前页面未找到包含 4 个组件的超级块（需包含 4 个列表项或 4 个子块）",4e3,"info"),!1;const te=e.currentPageDividerId.value||e.currentDocId.value;te&&(e.currentPageDividerLayout.value="clover",e.targetSlide.value&&(e.targetSlide.value.frontmatter||(e.targetSlide.value.frontmatter={}),e.targetSlide.value.frontmatter.layout="clover"),Be.setBlockAttrOverride(te,{[ge]:"clover"}),Je(te,{[ge]:"clover"}),await De(te,{[ge]:"clover"}).catch(()=>{})),Y.headerId&&(Be.setBlockAttrOverride(Y.headerId,{[Ee]:"header"}),Je(Y.headerId,{[Ee]:"header"}),await De(Y.headerId,{[Ee]:"header"}).catch(()=>{}));for(let ie=0;ie<4;ie++){const pe=Y.itemIds[ie],le=`col-${ie+1}`;Be.setBlockAttrOverride(pe,{[Ee]:le}),Je(pe,{[Ee]:le}),await De(pe,{[Ee]:le}).catch(()=>{})}return he.showMessage("已将本页版式设为四叶草（田字型）布局"),e.plugin&&await e.plugin.compileCurrentDocument(),!0}catch(Y){return console.error("[useInspectorActions] applyCloverLayout error:",Y),he.showMessage("配置四叶草布局失败",4e3,"error"),!1}}return{triggerSaveNotice:n,saveAttrs:o,saveAttr:s,savePageAttr:r,applyPageLayoutAndRatio:a,applyCloverLayout:ee,resetSuperBlockWidth:F,saveDocAttr:c,onToggleVideoAutoplay:d,onToggleVideoLoop:m,onToggleVideoMuted:b,onToggleVideoControls:u,onImageRoleChange:h,onToggleNoteBlock:v,createNoteBlockOnCurrentSlide:f,onAddNoteBlock:k,onLocateNoteBlock:S,onGenerateNotesWithAI:$,isBatchProcessing:t,onBatchAppendNotes:T,onBatchDeleteNotes:D,toggleElemClick:E,onElemClickStepChange:x,onElemMotionChange:W,onElemSlotChange:V,onElemShikiLinesChange:G,onElemMaxHeightChange:X,onSetTwoColsContrast:C,onClearBlockAttrs:P,onInsertDividerBefore:y,onInsertDividerAfter:O,onDeleteCurrentBlock:U,onExportHtml:B,onExportPdf:R}}const l0={class:"spm-slidev-inspector"},a0={class:"spm-inspector-topbar"},c0={class:"spm-inspector-title"},d0={class:"slidev-icon",style:{fill:"none !important"},"aria-hidden":"true",viewBox:"0 0 24 24"},u0={class:"spm-inspector-topbar-actions"},f0={class:"spm-target-banner"},p0={class:"spm-target-info"},h0=["aria-label"],m0={key:0,class:"spm-save-status"},g0=["title"],v0={class:"spm-inspector-body"},b0=Ct({__name:"SlidevInspectorDockView",setup(e,{expose:t}){const i=ei("plugin"),n=ve(!1);function o(Q){n.value=!1,c.value=Q.docId,i!=null&&i.compileCurrentDocument&&i.compileCurrentDocument(Q.docId)}const s=ve(""),l=ve(""),r=ve({}),a=ve(""),c=ve(""),d=ve(""),m=ve(""),b=ve(""),u=ve(""),h=ve(""),f=ve(""),v=ve(null),k=ve(""),S=ve("");function $(){var be;const Q=s.value||c.value;Q&&typeof navigator<"u"&&(be=navigator==null?void 0:navigator.clipboard)!=null&&be.writeText&&navigator.clipboard.writeText(Q).then(()=>{S.value="已复制！",setTimeout(()=>{S.value=""},1500)}).catch(()=>{})}const T=_e(()=>Da(l.value)),D=_e(()=>l.value==="NodeCodeBlock"),E=ve(!1),x=_e(()=>{if(E.value||Le.value)return!0;const Q=a.value||"";return!!wi(Q)}),W=_e(()=>{const Q=l.value||"";if(Q==="NodeVideo"||Q==="video")return!0;const be=a.value||"";return!!(/<video\b/i.test(be)||/\.mp4\b/i.test(be))}),V=_e(()=>!s.value||s.value===c.value||l.value==="doc"||l.value==="NodeDocument"),G=_e(()=>{const Q=s.value||c.value||"";return Q.length>8?Q.slice(-8):Q||"无"}),X=_e(()=>a.value?a.value.replace(/<[^>]+>/g,"").replace(/[\r\n]+/g," ").trim().slice(0,45):""),C=_e(()=>{if(T.value)return"分页符 (---)";if(V.value)return"全局文档";if(W.value)return"视频块";let Q="内容块";switch(l.value){case"NodeHeading":Q="标题块";break;case"NodeParagraph":Q="段落块";break;case"NodeCodeBlock":Q="代码块";break;case"NodeVideo":Q="视频块";break;case"NodeList":case"NodeListItem":Q="列表项";break;case"NodeBlockquote":Q="引述块";break;case"NodeTable":Q="表格块";break;case"NodeSuperBlock":case"s":case"sb":Q="超级块";break;default:Q="内容块";break}return u.value?h.value?`${h.value.replace(/^col-(\d+)$/,"第 $1 栏")} › ${Q}`:`分栏容器 › ${Q}`:Q}),P=_e(()=>T.value?"tag-divider":V.value?"tag-doc":"tag-block"),y=_e(()=>r.value[ge]||"default"),O=_e(()=>r.value[tt]||"slide-left"),U=ve(""),B=ve(""),R=_e(()=>r.value[gn]||"inherit"),F=_e(()=>{var Q;return o0((Q=v.value)==null?void 0:Q.slides,{activeBlockId:s.value,activeBlockType:l.value,currentTopBlockId:d.value,currentPageDividerId:m.value,activeBlockAttrs:r.value})}),ee=_e(()=>{var Q;return((Q=F.value)==null?void 0:Q.notes)||""}),I=_e(()=>{var Q,be,Ce;return((Ce=(be=(Q=F.value)==null?void 0:Q.noteBlocks)==null?void 0:be[0])==null?void 0:Ce.id)||""}),M=_e(()=>{var we,Fe,Oe,ft,Un,ci;if(T.value){const et=r.value[ge]||r.value["custom-slidev-layout"];if(et)return et}const Q=r.value[Ee]||r.value["custom-slidev-slot"];if(Q&&(["col-1","col-2","col-3"].includes(Q)||/^col-\d+$/.test(Q)))return"cols-header";if(b.value)return b.value;const be=m.value||(T.value?s.value:"");if(be){const et=Be.getBlockAttrOverride(be);if(et!=null&&et[ge])return et[ge]}if(be&&((we=v.value)!=null&&we.slides)){const et=v.value.slides.find(Wi=>Wi.startBlockId===be);if((Fe=et==null?void 0:et.frontmatter)!=null&&Fe.layout)return et.frontmatter.layout}if((ft=(Oe=F.value)==null?void 0:Oe.frontmatter)!=null&&ft.layout)return F.value.frontmatter.layout;if((ci=(Un=F.value)==null?void 0:Un.blocks)!=null&&ci.some(et=>et.slot&&(["col-1","col-2","col-3"].includes(et.slot)||/^col-\d+$/.test(et.slot))))return"cols-header";const Ce=Be.getBlockAttrOverride(c.value);return Ce!=null&&Ce[ge]?Ce[ge]:"default"}),J=_e(()=>{var be,Ce;if(T.value){const we=r.value[lt]||r.value["custom-slidev-layout-ratio"];if(we)return we}const Q=m.value||(T.value?s.value:"");if(Q){const we=Be.getBlockAttrOverride(Q);if(we!=null&&we[lt])return we[lt]}return((Ce=(be=F.value)==null?void 0:be.frontmatter)==null?void 0:Ce.layoutRatio)||""}),Y=_e(()=>{var be,Ce;if(T.value){const we=r.value[vi]||r.value["custom-slidev-mask"];if(we!==void 0)return we}const Q=m.value||(T.value?s.value:"");if(Q){const we=Be.getBlockAttrOverride(Q);if((we==null?void 0:we[vi])!==void 0)return we[vi]}return((Ce=(be=F.value)==null?void 0:be.frontmatter)==null?void 0:Ce.mask)||""}),te=_e(()=>{var be,Ce;if(T.value){const we=r.value[bi]||r.value["custom-slidev-mask-ratio"];if(we!==void 0)return we}const Q=m.value||(T.value?s.value:"");if(Q){const we=Be.getBlockAttrOverride(Q);if((we==null?void 0:we[bi])!==void 0)return we[bi]}return((Ce=(be=F.value)==null?void 0:be.frontmatter)==null?void 0:Ce.maskRatio)||""}),ie=_e(()=>{var be,Ce;if(T.value){const we=r.value[yi]||r.value["custom-slidev-mask-style"];if(we!==void 0)return we}const Q=m.value||(T.value?s.value:"");if(Q){const we=Be.getBlockAttrOverride(Q);if((we==null?void 0:we[yi])!==void 0)return we[yi]}return((Ce=(be=F.value)==null?void 0:be.frontmatter)==null?void 0:Ce.maskStyle)||"solid"}),pe=_e(()=>{var be,Ce;if(T.value){const we=r.value[ki]||r.value["custom-slidev-mask-initial"];if(we!==void 0)return we}const Q=m.value||(T.value?s.value:"");if(Q){const we=Be.getBlockAttrOverride(Q);if((we==null?void 0:we[ki])!==void 0)return we[ki]}return((Ce=(be=F.value)==null?void 0:be.frontmatter)==null?void 0:Ce.maskInitial)||"hidden"});function le(Q){if(!Q||(Q.getAttribute("data-sb-layout")||"").toLowerCase()!=="col")return null;const Ce=Array.from(Q.querySelectorAll(":scope > [data-node-id]"));if(Ce.length<2)return null;const we=Ce.length,Fe=Ce.map(ci=>{const et=ci.getAttribute("style")||"",Wi=et.match(/calc\(\s*([\d.]+)%/);if(Wi)return parseFloat(Wi[1]);const cn=et.match(/(?:^|;|\s)width:\s*([\d.]+)%/i);return cn?parseFloat(cn[1]):null});let Oe="",ft=!1;if(Fe.some(ci=>ci!==null)){ft=!0;const ci=Fe.reduce((Me,pt)=>Me+(pt||0),0),et=Fe.filter(Me=>Me===null).length,Wi=et>0?Math.max(0,100-ci)/et:100/Ce.length,cn=Fe.map(Me=>Me!==null?Me:Wi),yc=cn.reduce((Me,pt)=>Me+pt,0)||1,dn=cn.map(Me=>Me/yc*100);if(dn.length===2){const[Me]=dn;if(Me>=48&&Me<=52)Oe="1:1";else if(Me>=31&&Me<=35)Oe="1:2";else if(Me>=65&&Me<=69)Oe="2:1";else if(Me>=28&&Me<=32)Oe="3:7";else if(Me>=68&&Me<=72)Oe="7:3";else if(Me>=38&&Me<=42)Oe="4:6";else if(Me>=58&&Me<=62)Oe="6:4";else{const pt=Math.round(Me);Oe=`${pt}:${100-pt}`}}else if(dn.length===3){const[Me,pt,di]=dn;if(Me>=31&&Me<=35&&pt>=31&&pt<=35&&di>=31&&di<=35)Oe="1:1:1";else if(Me>=23&&Me<=27&&pt>=48&&pt<=52&&di>=23&&di<=27)Oe="1:2:1";else if(Me>=48&&Me<=52&&pt>=23&&pt<=27&&di>=23&&di<=27)Oe="2:1:1";else if(Me>=23&&Me<=27&&pt>=23&&pt<=27&&di>=48&&di<=52)Oe="1:1:2";else{const tr=Math.round(Me),ir=Math.round(pt);Oe=`${tr}:${ir}:${100-tr-ir}`}}else Oe=dn.map(Me=>Math.round(Me)).join(":")}else ft=!1,Oe=Array.from({length:we},()=>1).join(":");const Un=we>=2?"cols-header":"two-cols";return{hasSuperBlock:!0,colCount:we,ratio:Oe,isCustomWidth:ft,recommendedLayout:Un}}function N(Q){if(!(Q!=null&&Q.blocks))return null;for(const be of Q.blocks){const Ce=be.rawNode;if(Ce&&ot(Ce)&&qt(Ce)){const Fe=an(Ce).length,Oe=Ks(Ce);return{hasSuperBlock:!0,colCount:Fe,ratio:Oe||Array.from({length:Fe},()=>1).join(":"),isCustomWidth:!!Oe,recommendedLayout:Fe>=2?"cols-header":"two-cols"}}}return null}const ae=_e(()=>{var Q;if(typeof document<"u"){const be=s.value;if(be){const we=document.querySelector(`.protyle-wysiwyg [data-node-id="${be}"]`);if(we){const Fe=we.getAttribute("data-type")==="NodeSuperBlock"?we:we.closest('[data-type="NodeSuperBlock"]');if(Fe){const Oe=le(Fe);if(Oe)return Oe}}}const Ce=m.value||(T.value?s.value:"");if(Ce){const we=document.querySelector(`.protyle-wysiwyg [data-node-id="${Ce}"]`);if(we){let Fe=we.nextElementSibling;for(;Fe&&!(Fe.getAttribute("data-type")==="NodeThematicBreak"||(Q=Fe.classList)!=null&&Q.contains("protyle-wysiwyg__block--hr"));){const Oe=Fe.getAttribute("data-type")==="NodeSuperBlock"?Fe:Fe.querySelector('[data-type="NodeSuperBlock"]');if(Oe){const ft=le(Oe);if(ft)return ft}Fe=Fe.nextElementSibling}}}else{const we=document.querySelector('.protyle-wysiwyg [data-type="NodeThematicBreak"], .protyle-wysiwyg .protyle-wysiwyg__block--hr'),Fe=Array.from(document.querySelectorAll('.protyle-wysiwyg [data-type="NodeSuperBlock"]'));for(const Oe of Fe)if(!we||Oe.compareDocumentPosition(we)&Node.DOCUMENT_POSITION_FOLLOWING){const ft=le(Oe);if(ft)return ft}}}return N(F.value)}),ue=_e(()=>{var Q;return((Q=ae.value)==null?void 0:Q.ratio)||""}),L=_e(()=>{const Q=l.value||"";if(Q==="NodeSuperBlock"||Q==="s"||Q==="sb")return!0;if(typeof document<"u"&&s.value){const be=document.querySelector(`.protyle-wysiwyg [data-node-id="${s.value}"]`);if(be!=null&&be.closest('[data-type="NodeSuperBlock"]'))return!0}return!1}),H=_e(()=>{var Q;return((Q=F.value)==null?void 0:Q.pageIndex)||1}),g=_e(()=>!!(r.value[nt]||r.value["slidev-note"]));function j(){if(!u.value)return!1;if(s.value===u.value||typeof document>"u")return!0;const Q=document.querySelector(`.protyle-wysiwyg [data-node-id="${u.value}"]`)||document.querySelector(`[data-node-id="${u.value}"]`);if(!Q)return!1;const be=Q.querySelector(":scope > [data-node-id], :scope > div > [data-node-id]");return(be==null?void 0:be.getAttribute("data-node-id"))===s.value}const z=_e(()=>{var be;if(r.value[We]!==void 0)return r.value[We]||"";if(u.value&&j())return f.value||"";if(u.value)return"";const Q=s.value;if(Q&&((be=F.value)!=null&&be.blocks)){const Ce=F.value.blocks.find(we=>we.id===Q);if(Ce!=null&&Ce.clicks)return Ce.clicks}return""}),_=_e(()=>{var be;if(r.value[Vt])return r.value[Vt];const Q=s.value;if(Q&&((be=F.value)!=null&&be.blocks)){const Ce=F.value.blocks.find(we=>we.id===Q);if(Ce!=null&&Ce.motion)return typeof Ce.motion=="string"?Ce.motion:JSON.stringify(Ce.motion)}return""}),w=_e(()=>{var be;if(r.value[Ee])return r.value[Ee];const Q=s.value;if(Q&&((be=F.value)!=null&&be.blocks)){const Ce=F.value.blocks.find(we=>we.id===Q);if(Ce!=null&&Ce.slot)return Ce.slot}return""}),A=ve(""),q=ve(""),K=_e(()=>r.value[Di]==="true"),Z=_e(()=>r.value[uo]==="true"),ne=_e(()=>r.value[Ki]==="true"),ce=_e(()=>r.value[fo]!=="false"),re=_e(()=>{var Q,be;return((be=(Q=v.value)==null?void 0:Q.config)==null?void 0:be.theme)||r.value[Cn]||"default"}),me=_e(()=>{var Q,be;return((be=(Q=v.value)==null?void 0:Q.config)==null?void 0:be.aspectRatio)||r.value[$n]||"16/9"}),$e=_e(()=>{var Q,be;return((be=(Q=v.value)==null?void 0:Q.config)==null?void 0:be.defaultTransition)||r.value[In]||"slide-left"}),xe=_e(()=>{var Q,be;return((be=(Q=v.value)==null?void 0:Q.config)==null?void 0:be.spacing)||r.value[ls]||"normal"}),Le=_e(()=>{var Fe,Oe;if((r.value[Ge]||r.value["slidev-role"])===tl||r.value[Ue]==="true")return"background";const be=r.value[ge]||r.value["slidev-layout"];if(be==="image-left"||be==="image-right")return be;const Ce=a.value||"",we=wi(Ce);if(we&&((Oe=(Fe=F.value)==null?void 0:Fe.frontmatter)!=null&&Oe.background)){const ft=F.value.frontmatter.background;if(ft===we||ft.endsWith(we)||we.endsWith(ft))return"background"}return""}),Ze=_e(()=>!!(r.value[We]||r.value[Vt]||r.value[Ee]||r.value[zi]||r.value[nt]||r.value["slidev-note"]||r.value[Ge]||r.value[ge]||r.value[Di]||r.value[uo]||r.value[Ki]||r.value[fo])),{saveAttr:je,savePageAttr:Xe,applyPageLayoutAndRatio:ze,applyCloverLayout:Gt,resetSuperBlockWidth:st,saveDocAttr:Ye,onToggleVideoAutoplay:Si,onToggleVideoLoop:Hi,onToggleVideoMuted:zo,onToggleVideoControls:Fo,onImageRoleChange:Wn,onToggleNoteBlock:_i,onAddNoteBlock:ji,onLocateNoteBlock:Na,onGenerateNotesWithAI:za,isBatchProcessing:Fa,onBatchAppendNotes:Ha,onBatchDeleteNotes:ja,toggleElemClick:Wa,onElemClickStepChange:Ua,onElemMotionChange:Va,onElemSlotChange:Ka,onElemShikiLinesChange:qa,onElemMaxHeightChange:Ga,onSetTwoColsContrast:Za,onClearBlockAttrs:Ya,onInsertDividerBefore:Ja,onInsertDividerAfter:Xs,onDeleteCurrentBlock:Xa,onExportHtml:Qa,onExportPdf:ec}=r0({activeBlockId:s,activeBlockType:l,activeBlockAttrs:r,rawSnippet:a,currentDocId:c,currentPageDividerId:m,currentPageDividerLayout:b,parentContainerId:u,parentContainerClicks:f,latestDoc:v,targetSlide:F,currentSlideNoteBlockId:I,currentSlideLayout:M,isNoteBlock:g,elemClick:z,videoAutoplay:K,videoLoop:Z,videoMuted:ne,videoControls:ce,pageBackground:U,pageImage:B,elemShikiLines:A,elemMaxHeight:q,saveStatus:k,plugin:i});async function tc(Q){if(Q==="clover"){if(!await Gt())return}else je(ge,Q)}function ic(Q){Xe(lt,Q)}function nc(Q){Xe(vi,Q)}function oc(Q){Xe(bi,Q)}function sc(Q){Xe(yi,Q)}function rc(Q){Xe(ki,Q)}function Qs(Q){if(!Q)return;const be=Q.recommendedLayout||(Q.colCount&&Q.colCount>=2?"cols-header":"two-cols"),Ce=Q.ratio||(Q.colCount?Array(Q.colCount).fill(1).join(":"):"1:1");ze(be,Ce)}function lc(Q){Xe(lt,Q)}async function ac(){await st()}function cc(Q){je(tt,Q)}function dc(Q){U.value=Q,je(Ue,Q)}function uc(Q){B.value=Q,je(Bt,Q)}function fc(Q){je(gn,Q==="inherit"?"":Q)}function pc(Q){Ye(Cn,Q)}function hc(Q){Ye($n,Q)}function mc(Q){Ye(In,Q)}function gc(Q){Ye(ls,Q)}function er(){i!=null&&i.openBottomPreviewTab&&i.openBottomPreviewTab()}function vc(){typeof window<"u"&&window.open("/plugins/siyuan-slidev/slidev-client/presenter.html","SlidevPresenter","width=1200,height=800")}function bc(){i!=null&&i.executeCommand&&i.executeCommand("slidevAiSplit")}return t({setActiveBlock(Q){s.value=Q.id,l.value=Q.type,r.value={...Q.attrs},a.value=Q.content||Q.markdown||"",d.value=Q.topBlockId||Q.id,m.value=Q.pageDividerId||"",b.value=Q.pageDividerLayout||"",u.value=Q.parentContainerId||"",h.value=Q.parentContainerSlot||"",f.value=Q.parentContainerClicks||"",Q.rootId?c.value=Q.rootId:(Q.type==="doc"||Q.type==="NodeDocument")&&Q.id&&(c.value=Q.id),U.value=Q.attrs[Ue]||"",B.value=Q.attrs[Bt]||"",A.value=Q.attrs[zi]||"",q.value=Q.attrs[En]||"",E.value=!!Q.isImage},updateDocument(Q){v.value=Q,c.value=Q.docId},openImportDialog(){n.value=!0},setCurrentDocId(Q){c.value=Q}}),(Q,be)=>(oe(),se("div",l0,[p("div",a0,[p("div",c0,[(oe(),se("svg",d0,[...be[2]||(be[2]=[p("rect",{x:"2",y:"3",width:"20",height:"14",rx:"2"},null,-1),p("line",{x1:"8",y1:"21",x2:"16",y2:"21"},null,-1),p("line",{x1:"12",y1:"17",x2:"12",y2:"21"},null,-1)])])),be[3]||(be[3]=p("span",null,"演示配置",-1))]),p("div",u0,[p("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"导入 Slidev 演示文档 (.md / .zip)",onClick:be[0]||(be[0]=Ce=>n.value=!0)},[de(fe,{name:"import"}),be[4]||(be[4]=p("span",null,"导入",-1))]),p("button",{class:"spm-icon-btn is-primary b3-tooltips b3-tooltips__s","aria-label":"在下方分屏开启幻灯片预览 (Alt+P)",onClick:er},[de(fe,{name:"split-preview"}),be[5]||(be[5]=p("span",null,"分屏预览",-1))])])]),p("div",f0,[p("div",p0,[p("span",{class:Ie(["spm-target-tag",P.value])},Se(C.value),3),p("span",{class:"spm-target-id b3-tooltips b3-tooltips__s","aria-label":S.value||"点击复制 ID: "+(s.value||c.value),onClick:$},[de(fe,{name:"copy"}),p("span",null,"#"+Se(G.value),1)],8,h0)]),k.value?(oe(),se("span",m0,"● "+Se(k.value),1)):Re("",!0)]),X.value?(oe(),se("div",{key:0,class:"spm-context-quote",title:a.value},Se(X.value),9,g0)):Re("",!0),p("div",v0,[T.value?(oe(),Dt(Av,{key:0,"page-layout":y.value,"page-layout-ratio":J.value,"page-mask":Y.value,"page-mask-ratio":te.value,"page-mask-style":ie.value,"page-mask-initial":pe.value,"detected-sb-ratio":ue.value,"detected-sb-info":ae.value,"page-transition":O.value,"page-background":U.value,"page-spacing":R.value,"page-image":B.value,"page-notes":ee.value,"page-index":H.value,"onUpdate:pageLayout":tc,"onUpdate:pageLayoutRatio":ic,"onUpdate:pageMask":nc,"onUpdate:pageMaskRatio":oc,"onUpdate:pageMaskStyle":sc,"onUpdate:pageMaskInitial":rc,onApplySuperBlockLayout:Qs,onResetSuperblockRatio:ac,"onUpdate:pageTransition":cc,"onUpdate:pageBackground":dc,"onUpdate:pageSpacing":fc,"onUpdate:pageImage":uc,onAddNoteBlock:ye(ji),onLocateNoteBlock:ye(Na),onGenerateNotes:ye(za),onBatchAppendNotes:ye(Ha),onBatchDeleteNotes:ye(ja),"is-batch-processing":ye(Fa),onInsertDividerAfter:ye(Xs),onDeleteDivider:ye(Xa)},null,8,["page-layout","page-layout-ratio","page-mask","page-mask-ratio","page-mask-style","page-mask-initial","detected-sb-ratio","detected-sb-info","page-transition","page-background","page-spacing","page-image","page-notes","page-index","onAddNoteBlock","onLocateNoteBlock","onGenerateNotes","onBatchAppendNotes","onBatchDeleteNotes","is-batch-processing","onInsertDividerAfter","onDeleteDivider"])):s.value&&!V.value?(oe(),Dt(h1,{key:1,"elem-click":z.value,"elem-motion":_.value,"elem-slot":w.value,"elem-shiki-lines":A.value,"elem-max-height":q.value,"is-code-block":D.value,"is-image":x.value,"is-video":W.value,"is-super-block":L.value,"detected-sb-info":ae.value,"video-autoplay":K.value,"video-loop":Z.value,"video-muted":ne.value,"video-controls":ce.value,"has-block-attrs":Ze.value,"is-note":g.value,"image-role":Le.value,"current-slide-layout":M.value,"parent-elem-click":f.value,"parent-container-slot":h.value,"parent-container-id":u.value,onToggleNote:ye(_i),onToggleElemClick:ye(Wa),onToggleVideoAutoplay:ye(Si),onToggleVideoLoop:ye(Hi),onToggleVideoMuted:ye(zo),onToggleVideoControls:ye(Fo),"onUpdate:imageRole":ye(Wn),"onUpdate:elemClick":ye(Ua),"onUpdate:elemMotion":ye(Va),"onUpdate:elemSlot":ye(Ka),"onUpdate:elemShikiLines":ye(qa),"onUpdate:elemMaxHeight":ye(Ga),onApplySuperBlockLayout:Qs,onApplySuperBlockRatio:lc,onInsertDividerBefore:ye(Ja),onInsertDividerAfter:ye(Xs),onSetTwoColsContrast:ye(Za),onClearBlockAttrs:ye(Ya)},null,8,["elem-click","elem-motion","elem-slot","elem-shiki-lines","elem-max-height","is-code-block","is-image","is-video","is-super-block","detected-sb-info","video-autoplay","video-loop","video-muted","video-controls","has-block-attrs","is-note","image-role","current-slide-layout","parent-elem-click","parent-container-slot","parent-container-id","onToggleNote","onToggleElemClick","onToggleVideoAutoplay","onToggleVideoLoop","onToggleVideoMuted","onToggleVideoControls","onUpdate:imageRole","onUpdate:elemClick","onUpdate:elemMotion","onUpdate:elemSlot","onUpdate:elemShikiLines","onUpdate:elemMaxHeight","onInsertDividerBefore","onInsertDividerAfter","onSetTwoColsContrast","onClearBlockAttrs"])):(oe(),Dt(X1,{key:2,"doc-theme":re.value,"doc-aspect-ratio":me.value,"doc-default-transition":$e.value,"doc-spacing":xe.value,"onUpdate:docTheme":pc,"onUpdate:docAspectRatio":hc,"onUpdate:docDefaultTransition":mc,"onUpdate:docSpacing":gc,onOpenBottomPreview:er,onOpenPresenter:vc,onAiAutoSplit:bc,onExportHtml:ye(Qa),onExportPdf:ye(ec)},null,8,["doc-theme","doc-aspect-ratio","doc-default-transition","doc-spacing","onExportHtml","onExportPdf"]))]),n.value?(oe(),Dt(n0,{key:1,onClose:be[1]||(be[1]=Ce=>n.value=!1),onSuccess:o})):Re("",!0)]))}}),y0=2e3,k0=600;function w0(e){return!e||typeof e.closest!="function"?!1:!!e.closest(".fn__none")}function ns(e){if(!e||typeof e.isConnected=="boolean"&&!e.isConnected)return!1;if(qr(e))return!0;const t=e.firstElementChild;return!!(t&&qr(t))}function qr(e){return typeof e.getClientRects=="function"&&e.getClientRects().length>0?!0:typeof e.offsetWidth=="number"&&e.offsetWidth>0&&e.offsetHeight>0}function x0(){const e=typeof globalThis<"u"?globalThis.IntersectionObserver:void 0;return typeof e=="function"?e:void 0}class S0{constructor(){ke(this,"consumers",new Map);ke(this,"seq",0);ke(this,"verifyTimer",null)}register(t,i,n){if(!i)return()=>{};const o=++this.seq,s=x0(),l={kind:t,element:i,visible:!1,measureOnDemand:!s,observer:null,onVisible:n};return s?(l.observer=new s(r=>{var d;const a=r[r.length-1];if(!a)return;const c=a.isIntersecting&&!l.visible;l.visible=a.isIntersecting,c&&((d=l.onVisible)==null||d.call(l))}),l.observer.observe(i)):l.visible=ns(i),this.consumers.set(o,l),()=>{var r;(r=l.observer)==null||r.disconnect(),this.consumers.delete(o),this.consumers.size===0&&this.stopVerifyTimer()}}clear(){var t;for(const i of this.consumers.values())(t=i.observer)==null||t.disconnect();this.consumers.clear(),this.stopVerifyTimer()}get size(){return this.consumers.size}getVisibility(){if(this.consumers.size===0)return"none";if(typeof document<"u"&&document.visibilityState==="hidden")return"hidden";for(const t of this.consumers.values())if(t.measureOnDemand?ns(t.element):this.isRecordVisible(t))return"visible";return this.ensureVerifyTimer(),"hidden"}hasVisibleConsumer(){return this.getVisibility()==="visible"}isRecordVisible(t){return t.visible?!0:!w0(t.element)}ensureVerifyTimer(){if(this.verifyTimer!==null||typeof setTimeout!="function")return;let t=!1;for(const i of this.consumers.values())if(!i.measureOnDemand){t=!0;break}t&&(this.verifyTimer=setTimeout(()=>{var i;this.verifyTimer=null;for(const n of this.consumers.values())if(!n.visible&&ns(n.element)){n.visible=!0,(i=n.onVisible)==null||i.call(n);return}},y0))}stopVerifyTimer(){this.verifyTimer!==null&&(clearTimeout(this.verifyTimer),this.verifyTimer=null)}}const so=new S0,jn=new Ys;function Oa(e,t,i){const n=()=>{var s;try{(s=i==null?void 0:i.flushDirtyCompile)==null||s.call(i)}catch{}},o=so.register(e,t,n);return n(),o}let mi=null,Lt=null,ro=null;function _0(){return Lt}function C0(e,t){mi&&Ra(),mi=da(hg),mi.provide("plugin",t),mi.provide("sandboxBridge",jn);const i=mi.mount(e);return Lt=i,ro=Oa("preview",e,t),i}function Ra(e){ro&&(ro(),ro=null),mi&&(mi.unmount(),mi=null,Lt=null)}let gi=null,St=null,lo=null;function $0(e,t){gi&&Pa(),gi=da(b0),gi.provide("plugin",t),gi.provide("sandboxBridge",jn);const i=gi.mount(e);return St=i,lo=Oa("dock",e,t),i}function Pa(e){lo&&(lo(),lo=null),gi&&(gi.unmount(),gi=null,St=null)}function I0(e,t){St!=null&&St.updateDocument&&St.updateDocument(e),Lt!=null&&Lt.updateDocument?Lt.updateDocument(e,t):jn.updateSlides(e.slides,e.config,e.fullMarkdown)}function _s(e){Lt!=null&&Lt.navigateToBlock?Lt.navigateToBlock(e):jn.highlightElement(e)}function ao(e){St!=null&&St.setActiveBlock&&St.setActiveBlock(e)}function E0(){return St!=null&&St.openImportDialog?(St.openImportDialog(),!0):!1}function T0(e,t){const i=[];let o=0;for(let s=0;s<e.length;s++){const l=e[s];if(_o(l)){o=0;continue}const r=l.markdown||l.content||"";if(!(s===0)){if(l.type==="h"&&(l.subType==="h1"||r.startsWith("# "))){i.push({blockId:l.id,recommendedLayout:"cover",reason:"检测到一级核心章节标题，建议作为新幻灯片封面/大章"}),o=0;continue}if(l.type==="h"&&(l.subType==="h2"||r.startsWith("## "))){i.push({blockId:l.id,recommendedLayout:"default",reason:"检测到二级分论点标题，建议开启新页"}),o=0;continue}}if(o++,o>=6&&s<e.length-1){const c=e[s+1];_o(c)||(i.push({blockId:c.id,recommendedLayout:"default",reason:"当前页已达容量上限 (避免信息超载)，建议在此分页"}),o=0)}}return i}const A0=[{id:"slidev-cover",name:"幻灯片 - 封面页 (Cover)",open:!0,attrs:[{key:Mi,value:"true"},{key:ge,value:"cover"},{key:tt,value:"fade"}]},{id:"slidev-two-cols",name:"幻灯片 - 双栏对比 (Two Columns)",open:!0,attrs:[{key:Mi,value:"true"},{key:ge,value:"two-cols"},{key:tt,value:"slide-left"}]},{id:"slidev-fact",name:"幻灯片 - 大字报与核心指标 (Fact)",open:!0,attrs:[{key:Mi,value:"true"},{key:ge,value:"fact"},{key:tt,value:"zoom"}]},{id:"slidev-intro",name:"幻灯片 - 章节导引与作者 (Intro)",open:!0,attrs:[{key:Mi,value:"true"},{key:ge,value:"intro"},{key:tt,value:"slide-up"}]},{id:"slidev-quote",name:"幻灯片 - 金句与强调 (Quote)",open:!0,attrs:[{key:Mi,value:"true"},{key:ge,value:"quote"},{key:tt,value:"fade"}]},{id:"slidev-elem-click",name:"元素 - 顺延逐步呈现 (v-click)",open:!0,attrs:[{key:We,value:"+1"}]},{id:"slidev-elem-click-hide",name:"元素 - 隐藏直到激活 (v-click:hide)",open:!0,attrs:[{key:We,value:"hide"}]},{id:"slidev-elem-slot-right",name:"元素 - 双栏右栏归属 (Slot: Right)",open:!0,attrs:[{key:Ee,value:"right"}]},{id:"slidev-shiki-lines",name:"代码 - 逐行聚光高亮 (Shiki)",open:!0,attrs:[{key:zi,value:"1-3"}]}];class os{getPresetTemplates(){return A0}buildScanSlidevBlocksSql(t="custom-slidev-"){return`SELECT block_id, name, value FROM attributes WHERE name LIKE '${t}%' ORDER BY block_id ASC`}buildTransitionStatsSql(){return`SELECT value, count(1) as count FROM attributes WHERE name = '${tt}' GROUP BY value ORDER BY count DESC`}async batchUpdateTransitions(t,i,n,o){const s=`SELECT block_id FROM attributes WHERE name = '${tt}' AND value = '${t}'`,l=await n(s);let r=0;if(Array.isArray(l))for(const a of l){const c=a.block_id||a.blockId;c&&(await o(c,{[tt]:i}),r++)}return{updatedCount:r}}async batchUpdateLayout(t,i,n,o){const s=`SELECT block_id FROM attributes WHERE name = 'custom-slidev-layout' AND value = '${t}'`,l=await n(s);let r=0;if(Array.isArray(l))for(const a of l){const c=a.block_id||a.blockId;c&&(await o(c,{"custom-slidev-layout":i}),r++)}return{updatedCount:r}}exportTemplatesJson(){const t=this.getPresetTemplates();return JSON.stringify({templates:t,counter:t.length},null,2)}formatTransitionSummary(t){return!t||t.length===0?"全库目前暂无已设置 Slidev 转场效果的块":`全库 Slidev 转场分布统计：${t.map(n=>`${n.value}: ${n.count} 个`).join("，")}`}}function B0(e){e.addCommand({langKey:"slidevPresentation",langText:"Slidev: 在文档下方开启分屏演示预览",hotkey:"⌥P",enabled:()=>!0,execute:()=>{e.openBottomPreviewTab()}}),e.addCommand({langKey:"slidevImport",langText:"Slidev: 导入 Slidev 演示文档 (.md / .zip)",hotkey:"⌥I",enabled:()=>!0,execute:()=>{E0()||he.showMessage("请先在右侧栏打开「Slidev 演示配置」Dock 面板以呼起导入窗口")}}),e.addCommand({langKey:"slidevInitAttrs",langText:"Slidev: 初始化当前文档演示属性",hotkey:"",enabled:()=>!0,execute:async()=>{if(!e.currentDocId){const t=document.querySelector(".protyle-content[data-doc-id]");e.currentDocId=(t==null?void 0:t.getAttribute("data-doc-id"))||""}e.currentDocId&&(await De(e.currentDocId,{"custom-slidev-theme":"default","custom-slidev-aspect-ratio":"16/9","custom-slidev-default-transition":"slide-left"}),he.showMessage("已为当前文档初始化 Slidev 演示属性"),e.compileCurrentDocument(e.currentDocId))}}),e.addCommand({langKey:"slidevAiSplit",langText:"Slidev AI: 智能大纲断页建议与自动分页",hotkey:"",enabled:()=>!0,execute:async()=>{if(!e.currentDocId){const s=document.querySelector(".protyle-content[data-doc-id]");e.currentDocId=(s==null?void 0:s.getAttribute("data-doc-id"))||""}if(!e.currentDocId){he.showMessage("请先打开一篇思源笔记文档");return}const t=await co(e.currentDocId).catch(()=>[]);if(!t||t.length===0){he.showMessage("当前文档无内容，无需断页");return}const i=t.map(s=>({id:s.id,type:s.type,subType:s.subType,content:s.content||"",markdown:s.markdown||""})),n=T0(i);if(n.length===0){he.showMessage("AI 分析完毕：当前文档篇幅合理，暂无分页建议");return}he.showMessage(`AI 分析完毕：发现 ${n.length} 处建议分页点，正在自动插入分页分割线...`);let o=0;for(const s of n)try{await Ai("markdown","---",void 0,s.blockId),await De(s.blockId,{"custom-slidev-layout":s.recommendedLayout}),o++}catch(l){console.warn("Failed to insert divider:",l)}he.showMessage(`已成功在 ${o} 处插入分页线并重新编译`),e.compileCurrentDocument(e.currentDocId)}}),e.addCommand({langKey:"slidevAiNotes",langText:"Slidev AI: 自动为当前文档生成演讲者提词卡 (Notes)",hotkey:"",enabled:()=>!0,execute:async()=>{var a,c,d,m;if(!e.currentDocId){const b=document.querySelector(".protyle-content[data-doc-id]");e.currentDocId=(b==null?void 0:b.getAttribute("data-doc-id"))||""}if(!e.currentDocId){he.showMessage("请先打开一篇思源笔记文档");return}he.showMessage("正在调用思源 AI 提炼演讲者口播提词...");const t=await co(e.currentDocId).catch(()=>[]),i={startBlockId:e.currentDocId,blocks:t.map(b=>({id:b.id,type:b.type,content:b.content||"",rawMarkdown:b.markdown||""})),rawMarkdown:""},s=`> [!NOTE] 💡 演讲备注
${(await s0(i,Jr)).split(/\r?\n/).map(b=>`> ${b}`).join(`
`)}
{: custom-slidev-note="true"}`,l=await ss("markdown",s,e.currentDocId).catch(()=>null),r=((d=(c=(a=l==null?void 0:l[0])==null?void 0:a.doOperations)==null?void 0:c[0])==null?void 0:d.id)||((m=l==null?void 0:l[0])==null?void 0:m.id);r&&(await De(r,{"custom-slidev-note":"true"}),Be.setBlockAttrOverride(r,{"custom-slidev-note":"true"}),Ni(r,e.app)),he.showMessage("已成功生成口播提词卡并插入为正文讲稿备注块"),e.compileCurrentDocument(e.currentDocId)}}),e.addCommand({langKey:"slidevBatchTransitions",langText:"Slidev 协同: 统计全库转场效果分布",hotkey:"",enabled:()=>!0,execute:async()=>{const t=new os,i=t.buildTransitionStatsSql(),n=await en(i).catch(()=>[]),o=t.formatTransitionSummary(n||[]);he.showMessage(o)}}),e.addCommand({langKey:"slidevExportTemplates",langText:"Slidev 协同: 复制 Slidev 预设属性模板至剪贴板",hotkey:"",enabled:()=>!0,execute:async()=>{const i=new os().exportTemplatesJson();typeof navigator<"u"&&navigator.clipboard?(await navigator.clipboard.writeText(i),he.showMessage("已将 Slidev 属性模板 JSON 复制至剪贴板，可直接导入属性管家")):he.showMessage(`已生成模板数据（请在控制台查看）：
`+i)}}),e.addCommand({langKey:"slidevBatchReplaceTransition",langText:"Slidev 协同: 批量替换全库淡入淡出转场为滑动 (fade -> slide-left)",hotkey:"",enabled:()=>!0,execute:async()=>{const i=await new os().batchUpdateTransitions("fade","slide-left",n=>en(n).catch(()=>[]),(n,o)=>De(n,o));he.showMessage(`全库批量替换完成：已将 ${i.updatedCount} 处 fade 转场更新为 slide-left`),e.compileCurrentDocument()}}),e.addCommand({langKey:"slidevPresenterMode",langText:"Slidev: 打开双屏演讲者控制台 (Presenter Mode)",hotkey:"⌥M",enabled:()=>!0,execute:()=>{typeof window<"u"&&window.open("/plugins/siyuan-slidev/slidev-client/presenter.html","SlidevPresenter","width=1200,height=800")}}),e.addCommand({langKey:"slidevExportCliMd",langText:"Slidev Pro: 导出 Slidev 标准 slides.md 文档 (下载到本地)",hotkey:"",enabled:()=>!0,execute:async()=>{if(e.latestCompiledDoc||await e.compileCurrentDocument(),!e.latestCompiledDoc){he.showMessage("请先打开并放映一篇思源笔记文档");return}e.cliBridge.downloadSlidesMd(e.latestCompiledDoc,`slides-${e.currentDocId||"demo"}.md`)&&he.showMessage("已生成标准 Slidev Markdown 并触发下载，可在本地使用 npx @slidev/cli 运行")}}),e.addCommand({langKey:"slidevProbeCliDevServer",langText:"Slidev Pro: 检测本地 Slidev CLI DevServer 状态 (localhost:3030)",hotkey:"",enabled:()=>!0,execute:async()=>{he.showMessage("正在探测本地 Slidev CLI DevServer (http://localhost:3030)..."),await e.cliBridge.probeServer(1500)?he.showMessage("🟢 本地 Slidev CLI DevServer 运行正常！可直接在浏览器访问 http://localhost:3030"):he.showMessage("⚪ 未检测到运行中的本地 Slidev CLI DevServer (端口 3030 未开启)")}}),e.addCommand({langKey:"slidevSyncToCliWorkspace",langText:"Slidev Pro: 同步 slides.md 至思源工作空间存储目录",hotkey:"",enabled:()=>!0,execute:async()=>{if(e.latestCompiledDoc||await e.compileCurrentDocument(),!e.latestCompiledDoc){he.showMessage("请先打开并放映一篇思源笔记文档");return}const t=await e.cliBridge.syncToWorkspaceFile(e.latestCompiledDoc,"/data/storage/petal/siyuan-slidev/slides.md",rs);t.success?he.showMessage(`已成功同步最新 slides.md 至工作空间：${t.path}`):he.showMessage(`同步失败：${t.error}`)}})}class M0{constructor(t=400){ke(this,"entries",new Map);this.ttlMs=t}get(t,i=Date.now()){if(!t)return;const n=this.entries.get(t);if(n){if(i-n.at>this.ttlMs){this.entries.delete(t);return}return n.attrs}}set(t,i,n=Date.now()){!t||!i||this.entries.set(t,{attrs:i,at:n})}invalidate(t){t?this.entries.delete(t):this.entries.clear()}get size(){return this.entries.size}}function D0(e){const t=new Map;if(!(e!=null&&e.slides))return t;const i=n=>{for(const o of n||[])o!=null&&o.id&&o.ial&&t.set(o.id,o.ial)};for(const n of e.slides)i(n.blocks),i(n.noteBlocks);return t}class L0{constructor(t=150){ke(this,"lastBlockId","");ke(this,"lastAt",0);this.windowMs=t}shouldSkip(t,i=Date.now()){return t&&t===this.lastBlockId&&i-this.lastAt<this.windowMs?!0:(this.lastBlockId=t,this.lastAt=i,!1)}reset(){this.lastBlockId="",this.lastAt=0}}class O0{constructor(){ke(this,"attrCache",new M0);ke(this,"compiledIalIndex",{doc:null,map:new Map})}async resolveBlockAttrs(t,i){if(!t)return{};const n=Be.getBlockAttrOverride(t),o=this.getCompiledIal(i,t);if(n||o)return{...o||{},...n||{}};const s=this.attrCache.get(t);if(s)return s;const l=await Cs(t).catch(()=>({}))||{};return this.attrCache.set(t,l),l}getCompiledIal(t,i){if(t)return this.compiledIalIndex.doc!==t&&(this.compiledIalIndex={doc:t,map:D0(t)}),this.compiledIalIndex.map.get(i)}invalidateAttrCache(t){this.attrCache.invalidate(t)}getActiveDocumentId(){if(typeof document>"u")return"";const t=document.querySelector(".layout__wnd--active .protyle-title[data-node-id]")||document.querySelector(".item--focus .protyle-title[data-node-id]")||document.querySelector(".protyle-title[data-node-id]"),i=t==null?void 0:t.getAttribute("data-node-id");if(i)return i;const n=document.querySelector(".protyle .protyle-title[data-node-id]"),o=n==null?void 0:n.getAttribute("data-node-id");if(o)return o;const s=document.querySelector("[data-doc-id]"),l=s==null?void 0:s.getAttribute("data-doc-id");return l||""}resolveDocIdFromElement(t,i=""){const n=t.closest(".protyle-title"),o=n==null?void 0:n.getAttribute("data-node-id");if(o)return o;const s=t.closest(".protyle"),l=s==null?void 0:s.querySelector(".protyle-title"),r=l==null?void 0:l.getAttribute("data-node-id");if(r)return r;const a=t.closest("[data-doc-id]"),c=a==null?void 0:a.getAttribute("data-doc-id");if(c)return c;const d=this.getActiveDocumentId();return d||i}async switchToDocGlobalInspector(t,i){var s;if(!t)return;let n=i||"";if(!n&&typeof document<"u"){const l=document.querySelector(`.protyle-title[data-node-id="${t}"] .protyle-title__input`)||document.querySelector(`.protyle[data-doc-id="${t}"] .protyle-title__input`)||document.querySelector(".protyle-title__input");n=((s=l==null?void 0:l.innerText)==null?void 0:s.trim())||""}const o=await this.resolveBlockAttrs(t,null);ao({id:t,rootId:t,type:"doc",content:n,attrs:o,isDivider:!1,isCode:!1}),_s(t)}handleBlockClickedFromSlide(t,i,n,o){var a;if(!t)return!1;const s=Ni(t,i),l=document.querySelector(`.protyle-wysiwyg [data-node-id="${t}"]`)||document.querySelector(`[data-node-id="${t}"]`),r=(l==null?void 0:l.getAttribute("data-type"))||"";if(l)this.syncInspectorBlock(l,t,r,n,o);else{let c="",d="";if(o!=null&&o.slides){const m=o.slides.find(b=>{var u,h,f;return b.startBlockId===t||((u=b.blocks)==null?void 0:u.some(v=>v.id===t))||((h=b.allBlockIds)==null?void 0:h.includes(t))||((f=b.noteBlocks)==null?void 0:f.some(v=>v.id===t))});m!=null&&m.startBlockId&&(c=m.startBlockId),(a=m==null?void 0:m.frontmatter)!=null&&a.layout&&(d=m.frontmatter.layout)}this.resolveBlockAttrs(t,o).then(async m=>{if(c&&!d){const b=Be.getBlockAttrOverride(c);if(b!=null&&b[ge]||b!=null&&b["custom-slidev-layout"])d=b[ge]||b["custom-slidev-layout"]||"";else{const u=await this.resolveBlockAttrs(c,o);d=u[ge]||u["custom-slidev-layout"]||"",u&&Object.keys(u).length>0&&Be.setBlockAttrOverride(c,u)}}ao({id:t,rootId:n,type:r||"NodeParagraph",attrs:m||{},pageDividerId:c,pageDividerLayout:d})}).catch(()=>{})}return s}async syncInspectorBlock(t,i,n,o,s){var O,U,B,R,F,ee,I,M;let l=t,r=i,a=n;const c=t.closest('[data-type="NodeCallout"]');if(c&&c!==t){const J=c.getAttribute("data-node-id");if(J){const Y=await this.resolveBlockAttrs(J,s),te=Be.getBlockAttrOverride(J)||{},ie={...Y,...te};(ie[nt]||ie["slidev-note"])&&(l=c,r=J,a="NodeCallout")}}const d=l.closest(".protyle-wysiwyg > [data-node-id]")||l,m=(d==null?void 0:d.getAttribute("data-node-id"))||r,b=a==="NodeThematicBreak"||a==="tb"||a==="thematic-break"||(d==null?void 0:d.getAttribute("data-type"))==="NodeThematicBreak"||(d==null?void 0:d.getAttribute("data-type"))==="tb"||!!((O=d==null?void 0:d.classList)!=null&&O.contains("hr")),u=a==="NodeCodeBlock",h=((U=l.innerText)==null?void 0:U.trim())||"",f=await this.resolveBlockAttrs(r,s),v=Be.getBlockAttrOverride(r)||{},k={...f,...v};let S="",$="";if(b)S=r,$=k[ge]||k["custom-slidev-layout"]||"";else{let J=d.previousElementSibling;for(;J;){const Y=J.getAttribute("data-type");if(Y==="NodeThematicBreak"||Y==="tb"||(B=J.classList)!=null&&B.contains("hr")){S=J.getAttribute("data-node-id")||"";break}J=J.previousElementSibling}}if(s!=null&&s.slides){const J=[r,m];let Y=l.parentElement;for(;Y&&!Y.classList.contains("protyle-wysiwyg");){const ie=Y.getAttribute("data-node-id");ie&&!J.includes(ie)&&J.push(ie),Y=Y.parentElement}const te=s.slides.find(ie=>{var pe,le,N;return J.includes(ie.startBlockId)||((pe=ie.blocks)==null?void 0:pe.some(ae=>J.includes(ae.id)))||((le=ie.allBlockIds)==null?void 0:le.some(ae=>J.includes(ae)))||((N=ie.noteBlocks)==null?void 0:N.some(ae=>J.includes(ae.id)))});te&&(!S&&te.startBlockId&&(S=te.startBlockId),!$&&((R=te.frontmatter)!=null&&R.layout)&&($=te.frontmatter.layout))}if(S){const J=Be.getBlockAttrOverride(S);if(J&&(ge in J||"custom-slidev-layout"in J)&&($=J[ge]||J["custom-slidev-layout"]||""),!$&&(s!=null&&s.slides)){const Y=s.slides.find(te=>te.startBlockId===S);(F=Y==null?void 0:Y.frontmatter)!=null&&F.layout&&($=Y.frontmatter.layout)}if(!$){const Y=await this.resolveBlockAttrs(S,s);$=Y[ge]||Y["custom-slidev-layout"]||"",Y&&Object.keys(Y).length>0&&Be.setBlockAttrOverride(S,Y)}Je(S,{[ge]:$||""})}else if(o){const J=Be.getBlockAttrOverride(o);J&&(ge in J||"custom-slidev-layout"in J)?$=J[ge]||J["custom-slidev-layout"]||"":!$&&((M=(I=(ee=s==null?void 0:s.slides)==null?void 0:ee[0])==null?void 0:I.frontmatter)!=null&&M.layout)&&($=s.slides[0].frontmatter.layout)}const T=l.getAttribute(ge)||l.getAttribute("custom-slidev-layout"),D=k[ge]||k["custom-slidev-layout"]||"";T&&T!==D&&Je(r,{[ge]:D});const E=l.getAttribute(Ge)||l.getAttribute("custom-slidev-role"),x=k[Ge]||k["custom-slidev-role"]||"";E&&E!==x&&Je(r,{[Ge]:x});let W="",V="",G="";const X=l.closest('[data-type="NodeListItem"]');if(X&&X!==l){const J=X.getAttribute("data-node-id");if(J){W=J;const Y=await this.resolveBlockAttrs(J,s),te=Be.getBlockAttrOverride(J)||{},ie={...Y,...te};V=ie[Ee]||"",G=ie[We]||"";const pe=ie[ge]||ie["custom-slidev-layout"]||"",le=X.getAttribute(ge)||X.getAttribute("custom-slidev-layout");le&&le!==pe&&Je(J,{[ge]:pe});const N=ie[Ge]||ie["custom-slidev-role"]||"",ae=X.getAttribute(Ge)||X.getAttribute("custom-slidev-role");ae&&ae!==N&&Je(J,{[Ge]:N})}}const C=!!l.querySelector("img, span[data-type='img']"),P=(l.innerText||"").replace(/[\r\n\t\s]+/g," ").trim(),y=C&&P.length<=50;ao({id:r,rootId:o,type:a,content:h,attrs:k,isDivider:b,isCode:u,isImage:y,topBlockId:m,pageDividerId:S,pageDividerLayout:$,parentContainerId:W,parentContainerSlot:V,parentContainerClicks:G})}patchThematicBreakTransactions(t){if((t==null?void 0:t.cmd)==="transactions"&&Array.isArray(t.data)){for(const i of t.data)if(Array.isArray(i==null?void 0:i.doOperations)){for(const n of i.doOperations)if((n==null?void 0:n.action)==="updateAttrs"&&n.id&&n.data){const o=n.data.old||{},s=n.data.new||{},l={};for(const r of Object.keys(o))r in s||(l[r]="");for(const[r,a]of Object.entries(s))l[r]=String(a??"");Je(n.id,l),Be.setBlockAttrOverride(n.id,l)}}}}purgeStaleDomSlidevAttrs(t){var o,s,l;if(typeof document>"u"||!t)return;const i=new Map;if(Array.isArray(t.slides))for(const r of t.slides){if(r.startBlockId){const a=i.get(r.startBlockId)||{};(o=r.frontmatter)!=null&&o.layout&&(a[ge]=r.frontmatter.layout),i.set(r.startBlockId,a)}if(Array.isArray(r.blocks)){for(const a of r.blocks)if(a.id){const c=i.get(a.id)||{};(s=a.ial)!=null&&s[ge]&&(c[ge]=a.ial[ge]),(l=a.ial)!=null&&l[Ge]&&(c[Ge]=a.ial[Ge]),Object.keys(c).length>0&&i.set(a.id,c)}}}const n=Be.getAllAttrOverrides();for(const[r,a]of n.entries()){const c=i.get(r)||{};a[ge]!==void 0&&(c[ge]=a[ge]),a[Ge]!==void 0&&(c[Ge]=a[Ge]),i.set(r,c)}rh(i)}}const Ti=new O0;class R0{constructor(){ke(this,"inFlightDocId",null);ke(this,"pendingDocId",null);ke(this,"generation",0)}get isRunning(){return this.inFlightDocId!==null}get runningDocId(){return this.inFlightDocId}get pending(){return this.pendingDocId}tryBegin(t){return this.inFlightDocId!==null?(this.pendingDocId=t,null):(this.inFlightDocId=t,++this.generation)}isStale(t){return t!==this.generation}finish(){this.inFlightDocId=null;const t=this.pendingDocId;return this.pendingDocId=null,t}reset(){this.inFlightDocId=null,this.pendingDocId=null,this.generation=0}}const P0=150,N0=`<symbol id="iconSlidev" viewBox="0 0 1024 1024">
  <path fill="currentColor" d="M128 160h768c35.3 0 64 28.7 64 64v480c0 35.3-28.7 64-64 64H128c-35.3 0-64-28.7-64-64V224c0-35.3 28.7-64 64-64z m64 64v480h640V224H192z m128 640h384v64H320z"/>
  <path fill="currentColor" d="M416 336l256 144-256 144z"/>
</symbol>`,z0="slidev-dock",Gr="slidev-preview-tab",Zr=cf;class F0 extends he.Plugin{constructor(){super(...arguments);ke(this,"isMobile",!1);ke(this,"currentDocId","");ke(this,"previewTab",null);ke(this,"latestCompiledDoc",null);ke(this,"cliBridge",new qs);ke(this,"debounceTimer",null);ke(this,"activeCursorBlockId","");ke(this,"compileScheduler",new R0);ke(this,"dirtyDocId",null);ke(this,"inspectorSyncThrottle",new L0);ke(this,"onSwitchProtyleBound",this.onSwitchProtyle.bind(this));ke(this,"onWsMainBound",this.onWsMain.bind(this));ke(this,"onBlockClickedBound",this.onBlockClickedFromSlide.bind(this));ke(this,"onClickEditorTitleIconBound",this.onClickEditorTitleIcon.bind(this));ke(this,"onEditorClickBound",this.onEditorClick.bind(this));ke(this,"onSelectionChangeBound",this.onSelectionChange.bind(this));ke(this,"onClickEditorContentBound",this.onClickEditorContent.bind(this));ke(this,"onVisibilityChangeBound",this.onVisibilityChange.bind(this))}async onload(){const i=he.getFrontend();this.isMobile=i==="mobile"||i==="browser-mobile",await this.loadGlobalSettings(),this.addIcons(N0),this.addTopBar({id:"slidev-topbar-play",icon:"iconSlidev",title:"即现演示",position:"right",callback:()=>{this.openBottomPreviewTab()}}),B0(this);const n=this;if(this.addTab({type:Gr,init(o){const s=this||o;n.previewTab=(s==null?void 0:s.tab)||null,C0(s.element,n),n.updatePreviewTabHeader()},destroy(){n.previewTab===(this==null?void 0:this.tab)&&(n.previewTab=null),Ra(this.element)}}),this.addDock({config:{position:"RightTop",size:{width:320,height:0},icon:"iconSlidev",title:"Slidev 演示配置"},data:{},type:z0,init(){$0(this.element,n)},destroy(){Pa(this.element)}}),this.eventBus&&typeof this.eventBus.emit!="function"&&(this.eventBus.emit=(o,s)=>{try{typeof window<"u"&&window.dispatchEvent(new CustomEvent(`siyuan-event-${o}`,{detail:s}))}catch{}}),this.eventBus.on("switch-protyle",this.onSwitchProtyleBound),this.eventBus.on("ws-main",this.onWsMainBound),this.eventBus.on("slidev:request-compile",()=>this.compileCurrentDocument()),this.eventBus.on("slidev:block-clicked",this.onBlockClickedBound),this.eventBus.on("click-editortitleicon",this.onClickEditorTitleIconBound),this.eventBus.on("click-editorcontent",this.onClickEditorContentBound),typeof document<"u"&&(document.addEventListener("click",this.onEditorClickBound,!0),document.addEventListener("selectionchange",this.onSelectionChangeBound),document.addEventListener("visibilitychange",this.onVisibilityChangeBound)),typeof document<"u"){const o=()=>{const s=this.getActiveDocumentId();s&&(s!==this.currentDocId&&(this.currentDocId=s,this.updatePreviewTabHeader("",s)),this.latestCompiledDoc||this.markCompileDirty(s))};setTimeout(o,300),setTimeout(o,1e3)}}async onDataChanged(i){await this.loadGlobalSettings(),this.currentDocId&&this.markCompileDirty(this.currentDocId)}async loadGlobalSettings(){try{const i=await this.loadData(Zr),n=df(i);return Li(n),n}catch{return Li(sn),sn}}async saveGlobalSettings(i){const n=No(),o=Li({...n,...i||{}});try{await this.saveData(Zr,o)}catch(l){console.error("保存 Slidev 全局配置失败",l)}const s=this.currentDocId||this.getActiveDocumentId();return s&&this.markCompileDirty(s),o}onunload(){this.debounceTimer&&(window.clearTimeout(this.debounceTimer),this.debounceTimer=null),this.compileScheduler.reset(),this.inspectorSyncThrottle.reset(),this.dirtyDocId=null,so.clear(),this.eventBus.off("switch-protyle",this.onSwitchProtyleBound),this.eventBus.off("ws-main",this.onWsMainBound),this.eventBus.off("click-editortitleicon",this.onClickEditorTitleIconBound),this.eventBus.off("click-editorcontent",this.onClickEditorContentBound),typeof document<"u"&&(document.removeEventListener("click",this.onEditorClickBound,!0),document.removeEventListener("selectionchange",this.onSelectionChangeBound),document.removeEventListener("visibilitychange",this.onVisibilityChangeBound)),jn.detach()}onVisibilityChange(){typeof document<"u"&&document.visibilityState==="visible"&&this.flushDirtyCompile()}async openBottomPreviewTab(){this.currentDocId||(this.currentDocId=this.getActiveDocumentId());const i=this.currentDocId?await this.fetchDocumentTitle(this.currentDocId):"",n=this.buildPreviewTabTitle(i);await he.openTab({app:this.app,custom:{id:this.name+Gr,title:n,icon:"iconSlidev",data:{docId:this.currentDocId}},position:"bottom"}),this.currentDocId&&this.compileCurrentDocument(this.currentDocId),this.updatePreviewTabHeader(i,this.currentDocId)}onClickEditorTitleIcon(i){var l;const n=i.detail,o=n==null?void 0:n.menu,s=((l=n==null?void 0:n.data)==null?void 0:l.id)||this.currentDocId;!o||!s||o.addItem({icon:"iconSlidev",label:"Slidev 全局演示配置",submenu:[{label:"初始化演示属性 (custom-slidev-*)",click:async()=>{await De(s,{"custom-slidev-theme":"default","custom-slidev-aspect-ratio":"16/9","custom-slidev-default-transition":"slide-left"}),he.showMessage("已为当前文档初始化 Slidev 演示属性"),this.compileCurrentDocument(s)}},{type:"separator"},{label:"主题: 默认 (default)",click:async()=>{await De(s,{"custom-slidev-theme":"default"}),he.showMessage("已切换为 default 主题"),this.compileCurrentDocument(s)}},{label:"主题: 优雅衬线 (seriph)",click:async()=>{await De(s,{"custom-slidev-theme":"seriph"}),he.showMessage("已切换为 seriph 主题"),this.compileCurrentDocument(s)}},{label:"主题: 苹果极简 (apple-basic)",click:async()=>{await De(s,{"custom-slidev-theme":"apple-basic"}),he.showMessage("已切换为 apple-basic 主题"),this.compileCurrentDocument(s)}},{type:"separator"},{label:"画幅: 16 / 9 (宽屏)",click:async()=>{await De(s,{"custom-slidev-aspect-ratio":"16/9"}),he.showMessage("已切换画幅为 16/9"),this.compileCurrentDocument(s)}},{label:"画幅: 4 / 3 (标屏)",click:async()=>{await De(s,{"custom-slidev-aspect-ratio":"4/3"}),he.showMessage("已切换画幅为 4/3"),this.compileCurrentDocument(s)}}]})}async onSwitchProtyle(i){var l,r,a,c,d;const n=(l=i.detail)==null?void 0:l.protyle,o=(r=n==null?void 0:n.block)==null?void 0:r.rootID,s=((d=(c=(a=n==null?void 0:n.title)==null?void 0:a.editElement)==null?void 0:c.textContent)==null?void 0:d.trim())||"";if(o&&o!==this.currentDocId){this.currentDocId=o,this.activeCursorBlockId=o;const m=await Cs(o).catch(()=>({}));ao({id:o,rootId:o,type:"doc",attrs:m}),this.markCompileDirty(o),this.updatePreviewTabHeader(s,o)}}onClickEditorContent(i){var s,l;const n=i==null?void 0:i.detail;if(!n)return;const o=(l=(s=n.protyle)==null?void 0:s.block)==null?void 0:l.rootID;o&&(!this.currentDocId||this.currentDocId!==o)&&(this.currentDocId=o),n.event&&this.onEditorClick(n.event)}buildPreviewTabTitle(i){const n=(i||"").trim();return n?`即现（${n}）`:"即现"}async fetchDocumentTitle(i){var n,o,s;if(!i)return"";if(typeof document<"u"){const l=document.querySelector(`.protyle-title[data-node-id="${i}"] .protyle-title__input`)||document.querySelector(`.protyle[data-doc-id="${i}"] .protyle-title__input`)||(this.getActiveDocumentId()===i?document.querySelector(".layout__wnd--active .protyle-title__input"):null)||document.querySelector(".protyle-title__input"),r=((l==null?void 0:l.innerText)||(l==null?void 0:l.textContent)||"").trim();if(r)return r}if(this.latestCompiledDoc&&this.latestCompiledDoc.docId===i){const l=(n=this.latestCompiledDoc.slides)==null?void 0:n[0],r=(o=l==null?void 0:l.blocks)==null?void 0:o.find(a=>a.type==="h"||a.type==="NodeHeading");if(r!=null&&r.content)return r.content.trim()}try{const l=await en(`SELECT content FROM blocks WHERE id = '${i}' AND type = 'd' LIMIT 1`).catch(()=>[]);if(Array.isArray(l)&&l.length>0&&((s=l[0])!=null&&s.content))return String(l[0].content).trim()}catch{}return""}async updatePreviewTabHeader(i,n){var d,m,b;const o=_0(),s=!!((d=o==null?void 0:o.isPinned)!=null&&d.value),l=String(((m=o==null?void 0:o.pinnedDocId)==null?void 0:m.value)||"");if(s&&l&&n&&n!==l)return;const r=n||(s&&l?l:this.currentDocId||this.getActiveDocumentId());let a=(i||"").trim();!a&&r&&(a=await this.fetchDocumentTitle(r));const c=this.buildPreviewTabTitle(a);if(this.previewTab&&typeof this.previewTab.updateTitle=="function"){this.previewTab.updateTitle(c),this.previewTab.headElement&&this.previewTab.headElement.setAttribute("title",c);return}if(typeof document<"u"){const u=Array.from(document.querySelectorAll('.layout-tab-bar .item[data-type="tab-header"]'));for(const h of u){const f=h.querySelector(".item__text"),v=((b=f==null?void 0:f.textContent)==null?void 0:b.trim())||"";if(v.includes("Slidev 演示预览")||v.startsWith("即现")){f&&(f.textContent=c),h.setAttribute("title",c);break}}}}getActiveDocumentId(){return Ti.getActiveDocumentId()}resolveDocIdFromElement(i){return Ti.resolveDocIdFromElement(i,this.currentDocId)}async switchToDocGlobalInspector(i,n){i&&(this.activeCursorBlockId=i,this.currentDocId=i,await Ti.switchToDocGlobalInspector(i,n))}onWsMain(i){const n=i.detail;n&&n.cmd==="transactions"&&(Ti.patchThematicBreakTransactions(n),this.markCompileDirty())}markCompileDirty(i){const n=i||this.currentDocId||this.getActiveDocumentId();n&&(this.currentDocId||(this.currentDocId=n),this.dirtyDocId=n,this.scheduleDirtyCompile())}scheduleDirtyCompile(i=P0){if(this.debounceTimer&&(window.clearTimeout(this.debounceTimer),this.debounceTimer=null),!this.dirtyDocId)return;const n=so.getVisibility();if(n==="none")return;const o=n==="visible"?i:Math.max(i,k0);this.debounceTimer=window.setTimeout(()=>{this.debounceTimer=null;const s=this.dirtyDocId;this.dirtyDocId=null,s&&this.compileCurrentDocument(s,{reason:"auto"})},o)}flushDirtyCompile(){this.dirtyDocId&&this.scheduleDirtyCompile(0)}handleBlockClickedFromSlide(i,n){return i?(this.activeCursorBlockId=i,Ti.handleBlockClickedFromSlide(i,this.app,this.currentDocId,this.latestCompiledDoc)):!1}onBlockClickedFromSlide(i){const n=(i==null?void 0:i.detail)||i;n!=null&&n.blockId&&this.handleBlockClickedFromSlide(n.blockId,n.page)}onEditorClick(i){const n=i.target;if(!n)return;const o=n.closest(".protyle-title")||n.closest(".protyle-background");if(!!(o||n.closest(".protyle-content")&&!n.closest(".protyle-wysiwyg")&&!n.closest(".protyle-breadcrumb")&&!n.closest(".protyle-gutters"))){const d=this.resolveDocIdFromElement(n);if(d&&this.activeCursorBlockId!==d){const m=o||document.querySelector(`.protyle-title[data-node-id="${d}"]`)||document.querySelector(`.protyle[data-doc-id="${d}"] .protyle-title`),b=m==null?void 0:m.querySelector(".protyle-title__input"),u=((b==null?void 0:b.innerText)||(m==null?void 0:m.innerText)||"").trim();this.switchToDocGlobalInspector(d,u)}return}if(!n.closest(".protyle-wysiwyg"))return;const r=n.closest("[data-node-id]");if(!r)return;const a=r.getAttribute("data-node-id"),c=r.getAttribute("data-type")||"";a&&(this.currentDocId||(this.currentDocId=this.resolveDocIdFromElement(n)||""),this.currentDocId&&!this.latestCompiledDoc&&this.markCompileDirty(this.currentDocId),a!==this.activeCursorBlockId&&(this.activeCursorBlockId=a,_s(a)),this.syncInspectorBlock(r,a,c))}onSelectionChange(){if(typeof window>"u")return;const i=window.getSelection();if(!i||i.rangeCount===0)return;const n=i.anchorNode;if(!n)return;const o=n.nodeType===Node.ELEMENT_NODE?n:n.parentElement;if(!o)return;const s=o.closest(".protyle-title");if(!!(s||o.closest(".protyle-content")&&!o.closest(".protyle-wysiwyg"))){const d=this.resolveDocIdFromElement(o);if(d&&this.activeCursorBlockId!==d){const m=s||document.querySelector(`.protyle-title[data-node-id="${d}"]`)||document.querySelector(`.protyle[data-doc-id="${d}"] .protyle-title`),b=m==null?void 0:m.querySelector(".protyle-title__input"),u=((b==null?void 0:b.innerText)||(m==null?void 0:m.innerText)||"").trim();this.switchToDocGlobalInspector(d,u)}return}if(!o.closest(".protyle-wysiwyg"))return;const r=o.closest("[data-node-id]"),a=r==null?void 0:r.getAttribute("data-node-id"),c=(r==null?void 0:r.getAttribute("data-type"))||"";r&&a&&(this.currentDocId||(this.currentDocId=this.resolveDocIdFromElement(o)||""),this.currentDocId&&!this.latestCompiledDoc&&this.markCompileDirty(this.currentDocId),a!==this.activeCursorBlockId&&(this.activeCursorBlockId=a,_s(a)),this.syncInspectorBlock(r,a,c))}async syncInspectorBlock(i,n,o){this.inspectorSyncThrottle.shouldSkip(n)||await Ti.syncInspectorBlock(i,n,o,this.currentDocId,this.latestCompiledDoc)}async compileCurrentDocument(i,n){const o=(n==null?void 0:n.reason)??"explicit";let s=i||this.currentDocId;if(!s){const r=this.getActiveDocumentId();if(r)this.currentDocId=r,s=r;else return}if(o==="auto"&&so.getVisibility()==="none"){this.dirtyDocId=s;return}const l=this.compileScheduler.tryBegin(s);if(l!==null){this.dirtyDocId===s&&(this.dirtyDocId=null);try{const r=await Be.compile(s),a=!!this.currentDocId&&s!==this.currentDocId;!this.compileScheduler.isStale(l)&&!a&&(this.currentDocId||(this.currentDocId=s),this.latestCompiledDoc=r,I0(r,s),this.updatePreviewTabHeader("",s),this.purgeStaleDomSlidevAttrs(r))}catch(r){console.error("[SiYuanSlidev] Failed to compile document:",r)}finally{const r=this.compileScheduler.finish();r&&this.markCompileDirty(r)}}}purgeStaleDomSlidevAttrs(i){Ti.purgeStaleDomSlidevAttrs(i)}}module.exports=F0;
