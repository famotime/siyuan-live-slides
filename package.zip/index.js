"use strict";var Fa=Object.create;var Do=Object.defineProperty;var Ha=Object.getOwnPropertyDescriptor;var ja=Object.getOwnPropertyNames;var Ua=Object.getPrototypeOf,Wa=Object.prototype.hasOwnProperty;var Va=(t,i,e)=>i in t?Do(t,i,{enumerable:!0,configurable:!0,writable:!0,value:e}):t[i]=e;var qa=(t,i,e,n)=>{if(i&&typeof i=="object"||typeof i=="function")for(let o of ja(i))!Wa.call(t,o)&&o!==e&&Do(t,o,{get:()=>i[o],enumerable:!(n=Ha(i,o))||n.enumerable});return t};var Hn=(t,i,e)=>(e=t!=null?Fa(Ua(t)):{},qa(i||!t||!t.__esModule?Do(e,"default",{value:t,enumerable:!0}):e,t));var wt=(t,i,e)=>Va(t,typeof i!="symbol"?i+"":i,e);const ht=require("siyuan");async function be(t,i){const e=await ht.fetchSyncPost(t,i);return e.code===0?e.data:null}async function Ka(){return be("/api/notebook/lsNotebooks","")}async function Ga(t,i,e){return be("/api/filetree/createDocWithMd",{notebook:t,path:i,markdown:e})}async function Pr(t,i){const e=new FormData;e.append("assetsDirPath",t);for(const o of i)e.append("file[]",o);return be("/api/asset/upload",e)}async function Ii(t,i,e,n,o){return be("/api/block/insertBlock",{dataType:t,data:i,nextID:e,previousID:n,parentID:o})}async function Zo(t,i,e){return be("/api/block/appendBlock",{dataType:t,data:i,parentID:e})}async function Ws(t,i,e){return be("/api/block/updateBlock",{dataType:t,data:i,id:e})}async function Vs(t){return be("/api/block/deleteBlock",{id:t})}async function Za(t){return be("/api/block/getBlockKramdown",{id:t})}async function eo(t){return be("/api/block/getChildBlocks",{id:t})}async function Lt(t,i){return be("/api/attr/setBlockAttrs",{id:t,attrs:i})}async function Ze(t){return be("/api/attr/getBlockAttrs",{id:t})}async function yn(t){return be("/api/query/sql",{stmt:t})}async function Yo(t,i,e){const n=new FormData;return n.append("path",t),n.append("isDir",i.toString()),n.append("modTime",Math.floor(Date.now()/1e3).toString()),n.append("file",e),be("/api/file/putFile",n)}async function Rr(t){const i="/api/ai/chatGPT";try{const e=await be(i,{msg:t});return typeof e=="string"&&e.trim().length>0?e.trim():e&&typeof e.content=="string"&&e.content.trim().length>0?e.content.trim():null}catch{return null}}async function Ya(){return be("/api/storage/getInlineStyles","")}const Or=/\(\(([0-9a-zA-Z-]+)(?:\s*(?:'([^']*)'|"([^"]*)"|([^\)]+?)))?\s*\)\)/g;function Ja(t){const i=[];if(!t)return i;const e=new RegExp(Or.source,"g");let n;for(;(n=e.exec(t))!==null;){const o=n[2]??n[3]??n[4];i.push({fullMatch:n[0],blockId:n[1],anchorText:o?o.trim():void 0})}return i}function Xa(t,i){if(!t)return"";const e=new RegExp(Or.source,"g");return t.replace(e,(n,o,s,l,r)=>{const a=(s??l??r??"").trim();if(i&&i[o]){const u=i[o].trim();return`<div class="slidev-block-ref" data-ref-id="${o}">${u}</div>`}const c=a||`Ref(${o.slice(0,8)})`;return`<a href="siyuan://blocks/${o}" data-ref-id="${o}" class="slidev-ref-tag">🔗 ${c}</a>`})}const kn="custom-slidev-theme",wn="custom-slidev-aspect-ratio",zr="custom-slidev-highlighter",xn="custom-slidev-default-transition",Nr="custom-slidev-color-schema",Jo="custom-slidev-spacing",Bi="custom-slidev-slide",mt="custom-slidev-layout",Xt="custom-slidev-transition",jt="custom-slidev-background",Ee="custom-slidev-image",Ui="custom-slidev-notes",Wi="custom-slidev-class",un="custom-slidev-spacing",oe="custom-slidev-layout-ratio",Ae="custom-slidev-click",Ve="custom-slidev-motion",Ri="custom-slidev-shiki-lines",Bt="custom-slidev-slot",te="custom-slidev-note",Vt="custom-slidev-role",_n="custom-slidev-max-height",Ti="custom-slidev-autoplay",io="custom-slidev-loop",ji="custom-slidev-muted",no="custom-slidev-controls",Fr="background",oo="image-left",so="image-right";function ps(t){return t==="cols-header"||t==="two-cols-header"||t==="three-cols-header"}function Qa(t){return t.markdown&&t.markdown.trim()?t.markdown.trim():t.content&&t.content.trim()?t.content.trim():""}function tc(t){const i={};if(!t)return i;const e=t.replace(/^\{:\s*/,"").replace(/\s*\}$/,""),n=/([\w-]+)=(?:"([^"]*)"|'([^']*)'|(\S+))/g;let o;for(;(o=n.exec(e))!==null;){const s=o[1],l=o[2]??o[3]??o[4]??"";i[s]=l}return i}function ec(t){if(!t)return!1;const i=t.trim();return i.startsWith("assets/")||i.startsWith("./assets/")||i.startsWith("/assets/")}function ic(t){const i=t.trim();return i.startsWith("./assets/")?i.slice(2):i.startsWith("/assets/")?i.slice(1):i}function $e(t,i){if(!ec(t))return t;const e=ic(t);return i!=null&&i.base64Map&&i.base64Map[e]?i.base64Map[e]:i!=null&&i.baseUrl?`${i.baseUrl.replace(/\/+$/,"")}/${e}`:`/${e}`}function nc(t,i){if(!t)return"";let e=t;return e=e.replace(/!\[(.*?)\]\(((?:\.\/|\/)?assets\/[^\s)]+)\)/g,(n,o,s)=>{const l=$e(s,i);return`![${o}](${l})`}),e=e.replace(/(<(?:img|video|audio|source)\b[^>]*?\bsrc=["'])((?:\.\/|\/)?assets\/[^"']+)(["'][^>]*>)/gi,(n,o,s,l)=>{const r=$e(s,i);return`${o}${r}${l}`}),e=e.replace(/(url\(\s*["']?)((?:\.\/|\/)?assets\/[^"')]+)(["']?\s*\))/gi,(n,o,s,l)=>{const r=$e(s,i);return`${o}${r}${l}`}),e}/**
* @vue/shared v3.5.40
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/function hs(t){const i=Object.create(null);for(const e of t.split(","))i[e]=1;return e=>e in i}const Ut={},Vi=[],qe=()=>{},Hr=()=>!1,vo=t=>t.charCodeAt(0)===111&&t.charCodeAt(1)===110&&(t.charCodeAt(2)>122||t.charCodeAt(2)<97),bo=t=>t.startsWith("onUpdate:"),ce=Object.assign,ms=(t,i)=>{const e=t.indexOf(i);e>-1&&t.splice(e,1)},oc=Object.prototype.hasOwnProperty,zt=(t,i)=>oc.call(t,i),Ct=Array.isArray,qi=t=>Dn(t)==="[object Map]",tn=t=>Dn(t)==="[object Set]",qs=t=>Dn(t)==="[object Date]",At=t=>typeof t=="function",Qt=t=>typeof t=="string",Pe=t=>typeof t=="symbol",Ht=t=>t!==null&&typeof t=="object",jr=t=>(Ht(t)||At(t))&&At(t.then)&&At(t.catch),Ur=Object.prototype.toString,Dn=t=>Ur.call(t),sc=t=>Dn(t).slice(8,-1),Wr=t=>Dn(t)==="[object Object]",gs=t=>Qt(t)&&t!=="NaN"&&t[0]!=="-"&&""+parseInt(t,10)===t,fn=hs(",key,ref,ref_for,ref_key,onVnodeBeforeMount,onVnodeMounted,onVnodeBeforeUpdate,onVnodeUpdated,onVnodeBeforeUnmount,onVnodeUnmounted"),yo=t=>{const i=Object.create(null);return(e=>i[e]||(i[e]=t(e)))},rc=/-\w/g,ve=yo(t=>t.replace(rc,i=>i.slice(1).toUpperCase())),lc=/\B([A-Z])/g,bi=yo(t=>t.replace(lc,"-$1").toLowerCase()),ko=yo(t=>t.charAt(0).toUpperCase()+t.slice(1)),Lo=yo(t=>t?`on${ko(t)}`:""),Ue=(t,i)=>!Object.is(t,i),Zn=(t,...i)=>{for(let e=0;e<t.length;e++)t[e](...i)},Vr=(t,i,e,n=!1)=>{Object.defineProperty(t,i,{configurable:!0,enumerable:!1,writable:n,value:e})},wo=t=>{const i=parseFloat(t);return isNaN(i)?t:i};let Ks;const xo=()=>Ks||(Ks=typeof globalThis<"u"?globalThis:typeof self<"u"?self:typeof window<"u"?window:typeof global<"u"?global:{});function Sn(t){if(Ct(t)){const i={};for(let e=0;e<t.length;e++){const n=t[e],o=Qt(n)?uc(n):Sn(n);if(o)for(const s in o)i[s]=o[s]}return i}else if(Qt(t)||Ht(t))return t}const ac=/;(?![^(]*\))/g,cc=/:([^]+)/,dc=/\/\*[^]*?\*\//g;function uc(t){const i={};return t.replace(dc,"").split(ac).forEach(e=>{if(e){const n=e.split(cc);n.length>1&&(i[n[0].trim()]=n[1].trim())}}),i}function It(t){let i="";if(Qt(t))i=t;else if(Ct(t))for(let e=0;e<t.length;e++){const n=It(t[e]);n&&(i+=n+" ")}else if(Ht(t))for(const e in t)t[e]&&(i+=e+" ");return i.trim()}const fc="itemscope,allowfullscreen,formnovalidate,ismap,nomodule,novalidate,readonly",pc=hs(fc);function qr(t){return!!t||t===""}function hc(t,i){if(t.length!==i.length)return!1;let e=!0;for(let n=0;e&&n<t.length;n++)e=en(t[n],i[n]);return e}function en(t,i){if(t===i)return!0;let e=qs(t),n=qs(i);if(e||n)return e&&n?t.getTime()===i.getTime():!1;if(e=Pe(t),n=Pe(i),e||n)return t===i;if(e=Ct(t),n=Ct(i),e||n)return e&&n?hc(t,i):!1;if(e=Ht(t),n=Ht(i),e||n){if(!e||!n)return!1;const o=Object.keys(t).length,s=Object.keys(i).length;if(o!==s)return!1;for(const l in t){const r=t.hasOwnProperty(l),a=i.hasOwnProperty(l);if(r&&!a||!r&&a||!en(t[l],i[l]))return!1}}return String(t)===String(i)}function vs(t,i){return t.findIndex(e=>en(e,i))}const Kr=t=>!!(t&&t.__v_isRef===!0),St=t=>Qt(t)?t:t==null?"":Ct(t)||Ht(t)&&(t.toString===Ur||!At(t.toString))?Kr(t)?St(t.value):JSON.stringify(t,Gr,2):String(t),Gr=(t,i)=>Kr(i)?Gr(t,i.value):qi(i)?{[`Map(${i.size})`]:[...i.entries()].reduce((e,[n,o],s)=>(e[Po(n,s)+" =>"]=o,e),{})}:tn(i)?{[`Set(${i.size})`]:[...i.values()].map(e=>Po(e))}:Pe(i)?Po(i):Ht(i)&&!Ct(i)&&!Wr(i)?String(i):i,Po=(t,i="")=>{var e;return Pe(t)?`Symbol(${(e=t.description)!=null?e:i})`:t};/**
* @vue/reactivity v3.5.40
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/let re;class mc{constructor(i=!1){this.detached=i,this._active=!0,this._on=0,this.effects=[],this.cleanups=[],this._isPaused=!1,this._warnOnRun=!0,this.__v_skip=!0,!i&&re&&(re.active?(this.parent=re,this.index=(re.scopes||(re.scopes=[])).push(this)-1):(this._active=!1,this._warnOnRun=!1))}get active(){return this._active}pause(){if(this._active){this._isPaused=!0;let i,e;if(this.scopes){const n=this.scopes.slice();for(i=0,e=n.length;i<e;i++)n[i].pause()}for(i=0,e=this.effects.length;i<e;i++)this.effects[i].pause()}}resume(){if(this._active&&this._isPaused){this._isPaused=!1;let i,e;if(this.scopes){const o=this.scopes.slice();for(i=0,e=o.length;i<e;i++)o[i].resume()}const n=this.effects.slice();for(i=0,e=n.length;i<e;i++)n[i].resume()}}run(i){if(this._active){const e=re;try{return re=this,i()}finally{re=e}}}on(){++this._on===1&&(this.prevScope=re,re=this)}off(){if(this._on>0&&--this._on===0){if(re===this)re=this.prevScope;else{let i=re;for(;i;){if(i.prevScope===this){i.prevScope=this.prevScope;break}i=i.prevScope}}this.prevScope=void 0}}stop(i){if(this._active){this._active=!1;let e,n;for(e=0,n=this.effects.length;e<n;e++)this.effects[e].stop();for(this.effects.length=0,e=0,n=this.cleanups.length;e<n;e++)this.cleanups[e]();if(this.cleanups.length=0,this.scopes){const o=this.scopes.slice();for(e=0,n=o.length;e<n;e++)o[e].stop(!0);this.scopes.length=0}if(!this.detached&&this.parent&&!i){const o=this.parent.scopes.pop();o&&o!==this&&(this.parent.scopes[this.index]=o,o.index=this.index)}this.parent=void 0}}}function gc(){return re}let Wt;const Ro=new WeakSet;class Zr{constructor(i){this.fn=i,this.deps=void 0,this.depsTail=void 0,this.flags=5,this.next=void 0,this.cleanup=void 0,this.scheduler=void 0,re&&(re.active?re.effects.push(this):this.flags&=-2)}pause(){this.flags|=64}resume(){this.flags&64&&(this.flags&=-65,Ro.has(this)&&(Ro.delete(this),this.trigger()))}notify(){this.flags&2&&!(this.flags&32)||this.flags&8||Jr(this)}run(){if(!(this.flags&1))return this.fn();this.flags|=2,Gs(this),Xr(this);const i=Wt,e=Le;Wt=this,Le=!0;try{return this.fn()}finally{Qr(this),Wt=i,Le=e,this.flags&=-3}}stop(){if(this.flags&1){for(let i=this.deps;i;i=i.nextDep)ks(i);this.deps=this.depsTail=void 0,Gs(this),this.onStop&&this.onStop(),this.flags&=-2}}trigger(){this.flags&64?Ro.add(this):this.scheduler?this.scheduler():this.runIfDirty()}runIfDirty(){Xo(this)&&this.run()}get dirty(){return Xo(this)}}let Yr=0,pn,hn;function Jr(t,i=!1){if(t.flags|=8,i){t.next=hn,hn=t;return}t.next=pn,pn=t}function bs(){Yr++}function ys(){if(--Yr>0)return;if(hn){let i=hn;for(hn=void 0;i;){const e=i.next;i.next=void 0,i.flags&=-9,i=e}}let t;for(;pn;){let i=pn;for(pn=void 0;i;){const e=i.next;if(i.next=void 0,i.flags&=-9,i.flags&1)try{i.trigger()}catch(n){t||(t=n)}i=e}}if(t)throw t}function Xr(t){for(let i=t.deps;i;i=i.nextDep)i.version=-1,i.prevActiveLink=i.dep.activeLink,i.dep.activeLink=i}function Qr(t){let i,e=t.depsTail,n=e;for(;n;){const o=n.prevDep;n.version===-1?(n===e&&(e=o),ks(n),vc(n)):i=n,n.dep.activeLink=n.prevActiveLink,n.prevActiveLink=void 0,n=o}t.deps=i,t.depsTail=e}function Xo(t){for(let i=t.deps;i;i=i.nextDep)if(i.dep.version!==i.version||i.dep.computed&&(tl(i.dep.computed)||i.dep.version!==i.version))return!0;return!!t._dirty}function tl(t){if(t.flags&4&&!(t.flags&16)||(t.flags&=-17,t.globalVersion===Cn)||(t.globalVersion=Cn,!t.isSSR&&t.flags&128&&(!t.deps&&!t._dirty||!Xo(t))))return;t.flags|=2;const i=t.dep,e=Wt,n=Le;Wt=t,Le=!0;try{Xr(t);const o=t.fn(t._value);(i.version===0||Ue(o,t._value))&&(t.flags|=128,t._value=o,i.version++)}catch(o){throw i.version++,o}finally{Wt=e,Le=n,Qr(t),t.flags&=-3}}function ks(t,i=!1){const{dep:e,prevSub:n,nextSub:o}=t;if(n&&(n.nextSub=o,t.prevSub=void 0),o&&(o.prevSub=n,t.nextSub=void 0),e.subs===t&&(e.subs=n,!n&&e.computed)){e.computed.flags&=-5;for(let s=e.computed.deps;s;s=s.nextDep)ks(s,!0)}!i&&!--e.sc&&e.map&&e.map.delete(e.key)}function vc(t){const{prevDep:i,nextDep:e}=t;i&&(i.nextDep=e,t.prevDep=void 0),e&&(e.prevDep=i,t.nextDep=void 0)}let Le=!0;const el=[];function ni(){el.push(Le),Le=!1}function oi(){const t=el.pop();Le=t===void 0?!0:t}function Gs(t){const{cleanup:i}=t;if(t.cleanup=void 0,i){const e=Wt;Wt=void 0;try{i()}finally{Wt=e}}}let Cn=0;class bc{constructor(i,e){this.sub=i,this.dep=e,this.version=e.version,this.nextDep=this.prevDep=this.nextSub=this.prevSub=this.prevActiveLink=void 0}}class ws{constructor(i){this.computed=i,this.version=0,this.activeLink=void 0,this.subs=void 0,this.map=void 0,this.key=void 0,this.sc=0,this.__v_skip=!0}track(i){if(!Wt||!Le||Wt===this.computed)return;let e=this.activeLink;if(e===void 0||e.sub!==Wt)e=this.activeLink=new bc(Wt,this),Wt.deps?(e.prevDep=Wt.depsTail,Wt.depsTail.nextDep=e,Wt.depsTail=e):Wt.deps=Wt.depsTail=e,il(e);else if(e.version===-1&&(e.version=this.version,e.nextDep)){const n=e.nextDep;n.prevDep=e.prevDep,e.prevDep&&(e.prevDep.nextDep=n),e.prevDep=Wt.depsTail,e.nextDep=void 0,Wt.depsTail.nextDep=e,Wt.depsTail=e,Wt.deps===e&&(Wt.deps=n)}return e}trigger(i){this.version++,Cn++,this.notify(i)}notify(i){bs();try{for(let e=this.subs;e;e=e.prevSub)e.sub.notify()&&e.sub.dep.notify()}finally{ys()}}}function il(t){if(t.dep.sc++,t.sub.flags&4){const i=t.dep.computed;if(i&&!t.dep.subs){i.flags|=20;for(let n=i.deps;n;n=n.nextDep)il(n)}const e=t.dep.subs;e!==t&&(t.prevSub=e,e&&(e.nextSub=t)),t.dep.subs=t}}const Qo=new WeakMap,Mi=Symbol(""),ts=Symbol(""),$n=Symbol("");function fe(t,i,e){if(Le&&Wt){let n=Qo.get(t);n||Qo.set(t,n=new Map);let o=n.get(e);o||(n.set(e,o=new ws),o.map=n,o.key=e),o.track()}}function Xe(t,i,e,n,o,s){const l=Qo.get(t);if(!l){Cn++;return}const r=a=>{a&&a.trigger()};if(bs(),i==="clear")l.forEach(r);else{const a=Ct(t),c=a&&gs(e);if(a&&e==="length"){const u=Number(n);l.forEach((m,v)=>{(v==="length"||v===$n||!Pe(v)&&v>=u)&&r(m)})}else switch((e!==void 0||l.has(void 0))&&r(l.get(e)),c&&r(l.get($n)),i){case"add":a?c&&r(l.get("length")):(r(l.get(Mi)),qi(t)&&r(l.get(ts)));break;case"delete":a||(r(l.get(Mi)),qi(t)&&r(l.get(ts)));break;case"set":qi(t)&&r(l.get(Mi));break}}ys()}function Fi(t){const i=Ot(t);return i===t?i:(fe(i,"iterate",$n),Be(t)?i:i.map(Re))}function _o(t){return fe(t=Ot(t),"iterate",$n),t}function He(t,i){return si(t)?Yi(Di(t)?Re(i):i):Re(i)}const yc={__proto__:null,[Symbol.iterator](){return Oo(this,Symbol.iterator,t=>He(this,t))},concat(...t){return Fi(this).concat(...t.map(i=>Ct(i)?Fi(i):i))},entries(){return Oo(this,"entries",t=>(t[1]=He(this,t[1]),t))},every(t,i){return Ge(this,"every",t,i,void 0,arguments)},filter(t,i){return Ge(this,"filter",t,i,e=>e.map(n=>He(this,n)),arguments)},find(t,i){return Ge(this,"find",t,i,e=>He(this,e),arguments)},findIndex(t,i){return Ge(this,"findIndex",t,i,void 0,arguments)},findLast(t,i){return Ge(this,"findLast",t,i,e=>He(this,e),arguments)},findLastIndex(t,i){return Ge(this,"findLastIndex",t,i,void 0,arguments)},forEach(t,i){return Ge(this,"forEach",t,i,void 0,arguments)},includes(...t){return zo(this,"includes",t)},indexOf(...t){return zo(this,"indexOf",t)},join(t){return Fi(this).join(t)},lastIndexOf(...t){return zo(this,"lastIndexOf",t)},map(t,i){return Ge(this,"map",t,i,void 0,arguments)},pop(){return sn(this,"pop")},push(...t){return sn(this,"push",t)},reduce(t,...i){return Zs(this,"reduce",t,i)},reduceRight(t,...i){return Zs(this,"reduceRight",t,i)},shift(){return sn(this,"shift")},some(t,i){return Ge(this,"some",t,i,void 0,arguments)},splice(...t){return sn(this,"splice",t)},toReversed(){return Fi(this).toReversed()},toSorted(t){return Fi(this).toSorted(t)},toSpliced(...t){return Fi(this).toSpliced(...t)},unshift(...t){return sn(this,"unshift",t)},values(){return Oo(this,"values",t=>He(this,t))}};function Oo(t,i,e){const n=_o(t),o=n[i]();return n!==t&&!Be(t)&&(o._next=o.next,o.next=()=>{const s=o._next();return s.done||(s.value=e(s.value)),s}),o}const kc=Array.prototype;function Ge(t,i,e,n,o,s){const l=_o(t),r=l!==t&&!Be(t),a=l[i];if(a!==kc[i]){const m=a.apply(t,s);return r?Re(m):m}let c=e;l!==t&&(r?c=function(m,v){return e.call(this,He(t,m),v,t)}:e.length>2&&(c=function(m,v){return e.call(this,m,v,t)}));const u=a.call(l,c,n);return r&&o?o(u):u}function Zs(t,i,e,n){const o=_o(t),s=o!==t&&!Be(t);let l=e,r=!1;o!==t&&(s?(r=n.length===0,l=function(c,u,m){return r&&(r=!1,c=He(t,c)),e.call(this,c,He(t,u),m,t)}):e.length>3&&(l=function(c,u,m){return e.call(this,c,u,m,t)}));const a=o[i](l,...n);return r?He(t,a):a}function zo(t,i,e){const n=Ot(t);fe(n,"iterate",$n);const o=n[i](...e);return(o===-1||o===!1)&&Ss(e[0])?(e[0]=Ot(e[0]),n[i](...e)):o}function sn(t,i,e=[]){ni(),bs();const n=Ot(t)[i].apply(t,e);return ys(),oi(),n}const wc=hs("__proto__,__v_isRef,__isVue"),nl=new Set(Object.getOwnPropertyNames(Symbol).filter(t=>t!=="arguments"&&t!=="caller").map(t=>Symbol[t]).filter(Pe));function xc(t){Pe(t)||(t=String(t));const i=Ot(this);return fe(i,"has",t),i.hasOwnProperty(t)}class ol{constructor(i=!1,e=!1){this._isReadonly=i,this._isShallow=e}get(i,e,n){if(e==="__v_skip")return i.__v_skip;const o=this._isReadonly,s=this._isShallow;if(e==="__v_isReactive")return!o;if(e==="__v_isReadonly")return o;if(e==="__v_isShallow")return s;if(e==="__v_raw")return n===(o?s?Mc:al:s?ll:rl).get(i)||Object.getPrototypeOf(i)===Object.getPrototypeOf(n)?i:void 0;const l=Ct(i);if(!o){let a;if(l&&(a=yc[e]))return a;if(e==="hasOwnProperty")return xc}const r=Reflect.get(i,e,Zt(i)?i:n);if((Pe(e)?nl.has(e):wc(e))||(o||fe(i,"get",e),s))return r;if(Zt(r)){const a=l&&gs(e)?r:r.value;return o&&Ht(a)?is(a):a}return Ht(r)?o?is(r):So(r):r}}class sl extends ol{constructor(i=!1){super(!1,i)}set(i,e,n,o){let s=i[e];const l=Ct(i)&&gs(e);if(!this._isShallow){const c=si(s);if(!Be(n)&&!si(n)&&(s=Ot(s),n=Ot(n)),!l&&Zt(s)&&!Zt(n))return c||(s.value=n),!0}const r=l?Number(e)<i.length:zt(i,e),a=Reflect.set(i,e,n,Zt(i)?i:o);return i===Ot(o)&&a&&(r?Ue(n,s)&&Xe(i,"set",e,n):Xe(i,"add",e,n)),a}deleteProperty(i,e){const n=zt(i,e);i[e];const o=Reflect.deleteProperty(i,e);return o&&n&&Xe(i,"delete",e,void 0),o}has(i,e){const n=Reflect.has(i,e);return(!Pe(e)||!nl.has(e))&&fe(i,"has",e),n}ownKeys(i){return fe(i,"iterate",Ct(i)?"length":Mi),Reflect.ownKeys(i)}}class _c extends ol{constructor(i=!1){super(!0,i)}set(i,e){return!0}deleteProperty(i,e){return!0}}const Sc=new sl,Cc=new _c,$c=new sl(!0);const es=t=>t,jn=t=>Reflect.getPrototypeOf(t);function Ic(t,i,e){return function(...n){const o=this.__v_raw,s=Ot(o),l=qi(s),r=t==="entries"||t===Symbol.iterator&&l,a=t==="keys"&&l,c=o[t](...n),u=e?es:i?Yi:Re;return!i&&fe(s,"iterate",a?ts:Mi),ce(Object.create(c),{next(){const{value:m,done:v}=c.next();return v?{value:m,done:v}:{value:r?[u(m[0]),u(m[1])]:u(m),done:v}}})}}function Un(t){return function(...i){return t==="delete"?!1:t==="clear"?void 0:this}}function Ac(t,i){const e={get(o){const s=this.__v_raw,l=Ot(s),r=Ot(o);t||(Ue(o,r)&&fe(l,"get",o),fe(l,"get",r));const{has:a}=jn(l),c=i?es:t?Yi:Re;if(a.call(l,o))return c(s.get(o));if(a.call(l,r))return c(s.get(r));s!==l&&s.get(o)},get size(){const o=this.__v_raw;return!t&&fe(Ot(o),"iterate",Mi),o.size},has(o){const s=this.__v_raw,l=Ot(s),r=Ot(o);return t||(Ue(o,r)&&fe(l,"has",o),fe(l,"has",r)),o===r?s.has(o):s.has(o)||s.has(r)},forEach(o,s){const l=this,r=l.__v_raw,a=Ot(r),c=i?es:t?Yi:Re;return!t&&fe(a,"iterate",Mi),r.forEach((u,m)=>o.call(s,c(u),c(m),l))}};return ce(e,t?{add:Un("add"),set:Un("set"),delete:Un("delete"),clear:Un("clear")}:{add(o){const s=Ot(this),l=jn(s),r=Ot(o),a=!i&&!Be(o)&&!si(o)?r:o;return l.has.call(s,a)||Ue(o,a)&&l.has.call(s,o)||Ue(r,a)&&l.has.call(s,r)||(s.add(a),Xe(s,"add",a,a)),this},set(o,s){!i&&!Be(s)&&!si(s)&&(s=Ot(s));const l=Ot(this),{has:r,get:a}=jn(l);let c=r.call(l,o);c||(o=Ot(o),c=r.call(l,o));const u=a.call(l,o);return l.set(o,s),c?Ue(s,u)&&Xe(l,"set",o,s):Xe(l,"add",o,s),this},delete(o){const s=Ot(this),{has:l,get:r}=jn(s);let a=l.call(s,o);a||(o=Ot(o),a=l.call(s,o)),r&&r.call(s,o);const c=s.delete(o);return a&&Xe(s,"delete",o,void 0),c},clear(){const o=Ot(this),s=o.size!==0,l=o.clear();return s&&Xe(o,"clear",void 0,void 0),l}}),["keys","values","entries",Symbol.iterator].forEach(o=>{e[o]=Ic(o,t,i)}),e}function xs(t,i){const e=Ac(t,i);return(n,o,s)=>o==="__v_isReactive"?!t:o==="__v_isReadonly"?t:o==="__v_raw"?n:Reflect.get(zt(e,o)&&o in n?e:n,o,s)}const Bc={get:xs(!1,!1)},Tc={get:xs(!1,!0)},Ec={get:xs(!0,!1)};const rl=new WeakMap,ll=new WeakMap,al=new WeakMap,Mc=new WeakMap;function Dc(t){switch(t){case"Object":case"Array":return 1;case"Map":case"Set":case"WeakMap":case"WeakSet":return 2;default:return 0}}function So(t){return si(t)?t:_s(t,!1,Sc,Bc,rl)}function Lc(t){return _s(t,!1,$c,Tc,ll)}function is(t){return _s(t,!0,Cc,Ec,al)}function _s(t,i,e,n,o){if(!Ht(t)||t.__v_raw&&!(i&&t.__v_isReactive)||t.__v_skip||!Object.isExtensible(t))return t;const s=o.get(t);if(s)return s;const l=Dc(sc(t));if(l===0)return t;const r=new Proxy(t,l===2?n:e);return o.set(t,r),r}function Di(t){return si(t)?Di(t.__v_raw):!!(t&&t.__v_isReactive)}function si(t){return!!(t&&t.__v_isReadonly)}function Be(t){return!!(t&&t.__v_isShallow)}function Ss(t){return t?!!t.__v_raw:!1}function Ot(t){const i=t&&t.__v_raw;return i?Ot(i):t}function Pc(t){return!zt(t,"__v_skip")&&Object.isExtensible(t)&&Vr(t,"__v_skip",!0),t}const Re=t=>Ht(t)?So(t):t,Yi=t=>Ht(t)?is(t):t;function Zt(t){return t?t.__v_isRef===!0:!1}function gt(t){return Rc(t,!1)}function Rc(t,i){return Zt(t)?t:new Oc(t,i)}class Oc{constructor(i,e){this.dep=new ws,this.__v_isRef=!0,this.__v_isShallow=!1,this._rawValue=e?i:Ot(i),this._value=e?i:Re(i),this.__v_isShallow=e}get value(){return this.dep.track(),this._value}set value(i){const e=this._rawValue,n=this.__v_isShallow||Be(i)||si(i);i=n?i:Ot(i),Ue(i,e)&&(this._rawValue=i,this._value=n?i:Re(i),this.dep.trigger())}}function vt(t){return Zt(t)?t.value:t}const zc={get:(t,i,e)=>i==="__v_raw"?t:vt(Reflect.get(t,i,e)),set:(t,i,e,n)=>{const o=t[i];return Zt(o)&&!Zt(e)?(o.value=e,!0):Reflect.set(t,i,e,n)}};function cl(t){return Di(t)?t:new Proxy(t,zc)}class Nc{constructor(i,e,n){this.fn=i,this.setter=e,this._value=void 0,this.dep=new ws(this),this.__v_isRef=!0,this.deps=void 0,this.depsTail=void 0,this.flags=16,this.globalVersion=Cn-1,this.next=void 0,this.effect=this,this.__v_isReadonly=!e,this.isSSR=n}notify(){if(this.flags|=16,!(this.flags&8)&&Wt!==this)return Jr(this,!0),!0}get value(){const i=this.dep.track();return tl(this),i&&(i.version=this.dep.version),this._value}set value(i){this.setter&&this.setter(i)}}function Fc(t,i,e=!1){let n,o;return At(t)?n=t:(n=t.get,o=t.set),new Nc(n,o,e)}const Wn={},ro=new WeakMap;let Ai;function Hc(t,i=!1,e=Ai){if(e){let n=ro.get(e);n||ro.set(e,n=[]),n.push(t)}}function jc(t,i,e=Ut){const{immediate:n,deep:o,once:s,scheduler:l,augmentJob:r,call:a}=e,c=A=>o?A:Be(A)||o===!1||o===0?Qe(A,1):Qe(A);let u,m,v,d,b=!1,f=!1;if(Zt(t)?(m=()=>t.value,b=Be(t)):Di(t)?(m=()=>c(t),b=!0):Ct(t)?(f=!0,b=t.some(A=>Di(A)||Be(A)),m=()=>t.map(A=>{if(Zt(A))return A.value;if(Di(A))return c(A);if(At(A))return a?a(A,2):A()})):At(t)?i?m=a?()=>a(t,2):t:m=()=>{if(v){ni();try{v()}finally{oi()}}const A=Ai;Ai=u;try{return a?a(t,3,[d]):t(d)}finally{Ai=A}}:m=qe,i&&o){const A=m,B=o===!0?1/0:o;m=()=>Qe(A(),B)}const y=gc(),k=()=>{u.stop(),y&&y.active&&ms(y.effects,u)};if(s&&i){const A=i;i=(...B)=>{const I=A(...B);return k(),I}}let x=f?new Array(t.length).fill(Wn):Wn;const C=A=>{if(!(!(u.flags&1)||!u.dirty&&!A))if(i){const B=u.run();if(A||o||b||(f?B.some((I,w)=>Ue(I,x[w])):Ue(B,x))){v&&v();const I=Ai;Ai=u;try{const w=[B,x===Wn?void 0:f&&x[0]===Wn?[]:x,d];x=B,a?a(i,3,w):i(...w)}finally{Ai=I}}}else u.run()};return r&&r(C),u=new Zr(m),u.scheduler=l?()=>l(C,!1):C,d=A=>Hc(A,!1,u),v=u.onStop=()=>{const A=ro.get(u);if(A){if(a)a(A,4);else for(const B of A)B();ro.delete(u)}},i?n?C(!0):x=u.run():l?l(C.bind(null,!0),!0):u.run(),k.pause=u.pause.bind(u),k.resume=u.resume.bind(u),k.stop=k,k}function Qe(t,i=1/0,e){if(i<=0||!Ht(t)||t.__v_skip||(e=e||new Map,(e.get(t)||0)>=i))return t;if(e.set(t,i),i--,Zt(t))Qe(t.value,i,e);else if(Ct(t))for(let n=0;n<t.length;n++)Qe(t[n],i,e);else if(tn(t)||qi(t))t.forEach(n=>{Qe(n,i,e)});else if(Wr(t)){for(const n in t)Qe(t[n],i,e);for(const n of Object.getOwnPropertySymbols(t))Object.prototype.propertyIsEnumerable.call(t,n)&&Qe(t[n],i,e)}return t}/**
* @vue/runtime-core v3.5.40
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/function Ln(t,i,e,n){try{return n?t(...n):t()}catch(o){Co(o,i,e)}}function Oe(t,i,e,n){if(At(t)){const o=Ln(t,i,e,n);return o&&jr(o)&&o.catch(s=>{Co(s,i,e)}),o}if(Ct(t)){const o=[];for(let s=0;s<t.length;s++)o.push(Oe(t[s],i,e,n));return o}}function Co(t,i,e,n=!0){const o=i?i.vnode:null,{errorHandler:s,throwUnhandledErrorInProduction:l}=i&&i.appContext.config||Ut;if(i){let r=i.parent;const a=i.proxy,c=`https://vuejs.org/error-reference/#runtime-${e}`;for(;r;){const u=r.ec;if(u){for(let m=0;m<u.length;m++)if(u[m](t,a,c)===!1)return}r=r.parent}if(s){ni(),Ln(s,null,10,[t,a,c]),oi();return}}Uc(t,e,o,n,l)}function Uc(t,i,e,n=!0,o=!1){if(o)throw t;console.error(t)}const ge=[];let Fe=-1;const Ki=[];let fi=null,Hi=0;const dl=Promise.resolve();let lo=null;function ul(t){const i=lo||dl;return t?i.then(this?t.bind(this):t):i}function Wc(t){let i=Fe+1,e=ge.length;for(;i<e;){const n=i+e>>>1,o=ge[n],s=In(o);s<t||s===t&&o.flags&2?i=n+1:e=n}return i}function Cs(t){if(!(t.flags&1)){const i=In(t),e=ge[ge.length-1];!e||!(t.flags&2)&&i>=In(e)?ge.push(t):ge.splice(Wc(i),0,t),t.flags|=1,fl()}}function fl(){lo||(lo=dl.then(hl))}function Vc(t){Ct(t)?Ki.push(...t):fi&&t.id===-1?fi.splice(Hi+1,0,t):t.flags&1||(Ki.push(t),t.flags|=1),fl()}function Ys(t,i,e=Fe+1){for(;e<ge.length;e++){const n=ge[e];if(n&&n.flags&2){if(t&&n.id!==t.uid)continue;ge.splice(e,1),e--,n.flags&4&&(n.flags&=-2),n(),n.flags&4||(n.flags&=-2)}}}function pl(t){if(Ki.length){const i=[...new Set(Ki)].sort((e,n)=>In(e)-In(n));if(Ki.length=0,fi){fi.push(...i);return}for(fi=i,Hi=0;Hi<fi.length;Hi++){const e=fi[Hi];e.flags&4&&(e.flags&=-2),e.flags&8||e(),e.flags&=-2}fi=null,Hi=0}}const In=t=>t.id==null?t.flags&2?-1:1/0:t.id;function hl(t){try{for(Fe=0;Fe<ge.length;Fe++){const i=ge[Fe];i&&!(i.flags&8)&&(i.flags&4&&(i.flags&=-2),Ln(i,i.i,i.i?15:14),i.flags&4||(i.flags&=-2))}}finally{for(;Fe<ge.length;Fe++){const i=ge[Fe];i&&(i.flags&=-2)}Fe=-1,ge.length=0,pl(),lo=null,(ge.length||Ki.length)&&hl()}}let ae=null,ml=null;function ao(t){const i=ae;return ae=t,ml=t&&t.type.__scopeId||null,i}function gl(t,i=ae,e){if(!i||t._n)return t;const n=(...o)=>{n._d&&ar(-1);const s=ao(i),l=ei.length;let r;try{r=t(...o)}finally{for(let a=ei.length;a>l;a--)Es();ao(s),n._d&&ar(1)}return r};return n._n=!0,n._c=!0,n._d=!0,n}function Te(t,i){if(ae===null)return t;const e=Bo(ae),n=t.dirs||(t.dirs=[]);for(let o=0;o<i.length;o++){let[s,l,r,a=Ut]=i[o];s&&(At(s)&&(s={mounted:s,updated:s}),s.deep&&Qe(l),n.push({dir:s,instance:e,value:l,oldValue:void 0,arg:r,modifiers:a}))}return t}function xi(t,i,e,n){const o=t.dirs,s=i&&i.dirs;for(let l=0;l<o.length;l++){const r=o[l];s&&(r.oldValue=s[l].value);let a=r.dir[n];a&&(ni(),Oe(a,e,8,[t.el,r,t,i]),oi())}}function qc(t,i){if(pe){let e=pe.provides;const n=pe.parent&&pe.parent.provides;n===e&&(e=pe.provides=Object.create(n)),e[t]=i}}function ti(t,i,e=!1){const n=Wd();if(n||Zi){let o=Zi?Zi._context.provides:n?n.parent==null||n.ce?n.vnode.appContext&&n.vnode.appContext.provides:n.parent.provides:void 0;if(o&&t in o)return o[t];if(arguments.length>1)return e&&At(i)?i.call(n&&n.proxy):i}}const Kc=Symbol.for("v-scx"),Gc=()=>ti(Kc);function Li(t,i,e){return vl(t,i,e)}function vl(t,i,e=Ut){const{immediate:n,deep:o,flush:s,once:l}=e,r=ce({},e),a=i&&n||!i&&s!=="post";let c;if(Bn){if(s==="sync"){const d=Gc();c=d.__watcherHandles||(d.__watcherHandles=[])}else if(!a){const d=()=>{};return d.stop=qe,d.resume=qe,d.pause=qe,d}}const u=pe;r.call=(d,b,f)=>Oe(d,u,b,f);let m=!1;s==="post"?r.scheduler=d=>{ke(d,u&&u.suspense)}:s!=="sync"&&(m=!0,r.scheduler=(d,b)=>{b?d():Cs(d)}),r.augmentJob=d=>{i&&(d.flags|=4),m&&(d.flags|=2,u&&(d.id=u.uid,d.i=u))};const v=jc(t,i,r);return Bn&&(c?c.push(v):a&&v()),v}function Zc(t,i,e){const n=this.proxy,o=Qt(t)?t.includes(".")?bl(n,t):()=>n[t]:t.bind(n,n);let s;At(i)?s=i:(s=i.handler,e=i);const l=Rn(this),r=vl(o,s.bind(n),e);return l(),r}function bl(t,i){const e=i.split(".");return()=>{let n=t;for(let o=0;o<e.length&&n;o++)n=n[e[o]];return n}}const Yc=Symbol("_vte"),Jc=t=>t.__isTeleport,No=Symbol("_leaveCb");function $s(t,i){t.shapeFlag&6&&t.component?(t.transition=i,$s(t.component.subTree,i)):t.shapeFlag&128?(t.ssContent.transition=i.clone(t.ssContent),t.ssFallback.transition=i.clone(t.ssFallback)):t.transition=i}function _e(t,i){return At(t)?ce({name:t.name},i,{setup:t}):t}function yl(t){t.ids=[t.ids[0]+t.ids[2]+++"-",0,0]}function Js(t,i){let e;return!!((e=Object.getOwnPropertyDescriptor(t,i))&&!e.configurable)}const co=new WeakMap;function mn(t,i,e,n,o=!1){if(Ct(t)){t.forEach((f,y)=>mn(f,i&&(Ct(i)?i[y]:i),e,n,o));return}if(Gi(n)&&!o){n.shapeFlag&512&&n.type.__asyncResolved&&n.component.subTree.component&&mn(t,i,e,n.component.subTree);return}const s=n.shapeFlag&4?Bo(n.component):n.el,l=o?null:s,{i:r,r:a}=t,c=i&&i.r,u=r.refs===Ut?r.refs={}:r.refs,m=r.setupState,v=Ot(m),d=m===Ut?Hr:f=>Js(u,f)?!1:zt(v,f),b=(f,y)=>!(y&&Js(u,y));if(c!=null&&c!==a){if(Xs(i),Qt(c))u[c]=null,d(c)&&(m[c]=null);else if(Zt(c)){const f=i;b(c,f.k)&&(c.value=null),f.k&&(u[f.k]=null)}}if(At(a))Ln(a,r,12,[l,u]);else{const f=Qt(a),y=Zt(a);if(f||y){const k=()=>{if(t.f){const x=f?d(a)?m[a]:u[a]:b()||!t.k?a.value:u[t.k];if(o)Ct(x)&&ms(x,s);else if(Ct(x))x.includes(s)||x.push(s);else if(f)u[a]=[s],d(a)&&(m[a]=u[a]);else{const C=[s];b(a,t.k)&&(a.value=C),t.k&&(u[t.k]=C)}}else f?(u[a]=l,d(a)&&(m[a]=l)):y&&(b(a,t.k)&&(a.value=l),t.k&&(u[t.k]=l))};if(l){const x=()=>{k(),co.delete(t)};x.id=-1,co.set(t,x),ke(x,e)}else Xs(t),k()}}}function Xs(t){const i=co.get(t);i&&(i.flags|=8,co.delete(t))}xo().requestIdleCallback;xo().cancelIdleCallback;const Gi=t=>!!t.type.__asyncLoader,kl=t=>t.type.__isKeepAlive;function Xc(t,i){wl(t,"a",i)}function Qc(t,i){wl(t,"da",i)}function wl(t,i,e=pe){const n=t.__wdc||(t.__wdc=()=>{let o=e;for(;o;){if(o.isDeactivated)return;o=o.parent}return t()});if($o(i,n,e),e){let o=e.parent;for(;o&&o.parent;)kl(o.parent.vnode)&&td(n,i,e,o),o=o.parent}}function td(t,i,e,n){const o=$o(i,t,n,!0);As(()=>{ms(n[i],o)},e)}function $o(t,i,e=pe,n=!1){if(e){const o=e[t]||(e[t]=[]),s=i.__weh||(i.__weh=(...l)=>{ni();const r=Rn(e),a=Oe(i,e,t,l);return r(),oi(),a});return n?o.unshift(s):o.push(s),s}}const ai=t=>(i,e=pe)=>{(!Bn||t==="sp")&&$o(t,(...n)=>i(...n),e)},ed=ai("bm"),Pn=ai("m"),id=ai("bu"),nd=ai("u"),Is=ai("bum"),As=ai("um"),od=ai("sp"),sd=ai("rtg"),rd=ai("rtc");function ld(t,i=pe){$o("ec",t,i)}const ad="components";function cd(t,i){return ud(ad,t,!0,i)||t}const dd=Symbol.for("v-ndc");function ud(t,i,e=!0,n=!1){const o=ae||pe;if(o){const s=o.type;{const r=Zd(s,!1);if(r&&(r===i||r===ve(i)||r===ko(ve(i))))return s}const l=Qs(o[t]||s[t],i)||Qs(o.appContext[t],i);return!l&&n?s:l}}function Qs(t,i){return t&&(t[i]||t[ve(i)]||t[ko(ve(i))])}function we(t,i,e,n){let o;const s=e,l=Ct(t);if(l||Qt(t)){const r=l&&Di(t);let a=!1,c=!1;r&&(a=!Be(t),c=si(t),t=_o(t)),o=new Array(t.length);for(let u=0,m=t.length;u<m;u++)o[u]=i(a?c?Yi(Re(t[u])):Re(t[u]):t[u],u,void 0,s)}else if(typeof t=="number"){o=new Array(t);for(let r=0;r<t;r++)o[r]=i(r+1,r,void 0,s)}else if(Ht(t))if(t[Symbol.iterator])o=Array.from(t,(r,a)=>i(r,a,void 0,s));else{const r=Object.keys(t);o=new Array(r.length);for(let a=0,c=r.length;a<c;a++){const u=r[a];o[a]=i(t[u],u,a,s)}}else o=[];return o}function Vn(t,i,e={},n,o,s){if(ae.ce||ae.parent&&Gi(ae.parent)&&ae.parent.ce){const c=e,u=Object.keys(c).length>0;return i!=="default"&&(c.name=i),et(),De(qt,null,[at("slot",c,n&&n())],u?-2:64)}let l=t[i];l&&l._c&&(l._d=!1);const r=ei.length;et();let a;try{const c=l&&xl(l(e)),u=e.key||s||c&&c.key;a=De(qt,{key:(u&&!Pe(u)?u:`_${i}`)+(!c&&n?"_fb":"")},c||(n?n():[]),c&&t._===1?64:-2)}catch(c){for(let u=ei.length;u>r;u--)Es();throw c}finally{l&&l._c&&(l._d=!0)}return a}function xl(t){return t.some(i=>Ms(i)?!(i.type===ri||i.type===qt&&!xl(i.children)):!0)?t:null}const ns=t=>t?jl(t)?Bo(t):ns(t.parent):null,gn=ce(Object.create(null),{$:t=>t,$el:t=>t.vnode.el,$data:t=>t.data,$props:t=>t.props,$attrs:t=>t.attrs,$slots:t=>t.slots,$refs:t=>t.refs,$parent:t=>ns(t.parent),$root:t=>ns(t.root),$host:t=>t.ce,$emit:t=>t.emit,$options:t=>Sl(t),$forceUpdate:t=>t.f||(t.f=()=>{Cs(t.update)}),$nextTick:t=>t.n||(t.n=ul.bind(t.proxy)),$watch:t=>Zc.bind(t)}),Fo=(t,i)=>t!==Ut&&!t.__isScriptSetup&&zt(t,i),fd={get({_:t},i){if(i==="__v_skip")return!0;const{ctx:e,setupState:n,data:o,props:s,accessCache:l,type:r,appContext:a}=t;if(i[0]!=="$"){const v=l[i];if(v!==void 0)switch(v){case 1:return n[i];case 2:return o[i];case 4:return e[i];case 3:return s[i]}else{if(Fo(n,i))return l[i]=1,n[i];if(o!==Ut&&zt(o,i))return l[i]=2,o[i];if(zt(s,i))return l[i]=3,s[i];if(e!==Ut&&zt(e,i))return l[i]=4,e[i];os&&(l[i]=0)}}const c=gn[i];let u,m;if(c)return i==="$attrs"&&fe(t.attrs,"get",""),c(t);if((u=r.__cssModules)&&(u=u[i]))return u;if(e!==Ut&&zt(e,i))return l[i]=4,e[i];if(m=a.config.globalProperties,zt(m,i))return m[i]},set({_:t},i,e){const{data:n,setupState:o,ctx:s}=t;return Fo(o,i)?(o[i]=e,!0):n!==Ut&&zt(n,i)?(n[i]=e,!0):zt(t.props,i)||i[0]==="$"&&i.slice(1)in t?!1:(s[i]=e,!0)},has({_:{data:t,setupState:i,accessCache:e,ctx:n,appContext:o,props:s,type:l}},r){let a;return!!(e[r]||t!==Ut&&r[0]!=="$"&&zt(t,r)||Fo(i,r)||zt(s,r)||zt(n,r)||zt(gn,r)||zt(o.config.globalProperties,r)||(a=l.__cssModules)&&a[r])},defineProperty(t,i,e){return e.get!=null?t._.accessCache[i]=0:zt(e,"value")&&this.set(t,i,e.value,null),Reflect.defineProperty(t,i,e)}};function tr(t){return Ct(t)?t.reduce((i,e)=>(i[e]=null,i),{}):t}let os=!0;function pd(t){const i=Sl(t),e=t.proxy,n=t.ctx;os=!1,i.beforeCreate&&er(i.beforeCreate,t,"bc");const{data:o,computed:s,methods:l,watch:r,provide:a,inject:c,created:u,beforeMount:m,mounted:v,beforeUpdate:d,updated:b,activated:f,deactivated:y,beforeDestroy:k,beforeUnmount:x,destroyed:C,unmounted:A,render:B,renderTracked:I,renderTriggered:w,errorCaptured:D,serverPrefetch:P,expose:R,inheritAttrs:J,components:S,directives:H,filters:g}=i;if(c&&hd(c,n,null),l)for(const U in l){const G=l[U];At(G)&&(n[U]=G.bind(e))}if(o){const U=o.call(e,e);Ht(U)&&(t.data=So(U))}if(os=!0,s)for(const U in s){const G=s[U],Z=At(G)?G.bind(e,e):At(G.get)?G.get.bind(e,e):qe,O=!At(G)&&At(G.set)?G.set.bind(e):qe,E=_t({get:Z,set:O});Object.defineProperty(n,U,{enumerable:!0,configurable:!0,get:()=>E.value,set:z=>E.value=z})}if(r)for(const U in r)_l(r[U],n,e,U);if(a){const U=At(a)?a.call(e):a;Reflect.ownKeys(U).forEach(G=>{qc(G,U[G])})}u&&er(u,t,"c");function q(U,G){Ct(G)?G.forEach(Z=>U(Z.bind(e))):G&&U(G.bind(e))}if(q(ed,m),q(Pn,v),q(id,d),q(nd,b),q(Xc,f),q(Qc,y),q(ld,D),q(rd,I),q(sd,w),q(Is,x),q(As,A),q(od,P),Ct(R))if(R.length){const U=t.exposed||(t.exposed={});R.forEach(G=>{Object.defineProperty(U,G,{get:()=>e[G],set:Z=>e[G]=Z,enumerable:!0})})}else t.exposed||(t.exposed={});B&&t.render===qe&&(t.render=B),J!=null&&(t.inheritAttrs=J),S&&(t.components=S),H&&(t.directives=H),P&&yl(t)}function hd(t,i,e=qe){Ct(t)&&(t=ss(t));for(const n in t){const o=t[n];let s;Ht(o)?"default"in o?s=ti(o.from||n,o.default,!0):s=ti(o.from||n):s=ti(o),Zt(s)?Object.defineProperty(i,n,{enumerable:!0,configurable:!0,get:()=>s.value,set:l=>s.value=l}):i[n]=s}}function er(t,i,e){Oe(Ct(t)?t.map(n=>n.bind(i.proxy)):t.bind(i.proxy),i,e)}function _l(t,i,e,n){let o=n.includes(".")?bl(e,n):()=>e[n];if(Qt(t)){const s=i[t];At(s)&&Li(o,s)}else if(At(t))Li(o,t.bind(e));else if(Ht(t))if(Ct(t))t.forEach(s=>_l(s,i,e,n));else{const s=At(t.handler)?t.handler.bind(e):i[t.handler];At(s)&&Li(o,s,t)}}function Sl(t){const i=t.type,{mixins:e,extends:n}=i,{mixins:o,optionsCache:s,config:{optionMergeStrategies:l}}=t.appContext,r=s.get(i);let a;return r?a=r:!o.length&&!e&&!n?a=i:(a={},o.length&&o.forEach(c=>uo(a,c,l,!0)),uo(a,i,l)),Ht(i)&&s.set(i,a),a}function uo(t,i,e,n=!1){const{mixins:o,extends:s}=i;s&&uo(t,s,e,!0),o&&o.forEach(l=>uo(t,l,e,!0));for(const l in i)if(!(n&&l==="expose")){const r=md[l]||e&&e[l];t[l]=r?r(t[l],i[l]):i[l]}return t}const md={data:ir,props:nr,emits:nr,methods:cn,computed:cn,beforeCreate:me,created:me,beforeMount:me,mounted:me,beforeUpdate:me,updated:me,beforeDestroy:me,beforeUnmount:me,destroyed:me,unmounted:me,activated:me,deactivated:me,errorCaptured:me,serverPrefetch:me,components:cn,directives:cn,watch:vd,provide:ir,inject:gd};function ir(t,i){return i?t?function(){return ce(At(t)?t.call(this,this):t,At(i)?i.call(this,this):i)}:i:t}function gd(t,i){return cn(ss(t),ss(i))}function ss(t){if(Ct(t)){const i={};for(let e=0;e<t.length;e++)i[t[e]]=t[e];return i}return t}function me(t,i){return t?[...new Set([].concat(t,i))]:i}function cn(t,i){return t?ce(Object.create(null),t,i):i}function nr(t,i){return t?Ct(t)&&Ct(i)?[...new Set([...t,...i])]:ce(Object.create(null),tr(t),tr(i??{})):i}function vd(t,i){if(!t)return i;if(!i)return t;const e=ce(Object.create(null),t);for(const n in i)e[n]=me(t[n],i[n]);return e}function Cl(){return{app:null,config:{isNativeTag:Hr,performance:!1,globalProperties:{},optionMergeStrategies:{},errorHandler:void 0,warnHandler:void 0,compilerOptions:{}},mixins:[],components:{},directives:{},provides:Object.create(null),optionsCache:new WeakMap,propsCache:new WeakMap,emitsCache:new WeakMap}}let bd=0;function yd(t,i){return function(n,o=null){At(n)||(n=ce({},n)),o!=null&&!Ht(o)&&(o=null);const s=Cl(),l=new WeakSet,r=[];let a=!1;const c=s.app={_uid:bd++,_component:n,_props:o,_container:null,_context:s,_instance:null,version:Jd,get config(){return s.config},set config(u){},use(u,...m){return l.has(u)||(u&&At(u.install)?(l.add(u),u.install(c,...m)):At(u)&&(l.add(u),u(c,...m))),c},mixin(u){return s.mixins.includes(u)||s.mixins.push(u),c},component(u,m){return m?(s.components[u]=m,c):s.components[u]},directive(u,m){return m?(s.directives[u]=m,c):s.directives[u]},mount(u,m,v){if(!a){const d=c._ceVNode||at(n,o);return d.appContext=s,v===!0?v="svg":v===!1&&(v=void 0),t(d,u,v),a=!0,c._container=u,u.__vue_app__=c,Bo(d.component)}},onUnmount(u){r.push(u)},unmount(){a&&(Oe(r,c._instance,16),t(null,c._container),delete c._container.__vue_app__)},provide(u,m){return s.provides[u]=m,c},runWithContext(u){const m=Zi;Zi=c;try{return u()}finally{Zi=m}}};return c}}let Zi=null;const kd=(t,i)=>i==="modelValue"||i==="model-value"?t.modelModifiers:t[`${i}Modifiers`]||t[`${ve(i)}Modifiers`]||t[`${bi(i)}Modifiers`];function wd(t,i,...e){if(t.isUnmounted)return;const n=t.vnode.props||Ut;let o=e;const s=i.startsWith("update:"),l=s&&kd(n,i.slice(7));l&&(l.trim&&(o=e.map(u=>Qt(u)?u.trim():u)),l.number&&(o=e.map(wo)));let r,a=n[r=Lo(i)]||n[r=Lo(ve(i))];!a&&s&&(a=n[r=Lo(bi(i))]),a&&Oe(a,t,6,o);const c=n[r+"Once"];if(c){if(!t.emitted)t.emitted={};else if(t.emitted[r])return;t.emitted[r]=!0,Oe(c,t,6,o)}}const xd=new WeakMap;function $l(t,i,e=!1){const n=e?xd:i.emitsCache,o=n.get(t);if(o!==void 0)return o;const s=t.emits;let l={},r=!1;if(!At(t)){const a=c=>{const u=$l(c,i,!0);u&&(r=!0,ce(l,u))};!e&&i.mixins.length&&i.mixins.forEach(a),t.extends&&a(t.extends),t.mixins&&t.mixins.forEach(a)}return!s&&!r?(Ht(t)&&n.set(t,null),null):(Ct(s)?s.forEach(a=>l[a]=null):ce(l,s),Ht(t)&&n.set(t,l),l)}function Io(t,i){return!t||!vo(i)?!1:(i=i.slice(2),i=i==="Once"?i:i.replace(/Once$/,""),zt(t,i[0].toLowerCase()+i.slice(1))||zt(t,bi(i))||zt(t,i))}function or(t){const{type:i,vnode:e,proxy:n,withProxy:o,propsOptions:[s],slots:l,attrs:r,emit:a,render:c,renderCache:u,props:m,data:v,setupState:d,ctx:b,inheritAttrs:f}=t,y=ao(t);let k,x;try{if(e.shapeFlag&4){const A=o||n,B=A;k=je(c.call(B,A,u,m,d,v,b)),x=r}else{const A=i;k=je(A.length>1?A(m,{attrs:r,slots:l,emit:a}):A(m,null)),x=i.props?r:_d(r)}}catch(A){ei.length=0,Co(A,t,1),k=at(ri)}let C=k;if(x&&f!==!1){const A=Object.keys(x),{shapeFlag:B}=C;A.length&&B&7&&(s&&A.some(bo)&&(x=Sd(x,s)),C=Ji(C,x,!1,!0))}return e.dirs&&(C=Ji(C,null,!1,!0),C.dirs=C.dirs?C.dirs.concat(e.dirs):e.dirs),e.transition&&$s(C,e.transition),k=C,ao(y),k}const _d=t=>{let i;for(const e in t)(e==="class"||e==="style"||vo(e))&&((i||(i={}))[e]=t[e]);return i},Sd=(t,i)=>{const e={};for(const n in t)(!bo(n)||!(n.slice(9)in i))&&(e[n]=t[n]);return e};function Cd(t,i,e){const{props:n,children:o,component:s}=t,{props:l,children:r,patchFlag:a}=i,c=s.emitsOptions;if(i.dirs||i.transition)return!0;if(e&&a>=0){if(a&1024)return!0;if(a&16)return n?sr(n,l,c):!!l;if(a&8){const u=i.dynamicProps;for(let m=0;m<u.length;m++){const v=u[m];if(Il(l,n,v)&&!Io(c,v))return!0}}}else return(o||r)&&(!r||!r.$stable)?!0:n===l?!1:n?l?sr(n,l,c):!0:!!l;return!1}function sr(t,i,e){const n=Object.keys(i);if(n.length!==Object.keys(t).length)return!0;for(let o=0;o<n.length;o++){const s=n[o];if(Il(i,t,s)&&!Io(e,s))return!0}return!1}function Il(t,i,e){const n=t[e],o=i[e];return e==="style"&&Ht(n)&&Ht(o)?!en(n,o):n!==o}function $d({vnode:t,parent:i,suspense:e},n){for(;i;){const o=i.subTree;if(o.suspense&&o.suspense.activeBranch===t&&(o.suspense.vnode.el=o.el=n,t=o),o===t)(t=i.vnode).el=n,i=i.parent;else break}e&&e.activeBranch===t&&(e.vnode.el=n)}const Al={},Bl=()=>Object.create(Al),Tl=t=>Object.getPrototypeOf(t)===Al;function Id(t,i,e,n=!1){const o={},s=Bl();t.propsDefaults=Object.create(null),El(t,i,o,s);for(const l in t.propsOptions[0])l in o||(o[l]=void 0);e?t.props=n?o:Lc(o):t.type.props?t.props=o:t.props=s,t.attrs=s}function Ad(t,i,e,n){const{props:o,attrs:s,vnode:{patchFlag:l}}=t,r=Ot(o),[a]=t.propsOptions;let c=!1;if((n||l>0)&&!(l&16)){if(l&8){const u=t.vnode.dynamicProps;for(let m=0;m<u.length;m++){let v=u[m];if(Io(t.emitsOptions,v))continue;const d=i[v];if(a)if(zt(s,v))d!==s[v]&&(s[v]=d,c=!0);else{const b=ve(v);o[b]=rs(a,r,b,d,t,!1)}else d!==s[v]&&(s[v]=d,c=!0)}}}else{El(t,i,o,s)&&(c=!0);let u;for(const m in r)(!i||!zt(i,m)&&((u=bi(m))===m||!zt(i,u)))&&(a?e&&(e[m]!==void 0||e[u]!==void 0)&&(o[m]=rs(a,r,m,void 0,t,!0)):delete o[m]);if(s!==r)for(const m in s)(!i||!zt(i,m))&&(delete s[m],c=!0)}c&&Xe(t.attrs,"set","")}function El(t,i,e,n){const[o,s]=t.propsOptions;let l=!1,r;if(i)for(let a in i){if(fn(a))continue;const c=i[a];let u;o&&zt(o,u=ve(a))?!s||!s.includes(u)?e[u]=c:(r||(r={}))[u]=c:Io(t.emitsOptions,a)||(!(a in n)||c!==n[a])&&(n[a]=c,l=!0)}if(s){const a=Ot(e),c=r||Ut;for(let u=0;u<s.length;u++){const m=s[u];e[m]=rs(o,a,m,c[m],t,!zt(c,m))}}return l}function rs(t,i,e,n,o,s){const l=t[e];if(l!=null){const r=zt(l,"default");if(r&&n===void 0){const a=l.default;if(l.type!==Function&&!l.skipFactory&&At(a)){const{propsDefaults:c}=o;if(e in c)n=c[e];else{const u=Rn(o);n=c[e]=a.call(null,i),u()}}else n=a;o.ce&&o.ce._setProp(e,n)}l[0]&&(s&&!r?n=!1:l[1]&&(n===""||n===bi(e))&&(n=!0))}return n}const Bd=new WeakMap;function Ml(t,i,e=!1){const n=e?Bd:i.propsCache,o=n.get(t);if(o)return o;const s=t.props,l={},r=[];let a=!1;if(!At(t)){const u=m=>{a=!0;const[v,d]=Ml(m,i,!0);ce(l,v),d&&r.push(...d)};!e&&i.mixins.length&&i.mixins.forEach(u),t.extends&&u(t.extends),t.mixins&&t.mixins.forEach(u)}if(!s&&!a)return Ht(t)&&n.set(t,Vi),Vi;if(Ct(s))for(let u=0;u<s.length;u++){const m=ve(s[u]);rr(m)&&(l[m]=Ut)}else if(s)for(const u in s){const m=ve(u);if(rr(m)){const v=s[u],d=l[m]=Ct(v)||At(v)?{type:v}:ce({},v),b=d.type;let f=!1,y=!0;if(Ct(b))for(let k=0;k<b.length;++k){const x=b[k],C=At(x)&&x.name;if(C==="Boolean"){f=!0;break}else C==="String"&&(y=!1)}else f=At(b)&&b.name==="Boolean";d[0]=f,d[1]=y,(f||zt(d,"default"))&&r.push(m)}}const c=[l,r];return Ht(t)&&n.set(t,c),c}function rr(t){return t[0]!=="$"&&!fn(t)}const Bs=t=>t==="_"||t==="_ctx"||t==="$stable",Ts=t=>Ct(t)?t.map(je):[je(t)],Td=(t,i,e)=>{if(i._n)return i;const n=gl((...o)=>Ts(i(...o)),e);return n._c=!1,n},Dl=(t,i,e)=>{const n=t._ctx;for(const o in t){if(Bs(o))continue;const s=t[o];if(At(s))i[o]=Td(o,s,n);else if(s!=null){const l=Ts(s);i[o]=()=>l}}},Ll=(t,i)=>{const e=Ts(i);t.slots.default=()=>e},Pl=(t,i,e)=>{for(const n in i)(e||!Bs(n))&&(t[n]=i[n])},Ed=(t,i,e)=>{const n=t.slots=Bl();if(t.vnode.shapeFlag&32){const o=i._;o?(Pl(n,i,e),e&&Vr(n,"_",o,!0)):Dl(i,n)}else i&&Ll(t,i)},Md=(t,i,e)=>{const{vnode:n,slots:o}=t;let s=!0,l=Ut;if(n.shapeFlag&32){const r=i._;r?e&&r===1?s=!1:Pl(o,i,e):(s=!i.$stable,Dl(i,o)),l=i}else i&&(Ll(t,i),l={default:1});if(s)for(const r in o)!Bs(r)&&l[r]==null&&delete o[r]},ke=Od;function Dd(t){return Ld(t)}function Ld(t,i){const e=xo();e.__VUE__=!0;const{insert:n,remove:o,patchProp:s,createElement:l,createText:r,createComment:a,setText:c,setElementText:u,parentNode:m,nextSibling:v,setScopeId:d=qe,insertStaticContent:b}=t,f=(T,F,p,j=null,L=null,_=null,$=void 0,M=null,K=!!F.dynamicChildren)=>{if(T===F)return;T&&!rn(T,F)&&(j=ct(T),z(T,L,_,!0),T=null),F.patchFlag===-2&&(K=!1,F.dynamicChildren=null);const{type:W,ref:V,shapeFlag:Q}=F;switch(W){case Ao:y(T,F,p,j);break;case ri:k(T,F,p,j);break;case Yn:T==null&&x(F,p,j,$);break;case qt:S(T,F,p,j,L,_,$,M,K);break;default:Q&1?B(T,F,p,j,L,_,$,M,K):Q&6?H(T,F,p,j,L,_,$,M,K):(Q&64||Q&128)&&W.process(T,F,p,j,L,_,$,M,K,dt)}V!=null&&L?mn(V,T&&T.ref,_,F||T,!F):V==null&&T&&T.ref!=null&&mn(T.ref,null,_,T,!0)},y=(T,F,p,j)=>{if(T==null)n(F.el=r(F.children),p,j);else{const L=F.el=T.el;F.children!==T.children&&c(L,F.children)}},k=(T,F,p,j)=>{T==null?n(F.el=a(F.children||""),p,j):F.el=T.el},x=(T,F,p,j)=>{[T.el,T.anchor]=b(T.children,F,p,j,T.el,T.anchor)},C=({el:T,anchor:F},p,j)=>{let L;for(;T&&T!==F;)L=v(T),n(T,p,j),T=L;n(F,p,j)},A=({el:T,anchor:F})=>{let p;for(;T&&T!==F;)p=v(T),o(T),T=p;o(F)},B=(T,F,p,j,L,_,$,M,K)=>{if(F.type==="svg"?$="svg":F.type==="math"&&($="mathml"),T==null)I(F,p,j,L,_,$,M,K);else{const W=T.el&&T.el._isVueCE?T.el:null;try{W&&W._beginPatch(),P(T,F,L,_,$,M,K)}finally{W&&W._endPatch()}}},I=(T,F,p,j,L,_,$,M)=>{let K,W;const{props:V,shapeFlag:Q,transition:lt,dirs:st}=T;if(K=T.el=l(T.type,_,V&&V.is,V),Q&8?u(K,T.children):Q&16&&D(T.children,K,null,j,L,Ho(T,_),$,M),st&&xi(T,null,j,"created"),w(K,T,T.scopeId,$,j),V){for(const xt in V)xt!=="value"&&!fn(xt)&&s(K,xt,null,V[xt],_,j);"value"in V&&s(K,"value",null,V.value,_),(W=V.onVnodeBeforeMount)&&Ne(W,j,T)}st&&xi(T,null,j,"beforeMount");const ft=Pd(L,lt);ft&&lt.beforeEnter(K),n(K,F,p),((W=V&&V.onVnodeMounted)||ft||st)&&ke(()=>{try{W&&Ne(W,j,T),ft&&lt.enter(K),st&&xi(T,null,j,"mounted")}finally{}},L)},w=(T,F,p,j,L)=>{if(p&&d(T,p),j)for(let _=0;_<j.length;_++)d(T,j[_]);if(L){let _=L.subTree;if(F===_||Nl(_.type)&&(_.ssContent===F||_.ssFallback===F)){const $=L.vnode;w(T,$,$.scopeId,$.slotScopeIds,L.parent)}}},D=(T,F,p,j,L,_,$,M,K=0)=>{for(let W=K;W<T.length;W++){const V=T[W]=M?Je(T[W]):je(T[W]);f(null,V,F,p,j,L,_,$,M)}},P=(T,F,p,j,L,_,$)=>{const M=F.el=T.el;let{patchFlag:K,dynamicChildren:W,dirs:V}=F;K|=T.patchFlag&16;const Q=T.props||Ut,lt=F.props||Ut;let st;if(p&&_i(p,!1),(st=lt.onVnodeBeforeUpdate)&&Ne(st,p,F,T),V&&xi(F,T,p,"beforeUpdate"),p&&_i(p,!0),W&&(!T.dynamicChildren||T.dynamicChildren.length!==W.length)&&(K=0,$=!1,W=null),(Q.innerHTML&&lt.innerHTML==null||Q.textContent&&lt.textContent==null)&&u(M,""),W?R(T.dynamicChildren,W,M,p,j,Ho(F,L),_):$||G(T,F,M,null,p,j,Ho(F,L),_,!1),K>0){if(K&16)J(M,Q,lt,p,L);else if(K&2&&Q.class!==lt.class&&s(M,"class",null,lt.class,L),K&4&&s(M,"style",Q.style,lt.style,L),K&8){const ft=F.dynamicProps;for(let xt=0;xt<ft.length;xt++){const kt=ft[xt],Mt=Q[kt],Kt=lt[kt];(Kt!==Mt||kt==="value")&&s(M,kt,Mt,Kt,L,p)}}K&1&&T.children!==F.children&&u(M,F.children)}else!$&&W==null&&J(M,Q,lt,p,L);((st=lt.onVnodeUpdated)||V)&&ke(()=>{st&&Ne(st,p,F,T),V&&xi(F,T,p,"updated")},j)},R=(T,F,p,j,L,_,$)=>{for(let M=0;M<F.length;M++){const K=T[M],W=F[M],V=K.el&&(K.type===qt||!rn(K,W)||K.shapeFlag&198)?m(K.el):p;f(K,W,V,null,j,L,_,$,!0)}},J=(T,F,p,j,L)=>{if(F!==p){if(F!==Ut)for(const _ in F)!fn(_)&&!(_ in p)&&s(T,_,F[_],null,L,j);for(const _ in p){if(fn(_))continue;const $=p[_],M=F[_];$!==M&&_!=="value"&&s(T,_,M,$,L,j)}"value"in p&&s(T,"value",F.value,p.value,L)}},S=(T,F,p,j,L,_,$,M,K)=>{const W=F.el=T?T.el:r(""),V=F.anchor=T?T.anchor:r("");let{patchFlag:Q,dynamicChildren:lt,slotScopeIds:st}=F;st&&(M=M?M.concat(st):st),T==null?(n(W,p,j),n(V,p,j),D(F.children||[],p,V,L,_,$,M,K)):Q>0&&Q&64&&lt&&T.dynamicChildren&&T.dynamicChildren.length===lt.length?(R(T.dynamicChildren,lt,p,L,_,$,M),(F.key!=null||L&&F===L.subTree)&&Rl(T,F,!0)):G(T,F,p,V,L,_,$,M,K)},H=(T,F,p,j,L,_,$,M,K)=>{F.slotScopeIds=M,T==null?F.shapeFlag&512?L.ctx.activate(F,p,j,$,K):g(F,p,j,L,_,$,K):N(T,F,K)},g=(T,F,p,j,L,_,$)=>{const M=T.component=Ud(T,j,L);if(kl(T)&&(M.ctx.renderer=dt),Vd(M,!1,$),M.asyncDep){if(L&&L.registerDep(M,q,$),!T.el){const K=M.subTree=at(ri);k(null,K,F,p),T.placeholder=K.el}}else q(M,T,F,p,L,_,$)},N=(T,F,p)=>{const j=F.component=T.component;if(Cd(T,F,p))if(j.asyncDep&&!j.asyncResolved){U(j,F,p);return}else j.next=F,j.update();else F.el=T.el,j.vnode=F},q=(T,F,p,j,L,_,$)=>{const M=()=>{if(T.isMounted){let{next:Q,bu:lt,u:st,parent:ft,vnode:xt}=T;{const ne=Ol(T);if(ne){Q&&(Q.el=xt.el,U(T,Q,$)),ne.asyncDep.then(()=>{ke(()=>{T.isUnmounted||W()},L)});return}}let kt=Q,Mt;_i(T,!1),Q?(Q.el=xt.el,U(T,Q,$)):Q=xt,lt&&Zn(lt),(Mt=Q.props&&Q.props.onVnodeBeforeUpdate)&&Ne(Mt,ft,Q,xt),_i(T,!0);const Kt=or(T),Gt=T.subTree;T.subTree=Kt,f(Gt,Kt,m(Gt.el),ct(Gt),T,L,_),Q.el=Kt.el,kt===null&&$d(T,Kt.el),st&&ke(st,L),(Mt=Q.props&&Q.props.onVnodeUpdated)&&ke(()=>Ne(Mt,ft,Q,xt),L)}else{let Q;const{el:lt,props:st}=F,{bm:ft,m:xt,parent:kt,root:Mt,type:Kt}=T,Gt=Gi(F);_i(T,!1),ft&&Zn(ft),!Gt&&(Q=st&&st.onVnodeBeforeMount)&&Ne(Q,kt,F),_i(T,!0);{Mt.ce&&Mt.ce._hasShadowRoot()&&Mt.ce._injectChildStyle(Kt,T.parent?T.parent.type:void 0);const ne=T.subTree=or(T);f(null,ne,p,j,T,L,_),F.el=ne.el}if(xt&&ke(xt,L),!Gt&&(Q=st&&st.onVnodeMounted)){const ne=F;ke(()=>Ne(Q,kt,ne),L)}(F.shapeFlag&256||kt&&Gi(kt.vnode)&&kt.vnode.shapeFlag&256)&&T.a&&ke(T.a,L),T.isMounted=!0,F=p=j=null}};T.scope.on();const K=T.effect=new Zr(M);T.scope.off();const W=T.update=K.run.bind(K),V=T.job=K.runIfDirty.bind(K);V.i=T,V.id=T.uid,K.scheduler=()=>Cs(V),_i(T,!0),W()},U=(T,F,p)=>{F.component=T;const j=T.vnode.props;T.vnode=F,T.next=null,Ad(T,F.props,j,p),Md(T,F.children,p),ni(),Ys(T),oi()},G=(T,F,p,j,L,_,$,M,K=!1)=>{const W=T&&T.children,V=T?T.shapeFlag:0,Q=F.children,{patchFlag:lt,shapeFlag:st}=F;if(lt>0){if(lt&128){O(W,Q,p,j,L,_,$,M,K);return}else if(lt&256){Z(W,Q,p,j,L,_,$,M,K);return}}st&8?(V&16&&Y(W,L,_),Q!==W&&u(p,Q)):V&16?st&16?O(W,Q,p,j,L,_,$,M,K):Y(W,L,_,!0):(V&8&&u(p,""),st&16&&D(Q,p,j,L,_,$,M,K))},Z=(T,F,p,j,L,_,$,M,K)=>{T=T||Vi,F=F||Vi;const W=T.length,V=F.length,Q=Math.min(W,V);let lt;for(lt=0;lt<Q;lt++){const st=F[lt]=K?Je(F[lt]):je(F[lt]);f(T[lt],st,p,null,L,_,$,M,K)}W>V?Y(T,L,_,!0,!1,Q):D(F,p,j,L,_,$,M,K,Q)},O=(T,F,p,j,L,_,$,M,K)=>{let W=0;const V=F.length;let Q=T.length-1,lt=V-1;for(;W<=Q&&W<=lt;){const st=T[W],ft=F[W]=K?Je(F[W]):je(F[W]);if(rn(st,ft))f(st,ft,p,null,L,_,$,M,K);else break;W++}for(;W<=Q&&W<=lt;){const st=T[Q],ft=F[lt]=K?Je(F[lt]):je(F[lt]);if(rn(st,ft))f(st,ft,p,null,L,_,$,M,K);else break;Q--,lt--}if(W>Q){if(W<=lt){const st=lt+1,ft=st<V?F[st].el:j;for(;W<=lt;)f(null,F[W]=K?Je(F[W]):je(F[W]),p,ft,L,_,$,M,K),W++}}else if(W>lt)for(;W<=Q;)z(T[W],L,_,!0),W++;else{const st=W,ft=W,xt=new Map;for(W=ft;W<=lt;W++){const ee=F[W]=K?Je(F[W]):je(F[W]);ee.key!=null&&xt.set(ee.key,W)}let kt,Mt=0;const Kt=lt-ft+1;let Gt=!1,ne=0;const Nt=new Array(Kt);for(W=0;W<Kt;W++)Nt[W]=0;for(W=st;W<=Q;W++){const ee=T[W];if(Mt>=Kt){z(ee,L,_,!0);continue}let Yt;if(ee.key!=null)Yt=xt.get(ee.key);else for(kt=ft;kt<=lt;kt++)if(Nt[kt-ft]===0&&rn(ee,F[kt])){Yt=kt;break}Yt===void 0?z(ee,L,_,!0):(Nt[Yt-ft]=W+1,Yt>=ne?ne=Yt:Gt=!0,f(ee,F[Yt],p,null,L,_,$,M,K),Mt++)}const Ke=Gt?Rd(Nt):Vi;for(kt=Ke.length-1,W=Kt-1;W>=0;W--){const ee=ft+W,Yt=F[ee],ki=F[ee+1],Oi=ee+1<V?ki.el||zl(ki):j;Nt[W]===0?f(null,Yt,p,Oi,L,_,$,M,K):Gt&&(kt<0||W!==Ke[kt]?E(Yt,p,Oi,2):kt--)}}},E=(T,F,p,j,L=null)=>{const{el:_,type:$,transition:M,children:K,shapeFlag:W}=T;if(W&6){E(T.component.subTree,F,p,j);return}if(W&128){T.suspense.move(F,p,j);return}if(W&64){$.move(T,F,p,dt);return}if($===qt){n(_,F,p);for(let Q=0;Q<K.length;Q++)E(K[Q],F,p,j);n(T.anchor,F,p);return}if($===Yn){C(T,F,p);return}if(j!==2&&W&1&&M)if(j===0)M.persisted&&!_[No]?n(_,F,p):(M.beforeEnter(_),n(_,F,p),ke(()=>M.enter(_),L));else{const{leave:Q,delayLeave:lt,afterLeave:st}=M,ft=()=>{T.ctx.isUnmounted?o(_):n(_,F,p)},xt=()=>{const kt=_._isLeaving||!!_[No];_._isLeaving&&_[No](!0),M.persisted&&!kt?ft():Q(_,()=>{ft(),st&&st()})};lt?lt(_,ft,xt):xt()}else n(_,F,p)},z=(T,F,p,j=!1,L=!1)=>{const{type:_,props:$,ref:M,children:K,dynamicChildren:W,shapeFlag:V,patchFlag:Q,dirs:lt,cacheIndex:st,memo:ft}=T;if(Q===-2&&(L=!1),M!=null&&(ni(),mn(M,null,p,T,!0),oi()),st!=null&&(F.renderCache[st]=void 0),V&256){F.ctx.deactivate(T);return}const xt=V&1&&lt,kt=!Gi(T);let Mt;if(kt&&(Mt=$&&$.onVnodeBeforeUnmount)&&Ne(Mt,F,T),V&6)tt(T.component,p,j);else{if(V&128){T.suspense.unmount(p,j);return}xt&&xi(T,null,F,"beforeUnmount"),V&64?T.type.remove(T,F,p,dt,j):W&&!W.hasOnce&&(_!==qt||Q>0&&Q&64)?Y(W,F,p,!1,!0):(_===qt&&Q&384||!L&&V&16)&&Y(K,F,p),j&&rt(T)}const Kt=ft!=null&&st==null;(kt&&(Mt=$&&$.onVnodeUnmounted)||xt||Kt)&&ke(()=>{Mt&&Ne(Mt,F,T),xt&&xi(T,null,F,"unmounted"),Kt&&(T.el=null)},p)},rt=T=>{const{type:F,el:p,anchor:j,transition:L}=T;if(F===qt){nt(p,j);return}if(F===Yn){A(T);return}const _=()=>{o(p),L&&!L.persisted&&L.afterLeave&&L.afterLeave()};if(T.shapeFlag&1&&L&&!L.persisted){const{leave:$,delayLeave:M}=L,K=()=>$(p,_);M?M(T.el,_,K):K()}else _()},nt=(T,F)=>{let p;for(;T!==F;)p=v(T),o(T),T=p;o(F)},tt=(T,F,p)=>{const{bum:j,scope:L,job:_,subTree:$,um:M,m:K,a:W}=T;lr(K),lr(W),j&&Zn(j),L.stop(),_&&(_.flags|=8,z($,T,F,p)),M&&ke(M,F),ke(()=>{T.isUnmounted=!0},F)},Y=(T,F,p,j=!1,L=!1,_=0)=>{for(let $=_;$<T.length;$++)z(T[$],F,p,j,L)},ct=T=>{if(T.shapeFlag&6)return ct(T.component.subTree);if(T.shapeFlag&128)return T.suspense.next();const F=v(T.anchor||T.el),p=F&&F[Yc];return p?v(p):F};let pt=!1;const X=(T,F,p)=>{let j;T==null?F._vnode&&(z(F._vnode,null,null,!0),j=F._vnode.component):f(F._vnode||null,T,F,null,null,null,p),F._vnode=T,pt||(pt=!0,Ys(j),pl(),pt=!1)},dt={p:f,um:z,m:E,r:rt,mt:g,mc:D,pc:G,pbc:R,n:ct,o:t};return{render:X,hydrate:void 0,createApp:yd(X)}}function Ho({type:t,props:i},e){return e==="svg"&&t==="foreignObject"||e==="mathml"&&t==="annotation-xml"&&i&&i.encoding&&i.encoding.includes("html")?void 0:e}function _i({effect:t,job:i},e){e?(t.flags|=32,i.flags|=4):(t.flags&=-33,i.flags&=-5)}function Pd(t,i){return(!t||t&&!t.pendingBranch)&&i&&!i.persisted}function Rl(t,i,e=!1){const n=t.children,o=i.children;if(Ct(n)&&Ct(o))for(let s=0;s<n.length;s++){const l=n[s];let r=o[s];r.shapeFlag&1&&!r.dynamicChildren&&((r.patchFlag<=0||r.patchFlag===32)&&(r=o[s]=Je(o[s]),r.el=l.el),!e&&r.patchFlag!==-2&&Rl(l,r)),r.type===Ao&&(r.patchFlag===-1&&(r=o[s]=Je(r)),r.el=l.el),r.type===ri&&!r.el&&(r.el=l.el)}}function Rd(t){const i=t.slice(),e=[0];let n,o,s,l,r;const a=t.length;for(n=0;n<a;n++){const c=t[n];if(c!==0){if(o=e[e.length-1],t[o]<c){i[n]=o,e.push(n);continue}for(s=0,l=e.length-1;s<l;)r=s+l>>1,t[e[r]]<c?s=r+1:l=r;c<t[e[s]]&&(s>0&&(i[n]=e[s-1]),e[s]=n)}}for(s=e.length,l=e[s-1];s-- >0;)e[s]=l,l=i[l];return e}function Ol(t){const i=t.subTree.component;if(i)return i.asyncDep&&!i.asyncResolved?i:Ol(i)}function lr(t){if(t)for(let i=0;i<t.length;i++)t[i].flags|=8}function zl(t){if(t.placeholder)return t.placeholder;const i=t.component;return i?zl(i.subTree):null}const Nl=t=>t.__isSuspense;function Od(t,i){i&&i.pendingBranch?Ct(t)?i.effects.push(...t):i.effects.push(t):Vc(t)}const qt=Symbol.for("v-fgt"),Ao=Symbol.for("v-txt"),ri=Symbol.for("v-cmt"),Yn=Symbol.for("v-stc"),ei=[];let Se=null;function et(t=!1){ei.push(Se=t?null:[])}function Es(){ei.pop(),Se=ei[ei.length-1]||null}let An=1;function ar(t,i=!1){An+=t,t<0&&Se&&i&&(Se.hasOnce=!0)}function Fl(t){return t.dynamicChildren=An>0?Se||Vi:null,Es(),An>0&&Se&&Se.push(t),t}function it(t,i,e,n,o,s){return Fl(h(t,i,e,n,o,s,!0))}function De(t,i,e,n,o){return Fl(at(t,i,e,n,o,!0))}function Ms(t){return t?t.__v_isVNode===!0:!1}function rn(t,i){return t.type===i.type&&t.key===i.key}const Hl=({key:t})=>t??null,Jn=({ref:t,ref_key:i,ref_for:e})=>(typeof t=="number"&&(t=""+t),t!=null?Qt(t)||Zt(t)||At(t)?{i:ae,r:t,k:i,f:!!e}:t:null);function h(t,i=null,e=null,n=0,o=null,s=t===qt?0:1,l=!1,r=!1){const a={__v_isVNode:!0,__v_skip:!0,type:t,props:i,key:i&&Hl(i),ref:i&&Jn(i),scopeId:ml,slotScopeIds:null,children:e,component:null,suspense:null,ssContent:null,ssFallback:null,dirs:null,transition:null,el:null,anchor:null,target:null,targetStart:null,targetAnchor:null,staticCount:0,shapeFlag:s,patchFlag:n,dynamicProps:o,dynamicChildren:null,appContext:null,ctx:ae};return r?(fo(a,e),s&128&&t.normalize(a)):e&&(a.shapeFlag|=Qt(e)?8:16),An>0&&!l&&Se&&(a.patchFlag>0||s&6)&&a.patchFlag!==32&&Se.push(a),a}const at=zd;function zd(t,i=null,e=null,n=0,o=null,s=!1){if((!t||t===dd)&&(t=ri),Ms(t)){const r=Ji(t,i,!0);return e&&fo(r,e),An>0&&!s&&Se&&(r.shapeFlag&6?Se[Se.indexOf(t)]=r:Se.push(r)),r.patchFlag=-2,r}if(Yd(t)&&(t=t.__vccOpts),i){i=Nd(i);let{class:r,style:a}=i;r&&!Qt(r)&&(i.class=It(r)),Ht(a)&&(Ss(a)&&!Ct(a)&&(a=ce({},a)),i.style=Sn(a))}const l=Qt(t)?1:Nl(t)?128:Jc(t)?64:Ht(t)?4:At(t)?2:0;return h(t,i,e,n,o,l,s,!0)}function Nd(t){return t?Ss(t)||Tl(t)?ce({},t):t:null}function Ji(t,i,e=!1,n=!1){const{props:o,ref:s,patchFlag:l,children:r,transition:a}=t,c=i?Fd(o||{},i):o,u={__v_isVNode:!0,__v_skip:!0,type:t.type,props:c,key:c&&Hl(c),ref:i&&i.ref?e&&s?Ct(s)?s.concat(Jn(i)):[s,Jn(i)]:Jn(i):s,scopeId:t.scopeId,slotScopeIds:t.slotScopeIds,children:r,target:t.target,targetStart:t.targetStart,targetAnchor:t.targetAnchor,staticCount:t.staticCount,shapeFlag:t.shapeFlag,patchFlag:i&&t.type!==qt?l===-1?16:l|16:l,dynamicProps:t.dynamicProps,dynamicChildren:t.dynamicChildren,appContext:t.appContext,dirs:t.dirs,transition:a,component:t.component,suspense:t.suspense,ssContent:t.ssContent&&Ji(t.ssContent),ssFallback:t.ssFallback&&Ji(t.ssFallback),placeholder:t.placeholder,el:t.el,anchor:t.anchor,ctx:t.ctx,ce:t.ce};return a&&n&&$s(u,a.clone(u)),u}function Ie(t=" ",i=0){return at(Ao,null,t,i)}function ye(t,i){const e=at(Yn,null,t);return e.staticCount=i,e}function Rt(t="",i=!1){return i?(et(),De(ri,null,t)):at(ri,null,t)}function je(t){return t==null||typeof t=="boolean"?at(ri):Ct(t)?at(qt,null,t.slice()):Ms(t)?Je(t):at(Ao,null,String(t))}function Je(t){return t.el===null&&t.patchFlag!==-1||t.memo?t:Ji(t)}function fo(t,i){let e=0;const{shapeFlag:n}=t;if(i==null)i=null;else if(Ct(i))e=16;else if(typeof i=="object")if(n&65){const o=i.default;o&&(o._c&&(o._d=!1),fo(t,o()),o._c&&(o._d=!0));return}else{e=32;const o=i._;!o&&!Tl(i)?i._ctx=ae:o===3&&ae&&(ae.slots._===1?i._=1:(i._=2,t.patchFlag|=1024))}else if(At(i)){if(n&65){fo(t,{default:i});return}i={default:i,_ctx:ae},e=32}else i=String(i),n&64?(e=16,i=[Ie(i)]):e=8;t.children=i,t.shapeFlag|=e}function Fd(...t){const i={};for(let e=0;e<t.length;e++){const n=t[e];for(const o in n)if(o==="class")i.class!==n.class&&(i.class=It([i.class,n.class]));else if(o==="style")i.style=Sn([i.style,n.style]);else if(vo(o)){const s=i[o],l=n[o];l&&s!==l&&!(Ct(s)&&s.includes(l))?i[o]=s?[].concat(s,l):l:l==null&&s==null&&!bo(o)&&(i[o]=l)}else o!==""&&(i[o]=n[o])}return i}function Ne(t,i,e,n=null){Oe(t,i,7,[e,n])}const Hd=Cl();let jd=0;function Ud(t,i,e){const n=t.type,o=(i?i.appContext:t.appContext)||Hd,s={uid:jd++,vnode:t,type:n,parent:i,appContext:o,root:null,next:null,subTree:null,effect:null,update:null,job:null,scope:new mc(!0),render:null,proxy:null,exposed:null,exposeProxy:null,withProxy:null,provides:i?i.provides:Object.create(o.provides),ids:i?i.ids:["",0,0],accessCache:null,renderCache:[],components:null,directives:null,propsOptions:Ml(n,o),emitsOptions:$l(n,o),emit:null,emitted:null,propsDefaults:Ut,inheritAttrs:n.inheritAttrs,ctx:Ut,data:Ut,props:Ut,attrs:Ut,slots:Ut,refs:Ut,setupState:Ut,setupContext:null,suspense:e,suspenseId:e?e.pendingId:0,asyncDep:null,asyncResolved:!1,isMounted:!1,isUnmounted:!1,isDeactivated:!1,bc:null,c:null,bm:null,m:null,bu:null,u:null,um:null,bum:null,da:null,a:null,rtg:null,rtc:null,ec:null,sp:null};return s.ctx={_:s},s.root=i?i.root:s,s.emit=wd.bind(null,s),t.ce&&t.ce(s),s}let pe=null;const Wd=()=>pe||ae;let po,ls;{const t=xo(),i=(e,n)=>{let o;return(o=t[e])||(o=t[e]=[]),o.push(n),s=>{o.length>1?o.forEach(l=>l(s)):o[0](s)}};po=i("__VUE_INSTANCE_SETTERS__",e=>pe=e),ls=i("__VUE_SSR_SETTERS__",e=>Bn=e)}const Rn=t=>{const i=pe;return po(t),t.scope.on(),()=>{t.scope.off(),po(i)}},cr=()=>{pe&&pe.scope.off(),po(null)};function jl(t){return t.vnode.shapeFlag&4}let Bn=!1;function Vd(t,i=!1,e=!1){i&&ls(i);const{props:n,children:o}=t.vnode,s=jl(t);Id(t,n,s,i),Ed(t,o,e||i);const l=s?qd(t,i):void 0;return i&&ls(!1),l}function qd(t,i){const e=t.type;t.accessCache=Object.create(null),t.proxy=new Proxy(t.ctx,fd);const{setup:n}=e;if(n){ni();const o=t.setupContext=n.length>1?Gd(t):null,s=Rn(t),l=Ln(n,t,0,[t.props,o]),r=jr(l);if(oi(),s(),(r||t.sp)&&!Gi(t)&&yl(t),r){if(l.then(cr,cr),i)return l.then(a=>{dr(t,a)}).catch(a=>{Co(a,t,0)});t.asyncDep=l}else dr(t,l)}else Ul(t)}function dr(t,i,e){At(i)?t.type.__ssrInlineRender?t.ssrRender=i:t.render=i:Ht(i)&&(t.setupState=cl(i)),Ul(t)}function Ul(t,i,e){const n=t.type;t.render||(t.render=n.render||qe);{const o=Rn(t);ni();try{pd(t)}finally{oi(),o()}}}const Kd={get(t,i){return fe(t,"get",""),t[i]}};function Gd(t){const i=e=>{t.exposed=e||{}};return{attrs:new Proxy(t.attrs,Kd),slots:t.slots,emit:t.emit,expose:i}}function Bo(t){return t.exposed?t.exposeProxy||(t.exposeProxy=new Proxy(cl(Pc(t.exposed)),{get(i,e){if(e in i)return i[e];if(e in gn)return gn[e](t)},has(i,e){return e in i||e in gn}})):t.proxy}function Zd(t,i=!0){return At(t)?t.displayName||t.name:t.name||i&&t.__name}function Yd(t){return At(t)&&"__vccOpts"in t}const _t=(t,i)=>Fc(t,i,Bn),Jd="3.5.40";/**
* @vue/runtime-dom v3.5.40
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/let as;const ur=typeof window<"u"&&window.trustedTypes;if(ur)try{as=ur.createPolicy("vue",{createHTML:t=>t})}catch{}const Wl=as?t=>as.createHTML(t):t=>t,Xd="http://www.w3.org/2000/svg",Qd="http://www.w3.org/1998/Math/MathML",Ye=typeof document<"u"?document:null,fr=Ye&&Ye.createElement("template"),tu={insert:(t,i,e)=>{i.insertBefore(t,e||null)},remove:t=>{const i=t.parentNode;i&&i.removeChild(t)},createElement:(t,i,e,n)=>{const o=i==="svg"?Ye.createElementNS(Xd,t):i==="mathml"?Ye.createElementNS(Qd,t):e?Ye.createElement(t,{is:e}):Ye.createElement(t);return t==="select"&&n&&n.multiple!=null&&o.setAttribute("multiple",n.multiple),o},createText:t=>Ye.createTextNode(t),createComment:t=>Ye.createComment(t),setText:(t,i)=>{t.nodeValue=i},setElementText:(t,i)=>{t.textContent=i},parentNode:t=>t.parentNode,nextSibling:t=>t.nextSibling,querySelector:t=>Ye.querySelector(t),setScopeId(t,i){t.setAttribute(i,"")},insertStaticContent(t,i,e,n,o,s){const l=e?e.previousSibling:i.lastChild;if(o&&(o===s||o.nextSibling))for(;i.insertBefore(o.cloneNode(!0),e),!(o===s||!(o=o.nextSibling)););else{fr.innerHTML=Wl(n==="svg"?`<svg>${t}</svg>`:n==="mathml"?`<math>${t}</math>`:t);const r=fr.content;if(n==="svg"||n==="mathml"){const a=r.firstChild;for(;a.firstChild;)r.appendChild(a.firstChild);r.removeChild(a)}i.insertBefore(r,e)}return[l?l.nextSibling:i.firstChild,e?e.previousSibling:i.lastChild]}},eu=Symbol("_vtc");function iu(t,i,e){const n=t[eu];n&&(i=(i?[i,...n]:[...n]).join(" ")),i==null?t.removeAttribute("class"):e?t.setAttribute("class",i):t.className=i}const ho=Symbol("_vod"),Vl=Symbol("_vsh"),ql={name:"show",beforeMount(t,{value:i},{transition:e}){t[ho]=t.style.display==="none"?"":t.style.display,e&&i?e.beforeEnter(t):ln(t,i)},mounted(t,{value:i},{transition:e}){e&&i&&e.enter(t)},updated(t,{value:i,oldValue:e},{transition:n}){!i!=!e&&(n?i?(n.beforeEnter(t),ln(t,!0),n.enter(t)):n.leave(t,()=>{ln(t,!1)}):ln(t,i))},beforeUnmount(t,{value:i}){ln(t,i)}};function ln(t,i){t.style.display=i?t[ho]:"none",t[Vl]=!i}const nu=Symbol(""),ou=/(?:^|;)\s*display\s*:/;function su(t,i,e){const n=t.style,o=Qt(e);let s=!1;if(e&&!o){if(i)if(Qt(i))for(const l of i.split(";")){const r=l.slice(0,l.indexOf(":")).trim();e[r]==null&&dn(n,r,"")}else for(const l in i)e[l]==null&&dn(n,l,"");for(const l in e){l==="display"&&(s=!0);const r=e[l];r!=null?lu(t,l,!Qt(i)&&i?i[l]:void 0,r)||dn(n,l,r):dn(n,l,"")}}else if(o){if(i!==e){const l=n[nu];l&&(e+=";"+l),n.cssText=e,s=ou.test(e)}}else i&&t.removeAttribute("style");ho in t&&(t[ho]=s?n.display:"",t[Vl]&&(n.display="none"))}const pr=/\s*!important$/;function dn(t,i,e){if(Ct(e))e.forEach(n=>dn(t,i,n));else if(e==null&&(e=""),i.startsWith("--"))t.setProperty(i,e);else{const n=ru(t,i);pr.test(e)?t.setProperty(bi(n),e.replace(pr,""),"important"):t[n]=e}}const hr=["Webkit","Moz","ms"],jo={};function ru(t,i){const e=jo[i];if(e)return e;let n=ve(i);if(n!=="filter"&&n in t)return jo[i]=n;n=ko(n);for(let o=0;o<hr.length;o++){const s=hr[o]+n;if(s in t)return jo[i]=s}return i}function lu(t,i,e,n){return t.tagName==="TEXTAREA"&&(i==="width"||i==="height")&&Qt(n)&&e===n}const mr="http://www.w3.org/1999/xlink";function gr(t,i,e,n,o,s=pc(i)){n&&i.startsWith("xlink:")?e==null?t.removeAttributeNS(mr,i.slice(6,i.length)):t.setAttributeNS(mr,i,e):e==null||s&&!qr(e)?t.removeAttribute(i):t.setAttribute(i,s?"":Pe(e)?String(e):e)}function vr(t,i,e,n,o){if(i==="innerHTML"||i==="textContent"){e!=null&&(t[i]=i==="innerHTML"?Wl(e):e);return}const s=t.tagName;if(i==="value"&&s!=="PROGRESS"&&!s.includes("-")){const r=s==="OPTION"?t.getAttribute("value")||"":t.value,a=e==null?t.type==="checkbox"?"on":"":String(e);(r!==a||!("_value"in t))&&(t.value=a),e==null&&t.removeAttribute(i),t._value=e;return}let l=!1;if(e===""||e==null){const r=typeof t[i];r==="boolean"?e=qr(e):e==null&&r==="string"?(e="",l=!0):r==="number"&&(e=0,l=!0)}try{t[i]=e}catch{}l&&t.removeAttribute(o||i)}function pi(t,i,e,n){t.addEventListener(i,e,n)}function au(t,i,e,n){t.removeEventListener(i,e,n)}const br=Symbol("_vei");function cu(t,i,e,n,o=null){const s=t[br]||(t[br]={}),l=s[i];if(n&&l)l.value=n;else{const[r,a]=fu(i);if(n){const c=s[i]=mu(n,o);pi(t,r,c,a)}else l&&(au(t,r,l,a),s[i]=void 0)}}const du=/(Once|Passive|Capture)$/,uu=/^on:?(?:Once|Passive|Capture)$/;function fu(t){let i,e;for(;(e=t.match(du))&&!uu.test(t);)i||(i={}),t=t.slice(0,t.length-e[1].length),i[e[1].toLowerCase()]=!0;return[t[2]===":"?t.slice(3):bi(t.slice(2)),i]}let Uo=0;const pu=Promise.resolve(),hu=()=>Uo||(pu.then(()=>Uo=0),Uo=Date.now());function mu(t,i){const e=n=>{if(!n._vts)n._vts=Date.now();else if(n._vts<=e.attached)return;const o=e.value;if(Ct(o)){const s=n.stopImmediatePropagation;n.stopImmediatePropagation=()=>{s.call(n),n._stopped=!0};const l=o.slice(),r=[n];for(let a=0;a<l.length&&!n._stopped;a++){const c=l[a];c&&Oe(c,i,5,r)}}else Oe(o,i,5,[n])};return e.value=t,e.attached=hu(),e}const yr=t=>t.charCodeAt(0)===111&&t.charCodeAt(1)===110&&t.charCodeAt(2)>96&&t.charCodeAt(2)<123,gu=(t,i,e,n,o,s)=>{const l=o==="svg";i==="class"?iu(t,n,l):i==="style"?su(t,e,n):vo(i)?bo(i)||cu(t,i,e,n,s):(i[0]==="."?(i=i.slice(1),!0):i[0]==="^"?(i=i.slice(1),!1):vu(t,i,n,l))?(vr(t,i,n),!t.tagName.includes("-")&&(i==="value"||i==="checked"||i==="selected")&&gr(t,i,n,l,s,i!=="value")):t._isVueCE&&(bu(t,i)||t._def.__asyncLoader&&(/[A-Z]/.test(i)||!Qt(n)))?vr(t,ve(i),n,s,i):(i==="true-value"?t._trueValue=n:i==="false-value"&&(t._falseValue=n),gr(t,i,n,l))};function vu(t,i,e,n){if(n)return!!(i==="innerHTML"||i==="textContent"||i in t&&yr(i)&&At(e));if(i==="spellcheck"||i==="draggable"||i==="translate"||i==="autocorrect"||i==="sandbox"&&t.tagName==="IFRAME"||i==="form"||i==="list"&&t.tagName==="INPUT"||i==="type"&&t.tagName==="TEXTAREA")return!1;if(i==="width"||i==="height"){const o=t.tagName;if(o==="IMG"||o==="VIDEO"||o==="CANVAS"||o==="SOURCE")return!1}return yr(i)&&Qt(e)?!1:i in t}function bu(t,i){const e=t._def.props;if(!e)return!1;const n=ve(i);return Array.isArray(e)?e.some(o=>ve(o)===n):Object.keys(e).some(o=>ve(o)===n)}const Xi=t=>{const i=t.props["onUpdate:modelValue"]||!1;return Ct(i)?e=>Zn(i,e):i};function yu(t){t.target.composing=!0}function kr(t){const i=t.target;i.composing&&(i.composing=!1,i.dispatchEvent(new Event("input")))}const ii=Symbol("_assign");function wr(t,i,e){return i&&(t=t.trim()),e&&(t=wo(t)),t}const mo={created(t,{modifiers:{lazy:i,trim:e,number:n}},o){t[ii]=Xi(o);const s=n||o.props&&o.props.type==="number";pi(t,i?"change":"input",l=>{l.target.composing||t[ii](wr(t.value,e,s))}),(e||s)&&pi(t,"change",()=>{t.value=wr(t.value,e,s)}),i||(pi(t,"compositionstart",yu),pi(t,"compositionend",kr),pi(t,"change",kr))},mounted(t,{value:i}){t.value=i??""},beforeUpdate(t,{value:i,oldValue:e,modifiers:{lazy:n,trim:o,number:s}},l){if(t[ii]=Xi(l),t.composing)return;const r=(s||t.type==="number")&&!/^0\d/.test(t.value)?wo(t.value):t.value,a=i??"";if(r===a)return;const c=t.getRootNode();(c instanceof Document||c instanceof ShadowRoot)&&c.activeElement===t&&t.type!=="range"&&(n&&i===e||o&&t.value.trim()===a)||(t.value=a)}},qn={deep:!0,created(t,i,e){t[ii]=Xi(e),pi(t,"change",()=>{const n=t._modelValue,o=Tn(t),s=t.checked,l=t[ii];if(Ct(n)){const r=vs(n,o),a=r!==-1;if(s&&!a)l(n.concat(o));else if(!s&&a){const c=[...n];c.splice(r,1),l(c)}}else if(tn(n)){const r=new Set(n);s?r.add(o):r.delete(o),l(r)}else l(Kl(t,s))})},mounted:xr,beforeUpdate(t,i,e){t[ii]=Xi(e),xr(t,i,e)}};function xr(t,{value:i,oldValue:e},n){t._modelValue=i;let o;if(Ct(i))o=vs(i,n.props.value)>-1;else if(tn(i))o=i.has(n.props.value);else{if(i===e)return;o=en(i,Kl(t,!0))}t.checked!==o&&(t.checked=o)}const ku={deep:!0,created(t,{value:i,modifiers:{number:e}},n){t._modelValue=i,pi(t,"change",()=>{const o=Array.prototype.filter.call(t.options,s=>s.selected).map(s=>e?wo(Tn(s)):Tn(s));t[ii](t.multiple?tn(t._modelValue)?new Set(o):o:o[0]),t._assigning=!0,ul(()=>{t._assigning=!1})}),t[ii]=Xi(n)},mounted(t,{value:i}){_r(t,i)},beforeUpdate(t,{value:i},e){t._modelValue=i,t[ii]=Xi(e)},updated(t,{value:i}){t._assigning||_r(t,i)}};function _r(t,i){const e=t.multiple,n=Ct(i);if(!(e&&!n&&!tn(i))){for(let o=0,s=t.options.length;o<s;o++){const l=t.options[o],r=Tn(l);if(e)if(n){const a=typeof r;a==="string"||a==="number"?l.selected=i.some(c=>String(c)===String(r)):l.selected=vs(i,r)>-1}else l.selected=i.has(r);else if(en(Tn(l),i)){t.selectedIndex!==o&&(t.selectedIndex=o);return}}!e&&t.selectedIndex!==-1&&(t.selectedIndex=-1)}}function Tn(t){return"_value"in t?t._value:t.value}function Kl(t,i){const e=i?"_trueValue":"_falseValue";return e in t?t[e]:i}const wu=["ctrl","shift","alt","meta"],xu={stop:t=>t.stopPropagation(),prevent:t=>t.preventDefault(),self:t=>t.target!==t.currentTarget,ctrl:t=>!t.ctrlKey,shift:t=>!t.shiftKey,alt:t=>!t.altKey,meta:t=>!t.metaKey,left:t=>"button"in t&&t.button!==0,middle:t=>"button"in t&&t.button!==1,right:t=>"button"in t&&t.button!==2,exact:(t,i)=>wu.some(e=>t[`${e}Key`]&&!i.includes(e))},Me=(t,i)=>{if(!t)return t;const e=t._withMods||(t._withMods={}),n=i.join(".");return e[n]||(e[n]=((o,...s)=>{for(let l=0;l<i.length;l++){const r=xu[i[l]];if(r&&r(o,i))return}return t(o,...s)}))},_u={esc:"escape",space:" ",up:"arrow-up",left:"arrow-left",right:"arrow-right",down:"arrow-down",delete:"backspace"},Su=(t,i)=>{const e=t._withKeys||(t._withKeys={}),n=i.join(".");return e[n]||(e[n]=(o=>{if(!("key"in o))return;const s=bi(o.key);if(i.some(l=>l===s||_u[l]===s))return t(o)}))},Cu=ce({patchProp:gu},tu);let Sr;function $u(){return Sr||(Sr=Dd(Cu))}const Gl=((...t)=>{const i=$u().createApp(...t),{mount:e}=i;return i.mount=n=>{const o=Au(n);if(!o)return;const s=i._component;!At(s)&&!s.render&&!s.template&&(s.template=o.innerHTML),o.nodeType===1&&(o.textContent="");const l=e(o,!1,Iu(o));return o instanceof Element&&(o.removeAttribute("v-cloak"),o.setAttribute("data-v-app","")),l},i});function Iu(t){if(t instanceof SVGElement)return"svg";if(typeof MathMLElement=="function"&&t instanceof MathMLElement)return"mathml"}function Au(t){return Qt(t)?document.querySelector(t):t}const Bu="slidev-config.json",Qi={enableWebServeJump:!1,webServeUrl:"http://127.0.0.1:6806",normalizeHeadingSizes:!1},hi=So({...Qi});function Tu(t){if(!t||typeof t!="object")return{...Qi};const i=t;return{enableWebServeJump:!!i.enableWebServeJump,webServeUrl:typeof i.webServeUrl=="string"&&i.webServeUrl.trim()?i.webServeUrl.trim():Qi.webServeUrl,normalizeHeadingSizes:!!i.normalizeHeadingSizes}}function Ei(t){if(!t||typeof t!="object")return{...hi};const i=t;return i.enableWebServeJump!==void 0&&(hi.enableWebServeJump=!!i.enableWebServeJump),i.webServeUrl!==void 0&&(hi.webServeUrl=String(i.webServeUrl)),i.normalizeHeadingSizes!==void 0&&(hi.normalizeHeadingSizes=!!i.normalizeHeadingSizes),{...hi}}function To(){return{...hi}}function Zl(t,i,e){const n=(t||Qi.webServeUrl).trim(),o=n.startsWith("http://")||n.startsWith("https://")?n:`http://${n}`,s=(e==null?void 0:e.r)||Math.random().toString(36).slice(2,9).padEnd(7,"0");try{const l=new URL(o);let r=l.pathname.replace(/\/+$/,"");return r.endsWith("/stage/build/desktop")||(r=r?`${r}/stage/build/desktop`:"/stage/build/desktop"),l.pathname=`${r}/`,l.searchParams.set("id",i),e!=null&&e.focus&&l.searchParams.set("focus","1"),l.searchParams.set("r",s),l.toString()}catch{const l=e!=null&&e.focus?"&focus=1":"";return`${o.replace(/\/+$/,"")}/stage/build/desktop/?id=${i}${l}&r=${s}`}}const Si={theme:"default",aspectRatio:"16/9",highlighter:"shiki",defaultTransition:"slide-left",colorSchema:"auto",spacing:"normal",normalizeHeadingSizes:!1};function Eu(t){var e,n,o,s,l,r;const i=To();return t?{theme:((e=t[kn])==null?void 0:e.trim())||Si.theme,aspectRatio:((n=t[wn])==null?void 0:n.trim())||Si.aspectRatio,highlighter:((o=t[zr])==null?void 0:o.trim())||Si.highlighter,defaultTransition:((s=t[xn])==null?void 0:s.trim())||Si.defaultTransition,colorSchema:((l=t[Nr])==null?void 0:l.trim())||Si.colorSchema,spacing:((r=t[Jo])==null?void 0:r.trim())||Si.spacing,normalizeHeadingSizes:i.normalizeHeadingSizes}:{...Si,normalizeHeadingSizes:i.normalizeHeadingSizes}}function go(t){var e,n,o,s,l;const i=(e=t.ial)==null?void 0:e[Bi];return!!(i&&(i==="true"||i==="page"||i==="cover"||i==="end")||t.type==="tb"||t.type==="thematic-break"||t.type==="NodeThematicBreak"||((n=t.markdown)==null?void 0:n.trim())==="---"||((o=t.markdown)==null?void 0:o.trim())==="***"||t.type==="b"&&(((s=t.markdown)==null?void 0:s.trim())==="---"||((l=t.content)==null?void 0:l.trim())==="---"))}function Cr(t){const i={};let e="";if(!t)return{frontmatter:i,notes:e};t[mt]&&(i.layout=t[mt].trim()),t[Xt]&&(i.transition=t[Xt].trim()),t[jt]&&(i.background=t[jt].trim()),t[Ee]&&(i.image=t[Ee].trim()),t[Wi]&&(i.class=t[Wi].trim()),t[un]&&(i.spacing=t[un].trim()),t[oe]&&(i.layoutRatio=t[oe].trim()),t[Ui]&&(e=t[Ui].trim());for(const[n,o]of Object.entries(t))if(n.startsWith("custom-slidev-")&&![mt,oe,Xt,jt,Ee,Wi,un,Ui,Bi].includes(n)){const s=n.replace(/^custom-slidev-/,"");try{i[s]=JSON.parse(o)}catch{i[s]=o}}return{frontmatter:i,notes:e}}function Mu(t){const i={};if(!t)return i;const e=t[te]??t["slidev-note"];e!=null&&e!==""&&e!=="false"&&e!=="0"&&(i.isNote=!0);const n=t[Vt]??t["slidev-role"],o=t[jt]??t["slidev-background"];(n===Fr||o==="true"||o==="1")&&(i.isBackground=!0);const s=t[mt]??t["slidev-layout"];s===oo||s===so?i.imageLayout=s:(n===oo||n===so)&&(i.imageLayout=n);const l=t[Ae]??t["custom-slidev-clicks"]??t["slidev-click"]??t["slidev-clicks"];if(l!=null&&(i.clicks=l.trim()),t[Ve])try{const r=JSON.parse(t[Ve]);typeof r=="object"&&r!==null?i.motion={preset:r.preset||r.type||"fade-in",...r}:i.motion={preset:String(r).trim()}}catch{i.motion={preset:t[Ve].trim()}}return t[Ri]&&(i.shikiLines=t[Ri].trim()),t[_n]&&(i.maxHeight=t[_n].trim()),t[Bt]&&(i.slot=t[Bt].trim()),t.style&&t.style.trim()&&(i.style=t.style.trim()),i}function vi(t,i){const e=(t||i||"").trim();if(!e)return null;const n=e.match(/!\[[\s\S]*?\]\(\s*([^\s)]+)(?:\s+(?:=["']?[^"'\s)]*["']?|["'][^"']*["']))*?\s*\)/);if(n)return n[1].trim();const o=e.match(/<img\b[^>]*?\bsrc=["']([^"']+)["']/i);if(o)return o[1].trim();const s=e.replace(/\{:[^}]*\}/g,"").trim();return/^(?:assets\/|https?:\/\/|\/|\.\.?\/)[^\s]+\.(?:png|jpe?g|gif|webp|svg|avif)(?:\?[^\s]*)?$/i.test(s)?s:null}function Yl(t){if(!t)return"";const i=t.split(/\r?\n/);if(i.length===0)return"";const e=i[0],n=e.match(/^(\s*)(?:[-*+]|\d+\.)\s+(.*)$/);if(!n)return t;const o=n[1].length,s=n[2].trim(),l=e.length-n[2].length;if(i.length===1)return s;const r=[s];for(let a=1;a<i.length;a++){const c=i[a];if(!c.trim()){r.push("");continue}const u=c.match(/^(\s*)/),m=u?u[1].length:0;m>=l?r.push(c.slice(l)):m>o?r.push(c.slice(m)):r.push(c)}return r.join(`
`)}function En(t){if(!t)return!1;const i=(t.type||"").toLowerCase();if(i==="i"||i==="nodelistitem"||i==="l"||i==="nodelist")return!0;const e=(t.markdown||t.rawMarkdown||t.content||"").trim();return!!/^(?:[-*+]|\d+\.)\s+/.test(e)}function Wo(t,i=2){if(!t||typeof t!="string")return`repeat(${i}, 1fr)`;const e=t.trim();if(!e)return`repeat(${i}, 1fr)`;if(e.includes(":")){const o=e.split(":").map(s=>parseFloat(s.trim())).filter(s=>!isNaN(s)&&s>0);if(o.length>=2)return o.map(s=>`${s}fr`).join(" ")}const n=e.split(/\s+/).filter(Boolean);return n.length>=2?n.join(" "):`repeat(${i}, 1fr)`}function vn(t){if(!t)return[];if(se(t)&&li(t)&&!yi(t)){const n=On(t),o=[];for(const s of n)o.push(...vn(s));return o}const i=(t.type||"").toLowerCase();if(i==="l"||i==="nodelist"||i==="list"){if(t.children&&t.children.length>0){const l=t.children.filter(En);if(l.length>0)return l}const o=(t.markdown||t.content||"").trim().split(/\r?\n/),s=[];for(let l=0;l<o.length;l++)/^(?:[-*+]|\d+\.)\s+/.test(o[l])&&s.push(l);if(s.length>=2){const l=[];for(let r=0;r<s.length;r++){const a=s[r],c=r+1<s.length?s[r+1]:o.length,u=o.slice(a,c).join(`
`);l.push({id:`${t.id}-item-${r+1}`,type:"i",markdown:u,content:u,ial:{...t.ial||{}}})}return l}}return En(t)?[t]:[]}function Jl(t){var o;if(!t||!se(t)||!li(t)||yi(t))return null;const i=On(t);if(i.length===0)return null;if(i.length===1&&se(i[0])&&li(i[0])){const s=Jl(i[0]);return s?{items:s.items,nestedSuperBlocks:[i[0],...s.nestedSuperBlocks]}:null}const e=[];for(const s of i)if(se(s)){e.push(s);const l=((o=s.children)==null?void 0:o.filter(se))||[];e.push(...l)}const n=i.map(vn);if(n.length>=2&&n.every(s=>s.length>0)){const s=n.flat();if(s.length>=2&&s.length<=6)return{items:s,nestedSuperBlocks:e}}if(i.length===2){const s=vn(i[0]),l=vn(i[1]);if(s.length+l.length>=2&&s.length+l.length<=6&&(s.length>0||l.length>0))return{items:[...s,...l],nestedSuperBlocks:e}}return null}function Du(t){if(!t||!se(t)||!li(t)||yi(t))return null;const i=Jl(t);if(!i)return null;const{items:e,nestedSuperBlocks:n}=i;if(e.length<2||e.length>6)return null;const o=Ds(t)||void 0,s=e.length;return{superBlockNode:t,nestedSuperBlocks:n,count:s,layout:"cols-header",items:e,slots:e.map((l,r)=>`col-${r+1}`),ratio:o}}function Lu(t){if(!t||!se(t)||!li(t)||yi(t))return null;const i=On(t);if(i.length===0)return null;const e=[];for(const n of i){const o=vn(n);if(o.length===0)return null;e.push(...o)}return e}function Pu(t){if(!t||!se(t)||!li(t)||yi(t))return null;const i=Lu(t);return!i||i.length===0||i.length>=2&&i.length<=6?null:{superBlockNode:t,items:i}}function Ru(t,i,e){var u,m,v,d,b;const n=[],o=[],s=(e==null?void 0:e.tracked)||[],l=[];let r={pageTargetId:t,blocks:[]};l.push(r);for(let f=0;f<i.length;f++){const y=i[f];if(go(y)){if(l.length===1&&r.blocks.length===0){r.pageTargetId=y.id,r.blocks.push(y);continue}r={pageTargetId:y.id,blocks:[y]},l.push(r)}else r.blocks.push(y)}function a(f){const y=[];for(const k of f)se(k)&&y.push(k),k.children&&k.children.length>0&&y.push(...a(k.children));return y}function c(f,y,k){const x={blockId:f,attrs:y,previousAttrs:k};n.push(x),e!=null&&e.onTagChange&&e.onTagChange(x)}for(const f of l){const y=f.pageTargetId,k=i.find(I=>I.id===y),x=s.find(I=>I.pageTargetId===y);if(f.blocks.some(I=>{var w,D;return!!(yi(I)||cs(I)&&(((w=I.ial)==null?void 0:w[mt])==="image-left"||((D=I.ial)==null?void 0:D[mt])==="image-right"))})){if(x){const I=x.headerId;if(I){c(I,{[Bt]:""});const w=i.find(D=>D.id===I);w!=null&&w.ial&&(w.ial[Bt]="")}for(const w of x.itemIds){c(w,{[Bt]:""});const D=i.find(P=>P.id===w);D!=null&&D.ial&&(D.ial[Bt]="")}}continue}let A=null,B=-1;for(let I=0;I<f.blocks.length;I++){const w=f.blocks[I],D=se(w)?[w,...a(w.children||[])]:w.children?a(w.children):[];for(const P of D){const R=Du(P);if(R){A=R,B=I;break}}if(A)break}if(A){const{superBlockNode:I,layout:w,items:D,slots:P}=A,J=f.blocks.slice(0,B).find(N=>zu(N)),S=J==null?void 0:J.id,H=((u=k==null?void 0:k.ial)==null?void 0:u[mt])||"";if(H!==w&&(c(y,{[mt]:w},{[mt]:H}),k&&(k.ial||(k.ial={}),k.ial[mt]=w)),J){const N=((m=J.ial)==null?void 0:m[Bt])||"";N!=="header"&&(c(J.id,{[Bt]:"header"},{[Bt]:N}),J.ial||(J.ial={}),J.ial[Bt]="header")}if(x!=null&&x.headerId&&x.headerId!==S){c(x.headerId,{[Bt]:""});const N=i.find(q=>q.id===x.headerId);N&&(N.ial||(N.ial={}),N.ial[Bt]="")}const g=[];for(let N=0;N<D.length;N++){const q=D[N],U=P[N];g.push(q.id);const G=((v=q.ial)==null?void 0:v[Bt])||"";if(G!==U&&(c(q.id,{[Bt]:U},{[Bt]:G}),q.ial||(q.ial={}),q.ial[Bt]=U),q.children&&q.children.length>0)for(const Z of q.children)Z.ial||(Z.ial={}),Z.ial[Bt]!==U&&(Z.ial[Bt]=U)}if(x!=null&&x.itemIds){for(const N of x.itemIds)if(!g.includes(N)){c(N,{[Bt]:""});const q=i.find(U=>U.id===N);q&&(q.ial||(q.ial={}),q.ial[Bt]="")}}o.push({superBlockId:I.id,nestedSuperBlockIds:(d=A.nestedSuperBlocks)==null?void 0:d.map(N=>N.id),pageTargetId:y,headerId:S,itemIds:g,layout:w})}else{let I=!1;const w=[];for(const R of f.blocks){const J=se(R)?[R,...a(R.children||[])]:R.children?a(R.children):[];for(const S of J){const H=Pu(S);if(H){I=!0;for(const g of H.items)w.push(g.id)}}}const D=((b=k==null?void 0:k.ial)==null?void 0:b[mt])||"",P=ps(D);if(x||I&&P){c(y,{[mt]:""},{[mt]:D}),k&&(k.ial||(k.ial={}),k.ial[mt]="");const R=x==null?void 0:x.headerId;if(R){c(R,{[Bt]:""});const S=i.find(H=>H.id===R);S&&(S.ial||(S.ial={}),S.ial[Bt]="")}const J=new Set([...(x==null?void 0:x.itemIds)||[],...w]);for(const S of J){c(S,{[Bt]:""});const H=i.find(g=>g.id===S);H&&(H.ial||(H.ial={}),H.ial[Bt]="")}}}}return{changes:n,newTracked:o}}function se(t){if(!t)return!1;const i=(t.type||"").toLowerCase();return i==="s"||i==="sb"||i==="nodesuperblock"}function li(t){if(!se(t))return!1;const i=(t.subType||"").toLowerCase();if(i==="col"||i==="h"||i==="horizontal")return!0;if(i==="row"||i==="v"||i==="vertical")return!1;if(t.ial){const n=(t.ial["data-sb-layout"]||t.ial.layout||"").toLowerCase();if(n==="col"||n==="h")return!0;if(n==="row"||n==="v")return!1}if(t.children&&t.children.length>0){for(const n of t.children)if(n.type==="NodeSuperBlockLayoutMarker"||n.type==="layout-marker"){const o=(n.content||n.markdown||"").trim().toLowerCase();if(o==="col"||o==="h")return!0;if(o==="row"||o==="v")return!1}}const e=(t.markdown||t.content||"").trim();return/^\{\{\{col\b/i.test(e)?!0:!/^\{\{\{row\b/i.test(e)}function cs(t){return!t||En(t)||se(t)||!vi(t.markdown,t.content)?!1:(t.markdown||t.content||"").replace(/!\[.*?\]\([^)]+\)/g,"").replace(/<img\b[^>]*>/gi,"").replace(/\{:[^}]*\}/g,"").trim().length<=25}function Ds(t){var v;if(!t||!se(t)||!li(t))return null;const i=On(t);if(!i||i.length<2)return null;const e=[];let n=!1;for(const d of i){const b=(((v=d.ial)==null?void 0:v.style)||d.style||"").trim();let f=null;if(b){const y=b.match(/calc\(\s*([\d.]+)%/i);if(y)f=parseFloat(y[1]);else{const k=b.match(/(?:^|;|\s)width:\s*([\d.]+)%/i);k&&(f=parseFloat(k[1]))}}f!==null&&!isNaN(f)&&f>0?(e.push(f),n=!0):e.push(null)}if(!n)return null;const o=i.length,s=e.reduce((d,b)=>d+(b||0),0),l=e.filter(d=>d===null).length,r=Math.max(0,100-s),a=l>0?r/l:100/o,c=e.map(d=>d!==null?d:a),u=c.reduce((d,b)=>d+b,0);if(u<=0)return null;const m=c.map(d=>d/u*100);if(m.length===2){const[d]=m;if(d>=48&&d<=52)return"1:1";if(d>=31&&d<=35)return"1:2";if(d>=65&&d<=69)return"2:1";if(d>=28&&d<=32)return"3:7";if(d>=68&&d<=72)return"7:3";if(d>=38&&d<=42)return"4:6";if(d>=58&&d<=62)return"6:4";if(d>=23&&d<=27)return"1:3";if(d>=73&&d<=77)return"3:1";const b=Math.round(d),f=100-b;return`${b}:${f}`}if(m.length===3){const[d,b,f]=m;if(d>=31&&d<=35&&b>=31&&b<=35&&f>=31&&f<=35)return"1:1:1";if(d>=23&&d<=27&&b>=48&&b<=52&&f>=23&&f<=27)return"1:2:1";if(d>=48&&d<=52&&b>=23&&b<=27&&f>=23&&f<=27)return"2:1:1";if(d>=23&&d<=27&&b>=23&&b<=27&&f>=48&&f<=52)return"1:1:2";if(d>=18&&d<=22&&b>=58&&b<=62&&f>=18&&f<=22)return"1:3:1";const y=Math.round(d),k=Math.round(b),x=100-y-k;return`${y}:${k}:${x}`}return m.map(d=>Math.round(d)).join(":")}function yi(t){if(!t||!se(t)||!li(t))return null;const i=(t.children||[]).filter(s=>{const l=s.type||"";if(l==="NodeSuperBlockOpenMarker"||l==="NodeSuperBlockLayoutMarker"||l==="NodeSuperBlockCloseMarker"||l==="open-marker"||l==="layout-marker"||l==="close-marker")return!1;const r=(s.markdown||s.content||"").trim();return!(/^\{\{\{(?:col|row)?\s*$/i.test(r)||r==="}}}")});if(i.length<2)return null;const e=cs(i[0]),n=cs(i[i.length-1]),o=Ds(t)||void 0;if(e&&!n){const s=vi(i[0].markdown,i[0].content);if(s)return{imageNode:i[0],imageUrl:s,layout:oo,contentNodes:i.slice(1),ratio:o}}if(!e&&n){const s=vi(i[i.length-1].markdown,i[i.length-1].content);if(s)return{imageNode:i[i.length-1],imageUrl:s,layout:so,contentNodes:i.slice(0,i.length-1),ratio:o}}return null}function Ou(t,i){const e=[];function n(o){for(const s of o){const l=yi(s);if(l){const{imageNode:r,layout:a,ratio:c}=l;r.ial||(r.ial={});const u=r.ial[mt];if(u!==a){const v={blockId:r.id,layout:a,previousLayout:u,ratio:c};r.ial[mt]=a,e.push(v),i&&i(v)}}s.children&&s.children.length>0&&n(s.children)}}return n(t),e}function On(t){return(t.children||[]).filter(i=>{const e=i.type||"";if(e==="NodeSuperBlockOpenMarker"||e==="NodeSuperBlockLayoutMarker"||e==="NodeSuperBlockCloseMarker"||e==="open-marker"||e==="layout-marker"||e==="close-marker")return!1;const n=(i.markdown||i.content||"").trim();return!(/^\{\{\{(?:col|row)?\s*$/i.test(n)||n==="}}}")})}function zu(t){if(!t)return!1;const i=(t.type||"").toLowerCase();if(i==="h"||i==="nodeheading"||/^h[1-6]$/i.test(t.subType||""))return!0;const e=(t.markdown||t.content||"").trim();return!!/^#{1,6}\s+/.test(e)}function Ci(t,i,e){let n="",o=0;const s=/<div\b([^>]*)>/gi;for(;o<t.length;){s.lastIndex=o;let l,r=!1,a=-1,c=0;for(;(l=s.exec(t))!==null;){const k=l[1].match(/\bclass=["']([^"']*)["']/i);if(k){const x=k[1];if(typeof i=="string"?x.split(/\s+/).includes(i):i.test(x)){r=!0,a=l.index,c=l[0].length;break}}}if(!r){n+=t.slice(o);break}n+=t.slice(o,a);const u=a+c;let m=1,v=-1,d=-1;const b=/<\/?div\b[^>]*>/gi;b.lastIndex=u;let f;for(;(f=b.exec(t))!==null;)if(f[0].startsWith("</")){if(m--,m===0){v=f.index,d=f.index+f[0].length;break}}else m++;if(v!==-1&&d!==-1){const y=t.slice(u,v);n+=e(y),o=d}else n+=t.slice(a,u),o=u}return n}function Nu(t){const i=[];let e="",n=0;const o=/<div\b([^>]*)>/gi;for(;n<t.length;){o.lastIndex=n;let s,l=!1,r=-1,a=0;for(;(s=o.exec(t))!==null;){const f=s[1];if(/(?:\s@[a-zA-Z0-9_-]+=\s*["']|\s:[a-zA-Z0-9_-]+=\s*["']|\sv-[a-zA-Z0-9_.-]+|\shover:[a-zA-Z0-9_.-]+=\s*["']|\sgrid=["']~|\bclass=["'][^"']*\b(?:abs-br|slidev-icon-btn|grid\s+|grid$|grid-cols-|relative\b)\b[^"']*["']|\bstyle=["'][^"']*\bgrid-[^"']*["'])/i.test(f)){l=!0,r=s.index,a=s[0].length;break}}if(!l){e+=t.slice(n);break}e+=t.slice(n,r);const c=r+a;let u=1,m=-1,v=-1;const d=/<\/?div\b[^>]*>/gi;d.lastIndex=c;let b;for(;(b=d.exec(t))!==null;)if(b[0].startsWith("</")){if(u--,u===0){m=b.index,v=b.index+b[0].length;break}}else u++;if(m!==-1&&v!==-1){const f=t.slice(r,v),y=`__VUE_DIV_TOKEN_${i.length}__`;i.push(f),e+=y,n=v}else e+=t.slice(r,c),n=c}return{text:e,tokens:i}}function Fu(t){const i=[];let e=t.replace(/(?:^[ \t]*(`{3,}|~{3,})[^\n\r]*\r?\n[\s\S]*?\r?\n[ \t]*\1(?=[ \t]*(?:\r?\n|$)))/gm,r=>{const a=`__CODE_TOKEN_${i.length}__`;return i.push(r),a});e=e.replace(/(`+)(?:[^\n\r`]|(?!\1)`)+?\1/g,r=>{const a=`__CODE_TOKEN_${i.length}__`;return i.push(r),a});const n=[];e=e.replace(/<script\b[^>]*>[\s\S]*?<\/script>/gi,r=>{const a=`__SCRIPT_TOKEN_${n.length}__`;return n.push(r),a});const{text:o,tokens:s}=Nu(e);e=o;const l=[];e=e.replace(/<(?:[A-Z][a-zA-Z0-9_-]*|[a-z0-9_-]+:[a-z0-9_-]+|v-[a-z0-9_-]+|arrow\b|div\s+h-\d+)\b[^>]*\/>/gi,r=>{const a=`__VUE_COMP_TOKEN_${l.length}__`;return l.push(r),a}),e=e.replace(/<(v-[a-z0-9_-]+|button)\b([^>]*)>([\s\S]*?)<\/\1>/gi,r=>{const a=`__VUE_COMP_TOKEN_${l.length}__`;return l.push(r),a}),e=e.replace(/<img\b[^>]*?\bv-[a-z0-9_.-]+[^>]*\/?>/gi,r=>{const a=`__VUE_COMP_TOKEN_${l.length}__`;return l.push(r),a}),e=e.replace(/<(p|span)\b([^>]*?\bv-[a-z0-9_.-]+[^>]*)>([\s\S]*?)<\/\1>/gi,r=>{const a=`__VUE_COMP_TOKEN_${l.length}__`;return l.push(r),a}),e=e.replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi,""),e=e.replace(/<div class="terminal-bar">[\s\S]*?<\/div>/gi,""),e=e.replace(/<div class="cursor-line">[\s\S]*?<\/div>/gi,""),e=e.replace(/<span class="cursor">[\s\S]*?<\/span>/gi,""),e=e.replace(/<div class="stamp">\s*([\s\S]*?)\s*<\/div>/gi,`

*[$1]*

`),e=e.replace(/<div class="arrow">\s*([→\->]+)\s*<\/div>/gi,`

$1

`),e=e.replace(/<i>\s*[→\->]+\s*<\/i>/gi,""),e=e.replace(/<div class="prompt">\s*([\s\S]*?)\s*<\/div>/gi,(r,a)=>`
\`\`\`bash
${a.trim()}
\`\`\`
`),e=e.replace(/<p>\s*<i>\$<\/i>\s*([\s\S]*?)<\/p>/gi,(r,a)=>`
\`\`\`bash
$ ${a.trim()}
\`\`\`
`),e=e.replace(/<div class="statusline">\s*([\s\S]*?)\s*<\/div>/gi,(r,a)=>`
> ${Array.from(a.matchAll(/<span>([\s\S]*?)<\/span>/gi)).map(u=>`\`${u[1].trim()}\``).join(" | ")}
`),e=e.replace(/<div class="log-panel">\s*<pre>([\s\S]*?)<\/pre>\s*<\/div>/gi,(r,a)=>`
\`\`\`log
${a.replace(/<span[^>]*>([\s\S]*?)<\/span>/gi,"$1").trim()}
\`\`\`
`),e=Ci(e,"diff-grid",r=>{const a=Array.from(r.matchAll(/<div class="diff\s+([^"]*)">\s*<span>(.*?)<\/span>\s*<pre>([\s\S]*?)<\/pre>\s*<\/div>/gi));return a.length>0?`
`+a.map(c=>{const u=c[2].trim().toUpperCase(),m=c[3].trim();return`**${u}:**
\`\`\`yaml
${m}
\`\`\``}).join(`

`)+`
`:r}),e=Ci(e,"before-after",r=>{const a=r.match(/<div class="before">[\s\S]*?<small>(.*?)<\/small>[\s\S]*?<h2>(.*?)<\/h2>[\s\S]*?<p>(.*?)<\/p>\s*<\/div>/i),c=r.match(/<div class="after">[\s\S]*?<small>(.*?)<\/small>[\s\S]*?<h2>(.*?)<\/h2>[\s\S]*?<p>(.*?)<\/p>\s*<\/div>/i);let u=`
`;return a&&(u+=`### ${a[1]}
## ${a[2]}
${a[3]}

`),c&&(u+=`### ${c[1]}
## ${c[2]}
${c[3]}
`),u.trim()?u:r}),e=e.replace(/<ul\b[^>]*>([\s\S]*?)<\/ul>/gi,(r,a)=>{const c=Array.from(a.matchAll(/<li>\s*(?:<em>)?(\[[x ]\])(?:<\/em>)?\s*([\s\S]*?)<\/li>/gi));return c.length>0?`
`+c.map(u=>`- ${u[1]} ${u[2].trim()}`).join(`
`)+`
`:a}),e=Ci(e,"timeline",r=>{const a=Array.from(r.matchAll(/<div(?:\s+class="([^"]*)")?>\s*<time>([\s\S]*?)<\/time>\s*<b>([\s\S]*?)<\/b>\s*<span>([\s\S]*?)<\/span>\s*<\/div>/gi));return a.length>0?`

`+a.map(c=>{const u=c[1]||"";let m="-";return u.includes("warn")?m="- ⚠️":u.includes("bad")?m="- ❌":u.includes("ok")&&(m="- ✅"),`${m} **${c[2].trim()}** **${c[3].trim()}** — ${c[4].trim()}`}).join(`
`)+`

`:r}),e=Ci(e,"pipeline",r=>{const a=Array.from(r.matchAll(/<div(?:\s+class="([^"]*)")?>\s*<small>([\s\S]*?)<\/small>\s*<b>([\s\S]*?)<\/b>\s*<span>([\s\S]*?)<\/span>\s*<\/div>/gi));return a.length>0?`

`+a.map((c,u)=>{const v=(c[1]||"").includes("hot")?"⚠️ ":"";return`${u+1}. ${v}**${c[3].trim()}** (*${c[4].trim()}*)`}).join(`
`)+`

`:r}),e=Ci(e,"check-grid",r=>{const a=Array.from(r.matchAll(/<div>\s*<span class="([^"]*)"><\/span>\s*<b>([\s\S]*?)<\/b>\s*<p>([\s\S]*?)<\/p>\s*<\/div>/gi));return a.length>0?`

`+a.map(c=>`- ${(c[1]||"").includes("warn")?"⚠️":"✅"} **${c[2].trim()}**: ${c[3].trim()}`).join(`
`)+`

`:r}),e=Ci(e,"manifesto",r=>{const a=Array.from(r.matchAll(/<div>\s*<span>([\s\S]*?)<\/span>\s*<h2>([\s\S]*?)<\/h2>\s*<p>([\s\S]*?)<\/p>\s*<\/div>/gi));return a.length>0?`

`+a.map(c=>`## ${c[1].trim()} ${c[2].trim()}

${c[3].trim()}`).join(`

`)+`

`:r}),e=Ci(e,"split-note",r=>{const a=Array.from(r.matchAll(/<div>\s*<b>([\s\S]*?)<\/b>\s*<p>([\s\S]*?)<\/p>\s*<\/div>/gi));return a.length>0?`

`+a.map(c=>`> **${c[1].trim()}**: ${c[2].trim()}`).join(`
>
`)+`

`:r}),e=e.replace(/<div class="mechanism">\s*<b>([\s\S]*?)<\/b>\s*<p>([\s\S]*?)<\/p>\s*<\/div>/gi,(r,a,c)=>`

> **${a.trim()}**: ${c.trim()}

`),e=e.replace(/<pre>([\s\S]*?)<\/pre>/gi,(r,a)=>`
\`\`\`text
${a.replace(/<span[^>]*>([\s\S]*?)<\/span>/gi,"$1").trim()}
\`\`\`
`),e=e.replace(/<div class="page-head">\s*<span>([\s\S]*?)<\/span>\s*<b>([\s\S]*?)<\/b>\s*<\/div>/gi,`
### $1 ($2)
`),e=e.replace(/<h1\b[^>]*>([\s\S]*?)<\/h1>/gi,`
# $1
`),e=e.replace(/<h2\b[^>]*>([\s\S]*?)<\/h2>/gi,`
## $1
`),e=e.replace(/<h3\b[^>]*>([\s\S]*?)<\/h3>/gi,`
### $1
`),e=e.replace(/<h4\b[^>]*>([\s\S]*?)<\/h4>/gi,`
#### $1
`),e=e.replace(/<p\s+class="ok">\s*●\s*([\s\S]*?)<\/p>/gi,`
✅ **$1**
`),e=e.replace(/<p\s+class="caption">\s*([\s\S]*?)<\/p>/gi,`
> *$1*
`),e=e.replace(/<p\s+class="lead">\s*([\s\S]*?)<\/p>/gi,`
*$1*
`),e=e.replace(/<p\b([^>]*)>([\s\S]*?)<\/p>/gi,(r,a,c)=>/@|v-|:|class=/i.test(a)?r:`
${c.trim()}

`),e=e.replace(/<br\s*\/?>/gi,`
`),e=e.replace(/<hr\s*\/?>/gi,`
---
`),e=e.replace(/<b\b[^>]*>([\s\S]*?)<\/b>/gi,"**$1**"),e=e.replace(/<strong\b[^>]*>([\s\S]*?)<\/strong>/gi,"**$1**"),e=e.replace(/<i\b[^>]*>([\s\S]*?)<\/i>/gi,"*$1*"),e=e.replace(/<code\b[^>]*>([\s\S]*?)<\/code>/gi,(r,a)=>{if(a.startsWith("`")&&a.endsWith("`"))return a;if(a.includes("`")){const c=(a.match(/`+/g)||[]).reduce((m,v)=>Math.max(m,v.length),0),u="`".repeat(c+1);return`${u} ${a} ${u}`}return`\`${a}\``}),e=e.replace(/<small\b[^>]*>([\s\S]*?)<\/small>/gi,"*$1*"),e=e.replace(/\*{4}/g,"** **"),e=e.replace(/<li\b[^>]*>([\s\S]*?)<\/li>/gi,`- $1
`),e=e.replace(/<ul\b[^>]*>([\s\S]*?)<\/ul>/gi,`
$1
`),e=e.replace(/<ol\b[^>]*>([\s\S]*?)<\/ol>/gi,`
$1
`),e=e.replace(/<a\b([^>]*)href=["'](.*?)["']([^>]*)>([\s\S]*?)<\/a>/gi,(r,a,c,u,m)=>{const v=m.trim();return v.includes("<")||v.includes(`
`)?r:`[${v}](${c})`}),e=e.replace(/<blockquote\b[^>]*>([\s\S]*?)<\/blockquote>/gi,(r,a)=>`
`+a.trim().split(`
`).map(c=>`> ${c.trim()}`).join(`
`)+`
`),e=e.replace(/<span\b[^>]*data-type=["']block-ref["'][^>]*data-id=["']([0-9a-zA-Z-]+)["'][^>]*>([\s\S]*?)<\/span>/gi,(r,a,c)=>{const u=c.replace(/<[^>]+>/g,"").trim();return u?`((${a} '${u}'))`:`((${a}))`}),e=e.replace(/<span\b[^>]*data-type=["']a["'][^>]*data-href=["']([^"']+)["'][^>]*>([\s\S]*?)<\/span>/gi,(r,a,c)=>`[${c.replace(/<[^>]+>/g,"").trim()}](${a})`),e=e.replace(/<\/(?:div|section|header|footer|main|article|nav|aside)\b[^>]*>/gi,`
`),e=e.replace(/<(?:div|section|header|footer|main|article|nav|aside)\b[^>]*>/gi,""),e=e.replace(/<\/?span\b[^>]*>/gi,"");for(let r=0;r<l.length;r++)e=e.replace(`__VUE_COMP_TOKEN_${r}__`,l[r]);for(let r=0;r<s.length;r++)e=e.replace(`__VUE_DIV_TOKEN_${r}__`,s[r]);for(let r=0;r<n.length;r++)e=e.replace(`__SCRIPT_TOKEN_${r}__`,n[r]);for(let r=0;r<i.length;r++)e=e.replace(`__CODE_TOKEN_${r}__`,i[r]);return e=e.replace(/\n{3,}/g,`

`).trim(),e}function Xl(t){if(!t||typeof t!="string")return"";const i=[];let e=t.replace(/`([^`]+)`/g,n=>(i.push(n),`%%INLINE_CODE_${i.length-1}%%`));return e=e.replace(/(<\/[a-zA-Z0-9_-]+>)\s*\{:[^}]*\}/g,"$1"),e=e.replace(/(\[[^\]]+\]\([^)]+\))\s*\{:\s*style=["']([^"']*)["'][^}]*\}/g,'<span style="$2">$1</span>'),e=e.replace(/(\*\*[^*]+\*\*)\s*\{:\s*style=["']([^"']*)["'][^}]*\}/g,'<span style="$2">$1</span>'),e=e.replace(/(\*[^*]+\*)\s*\{:\s*style=["']([^"']*)["'][^}]*\}/g,'<span style="$2">$1</span>'),e=e.replace(/(~~[^~]+~~)\s*\{:\s*style=["']([^"']*)["'][^}]*\}/g,'<span style="$2">$1</span>'),e=e.replace(/([\p{L}\p{N}_\-]+)\s*\{:\s*style=["']([^"']*)["'][^}]*\}/gu,'<span style="$2">$1</span>'),e=e.replace(/\{:[^}]*\}/g,""),e=e.replace(/%%INLINE_CODE_(\d+)%%/g,(n,o)=>i[parseInt(o,10)]||""),e}function Hu(t){const i=Object.entries(t).filter(([n,o])=>o!=null&&o!=="");return i.length===0?"":`---
${i.map(([n,o])=>typeof o=="string"?o.includes(":")||o.includes(`
`)||o.includes("#")?`${n}: "${o.replace(/"/g,'\\"')}"`:`${n}: ${o}`:`${n}: ${JSON.stringify(o)}`).join(`
`)}
---`}function ju(t,i){if(!i||!t.startsWith("```"))return t;const e=t.indexOf(`
`);if(e===-1)return t;const n=t.slice(0,e).trim(),o=t.slice(e);return n.includes("{")?t:`${n} {${i}}${o}`}function Uu(t,i){if(i==null)return t;const e=i.trim();return e===""||e==="+1"?`<v-click>

${t}

</v-click>`:e==="hide"?`<v-click hide>

${t}

</v-click>`:`<v-click at="${e}">

${t}

</v-click>`}function Wu(t){if(!t||!t.preset)return null;const i=t.preset.toLowerCase().trim();if(!i||i==="none")return null;let e={opacity:0},n={opacity:1};switch(i){case"slide-up":e={y:40,opacity:0},n={y:0,opacity:1};break;case"slide-down":e={y:-40,opacity:0},n={y:0,opacity:1};break;case"slide-left":e={x:40,opacity:0},n={x:0,opacity:1};break;case"slide-right":e={x:-40,opacity:0},n={x:0,opacity:1};break;case"zoom-in":case"pop":e={scale:.8,opacity:0},n={scale:1,opacity:1};break;case"bounce":e={y:40,opacity:0},n={y:0,opacity:1,transition:{type:"spring",damping:10,stiffness:100}};break;case"fade-in":default:e={opacity:0},n={opacity:1};break}t.initial&&typeof t.initial=="object"&&(e={...e,...t.initial}),t.enter&&typeof t.enter=="object"&&(n={...n,...t.enter});const o={...n.transition||{}};return typeof t.duration=="number"&&t.duration>0&&(o.duration=t.duration),typeof t.delay=="number"&&t.delay>0&&(o.delay=t.delay),Object.keys(o).length>0&&(n.transition=o),{initial:e,enter:n}}function $r(t,i,e,n){const o=i!=null&&i.trim()!=="",s=Wu(e),l=n==null?void 0:n.trim(),r=l!==void 0&&l!=="",a=r?` style="${l.replace(/"/g,"&quot;")}" class="slide-styled-block"`:"";if(!o&&!s)return r?`<div${a}>

${t}

</div>`:t;if(o&&!s){if(r){const b=i.trim();let f="v-click";return b==="hide"?f="v-click.hide":b!==""&&b!=="+1"&&(f=`v-click="${b}"`),`<div ${f}${a}>

${t}

</div>`}return Uu(t,i)}const c=JSON.stringify(s.initial).replace(/"/g,"'"),u=JSON.stringify(s.enter).replace(/"/g,"'"),m=`v-motion :initial="${c}" :enter="${u}"`;if(!o)return`<div ${m}${a}>

${t}

</div>`;const v=i.trim();let d="v-click";return v==="hide"?d="v-click.hide":v!==""&&v!=="+1"&&(d=`v-click="${v}"`),`<div ${d} ${m}${a}>

${t}

</div>`}function Ql(t){if(!t)return"";let i=t.trim();i=i.replace(/\{:[^}]*\}/g,"").trim(),i=i.replace(/^:::\s*[a-zA-Z0-9_-]*\s*\r?\n?/g,""),i=i.replace(/\r?\n?:::\s*$/g,"");let o=i.split(/\r?\n/).map(s=>s.trim().replace(/^>\s*/,"")).join(`
`).trim();return o=o.replace(/^\[!(?:NOTE|TIP|IMPORTANT|WARNING|CAUTION|[A-Za-z_-]+)\][^\r\n]*(?:\r?\n)?/i,"").trim(),o=o.replace(/^(?:💡|✏️|❗|⚠️|🚨|\s*)*(?:\*\*|__)?(?:演讲备注|演讲者提词|讲稿备注|演讲提词|备注|Notes?)(?:\*\*|__)?[:：]?\s*(?:\r?\n)?/i,"").trim(),o=o.replace(/^[-*+]\s+/,""),o=o.replace(/^\d+\.\s+/,""),o.trim()}function Vu(t){var n;if(t.subType&&/^h([1-6])$/i.test(t.subType))return parseInt(t.subType.slice(1),10);const e=(t.markdown||t.content||"").trim().match(/^(#{1,6})\s+/);return e?e[1].length:t.type==="h"?(n=t.ial)!=null&&n.subType&&/^h([1-6])$/i.test(t.ial.subType)?parseInt(t.ial.subType.slice(1),10):1:null}function ta(t,i=2){const e=Math.max(2,i);if(!t||t.length===0)return Array.from({length:e},()=>[]);if(t.length===1&&t[0].children&&t[0].children.length>=2){const c=t[0].children,u=Array.from({length:e},()=>[]),m=Math.min(e,c.length),v=Math.floor(c.length/m),d=c.length%m;let b=0;for(let f=0;f<m;f++){const y=v+(f<d?1:0);u[f]=c.slice(b,b+y),b+=y}return u}const n=c=>{const u=(c.slot||"").trim();if(!u)return null;if(u==="left")return 1;if(u==="center")return 2;if(u==="right")return e===2?2:e;const m=u.match(/^col-(\d+)$/i);if(m){const v=parseInt(m[1],10);if(v>=1&&v<=e)return v}return null},o=t.map(n);if(o.some(c=>c!==null)){if(o.some(d=>d!==null&&d>=2)){const d=Array.from({length:e},()=>[]);let b=1;for(const f of t){const y=n(f);y!==null&&(b=y),d[b-1].push(f)}return d}const u=t.filter(d=>n(d)===1),m=t.filter(d=>n(d)===null),v=e-1;if(m.length>=v){const d=Math.floor(m.length/v),b=m.length%v,f=[u];let y=0;for(let k=0;k<v;k++){const x=d+(k<b?1:0);f.push(m.slice(y,y+x)),y+=x}return f}else if(m.length>0){const d=[u];for(let b=0;b<v;b++)d.push(b<m.length?[m[b]]:[]);return d}else return[u,...Array.from({length:v},()=>[])]}const l=c=>{if(c.type==="h"||c.subType&&/^h[1-6]$/i.test(c.subType))return!0;const u=(c.rawMarkdown||c.content||"").trim();return/^#{1,6}\s+/.test(u)},r=t.map((c,u)=>l(c)?u:-1).filter(c=>c!==-1);if(r.length>=e){const c=Array.from({length:e},()=>[]);for(let u=0;u<e;u++){const m=r[u],v=u+1<e?r[u+1]:t.length;c[u]=t.slice(m,v)}return c}if(t.length>=e){const c=Array.from({length:e},()=>[]);let u=0;for(let m=0;m<e;m++){const v=e-m,d=t.length-u,b=Math.ceil(d/v);c[m]=t.slice(u,u+b),u+=b}return c}if(t.length>1&&t.length<e){const c=Array.from({length:e},()=>[]);for(let u=0;u<t.length;u++)c[u]=[t[u]];return c}if(t.length===1){const c=t[0],u=(c.rawMarkdown||c.content||"").trim(),m=u.split(/\r?\n/),v=[];for(let f=0;f<m.length;f++)/^[ \t]*[-*+]\s+|^[ \t]*\d+\.\s+/.test(m[f])&&v.push(f);if(v.length>=e){const f=Array.from({length:e},()=>[]);let y=0;for(let k=0;k<e;k++){const x=e-k,C=v.length-y,A=Math.ceil(C/x),B=v[y],I=y+A<v.length?v[y+A]:m.length,w=m.slice(B,I).join(`
`);f[k]=[{...c,id:k===0?c.id:`${c.id}-col${k+1}`,rawMarkdown:w,content:w}],y+=A}return f}const d=u.match(/<li[\s\S]*?<\/li>/gi);if(d&&d.length>=e){const f=Array.from({length:e},()=>[]);let y=0;for(let k=0;k<e;k++){const x=e-k,C=d.length-y,A=Math.ceil(C/x),B=`<ul>
${d.slice(y,y+A).join(`
`)}
</ul>`;f[k]=[{...c,id:k===0?c.id:`${c.id}-col${k+1}`,rawMarkdown:B,content:B}],y+=A}return f}const b=u.split(/\r?\n\s*\r?\n/).filter(f=>f.trim()!=="");if(b.length>=e){const f=Array.from({length:e},()=>[]);let y=0;for(let k=0;k<e;k++){const x=e-k,C=b.length-y,A=Math.ceil(C/x),B=b.slice(y,y+A).join(`

`);f[k]=[{...c,id:k===0?c.id:`${c.id}-col${k+1}`,rawMarkdown:B,content:B}],y+=A}return f}}const a=Array.from({length:e},()=>[]);return a[0]=t,a}function Ir(t,i,e,n){var u;const o=Eu(i),s=[],l=Cr(i);let r={pageIndex:1,startBlockId:t,frontmatter:{layout:l.frontmatter.layout||"cover",...l.frontmatter},notes:"",noteBlocks:[],blocks:[],rawMarkdown:"",allBlockIds:[t]};r.frontmatter.background&&(r.frontmatter.background=$e(r.frontmatter.background,n)),r.frontmatter.image&&(r.frontmatter.image=$e(r.frontmatter.image,n)),s.push(r);let a=[];for(const m of e){if(go(m)){a=[];const d=Cr(m.ial);if(s.length===1&&r.blocks.length===0){r.startBlockId=m.id,r.allBlockIds||(r.allBlockIds=[]),r.allBlockIds.includes(m.id)||r.allBlockIds.push(m.id),d.frontmatter.layout&&(r.frontmatter.layout=d.frontmatter.layout),Object.assign(r.frontmatter,d.frontmatter),!d.frontmatter.image&&l.frontmatter.image&&(r.frontmatter.image=l.frontmatter.image),!d.frontmatter.background&&l.frontmatter.background&&(r.frontmatter.background=l.frontmatter.background),r.frontmatter.background&&(r.frontmatter.background=$e(r.frontmatter.background,n)),r.frontmatter.image&&(r.frontmatter.image=$e(r.frontmatter.image,n));continue}r={pageIndex:s.length+1,startBlockId:m.id,frontmatter:{layout:d.frontmatter.layout||"default",...d.frontmatter},notes:"",noteBlocks:[],blocks:[],rawMarkdown:"",allBlockIds:[m.id]},r.frontmatter.background&&(r.frontmatter.background=$e(r.frontmatter.background,n)),r.frontmatter.image&&(r.frontmatter.image=$e(r.frontmatter.image,n)),s.push(r);continue}const v=d=>{var H;if(r.allBlockIds||(r.allBlockIds=[]),d.id&&!r.allBlockIds.includes(d.id)&&r.allBlockIds.push(d.id),d.children&&d.children.length>0){const g=N=>{for(const q of N)q.id&&!r.allBlockIds.includes(q.id)&&r.allBlockIds.push(q.id),q.children&&q.children.length>0&&g(q.children)};g(d.children)}let b=Qa(d),f=d.ial?{...d.ial}:{};const y=b.match(/\{:\s*([^}]+)\s*\}\s*$/);y&&(f={...tc(y[0]),...f},b=b.slice(0,y.index).trim()),d.type!=="c"&&!b.startsWith("```")&&(b=Xl(b));let k=b.trim();if(/^\{\{\{(?:row|col)?\s*$/i.test(k)||k==="}}}")return;/^\{\{\{(?:row|col)?\s*\r?\n/i.test(k)&&/\r?\n\}\}\}$/.test(k)&&(b=k.replace(/^\{\{\{(?:row|col)?\s*\r?\n/i,"").replace(/\r?\n\}\}\}$/,"").trim(),k=b.trim());const x=Mu(f);if(b=nc(b,n),b=Xa(b,n==null?void 0:n.refContentMap),d.children&&d.children.length>0){const g=N=>{for(const q of N){if(q.ial)for(const[U,G]of Object.entries(q.ial))U.startsWith("custom-slidev-")&&!f[U]&&(f[U]=G);q.children&&q.children.length>0&&g(q.children)}};g(d.children)}const C=d.type==="video"||d.type==="NodeVideo"||/<video\b/i.test(b);if(C){const g=f["custom-slidev-autoplay"]==="true",N=f["custom-slidev-loop"]==="true",q=f["custom-slidev-muted"]==="true"||g,U=f["custom-slidev-controls"]==="false";b=b.replace(/<video\b([^>]*)>/gi,(G,Z)=>{let O=Z;return U?O=O.replace(/\bcontrols(?:="[^"]*")?/gi,"").trim():/controls/i.test(O)||(O+=" controls"),g&&!/autoplay/i.test(O)?O+=" autoplay playsinline":!g&&f["custom-slidev-autoplay"]==="false"&&(O=O.replace(/\bautoplay\b/gi,"").replace(/\bplaysinline\b/gi,"").trim()),N&&!/loop/i.test(O)?O+=" loop":!N&&f["custom-slidev-loop"]==="false"&&(O=O.replace(/\bloop\b/gi,"").trim()),q&&!/muted/i.test(O)?O+=" muted":!q&&f["custom-slidev-muted"]==="false"&&(O=O.replace(/\bmuted\b/gi,"").trim()),`<video ${O.trim()}>`})}if(x.isBackground){const g=vi(b,d.content);if(g){r.frontmatter.background=$e(g,n);return}}const A=yi(d);if(A){r.frontmatter.layout=A.layout,r.frontmatter.image=$e(A.imageUrl,n),!r.frontmatter.layoutRatio&&A.ratio&&(r.frontmatter.layoutRatio=A.ratio);for(const g of A.contentNodes)v(g);return}if(x.imageLayout==="image-left"||x.imageLayout==="image-right"){const g=vi(b,d.content);if(g){r.frontmatter.layout=x.imageLayout,r.frontmatter.image=$e(g,n),!r.frontmatter.layoutRatio&&((H=d.ial)!=null&&H[oe])&&(r.frontmatter.layoutRatio=d.ial[oe]);return}}if(se(d)&&d.children&&d.children.length>0){for(const g of d.children)v(g);return}if((d.type==="l"||d.type==="NodeList"||d.type==="list")&&d.children&&d.children.length>0&&(d.children.some(g=>{var N;return(N=g.ial)==null?void 0:N[Bt]})||x.slot)){for(const g of d.children)x.slot&&(!g.ial||!g.ial[Bt])&&(g.ial||(g.ial={}),g.ial[Bt]=x.slot),v(g);return}if(x.isNote){const g=Ql(b);g&&(r.notes?r.notes+=`

`+g:r.notes=g),r.noteBlocks||(r.noteBlocks=[]),r.noteBlocks.push({id:d.id,type:d.type,content:g||d.content||"",rawMarkdown:b,isNote:!0,attributes:d.ial});return}x.shikiLines&&(b=ju(b,x.shikiLines)),k=b.trim();const B=(d.content||"").trim();if(k==="::right::"||B==="::right::"||/^<p>\s*::right::\s*<\/p>$/i.test(k)||k.startsWith("::right::")){r.blocks.push({id:d.id,type:d.type,content:"::right::",rawMarkdown:"::right::",slot:"slot-divider-right",attributes:d.ial});return}const w=Vu(d);let D=x.slot,P=x.clicks,R=x.motion,J={...d.ial||{}};if(w!==null){for(;a.length>0&&a[a.length-1].level>=w;)a.pop();const g=a.length>0?a[a.length-1]:void 0;!D&&(g!=null&&g.slot)&&(D=g.slot),!P&&(g!=null&&g.clicks)&&(P=g.clicks),!R&&(g!=null&&g.motion)&&(R=g.motion);const N={...(g==null?void 0:g.customAttrs)||{}};if(d.ial)for(const[q,U]of Object.entries(d.ial))q.startsWith("custom-slidev-")&&!q.startsWith("custom-slidev-slide")&&(N[q]=U);a.push({level:w,slot:D,clicks:P,motion:R,customAttrs:N})}else{const g=a.length>0?a[a.length-1]:void 0;g&&(!D&&g.slot&&g.slot!=="header"&&(D=g.slot),!P&&g.clicks&&(P=g.clicks),!R&&g.motion&&(R=g.motion),g.customAttrs&&(J={...g.customAttrs,...J}))}!D&&r.blocks.some(g=>g.slot==="slot-divider-right")&&(D="right"),D&&(J[Bt]=D),P&&!J[Ae]&&(J[Ae]=P),R&&!J[Ve]&&(J[Ve]=JSON.stringify(R)),(C||f["custom-slidev-autoplay"]||f["custom-slidev-muted"])&&(f["custom-slidev-autoplay"]&&(J["custom-slidev-autoplay"]=f["custom-slidev-autoplay"],f["custom-slidev-autoplay"]==="true"&&!f["custom-slidev-muted"]&&(J["custom-slidev-muted"]="true")),f["custom-slidev-loop"]&&(J["custom-slidev-loop"]=f["custom-slidev-loop"]),f["custom-slidev-muted"]&&(J["custom-slidev-muted"]=f["custom-slidev-muted"]),f["custom-slidev-controls"]&&(J["custom-slidev-controls"]=f["custom-slidev-controls"]));const S={id:d.id,type:d.type,content:d.content||"",rawMarkdown:b,clicks:P,motion:R,shikiLines:x.shikiLines,slot:D,attributes:J};r.blocks.push(S)};v(m)}for(let m=0;m<s.length;m++){const v=s[m],d=[],b={...v.frontmatter};m===0&&(b.theme=o.theme,b.aspectRatio=o.aspectRatio,b.highlighter=o.highlighter,b.transition=v.frontmatter.transition||o.defaultTransition);const f=Hu(b);f&&d.push(f);const y=v.blocks.filter(B=>B.slot!=="slot-divider-right"),k=B=>B.filter(I=>!!(I.rawMarkdown||I.content||"").trim()).map(I=>{var w;return $r(I.rawMarkdown,I.clicks,I.motion,(w=I.attributes)==null?void 0:w.style)}).join(`

`),x=B=>{const I=B.filter(R=>!!(R.rawMarkdown||R.content||"").trim());if(I.length===0)return;const w=I[0],D=(w.rawMarkdown||w.content||"").trim();(En(w)||/^(?:[-*+]|\d+\.)\s+/.test(D))&&(w.rawMarkdown=Yl(w.rawMarkdown||w.content||""),w.content=w.rawMarkdown)},C=B=>B.length===0?"":(x(B),k(B)),A=v.frontmatter.layout||"default";if(ps(A)){let B=[];const I=y.filter(S=>S.slot==="header");if(I.length>0)B=I;else if(y.length>0){const S=y.find(H=>H.type==="h"&&(!H.slot||H.slot==="default"));S&&(B=[S])}const w=y.filter(S=>!B.includes(S));let D=2;if(A==="three-cols-header")D=3;else if(A==="two-cols-header")D=2;else{let S=0;for(const H of w){const g=(H.slot||"").match(/^col-(\d+)$/i);g&&(S=Math.max(S,parseInt(g[1],10)))}if(S>=2)D=S;else if(v.frontmatter.layoutRatio){const H=v.frontmatter.layoutRatio.trim();if(H.includes(":")){const g=H.split(":").map(N=>parseFloat(N.trim())).filter(N=>!isNaN(N)&&N>0);g.length>=2&&(D=g.length)}else{const g=H.split(/\s+/).filter(Boolean);g.length>=2&&(D=g.length)}}else w.length===1&&w[0].children&&w[0].children.length>=2&&(D=Math.min(6,w[0].children.length))}const P=ta(w,D);P.forEach((S,H)=>{const g=`col-${H+1}`;for(const N of S)(!N.slot||N.slot==="default")&&(N.slot=g);x(S)});const R=P.flat();if(w.length===1&&R.length>1){const S=v.blocks.findIndex(H=>H.id===w[0].id);S!==-1&&v.blocks.splice(S,1,...R)}const J=k(B);if(J&&d.push(J),A==="two-cols-header"&&D===2){const S=C(P[0]||[]),H=C(P[1]||[]);S&&d.push(`::left::

${S}`),H&&d.push(`::right::

${H}`)}else P.forEach((S,H)=>{const g=C(S);g&&d.push(`::col-${H+1}::

${g}`)})}else if(A==="two-cols"){const B=y.filter(P=>P.slot==="left"),I=y.filter(P=>P.slot==="right");x(B),x(I);const w=k(B.length>0?B:y.filter(P=>P.slot!=="right")),D=k(I);d.push(w),D&&d.push(`::right::

${D}`)}else for(const B of y)d.push($r(B.rawMarkdown,B.clicks,B.motion,(u=B.attributes)==null?void 0:u.style));v.notes&&d.push(`<!--
${v.notes}
-->`),v.rawMarkdown=d.join(`

`).trim()}const c=s.map(m=>m.rawMarkdown).filter(Boolean).join(`

---

`);return{docId:t,config:o,slides:s,fullMarkdown:c}}const ds=`/* SiYuan Note Built-in Font & Background Styles for Slidev */
:root,
html:not(.dark),
[data-theme="light"],
[data-theme-mode="light"] {
  /* 思源基础卡片与主题色 (浅色模式 daylight) */
  --b3-card-error-color: #790600;
  --b3-card-error-background: #f5d1cf;
  --b3-card-warning-color: #8a4f00;
  --b3-card-warning-background: #ffe8c8;
  --b3-card-info-color: #005599;
  --b3-card-info-background: #d6eaf9;
  --b3-card-success-color: #006b04;
  --b3-card-success-background: #d7eed8;

  --b3-theme-primary: #3575f0;
  --b3-theme-secondary: #ff9200;
  --b3-theme-error: #d23f31;
  --b3-theme-background: #ffffff;
  --b3-theme-on-background: #222222;
  --b3-theme-on-surface: #5f6368;
  --b3-theme-surface-lighter: #e0e0e0;

  /* 13 种内置文字颜色 */
  --b3-font-color1: var(--b3-card-error-color);
  --b3-font-color2: var(--b3-card-warning-color);
  --b3-font-color3: var(--b3-card-info-color);
  --b3-font-color4: var(--b3-card-success-color);
  --b3-font-color5: var(--b3-theme-on-surface);
  --b3-font-color6: var(--b3-theme-primary);
  --b3-font-color7: var(--b3-theme-secondary);
  --b3-font-color8: var(--b3-theme-error);
  --b3-font-color9: #a40074;
  --b3-font-color10: #007080;
  --b3-font-color11: #006e2a;
  --b3-font-color12: #6b5a00;
  --b3-font-color13: var(--b3-theme-background);

  /* 13 种内置背景颜色 */
  --b3-font-background1: var(--b3-card-error-background);
  --b3-font-background2: var(--b3-card-warning-background);
  --b3-font-background3: var(--b3-card-info-background);
  --b3-font-background4: var(--b3-card-success-background);
  --b3-font-background5: #e2e3e4;
  --b3-font-background6: #acd0fc;
  --b3-font-background7: #fddaab;
  --b3-font-background8: #ffb0a9;
  --b3-font-background9: #fdbfff;
  --b3-font-background10: #b1ffff;
  --b3-font-background11: #affad1;
  --b3-font-background12: #fff88f;
  --b3-font-background13: var(--b3-theme-on-background);
}

html.dark,
[data-theme="dark"],
[data-theme-mode="dark"],
.theme-dark,
.dark {
  /* 思源基础卡片与主题色 (深色模式 midnight) */
  --b3-card-error-color: rgb(243, 153, 147);
  --b3-card-error-background: #442724;
  --b3-card-warning-color: rgb(255, 213, 153);
  --b3-card-warning-background: #554636;
  --b3-card-info-color: rgb(166, 213, 250);
  --b3-card-info-background: #28405c;
  --b3-card-success-color: rgb(183, 223, 185);
  --b3-card-success-background: #425347;

  --b3-theme-primary: #3575f0;
  --b3-theme-secondary: #ff9200;
  --b3-theme-error: #d23f31;
  --b3-theme-background: #1e1e1e;
  --b3-theme-on-background: #c8ccd6;
  --b3-theme-on-surface: #8b949e;
  --b3-theme-surface-lighter: #282a2e;

  /* 13 种内置文字颜色 */
  --b3-font-color1: var(--b3-card-error-color);
  --b3-font-color2: var(--b3-card-warning-color);
  --b3-font-color3: var(--b3-card-info-color);
  --b3-font-color4: var(--b3-card-success-color);
  --b3-font-color5: var(--b3-theme-on-surface);
  --b3-font-color6: var(--b3-theme-primary);
  --b3-font-color7: var(--b3-theme-secondary);
  --b3-font-color8: var(--b3-theme-error);
  --b3-font-color9: #f47c9c;
  --b3-font-color10: #4dd0e1;
  --b3-font-color11: #10df54;
  --b3-font-color12: #ecd424;
  --b3-font-color13: var(--b3-theme-background);

  /* 13 种内置背景颜色 */
  --b3-font-background1: var(--b3-card-error-background);
  --b3-font-background2: var(--b3-card-warning-background);
  --b3-font-background3: var(--b3-card-info-background);
  --b3-font-background4: var(--b3-card-success-background);
  --b3-font-background5: #3a3f42;
  --b3-font-background6: #031840;
  --b3-font-background7: #593905;
  --b3-font-background8: #3a0c09;
  --b3-font-background9: #4d1b40;
  --b3-font-background10: #1a5459;
  --b3-font-background11: #305415;
  --b3-font-background12: #4a4712;
  --b3-font-background13: var(--b3-theme-on-background);
}

@media (prefers-color-scheme: dark) {
  :root:not([data-theme="light"]):not([data-theme-mode="light"]):not(.light) {
    --b3-card-error-color: rgb(243, 153, 147);
    --b3-card-error-background: #442724;
    --b3-card-warning-color: rgb(255, 213, 153);
    --b3-card-warning-background: #554636;
    --b3-card-info-color: rgb(166, 213, 250);
    --b3-card-info-background: #28405c;
    --b3-card-success-color: rgb(183, 223, 185);
    --b3-card-success-background: #425347;

    --b3-theme-primary: #3575f0;
    --b3-theme-secondary: #ff9200;
    --b3-theme-error: #d23f31;
    --b3-theme-background: #1e1e1e;
    --b3-theme-on-background: #c8ccd6;
    --b3-theme-on-surface: #8b949e;
    --b3-theme-surface-lighter: #282a2e;

    --b3-font-color1: var(--b3-card-error-color);
    --b3-font-color2: var(--b3-card-warning-color);
    --b3-font-color3: var(--b3-card-info-color);
    --b3-font-color4: var(--b3-card-success-color);
    --b3-font-color5: var(--b3-theme-on-surface);
    --b3-font-color6: var(--b3-theme-primary);
    --b3-font-color7: var(--b3-theme-secondary);
    --b3-font-color8: var(--b3-theme-error);
    --b3-font-color9: #f47c9c;
    --b3-font-color10: #4dd0e1;
    --b3-font-color11: #10df54;
    --b3-font-color12: #ecd424;
    --b3-font-color13: var(--b3-theme-background);

    --b3-font-background1: var(--b3-card-error-background);
    --b3-font-background2: var(--b3-card-warning-background);
    --b3-font-background3: var(--b3-card-info-background);
    --b3-font-background4: var(--b3-card-success-background);
    --b3-font-background5: #3a3f42;
    --b3-font-background6: #031840;
    --b3-font-background7: #593905;
    --b3-font-background8: #3a0c09;
    --b3-font-background9: #4d1b40;
    --b3-font-background10: #1a5459;
    --b3-font-background11: #305415;
    --b3-font-background12: #4a4712;
    --b3-font-background13: var(--b3-theme-on-background);
  }
}

/* 演示块级样式排版增强 (带背景色时赋予呼吸内边距与舒适圆角) */
.slide-styled-block {
  border-radius: 6px;
  padding: 8px 14px;
  box-sizing: border-box;
  margin: 6px 0;
  transition: background-color 0.2s ease, color 0.2s ease;
}

/* 行内带背景色文本的精美圆角与微边距 */
span[style*="background-color"],
span[style*="background:"] {
  border-radius: 3px;
  padding: 1px 5px;
  box-decoration-break: clone;
  -webkit-box-decoration-break: clone;
}
`;function qu(t){var o,s,l,r,a,c,u,m,v,d,b,f;if(!t||typeof t!="object")return"";const i=[],e=[];if(Array.isArray(t.styles))for(const y of t.styles){if(!y||!y.id)continue;const k=`--b3-inline-style-${y.id}`;(o=y.light)!=null&&o.color&&i.push(`  ${k}-color: ${y.light.color};`),(s=y.light)!=null&&s.backgroundColor&&i.push(`  ${k}-background-color: ${y.light.backgroundColor};`),(l=y.dark)!=null&&l.color&&e.push(`  ${k}-color: ${y.dark.color};`),(r=y.dark)!=null&&r.backgroundColor&&e.push(`  ${k}-background-color: ${y.dark.backgroundColor};`)}if(t.builtin&&Array.isArray(t.builtin.colors))for(const y of t.builtin.colors){if(!y||typeof y.index!="number")continue;const k=y.index;(a=y.light)!=null&&a.color&&i.push(`  --b3-font-color${k}: ${y.light.color};`),(c=y.light)!=null&&c.backgroundColor&&i.push(`  --b3-font-background${k}: ${y.light.backgroundColor};`),(u=y.dark)!=null&&u.color&&e.push(`  --b3-font-color${k}: ${y.dark.color};`),(m=y.dark)!=null&&m.backgroundColor&&e.push(`  --b3-font-background${k}: ${y.dark.backgroundColor};`)}if(t.builtin&&Array.isArray(t.builtin.styles))for(const y of t.builtin.styles){if(!y||!y.id)continue;const k=y.id;(v=y.light)!=null&&v.color&&i.push(`  --b3-card-${k}-color: ${y.light.color};`),(d=y.light)!=null&&d.backgroundColor&&i.push(`  --b3-card-${k}-background: ${y.light.backgroundColor};`),(b=y.dark)!=null&&b.color&&e.push(`  --b3-card-${k}-color: ${y.dark.color};`),(f=y.dark)!=null&&f.backgroundColor&&e.push(`  --b3-card-${k}-background: ${y.dark.backgroundColor};`)}if(i.length===0&&e.length===0)return"";const n=[];return i.length>0&&n.push(`:root, html:not(.dark), [data-theme="light"] {
${i.join(`
`)}
}`),e.length>0&&n.push(`html.dark, [data-theme="dark"], .dark {
${e.join(`
`)}
}`),n.join(`

`)}function bn(t){const i=qu(t);return i?`${ds}

/* Custom Workspace Inline Styles */
${i}`:ds}function Vo(t){const i={};if(!t||typeof t!="string")return i;const e=t.replace(/^\{:\s*/,"").replace(/\s*\}$/,""),n=/([\w-]+)=(?:"([^"]*)"|'([^']*)'|(\S+))/g;let o;for(;(o=n.exec(e))!==null;){const s=o[1],l=o[2]??o[3]??o[4]??"";i[s]=l}return i}const Ku={getBlockAttrs:Ze,getChildBlocks:eo,setBlockAttrs:Lt,sql:yn,getBaseUrl:()=>typeof location<"u"?location.origin:"",getInlineStyles:Ya};class Gu{constructor(i){wt(this,"deps");wt(this,"attrOverrides",new Map);wt(this,"trackedListSuperBlocks",new Map);this.deps={...Ku,...i||{}}}setBlockAttrOverride(i,e){if(!i||!e)return;const o={...this.attrOverrides.get(i)||{}};for(const[s,l]of Object.entries(e))l===""||l===null||l===void 0?delete o[s]:o[s]=String(l);Object.keys(o).length===0?this.attrOverrides.delete(i):this.attrOverrides.set(i,o)}getBlockAttrOverride(i){return this.attrOverrides.get(i)}getAllAttrOverrides(){return new Map(this.attrOverrides)}getTrackedListSuperBlocks(i){return this.trackedListSuperBlocks.get(i)||[]}clearBlockAttrOverride(i,e){if(!i)return;if(!e){this.attrOverrides.delete(i);return}const n=this.attrOverrides.get(i);n&&(delete n[e],Object.keys(n).length===0&&this.attrOverrides.delete(i))}clearAllOverrides(){this.attrOverrides.clear(),this.trackedListSuperBlocks.clear()}async compile(i){try{const e=await this.deps.getBlockAttrs(i).catch(()=>({}))||{},n=this.attrOverrides.get(i);n&&Object.assign(e,n);let o=await this.deps.getChildBlocks(i).catch(()=>[]);const s=`SELECT id, ial FROM blocks WHERE root_id = '${i}' LIMIT 99999`,l=await this.deps.sql(s).catch(()=>[])||[],r=new Map;if(Array.isArray(l))for(const C of l)C.id&&C.ial&&r.set(C.id,Vo(C.ial));const a=`SELECT block_id, name, value FROM attributes WHERE root_id = '${i}' AND type = 'b' LIMIT 99999`,c=await this.deps.sql(a).catch(()=>[])||[];if(Array.isArray(c)){for(const C of c)if(C.block_id&&C.name){let A=r.get(C.block_id);A||(A={},r.set(C.block_id,A)),A[C.name]=C.value||""}}if(!o||o.length===0){const C=`SELECT id, parent_id, root_id, type, sub_type as subType, content, markdown, ial FROM blocks WHERE root_id = '${i}' AND id != '${i}' ORDER BY created ASC LIMIT 99999`;o=await this.deps.sql(C).catch(()=>[])||[]}const u=(o||[]).map(C=>{const A=r.get(C.id)||(C.ial?Vo(C.ial):{}),B=this.attrOverrides.get(C.id);return B&&Object.assign(A,B),{id:C.id,parent_id:C.parent_id,root_id:C.root_id||i,type:C.type,subType:C.subType,content:C.content||"",markdown:C.markdown||"",ial:A,children:C.children}}),m=async(C,A=0)=>{if(!(!C||C.length===0||A>8))for(const B of C){if((se(B)||B.type==="l"||B.type==="NodeList"||B.type==="i"||B.type==="NodeListItem"||B.type==="b"||B.type==="NodeBlockquote")&&(!B.children||B.children.length===0)){let w=await this.deps.getChildBlocks(B.id).catch(()=>[]);if(!w||w.length===0){const D=`SELECT id, parent_id, root_id, type, sub_type as subType, content, markdown, ial FROM blocks WHERE parent_id = '${B.id}' ORDER BY sort ASC, created ASC`;w=await this.deps.sql(D).catch(()=>[])||[]}Array.isArray(w)&&w.length>0&&(B.children=w.map(D=>{const P=r.get(D.id)||(D.ial?Vo(D.ial):{}),R=this.attrOverrides.get(D.id);return R&&Object.assign(P,R),{id:D.id,parent_id:D.parent_id||B.id,root_id:D.root_id||i,type:D.type,subType:D.subType,content:D.content||"",markdown:D.markdown||"",ial:P}}))}B.children&&B.children.length>0&&await m(B.children,A+1)}};await m(u);const v=C=>{var A,B;for(const I of C)if(I.children&&I.children.length>0){v(I.children);for(const w of I.children)if(w.ial)for(const[D,P]of Object.entries(w.ial))D.startsWith("custom-slidev-")&&!((A=I.ial)!=null&&A[D])&&(I.ial||(I.ial={}),I.ial[D]=P);if(I.ial){for(const[w,D]of Object.entries(I.ial))if(w.startsWith("custom-slidev-"))for(const P of I.children)(P.type==="video"||P.type==="NodeVideo"||/<video\b/i.test(P.markdown||P.content||""))&&!((B=P.ial)!=null&&B[w])&&(P.ial||(P.ial={}),P.ial[w]=D)}}};v(u),Ou(u,C=>{const A={[mt]:C.layout};this.setBlockAttrOverride(C.blockId,A),(this.deps.setBlockAttrs||Lt)(C.blockId,A).catch(I=>{console.warn("[DocumentCompiler] Failed to auto-tag superblock image layout:",I)})});const d=this.trackedListSuperBlocks.get(i)||[],b=Ru(i,u,{tracked:d,onTagChange:C=>{this.setBlockAttrOverride(C.blockId,C.attrs),C.blockId===i&&Object.assign(e,C.attrs);const A=I=>{for(const w of I)w.id===C.blockId&&(w.ial||(w.ial={}),Object.assign(w.ial,C.attrs)),w.children&&w.children.length>0&&A(w.children)};A(u),(this.deps.setBlockAttrs||Lt)(C.blockId,C.attrs).catch(I=>{console.warn("[DocumentCompiler] Failed to auto-tag list superblock attrs:",I)})}});this.trackedListSuperBlocks.set(i,b.newTracked);const f=new Set;for(const C of u){const A=C.markdown||C.content||"";if(A.includes("((")){const B=Ja(A);for(const I of B)f.add(I.blockId)}}const y={};if(f.size>0){const C=Array.from(f).map(B=>`'${B}'`).join(","),A=await this.deps.sql(`SELECT id, content, markdown FROM blocks WHERE id IN (${C})`).catch(()=>[])||[];if(Array.isArray(A))for(const B of A)B.id&&(y[B.id]=B.markdown||B.content||"")}const k=this.deps.getBaseUrl?this.deps.getBaseUrl():"",x=Ir(i,e,u,{baseUrl:k,refContentMap:y});try{const C=this.deps.getInlineStyles?await this.deps.getInlineStyles().catch(()=>null):null;x.customThemeCss=bn(C)}catch{x.customThemeCss=bn(null)}return x}catch(e){console.error("[DocumentCompilerService] Failed to compile document:",e);const n=Ir(i,{},[],{});return n.customThemeCss=bn(null),n}}}const Pt=new Gu;class Ls{constructor(i){wt(this,"devServerUrl","http://localhost:3030");wt(this,"isConnected",!1);wt(this,"lastSyncTime",null);i&&(this.devServerUrl=i)}getUrl(){return this.devServerUrl}setUrl(i){this.devServerUrl=i.replace(/\/+$/,"")}isServerConnected(){return this.isConnected}getLastSyncTime(){return this.lastSyncTime}async probeServer(i=1500){try{const e=new AbortController,n=setTimeout(()=>e.abort(),i),o=await fetch(this.devServerUrl,{method:"HEAD",mode:"no-cors",signal:e.signal}).catch(()=>null);return clearTimeout(n),this.isConnected=!!o,this.isConnected}catch{return this.isConnected=!1,!1}}buildStandardSlidevMarkdown(i){const e=i.config,n=["---",`theme: ${e.theme||"default"}`,`aspectRatio: "${e.aspectRatio||"16/9"}"`,`highlighter: ${e.highlighter||"shiki"}`,`transition: ${e.defaultTransition||"slide-left"}`];e.colorSchema&&e.colorSchema!=="auto"&&n.push(`colorSchema: ${e.colorSchema}`),n.push("drawings:","  persist: false","---","");const o=n.join(`
`),s=i.slides.map((l,r)=>{const a=l.frontmatter||{},c=[],u=r===0;a.layout&&a.layout!=="default"&&c.push(`layout: ${a.layout}`),a.transition&&c.push(`transition: ${a.transition}`),a.background&&c.push(`background: ${a.background}`),a.class&&c.push(`class: "${a.class}"`);let m="";c.length>0?m=u?"":`---
${c.join(`
`)}
---

`:u||(m=`---

`);let v="";if(a.layout==="two-cols"){const b=l.blocks.filter(x=>x.slot!=="right"),f=l.blocks.filter(x=>x.slot==="right"),y=b.map(x=>x.rawMarkdown||x.content||"").join(`

`),k=f.map(x=>x.rawMarkdown||x.content||"").join(`

`);v=`${y}

::right::

${k}`}else v=l.blocks.map(b=>b.rawMarkdown||b.content||"").join(`

`);let d="";return l.notes&&l.notes.trim()&&(d=`

<!--
${l.notes.trim()}
-->`),`${m}${v}${d}`}).join(`

`);return`${o}${s}
`}async syncToWorkspaceFile(i,e="/data/storage/petal/siyuan-slidev/slides.md",n){const o=this.buildStandardSlidevMarkdown(i);if(this.lastSyncTime=Date.now(),n)try{const s=typeof Blob<"u"?new Blob([o],{type:"text/markdown;charset=utf-8"}):Buffer.from(o,"utf-8");return await n(e,!1,s),{success:!0,path:e}}catch(s){return{success:!1,path:e,error:String(s)}}return{success:!0,path:e}}downloadSlidesMd(i,e="slides.md"){if(typeof window>"u"||typeof document>"u")return!1;const n=this.buildStandardSlidevMarkdown(i),o=new Blob([n],{type:"text/markdown;charset=utf-8"}),s=URL.createObjectURL(o),l=document.createElement("a");return l.href=s,l.download=e,document.body.appendChild(l),l.click(),document.body.removeChild(l),URL.revokeObjectURL(s),!0}}function Zu(){if(typeof window<"u"&&typeof window.require=="function")return window.require.bind(window);if(typeof globalThis<"u"&&typeof globalThis.require=="function")return globalThis.require.bind(globalThis);if(typeof require=="function")return require}function Ce(t){const i=Zu();if(i)try{return i(t)}catch{try{const e=t.startsWith("node:")?t.slice(5):`node:${t}`;return i(e)}catch{}}}function Ps(){var i;if(typeof window<"u"&&window.process)return window.process;const t=Ce("process");return t&&t.versions?t:typeof process<"u"&&((i=process.versions)!=null&&i.node)?process:globalThis.process}function ea(){var i,e;const t=Ps();if(t&&((i=t.versions)!=null&&i.node))return!0;if(typeof window<"u"&&window.siyuan){const n=Ce("child_process");if(n&&typeof n.spawn=="function")return!0}return!!(typeof process<"u"&&((e=process.versions)!=null&&e.node))}function Mn(){const t=Ps();if(t!=null&&t.platform)return t.platform;if(typeof process<"u"&&process.platform)return process.platform;const i=Ce("os");if(i&&typeof i.platform=="function")return i.platform();if(typeof navigator<"u"){const e=navigator.userAgent.toLowerCase();if(e.includes("win"))return"win32";if(e.includes("mac"))return"darwin";if(e.includes("linux"))return"linux"}return"web"}function ia(){var n,o;const t=Ps(),i={...(t==null?void 0:t.env)||{}};if(Mn()==="win32"){const s=["C:\\Program Files\\nodejs","C:\\Program Files (x86)\\nodejs",(n=t==null?void 0:t.env)!=null&&n.APPDATA?`${t.env.APPDATA}\\npm`:"",(o=t==null?void 0:t.env)!=null&&o.USERPROFILE?`${t.env.USERPROFILE}\\AppData\\Roaming\\npm`:""].filter(Boolean),l=Object.keys(i).find(c=>c.toLowerCase()==="path")||"PATH",a=(i[l]||"").split(";").filter(Boolean);for(const c of s)c&&!a.some(u=>u.toLowerCase()===c.toLowerCase())&&a.push(c);i[l]=a.join(";")}return i}function us(t){var e,n,o;if(!t)return"";if(/^[a-zA-Z]:[/\\]/.test(t))return t.replace(/\\/g,"/");let i="";if(typeof window<"u"&&((o=(n=(e=window.siyuan)==null?void 0:e.config)==null?void 0:n.system)!=null&&o.dataDir)&&(i=window.siyuan.config.system.dataDir.replace(/\\/g,"/")),i&&t.startsWith("/data/")){const s=t.slice(6);return`${i}/${s}`.replace(/\\/g,"/")}return t}function Yu(){const t=Ce("os"),i=Ce("path");if(t&&typeof t.tmpdir=="function"){const e=t.tmpdir();return i&&typeof i.join=="function"?i.join(e,"siyuan-slidev-pro").replace(/\\/g,"/"):`${e}/siyuan-slidev-pro`.replace(/\\/g,"/")}return"/data/storage/petal/siyuan-slidev/pro-workspace"}class Rs{constructor(i){wt(this,"runner");this.runner=i||Rs.defaultRunner}static async defaultRunner(i,e){var n;try{let o=(n=Ce("child_process"))==null?void 0:n.execFile;if(!o){const a=await import("node:child_process").catch(()=>({}));o=a==null?void 0:a.execFile}if(!o)return{code:-1,stdout:"",stderr:"child_process execFile not available"};const l=Mn()==="win32",r=ia();return await new Promise(a=>{o(i,e,{timeout:5e3,shell:l,env:r},(c,u,m)=>{a({code:c?c.code||1:0,stdout:u?String(u).trim():"",stderr:m?String(m).trim():""})})})}catch(o){return{code:-1,stdout:"",stderr:String(o)}}}async detect(){const i=ea(),e=Mn();if(!i)return{hasNode:!1,hasSlidevCli:!1,platform:"browser",isDesktop:!1,error:"当前处于纯前端浏览器或移动端环境，无 Node.js 运行时支撑"};let n=!1,o,s=!1,l;try{const r=await this.runner("node",["-v"]);r.code===0&&r.stdout.startsWith("v")&&(n=!0,o=r.stdout)}catch{}if(n){try{const r=e==="win32"?"slidev.cmd":"slidev",a=await this.runner(r,["--version"]);a.code===0&&a.stdout&&(s=!0,l=a.stdout)}catch{}if(!s)try{const r=e==="win32"?"npx.cmd":"npx",a=await this.runner(r,["@slidev/cli","--version"]);a.code===0&&a.stdout&&(s=!0,l=a.stdout)}catch{}}return{hasNode:n,nodeVersion:o,hasSlidevCli:s,slidevVersion:l,platform:e,isDesktop:i}}}class Ju{constructor(){wt(this,"iframe",null);wt(this,"isReady",!1);wt(this,"pageChangedHandlers",[]);wt(this,"readyHandlers",[]);wt(this,"currentState",{no:1,clicks:0,total:1});this.handleWindowMessage=this.handleWindowMessage.bind(this)}getCurrentState(){return{...this.currentState}}attach(i){this.detach(),this.iframe=i,this.isReady=!1,typeof window<"u"&&window.addEventListener("message",this.handleWindowMessage)}detach(){typeof window<"u"&&window.removeEventListener("message",this.handleWindowMessage),this.iframe=null,this.isReady=!1}postMessage(i,e){var o;if(!((o=this.iframe)!=null&&o.contentWindow))return;const n={target:"slidev",sender:"siyuan",type:i,...e};try{this.iframe.contentWindow.postMessage(n,"*")}catch(s){console.warn("[NativeSlidevBridge] postMessage error:",s)}}navigateToPage(i){this.postMessage("navigate",{no:i})}next(){this.postMessage("next")}prev(){this.postMessage("prev")}nextClick(){this.postMessage("next-click")}prevClick(){this.postMessage("prev-click")}onPageChanged(i){return this.pageChangedHandlers.push(i),()=>{this.pageChangedHandlers=this.pageChangedHandlers.filter(e=>e!==i)}}onReady(i){return this.readyHandlers.push(i),()=>{this.readyHandlers=this.readyHandlers.filter(e=>e!==i)}}handleWindowMessage(i){const e=i.data;if(!(!e||e.target!=="slidev")){if(!this.isReady){this.isReady=!0;for(const n of this.readyHandlers)n()}if(e.type==="update-state"&&e.navState){const n=e.navState;this.currentState={no:n.no??this.currentState.no,clicks:n.clicks??this.currentState.clicks,total:n.total??this.currentState.total,hasNext:n.hasNext,hasPrev:n.hasPrev};for(const o of this.pageChangedHandlers)o(this.currentState.no,this.currentState.total||1,this.currentState)}else if(e.type==="navigate"&&typeof e.no=="number"){this.currentState.no=e.no;for(const n of this.pageChangedHandlers)n(e.no,this.currentState.total||1,this.currentState)}}}}class Xu{constructor(i){wt(this,"childProcess",null);wt(this,"activePort",null);wt(this,"isRunning",!1);wt(this,"defaultPort");wt(this,"maxPortRetries");wt(this,"probeTimeoutMs");wt(this,"customSpawner");wt(this,"customPortChecker");this.defaultPort=(i==null?void 0:i.defaultPort)||3030,this.maxPortRetries=(i==null?void 0:i.maxPortRetries)||20,this.probeTimeoutMs=(i==null?void 0:i.probeTimeoutMs)||1e4,this.customSpawner=i==null?void 0:i.customSpawner,this.customPortChecker=i==null?void 0:i.customPortChecker}getActivePort(){return this.activePort}getIsRunning(){return this.isRunning}async isPortAvailable(i){if(this.customPortChecker)return this.customPortChecker(i);try{let e=Ce("net");return e||(e=await import("node:net").catch(()=>({}))),e!=null&&e.createServer?await new Promise(n=>{const o=e.createServer();o.once("error",()=>n(!1)),o.once("listening",()=>{o.close(()=>n(!0))}),o.listen(i,"127.0.0.1")}):!0}catch{return!0}}async allocPort(i){const e=i||this.defaultPort;for(let n=0;n<this.maxPortRetries;n++){const o=e+n;if(await this.isPortAvailable(o))return o}return e}async pollServerReady(i,e=8e3,n=300){const o=Date.now();for(;Date.now()-o<e;){try{const s=new AbortController,l=setTimeout(()=>s.abort(),n),r=await fetch(i,{method:"HEAD",mode:"no-cors",signal:s.signal}).catch(()=>null);if(clearTimeout(l),r)return!0}catch{}await new Promise(s=>setTimeout(s,n))}return!1}async startServer(i,e){var a,c;if(this.isRunning&&this.activePort)return{success:!0,port:this.activePort,url:`http://localhost:${this.activePort}?embedded=true`};const n=await this.allocPort(e);this.activePort=n;const s=Mn()==="win32"?"npx.cmd":"npx",l=us(i),r=["@slidev/cli",l,"--port",String(n),"--no-open"];try{if(this.customSpawner)this.childProcess=this.customSpawner(s,r,{detached:!1});else{let m=(a=Ce("child_process"))==null?void 0:a.spawn;if(!m){const b=await import("node:child_process").catch(()=>({}));m=b==null?void 0:b.spawn}if(!m)throw new Error("child_process spawn not available in current runtime");const v=l.includes("/")||l.includes("\\")?l.replace(/[/\\][^/\\]+$/,""):void 0,d=ia();this.childProcess=m(s,r,{cwd:v,detached:!1,shell:!0,env:{...d,FORCE_COLOR:"1"}})}this.isRunning=!0,(c=this.childProcess)!=null&&c.on&&this.childProcess.on("exit",()=>{this.isRunning=!1,this.activePort=null,this.childProcess=null});const u=`http://localhost:${n}`;return!this.customSpawner&&!await this.pollServerReady(u,this.probeTimeoutMs)?(this.stopServer(),{success:!1,port:n,url:"",error:`Slidev DevServer 启动超时 (未在 ${this.probeTimeoutMs}ms 内响应端口 ${n})`}):{success:!0,port:n,url:`${u}?embedded=true`}}catch(u){return this.stopServer(),{success:!1,port:n,url:"",error:`唤起 Slidev 进程失败: ${String(u)}`}}}stopServer(){var i;if(this.childProcess){try{if(this.childProcess.kill("SIGTERM"),Mn()==="win32"&&this.childProcess.pid&&!this.customSpawner){const n=(i=Ce("child_process"))==null?void 0:i.exec;n?n(`taskkill /pid ${this.childProcess.pid} /T /F`,()=>{}):import("node:child_process").then(({exec:o})=>{var s;o(`taskkill /pid ${(s=this.childProcess)==null?void 0:s.pid} /T /F`,()=>{})}).catch(()=>{})}}catch{}this.childProcess=null}this.isRunning=!1,this.activePort=null}}class Os{constructor(){wt(this,"iframe",null);wt(this,"isReady",!1);wt(this,"pendingMessages",[]);wt(this,"slideChangedHandlers",[]);wt(this,"blockClickedHandlers",[]);wt(this,"openInEditorHandlers",[]);wt(this,"clientReadyHandlers",[]);wt(this,"openPeekDrawerHandlers",[]);wt(this,"toggleFullscreenHandlers",[]);this.handleWindowMessage=this.handleWindowMessage.bind(this)}attach(i){this.detach(),this.iframe=i,this.isReady=!1,typeof window<"u"&&window.addEventListener("message",this.handleWindowMessage)}detach(){typeof window<"u"&&window.removeEventListener("message",this.handleWindowMessage),this.iframe=null,this.isReady=!1,this.pendingMessages=[]}postMessage(i,e){var o;const n={source:"siyuan-slidev-host",action:i,payload:e};if(!((o=this.iframe)!=null&&o.contentWindow)||!this.isReady){this.pendingMessages.push(n);return}try{this.iframe.contentWindow.postMessage(n,"*")}catch(s){console.warn("[WebSandboxBridge] postMessage error:",s)}}updateSlides(i,e,n,o){this.postMessage("UPDATE_SLIDES",{slides:i,config:e,fullMarkdown:n,customThemeCss:o})}navigatePage(i){this.postMessage("NAVIGATE_PAGE",{pageIndex:i})}highlightElement(i){this.postMessage("HIGHLIGHT_ELEMENT",{targetBlockId:i})}nextStep(){this.postMessage("NEXT_STEP",{})}prevStep(){this.postMessage("PREV_STEP",{})}freezeKeyboardNav(i){this.postMessage("FREEZE_KEYBOARD_NAV",{frozen:i})}onSlideChanged(i){return this.slideChangedHandlers.push(i),()=>{this.slideChangedHandlers=this.slideChangedHandlers.filter(e=>e!==i)}}onBlockClicked(i){return this.blockClickedHandlers.push(i),()=>{this.blockClickedHandlers=this.blockClickedHandlers.filter(e=>e!==i)}}onOpenInEditor(i){return this.openInEditorHandlers.push(i),()=>{this.openInEditorHandlers=this.openInEditorHandlers.filter(e=>e!==i)}}onOpenPeekDrawer(i){return this.openPeekDrawerHandlers.push(i),()=>{this.openPeekDrawerHandlers=this.openPeekDrawerHandlers.filter(e=>e!==i)}}onRequestToggleFullscreen(i){return this.toggleFullscreenHandlers.push(i),()=>{this.toggleFullscreenHandlers=this.toggleFullscreenHandlers.filter(e=>e!==i)}}onClientReady(i){return this.clientReadyHandlers.push(i),()=>{this.clientReadyHandlers=this.clientReadyHandlers.filter(e=>e!==i)}}handleWindowMessage(i){var n;const e=i.data;if(!(!e||e.source!=="siyuan-slidev-client"))switch(e.action){case"CLIENT_READY":for(this.isReady=!0;this.pendingMessages.length>0;){const o=this.pendingMessages.shift();o&&((n=this.iframe)!=null&&n.contentWindow)&&this.iframe.contentWindow.postMessage(o,"*")}for(const o of this.clientReadyHandlers)o();break;case"SLIDE_CHANGED":if(e.payload.currentPage!==void 0)for(const o of this.slideChangedHandlers)o(e.payload.currentPage,e.payload.totalPages||1,e.payload.currentBlockId||"");break;case"BLOCK_CLICKED":if(e.payload.clickedBlockId)for(const o of this.blockClickedHandlers)o(e.payload.clickedBlockId,e.payload.currentPage||1);break;case"OPEN_IN_EDITOR":if(e.payload.blockId||e.payload.clickedBlockId){const o=e.payload.blockId||e.payload.clickedBlockId||"";for(const s of this.openInEditorHandlers)s(o,e.payload.currentPage||1)}break;case"OPEN_PEEK_DRAWER":if(e.payload.peekType){const o=e.payload.blockId||e.payload.url||"",s={peekType:e.payload.peekType,target:o,title:e.payload.title};for(const l of this.openPeekDrawerHandlers)l(s)}break;case"REQUEST_TOGGLE_FULLSCREEN":for(const o of this.toggleFullscreenHandlers)o();break}}}const na={"snippets/external.ts":`// Inside ./snippets/external.ts
// #region snippet
export function emptyArray<T>(length: number) {
  return Array.from<T>({ length })
}
// #endregion snippet

export function sayHello() {
  console.log('Hello from snippets/external.ts')
}
`},Qu=`<script setup lang="ts">
import { computed, useSlots } from 'vue'

const props = defineProps({
  layoutRatio: {
    type: String,
    default: '',
  },
  cols: {
    type: [Number, String],
    default: 0,
  },
})

const slots = useSlots()

const detectedColsCount = computed(() => {
  const explicitCols = Number(props.cols)
  if (explicitCols >= 2 && explicitCols <= 6) return explicitCols
  const r = (props.layoutRatio || '').trim()
  if (r.includes(':')) {
    const parts = r.split(':').map(p => parseFloat(p.trim())).filter(n => !isNaN(n) && n > 0)
    if (parts.length >= 2) return Math.min(parts.length, 6)
  }
  const tokens = r.split(/\\s+/).filter(Boolean)
  if (tokens.length >= 2) return Math.min(tokens.length, 6)
  for (let i = 6; i >= 3; i--) {
    if (slots[\`col-\${i}\`]) return i
  }
  if (slots['col-2'] || slots['right']) return 2
  return 2
})

const gridStyle = computed(() => {
  const r = props.layoutRatio || ''
  if (r) {
    if (r.includes(':')) {
      const parts = r.split(':').map(p => parseFloat(p.trim())).filter(n => !isNaN(n) && n > 0)
      if (parts.length >= 2) {
        return { gridTemplateColumns: parts.map(n => \`\${n}fr\`).join(' ') }
      }
    }
    const tokens = r.split(/\\s+/).filter(Boolean)
    if (tokens.length >= 2) {
      return { gridTemplateColumns: tokens.join(' ') }
    }
  }
  return { gridTemplateColumns: \`repeat(\${detectedColsCount.value}, minmax(0, 1fr))\` }
})
<\/script>

<template>
  <div class="slidev-layout cols-header w-full h-full flex flex-col">
    <div class="header-section mb-4 w-full">
      <slot />
    </div>
    <div class="grid gap-6 flex-1 items-stretch" :style="gridStyle">
      <div v-if="detectedColsCount >= 1" class="col-1 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-1"><slot name="left" /></slot>
      </div>
      <div v-if="detectedColsCount >= 2" class="col-2 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-2"><slot v-if="detectedColsCount === 2" name="right" /></slot>
      </div>
      <div v-if="detectedColsCount >= 3" class="col-3 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-3" />
      </div>
      <div v-if="detectedColsCount >= 4" class="col-4 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-4" />
      </div>
      <div v-if="detectedColsCount >= 5" class="col-5 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-5" />
      </div>
      <div v-if="detectedColsCount >= 6" class="col-6 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-6" />
      </div>
    </div>
  </div>
</template>
`,tf=`<script setup lang="ts">
import { computed } from 'vue'

const props = defineProps({
  layoutRatio: {
    type: String,
    default: '',
  },
})

const gridStyle = computed(() => {
  const r = props.layoutRatio || ''
  if (!r) return {}
  if (r.includes(':')) {
    const parts = r.split(':').map(p => parseFloat(p.trim())).filter(n => !isNaN(n) && n > 0)
    if (parts.length >= 2) {
      return { gridTemplateColumns: parts.map(n => \`\${n}fr\`).join(' ') }
    }
  }
  const tokens = r.split(/\\s+/).filter(Boolean)
  if (tokens.length >= 2) {
    return { gridTemplateColumns: tokens.join(' ') }
  }
  return {}
})
<\/script>

<template>
  <div class="slidev-layout three-cols-header w-full h-full flex flex-col">
    <div class="header-section mb-4 w-full">
      <slot />
    </div>
    <div class="grid gap-6 flex-1 items-stretch" :class="gridStyle.gridTemplateColumns ? '' : 'grid-cols-3'" :style="gridStyle">
      <div class="col-1 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-1" />
      </div>
      <div class="col-2 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-2" />
      </div>
      <div class="col-3 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-3" />
      </div>
    </div>
  </div>
</template>
`,ef=`// Auto-generated by SiYuan Slidev Studio
export default function() {
  if (typeof window === 'undefined') return
  window.addEventListener('click', (e: MouseEvent) => {
    const target = e.target as HTMLElement | null
    if (!target || !target.closest) return

    const refEl = target.closest('[data-ref-id]')
    if (refEl) {
      const blockId = refEl.getAttribute('data-ref-id')
      if (blockId) {
        e.preventDefault()
        e.stopPropagation()
        window.parent.postMessage({
          source: 'siyuan-slidev-client',
          action: 'OPEN_PEEK_DRAWER',
          payload: { peekType: 'siyuan', blockId, title: (refEl.innerText || refEl.title || '').trim() }
        }, '*')
        return
      }
    }

    const linkEl = target.closest('a') as HTMLAnchorElement | null
    if (linkEl) {
      const href = linkEl.getAttribute('href') || ''
      if (href.startsWith('siyuan://blocks/')) {
        e.preventDefault()
        e.stopPropagation()
        const cleanBlockId = href.replace('siyuan://blocks/', '').split('?')[0]
        window.parent.postMessage({
          source: 'siyuan-slidev-client',
          action: 'OPEN_PEEK_DRAWER',
          payload: { peekType: 'siyuan', blockId: cleanBlockId, title: (linkEl.innerText || linkEl.title || '').trim() }
        }, '*')
      } else if (/^https?:\\/\\//i.test(href)) {
        e.preventDefault()
        e.stopPropagation()
        window.parent.postMessage({
          source: 'siyuan-slidev-client',
          action: 'OPEN_PEEK_DRAWER',
          payload: { peekType: 'web', url: href, title: (linkEl.innerText || linkEl.title || '').trim() }
        }, '*')
      }
    }
  }, true)
}
`,nf=`${ds}

/* Auto-generated by SiYuan Slidev Studio */
.slidev-ref-tag,
a.slidev-ref-tag {
  display: inline-flex;
  align-items: center;
  background: color-mix(in srgb, var(--slidev-theme-primary, #10b981) 12%, transparent);
  color: var(--slidev-theme-primary, #10b981);
  border-radius: 4px;
  padding: 2px 8px;
  font-size: 0.88em;
  text-decoration: none;
  border: 1px solid color-mix(in srgb, var(--slidev-theme-primary, #10b981) 25%, transparent);
  cursor: pointer;
  transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
  user-select: none;
}

.slidev-ref-tag:hover,
a.slidev-ref-tag:hover {
  background: color-mix(in srgb, var(--slidev-theme-primary, #10b981) 22%, transparent);
  color: var(--slidev-theme-primary, #10b981);
  border-color: color-mix(in srgb, var(--slidev-theme-primary, #10b981) 55%, transparent);
  transform: translateY(-1px);
  box-shadow: 0 2px 8px color-mix(in srgb, var(--slidev-theme-primary, #10b981) 20%, transparent);
}

.slidev-block-ref {
  display: block;
  padding: 10px 14px;
  background: color-mix(in srgb, var(--slidev-theme-primary, #10b981) 8%, transparent);
  border-left: 3px solid var(--slidev-theme-primary, #10b981);
  border-radius: 0 6px 6px 0;
  margin: 8px 0;
  cursor: pointer;
  transition: background 0.2s ease;
}

.slidev-block-ref:hover {
  background: color-mix(in srgb, var(--slidev-theme-primary, #10b981) 15%, transparent);
}

/* 代码块自动换行与无横向滚动条 */
pre,
pre code {
  white-space: pre-wrap !important;
  word-break: break-all !important;
  overflow-wrap: anywhere !important;
  overflow-x: hidden !important;
  overflow-y: auto !important;
  max-width: 100% !important;
  box-sizing: border-box !important;
}

/* 弱提示滚动条样式 */
* {
  scrollbar-width: thin;
}
html:not(.dark) * {
  scrollbar-color: rgba(0, 0, 0, 0.15) transparent;
}
html.dark * {
  scrollbar-color: rgba(255, 255, 255, 0.20) transparent;
}
*::-webkit-scrollbar {
  width: 4px;
  height: 4px;
}
*::-webkit-scrollbar-track {
  background: transparent;
}
html:not(.dark) *::-webkit-scrollbar-thumb {
  background: rgba(0, 0, 0, 0.15);
  border-radius: 2px;
}
html:not(.dark) *:hover::-webkit-scrollbar-thumb,
html:not(.dark) *::-webkit-scrollbar-thumb:hover {
  background: rgba(0, 0, 0, 0.35);
}
html.dark *::-webkit-scrollbar-thumb {
  background: rgba(255, 255, 255, 0.20);
  border-radius: 2px;
}
html.dark *:hover::-webkit-scrollbar-thumb,
html.dark *::-webkit-scrollbar-thumb:hover {
  background: rgba(255, 255, 255, 0.45);
}

/* 多媒体（GIF动图、静态图片、MP4视频）最大化自适应且不超出视口：顶部对齐，横向居中 */
.slidev-layout img,
.slidev-layout video {
  max-width: 100% !important;
  max-height: 100% !important;
  width: auto;
  height: auto;
  object-fit: contain !important;
}
.three-cols-header video,
.two-cols-header video,
.grid-cols-3 video,
.grid-cols-2 video,
.col-1 video,
.col-2 video,
.col-3 video {
  width: auto !important;
  height: auto !important;
  max-width: 100% !important;
  max-height: 100% !important;
  object-fit: contain !important;
  display: block !important;
  margin: 0 auto !important;
}
.slide-list-media {
  display: flex !important;
  flex-direction: column !important;
  align-items: center !important;
  justify-content: flex-start !important;
  margin-top: 4px !important;
  margin-bottom: 4px !important;
  width: 100% !important;
  max-width: 100% !important;
  height: 100% !important;
  max-height: 100% !important;
  flex: 1 1 0% !important;
  overflow: hidden !important;
}
.slide-list-media img,
.slide-list-media video,
.slide-list-media .list-item-gif {
  width: auto !important;
  height: auto !important;
  max-width: 100% !important;
  max-height: 100% !important;
  object-fit: contain !important;
  border-radius: 6px !important;
  box-shadow: 0 3px 12px rgba(0, 0, 0, 0.14) !important;
  display: block !important;
  margin: 0 auto !important;
}
.slide-video-container {
  display: flex !important;
  flex-direction: column !important;
  justify-content: flex-start !important;
  align-items: center !important;
  width: 100% !important;
  max-height: 100% !important;
  margin: 6px 0 !important;
}
.slide-video-player {
  max-width: 100% !important;
  max-height: 100% !important;
  object-fit: contain !important;
  border-radius: 8px !important;
}

/* 两栏与多栏（超级块分栏）布局：紧凑自然行距，子列表保留圆点与层级缩进 */
.cols-header ul,
.three-cols-header ul,
.two-cols-header ul,
.two-cols ul,
.col-1 ul,
.col-2 ul,
.col-3 ul,
.col-4 ul,
.col-5 ul,
.col-6 ul,
.grid-cols-2 ul,
.grid-cols-3 ul {
  list-style: disc !important;
  list-style-type: disc !important;
  padding-left: 1.25em !important;
  margin-left: 0 !important;
  margin-top: 0 !important;
  margin-bottom: 8px !important;
  flex: 0 0 auto !important;
  height: auto !important;
  display: block !important;
}
.cols-header ol,
.three-cols-header ol,
.two-cols-header ol,
.two-cols ol,
.col-1 ol,
.col-2 ol,
.col-3 ol,
.col-4 ol,
.col-5 ol,
.col-6 ol,
.grid-cols-2 ol,
.grid-cols-3 ol {
  list-style: decimal !important;
  list-style-type: decimal !important;
  padding-left: 1.25em !important;
  margin-left: 0 !important;
  margin-top: 0 !important;
  margin-bottom: 8px !important;
  flex: 0 0 auto !important;
  height: auto !important;
  display: block !important;
}
.cols-header li,
.three-cols-header li,
.two-cols-header li,
.two-cols li,
.col-1 li,
.col-2 li,
.col-3 li,
.col-4 li,
.col-5 li,
.col-6 li,
.grid-cols-2 li,
.grid-cols-3 li {
  padding-left: 0.2em !important;
  margin-left: 0 !important;
  margin-bottom: 6px !important;
  flex: 0 0 auto !important;
  height: auto !important;
  display: list-item !important;
  line-height: 1.6 !important;
}
.cols-header ul ul,
.three-cols-header ul ul,
.two-cols-header ul ul,
.two-cols ul ul,
.col-1 ul ul,
.col-2 ul ul,
.col-3 ul ul,
.col-4 ul ul,
.col-5 ul ul,
.col-6 ul ul {
  list-style: circle !important;
  list-style-type: circle !important;
  padding-left: 1.25em !important;
  margin-top: 4px !important;
  margin-bottom: 4px !important;
}

/* 列表项内嵌标题与说明排版 */
.slide-list-item-title,
li > h1,
li > h2,
li > h3,
li > h4,
li > h5,
li > h6 {
  margin-top: 2px !important;
  margin-bottom: 6px !important;
  line-height: 1.35 !important;
  font-weight: 700 !important;
}
li > h1 { font-size: 1.6rem !important; }
li > h2 { font-size: 1.4rem !important; }
li > h3 { font-size: 1.22rem !important; }
li > h4 { font-size: 1.1rem !important; }
.slide-list-item-desc,
li > p {
  margin-top: 4px !important;
  margin-bottom: 6px !important;
  font-size: 1.05rem;
  line-height: 1.55;
  opacity: 0.92;
}
`;function of(t){var o;const i=[],e=/^[ \t]*<<<[ \t]+(?:@\/|\.\/|)([^\s#]+)(?:#[^\s]+)?/gm;let n;for(;(n=e.exec(t))!==null;){const s=(o=n[1])==null?void 0:o.trim();s&&!i.includes(s)&&i.push(s)}return i}class sf{constructor(i){wt(this,"workspacePath");wt(this,"slidesFileName");wt(this,"cliBridge",new Ls);const e=Yu();!(i!=null&&i.workspacePath)||i.workspacePath.includes("/data/storage/petal/siyuan-slidev/pro-workspace")?this.workspacePath=e:this.workspacePath=i.workspacePath,this.slidesFileName=(i==null?void 0:i.slidesFileName)||"slides.md"}getWorkspacePath(){return this.workspacePath}getSlidesPath(){return`${this.workspacePath}/${this.slidesFileName}`}generatePackageJson(i="default"){const e={name:"siyuan-slidev-pro-workspace",type:"module",private:!0,scripts:{dev:"slidev --port 3030",build:"slidev build"},dependencies:{"@slidev/cli":"^53.0.0","@slidev/theme-default":"latest"}};return i&&i!=="default"&&(e.dependencies[`@slidev/theme-${i}`]="latest"),JSON.stringify(e,null,2)}buildSlidesMarkdown(i){return this.cliBridge.buildStandardSlidevMarkdown(i)}async scaffold(i,e){const n=this.buildSlidesMarkdown(i),o=this.generatePackageJson(i.config.theme),s=this.getSlidesPath(),l=`${this.workspacePath}/package.json`,r=us(s),a=us(l),c=of(n);c.includes("snippets/external.ts")||c.push("snippets/external.ts");const u=new Map;for(const x of c){const C=na[x]||`// Auto-generated snippet placeholder for SiYuan Slidev
// #region snippet
// ${x}
// #endregion snippet
`;u.set(x,C)}i.slides.some(x=>{var C;return((C=x.frontmatter)==null?void 0:C.layout)==="cols-header"})&&u.set("layouts/cols-header.vue",Qu),i.slides.some(x=>{var C;return((C=x.frontmatter)==null?void 0:C.layout)==="three-cols-header"})&&u.set("layouts/three-cols-header.vue",tf),u.set("setup/root.ts",ef),u.set("styles/index.css",nf);const d=Ce("fs"),b=Ce("path");let f=!1;const y=b!=null&&b.dirname?b.dirname(r):"",k=/^[a-zA-Z]:[/\\]/.test(r)||r.includes("siyuan-slidev-pro");if(d&&b&&k)try{d.existsSync(y)||d.mkdirSync(y,{recursive:!0}),d.writeFileSync(a,o,"utf-8"),d.writeFileSync(r,n,"utf-8");for(const[x,C]of u.entries()){const A=b.join(y,x),B=b.dirname(A);d.existsSync(B)||d.mkdirSync(B,{recursive:!0}),d.existsSync(A)||d.writeFileSync(A,C,"utf-8")}f=!0}catch{}if(!f&&e)try{const x=typeof Blob<"u"?new Blob([n],{type:"text/markdown;charset=utf-8"}):Buffer.from(n,"utf-8"),C=typeof Blob<"u"?new Blob([o],{type:"application/json;charset=utf-8"}):Buffer.from(o,"utf-8");await e(l,!1,C),await e(s,!1,x);for(const[A,B]of u.entries()){const I=`${this.workspacePath}/${A}`,w=typeof Blob<"u"?new Blob([B],{type:"text/plain;charset=utf-8"}):Buffer.from(B,"utf-8");await e(I,!1,w).catch(()=>{})}return{success:!0,slidesPath:s,physicalSlidesPath:r,packageJsonPath:l}}catch(x){return{success:!1,slidesPath:s,physicalSlidesPath:r,packageJsonPath:l,error:String(x)}}return{success:!0,slidesPath:s,physicalSlidesPath:r,packageJsonPath:l}}}class rf{constructor(){wt(this,"mode","web-sandbox");wt(this,"webBridge");wt(this,"cliBridge");wt(this,"nativeBridge");wt(this,"processManager");wt(this,"scaffolder");wt(this,"envDetector");this.webBridge=new Os,this.cliBridge=new Ls,this.nativeBridge=new Ju,this.processManager=new Xu,this.scaffolder=new sf,this.envDetector=new Rs}getMode(){return this.mode}setMode(i){this.mode=i}async startProMode(i,e){if(!(await this.envDetector.detect()).hasNode)return{success:!1,url:"",error:"当前系统未检测到 Node.js 环境，无法拉起官方 Slidev CLI，建议继续使用内置高保真引擎"};const o=await this.scaffolder.scaffold(i,e);if(!o.success)return{success:!1,url:"",error:`初始化 Slidev 临时工作空间失败: ${o.error}`};const s=o.physicalSlidesPath||o.slidesPath,l=await this.processManager.startServer(s);return l.success?(this.mode="pro-cli",{success:!0,url:l.url,port:l.port}):{success:!1,url:"",error:l.error}}stopProMode(){this.processManager.stopServer(),this.mode="web-sandbox"}destroy(){this.webBridge.detach(),this.nativeBridge.detach(),this.processManager.stopServer()}}const lf={class:"slidev-icon",style:{fill:"none !important"},viewBox:"0 0 24 24",stroke:"currentColor","stroke-width":"1.75","stroke-linecap":"round","stroke-linejoin":"round","aria-hidden":"true"},af={key:0},cf={key:1},df={key:2},uf={key:3},ff={key:4},pf={key:5},hf={key:6},mf={key:7},gf={key:8},vf={key:9},bf={key:10},yf={key:11},kf={key:12},wf={key:13},xf={key:14},_f={key:15},Sf={key:16},Cf={key:17},$f={key:18},If={key:19},Af={key:20},Bf={key:21},Tf={key:22},Ef={key:23},Mf={key:24},Df={key:25},Lf={key:26},Pf={key:27},Rf={key:28},Of={key:29},zf={key:30},Nf={key:31},Ff={key:32},Hf={key:33},jf={key:34},Uf={key:35},Wf={key:36},Vf={key:37},qf={key:38},Kf={key:39},Gf={key:40},Zf={key:41},Yf={key:42},Jf={key:43},Xf={key:44},Qf={key:45},tp={key:46},ep={key:47},ip={key:48},np={key:49},op={key:50},sp={key:51},rp={key:52},lp={key:53},ap={key:54},cp={key:55},dp={key:56},up={key:57},fp={key:58},pp={key:59},hp={key:60},mp={key:61},gp={key:62},vp={key:63},bp=_e({__name:"SlidevIcon",props:{name:{}},setup(t){return(i,e)=>(et(),it("svg",lf,[t.name==="fullscreen"||t.name==="maximize"?(et(),it("g",af,[...e[0]||(e[0]=[h("polyline",{points:"15 3 21 3 21 9"},null,-1),h("polyline",{points:"9 21 3 21 3 15"},null,-1),h("polyline",{points:"21 15 21 21 15 21"},null,-1),h("polyline",{points:"3 9 3 3 9 3"},null,-1)])])):t.name==="minimize"?(et(),it("g",cf,[...e[1]||(e[1]=[h("polyline",{points:"4 14 10 14 10 20"},null,-1),h("polyline",{points:"20 10 14 10 14 4"},null,-1),h("line",{x1:"14",y1:"10",x2:"21",y2:"3"},null,-1),h("line",{x1:"3",y1:"21",x2:"10",y2:"14"},null,-1)])])):t.name==="close"||t.name==="x"?(et(),it("g",df,[...e[2]||(e[2]=[h("line",{x1:"18",y1:"6",x2:"6",y2:"18"},null,-1),h("line",{x1:"6",y1:"6",x2:"18",y2:"18"},null,-1)])])):t.name==="edit"?(et(),it("g",uf,[...e[3]||(e[3]=[h("path",{d:"M12 20h9"},null,-1),h("path",{d:"M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z"},null,-1)])])):t.name==="eye"?(et(),it("g",ff,[...e[4]||(e[4]=[h("path",{d:"M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"},null,-1),h("circle",{cx:"12",cy:"12",r:"3"},null,-1)])])):t.name==="external-link"||t.name==="window"?(et(),it("g",pf,[...e[5]||(e[5]=[h("path",{d:"M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"},null,-1),h("polyline",{points:"15 3 21 3 21 9"},null,-1),h("line",{x1:"10",y1:"14",x2:"21",y2:"3"},null,-1)])])):t.name==="arrow-left"?(et(),it("g",hf,[...e[6]||(e[6]=[h("line",{x1:"19",y1:"12",x2:"5",y2:"12"},null,-1),h("polyline",{points:"12 19 5 12 12 5"},null,-1)])])):t.name==="arrow-right"?(et(),it("g",mf,[...e[7]||(e[7]=[h("line",{x1:"5",y1:"12",x2:"19",y2:"12"},null,-1),h("polyline",{points:"12 5 19 12 12 19"},null,-1)])])):t.name==="plus"?(et(),it("g",gf,[...e[8]||(e[8]=[h("line",{x1:"12",y1:"5",x2:"12",y2:"19"},null,-1),h("line",{x1:"5",y1:"12",x2:"19",y2:"12"},null,-1)])])):t.name==="minus"?(et(),it("g",vf,[...e[9]||(e[9]=[h("line",{x1:"5",y1:"12",x2:"19",y2:"12"},null,-1)])])):t.name==="split-preview"?(et(),it("g",bf,[...e[10]||(e[10]=[h("rect",{x:"3",y:"3",width:"18",height:"18",rx:"2"},null,-1),h("path",{d:"M12 3v18"},null,-1)])])):t.name==="import"?(et(),it("g",yf,[...e[11]||(e[11]=[h("path",{d:"M4 17v2a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-2"},null,-1),h("polyline",{points:"7 9 12 14 17 9"},null,-1),h("line",{x1:"12",y1:"14",x2:"12",y2:"3"},null,-1)])])):t.name==="presenter"?(et(),it("g",kf,[...e[12]||(e[12]=[h("path",{d:"M2 3h20"},null,-1),h("path",{d:"M21 3v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V3"},null,-1),h("path",{d:"m7 21 5-5 5 5"},null,-1)])])):t.name==="video"?(et(),it("g",wf,[...e[13]||(e[13]=[h("polygon",{points:"23 7 16 12 23 17 23 7"},null,-1),h("rect",{x:"1",y:"5",width:"15",height:"14",rx:"2",ry:"2"},null,-1)])])):t.name==="step"?(et(),it("g",xf,[...e[14]||(e[14]=[h("polygon",{points:"13 2 3 14 12 14 11 22 21 10 12 10 13 2"},null,-1)])])):t.name==="motion"?(et(),it("g",_f,[...e[15]||(e[15]=[h("path",{d:"M5 12h14"},null,-1),h("path",{d:"m12 5 7 7-7 7"},null,-1),h("path",{d:"M5 6h4"},null,-1),h("path",{d:"M5 18h4"},null,-1)])])):t.name==="columns"?(et(),it("g",Sf,[...e[16]||(e[16]=[h("rect",{x:"3",y:"3",width:"7",height:"18",rx:"1"},null,-1),h("rect",{x:"14",y:"3",width:"7",height:"18",rx:"1"},null,-1)])])):t.name==="code"?(et(),it("g",Cf,[...e[17]||(e[17]=[h("polyline",{points:"16 18 22 12 16 6"},null,-1),h("polyline",{points:"8 6 2 12 8 18"},null,-1)])])):t.name==="insert-above"?(et(),it("g",$f,[...e[18]||(e[18]=[h("line",{x1:"12",y1:"5",x2:"12",y2:"13"},null,-1),h("line",{x1:"8",y1:"9",x2:"16",y2:"9"},null,-1),h("path",{d:"M4 19h16","stroke-dasharray":"2 2"},null,-1)])])):t.name==="insert-below"?(et(),it("g",If,[...e[19]||(e[19]=[h("path",{d:"M4 5h16","stroke-dasharray":"2 2"},null,-1),h("line",{x1:"12",y1:"11",x2:"12",y2:"19"},null,-1),h("line",{x1:"8",y1:"15",x2:"16",y2:"15"},null,-1)])])):t.name==="broom"?(et(),it("g",Af,[...e[20]||(e[20]=[h("path",{d:"m18 15-6-6"},null,-1),h("path",{d:"M4 20h16"},null,-1),h("path",{d:"M6 14l8-8a2.8 2.8 0 0 1 4 4l-8 8H6v-4z"},null,-1)])])):t.name==="trash"?(et(),it("g",Bf,[...e[21]||(e[21]=[h("path",{d:"M3 6h18"},null,-1),h("path",{d:"M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"},null,-1),h("path",{d:"M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"},null,-1)])])):t.name==="ai"||t.name==="sparkles"?(et(),it("g",Tf,[...e[22]||(e[22]=[h("path",{d:"m12 3-1.9 5.8a2 2 0 0 1-1.3 1.3L3 12l5.8 1.9a2 2 0 0 1 1.3 1.3L12 21l1.9-5.8a2 2 0 0 1 1.3-1.3L21 12l-5.8-1.9a2 2 0 0 1-1.3-1.3L12 3z"},null,-1)])])):t.name==="palette"?(et(),it("g",Ef,[...e[23]||(e[23]=[ye('<circle cx="13.5" cy="6.5" r=".5" fill="currentColor" data-v-b0848a36></circle><circle cx="17.5" cy="10.5" r=".5" fill="currentColor" data-v-b0848a36></circle><circle cx="8.5" cy="7.5" r=".5" fill="currentColor" data-v-b0848a36></circle><circle cx="6.5" cy="12.5" r=".5" fill="currentColor" data-v-b0848a36></circle><path d="M12 2C6.5 2 2 6.5 2 12s4.5 10 10 10c.9 0 1.5-.7 1.5-1.5 0-.4-.2-.8-.4-1.1-.3-.4-.4-.8-.4-1.4 0-1.1.9-2 2-2h2.3c3.9 0 7-3.1 7-7 0-5-4.5-9-10-9z" data-v-b0848a36></path>',5)])])):t.name==="ratio"?(et(),it("g",Mf,[...e[24]||(e[24]=[h("rect",{x:"2",y:"5",width:"20",height:"14",rx:"2"},null,-1),h("line",{x1:"2",y1:"10",x2:"22",y2:"10","stroke-dasharray":"2 2"},null,-1)])])):t.name==="transition"?(et(),it("g",Df,[...e[25]||(e[25]=[h("path",{d:"M8 3 4 7l4 4"},null,-1),h("path",{d:"M4 7h16"},null,-1),h("path",{d:"m16 21 4-4-4-4"},null,-1),h("path",{d:"M20 17H4"},null,-1)])])):t.name==="export-html"?(et(),it("g",Lf,[...e[26]||(e[26]=[h("polyline",{points:"16 16 12 12 8 16"},null,-1),h("line",{x1:"12",y1:"12",x2:"12",y2:"21"},null,-1),h("path",{d:"M20.4 16.3A5 5 0 0 0 18 7h-1.3A8 8 0 0 0 4 12.8a5 5 0 0 0 1.5 9.2"},null,-1)])])):t.name==="export-pdf"?(et(),it("g",Pf,[...e[27]||(e[27]=[h("polyline",{points:"6 9 6 2 18 2 18 9"},null,-1),h("path",{d:"M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"},null,-1),h("rect",{x:"6",y:"14",width:"12",height:"8"},null,-1)])])):t.name==="pin"?(et(),it("g",Rf,[...e[28]||(e[28]=[h("line",{x1:"12",y1:"17",x2:"12",y2:"22"},null,-1),h("path",{d:"M5 17h14v-2l-2-2V5l1-1V2H6v2l1 1v8l-2 2v2z"},null,-1)])])):t.name==="refresh"?(et(),it("g",Of,[...e[29]||(e[29]=[h("path",{d:"M3 12a9 9 0 0 1 9-9 9.75 9.75 0 0 1 6.74 2.74L21 8"},null,-1),h("path",{d:"M21 3v5h-5"},null,-1),h("path",{d:"M21 12a9 9 0 0 1-9 9 9.75 9.75 0 0 1-6.74-2.74L3 16"},null,-1),h("path",{d:"M8 16H3v5"},null,-1)])])):t.name==="outline"?(et(),it("g",zf,[...e[30]||(e[30]=[h("line",{x1:"3",y1:"6",x2:"21",y2:"6"},null,-1),h("line",{x1:"3",y1:"12",x2:"21",y2:"12"},null,-1),h("line",{x1:"3",y1:"18",x2:"21",y2:"18"},null,-1)])])):t.name==="chevron-left"?(et(),it("g",Nf,[...e[31]||(e[31]=[h("polyline",{points:"15 18 9 12 15 6"},null,-1)])])):t.name==="chevron-right"?(et(),it("g",Ff,[...e[32]||(e[32]=[h("polyline",{points:"9 18 15 12 9 6"},null,-1)])])):t.name==="copy"?(et(),it("g",Hf,[...e[33]||(e[33]=[h("rect",{x:"9",y:"9",width:"13",height:"13",rx:"2",ry:"2"},null,-1),h("path",{d:"M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"},null,-1)])])):t.name==="image"?(et(),it("g",jf,[...e[34]||(e[34]=[h("rect",{x:"3",y:"3",width:"18",height:"18",rx:"2",ry:"2"},null,-1),h("circle",{cx:"8.5",cy:"8.5",r:"1.5"},null,-1),h("polyline",{points:"21 15 16 10 5 21"},null,-1)])])):t.name==="search"?(et(),it("g",Uf,[...e[35]||(e[35]=[h("circle",{cx:"11",cy:"11",r:"7"},null,-1),h("line",{x1:"21",y1:"21",x2:"16.65",y2:"16.65"},null,-1)])])):t.name==="settings"||t.name==="gear"?(et(),it("g",Wf,[...e[36]||(e[36]=[h("circle",{cx:"12",cy:"12",r:"3"},null,-1),h("path",{d:"M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 1 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 1 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 1 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 1 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"},null,-1)])])):t.name==="notes"||t.name==="file-text"?(et(),it("g",Vf,[...e[37]||(e[37]=[ye('<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" data-v-b0848a36></path><polyline points="14 2 14 8 20 8" data-v-b0848a36></polyline><line x1="16" y1="13" x2="8" y2="13" data-v-b0848a36></line><line x1="16" y1="17" x2="8" y2="17" data-v-b0848a36></line><line x1="10" y1="9" x2="8" y2="9" data-v-b0848a36></line>',5)])])):t.name==="focus"||t.name==="target"?(et(),it("g",qf,[...e[38]||(e[38]=[h("circle",{cx:"12",cy:"12",r:"3",fill:"currentColor"},null,-1),h("path",{d:"M12 2v4M12 18v4M2 12h4M18 12h4",stroke:"currentColor","stroke-width":"2","stroke-linecap":"round"},null,-1),h("circle",{cx:"12",cy:"12",r:"7",fill:"none",stroke:"currentColor","stroke-width":"1.8"},null,-1)])])):t.name==="layout-cover"||t.name==="cover"?(et(),it("g",Kf,[...e[39]||(e[39]=[h("rect",{x:"2",y:"4",width:"20",height:"16",rx:"2"},null,-1),h("line",{x1:"9",y1:"8",x2:"15",y2:"8"},null,-1),h("line",{x1:"5.5",y1:"11.5",x2:"18.5",y2:"11.5"},null,-1),h("line",{x1:"7.5",y1:"15",x2:"16.5",y2:"15"},null,-1)])])):t.name==="layout-default"||t.name==="default"?(et(),it("g",Gf,[...e[40]||(e[40]=[ye('<rect x="2" y="4" width="20" height="16" rx="2" data-v-b0848a36></rect><line x1="5" y1="8" x2="11.5" y2="8" data-v-b0848a36></line><line x1="5" y1="11.5" x2="19" y2="11.5" data-v-b0848a36></line><line x1="5" y1="14.5" x2="19" y2="14.5" data-v-b0848a36></line><line x1="5" y1="17.5" x2="13.5" y2="17.5" data-v-b0848a36></line>',5)])])):t.name==="layout-two-cols"||t.name==="two-cols"?(et(),it("g",Zf,[...e[41]||(e[41]=[ye('<rect x="2" y="4" width="20" height="16" rx="2" data-v-b0848a36></rect><line x1="12" y1="4" x2="12" y2="20" stroke-dasharray="2 1.5" data-v-b0848a36></line><line x1="5" y1="8" x2="9.5" y2="8" data-v-b0848a36></line><line x1="5" y1="11.5" x2="9.5" y2="11.5" data-v-b0848a36></line><line x1="5" y1="15" x2="8" y2="15" data-v-b0848a36></line><line x1="14.5" y1="8" x2="19" y2="8" data-v-b0848a36></line><line x1="14.5" y1="11.5" x2="19" y2="11.5" data-v-b0848a36></line><line x1="14.5" y1="15" x2="17.5" y2="15" data-v-b0848a36></line>',8)])])):t.name==="layout-two-cols-header"||t.name==="two-cols-header"?(et(),it("g",Yf,[...e[42]||(e[42]=[ye('<rect x="2" y="4" width="20" height="16" rx="2" data-v-b0848a36></rect><line x1="5" y1="7.5" x2="13" y2="7.5" data-v-b0848a36></line><line x1="12" y1="10.5" x2="12" y2="18.5" stroke-dasharray="1.5 1.5" data-v-b0848a36></line><line x1="5" y1="12" x2="9.5" y2="12" data-v-b0848a36></line><line x1="5" y1="15.5" x2="8.5" y2="15.5" data-v-b0848a36></line><line x1="14.5" y1="12" x2="19" y2="12" data-v-b0848a36></line><line x1="14.5" y1="15.5" x2="18" y2="15.5" data-v-b0848a36></line>',7)])])):t.name==="layout-cols-header"||t.name==="cols-header"||t.name==="layout-three-cols-header"||t.name==="three-cols-header"?(et(),it("g",Jf,[...e[43]||(e[43]=[ye('<rect x="2" y="4" width="20" height="16" rx="2" data-v-b0848a36></rect><line x1="5" y1="7.5" x2="13" y2="7.5" data-v-b0848a36></line><line x1="9.3" y1="10.5" x2="9.3" y2="18.5" stroke-dasharray="1.5 1.5" data-v-b0848a36></line><line x1="14.7" y1="10.5" x2="14.7" y2="18.5" stroke-dasharray="1.5 1.5" data-v-b0848a36></line><line x1="4.5" y1="12" x2="7.5" y2="12" data-v-b0848a36></line><line x1="4.5" y1="15.5" x2="7" y2="15.5" data-v-b0848a36></line><line x1="10.5" y1="12" x2="13.5" y2="12" data-v-b0848a36></line><line x1="10.5" y1="15.5" x2="13.5" y2="15.5" data-v-b0848a36></line><line x1="16" y1="12" x2="19.5" y2="12" data-v-b0848a36></line><line x1="16" y1="15.5" x2="18.5" y2="15.5" data-v-b0848a36></line>',10)])])):t.name==="layout-image-right"||t.name==="image-right"?(et(),it("g",Xf,[...e[44]||(e[44]=[ye('<rect x="2" y="4" width="20" height="16" rx="2" data-v-b0848a36></rect><line x1="12" y1="4" x2="12" y2="20" data-v-b0848a36></line><line x1="4.5" y1="8" x2="9.5" y2="8" data-v-b0848a36></line><line x1="4.5" y1="11.5" x2="10" y2="11.5" data-v-b0848a36></line><line x1="4.5" y1="14.5" x2="8" y2="14.5" data-v-b0848a36></line><circle cx="15.5" cy="8.5" r="1.2" data-v-b0848a36></circle><polyline points="13 17 15.5 13 18 16 19.5 14" data-v-b0848a36></polyline>',7)])])):t.name==="layout-image-left"||t.name==="image-left"?(et(),it("g",Qf,[...e[45]||(e[45]=[ye('<rect x="2" y="4" width="20" height="16" rx="2" data-v-b0848a36></rect><line x1="12" y1="4" x2="12" y2="20" data-v-b0848a36></line><circle cx="6" cy="8.5" r="1.2" data-v-b0848a36></circle><polyline points="3.5 17 6 13 8.5 16 10 14" data-v-b0848a36></polyline><line x1="14.5" y1="8" x2="19.5" y2="8" data-v-b0848a36></line><line x1="14.5" y1="11.5" x2="20" y2="11.5" data-v-b0848a36></line><line x1="14.5" y1="14.5" x2="18" y2="14.5" data-v-b0848a36></line>',7)])])):t.name==="layout-center"||t.name==="center"?(et(),it("g",tp,[...e[46]||(e[46]=[h("rect",{x:"2",y:"4",width:"20",height:"16",rx:"2"},null,-1),h("line",{x1:"6.5",y1:"9",x2:"17.5",y2:"9"},null,-1),h("line",{x1:"5",y1:"12",x2:"19",y2:"12"},null,-1),h("line",{x1:"8",y1:"15",x2:"16",y2:"15"},null,-1)])])):t.name==="layout-fact"||t.name==="fact"?(et(),it("g",ep,[...e[47]||(e[47]=[ye('<rect x="2" y="4" width="20" height="16" rx="2" data-v-b0848a36></rect><circle cx="8" cy="9" r="1.5" data-v-b0848a36></circle><line x1="14" y1="8" x2="9" y2="14" data-v-b0848a36></line><circle cx="15" cy="13" r="1.5" data-v-b0848a36></circle><line x1="6.5" y1="17" x2="17.5" y2="17" data-v-b0848a36></line>',5)])])):t.name==="layout-intro"||t.name==="intro"?(et(),it("g",ip,[...e[48]||(e[48]=[ye('<rect x="2" y="4" width="20" height="16" rx="2" data-v-b0848a36></rect><circle cx="7.5" cy="9.5" r="2" data-v-b0848a36></circle><path d="M4.5 16.5c0-1.8 1.3-3 3-3s3 1.2 3 3" data-v-b0848a36></path><line x1="13" y1="9" x2="18.5" y2="9" data-v-b0848a36></line><line x1="13" y1="12.5" x2="19.5" y2="12.5" data-v-b0848a36></line><line x1="13" y1="15.5" x2="17" y2="15.5" data-v-b0848a36></line>',6)])])):t.name==="layout-quote"||t.name==="quote"?(et(),it("g",np,[...e[49]||(e[49]=[ye('<rect x="2" y="4" width="20" height="16" rx="2" data-v-b0848a36></rect><path d="M6 7.5h2v2H6.5c0 1.2-.4 2-1.5 2.5" data-v-b0848a36></path><path d="M9.5 7.5h2v2H10c0 1.2-.4 2-1.5 2.5" data-v-b0848a36></path><line x1="6" y1="13.5" x2="18" y2="13.5" data-v-b0848a36></line><line x1="12.5" y1="16.5" x2="17.5" y2="16.5" data-v-b0848a36></line>',5)])])):t.name==="desktop"||t.name==="monitor"?(et(),it("g",op,[...e[50]||(e[50]=[h("rect",{x:"2",y:"3",width:"20",height:"14",rx:"2"},null,-1),h("line",{x1:"8",y1:"21",x2:"16",y2:"21"},null,-1),h("line",{x1:"12",y1:"17",x2:"12",y2:"21"},null,-1)])])):t.name==="mobile"||t.name==="smartphone"||t.name==="phone"?(et(),it("g",sp,[...e[51]||(e[51]=[h("rect",{x:"5",y:"2",width:"14",height:"20",rx:"2",ry:"2"},null,-1),h("line",{x1:"12",y1:"18",x2:"12.01",y2:"18","stroke-width":"2","stroke-linecap":"round"},null,-1)])])):t.name==="type"||t.name==="heading"?(et(),it("g",rp,[...e[52]||(e[52]=[h("polyline",{points:"4 7 4 4 20 4 20 7"},null,-1),h("line",{x1:"9",y1:"20",x2:"15",y2:"20"},null,-1),h("line",{x1:"12",y1:"4",x2:"12",y2:"20"},null,-1)])])):t.name==="reset"||t.name==="undo"?(et(),it("g",lp,[...e[53]||(e[53]=[h("path",{d:"M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8"},null,-1),h("polyline",{points:"3 3 3 8 8 8"},null,-1)])])):t.name==="repeat"||t.name==="loop"?(et(),it("g",ap,[...e[54]||(e[54]=[h("path",{d:"m17 1 4 4-4 4"},null,-1),h("path",{d:"M3 11V9a4 4 0 0 1 4-4h14"},null,-1),h("path",{d:"m7 23-4-4 4-4"},null,-1),h("path",{d:"M21 13v2a4 4 0 0 1-4 4H3"},null,-1)])])):t.name==="volume-x"||t.name==="mute"?(et(),it("g",cp,[...e[55]||(e[55]=[h("polygon",{points:"11 5 6 9 2 9 2 15 6 15 11 19 11 5"},null,-1),h("line",{x1:"22",y1:"9",x2:"16",y2:"15"},null,-1),h("line",{x1:"16",y1:"9",x2:"22",y2:"15"},null,-1)])])):t.name==="sliders"||t.name==="controls"?(et(),it("g",dp,[...e[56]||(e[56]=[ye('<line x1="4" y1="21" x2="4" y2="14" data-v-b0848a36></line><line x1="4" y1="10" x2="4" y2="3" data-v-b0848a36></line><line x1="12" y1="21" x2="12" y2="12" data-v-b0848a36></line><line x1="12" y1="8" x2="12" y2="3" data-v-b0848a36></line><line x1="20" y1="21" x2="20" y2="16" data-v-b0848a36></line><line x1="20" y1="12" x2="20" y2="3" data-v-b0848a36></line><line x1="1" y1="14" x2="7" y2="14" data-v-b0848a36></line><line x1="9" y1="8" x2="15" y2="8" data-v-b0848a36></line><line x1="17" y1="16" x2="23" y2="16" data-v-b0848a36></line>',9)])])):t.name==="package"||t.name==="zip"||t.name==="archive"?(et(),it("g",up,[...e[57]||(e[57]=[h("line",{x1:"16.5",y1:"9.4",x2:"7.5",y2:"4.21"},null,-1),h("path",{d:"M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"},null,-1),h("polyline",{points:"3.27 6.96 12 12.01 20.73 6.96"},null,-1),h("line",{x1:"12",y1:"22.08",x2:"12",y2:"12"},null,-1)])])):t.name==="folder"?(et(),it("g",fp,[...e[58]||(e[58]=[h("path",{d:"M4 20h16a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2h-7.93a2 2 0 0 1-1.66-.9l-.82-1.2A2 2 0 0 0 7.93 3H4a2 2 0 0 0-2 2v13c0 1.1.9 2 2 2Z"},null,-1)])])):t.name==="rocket"?(et(),it("g",pp,[...e[59]||(e[59]=[h("path",{d:"M4.5 16.5c-1.5 1.26-2 5-2 5s3.74-.5 5-2c.71-.84.7-2.13-.09-2.91a2.18 2.18 0 0 0-2.91-.09z"},null,-1),h("path",{d:"m12 15-3-3a22 22 0 0 1 2-3.95A12.88 12.88 0 0 1 22 2c0 2.72-.78 7.5-6 11a22.35 22.35 0 0 1-4 2z"},null,-1),h("path",{d:"M9 12H4s.55-3.03 2-4c1.62-1.08 5 0 5 0"},null,-1),h("path",{d:"M12 15v5s3.03-.55 4-2c1.08-1.62 0-5 0-5"},null,-1)])])):t.name==="wand"||t.name==="magic"?(et(),it("g",hp,[...e[60]||(e[60]=[h("path",{d:"m19 2 2 2-6 6-2-2Z"},null,-1),h("path",{d:"m13 8 2 2"},null,-1),h("path",{d:"m3 21 9-9"},null,-1)])])):t.name==="image-left"?(et(),it("g",mp,[...e[61]||(e[61]=[ye('<rect x="2" y="4" width="20" height="16" rx="2" data-v-b0848a36></rect><rect x="4" y="6" width="6" height="12" rx="1" data-v-b0848a36></rect><line x1="13" y1="8" x2="19" y2="8" data-v-b0848a36></line><line x1="13" y1="12" x2="19" y2="12" data-v-b0848a36></line><line x1="13" y1="16" x2="17" y2="16" data-v-b0848a36></line>',5)])])):t.name==="image-right"?(et(),it("g",gp,[...e[62]||(e[62]=[ye('<rect x="2" y="4" width="20" height="16" rx="2" data-v-b0848a36></rect><rect x="14" y="6" width="6" height="12" rx="1" data-v-b0848a36></rect><line x1="5" y1="8" x2="11" y2="8" data-v-b0848a36></line><line x1="5" y1="12" x2="11" y2="12" data-v-b0848a36></line><line x1="5" y1="16" x2="9" y2="16" data-v-b0848a36></line>',5)])])):(et(),it("g",vp,[...e[63]||(e[63]=[h("rect",{x:"2",y:"3",width:"20",height:"14",rx:"2"},null,-1),h("line",{x1:"8",y1:"21",x2:"16",y2:"21"},null,-1),h("line",{x1:"12",y1:"17",x2:"12",y2:"21"},null,-1)])]))]))}}),ze=(t,i)=>{const e=t.__vccOpts||t;for(const[n,o]of i)e[n]=o;return e},ut=ze(bp,[["__scopeId","data-v-b0848a36"]]);function ie(t,i){var o;if(typeof document>"u"||!t)return;const e=(o=globalThis.CSS)!=null&&o.escape?globalThis.CSS.escape(t):t.replace(/"/g,'\\"'),n=document.querySelectorAll(`[data-node-id="${e}"]`);!n||n.length===0||n.forEach(s=>{for(const[l,r]of Object.entries(i))r!=null&&r!==""?s.setAttribute(l,String(r)):s.removeAttribute(l)})}function yp(t){if(typeof document>"u")return;const i=`.protyle-wysiwyg [${mt}], .protyle-wysiwyg [${Vt}], .protyle-wysiwyg [custom-slidev-layout], .protyle-wysiwyg [custom-slidev-role]`,e=document.querySelectorAll(i);!e||e.length===0||e.forEach(n=>{const o=n.getAttribute("data-node-id");if(!o){n.removeAttribute(mt),n.removeAttribute("custom-slidev-layout"),n.removeAttribute(Vt),n.removeAttribute("custom-slidev-role");return}const s=t.get(o),l=(s==null?void 0:s[mt])||(s==null?void 0:s["custom-slidev-layout"])||"",r=n.getAttribute(mt)||n.getAttribute("custom-slidev-layout");r&&r!==l&&(l?n.setAttribute(mt,l):(n.removeAttribute(mt),n.removeAttribute("custom-slidev-layout")));const a=(s==null?void 0:s[Vt])||(s==null?void 0:s["custom-slidev-role"])||"",c=n.getAttribute(Vt)||n.getAttribute("custom-slidev-role");c&&c!==a&&(a?n.setAttribute(Vt,a):(n.removeAttribute(Vt),n.removeAttribute("custom-slidev-role")))})}const kp={class:"spm-layout-picker"},wp={class:"spm-layout-picker__grid"},xp=["title","onClick"],_p={class:"spm-layout-icon"},Sp={class:"spm-layout-label"},Cp=_e({__name:"LayoutPicker",props:{modelValue:{}},emits:["update:modelValue","change"],setup(t,{emit:i}){const e=t,n=i,o=[{name:"cover",label:"封面",desc:"大标题与副标题封面页"},{name:"default",label:"标准",desc:"标题在上方，内容在下方"},{name:"two-cols",label:"双栏",desc:"左右双栏对比展示"},{name:"cols-header",label:"表头多栏",desc:"顶部通栏标题，下方自适应 2~N 栏"},{name:"image-right",label:"图右",desc:"左侧为内容，右侧全屏背景图"},{name:"image-left",label:"图左",desc:"左侧全屏背景图，右侧为内容"},{name:"center",label:"居中",desc:"内容全屏垂直水平居中"},{name:"fact",label:"大字报",desc:"核心数据或指标突出展示"},{name:"intro",label:"介绍",desc:"演讲者自我介绍或章节导览"},{name:"quote",label:"引言",desc:"名人名言与强调段落"}];function s(r){return e.modelValue===r||r==="cols-header"&&(e.modelValue==="two-cols-header"||e.modelValue==="three-cols-header")}function l(r){n("update:modelValue",r),n("change",r)}return(r,a)=>(et(),it("div",kp,[a[0]||(a[0]=h("div",{class:"spm-layout-picker__header"},"选择页面版式",-1)),h("div",wp,[(et(),it(qt,null,we(o,c=>h("div",{key:c.name,class:It(["spm-layout-item",{active:s(c.name)}]),title:c.desc,onClick:u=>l(c.name)},[h("div",_p,[at(ut,{name:"layout-"+c.name},null,8,["name"])]),h("span",Sp,St(c.label),1)],10,xp)),64))])]))}}),oa=ze(Cp,[["__scopeId","data-v-da9222a6"]]),$p={key:0,class:"spm-transition-selector__header"},Ip={class:"spm-transition-list"},Ap=["onClick"],Bp={class:"spm-transition-meta"},Tp={class:"spm-transition-label"},Ep={class:"spm-transition-name"},Mp={class:"spm-transition-preview-box"},Dp=_e({__name:"TransitionSelector",props:{modelValue:{},hideHeader:{type:Boolean},title:{}},emits:["update:modelValue","change"],setup(t,{emit:i}){const e=i,n=[{name:"slide-left",label:"向左滑入",desc:"向左滑入 (slide-left)：页面从右侧向左平滑推入，最通用标准的横向幻灯片动效"},{name:"slide-right",label:"向右滑入",desc:"向右滑入 (slide-right)：页面从左侧向右平滑推入，适合倒序回退或逆向章节叙述"},{name:"slide-up",label:"向上推入",desc:"向上推入 (slide-up)：页面从底部向上平滑推入，适合纵向展开或纵深层级展示"},{name:"fade",label:"淡入淡出",desc:"淡入淡出 (fade)：透明度平滑渐变过度，典雅柔和，适合学术长篇与沉浸叙事"},{name:"zoom",label:"缩放进入",desc:"缩放进入 (zoom)：页面由中心向外平滑放大，富有动感冲击力，适合聚焦重点"}];function o(s){e("update:modelValue",s),e("change",s)}return(s,l)=>(et(),it("div",{class:It(["spm-transition-selector",{"spm-transition-selector--no-header":t.hideHeader}])},[t.hideHeader?Rt("",!0):(et(),it("div",$p,St(t.title||"转场动效"),1)),h("div",Ip,[(et(),it(qt,null,we(n,r=>h("div",{key:r.name,class:It(["spm-transition-item",{active:t.modelValue===r.name}]),onClick:a=>o(r.name)},[h("div",Bp,[h("span",Tp,St(r.label),1),h("span",Ep,"("+St(r.name)+")",1)]),h("div",Mp,[h("div",{class:It(["spm-anim-cube","anim-"+r.name])},null,2)])],10,Ap)),64))])],2))}}),zs=ze(Dp,[["__scopeId","data-v-b0aa61ff"]]),Lp={class:"spm-divider-popover"},Pp={class:"spm-divider-popover__title"},Rp={class:"spm-form-item"},Op={class:"spm-popover-footer"},zp={class:"spm-save-hint"},Np=_e({__name:"QuickDividerPopover",props:{blockId:{},initialAttrs:{}},emits:["close","updated"],setup(t,{emit:i}){var v,d,b;const e=t,n=i,o=gt(((v=e.initialAttrs)==null?void 0:v[mt])||"default"),s=gt(((d=e.initialAttrs)==null?void 0:d[Xt])||"slide-left"),l=gt(((b=e.initialAttrs)==null?void 0:b[jt])||""),r=gt("");Li(()=>e.initialAttrs,f=>{o.value=(f==null?void 0:f[mt])||"default",s.value=(f==null?void 0:f[Xt])||"slide-left",l.value=(f==null?void 0:f[jt])||""},{deep:!0});async function a(f,y){if(e.blockId){r.value="正在同步...",Pt.setBlockAttrOverride(e.blockId,{[f]:y}),ie(e.blockId,{[f]:y});try{await Lt(e.blockId,{[f]:y}),r.value="已同步至块属性",n("updated",{[f]:y}),setTimeout(()=>{r.value=""},1500)}catch{r.value="同步失败"}}}function c(f){a(mt,f)}function u(f){a(Xt,f)}function m(){a(jt,l.value.trim())}return(f,y)=>(et(),it("div",Lp,[h("div",Pp,[y[4]||(y[4]=h("span",null,"幻灯片页面设置",-1)),h("button",{class:"spm-close-btn",onClick:y[0]||(y[0]=k=>n("close"))},"✕")]),at(oa,{modelValue:o.value,"onUpdate:modelValue":y[1]||(y[1]=k=>o.value=k),onChange:c},null,8,["modelValue"]),at(zs,{modelValue:s.value,"onUpdate:modelValue":y[2]||(y[2]=k=>s.value=k),onChange:u},null,8,["modelValue"]),h("div",Rp,[y[5]||(y[5]=h("label",{class:"spm-form-label"},"页面背景",-1)),Te(h("input",{"onUpdate:modelValue":y[3]||(y[3]=k=>l.value=k),class:"spm-input",placeholder:"assets/bg.jpg 或颜色值 (#1e1e24)",onBlur:m},null,544),[[mo,l.value]])]),h("div",Op,[h("span",zp,St(r.value),1)])]))}}),Fp=ze(Np,[["__scopeId","data-v-e4871368"]]),Hp={class:"spm-slide-inspector"},jp={class:"spm-inspector-header"},Up={class:"spm-inspector-list"},Wp=["onClick"],Vp={class:"spm-card-top"},qp={class:"spm-card-badge"},Kp={class:"spm-card-layout"},Gp=["onClick"],Zp={class:"spm-card-preview"},Yp={key:0,class:"spm-card-notes",title:"演讲备忘录"},Jp={class:"spm-inspector-modal-content"},Xp=_e({__name:"SlideInspector",props:{slides:{},currentActivePage:{}},emits:["navigate","refresh"],setup(t,{emit:i}){const e=i,n=gt(null);function o(c){n.value=c}function s(c){const u={};return c.frontmatter.layout&&(u[mt]=c.frontmatter.layout),c.frontmatter.transition&&(u[Xt]=c.frontmatter.transition),c.frontmatter.background&&(u[jt]=c.frontmatter.background),c.notes&&(u[Ui]=c.notes),u}function l(c){n.value&&(c[mt]&&(n.value.frontmatter.layout=c[mt]),c[Xt]&&(n.value.frontmatter.transition=c[Xt]),c[jt]&&(n.value.frontmatter.background=c[jt]),c[Ui]&&(n.value.notes=c[Ui]),e("refresh"))}function r(c){e("navigate",c)}function a(c){if(!c.blocks||c.blocks.length===0)return"(空白页)";const u=c.blocks[0],m=u.content||u.rawMarkdown||"";return m.slice(0,40)+(m.length>40?"...":"")}return(c,u)=>(et(),it("div",Hp,[h("div",jp,[h("span",null,"幻灯片大纲 ("+St(t.slides.length)+" 页)",1)]),h("div",Up,[(et(!0),it(qt,null,we(t.slides,m=>(et(),it("div",{key:m.pageIndex,class:It(["spm-card",{active:t.currentActivePage===m.pageIndex}]),onClick:v=>r(m.pageIndex)},[h("div",Vp,[h("span",qp,"P"+St(m.pageIndex),1),h("span",Kp,St(m.frontmatter.layout||"default"),1),h("button",{class:"spm-card-btn-edit",title:"配置此页版式与属性",onClick:Me(v=>o(m),["stop"])},[at(ut,{name:"settings"})],8,Gp)]),h("div",Zp,St(a(m)),1),m.notes?(et(),it("div",Yp,[at(ut,{name:"notes",style:{"font-size":"11px","margin-right":"3px"}}),h("span",null,St(m.notes),1)])):Rt("",!0)],10,Wp))),128))]),n.value?(et(),it("div",{key:0,class:"spm-inspector-modal-mask",onClick:u[1]||(u[1]=Me(m=>n.value=null,["self"]))},[h("div",Jp,[at(Fp,{"block-id":n.value.startBlockId,"initial-attrs":s(n.value),onClose:u[0]||(u[0]=m=>n.value=null),onUpdated:l},null,8,["block-id","initial-attrs"])])])):Rt("",!0)]))}}),Qp=ze(Xp,[["__scopeId","data-v-68b25edd"]]),th={class:"spm-immersion-header"},eh={class:"spm-immersion-header__left"},ih={class:"spm-immersion-title"},nh={class:"spm-immersion-header__center"},oh={class:"spm-immersion-header__actions"},sh=["aria-label"],rh={class:"spm-immersion-body"},lh=_e({__name:"ImmersionDrawerContainer",props:{visible:{type:Boolean,default:!1},isMaximized:{type:Boolean,default:!1},title:{default:"速览"},closeOnClickMask:{type:Boolean,default:!0}},emits:["update:visible","update:isMaximized","close","toggle-maximize"],setup(t,{emit:i}){const e=t,n=i;function o(){n("update:visible",!1),n("close")}function s(){e.closeOnClickMask&&o()}function l(){n("update:isMaximized",!e.isMaximized),n("toggle-maximize")}function r(a){(a.key===" "||a.key==="ArrowLeft"||a.key==="ArrowRight"||a.key==="PageUp"||a.key==="PageDown")&&a.stopPropagation(),a.key==="Escape"&&(a.preventDefault(),a.stopPropagation(),o())}return(a,c)=>Te((et(),it("div",{class:It(["spm-immersion-container",{"is-maximized":t.isMaximized}]),onKeydown:Me(r,["stop"])},[h("div",{class:"spm-immersion-mask",onClick:s}),h("div",{class:It(["spm-immersion-drawer",{"is-maximized":t.isMaximized}])},[h("div",th,[h("div",eh,[Vn(a.$slots,"header-left",{},()=>[h("span",ih,St(t.title),1)])]),h("div",nh,[Vn(a.$slots,"header-center",{},void 0)]),h("div",oh,[Vn(a.$slots,"header-actions",{},void 0),h("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":t.isMaximized?"还原抽屉宽度 (70%)":"最大化填满视口 (100%)",onClick:l},[at(ut,{name:t.isMaximized?"minimize":"maximize"},null,8,["name"])],8,sh),h("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"关闭速览 (ESC)",onClick:o},[at(ut,{name:"close"})])])]),h("div",rh,[Vn(a.$slots,"default",{},void 0)])],2)],34)),[[ql,t.visible]])}}),ah=ze(lh,[["__scopeId","data-v-3f1665db"]]),ch={class:"spm-protyle-drawer"},dh={class:"spm-protyle-drawer__subbar"},uh={class:"spm-protyle-drawer__nav"},fh=["title"],ph={class:"spm-protyle-drawer__actions"},hh=["aria-label"],mh=["aria-label"],gh=_e({__name:"ProtylePeekDrawer",props:{blockId:{},title:{},plugin:{}},emits:["external-jump"],setup(t,{emit:i}){const e=i,n=t,o=gt(n.blockId),s=gt(n.title||""),l=gt(!1),r=gt(!0),a=gt(!1),c=gt(""),u=hi,m=gt([]),v=gt(null);let d=null;Li(()=>n.blockId,w=>{w&&w!==o.value&&(o.value=w,s.value=n.title||"",m.value=[],f(w))}),Pn(()=>{o.value&&f(o.value)}),Is(()=>{y()});async function b(w){try{const D=await yn(`SELECT id, root_id, type, content FROM blocks WHERE id = '${w}' LIMIT 1`);if(Array.isArray(D)&&D.length>0){const P=D[0];c.value=P.root_id||"";const R=P.id===P.root_id||P.type==="d";a.value=R,r.value=!R,!s.value&&P.content&&(s.value=P.content.trim().slice(0,30));return}}catch(D){console.warn("[ProtylePeekDrawer] detectBlockType query failed:",D)}a.value=!1,r.value=!0}async function f(w,D){if(!v.value||!w)return;y(),await b(w),typeof D=="boolean"&&(r.value=!a.value&&D);let P,R;r.value&&!a.value?(P=["cb-get-all","cb-get-hl","cb-get-focus"],R={background:!1,title:!1,gutter:!0,breadcrumbDocName:!0,scroll:!0}):(P=["cb-get-context","cb-get-hl"],R={background:!0,title:!0,gutter:!0,breadcrumbDocName:!0,scroll:!0});try{d=new ht.Protyle(n.plugin.app,v.value,{blockId:w,action:P,render:R}),!l.value&&d&&typeof d.disable=="function"&&d.disable()}catch(J){console.error("[ProtylePeekDrawer] Failed to instantiate Protyle:",J)}}function y(){if(d){try{typeof d.destroy=="function"&&d.destroy()}catch(w){console.warn("[ProtylePeekDrawer] Error destroying protyle:",w)}d=null}v.value&&(v.value.innerHTML="")}function k(){a.value||(r.value=!r.value,f(o.value,r.value))}function x(){l.value=!l.value,d&&(l.value?(typeof d.enable=="function"&&d.enable(),typeof d.focus=="function"&&d.focus()):typeof d.disable=="function"&&d.disable())}function C(){if(o.value)try{ht.openWindow({doc:{id:o.value},alwaysOnTop:!0})}catch(w){console.warn("[ProtylePeekDrawer] openWindow failed:",w)}}function A(){var P;if(!o.value)return;const w=To(),D=Zl(w.webServeUrl,o.value,{focus:!a.value});if(typeof window<"u"){const R=Ce("electron");(P=R==null?void 0:R.shell)!=null&&P.openExternal?R.shell.openExternal(D).catch(()=>{window.open(D,"_blank")}):window.open(D,"_blank")}e("external-jump",D)}function B(){if(m.value.length>0){const w=m.value.pop();w&&(o.value=w.blockId,s.value=w.title,r.value=w.isFocusMode,a.value=w.isDoc,f(w.blockId,w.isFocusMode))}}function I(w){const D=w.target;if(!D)return;const P=D.closest('[data-type="block-ref"]');if(P){const J=P.getAttribute("data-id");if(J&&J!==o.value){w.preventDefault(),w.stopPropagation(),m.value.push({blockId:o.value,title:s.value||o.value,isFocusMode:r.value,isDoc:a.value}),o.value=J,s.value=P.innerText.trim()||J,f(J);return}}const R=D.closest("a");if(R&&R.href&&R.href.startsWith("siyuan://blocks/")){w.preventDefault(),w.stopPropagation();const J=R.href.replace("siyuan://blocks/","").split("?")[0];J&&J!==o.value&&(m.value.push({blockId:o.value,title:s.value||o.value,isFocusMode:r.value,isDoc:a.value}),o.value=J,s.value=R.innerText.trim()||J,f(J))}}return(w,D)=>(et(),it("div",ch,[h("div",dh,[h("div",uh,[m.value.length>0?(et(),it("button",{key:0,class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"返回上层引用文档或块",onClick:B},[at(ut,{name:"arrow-left"}),D[0]||(D[0]=h("span",null,"返回",-1))])):Rt("",!0),h("span",{class:It(["spm-protyle-badge",{"is-focus":r.value&&!a.value}])},St(r.value&&!a.value?"思源块聚焦":"思源文档速览"),3),h("span",{class:"spm-protyle-id",title:s.value||o.value},St(s.value||o.value),9,fh)]),h("div",ph,[a.value?Rt("",!0):(et(),it("button",{key:0,class:It(["spm-icon-btn b3-tooltips b3-tooltips__s",{"is-primary":r.value}]),"aria-label":r.value?"当前为块聚焦模式（点击展开所属文档全文）":"当前为文档全文模式（点击切回仅聚焦当前块）",onClick:k},[at(ut,{name:r.value?"focus":"file-text"},null,8,["name"]),h("span",null,St(r.value?"块聚焦":"展开全文"),1)],10,hh)),h("button",{class:It(["spm-icon-btn b3-tooltips b3-tooltips__s",{"is-primary":l.value}]),"aria-label":l.value?"当前为即时编辑模式（点击切回只读）":"当前为只读速览模式（点击解锁即时编辑）",onClick:x},[at(ut,{name:l.value?"edit":"eye"},null,8,["name"]),h("span",null,St(l.value?"编辑中":"只读"),1)],10,mh),h("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"在置顶独立窗口中打开 (保留完整侧边栏与插件)",onClick:C},[at(ut,{name:"window"}),D[1]||(D[1]=h("span",null,"独立窗口",-1))]),vt(u).enableWebServeJump?(et(),it("button",{key:1,class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"在系统默认浏览器中打开 (外跳)",onClick:A},[at(ut,{name:"external-link"}),D[2]||(D[2]=h("span",null,"外跳",-1))])):Rt("",!0)])]),h("div",{ref_key:"mountEl",ref:v,class:It(["spm-protyle-mount",{"is-focus-mode":r.value&&!a.value}]),onClick:I},null,2)]))}}),vh=ze(gh,[["__scopeId","data-v-7e586ef3"]]),bh={class:"spm-webview-drawer"},yh={class:"spm-webview-toolbar"},kh={class:"spm-webview-toolbar__nav"},wh=["disabled"],xh=["disabled"],_h=["aria-label"],Sh={class:"spm-webview-toolbar__address"},Ch=["aria-label"],$h={class:"spm-webview-toolbar__actions"},Ih=["aria-label"],Ah={class:"spm-zoom-controller"},Bh=["disabled"],Th=["disabled"],Eh={key:1,class:"spm-webview-fallback"},Mh=["src"],Ar="Mozilla/5.0 (iPhone; CPU iPhone OS 17_4_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.4.1 Mobile/15E148 Safari/604.1",sa="siyuan-slidev-peek-view-mode";let ra="desktop";function Dh(){if(typeof window<"u"&&window.localStorage)try{const t=window.localStorage.getItem(sa);if(t==="mobile"||t==="desktop")return t}catch{}return ra}function Lh(t){if(ra=t,typeof window<"u"&&window.localStorage)try{window.localStorage.setItem(sa,t)}catch{}}const Ph=_e({__name:"WebviewPeekDrawer",props:{url:{},title:{},visible:{type:Boolean,default:!0}},emits:["external-jump"],setup(t,{emit:i}){const e=i,n=t,o=gt(ea()),s=gt(n.url),l=gt(n.url),r=gt(!1),a=gt(!1),c=gt(!1),u=gt(1),m=gt(!1),v=gt(Dh());let d=typeof navigator<"u"&&!navigator.userAgent.includes("iPhone")?navigator.userAgent:"";const b=_t(()=>v.value==="mobile"?Ar:d||void 0),f=gt(null),y=gt(null);let k=null,x=null,C=null;Li(()=>n.url,Y=>{Y&&Y!==s.value&&(s.value=Y,l.value=Y,v.value==="mobile"&&D(!1),f.value&&typeof f.value.loadURL=="function"&&f.value.loadURL(Y))}),Li(()=>n.visible,Y=>{if(Y)Z(),v.value==="mobile"&&D(!1);else if(f.value)try{typeof f.value.stop=="function"&&f.value.stop()}catch{}}),Pn(()=>{A(),y.value&&typeof ResizeObserver<"u"&&(k=new ResizeObserver(()=>{const Y=f.value;if(Y&&typeof Y.invalidate=="function")try{Y.invalidate()}catch{}}),k.observe(y.value)),x=Y=>{var pt;const ct=Y.message||((pt=Y.error)==null?void 0:pt.message);if(typeof ct=="string"&&ct.includes("Invalid guestInstanceId"))return Y.preventDefault(),Y.stopImmediatePropagation(),!0},window.addEventListener("error",x,!0),C=Y=>{const ct=Y.reason,pt=typeof ct=="string"?ct:ct==null?void 0:ct.message;typeof pt=="string"&&pt.includes("Invalid guestInstanceId")&&Y.preventDefault()},window.addEventListener("unhandledrejection",C)}),Is(()=>{if(B(),k&&(k.disconnect(),k=null),x&&(window.removeEventListener("error",x,!0),x=null),C&&(window.removeEventListener("unhandledrejection",C),C=null),f.value)try{typeof f.value.stop=="function"&&f.value.stop()}catch{}});function A(){const Y=f.value;Y&&(Y.addEventListener("dom-ready",I),Y.addEventListener("did-start-loading",P),Y.addEventListener("did-stop-loading",R),Y.addEventListener("did-navigate",J),Y.addEventListener("did-navigate-in-page",S),Y.addEventListener("new-window",H))}function B(){const Y=f.value;if(Y)try{Y.removeEventListener("dom-ready",I),Y.removeEventListener("did-start-loading",P),Y.removeEventListener("did-stop-loading",R),Y.removeEventListener("did-navigate",J),Y.removeEventListener("did-navigate-in-page",S),Y.removeEventListener("new-window",H)}catch{}}function I(){const Y=f.value;if(Y&&typeof Y.getUserAgent=="function"&&!d)try{const ct=Y.getUserAgent();ct&&!ct.includes("iPhone")&&(d=ct)}catch{}v.value==="mobile"&&D(!1),Z(),g()}function w(){const Y=v.value==="mobile"?"desktop":"mobile";v.value=Y,Lh(Y),D(!0)}function D(Y=!1){const ct=f.value;if(!ct)return;const pt=v.value==="mobile"?Ar:d;if(typeof ct.setUserAgent=="function"&&pt)try{ct.setUserAgent(pt)}catch(X){console.warn("[WebviewPeekDrawer] setUserAgent error:",X)}if(Y&&typeof ct.reload=="function")try{ct.reload()}catch(X){console.warn("[WebviewPeekDrawer] reload error:",X)}}function P(){r.value=!0}function R(){if(r.value=!1,g(),f.value&&typeof f.value.getURL=="function"){const Y=f.value.getURL();Y&&Y!=="about:blank"&&(s.value=Y,l.value=Y)}}function J(Y){Y!=null&&Y.url&&(s.value=Y.url,l.value=Y.url),g()}function S(Y){Y!=null&&Y.url&&(s.value=Y.url,l.value=Y.url),g()}function H(Y){Y&&Y.url&&(Y.preventDefault(),f.value&&typeof f.value.loadURL=="function"&&f.value.loadURL(Y.url))}function g(){const Y=f.value;Y&&(typeof Y.canGoBack=="function"&&(a.value=Y.canGoBack()),typeof Y.canGoForward=="function"&&(c.value=Y.canGoForward()))}function N(){f.value&&typeof f.value.goBack=="function"&&f.value.goBack()}function q(){f.value&&typeof f.value.goForward=="function"&&f.value.goForward()}function U(){f.value&&typeof f.value.reload=="function"&&f.value.reload()}function G(){let Y=l.value.trim();Y&&(/^https?:\/\//i.test(Y)||(Y=`https://${Y}`),s.value=Y,l.value=Y,f.value&&typeof f.value.loadURL=="function"&&f.value.loadURL(Y))}function Z(){const Y=f.value;if(Y&&typeof Y.setZoomFactor=="function")try{Y.setZoomFactor(u.value)}catch(ct){console.warn("[WebviewPeekDrawer] setZoomFactor error:",ct)}}function O(){u.value=Math.min(2.5,Math.round((u.value+.1)*10)/10),Z()}function E(){u.value=Math.max(.5,Math.round((u.value-.1)*10)/10),Z()}function z(){u.value=1,Z()}function rt(Y){Y.preventDefault(),Y.deltaY<0?O():Y.deltaY>0&&E()}async function nt(){if(typeof navigator<"u"&&navigator.clipboard)try{await navigator.clipboard.writeText(s.value),m.value=!0,setTimeout(()=>{m.value=!1},2e3)}catch(Y){console.warn("Copy url failed:",Y)}}function tt(){var ct;const Y=s.value;if(typeof window<"u"){const pt=Ce("electron");(ct=pt==null?void 0:pt.shell)!=null&&ct.openExternal?pt.shell.openExternal(Y).catch(()=>{window.open(Y,"_blank")}):window.open(Y,"_blank")}e("external-jump",Y)}return(Y,ct)=>{const pt=cd("webview");return et(),it("div",bh,[h("div",yh,[h("div",kh,[h("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s",disabled:!a.value,"aria-label":"后退",onClick:N},[at(ut,{name:"arrow-left"})],8,wh),h("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s",disabled:!c.value,"aria-label":"前进",onClick:q},[at(ut,{name:"arrow-right"})],8,xh),h("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":r.value?"正在加载...":"刷新页面",onClick:U},[at(ut,{name:"refresh"})],8,_h)]),h("div",Sh,[Te(h("input",{"onUpdate:modelValue":ct[0]||(ct[0]=X=>l.value=X),type:"text",class:"b3-text-field spm-url-input",placeholder:"https://...",spellcheck:"false",onKeydown:Su(G,["enter"])},null,544),[[mo,l.value]]),h("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":m.value?"已复制地址！":"复制网址",onClick:nt},[at(ut,{name:"copy"})],8,Ch)]),h("div",$h,[h("button",{class:It(["spm-icon-btn spm-mode-toggle b3-tooltips b3-tooltips__s",{"is-active":v.value==="mobile"}]),"aria-label":v.value==="mobile"?"当前为手机视图，点击切换为桌面视图":"当前为桌面视图，点击切换为手机视图",onClick:w},[at(ut,{name:v.value==="mobile"?"mobile":"desktop"},null,8,["name"])],10,Ih),h("div",Ah,[h("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"缩小 (Ctrl + -)",disabled:u.value<=.5,onClick:E},[at(ut,{name:"minus"})],8,Bh),h("button",{class:"spm-zoom-badge b3-tooltips b3-tooltips__s","aria-label":"重置 100% (Ctrl + 0)",onClick:z},St(Math.round(u.value*100))+"% ",1),h("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"放大 (Ctrl + +)",disabled:u.value>=2.5,onClick:O},[at(ut,{name:"plus"})],8,Th)]),h("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"在系统默认浏览器中打开 ↗",onClick:tt},[at(ut,{name:"external-link"}),ct[1]||(ct[1]=h("span",null,"外跳",-1))])])]),h("div",{ref_key:"containerEl",ref:y,class:It(["spm-webview-body",{"is-mobile":v.value==="mobile"}]),onWheel:Me(rt,["ctrl"])},[h("div",{class:It(["spm-webview-viewport",{"is-mobile":v.value==="mobile"}])},[o.value?(et(),De(pt,{key:0,ref_key:"webviewRef",ref:f,class:"spm-webview-frame",src:s.value,useragent:b.value,allowpopups:"true",partition:"persist:slidev-peek",style:{position:"absolute",top:"0",left:"0",width:"100%",height:"100%",display:"inline-flex"}},null,8,["src","useragent"])):(et(),it("div",Eh,[h("iframe",{class:"spm-webview-fallback-frame",src:s.value,frameborder:"0",sandbox:"allow-scripts allow-same-origin allow-forms allow-popups"},null,8,Mh),h("div",{class:"spm-fallback-bar"},[ct[2]||(ct[2]=h("span",null,"如页面受同源策略 (X-Frame-Options) 拦截无法显示，请",-1)),h("button",{class:"spm-icon-btn is-primary",onClick:tt}," 在新标签页中打开 ↗ ")])]))],2)],34)])}}}),Rh=ze(Ph,[["__scopeId","data-v-40e35375"]]);class Oh{constructor(){wt(this,"timers",new Map)}debounce(i,e,n=150){this.cancel(i);const o=setTimeout(()=>{this.timers.delete(i),e()},n);this.timers.set(i,o)}cancel(i){this.timers.has(i)&&(clearTimeout(this.timers.get(i)),this.timers.delete(i))}cancelAll(){for(const i of this.timers.values())clearTimeout(i);this.timers.clear()}hasPending(i){return this.timers.has(i)}}class zh{constructor(i){wt(this,"blockToPageMap",new Map);wt(this,"debounceCtrl",new Oh);wt(this,"activeBlockId","");wt(this,"activePageIndex",1);wt(this,"currentDocId","");wt(this,"bridge",null);i&&(this.bridge=i)}setBridge(i){this.bridge=i}setDocId(i){this.currentDocId=i}updateSlidesIndex(i){this.blockToPageMap.clear();for(const e of i){e.startBlockId&&this.blockToPageMap.set(e.startBlockId,e.pageIndex);for(const n of e.blocks)this.blockToPageMap.set(n.id,e.pageIndex)}}getPageByBlockId(i){return this.blockToPageMap.get(i)??null}onCursorFocusBlock(i){if(!i||i===this.activeBlockId)return;this.activeBlockId=i;let e=this.getPageByBlockId(i);!e&&(i===this.currentDocId||!this.currentDocId&&this.blockToPageMap.size>0)&&(e=1),e&&this.debounceCtrl.debounce("cursor-navigate",()=>{this.activePageIndex=e,this.bridge&&(this.bridge.navigatePage(e),this.bridge.highlightElement(i))},100)}getActiveBlockId(){return this.activeBlockId}setActiveBlockId(i){this.activeBlockId=i;const e=this.getPageByBlockId(i);e&&(this.activePageIndex=e)}getActivePageIndex(){return this.activePageIndex}destroy(){this.debounceCtrl.cancelAll(),this.blockToPageMap.clear(),this.bridge=null}}function Pi(t,i){var s,l;if(!t||typeof document>"u")return!1;const e=(s=globalThis.CSS)!=null&&s.escape?globalThis.CSS.escape(t):t.replace(/"/g,'\\"'),n=document.querySelector(`.protyle-wysiwyg [data-node-id="${e}"]`)||document.querySelector(`[data-node-id="${e}"]`);if(!n){if(i)try{return ht.openTab({app:i,doc:{id:t,action:["cb-get-hl","cb-get-focus","cb-get-context"]}}),!0}catch(r){console.warn("[SelectionMirror] openTab fallback failed:",r)}return!1}try{n.scrollIntoView({behavior:"smooth",block:"center",inline:"nearest"})}catch{n.scrollIntoView()}try{(l=n.focus)==null||l.call(n,{preventScroll:!0})}catch{}n.classList.add("protyle-wysiwyg--select");const o=n.style.outline;return n.style.outline="2px solid #3b82f6",n.style.transition="outline 0.3s ease",setTimeout(()=>{n.classList.remove("protyle-wysiwyg--select"),n.style.outline=o},1200),!0}function Nh(t){if(!t)return"";const i=t.split(`
`).map(l=>l.trim()).filter(Boolean);if(i.length===0)return"";if(!i.some(l=>/^#{1,6}\s+/.test(l)))return i.map(l=>he(l)).join("<br/>");const n=[];let o=[];const s=()=>{if(o.length>0){const l=o.map(r=>he(r)).join("<br/>");n.push(`<p class="slide-list-item-desc">${l}</p>`),o=[]}};for(const l of i){const r=l.match(/^(#{1,6})\s+(.*)$/);if(r){s();const a=r[1].length,c=r[2].trim();n.push(`<h${a} class="slide-list-item-title">${he(c)}</h${a}>`)}else o.push(l)}return s(),n.join(`
`)}function Fh(t){if(t.length===0)return"";const i=[],e=t[0],n=e.match(/^(#{1,6})\s+(.*)$/);if(n){const o=n[1].length,s=n[2].trim();i.push(`<h${o} class="slide-list-item-title">${he(s)}</h${o}>`)}else i.push(`<p class="slide-list-item-title">${he(e)}</p>`);if(t.length>1){const o=t.slice(1);let s=[];const l=()=>{if(s.length>0){const r=s.map(a=>he(a)).join("<br/>");i.push(`<p class="slide-list-item-desc">${r}</p>`),s=[]}};for(const r of o){const a=r.match(/^(#{1,6})\s+(.*)$/);if(a){l();const c=a[1].length,u=a[2].trim();i.push(`<h${c} class="slide-list-item-title">${he(u)}</h${c}>`)}else s.push(r)}l()}return i.join(`
`)+(i.length>0?`
`:"")}function la(t,i,e){var v,d,b,f;const n=t.split(`
`);if(!n.some(y=>/^(\s*)([-*+]|\d+\.)\s+/.test(y)))return null;const s=[],l=[];let r=!1;for(let y=0;y<n.length;y++){const k=n[y];if(!k.trim())continue;const x=k.match(/^(\s*)[-*+]\s+\[([ xX])\]\s+(.*)$/);if(x){const I=x[1].length,w=Math.floor(I/2);l.push({type:"task",level:w,checked:x[2].toLowerCase()==="x",text:x[3],media:[]});continue}const C=k.match(/^(\s*)[-*+]\s+(.*)$/);if(C){const I=C[1].length,w=Math.floor(I/2);l.push({type:"unordered",level:w,text:C[2],media:[]});continue}const A=k.match(/^(\s*)\d+\.\s+(.*)$/);if(A){l.length===0&&(r=!0);const I=A[1].length,w=Math.floor(I/2);l.push({type:"ordered",level:w,text:A[2],media:[]});continue}const B=k.trim();if(!(!B||/^\{:.*?\}$/.test(B)))if(l.length>0){const I=B.match(/^!\[(.*?)\]\((.*?)\)(?:\{:?[^}]*\})?$/);if(I){const P=/\.gif(?:\?|$)/i.test(I[2])?"list-item-gif":"list-item-img";l[l.length-1].media||(l[l.length-1].media=[]),l[l.length-1].media.push(`<div class="slide-list-media"><img alt="${le(I[1])}" src="${I[2]}" class="${P}" /></div>`);continue}if(B.match(/^<img\b[\s\S]*?\/?>$/i)){const D=B.replace(/\s+style="[^"]*"/gi,"");l[l.length-1].media||(l[l.length-1].media=[]),l[l.length-1].media.push(`<div class="slide-list-media">${D}</div>`);continue}if(/<video\b/i.test(B)){let D=B;if(!/<\/video>/i.test(D))for(;y+1<n.length&&!/<\/video>/i.test(D);)y++,D+=" "+n[y].trim();const P=((v=e==null?void 0:e.attributes)==null?void 0:v["custom-slidev-autoplay"])==="true"||/autoplay/i.test(D),R=((d=e==null?void 0:e.attributes)==null?void 0:d["custom-slidev-loop"])==="true"||/loop/i.test(D),J=((b=e==null?void 0:e.attributes)==null?void 0:b["custom-slidev-muted"])==="true"||P||/muted/i.test(D),S=((f=e==null?void 0:e.attributes)==null?void 0:f["custom-slidev-controls"])==="false",H=D.match(/\bsrc=["']([^"']+)["']/i),g=H?H[1]:"",N=['class="slide-video-player"'];S||N.push("controls"),P&&(N.push("autoplay"),N.push("playsinline")),R&&N.push("loop"),J&&N.push("muted"),N.push('preload="metadata"'),g&&N.push(`src="${g}"`);const q=D.match(/<video[^>]*>([\s\S]*?)<\/video>/i);let U=q?q[1].trim():"";!U&&g&&(U=`<source src="${g}" type="video/mp4" />您的浏览器不支持视频播放。`),l[l.length-1].media||(l[l.length-1].media=[]),l[l.length-1].media.push(`<div class="slide-list-media slide-video-container slide-media-container" data-autoplay="${P?"true":"false"}" data-muted="${J?"true":"false"}"><video ${N.join(" ")}>${U}</video></div>`);continue}l[l.length-1].text+=`
`+B}else s.push(B)}if(l.length===0)return null;const a=r?"ol":"ul",c=(i==null?void 0:i.listClassName)||(r?"pdf-list pdf-list--ordered":"pdf-list pdf-list--unordered"),u=l.map(y=>{const k=Nh(y.text),x=y.media&&y.media.length>0?`
${y.media.join(`
`)}`:"",C=y.level||0,A=C>0?` style="margin-left:${(C*1.25).toFixed(2)}em;${y.type==="unordered"?`list-style-type:${C%2===1?"circle":"square"} !important;`:""}"`:"",B=C>0?" slide-list-item--nested":"";if(y.type==="task"){const w=y.checked?' checked=""':"";return`<li class="pdf-task-item${B}"${A}><label><input type="checkbox" disabled=""${w}/> <span>${k}</span></label>${x}</li>`}return`<li${B?` class="${B.trim()}"`:""}${A}>${k}${x}</li>`}).join(`
`);return`${Fh(s)}<${a} class="${c}">
${u}
</${a}>`}function Hh(t,i,e){const n=(i==null?void 0:i.containerClassName)||"pdf-block",o=t.split(/\r?\n/),s=[];let l=[];for(let a=0;a<o.length;a++){const c=o[a],u=c.trim();if(/^#{1,6}\s+/.test(u)){l.length>0&&(s.push(l.join(`
`)),l=[]),s.push(u);continue}if(!u){l.length>0&&(s.push(l.join(`
`)),l=[]);continue}if(/^!\[.*?\]\(.*?\)$/.test(u)){l.length>0&&(s.push(l.join(`
`)),l=[]),s.push(u);continue}if(/<video\b/i.test(u)){l.length>0&&(s.push(l.join(`
`)),l=[]);let m=u;if(!/<\/video>/i.test(m))for(;a+1<o.length&&!/<\/video>/i.test(m);)a++,m+=`
`+o[a];s.push(m);continue}l.push(c)}return l.length>0&&s.push(l.join(`
`)),s.map(a=>{var d,b,f,y;const c=a.trim();if(!c)return"";const u=c.match(/^(#{1,6})\s+(.*)$/);if(u){const k=u[1].length;return`<h${k} class="slide-list-item-title">${he(u[2].trim())}</h${k}>`}const m=c.match(/^!\[(.*?)\]\((.*?)\)$/);if(m){const k=/\.gif(?:\?|$)/i.test(m[2]),x=(i==null?void 0:i.imageClassName)||(k?"list-item-gif":"pdf-image slide-media-img");return`<div class="${n} ${n}--image slide-media-block slide-media-container slide-list-media"><img alt="${le(m[1])}" src="${m[2]}" class="${x}" /></div>`}if(/<video\b/i.test(c)){const k=((d=e==null?void 0:e.attributes)==null?void 0:d["custom-slidev-autoplay"])==="true"||/autoplay/i.test(c),x=((b=e==null?void 0:e.attributes)==null?void 0:b["custom-slidev-loop"])==="true"||/loop/i.test(c),C=((f=e==null?void 0:e.attributes)==null?void 0:f["custom-slidev-muted"])==="true"||k||/muted/i.test(c),A=((y=e==null?void 0:e.attributes)==null?void 0:y["custom-slidev-controls"])==="false",B=c.match(/\bsrc=["']([^"']+)["']/i),I=B?B[1]:"",w=['class="slide-video-player"'];A||w.push("controls"),k&&w.push("autoplay playsinline"),x&&w.push("loop"),C&&w.push("muted"),w.push('preload="metadata"'),I&&w.push(`src="${I}"`);const D=c.match(/<video[^>]*>([\s\S]*?)<\/video>/i);let P=D?D[1].trim():"";return!P&&I&&(P=`<source src="${I}" type="video/mp4" />您的浏览器不支持视频播放。`),`<div class="${n} ${n}--video slide-media-block slide-video-container slide-media-container" data-autoplay="${k?"true":"false"}" data-muted="${C?"true":"false"}"><video ${w.join(" ")}>${P}</video></div>`}const v=la(c,i,e);return v||`<p class="slide-list-item-desc">${he(c)}</p>`}).filter(Boolean).join(`
`)}function an(t){if(!t)return!1;if(t.type==="h"||t.type==="NodeHeading")return!0;const i=(t.rawMarkdown||t.content||"").trim();return/^#{1,6}\s+/.test(i)}function jh(t,i){var r,a,c,u,m,v,d,b;const e=((r=t.frontmatter)==null?void 0:r.layout)||"default",o=(t.blocks||[]).filter(f=>f.slot!=="slot-divider-right"),l=e==="cover"?null:o.find(an);if(e==="two-cols"){const f=o.some(S=>S.slot==="right");let y=[],k=[];if(f)y=o.filter(S=>S.slot!=="right"),k=o.filter(S=>S.slot==="right");else{const S=Math.ceil(o.length/2);y=o.slice(0,S),k=o.slice(S)}const x=y.find(an),C=k.find(an),A=y.map(S=>ui(S,{...i,extraClassName:S===x?"slidev-col-first-heading-block":""})).join(`
`),B=k.map(S=>ui(S,{...i,extraClassName:S===C?"slidev-col-first-heading-block":""})).join(`
`),I="pdf-two-cols-wrapper layout-two-cols-grid",w=(a=t.frontmatter)!=null&&a.layoutClass?` ${t.frontmatter.layoutClass}`:"",D="pdf-col pdf-col--left",P="pdf-col pdf-col--right",J=`style="grid-template-columns: ${Wo((c=t.frontmatter)==null?void 0:c.layoutRatio,2)};"`;return`
      <div class="${I}${w}" ${J}>
        <div class="${D}">${A}</div>
        <div class="${P}">${B}</div>
      </div>
    `}if(ps(e)){let f=[];const y=o.filter(S=>S.slot==="header");if(y.length>0)f=y;else if(o.length>0){const S=o.find(H=>H.type==="h"&&(!H.slot||H.slot==="default"));S&&(f=[S])}const k=o.filter(S=>!f.includes(S));let x=2;if(e==="three-cols-header")x=3;else if(e==="two-cols-header")x=2;else{let S=0;for(const H of k){const g=(H.slot||"").match(/^col-(\d+)$/i);g&&(S=Math.max(S,parseInt(g[1],10)))}if(S>=2)x=S;else if((u=t.frontmatter)!=null&&u.layoutRatio){const H=t.frontmatter.layoutRatio.trim();if(H.includes(":")){const g=H.split(":").map(N=>parseFloat(N.trim())).filter(N=>!isNaN(N)&&N>0);g.length>=2&&(x=g.length)}else{const g=H.split(/\s+/).filter(Boolean);g.length>=2&&(x=g.length)}}else k.length===1&&k[0].children&&k[0].children.length>=2&&(x=Math.min(6,k[0].children.length))}const C=ta(k,x),A=S=>{const H=S.filter(N=>!!(N.rawMarkdown||N.content||"").trim());if(H.length>0){const N=H[0],q=(N.rawMarkdown||N.content||"").trim();(En(N)||/^(?:[-*+]|\d+\.)\s+/.test(q))&&(N.rawMarkdown=Yl(N.rawMarkdown||N.content||""),N.content=N.rawMarkdown)}const g=H.find(an);return H.map(N=>ui(N,{...i,extraClassName:N===g?"slidev-col-first-heading-block":""})).join(`
`)},B=f.find(an),I=f.map(S=>ui(S,{...i,extraClassName:S===B?"slidev-page-first-heading-block":""})).join(`
`),D=`style="grid-template-columns: ${Wo((m=t.frontmatter)==null?void 0:m.layoutRatio,x)};"`,P=["layout-cols-header-container",x===2?"layout-two-cols-header-container":"",x===3?"layout-three-cols-header-container":"",`layout-${e}-container`].filter(Boolean).join(" "),R=["layout-cols-wrapper","layout-cols-grid",x===2?"pdf-two-cols-wrapper layout-two-cols-grid":"",x===3?"pdf-three-cols-wrapper layout-three-cols-grid":""].filter(Boolean).join(" "),J=C.map((S,H)=>{const g=H+1;return`<div class="${["pdf-col",x===2&&g===1?"pdf-col--left":"",x===2&&g===2?"pdf-col--right":"",`pdf-col--${g}`,`col-${g}`].filter(Boolean).join(" ")}">${A(S)}</div>`}).join(`
`);return`
      <div class="${P}">
        <div class="layout-header-section">${I}</div>
        <div class="${R}" ${D}>
          ${J}
        </div>
      </div>
    `}if(e==="image-right"||e==="image-left"){const f=e==="image-right",y=o.map(I=>ui(I,i)).join(`
`),k=((v=t.frontmatter)==null?void 0:v.image)||((d=t.frontmatter)==null?void 0:d.background)||"",x=`<div class="pdf-image-col" style="background-image:url('${le(k)}');background-size:cover;background-position:center;background-repeat:no-repeat;width:100%;height:100%;position:relative;overflow:hidden;"><img src="${le(k)}" style="width:100%;height:100%;object-fit:cover;object-position:center;display:block;" onerror="this.style.display='none'" alt="Slide cover" /></div>`,C=`<div class="pdf-content-col" style="padding:48px 56px;display:flex;flex-direction:column;justify-content:flex-start;height:100%;box-sizing:border-box;overflow-y:auto;">${y}</div>`,A=f?`${C}
${x}`:`${x}
${C}`;return`
      <div class="layout-image-cols-grid" style="display:grid;grid-template-columns:${Wo((b=t.frontmatter)==null?void 0:b.layoutRatio,2)};grid-template-rows:100%;width:100%;height:100%;position:absolute;top:0;left:0;right:0;bottom:0;box-sizing:border-box;">
        ${A}
      </div>
    `}return e==="fact"?`<div class="layout-fact-container">${o.map(y=>ui(y,i)).join(`
`)}</div>`:e==="cover"?`<div class="layout-cover-container">${o.map(y=>ui(y,i)).join(`
`)}</div>`:o.map(f=>ui(f,{...i,extraClassName:f===l?"slidev-page-first-heading-block":""})).join(`
`)}function le(t){return t?t.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&#039;"):""}function Uh(t){if(!t||t.trim()===""||t.trim()==="all")return"all";const i=new Set,e=t.split("|");for(const n of e){const o=n.trim();if(o==="all")return"all";if(o.includes("-")){const[s,l]=o.split("-"),r=parseInt(s,10),a=parseInt(l,10);if(!isNaN(r)&&!isNaN(a))for(let c=Math.min(r,a);c<=Math.max(r,a);c++)i.add(c)}else{const s=parseInt(o,10);isNaN(s)||i.add(s)}}return i}const Wh=new Set(["kbd","mark","sub","sup","span","a","br","b","i","u","s","del","em","strong","code","small","abbr","ruby","rt","rp","v-mark","img","video","source","picture"]);function he(t){if(!t)return"";const i=Xl(t),e=[],n=i.replace(/<\/?([a-zA-Z0-9_-]+)(?:\s+[^<>]*)?\/?>/g,(s,l)=>{const r=l.toLowerCase();if(!Wh.has(r)||/on\w+\s*=|javascript:/i.test(s))return s;if(r==="v-mark"){const a=s.match(/type=["']?([a-zA-Z-]+)["']?/),c=a?a[1]:"circle";return s.startsWith("</")?e.push("</mark>"):e.push(`<mark class="v-mark v-mark--${c}">`),`%%SAFE_HTML_${e.length-1}%%`}return e.push(s),`%%SAFE_HTML_${e.length-1}%%`});let o=le(n);return o=o.replace(/\(\(([0-9a-zA-Z-]+)(?:\s*(?:&#039;([^&#]*)&#039;|&quot;([^&]*)&quot;|'([^']*)'|"([^"]*)"|([^\)]+?)))?\s*\)\)/g,(s,l,r,a,c,u,m)=>{const d=(r??a??c??u??m??"").trim()||`Ref(${l.slice(0,8)})`;return`<a href="siyuan://blocks/${l}" data-ref-id="${l}" class="slidev-ref-tag">🔗 ${d}</a>`}),o=o.replace(/\$([^$\n]+)\$/g,'<span class="katex-inline font-math"><em>$1</em></span>'),o=o.replace(/!\[(.*?)\]\((.*?)\)/g,(s,l,r)=>{const c=/\.gif(?:\?|$)/i.test(r)?"slide-inline-img list-item-gif":"slide-inline-img";return`<img alt="${l}" src="${r}" class="${c}" />`}),o=o.replace(/\[(.*?)\]\((.*?)\)/g,(s,l,r)=>{if(r.startsWith("siyuan://blocks/")){const a=r.replace("siyuan://blocks/","").split("?")[0];return`<a href="${r}" data-ref-id="${a}" class="slidev-ref-tag">🔗 ${l}</a>`}return`<a href="${r}" target="_blank" rel="noopener noreferrer" class="slidev-link">${l}</a>`}),o=o.replace(/(^|[\s(])(siyuan:\/\/blocks\/([0-9a-zA-Z-]+)(?:\?[^\s\)]*)?)/g,(s,l,r,a)=>`${l}<a href="${r}" data-ref-id="${a}" class="slidev-ref-tag">🔗 ${r}</a>`),o=o.replace(/\*\*(.*?)\*\*/g,"<strong>$1</strong>"),o=o.replace(/\*(.*?)\*/g,"<em>$1</em>"),o=o.replace(/~~(.*?)~~/g,"<del>$1</del>"),o=o.replace(/`([^`]+)`/g,"<code>$1</code>"),o=o.replace(/%%SAFE_HTML_(\d+)%%/g,(s,l)=>{const r=parseInt(l,10);return e[r]||""}),o}function Vh(t,i="pdf-table"){if(t.length<2)return"";const e=t.map(a=>a.trim().replace(/^\|/,"").replace(/\|$/,"").split("|").map(c=>c.trim())),n=e[0];let o=[],s=1;t.length>=2&&e[1].every(a=>/^:?-+:?$/.test(a))&&(o=e[1].map(a=>a.startsWith(":")&&a.endsWith(":")?"center":a.endsWith(":")?"right":"left"),s=2);const l=`<thead><tr>${n.map((a,c)=>`<th${o[c]?` style="text-align: ${o[c]}"`:""}>${he(a)}</th>`).join("")}</tr></thead>`,r=e.slice(s).map(a=>`<tr>${a.map((c,u)=>`<td${o[u]?` style="text-align: ${o[u]}"`:""}>${he(c)}</td>`).join("")}</tr>`).join("");return`<table class="${i}">${l}<tbody>${r}</tbody></table>`}function qo(t){return String(t||"").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;")}function Br(t,i="ts"){if(!t)return"";if(t.trim().startsWith("//"))return`<span class="token-comment">${qo(t)}</span>`;const e=[];function n(s,l){return e.push(`<span class="${s}">${qo(l)}</span>`),`__TOK_${e.length-1}__`}let o=t.replace(/(['"`])(.*?)\1/g,(s,l,r)=>n("token-string",`${l}${r}${l}`));return o=o.replace(/\b(import|export|from|const|let|var|function|return|default|type|interface|class|new|async|await)\b/g,s=>n("token-keyword",s)),o=o.replace(/\b(computed|ref|number|string|boolean|void|Array)\b/g,s=>n("token-type",s)),o=o.replace(/\b(\d+)\b/g,s=>n("token-number",s)),o=qo(o),o=o.replace(/__TOK_(\d+)__/g,(s,l)=>e[parseInt(l,10)]||""),o}function qh(t,i){if(!t)return null;const e=t.frontmatter||{};if(e.hideInToc===!0||e.hideInToc==="true")return null;let n=(e.title||"").trim(),o=e.level?parseInt(e.level,10):0;if(!n){const s=t.blocks||[];for(const l of s){const a=(l.rawMarkdown||l.content||"").trim().match(/^(#{1,6})\s+(.*)$/);if(a){o||(o=a[1].length),n=a[2].trim();break}}}return n?((!o||isNaN(o))&&(o=1),{pageIndex:t.pageIndex||i,title:n,level:o}):null}function Kh(t,i=1,e={}){const n=e.minDepth!==void 0?Number(e.minDepth):1,o=e.maxDepth!==void 0?Number(e.maxDepth):1/0,s=[];Array.isArray(t)&&t.forEach((c,u)=>{const m=qh(c,u+1);m&&s.push(m)});const l=[];let r=null;for(const c of s){const u={...c,active:c.pageIndex===i,hasActiveChild:!1,children:[]};c.level===1||l.length===0?(l.push(u),r=u):r?(u.active&&(r.hasActiveChild=!0),r.children.push(u)):l.push(u)}function a(c,u=1){if(u>o)return[];const m=[];for(const v of c){const d=a(v.children,u+1);u>=n?m.push({...v,children:d}):m.push(...d)}return m}return a(l,1)}function Gh(t,i=1,e={}){const n=Kh(t,i,e),o=e.columns?Number(e.columns):1,s=o>1?` style="column-count: ${o};"`:"",l=e.textSm?" text-sm":"";function r(c,u=1){if(!c||c.length===0)return"";const m=`slidev-toc-list slidev-toc-list-level-${u}`,v=c.map(d=>{const b=d.active?" slidev-toc-item-active":d.hasActiveChild?" slidev-toc-item-parent-active":"",f=d.children&&d.children.length>0?r(d.children,u+1):"";let y=he(d.title);return y.includes("LaTeX")&&(y=y.replace(/\$\\LaTeX\$/g,'<span class="font-math">L<sup>A</sup>T<sub>E</sub>X</span>')),`
        <li class="slidev-toc-item${b}" data-page="${d.pageIndex}">
          <a class="slidev-toc-link" href="javascript:void(0)">
            <span class="slidev-toc-title">${y}</span>
          </a>
          ${f}
        </li>
      `}).join("");return`<ol class="${m}">${v}</ol>`}const a=r(n,1);return`<div class="slidev-toc${l}"${s}>${a}</div>`}function ui(t,i){var k,x,C,A,B,I,w,D,P;let e="",n="",o="";const s=[];(k=t.motion)!=null&&k.preset&&t.motion.preset!=="none"&&(e=` slidev-motion-${t.motion.preset.toLowerCase()}`,typeof t.motion.duration=="number"&&t.motion.duration>0&&s.push(`--motion-duration:${t.motion.duration}ms`),typeof t.motion.delay=="number"&&t.motion.delay>0&&s.push(`--motion-delay:${t.motion.delay}ms`));const l=((x=t.attributes)==null?void 0:x.style)||"";l&&(s.push(l),o=" slide-styled-block"),s.length>0&&(n=` style="${le(s.join(";"))}"`);const r=(i==null?void 0:i.containerClassName)||"pdf-block",a=i!=null&&i.extraClassName?` ${i.extraClassName}`:"",c=`${r}${e}${o}${a}`,u=(t.rawMarkdown||t.content||"").trim();if(!u)return`<div class="${c}"${n}></div>`;if(u.includes('class="slidev-block-ref"')||u.includes('class="slidev-ref-tag"'))return`<div class="${c}"${n}>${u}</div>`;if(u.startsWith("$$")&&u.endsWith("$$")){const R=u.slice(2,-2).trim();return`<div class="${c} katex-display-container"${n}><div class="katex-display font-math"><em>${le(R)}</em></div></div>`}const m=u.match(/^(#{1,6})\s+(.*)$/);if(m){const R=m[1].length,J=he(m[2]);return`<div class="${c}"${n}><h${R}>${J}</h${R}></div>`}if(u.startsWith(":::")){const R=u.split(`
`),S=R[0].replace(/^:::\s*/,"").trim()||"info",H=R.slice(1,R[R.length-1].startsWith(":::")?-1:void 0).join(`
`),g=(i==null?void 0:i.calloutClassName)||"pdf-callout";return`<div class="${c}"${n}><div class="${g} ${g}--${S}"><div class="${g}-title">${S.toUpperCase()}</div><div class="${g}-body">${he(H)}</div></div></div>`}if(u.startsWith("<<<")){const S=`// Inside ./snippets/external.ts
export function emptyArray<T>(length: number) {
  return Array.from<T>({ length })
}`.split(`
`).map((q,U)=>`<span class="code-line shiki-focus"><span class="line-no">${U+1}</span><span class="line-content">${Br(q,"ts")}</span></span>`).join(`
`),H=(i==null?void 0:i.codeClassName)||"pdf-code shiki-container",g=((C=t.attrs)==null?void 0:C["custom-slidev-max-height"])||t.maxHeight||"",N=g?` style="max-height:${le(g)};overflow-y:auto;"`:"";return`<div class="${c}"${n}><pre class="${H}"${N}><span class="lang-badge">TS</span><code>${S}</code></pre></div>`}if(u.startsWith("<style")||u.startsWith("<!-- Inline style -->")||u.startsWith(`<!--
Notes`))return"";if(u.startsWith("```")){const R=u.split(`
`),J=R[0].slice(3).trim(),S=J.match(/^([^\s{\[]+)/),H=S?S[1]:"",g=J.match(/\[([^\]]+)\]/),N=g?g[1]:"",q=J.includes("twoslash"),U=t.shikiLines||((A=J.match(/\{([^}]+)\}/))==null?void 0:A[1])||"",G=Uh(U),Z=R.length>2?R[R.length-1]==="```"?R.slice(1,-1):R.slice(1):[u.slice(3).replace(/```$/,"")],O=(i==null?void 0:i.codeClassName)||"pdf-code shiki-container",E=N?`${O} has-filename`:O,z=G!=="all",rt=Z.map((pt,X)=>{const dt=X+1,T=G==="all"||G.has(dt)?"code-line shiki-focus":z?"code-line shiki-dimmed":"code-line";let p=(i==null?void 0:i.highlight)===!0?Br(pt,H):le(pt);return q&&pt.includes("doubled.value = 2")?(p=p.replace(/(\bvalue\b)/,'<span class="twoslash-error-wavy">$1</span>'),`<span class="${T}"><span class="line-no">${dt}</span><span class="line-content">${p}</span></span>
<div class="twoslash-popup-error"><span style="color:#ef4444;font-weight:bold;margin-right:4px;">✕</span> Cannot assign to 'value' because it is a read-only property.</div>`):`<span class="${T}"><span class="line-no">${dt}</span><span class="line-content">${p}</span></span>`}).join(`
`),nt=H?`<span class="lang-badge">${le(H)}</span>`:"",tt=N?`<span class="code-filename">${le(N)}</span>`:"",Y=((B=t.attrs)==null?void 0:B["custom-slidev-max-height"])||t.maxHeight||"",ct=Y?` style="max-height:${le(Y)};overflow-y:auto;"`:"";return`<div class="${c}"${n}><pre class="${E}"${ct}>${tt}${nt}<code>${rt}</code></pre></div>`}if(u.includes("|")&&u.split(`
`).filter(R=>R.trim().startsWith("|")).length>=2){const R=u.split(`
`).filter(S=>S.trim().startsWith("|")),J=Vh(R,i==null?void 0:i.tableClassName);return`<div class="${c}"${n}>${J}</div>`}if(u.startsWith("> ")){const R=(i==null?void 0:i.quoteClassName)||"pdf-quote";return`<div class="${c}"${n}><blockquote class="${R}"><p>${he(u.slice(2))}</p></blockquote></div>`}const v=/<video\b/i.test(u)||t.type==="video"||t.type==="NodeVideo",d=/^(\s*)([-*+]|\d+\.)\s+/m.test(u),b=/(?:^|\n)\s*#{1,6}\s+/.test(u);if(v&&!d&&!b&&!u.includes(`
`)){const R=((I=t.attributes)==null?void 0:I["custom-slidev-autoplay"])==="true"||/autoplay/i.test(u),J=((w=t.attributes)==null?void 0:w["custom-slidev-loop"])==="true"||/loop/i.test(u),S=((D=t.attributes)==null?void 0:D["custom-slidev-muted"])==="true"||R||/muted/i.test(u),H=((P=t.attributes)==null?void 0:P["custom-slidev-controls"])==="false",g=u.match(/\bsrc=["']([^"']+)["']/i),N=g?g[1]:"",q=['class="slide-video-player"'];H||q.push("controls"),R&&(q.push("autoplay"),q.push("playsinline")),J&&q.push("loop"),S&&q.push("muted"),q.push('preload="metadata"'),N&&q.push(`src="${N}"`);const U=u.match(/<video[^>]*>([\s\S]*?)<\/video>/i);let G=U?U[1].trim():"";return!G&&N&&(G=`<source src="${N}" type="video/mp4" />您的浏览器不支持视频播放。`),`<div class="${c} ${c}--video slide-media-block slide-video-container slide-media-container" data-autoplay="${R?"true":"false"}" data-muted="${S?"true":"false"}"${n}><video ${q.join(" ")}>${G}</video></div>`}const f=u.match(/^!\[(.*?)\]\((.*?)\)$/);if(f){const R=(i==null?void 0:i.imageClassName)||"pdf-image slide-media-img";return`<div class="${c} ${c}--image slide-media-block slide-media-container"${n}><img alt="${le(f[1])}" src="${f[2]}" class="${R}" /></div>`}const y=la(u,i,t);if(y)return`<div class="${c} pdf-list-item"${n}>${y}</div>`;if(/<(?:Toc|toc)\b/i.test(u)&&!u.startsWith("```")){const R=u.match(/minDepth=["']?(\d+)["']?/i),J=u.match(/maxDepth=["']?(\d+)["']?/i),S=u.match(/columns=["']?(\d+)["']?/i),H=(i==null?void 0:i.allSlides)||[];return`<div class="${c}"${n}>${Gh(H,(i==null?void 0:i.currentPageIndex)||1,{minDepth:R?parseInt(R[1],10):1,maxDepth:J?parseInt(J[1],10):1/0,columns:S?parseInt(S[1],10):1,textSm:u.includes("text-sm")})}</div>`}if(u.includes(`
`)||b){const R=Hh(u,i,t);if(R)return`<div class="${c}"${n}>${R}</div>`}return`<div class="${c}"${n}><p>${he(u)}</p></div>`}function Zh(t){return`
    ${bn(t)}

    :root {
      --slide-bg: #ffffff;
      --slide-text: #1a1a1a;
      --slide-accent: #3b82f6;
      --slide-font: system-ui, -apple-system, sans-serif;
    }
    [data-theme="dark"] {
      --slide-bg: #121214;
      --slide-text: #e2e8f0;
      --slide-accent: #60a5fa;
    }

    /* 1. 默认科技主题 Default */
    [data-slidev-theme="default"],
    .slidev-theme-default {
      --slide-font: system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "PingFang SC", "Microsoft YaHei", sans-serif;
      --slide-accent: #10b981;
    }
    [data-theme="light"][data-slidev-theme="default"],
    [data-theme="light"] .slidev-theme-default {
      --slide-bg: #ffffff;
      --slide-text: #1e293b;
      --slide-accent: #059669;
    }
    [data-theme="dark"][data-slidev-theme="default"],
    [data-theme="dark"] .slidev-theme-default {
      --slide-bg: #121214;
      --slide-text: #e2e8f0;
      --slide-accent: #34d399;
    }
    .slidev-theme-default .layout-cover h1,
    .slidev-theme-default .layout-cover .slide-block h1 {
      font-size: 3.8rem !important;
      font-weight: 800 !important;
      line-height: 1.15 !important;
      letter-spacing: -0.025em !important;
      margin-bottom: 18px !important;
      background: linear-gradient(135deg, #10b981, #06b6d4) !important;
      -webkit-background-clip: text !important;
      -webkit-text-fill-color: transparent !important;
    }
    .slidev-theme-default .layout-cover h2,
    .slidev-theme-default .layout-cover .slide-block h2 {
      font-size: 1.85rem !important;
      font-weight: 600 !important;
      opacity: 0.85 !important;
      margin-bottom: 12px !important;
    }
    .slidev-theme-default .layout-cover p,
    .slidev-theme-default .layout-cover .slide-block p {
      font-size: 1.45rem !important;
      line-height: 1.5 !important;
      opacity: 0.85 !important;
    }

    /* 2. 优雅衬线主题 Seriph */
    [data-slidev-theme="seriph"],
    .slidev-theme-seriph {
      --slide-font: "PT Serif", "Charter", "Georgia", "Cambria", "Times New Roman", "Source Han Serif SC", "Noto Serif SC", "Songti SC", "SimSun", serif;
      --slide-accent: #b45309;
      letter-spacing: 0.015em;
    }
    [data-theme="light"][data-slidev-theme="seriph"],
    [data-theme="light"] .slidev-theme-seriph {
      --slide-bg: #fdfbf7;
      --slide-text: #2a2521;
      --slide-accent: #b45309;
    }
    [data-theme="dark"][data-slidev-theme="seriph"],
    [data-theme="dark"] .slidev-theme-seriph {
      --slide-bg: #1c1a17;
      --slide-text: #e8e3d9;
      --slide-accent: #f59e0b;
    }
    .slidev-theme-seriph,
    .slidev-theme-seriph .slide-content {
      font-family: var(--slide-font) !important;
      line-height: 1.72;
    }
    .slidev-theme-seriph h1,
    .slidev-theme-seriph h2,
    .slidev-theme-seriph h3 {
      font-family: var(--slide-font) !important;
      letter-spacing: 0.025em;
      font-weight: 700;
    }
    .slidev-theme-seriph .layout-cover h1 {
      background: none !important;
      -webkit-background-clip: initial !important;
      -webkit-text-fill-color: initial !important;
      color: var(--slide-accent) !important;
      font-size: 3.4rem !important;
      border-bottom: 2px solid var(--slide-accent);
      display: inline-block;
      padding-bottom: 10px;
    }

    /* 3. 极简发布会主题 Apple Basic */
    [data-slidev-theme="apple-basic"],
    .slidev-theme-apple-basic {
      --slide-font: -apple-system, "SF Pro Display", "SF Pro Text", BlinkMacSystemFont, "PingFang SC", "Helvetica Neue", sans-serif;
      --slide-accent: #0071e3;
    }
    [data-theme="light"][data-slidev-theme="apple-basic"],
    [data-theme="light"] .slidev-theme-apple-basic {
      --slide-bg: #ffffff;
      --slide-text: #1d1d1f;
      --slide-accent: #0071e3;
    }
    [data-theme="dark"][data-slidev-theme="apple-basic"],
    [data-theme="dark"] .slidev-theme-apple-basic {
      --slide-bg: #000000;
      --slide-text: #f5f5f7;
      --slide-accent: #2997ff;
    }
    .slidev-theme-apple-basic,
    .slidev-theme-apple-basic .slide-content {
      font-family: var(--slide-font) !important;
    }
    .slidev-theme-apple-basic h1,
    .slidev-theme-apple-basic h2,
    .slidev-theme-apple-basic h3 {
      letter-spacing: -0.035em;
      font-weight: 800;
    }
    .slidev-theme-apple-basic .layout-cover h1 {
      background: none !important;
      -webkit-background-clip: initial !important;
      -webkit-text-fill-color: initial !important;
      color: var(--slide-text) !important;
      font-size: 3.8rem !important;
      letter-spacing: -0.04em !important;
    }
    .slidev-theme-apple-basic .layout-cover p {
      color: #86868b !important;
      font-size: 1.35rem !important;
    }

    * { box-sizing: border-box; margin: 0; padding: 0; }
    html, body {
      width: 100%; height: 100%; overflow: hidden;
      background: #0f1115; font-family: var(--slide-font);
      display: flex; justify-content: center; align-items: center;
    }
    #app { width: 100%; height: 100%; position: relative; overflow: hidden; }
    .slide-viewport {
      position: absolute; left: 50%; top: 50%;
      background: var(--slide-bg); color: var(--slide-text);
      box-shadow: 0 10px 30px rgba(0,0,0,0.5); border-radius: 8px; overflow: hidden;
      display: flex; flex-direction: column; flex-shrink: 0;
      transform: translate(-50%, -50%) scale(var(--slidev-slide-scale, 1));
      transform-origin: center center; will-change: transform;
      transition: background 0.3s ease, color 0.3s ease, border-radius 0.2s ease, box-shadow 0.2s ease;
    }
    :fullscreen .slide-viewport, .is-fullscreen .slide-viewport {
      border-radius: 0 !important; box-shadow: none !important;
    }
    .slide-content {
      position: relative;
      width: 100%;
      height: 100%;
      min-height: 100%;
      flex: 1 1 0%;
      padding: var(--slidev-padding-y, 32px) var(--slidev-padding-x, 48px);
      display: flex;
      flex-direction: column;
      overflow: hidden;
      box-sizing: border-box;
    }

    /* 间距预设风格 */
    .slide-content.spacing-compact,
    .slide-viewport[data-spacing="compact"] .slide-content,
    [data-slidev-spacing="compact"] {
      --slidev-padding-y: 20px;
      --slidev-padding-x: 36px;
      --slidev-header-gap: 10px;
      --slidev-title-margin-bottom: 6px;
    }
    .slide-content.spacing-normal,
    .slide-viewport[data-spacing="normal"] .slide-content,
    [data-slidev-spacing="normal"] {
      --slidev-padding-y: 32px;
      --slidev-padding-x: 48px;
      --slidev-header-gap: 16px;
      --slidev-title-margin-bottom: 10px;
    }
    .slide-content.spacing-loose,
    .slide-viewport[data-spacing="loose"] .slide-content,
    [data-slidev-spacing="loose"] {
      --slidev-padding-y: 48px;
      --slidev-padding-x: 56px;
      --slidev-header-gap: 24px;
      --slidev-title-margin-bottom: 16px;
    }

    .layout-cover { justify-content: center; align-items: center; text-align: center; }
    .layout-cover h1, .layout-cover .slide-block h1 { font-size: 3.8rem !important; font-weight: 800 !important; line-height: 1.15 !important; letter-spacing: -0.025em !important; margin-bottom: 16px !important; }
    .layout-cover h2, .layout-cover .slide-block h2 { font-size: 1.85rem !important; font-weight: 600 !important; opacity: 0.85 !important; margin-bottom: 12px !important; }
    .layout-cover p, .layout-cover .slide-block p { font-size: 1.45rem !important; line-height: 1.5 !important; opacity: 0.85 !important; }
    .two-cols-left, .two-cols-right { min-width: 0; width: 100%; display: flex; flex-direction: column; box-sizing: border-box; overflow-wrap: break-word; word-break: break-word; }
    .pdf-two-cols-wrapper,
    .layout-two-cols-grid,
    .layout-cols-wrapper,
    .layout-cols-grid {
      display: grid;
      grid-template-columns: var(--slide-grid-cols, minmax(0, 1fr) minmax(0, 1fr));
      grid-template-rows: minmax(0, 1fr) !important;
      gap: 32px;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      overflow: hidden !important;
    }
    .layout-cols-header-container,
    .layout-two-cols-header-container,
    .layout-three-cols-header-container {
      display: flex;
      flex-direction: column;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      overflow: hidden !important;
    }
    .layout-header-section {
      width: 100%;
      margin-bottom: var(--slidev-header-gap, 16px) !important;
      flex-shrink: 0;
    }
    .layout-header-section h1,
    .layout-header-section h2,
    .layout-header-section h3 {
      margin-bottom: var(--slidev-title-margin-bottom, 10px) !important;
    }
    .pdf-three-cols-wrapper,
    .layout-three-cols-grid {
      display: grid;
      grid-template-columns: var(--slide-grid-cols, minmax(0, 1fr) minmax(0, 1fr) minmax(0, 1fr));
      grid-template-rows: minmax(0, 1fr) !important;
      gap: 24px;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      box-sizing: border-box;
      overflow: hidden !important;
    }
    .pdf-col {
      display: flex;
      flex-direction: column;
      gap: 14px;
      min-width: 0;
      width: 100%;
      max-width: 100%;
      height: 100%;
      max-height: 100%;
      min-height: 0;
      justify-content: flex-start;
      box-sizing: border-box;
      overflow: hidden;
      overflow-wrap: break-word;
      word-break: break-word;
      white-space: normal;
    }
    .pdf-col * {
      overflow-wrap: break-word;
      word-break: break-word;
      box-sizing: border-box;
    }
    /* 表头多栏内超级块子块首个列表项去圆点后居中显示标题/首行文本 */
    .layout-cols-wrapper .pdf-col > *:first-child .slide-list-item-title,
    .layout-cols-wrapper .pdf-col > *:first-child > :is(h1, h2, h3, h4),
    .layout-cols-wrapper .pdf-col > *:first-child > p.slide-list-item-title,
    .layout-cols-header-container .pdf-col > *:first-child .slide-list-item-title,
    .layout-cols-header-container .pdf-col > *:first-child > :is(h1, h2, h3, h4),
    .layout-cols-header-container .pdf-col > *:first-child > p.slide-list-item-title,
    .two-cols-left > *:first-child .slide-list-item-title,
    .two-cols-right > *:first-child .slide-list-item-title {
      text-align: center !important;
      width: 100% !important;
    }

    /* 栏内说明段落与列表项：左对齐，自然阅读排版 */
    .layout-cols-wrapper .pdf-col .slide-list-item-desc,
    .layout-cols-header-container .pdf-col .slide-list-item-desc,
    .two-cols-left .slide-list-item-desc,
    .two-cols-right .slide-list-item-desc,
    .layout-cols-wrapper .pdf-col li,
    .layout-cols-header-container .pdf-col li,
    .two-cols-left li,
    .two-cols-right li {
      text-align: left !important;
    }

    /* 全局特定标题大小规范化 (除封面外页首首个标题按 H2 1.7rem，表头多栏内首个标题按 H3 1.3rem) */
    [data-normalize-headings="true"] .slidev-page-first-heading-block :is(h1, h2, h3, h4, h5, h6),
    [data-normalize-headings="true"] .slidev-page-first-heading-block:is(h1, h2, h3, h4, h5, h6),
    [data-normalize-headings="true"] .slide-content:not(.layout-cover) > .pdf-block:first-child :is(h1, h2, h3, h4, h5, h6),
    [data-normalize-headings="true"] .slide-content:not(.layout-cover) > .layout-header-section .pdf-block:first-child :is(h1, h2, h3, h4, h5, h6),
    [data-normalize-headings="true"] .slide-content:not(.layout-cover) > :not(.layout-cols-wrapper):not(.pdf-two-cols-wrapper):not(.layout-image-cols-grid):first-child :is(h1, h2, h3, h4, h5, h6) {
      font-size: 1.7rem !important;
      font-weight: 600 !important;
      line-height: 1.25 !important;
      margin-bottom: 10px !important;
    }

    [data-normalize-headings="true"] .slidev-col-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .slidev-col-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] :is(.layout-cols-wrapper, .pdf-two-cols-wrapper, .layout-cols-header-container) .pdf-col > *:first-child :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      font-size: 1.3rem !important;
      font-weight: 600 !important;
      line-height: 1.3 !important;
      margin-bottom: 8px !important;
    }
    .pdf-col pre,
    .two-cols-left pre,
    .two-cols-right pre,
    .image-right-content pre,
    .image-left-content pre {
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      overflow-x: hidden !important;
      overflow-y: auto !important;
      max-width: 100% !important;
      box-sizing: border-box !important;
    }
    .slide-content.layout-image-right, .slide-content.layout-image-left {
      padding: 0;
      display: grid;
      grid-template-columns: var(--slide-grid-cols, minmax(0, 1fr) minmax(0, 1fr));
      grid-template-rows: 100%;
      width: 100%;
      height: 100%;
      position: absolute;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      box-sizing: border-box;
    }
    .image-right-content, .image-left-content {
      padding: 44px 50px;
      display: flex;
      flex-direction: column;
      justify-content: flex-start;
      overflow-y: auto;
      width: 100%;
      height: 100%;
      box-sizing: border-box;
    }
    .image-right-img-container, .image-left-img-container {
      width: 100%;
      height: 100%;
      overflow: hidden;
      position: relative;
      background: #18181b;
      display: flex;
      align-items: center;
      justify-content: center;
    }
    .image-right-img, .image-left-img {
      width: 100%;
      height: 100%;
      object-fit: cover;
      object-position: center;
      display: block;
    }
    .slide-block { margin-bottom: 14px; line-height: 1.6; }
    .slide-block h1 { font-size: 2.2rem; margin-bottom: 12px; }
    .slide-block h2 { font-size: 1.7rem; margin-bottom: 10px; }
    .slide-block p { font-size: 1.15rem; }
    .slide-block ul, .slide-block ol, .pdf-list {
      padding-left: 28px;
      margin: 8px 0;
      display: flex;
      flex-direction: column;
      gap: 6px;
    }
    .slide-block li, .pdf-list li {
      font-size: 1.15rem;
      line-height: 1.6;
    }
    .pdf-task-item {
      list-style: none;
      margin-left: -20px;
      display: flex;
      align-items: center;
      gap: 8px;
    }
    .pdf-task-item input[type="checkbox"] {
      width: 1.15em;
      height: 1.15em;
      cursor: pointer;
    }

    /* 两栏与三栏及多栏（超级块分栏）布局：紧凑自然行距，子列表保留圆点与层级缩进 */
    .layout-two-cols ul,
    .layout-cols-header ul,
    .layout-two-cols-header ul,
    .layout-three-cols ul,
    .layout-three-cols-header ul,
    .two-cols-left ul,
    .two-cols-right ul,
    .three-cols-col ul,
    .col ul,
    .pdf-col ul,
    .layout-two-cols-grid .pdf-list,
    .layout-three-cols-grid .pdf-list,
    .layout-cols-grid .pdf-list,
    .layout-two-cols-grid .pdf-list--unordered,
    .layout-three-cols-grid .pdf-list--unordered,
    .layout-cols-grid .pdf-list--unordered {
      list-style: disc !important;
      list-style-type: disc !important;
      padding-left: 1.25em !important;
      margin-left: 0 !important;
      margin-top: 0 !important;
      margin-bottom: 8px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: block !important;
    }

    .layout-two-cols ol,
    .layout-cols-header ol,
    .layout-two-cols-header ol,
    .layout-three-cols ol,
    .layout-three-cols-header ol,
    .two-cols-left ol,
    .two-cols-right ol,
    .three-cols-col ol,
    .col ol,
    .pdf-col ol,
    .layout-two-cols-grid .pdf-list--ordered,
    .layout-three-cols-grid .pdf-list--ordered,
    .layout-cols-grid .pdf-list--ordered {
      list-style: decimal !important;
      list-style-type: decimal !important;
      padding-left: 1.25em !important;
      margin-left: 0 !important;
      margin-top: 0 !important;
      margin-bottom: 8px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: block !important;
    }

    .layout-two-cols li,
    .layout-cols-header li,
    .layout-two-cols-header li,
    .layout-three-cols li,
    .layout-three-cols-header li,
    .two-cols-left li,
    .two-cols-right li,
    .three-cols-col li,
    .col li,
    .pdf-col li,
    .pdf-col .pdf-list-item {
      padding-left: 0.2em !important;
      margin-left: 0 !important;
      margin-bottom: 6px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: list-item !important;
      line-height: 1.6 !important;
    }

    .layout-two-cols ul ul,
    .layout-three-cols ul ul,
    .three-cols-col ul ul,
    .pdf-col ul ul {
      list-style: circle !important;
      list-style-type: circle !important;
      padding-left: 1.25em !important;
      margin-top: 4px !important;
      margin-bottom: 4px !important;
    }

    /* 列表项内嵌标题与说明排版 */
    .slide-list-item-title,
    .pdf-list li > h1,
    .pdf-list li > h2,
    .pdf-list li > h3,
    .pdf-list li > h4,
    .pdf-list li > h5,
    .pdf-list li > h6,
    li > h1.slide-list-item-title,
    li > h2.slide-list-item-title,
    li > h3.slide-list-item-title,
    li > h4.slide-list-item-title {
      margin-top: 2px !important;
      margin-bottom: 6px !important;
      line-height: 1.35 !important;
      font-weight: 700 !important;
    }
    .pdf-list li > h1, li > h1.slide-list-item-title { font-size: 1.6rem !important; }
    .pdf-list li > h2, li > h2.slide-list-item-title { font-size: 1.4rem !important; }
    .pdf-list li > h3, li > h3.slide-list-item-title { font-size: 1.22rem !important; }
    .pdf-list li > h4, li > h4.slide-list-item-title { font-size: 1.1rem !important; }
    .slide-list-item-desc,
    .pdf-list li > p {
      margin-top: 4px !important;
      margin-bottom: 6px !important;
      font-size: 1.05rem;
      line-height: 1.55;
      opacity: 0.92;
    }

    /* 多媒体（GIF动图、静态图片、MP4视频）全视口最大化自适应且不超出视口 */
    .slide-media-block,
    .slide-media-container,
    .slide-video-container,
    .slide-block--media,
    .slide-block--image,
    .slide-block--video,
    .slide-block:has(> img),
    .slide-block:has(> .slide-media-container),
    .slide-block:has(> p > img:only-child),
    .slide-block:has(> .slide-video-container),
    .slide-block:has(> video) {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      min-width: 0 !important;
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
      justify-content: center !important;
      width: 100% !important;
      height: 100% !important;
      max-height: 100% !important;
      overflow: hidden !important;
      margin: 4px 0 !important;
      box-sizing: border-box !important;
    }

    .two-cols-left > .slide-block,
    .two-cols-right > .slide-block,
    .three-cols-col > .slide-block,
    .pdf-col > .slide-block,
    .pdf-col .slide-block {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      max-height: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      width: 100% !important;
      height: 100% !important;
      box-sizing: border-box !important;
      overflow: hidden !important;
      margin-bottom: 0 !important;
    }

    /* 列内列表项的标题与段落文字：固定高度，不压缩 */
    .two-cols-left .slide-list-item-title,
    .two-cols-right .slide-list-item-title,
    .three-cols-col .slide-list-item-title,
    .pdf-col .slide-list-item-title,
    .two-cols-left h1, .two-cols-left h2, .two-cols-left h3, .two-cols-left h4, .two-cols-left h5, .two-cols-left h6,
    .two-cols-right h1, .two-cols-right h2, .two-cols-right h3, .two-cols-right h4, .two-cols-right h5, .two-cols-right h6,
    .three-cols-col h1, .three-cols-col h2, .three-cols-col h3, .three-cols-col h4, .three-cols-col h5, .three-cols-col h6,
    .pdf-col h1, .pdf-col h2, .pdf-col h3, .pdf-col h4, .pdf-col h5, .pdf-col h6,
    .three-cols-col .slide-list-item-desc,
    .pdf-col .slide-list-item-desc {
      flex: 0 0 auto !important;
      margin-top: 0 !important;
      margin-bottom: 6px !important;
    }

    /* 列内媒体容器：填满标题下方所有剩余垂直空间，纵向顶部对齐，横向居中，无溢出 */
    .two-cols-left .slide-list-media,
    .two-cols-right .slide-list-media,
    .three-cols-col .slide-list-media,
    .pdf-col .slide-list-media,
    .two-cols-left .slide-video-container,
    .two-cols-right .slide-video-container,
    .three-cols-col .slide-video-container,
    .pdf-col .slide-video-container,
    .two-cols-left .slide-media-container,
    .two-cols-right .slide-media-container,
    .three-cols-col .slide-media-container,
    .pdf-col .slide-media-container {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      min-width: 0 !important;
      width: 100% !important;
      height: 100% !important;
      max-height: 100% !important;
      max-width: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
      justify-content: flex-start !important;
      overflow: hidden !important;
      margin: 0 !important;
      padding: 0 !important;
      box-sizing: border-box !important;
    }

    /* 列内多媒体播放器：以 contain 模式等比缩放完整可见，绝对不超高超宽、不产生遮挡与滚动条 */
    .two-cols-left video,
    .two-cols-right video,
    .three-cols-col video,
    .pdf-col video,
    .two-cols-left img,
    .two-cols-right img,
    .three-cols-col img,
    .pdf-col img,
    .two-cols-left .slide-video-player,
    .two-cols-right .slide-video-player,
    .three-cols-col .slide-video-player,
    .pdf-col .slide-video-player,
    .layout-three-cols-grid video,
    .layout-two-cols-grid video,
    .layout-three-cols-grid img,
    .layout-two-cols-grid img {
      max-width: 100% !important;
      max-height: 100% !important;
      width: auto !important;
      height: auto !important;
      min-width: 0 !important;
      min-height: 0 !important;
      object-fit: contain !important;
      display: block !important;
      margin: 0 auto !important;
      cursor: zoom-in;
    }

    .slide-block img,
    .slide-media-img,
    .slide-media-container img,
    .slide-video-player,
    video.slide-video-player,
    .slide-block video {
      max-width: 100% !important;
      max-height: 100% !important;
      width: auto !important;
      height: auto !important;
      min-width: 0 !important;
      min-height: 0 !important;
      object-fit: contain !important;
      display: block !important;
      margin: 0 auto !important;
      border-radius: 8px;
      box-shadow: 0 4px 16px rgba(0, 0, 0, 0.16);
      background: transparent;
      outline: none;
      cursor: zoom-in;
    }

    .slide-list-media {
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
      justify-content: flex-start !important;
      width: 100% !important;
      max-width: 100% !important;
      height: 100% !important;
      max-height: 100% !important;
      flex: 1 1 0% !important;
      margin-top: 4px !important;
      margin-bottom: 4px !important;
      min-height: 0 !important;
      overflow: hidden !important;
      box-sizing: border-box !important;
    }
    .slide-list-media img,
    .slide-list-media video,
    .slide-list-media .list-item-gif,
    .slide-list-media .slide-video-player {
      max-width: 100% !important;
      max-height: 100% !important;
      width: auto !important;
      height: auto !important;
      min-width: 0 !important;
      min-height: 0 !important;
      object-fit: contain !important;
      border-radius: 6px !important;
      box-shadow: 0 3px 12px rgba(0, 0, 0, 0.14) !important;
      display: block !important;
      margin: 0 auto !important;
      cursor: zoom-in;
    }

    .slide-block:has(.slide-list-media) {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      height: 100% !important;
      max-height: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      overflow: hidden !important;
    }
    .slide-block:has(.slide-list-media) .pdf-list,
    .slide-block:has(.slide-list-media) ul,
    .slide-block:has(.slide-list-media) ol {
      display: block !important;
      flex: 1 1 auto;
      min-height: 0;
      max-height: 100%;
      overflow: visible !important;
      list-style: disc !important;
      list-style-type: disc !important;
    }
    .slide-block:has(.slide-list-media) li,
    .slide-block:has(.slide-list-media) .slide-list-item,
    .slide-block:has(.slide-list-media) .pdf-list-item,
    .slide-block:has(.slide-media-container) li,
    .slide-block:has(.slide-video-container) li,
    .layout-cols-wrapper li:has(.slide-list-media),
    .layout-cols-header-container li:has(.slide-list-media),
    .two-cols-left li:has(.slide-list-media),
    .two-cols-right li:has(.slide-list-media),
    .three-cols-col li:has(.slide-list-media),
    .pdf-col li:has(.slide-list-media),
    li:has(.slide-list-media),
    li:has(.slide-video-container),
    li:has(.slide-media-container) {
      display: list-item !important;
      list-style-type: disc !important;
      flex: 0 0 auto !important;
      height: auto !important;
      max-height: none !important;
      overflow: visible !important;
      margin-bottom: 6px !important;
    }

    .layout-two-cols .slide-media-block,
    .layout-two-cols .slide-video-container,
    .layout-two-cols .slide-media-container,
    .layout-three-cols .slide-media-block,
    .layout-three-cols .slide-video-container,
    .layout-three-cols .slide-media-container {
      max-width: 100% !important;
      max-height: 100% !important;
      width: 100% !important;
      height: 100% !important;
      min-width: 0 !important;
      min-height: 0 !important;
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
      justify-content: flex-start !important;
      overflow: hidden !important;
    }

    /* Lightbox 大图与视频灯箱模态窗口 */
    .slidev-lightbox {
      position: fixed;
      top: 0;
      left: 0;
      width: 100vw;
      height: 100vh;
      background: rgba(0, 0, 0, 0.88);
      backdrop-filter: blur(8px);
      z-index: 999999;
      display: none;
      align-items: center;
      justify-content: center;
      cursor: zoom-out;
      opacity: 0;
      transition: opacity 0.2s cubic-bezier(0.16, 1, 0.3, 1);
    }
    .slidev-lightbox.active {
      display: flex;
      opacity: 1;
    }
    .slidev-lightbox-content {
      position: relative;
      max-width: 92vw;
      max-height: 92vh;
      display: flex;
      align-items: center;
      justify-content: center;
      cursor: default;
    }
    .slidev-lightbox-img {
      max-width: 92vw;
      max-height: 92vh;
      object-fit: contain;
      border-radius: 8px;
      box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.75);
    }
    .slidev-lightbox-video {
      max-width: 92vw;
      max-height: 92vh;
      border-radius: 8px;
      box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.75);
    }
    .slidev-lightbox-close {
      position: absolute;
      top: 24px;
      right: 28px;
      width: 40px;
      height: 40px;
      background: rgba(255, 255, 255, 0.2);
      border: 1px solid rgba(255, 255, 255, 0.35);
      border-radius: 50%;
      color: #fff;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 22px;
      cursor: pointer;
      transition: background 0.2s, transform 0.2s;
      z-index: 1000000;
    }
    .slidev-lightbox-close:hover {
      background: rgba(255, 255, 255, 0.35);
      transform: scale(1.05);
    }

    img.slide-inline-img {
      max-width: 100% !important;
      max-height: min(320px, 40vh) !important;
      object-fit: contain !important;
      vertical-align: middle;
      border-radius: 4px;
    }
    kbd {
      display: inline-block;
      padding: 2px 7px;
      font-family: ui-monospace, SFMono-Regular, "SF Mono", Menlo, Consolas, "Liberation Mono", monospace;
      font-size: 0.85em;
      font-weight: 600;
      line-height: 1.25;
      color: inherit;
      background: rgba(125, 125, 125, 0.12);
      border: 1px solid rgba(125, 125, 125, 0.35);
      border-bottom-width: 2px;
      border-radius: 5px;
      box-shadow: 0 1px 2px rgba(0, 0, 0, 0.12);
      margin: 0 2px;
      vertical-align: middle;
      white-space: nowrap;
    }
    [data-theme="dark"] kbd, .theme-dark kbd {
      background: rgba(255, 255, 255, 0.1);
      border-color: rgba(255, 255, 255, 0.25);
      border-bottom-color: rgba(255, 255, 255, 0.4);
      color: #f1f5f9;
      box-shadow: 0 1px 2px rgba(0, 0, 0, 0.4);
    }
    .slide-block pre,
    pre {
      background: rgba(0, 0, 0, 0.1);
      padding: 12px;
      border-radius: 6px;
      font-family: "JetBrains Mono", Consolas, monospace;
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      overflow-x: hidden !important;
      overflow-y: auto !important;
      max-width: 100% !important;
      box-sizing: border-box !important;
    }
    .slide-block pre code,
    pre code {
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      display: block !important;
      width: 100% !important;
      box-sizing: border-box !important;
    }
    .code-line {
      display: flex !important;
      align-items: flex-start !important;
      width: 100% !important;
      box-sizing: border-box !important;
      line-height: 1.6;
    }
    .code-line .line-no {
      display: inline-block !important;
      flex-shrink: 0 !important;
      min-width: 2.2em !important;
      text-align: right !important;
      margin-right: 12px !important;
      user-select: none !important;
      opacity: 0.45 !important;
    }
    .code-line .line-content {
      flex: 1 1 0% !important;
      min-width: 0 !important;
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
    }
    /* 弱提示滚动条样式 */
    * {
      scrollbar-width: thin;
      scrollbar-color: rgba(255, 255, 255, 0.20) transparent;
    }
    *::-webkit-scrollbar {
      width: 4px;
      height: 4px;
    }
    *::-webkit-scrollbar-track {
      background: transparent;
    }
    *::-webkit-scrollbar-thumb {
      background: rgba(255, 255, 255, 0.20);
      border-radius: 2px;
      transition: background 0.2s ease;
    }
    *:hover::-webkit-scrollbar-thumb,
    *::-webkit-scrollbar-thumb:hover {
      background: rgba(255, 255, 255, 0.45);
    }
    /* Slidev Micro-motion Keyframes & Presets */
    @keyframes slidevMotionFadeIn { from { opacity: 0; } to { opacity: 1; } }
    @keyframes slidevMotionSlideUp { from { opacity: 0; transform: translateY(40px); } to { opacity: 1; transform: translateY(0); } }
    @keyframes slidevMotionSlideDown { from { opacity: 0; transform: translateY(-40px); } to { opacity: 1; transform: translateY(0); } }
    @keyframes slidevMotionSlideLeft { from { opacity: 0; transform: translateX(40px); } to { opacity: 1; transform: translateX(0); } }
    @keyframes slidevMotionSlideRight { from { opacity: 0; transform: translateX(-40px); } to { opacity: 1; transform: translateX(0); } }
    @keyframes slidevMotionZoomIn { from { opacity: 0; transform: scale(0.8); } to { opacity: 1; transform: scale(1); } }
    @keyframes slidevMotionBounce {
      0% { opacity: 0; transform: translateY(40px); }
      60% { opacity: 1; transform: translateY(-8px); }
      80% { transform: translateY(4px); }
      100% { transform: translateY(0); }
    }
    .slidev-motion-fade-in { animation: slidevMotionFadeIn var(--motion-duration, 0.4s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slidev-motion-slide-up { animation: slidevMotionSlideUp var(--motion-duration, 0.45s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slidev-motion-slide-down { animation: slidevMotionSlideDown var(--motion-duration, 0.45s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slidev-motion-slide-left { animation: slidevMotionSlideLeft var(--motion-duration, 0.45s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slidev-motion-slide-right { animation: slidevMotionSlideRight var(--motion-duration, 0.45s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slidev-motion-zoom-in, .slidev-motion-pop { animation: slidevMotionZoomIn var(--motion-duration, 0.4s) cubic-bezier(0.34, 1.56, 0.64, 1) var(--motion-delay, 0s) both; }
    .slidev-motion-bounce { animation: slidevMotionBounce var(--motion-duration, 0.6s) cubic-bezier(0.34, 1.56, 0.64, 1) var(--motion-delay, 0s) both; }
    .controls {
      position: absolute; bottom: 16px; display: flex; gap: 12px; align-items: center;
      background: rgba(24, 24, 27, 0.8); backdrop-filter: blur(8px);
      padding: 6px 18px; border-radius: 20px; color: #fff; font-size: 13px; z-index: 10;
    }
    .controls button { background: transparent; border: none; color: inherit; cursor: pointer; padding: 2px 6px; }

    /* Slidev Native Icons & Interactive Buttons */
    .slidev-icon-btn {
      display: inline-flex !important; flex-direction: row !important; align-items: center !important; justify-content: center !important;
      padding: 0.35rem 0.5rem; border-radius: 0.375rem; background: transparent;
      border: 1px solid transparent; color: inherit; font-size: inherit; line-height: 1;
      cursor: pointer; opacity: 0.8; transition: all 0.2s ease; text-decoration: none;
      vertical-align: middle; user-select: none; margin: 0 4px;
    }
    .slidev-icon-btn:hover { opacity: 1; background: rgba(255, 255, 255, 0.12); border-color: rgba(255, 255, 255, 0.15); }

    /* 组件从上到下按顺序流式渲染，避免相互重叠 */
    .slide-block > div + div { margin-top: 14px; }

    /* 同一个 div 内的按钮/链接从左到右水平渲染 */
    .slide-block div:has(> .slidev-icon-btn),
    .slide-block div:has(> button),
    .slide-block [class*="abs-"],
    .slidev-btn-row {
      display: inline-flex !important;
      flex-direction: row !important;
      align-items: center !important;
      justify-content: center !important;
      flex-wrap: wrap !important;
      gap: 8px !important;
    }

    /* Position Shortcuts 适配：在组件流中保持从上到下排列，不脱离流产生重叠 */
    .slide-block .abs-br,
    .slide-block .abs-bl,
    .slide-block .abs-tr,
    .slide-block .abs-tl,
    .slide-block [class*="abs-"] {
      position: relative !important;
      bottom: auto !important;
      right: auto !important;
      top: auto !important;
      left: auto !important;
      margin: 0.75rem auto !important;
    }

    .slide-block--absolute { position: relative !important; margin-bottom: 14px !important; padding: 0 !important; background: transparent !important; }
    .slide-block--absolute:hover { background: transparent !important; }
    .mt-12 { margin-top: 3rem !important; }
    .py-1 { padding-top: 0.25rem !important; padding-bottom: 0.25rem !important; }
    .m-6 { margin: 1.5rem !important; }
    .text-xl { font-size: 1.25rem !important; }
    [hover\\:bg~="white"][hover\\:bg~="op-10"]:hover,
    [hover\\:bg="white op-10"]:hover { background: rgba(255, 255, 255, 0.1) !important; border-radius: 4px; }
    .cursor-pointer, [data-clickable] { cursor: pointer; }
    /* Slidev 规范链接排版 (继承正文颜色，虚线底边，Hover 时平滑点亮为主题色并转为实线) */
    .slide-content a:not(.slidev-ref-tag):not(.slidev-icon-btn):not(.slidev-toc-link),
    .slide-block a:not(.slidev-ref-tag):not(.slidev-icon-btn):not(.slidev-toc-link),
    a.slidev-link {
      color: inherit;
      text-decoration: none;
      border-bottom: 1px dashed currentColor;
      transition: color 0.2s cubic-bezier(0.4, 0, 0.2, 1),
                  border-color 0.2s cubic-bezier(0.4, 0, 0.2, 1),
                  border-bottom-style 0.2s cubic-bezier(0.4, 0, 0.2, 1);
      cursor: pointer;
    }
    .slide-content a:not(.slidev-ref-tag):not(.slidev-icon-btn):not(.slidev-toc-link):hover,
    .slide-block a:not(.slidev-ref-tag):not(.slidev-icon-btn):not(.slidev-toc-link):hover,
    a.slidev-link:hover {
      color: var(--slide-accent);
      border-bottom-style: solid;
      border-bottom-color: var(--slide-accent);
    }
    .slidev-ref-tag, a.slidev-ref-tag {
      display: inline-flex;
      align-items: center;
      background: color-mix(in srgb, var(--slide-accent) 12%, transparent);
      color: var(--slide-accent);
      border-radius: 4px;
      padding: 2px 8px;
      font-size: 0.88em;
      text-decoration: none;
      cursor: pointer;
      margin: 2px 4px 2px 0;
      border: 1px solid color-mix(in srgb, var(--slide-accent) 25%, transparent);
      transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
    }
    .slidev-ref-tag:hover, a.slidev-ref-tag:hover {
      background: color-mix(in srgb, var(--slide-accent) 22%, transparent);
      color: var(--slide-accent);
      border-color: color-mix(in srgb, var(--slide-accent) 55%, transparent);
      transform: translateY(-1px);
      box-shadow: 0 2px 8px color-mix(in srgb, var(--slide-accent) 20%, transparent);
    }
    .slidev-block-ref {
      display: block;
      padding: 10px 14px;
      background: color-mix(in srgb, var(--slide-accent) 8%, transparent);
      border-left: 3px solid var(--slide-accent);
      border-radius: 0 6px 6px 0;
      margin: 8px 0;
      cursor: pointer;
      transition: background 0.2s ease;
    }
    .slidev-block-ref:hover {
      background: color-mix(in srgb, var(--slide-accent) 15%, transparent);
    }`}function Yh(){return`    (function() {
      const data = window.__SLIDEV_DATA__ || { slides: [] };
      const slides = data.slides || [];
      let currentIndex = 0;

      const container = document.getElementById("slide-container");
      const pageNum = document.getElementById("page-num");
      const btnPrev = document.getElementById("btn-prev");
      const btnNext = document.getElementById("btn-next");
      const btnFullscreen = document.getElementById("btn-fullscreen");

      const baseWidth = 980;
      const aspectStr = (data.config && data.config.aspectRatio) || "16/9";
      let ratioNum = 16 / 9;
      if (aspectStr === "4/3") ratioNum = 4 / 3;
      else if (aspectStr === "16/10") ratioNum = 16 / 10;
      else if (typeof aspectStr === "string" && aspectStr.includes("/")) {
        const parts = aspectStr.split("/").map(Number);
        if (parts[0] && parts[1]) ratioNum = parts[0] / parts[1];
      }
      const baseHeight = Math.ceil(baseWidth / ratioNum);
      const viewport = document.getElementById("viewport");

      function updateScale() {
        if (!viewport) return;
        const isFull = !!document.fullscreenElement;
        const padX = isFull ? 0 : 20;
        const padY = isFull ? 0 : 32;
        const availW = Math.max(100, window.innerWidth - padX);
        const availH = Math.max(100, window.innerHeight - padY);
        const scale = Math.min(availW / baseWidth, availH / baseHeight);
        viewport.style.width = baseWidth + "px";
        viewport.style.height = baseHeight + "px";
        viewport.style.transform = "translate(-50%, -50%) scale(" + scale + ")";
        viewport.style.setProperty("--slidev-slide-scale", scale);
        if (isFull) document.body.classList.add("is-fullscreen");
        else document.body.classList.remove("is-fullscreen");
      }

      window.addEventListener("resize", updateScale);
      document.addEventListener("fullscreenchange", updateScale);

      function cleanCardListItemMarkdown(rawMarkdown) {
        if (!rawMarkdown) return "";
        let cleaned = rawMarkdown.replace(/^[ 	]*[-*+]s+|^[ 	]*d+.s+/, "");
        cleaned = cleaned.replace(/
[ 	]{2,4}/g, "
");
        return cleaned.trim();
      }

      function cleanColList(blocks) {
        const valid = (blocks || []).filter(b => Boolean((b.rawMarkdown || b.content || "").trim()));
        if (valid.length === 0) return valid;
        const first = valid[0];
        const md = (first.rawMarkdown || first.content || "").trim();
        const isList = /^(?:[-*+]|d+.)s+/.test(md) || first.type === "i" || first.type === "l";
        if (isList) {
          first.rawMarkdown = cleanCardListItemMarkdown(first.rawMarkdown || first.content || "");
          first.content = first.rawMarkdown;
        }
        return valid;
      }

      function renderBlock(block) {
        const div = document.createElement("div");
        div.className = "slide-block";
        if (block && block.motion && block.motion.preset && block.motion.preset !== "none") {
          div.classList.add("slidev-motion-" + block.motion.preset.toLowerCase());
          if (typeof block.motion.duration === "number" && block.motion.duration > 0) {
            div.style.setProperty("--motion-duration", block.motion.duration + "ms");
          }
          if (typeof block.motion.delay === "number" && block.motion.delay > 0) {
            div.style.setProperty("--motion-delay", block.motion.delay + "ms");
          }
        }
        const md = block.rawMarkdown || block.content || "";

        if (md.includes('class="slidev-block-ref"') || md.includes('class="slidev-ref-tag"')) {
          div.innerHTML = md;
          return div;
        }

        const CARBON_MAP = {
          'carbon:arrow-right': '<svg viewBox="0 0 32 32" width="1.2em" height="1.2em" fill="currentColor" style="display:inline-block;vertical-align:middle;"><path d="m18 6l-1.43 1.393L24.15 15H4v2h20.15l-7.58 7.573L18 26l10-10z"/></svg>',
          'carbon:arrow-left': '<svg viewBox="0 0 32 32" width="1.2em" height="1.2em" fill="currentColor" style="display:inline-block;vertical-align:middle;"><path d="m14 26l1.43-1.393L7.85 17H28v-2H7.85l7.58-7.573L14 6L4 16z"/></svg>',
          'carbon:edit': '<svg viewBox="0 0 32 32" width="1.2em" height="1.2em" fill="currentColor" style="display:inline-block;vertical-align:middle;"><path d="M2 26h28v2H2zM25.4 9c.8-.8.8-2 0-2.8l-3.6-3.6c-.8-.8-2-.8-2.8 0l-15 15V24h6.4l15-15zM20.4 4L24 7.6l-2.4 2.4l-3.6-3.6L20.4 4zM6 22v-3.6l11-11l3.6 3.6l-11 11H6z"/></svg>',
          'carbon:logo-github': '<svg viewBox="0 0 32 32" width="1.2em" height="1.2em" fill="currentColor" style="display:inline-block;vertical-align:middle;"><path fill-rule="evenodd" d="M16 2a14 14 0 0 0-4.43 27.28c.7.13 1-.3 1-.67v-2.38c-3.89.84-4.71-1.88-4.71-1.88a3.7 3.7 0 0 0-1.56-2.05c-1.27-.86.1-.85.1-.85a2.94 2.94 0 0 1 2.14 1.44a3 3 0 0 0 4.08 1.16a2.93 2.93 0 0 1 .89-1.87c-3.1-.35-6.36-1.55-6.36-6.9a5.4 5.4 0 0 1 1.44-3.75a5 5 0 0 1 .14-3.71s1.17-.38 3.85 1.43a13.3 13.3 0 0 1 7 0c2.67-1.81 3.84-1.43 3.84-1.43a5 5 0 0 1 .14 3.71a5.4 5.4 0 0 1 1.44 3.75c0 5.37-3.27 6.54-6.38 6.89a3.35 3.35 0 0 1 1.26 2.61v3.87c0 .38.26.81 1 .67A14 14 0 0 0 16 2"/></svg>'
        };

        if (/@\\w+=['"]|v-\\w+|<button|<a\\b|<carbon:|^<div/i.test(md)) {
          if (md.includes('abs-br') || md.includes('abs-bl') || md.includes('abs-tr') || md.includes('abs-tl') || md.includes('absolute')) {
            div.classList.add("slide-block--absolute");
          }
          let renderedHtml = md;
          for (const [tag, svg] of Object.entries(CARBON_MAP)) {
            const regex = new RegExp("<" + tag + "\\\\s*\\\\/?>", "gi");
            renderedHtml = renderedHtml.replace(regex, svg);
            const regexDash = new RegExp("<" + tag.replace(":", "-") + "\\\\s*\\\\/?>", "gi");
            renderedHtml = renderedHtml.replace(regexDash, svg);
          }
          div.innerHTML = renderedHtml;

          // 挂载交互事件监听
          const nextBtns = div.querySelectorAll('[\\\\@click*="nav.next"], [\\\\@click*="next"]');
          nextBtns.forEach(btn => {
            btn.style.cursor = "pointer";
            btn.addEventListener("click", (e) => {
              e.stopPropagation();
              renderSlide(currentIndex + 1);
            });
          });

          const prevBtns = div.querySelectorAll('[\\\\@click*="nav.prev"], [\\\\@click*="prev"]');
          prevBtns.forEach(btn => {
            btn.style.cursor = "pointer";
            btn.addEventListener("click", (e) => {
              e.stopPropagation();
              renderSlide(currentIndex - 1);
            });
          });

          return div;
        }

        const hasHeadingTag = /(?:^|
)s*#{1,6}s+/.test(md);

        if (md.startsWith("### ")) div.innerHTML = "<h3>" + md.slice(4) + "</h3>";
        else if (md.startsWith("## ")) div.innerHTML = "<h2>" + md.slice(3) + "</h2>";
        else if (md.startsWith("# ")) div.innerHTML = "<h1>" + md.slice(2) + "</h1>";
        else if (md.startsWith("\`\`\`")) {
          const customMaxHeight = block?.attributes?.["custom-slidev-max-height"] || block?.attrs?.["custom-slidev-max-height"] || block?.maxHeight || "";
          const heightStyle = customMaxHeight ? ' style="max-height:' + customMaxHeight + ';overflow-y:auto;"' : "";
          div.innerHTML = "<pre" + heightStyle + "><code>" + md.slice(3, -3) + "</code></pre>";
        }
        else if (md.startsWith("> ")) div.innerHTML = "<blockquote><p>" + md.slice(2) + "</p></blockquote>";
        else if ((/<video\b/i.test(md) || (block && (block.type === "video" || block.type === "NodeVideo"))) && !/^(s*)([-*+]|d+.)s+/m.test(md) && !hasHeadingTag && !md.includes("
")) {
          div.classList.add("slide-video-container", "slide-media-container", "slide-media-block");
          const isAutoplay = block && block.attributes && block.attributes["custom-slidev-autoplay"] === "true";
          const isLoop = block && block.attributes && block.attributes["custom-slidev-loop"] === "true";
          const isMuted = block && block.attributes && (block.attributes["custom-slidev-muted"] === "true" || isAutoplay);
          const hideControls = block && block.attributes && block.attributes["custom-slidev-controls"] === "false";
          let videoHtml = md;
          if (hideControls) videoHtml = videoHtml.replace(/\bcontrols(?:="[^"]*")?/gi, "").trim();
          else if (!videoHtml.includes("controls")) videoHtml = videoHtml.replace("<video", "<video controls");
          if (isAutoplay && !videoHtml.includes("autoplay")) videoHtml = videoHtml.replace("<video", "<video autoplay playsinline");
          if (isLoop && !videoHtml.includes("loop")) videoHtml = videoHtml.replace("<video", "<video loop");
          if (isMuted && !videoHtml.includes("muted")) videoHtml = videoHtml.replace("<video", "<video muted");
          videoHtml = videoHtml.replace("<video", '<video class="slide-video-player"');
          div.setAttribute("data-autoplay", isAutoplay ? "true" : "false");
          div.innerHTML = videoHtml;
        }
        else if (/^(s*)([-*+]|d+.)s+/m.test(md) || (md.includes("
") && /^(s*)([-*+]|d+.)s+/m.test(md.split("
").slice(1).join("
")))) {
          div.classList.add("pdf-list-item");
          const lines = md.split("
");
          let isOrdered = false;
          const items = [];
          const leadLines = [];
          for (let i = 0; i < lines.length; i++) {
            const line = lines[i];
            const tr = line.trim();
            if (!tr || /^{:.*?}$/.test(tr)) continue;
            const um = line.match(/^(s*)[-*+]s+(.*)$/);
            const om = line.match(/^(s*)d+.s+(.*)$/);
            if (um) {
              const indent = um[1].length;
              items.push({ type: "unordered", level: Math.floor(indent / 2), text: um[2], media: [] });
              continue;
            }
            if (om) {
              if (items.length === 0) isOrdered = true;
              const indent = om[1].length;
              items.push({ type: "ordered", level: Math.floor(indent / 2), text: om[2], media: [] });
              continue;
            }
            if (items.length > 0) {
              const im = tr.match(/^![(.*?)]((.*?))(?:{:?[^}]*})?$/);
              if (im) {
                const isGif = /.gif(?:?|$)/i.test(im[2]);
                items[items.length - 1].media.push('<div class="slide-list-media"><img alt="' + im[1] + '" src="' + im[2] + '" class="' + (isGif ? 'list-item-gif' : 'list-item-img') + '" /></div>');
                continue;
              }
              const hm = tr.match(/^<img\b[sS]*?/?>$/i);
              if (hm) {
                const cleanTr = tr.replace(/s+style="[^"]*"/gi, "");
                items[items.length - 1].media.push('<div class="slide-list-media">' + cleanTr + '</div>');
                continue;
              }
              if (/<video\b/i.test(tr)) {
                let vHtml = tr;
                if (!/</video>/i.test(vHtml)) {
                  while (i + 1 < lines.length && !/</video>/i.test(vHtml)) {
                    i++;
                    vHtml += " " + lines[i].trim();
                  }
                }
                const isAutoplay = block && block.attributes && block.attributes["custom-slidev-autoplay"] === "true";
                const isLoop = block && block.attributes && block.attributes["custom-slidev-loop"] === "true";
                const isMuted = block && block.attributes && (block.attributes["custom-slidev-muted"] === "true" || isAutoplay);
                const hideControls = block && block.attributes && block.attributes["custom-slidev-controls"] === "false";
                if (hideControls) vHtml = vHtml.replace(/\bcontrols(?:="[^"]*")?/gi, "").trim();
                else if (!vHtml.includes("controls")) vHtml = vHtml.replace("<video", "<video controls");
                if (isAutoplay && !vHtml.includes("autoplay")) vHtml = vHtml.replace("<video", "<video autoplay playsinline");
                if (isLoop && !vHtml.includes("loop")) vHtml = vHtml.replace("<video", "<video loop");
                if (isMuted && !vHtml.includes("muted")) vHtml = vHtml.replace("<video", "<video muted");
                vHtml = vHtml.replace("<video", '<video class="slide-video-player"');
                items[items.length - 1].media.push('<div class="slide-list-media slide-video-container slide-media-container" data-autoplay="' + (isAutoplay ? 'true' : 'false') + '">' + vHtml + '</div>');
                continue;
              }
              items[items.length - 1].text += "
" + tr;
            } else {
              leadLines.push(tr);
            }
          }

          let leadHtml = "";
          if (leadLines.length > 0) {
            const lParts = [];
            const firstL = leadLines[0];
            const fhm = firstL.match(/^(#{1,6})s+(.*)$/);
            if (fhm) {
              const lvl = fhm[1].length;
              let th = fhm[2].trim().replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
              lParts.push('<h' + lvl + ' class="slide-list-item-title">' + th + '</h' + lvl + '>');
            } else {
              let th = firstL.trim().replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
              lParts.push('<p class="slide-list-item-title">' + th + '</p>');
            }
            if (leadLines.length > 1) {
              const dLines = leadLines.slice(1);
              let pL = [];
              const flushLeadP = () => {
                if (pL.length > 0) {
                  let txt = pL.map(l => l.replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>")).join("<br/>");
                  lParts.push('<p class="slide-list-item-desc">' + txt + '</p>');
                  pL = [];
                }
              };
              for (const l of dLines) {
                const hm = l.match(/^(#{1,6})s+(.*)$/);
                if (hm) {
                  flushLeadP();
                  const lvl = hm[1].length;
                  let th = hm[2].trim().replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
                  lParts.push('<h' + lvl + ' class="slide-list-item-title">' + th + '</h' + lvl + '>');
                } else {
                  pL.push(l);
                }
              }
              flushLeadP();
            }
            leadHtml = lParts.join("
") + "
";
          }

          const tag = isOrdered ? "ol" : "ul";
          const listCls = isOrdered ? "pdf-list pdf-list--ordered" : "pdf-list pdf-list--unordered";
          const liHtml = items.map(it => {
            const med = it.media && it.media.length ? "
" + it.media.join("
") : "";
            const lines = (it.text || "").split("
").map(l => l.trim()).filter(Boolean);
            const hasHeading = lines.some(l => /^#{1,6}s+/.test(l));
            const lvl = it.level || 0;
            const nStyle = lvl > 0 ? ' style="margin-left:' + (lvl * 1.25).toFixed(2) + 'em;' + (it.type === 'unordered' ? 'list-style-type:' + (lvl % 2 === 1 ? 'circle' : 'square') + ' !important;' : '') + '"' : "";
            const nClass = lvl > 0 ? " slide-list-item--nested" : "";
            const clsAttr = nClass ? ' class="' + nClass.trim() + '"' : "";
            if (!hasHeading) {
              let h = lines.map(l => l.replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>")).join("<br/>");
              return '<li' + clsAttr + nStyle + '>' + h + med + '</li>';
            }
            const parts = [];
            let pLines = [];
            const flushP = () => {
              if (pLines.length > 0) {
                let ph = pLines.map(l => l.replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>")).join("<br/>");
                parts.push('<p class="slide-list-item-desc">' + ph + '</p>');
                pLines = [];
              }
            };
            for (const l of lines) {
              const hm = l.match(/^(#{1,6})s+(.*)$/);
              if (hm) {
                flushP();
                const hl = hm[1].length;
                let th = hm[2].trim().replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
                parts.push('<h' + hl + ' class="slide-list-item-title">' + th + '</h' + hl + '>');
              } else {
                pLines.push(l);
              }
            }
            flushP();
            return '<li' + clsAttr + nStyle + '>' + parts.join("
") + med + '</li>';
          }).join("
");
          div.innerHTML = leadHtml + "<" + tag + " class="" + listCls + "">
" + liHtml + "
</" + tag + ">";
        }
        else {
          // 复合块（包含换行、标题或媒体）高保真解析
          const lines = md.split(/\r?
/);
          const subBlocks = [];
          let current = [];
          for (let i = 0; i < lines.length; i++) {
            const line = lines[i];
            const trimmed = line.trim();
            if (/^#{1,6}s+/.test(trimmed)) {
              if (current.length > 0) { subBlocks.push(current.join("
")); current = []; }
              subBlocks.push(trimmed);
              continue;
            }
            if (!trimmed) {
              if (current.length > 0) { subBlocks.push(current.join("
")); current = []; }
              continue;
            }
            if (/^![.*?](.*?)$/.test(trimmed)) {
              if (current.length > 0) { subBlocks.push(current.join("
")); current = []; }
              subBlocks.push(trimmed);
              continue;
            }
            if (/<video\b/i.test(trimmed)) {
              if (current.length > 0) { subBlocks.push(current.join("
")); current = []; }
              let vRaw = trimmed;
              if (!/</video>/i.test(vRaw)) {
                while (i + 1 < lines.length && !/</video>/i.test(vRaw)) {
                  i++;
                  vRaw += "
" + lines[i];
                }
              }
              subBlocks.push(vRaw);
              continue;
            }
            current.push(line);
          }
          if (current.length > 0) subBlocks.push(current.join("
"));

          if (subBlocks.length > 1 || (subBlocks.length === 1 && /^#{1,6}s+/.test(subBlocks[0].trim()))) {
            const htmlParts = subBlocks.map(sub => {
              const t = sub.trim();
              if (!t) return "";
              const hm = t.match(/^(#{1,6})s+(.*)$/);
              if (hm) {
                const hl = hm[1].length;
                let th = hm[2].trim().replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
                return '<h' + hl + ' class="slide-list-item-title">' + th + '</h' + hl + '>';
              }
              const im = t.match(/^![(.*?)]((.*?))$/);
              if (im) {
                return '<div class="slide-media-block slide-media-container slide-list-media"><img alt="' + im[1] + '" src="' + im[2] + '" class="slide-media-img" /></div>';
              }
              if (/<video\b/i.test(t)) {
                return '<div class="slide-media-block slide-video-container slide-media-container">' + t + '</div>';
              }
              let ph = t.replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
              return '<p class="slide-list-item-desc">' + ph + '</p>';
            }).filter(Boolean);
            div.innerHTML = htmlParts.join("
");
          } else {
            const imgMatch = md.match(/!\\[(.*?)\\]\\((.*?)\\)/);
            if (imgMatch) {
              div.classList.add("slide-media-container", "slide-media-block", "slide-block--image");
              div.innerHTML = '<img alt="' + imgMatch[1] + '" src="' + imgMatch[2] + '" class="slide-media-img" />';
            } else {
              let html = md.replace(/\\*\\*(.*?)\\*\\*/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
              div.innerHTML = "<p>" + html + "</p>";
            }
          }
        }
        return div;
      }

      function renderSlide(idx) {
        if (slides.length === 0) return;
        currentIndex = Math.max(0, Math.min(idx, slides.length - 1));
        const slide = slides[currentIndex];
        pageNum.textContent = (currentIndex + 1) + " / " + slides.length;

        const pageSp = slide.frontmatter?.spacing;
        const currentSpacing = (pageSp && pageSp !== "inherit") ? pageSp : (data.config?.spacing || "normal");
        container.className = "slide-content layout-" + (slide.frontmatter?.layout || "default") + " spacing-" + currentSpacing;
        if (viewport) viewport.setAttribute("data-spacing", currentSpacing);
        container.innerHTML = "";

        const z = typeof slide.frontmatter?.zoom === "number" && slide.frontmatter.zoom > 0 ? slide.frontmatter.zoom : 1;
        if (z !== 1) {
          container.style.width = (100 / z) + "%";
          container.style.height = (100 / z) + "%";
          container.style.transformOrigin = "top left";
          container.style.transform = "scale(" + z + ")";
        } else {
          container.style.width = "100%";
          container.style.height = "100%";
          container.style.transform = "none";
        }

        if (slide.frontmatter?.layout === "two-cols") {
          const leftCol = document.createElement("div");
          leftCol.className = "two-cols-left";
          const rightCol = document.createElement("div");
          rightCol.className = "two-cols-right";

          const blocks = (slide.blocks || []).filter(b => b.slot !== "slot-divider-right");
          let leftList = [];
          let rightList = [];
          for (const block of blocks) {
            if (block.slot === "right") rightList.push(block);
            else leftList.push(block);
          }
          leftList = cleanColList(leftList);
          rightList = cleanColList(rightList);
          for (const b of leftList) leftCol.appendChild(renderBlock(b));
          for (const b of rightList) rightCol.appendChild(renderBlock(b));
          container.appendChild(leftCol);
          container.appendChild(rightCol);
        } else if (slide.frontmatter?.layout === "cols-header" || slide.frontmatter?.layout === "two-cols-header" || slide.frontmatter?.layout === "three-cols-header") {
          const blocks = (slide.blocks || []).filter(b => b.slot !== "slot-divider-right");
          let headerBlocks = blocks.filter(b => b.slot === "header");
          if (headerBlocks.length === 0 && blocks.length > 0) {
            const candidate = blocks.find(b => b.type === "h" && (!b.slot || b.slot === "default"));
            if (candidate) headerBlocks = [candidate];
          }
          const rem = blocks.filter(b => !headerBlocks.includes(b));

          let targetCols = 2;
          if (slide.frontmatter?.layout === "three-cols-header") {
            targetCols = 3;
          } else if (slide.frontmatter?.layout === "two-cols-header") {
            targetCols = 2;
          } else {
            let maxCol = 0;
            for (const b of rem) {
              const m = (b.slot || "").match(/^col-(d+)$/i);
              if (m) maxCol = Math.max(maxCol, parseInt(m[1], 10));
            }
            if (maxCol >= 2) {
              targetCols = maxCol;
            } else if (slide.frontmatter?.layoutRatio) {
              const r = slide.frontmatter.layoutRatio.trim();
              if (r.includes(":")) {
                const parts = r.split(":").map(p => parseFloat(p.trim())).filter(n => !isNaN(n) && n > 0);
                if (parts.length >= 2) targetCols = parts.length;
              }
            }
          }

          const containerDiv = document.createElement("div");
          containerDiv.className = "layout-cols-header-container " + (targetCols === 2 ? "layout-two-cols-header-container" : (targetCols === 3 ? "layout-three-cols-header-container" : ""));
          const headerDiv = document.createElement("div");
          headerDiv.className = "layout-header-section";
          const gridDiv = document.createElement("div");
          gridDiv.className = "layout-cols-wrapper layout-cols-grid " + (targetCols === 2 ? "pdf-two-cols-wrapper layout-two-cols-grid" : (targetCols === 3 ? "pdf-three-cols-wrapper layout-three-cols-grid" : ""));

          const gridCols = parseRatioToGridCols(slide.frontmatter?.layoutRatio, targetCols);
          if (gridCols) gridDiv.style.gridTemplateColumns = gridCols;

          let colsList = [];
          for (let i = 0; i < targetCols; i++) colsList.push([]);
          const hasExplicitCols = rem.some(b => b.slot && (b.slot.startsWith("col-") || b.slot === "left" || b.slot === "right" || b.slot === "center"));
          if (hasExplicitCols) {
            for (const b of rem) {
              let idx = 0;
              if (b.slot === "left" || b.slot === "col-1") idx = 0;
              else if (b.slot === "center" || b.slot === "col-2") idx = 1;
              else if (b.slot === "right") idx = targetCols === 2 ? 1 : targetCols - 1;
              else {
                const m = (b.slot || "").match(/^col-(d+)$/i);
                if (m) idx = Math.min(targetCols - 1, Math.max(0, parseInt(m[1], 10) - 1));
              }
              colsList[idx].push(b);
            }
          } else {
            let cur = 0;
            for (let i = 0; i < targetCols; i++) {
              const remainingCols = targetCols - i;
              const remainingItems = rem.length - cur;
              const take = Math.ceil(remainingItems / remainingCols);
              colsList[i] = rem.slice(cur, cur + take);
              cur += take;
            }
          }

          for (const b of headerBlocks) headerDiv.appendChild(renderBlock(b));
          containerDiv.appendChild(headerDiv);

          colsList.forEach((colBlocks, idx) => {
            const colDiv = document.createElement("div");
            colDiv.className = "pdf-col pdf-col--" + (idx + 1) + " col-" + (idx + 1) + (targetCols === 2 && idx === 0 ? " pdf-col--left" : "") + (targetCols === 2 && idx === 1 ? " pdf-col--right" : "");
            const cleaned = cleanColList(colBlocks);
            for (const b of cleaned) colDiv.appendChild(renderBlock(b));
            gridDiv.appendChild(colDiv);
          });
          containerDiv.appendChild(gridDiv);
          container.appendChild(containerDiv);
        } else if (slide.frontmatter?.layout === "image-right" || slide.frontmatter?.layout === "image-left") {
          const isImageRight = slide.frontmatter?.layout === "image-right";
          const contentCol = document.createElement("div");
          contentCol.className = isImageRight ? "image-right-content" : "image-left-content";

          for (const block of (slide.blocks || [])) {
            contentCol.appendChild(renderBlock(block));
          }

          const imgCol = document.createElement("div");
          imgCol.className = isImageRight ? "image-right-img-container" : "image-left-img-container";
          const img = document.createElement("img");
          img.className = isImageRight ? "image-right-img" : "image-left-img";
          img.src = slide.frontmatter?.image || slide.frontmatter?.background || "";
          img.alt = "Slide cover";
          img.onerror = function() {
            this.src = "https://fastly.jsdelivr.net/gh/slidevjs/slidev-covers@main/static/2HmfbSpvcos.webp";
          };
          imgCol.appendChild(img);

          if (isImageRight) {
            container.appendChild(contentCol);
            container.appendChild(imgCol);
          } else {
            container.appendChild(imgCol);
            container.appendChild(contentCol);
          }
        } else {
          for (const block of (slide.blocks || [])) {
            container.appendChild(renderBlock(block));
          }
        }

        function syncAutoplayVideos() {
          const doSync = () => {
            const videos = container.querySelectorAll("video");
            videos.forEach((v) => {
              const box = v.closest("[data-autoplay]");
              const isAuto = v.hasAttribute("autoplay") || v.autoplay || (box && box.getAttribute("data-autoplay") === "true");
              if (isAuto) {
                v.muted = true;
                v.defaultMuted = true;
                v.setAttribute("muted", "");
                v.playsInline = true;
                v.setAttribute("playsinline", "");
                const playFn = () => {
                  if (!v.paused) return;
                  v.muted = true;
                  v.defaultMuted = true;
                  const p = v.play();
                  if (p !== undefined) {
                    p.catch(() => {
                      v.muted = true;
                      v.defaultMuted = true;
                      setTimeout(() => { if (v.paused) v.play().catch(() => {}); }, 150);
                    });
                  }
                };
                playFn();
                if (!v.__autoplayBound) {
                  v.__autoplayBound = true;
                  v.addEventListener("loadedmetadata", playFn);
                  v.addEventListener("canplay", playFn);
                }
              }
            });
          };
          setTimeout(doSync, 60);
          setTimeout(doSync, 200);
        }
        syncAutoplayVideos();
      }

      // Lightbox 控制逻辑
      const lightbox = document.getElementById("slidev-lightbox");
      const lightboxContent = document.getElementById("lightbox-content");
      const lightboxClose = document.getElementById("lightbox-close");
      let isLightboxOpen = false;

      function openLightbox(type, src, alt) {
        if (!lightbox || !lightboxContent) return;
        lightboxContent.innerHTML = "";
        if (type === "video") {
          const v = document.createElement("video");
          v.className = "slidev-lightbox-video";
          v.src = src;
          v.controls = true;
          v.autoplay = true;
          v.playsInline = true;
          lightboxContent.appendChild(v);
        } else {
          const img = document.createElement("img");
          img.className = "slidev-lightbox-img";
          img.src = src;
          img.alt = alt || "";
          lightboxContent.appendChild(img);
        }
        lightbox.classList.add("active");
        isLightboxOpen = true;
      }

      function closeLightbox() {
        if (!lightbox) return;
        const v = lightbox.querySelector("video");
        if (v) v.pause();
        lightbox.classList.remove("active");
        if (lightboxContent) lightboxContent.innerHTML = "";
        isLightboxOpen = false;
      }

      if (lightboxClose) {
        lightboxClose.addEventListener("click", (e) => {
          e.stopPropagation();
          closeLightbox();
        });
      }
      if (lightbox) {
        lightbox.addEventListener("click", (e) => {
          if (e.target === lightbox || e.target === lightboxClose) {
            e.stopPropagation();
            closeLightbox();
          }
        });
      }

      btnPrev.addEventListener("click", () => renderSlide(currentIndex - 1));
      btnNext.addEventListener("click", () => renderSlide(currentIndex + 1));
      btnFullscreen.addEventListener("click", () => {
        if (!document.fullscreenElement) {
          document.documentElement.requestFullscreen().then(() => updateScale()).catch(() => {});
        } else {
          document.exitFullscreen().then(() => updateScale()).catch(() => {});
        }
      });

      window.addEventListener("keydown", (e) => {
        if (e.key === "Escape" || e.key === "Esc") {
          if (isLightboxOpen) {
            closeLightbox();
            e.preventDefault();
            return;
          }
        }
        if (isLightboxOpen) return;
        if (e.key === "ArrowRight" || e.key === " ") renderSlide(currentIndex + 1);
        if (e.key === "ArrowLeft") renderSlide(currentIndex - 1);
        if (e.key === "f" || e.key === "F") btnFullscreen.click();
      });

      document.addEventListener("click", (e) => {
        if (isLightboxOpen) {
          const target = e.target instanceof Element ? e.target : e.target?.parentElement;
          const isMediaItself = target && target.closest && target.closest(".slidev-lightbox-img, .slidev-lightbox-video");
          if (!isMediaItself) {
            e.stopPropagation();
            closeLightbox();
          }
          return;
        }
        if (e.button !== 0) return;
        const targetEl = e.target instanceof Element ? e.target : e.target?.parentElement;
        if (!targetEl || !targetEl.closest) return;

        const refEl = targetEl.closest("[data-ref-id]");
        if (refEl) {
          const id = refEl.getAttribute("data-ref-id");
          if (id) {
            window.open("siyuan://blocks/" + id, "_blank");
            return;
          }
        }

        // 媒体点击唤起 Lightbox 放大模态
        const mediaEl = targetEl.closest(".slide-content img, .slide-content video");
        if (mediaEl && !mediaEl.closest(".controls, button, a")) {
          e.stopPropagation();
          const isVideo = mediaEl.tagName.toLowerCase() === "video";
          const src = isVideo ? (mediaEl.currentSrc || mediaEl.src || mediaEl.querySelector("source")?.src) : mediaEl.src;
          if (src) {
            openLightbox(isVideo ? "video" : "image", src, mediaEl.alt || "");
            return;
          }
        }

        const selection = window.getSelection ? window.getSelection().toString().trim() : "";
        if (selection.length > 0) return;

        const isComponent = targetEl.closest(
          ".slide-block, .controls-bar, .image-right-img-container, .image-left-img-container, img, video, audio, button, a, input, textarea, select, [data-clickable], [data-ref-id], .slidev-toc, .empty-state"
        );
        if (isComponent) return;

        const isLeft = e.clientX < window.innerWidth / 2;
        if (isLeft) {
          renderSlide(currentIndex - 1);
        } else {
          renderSlide(currentIndex + 1);
        }
      });

      renderSlide(0);
      updateScale();
    })();`}function aa(t,i){const e="Slidev 演示文稿";let n=t.slides;const o=JSON.stringify(n),s=JSON.stringify(t.config);return`<!DOCTYPE html>
<html lang="zh-CN">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${le(e)}</title>
  <style>
${Zh(i==null?void 0:i.customInlineStyles)}
  </style>
  <script>
    // 注入演示数据载荷
    window.__SLIDEV_DATA__ = {
      docId: ${JSON.stringify(t.docId)},
      slides: ${o},
      config: ${s}
    };
  <\/script>
</head>
<body>
  <div id="app" data-normalize-headings="${t.config.normalizeHeadingSizes?"true":"false"}">
    <div class="slide-viewport slidev-theme-${t.config.theme||"default"}" id="viewport" data-slidev-theme="${t.config.theme||"default"}">
      <div class="slide-content" id="slide-container"></div>
    </div>
    <div class="controls">
      <button id="btn-prev">◀ 上一页</button>
      <span id="page-num">1 / 1</span>
      <button id="btn-next">下一页 ▶</button>
      <button id="btn-fullscreen">全屏</button>
    </div>
    <!-- 全屏媒体灯箱 (Lightbox) 模态窗口 -->
    <div id="slidev-lightbox" class="slidev-lightbox">
      <button class="slidev-lightbox-close" id="lightbox-close" aria-label="关闭 (Esc)">✕</button>
      <div class="slidev-lightbox-content" id="lightbox-content"></div>
    </div>
  </div>

  <script>
${Yh()}
  <\/script>
</body>
</html>`}function ca(t,i){if(typeof document>"u")return!1;const e=new Blob([i],{type:"text/html;charset=utf-8"}),n=URL.createObjectURL(e),o=document.createElement("a");return o.href=n,o.download=t.endsWith(".html")?t:`${t}.html`,document.body.appendChild(o),o.click(),document.body.removeChild(o),URL.revokeObjectURL(n),!0}function Jh(t){switch(t){case"4:3":return"size: 12in 9in;";case"A4-landscape":return"size: 297mm 210mm;";case"A4-portrait":return"size: 210mm 297mm;";case"16:9":default:return"size: 16in 9in;"}}function Xh(t){const i=Jh(t==null?void 0:t.pageRatio);return`
    ${bn(t==null?void 0:t.customInlineStyles)}

    @page {
      ${i}
      margin: 0;
    }
    * {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
      -webkit-print-color-adjust: exact !important;
      print-color-adjust: exact !important;
    }
    body {
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "PingFang SC", "Microsoft YaHei", sans-serif;
      background: #f8fafc;
      color: #1e293b;
    }
    .pdf-slide-page {
      width: 100vw;
      height: 100vh;
      page-break-after: always;
      break-after: page;
      padding: var(--slidev-padding-y, 36px) var(--slidev-padding-x, 56px);
      display: flex;
      flex-direction: column;
      position: relative;
      background: #ffffff;
      overflow: hidden;
    }
    .pdf-slide-page.spacing-compact {
      --slidev-padding-y: 20px;
      --slidev-padding-x: 36px;
      --slidev-header-gap: 10px;
      --slidev-title-margin-bottom: 6px;
    }
    .pdf-slide-page.spacing-normal {
      --slidev-padding-y: 36px;
      --slidev-padding-x: 56px;
      --slidev-header-gap: 16px;
      --slidev-title-margin-bottom: 10px;
    }
    .pdf-slide-page.spacing-loose {
      --slidev-padding-y: 48px;
      --slidev-padding-x: 64px;
      --slidev-header-gap: 24px;
      --slidev-title-margin-bottom: 16px;
    }
    .pdf-slide-page.theme-dark {
      background: #0f1117;
      color: #f1f5f9;
    }
    .pdf-slide-header {
      font-size: 13px;
      color: #64748b;
      margin-bottom: 24px;
      display: flex;
      justify-content: space-between;
      border-bottom: 1px solid #e2e8f0;
      padding-bottom: 8px;
    }
    .theme-dark .pdf-slide-header {
      border-bottom-color: #2e3346;
      color: #94a3b8;
    }
    .pdf-slide-body {
      flex: 1;
      display: flex;
      flex-direction: column;
      gap: 16px;
      font-size: 20px;
      line-height: 1.6;
      overflow: hidden;
    }
    .pdf-block h1 { font-size: 2.5rem; font-weight: 800; color: #2563eb; margin-bottom: 12px; }
    .pdf-block h2 { font-size: 1.9rem; font-weight: 700; color: #1d4ed8; margin-bottom: 10px; }
    .pdf-block h3 { font-size: 1.4rem; font-weight: 600; margin-bottom: 8px; }
    .pdf-block h4 { font-size: 1.2rem; font-weight: 600; margin-bottom: 6px; }
    .pdf-block p { font-size: 1.15rem; color: inherit; }
    .pdf-code,
    pre {
      background: #f1f5f9;
      padding: 14px 18px;
      border-radius: 6px;
      font-family: "JetBrains Mono", Consolas, monospace;
      font-size: 0.95rem;
      border-left: 4px solid #3b82f6;
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      max-width: 100% !important;
      box-sizing: border-box !important;
    }
    .pdf-code code,
    pre code {
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      display: block !important;
      width: 100% !important;
      box-sizing: border-box !important;
    }
    .code-line {
      display: flex !important;
      align-items: flex-start !important;
      width: 100% !important;
      box-sizing: border-box !important;
      line-height: 1.6;
    }
    .code-line .line-no {
      display: inline-block !important;
      flex-shrink: 0 !important;
      min-width: 2.2em !important;
      text-align: right !important;
      margin-right: 12px !important;
      user-select: none !important;
      opacity: 0.45 !important;
    }
    .code-line .line-content {
      flex: 1 1 0% !important;
      min-width: 0 !important;
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
    }
    .theme-dark .pdf-code {
      background: #1e1e24;
      border-left-color: #60a5fa;
    }
    .pdf-quote {
      border-left: 4px solid #10b981;
      background: rgba(16, 185, 129, 0.08);
      padding: 10px 16px;
      border-radius: 0 4px 4px 0;
      font-style: italic;
    }
    .pdf-image,
    .slide-media-img {
      max-width: 100% !important;
      max-height: 48vh !important;
      width: auto !important;
      height: auto !important;
      object-fit: contain !important;
      border-radius: 6px;
      margin: auto;
      display: block;
    }
    .slide-media-block,
    .slide-media-container,
    .slide-video-container {
      display: flex;
      flex-direction: column;
      justify-content: center;
      align-items: center;
      width: 100%;
      max-height: 48vh;
      margin: 8px 0;
      overflow: hidden;
    }
    .slide-list-media {
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: flex-start;
      margin-top: 8px;
      margin-bottom: 6px;
      max-width: 100%;
      overflow: hidden;
    }
    .slide-list-media img,
    .slide-list-media video,
    .slide-list-media .list-item-gif {
      max-width: 100% !important;
      max-height: min(280px, 36vh) !important;
      width: auto !important;
      height: auto !important;
      min-width: 0 !important;
      min-height: 0 !important;
      object-fit: contain !important;
      border-radius: 6px;
      display: block;
      margin: 0 auto !important;
    }
    .slide-video-player {
      max-width: 100% !important;
      max-height: 48vh !important;
      width: auto !important;
      height: auto !important;
      object-fit: contain !important;
      border-radius: 6px;
      background: #000;
      border: 1px solid #cbd5e1;
    }
    .pdf-two-cols-wrapper,
    .layout-two-cols-grid,
    .layout-cols-wrapper,
    .layout-cols-grid {
      display: grid;
      grid-template-columns: minmax(0, 1fr) minmax(0, 1fr);
      grid-template-rows: minmax(0, 1fr) !important;
      gap: 36px;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      overflow: hidden !important;
    }
    .layout-cols-header-container,
    .layout-two-cols-header-container,
    .layout-three-cols-header-container {
      display: flex;
      flex-direction: column;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      overflow: hidden !important;
    }
    .layout-header-section {
      width: 100%;
      margin-bottom: var(--slidev-header-gap, 16px) !important;
      flex-shrink: 0;
    }
    .layout-header-section h1,
    .layout-header-section h2,
    .layout-header-section h3 {
      margin-bottom: var(--slidev-title-margin-bottom, 10px) !important;
    }
    .pdf-three-cols-wrapper,
    .layout-three-cols-grid {
      display: grid;
      grid-template-columns: minmax(0, 1fr) minmax(0, 1fr) minmax(0, 1fr);
      grid-template-rows: minmax(0, 1fr) !important;
      gap: 24px;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      box-sizing: border-box;
      overflow: hidden !important;
    }
    .pdf-col {
      display: flex;
      flex-direction: column;
      gap: 14px;
      min-width: 0;
      width: 100%;
      max-width: 100%;
      height: 100%;
      max-height: 100%;
      min-height: 0;
      justify-content: flex-start;
      overflow: hidden;
      box-sizing: border-box;
      overflow-wrap: break-word;
      word-break: break-word;
      white-space: normal;
    }
    /* 表头多栏内超级块子块首个列表项去圆点后居中显示标题/首行文本 */
    .layout-cols-wrapper .pdf-col > *:first-child .slide-list-item-title,
    .layout-cols-wrapper .pdf-col > *:first-child > :is(h1, h2, h3, h4),
    .layout-cols-wrapper .pdf-col > *:first-child > p.slide-list-item-title,
    .layout-cols-header-container .pdf-col > *:first-child .slide-list-item-title,
    .layout-cols-header-container .pdf-col > *:first-child > :is(h1, h2, h3, h4),
    .layout-cols-header-container .pdf-col > *:first-child > p.slide-list-item-title {
      text-align: center !important;
      width: 100% !important;
    }

    /* 栏内说明段落与列表项：左对齐，自然阅读排版 */
    .layout-cols-wrapper .pdf-col .slide-list-item-desc,
    .layout-cols-header-container .pdf-col .slide-list-item-desc,
    .pdf-col .slide-list-item-desc,
    .layout-cols-wrapper .pdf-col li,
    .layout-cols-header-container .pdf-col li,
    .pdf-col li {
      text-align: left !important;
    }

    /* 全局特定标题大小规范化 (除封面外页首首个标题按 H2 1.7rem，表头多栏内首个标题按 H3 1.3rem) */
    [data-normalize-headings="true"] .slidev-page-first-heading-block :is(h1, h2, h3, h4, h5, h6),
    [data-normalize-headings="true"] .slidev-page-first-heading-block:is(h1, h2, h3, h4, h5, h6),
    [data-normalize-headings="true"] .pdf-slide:not(.layout-cover) > .pdf-block:first-child :is(h1, h2, h3, h4, h5, h6),
    [data-normalize-headings="true"] .pdf-slide:not(.layout-cover) > .layout-header-section .pdf-block:first-child :is(h1, h2, h3, h4, h5, h6),
    [data-normalize-headings="true"] .pdf-slide:not(.layout-cover) > :not(.layout-cols-wrapper):not(.pdf-two-cols-wrapper):not(.layout-image-cols-grid):first-child :is(h1, h2, h3, h4, h5, h6) {
      font-size: 1.7rem !important;
      font-weight: 600 !important;
      line-height: 1.25 !important;
      margin-bottom: 10px !important;
    }

    [data-normalize-headings="true"] .slidev-col-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .slidev-col-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] :is(.layout-cols-wrapper, .pdf-two-cols-wrapper, .layout-cols-header-container) .pdf-col > *:first-child :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      font-size: 1.3rem !important;
      font-weight: 600 !important;
      line-height: 1.3 !important;
      margin-bottom: 8px !important;
    }
    .pdf-col > .pdf-block,
    .pdf-col > .slide-block {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      max-height: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      width: 100% !important;
      height: 100% !important;
      box-sizing: border-box !important;
      overflow: hidden !important;
    }
    .pdf-col .slide-list-item-title,
    .pdf-col h1, .pdf-col h2, .pdf-col h3, .pdf-col h4, .pdf-col h5, .pdf-col h6,
    .pdf-col .slide-list-item-desc {
      flex: 0 0 auto !important;
      margin-top: 0 !important;
      margin-bottom: 6px !important;
    }
    .pdf-col .slide-list-media,
    .pdf-col .slide-video-container,
    .pdf-col .slide-media-container {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      min-width: 0 !important;
      width: 100% !important;
      height: 100% !important;
      max-height: 100% !important;
      max-width: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
      justify-content: flex-start !important;
      overflow: hidden !important;
      margin: 0 !important;
      padding: 0 !important;
      box-sizing: border-box !important;
    }
    .pdf-col li:has(.slide-list-media),
    .pdf-col li:has(.slide-media-container),
    .pdf-col li:has(.slide-video-container),
    .pdf-col li:has(img),
    .pdf-col li:has(video),
    .pdf-col .pdf-list-item:has(.slide-list-media),
    .pdf-col .pdf-list-item:has(.slide-media-container),
    .pdf-col .pdf-list-item:has(.slide-video-container),
    .pdf-col .pdf-list-item:has(img),
    .pdf-col .pdf-list-item:has(video) {
      display: list-item !important;
      list-style-type: disc !important;
      flex: 0 0 auto !important;
      height: auto !important;
      max-height: none !important;
      overflow: visible !important;
      margin-bottom: 6px !important;
    }
    .pdf-col video,
    .layout-three-cols-grid video,
    .layout-two-cols-grid video,
    .pdf-col img,
    .layout-three-cols-grid img,
    .layout-two-cols-grid img,
    .pdf-col .slide-video-player {
      max-width: 100% !important;
      max-height: 100% !important;
      width: auto !important;
      height: auto !important;
      min-width: 0 !important;
      min-height: 0 !important;
      object-fit: contain !important;
      display: block !important;
      margin: 0 auto !important;
    }
    .pdf-col * {
      overflow-wrap: break-word;
      word-break: break-word;
      box-sizing: border-box;
    }
    .pdf-col pre {
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      max-width: 100% !important;
      box-sizing: border-box !important;
    }
    .pdf-list-item {
      padding-left: 20px;
    }
    .pdf-list {
      padding-left: 24px;
      margin: 8px 0;
      display: flex;
      flex-direction: column;
      gap: 6px;
    }
    .pdf-list li {
      font-size: 1.15rem;
      line-height: 1.6;
    }
    .pdf-task-item {
      list-style: none;
      margin-left: -20px;
      display: flex;
      align-items: center;
      gap: 8px;
    }
    .pdf-task-item input[type="checkbox"] {
      width: 1.15em;
      height: 1.15em;
      cursor: pointer;
    }
    /* 两栏与三栏及多栏（超级块分栏）布局：紧凑自然行距，子列表保留圆点与层级缩进 */
    .layout-two-cols ul,
    .layout-cols-header ul,
    .layout-two-cols-header ul,
    .layout-three-cols ul,
    .layout-three-cols-header ul,
    .two-cols-left ul,
    .two-cols-right ul,
    .three-cols-col ul,
    .col ul,
    .pdf-two-cols-wrapper ul,
    .pdf-three-cols-wrapper ul,
    .pdf-col ul,
    .layout-two-cols-grid .pdf-list,
    .layout-three-cols-grid .pdf-list,
    .layout-cols-grid .pdf-list,
    .layout-two-cols-grid .pdf-list--unordered,
    .layout-three-cols-grid .pdf-list--unordered,
    .layout-cols-grid .pdf-list--unordered {
      list-style: disc !important;
      list-style-type: disc !important;
      padding-left: 1.25em !important;
      margin-left: 0 !important;
      margin-top: 0 !important;
      margin-bottom: 8px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: block !important;
    }
    .layout-two-cols ol,
    .layout-cols-header ol,
    .layout-two-cols-header ol,
    .layout-three-cols ol,
    .layout-three-cols-header ol,
    .two-cols-left ol,
    .two-cols-right ol,
    .three-cols-col ol,
    .col ol,
    .pdf-two-cols-wrapper ol,
    .pdf-three-cols-wrapper ol,
    .pdf-col ol,
    .layout-two-cols-grid .pdf-list--ordered,
    .layout-three-cols-grid .pdf-list--ordered,
    .layout-cols-grid .pdf-list--ordered {
      list-style: decimal !important;
      list-style-type: decimal !important;
      padding-left: 1.25em !important;
      margin-left: 0 !important;
      margin-top: 0 !important;
      margin-bottom: 8px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: block !important;
    }
    .layout-two-cols li,
    .layout-cols-header li,
    .layout-two-cols-header li,
    .layout-three-cols li,
    .layout-three-cols-header li,
    .two-cols-left li,
    .two-cols-right li,
    .three-cols-col li,
    .col li,
    .pdf-col li,
    .pdf-col .pdf-list-item {
      padding-left: 0.2em !important;
      margin-left: 0 !important;
      margin-bottom: 6px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: list-item !important;
      line-height: 1.6 !important;
    }
    .layout-two-cols ul ul,
    .layout-three-cols ul ul,
    .three-cols-col ul ul,
    .pdf-col ul ul {
      list-style: circle !important;
      list-style-type: circle !important;
      padding-left: 1.25em !important;
      margin-top: 4px !important;
      margin-bottom: 4px !important;
    }
    /* 列表项内嵌标题与说明排版 */
    .slide-list-item-title,
    .pdf-list li > h1,
    .pdf-list li > h2,
    .pdf-list li > h3,
    .pdf-list li > h4,
    .pdf-list li > h5,
    .pdf-list li > h6,
    li > h1.slide-list-item-title,
    li > h2.slide-list-item-title,
    li > h3.slide-list-item-title,
    li > h4.slide-list-item-title {
      margin-top: 2px !important;
      margin-bottom: 6px !important;
      line-height: 1.35 !important;
      font-weight: 700 !important;
    }
    .pdf-list li > h1, li > h1.slide-list-item-title { font-size: 1.6rem !important; }
    .pdf-list li > h2, li > h2.slide-list-item-title { font-size: 1.4rem !important; }
    .pdf-list li > h3, li > h3.slide-list-item-title { font-size: 1.22rem !important; }
    .pdf-list li > h4, li > h4.slide-list-item-title { font-size: 1.1rem !important; }
    .slide-list-item-desc,
    .pdf-list li > p {
      margin-top: 4px !important;
      margin-bottom: 6px !important;
      font-size: 1.05rem;
      line-height: 1.55;
      opacity: 0.92;
    }
    kbd {
      display: inline-block;
      padding: 2px 7px;
      font-family: ui-monospace, SFMono-Regular, "SF Mono", Menlo, Consolas, "Liberation Mono", monospace;
      font-size: 0.85em;
      font-weight: 600;
      line-height: 1.25;
      color: inherit;
      background: rgba(125, 125, 125, 0.12);
      border: 1px solid rgba(125, 125, 125, 0.35);
      border-bottom-width: 2px;
      border-radius: 5px;
      box-shadow: 0 1px 2px rgba(0, 0, 0, 0.12);
      margin: 0 2px;
      vertical-align: middle;
      white-space: nowrap;
    }
    .theme-dark kbd {
      background: rgba(255, 255, 255, 0.1);
      border-color: rgba(255, 255, 255, 0.25);
      border-bottom-color: rgba(255, 255, 255, 0.4);
      color: #f1f5f9;
      box-shadow: 0 1px 2px rgba(0, 0, 0, 0.4);
    }
    a {
      color: inherit;
      text-decoration: none;
      border-bottom: 1px dashed currentColor;
    }
    .slidev-ref-tag, a.slidev-ref-tag {
      display: inline-flex;
      align-items: center;
      background: rgba(16, 185, 129, 0.1);
      color: #059669;
      border: 1px solid rgba(16, 185, 129, 0.25);
      border-radius: 4px;
      padding: 2px 8px;
      font-size: 0.88em;
      text-decoration: none;
      margin: 2px 4px 2px 0;
    }
    .theme-dark .slidev-ref-tag, .theme-dark a.slidev-ref-tag {
      background: rgba(52, 211, 153, 0.15);
      color: #34d399;
      border-color: rgba(52, 211, 153, 0.3);
    }
    .slidev-block-ref, .pdf-block--ref {
      background: rgba(16, 185, 129, 0.06);
      border-left: 3px solid #059669;
      border-radius: 0 6px 6px 0;
      padding: 10px 14px;
      margin: 8px 0;
    }
    .theme-dark .slidev-block-ref, .theme-dark .pdf-block--ref {
      background: rgba(52, 211, 153, 0.08);
      border-left-color: #34d399;
    }
    .pdf-slide-notes {
      font-size: 14px;
      color: #059669;
      border-top: 1px dashed #cbd5e1;
      padding-top: 12px;
      margin-top: auto;
      line-height: 1.5;
    }
    .theme-dark .pdf-slide-notes {
      color: #34d399;
      border-top-color: #334155;
    }
    /* Layouts */
    .layout-cover .pdf-slide-body {
      justify-content: center;
      align-items: center;
      text-align: center;
    }
    .layout-cover h1 {
      font-size: 3.2rem;
    }
    .layout-center .pdf-slide-body {
      justify-content: center;
      align-items: center;
      text-align: center;
    }
    .layout-fact .pdf-slide-body {
      justify-content: center;
      align-items: center;
      text-align: center;
    }
    .layout-fact h1 {
      font-size: 4.5rem;
      color: #ef4444;
    }
    @media print {
      .slidev-motion-fade-in,
      .slidev-motion-slide-up,
      .slidev-motion-slide-down,
      .slidev-motion-slide-left,
      .slidev-motion-slide-right,
      .slidev-motion-zoom-in,
      .slidev-motion-pop,
      .slidev-motion-bounce {
        animation: none !important;
        opacity: 1 !important;
        transform: none !important;
      }
    }
  `}function Qh(t,i){const e="Slidev 演示讲义",n="16:9",o="light",s=t.slides.map((l,r)=>{const a=l.frontmatter.layout||"default",c=l.frontmatter.spacing,u=c&&c!=="inherit"?c:t.config.spacing||"normal",m=jh(l),v=`${r+1} / ${t.slides.length}`;return`
      <section class="pdf-slide-page layout-${a} theme-${o} spacing-${u}">
        <header class="pdf-slide-header">
          <span class="pdf-doc-title">${le(e)}</span>
          ${`<span class="pdf-page-badge">P. ${v}</span>`}
        </header>
        <div class="pdf-slide-body">
          ${m}
        </div>
        ${l.notes?`
          <footer class="pdf-slide-notes">
            <strong>演讲备注:</strong> ${le(l.notes)}
          </footer>
        `:""}
      </section>
    `}).join(`
`);return`<!DOCTYPE html>
<html lang="zh-CN">
<head>
  <meta charset="UTF-8">
  <title>${le(e)} - 高保真讲义</title>
  <style>
    ${Xh({pageRatio:n,customInlineStyles:i==null?void 0:i.customInlineStyles})}
  </style>
</head>
<body data-normalize-headings="${t.config.normalizeHeadingSizes?"true":"false"}">
  ${s}
</body>
</html>`}function da(t,i){var o;if(typeof window>"u"||typeof document>"u")return!1;const e=Qh(t,i);try{const s=document.createElement("iframe");s.style.position="fixed",s.style.right="0",s.style.bottom="0",s.style.width="0",s.style.height="0",s.style.border="none",s.style.visibility="hidden",document.body.appendChild(s);const l=(o=s.contentWindow)==null?void 0:o.document;if(l)return l.open(),l.write(e),l.close(),setTimeout(()=>{var r,a;try{(r=s.contentWindow)==null||r.focus(),(a=s.contentWindow)==null||a.print()}finally{setTimeout(()=>{s.remove()},2e3)}},350),!0}catch(s){console.warn("[pdf-exporter] iframe 打印模式异常，降级尝试 window.open:",s)}const n=window.open("","_blank");return n?(n.document.write(e),n.document.close(),n.focus(),setTimeout(()=>{n.print(),n.close()},350),!0):!1}const tm={class:"spm-slidev-preview-tab"},em={class:"spm-slidev-tab__toolbar"},im={class:"spm-slidev-tab__actions"},nm=["disabled"],om={class:"spm-page-badge"},sm=["disabled"],rm=["aria-label"],lm=["aria-label"],am=["src"],cm=_e({__name:"SlidevPreviewTab",setup(t,{expose:i}){const e=ti("plugin"),n=ti("sandboxBridge",new Os),o=new zh(n),s=new rf,l=gt("web-sandbox"),r=gt(3030),a=gt(null),c=gt(!1),u=gt(null),m=gt(1),v=gt(1),d=gt([]),b=gt(!1),f=gt(!1),y=gt(!1),k=gt("siyuan"),x=gt(""),C=gt(""),A=gt(""),B=gt(!1),I=gt(!1),w=gt(""),D=gt("/plugins/siyuan-slidev/slidev-client/index.html");let P=null,R=null,J=null,S=null,H=null,g=null,N=null;Pn(()=>{u.value&&(n.attach(u.value),s.nativeBridge.attach(u.value)),P=n.onSlideChanged((X,dt)=>{m.value=X,v.value=dt}),R=n.onBlockClicked((X,dt)=>{m.value=dt,o.setActiveBlockId(X),e&&typeof e.handleBlockClickedFromSlide=="function"?e.handleBlockClickedFromSlide(X,dt):Pi(X,e==null?void 0:e.app)}),J=n.onOpenInEditor((X,dt)=>{m.value=dt,o.setActiveBlockId(X),Pi(X,e==null?void 0:e.app)}),S=s.nativeBridge.onPageChanged((X,dt)=>{m.value=X,v.value=dt}),H=n.onOpenPeekDrawer(async X=>{const dt=To();if(X.peekType==="siyuan"&&dt.enableWebServeJump){let bt=!1;if(N&&N.docId===X.target)bt=!0;else if(N&&N.slides&&N.slides.some(T=>{var F;return(F=T.blocks)==null?void 0:F.some(p=>p.id===X.target)}))bt=!1;else try{const T=await yn(`SELECT id, root_id, type FROM blocks WHERE id = '${X.target}' LIMIT 1`);T&&T.length>0&&(bt=T[0].type==="d"||T[0].id===T[0].root_id)}catch(T){console.warn("[SlidevPreviewTab] detect block type failed:",T)}k.value="web",B.value=!0,C.value=Zl(dt.webServeUrl,X.target,{focus:!bt}),A.value=X.title||`${bt?"思源文档":"思源块"}: ${X.target.slice(0,8)}`,f.value=!0,n.freezeKeyboardNav(!0)}else k.value=X.peekType,X.peekType==="siyuan"?(x.value=X.target,A.value=X.title||`块速览: ${X.target.slice(0,8)}`):(B.value=!0,C.value=X.target,A.value=X.title||X.target),f.value=!0,n.freezeKeyboardNav(!0)}),g=n.onRequestToggleFullscreen(()=>{tt()}),typeof document<"u"&&document.addEventListener("fullscreenchange",nt)}),As(()=>{typeof document<"u"&&document.removeEventListener("fullscreenchange",nt),H&&H(),g&&g(),P&&P(),R&&R(),J&&J(),S&&S(),n.detach(),o.destroy(),s.destroy()});async function q(){if(l.value==="web-sandbox"){if(!N){ht.showMessage("请先在主编辑区打开演示文档");return}ht.showMessage("正在探测本地 Node 环境并编排 Slidev Pro 进程...");const X=await s.startProMode(N,Yo);if(!X.success){ht.showMessage(`无法启动官方 Pro 模式：${X.error}`);return}l.value="pro-cli",r.value=X.port||3030,D.value=X.url,u.value&&s.nativeBridge.attach(u.value),ht.showMessage(`🟢 已成功接入官方原生 Slidev 服务 (端口: ${r.value})`)}else s.stopProMode(),l.value="web-sandbox",D.value="/plugins/siyuan-slidev/slidev-client/index.html",u.value&&n.attach(u.value),ht.showMessage("已切回内置高保真沙箱")}function U(){I.value=!I.value,I.value?w.value=(N==null?void 0:N.docId)||"":(w.value="",E())}function G(){m.value>1&&(l.value==="pro-cli"?s.nativeBridge.navigateToPage(m.value-1):n.navigatePage(m.value-1))}function Z(){m.value<v.value&&(l.value==="pro-cli"?s.nativeBridge.navigateToPage(m.value+1):n.navigatePage(m.value+1))}function O(X){m.value=X,l.value==="pro-cli"?s.nativeBridge.navigateToPage(X):n.navigatePage(X)}function E(){e&&typeof e.compileCurrentDocument=="function"?e.compileCurrentDocument():e!=null&&e.eventBus&&typeof e.eventBus.emit=="function"&&e.eventBus.emit("slidev:request-compile")}function z(){f.value=!1,n.freezeKeyboardNav(!1)}function rt(){z()}function nt(){typeof document<"u"&&(c.value=!!document.fullscreenElement,n.postMessage("FULLSCREEN_CHANGED",{isFullscreen:c.value}))}function tt(){const X=a.value||u.value;X&&(document.fullscreenElement?document.exitFullscreen().then(()=>{n.postMessage("FULLSCREEN_CHANGED",{isFullscreen:!1})}).catch(()=>{}):X.requestFullscreen().then(()=>{n.postMessage("FULLSCREEN_CHANGED",{isFullscreen:!0})}).catch(()=>{}))}function Y(){window.open("/plugins/siyuan-slidev/slidev-client/presenter.html","SlidevPresenter","width=1200,height=800")}function ct(){if(!N){ht.showMessage("请先在主编辑区打开幻灯片文档");return}const X=aa(N);ca("presentation.html",X)&&ht.showMessage("已开始下载单文件离线 HTML 演示包")}function pt(){if(!N){ht.showMessage("请先在主编辑区打开幻灯片文档");return}da(N)&&ht.showMessage("已唤起打印视窗，请在打印选项中选择「另存为 PDF」")}return i({updateDocument(X,dt){I.value&&w.value&&dt&&dt!==w.value||(N=X,I.value&&!w.value&&(w.value=X.docId),d.value=X.slides,v.value=X.slides.length,o.setDocId(X.docId),o.updateSlidesIndex(X.slides),l.value==="pro-cli"?s.scaffolder.scaffold(X,Yo).catch(()=>{}):n.updateSlides(X.slides,X.config,X.fullMarkdown,X.customThemeCss))},navigateToBlock(X){o.onCursorFocusBlock(X)},isPinned:I,pinnedDocId:w,engineMode:l,toggleEngineMode:q}),(X,dt)=>(et(),it("div",tm,[h("div",em,[dt[4]||(dt[4]=h("div",{class:"spm-slidev-tab__title"},[h("svg",{class:"spm-slidev-tab__icon","aria-hidden":"true"},[h("use",{"xlink:href":"#iconSlidev"})]),h("span",null,"Slidev 演示预览")],-1)),h("div",im,[h("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s",disabled:m.value<=1,"aria-label":"上一页",onClick:G},[at(ut,{name:"chevron-left"})],8,nm),h("span",om,St(m.value)+" / "+St(v.value||1),1),h("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s",disabled:m.value>=v.value,"aria-label":"下一页",onClick:Z},[at(ut,{name:"chevron-right"})],8,sm),h("button",{class:It(["spm-icon-btn b3-tooltips b3-tooltips__s",{"is-primary":I.value}]),"aria-label":I.value?"已锁定当前文档（点击解除）："+w.value:"点击锁定当前文档（不随主编辑区切换）",onClick:U},[at(ut,{name:"pin"}),h("span",null,St(I.value?"已锁定":"跟随"),1)],10,rm),h("button",{class:It(["spm-icon-btn b3-tooltips b3-tooltips__s",{"is-primary":l.value==="pro-cli"}]),"aria-label":l.value==="pro-cli"?"当前：官方原生 Pro 模式 (localhost:"+r.value+")，点击切回沙箱":"当前：内置高保真沙箱，点击切换官方原生 Pro 模式",onClick:q},[at(ut,{name:"rocket"}),h("span",null,St(l.value==="pro-cli"?"Pro ("+r.value+")":"沙箱"),1)],10,lm),dt[3]||(dt[3]=h("span",{class:"spm-toolbar-divider"},null,-1)),h("button",{class:It(["spm-icon-btn b3-tooltips b3-tooltips__s",{"is-primary":b.value}]),"aria-label":"切换幻灯片大纲抽屉",onClick:dt[0]||(dt[0]=bt=>b.value=!b.value)},[at(ut,{name:"outline"})],2),h("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"双屏演讲者视图 (Presenter Mode ⌥M)",onClick:Y},[at(ut,{name:"presenter"})]),h("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"导出单文件 HTML 演示包",onClick:ct},[at(ut,{name:"export-html"})]),h("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"导出 16:9 PDF 演示讲义",onClick:pt},[at(ut,{name:"export-pdf"})]),h("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"重新编译并刷新",onClick:E},[at(ut,{name:"refresh"})]),h("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"全屏放映",onClick:tt},[at(ut,{name:"fullscreen"})])])]),h("div",{ref_key:"fullscreenContainerRef",ref:a,class:"spm-slidev-tab__viewport spm-slidev-fullscreen-container"},[h("iframe",{ref_key:"sandboxIframeRef",ref:u,class:"spm-slidev-tab__iframe",src:D.value,frameborder:"0",allow:"fullscreen; autoplay"},null,8,am),at(ah,{visible:f.value,"onUpdate:visible":dt[1]||(dt[1]=bt=>f.value=bt),"is-maximized":y.value,"onUpdate:isMaximized":dt[2]||(dt[2]=bt=>y.value=bt),title:A.value,onClose:z},{default:gl(()=>[k.value==="siyuan"&&x.value?(et(),De(vh,{key:0,"block-id":x.value,title:A.value,plugin:vt(e),onExternalJump:rt},null,8,["block-id","title","plugin"])):Rt("",!0),B.value?Te((et(),De(Rh,{key:1,visible:f.value&&k.value==="web",url:C.value,title:A.value,onExternalJump:rt},null,8,["visible","url","title"])),[[ql,k.value==="web"]]):Rt("",!0)]),_:1},8,["visible","is-maximized","title"])],512),b.value&&d.value.length>0?(et(),De(Qp,{key:0,slides:d.value,"current-active-page":m.value,onNavigate:O,onRefresh:E},null,8,["slides","current-active-page"])):Rt("",!0)]))}}),dm=ze(cm,[["__scopeId","data-v-cdfa5b82"]]),um={class:"spm-section spm-section--page"},fm={class:"spm-section-header"},pm={key:0,class:"spm-card-control",style:{"border-left":"3px solid var(--b3-theme-primary)",background:"rgba(var(--b3-theme-primary-rgb, 66, 133, 244), 0.06)",padding:"8px 12px","margin-top":"6px"}},hm={style:{display:"flex","align-items":"center","justify-content":"space-between",gap:"8px"}},mm={style:{"font-size":"11px",display:"flex","align-items":"center",gap:"6px",flex:"1"}},gm={key:1,class:"spm-card-control"},vm={class:"spm-control-header"},bm={class:"spm-control-title-group"},ym={class:"spm-control-title"},km={class:"spm-quick-chips"},wm=["onClick"],xm={style:{display:"flex",gap:"6px","align-items":"center","margin-top":"6px"}},_m=["value"],Sm=["aria-label"],Cm={key:1,class:"spm-icon-btn b3-tooltips b3-tooltips__w",disabled:"",style:{opacity:"0.45",cursor:"not-allowed",padding:"0 8px",height:"26px","font-size":"11px","white-space":"nowrap","flex-shrink":"0"},"aria-label":"当前页未检测到调整过列宽的横向超级块"},$m={key:0,style:{"margin-top":"6px","font-size":"11px",opacity:"0.85",display:"flex","align-items":"center",gap:"4px"}},Im={style:{background:"rgba(125, 125, 125, 0.15)",padding:"1px 4px","border-radius":"3px","font-weight":"bold"}},Am={key:1,style:{"margin-top":"6px","font-size":"11px",opacity:"0.6",display:"flex","align-items":"center",gap:"4px"}},Bm={class:"spm-card-control"},Tm={class:"spm-control-header"},Em={class:"spm-control-title-group"},Mm={class:"spm-control-title"},Dm={class:"spm-segmented-group"},Lm={class:"spm-card-control"},Pm={class:"spm-control-header"},Rm={class:"spm-control-title-group"},Om={class:"spm-control-title"},zm={class:"spm-quick-chips"},Nm=["onClick"],Fm=["value"],Hm={key:2,class:"spm-card-control"},jm={class:"spm-control-header"},Um={class:"spm-control-title-group"},Wm={class:"spm-control-title"},Vm={class:"spm-quick-chips"},qm=["onClick"],Km=["value"],Gm={class:"spm-card-control"},Zm={class:"spm-control-header"},Ym={class:"spm-control-title-group"},Jm={class:"spm-control-title"},Xm={key:0,class:"spm-note-status-box"},Qm=["title"],tg={class:"spm-action-grid",style:{"margin-top":"6px"}},eg={key:1,class:"spm-note-empty-box"},ig={class:"spm-batch-actions-box",style:{"margin-top":"8px","border-top":"1px dashed var(--b3-border-color, #e2e8f0)","padding-top":"8px"}},ng={class:"spm-action-grid"},og=["disabled"],sg=["disabled"],rg={class:"spm-card-control"},lg={class:"spm-action-grid"},ag=_e({__name:"PageInspectorSection",props:{pageLayout:{},pageTransition:{},pageBackground:{},pageSpacing:{},pageImage:{},pageNotes:{},pageIndex:{},pageLayoutRatio:{},detectedSbRatio:{},detectedSbInfo:{},isBatchProcessing:{type:Boolean}},emits:["update:pageLayout","update:pageTransition","update:pageBackground","update:pageSpacing","update:pageImage","update:pageLayoutRatio","applySuperBlockLayout","resetSuperblockRatio","addNoteBlock","locateNoteBlock","generateNotes","batchAppendNotes","batchDeleteNotes","insertDividerAfter","deleteDivider"],setup(t,{emit:i}){const e=t,n=i,o=_t(()=>["two-cols","cols-header","two-cols-header","three-cols-header","image-left","image-right"].includes(e.pageLayout)),s=_t(()=>{var b,f;if(e.pageLayout==="two-cols-header"||e.pageLayout==="two-cols"||e.pageLayout==="image-left"||e.pageLayout==="image-right")return 2;if(e.pageLayout==="three-cols-header")return 3;const v=(e.pageLayoutRatio||"").trim();if(v.includes(":")){const y=v.split(":").filter(Boolean).length;if(y>=2&&y<=6)return y}const d=(e.detectedSbRatio||"").trim();if(d.includes(":")){const y=d.split(":").filter(Boolean).length;if(y>=2&&y<=6)return y}if((b=e.detectedSbInfo)!=null&&b.colCount&&e.detectedSbInfo.colCount>=2)return Math.min(e.detectedSbInfo.colCount,6);if((f=e.detectedSbInfo)!=null&&f.slots&&Array.isArray(e.detectedSbInfo.slots)){const y=e.detectedSbInfo.slots.length;if(y>=2&&y<=6)return y}return 2}),l=_t(()=>{const v=s.value;return v===3?[{label:"默认 1:1:1",value:""},{label:"1:2:1 (主中)",value:"1:2:1"},{label:"2:1:1 (主左)",value:"2:1:1"},{label:"1:1:2 (主右)",value:"1:1:2"},{label:"1:3:1",value:"1:3:1"}]:v===4?[{label:"默认 1:1:1:1",value:""},{label:"1:2:2:1",value:"1:2:2:1"},{label:"2:1:1:2",value:"2:1:1:2"}]:v===5?[{label:"默认 1:1:1:1:1",value:""}]:v===6?[{label:"默认 1:1:1:1:1:1",value:""}]:[{label:"默认 1:1",value:""},{label:"1:2",value:"1:2"},{label:"2:1",value:"2:1"},{label:"3:7",value:"3:7"},{label:"7:3",value:"7:3"},{label:"4:6",value:"4:6"},{label:"6:4",value:"6:4"}]}),r=_t(()=>e.pageLayoutRatio||"");function a(){const v=s.value||2,d=Array(v).fill("1").join(":");n("update:pageLayoutRatio",d),n("resetSuperblockRatio")}const c=_t(()=>{if(!e.pageNotes)return"";const v=e.pageNotes.replace(/[\r\n]+/g," ").trim();return v.length>50?v.slice(0,50)+"...":v}),u=[{label:"默认",value:""},{label:"暗黑 #1e1e24",value:"#1e1e24"},{label:"极夜 #0f172a",value:"#0f172a"},{label:"极简白 #ffffff",value:"#ffffff"}],m=[{label:"默认封面",value:"https://cover.sli.dev"},{label:"清空配图",value:""}];return(v,d)=>(et(),it("div",um,[h("div",fm,[h("span",null,"幻灯片页面设置"+St(t.pageIndex?` (第 ${t.pageIndex} 页)`:""),1)]),at(oa,{"model-value":t.pageLayout,onChange:d[0]||(d[0]=b=>v.$emit("update:pageLayout",b))},null,8,["model-value"]),!o.value&&t.detectedSbRatio?(et(),it("div",pm,[h("div",hm,[h("div",mm,[at(ut,{name:"sparkles"}),h("span",null,[d[22]||(d[22]=Ie("检测到本页横向超级块列宽比例：",-1)),h("b",null,St(t.detectedSbRatio),1)])]),h("button",{class:"spm-btn-action b3-tooltips b3-tooltips__w","aria-label":"一键将本页版式设为分栏并应用超级块列宽",style:{padding:"2px 8px",height:"26px","font-size":"11px","flex-shrink":"0",background:"var(--b3-theme-primary)",color:"#fff",display:"inline-flex","align-items":"center",gap:"4px"},onClick:d[1]||(d[1]=b=>v.$emit("applySuperBlockLayout",t.detectedSbInfo||{recommendedLayout:"two-cols",ratio:t.detectedSbRatio}))},[at(ut,{name:"columns"}),d[23]||(d[23]=h("span",null,"设为分栏",-1))])])])):Rt("",!0),o.value?(et(),it("div",gm,[h("div",vm,[h("div",bm,[h("div",ym,[at(ut,{name:"ratio"}),d[24]||(d[24]=h("span",null,"分栏比例 (Ratio)",-1))]),d[25]||(d[25]=h("span",{class:"spm-control-desc"},"设置各列横向空间占比，默认平均分配",-1))])]),h("div",km,[(et(!0),it(qt,null,we(l.value,b=>(et(),it("button",{key:b.value,class:It(["spm-chip",{active:r.value===b.value}]),onClick:f=>v.$emit("update:pageLayoutRatio",b.value)},St(b.label),11,wm))),128))]),h("div",xm,[h("input",{value:t.pageLayoutRatio||"",class:"spm-input",style:{flex:"1","min-width":"0"},placeholder:"自定义比例（如 1:2 或 30:70，留空为默认）",onInput:d[2]||(d[2]=b=>v.$emit("update:pageLayoutRatio",b.target.value)),onChange:d[3]||(d[3]=b=>v.$emit("update:pageLayoutRatio",b.target.value))},null,40,_m),t.detectedSbRatio?(et(),it("button",{key:0,class:"spm-icon-btn b3-tooltips b3-tooltips__w","aria-label":`从当前页思源超级块读取实际宽度比例 (${t.detectedSbRatio}) 并应用`,style:{padding:"0 8px",height:"26px","font-size":"11px","white-space":"nowrap","flex-shrink":"0"},onClick:d[4]||(d[4]=b=>v.$emit("update:pageLayoutRatio",t.detectedSbRatio))},[at(ut,{name:"sparkles"}),d[26]||(d[26]=h("span",null,"读取",-1))],8,Sm)):(et(),it("button",Cm,[at(ut,{name:"sparkles"}),d[27]||(d[27]=h("span",null,"读取",-1))])),h("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__w","aria-label":"重置渲染比例为平均分布，并立即重置文档中超级块内容分布比例",style:{padding:"0 8px",height:"26px","font-size":"11px","white-space":"nowrap","flex-shrink":"0"},onClick:a},[at(ut,{name:"reset"}),d[28]||(d[28]=h("span",null,"重置",-1))])]),t.detectedSbRatio?(et(),it("div",$m,[at(ut,{name:"ratio"}),d[29]||(d[29]=h("span",null,"检测到思源超级块宽度：",-1)),h("code",Im,St(t.detectedSbRatio),1)])):(et(),it("div",Am,[at(ut,{name:"ratio"}),d[30]||(d[30]=h("span",null,"未检测到调宽超级块（默认各列平均分配）",-1))]))])):Rt("",!0),at(zs,{"model-value":t.pageTransition,onChange:d[5]||(d[5]=b=>v.$emit("update:pageTransition",b))},null,8,["model-value"]),h("div",Bm,[h("div",Tm,[h("div",Em,[h("div",Mm,[at(ut,{name:"ratio"}),d[31]||(d[31]=h("span",null,"页面间距 (Spacing)",-1))]),d[32]||(d[32]=h("span",{class:"spm-control-desc"},"覆盖本页内边距与顶部标题间距",-1))])]),h("div",Dm,[h("button",{class:It(["spm-segmented-item",{active:!t.pageSpacing||t.pageSpacing==="inherit"}]),onClick:d[6]||(d[6]=b=>v.$emit("update:pageSpacing","inherit"))}," 继承全局 ",2),h("button",{class:It(["spm-segmented-item",{active:t.pageSpacing==="compact"}]),onClick:d[7]||(d[7]=b=>v.$emit("update:pageSpacing","compact"))}," 紧凑 ",2),h("button",{class:It(["spm-segmented-item",{active:t.pageSpacing==="normal"}]),onClick:d[8]||(d[8]=b=>v.$emit("update:pageSpacing","normal"))}," 标准 ",2),h("button",{class:It(["spm-segmented-item",{active:t.pageSpacing==="loose"}]),onClick:d[9]||(d[9]=b=>v.$emit("update:pageSpacing","loose"))}," 宽松 ",2)])]),h("div",Lm,[h("div",Pm,[h("div",Rm,[h("div",Om,[at(ut,{name:"palette"}),d[33]||(d[33]=h("span",null,"页面背景 (Background)",-1))]),d[34]||(d[34]=h("span",{class:"spm-control-desc"},"设置当前页特定底色或壁纸",-1))])]),h("div",zm,[(et(),it(qt,null,we(u,b=>h("button",{key:b.value,class:It(["spm-chip",{active:t.pageBackground===b.value}]),onClick:f=>v.$emit("update:pageBackground",b.value)},St(b.label),11,Nm)),64))]),h("input",{value:t.pageBackground,class:"spm-input",placeholder:"自定义颜色代码或资源路径",onInput:d[10]||(d[10]=b=>v.$emit("update:pageBackground",b.target.value)),onChange:d[11]||(d[11]=b=>v.$emit("update:pageBackground",b.target.value))},null,40,Fm)]),t.pageLayout==="image-right"||t.pageLayout==="image-left"||t.pageImage?(et(),it("div",Hm,[h("div",jm,[h("div",Um,[h("div",Wm,[at(ut,{name:"image"}),d[35]||(d[35]=h("span",null,"页面图片 (Image)",-1))]),d[36]||(d[36]=h("span",{class:"spm-control-desc"},"图文分栏或页面专属配图 URL / 资源路径",-1))])]),h("div",Vm,[(et(),it(qt,null,we(m,b=>h("button",{key:b.value,class:It(["spm-chip",{active:t.pageImage===b.value}]),onClick:f=>v.$emit("update:pageImage",b.value)},St(b.label),11,qm)),64))]),h("input",{value:t.pageImage,class:"spm-input",placeholder:"网络图片 URL (如 https://cover.sli.dev) 或 assets/...",onInput:d[12]||(d[12]=b=>v.$emit("update:pageImage",b.target.value)),onChange:d[13]||(d[13]=b=>v.$emit("update:pageImage",b.target.value))},null,40,Km)])):Rt("",!0),h("div",Gm,[h("div",Zm,[h("div",Ym,[h("div",Jm,[at(ut,{name:"presenter"}),d[37]||(d[37]=h("span",null,"演讲者提词 (Notes)",-1))]),d[38]||(d[38]=h("span",{class:"spm-control-desc"},"正文备注块驱动 · 仅演讲者视图可见",-1))]),h("button",{class:"spm-btn-text b3-tooltips b3-tooltips__w","aria-label":"AI 自动生成本页讲稿提示块",onClick:d[14]||(d[14]=b=>v.$emit("generateNotes"))},[at(ut,{name:"sparkles"}),d[39]||(d[39]=h("span",null,"AI 讲稿",-1))])]),t.pageNotes?(et(),it("div",Xm,[d[42]||(d[42]=h("div",{class:"spm-note-status-badge"},[h("span",{class:"spm-badge-dot"}),h("span",null,"已配置正文讲稿")],-1)),h("div",{class:"spm-note-preview-text",title:t.pageNotes},St(c.value),9,Qm),h("div",tg,[h("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"在正文编辑区定位并高亮此讲稿备注块",onClick:d[15]||(d[15]=b=>v.$emit("locateNoteBlock"))},[at(ut,{name:"search"}),d[40]||(d[40]=h("span",null,"定位讲稿块",-1))]),h("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"在本页末尾追加新的讲稿提示块",onClick:d[16]||(d[16]=b=>v.$emit("addNoteBlock"))},[at(ut,{name:"insert-below"}),d[41]||(d[41]=h("span",null,"追加讲稿块",-1))])])])):(et(),it("div",eg,[d[44]||(d[44]=h("div",{class:"spm-note-empty-hint"},"本页暂无讲稿备注块",-1)),h("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s",style:{width:"100%","margin-top":"6px"},"aria-label":"在当前页末尾插入默认演讲备注提示块",onClick:d[17]||(d[17]=b=>v.$emit("addNoteBlock"))},[at(ut,{name:"insert-below"}),d[43]||(d[43]=h("span",null,"添加讲稿备注块",-1))])])),h("div",ig,[h("div",ng,[h("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s",disabled:t.isBatchProcessing,style:Sn(t.isBatchProcessing?"opacity: 0.5; cursor: not-allowed;":""),"aria-label":"在所有尚未配置讲稿的页面末尾批量追加讲稿提示块",onClick:d[18]||(d[18]=b=>v.$emit("batchAppendNotes"))},[at(ut,{name:"insert-below"}),d[45]||(d[45]=h("span",null,"全部追加",-1))],12,og),h("button",{class:"spm-btn-action spm-btn-danger b3-tooltips b3-tooltips__s",disabled:t.isBatchProcessing,style:Sn(t.isBatchProcessing?"opacity: 0.5; cursor: not-allowed;":""),"aria-label":"批量物理删除正文中的全部讲稿备注块（涉及全部页）",onClick:d[19]||(d[19]=b=>v.$emit("batchDeleteNotes"))},[at(ut,{name:"trash"}),d[46]||(d[46]=h("span",null,"全部删除",-1))],12,sg)])])]),h("div",rg,[d[49]||(d[49]=h("div",{class:"spm-control-header"},[h("div",{class:"spm-control-title-group"},[h("span",{class:"spm-control-title"},"分页快捷操作")])],-1)),h("div",lg,[h("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"在此分页符之后插入新的空白分页",onClick:d[20]||(d[20]=b=>v.$emit("insertDividerAfter"))},[at(ut,{name:"insert-below"}),d[47]||(d[47]=h("span",null,"插入新页",-1))]),h("button",{class:"spm-btn-action spm-btn-danger b3-tooltips b3-tooltips__s","aria-label":"彻底删除当前分页符（合并前后页面）",onClick:d[21]||(d[21]=b=>v.$emit("deleteDivider"))},[at(ut,{name:"trash"}),d[48]||(d[48]=h("span",null,"删除此页",-1))])])])]))}}),cg=ze(ag,[["__scopeId","data-v-246d804f"]]),dg={class:"spm-section spm-section--block"},ug={key:0,class:"spm-card-control",style:{"border-left":"3px solid var(--b3-theme-primary)"}},fg={class:"spm-control-header"},pg={class:"spm-control-title-group"},hg={class:"spm-control-title"},mg={style:{background:"var(--b3-theme-surface)",border:"1px solid var(--b3-theme-surface-lighter)","border-radius":"6px",padding:"10px","margin-bottom":"8px"}},gg={style:{display:"flex","align-items":"center","justify-content":"space-between","margin-bottom":"4px"}},vg={style:{"font-size":"12px","font-weight":"500",display:"flex","align-items":"center",gap:"4px"}},bg={key:0},yg={key:1},kg={style:{background:"rgba(var(--b3-theme-primary-rgb, 59, 130, 246), 0.16)",color:"var(--b3-theme-primary)",border:"1px solid rgba(var(--b3-theme-primary-rgb, 59, 130, 246), 0.3)",padding:"2px 6px","border-radius":"4px","font-weight":"bold","font-size":"12px"}},wg={style:{"font-size":"11px",opacity:"0.75","line-height":"1.4"}},xg={class:"spm-action-grid"},_g={class:"spm-card-control"},Sg={class:"spm-control-header"},Cg={class:"spm-control-title-group"},$g={class:"spm-control-title"},Ig=["aria-label"],Ag=["checked"],Bg={key:1,class:"spm-card-control"},Tg={class:"spm-control-header"},Eg={class:"spm-control-title-group"},Mg={class:"spm-control-title"},Dg={class:"spm-quick-chips"},Lg={key:2,class:"spm-card-control"},Pg={class:"spm-control-header"},Rg={class:"spm-control-title-group"},Og={class:"spm-control-title"},zg={class:"spm-video-settings-grid",style:{display:"grid","grid-template-columns":"1fr 1fr",gap:"8px","margin-top":"8px"}},Ng={class:"spm-toggle-item",style:{display:"flex","align-items":"center","justify-content":"space-between",padding:"4px 6px",background:"rgba(125,125,125,0.06)","border-radius":"4px"}},Fg={style:{"font-size":"11px",display:"inline-flex","align-items":"center",gap:"4px"}},Hg=["aria-label"],jg=["checked"],Ug={class:"spm-toggle-item",style:{display:"flex","align-items":"center","justify-content":"space-between",padding:"4px 6px",background:"rgba(125,125,125,0.06)","border-radius":"4px"}},Wg={style:{"font-size":"11px",display:"inline-flex","align-items":"center",gap:"4px"}},Vg=["aria-label"],qg=["checked"],Kg={class:"spm-toggle-item",style:{display:"flex","align-items":"center","justify-content":"space-between",padding:"4px 6px",background:"rgba(125,125,125,0.06)","border-radius":"4px"}},Gg={style:{"font-size":"11px",display:"inline-flex","align-items":"center",gap:"4px"}},Zg=["aria-label"],Yg=["checked"],Jg={class:"spm-toggle-item",style:{display:"flex","align-items":"center","justify-content":"space-between",padding:"4px 6px",background:"rgba(125,125,125,0.06)","border-radius":"4px"}},Xg={style:{"font-size":"11px",display:"inline-flex","align-items":"center",gap:"4px"}},Qg=["aria-label"],tv=["checked"],ev={class:"spm-card-control"},iv={class:"spm-control-header"},nv={class:"spm-control-title-group"},ov={class:"spm-control-title"},sv=["aria-label"],rv=["checked"],lv={key:0,class:"spm-quick-chips"},av=["onClick"],cv={class:"spm-card-control"},dv={class:"spm-control-header"},uv={class:"spm-control-title-group"},fv={class:"spm-control-title"},pv=["aria-label"],hv=["checked"],mv={key:0,class:"spm-quick-chips"},gv=["onClick"],vv={key:1,class:"spm-motion-details",style:{display:"flex","flex-direction":"column",gap:"4px","margin-top":"4px"}},bv={style:{display:"flex",gap:"8px","justify-content":"space-between","font-size":"11px",opacity:"0.8"}},yv={style:{display:"flex",gap:"6px"}},kv=["value"],wv=["value"],xv={key:3,class:"spm-card-control"},_v={class:"spm-control-header"},Sv={class:"spm-control-title-group"},Cv={class:"spm-control-title"},$v={class:"spm-control-desc"},Iv={class:"spm-segmented-group"},Av=["onClick"],Bv={key:4,class:"spm-card-control"},Tv={class:"spm-control-header"},Ev={class:"spm-control-title-group"},Mv={class:"spm-control-title"},Dv={class:"spm-quick-chips"},Lv=["onClick"],Pv=["value"],Rv={key:5,class:"spm-card-control"},Ov={class:"spm-control-header"},zv={class:"spm-control-title-group"},Nv={class:"spm-control-title"},Fv={class:"spm-quick-chips"},Hv=["onClick"],jv=["value"],Uv={class:"spm-card-control"},Wv={class:"spm-action-grid"},Vv=["aria-label"],qv=_e({__name:"BlockInspectorSection",props:{elemClick:{},elemMotion:{},elemSlot:{},elemShikiLines:{},elemMaxHeight:{},isCodeBlock:{type:Boolean},isImage:{type:Boolean},isVideo:{type:Boolean},videoAutoplay:{type:Boolean},videoLoop:{type:Boolean},videoMuted:{type:Boolean},videoControls:{type:Boolean},hasBlockAttrs:{type:Boolean},isNote:{type:Boolean},imageRole:{},currentSlideLayout:{},isSuperBlock:{type:Boolean},detectedSbInfo:{}},emits:["toggleNote","toggleElemClick","update:elemClick","update:elemMotion","update:elemSlot","update:elemShikiLines","update:elemMaxHeight","applySuperBlockLayout","applySuperBlockRatio","insertDividerBefore","insertDividerAfter","setTwoColsContrast","clearBlockAttrs","update:imageRole","toggleVideoAutoplay","toggleVideoLoop","toggleVideoMuted","toggleVideoControls"],setup(t,{emit:i}){const e=t,n=_t(()=>{const I=e.currentSlideLayout||"";return["col-1","col-2","col-3","col-4","col-5","col-6"].includes(e.elemSlot)?"cols-header":I}),o=_t(()=>{const I=n.value;return["two-cols","cols-header","two-cols-header","three-cols-header"].includes(I)}),s=_t(()=>{var w,D,P,R;if((w=e.detectedSbInfo)!=null&&w.colCount&&e.detectedSbInfo.colCount>=2)return Math.min(e.detectedSbInfo.colCount,6);const I=(D=e.elemSlot)==null?void 0:D.match(/^col-(\d+)$/);if(I){const J=parseInt(I[1],10);if(J>=2&&J<=6)return Math.max(J,3)}if(e.currentSlideLayout==="three-cols-header")return 3;if(e.currentSlideLayout==="two-cols-header"||e.currentSlideLayout==="two-cols")return 2;if((R=(P=e.detectedSbInfo)==null?void 0:P.ratio)!=null&&R.includes(":")){const J=e.detectedSbInfo.ratio.split(":").filter(Boolean);if(J.length>=2)return Math.min(J.length,6)}return 3}),l=_t(()=>{const I=n.value;return I==="cols-header"?"多栏插槽归属 (Slot)":I==="three-cols-header"?"三栏插槽归属 (Slot)":I==="two-cols-header"?"带表头双栏插槽 (Slot)":"多栏插槽归属 (Slot)"}),r=_t(()=>{const I=n.value;return I==="cols-header"?`在 cols-header 表头多栏（${s.value} 栏）中的内容块位置`:I==="three-cols-header"?"在 three-cols-header 版式中的内容块位置":I==="two-cols-header"?"在 two-cols-header 版式中的内容块位置":I==="two-cols"?"在 two-cols 双栏版式中的归属":"在当前分栏版式中的内容块位置"}),a=_t(()=>{const I=n.value;if(I==="two-cols")return[{value:"",label:"默认 (左)"},{value:"right",label:"右栏"}];if(I==="two-cols-header")return[{value:"",label:"默认"},{value:"header",label:"表头"},{value:"left",label:"左栏"},{value:"right",label:"右栏"}];if(I==="three-cols-header")return[{value:"",label:"默认"},{value:"header",label:"表头"},{value:"col-1",label:"第 1 栏"},{value:"col-2",label:"第 2 栏"},{value:"col-3",label:"第 3 栏"}];const w=s.value,D=[{value:"",label:"默认"},{value:"header",label:"表头"}];for(let P=1;P<=w;P++)D.push({value:`col-${P}`,label:`第 ${P} 栏`});return D});function c(I){const w=e.elemSlot||"";return I?w===I||I==="col-1"&&w==="left"||I==="col-2"&&w==="center"||I==="col-3"&&w==="right"&&s.value===3||I==="col-2"&&w==="right"&&s.value===2||I==="left"&&w==="col-1"||I==="right"&&(w==="col-2"||w==="col-3"):!w||w==="default"}const u=i,m=[{label:"上浮 (slide-up)",value:"slide-up"},{label:"淡入 (fade-in)",value:"fade-in"},{label:"下沉 (slide-down)",value:"slide-down"},{label:"左滑 (slide-left)",value:"slide-left"},{label:"右滑 (slide-right)",value:"slide-right"},{label:"缩放 (zoom-in)",value:"zoom-in"},{label:"弹性 (bounce)",value:"bounce"}],v=_t(()=>{if(!e.elemMotion||e.elemMotion.trim()===""||e.elemMotion.trim()==="none")return null;try{const I=JSON.parse(e.elemMotion);if(typeof I=="object"&&I!==null)return{preset:I.preset||I.type||"slide-up",duration:typeof I.duration=="number"?I.duration:0,delay:typeof I.delay=="number"?I.delay:0}}catch{}return{preset:e.elemMotion.trim(),duration:0,delay:0}}),d=_t(()=>!!v.value),b=_t(()=>{var I;return((I=v.value)==null?void 0:I.preset)||"slide-up"}),f=_t(()=>{var I;return((I=v.value)==null?void 0:I.duration)||0}),y=_t(()=>{var I;return((I=v.value)==null?void 0:I.delay)||0});function k(){d.value?u("update:elemMotion",""):u("update:elemMotion","slide-up")}function x(I){B(I,f.value,y.value)}function C(I){B(b.value,I,y.value)}function A(I){B(b.value,f.value,I)}function B(I,w,D){if(!I||I==="none"){u("update:elemMotion","");return}if(!w&&!D){u("update:elemMotion",I);return}const P={preset:I};w>0&&(P.duration=w),D>0&&(P.delay=D),u("update:elemMotion",JSON.stringify(P))}return(I,w)=>{var D,P,R,J,S,H;return et(),it("div",dg,[w[61]||(w[61]=h("div",{class:"spm-section-header"},[h("span",null,"元素动效与排版")],-1)),t.isSuperBlock||(D=t.detectedSbInfo)!=null&&D.hasSuperBlock?(et(),it("div",ug,[h("div",fg,[h("div",pg,[h("div",hg,[at(ut,{name:"ratio"}),w[24]||(w[24]=h("span",null,"超级块列宽与布局",-1))]),w[25]||(w[25]=h("span",{class:"spm-control-desc"},"读取思源超级块列宽并一键同步到幻灯片分栏",-1))])]),h("div",mg,[h("div",gg,[h("div",vg,[at(ut,{name:"ratio"}),(P=t.detectedSbInfo)!=null&&P.isCustomWidth?(et(),it("span",bg,"已识别自定义列宽比例")):(et(),it("span",yg,"识别到 "+St(((R=t.detectedSbInfo)==null?void 0:R.colCount)||2)+" 列超级块分栏",1))]),h("code",kg,St(((J=t.detectedSbInfo)==null?void 0:J.ratio)||"1:1"),1)]),h("div",wg,St((S=t.detectedSbInfo)!=null&&S.isCustomWidth?"检测到已调节子块宽度，可一键应用为当前页分栏比例。":"当前超级块子列为思源默认均宽，可在思源中拖动调节或直接应用。"),1)]),h("div",xg,[h("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"一键将当前页版式切换为对应双栏/三栏，并写入此列宽比例",style:{background:"rgba(var(--b3-theme-primary-rgb, 59, 130, 246), 0.16)",color:"var(--b3-theme-primary)","font-weight":"500",border:"1px solid rgba(var(--b3-theme-primary-rgb, 59, 130, 246), 0.3)"},onClick:w[0]||(w[0]=g=>I.$emit("applySuperBlockLayout",t.detectedSbInfo))},[at(ut,{name:"sparkles"}),w[26]||(w[26]=h("span",null,"应用版式与比例",-1))]),h("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"仅将提取的比值写入当前页的分栏比例属性",onClick:w[1]||(w[1]=g=>{var N;return I.$emit("applySuperBlockRatio",((N=t.detectedSbInfo)==null?void 0:N.ratio)||"1:1")})},[at(ut,{name:"check"}),h("span",null,"应用比例 ("+St(((H=t.detectedSbInfo)==null?void 0:H.ratio)||"1:1")+")",1)])])])):Rt("",!0),h("div",_g,[h("div",Sg,[h("div",Cg,[h("div",$g,[at(ut,{name:"presenter"}),w[27]||(w[27]=h("span",null,"设为讲稿备注 (slidev-note)",-1))]),w[28]||(w[28]=h("span",{class:"spm-control-desc"},"作为当前页演讲提词，不在幻灯片中渲染",-1))]),h("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":t.isNote?"取消讲稿备注":"设为讲稿备注"},[h("input",{type:"checkbox",checked:!!t.isNote,onChange:w[2]||(w[2]=g=>I.$emit("toggleNote"))},null,40,Ag),w[29]||(w[29]=h("span",{class:"spm-switch-slider"},null,-1))],8,Ig)])]),t.isImage||t.imageRole?(et(),it("div",Bg,[h("div",Tg,[h("div",Eg,[h("div",Mg,[at(ut,{name:"image"}),w[30]||(w[30]=h("span",null,"图片角色与分栏 (Image & Layout)",-1))]),w[31]||(w[31]=h("span",{class:"spm-control-desc"},"设为幻灯片背景图或图文分栏配图",-1))])]),h("div",Dg,[h("button",{class:It(["spm-chip",{active:!t.imageRole}]),onClick:w[3]||(w[3]=g=>I.$emit("update:imageRole",""))}," 普通内容 ",2),h("button",{class:It(["spm-chip",{active:t.imageRole==="background"}]),onClick:w[4]||(w[4]=g=>I.$emit("update:imageRole","background"))},[at(ut,{name:"image"}),w[32]||(w[32]=h("span",null,"背景图",-1))],2),h("button",{class:It(["spm-chip",{active:t.imageRole==="image-left"}]),onClick:w[5]||(w[5]=g=>I.$emit("update:imageRole","image-left"))},[at(ut,{name:"image-left"}),w[33]||(w[33]=h("span",null,"图左",-1))],2),h("button",{class:It(["spm-chip",{active:t.imageRole==="image-right"}]),onClick:w[6]||(w[6]=g=>I.$emit("update:imageRole","image-right"))},[at(ut,{name:"image-right"}),w[34]||(w[34]=h("span",null,"图右",-1))],2)])])):Rt("",!0),t.isVideo?(et(),it("div",Lg,[h("div",Pg,[h("div",Rg,[h("div",Og,[at(ut,{name:"video"}),w[35]||(w[35]=h("span",null,"视频播放设置 (Video Playback)",-1))]),w[36]||(w[36]=h("span",{class:"spm-control-desc"},"配置播放器控制条、自动播放与循环",-1))])]),h("div",zg,[h("div",Ng,[h("span",Fg,[at(ut,{name:"sliders"}),w[37]||(w[37]=Ie(" 控制条",-1))]),h("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":t.videoControls?"关闭控制条":"开启控制条"},[h("input",{type:"checkbox",checked:!!t.videoControls,onChange:w[7]||(w[7]=g=>I.$emit("toggleVideoControls"))},null,40,jg),w[38]||(w[38]=h("span",{class:"spm-switch-slider"},null,-1))],8,Hg)]),h("div",Ug,[h("span",Wg,[at(ut,{name:"video"}),w[39]||(w[39]=Ie(" 自动播放",-1))]),h("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":t.videoAutoplay?"关闭自动播放":"开启自动播放"},[h("input",{type:"checkbox",checked:!!t.videoAutoplay,onChange:w[8]||(w[8]=g=>I.$emit("toggleVideoAutoplay"))},null,40,qg),w[40]||(w[40]=h("span",{class:"spm-switch-slider"},null,-1))],8,Vg)]),h("div",Kg,[h("span",Gg,[at(ut,{name:"repeat"}),w[41]||(w[41]=Ie(" 循环播放",-1))]),h("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":t.videoLoop?"关闭循环播放":"开启循环播放"},[h("input",{type:"checkbox",checked:!!t.videoLoop,onChange:w[9]||(w[9]=g=>I.$emit("toggleVideoLoop"))},null,40,Yg),w[42]||(w[42]=h("span",{class:"spm-switch-slider"},null,-1))],8,Zg)]),h("div",Jg,[h("span",Xg,[at(ut,{name:"volume-x"}),w[43]||(w[43]=Ie(" 静音播放",-1))]),h("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":t.videoMuted?"关闭静音":"开启静音"},[h("input",{type:"checkbox",checked:!!t.videoMuted,onChange:w[10]||(w[10]=g=>I.$emit("toggleVideoMuted"))},null,40,tv),w[44]||(w[44]=h("span",{class:"spm-switch-slider"},null,-1))],8,Qg)])])])):Rt("",!0),h("div",ev,[h("div",iv,[h("div",nv,[h("div",ov,[at(ut,{name:"step"}),w[45]||(w[45]=h("span",null,"逐步呈现 (v-click)",-1))]),w[46]||(w[46]=h("span",{class:"spm-control-desc"},"放映时按步长逐个呈现",-1))]),h("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":t.elemClick?"关闭逐步呈现":"开启逐步呈现 (+1)"},[h("input",{type:"checkbox",checked:!!t.elemClick,onChange:w[11]||(w[11]=g=>I.$emit("toggleElemClick"))},null,40,rv),w[47]||(w[47]=h("span",{class:"spm-switch-slider"},null,-1))],8,sv)]),t.elemClick?(et(),it("div",lv,[(et(),it(qt,null,we(["+1","1","2","hide"],g=>h("button",{key:g,class:It(["spm-chip",{active:t.elemClick===g}]),onClick:N=>I.$emit("update:elemClick",g)},St(g==="+1"?"顺延 (+1)":g==="hide"?"隐藏 (hide)":"第 "+g+" 步"),11,av)),64))])):Rt("",!0)]),h("div",cv,[h("div",dv,[h("div",uv,[h("div",fv,[at(ut,{name:"motion"}),w[48]||(w[48]=h("span",null,"入场微动效 (v-motion)",-1))]),w[49]||(w[49]=h("span",{class:"spm-control-desc"},"为当前块添加平滑位移与渐入动画",-1))]),h("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":d.value?"关闭微动效":"开启微动效 (slide-up)"},[h("input",{type:"checkbox",checked:d.value,onChange:k},null,40,hv),w[50]||(w[50]=h("span",{class:"spm-switch-slider"},null,-1))],8,pv)]),d.value?(et(),it("div",mv,[(et(),it(qt,null,we(m,g=>h("button",{key:g.value,class:It(["spm-chip",{active:b.value===g.value}]),onClick:N=>x(g.value)},St(g.label),11,gv)),64))])):Rt("",!0),d.value?(et(),it("div",vv,[h("div",bv,[h("span",null,"时长: "+St(f.value?f.value+"ms":"默认 (450ms)"),1),h("span",null,"延迟: "+St(y.value?y.value+"ms":"0ms"),1)]),h("div",yv,[h("select",{class:"spm-select",style:{flex:"1"},value:f.value,onChange:w[12]||(w[12]=g=>C(Number(g.target.value)))},[...w[51]||(w[51]=[h("option",{value:0},"默认耗时",-1),h("option",{value:200},"极速 (200ms)",-1),h("option",{value:350},"较快 (350ms)",-1),h("option",{value:500},"平滑 (500ms)",-1),h("option",{value:800},"缓慢 (800ms)",-1)])],40,kv),h("select",{class:"spm-select",style:{flex:"1"},value:y.value,onChange:w[13]||(w[13]=g=>A(Number(g.target.value)))},[...w[52]||(w[52]=[h("option",{value:0},"无延迟",-1),h("option",{value:150},"延迟 150ms",-1),h("option",{value:300},"延迟 300ms",-1),h("option",{value:500},"延迟 500ms",-1)])],40,wv)])])):Rt("",!0)]),o.value||t.elemSlot?(et(),it("div",xv,[h("div",_v,[h("div",Sv,[h("div",Cv,[at(ut,{name:"columns"}),h("span",null,St(l.value),1)]),h("span",$v,St(r.value),1)])]),h("div",Iv,[(et(!0),it(qt,null,we(a.value,g=>(et(),it("button",{key:g.value,class:It(["spm-segmented-item",{active:c(g.value)}]),onClick:N=>I.$emit("update:elemSlot",g.value)},St(g.label),11,Av))),128))])])):Rt("",!0),t.isCodeBlock?(et(),it("div",Bv,[h("div",Tv,[h("div",Ev,[h("div",Mv,[at(ut,{name:"code"}),w[53]||(w[53]=h("span",null,"代码逐行聚光 (Shiki)",-1))]),w[54]||(w[54]=h("span",{class:"spm-control-desc"},"翻页时动态聚光高亮特定行",-1))])]),h("div",Dv,[(et(),it(qt,null,we(["1-3","all","1|2|3","2-5"],g=>h("button",{key:g,class:It(["spm-chip",{active:t.elemShikiLines===g}]),onClick:N=>I.$emit("update:elemShikiLines",g)},St(g),11,Lv)),64)),t.elemShikiLines?(et(),it("button",{key:0,class:"spm-chip spm-chip-clear",onClick:w[14]||(w[14]=g=>I.$emit("update:elemShikiLines",""))}," 清空 ")):Rt("",!0)]),h("input",{value:t.elemShikiLines,class:"spm-input",placeholder:"自定义高亮区间，如 1-3|5|all",onInput:w[15]||(w[15]=g=>I.$emit("update:elemShikiLines",g.target.value)),onChange:w[16]||(w[16]=g=>I.$emit("update:elemShikiLines",g.target.value))},null,40,Pv)])):Rt("",!0),t.isCodeBlock?(et(),it("div",Rv,[h("div",Ov,[h("div",zv,[h("div",Nv,[at(ut,{name:"code"}),w[55]||(w[55]=h("span",null,"代码块限高 (Max Height)",-1))]),w[56]||(w[56]=h("span",{class:"spm-control-desc"},"超出限高自动竖向滚动，弱提示滚动条",-1))])]),h("div",Fv,[(et(),it(qt,null,we(["240px","320px","400px","50vh"],g=>h("button",{key:g,class:It(["spm-chip",{active:t.elemMaxHeight===g}]),onClick:N=>I.$emit("update:elemMaxHeight",g)},St(g),11,Hv)),64)),t.elemMaxHeight?(et(),it("button",{key:0,class:"spm-chip spm-chip-clear",onClick:w[17]||(w[17]=g=>I.$emit("update:elemMaxHeight",""))}," 自适应 ")):Rt("",!0)]),h("input",{value:t.elemMaxHeight,class:"spm-input",placeholder:"自适应高度，或输入 350px、50vh",onInput:w[18]||(w[18]=g=>I.$emit("update:elemMaxHeight",g.target.value)),onChange:w[19]||(w[19]=g=>I.$emit("update:elemMaxHeight",g.target.value))},null,40,jv)])):Rt("",!0),h("div",Uv,[w[60]||(w[60]=h("div",{class:"spm-control-header"},[h("div",{class:"spm-control-title-group"},[h("span",{class:"spm-control-title"},"快捷操作")])],-1)),h("div",Wv,[h("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"在当前块上方插入幻灯片分页线 (---)",onClick:w[20]||(w[20]=g=>I.$emit("insertDividerBefore"))},[at(ut,{name:"insert-above"}),w[57]||(w[57]=h("span",null,"上方分页",-1))]),h("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"在当前块下方插入幻灯片分页线 (---)",onClick:w[21]||(w[21]=g=>I.$emit("insertDividerAfter"))},[at(ut,{name:"insert-below"}),w[58]||(w[58]=h("span",null,"下方分页",-1))]),h("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":n.value==="three-cols-header"?"将当前块属性设为三栏第1栏归属 (slot: col-1)":"将当前块属性设为双栏左侧归属 (slot: left)",onClick:w[22]||(w[22]=g=>I.$emit("setTwoColsContrast"))},[at(ut,{name:"columns"}),h("span",null,St(n.value==="three-cols-header"?"设为第1栏":"设为双栏"),1)],8,Vv),t.hasBlockAttrs?(et(),it("button",{key:0,class:"spm-btn-action spm-btn-danger b3-tooltips b3-tooltips__s","aria-label":"一键移除本块所有 custom-slidev 属性",onClick:w[23]||(w[23]=g=>I.$emit("clearBlockAttrs"))},[at(ut,{name:"broom"}),w[59]||(w[59]=h("span",null,"清除属性",-1))])):Rt("",!0)])])])}}}),Kv={class:"spm-section spm-section--doc"},Gv={class:"spm-card-control"},Zv={class:"spm-control-header"},Yv={class:"spm-control-title-group"},Jv={class:"spm-control-title"},Xv={class:"spm-segmented-group"},Qv=["aria-label","onClick"],t1={class:"spm-card-control"},e1={class:"spm-control-header"},i1={class:"spm-control-title-group"},n1={class:"spm-control-title"},o1={class:"spm-segmented-group"},s1={class:"spm-card-control"},r1={class:"spm-control-header"},l1={class:"spm-control-title-group"},a1={class:"spm-control-title"},c1={class:"spm-segmented-group"},d1={class:"spm-card-control"},u1={class:"spm-control-header"},f1={class:"spm-control-title-group"},p1={class:"spm-control-title"},h1={class:"spm-card-control"},m1={class:"spm-control-header"},g1={class:"spm-control-title-group"},v1={class:"spm-control-title"},b1=["aria-label"],y1=["checked"],k1={key:0,class:"spm-control-body",style:{"margin-top":"8px"}},w1=["value"],x1={class:"spm-card-control"},_1={class:"spm-control-header"},S1={class:"spm-control-title-group"},C1={class:"spm-control-title"},$1=["aria-label"],I1=["checked"],A1={class:"spm-card-control"},B1={class:"spm-action-grid"},T1=_e({__name:"DocInspectorSection",props:{docTheme:{},docAspectRatio:{},docDefaultTransition:{},docSpacing:{}},emits:["update:docTheme","update:docAspectRatio","update:docDefaultTransition","update:docSpacing","openBottomPreview","openPresenter","aiAutoSplit","exportHtml","exportPdf"],setup(t){const i=ti("plugin"),e=hi,n=[{value:"default",label:"默认 default",desc:"官方默认科技风：现代无衬线排版与清新代码语法高亮，通用汇报与技术分享首选"},{value:"seriph",label:"优雅 seriph",desc:"典雅学术衬线风：书卷学术质感、衬线字体典雅庄重，适合学术论文、人文讲座与深度阅读"},{value:"apple-basic",label:"极简 apple",desc:"苹果发布会极简风：大字号、高对比度与极致留白，适合产品发布、方案演讲与纯粹视觉呈现"}];function o(a){Ei({enableWebServeJump:a}),i&&typeof i.saveGlobalSettings=="function"&&i.saveGlobalSettings({enableWebServeJump:a})}function s(a){Ei({normalizeHeadingSizes:a}),i&&typeof i.saveGlobalSettings=="function"&&i.saveGlobalSettings({normalizeHeadingSizes:a})}function l(a){Ei({webServeUrl:a})}function r(a){Ei({webServeUrl:a}),i&&typeof i.saveGlobalSettings=="function"&&i.saveGlobalSettings({webServeUrl:a})}return(a,c)=>(et(),it("div",Kv,[c[39]||(c[39]=h("div",{class:"spm-section-header"},[h("span",null,"全局演示配置")],-1)),h("div",Gv,[h("div",Zv,[h("div",Yv,[h("div",Jv,[at(ut,{name:"palette"}),c[18]||(c[18]=h("span",null,"幻灯片主题 (Theme)",-1))]),c[19]||(c[19]=h("span",{class:"spm-control-desc"},"全局 Slidev 视觉设计范式",-1))])]),h("div",Xv,[(et(),it(qt,null,we(n,u=>h("button",{key:u.value,class:It(["spm-segmented-item b3-tooltips b3-tooltips__s",{active:t.docTheme===u.value}]),"aria-label":u.desc,onClick:m=>a.$emit("update:docTheme",u.value)},St(u.label),11,Qv)),64))])]),h("div",t1,[h("div",e1,[h("div",i1,[h("div",n1,[at(ut,{name:"ratio"}),c[20]||(c[20]=h("span",null,"画幅比例 (Aspect Ratio)",-1))]),c[21]||(c[21]=h("span",{class:"spm-control-desc"},"演讲屏幕投影宽高比",-1))])]),h("div",o1,[h("button",{class:It(["spm-segmented-item",{active:t.docAspectRatio==="16/9"}]),onClick:c[0]||(c[0]=u=>a.$emit("update:docAspectRatio","16/9"))}," 16 : 9 (宽屏) ",2),h("button",{class:It(["spm-segmented-item",{active:t.docAspectRatio==="4/3"}]),onClick:c[1]||(c[1]=u=>a.$emit("update:docAspectRatio","4/3"))}," 4 : 3 (标屏) ",2),h("button",{class:It(["spm-segmented-item",{active:t.docAspectRatio==="16/10"}]),onClick:c[2]||(c[2]=u=>a.$emit("update:docAspectRatio","16/10"))}," 16 : 10 ",2)])]),h("div",s1,[h("div",r1,[h("div",l1,[h("div",a1,[at(ut,{name:"ratio"}),c[22]||(c[22]=h("span",null,"间距风格 (Spacing)",-1))]),c[23]||(c[23]=h("span",{class:"spm-control-desc"},"内边距与顶部标题下边距预设",-1))])]),h("div",c1,[h("button",{class:It(["spm-segmented-item b3-tooltips b3-tooltips__s",{active:(t.docSpacing||"normal")==="compact"}]),"aria-label":"紧凑排版：上下 20px / 左右 36px，释放垂直空间，适配图文分栏",onClick:c[3]||(c[3]=u=>a.$emit("update:docSpacing","compact"))}," 紧凑 (Compact) ",2),h("button",{class:It(["spm-segmented-item b3-tooltips b3-tooltips__s",{active:(t.docSpacing||"normal")==="normal"}]),"aria-label":"标准排版：上下 32px / 左右 48px，协调美观（推荐默认）",onClick:c[4]||(c[4]=u=>a.$emit("update:docSpacing","normal"))}," 标准 (Normal) ",2),h("button",{class:It(["spm-segmented-item b3-tooltips b3-tooltips__s",{active:(t.docSpacing||"normal")==="loose"}]),"aria-label":"宽松排版：上下 48px / 左右 56px，大留白适合极简大字",onClick:c[5]||(c[5]=u=>a.$emit("update:docSpacing","loose"))}," 宽松 (Loose) ",2)])]),h("div",d1,[h("div",u1,[h("div",f1,[h("div",p1,[at(ut,{name:"transition"}),c[24]||(c[24]=h("span",null,"全局默认转场",-1))]),c[25]||(c[25]=h("span",{class:"spm-control-desc"},"页面切换过渡动效（未单设转场的页面将继承此动效）",-1))])]),at(zs,{"model-value":t.docDefaultTransition,"hide-header":!0,onChange:c[6]||(c[6]=u=>a.$emit("update:docDefaultTransition",u))},null,8,["model-value"])]),h("div",h1,[h("div",m1,[h("div",g1,[h("div",v1,[at(ut,{name:"external-link"}),c[26]||(c[26]=h("span",null,"本地网络伺服预览 (Web Serve)",-1))]),c[27]||(c[27]=h("span",{class:"spm-control-desc"},"点击文档/块链接以 Webview 抽屉呈现，支持外跳",-1))]),h("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":vt(e).enableWebServeJump?"关闭本地网络伺服预览":"开启本地网络伺服预览"},[h("input",{type:"checkbox",checked:vt(e).enableWebServeJump,onChange:c[7]||(c[7]=u=>o(u.target.checked))},null,40,y1),c[28]||(c[28]=h("span",{class:"spm-switch-slider"},null,-1))],8,b1)]),vt(e).enableWebServeJump?(et(),it("div",k1,[h("input",{value:vt(e).webServeUrl,class:"spm-input",placeholder:"http://127.0.0.1:6806",spellcheck:"false",onKeydown:c[8]||(c[8]=Me(()=>{},["stop"])),onKeyup:c[9]||(c[9]=Me(()=>{},["stop"])),onInput:c[10]||(c[10]=u=>l(u.target.value)),onChange:c[11]||(c[11]=u=>r(u.target.value))},null,40,w1),c[29]||(c[29]=h("span",{class:"spm-control-desc",style:{display:"block","margin-top":"4px","font-size":"11px",opacity:"0.8"}}," 默认伺服地址为 http://127.0.0.1:6806。开启后点击块链接将在 Webview 抽屉中打开，点击抽屉顶部『外跳』可在外部浏览器打开 ",-1))])):Rt("",!0)]),h("div",x1,[h("div",_1,[h("div",S1,[h("div",C1,[at(ut,{name:"type"}),c[30]||(c[30]=h("span",null,"固定特定标题大小",-1))]),c[31]||(c[31]=h("span",{class:"spm-control-desc"},"除封面外页首标题按 H2、多栏内首标题按 H3 大小展示",-1))]),h("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":vt(e).normalizeHeadingSizes?"关闭固定特定标题大小":"开启固定特定标题大小"},[h("input",{type:"checkbox",checked:vt(e).normalizeHeadingSizes,onChange:c[12]||(c[12]=u=>s(u.target.checked))},null,40,I1),c[32]||(c[32]=h("span",{class:"spm-switch-slider"},null,-1))],8,$1)])]),h("div",A1,[c[38]||(c[38]=h("div",{class:"spm-control-header"},[h("div",{class:"spm-control-title-group"},[h("span",{class:"spm-control-title"},"演示全局操作")])],-1)),h("div",B1,[h("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"在当前文档下方开启分屏同步预览 (Alt+P)",onClick:c[13]||(c[13]=u=>a.$emit("openBottomPreview"))},[at(ut,{name:"split-preview"}),c[33]||(c[33]=h("span",null,"分屏预览",-1))]),h("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"打开双屏演讲者控制台视窗 (Alt+M)",onClick:c[14]||(c[14]=u=>a.$emit("openPresenter"))},[at(ut,{name:"presenter"}),c[34]||(c[34]=h("span",null,"演讲者视图",-1))]),h("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"智能分析长文本结构并给出大纲分页插入建议",onClick:c[15]||(c[15]=u=>a.$emit("aiAutoSplit"))},[at(ut,{name:"sparkles"}),c[35]||(c[35]=h("span",null,"AI 智能分页",-1))]),h("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"打包导出离线单文件 HTML 幻灯片",onClick:c[16]||(c[16]=u=>a.$emit("exportHtml"))},[at(ut,{name:"export-html"}),c[36]||(c[36]=h("span",null,"导出 HTML",-1))]),h("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"打印生成 16:9 高清演示 PDF 讲义",onClick:c[17]||(c[17]=u=>a.$emit("exportPdf"))},[at(ut,{name:"export-pdf"}),c[37]||(c[37]=h("span",null,"导出 PDF",-1))])])])]))}});var Kn=typeof globalThis<"u"?globalThis:typeof window<"u"?window:typeof global<"u"?global:typeof self<"u"?self:{};function E1(t){return t&&t.__esModule&&Object.prototype.hasOwnProperty.call(t,"default")?t.default:t}function Gn(t){throw new Error('Could not dynamically require "'+t+'". Please configure the dynamicRequireTargets or/and ignoreDynamicRequires option of @rollup/plugin-commonjs appropriately for this require call to work.')}var Ko={exports:{}};/*!

JSZip v3.10.1 - A JavaScript class for generating and reading zip files
<http://stuartk.com/jszip>

(c) 2009-2016 Stuart Knightley <stuart [at] stuartk.com>
Dual licenced under the MIT license or GPLv3. See https://raw.github.com/Stuk/jszip/main/LICENSE.markdown.

JSZip uses the library pako released under the MIT license :
https://github.com/nodeca/pako/blob/main/LICENSE
*/var Tr;function M1(){return Tr||(Tr=1,(function(t,i){(function(e){t.exports=e()})(function(){return(function e(n,o,s){function l(c,u){if(!o[c]){if(!n[c]){var m=typeof Gn=="function"&&Gn;if(!u&&m)return m(c,!0);if(r)return r(c,!0);var v=new Error("Cannot find module '"+c+"'");throw v.code="MODULE_NOT_FOUND",v}var d=o[c]={exports:{}};n[c][0].call(d.exports,function(b){var f=n[c][1][b];return l(f||b)},d,d.exports,e,n,o,s)}return o[c].exports}for(var r=typeof Gn=="function"&&Gn,a=0;a<s.length;a++)l(s[a]);return l})({1:[function(e,n,o){var s=e("./utils"),l=e("./support"),r="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";o.encode=function(a){for(var c,u,m,v,d,b,f,y=[],k=0,x=a.length,C=x,A=s.getTypeOf(a)!=="string";k<a.length;)C=x-k,m=A?(c=a[k++],u=k<x?a[k++]:0,k<x?a[k++]:0):(c=a.charCodeAt(k++),u=k<x?a.charCodeAt(k++):0,k<x?a.charCodeAt(k++):0),v=c>>2,d=(3&c)<<4|u>>4,b=1<C?(15&u)<<2|m>>6:64,f=2<C?63&m:64,y.push(r.charAt(v)+r.charAt(d)+r.charAt(b)+r.charAt(f));return y.join("")},o.decode=function(a){var c,u,m,v,d,b,f=0,y=0,k="data:";if(a.substr(0,k.length)===k)throw new Error("Invalid base64 input, it looks like a data url.");var x,C=3*(a=a.replace(/[^A-Za-z0-9+/=]/g,"")).length/4;if(a.charAt(a.length-1)===r.charAt(64)&&C--,a.charAt(a.length-2)===r.charAt(64)&&C--,C%1!=0)throw new Error("Invalid base64 input, bad content length.");for(x=l.uint8array?new Uint8Array(0|C):new Array(0|C);f<a.length;)c=r.indexOf(a.charAt(f++))<<2|(v=r.indexOf(a.charAt(f++)))>>4,u=(15&v)<<4|(d=r.indexOf(a.charAt(f++)))>>2,m=(3&d)<<6|(b=r.indexOf(a.charAt(f++))),x[y++]=c,d!==64&&(x[y++]=u),b!==64&&(x[y++]=m);return x}},{"./support":30,"./utils":32}],2:[function(e,n,o){var s=e("./external"),l=e("./stream/DataWorker"),r=e("./stream/Crc32Probe"),a=e("./stream/DataLengthProbe");function c(u,m,v,d,b){this.compressedSize=u,this.uncompressedSize=m,this.crc32=v,this.compression=d,this.compressedContent=b}c.prototype={getContentWorker:function(){var u=new l(s.Promise.resolve(this.compressedContent)).pipe(this.compression.uncompressWorker()).pipe(new a("data_length")),m=this;return u.on("end",function(){if(this.streamInfo.data_length!==m.uncompressedSize)throw new Error("Bug : uncompressed data size mismatch")}),u},getCompressedWorker:function(){return new l(s.Promise.resolve(this.compressedContent)).withStreamInfo("compressedSize",this.compressedSize).withStreamInfo("uncompressedSize",this.uncompressedSize).withStreamInfo("crc32",this.crc32).withStreamInfo("compression",this.compression)}},c.createWorkerFrom=function(u,m,v){return u.pipe(new r).pipe(new a("uncompressedSize")).pipe(m.compressWorker(v)).pipe(new a("compressedSize")).withStreamInfo("compression",m)},n.exports=c},{"./external":6,"./stream/Crc32Probe":25,"./stream/DataLengthProbe":26,"./stream/DataWorker":27}],3:[function(e,n,o){var s=e("./stream/GenericWorker");o.STORE={magic:"\0\0",compressWorker:function(){return new s("STORE compression")},uncompressWorker:function(){return new s("STORE decompression")}},o.DEFLATE=e("./flate")},{"./flate":7,"./stream/GenericWorker":28}],4:[function(e,n,o){var s=e("./utils"),l=(function(){for(var r,a=[],c=0;c<256;c++){r=c;for(var u=0;u<8;u++)r=1&r?3988292384^r>>>1:r>>>1;a[c]=r}return a})();n.exports=function(r,a){return r!==void 0&&r.length?s.getTypeOf(r)!=="string"?(function(c,u,m,v){var d=l,b=v+m;c^=-1;for(var f=v;f<b;f++)c=c>>>8^d[255&(c^u[f])];return-1^c})(0|a,r,r.length,0):(function(c,u,m,v){var d=l,b=v+m;c^=-1;for(var f=v;f<b;f++)c=c>>>8^d[255&(c^u.charCodeAt(f))];return-1^c})(0|a,r,r.length,0):0}},{"./utils":32}],5:[function(e,n,o){o.base64=!1,o.binary=!1,o.dir=!1,o.createFolders=!0,o.date=null,o.compression=null,o.compressionOptions=null,o.comment=null,o.unixPermissions=null,o.dosPermissions=null},{}],6:[function(e,n,o){var s=null;s=typeof Promise<"u"?Promise:e("lie"),n.exports={Promise:s}},{lie:37}],7:[function(e,n,o){var s=typeof Uint8Array<"u"&&typeof Uint16Array<"u"&&typeof Uint32Array<"u",l=e("pako"),r=e("./utils"),a=e("./stream/GenericWorker"),c=s?"uint8array":"array";function u(m,v){a.call(this,"FlateWorker/"+m),this._pako=null,this._pakoAction=m,this._pakoOptions=v,this.meta={}}o.magic="\b\0",r.inherits(u,a),u.prototype.processChunk=function(m){this.meta=m.meta,this._pako===null&&this._createPako(),this._pako.push(r.transformTo(c,m.data),!1)},u.prototype.flush=function(){a.prototype.flush.call(this),this._pako===null&&this._createPako(),this._pako.push([],!0)},u.prototype.cleanUp=function(){a.prototype.cleanUp.call(this),this._pako=null},u.prototype._createPako=function(){this._pako=new l[this._pakoAction]({raw:!0,level:this._pakoOptions.level||-1});var m=this;this._pako.onData=function(v){m.push({data:v,meta:m.meta})}},o.compressWorker=function(m){return new u("Deflate",m)},o.uncompressWorker=function(){return new u("Inflate",{})}},{"./stream/GenericWorker":28,"./utils":32,pako:38}],8:[function(e,n,o){function s(d,b){var f,y="";for(f=0;f<b;f++)y+=String.fromCharCode(255&d),d>>>=8;return y}function l(d,b,f,y,k,x){var C,A,B=d.file,I=d.compression,w=x!==c.utf8encode,D=r.transformTo("string",x(B.name)),P=r.transformTo("string",c.utf8encode(B.name)),R=B.comment,J=r.transformTo("string",x(R)),S=r.transformTo("string",c.utf8encode(R)),H=P.length!==B.name.length,g=S.length!==R.length,N="",q="",U="",G=B.dir,Z=B.date,O={crc32:0,compressedSize:0,uncompressedSize:0};b&&!f||(O.crc32=d.crc32,O.compressedSize=d.compressedSize,O.uncompressedSize=d.uncompressedSize);var E=0;b&&(E|=8),w||!H&&!g||(E|=2048);var z=0,rt=0;G&&(z|=16),k==="UNIX"?(rt=798,z|=(function(tt,Y){var ct=tt;return tt||(ct=Y?16893:33204),(65535&ct)<<16})(B.unixPermissions,G)):(rt=20,z|=(function(tt){return 63&(tt||0)})(B.dosPermissions)),C=Z.getUTCHours(),C<<=6,C|=Z.getUTCMinutes(),C<<=5,C|=Z.getUTCSeconds()/2,A=Z.getUTCFullYear()-1980,A<<=4,A|=Z.getUTCMonth()+1,A<<=5,A|=Z.getUTCDate(),H&&(q=s(1,1)+s(u(D),4)+P,N+="up"+s(q.length,2)+q),g&&(U=s(1,1)+s(u(J),4)+S,N+="uc"+s(U.length,2)+U);var nt="";return nt+=`
\0`,nt+=s(E,2),nt+=I.magic,nt+=s(C,2),nt+=s(A,2),nt+=s(O.crc32,4),nt+=s(O.compressedSize,4),nt+=s(O.uncompressedSize,4),nt+=s(D.length,2),nt+=s(N.length,2),{fileRecord:m.LOCAL_FILE_HEADER+nt+D+N,dirRecord:m.CENTRAL_FILE_HEADER+s(rt,2)+nt+s(J.length,2)+"\0\0\0\0"+s(z,4)+s(y,4)+D+N+J}}var r=e("../utils"),a=e("../stream/GenericWorker"),c=e("../utf8"),u=e("../crc32"),m=e("../signature");function v(d,b,f,y){a.call(this,"ZipFileWorker"),this.bytesWritten=0,this.zipComment=b,this.zipPlatform=f,this.encodeFileName=y,this.streamFiles=d,this.accumulate=!1,this.contentBuffer=[],this.dirRecords=[],this.currentSourceOffset=0,this.entriesCount=0,this.currentFile=null,this._sources=[]}r.inherits(v,a),v.prototype.push=function(d){var b=d.meta.percent||0,f=this.entriesCount,y=this._sources.length;this.accumulate?this.contentBuffer.push(d):(this.bytesWritten+=d.data.length,a.prototype.push.call(this,{data:d.data,meta:{currentFile:this.currentFile,percent:f?(b+100*(f-y-1))/f:100}}))},v.prototype.openedSource=function(d){this.currentSourceOffset=this.bytesWritten,this.currentFile=d.file.name;var b=this.streamFiles&&!d.file.dir;if(b){var f=l(d,b,!1,this.currentSourceOffset,this.zipPlatform,this.encodeFileName);this.push({data:f.fileRecord,meta:{percent:0}})}else this.accumulate=!0},v.prototype.closedSource=function(d){this.accumulate=!1;var b=this.streamFiles&&!d.file.dir,f=l(d,b,!0,this.currentSourceOffset,this.zipPlatform,this.encodeFileName);if(this.dirRecords.push(f.dirRecord),b)this.push({data:(function(y){return m.DATA_DESCRIPTOR+s(y.crc32,4)+s(y.compressedSize,4)+s(y.uncompressedSize,4)})(d),meta:{percent:100}});else for(this.push({data:f.fileRecord,meta:{percent:0}});this.contentBuffer.length;)this.push(this.contentBuffer.shift());this.currentFile=null},v.prototype.flush=function(){for(var d=this.bytesWritten,b=0;b<this.dirRecords.length;b++)this.push({data:this.dirRecords[b],meta:{percent:100}});var f=this.bytesWritten-d,y=(function(k,x,C,A,B){var I=r.transformTo("string",B(A));return m.CENTRAL_DIRECTORY_END+"\0\0\0\0"+s(k,2)+s(k,2)+s(x,4)+s(C,4)+s(I.length,2)+I})(this.dirRecords.length,f,d,this.zipComment,this.encodeFileName);this.push({data:y,meta:{percent:100}})},v.prototype.prepareNextSource=function(){this.previous=this._sources.shift(),this.openedSource(this.previous.streamInfo),this.isPaused?this.previous.pause():this.previous.resume()},v.prototype.registerPrevious=function(d){this._sources.push(d);var b=this;return d.on("data",function(f){b.processChunk(f)}),d.on("end",function(){b.closedSource(b.previous.streamInfo),b._sources.length?b.prepareNextSource():b.end()}),d.on("error",function(f){b.error(f)}),this},v.prototype.resume=function(){return!!a.prototype.resume.call(this)&&(!this.previous&&this._sources.length?(this.prepareNextSource(),!0):this.previous||this._sources.length||this.generatedError?void 0:(this.end(),!0))},v.prototype.error=function(d){var b=this._sources;if(!a.prototype.error.call(this,d))return!1;for(var f=0;f<b.length;f++)try{b[f].error(d)}catch{}return!0},v.prototype.lock=function(){a.prototype.lock.call(this);for(var d=this._sources,b=0;b<d.length;b++)d[b].lock()},n.exports=v},{"../crc32":4,"../signature":23,"../stream/GenericWorker":28,"../utf8":31,"../utils":32}],9:[function(e,n,o){var s=e("../compressions"),l=e("./ZipFileWorker");o.generateWorker=function(r,a,c){var u=new l(a.streamFiles,c,a.platform,a.encodeFileName),m=0;try{r.forEach(function(v,d){m++;var b=(function(x,C){var A=x||C,B=s[A];if(!B)throw new Error(A+" is not a valid compression method !");return B})(d.options.compression,a.compression),f=d.options.compressionOptions||a.compressionOptions||{},y=d.dir,k=d.date;d._compressWorker(b,f).withStreamInfo("file",{name:v,dir:y,date:k,comment:d.comment||"",unixPermissions:d.unixPermissions,dosPermissions:d.dosPermissions}).pipe(u)}),u.entriesCount=m}catch(v){u.error(v)}return u}},{"../compressions":3,"./ZipFileWorker":8}],10:[function(e,n,o){function s(){if(!(this instanceof s))return new s;if(arguments.length)throw new Error("The constructor with parameters has been removed in JSZip 3.0, please check the upgrade guide.");this.files=Object.create(null),this.comment=null,this.root="",this.clone=function(){var l=new s;for(var r in this)typeof this[r]!="function"&&(l[r]=this[r]);return l}}(s.prototype=e("./object")).loadAsync=e("./load"),s.support=e("./support"),s.defaults=e("./defaults"),s.version="3.10.1",s.loadAsync=function(l,r){return new s().loadAsync(l,r)},s.external=e("./external"),n.exports=s},{"./defaults":5,"./external":6,"./load":11,"./object":15,"./support":30}],11:[function(e,n,o){var s=e("./utils"),l=e("./external"),r=e("./utf8"),a=e("./zipEntries"),c=e("./stream/Crc32Probe"),u=e("./nodejsUtils");function m(v){return new l.Promise(function(d,b){var f=v.decompressed.getContentWorker().pipe(new c);f.on("error",function(y){b(y)}).on("end",function(){f.streamInfo.crc32!==v.decompressed.crc32?b(new Error("Corrupted zip : CRC32 mismatch")):d()}).resume()})}n.exports=function(v,d){var b=this;return d=s.extend(d||{},{base64:!1,checkCRC32:!1,optimizedBinaryString:!1,createFolders:!1,decodeFileName:r.utf8decode}),u.isNode&&u.isStream(v)?l.Promise.reject(new Error("JSZip can't accept a stream when loading a zip file.")):s.prepareContent("the loaded zip file",v,!0,d.optimizedBinaryString,d.base64).then(function(f){var y=new a(d);return y.load(f),y}).then(function(f){var y=[l.Promise.resolve(f)],k=f.files;if(d.checkCRC32)for(var x=0;x<k.length;x++)y.push(m(k[x]));return l.Promise.all(y)}).then(function(f){for(var y=f.shift(),k=y.files,x=0;x<k.length;x++){var C=k[x],A=C.fileNameStr,B=s.resolve(C.fileNameStr);b.file(B,C.decompressed,{binary:!0,optimizedBinaryString:!0,date:C.date,dir:C.dir,comment:C.fileCommentStr.length?C.fileCommentStr:null,unixPermissions:C.unixPermissions,dosPermissions:C.dosPermissions,createFolders:d.createFolders}),C.dir||(b.file(B).unsafeOriginalName=A)}return y.zipComment.length&&(b.comment=y.zipComment),b})}},{"./external":6,"./nodejsUtils":14,"./stream/Crc32Probe":25,"./utf8":31,"./utils":32,"./zipEntries":33}],12:[function(e,n,o){var s=e("../utils"),l=e("../stream/GenericWorker");function r(a,c){l.call(this,"Nodejs stream input adapter for "+a),this._upstreamEnded=!1,this._bindStream(c)}s.inherits(r,l),r.prototype._bindStream=function(a){var c=this;(this._stream=a).pause(),a.on("data",function(u){c.push({data:u,meta:{percent:0}})}).on("error",function(u){c.isPaused?this.generatedError=u:c.error(u)}).on("end",function(){c.isPaused?c._upstreamEnded=!0:c.end()})},r.prototype.pause=function(){return!!l.prototype.pause.call(this)&&(this._stream.pause(),!0)},r.prototype.resume=function(){return!!l.prototype.resume.call(this)&&(this._upstreamEnded?this.end():this._stream.resume(),!0)},n.exports=r},{"../stream/GenericWorker":28,"../utils":32}],13:[function(e,n,o){var s=e("readable-stream").Readable;function l(r,a,c){s.call(this,a),this._helper=r;var u=this;r.on("data",function(m,v){u.push(m)||u._helper.pause(),c&&c(v)}).on("error",function(m){u.emit("error",m)}).on("end",function(){u.push(null)})}e("../utils").inherits(l,s),l.prototype._read=function(){this._helper.resume()},n.exports=l},{"../utils":32,"readable-stream":16}],14:[function(e,n,o){n.exports={isNode:typeof Buffer<"u",newBufferFrom:function(s,l){if(Buffer.from&&Buffer.from!==Uint8Array.from)return Buffer.from(s,l);if(typeof s=="number")throw new Error('The "data" argument must not be a number');return new Buffer(s,l)},allocBuffer:function(s){if(Buffer.alloc)return Buffer.alloc(s);var l=new Buffer(s);return l.fill(0),l},isBuffer:function(s){return Buffer.isBuffer(s)},isStream:function(s){return s&&typeof s.on=="function"&&typeof s.pause=="function"&&typeof s.resume=="function"}}},{}],15:[function(e,n,o){function s(B,I,w){var D,P=r.getTypeOf(I),R=r.extend(w||{},u);R.date=R.date||new Date,R.compression!==null&&(R.compression=R.compression.toUpperCase()),typeof R.unixPermissions=="string"&&(R.unixPermissions=parseInt(R.unixPermissions,8)),R.unixPermissions&&16384&R.unixPermissions&&(R.dir=!0),R.dosPermissions&&16&R.dosPermissions&&(R.dir=!0),R.dir&&(B=k(B)),R.createFolders&&(D=y(B))&&x.call(this,D,!0);var J=P==="string"&&R.binary===!1&&R.base64===!1;w&&w.binary!==void 0||(R.binary=!J),(I instanceof m&&I.uncompressedSize===0||R.dir||!I||I.length===0)&&(R.base64=!1,R.binary=!0,I="",R.compression="STORE",P="string");var S=null;S=I instanceof m||I instanceof a?I:b.isNode&&b.isStream(I)?new f(B,I):r.prepareContent(B,I,R.binary,R.optimizedBinaryString,R.base64);var H=new v(B,S,R);this.files[B]=H}var l=e("./utf8"),r=e("./utils"),a=e("./stream/GenericWorker"),c=e("./stream/StreamHelper"),u=e("./defaults"),m=e("./compressedObject"),v=e("./zipObject"),d=e("./generate"),b=e("./nodejsUtils"),f=e("./nodejs/NodejsStreamInputAdapter"),y=function(B){B.slice(-1)==="/"&&(B=B.substring(0,B.length-1));var I=B.lastIndexOf("/");return 0<I?B.substring(0,I):""},k=function(B){return B.slice(-1)!=="/"&&(B+="/"),B},x=function(B,I){return I=I!==void 0?I:u.createFolders,B=k(B),this.files[B]||s.call(this,B,null,{dir:!0,createFolders:I}),this.files[B]};function C(B){return Object.prototype.toString.call(B)==="[object RegExp]"}var A={load:function(){throw new Error("This method has been removed in JSZip 3.0, please check the upgrade guide.")},forEach:function(B){var I,w,D;for(I in this.files)D=this.files[I],(w=I.slice(this.root.length,I.length))&&I.slice(0,this.root.length)===this.root&&B(w,D)},filter:function(B){var I=[];return this.forEach(function(w,D){B(w,D)&&I.push(D)}),I},file:function(B,I,w){if(arguments.length!==1)return B=this.root+B,s.call(this,B,I,w),this;if(C(B)){var D=B;return this.filter(function(R,J){return!J.dir&&D.test(R)})}var P=this.files[this.root+B];return P&&!P.dir?P:null},folder:function(B){if(!B)return this;if(C(B))return this.filter(function(P,R){return R.dir&&B.test(P)});var I=this.root+B,w=x.call(this,I),D=this.clone();return D.root=w.name,D},remove:function(B){B=this.root+B;var I=this.files[B];if(I||(B.slice(-1)!=="/"&&(B+="/"),I=this.files[B]),I&&!I.dir)delete this.files[B];else for(var w=this.filter(function(P,R){return R.name.slice(0,B.length)===B}),D=0;D<w.length;D++)delete this.files[w[D].name];return this},generate:function(){throw new Error("This method has been removed in JSZip 3.0, please check the upgrade guide.")},generateInternalStream:function(B){var I,w={};try{if((w=r.extend(B||{},{streamFiles:!1,compression:"STORE",compressionOptions:null,type:"",platform:"DOS",comment:null,mimeType:"application/zip",encodeFileName:l.utf8encode})).type=w.type.toLowerCase(),w.compression=w.compression.toUpperCase(),w.type==="binarystring"&&(w.type="string"),!w.type)throw new Error("No output type specified.");r.checkSupport(w.type),w.platform!=="darwin"&&w.platform!=="freebsd"&&w.platform!=="linux"&&w.platform!=="sunos"||(w.platform="UNIX"),w.platform==="win32"&&(w.platform="DOS");var D=w.comment||this.comment||"";I=d.generateWorker(this,w,D)}catch(P){(I=new a("error")).error(P)}return new c(I,w.type||"string",w.mimeType)},generateAsync:function(B,I){return this.generateInternalStream(B).accumulate(I)},generateNodeStream:function(B,I){return(B=B||{}).type||(B.type="nodebuffer"),this.generateInternalStream(B).toNodejsStream(I)}};n.exports=A},{"./compressedObject":2,"./defaults":5,"./generate":9,"./nodejs/NodejsStreamInputAdapter":12,"./nodejsUtils":14,"./stream/GenericWorker":28,"./stream/StreamHelper":29,"./utf8":31,"./utils":32,"./zipObject":35}],16:[function(e,n,o){n.exports=e("stream")},{stream:void 0}],17:[function(e,n,o){var s=e("./DataReader");function l(r){s.call(this,r);for(var a=0;a<this.data.length;a++)r[a]=255&r[a]}e("../utils").inherits(l,s),l.prototype.byteAt=function(r){return this.data[this.zero+r]},l.prototype.lastIndexOfSignature=function(r){for(var a=r.charCodeAt(0),c=r.charCodeAt(1),u=r.charCodeAt(2),m=r.charCodeAt(3),v=this.length-4;0<=v;--v)if(this.data[v]===a&&this.data[v+1]===c&&this.data[v+2]===u&&this.data[v+3]===m)return v-this.zero;return-1},l.prototype.readAndCheckSignature=function(r){var a=r.charCodeAt(0),c=r.charCodeAt(1),u=r.charCodeAt(2),m=r.charCodeAt(3),v=this.readData(4);return a===v[0]&&c===v[1]&&u===v[2]&&m===v[3]},l.prototype.readData=function(r){if(this.checkOffset(r),r===0)return[];var a=this.data.slice(this.zero+this.index,this.zero+this.index+r);return this.index+=r,a},n.exports=l},{"../utils":32,"./DataReader":18}],18:[function(e,n,o){var s=e("../utils");function l(r){this.data=r,this.length=r.length,this.index=0,this.zero=0}l.prototype={checkOffset:function(r){this.checkIndex(this.index+r)},checkIndex:function(r){if(this.length<this.zero+r||r<0)throw new Error("End of data reached (data length = "+this.length+", asked index = "+r+"). Corrupted zip ?")},setIndex:function(r){this.checkIndex(r),this.index=r},skip:function(r){this.setIndex(this.index+r)},byteAt:function(){},readInt:function(r){var a,c=0;for(this.checkOffset(r),a=this.index+r-1;a>=this.index;a--)c=(c<<8)+this.byteAt(a);return this.index+=r,c},readString:function(r){return s.transformTo("string",this.readData(r))},readData:function(){},lastIndexOfSignature:function(){},readAndCheckSignature:function(){},readDate:function(){var r=this.readInt(4);return new Date(Date.UTC(1980+(r>>25&127),(r>>21&15)-1,r>>16&31,r>>11&31,r>>5&63,(31&r)<<1))}},n.exports=l},{"../utils":32}],19:[function(e,n,o){var s=e("./Uint8ArrayReader");function l(r){s.call(this,r)}e("../utils").inherits(l,s),l.prototype.readData=function(r){this.checkOffset(r);var a=this.data.slice(this.zero+this.index,this.zero+this.index+r);return this.index+=r,a},n.exports=l},{"../utils":32,"./Uint8ArrayReader":21}],20:[function(e,n,o){var s=e("./DataReader");function l(r){s.call(this,r)}e("../utils").inherits(l,s),l.prototype.byteAt=function(r){return this.data.charCodeAt(this.zero+r)},l.prototype.lastIndexOfSignature=function(r){return this.data.lastIndexOf(r)-this.zero},l.prototype.readAndCheckSignature=function(r){return r===this.readData(4)},l.prototype.readData=function(r){this.checkOffset(r);var a=this.data.slice(this.zero+this.index,this.zero+this.index+r);return this.index+=r,a},n.exports=l},{"../utils":32,"./DataReader":18}],21:[function(e,n,o){var s=e("./ArrayReader");function l(r){s.call(this,r)}e("../utils").inherits(l,s),l.prototype.readData=function(r){if(this.checkOffset(r),r===0)return new Uint8Array(0);var a=this.data.subarray(this.zero+this.index,this.zero+this.index+r);return this.index+=r,a},n.exports=l},{"../utils":32,"./ArrayReader":17}],22:[function(e,n,o){var s=e("../utils"),l=e("../support"),r=e("./ArrayReader"),a=e("./StringReader"),c=e("./NodeBufferReader"),u=e("./Uint8ArrayReader");n.exports=function(m){var v=s.getTypeOf(m);return s.checkSupport(v),v!=="string"||l.uint8array?v==="nodebuffer"?new c(m):l.uint8array?new u(s.transformTo("uint8array",m)):new r(s.transformTo("array",m)):new a(m)}},{"../support":30,"../utils":32,"./ArrayReader":17,"./NodeBufferReader":19,"./StringReader":20,"./Uint8ArrayReader":21}],23:[function(e,n,o){o.LOCAL_FILE_HEADER="PK",o.CENTRAL_FILE_HEADER="PK",o.CENTRAL_DIRECTORY_END="PK",o.ZIP64_CENTRAL_DIRECTORY_LOCATOR="PK\x07",o.ZIP64_CENTRAL_DIRECTORY_END="PK",o.DATA_DESCRIPTOR="PK\x07\b"},{}],24:[function(e,n,o){var s=e("./GenericWorker"),l=e("../utils");function r(a){s.call(this,"ConvertWorker to "+a),this.destType=a}l.inherits(r,s),r.prototype.processChunk=function(a){this.push({data:l.transformTo(this.destType,a.data),meta:a.meta})},n.exports=r},{"../utils":32,"./GenericWorker":28}],25:[function(e,n,o){var s=e("./GenericWorker"),l=e("../crc32");function r(){s.call(this,"Crc32Probe"),this.withStreamInfo("crc32",0)}e("../utils").inherits(r,s),r.prototype.processChunk=function(a){this.streamInfo.crc32=l(a.data,this.streamInfo.crc32||0),this.push(a)},n.exports=r},{"../crc32":4,"../utils":32,"./GenericWorker":28}],26:[function(e,n,o){var s=e("../utils"),l=e("./GenericWorker");function r(a){l.call(this,"DataLengthProbe for "+a),this.propName=a,this.withStreamInfo(a,0)}s.inherits(r,l),r.prototype.processChunk=function(a){if(a){var c=this.streamInfo[this.propName]||0;this.streamInfo[this.propName]=c+a.data.length}l.prototype.processChunk.call(this,a)},n.exports=r},{"../utils":32,"./GenericWorker":28}],27:[function(e,n,o){var s=e("../utils"),l=e("./GenericWorker");function r(a){l.call(this,"DataWorker");var c=this;this.dataIsReady=!1,this.index=0,this.max=0,this.data=null,this.type="",this._tickScheduled=!1,a.then(function(u){c.dataIsReady=!0,c.data=u,c.max=u&&u.length||0,c.type=s.getTypeOf(u),c.isPaused||c._tickAndRepeat()},function(u){c.error(u)})}s.inherits(r,l),r.prototype.cleanUp=function(){l.prototype.cleanUp.call(this),this.data=null},r.prototype.resume=function(){return!!l.prototype.resume.call(this)&&(!this._tickScheduled&&this.dataIsReady&&(this._tickScheduled=!0,s.delay(this._tickAndRepeat,[],this)),!0)},r.prototype._tickAndRepeat=function(){this._tickScheduled=!1,this.isPaused||this.isFinished||(this._tick(),this.isFinished||(s.delay(this._tickAndRepeat,[],this),this._tickScheduled=!0))},r.prototype._tick=function(){if(this.isPaused||this.isFinished)return!1;var a=null,c=Math.min(this.max,this.index+16384);if(this.index>=this.max)return this.end();switch(this.type){case"string":a=this.data.substring(this.index,c);break;case"uint8array":a=this.data.subarray(this.index,c);break;case"array":case"nodebuffer":a=this.data.slice(this.index,c)}return this.index=c,this.push({data:a,meta:{percent:this.max?this.index/this.max*100:0}})},n.exports=r},{"../utils":32,"./GenericWorker":28}],28:[function(e,n,o){function s(l){this.name=l||"default",this.streamInfo={},this.generatedError=null,this.extraStreamInfo={},this.isPaused=!0,this.isFinished=!1,this.isLocked=!1,this._listeners={data:[],end:[],error:[]},this.previous=null}s.prototype={push:function(l){this.emit("data",l)},end:function(){if(this.isFinished)return!1;this.flush();try{this.emit("end"),this.cleanUp(),this.isFinished=!0}catch(l){this.emit("error",l)}return!0},error:function(l){return!this.isFinished&&(this.isPaused?this.generatedError=l:(this.isFinished=!0,this.emit("error",l),this.previous&&this.previous.error(l),this.cleanUp()),!0)},on:function(l,r){return this._listeners[l].push(r),this},cleanUp:function(){this.streamInfo=this.generatedError=this.extraStreamInfo=null,this._listeners=[]},emit:function(l,r){if(this._listeners[l])for(var a=0;a<this._listeners[l].length;a++)this._listeners[l][a].call(this,r)},pipe:function(l){return l.registerPrevious(this)},registerPrevious:function(l){if(this.isLocked)throw new Error("The stream '"+this+"' has already been used.");this.streamInfo=l.streamInfo,this.mergeStreamInfo(),this.previous=l;var r=this;return l.on("data",function(a){r.processChunk(a)}),l.on("end",function(){r.end()}),l.on("error",function(a){r.error(a)}),this},pause:function(){return!this.isPaused&&!this.isFinished&&(this.isPaused=!0,this.previous&&this.previous.pause(),!0)},resume:function(){if(!this.isPaused||this.isFinished)return!1;var l=this.isPaused=!1;return this.generatedError&&(this.error(this.generatedError),l=!0),this.previous&&this.previous.resume(),!l},flush:function(){},processChunk:function(l){this.push(l)},withStreamInfo:function(l,r){return this.extraStreamInfo[l]=r,this.mergeStreamInfo(),this},mergeStreamInfo:function(){for(var l in this.extraStreamInfo)Object.prototype.hasOwnProperty.call(this.extraStreamInfo,l)&&(this.streamInfo[l]=this.extraStreamInfo[l])},lock:function(){if(this.isLocked)throw new Error("The stream '"+this+"' has already been used.");this.isLocked=!0,this.previous&&this.previous.lock()},toString:function(){var l="Worker "+this.name;return this.previous?this.previous+" -> "+l:l}},n.exports=s},{}],29:[function(e,n,o){var s=e("../utils"),l=e("./ConvertWorker"),r=e("./GenericWorker"),a=e("../base64"),c=e("../support"),u=e("../external"),m=null;if(c.nodestream)try{m=e("../nodejs/NodejsStreamOutputAdapter")}catch{}function v(b,f){return new u.Promise(function(y,k){var x=[],C=b._internalType,A=b._outputType,B=b._mimeType;b.on("data",function(I,w){x.push(I),f&&f(w)}).on("error",function(I){x=[],k(I)}).on("end",function(){try{var I=(function(w,D,P){switch(w){case"blob":return s.newBlob(s.transformTo("arraybuffer",D),P);case"base64":return a.encode(D);default:return s.transformTo(w,D)}})(A,(function(w,D){var P,R=0,J=null,S=0;for(P=0;P<D.length;P++)S+=D[P].length;switch(w){case"string":return D.join("");case"array":return Array.prototype.concat.apply([],D);case"uint8array":for(J=new Uint8Array(S),P=0;P<D.length;P++)J.set(D[P],R),R+=D[P].length;return J;case"nodebuffer":return Buffer.concat(D);default:throw new Error("concat : unsupported type '"+w+"'")}})(C,x),B);y(I)}catch(w){k(w)}x=[]}).resume()})}function d(b,f,y){var k=f;switch(f){case"blob":case"arraybuffer":k="uint8array";break;case"base64":k="string"}try{this._internalType=k,this._outputType=f,this._mimeType=y,s.checkSupport(k),this._worker=b.pipe(new l(k)),b.lock()}catch(x){this._worker=new r("error"),this._worker.error(x)}}d.prototype={accumulate:function(b){return v(this,b)},on:function(b,f){var y=this;return b==="data"?this._worker.on(b,function(k){f.call(y,k.data,k.meta)}):this._worker.on(b,function(){s.delay(f,arguments,y)}),this},resume:function(){return s.delay(this._worker.resume,[],this._worker),this},pause:function(){return this._worker.pause(),this},toNodejsStream:function(b){if(s.checkSupport("nodestream"),this._outputType!=="nodebuffer")throw new Error(this._outputType+" is not supported by this method");return new m(this,{objectMode:this._outputType!=="nodebuffer"},b)}},n.exports=d},{"../base64":1,"../external":6,"../nodejs/NodejsStreamOutputAdapter":13,"../support":30,"../utils":32,"./ConvertWorker":24,"./GenericWorker":28}],30:[function(e,n,o){if(o.base64=!0,o.array=!0,o.string=!0,o.arraybuffer=typeof ArrayBuffer<"u"&&typeof Uint8Array<"u",o.nodebuffer=typeof Buffer<"u",o.uint8array=typeof Uint8Array<"u",typeof ArrayBuffer>"u")o.blob=!1;else{var s=new ArrayBuffer(0);try{o.blob=new Blob([s],{type:"application/zip"}).size===0}catch{try{var l=new(self.BlobBuilder||self.WebKitBlobBuilder||self.MozBlobBuilder||self.MSBlobBuilder);l.append(s),o.blob=l.getBlob("application/zip").size===0}catch{o.blob=!1}}}try{o.nodestream=!!e("readable-stream").Readable}catch{o.nodestream=!1}},{"readable-stream":16}],31:[function(e,n,o){for(var s=e("./utils"),l=e("./support"),r=e("./nodejsUtils"),a=e("./stream/GenericWorker"),c=new Array(256),u=0;u<256;u++)c[u]=252<=u?6:248<=u?5:240<=u?4:224<=u?3:192<=u?2:1;c[254]=c[254]=1;function m(){a.call(this,"utf-8 decode"),this.leftOver=null}function v(){a.call(this,"utf-8 encode")}o.utf8encode=function(d){return l.nodebuffer?r.newBufferFrom(d,"utf-8"):(function(b){var f,y,k,x,C,A=b.length,B=0;for(x=0;x<A;x++)(64512&(y=b.charCodeAt(x)))==55296&&x+1<A&&(64512&(k=b.charCodeAt(x+1)))==56320&&(y=65536+(y-55296<<10)+(k-56320),x++),B+=y<128?1:y<2048?2:y<65536?3:4;for(f=l.uint8array?new Uint8Array(B):new Array(B),x=C=0;C<B;x++)(64512&(y=b.charCodeAt(x)))==55296&&x+1<A&&(64512&(k=b.charCodeAt(x+1)))==56320&&(y=65536+(y-55296<<10)+(k-56320),x++),y<128?f[C++]=y:(y<2048?f[C++]=192|y>>>6:(y<65536?f[C++]=224|y>>>12:(f[C++]=240|y>>>18,f[C++]=128|y>>>12&63),f[C++]=128|y>>>6&63),f[C++]=128|63&y);return f})(d)},o.utf8decode=function(d){return l.nodebuffer?s.transformTo("nodebuffer",d).toString("utf-8"):(function(b){var f,y,k,x,C=b.length,A=new Array(2*C);for(f=y=0;f<C;)if((k=b[f++])<128)A[y++]=k;else if(4<(x=c[k]))A[y++]=65533,f+=x-1;else{for(k&=x===2?31:x===3?15:7;1<x&&f<C;)k=k<<6|63&b[f++],x--;1<x?A[y++]=65533:k<65536?A[y++]=k:(k-=65536,A[y++]=55296|k>>10&1023,A[y++]=56320|1023&k)}return A.length!==y&&(A.subarray?A=A.subarray(0,y):A.length=y),s.applyFromCharCode(A)})(d=s.transformTo(l.uint8array?"uint8array":"array",d))},s.inherits(m,a),m.prototype.processChunk=function(d){var b=s.transformTo(l.uint8array?"uint8array":"array",d.data);if(this.leftOver&&this.leftOver.length){if(l.uint8array){var f=b;(b=new Uint8Array(f.length+this.leftOver.length)).set(this.leftOver,0),b.set(f,this.leftOver.length)}else b=this.leftOver.concat(b);this.leftOver=null}var y=(function(x,C){var A;for((C=C||x.length)>x.length&&(C=x.length),A=C-1;0<=A&&(192&x[A])==128;)A--;return A<0||A===0?C:A+c[x[A]]>C?A:C})(b),k=b;y!==b.length&&(l.uint8array?(k=b.subarray(0,y),this.leftOver=b.subarray(y,b.length)):(k=b.slice(0,y),this.leftOver=b.slice(y,b.length))),this.push({data:o.utf8decode(k),meta:d.meta})},m.prototype.flush=function(){this.leftOver&&this.leftOver.length&&(this.push({data:o.utf8decode(this.leftOver),meta:{}}),this.leftOver=null)},o.Utf8DecodeWorker=m,s.inherits(v,a),v.prototype.processChunk=function(d){this.push({data:o.utf8encode(d.data),meta:d.meta})},o.Utf8EncodeWorker=v},{"./nodejsUtils":14,"./stream/GenericWorker":28,"./support":30,"./utils":32}],32:[function(e,n,o){var s=e("./support"),l=e("./base64"),r=e("./nodejsUtils"),a=e("./external");function c(f){return f}function u(f,y){for(var k=0;k<f.length;++k)y[k]=255&f.charCodeAt(k);return y}e("setimmediate"),o.newBlob=function(f,y){o.checkSupport("blob");try{return new Blob([f],{type:y})}catch{try{var k=new(self.BlobBuilder||self.WebKitBlobBuilder||self.MozBlobBuilder||self.MSBlobBuilder);return k.append(f),k.getBlob(y)}catch{throw new Error("Bug : can't construct the Blob.")}}};var m={stringifyByChunk:function(f,y,k){var x=[],C=0,A=f.length;if(A<=k)return String.fromCharCode.apply(null,f);for(;C<A;)y==="array"||y==="nodebuffer"?x.push(String.fromCharCode.apply(null,f.slice(C,Math.min(C+k,A)))):x.push(String.fromCharCode.apply(null,f.subarray(C,Math.min(C+k,A)))),C+=k;return x.join("")},stringifyByChar:function(f){for(var y="",k=0;k<f.length;k++)y+=String.fromCharCode(f[k]);return y},applyCanBeUsed:{uint8array:(function(){try{return s.uint8array&&String.fromCharCode.apply(null,new Uint8Array(1)).length===1}catch{return!1}})(),nodebuffer:(function(){try{return s.nodebuffer&&String.fromCharCode.apply(null,r.allocBuffer(1)).length===1}catch{return!1}})()}};function v(f){var y=65536,k=o.getTypeOf(f),x=!0;if(k==="uint8array"?x=m.applyCanBeUsed.uint8array:k==="nodebuffer"&&(x=m.applyCanBeUsed.nodebuffer),x)for(;1<y;)try{return m.stringifyByChunk(f,k,y)}catch{y=Math.floor(y/2)}return m.stringifyByChar(f)}function d(f,y){for(var k=0;k<f.length;k++)y[k]=f[k];return y}o.applyFromCharCode=v;var b={};b.string={string:c,array:function(f){return u(f,new Array(f.length))},arraybuffer:function(f){return b.string.uint8array(f).buffer},uint8array:function(f){return u(f,new Uint8Array(f.length))},nodebuffer:function(f){return u(f,r.allocBuffer(f.length))}},b.array={string:v,array:c,arraybuffer:function(f){return new Uint8Array(f).buffer},uint8array:function(f){return new Uint8Array(f)},nodebuffer:function(f){return r.newBufferFrom(f)}},b.arraybuffer={string:function(f){return v(new Uint8Array(f))},array:function(f){return d(new Uint8Array(f),new Array(f.byteLength))},arraybuffer:c,uint8array:function(f){return new Uint8Array(f)},nodebuffer:function(f){return r.newBufferFrom(new Uint8Array(f))}},b.uint8array={string:v,array:function(f){return d(f,new Array(f.length))},arraybuffer:function(f){return f.buffer},uint8array:c,nodebuffer:function(f){return r.newBufferFrom(f)}},b.nodebuffer={string:v,array:function(f){return d(f,new Array(f.length))},arraybuffer:function(f){return b.nodebuffer.uint8array(f).buffer},uint8array:function(f){return d(f,new Uint8Array(f.length))},nodebuffer:c},o.transformTo=function(f,y){if(y=y||"",!f)return y;o.checkSupport(f);var k=o.getTypeOf(y);return b[k][f](y)},o.resolve=function(f){for(var y=f.split("/"),k=[],x=0;x<y.length;x++){var C=y[x];C==="."||C===""&&x!==0&&x!==y.length-1||(C===".."?k.pop():k.push(C))}return k.join("/")},o.getTypeOf=function(f){return typeof f=="string"?"string":Object.prototype.toString.call(f)==="[object Array]"?"array":s.nodebuffer&&r.isBuffer(f)?"nodebuffer":s.uint8array&&f instanceof Uint8Array?"uint8array":s.arraybuffer&&f instanceof ArrayBuffer?"arraybuffer":void 0},o.checkSupport=function(f){if(!s[f.toLowerCase()])throw new Error(f+" is not supported by this platform")},o.MAX_VALUE_16BITS=65535,o.MAX_VALUE_32BITS=-1,o.pretty=function(f){var y,k,x="";for(k=0;k<(f||"").length;k++)x+="\\x"+((y=f.charCodeAt(k))<16?"0":"")+y.toString(16).toUpperCase();return x},o.delay=function(f,y,k){setImmediate(function(){f.apply(k||null,y||[])})},o.inherits=function(f,y){function k(){}k.prototype=y.prototype,f.prototype=new k},o.extend=function(){var f,y,k={};for(f=0;f<arguments.length;f++)for(y in arguments[f])Object.prototype.hasOwnProperty.call(arguments[f],y)&&k[y]===void 0&&(k[y]=arguments[f][y]);return k},o.prepareContent=function(f,y,k,x,C){return a.Promise.resolve(y).then(function(A){return s.blob&&(A instanceof Blob||["[object File]","[object Blob]"].indexOf(Object.prototype.toString.call(A))!==-1)&&typeof FileReader<"u"?new a.Promise(function(B,I){var w=new FileReader;w.onload=function(D){B(D.target.result)},w.onerror=function(D){I(D.target.error)},w.readAsArrayBuffer(A)}):A}).then(function(A){var B=o.getTypeOf(A);return B?(B==="arraybuffer"?A=o.transformTo("uint8array",A):B==="string"&&(C?A=l.decode(A):k&&x!==!0&&(A=(function(I){return u(I,s.uint8array?new Uint8Array(I.length):new Array(I.length))})(A))),A):a.Promise.reject(new Error("Can't read the data of '"+f+"'. Is it in a supported JavaScript type (String, Blob, ArrayBuffer, etc) ?"))})}},{"./base64":1,"./external":6,"./nodejsUtils":14,"./support":30,setimmediate:54}],33:[function(e,n,o){var s=e("./reader/readerFor"),l=e("./utils"),r=e("./signature"),a=e("./zipEntry"),c=e("./support");function u(m){this.files=[],this.loadOptions=m}u.prototype={checkSignature:function(m){if(!this.reader.readAndCheckSignature(m)){this.reader.index-=4;var v=this.reader.readString(4);throw new Error("Corrupted zip or bug: unexpected signature ("+l.pretty(v)+", expected "+l.pretty(m)+")")}},isSignature:function(m,v){var d=this.reader.index;this.reader.setIndex(m);var b=this.reader.readString(4)===v;return this.reader.setIndex(d),b},readBlockEndOfCentral:function(){this.diskNumber=this.reader.readInt(2),this.diskWithCentralDirStart=this.reader.readInt(2),this.centralDirRecordsOnThisDisk=this.reader.readInt(2),this.centralDirRecords=this.reader.readInt(2),this.centralDirSize=this.reader.readInt(4),this.centralDirOffset=this.reader.readInt(4),this.zipCommentLength=this.reader.readInt(2);var m=this.reader.readData(this.zipCommentLength),v=c.uint8array?"uint8array":"array",d=l.transformTo(v,m);this.zipComment=this.loadOptions.decodeFileName(d)},readBlockZip64EndOfCentral:function(){this.zip64EndOfCentralSize=this.reader.readInt(8),this.reader.skip(4),this.diskNumber=this.reader.readInt(4),this.diskWithCentralDirStart=this.reader.readInt(4),this.centralDirRecordsOnThisDisk=this.reader.readInt(8),this.centralDirRecords=this.reader.readInt(8),this.centralDirSize=this.reader.readInt(8),this.centralDirOffset=this.reader.readInt(8),this.zip64ExtensibleData={};for(var m,v,d,b=this.zip64EndOfCentralSize-44;0<b;)m=this.reader.readInt(2),v=this.reader.readInt(4),d=this.reader.readData(v),this.zip64ExtensibleData[m]={id:m,length:v,value:d}},readBlockZip64EndOfCentralLocator:function(){if(this.diskWithZip64CentralDirStart=this.reader.readInt(4),this.relativeOffsetEndOfZip64CentralDir=this.reader.readInt(8),this.disksCount=this.reader.readInt(4),1<this.disksCount)throw new Error("Multi-volumes zip are not supported")},readLocalFiles:function(){var m,v;for(m=0;m<this.files.length;m++)v=this.files[m],this.reader.setIndex(v.localHeaderOffset),this.checkSignature(r.LOCAL_FILE_HEADER),v.readLocalPart(this.reader),v.handleUTF8(),v.processAttributes()},readCentralDir:function(){var m;for(this.reader.setIndex(this.centralDirOffset);this.reader.readAndCheckSignature(r.CENTRAL_FILE_HEADER);)(m=new a({zip64:this.zip64},this.loadOptions)).readCentralPart(this.reader),this.files.push(m);if(this.centralDirRecords!==this.files.length&&this.centralDirRecords!==0&&this.files.length===0)throw new Error("Corrupted zip or bug: expected "+this.centralDirRecords+" records in central dir, got "+this.files.length)},readEndOfCentral:function(){var m=this.reader.lastIndexOfSignature(r.CENTRAL_DIRECTORY_END);if(m<0)throw this.isSignature(0,r.LOCAL_FILE_HEADER)?new Error("Corrupted zip: can't find end of central directory"):new Error("Can't find end of central directory : is this a zip file ? If it is, see https://stuk.github.io/jszip/documentation/howto/read_zip.html");this.reader.setIndex(m);var v=m;if(this.checkSignature(r.CENTRAL_DIRECTORY_END),this.readBlockEndOfCentral(),this.diskNumber===l.MAX_VALUE_16BITS||this.diskWithCentralDirStart===l.MAX_VALUE_16BITS||this.centralDirRecordsOnThisDisk===l.MAX_VALUE_16BITS||this.centralDirRecords===l.MAX_VALUE_16BITS||this.centralDirSize===l.MAX_VALUE_32BITS||this.centralDirOffset===l.MAX_VALUE_32BITS){if(this.zip64=!0,(m=this.reader.lastIndexOfSignature(r.ZIP64_CENTRAL_DIRECTORY_LOCATOR))<0)throw new Error("Corrupted zip: can't find the ZIP64 end of central directory locator");if(this.reader.setIndex(m),this.checkSignature(r.ZIP64_CENTRAL_DIRECTORY_LOCATOR),this.readBlockZip64EndOfCentralLocator(),!this.isSignature(this.relativeOffsetEndOfZip64CentralDir,r.ZIP64_CENTRAL_DIRECTORY_END)&&(this.relativeOffsetEndOfZip64CentralDir=this.reader.lastIndexOfSignature(r.ZIP64_CENTRAL_DIRECTORY_END),this.relativeOffsetEndOfZip64CentralDir<0))throw new Error("Corrupted zip: can't find the ZIP64 end of central directory");this.reader.setIndex(this.relativeOffsetEndOfZip64CentralDir),this.checkSignature(r.ZIP64_CENTRAL_DIRECTORY_END),this.readBlockZip64EndOfCentral()}var d=this.centralDirOffset+this.centralDirSize;this.zip64&&(d+=20,d+=12+this.zip64EndOfCentralSize);var b=v-d;if(0<b)this.isSignature(v,r.CENTRAL_FILE_HEADER)||(this.reader.zero=b);else if(b<0)throw new Error("Corrupted zip: missing "+Math.abs(b)+" bytes.")},prepareReader:function(m){this.reader=s(m)},load:function(m){this.prepareReader(m),this.readEndOfCentral(),this.readCentralDir(),this.readLocalFiles()}},n.exports=u},{"./reader/readerFor":22,"./signature":23,"./support":30,"./utils":32,"./zipEntry":34}],34:[function(e,n,o){var s=e("./reader/readerFor"),l=e("./utils"),r=e("./compressedObject"),a=e("./crc32"),c=e("./utf8"),u=e("./compressions"),m=e("./support");function v(d,b){this.options=d,this.loadOptions=b}v.prototype={isEncrypted:function(){return(1&this.bitFlag)==1},useUTF8:function(){return(2048&this.bitFlag)==2048},readLocalPart:function(d){var b,f;if(d.skip(22),this.fileNameLength=d.readInt(2),f=d.readInt(2),this.fileName=d.readData(this.fileNameLength),d.skip(f),this.compressedSize===-1||this.uncompressedSize===-1)throw new Error("Bug or corrupted zip : didn't get enough information from the central directory (compressedSize === -1 || uncompressedSize === -1)");if((b=(function(y){for(var k in u)if(Object.prototype.hasOwnProperty.call(u,k)&&u[k].magic===y)return u[k];return null})(this.compressionMethod))===null)throw new Error("Corrupted zip : compression "+l.pretty(this.compressionMethod)+" unknown (inner file : "+l.transformTo("string",this.fileName)+")");this.decompressed=new r(this.compressedSize,this.uncompressedSize,this.crc32,b,d.readData(this.compressedSize))},readCentralPart:function(d){this.versionMadeBy=d.readInt(2),d.skip(2),this.bitFlag=d.readInt(2),this.compressionMethod=d.readString(2),this.date=d.readDate(),this.crc32=d.readInt(4),this.compressedSize=d.readInt(4),this.uncompressedSize=d.readInt(4);var b=d.readInt(2);if(this.extraFieldsLength=d.readInt(2),this.fileCommentLength=d.readInt(2),this.diskNumberStart=d.readInt(2),this.internalFileAttributes=d.readInt(2),this.externalFileAttributes=d.readInt(4),this.localHeaderOffset=d.readInt(4),this.isEncrypted())throw new Error("Encrypted zip are not supported");d.skip(b),this.readExtraFields(d),this.parseZIP64ExtraField(d),this.fileComment=d.readData(this.fileCommentLength)},processAttributes:function(){this.unixPermissions=null,this.dosPermissions=null;var d=this.versionMadeBy>>8;this.dir=!!(16&this.externalFileAttributes),d==0&&(this.dosPermissions=63&this.externalFileAttributes),d==3&&(this.unixPermissions=this.externalFileAttributes>>16&65535),this.dir||this.fileNameStr.slice(-1)!=="/"||(this.dir=!0)},parseZIP64ExtraField:function(){if(this.extraFields[1]){var d=s(this.extraFields[1].value);this.uncompressedSize===l.MAX_VALUE_32BITS&&(this.uncompressedSize=d.readInt(8)),this.compressedSize===l.MAX_VALUE_32BITS&&(this.compressedSize=d.readInt(8)),this.localHeaderOffset===l.MAX_VALUE_32BITS&&(this.localHeaderOffset=d.readInt(8)),this.diskNumberStart===l.MAX_VALUE_32BITS&&(this.diskNumberStart=d.readInt(4))}},readExtraFields:function(d){var b,f,y,k=d.index+this.extraFieldsLength;for(this.extraFields||(this.extraFields={});d.index+4<k;)b=d.readInt(2),f=d.readInt(2),y=d.readData(f),this.extraFields[b]={id:b,length:f,value:y};d.setIndex(k)},handleUTF8:function(){var d=m.uint8array?"uint8array":"array";if(this.useUTF8())this.fileNameStr=c.utf8decode(this.fileName),this.fileCommentStr=c.utf8decode(this.fileComment);else{var b=this.findExtraFieldUnicodePath();if(b!==null)this.fileNameStr=b;else{var f=l.transformTo(d,this.fileName);this.fileNameStr=this.loadOptions.decodeFileName(f)}var y=this.findExtraFieldUnicodeComment();if(y!==null)this.fileCommentStr=y;else{var k=l.transformTo(d,this.fileComment);this.fileCommentStr=this.loadOptions.decodeFileName(k)}}},findExtraFieldUnicodePath:function(){var d=this.extraFields[28789];if(d){var b=s(d.value);return b.readInt(1)!==1||a(this.fileName)!==b.readInt(4)?null:c.utf8decode(b.readData(d.length-5))}return null},findExtraFieldUnicodeComment:function(){var d=this.extraFields[25461];if(d){var b=s(d.value);return b.readInt(1)!==1||a(this.fileComment)!==b.readInt(4)?null:c.utf8decode(b.readData(d.length-5))}return null}},n.exports=v},{"./compressedObject":2,"./compressions":3,"./crc32":4,"./reader/readerFor":22,"./support":30,"./utf8":31,"./utils":32}],35:[function(e,n,o){function s(b,f,y){this.name=b,this.dir=y.dir,this.date=y.date,this.comment=y.comment,this.unixPermissions=y.unixPermissions,this.dosPermissions=y.dosPermissions,this._data=f,this._dataBinary=y.binary,this.options={compression:y.compression,compressionOptions:y.compressionOptions}}var l=e("./stream/StreamHelper"),r=e("./stream/DataWorker"),a=e("./utf8"),c=e("./compressedObject"),u=e("./stream/GenericWorker");s.prototype={internalStream:function(b){var f=null,y="string";try{if(!b)throw new Error("No output type specified.");var k=(y=b.toLowerCase())==="string"||y==="text";y!=="binarystring"&&y!=="text"||(y="string"),f=this._decompressWorker();var x=!this._dataBinary;x&&!k&&(f=f.pipe(new a.Utf8EncodeWorker)),!x&&k&&(f=f.pipe(new a.Utf8DecodeWorker))}catch(C){(f=new u("error")).error(C)}return new l(f,y,"")},async:function(b,f){return this.internalStream(b).accumulate(f)},nodeStream:function(b,f){return this.internalStream(b||"nodebuffer").toNodejsStream(f)},_compressWorker:function(b,f){if(this._data instanceof c&&this._data.compression.magic===b.magic)return this._data.getCompressedWorker();var y=this._decompressWorker();return this._dataBinary||(y=y.pipe(new a.Utf8EncodeWorker)),c.createWorkerFrom(y,b,f)},_decompressWorker:function(){return this._data instanceof c?this._data.getContentWorker():this._data instanceof u?this._data:new r(this._data)}};for(var m=["asText","asBinary","asNodeBuffer","asUint8Array","asArrayBuffer"],v=function(){throw new Error("This method has been removed in JSZip 3.0, please check the upgrade guide.")},d=0;d<m.length;d++)s.prototype[m[d]]=v;n.exports=s},{"./compressedObject":2,"./stream/DataWorker":27,"./stream/GenericWorker":28,"./stream/StreamHelper":29,"./utf8":31}],36:[function(e,n,o){(function(s){var l,r,a=s.MutationObserver||s.WebKitMutationObserver;if(a){var c=0,u=new a(b),m=s.document.createTextNode("");u.observe(m,{characterData:!0}),l=function(){m.data=c=++c%2}}else if(s.setImmediate||s.MessageChannel===void 0)l="document"in s&&"onreadystatechange"in s.document.createElement("script")?function(){var f=s.document.createElement("script");f.onreadystatechange=function(){b(),f.onreadystatechange=null,f.parentNode.removeChild(f),f=null},s.document.documentElement.appendChild(f)}:function(){setTimeout(b,0)};else{var v=new s.MessageChannel;v.port1.onmessage=b,l=function(){v.port2.postMessage(0)}}var d=[];function b(){var f,y;r=!0;for(var k=d.length;k;){for(y=d,d=[],f=-1;++f<k;)y[f]();k=d.length}r=!1}n.exports=function(f){d.push(f)!==1||r||l()}}).call(this,typeof Kn<"u"?Kn:typeof self<"u"?self:typeof window<"u"?window:{})},{}],37:[function(e,n,o){var s=e("immediate");function l(){}var r={},a=["REJECTED"],c=["FULFILLED"],u=["PENDING"];function m(k){if(typeof k!="function")throw new TypeError("resolver must be a function");this.state=u,this.queue=[],this.outcome=void 0,k!==l&&f(this,k)}function v(k,x,C){this.promise=k,typeof x=="function"&&(this.onFulfilled=x,this.callFulfilled=this.otherCallFulfilled),typeof C=="function"&&(this.onRejected=C,this.callRejected=this.otherCallRejected)}function d(k,x,C){s(function(){var A;try{A=x(C)}catch(B){return r.reject(k,B)}A===k?r.reject(k,new TypeError("Cannot resolve promise with itself")):r.resolve(k,A)})}function b(k){var x=k&&k.then;if(k&&(typeof k=="object"||typeof k=="function")&&typeof x=="function")return function(){x.apply(k,arguments)}}function f(k,x){var C=!1;function A(w){C||(C=!0,r.reject(k,w))}function B(w){C||(C=!0,r.resolve(k,w))}var I=y(function(){x(B,A)});I.status==="error"&&A(I.value)}function y(k,x){var C={};try{C.value=k(x),C.status="success"}catch(A){C.status="error",C.value=A}return C}(n.exports=m).prototype.finally=function(k){if(typeof k!="function")return this;var x=this.constructor;return this.then(function(C){return x.resolve(k()).then(function(){return C})},function(C){return x.resolve(k()).then(function(){throw C})})},m.prototype.catch=function(k){return this.then(null,k)},m.prototype.then=function(k,x){if(typeof k!="function"&&this.state===c||typeof x!="function"&&this.state===a)return this;var C=new this.constructor(l);return this.state!==u?d(C,this.state===c?k:x,this.outcome):this.queue.push(new v(C,k,x)),C},v.prototype.callFulfilled=function(k){r.resolve(this.promise,k)},v.prototype.otherCallFulfilled=function(k){d(this.promise,this.onFulfilled,k)},v.prototype.callRejected=function(k){r.reject(this.promise,k)},v.prototype.otherCallRejected=function(k){d(this.promise,this.onRejected,k)},r.resolve=function(k,x){var C=y(b,x);if(C.status==="error")return r.reject(k,C.value);var A=C.value;if(A)f(k,A);else{k.state=c,k.outcome=x;for(var B=-1,I=k.queue.length;++B<I;)k.queue[B].callFulfilled(x)}return k},r.reject=function(k,x){k.state=a,k.outcome=x;for(var C=-1,A=k.queue.length;++C<A;)k.queue[C].callRejected(x);return k},m.resolve=function(k){return k instanceof this?k:r.resolve(new this(l),k)},m.reject=function(k){var x=new this(l);return r.reject(x,k)},m.all=function(k){var x=this;if(Object.prototype.toString.call(k)!=="[object Array]")return this.reject(new TypeError("must be an array"));var C=k.length,A=!1;if(!C)return this.resolve([]);for(var B=new Array(C),I=0,w=-1,D=new this(l);++w<C;)P(k[w],w);return D;function P(R,J){x.resolve(R).then(function(S){B[J]=S,++I!==C||A||(A=!0,r.resolve(D,B))},function(S){A||(A=!0,r.reject(D,S))})}},m.race=function(k){var x=this;if(Object.prototype.toString.call(k)!=="[object Array]")return this.reject(new TypeError("must be an array"));var C=k.length,A=!1;if(!C)return this.resolve([]);for(var B=-1,I=new this(l);++B<C;)w=k[B],x.resolve(w).then(function(D){A||(A=!0,r.resolve(I,D))},function(D){A||(A=!0,r.reject(I,D))});var w;return I}},{immediate:36}],38:[function(e,n,o){var s={};(0,e("./lib/utils/common").assign)(s,e("./lib/deflate"),e("./lib/inflate"),e("./lib/zlib/constants")),n.exports=s},{"./lib/deflate":39,"./lib/inflate":40,"./lib/utils/common":41,"./lib/zlib/constants":44}],39:[function(e,n,o){var s=e("./zlib/deflate"),l=e("./utils/common"),r=e("./utils/strings"),a=e("./zlib/messages"),c=e("./zlib/zstream"),u=Object.prototype.toString,m=0,v=-1,d=0,b=8;function f(k){if(!(this instanceof f))return new f(k);this.options=l.assign({level:v,method:b,chunkSize:16384,windowBits:15,memLevel:8,strategy:d,to:""},k||{});var x=this.options;x.raw&&0<x.windowBits?x.windowBits=-x.windowBits:x.gzip&&0<x.windowBits&&x.windowBits<16&&(x.windowBits+=16),this.err=0,this.msg="",this.ended=!1,this.chunks=[],this.strm=new c,this.strm.avail_out=0;var C=s.deflateInit2(this.strm,x.level,x.method,x.windowBits,x.memLevel,x.strategy);if(C!==m)throw new Error(a[C]);if(x.header&&s.deflateSetHeader(this.strm,x.header),x.dictionary){var A;if(A=typeof x.dictionary=="string"?r.string2buf(x.dictionary):u.call(x.dictionary)==="[object ArrayBuffer]"?new Uint8Array(x.dictionary):x.dictionary,(C=s.deflateSetDictionary(this.strm,A))!==m)throw new Error(a[C]);this._dict_set=!0}}function y(k,x){var C=new f(x);if(C.push(k,!0),C.err)throw C.msg||a[C.err];return C.result}f.prototype.push=function(k,x){var C,A,B=this.strm,I=this.options.chunkSize;if(this.ended)return!1;A=x===~~x?x:x===!0?4:0,typeof k=="string"?B.input=r.string2buf(k):u.call(k)==="[object ArrayBuffer]"?B.input=new Uint8Array(k):B.input=k,B.next_in=0,B.avail_in=B.input.length;do{if(B.avail_out===0&&(B.output=new l.Buf8(I),B.next_out=0,B.avail_out=I),(C=s.deflate(B,A))!==1&&C!==m)return this.onEnd(C),!(this.ended=!0);B.avail_out!==0&&(B.avail_in!==0||A!==4&&A!==2)||(this.options.to==="string"?this.onData(r.buf2binstring(l.shrinkBuf(B.output,B.next_out))):this.onData(l.shrinkBuf(B.output,B.next_out)))}while((0<B.avail_in||B.avail_out===0)&&C!==1);return A===4?(C=s.deflateEnd(this.strm),this.onEnd(C),this.ended=!0,C===m):A!==2||(this.onEnd(m),!(B.avail_out=0))},f.prototype.onData=function(k){this.chunks.push(k)},f.prototype.onEnd=function(k){k===m&&(this.options.to==="string"?this.result=this.chunks.join(""):this.result=l.flattenChunks(this.chunks)),this.chunks=[],this.err=k,this.msg=this.strm.msg},o.Deflate=f,o.deflate=y,o.deflateRaw=function(k,x){return(x=x||{}).raw=!0,y(k,x)},o.gzip=function(k,x){return(x=x||{}).gzip=!0,y(k,x)}},{"./utils/common":41,"./utils/strings":42,"./zlib/deflate":46,"./zlib/messages":51,"./zlib/zstream":53}],40:[function(e,n,o){var s=e("./zlib/inflate"),l=e("./utils/common"),r=e("./utils/strings"),a=e("./zlib/constants"),c=e("./zlib/messages"),u=e("./zlib/zstream"),m=e("./zlib/gzheader"),v=Object.prototype.toString;function d(f){if(!(this instanceof d))return new d(f);this.options=l.assign({chunkSize:16384,windowBits:0,to:""},f||{});var y=this.options;y.raw&&0<=y.windowBits&&y.windowBits<16&&(y.windowBits=-y.windowBits,y.windowBits===0&&(y.windowBits=-15)),!(0<=y.windowBits&&y.windowBits<16)||f&&f.windowBits||(y.windowBits+=32),15<y.windowBits&&y.windowBits<48&&(15&y.windowBits)==0&&(y.windowBits|=15),this.err=0,this.msg="",this.ended=!1,this.chunks=[],this.strm=new u,this.strm.avail_out=0;var k=s.inflateInit2(this.strm,y.windowBits);if(k!==a.Z_OK)throw new Error(c[k]);this.header=new m,s.inflateGetHeader(this.strm,this.header)}function b(f,y){var k=new d(y);if(k.push(f,!0),k.err)throw k.msg||c[k.err];return k.result}d.prototype.push=function(f,y){var k,x,C,A,B,I,w=this.strm,D=this.options.chunkSize,P=this.options.dictionary,R=!1;if(this.ended)return!1;x=y===~~y?y:y===!0?a.Z_FINISH:a.Z_NO_FLUSH,typeof f=="string"?w.input=r.binstring2buf(f):v.call(f)==="[object ArrayBuffer]"?w.input=new Uint8Array(f):w.input=f,w.next_in=0,w.avail_in=w.input.length;do{if(w.avail_out===0&&(w.output=new l.Buf8(D),w.next_out=0,w.avail_out=D),(k=s.inflate(w,a.Z_NO_FLUSH))===a.Z_NEED_DICT&&P&&(I=typeof P=="string"?r.string2buf(P):v.call(P)==="[object ArrayBuffer]"?new Uint8Array(P):P,k=s.inflateSetDictionary(this.strm,I)),k===a.Z_BUF_ERROR&&R===!0&&(k=a.Z_OK,R=!1),k!==a.Z_STREAM_END&&k!==a.Z_OK)return this.onEnd(k),!(this.ended=!0);w.next_out&&(w.avail_out!==0&&k!==a.Z_STREAM_END&&(w.avail_in!==0||x!==a.Z_FINISH&&x!==a.Z_SYNC_FLUSH)||(this.options.to==="string"?(C=r.utf8border(w.output,w.next_out),A=w.next_out-C,B=r.buf2string(w.output,C),w.next_out=A,w.avail_out=D-A,A&&l.arraySet(w.output,w.output,C,A,0),this.onData(B)):this.onData(l.shrinkBuf(w.output,w.next_out)))),w.avail_in===0&&w.avail_out===0&&(R=!0)}while((0<w.avail_in||w.avail_out===0)&&k!==a.Z_STREAM_END);return k===a.Z_STREAM_END&&(x=a.Z_FINISH),x===a.Z_FINISH?(k=s.inflateEnd(this.strm),this.onEnd(k),this.ended=!0,k===a.Z_OK):x!==a.Z_SYNC_FLUSH||(this.onEnd(a.Z_OK),!(w.avail_out=0))},d.prototype.onData=function(f){this.chunks.push(f)},d.prototype.onEnd=function(f){f===a.Z_OK&&(this.options.to==="string"?this.result=this.chunks.join(""):this.result=l.flattenChunks(this.chunks)),this.chunks=[],this.err=f,this.msg=this.strm.msg},o.Inflate=d,o.inflate=b,o.inflateRaw=function(f,y){return(y=y||{}).raw=!0,b(f,y)},o.ungzip=b},{"./utils/common":41,"./utils/strings":42,"./zlib/constants":44,"./zlib/gzheader":47,"./zlib/inflate":49,"./zlib/messages":51,"./zlib/zstream":53}],41:[function(e,n,o){var s=typeof Uint8Array<"u"&&typeof Uint16Array<"u"&&typeof Int32Array<"u";o.assign=function(a){for(var c=Array.prototype.slice.call(arguments,1);c.length;){var u=c.shift();if(u){if(typeof u!="object")throw new TypeError(u+"must be non-object");for(var m in u)u.hasOwnProperty(m)&&(a[m]=u[m])}}return a},o.shrinkBuf=function(a,c){return a.length===c?a:a.subarray?a.subarray(0,c):(a.length=c,a)};var l={arraySet:function(a,c,u,m,v){if(c.subarray&&a.subarray)a.set(c.subarray(u,u+m),v);else for(var d=0;d<m;d++)a[v+d]=c[u+d]},flattenChunks:function(a){var c,u,m,v,d,b;for(c=m=0,u=a.length;c<u;c++)m+=a[c].length;for(b=new Uint8Array(m),c=v=0,u=a.length;c<u;c++)d=a[c],b.set(d,v),v+=d.length;return b}},r={arraySet:function(a,c,u,m,v){for(var d=0;d<m;d++)a[v+d]=c[u+d]},flattenChunks:function(a){return[].concat.apply([],a)}};o.setTyped=function(a){a?(o.Buf8=Uint8Array,o.Buf16=Uint16Array,o.Buf32=Int32Array,o.assign(o,l)):(o.Buf8=Array,o.Buf16=Array,o.Buf32=Array,o.assign(o,r))},o.setTyped(s)},{}],42:[function(e,n,o){var s=e("./common"),l=!0,r=!0;try{String.fromCharCode.apply(null,[0])}catch{l=!1}try{String.fromCharCode.apply(null,new Uint8Array(1))}catch{r=!1}for(var a=new s.Buf8(256),c=0;c<256;c++)a[c]=252<=c?6:248<=c?5:240<=c?4:224<=c?3:192<=c?2:1;function u(m,v){if(v<65537&&(m.subarray&&r||!m.subarray&&l))return String.fromCharCode.apply(null,s.shrinkBuf(m,v));for(var d="",b=0;b<v;b++)d+=String.fromCharCode(m[b]);return d}a[254]=a[254]=1,o.string2buf=function(m){var v,d,b,f,y,k=m.length,x=0;for(f=0;f<k;f++)(64512&(d=m.charCodeAt(f)))==55296&&f+1<k&&(64512&(b=m.charCodeAt(f+1)))==56320&&(d=65536+(d-55296<<10)+(b-56320),f++),x+=d<128?1:d<2048?2:d<65536?3:4;for(v=new s.Buf8(x),f=y=0;y<x;f++)(64512&(d=m.charCodeAt(f)))==55296&&f+1<k&&(64512&(b=m.charCodeAt(f+1)))==56320&&(d=65536+(d-55296<<10)+(b-56320),f++),d<128?v[y++]=d:(d<2048?v[y++]=192|d>>>6:(d<65536?v[y++]=224|d>>>12:(v[y++]=240|d>>>18,v[y++]=128|d>>>12&63),v[y++]=128|d>>>6&63),v[y++]=128|63&d);return v},o.buf2binstring=function(m){return u(m,m.length)},o.binstring2buf=function(m){for(var v=new s.Buf8(m.length),d=0,b=v.length;d<b;d++)v[d]=m.charCodeAt(d);return v},o.buf2string=function(m,v){var d,b,f,y,k=v||m.length,x=new Array(2*k);for(d=b=0;d<k;)if((f=m[d++])<128)x[b++]=f;else if(4<(y=a[f]))x[b++]=65533,d+=y-1;else{for(f&=y===2?31:y===3?15:7;1<y&&d<k;)f=f<<6|63&m[d++],y--;1<y?x[b++]=65533:f<65536?x[b++]=f:(f-=65536,x[b++]=55296|f>>10&1023,x[b++]=56320|1023&f)}return u(x,b)},o.utf8border=function(m,v){var d;for((v=v||m.length)>m.length&&(v=m.length),d=v-1;0<=d&&(192&m[d])==128;)d--;return d<0||d===0?v:d+a[m[d]]>v?d:v}},{"./common":41}],43:[function(e,n,o){n.exports=function(s,l,r,a){for(var c=65535&s|0,u=s>>>16&65535|0,m=0;r!==0;){for(r-=m=2e3<r?2e3:r;u=u+(c=c+l[a++]|0)|0,--m;);c%=65521,u%=65521}return c|u<<16|0}},{}],44:[function(e,n,o){n.exports={Z_NO_FLUSH:0,Z_PARTIAL_FLUSH:1,Z_SYNC_FLUSH:2,Z_FULL_FLUSH:3,Z_FINISH:4,Z_BLOCK:5,Z_TREES:6,Z_OK:0,Z_STREAM_END:1,Z_NEED_DICT:2,Z_ERRNO:-1,Z_STREAM_ERROR:-2,Z_DATA_ERROR:-3,Z_BUF_ERROR:-5,Z_NO_COMPRESSION:0,Z_BEST_SPEED:1,Z_BEST_COMPRESSION:9,Z_DEFAULT_COMPRESSION:-1,Z_FILTERED:1,Z_HUFFMAN_ONLY:2,Z_RLE:3,Z_FIXED:4,Z_DEFAULT_STRATEGY:0,Z_BINARY:0,Z_TEXT:1,Z_UNKNOWN:2,Z_DEFLATED:8}},{}],45:[function(e,n,o){var s=(function(){for(var l,r=[],a=0;a<256;a++){l=a;for(var c=0;c<8;c++)l=1&l?3988292384^l>>>1:l>>>1;r[a]=l}return r})();n.exports=function(l,r,a,c){var u=s,m=c+a;l^=-1;for(var v=c;v<m;v++)l=l>>>8^u[255&(l^r[v])];return-1^l}},{}],46:[function(e,n,o){var s,l=e("../utils/common"),r=e("./trees"),a=e("./adler32"),c=e("./crc32"),u=e("./messages"),m=0,v=4,d=0,b=-2,f=-1,y=4,k=2,x=8,C=9,A=286,B=30,I=19,w=2*A+1,D=15,P=3,R=258,J=R+P+1,S=42,H=113,g=1,N=2,q=3,U=4;function G(p,j){return p.msg=u[j],j}function Z(p){return(p<<1)-(4<p?9:0)}function O(p){for(var j=p.length;0<=--j;)p[j]=0}function E(p){var j=p.state,L=j.pending;L>p.avail_out&&(L=p.avail_out),L!==0&&(l.arraySet(p.output,j.pending_buf,j.pending_out,L,p.next_out),p.next_out+=L,j.pending_out+=L,p.total_out+=L,p.avail_out-=L,j.pending-=L,j.pending===0&&(j.pending_out=0))}function z(p,j){r._tr_flush_block(p,0<=p.block_start?p.block_start:-1,p.strstart-p.block_start,j),p.block_start=p.strstart,E(p.strm)}function rt(p,j){p.pending_buf[p.pending++]=j}function nt(p,j){p.pending_buf[p.pending++]=j>>>8&255,p.pending_buf[p.pending++]=255&j}function tt(p,j){var L,_,$=p.max_chain_length,M=p.strstart,K=p.prev_length,W=p.nice_match,V=p.strstart>p.w_size-J?p.strstart-(p.w_size-J):0,Q=p.window,lt=p.w_mask,st=p.prev,ft=p.strstart+R,xt=Q[M+K-1],kt=Q[M+K];p.prev_length>=p.good_match&&($>>=2),W>p.lookahead&&(W=p.lookahead);do if(Q[(L=j)+K]===kt&&Q[L+K-1]===xt&&Q[L]===Q[M]&&Q[++L]===Q[M+1]){M+=2,L++;do;while(Q[++M]===Q[++L]&&Q[++M]===Q[++L]&&Q[++M]===Q[++L]&&Q[++M]===Q[++L]&&Q[++M]===Q[++L]&&Q[++M]===Q[++L]&&Q[++M]===Q[++L]&&Q[++M]===Q[++L]&&M<ft);if(_=R-(ft-M),M=ft-R,K<_){if(p.match_start=j,W<=(K=_))break;xt=Q[M+K-1],kt=Q[M+K]}}while((j=st[j&lt])>V&&--$!=0);return K<=p.lookahead?K:p.lookahead}function Y(p){var j,L,_,$,M,K,W,V,Q,lt,st=p.w_size;do{if($=p.window_size-p.lookahead-p.strstart,p.strstart>=st+(st-J)){for(l.arraySet(p.window,p.window,st,st,0),p.match_start-=st,p.strstart-=st,p.block_start-=st,j=L=p.hash_size;_=p.head[--j],p.head[j]=st<=_?_-st:0,--L;);for(j=L=st;_=p.prev[--j],p.prev[j]=st<=_?_-st:0,--L;);$+=st}if(p.strm.avail_in===0)break;if(K=p.strm,W=p.window,V=p.strstart+p.lookahead,Q=$,lt=void 0,lt=K.avail_in,Q<lt&&(lt=Q),L=lt===0?0:(K.avail_in-=lt,l.arraySet(W,K.input,K.next_in,lt,V),K.state.wrap===1?K.adler=a(K.adler,W,lt,V):K.state.wrap===2&&(K.adler=c(K.adler,W,lt,V)),K.next_in+=lt,K.total_in+=lt,lt),p.lookahead+=L,p.lookahead+p.insert>=P)for(M=p.strstart-p.insert,p.ins_h=p.window[M],p.ins_h=(p.ins_h<<p.hash_shift^p.window[M+1])&p.hash_mask;p.insert&&(p.ins_h=(p.ins_h<<p.hash_shift^p.window[M+P-1])&p.hash_mask,p.prev[M&p.w_mask]=p.head[p.ins_h],p.head[p.ins_h]=M,M++,p.insert--,!(p.lookahead+p.insert<P)););}while(p.lookahead<J&&p.strm.avail_in!==0)}function ct(p,j){for(var L,_;;){if(p.lookahead<J){if(Y(p),p.lookahead<J&&j===m)return g;if(p.lookahead===0)break}if(L=0,p.lookahead>=P&&(p.ins_h=(p.ins_h<<p.hash_shift^p.window[p.strstart+P-1])&p.hash_mask,L=p.prev[p.strstart&p.w_mask]=p.head[p.ins_h],p.head[p.ins_h]=p.strstart),L!==0&&p.strstart-L<=p.w_size-J&&(p.match_length=tt(p,L)),p.match_length>=P)if(_=r._tr_tally(p,p.strstart-p.match_start,p.match_length-P),p.lookahead-=p.match_length,p.match_length<=p.max_lazy_match&&p.lookahead>=P){for(p.match_length--;p.strstart++,p.ins_h=(p.ins_h<<p.hash_shift^p.window[p.strstart+P-1])&p.hash_mask,L=p.prev[p.strstart&p.w_mask]=p.head[p.ins_h],p.head[p.ins_h]=p.strstart,--p.match_length!=0;);p.strstart++}else p.strstart+=p.match_length,p.match_length=0,p.ins_h=p.window[p.strstart],p.ins_h=(p.ins_h<<p.hash_shift^p.window[p.strstart+1])&p.hash_mask;else _=r._tr_tally(p,0,p.window[p.strstart]),p.lookahead--,p.strstart++;if(_&&(z(p,!1),p.strm.avail_out===0))return g}return p.insert=p.strstart<P-1?p.strstart:P-1,j===v?(z(p,!0),p.strm.avail_out===0?q:U):p.last_lit&&(z(p,!1),p.strm.avail_out===0)?g:N}function pt(p,j){for(var L,_,$;;){if(p.lookahead<J){if(Y(p),p.lookahead<J&&j===m)return g;if(p.lookahead===0)break}if(L=0,p.lookahead>=P&&(p.ins_h=(p.ins_h<<p.hash_shift^p.window[p.strstart+P-1])&p.hash_mask,L=p.prev[p.strstart&p.w_mask]=p.head[p.ins_h],p.head[p.ins_h]=p.strstart),p.prev_length=p.match_length,p.prev_match=p.match_start,p.match_length=P-1,L!==0&&p.prev_length<p.max_lazy_match&&p.strstart-L<=p.w_size-J&&(p.match_length=tt(p,L),p.match_length<=5&&(p.strategy===1||p.match_length===P&&4096<p.strstart-p.match_start)&&(p.match_length=P-1)),p.prev_length>=P&&p.match_length<=p.prev_length){for($=p.strstart+p.lookahead-P,_=r._tr_tally(p,p.strstart-1-p.prev_match,p.prev_length-P),p.lookahead-=p.prev_length-1,p.prev_length-=2;++p.strstart<=$&&(p.ins_h=(p.ins_h<<p.hash_shift^p.window[p.strstart+P-1])&p.hash_mask,L=p.prev[p.strstart&p.w_mask]=p.head[p.ins_h],p.head[p.ins_h]=p.strstart),--p.prev_length!=0;);if(p.match_available=0,p.match_length=P-1,p.strstart++,_&&(z(p,!1),p.strm.avail_out===0))return g}else if(p.match_available){if((_=r._tr_tally(p,0,p.window[p.strstart-1]))&&z(p,!1),p.strstart++,p.lookahead--,p.strm.avail_out===0)return g}else p.match_available=1,p.strstart++,p.lookahead--}return p.match_available&&(_=r._tr_tally(p,0,p.window[p.strstart-1]),p.match_available=0),p.insert=p.strstart<P-1?p.strstart:P-1,j===v?(z(p,!0),p.strm.avail_out===0?q:U):p.last_lit&&(z(p,!1),p.strm.avail_out===0)?g:N}function X(p,j,L,_,$){this.good_length=p,this.max_lazy=j,this.nice_length=L,this.max_chain=_,this.func=$}function dt(){this.strm=null,this.status=0,this.pending_buf=null,this.pending_buf_size=0,this.pending_out=0,this.pending=0,this.wrap=0,this.gzhead=null,this.gzindex=0,this.method=x,this.last_flush=-1,this.w_size=0,this.w_bits=0,this.w_mask=0,this.window=null,this.window_size=0,this.prev=null,this.head=null,this.ins_h=0,this.hash_size=0,this.hash_bits=0,this.hash_mask=0,this.hash_shift=0,this.block_start=0,this.match_length=0,this.prev_match=0,this.match_available=0,this.strstart=0,this.match_start=0,this.lookahead=0,this.prev_length=0,this.max_chain_length=0,this.max_lazy_match=0,this.level=0,this.strategy=0,this.good_match=0,this.nice_match=0,this.dyn_ltree=new l.Buf16(2*w),this.dyn_dtree=new l.Buf16(2*(2*B+1)),this.bl_tree=new l.Buf16(2*(2*I+1)),O(this.dyn_ltree),O(this.dyn_dtree),O(this.bl_tree),this.l_desc=null,this.d_desc=null,this.bl_desc=null,this.bl_count=new l.Buf16(D+1),this.heap=new l.Buf16(2*A+1),O(this.heap),this.heap_len=0,this.heap_max=0,this.depth=new l.Buf16(2*A+1),O(this.depth),this.l_buf=0,this.lit_bufsize=0,this.last_lit=0,this.d_buf=0,this.opt_len=0,this.static_len=0,this.matches=0,this.insert=0,this.bi_buf=0,this.bi_valid=0}function bt(p){var j;return p&&p.state?(p.total_in=p.total_out=0,p.data_type=k,(j=p.state).pending=0,j.pending_out=0,j.wrap<0&&(j.wrap=-j.wrap),j.status=j.wrap?S:H,p.adler=j.wrap===2?0:1,j.last_flush=m,r._tr_init(j),d):G(p,b)}function T(p){var j=bt(p);return j===d&&(function(L){L.window_size=2*L.w_size,O(L.head),L.max_lazy_match=s[L.level].max_lazy,L.good_match=s[L.level].good_length,L.nice_match=s[L.level].nice_length,L.max_chain_length=s[L.level].max_chain,L.strstart=0,L.block_start=0,L.lookahead=0,L.insert=0,L.match_length=L.prev_length=P-1,L.match_available=0,L.ins_h=0})(p.state),j}function F(p,j,L,_,$,M){if(!p)return b;var K=1;if(j===f&&(j=6),_<0?(K=0,_=-_):15<_&&(K=2,_-=16),$<1||C<$||L!==x||_<8||15<_||j<0||9<j||M<0||y<M)return G(p,b);_===8&&(_=9);var W=new dt;return(p.state=W).strm=p,W.wrap=K,W.gzhead=null,W.w_bits=_,W.w_size=1<<W.w_bits,W.w_mask=W.w_size-1,W.hash_bits=$+7,W.hash_size=1<<W.hash_bits,W.hash_mask=W.hash_size-1,W.hash_shift=~~((W.hash_bits+P-1)/P),W.window=new l.Buf8(2*W.w_size),W.head=new l.Buf16(W.hash_size),W.prev=new l.Buf16(W.w_size),W.lit_bufsize=1<<$+6,W.pending_buf_size=4*W.lit_bufsize,W.pending_buf=new l.Buf8(W.pending_buf_size),W.d_buf=1*W.lit_bufsize,W.l_buf=3*W.lit_bufsize,W.level=j,W.strategy=M,W.method=L,T(p)}s=[new X(0,0,0,0,function(p,j){var L=65535;for(L>p.pending_buf_size-5&&(L=p.pending_buf_size-5);;){if(p.lookahead<=1){if(Y(p),p.lookahead===0&&j===m)return g;if(p.lookahead===0)break}p.strstart+=p.lookahead,p.lookahead=0;var _=p.block_start+L;if((p.strstart===0||p.strstart>=_)&&(p.lookahead=p.strstart-_,p.strstart=_,z(p,!1),p.strm.avail_out===0)||p.strstart-p.block_start>=p.w_size-J&&(z(p,!1),p.strm.avail_out===0))return g}return p.insert=0,j===v?(z(p,!0),p.strm.avail_out===0?q:U):(p.strstart>p.block_start&&(z(p,!1),p.strm.avail_out),g)}),new X(4,4,8,4,ct),new X(4,5,16,8,ct),new X(4,6,32,32,ct),new X(4,4,16,16,pt),new X(8,16,32,32,pt),new X(8,16,128,128,pt),new X(8,32,128,256,pt),new X(32,128,258,1024,pt),new X(32,258,258,4096,pt)],o.deflateInit=function(p,j){return F(p,j,x,15,8,0)},o.deflateInit2=F,o.deflateReset=T,o.deflateResetKeep=bt,o.deflateSetHeader=function(p,j){return p&&p.state?p.state.wrap!==2?b:(p.state.gzhead=j,d):b},o.deflate=function(p,j){var L,_,$,M;if(!p||!p.state||5<j||j<0)return p?G(p,b):b;if(_=p.state,!p.output||!p.input&&p.avail_in!==0||_.status===666&&j!==v)return G(p,p.avail_out===0?-5:b);if(_.strm=p,L=_.last_flush,_.last_flush=j,_.status===S)if(_.wrap===2)p.adler=0,rt(_,31),rt(_,139),rt(_,8),_.gzhead?(rt(_,(_.gzhead.text?1:0)+(_.gzhead.hcrc?2:0)+(_.gzhead.extra?4:0)+(_.gzhead.name?8:0)+(_.gzhead.comment?16:0)),rt(_,255&_.gzhead.time),rt(_,_.gzhead.time>>8&255),rt(_,_.gzhead.time>>16&255),rt(_,_.gzhead.time>>24&255),rt(_,_.level===9?2:2<=_.strategy||_.level<2?4:0),rt(_,255&_.gzhead.os),_.gzhead.extra&&_.gzhead.extra.length&&(rt(_,255&_.gzhead.extra.length),rt(_,_.gzhead.extra.length>>8&255)),_.gzhead.hcrc&&(p.adler=c(p.adler,_.pending_buf,_.pending,0)),_.gzindex=0,_.status=69):(rt(_,0),rt(_,0),rt(_,0),rt(_,0),rt(_,0),rt(_,_.level===9?2:2<=_.strategy||_.level<2?4:0),rt(_,3),_.status=H);else{var K=x+(_.w_bits-8<<4)<<8;K|=(2<=_.strategy||_.level<2?0:_.level<6?1:_.level===6?2:3)<<6,_.strstart!==0&&(K|=32),K+=31-K%31,_.status=H,nt(_,K),_.strstart!==0&&(nt(_,p.adler>>>16),nt(_,65535&p.adler)),p.adler=1}if(_.status===69)if(_.gzhead.extra){for($=_.pending;_.gzindex<(65535&_.gzhead.extra.length)&&(_.pending!==_.pending_buf_size||(_.gzhead.hcrc&&_.pending>$&&(p.adler=c(p.adler,_.pending_buf,_.pending-$,$)),E(p),$=_.pending,_.pending!==_.pending_buf_size));)rt(_,255&_.gzhead.extra[_.gzindex]),_.gzindex++;_.gzhead.hcrc&&_.pending>$&&(p.adler=c(p.adler,_.pending_buf,_.pending-$,$)),_.gzindex===_.gzhead.extra.length&&(_.gzindex=0,_.status=73)}else _.status=73;if(_.status===73)if(_.gzhead.name){$=_.pending;do{if(_.pending===_.pending_buf_size&&(_.gzhead.hcrc&&_.pending>$&&(p.adler=c(p.adler,_.pending_buf,_.pending-$,$)),E(p),$=_.pending,_.pending===_.pending_buf_size)){M=1;break}M=_.gzindex<_.gzhead.name.length?255&_.gzhead.name.charCodeAt(_.gzindex++):0,rt(_,M)}while(M!==0);_.gzhead.hcrc&&_.pending>$&&(p.adler=c(p.adler,_.pending_buf,_.pending-$,$)),M===0&&(_.gzindex=0,_.status=91)}else _.status=91;if(_.status===91)if(_.gzhead.comment){$=_.pending;do{if(_.pending===_.pending_buf_size&&(_.gzhead.hcrc&&_.pending>$&&(p.adler=c(p.adler,_.pending_buf,_.pending-$,$)),E(p),$=_.pending,_.pending===_.pending_buf_size)){M=1;break}M=_.gzindex<_.gzhead.comment.length?255&_.gzhead.comment.charCodeAt(_.gzindex++):0,rt(_,M)}while(M!==0);_.gzhead.hcrc&&_.pending>$&&(p.adler=c(p.adler,_.pending_buf,_.pending-$,$)),M===0&&(_.status=103)}else _.status=103;if(_.status===103&&(_.gzhead.hcrc?(_.pending+2>_.pending_buf_size&&E(p),_.pending+2<=_.pending_buf_size&&(rt(_,255&p.adler),rt(_,p.adler>>8&255),p.adler=0,_.status=H)):_.status=H),_.pending!==0){if(E(p),p.avail_out===0)return _.last_flush=-1,d}else if(p.avail_in===0&&Z(j)<=Z(L)&&j!==v)return G(p,-5);if(_.status===666&&p.avail_in!==0)return G(p,-5);if(p.avail_in!==0||_.lookahead!==0||j!==m&&_.status!==666){var W=_.strategy===2?(function(V,Q){for(var lt;;){if(V.lookahead===0&&(Y(V),V.lookahead===0)){if(Q===m)return g;break}if(V.match_length=0,lt=r._tr_tally(V,0,V.window[V.strstart]),V.lookahead--,V.strstart++,lt&&(z(V,!1),V.strm.avail_out===0))return g}return V.insert=0,Q===v?(z(V,!0),V.strm.avail_out===0?q:U):V.last_lit&&(z(V,!1),V.strm.avail_out===0)?g:N})(_,j):_.strategy===3?(function(V,Q){for(var lt,st,ft,xt,kt=V.window;;){if(V.lookahead<=R){if(Y(V),V.lookahead<=R&&Q===m)return g;if(V.lookahead===0)break}if(V.match_length=0,V.lookahead>=P&&0<V.strstart&&(st=kt[ft=V.strstart-1])===kt[++ft]&&st===kt[++ft]&&st===kt[++ft]){xt=V.strstart+R;do;while(st===kt[++ft]&&st===kt[++ft]&&st===kt[++ft]&&st===kt[++ft]&&st===kt[++ft]&&st===kt[++ft]&&st===kt[++ft]&&st===kt[++ft]&&ft<xt);V.match_length=R-(xt-ft),V.match_length>V.lookahead&&(V.match_length=V.lookahead)}if(V.match_length>=P?(lt=r._tr_tally(V,1,V.match_length-P),V.lookahead-=V.match_length,V.strstart+=V.match_length,V.match_length=0):(lt=r._tr_tally(V,0,V.window[V.strstart]),V.lookahead--,V.strstart++),lt&&(z(V,!1),V.strm.avail_out===0))return g}return V.insert=0,Q===v?(z(V,!0),V.strm.avail_out===0?q:U):V.last_lit&&(z(V,!1),V.strm.avail_out===0)?g:N})(_,j):s[_.level].func(_,j);if(W!==q&&W!==U||(_.status=666),W===g||W===q)return p.avail_out===0&&(_.last_flush=-1),d;if(W===N&&(j===1?r._tr_align(_):j!==5&&(r._tr_stored_block(_,0,0,!1),j===3&&(O(_.head),_.lookahead===0&&(_.strstart=0,_.block_start=0,_.insert=0))),E(p),p.avail_out===0))return _.last_flush=-1,d}return j!==v?d:_.wrap<=0?1:(_.wrap===2?(rt(_,255&p.adler),rt(_,p.adler>>8&255),rt(_,p.adler>>16&255),rt(_,p.adler>>24&255),rt(_,255&p.total_in),rt(_,p.total_in>>8&255),rt(_,p.total_in>>16&255),rt(_,p.total_in>>24&255)):(nt(_,p.adler>>>16),nt(_,65535&p.adler)),E(p),0<_.wrap&&(_.wrap=-_.wrap),_.pending!==0?d:1)},o.deflateEnd=function(p){var j;return p&&p.state?(j=p.state.status)!==S&&j!==69&&j!==73&&j!==91&&j!==103&&j!==H&&j!==666?G(p,b):(p.state=null,j===H?G(p,-3):d):b},o.deflateSetDictionary=function(p,j){var L,_,$,M,K,W,V,Q,lt=j.length;if(!p||!p.state||(M=(L=p.state).wrap)===2||M===1&&L.status!==S||L.lookahead)return b;for(M===1&&(p.adler=a(p.adler,j,lt,0)),L.wrap=0,lt>=L.w_size&&(M===0&&(O(L.head),L.strstart=0,L.block_start=0,L.insert=0),Q=new l.Buf8(L.w_size),l.arraySet(Q,j,lt-L.w_size,L.w_size,0),j=Q,lt=L.w_size),K=p.avail_in,W=p.next_in,V=p.input,p.avail_in=lt,p.next_in=0,p.input=j,Y(L);L.lookahead>=P;){for(_=L.strstart,$=L.lookahead-(P-1);L.ins_h=(L.ins_h<<L.hash_shift^L.window[_+P-1])&L.hash_mask,L.prev[_&L.w_mask]=L.head[L.ins_h],L.head[L.ins_h]=_,_++,--$;);L.strstart=_,L.lookahead=P-1,Y(L)}return L.strstart+=L.lookahead,L.block_start=L.strstart,L.insert=L.lookahead,L.lookahead=0,L.match_length=L.prev_length=P-1,L.match_available=0,p.next_in=W,p.input=V,p.avail_in=K,L.wrap=M,d},o.deflateInfo="pako deflate (from Nodeca project)"},{"../utils/common":41,"./adler32":43,"./crc32":45,"./messages":51,"./trees":52}],47:[function(e,n,o){n.exports=function(){this.text=0,this.time=0,this.xflags=0,this.os=0,this.extra=null,this.extra_len=0,this.name="",this.comment="",this.hcrc=0,this.done=!1}},{}],48:[function(e,n,o){n.exports=function(s,l){var r,a,c,u,m,v,d,b,f,y,k,x,C,A,B,I,w,D,P,R,J,S,H,g,N;r=s.state,a=s.next_in,g=s.input,c=a+(s.avail_in-5),u=s.next_out,N=s.output,m=u-(l-s.avail_out),v=u+(s.avail_out-257),d=r.dmax,b=r.wsize,f=r.whave,y=r.wnext,k=r.window,x=r.hold,C=r.bits,A=r.lencode,B=r.distcode,I=(1<<r.lenbits)-1,w=(1<<r.distbits)-1;t:do{C<15&&(x+=g[a++]<<C,C+=8,x+=g[a++]<<C,C+=8),D=A[x&I];e:for(;;){if(x>>>=P=D>>>24,C-=P,(P=D>>>16&255)===0)N[u++]=65535&D;else{if(!(16&P)){if((64&P)==0){D=A[(65535&D)+(x&(1<<P)-1)];continue e}if(32&P){r.mode=12;break t}s.msg="invalid literal/length code",r.mode=30;break t}R=65535&D,(P&=15)&&(C<P&&(x+=g[a++]<<C,C+=8),R+=x&(1<<P)-1,x>>>=P,C-=P),C<15&&(x+=g[a++]<<C,C+=8,x+=g[a++]<<C,C+=8),D=B[x&w];i:for(;;){if(x>>>=P=D>>>24,C-=P,!(16&(P=D>>>16&255))){if((64&P)==0){D=B[(65535&D)+(x&(1<<P)-1)];continue i}s.msg="invalid distance code",r.mode=30;break t}if(J=65535&D,C<(P&=15)&&(x+=g[a++]<<C,(C+=8)<P&&(x+=g[a++]<<C,C+=8)),d<(J+=x&(1<<P)-1)){s.msg="invalid distance too far back",r.mode=30;break t}if(x>>>=P,C-=P,(P=u-m)<J){if(f<(P=J-P)&&r.sane){s.msg="invalid distance too far back",r.mode=30;break t}if(H=k,(S=0)===y){if(S+=b-P,P<R){for(R-=P;N[u++]=k[S++],--P;);S=u-J,H=N}}else if(y<P){if(S+=b+y-P,(P-=y)<R){for(R-=P;N[u++]=k[S++],--P;);if(S=0,y<R){for(R-=P=y;N[u++]=k[S++],--P;);S=u-J,H=N}}}else if(S+=y-P,P<R){for(R-=P;N[u++]=k[S++],--P;);S=u-J,H=N}for(;2<R;)N[u++]=H[S++],N[u++]=H[S++],N[u++]=H[S++],R-=3;R&&(N[u++]=H[S++],1<R&&(N[u++]=H[S++]))}else{for(S=u-J;N[u++]=N[S++],N[u++]=N[S++],N[u++]=N[S++],2<(R-=3););R&&(N[u++]=N[S++],1<R&&(N[u++]=N[S++]))}break}}break}}while(a<c&&u<v);a-=R=C>>3,x&=(1<<(C-=R<<3))-1,s.next_in=a,s.next_out=u,s.avail_in=a<c?c-a+5:5-(a-c),s.avail_out=u<v?v-u+257:257-(u-v),r.hold=x,r.bits=C}},{}],49:[function(e,n,o){var s=e("../utils/common"),l=e("./adler32"),r=e("./crc32"),a=e("./inffast"),c=e("./inftrees"),u=1,m=2,v=0,d=-2,b=1,f=852,y=592;function k(S){return(S>>>24&255)+(S>>>8&65280)+((65280&S)<<8)+((255&S)<<24)}function x(){this.mode=0,this.last=!1,this.wrap=0,this.havedict=!1,this.flags=0,this.dmax=0,this.check=0,this.total=0,this.head=null,this.wbits=0,this.wsize=0,this.whave=0,this.wnext=0,this.window=null,this.hold=0,this.bits=0,this.length=0,this.offset=0,this.extra=0,this.lencode=null,this.distcode=null,this.lenbits=0,this.distbits=0,this.ncode=0,this.nlen=0,this.ndist=0,this.have=0,this.next=null,this.lens=new s.Buf16(320),this.work=new s.Buf16(288),this.lendyn=null,this.distdyn=null,this.sane=0,this.back=0,this.was=0}function C(S){var H;return S&&S.state?(H=S.state,S.total_in=S.total_out=H.total=0,S.msg="",H.wrap&&(S.adler=1&H.wrap),H.mode=b,H.last=0,H.havedict=0,H.dmax=32768,H.head=null,H.hold=0,H.bits=0,H.lencode=H.lendyn=new s.Buf32(f),H.distcode=H.distdyn=new s.Buf32(y),H.sane=1,H.back=-1,v):d}function A(S){var H;return S&&S.state?((H=S.state).wsize=0,H.whave=0,H.wnext=0,C(S)):d}function B(S,H){var g,N;return S&&S.state?(N=S.state,H<0?(g=0,H=-H):(g=1+(H>>4),H<48&&(H&=15)),H&&(H<8||15<H)?d:(N.window!==null&&N.wbits!==H&&(N.window=null),N.wrap=g,N.wbits=H,A(S))):d}function I(S,H){var g,N;return S?(N=new x,(S.state=N).window=null,(g=B(S,H))!==v&&(S.state=null),g):d}var w,D,P=!0;function R(S){if(P){var H;for(w=new s.Buf32(512),D=new s.Buf32(32),H=0;H<144;)S.lens[H++]=8;for(;H<256;)S.lens[H++]=9;for(;H<280;)S.lens[H++]=7;for(;H<288;)S.lens[H++]=8;for(c(u,S.lens,0,288,w,0,S.work,{bits:9}),H=0;H<32;)S.lens[H++]=5;c(m,S.lens,0,32,D,0,S.work,{bits:5}),P=!1}S.lencode=w,S.lenbits=9,S.distcode=D,S.distbits=5}function J(S,H,g,N){var q,U=S.state;return U.window===null&&(U.wsize=1<<U.wbits,U.wnext=0,U.whave=0,U.window=new s.Buf8(U.wsize)),N>=U.wsize?(s.arraySet(U.window,H,g-U.wsize,U.wsize,0),U.wnext=0,U.whave=U.wsize):(N<(q=U.wsize-U.wnext)&&(q=N),s.arraySet(U.window,H,g-N,q,U.wnext),(N-=q)?(s.arraySet(U.window,H,g-N,N,0),U.wnext=N,U.whave=U.wsize):(U.wnext+=q,U.wnext===U.wsize&&(U.wnext=0),U.whave<U.wsize&&(U.whave+=q))),0}o.inflateReset=A,o.inflateReset2=B,o.inflateResetKeep=C,o.inflateInit=function(S){return I(S,15)},o.inflateInit2=I,o.inflate=function(S,H){var g,N,q,U,G,Z,O,E,z,rt,nt,tt,Y,ct,pt,X,dt,bt,T,F,p,j,L,_,$=0,M=new s.Buf8(4),K=[16,17,18,0,8,7,9,6,10,5,11,4,12,3,13,2,14,1,15];if(!S||!S.state||!S.output||!S.input&&S.avail_in!==0)return d;(g=S.state).mode===12&&(g.mode=13),G=S.next_out,q=S.output,O=S.avail_out,U=S.next_in,N=S.input,Z=S.avail_in,E=g.hold,z=g.bits,rt=Z,nt=O,j=v;t:for(;;)switch(g.mode){case b:if(g.wrap===0){g.mode=13;break}for(;z<16;){if(Z===0)break t;Z--,E+=N[U++]<<z,z+=8}if(2&g.wrap&&E===35615){M[g.check=0]=255&E,M[1]=E>>>8&255,g.check=r(g.check,M,2,0),z=E=0,g.mode=2;break}if(g.flags=0,g.head&&(g.head.done=!1),!(1&g.wrap)||(((255&E)<<8)+(E>>8))%31){S.msg="incorrect header check",g.mode=30;break}if((15&E)!=8){S.msg="unknown compression method",g.mode=30;break}if(z-=4,p=8+(15&(E>>>=4)),g.wbits===0)g.wbits=p;else if(p>g.wbits){S.msg="invalid window size",g.mode=30;break}g.dmax=1<<p,S.adler=g.check=1,g.mode=512&E?10:12,z=E=0;break;case 2:for(;z<16;){if(Z===0)break t;Z--,E+=N[U++]<<z,z+=8}if(g.flags=E,(255&g.flags)!=8){S.msg="unknown compression method",g.mode=30;break}if(57344&g.flags){S.msg="unknown header flags set",g.mode=30;break}g.head&&(g.head.text=E>>8&1),512&g.flags&&(M[0]=255&E,M[1]=E>>>8&255,g.check=r(g.check,M,2,0)),z=E=0,g.mode=3;case 3:for(;z<32;){if(Z===0)break t;Z--,E+=N[U++]<<z,z+=8}g.head&&(g.head.time=E),512&g.flags&&(M[0]=255&E,M[1]=E>>>8&255,M[2]=E>>>16&255,M[3]=E>>>24&255,g.check=r(g.check,M,4,0)),z=E=0,g.mode=4;case 4:for(;z<16;){if(Z===0)break t;Z--,E+=N[U++]<<z,z+=8}g.head&&(g.head.xflags=255&E,g.head.os=E>>8),512&g.flags&&(M[0]=255&E,M[1]=E>>>8&255,g.check=r(g.check,M,2,0)),z=E=0,g.mode=5;case 5:if(1024&g.flags){for(;z<16;){if(Z===0)break t;Z--,E+=N[U++]<<z,z+=8}g.length=E,g.head&&(g.head.extra_len=E),512&g.flags&&(M[0]=255&E,M[1]=E>>>8&255,g.check=r(g.check,M,2,0)),z=E=0}else g.head&&(g.head.extra=null);g.mode=6;case 6:if(1024&g.flags&&(Z<(tt=g.length)&&(tt=Z),tt&&(g.head&&(p=g.head.extra_len-g.length,g.head.extra||(g.head.extra=new Array(g.head.extra_len)),s.arraySet(g.head.extra,N,U,tt,p)),512&g.flags&&(g.check=r(g.check,N,tt,U)),Z-=tt,U+=tt,g.length-=tt),g.length))break t;g.length=0,g.mode=7;case 7:if(2048&g.flags){if(Z===0)break t;for(tt=0;p=N[U+tt++],g.head&&p&&g.length<65536&&(g.head.name+=String.fromCharCode(p)),p&&tt<Z;);if(512&g.flags&&(g.check=r(g.check,N,tt,U)),Z-=tt,U+=tt,p)break t}else g.head&&(g.head.name=null);g.length=0,g.mode=8;case 8:if(4096&g.flags){if(Z===0)break t;for(tt=0;p=N[U+tt++],g.head&&p&&g.length<65536&&(g.head.comment+=String.fromCharCode(p)),p&&tt<Z;);if(512&g.flags&&(g.check=r(g.check,N,tt,U)),Z-=tt,U+=tt,p)break t}else g.head&&(g.head.comment=null);g.mode=9;case 9:if(512&g.flags){for(;z<16;){if(Z===0)break t;Z--,E+=N[U++]<<z,z+=8}if(E!==(65535&g.check)){S.msg="header crc mismatch",g.mode=30;break}z=E=0}g.head&&(g.head.hcrc=g.flags>>9&1,g.head.done=!0),S.adler=g.check=0,g.mode=12;break;case 10:for(;z<32;){if(Z===0)break t;Z--,E+=N[U++]<<z,z+=8}S.adler=g.check=k(E),z=E=0,g.mode=11;case 11:if(g.havedict===0)return S.next_out=G,S.avail_out=O,S.next_in=U,S.avail_in=Z,g.hold=E,g.bits=z,2;S.adler=g.check=1,g.mode=12;case 12:if(H===5||H===6)break t;case 13:if(g.last){E>>>=7&z,z-=7&z,g.mode=27;break}for(;z<3;){if(Z===0)break t;Z--,E+=N[U++]<<z,z+=8}switch(g.last=1&E,z-=1,3&(E>>>=1)){case 0:g.mode=14;break;case 1:if(R(g),g.mode=20,H!==6)break;E>>>=2,z-=2;break t;case 2:g.mode=17;break;case 3:S.msg="invalid block type",g.mode=30}E>>>=2,z-=2;break;case 14:for(E>>>=7&z,z-=7&z;z<32;){if(Z===0)break t;Z--,E+=N[U++]<<z,z+=8}if((65535&E)!=(E>>>16^65535)){S.msg="invalid stored block lengths",g.mode=30;break}if(g.length=65535&E,z=E=0,g.mode=15,H===6)break t;case 15:g.mode=16;case 16:if(tt=g.length){if(Z<tt&&(tt=Z),O<tt&&(tt=O),tt===0)break t;s.arraySet(q,N,U,tt,G),Z-=tt,U+=tt,O-=tt,G+=tt,g.length-=tt;break}g.mode=12;break;case 17:for(;z<14;){if(Z===0)break t;Z--,E+=N[U++]<<z,z+=8}if(g.nlen=257+(31&E),E>>>=5,z-=5,g.ndist=1+(31&E),E>>>=5,z-=5,g.ncode=4+(15&E),E>>>=4,z-=4,286<g.nlen||30<g.ndist){S.msg="too many length or distance symbols",g.mode=30;break}g.have=0,g.mode=18;case 18:for(;g.have<g.ncode;){for(;z<3;){if(Z===0)break t;Z--,E+=N[U++]<<z,z+=8}g.lens[K[g.have++]]=7&E,E>>>=3,z-=3}for(;g.have<19;)g.lens[K[g.have++]]=0;if(g.lencode=g.lendyn,g.lenbits=7,L={bits:g.lenbits},j=c(0,g.lens,0,19,g.lencode,0,g.work,L),g.lenbits=L.bits,j){S.msg="invalid code lengths set",g.mode=30;break}g.have=0,g.mode=19;case 19:for(;g.have<g.nlen+g.ndist;){for(;X=($=g.lencode[E&(1<<g.lenbits)-1])>>>16&255,dt=65535&$,!((pt=$>>>24)<=z);){if(Z===0)break t;Z--,E+=N[U++]<<z,z+=8}if(dt<16)E>>>=pt,z-=pt,g.lens[g.have++]=dt;else{if(dt===16){for(_=pt+2;z<_;){if(Z===0)break t;Z--,E+=N[U++]<<z,z+=8}if(E>>>=pt,z-=pt,g.have===0){S.msg="invalid bit length repeat",g.mode=30;break}p=g.lens[g.have-1],tt=3+(3&E),E>>>=2,z-=2}else if(dt===17){for(_=pt+3;z<_;){if(Z===0)break t;Z--,E+=N[U++]<<z,z+=8}z-=pt,p=0,tt=3+(7&(E>>>=pt)),E>>>=3,z-=3}else{for(_=pt+7;z<_;){if(Z===0)break t;Z--,E+=N[U++]<<z,z+=8}z-=pt,p=0,tt=11+(127&(E>>>=pt)),E>>>=7,z-=7}if(g.have+tt>g.nlen+g.ndist){S.msg="invalid bit length repeat",g.mode=30;break}for(;tt--;)g.lens[g.have++]=p}}if(g.mode===30)break;if(g.lens[256]===0){S.msg="invalid code -- missing end-of-block",g.mode=30;break}if(g.lenbits=9,L={bits:g.lenbits},j=c(u,g.lens,0,g.nlen,g.lencode,0,g.work,L),g.lenbits=L.bits,j){S.msg="invalid literal/lengths set",g.mode=30;break}if(g.distbits=6,g.distcode=g.distdyn,L={bits:g.distbits},j=c(m,g.lens,g.nlen,g.ndist,g.distcode,0,g.work,L),g.distbits=L.bits,j){S.msg="invalid distances set",g.mode=30;break}if(g.mode=20,H===6)break t;case 20:g.mode=21;case 21:if(6<=Z&&258<=O){S.next_out=G,S.avail_out=O,S.next_in=U,S.avail_in=Z,g.hold=E,g.bits=z,a(S,nt),G=S.next_out,q=S.output,O=S.avail_out,U=S.next_in,N=S.input,Z=S.avail_in,E=g.hold,z=g.bits,g.mode===12&&(g.back=-1);break}for(g.back=0;X=($=g.lencode[E&(1<<g.lenbits)-1])>>>16&255,dt=65535&$,!((pt=$>>>24)<=z);){if(Z===0)break t;Z--,E+=N[U++]<<z,z+=8}if(X&&(240&X)==0){for(bt=pt,T=X,F=dt;X=($=g.lencode[F+((E&(1<<bt+T)-1)>>bt)])>>>16&255,dt=65535&$,!(bt+(pt=$>>>24)<=z);){if(Z===0)break t;Z--,E+=N[U++]<<z,z+=8}E>>>=bt,z-=bt,g.back+=bt}if(E>>>=pt,z-=pt,g.back+=pt,g.length=dt,X===0){g.mode=26;break}if(32&X){g.back=-1,g.mode=12;break}if(64&X){S.msg="invalid literal/length code",g.mode=30;break}g.extra=15&X,g.mode=22;case 22:if(g.extra){for(_=g.extra;z<_;){if(Z===0)break t;Z--,E+=N[U++]<<z,z+=8}g.length+=E&(1<<g.extra)-1,E>>>=g.extra,z-=g.extra,g.back+=g.extra}g.was=g.length,g.mode=23;case 23:for(;X=($=g.distcode[E&(1<<g.distbits)-1])>>>16&255,dt=65535&$,!((pt=$>>>24)<=z);){if(Z===0)break t;Z--,E+=N[U++]<<z,z+=8}if((240&X)==0){for(bt=pt,T=X,F=dt;X=($=g.distcode[F+((E&(1<<bt+T)-1)>>bt)])>>>16&255,dt=65535&$,!(bt+(pt=$>>>24)<=z);){if(Z===0)break t;Z--,E+=N[U++]<<z,z+=8}E>>>=bt,z-=bt,g.back+=bt}if(E>>>=pt,z-=pt,g.back+=pt,64&X){S.msg="invalid distance code",g.mode=30;break}g.offset=dt,g.extra=15&X,g.mode=24;case 24:if(g.extra){for(_=g.extra;z<_;){if(Z===0)break t;Z--,E+=N[U++]<<z,z+=8}g.offset+=E&(1<<g.extra)-1,E>>>=g.extra,z-=g.extra,g.back+=g.extra}if(g.offset>g.dmax){S.msg="invalid distance too far back",g.mode=30;break}g.mode=25;case 25:if(O===0)break t;if(tt=nt-O,g.offset>tt){if((tt=g.offset-tt)>g.whave&&g.sane){S.msg="invalid distance too far back",g.mode=30;break}Y=tt>g.wnext?(tt-=g.wnext,g.wsize-tt):g.wnext-tt,tt>g.length&&(tt=g.length),ct=g.window}else ct=q,Y=G-g.offset,tt=g.length;for(O<tt&&(tt=O),O-=tt,g.length-=tt;q[G++]=ct[Y++],--tt;);g.length===0&&(g.mode=21);break;case 26:if(O===0)break t;q[G++]=g.length,O--,g.mode=21;break;case 27:if(g.wrap){for(;z<32;){if(Z===0)break t;Z--,E|=N[U++]<<z,z+=8}if(nt-=O,S.total_out+=nt,g.total+=nt,nt&&(S.adler=g.check=g.flags?r(g.check,q,nt,G-nt):l(g.check,q,nt,G-nt)),nt=O,(g.flags?E:k(E))!==g.check){S.msg="incorrect data check",g.mode=30;break}z=E=0}g.mode=28;case 28:if(g.wrap&&g.flags){for(;z<32;){if(Z===0)break t;Z--,E+=N[U++]<<z,z+=8}if(E!==(4294967295&g.total)){S.msg="incorrect length check",g.mode=30;break}z=E=0}g.mode=29;case 29:j=1;break t;case 30:j=-3;break t;case 31:return-4;case 32:default:return d}return S.next_out=G,S.avail_out=O,S.next_in=U,S.avail_in=Z,g.hold=E,g.bits=z,(g.wsize||nt!==S.avail_out&&g.mode<30&&(g.mode<27||H!==4))&&J(S,S.output,S.next_out,nt-S.avail_out)?(g.mode=31,-4):(rt-=S.avail_in,nt-=S.avail_out,S.total_in+=rt,S.total_out+=nt,g.total+=nt,g.wrap&&nt&&(S.adler=g.check=g.flags?r(g.check,q,nt,S.next_out-nt):l(g.check,q,nt,S.next_out-nt)),S.data_type=g.bits+(g.last?64:0)+(g.mode===12?128:0)+(g.mode===20||g.mode===15?256:0),(rt==0&&nt===0||H===4)&&j===v&&(j=-5),j)},o.inflateEnd=function(S){if(!S||!S.state)return d;var H=S.state;return H.window&&(H.window=null),S.state=null,v},o.inflateGetHeader=function(S,H){var g;return S&&S.state?(2&(g=S.state).wrap)==0?d:((g.head=H).done=!1,v):d},o.inflateSetDictionary=function(S,H){var g,N=H.length;return S&&S.state?(g=S.state).wrap!==0&&g.mode!==11?d:g.mode===11&&l(1,H,N,0)!==g.check?-3:J(S,H,N,N)?(g.mode=31,-4):(g.havedict=1,v):d},o.inflateInfo="pako inflate (from Nodeca project)"},{"../utils/common":41,"./adler32":43,"./crc32":45,"./inffast":48,"./inftrees":50}],50:[function(e,n,o){var s=e("../utils/common"),l=[3,4,5,6,7,8,9,10,11,13,15,17,19,23,27,31,35,43,51,59,67,83,99,115,131,163,195,227,258,0,0],r=[16,16,16,16,16,16,16,16,17,17,17,17,18,18,18,18,19,19,19,19,20,20,20,20,21,21,21,21,16,72,78],a=[1,2,3,4,5,7,9,13,17,25,33,49,65,97,129,193,257,385,513,769,1025,1537,2049,3073,4097,6145,8193,12289,16385,24577,0,0],c=[16,16,16,16,17,17,18,18,19,19,20,20,21,21,22,22,23,23,24,24,25,25,26,26,27,27,28,28,29,29,64,64];n.exports=function(u,m,v,d,b,f,y,k){var x,C,A,B,I,w,D,P,R,J=k.bits,S=0,H=0,g=0,N=0,q=0,U=0,G=0,Z=0,O=0,E=0,z=null,rt=0,nt=new s.Buf16(16),tt=new s.Buf16(16),Y=null,ct=0;for(S=0;S<=15;S++)nt[S]=0;for(H=0;H<d;H++)nt[m[v+H]]++;for(q=J,N=15;1<=N&&nt[N]===0;N--);if(N<q&&(q=N),N===0)return b[f++]=20971520,b[f++]=20971520,k.bits=1,0;for(g=1;g<N&&nt[g]===0;g++);for(q<g&&(q=g),S=Z=1;S<=15;S++)if(Z<<=1,(Z-=nt[S])<0)return-1;if(0<Z&&(u===0||N!==1))return-1;for(tt[1]=0,S=1;S<15;S++)tt[S+1]=tt[S]+nt[S];for(H=0;H<d;H++)m[v+H]!==0&&(y[tt[m[v+H]]++]=H);if(w=u===0?(z=Y=y,19):u===1?(z=l,rt-=257,Y=r,ct-=257,256):(z=a,Y=c,-1),S=g,I=f,G=H=E=0,A=-1,B=(O=1<<(U=q))-1,u===1&&852<O||u===2&&592<O)return 1;for(;;){for(D=S-G,R=y[H]<w?(P=0,y[H]):y[H]>w?(P=Y[ct+y[H]],z[rt+y[H]]):(P=96,0),x=1<<S-G,g=C=1<<U;b[I+(E>>G)+(C-=x)]=D<<24|P<<16|R|0,C!==0;);for(x=1<<S-1;E&x;)x>>=1;if(x!==0?(E&=x-1,E+=x):E=0,H++,--nt[S]==0){if(S===N)break;S=m[v+y[H]]}if(q<S&&(E&B)!==A){for(G===0&&(G=q),I+=g,Z=1<<(U=S-G);U+G<N&&!((Z-=nt[U+G])<=0);)U++,Z<<=1;if(O+=1<<U,u===1&&852<O||u===2&&592<O)return 1;b[A=E&B]=q<<24|U<<16|I-f|0}}return E!==0&&(b[I+E]=S-G<<24|64<<16|0),k.bits=q,0}},{"../utils/common":41}],51:[function(e,n,o){n.exports={2:"need dictionary",1:"stream end",0:"","-1":"file error","-2":"stream error","-3":"data error","-4":"insufficient memory","-5":"buffer error","-6":"incompatible version"}},{}],52:[function(e,n,o){var s=e("../utils/common"),l=0,r=1;function a($){for(var M=$.length;0<=--M;)$[M]=0}var c=0,u=29,m=256,v=m+1+u,d=30,b=19,f=2*v+1,y=15,k=16,x=7,C=256,A=16,B=17,I=18,w=[0,0,0,0,0,0,0,0,1,1,1,1,2,2,2,2,3,3,3,3,4,4,4,4,5,5,5,5,0],D=[0,0,0,0,1,1,2,2,3,3,4,4,5,5,6,6,7,7,8,8,9,9,10,10,11,11,12,12,13,13],P=[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,2,3,7],R=[16,17,18,0,8,7,9,6,10,5,11,4,12,3,13,2,14,1,15],J=new Array(2*(v+2));a(J);var S=new Array(2*d);a(S);var H=new Array(512);a(H);var g=new Array(256);a(g);var N=new Array(u);a(N);var q,U,G,Z=new Array(d);function O($,M,K,W,V){this.static_tree=$,this.extra_bits=M,this.extra_base=K,this.elems=W,this.max_length=V,this.has_stree=$&&$.length}function E($,M){this.dyn_tree=$,this.max_code=0,this.stat_desc=M}function z($){return $<256?H[$]:H[256+($>>>7)]}function rt($,M){$.pending_buf[$.pending++]=255&M,$.pending_buf[$.pending++]=M>>>8&255}function nt($,M,K){$.bi_valid>k-K?($.bi_buf|=M<<$.bi_valid&65535,rt($,$.bi_buf),$.bi_buf=M>>k-$.bi_valid,$.bi_valid+=K-k):($.bi_buf|=M<<$.bi_valid&65535,$.bi_valid+=K)}function tt($,M,K){nt($,K[2*M],K[2*M+1])}function Y($,M){for(var K=0;K|=1&$,$>>>=1,K<<=1,0<--M;);return K>>>1}function ct($,M,K){var W,V,Q=new Array(y+1),lt=0;for(W=1;W<=y;W++)Q[W]=lt=lt+K[W-1]<<1;for(V=0;V<=M;V++){var st=$[2*V+1];st!==0&&($[2*V]=Y(Q[st]++,st))}}function pt($){var M;for(M=0;M<v;M++)$.dyn_ltree[2*M]=0;for(M=0;M<d;M++)$.dyn_dtree[2*M]=0;for(M=0;M<b;M++)$.bl_tree[2*M]=0;$.dyn_ltree[2*C]=1,$.opt_len=$.static_len=0,$.last_lit=$.matches=0}function X($){8<$.bi_valid?rt($,$.bi_buf):0<$.bi_valid&&($.pending_buf[$.pending++]=$.bi_buf),$.bi_buf=0,$.bi_valid=0}function dt($,M,K,W){var V=2*M,Q=2*K;return $[V]<$[Q]||$[V]===$[Q]&&W[M]<=W[K]}function bt($,M,K){for(var W=$.heap[K],V=K<<1;V<=$.heap_len&&(V<$.heap_len&&dt(M,$.heap[V+1],$.heap[V],$.depth)&&V++,!dt(M,W,$.heap[V],$.depth));)$.heap[K]=$.heap[V],K=V,V<<=1;$.heap[K]=W}function T($,M,K){var W,V,Q,lt,st=0;if($.last_lit!==0)for(;W=$.pending_buf[$.d_buf+2*st]<<8|$.pending_buf[$.d_buf+2*st+1],V=$.pending_buf[$.l_buf+st],st++,W===0?tt($,V,M):(tt($,(Q=g[V])+m+1,M),(lt=w[Q])!==0&&nt($,V-=N[Q],lt),tt($,Q=z(--W),K),(lt=D[Q])!==0&&nt($,W-=Z[Q],lt)),st<$.last_lit;);tt($,C,M)}function F($,M){var K,W,V,Q=M.dyn_tree,lt=M.stat_desc.static_tree,st=M.stat_desc.has_stree,ft=M.stat_desc.elems,xt=-1;for($.heap_len=0,$.heap_max=f,K=0;K<ft;K++)Q[2*K]!==0?($.heap[++$.heap_len]=xt=K,$.depth[K]=0):Q[2*K+1]=0;for(;$.heap_len<2;)Q[2*(V=$.heap[++$.heap_len]=xt<2?++xt:0)]=1,$.depth[V]=0,$.opt_len--,st&&($.static_len-=lt[2*V+1]);for(M.max_code=xt,K=$.heap_len>>1;1<=K;K--)bt($,Q,K);for(V=ft;K=$.heap[1],$.heap[1]=$.heap[$.heap_len--],bt($,Q,1),W=$.heap[1],$.heap[--$.heap_max]=K,$.heap[--$.heap_max]=W,Q[2*V]=Q[2*K]+Q[2*W],$.depth[V]=($.depth[K]>=$.depth[W]?$.depth[K]:$.depth[W])+1,Q[2*K+1]=Q[2*W+1]=V,$.heap[1]=V++,bt($,Q,1),2<=$.heap_len;);$.heap[--$.heap_max]=$.heap[1],(function(kt,Mt){var Kt,Gt,ne,Nt,Ke,ee,Yt=Mt.dyn_tree,ki=Mt.max_code,Oi=Mt.stat_desc.static_tree,Eo=Mt.stat_desc.has_stree,Mo=Mt.stat_desc.extra_bits,Nn=Mt.stat_desc.extra_base,wi=Mt.stat_desc.max_length,zi=0;for(Nt=0;Nt<=y;Nt++)kt.bl_count[Nt]=0;for(Yt[2*kt.heap[kt.heap_max]+1]=0,Kt=kt.heap_max+1;Kt<f;Kt++)wi<(Nt=Yt[2*Yt[2*(Gt=kt.heap[Kt])+1]+1]+1)&&(Nt=wi,zi++),Yt[2*Gt+1]=Nt,ki<Gt||(kt.bl_count[Nt]++,Ke=0,Nn<=Gt&&(Ke=Mo[Gt-Nn]),ee=Yt[2*Gt],kt.opt_len+=ee*(Nt+Ke),Eo&&(kt.static_len+=ee*(Oi[2*Gt+1]+Ke)));if(zi!==0){do{for(Nt=wi-1;kt.bl_count[Nt]===0;)Nt--;kt.bl_count[Nt]--,kt.bl_count[Nt+1]+=2,kt.bl_count[wi]--,zi-=2}while(0<zi);for(Nt=wi;Nt!==0;Nt--)for(Gt=kt.bl_count[Nt];Gt!==0;)ki<(ne=kt.heap[--Kt])||(Yt[2*ne+1]!==Nt&&(kt.opt_len+=(Nt-Yt[2*ne+1])*Yt[2*ne],Yt[2*ne+1]=Nt),Gt--)}})($,M),ct(Q,xt,$.bl_count)}function p($,M,K){var W,V,Q=-1,lt=M[1],st=0,ft=7,xt=4;for(lt===0&&(ft=138,xt=3),M[2*(K+1)+1]=65535,W=0;W<=K;W++)V=lt,lt=M[2*(W+1)+1],++st<ft&&V===lt||(st<xt?$.bl_tree[2*V]+=st:V!==0?(V!==Q&&$.bl_tree[2*V]++,$.bl_tree[2*A]++):st<=10?$.bl_tree[2*B]++:$.bl_tree[2*I]++,Q=V,xt=(st=0)===lt?(ft=138,3):V===lt?(ft=6,3):(ft=7,4))}function j($,M,K){var W,V,Q=-1,lt=M[1],st=0,ft=7,xt=4;for(lt===0&&(ft=138,xt=3),W=0;W<=K;W++)if(V=lt,lt=M[2*(W+1)+1],!(++st<ft&&V===lt)){if(st<xt)for(;tt($,V,$.bl_tree),--st!=0;);else V!==0?(V!==Q&&(tt($,V,$.bl_tree),st--),tt($,A,$.bl_tree),nt($,st-3,2)):st<=10?(tt($,B,$.bl_tree),nt($,st-3,3)):(tt($,I,$.bl_tree),nt($,st-11,7));Q=V,xt=(st=0)===lt?(ft=138,3):V===lt?(ft=6,3):(ft=7,4)}}a(Z);var L=!1;function _($,M,K,W){nt($,(c<<1)+(W?1:0),3),(function(V,Q,lt,st){X(V),rt(V,lt),rt(V,~lt),s.arraySet(V.pending_buf,V.window,Q,lt,V.pending),V.pending+=lt})($,M,K)}o._tr_init=function($){L||((function(){var M,K,W,V,Q,lt=new Array(y+1);for(V=W=0;V<u-1;V++)for(N[V]=W,M=0;M<1<<w[V];M++)g[W++]=V;for(g[W-1]=V,V=Q=0;V<16;V++)for(Z[V]=Q,M=0;M<1<<D[V];M++)H[Q++]=V;for(Q>>=7;V<d;V++)for(Z[V]=Q<<7,M=0;M<1<<D[V]-7;M++)H[256+Q++]=V;for(K=0;K<=y;K++)lt[K]=0;for(M=0;M<=143;)J[2*M+1]=8,M++,lt[8]++;for(;M<=255;)J[2*M+1]=9,M++,lt[9]++;for(;M<=279;)J[2*M+1]=7,M++,lt[7]++;for(;M<=287;)J[2*M+1]=8,M++,lt[8]++;for(ct(J,v+1,lt),M=0;M<d;M++)S[2*M+1]=5,S[2*M]=Y(M,5);q=new O(J,w,m+1,v,y),U=new O(S,D,0,d,y),G=new O(new Array(0),P,0,b,x)})(),L=!0),$.l_desc=new E($.dyn_ltree,q),$.d_desc=new E($.dyn_dtree,U),$.bl_desc=new E($.bl_tree,G),$.bi_buf=0,$.bi_valid=0,pt($)},o._tr_stored_block=_,o._tr_flush_block=function($,M,K,W){var V,Q,lt=0;0<$.level?($.strm.data_type===2&&($.strm.data_type=(function(st){var ft,xt=4093624447;for(ft=0;ft<=31;ft++,xt>>>=1)if(1&xt&&st.dyn_ltree[2*ft]!==0)return l;if(st.dyn_ltree[18]!==0||st.dyn_ltree[20]!==0||st.dyn_ltree[26]!==0)return r;for(ft=32;ft<m;ft++)if(st.dyn_ltree[2*ft]!==0)return r;return l})($)),F($,$.l_desc),F($,$.d_desc),lt=(function(st){var ft;for(p(st,st.dyn_ltree,st.l_desc.max_code),p(st,st.dyn_dtree,st.d_desc.max_code),F(st,st.bl_desc),ft=b-1;3<=ft&&st.bl_tree[2*R[ft]+1]===0;ft--);return st.opt_len+=3*(ft+1)+5+5+4,ft})($),V=$.opt_len+3+7>>>3,(Q=$.static_len+3+7>>>3)<=V&&(V=Q)):V=Q=K+5,K+4<=V&&M!==-1?_($,M,K,W):$.strategy===4||Q===V?(nt($,2+(W?1:0),3),T($,J,S)):(nt($,4+(W?1:0),3),(function(st,ft,xt,kt){var Mt;for(nt(st,ft-257,5),nt(st,xt-1,5),nt(st,kt-4,4),Mt=0;Mt<kt;Mt++)nt(st,st.bl_tree[2*R[Mt]+1],3);j(st,st.dyn_ltree,ft-1),j(st,st.dyn_dtree,xt-1)})($,$.l_desc.max_code+1,$.d_desc.max_code+1,lt+1),T($,$.dyn_ltree,$.dyn_dtree)),pt($),W&&X($)},o._tr_tally=function($,M,K){return $.pending_buf[$.d_buf+2*$.last_lit]=M>>>8&255,$.pending_buf[$.d_buf+2*$.last_lit+1]=255&M,$.pending_buf[$.l_buf+$.last_lit]=255&K,$.last_lit++,M===0?$.dyn_ltree[2*K]++:($.matches++,M--,$.dyn_ltree[2*(g[K]+m+1)]++,$.dyn_dtree[2*z(M)]++),$.last_lit===$.lit_bufsize-1},o._tr_align=function($){nt($,2,3),tt($,C,J),(function(M){M.bi_valid===16?(rt(M,M.bi_buf),M.bi_buf=0,M.bi_valid=0):8<=M.bi_valid&&(M.pending_buf[M.pending++]=255&M.bi_buf,M.bi_buf>>=8,M.bi_valid-=8)})($)}},{"../utils/common":41}],53:[function(e,n,o){n.exports=function(){this.input=null,this.next_in=0,this.avail_in=0,this.total_in=0,this.output=null,this.next_out=0,this.avail_out=0,this.total_out=0,this.msg="",this.state=null,this.data_type=2,this.adler=0}},{}],54:[function(e,n,o){(function(s){(function(l,r){if(!l.setImmediate){var a,c,u,m,v=1,d={},b=!1,f=l.document,y=Object.getPrototypeOf&&Object.getPrototypeOf(l);y=y&&y.setTimeout?y:l,a={}.toString.call(l.process)==="[object process]"?function(A){process.nextTick(function(){x(A)})}:(function(){if(l.postMessage&&!l.importScripts){var A=!0,B=l.onmessage;return l.onmessage=function(){A=!1},l.postMessage("","*"),l.onmessage=B,A}})()?(m="setImmediate$"+Math.random()+"$",l.addEventListener?l.addEventListener("message",C,!1):l.attachEvent("onmessage",C),function(A){l.postMessage(m+A,"*")}):l.MessageChannel?((u=new MessageChannel).port1.onmessage=function(A){x(A.data)},function(A){u.port2.postMessage(A)}):f&&"onreadystatechange"in f.createElement("script")?(c=f.documentElement,function(A){var B=f.createElement("script");B.onreadystatechange=function(){x(A),B.onreadystatechange=null,c.removeChild(B),B=null},c.appendChild(B)}):function(A){setTimeout(x,0,A)},y.setImmediate=function(A){typeof A!="function"&&(A=new Function(""+A));for(var B=new Array(arguments.length-1),I=0;I<B.length;I++)B[I]=arguments[I+1];var w={callback:A,args:B};return d[v]=w,a(v),v++},y.clearImmediate=k}function k(A){delete d[A]}function x(A){if(b)setTimeout(x,0,A);else{var B=d[A];if(B){b=!0;try{(function(I){var w=I.callback,D=I.args;switch(D.length){case 0:w();break;case 1:w(D[0]);break;case 2:w(D[0],D[1]);break;case 3:w(D[0],D[1],D[2]);break;default:w.apply(r,D)}})(B)}finally{k(A),b=!1}}}}function C(A){A.source===l&&typeof A.data=="string"&&A.data.indexOf(m)===0&&x(+A.data.slice(m.length))}})(typeof self>"u"?s===void 0?this:s:self)}).call(this,typeof Kn<"u"?Kn:typeof self<"u"?self:typeof window<"u"?window:{})},{}]},{},[10])(10)})})(Ko)),Ko.exports}var D1=M1();const L1=E1(D1),P1=/\.(?:png|jpe?g|gif|svg|webp|avif|ico|bmp|tiff?|mp4|webm|mp3|wav|ogg)$/i,R1=/\.(?:ts|js|mjs|cjs|jsx|tsx|vue|json|css|scss|less|html|py|rs|go|java|c|cpp|h|sh|bash|yaml|yml|toml)$/i;async function O1(t){const i=await L1.loadAsync(t),e={},n=[];let o="",s="";const l=[];i.forEach((a,c)=>{!c.dir&&!a.startsWith("__MACOSX")&&!a.includes("node_modules/")&&l.push({path:a,file:c})});let r=l.find(a=>a.path.toLowerCase()==="slides.md");r||(r=l.find(a=>a.path.toLowerCase().endsWith("/slides.md"))),r||(r=l.find(a=>a.path.toLowerCase().endsWith(".md"))),r&&(o=await r.file.async("string"),s=r.path);for(const a of l){const c=a.path;if(c.toLowerCase().endsWith(".md")||R1.test(c)||c.includes("snippets/")){const u=await a.file.async("string");e[c]=u;const m=c.split("/");m.length>1&&(e[m.slice(1).join("/")]=u)}else if(P1.test(c)){const u=await a.file.async("uint8array"),m=c.split("/").pop()||c,v=typeof Blob<"u"?new Blob([u]):void 0;n.push({zipPath:c,fileName:m,data:u,blob:v})}}return{entryMarkdown:o,entryMarkdownPath:s,virtualFiles:e,assets:n}}function z1(t,i){if(Object.keys(i).length===0)return t;function e(o){const s=o.trim().replace(/^['"]|['"]$/g,""),l=s.split("/").pop()||s;if(i[s])return i[s];const r=s.replace(/^\.?\//,"");return i[r]?i[r]:i[l]?i[l]:null}function n(o){let s=o;return s=s.replace(/!\[(.*?)\]\((.*?)\)/g,(l,r,a)=>{const c=e(a);return c?`![${r}](${c})`:l}),s=s.replace(/\bsrc=["'](.*?)["']/gi,(l,r)=>{const a=e(r);return a?`src="${a}"`:l}),s}for(const o of t.slides)if(o.rawMarkdown=n(o.rawMarkdown),o.pageAttrs["custom-slidev-background"]){const s=o.pageAttrs["custom-slidev-background"],l=e(s);l&&(o.pageAttrs["custom-slidev-background"]=l)}if(t.flattenedMarkdown=n(t.flattenedMarkdown),t.docRootAttrs["custom-slidev-background"]){const o=t.docRootAttrs["custom-slidev-background"],s=e(o);s&&(t.docRootAttrs["custom-slidev-background"]=s)}return t}function ua(t){try{if(typeof process<"u"&&typeof require<"u"){const i=require("fs");if(i.existsSync(t))return i.readFileSync(t,"utf-8")}}catch{}return null}function N1(t,i){const e=t.match(/^[ \t]*<<<[ \t]+([^\s]+)/);if(!e)return null;const n=e[1].trim(),o=n.indexOf("#"),s=o!==-1?n.slice(0,o):n,l=o!==-1?n.slice(o+1):"",r=s.replace(/^@\//,"").replace(/^\.\//,""),a=(i==null?void 0:i.virtualFiles)||{};let c=a[s]||a[r]||a[`./${r}`]||a[`@/${r}`];if(!c&&Object.keys(a).length>0){const d=r.split("/").pop();for(const[b,f]of Object.entries(a))if(b.endsWith(`/${r}`)||d&&b.endsWith(`/${d}`)){c=f;break}}if(!c){const d=[];if(i!=null&&i.baseDir)try{const b=require("path");d.push(b.resolve(i.baseDir,r)),d.push(b.resolve(i.baseDir,s))}catch{}try{const b=require("path");d.push(b.resolve(process.cwd(),r))}catch{}for(const b of d){const f=ua(b);if(f!==null){c=f;break}}}if(!c){const d=na||{};if(c=d[s]||d[r]||d[`snippets/${r}`],!c){const b=r.split("/").pop();for(const[f,y]of Object.entries(d))if(f.endsWith(`/${r}`)||b&&f.endsWith(`/${b}`)){c=y;break}}}if(!c)return null;let u=c;if(l){const d=new RegExp(`(?:\\/\\/|\\/\\*|#)?\\s*#(?:region|REGION)\\s+${l}[^\\r\\n]*\\r?\\n([\\s\\S]*?)(?:\\/\\/|\\/\\*|#)?\\s*#(?:endregion|ENDREGION)\\s+${l}`,"i"),b=c.match(d);if(b){const f=c.match(/^(\/\/\s*Inside[^\r\n]+\r?\n)/i);u=(f?f[1]:"")+b[1].trimEnd()}}const m=r.match(/\.([a-zA-Z0-9]+)$/);return`\`\`\`${m?m[1]:""}
${u}
\`\`\``}function F1(t){let i=!1,e=!1;for(let n=0;n<t.length;n++){const o=t[n];if(o==="'"&&!e)i=!i;else if(o==='"'&&!i)e=!e;else if(o==="#"&&!i&&!e)return t.slice(0,n).trim()}return t.trim()}function Xn(t){const i={},e=t.split(/\r?\n/);let n=0;for(;n<e.length;){const o=e[n],s=o.trim();if(!s||s.startsWith("#")){n++;continue}const l=o.indexOf(":");if(l>0){const r=o.slice(0,l).trim();let a=o.slice(l+1).trim();if(a==="|"||a===">"){n++;const c=[];let u=-1;for(;n<e.length;){const m=e[n];if(!m.trim()){c.push(""),n++;continue}const d=m.match(/^(\s+)/),b=d?d[1].length:0;if(u===-1&&(u=b),b<u)break;c.push(m.slice(u)),n++}for(;c.length>0&&c[c.length-1]==="";)c.pop();i[r]=a===">"?c.join(" "):c.join(`
`);continue}if(a=F1(a),!a){let c=n+1;const u=[];let m=-1;for(;c<e.length;){const v=e[c],d=v.trim();if(!d||d.startsWith("#")){m!==-1&&u.push(""),c++;continue}const b=v.match(/^(\s+)/),f=b?b[1].length:0;if(m===-1)if(f>0)m=f;else break;if(f<m)break;u.push(v.slice(m)),c++}if(u.length>0){i[r]=Xn(u.join(`
`)),n=c;continue}}a.startsWith('"')&&a.endsWith('"')||a.startsWith("'")&&a.endsWith("'")?a=a.slice(1,-1):a==="true"?a=!0:a==="false"?a=!1:a==="null"?a=null:/^-?\d+(?:\.\d+)?$/.test(a)&&(a=Number(a)),i[r]=a}n++}return i}const H1=/^\s*```ya?ml([\s\S]*?)```/;function Er(t){let i={},e=t.trim();const n=e.match(/^---[^\n\r]*\r?\n([\s\S]*?)\r?\n---(?=[ \t]*(?:\r?\n|$))/);if(n&&!n[1].includes("```")){const s=Xn(n[1]);if(Object.keys(s).length>0||!n[1].trim())return i=s,e=e.slice(n[0].length).trim(),{frontmatter:i,content:e}}if(e.startsWith("---")){const s=e.match(/^---[^\n\r]*(?:\r?\n|$)/);s&&(e=e.slice(s[0].length).trim())}const o=e.match(H1);if(o)i=Xn(o[1]),e=e.slice(o[0].length).trim();else{const s=e.split(/\r?\n/),l=[];let r=0;for(let a=0;a<s.length;a++){const c=s[a].trim();if(!c){if(l.length>0){r=a+1;break}continue}if(/^[a-zA-Z0-9_-]+\s*:\s*.*/.test(c)&&!c.startsWith("<")&&!c.startsWith("#"))l.push(c);else{r=a;break}}l.length>0&&(i=Xn(l.join(`
`)),e=s.slice(r).join(`
`).trim())}return{frontmatter:i,content:e}}function j1(t){const i=t.split(/\r?\n/),e=[];let n=0,o=!1;function s(l){if(n>=l)return;const r=i.slice(n,l).join(`
`).trim();r&&e.push(r),n=l+1}for(let l=0;l<i.length;l++){const a=i[l].trimEnd();if(o){a.includes("-->")&&(o=!1);continue}if(a.startsWith("<!--")){a.includes("-->")||(o=!0);continue}if(a.startsWith("---")){s(l);const c=i[l+1];if(c&&c.trim()&&a.replace(/^-+/,"").trim()==="")for(n=l,l+=1;l<i.length&&i[l].trimEnd()!=="---";l++);}else if(a.trimStart().startsWith("```")){const c=a.match(/^\s*`+/),u=c?c[0].trim():"```";let m=l+1;for(;m<i.length&&!i[m].trimStart().startsWith(u);m++);m<i.length&&(l=m)}}return n<i.length&&s(i.length),e}function Qn(t,i={}){const{stripNotesFromMarkdown:e=!0,cleanVClicks:n=!0,cleanShikiLines:o=!0,cleanSlots:s=!0,isolateStyleTags:l=!0,cleanHtmlToMarkdown:r=!0,wrapSuperBlocks:a=!0,virtualFiles:c={}}=i;let u=t;u&&!u.trimStart().startsWith("---")&&(u=`---

${u.trimStart()}`);const m=j1(u),v={};let d="",b="",f=0;if(m.length>0){const R=m[0],J=Er(R),S=Object.keys(J.frontmatter).length>0,H=J.content.length>0;S&&!H&&m.length>1?(f=1,y(J.frontmatter)):S&&y(J.frontmatter)}function y(R){d=R.title||"",R.theme&&(v[kn]=String(R.theme)),R.aspectRatio&&(v[wn]=String(R.aspectRatio)),R.highlighter&&(v[zr]=String(R.highlighter)),R.transition&&(v[xn]=String(R.transition)),R.colorSchema&&(v[Nr]=String(R.colorSchema)),R.layout&&(v[mt]=String(R.layout)),R.background&&(v[jt]=String(R.background)),R.image&&(v[Ee]=String(R.image)),R.class&&(v[Wi]=String(R.class));for(const[J,S]of Object.entries(R))["theme","aspectRatio","highlighter","transition","colorSchema","title","layout","background","image","class"].includes(J)||(v[`custom-slidev-${J}`]=typeof S=="object"?JSON.stringify(S):String(S))}const k=[];let x=0,C=0,A=0,B=0;const I=new Set,w={};let D=1;for(let R=f;R<m.length;R++){const J=m[R],{frontmatter:S,content:H}=Er(J),g=J.match(/^\s*(?:---\s*)?src:\s*([^\n\r]+)/m),N=S.src||(g?g[1]:void 0);if(N){const X=String(N).trim().replace(/^['"]|['"]$/g,"");let dt=c[X]||c[X.replace(/^\.\//,"")]||c[`pages/${X.replace(/^.*pages\//,"")}`];if(!dt){const T=X.replace(/^\.\//,""),F=[];if(i.baseDir)try{const p=require("path");F.push(p.resolve(i.baseDir,T)),F.push(p.resolve(i.baseDir,X))}catch{}try{const p=require("path");F.push(p.resolve(process.cwd(),T)),F.push(p.resolve(process.cwd(),X))}catch{}for(const p of F){const j=ua(p);if(j!==null){dt=j;break}}}const bt={};S.layout&&(bt[mt]=String(S.layout)),S.transition&&(bt[Xt]=String(S.transition)),S.background&&(bt[jt]=String(S.background)),S.image&&(bt[Ee]=String(S.image)),S.class&&(bt[Wi]=String(S.class));for(const[T,F]of Object.entries(S))["src","layout","transition","background","image","class"].includes(T)||(bt[`custom-slidev-${T}`]=typeof F=="object"?JSON.stringify(F):String(F));if(dt){const T=Qn(dt,{...i,virtualFiles:c});for(const F of T.slides){F.pageIndex=D++,F.pageAttrs={...bt,...F.pageAttrs},k.push(F);const p=F.pageAttrs[mt]||"default";w[p]=(w[p]||0)+1}continue}else{k.push({pageIndex:D++,pageAttrs:{...bt,"custom-slidev-src":X},notes:"",rawMarkdown:`> 📄 **引入外部幻灯片页面**: \`${X}\`
>
> *提示：如需展示该页面完整内容，请将关联子页面一同打包为 .zip 或通过本地工程导入。*`,hasVueComponent:!1,hasStyleTag:!1,assetReferences:[]});const T=bt[mt]||"default";w[T]=(w[T]||0)+1;continue}}const q={};S.layout&&(q[mt]=String(S.layout)),S.transition&&(q[Xt]=String(S.transition)),S.background&&(q[jt]=String(S.background)),S.image&&(q[Ee]=String(S.image)),S.class&&(q[Wi]=String(S.class));for(const[X,dt]of Object.entries(S))["layout","transition","background","image","class"].includes(X)||(q[`custom-slidev-${X}`]=typeof dt=="object"?JSON.stringify(dt):String(dt));let U=H;const G=[];let Z=U.replace(/(?:^[ \t]*(`{3,}|~{3,})[^\n\r]*\r?\n[\s\S]*?\r?\n[ \t]*\1(?=[ \t]*(?:\r?\n|$)))/gm,X=>{const dt=`__CODE_TOKEN_NOTE_${G.length}__`;return G.push(X),dt});Z=Z.replace(/(`+)(?:[^\n\r`]|(?!\1)`)+?\1/g,X=>{const dt=`__CODE_TOKEN_NOTE_${G.length}__`;return G.push(X),dt});let O="";const E=Array.from(Z.matchAll(/<!--([\s\S]*?)-->/g));if(E.length>0){const X=E[E.length-1],dt=Z.slice(X.index+X[0].length).trim();if(!dt||!dt.replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi,"").trim()){const T=X[1].trim();T.startsWith("TODO:")||(O=T,x++),e&&(Z=Z.slice(0,X.index).trimEnd()+Z.slice(X.index+X[0].length))}}e&&(Z=Z.replace(/<!--(?![\s\S]*?TODO:)[\s\S]*?-->/g,"").trim());for(let X=0;X<G.length;X++)Z=Z.replace(`__CODE_TOKEN_NOTE_${X}__`,G[X]);if(U=Z,O){for(let bt=0;bt<G.length;bt++)O=O.replace(`__CODE_TOKEN_NOTE_${bt}__`,G[bt]);const dt=`> [!NOTE] 💡 演讲备注
${O.split(/\r?\n/).map(bt=>`> ${bt}`).join(`
`)}
{: custom-slidev-note="true"}`;U=U?`${U}

${dt}`:dt}let z=!1;if(/<style\b/i.test(U)){z=!0;const X=U.match(/<style\b[^>]*>([\s\S]*?)<\/style>/gi);if(X){for(const dt of X){const bt=dt.replace(/<style\b[^>]*>|<\/style>/gi,"").trim();b=b?`${b}

${bt}`:bt}l&&(U=U.replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi,"").trim())}}const rt=U.match(/<v-click[^>]*>|<v-clicks[^>]*>|v-click=/g);rt&&(C+=rt.length);const nt=U.match(/```\w+\s+\{[^}]+\}/g);nt&&(A+=nt.length);const tt=U.match(/::\w+::|<template\s+#[^>]+>/g);if(tt&&(B+=tt.length),U=U.replace(/^[ \t]*<<<[ \t]+([^\n\r]+)/gm,X=>N1(X,{...i,virtualFiles:c})||X),n&&(U=U.replace(/<v-click(?:\s+at="[^"]*")?(?:\s+hide)?>\s*([\s\S]*?)\s*<\/v-click>/gi,"$1")),o&&(U=U.replace(/(^```\w+(?:[ \t]+\[[^\]]*\])?)[ \t]+\{[^}]+\}(?:[ \t]+\w+)?/gm,"$1"),U=U.replace(/^\$\$\s+\{[^}]+\}/gm,()=>"$$")),s&&(U=U.replace(/^::\w+::\s*$/gm,"")),r&&(U=Fu(U)),a){let X=U.trim(),dt="";const bt=X.lastIndexOf("> [!NOTE] 💡 演讲备注");if(bt!==-1&&(dt=X.slice(bt),X=X.slice(0,bt).trim()),(S.layout==="image-left"||S.layout==="image-right")&&S.image){const T=String(S.image).trim(),F=S.layout==="image-left"?"image-left":"image-right",p=`![配图](${T})
{: custom-slidev-layout="${F}" }`;S.layout==="image-left"?X=`{{{col

${p}

${X}

}}}`:X=`{{{col

${X}

${p}

}}}`}if(S.background){const F=`![背景图](${String(S.background).trim()})
{: custom-slidev-role="background" }`;X=X?`${F}

${X}`:F}U=dt?`${X}

${dt}`:X}const Y=U1(U);q[jt]&&Y.push(q[jt]),q[Ee]&&Y.push(q[Ee]);for(const X of Y)I.add(X);const ct=/<[A-Z][a-zA-Z0-9]+/.test(U),pt=q[mt]||(D===1?v[mt]||"cover":"default");w[pt]=(w[pt]||0)+1,k.push({pageIndex:D++,pageAttrs:q,notes:O,rawMarkdown:U,hasVueComponent:ct,hasStyleTag:z,assetReferences:Y})}if(!d&&k.length>0){const R=k[0].rawMarkdown.match(/^#\s+(.+)$/m);R&&(d=R[1].trim())}b&&(v["custom-slidev-custom-css"]=b);let P=k.map(R=>`---

${R.rawMarkdown}`).join(`

`);return P.trimStart().startsWith("---")||(P=`---

${P.trimStart()}`),{docTitle:d||"Slidev 演示文稿",docRootAttrs:v,slides:k,totalSlides:k.length,stats:{totalNotes:x,totalVClicks:C,totalShikiHighlights:A,totalSlots:B,discoveredAssets:Array.from(I),layoutDistribution:w},flattenedMarkdown:P,customCss:b}}function U1(t){const i=[],e=/!\[.*?\]\((.*?)\)/g;let n;for(;(n=e.exec(t))!==null;){const s=n[1].split(/\s+/)[0].trim();s&&i.push(s)}const o=/<(?:img|video|source|audio)\b[^>]*src=["'](.*?)["']/gi;for(;(n=o.exec(t))!==null;){const s=n[1].trim();s&&i.push(s)}return i}function fa(t){if(!t)return!1;const i=String(t.type||"").toLowerCase(),e=String(t.markdown||"").trim(),n=String(t.content||"").trim();return i==="tb"||i==="thematic-break"||i==="nodethematicbreak"||e==="---"||e==="***"||n==="---"||n==="***"}function W1(t){return(t.trim()||"Slidev 演示文稿").replace(/[\\/:*?"<>|]/g,"_")}async function V1(t,i,e=Lt){const n=t.filter(fa);let o=0;if(n.length>=i.length)for(let s=0;s<i.length;s++){const l=i[s],r=n[s];r&&r.id&&Object.keys(l.pageAttrs||{}).length>0&&(await e(r.id,l.pageAttrs),o++)}else for(let s=1;s<i.length;s++){const l=i[s],r=n[s-1];r&&r.id&&Object.keys(l.pageAttrs||{}).length>0&&(await e(r.id,l.pageAttrs),o++)}return o}async function q1(t,i=Lt){let e=!1,n=0;for(const o of t){if(fa(o)){e=!1;continue}const s=(o.markdown||o.content||"").trim();if(s==="::right::"||s.startsWith("::right::")){e=!0;continue}e&&o.id&&(await i(o.id,{[Bt]:"right"}).catch(()=>{}),n++)}return n}async function K1(t,i,e=Pr){const n={};if(!i||i.length===0)return n;const o=[];for(const s of i){const l=new File([s.data],s.fileName,{type:"application/octet-stream"});o.push(l)}try{const s=await e("/data/assets",o);if(s!=null&&s.succMap)for(const[l,r]of Object.entries(s.succMap))n[l]=String(r)}catch(s){console.warn("上传本地静态资产失败，保留原路径:",s)}return Object.keys(n).length>0&&z1(t,n),n}async function G1(t){var A;const{presentation:i,notebookId:e,docTitle:n,extractedAssets:o=[],uploadAssets:s=!0,autoPreview:l=!0,plugin:r,api:a={}}=t,c=a.uploadFn||Pr,u=a.createDocFn||Ga,m=a.setAttrsFn||Lt,v=a.getChildBlocksFn||eo,d=a.openTabFn||ht.openTab,b=a.showMessageFn||ht.showMessage;s&&o.length>0&&await K1(i,o,c);const f=W1(n),y=`/${f}`,k=await u(e,y,i.flattenedMarkdown);if(!k)throw new Error("思源内核创建文档失败，未返回有效 DocumentId");const x=((A=i.slides[0])==null?void 0:A.pageAttrs)||{};await m(k,{...x,...i.docRootAttrs});const C=await v(k).catch(()=>[]);return Array.isArray(C)&&C.length>0&&(await V1(C,i.slides,m),await q1(C,m)),b(`🎉 成功导入 Slidev 演示文档《${f}》！`),l&&r&&(r.currentDocId=k,await d({app:r.app,doc:{id:k}}),r.openBottomPreviewTab&&r.openBottomPreviewTab()),k}function Z1(t){const i=gt("file"),e=gt(!1),n=gt(!1),o=gt(""),s=gt(null),l=gt(null),r=gt(""),a=gt(0),c=gt(""),u=gt([]),m=gt(null),v=gt(""),d=gt([]),b=gt(""),f=gt(!0),y=gt(!0),k=gt(!0),x=gt(!0),C=_t(()=>{const q=a.value;if(q===0)return"0 B";const U=1024,G=["B","KB","MB","GB"],Z=Math.floor(Math.log(q)/Math.log(U));return`${(q/U**Z).toFixed(1)} ${G[Z]}`}),A=_t(()=>{var q;return((q=m.value)==null?void 0:q.docRootAttrs["custom-slidev-theme"])||"default"}),B=_t(()=>{var q;return u.value.length>0?u.value.length:((q=m.value)==null?void 0:q.stats.discoveredAssets.length)||0}),I=_t(()=>{var U;const q=((U=m.value)==null?void 0:U.stats.layoutDistribution)||{};return Object.entries(q).map(([G,Z])=>({name:G,count:Z}))});async function w(q=Ka){try{const U=await q();U!=null&&U.notebooks&&Array.isArray(U.notebooks)&&(d.value=U.notebooks.filter(G=>!G.closed),d.value.length>0&&!b.value&&(b.value=d.value[0].id))}catch(U){console.warn("获取笔记本列表失败:",U)}}function D(){var q;(q=s.value)==null||q.click()}function P(){l.value=null,r.value="",a.value=0,m.value=null,u.value=[],o.value=""}async function R(q){o.value="",l.value=q,r.value=q.name,a.value=q.size;try{if(q.name.toLowerCase().endsWith(".zip")){const G=await q.arrayBuffer(),Z=await O1(G);if(!Z.entryMarkdown){o.value="未在 Zip 压缩包中找到 slides.md 或任何有效的 Markdown 入口文件";return}u.value=Z.assets;const O=Qn(Z.entryMarkdown,{stripNotesFromMarkdown:y.value,cleanHtmlToMarkdown:f.value,cleanSlots:!1,virtualFiles:Z.virtualFiles});m.value=O,v.value=O.docTitle||q.name.replace(/\.zip$/i,"")}else{const G=await q.text();u.value=[];const Z=q.path||"",O=Z?Z.replace(/[\\/][^\\/]+$/,""):"",E=Qn(G,{stripNotesFromMarkdown:y.value,cleanHtmlToMarkdown:f.value,cleanSlots:!1,baseDir:O||void 0});m.value=E,v.value=E.docTitle||q.name.replace(/\.md$/i,"")}}catch(U){console.error("解析文件失败:",U),o.value=`解析文件失败: ${U.message||String(U)}`}}function J(){if(o.value="",!c.value.trim()){m.value=null;return}try{const q=Qn(c.value,{stripNotesFromMarkdown:y.value,cleanHtmlToMarkdown:f.value,cleanSlots:!1});m.value=q,v.value=q.docTitle||"Slidev 演示文稿"}catch(q){o.value=`解析 Markdown 源码失败: ${q.message||String(q)}`}}async function S(){l.value?await R(l.value):c.value&&J()}async function H(q){const U=q.target;U.files&&U.files[0]&&await R(U.files[0])}async function g(q){var U;e.value=!1,(U=q.dataTransfer)!=null&&U.files&&q.dataTransfer.files[0]&&await R(q.dataTransfer.files[0])}async function N(q=t){if(m.value){if(!b.value&&d.value.length>0&&(b.value=d.value[0].id),!b.value){o.value="请先选择目标笔记本";return}n.value=!0,o.value="";try{return await G1({presentation:m.value,notebookId:b.value,docTitle:v.value,extractedAssets:u.value,uploadAssets:k.value,autoPreview:x.value,plugin:q})}catch(U){console.error("导入 Slidev 演示失败:",U),o.value=`导入执行失败: ${U.message||String(U)}`}finally{n.value=!1}}}return{inputMode:i,isDragging:e,isImporting:n,errorMessage:o,fileInputRef:s,selectedFile:l,selectedFileName:r,selectedFileSize:a,rawMarkdownText:c,extractedAssets:u,parsedPresentation:m,customDocTitle:v,notebooks:d,selectedNotebookId:b,optCleanHtml:f,optStripNotes:y,optUploadAssets:k,optAutoPreview:x,formattedFileSize:C,currentTheme:A,extractedAssetsCount:B,layoutChips:I,fetchNotebooks:w,triggerFileInput:D,clearFile:P,processFile:R,onFileSelected:H,onFileDrop:g,onTextChange:J,reprocessCurrentInput:S,handleConfirmImport:N}}const Y1={class:"spm-import-dialog"},J1={class:"spm-tabs-header"},X1={class:"spm-dialog-body"},Q1={key:0,class:"spm-file-section"},tb={key:0,class:"spm-dropzone-prompt"},eb={class:"spm-dropzone-icon"},ib={key:1,class:"spm-dropzone-active"},nb={class:"spm-file-badge"},ob={class:"spm-file-size"},sb={key:1,class:"spm-text-section"},rb={key:2,class:"spm-error-banner"},lb={key:3,class:"spm-preview-card"},ab={class:"spm-preview-card__header"},cb={style:{display:"inline-flex","align-items":"center",gap:"4px"}},db={class:"spm-config-grid"},ub={class:"spm-form-item"},fb={class:"spm-form-item"},pb=["value"],hb={class:"spm-stats-grid"},mb={class:"spm-stat-box"},gb={class:"spm-stat-value"},vb={class:"spm-stat-box"},bb={class:"spm-stat-value"},yb={class:"spm-stat-box"},kb={class:"spm-stat-value"},wb={class:"spm-stat-box"},xb={class:"spm-stat-value"},_b={key:0,class:"spm-chips-row"},Sb={class:"spm-options-group"},Cb={class:"spm-checkbox-label"},$b={class:"spm-checkbox-label"},Ib={class:"spm-checkbox-label"},Ab={class:"spm-checkbox-label"},Bb={class:"spm-dialog-footer"},Tb=["disabled"],Eb=["disabled"],Mb={key:0,style:{display:"inline-flex","align-items":"center",gap:"4px"}},Db={key:1,style:{display:"inline-flex","align-items":"center",gap:"4px"}},Lb=_e({__name:"SlidevImportDialog",emits:["close","success"],setup(t,{emit:i}){const e=i,n=ti("plugin"),{inputMode:o,isDragging:s,isImporting:l,errorMessage:r,fileInputRef:a,selectedFileName:c,rawMarkdownText:u,extractedAssetsCount:m,parsedPresentation:v,customDocTitle:d,notebooks:b,selectedNotebookId:f,optCleanHtml:y,optStripNotes:k,optUploadAssets:x,optAutoPreview:C,formattedFileSize:A,currentTheme:B,layoutChips:I,fetchNotebooks:w,triggerFileInput:D,clearFile:P,onFileSelected:R,onFileDrop:J,onTextChange:S,reprocessCurrentInput:H,handleConfirmImport:g}=Z1(n);Pn(async()=>{await w()});async function N(){const U=await g();U&&(e("success",{docId:U}),e("close"))}function q(){e("close")}return(U,G)=>(et(),it("div",{class:"spm-modal-overlay",onClick:Me(q,["self"])},[h("div",Y1,[h("div",{class:"spm-dialog-header"},[G[18]||(G[18]=h("div",{class:"spm-dialog-title"},[h("svg",{class:"spm-dialog-icon","aria-hidden":"true"},[h("use",{"xlink:href":"#iconSlidev"})]),h("span",null,"导入 Slidev 演示文档")],-1)),h("button",{class:"spm-close-btn",title:"关闭",onClick:q},"✕")]),h("div",J1,[h("button",{class:It(["spm-tab-btn",{active:vt(o)==="file"}]),onClick:G[0]||(G[0]=Z=>o.value="file")},[at(ut,{name:"package"}),G[19]||(G[19]=h("span",null,"文件 / 压缩包导入 (.zip / .md)",-1))],2),h("button",{class:It(["spm-tab-btn",{active:vt(o)==="text"}]),onClick:G[1]||(G[1]=Z=>o.value="text")},[at(ut,{name:"notes"}),G[20]||(G[20]=h("span",null,"粘贴 Markdown 源码",-1))],2)]),h("div",X1,[vt(o)==="file"?(et(),it("div",Q1,[h("div",{class:It(["spm-dropzone",{dragover:vt(s),"has-file":!!vt(c)}]),onDragover:G[4]||(G[4]=Me(Z=>s.value=!0,["prevent"])),onDragleave:G[5]||(G[5]=Me(Z=>s.value=!1,["prevent"])),onDrop:G[6]||(G[6]=Me((...Z)=>vt(J)&&vt(J)(...Z),["prevent"])),onClick:G[7]||(G[7]=(...Z)=>vt(D)&&vt(D)(...Z))},[h("input",{ref_key:"fileInputRef",ref:a,type:"file",accept:".zip,.md",class:"spm-hidden-input",onChange:G[2]||(G[2]=(...Z)=>vt(R)&&vt(R)(...Z))},null,544),vt(c)?(et(),it("div",ib,[h("span",nb,[at(ut,{name:"notes"}),Ie(" "+St(vt(c)),1)]),h("span",ob,"("+St(vt(A))+")",1),h("button",{class:"spm-btn-text",onClick:G[3]||(G[3]=Me((...Z)=>vt(P)&&vt(P)(...Z),["stop"]))},"更换文件")])):(et(),it("div",tb,[h("span",eb,[at(ut,{name:"folder",style:{"font-size":"32px"}})]),G[21]||(G[21]=h("p",{class:"spm-dropzone-text"},"点击选择文件，或直接拖拽文件至此处",-1)),G[22]||(G[22]=h("p",{class:"spm-dropzone-hint"},[Ie(" 支持 Slidev 完整工程 "),h("strong",null,".zip"),Ie("（自动解包 public/ 静态素材）或单文件 "),h("strong",null,".md")],-1))]))],34)])):(et(),it("div",sb,[Te(h("textarea",{"onUpdate:modelValue":G[8]||(G[8]=Z=>Zt(u)?u.value=Z:null),class:"spm-textarea spm-source-editor",rows:"8",placeholder:"在此直接粘贴包含 Frontmatter 的 Slidev slides.md 源码...",onInput:G[9]||(G[9]=(...Z)=>vt(S)&&vt(S)(...Z))},null,544),[[mo,vt(u)]])])),vt(r)?(et(),it("div",rb," ⚠️ "+St(vt(r)),1)):Rt("",!0),vt(v)?(et(),it("div",lb,[h("div",ab,[h("span",cb,[at(ut,{name:"sparkles"}),G[23]||(G[23]=Ie(" 演示解析摘要",-1))]),G[24]||(G[24]=h("span",{class:"spm-badge-success"},"预检就绪",-1))]),h("div",db,[h("div",ub,[G[25]||(G[25]=h("label",{class:"spm-form-label"},"笔记文档标题",-1)),Te(h("input",{"onUpdate:modelValue":G[10]||(G[10]=Z=>Zt(d)?d.value=Z:null),class:"spm-input",placeholder:"思源新文档标题"},null,512),[[mo,vt(d)]])]),h("div",fb,[G[26]||(G[26]=h("label",{class:"spm-form-label"},"存放目标笔记本",-1)),Te(h("select",{"onUpdate:modelValue":G[11]||(G[11]=Z=>Zt(f)?f.value=Z:null),class:"spm-select"},[(et(!0),it(qt,null,we(vt(b),Z=>(et(),it("option",{key:Z.id,value:Z.id},St(Z.name),9,pb))),128))],512),[[ku,vt(f)]])])]),h("div",hb,[h("div",mb,[h("span",gb,St(vt(v).totalSlides),1),G[27]||(G[27]=h("span",{class:"spm-stat-label"},"幻灯片页数",-1))]),h("div",vb,[h("span",bb,St(vt(B)),1),G[28]||(G[28]=h("span",{class:"spm-stat-label"},"演示主题",-1))]),h("div",yb,[h("span",kb,St(vt(v).stats.totalNotes),1),G[29]||(G[29]=h("span",{class:"spm-stat-label"},"演讲者提词",-1))]),h("div",wb,[h("span",xb,St(vt(m)),1),G[30]||(G[30]=h("span",{class:"spm-stat-label"},"关联本地素材",-1))])]),vt(I).length>0?(et(),it("div",_b,[G[31]||(G[31]=h("span",{class:"spm-chips-label"},"页面版式分布：",-1)),(et(!0),it(qt,null,we(vt(I),Z=>(et(),it("span",{key:Z.name,class:"spm-chip-badge"},St(Z.name)+": "+St(Z.count),1))),128))])):Rt("",!0),h("div",Sb,[h("label",Cb,[Te(h("input",{"onUpdate:modelValue":G[12]||(G[12]=Z=>Zt(y)?y.value=Z:null),type:"checkbox",onChange:G[13]||(G[13]=(...Z)=>vt(H)&&vt(H)(...Z))},null,544),[[qn,vt(y)]]),G[32]||(G[32]=h("span",null,"智能剥离展示型 HTML 容器为干净原生的 Markdown 笔记块",-1))]),h("label",$b,[Te(h("input",{"onUpdate:modelValue":G[14]||(G[14]=Z=>Zt(k)?k.value=Z:null),type:"checkbox",onChange:G[15]||(G[15]=(...Z)=>vt(H)&&vt(H)(...Z))},null,544),[[qn,vt(k)]]),G[33]||(G[33]=h("span",null,"提取演讲者提词到块属性并保持正文笔记清爽",-1))]),h("label",Ib,[Te(h("input",{"onUpdate:modelValue":G[16]||(G[16]=Z=>Zt(x)?x.value=Z:null),type:"checkbox"},null,512),[[qn,vt(x)]]),G[34]||(G[34]=h("span",null,"自动上传关联素材至思源资产库并重写路径 (assets/...)",-1))]),h("label",Ab,[Te(h("input",{"onUpdate:modelValue":G[17]||(G[17]=Z=>Zt(C)?C.value=Z:null),type:"checkbox"},null,512),[[qn,vt(C)]]),G[35]||(G[35]=h("span",null,"导入后自动打开新文档并开启下方分屏放映预览",-1))])])])):Rt("",!0)]),h("div",Bb,[h("button",{class:"spm-btn-secondary",disabled:vt(l),onClick:q}," 取消 ",8,Tb),h("button",{class:"spm-btn-primary",disabled:!vt(v)||vt(l),onClick:N},[vt(l)?(et(),it("span",Mb,[at(ut,{name:"refresh"}),G[36]||(G[36]=Ie(" 正在导入生成中...",-1))])):(et(),it("span",Db,[at(ut,{name:"rocket"}),G[37]||(G[37]=Ie(" 确认导入思源笔记",-1))]))],8,Eb)])])]))}}),Pb=ze(Lb,[["__scopeId","data-v-ce8dffdc"]]);function pa(t){return t?t==="NodeThematicBreak"||t==="tb"||t==="thematic-break":!1}function Rb(t,i){var r;if(!t||t.length===0)return null;const e=i.activeBlockId||"",n=i.currentTopBlockId||e,o=i.currentPageDividerId||"",s=i.activeBlockType||"";if(pa(s)&&e){let a=t.find(c=>c.startBlockId===e);if(a||(a=t.find(c=>{var u,m;return((m=(u=c.blocks)==null?void 0:u[0])==null?void 0:m.id)===e}),a)||(a=t.find(c=>{var u;return(u=c.allBlockIds)==null?void 0:u.includes(e)}),a))return a}if(o){let a=t.find(c=>c.startBlockId===o);if(a||(a=t.find(c=>{var u,m;return((m=(u=c.blocks)==null?void 0:u[0])==null?void 0:m.id)===o}),a))return a}if(e){let a=t.find(u=>u.startBlockId===e);if(a||(a=t.find(u=>{var m,v;return((m=u.blocks)==null?void 0:m.some(d=>d.id===e))||((v=u.allBlockIds)==null?void 0:v.includes(e))}),a)||n&&n!==e&&(a=t.find(u=>{var m,v;return((m=u.blocks)==null?void 0:m.some(d=>d.id===n))||((v=u.allBlockIds)==null?void 0:v.includes(n))}),a)||(a=t.find(u=>{var m;return(m=u.noteBlocks)==null?void 0:m.some(v=>v.id===e||v.id===n)}),a))return a;const c=(r=i.activeBlockAttrs)==null?void 0:r[Bt];if(c&&["col-1","col-2","col-3"].includes(c)&&(a=t.find(u=>{var m,v;return((m=u.frontmatter)==null?void 0:m.layout)==="three-cols-header"||((v=u.blocks)==null?void 0:v.some(d=>d.slot==="col-1"||d.slot==="col-2"||d.slot==="col-3"))}),a))return a}return t[0]||null}function Mr(t,i){const e=(t.blocks||[]).filter(l=>{const r=(l.content||l.rawMarkdown||"").trim();return r&&r!=="---"});if(e.length===0)return"本页暂无内容，建议过渡承接上下文。";const n=[],o=[];for(const l of e){const r=(l.content||l.rawMarkdown||"").trim();r&&(l.type==="h"||r.startsWith("#")?n.push(r.replace(/^#+\s*/,"")):o.push(r.slice(0,50)))}const s=[];return n.length>0&&s.push(`【核心重点】：${n.join("、")}`),o.length>0&&(s.push("【口播要点】："),o.slice(0,3).forEach((l,r)=>{s.push(`${r+1}. 讲解 ${l}`)})),s.push("【过渡提示】：注意观察听众反应，适时抛出互动提问。"),s.join(`
`)}async function ha(t,i){const e=t.blocks&&t.blocks.length>0?t.blocks.map(n=>(n.content||n.rawMarkdown||"").trim()).filter(n=>n&&n!=="---").join(`
`):(t.rawMarkdown||"").replace(/^---\s*$/gm,"").trim();if(i&&e){const n=`你是一位专业的演讲教练。请根据以下幻灯片内容，提炼出简短精炼的演讲口播提词卡（Notes），包含核心观点与口播要点，总字数在 150 字以内：
${e}`;try{const o=await i(n);if(o&&o.trim())return{notes:o.trim(),isAiGenerated:!0}}catch(o){return{notes:Mr(t),isAiGenerated:!1,error:(o==null?void 0:o.message)||"AI 调用异常"}}}return{notes:Mr(t),isAiGenerated:!1}}async function Ob(t,i){return(await ha(t,i)).notes}function zb(t){const i=gt(!1);let e=null;function n(O="已同步"){t.saveStatus.value=O,e&&(typeof window<"u"?window.clearTimeout(e):clearTimeout(e));const E=()=>{t.saveStatus.value=""};typeof window<"u"?e=window.setTimeout(E,1200):e=setTimeout(E,1200)}async function o(O){const E=t.activeBlockId.value||t.currentDocId.value;if(E){for(const[z,rt]of Object.entries(O))t.activeBlockAttrs.value[z]=rt;if(Pt.setBlockAttrOverride(E,O),ie(E,O),mt in O){const z=O[mt];t.currentPageDividerLayout.value=z,t.targetSlide.value&&(t.targetSlide.value.frontmatter||(t.targetSlide.value.frontmatter={}),t.targetSlide.value.frontmatter.layout=z)}if(oe in O){const z=O[oe];t.targetSlide.value&&(t.targetSlide.value.frontmatter||(t.targetSlide.value.frontmatter={}),t.targetSlide.value.frontmatter.layoutRatio=z)}n("保存中...");try{await Lt(E,O),n("已同步"),t.plugin&&await t.plugin.compileCurrentDocument()}catch{n("同步失败")}}}async function s(O,E){const z=t.activeBlockId.value||t.currentDocId.value;if(z){t.activeBlockAttrs.value[O]=E,Pt.setBlockAttrOverride(z,{[O]:E}),ie(z,{[O]:E}),O===mt&&(t.currentPageDividerLayout.value=E,t.targetSlide.value&&(t.targetSlide.value.frontmatter||(t.targetSlide.value.frontmatter={}),t.targetSlide.value.frontmatter.layout=E)),O===oe&&t.targetSlide.value&&(t.targetSlide.value.frontmatter||(t.targetSlide.value.frontmatter={}),t.targetSlide.value.frontmatter.layoutRatio=E),n("保存中...");try{await Lt(z,{[O]:E}),n("已同步"),t.plugin&&await t.plugin.compileCurrentDocument()}catch{n("同步失败")}}}function l(){const O=t.activeBlockType.value==="NodeThematicBreak"||t.activeBlockType.value==="NodeThematicBreakBlock"||t.activeBlockType.value==="hr"||t.activeBlockType.value==="thematicbreak";return t.currentPageDividerId.value||(O?t.activeBlockId.value:"")||t.currentDocId.value}async function r(O,E){const z=l();if(z){z===t.activeBlockId.value&&(t.activeBlockAttrs.value[O]=E),Pt.setBlockAttrOverride(z,{[O]:E}),ie(z,{[O]:E}),O===mt&&(t.currentPageDividerLayout.value=E,t.targetSlide.value&&(t.targetSlide.value.frontmatter||(t.targetSlide.value.frontmatter={}),t.targetSlide.value.frontmatter.layout=E)),O===oe&&t.targetSlide.value&&(t.targetSlide.value.frontmatter||(t.targetSlide.value.frontmatter={}),t.targetSlide.value.frontmatter.layoutRatio=E),n("保存中...");try{await Lt(z,{[O]:E}),n("已同步"),t.plugin&&await t.plugin.compileCurrentDocument()}catch{n("同步失败")}}}async function a(O,E){const z=l();if(!z)return;const rt={[mt]:O,[oe]:E};z===t.activeBlockId.value&&(t.activeBlockAttrs.value[mt]=O,t.activeBlockAttrs.value[oe]=E),t.currentPageDividerLayout.value=O,Pt.setBlockAttrOverride(z,rt),ie(z,rt),t.targetSlide.value&&(t.targetSlide.value.frontmatter||(t.targetSlide.value.frontmatter={}),t.targetSlide.value.frontmatter.layout=O,t.targetSlide.value.frontmatter.layoutRatio=E),n("应用排版中...");try{await Lt(z,rt),n("已应用分栏与比例"),t.plugin&&await t.plugin.compileCurrentDocument()}catch{n("应用失败")}}async function c(O,E){var rt;const z=t.currentDocId.value||t.activeBlockId.value;if(z){t.activeBlockAttrs.value[O]=E,Pt.setBlockAttrOverride(z,{[O]:E}),ie(z,{[O]:E}),(rt=t.latestDoc.value)!=null&&rt.config&&(O===kn&&(t.latestDoc.value.config.theme=E),O===wn&&(t.latestDoc.value.config.aspectRatio=E),O===xn&&(t.latestDoc.value.config.defaultTransition=E)),n("更新中...");try{await Lt(z,{[O]:E}),n("已更新"),t.plugin&&await t.plugin.compileCurrentDocument(z)}catch{n("更新失败")}}}async function u(){(t.videoAutoplay.value?"false":"true")==="true"?(await o({[Ti]:"true",[ji]:"true"}),t.activeBlockAttrs.value[Ti]="true",t.activeBlockAttrs.value[ji]="true"):(await s(Ti,"false"),t.activeBlockAttrs.value[Ti]="false")}async function m(){const O=t.videoLoop.value?"false":"true";await s(io,O)}async function v(){const O=t.videoMuted.value?"false":"true";await s(ji,O)}async function d(){const O=t.videoControls.value?"false":"true";await s(no,O)}async function b(O){var tt;const E=t.activeBlockId.value;if(!E)return;const z=t.rawSnippet.value||"",rt=vi(z)||"",nt=t.currentPageDividerId.value||t.currentDocId.value;if(O)if(O==="background"){const Y={[Vt]:"background",[mt]:""};nt&&rt&&(t.pageBackground.value=rt,await Lt(nt,{[jt]:rt}).catch(()=>{}),Pt.setBlockAttrOverride(nt,{[jt]:rt}),ie(nt,{[jt]:rt}),t.targetSlide.value&&(t.targetSlide.value.frontmatter||(t.targetSlide.value.frontmatter={}),t.targetSlide.value.frontmatter.background=rt)),await o(Y)}else(O===oo||O===so)&&await o({[mt]:O,[Vt]:""});else{const Y={[Vt]:"",[mt]:""};if(t.activeBlockAttrs.value[jt]==="true"&&(Y[jt]=""),nt&&rt&&t.pageBackground.value===rt&&(t.pageBackground.value="",await Lt(nt,{[jt]:""}).catch(()=>{}),Pt.setBlockAttrOverride(nt,{[jt]:""}),ie(nt,{[jt]:""}),(tt=t.targetSlide.value)!=null&&tt.frontmatter&&delete t.targetSlide.value.frontmatter.background),await o(Y),typeof document<"u"){const ct=document.querySelector(`.protyle-wysiwyg [data-node-id="${E}"]`),pt=ct==null?void 0:ct.closest('[data-type="NodeListItem"]'),X=pt==null?void 0:pt.getAttribute("data-node-id");if(X&&X!==E){const dt={[mt]:"",[Vt]:""};ie(X,dt),Pt.setBlockAttrOverride(X,dt),await Lt(X,dt).catch(()=>{})}}}}async function f(O){var X,dt,bt,T,F,p,j,L;const rt=`> [!NOTE] 💡 演讲备注
${(O||"在此输入本页讲稿提词...").split(/\r?\n/).map(_=>`> ${_}`).join(`
`)}
{: custom-slidev-note="true"}`,nt=((X=t.latestDoc.value)==null?void 0:X.slides)||[],tt=t.targetSlide.value,Y=tt?nt.findIndex(_=>_===tt):-1;let ct=null;if(Y!==-1&&Y<nt.length-1){const _=nt[Y+1];ct=await Ii("markdown",rt,_.startBlockId)}else{const _=((dt=tt==null?void 0:tt.noteBlocks)==null?void 0:dt.slice(-1)[0])||((bt=tt==null?void 0:tt.blocks)==null?void 0:bt.slice(-1)[0]),$=(_==null?void 0:_.id)||(tt==null?void 0:tt.startBlockId);$?ct=await Ii("markdown",rt,void 0,$):ct=await Zo("markdown",rt,t.currentDocId.value)}const pt=((p=(F=(T=ct==null?void 0:ct[0])==null?void 0:T.doOperations)==null?void 0:F[0])==null?void 0:p.id)||((j=ct==null?void 0:ct[0])==null?void 0:j.id);return pt&&(await Lt(pt,{[te]:"true"}),Pt.setBlockAttrOverride(pt,{[te]:"true"}),Pi(pt,(L=t.plugin)==null?void 0:L.app)),t.plugin&&await t.plugin.compileCurrentDocument(),pt}async function y(){const O=t.activeBlockId.value;if(O)if(t.isNoteBlock.value){n("取消中...");try{await Lt(O,{[te]:"","slidev-note":""}),Pt.setBlockAttrOverride(O,{[te]:"","slidev-note":""}),ie(O,{[te]:"","slidev-note":""}),delete t.activeBlockAttrs.value[te],delete t.activeBlockAttrs.value["slidev-note"],n("已取消备注"),ht.showMessage("已取消讲稿备注"),t.plugin&&await t.plugin.compileCurrentDocument()}catch(E){console.error("[SiYuanSlidev] 取消讲稿备注失败:",E),n("取消失败"),ht.showMessage("取消讲稿备注失败")}}else{n("转换中...");try{let E=t.rawSnippet.value;try{const tt=await Za(O);tt!=null&&tt.kramdown&&(E=tt.kramdown)}catch{}const nt=`> [!NOTE] 💡 演讲备注
${(Ql(E)||E.replace(/<[^>]+>/g,"").trim()||"在此输入本页讲稿提词...").split(/\r?\n/).map(tt=>`> ${tt}`).join(`
`)}
{: custom-slidev-note="true"}`;await Ws("markdown",nt,O),await Lt(O,{[te]:"true"}),Pt.setBlockAttrOverride(O,{[te]:"true"}),ie(O,{[te]:"true"}),t.activeBlockAttrs.value[te]="true",t.activeBlockType.value="NodeCallout",n("已设为讲稿备注"),ht.showMessage("已转为讲稿备注提示块（不在幻灯片中渲染）"),t.plugin&&await t.plugin.compileCurrentDocument()}catch(E){console.error("[SiYuanSlidev] 转换讲稿备注提示块失败:",E),n("设置失败"),ht.showMessage("转为讲稿备注提示块失败")}}}async function k(){try{await f(),ht.showMessage("已在正文末尾插入讲稿备注提示块")}catch(O){ht.showMessage("插入讲稿备注块失败"),console.error(O)}}function x(){var z;const O=t.currentSlideNoteBlockId.value;if(!O){ht.showMessage("未找到本页关联的讲稿备注块");return}Pi(O,(z=t.plugin)==null?void 0:z.app)?ht.showMessage("已在编辑区定位讲稿备注块"):ht.showMessage("定位讲稿备注块失败")}async function C(){var z;if(!t.currentDocId.value)return;const O=t.targetSlide.value||{startBlockId:t.activeBlockId.value||t.currentDocId.value,blocks:t.rawSnippet.value&&t.rawSnippet.value!=="---"?[{id:t.activeBlockId.value,type:t.activeBlockType.value,content:t.rawSnippet.value,rawMarkdown:""}]:[],rawMarkdown:t.rawSnippet.value&&t.rawSnippet.value!=="---"?t.rawSnippet.value:""};ht.showMessage("正在调用思源 AI 提炼本页讲稿提词...");const E=await ha(O,Rr);if(E.notes){const rt=t.currentSlideNoteBlockId.value;if(rt){const nt=`> [!NOTE] 💡 演讲备注
${E.notes.split(/\r?\n/).map(tt=>`> ${tt}`).join(`
`)}
{: custom-slidev-note="true"}`;await Ws("markdown",nt,rt),await Lt(rt,{[te]:"true"}),Pt.setBlockAttrOverride(rt,{[te]:"true"}),Pi(rt,(z=t.plugin)==null?void 0:z.app)}else await f(E.notes);E.isAiGenerated?ht.showMessage("思源 AI 演讲提词卡生成成功！"):ht.showMessage("未获取到思源 AI 响应，已生成预设提词卡模板",5e3),t.plugin&&await t.plugin.compileCurrentDocument()}}async function A(){var rt;if(i.value)return;const O=((rt=t.latestDoc.value)==null?void 0:rt.slides)||[];if(O.length===0){ht.showMessage("当前文档无幻灯片页面");return}const E=O.map((nt,tt)=>({slide:nt,idx:tt})).filter(({slide:nt})=>{var ct;const tt=Array.isArray(nt.noteBlocks)&&nt.noteBlocks.length>0,Y=!!((ct=nt.notes)!=null&&ct.trim());return!tt&&!Y});if(E.length===0){ht.showMessage("所有幻灯片页面均已存在讲稿备注块，无需追加");return}const z=E.length;ht.confirm("批量追加讲稿备注",`将在未配置讲稿的 ${z} 页末尾自动插入讲稿提示块，是否继续？`,async()=>{var tt,Y,ct,pt,X,dt;if(i.value)return;i.value=!0,ht.showMessage("正在批量追加讲稿块...");let nt=0;try{const F=`> [!NOTE] 💡 演讲备注
${"在此输入本页讲稿提词...".split(/\r?\n/).map(p=>`> ${p}`).join(`
`)}
{: custom-slidev-note="true"}`;for(const{slide:p,idx:j}of E)try{let L=null;if(j<O.length-1){const $=O[j+1];L=await Ii("markdown",F,$.startBlockId)}else{const $=((tt=p==null?void 0:p.noteBlocks)==null?void 0:tt.slice(-1)[0])||((Y=p==null?void 0:p.blocks)==null?void 0:Y.slice(-1)[0]),M=($==null?void 0:$.id)||(p==null?void 0:p.startBlockId);M?L=await Ii("markdown",F,void 0,M):L=await Zo("markdown",F,t.currentDocId.value)}const _=((X=(pt=(ct=L==null?void 0:L[0])==null?void 0:ct.doOperations)==null?void 0:pt[0])==null?void 0:X.id)||((dt=L==null?void 0:L[0])==null?void 0:dt.id);_&&(await Lt(_,{[te]:"true"}),Pt.setBlockAttrOverride(_,{[te]:"true"})),nt++}catch(L){console.error(`[SiYuanSlidev] 为第 ${j+1} 页追加讲稿块失败:`,L)}t.plugin&&await t.plugin.compileCurrentDocument(),ht.showMessage(`已成功为 ${nt} 页追加讲稿备注块`)}catch(bt){console.error("[SiYuanSlidev] 批量追加讲稿块失败:",bt),ht.showMessage("批量追加讲稿块时出现异常")}finally{i.value=!1}})}async function B(){var nt;if(i.value)return;const O=((nt=t.latestDoc.value)==null?void 0:nt.slides)||[];if(O.length===0){ht.showMessage("当前文档无幻灯片页面");return}const E=[];for(const tt of O)if(tt.noteBlocks&&tt.noteBlocks.length>0)for(const Y of tt.noteBlocks)Y.id&&E.push({id:Y.id,pageIndex:tt.pageIndex});if(E.length===0){ht.showMessage("当前文档中没有讲稿备注块，无需删除");return}const z=new Set(E.map(tt=>tt.pageIndex)).size,rt=E.length;ht.confirm("危险操作：批量删除所有讲稿块",`此操作将从正文中物理删除全部 ${rt} 个讲稿备注块（涉及 ${z} 页），删除后无法撤销。是否确认继续？`,async()=>{if(i.value)return;i.value=!0,ht.showMessage("正在批量删除讲稿块...");let tt=0;try{for(const Y of E)try{await Vs(Y.id),Pt.clearBlockAttrOverride(Y.id),tt++}catch(ct){console.error(`[SiYuanSlidev] 删除讲稿块 ${Y.id} 失败:`,ct)}t.activeBlockId.value&&E.some(Y=>Y.id===t.activeBlockId.value)&&(delete t.activeBlockAttrs.value[te],delete t.activeBlockAttrs.value["slidev-note"]),t.plugin&&await t.plugin.compileCurrentDocument(),ht.showMessage(`已成功删除全部 ${tt} 个讲稿备注块`)}catch(Y){console.error("[SiYuanSlidev] 批量删除讲稿块失败:",Y),ht.showMessage("批量删除讲稿块时出现异常")}finally{i.value=!1}})}function I(){t.elemClick.value?s(Ae,""):s(Ae,"+1")}function w(O){s(Ae,O)}function D(O){s(Ve,O)}function P(O){(t.activeBlockAttrs.value[Bt]||"")===O?s(Bt,""):s(Bt,O)}function R(O){t.elemShikiLines.value=O,s(Ri,O)}function J(O){t.elemMaxHeight.value=O,s(_n,O)}async function S(){const O=t.currentSlideLayout.value==="three-cols-header";await s(Bt,O?"col-1":"left"),ht.showMessage(O?"已将当前块设置为第 1 栏 (col-1)":"已将当前块设置为双栏左栏 (left)")}async function H(){const O=t.activeBlockId.value;if(!O)return;const E={[Ae]:"",[Ve]:"",[Bt]:"",[Ri]:"",[_n]:"",[te]:"","slidev-note":"",[mt]:"",[oe]:"",[Vt]:"",[Xt]:"",[jt]:"",[Ee]:"",[Ti]:"",[io]:"",[ji]:"",[no]:""};if(ie(O,E),await Lt(O,E),Pt.clearBlockAttrOverride(O),typeof document<"u"){const z=document.querySelector(`.protyle-wysiwyg [data-node-id="${O}"]`),rt=z==null?void 0:z.closest('[data-type="NodeListItem"]'),nt=rt==null?void 0:rt.getAttribute("data-node-id");nt&&nt!==O&&(ie(nt,E),await Lt(nt,E).catch(()=>{}),Pt.clearBlockAttrOverride(nt))}t.activeBlockAttrs.value={},t.elemShikiLines.value="",t.elemMaxHeight.value="",t.pageBackground.value="",t.pageImage.value="",ht.showMessage("已清除本块演示属性"),t.plugin&&await t.plugin.compileCurrentDocument()}async function g(){if(t.activeBlockId.value)try{await Ii("markdown","---",t.activeBlockId.value,void 0),ht.showMessage("已在上方插入分页符 (---)"),t.plugin&&t.plugin.compileCurrentDocument()}catch{ht.showMessage("插入分页符失败")}}async function N(){const O=t.activeBlockId.value||t.currentDocId.value;if(O)try{await Ii("markdown","---",void 0,O),ht.showMessage("已在下方插入分页符 (---)"),t.plugin&&t.plugin.compileCurrentDocument()}catch{ht.showMessage("插入分页符失败")}}async function q(){if(t.activeBlockId.value)try{await Vs(t.activeBlockId.value),ht.showMessage("已删除该分页符"),t.activeBlockId.value="",t.activeBlockType.value="",t.plugin&&t.plugin.compileCurrentDocument()}catch{ht.showMessage("删除失败")}}function U(){if(!t.latestDoc.value){ht.showMessage("请先在主编辑区打开幻灯片文档");return}const O=aa(t.latestDoc.value);ca("presentation.html",O)&&ht.showMessage("已开始下载单文件离线 HTML 演示包")}function G(){if(!t.latestDoc.value){ht.showMessage("请先在主编辑区打开幻灯片文档");return}da(t.latestDoc.value)&&ht.showMessage("已唤起打印视窗，请在打印选项中选择「另存为 PDF」")}async function Z(){var O,E;try{let z=null;if(typeof document<"u"){const nt=t.activeBlockId.value;if(nt){const tt=document.querySelector(`.protyle-wysiwyg [data-node-id="${nt}"]`);tt&&(z=tt.getAttribute("data-type")==="NodeSuperBlock"?tt:tt.closest('[data-type="NodeSuperBlock"]'))}if(!z){const tt=t.currentPageDividerId.value||(t.activeBlockType.value==="hr"||t.activeBlockType.value==="NodeThematicBreak"?t.activeBlockId.value:"");if(tt){const Y=document.querySelector(`.protyle-wysiwyg [data-node-id="${tt}"]`);if(Y){let ct=Y.nextElementSibling;for(;ct&&!(ct.getAttribute("data-type")==="NodeThematicBreak"||(O=ct.classList)!=null&&O.contains("protyle-wysiwyg__block--hr"));){const pt=ct.getAttribute("data-type")==="NodeSuperBlock"?ct:ct.querySelector('[data-type="NodeSuperBlock"]');if(pt){z=pt;break}ct=ct.nextElementSibling}}}else{const Y=document.querySelector('.protyle-wysiwyg [data-type="NodeThematicBreak"], .protyle-wysiwyg .protyle-wysiwyg__block--hr'),ct=Array.from(document.querySelectorAll('.protyle-wysiwyg [data-type="NodeSuperBlock"]'));for(const pt of ct)if(!Y||pt.compareDocumentPosition(Y)&Node.DOCUMENT_POSITION_FOLLOWING){z=pt;break}}}}const rt=[];if(z){const nt=Array.from(z.querySelectorAll(":scope > [data-node-id]"));for(const tt of nt){const Y=tt.getAttribute("data-node-id");Y&&(rt.push(Y),tt.removeAttribute("style"))}}else if((E=t.targetSlide.value)!=null&&E.blocks){for(const nt of t.targetSlide.value.blocks)if(nt.children&&nt.children.length>=2){for(const tt of nt.children)tt.id&&rt.push(tt.id);break}}if(rt.length>0)for(const nt of rt)await Lt(nt,{style:""}).catch(()=>{});await r(oe,""),ht.showMessage("已重置超级块为平均分布比例"),t.plugin&&await t.plugin.compileCurrentDocument()}catch(z){console.error("[useInspectorActions] resetSuperBlockWidth error:",z),ht.showMessage("重置超级块比例失败")}}return{triggerSaveNotice:n,saveAttrs:o,saveAttr:s,savePageAttr:r,applyPageLayoutAndRatio:a,resetSuperBlockWidth:Z,saveDocAttr:c,onToggleVideoAutoplay:u,onToggleVideoLoop:m,onToggleVideoMuted:v,onToggleVideoControls:d,onImageRoleChange:b,onToggleNoteBlock:y,createNoteBlockOnCurrentSlide:f,onAddNoteBlock:k,onLocateNoteBlock:x,onGenerateNotesWithAI:C,isBatchProcessing:i,onBatchAppendNotes:A,onBatchDeleteNotes:B,toggleElemClick:I,onElemClickStepChange:w,onElemMotionChange:D,onElemSlotChange:P,onElemShikiLinesChange:R,onElemMaxHeightChange:J,onSetTwoColsContrast:S,onClearBlockAttrs:H,onInsertDividerBefore:g,onInsertDividerAfter:N,onDeleteCurrentBlock:q,onExportHtml:U,onExportPdf:G}}const Nb={class:"spm-slidev-inspector"},Fb={class:"spm-inspector-topbar"},Hb={class:"spm-inspector-title"},jb={class:"slidev-icon",style:{fill:"none !important"},"aria-hidden":"true",viewBox:"0 0 24 24"},Ub={class:"spm-inspector-topbar-actions"},Wb={class:"spm-target-banner"},Vb={class:"spm-target-info"},qb=["aria-label"],Kb={key:0,class:"spm-save-status"},Gb=["title"],Zb={class:"spm-inspector-body"},Yb=_e({__name:"SlidevInspectorDockView",setup(t,{expose:i}){const e=ti("plugin"),n=gt(!1);function o(ot){n.value=!1,c.value=ot.docId,e!=null&&e.compileCurrentDocument&&e.compileCurrentDocument(ot.docId)}const s=gt(""),l=gt(""),r=gt({}),a=gt(""),c=gt(""),u=gt(""),m=gt(""),v=gt(""),d=gt(null),b=gt(""),f=gt("");function y(){var yt;const ot=s.value||c.value;ot&&typeof navigator<"u"&&(yt=navigator==null?void 0:navigator.clipboard)!=null&&yt.writeText&&navigator.clipboard.writeText(ot).then(()=>{f.value="已复制！",setTimeout(()=>{f.value=""},1500)}).catch(()=>{})}const k=_t(()=>pa(l.value)),x=_t(()=>l.value==="NodeCodeBlock"),C=gt(!1),A=_t(()=>{if(C.value||W.value)return!0;const ot=a.value||"";return!!vi(ot)}),B=_t(()=>{const ot=l.value||"";if(ot==="NodeVideo"||ot==="video")return!0;const yt=a.value||"";return!!(/<video\b/i.test(yt)||/\.mp4\b/i.test(yt))}),I=_t(()=>!s.value||s.value===c.value||l.value==="doc"||l.value==="NodeDocument"),w=_t(()=>{const ot=s.value||c.value||"";return ot.length>8?ot.slice(-8):ot||"无"}),D=_t(()=>a.value?a.value.replace(/<[^>]+>/g,"").replace(/[\r\n]+/g," ").trim().slice(0,45):""),P=_t(()=>{if(k.value)return"分页符 (---)";if(I.value)return"全局文档";if(B.value)return"视频块";switch(l.value){case"NodeHeading":return"标题块";case"NodeParagraph":return"段落块";case"NodeCodeBlock":return"代码块";case"NodeVideo":return"视频块";case"NodeList":case"NodeListItem":return"列表项";case"NodeBlockquote":return"引述块";case"NodeTable":return"表格块";case"NodeSuperBlock":case"s":case"sb":return"超级块";default:return"内容块"}}),R=_t(()=>k.value?"tag-divider":I.value?"tag-doc":"tag-block"),J=_t(()=>r.value[mt]||"default"),S=_t(()=>r.value[Xt]||"slide-left"),H=gt(""),g=gt(""),N=_t(()=>r.value[un]||"inherit"),q=_t(()=>{var ot;return Rb((ot=d.value)==null?void 0:ot.slides,{activeBlockId:s.value,activeBlockType:l.value,currentTopBlockId:u.value,currentPageDividerId:m.value,activeBlockAttrs:r.value})}),U=_t(()=>{var ot;return((ot=q.value)==null?void 0:ot.notes)||""}),G=_t(()=>{var ot,yt,$t;return(($t=(yt=(ot=q.value)==null?void 0:ot.noteBlocks)==null?void 0:yt[0])==null?void 0:$t.id)||""}),Z=_t(()=>{var Et,Ft,Dt,de,Fn,ci;if(k.value){const Jt=r.value[mt]||r.value["custom-slidev-layout"];if(Jt)return Jt}const ot=r.value[Bt]||r.value["custom-slidev-slot"];if(ot&&(["col-1","col-2","col-3"].includes(ot)||/^col-\d+$/.test(ot)))return"cols-header";if(v.value)return v.value;const yt=m.value||(k.value?s.value:"");if(yt){const Jt=Pt.getBlockAttrOverride(yt);if(Jt!=null&&Jt[mt])return Jt[mt]}if(yt&&((Et=d.value)!=null&&Et.slides)){const Jt=d.value.slides.find(Ni=>Ni.startBlockId===yt);if((Ft=Jt==null?void 0:Jt.frontmatter)!=null&&Ft.layout)return Jt.frontmatter.layout}if((de=(Dt=q.value)==null?void 0:Dt.frontmatter)!=null&&de.layout)return q.value.frontmatter.layout;if((ci=(Fn=q.value)==null?void 0:Fn.blocks)!=null&&ci.some(Jt=>Jt.slot&&(["col-1","col-2","col-3"].includes(Jt.slot)||/^col-\d+$/.test(Jt.slot))))return"cols-header";const $t=Pt.getBlockAttrOverride(c.value);return $t!=null&&$t[mt]?$t[mt]:"default"}),O=_t(()=>{var yt,$t;if(k.value){const Et=r.value[oe]||r.value["custom-slidev-layout-ratio"];if(Et)return Et}const ot=m.value||(k.value?s.value:"");if(ot){const Et=Pt.getBlockAttrOverride(ot);if(Et!=null&&Et[oe])return Et[oe]}return(($t=(yt=q.value)==null?void 0:yt.frontmatter)==null?void 0:$t.layoutRatio)||""});function E(ot){if(!ot||(ot.getAttribute("data-sb-layout")||"").toLowerCase()!=="col")return null;const $t=Array.from(ot.querySelectorAll(":scope > [data-node-id]"));if($t.length<2)return null;const Et=$t.length,Ft=$t.map(ci=>{const Jt=ci.getAttribute("style")||"",Ni=Jt.match(/calc\(\s*([\d.]+)%/);if(Ni)return parseFloat(Ni[1]);const nn=Jt.match(/(?:^|;|\s)width:\s*([\d.]+)%/i);return nn?parseFloat(nn[1]):null});let Dt="",de=!1;if(Ft.some(ci=>ci!==null)){de=!0;const ci=Ft.reduce((Tt,ue)=>Tt+(ue||0),0),Jt=Ft.filter(Tt=>Tt===null).length,Ni=Jt>0?Math.max(0,100-ci)/Jt:100/$t.length,nn=Ft.map(Tt=>Tt!==null?Tt:Ni),Na=nn.reduce((Tt,ue)=>Tt+ue,0)||1,on=nn.map(Tt=>Tt/Na*100);if(on.length===2){const[Tt]=on;if(Tt>=48&&Tt<=52)Dt="1:1";else if(Tt>=31&&Tt<=35)Dt="1:2";else if(Tt>=65&&Tt<=69)Dt="2:1";else if(Tt>=28&&Tt<=32)Dt="3:7";else if(Tt>=68&&Tt<=72)Dt="7:3";else if(Tt>=38&&Tt<=42)Dt="4:6";else if(Tt>=58&&Tt<=62)Dt="6:4";else{const ue=Math.round(Tt);Dt=`${ue}:${100-ue}`}}else if(on.length===3){const[Tt,ue,di]=on;if(Tt>=31&&Tt<=35&&ue>=31&&ue<=35&&di>=31&&di<=35)Dt="1:1:1";else if(Tt>=23&&Tt<=27&&ue>=48&&ue<=52&&di>=23&&di<=27)Dt="1:2:1";else if(Tt>=48&&Tt<=52&&ue>=23&&ue<=27&&di>=23&&di<=27)Dt="2:1:1";else if(Tt>=23&&Tt<=27&&ue>=23&&ue<=27&&di>=48&&di<=52)Dt="1:1:2";else{const js=Math.round(Tt),Us=Math.round(ue);Dt=`${js}:${Us}:${100-js-Us}`}}else Dt=on.map(Tt=>Math.round(Tt)).join(":")}else de=!1,Dt=Array.from({length:Et},()=>1).join(":");const Fn=Et>=2?"cols-header":"two-cols";return{hasSuperBlock:!0,colCount:Et,ratio:Dt,isCustomWidth:de,recommendedLayout:Fn}}function z(ot){if(!(ot!=null&&ot.blocks))return null;for(const yt of ot.blocks){const $t=yt.rawNode;if($t&&se($t)&&li($t)){const Ft=On($t).length,Dt=Ds($t);return{hasSuperBlock:!0,colCount:Ft,ratio:Dt||Array.from({length:Ft},()=>1).join(":"),isCustomWidth:!!Dt,recommendedLayout:Ft>=2?"cols-header":"two-cols"}}}return null}const rt=_t(()=>{var ot;if(typeof document<"u"){const yt=s.value;if(yt){const Et=document.querySelector(`.protyle-wysiwyg [data-node-id="${yt}"]`);if(Et){const Ft=Et.getAttribute("data-type")==="NodeSuperBlock"?Et:Et.closest('[data-type="NodeSuperBlock"]');if(Ft){const Dt=E(Ft);if(Dt)return Dt}}}const $t=m.value||(k.value?s.value:"");if($t){const Et=document.querySelector(`.protyle-wysiwyg [data-node-id="${$t}"]`);if(Et){let Ft=Et.nextElementSibling;for(;Ft&&!(Ft.getAttribute("data-type")==="NodeThematicBreak"||(ot=Ft.classList)!=null&&ot.contains("protyle-wysiwyg__block--hr"));){const Dt=Ft.getAttribute("data-type")==="NodeSuperBlock"?Ft:Ft.querySelector('[data-type="NodeSuperBlock"]');if(Dt){const de=E(Dt);if(de)return de}Ft=Ft.nextElementSibling}}}else{const Et=document.querySelector('.protyle-wysiwyg [data-type="NodeThematicBreak"], .protyle-wysiwyg .protyle-wysiwyg__block--hr'),Ft=Array.from(document.querySelectorAll('.protyle-wysiwyg [data-type="NodeSuperBlock"]'));for(const Dt of Ft)if(!Et||Dt.compareDocumentPosition(Et)&Node.DOCUMENT_POSITION_FOLLOWING){const de=E(Dt);if(de)return de}}}return z(q.value)}),nt=_t(()=>{var ot;return((ot=rt.value)==null?void 0:ot.ratio)||""}),tt=_t(()=>{const ot=l.value||"";if(ot==="NodeSuperBlock"||ot==="s"||ot==="sb")return!0;if(typeof document<"u"&&s.value){const yt=document.querySelector(`.protyle-wysiwyg [data-node-id="${s.value}"]`);if(yt!=null&&yt.closest('[data-type="NodeSuperBlock"]'))return!0}return!1}),Y=_t(()=>{var ot;return((ot=q.value)==null?void 0:ot.pageIndex)||1}),ct=_t(()=>!!(r.value[te]||r.value["slidev-note"])),pt=_t(()=>{var yt;if(r.value[Ae])return r.value[Ae];const ot=s.value;if(ot&&((yt=q.value)!=null&&yt.blocks)){const $t=q.value.blocks.find(Et=>Et.id===ot);if($t!=null&&$t.clicks)return $t.clicks}return""}),X=_t(()=>{var yt;if(r.value[Ve])return r.value[Ve];const ot=s.value;if(ot&&((yt=q.value)!=null&&yt.blocks)){const $t=q.value.blocks.find(Et=>Et.id===ot);if($t!=null&&$t.motion)return typeof $t.motion=="string"?$t.motion:JSON.stringify($t.motion)}return""}),dt=_t(()=>{var yt;if(r.value[Bt])return r.value[Bt];const ot=s.value;if(ot&&((yt=q.value)!=null&&yt.blocks)){const $t=q.value.blocks.find(Et=>Et.id===ot);if($t!=null&&$t.slot)return $t.slot}return""}),bt=gt(""),T=gt(""),F=_t(()=>r.value[Ti]==="true"),p=_t(()=>r.value[io]==="true"),j=_t(()=>r.value[ji]==="true"),L=_t(()=>r.value[no]!=="false"),_=_t(()=>{var ot,yt;return((yt=(ot=d.value)==null?void 0:ot.config)==null?void 0:yt.theme)||r.value[kn]||"default"}),$=_t(()=>{var ot,yt;return((yt=(ot=d.value)==null?void 0:ot.config)==null?void 0:yt.aspectRatio)||r.value[wn]||"16/9"}),M=_t(()=>{var ot,yt;return((yt=(ot=d.value)==null?void 0:ot.config)==null?void 0:yt.defaultTransition)||r.value[xn]||"slide-left"}),K=_t(()=>{var ot,yt;return((yt=(ot=d.value)==null?void 0:ot.config)==null?void 0:yt.spacing)||r.value[Jo]||"normal"}),W=_t(()=>{var Ft,Dt;if((r.value[Vt]||r.value["slidev-role"])===Fr||r.value[jt]==="true")return"background";const yt=r.value[mt]||r.value["slidev-layout"];if(yt==="image-left"||yt==="image-right")return yt;const $t=a.value||"",Et=vi($t);if(Et&&((Dt=(Ft=q.value)==null?void 0:Ft.frontmatter)!=null&&Dt.background)){const de=q.value.frontmatter.background;if(de===Et||de.endsWith(Et)||Et.endsWith(de))return"background"}return""}),V=_t(()=>!!(r.value[Ae]||r.value[Ve]||r.value[Bt]||r.value[Ri]||r.value[te]||r.value["slidev-note"]||r.value[Vt]||r.value[mt]||r.value[Ti]||r.value[io]||r.value[ji]||r.value[no])),{saveAttr:Q,savePageAttr:lt,applyPageLayoutAndRatio:st,resetSuperBlockWidth:ft,saveDocAttr:xt,onToggleVideoAutoplay:kt,onToggleVideoLoop:Mt,onToggleVideoMuted:Kt,onToggleVideoControls:Gt,onImageRoleChange:ne,onToggleNoteBlock:Nt,onAddNoteBlock:Ke,onLocateNoteBlock:ee,onGenerateNotesWithAI:Yt,isBatchProcessing:ki,onBatchAppendNotes:Oi,onBatchDeleteNotes:Eo,toggleElemClick:Mo,onElemClickStepChange:Nn,onElemMotionChange:wi,onElemSlotChange:zi,onElemShikiLinesChange:va,onElemMaxHeightChange:ba,onSetTwoColsContrast:ya,onClearBlockAttrs:ka,onInsertDividerBefore:wa,onInsertDividerAfter:Ns,onDeleteCurrentBlock:xa,onExportHtml:_a,onExportPdf:Sa}=zb({activeBlockId:s,activeBlockType:l,activeBlockAttrs:r,rawSnippet:a,currentDocId:c,currentPageDividerId:m,currentPageDividerLayout:v,latestDoc:d,targetSlide:q,currentSlideNoteBlockId:G,currentSlideLayout:Z,isNoteBlock:ct,elemClick:pt,videoAutoplay:F,videoLoop:p,videoMuted:j,videoControls:L,pageBackground:H,pageImage:g,elemShikiLines:bt,elemMaxHeight:T,saveStatus:b,plugin:e});function Ca(ot){Q(mt,ot)}function $a(ot){lt(oe,ot)}function Fs(ot){if(!ot)return;const yt=ot.recommendedLayout||(ot.colCount&&ot.colCount>=2?"cols-header":"two-cols"),$t=ot.ratio||(ot.colCount?Array(ot.colCount).fill(1).join(":"):"1:1");st(yt,$t)}function Ia(ot){lt(oe,ot)}async function Aa(){await ft()}function Ba(ot){Q(Xt,ot)}function Ta(ot){H.value=ot,Q(jt,ot)}function Ea(ot){g.value=ot,Q(Ee,ot)}function Ma(ot){Q(un,ot==="inherit"?"":ot)}function Da(ot){xt(kn,ot)}function La(ot){xt(wn,ot)}function Pa(ot){xt(xn,ot)}function Ra(ot){xt(Jo,ot)}function Hs(){e!=null&&e.openBottomPreviewTab&&e.openBottomPreviewTab()}function Oa(){typeof window<"u"&&window.open("/plugins/siyuan-slidev/slidev-client/presenter.html","SlidevPresenter","width=1200,height=800")}function za(){e!=null&&e.executeCommand&&e.executeCommand("slidevAiSplit")}return i({setActiveBlock(ot){s.value=ot.id,l.value=ot.type,r.value={...ot.attrs},a.value=ot.content||ot.markdown||"",u.value=ot.topBlockId||ot.id,m.value=ot.pageDividerId||"",v.value=ot.pageDividerLayout||"",ot.rootId?c.value=ot.rootId:(ot.type==="doc"||ot.type==="NodeDocument")&&ot.id&&(c.value=ot.id),H.value=ot.attrs[jt]||"",g.value=ot.attrs[Ee]||"",bt.value=ot.attrs[Ri]||"",T.value=ot.attrs[_n]||"",C.value=!!ot.isImage},updateDocument(ot){d.value=ot,c.value=ot.docId},openImportDialog(){n.value=!0},setCurrentDocId(ot){c.value=ot}}),(ot,yt)=>(et(),it("div",Nb,[h("div",Fb,[h("div",Hb,[(et(),it("svg",jb,[...yt[2]||(yt[2]=[h("rect",{x:"2",y:"3",width:"20",height:"14",rx:"2"},null,-1),h("line",{x1:"8",y1:"21",x2:"16",y2:"21"},null,-1),h("line",{x1:"12",y1:"17",x2:"12",y2:"21"},null,-1)])])),yt[3]||(yt[3]=h("span",null,"演示配置",-1))]),h("div",Ub,[h("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"导入 Slidev 演示文档 (.md / .zip)",onClick:yt[0]||(yt[0]=$t=>n.value=!0)},[at(ut,{name:"import"}),yt[4]||(yt[4]=h("span",null,"导入",-1))]),h("button",{class:"spm-icon-btn is-primary b3-tooltips b3-tooltips__s","aria-label":"在下方分屏开启幻灯片预览 (Alt+P)",onClick:Hs},[at(ut,{name:"split-preview"}),yt[5]||(yt[5]=h("span",null,"分屏预览",-1))])])]),h("div",Wb,[h("div",Vb,[h("span",{class:It(["spm-target-tag",R.value])},St(P.value),3),h("span",{class:"spm-target-id b3-tooltips b3-tooltips__s","aria-label":f.value||"点击复制 ID: "+(s.value||c.value),onClick:y},[at(ut,{name:"copy"}),h("span",null,"#"+St(w.value),1)],8,qb)]),b.value?(et(),it("span",Kb,"● "+St(b.value),1)):Rt("",!0)]),D.value?(et(),it("div",{key:0,class:"spm-context-quote",title:a.value},St(D.value),9,Gb)):Rt("",!0),h("div",Zb,[k.value?(et(),De(cg,{key:0,"page-layout":J.value,"page-layout-ratio":O.value,"detected-sb-ratio":nt.value,"detected-sb-info":rt.value,"page-transition":S.value,"page-background":H.value,"page-spacing":N.value,"page-image":g.value,"page-notes":U.value,"page-index":Y.value,"onUpdate:pageLayout":Ca,"onUpdate:pageLayoutRatio":$a,onApplySuperBlockLayout:Fs,onResetSuperblockRatio:Aa,"onUpdate:pageTransition":Ba,"onUpdate:pageBackground":Ta,"onUpdate:pageSpacing":Ma,"onUpdate:pageImage":Ea,onAddNoteBlock:vt(Ke),onLocateNoteBlock:vt(ee),onGenerateNotes:vt(Yt),onBatchAppendNotes:vt(Oi),onBatchDeleteNotes:vt(Eo),"is-batch-processing":vt(ki),onInsertDividerAfter:vt(Ns),onDeleteDivider:vt(xa)},null,8,["page-layout","page-layout-ratio","detected-sb-ratio","detected-sb-info","page-transition","page-background","page-spacing","page-image","page-notes","page-index","onAddNoteBlock","onLocateNoteBlock","onGenerateNotes","onBatchAppendNotes","onBatchDeleteNotes","is-batch-processing","onInsertDividerAfter","onDeleteDivider"])):s.value&&!I.value?(et(),De(qv,{key:1,"elem-click":pt.value,"elem-motion":X.value,"elem-slot":dt.value,"elem-shiki-lines":bt.value,"elem-max-height":T.value,"is-code-block":x.value,"is-image":A.value,"is-video":B.value,"is-super-block":tt.value,"detected-sb-info":rt.value,"video-autoplay":F.value,"video-loop":p.value,"video-muted":j.value,"video-controls":L.value,"has-block-attrs":V.value,"is-note":ct.value,"image-role":W.value,"current-slide-layout":Z.value,onToggleNote:vt(Nt),onToggleElemClick:vt(Mo),onToggleVideoAutoplay:vt(kt),onToggleVideoLoop:vt(Mt),onToggleVideoMuted:vt(Kt),onToggleVideoControls:vt(Gt),"onUpdate:imageRole":vt(ne),"onUpdate:elemClick":vt(Nn),"onUpdate:elemMotion":vt(wi),"onUpdate:elemSlot":vt(zi),"onUpdate:elemShikiLines":vt(va),"onUpdate:elemMaxHeight":vt(ba),onApplySuperBlockLayout:Fs,onApplySuperBlockRatio:Ia,onInsertDividerBefore:vt(wa),onInsertDividerAfter:vt(Ns),onSetTwoColsContrast:vt(ya),onClearBlockAttrs:vt(ka)},null,8,["elem-click","elem-motion","elem-slot","elem-shiki-lines","elem-max-height","is-code-block","is-image","is-video","is-super-block","detected-sb-info","video-autoplay","video-loop","video-muted","video-controls","has-block-attrs","is-note","image-role","current-slide-layout","onToggleNote","onToggleElemClick","onToggleVideoAutoplay","onToggleVideoLoop","onToggleVideoMuted","onToggleVideoControls","onUpdate:imageRole","onUpdate:elemClick","onUpdate:elemMotion","onUpdate:elemSlot","onUpdate:elemShikiLines","onUpdate:elemMaxHeight","onInsertDividerBefore","onInsertDividerAfter","onSetTwoColsContrast","onClearBlockAttrs"])):(et(),De(T1,{key:2,"doc-theme":_.value,"doc-aspect-ratio":$.value,"doc-default-transition":M.value,"doc-spacing":K.value,"onUpdate:docTheme":Da,"onUpdate:docAspectRatio":La,"onUpdate:docDefaultTransition":Pa,"onUpdate:docSpacing":Ra,onOpenBottomPreview:Hs,onOpenPresenter:Oa,onAiAutoSplit:za,onExportHtml:vt(_a),onExportPdf:vt(Sa)},null,8,["doc-theme","doc-aspect-ratio","doc-default-transition","doc-spacing","onExportHtml","onExportPdf"]))]),n.value?(et(),De(Pb,{key:1,onClose:yt[1]||(yt[1]=$t=>n.value=!1),onSuccess:o})):Rt("",!0)]))}}),zn=new Os;let mi=null,We=null;function Jb(t,i){mi&&ma(),mi=Gl(dm),mi.provide("plugin",i),mi.provide("sandboxBridge",zn);const e=mi.mount(t);return We=e,e}function ma(t){mi&&(mi.unmount(),mi=null,We=null)}let gi=null,xe=null;function Xb(t,i){gi&&ga(),gi=Gl(Yb),gi.provide("plugin",i),gi.provide("sandboxBridge",zn);const e=gi.mount(t);return xe=e,e}function ga(t){gi&&(gi.unmount(),gi=null,xe=null)}function Qb(t,i){xe!=null&&xe.updateDocument&&xe.updateDocument(t),We!=null&&We.updateDocument?We.updateDocument(t,i):zn.updateSlides(t.slides,t.config,t.fullMarkdown)}function fs(t){We!=null&&We.navigateToBlock?We.navigateToBlock(t):zn.highlightElement(t)}function to(t){xe!=null&&xe.setActiveBlock&&xe.setActiveBlock(t)}function ty(){return xe!=null&&xe.openImportDialog?(xe.openImportDialog(),!0):!1}function ey(t,i){const e=[];let o=0;for(let s=0;s<t.length;s++){const l=t[s];if(go(l)){o=0;continue}const r=l.markdown||l.content||"";if(!(s===0)){if(l.type==="h"&&(l.subType==="h1"||r.startsWith("# "))){e.push({blockId:l.id,recommendedLayout:"cover",reason:"检测到一级核心章节标题，建议作为新幻灯片封面/大章"}),o=0;continue}if(l.type==="h"&&(l.subType==="h2"||r.startsWith("## "))){e.push({blockId:l.id,recommendedLayout:"default",reason:"检测到二级分论点标题，建议开启新页"}),o=0;continue}}if(o++,o>=6&&s<t.length-1){const c=t[s+1];go(c)||(e.push({blockId:c.id,recommendedLayout:"default",reason:"当前页已达容量上限 (避免信息超载)，建议在此分页"}),o=0)}}return e}const iy=[{id:"slidev-cover",name:"幻灯片 - 封面页 (Cover)",open:!0,attrs:[{key:Bi,value:"true"},{key:mt,value:"cover"},{key:Xt,value:"fade"}]},{id:"slidev-two-cols",name:"幻灯片 - 双栏对比 (Two Columns)",open:!0,attrs:[{key:Bi,value:"true"},{key:mt,value:"two-cols"},{key:Xt,value:"slide-left"}]},{id:"slidev-fact",name:"幻灯片 - 大字报与核心指标 (Fact)",open:!0,attrs:[{key:Bi,value:"true"},{key:mt,value:"fact"},{key:Xt,value:"zoom"}]},{id:"slidev-intro",name:"幻灯片 - 章节导引与作者 (Intro)",open:!0,attrs:[{key:Bi,value:"true"},{key:mt,value:"intro"},{key:Xt,value:"slide-up"}]},{id:"slidev-quote",name:"幻灯片 - 金句与强调 (Quote)",open:!0,attrs:[{key:Bi,value:"true"},{key:mt,value:"quote"},{key:Xt,value:"fade"}]},{id:"slidev-elem-click",name:"元素 - 顺延逐步呈现 (v-click)",open:!0,attrs:[{key:Ae,value:"+1"}]},{id:"slidev-elem-click-hide",name:"元素 - 隐藏直到激活 (v-click:hide)",open:!0,attrs:[{key:Ae,value:"hide"}]},{id:"slidev-elem-slot-right",name:"元素 - 双栏右栏归属 (Slot: Right)",open:!0,attrs:[{key:Bt,value:"right"}]},{id:"slidev-shiki-lines",name:"代码 - 逐行聚光高亮 (Shiki)",open:!0,attrs:[{key:Ri,value:"1-3"}]}];class Go{getPresetTemplates(){return iy}buildScanSlidevBlocksSql(i="custom-slidev-"){return`SELECT block_id, name, value FROM attributes WHERE name LIKE '${i}%' ORDER BY block_id ASC`}buildTransitionStatsSql(){return`SELECT value, count(1) as count FROM attributes WHERE name = '${Xt}' GROUP BY value ORDER BY count DESC`}async batchUpdateTransitions(i,e,n,o){const s=`SELECT block_id FROM attributes WHERE name = '${Xt}' AND value = '${i}'`,l=await n(s);let r=0;if(Array.isArray(l))for(const a of l){const c=a.block_id||a.blockId;c&&(await o(c,{[Xt]:e}),r++)}return{updatedCount:r}}async batchUpdateLayout(i,e,n,o){const s=`SELECT block_id FROM attributes WHERE name = 'custom-slidev-layout' AND value = '${i}'`,l=await n(s);let r=0;if(Array.isArray(l))for(const a of l){const c=a.block_id||a.blockId;c&&(await o(c,{"custom-slidev-layout":e}),r++)}return{updatedCount:r}}exportTemplatesJson(){const i=this.getPresetTemplates();return JSON.stringify({templates:i,counter:i.length},null,2)}formatTransitionSummary(i){return!i||i.length===0?"全库目前暂无已设置 Slidev 转场效果的块":`全库 Slidev 转场分布统计：${i.map(n=>`${n.value}: ${n.count} 个`).join("，")}`}}function ny(t){t.addCommand({langKey:"slidevPresentation",langText:"Slidev: 在文档下方开启分屏演示预览",hotkey:"⌥P",enabled:()=>!0,execute:()=>{t.openBottomPreviewTab()}}),t.addCommand({langKey:"slidevImport",langText:"Slidev: 导入 Slidev 演示文档 (.md / .zip)",hotkey:"⌥I",enabled:()=>!0,execute:()=>{ty()||ht.showMessage("请先在右侧栏打开「Slidev 演示配置」Dock 面板以呼起导入窗口")}}),t.addCommand({langKey:"slidevInitAttrs",langText:"Slidev: 初始化当前文档演示属性",hotkey:"",enabled:()=>!0,execute:async()=>{if(!t.currentDocId){const i=document.querySelector(".protyle-content[data-doc-id]");t.currentDocId=(i==null?void 0:i.getAttribute("data-doc-id"))||""}t.currentDocId&&(await Lt(t.currentDocId,{"custom-slidev-theme":"default","custom-slidev-aspect-ratio":"16/9","custom-slidev-default-transition":"slide-left"}),ht.showMessage("已为当前文档初始化 Slidev 演示属性"),t.compileCurrentDocument(t.currentDocId))}}),t.addCommand({langKey:"slidevAiSplit",langText:"Slidev AI: 智能大纲断页建议与自动分页",hotkey:"",enabled:()=>!0,execute:async()=>{if(!t.currentDocId){const s=document.querySelector(".protyle-content[data-doc-id]");t.currentDocId=(s==null?void 0:s.getAttribute("data-doc-id"))||""}if(!t.currentDocId){ht.showMessage("请先打开一篇思源笔记文档");return}const i=await eo(t.currentDocId).catch(()=>[]);if(!i||i.length===0){ht.showMessage("当前文档无内容，无需断页");return}const e=i.map(s=>({id:s.id,type:s.type,subType:s.subType,content:s.content||"",markdown:s.markdown||""})),n=ey(e);if(n.length===0){ht.showMessage("AI 分析完毕：当前文档篇幅合理，暂无分页建议");return}ht.showMessage(`AI 分析完毕：发现 ${n.length} 处建议分页点，正在自动插入分页分割线...`);let o=0;for(const s of n)try{await Ii("markdown","---",void 0,s.blockId),await Lt(s.blockId,{"custom-slidev-layout":s.recommendedLayout}),o++}catch(l){console.warn("Failed to insert divider:",l)}ht.showMessage(`已成功在 ${o} 处插入分页线并重新编译`),t.compileCurrentDocument(t.currentDocId)}}),t.addCommand({langKey:"slidevAiNotes",langText:"Slidev AI: 自动为当前文档生成演讲者提词卡 (Notes)",hotkey:"",enabled:()=>!0,execute:async()=>{var a,c,u,m;if(!t.currentDocId){const v=document.querySelector(".protyle-content[data-doc-id]");t.currentDocId=(v==null?void 0:v.getAttribute("data-doc-id"))||""}if(!t.currentDocId){ht.showMessage("请先打开一篇思源笔记文档");return}ht.showMessage("正在调用思源 AI 提炼演讲者口播提词...");const i=await eo(t.currentDocId).catch(()=>[]),e={startBlockId:t.currentDocId,blocks:i.map(v=>({id:v.id,type:v.type,content:v.content||"",rawMarkdown:v.markdown||""})),rawMarkdown:""},s=`> [!NOTE] 💡 演讲备注
${(await Ob(e,Rr)).split(/\r?\n/).map(v=>`> ${v}`).join(`
`)}
{: custom-slidev-note="true"}`,l=await Zo("markdown",s,t.currentDocId).catch(()=>null),r=((u=(c=(a=l==null?void 0:l[0])==null?void 0:a.doOperations)==null?void 0:c[0])==null?void 0:u.id)||((m=l==null?void 0:l[0])==null?void 0:m.id);r&&(await Lt(r,{"custom-slidev-note":"true"}),Pt.setBlockAttrOverride(r,{"custom-slidev-note":"true"}),Pi(r,t.app)),ht.showMessage("已成功生成口播提词卡并插入为正文讲稿备注块"),t.compileCurrentDocument(t.currentDocId)}}),t.addCommand({langKey:"slidevBatchTransitions",langText:"Slidev 协同: 统计全库转场效果分布",hotkey:"",enabled:()=>!0,execute:async()=>{const i=new Go,e=i.buildTransitionStatsSql(),n=await yn(e).catch(()=>[]),o=i.formatTransitionSummary(n||[]);ht.showMessage(o)}}),t.addCommand({langKey:"slidevExportTemplates",langText:"Slidev 协同: 复制 Slidev 预设属性模板至剪贴板",hotkey:"",enabled:()=>!0,execute:async()=>{const e=new Go().exportTemplatesJson();typeof navigator<"u"&&navigator.clipboard?(await navigator.clipboard.writeText(e),ht.showMessage("已将 Slidev 属性模板 JSON 复制至剪贴板，可直接导入属性管家")):ht.showMessage(`已生成模板数据（请在控制台查看）：
`+e)}}),t.addCommand({langKey:"slidevBatchReplaceTransition",langText:"Slidev 协同: 批量替换全库淡入淡出转场为滑动 (fade -> slide-left)",hotkey:"",enabled:()=>!0,execute:async()=>{const e=await new Go().batchUpdateTransitions("fade","slide-left",n=>yn(n).catch(()=>[]),(n,o)=>Lt(n,o));ht.showMessage(`全库批量替换完成：已将 ${e.updatedCount} 处 fade 转场更新为 slide-left`),t.compileCurrentDocument()}}),t.addCommand({langKey:"slidevPresenterMode",langText:"Slidev: 打开双屏演讲者控制台 (Presenter Mode)",hotkey:"⌥M",enabled:()=>!0,execute:()=>{typeof window<"u"&&window.open("/plugins/siyuan-slidev/slidev-client/presenter.html","SlidevPresenter","width=1200,height=800")}}),t.addCommand({langKey:"slidevExportCliMd",langText:"Slidev Pro: 导出 Slidev 标准 slides.md 文档 (下载到本地)",hotkey:"",enabled:()=>!0,execute:async()=>{if(t.latestCompiledDoc||await t.compileCurrentDocument(),!t.latestCompiledDoc){ht.showMessage("请先打开并放映一篇思源笔记文档");return}t.cliBridge.downloadSlidesMd(t.latestCompiledDoc,`slides-${t.currentDocId||"demo"}.md`)&&ht.showMessage("已生成标准 Slidev Markdown 并触发下载，可在本地使用 npx @slidev/cli 运行")}}),t.addCommand({langKey:"slidevProbeCliDevServer",langText:"Slidev Pro: 检测本地 Slidev CLI DevServer 状态 (localhost:3030)",hotkey:"",enabled:()=>!0,execute:async()=>{ht.showMessage("正在探测本地 Slidev CLI DevServer (http://localhost:3030)..."),await t.cliBridge.probeServer(1500)?ht.showMessage("🟢 本地 Slidev CLI DevServer 运行正常！可直接在浏览器访问 http://localhost:3030"):ht.showMessage("⚪ 未检测到运行中的本地 Slidev CLI DevServer (端口 3030 未开启)")}}),t.addCommand({langKey:"slidevSyncToCliWorkspace",langText:"Slidev Pro: 同步 slides.md 至思源工作空间存储目录",hotkey:"",enabled:()=>!0,execute:async()=>{if(t.latestCompiledDoc||await t.compileCurrentDocument(),!t.latestCompiledDoc){ht.showMessage("请先打开并放映一篇思源笔记文档");return}const i=await t.cliBridge.syncToWorkspaceFile(t.latestCompiledDoc,"/data/storage/petal/siyuan-slidev/slides.md",Yo);i.success?ht.showMessage(`已成功同步最新 slides.md 至工作空间：${i.path}`):ht.showMessage(`同步失败：${i.error}`)}})}class oy{getActiveDocumentId(){if(typeof document>"u")return"";const i=document.querySelector(".layout__wnd--active .protyle-title[data-node-id]")||document.querySelector(".item--focus .protyle-title[data-node-id]")||document.querySelector(".protyle-title[data-node-id]"),e=i==null?void 0:i.getAttribute("data-node-id");if(e)return e;const n=document.querySelector(".protyle .protyle-title[data-node-id]"),o=n==null?void 0:n.getAttribute("data-node-id");if(o)return o;const s=document.querySelector("[data-doc-id]"),l=s==null?void 0:s.getAttribute("data-doc-id");return l||""}resolveDocIdFromElement(i,e=""){const n=i.closest(".protyle-title"),o=n==null?void 0:n.getAttribute("data-node-id");if(o)return o;const s=i.closest(".protyle"),l=s==null?void 0:s.querySelector(".protyle-title"),r=l==null?void 0:l.getAttribute("data-node-id");if(r)return r;const a=i.closest("[data-doc-id]"),c=a==null?void 0:a.getAttribute("data-doc-id");if(c)return c;const u=this.getActiveDocumentId();return u||e}async switchToDocGlobalInspector(i,e){var s;if(!i)return;let n=e||"";if(!n&&typeof document<"u"){const l=document.querySelector(`.protyle-title[data-node-id="${i}"] .protyle-title__input`)||document.querySelector(`.protyle[data-doc-id="${i}"] .protyle-title__input`)||document.querySelector(".protyle-title__input");n=((s=l==null?void 0:l.innerText)==null?void 0:s.trim())||""}const o=await Ze(i).catch(()=>({}));to({id:i,rootId:i,type:"doc",content:n,attrs:o,isDivider:!1,isCode:!1}),fs(i)}handleBlockClickedFromSlide(i,e,n,o){var a;if(!i)return!1;const s=Pi(i,e),l=document.querySelector(`.protyle-wysiwyg [data-node-id="${i}"]`)||document.querySelector(`[data-node-id="${i}"]`),r=(l==null?void 0:l.getAttribute("data-type"))||"";if(l)this.syncInspectorBlock(l,i,r,n,o);else{let c="",u="";if(o!=null&&o.slides){const m=o.slides.find(v=>{var d,b,f;return v.startBlockId===i||((d=v.blocks)==null?void 0:d.some(y=>y.id===i))||((b=v.allBlockIds)==null?void 0:b.includes(i))||((f=v.noteBlocks)==null?void 0:f.some(y=>y.id===i))});m!=null&&m.startBlockId&&(c=m.startBlockId),(a=m==null?void 0:m.frontmatter)!=null&&a.layout&&(u=m.frontmatter.layout)}Ze(i).then(async m=>{if(c&&!u){const v=Pt.getBlockAttrOverride(c);if(v!=null&&v[mt]||v!=null&&v["custom-slidev-layout"])u=v[mt]||v["custom-slidev-layout"]||"";else{const d=await Ze(c).catch(()=>({}))||{};u=d[mt]||d["custom-slidev-layout"]||"",d&&Object.keys(d).length>0&&Pt.setBlockAttrOverride(c,d)}}to({id:i,rootId:n,type:r||"NodeParagraph",attrs:m||{},pageDividerId:c,pageDividerLayout:u})}).catch(()=>{})}return s}async syncInspectorBlock(i,e,n,o,s){var S,H,g,N,q,U,G,Z;let l=i,r=e,a=n;const c=i.closest('[data-type="NodeCallout"]');if(c&&c!==i){const O=c.getAttribute("data-node-id");if(O){const E=await Ze(O).catch(()=>({}))||{},z=Pt.getBlockAttrOverride(O)||{},rt={...E,...z};(rt[te]||rt["slidev-note"])&&(l=c,r=O,a="NodeCallout")}}const u=l.closest(".protyle-wysiwyg > [data-node-id]")||l,m=(u==null?void 0:u.getAttribute("data-node-id"))||r,v=a==="NodeThematicBreak"||a==="tb"||a==="thematic-break"||(u==null?void 0:u.getAttribute("data-type"))==="NodeThematicBreak"||(u==null?void 0:u.getAttribute("data-type"))==="tb"||!!((S=u==null?void 0:u.classList)!=null&&S.contains("hr")),d=a==="NodeCodeBlock",b=((H=l.innerText)==null?void 0:H.trim())||"",f=await Ze(r).catch(()=>({}))||{},y=Pt.getBlockAttrOverride(r)||{},k={...f,...y};let x="",C="";if(v)x=r,C=k[mt]||k["custom-slidev-layout"]||"";else{let O=u.previousElementSibling;for(;O;){const E=O.getAttribute("data-type");if(E==="NodeThematicBreak"||E==="tb"||(g=O.classList)!=null&&g.contains("hr")){x=O.getAttribute("data-node-id")||"";break}O=O.previousElementSibling}}if(s!=null&&s.slides){const O=[r,m];let E=l.parentElement;for(;E&&!E.classList.contains("protyle-wysiwyg");){const rt=E.getAttribute("data-node-id");rt&&!O.includes(rt)&&O.push(rt),E=E.parentElement}const z=s.slides.find(rt=>{var nt,tt,Y;return O.includes(rt.startBlockId)||((nt=rt.blocks)==null?void 0:nt.some(ct=>O.includes(ct.id)))||((tt=rt.allBlockIds)==null?void 0:tt.some(ct=>O.includes(ct)))||((Y=rt.noteBlocks)==null?void 0:Y.some(ct=>O.includes(ct.id)))});z&&(!x&&z.startBlockId&&(x=z.startBlockId),!C&&((N=z.frontmatter)!=null&&N.layout)&&(C=z.frontmatter.layout))}if(x){const O=Pt.getBlockAttrOverride(x);if(O&&(mt in O||"custom-slidev-layout"in O)&&(C=O[mt]||O["custom-slidev-layout"]||""),!C&&(s!=null&&s.slides)){const E=s.slides.find(z=>z.startBlockId===x);(q=E==null?void 0:E.frontmatter)!=null&&q.layout&&(C=E.frontmatter.layout)}if(!C){const E=await Ze(x).catch(()=>({}))||{};C=E[mt]||E["custom-slidev-layout"]||"",E&&Object.keys(E).length>0&&Pt.setBlockAttrOverride(x,E)}ie(x,{[mt]:C||""})}else if(o){const O=Pt.getBlockAttrOverride(o);O&&(mt in O||"custom-slidev-layout"in O)?C=O[mt]||O["custom-slidev-layout"]||"":!C&&((Z=(G=(U=s==null?void 0:s.slides)==null?void 0:U[0])==null?void 0:G.frontmatter)!=null&&Z.layout)&&(C=s.slides[0].frontmatter.layout)}const A=l.getAttribute(mt)||l.getAttribute("custom-slidev-layout"),B=k[mt]||k["custom-slidev-layout"]||"";A&&A!==B&&ie(r,{[mt]:B});const I=l.getAttribute(Vt)||l.getAttribute("custom-slidev-role"),w=k[Vt]||k["custom-slidev-role"]||"";I&&I!==w&&ie(r,{[Vt]:w});const D=l.closest('[data-type="NodeListItem"]');if(D&&D!==l){const O=D.getAttribute("data-node-id");if(O){const E=await Ze(O).catch(()=>({}))||{},z=Pt.getBlockAttrOverride(O)||{},rt={...E,...z},nt=rt[mt]||rt["custom-slidev-layout"]||"",tt=D.getAttribute(mt)||D.getAttribute("custom-slidev-layout");tt&&tt!==nt&&ie(O,{[mt]:nt});const Y=rt[Vt]||rt["custom-slidev-role"]||"",ct=D.getAttribute(Vt)||D.getAttribute("custom-slidev-role");ct&&ct!==Y&&ie(O,{[Vt]:Y})}}const P=!!l.querySelector("img, span[data-type='img']"),R=(l.innerText||"").replace(/[\r\n\t\s]+/g," ").trim(),J=P&&R.length<=50;to({id:r,rootId:o,type:a,content:b,attrs:k,isDivider:v,isCode:d,isImage:J,topBlockId:m,pageDividerId:x,pageDividerLayout:C})}patchThematicBreakTransactions(i){if((i==null?void 0:i.cmd)==="transactions"&&Array.isArray(i.data)){for(const e of i.data)if(Array.isArray(e==null?void 0:e.doOperations)){for(const n of e.doOperations)if((n==null?void 0:n.action)==="updateAttrs"&&n.id&&n.data){const o=n.data.old||{},s=n.data.new||{},l={};for(const r of Object.keys(o))r in s||(l[r]="");for(const[r,a]of Object.entries(s))l[r]=String(a??"");ie(n.id,l),Pt.setBlockAttrOverride(n.id,l)}}}}purgeStaleDomSlidevAttrs(i){var o,s,l;if(typeof document>"u"||!i)return;const e=new Map;if(Array.isArray(i.slides))for(const r of i.slides){if(r.startBlockId){const a=e.get(r.startBlockId)||{};(o=r.frontmatter)!=null&&o.layout&&(a[mt]=r.frontmatter.layout),e.set(r.startBlockId,a)}if(Array.isArray(r.blocks)){for(const a of r.blocks)if(a.id){const c=e.get(a.id)||{};(s=a.ial)!=null&&s[mt]&&(c[mt]=a.ial[mt]),(l=a.ial)!=null&&l[Vt]&&(c[Vt]=a.ial[Vt]),Object.keys(c).length>0&&e.set(a.id,c)}}}const n=Pt.getAllAttrOverrides();for(const[r,a]of n.entries()){const c=e.get(r)||{};a[mt]!==void 0&&(c[mt]=a[mt]),a[Vt]!==void 0&&(c[Vt]=a[Vt]),e.set(r,c)}yp(e)}}const $i=new oy,sy=`<symbol id="iconSlidev" viewBox="0 0 1024 1024">
  <path fill="currentColor" d="M128 160h768c35.3 0 64 28.7 64 64v480c0 35.3-28.7 64-64 64H128c-35.3 0-64-28.7-64-64V224c0-35.3 28.7-64 64-64z m64 64v480h640V224H192z m128 640h384v64H320z"/>
  <path fill="currentColor" d="M416 336l256 144-256 144z"/>
</symbol>`,ry="slidev-dock",Dr="slidev-preview-tab",Lr=Bu;class ly extends ht.Plugin{constructor(){super(...arguments);wt(this,"isMobile",!1);wt(this,"currentDocId","");wt(this,"latestCompiledDoc",null);wt(this,"cliBridge",new Ls);wt(this,"debounceTimer",null);wt(this,"activeCursorBlockId","");wt(this,"onSwitchProtyleBound",this.onSwitchProtyle.bind(this));wt(this,"onWsMainBound",this.onWsMain.bind(this));wt(this,"onBlockClickedBound",this.onBlockClickedFromSlide.bind(this));wt(this,"onClickEditorTitleIconBound",this.onClickEditorTitleIcon.bind(this));wt(this,"onEditorClickBound",this.onEditorClick.bind(this));wt(this,"onSelectionChangeBound",this.onSelectionChange.bind(this));wt(this,"onClickEditorContentBound",this.onClickEditorContent.bind(this))}async onload(){const e=ht.getFrontend();this.isMobile=e==="mobile"||e==="browser-mobile",await this.loadGlobalSettings(),this.addIcons(sy),this.addTopBar({id:"slidev-topbar-play",icon:"iconSlidev",title:"Slidev 演示 (下方分屏)",position:"right",callback:()=>{this.openBottomPreviewTab()}}),ny(this);const n=this;if(this.addTab({type:Dr,init(){Jb(this.element,n)},destroy(){ma(this.element)}}),this.addDock({config:{position:"RightTop",size:{width:320,height:0},icon:"iconSlidev",title:"Slidev 演示配置"},data:{},type:ry,init(){Xb(this.element,n)},destroy(){ga(this.element)}}),this.eventBus&&typeof this.eventBus.emit!="function"&&(this.eventBus.emit=(o,s)=>{try{typeof window<"u"&&window.dispatchEvent(new CustomEvent(`siyuan-event-${o}`,{detail:s}))}catch{}}),this.eventBus.on("switch-protyle",this.onSwitchProtyleBound),this.eventBus.on("ws-main",this.onWsMainBound),this.eventBus.on("slidev:request-compile",()=>this.compileCurrentDocument()),this.eventBus.on("slidev:block-clicked",this.onBlockClickedBound),this.eventBus.on("click-editortitleicon",this.onClickEditorTitleIconBound),this.eventBus.on("click-editorcontent",this.onClickEditorContentBound),typeof document<"u"&&(document.addEventListener("click",this.onEditorClickBound,!0),document.addEventListener("selectionchange",this.onSelectionChangeBound)),typeof document<"u"){const o=()=>{const s=this.getActiveDocumentId();s&&(s!==this.currentDocId&&(this.currentDocId=s),this.latestCompiledDoc||this.compileCurrentDocument(s))};setTimeout(o,300),setTimeout(o,1e3)}}async onDataChanged(e){await this.loadGlobalSettings(),this.currentDocId&&await this.compileCurrentDocument(this.currentDocId)}async loadGlobalSettings(){try{const e=await this.loadData(Lr),n=Tu(e);return Ei(n),n}catch{return Ei(Qi),Qi}}async saveGlobalSettings(e){const n=To(),o=Ei({...n,...e||{}});try{await this.saveData(Lr,o)}catch(l){console.error("保存 Slidev 全局配置失败",l)}const s=this.currentDocId||this.getActiveDocumentId();return s&&await this.compileCurrentDocument(s),o}onunload(){this.debounceTimer&&(window.clearTimeout(this.debounceTimer),this.debounceTimer=null),this.eventBus.off("switch-protyle",this.onSwitchProtyleBound),this.eventBus.off("ws-main",this.onWsMainBound),this.eventBus.off("click-editortitleicon",this.onClickEditorTitleIconBound),this.eventBus.off("click-editorcontent",this.onClickEditorContentBound),typeof document<"u"&&(document.removeEventListener("click",this.onEditorClickBound,!0),document.removeEventListener("selectionchange",this.onSelectionChangeBound)),zn.detach()}async openBottomPreviewTab(){this.currentDocId||(this.currentDocId=this.getActiveDocumentId()),await ht.openTab({app:this.app,custom:{id:this.name+Dr,title:"Slidev 演示预览",icon:"iconSlidev",data:{docId:this.currentDocId}},position:"bottom"}),this.currentDocId&&this.compileCurrentDocument(this.currentDocId)}onClickEditorTitleIcon(e){var l;const n=e.detail,o=n==null?void 0:n.menu,s=((l=n==null?void 0:n.data)==null?void 0:l.id)||this.currentDocId;!o||!s||o.addItem({icon:"iconSlidev",label:"Slidev 全局演示配置",submenu:[{label:"初始化演示属性 (custom-slidev-*)",click:async()=>{await Lt(s,{"custom-slidev-theme":"default","custom-slidev-aspect-ratio":"16/9","custom-slidev-default-transition":"slide-left"}),ht.showMessage("已为当前文档初始化 Slidev 演示属性"),this.compileCurrentDocument(s)}},{type:"separator"},{label:"主题: 默认 (default)",click:async()=>{await Lt(s,{"custom-slidev-theme":"default"}),ht.showMessage("已切换为 default 主题"),this.compileCurrentDocument(s)}},{label:"主题: 优雅衬线 (seriph)",click:async()=>{await Lt(s,{"custom-slidev-theme":"seriph"}),ht.showMessage("已切换为 seriph 主题"),this.compileCurrentDocument(s)}},{label:"主题: 苹果极简 (apple-basic)",click:async()=>{await Lt(s,{"custom-slidev-theme":"apple-basic"}),ht.showMessage("已切换为 apple-basic 主题"),this.compileCurrentDocument(s)}},{type:"separator"},{label:"画幅: 16 / 9 (宽屏)",click:async()=>{await Lt(s,{"custom-slidev-aspect-ratio":"16/9"}),ht.showMessage("已切换画幅为 16/9"),this.compileCurrentDocument(s)}},{label:"画幅: 4 / 3 (标屏)",click:async()=>{await Lt(s,{"custom-slidev-aspect-ratio":"4/3"}),ht.showMessage("已切换画幅为 4/3"),this.compileCurrentDocument(s)}}]})}async onSwitchProtyle(e){var s,l;const n=(s=e.detail)==null?void 0:s.protyle,o=(l=n==null?void 0:n.block)==null?void 0:l.rootID;if(o&&o!==this.currentDocId){this.currentDocId=o,this.activeCursorBlockId=o;const r=await Ze(o).catch(()=>({}));to({id:o,rootId:o,type:"doc",attrs:r}),this.compileCurrentDocument(o)}}onClickEditorContent(e){var s,l;const n=e==null?void 0:e.detail;if(!n)return;const o=(l=(s=n.protyle)==null?void 0:s.block)==null?void 0:l.rootID;o&&(!this.currentDocId||this.currentDocId!==o)&&(this.currentDocId=o),n.event&&this.onEditorClick(n.event)}getActiveDocumentId(){return $i.getActiveDocumentId()}resolveDocIdFromElement(e){return $i.resolveDocIdFromElement(e,this.currentDocId)}async switchToDocGlobalInspector(e,n){e&&(this.activeCursorBlockId=e,this.currentDocId=e,await $i.switchToDocGlobalInspector(e,n))}onWsMain(e){const n=e.detail;n&&($i.patchThematicBreakTransactions(n),this.debounceTimer&&window.clearTimeout(this.debounceTimer),this.debounceTimer=window.setTimeout(()=>{this.compileCurrentDocument()},150))}handleBlockClickedFromSlide(e,n){return e?(this.activeCursorBlockId=e,$i.handleBlockClickedFromSlide(e,this.app,this.currentDocId,this.latestCompiledDoc)):!1}onBlockClickedFromSlide(e){const n=(e==null?void 0:e.detail)||e;n!=null&&n.blockId&&this.handleBlockClickedFromSlide(n.blockId,n.page)}onEditorClick(e){const n=e.target;if(!n)return;const o=n.closest(".protyle-title")||n.closest(".protyle-background");if(!!(o||n.closest(".protyle-content")&&!n.closest(".protyle-wysiwyg")&&!n.closest(".protyle-breadcrumb")&&!n.closest(".protyle-gutters"))){const u=this.resolveDocIdFromElement(n);if(u&&this.activeCursorBlockId!==u){const m=o||document.querySelector(`.protyle-title[data-node-id="${u}"]`)||document.querySelector(`.protyle[data-doc-id="${u}"] .protyle-title`),v=m==null?void 0:m.querySelector(".protyle-title__input"),d=((v==null?void 0:v.innerText)||(m==null?void 0:m.innerText)||"").trim();this.switchToDocGlobalInspector(u,d)}return}if(!n.closest(".protyle-wysiwyg"))return;const r=n.closest("[data-node-id]");if(!r)return;const a=r.getAttribute("data-node-id"),c=r.getAttribute("data-type")||"";a&&(this.currentDocId||(this.currentDocId=this.resolveDocIdFromElement(n)||""),this.currentDocId&&!this.latestCompiledDoc&&this.compileCurrentDocument(this.currentDocId),a!==this.activeCursorBlockId&&(this.activeCursorBlockId=a,fs(a)),this.syncInspectorBlock(r,a,c))}onSelectionChange(){if(typeof window>"u")return;const e=window.getSelection();if(!e||e.rangeCount===0)return;const n=e.anchorNode;if(!n)return;const o=n.nodeType===Node.ELEMENT_NODE?n:n.parentElement;if(!o)return;const s=o.closest(".protyle-title");if(!!(s||o.closest(".protyle-content")&&!o.closest(".protyle-wysiwyg"))){const u=this.resolveDocIdFromElement(o);if(u&&this.activeCursorBlockId!==u){const m=s||document.querySelector(`.protyle-title[data-node-id="${u}"]`)||document.querySelector(`.protyle[data-doc-id="${u}"] .protyle-title`),v=m==null?void 0:m.querySelector(".protyle-title__input"),d=((v==null?void 0:v.innerText)||(m==null?void 0:m.innerText)||"").trim();this.switchToDocGlobalInspector(u,d)}return}if(!o.closest(".protyle-wysiwyg"))return;const r=o.closest("[data-node-id]"),a=r==null?void 0:r.getAttribute("data-node-id"),c=(r==null?void 0:r.getAttribute("data-type"))||"";r&&a&&(this.currentDocId||(this.currentDocId=this.resolveDocIdFromElement(o)||""),this.currentDocId&&!this.latestCompiledDoc&&this.compileCurrentDocument(this.currentDocId),a!==this.activeCursorBlockId&&(this.activeCursorBlockId=a,fs(a)),this.syncInspectorBlock(r,a,c))}async syncInspectorBlock(e,n,o){await $i.syncInspectorBlock(e,n,o,this.currentDocId,this.latestCompiledDoc)}async compileCurrentDocument(e){let n=e||this.currentDocId;if(!n){const o=this.getActiveDocumentId();if(o)this.currentDocId=o,n=o;else return}try{const o=await Pt.compile(n);this.latestCompiledDoc=o,Qb(o,n),this.purgeStaleDomSlidevAttrs(o)}catch(o){console.error("[SiYuanSlidev] Failed to compile document:",o)}}purgeStaleDomSlidevAttrs(e){$i.purgeStaleDomSlidevAttrs(e)}}module.exports=ly;
