"use strict";var Qc=Object.create;var Js=Object.defineProperty;var ed=Object.getOwnPropertyDescriptor;var td=Object.getOwnPropertyNames;var id=Object.getPrototypeOf,nd=Object.prototype.hasOwnProperty;var sd=(e,t,i)=>t in e?Js(e,t,{enumerable:!0,configurable:!0,writable:!0,value:i}):e[t]=i;var od=(e,t,i,n)=>{if(t&&typeof t=="object"||typeof t=="function")for(let s of td(t))!nd.call(e,s)&&s!==i&&Js(e,s,{get:()=>t[s],enumerable:!(n=ed(t,s))||n.enumerable});return e};var is=(e,t,i)=>(i=e!=null?Qc(id(e)):{},od(t||!e||!e.__esModule?Js(i,"default",{value:e,enumerable:!0}):i,e));var ye=(e,t,i)=>sd(e,typeof t!="symbol"?t+"":t,i);const ue=require("siyuan");async function bt(e,t){const i=await ue.fetchSyncPost(e,t);return i.code===0?i.data:null}async function rd(){return bt("/api/notebook/lsNotebooks","")}async function ad(e,t,i){return bt("/api/filetree/createDocWithMd",{notebook:e,path:t,markdown:i})}async function ga(e,t){const i=new FormData;i.append("assetsDirPath",e);for(const s of t)i.append("file[]",s);return bt("/api/asset/upload",i)}async function zi(e,t,i,n,s){return bt("/api/block/insertBlock",{dataType:e,data:t,nextID:i,previousID:n,parentID:s})}async function bo(e,t,i){return bt("/api/block/appendBlock",{dataType:e,data:t,parentID:i})}async function yo(e,t,i){return bt("/api/block/updateBlock",{dataType:e,data:t,id:i})}async function va(e){return bt("/api/block/deleteBlock",{id:e})}async function ld(e){return bt("/api/block/getBlockKramdown",{id:e})}async function Yn(e){return bt("/api/block/getChildBlocks",{id:e})}async function cd(e){return bt("/api/block/getDocBlocksOrders",{id:e})}async function ze(e,t){return bt("/api/attr/setBlockAttrs",{id:e,attrs:t})}async function jo(e){return bt("/api/attr/getBlockAttrs",{id:e})}async function dn(e){return bt("/api/query/sql",{stmt:e})}async function ko(e,t,i){const n=new FormData;return n.append("path",e),n.append("isDir",t.toString()),n.append("modTime",Math.floor(Date.now()/1e3).toString()),n.append("file",i),bt("/api/file/putFile",n)}async function ba(e){const t="/api/ai/chatGPT";try{const i=await bt(t,{msg:e});return typeof i=="string"&&i.trim().length>0?i.trim():i&&typeof i.content=="string"&&i.content.trim().length>0?i.content.trim():null}catch{return null}}async function dd(){return bt("/api/storage/getInlineStyles","")}function ud(e){return e.markdown&&e.markdown.trim()?e.markdown.trim():e.content&&e.content.trim()?e.content.trim():""}function ya(e){const t={};if(!e)return t;const i=e.replace(/^\{:\s*/,"").replace(/\s*\}$/,""),n=/([\w-]+)=(?:"([^"]*)"|'([^']*)'|(\S+))/g;let s;for(;(s=n.exec(i))!==null;){const o=s[1],a=s[2]??s[3]??s[4]??"";t[o]=a}return t}const ka=/\(\(([0-9a-zA-Z-]+)(?:\s*(?:'([^']*)'|"([^"]*)"|([^\)]+?)))?\s*\)\)/g;function fd(e){const t=[];if(!e)return t;const i=new RegExp(ka.source,"g");let n;for(;(n=i.exec(e))!==null;){const s=n[2]??n[3]??n[4];t.push({fullMatch:n[0],blockId:n[1],anchorText:s?s.trim():void 0})}return t}function pd(e,t){if(!e)return"";const i=new RegExp(ka.source,"g");return e.replace(i,(n,s,o,a,r)=>{const l=(o??a??r??"").trim();if(t&&t[s]){const u=t[s].trim();return`<div class="slides-block-ref" data-ref-id="${s}">${u}</div>`}const c=l||`Ref(${s.slice(0,8)})`;return`<a href="siyuan://blocks/${s}" data-ref-id="${s}" class="slides-ref-tag">🔗 ${c}</a>`})}const Rn="custom-slides-theme",Nn="custom-slides-aspect-ratio",wa="custom-slides-highlighter",zn="custom-slides-default-transition",xa="custom-slides-color-schema",wo="custom-slides-spacing",wr="custom-slides-show-unordered-list-markers",xr="custom-slides-show-ordered-list-markers",Ri="custom-slides-slide",Se="custom-slides-layout",gt="custom-slides-transition",st="custom-slides-background",Ot="custom-slides-image",Xs="custom-slides-notes",Qi="custom-slides-class",In="custom-slides-spacing",wt="custom-slides-layout-ratio",en="custom-slides-mask",Fi="custom-slides-mask-ratio",tn="custom-slides-mask-style",nn="custom-slides-mask-initial",Re="custom-slides-click",Jt="custom-slides-motion",Gi="custom-slides-shiki-lines",Me="custom-slides-slot",Ge="custom-slides-note",Ze="custom-slides-role",Hn="custom-slides-max-height",Ni="custom-slides-autoplay",ws="custom-slides-loop",Xi="custom-slides-muted",xs="custom-slides-controls",Sa="background",Ss="image-left",Cs="image-right";function sn(e){return e==="cols-header"||e==="two-cols-header"||e==="three-cols-header"}function hd(e,t=2){const i=t===4?[25,50,75,100]:[50,100],n=t===4?4:2;if(!e||typeof e!="string")return{steps:n,breakpoints:i};const s=e.trim();if(!s||t===4&&(s==="1:1"||s==="1"))return{steps:n,breakpoints:i};const o=s.split(":").map(h=>parseFloat(h.trim())).filter(h=>!isNaN(h)&&h>0);if(o.length===0)return{steps:n,breakpoints:i};if(o.length===1){const h=Math.min(100,Math.max(1,o[0]));return h===100?{steps:1,breakpoints:[100]}:{steps:2,breakpoints:[Math.round(h*100)/100,100]}}const a=o.every((h,f)=>f===0||h>o[f-1]),r=o[o.length-1];if(a&&(r===100||o.some(h=>h>10))){const h=o.map(f=>Math.min(100,Math.round(f*100)/100));return h[h.length-1]<100&&h.push(100),{steps:h.length,breakpoints:h}}const c=o.reduce((h,f)=>h+f,0);if(c<=0)return{steps:n,breakpoints:i};let u=0;const d=[];for(let h=0;h<o.length;h++)u+=o[h],h===o.length-1?d.push(100):d.push(Math.round(u/c*1e4)/100);return{steps:d.length,breakpoints:d}}function Ca(e){if(!e)return!1;const t=e.trim();return t.startsWith("assets/")||t.startsWith("./assets/")||t.startsWith("/assets/")}function _a(e){const t=e.trim();return t.startsWith("./assets/")?t.slice(2):t.startsWith("/assets/")?t.slice(1):t}function Bt(e,t){if(!Ca(e))return e;const i=_a(e);return t!=null&&t.base64Map&&t.base64Map[i]?t.base64Map[i]:t!=null&&t.baseUrl?`${t.baseUrl.replace(/\/+$/,"")}/${i}`:`/${i}`}function md(e,t){if(!e)return"";let i=e;return i=i.replace(/!\[(.*?)\]\(((?:\.\/|\/)?assets\/[^\s)]+)\)/g,(n,s,o)=>{const a=Bt(o,t);return`![${s}](${a})`}),i=i.replace(/(<(?:img|video|audio|source)\b[^>]*?\bsrc=["'])((?:\.\/|\/)?assets\/[^"']+)(["'][^>]*>)/gi,(n,s,o,a)=>{const r=Bt(o,t);return`${s}${r}${a}`}),i=i.replace(/(url\(\s*["']?)((?:\.\/|\/)?assets\/[^"')]+)(["']?\s*\))/gi,(n,s,o,a)=>{const r=Bt(o,t);return`${s}${r}${a}`}),i}/**
* @vue/shared v3.5.40
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/function Wo(e){const t=Object.create(null);for(const i of e.split(","))t[i]=1;return i=>i in t}const Je={},on=[],Xt=()=>{},$a=()=>!1,Ls=e=>e.charCodeAt(0)===111&&e.charCodeAt(1)===110&&(e.charCodeAt(2)>122||e.charCodeAt(2)<97),Ps=e=>e.startsWith("onUpdate:"),ut=Object.assign,Uo=(e,t)=>{const i=e.indexOf(t);i>-1&&e.splice(i,1)},gd=Object.prototype.hasOwnProperty,je=(e,t)=>gd.call(e,t),Ee=Array.isArray,rn=e=>Zn(e)==="[object Map]",hn=e=>Zn(e)==="[object Set]",Sr=e=>Zn(e)==="[object Date]",Be=e=>typeof e=="function",nt=e=>typeof e=="string",zt=e=>typeof e=="symbol",Ke=e=>e!==null&&typeof e=="object",Ia=e=>(Ke(e)||Be(e))&&Be(e.then)&&Be(e.catch),Ma=Object.prototype.toString,Zn=e=>Ma.call(e),vd=e=>Zn(e).slice(8,-1),Ta=e=>Zn(e)==="[object Object]",Vo=e=>nt(e)&&e!=="NaN"&&e[0]!=="-"&&""+parseInt(e,10)===e,Mn=Wo(",key,ref,ref_for,ref_key,onVnodeBeforeMount,onVnodeMounted,onVnodeBeforeUpdate,onVnodeUpdated,onVnodeBeforeUnmount,onVnodeUnmounted"),Os=e=>{const t=Object.create(null);return(i=>t[i]||(t[i]=e(i)))},bd=/-\w/g,St=Os(e=>e.replace(bd,t=>t.slice(1).toUpperCase())),yd=/\B([A-Z])/g,Ei=Os(e=>e.replace(yd,"-$1").toLowerCase()),Rs=Os(e=>e.charAt(0).toUpperCase()+e.slice(1)),Qs=Os(e=>e?`on${Rs(e)}`:""),Kt=(e,t)=>!Object.is(e,t),us=(e,...t)=>{for(let i=0;i<e.length;i++)e[i](...t)},Ea=(e,t,i,n=!1)=>{Object.defineProperty(e,t,{configurable:!0,enumerable:!1,writable:n,value:i})},Ns=e=>{const t=parseFloat(e);return isNaN(t)?e:t};let Cr;const zs=()=>Cr||(Cr=typeof globalThis<"u"?globalThis:typeof self<"u"?self:typeof window<"u"?window:typeof global<"u"?global:{});function qt(e){if(Ee(e)){const t={};for(let i=0;i<e.length;i++){const n=e[i],s=nt(n)?Sd(n):qt(n);if(s)for(const o in s)t[o]=s[o]}return t}else if(nt(e)||Ke(e))return e}const kd=/;(?![^(]*\))/g,wd=/:([^]+)/,xd=/\/\*[^]*?\*\//g;function Sd(e){const t={};return e.replace(xd,"").split(kd).forEach(i=>{if(i){const n=i.split(wd);n.length>1&&(t[n[0].trim()]=n[1].trim())}}),t}function $e(e){let t="";if(nt(e))t=e;else if(Ee(e))for(let i=0;i<e.length;i++){const n=$e(e[i]);n&&(t+=n+" ")}else if(Ke(e))for(const i in e)e[i]&&(t+=i+" ");return t.trim()}const Cd="itemscope,allowfullscreen,formnovalidate,ismap,nomodule,novalidate,readonly",_d=Wo(Cd);function Aa(e){return!!e||e===""}function $d(e,t){if(e.length!==t.length)return!1;let i=!0;for(let n=0;i&&n<e.length;n++)i=mn(e[n],t[n]);return i}function mn(e,t){if(e===t)return!0;let i=Sr(e),n=Sr(t);if(i||n)return i&&n?e.getTime()===t.getTime():!1;if(i=zt(e),n=zt(t),i||n)return e===t;if(i=Ee(e),n=Ee(t),i||n)return i&&n?$d(e,t):!1;if(i=Ke(e),n=Ke(t),i||n){if(!i||!n)return!1;const s=Object.keys(e).length,o=Object.keys(t).length;if(s!==o)return!1;for(const a in e){const r=e.hasOwnProperty(a),l=t.hasOwnProperty(a);if(r&&!l||!r&&l||!mn(e[a],t[a]))return!1}}return String(e)===String(t)}function Go(e,t){return e.findIndex(i=>mn(i,t))}const Ba=e=>!!(e&&e.__v_isRef===!0),Ce=e=>nt(e)?e:e==null?"":Ee(e)||Ke(e)&&(e.toString===Ma||!Be(e.toString))?Ba(e)?Ce(e.value):JSON.stringify(e,Da,2):String(e),Da=(e,t)=>Ba(t)?Da(e,t.value):rn(t)?{[`Map(${t.size})`]:[...t.entries()].reduce((i,[n,s],o)=>(i[eo(n,o)+" =>"]=s,i),{})}:hn(t)?{[`Set(${t.size})`]:[...t.values()].map(i=>eo(i))}:zt(t)?eo(t):Ke(t)&&!Ee(t)&&!Ta(t)?String(t):t,eo=(e,t="")=>{var i;return zt(e)?`Symbol(${(i=e.description)!=null?i:t})`:e};/**
* @vue/reactivity v3.5.40
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/let ct;class Id{constructor(t=!1){this.detached=t,this._active=!0,this._on=0,this.effects=[],this.cleanups=[],this._isPaused=!1,this._warnOnRun=!0,this.__v_skip=!0,!t&&ct&&(ct.active?(this.parent=ct,this.index=(ct.scopes||(ct.scopes=[])).push(this)-1):(this._active=!1,this._warnOnRun=!1))}get active(){return this._active}pause(){if(this._active){this._isPaused=!0;let t,i;if(this.scopes){const n=this.scopes.slice();for(t=0,i=n.length;t<i;t++)n[t].pause()}for(t=0,i=this.effects.length;t<i;t++)this.effects[t].pause()}}resume(){if(this._active&&this._isPaused){this._isPaused=!1;let t,i;if(this.scopes){const s=this.scopes.slice();for(t=0,i=s.length;t<i;t++)s[t].resume()}const n=this.effects.slice();for(t=0,i=n.length;t<i;t++)n[t].resume()}}run(t){if(this._active){const i=ct;try{return ct=this,t()}finally{ct=i}}}on(){++this._on===1&&(this.prevScope=ct,ct=this)}off(){if(this._on>0&&--this._on===0){if(ct===this)ct=this.prevScope;else{let t=ct;for(;t;){if(t.prevScope===this){t.prevScope=this.prevScope;break}t=t.prevScope}}this.prevScope=void 0}}stop(t){if(this._active){this._active=!1;let i,n;for(i=0,n=this.effects.length;i<n;i++)this.effects[i].stop();for(this.effects.length=0,i=0,n=this.cleanups.length;i<n;i++)this.cleanups[i]();if(this.cleanups.length=0,this.scopes){const s=this.scopes.slice();for(i=0,n=s.length;i<n;i++)s[i].stop(!0);this.scopes.length=0}if(!this.detached&&this.parent&&!t){const s=this.parent.scopes.pop();s&&s!==this&&(this.parent.scopes[this.index]=s,s.index=this.index)}this.parent=void 0}}}function Md(){return ct}let Qe;const to=new WeakSet;class La{constructor(t){this.fn=t,this.deps=void 0,this.depsTail=void 0,this.flags=5,this.next=void 0,this.cleanup=void 0,this.scheduler=void 0,ct&&(ct.active?ct.effects.push(this):this.flags&=-2)}pause(){this.flags|=64}resume(){this.flags&64&&(this.flags&=-65,to.has(this)&&(to.delete(this),this.trigger()))}notify(){this.flags&2&&!(this.flags&32)||this.flags&8||Oa(this)}run(){if(!(this.flags&1))return this.fn();this.flags|=2,_r(this),Ra(this);const t=Qe,i=Rt;Qe=this,Rt=!0;try{return this.fn()}finally{Na(this),Qe=t,Rt=i,this.flags&=-3}}stop(){if(this.flags&1){for(let t=this.deps;t;t=t.nextDep)Yo(t);this.deps=this.depsTail=void 0,_r(this),this.onStop&&this.onStop(),this.flags&=-2}}trigger(){this.flags&64?to.add(this):this.scheduler?this.scheduler():this.runIfDirty()}runIfDirty(){xo(this)&&this.run()}get dirty(){return xo(this)}}let Pa=0,Tn,En;function Oa(e,t=!1){if(e.flags|=8,t){e.next=En,En=e;return}e.next=Tn,Tn=e}function Ko(){Pa++}function qo(){if(--Pa>0)return;if(En){let t=En;for(En=void 0;t;){const i=t.next;t.next=void 0,t.flags&=-9,t=i}}let e;for(;Tn;){let t=Tn;for(Tn=void 0;t;){const i=t.next;if(t.next=void 0,t.flags&=-9,t.flags&1)try{t.trigger()}catch(n){e||(e=n)}t=i}}if(e)throw e}function Ra(e){for(let t=e.deps;t;t=t.nextDep)t.version=-1,t.prevActiveLink=t.dep.activeLink,t.dep.activeLink=t}function Na(e){let t,i=e.depsTail,n=i;for(;n;){const s=n.prevDep;n.version===-1?(n===i&&(i=s),Yo(n),Td(n)):t=n,n.dep.activeLink=n.prevActiveLink,n.prevActiveLink=void 0,n=s}e.deps=t,e.depsTail=i}function xo(e){for(let t=e.deps;t;t=t.nextDep)if(t.dep.version!==t.version||t.dep.computed&&(za(t.dep.computed)||t.dep.version!==t.version))return!0;return!!e._dirty}function za(e){if(e.flags&4&&!(e.flags&16)||(e.flags&=-17,e.globalVersion===Fn)||(e.globalVersion=Fn,!e.isSSR&&e.flags&128&&(!e.deps&&!e._dirty||!xo(e))))return;e.flags|=2;const t=e.dep,i=Qe,n=Rt;Qe=e,Rt=!0;try{Ra(e);const s=e.fn(e._value);(t.version===0||Kt(s,e._value))&&(e.flags|=128,e._value=s,t.version++)}catch(s){throw t.version++,s}finally{Qe=i,Rt=n,Na(e),e.flags&=-3}}function Yo(e,t=!1){const{dep:i,prevSub:n,nextSub:s}=e;if(n&&(n.nextSub=s,e.prevSub=void 0),s&&(s.prevSub=n,e.nextSub=void 0),i.subs===e&&(i.subs=n,!n&&i.computed)){i.computed.flags&=-5;for(let o=i.computed.deps;o;o=o.nextDep)Yo(o,!0)}!t&&!--i.sc&&i.map&&i.map.delete(i.key)}function Td(e){const{prevDep:t,nextDep:i}=e;t&&(t.nextDep=i,e.prevDep=void 0),i&&(i.prevDep=t,e.nextDep=void 0)}let Rt=!0;const Ha=[];function ui(){Ha.push(Rt),Rt=!1}function fi(){const e=Ha.pop();Rt=e===void 0?!0:e}function _r(e){const{cleanup:t}=e;if(e.cleanup=void 0,t){const i=Qe;Qe=void 0;try{t()}finally{Qe=i}}}let Fn=0;class Ed{constructor(t,i){this.sub=t,this.dep=i,this.version=i.version,this.nextDep=this.prevDep=this.nextSub=this.prevSub=this.prevActiveLink=void 0}}class Zo{constructor(t){this.computed=t,this.version=0,this.activeLink=void 0,this.subs=void 0,this.map=void 0,this.key=void 0,this.sc=0,this.__v_skip=!0}track(t){if(!Qe||!Rt||Qe===this.computed)return;let i=this.activeLink;if(i===void 0||i.sub!==Qe)i=this.activeLink=new Ed(Qe,this),Qe.deps?(i.prevDep=Qe.depsTail,Qe.depsTail.nextDep=i,Qe.depsTail=i):Qe.deps=Qe.depsTail=i,Fa(i);else if(i.version===-1&&(i.version=this.version,i.nextDep)){const n=i.nextDep;n.prevDep=i.prevDep,i.prevDep&&(i.prevDep.nextDep=n),i.prevDep=Qe.depsTail,i.nextDep=void 0,Qe.depsTail.nextDep=i,Qe.depsTail=i,Qe.deps===i&&(Qe.deps=n)}return i}trigger(t){this.version++,Fn++,this.notify(t)}notify(t){Ko();try{for(let i=this.subs;i;i=i.prevSub)i.sub.notify()&&i.sub.dep.notify()}finally{qo()}}}function Fa(e){if(e.dep.sc++,e.sub.flags&4){const t=e.dep.computed;if(t&&!e.dep.subs){t.flags|=20;for(let n=t.deps;n;n=n.nextDep)Fa(n)}const i=e.dep.subs;i!==e&&(e.prevSub=i,i&&(i.nextSub=e)),e.dep.subs=e}}const So=new WeakMap,ji=Symbol(""),Co=Symbol(""),jn=Symbol("");function mt(e,t,i){if(Rt&&Qe){let n=So.get(e);n||So.set(e,n=new Map);let s=n.get(i);s||(n.set(i,s=new Zo),s.map=n,s.key=i),s.track()}}function ai(e,t,i,n,s,o){const a=So.get(e);if(!a){Fn++;return}const r=l=>{l&&l.trigger()};if(Ko(),t==="clear")a.forEach(r);else{const l=Ee(e),c=l&&Vo(i);if(l&&i==="length"){const u=Number(n);a.forEach((d,h)=>{(h==="length"||h===jn||!zt(h)&&h>=u)&&r(d)})}else switch((i!==void 0||a.has(void 0))&&r(a.get(i)),c&&r(a.get(jn)),t){case"add":l?c&&r(a.get("length")):(r(a.get(ji)),rn(e)&&r(a.get(Co)));break;case"delete":l||(r(a.get(ji)),rn(e)&&r(a.get(Co)));break;case"set":rn(e)&&r(a.get(ji));break}}qo()}function Yi(e){const t=Fe(e);return t===e?t:(mt(t,"iterate",jn),Lt(e)?t:t.map(Ht))}function Hs(e){return mt(e=Fe(e),"iterate",jn),e}function Vt(e,t){return pi(e)?un(Wi(e)?Ht(t):t):Ht(t)}const Ad={__proto__:null,[Symbol.iterator](){return io(this,Symbol.iterator,e=>Vt(this,e))},concat(...e){return Yi(this).concat(...e.map(t=>Ee(t)?Yi(t):t))},entries(){return io(this,"entries",e=>(e[1]=Vt(this,e[1]),e))},every(e,t){return ii(this,"every",e,t,void 0,arguments)},filter(e,t){return ii(this,"filter",e,t,i=>i.map(n=>Vt(this,n)),arguments)},find(e,t){return ii(this,"find",e,t,i=>Vt(this,i),arguments)},findIndex(e,t){return ii(this,"findIndex",e,t,void 0,arguments)},findLast(e,t){return ii(this,"findLast",e,t,i=>Vt(this,i),arguments)},findLastIndex(e,t){return ii(this,"findLastIndex",e,t,void 0,arguments)},forEach(e,t){return ii(this,"forEach",e,t,void 0,arguments)},includes(...e){return no(this,"includes",e)},indexOf(...e){return no(this,"indexOf",e)},join(e){return Yi(this).join(e)},lastIndexOf(...e){return no(this,"lastIndexOf",e)},map(e,t){return ii(this,"map",e,t,void 0,arguments)},pop(){return wn(this,"pop")},push(...e){return wn(this,"push",e)},reduce(e,...t){return $r(this,"reduce",e,t)},reduceRight(e,...t){return $r(this,"reduceRight",e,t)},shift(){return wn(this,"shift")},some(e,t){return ii(this,"some",e,t,void 0,arguments)},splice(...e){return wn(this,"splice",e)},toReversed(){return Yi(this).toReversed()},toSorted(e){return Yi(this).toSorted(e)},toSpliced(...e){return Yi(this).toSpliced(...e)},unshift(...e){return wn(this,"unshift",e)},values(){return io(this,"values",e=>Vt(this,e))}};function io(e,t,i){const n=Hs(e),s=n[t]();return n!==e&&!Lt(e)&&(s._next=s.next,s.next=()=>{const o=s._next();return o.done||(o.value=i(o.value)),o}),s}const Bd=Array.prototype;function ii(e,t,i,n,s,o){const a=Hs(e),r=a!==e&&!Lt(e),l=a[t];if(l!==Bd[t]){const d=l.apply(e,o);return r?Ht(d):d}let c=i;a!==e&&(r?c=function(d,h){return i.call(this,Vt(e,d),h,e)}:i.length>2&&(c=function(d,h){return i.call(this,d,h,e)}));const u=l.call(a,c,n);return r&&s?s(u):u}function $r(e,t,i,n){const s=Hs(e),o=s!==e&&!Lt(e);let a=i,r=!1;s!==e&&(o?(r=n.length===0,a=function(c,u,d){return r&&(r=!1,c=Vt(e,c)),i.call(this,c,Vt(e,u),d,e)}):i.length>3&&(a=function(c,u,d){return i.call(this,c,u,d,e)}));const l=s[t](a,...n);return r?Vt(e,l):l}function no(e,t,i){const n=Fe(e);mt(n,"iterate",jn);const s=n[t](...i);return(s===-1||s===!1)&&Qo(i[0])?(i[0]=Fe(i[0]),n[t](...i)):s}function wn(e,t,i=[]){ui(),Ko();const n=Fe(e)[t].apply(e,i);return qo(),fi(),n}const Dd=Wo("__proto__,__v_isRef,__isVue"),ja=new Set(Object.getOwnPropertyNames(Symbol).filter(e=>e!=="arguments"&&e!=="caller").map(e=>Symbol[e]).filter(zt));function Ld(e){zt(e)||(e=String(e));const t=Fe(this);return mt(t,"has",e),t.hasOwnProperty(e)}class Wa{constructor(t=!1,i=!1){this._isReadonly=t,this._isShallow=i}get(t,i,n){if(i==="__v_skip")return t.__v_skip;const s=this._isReadonly,o=this._isShallow;if(i==="__v_isReactive")return!s;if(i==="__v_isReadonly")return s;if(i==="__v_isShallow")return o;if(i==="__v_raw")return n===(s?o?Ud:Ka:o?Ga:Va).get(t)||Object.getPrototypeOf(t)===Object.getPrototypeOf(n)?t:void 0;const a=Ee(t);if(!s){let l;if(a&&(l=Ad[i]))return l;if(i==="hasOwnProperty")return Ld}const r=Reflect.get(t,i,tt(t)?t:n);if((zt(i)?ja.has(i):Dd(i))||(s||mt(t,"get",i),o))return r;if(tt(r)){const l=a&&Vo(i)?r:r.value;return s&&Ke(l)?$o(l):l}return Ke(r)?s?$o(r):Fs(r):r}}class Ua extends Wa{constructor(t=!1){super(!1,t)}set(t,i,n,s){let o=t[i];const a=Ee(t)&&Vo(i);if(!this._isShallow){const c=pi(o);if(!Lt(n)&&!pi(n)&&(o=Fe(o),n=Fe(n)),!a&&tt(o)&&!tt(n))return c||(o.value=n),!0}const r=a?Number(i)<t.length:je(t,i),l=Reflect.set(t,i,n,tt(t)?t:s);return t===Fe(s)&&l&&(r?Kt(n,o)&&ai(t,"set",i,n):ai(t,"add",i,n)),l}deleteProperty(t,i){const n=je(t,i);t[i];const s=Reflect.deleteProperty(t,i);return s&&n&&ai(t,"delete",i,void 0),s}has(t,i){const n=Reflect.has(t,i);return(!zt(i)||!ja.has(i))&&mt(t,"has",i),n}ownKeys(t){return mt(t,"iterate",Ee(t)?"length":ji),Reflect.ownKeys(t)}}class Pd extends Wa{constructor(t=!1){super(!0,t)}set(t,i){return!0}deleteProperty(t,i){return!0}}const Od=new Ua,Rd=new Pd,Nd=new Ua(!0);const _o=e=>e,ns=e=>Reflect.getPrototypeOf(e);function zd(e,t,i){return function(...n){const s=this.__v_raw,o=Fe(s),a=rn(o),r=e==="entries"||e===Symbol.iterator&&a,l=e==="keys"&&a,c=s[e](...n),u=i?_o:t?un:Ht;return!t&&mt(o,"iterate",l?Co:ji),ut(Object.create(c),{next(){const{value:d,done:h}=c.next();return h?{value:d,done:h}:{value:r?[u(d[0]),u(d[1])]:u(d),done:h}}})}}function ss(e){return function(...t){return e==="delete"?!1:e==="clear"?void 0:this}}function Hd(e,t){const i={get(s){const o=this.__v_raw,a=Fe(o),r=Fe(s);e||(Kt(s,r)&&mt(a,"get",s),mt(a,"get",r));const{has:l}=ns(a),c=t?_o:e?un:Ht;if(l.call(a,s))return c(o.get(s));if(l.call(a,r))return c(o.get(r));o!==a&&o.get(s)},get size(){const s=this.__v_raw;return!e&&mt(Fe(s),"iterate",ji),s.size},has(s){const o=this.__v_raw,a=Fe(o),r=Fe(s);return e||(Kt(s,r)&&mt(a,"has",s),mt(a,"has",r)),s===r?o.has(s):o.has(s)||o.has(r)},forEach(s,o){const a=this,r=a.__v_raw,l=Fe(r),c=t?_o:e?un:Ht;return!e&&mt(l,"iterate",ji),r.forEach((u,d)=>s.call(o,c(u),c(d),a))}};return ut(i,e?{add:ss("add"),set:ss("set"),delete:ss("delete"),clear:ss("clear")}:{add(s){const o=Fe(this),a=ns(o),r=Fe(s),l=!t&&!Lt(s)&&!pi(s)?r:s;return a.has.call(o,l)||Kt(s,l)&&a.has.call(o,s)||Kt(r,l)&&a.has.call(o,r)||(o.add(l),ai(o,"add",l,l)),this},set(s,o){!t&&!Lt(o)&&!pi(o)&&(o=Fe(o));const a=Fe(this),{has:r,get:l}=ns(a);let c=r.call(a,s);c||(s=Fe(s),c=r.call(a,s));const u=l.call(a,s);return a.set(s,o),c?Kt(o,u)&&ai(a,"set",s,o):ai(a,"add",s,o),this},delete(s){const o=Fe(this),{has:a,get:r}=ns(o);let l=a.call(o,s);l||(s=Fe(s),l=a.call(o,s)),r&&r.call(o,s);const c=o.delete(s);return l&&ai(o,"delete",s,void 0),c},clear(){const s=Fe(this),o=s.size!==0,a=s.clear();return o&&ai(s,"clear",void 0,void 0),a}}),["keys","values","entries",Symbol.iterator].forEach(s=>{i[s]=zd(s,e,t)}),i}function Jo(e,t){const i=Hd(e,t);return(n,s,o)=>s==="__v_isReactive"?!e:s==="__v_isReadonly"?e:s==="__v_raw"?n:Reflect.get(je(i,s)&&s in n?i:n,s,o)}const Fd={get:Jo(!1,!1)},jd={get:Jo(!1,!0)},Wd={get:Jo(!0,!1)};const Va=new WeakMap,Ga=new WeakMap,Ka=new WeakMap,Ud=new WeakMap;function Vd(e){switch(e){case"Object":case"Array":return 1;case"Map":case"Set":case"WeakMap":case"WeakSet":return 2;default:return 0}}function Fs(e){return pi(e)?e:Xo(e,!1,Od,Fd,Va)}function Gd(e){return Xo(e,!1,Nd,jd,Ga)}function $o(e){return Xo(e,!0,Rd,Wd,Ka)}function Xo(e,t,i,n,s){if(!Ke(e)||e.__v_raw&&!(t&&e.__v_isReactive)||e.__v_skip||!Object.isExtensible(e))return e;const o=s.get(e);if(o)return o;const a=Vd(vd(e));if(a===0)return e;const r=new Proxy(e,a===2?n:i);return s.set(e,r),r}function Wi(e){return pi(e)?Wi(e.__v_raw):!!(e&&e.__v_isReactive)}function pi(e){return!!(e&&e.__v_isReadonly)}function Lt(e){return!!(e&&e.__v_isShallow)}function Qo(e){return e?!!e.__v_raw:!1}function Fe(e){const t=e&&e.__v_raw;return t?Fe(t):e}function Kd(e){return!je(e,"__v_skip")&&Object.isExtensible(e)&&Ea(e,"__v_skip",!0),e}const Ht=e=>Ke(e)?Fs(e):e,un=e=>Ke(e)?$o(e):e;function tt(e){return e?e.__v_isRef===!0:!1}function ve(e){return qd(e,!1)}function qd(e,t){return tt(e)?e:new Yd(e,t)}class Yd{constructor(t,i){this.dep=new Zo,this.__v_isRef=!0,this.__v_isShallow=!1,this._rawValue=i?t:Fe(t),this._value=i?t:Ht(t),this.__v_isShallow=i}get value(){return this.dep.track(),this._value}set value(t){const i=this._rawValue,n=this.__v_isShallow||Lt(t)||pi(t);t=n?t:Fe(t),Kt(t,i)&&(this._rawValue=t,this._value=n?t:Ht(t),this.dep.trigger())}}function me(e){return tt(e)?e.value:e}const Zd={get:(e,t,i)=>t==="__v_raw"?e:me(Reflect.get(e,t,i)),set:(e,t,i,n)=>{const s=e[t];return tt(s)&&!tt(i)?(s.value=i,!0):Reflect.set(e,t,i,n)}};function qa(e){return Wi(e)?e:new Proxy(e,Zd)}class Jd{constructor(t,i,n){this.fn=t,this.setter=i,this._value=void 0,this.dep=new Zo(this),this.__v_isRef=!0,this.deps=void 0,this.depsTail=void 0,this.flags=16,this.globalVersion=Fn-1,this.next=void 0,this.effect=this,this.__v_isReadonly=!i,this.isSSR=n}notify(){if(this.flags|=16,!(this.flags&8)&&Qe!==this)return Oa(this,!0),!0}get value(){const t=this.dep.track();return za(this),t&&(t.version=this.dep.version),this._value}set value(t){this.setter&&this.setter(t)}}function Xd(e,t,i=!1){let n,s;return Be(e)?n=e:(n=e.get,s=e.set),new Jd(n,s,i)}const os={},_s=new WeakMap;let Oi;function Qd(e,t=!1,i=Oi){if(i){let n=_s.get(i);n||_s.set(i,n=[]),n.push(e)}}function eu(e,t,i=Je){const{immediate:n,deep:s,once:o,scheduler:a,augmentJob:r,call:l}=i,c=w=>s?w:Lt(w)||s===!1||s===0?li(w,1):li(w);let u,d,h,f,v=!1,m=!1;if(tt(e)?(d=()=>e.value,v=Lt(e)):Wi(e)?(d=()=>c(e),v=!0):Ee(e)?(m=!0,v=e.some(w=>Wi(w)||Lt(w)),d=()=>e.map(w=>{if(tt(w))return w.value;if(Wi(w))return c(w);if(Be(w))return l?l(w,2):w()})):Be(e)?t?d=l?()=>l(e,2):e:d=()=>{if(h){ui();try{h()}finally{fi()}}const w=Oi;Oi=u;try{return l?l(e,3,[f]):e(f)}finally{Oi=w}}:d=Xt,t&&s){const w=d,$=s===!0?1/0:s;d=()=>li(w(),$)}const b=Md(),y=()=>{u.stop(),b&&b.active&&Uo(b.effects,u)};if(o&&t){const w=t;t=(...$)=>{const E=w(...$);return y(),E}}let x=m?new Array(e.length).fill(os):os;const S=w=>{if(!(!(u.flags&1)||!u.dirty&&!w))if(t){const $=u.run();if(w||s||v||(m?$.some((E,C)=>Kt(E,x[C])):Kt($,x))){h&&h();const E=Oi;Oi=u;try{const C=[$,x===os?void 0:m&&x[0]===os?[]:x,f];x=$,l?l(t,3,C):t(...C)}finally{Oi=E}}}else u.run()};return r&&r(S),u=new La(d),u.scheduler=a?()=>a(S,!1):S,f=w=>Qd(w,!1,u),h=u.onStop=()=>{const w=_s.get(u);if(w){if(l)l(w,4);else for(const $ of w)$();_s.delete(u)}},t?n?S(!0):x=u.run():a?a(S.bind(null,!0),!0):u.run(),y.pause=u.pause.bind(u),y.resume=u.resume.bind(u),y.stop=y,y}function li(e,t=1/0,i){if(t<=0||!Ke(e)||e.__v_skip||(i=i||new Map,(i.get(e)||0)>=t))return e;if(i.set(e,t),t--,tt(e))li(e.value,t,i);else if(Ee(e))for(let n=0;n<e.length;n++)li(e[n],t,i);else if(hn(e)||rn(e))e.forEach(n=>{li(n,t,i)});else if(Ta(e)){for(const n in e)li(e[n],t,i);for(const n of Object.getOwnPropertySymbols(e))Object.prototype.propertyIsEnumerable.call(e,n)&&li(e[n],t,i)}return e}/**
* @vue/runtime-core v3.5.40
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/function Jn(e,t,i,n){try{return n?e(...n):e()}catch(s){js(s,t,i)}}function Ft(e,t,i,n){if(Be(e)){const s=Jn(e,t,i,n);return s&&Ia(s)&&s.catch(o=>{js(o,t,i)}),s}if(Ee(e)){const s=[];for(let o=0;o<e.length;o++)s.push(Ft(e[o],t,i,n));return s}}function js(e,t,i,n=!0){const s=t?t.vnode:null,{errorHandler:o,throwUnhandledErrorInProduction:a}=t&&t.appContext.config||Je;if(t){let r=t.parent;const l=t.proxy,c=`https://vuejs.org/error-reference/#runtime-${i}`;for(;r;){const u=r.ec;if(u){for(let d=0;d<u.length;d++)if(u[d](e,l,c)===!1)return}r=r.parent}if(o){ui(),Jn(o,null,10,[e,l,c]),fi();return}}tu(e,i,s,n,a)}function tu(e,t,i,n=!0,s=!1){if(s)throw e;console.error(e)}const kt=[];let Wt=-1;const an=[];let wi=null,Zi=0;const Ya=Promise.resolve();let $s=null;function Is(e){const t=$s||Ya;return e?t.then(this?e.bind(this):e):t}function iu(e){let t=Wt+1,i=kt.length;for(;t<i;){const n=t+i>>>1,s=kt[n],o=Wn(s);o<e||o===e&&s.flags&2?t=n+1:i=n}return t}function er(e){if(!(e.flags&1)){const t=Wn(e),i=kt[kt.length-1];!i||!(e.flags&2)&&t>=Wn(i)?kt.push(e):kt.splice(iu(t),0,e),e.flags|=1,Za()}}function Za(){$s||($s=Ya.then(Xa))}function nu(e){Ee(e)?an.push(...e):wi&&e.id===-1?wi.splice(Zi+1,0,e):e.flags&1||(an.push(e),e.flags|=1),Za()}function Ir(e,t,i=Wt+1){for(;i<kt.length;i++){const n=kt[i];if(n&&n.flags&2){if(e&&n.id!==e.uid)continue;kt.splice(i,1),i--,n.flags&4&&(n.flags&=-2),n(),n.flags&4||(n.flags&=-2)}}}function Ja(e){if(an.length){const t=[...new Set(an)].sort((i,n)=>Wn(i)-Wn(n));if(an.length=0,wi){wi.push(...t);return}for(wi=t,Zi=0;Zi<wi.length;Zi++){const i=wi[Zi];i.flags&4&&(i.flags&=-2),i.flags&8||i(),i.flags&=-2}wi=null,Zi=0}}const Wn=e=>e.id==null?e.flags&2?-1:1/0:e.id;function Xa(e){try{for(Wt=0;Wt<kt.length;Wt++){const t=kt[Wt];t&&!(t.flags&8)&&(t.flags&4&&(t.flags&=-2),Jn(t,t.i,t.i?15:14),t.flags&4||(t.flags&=-2))}}finally{for(;Wt<kt.length;Wt++){const t=kt[Wt];t&&(t.flags&=-2)}Wt=-1,kt.length=0,Ja(),$s=null,(kt.length||an.length)&&Xa()}}let dt=null,Qa=null;function Ms(e){const t=dt;return dt=e,Qa=e&&e.type.__scopeId||null,t}function el(e,t=dt,i){if(!t||e._n)return e;const n=(...s)=>{n._d&&zr(-1);const o=Ms(t),a=ci.length;let r;try{r=e(...s)}finally{for(let l=ci.length;l>a;l--)or();Ms(o),n._d&&zr(1)}return r};return n._n=!0,n._c=!0,n._d=!0,n}function Pt(e,t){if(dt===null)return e;const i=Ks(dt),n=e.dirs||(e.dirs=[]);for(let s=0;s<t.length;s++){let[o,a,r,l=Je]=t[s];o&&(Be(o)&&(o={mounted:o,updated:o}),o.deep&&li(a),n.push({dir:o,instance:i,value:a,oldValue:void 0,arg:r,modifiers:l}))}return e}function Bi(e,t,i,n){const s=e.dirs,o=t&&t.dirs;for(let a=0;a<s.length;a++){const r=s[a];o&&(r.oldValue=o[a].value);let l=r.dir[n];l&&(ui(),Ft(l,i,8,[e.el,r,e,t]),fi())}}function su(e,t){if(vt){let i=vt.provides;const n=vt.parent&&vt.parent.provides;n===i&&(i=vt.provides=Object.create(n)),i[e]=t}}function Nt(e,t,i=!1){const n=nf();if(n||cn){let s=cn?cn._context.provides:n?n.parent==null||n.ce?n.vnode.appContext&&n.vnode.appContext.provides:n.parent.provides:void 0;if(s&&e in s)return s[e];if(arguments.length>1)return i&&Be(t)?t.call(n&&n.proxy):t}}const ou=Symbol.for("v-scx"),ru=()=>Nt(ou);function Ui(e,t,i){return tl(e,t,i)}function tl(e,t,i=Je){const{immediate:n,deep:s,flush:o,once:a}=i,r=ut({},i),l=t&&n||!t&&o!=="post";let c;if(Vn){if(o==="sync"){const f=ru();c=f.__watcherHandles||(f.__watcherHandles=[])}else if(!l){const f=()=>{};return f.stop=Xt,f.resume=Xt,f.pause=Xt,f}}const u=vt;r.call=(f,v,m)=>Ft(f,u,v,m);let d=!1;o==="post"?r.scheduler=f=>{Ct(f,u&&u.suspense)}:o!=="sync"&&(d=!0,r.scheduler=(f,v)=>{v?f():er(f)}),r.augmentJob=f=>{t&&(f.flags|=4),d&&(f.flags|=2,u&&(f.id=u.uid,f.i=u))};const h=eu(e,t,r);return Vn&&(c?c.push(h):l&&h()),h}function au(e,t,i){const n=this.proxy,s=nt(e)?e.includes(".")?il(n,e):()=>n[e]:e.bind(n,n);let o;Be(t)?o=t:(o=t.handler,i=t);const a=Xn(this),r=tl(s,o.bind(n),i);return a(),r}function il(e,t){const i=t.split(".");return()=>{let n=e;for(let s=0;s<i.length&&n;s++)n=n[i[s]];return n}}const lu=Symbol("_vte"),cu=e=>e.__isTeleport,so=Symbol("_leaveCb");function tr(e,t){e.shapeFlag&6&&e.component?(e.transition=t,tr(e.component.subTree,t)):e.shapeFlag&128?(e.ssContent.transition=t.clone(e.ssContent),e.ssFallback.transition=t.clone(e.ssFallback)):e.transition=t}function At(e,t){return Be(e)?ut({name:e.name},t,{setup:e}):e}function nl(e){e.ids=[e.ids[0]+e.ids[2]+++"-",0,0]}function Mr(e,t){let i;return!!((i=Object.getOwnPropertyDescriptor(e,t))&&!i.configurable)}const Ts=new WeakMap;function An(e,t,i,n,s=!1){if(Ee(e)){e.forEach((m,b)=>An(m,t&&(Ee(t)?t[b]:t),i,n,s));return}if(ln(n)&&!s){n.shapeFlag&512&&n.type.__asyncResolved&&n.component.subTree.component&&An(e,t,i,n.component.subTree);return}const o=n.shapeFlag&4?Ks(n.component):n.el,a=s?null:o,{i:r,r:l}=e,c=t&&t.r,u=r.refs===Je?r.refs={}:r.refs,d=r.setupState,h=Fe(d),f=d===Je?$a:m=>Mr(u,m)?!1:je(h,m),v=(m,b)=>!(b&&Mr(u,b));if(c!=null&&c!==l){if(Tr(t),nt(c))u[c]=null,f(c)&&(d[c]=null);else if(tt(c)){const m=t;v(c,m.k)&&(c.value=null),m.k&&(u[m.k]=null)}}if(Be(l))Jn(l,r,12,[a,u]);else{const m=nt(l),b=tt(l);if(m||b){const y=()=>{if(e.f){const x=m?f(l)?d[l]:u[l]:v()||!e.k?l.value:u[e.k];if(s)Ee(x)&&Uo(x,o);else if(Ee(x))x.includes(o)||x.push(o);else if(m)u[l]=[o],f(l)&&(d[l]=u[l]);else{const S=[o];v(l,e.k)&&(l.value=S),e.k&&(u[e.k]=S)}}else m?(u[l]=a,f(l)&&(d[l]=a)):b&&(v(l,e.k)&&(l.value=a),e.k&&(u[e.k]=a))};if(a){const x=()=>{y(),Ts.delete(e)};x.id=-1,Ts.set(e,x),Ct(x,i)}else Tr(e),y()}}}function Tr(e){const t=Ts.get(e);t&&(t.flags|=8,Ts.delete(e))}zs().requestIdleCallback;zs().cancelIdleCallback;const ln=e=>!!e.type.__asyncLoader,sl=e=>e.type.__isKeepAlive;function du(e,t){ol(e,"a",t)}function uu(e,t){ol(e,"da",t)}function ol(e,t,i=vt){const n=e.__wdc||(e.__wdc=()=>{let s=i;for(;s;){if(s.isDeactivated)return;s=s.parent}return e()});if(Ws(t,n,i),i){let s=i.parent;for(;s&&s.parent;)sl(s.parent.vnode)&&fu(n,t,i,s),s=s.parent}}function fu(e,t,i,n){const s=Ws(t,e,n,!0);Us(()=>{Uo(n[t],s)},i)}function Ws(e,t,i=vt,n=!1){if(i){const s=i[e]||(i[e]=[]),o=t.__weh||(t.__weh=(...a)=>{ui();const r=Xn(i),l=Ft(t,i,e,a);return r(),fi(),l});return n?s.unshift(o):s.push(o),o}}const mi=e=>(t,i=vt)=>{(!Vn||e==="sp")&&Ws(e,(...n)=>t(...n),i)},pu=mi("bm"),gn=mi("m"),hu=mi("bu"),mu=mi("u"),ir=mi("bum"),Us=mi("um"),gu=mi("sp"),vu=mi("rtg"),bu=mi("rtc");function yu(e,t=vt){Ws("ec",e,t)}const ku="components";function wu(e,t){return Su(ku,e,!0,t)||e}const xu=Symbol.for("v-ndc");function Su(e,t,i=!0,n=!1){const s=dt||vt;if(s){const o=s.type;{const r=lf(o,!1);if(r&&(r===t||r===St(t)||r===Rs(St(t))))return o}const a=Er(s[e]||o[e],t)||Er(s.appContext[e],t);return!a&&n?o:a}}function Er(e,t){return e&&(e[t]||e[St(t)]||e[Rs(St(t))])}function xt(e,t,i,n){let s;const o=i,a=Ee(e);if(a||nt(e)){const r=a&&Wi(e);let l=!1,c=!1;r&&(l=!Lt(e),c=pi(e),e=Hs(e)),s=new Array(e.length);for(let u=0,d=e.length;u<d;u++)s[u]=t(l?c?un(Ht(e[u])):Ht(e[u]):e[u],u,void 0,o)}else if(typeof e=="number"){s=new Array(e);for(let r=0;r<e;r++)s[r]=t(r+1,r,void 0,o)}else if(Ke(e))if(e[Symbol.iterator])s=Array.from(e,(r,l)=>t(r,l,void 0,o));else{const r=Object.keys(e);s=new Array(r.length);for(let l=0,c=r.length;l<c;l++){const u=r[l];s[l]=t(e[u],u,l,o)}}else s=[];return s}function rs(e,t,i={},n,s,o){if(dt.ce||dt.parent&&ln(dt.parent)&&dt.parent.ce){const c=i,u=Object.keys(c).length>0;return t!=="default"&&(c.name=t),X(),Zt(Xe,null,[ae("slot",c,n&&n())],u?-2:64)}let a=e[t];a&&a._c&&(a._d=!1);const r=ci.length;X();let l;try{const c=a&&rl(a(i)),u=i.key||o||c&&c.key;l=Zt(Xe,{key:(u&&!zt(u)?u:`_${t}`)+(!c&&n?"_fb":"")},c||(n?n():[]),c&&e._===1?64:-2)}catch(c){for(let u=ci.length;u>r;u--)or();throw c}finally{a&&a._c&&(a._d=!0)}return l}function rl(e){return e.some(t=>rr(t)?!(t.type===hi||t.type===Xe&&!rl(t.children)):!0)?e:null}const Io=e=>e?$l(e)?Ks(e):Io(e.parent):null,Bn=ut(Object.create(null),{$:e=>e,$el:e=>e.vnode.el,$data:e=>e.data,$props:e=>e.props,$attrs:e=>e.attrs,$slots:e=>e.slots,$refs:e=>e.refs,$parent:e=>Io(e.parent),$root:e=>Io(e.root),$host:e=>e.ce,$emit:e=>e.emit,$options:e=>ll(e),$forceUpdate:e=>e.f||(e.f=()=>{er(e.update)}),$nextTick:e=>e.n||(e.n=Is.bind(e.proxy)),$watch:e=>au.bind(e)}),oo=(e,t)=>e!==Je&&!e.__isScriptSetup&&je(e,t),Cu={get({_:e},t){if(t==="__v_skip")return!0;const{ctx:i,setupState:n,data:s,props:o,accessCache:a,type:r,appContext:l}=e;if(t[0]!=="$"){const h=a[t];if(h!==void 0)switch(h){case 1:return n[t];case 2:return s[t];case 4:return i[t];case 3:return o[t]}else{if(oo(n,t))return a[t]=1,n[t];if(s!==Je&&je(s,t))return a[t]=2,s[t];if(je(o,t))return a[t]=3,o[t];if(i!==Je&&je(i,t))return a[t]=4,i[t];Mo&&(a[t]=0)}}const c=Bn[t];let u,d;if(c)return t==="$attrs"&&mt(e.attrs,"get",""),c(e);if((u=r.__cssModules)&&(u=u[t]))return u;if(i!==Je&&je(i,t))return a[t]=4,i[t];if(d=l.config.globalProperties,je(d,t))return d[t]},set({_:e},t,i){const{data:n,setupState:s,ctx:o}=e;return oo(s,t)?(s[t]=i,!0):n!==Je&&je(n,t)?(n[t]=i,!0):je(e.props,t)||t[0]==="$"&&t.slice(1)in e?!1:(o[t]=i,!0)},has({_:{data:e,setupState:t,accessCache:i,ctx:n,appContext:s,props:o,type:a}},r){let l;return!!(i[r]||e!==Je&&r[0]!=="$"&&je(e,r)||oo(t,r)||je(o,r)||je(n,r)||je(Bn,r)||je(s.config.globalProperties,r)||(l=a.__cssModules)&&l[r])},defineProperty(e,t,i){return i.get!=null?e._.accessCache[t]=0:je(i,"value")&&this.set(e,t,i.value,null),Reflect.defineProperty(e,t,i)}};function Ar(e){return Ee(e)?e.reduce((t,i)=>(t[i]=null,t),{}):e}let Mo=!0;function _u(e){const t=ll(e),i=e.proxy,n=e.ctx;Mo=!1,t.beforeCreate&&Br(t.beforeCreate,e,"bc");const{data:s,computed:o,methods:a,watch:r,provide:l,inject:c,created:u,beforeMount:d,mounted:h,beforeUpdate:f,updated:v,activated:m,deactivated:b,beforeDestroy:y,beforeUnmount:x,destroyed:S,unmounted:w,render:$,renderTracked:E,renderTriggered:C,errorCaptured:L,serverPrefetch:z,expose:H,inheritAttrs:q,components:_,directives:N,filters:k}=t;if(c&&$u(c,n,null),a)for(const M in a){const B=a[M];Be(B)&&(n[M]=B.bind(i))}if(s){const M=s.call(i,i);Ke(M)&&(e.data=Fs(M))}if(Mo=!0,o)for(const M in o){const B=o[M],P=Be(B)?B.bind(i,i):Be(B.get)?B.get.bind(i,i):Xt,se=!Be(B)&&Be(B.set)?B.set.bind(i):Xt,G=xe({get:P,set:se});Object.defineProperty(n,M,{enumerable:!0,configurable:!0,get:()=>G.value,set:K=>G.value=K})}if(r)for(const M in r)al(r[M],n,i,M);if(l){const M=Be(l)?l.call(i):l;Reflect.ownKeys(M).forEach(B=>{su(B,M[B])})}u&&Br(u,e,"c");function F(M,B){Ee(B)?B.forEach(P=>M(P.bind(i))):B&&M(B.bind(i))}if(F(pu,d),F(gn,h),F(hu,f),F(mu,v),F(du,m),F(uu,b),F(yu,L),F(bu,E),F(vu,C),F(ir,x),F(Us,w),F(gu,z),Ee(H))if(H.length){const M=e.exposed||(e.exposed={});H.forEach(B=>{Object.defineProperty(M,B,{get:()=>i[B],set:P=>i[B]=P,enumerable:!0})})}else e.exposed||(e.exposed={});$&&e.render===Xt&&(e.render=$),q!=null&&(e.inheritAttrs=q),_&&(e.components=_),N&&(e.directives=N),z&&nl(e)}function $u(e,t,i=Xt){Ee(e)&&(e=To(e));for(const n in e){const s=e[n];let o;Ke(s)?"default"in s?o=Nt(s.from||n,s.default,!0):o=Nt(s.from||n):o=Nt(s),tt(o)?Object.defineProperty(t,n,{enumerable:!0,configurable:!0,get:()=>o.value,set:a=>o.value=a}):t[n]=o}}function Br(e,t,i){Ft(Ee(e)?e.map(n=>n.bind(t.proxy)):e.bind(t.proxy),t,i)}function al(e,t,i,n){let s=n.includes(".")?il(i,n):()=>i[n];if(nt(e)){const o=t[e];Be(o)&&Ui(s,o)}else if(Be(e))Ui(s,e.bind(i));else if(Ke(e))if(Ee(e))e.forEach(o=>al(o,t,i,n));else{const o=Be(e.handler)?e.handler.bind(i):t[e.handler];Be(o)&&Ui(s,o,e)}}function ll(e){const t=e.type,{mixins:i,extends:n}=t,{mixins:s,optionsCache:o,config:{optionMergeStrategies:a}}=e.appContext,r=o.get(t);let l;return r?l=r:!s.length&&!i&&!n?l=t:(l={},s.length&&s.forEach(c=>Es(l,c,a,!0)),Es(l,t,a)),Ke(t)&&o.set(t,l),l}function Es(e,t,i,n=!1){const{mixins:s,extends:o}=t;o&&Es(e,o,i,!0),s&&s.forEach(a=>Es(e,a,i,!0));for(const a in t)if(!(n&&a==="expose")){const r=Iu[a]||i&&i[a];e[a]=r?r(e[a],t[a]):t[a]}return e}const Iu={data:Dr,props:Lr,emits:Lr,methods:Cn,computed:Cn,beforeCreate:yt,created:yt,beforeMount:yt,mounted:yt,beforeUpdate:yt,updated:yt,beforeDestroy:yt,beforeUnmount:yt,destroyed:yt,unmounted:yt,activated:yt,deactivated:yt,errorCaptured:yt,serverPrefetch:yt,components:Cn,directives:Cn,watch:Tu,provide:Dr,inject:Mu};function Dr(e,t){return t?e?function(){return ut(Be(e)?e.call(this,this):e,Be(t)?t.call(this,this):t)}:t:e}function Mu(e,t){return Cn(To(e),To(t))}function To(e){if(Ee(e)){const t={};for(let i=0;i<e.length;i++)t[e[i]]=e[i];return t}return e}function yt(e,t){return e?[...new Set([].concat(e,t))]:t}function Cn(e,t){return e?ut(Object.create(null),e,t):t}function Lr(e,t){return e?Ee(e)&&Ee(t)?[...new Set([...e,...t])]:ut(Object.create(null),Ar(e),Ar(t??{})):t}function Tu(e,t){if(!e)return t;if(!t)return e;const i=ut(Object.create(null),e);for(const n in t)i[n]=yt(e[n],t[n]);return i}function cl(){return{app:null,config:{isNativeTag:$a,performance:!1,globalProperties:{},optionMergeStrategies:{},errorHandler:void 0,warnHandler:void 0,compilerOptions:{}},mixins:[],components:{},directives:{},provides:Object.create(null),optionsCache:new WeakMap,propsCache:new WeakMap,emitsCache:new WeakMap}}let Eu=0;function Au(e,t){return function(n,s=null){Be(n)||(n=ut({},n)),s!=null&&!Ke(s)&&(s=null);const o=cl(),a=new WeakSet,r=[];let l=!1;const c=o.app={_uid:Eu++,_component:n,_props:s,_container:null,_context:o,_instance:null,version:df,get config(){return o.config},set config(u){},use(u,...d){return a.has(u)||(u&&Be(u.install)?(a.add(u),u.install(c,...d)):Be(u)&&(a.add(u),u(c,...d))),c},mixin(u){return o.mixins.includes(u)||o.mixins.push(u),c},component(u,d){return d?(o.components[u]=d,c):o.components[u]},directive(u,d){return d?(o.directives[u]=d,c):o.directives[u]},mount(u,d,h){if(!l){const f=c._ceVNode||ae(n,s);return f.appContext=o,h===!0?h="svg":h===!1&&(h=void 0),e(f,u,h),l=!0,c._container=u,u.__vue_app__=c,Ks(f.component)}},onUnmount(u){r.push(u)},unmount(){l&&(Ft(r,c._instance,16),e(null,c._container),delete c._container.__vue_app__)},provide(u,d){return o.provides[u]=d,c},runWithContext(u){const d=cn;cn=c;try{return u()}finally{cn=d}}};return c}}let cn=null;const Bu=(e,t)=>t==="modelValue"||t==="model-value"?e.modelModifiers:e[`${t}Modifiers`]||e[`${St(t)}Modifiers`]||e[`${Ei(t)}Modifiers`];function Du(e,t,...i){if(e.isUnmounted)return;const n=e.vnode.props||Je;let s=i;const o=t.startsWith("update:"),a=o&&Bu(n,t.slice(7));a&&(a.trim&&(s=i.map(u=>nt(u)?u.trim():u)),a.number&&(s=i.map(Ns)));let r,l=n[r=Qs(t)]||n[r=Qs(St(t))];!l&&o&&(l=n[r=Qs(Ei(t))]),l&&Ft(l,e,6,s);const c=n[r+"Once"];if(c){if(!e.emitted)e.emitted={};else if(e.emitted[r])return;e.emitted[r]=!0,Ft(c,e,6,s)}}const Lu=new WeakMap;function dl(e,t,i=!1){const n=i?Lu:t.emitsCache,s=n.get(e);if(s!==void 0)return s;const o=e.emits;let a={},r=!1;if(!Be(e)){const l=c=>{const u=dl(c,t,!0);u&&(r=!0,ut(a,u))};!i&&t.mixins.length&&t.mixins.forEach(l),e.extends&&l(e.extends),e.mixins&&e.mixins.forEach(l)}return!o&&!r?(Ke(e)&&n.set(e,null),null):(Ee(o)?o.forEach(l=>a[l]=null):ut(a,o),Ke(e)&&n.set(e,a),a)}function Vs(e,t){return!e||!Ls(t)?!1:(t=t.slice(2),t=t==="Once"?t:t.replace(/Once$/,""),je(e,t[0].toLowerCase()+t.slice(1))||je(e,Ei(t))||je(e,t))}function Pr(e){const{type:t,vnode:i,proxy:n,withProxy:s,propsOptions:[o],slots:a,attrs:r,emit:l,render:c,renderCache:u,props:d,data:h,setupState:f,ctx:v,inheritAttrs:m}=e,b=Ms(e);let y,x;try{if(i.shapeFlag&4){const w=s||n,$=w;y=Gt(c.call($,w,u,d,f,h,v)),x=r}else{const w=t;y=Gt(w.length>1?w(d,{attrs:r,slots:a,emit:l}):w(d,null)),x=t.props?r:Pu(r)}}catch(w){ci.length=0,js(w,e,1),y=ae(hi)}let S=y;if(x&&m!==!1){const w=Object.keys(x),{shapeFlag:$}=S;w.length&&$&7&&(o&&w.some(Ps)&&(x=Ou(x,o)),S=fn(S,x,!1,!0))}return i.dirs&&(S=fn(S,null,!1,!0),S.dirs=S.dirs?S.dirs.concat(i.dirs):i.dirs),i.transition&&tr(S,i.transition),y=S,Ms(b),y}const Pu=e=>{let t;for(const i in e)(i==="class"||i==="style"||Ls(i))&&((t||(t={}))[i]=e[i]);return t},Ou=(e,t)=>{const i={};for(const n in e)(!Ps(n)||!(n.slice(9)in t))&&(i[n]=e[n]);return i};function Ru(e,t,i){const{props:n,children:s,component:o}=e,{props:a,children:r,patchFlag:l}=t,c=o.emitsOptions;if(t.dirs||t.transition)return!0;if(i&&l>=0){if(l&1024)return!0;if(l&16)return n?Or(n,a,c):!!a;if(l&8){const u=t.dynamicProps;for(let d=0;d<u.length;d++){const h=u[d];if(ul(a,n,h)&&!Vs(c,h))return!0}}}else return(s||r)&&(!r||!r.$stable)?!0:n===a?!1:n?a?Or(n,a,c):!0:!!a;return!1}function Or(e,t,i){const n=Object.keys(t);if(n.length!==Object.keys(e).length)return!0;for(let s=0;s<n.length;s++){const o=n[s];if(ul(t,e,o)&&!Vs(i,o))return!0}return!1}function ul(e,t,i){const n=e[i],s=t[i];return i==="style"&&Ke(n)&&Ke(s)?!mn(n,s):n!==s}function Nu({vnode:e,parent:t,suspense:i},n){for(;t;){const s=t.subTree;if(s.suspense&&s.suspense.activeBranch===e&&(s.suspense.vnode.el=s.el=n,e=s),s===e)(e=t.vnode).el=n,t=t.parent;else break}i&&i.activeBranch===e&&(i.vnode.el=n)}const fl={},pl=()=>Object.create(fl),hl=e=>Object.getPrototypeOf(e)===fl;function zu(e,t,i,n=!1){const s={},o=pl();e.propsDefaults=Object.create(null),ml(e,t,s,o);for(const a in e.propsOptions[0])a in s||(s[a]=void 0);i?e.props=n?s:Gd(s):e.type.props?e.props=s:e.props=o,e.attrs=o}function Hu(e,t,i,n){const{props:s,attrs:o,vnode:{patchFlag:a}}=e,r=Fe(s),[l]=e.propsOptions;let c=!1;if((n||a>0)&&!(a&16)){if(a&8){const u=e.vnode.dynamicProps;for(let d=0;d<u.length;d++){let h=u[d];if(Vs(e.emitsOptions,h))continue;const f=t[h];if(l)if(je(o,h))f!==o[h]&&(o[h]=f,c=!0);else{const v=St(h);s[v]=Eo(l,r,v,f,e,!1)}else f!==o[h]&&(o[h]=f,c=!0)}}}else{ml(e,t,s,o)&&(c=!0);let u;for(const d in r)(!t||!je(t,d)&&((u=Ei(d))===d||!je(t,u)))&&(l?i&&(i[d]!==void 0||i[u]!==void 0)&&(s[d]=Eo(l,r,d,void 0,e,!0)):delete s[d]);if(o!==r)for(const d in o)(!t||!je(t,d))&&(delete o[d],c=!0)}c&&ai(e.attrs,"set","")}function ml(e,t,i,n){const[s,o]=e.propsOptions;let a=!1,r;if(t)for(let l in t){if(Mn(l))continue;const c=t[l];let u;s&&je(s,u=St(l))?!o||!o.includes(u)?i[u]=c:(r||(r={}))[u]=c:Vs(e.emitsOptions,l)||(!(l in n)||c!==n[l])&&(n[l]=c,a=!0)}if(o){const l=Fe(i),c=r||Je;for(let u=0;u<o.length;u++){const d=o[u];i[d]=Eo(s,l,d,c[d],e,!je(c,d))}}return a}function Eo(e,t,i,n,s,o){const a=e[i];if(a!=null){const r=je(a,"default");if(r&&n===void 0){const l=a.default;if(a.type!==Function&&!a.skipFactory&&Be(l)){const{propsDefaults:c}=s;if(i in c)n=c[i];else{const u=Xn(s);n=c[i]=l.call(null,t),u()}}else n=l;s.ce&&s.ce._setProp(i,n)}a[0]&&(o&&!r?n=!1:a[1]&&(n===""||n===Ei(i))&&(n=!0))}return n}const Fu=new WeakMap;function gl(e,t,i=!1){const n=i?Fu:t.propsCache,s=n.get(e);if(s)return s;const o=e.props,a={},r=[];let l=!1;if(!Be(e)){const u=d=>{l=!0;const[h,f]=gl(d,t,!0);ut(a,h),f&&r.push(...f)};!i&&t.mixins.length&&t.mixins.forEach(u),e.extends&&u(e.extends),e.mixins&&e.mixins.forEach(u)}if(!o&&!l)return Ke(e)&&n.set(e,on),on;if(Ee(o))for(let u=0;u<o.length;u++){const d=St(o[u]);Rr(d)&&(a[d]=Je)}else if(o)for(const u in o){const d=St(u);if(Rr(d)){const h=o[u],f=a[d]=Ee(h)||Be(h)?{type:h}:ut({},h),v=f.type;let m=!1,b=!0;if(Ee(v))for(let y=0;y<v.length;++y){const x=v[y],S=Be(x)&&x.name;if(S==="Boolean"){m=!0;break}else S==="String"&&(b=!1)}else m=Be(v)&&v.name==="Boolean";f[0]=m,f[1]=b,(m||je(f,"default"))&&r.push(d)}}const c=[a,r];return Ke(e)&&n.set(e,c),c}function Rr(e){return e[0]!=="$"&&!Mn(e)}const nr=e=>e==="_"||e==="_ctx"||e==="$stable",sr=e=>Ee(e)?e.map(Gt):[Gt(e)],ju=(e,t,i)=>{if(t._n)return t;const n=el((...s)=>sr(t(...s)),i);return n._c=!1,n},vl=(e,t,i)=>{const n=e._ctx;for(const s in e){if(nr(s))continue;const o=e[s];if(Be(o))t[s]=ju(s,o,n);else if(o!=null){const a=sr(o);t[s]=()=>a}}},bl=(e,t)=>{const i=sr(t);e.slots.default=()=>i},yl=(e,t,i)=>{for(const n in t)(i||!nr(n))&&(e[n]=t[n])},Wu=(e,t,i)=>{const n=e.slots=pl();if(e.vnode.shapeFlag&32){const s=t._;s?(yl(n,t,i),i&&Ea(n,"_",s,!0)):vl(t,n)}else t&&bl(e,t)},Uu=(e,t,i)=>{const{vnode:n,slots:s}=e;let o=!0,a=Je;if(n.shapeFlag&32){const r=t._;r?i&&r===1?o=!1:yl(s,t,i):(o=!t.$stable,vl(t,s)),a=t}else t&&(bl(e,t),a={default:1});if(o)for(const r in s)!nr(r)&&a[r]==null&&delete s[r]},Ct=Yu;function Vu(e){return Gu(e)}function Gu(e,t){const i=zs();i.__VUE__=!0;const{insert:n,remove:s,patchProp:o,createElement:a,createText:r,createComment:l,setText:c,setElementText:u,parentNode:d,nextSibling:h,setScopeId:f=Xt,insertStaticContent:v}=e,m=(D,W,g,V=null,j=null,I=null,T=void 0,O=null,Y=!!W.dynamicChildren)=>{if(D===W)return;D&&!xn(D,W)&&(V=be(D),K(D,j,I,!0),D=null),W.patchFlag===-2&&(Y=!1,W.dynamicChildren=null);const{type:A,ref:R,shapeFlag:Z}=W;switch(A){case Gs:b(D,W,g,V);break;case hi:y(D,W,g,V);break;case fs:D==null&&x(W,g,V,T);break;case Xe:_(D,W,g,V,j,I,T,O,Y);break;default:Z&1?$(D,W,g,V,j,I,T,O,Y):Z&6?N(D,W,g,V,j,I,T,O,Y):(Z&64||Z&128)&&A.process(D,W,g,V,j,I,T,O,Y,J)}R!=null&&j?An(R,D&&D.ref,I,W||D,!W):R==null&&D&&D.ref!=null&&An(D.ref,null,I,D,!0)},b=(D,W,g,V)=>{if(D==null)n(W.el=r(W.children),g,V);else{const j=W.el=D.el;W.children!==D.children&&c(j,W.children)}},y=(D,W,g,V)=>{D==null?n(W.el=l(W.children||""),g,V):W.el=D.el},x=(D,W,g,V)=>{[D.el,D.anchor]=v(D.children,W,g,V,D.el,D.anchor)},S=({el:D,anchor:W},g,V)=>{let j;for(;D&&D!==W;)j=h(D),n(D,g,V),D=j;n(W,g,V)},w=({el:D,anchor:W})=>{let g;for(;D&&D!==W;)g=h(D),s(D),D=g;s(W)},$=(D,W,g,V,j,I,T,O,Y)=>{if(W.type==="svg"?T="svg":W.type==="math"&&(T="mathml"),D==null)E(W,g,V,j,I,T,O,Y);else{const A=D.el&&D.el._isVueCE?D.el:null;try{A&&A._beginPatch(),z(D,W,j,I,T,O,Y)}finally{A&&A._endPatch()}}},E=(D,W,g,V,j,I,T,O)=>{let Y,A;const{props:R,shapeFlag:Z,transition:te,dirs:ne}=D;if(Y=D.el=a(D.type,I,R&&R.is,R),Z&8?u(Y,D.children):Z&16&&L(D.children,Y,null,V,j,ro(D,I),T,O),ne&&Bi(D,null,V,"created"),C(Y,D,D.scopeId,T,V),R){for(const Ie in R)Ie!=="value"&&!Mn(Ie)&&o(Y,Ie,null,R[Ie],I,V);"value"in R&&o(Y,"value",null,R.value,I),(A=R.onVnodeBeforeMount)&&jt(A,V,D)}ne&&Bi(D,null,V,"beforeMount");const ge=Ku(j,te);ge&&te.beforeEnter(Y),n(Y,W,g),((A=R&&R.onVnodeMounted)||ge||ne)&&Ct(()=>{try{A&&jt(A,V,D),ge&&te.enter(Y),ne&&Bi(D,null,V,"mounted")}finally{}},j)},C=(D,W,g,V,j)=>{if(g&&f(D,g),V)for(let I=0;I<V.length;I++)f(D,V[I]);if(j){let I=j.subTree;if(W===I||Sl(I.type)&&(I.ssContent===W||I.ssFallback===W)){const T=j.vnode;C(D,T,T.scopeId,T.slotScopeIds,j.parent)}}},L=(D,W,g,V,j,I,T,O,Y=0)=>{for(let A=Y;A<D.length;A++){const R=D[A]=O?si(D[A]):Gt(D[A]);m(null,R,W,g,V,j,I,T,O)}},z=(D,W,g,V,j,I,T)=>{const O=W.el=D.el;let{patchFlag:Y,dynamicChildren:A,dirs:R}=W;Y|=D.patchFlag&16;const Z=D.props||Je,te=W.props||Je;let ne;if(g&&Di(g,!1),(ne=te.onVnodeBeforeUpdate)&&jt(ne,g,W,D),R&&Bi(W,D,g,"beforeUpdate"),g&&Di(g,!0),A&&(!D.dynamicChildren||D.dynamicChildren.length!==A.length)&&(Y=0,T=!1,A=null),(Z.innerHTML&&te.innerHTML==null||Z.textContent&&te.textContent==null)&&u(O,""),A?H(D.dynamicChildren,A,O,g,V,ro(W,j),I):T||B(D,W,O,null,g,V,ro(W,j),I,!1),Y>0){if(Y&16)q(O,Z,te,g,j);else if(Y&2&&Z.class!==te.class&&o(O,"class",null,te.class,j),Y&4&&o(O,"style",Z.style,te.style,j),Y&8){const ge=W.dynamicProps;for(let Ie=0;Ie<ge.length;Ie++){const _e=ge[Ie],Le=Z[_e],Ue=te[_e];(Ue!==Le||_e==="value")&&o(O,_e,Le,Ue,j,g)}}Y&1&&D.children!==W.children&&u(O,W.children)}else!T&&A==null&&q(O,Z,te,g,j);((ne=te.onVnodeUpdated)||R)&&Ct(()=>{ne&&jt(ne,g,W,D),R&&Bi(W,D,g,"updated")},V)},H=(D,W,g,V,j,I,T)=>{for(let O=0;O<W.length;O++){const Y=D[O],A=W[O],R=Y.el&&(Y.type===Xe||!xn(Y,A)||Y.shapeFlag&198)?d(Y.el):g;m(Y,A,R,null,V,j,I,T,!0)}},q=(D,W,g,V,j)=>{if(W!==g){if(W!==Je)for(const I in W)!Mn(I)&&!(I in g)&&o(D,I,W[I],null,j,V);for(const I in g){if(Mn(I))continue;const T=g[I],O=W[I];T!==O&&I!=="value"&&o(D,I,O,T,j,V)}"value"in g&&o(D,"value",W.value,g.value,j)}},_=(D,W,g,V,j,I,T,O,Y)=>{const A=W.el=D?D.el:r(""),R=W.anchor=D?D.anchor:r("");let{patchFlag:Z,dynamicChildren:te,slotScopeIds:ne}=W;ne&&(O=O?O.concat(ne):ne),D==null?(n(A,g,V),n(R,g,V),L(W.children||[],g,R,j,I,T,O,Y)):Z>0&&Z&64&&te&&D.dynamicChildren&&D.dynamicChildren.length===te.length?(H(D.dynamicChildren,te,g,j,I,T,O),(W.key!=null||j&&W===j.subTree)&&kl(D,W,!0)):B(D,W,g,R,j,I,T,O,Y)},N=(D,W,g,V,j,I,T,O,Y)=>{W.slotScopeIds=O,D==null?W.shapeFlag&512?j.ctx.activate(W,g,V,T,Y):k(W,g,V,j,I,T,Y):U(D,W,Y)},k=(D,W,g,V,j,I,T)=>{const O=D.component=tf(D,V,j);if(sl(D)&&(O.ctx.renderer=J),sf(O,!1,T),O.asyncDep){if(j&&j.registerDep(O,F,T),!D.el){const Y=O.subTree=ae(hi);y(null,Y,W,g),D.placeholder=Y.el}}else F(O,D,W,g,j,I,T)},U=(D,W,g)=>{const V=W.component=D.component;if(Ru(D,W,g))if(V.asyncDep&&!V.asyncResolved){M(V,W,g);return}else V.next=W,V.update();else W.el=D.el,V.vnode=W},F=(D,W,g,V,j,I,T)=>{const O=()=>{if(D.isMounted){let{next:Z,bu:te,u:ne,parent:ge,vnode:Ie}=D;{const de=wl(D);if(de){Z&&(Z.el=Ie.el,M(D,Z,T)),de.asyncDep.then(()=>{Ct(()=>{D.isUnmounted||A()},j)});return}}let _e=Z,Le;Di(D,!1),Z?(Z.el=Ie.el,M(D,Z,T)):Z=Ie,te&&us(te),(Le=Z.props&&Z.props.onVnodeBeforeUpdate)&&jt(Le,ge,Z,Ie),Di(D,!0);const Ue=Pr(D),qe=D.subTree;D.subTree=Ue,m(qe,Ue,d(qe.el),be(qe),D,j,I),Z.el=Ue.el,_e===null&&Nu(D,Ue.el),ne&&Ct(ne,j),(Le=Z.props&&Z.props.onVnodeUpdated)&&Ct(()=>jt(Le,ge,Z,Ie),j)}else{let Z;const{el:te,props:ne}=W,{bm:ge,m:Ie,parent:_e,root:Le,type:Ue}=D,qe=ln(W);Di(D,!1),ge&&us(ge),!qe&&(Z=ne&&ne.onVnodeBeforeMount)&&jt(Z,_e,W),Di(D,!0);{Le.ce&&Le.ce._hasShadowRoot()&&Le.ce._injectChildStyle(Ue,D.parent?D.parent.type:void 0);const de=D.subTree=Pr(D);m(null,de,g,V,D,j,I),W.el=de.el}if(Ie&&Ct(Ie,j),!qe&&(Z=ne&&ne.onVnodeMounted)){const de=W;Ct(()=>jt(Z,_e,de),j)}(W.shapeFlag&256||_e&&ln(_e.vnode)&&_e.vnode.shapeFlag&256)&&D.a&&Ct(D.a,j),D.isMounted=!0,W=g=V=null}};D.scope.on();const Y=D.effect=new La(O);D.scope.off();const A=D.update=Y.run.bind(Y),R=D.job=Y.runIfDirty.bind(Y);R.i=D,R.id=D.uid,Y.scheduler=()=>er(R),Di(D,!0),A()},M=(D,W,g)=>{W.component=D;const V=D.vnode.props;D.vnode=W,D.next=null,Hu(D,W.props,V,g),Uu(D,W.children,g),ui(),Ir(D),fi()},B=(D,W,g,V,j,I,T,O,Y=!1)=>{const A=D&&D.children,R=D?D.shapeFlag:0,Z=W.children,{patchFlag:te,shapeFlag:ne}=W;if(te>0){if(te&128){se(A,Z,g,V,j,I,T,O,Y);return}else if(te&256){P(A,Z,g,V,j,I,T,O,Y);return}}ne&8?(R&16&&re(A,j,I),Z!==A&&u(g,Z)):R&16?ne&16?se(A,Z,g,V,j,I,T,O,Y):re(A,j,I,!0):(R&8&&u(g,""),ne&16&&L(Z,g,V,j,I,T,O,Y))},P=(D,W,g,V,j,I,T,O,Y)=>{D=D||on,W=W||on;const A=D.length,R=W.length,Z=Math.min(A,R);let te;for(te=0;te<Z;te++){const ne=W[te]=Y?si(W[te]):Gt(W[te]);m(D[te],ne,g,null,j,I,T,O,Y)}A>R?re(D,j,I,!0,!1,Z):L(W,g,V,j,I,T,O,Y,Z)},se=(D,W,g,V,j,I,T,O,Y)=>{let A=0;const R=W.length;let Z=D.length-1,te=R-1;for(;A<=Z&&A<=te;){const ne=D[A],ge=W[A]=Y?si(W[A]):Gt(W[A]);if(xn(ne,ge))m(ne,ge,g,null,j,I,T,O,Y);else break;A++}for(;A<=Z&&A<=te;){const ne=D[Z],ge=W[te]=Y?si(W[te]):Gt(W[te]);if(xn(ne,ge))m(ne,ge,g,null,j,I,T,O,Y);else break;Z--,te--}if(A>Z){if(A<=te){const ne=te+1,ge=ne<R?W[ne].el:V;for(;A<=te;)m(null,W[A]=Y?si(W[A]):Gt(W[A]),g,ge,j,I,T,O,Y),A++}}else if(A>te)for(;A<=Z;)K(D[A],j,I,!0),A++;else{const ne=A,ge=A,Ie=new Map;for(A=ge;A<=te;A++){const Ne=W[A]=Y?si(W[A]):Gt(W[A]);Ne.key!=null&&Ie.set(Ne.key,A)}let _e,Le=0;const Ue=te-ge+1;let qe=!1,de=0;const fe=new Array(Ue);for(A=0;A<Ue;A++)fe[A]=0;for(A=ne;A<=Z;A++){const Ne=D[A];if(Le>=Ue){K(Ne,j,I,!0);continue}let He;if(Ne.key!=null)He=Ie.get(Ne.key);else for(_e=ge;_e<=te;_e++)if(fe[_e-ge]===0&&xn(Ne,W[_e])){He=_e;break}He===void 0?K(Ne,j,I,!0):(fe[He-ge]=A+1,He>=de?de=He:qe=!0,m(Ne,W[He],g,null,j,I,T,O,Y),Le++)}const Ye=qe?qu(fe):on;for(_e=Ye.length-1,A=Ue-1;A>=0;A--){const Ne=ge+A,He=W[Ne],ot=W[Ne+1],ti=Ne+1<R?ot.el||xl(ot):V;fe[A]===0?m(null,He,g,ti,j,I,T,O,Y):qe&&(_e<0||A!==Ye[_e]?G(He,g,ti,2):_e--)}}},G=(D,W,g,V,j=null)=>{const{el:I,type:T,transition:O,children:Y,shapeFlag:A}=D;if(A&6){G(D.component.subTree,W,g,V);return}if(A&128){D.suspense.move(W,g,V);return}if(A&64){T.move(D,W,g,J);return}if(T===Xe){n(I,W,g);for(let Z=0;Z<Y.length;Z++)G(Y[Z],W,g,V);n(D.anchor,W,g);return}if(T===fs){S(D,W,g);return}if(V!==2&&A&1&&O)if(V===0)O.persisted&&!I[so]?n(I,W,g):(O.beforeEnter(I),n(I,W,g),Ct(()=>O.enter(I),j));else{const{leave:Z,delayLeave:te,afterLeave:ne}=O,ge=()=>{D.ctx.isUnmounted?s(I):n(I,W,g)},Ie=()=>{const _e=I._isLeaving||!!I[so];I._isLeaving&&I[so](!0),O.persisted&&!_e?ge():Z(I,()=>{ge(),ne&&ne()})};te?te(I,ge,Ie):Ie()}else n(I,W,g)},K=(D,W,g,V=!1,j=!1)=>{const{type:I,props:T,ref:O,children:Y,dynamicChildren:A,shapeFlag:R,patchFlag:Z,dirs:te,cacheIndex:ne,memo:ge}=D;if(Z===-2&&(j=!1),O!=null&&(ui(),An(O,null,g,D,!0),fi()),ne!=null&&(W.renderCache[ne]=void 0),R&256){W.ctx.deactivate(D);return}const Ie=R&1&&te,_e=!ln(D);let Le;if(_e&&(Le=T&&T.onVnodeBeforeUnmount)&&jt(Le,W,D),R&6)oe(D.component,g,V);else{if(R&128){D.suspense.unmount(g,V);return}Ie&&Bi(D,null,W,"beforeUnmount"),R&64?D.type.remove(D,W,g,J,V):A&&!A.hasOnce&&(I!==Xe||Z>0&&Z&64)?re(A,W,g,!1,!0):(I===Xe&&Z&384||!j&&R&16)&&re(Y,W,g),V&&ce(D)}const Ue=ge!=null&&ne==null;(_e&&(Le=T&&T.onVnodeUnmounted)||Ie||Ue)&&Ct(()=>{Le&&jt(Le,W,D),Ie&&Bi(D,null,W,"unmounted"),Ue&&(D.el=null)},g)},ce=D=>{const{type:W,el:g,anchor:V,transition:j}=D;if(W===Xe){ie(g,V);return}if(W===fs){w(D);return}const I=()=>{s(g),j&&!j.persisted&&j.afterLeave&&j.afterLeave()};if(D.shapeFlag&1&&j&&!j.persisted){const{leave:T,delayLeave:O}=j,Y=()=>T(g,I);O?O(D.el,I,Y):Y()}else I()},ie=(D,W)=>{let g;for(;D!==W;)g=h(D),s(D),D=g;s(W)},oe=(D,W,g)=>{const{bum:V,scope:j,job:I,subTree:T,um:O,m:Y,a:A}=D;Nr(Y),Nr(A),V&&us(V),j.stop(),I&&(I.flags|=8,K(T,D,W,g)),O&&Ct(O,W),Ct(()=>{D.isUnmounted=!0},W)},re=(D,W,g,V=!1,j=!1,I=0)=>{for(let T=I;T<D.length;T++)K(D[T],W,g,V,j)},be=D=>{if(D.shapeFlag&6)return be(D.component.subTree);if(D.shapeFlag&128)return D.suspense.next();const W=h(D.anchor||D.el),g=W&&W[lu];return g?h(g):W};let ke=!1;const le=(D,W,g)=>{let V;D==null?W._vnode&&(K(W._vnode,null,null,!0),V=W._vnode.component):m(W._vnode||null,D,W,null,null,null,g),W._vnode=D,ke||(ke=!0,Ir(V),Ja(),ke=!1)},J={p:m,um:K,m:G,r:ce,mt:k,mc:L,pc:B,pbc:H,n:be,o:e};return{render:le,hydrate:void 0,createApp:Au(le)}}function ro({type:e,props:t},i){return i==="svg"&&e==="foreignObject"||i==="mathml"&&e==="annotation-xml"&&t&&t.encoding&&t.encoding.includes("html")?void 0:i}function Di({effect:e,job:t},i){i?(e.flags|=32,t.flags|=4):(e.flags&=-33,t.flags&=-5)}function Ku(e,t){return(!e||e&&!e.pendingBranch)&&t&&!t.persisted}function kl(e,t,i=!1){const n=e.children,s=t.children;if(Ee(n)&&Ee(s))for(let o=0;o<n.length;o++){const a=n[o];let r=s[o];r.shapeFlag&1&&!r.dynamicChildren&&((r.patchFlag<=0||r.patchFlag===32)&&(r=s[o]=si(s[o]),r.el=a.el),!i&&r.patchFlag!==-2&&kl(a,r)),r.type===Gs&&(r.patchFlag===-1&&(r=s[o]=si(r)),r.el=a.el),r.type===hi&&!r.el&&(r.el=a.el)}}function qu(e){const t=e.slice(),i=[0];let n,s,o,a,r;const l=e.length;for(n=0;n<l;n++){const c=e[n];if(c!==0){if(s=i[i.length-1],e[s]<c){t[n]=s,i.push(n);continue}for(o=0,a=i.length-1;o<a;)r=o+a>>1,e[i[r]]<c?o=r+1:a=r;c<e[i[o]]&&(o>0&&(t[n]=i[o-1]),i[o]=n)}}for(o=i.length,a=i[o-1];o-- >0;)i[o]=a,a=t[a];return i}function wl(e){const t=e.subTree.component;if(t)return t.asyncDep&&!t.asyncResolved?t:wl(t)}function Nr(e){if(e)for(let t=0;t<e.length;t++)e[t].flags|=8}function xl(e){if(e.placeholder)return e.placeholder;const t=e.component;return t?xl(t.subTree):null}const Sl=e=>e.__isSuspense;function Yu(e,t){t&&t.pendingBranch?Ee(e)?t.effects.push(...e):t.effects.push(e):nu(e)}const Xe=Symbol.for("v-fgt"),Gs=Symbol.for("v-txt"),hi=Symbol.for("v-cmt"),fs=Symbol.for("v-stc"),ci=[];let Et=null;function X(e=!1){ci.push(Et=e?null:[])}function or(){ci.pop(),Et=ci[ci.length-1]||null}let Un=1;function zr(e,t=!1){Un+=e,e<0&&Et&&t&&(Et.hasOnce=!0)}function Cl(e){return e.dynamicChildren=Un>0?Et||on:null,or(),Un>0&&Et&&Et.push(e),e}function ee(e,t,i,n,s,o){return Cl(p(e,t,i,n,s,o,!0))}function Zt(e,t,i,n,s){return Cl(ae(e,t,i,n,s,!0))}function rr(e){return e?e.__v_isVNode===!0:!1}function xn(e,t){return e.type===t.type&&e.key===t.key}const _l=({key:e})=>e??null,ps=({ref:e,ref_key:t,ref_for:i})=>(typeof e=="number"&&(e=""+e),e!=null?nt(e)||tt(e)||Be(e)?{i:dt,r:e,k:t,f:!!i}:e:null);function p(e,t=null,i=null,n=0,s=null,o=e===Xe?0:1,a=!1,r=!1){const l={__v_isVNode:!0,__v_skip:!0,type:e,props:t,key:t&&_l(t),ref:t&&ps(t),scopeId:Qa,slotScopeIds:null,children:i,component:null,suspense:null,ssContent:null,ssFallback:null,dirs:null,transition:null,el:null,anchor:null,target:null,targetStart:null,targetAnchor:null,staticCount:0,shapeFlag:o,patchFlag:n,dynamicProps:s,dynamicChildren:null,appContext:null,ctx:dt};return r?(As(l,i),o&128&&e.normalize(l)):i&&(l.shapeFlag|=nt(i)?8:16),Un>0&&!a&&Et&&(l.patchFlag>0||o&6)&&l.patchFlag!==32&&Et.push(l),l}const ae=Zu;function Zu(e,t=null,i=null,n=0,s=null,o=!1){if((!e||e===xu)&&(e=hi),rr(e)){const r=fn(e,t,!0);return i&&As(r,i),Un>0&&!o&&Et&&(r.shapeFlag&6?Et[Et.indexOf(e)]=r:Et.push(r)),r.patchFlag=-2,r}if(cf(e)&&(e=e.__vccOpts),t){t=Ju(t);let{class:r,style:l}=t;r&&!nt(r)&&(t.class=$e(r)),Ke(l)&&(Qo(l)&&!Ee(l)&&(l=ut({},l)),t.style=qt(l))}const a=nt(e)?1:Sl(e)?128:cu(e)?64:Ke(e)?4:Be(e)?2:0;return p(e,t,i,n,s,a,o,!0)}function Ju(e){return e?Qo(e)||hl(e)?ut({},e):e:null}function fn(e,t,i=!1,n=!1){const{props:s,ref:o,patchFlag:a,children:r,transition:l}=e,c=t?Xu(s||{},t):s,u={__v_isVNode:!0,__v_skip:!0,type:e.type,props:c,key:c&&_l(c),ref:t&&t.ref?i&&o?Ee(o)?o.concat(ps(t)):[o,ps(t)]:ps(t):o,scopeId:e.scopeId,slotScopeIds:e.slotScopeIds,children:r,target:e.target,targetStart:e.targetStart,targetAnchor:e.targetAnchor,staticCount:e.staticCount,shapeFlag:e.shapeFlag,patchFlag:t&&e.type!==Xe?a===-1?16:a|16:a,dynamicProps:e.dynamicProps,dynamicChildren:e.dynamicChildren,appContext:e.appContext,dirs:e.dirs,transition:l,component:e.component,suspense:e.suspense,ssContent:e.ssContent&&fn(e.ssContent),ssFallback:e.ssFallback&&fn(e.ssFallback),placeholder:e.placeholder,el:e.el,anchor:e.anchor,ctx:e.ctx,ce:e.ce};return l&&n&&tr(u,l.clone(u)),u}function _t(e=" ",t=0){return ae(Gs,null,e,t)}function ht(e,t){const i=ae(fs,null,e);return i.staticCount=t,i}function Te(e="",t=!1){return t?(X(),Zt(hi,null,e)):ae(hi,null,e)}function Gt(e){return e==null||typeof e=="boolean"?ae(hi):Ee(e)?ae(Xe,null,e.slice()):rr(e)?si(e):ae(Gs,null,String(e))}function si(e){return e.el===null&&e.patchFlag!==-1||e.memo?e:fn(e)}function As(e,t){let i=0;const{shapeFlag:n}=e;if(t==null)t=null;else if(Ee(t))i=16;else if(typeof t=="object")if(n&65){const s=t.default;s&&(s._c&&(s._d=!1),As(e,s()),s._c&&(s._d=!0));return}else{i=32;const s=t._;!s&&!hl(t)?t._ctx=dt:s===3&&dt&&(dt.slots._===1?t._=1:(t._=2,e.patchFlag|=1024))}else if(Be(t)){if(n&65){As(e,{default:t});return}t={default:t,_ctx:dt},i=32}else t=String(t),n&64?(i=16,t=[_t(t)]):i=8;e.children=t,e.shapeFlag|=i}function Xu(...e){const t={};for(let i=0;i<e.length;i++){const n=e[i];for(const s in n)if(s==="class")t.class!==n.class&&(t.class=$e([t.class,n.class]));else if(s==="style")t.style=qt([t.style,n.style]);else if(Ls(s)){const o=t[s],a=n[s];a&&o!==a&&!(Ee(o)&&o.includes(a))?t[s]=o?[].concat(o,a):a:a==null&&o==null&&!Ps(s)&&(t[s]=a)}else s!==""&&(t[s]=n[s])}return t}function jt(e,t,i,n=null){Ft(e,t,7,[i,n])}const Qu=cl();let ef=0;function tf(e,t,i){const n=e.type,s=(t?t.appContext:e.appContext)||Qu,o={uid:ef++,vnode:e,type:n,parent:t,appContext:s,root:null,next:null,subTree:null,effect:null,update:null,job:null,scope:new Id(!0),render:null,proxy:null,exposed:null,exposeProxy:null,withProxy:null,provides:t?t.provides:Object.create(s.provides),ids:t?t.ids:["",0,0],accessCache:null,renderCache:[],components:null,directives:null,propsOptions:gl(n,s),emitsOptions:dl(n,s),emit:null,emitted:null,propsDefaults:Je,inheritAttrs:n.inheritAttrs,ctx:Je,data:Je,props:Je,attrs:Je,slots:Je,refs:Je,setupState:Je,setupContext:null,suspense:i,suspenseId:i?i.pendingId:0,asyncDep:null,asyncResolved:!1,isMounted:!1,isUnmounted:!1,isDeactivated:!1,bc:null,c:null,bm:null,m:null,bu:null,u:null,um:null,bum:null,da:null,a:null,rtg:null,rtc:null,ec:null,sp:null};return o.ctx={_:o},o.root=t?t.root:o,o.emit=Du.bind(null,o),e.ce&&e.ce(o),o}let vt=null;const nf=()=>vt||dt;let Bs,Ao;{const e=zs(),t=(i,n)=>{let s;return(s=e[i])||(s=e[i]=[]),s.push(n),o=>{s.length>1?s.forEach(a=>a(o)):s[0](o)}};Bs=t("__VUE_INSTANCE_SETTERS__",i=>vt=i),Ao=t("__VUE_SSR_SETTERS__",i=>Vn=i)}const Xn=e=>{const t=vt;return Bs(e),e.scope.on(),()=>{e.scope.off(),Bs(t)}},Hr=()=>{vt&&vt.scope.off(),Bs(null)};function $l(e){return e.vnode.shapeFlag&4}let Vn=!1;function sf(e,t=!1,i=!1){t&&Ao(t);const{props:n,children:s}=e.vnode,o=$l(e);zu(e,n,o,t),Wu(e,s,i||t);const a=o?of(e,t):void 0;return t&&Ao(!1),a}function of(e,t){const i=e.type;e.accessCache=Object.create(null),e.proxy=new Proxy(e.ctx,Cu);const{setup:n}=i;if(n){ui();const s=e.setupContext=n.length>1?af(e):null,o=Xn(e),a=Jn(n,e,0,[e.props,s]),r=Ia(a);if(fi(),o(),(r||e.sp)&&!ln(e)&&nl(e),r){if(a.then(Hr,Hr),t)return a.then(l=>{Fr(e,l)}).catch(l=>{js(l,e,0)});e.asyncDep=a}else Fr(e,a)}else Il(e)}function Fr(e,t,i){Be(t)?e.type.__ssrInlineRender?e.ssrRender=t:e.render=t:Ke(t)&&(e.setupState=qa(t)),Il(e)}function Il(e,t,i){const n=e.type;e.render||(e.render=n.render||Xt);{const s=Xn(e);ui();try{_u(e)}finally{fi(),s()}}}const rf={get(e,t){return mt(e,"get",""),e[t]}};function af(e){const t=i=>{e.exposed=i||{}};return{attrs:new Proxy(e.attrs,rf),slots:e.slots,emit:e.emit,expose:t}}function Ks(e){return e.exposed?e.exposeProxy||(e.exposeProxy=new Proxy(qa(Kd(e.exposed)),{get(t,i){if(i in t)return t[i];if(i in Bn)return Bn[i](e)},has(t,i){return i in t||i in Bn}})):e.proxy}function lf(e,t=!0){return Be(e)?e.displayName||e.name:e.name||t&&e.__name}function cf(e){return Be(e)&&"__vccOpts"in e}const xe=(e,t)=>Xd(e,t,Vn),df="3.5.40";/**
* @vue/runtime-dom v3.5.40
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/let Bo;const jr=typeof window<"u"&&window.trustedTypes;if(jr)try{Bo=jr.createPolicy("vue",{createHTML:e=>e})}catch{}const Ml=Bo?e=>Bo.createHTML(e):e=>e,uf="http://www.w3.org/2000/svg",ff="http://www.w3.org/1998/Math/MathML",ni=typeof document<"u"?document:null,Wr=ni&&ni.createElement("template"),pf={insert:(e,t,i)=>{t.insertBefore(e,i||null)},remove:e=>{const t=e.parentNode;t&&t.removeChild(e)},createElement:(e,t,i,n)=>{const s=t==="svg"?ni.createElementNS(uf,e):t==="mathml"?ni.createElementNS(ff,e):i?ni.createElement(e,{is:i}):ni.createElement(e);return e==="select"&&n&&n.multiple!=null&&s.setAttribute("multiple",n.multiple),s},createText:e=>ni.createTextNode(e),createComment:e=>ni.createComment(e),setText:(e,t)=>{e.nodeValue=t},setElementText:(e,t)=>{e.textContent=t},parentNode:e=>e.parentNode,nextSibling:e=>e.nextSibling,querySelector:e=>ni.querySelector(e),setScopeId(e,t){e.setAttribute(t,"")},insertStaticContent(e,t,i,n,s,o){const a=i?i.previousSibling:t.lastChild;if(s&&(s===o||s.nextSibling))for(;t.insertBefore(s.cloneNode(!0),i),!(s===o||!(s=s.nextSibling)););else{Wr.innerHTML=Ml(n==="svg"?`<svg>${e}</svg>`:n==="mathml"?`<math>${e}</math>`:e);const r=Wr.content;if(n==="svg"||n==="mathml"){const l=r.firstChild;for(;l.firstChild;)r.appendChild(l.firstChild);r.removeChild(l)}t.insertBefore(r,i)}return[a?a.nextSibling:t.firstChild,i?i.previousSibling:t.lastChild]}},hf=Symbol("_vtc");function mf(e,t,i){const n=e[hf];n&&(t=(t?[t,...n]:[...n]).join(" ")),t==null?e.removeAttribute("class"):i?e.setAttribute("class",t):e.className=t}const Ds=Symbol("_vod"),Tl=Symbol("_vsh"),Do={name:"show",beforeMount(e,{value:t},{transition:i}){e[Ds]=e.style.display==="none"?"":e.style.display,i&&t?i.beforeEnter(e):Sn(e,t)},mounted(e,{value:t},{transition:i}){i&&t&&i.enter(e)},updated(e,{value:t,oldValue:i},{transition:n}){!t!=!i&&(n?t?(n.beforeEnter(e),Sn(e,!0),n.enter(e)):n.leave(e,()=>{Sn(e,!1)}):Sn(e,t))},beforeUnmount(e,{value:t}){Sn(e,t)}};function Sn(e,t){e.style.display=t?e[Ds]:"none",e[Tl]=!t}const gf=Symbol(""),vf=/(?:^|;)\s*display\s*:/;function bf(e,t,i){const n=e.style,s=nt(i);let o=!1;if(i&&!s){if(t)if(nt(t))for(const a of t.split(";")){const r=a.slice(0,a.indexOf(":")).trim();i[r]==null&&_n(n,r,"")}else for(const a in t)i[a]==null&&_n(n,a,"");for(const a in i){a==="display"&&(o=!0);const r=i[a];r!=null?kf(e,a,!nt(t)&&t?t[a]:void 0,r)||_n(n,a,r):_n(n,a,"")}}else if(s){if(t!==i){const a=n[gf];a&&(i+=";"+a),n.cssText=i,o=vf.test(i)}}else t&&e.removeAttribute("style");Ds in e&&(e[Ds]=o?n.display:"",e[Tl]&&(n.display="none"))}const Ur=/\s*!important$/;function _n(e,t,i){if(Ee(i))i.forEach(n=>_n(e,t,n));else if(i==null&&(i=""),t.startsWith("--"))e.setProperty(t,i);else{const n=yf(e,t);Ur.test(i)?e.setProperty(Ei(n),i.replace(Ur,""),"important"):e[n]=i}}const Vr=["Webkit","Moz","ms"],ao={};function yf(e,t){const i=ao[t];if(i)return i;let n=St(t);if(n!=="filter"&&n in e)return ao[t]=n;n=Rs(n);for(let s=0;s<Vr.length;s++){const o=Vr[s]+n;if(o in e)return ao[t]=o}return t}function kf(e,t,i,n){return e.tagName==="TEXTAREA"&&(t==="width"||t==="height")&&nt(n)&&i===n}const Gr="http://www.w3.org/1999/xlink";function Kr(e,t,i,n,s,o=_d(t)){n&&t.startsWith("xlink:")?i==null?e.removeAttributeNS(Gr,t.slice(6,t.length)):e.setAttributeNS(Gr,t,i):i==null||o&&!Aa(i)?e.removeAttribute(t):e.setAttribute(t,o?"":zt(i)?String(i):i)}function qr(e,t,i,n,s){if(t==="innerHTML"||t==="textContent"){i!=null&&(e[t]=t==="innerHTML"?Ml(i):i);return}const o=e.tagName;if(t==="value"&&o!=="PROGRESS"&&!o.includes("-")){const r=o==="OPTION"?e.getAttribute("value")||"":e.value,l=i==null?e.type==="checkbox"?"on":"":String(i);(r!==l||!("_value"in e))&&(e.value=l),i==null&&e.removeAttribute(t),e._value=i;return}let a=!1;if(i===""||i==null){const r=typeof e[t];r==="boolean"?i=Aa(i):i==null&&r==="string"?(i="",a=!0):r==="number"&&(i=0,a=!0)}try{e[t]=i}catch{}a&&e.removeAttribute(s||t)}function xi(e,t,i,n){e.addEventListener(t,i,n)}function wf(e,t,i,n){e.removeEventListener(t,i,n)}const Yr=Symbol("_vei");function xf(e,t,i,n,s=null){const o=e[Yr]||(e[Yr]={}),a=o[t];if(n&&a)a.value=n;else{const[r,l]=_f(t);if(n){const c=o[t]=Mf(n,s);xi(e,r,c,l)}else a&&(wf(e,r,a,l),o[t]=void 0)}}const Sf=/(Once|Passive|Capture)$/,Cf=/^on:?(?:Once|Passive|Capture)$/;function _f(e){let t,i;for(;(i=e.match(Sf))&&!Cf.test(e);)t||(t={}),e=e.slice(0,e.length-i[1].length),t[i[1].toLowerCase()]=!0;return[e[2]===":"?e.slice(3):Ei(e.slice(2)),t]}let lo=0;const $f=Promise.resolve(),If=()=>lo||($f.then(()=>lo=0),lo=Date.now());function Mf(e,t){const i=n=>{if(!n._vts)n._vts=Date.now();else if(n._vts<=i.attached)return;const s=i.value;if(Ee(s)){const o=n.stopImmediatePropagation;n.stopImmediatePropagation=()=>{o.call(n),n._stopped=!0};const a=s.slice(),r=[n];for(let l=0;l<a.length&&!n._stopped;l++){const c=a[l];c&&Ft(c,t,5,r)}}else Ft(s,t,5,[n])};return i.value=e,i.attached=If(),i}const Zr=e=>e.charCodeAt(0)===111&&e.charCodeAt(1)===110&&e.charCodeAt(2)>96&&e.charCodeAt(2)<123,Tf=(e,t,i,n,s,o)=>{const a=s==="svg";t==="class"?mf(e,n,a):t==="style"?bf(e,i,n):Ls(t)?Ps(t)||xf(e,t,i,n,o):(t[0]==="."?(t=t.slice(1),!0):t[0]==="^"?(t=t.slice(1),!1):Ef(e,t,n,a))?(qr(e,t,n),!e.tagName.includes("-")&&(t==="value"||t==="checked"||t==="selected")&&Kr(e,t,n,a,o,t!=="value")):e._isVueCE&&(Af(e,t)||e._def.__asyncLoader&&(/[A-Z]/.test(t)||!nt(n)))?qr(e,St(t),n,o,t):(t==="true-value"?e._trueValue=n:t==="false-value"&&(e._falseValue=n),Kr(e,t,n,a))};function Ef(e,t,i,n){if(n)return!!(t==="innerHTML"||t==="textContent"||t in e&&Zr(t)&&Be(i));if(t==="spellcheck"||t==="draggable"||t==="translate"||t==="autocorrect"||t==="sandbox"&&e.tagName==="IFRAME"||t==="form"||t==="list"&&e.tagName==="INPUT"||t==="type"&&e.tagName==="TEXTAREA")return!1;if(t==="width"||t==="height"){const s=e.tagName;if(s==="IMG"||s==="VIDEO"||s==="CANVAS"||s==="SOURCE")return!1}return Zr(t)&&nt(i)?!1:t in e}function Af(e,t){const i=e._def.props;if(!i)return!1;const n=St(t);return Array.isArray(i)?i.some(s=>St(s)===n):Object.keys(i).some(s=>St(s)===n)}const pn=e=>{const t=e.props["onUpdate:modelValue"]||!1;return Ee(t)?i=>us(t,i):t};function Bf(e){e.target.composing=!0}function Jr(e){const t=e.target;t.composing&&(t.composing=!1,t.dispatchEvent(new Event("input")))}const di=Symbol("_assign");function Xr(e,t,i){return t&&(e=e.trim()),i&&(e=Ns(e)),e}const Lo={created(e,{modifiers:{lazy:t,trim:i,number:n}},s){e[di]=pn(s);const o=n||s.props&&s.props.type==="number";xi(e,t?"change":"input",a=>{a.target.composing||e[di](Xr(e.value,i,o))}),(i||o)&&xi(e,"change",()=>{e.value=Xr(e.value,i,o)}),t||(xi(e,"compositionstart",Bf),xi(e,"compositionend",Jr),xi(e,"change",Jr))},mounted(e,{value:t}){e.value=t??""},beforeUpdate(e,{value:t,oldValue:i,modifiers:{lazy:n,trim:s,number:o}},a){if(e[di]=pn(a),e.composing)return;const r=(o||e.type==="number")&&!/^0\d/.test(e.value)?Ns(e.value):e.value,l=t??"";if(r===l)return;const c=e.getRootNode();(c instanceof Document||c instanceof ShadowRoot)&&c.activeElement===e&&e.type!=="range"&&(n&&t===i||s&&e.value.trim()===l)||(e.value=l)}},as={deep:!0,created(e,t,i){e[di]=pn(i),xi(e,"change",()=>{const n=e._modelValue,s=Gn(e),o=e.checked,a=e[di];if(Ee(n)){const r=Go(n,s),l=r!==-1;if(o&&!l)a(n.concat(s));else if(!o&&l){const c=[...n];c.splice(r,1),a(c)}}else if(hn(n)){const r=new Set(n);o?r.add(s):r.delete(s),a(r)}else a(El(e,o))})},mounted:Qr,beforeUpdate(e,t,i){e[di]=pn(i),Qr(e,t,i)}};function Qr(e,{value:t,oldValue:i},n){e._modelValue=t;let s;if(Ee(t))s=Go(t,n.props.value)>-1;else if(hn(t))s=t.has(n.props.value);else{if(t===i)return;s=mn(t,El(e,!0))}e.checked!==s&&(e.checked=s)}const Df={deep:!0,created(e,{value:t,modifiers:{number:i}},n){e._modelValue=t,xi(e,"change",()=>{const s=Array.prototype.filter.call(e.options,o=>o.selected).map(o=>i?Ns(Gn(o)):Gn(o));e[di](e.multiple?hn(e._modelValue)?new Set(s):s:s[0]),e._assigning=!0,Is(()=>{e._assigning=!1})}),e[di]=pn(n)},mounted(e,{value:t}){ea(e,t)},beforeUpdate(e,{value:t},i){e._modelValue=t,e[di]=pn(i)},updated(e,{value:t}){e._assigning||ea(e,t)}};function ea(e,t){const i=e.multiple,n=Ee(t);if(!(i&&!n&&!hn(t))){for(let s=0,o=e.options.length;s<o;s++){const a=e.options[s],r=Gn(a);if(i)if(n){const l=typeof r;l==="string"||l==="number"?a.selected=t.some(c=>String(c)===String(r)):a.selected=Go(t,r)>-1}else a.selected=t.has(r);else if(mn(Gn(a),t)){e.selectedIndex!==s&&(e.selectedIndex=s);return}}!i&&e.selectedIndex!==-1&&(e.selectedIndex=-1)}}function Gn(e){return"_value"in e?e._value:e.value}function El(e,t){const i=t?"_trueValue":"_falseValue";return i in e?e[i]:t}const Lf=["ctrl","shift","alt","meta"],Pf={stop:e=>e.stopPropagation(),prevent:e=>e.preventDefault(),self:e=>e.target!==e.currentTarget,ctrl:e=>!e.ctrlKey,shift:e=>!e.shiftKey,alt:e=>!e.altKey,meta:e=>!e.metaKey,left:e=>"button"in e&&e.button!==0,middle:e=>"button"in e&&e.button!==1,right:e=>"button"in e&&e.button!==2,exact:(e,t)=>Lf.some(i=>e[`${i}Key`]&&!t.includes(i))},Yt=(e,t)=>{if(!e)return e;const i=e._withMods||(e._withMods={}),n=t.join(".");return i[n]||(i[n]=((s,...o)=>{for(let a=0;a<t.length;a++){const r=Pf[t[a]];if(r&&r(s,t))return}return e(s,...o)}))},Of={esc:"escape",space:" ",up:"arrow-up",left:"arrow-left",right:"arrow-right",down:"arrow-down",delete:"backspace"},Rf=(e,t)=>{const i=e._withKeys||(e._withKeys={}),n=t.join(".");return i[n]||(i[n]=(s=>{if(!("key"in s))return;const o=Ei(s.key);if(t.some(a=>a===o||Of[a]===o))return e(s)}))},Nf=ut({patchProp:Tf},pf);let ta;function zf(){return ta||(ta=Vu(Nf))}const ar=((...e)=>{const t=zf().createApp(...e),{mount:i}=t;return t.mount=n=>{const s=Ff(n);if(!s)return;const o=t._component;!Be(o)&&!o.render&&!o.template&&(o.template=s.innerHTML),s.nodeType===1&&(s.textContent="");const a=i(s,!1,Hf(s));return s instanceof Element&&(s.removeAttribute("v-cloak"),s.setAttribute("data-v-app","")),a},t});function Hf(e){if(e instanceof SVGElement)return"svg";if(typeof MathMLElement=="function"&&e instanceof MathMLElement)return"mathml"}function Ff(e){return nt(e)?document.querySelector(e):e}const jf="slides-config.json",$i={enableWebServeJump:!1,webServeUrl:"http://127.0.0.1:6806",normalizeHeadingSizes:!1,showUnorderedListMarkers:!0,showOrderedListMarkers:!0},Ut=Fs({...$i});function Wf(e){if(!e||typeof e!="object")return{...$i};const t=e;return{enableWebServeJump:!!t.enableWebServeJump,webServeUrl:typeof t.webServeUrl=="string"&&t.webServeUrl.trim()?t.webServeUrl.trim():$i.webServeUrl,normalizeHeadingSizes:!!t.normalizeHeadingSizes,showUnorderedListMarkers:t.showUnorderedListMarkers!==void 0?!!t.showUnorderedListMarkers:$i.showUnorderedListMarkers,showOrderedListMarkers:t.showOrderedListMarkers!==void 0?!!t.showOrderedListMarkers:$i.showOrderedListMarkers}}function oi(e){if(!e||typeof e!="object")return{...Ut};const t=e;return t.enableWebServeJump!==void 0&&(Ut.enableWebServeJump=!!t.enableWebServeJump),t.webServeUrl!==void 0&&(Ut.webServeUrl=String(t.webServeUrl)),t.normalizeHeadingSizes!==void 0&&(Ut.normalizeHeadingSizes=!!t.normalizeHeadingSizes),t.showUnorderedListMarkers!==void 0&&(Ut.showUnorderedListMarkers=!!t.showUnorderedListMarkers),t.showOrderedListMarkers!==void 0&&(Ut.showOrderedListMarkers=!!t.showOrderedListMarkers),{...Ut}}function qs(){return{...Ut}}function Al(e,t,i){const n=(e||$i.webServeUrl).trim(),s=n.startsWith("http://")||n.startsWith("https://")?n:`http://${n}`,o=(i==null?void 0:i.r)||Math.random().toString(36).slice(2,9).padEnd(7,"0");try{const a=new URL(s);let r=a.pathname.replace(/\/+$/,"");return r.endsWith("/stage/build/desktop")||(r=r?`${r}/stage/build/desktop`:"/stage/build/desktop"),a.pathname=`${r}/`,a.searchParams.set("id",t),i!=null&&i.focus&&a.searchParams.set("focus","1"),a.searchParams.set("r",o),a.toString()}catch{const a=i!=null&&i.focus?"&focus=1":"";return`${s.replace(/\/+$/,"")}/stage/build/desktop/?id=${t}${a}&r=${o}`}}const Li={theme:"default",aspectRatio:"16/9",highlighter:"shiki",defaultTransition:"slide-left",colorSchema:"auto",spacing:"normal",normalizeHeadingSizes:!1,showUnorderedListMarkers:!0,showOrderedListMarkers:!0};function Uf(e){var s,o,a,r,l,c;const t=qs();if(!e)return{...Li,normalizeHeadingSizes:t.normalizeHeadingSizes,showUnorderedListMarkers:t.showUnorderedListMarkers,showOrderedListMarkers:t.showOrderedListMarkers};const i=e[wr]!==void 0?e[wr]!=="false":t.showUnorderedListMarkers,n=e[xr]!==void 0?e[xr]!=="false":t.showOrderedListMarkers;return{theme:((s=e[Rn])==null?void 0:s.trim())||Li.theme,aspectRatio:((o=e[Nn])==null?void 0:o.trim())||Li.aspectRatio,highlighter:((a=e[wa])==null?void 0:a.trim())||Li.highlighter,defaultTransition:((r=e[zn])==null?void 0:r.trim())||Li.defaultTransition,colorSchema:((l=e[xa])==null?void 0:l.trim())||Li.colorSchema,spacing:((c=e[wo])==null?void 0:c.trim())||Li.spacing,normalizeHeadingSizes:t.normalizeHeadingSizes,showUnorderedListMarkers:i,showOrderedListMarkers:n}}function Kn(e){var i,n,s,o,a;const t=(i=e.ial)==null?void 0:i[Ri];return!!(t&&(t==="true"||t==="page"||t==="cover"||t==="end")||e.type==="tb"||e.type==="thematic-break"||e.type==="NodeThematicBreak"||((n=e.markdown)==null?void 0:n.trim())==="---"||((s=e.markdown)==null?void 0:s.trim())==="***"||e.type==="b"&&(((o=e.markdown)==null?void 0:o.trim())==="---"||((a=e.content)==null?void 0:a.trim())==="---"))}function ia(e){const t={};let i="";if(!e)return{frontmatter:t,notes:i};e[Se]&&(t.layout=e[Se].trim()),e[gt]&&(t.transition=e[gt].trim()),e[st]&&(t.background=e[st].trim()),e[Ot]&&(t.image=e[Ot].trim()),e[Qi]&&(t.class=e[Qi].trim()),e[In]&&(t.spacing=e[In].trim()),e[wt]&&(t.layoutRatio=e[wt].trim()),e[en]&&(t.mask=e[en].trim()),e[Fi]&&(t.maskRatio=e[Fi].trim()),e[tn]&&(t.maskStyle=e[tn].trim()),e[nn]&&(t.maskInitial=e[nn].trim()),e[Xs]&&(i=e[Xs].trim());for(const[n,s]of Object.entries(e))if(n.startsWith("custom-slides-")&&![Se,wt,en,Fi,tn,nn,gt,st,Ot,Qi,In,Xs,Ri].includes(n)){const o=n.replace(/^custom-slides-/,"");try{t[o]=JSON.parse(s)}catch{t[o]=s}}return{frontmatter:t,notes:i}}function Vf(e){const t={};if(!e)return t;const i=e[Ge]??e["slides-note"];i!=null&&i!==""&&i!=="false"&&i!=="0"&&(t.isNote=!0);const n=e[Ze]??e["slides-role"],s=e[st]??e["slides-background"];(n===Sa||s==="true"||s==="1")&&(t.isBackground=!0);const o=e[Se]??e["slides-layout"];o===Ss||o===Cs?t.imageLayout=o:(n===Ss||n===Cs)&&(t.imageLayout=n);const a=e[Re]??e["custom-slides-clicks"]??e["slides-click"]??e["slides-clicks"];if(a!=null&&(t.clicks=a.trim()),e[Jt])try{const r=JSON.parse(e[Jt]);typeof r=="object"&&r!==null?t.motion={preset:r.preset||r.type||"fade-in",...r}:t.motion={preset:String(r).trim()}}catch{t.motion={preset:e[Jt].trim()}}return e[Gi]&&(t.shikiLines=e[Gi].trim()),e[Hn]&&(t.maxHeight=e[Hn].trim()),e[Me]&&(t.slot=e[Me].trim()),e.style&&e.style.trim()&&(t.style=e.style.trim()),t}function Ti(e,t){const i=(e||t||"").trim();if(!i)return null;const n=i.match(/!\[[\s\S]*?\]\(\s*([^\s)]+)(?:\s+(?:=["']?[^"'\s)]*["']?|["'][^"']*["']))*?\s*\)/);if(n)return n[1].trim();const s=i.match(/<img\b[^>]*?\bsrc=["']([^"']+)["']/i);if(s)return s[1].trim();const o=i.replace(/\{:[^}]*\}/g,"").trim();return/^(?:assets\/|https?:\/\/|\/|\.\.?\/)[^\s]+\.(?:png|jpe?g|gif|webp|svg|avif)(?:\?[^\s]*)?$/i.test(o)?o:null}function Dn(e){if(!e)return"";const t=e.split(/\r?\n/);if(t.length===0)return"";const i=t[0],n=i.match(/^(\s*)(?:[-*+]|\d+\.)\s+(.*)$/);if(!n)return e;const s=n[1].length,o=n[2].trim(),a=i.length-n[2].length;if(t.length===1)return o;const r=[o];for(let l=1;l<t.length;l++){const c=t[l];if(!c.trim()){r.push("");continue}const u=c.match(/^(\s*)/),d=u?u[1].length:0;d>=a?r.push(c.slice(a)):d>s?r.push(c.slice(d)):r.push(c)}return r.join(`
`)}function Mi(e){if(!e)return!1;const t=(e.type||"").toLowerCase();if(t==="i"||t==="nodelistitem"||t==="l"||t==="nodelist")return!0;const i=(e.markdown||e.rawMarkdown||e.content||"").trim();return!!/^(?:[-*+]|\d+\.)\s+/.test(i)}function co(e,t=2){if(!e||typeof e!="string")return`repeat(${t}, 1fr)`;const i=e.trim();if(!i)return`repeat(${t}, 1fr)`;if(i.includes(":")){const s=i.split(":").map(o=>parseFloat(o.trim())).filter(o=>!isNaN(o)&&o>0);if(s.length>=2)return s.map(o=>`${o}fr`).join(" ")}const n=i.split(/\s+/).filter(Boolean);return n.length>=2?n.join(" "):`repeat(${t}, 1fr)`}function Ln(e){if(!e)return[];if(at(e)&&Qt(e)&&!gi(e)){const n=vn(e),s=[];for(const o of n)s.push(...Ln(o));return s}const t=(e.type||"").toLowerCase();if(t==="l"||t==="nodelist"||t==="list"){if(e.children&&e.children.length>0){const a=e.children.filter(Mi);if(a.length>0)return a}const s=(e.markdown||e.content||"").trim().split(/\r?\n/),o=[];for(let a=0;a<s.length;a++)/^(?:[-*+]|\d+\.)\s+/.test(s[a])&&o.push(a);if(o.length>=2){const a=[];for(let r=0;r<o.length;r++){const l=o[r],c=r+1<o.length?o[r+1]:s.length,u=s.slice(l,c).join(`
`);a.push({id:`${e.id}-item-${r+1}`,type:"i",markdown:u,content:u,ial:{...e.ial||{}}})}return a}}return Mi(e)?[e]:[]}function lr(e){var s;if(!e||!at(e)||!Qt(e)||gi(e))return null;const t=vn(e);if(t.length===0)return null;if(t.length===1&&at(t[0])&&Qt(t[0])){const o=lr(t[0]);return o?{items:o.items,nestedSuperBlocks:[t[0],...o.nestedSuperBlocks]}:null}const i=[];for(const o of t)if(at(o)){i.push(o);const a=((s=o.children)==null?void 0:s.filter(at))||[];i.push(...a)}const n=t.map(Ln);if(n.length>=2&&n.every(o=>o.length>0)){const o=n.flat();if(o.length>=2&&o.length<=6)return{items:o,nestedSuperBlocks:i}}if(t.length===2){const o=Ln(t[0]),a=Ln(t[1]);if(o.length+a.length>=2&&o.length+a.length<=6&&(o.length>0||a.length>0))return{items:[...o,...a],nestedSuperBlocks:i}}return null}function Gf(e){if(!e||!at(e)||!Qt(e)||gi(e))return null;const t=lr(e);if(!t)return null;const{items:i,nestedSuperBlocks:n}=t;if(i.length<2||i.length>6)return null;const s=cr(e)||void 0,o=i.length;return{superBlockNode:e,nestedSuperBlocks:n,count:o,layout:"cols-header",items:i,slots:i.map((a,r)=>`col-${r+1}`),ratio:s}}function Bl(e){if(!e||!at(e)||!Qt(e)||gi(e))return null;const t=vn(e);if(t.length===0)return null;const i=[];for(const n of t){const s=Ln(n);if(s.length===0)return null;i.push(...s)}return i}function Kf(e){if(!e||!at(e)||!Qt(e)||gi(e))return null;const t=Bl(e);return!t||t.length===0||t.length>=2&&t.length<=6?null:{superBlockNode:e,items:t}}function qf(e){if(!e||!at(e)||!Qt(e)||gi(e))return null;const t=lr(e);if(t&&t.items.length===4)return t.items;const i=Bl(e);if(i&&i.length===4)return i;const n=vn(e);return n.length===4?n:null}function Yf(e,t){if(!e||e.length===0)return null;const i=[];function n(r,l){if(at(r)){const c=qf(r);c&&c.length===4&&i.push({sbNode:r,items:c,topLevelIndex:l})}if(r.children&&r.children.length>0)for(const c of r.children)n(c,l)}for(let r=0;r<e.length;r++)n(e[r],r);if(i.length===0)return null;let s=null;t&&(s=i.find(r=>{if(r.sbNode.id===t||r.items.some(c=>c.id===t))return!0;const l=c=>c.id===t?!0:c.children?c.children.some(l):!1;return l(r.sbNode)})||null),s||(s=i[0]);const a=e.slice(0,s.topLevelIndex).slice().reverse().find(r=>Dl(r));return{superBlockNode:s.sbNode,items:s.items,headerNode:a}}function Zf(e,t,i){var u,d,h,f,v;const n=[],s=[],o=(i==null?void 0:i.tracked)||[],a=[];let r={pageTargetId:e,blocks:[]};a.push(r);for(let m=0;m<t.length;m++){const b=t[m];if(Kn(b)){if(a.length===1&&r.blocks.length===0){r.pageTargetId=b.id,r.blocks.push(b);continue}r={pageTargetId:b.id,blocks:[b]},a.push(r)}else r.blocks.push(b)}function l(m){const b=[];for(const y of m)at(y)&&b.push(y),y.children&&y.children.length>0&&b.push(...l(y.children));return b}function c(m,b,y){const x={blockId:m,attrs:b,previousAttrs:y};n.push(x),i!=null&&i.onTagChange&&i.onTagChange(x)}for(const m of a){const b=m.pageTargetId,y=t.find(E=>E.id===b),x=o.find(E=>E.pageTargetId===b);if(m.blocks.some(E=>{var C,L;return!!(gi(E)||Po(E)&&(((C=E.ial)==null?void 0:C[Se])==="image-left"||((L=E.ial)==null?void 0:L[Se])==="image-right"))})){if(x){const E=x.headerId;if(E){c(E,{[Me]:""});const C=t.find(L=>L.id===E);C!=null&&C.ial&&(C.ial[Me]="")}for(const C of x.itemIds){c(C,{[Me]:""});const L=t.find(z=>z.id===C);L!=null&&L.ial&&(L.ial[Me]="")}}continue}let w=null,$=-1;for(let E=0;E<m.blocks.length;E++){const C=m.blocks[E],L=at(C)?[C,...l(C.children||[])]:C.children?l(C.children):[];for(const z of L){const H=Gf(z);if(H){w=H,$=E;break}}if(w)break}if(w){const{superBlockNode:E,layout:C,items:L,slots:z}=w,q=m.blocks.slice(0,$).find(M=>Dl(M)),_=q==null?void 0:q.id,N=((u=y==null?void 0:y.ial)==null?void 0:u[Se])||"",k=N==="clover",U=k?"clover":C;if(N!==U&&(c(b,{[Se]:U},{[Se]:N}),y&&(y.ial||(y.ial={}),y.ial[Se]=U)),q){const M=((d=q.ial)==null?void 0:d[Me])||"";M!=="header"&&(c(q.id,{[Me]:"header"},{[Me]:M}),q.ial||(q.ial={}),q.ial[Me]="header")}if(x!=null&&x.headerId&&x.headerId!==_){c(x.headerId,{[Me]:""});const M=t.find(B=>B.id===x.headerId);M&&(M.ial||(M.ial={}),M.ial[Me]="")}const F=[];for(let M=0;M<L.length;M++){const B=L[M],P=z[M];F.push(B.id);const se=((h=B.ial)==null?void 0:h[Me])||"";if(se!==P&&(c(B.id,{[Me]:P},{[Me]:se}),B.ial||(B.ial={}),B.ial[Me]=P),B.children&&B.children.length>0)for(const G of B.children)G.ial||(G.ial={}),G.ial[Me]!==P&&(G.ial[Me]=P)}if(x!=null&&x.itemIds){for(const M of x.itemIds)if(!F.includes(M)){c(M,{[Me]:""});const B=t.find(P=>P.id===M);B&&(B.ial||(B.ial={}),B.ial[Me]="")}}s.push({superBlockId:E.id,nestedSuperBlockIds:(f=w.nestedSuperBlocks)==null?void 0:f.map(M=>M.id),pageTargetId:b,headerId:_,itemIds:F,layout:k?"clover":C})}else{let E=!1;const C=[];for(const H of m.blocks){const q=at(H)?[H,...l(H.children||[])]:H.children?l(H.children):[];for(const _ of q){const N=Kf(_);if(N){E=!0;for(const k of N.items)C.push(k.id)}}}const L=((v=y==null?void 0:y.ial)==null?void 0:v[Se])||"",z=sn(L);if(x||E&&z){c(b,{[Se]:""},{[Se]:L}),y&&(y.ial||(y.ial={}),y.ial[Se]="");const H=x==null?void 0:x.headerId;if(H){c(H,{[Me]:""});const _=t.find(N=>N.id===H);_&&(_.ial||(_.ial={}),_.ial[Me]="")}const q=new Set([...(x==null?void 0:x.itemIds)||[],...C]);for(const _ of q){c(_,{[Me]:""});const N=t.find(k=>k.id===_);N&&(N.ial||(N.ial={}),N.ial[Me]="")}}}}return{changes:n,newTracked:s}}function at(e){if(!e)return!1;const t=(e.type||"").toLowerCase();return t==="s"||t==="sb"||t==="nodesuperblock"}function Qt(e){if(!at(e))return!1;const t=(e.subType||"").toLowerCase();if(t==="col"||t==="h"||t==="horizontal")return!0;if(t==="row"||t==="v"||t==="vertical")return!1;if(e.ial){const n=(e.ial["data-sb-layout"]||e.ial.layout||"").toLowerCase();if(n==="col"||n==="h")return!0;if(n==="row"||n==="v")return!1}if(e.children&&e.children.length>0){for(const n of e.children)if(n.type==="NodeSuperBlockLayoutMarker"||n.type==="layout-marker"){const s=(n.content||n.markdown||"").trim().toLowerCase();if(s==="col"||s==="h")return!0;if(s==="row"||s==="v")return!1}}const i=(e.markdown||e.content||"").trim();return/^\{\{\{col\b/i.test(i)?!0:!/^\{\{\{row\b/i.test(i)}function Po(e){return!e||Mi(e)||at(e)||!Ti(e.markdown,e.content)?!1:(e.markdown||e.content||"").replace(/!\[.*?\]\([^)]+\)/g,"").replace(/<img\b[^>]*>/gi,"").replace(/\{:[^}]*\}/g,"").trim().length<=25}function cr(e){var h;if(!e||!at(e)||!Qt(e))return null;const t=vn(e);if(!t||t.length<2)return null;const i=[];let n=!1;for(const f of t){const v=(((h=f.ial)==null?void 0:h.style)||f.style||"").trim();let m=null;if(v){const b=v.match(/calc\(\s*([\d.]+)%/i);if(b)m=parseFloat(b[1]);else{const y=v.match(/(?:^|;|\s)width:\s*([\d.]+)%/i);y&&(m=parseFloat(y[1]))}}m!==null&&!isNaN(m)&&m>0?(i.push(m),n=!0):i.push(null)}if(!n)return null;const s=t.length,o=i.reduce((f,v)=>f+(v||0),0),a=i.filter(f=>f===null).length,r=Math.max(0,100-o),l=a>0?r/a:100/s,c=i.map(f=>f!==null?f:l),u=c.reduce((f,v)=>f+v,0);if(u<=0)return null;const d=c.map(f=>f/u*100);if(d.length===2){const[f]=d;if(f>=48&&f<=52)return"1:1";if(f>=31&&f<=35)return"1:2";if(f>=65&&f<=69)return"2:1";if(f>=28&&f<=32)return"3:7";if(f>=68&&f<=72)return"7:3";if(f>=38&&f<=42)return"4:6";if(f>=58&&f<=62)return"6:4";if(f>=23&&f<=27)return"1:3";if(f>=73&&f<=77)return"3:1";const v=Math.round(f),m=100-v;return`${v}:${m}`}if(d.length===3){const[f,v,m]=d;if(f>=31&&f<=35&&v>=31&&v<=35&&m>=31&&m<=35)return"1:1:1";if(f>=23&&f<=27&&v>=48&&v<=52&&m>=23&&m<=27)return"1:2:1";if(f>=48&&f<=52&&v>=23&&v<=27&&m>=23&&m<=27)return"2:1:1";if(f>=23&&f<=27&&v>=23&&v<=27&&m>=48&&m<=52)return"1:1:2";if(f>=18&&f<=22&&v>=58&&v<=62&&m>=18&&m<=22)return"1:3:1";const b=Math.round(f),y=Math.round(v),x=100-b-y;return`${b}:${y}:${x}`}return d.map(f=>Math.round(f)).join(":")}function gi(e){if(!e||!at(e)||!Qt(e))return null;const t=(e.children||[]).filter(o=>{const a=o.type||"";if(a==="NodeSuperBlockOpenMarker"||a==="NodeSuperBlockLayoutMarker"||a==="NodeSuperBlockCloseMarker"||a==="open-marker"||a==="layout-marker"||a==="close-marker")return!1;const r=(o.markdown||o.content||"").trim();return!(/^\{\{\{(?:col|row)?\s*$/i.test(r)||r==="}}}")});if(t.length<2)return null;const i=Po(t[0]),n=Po(t[t.length-1]),s=cr(e)||void 0;if(i&&!n){const o=Ti(t[0].markdown,t[0].content);if(o)return{imageNode:t[0],imageUrl:o,layout:Ss,contentNodes:t.slice(1),ratio:s}}if(!i&&n){const o=Ti(t[t.length-1].markdown,t[t.length-1].content);if(o)return{imageNode:t[t.length-1],imageUrl:o,layout:Cs,contentNodes:t.slice(0,t.length-1),ratio:s}}return null}function Jf(e,t){const i=[];function n(s){for(const o of s){const a=gi(o);if(a){const{imageNode:r,layout:l,ratio:c}=a;r.ial||(r.ial={});const u=r.ial[Se];if(u!==l){const h={blockId:r.id,layout:l,previousLayout:u,ratio:c};r.ial[Se]=l,i.push(h),t&&t(h)}}o.children&&o.children.length>0&&n(o.children)}}return n(e),i}function vn(e){return(e.children||[]).filter(t=>{const i=t.type||"";if(i==="NodeSuperBlockOpenMarker"||i==="NodeSuperBlockLayoutMarker"||i==="NodeSuperBlockCloseMarker"||i==="open-marker"||i==="layout-marker"||i==="close-marker")return!1;const n=(t.markdown||t.content||"").trim();return!(/^\{\{\{(?:col|row)?\s*$/i.test(n)||n==="}}}")})}function Dl(e){if(!e)return!1;const t=(e.type||"").toLowerCase();if(t==="h"||t==="nodeheading"||/^h[1-6]$/i.test(e.subType||""))return!0;const i=(e.markdown||e.content||"").trim();return!!/^#{1,6}\s+/.test(i)}function Pi(e,t,i){let n="",s=0;const o=/<div\b([^>]*)>/gi;for(;s<e.length;){o.lastIndex=s;let a,r=!1,l=-1,c=0;for(;(a=o.exec(e))!==null;){const y=a[1].match(/\bclass=["']([^"']*)["']/i);if(y){const x=y[1];if(typeof t=="string"?x.split(/\s+/).includes(t):t.test(x)){r=!0,l=a.index,c=a[0].length;break}}}if(!r){n+=e.slice(s);break}n+=e.slice(s,l);const u=l+c;let d=1,h=-1,f=-1;const v=/<\/?div\b[^>]*>/gi;v.lastIndex=u;let m;for(;(m=v.exec(e))!==null;)if(m[0].startsWith("</")){if(d--,d===0){h=m.index,f=m.index+m[0].length;break}}else d++;if(h!==-1&&f!==-1){const b=e.slice(u,h);n+=i(b),s=f}else n+=e.slice(l,u),s=u}return n}function Xf(e){const t=[];let i="",n=0;const s=/<div\b([^>]*)>/gi;for(;n<e.length;){s.lastIndex=n;let o,a=!1,r=-1,l=0;for(;(o=s.exec(e))!==null;){const m=o[1];if(/(?:\s@[a-zA-Z0-9_-]+=\s*["']|\s:[a-zA-Z0-9_-]+=\s*["']|\sv-[a-zA-Z0-9_.-]+|\shover:[a-zA-Z0-9_.-]+=\s*["']|\sgrid=["']~|\bclass=["'][^"']*\b(?:abs-br|slidev-icon-btn|grid\s+|grid$|grid-cols-|relative\b)\b[^"']*["']|\bstyle=["'][^"']*\bgrid-[^"']*["'])/i.test(m)){a=!0,r=o.index,l=o[0].length;break}}if(!a){i+=e.slice(n);break}i+=e.slice(n,r);const c=r+l;let u=1,d=-1,h=-1;const f=/<\/?div\b[^>]*>/gi;f.lastIndex=c;let v;for(;(v=f.exec(e))!==null;)if(v[0].startsWith("</")){if(u--,u===0){d=v.index,h=v.index+v[0].length;break}}else u++;if(d!==-1&&h!==-1){const m=e.slice(r,h),b=`__VUE_DIV_TOKEN_${t.length}__`;t.push(m),i+=b,n=h}else i+=e.slice(r,c),n=c}return{text:i,tokens:t}}function Qf(e){const t=[];let i=e.replace(/(?:^[ \t]*(`{3,}|~{3,})[^\n\r]*\r?\n[\s\S]*?\r?\n[ \t]*\1(?=[ \t]*(?:\r?\n|$)))/gm,r=>{const l=`__CODE_TOKEN_${t.length}__`;return t.push(r),l});i=i.replace(/(`+)(?:[^\n\r`]|(?!\1)`)+?\1/g,r=>{const l=`__CODE_TOKEN_${t.length}__`;return t.push(r),l});const n=[];i=i.replace(/<script\b[^>]*>[\s\S]*?<\/script>/gi,r=>{const l=`__SCRIPT_TOKEN_${n.length}__`;return n.push(r),l});const{text:s,tokens:o}=Xf(i);i=s;const a=[];i=i.replace(/<(?:[A-Z][a-zA-Z0-9_-]*|[a-z0-9_-]+:[a-z0-9_-]+|v-[a-z0-9_-]+|arrow\b|div\s+h-\d+)\b[^>]*\/>/gi,r=>{const l=`__VUE_COMP_TOKEN_${a.length}__`;return a.push(r),l}),i=i.replace(/<(v-[a-z0-9_-]+|button)\b([^>]*)>([\s\S]*?)<\/\1>/gi,r=>{const l=`__VUE_COMP_TOKEN_${a.length}__`;return a.push(r),l}),i=i.replace(/<img\b[^>]*?\bv-[a-z0-9_.-]+[^>]*\/?>/gi,r=>{const l=`__VUE_COMP_TOKEN_${a.length}__`;return a.push(r),l}),i=i.replace(/<(p|span)\b([^>]*?\bv-[a-z0-9_.-]+[^>]*)>([\s\S]*?)<\/\1>/gi,r=>{const l=`__VUE_COMP_TOKEN_${a.length}__`;return a.push(r),l}),i=i.replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi,""),i=i.replace(/<div class="terminal-bar">[\s\S]*?<\/div>/gi,""),i=i.replace(/<div class="cursor-line">[\s\S]*?<\/div>/gi,""),i=i.replace(/<span class="cursor">[\s\S]*?<\/span>/gi,""),i=i.replace(/<div class="stamp">\s*([\s\S]*?)\s*<\/div>/gi,`

*[$1]*

`),i=i.replace(/<div class="arrow">\s*([→\->]+)\s*<\/div>/gi,`

$1

`),i=i.replace(/<i>\s*[→\->]+\s*<\/i>/gi,""),i=i.replace(/<div class="prompt">\s*([\s\S]*?)\s*<\/div>/gi,(r,l)=>`
\`\`\`bash
${l.trim()}
\`\`\`
`),i=i.replace(/<p>\s*<i>\$<\/i>\s*([\s\S]*?)<\/p>/gi,(r,l)=>`
\`\`\`bash
$ ${l.trim()}
\`\`\`
`),i=i.replace(/<div class="statusline">\s*([\s\S]*?)\s*<\/div>/gi,(r,l)=>`
> ${Array.from(l.matchAll(/<span>([\s\S]*?)<\/span>/gi)).map(u=>`\`${u[1].trim()}\``).join(" | ")}
`),i=i.replace(/<div class="log-panel">\s*<pre>([\s\S]*?)<\/pre>\s*<\/div>/gi,(r,l)=>`
\`\`\`log
${l.replace(/<span[^>]*>([\s\S]*?)<\/span>/gi,"$1").trim()}
\`\`\`
`),i=Pi(i,"diff-grid",r=>{const l=Array.from(r.matchAll(/<div class="diff\s+([^"]*)">\s*<span>(.*?)<\/span>\s*<pre>([\s\S]*?)<\/pre>\s*<\/div>/gi));return l.length>0?`
`+l.map(c=>{const u=c[2].trim().toUpperCase(),d=c[3].trim();return`**${u}:**
\`\`\`yaml
${d}
\`\`\``}).join(`

`)+`
`:r}),i=Pi(i,"before-after",r=>{const l=r.match(/<div class="before">[\s\S]*?<small>(.*?)<\/small>[\s\S]*?<h2>(.*?)<\/h2>[\s\S]*?<p>(.*?)<\/p>\s*<\/div>/i),c=r.match(/<div class="after">[\s\S]*?<small>(.*?)<\/small>[\s\S]*?<h2>(.*?)<\/h2>[\s\S]*?<p>(.*?)<\/p>\s*<\/div>/i);let u=`
`;return l&&(u+=`### ${l[1]}
## ${l[2]}
${l[3]}

`),c&&(u+=`### ${c[1]}
## ${c[2]}
${c[3]}
`),u.trim()?u:r}),i=i.replace(/<ul\b[^>]*>([\s\S]*?)<\/ul>/gi,(r,l)=>{const c=Array.from(l.matchAll(/<li>\s*(?:<em>)?(\[[x ]\])(?:<\/em>)?\s*([\s\S]*?)<\/li>/gi));return c.length>0?`
`+c.map(u=>`- ${u[1]} ${u[2].trim()}`).join(`
`)+`
`:l}),i=Pi(i,"timeline",r=>{const l=Array.from(r.matchAll(/<div(?:\s+class="([^"]*)")?>\s*<time>([\s\S]*?)<\/time>\s*<b>([\s\S]*?)<\/b>\s*<span>([\s\S]*?)<\/span>\s*<\/div>/gi));return l.length>0?`

`+l.map(c=>{const u=c[1]||"";let d="-";return u.includes("warn")?d="- ⚠️":u.includes("bad")?d="- ❌":u.includes("ok")&&(d="- ✅"),`${d} **${c[2].trim()}** **${c[3].trim()}** — ${c[4].trim()}`}).join(`
`)+`

`:r}),i=Pi(i,"pipeline",r=>{const l=Array.from(r.matchAll(/<div(?:\s+class="([^"]*)")?>\s*<small>([\s\S]*?)<\/small>\s*<b>([\s\S]*?)<\/b>\s*<span>([\s\S]*?)<\/span>\s*<\/div>/gi));return l.length>0?`

`+l.map((c,u)=>{const h=(c[1]||"").includes("hot")?"⚠️ ":"";return`${u+1}. ${h}**${c[3].trim()}** (*${c[4].trim()}*)`}).join(`
`)+`

`:r}),i=Pi(i,"check-grid",r=>{const l=Array.from(r.matchAll(/<div>\s*<span class="([^"]*)"><\/span>\s*<b>([\s\S]*?)<\/b>\s*<p>([\s\S]*?)<\/p>\s*<\/div>/gi));return l.length>0?`

`+l.map(c=>`- ${(c[1]||"").includes("warn")?"⚠️":"✅"} **${c[2].trim()}**: ${c[3].trim()}`).join(`
`)+`

`:r}),i=Pi(i,"manifesto",r=>{const l=Array.from(r.matchAll(/<div>\s*<span>([\s\S]*?)<\/span>\s*<h2>([\s\S]*?)<\/h2>\s*<p>([\s\S]*?)<\/p>\s*<\/div>/gi));return l.length>0?`

`+l.map(c=>`## ${c[1].trim()} ${c[2].trim()}

${c[3].trim()}`).join(`

`)+`

`:r}),i=Pi(i,"split-note",r=>{const l=Array.from(r.matchAll(/<div>\s*<b>([\s\S]*?)<\/b>\s*<p>([\s\S]*?)<\/p>\s*<\/div>/gi));return l.length>0?`

`+l.map(c=>`> **${c[1].trim()}**: ${c[2].trim()}`).join(`
>
`)+`

`:r}),i=i.replace(/<div class="mechanism">\s*<b>([\s\S]*?)<\/b>\s*<p>([\s\S]*?)<\/p>\s*<\/div>/gi,(r,l,c)=>`

> **${l.trim()}**: ${c.trim()}

`),i=i.replace(/<pre>([\s\S]*?)<\/pre>/gi,(r,l)=>`
\`\`\`text
${l.replace(/<span[^>]*>([\s\S]*?)<\/span>/gi,"$1").trim()}
\`\`\`
`),i=i.replace(/<div class="page-head">\s*<span>([\s\S]*?)<\/span>\s*<b>([\s\S]*?)<\/b>\s*<\/div>/gi,`
### $1 ($2)
`),i=i.replace(/<h1\b[^>]*>([\s\S]*?)<\/h1>/gi,`
# $1
`),i=i.replace(/<h2\b[^>]*>([\s\S]*?)<\/h2>/gi,`
## $1
`),i=i.replace(/<h3\b[^>]*>([\s\S]*?)<\/h3>/gi,`
### $1
`),i=i.replace(/<h4\b[^>]*>([\s\S]*?)<\/h4>/gi,`
#### $1
`),i=i.replace(/<p\s+class="ok">\s*●\s*([\s\S]*?)<\/p>/gi,`
✅ **$1**
`),i=i.replace(/<p\s+class="caption">\s*([\s\S]*?)<\/p>/gi,`
> *$1*
`),i=i.replace(/<p\s+class="lead">\s*([\s\S]*?)<\/p>/gi,`
*$1*
`),i=i.replace(/<p\b([^>]*)>([\s\S]*?)<\/p>/gi,(r,l,c)=>/@|v-|:|class=/i.test(l)?r:`
${c.trim()}

`),i=i.replace(/<br\s*\/?>/gi,`
`),i=i.replace(/<hr\s*\/?>/gi,`
---
`),i=i.replace(/<b\b[^>]*>([\s\S]*?)<\/b>/gi,"**$1**"),i=i.replace(/<strong\b[^>]*>([\s\S]*?)<\/strong>/gi,"**$1**"),i=i.replace(/<i\b[^>]*>([\s\S]*?)<\/i>/gi,"*$1*"),i=i.replace(/<code\b[^>]*>([\s\S]*?)<\/code>/gi,(r,l)=>{if(l.startsWith("`")&&l.endsWith("`"))return l;if(l.includes("`")){const c=(l.match(/`+/g)||[]).reduce((d,h)=>Math.max(d,h.length),0),u="`".repeat(c+1);return`${u} ${l} ${u}`}return`\`${l}\``}),i=i.replace(/<small\b[^>]*>([\s\S]*?)<\/small>/gi,"*$1*"),i=i.replace(/\*{4}/g,"** **"),i=i.replace(/<li\b[^>]*>([\s\S]*?)<\/li>/gi,`- $1
`),i=i.replace(/<ul\b[^>]*>([\s\S]*?)<\/ul>/gi,`
$1
`),i=i.replace(/<ol\b[^>]*>([\s\S]*?)<\/ol>/gi,`
$1
`),i=i.replace(/<a\b([^>]*)href=["'](.*?)["']([^>]*)>([\s\S]*?)<\/a>/gi,(r,l,c,u,d)=>{const h=d.trim();return h.includes("<")||h.includes(`
`)?r:`[${h}](${c})`}),i=i.replace(/<blockquote\b[^>]*>([\s\S]*?)<\/blockquote>/gi,(r,l)=>`
`+l.trim().split(`
`).map(c=>`> ${c.trim()}`).join(`
`)+`
`),i=i.replace(/<span\b[^>]*data-type=["']block-ref["'][^>]*data-id=["']([0-9a-zA-Z-]+)["'][^>]*>([\s\S]*?)<\/span>/gi,(r,l,c)=>{const u=c.replace(/<[^>]+>/g,"").trim();return u?`((${l} '${u}'))`:`((${l}))`}),i=i.replace(/<span\b[^>]*data-type=["']a["'][^>]*data-href=["']([^"']+)["'][^>]*>([\s\S]*?)<\/span>/gi,(r,l,c)=>`[${c.replace(/<[^>]+>/g,"").trim()}](${l})`),i=i.replace(/<\/(?:div|section|header|footer|main|article|nav|aside)\b[^>]*>/gi,`
`),i=i.replace(/<(?:div|section|header|footer|main|article|nav|aside)\b[^>]*>/gi,""),i=i.replace(/<\/?span\b[^>]*>/gi,"");for(let r=0;r<a.length;r++)i=i.replace(`__VUE_COMP_TOKEN_${r}__`,()=>a[r]);for(let r=0;r<o.length;r++)i=i.replace(`__VUE_DIV_TOKEN_${r}__`,()=>o[r]);for(let r=0;r<n.length;r++)i=i.replace(`__SCRIPT_TOKEN_${r}__`,()=>n[r]);for(let r=0;r<t.length;r++)i=i.replace(`__CODE_TOKEN_${r}__`,()=>t[r]);return i=i.replace(/\n{3,}/g,`

`).trim(),i}function Ll(e){if(!e||typeof e!="string")return"";const t=[];let i=e.replace(/`([^`]+)`/g,n=>(t.push(n),`%%INLINE_CODE_${t.length-1}%%`));return i=i.replace(/(<\/[a-zA-Z0-9_-]+>)\s*\{:[^}]*\}/g,"$1"),i=i.replace(/(\[[^\]]+\]\([^)]+\))\s*\{:\s*style=["']([^"']*)["'][^}]*\}/g,'<span style="$2">$1</span>'),i=i.replace(/(\*\*[^*]+\*\*)\s*\{:\s*style=["']([^"']*)["'][^}]*\}/g,'<span style="$2">$1</span>'),i=i.replace(/(\*[^*]+\*)\s*\{:\s*style=["']([^"']*)["'][^}]*\}/g,'<span style="$2">$1</span>'),i=i.replace(/(~~[^~]+~~)\s*\{:\s*style=["']([^"']*)["'][^}]*\}/g,'<span style="$2">$1</span>'),i=i.replace(/([\p{L}\p{N}_\-]+)\s*\{:\s*style=["']([^"']*)["'][^}]*\}/gu,'<span style="$2">$1</span>'),i=i.replace(/\{:[^}]*\}/g,""),i=i.replace(/%%INLINE_CODE_(\d+)%%/g,(n,s)=>t[parseInt(s,10)]||""),i}function ep(e){const t=Object.entries(e).filter(([n,s])=>s!=null&&s!=="");return t.length===0?"":`---
${t.map(([n,s])=>typeof s=="string"?s.includes(":")||s.includes(`
`)||s.includes("#")?`${n}: "${s.replace(/"/g,'\\"')}"`:`${n}: ${s}`:`${n}: ${JSON.stringify(s)}`).join(`
`)}
---`}function tp(e,t){if(!t||!e.startsWith("```"))return e;const i=e.indexOf(`
`);if(i===-1)return e;const n=e.slice(0,i).trim(),s=e.slice(i);return n.includes("{")?e:`${n} {${t}}${s}`}function Pl(e,t){if(t==null)return e;const i=t.trim();return i===""||i==="+1"?`<v-click>

${e}

</v-click>`:i==="hide"?`<v-click hide>

${e}

</v-click>`:`<v-click at="${i}">

${e}

</v-click>`}function ip(e){if(!e||!e.preset)return null;const t=e.preset.toLowerCase().trim();if(!t||t==="none")return null;let i={opacity:0},n={opacity:1};switch(t){case"slide-up":i={y:40,opacity:0},n={y:0,opacity:1};break;case"slide-down":i={y:-40,opacity:0},n={y:0,opacity:1};break;case"slide-left":i={x:40,opacity:0},n={x:0,opacity:1};break;case"slide-right":i={x:-40,opacity:0},n={x:0,opacity:1};break;case"zoom-in":case"pop":i={scale:.8,opacity:0},n={scale:1,opacity:1};break;case"bounce":i={y:40,opacity:0},n={y:0,opacity:1,transition:{type:"spring",damping:10,stiffness:100}};break;case"fade-in":default:i={opacity:0},n={opacity:1};break}e.initial&&typeof e.initial=="object"&&(i={...i,...e.initial}),e.enter&&typeof e.enter=="object"&&(n={...n,...e.enter});const s={...n.transition||{}};return typeof e.duration=="number"&&e.duration>0&&(s.duration=e.duration),typeof e.delay=="number"&&e.delay>0&&(s.delay=e.delay),Object.keys(s).length>0&&(n.transition=s),{initial:i,enter:n}}function ls(e,t,i,n,s){const o=t!=null&&t.trim()!=="",a=ip(i),r=s?/^\d+$/.test(s.trim())?`${s.trim()}px`:s.trim():"",l=r?`max-height:${r};overflow-y:auto`:"",c=[n==null?void 0:n.trim(),l].filter(Boolean).join(";"),u=c!==void 0&&c!=="",d=u?` style="${c.replace(/"/g,"&quot;")}" class="slide-styled-block"`:"";if(!o&&!a)return u?`<div${d}>

${e}

</div>`:e;if(o&&!a){if(u){const y=t.trim();let x="v-click";return y==="hide"?x="v-click.hide":y!==""&&y!=="+1"&&(x=`v-click="${y}"`),`<div ${x}${d}>

${e}

</div>`}return Pl(e,t)}const h=JSON.stringify(a.initial).replace(/"/g,"'"),f=JSON.stringify(a.enter).replace(/"/g,"'"),v=`v-motion :initial="${h}" :enter="${f}"`;if(!o)return`<div ${v}${d}>

${e}

</div>`;const m=t.trim();let b="v-click";return m==="hide"?b="v-click.hide":m!==""&&m!=="+1"&&(b=`v-click="${m}"`),`<div ${b} ${v}${d}>

${e}

</div>`}function dr(e){if(!e)return"";let t=e.trim();t=t.replace(/\{:[^}]*\}/g,"").trim(),t=t.replace(/^:::\s*[a-zA-Z0-9_-]*\s*\r?\n?/g,""),t=t.replace(/\r?\n?:::\s*$/g,"");let s=t.split(/\r?\n/).map(o=>o.trim().replace(/^>\s*/,"")).join(`
`).trim();return s=s.replace(/^\[!(?:NOTE|TIP|IMPORTANT|WARNING|CAUTION|[A-Za-z_-]+)\][^\r\n]*(?:\r?\n)?/i,"").trim(),s=s.replace(/^(?:💡|✏️|❗|⚠️|🚨|\s*)*(?:\*\*|__)?(?:演讲备注|演讲者提词|讲稿备注|演讲提词|备注|Notes?)(?:\*\*|__)?[:：]?\s*(?:\r?\n)?/i,"").trim(),s=s.replace(/^[-*+]\s+/,""),s=s.replace(/^\d+\.\s+/,""),s.trim()}function np(e){var n;if(e.subType&&/^h([1-6])$/i.test(e.subType))return parseInt(e.subType.slice(1),10);const i=(e.markdown||e.content||"").trim().match(/^(#{1,6})\s+/);return i?i[1].length:e.type==="h"?(n=e.ial)!=null&&n.subType&&/^h([1-6])$/i.test(e.ial.subType)?parseInt(e.ial.subType.slice(1),10):1:null}function Ol(e,t=2){const i=Math.max(2,t);if(!e||e.length===0)return Array.from({length:i},()=>[]);if(e.length===1&&e[0].children&&e[0].children.length>=2){const c=e[0].children,u=Array.from({length:i},()=>[]),d=Math.min(i,c.length),h=Math.floor(c.length/d),f=c.length%d;let v=0;for(let m=0;m<d;m++){const b=h+(m<f?1:0);u[m]=c.slice(v,v+b),v+=b}return u}if(e.length===1){const c=e[0],d=(c.slot||"").trim().match(/^col-(\d+)$/i),h=d?parseInt(d[1],10):null,f=(c.rawMarkdown||c.content||"").trim(),v=f.split(/\r?\n/),m=[];for(let x=0;x<v.length;x++)/^[ \t]*[-*+]\s+|^[ \t]*\d+\.\s+/.test(v[x])&&m.push(x);if(m.length>=i){const x=Array.from({length:i},()=>[]);let S=0;for(let w=0;w<i;w++){const $=i-w,E=m.length-S,C=Math.ceil(E/$),L=m[S],z=S+C<m.length?m[S+C]:v.length,H=v.slice(L,z).join(`
`);x[w]=[{...c,id:w===0?c.id:`${c.id}-col${w+1}`,rawMarkdown:H,content:H}],S+=C}return x}const b=f.match(/<li[\s\S]*?<\/li>/gi);if(b&&b.length>=i){const x=Array.from({length:i},()=>[]);let S=0;for(let w=0;w<i;w++){const $=i-w,E=b.length-S,C=Math.ceil(E/$),L=`<ul>
${b.slice(S,S+C).join(`
`)}
</ul>`;x[w]=[{...c,id:w===0?c.id:`${c.id}-col${w+1}`,rawMarkdown:L,content:L}],S+=C}return x}const y=f.split(/\r?\n\s*\r?\n/).filter(x=>x.trim()!=="");if(y.length>=i){const x=Array.from({length:i},()=>[]);let S=0;for(let w=0;w<i;w++){const $=i-w,E=y.length-S,C=Math.ceil(E/$),L=y.slice(S,S+C).join(`

`);x[w]=[{...c,id:w===0?c.id:`${c.id}-col${w+1}`,rawMarkdown:L,content:L}],S+=C}return x}if(h&&h>=1&&h<=i){const x=Array.from({length:i},()=>[]);return x[h-1]=[c],x}return[[c],...Array.from({length:i-1},()=>[])]}const n=c=>{const u=(c.slot||"").trim();if(!u)return null;if(u==="left")return 1;if(u==="center")return 2;if(u==="right")return i===2?2:i;const d=u.match(/^col-(\d+)$/i);if(d){const h=parseInt(d[1],10);if(h>=1&&h<=i)return h}return null},s=e.map(n);if(s.some(c=>c!==null)){if(s.some(f=>f!==null&&f>=2)){const f=Array.from({length:i},()=>[]);let v=1;for(const b of e){const y=n(b);y!==null&&(v=y),f[v-1].push(b)}if(!e.some(b=>/^col-\d+$/i.test((b.slot||"").trim()))&&f[0].length===0){const b=f.filter(y=>y.length>0);if(b.length===1)return[b[0],...Array.from({length:i-1},()=>[])]}return f}const u=e.filter(f=>n(f)===1),d=e.filter(f=>n(f)===null),h=i-1;if(d.length>=h){const f=Math.floor(d.length/h),v=d.length%h,m=[u];let b=0;for(let y=0;y<h;y++){const x=f+(y<v?1:0);m.push(d.slice(b,b+x)),b+=x}return m}else if(d.length>0){const f=[u];for(let v=0;v<h;v++)f.push(v<d.length?[d[v]]:[]);return f}else return[u,...Array.from({length:h},()=>[])]}const a=c=>{if(c.type==="h"||c.subType&&/^h[1-6]$/i.test(c.subType))return!0;const u=(c.rawMarkdown||c.content||"").trim();return/^#{1,6}\s+/.test(u)},r=e.map((c,u)=>a(c)?u:-1).filter(c=>c!==-1);if(r.length>=i){const c=Array.from({length:i},()=>[]);for(let u=0;u<i;u++){const d=r[u],h=u+1<i?r[u+1]:e.length;c[u]=e.slice(d,h)}return c}if(e.length>=i){const c=Array.from({length:i},()=>[]);let u=0;for(let d=0;d<i;d++){const h=i-d,f=e.length-u,v=Math.ceil(f/h);c[d]=e.slice(u,u+v),u+=v}return c}if(e.length>1&&e.length<i){const c=Array.from({length:i},()=>[]);for(let u=0;u<e.length;u++)c[u]=[e[u]];return c}const l=Array.from({length:i},()=>[]);return l[0]=e,l}function na(e,t,i,n){var u;const s=Uf(t),o=[],a=ia(t);let r={pageIndex:1,startBlockId:e,frontmatter:{layout:a.frontmatter.layout||"cover",...a.frontmatter},notes:"",noteBlocks:[],blocks:[],rawMarkdown:"",allBlockIds:[e]};r.frontmatter.background&&(r.frontmatter.background=Bt(r.frontmatter.background,n)),r.frontmatter.image&&(r.frontmatter.image=Bt(r.frontmatter.image,n)),o.push(r);let l=[];for(const d of i){if(Kn(d)){l=[];const f=ia(d.ial);if(o.length===1&&r.blocks.length===0){r.startBlockId=d.id,r.allBlockIds||(r.allBlockIds=[]),r.allBlockIds.includes(d.id)||r.allBlockIds.push(d.id),f.frontmatter.layout&&(r.frontmatter.layout=f.frontmatter.layout),Object.assign(r.frontmatter,f.frontmatter),!f.frontmatter.image&&a.frontmatter.image&&(r.frontmatter.image=a.frontmatter.image),!f.frontmatter.background&&a.frontmatter.background&&(r.frontmatter.background=a.frontmatter.background),r.frontmatter.background&&(r.frontmatter.background=Bt(r.frontmatter.background,n)),r.frontmatter.image&&(r.frontmatter.image=Bt(r.frontmatter.image,n));continue}r={pageIndex:o.length+1,startBlockId:d.id,frontmatter:{layout:f.frontmatter.layout||"default",...f.frontmatter},notes:"",noteBlocks:[],blocks:[],rawMarkdown:"",allBlockIds:[d.id]},r.frontmatter.background&&(r.frontmatter.background=Bt(r.frontmatter.background,n)),r.frontmatter.image&&(r.frontmatter.image=Bt(r.frontmatter.image,n)),o.push(r);continue}const h=(f,v)=>{var se,G,K,ce,ie,oe;if(r.allBlockIds||(r.allBlockIds=[]),f.id&&!r.allBlockIds.includes(f.id)&&r.allBlockIds.push(f.id),f.children&&f.children.length>0){const re=be=>{for(const ke of be)ke.id&&!r.allBlockIds.includes(ke.id)&&r.allBlockIds.push(ke.id),ke.children&&ke.children.length>0&&re(ke.children)};re(f.children)}let m=ud(f),b=f.ial?{...f.ial}:{};const y=m.match(/\{:\s*([^}]+)\s*\}\s*$/);y&&(b={...ya(y[0]),...b},m=m.slice(0,y.index).trim()),f.type!=="c"&&!m.startsWith("```")&&(m=Ll(m));let x=m.trim();if(/^\{\{\{(?:row|col)?\s*$/i.test(x)||x==="}}}")return;/^\{\{\{(?:row|col)?\s*\r?\n/i.test(x)&&/\r?\n\}\}\}$/.test(x)&&(m=x.replace(/^\{\{\{(?:row|col)?\s*\r?\n/i,"").replace(/\r?\n\}\}\}$/,"").trim(),x=m.trim());const S=Vf(b);if(m=md(m,n),m=pd(m,n==null?void 0:n.refContentMap),f.children&&f.children.length>0){const re=["custom-slides-autoplay","custom-slides-loop","custom-slides-muted","custom-slides-controls"],be=ke=>{for(const le of ke){if(le.ial)for(const[J,he]of Object.entries(le.ial))re.includes(J)&&!b[J]&&(b[J]=he);le.children&&le.children.length>0&&be(le.children)}};be(f.children)}const w=f.type==="video"||f.type==="NodeVideo"||/<video\b/i.test(m);if(w){const re=b["custom-slides-autoplay"]==="true",be=b["custom-slides-loop"]==="true",ke=b["custom-slides-muted"]==="true"||re,le=b["custom-slides-controls"]==="false";m=m.replace(/<video\b([^>]*)>/gi,(J,he)=>{let D=he;return le?D=D.replace(/\bcontrols(?:="[^"]*")?/gi,"").trim():/controls/i.test(D)||(D+=" controls"),re&&!/autoplay/i.test(D)?D+=" autoplay playsinline":!re&&b["custom-slides-autoplay"]==="false"&&(D=D.replace(/\bautoplay\b/gi,"").replace(/\bplaysinline\b/gi,"").trim()),be&&!/loop/i.test(D)?D+=" loop":!be&&b["custom-slides-loop"]==="false"&&(D=D.replace(/\bloop\b/gi,"").trim()),ke&&!/muted/i.test(D)?D+=" muted":!ke&&b["custom-slides-muted"]==="false"&&(D=D.replace(/\bmuted\b/gi,"").trim()),`<video ${D.trim()}>`})}if(S.isBackground){const re=Ti(m,f.content);if(re){r.frontmatter.background=Bt(re,n);return}}const $=gi(f);if($){r.frontmatter.layout=$.layout,r.frontmatter.image=Bt($.imageUrl,n),!r.frontmatter.layoutRatio&&$.ratio&&(r.frontmatter.layoutRatio=$.ratio);for(const re of $.contentNodes)h(re);return}if(S.imageLayout==="image-left"||S.imageLayout==="image-right"){const re=Ti(m,f.content);if(re){r.frontmatter.layout=S.imageLayout,r.frontmatter.image=Bt(re,n),!r.frontmatter.layoutRatio&&((se=f.ial)!=null&&se[wt])&&(r.frontmatter.layoutRatio=f.ial[wt]);return}}if(at(f)&&f.children&&f.children.length>0){for(const re of f.children)h(re);return}const E=!!(S.slot||v!=null&&v.defaultSlot||r.frontmatter.layout==="clover"||sn(r.frontmatter.layout)||r.frontmatter.layout==="two-cols"),C=!!(f.children&&f.children.some(re=>{var be,ke;return((be=re.ial)==null?void 0:be[Me])||((ke=re.ial)==null?void 0:ke[Re])||re.children&&re.children.length>=2||re.children&&re.children.some(le=>{var J,he,D,W,g,V;return((J=le.ial)==null?void 0:J[Re])||((he=le.ial)==null?void 0:he[Me])||((D=le.ial)==null?void 0:D[Ze])||((W=le.ial)==null?void 0:W[Se])||((g=le.ial)==null?void 0:g["custom-slides-role"])||((V=le.ial)==null?void 0:V["custom-slides-layout"])})}));if((f.type==="l"||f.type==="NodeList"||f.type==="list")&&f.children&&f.children.length>0&&(C||S.slot||S.clicks||E)){const re=/^\s*\d+\.\s+/m.test(f.markdown||"")||f.subType==="o"||f.subtype==="o";for(let be=0;be<f.children.length;be++){const ke=f.children[be];S.slot&&(!ke.ial||!ke.ial[Me])&&(ke.ial||(ke.ial={}),ke.ial[Me]=S.slot),h(ke,{...v,parentClicks:S.clicks||(v==null?void 0:v.parentClicks),defaultSlot:S.slot||(v==null?void 0:v.defaultSlot),isParentListUnpacked:!0,isListItem:!0,listContext:{isOrdered:re,itemIndex:be+1}})}return}const L=!!(v!=null&&v.isParentListUnpacked),z=!!(f.children&&f.children.length>=2)||!!S.clicks||!!((G=f.children)!=null&&G.some(re=>{var be;return(be=re.ial)==null?void 0:be[Re]}))||L||!f.markdown&&!!(f.children&&f.children.length>0);if(Mi(f)&&f.children&&f.children.length>0&&(E||L||S.clicks||f.children.some(re=>{var be;return(be=re.ial)==null?void 0:be[Re]}))&&z){const re=!!(f.children&&f.children.length>=2),be=f.children.find(g=>!!(g.markdown||g.content||"").trim())||f.children[0],ke=((K=be==null?void 0:be.ial)==null?void 0:K[Re])||((ce=be==null?void 0:be.ial)==null?void 0:ce["custom-slides-click"]),le=!!(!S.clicks&&re&&ke),J=S.clicks||(le?ke:void 0)||(v==null?void 0:v.parentClicks),he=f.id||(v==null?void 0:v.parentContainerId),D=S.slot||(v==null?void 0:v.defaultSlot);let W=!0;for(const g of f.children){D&&(!g.ial||!g.ial[Me])&&(g.ial||(g.ial={}),g.ial[Me]=D);const V=!!(g.markdown||g.content||"").trim(),j=W&&V;if(j){if(!(r.frontmatter.layout==="image-right"||r.frontmatter.layout==="image-left")&&!!(r.frontmatter.layout==="clover"||sn(r.frontmatter.layout)||r.frontmatter.layout==="two-cols"||v!=null&&v.defaultSlot))g.markdown&&(g.markdown=Dn(g.markdown)),g.content&&(g.content=Dn(g.content));else{const Y=!!((ie=v==null?void 0:v.listContext)!=null&&ie.isOrdered),A=((oe=v==null?void 0:v.listContext)==null?void 0:oe.itemIndex)||1,R=Y?`${A}. `:"- ",Z=te=>{if(!te)return R.trim();const ne=te.trim();return/^[-*+]\s+/.test(ne)||/^\d+\.\s+/.test(ne)?te:`${R}${te}`};g.markdown&&(g.markdown=Z(g.markdown)),g.content&&(g.content=Z(g.content))}W=!1}let I=g;j&&J&&re?(I={...g,ial:{...g.ial||{}}},delete I.ial[Re],delete I.ial["custom-slides-click"]):!re&&J&&(I={...g,ial:{...g.ial||{},[Re]:J}}),h(I,{...v,parentClicks:J,parentContainerId:he,defaultSlot:D,isListItem:!0})}return}if(S.isNote){const re=dr(m);re&&(r.notes?r.notes+=`

`+re:r.notes=re),r.noteBlocks||(r.noteBlocks=[]),r.noteBlocks.push({id:f.id,type:f.type,content:re||f.content||"",rawMarkdown:m,isNote:!0,attributes:f.ial});return}S.shikiLines&&(m=tp(m,S.shikiLines)),x=m.trim();const H=(f.content||"").trim();if(x==="::right::"||H==="::right::"||/^<p>\s*::right::\s*<\/p>$/i.test(x)||x.startsWith("::right::")){r.blocks.push({id:f.id,type:f.type,content:"::right::",rawMarkdown:"::right::",slot:"slot-divider-right",attributes:f.ial});return}const _=np(f);let N=S.slot,k=S.clicks,U=S.motion,F={...f.ial||{}};if(_!==null){for(;l.length>0&&l[l.length-1].level>=_;)l.pop();const re=l.length>0?l[l.length-1]:void 0;!N&&(re!=null&&re.slot)&&(N=re.slot),!k&&(re!=null&&re.clicks)&&!(v!=null&&v.parentContainerId)&&(k=re.clicks),!U&&(re!=null&&re.motion)&&(U=re.motion);const be={...(re==null?void 0:re.customAttrs)||{}};if(f.ial)for(const[ke,le]of Object.entries(f.ial))ke.startsWith("custom-slides-")&&!ke.startsWith("custom-slides-slide")&&(be[ke]=le);v!=null&&v.parentContainerId||l.push({level:_,slot:N,clicks:k,motion:U,customAttrs:be})}else{const re=l.length>0?l[l.length-1]:void 0;re&&(!N&&re.slot&&re.slot!=="header"&&(N=re.slot),!k&&re.clicks&&!(v!=null&&v.parentContainerId)&&(k=re.clicks),!U&&re.motion&&(U=re.motion),re.customAttrs&&(F={...re.customAttrs,...F}))}!N&&r.blocks.some(re=>re.slot==="slot-divider-right")&&(N="right"),!N&&(v!=null&&v.defaultSlot)&&(N=v.defaultSlot),N&&(F[Me]=N),k&&!F[Re]&&(F[Re]=k),U&&!F[Jt]&&(F[Jt]=JSON.stringify(U)),(w||b["custom-slides-autoplay"]||b["custom-slides-muted"])&&(b["custom-slides-autoplay"]&&(F["custom-slides-autoplay"]=b["custom-slides-autoplay"],b["custom-slides-autoplay"]==="true"&&!b["custom-slides-muted"]&&(F["custom-slides-muted"]="true")),b["custom-slides-loop"]&&(F["custom-slides-loop"]=b["custom-slides-loop"]),b["custom-slides-muted"]&&(F["custom-slides-muted"]=b["custom-slides-muted"]),b["custom-slides-controls"]&&(F["custom-slides-controls"]=b["custom-slides-controls"]));const M=S.maxHeight?/^\d+$/.test(S.maxHeight.trim())?`${S.maxHeight.trim()}px`:S.maxHeight.trim():void 0,B=!!(v!=null&&v.isListItem||Mi(f)),P={id:f.id,type:f.type,content:f.content||"",rawMarkdown:m,clicks:k,parentClicks:v==null?void 0:v.parentClicks,parentContainerId:v==null?void 0:v.parentContainerId,motion:U,shikiLines:S.shikiLines,maxHeight:M,slot:N,attributes:F,attrs:F,rawNode:f,isListItem:B};r.blocks.push(P)};h(d)}for(let d=0;d<o.length;d++){const h=o[d],f=[],v={...h.frontmatter};d===0&&(v.theme=s.theme,v.aspectRatio=s.aspectRatio,v.highlighter=s.highlighter,v.transition=h.frontmatter.transition||s.defaultTransition);const m=ep(v);m&&f.push(m);const b=h.blocks.filter($=>$.slot!=="slot-divider-right"),y=$=>$.filter(E=>!!(E.rawMarkdown||E.content||"").trim()).map(E=>{var C;return ls(E.rawMarkdown,E.clicks,E.motion,(C=E.attributes)==null?void 0:C.style,E.maxHeight)}).join(`

`),x=$=>{const E=$.filter(H=>!!(H.rawMarkdown||H.content||"").trim());if(E.length===0)return;const C=E[0],L=(C.rawMarkdown||C.content||"").trim();(Mi(C)||/^(?:[-*+]|\d+\.)\s+/.test(L))&&(C.rawMarkdown=Dn(C.rawMarkdown||C.content||""),C.content=C.rawMarkdown)},S=$=>{var H,q;if($.length===0)return"";x($);const E=(H=$.find(_=>_.parentClicks))==null?void 0:H.parentClicks;if(!E)return $.filter(_=>!!(_.rawMarkdown||_.content||"").trim()).map(_=>{var N;return ls(_.rawMarkdown,_.clicks,_.motion,(N=_.attributes)==null?void 0:N.style,_.maxHeight)}).join(`

`);const C=[];let L=[];const z=()=>{if(L.length===0)return;const _=L.map(N=>(N.rawMarkdown||N.content||"").trim()).filter(Boolean).join(`

`);_&&C.push(Pl(_,E)),L=[]};for(const _ of $){if(!(_.rawMarkdown||_.content||"").trim())continue;!!(_.clicks&&_.clicks.trim()!=="")?(z(),C.push(ls(_.rawMarkdown,_.clicks,_.motion,(q=_.attributes)==null?void 0:q.style,_.maxHeight))):L.push(_)}return z(),C.join(`

`)},w=h.frontmatter.layout||"default";if(w==="clover"||sn(w)){let $=[];const E=b.filter(_=>_.slot==="header");if(E.length>0)$=E;else if(b.length>0){const _=b.find(N=>N.type==="h"&&(!N.slot||N.slot==="default"));_&&($=[_])}const C=b.filter(_=>!$.includes(_));let L=2;if(w==="clover")L=4;else if(w==="three-cols-header")L=3;else if(w==="two-cols-header")L=2;else{let _=0;for(const N of C){const k=(N.slot||"").match(/^col-(\d+)$/i);k&&(_=Math.max(_,parseInt(k[1],10)))}if(_>=2)L=_;else if(h.frontmatter.layoutRatio){const N=h.frontmatter.layoutRatio.trim();if(N.includes(":")){const k=N.split(":").map(U=>parseFloat(U.trim())).filter(U=>!isNaN(U)&&U>0);k.length>=2&&(L=k.length)}else{const k=N.split(/\s+/).filter(Boolean);k.length>=2&&(L=k.length)}}else C.length===1&&C[0].children&&C[0].children.length>=2&&(L=Math.min(6,C[0].children.length))}const z=Ol(C,L);z.forEach((_,N)=>{const k=`col-${N+1}`;for(const U of _)(!U.slot||U.slot==="default")&&(U.slot=k);x(_)});const H=z.flat();if(C.length===1&&H.length>1){const _=h.blocks.findIndex(N=>N.id===C[0].id);_!==-1&&h.blocks.splice(_,1,...H)}const q=y($);if(q&&f.push(q),w==="two-cols-header"&&L===2){const _=S(z[0]||[]),N=S(z[1]||[]);_&&f.push(`::left::

${_}`),N&&f.push(`::right::

${N}`)}else z.forEach((_,N)=>{const k=S(_);k&&f.push(`::col-${N+1}::

${k}`)})}else if(w==="two-cols"){const $=b.filter(z=>z.slot==="left"),E=b.filter(z=>z.slot==="right");x($),x(E);const C=y($.length>0?$:b.filter(z=>z.slot!=="right")),L=y(E);f.push(C),L&&f.push(`::right::

${L}`)}else for(const $ of b)f.push(ls($.rawMarkdown,$.clicks||$.parentClicks,$.motion,(u=$.attributes)==null?void 0:u.style,$.maxHeight));h.notes&&f.push(`<!--
${h.notes}
-->`),h.rawMarkdown=f.join(`

`).trim()}const c=o.map(d=>d.rawMarkdown).filter(Boolean).join(`

---

`);return{docId:e,config:s,slides:o,fullMarkdown:c}}const Oo=`/* SiYuan Note Built-in Font & Background Styles for Slidev */
:root,
html:not(.dark),
[data-theme="light"],
[data-theme-mode="light"] {
  /* 思源基础卡片与主题色 (浅色模式 daylight) */
  --b3-card-error-color: #790600;
  --b3-card-error-background: #f5d1cf;
  --b3-card-warning-color: #8a4f00;
  --b3-card-warning-background: #ffe8c8;
  --b3-card-info-color: #005599;
  --b3-card-info-background: #d6eaf9;
  --b3-card-success-color: #006b04;
  --b3-card-success-background: #d7eed8;

  --b3-theme-primary: #3575f0;
  --b3-theme-secondary: #ff9200;
  --b3-theme-error: #d23f31;
  --b3-theme-background: #ffffff;
  --b3-theme-on-background: #222222;
  --b3-theme-on-surface: #5f6368;
  --b3-theme-surface-lighter: #e0e0e0;

  /* 13 种内置文字颜色 */
  --b3-font-color1: var(--b3-card-error-color);
  --b3-font-color2: var(--b3-card-warning-color);
  --b3-font-color3: var(--b3-card-info-color);
  --b3-font-color4: var(--b3-card-success-color);
  --b3-font-color5: var(--b3-theme-on-surface);
  --b3-font-color6: var(--b3-theme-primary);
  --b3-font-color7: var(--b3-theme-secondary);
  --b3-font-color8: var(--b3-theme-error);
  --b3-font-color9: #a40074;
  --b3-font-color10: #007080;
  --b3-font-color11: #006e2a;
  --b3-font-color12: #6b5a00;
  --b3-font-color13: var(--b3-theme-background);

  /* 13 种内置背景颜色 */
  --b3-font-background1: var(--b3-card-error-background);
  --b3-font-background2: var(--b3-card-warning-background);
  --b3-font-background3: var(--b3-card-info-background);
  --b3-font-background4: var(--b3-card-success-background);
  --b3-font-background5: #e2e3e4;
  --b3-font-background6: #acd0fc;
  --b3-font-background7: #fddaab;
  --b3-font-background8: #ffb0a9;
  --b3-font-background9: #fdbfff;
  --b3-font-background10: #b1ffff;
  --b3-font-background11: #affad1;
  --b3-font-background12: #fff88f;
  --b3-font-background13: var(--b3-theme-on-background);
}

html.dark,
[data-theme="dark"],
[data-theme-mode="dark"],
.theme-dark,
.dark {
  /* 思源基础卡片与主题色 (深色模式 midnight) */
  --b3-card-error-color: rgb(243, 153, 147);
  --b3-card-error-background: #442724;
  --b3-card-warning-color: rgb(255, 213, 153);
  --b3-card-warning-background: #554636;
  --b3-card-info-color: rgb(166, 213, 250);
  --b3-card-info-background: #28405c;
  --b3-card-success-color: rgb(183, 223, 185);
  --b3-card-success-background: #425347;

  --b3-theme-primary: #3575f0;
  --b3-theme-secondary: #ff9200;
  --b3-theme-error: #d23f31;
  --b3-theme-background: #1e1e1e;
  --b3-theme-on-background: #c8ccd6;
  --b3-theme-on-surface: #8b949e;
  --b3-theme-surface-lighter: #282a2e;

  /* 13 种内置文字颜色 */
  --b3-font-color1: var(--b3-card-error-color);
  --b3-font-color2: var(--b3-card-warning-color);
  --b3-font-color3: var(--b3-card-info-color);
  --b3-font-color4: var(--b3-card-success-color);
  --b3-font-color5: var(--b3-theme-on-surface);
  --b3-font-color6: var(--b3-theme-primary);
  --b3-font-color7: var(--b3-theme-secondary);
  --b3-font-color8: var(--b3-theme-error);
  --b3-font-color9: #f47c9c;
  --b3-font-color10: #4dd0e1;
  --b3-font-color11: #10df54;
  --b3-font-color12: #ecd424;
  --b3-font-color13: var(--b3-theme-background);

  /* 13 种内置背景颜色 */
  --b3-font-background1: var(--b3-card-error-background);
  --b3-font-background2: var(--b3-card-warning-background);
  --b3-font-background3: var(--b3-card-info-background);
  --b3-font-background4: var(--b3-card-success-background);
  --b3-font-background5: #3a3f42;
  --b3-font-background6: #031840;
  --b3-font-background7: #593905;
  --b3-font-background8: #3a0c09;
  --b3-font-background9: #4d1b40;
  --b3-font-background10: #1a5459;
  --b3-font-background11: #305415;
  --b3-font-background12: #4a4712;
  --b3-font-background13: var(--b3-theme-on-background);
}

@media (prefers-color-scheme: dark) {
  :root:not([data-theme="light"]):not([data-theme-mode="light"]):not(.light) {
    --b3-card-error-color: rgb(243, 153, 147);
    --b3-card-error-background: #442724;
    --b3-card-warning-color: rgb(255, 213, 153);
    --b3-card-warning-background: #554636;
    --b3-card-info-color: rgb(166, 213, 250);
    --b3-card-info-background: #28405c;
    --b3-card-success-color: rgb(183, 223, 185);
    --b3-card-success-background: #425347;

    --b3-theme-primary: #3575f0;
    --b3-theme-secondary: #ff9200;
    --b3-theme-error: #d23f31;
    --b3-theme-background: #1e1e1e;
    --b3-theme-on-background: #c8ccd6;
    --b3-theme-on-surface: #8b949e;
    --b3-theme-surface-lighter: #282a2e;

    --b3-font-color1: var(--b3-card-error-color);
    --b3-font-color2: var(--b3-card-warning-color);
    --b3-font-color3: var(--b3-card-info-color);
    --b3-font-color4: var(--b3-card-success-color);
    --b3-font-color5: var(--b3-theme-on-surface);
    --b3-font-color6: var(--b3-theme-primary);
    --b3-font-color7: var(--b3-theme-secondary);
    --b3-font-color8: var(--b3-theme-error);
    --b3-font-color9: #f47c9c;
    --b3-font-color10: #4dd0e1;
    --b3-font-color11: #10df54;
    --b3-font-color12: #ecd424;
    --b3-font-color13: var(--b3-theme-background);

    --b3-font-background1: var(--b3-card-error-background);
    --b3-font-background2: var(--b3-card-warning-background);
    --b3-font-background3: var(--b3-card-info-background);
    --b3-font-background4: var(--b3-card-success-background);
    --b3-font-background5: #3a3f42;
    --b3-font-background6: #031840;
    --b3-font-background7: #593905;
    --b3-font-background8: #3a0c09;
    --b3-font-background9: #4d1b40;
    --b3-font-background10: #1a5459;
    --b3-font-background11: #305415;
    --b3-font-background12: #4a4712;
    --b3-font-background13: var(--b3-theme-on-background);
  }
}

/* 演示块级样式排版增强 (带背景色时赋予呼吸内边距与舒适圆角) */
.slide-styled-block {
  border-radius: 6px;
  padding: 8px 14px;
  box-sizing: border-box;
  margin: 6px 0;
  transition: background-color 0.2s ease, color 0.2s ease;
}

/* 行内带背景色文本的精美圆角与微边距 */
span[style*="background-color"],
span[style*="background:"] {
  border-radius: 3px;
  padding: 1px 5px;
  box-decoration-break: clone;
  -webkit-box-decoration-break: clone;
}
`;function sp(e){var s,o,a,r,l,c,u,d,h,f,v,m;if(!e||typeof e!="object")return"";const t=[],i=[];if(Array.isArray(e.styles))for(const b of e.styles){if(!b||!b.id)continue;const y=`--b3-inline-style-${b.id}`;(s=b.light)!=null&&s.color&&t.push(`  ${y}-color: ${b.light.color};`),(o=b.light)!=null&&o.backgroundColor&&t.push(`  ${y}-background-color: ${b.light.backgroundColor};`),(a=b.dark)!=null&&a.color&&i.push(`  ${y}-color: ${b.dark.color};`),(r=b.dark)!=null&&r.backgroundColor&&i.push(`  ${y}-background-color: ${b.dark.backgroundColor};`)}if(e.builtin&&Array.isArray(e.builtin.colors))for(const b of e.builtin.colors){if(!b||typeof b.index!="number")continue;const y=b.index;(l=b.light)!=null&&l.color&&t.push(`  --b3-font-color${y}: ${b.light.color};`),(c=b.light)!=null&&c.backgroundColor&&t.push(`  --b3-font-background${y}: ${b.light.backgroundColor};`),(u=b.dark)!=null&&u.color&&i.push(`  --b3-font-color${y}: ${b.dark.color};`),(d=b.dark)!=null&&d.backgroundColor&&i.push(`  --b3-font-background${y}: ${b.dark.backgroundColor};`)}if(e.builtin&&Array.isArray(e.builtin.styles))for(const b of e.builtin.styles){if(!b||!b.id)continue;const y=b.id;(h=b.light)!=null&&h.color&&t.push(`  --b3-card-${y}-color: ${b.light.color};`),(f=b.light)!=null&&f.backgroundColor&&t.push(`  --b3-card-${y}-background: ${b.light.backgroundColor};`),(v=b.dark)!=null&&v.color&&i.push(`  --b3-card-${y}-color: ${b.dark.color};`),(m=b.dark)!=null&&m.backgroundColor&&i.push(`  --b3-card-${y}-background: ${b.dark.backgroundColor};`)}if(t.length===0&&i.length===0)return"";const n=[];return t.length>0&&n.push(`:root, html:not(.dark), [data-theme="light"] {
${t.join(`
`)}
}`),i.length>0&&n.push(`html.dark, [data-theme="dark"], .dark {
${i.join(`
`)}
}`),n.join(`

`)}function Pn(e){const t=sp(e);return t?`${Oo}

/* Custom Workspace Inline Styles */
${t}`:Oo}const uo=ya;function op(e){const t=String((e==null?void 0:e.type)||"").toLowerCase();return t==="s"||t==="sb"||t==="nodesuperblock"||t==="l"||t==="nodelist"||t==="i"||t==="nodelistitem"||t==="b"||t==="nodeblockquote"}function rp(e,t){const i=new Map,n=[];if(!Array.isArray(t)||t.length===0)return{usable:!1,reason:"索引无行",leafPatch:i,rebuildRoots:n};const s=new Map;for(const o of t)o!=null&&o.id&&s.set(o.id,o);for(const o of e||[]){if(!(o!=null&&o.id))continue;const a=s.get(o.id);if(!a)continue;const r=o.content??"",l=o.markdown??"";(a.content??"")===r&&(a.markdown??"")===l||(op(a)?n.push(o.id):i.set(o.id,{content:r,markdown:l}))}return{usable:!0,reason:"",leafPatch:i,rebuildRoots:n}}function ap(e){const t=String((e==null?void 0:e.type)||"").toLowerCase();return t==="h"||t==="nodeheading"}function Ro(e){return at(e)||e.type==="l"||e.type==="NodeList"||e.type==="i"||e.type==="NodeListItem"||e.type==="b"||e.type==="NodeBlockquote"}function lp(e,t,i,n=8,s){const o=new Map;for(const h of t)h!=null&&h.id&&o.set(h.id,h);const a=h=>({id:h.id,parent_id:h.parent_id,root_id:h.root_id||e,type:h.type,subType:h.subtype??h.subType??"",content:h.content||"",markdown:h.markdown||"",ial:i(h.id,h.ial),children:[]}),r=h=>{let f=h.parent_id,v=0;for(;f&&f!==e&&v++<16;){const m=o.get(f);if(!m||!ap(m))return f;f=m.parent_id}return f||e},l=new Map;for(const h of t){if(!(h!=null&&h.id)||h.id===e||s&&s.size>0&&!s.has(h.id))continue;const f=r(h),v=l.get(f);v?v.push(h):l.set(f,[h])}if(s&&s.size>0)for(const h of l.values())h.sort((f,v)=>(s.get(f.id)??Number.MAX_SAFE_INTEGER)-(s.get(v.id)??Number.MAX_SAFE_INTEGER));const c=new Map,u=(h,f)=>{const v=a(h);if(c.set(v.id,v),f>=n||!Ro(v))return v;const m=l.get(v.id);return m&&m.length>0&&(v.children=m.map(b=>u(b,f+1))),v};return{topLevel:(l.get(e)||[]).map(h=>u(h,0)),byId:c}}const cp={getBlockAttrs:jo,getChildBlocks:Yn,getDocBlocksOrders:cd,setBlockAttrs:ze,sql:dn,getBaseUrl:()=>typeof location<"u"?location.origin:"",getInlineStyles:dd};class dp{constructor(t){ye(this,"deps");ye(this,"attrOverrides",new Map);ye(this,"trackedListSuperBlocks",new Map);ye(this,"fallbackWarnedDocId","");this.deps={...cp,...t||{}}}setBlockAttrOverride(t,i){if(!t||!i)return;const s={...this.attrOverrides.get(t)||{}};for(const[o,a]of Object.entries(i))a===""||a===null||a===void 0?delete s[o]:s[o]=String(a);Object.keys(s).length===0?this.attrOverrides.delete(t):this.attrOverrides.set(t,s)}getBlockAttrOverride(t){return this.attrOverrides.get(t)}getAllAttrOverrides(){return new Map(this.attrOverrides)}getTrackedListSuperBlocks(t){return this.trackedListSuperBlocks.get(t)||[]}clearBlockAttrOverride(t,i){if(!t)return;if(!i){this.attrOverrides.delete(t);return}const n=this.attrOverrides.get(t);n&&(delete n[i],Object.keys(n).length===0&&this.attrOverrides.delete(t))}clearAllOverrides(){this.attrOverrides.clear(),this.trackedListSuperBlocks.clear()}async compile(t){try{const i=await this.deps.getBlockAttrs(t).catch(()=>({}))||{},n=this.attrOverrides.get(t);n&&Object.assign(i,n);const s=await this.deps.getChildBlocks(t).catch(()=>[])||[],o=this.deps.getDocBlocksOrders?await this.deps.getDocBlocksOrders(t).catch(()=>[])||[]:[],a=new Map;for(let F=0;F<o.length;F++)o[F]&&a.set(o[F],F);const r=a.size>0,l=`SELECT id, parent_id, root_id, type, subtype, content, markdown, ial, sort, created FROM blocks WHERE root_id = '${t}' AND id != '${t}' ORDER BY sort ASC, created ASC LIMIT 99999`,c=await this.deps.sql(l).catch(()=>[])||[],u=rp(s,c),d=new Map;if(Array.isArray(c))for(const F of c)F.id&&F.ial&&d.set(F.id,uo(F.ial));const h=`SELECT block_id, name, value FROM attributes WHERE root_id = '${t}' AND type = 'b' LIMIT 99999`,f=await this.deps.sql(h).catch(()=>[])||[];if(Array.isArray(f)){for(const F of f)if(F.block_id&&F.name){let M=d.get(F.block_id);M||(M={},d.set(F.block_id,M)),M[F.name]=F.value||""}}const v=(F,M)=>{const B={...d.get(F)||(M?uo(M):{})},P=this.attrOverrides.get(F);return P&&Object.assign(B,P),B},m=Array.isArray(c)&&c.length>0?lp(t,c,v,8,a):null,b=s.map(F=>F.id).filter(Boolean),y=F=>({id:F.id,parent_id:F.parent_id,root_id:F.root_id||t,type:F.type,subType:F.subType,content:F.content||"",markdown:F.markdown||"",ial:v(F.id,F.ial),children:F.children}),x=async(F,M=0)=>{if(!F||M>8||!Ro(F))return;const B=await this.deps.getChildBlocks(F.id).catch(()=>[])||[];if(!(!Array.isArray(B)||B.length===0)){F.children=B.filter(P=>P==null?void 0:P.id).map(P=>({id:P.id,parent_id:F.id,root_id:t,type:P.type,subType:P.subType,content:P.content||"",markdown:P.markdown||"",ial:v(P.id,P.ial),children:[]}));for(const P of F.children)await x(P,M+1)}},S=new Map;for(const F of c)F!=null&&F.id&&S.set(F.id,F);const w=b.every(F=>{const M=S.get(F);return!M||!!M.type});let $=[],E=!1;if(m&&u.usable&&r&&w){this.fallbackWarnedDocId="";for(const[M,B]of u.leafPatch){const P=m.byId.get(M);P&&(P.content=B.content,P.markdown=B.markdown)}const F=new Map;for(const M of s)M!=null&&M.id&&F.set(M.id,M);for(const M of u.rebuildRoots){const B=m.byId.get(M),P=F.get(M);B&&P&&(B.content=P.content||"",B.markdown=P.markdown||""),await x(B)}for(const M of s){if(!(M!=null&&M.id)||m.byId.has(M.id))continue;const B=y(M);await x(B),m.byId.set(B.id,B),m.topLevel.push(B)}$=m.topLevel.filter(M=>a.has(M.id)).sort((M,B)=>(a.get(M.id)??0)-(a.get(B.id)??0))}else b.length>0?(E=!0,this.fallbackWarnedDocId!==t&&(this.fallbackWarnedDocId=t,console.warn(`[DocumentCompiler] 索引结构不可用，回退逐容器查询（较慢）doc=${t} 实时顶层=${b.length} 索引行=${c.length} 文档序=${o.length} 原因=${u.reason||"缺少实时文档序"}`)),$=s.map(F=>y(F))):m&&($=m.topLevel);const C=async(F,M=0)=>{if(!(!F||F.length===0||M>8))for(const B of F){if(Ro(B)&&(!B.children||B.children.length===0)){let se=await this.deps.getChildBlocks(B.id).catch(()=>[]);if(!se||se.length===0){const G=`SELECT id, parent_id, root_id, type, subtype as subType, content, markdown, ial FROM blocks WHERE parent_id = '${B.id}' ORDER BY sort ASC, created ASC`;se=await this.deps.sql(G).catch(()=>[])||[]}if(Array.isArray(se)&&se.length>0){const G=new Set($.map(ce=>ce.id)),K=se.filter(ce=>ce.id!==B.id&&!G.has(ce.id));K.length>0&&(B.children=K.map(ce=>{const ie=d.get(ce.id)||(ce.ial?uo(ce.ial):{}),oe=this.attrOverrides.get(ce.id);return oe&&Object.assign(ie,oe),{id:ce.id,parent_id:ce.parent_id||B.id,root_id:ce.root_id||t,type:ce.type,subType:ce.subType,content:ce.content||"",markdown:ce.markdown||"",ial:ie}}))}}B.children&&B.children.length>0&&await C(B.children,M+1)}};E&&await C($);const L=F=>{var M,B;for(const P of F)if(P.children&&P.children.length>0){L(P.children);for(const se of P.children)if(se.ial)for(const[G,K]of Object.entries(se.ial))G.startsWith("custom-slides-")&&!((M=P.ial)!=null&&M[G])&&(P.ial||(P.ial={}),P.ial[G]=K);if(P.ial){for(const[se,G]of Object.entries(P.ial))if(se.startsWith("custom-slides-"))for(const K of P.children)(K.type==="video"||K.type==="NodeVideo"||/<video\b/i.test(K.markdown||K.content||""))&&!((B=K.ial)!=null&&B[se])&&(K.ial||(K.ial={}),K.ial[se]=G)}}};L($),Jf($,F=>{const M={[Se]:F.layout};this.setBlockAttrOverride(F.blockId,M),(this.deps.setBlockAttrs||ze)(F.blockId,M).catch(P=>{console.warn("[DocumentCompiler] Failed to auto-tag superblock image layout:",P)})});const z=this.trackedListSuperBlocks.get(t)||[],H=Zf(t,$,{tracked:z,onTagChange:F=>{this.setBlockAttrOverride(F.blockId,F.attrs),F.blockId===t&&Object.assign(i,F.attrs);const M=P=>{for(const se of P)se.id===F.blockId&&(se.ial||(se.ial={}),Object.assign(se.ial,F.attrs)),se.children&&se.children.length>0&&M(se.children)};M($),(this.deps.setBlockAttrs||ze)(F.blockId,F.attrs).catch(P=>{console.warn("[DocumentCompiler] Failed to auto-tag list superblock attrs:",P)})}});this.trackedListSuperBlocks.set(t,H.newTracked);const q=new Set,_=F=>{for(const M of F){const B=M.markdown||M.content||"";if(B.includes("((")){const P=fd(B);for(const se of P)q.add(se.blockId)}M.children&&M.children.length>0&&_(M.children)}};_($);const N={};if(q.size>0){const F=Array.from(q).map(B=>`'${B}'`).join(","),M=await this.deps.sql(`SELECT id, content, markdown FROM blocks WHERE id IN (${F})`).catch(()=>[])||[];if(Array.isArray(M))for(const B of M)B.id&&(N[B.id]=B.markdown||B.content||"")}const k=this.deps.getBaseUrl?this.deps.getBaseUrl():"",U=na(t,i,$,{baseUrl:k,refContentMap:N});try{const F=this.deps.getInlineStyles?await this.deps.getInlineStyles().catch(()=>null):null;U.customThemeCss=Pn(F)}catch{U.customThemeCss=Pn(null)}return U}catch(i){console.error("[DocumentCompilerService] Failed to compile document:",i);const n=na(t,{},[],{});return n.customThemeCss=Pn(null),n}}}const De=new dp;class ur{constructor(t){ye(this,"devServerUrl","http://localhost:3030");ye(this,"isConnected",!1);ye(this,"lastSyncTime",null);t&&(this.devServerUrl=t)}getUrl(){return this.devServerUrl}setUrl(t){this.devServerUrl=t.replace(/\/+$/,"")}isServerConnected(){return this.isConnected}getLastSyncTime(){return this.lastSyncTime}async probeServer(t=1500){try{const i=new AbortController,n=setTimeout(()=>i.abort(),t),s=await fetch(this.devServerUrl,{method:"HEAD",mode:"no-cors",signal:i.signal}).catch(()=>null);return clearTimeout(n),this.isConnected=!!s,this.isConnected}catch{return this.isConnected=!1,!1}}buildStandardSlidevMarkdown(t){const i=t.config,n=["---",`theme: ${i.theme||"default"}`,`aspectRatio: "${i.aspectRatio||"16/9"}"`,`highlighter: ${i.highlighter||"shiki"}`,`transition: ${i.defaultTransition||"slide-left"}`];i.colorSchema&&i.colorSchema!=="auto"&&n.push(`colorSchema: ${i.colorSchema}`),n.push("drawings:","  persist: false","---","");const s=n.join(`
`),o=t.slides.map((l,c)=>{const u=l.frontmatter||{},d=[],h=c===0;u.layout&&u.layout!=="default"&&d.push(`layout: ${u.layout}`),u.transition&&d.push(`transition: ${u.transition}`),u.background&&d.push(`background: ${u.background}`),u.class&&d.push(`class: "${u.class}"`);let f="";d.length>0?f=h?"":`---
${d.join(`
`)}
---

`:h||(f=`---

`);let v="";if(u.layout==="two-cols"){const b=l.blocks.filter(w=>w.slot!=="right"),y=l.blocks.filter(w=>w.slot==="right"),x=b.map(w=>w.rawMarkdown||w.content||"").join(`

`),S=y.map(w=>w.rawMarkdown||w.content||"").join(`

`);v=`${x}

::right::

${S}`}else v=l.blocks.map(b=>b.rawMarkdown||b.content||"").join(`

`);let m="";return l.notes&&l.notes.trim()&&(m=`

<!--
${l.notes.trim()}
-->`),`${f}${v}${m}`}).join(`

`),a=[];t.config.normalizeHeadingSizes&&a.push(`/* Specific Heading Normalization */
.slidev-layout:not(.cover) > :is(h1, h2, h3, h4, h5, h6):first-child {
  font-size: 1.7rem !important;
}
.two-cols-header-top :is(h1, h2, h3, h4, h5, h6),
.cols-header-top :is(h1, h2, h3, h4, h5, h6),
.layout-header-section :is(h1, h2, h3, h4, h5, h6) {
  font-size: 1.7rem !important;
}
:is(.two-cols-left, .two-cols-right, .col, .col-1, .col-2, .col-3, .three-cols-col) > :is(h1, h2, h3, h4, h5, h6):first-child {
  font-size: 1.3rem !important;
}`),t.config.showUnorderedListMarkers===!1&&a.push(`/* Hide Unordered List Bullets */
ul, .slidev-layout ul, .slidev-layout li:has(ul) {
  list-style: none !important;
  list-style-type: none !important;
  padding-left: 0 !important;
}`),t.config.showOrderedListMarkers===!1&&a.push(`/* Hide Ordered List Numbers */
ol, .slidev-layout ol, .slidev-layout li:has(ol) {
  list-style: none !important;
  list-style-type: none !important;
  padding-left: 0 !important;
}`);let r="";return a.length>0&&(r=`

<style>
${a.join(`

`)}
</style>`),`${s}${o}${r}
`}async syncToWorkspaceFile(t,i="/data/storage/petal/siyuan-live-slides/slides.md",n){const s=this.buildStandardSlidevMarkdown(t);if(this.lastSyncTime=Date.now(),n)try{const o=typeof Blob<"u"?new Blob([s],{type:"text/markdown;charset=utf-8"}):Buffer.from(s,"utf-8");return await n(i,!1,o),{success:!0,path:i}}catch(o){return{success:!1,path:i,error:String(o)}}return{success:!0,path:i}}downloadSlidesMd(t,i="slides.md"){if(typeof window>"u"||typeof document>"u")return!1;const n=this.buildStandardSlidevMarkdown(t),s=new Blob([n],{type:"text/markdown;charset=utf-8"}),o=URL.createObjectURL(s),a=document.createElement("a");return a.href=o,a.download=i,document.body.appendChild(a),a.click(),document.body.removeChild(a),URL.revokeObjectURL(o),!0}}const up={proMode:!1,presenterMode:!0,exportHtml:!1,exportPdf:!1,exportImage:!0,import:!1,aiScript:!0};function ri(e){return up[e]===!1}function $t(e){return!ri(e)}function fp(){if(typeof window<"u"&&typeof window.require=="function")return window.require.bind(window);if(typeof globalThis<"u"&&typeof globalThis.require=="function")return globalThis.require.bind(globalThis);if(typeof require=="function")return require}function Mt(e){const t=fp();if(t)try{return t(e)}catch{try{const i=e.startsWith("node:")?e.slice(5):`node:${e}`;return t(i)}catch{}}}function fr(){var t;if(typeof window<"u"&&window.process)return window.process;const e=Mt("process");return e&&e.versions?e:typeof process<"u"&&((t=process.versions)!=null&&t.node)?process:globalThis.process}function Rl(){var t,i;const e=fr();if(e&&((t=e.versions)!=null&&t.node))return!0;if(typeof window<"u"&&window.siyuan){const n=Mt("child_process");if(n&&typeof n.spawn=="function")return!0}return!!(typeof process<"u"&&((i=process.versions)!=null&&i.node))}function pp(){if(typeof window>"u"||!window.location)return!1;try{return new URLSearchParams(window.location.search).get("remote")==="1"}catch{return!1}}function qn(){const e=fr();if(e!=null&&e.platform)return e.platform;if(typeof process<"u"&&process.platform)return process.platform;const t=Mt("os");if(t&&typeof t.platform=="function")return t.platform();if(typeof navigator<"u"){const i=navigator.userAgent.toLowerCase();if(i.includes("win"))return"win32";if(i.includes("mac"))return"darwin";if(i.includes("linux"))return"linux"}return"web"}function Nl(){var n,s;const e=fr(),t={...(e==null?void 0:e.env)||{}};if(qn()==="win32"){const o=["C:\\Program Files\\nodejs","C:\\Program Files (x86)\\nodejs",(n=e==null?void 0:e.env)!=null&&n.APPDATA?`${e.env.APPDATA}\\npm`:"",(s=e==null?void 0:e.env)!=null&&s.USERPROFILE?`${e.env.USERPROFILE}\\AppData\\Roaming\\npm`:""].filter(Boolean),a=Object.keys(t).find(c=>c.toLowerCase()==="path")||"PATH",l=(t[a]||"").split(";").filter(Boolean);for(const c of o)c&&!l.some(u=>u.toLowerCase()===c.toLowerCase())&&l.push(c);t[a]=l.join(";")}return t}function No(e){var i,n,s;if(!e)return"";if(/^[a-zA-Z]:[/\\]/.test(e))return e.replace(/\\/g,"/");let t="";if(typeof window<"u"&&((s=(n=(i=window.siyuan)==null?void 0:i.config)==null?void 0:n.system)!=null&&s.dataDir)&&(t=window.siyuan.config.system.dataDir.replace(/\\/g,"/")),t&&e.startsWith("/data/")){const o=e.slice(6);return`${t}/${o}`.replace(/\\/g,"/")}return e}function hp(){const e=Mt("os"),t=Mt("path");if(e&&typeof e.tmpdir=="function"){const i=e.tmpdir();return t&&typeof t.join=="function"?t.join(i,"siyuan-live-slides-pro").replace(/\\/g,"/"):`${i}/siyuan-live-slides-pro`.replace(/\\/g,"/")}return"/data/storage/petal/siyuan-live-slides/pro-workspace"}class pr{constructor(t){ye(this,"runner");this.runner=t||pr.defaultRunner}static async defaultRunner(t,i){var n;try{let s=(n=Mt("child_process"))==null?void 0:n.execFile;if(!s){const l=await import("node:child_process").catch(()=>({}));s=l==null?void 0:l.execFile}if(!s)return{code:-1,stdout:"",stderr:"child_process execFile not available"};const a=qn()==="win32",r=Nl();return await new Promise(l=>{s(t,i,{timeout:5e3,shell:a,env:r},(c,u,d)=>{l({code:c?c.code||1:0,stdout:u?String(u).trim():"",stderr:d?String(d).trim():""})})})}catch(s){return{code:-1,stdout:"",stderr:String(s)}}}async detect(){const t=Rl(),i=qn();if(!t)return{hasNode:!1,hasSlidevCli:!1,platform:"browser",isDesktop:!1,error:"当前处于纯前端浏览器或移动端环境，无 Node.js 运行时支撑"};let n=!1,s,o=!1,a;try{const r=await this.runner("node",["-v"]);r.code===0&&r.stdout.startsWith("v")&&(n=!0,s=r.stdout)}catch{}if(n){try{const r=i==="win32"?"slidev.cmd":"slidev",l=await this.runner(r,["--version"]);l.code===0&&l.stdout&&(o=!0,a=l.stdout)}catch{}if(!o)try{const r=i==="win32"?"npx.cmd":"npx",l=await this.runner(r,["@slidev/cli","--version"]);l.code===0&&l.stdout&&(o=!0,a=l.stdout)}catch{}}return{hasNode:n,nodeVersion:s,hasSlidevCli:o,slidevVersion:a,platform:i,isDesktop:t}}}class mp{constructor(){ye(this,"iframe",null);ye(this,"isReady",!1);ye(this,"pageChangedHandlers",[]);ye(this,"readyHandlers",[]);ye(this,"currentState",{no:1,clicks:0,total:1});this.handleWindowMessage=this.handleWindowMessage.bind(this)}getCurrentState(){return{...this.currentState}}attach(t){this.detach(),this.iframe=t,this.isReady=!1,typeof window<"u"&&window.addEventListener("message",this.handleWindowMessage)}detach(){typeof window<"u"&&window.removeEventListener("message",this.handleWindowMessage),this.iframe=null,this.isReady=!1}postMessage(t,i){var s;if(!((s=this.iframe)!=null&&s.contentWindow))return;const n={target:"slidev",sender:"siyuan",type:t,...i};try{this.iframe.contentWindow.postMessage(n,"*")}catch(o){console.warn("[NativeSlidesBridge] postMessage error:",o)}}navigateToPage(t){this.postMessage("navigate",{no:t})}next(){this.postMessage("next")}prev(){this.postMessage("prev")}nextClick(){this.postMessage("next-click")}prevClick(){this.postMessage("prev-click")}onPageChanged(t){return this.pageChangedHandlers.push(t),()=>{this.pageChangedHandlers=this.pageChangedHandlers.filter(i=>i!==t)}}onReady(t){return this.readyHandlers.push(t),()=>{this.readyHandlers=this.readyHandlers.filter(i=>i!==t)}}handleWindowMessage(t){const i=t.data;if(!(!i||i.target!=="slidev")){if(!this.isReady){this.isReady=!0;for(const n of this.readyHandlers)n()}if(i.type==="update-state"&&i.navState){const n=i.navState;this.currentState={no:n.no??this.currentState.no,clicks:n.clicks??this.currentState.clicks,total:n.total??this.currentState.total,hasNext:n.hasNext,hasPrev:n.hasPrev};for(const s of this.pageChangedHandlers)s(this.currentState.no,this.currentState.total||1,this.currentState)}else if(i.type==="navigate"&&typeof i.no=="number"){this.currentState.no=i.no;for(const n of this.pageChangedHandlers)n(i.no,this.currentState.total||1,this.currentState)}}}}class gp{constructor(t){ye(this,"childProcess",null);ye(this,"activePort",null);ye(this,"isRunning",!1);ye(this,"defaultPort");ye(this,"maxPortRetries");ye(this,"probeTimeoutMs");ye(this,"customSpawner");ye(this,"customPortChecker");this.defaultPort=(t==null?void 0:t.defaultPort)||3030,this.maxPortRetries=(t==null?void 0:t.maxPortRetries)||20,this.probeTimeoutMs=(t==null?void 0:t.probeTimeoutMs)||1e4,this.customSpawner=t==null?void 0:t.customSpawner,this.customPortChecker=t==null?void 0:t.customPortChecker}getActivePort(){return this.activePort}getIsRunning(){return this.isRunning}async isPortAvailable(t){if(this.customPortChecker)return this.customPortChecker(t);try{let i=Mt("net");return i||(i=await import("node:net").catch(()=>({}))),i!=null&&i.createServer?await new Promise(n=>{const s=i.createServer();s.once("error",()=>n(!1)),s.once("listening",()=>{s.close(()=>n(!0))}),s.listen(t,"127.0.0.1")}):!0}catch{return!0}}async allocPort(t){const i=t||this.defaultPort;for(let n=0;n<this.maxPortRetries;n++){const s=i+n;if(await this.isPortAvailable(s))return s}return i}async pollServerReady(t,i=8e3,n=300){const s=Date.now();for(;Date.now()-s<i;){try{const o=new AbortController,a=setTimeout(()=>o.abort(),n),r=await fetch(t,{method:"HEAD",mode:"no-cors",signal:o.signal}).catch(()=>null);if(clearTimeout(a),r)return!0}catch{}await new Promise(o=>setTimeout(o,n))}return!1}async startServer(t,i){var l,c;if(this.isRunning&&this.activePort)return{success:!0,port:this.activePort,url:`http://localhost:${this.activePort}?embedded=true`};const n=await this.allocPort(i);this.activePort=n;const o=qn()==="win32"?"npx.cmd":"npx",a=No(t),r=["@slidev/cli",a,"--port",String(n),"--no-open"];try{if(this.customSpawner)this.childProcess=this.customSpawner(o,r,{detached:!1});else{let d=(l=Mt("child_process"))==null?void 0:l.spawn;if(!d){const v=await import("node:child_process").catch(()=>({}));d=v==null?void 0:v.spawn}if(!d)throw new Error("child_process spawn not available in current runtime");const h=a.includes("/")||a.includes("\\")?a.replace(/[/\\][^/\\]+$/,""):void 0,f=Nl();this.childProcess=d(o,r,{cwd:h,detached:!1,shell:!0,env:{...f,FORCE_COLOR:"1"}})}this.isRunning=!0,(c=this.childProcess)!=null&&c.on&&this.childProcess.on("exit",()=>{this.isRunning=!1,this.activePort=null,this.childProcess=null});const u=`http://localhost:${n}`;return!this.customSpawner&&!await this.pollServerReady(u,this.probeTimeoutMs)?(this.stopServer(),{success:!1,port:n,url:"",error:`Slidev DevServer 启动超时 (未在 ${this.probeTimeoutMs}ms 内响应端口 ${n})`}):{success:!0,port:n,url:`${u}?embedded=true`}}catch(u){return this.stopServer(),{success:!1,port:n,url:"",error:`唤起 Slidev 进程失败: ${String(u)}`}}}async stopServer(){var t;if(this.childProcess){const i=this.childProcess;this.childProcess=null;try{if(i.kill("SIGTERM"),qn()==="win32"&&i.pid&&!this.customSpawner){const s=(t=Mt("child_process"))==null?void 0:t.exec;if(s)await new Promise(o=>{const a=setTimeout(o,400);s(`taskkill /pid ${i.pid} /T /F`,()=>{clearTimeout(a),o()})});else{const o=await import("node:child_process").catch(()=>null);o!=null&&o.exec&&await new Promise(a=>{const r=setTimeout(a,400);o.exec(`taskkill /pid ${i.pid} /T /F`,()=>{clearTimeout(r),a()})})}}}catch{}}this.isRunning=!1,this.activePort=null}}class Qn{constructor(){ye(this,"iframe",null);ye(this,"isReady",!1);ye(this,"pendingMessages",[]);ye(this,"slideChangedHandlers",[]);ye(this,"blockClickedHandlers",[]);ye(this,"openInEditorHandlers",[]);ye(this,"clientReadyHandlers",[]);ye(this,"openPeekDrawerHandlers",[]);ye(this,"toggleFullscreenHandlers",[]);ye(this,"openPresenterHandlers",[]);ye(this,"captureProgressHandlers",[]);ye(this,"capturePageDoneHandlers",[]);ye(this,"captureCompleteHandlers",[]);ye(this,"captureErrorHandlers",[]);this.handleWindowMessage=this.handleWindowMessage.bind(this)}attach(t){this.detach(),this.iframe=t,this.isReady=!1,typeof window<"u"&&window.addEventListener("message",this.handleWindowMessage)}detach(){typeof window<"u"&&window.removeEventListener("message",this.handleWindowMessage),this.iframe=null,this.isReady=!1,this.pendingMessages=[]}resetReady(){this.isReady=!1}postMessage(t,i){var s;const n={source:"siyuan-slides-host",action:t,payload:i};if(!((s=this.iframe)!=null&&s.contentWindow)||!this.isReady){if(t==="UPDATE_SLIDES"||t==="NAVIGATE_PAGE"){const o=this.pendingMessages.findIndex(a=>a.action===t);o!==-1?this.pendingMessages[o]=n:this.pendingMessages.push(n)}else this.pendingMessages.length>=50&&this.pendingMessages.shift(),this.pendingMessages.push(n);return}try{this.iframe.contentWindow.postMessage(n,"*")}catch(o){console.warn("[WebSandboxBridge] postMessage error:",o)}}updateSlides(t,i,n,s){this.postMessage("UPDATE_SLIDES",{slides:t,config:i,fullMarkdown:n,customThemeCss:s})}navigatePage(t,i){const n={pageIndex:t};typeof i=="number"&&(n.step=i),this.postMessage("NAVIGATE_PAGE",n)}highlightElement(t){this.postMessage("HIGHLIGHT_ELEMENT",{targetBlockId:t})}nextStep(){this.postMessage("NEXT_STEP",{})}prevStep(){this.postMessage("PREV_STEP",{})}freezeKeyboardNav(t){this.postMessage("FREEZE_KEYBOARD_NAV",{frozen:t})}toggleOverview(){this.postMessage("TOGGLE_OVERVIEW",{})}startImageExport(t){this.postMessage("START_IMAGE_EXPORT",{captureOptions:t})}cancelImageExport(){this.postMessage("CANCEL_IMAGE_EXPORT",{})}onCaptureProgress(t){return this.captureProgressHandlers.push(t),()=>{this.captureProgressHandlers=this.captureProgressHandlers.filter(i=>i!==t)}}onCapturePageDone(t){return this.capturePageDoneHandlers.push(t),()=>{this.capturePageDoneHandlers=this.capturePageDoneHandlers.filter(i=>i!==t)}}onCaptureComplete(t){return this.captureCompleteHandlers.push(t),()=>{this.captureCompleteHandlers=this.captureCompleteHandlers.filter(i=>i!==t)}}onCaptureError(t){return this.captureErrorHandlers.push(t),()=>{this.captureErrorHandlers=this.captureErrorHandlers.filter(i=>i!==t)}}onSlideChanged(t){return this.slideChangedHandlers.push(t),()=>{this.slideChangedHandlers=this.slideChangedHandlers.filter(i=>i!==t)}}onBlockClicked(t){return this.blockClickedHandlers.push(t),()=>{this.blockClickedHandlers=this.blockClickedHandlers.filter(i=>i!==t)}}onOpenInEditor(t){return this.openInEditorHandlers.push(t),()=>{this.openInEditorHandlers=this.openInEditorHandlers.filter(i=>i!==t)}}onOpenPeekDrawer(t){return this.openPeekDrawerHandlers.push(t),()=>{this.openPeekDrawerHandlers=this.openPeekDrawerHandlers.filter(i=>i!==t)}}onRequestToggleFullscreen(t){return this.toggleFullscreenHandlers.push(t),()=>{this.toggleFullscreenHandlers=this.toggleFullscreenHandlers.filter(i=>i!==t)}}onOpenPresenter(t){return this.openPresenterHandlers.push(t),()=>{this.openPresenterHandlers=this.openPresenterHandlers.filter(i=>i!==t)}}onClientReady(t){return this.clientReadyHandlers.push(t),()=>{this.clientReadyHandlers=this.clientReadyHandlers.filter(i=>i!==t)}}handleWindowMessage(t){var n,s;const i=t.data;if(!(!i||i.source!=="siyuan-slides-client")&&!((n=this.iframe)!=null&&n.contentWindow&&t.source&&t.source!==this.iframe.contentWindow))switch(i.action){case"CLIENT_READY":for(this.isReady=!0;this.pendingMessages.length>0;){const o=this.pendingMessages.shift();o&&((s=this.iframe)!=null&&s.contentWindow)&&this.iframe.contentWindow.postMessage(o,"*")}for(const o of this.clientReadyHandlers)o();break;case"SLIDE_CHANGED":if(i.payload.currentPage!==void 0)for(const o of this.slideChangedHandlers)i.payload.currentStep!==void 0||i.payload.maxStep!==void 0?o(i.payload.currentPage,i.payload.totalPages||1,i.payload.currentBlockId||"",i.payload.currentStep,i.payload.maxStep):o(i.payload.currentPage,i.payload.totalPages||1,i.payload.currentBlockId||"");break;case"BLOCK_CLICKED":if(i.payload.clickedBlockId)for(const o of this.blockClickedHandlers)o(i.payload.clickedBlockId,i.payload.currentPage||1);break;case"OPEN_IN_EDITOR":if(i.payload.blockId||i.payload.clickedBlockId){const o=i.payload.blockId||i.payload.clickedBlockId||"";for(const a of this.openInEditorHandlers)a(o,i.payload.currentPage||1)}break;case"OPEN_PEEK_DRAWER":if(i.payload.peekType){const o=i.payload.blockId||i.payload.url||"",a={peekType:i.payload.peekType,target:o,title:i.payload.title};for(const r of this.openPeekDrawerHandlers)r(a)}break;case"REQUEST_TOGGLE_FULLSCREEN":for(const o of this.toggleFullscreenHandlers)o();break;case"OPEN_PRESENTER":for(const o of this.openPresenterHandlers)o();break;case"CAPTURE_PROGRESS":if(i.payload.captureProgress)for(const o of this.captureProgressHandlers)o(i.payload.captureProgress);break;case"CAPTURE_PAGE_DONE":if(i.payload.captureResult)for(const o of this.capturePageDoneHandlers)o(i.payload.captureResult);break;case"CAPTURE_COMPLETE":for(const o of this.captureCompleteHandlers)o({total:i.payload.totalPages||0});break;case"CAPTURE_ERROR":for(const o of this.captureErrorHandlers)o(i.payload.captureError||"未知沙箱截图异常");break}}}const zl={"snippets/external.ts":`// Inside ./snippets/external.ts
// #region snippet
export function emptyArray<T>(length: number) {
  return Array.from<T>({ length })
}
// #endregion snippet

export function sayHello() {
  console.log('Hello from snippets/external.ts')
}
`},vp=`<script setup lang="ts">
import { computed, useSlots } from 'vue'

const props = defineProps({
  layoutRatio: {
    type: String,
    default: '',
  },
  cols: {
    type: [Number, String],
    default: 0,
  },
})

const slots = useSlots()

const detectedColsCount = computed(() => {
  const explicitCols = Number(props.cols)
  if (explicitCols >= 2 && explicitCols <= 6) return explicitCols
  const r = (props.layoutRatio || '').trim()
  if (r.includes(':')) {
    const parts = r.split(':').map(p => parseFloat(p.trim())).filter(n => !isNaN(n) && n > 0)
    if (parts.length >= 2) return Math.min(parts.length, 6)
  }
  const tokens = r.split(/\\s+/).filter(Boolean)
  if (tokens.length >= 2) return Math.min(tokens.length, 6)
  for (let i = 6; i >= 3; i--) {
    if (slots[\`col-\${i}\`]) return i
  }
  if (slots['col-2'] || slots['right']) return 2
  return 2
})

const gridStyle = computed(() => {
  const r = props.layoutRatio || ''
  if (r) {
    if (r.includes(':')) {
      const parts = r.split(':').map(p => parseFloat(p.trim())).filter(n => !isNaN(n) && n > 0)
      if (parts.length >= 2) {
        return { gridTemplateColumns: parts.map(n => \`\${n}fr\`).join(' ') }
      }
    }
    const tokens = r.split(/\\s+/).filter(Boolean)
    if (tokens.length >= 2) {
      return { gridTemplateColumns: tokens.join(' ') }
    }
  }
  return { gridTemplateColumns: \`repeat(\${detectedColsCount.value}, minmax(0, 1fr))\` }
})
<\/script>

<template>
  <div class="slidev-layout cols-header w-full h-full flex flex-col">
    <div class="header-section mb-4 w-full">
      <slot />
    </div>
    <div class="grid gap-6 flex-1 items-stretch" :style="gridStyle">
      <div v-if="detectedColsCount >= 1" class="col-1 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-1"><slot name="left" /></slot>
      </div>
      <div v-if="detectedColsCount >= 2" class="col-2 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-2"><slot v-if="detectedColsCount === 2" name="right" /></slot>
      </div>
      <div v-if="detectedColsCount >= 3" class="col-3 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-3" />
      </div>
      <div v-if="detectedColsCount >= 4" class="col-4 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-4" />
      </div>
      <div v-if="detectedColsCount >= 5" class="col-5 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-5" />
      </div>
      <div v-if="detectedColsCount >= 6" class="col-6 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-6" />
      </div>
    </div>
  </div>
</template>
`,bp=`<script setup lang="ts">
import { computed } from 'vue'

const props = defineProps({
  layoutRatio: {
    type: String,
    default: '',
  },
})

const gridStyle = computed(() => {
  const r = props.layoutRatio || ''
  if (!r) return {}
  if (r.includes(':')) {
    const parts = r.split(':').map(p => parseFloat(p.trim())).filter(n => !isNaN(n) && n > 0)
    if (parts.length >= 2) {
      return { gridTemplateColumns: parts.map(n => \`\${n}fr\`).join(' ') }
    }
  }
  const tokens = r.split(/\\s+/).filter(Boolean)
  if (tokens.length >= 2) {
    return { gridTemplateColumns: tokens.join(' ') }
  }
  return {}
})
<\/script>

<template>
  <div class="slidev-layout three-cols-header w-full h-full flex flex-col">
    <div class="header-section mb-4 w-full">
      <slot />
    </div>
    <div class="grid gap-6 flex-1 items-stretch" :class="gridStyle.gridTemplateColumns ? '' : 'grid-cols-3'" :style="gridStyle">
      <div class="col-1 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-1" />
      </div>
      <div class="col-2 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-2" />
      </div>
      <div class="col-3 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-3" />
      </div>
    </div>
  </div>
</template>
`,yp=`<script setup lang="ts">
import { computed, useSlots } from 'vue'

const props = defineProps({
  mask: {
    type: String,
    default: '',
  },
  maskStyle: {
    type: String,
    default: 'solid',
  },
  maskInitial: {
    type: String,
    default: 'hidden',
  },
  clicks: {
    type: [Number, String],
    default: 0,
  },
})

const slots = useSlots()

const isClockMask = computed(() => {
  const m = props.mask || ''
  return m === 'clockwise' || m === 'counter-clockwise' || m === 'cw' || m === 'ccw'
})

const currentClockClicks = computed(() => {
  // 优先取 Slidev 全局 $slidev.nav.clicks，否则降级为 props.clicks
  // @ts-ignore
  const navClicks = typeof window !== 'undefined' && (window as any).$slidev?.nav?.clicks
  return typeof navClicks === 'number' ? navClicks : Number(props.clicks || 0)
})

const clockPercent = computed(() => {
  if (!isClockMask.value) return 100
  const isInitRev = props.maskInitial === 'revealed'
  const step = currentClockClicks.value
  const bps = [25, 50, 75, 100]
  if (step <= 0) return isInitRev ? bps[0] : 0
  const effectiveIdx = isInitRev ? step : (step - 1)
  if (effectiveIdx >= bps.length) return 100
  return bps[effectiveIdx] || 100
})

const clockNeedleAngle = computed(() => {
  const isCw = props.mask === 'clockwise' || props.mask === 'cw'
  const sweepDeg = Math.min(360, Math.max(0, (clockPercent.value / 100) * 360))
  return isCw ? (-180 + sweepDeg) : (-90 - sweepDeg)
})

const clockMaskOverlayStyle = computed(() => {
  if (!isClockMask.value) return {}
  const p = clockPercent.value
  const isCw = props.mask === 'clockwise' || props.mask === 'cw'
  const sweepDeg = Math.min(360, Math.max(0, (p / 100) * 360))
  let maskGrad = ''
  if (sweepDeg <= 0) {
    maskGrad = 'conic-gradient(from 0deg at 50% 50%, #000 0deg, #000 360deg)'
  } else if (sweepDeg >= 360) {
    maskGrad = 'conic-gradient(from 0deg at 50% 50%, transparent 0deg, transparent 360deg)'
  } else if (isCw) {
    maskGrad = \`conic-gradient(from 270deg at 50% 50%, transparent 0deg, transparent \${sweepDeg}deg, #000 \${sweepDeg}deg, #000 360deg)\`
  } else {
    const remDeg = 360 - sweepDeg
    maskGrad = \`conic-gradient(from 0deg at 50% 50%, #000 0deg, #000 \${remDeg}deg, transparent \${remDeg}deg, transparent 360deg)\`
  }
  return {
    WebkitMaskImage: maskGrad,
    maskImage: maskGrad,
  }
})
<\/script>

<template>
  <div class="slidev-layout clover w-full h-full flex flex-col">
    <div class="header-section mb-4 w-full">
      <slot />
    </div>
    <div class="relative flex-1 min-h-0 overflow-hidden">
      <div class="grid grid-cols-2 grid-rows-2 gap-6 w-full h-full items-stretch">
        <div class="col-1 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
          <slot name="col-1" />
        </div>
        <div class="col-2 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
          <slot name="col-2" />
        </div>
        <div class="col-3 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
          <slot name="col-3" />
        </div>
        <div class="col-4 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
          <slot name="col-4" />
        </div>
      </div>
      <div
        v-if="isClockMask"
        class="slides-mask-layer slides-mask-layer--clock pointer-events-none absolute inset-0 z-50 transition-opacity duration-300"
        :class="props.maskStyle === 'blur' ? 'slides-mask-layer--blur' : 'slides-mask-layer--solid'"
        :style="{ opacity: clockPercent >= 100 ? 0 : 1 }"
      >
        <div
          class="slides-mask-overlay absolute inset-0 w-full h-full"
          :class="props.maskStyle === 'blur' ? 'backdrop-blur-xl bg-white/70 dark:bg-black/70' : 'bg-[var(--slide-bg,#fff)] dark:bg-[var(--slide-bg,#121214)]'"
          :style="clockMaskOverlayStyle"
        />
        <div
          class="slides-mask-divider-line slides-mask-divider-line--clock absolute pointer-events-none transition-all duration-300"
          :style="{
            top: '50%',
            left: '50%',
            width: '55%',
            height: '2.5px',
            transformOrigin: '0% 50%',
            transform: \`translateY(-50%) rotate(\${clockNeedleAngle}deg)\`,
            opacity: (clockPercent <= 0 || clockPercent >= 100) ? 0 : 1,
            background: 'linear-gradient(90deg, var(--slide-accent, #3b82f6) 0%, var(--slide-accent, #3b82f6) 75%, transparent 100%)',
            boxShadow: '0 0 10px var(--slide-accent, #3b82f6), 0 0 4px var(--slide-accent, #3b82f6)',
          }"
        />
      </div>
    </div>
  </div>
</template>
`,kp=`// Auto-generated by SiYuan Slidev Studio
// 本地 HTML 链接（思源资产 / 工作区文件 / 绝对文件路径）速览判定
// 注意：需与 public/slides-client/index.html 中的拦截器保持同步
function isPeekableLocalHtml(href: string): boolean {
  const clean = (href || '').trim()
  if (!clean || clean.startsWith('#') || clean.startsWith('//')) return false
  if (!/\\.html?($|[?#])/i.test(clean)) return false
  if (/^https?:\\/\\//i.test(clean)) return false
  const scheme = /^([a-z][a-z0-9+.-]*):/i.exec(clean)
  if (!scheme) return true
  const schemeName = scheme[1].toLowerCase()
  if (schemeName === 'file') return true
  // Windows 盘符路径（D:\\\\docs\\\\demo.html）并非协议前缀
  return schemeName.length === 1 && /^[a-zA-Z]:[\\\\/]/.test(clean)
}

// 本地 HTML 链接预处理：思源资产统一指向内核 /assets/ 静态服务，其余原样转交宿主归一化
// 不基于 location 绝对化，保证 Pro 模式（Slidev dev server）与沙箱模式行为完全一致
function resolvePeekHref(href: string): string {
  const clean = (href || '').trim()
  if (/^(?:\\.\\/|\\/)?assets\\//.test(clean)) {
    return '/' + clean.replace(/^(?:\\.\\/|\\/)/, '')
  }
  return clean
}

export default function() {
  if (typeof window === 'undefined') return
  window.addEventListener('click', (e: MouseEvent) => {
    const target = e.target as HTMLElement | null
    if (!target || !target.closest) return

    const refEl = target.closest('[data-ref-id]')
    if (refEl) {
      const blockId = refEl.getAttribute('data-ref-id')
      if (blockId) {
        e.preventDefault()
        e.stopPropagation()
        window.parent.postMessage({
          source: 'siyuan-slides-client',
          action: 'OPEN_PEEK_DRAWER',
          payload: { peekType: 'siyuan', blockId, title: (refEl.innerText || refEl.title || '').trim() }
        }, '*')
        return
      }
    }

    const linkEl = target.closest('a') as HTMLAnchorElement | null
    if (linkEl) {
      const href = linkEl.getAttribute('href') || ''
      if (href.startsWith('siyuan://blocks/')) {
        e.preventDefault()
        e.stopPropagation()
        const cleanBlockId = href.replace('siyuan://blocks/', '').split('?')[0]
        window.parent.postMessage({
          source: 'siyuan-slides-client',
          action: 'OPEN_PEEK_DRAWER',
          payload: { peekType: 'siyuan', blockId: cleanBlockId, title: (linkEl.innerText || linkEl.title || '').trim() }
        }, '*')
      } else if (/^https?:\\/\\//i.test(href)) {
        e.preventDefault()
        e.stopPropagation()
        window.parent.postMessage({
          source: 'siyuan-slides-client',
          action: 'OPEN_PEEK_DRAWER',
          payload: { peekType: 'web', url: href, title: (linkEl.innerText || linkEl.title || '').trim() }
        }, '*')
      } else if (isPeekableLocalHtml(href)) {
        e.preventDefault()
        e.stopPropagation()
        window.parent.postMessage({
          source: 'siyuan-slides-client',
          action: 'OPEN_PEEK_DRAWER',
          payload: { peekType: 'web', url: resolvePeekHref(href), title: (linkEl.innerText || linkEl.title || '').trim() }
        }, '*')
      }
    }
  }, true)
}
`,wp=`${Oo}

/* Auto-generated by SiYuan Slidev Studio */
.slides-ref-tag,
a.slides-ref-tag {
  display: inline-flex;
  align-items: center;
  background: color-mix(in srgb, var(--slides-theme-primary, #10b981) 12%, transparent);
  color: var(--slides-theme-primary, #10b981);
  border-radius: 4px;
  padding: 2px 8px;
  font-size: 0.88em;
  text-decoration: none;
  border: 1px solid color-mix(in srgb, var(--slides-theme-primary, #10b981) 25%, transparent);
  cursor: pointer;
  transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
  user-select: none;
}

.slides-ref-tag:hover,
a.slides-ref-tag:hover {
  background: color-mix(in srgb, var(--slides-theme-primary, #10b981) 22%, transparent);
  color: var(--slides-theme-primary, #10b981);
  border-color: color-mix(in srgb, var(--slides-theme-primary, #10b981) 55%, transparent);
  transform: translateY(-1px);
  box-shadow: 0 2px 8px color-mix(in srgb, var(--slides-theme-primary, #10b981) 20%, transparent);
}

.slides-block-ref {
  display: block;
  padding: 10px 14px;
  background: color-mix(in srgb, var(--slides-theme-primary, #10b981) 8%, transparent);
  border-left: 3px solid var(--slides-theme-primary, #10b981);
  border-radius: 0 6px 6px 0;
  margin: 8px 0;
  cursor: pointer;
  transition: background 0.2s ease;
}

.slides-block-ref:hover {
  background: color-mix(in srgb, var(--slides-theme-primary, #10b981) 15%, transparent);
}

/* 代码块自动换行与无横向滚动条 */
pre,
pre code {
  white-space: pre-wrap !important;
  word-break: break-all !important;
  overflow-wrap: anywhere !important;
  overflow-x: hidden !important;
  overflow-y: auto !important;
  max-width: 100% !important;
  box-sizing: border-box !important;
}

/* 弱提示滚动条样式 */
* {
  scrollbar-width: thin;
}
html:not(.dark) * {
  scrollbar-color: rgba(0, 0, 0, 0.15) transparent;
}
html.dark * {
  scrollbar-color: rgba(255, 255, 255, 0.20) transparent;
}
*::-webkit-scrollbar {
  width: 4px;
  height: 4px;
}
*::-webkit-scrollbar-track {
  background: transparent;
}
html:not(.dark) *::-webkit-scrollbar-thumb {
  background: rgba(0, 0, 0, 0.15);
  border-radius: 2px;
}
html:not(.dark) *:hover::-webkit-scrollbar-thumb,
html:not(.dark) *::-webkit-scrollbar-thumb:hover {
  background: rgba(0, 0, 0, 0.35);
}
html.dark *::-webkit-scrollbar-thumb {
  background: rgba(255, 255, 255, 0.20);
  border-radius: 2px;
}
html.dark *:hover::-webkit-scrollbar-thumb,
html.dark *::-webkit-scrollbar-thumb:hover {
  background: rgba(255, 255, 255, 0.45);
}

/* 多媒体（GIF动图、静态图片、MP4视频）最大化自适应且不超出视口：顶部对齐，横向居中 */
.slidev-layout img,
.slidev-layout video {
  max-width: 100% !important;
  max-height: 100% !important;
  width: auto;
  height: auto;
  object-fit: contain !important;
}
.three-cols-header video,
.two-cols-header video,
.grid-cols-3 video,
.grid-cols-2 video,
.col-1 video,
.col-2 video,
.col-3 video {
  width: auto !important;
  height: auto !important;
  max-width: 100% !important;
  max-height: 100% !important;
  object-fit: contain !important;
  display: block !important;
  margin: 0 auto !important;
}
.slide-list-media {
  display: flex !important;
  flex-direction: column !important;
  align-items: center !important;
  justify-content: flex-start !important;
  margin-top: 4px !important;
  margin-bottom: 4px !important;
  width: 100% !important;
  max-width: 100% !important;
  height: 100% !important;
  max-height: 100% !important;
  flex: 1 1 0% !important;
  overflow: hidden !important;
}
.slide-list-media img,
.slide-list-media video,
.slide-list-media .list-item-gif {
  width: auto !important;
  height: auto !important;
  max-width: 100% !important;
  max-height: 100% !important;
  object-fit: contain !important;
  border-radius: 6px !important;
  box-shadow: 0 3px 12px rgba(0, 0, 0, 0.14) !important;
  display: block !important;
  margin: 0 auto !important;
}
.slide-video-container {
  display: flex !important;
  flex-direction: column !important;
  justify-content: flex-start !important;
  align-items: center !important;
  width: 100% !important;
  max-height: 100% !important;
  margin: 6px 0 !important;
}
.slide-video-player {
  max-width: 100% !important;
  max-height: 100% !important;
  object-fit: contain !important;
  border-radius: 8px !important;
}

/* 两栏与多栏（超级块分栏）布局：紧凑自然行距，子列表保留圆点与层级缩进 */
.cols-header ul,
.three-cols-header ul,
.two-cols-header ul,
.two-cols ul,
.col-1 ul,
.col-2 ul,
.col-3 ul,
.col-4 ul,
.col-5 ul,
.col-6 ul,
.grid-cols-2 ul,
.grid-cols-3 ul {
  list-style: disc !important;
  list-style-type: disc !important;
  padding-left: 1.25em !important;
  margin-left: 0 !important;
  margin-top: 0 !important;
  margin-bottom: 8px !important;
  flex: 0 0 auto !important;
  height: auto !important;
  display: block !important;
}
.cols-header ol,
.three-cols-header ol,
.two-cols-header ol,
.two-cols ol,
.col-1 ol,
.col-2 ol,
.col-3 ol,
.col-4 ol,
.col-5 ol,
.col-6 ol,
.grid-cols-2 ol,
.grid-cols-3 ol {
  list-style: decimal !important;
  list-style-type: decimal !important;
  padding-left: 1.25em !important;
  margin-left: 0 !important;
  margin-top: 0 !important;
  margin-bottom: 8px !important;
  flex: 0 0 auto !important;
  height: auto !important;
  display: block !important;
}
.cols-header li,
.three-cols-header li,
.two-cols-header li,
.two-cols li,
.col-1 li,
.col-2 li,
.col-3 li,
.col-4 li,
.col-5 li,
.col-6 li,
.grid-cols-2 li,
.grid-cols-3 li {
  padding-left: 0.2em !important;
  margin-left: 0 !important;
  margin-bottom: 6px !important;
  flex: 0 0 auto !important;
  height: auto !important;
  display: list-item !important;
  line-height: 1.6 !important;
}
.cols-header ul ul,
.three-cols-header ul ul,
.two-cols-header ul ul,
.two-cols ul ul,
.col-1 ul ul,
.col-2 ul ul,
.col-3 ul ul,
.col-4 ul ul,
.col-5 ul ul,
.col-6 ul ul {
  list-style: circle !important;
  list-style-type: circle !important;
  padding-left: 1.25em !important;
  margin-top: 4px !important;
  margin-bottom: 4px !important;
}

/* 列表项内嵌标题与说明排版 */
.slide-list-item-title,
li > h1,
li > h2,
li > h3,
li > h4,
li > h5,
li > h6 {
  margin-top: 2px !important;
  margin-bottom: 6px !important;
  line-height: 1.35 !important;
  font-weight: 700 !important;
}
li > h1 { font-size: 1.6rem !important; }
li > h2 { font-size: 1.4rem !important; }
li > h3 { font-size: 1.22rem !important; }
li > h4 { font-size: 1.1rem !important; }
.slide-list-item-desc,
li > p {
  margin-top: 4px !important;
  margin-bottom: 6px !important;
  font-size: 1.05rem;
  line-height: 1.55;
  opacity: 0.92;
}
`;function xp(e){var s;const t=[],i=/^[ \t]*<<<[ \t]+(?:@\/|\.\/|)([^\s#]+)(?:#[^\s]+)?/gm;let n;for(;(n=i.exec(e))!==null;){const o=(s=n[1])==null?void 0:s.trim();o&&!t.includes(o)&&t.push(o)}return t}class Sp{constructor(t){ye(this,"workspacePath");ye(this,"slidesFileName");ye(this,"cliBridge",new ur);const i=hp();!(t!=null&&t.workspacePath)||t.workspacePath.includes("/data/storage/petal/siyuan-live-slides/pro-workspace")?this.workspacePath=i:this.workspacePath=t.workspacePath,this.slidesFileName=(t==null?void 0:t.slidesFileName)||"slides.md"}getWorkspacePath(){return this.workspacePath}getSlidesPath(){return`${this.workspacePath}/${this.slidesFileName}`}generatePackageJson(t="default"){const i={name:"siyuan-live-slides-pro-workspace",type:"module",private:!0,scripts:{dev:"slidev --port 3030",build:"slidev build"},dependencies:{"@slidev/cli":"^53.0.0","@slidev/theme-default":"latest"}};return t&&t!=="default"&&(i.dependencies[`@slidev/theme-${t}`]="latest"),JSON.stringify(i,null,2)}buildSlidesMarkdown(t){return this.cliBridge.buildStandardSlidevMarkdown(t)}async scaffold(t,i){const n=this.buildSlidesMarkdown(t),s=this.generatePackageJson(t.config.theme),o=this.getSlidesPath(),a=`${this.workspacePath}/package.json`,r=No(o),l=No(a),c=xp(n);c.includes("snippets/external.ts")||c.push("snippets/external.ts");const u=new Map;for(const S of c){const w=zl[S]||`// Auto-generated snippet placeholder for SiYuan Slidev
// #region snippet
// ${S}
// #endregion snippet
`;u.set(S,w)}t.slides.some(S=>{var w;return((w=S.frontmatter)==null?void 0:w.layout)==="cols-header"})&&u.set("layouts/cols-header.vue",vp),t.slides.some(S=>{var w;return((w=S.frontmatter)==null?void 0:w.layout)==="three-cols-header"})&&u.set("layouts/three-cols-header.vue",bp),t.slides.some(S=>{var w;return((w=S.frontmatter)==null?void 0:w.layout)==="clover"})&&u.set("layouts/clover.vue",yp),u.set("setup/root.ts",kp),u.set("styles/index.css",wp);const v=Mt("fs"),m=Mt("path");let b=!1;const y=m!=null&&m.dirname?m.dirname(r):"",x=/^[a-zA-Z]:[/\\]/.test(r)||r.includes("siyuan-live-slides-pro");if(v&&m&&x)try{v.existsSync(y)||v.mkdirSync(y,{recursive:!0}),v.writeFileSync(l,s,"utf-8"),v.writeFileSync(r,n,"utf-8");for(const[S,w]of u.entries()){const $=m.join(y,S),E=m.dirname($);v.existsSync(E)||v.mkdirSync(E,{recursive:!0}),v.existsSync($)||v.writeFileSync($,w,"utf-8")}b=!0}catch{}if(!b&&i)try{const S=typeof Blob<"u"?new Blob([n],{type:"text/markdown;charset=utf-8"}):Buffer.from(n,"utf-8"),w=typeof Blob<"u"?new Blob([s],{type:"application/json;charset=utf-8"}):Buffer.from(s,"utf-8");await i(a,!1,w),await i(o,!1,S);for(const[$,E]of u.entries()){const C=`${this.workspacePath}/${$}`,L=typeof Blob<"u"?new Blob([E],{type:"text/plain;charset=utf-8"}):Buffer.from(E,"utf-8");await i(C,!1,L).catch(()=>{})}return{success:!0,slidesPath:o,physicalSlidesPath:r,packageJsonPath:a}}catch(S){return{success:!1,slidesPath:o,physicalSlidesPath:r,packageJsonPath:a,error:String(S)}}return{success:!0,slidesPath:o,physicalSlidesPath:r,packageJsonPath:a}}}class Cp{constructor(){ye(this,"mode","web-sandbox");ye(this,"webBridge");ye(this,"cliBridge");ye(this,"nativeBridge");ye(this,"processManager");ye(this,"scaffolder");ye(this,"envDetector");this.webBridge=new Qn,this.cliBridge=new ur,this.nativeBridge=new mp,this.processManager=new gp,this.scaffolder=new Sp,this.envDetector=new pr}getMode(){return this.mode}setMode(t){this.mode=t}async startProMode(t,i){if(!(await this.envDetector.detect()).hasNode)return{success:!1,url:"",error:"当前系统未检测到 Node.js 环境，无法拉起官方 Slidev CLI，建议继续使用内置高保真引擎"};const s=await this.scaffolder.scaffold(t,i);if(!s.success)return{success:!1,url:"",error:`初始化 Slidev 临时工作空间失败: ${s.error}`};const o=s.physicalSlidesPath||s.slidesPath,a=await this.processManager.startServer(o);return a.success?(this.mode="pro-cli",{success:!0,url:a.url,port:a.port}):{success:!1,url:"",error:a.error}}stopProMode(){this.processManager.stopServer(),this.mode="web-sandbox"}destroy(){this.webBridge.detach(),this.nativeBridge.detach(),this.processManager.stopServer()}}const _p={class:"slides-icon",style:{fill:"none !important"},viewBox:"0 0 24 24",stroke:"currentColor","stroke-width":"1.75","stroke-linecap":"round","stroke-linejoin":"round","aria-hidden":"true"},$p={key:0},Ip={key:1},Mp={key:2},Tp={key:3},Ep={key:4},Ap={key:5},Bp={key:6},Dp={key:7},Lp={key:8},Pp={key:9},Op={key:10},Rp={key:11},Np={key:12},zp={key:13},Hp={key:14},Fp={key:15},jp={key:16},Wp={key:17},Up={key:18},Vp={key:19},Gp={key:20},Kp={key:21},qp={key:22},Yp={key:23},Zp={key:24},Jp={key:25},Xp={key:26},Qp={key:27},eh={key:28},th={key:29},ih={key:30},nh={key:31},sh={key:32},oh={key:33},rh={key:34},ah={key:35},lh={key:36},ch={key:37},dh={key:38},uh={key:39},fh={key:40},ph={key:41},hh={key:42},mh={key:43},gh={key:44},vh={key:45},bh={key:46},yh={key:47},kh={key:48},wh={key:49},xh={key:50},Sh={key:51},Ch={key:52},_h={key:53},$h={key:54},Ih={key:55},Mh={key:56},Th={key:57},Eh={key:58},Ah={key:59},Bh={key:60},Dh={key:61},Lh={key:62},Ph={key:63},Oh={key:64},Rh={key:65},Nh={key:66},zh={key:67},Hh={key:68},Fh={key:69},jh={key:70},Wh={key:71},Uh={key:72},Vh=At({__name:"SlidesIcon",props:{name:{}},setup(e){return(t,i)=>(X(),ee("svg",_p,[e.name==="fullscreen"||e.name==="maximize"?(X(),ee("g",$p,[...i[0]||(i[0]=[p("polyline",{points:"15 3 21 3 21 9"},null,-1),p("polyline",{points:"9 21 3 21 3 15"},null,-1),p("polyline",{points:"21 15 21 21 15 21"},null,-1),p("polyline",{points:"3 9 3 3 9 3"},null,-1)])])):e.name==="minimize"?(X(),ee("g",Ip,[...i[1]||(i[1]=[p("polyline",{points:"4 14 10 14 10 20"},null,-1),p("polyline",{points:"20 10 14 10 14 4"},null,-1),p("line",{x1:"14",y1:"10",x2:"21",y2:"3"},null,-1),p("line",{x1:"3",y1:"21",x2:"10",y2:"14"},null,-1)])])):e.name==="close"||e.name==="x"?(X(),ee("g",Mp,[...i[2]||(i[2]=[p("line",{x1:"18",y1:"6",x2:"6",y2:"18"},null,-1),p("line",{x1:"6",y1:"6",x2:"18",y2:"18"},null,-1)])])):e.name==="edit"?(X(),ee("g",Tp,[...i[3]||(i[3]=[p("path",{d:"M12 20h9"},null,-1),p("path",{d:"M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z"},null,-1)])])):e.name==="eye"?(X(),ee("g",Ep,[...i[4]||(i[4]=[p("path",{d:"M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"},null,-1),p("circle",{cx:"12",cy:"12",r:"3"},null,-1)])])):e.name==="external-link"||e.name==="window"?(X(),ee("g",Ap,[...i[5]||(i[5]=[p("path",{d:"M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"},null,-1),p("polyline",{points:"15 3 21 3 21 9"},null,-1),p("line",{x1:"10",y1:"14",x2:"21",y2:"3"},null,-1)])])):e.name==="arrow-left"?(X(),ee("g",Bp,[...i[6]||(i[6]=[p("line",{x1:"19",y1:"12",x2:"5",y2:"12"},null,-1),p("polyline",{points:"12 19 5 12 12 5"},null,-1)])])):e.name==="arrow-right"?(X(),ee("g",Dp,[...i[7]||(i[7]=[p("line",{x1:"5",y1:"12",x2:"19",y2:"12"},null,-1),p("polyline",{points:"12 5 19 12 12 19"},null,-1)])])):e.name==="plus"?(X(),ee("g",Lp,[...i[8]||(i[8]=[p("line",{x1:"12",y1:"5",x2:"12",y2:"19"},null,-1),p("line",{x1:"5",y1:"12",x2:"19",y2:"12"},null,-1)])])):e.name==="minus"?(X(),ee("g",Pp,[...i[9]||(i[9]=[p("line",{x1:"5",y1:"12",x2:"19",y2:"12"},null,-1)])])):e.name==="split-preview"?(X(),ee("g",Op,[...i[10]||(i[10]=[p("rect",{x:"3",y:"3",width:"18",height:"18",rx:"2"},null,-1),p("path",{d:"M12 3v18"},null,-1)])])):e.name==="import"?(X(),ee("g",Rp,[...i[11]||(i[11]=[p("path",{d:"M4 17v2a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-2"},null,-1),p("polyline",{points:"7 9 12 14 17 9"},null,-1),p("line",{x1:"12",y1:"14",x2:"12",y2:"3"},null,-1)])])):e.name==="presenter"?(X(),ee("g",Np,[...i[12]||(i[12]=[p("path",{d:"M2 3h20"},null,-1),p("path",{d:"M21 3v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V3"},null,-1),p("path",{d:"m7 21 5-5 5 5"},null,-1)])])):e.name==="video"?(X(),ee("g",zp,[...i[13]||(i[13]=[p("polygon",{points:"23 7 16 12 23 17 23 7"},null,-1),p("rect",{x:"1",y:"5",width:"15",height:"14",rx:"2",ry:"2"},null,-1)])])):e.name==="step"?(X(),ee("g",Hp,[...i[14]||(i[14]=[p("polygon",{points:"13 2 3 14 12 14 11 22 21 10 12 10 13 2"},null,-1)])])):e.name==="motion"?(X(),ee("g",Fp,[...i[15]||(i[15]=[p("path",{d:"M5 12h14"},null,-1),p("path",{d:"m12 5 7 7-7 7"},null,-1),p("path",{d:"M5 6h4"},null,-1),p("path",{d:"M5 18h4"},null,-1)])])):e.name==="columns"?(X(),ee("g",jp,[...i[16]||(i[16]=[p("rect",{x:"3",y:"3",width:"7",height:"18",rx:"1"},null,-1),p("rect",{x:"14",y:"3",width:"7",height:"18",rx:"1"},null,-1)])])):e.name==="code"?(X(),ee("g",Wp,[...i[17]||(i[17]=[p("polyline",{points:"16 18 22 12 16 6"},null,-1),p("polyline",{points:"8 6 2 12 8 18"},null,-1)])])):e.name==="list"?(X(),ee("g",Up,[...i[18]||(i[18]=[ht('<line x1="8" y1="6" x2="21" y2="6" data-v-af7d02a2></line><line x1="8" y1="12" x2="21" y2="12" data-v-af7d02a2></line><line x1="8" y1="18" x2="21" y2="18" data-v-af7d02a2></line><line x1="3" y1="6" x2="3.01" y2="6" data-v-af7d02a2></line><line x1="3" y1="12" x2="3.01" y2="12" data-v-af7d02a2></line><line x1="3" y1="18" x2="3.01" y2="18" data-v-af7d02a2></line>',6)])])):e.name==="insert-above"?(X(),ee("g",Vp,[...i[19]||(i[19]=[p("line",{x1:"12",y1:"5",x2:"12",y2:"13"},null,-1),p("line",{x1:"8",y1:"9",x2:"16",y2:"9"},null,-1),p("path",{d:"M4 19h16","stroke-dasharray":"2 2"},null,-1)])])):e.name==="insert-below"?(X(),ee("g",Gp,[...i[20]||(i[20]=[p("path",{d:"M4 5h16","stroke-dasharray":"2 2"},null,-1),p("line",{x1:"12",y1:"11",x2:"12",y2:"19"},null,-1),p("line",{x1:"8",y1:"15",x2:"16",y2:"15"},null,-1)])])):e.name==="broom"?(X(),ee("g",Kp,[...i[21]||(i[21]=[p("path",{d:"m18 15-6-6"},null,-1),p("path",{d:"M4 20h16"},null,-1),p("path",{d:"M6 14l8-8a2.8 2.8 0 0 1 4 4l-8 8H6v-4z"},null,-1)])])):e.name==="trash"?(X(),ee("g",qp,[...i[22]||(i[22]=[p("path",{d:"M3 6h18"},null,-1),p("path",{d:"M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"},null,-1),p("path",{d:"M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"},null,-1)])])):e.name==="ai"||e.name==="sparkles"?(X(),ee("g",Yp,[...i[23]||(i[23]=[p("path",{d:"m12 3-1.9 5.8a2 2 0 0 1-1.3 1.3L3 12l5.8 1.9a2 2 0 0 1 1.3 1.3L12 21l1.9-5.8a2 2 0 0 1 1.3-1.3L21 12l-5.8-1.9a2 2 0 0 1-1.3-1.3L12 3z"},null,-1)])])):e.name==="palette"?(X(),ee("g",Zp,[...i[24]||(i[24]=[ht('<circle cx="13.5" cy="6.5" r=".5" fill="currentColor" data-v-af7d02a2></circle><circle cx="17.5" cy="10.5" r=".5" fill="currentColor" data-v-af7d02a2></circle><circle cx="8.5" cy="7.5" r=".5" fill="currentColor" data-v-af7d02a2></circle><circle cx="6.5" cy="12.5" r=".5" fill="currentColor" data-v-af7d02a2></circle><path d="M12 2C6.5 2 2 6.5 2 12s4.5 10 10 10c.9 0 1.5-.7 1.5-1.5 0-.4-.2-.8-.4-1.1-.3-.4-.4-.8-.4-1.4 0-1.1.9-2 2-2h2.3c3.9 0 7-3.1 7-7 0-5-4.5-9-10-9z" data-v-af7d02a2></path>',5)])])):e.name==="ratio"?(X(),ee("g",Jp,[...i[25]||(i[25]=[p("rect",{x:"2",y:"5",width:"20",height:"14",rx:"2"},null,-1),p("line",{x1:"2",y1:"10",x2:"22",y2:"10","stroke-dasharray":"2 2"},null,-1)])])):e.name==="transition"?(X(),ee("g",Xp,[...i[26]||(i[26]=[p("path",{d:"M8 3 4 7l4 4"},null,-1),p("path",{d:"M4 7h16"},null,-1),p("path",{d:"m16 21 4-4-4-4"},null,-1),p("path",{d:"M20 17H4"},null,-1)])])):e.name==="export-html"?(X(),ee("g",Qp,[...i[27]||(i[27]=[p("polyline",{points:"16 16 12 12 8 16"},null,-1),p("line",{x1:"12",y1:"12",x2:"12",y2:"21"},null,-1),p("path",{d:"M20.4 16.3A5 5 0 0 0 18 7h-1.3A8 8 0 0 0 4 12.8a5 5 0 0 0 1.5 9.2"},null,-1)])])):e.name==="export-pdf"?(X(),ee("g",eh,[...i[28]||(i[28]=[p("polyline",{points:"6 9 6 2 18 2 18 9"},null,-1),p("path",{d:"M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"},null,-1),p("rect",{x:"6",y:"14",width:"12",height:"8"},null,-1)])])):e.name==="pin"?(X(),ee("g",th,[...i[29]||(i[29]=[p("line",{x1:"12",y1:"17",x2:"12",y2:"22"},null,-1),p("path",{d:"M5 17h14v-2l-2-2V5l1-1V2H6v2l1 1v8l-2 2v2z"},null,-1)])])):e.name==="refresh"?(X(),ee("g",ih,[...i[30]||(i[30]=[p("path",{d:"M3 12a9 9 0 0 1 9-9 9.75 9.75 0 0 1 6.74 2.74L21 8"},null,-1),p("path",{d:"M21 3v5h-5"},null,-1),p("path",{d:"M21 12a9 9 0 0 1-9 9 9.75 9.75 0 0 1-6.74-2.74L3 16"},null,-1),p("path",{d:"M8 16H3v5"},null,-1)])])):e.name==="alert"||e.name==="warning"?(X(),ee("g",nh,[...i[31]||(i[31]=[p("path",{d:"M10.29 3.86 1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"},null,-1),p("line",{x1:"12",y1:"9",x2:"12",y2:"13"},null,-1),p("line",{x1:"12",y1:"17",x2:"12.01",y2:"17"},null,-1)])])):e.name==="chevron-left"?(X(),ee("g",sh,[...i[32]||(i[32]=[p("polyline",{points:"15 18 9 12 15 6"},null,-1)])])):e.name==="chevron-right"?(X(),ee("g",oh,[...i[33]||(i[33]=[p("polyline",{points:"9 18 15 12 9 6"},null,-1)])])):e.name==="chevron-down"?(X(),ee("g",rh,[...i[34]||(i[34]=[p("polyline",{points:"6 9 12 15 18 9"},null,-1)])])):e.name==="chevrons-left"?(X(),ee("g",ah,[...i[35]||(i[35]=[p("polyline",{points:"11 17 6 12 11 7"},null,-1),p("polyline",{points:"18 17 13 12 18 7"},null,-1)])])):e.name==="chevrons-right"?(X(),ee("g",lh,[...i[36]||(i[36]=[p("polyline",{points:"13 17 18 12 13 7"},null,-1),p("polyline",{points:"6 17 11 12 6 7"},null,-1)])])):e.name==="play"?(X(),ee("g",ch,[...i[37]||(i[37]=[p("polygon",{points:"6 3 20 12 6 21 6 3"},null,-1)])])):e.name==="pause"?(X(),ee("g",dh,[...i[38]||(i[38]=[p("line",{x1:"10",y1:"4",x2:"10",y2:"20"},null,-1),p("line",{x1:"14",y1:"4",x2:"14",y2:"20"},null,-1)])])):e.name==="clock"?(X(),ee("g",uh,[...i[39]||(i[39]=[p("circle",{cx:"12",cy:"12",r:"10"},null,-1),p("polyline",{points:"12 6 12 12 16 14"},null,-1)])])):e.name==="copy"?(X(),ee("g",fh,[...i[40]||(i[40]=[p("rect",{x:"9",y:"9",width:"13",height:"13",rx:"2",ry:"2"},null,-1),p("path",{d:"M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"},null,-1)])])):e.name==="image"||e.name==="export-image"?(X(),ee("g",ph,[...i[41]||(i[41]=[p("rect",{x:"3",y:"3",width:"18",height:"18",rx:"2",ry:"2"},null,-1),p("circle",{cx:"8.5",cy:"8.5",r:"1.5"},null,-1),p("polyline",{points:"21 15 16 10 5 21"},null,-1)])])):e.name==="search"?(X(),ee("g",hh,[...i[42]||(i[42]=[p("circle",{cx:"11",cy:"11",r:"7"},null,-1),p("line",{x1:"21",y1:"21",x2:"16.65",y2:"16.65"},null,-1)])])):e.name==="settings"||e.name==="gear"?(X(),ee("g",mh,[...i[43]||(i[43]=[p("circle",{cx:"12",cy:"12",r:"3"},null,-1),p("path",{d:"M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 1 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 1 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 1 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 1 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"},null,-1)])])):e.name==="notes"||e.name==="file-text"?(X(),ee("g",gh,[...i[44]||(i[44]=[ht('<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" data-v-af7d02a2></path><polyline points="14 2 14 8 20 8" data-v-af7d02a2></polyline><line x1="16" y1="13" x2="8" y2="13" data-v-af7d02a2></line><line x1="16" y1="17" x2="8" y2="17" data-v-af7d02a2></line><line x1="10" y1="9" x2="8" y2="9" data-v-af7d02a2></line>',5)])])):e.name==="focus"||e.name==="target"?(X(),ee("g",vh,[...i[45]||(i[45]=[p("circle",{cx:"12",cy:"12",r:"3",fill:"currentColor"},null,-1),p("path",{d:"M12 2v4M12 18v4M2 12h4M18 12h4",stroke:"currentColor","stroke-width":"2","stroke-linecap":"round"},null,-1),p("circle",{cx:"12",cy:"12",r:"7",fill:"none",stroke:"currentColor","stroke-width":"1.8"},null,-1)])])):e.name==="layout-cover"||e.name==="cover"?(X(),ee("g",bh,[...i[46]||(i[46]=[p("rect",{x:"2",y:"4",width:"20",height:"16",rx:"2"},null,-1),p("line",{x1:"9",y1:"8",x2:"15",y2:"8"},null,-1),p("line",{x1:"5.5",y1:"11.5",x2:"18.5",y2:"11.5"},null,-1),p("line",{x1:"7.5",y1:"15",x2:"16.5",y2:"15"},null,-1)])])):e.name==="layout-default"||e.name==="default"?(X(),ee("g",yh,[...i[47]||(i[47]=[ht('<rect x="2" y="4" width="20" height="16" rx="2" data-v-af7d02a2></rect><line x1="5" y1="8" x2="11.5" y2="8" data-v-af7d02a2></line><line x1="5" y1="11.5" x2="19" y2="11.5" data-v-af7d02a2></line><line x1="5" y1="14.5" x2="19" y2="14.5" data-v-af7d02a2></line><line x1="5" y1="17.5" x2="13.5" y2="17.5" data-v-af7d02a2></line>',5)])])):e.name==="layout-two-cols"||e.name==="two-cols"?(X(),ee("g",kh,[...i[48]||(i[48]=[ht('<rect x="2" y="4" width="20" height="16" rx="2" data-v-af7d02a2></rect><line x1="12" y1="4" x2="12" y2="20" stroke-dasharray="2 1.5" data-v-af7d02a2></line><line x1="5" y1="8" x2="9.5" y2="8" data-v-af7d02a2></line><line x1="5" y1="11.5" x2="9.5" y2="11.5" data-v-af7d02a2></line><line x1="5" y1="15" x2="8" y2="15" data-v-af7d02a2></line><line x1="14.5" y1="8" x2="19" y2="8" data-v-af7d02a2></line><line x1="14.5" y1="11.5" x2="19" y2="11.5" data-v-af7d02a2></line><line x1="14.5" y1="15" x2="17.5" y2="15" data-v-af7d02a2></line>',8)])])):e.name==="layout-two-cols-header"||e.name==="two-cols-header"?(X(),ee("g",wh,[...i[49]||(i[49]=[ht('<rect x="2" y="4" width="20" height="16" rx="2" data-v-af7d02a2></rect><line x1="5" y1="7.5" x2="13" y2="7.5" data-v-af7d02a2></line><line x1="12" y1="10.5" x2="12" y2="18.5" stroke-dasharray="1.5 1.5" data-v-af7d02a2></line><line x1="5" y1="12" x2="9.5" y2="12" data-v-af7d02a2></line><line x1="5" y1="15.5" x2="8.5" y2="15.5" data-v-af7d02a2></line><line x1="14.5" y1="12" x2="19" y2="12" data-v-af7d02a2></line><line x1="14.5" y1="15.5" x2="18" y2="15.5" data-v-af7d02a2></line>',7)])])):e.name==="layout-cols-header"||e.name==="cols-header"||e.name==="layout-three-cols-header"||e.name==="three-cols-header"?(X(),ee("g",xh,[...i[50]||(i[50]=[ht('<rect x="2" y="4" width="20" height="16" rx="2" data-v-af7d02a2></rect><line x1="5" y1="7.5" x2="13" y2="7.5" data-v-af7d02a2></line><line x1="9.3" y1="10.5" x2="9.3" y2="18.5" stroke-dasharray="1.5 1.5" data-v-af7d02a2></line><line x1="14.7" y1="10.5" x2="14.7" y2="18.5" stroke-dasharray="1.5 1.5" data-v-af7d02a2></line><line x1="4.5" y1="12" x2="7.5" y2="12" data-v-af7d02a2></line><line x1="4.5" y1="15.5" x2="7" y2="15.5" data-v-af7d02a2></line><line x1="10.5" y1="12" x2="13.5" y2="12" data-v-af7d02a2></line><line x1="10.5" y1="15.5" x2="13.5" y2="15.5" data-v-af7d02a2></line><line x1="16" y1="12" x2="19.5" y2="12" data-v-af7d02a2></line><line x1="16" y1="15.5" x2="18.5" y2="15.5" data-v-af7d02a2></line>',10)])])):e.name==="layout-clover"||e.name==="clover"?(X(),ee("g",Sh,[...i[51]||(i[51]=[ht('<rect x="2" y="4" width="20" height="16" rx="2" data-v-af7d02a2></rect><line x1="5" y1="7" x2="13" y2="7" data-v-af7d02a2></line><line x1="4.5" y1="13.5" x2="19.5" y2="13.5" stroke-dasharray="1.5 1.5" data-v-af7d02a2></line><line x1="12" y1="9" x2="12" y2="18.5" stroke-dasharray="1.5 1.5" data-v-af7d02a2></line><line x1="5" y1="11" x2="9.5" y2="11" data-v-af7d02a2></line><line x1="14.5" y1="11" x2="19" y2="11" data-v-af7d02a2></line><line x1="5" y1="16" x2="9.5" y2="16" data-v-af7d02a2></line><line x1="14.5" y1="16" x2="19" y2="16" data-v-af7d02a2></line>',8)])])):e.name==="layout-image-right"||e.name==="image-right"?(X(),ee("g",Ch,[...i[52]||(i[52]=[ht('<rect x="2" y="4" width="20" height="16" rx="2" data-v-af7d02a2></rect><line x1="12" y1="4" x2="12" y2="20" data-v-af7d02a2></line><line x1="4.5" y1="8" x2="9.5" y2="8" data-v-af7d02a2></line><line x1="4.5" y1="11.5" x2="10" y2="11.5" data-v-af7d02a2></line><line x1="4.5" y1="14.5" x2="8" y2="14.5" data-v-af7d02a2></line><circle cx="15.5" cy="8.5" r="1.2" data-v-af7d02a2></circle><polyline points="13 17 15.5 13 18 16 19.5 14" data-v-af7d02a2></polyline>',7)])])):e.name==="layout-image-left"||e.name==="image-left"?(X(),ee("g",_h,[...i[53]||(i[53]=[ht('<rect x="2" y="4" width="20" height="16" rx="2" data-v-af7d02a2></rect><line x1="12" y1="4" x2="12" y2="20" data-v-af7d02a2></line><circle cx="6" cy="8.5" r="1.2" data-v-af7d02a2></circle><polyline points="3.5 17 6 13 8.5 16 10 14" data-v-af7d02a2></polyline><line x1="14.5" y1="8" x2="19.5" y2="8" data-v-af7d02a2></line><line x1="14.5" y1="11.5" x2="20" y2="11.5" data-v-af7d02a2></line><line x1="14.5" y1="14.5" x2="18" y2="14.5" data-v-af7d02a2></line>',7)])])):e.name==="layout-center"||e.name==="center"?(X(),ee("g",$h,[...i[54]||(i[54]=[p("rect",{x:"2",y:"4",width:"20",height:"16",rx:"2"},null,-1),p("line",{x1:"6.5",y1:"9",x2:"17.5",y2:"9"},null,-1),p("line",{x1:"5",y1:"12",x2:"19",y2:"12"},null,-1),p("line",{x1:"8",y1:"15",x2:"16",y2:"15"},null,-1)])])):e.name==="layout-fact"||e.name==="fact"?(X(),ee("g",Ih,[...i[55]||(i[55]=[ht('<rect x="2" y="4" width="20" height="16" rx="2" data-v-af7d02a2></rect><circle cx="8" cy="9" r="1.5" data-v-af7d02a2></circle><line x1="14" y1="8" x2="9" y2="14" data-v-af7d02a2></line><circle cx="15" cy="13" r="1.5" data-v-af7d02a2></circle><line x1="6.5" y1="17" x2="17.5" y2="17" data-v-af7d02a2></line>',5)])])):e.name==="layout-intro"||e.name==="intro"?(X(),ee("g",Mh,[...i[56]||(i[56]=[ht('<rect x="2" y="4" width="20" height="16" rx="2" data-v-af7d02a2></rect><circle cx="7.5" cy="9.5" r="2" data-v-af7d02a2></circle><path d="M4.5 16.5c0-1.8 1.3-3 3-3s3 1.2 3 3" data-v-af7d02a2></path><line x1="13" y1="9" x2="18.5" y2="9" data-v-af7d02a2></line><line x1="13" y1="12.5" x2="19.5" y2="12.5" data-v-af7d02a2></line><line x1="13" y1="15.5" x2="17" y2="15.5" data-v-af7d02a2></line>',6)])])):e.name==="layout-quote"||e.name==="quote"?(X(),ee("g",Th,[...i[57]||(i[57]=[ht('<rect x="2" y="4" width="20" height="16" rx="2" data-v-af7d02a2></rect><path d="M6 7.5h2v2H6.5c0 1.2-.4 2-1.5 2.5" data-v-af7d02a2></path><path d="M9.5 7.5h2v2H10c0 1.2-.4 2-1.5 2.5" data-v-af7d02a2></path><line x1="6" y1="13.5" x2="18" y2="13.5" data-v-af7d02a2></line><line x1="12.5" y1="16.5" x2="17.5" y2="16.5" data-v-af7d02a2></line>',5)])])):e.name==="desktop"||e.name==="monitor"?(X(),ee("g",Eh,[...i[58]||(i[58]=[p("rect",{x:"2",y:"3",width:"20",height:"14",rx:"2"},null,-1),p("line",{x1:"8",y1:"21",x2:"16",y2:"21"},null,-1),p("line",{x1:"12",y1:"17",x2:"12",y2:"21"},null,-1)])])):e.name==="mobile"||e.name==="smartphone"||e.name==="phone"?(X(),ee("g",Ah,[...i[59]||(i[59]=[p("rect",{x:"5",y:"2",width:"14",height:"20",rx:"2",ry:"2"},null,-1),p("line",{x1:"12",y1:"18",x2:"12.01",y2:"18","stroke-width":"2","stroke-linecap":"round"},null,-1)])])):e.name==="type"||e.name==="heading"?(X(),ee("g",Bh,[...i[60]||(i[60]=[p("polyline",{points:"4 7 4 4 20 4 20 7"},null,-1),p("line",{x1:"9",y1:"20",x2:"15",y2:"20"},null,-1),p("line",{x1:"12",y1:"4",x2:"12",y2:"20"},null,-1)])])):e.name==="reset"||e.name==="undo"?(X(),ee("g",Dh,[...i[61]||(i[61]=[p("path",{d:"M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8"},null,-1),p("polyline",{points:"3 3 3 8 8 8"},null,-1)])])):e.name==="repeat"||e.name==="loop"?(X(),ee("g",Lh,[...i[62]||(i[62]=[p("path",{d:"m17 1 4 4-4 4"},null,-1),p("path",{d:"M3 11V9a4 4 0 0 1 4-4h14"},null,-1),p("path",{d:"m7 23-4-4 4-4"},null,-1),p("path",{d:"M21 13v2a4 4 0 0 1-4 4H3"},null,-1)])])):e.name==="volume-x"||e.name==="mute"?(X(),ee("g",Ph,[...i[63]||(i[63]=[p("polygon",{points:"11 5 6 9 2 9 2 15 6 15 11 19 11 5"},null,-1),p("line",{x1:"22",y1:"9",x2:"16",y2:"15"},null,-1),p("line",{x1:"16",y1:"9",x2:"22",y2:"15"},null,-1)])])):e.name==="sliders"||e.name==="controls"?(X(),ee("g",Oh,[...i[64]||(i[64]=[ht('<line x1="4" y1="21" x2="4" y2="14" data-v-af7d02a2></line><line x1="4" y1="10" x2="4" y2="3" data-v-af7d02a2></line><line x1="12" y1="21" x2="12" y2="12" data-v-af7d02a2></line><line x1="12" y1="8" x2="12" y2="3" data-v-af7d02a2></line><line x1="20" y1="21" x2="20" y2="16" data-v-af7d02a2></line><line x1="20" y1="12" x2="20" y2="3" data-v-af7d02a2></line><line x1="1" y1="14" x2="7" y2="14" data-v-af7d02a2></line><line x1="9" y1="8" x2="15" y2="8" data-v-af7d02a2></line><line x1="17" y1="16" x2="23" y2="16" data-v-af7d02a2></line>',9)])])):e.name==="package"||e.name==="zip"||e.name==="archive"?(X(),ee("g",Rh,[...i[65]||(i[65]=[p("line",{x1:"16.5",y1:"9.4",x2:"7.5",y2:"4.21"},null,-1),p("path",{d:"M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"},null,-1),p("polyline",{points:"3.27 6.96 12 12.01 20.73 6.96"},null,-1),p("line",{x1:"12",y1:"22.08",x2:"12",y2:"12"},null,-1)])])):e.name==="folder"?(X(),ee("g",Nh,[...i[66]||(i[66]=[p("path",{d:"M4 20h16a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2h-7.93a2 2 0 0 1-1.66-.9l-.82-1.2A2 2 0 0 0 7.93 3H4a2 2 0 0 0-2 2v13c0 1.1.9 2 2 2Z"},null,-1)])])):e.name==="rocket"?(X(),ee("g",zh,[...i[67]||(i[67]=[p("path",{d:"M4.5 16.5c-1.5 1.26-2 5-2 5s3.74-.5 5-2c.71-.84.7-2.13-.09-2.91a2.18 2.18 0 0 0-2.91-.09z"},null,-1),p("path",{d:"m12 15-3-3a22 22 0 0 1 2-3.95A12.88 12.88 0 0 1 22 2c0 2.72-.78 7.5-6 11a22.35 22.35 0 0 1-4 2z"},null,-1),p("path",{d:"M9 12H4s.55-3.03 2-4c1.62-1.08 5 0 5 0"},null,-1),p("path",{d:"M12 15v5s3.03-.55 4-2c1.08-1.62 0-5 0-5"},null,-1)])])):e.name==="wand"||e.name==="magic"?(X(),ee("g",Hh,[...i[68]||(i[68]=[p("path",{d:"m19 2 2 2-6 6-2-2Z"},null,-1),p("path",{d:"m13 8 2 2"},null,-1),p("path",{d:"m3 21 9-9"},null,-1)])])):e.name==="image-left"?(X(),ee("g",Fh,[...i[69]||(i[69]=[ht('<rect x="2" y="4" width="20" height="16" rx="2" data-v-af7d02a2></rect><rect x="4" y="6" width="6" height="12" rx="1" data-v-af7d02a2></rect><line x1="13" y1="8" x2="19" y2="8" data-v-af7d02a2></line><line x1="13" y1="12" x2="19" y2="12" data-v-af7d02a2></line><line x1="13" y1="16" x2="17" y2="16" data-v-af7d02a2></line>',5)])])):e.name==="image-right"?(X(),ee("g",jh,[...i[70]||(i[70]=[ht('<rect x="2" y="4" width="20" height="16" rx="2" data-v-af7d02a2></rect><rect x="14" y="6" width="6" height="12" rx="1" data-v-af7d02a2></rect><line x1="5" y1="8" x2="11" y2="8" data-v-af7d02a2></line><line x1="5" y1="12" x2="11" y2="12" data-v-af7d02a2></line><line x1="5" y1="16" x2="9" y2="16" data-v-af7d02a2></line>',5)])])):e.name==="help"||e.name==="question"||e.name==="info"?(X(),ee("g",Wh,[...i[71]||(i[71]=[p("circle",{cx:"12",cy:"12",r:"10"},null,-1),p("path",{d:"M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"},null,-1),p("line",{x1:"12",y1:"17",x2:"12.01",y2:"17"},null,-1)])])):(X(),ee("g",Uh,[...i[72]||(i[72]=[p("rect",{x:"2",y:"3",width:"20",height:"14",rx:"2"},null,-1),p("line",{x1:"8",y1:"21",x2:"16",y2:"21"},null,-1),p("line",{x1:"12",y1:"17",x2:"12",y2:"21"},null,-1)])]))]))}}),ei=(e,t)=>{const i=e.__vccOpts||e;for(const[n,s]of t)i[n]=s;return i},pe=ei(Vh,[["__scopeId","data-v-af7d02a2"]]),Gh={class:"spm-immersion-header"},Kh={class:"spm-immersion-header__left"},qh={class:"spm-immersion-title"},Yh={class:"spm-immersion-header__center"},Zh={class:"spm-immersion-header__actions"},Jh=["aria-label"],Xh={class:"spm-immersion-body"},Qh=At({__name:"ImmersionDrawerContainer",props:{visible:{type:Boolean,default:!1},isMaximized:{type:Boolean,default:!1},title:{default:"速览"},closeOnClickMask:{type:Boolean,default:!0}},emits:["update:visible","update:isMaximized","close","toggle-maximize"],setup(e,{emit:t}){const i=e,n=t;function s(){n("update:visible",!1),n("close")}function o(){i.closeOnClickMask&&s()}function a(){n("update:isMaximized",!i.isMaximized),n("toggle-maximize")}function r(l){(l.key===" "||l.key==="ArrowLeft"||l.key==="ArrowRight"||l.key==="PageUp"||l.key==="PageDown")&&l.stopPropagation(),l.key==="Escape"&&(l.preventDefault(),l.stopPropagation(),s())}return(l,c)=>Pt((X(),ee("div",{class:$e(["spm-immersion-container",{"is-maximized":e.isMaximized}]),onKeydown:Yt(r,["stop"])},[p("div",{class:"spm-immersion-mask",onClick:o}),p("div",{class:$e(["spm-immersion-drawer",{"is-maximized":e.isMaximized}])},[p("div",Gh,[p("div",Kh,[rs(l.$slots,"header-left",{},()=>[p("span",qh,Ce(e.title),1)])]),p("div",Yh,[rs(l.$slots,"header-center",{},void 0)]),p("div",Zh,[rs(l.$slots,"header-actions",{},void 0),p("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":e.isMaximized?"还原抽屉宽度 (70%)":"最大化填满视口 (100%)",onClick:a},[ae(pe,{name:e.isMaximized?"minimize":"maximize"},null,8,["name"])],8,Jh),p("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"关闭速览 (ESC)",onClick:s},[ae(pe,{name:"close"})])])]),p("div",Xh,[rs(l.$slots,"default",{},void 0)])],2)],34)),[[Do,e.visible]])}}),em=ei(Qh,[["__scopeId","data-v-1359fecb"]]),tm={class:"spm-protyle-drawer"},im={class:"spm-protyle-drawer__subbar"},nm={class:"spm-protyle-drawer__nav"},sm=["title"],om={class:"spm-protyle-drawer__actions"},rm=["aria-label"],am=["aria-label"],lm=At({__name:"ProtylePeekDrawer",props:{blockId:{},title:{},plugin:{}},emits:["external-jump"],setup(e,{emit:t}){const i=t,n=e,s=ve(n.blockId),o=ve(n.title||""),a=ve(!1),r=ve(!0),l=ve(!1),c=ve(""),u=Ut,d=ve([]),h=ve(null);let f=null;Ui(()=>n.blockId,C=>{C&&C!==s.value&&(s.value=C,o.value=n.title||"",d.value=[],m(C))}),gn(()=>{s.value&&m(s.value)}),ir(()=>{b()});async function v(C){try{const L=await dn(`SELECT id, root_id, type, content FROM blocks WHERE id = '${C}' LIMIT 1`);if(Array.isArray(L)&&L.length>0){const z=L[0];c.value=z.root_id||"";const H=z.id===z.root_id||z.type==="d";l.value=H,r.value=!H,!o.value&&z.content&&(o.value=z.content.trim().slice(0,30));return}}catch(L){console.warn("[ProtylePeekDrawer] detectBlockType query failed:",L)}l.value=!1,r.value=!0}async function m(C,L){if(!h.value||!C)return;b(),await v(C),typeof L=="boolean"&&(r.value=!l.value&&L);let z,H;r.value&&!l.value?(z=["cb-get-all","cb-get-hl","cb-get-focus"],H={background:!1,title:!1,gutter:!0,breadcrumbDocName:!0,scroll:!0}):(z=["cb-get-context","cb-get-hl"],H={background:!0,title:!0,gutter:!0,breadcrumbDocName:!0,scroll:!0});try{f=new ue.Protyle(n.plugin.app,h.value,{blockId:C,action:z,render:H}),!a.value&&f&&typeof f.disable=="function"&&f.disable()}catch(q){console.error("[ProtylePeekDrawer] Failed to instantiate Protyle:",q)}}function b(){if(f){try{typeof f.destroy=="function"&&f.destroy()}catch(C){console.warn("[ProtylePeekDrawer] Error destroying protyle:",C)}f=null}h.value&&(h.value.innerHTML="")}function y(){l.value||(r.value=!r.value,m(s.value,r.value))}function x(){a.value=!a.value,f&&(a.value?(typeof f.enable=="function"&&f.enable(),typeof f.focus=="function"&&f.focus()):typeof f.disable=="function"&&f.disable())}function S(){if(s.value)try{ue.openWindow({doc:{id:s.value},alwaysOnTop:!0})}catch(C){console.warn("[ProtylePeekDrawer] openWindow failed:",C)}}function w(){var z;if(!s.value)return;const C=qs(),L=Al(C.webServeUrl,s.value,{focus:!l.value});if(typeof window<"u"){const H=Mt("electron");(z=H==null?void 0:H.shell)!=null&&z.openExternal?H.shell.openExternal(L).catch(()=>{window.open(L,"_blank")}):window.open(L,"_blank")}i("external-jump",L)}function $(){if(d.value.length>0){const C=d.value.pop();C&&(s.value=C.blockId,o.value=C.title,r.value=C.isFocusMode,l.value=C.isDoc,m(C.blockId,C.isFocusMode))}}function E(C){const L=C.target;if(!L)return;const z=L.closest('[data-type="block-ref"]');if(z){const q=z.getAttribute("data-id");if(q&&q!==s.value){C.preventDefault(),C.stopPropagation(),d.value.push({blockId:s.value,title:o.value||s.value,isFocusMode:r.value,isDoc:l.value}),s.value=q,o.value=z.innerText.trim()||q,m(q);return}}const H=L.closest("a");if(H&&H.href&&H.href.startsWith("siyuan://blocks/")){C.preventDefault(),C.stopPropagation();const q=H.href.replace("siyuan://blocks/","").split("?")[0];q&&q!==s.value&&(d.value.push({blockId:s.value,title:o.value||s.value,isFocusMode:r.value,isDoc:l.value}),s.value=q,o.value=H.innerText.trim()||q,m(q))}}return(C,L)=>(X(),ee("div",tm,[p("div",im,[p("div",nm,[d.value.length>0?(X(),ee("button",{key:0,class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"返回上层引用文档或块",onClick:$},[ae(pe,{name:"arrow-left"}),L[0]||(L[0]=p("span",null,"返回",-1))])):Te("",!0),p("span",{class:$e(["spm-protyle-badge",{"is-focus":r.value&&!l.value}])},Ce(r.value&&!l.value?"思源块聚焦":"思源文档速览"),3),p("span",{class:"spm-protyle-id",title:o.value||s.value},Ce(o.value||s.value),9,sm)]),p("div",om,[l.value?Te("",!0):(X(),ee("button",{key:0,class:$e(["spm-icon-btn b3-tooltips b3-tooltips__s",{"is-primary":r.value}]),"aria-label":r.value?"当前为块聚焦模式（点击展开所属文档全文）":"当前为文档全文模式（点击切回仅聚焦当前块）",onClick:y},[ae(pe,{name:r.value?"focus":"file-text"},null,8,["name"]),p("span",null,Ce(r.value?"块聚焦":"展开全文"),1)],10,rm)),p("button",{class:$e(["spm-icon-btn b3-tooltips b3-tooltips__s",{"is-primary":a.value}]),"aria-label":a.value?"当前为即时编辑模式（点击切回只读）":"当前为只读速览模式（点击解锁即时编辑）",onClick:x},[ae(pe,{name:a.value?"edit":"eye"},null,8,["name"]),p("span",null,Ce(a.value?"编辑中":"只读"),1)],10,am),p("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"在置顶独立窗口中打开 (保留完整侧边栏与插件)",onClick:S},[ae(pe,{name:"window"}),L[1]||(L[1]=p("span",null,"独立窗口",-1))]),me(u).enableWebServeJump?(X(),ee("button",{key:1,class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"在系统默认浏览器中打开 (外跳)",onClick:w},[ae(pe,{name:"external-link"}),L[2]||(L[2]=p("span",null,"外跳",-1))])):Te("",!0)])]),p("div",{ref_key:"mountEl",ref:h,class:$e(["spm-protyle-mount",{"is-focus-mode":r.value&&!l.value}]),onClick:E},null,2)]))}}),cm=ei(lm,[["__scopeId","data-v-0d6e2df3"]]),dm=/^(https?|file|data|blob|mailto|tel|ftp|ftps|siyuan|about|chrome|ws|wss):/i,um=/\.(html?|xhtml|pdf|png|jpe?g|gif|svg|webp|avif|ico|mp4|webm|mov|mp3|wav|m4a|ogg|json|md|markdown|txt|csv|zip|tar|gz|7z|rar|js|mjs|css|xml|yaml|yml|toml|ipynb|docx?|xlsx?|pptx?)$/i;function sa(e){let t=e||"";try{t=decodeURIComponent(t)}catch{}t=t.replace(/\\/g,"/");const i=/(?:^|\/)data\/assets\/(.+)$/i.exec(t);if(i)return`/assets/${i[1]}`;const n=/(?:^|\/)data\/plugins\/(.+)$/i.exec(t);return n?`/plugins/${n[1]}`:null}function Hl(e){const t=(e||"").replace(/^file:\/\//i,"");let i=t;try{i=decodeURIComponent(t)}catch{}if(i.startsWith("/"))return/^\/([a-zA-Z]:[\\/])/.exec(i)?i.slice(1):i;const n=i.indexOf("/");return n>=0?i.slice(n):i}function fm(e){const t=e.split(/[/?#]/)[0];return!t||um.test(t)?!1:/^(localhost|\d{1,3}(\.\d{1,3}){3})(:\d+)?$/i.test(t)?!0:/^[a-z0-9-]+(\.[a-z0-9-]+)+(:\d+)?$/i.test(t)}function pm(e){const t=e.indexOf("#"),i=t>=0?e.slice(t):"",n=t>=0?e.slice(0,t):e,s=n.indexOf("?"),o=s>=0?n.slice(0,s):n,a=s>=0?n.slice(s+1):"";if(!/^\/?assets\/.+\.html?$/i.test(o))return e;const r=new URLSearchParams(a);return r.get("iframe")==="true"||r.get("download")==="true"?e:(r.set("iframe","true"),`${o}?${r.toString()}${i}`)}function Fl(e){const t=hm(e);return t.external||!t.url?t:{url:pm(t.url),external:!1}}function hm(e){const t=(e||"").trim();if(!t)return{url:"",external:!1};if(/^https?:\/\//i.test(t))return{url:t,external:!1};if(t.startsWith("//"))return{url:`https:${t}`,external:!1};if(/^(siyuan|data|blob|about):/i.test(t))return{url:t,external:!1};if(Ca(t))return{url:`/${_a(t)}`,external:!1};if(/^file:/i.test(t)){const n=sa(Hl(t));return n?{url:n,external:!1}:{url:t,external:!0}}if(/^[a-zA-Z]:[\\/]/.test(t)||t.startsWith("\\\\")){const n=sa(t);return n?{url:n,external:!1}:{url:t,external:!0}}return dm.test(t)?{url:t,external:!0}:fm(t)?{url:`https://${t}`,external:!1}:{url:`/${t.replace(/^(?:\.{1,2}\/)+/,"").replace(/^\/+/,"")}`,external:!1}}const mm={class:"spm-webview-drawer"},gm={class:"spm-webview-toolbar"},vm={class:"spm-webview-toolbar__nav"},bm=["disabled"],ym=["disabled"],km=["aria-label"],wm={class:"spm-webview-toolbar__address"},xm=["aria-label"],Sm={class:"spm-webview-toolbar__actions"},Cm=["aria-label"],_m={class:"spm-zoom-controller"},$m=["disabled"],Im=["disabled"],Mm={key:1,class:"spm-webview-fallback"},Tm=["src"],Em={key:2,class:"spm-load-error"},Am={class:"spm-load-error__code"},Bm={class:"spm-load-error__code-num"},Dm={class:"spm-load-error__url"},Lm={class:"spm-load-error__hint"},Pm={class:"spm-load-error__actions"},oa="Mozilla/5.0 (iPhone; CPU iPhone OS 17_4_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.4.1 Mobile/15E148 Safari/604.1",jl="siyuan-slides-peek-view-mode";let Wl="desktop";function Om(){if(typeof window<"u"&&window.localStorage)try{const e=window.localStorage.getItem(jl);if(e==="mobile"||e==="desktop")return e}catch{}return Wl}function Rm(e){if(Wl=e,typeof window<"u"&&window.localStorage)try{window.localStorage.setItem(jl,e)}catch{}}function Nm(e){switch((e||"").toUpperCase()){case"ERR_PROXY_CONNECTION_FAILED":return"无法连接到代理服务器：请在思源「设置 → 网络代理」中填写公司代理地址，或切换为「使用系统代理」。";case"ERR_TUNNEL_CONNECTION_FAILED":return"HTTPS 代理隧道建立失败：请将思源「网络代理」的类型设为 HTTPS 并确认地址正确。";case"ERR_MANDATORY_PROXY_CONFIGURATION_FAILED":return"强制代理配置获取失败：公司 PAC 脚本不可用，请在思源「网络代理」中改为手动填写代理地址。";case"ERR_NAME_NOT_RESOLVED":case"ERR_NAME_RESOLUTION_FAILED":return"域名解析失败：内网环境访问外网通常需要配置代理或 DNS。";case"ERR_INTERNET_DISCONNECTED":return"当前网络不可用：请检查网络连接。";case"ERR_CONNECTION_TIMED_OUT":case"ERR_TIMED_OUT":return"连接超时：该地址可能需要通过代理才能访问。";case"ERR_CONNECTION_REFUSED":return"连接被拒绝：目标服务未在监听，或思源本地内核尚未启动。";case"ERR_CERT_AUTHORITY_INVALID":case"ERR_CERT_COMMON_NAME_INVALID":case"ERR_CERT_DATE_INVALID":return"证书校验失败：若公司网络使用 TLS 拦截，需将根证书导入思源所用系统的证书库。";default:return"若处于公司内网，请优先检查思源「设置 → 网络代理」是否已配置为可用代理（支持「使用系统代理」）。"}}const zm=At({__name:"WebviewPeekDrawer",props:{url:{},title:{},visible:{type:Boolean,default:!0}},emits:["external-jump"],setup(e,{emit:t}){const i=t,n=e,s=ve(Rl()&&!pp()),o=ve(n.url),a=ve(n.url),r=n.url,l=ve(!1),c=ve(null),u=ve(!1),d=ve(!1),h=ve(1),f=ve(!1),v=ve(Om());let m=typeof navigator<"u"&&!navigator.userAgent.includes("iPhone")?navigator.userAgent:"";const b=xe(()=>v.value==="mobile"?oa:m||void 0),y=ve(null),x=ve(null);let S=null,w=null,$=null;Ui(()=>n.url,J=>{J&&J!==o.value&&(o.value=J,a.value=J,v.value==="mobile"&&H(!1),y.value&&typeof y.value.loadURL=="function"&&y.value.loadURL(J))}),Ui(()=>n.visible,J=>{if(J)ce(),v.value==="mobile"&&H(!1);else if(y.value)try{typeof y.value.stop=="function"&&y.value.stop()}catch{}}),gn(()=>{E(),x.value&&typeof ResizeObserver<"u"&&(S=new ResizeObserver(()=>{const J=y.value;if(J&&typeof J.invalidate=="function")try{J.invalidate()}catch{}}),S.observe(x.value)),w=J=>{var D;const he=J.message||((D=J.error)==null?void 0:D.message);if(typeof he=="string"&&he.includes("Invalid guestInstanceId"))return J.preventDefault(),J.stopImmediatePropagation(),!0},window.addEventListener("error",w,!0),$=J=>{const he=J.reason,D=typeof he=="string"?he:he==null?void 0:he.message;typeof D=="string"&&D.includes("Invalid guestInstanceId")&&J.preventDefault()},window.addEventListener("unhandledrejection",$)}),ir(()=>{if(C(),S&&(S.disconnect(),S=null),w&&(window.removeEventListener("error",w,!0),w=null),$&&(window.removeEventListener("unhandledrejection",$),$=null),y.value)try{typeof y.value.stop=="function"&&y.value.stop()}catch{}});function E(){const J=y.value;J&&(J.addEventListener("dom-ready",L),J.addEventListener("did-start-loading",q),J.addEventListener("did-stop-loading",k),J.addEventListener("did-navigate",U),J.addEventListener("did-navigate-in-page",F),J.addEventListener("new-window",M),J.addEventListener("did-fail-load",_),J.addEventListener("did-fail-provisional-load",_))}function C(){const J=y.value;if(J)try{J.removeEventListener("dom-ready",L),J.removeEventListener("did-start-loading",q),J.removeEventListener("did-stop-loading",k),J.removeEventListener("did-navigate",U),J.removeEventListener("did-navigate-in-page",F),J.removeEventListener("new-window",M),J.removeEventListener("did-fail-load",_),J.removeEventListener("did-fail-provisional-load",_)}catch{}}function L(){const J=y.value;if(J&&typeof J.getUserAgent=="function"&&!m)try{const he=J.getUserAgent();he&&!he.includes("iPhone")&&(m=he)}catch{}v.value==="mobile"&&H(!1),ce(),B()}function z(){const J=v.value==="mobile"?"desktop":"mobile";v.value=J,Rm(J),H(!0)}function H(J=!1){const he=y.value;if(!he)return;const D=v.value==="mobile"?oa:m;if(typeof he.setUserAgent=="function"&&D)try{he.setUserAgent(D)}catch(W){console.warn("[WebviewPeekDrawer] setUserAgent error:",W)}if(J&&typeof he.reload=="function")try{he.reload()}catch(W){console.warn("[WebviewPeekDrawer] reload error:",W)}}function q(){l.value=!0,c.value=null}function _(J){if(J&&J.isMainFrame===!1||J&&Number(J.errorCode)===-3)return;const he=String((J==null?void 0:J.errorDescription)||"ERR_FAILED");c.value={errorCode:Number((J==null?void 0:J.errorCode)??0),description:he,validatedURL:String((J==null?void 0:J.validatedURL)||o.value),hint:Nm(he)},l.value=!1}function N(){c.value=null,G()}function k(){if(l.value=!1,B(),y.value&&typeof y.value.getURL=="function"){const J=y.value.getURL();J&&J!=="about:blank"&&(o.value=J,a.value=J)}}function U(J){J!=null&&J.url&&(o.value=J.url,a.value=J.url),B()}function F(J){J!=null&&J.url&&(o.value=J.url,a.value=J.url),B()}function M(J){J&&J.url&&(J.preventDefault(),y.value&&typeof y.value.loadURL=="function"&&y.value.loadURL(J.url))}function B(){const J=y.value;J&&(typeof J.canGoBack=="function"&&(u.value=J.canGoBack()),typeof J.canGoForward=="function"&&(d.value=J.canGoForward()))}function P(){y.value&&typeof y.value.goBack=="function"&&y.value.goBack()}function se(){y.value&&typeof y.value.goForward=="function"&&y.value.goForward()}function G(){y.value&&typeof y.value.reload=="function"&&y.value.reload()}function K(){const J=Fl(a.value);if(J.url){if(J.external){o.value=J.url,le();return}o.value=J.url,a.value=J.url,y.value&&typeof y.value.loadURL=="function"&&y.value.loadURL(J.url)}}function ce(){const J=y.value;if(J&&typeof J.setZoomFactor=="function")try{J.setZoomFactor(h.value)}catch(he){console.warn("[WebviewPeekDrawer] setZoomFactor error:",he)}}function ie(){h.value=Math.min(2.5,Math.round((h.value+.1)*10)/10),ce()}function oe(){h.value=Math.max(.5,Math.round((h.value-.1)*10)/10),ce()}function re(){h.value=1,ce()}function be(J){J.preventDefault(),J.deltaY<0?ie():J.deltaY>0&&oe()}async function ke(){if(typeof navigator<"u"&&navigator.clipboard)try{await navigator.clipboard.writeText(o.value),f.value=!0,setTimeout(()=>{f.value=!1},2e3)}catch(J){console.warn("Copy url failed:",J)}}function le(){var he;const J=o.value;if(typeof window<"u"){const D=Mt("electron");(he=D==null?void 0:D.shell)!=null&&he.openExternal?D.shell.openExternal(J).catch(()=>{window.open(J,"_blank")}):window.open(J,"_blank")}i("external-jump",J)}return(J,he)=>{const D=wu("webview");return X(),ee("div",mm,[p("div",gm,[p("div",vm,[p("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s",disabled:!u.value,"aria-label":"后退",onClick:P},[ae(pe,{name:"arrow-left"})],8,bm),p("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s",disabled:!d.value,"aria-label":"前进",onClick:se},[ae(pe,{name:"arrow-right"})],8,ym),p("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":l.value?"正在加载...":"刷新页面",onClick:G},[ae(pe,{name:"refresh"})],8,km)]),p("div",wm,[Pt(p("input",{"onUpdate:modelValue":he[0]||(he[0]=W=>a.value=W),type:"text",class:"b3-text-field spm-url-input",placeholder:"https://...",spellcheck:"false",onKeydown:Rf(K,["enter"])},null,544),[[Lo,a.value]]),p("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":f.value?"已复制地址！":"复制网址",onClick:ke},[ae(pe,{name:"copy"})],8,xm)]),p("div",Sm,[p("button",{class:$e(["spm-icon-btn spm-mode-toggle b3-tooltips b3-tooltips__s",{"is-active":v.value==="mobile"}]),"aria-label":v.value==="mobile"?"当前为手机视图，点击切换为桌面视图":"当前为桌面视图，点击切换为手机视图",onClick:z},[ae(pe,{name:v.value==="mobile"?"mobile":"desktop"},null,8,["name"])],10,Cm),p("div",_m,[p("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"缩小 (Ctrl + -)",disabled:h.value<=.5,onClick:oe},[ae(pe,{name:"minus"})],8,$m),p("button",{class:"spm-zoom-badge b3-tooltips b3-tooltips__s","aria-label":"重置 100% (Ctrl + 0)",onClick:re},Ce(Math.round(h.value*100))+"% ",1),p("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"放大 (Ctrl + +)",disabled:h.value>=2.5,onClick:ie},[ae(pe,{name:"plus"})],8,Im)]),p("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"在系统默认浏览器中打开 ↗",onClick:le},[ae(pe,{name:"external-link"}),he[1]||(he[1]=p("span",null,"外跳",-1))])])]),p("div",{ref_key:"containerEl",ref:x,class:$e(["spm-webview-body",{"is-mobile":v.value==="mobile"}]),onWheel:Yt(be,["ctrl"])},[p("div",{class:$e(["spm-webview-viewport",{"is-mobile":v.value==="mobile"}])},[s.value?(X(),Zt(D,{key:0,ref_key:"webviewRef",ref:y,class:"spm-webview-frame",src:me(r),useragent:b.value,allowpopups:"true",style:{position:"absolute",top:"0",left:"0",width:"100%",height:"100%",display:"inline-flex"}},null,8,["src","useragent"])):(X(),ee("div",Mm,[p("iframe",{class:"spm-webview-fallback-frame",src:o.value,frameborder:"0",sandbox:"allow-scripts allow-same-origin allow-forms allow-popups"},null,8,Tm),p("div",{class:"spm-fallback-bar"},[he[2]||(he[2]=p("span",null,"如页面受同源策略 (X-Frame-Options) 拦截无法显示，请",-1)),p("button",{class:"spm-icon-btn is-primary",onClick:le}," 在新标签页中打开 ↗ ")])])),c.value?(X(),ee("div",Em,[ae(pe,{name:"alert",class:"spm-load-error__icon"}),he[5]||(he[5]=p("div",{class:"spm-load-error__title"},"页面加载失败",-1)),p("div",Am,[_t(Ce(c.value.description)+" ",1),p("span",Bm,"("+Ce(c.value.errorCode)+")",1)]),p("div",Dm,Ce(c.value.validatedURL),1),p("p",Lm,Ce(c.value.hint),1),p("div",Pm,[p("button",{class:"spm-icon-btn","aria-label":"重试",onClick:N},[ae(pe,{name:"refresh"}),he[3]||(he[3]=p("span",null,"重试",-1))]),p("button",{class:"spm-icon-btn is-primary","aria-label":"用系统浏览器打开",onClick:le},[ae(pe,{name:"external-link"}),he[4]||(he[4]=p("span",null,"用系统浏览器打开 ↗",-1))])])])):Te("",!0)],2)],34)])}}}),Hm=ei(zm,[["__scopeId","data-v-6e363f73"]]);class Fm{constructor(){ye(this,"timers",new Map)}debounce(t,i,n=150){this.cancel(t);const s=setTimeout(()=>{this.timers.delete(t),i()},n);this.timers.set(t,s)}cancel(t){this.timers.has(t)&&(clearTimeout(this.timers.get(t)),this.timers.delete(t))}cancelAll(){for(const t of this.timers.values())clearTimeout(t);this.timers.clear()}hasPending(t){return this.timers.has(t)}}class jm{constructor(t){ye(this,"blockToPageMap",new Map);ye(this,"debounceCtrl",new Fm);ye(this,"activeBlockId","");ye(this,"activePageIndex",1);ye(this,"currentDocId","");ye(this,"bridge",null);t&&(this.bridge=t)}setBridge(t){this.bridge=t}setDocId(t){this.currentDocId=t}updateSlidesIndex(t){this.blockToPageMap.clear();for(const i of t){i.startBlockId&&this.blockToPageMap.set(i.startBlockId,i.pageIndex);for(const n of i.blocks)this.blockToPageMap.set(n.id,i.pageIndex)}}getPageByBlockId(t){return this.blockToPageMap.get(t)??null}onCursorFocusBlock(t){if(!t||t===this.activeBlockId)return;this.activeBlockId=t;let i=this.getPageByBlockId(t);!i&&(t===this.currentDocId||!this.currentDocId&&this.blockToPageMap.size>0)&&(i=1),i&&this.debounceCtrl.debounce("cursor-navigate",()=>{this.activePageIndex=i,this.bridge&&(this.bridge.navigatePage(i),this.bridge.highlightElement(t))},100)}getActiveBlockId(){return this.activeBlockId}setActiveBlockId(t){this.activeBlockId=t,t||this.debounceCtrl.cancel("cursor-navigate");const i=this.getPageByBlockId(t);i&&(this.activePageIndex=i)}getActivePageIndex(){return this.activePageIndex}destroy(){this.debounceCtrl.cancelAll(),this.blockToPageMap.clear(),this.bridge=null}}let Tt=null,hs=null,ms="";function On(){var e,t;if(hs&&(clearTimeout(hs),hs=null),Tt){try{Tt.classList.remove("protyle-wysiwyg--select"),ms?Tt.style.outline=ms:typeof((e=Tt.style)==null?void 0:e.removeProperty)=="function"?Tt.style.removeProperty("outline"):Tt.style&&(Tt.style.outline=""),typeof((t=Tt.style)==null?void 0:t.removeProperty)=="function"?Tt.style.removeProperty("transition"):Tt.style&&(Tt.style.transition="")}catch(i){console.warn("[SelectionMirror] clear activeHighlightEl failed:",i)}Tt=null,ms=""}if(typeof document<"u"&&typeof document.querySelectorAll=="function")try{document.querySelectorAll(".protyle-wysiwyg [data-node-id].protyle-wysiwyg--select, .protyle-wysiwyg [data-node-id][style*='outline']").forEach(n=>{var o,a;n.classList.remove("protyle-wysiwyg--select");const s=((o=n.style)==null?void 0:o.outline)||"";(s.includes("#3b82f6")||s.includes("rgb(59, 130, 246)")||s.includes("59, 130, 246"))&&(typeof((a=n.style)==null?void 0:a.removeProperty)=="function"?(n.style.removeProperty("outline"),n.style.removeProperty("transition")):n.style&&(n.style.outline="",n.style.transition=""))})}catch{}}function Vi(e,t){var a,r,l,c;if(!e||typeof document>"u")return On(),!1;On();const i=(a=globalThis.CSS)!=null&&a.escape?globalThis.CSS.escape(e):e.replace(/"/g,'\\"'),n=document.querySelector(`.protyle-wysiwyg [data-node-id="${i}"]`)||document.querySelector(`[data-node-id="${i}"]`);if(!n){if(t)try{return ue.openTab({app:t,doc:{id:e,action:["cb-get-hl","cb-get-focus","cb-get-context"]}}),!0}catch(u){console.warn("[SelectionMirror] openTab fallback failed:",u)}return!1}try{n.scrollIntoView({behavior:"smooth",block:"center",inline:"nearest"})}catch{(r=n.scrollIntoView)==null||r.call(n)}try{(l=n.focus)==null||l.call(n,{preventScroll:!0})}catch{}const s=((c=n.style)==null?void 0:c.outline)||"";return ms=s.includes("#3b82f6")||s.includes("rgb(59, 130, 246)")||s.includes("59, 130, 246")?"":s,n.classList.add("protyle-wysiwyg--select"),n.style&&(n.style.outline="2px solid #3b82f6",n.style.transition="outline 0.2s ease"),Tt=n,hs=setTimeout(()=>{On()},500),!0}function Wm(e){if(!e)return"";const t=e.split(`
`).map(a=>a.trim()).filter(Boolean);if(t.length===0)return"";if(!t.some(a=>/^#{1,6}\s+/.test(a)))return t.map(a=>lt(a)).join("<br/>");const n=[];let s=[];const o=()=>{if(s.length>0){const a=s.map(r=>lt(r)).join("<br/>");n.push(`<p class="slide-list-item-desc">${a}</p>`),s=[]}};for(const a of t){const r=a.match(/^(#{1,6})\s+(.*)$/);if(r){o();const l=r[1].length,c=r[2].trim();n.push(`<h${l} class="slide-list-item-title">${lt(c)}</h${l}>`)}else s.push(a)}return o(),n.join(`
`)}function Um(e){if(e.length===0)return"";const t=[],i=e[0],n=i.match(/^(#{1,6})\s+(.*)$/);if(n){const s=n[1].length,o=n[2].trim();t.push(`<h${s} class="slide-list-item-title">${lt(o)}</h${s}>`)}else t.push(`<p class="slide-list-item-title">${lt(i)}</p>`);if(e.length>1){const s=e.slice(1);let o=[];const a=()=>{if(o.length>0){const r=o.map(l=>lt(l)).join("<br/>");t.push(`<p class="slide-list-item-desc">${r}</p>`),o=[]}};for(const r of s){const l=r.match(/^(#{1,6})\s+(.*)$/);if(l){a();const c=l[1].length,u=l[2].trim();t.push(`<h${c} class="slide-list-item-title">${lt(u)}</h${c}>`)}else o.push(r)}a()}return t.join(`
`)+(t.length>0?`
`:"")}function Ul(e,t,i){var h,f,v,m;const n=e.split(`
`);if(!n.some(b=>/^(\s*)([-*+]|\d+\.)\s+/.test(b)))return null;const o=[],a=[];let r=!1;for(let b=0;b<n.length;b++){const y=n[b];if(!y.trim())continue;const x=y.match(/^(\s*)[-*+]\s+\[([ xX])\]\s+(.*)$/);if(x){const E=x[1].length,C=Math.floor(E/2);a.push({type:"task",level:C,checked:x[2].toLowerCase()==="x",text:x[3],media:[]});continue}const S=y.match(/^(\s*)[-*+]\s+(.*)$/);if(S){const E=S[1].length,C=Math.floor(E/2);a.push({type:"unordered",level:C,text:S[2],media:[]});continue}const w=y.match(/^(\s*)\d+\.\s+(.*)$/);if(w){a.length===0&&(r=!0);const E=w[1].length,C=Math.floor(E/2);a.push({type:"ordered",level:C,text:w[2],media:[]});continue}const $=y.trim();if(!(!$||/^\{:.*?\}$/.test($)))if(a.length>0){const E=$.match(/^!\[(.*?)\]\((.*?)\)(?:\{:?[^}]*\})?$/);if(E){const z=/\.gif(?:\?|$)/i.test(E[2])?"list-item-gif":"list-item-img";a[a.length-1].media||(a[a.length-1].media=[]),a[a.length-1].media.push(`<div class="slide-list-media"><img alt="${rt(E[1])}" src="${E[2]}" class="${z}" /></div>`);continue}if($.match(/^<img\b[\s\S]*?\/?>$/i)){const L=$.replace(/\s+style="[^"]*"/gi,"");a[a.length-1].media||(a[a.length-1].media=[]),a[a.length-1].media.push(`<div class="slide-list-media">${L}</div>`);continue}if(/<video\b/i.test($)){let L=$;if(!/<\/video>/i.test(L))for(;b+1<n.length&&!/<\/video>/i.test(L);)b++,L+=" "+n[b].trim();const z=((h=i==null?void 0:i.attributes)==null?void 0:h["custom-slides-autoplay"])==="true"||/autoplay/i.test(L),H=((f=i==null?void 0:i.attributes)==null?void 0:f["custom-slides-loop"])==="true"||/loop/i.test(L),q=((v=i==null?void 0:i.attributes)==null?void 0:v["custom-slides-muted"])==="true"||z||/muted/i.test(L),_=((m=i==null?void 0:i.attributes)==null?void 0:m["custom-slides-controls"])==="false",N=L.match(/\bsrc=["']([^"']+)["']/i),k=N?N[1]:"",U=['class="slide-video-player"'];_||U.push("controls"),z&&(U.push("autoplay"),U.push("playsinline")),H&&U.push("loop"),q&&U.push("muted"),U.push('preload="metadata"'),k&&U.push(`src="${k}"`);const F=L.match(/<video[^>]*>([\s\S]*?)<\/video>/i);let M=F?F[1].trim():"";!M&&k&&(M=`<source src="${k}" type="video/mp4" />您的浏览器不支持视频播放。`),a[a.length-1].media||(a[a.length-1].media=[]),a[a.length-1].media.push(`<div class="slide-list-media slide-video-container slide-media-container" data-autoplay="${z?"true":"false"}" data-muted="${q?"true":"false"}"><video ${U.join(" ")}>${M}</video></div>`);continue}a[a.length-1].text+=`
`+$}else o.push($)}if(a.length===0)return null;const l=r?"ol":"ul",c=(t==null?void 0:t.listClassName)||(r?"pdf-list pdf-list--ordered":"pdf-list pdf-list--unordered"),u=a.map(b=>{const y=Wm(b.text),x=b.media&&b.media.length>0?`
${b.media.join(`
`)}`:"",S=b.level||0,w=S>0?` style="margin-left:${(S*1.25).toFixed(2)}em;${b.type==="unordered"?`list-style-type:${S%2===1?"circle":"square"} !important;`:""}"`:"",$=S>0?" slide-list-item--nested":"";if(b.type==="task"){const C=b.checked?' checked=""':"";return`<li class="pdf-task-item${$}"${w}><label><input type="checkbox" disabled=""${C}/> <span>${y}</span></label>${x}</li>`}return`<li${$?` class="${$.trim()}"`:""}${w}>${y}${x}</li>`}).join(`
`);return`${Um(o)}<${l} class="${c}">
${u}
</${l}>`}function Vm(e,t,i){const n=(t==null?void 0:t.containerClassName)||"pdf-block",s=e.split(/\r?\n/),o=[];let a=[];for(let c=0;c<s.length;c++){const u=s[c],d=u.trim();if(/^#{1,6}\s+/.test(d)){a.length>0&&(o.push(a.join(`
`)),a=[]),o.push(d);continue}if(!d){a.length>0&&(o.push(a.join(`
`)),a=[]);continue}if(/^!\[.*?\]\(.*?\)$/.test(d)){a.length>0&&(o.push(a.join(`
`)),a=[]),o.push(d);continue}if(/<video\b/i.test(d)){a.length>0&&(o.push(a.join(`
`)),a=[]);let h=d;if(!/<\/video>/i.test(h))for(;c+1<s.length&&!/<\/video>/i.test(h);)c++,h+=`
`+s[c];o.push(h);continue}a.push(u)}a.length>0&&o.push(a.join(`
`));let r=!0;return o.map(c=>{var v,m,b,y;const u=c.trim();if(!u)return"";const d=u.match(/^(#{1,6})\s+(.*)$/);if(d){r=!1;const x=d[1].length;return`<h${x} class="slide-list-item-title">${lt(d[2].trim())}</h${x}>`}const h=u.match(/^!\[(.*?)\]\((.*?)\)$/);if(h){const x=/\.gif(?:\?|$)/i.test(h[2]),S=(t==null?void 0:t.imageClassName)||(x?"list-item-gif":"pdf-image slide-media-img");return`<div class="${n} ${n}--image slide-media-block slide-media-container slide-list-media"><img alt="${rt(h[1])}" src="${h[2]}" class="${S}" /></div>`}if(/<video\b/i.test(u)){const x=((v=i==null?void 0:i.attributes)==null?void 0:v["custom-slides-autoplay"])==="true"||/autoplay/i.test(u),S=((m=i==null?void 0:i.attributes)==null?void 0:m["custom-slides-loop"])==="true"||/loop/i.test(u),w=((b=i==null?void 0:i.attributes)==null?void 0:b["custom-slides-muted"])==="true"||x||/muted/i.test(u),$=((y=i==null?void 0:i.attributes)==null?void 0:y["custom-slides-controls"])==="false",E=u.match(/\bsrc=["']([^"']+)["']/i),C=E?E[1]:"",L=['class="slide-video-player"'];$||L.push("controls"),x&&L.push("autoplay playsinline"),S&&L.push("loop"),w&&L.push("muted"),L.push('preload="metadata"'),C&&L.push(`src="${C}"`);const z=u.match(/<video[^>]*>([\s\S]*?)<\/video>/i);let H=z?z[1].trim():"";return!H&&C&&(H=`<source src="${C}" type="video/mp4" />您的浏览器不支持视频播放。`),`<div class="${n} ${n}--video slide-media-block slide-video-container slide-media-container" data-autoplay="${x?"true":"false"}" data-muted="${w?"true":"false"}"><video ${L.join(" ")}>${H}</video></div>`}const f=Ul(u,t,i);if(f)return r=!1,f;if(r){r=!1;const x=u.split(/\r?\n/).map(E=>E.trim()).filter(Boolean);if(x.length===1)return`<p class="slide-list-item-title">${lt(x[0])}</p>`;const S=x[0],$=x.slice(1).map(E=>lt(E)).join("<br/>");return`<p class="slide-list-item-title">${lt(S)}</p>
<p class="slide-list-item-desc">${$}</p>`}return`<p class="slide-list-item-desc">${lt(u)}</p>`}).filter(Boolean).join(`
`)}function fo(e){if(!e)return!1;if(e.type==="h"||e.type==="NodeHeading")return!0;const t=(e.rawMarkdown||e.content||"").trim();return/^#{1,6}\s+/.test(t)}function Vl(e,t){var r,l,c,u,d,h,f,v;const i=((r=e.frontmatter)==null?void 0:r.layout)||"default",s=(e.blocks||[]).filter(m=>m.slot!=="slot-divider-right"),a=i==="cover"?null:s.find(fo);if(i==="two-cols"){const m=s.some(q=>q.slot==="right");let b=[],y=[];if(m)b=s.filter(q=>q.slot!=="right"),y=s.filter(q=>q.slot==="right");else{const q=Math.ceil(s.length/2);b=s.slice(0,q),y=s.slice(q)}const x=q=>{const _=q.filter(N=>!!(N.rawMarkdown||N.content||"").trim());if(_.length>0){const N=_[0],k=(N.rawMarkdown||N.content||"").trim();(Mi(N)||/^(?:[-*+]|\d+\.)\s+/.test(k))&&(N.rawMarkdown=Dn(N.rawMarkdown||N.content||""),N.content=N.rawMarkdown)}};x(b),x(y);const S=b.map(q=>yi(q,t)).join(`
`),w=y.map(q=>yi(q,t)).join(`
`),$=(t==null?void 0:t.twoColsWrapperClass)||"pdf-two-cols-wrapper layout-two-cols-grid",E=(l=e.frontmatter)!=null&&l.layoutClass?` ${e.frontmatter.layoutClass}`:"",C=(t==null?void 0:t.leftColClass)||"pdf-col pdf-col--left",L=(t==null?void 0:t.rightColClass)||"pdf-col pdf-col--right",H=`style="grid-template-columns: ${co((c=e.frontmatter)==null?void 0:c.layoutRatio,2)};"`;return`
      <div class="${$}${E}" ${H}>
        <div class="${C}">${S}</div>
        <div class="${L}">${w}</div>
      </div>
    `}if(i==="clover"||sn(i)){const m=i==="clover";let b=[];const y=s.filter(U=>U.slot==="header");if(y.length>0)b=y;else if(s.length>0){const U=s.find(F=>F.type==="h"&&(!F.slot||F.slot==="default"));U&&(b=[U])}const x=s.filter(U=>!b.includes(U));let S=2;if(m)S=4;else if(i==="three-cols-header")S=3;else if(i==="two-cols-header")S=2;else{let U=0;for(const F of x){const M=(F.slot||"").match(/^col-(\d+)$/i);M&&(U=Math.max(U,parseInt(M[1],10)))}if(U>=2)S=U;else if((u=e.frontmatter)!=null&&u.layoutRatio){const F=e.frontmatter.layoutRatio.trim();if(F.includes(":")){const M=F.split(":").map(B=>parseFloat(B.trim())).filter(B=>!isNaN(B)&&B>0);M.length>=2&&(S=M.length)}else{const M=F.split(/\s+/).filter(Boolean);M.length>=2&&(S=M.length)}}else x.length===1&&x[0].children&&x[0].children.length>=2&&(S=Math.min(6,x[0].children.length))}const w=Ol(x,S),$=x.some(U=>U.slot&&/^(?:col-\d+|left|right)$/i.test(U.slot)),E=i==="clover"||i==="two-cols-header"||i==="three-cols-header"||sn(i)&&$,C=U=>{const F=U.filter(B=>!!(B.rawMarkdown||B.content||"").trim());if(E&&F.length>0){const B=F[0],P=(B.rawMarkdown||B.content||"").trim();(Mi(B)||/^(?:[-*+]|\d+\.)\s+/.test(P))&&(B.rawMarkdown=Dn(B.rawMarkdown||B.content||""),B.content=B.rawMarkdown),B.isColFirst=!0}const M=E?F.find(fo):null;return F.map(B=>yi(B,{...t,extraClassName:B===M?"slides-col-first-heading-block":""})).join(`
`)},L=b.find(fo),z=b.map(U=>yi(U,{...t,extraClassName:U===L?"slides-page-first-heading-block":""})).join(`
`),H=m?"repeat(2, minmax(0, 1fr))":co((d=e.frontmatter)==null?void 0:d.layoutRatio,S),q=m?`style="grid-template-columns: ${H}; grid-template-rows: repeat(2, minmax(0, 1fr));"`:`style="grid-template-columns: ${H};"`,_=[m?"layout-clover-container":"layout-cols-header-container",S===2?"layout-two-cols-header-container":"",S===3?"layout-three-cols-header-container":"",`layout-${i}-container`,E?"has-superblock-cols":""].filter(Boolean).join(" "),N=[m?"layout-clover-grid pdf-clover-wrapper":"layout-cols-wrapper layout-cols-grid",S===2?"pdf-two-cols-wrapper layout-two-cols-grid":"",S===3?"pdf-three-cols-wrapper layout-three-cols-grid":"",E?"has-superblock-cols":""].filter(Boolean).join(" "),k=w.map((U,F)=>{const M=F+1;return`<div class="${["pdf-col",S===2&&M===1?"pdf-col--left":"",S===2&&M===2?"pdf-col--right":"",`pdf-col--${M}`,`col-${M}`].filter(Boolean).join(" ")}">${C(U)}</div>`}).join(`
`);return`
      <div class="${_}">
        <div class="layout-header-section">${z}</div>
        <div class="${N}" ${q}>
          ${k}
        </div>
      </div>
    `}if(i==="image-right"||i==="image-left"){const m=i==="image-right",b=s.map(E=>yi(E,t)).join(`
`),y=((h=e.frontmatter)==null?void 0:h.image)||((f=e.frontmatter)==null?void 0:f.background)||"",x=`<div class="pdf-image-col" style="background-image:url('${rt(y)}');background-size:cover;background-position:center;background-repeat:no-repeat;width:100%;height:100%;position:relative;overflow:hidden;"><img src="${rt(y)}" style="width:100%;height:100%;object-fit:cover;object-position:center;display:block;" onerror="this.style.display='none'" alt="Slide cover" /></div>`,S=`<div class="pdf-content-col" style="padding:48px 56px;display:flex;flex-direction:column;justify-content:flex-start;height:100%;box-sizing:border-box;overflow-y:auto;">${b}</div>`,w=m?`${S}
${x}`:`${x}
${S}`;return`
      <div class="layout-image-cols-grid" style="display:grid;grid-template-columns:${co((v=e.frontmatter)==null?void 0:v.layoutRatio,2)};grid-template-rows:100%;width:100%;height:100%;position:absolute;top:0;left:0;right:0;bottom:0;box-sizing:border-box;">
        ${w}
      </div>
    `}return i==="fact"?`<div class="layout-fact-container">${s.map(b=>yi(b,t)).join(`
`)}</div>`:i==="cover"?`<div class="layout-cover-container">${s.map(b=>yi(b,t)).join(`
`)}</div>`:s.map(m=>yi(m,{...t,extraClassName:m===a?"slides-page-first-heading-block":""})).join(`
`)}function rt(e){return e?e.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&#039;"):""}function Gm(e){if(!e||e.trim()===""||e.trim()==="all")return"all";const t=new Set,i=e.split("|");for(const n of i){const s=n.trim();if(s==="all")return"all";if(s.includes("-")){const[o,a]=s.split("-"),r=parseInt(o,10),l=parseInt(a,10);if(!isNaN(r)&&!isNaN(l))for(let c=Math.min(r,l);c<=Math.max(r,l);c++)t.add(c)}else{const o=parseInt(s,10);isNaN(o)||t.add(o)}}return t}const Km=new Set(["kbd","mark","sub","sup","span","a","br","b","i","u","s","del","em","strong","code","small","abbr","ruby","rt","rp","v-mark","img","video","source","picture"]);function lt(e){if(!e)return"";const t=Ll(e),i=[],n=t.replace(/<\/?([a-zA-Z0-9_-]+)(?:\s+[^<>]*)?\/?>/g,(o,a)=>{const r=a.toLowerCase();if(!Km.has(r)||/on\w+\s*=|javascript:/i.test(o))return o;if(r==="v-mark"){const l=o.match(/type=["']?([a-zA-Z-]+)["']?/),c=l?l[1]:"circle";return o.startsWith("</")?i.push("</mark>"):i.push(`<mark class="v-mark v-mark--${c}">`),`%%SAFE_HTML_${i.length-1}%%`}return i.push(o),`%%SAFE_HTML_${i.length-1}%%`});let s=rt(n);return s=s.replace(/\(\(([0-9a-zA-Z-]+)(?:\s*(?:&#039;([^&#]*)&#039;|&quot;([^&]*)&quot;|'([^']*)'|"([^"]*)"|([^\)]+?)))?\s*\)\)/g,(o,a,r,l,c,u,d)=>{const f=(r??l??c??u??d??"").trim()||`Ref(${a.slice(0,8)})`;return`<a href="siyuan://blocks/${a}" data-ref-id="${a}" class="slides-ref-tag">🔗 ${f}</a>`}),s=s.replace(/\$([^$\n]+)\$/g,'<span class="katex-inline font-math"><em>$1</em></span>'),s=s.replace(/!\[(.*?)\]\((.*?)\)/g,(o,a,r)=>{const c=/\.gif(?:\?|$)/i.test(r)?"slide-inline-img list-item-gif":"slide-inline-img";return`<img alt="${a}" src="${r}" class="${c}" />`}),s=s.replace(/\[(.*?)\]\((.*?)\)/g,(o,a,r)=>{if(r.startsWith("siyuan://blocks/")){const l=r.replace("siyuan://blocks/","").split("?")[0];return`<a href="${r}" data-ref-id="${l}" class="slides-ref-tag">🔗 ${a}</a>`}return`<a href="${r}" target="_blank" rel="noopener noreferrer" class="slides-link">${a}</a>`}),s=s.replace(/(^|[\s(])(siyuan:\/\/blocks\/([0-9a-zA-Z-]+)(?:\?[^\s\)]*)?)/g,(o,a,r,l)=>`${a}<a href="${r}" data-ref-id="${l}" class="slides-ref-tag">🔗 ${r}</a>`),s=s.replace(/\*\*(.*?)\*\*/g,"<strong>$1</strong>"),s=s.replace(/\*(.*?)\*/g,"<em>$1</em>"),s=s.replace(/~~(.*?)~~/g,"<del>$1</del>"),s=s.replace(/`([^`]+)`/g,"<code>$1</code>"),s=s.replace(/%%SAFE_HTML_(\d+)%%/g,(o,a)=>{const r=parseInt(a,10);return i[r]||""}),s}function qm(e,t="pdf-table"){if(e.length<2)return"";const i=e.map(l=>l.trim().replace(/^\|/,"").replace(/\|$/,"").split("|").map(c=>c.trim())),n=i[0];let s=[],o=1;e.length>=2&&i[1].every(l=>/^:?-+:?$/.test(l))&&(s=i[1].map(l=>l.startsWith(":")&&l.endsWith(":")?"center":l.endsWith(":")?"right":"left"),o=2);const a=`<thead><tr>${n.map((l,c)=>`<th${s[c]?` style="text-align: ${s[c]}"`:""}>${lt(l)}</th>`).join("")}</tr></thead>`,r=i.slice(o).map(l=>`<tr>${l.map((c,u)=>`<td${s[u]?` style="text-align: ${s[u]}"`:""}>${lt(c)}</td>`).join("")}</tr>`).join("");return`<table class="${t}">${a}<tbody>${r}</tbody></table>`}function po(e){return String(e||"").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;")}function ra(e,t="ts"){if(!e)return"";if(e.trim().startsWith("//"))return`<span class="token-comment">${po(e)}</span>`;const i=[];function n(o,a){return i.push(`<span class="${o}">${po(a)}</span>`),`__TOK_${i.length-1}__`}let s=e.replace(/(['"`])(.*?)\1/g,(o,a,r)=>n("token-string",`${a}${r}${a}`));return s=s.replace(/\b(import|export|from|const|let|var|function|return|default|type|interface|class|new|async|await)\b/g,o=>n("token-keyword",o)),s=s.replace(/\b(computed|ref|number|string|boolean|void|Array)\b/g,o=>n("token-type",o)),s=s.replace(/\b(\d+)\b/g,o=>n("token-number",o)),s=po(s),s=s.replace(/__TOK_(\d+)__/g,(o,a)=>i[parseInt(a,10)]||""),s}function Ym(e,t){if(!e)return null;const i=e.frontmatter||{};if(i.hideInToc===!0||i.hideInToc==="true")return null;let n=(i.title||"").trim(),s=i.level?parseInt(i.level,10):0;if(!n){const o=e.blocks||[];for(const a of o){const l=(a.rawMarkdown||a.content||"").trim().match(/^(#{1,6})\s+(.*)$/);if(l){s||(s=l[1].length),n=l[2].trim();break}}}return n?((!s||isNaN(s))&&(s=1),{pageIndex:e.pageIndex||t,title:n,level:s}):null}function Zm(e,t=1,i={}){const n=i.minDepth!==void 0?Number(i.minDepth):1,s=i.maxDepth!==void 0?Number(i.maxDepth):1/0,o=[];Array.isArray(e)&&e.forEach((c,u)=>{const d=Ym(c,u+1);d&&o.push(d)});const a=[];let r=null;for(const c of o){const u={...c,active:c.pageIndex===t,hasActiveChild:!1,children:[]};c.level===1||a.length===0?(a.push(u),r=u):r?(u.active&&(r.hasActiveChild=!0),r.children.push(u)):a.push(u)}function l(c,u=1){if(u>s)return[];const d=[];for(const h of c){const f=l(h.children,u+1);u>=n?d.push({...h,children:f}):d.push(...f)}return d}return l(a,1)}function Jm(e,t=1,i={}){const n=Zm(e,t,i),s=i.columns?Number(i.columns):1,o=s>1?` style="column-count: ${s};"`:"",a=i.textSm?" text-sm":"";function r(c,u=1){if(!c||c.length===0)return"";const d=`slides-toc-list slides-toc-list-level-${u}`,h=c.map(f=>{const v=f.active?" slides-toc-item-active":f.hasActiveChild?" slides-toc-item-parent-active":"",m=f.children&&f.children.length>0?r(f.children,u+1):"";let b=lt(f.title);return b.includes("LaTeX")&&(b=b.replace(/\$\\LaTeX\$/g,'<span class="font-math">L<sup>A</sup>T<sub>E</sub>X</span>')),`
        <li class="slides-toc-item${v}" data-page="${f.pageIndex}">
          <a class="slides-toc-link" href="javascript:void(0)">
            <span class="slides-toc-title">${b}</span>
          </a>
          ${m}
        </li>
      `}).join("");return`<ol class="${d}">${h}</ol>`}const l=r(n,1);return`<div class="slides-toc${a}"${o}>${l}</div>`}function yi(e,t){var $,E,C,L,z,H,q,_,N,k,U,F;let i="",n="",s="";const o=[];($=e.motion)!=null&&$.preset&&e.motion.preset!=="none"&&(i=` slides-motion-${e.motion.preset.toLowerCase()}`,typeof e.motion.duration=="number"&&e.motion.duration>0&&o.push(`--motion-duration:${e.motion.duration}ms`),typeof e.motion.delay=="number"&&e.motion.delay>0&&o.push(`--motion-delay:${e.motion.delay}ms`));const a=((E=e.attributes)==null?void 0:E.style)||"";a&&(o.push(a),s=" slide-styled-block"),o.length>0&&(n=` style="${rt(o.join(";"))}"`);const r=(t==null?void 0:t.containerClassName)||"pdf-block",l=t!=null&&t.extraClassName?` ${t.extraClassName}`:"",c=t!=null&&t.blockClassResolver?t.blockClassResolver(e):"",u=c?` ${c}`:"",d=`${r}${i}${s}${l}${u}`,h=(e.rawMarkdown||e.content||"").trim();if(!h)return`<div class="${d}"${n}></div>`;if(h.includes('class="slides-block-ref"')||h.includes('class="slides-ref-tag"'))return`<div class="${d}"${n}>${h}</div>`;if(h.startsWith("$$")&&h.endsWith("$$")){const M=h.slice(2,-2).trim();return`<div class="${d} katex-display-container"${n}><div class="katex-display font-math"><em>${rt(M)}</em></div></div>`}const f=h.match(/^(#{1,6})\s+(.*)$/);if(f){const M=f[1].length,B=lt(f[2]),se=!!(e.isColFirst||e.type==="i"&&((C=t==null?void 0:t.extraClassName)!=null&&C.includes("slides-col-first-heading-block")))?' class="slide-list-item-title"':"";return`<div class="${d}"${n}><h${M}${se}>${B}</h${M}></div>`}if(h.startsWith(":::")){const M=h.split(`
`),P=M[0].replace(/^:::\s*/,"").trim()||"info",se=M.slice(1,M[M.length-1].startsWith(":::")?-1:void 0).join(`
`),G=(t==null?void 0:t.calloutClassName)||"pdf-callout";return`<div class="${d}"${n}><div class="${G} ${G}--${P}"><div class="${G}-title">${P.toUpperCase()}</div><div class="${G}-body">${lt(se)}</div></div></div>`}if(h.startsWith("<<<")){const P=`// Inside ./snippets/external.ts
export function emptyArray<T>(length: number) {
  return Array.from<T>({ length })
}`.split(`
`).map((ie,oe)=>`<span class="code-line shiki-focus"><span class="line-no">${oe+1}</span><span class="line-content">${ra(ie,"ts")}</span></span>`).join(`
`),se=(t==null?void 0:t.codeClassName)||"pdf-code shiki-container",G=((L=e.attrs)==null?void 0:L["custom-slides-max-height"])||((z=e.attributes)==null?void 0:z["custom-slides-max-height"])||e.maxHeight||"",K=G?/^\d+$/.test(String(G).trim())?`${String(G).trim()}px`:String(G).trim():"",ce=K?` style="max-height:${rt(K)};overflow-y:auto;"`:"";return`<div class="${d}"${n}><pre class="${se}"${ce}><span class="lang-badge">TS</span><code>${P}</code></pre></div>`}if(h.startsWith("<style")||h.startsWith("<!-- Inline style -->")||h.startsWith(`<!--
Notes`))return"";if(h.startsWith("```")){const M=h.split(`
`),B=M[0].slice(3).trim(),P=B.match(/^([^\s{\[]+)/),se=P?P[1]:"",G=B.match(/\[([^\]]+)\]/),K=G?G[1]:"",ce=B.includes("twoslash"),ie=e.shikiLines||((H=B.match(/\{([^}]+)\}/))==null?void 0:H[1])||"",oe=Gm(ie),re=M.length>2?M[M.length-1]==="```"?M.slice(1,-1):M.slice(1):[h.slice(3).replace(/```$/,"")],be=(t==null?void 0:t.codeClassName)||"pdf-code shiki-container",ke=K?`${be} has-filename`:be,le=oe!=="all",J=re.map((j,I)=>{const T=I+1,Y=oe==="all"||oe.has(T)?"code-line shiki-focus":le?"code-line shiki-dimmed":"code-line";let R=(t==null?void 0:t.highlight)===!0?ra(j,se):rt(j);return ce&&j.includes("doubled.value = 2")?(R=R.replace(/(\bvalue\b)/,'<span class="twoslash-error-wavy">$1</span>'),`<span class="${Y}"><span class="line-no">${T}</span><span class="line-content">${R}</span></span>
<div class="twoslash-popup-error"><span style="color:#ef4444;font-weight:bold;margin-right:4px;">✕</span> Cannot assign to 'value' because it is a read-only property.</div>`):`<span class="${Y}"><span class="line-no">${T}</span><span class="line-content">${R}</span></span>`}).join(`
`),he=se?`<span class="lang-badge">${rt(se)}</span>`:"",D=K?`<span class="code-filename">${rt(K)}</span>`:"",W=((q=e.attrs)==null?void 0:q["custom-slides-max-height"])||((_=e.attributes)==null?void 0:_["custom-slides-max-height"])||e.maxHeight||"",g=W?/^\d+$/.test(String(W).trim())?`${String(W).trim()}px`:String(W).trim():"",V=g?` style="max-height:${rt(g)};overflow-y:auto;"`:"";return`<div class="${d}"${n}><pre class="${ke}"${V}>${D}${he}<code>${J}</code></pre></div>`}if(h.includes("|")&&h.split(`
`).filter(M=>M.trim().startsWith("|")).length>=2){const M=h.split(`
`).filter(P=>P.trim().startsWith("|")),B=qm(M,t==null?void 0:t.tableClassName);return`<div class="${d}"${n}>${B}</div>`}if(h.startsWith("> ")){const M=(t==null?void 0:t.quoteClassName)||"pdf-quote";return`<div class="${d}"${n}><blockquote class="${M}"><p>${lt(h.slice(2))}</p></blockquote></div>`}const v=/<video\b/i.test(h)||e.type==="video"||e.type==="NodeVideo",m=/^(\s*)([-*+]|\d+\.)\s+/m.test(h),b=/(?:^|\n)\s*#{1,6}\s+/.test(h);if(v&&!m&&!b&&!h.includes(`
`)){const M=((N=e.attributes)==null?void 0:N["custom-slides-autoplay"])==="true"||/autoplay/i.test(h),B=((k=e.attributes)==null?void 0:k["custom-slides-loop"])==="true"||/loop/i.test(h),P=((U=e.attributes)==null?void 0:U["custom-slides-muted"])==="true"||M||/muted/i.test(h),se=((F=e.attributes)==null?void 0:F["custom-slides-controls"])==="false",G=h.match(/\bsrc=["']([^"']+)["']/i),K=G?G[1]:"",ce=['class="slide-video-player"'];se||ce.push("controls"),M&&(ce.push("autoplay"),ce.push("playsinline")),B&&ce.push("loop"),P&&ce.push("muted"),ce.push('preload="auto"'),K&&ce.push(`src="${K}"`);const ie=h.match(/<video[^>]*>([\s\S]*?)<\/video>/i);let oe=ie?ie[1].trim():"";return!oe&&K&&(oe=`<source src="${K}" type="video/mp4" />您的浏览器不支持视频播放。`),`<div class="${d} ${d}--video slide-media-block slide-video-container slide-media-container" data-autoplay="${M?"true":"false"}" data-muted="${P?"true":"false"}"${n}><video ${ce.join(" ")}>${oe}</video></div>`}const y=h.match(/^!\[(.*?)\]\((.*?)\)$/);if(y){const M=(t==null?void 0:t.imageClassName)||"pdf-image slide-media-img";return`<div class="${d} ${d}--image slide-media-block slide-media-container"${n}><img alt="${rt(y[1])}" src="${y[2]}" class="${M}" /></div>`}const x=Ul(h,t,e);if(x)return`<div class="${d} pdf-list-item"${n}>${x}</div>`;if(/<(?:Toc|toc)\b/i.test(h)&&!h.startsWith("```")){const M=h.match(/minDepth=["']?(\d+)["']?/i),B=h.match(/maxDepth=["']?(\d+)["']?/i),P=h.match(/columns=["']?(\d+)["']?/i),se=(t==null?void 0:t.allSlides)||[];return`<div class="${d}"${n}>${Jm(se,(t==null?void 0:t.currentPageIndex)||1,{minDepth:M?parseInt(M[1],10):1,maxDepth:B?parseInt(B[1],10):1/0,columns:P?parseInt(P[1],10):1,textSm:h.includes("text-sm")})}</div>`}if(h.includes(`
`)||b){const M=Vm(h,t,e);if(M)return`<div class="${d}"${n}>${M}</div>`}const w=!!e.isColFirst?' class="slide-list-item-title"':"";return`<div class="${d}"${n}><p${w}>${lt(h)}</p></div>`}function Xm(e){return`
    ${Pn(e)}

    :root {
      --slide-bg: #ffffff;
      --slide-text: #1a1a1a;
      --slide-accent: #3b82f6;
      --slide-font: system-ui, -apple-system, sans-serif;
    }
    [data-theme="dark"] {
      --slide-bg: #121214;
      --slide-text: #e2e8f0;
      --slide-accent: #60a5fa;
    }

    /* 1. 默认科技主题 Default */
    [data-slides-theme="default"],
    .slides-theme-default {
      --slide-font: system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "PingFang SC", "Microsoft YaHei", sans-serif;
      --slide-accent: #10b981;
    }
    [data-theme="light"][data-slides-theme="default"],
    [data-theme="light"] .slides-theme-default {
      --slide-bg: #ffffff;
      --slide-text: #1e293b;
      --slide-accent: #059669;
    }
    [data-theme="dark"][data-slides-theme="default"],
    [data-theme="dark"] .slides-theme-default {
      --slide-bg: #121214;
      --slide-text: #e2e8f0;
      --slide-accent: #34d399;
    }
    .slides-theme-default .layout-cover h1,
    .slides-theme-default .layout-cover .slide-block h1 {
      font-size: 3.8rem !important;
      font-weight: 800 !important;
      line-height: 1.15 !important;
      letter-spacing: -0.025em !important;
      margin-bottom: 18px !important;
      background: linear-gradient(135deg, #10b981, #06b6d4) !important;
      -webkit-background-clip: text !important;
      -webkit-text-fill-color: transparent !important;
    }
    .slides-theme-default .layout-cover h2,
    .slides-theme-default .layout-cover .slide-block h2 {
      font-size: 1.85rem !important;
      font-weight: 600 !important;
      opacity: 0.85 !important;
      margin-bottom: 12px !important;
    }
    .slides-theme-default .layout-cover p,
    .slides-theme-default .layout-cover .slide-block p {
      font-size: 1.45rem !important;
      line-height: 1.5 !important;
      opacity: 0.85 !important;
    }

    /* 2. 优雅衬线主题 Seriph */
    [data-slides-theme="seriph"],
    .slides-theme-seriph {
      --slide-font: "PT Serif", "Charter", "Georgia", "Cambria", "Times New Roman", "Source Han Serif SC", "Noto Serif SC", "Songti SC", "SimSun", serif;
      --slide-accent: #b45309;
      letter-spacing: 0.015em;
    }
    [data-theme="light"][data-slides-theme="seriph"],
    [data-theme="light"] .slides-theme-seriph {
      --slide-bg: #fdfbf7;
      --slide-text: #2a2521;
      --slide-accent: #b45309;
    }
    [data-theme="dark"][data-slides-theme="seriph"],
    [data-theme="dark"] .slides-theme-seriph {
      --slide-bg: #1c1a17;
      --slide-text: #e8e3d9;
      --slide-accent: #f59e0b;
    }
    .slides-theme-seriph,
    .slides-theme-seriph .slide-content {
      font-family: var(--slide-font) !important;
      line-height: 1.72;
    }
    .slides-theme-seriph h1,
    .slides-theme-seriph h2,
    .slides-theme-seriph h3 {
      font-family: var(--slide-font) !important;
      letter-spacing: 0.025em;
      font-weight: 700;
    }
    .slides-theme-seriph .layout-cover h1 {
      background: none !important;
      -webkit-background-clip: initial !important;
      -webkit-text-fill-color: initial !important;
      color: var(--slide-accent) !important;
      font-size: 3.4rem !important;
      border-bottom: 2px solid var(--slide-accent);
      display: inline-block;
      padding-bottom: 10px;
    }

    /* 3. 极简发布会主题 Apple Basic */
    [data-slides-theme="apple-basic"],
    .slides-theme-apple-basic {
      --slide-font: -apple-system, "SF Pro Display", "SF Pro Text", BlinkMacSystemFont, "PingFang SC", "Helvetica Neue", sans-serif;
      --slide-accent: #0071e3;
    }
    [data-theme="light"][data-slides-theme="apple-basic"],
    [data-theme="light"] .slides-theme-apple-basic {
      --slide-bg: #ffffff;
      --slide-text: #1d1d1f;
      --slide-accent: #0071e3;
    }
    [data-theme="dark"][data-slides-theme="apple-basic"],
    [data-theme="dark"] .slides-theme-apple-basic {
      --slide-bg: #000000;
      --slide-text: #f5f5f7;
      --slide-accent: #2997ff;
    }
    .slides-theme-apple-basic,
    .slides-theme-apple-basic .slide-content {
      font-family: var(--slide-font) !important;
    }
    .slides-theme-apple-basic h1,
    .slides-theme-apple-basic h2,
    .slides-theme-apple-basic h3 {
      letter-spacing: -0.035em;
      font-weight: 800;
    }
    .slides-theme-apple-basic .layout-cover h1 {
      background: none !important;
      -webkit-background-clip: initial !important;
      -webkit-text-fill-color: initial !important;
      color: var(--slide-text) !important;
      font-size: 3.8rem !important;
      letter-spacing: -0.04em !important;
    }
    .slides-theme-apple-basic .layout-cover p {
      color: #86868b !important;
      font-size: 1.35rem !important;
    }

    * { box-sizing: border-box; margin: 0; padding: 0; }
    html, body {
      width: 100%; height: 100%; overflow: hidden;
      background: #0f1115; font-family: var(--slide-font);
      display: flex; justify-content: center; align-items: center;
    }
    #app { width: 100%; height: 100%; position: relative; overflow: hidden; }
    .slide-viewport {
      position: absolute; left: 50%; top: 50%;
      background: var(--slide-bg); color: var(--slide-text);
      box-shadow: 0 10px 30px rgba(0,0,0,0.5); border-radius: 8px; overflow: hidden;
      display: flex; flex-direction: column; flex-shrink: 0;
      transform: translate(-50%, -50%) scale(var(--slides-slide-scale, 1));
      transform-origin: center center; will-change: transform;
      transition: background 0.3s ease, color 0.3s ease, border-radius 0.2s ease, box-shadow 0.2s ease;
    }
    :fullscreen .slide-viewport, .is-fullscreen .slide-viewport {
      border-radius: 0 !important; box-shadow: none !important;
    }
    .slide-content {
      position: relative;
      width: 100%;
      height: 100%;
      min-height: 100%;
      flex: 1 1 0%;
      padding: var(--slides-padding-y, 32px) var(--slides-padding-x, 48px);
      display: flex;
      flex-direction: column;
      overflow: hidden;
      box-sizing: border-box;
    }

    /* 间距预设风格 */
    .slide-content.spacing-compact,
    .slide-viewport[data-spacing="compact"] .slide-content,
    [data-slides-spacing="compact"] {
      --slides-padding-y: 20px;
      --slides-padding-x: 36px;
      --slides-header-gap: 10px;
      --slides-title-margin-bottom: 6px;
    }
    .slide-content.spacing-normal,
    .slide-viewport[data-spacing="normal"] .slide-content,
    [data-slides-spacing="normal"] {
      --slides-padding-y: 32px;
      --slides-padding-x: 48px;
      --slides-header-gap: 16px;
      --slides-title-margin-bottom: 10px;
    }
    .slide-content.spacing-loose,
    .slide-viewport[data-spacing="loose"] .slide-content,
    [data-slides-spacing="loose"] {
      --slides-padding-y: 48px;
      --slides-padding-x: 56px;
      --slides-header-gap: 24px;
      --slides-title-margin-bottom: 16px;
    }

    .layout-cover { justify-content: center; align-items: center; text-align: center; }
    .layout-cover h1, .layout-cover .slide-block h1 { font-size: 3.8rem !important; font-weight: 800 !important; line-height: 1.15 !important; letter-spacing: -0.025em !important; margin-bottom: 16px !important; }
    .layout-cover h2, .layout-cover .slide-block h2 { font-size: 1.85rem !important; font-weight: 600 !important; opacity: 0.85 !important; margin-bottom: 12px !important; }
    .layout-cover p, .layout-cover .slide-block p { font-size: 1.45rem !important; line-height: 1.5 !important; opacity: 0.85 !important; }
    .two-cols-left, .two-cols-right { min-width: 0; width: 100%; display: flex; flex-direction: column; box-sizing: border-box; overflow-wrap: break-word; word-break: break-word; }
    .pdf-two-cols-wrapper,
    .layout-two-cols-grid,
    .layout-cols-wrapper,
    .layout-cols-grid {
      display: grid;
      grid-template-columns: var(--slide-grid-cols, minmax(0, 1fr) minmax(0, 1fr));
      grid-template-rows: minmax(0, 1fr) !important;
      gap: 32px;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      overflow: hidden !important;
    }
    .layout-cols-header-container,
    .layout-two-cols-header-container,
    .layout-three-cols-header-container,
    .layout-clover-container {
      display: flex;
      flex-direction: column;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      overflow: hidden !important;
    }
    .layout-header-section {
      width: 100%;
      margin-bottom: var(--slides-header-gap, 16px) !important;
      flex-shrink: 0;
    }
    .layout-header-section h1,
    .layout-header-section h2,
    .layout-header-section h3 {
      margin-bottom: var(--slides-title-margin-bottom, 10px) !important;
    }
    .pdf-three-cols-wrapper,
    .layout-three-cols-grid {
      display: grid;
      grid-template-columns: var(--slide-grid-cols, minmax(0, 1fr) minmax(0, 1fr) minmax(0, 1fr));
      grid-template-rows: minmax(0, 1fr) !important;
      gap: 24px;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      box-sizing: border-box;
      overflow: hidden !important;
    }
    .pdf-clover-wrapper,
    .layout-clover-grid {
      display: grid;
      grid-template-columns: repeat(2, minmax(0, 1fr)) !important;
      grid-template-rows: repeat(2, minmax(0, 1fr)) !important;
      gap: 20px;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      box-sizing: border-box;
      overflow: hidden !important;
    }
    .layout-clover-grid .pdf-col {
      background: transparent !important;
      border: none !important;
      box-shadow: none !important;
    }
    .pdf-col {
      display: flex;
      flex-direction: column;
      gap: 14px;
      min-width: 0;
      width: 100%;
      max-width: 100%;
      height: 100%;
      max-height: 100%;
      min-height: 0;
      justify-content: flex-start;
      box-sizing: border-box;
      overflow: hidden;
      overflow-wrap: break-word;
      word-break: break-word;
      white-space: normal;
    }
    .pdf-col * {
      overflow-wrap: break-word;
      word-break: break-word;
      box-sizing: border-box;
    }
    /* 表头多栏内超级块子块首个列表项去圆点后居中显示标题/首行文本 (仅在存在超级块分栏时生效) */
    .has-superblock-cols .pdf-col > *:first-child .slide-list-item-title,
    .has-superblock-cols .pdf-col > *:first-child :is(h1, h2, h3, h4, h5, h6),
    .has-superblock-cols .pdf-col > *:first-child p.slide-list-item-title,
    .has-superblock-cols .pdf-col > *:first-child p:first-of-type,
    .has-superblock-cols .pdf-col > *:first-child p:first-child,
    .has-superblock-cols .pdf-col > *:first-child :is(ul, ol) > li:first-child,
    .has-superblock-cols .pdf-col > *:first-child .slide-list > .slide-list-item:first-child,
    .has-superblock-cols .pdf-col > *:first-child .pdf-list > li:first-child,
    .has-superblock-cols .slides-col-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    .has-superblock-cols .slides-col-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      list-style: none !important;
      list-style-type: none !important;
      text-align: center !important;
      margin-left: 0 !important;
      padding-left: 0 !important;
      width: 100% !important;
    }

    /* 彻底清除首个列表项的原生圆点 Marker (仅在存在超级块分栏时生效) */
    .has-superblock-cols .pdf-col > *:first-child :is(ul, ol) > li:first-child::marker {
      content: "" !important;
      display: none !important;
    }

    /* 确保首个列表项内部内联与块级元素居中 (仅在存在超级块分栏时生效) */
    .has-superblock-cols .pdf-col > *:first-child :is(ul, ol) > li:first-child * {
      text-align: center !important;
    }

    /* 栏内说明段落与列表项：左对齐，自然阅读排版 */
    .has-superblock-cols .pdf-col .slide-list-item-desc,
    .has-superblock-cols .pdf-col li:not(:first-child) {
      text-align: left !important;
    }

    /* 全局特定标题大小规范化 (除封面外页首首个标题按 H2 1.7rem，表头多栏内首个标题按 H3 1.3rem) */
    [data-normalize-headings="true"] .slides-page-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .slides-page-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .slide-content:not(.layout-cover) > :is(.pdf-block, .slide-block):first-child :is(h1, h2, h3, h4, h5, h6),
    [data-normalize-headings="true"] .slide-content:not(.layout-cover) > .layout-header-section :is(.pdf-block, .slide-block):first-child :is(h1, h2, h3, h4, h5, h6),
    [data-normalize-headings="true"] .slide-content:not(.layout-cover) > :not(.layout-cols-wrapper):not(.pdf-two-cols-wrapper):not(.layout-image-cols-grid):first-child :is(h1, h2, h3, h4, h5, h6) {
      font-size: 1.7rem !important;
      font-weight: 600 !important;
      line-height: 1.25 !important;
      margin-bottom: 10px !important;
    }

    [data-normalize-headings="true"] .has-superblock-cols .slides-col-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .has-superblock-cols .slides-col-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .has-superblock-cols .pdf-col > *:first-child :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      font-size: 1.3rem !important;
      font-weight: 600 !important;
      line-height: 1.3 !important;
      margin-bottom: 8px !important;
      text-align: center !important;
    }

    /* 图左与图右版式标题完全保留用户原始字号与默认排版，不进行任何固定大小规范化 */
    [data-normalize-headings="true"] :is(.layout-image-left, .layout-image-right, .image-left-content, .image-right-content) :is(h1, h2, h3, h4, h5, h6) {
      text-align: left !important;
    }
    .pdf-col pre,
    .two-cols-left pre,
    .two-cols-right pre,
    .image-right-content pre,
    .image-left-content pre {
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      overflow-x: hidden !important;
      overflow-y: auto !important;
      max-width: 100% !important;
      box-sizing: border-box !important;
    }
    .slide-content.layout-image-right, .slide-content.layout-image-left {
      padding: 0;
      display: grid;
      grid-template-columns: var(--slide-grid-cols, minmax(0, 1fr) minmax(0, 1fr));
      grid-template-rows: 100%;
      width: 100%;
      height: 100%;
      position: absolute;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      box-sizing: border-box;
    }
    .image-right-content, .image-left-content {
      padding: 44px 50px;
      display: flex;
      flex-direction: column;
      justify-content: flex-start;
      overflow-y: auto;
      width: 100%;
      height: 100%;
      box-sizing: border-box;
    }
    .image-right-img-container, .image-left-img-container {
      width: 100%;
      height: 100%;
      overflow: hidden;
      position: relative;
      background: #18181b;
      display: flex;
      align-items: center;
      justify-content: center;
    }
    .image-right-img, .image-left-img {
      width: 100%;
      height: 100%;
      object-fit: cover;
      object-position: center;
      display: block;
    }
    .slide-block { margin-bottom: 14px; line-height: 1.6; }
    .slide-block h1 { font-size: 2.2rem; margin-bottom: 12px; }
    .slide-block h2 { font-size: 1.7rem; margin-bottom: 10px; }
    .slide-block p { font-size: 1.15rem; }
    .slide-block ul, .slide-block ol, .pdf-list {
      padding-left: 28px;
      margin: 8px 0;
      display: flex;
      flex-direction: column;
      gap: 6px;
    }
    .slide-block li, .pdf-list li {
      font-size: 1.15rem;
      line-height: 1.6;
    }
    .pdf-task-item {
      list-style: none;
      margin-left: -20px;
      display: flex;
      align-items: center;
      gap: 8px;
    }
    .pdf-task-item input[type="checkbox"] {
      width: 1.15em;
      height: 1.15em;
      cursor: pointer;
    }

    /* 两栏与三栏及多栏（超级块分栏）布局：紧凑自然行距，子列表保留圆点与层级缩进 */
    .layout-two-cols ul,
    .layout-cols-header ul,
    .layout-two-cols-header ul,
    .layout-three-cols ul,
    .layout-three-cols-header ul,
    .two-cols-left ul,
    .two-cols-right ul,
    .three-cols-col ul,
    .col ul,
    .pdf-col ul,
    .layout-two-cols-grid .pdf-list,
    .layout-three-cols-grid .pdf-list,
    .layout-cols-grid .pdf-list,
    .layout-two-cols-grid .pdf-list--unordered,
    .layout-three-cols-grid .pdf-list--unordered,
    .layout-cols-grid .pdf-list--unordered {
      list-style: disc !important;
      list-style-type: disc !important;
      padding-left: 1.25em !important;
      margin-left: 0 !important;
      margin-top: 0 !important;
      margin-bottom: 8px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: block !important;
    }

    .layout-two-cols ol,
    .layout-cols-header ol,
    .layout-two-cols-header ol,
    .layout-three-cols ol,
    .layout-three-cols-header ol,
    .two-cols-left ol,
    .two-cols-right ol,
    .three-cols-col ol,
    .col ol,
    .pdf-col ol,
    .layout-two-cols-grid .pdf-list--ordered,
    .layout-three-cols-grid .pdf-list--ordered,
    .layout-cols-grid .pdf-list--ordered {
      list-style: decimal !important;
      list-style-type: decimal !important;
      padding-left: 1.25em !important;
      margin-left: 0 !important;
      margin-top: 0 !important;
      margin-bottom: 8px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: block !important;
    }

    .layout-two-cols li,
    .layout-cols-header li,
    .layout-two-cols-header li,
    .layout-three-cols li,
    .layout-three-cols-header li,
    .two-cols-left li,
    .two-cols-right li,
    .three-cols-col li,
    .col li,
    .pdf-col li,
    .pdf-col .pdf-list-item {
      padding-left: 0.2em !important;
      margin-left: 0 !important;
      margin-bottom: 6px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: list-item !important;
      line-height: 1.6 !important;
    }

    .layout-two-cols ul ul,
    .layout-three-cols ul ul,
    .three-cols-col ul ul,
    .pdf-col ul ul {
      list-style: circle !important;
      list-style-type: circle !important;
      padding-left: 1.25em !important;
      margin-top: 4px !important;
      margin-bottom: 4px !important;
    }

    /* 列表项内嵌标题与说明排版 */
    .slide-list-item-title,
    .pdf-list li > h1,
    .pdf-list li > h2,
    .pdf-list li > h3,
    .pdf-list li > h4,
    .pdf-list li > h5,
    .pdf-list li > h6,
    li > h1.slide-list-item-title,
    li > h2.slide-list-item-title,
    li > h3.slide-list-item-title,
    li > h4.slide-list-item-title {
      margin-top: 2px !important;
      margin-bottom: 6px !important;
      line-height: 1.35 !important;
      font-weight: 700 !important;
    }
    .pdf-list li > h1, li > h1.slide-list-item-title { font-size: 1.6rem !important; }
    .pdf-list li > h2, li > h2.slide-list-item-title { font-size: 1.4rem !important; }
    .pdf-list li > h3, li > h3.slide-list-item-title { font-size: 1.22rem !important; }
    .pdf-list li > h4, li > h4.slide-list-item-title { font-size: 1.1rem !important; }

    /* 全局特定标题大小规范化后置强力锁定 (防止被列表项内部字号覆盖) */
    [data-normalize-headings="true"] .slides-page-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .slides-page-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      font-size: 1.7rem !important;
      font-weight: 600 !important;
      line-height: 1.25 !important;
      margin-bottom: 10px !important;
    }
    [data-normalize-headings="true"] .slides-col-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .slides-col-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] :is(.layout-cols-wrapper, .pdf-two-cols-wrapper, .layout-cols-header-container, .layout-cols-grid) .pdf-col > *:first-child :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] :is(.two-cols-left, .two-cols-right, .pdf-col, .col) > *:first-child :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      font-size: 1.3rem !important;
      font-weight: 600 !important;
      line-height: 1.3 !important;
      margin-bottom: 8px !important;
      text-align: center !important;
    }
    /* 基础列表项前缀样式 */
    .slide-block ul,
    .slide-list--unordered,
    .pdf-list--unordered {
      list-style: disc !important;
      list-style-type: disc !important;
    }
    .slide-block ol,
    .slide-list--ordered,
    .pdf-list--ordered {
      list-style: decimal !important;
      list-style-type: decimal !important;
    }
    .slide-block li,
    .slide-list-item,
    .pdf-list-item,
    .pdf-list li {
      display: list-item !important;
    }

    /* 隐藏无序列表前缀标记 */
    [data-hide-unordered-markers="true"] :is(ul, .slide-list, .slide-list--unordered, .pdf-list, .pdf-list--unordered),
    [data-hide-unordered-markers="true"] :is(ul, .slide-list, .slide-list--unordered, .pdf-list, .pdf-list--unordered) > li,
    [data-hide-unordered-markers="true"] li.slide-list-item,
    [data-hide-unordered-markers="true"] ul > li {
      list-style: none !important;
      list-style-type: none !important;
      padding-left: 0 !important;
      margin-left: 0 !important;
    }
    [data-hide-unordered-markers="true"] :is(ul, .slide-list, .slide-list--unordered, .pdf-list, .pdf-list--unordered) > li::marker,
    [data-hide-unordered-markers="true"] li.slide-list-item::marker {
      content: "" !important;
      display: none !important;
    }

    /* 隐藏有序列表前缀标记 */
    [data-hide-ordered-markers="true"] :is(ol, .slide-list, .slide-list--ordered, .pdf-list, .pdf-list--ordered),
    [data-hide-ordered-markers="true"] :is(ol, .slide-list, .slide-list--ordered, .pdf-list, .pdf-list--ordered) > li,
    [data-hide-ordered-markers="true"] li.slide-list-item,
    [data-hide-ordered-markers="true"] ol > li {
      list-style: none !important;
      list-style-type: none !important;
      padding-left: 0 !important;
      margin-left: 0 !important;
    }
    [data-hide-ordered-markers="true"] :is(ol, .slide-list, .slide-list--ordered, .pdf-list, .pdf-list--ordered) > li::marker,
    [data-hide-ordered-markers="true"] li.slide-list-item::marker {
      content: "" !important;
      display: none !important;
    }

    .slide-list-item-desc,
    .pdf-list li > p {
      margin-top: 4px !important;
      margin-bottom: 6px !important;
      font-size: 1.05rem;
      line-height: 1.55;
      opacity: 0.92;
    }

    /* 多媒体（GIF动图、静态图片、MP4视频）全视口最大化自适应且不超出视口 */
    .slide-media-block,
    .slide-media-container,
    .slide-video-container,
    .slide-block--media,
    .slide-block--image,
    .slide-block--video,
    .slide-block:has(> img),
    .slide-block:has(> .slide-media-container),
    .slide-block:has(> p > img:only-child),
    .slide-block:has(> .slide-video-container),
    .slide-block:has(> video) {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      min-width: 0 !important;
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
      justify-content: center !important;
      width: 100% !important;
      height: 100% !important;
      max-height: 100% !important;
      overflow: hidden !important;
      margin: 4px 0 !important;
      box-sizing: border-box !important;
    }

    .two-cols-left > .slide-block,
    .two-cols-right > .slide-block,
    .three-cols-col > .slide-block,
    .pdf-col > .slide-block,
    .pdf-col .slide-block {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      max-height: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      width: 100% !important;
      height: 100% !important;
      box-sizing: border-box !important;
      overflow: hidden !important;
      margin-bottom: 0 !important;
    }

    /* 列内列表项的标题与段落文字：固定高度，不压缩 */
    .two-cols-left .slide-list-item-title,
    .two-cols-right .slide-list-item-title,
    .three-cols-col .slide-list-item-title,
    .pdf-col .slide-list-item-title,
    .two-cols-left h1, .two-cols-left h2, .two-cols-left h3, .two-cols-left h4, .two-cols-left h5, .two-cols-left h6,
    .two-cols-right h1, .two-cols-right h2, .two-cols-right h3, .two-cols-right h4, .two-cols-right h5, .two-cols-right h6,
    .three-cols-col h1, .three-cols-col h2, .three-cols-col h3, .three-cols-col h4, .three-cols-col h5, .three-cols-col h6,
    .pdf-col h1, .pdf-col h2, .pdf-col h3, .pdf-col h4, .pdf-col h5, .pdf-col h6,
    .three-cols-col .slide-list-item-desc,
    .pdf-col .slide-list-item-desc {
      flex: 0 0 auto !important;
      margin-top: 0 !important;
      margin-bottom: 6px !important;
    }

    /* 列内媒体容器：填满标题下方所有剩余垂直空间，纵向顶部对齐，横向居中，无溢出 */
    .two-cols-left .slide-list-media,
    .two-cols-right .slide-list-media,
    .three-cols-col .slide-list-media,
    .pdf-col .slide-list-media,
    .two-cols-left .slide-video-container,
    .two-cols-right .slide-video-container,
    .three-cols-col .slide-video-container,
    .pdf-col .slide-video-container,
    .two-cols-left .slide-media-container,
    .two-cols-right .slide-media-container,
    .three-cols-col .slide-media-container,
    .pdf-col .slide-media-container {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      min-width: 0 !important;
      width: 100% !important;
      height: 100% !important;
      max-height: 100% !important;
      max-width: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
      justify-content: flex-start !important;
      overflow: hidden !important;
      margin: 0 !important;
      padding: 0 !important;
      box-sizing: border-box !important;
    }

    /* 列内多媒体播放器：以 contain 模式等比缩放完整可见，绝对不超高超宽、不产生遮挡与滚动条 */
    .two-cols-left video,
    .two-cols-right video,
    .three-cols-col video,
    .pdf-col video,
    .two-cols-left img,
    .two-cols-right img,
    .three-cols-col img,
    .pdf-col img,
    .two-cols-left .slide-video-player,
    .two-cols-right .slide-video-player,
    .three-cols-col .slide-video-player,
    .pdf-col .slide-video-player,
    .layout-three-cols-grid video,
    .layout-two-cols-grid video,
    .layout-three-cols-grid img,
    .layout-two-cols-grid img {
      max-width: 100% !important;
      max-height: 100% !important;
      width: auto !important;
      height: auto !important;
      min-width: 0 !important;
      min-height: 0 !important;
      object-fit: contain !important;
      display: block !important;
      margin: 0 auto !important;
      cursor: zoom-in;
    }

    .slide-block img,
    .slide-media-img,
    .slide-media-container img,
    .slide-video-player,
    video.slide-video-player,
    .slide-block video {
      max-width: 100% !important;
      max-height: 100% !important;
      width: auto !important;
      height: auto !important;
      min-width: 0 !important;
      min-height: 0 !important;
      object-fit: contain !important;
      display: block !important;
      margin: 0 auto !important;
      border-radius: 8px;
      box-shadow: 0 4px 16px rgba(0, 0, 0, 0.16);
      background: transparent;
      outline: none;
      cursor: zoom-in;
    }

    .slide-list-media {
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
      justify-content: flex-start !important;
      width: 100% !important;
      max-width: 100% !important;
      height: 100% !important;
      max-height: 100% !important;
      flex: 1 1 0% !important;
      margin-top: 4px !important;
      margin-bottom: 4px !important;
      min-height: 0 !important;
      overflow: hidden !important;
      box-sizing: border-box !important;
    }
    .slide-list-media img,
    .slide-list-media video,
    .slide-list-media .list-item-gif,
    .slide-list-media .slide-video-player {
      max-width: 100% !important;
      max-height: 100% !important;
      width: auto !important;
      height: auto !important;
      min-width: 0 !important;
      min-height: 0 !important;
      object-fit: contain !important;
      border-radius: 6px !important;
      box-shadow: 0 3px 12px rgba(0, 0, 0, 0.14) !important;
      display: block !important;
      margin: 0 auto !important;
      cursor: zoom-in;
    }

    .slide-block:has(.slide-list-media) {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      height: 100% !important;
      max-height: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      overflow: hidden !important;
    }
    .slide-block:has(.slide-list-media) .pdf-list,
    .slide-block:has(.slide-list-media) ul,
    .slide-block:has(.slide-list-media) ol {
      display: block !important;
      flex: 1 1 auto;
      min-height: 0;
      max-height: 100%;
      overflow: visible !important;
      list-style: disc !important;
      list-style-type: disc !important;
    }
    .slide-block:has(.slide-list-media) li,
    .slide-block:has(.slide-list-media) .slide-list-item,
    .slide-block:has(.slide-list-media) .pdf-list-item,
    .slide-block:has(.slide-media-container) li,
    .slide-block:has(.slide-video-container) li,
    .layout-cols-wrapper li:has(.slide-list-media),
    .layout-cols-header-container li:has(.slide-list-media),
    .two-cols-left li:has(.slide-list-media),
    .two-cols-right li:has(.slide-list-media),
    .three-cols-col li:has(.slide-list-media),
    .pdf-col li:has(.slide-list-media),
    li:has(.slide-list-media),
    li:has(.slide-video-container),
    li:has(.slide-media-container) {
      display: list-item !important;
      list-style-type: disc !important;
      flex: 0 0 auto !important;
      height: auto !important;
      max-height: none !important;
      overflow: visible !important;
      margin-bottom: 6px !important;
    }

    .layout-two-cols .slide-media-block,
    .layout-two-cols .slide-video-container,
    .layout-two-cols .slide-media-container,
    .layout-three-cols .slide-media-block,
    .layout-three-cols .slide-video-container,
    .layout-three-cols .slide-media-container {
      max-width: 100% !important;
      max-height: 100% !important;
      width: 100% !important;
      height: 100% !important;
      min-width: 0 !important;
      min-height: 0 !important;
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
      justify-content: flex-start !important;
      overflow: hidden !important;
    }

    /* Lightbox 大图与视频灯箱模态窗口 */
    .slides-lightbox {
      position: fixed;
      top: 0;
      left: 0;
      width: 100vw;
      height: 100vh;
      background: rgba(0, 0, 0, 0.88);
      backdrop-filter: blur(8px);
      z-index: 999999;
      display: none;
      align-items: center;
      justify-content: center;
      cursor: zoom-out;
      opacity: 0;
      transition: opacity 0.2s cubic-bezier(0.16, 1, 0.3, 1);
    }
    .slides-lightbox.active {
      display: flex;
      opacity: 1;
    }
    .slides-lightbox-content {
      position: relative;
      max-width: 92vw;
      max-height: 92vh;
      display: flex;
      align-items: center;
      justify-content: center;
      cursor: default;
    }
    .slides-lightbox-img {
      max-width: 92vw;
      max-height: 92vh;
      object-fit: contain;
      border-radius: 8px;
      box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.75);
      user-select: none;
      -webkit-user-drag: none;
      touch-action: none;
    }
    .slides-lightbox-video {
      max-width: 92vw;
      max-height: 92vh;
      border-radius: 8px;
      box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.75);
    }
    .slides-lightbox-close {
      position: absolute;
      top: 24px;
      right: 28px;
      width: 40px;
      height: 40px;
      background: rgba(255, 255, 255, 0.2);
      border: 1px solid rgba(255, 255, 255, 0.35);
      border-radius: 50%;
      color: #fff;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 22px;
      cursor: pointer;
      transition: background 0.2s, transform 0.2s;
      z-index: 1000000;
    }
    .slides-lightbox-close:hover {
      background: rgba(255, 255, 255, 0.35);
      transform: scale(1.05);
    }

    img.slide-inline-img {
      max-width: 100% !important;
      max-height: min(320px, 40vh) !important;
      object-fit: contain !important;
      vertical-align: middle;
      border-radius: 4px;
    }
    kbd {
      display: inline-block;
      padding: 2px 7px;
      font-family: ui-monospace, SFMono-Regular, "SF Mono", Menlo, Consolas, "Liberation Mono", monospace;
      font-size: 0.85em;
      font-weight: 600;
      line-height: 1.25;
      color: inherit;
      background: rgba(125, 125, 125, 0.12);
      border: 1px solid rgba(125, 125, 125, 0.35);
      border-bottom-width: 2px;
      border-radius: 5px;
      box-shadow: 0 1px 2px rgba(0, 0, 0, 0.12);
      margin: 0 2px;
      vertical-align: middle;
      white-space: nowrap;
    }
    [data-theme="dark"] kbd, .theme-dark kbd {
      background: rgba(255, 255, 255, 0.1);
      border-color: rgba(255, 255, 255, 0.25);
      border-bottom-color: rgba(255, 255, 255, 0.4);
      color: #f1f5f9;
      box-shadow: 0 1px 2px rgba(0, 0, 0, 0.4);
    }
    .slide-block pre,
    pre {
      background: rgba(0, 0, 0, 0.1);
      padding: 12px;
      border-radius: 6px;
      font-family: "JetBrains Mono", Consolas, monospace;
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      overflow-x: hidden !important;
      overflow-y: auto !important;
      max-width: 100% !important;
      box-sizing: border-box !important;
    }
    .slide-block pre code,
    pre code {
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      display: block !important;
      width: 100% !important;
      box-sizing: border-box !important;
    }
    .code-line {
      display: flex !important;
      align-items: flex-start !important;
      width: 100% !important;
      box-sizing: border-box !important;
      line-height: 1.6;
    }
    .code-line .line-no {
      display: inline-block !important;
      flex-shrink: 0 !important;
      min-width: 2.2em !important;
      text-align: right !important;
      margin-right: 12px !important;
      user-select: none !important;
      opacity: 0.45 !important;
    }
    .code-line .line-content {
      flex: 1 1 0% !important;
      min-width: 0 !important;
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
    }
    /* 弱提示滚动条样式 */
    * {
      scrollbar-width: thin;
      scrollbar-color: rgba(255, 255, 255, 0.20) transparent;
    }
    *::-webkit-scrollbar {
      width: 4px;
      height: 4px;
    }
    *::-webkit-scrollbar-track {
      background: transparent;
    }
    *::-webkit-scrollbar-thumb {
      background: rgba(255, 255, 255, 0.20);
      border-radius: 2px;
      transition: background 0.2s ease;
    }
    *:hover::-webkit-scrollbar-thumb,
    *::-webkit-scrollbar-thumb:hover {
      background: rgba(255, 255, 255, 0.45);
    }
    /* Slidev Micro-motion Keyframes & Presets */
    @keyframes slidesMotionFadeIn { from { opacity: 0; } to { opacity: 1; } }
    @keyframes slidesMotionSlideUp { from { opacity: 0; transform: translateY(40px); } to { opacity: 1; transform: translateY(0); } }
    @keyframes slidesMotionSlideDown { from { opacity: 0; transform: translateY(-40px); } to { opacity: 1; transform: translateY(0); } }
    @keyframes slidesMotionSlideLeft { from { opacity: 0; transform: translateX(40px); } to { opacity: 1; transform: translateX(0); } }
    @keyframes slidesMotionSlideRight { from { opacity: 0; transform: translateX(-40px); } to { opacity: 1; transform: translateX(0); } }
    @keyframes slidesMotionZoomIn { from { opacity: 0; transform: scale(0.8); } to { opacity: 1; transform: scale(1); } }
    @keyframes slidesMotionBounce {
      0% { opacity: 0; transform: translateY(40px); }
      60% { opacity: 1; transform: translateY(-8px); }
      80% { transform: translateY(4px); }
      100% { transform: translateY(0); }
    }
    .slides-motion-fade-in { animation: slidesMotionFadeIn var(--motion-duration, 0.4s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slides-motion-slide-up { animation: slidesMotionSlideUp var(--motion-duration, 0.45s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slides-motion-slide-down { animation: slidesMotionSlideDown var(--motion-duration, 0.45s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slides-motion-slide-left { animation: slidesMotionSlideLeft var(--motion-duration, 0.45s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slides-motion-slide-right { animation: slidesMotionSlideRight var(--motion-duration, 0.45s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slides-motion-zoom-in, .slides-motion-pop { animation: slidesMotionZoomIn var(--motion-duration, 0.4s) cubic-bezier(0.34, 1.56, 0.64, 1) var(--motion-delay, 0s) both; }
    .slides-motion-bounce { animation: slidesMotionBounce var(--motion-duration, 0.6s) cubic-bezier(0.34, 1.56, 0.64, 1) var(--motion-delay, 0s) both; }
    .controls {
      position: absolute; bottom: 16px; display: flex; gap: 12px; align-items: center;
      background: rgba(24, 24, 27, 0.8); backdrop-filter: blur(8px);
      padding: 6px 18px; border-radius: 20px; color: #fff; font-size: 13px; z-index: 10;
      opacity: 0; pointer-events: auto;
      transition: opacity 0.3s cubic-bezier(0.16, 1, 0.3, 1), transform 0.3s cubic-bezier(0.16, 1, 0.3, 1);
    }
    .controls::before {
      content: ""; position: absolute; top: -20px; bottom: -16px; left: -24px; right: -24px;
    }
    .controls:hover, .controls:focus-within {
      opacity: 1; transform: translateY(-2px);
    }
    .controls button { background: transparent; border: none; color: inherit; cursor: pointer; padding: 2px 6px; }

    /* Slidev Native Icons & Interactive Buttons */
    .slidev-icon-btn {
      display: inline-flex !important; flex-direction: row !important; align-items: center !important; justify-content: center !important;
      padding: 0.35rem 0.5rem; border-radius: 0.375rem; background: transparent;
      border: 1px solid transparent; color: inherit; font-size: inherit; line-height: 1;
      cursor: pointer; opacity: 0.8; transition: all 0.2s ease; text-decoration: none;
      vertical-align: middle; user-select: none; margin: 0 4px;
    }
    .slidev-icon-btn:hover { opacity: 1; background: rgba(255, 255, 255, 0.12); border-color: rgba(255, 255, 255, 0.15); }

    /* 组件从上到下按顺序流式渲染，避免相互重叠 */
    .slide-block > div + div { margin-top: 14px; }

    /* 同一个 div 内的按钮/链接从左到右水平渲染 */
    .slide-block div:has(> .slidev-icon-btn),
    .slide-block div:has(> button),
    .slide-block [class*="abs-"],
    .slides-btn-row {
      display: inline-flex !important;
      flex-direction: row !important;
      align-items: center !important;
      justify-content: center !important;
      flex-wrap: wrap !important;
      gap: 8px !important;
    }

    /* Position Shortcuts 适配：在组件流中保持从上到下排列，不脱离流产生重叠 */
    .slide-block .abs-br,
    .slide-block .abs-bl,
    .slide-block .abs-tr,
    .slide-block .abs-tl,
    .slide-block [class*="abs-"] {
      position: relative !important;
      bottom: auto !important;
      right: auto !important;
      top: auto !important;
      left: auto !important;
      margin: 0.75rem auto !important;
    }

    .slide-block--absolute { position: relative !important; margin-bottom: 14px !important; padding: 0 !important; background: transparent !important; }
    .slide-block--absolute:hover { background: transparent !important; }
    .mt-12 { margin-top: 3rem !important; }
    .py-1 { padding-top: 0.25rem !important; padding-bottom: 0.25rem !important; }
    .m-6 { margin: 1.5rem !important; }
    .text-xl { font-size: 1.25rem !important; }
    [hover\\:bg~="white"][hover\\:bg~="op-10"]:hover,
    [hover\\:bg="white op-10"]:hover { background: rgba(255, 255, 255, 0.1) !important; border-radius: 4px; }
    .cursor-pointer, [data-clickable] { cursor: pointer; }
    /* Slidev 规范链接排版 (继承正文颜色，虚线底边，Hover 时平滑点亮为主题色并转为实线) */
    .slide-content a:not(.slides-ref-tag):not(.slidev-icon-btn):not(.slides-toc-link),
    .slide-block a:not(.slides-ref-tag):not(.slidev-icon-btn):not(.slides-toc-link),
    a.slides-link {
      color: inherit;
      text-decoration: none;
      border-bottom: 1px dashed currentColor;
      transition: color 0.2s cubic-bezier(0.4, 0, 0.2, 1),
                  border-color 0.2s cubic-bezier(0.4, 0, 0.2, 1),
                  border-bottom-style 0.2s cubic-bezier(0.4, 0, 0.2, 1);
      cursor: pointer;
    }
    .slide-content a:not(.slides-ref-tag):not(.slidev-icon-btn):not(.slides-toc-link):hover,
    .slide-block a:not(.slides-ref-tag):not(.slidev-icon-btn):not(.slides-toc-link):hover,
    a.slides-link:hover {
      color: var(--slide-accent);
      border-bottom-style: solid;
      border-bottom-color: var(--slide-accent);
    }
    .slides-ref-tag, a.slides-ref-tag {
      display: inline-flex;
      align-items: center;
      background: color-mix(in srgb, var(--slide-accent) 12%, transparent);
      color: var(--slide-accent);
      border-radius: 4px;
      padding: 2px 8px;
      font-size: 0.88em;
      text-decoration: none;
      cursor: pointer;
      margin: 2px 4px 2px 0;
      border: 1px solid color-mix(in srgb, var(--slide-accent) 25%, transparent);
      transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
    }
    .slides-ref-tag:hover, a.slides-ref-tag:hover {
      background: color-mix(in srgb, var(--slide-accent) 22%, transparent);
      color: var(--slide-accent);
      border-color: color-mix(in srgb, var(--slide-accent) 55%, transparent);
      transform: translateY(-1px);
      box-shadow: 0 2px 8px color-mix(in srgb, var(--slide-accent) 20%, transparent);
    }
    .slides-block-ref {
      display: block;
      padding: 10px 14px;
      background: color-mix(in srgb, var(--slide-accent) 8%, transparent);
      border-left: 3px solid var(--slide-accent);
      border-radius: 0 6px 6px 0;
      margin: 8px 0;
      cursor: pointer;
      transition: background 0.2s ease;
    }
    .slides-block-ref:hover {
      background: color-mix(in srgb, var(--slide-accent) 15%, transparent);
    }

    /* 页面动态蒙版 (Dynamic Mask) GPU 合成器硬件加速体系 */
    .slides-mask-body-container {
      position: relative;
      width: 100%;
      height: 100%;
      min-height: 0;
      flex: 1;
      display: flex;
      flex-direction: column;
      overflow: hidden !important;
      contain: layout paint;
      isolation: isolate;
    }
    .slides-mask-body-container--has-mask {
      overflow: hidden !important;
      /* 向左右、向下突破父容器内边距，完全贴合幻灯片视口边缘 */
      margin-left: calc(-1 * var(--slides-padding-x, 48px)) !important;
      margin-right: calc(-1 * var(--slides-padding-x, 48px)) !important;
      margin-bottom: calc(-1 * var(--slides-padding-y, 32px)) !important;
      padding-left: var(--slides-padding-x, 48px) !important;
      padding-right: var(--slides-padding-x, 48px) !important;
      padding-bottom: var(--slides-padding-y, 32px) !important;
      width: calc(100% + 2 * var(--slides-padding-x, 48px)) !important;
      box-sizing: border-box !important;
    }
    /* 无标题且首个元素即为蒙版正文容器时，向上同步扩展至顶部边缘 */
    .slide-content-wrapper > .slides-mask-body-container--has-mask:first-child,
    .slide-content > .slides-mask-body-container--has-mask:first-child {
      margin-top: calc(-1 * var(--slides-padding-y, 32px)) !important;
      padding-top: var(--slides-padding-y, 32px) !important;
    }
    /* 针对全屏零内边距特殊布局（如 image-right/image-left），重置内边距变量避免越界 */
    .slide-content-wrapper.layout-image-right,
    .slide-content-wrapper.layout-image-left,
    .slide-content.layout-image-right,
    .slide-content.layout-image-left {
      --slides-padding-x: 0px !important;
      --slides-padding-y: 0px !important;
    }
    /* 蒙版运动总图层：纯 GPU Compositor 硬件加速 translate3d */
    .slides-mask-layer {
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      pointer-events: none;
      z-index: 50;
      will-change: transform, opacity;
      transform: translate3d(0, 0, 0);
      backface-visibility: hidden;
      transition: transform 0.42s cubic-bezier(0.2, 0, 0, 1),
                  opacity 0.42s cubic-bezier(0.2, 0, 0, 1);
    }
    /* 蒙版内部遮罩层：纯色或磨砂玻璃 */
    .slides-mask-overlay {
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      pointer-events: none;
    }
    .slides-mask-layer--solid .slides-mask-overlay,
    .slides-mask-overlay--solid {
      background: var(--slide-bg, #ffffff);
    }
    [data-theme="dark"] .slides-mask-layer--solid .slides-mask-overlay,
    [data-theme="dark"] .slides-mask-overlay--solid {
      background: var(--slide-bg, #121214);
    }
    .slides-mask-layer--blur .slides-mask-overlay,
    .slides-mask-overlay--blur {
      backdrop-filter: blur(30px) saturate(180%);
      -webkit-backdrop-filter: blur(30px) saturate(180%);
      background: color-mix(in srgb, var(--slide-bg, #ffffff) 90%, transparent);
    }
    [data-theme="dark"] .slides-mask-layer--blur .slides-mask-overlay,
    [data-theme="dark"] .slides-mask-overlay--blur {
      background: color-mix(in srgb, var(--slide-bg, #121214) 90%, transparent);
    }
    /* 动态展露分界提示线：物理内嵌于蒙版边缘，相对坐标永为 0，绝对物理同步 */
    .slides-mask-divider-line {
      position: absolute;
      pointer-events: none;
      z-index: 51;
      opacity: 0;
      transition: opacity 0.3s ease;
    }
    .slides-mask-layer--down .slides-mask-divider-line,
    .slides-mask-divider-line--down {
      top: 0;
      left: 0;
      right: 0;
      height: 2.5px;
      transform: translateY(-50%);
      background: linear-gradient(90deg, transparent 0%, var(--slide-accent, #3b82f6) 6%, var(--slide-accent, #3b82f6) 94%, transparent 100%);
      box-shadow: 0 0 10px var(--slide-accent, #3b82f6), 0 0 4px var(--slide-accent, #3b82f6);
    }
    .slides-mask-layer--right .slides-mask-divider-line,
    .slides-mask-divider-line--right {
      top: 0;
      bottom: 0;
      left: 0;
      width: 2.5px;
      transform: translateX(-50%);
      background: linear-gradient(180deg, transparent 0%, var(--slide-accent, #3b82f6) 6%, var(--slide-accent, #3b82f6) 94%, transparent 100%);
      box-shadow: 0 0 10px var(--slide-accent, #3b82f6), 0 0 4px var(--slide-accent, #3b82f6);
    }
    .slides-mask-layer--clockwise,
    .slides-mask-layer--counter-clockwise,
    .slides-mask-layer--cw,
    .slides-mask-layer--ccw,
    .slides-mask-layer--clock {
      transform: none !important;
    }
    .slides-mask-layer--clockwise .slides-mask-divider-line,
    .slides-mask-layer--counter-clockwise .slides-mask-divider-line,
    .slides-mask-layer--cw .slides-mask-divider-line,
    .slides-mask-layer--ccw .slides-mask-divider-line,
    .slides-mask-layer--clock .slides-mask-divider-line,
    .slides-mask-divider-line--clock,
    .slides-mask-divider-line--clockwise,
    .slides-mask-divider-line--counter-clockwise {
      top: 50%;
      left: 50%;
      right: auto;
      bottom: auto;
      width: 55%;
      height: 2.5px;
      transform-origin: 0% 50%;
      transform: translateY(-50%) rotate(-180deg);
      background: linear-gradient(90deg, var(--slide-accent, #3b82f6) 0%, var(--slide-accent, #3b82f6) 75%, transparent 100%);
      box-shadow: 0 0 10px var(--slide-accent, #3b82f6), 0 0 4px var(--slide-accent, #3b82f6);
      transition: transform 0.42s cubic-bezier(0.2, 0, 0, 1), opacity 0.3s ease;
      will-change: transform, opacity;
    }
    .slides-mask-layer--counter-clockwise .slides-mask-divider-line,
    .slides-mask-divider-line--counter-clockwise {
      transform: translateY(-50%) rotate(-90deg);
    }`}function Qm(){return`    (function() {
      const data = window.__SLIDES_DATA__ || { slides: [] };
      const slides = data.slides || [];
      let currentIndex = 0;

      const container = document.getElementById("slide-container");
      const pageNum = document.getElementById("page-num");
      const btnPrev = document.getElementById("btn-prev");
      const btnNext = document.getElementById("btn-next");
      const btnFullscreen = document.getElementById("btn-fullscreen");

      // 「数字+回车」跳页输入角标：右下角悬浮显示，独立于缩放视口
      const jumpBadge = document.createElement("div");
      jumpBadge.className = "jump-page-indicator";
      jumpBadge.style.display = "none";
      document.body.appendChild(jumpBadge);
      const jumpStyle = document.createElement("style");
      jumpStyle.textContent = ".jump-page-indicator{position:fixed;right:16px;bottom:16px;z-index:1000;min-width:40px;padding:4px 12px;border-radius:18px;background:rgba(24,24,27,0.8);backdrop-filter:blur(12px);-webkit-backdrop-filter:blur(12px);border:1px solid rgba(255,255,255,0.12);color:#f4f4f5;font-size:14px;font-variant-numeric:tabular-nums;text-align:center;pointer-events:none;box-shadow:0 4px 16px rgba(0,0,0,0.35);}.jump-page-indicator.is-invalid{background:rgba(153,27,27,0.85);border-color:rgba(248,113,113,0.5);color:#fecaca;animation:jump-indicator-shake 0.4s ease;}@keyframes jump-indicator-shake{0%,100%{transform:translateX(0);}25%{transform:translateX(-4px);}50%{transform:translateX(4px);}75%{transform:translateX(-2px);}}";
      document.head.appendChild(jumpStyle);

`}function eg(){return`      // ========= 缩略图总览层（o 键呼出，方向键/数字+回车/点选跳页） =========
      const OVERVIEW_CARD_W = 236;
      let overviewOpen = false;
      let overviewFocus = 1;
      let overviewBuilt = false;
      let overviewObserver = null;
      const overviewOverlay = document.createElement("div");
      overviewOverlay.className = "slides-overview";
      overviewOverlay.style.display = "none";
      const overviewGrid = document.createElement("div");
      overviewGrid.className = "slides-overview-grid";
      const overviewHint = document.createElement("div");
      overviewHint.className = "slides-overview-hint";
      overviewHint.textContent = "← → ↑ ↓ 移动 · Enter 跳转 · 数字直达 · Esc / O 关闭";
      overviewOverlay.appendChild(overviewGrid);
      overviewOverlay.appendChild(overviewHint);
      document.body.appendChild(overviewOverlay);
      overviewOverlay.addEventListener("click", (e) => {
        if (e.target === overviewOverlay) closeOverview();
      });
      const overviewStyle = document.createElement("style");
      overviewStyle.textContent = ".slides-overview{position:fixed;inset:0;z-index:900;overflow-y:auto;background:rgba(13,16,22,0.88);backdrop-filter:blur(18px);-webkit-backdrop-filter:blur(18px);padding:36px 44px 20px;box-sizing:border-box;}.slides-overview-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(236px,1fr));gap:18px;max-width:1440px;margin:0 auto;}.slides-overview-card{cursor:pointer;border-radius:10px;border:2px solid rgba(255,255,255,0.12);background:rgba(255,255,255,0.04);overflow:hidden;transition:border-color 0.15s ease,transform 0.15s ease,box-shadow 0.15s ease;}.slides-overview-card:hover{border-color:rgba(255,255,255,0.38);transform:translateY(-2px);}.slides-overview-card.is-active{border-color:var(--slide-accent,#3b82f6);box-shadow:0 0 0 1px var(--slide-accent,#3b82f6),0 8px 24px rgba(0,0,0,0.4);}.slides-overview-canvas-box{position:relative;overflow:hidden;background:var(--slide-bg,#ffffff);}.slides-overview-canvas{position:absolute;top:0;left:0;transform-origin:top left;pointer-events:none;}.slides-overview-canvas *{scrollbar-width:none;}.slides-overview-caption{display:flex;align-items:center;gap:8px;padding:6px 10px;font-size:12px;color:rgba(255,255,255,0.72);border-top:1px solid rgba(255,255,255,0.08);background:rgba(13,16,22,0.6);}.slides-overview-page-no{flex-shrink:0;font-variant-numeric:tabular-nums;font-weight:600;color:#f4f4f5;background:rgba(255,255,255,0.16);border-radius:8px;padding:0 7px;line-height:18px;}.slides-overview-page-no.is-current{background:var(--slide-accent,#10b981);color:#0b1210;}.slides-overview-title{white-space:nowrap;overflow:hidden;text-overflow:ellipsis;user-select:none;}.slides-overview-hint{text-align:center;margin:18px 0 8px;font-size:12px;color:rgba(255,255,255,0.45);user-select:none;}";
      document.head.appendChild(overviewStyle);

      const baseWidth = 980;
      const aspectStr = (data.config && data.config.aspectRatio) || "16/9";
      let ratioNum = 16 / 9;
      if (aspectStr === "4/3") ratioNum = 4 / 3;
      else if (aspectStr === "16/10") ratioNum = 16 / 10;
      else if (typeof aspectStr === "string" && aspectStr.includes("/")) {
        const parts = aspectStr.split("/").map(Number);
        if (parts[0] && parts[1]) ratioNum = parts[0] / parts[1];
      }
      const baseHeight = Math.ceil(baseWidth / ratioNum);
      const viewport = document.getElementById("viewport");

`}function tg(){return`      function updateScale() {
        if (!viewport) return;
        const isFull = !!document.fullscreenElement;
        const padX = isFull ? 0 : 20;
        const padY = isFull ? 0 : 32;
        const availW = Math.max(100, window.innerWidth - padX);
        const availH = Math.max(100, window.innerHeight - padY);
        const scale = Math.min(availW / baseWidth, availH / baseHeight);
        viewport.style.width = baseWidth + "px";
        viewport.style.height = baseHeight + "px";
        viewport.style.transform = "translate(-50%, -50%) scale(" + scale + ")";
        viewport.style.setProperty("--slides-slide-scale", scale);
        if (isFull) document.body.classList.add("is-fullscreen");
        else document.body.classList.remove("is-fullscreen");
      }

      window.addEventListener("resize", updateScale);
      document.addEventListener("fullscreenchange", updateScale);

      function parseMaskRatio(ratioStr, defaultSteps) {
        var defSteps = (defaultSteps === 4) ? 4 : 2;
        var defBps = (defaultSteps === 4) ? [25, 50, 75, 100] : [50, 100];
        if (!ratioStr || typeof ratioStr !== "string") {
          return { steps: defSteps, breakpoints: defBps };
        }
        var clean = ratioStr.trim();
        if (!clean || (defaultSteps === 4 && (clean === "1:1" || clean === "1"))) return { steps: defSteps, breakpoints: defBps };
        var parts = clean.split(":").map(function(p) { return parseFloat(p.trim()); }).filter(function(n) { return !isNaN(n) && n > 0; });
        if (parts.length === 0) return { steps: defSteps, breakpoints: defBps };
        if (parts.length === 1) {
          var val = Math.min(100, Math.max(1, parts[0]));
          if (val === 100) return { steps: 1, breakpoints: [100] };
          return { steps: 2, breakpoints: [Math.round(val * 100) / 100, 100] };
        }
        var isMonotonic = parts.every(function(val, idx) { return idx === 0 || val > parts[idx - 1]; });
        var maxVal = parts[parts.length - 1];
        if (isMonotonic && (maxVal === 100 || parts.some(function(p) { return p > 10; }))) {
          var bps = parts.map(function(p) { return Math.min(100, Math.round(p * 100) / 100); });
          if (bps[bps.length - 1] < 100) bps.push(100);
          return { steps: bps.length, breakpoints: bps };
        }
        var totalWeight = parts.reduce(function(acc, cur) { return acc + cur; }, 0);
        if (totalWeight <= 0) return { steps: defSteps, breakpoints: defBps };
        var accumulated = 0;
        var bps = [];
        for (var i = 0; i < parts.length; i++) {
          accumulated += parts[i];
          if (i === parts.length - 1) {
            bps.push(100);
          } else {
            bps.push(Math.round((accumulated / totalWeight) * 10000) / 100);
          }
        }
        return { steps: bps.length, breakpoints: bps };
      }

      let currentMaskStep = 0;
      let currentMaskConfig = null;
      let maskLayerEl = null;
      let maskOverlayEl = null;
      let maskDividerEl = null;

      function updateMaskVisual() {
        if (!currentMaskConfig || !maskLayerEl) return;
        const p = (currentMaskStep <= 0)
          ? (currentMaskConfig.isInitialRevealed ? currentMaskConfig.breakpoints[0] : 0)
          : (currentMaskStep >= currentMaskConfig.totalSteps
              ? 100
              : currentMaskConfig.breakpoints[currentMaskConfig.isInitialRevealed ? currentMaskStep : (currentMaskStep - 1)]);

        if (currentMaskConfig.isClock) {
          const isCw = currentMaskConfig.direction === "clockwise" || currentMaskConfig.direction === "cw";
          const sweepDeg = Math.min(360, Math.max(0, (p / 100) * 360));
          const needleAngle = isCw ? (-180 + sweepDeg) : (-90 - sweepDeg);

          if (maskOverlayEl) {
            let maskGrad = "";
            if (sweepDeg <= 0) {
              maskGrad = "conic-gradient(from 0deg at 50% 50%, #000 0deg, #000 360deg)";
            } else if (sweepDeg >= 360) {
              maskGrad = "conic-gradient(from 0deg at 50% 50%, transparent 0deg, transparent 360deg)";
            } else if (isCw) {
              maskGrad = "conic-gradient(from 270deg at 50% 50%, transparent 0deg, transparent " + sweepDeg + "deg, #000 " + sweepDeg + "deg, #000 360deg)";
            } else {
              const remDeg = 360 - sweepDeg;
              maskGrad = "conic-gradient(from 0deg at 50% 50%, #000 0deg, #000 " + remDeg + "deg, transparent " + remDeg + "deg, transparent 360deg)";
            }
            maskOverlayEl.style.webkitMaskImage = maskGrad;
            maskOverlayEl.style.maskImage = maskGrad;
          }

          if (maskDividerEl) {
            maskDividerEl.style.transform = "translateY(-50%) rotate(" + needleAngle + "deg)";
            maskDividerEl.style.opacity = (p <= 0 || p >= 100) ? "0" : "1";
          }

          if (p >= 100) {
            maskLayerEl.style.opacity = "0";
            maskLayerEl.style.pointerEvents = "none";
          } else {
            maskLayerEl.style.opacity = "1";
            maskLayerEl.style.pointerEvents = "none";
          }
          return;
        }

        const isDown = currentMaskConfig.direction === "down";
        if (p >= 100) {
          maskLayerEl.style.transform = isDown ? "translate3d(0, 100%, 0)" : "translate3d(100%, 0, 0)";
          maskLayerEl.style.opacity = "0";
          maskLayerEl.style.pointerEvents = "none";
          if (maskDividerEl) maskDividerEl.style.opacity = "0";
        } else {
          maskLayerEl.style.transform = isDown ? ("translate3d(0, " + p + "%, 0)") : ("translate3d(" + p + "%, 0, 0)");
          maskLayerEl.style.opacity = "1";
          maskLayerEl.style.pointerEvents = "none";
          if (maskDividerEl) {
            maskDividerEl.style.opacity = (p <= 0) ? "0" : "1";
          }
        }
      }

      function goNext() {
        if (currentMaskConfig && currentMaskStep < currentMaskConfig.totalSteps) {
          currentMaskStep++;
          updateMaskVisual();
          return;
        }
        renderSlide(currentIndex + 1);
      }

      function goPrev() {
        if (currentMaskConfig && currentMaskStep > (currentMaskConfig.isInitialRevealed ? 1 : 0)) {
          currentMaskStep--;
          updateMaskVisual();
          return;
        }
        // FSM-9 优化：回退至上一页时传递 backward 方向，使上一页遮罩处于完全展开状态
        renderSlide(currentIndex - 1, "backward");
      }

`}function ig(){return`      function cleanCardListItemMarkdown(rawMarkdown) {
        if (!rawMarkdown) return "";
        let cleaned = rawMarkdown.replace(/^[ 	]*[-*+]s+|^[ 	]*d+.s+/, "");
        cleaned = cleaned.replace(/
[ 	]{2,4}/g, "
");
        return cleaned.trim();
      }

      function isHeadingBlock(b) {
        if (!b) return false;
        if (b.type === "h" || b.type === "NodeHeading") return true;
        if (b.subType && /^h[1-6]$/i.test(b.subType)) return true;
        const md = (b.rawMarkdown || b.content || "").trim();
        if (/^#{1,6}s+/.test(md)) return true;
        if (/^(?:[-*+]|d+.)s+#{1,6}s+/.test(md)) return true;
        return false;
      }

      function cleanColList(blocks) {
        const valid = (blocks || []).filter(b => Boolean((b.rawMarkdown || b.content || "").trim()));
        if (valid.length === 0) return valid;
        const first = valid[0];
        const md = (first.rawMarkdown || first.content || "").trim();
        const isList = /^(?:[-*+]|d+.)s+/.test(md) || first.type === "i" || first.type === "l";
        if (isList) {
          first.rawMarkdown = cleanCardListItemMarkdown(first.rawMarkdown || first.content || "");
          first.content = first.rawMarkdown;
        }
        return valid;
      }

      function renderBlock(block, extraClass) {
        const div = document.createElement("div");
        div.className = "slide-block" + (extraClass ? " " + extraClass : "");
        if (block && block.motion && block.motion.preset && block.motion.preset !== "none") {
          div.classList.add("slides-motion-" + block.motion.preset.toLowerCase());
          if (typeof block.motion.duration === "number" && block.motion.duration > 0) {
            div.style.setProperty("--motion-duration", block.motion.duration + "ms");
          }
          if (typeof block.motion.delay === "number" && block.motion.delay > 0) {
            div.style.setProperty("--motion-delay", block.motion.delay + "ms");
          }
        }
        const md = block.rawMarkdown || block.content || "";

        if (md.includes('class="slides-block-ref"') || md.includes('class="slides-ref-tag"')) {
          div.innerHTML = md;
          return div;
        }

        const CARBON_MAP = {
          'carbon:arrow-right': '<svg viewBox="0 0 32 32" width="1.2em" height="1.2em" fill="currentColor" style="display:inline-block;vertical-align:middle;"><path d="m18 6l-1.43 1.393L24.15 15H4v2h20.15l-7.58 7.573L18 26l10-10z"/></svg>',
          'carbon:arrow-left': '<svg viewBox="0 0 32 32" width="1.2em" height="1.2em" fill="currentColor" style="display:inline-block;vertical-align:middle;"><path d="m14 26l1.43-1.393L7.85 17H28v-2H7.85l7.58-7.573L14 6L4 16z"/></svg>',
          'carbon:edit': '<svg viewBox="0 0 32 32" width="1.2em" height="1.2em" fill="currentColor" style="display:inline-block;vertical-align:middle;"><path d="M2 26h28v2H2zM25.4 9c.8-.8.8-2 0-2.8l-3.6-3.6c-.8-.8-2-.8-2.8 0l-15 15V24h6.4l15-15zM20.4 4L24 7.6l-2.4 2.4l-3.6-3.6L20.4 4zM6 22v-3.6l11-11l3.6 3.6l-11 11H6z"/></svg>',
          'carbon:logo-github': '<svg viewBox="0 0 32 32" width="1.2em" height="1.2em" fill="currentColor" style="display:inline-block;vertical-align:middle;"><path fill-rule="evenodd" d="M16 2a14 14 0 0 0-4.43 27.28c.7.13 1-.3 1-.67v-2.38c-3.89.84-4.71-1.88-4.71-1.88a3.7 3.7 0 0 0-1.56-2.05c-1.27-.86.1-.85.1-.85a2.94 2.94 0 0 1 2.14 1.44a3 3 0 0 0 4.08 1.16a2.93 2.93 0 0 1 .89-1.87c-3.1-.35-6.36-1.55-6.36-6.9a5.4 5.4 0 0 1 1.44-3.75a5 5 0 0 1 .14-3.71s1.17-.38 3.85 1.43a13.3 13.3 0 0 1 7 0c2.67-1.81 3.84-1.43 3.84-1.43a5 5 0 0 1 .14 3.71a5.4 5.4 0 0 1 1.44 3.75c0 5.37-3.27 6.54-6.38 6.89a3.35 3.35 0 0 1 1.26 2.61v3.87c0 .38.26.81 1 .67A14 14 0 0 0 16 2"/></svg>'
        };

        if (/@\\w+=['"]|v-\\w+|<button|<a\\b|<carbon:|^<div/i.test(md)) {
          if (md.includes('abs-br') || md.includes('abs-bl') || md.includes('abs-tr') || md.includes('abs-tl') || md.includes('absolute')) {
            div.classList.add("slide-block--absolute");
          }
          let renderedHtml = md;
          for (const [tag, svg] of Object.entries(CARBON_MAP)) {
            const regex = new RegExp("<" + tag + "\\\\s*\\\\/?>", "gi");
            renderedHtml = renderedHtml.replace(regex, svg);
            const regexDash = new RegExp("<" + tag.replace(":", "-") + "\\\\s*\\\\/?>", "gi");
            renderedHtml = renderedHtml.replace(regexDash, svg);
          }
          div.innerHTML = renderedHtml;

          // 挂载交互事件监听
          const nextBtns = div.querySelectorAll('[\\\\@click*="nav.next"], [\\\\@click*="next"]');
          nextBtns.forEach(btn => {
            btn.style.cursor = "pointer";
            btn.addEventListener("click", (e) => {
              e.stopPropagation();
              renderSlide(currentIndex + 1);
            });
          });

          const prevBtns = div.querySelectorAll('[\\\\@click*="nav.prev"], [\\\\@click*="prev"]');
          prevBtns.forEach(btn => {
            btn.style.cursor = "pointer";
            btn.addEventListener("click", (e) => {
              e.stopPropagation();
              renderSlide(currentIndex - 1);
            });
          });

          return div;
        }

        const hasHeadingTag = /(?:^|
)s*#{1,6}s+/.test(md);
        const hMatch = md.match(/^(#{1,6})\\s+(.*)$/);

        if (hMatch) {
          const level = hMatch[1].length;
          let th = hMatch[2].trim().replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
          div.innerHTML = "<h" + level + ">" + th + "</h" + level + ">";
        }
        else if (md.startsWith("\`\`\`")) {
          const customMaxHeight = block?.attributes?.["custom-slides-max-height"] || block?.attrs?.["custom-slides-max-height"] || block?.maxHeight || "";
          const heightStyle = customMaxHeight ? ' style="max-height:' + customMaxHeight + ';overflow-y:auto;"' : "";
          div.innerHTML = "<pre" + heightStyle + "><code>" + md.slice(3, -3) + "</code></pre>";
        }
        else if (md.startsWith("> ")) div.innerHTML = "<blockquote><p>" + md.slice(2) + "</p></blockquote>";
        else if ((/<video\b/i.test(md) || (block && (block.type === "video" || block.type === "NodeVideo"))) && !/^(s*)([-*+]|d+.)s+/m.test(md) && !hasHeadingTag && !md.includes("
")) {
          div.classList.add("slide-video-container", "slide-media-container", "slide-media-block");
          const isAutoplay = block && block.attributes && block.attributes["custom-slides-autoplay"] === "true";
          const isLoop = block && block.attributes && block.attributes["custom-slides-loop"] === "true";
          const isMuted = block && block.attributes && (block.attributes["custom-slides-muted"] === "true" || isAutoplay);
          const hideControls = block && block.attributes && block.attributes["custom-slides-controls"] === "false";
          let videoHtml = md;
          if (hideControls) videoHtml = videoHtml.replace(/\bcontrols(?:="[^"]*")?/gi, "").trim();
          else if (!videoHtml.includes("controls")) videoHtml = videoHtml.replace("<video", "<video controls");
          if (isAutoplay && !videoHtml.includes("autoplay")) videoHtml = videoHtml.replace("<video", "<video autoplay playsinline");
          if (isLoop && !videoHtml.includes("loop")) videoHtml = videoHtml.replace("<video", "<video loop");
          if (isMuted && !videoHtml.includes("muted")) videoHtml = videoHtml.replace("<video", "<video muted");
          videoHtml = videoHtml.replace("<video", '<video class="slide-video-player"');
          div.setAttribute("data-autoplay", isAutoplay ? "true" : "false");
          div.innerHTML = videoHtml;
        }
        else if (/^(s*)([-*+]|d+.)s+/m.test(md) || (md.includes("
") && /^(s*)([-*+]|d+.)s+/m.test(md.split("
").slice(1).join("
")))) {
          div.classList.add("pdf-list-item");
          const lines = md.split("
");
          let isOrdered = false;
          const items = [];
          const leadLines = [];
          for (let i = 0; i < lines.length; i++) {
            const line = lines[i];
            const tr = line.trim();
            if (!tr || /^{:.*?}$/.test(tr)) continue;
            const um = line.match(/^(s*)[-*+]s+(.*)$/);
            const om = line.match(/^(s*)d+.s+(.*)$/);
            if (um) {
              const indent = um[1].length;
              items.push({ type: "unordered", level: Math.floor(indent / 2), text: um[2], media: [] });
              continue;
            }
            if (om) {
              if (items.length === 0) isOrdered = true;
              const indent = om[1].length;
              items.push({ type: "ordered", level: Math.floor(indent / 2), text: om[2], media: [] });
              continue;
            }
            if (items.length > 0) {
              const im = tr.match(/^![(.*?)]((.*?))(?:{:?[^}]*})?$/);
              if (im) {
                const isGif = /.gif(?:?|$)/i.test(im[2]);
                items[items.length - 1].media.push('<div class="slide-list-media"><img alt="' + im[1] + '" src="' + im[2] + '" class="' + (isGif ? 'list-item-gif' : 'list-item-img') + '" /></div>');
                continue;
              }
              const hm = tr.match(/^<img\b[sS]*?/?>$/i);
              if (hm) {
                const cleanTr = tr.replace(/s+style="[^"]*"/gi, "");
                items[items.length - 1].media.push('<div class="slide-list-media">' + cleanTr + '</div>');
                continue;
              }
              if (/<video\b/i.test(tr)) {
                let vHtml = tr;
                if (!/</video>/i.test(vHtml)) {
                  while (i + 1 < lines.length && !/</video>/i.test(vHtml)) {
                    i++;
                    vHtml += " " + lines[i].trim();
                  }
                }
                const isAutoplay = block && block.attributes && block.attributes["custom-slides-autoplay"] === "true";
                const isLoop = block && block.attributes && block.attributes["custom-slides-loop"] === "true";
                const isMuted = block && block.attributes && (block.attributes["custom-slides-muted"] === "true" || isAutoplay);
                const hideControls = block && block.attributes && block.attributes["custom-slides-controls"] === "false";
                if (hideControls) vHtml = vHtml.replace(/\bcontrols(?:="[^"]*")?/gi, "").trim();
                else if (!vHtml.includes("controls")) vHtml = vHtml.replace("<video", "<video controls");
                if (isAutoplay && !vHtml.includes("autoplay")) vHtml = vHtml.replace("<video", "<video autoplay playsinline");
                if (isLoop && !vHtml.includes("loop")) vHtml = vHtml.replace("<video", "<video loop");
                if (isMuted && !vHtml.includes("muted")) vHtml = vHtml.replace("<video", "<video muted");
                vHtml = vHtml.replace("<video", '<video class="slide-video-player"');
                items[items.length - 1].media.push('<div class="slide-list-media slide-video-container slide-media-container" data-autoplay="' + (isAutoplay ? 'true' : 'false') + '">' + vHtml + '</div>');
                continue;
              }
              items[items.length - 1].text += "
" + tr;
            } else {
              leadLines.push(tr);
            }
          }

          let leadHtml = "";
          if (leadLines.length > 0) {
            const lParts = [];
            const firstL = leadLines[0];
            const fhm = firstL.match(/^(#{1,6})s+(.*)$/);
            if (fhm) {
              const lvl = fhm[1].length;
              let th = fhm[2].trim().replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
              lParts.push('<h' + lvl + ' class="slide-list-item-title">' + th + '</h' + lvl + '>');
            } else {
              let th = firstL.trim().replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
              lParts.push('<p class="slide-list-item-title">' + th + '</p>');
            }
            if (leadLines.length > 1) {
              const dLines = leadLines.slice(1);
              let pL = [];
              const flushLeadP = () => {
                if (pL.length > 0) {
                  let txt = pL.map(l => l.replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>")).join("<br/>");
                  lParts.push('<p class="slide-list-item-desc">' + txt + '</p>');
                  pL = [];
                }
              };
              for (const l of dLines) {
                const hm = l.match(/^(#{1,6})s+(.*)$/);
                if (hm) {
                  flushLeadP();
                  const lvl = hm[1].length;
                  let th = hm[2].trim().replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
                  lParts.push('<h' + lvl + ' class="slide-list-item-title">' + th + '</h' + lvl + '>');
                } else {
                  pL.push(l);
                }
              }
              flushLeadP();
            }
            leadHtml = lParts.join("
") + "
";
          }

          const tag = isOrdered ? "ol" : "ul";
          const listCls = isOrdered ? "pdf-list pdf-list--ordered" : "pdf-list pdf-list--unordered";
          const liHtml = items.map(it => {
            const med = it.media && it.media.length ? "
" + it.media.join("
") : "";
            const lines = (it.text || "").split("
").map(l => l.trim()).filter(Boolean);
            const hasHeading = lines.some(l => /^#{1,6}s+/.test(l));
            const lvl = it.level || 0;
            const nStyle = lvl > 0 ? ' style="margin-left:' + (lvl * 1.25).toFixed(2) + 'em;' + (it.type === 'unordered' ? 'list-style-type:' + (lvl % 2 === 1 ? 'circle' : 'square') + ' !important;' : '') + '"' : "";
            const nClass = lvl > 0 ? " slide-list-item--nested" : "";
            const clsAttr = nClass ? ' class="' + nClass.trim() + '"' : "";
            if (!hasHeading) {
              let h = lines.map(l => l.replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>")).join("<br/>");
              return '<li' + clsAttr + nStyle + '>' + h + med + '</li>';
            }
            const parts = [];
            let pLines = [];
            const flushP = () => {
              if (pLines.length > 0) {
                let ph = pLines.map(l => l.replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>")).join("<br/>");
                parts.push('<p class="slide-list-item-desc">' + ph + '</p>');
                pLines = [];
              }
            };
            for (const l of lines) {
              const hm = l.match(/^(#{1,6})s+(.*)$/);
              if (hm) {
                flushP();
                const hl = hm[1].length;
                let th = hm[2].trim().replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
                parts.push('<h' + hl + ' class="slide-list-item-title">' + th + '</h' + hl + '>');
              } else {
                pLines.push(l);
              }
            }
            flushP();
            return '<li' + clsAttr + nStyle + '>' + parts.join("
") + med + '</li>';
          }).join("
");
          div.innerHTML = leadHtml + "<" + tag + " class="" + listCls + "">
" + liHtml + "
</" + tag + ">";
        }
        else {
          // 复合块（包含换行、标题或媒体）高保真解析
          const lines = md.split(/\r?
/);
          const subBlocks = [];
          let current = [];
          for (let i = 0; i < lines.length; i++) {
            const line = lines[i];
            const trimmed = line.trim();
            if (/^#{1,6}s+/.test(trimmed)) {
              if (current.length > 0) { subBlocks.push(current.join("
")); current = []; }
              subBlocks.push(trimmed);
              continue;
            }
            if (!trimmed) {
              if (current.length > 0) { subBlocks.push(current.join("
")); current = []; }
              continue;
            }
            if (/^![.*?](.*?)$/.test(trimmed)) {
              if (current.length > 0) { subBlocks.push(current.join("
")); current = []; }
              subBlocks.push(trimmed);
              continue;
            }
            if (/<video\b/i.test(trimmed)) {
              if (current.length > 0) { subBlocks.push(current.join("
")); current = []; }
              let vRaw = trimmed;
              if (!/</video>/i.test(vRaw)) {
                while (i + 1 < lines.length && !/</video>/i.test(vRaw)) {
                  i++;
                  vRaw += "
" + lines[i];
                }
              }
              subBlocks.push(vRaw);
              continue;
            }
            current.push(line);
          }
          if (current.length > 0) subBlocks.push(current.join("
"));

          if (subBlocks.length > 1 || (subBlocks.length === 1 && /^#{1,6}s+/.test(subBlocks[0].trim()))) {
            let isFirstParagraph = true;
            const htmlParts = subBlocks.map(sub => {
              const t = sub.trim();
              if (!t) return "";
              const hm = t.match(/^(#{1,6})s+(.*)$/);
              if (hm) {
                isFirstParagraph = false;
                const hl = hm[1].length;
                let th = hm[2].trim().replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
                return '<h' + hl + ' class="slide-list-item-title">' + th + '</h' + hl + '>';
              }
              const im = t.match(/^![(.*?)]((.*?))$/);
              if (im) {
                return '<div class="slide-media-block slide-media-container slide-list-media"><img alt="' + im[1] + '" src="' + im[2] + '" class="slide-media-img" /></div>';
              }
              if (/<video\b/i.test(t)) {
                return '<div class="slide-media-block slide-video-container slide-media-container">' + t + '</div>';
              }
              if (isFirstParagraph) {
                isFirstParagraph = false;
                const subLines = t.split(/\r?
/).map(l => l.trim()).filter(Boolean);
                if (subLines.length === 1) {
                  let ph = subLines[0].replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
                  return '<p class="slide-list-item-title">' + ph + '</p>';
                }
                let titleHtml = subLines[0].replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
                let descHtml = subLines.slice(1).map(l => l.replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>")).join("<br/>");
                return '<p class="slide-list-item-title">' + titleHtml + '</p>
<p class="slide-list-item-desc">' + descHtml + '</p>';
              }
              let ph = t.replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
              return '<p class="slide-list-item-desc">' + ph + '</p>';
            }).filter(Boolean);
            div.innerHTML = htmlParts.join("
");
          } else {
            const imgMatch = md.match(/!\\[(.*?)\\]\\((.*?)\\)/);
            if (imgMatch) {
              div.classList.add("slide-media-container", "slide-media-block", "slide-block--image");
              div.innerHTML = '<img alt="' + imgMatch[1] + '" src="' + imgMatch[2] + '" class="slide-media-img" />';
            } else {
              let html = md.replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
              const pCls = (block && block.isColFirst) ? ' class="slide-list-item-title"' : '';
              div.innerHTML = "<p" + pCls + ">" + html + "</p>";
            }
          }
        }
        return div;
      }

`}function ng(){return`      function renderSlide(idx, direction) {
        if (slides.length === 0) return;
        currentIndex = Math.max(0, Math.min(idx, slides.length - 1));
        const slide = slides[currentIndex];
        pageNum.textContent = (currentIndex + 1) + " / " + slides.length;

        const pageSp = slide.frontmatter?.spacing;
        const currentSpacing = (pageSp && pageSp !== "inherit") ? pageSp : (data.config?.spacing || "normal");
        container.className = "slide-content layout-" + (slide.frontmatter?.layout || "default") + " spacing-" + currentSpacing;
        if (viewport) viewport.setAttribute("data-spacing", currentSpacing);
        container.innerHTML = "";

        const z = typeof slide.frontmatter?.zoom === "number" && slide.frontmatter.zoom > 0 ? slide.frontmatter.zoom : 1;
        if (z !== 1) {
          container.style.width = (100 / z) + "%";
          container.style.height = (100 / z) + "%";
          container.style.transformOrigin = "top left";
          container.style.transform = "scale(" + z + ")";
        } else {
          container.style.width = "100%";
          container.style.height = "100%";
          container.style.transform = "none";
        }

        maskOverlayEl = null;
        maskDividerEl = null;
        const maskDir = slide.frontmatter?.mask;
        const isClock = maskDir === "clockwise" || maskDir === "counter-clockwise" || maskDir === "cw" || maskDir === "ccw";
        if (maskDir === "down" || maskDir === "right" || isClock) {
          const isClover = slide.frontmatter?.layout === "clover";
          const ratioInfo = parseMaskRatio(slide.frontmatter.maskRatio, (isClock || isClover) ? 4 : 2);
          const isInitRev = slide.frontmatter.maskInitial === "revealed";
          currentMaskConfig = {
            direction: isClock ? ((maskDir === "cw" || maskDir === "clockwise") ? "clockwise" : "counter-clockwise") : maskDir,
            isClock: isClock,
            totalSteps: isInitRev ? Math.max(0, ratioInfo.steps - 1) : ratioInfo.steps,
            rawSteps: ratioInfo.steps,
            breakpoints: ratioInfo.breakpoints,
            isInitialRevealed: isInitRev,
            style: slide.frontmatter.maskStyle || "solid",
          };
          // FSM-9 优化：后退进入历史页时，遮罩与逐步呈现处于全部揭开完成状态，避免上一页重新变为全黑遮盖
          currentMaskStep = (direction === "backward") ? currentMaskConfig.totalSteps : 0;
        } else {
          currentMaskConfig = null;
          currentMaskStep = 0;
        }

        function createMaskElements() {
          if (!currentMaskConfig) return null;
          const layer = document.createElement("div");
          layer.className = "slides-mask-layer slides-mask-layer--" + currentMaskConfig.style + " slides-mask-layer--" + currentMaskConfig.direction + (currentMaskConfig.isClock ? " slides-mask-layer--clock" : "");
          const overlay = document.createElement("div");
          overlay.className = "slides-mask-overlay";
          const divider = document.createElement("div");
          divider.className = "slides-mask-divider-line" + (currentMaskConfig.isClock ? " slides-mask-divider-line--clock" : "");
          divider.style.opacity = "0";
          if (currentMaskConfig.isClock) {
            const isCw = currentMaskConfig.direction === "clockwise" || currentMaskConfig.direction === "cw";
            divider.style.transform = isCw ? "translateY(-50%) rotate(-180deg)" : "translateY(-50%) rotate(-90deg)";
          }
          layer.appendChild(overlay);
          layer.appendChild(divider);
          maskLayerEl = layer;
          maskOverlayEl = overlay;
          maskDividerEl = divider;
          return { layer, overlay, divider };
        }

        if (slide.frontmatter?.layout === "two-cols") {
          const bodyWrap = document.createElement("div");
          bodyWrap.className = "slides-mask-body-container" + (currentMaskConfig ? " slides-mask-body-container--has-mask" : "");
          bodyWrap.style.display = "flex";
          bodyWrap.style.flexDirection = "row";
          bodyWrap.style.gap = "2rem";
          bodyWrap.style.width = "100%";
          bodyWrap.style.height = "100%";

          const leftCol = document.createElement("div");
          leftCol.className = "two-cols-left";
          const rightCol = document.createElement("div");
          rightCol.className = "two-cols-right";

          const blocks = (slide.blocks || []).filter(b => b.slot !== "slot-divider-right");
          let leftList = [];
          let rightList = [];
          for (const block of blocks) {
            if (block.slot === "right") rightList.push(block);
            else leftList.push(block);
          }
          leftList = cleanColList(leftList);
          rightList = cleanColList(rightList);
          const isCover = slide.frontmatter?.layout === "cover";
          const leftFirstH = !isCover ? leftList.find(isHeadingBlock) : null;
          const rightFirstH = !isCover ? rightList.find(isHeadingBlock) : null;
          for (const b of leftList) leftCol.appendChild(renderBlock(b, b === leftFirstH ? "slides-col-first-heading-block" : ""));
          for (const b of rightList) rightCol.appendChild(renderBlock(b, b === rightFirstH ? "slides-col-first-heading-block" : ""));
          bodyWrap.appendChild(leftCol);
          bodyWrap.appendChild(rightCol);

          const maskEls = createMaskElements();
          if (maskEls) {
            bodyWrap.appendChild(maskEls.layer);
          }
          container.appendChild(bodyWrap);
        } else if (slide.frontmatter?.layout === "cols-header" || slide.frontmatter?.layout === "two-cols-header" || slide.frontmatter?.layout === "three-cols-header" || slide.frontmatter?.layout === "clover") {
          const isCover = slide.frontmatter?.layout === "cover";
          const isClover = slide.frontmatter?.layout === "clover";
          const blocks = (slide.blocks || []).filter(b => b.slot !== "slot-divider-right");
          let headerBlocks = blocks.filter(b => b.slot === "header");
          if (headerBlocks.length === 0 && blocks.length > 0) {
            const candidate = blocks.find(b => b.type === "h" && (!b.slot || b.slot === "default"));
            if (candidate) headerBlocks = [candidate];
          }
          const rem = blocks.filter(b => !headerBlocks.includes(b));

          let targetCols = isClover ? 4 : 2;
          if (isClover) {
            targetCols = 4;
          } else if (slide.frontmatter?.layout === "three-cols-header") {
            targetCols = 3;
          } else if (slide.frontmatter?.layout === "two-cols-header") {
            targetCols = 2;
          } else {
            let maxCol = 0;
            for (const b of rem) {
              const m = (b.slot || "").match(/^col-(d+)$/i);
              if (m) maxCol = Math.max(maxCol, parseInt(m[1], 10));
            }
            if (maxCol >= 2) {
              targetCols = maxCol;
            } else if (slide.frontmatter?.layoutRatio) {
              const r = slide.frontmatter.layoutRatio.trim();
              if (r.includes(":")) {
                const parts = r.split(":").map(p => parseFloat(p.trim())).filter(n => !isNaN(n) && n > 0);
                if (parts.length >= 2) targetCols = parts.length;
              }
            }
          }

          const hasColSlots = rem.some(b => b.slot && /^col-d+$/i.test(b.slot));
          const isSuperBlockCols = isClover || hasColSlots;

          const containerDiv = document.createElement("div");
          containerDiv.className = (isClover ? "layout-clover-container" : ("layout-cols-header-container " + (targetCols === 2 ? "layout-two-cols-header-container" : (targetCols === 3 ? "layout-three-cols-header-container" : "")))) + (isSuperBlockCols ? " has-superblock-cols" : "");
          const headerDiv = document.createElement("div");
          headerDiv.className = "layout-header-section";
          const gridDiv = document.createElement("div");
          gridDiv.className = (isClover ? "layout-clover-grid pdf-clover-wrapper" : ("layout-cols-wrapper layout-cols-grid " + (targetCols === 2 ? "pdf-two-cols-wrapper layout-two-cols-grid" : (targetCols === 3 ? "pdf-three-cols-wrapper layout-three-cols-grid" : "")))) + (isSuperBlockCols ? " has-superblock-cols" : "") + (currentMaskConfig ? " slides-mask-body-container slides-mask-body-container--has-mask" : "");

          const gridCols = isClover ? "repeat(2, minmax(0, 1fr))" : parseRatioToGridCols(slide.frontmatter?.layoutRatio, targetCols);
          if (gridCols) gridDiv.style.gridTemplateColumns = gridCols;
          if (isClover) gridDiv.style.gridTemplateRows = "repeat(2, minmax(0, 1fr))";

          let colsList = [];
          for (let i = 0; i < targetCols; i++) colsList.push([]);
          const hasExplicitCols = rem.some(b => b.slot && (b.slot.startsWith("col-") || b.slot === "left" || b.slot === "right" || b.slot === "center"));
          if (hasExplicitCols && rem.length > 1) {
            for (const b of rem) {
              let idx = 0;
              if (b.slot === "left" || b.slot === "col-1") idx = 0;
              else if (b.slot === "center" || b.slot === "col-2") idx = 1;
              else if (b.slot === "right") idx = targetCols === 2 ? 1 : targetCols - 1;
              else {
                const m = (b.slot || "").match(/^col-(d+)$/i);
                if (m) idx = Math.min(targetCols - 1, Math.max(0, parseInt(m[1], 10) - 1));
              }
              colsList[idx].push(b);
            }
            const hasExplicitColN = rem.some(b => /^col-d+$/i.test((b.slot || "").trim()));
            if (!hasExplicitColN && colsList[0].length === 0) {
              const nonEmptyCols = colsList.filter(c => c.length > 0);
              if (nonEmptyCols.length === 1) {
                colsList = [nonEmptyCols[0], ...Array.from({ length: targetCols - 1 }, () => [])];
              }
            }
          } else if (rem.length === 1) {
            colsList[0] = [rem[0]];
          } else {
            let cur = 0;
            for (let i = 0; i < targetCols; i++) {
              const remainingCols = targetCols - i;
              const remainingItems = rem.length - cur;
              const take = Math.ceil(remainingItems / remainingCols);
              colsList[i] = rem.slice(cur, cur + take);
              cur += take;
            }
          }

          const headerFirstH = !isCover ? headerBlocks.find(isHeadingBlock) : null;
          for (const b of headerBlocks) headerDiv.appendChild(renderBlock(b, b === headerFirstH ? "slides-page-first-heading-block" : ""));
          containerDiv.appendChild(headerDiv);

          colsList.forEach((colBlocks, idx) => {
            const colDiv = document.createElement("div");
            colDiv.className = "pdf-col pdf-col--" + (idx + 1) + " col-" + (idx + 1) + (targetCols === 2 && idx === 0 ? " pdf-col--left" : "") + (targetCols === 2 && idx === 1 ? " pdf-col--right" : "");
            const cleaned = cleanColList(colBlocks);
            const colFirstH = !isCover ? (cleaned.find(isHeadingBlock) || cleaned[0]) : null;
            for (const b of cleaned) colDiv.appendChild(renderBlock(b, b === colFirstH ? "slides-col-first-heading-block" : ""));
            gridDiv.appendChild(colDiv);
          });

          const maskEls = createMaskElements();
          if (maskEls) {
            gridDiv.appendChild(maskEls.layer);
          }

          containerDiv.appendChild(gridDiv);
          container.appendChild(containerDiv);
        } else if (slide.frontmatter?.layout === "image-right" || slide.frontmatter?.layout === "image-left") {
          const isImageRight = slide.frontmatter?.layout === "image-right";
          const isCover = slide.frontmatter?.layout === "cover";
          const allBlocks = slide.blocks || [];
          const pageFirstH = !isCover ? allBlocks.find(isHeadingBlock) : null;

          if (pageFirstH) {
            container.appendChild(renderBlock(pageFirstH, "slides-page-first-heading-block"));
          }

          const bodyWrap = document.createElement("div");
          bodyWrap.className = "slides-mask-body-container" + (currentMaskConfig ? " slides-mask-body-container--has-mask" : "");
          bodyWrap.style.display = "flex";
          bodyWrap.style.flexDirection = isImageRight ? "row" : "row-reverse";
          bodyWrap.style.gap = "2rem";
          bodyWrap.style.width = "100%";
          bodyWrap.style.height = "100%";
          bodyWrap.style.minHeight = "0";
          bodyWrap.style.flex = "1";

          const contentCol = document.createElement("div");
          contentCol.className = isImageRight ? "image-right-content" : "image-left-content";

          for (const block of allBlocks) {
            if (block === pageFirstH) continue;
            contentCol.appendChild(renderBlock(block, ""));
          }

          const imgCol = document.createElement("div");
          imgCol.className = isImageRight ? "image-right-img-container" : "image-left-img-container";
          const img = document.createElement("img");
          img.className = isImageRight ? "image-right-img" : "image-left-img";
          img.src = slide.frontmatter?.image || slide.frontmatter?.background || "";
          img.alt = "Slide cover";
          img.onerror = function() {
            this.src = "https://fastly.jsdelivr.net/gh/slidevjs/slidev-covers@main/static/2HmfbSpvcos.webp";
          };
          imgCol.appendChild(img);

          bodyWrap.appendChild(contentCol);
          bodyWrap.appendChild(imgCol);

          const maskEls = createMaskElements();
          if (maskEls) {
            bodyWrap.appendChild(maskEls.layer);
          }
          container.appendChild(bodyWrap);
        } else {
          const isCover = slide.frontmatter?.layout === "cover";
          const validBlocks = (slide.blocks || []).filter(b => b.slot !== "slot-divider-right");
          const pageFirstH = !isCover ? validBlocks.find(isHeadingBlock) : null;

          if (pageFirstH) {
            container.appendChild(renderBlock(pageFirstH, "slides-page-first-heading-block"));
          }

          const bodyWrap = document.createElement("div");
          bodyWrap.className = "slides-mask-body-container" + (currentMaskConfig ? " slides-mask-body-container--has-mask" : "");

          for (const block of validBlocks) {
            if (block === pageFirstH) continue;
            bodyWrap.appendChild(renderBlock(block, ""));
          }

          const maskEls = createMaskElements();
          if (maskEls) {
            bodyWrap.appendChild(maskEls.layer);
          }
          container.appendChild(bodyWrap);
        }

        updateMaskVisual();
        if (currentMaskConfig && maskLayerEl) {
          requestAnimationFrame(() => {
            if (maskLayerEl) void maskLayerEl.offsetHeight;
          });
        }

        function syncAutoplayVideos() {
          const doSync = () => {
            const videos = container.querySelectorAll("video");
            videos.forEach((v) => {
              const box = v.closest("[data-autoplay]");
              const isAuto = v.hasAttribute("autoplay") || v.autoplay || (box && box.getAttribute("data-autoplay") === "true");
              if (isAuto) {
                v.muted = true;
                v.defaultMuted = true;
                v.setAttribute("muted", "");
                v.playsInline = true;
                v.setAttribute("playsinline", "");
                const playFn = () => {
                  if (!v.paused) return;
                  v.muted = true;
                  v.defaultMuted = true;
                  const p = v.play();
                  if (p !== undefined) {
                    p.catch(() => {
                      v.muted = true;
                      v.defaultMuted = true;
                      setTimeout(() => { if (v.paused) v.play().catch(() => {}); }, 150);
                    });
                  }
                };
                playFn();
                if (!v.__autoplayBound) {
                  v.__autoplayBound = true;
                  v.addEventListener("loadedmetadata", playFn);
                  v.addEventListener("canplay", playFn);
                }
              }
            });
          };
          setTimeout(doSync, 60);
          setTimeout(doSync, 200);
        }
        syncAutoplayVideos();
      }

      // Lightbox 控制逻辑
      const lightbox = document.getElementById("slides-lightbox");
      const lightboxContent = document.getElementById("lightbox-content");
      const lightboxClose = document.getElementById("lightbox-close");
      let isLightboxOpen = false;

`}function sg(){return`      let lightboxScale = 1.0;
      let lightboxTranslateX = 0;
      let lightboxTranslateY = 0;
      let isLightboxDragging = false;
      let lightboxDragStartX = 0;
      let lightboxDragStartY = 0;
      let lightboxInitialTx = 0;
      let lightboxInitialTy = 0;
      let lightboxHasMoved = false;
      let lightboxMediaType = "";

      function updateLightboxImgTransform(animate) {
        if (!lightboxContent) return;
        const img = lightboxContent.querySelector(".slides-lightbox-img");
        if (!img) return;
        img.style.transformOrigin = "center center";
        img.style.transform = "translate(" + lightboxTranslateX + "px, " + lightboxTranslateY + "px) scale(" + lightboxScale + ")";
        img.style.transition = animate ? "transform 0.12s cubic-bezier(0.16, 1, 0.3, 1)" : "none";
        img.style.cursor = lightboxScale > 1.0 ? (isLightboxDragging ? "grabbing" : "grab") : "zoom-in";
      }

      function resetLightboxZoom() {
        lightboxScale = 1.0;
        lightboxTranslateX = 0;
        lightboxTranslateY = 0;
        isLightboxDragging = false;
        lightboxHasMoved = false;
        updateLightboxImgTransform(false);
      }

      function openLightbox(type, src, alt) {
        if (!lightbox || !lightboxContent) return;
        lightboxContent.innerHTML = "";
        lightboxMediaType = type;
        resetLightboxZoom();
        if (type === "video") {
          const v = document.createElement("video");
          v.className = "slides-lightbox-video";
          v.src = src;
          v.controls = true;
          v.autoplay = true;
          v.playsInline = true;
          lightboxContent.appendChild(v);
        } else {
          const img = document.createElement("img");
          img.className = "slides-lightbox-img";
          img.src = src;
          img.alt = alt || "";
          lightboxContent.appendChild(img);
          updateLightboxImgTransform(false);
        }
        lightbox.classList.add("active");
        isLightboxOpen = true;
      }

      function closeLightbox() {
        if (!lightbox) return;
        const v = lightbox.querySelector("video");
        if (v) v.pause();
        lightbox.classList.remove("active");
        if (lightboxContent) lightboxContent.innerHTML = "";
        isLightboxOpen = false;
        lightboxMediaType = "";
        resetLightboxZoom();
      }

      function handleLightboxWheel(e) {
        if (!lightboxContent || lightboxMediaType !== "image") return;
        const img = lightboxContent.querySelector(".slides-lightbox-img");
        if (!img) return;
        e.preventDefault();
        e.stopPropagation();
        if (Math.abs(e.deltaY) < 1) return;

        const factor = e.deltaY < 0 ? 1.2 : 1 / 1.2;
        const currentScale = lightboxScale;
        let nextScale = currentScale * factor;

        if (nextScale <= 1.02) {
          resetLightboxZoom();
          return;
        }
        if (nextScale > 5.0) {
          nextScale = 5.0;
        }

        const rect = img.getBoundingClientRect();
        const currentCenterX = rect.left + rect.width / 2;
        const currentCenterY = rect.top + rect.height / 2;
        const origCenterX = currentCenterX - lightboxTranslateX;
        const origCenterY = currentCenterY - lightboxTranslateY;

        const nextTx = (e.clientX - origCenterX) * (1 - nextScale / currentScale) + lightboxTranslateX * (nextScale / currentScale);
        const nextTy = (e.clientY - origCenterY) * (1 - nextScale / currentScale) + lightboxTranslateY * (nextScale / currentScale);

        lightboxTranslateX = Math.round(nextTx * 10) / 10;
        lightboxTranslateY = Math.round(nextTy * 10) / 10;
        lightboxScale = Math.round(nextScale * 1000) / 1000;
        updateLightboxImgTransform(true);
      }

      if (lightboxContent) {
        lightboxContent.addEventListener("pointerdown", (e) => {
          if (e.button !== 0 || lightboxMediaType !== "image" || lightboxScale <= 1.0) return;
          const img = lightboxContent.querySelector(".slides-lightbox-img");
          if (!img || (e.target !== img && !img.contains(e.target))) return;
          e.preventDefault();
          e.stopPropagation();
          isLightboxDragging = true;
          lightboxDragStartX = e.clientX;
          lightboxDragStartY = e.clientY;
          lightboxInitialTx = lightboxTranslateX;
          lightboxInitialTy = lightboxTranslateY;
          lightboxHasMoved = false;
          if (img.setPointerCapture) {
            try { img.setPointerCapture(e.pointerId); } catch (_) {}
          }
          updateLightboxImgTransform(false);
        });

        window.addEventListener("pointermove", (e) => {
          if (!isLightboxDragging || lightboxMediaType !== "image") return;
          e.preventDefault();
          e.stopPropagation();
          const dx = e.clientX - lightboxDragStartX;
          const dy = e.clientY - lightboxDragStartY;
          if (Math.abs(dx) > 3 || Math.abs(dy) > 3) {
            lightboxHasMoved = true;
          }
          lightboxTranslateX = Math.round((lightboxInitialTx + dx) * 10) / 10;
          lightboxTranslateY = Math.round((lightboxInitialTy + dy) * 10) / 10;
          updateLightboxImgTransform(false);
        });

        const onLightboxPointerEnd = (e) => {
          if (!isLightboxDragging) return;
          isLightboxDragging = false;
          const img = lightboxContent ? lightboxContent.querySelector(".slides-lightbox-img") : null;
          if (img && img.releasePointerCapture) {
            try { img.releasePointerCapture(e.pointerId); } catch (_) {}
          }
          updateLightboxImgTransform(false);
        };
        window.addEventListener("pointerup", onLightboxPointerEnd);
        window.addEventListener("pointercancel", onLightboxPointerEnd);

        lightboxContent.addEventListener("dblclick", (e) => {
          if (lightboxMediaType !== "image") return;
          const img = lightboxContent.querySelector(".slides-lightbox-img");
          if (!img || (e.target !== img && !img.contains(e.target))) return;
          e.preventDefault();
          e.stopPropagation();
          if (lightboxScale > 1.05 || lightboxTranslateX !== 0 || lightboxTranslateY !== 0) {
            resetLightboxZoom();
          } else {
            const targetScale = 2.0;
            const rect = img.getBoundingClientRect();
            const currentCenterX = rect.left + rect.width / 2;
            const currentCenterY = rect.top + rect.height / 2;
            const origCenterX = currentCenterX - lightboxTranslateX;
            const origCenterY = currentCenterY - lightboxTranslateY;
            lightboxTranslateX = Math.round(((e.clientX - origCenterX) * (1 - targetScale / 1.0)) * 10) / 10;
            lightboxTranslateY = Math.round(((e.clientY - origCenterY) * (1 - targetScale / 1.0)) * 10) / 10;
            lightboxScale = targetScale;
            updateLightboxImgTransform(true);
          }
        });
      }

      if (lightboxClose) {
        lightboxClose.addEventListener("click", (e) => {
          e.stopPropagation();
          closeLightbox();
        });
      }
      if (lightbox) {
        lightbox.addEventListener("click", (e) => {
          if (e.target === lightbox || e.target === lightboxClose) {
            if (lightboxHasMoved) {
              lightboxHasMoved = false;
              return;
            }
            e.stopPropagation();
            closeLightbox();
          }
        });
      }

      btnPrev.addEventListener("click", () => goPrev());
      btnNext.addEventListener("click", () => goNext());
      btnFullscreen.addEventListener("click", () => {
        if (!document.fullscreenElement) {
          document.documentElement.requestFullscreen().then(() => updateScale()).catch(() => {});
        } else {
          document.exitFullscreen().then(() => updateScale()).catch(() => {});
        }
      });

      // 「数字+回车」跳页输入状态：数字缓冲实时回显，Esc/超时清空，越界红色抖动提示
      let jumpDisplay = "";
      let jumpInvalid = false;
      let jumpIdleTimer = null;
      let jumpFlashTimer = null;

`}function og(){return`      function hideJumpIndicator() {
        jumpDisplay = "";
        jumpInvalid = false;
        jumpBadge.style.display = "none";
        jumpBadge.classList.remove("is-invalid");
        if (jumpIdleTimer) { clearTimeout(jumpIdleTimer); jumpIdleTimer = null; }
        if (jumpFlashTimer) { clearTimeout(jumpFlashTimer); jumpFlashTimer = null; }
      }

      function renderJumpBadge() {
        jumpBadge.textContent = jumpDisplay;
        jumpBadge.style.display = jumpDisplay ? "block" : "none";
        jumpBadge.classList.toggle("is-invalid", jumpInvalid);
      }

      function armJumpIdleTimer() {
        if (jumpIdleTimer) clearTimeout(jumpIdleTimer);
        jumpIdleTimer = setTimeout(hideJumpIndicator, 1500);
      }

      function flashJumpInvalid() {
        if (jumpIdleTimer) { clearTimeout(jumpIdleTimer); jumpIdleTimer = null; }
        jumpInvalid = true;
        renderJumpBadge();
        if (jumpFlashTimer) clearTimeout(jumpFlashTimer);
        jumpFlashTimer = setTimeout(hideJumpIndicator, 500);
      }

      function isEditableKeyTarget(t) {
        if (!t || !t.tagName) return false;
        return t.tagName === "INPUT" || t.tagName === "TEXTAREA" || t.tagName === "SELECT" || t.isContentEditable === true;
      }

`}function rg(){return`      function getSlideOverviewTitle(slide) {
        const fm = slide?.frontmatter || {};
        if (fm.title) return String(fm.title);
        const blocks = slide?.blocks || [];
        for (const b of blocks) {
          if (b.type === "h" || /^h[1-6]$/i.test(b.subType || "")) {
            const md = (b.rawMarkdown || b.content || "").trim();
            return md.replace(/^#{1,6}s+/, "").replace(/[*_\`]/g, "").slice(0, 40);
          }
        }
        return "";
      }

      // 把任意一页渲染为静态缩略图：复用 renderBlock 与主渲染同名版式类，导出样式自动生效
      function buildOverviewThumbInto(canvas, slide) {
        const fm = slide.frontmatter || {};
        const layout = fm.layout || "default";
        const blocks = (slide.blocks || []).filter((b) => b.slot !== "slot-divider-right");
        let headerBlocks = blocks.filter((b) => b.slot === "header");
        if (headerBlocks.length === 0 && blocks.length > 0) {
          const candidate = blocks.find((b) => b.type === "h" && (!b.slot || b.slot === "default"));
          if (candidate) headerBlocks = [candidate];
        }
        const rem = blocks.filter((b) => !headerBlocks.includes(b));
        let bodyEl = null;

        if (layout === "cols-header" || layout === "two-cols-header" || layout === "three-cols-header" || layout === "clover") {
          const isClover = layout === "clover";
          let targetCols = isClover ? 4 : 2;
          if (layout === "three-cols-header") targetCols = 3;
          else if (layout === "two-cols-header") targetCols = 2;
          else if (!isClover) {
            let maxCol = 0;
            for (const b of rem) {
              const m = (b.slot || "").match(/^col-(d+)$/i);
              if (m) maxCol = Math.max(maxCol, parseInt(m[1], 10));
            }
            if (maxCol >= 2) targetCols = maxCol;
            else if (fm.layoutRatio) {
              const r = String(fm.layoutRatio).trim();
              if (r.includes(":")) {
                const parts = r.split(":").map((p) => parseFloat(p.trim())).filter((n) => !isNaN(n) && n > 0);
                if (parts.length >= 2) targetCols = parts.length;
              }
            }
          }
          const hasColSlots = rem.some((b) => b.slot && /^col-d+$/i.test(b.slot));
          const containerDiv = document.createElement("div");
          containerDiv.className = (isClover ? "layout-clover-container" : ("layout-cols-header-container " + (targetCols === 2 ? "layout-two-cols-header-container" : (targetCols === 3 ? "layout-three-cols-header-container" : "")))) + (hasColSlots || isClover ? " has-superblock-cols" : "");
          const headerDiv = document.createElement("div");
          headerDiv.className = "layout-header-section";
          for (const b of headerBlocks) headerDiv.appendChild(renderBlock(b, ""));
          containerDiv.appendChild(headerDiv);
          const gridDiv = document.createElement("div");
          gridDiv.className = (isClover ? "layout-clover-grid pdf-clover-wrapper" : ("layout-cols-wrapper layout-cols-grid " + (targetCols === 2 ? "pdf-two-cols-wrapper layout-two-cols-grid" : (targetCols === 3 ? "pdf-three-cols-wrapper layout-three-cols-grid" : "")))) + (hasColSlots || isClover ? " has-superblock-cols" : "");
          const gridCols = isClover ? "repeat(2, minmax(0, 1fr))" : parseRatioToGridCols(fm.layoutRatio, targetCols);
          if (gridCols) gridDiv.style.gridTemplateColumns = gridCols;
          if (isClover) gridDiv.style.gridTemplateRows = "repeat(2, minmax(0, 1fr))";
          let colsList = [];
          for (let i = 0; i < targetCols; i++) colsList.push([]);
          const hasExplicitCols = rem.some((b) => b.slot && (b.slot.startsWith("col-") || b.slot === "left" || b.slot === "right" || b.slot === "center"));
          if (hasExplicitCols && rem.length > 1) {
            for (const b of rem) {
              let idx = 0;
              if (b.slot === "left" || b.slot === "col-1") idx = 0;
              else if (b.slot === "center" || b.slot === "col-2") idx = 1;
              else if (b.slot === "right") idx = targetCols === 2 ? 1 : targetCols - 1;
              else {
                const m = (b.slot || "").match(/^col-(d+)$/i);
                if (m) idx = Math.min(targetCols - 1, Math.max(0, parseInt(m[1], 10) - 1));
              }
              colsList[idx].push(b);
            }
            const hasExplicitColN = rem.some(b => /^col-d+$/i.test((b.slot || "").trim()));
            if (!hasExplicitColN && colsList[0].length === 0) {
              const nonEmptyCols = colsList.filter(c => c.length > 0);
              if (nonEmptyCols.length === 1) {
                colsList = [nonEmptyCols[0], ...Array.from({ length: targetCols - 1 }, () => [])];
              }
            }
          } else if (rem.length === 1) {
            colsList[0] = [rem[0]];
          } else {
            let cur = 0;
            for (let i = 0; i < targetCols; i++) {
              const remainingCols = targetCols - i;
              const remainingItems = rem.length - cur;
              const take = Math.ceil(remainingItems / remainingCols);
              colsList[i] = rem.slice(cur, cur + take);
              cur += take;
            }
          }
          colsList.forEach((colBlocks, idx) => {
            const colDiv = document.createElement("div");
            colDiv.className = "pdf-col pdf-col--" + (idx + 1) + " col-" + (idx + 1) + (targetCols === 2 && idx === 0 ? " pdf-col--left" : "") + (targetCols === 2 && idx === 1 ? " pdf-col--right" : "");
            const cleaned = cleanColList(colBlocks);
            for (const b of cleaned) colDiv.appendChild(renderBlock(b, ""));
            gridDiv.appendChild(colDiv);
          });
          containerDiv.appendChild(gridDiv);
          bodyEl = containerDiv;
        } else if (layout === "two-cols") {
          bodyEl = document.createElement("div");
          bodyEl.style.display = "flex";
          bodyEl.style.flexDirection = "row";
          bodyEl.style.gap = "2rem";
          bodyEl.style.width = "100%";
          bodyEl.style.flex = "1";
          bodyEl.style.minHeight = "0";
          let leftList = [];
          let rightList = [];
          for (const b of blocks) {
            if (b.slot === "right") rightList.push(b);
            else leftList.push(b);
          }
          const leftCol = document.createElement("div");
          leftCol.className = "two-cols-left";
          const rightCol = document.createElement("div");
          rightCol.className = "two-cols-right";
          for (const b of cleanColList(leftList)) leftCol.appendChild(renderBlock(b, ""));
          for (const b of cleanColList(rightList)) rightCol.appendChild(renderBlock(b, ""));
          bodyEl.appendChild(leftCol);
          bodyEl.appendChild(rightCol);
        } else if (layout === "image-right" || layout === "image-left") {
          const isImageRight = layout === "image-right";
          bodyEl = document.createElement("div");
          bodyEl.style.display = "flex";
          bodyEl.style.flexDirection = isImageRight ? "row" : "row-reverse";
          bodyEl.style.gap = "2rem";
          bodyEl.style.width = "100%";
          bodyEl.style.flex = "1";
          bodyEl.style.minHeight = "0";
          const contentCol = document.createElement("div");
          contentCol.className = isImageRight ? "image-right-content" : "image-left-content";
          for (const b of blocks) contentCol.appendChild(renderBlock(b, ""));
          const imgCol = document.createElement("div");
          imgCol.className = isImageRight ? "image-right-img-container" : "image-left-img-container";
          const url = fm.image || fm.background || "";
          if (url) {
            const img = document.createElement("img");
            img.className = isImageRight ? "image-right-img" : "image-left-img";
            img.src = url;
            img.alt = "Slide cover";
            imgCol.appendChild(img);
          }
          bodyEl.appendChild(contentCol);
          bodyEl.appendChild(imgCol);
        } else {
          bodyEl = document.createElement("div");
          for (const b of blocks) bodyEl.appendChild(renderBlock(b, ""));
        }
        canvas.appendChild(bodyEl);
      }

      function buildOverviewCards() {
        if (overviewBuilt) return;
        overviewBuilt = true;
        const scale = OVERVIEW_CARD_W / baseWidth;
        const canvasH = Math.round(baseHeight * scale);
        slides.forEach((slide, idx) => {
          const card = document.createElement("div");
          card.className = "slides-overview-card";
          card.dataset.idx = String(idx);
          const box = document.createElement("div");
          box.className = "slides-overview-canvas-box";
          box.style.height = canvasH + "px";
          const fm = slide.frontmatter || {};
          const spacing = (fm.spacing && fm.spacing !== "inherit") ? fm.spacing : ((data.config && data.config.spacing) || "normal");
          const canvas = document.createElement("div");
          canvas.className = "slides-overview-canvas slide-content layout-" + (fm.layout || "default") + " spacing-" + spacing;
          canvas.style.width = baseWidth + "px";
          canvas.style.height = baseHeight + "px";
          canvas.style.transform = "scale(" + scale + ")";
          const bg = fm.background;
          if (bg) {
            if (/^(http|/|data:|assets/)/.test(bg)) {
              canvas.style.backgroundImage = 'url("' + bg + '")';
              canvas.style.backgroundSize = "cover";
              canvas.style.backgroundPosition = "center";
            } else {
              canvas.style.background = bg;
            }
          }
          box.appendChild(canvas);
          const caption = document.createElement("div");
          caption.className = "slides-overview-caption";
          const pageNo = document.createElement("span");
          pageNo.className = "slides-overview-page-no";
          pageNo.textContent = String(idx + 1);
          caption.appendChild(pageNo);
          const title = getSlideOverviewTitle(slide);
          if (title) {
            const titleEl = document.createElement("span");
            titleEl.className = "slides-overview-title";
            titleEl.textContent = title;
            caption.appendChild(titleEl);
          }
          card.appendChild(box);
          card.appendChild(caption);
          card.addEventListener("click", (e) => {
            e.stopPropagation();
            goFromOverview(idx + 1);
          });
          overviewGrid.appendChild(card);
        });
        updateOverviewCurrentMark();
      }

      function renderOverviewThumb(card) {
        if (!card || card.dataset.rendered === "1") return;
        const idx = Number(card.dataset.idx);
        const slide = slides[idx];
        const canvas = card.querySelector(".slides-overview-canvas");
        if (slide && canvas) buildOverviewThumbInto(canvas, slide);
        card.dataset.rendered = "1";
      }

      function ensureOverviewObserver() {
        if (overviewObserver || typeof window.IntersectionObserver !== "function") return;
        overviewObserver = new IntersectionObserver((entries) => {
          for (const en of entries) {
            if (!en.isIntersecting) continue;
            overviewObserver.unobserve(en.target);
            renderOverviewThumb(en.target);
          }
        }, { rootMargin: "240px" });
      }

      function observeOverviewCards() {
        if (!overviewObserver) return;
        const cards = overviewGrid.children;
        for (let i = 0; i < cards.length; i++) {
          if (cards[i].dataset.rendered !== "1") overviewObserver.observe(cards[i]);
        }
      }

      function updateOverviewCurrentMark() {
        const cards = overviewGrid.children;
        for (let i = 0; i < cards.length; i++) {
          const pageNo = cards[i].querySelector(".slides-overview-page-no");
          if (pageNo) pageNo.classList.toggle("is-current", i === currentIndex);
        }
      }

      function setOverviewFocus(page) {
        const total = slides.length || 1;
        overviewFocus = Math.min(Math.max(1, page), total);
        const cards = overviewGrid.children;
        for (let i = 0; i < cards.length; i++) {
          cards[i].classList.toggle("is-active", i + 1 === overviewFocus);
        }
        const el = cards[overviewFocus - 1];
        if (el && el.scrollIntoView) el.scrollIntoView({ block: "nearest", behavior: "smooth" });
      }

      function getOverviewCols() {
        if (!overviewGrid || !overviewGrid.clientWidth) return 1;
        return Math.max(1, Math.round(overviewGrid.clientWidth / (OVERVIEW_CARD_W + 18)));
      }

      function goFromOverview(page) {
        const p = parseInt(page, 10);
        if (isNaN(p) || p < 1 || p > slides.length) return;
        closeOverview();
        renderSlide(p - 1);
        updateOverviewCurrentMark();
      }

      function openOverview() {
        if (slides.length === 0) return;
        buildOverviewCards();
        overviewOpen = true;
        overviewOverlay.style.display = "block";
        ensureOverviewObserver();
        if (overviewObserver) {
          observeOverviewCards();
        } else {
          const cards = overviewGrid.children;
          for (let i = 0; i < cards.length; i++) renderOverviewThumb(cards[i]);
        }
        setOverviewFocus(currentIndex + 1);
      }

      function closeOverview() {
        overviewOpen = false;
        overviewOverlay.style.display = "none";
        hideJumpIndicator();
        if (overviewObserver) {
          const cards = overviewGrid.children;
          for (let i = 0; i < cards.length; i++) overviewObserver.unobserve(cards[i]);
        }
      }

      function toggleOverview() {
        if (overviewOpen) closeOverview();
        else openOverview();
      }

      // 总览打开期间接管全部按键：修复上游总览中空格/PGUP/PGDN 仍会翻页的漏洞
      function handleOverviewKeyDown(e) {
        if (e.ctrlKey || e.metaKey || e.altKey) return;
        if (e.isComposing || isEditableKeyTarget(e.target)) return;
        if (/^[0-9]$/.test(e.key)) {
          if (!jumpInvalid && jumpDisplay.length < 4) {
            jumpDisplay += e.key;
            const p = parseInt(jumpDisplay, 10);
            if (!isNaN(p) && p >= 1 && p <= slides.length) setOverviewFocus(p);
            renderJumpBadge();
            armJumpIdleTimer();
          }
          e.preventDefault();
          return;
        }
        if (e.key === "Enter" && jumpDisplay) {
          if (!jumpInvalid) {
            const page = parseInt(jumpDisplay, 10);
            if (!isNaN(page) && page >= 1 && page <= slides.length) {
              goFromOverview(page);
            } else {
              flashJumpInvalid();
            }
          }
          e.preventDefault();
          return;
        }
        if ((e.key === "Escape" || e.key === "Esc") && (jumpDisplay || jumpInvalid)) {
          hideJumpIndicator();
          e.preventDefault();
          return;
        }
        if (e.key === "ArrowRight") {
          e.preventDefault();
          setOverviewFocus(overviewFocus + 1);
          return;
        }
        if (e.key === "ArrowLeft") {
          e.preventDefault();
          setOverviewFocus(overviewFocus - 1);
          return;
        }
        if (e.key === "ArrowDown" || e.key === "PageDown") {
          e.preventDefault();
          setOverviewFocus(overviewFocus + getOverviewCols());
          return;
        }
        if (e.key === "ArrowUp" || e.key === "PageUp") {
          e.preventDefault();
          setOverviewFocus(overviewFocus - getOverviewCols());
          return;
        }
        if (e.key === " ") {
          e.preventDefault();
          return;
        }
        if (e.key === "Enter") {
          e.preventDefault();
          goFromOverview(overviewFocus);
          return;
        }
        if (e.key === "Escape" || e.key === "Esc" || e.key === "o" || e.key === "O") {
          e.preventDefault();
          closeOverview();
        }
      }

      window.addEventListener("keydown", (e) => {
        if (e.key === "Escape" || e.key === "Esc") {
          if (isLightboxOpen) {
            closeLightbox();
            e.preventDefault();
            return;
          }
        }
        if (isLightboxOpen) return;
        // 总览打开期间全部按键由总览层接管
        if (overviewOpen) {
          handleOverviewKeyDown(e);
          return;
        }
        // 「数字+回车」跳页：可输入元素、修饰键、IME 组合输入中不拦截
        if (!e.ctrlKey && !e.metaKey && !e.altKey && !e.isComposing && !isEditableKeyTarget(e.target)) {
          if (/^[0-9]$/.test(e.key)) {
            if (!jumpInvalid && jumpDisplay.length < 4) {
              jumpDisplay += e.key;
              renderJumpBadge();
              armJumpIdleTimer();
            }
            e.preventDefault();
            return;
          }
          if (e.key === "Enter" && jumpDisplay) {
            if (!jumpInvalid) {
              const page = parseInt(jumpDisplay, 10);
              if (!isNaN(page) && page >= 1 && page <= slides.length) {
                hideJumpIndicator();
                renderSlide(page - 1);
              } else {
                flashJumpInvalid();
              }
            }
            e.preventDefault();
            return;
          }
          if ((e.key === "Escape" || e.key === "Esc") && (jumpDisplay || jumpInvalid)) {
            hideJumpIndicator();
            e.preventDefault();
            return;
          }
          if (e.key === "o" || e.key === "O") {
            e.preventDefault();
            toggleOverview();
            return;
          }
        }
        if (e.key === "ArrowRight" || e.key === " " || e.key === "ArrowDown") goNext();
        if (e.key === "ArrowLeft" || e.key === "ArrowUp") goPrev();
        if (e.key === "f" || e.key === "F") btnFullscreen.click();
      });

      // 监听鼠标滚轮上下翻页调度
      let lastWheelTime = 0;
      const WHEEL_COOLDOWN_MS = 280;
      const WHEEL_DELTA_THRESHOLD = 15;

`}function ag(){return`      function canElementScrollY(el, deltaY) {
        let cur = el;
        while (cur && cur !== document.body && cur !== document.documentElement) {
          if (cur.classList && (cur.classList.contains("slides-viewport") || cur.classList.contains("slides-stage") || cur.classList.contains("slide-container"))) {
            break;
          }
          const style = window.getComputedStyle(cur);
          const overflowY = style.overflowY;
          if (overflowY === "auto" || overflowY === "scroll") {
            const maxScroll = cur.scrollHeight - cur.clientHeight;
            if (maxScroll > 2) {
              if (deltaY > 0 && cur.scrollTop < maxScroll - 1) return true;
              if (deltaY < 0 && cur.scrollTop > 1) return true;
            }
          }
          cur = cur.parentElement;
        }
        return false;
      }

      window.addEventListener("wheel", (e) => {
        if (isLightboxOpen) {
          if (typeof handleLightboxWheel === "function") {
            handleLightboxWheel(e);
          }
          return;
        }
        // 总览打开时滚轮交给总览列表原生滚动，不触发翻页
        if (overviewOpen) return;
        if (Math.abs(e.deltaY) < Math.abs(e.deltaX)) return;
        if (Math.abs(e.deltaY) < WHEEL_DELTA_THRESHOLD) return;

        const target = e.target instanceof Element ? e.target : e.target?.parentElement;
        if (target && canElementScrollY(target, e.deltaY)) return;

        e.preventDefault();
        const now = Date.now();
        if (now - lastWheelTime < WHEEL_COOLDOWN_MS) return;
        lastWheelTime = now;

        if (e.deltaY > 0) {
          goNext();
        } else {
          goPrev();
        }
      }, { passive: false });

      document.addEventListener("click", (e) => {
        if (isLightboxOpen) {
          if (typeof lightboxHasMoved !== "undefined" && lightboxHasMoved) {
            lightboxHasMoved = false;
            e.stopPropagation();
            return;
          }
          const target = e.target instanceof Element ? e.target : e.target?.parentElement;
          const isMediaItself = target && target.closest && target.closest(".slides-lightbox-img, .slides-lightbox-video");
          if (!isMediaItself) {
            e.stopPropagation();
            closeLightbox();
          }
          return;
        }
        // 总览打开时空白点击由总览层自身处理，不触发底层翻页
        if (overviewOpen) return;
        if (e.button !== 0) return;
        const targetEl = e.target instanceof Element ? e.target : e.target?.parentElement;
        if (!targetEl || !targetEl.closest) return;

        const hasPendingMask = currentMaskConfig && (currentMaskStep < currentMaskConfig.totalSteps);
        if (hasPendingMask) {
          const isBottomControls = targetEl.closest(".controls-bar, .controls, .slides-toc");
          if (isBottomControls) return;
          e.preventDefault();
          e.stopPropagation();
          goNext();
          return;
        }

        const refEl = targetEl.closest("[data-ref-id]");
        if (refEl) {
          const id = refEl.getAttribute("data-ref-id");
          if (id) {
            window.open("siyuan://blocks/" + id, "_blank");
            return;
          }
        }

        // 媒体点击唤起 Lightbox 放大模态
        const mediaEl = targetEl.closest(".slide-content img, .slide-content video");
        if (mediaEl && !mediaEl.closest(".controls, .controls-bar, button, a")) {
          e.stopPropagation();
          const isVideo = mediaEl.tagName.toLowerCase() === "video";
          const src = isVideo ? (mediaEl.currentSrc || mediaEl.src || mediaEl.querySelector("source")?.src) : mediaEl.src;
          if (src) {
            openLightbox(isVideo ? "video" : "image", src, mediaEl.alt || "");
            return;
          }
        }

        const selection = window.getSelection ? window.getSelection().toString().trim() : "";
        if (selection.length > 0) return;

        const isComponent = targetEl.closest(
          ".slide-block, .controls-bar, .image-right-img-container, .image-left-img-container, .controls, img, video, audio, button, a, input, textarea, select, [data-clickable], [data-ref-id], .slides-toc, .empty-state"
        );
        if (isComponent) return;

        const isLeft = e.clientX < window.innerWidth / 2;
        if (isLeft) {
          goPrev();
        } else {
          goNext();
        }
      });

      renderSlide(0);
      updateScale();
    })();`}function lg(){return[Qm(),eg(),tg(),ig(),ng(),sg(),og(),rg(),ag()].join("")}function Gl(e,t){const i=(t==null?void 0:t.title)||"即现演示文稿";let n=e.slides;if(t!=null&&t.inlineAssetBase64Map&&Object.keys(t.inlineAssetBase64Map).length>0){const a=t.inlineAssetBase64Map;n=e.slides.map(r=>{let l=r.rawMarkdown;for(const[d,h]of Object.entries(a))l.includes(d)&&(l=l.split(d).join(h));const c=r.blocks.map(d=>{let h=d.rawMarkdown;for(const[f,v]of Object.entries(a))h.includes(f)&&(h=h.split(f).join(v));return{...d,rawMarkdown:h}});let u=r.frontmatter?{...r.frontmatter}:r.frontmatter;if(u){if(typeof u.background=="string")for(const[d,h]of Object.entries(a))u.background.includes(d)&&(u.background=u.background.split(d).join(h));if(typeof u.image=="string")for(const[d,h]of Object.entries(a))u.image.includes(d)&&(u.image=u.image.split(d).join(h))}return{...r,rawMarkdown:l,blocks:c,frontmatter:u}})}const s=JSON.stringify(n),o=JSON.stringify(e.config);return`<!DOCTYPE html>
<html lang="zh-CN">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${rt(i)}</title>
  <style>
${Xm(t==null?void 0:t.customInlineStyles)}
  </style>
  <script>
    // 注入演示数据载荷
    window.__SLIDES_DATA__ = {
      docId: ${JSON.stringify(e.docId)},
      slides: ${s},
      config: ${o}
    };
  <\/script>
</head>
<body>
  <div id="app" data-normalize-headings="${e.config.normalizeHeadingSizes?"true":"false"}" data-hide-unordered-markers="${e.config.showUnorderedListMarkers===!1?"true":"false"}" data-hide-ordered-markers="${e.config.showOrderedListMarkers===!1?"true":"false"}">
    <div class="slide-viewport slides-theme-${e.config.theme||"default"}" id="viewport" data-slides-theme="${e.config.theme||"default"}">
      <div class="slide-content" id="slide-container"></div>
    </div>
    <div class="controls">
      <button id="btn-prev">◀ 上一页</button>
      <span id="page-num">1 / 1</span>
      <button id="btn-next">下一页 ▶</button>
      <button id="btn-fullscreen">全屏</button>
    </div>
    <!-- 全屏媒体灯箱 (Lightbox) 模态窗口 -->
    <div id="slides-lightbox" class="slides-lightbox">
      <button class="slides-lightbox-close" id="lightbox-close" aria-label="关闭 (Esc)">✕</button>
      <div class="slides-lightbox-content" id="lightbox-content"></div>
    </div>
  </div>

  <script>
${lg()}
  <\/script>
</body>
</html>`}function Kl(e,t){if(typeof document>"u")return!1;const i=new Blob([t],{type:"text/html;charset=utf-8"}),n=URL.createObjectURL(i),s=document.createElement("a");return s.href=n,s.download=e.endsWith(".html")?e:`${e}.html`,document.body.appendChild(s),s.click(),document.body.removeChild(s),URL.revokeObjectURL(n),!0}function cg(e){switch(e){case"4:3":return"size: 12in 9in;";case"A4-landscape":return"size: 297mm 210mm;";case"A4-portrait":return"size: 210mm 297mm;";case"16:9":default:return"size: 16in 9in;"}}function dg(e){const t=cg(e==null?void 0:e.pageRatio);return`
    ${Pn(e==null?void 0:e.customInlineStyles)}

    @page {
      ${t}
      margin: 0;
    }
    * {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
      -webkit-print-color-adjust: exact !important;
      print-color-adjust: exact !important;
    }
    body {
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "PingFang SC", "Microsoft YaHei", sans-serif;
      background: #f8fafc;
      color: #1e293b;
    }
    .pdf-slide-page {
      width: 100vw;
      height: 100vh;
      page-break-after: always;
      break-after: page;
      padding: var(--slides-padding-y, 36px) var(--slides-padding-x, 56px);
      display: flex;
      flex-direction: column;
      position: relative;
      background: #ffffff;
      overflow: hidden;
    }
    .pdf-slide-page.spacing-compact {
      --slides-padding-y: 20px;
      --slides-padding-x: 36px;
      --slides-header-gap: 10px;
      --slides-title-margin-bottom: 6px;
    }
    .pdf-slide-page.spacing-normal {
      --slides-padding-y: 36px;
      --slides-padding-x: 56px;
      --slides-header-gap: 16px;
      --slides-title-margin-bottom: 10px;
    }
    .pdf-slide-page.spacing-loose {
      --slides-padding-y: 48px;
      --slides-padding-x: 64px;
      --slides-header-gap: 24px;
      --slides-title-margin-bottom: 16px;
    }
    .pdf-slide-page.theme-dark {
      background: #0f1117;
      color: #f1f5f9;
    }
    .pdf-slide-header {
      font-size: 13px;
      color: #64748b;
      margin-bottom: 24px;
      display: flex;
      justify-content: space-between;
      border-bottom: 1px solid #e2e8f0;
      padding-bottom: 8px;
    }
    .theme-dark .pdf-slide-header {
      border-bottom-color: #2e3346;
      color: #94a3b8;
    }
    .pdf-slide-body {
      flex: 1;
      display: flex;
      flex-direction: column;
      gap: 16px;
      font-size: 20px;
      line-height: 1.6;
      overflow: hidden;
    }
    .pdf-block h1 { font-size: 2.5rem; font-weight: 800; color: #2563eb; margin-bottom: 12px; }
    .pdf-block h2 { font-size: 1.9rem; font-weight: 700; color: #1d4ed8; margin-bottom: 10px; }
    .pdf-block h3 { font-size: 1.4rem; font-weight: 600; margin-bottom: 8px; }
    .pdf-block h4 { font-size: 1.2rem; font-weight: 600; margin-bottom: 6px; }
    .pdf-block p { font-size: 1.15rem; color: inherit; }
    .pdf-code,
    pre {
      background: #f1f5f9;
      padding: 14px 18px;
      border-radius: 6px;
      font-family: "JetBrains Mono", Consolas, monospace;
      font-size: 0.95rem;
      border-left: 4px solid #3b82f6;
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      max-width: 100% !important;
      box-sizing: border-box !important;
    }
    .pdf-code code,
    pre code {
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      display: block !important;
      width: 100% !important;
      box-sizing: border-box !important;
    }
    .code-line {
      display: flex !important;
      align-items: flex-start !important;
      width: 100% !important;
      box-sizing: border-box !important;
      line-height: 1.6;
    }
    .code-line .line-no {
      display: inline-block !important;
      flex-shrink: 0 !important;
      min-width: 2.2em !important;
      text-align: right !important;
      margin-right: 12px !important;
      user-select: none !important;
      opacity: 0.45 !important;
    }
    .code-line .line-content {
      flex: 1 1 0% !important;
      min-width: 0 !important;
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
    }
    .theme-dark .pdf-code {
      background: #1e1e24;
      border-left-color: #60a5fa;
    }
    .pdf-quote {
      border-left: 4px solid #10b981;
      background: rgba(16, 185, 129, 0.08);
      padding: 10px 16px;
      border-radius: 0 4px 4px 0;
      font-style: italic;
    }
    .pdf-image,
    .slide-media-img {
      max-width: 100% !important;
      max-height: 48vh !important;
      width: auto !important;
      height: auto !important;
      object-fit: contain !important;
      border-radius: 6px;
      margin: auto;
      display: block;
    }
    .slide-media-block,
    .slide-media-container,
    .slide-video-container {
      display: flex;
      flex-direction: column;
      justify-content: center;
      align-items: center;
      width: 100%;
      max-height: 48vh;
      margin: 8px 0;
      overflow: hidden;
    }
    .slide-list-media {
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: flex-start;
      margin-top: 8px;
      margin-bottom: 6px;
      max-width: 100%;
      overflow: hidden;
    }
    .slide-list-media img,
    .slide-list-media video,
    .slide-list-media .list-item-gif {
      max-width: 100% !important;
      max-height: min(280px, 36vh) !important;
      width: auto !important;
      height: auto !important;
      min-width: 0 !important;
      min-height: 0 !important;
      object-fit: contain !important;
      border-radius: 6px;
      display: block;
      margin: 0 auto !important;
    }
    .slide-video-player {
      max-width: 100% !important;
      max-height: 48vh !important;
      width: auto !important;
      height: auto !important;
      object-fit: contain !important;
      border-radius: 6px;
      background: #000;
      border: 1px solid #cbd5e1;
    }
    .pdf-two-cols-wrapper,
    .layout-two-cols-grid,
    .layout-cols-wrapper,
    .layout-cols-grid {
      display: grid;
      grid-template-columns: minmax(0, 1fr) minmax(0, 1fr);
      grid-template-rows: minmax(0, 1fr) !important;
      gap: 36px;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      overflow: hidden !important;
    }
    .layout-cols-header-container,
    .layout-two-cols-header-container,
    .layout-three-cols-header-container,
    .layout-clover-container {
      display: flex;
      flex-direction: column;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      overflow: hidden !important;
    }
    .layout-header-section {
      width: 100%;
      margin-bottom: var(--slides-header-gap, 16px) !important;
      flex-shrink: 0;
    }
    .layout-header-section h1,
    .layout-header-section h2,
    .layout-header-section h3 {
      margin-bottom: var(--slides-title-margin-bottom, 10px) !important;
    }
    .pdf-three-cols-wrapper,
    .layout-three-cols-grid {
      display: grid;
      grid-template-columns: minmax(0, 1fr) minmax(0, 1fr) minmax(0, 1fr);
      grid-template-rows: minmax(0, 1fr) !important;
      gap: 24px;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      box-sizing: border-box;
      overflow: hidden !important;
    }
    .pdf-clover-wrapper,
    .layout-clover-grid {
      display: grid;
      grid-template-columns: repeat(2, minmax(0, 1fr)) !important;
      grid-template-rows: repeat(2, minmax(0, 1fr)) !important;
      gap: 20px;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      box-sizing: border-box;
      overflow: hidden !important;
    }
    .layout-clover-grid .pdf-col {
      background: transparent !important;
      border: none !important;
      box-shadow: none !important;
    }
    .pdf-col {
      display: flex;
      flex-direction: column;
      gap: 14px;
      min-width: 0;
      width: 100%;
      max-width: 100%;
      height: 100%;
      max-height: 100%;
      min-height: 0;
      justify-content: flex-start;
      overflow: hidden;
      box-sizing: border-box;
      overflow-wrap: break-word;
      word-break: break-word;
      white-space: normal;
    }
    /* 表头多栏内超级块子块首个列表项去圆点后居中显示标题/首行文本 (仅在存在超级块分栏时生效) */
    .has-superblock-cols .pdf-col > *:first-child .slide-list-item-title,
    .has-superblock-cols .pdf-col > *:first-child :is(h1, h2, h3, h4, h5, h6),
    .has-superblock-cols .pdf-col > *:first-child p.slide-list-item-title,
    .has-superblock-cols .pdf-col > *:first-child p:first-of-type,
    .has-superblock-cols .pdf-col > *:first-child p:first-child,
    .has-superblock-cols .pdf-col > *:first-child :is(ul, ol) > li:first-child,
    .has-superblock-cols .pdf-col > *:first-child .slide-list > .slide-list-item:first-child,
    .has-superblock-cols .pdf-col > *:first-child .pdf-list > li:first-child,
    .has-superblock-cols .slides-col-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    .has-superblock-cols .slides-col-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      list-style: none !important;
      list-style-type: none !important;
      text-align: center !important;
      margin-left: 0 !important;
      padding-left: 0 !important;
      width: 100% !important;
    }

    /* 彻底清除首个列表项的原生圆点 Marker (仅在存在超级块分栏时生效) */
    .has-superblock-cols .pdf-col > *:first-child :is(ul, ol) > li:first-child::marker {
      content: "" !important;
      display: none !important;
    }

    /* 确保首个列表项内部内联与块级元素居中 (仅在存在超级块分栏时生效) */
    .has-superblock-cols .pdf-col > *:first-child :is(ul, ol) > li:first-child * {
      text-align: center !important;
    }

    /* 栏内说明段落与列表项：左对齐，自然阅读排版 */
    .has-superblock-cols .pdf-col .slide-list-item-desc,
    .has-superblock-cols .pdf-col li:not(:first-child) {
      text-align: left !important;
    }

    /* 全局特定标题大小规范化 (除封面外页首首个标题按 H2 1.7rem，表头多栏内首个标题按 H3 1.3rem) */
    [data-normalize-headings="true"] .slides-page-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .slides-page-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .pdf-slide:not(.layout-cover) > :is(.pdf-block, .slide-block):first-child :is(h1, h2, h3, h4, h5, h6),
    [data-normalize-headings="true"] .pdf-slide:not(.layout-cover) > .layout-header-section :is(.pdf-block, .slide-block):first-child :is(h1, h2, h3, h4, h5, h6),
    [data-normalize-headings="true"] .pdf-slide:not(.layout-cover) > :not(.layout-cols-wrapper):not(.pdf-two-cols-wrapper):not(.layout-image-cols-grid):first-child :is(h1, h2, h3, h4, h5, h6) {
      font-size: 1.7rem !important;
      font-weight: 600 !important;
      line-height: 1.25 !important;
      margin-bottom: 10px !important;
    }

    [data-normalize-headings="true"] .has-superblock-cols .slides-col-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .has-superblock-cols .slides-col-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .has-superblock-cols .pdf-col > *:first-child :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      font-size: 1.3rem !important;
      font-weight: 600 !important;
      line-height: 1.3 !important;
      margin-bottom: 8px !important;
      text-align: center !important;
    }

    /* 图左与图右版式标题完全保留用户原始字号与默认排版，不进行任何固定大小规范化 */
    [data-normalize-headings="true"] :is(.layout-image-left, .layout-image-right, .image-left-content, .image-right-content) :is(h1, h2, h3, h4, h5, h6) {
      text-align: left !important;
    }
    .pdf-col > .pdf-block,
    .pdf-col > .slide-block {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      max-height: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      width: 100% !important;
      height: 100% !important;
      box-sizing: border-box !important;
      overflow: hidden !important;
    }
    .pdf-col .slide-list-item-title,
    .pdf-col h1, .pdf-col h2, .pdf-col h3, .pdf-col h4, .pdf-col h5, .pdf-col h6,
    .pdf-col .slide-list-item-desc {
      flex: 0 0 auto !important;
      margin-top: 0 !important;
      margin-bottom: 6px !important;
    }
    .pdf-col .slide-list-media,
    .pdf-col .slide-video-container,
    .pdf-col .slide-media-container {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      min-width: 0 !important;
      width: 100% !important;
      height: 100% !important;
      max-height: 100% !important;
      max-width: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
      justify-content: flex-start !important;
      overflow: hidden !important;
      margin: 0 !important;
      padding: 0 !important;
      box-sizing: border-box !important;
    }
    .pdf-col li:has(.slide-list-media),
    .pdf-col li:has(.slide-media-container),
    .pdf-col li:has(.slide-video-container),
    .pdf-col li:has(img),
    .pdf-col li:has(video),
    .pdf-col .pdf-list-item:has(.slide-list-media),
    .pdf-col .pdf-list-item:has(.slide-media-container),
    .pdf-col .pdf-list-item:has(.slide-video-container),
    .pdf-col .pdf-list-item:has(img),
    .pdf-col .pdf-list-item:has(video) {
      display: list-item !important;
      list-style-type: disc !important;
      flex: 0 0 auto !important;
      height: auto !important;
      max-height: none !important;
      overflow: visible !important;
      margin-bottom: 6px !important;
    }
    .pdf-col video,
    .layout-three-cols-grid video,
    .layout-two-cols-grid video,
    .pdf-col img,
    .layout-three-cols-grid img,
    .layout-two-cols-grid img,
    .pdf-col .slide-video-player {
      max-width: 100% !important;
      max-height: 100% !important;
      width: auto !important;
      height: auto !important;
      min-width: 0 !important;
      min-height: 0 !important;
      object-fit: contain !important;
      display: block !important;
      margin: 0 auto !important;
    }
    .pdf-col * {
      overflow-wrap: break-word;
      word-break: break-word;
      box-sizing: border-box;
    }
    .pdf-col pre {
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      max-width: 100% !important;
      box-sizing: border-box !important;
    }
    .pdf-list-item {
      padding-left: 20px;
    }
    .pdf-list {
      padding-left: 24px;
      margin: 8px 0;
      display: flex;
      flex-direction: column;
      gap: 6px;
    }
    .pdf-list li {
      font-size: 1.15rem;
      line-height: 1.6;
    }
    .pdf-task-item {
      list-style: none;
      margin-left: -20px;
      display: flex;
      align-items: center;
      gap: 8px;
    }
    .pdf-task-item input[type="checkbox"] {
      width: 1.15em;
      height: 1.15em;
      cursor: pointer;
    }
    /* 两栏与三栏及多栏（超级块分栏）布局：紧凑自然行距，子列表保留圆点与层级缩进 */
    .layout-two-cols ul,
    .layout-cols-header ul,
    .layout-two-cols-header ul,
    .layout-three-cols ul,
    .layout-three-cols-header ul,
    .two-cols-left ul,
    .two-cols-right ul,
    .three-cols-col ul,
    .col ul,
    .pdf-two-cols-wrapper ul,
    .pdf-three-cols-wrapper ul,
    .pdf-col ul,
    .layout-two-cols-grid .pdf-list,
    .layout-three-cols-grid .pdf-list,
    .layout-cols-grid .pdf-list,
    .layout-two-cols-grid .pdf-list--unordered,
    .layout-three-cols-grid .pdf-list--unordered,
    .layout-cols-grid .pdf-list--unordered {
      list-style: disc !important;
      list-style-type: disc !important;
      padding-left: 1.25em !important;
      margin-left: 0 !important;
      margin-top: 0 !important;
      margin-bottom: 8px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: block !important;
    }
    .layout-two-cols ol,
    .layout-cols-header ol,
    .layout-two-cols-header ol,
    .layout-three-cols ol,
    .layout-three-cols-header ol,
    .two-cols-left ol,
    .two-cols-right ol,
    .three-cols-col ol,
    .col ol,
    .pdf-two-cols-wrapper ol,
    .pdf-three-cols-wrapper ol,
    .pdf-col ol,
    .layout-two-cols-grid .pdf-list--ordered,
    .layout-three-cols-grid .pdf-list--ordered,
    .layout-cols-grid .pdf-list--ordered {
      list-style: decimal !important;
      list-style-type: decimal !important;
      padding-left: 1.25em !important;
      margin-left: 0 !important;
      margin-top: 0 !important;
      margin-bottom: 8px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: block !important;
    }
    .layout-two-cols li,
    .layout-cols-header li,
    .layout-two-cols-header li,
    .layout-three-cols li,
    .layout-three-cols-header li,
    .two-cols-left li,
    .two-cols-right li,
    .three-cols-col li,
    .col li,
    .pdf-col li,
    .pdf-col .pdf-list-item {
      padding-left: 0.2em !important;
      margin-left: 0 !important;
      margin-bottom: 6px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: list-item !important;
      line-height: 1.6 !important;
    }
    .layout-two-cols ul ul,
    .layout-three-cols ul ul,
    .three-cols-col ul ul,
    .pdf-col ul ul {
      list-style: circle !important;
      list-style-type: circle !important;
      padding-left: 1.25em !important;
      margin-top: 4px !important;
      margin-bottom: 4px !important;
    }
    /* 列表项内嵌标题与说明排版 */
    .slide-list-item-title,
    .pdf-list li > h1,
    .pdf-list li > h2,
    .pdf-list li > h3,
    .pdf-list li > h4,
    .pdf-list li > h5,
    .pdf-list li > h6,
    li > h1.slide-list-item-title,
    li > h2.slide-list-item-title,
    li > h3.slide-list-item-title,
    li > h4.slide-list-item-title {
      margin-top: 2px !important;
      margin-bottom: 6px !important;
      line-height: 1.35 !important;
      font-weight: 700 !important;
    }
    .pdf-list li > h1, li > h1.slide-list-item-title { font-size: 1.6rem !important; }
    .pdf-list li > h2, li > h2.slide-list-item-title { font-size: 1.4rem !important; }
    .pdf-list li > h3, li > h3.slide-list-item-title { font-size: 1.22rem !important; }
    .pdf-list li > h4, li > h4.slide-list-item-title { font-size: 1.1rem !important; }

    /* 全局特定标题大小规范化后置强力锁定 (防止被列表项内部字号覆盖) */
    [data-normalize-headings="true"] .slides-page-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .slides-page-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      font-size: 1.7rem !important;
      font-weight: 600 !important;
      line-height: 1.25 !important;
      margin-bottom: 10px !important;
    }
    [data-normalize-headings="true"] .has-superblock-cols .slides-col-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .has-superblock-cols .slides-col-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .has-superblock-cols .pdf-col > *:first-child :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      font-size: 1.3rem !important;
      font-weight: 600 !important;
      line-height: 1.3 !important;
      margin-bottom: 8px !important;
      text-align: center !important;
    }
    /* 基础列表项前缀样式 */
    .slide-block ul,
    .slide-list--unordered,
    .pdf-list--unordered {
      list-style: disc !important;
      list-style-type: disc !important;
    }
    .slide-block ol,
    .slide-list--ordered,
    .pdf-list--ordered {
      list-style: decimal !important;
      list-style-type: decimal !important;
    }
    .slide-block li,
    .slide-list-item,
    .pdf-list-item,
    .pdf-list li {
      display: list-item !important;
    }

    /* 隐藏无序列表前缀标记 */
    [data-hide-unordered-markers="true"] :is(ul, .slide-list, .slide-list--unordered, .pdf-list, .pdf-list--unordered),
    [data-hide-unordered-markers="true"] :is(ul, .slide-list, .slide-list--unordered, .pdf-list, .pdf-list--unordered) > li,
    [data-hide-unordered-markers="true"] li.slide-list-item,
    [data-hide-unordered-markers="true"] ul > li {
      list-style: none !important;
      list-style-type: none !important;
      padding-left: 0 !important;
      margin-left: 0 !important;
    }
    [data-hide-unordered-markers="true"] :is(ul, .slide-list, .slide-list--unordered, .pdf-list, .pdf-list--unordered) > li::marker,
    [data-hide-unordered-markers="true"] li.slide-list-item::marker {
      content: "" !important;
      display: none !important;
    }

    /* 隐藏有序列表前缀标记 */
    [data-hide-ordered-markers="true"] :is(ol, .slide-list, .slide-list--ordered, .pdf-list, .pdf-list--ordered),
    [data-hide-ordered-markers="true"] :is(ol, .slide-list, .slide-list--ordered, .pdf-list, .pdf-list--ordered) > li,
    [data-hide-ordered-markers="true"] li.slide-list-item,
    [data-hide-ordered-markers="true"] ol > li {
      list-style: none !important;
      list-style-type: none !important;
      padding-left: 0 !important;
      margin-left: 0 !important;
    }
    [data-hide-ordered-markers="true"] :is(ol, .slide-list, .slide-list--ordered, .pdf-list, .pdf-list--ordered) > li::marker,
    [data-hide-ordered-markers="true"] li.slide-list-item::marker {
      content: "" !important;
      display: none !important;
    }

    .slide-list-item-desc,
    .pdf-list li > p {
      margin-top: 4px !important;
      margin-bottom: 6px !important;
      font-size: 1.05rem;
      line-height: 1.55;
      opacity: 0.92;
    }
    kbd {
      display: inline-block;
      padding: 2px 7px;
      font-family: ui-monospace, SFMono-Regular, "SF Mono", Menlo, Consolas, "Liberation Mono", monospace;
      font-size: 0.85em;
      font-weight: 600;
      line-height: 1.25;
      color: inherit;
      background: rgba(125, 125, 125, 0.12);
      border: 1px solid rgba(125, 125, 125, 0.35);
      border-bottom-width: 2px;
      border-radius: 5px;
      box-shadow: 0 1px 2px rgba(0, 0, 0, 0.12);
      margin: 0 2px;
      vertical-align: middle;
      white-space: nowrap;
    }
    .theme-dark kbd {
      background: rgba(255, 255, 255, 0.1);
      border-color: rgba(255, 255, 255, 0.25);
      border-bottom-color: rgba(255, 255, 255, 0.4);
      color: #f1f5f9;
      box-shadow: 0 1px 2px rgba(0, 0, 0, 0.4);
    }
    a {
      color: inherit;
      text-decoration: none;
      border-bottom: 1px dashed currentColor;
    }
    .slides-ref-tag, a.slides-ref-tag {
      display: inline-flex;
      align-items: center;
      background: rgba(16, 185, 129, 0.1);
      color: #059669;
      border: 1px solid rgba(16, 185, 129, 0.25);
      border-radius: 4px;
      padding: 2px 8px;
      font-size: 0.88em;
      text-decoration: none;
      margin: 2px 4px 2px 0;
    }
    .theme-dark .slides-ref-tag, .theme-dark a.slides-ref-tag {
      background: rgba(52, 211, 153, 0.15);
      color: #34d399;
      border-color: rgba(52, 211, 153, 0.3);
    }
    .slides-block-ref, .pdf-block--ref {
      background: rgba(16, 185, 129, 0.06);
      border-left: 3px solid #059669;
      border-radius: 0 6px 6px 0;
      padding: 10px 14px;
      margin: 8px 0;
    }
    .theme-dark .slides-block-ref, .theme-dark .pdf-block--ref {
      background: rgba(52, 211, 153, 0.08);
      border-left-color: #34d399;
    }
    .pdf-slide-notes {
      font-size: 14px;
      color: #059669;
      border-top: 1px dashed #cbd5e1;
      padding-top: 12px;
      margin-top: auto;
      line-height: 1.5;
    }
    .theme-dark .pdf-slide-notes {
      color: #34d399;
      border-top-color: #334155;
    }
    /* Layouts */
    .layout-cover .pdf-slide-body {
      justify-content: center;
      align-items: center;
      text-align: center;
    }
    .layout-cover h1 {
      font-size: 3.2rem;
    }
    .layout-center .pdf-slide-body {
      justify-content: center;
      align-items: center;
      text-align: center;
    }
    .layout-fact .pdf-slide-body {
      justify-content: center;
      align-items: center;
      text-align: center;
    }
    .layout-fact h1 {
      font-size: 4.5rem;
      color: #ef4444;
    }
    @media print {
      .slides-motion-fade-in,
      .slides-motion-slide-up,
      .slides-motion-slide-down,
      .slides-motion-slide-left,
      .slides-motion-slide-right,
      .slides-motion-zoom-in,
      .slides-motion-pop,
      .slides-motion-bounce {
        animation: none !important;
        opacity: 1 !important;
        transform: none !important;
      }
      /* PDF 打印讲义下禁用动态蒙版遮挡，保证内容 100% 完整可见 */
      .slides-mask-layer,
      .slides-mask-overlay,
      .slides-mask-divider-line {
        display: none !important;
        opacity: 0 !important;
        mask: none !important;
        -webkit-mask: none !important;
      }
      .slides-mask-body-container {
        clip-path: none !important;
        -webkit-clip-path: none !important;
        overflow: visible !important;
      }
    }
  `}function ug(e,t){const i="即现演示讲义",n="16:9",s="light",o=e.slides.map((a,r)=>{const l=a.frontmatter.layout||"default",c=a.frontmatter.spacing,u=c&&c!=="inherit"?c:e.config.spacing||"normal",d=Vl(a),h=`${r+1} / ${e.slides.length}`;return`
      <section class="pdf-slide-page layout-${l} theme-${s} spacing-${u}">
        <header class="pdf-slide-header">
          <span class="pdf-doc-title">${rt(i)}</span>
          ${`<span class="pdf-page-badge">P. ${h}</span>`}
        </header>
        <div class="pdf-slide-body">
          ${d}
        </div>
        ${a.notes?`
          <footer class="pdf-slide-notes">
            <strong>演讲备注:</strong> ${rt(a.notes)}
          </footer>
        `:""}
      </section>
    `}).join(`
`);return`<!DOCTYPE html>
<html lang="zh-CN">
<head>
  <meta charset="UTF-8">
  <title>${rt(i)} - 高保真讲义</title>
  <style>
    ${dg({pageRatio:n,customInlineStyles:t==null?void 0:t.customInlineStyles})}
  </style>
</head>
<body data-normalize-headings="${e.config.normalizeHeadingSizes?"true":"false"}" data-hide-unordered-markers="${e.config.showUnorderedListMarkers===!1?"true":"false"}" data-hide-ordered-markers="${e.config.showOrderedListMarkers===!1?"true":"false"}">
  ${o}
</body>
</html>`}function ql(e,t){var s;if(typeof window>"u"||typeof document>"u")return!1;const i=ug(e,t);try{const o=document.createElement("iframe");o.style.position="fixed",o.style.right="0",o.style.bottom="0",o.style.width="0",o.style.height="0",o.style.border="none",o.style.visibility="hidden",document.body.appendChild(o);const a=(s=o.contentWindow)==null?void 0:s.document;if(a)return a.open(),a.write(i),a.close(),setTimeout(()=>{var r,l;try{(r=o.contentWindow)==null||r.focus(),(l=o.contentWindow)==null||l.print()}finally{setTimeout(()=>{o.remove()},2e3)}},350),!0}catch(o){console.warn("[pdf-exporter] iframe 打印模式异常，降级尝试 window.open:",o)}const n=window.open("","_blank");return n?(n.document.write(i),n.document.close(),n.focus(),setTimeout(()=>{n.print(),n.close()},350),!0):!1}var cs=typeof globalThis<"u"?globalThis:typeof window<"u"?window:typeof global<"u"?global:typeof self<"u"?self:{};function fg(e){return e&&e.__esModule&&Object.prototype.hasOwnProperty.call(e,"default")?e.default:e}function ds(e){throw new Error('Could not dynamically require "'+e+'". Please configure the dynamicRequireTargets or/and ignoreDynamicRequires option of @rollup/plugin-commonjs appropriately for this require call to work.')}var ho={exports:{}};/*!

JSZip v3.10.1 - A JavaScript class for generating and reading zip files
<http://stuartk.com/jszip>

(c) 2009-2016 Stuart Knightley <stuart [at] stuartk.com>
Dual licenced under the MIT license or GPLv3. See https://raw.github.com/Stuk/jszip/main/LICENSE.markdown.

JSZip uses the library pako released under the MIT license :
https://github.com/nodeca/pako/blob/main/LICENSE
*/var aa;function pg(){return aa||(aa=1,(function(e,t){(function(i){e.exports=i()})(function(){return(function i(n,s,o){function a(c,u){if(!s[c]){if(!n[c]){var d=typeof ds=="function"&&ds;if(!u&&d)return d(c,!0);if(r)return r(c,!0);var h=new Error("Cannot find module '"+c+"'");throw h.code="MODULE_NOT_FOUND",h}var f=s[c]={exports:{}};n[c][0].call(f.exports,function(v){var m=n[c][1][v];return a(m||v)},f,f.exports,i,n,s,o)}return s[c].exports}for(var r=typeof ds=="function"&&ds,l=0;l<o.length;l++)a(o[l]);return a})({1:[function(i,n,s){var o=i("./utils"),a=i("./support"),r="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";s.encode=function(l){for(var c,u,d,h,f,v,m,b=[],y=0,x=l.length,S=x,w=o.getTypeOf(l)!=="string";y<l.length;)S=x-y,d=w?(c=l[y++],u=y<x?l[y++]:0,y<x?l[y++]:0):(c=l.charCodeAt(y++),u=y<x?l.charCodeAt(y++):0,y<x?l.charCodeAt(y++):0),h=c>>2,f=(3&c)<<4|u>>4,v=1<S?(15&u)<<2|d>>6:64,m=2<S?63&d:64,b.push(r.charAt(h)+r.charAt(f)+r.charAt(v)+r.charAt(m));return b.join("")},s.decode=function(l){var c,u,d,h,f,v,m=0,b=0,y="data:";if(l.substr(0,y.length)===y)throw new Error("Invalid base64 input, it looks like a data url.");var x,S=3*(l=l.replace(/[^A-Za-z0-9+/=]/g,"")).length/4;if(l.charAt(l.length-1)===r.charAt(64)&&S--,l.charAt(l.length-2)===r.charAt(64)&&S--,S%1!=0)throw new Error("Invalid base64 input, bad content length.");for(x=a.uint8array?new Uint8Array(0|S):new Array(0|S);m<l.length;)c=r.indexOf(l.charAt(m++))<<2|(h=r.indexOf(l.charAt(m++)))>>4,u=(15&h)<<4|(f=r.indexOf(l.charAt(m++)))>>2,d=(3&f)<<6|(v=r.indexOf(l.charAt(m++))),x[b++]=c,f!==64&&(x[b++]=u),v!==64&&(x[b++]=d);return x}},{"./support":30,"./utils":32}],2:[function(i,n,s){var o=i("./external"),a=i("./stream/DataWorker"),r=i("./stream/Crc32Probe"),l=i("./stream/DataLengthProbe");function c(u,d,h,f,v){this.compressedSize=u,this.uncompressedSize=d,this.crc32=h,this.compression=f,this.compressedContent=v}c.prototype={getContentWorker:function(){var u=new a(o.Promise.resolve(this.compressedContent)).pipe(this.compression.uncompressWorker()).pipe(new l("data_length")),d=this;return u.on("end",function(){if(this.streamInfo.data_length!==d.uncompressedSize)throw new Error("Bug : uncompressed data size mismatch")}),u},getCompressedWorker:function(){return new a(o.Promise.resolve(this.compressedContent)).withStreamInfo("compressedSize",this.compressedSize).withStreamInfo("uncompressedSize",this.uncompressedSize).withStreamInfo("crc32",this.crc32).withStreamInfo("compression",this.compression)}},c.createWorkerFrom=function(u,d,h){return u.pipe(new r).pipe(new l("uncompressedSize")).pipe(d.compressWorker(h)).pipe(new l("compressedSize")).withStreamInfo("compression",d)},n.exports=c},{"./external":6,"./stream/Crc32Probe":25,"./stream/DataLengthProbe":26,"./stream/DataWorker":27}],3:[function(i,n,s){var o=i("./stream/GenericWorker");s.STORE={magic:"\0\0",compressWorker:function(){return new o("STORE compression")},uncompressWorker:function(){return new o("STORE decompression")}},s.DEFLATE=i("./flate")},{"./flate":7,"./stream/GenericWorker":28}],4:[function(i,n,s){var o=i("./utils"),a=(function(){for(var r,l=[],c=0;c<256;c++){r=c;for(var u=0;u<8;u++)r=1&r?3988292384^r>>>1:r>>>1;l[c]=r}return l})();n.exports=function(r,l){return r!==void 0&&r.length?o.getTypeOf(r)!=="string"?(function(c,u,d,h){var f=a,v=h+d;c^=-1;for(var m=h;m<v;m++)c=c>>>8^f[255&(c^u[m])];return-1^c})(0|l,r,r.length,0):(function(c,u,d,h){var f=a,v=h+d;c^=-1;for(var m=h;m<v;m++)c=c>>>8^f[255&(c^u.charCodeAt(m))];return-1^c})(0|l,r,r.length,0):0}},{"./utils":32}],5:[function(i,n,s){s.base64=!1,s.binary=!1,s.dir=!1,s.createFolders=!0,s.date=null,s.compression=null,s.compressionOptions=null,s.comment=null,s.unixPermissions=null,s.dosPermissions=null},{}],6:[function(i,n,s){var o=null;o=typeof Promise<"u"?Promise:i("lie"),n.exports={Promise:o}},{lie:37}],7:[function(i,n,s){var o=typeof Uint8Array<"u"&&typeof Uint16Array<"u"&&typeof Uint32Array<"u",a=i("pako"),r=i("./utils"),l=i("./stream/GenericWorker"),c=o?"uint8array":"array";function u(d,h){l.call(this,"FlateWorker/"+d),this._pako=null,this._pakoAction=d,this._pakoOptions=h,this.meta={}}s.magic="\b\0",r.inherits(u,l),u.prototype.processChunk=function(d){this.meta=d.meta,this._pako===null&&this._createPako(),this._pako.push(r.transformTo(c,d.data),!1)},u.prototype.flush=function(){l.prototype.flush.call(this),this._pako===null&&this._createPako(),this._pako.push([],!0)},u.prototype.cleanUp=function(){l.prototype.cleanUp.call(this),this._pako=null},u.prototype._createPako=function(){this._pako=new a[this._pakoAction]({raw:!0,level:this._pakoOptions.level||-1});var d=this;this._pako.onData=function(h){d.push({data:h,meta:d.meta})}},s.compressWorker=function(d){return new u("Deflate",d)},s.uncompressWorker=function(){return new u("Inflate",{})}},{"./stream/GenericWorker":28,"./utils":32,pako:38}],8:[function(i,n,s){function o(f,v){var m,b="";for(m=0;m<v;m++)b+=String.fromCharCode(255&f),f>>>=8;return b}function a(f,v,m,b,y,x){var S,w,$=f.file,E=f.compression,C=x!==c.utf8encode,L=r.transformTo("string",x($.name)),z=r.transformTo("string",c.utf8encode($.name)),H=$.comment,q=r.transformTo("string",x(H)),_=r.transformTo("string",c.utf8encode(H)),N=z.length!==$.name.length,k=_.length!==H.length,U="",F="",M="",B=$.dir,P=$.date,se={crc32:0,compressedSize:0,uncompressedSize:0};v&&!m||(se.crc32=f.crc32,se.compressedSize=f.compressedSize,se.uncompressedSize=f.uncompressedSize);var G=0;v&&(G|=8),C||!N&&!k||(G|=2048);var K=0,ce=0;B&&(K|=16),y==="UNIX"?(ce=798,K|=(function(oe,re){var be=oe;return oe||(be=re?16893:33204),(65535&be)<<16})($.unixPermissions,B)):(ce=20,K|=(function(oe){return 63&(oe||0)})($.dosPermissions)),S=P.getUTCHours(),S<<=6,S|=P.getUTCMinutes(),S<<=5,S|=P.getUTCSeconds()/2,w=P.getUTCFullYear()-1980,w<<=4,w|=P.getUTCMonth()+1,w<<=5,w|=P.getUTCDate(),N&&(F=o(1,1)+o(u(L),4)+z,U+="up"+o(F.length,2)+F),k&&(M=o(1,1)+o(u(q),4)+_,U+="uc"+o(M.length,2)+M);var ie="";return ie+=`
\0`,ie+=o(G,2),ie+=E.magic,ie+=o(S,2),ie+=o(w,2),ie+=o(se.crc32,4),ie+=o(se.compressedSize,4),ie+=o(se.uncompressedSize,4),ie+=o(L.length,2),ie+=o(U.length,2),{fileRecord:d.LOCAL_FILE_HEADER+ie+L+U,dirRecord:d.CENTRAL_FILE_HEADER+o(ce,2)+ie+o(q.length,2)+"\0\0\0\0"+o(K,4)+o(b,4)+L+U+q}}var r=i("../utils"),l=i("../stream/GenericWorker"),c=i("../utf8"),u=i("../crc32"),d=i("../signature");function h(f,v,m,b){l.call(this,"ZipFileWorker"),this.bytesWritten=0,this.zipComment=v,this.zipPlatform=m,this.encodeFileName=b,this.streamFiles=f,this.accumulate=!1,this.contentBuffer=[],this.dirRecords=[],this.currentSourceOffset=0,this.entriesCount=0,this.currentFile=null,this._sources=[]}r.inherits(h,l),h.prototype.push=function(f){var v=f.meta.percent||0,m=this.entriesCount,b=this._sources.length;this.accumulate?this.contentBuffer.push(f):(this.bytesWritten+=f.data.length,l.prototype.push.call(this,{data:f.data,meta:{currentFile:this.currentFile,percent:m?(v+100*(m-b-1))/m:100}}))},h.prototype.openedSource=function(f){this.currentSourceOffset=this.bytesWritten,this.currentFile=f.file.name;var v=this.streamFiles&&!f.file.dir;if(v){var m=a(f,v,!1,this.currentSourceOffset,this.zipPlatform,this.encodeFileName);this.push({data:m.fileRecord,meta:{percent:0}})}else this.accumulate=!0},h.prototype.closedSource=function(f){this.accumulate=!1;var v=this.streamFiles&&!f.file.dir,m=a(f,v,!0,this.currentSourceOffset,this.zipPlatform,this.encodeFileName);if(this.dirRecords.push(m.dirRecord),v)this.push({data:(function(b){return d.DATA_DESCRIPTOR+o(b.crc32,4)+o(b.compressedSize,4)+o(b.uncompressedSize,4)})(f),meta:{percent:100}});else for(this.push({data:m.fileRecord,meta:{percent:0}});this.contentBuffer.length;)this.push(this.contentBuffer.shift());this.currentFile=null},h.prototype.flush=function(){for(var f=this.bytesWritten,v=0;v<this.dirRecords.length;v++)this.push({data:this.dirRecords[v],meta:{percent:100}});var m=this.bytesWritten-f,b=(function(y,x,S,w,$){var E=r.transformTo("string",$(w));return d.CENTRAL_DIRECTORY_END+"\0\0\0\0"+o(y,2)+o(y,2)+o(x,4)+o(S,4)+o(E.length,2)+E})(this.dirRecords.length,m,f,this.zipComment,this.encodeFileName);this.push({data:b,meta:{percent:100}})},h.prototype.prepareNextSource=function(){this.previous=this._sources.shift(),this.openedSource(this.previous.streamInfo),this.isPaused?this.previous.pause():this.previous.resume()},h.prototype.registerPrevious=function(f){this._sources.push(f);var v=this;return f.on("data",function(m){v.processChunk(m)}),f.on("end",function(){v.closedSource(v.previous.streamInfo),v._sources.length?v.prepareNextSource():v.end()}),f.on("error",function(m){v.error(m)}),this},h.prototype.resume=function(){return!!l.prototype.resume.call(this)&&(!this.previous&&this._sources.length?(this.prepareNextSource(),!0):this.previous||this._sources.length||this.generatedError?void 0:(this.end(),!0))},h.prototype.error=function(f){var v=this._sources;if(!l.prototype.error.call(this,f))return!1;for(var m=0;m<v.length;m++)try{v[m].error(f)}catch{}return!0},h.prototype.lock=function(){l.prototype.lock.call(this);for(var f=this._sources,v=0;v<f.length;v++)f[v].lock()},n.exports=h},{"../crc32":4,"../signature":23,"../stream/GenericWorker":28,"../utf8":31,"../utils":32}],9:[function(i,n,s){var o=i("../compressions"),a=i("./ZipFileWorker");s.generateWorker=function(r,l,c){var u=new a(l.streamFiles,c,l.platform,l.encodeFileName),d=0;try{r.forEach(function(h,f){d++;var v=(function(x,S){var w=x||S,$=o[w];if(!$)throw new Error(w+" is not a valid compression method !");return $})(f.options.compression,l.compression),m=f.options.compressionOptions||l.compressionOptions||{},b=f.dir,y=f.date;f._compressWorker(v,m).withStreamInfo("file",{name:h,dir:b,date:y,comment:f.comment||"",unixPermissions:f.unixPermissions,dosPermissions:f.dosPermissions}).pipe(u)}),u.entriesCount=d}catch(h){u.error(h)}return u}},{"../compressions":3,"./ZipFileWorker":8}],10:[function(i,n,s){function o(){if(!(this instanceof o))return new o;if(arguments.length)throw new Error("The constructor with parameters has been removed in JSZip 3.0, please check the upgrade guide.");this.files=Object.create(null),this.comment=null,this.root="",this.clone=function(){var a=new o;for(var r in this)typeof this[r]!="function"&&(a[r]=this[r]);return a}}(o.prototype=i("./object")).loadAsync=i("./load"),o.support=i("./support"),o.defaults=i("./defaults"),o.version="3.10.1",o.loadAsync=function(a,r){return new o().loadAsync(a,r)},o.external=i("./external"),n.exports=o},{"./defaults":5,"./external":6,"./load":11,"./object":15,"./support":30}],11:[function(i,n,s){var o=i("./utils"),a=i("./external"),r=i("./utf8"),l=i("./zipEntries"),c=i("./stream/Crc32Probe"),u=i("./nodejsUtils");function d(h){return new a.Promise(function(f,v){var m=h.decompressed.getContentWorker().pipe(new c);m.on("error",function(b){v(b)}).on("end",function(){m.streamInfo.crc32!==h.decompressed.crc32?v(new Error("Corrupted zip : CRC32 mismatch")):f()}).resume()})}n.exports=function(h,f){var v=this;return f=o.extend(f||{},{base64:!1,checkCRC32:!1,optimizedBinaryString:!1,createFolders:!1,decodeFileName:r.utf8decode}),u.isNode&&u.isStream(h)?a.Promise.reject(new Error("JSZip can't accept a stream when loading a zip file.")):o.prepareContent("the loaded zip file",h,!0,f.optimizedBinaryString,f.base64).then(function(m){var b=new l(f);return b.load(m),b}).then(function(m){var b=[a.Promise.resolve(m)],y=m.files;if(f.checkCRC32)for(var x=0;x<y.length;x++)b.push(d(y[x]));return a.Promise.all(b)}).then(function(m){for(var b=m.shift(),y=b.files,x=0;x<y.length;x++){var S=y[x],w=S.fileNameStr,$=o.resolve(S.fileNameStr);v.file($,S.decompressed,{binary:!0,optimizedBinaryString:!0,date:S.date,dir:S.dir,comment:S.fileCommentStr.length?S.fileCommentStr:null,unixPermissions:S.unixPermissions,dosPermissions:S.dosPermissions,createFolders:f.createFolders}),S.dir||(v.file($).unsafeOriginalName=w)}return b.zipComment.length&&(v.comment=b.zipComment),v})}},{"./external":6,"./nodejsUtils":14,"./stream/Crc32Probe":25,"./utf8":31,"./utils":32,"./zipEntries":33}],12:[function(i,n,s){var o=i("../utils"),a=i("../stream/GenericWorker");function r(l,c){a.call(this,"Nodejs stream input adapter for "+l),this._upstreamEnded=!1,this._bindStream(c)}o.inherits(r,a),r.prototype._bindStream=function(l){var c=this;(this._stream=l).pause(),l.on("data",function(u){c.push({data:u,meta:{percent:0}})}).on("error",function(u){c.isPaused?this.generatedError=u:c.error(u)}).on("end",function(){c.isPaused?c._upstreamEnded=!0:c.end()})},r.prototype.pause=function(){return!!a.prototype.pause.call(this)&&(this._stream.pause(),!0)},r.prototype.resume=function(){return!!a.prototype.resume.call(this)&&(this._upstreamEnded?this.end():this._stream.resume(),!0)},n.exports=r},{"../stream/GenericWorker":28,"../utils":32}],13:[function(i,n,s){var o=i("readable-stream").Readable;function a(r,l,c){o.call(this,l),this._helper=r;var u=this;r.on("data",function(d,h){u.push(d)||u._helper.pause(),c&&c(h)}).on("error",function(d){u.emit("error",d)}).on("end",function(){u.push(null)})}i("../utils").inherits(a,o),a.prototype._read=function(){this._helper.resume()},n.exports=a},{"../utils":32,"readable-stream":16}],14:[function(i,n,s){n.exports={isNode:typeof Buffer<"u",newBufferFrom:function(o,a){if(Buffer.from&&Buffer.from!==Uint8Array.from)return Buffer.from(o,a);if(typeof o=="number")throw new Error('The "data" argument must not be a number');return new Buffer(o,a)},allocBuffer:function(o){if(Buffer.alloc)return Buffer.alloc(o);var a=new Buffer(o);return a.fill(0),a},isBuffer:function(o){return Buffer.isBuffer(o)},isStream:function(o){return o&&typeof o.on=="function"&&typeof o.pause=="function"&&typeof o.resume=="function"}}},{}],15:[function(i,n,s){function o($,E,C){var L,z=r.getTypeOf(E),H=r.extend(C||{},u);H.date=H.date||new Date,H.compression!==null&&(H.compression=H.compression.toUpperCase()),typeof H.unixPermissions=="string"&&(H.unixPermissions=parseInt(H.unixPermissions,8)),H.unixPermissions&&16384&H.unixPermissions&&(H.dir=!0),H.dosPermissions&&16&H.dosPermissions&&(H.dir=!0),H.dir&&($=y($)),H.createFolders&&(L=b($))&&x.call(this,L,!0);var q=z==="string"&&H.binary===!1&&H.base64===!1;C&&C.binary!==void 0||(H.binary=!q),(E instanceof d&&E.uncompressedSize===0||H.dir||!E||E.length===0)&&(H.base64=!1,H.binary=!0,E="",H.compression="STORE",z="string");var _=null;_=E instanceof d||E instanceof l?E:v.isNode&&v.isStream(E)?new m($,E):r.prepareContent($,E,H.binary,H.optimizedBinaryString,H.base64);var N=new h($,_,H);this.files[$]=N}var a=i("./utf8"),r=i("./utils"),l=i("./stream/GenericWorker"),c=i("./stream/StreamHelper"),u=i("./defaults"),d=i("./compressedObject"),h=i("./zipObject"),f=i("./generate"),v=i("./nodejsUtils"),m=i("./nodejs/NodejsStreamInputAdapter"),b=function($){$.slice(-1)==="/"&&($=$.substring(0,$.length-1));var E=$.lastIndexOf("/");return 0<E?$.substring(0,E):""},y=function($){return $.slice(-1)!=="/"&&($+="/"),$},x=function($,E){return E=E!==void 0?E:u.createFolders,$=y($),this.files[$]||o.call(this,$,null,{dir:!0,createFolders:E}),this.files[$]};function S($){return Object.prototype.toString.call($)==="[object RegExp]"}var w={load:function(){throw new Error("This method has been removed in JSZip 3.0, please check the upgrade guide.")},forEach:function($){var E,C,L;for(E in this.files)L=this.files[E],(C=E.slice(this.root.length,E.length))&&E.slice(0,this.root.length)===this.root&&$(C,L)},filter:function($){var E=[];return this.forEach(function(C,L){$(C,L)&&E.push(L)}),E},file:function($,E,C){if(arguments.length!==1)return $=this.root+$,o.call(this,$,E,C),this;if(S($)){var L=$;return this.filter(function(H,q){return!q.dir&&L.test(H)})}var z=this.files[this.root+$];return z&&!z.dir?z:null},folder:function($){if(!$)return this;if(S($))return this.filter(function(z,H){return H.dir&&$.test(z)});var E=this.root+$,C=x.call(this,E),L=this.clone();return L.root=C.name,L},remove:function($){$=this.root+$;var E=this.files[$];if(E||($.slice(-1)!=="/"&&($+="/"),E=this.files[$]),E&&!E.dir)delete this.files[$];else for(var C=this.filter(function(z,H){return H.name.slice(0,$.length)===$}),L=0;L<C.length;L++)delete this.files[C[L].name];return this},generate:function(){throw new Error("This method has been removed in JSZip 3.0, please check the upgrade guide.")},generateInternalStream:function($){var E,C={};try{if((C=r.extend($||{},{streamFiles:!1,compression:"STORE",compressionOptions:null,type:"",platform:"DOS",comment:null,mimeType:"application/zip",encodeFileName:a.utf8encode})).type=C.type.toLowerCase(),C.compression=C.compression.toUpperCase(),C.type==="binarystring"&&(C.type="string"),!C.type)throw new Error("No output type specified.");r.checkSupport(C.type),C.platform!=="darwin"&&C.platform!=="freebsd"&&C.platform!=="linux"&&C.platform!=="sunos"||(C.platform="UNIX"),C.platform==="win32"&&(C.platform="DOS");var L=C.comment||this.comment||"";E=f.generateWorker(this,C,L)}catch(z){(E=new l("error")).error(z)}return new c(E,C.type||"string",C.mimeType)},generateAsync:function($,E){return this.generateInternalStream($).accumulate(E)},generateNodeStream:function($,E){return($=$||{}).type||($.type="nodebuffer"),this.generateInternalStream($).toNodejsStream(E)}};n.exports=w},{"./compressedObject":2,"./defaults":5,"./generate":9,"./nodejs/NodejsStreamInputAdapter":12,"./nodejsUtils":14,"./stream/GenericWorker":28,"./stream/StreamHelper":29,"./utf8":31,"./utils":32,"./zipObject":35}],16:[function(i,n,s){n.exports=i("stream")},{stream:void 0}],17:[function(i,n,s){var o=i("./DataReader");function a(r){o.call(this,r);for(var l=0;l<this.data.length;l++)r[l]=255&r[l]}i("../utils").inherits(a,o),a.prototype.byteAt=function(r){return this.data[this.zero+r]},a.prototype.lastIndexOfSignature=function(r){for(var l=r.charCodeAt(0),c=r.charCodeAt(1),u=r.charCodeAt(2),d=r.charCodeAt(3),h=this.length-4;0<=h;--h)if(this.data[h]===l&&this.data[h+1]===c&&this.data[h+2]===u&&this.data[h+3]===d)return h-this.zero;return-1},a.prototype.readAndCheckSignature=function(r){var l=r.charCodeAt(0),c=r.charCodeAt(1),u=r.charCodeAt(2),d=r.charCodeAt(3),h=this.readData(4);return l===h[0]&&c===h[1]&&u===h[2]&&d===h[3]},a.prototype.readData=function(r){if(this.checkOffset(r),r===0)return[];var l=this.data.slice(this.zero+this.index,this.zero+this.index+r);return this.index+=r,l},n.exports=a},{"../utils":32,"./DataReader":18}],18:[function(i,n,s){var o=i("../utils");function a(r){this.data=r,this.length=r.length,this.index=0,this.zero=0}a.prototype={checkOffset:function(r){this.checkIndex(this.index+r)},checkIndex:function(r){if(this.length<this.zero+r||r<0)throw new Error("End of data reached (data length = "+this.length+", asked index = "+r+"). Corrupted zip ?")},setIndex:function(r){this.checkIndex(r),this.index=r},skip:function(r){this.setIndex(this.index+r)},byteAt:function(){},readInt:function(r){var l,c=0;for(this.checkOffset(r),l=this.index+r-1;l>=this.index;l--)c=(c<<8)+this.byteAt(l);return this.index+=r,c},readString:function(r){return o.transformTo("string",this.readData(r))},readData:function(){},lastIndexOfSignature:function(){},readAndCheckSignature:function(){},readDate:function(){var r=this.readInt(4);return new Date(Date.UTC(1980+(r>>25&127),(r>>21&15)-1,r>>16&31,r>>11&31,r>>5&63,(31&r)<<1))}},n.exports=a},{"../utils":32}],19:[function(i,n,s){var o=i("./Uint8ArrayReader");function a(r){o.call(this,r)}i("../utils").inherits(a,o),a.prototype.readData=function(r){this.checkOffset(r);var l=this.data.slice(this.zero+this.index,this.zero+this.index+r);return this.index+=r,l},n.exports=a},{"../utils":32,"./Uint8ArrayReader":21}],20:[function(i,n,s){var o=i("./DataReader");function a(r){o.call(this,r)}i("../utils").inherits(a,o),a.prototype.byteAt=function(r){return this.data.charCodeAt(this.zero+r)},a.prototype.lastIndexOfSignature=function(r){return this.data.lastIndexOf(r)-this.zero},a.prototype.readAndCheckSignature=function(r){return r===this.readData(4)},a.prototype.readData=function(r){this.checkOffset(r);var l=this.data.slice(this.zero+this.index,this.zero+this.index+r);return this.index+=r,l},n.exports=a},{"../utils":32,"./DataReader":18}],21:[function(i,n,s){var o=i("./ArrayReader");function a(r){o.call(this,r)}i("../utils").inherits(a,o),a.prototype.readData=function(r){if(this.checkOffset(r),r===0)return new Uint8Array(0);var l=this.data.subarray(this.zero+this.index,this.zero+this.index+r);return this.index+=r,l},n.exports=a},{"../utils":32,"./ArrayReader":17}],22:[function(i,n,s){var o=i("../utils"),a=i("../support"),r=i("./ArrayReader"),l=i("./StringReader"),c=i("./NodeBufferReader"),u=i("./Uint8ArrayReader");n.exports=function(d){var h=o.getTypeOf(d);return o.checkSupport(h),h!=="string"||a.uint8array?h==="nodebuffer"?new c(d):a.uint8array?new u(o.transformTo("uint8array",d)):new r(o.transformTo("array",d)):new l(d)}},{"../support":30,"../utils":32,"./ArrayReader":17,"./NodeBufferReader":19,"./StringReader":20,"./Uint8ArrayReader":21}],23:[function(i,n,s){s.LOCAL_FILE_HEADER="PK",s.CENTRAL_FILE_HEADER="PK",s.CENTRAL_DIRECTORY_END="PK",s.ZIP64_CENTRAL_DIRECTORY_LOCATOR="PK\x07",s.ZIP64_CENTRAL_DIRECTORY_END="PK",s.DATA_DESCRIPTOR="PK\x07\b"},{}],24:[function(i,n,s){var o=i("./GenericWorker"),a=i("../utils");function r(l){o.call(this,"ConvertWorker to "+l),this.destType=l}a.inherits(r,o),r.prototype.processChunk=function(l){this.push({data:a.transformTo(this.destType,l.data),meta:l.meta})},n.exports=r},{"../utils":32,"./GenericWorker":28}],25:[function(i,n,s){var o=i("./GenericWorker"),a=i("../crc32");function r(){o.call(this,"Crc32Probe"),this.withStreamInfo("crc32",0)}i("../utils").inherits(r,o),r.prototype.processChunk=function(l){this.streamInfo.crc32=a(l.data,this.streamInfo.crc32||0),this.push(l)},n.exports=r},{"../crc32":4,"../utils":32,"./GenericWorker":28}],26:[function(i,n,s){var o=i("../utils"),a=i("./GenericWorker");function r(l){a.call(this,"DataLengthProbe for "+l),this.propName=l,this.withStreamInfo(l,0)}o.inherits(r,a),r.prototype.processChunk=function(l){if(l){var c=this.streamInfo[this.propName]||0;this.streamInfo[this.propName]=c+l.data.length}a.prototype.processChunk.call(this,l)},n.exports=r},{"../utils":32,"./GenericWorker":28}],27:[function(i,n,s){var o=i("../utils"),a=i("./GenericWorker");function r(l){a.call(this,"DataWorker");var c=this;this.dataIsReady=!1,this.index=0,this.max=0,this.data=null,this.type="",this._tickScheduled=!1,l.then(function(u){c.dataIsReady=!0,c.data=u,c.max=u&&u.length||0,c.type=o.getTypeOf(u),c.isPaused||c._tickAndRepeat()},function(u){c.error(u)})}o.inherits(r,a),r.prototype.cleanUp=function(){a.prototype.cleanUp.call(this),this.data=null},r.prototype.resume=function(){return!!a.prototype.resume.call(this)&&(!this._tickScheduled&&this.dataIsReady&&(this._tickScheduled=!0,o.delay(this._tickAndRepeat,[],this)),!0)},r.prototype._tickAndRepeat=function(){this._tickScheduled=!1,this.isPaused||this.isFinished||(this._tick(),this.isFinished||(o.delay(this._tickAndRepeat,[],this),this._tickScheduled=!0))},r.prototype._tick=function(){if(this.isPaused||this.isFinished)return!1;var l=null,c=Math.min(this.max,this.index+16384);if(this.index>=this.max)return this.end();switch(this.type){case"string":l=this.data.substring(this.index,c);break;case"uint8array":l=this.data.subarray(this.index,c);break;case"array":case"nodebuffer":l=this.data.slice(this.index,c)}return this.index=c,this.push({data:l,meta:{percent:this.max?this.index/this.max*100:0}})},n.exports=r},{"../utils":32,"./GenericWorker":28}],28:[function(i,n,s){function o(a){this.name=a||"default",this.streamInfo={},this.generatedError=null,this.extraStreamInfo={},this.isPaused=!0,this.isFinished=!1,this.isLocked=!1,this._listeners={data:[],end:[],error:[]},this.previous=null}o.prototype={push:function(a){this.emit("data",a)},end:function(){if(this.isFinished)return!1;this.flush();try{this.emit("end"),this.cleanUp(),this.isFinished=!0}catch(a){this.emit("error",a)}return!0},error:function(a){return!this.isFinished&&(this.isPaused?this.generatedError=a:(this.isFinished=!0,this.emit("error",a),this.previous&&this.previous.error(a),this.cleanUp()),!0)},on:function(a,r){return this._listeners[a].push(r),this},cleanUp:function(){this.streamInfo=this.generatedError=this.extraStreamInfo=null,this._listeners=[]},emit:function(a,r){if(this._listeners[a])for(var l=0;l<this._listeners[a].length;l++)this._listeners[a][l].call(this,r)},pipe:function(a){return a.registerPrevious(this)},registerPrevious:function(a){if(this.isLocked)throw new Error("The stream '"+this+"' has already been used.");this.streamInfo=a.streamInfo,this.mergeStreamInfo(),this.previous=a;var r=this;return a.on("data",function(l){r.processChunk(l)}),a.on("end",function(){r.end()}),a.on("error",function(l){r.error(l)}),this},pause:function(){return!this.isPaused&&!this.isFinished&&(this.isPaused=!0,this.previous&&this.previous.pause(),!0)},resume:function(){if(!this.isPaused||this.isFinished)return!1;var a=this.isPaused=!1;return this.generatedError&&(this.error(this.generatedError),a=!0),this.previous&&this.previous.resume(),!a},flush:function(){},processChunk:function(a){this.push(a)},withStreamInfo:function(a,r){return this.extraStreamInfo[a]=r,this.mergeStreamInfo(),this},mergeStreamInfo:function(){for(var a in this.extraStreamInfo)Object.prototype.hasOwnProperty.call(this.extraStreamInfo,a)&&(this.streamInfo[a]=this.extraStreamInfo[a])},lock:function(){if(this.isLocked)throw new Error("The stream '"+this+"' has already been used.");this.isLocked=!0,this.previous&&this.previous.lock()},toString:function(){var a="Worker "+this.name;return this.previous?this.previous+" -> "+a:a}},n.exports=o},{}],29:[function(i,n,s){var o=i("../utils"),a=i("./ConvertWorker"),r=i("./GenericWorker"),l=i("../base64"),c=i("../support"),u=i("../external"),d=null;if(c.nodestream)try{d=i("../nodejs/NodejsStreamOutputAdapter")}catch{}function h(v,m){return new u.Promise(function(b,y){var x=[],S=v._internalType,w=v._outputType,$=v._mimeType;v.on("data",function(E,C){x.push(E),m&&m(C)}).on("error",function(E){x=[],y(E)}).on("end",function(){try{var E=(function(C,L,z){switch(C){case"blob":return o.newBlob(o.transformTo("arraybuffer",L),z);case"base64":return l.encode(L);default:return o.transformTo(C,L)}})(w,(function(C,L){var z,H=0,q=null,_=0;for(z=0;z<L.length;z++)_+=L[z].length;switch(C){case"string":return L.join("");case"array":return Array.prototype.concat.apply([],L);case"uint8array":for(q=new Uint8Array(_),z=0;z<L.length;z++)q.set(L[z],H),H+=L[z].length;return q;case"nodebuffer":return Buffer.concat(L);default:throw new Error("concat : unsupported type '"+C+"'")}})(S,x),$);b(E)}catch(C){y(C)}x=[]}).resume()})}function f(v,m,b){var y=m;switch(m){case"blob":case"arraybuffer":y="uint8array";break;case"base64":y="string"}try{this._internalType=y,this._outputType=m,this._mimeType=b,o.checkSupport(y),this._worker=v.pipe(new a(y)),v.lock()}catch(x){this._worker=new r("error"),this._worker.error(x)}}f.prototype={accumulate:function(v){return h(this,v)},on:function(v,m){var b=this;return v==="data"?this._worker.on(v,function(y){m.call(b,y.data,y.meta)}):this._worker.on(v,function(){o.delay(m,arguments,b)}),this},resume:function(){return o.delay(this._worker.resume,[],this._worker),this},pause:function(){return this._worker.pause(),this},toNodejsStream:function(v){if(o.checkSupport("nodestream"),this._outputType!=="nodebuffer")throw new Error(this._outputType+" is not supported by this method");return new d(this,{objectMode:this._outputType!=="nodebuffer"},v)}},n.exports=f},{"../base64":1,"../external":6,"../nodejs/NodejsStreamOutputAdapter":13,"../support":30,"../utils":32,"./ConvertWorker":24,"./GenericWorker":28}],30:[function(i,n,s){if(s.base64=!0,s.array=!0,s.string=!0,s.arraybuffer=typeof ArrayBuffer<"u"&&typeof Uint8Array<"u",s.nodebuffer=typeof Buffer<"u",s.uint8array=typeof Uint8Array<"u",typeof ArrayBuffer>"u")s.blob=!1;else{var o=new ArrayBuffer(0);try{s.blob=new Blob([o],{type:"application/zip"}).size===0}catch{try{var a=new(self.BlobBuilder||self.WebKitBlobBuilder||self.MozBlobBuilder||self.MSBlobBuilder);a.append(o),s.blob=a.getBlob("application/zip").size===0}catch{s.blob=!1}}}try{s.nodestream=!!i("readable-stream").Readable}catch{s.nodestream=!1}},{"readable-stream":16}],31:[function(i,n,s){for(var o=i("./utils"),a=i("./support"),r=i("./nodejsUtils"),l=i("./stream/GenericWorker"),c=new Array(256),u=0;u<256;u++)c[u]=252<=u?6:248<=u?5:240<=u?4:224<=u?3:192<=u?2:1;c[254]=c[254]=1;function d(){l.call(this,"utf-8 decode"),this.leftOver=null}function h(){l.call(this,"utf-8 encode")}s.utf8encode=function(f){return a.nodebuffer?r.newBufferFrom(f,"utf-8"):(function(v){var m,b,y,x,S,w=v.length,$=0;for(x=0;x<w;x++)(64512&(b=v.charCodeAt(x)))==55296&&x+1<w&&(64512&(y=v.charCodeAt(x+1)))==56320&&(b=65536+(b-55296<<10)+(y-56320),x++),$+=b<128?1:b<2048?2:b<65536?3:4;for(m=a.uint8array?new Uint8Array($):new Array($),x=S=0;S<$;x++)(64512&(b=v.charCodeAt(x)))==55296&&x+1<w&&(64512&(y=v.charCodeAt(x+1)))==56320&&(b=65536+(b-55296<<10)+(y-56320),x++),b<128?m[S++]=b:(b<2048?m[S++]=192|b>>>6:(b<65536?m[S++]=224|b>>>12:(m[S++]=240|b>>>18,m[S++]=128|b>>>12&63),m[S++]=128|b>>>6&63),m[S++]=128|63&b);return m})(f)},s.utf8decode=function(f){return a.nodebuffer?o.transformTo("nodebuffer",f).toString("utf-8"):(function(v){var m,b,y,x,S=v.length,w=new Array(2*S);for(m=b=0;m<S;)if((y=v[m++])<128)w[b++]=y;else if(4<(x=c[y]))w[b++]=65533,m+=x-1;else{for(y&=x===2?31:x===3?15:7;1<x&&m<S;)y=y<<6|63&v[m++],x--;1<x?w[b++]=65533:y<65536?w[b++]=y:(y-=65536,w[b++]=55296|y>>10&1023,w[b++]=56320|1023&y)}return w.length!==b&&(w.subarray?w=w.subarray(0,b):w.length=b),o.applyFromCharCode(w)})(f=o.transformTo(a.uint8array?"uint8array":"array",f))},o.inherits(d,l),d.prototype.processChunk=function(f){var v=o.transformTo(a.uint8array?"uint8array":"array",f.data);if(this.leftOver&&this.leftOver.length){if(a.uint8array){var m=v;(v=new Uint8Array(m.length+this.leftOver.length)).set(this.leftOver,0),v.set(m,this.leftOver.length)}else v=this.leftOver.concat(v);this.leftOver=null}var b=(function(x,S){var w;for((S=S||x.length)>x.length&&(S=x.length),w=S-1;0<=w&&(192&x[w])==128;)w--;return w<0||w===0?S:w+c[x[w]]>S?w:S})(v),y=v;b!==v.length&&(a.uint8array?(y=v.subarray(0,b),this.leftOver=v.subarray(b,v.length)):(y=v.slice(0,b),this.leftOver=v.slice(b,v.length))),this.push({data:s.utf8decode(y),meta:f.meta})},d.prototype.flush=function(){this.leftOver&&this.leftOver.length&&(this.push({data:s.utf8decode(this.leftOver),meta:{}}),this.leftOver=null)},s.Utf8DecodeWorker=d,o.inherits(h,l),h.prototype.processChunk=function(f){this.push({data:s.utf8encode(f.data),meta:f.meta})},s.Utf8EncodeWorker=h},{"./nodejsUtils":14,"./stream/GenericWorker":28,"./support":30,"./utils":32}],32:[function(i,n,s){var o=i("./support"),a=i("./base64"),r=i("./nodejsUtils"),l=i("./external");function c(m){return m}function u(m,b){for(var y=0;y<m.length;++y)b[y]=255&m.charCodeAt(y);return b}i("setimmediate"),s.newBlob=function(m,b){s.checkSupport("blob");try{return new Blob([m],{type:b})}catch{try{var y=new(self.BlobBuilder||self.WebKitBlobBuilder||self.MozBlobBuilder||self.MSBlobBuilder);return y.append(m),y.getBlob(b)}catch{throw new Error("Bug : can't construct the Blob.")}}};var d={stringifyByChunk:function(m,b,y){var x=[],S=0,w=m.length;if(w<=y)return String.fromCharCode.apply(null,m);for(;S<w;)b==="array"||b==="nodebuffer"?x.push(String.fromCharCode.apply(null,m.slice(S,Math.min(S+y,w)))):x.push(String.fromCharCode.apply(null,m.subarray(S,Math.min(S+y,w)))),S+=y;return x.join("")},stringifyByChar:function(m){for(var b="",y=0;y<m.length;y++)b+=String.fromCharCode(m[y]);return b},applyCanBeUsed:{uint8array:(function(){try{return o.uint8array&&String.fromCharCode.apply(null,new Uint8Array(1)).length===1}catch{return!1}})(),nodebuffer:(function(){try{return o.nodebuffer&&String.fromCharCode.apply(null,r.allocBuffer(1)).length===1}catch{return!1}})()}};function h(m){var b=65536,y=s.getTypeOf(m),x=!0;if(y==="uint8array"?x=d.applyCanBeUsed.uint8array:y==="nodebuffer"&&(x=d.applyCanBeUsed.nodebuffer),x)for(;1<b;)try{return d.stringifyByChunk(m,y,b)}catch{b=Math.floor(b/2)}return d.stringifyByChar(m)}function f(m,b){for(var y=0;y<m.length;y++)b[y]=m[y];return b}s.applyFromCharCode=h;var v={};v.string={string:c,array:function(m){return u(m,new Array(m.length))},arraybuffer:function(m){return v.string.uint8array(m).buffer},uint8array:function(m){return u(m,new Uint8Array(m.length))},nodebuffer:function(m){return u(m,r.allocBuffer(m.length))}},v.array={string:h,array:c,arraybuffer:function(m){return new Uint8Array(m).buffer},uint8array:function(m){return new Uint8Array(m)},nodebuffer:function(m){return r.newBufferFrom(m)}},v.arraybuffer={string:function(m){return h(new Uint8Array(m))},array:function(m){return f(new Uint8Array(m),new Array(m.byteLength))},arraybuffer:c,uint8array:function(m){return new Uint8Array(m)},nodebuffer:function(m){return r.newBufferFrom(new Uint8Array(m))}},v.uint8array={string:h,array:function(m){return f(m,new Array(m.length))},arraybuffer:function(m){return m.buffer},uint8array:c,nodebuffer:function(m){return r.newBufferFrom(m)}},v.nodebuffer={string:h,array:function(m){return f(m,new Array(m.length))},arraybuffer:function(m){return v.nodebuffer.uint8array(m).buffer},uint8array:function(m){return f(m,new Uint8Array(m.length))},nodebuffer:c},s.transformTo=function(m,b){if(b=b||"",!m)return b;s.checkSupport(m);var y=s.getTypeOf(b);return v[y][m](b)},s.resolve=function(m){for(var b=m.split("/"),y=[],x=0;x<b.length;x++){var S=b[x];S==="."||S===""&&x!==0&&x!==b.length-1||(S===".."?y.pop():y.push(S))}return y.join("/")},s.getTypeOf=function(m){return typeof m=="string"?"string":Object.prototype.toString.call(m)==="[object Array]"?"array":o.nodebuffer&&r.isBuffer(m)?"nodebuffer":o.uint8array&&m instanceof Uint8Array?"uint8array":o.arraybuffer&&m instanceof ArrayBuffer?"arraybuffer":void 0},s.checkSupport=function(m){if(!o[m.toLowerCase()])throw new Error(m+" is not supported by this platform")},s.MAX_VALUE_16BITS=65535,s.MAX_VALUE_32BITS=-1,s.pretty=function(m){var b,y,x="";for(y=0;y<(m||"").length;y++)x+="\\x"+((b=m.charCodeAt(y))<16?"0":"")+b.toString(16).toUpperCase();return x},s.delay=function(m,b,y){setImmediate(function(){m.apply(y||null,b||[])})},s.inherits=function(m,b){function y(){}y.prototype=b.prototype,m.prototype=new y},s.extend=function(){var m,b,y={};for(m=0;m<arguments.length;m++)for(b in arguments[m])Object.prototype.hasOwnProperty.call(arguments[m],b)&&y[b]===void 0&&(y[b]=arguments[m][b]);return y},s.prepareContent=function(m,b,y,x,S){return l.Promise.resolve(b).then(function(w){return o.blob&&(w instanceof Blob||["[object File]","[object Blob]"].indexOf(Object.prototype.toString.call(w))!==-1)&&typeof FileReader<"u"?new l.Promise(function($,E){var C=new FileReader;C.onload=function(L){$(L.target.result)},C.onerror=function(L){E(L.target.error)},C.readAsArrayBuffer(w)}):w}).then(function(w){var $=s.getTypeOf(w);return $?($==="arraybuffer"?w=s.transformTo("uint8array",w):$==="string"&&(S?w=a.decode(w):y&&x!==!0&&(w=(function(E){return u(E,o.uint8array?new Uint8Array(E.length):new Array(E.length))})(w))),w):l.Promise.reject(new Error("Can't read the data of '"+m+"'. Is it in a supported JavaScript type (String, Blob, ArrayBuffer, etc) ?"))})}},{"./base64":1,"./external":6,"./nodejsUtils":14,"./support":30,setimmediate:54}],33:[function(i,n,s){var o=i("./reader/readerFor"),a=i("./utils"),r=i("./signature"),l=i("./zipEntry"),c=i("./support");function u(d){this.files=[],this.loadOptions=d}u.prototype={checkSignature:function(d){if(!this.reader.readAndCheckSignature(d)){this.reader.index-=4;var h=this.reader.readString(4);throw new Error("Corrupted zip or bug: unexpected signature ("+a.pretty(h)+", expected "+a.pretty(d)+")")}},isSignature:function(d,h){var f=this.reader.index;this.reader.setIndex(d);var v=this.reader.readString(4)===h;return this.reader.setIndex(f),v},readBlockEndOfCentral:function(){this.diskNumber=this.reader.readInt(2),this.diskWithCentralDirStart=this.reader.readInt(2),this.centralDirRecordsOnThisDisk=this.reader.readInt(2),this.centralDirRecords=this.reader.readInt(2),this.centralDirSize=this.reader.readInt(4),this.centralDirOffset=this.reader.readInt(4),this.zipCommentLength=this.reader.readInt(2);var d=this.reader.readData(this.zipCommentLength),h=c.uint8array?"uint8array":"array",f=a.transformTo(h,d);this.zipComment=this.loadOptions.decodeFileName(f)},readBlockZip64EndOfCentral:function(){this.zip64EndOfCentralSize=this.reader.readInt(8),this.reader.skip(4),this.diskNumber=this.reader.readInt(4),this.diskWithCentralDirStart=this.reader.readInt(4),this.centralDirRecordsOnThisDisk=this.reader.readInt(8),this.centralDirRecords=this.reader.readInt(8),this.centralDirSize=this.reader.readInt(8),this.centralDirOffset=this.reader.readInt(8),this.zip64ExtensibleData={};for(var d,h,f,v=this.zip64EndOfCentralSize-44;0<v;)d=this.reader.readInt(2),h=this.reader.readInt(4),f=this.reader.readData(h),this.zip64ExtensibleData[d]={id:d,length:h,value:f}},readBlockZip64EndOfCentralLocator:function(){if(this.diskWithZip64CentralDirStart=this.reader.readInt(4),this.relativeOffsetEndOfZip64CentralDir=this.reader.readInt(8),this.disksCount=this.reader.readInt(4),1<this.disksCount)throw new Error("Multi-volumes zip are not supported")},readLocalFiles:function(){var d,h;for(d=0;d<this.files.length;d++)h=this.files[d],this.reader.setIndex(h.localHeaderOffset),this.checkSignature(r.LOCAL_FILE_HEADER),h.readLocalPart(this.reader),h.handleUTF8(),h.processAttributes()},readCentralDir:function(){var d;for(this.reader.setIndex(this.centralDirOffset);this.reader.readAndCheckSignature(r.CENTRAL_FILE_HEADER);)(d=new l({zip64:this.zip64},this.loadOptions)).readCentralPart(this.reader),this.files.push(d);if(this.centralDirRecords!==this.files.length&&this.centralDirRecords!==0&&this.files.length===0)throw new Error("Corrupted zip or bug: expected "+this.centralDirRecords+" records in central dir, got "+this.files.length)},readEndOfCentral:function(){var d=this.reader.lastIndexOfSignature(r.CENTRAL_DIRECTORY_END);if(d<0)throw this.isSignature(0,r.LOCAL_FILE_HEADER)?new Error("Corrupted zip: can't find end of central directory"):new Error("Can't find end of central directory : is this a zip file ? If it is, see https://stuk.github.io/jszip/documentation/howto/read_zip.html");this.reader.setIndex(d);var h=d;if(this.checkSignature(r.CENTRAL_DIRECTORY_END),this.readBlockEndOfCentral(),this.diskNumber===a.MAX_VALUE_16BITS||this.diskWithCentralDirStart===a.MAX_VALUE_16BITS||this.centralDirRecordsOnThisDisk===a.MAX_VALUE_16BITS||this.centralDirRecords===a.MAX_VALUE_16BITS||this.centralDirSize===a.MAX_VALUE_32BITS||this.centralDirOffset===a.MAX_VALUE_32BITS){if(this.zip64=!0,(d=this.reader.lastIndexOfSignature(r.ZIP64_CENTRAL_DIRECTORY_LOCATOR))<0)throw new Error("Corrupted zip: can't find the ZIP64 end of central directory locator");if(this.reader.setIndex(d),this.checkSignature(r.ZIP64_CENTRAL_DIRECTORY_LOCATOR),this.readBlockZip64EndOfCentralLocator(),!this.isSignature(this.relativeOffsetEndOfZip64CentralDir,r.ZIP64_CENTRAL_DIRECTORY_END)&&(this.relativeOffsetEndOfZip64CentralDir=this.reader.lastIndexOfSignature(r.ZIP64_CENTRAL_DIRECTORY_END),this.relativeOffsetEndOfZip64CentralDir<0))throw new Error("Corrupted zip: can't find the ZIP64 end of central directory");this.reader.setIndex(this.relativeOffsetEndOfZip64CentralDir),this.checkSignature(r.ZIP64_CENTRAL_DIRECTORY_END),this.readBlockZip64EndOfCentral()}var f=this.centralDirOffset+this.centralDirSize;this.zip64&&(f+=20,f+=12+this.zip64EndOfCentralSize);var v=h-f;if(0<v)this.isSignature(h,r.CENTRAL_FILE_HEADER)||(this.reader.zero=v);else if(v<0)throw new Error("Corrupted zip: missing "+Math.abs(v)+" bytes.")},prepareReader:function(d){this.reader=o(d)},load:function(d){this.prepareReader(d),this.readEndOfCentral(),this.readCentralDir(),this.readLocalFiles()}},n.exports=u},{"./reader/readerFor":22,"./signature":23,"./support":30,"./utils":32,"./zipEntry":34}],34:[function(i,n,s){var o=i("./reader/readerFor"),a=i("./utils"),r=i("./compressedObject"),l=i("./crc32"),c=i("./utf8"),u=i("./compressions"),d=i("./support");function h(f,v){this.options=f,this.loadOptions=v}h.prototype={isEncrypted:function(){return(1&this.bitFlag)==1},useUTF8:function(){return(2048&this.bitFlag)==2048},readLocalPart:function(f){var v,m;if(f.skip(22),this.fileNameLength=f.readInt(2),m=f.readInt(2),this.fileName=f.readData(this.fileNameLength),f.skip(m),this.compressedSize===-1||this.uncompressedSize===-1)throw new Error("Bug or corrupted zip : didn't get enough information from the central directory (compressedSize === -1 || uncompressedSize === -1)");if((v=(function(b){for(var y in u)if(Object.prototype.hasOwnProperty.call(u,y)&&u[y].magic===b)return u[y];return null})(this.compressionMethod))===null)throw new Error("Corrupted zip : compression "+a.pretty(this.compressionMethod)+" unknown (inner file : "+a.transformTo("string",this.fileName)+")");this.decompressed=new r(this.compressedSize,this.uncompressedSize,this.crc32,v,f.readData(this.compressedSize))},readCentralPart:function(f){this.versionMadeBy=f.readInt(2),f.skip(2),this.bitFlag=f.readInt(2),this.compressionMethod=f.readString(2),this.date=f.readDate(),this.crc32=f.readInt(4),this.compressedSize=f.readInt(4),this.uncompressedSize=f.readInt(4);var v=f.readInt(2);if(this.extraFieldsLength=f.readInt(2),this.fileCommentLength=f.readInt(2),this.diskNumberStart=f.readInt(2),this.internalFileAttributes=f.readInt(2),this.externalFileAttributes=f.readInt(4),this.localHeaderOffset=f.readInt(4),this.isEncrypted())throw new Error("Encrypted zip are not supported");f.skip(v),this.readExtraFields(f),this.parseZIP64ExtraField(f),this.fileComment=f.readData(this.fileCommentLength)},processAttributes:function(){this.unixPermissions=null,this.dosPermissions=null;var f=this.versionMadeBy>>8;this.dir=!!(16&this.externalFileAttributes),f==0&&(this.dosPermissions=63&this.externalFileAttributes),f==3&&(this.unixPermissions=this.externalFileAttributes>>16&65535),this.dir||this.fileNameStr.slice(-1)!=="/"||(this.dir=!0)},parseZIP64ExtraField:function(){if(this.extraFields[1]){var f=o(this.extraFields[1].value);this.uncompressedSize===a.MAX_VALUE_32BITS&&(this.uncompressedSize=f.readInt(8)),this.compressedSize===a.MAX_VALUE_32BITS&&(this.compressedSize=f.readInt(8)),this.localHeaderOffset===a.MAX_VALUE_32BITS&&(this.localHeaderOffset=f.readInt(8)),this.diskNumberStart===a.MAX_VALUE_32BITS&&(this.diskNumberStart=f.readInt(4))}},readExtraFields:function(f){var v,m,b,y=f.index+this.extraFieldsLength;for(this.extraFields||(this.extraFields={});f.index+4<y;)v=f.readInt(2),m=f.readInt(2),b=f.readData(m),this.extraFields[v]={id:v,length:m,value:b};f.setIndex(y)},handleUTF8:function(){var f=d.uint8array?"uint8array":"array";if(this.useUTF8())this.fileNameStr=c.utf8decode(this.fileName),this.fileCommentStr=c.utf8decode(this.fileComment);else{var v=this.findExtraFieldUnicodePath();if(v!==null)this.fileNameStr=v;else{var m=a.transformTo(f,this.fileName);this.fileNameStr=this.loadOptions.decodeFileName(m)}var b=this.findExtraFieldUnicodeComment();if(b!==null)this.fileCommentStr=b;else{var y=a.transformTo(f,this.fileComment);this.fileCommentStr=this.loadOptions.decodeFileName(y)}}},findExtraFieldUnicodePath:function(){var f=this.extraFields[28789];if(f){var v=o(f.value);return v.readInt(1)!==1||l(this.fileName)!==v.readInt(4)?null:c.utf8decode(v.readData(f.length-5))}return null},findExtraFieldUnicodeComment:function(){var f=this.extraFields[25461];if(f){var v=o(f.value);return v.readInt(1)!==1||l(this.fileComment)!==v.readInt(4)?null:c.utf8decode(v.readData(f.length-5))}return null}},n.exports=h},{"./compressedObject":2,"./compressions":3,"./crc32":4,"./reader/readerFor":22,"./support":30,"./utf8":31,"./utils":32}],35:[function(i,n,s){function o(v,m,b){this.name=v,this.dir=b.dir,this.date=b.date,this.comment=b.comment,this.unixPermissions=b.unixPermissions,this.dosPermissions=b.dosPermissions,this._data=m,this._dataBinary=b.binary,this.options={compression:b.compression,compressionOptions:b.compressionOptions}}var a=i("./stream/StreamHelper"),r=i("./stream/DataWorker"),l=i("./utf8"),c=i("./compressedObject"),u=i("./stream/GenericWorker");o.prototype={internalStream:function(v){var m=null,b="string";try{if(!v)throw new Error("No output type specified.");var y=(b=v.toLowerCase())==="string"||b==="text";b!=="binarystring"&&b!=="text"||(b="string"),m=this._decompressWorker();var x=!this._dataBinary;x&&!y&&(m=m.pipe(new l.Utf8EncodeWorker)),!x&&y&&(m=m.pipe(new l.Utf8DecodeWorker))}catch(S){(m=new u("error")).error(S)}return new a(m,b,"")},async:function(v,m){return this.internalStream(v).accumulate(m)},nodeStream:function(v,m){return this.internalStream(v||"nodebuffer").toNodejsStream(m)},_compressWorker:function(v,m){if(this._data instanceof c&&this._data.compression.magic===v.magic)return this._data.getCompressedWorker();var b=this._decompressWorker();return this._dataBinary||(b=b.pipe(new l.Utf8EncodeWorker)),c.createWorkerFrom(b,v,m)},_decompressWorker:function(){return this._data instanceof c?this._data.getContentWorker():this._data instanceof u?this._data:new r(this._data)}};for(var d=["asText","asBinary","asNodeBuffer","asUint8Array","asArrayBuffer"],h=function(){throw new Error("This method has been removed in JSZip 3.0, please check the upgrade guide.")},f=0;f<d.length;f++)o.prototype[d[f]]=h;n.exports=o},{"./compressedObject":2,"./stream/DataWorker":27,"./stream/GenericWorker":28,"./stream/StreamHelper":29,"./utf8":31}],36:[function(i,n,s){(function(o){var a,r,l=o.MutationObserver||o.WebKitMutationObserver;if(l){var c=0,u=new l(v),d=o.document.createTextNode("");u.observe(d,{characterData:!0}),a=function(){d.data=c=++c%2}}else if(o.setImmediate||o.MessageChannel===void 0)a="document"in o&&"onreadystatechange"in o.document.createElement("script")?function(){var m=o.document.createElement("script");m.onreadystatechange=function(){v(),m.onreadystatechange=null,m.parentNode.removeChild(m),m=null},o.document.documentElement.appendChild(m)}:function(){setTimeout(v,0)};else{var h=new o.MessageChannel;h.port1.onmessage=v,a=function(){h.port2.postMessage(0)}}var f=[];function v(){var m,b;r=!0;for(var y=f.length;y;){for(b=f,f=[],m=-1;++m<y;)b[m]();y=f.length}r=!1}n.exports=function(m){f.push(m)!==1||r||a()}}).call(this,typeof cs<"u"?cs:typeof self<"u"?self:typeof window<"u"?window:{})},{}],37:[function(i,n,s){var o=i("immediate");function a(){}var r={},l=["REJECTED"],c=["FULFILLED"],u=["PENDING"];function d(y){if(typeof y!="function")throw new TypeError("resolver must be a function");this.state=u,this.queue=[],this.outcome=void 0,y!==a&&m(this,y)}function h(y,x,S){this.promise=y,typeof x=="function"&&(this.onFulfilled=x,this.callFulfilled=this.otherCallFulfilled),typeof S=="function"&&(this.onRejected=S,this.callRejected=this.otherCallRejected)}function f(y,x,S){o(function(){var w;try{w=x(S)}catch($){return r.reject(y,$)}w===y?r.reject(y,new TypeError("Cannot resolve promise with itself")):r.resolve(y,w)})}function v(y){var x=y&&y.then;if(y&&(typeof y=="object"||typeof y=="function")&&typeof x=="function")return function(){x.apply(y,arguments)}}function m(y,x){var S=!1;function w(C){S||(S=!0,r.reject(y,C))}function $(C){S||(S=!0,r.resolve(y,C))}var E=b(function(){x($,w)});E.status==="error"&&w(E.value)}function b(y,x){var S={};try{S.value=y(x),S.status="success"}catch(w){S.status="error",S.value=w}return S}(n.exports=d).prototype.finally=function(y){if(typeof y!="function")return this;var x=this.constructor;return this.then(function(S){return x.resolve(y()).then(function(){return S})},function(S){return x.resolve(y()).then(function(){throw S})})},d.prototype.catch=function(y){return this.then(null,y)},d.prototype.then=function(y,x){if(typeof y!="function"&&this.state===c||typeof x!="function"&&this.state===l)return this;var S=new this.constructor(a);return this.state!==u?f(S,this.state===c?y:x,this.outcome):this.queue.push(new h(S,y,x)),S},h.prototype.callFulfilled=function(y){r.resolve(this.promise,y)},h.prototype.otherCallFulfilled=function(y){f(this.promise,this.onFulfilled,y)},h.prototype.callRejected=function(y){r.reject(this.promise,y)},h.prototype.otherCallRejected=function(y){f(this.promise,this.onRejected,y)},r.resolve=function(y,x){var S=b(v,x);if(S.status==="error")return r.reject(y,S.value);var w=S.value;if(w)m(y,w);else{y.state=c,y.outcome=x;for(var $=-1,E=y.queue.length;++$<E;)y.queue[$].callFulfilled(x)}return y},r.reject=function(y,x){y.state=l,y.outcome=x;for(var S=-1,w=y.queue.length;++S<w;)y.queue[S].callRejected(x);return y},d.resolve=function(y){return y instanceof this?y:r.resolve(new this(a),y)},d.reject=function(y){var x=new this(a);return r.reject(x,y)},d.all=function(y){var x=this;if(Object.prototype.toString.call(y)!=="[object Array]")return this.reject(new TypeError("must be an array"));var S=y.length,w=!1;if(!S)return this.resolve([]);for(var $=new Array(S),E=0,C=-1,L=new this(a);++C<S;)z(y[C],C);return L;function z(H,q){x.resolve(H).then(function(_){$[q]=_,++E!==S||w||(w=!0,r.resolve(L,$))},function(_){w||(w=!0,r.reject(L,_))})}},d.race=function(y){var x=this;if(Object.prototype.toString.call(y)!=="[object Array]")return this.reject(new TypeError("must be an array"));var S=y.length,w=!1;if(!S)return this.resolve([]);for(var $=-1,E=new this(a);++$<S;)C=y[$],x.resolve(C).then(function(L){w||(w=!0,r.resolve(E,L))},function(L){w||(w=!0,r.reject(E,L))});var C;return E}},{immediate:36}],38:[function(i,n,s){var o={};(0,i("./lib/utils/common").assign)(o,i("./lib/deflate"),i("./lib/inflate"),i("./lib/zlib/constants")),n.exports=o},{"./lib/deflate":39,"./lib/inflate":40,"./lib/utils/common":41,"./lib/zlib/constants":44}],39:[function(i,n,s){var o=i("./zlib/deflate"),a=i("./utils/common"),r=i("./utils/strings"),l=i("./zlib/messages"),c=i("./zlib/zstream"),u=Object.prototype.toString,d=0,h=-1,f=0,v=8;function m(y){if(!(this instanceof m))return new m(y);this.options=a.assign({level:h,method:v,chunkSize:16384,windowBits:15,memLevel:8,strategy:f,to:""},y||{});var x=this.options;x.raw&&0<x.windowBits?x.windowBits=-x.windowBits:x.gzip&&0<x.windowBits&&x.windowBits<16&&(x.windowBits+=16),this.err=0,this.msg="",this.ended=!1,this.chunks=[],this.strm=new c,this.strm.avail_out=0;var S=o.deflateInit2(this.strm,x.level,x.method,x.windowBits,x.memLevel,x.strategy);if(S!==d)throw new Error(l[S]);if(x.header&&o.deflateSetHeader(this.strm,x.header),x.dictionary){var w;if(w=typeof x.dictionary=="string"?r.string2buf(x.dictionary):u.call(x.dictionary)==="[object ArrayBuffer]"?new Uint8Array(x.dictionary):x.dictionary,(S=o.deflateSetDictionary(this.strm,w))!==d)throw new Error(l[S]);this._dict_set=!0}}function b(y,x){var S=new m(x);if(S.push(y,!0),S.err)throw S.msg||l[S.err];return S.result}m.prototype.push=function(y,x){var S,w,$=this.strm,E=this.options.chunkSize;if(this.ended)return!1;w=x===~~x?x:x===!0?4:0,typeof y=="string"?$.input=r.string2buf(y):u.call(y)==="[object ArrayBuffer]"?$.input=new Uint8Array(y):$.input=y,$.next_in=0,$.avail_in=$.input.length;do{if($.avail_out===0&&($.output=new a.Buf8(E),$.next_out=0,$.avail_out=E),(S=o.deflate($,w))!==1&&S!==d)return this.onEnd(S),!(this.ended=!0);$.avail_out!==0&&($.avail_in!==0||w!==4&&w!==2)||(this.options.to==="string"?this.onData(r.buf2binstring(a.shrinkBuf($.output,$.next_out))):this.onData(a.shrinkBuf($.output,$.next_out)))}while((0<$.avail_in||$.avail_out===0)&&S!==1);return w===4?(S=o.deflateEnd(this.strm),this.onEnd(S),this.ended=!0,S===d):w!==2||(this.onEnd(d),!($.avail_out=0))},m.prototype.onData=function(y){this.chunks.push(y)},m.prototype.onEnd=function(y){y===d&&(this.options.to==="string"?this.result=this.chunks.join(""):this.result=a.flattenChunks(this.chunks)),this.chunks=[],this.err=y,this.msg=this.strm.msg},s.Deflate=m,s.deflate=b,s.deflateRaw=function(y,x){return(x=x||{}).raw=!0,b(y,x)},s.gzip=function(y,x){return(x=x||{}).gzip=!0,b(y,x)}},{"./utils/common":41,"./utils/strings":42,"./zlib/deflate":46,"./zlib/messages":51,"./zlib/zstream":53}],40:[function(i,n,s){var o=i("./zlib/inflate"),a=i("./utils/common"),r=i("./utils/strings"),l=i("./zlib/constants"),c=i("./zlib/messages"),u=i("./zlib/zstream"),d=i("./zlib/gzheader"),h=Object.prototype.toString;function f(m){if(!(this instanceof f))return new f(m);this.options=a.assign({chunkSize:16384,windowBits:0,to:""},m||{});var b=this.options;b.raw&&0<=b.windowBits&&b.windowBits<16&&(b.windowBits=-b.windowBits,b.windowBits===0&&(b.windowBits=-15)),!(0<=b.windowBits&&b.windowBits<16)||m&&m.windowBits||(b.windowBits+=32),15<b.windowBits&&b.windowBits<48&&(15&b.windowBits)==0&&(b.windowBits|=15),this.err=0,this.msg="",this.ended=!1,this.chunks=[],this.strm=new u,this.strm.avail_out=0;var y=o.inflateInit2(this.strm,b.windowBits);if(y!==l.Z_OK)throw new Error(c[y]);this.header=new d,o.inflateGetHeader(this.strm,this.header)}function v(m,b){var y=new f(b);if(y.push(m,!0),y.err)throw y.msg||c[y.err];return y.result}f.prototype.push=function(m,b){var y,x,S,w,$,E,C=this.strm,L=this.options.chunkSize,z=this.options.dictionary,H=!1;if(this.ended)return!1;x=b===~~b?b:b===!0?l.Z_FINISH:l.Z_NO_FLUSH,typeof m=="string"?C.input=r.binstring2buf(m):h.call(m)==="[object ArrayBuffer]"?C.input=new Uint8Array(m):C.input=m,C.next_in=0,C.avail_in=C.input.length;do{if(C.avail_out===0&&(C.output=new a.Buf8(L),C.next_out=0,C.avail_out=L),(y=o.inflate(C,l.Z_NO_FLUSH))===l.Z_NEED_DICT&&z&&(E=typeof z=="string"?r.string2buf(z):h.call(z)==="[object ArrayBuffer]"?new Uint8Array(z):z,y=o.inflateSetDictionary(this.strm,E)),y===l.Z_BUF_ERROR&&H===!0&&(y=l.Z_OK,H=!1),y!==l.Z_STREAM_END&&y!==l.Z_OK)return this.onEnd(y),!(this.ended=!0);C.next_out&&(C.avail_out!==0&&y!==l.Z_STREAM_END&&(C.avail_in!==0||x!==l.Z_FINISH&&x!==l.Z_SYNC_FLUSH)||(this.options.to==="string"?(S=r.utf8border(C.output,C.next_out),w=C.next_out-S,$=r.buf2string(C.output,S),C.next_out=w,C.avail_out=L-w,w&&a.arraySet(C.output,C.output,S,w,0),this.onData($)):this.onData(a.shrinkBuf(C.output,C.next_out)))),C.avail_in===0&&C.avail_out===0&&(H=!0)}while((0<C.avail_in||C.avail_out===0)&&y!==l.Z_STREAM_END);return y===l.Z_STREAM_END&&(x=l.Z_FINISH),x===l.Z_FINISH?(y=o.inflateEnd(this.strm),this.onEnd(y),this.ended=!0,y===l.Z_OK):x!==l.Z_SYNC_FLUSH||(this.onEnd(l.Z_OK),!(C.avail_out=0))},f.prototype.onData=function(m){this.chunks.push(m)},f.prototype.onEnd=function(m){m===l.Z_OK&&(this.options.to==="string"?this.result=this.chunks.join(""):this.result=a.flattenChunks(this.chunks)),this.chunks=[],this.err=m,this.msg=this.strm.msg},s.Inflate=f,s.inflate=v,s.inflateRaw=function(m,b){return(b=b||{}).raw=!0,v(m,b)},s.ungzip=v},{"./utils/common":41,"./utils/strings":42,"./zlib/constants":44,"./zlib/gzheader":47,"./zlib/inflate":49,"./zlib/messages":51,"./zlib/zstream":53}],41:[function(i,n,s){var o=typeof Uint8Array<"u"&&typeof Uint16Array<"u"&&typeof Int32Array<"u";s.assign=function(l){for(var c=Array.prototype.slice.call(arguments,1);c.length;){var u=c.shift();if(u){if(typeof u!="object")throw new TypeError(u+"must be non-object");for(var d in u)u.hasOwnProperty(d)&&(l[d]=u[d])}}return l},s.shrinkBuf=function(l,c){return l.length===c?l:l.subarray?l.subarray(0,c):(l.length=c,l)};var a={arraySet:function(l,c,u,d,h){if(c.subarray&&l.subarray)l.set(c.subarray(u,u+d),h);else for(var f=0;f<d;f++)l[h+f]=c[u+f]},flattenChunks:function(l){var c,u,d,h,f,v;for(c=d=0,u=l.length;c<u;c++)d+=l[c].length;for(v=new Uint8Array(d),c=h=0,u=l.length;c<u;c++)f=l[c],v.set(f,h),h+=f.length;return v}},r={arraySet:function(l,c,u,d,h){for(var f=0;f<d;f++)l[h+f]=c[u+f]},flattenChunks:function(l){return[].concat.apply([],l)}};s.setTyped=function(l){l?(s.Buf8=Uint8Array,s.Buf16=Uint16Array,s.Buf32=Int32Array,s.assign(s,a)):(s.Buf8=Array,s.Buf16=Array,s.Buf32=Array,s.assign(s,r))},s.setTyped(o)},{}],42:[function(i,n,s){var o=i("./common"),a=!0,r=!0;try{String.fromCharCode.apply(null,[0])}catch{a=!1}try{String.fromCharCode.apply(null,new Uint8Array(1))}catch{r=!1}for(var l=new o.Buf8(256),c=0;c<256;c++)l[c]=252<=c?6:248<=c?5:240<=c?4:224<=c?3:192<=c?2:1;function u(d,h){if(h<65537&&(d.subarray&&r||!d.subarray&&a))return String.fromCharCode.apply(null,o.shrinkBuf(d,h));for(var f="",v=0;v<h;v++)f+=String.fromCharCode(d[v]);return f}l[254]=l[254]=1,s.string2buf=function(d){var h,f,v,m,b,y=d.length,x=0;for(m=0;m<y;m++)(64512&(f=d.charCodeAt(m)))==55296&&m+1<y&&(64512&(v=d.charCodeAt(m+1)))==56320&&(f=65536+(f-55296<<10)+(v-56320),m++),x+=f<128?1:f<2048?2:f<65536?3:4;for(h=new o.Buf8(x),m=b=0;b<x;m++)(64512&(f=d.charCodeAt(m)))==55296&&m+1<y&&(64512&(v=d.charCodeAt(m+1)))==56320&&(f=65536+(f-55296<<10)+(v-56320),m++),f<128?h[b++]=f:(f<2048?h[b++]=192|f>>>6:(f<65536?h[b++]=224|f>>>12:(h[b++]=240|f>>>18,h[b++]=128|f>>>12&63),h[b++]=128|f>>>6&63),h[b++]=128|63&f);return h},s.buf2binstring=function(d){return u(d,d.length)},s.binstring2buf=function(d){for(var h=new o.Buf8(d.length),f=0,v=h.length;f<v;f++)h[f]=d.charCodeAt(f);return h},s.buf2string=function(d,h){var f,v,m,b,y=h||d.length,x=new Array(2*y);for(f=v=0;f<y;)if((m=d[f++])<128)x[v++]=m;else if(4<(b=l[m]))x[v++]=65533,f+=b-1;else{for(m&=b===2?31:b===3?15:7;1<b&&f<y;)m=m<<6|63&d[f++],b--;1<b?x[v++]=65533:m<65536?x[v++]=m:(m-=65536,x[v++]=55296|m>>10&1023,x[v++]=56320|1023&m)}return u(x,v)},s.utf8border=function(d,h){var f;for((h=h||d.length)>d.length&&(h=d.length),f=h-1;0<=f&&(192&d[f])==128;)f--;return f<0||f===0?h:f+l[d[f]]>h?f:h}},{"./common":41}],43:[function(i,n,s){n.exports=function(o,a,r,l){for(var c=65535&o|0,u=o>>>16&65535|0,d=0;r!==0;){for(r-=d=2e3<r?2e3:r;u=u+(c=c+a[l++]|0)|0,--d;);c%=65521,u%=65521}return c|u<<16|0}},{}],44:[function(i,n,s){n.exports={Z_NO_FLUSH:0,Z_PARTIAL_FLUSH:1,Z_SYNC_FLUSH:2,Z_FULL_FLUSH:3,Z_FINISH:4,Z_BLOCK:5,Z_TREES:6,Z_OK:0,Z_STREAM_END:1,Z_NEED_DICT:2,Z_ERRNO:-1,Z_STREAM_ERROR:-2,Z_DATA_ERROR:-3,Z_BUF_ERROR:-5,Z_NO_COMPRESSION:0,Z_BEST_SPEED:1,Z_BEST_COMPRESSION:9,Z_DEFAULT_COMPRESSION:-1,Z_FILTERED:1,Z_HUFFMAN_ONLY:2,Z_RLE:3,Z_FIXED:4,Z_DEFAULT_STRATEGY:0,Z_BINARY:0,Z_TEXT:1,Z_UNKNOWN:2,Z_DEFLATED:8}},{}],45:[function(i,n,s){var o=(function(){for(var a,r=[],l=0;l<256;l++){a=l;for(var c=0;c<8;c++)a=1&a?3988292384^a>>>1:a>>>1;r[l]=a}return r})();n.exports=function(a,r,l,c){var u=o,d=c+l;a^=-1;for(var h=c;h<d;h++)a=a>>>8^u[255&(a^r[h])];return-1^a}},{}],46:[function(i,n,s){var o,a=i("../utils/common"),r=i("./trees"),l=i("./adler32"),c=i("./crc32"),u=i("./messages"),d=0,h=4,f=0,v=-2,m=-1,b=4,y=2,x=8,S=9,w=286,$=30,E=19,C=2*w+1,L=15,z=3,H=258,q=H+z+1,_=42,N=113,k=1,U=2,F=3,M=4;function B(g,V){return g.msg=u[V],V}function P(g){return(g<<1)-(4<g?9:0)}function se(g){for(var V=g.length;0<=--V;)g[V]=0}function G(g){var V=g.state,j=V.pending;j>g.avail_out&&(j=g.avail_out),j!==0&&(a.arraySet(g.output,V.pending_buf,V.pending_out,j,g.next_out),g.next_out+=j,V.pending_out+=j,g.total_out+=j,g.avail_out-=j,V.pending-=j,V.pending===0&&(V.pending_out=0))}function K(g,V){r._tr_flush_block(g,0<=g.block_start?g.block_start:-1,g.strstart-g.block_start,V),g.block_start=g.strstart,G(g.strm)}function ce(g,V){g.pending_buf[g.pending++]=V}function ie(g,V){g.pending_buf[g.pending++]=V>>>8&255,g.pending_buf[g.pending++]=255&V}function oe(g,V){var j,I,T=g.max_chain_length,O=g.strstart,Y=g.prev_length,A=g.nice_match,R=g.strstart>g.w_size-q?g.strstart-(g.w_size-q):0,Z=g.window,te=g.w_mask,ne=g.prev,ge=g.strstart+H,Ie=Z[O+Y-1],_e=Z[O+Y];g.prev_length>=g.good_match&&(T>>=2),A>g.lookahead&&(A=g.lookahead);do if(Z[(j=V)+Y]===_e&&Z[j+Y-1]===Ie&&Z[j]===Z[O]&&Z[++j]===Z[O+1]){O+=2,j++;do;while(Z[++O]===Z[++j]&&Z[++O]===Z[++j]&&Z[++O]===Z[++j]&&Z[++O]===Z[++j]&&Z[++O]===Z[++j]&&Z[++O]===Z[++j]&&Z[++O]===Z[++j]&&Z[++O]===Z[++j]&&O<ge);if(I=H-(ge-O),O=ge-H,Y<I){if(g.match_start=V,A<=(Y=I))break;Ie=Z[O+Y-1],_e=Z[O+Y]}}while((V=ne[V&te])>R&&--T!=0);return Y<=g.lookahead?Y:g.lookahead}function re(g){var V,j,I,T,O,Y,A,R,Z,te,ne=g.w_size;do{if(T=g.window_size-g.lookahead-g.strstart,g.strstart>=ne+(ne-q)){for(a.arraySet(g.window,g.window,ne,ne,0),g.match_start-=ne,g.strstart-=ne,g.block_start-=ne,V=j=g.hash_size;I=g.head[--V],g.head[V]=ne<=I?I-ne:0,--j;);for(V=j=ne;I=g.prev[--V],g.prev[V]=ne<=I?I-ne:0,--j;);T+=ne}if(g.strm.avail_in===0)break;if(Y=g.strm,A=g.window,R=g.strstart+g.lookahead,Z=T,te=void 0,te=Y.avail_in,Z<te&&(te=Z),j=te===0?0:(Y.avail_in-=te,a.arraySet(A,Y.input,Y.next_in,te,R),Y.state.wrap===1?Y.adler=l(Y.adler,A,te,R):Y.state.wrap===2&&(Y.adler=c(Y.adler,A,te,R)),Y.next_in+=te,Y.total_in+=te,te),g.lookahead+=j,g.lookahead+g.insert>=z)for(O=g.strstart-g.insert,g.ins_h=g.window[O],g.ins_h=(g.ins_h<<g.hash_shift^g.window[O+1])&g.hash_mask;g.insert&&(g.ins_h=(g.ins_h<<g.hash_shift^g.window[O+z-1])&g.hash_mask,g.prev[O&g.w_mask]=g.head[g.ins_h],g.head[g.ins_h]=O,O++,g.insert--,!(g.lookahead+g.insert<z)););}while(g.lookahead<q&&g.strm.avail_in!==0)}function be(g,V){for(var j,I;;){if(g.lookahead<q){if(re(g),g.lookahead<q&&V===d)return k;if(g.lookahead===0)break}if(j=0,g.lookahead>=z&&(g.ins_h=(g.ins_h<<g.hash_shift^g.window[g.strstart+z-1])&g.hash_mask,j=g.prev[g.strstart&g.w_mask]=g.head[g.ins_h],g.head[g.ins_h]=g.strstart),j!==0&&g.strstart-j<=g.w_size-q&&(g.match_length=oe(g,j)),g.match_length>=z)if(I=r._tr_tally(g,g.strstart-g.match_start,g.match_length-z),g.lookahead-=g.match_length,g.match_length<=g.max_lazy_match&&g.lookahead>=z){for(g.match_length--;g.strstart++,g.ins_h=(g.ins_h<<g.hash_shift^g.window[g.strstart+z-1])&g.hash_mask,j=g.prev[g.strstart&g.w_mask]=g.head[g.ins_h],g.head[g.ins_h]=g.strstart,--g.match_length!=0;);g.strstart++}else g.strstart+=g.match_length,g.match_length=0,g.ins_h=g.window[g.strstart],g.ins_h=(g.ins_h<<g.hash_shift^g.window[g.strstart+1])&g.hash_mask;else I=r._tr_tally(g,0,g.window[g.strstart]),g.lookahead--,g.strstart++;if(I&&(K(g,!1),g.strm.avail_out===0))return k}return g.insert=g.strstart<z-1?g.strstart:z-1,V===h?(K(g,!0),g.strm.avail_out===0?F:M):g.last_lit&&(K(g,!1),g.strm.avail_out===0)?k:U}function ke(g,V){for(var j,I,T;;){if(g.lookahead<q){if(re(g),g.lookahead<q&&V===d)return k;if(g.lookahead===0)break}if(j=0,g.lookahead>=z&&(g.ins_h=(g.ins_h<<g.hash_shift^g.window[g.strstart+z-1])&g.hash_mask,j=g.prev[g.strstart&g.w_mask]=g.head[g.ins_h],g.head[g.ins_h]=g.strstart),g.prev_length=g.match_length,g.prev_match=g.match_start,g.match_length=z-1,j!==0&&g.prev_length<g.max_lazy_match&&g.strstart-j<=g.w_size-q&&(g.match_length=oe(g,j),g.match_length<=5&&(g.strategy===1||g.match_length===z&&4096<g.strstart-g.match_start)&&(g.match_length=z-1)),g.prev_length>=z&&g.match_length<=g.prev_length){for(T=g.strstart+g.lookahead-z,I=r._tr_tally(g,g.strstart-1-g.prev_match,g.prev_length-z),g.lookahead-=g.prev_length-1,g.prev_length-=2;++g.strstart<=T&&(g.ins_h=(g.ins_h<<g.hash_shift^g.window[g.strstart+z-1])&g.hash_mask,j=g.prev[g.strstart&g.w_mask]=g.head[g.ins_h],g.head[g.ins_h]=g.strstart),--g.prev_length!=0;);if(g.match_available=0,g.match_length=z-1,g.strstart++,I&&(K(g,!1),g.strm.avail_out===0))return k}else if(g.match_available){if((I=r._tr_tally(g,0,g.window[g.strstart-1]))&&K(g,!1),g.strstart++,g.lookahead--,g.strm.avail_out===0)return k}else g.match_available=1,g.strstart++,g.lookahead--}return g.match_available&&(I=r._tr_tally(g,0,g.window[g.strstart-1]),g.match_available=0),g.insert=g.strstart<z-1?g.strstart:z-1,V===h?(K(g,!0),g.strm.avail_out===0?F:M):g.last_lit&&(K(g,!1),g.strm.avail_out===0)?k:U}function le(g,V,j,I,T){this.good_length=g,this.max_lazy=V,this.nice_length=j,this.max_chain=I,this.func=T}function J(){this.strm=null,this.status=0,this.pending_buf=null,this.pending_buf_size=0,this.pending_out=0,this.pending=0,this.wrap=0,this.gzhead=null,this.gzindex=0,this.method=x,this.last_flush=-1,this.w_size=0,this.w_bits=0,this.w_mask=0,this.window=null,this.window_size=0,this.prev=null,this.head=null,this.ins_h=0,this.hash_size=0,this.hash_bits=0,this.hash_mask=0,this.hash_shift=0,this.block_start=0,this.match_length=0,this.prev_match=0,this.match_available=0,this.strstart=0,this.match_start=0,this.lookahead=0,this.prev_length=0,this.max_chain_length=0,this.max_lazy_match=0,this.level=0,this.strategy=0,this.good_match=0,this.nice_match=0,this.dyn_ltree=new a.Buf16(2*C),this.dyn_dtree=new a.Buf16(2*(2*$+1)),this.bl_tree=new a.Buf16(2*(2*E+1)),se(this.dyn_ltree),se(this.dyn_dtree),se(this.bl_tree),this.l_desc=null,this.d_desc=null,this.bl_desc=null,this.bl_count=new a.Buf16(L+1),this.heap=new a.Buf16(2*w+1),se(this.heap),this.heap_len=0,this.heap_max=0,this.depth=new a.Buf16(2*w+1),se(this.depth),this.l_buf=0,this.lit_bufsize=0,this.last_lit=0,this.d_buf=0,this.opt_len=0,this.static_len=0,this.matches=0,this.insert=0,this.bi_buf=0,this.bi_valid=0}function he(g){var V;return g&&g.state?(g.total_in=g.total_out=0,g.data_type=y,(V=g.state).pending=0,V.pending_out=0,V.wrap<0&&(V.wrap=-V.wrap),V.status=V.wrap?_:N,g.adler=V.wrap===2?0:1,V.last_flush=d,r._tr_init(V),f):B(g,v)}function D(g){var V=he(g);return V===f&&(function(j){j.window_size=2*j.w_size,se(j.head),j.max_lazy_match=o[j.level].max_lazy,j.good_match=o[j.level].good_length,j.nice_match=o[j.level].nice_length,j.max_chain_length=o[j.level].max_chain,j.strstart=0,j.block_start=0,j.lookahead=0,j.insert=0,j.match_length=j.prev_length=z-1,j.match_available=0,j.ins_h=0})(g.state),V}function W(g,V,j,I,T,O){if(!g)return v;var Y=1;if(V===m&&(V=6),I<0?(Y=0,I=-I):15<I&&(Y=2,I-=16),T<1||S<T||j!==x||I<8||15<I||V<0||9<V||O<0||b<O)return B(g,v);I===8&&(I=9);var A=new J;return(g.state=A).strm=g,A.wrap=Y,A.gzhead=null,A.w_bits=I,A.w_size=1<<A.w_bits,A.w_mask=A.w_size-1,A.hash_bits=T+7,A.hash_size=1<<A.hash_bits,A.hash_mask=A.hash_size-1,A.hash_shift=~~((A.hash_bits+z-1)/z),A.window=new a.Buf8(2*A.w_size),A.head=new a.Buf16(A.hash_size),A.prev=new a.Buf16(A.w_size),A.lit_bufsize=1<<T+6,A.pending_buf_size=4*A.lit_bufsize,A.pending_buf=new a.Buf8(A.pending_buf_size),A.d_buf=1*A.lit_bufsize,A.l_buf=3*A.lit_bufsize,A.level=V,A.strategy=O,A.method=j,D(g)}o=[new le(0,0,0,0,function(g,V){var j=65535;for(j>g.pending_buf_size-5&&(j=g.pending_buf_size-5);;){if(g.lookahead<=1){if(re(g),g.lookahead===0&&V===d)return k;if(g.lookahead===0)break}g.strstart+=g.lookahead,g.lookahead=0;var I=g.block_start+j;if((g.strstart===0||g.strstart>=I)&&(g.lookahead=g.strstart-I,g.strstart=I,K(g,!1),g.strm.avail_out===0)||g.strstart-g.block_start>=g.w_size-q&&(K(g,!1),g.strm.avail_out===0))return k}return g.insert=0,V===h?(K(g,!0),g.strm.avail_out===0?F:M):(g.strstart>g.block_start&&(K(g,!1),g.strm.avail_out),k)}),new le(4,4,8,4,be),new le(4,5,16,8,be),new le(4,6,32,32,be),new le(4,4,16,16,ke),new le(8,16,32,32,ke),new le(8,16,128,128,ke),new le(8,32,128,256,ke),new le(32,128,258,1024,ke),new le(32,258,258,4096,ke)],s.deflateInit=function(g,V){return W(g,V,x,15,8,0)},s.deflateInit2=W,s.deflateReset=D,s.deflateResetKeep=he,s.deflateSetHeader=function(g,V){return g&&g.state?g.state.wrap!==2?v:(g.state.gzhead=V,f):v},s.deflate=function(g,V){var j,I,T,O;if(!g||!g.state||5<V||V<0)return g?B(g,v):v;if(I=g.state,!g.output||!g.input&&g.avail_in!==0||I.status===666&&V!==h)return B(g,g.avail_out===0?-5:v);if(I.strm=g,j=I.last_flush,I.last_flush=V,I.status===_)if(I.wrap===2)g.adler=0,ce(I,31),ce(I,139),ce(I,8),I.gzhead?(ce(I,(I.gzhead.text?1:0)+(I.gzhead.hcrc?2:0)+(I.gzhead.extra?4:0)+(I.gzhead.name?8:0)+(I.gzhead.comment?16:0)),ce(I,255&I.gzhead.time),ce(I,I.gzhead.time>>8&255),ce(I,I.gzhead.time>>16&255),ce(I,I.gzhead.time>>24&255),ce(I,I.level===9?2:2<=I.strategy||I.level<2?4:0),ce(I,255&I.gzhead.os),I.gzhead.extra&&I.gzhead.extra.length&&(ce(I,255&I.gzhead.extra.length),ce(I,I.gzhead.extra.length>>8&255)),I.gzhead.hcrc&&(g.adler=c(g.adler,I.pending_buf,I.pending,0)),I.gzindex=0,I.status=69):(ce(I,0),ce(I,0),ce(I,0),ce(I,0),ce(I,0),ce(I,I.level===9?2:2<=I.strategy||I.level<2?4:0),ce(I,3),I.status=N);else{var Y=x+(I.w_bits-8<<4)<<8;Y|=(2<=I.strategy||I.level<2?0:I.level<6?1:I.level===6?2:3)<<6,I.strstart!==0&&(Y|=32),Y+=31-Y%31,I.status=N,ie(I,Y),I.strstart!==0&&(ie(I,g.adler>>>16),ie(I,65535&g.adler)),g.adler=1}if(I.status===69)if(I.gzhead.extra){for(T=I.pending;I.gzindex<(65535&I.gzhead.extra.length)&&(I.pending!==I.pending_buf_size||(I.gzhead.hcrc&&I.pending>T&&(g.adler=c(g.adler,I.pending_buf,I.pending-T,T)),G(g),T=I.pending,I.pending!==I.pending_buf_size));)ce(I,255&I.gzhead.extra[I.gzindex]),I.gzindex++;I.gzhead.hcrc&&I.pending>T&&(g.adler=c(g.adler,I.pending_buf,I.pending-T,T)),I.gzindex===I.gzhead.extra.length&&(I.gzindex=0,I.status=73)}else I.status=73;if(I.status===73)if(I.gzhead.name){T=I.pending;do{if(I.pending===I.pending_buf_size&&(I.gzhead.hcrc&&I.pending>T&&(g.adler=c(g.adler,I.pending_buf,I.pending-T,T)),G(g),T=I.pending,I.pending===I.pending_buf_size)){O=1;break}O=I.gzindex<I.gzhead.name.length?255&I.gzhead.name.charCodeAt(I.gzindex++):0,ce(I,O)}while(O!==0);I.gzhead.hcrc&&I.pending>T&&(g.adler=c(g.adler,I.pending_buf,I.pending-T,T)),O===0&&(I.gzindex=0,I.status=91)}else I.status=91;if(I.status===91)if(I.gzhead.comment){T=I.pending;do{if(I.pending===I.pending_buf_size&&(I.gzhead.hcrc&&I.pending>T&&(g.adler=c(g.adler,I.pending_buf,I.pending-T,T)),G(g),T=I.pending,I.pending===I.pending_buf_size)){O=1;break}O=I.gzindex<I.gzhead.comment.length?255&I.gzhead.comment.charCodeAt(I.gzindex++):0,ce(I,O)}while(O!==0);I.gzhead.hcrc&&I.pending>T&&(g.adler=c(g.adler,I.pending_buf,I.pending-T,T)),O===0&&(I.status=103)}else I.status=103;if(I.status===103&&(I.gzhead.hcrc?(I.pending+2>I.pending_buf_size&&G(g),I.pending+2<=I.pending_buf_size&&(ce(I,255&g.adler),ce(I,g.adler>>8&255),g.adler=0,I.status=N)):I.status=N),I.pending!==0){if(G(g),g.avail_out===0)return I.last_flush=-1,f}else if(g.avail_in===0&&P(V)<=P(j)&&V!==h)return B(g,-5);if(I.status===666&&g.avail_in!==0)return B(g,-5);if(g.avail_in!==0||I.lookahead!==0||V!==d&&I.status!==666){var A=I.strategy===2?(function(R,Z){for(var te;;){if(R.lookahead===0&&(re(R),R.lookahead===0)){if(Z===d)return k;break}if(R.match_length=0,te=r._tr_tally(R,0,R.window[R.strstart]),R.lookahead--,R.strstart++,te&&(K(R,!1),R.strm.avail_out===0))return k}return R.insert=0,Z===h?(K(R,!0),R.strm.avail_out===0?F:M):R.last_lit&&(K(R,!1),R.strm.avail_out===0)?k:U})(I,V):I.strategy===3?(function(R,Z){for(var te,ne,ge,Ie,_e=R.window;;){if(R.lookahead<=H){if(re(R),R.lookahead<=H&&Z===d)return k;if(R.lookahead===0)break}if(R.match_length=0,R.lookahead>=z&&0<R.strstart&&(ne=_e[ge=R.strstart-1])===_e[++ge]&&ne===_e[++ge]&&ne===_e[++ge]){Ie=R.strstart+H;do;while(ne===_e[++ge]&&ne===_e[++ge]&&ne===_e[++ge]&&ne===_e[++ge]&&ne===_e[++ge]&&ne===_e[++ge]&&ne===_e[++ge]&&ne===_e[++ge]&&ge<Ie);R.match_length=H-(Ie-ge),R.match_length>R.lookahead&&(R.match_length=R.lookahead)}if(R.match_length>=z?(te=r._tr_tally(R,1,R.match_length-z),R.lookahead-=R.match_length,R.strstart+=R.match_length,R.match_length=0):(te=r._tr_tally(R,0,R.window[R.strstart]),R.lookahead--,R.strstart++),te&&(K(R,!1),R.strm.avail_out===0))return k}return R.insert=0,Z===h?(K(R,!0),R.strm.avail_out===0?F:M):R.last_lit&&(K(R,!1),R.strm.avail_out===0)?k:U})(I,V):o[I.level].func(I,V);if(A!==F&&A!==M||(I.status=666),A===k||A===F)return g.avail_out===0&&(I.last_flush=-1),f;if(A===U&&(V===1?r._tr_align(I):V!==5&&(r._tr_stored_block(I,0,0,!1),V===3&&(se(I.head),I.lookahead===0&&(I.strstart=0,I.block_start=0,I.insert=0))),G(g),g.avail_out===0))return I.last_flush=-1,f}return V!==h?f:I.wrap<=0?1:(I.wrap===2?(ce(I,255&g.adler),ce(I,g.adler>>8&255),ce(I,g.adler>>16&255),ce(I,g.adler>>24&255),ce(I,255&g.total_in),ce(I,g.total_in>>8&255),ce(I,g.total_in>>16&255),ce(I,g.total_in>>24&255)):(ie(I,g.adler>>>16),ie(I,65535&g.adler)),G(g),0<I.wrap&&(I.wrap=-I.wrap),I.pending!==0?f:1)},s.deflateEnd=function(g){var V;return g&&g.state?(V=g.state.status)!==_&&V!==69&&V!==73&&V!==91&&V!==103&&V!==N&&V!==666?B(g,v):(g.state=null,V===N?B(g,-3):f):v},s.deflateSetDictionary=function(g,V){var j,I,T,O,Y,A,R,Z,te=V.length;if(!g||!g.state||(O=(j=g.state).wrap)===2||O===1&&j.status!==_||j.lookahead)return v;for(O===1&&(g.adler=l(g.adler,V,te,0)),j.wrap=0,te>=j.w_size&&(O===0&&(se(j.head),j.strstart=0,j.block_start=0,j.insert=0),Z=new a.Buf8(j.w_size),a.arraySet(Z,V,te-j.w_size,j.w_size,0),V=Z,te=j.w_size),Y=g.avail_in,A=g.next_in,R=g.input,g.avail_in=te,g.next_in=0,g.input=V,re(j);j.lookahead>=z;){for(I=j.strstart,T=j.lookahead-(z-1);j.ins_h=(j.ins_h<<j.hash_shift^j.window[I+z-1])&j.hash_mask,j.prev[I&j.w_mask]=j.head[j.ins_h],j.head[j.ins_h]=I,I++,--T;);j.strstart=I,j.lookahead=z-1,re(j)}return j.strstart+=j.lookahead,j.block_start=j.strstart,j.insert=j.lookahead,j.lookahead=0,j.match_length=j.prev_length=z-1,j.match_available=0,g.next_in=A,g.input=R,g.avail_in=Y,j.wrap=O,f},s.deflateInfo="pako deflate (from Nodeca project)"},{"../utils/common":41,"./adler32":43,"./crc32":45,"./messages":51,"./trees":52}],47:[function(i,n,s){n.exports=function(){this.text=0,this.time=0,this.xflags=0,this.os=0,this.extra=null,this.extra_len=0,this.name="",this.comment="",this.hcrc=0,this.done=!1}},{}],48:[function(i,n,s){n.exports=function(o,a){var r,l,c,u,d,h,f,v,m,b,y,x,S,w,$,E,C,L,z,H,q,_,N,k,U;r=o.state,l=o.next_in,k=o.input,c=l+(o.avail_in-5),u=o.next_out,U=o.output,d=u-(a-o.avail_out),h=u+(o.avail_out-257),f=r.dmax,v=r.wsize,m=r.whave,b=r.wnext,y=r.window,x=r.hold,S=r.bits,w=r.lencode,$=r.distcode,E=(1<<r.lenbits)-1,C=(1<<r.distbits)-1;e:do{S<15&&(x+=k[l++]<<S,S+=8,x+=k[l++]<<S,S+=8),L=w[x&E];t:for(;;){if(x>>>=z=L>>>24,S-=z,(z=L>>>16&255)===0)U[u++]=65535&L;else{if(!(16&z)){if((64&z)==0){L=w[(65535&L)+(x&(1<<z)-1)];continue t}if(32&z){r.mode=12;break e}o.msg="invalid literal/length code",r.mode=30;break e}H=65535&L,(z&=15)&&(S<z&&(x+=k[l++]<<S,S+=8),H+=x&(1<<z)-1,x>>>=z,S-=z),S<15&&(x+=k[l++]<<S,S+=8,x+=k[l++]<<S,S+=8),L=$[x&C];i:for(;;){if(x>>>=z=L>>>24,S-=z,!(16&(z=L>>>16&255))){if((64&z)==0){L=$[(65535&L)+(x&(1<<z)-1)];continue i}o.msg="invalid distance code",r.mode=30;break e}if(q=65535&L,S<(z&=15)&&(x+=k[l++]<<S,(S+=8)<z&&(x+=k[l++]<<S,S+=8)),f<(q+=x&(1<<z)-1)){o.msg="invalid distance too far back",r.mode=30;break e}if(x>>>=z,S-=z,(z=u-d)<q){if(m<(z=q-z)&&r.sane){o.msg="invalid distance too far back",r.mode=30;break e}if(N=y,(_=0)===b){if(_+=v-z,z<H){for(H-=z;U[u++]=y[_++],--z;);_=u-q,N=U}}else if(b<z){if(_+=v+b-z,(z-=b)<H){for(H-=z;U[u++]=y[_++],--z;);if(_=0,b<H){for(H-=z=b;U[u++]=y[_++],--z;);_=u-q,N=U}}}else if(_+=b-z,z<H){for(H-=z;U[u++]=y[_++],--z;);_=u-q,N=U}for(;2<H;)U[u++]=N[_++],U[u++]=N[_++],U[u++]=N[_++],H-=3;H&&(U[u++]=N[_++],1<H&&(U[u++]=N[_++]))}else{for(_=u-q;U[u++]=U[_++],U[u++]=U[_++],U[u++]=U[_++],2<(H-=3););H&&(U[u++]=U[_++],1<H&&(U[u++]=U[_++]))}break}}break}}while(l<c&&u<h);l-=H=S>>3,x&=(1<<(S-=H<<3))-1,o.next_in=l,o.next_out=u,o.avail_in=l<c?c-l+5:5-(l-c),o.avail_out=u<h?h-u+257:257-(u-h),r.hold=x,r.bits=S}},{}],49:[function(i,n,s){var o=i("../utils/common"),a=i("./adler32"),r=i("./crc32"),l=i("./inffast"),c=i("./inftrees"),u=1,d=2,h=0,f=-2,v=1,m=852,b=592;function y(_){return(_>>>24&255)+(_>>>8&65280)+((65280&_)<<8)+((255&_)<<24)}function x(){this.mode=0,this.last=!1,this.wrap=0,this.havedict=!1,this.flags=0,this.dmax=0,this.check=0,this.total=0,this.head=null,this.wbits=0,this.wsize=0,this.whave=0,this.wnext=0,this.window=null,this.hold=0,this.bits=0,this.length=0,this.offset=0,this.extra=0,this.lencode=null,this.distcode=null,this.lenbits=0,this.distbits=0,this.ncode=0,this.nlen=0,this.ndist=0,this.have=0,this.next=null,this.lens=new o.Buf16(320),this.work=new o.Buf16(288),this.lendyn=null,this.distdyn=null,this.sane=0,this.back=0,this.was=0}function S(_){var N;return _&&_.state?(N=_.state,_.total_in=_.total_out=N.total=0,_.msg="",N.wrap&&(_.adler=1&N.wrap),N.mode=v,N.last=0,N.havedict=0,N.dmax=32768,N.head=null,N.hold=0,N.bits=0,N.lencode=N.lendyn=new o.Buf32(m),N.distcode=N.distdyn=new o.Buf32(b),N.sane=1,N.back=-1,h):f}function w(_){var N;return _&&_.state?((N=_.state).wsize=0,N.whave=0,N.wnext=0,S(_)):f}function $(_,N){var k,U;return _&&_.state?(U=_.state,N<0?(k=0,N=-N):(k=1+(N>>4),N<48&&(N&=15)),N&&(N<8||15<N)?f:(U.window!==null&&U.wbits!==N&&(U.window=null),U.wrap=k,U.wbits=N,w(_))):f}function E(_,N){var k,U;return _?(U=new x,(_.state=U).window=null,(k=$(_,N))!==h&&(_.state=null),k):f}var C,L,z=!0;function H(_){if(z){var N;for(C=new o.Buf32(512),L=new o.Buf32(32),N=0;N<144;)_.lens[N++]=8;for(;N<256;)_.lens[N++]=9;for(;N<280;)_.lens[N++]=7;for(;N<288;)_.lens[N++]=8;for(c(u,_.lens,0,288,C,0,_.work,{bits:9}),N=0;N<32;)_.lens[N++]=5;c(d,_.lens,0,32,L,0,_.work,{bits:5}),z=!1}_.lencode=C,_.lenbits=9,_.distcode=L,_.distbits=5}function q(_,N,k,U){var F,M=_.state;return M.window===null&&(M.wsize=1<<M.wbits,M.wnext=0,M.whave=0,M.window=new o.Buf8(M.wsize)),U>=M.wsize?(o.arraySet(M.window,N,k-M.wsize,M.wsize,0),M.wnext=0,M.whave=M.wsize):(U<(F=M.wsize-M.wnext)&&(F=U),o.arraySet(M.window,N,k-U,F,M.wnext),(U-=F)?(o.arraySet(M.window,N,k-U,U,0),M.wnext=U,M.whave=M.wsize):(M.wnext+=F,M.wnext===M.wsize&&(M.wnext=0),M.whave<M.wsize&&(M.whave+=F))),0}s.inflateReset=w,s.inflateReset2=$,s.inflateResetKeep=S,s.inflateInit=function(_){return E(_,15)},s.inflateInit2=E,s.inflate=function(_,N){var k,U,F,M,B,P,se,G,K,ce,ie,oe,re,be,ke,le,J,he,D,W,g,V,j,I,T=0,O=new o.Buf8(4),Y=[16,17,18,0,8,7,9,6,10,5,11,4,12,3,13,2,14,1,15];if(!_||!_.state||!_.output||!_.input&&_.avail_in!==0)return f;(k=_.state).mode===12&&(k.mode=13),B=_.next_out,F=_.output,se=_.avail_out,M=_.next_in,U=_.input,P=_.avail_in,G=k.hold,K=k.bits,ce=P,ie=se,V=h;e:for(;;)switch(k.mode){case v:if(k.wrap===0){k.mode=13;break}for(;K<16;){if(P===0)break e;P--,G+=U[M++]<<K,K+=8}if(2&k.wrap&&G===35615){O[k.check=0]=255&G,O[1]=G>>>8&255,k.check=r(k.check,O,2,0),K=G=0,k.mode=2;break}if(k.flags=0,k.head&&(k.head.done=!1),!(1&k.wrap)||(((255&G)<<8)+(G>>8))%31){_.msg="incorrect header check",k.mode=30;break}if((15&G)!=8){_.msg="unknown compression method",k.mode=30;break}if(K-=4,g=8+(15&(G>>>=4)),k.wbits===0)k.wbits=g;else if(g>k.wbits){_.msg="invalid window size",k.mode=30;break}k.dmax=1<<g,_.adler=k.check=1,k.mode=512&G?10:12,K=G=0;break;case 2:for(;K<16;){if(P===0)break e;P--,G+=U[M++]<<K,K+=8}if(k.flags=G,(255&k.flags)!=8){_.msg="unknown compression method",k.mode=30;break}if(57344&k.flags){_.msg="unknown header flags set",k.mode=30;break}k.head&&(k.head.text=G>>8&1),512&k.flags&&(O[0]=255&G,O[1]=G>>>8&255,k.check=r(k.check,O,2,0)),K=G=0,k.mode=3;case 3:for(;K<32;){if(P===0)break e;P--,G+=U[M++]<<K,K+=8}k.head&&(k.head.time=G),512&k.flags&&(O[0]=255&G,O[1]=G>>>8&255,O[2]=G>>>16&255,O[3]=G>>>24&255,k.check=r(k.check,O,4,0)),K=G=0,k.mode=4;case 4:for(;K<16;){if(P===0)break e;P--,G+=U[M++]<<K,K+=8}k.head&&(k.head.xflags=255&G,k.head.os=G>>8),512&k.flags&&(O[0]=255&G,O[1]=G>>>8&255,k.check=r(k.check,O,2,0)),K=G=0,k.mode=5;case 5:if(1024&k.flags){for(;K<16;){if(P===0)break e;P--,G+=U[M++]<<K,K+=8}k.length=G,k.head&&(k.head.extra_len=G),512&k.flags&&(O[0]=255&G,O[1]=G>>>8&255,k.check=r(k.check,O,2,0)),K=G=0}else k.head&&(k.head.extra=null);k.mode=6;case 6:if(1024&k.flags&&(P<(oe=k.length)&&(oe=P),oe&&(k.head&&(g=k.head.extra_len-k.length,k.head.extra||(k.head.extra=new Array(k.head.extra_len)),o.arraySet(k.head.extra,U,M,oe,g)),512&k.flags&&(k.check=r(k.check,U,oe,M)),P-=oe,M+=oe,k.length-=oe),k.length))break e;k.length=0,k.mode=7;case 7:if(2048&k.flags){if(P===0)break e;for(oe=0;g=U[M+oe++],k.head&&g&&k.length<65536&&(k.head.name+=String.fromCharCode(g)),g&&oe<P;);if(512&k.flags&&(k.check=r(k.check,U,oe,M)),P-=oe,M+=oe,g)break e}else k.head&&(k.head.name=null);k.length=0,k.mode=8;case 8:if(4096&k.flags){if(P===0)break e;for(oe=0;g=U[M+oe++],k.head&&g&&k.length<65536&&(k.head.comment+=String.fromCharCode(g)),g&&oe<P;);if(512&k.flags&&(k.check=r(k.check,U,oe,M)),P-=oe,M+=oe,g)break e}else k.head&&(k.head.comment=null);k.mode=9;case 9:if(512&k.flags){for(;K<16;){if(P===0)break e;P--,G+=U[M++]<<K,K+=8}if(G!==(65535&k.check)){_.msg="header crc mismatch",k.mode=30;break}K=G=0}k.head&&(k.head.hcrc=k.flags>>9&1,k.head.done=!0),_.adler=k.check=0,k.mode=12;break;case 10:for(;K<32;){if(P===0)break e;P--,G+=U[M++]<<K,K+=8}_.adler=k.check=y(G),K=G=0,k.mode=11;case 11:if(k.havedict===0)return _.next_out=B,_.avail_out=se,_.next_in=M,_.avail_in=P,k.hold=G,k.bits=K,2;_.adler=k.check=1,k.mode=12;case 12:if(N===5||N===6)break e;case 13:if(k.last){G>>>=7&K,K-=7&K,k.mode=27;break}for(;K<3;){if(P===0)break e;P--,G+=U[M++]<<K,K+=8}switch(k.last=1&G,K-=1,3&(G>>>=1)){case 0:k.mode=14;break;case 1:if(H(k),k.mode=20,N!==6)break;G>>>=2,K-=2;break e;case 2:k.mode=17;break;case 3:_.msg="invalid block type",k.mode=30}G>>>=2,K-=2;break;case 14:for(G>>>=7&K,K-=7&K;K<32;){if(P===0)break e;P--,G+=U[M++]<<K,K+=8}if((65535&G)!=(G>>>16^65535)){_.msg="invalid stored block lengths",k.mode=30;break}if(k.length=65535&G,K=G=0,k.mode=15,N===6)break e;case 15:k.mode=16;case 16:if(oe=k.length){if(P<oe&&(oe=P),se<oe&&(oe=se),oe===0)break e;o.arraySet(F,U,M,oe,B),P-=oe,M+=oe,se-=oe,B+=oe,k.length-=oe;break}k.mode=12;break;case 17:for(;K<14;){if(P===0)break e;P--,G+=U[M++]<<K,K+=8}if(k.nlen=257+(31&G),G>>>=5,K-=5,k.ndist=1+(31&G),G>>>=5,K-=5,k.ncode=4+(15&G),G>>>=4,K-=4,286<k.nlen||30<k.ndist){_.msg="too many length or distance symbols",k.mode=30;break}k.have=0,k.mode=18;case 18:for(;k.have<k.ncode;){for(;K<3;){if(P===0)break e;P--,G+=U[M++]<<K,K+=8}k.lens[Y[k.have++]]=7&G,G>>>=3,K-=3}for(;k.have<19;)k.lens[Y[k.have++]]=0;if(k.lencode=k.lendyn,k.lenbits=7,j={bits:k.lenbits},V=c(0,k.lens,0,19,k.lencode,0,k.work,j),k.lenbits=j.bits,V){_.msg="invalid code lengths set",k.mode=30;break}k.have=0,k.mode=19;case 19:for(;k.have<k.nlen+k.ndist;){for(;le=(T=k.lencode[G&(1<<k.lenbits)-1])>>>16&255,J=65535&T,!((ke=T>>>24)<=K);){if(P===0)break e;P--,G+=U[M++]<<K,K+=8}if(J<16)G>>>=ke,K-=ke,k.lens[k.have++]=J;else{if(J===16){for(I=ke+2;K<I;){if(P===0)break e;P--,G+=U[M++]<<K,K+=8}if(G>>>=ke,K-=ke,k.have===0){_.msg="invalid bit length repeat",k.mode=30;break}g=k.lens[k.have-1],oe=3+(3&G),G>>>=2,K-=2}else if(J===17){for(I=ke+3;K<I;){if(P===0)break e;P--,G+=U[M++]<<K,K+=8}K-=ke,g=0,oe=3+(7&(G>>>=ke)),G>>>=3,K-=3}else{for(I=ke+7;K<I;){if(P===0)break e;P--,G+=U[M++]<<K,K+=8}K-=ke,g=0,oe=11+(127&(G>>>=ke)),G>>>=7,K-=7}if(k.have+oe>k.nlen+k.ndist){_.msg="invalid bit length repeat",k.mode=30;break}for(;oe--;)k.lens[k.have++]=g}}if(k.mode===30)break;if(k.lens[256]===0){_.msg="invalid code -- missing end-of-block",k.mode=30;break}if(k.lenbits=9,j={bits:k.lenbits},V=c(u,k.lens,0,k.nlen,k.lencode,0,k.work,j),k.lenbits=j.bits,V){_.msg="invalid literal/lengths set",k.mode=30;break}if(k.distbits=6,k.distcode=k.distdyn,j={bits:k.distbits},V=c(d,k.lens,k.nlen,k.ndist,k.distcode,0,k.work,j),k.distbits=j.bits,V){_.msg="invalid distances set",k.mode=30;break}if(k.mode=20,N===6)break e;case 20:k.mode=21;case 21:if(6<=P&&258<=se){_.next_out=B,_.avail_out=se,_.next_in=M,_.avail_in=P,k.hold=G,k.bits=K,l(_,ie),B=_.next_out,F=_.output,se=_.avail_out,M=_.next_in,U=_.input,P=_.avail_in,G=k.hold,K=k.bits,k.mode===12&&(k.back=-1);break}for(k.back=0;le=(T=k.lencode[G&(1<<k.lenbits)-1])>>>16&255,J=65535&T,!((ke=T>>>24)<=K);){if(P===0)break e;P--,G+=U[M++]<<K,K+=8}if(le&&(240&le)==0){for(he=ke,D=le,W=J;le=(T=k.lencode[W+((G&(1<<he+D)-1)>>he)])>>>16&255,J=65535&T,!(he+(ke=T>>>24)<=K);){if(P===0)break e;P--,G+=U[M++]<<K,K+=8}G>>>=he,K-=he,k.back+=he}if(G>>>=ke,K-=ke,k.back+=ke,k.length=J,le===0){k.mode=26;break}if(32&le){k.back=-1,k.mode=12;break}if(64&le){_.msg="invalid literal/length code",k.mode=30;break}k.extra=15&le,k.mode=22;case 22:if(k.extra){for(I=k.extra;K<I;){if(P===0)break e;P--,G+=U[M++]<<K,K+=8}k.length+=G&(1<<k.extra)-1,G>>>=k.extra,K-=k.extra,k.back+=k.extra}k.was=k.length,k.mode=23;case 23:for(;le=(T=k.distcode[G&(1<<k.distbits)-1])>>>16&255,J=65535&T,!((ke=T>>>24)<=K);){if(P===0)break e;P--,G+=U[M++]<<K,K+=8}if((240&le)==0){for(he=ke,D=le,W=J;le=(T=k.distcode[W+((G&(1<<he+D)-1)>>he)])>>>16&255,J=65535&T,!(he+(ke=T>>>24)<=K);){if(P===0)break e;P--,G+=U[M++]<<K,K+=8}G>>>=he,K-=he,k.back+=he}if(G>>>=ke,K-=ke,k.back+=ke,64&le){_.msg="invalid distance code",k.mode=30;break}k.offset=J,k.extra=15&le,k.mode=24;case 24:if(k.extra){for(I=k.extra;K<I;){if(P===0)break e;P--,G+=U[M++]<<K,K+=8}k.offset+=G&(1<<k.extra)-1,G>>>=k.extra,K-=k.extra,k.back+=k.extra}if(k.offset>k.dmax){_.msg="invalid distance too far back",k.mode=30;break}k.mode=25;case 25:if(se===0)break e;if(oe=ie-se,k.offset>oe){if((oe=k.offset-oe)>k.whave&&k.sane){_.msg="invalid distance too far back",k.mode=30;break}re=oe>k.wnext?(oe-=k.wnext,k.wsize-oe):k.wnext-oe,oe>k.length&&(oe=k.length),be=k.window}else be=F,re=B-k.offset,oe=k.length;for(se<oe&&(oe=se),se-=oe,k.length-=oe;F[B++]=be[re++],--oe;);k.length===0&&(k.mode=21);break;case 26:if(se===0)break e;F[B++]=k.length,se--,k.mode=21;break;case 27:if(k.wrap){for(;K<32;){if(P===0)break e;P--,G|=U[M++]<<K,K+=8}if(ie-=se,_.total_out+=ie,k.total+=ie,ie&&(_.adler=k.check=k.flags?r(k.check,F,ie,B-ie):a(k.check,F,ie,B-ie)),ie=se,(k.flags?G:y(G))!==k.check){_.msg="incorrect data check",k.mode=30;break}K=G=0}k.mode=28;case 28:if(k.wrap&&k.flags){for(;K<32;){if(P===0)break e;P--,G+=U[M++]<<K,K+=8}if(G!==(4294967295&k.total)){_.msg="incorrect length check",k.mode=30;break}K=G=0}k.mode=29;case 29:V=1;break e;case 30:V=-3;break e;case 31:return-4;case 32:default:return f}return _.next_out=B,_.avail_out=se,_.next_in=M,_.avail_in=P,k.hold=G,k.bits=K,(k.wsize||ie!==_.avail_out&&k.mode<30&&(k.mode<27||N!==4))&&q(_,_.output,_.next_out,ie-_.avail_out)?(k.mode=31,-4):(ce-=_.avail_in,ie-=_.avail_out,_.total_in+=ce,_.total_out+=ie,k.total+=ie,k.wrap&&ie&&(_.adler=k.check=k.flags?r(k.check,F,ie,_.next_out-ie):a(k.check,F,ie,_.next_out-ie)),_.data_type=k.bits+(k.last?64:0)+(k.mode===12?128:0)+(k.mode===20||k.mode===15?256:0),(ce==0&&ie===0||N===4)&&V===h&&(V=-5),V)},s.inflateEnd=function(_){if(!_||!_.state)return f;var N=_.state;return N.window&&(N.window=null),_.state=null,h},s.inflateGetHeader=function(_,N){var k;return _&&_.state?(2&(k=_.state).wrap)==0?f:((k.head=N).done=!1,h):f},s.inflateSetDictionary=function(_,N){var k,U=N.length;return _&&_.state?(k=_.state).wrap!==0&&k.mode!==11?f:k.mode===11&&a(1,N,U,0)!==k.check?-3:q(_,N,U,U)?(k.mode=31,-4):(k.havedict=1,h):f},s.inflateInfo="pako inflate (from Nodeca project)"},{"../utils/common":41,"./adler32":43,"./crc32":45,"./inffast":48,"./inftrees":50}],50:[function(i,n,s){var o=i("../utils/common"),a=[3,4,5,6,7,8,9,10,11,13,15,17,19,23,27,31,35,43,51,59,67,83,99,115,131,163,195,227,258,0,0],r=[16,16,16,16,16,16,16,16,17,17,17,17,18,18,18,18,19,19,19,19,20,20,20,20,21,21,21,21,16,72,78],l=[1,2,3,4,5,7,9,13,17,25,33,49,65,97,129,193,257,385,513,769,1025,1537,2049,3073,4097,6145,8193,12289,16385,24577,0,0],c=[16,16,16,16,17,17,18,18,19,19,20,20,21,21,22,22,23,23,24,24,25,25,26,26,27,27,28,28,29,29,64,64];n.exports=function(u,d,h,f,v,m,b,y){var x,S,w,$,E,C,L,z,H,q=y.bits,_=0,N=0,k=0,U=0,F=0,M=0,B=0,P=0,se=0,G=0,K=null,ce=0,ie=new o.Buf16(16),oe=new o.Buf16(16),re=null,be=0;for(_=0;_<=15;_++)ie[_]=0;for(N=0;N<f;N++)ie[d[h+N]]++;for(F=q,U=15;1<=U&&ie[U]===0;U--);if(U<F&&(F=U),U===0)return v[m++]=20971520,v[m++]=20971520,y.bits=1,0;for(k=1;k<U&&ie[k]===0;k++);for(F<k&&(F=k),_=P=1;_<=15;_++)if(P<<=1,(P-=ie[_])<0)return-1;if(0<P&&(u===0||U!==1))return-1;for(oe[1]=0,_=1;_<15;_++)oe[_+1]=oe[_]+ie[_];for(N=0;N<f;N++)d[h+N]!==0&&(b[oe[d[h+N]]++]=N);if(C=u===0?(K=re=b,19):u===1?(K=a,ce-=257,re=r,be-=257,256):(K=l,re=c,-1),_=k,E=m,B=N=G=0,w=-1,$=(se=1<<(M=F))-1,u===1&&852<se||u===2&&592<se)return 1;for(;;){for(L=_-B,H=b[N]<C?(z=0,b[N]):b[N]>C?(z=re[be+b[N]],K[ce+b[N]]):(z=96,0),x=1<<_-B,k=S=1<<M;v[E+(G>>B)+(S-=x)]=L<<24|z<<16|H|0,S!==0;);for(x=1<<_-1;G&x;)x>>=1;if(x!==0?(G&=x-1,G+=x):G=0,N++,--ie[_]==0){if(_===U)break;_=d[h+b[N]]}if(F<_&&(G&$)!==w){for(B===0&&(B=F),E+=k,P=1<<(M=_-B);M+B<U&&!((P-=ie[M+B])<=0);)M++,P<<=1;if(se+=1<<M,u===1&&852<se||u===2&&592<se)return 1;v[w=G&$]=F<<24|M<<16|E-m|0}}return G!==0&&(v[E+G]=_-B<<24|64<<16|0),y.bits=F,0}},{"../utils/common":41}],51:[function(i,n,s){n.exports={2:"need dictionary",1:"stream end",0:"","-1":"file error","-2":"stream error","-3":"data error","-4":"insufficient memory","-5":"buffer error","-6":"incompatible version"}},{}],52:[function(i,n,s){var o=i("../utils/common"),a=0,r=1;function l(T){for(var O=T.length;0<=--O;)T[O]=0}var c=0,u=29,d=256,h=d+1+u,f=30,v=19,m=2*h+1,b=15,y=16,x=7,S=256,w=16,$=17,E=18,C=[0,0,0,0,0,0,0,0,1,1,1,1,2,2,2,2,3,3,3,3,4,4,4,4,5,5,5,5,0],L=[0,0,0,0,1,1,2,2,3,3,4,4,5,5,6,6,7,7,8,8,9,9,10,10,11,11,12,12,13,13],z=[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,2,3,7],H=[16,17,18,0,8,7,9,6,10,5,11,4,12,3,13,2,14,1,15],q=new Array(2*(h+2));l(q);var _=new Array(2*f);l(_);var N=new Array(512);l(N);var k=new Array(256);l(k);var U=new Array(u);l(U);var F,M,B,P=new Array(f);function se(T,O,Y,A,R){this.static_tree=T,this.extra_bits=O,this.extra_base=Y,this.elems=A,this.max_length=R,this.has_stree=T&&T.length}function G(T,O){this.dyn_tree=T,this.max_code=0,this.stat_desc=O}function K(T){return T<256?N[T]:N[256+(T>>>7)]}function ce(T,O){T.pending_buf[T.pending++]=255&O,T.pending_buf[T.pending++]=O>>>8&255}function ie(T,O,Y){T.bi_valid>y-Y?(T.bi_buf|=O<<T.bi_valid&65535,ce(T,T.bi_buf),T.bi_buf=O>>y-T.bi_valid,T.bi_valid+=Y-y):(T.bi_buf|=O<<T.bi_valid&65535,T.bi_valid+=Y)}function oe(T,O,Y){ie(T,Y[2*O],Y[2*O+1])}function re(T,O){for(var Y=0;Y|=1&T,T>>>=1,Y<<=1,0<--O;);return Y>>>1}function be(T,O,Y){var A,R,Z=new Array(b+1),te=0;for(A=1;A<=b;A++)Z[A]=te=te+Y[A-1]<<1;for(R=0;R<=O;R++){var ne=T[2*R+1];ne!==0&&(T[2*R]=re(Z[ne]++,ne))}}function ke(T){var O;for(O=0;O<h;O++)T.dyn_ltree[2*O]=0;for(O=0;O<f;O++)T.dyn_dtree[2*O]=0;for(O=0;O<v;O++)T.bl_tree[2*O]=0;T.dyn_ltree[2*S]=1,T.opt_len=T.static_len=0,T.last_lit=T.matches=0}function le(T){8<T.bi_valid?ce(T,T.bi_buf):0<T.bi_valid&&(T.pending_buf[T.pending++]=T.bi_buf),T.bi_buf=0,T.bi_valid=0}function J(T,O,Y,A){var R=2*O,Z=2*Y;return T[R]<T[Z]||T[R]===T[Z]&&A[O]<=A[Y]}function he(T,O,Y){for(var A=T.heap[Y],R=Y<<1;R<=T.heap_len&&(R<T.heap_len&&J(O,T.heap[R+1],T.heap[R],T.depth)&&R++,!J(O,A,T.heap[R],T.depth));)T.heap[Y]=T.heap[R],Y=R,R<<=1;T.heap[Y]=A}function D(T,O,Y){var A,R,Z,te,ne=0;if(T.last_lit!==0)for(;A=T.pending_buf[T.d_buf+2*ne]<<8|T.pending_buf[T.d_buf+2*ne+1],R=T.pending_buf[T.l_buf+ne],ne++,A===0?oe(T,R,O):(oe(T,(Z=k[R])+d+1,O),(te=C[Z])!==0&&ie(T,R-=U[Z],te),oe(T,Z=K(--A),Y),(te=L[Z])!==0&&ie(T,A-=P[Z],te)),ne<T.last_lit;);oe(T,S,O)}function W(T,O){var Y,A,R,Z=O.dyn_tree,te=O.stat_desc.static_tree,ne=O.stat_desc.has_stree,ge=O.stat_desc.elems,Ie=-1;for(T.heap_len=0,T.heap_max=m,Y=0;Y<ge;Y++)Z[2*Y]!==0?(T.heap[++T.heap_len]=Ie=Y,T.depth[Y]=0):Z[2*Y+1]=0;for(;T.heap_len<2;)Z[2*(R=T.heap[++T.heap_len]=Ie<2?++Ie:0)]=1,T.depth[R]=0,T.opt_len--,ne&&(T.static_len-=te[2*R+1]);for(O.max_code=Ie,Y=T.heap_len>>1;1<=Y;Y--)he(T,Z,Y);for(R=ge;Y=T.heap[1],T.heap[1]=T.heap[T.heap_len--],he(T,Z,1),A=T.heap[1],T.heap[--T.heap_max]=Y,T.heap[--T.heap_max]=A,Z[2*R]=Z[2*Y]+Z[2*A],T.depth[R]=(T.depth[Y]>=T.depth[A]?T.depth[Y]:T.depth[A])+1,Z[2*Y+1]=Z[2*A+1]=R,T.heap[1]=R++,he(T,Z,1),2<=T.heap_len;);T.heap[--T.heap_max]=T.heap[1],(function(_e,Le){var Ue,qe,de,fe,Ye,Ne,He=Le.dyn_tree,ot=Le.max_code,ti=Le.stat_desc.static_tree,Ys=Le.stat_desc.has_stree,Zs=Le.stat_desc.extra_bits,es=Le.stat_desc.extra_base,Ai=Le.stat_desc.max_length,Ki=0;for(fe=0;fe<=b;fe++)_e.bl_count[fe]=0;for(He[2*_e.heap[_e.heap_max]+1]=0,Ue=_e.heap_max+1;Ue<m;Ue++)Ai<(fe=He[2*He[2*(qe=_e.heap[Ue])+1]+1]+1)&&(fe=Ai,Ki++),He[2*qe+1]=fe,ot<qe||(_e.bl_count[fe]++,Ye=0,es<=qe&&(Ye=Zs[qe-es]),Ne=He[2*qe],_e.opt_len+=Ne*(fe+Ye),Ys&&(_e.static_len+=Ne*(ti[2*qe+1]+Ye)));if(Ki!==0){do{for(fe=Ai-1;_e.bl_count[fe]===0;)fe--;_e.bl_count[fe]--,_e.bl_count[fe+1]+=2,_e.bl_count[Ai]--,Ki-=2}while(0<Ki);for(fe=Ai;fe!==0;fe--)for(qe=_e.bl_count[fe];qe!==0;)ot<(de=_e.heap[--Ue])||(He[2*de+1]!==fe&&(_e.opt_len+=(fe-He[2*de+1])*He[2*de],He[2*de+1]=fe),qe--)}})(T,O),be(Z,Ie,T.bl_count)}function g(T,O,Y){var A,R,Z=-1,te=O[1],ne=0,ge=7,Ie=4;for(te===0&&(ge=138,Ie=3),O[2*(Y+1)+1]=65535,A=0;A<=Y;A++)R=te,te=O[2*(A+1)+1],++ne<ge&&R===te||(ne<Ie?T.bl_tree[2*R]+=ne:R!==0?(R!==Z&&T.bl_tree[2*R]++,T.bl_tree[2*w]++):ne<=10?T.bl_tree[2*$]++:T.bl_tree[2*E]++,Z=R,Ie=(ne=0)===te?(ge=138,3):R===te?(ge=6,3):(ge=7,4))}function V(T,O,Y){var A,R,Z=-1,te=O[1],ne=0,ge=7,Ie=4;for(te===0&&(ge=138,Ie=3),A=0;A<=Y;A++)if(R=te,te=O[2*(A+1)+1],!(++ne<ge&&R===te)){if(ne<Ie)for(;oe(T,R,T.bl_tree),--ne!=0;);else R!==0?(R!==Z&&(oe(T,R,T.bl_tree),ne--),oe(T,w,T.bl_tree),ie(T,ne-3,2)):ne<=10?(oe(T,$,T.bl_tree),ie(T,ne-3,3)):(oe(T,E,T.bl_tree),ie(T,ne-11,7));Z=R,Ie=(ne=0)===te?(ge=138,3):R===te?(ge=6,3):(ge=7,4)}}l(P);var j=!1;function I(T,O,Y,A){ie(T,(c<<1)+(A?1:0),3),(function(R,Z,te,ne){le(R),ce(R,te),ce(R,~te),o.arraySet(R.pending_buf,R.window,Z,te,R.pending),R.pending+=te})(T,O,Y)}s._tr_init=function(T){j||((function(){var O,Y,A,R,Z,te=new Array(b+1);for(R=A=0;R<u-1;R++)for(U[R]=A,O=0;O<1<<C[R];O++)k[A++]=R;for(k[A-1]=R,R=Z=0;R<16;R++)for(P[R]=Z,O=0;O<1<<L[R];O++)N[Z++]=R;for(Z>>=7;R<f;R++)for(P[R]=Z<<7,O=0;O<1<<L[R]-7;O++)N[256+Z++]=R;for(Y=0;Y<=b;Y++)te[Y]=0;for(O=0;O<=143;)q[2*O+1]=8,O++,te[8]++;for(;O<=255;)q[2*O+1]=9,O++,te[9]++;for(;O<=279;)q[2*O+1]=7,O++,te[7]++;for(;O<=287;)q[2*O+1]=8,O++,te[8]++;for(be(q,h+1,te),O=0;O<f;O++)_[2*O+1]=5,_[2*O]=re(O,5);F=new se(q,C,d+1,h,b),M=new se(_,L,0,f,b),B=new se(new Array(0),z,0,v,x)})(),j=!0),T.l_desc=new G(T.dyn_ltree,F),T.d_desc=new G(T.dyn_dtree,M),T.bl_desc=new G(T.bl_tree,B),T.bi_buf=0,T.bi_valid=0,ke(T)},s._tr_stored_block=I,s._tr_flush_block=function(T,O,Y,A){var R,Z,te=0;0<T.level?(T.strm.data_type===2&&(T.strm.data_type=(function(ne){var ge,Ie=4093624447;for(ge=0;ge<=31;ge++,Ie>>>=1)if(1&Ie&&ne.dyn_ltree[2*ge]!==0)return a;if(ne.dyn_ltree[18]!==0||ne.dyn_ltree[20]!==0||ne.dyn_ltree[26]!==0)return r;for(ge=32;ge<d;ge++)if(ne.dyn_ltree[2*ge]!==0)return r;return a})(T)),W(T,T.l_desc),W(T,T.d_desc),te=(function(ne){var ge;for(g(ne,ne.dyn_ltree,ne.l_desc.max_code),g(ne,ne.dyn_dtree,ne.d_desc.max_code),W(ne,ne.bl_desc),ge=v-1;3<=ge&&ne.bl_tree[2*H[ge]+1]===0;ge--);return ne.opt_len+=3*(ge+1)+5+5+4,ge})(T),R=T.opt_len+3+7>>>3,(Z=T.static_len+3+7>>>3)<=R&&(R=Z)):R=Z=Y+5,Y+4<=R&&O!==-1?I(T,O,Y,A):T.strategy===4||Z===R?(ie(T,2+(A?1:0),3),D(T,q,_)):(ie(T,4+(A?1:0),3),(function(ne,ge,Ie,_e){var Le;for(ie(ne,ge-257,5),ie(ne,Ie-1,5),ie(ne,_e-4,4),Le=0;Le<_e;Le++)ie(ne,ne.bl_tree[2*H[Le]+1],3);V(ne,ne.dyn_ltree,ge-1),V(ne,ne.dyn_dtree,Ie-1)})(T,T.l_desc.max_code+1,T.d_desc.max_code+1,te+1),D(T,T.dyn_ltree,T.dyn_dtree)),ke(T),A&&le(T)},s._tr_tally=function(T,O,Y){return T.pending_buf[T.d_buf+2*T.last_lit]=O>>>8&255,T.pending_buf[T.d_buf+2*T.last_lit+1]=255&O,T.pending_buf[T.l_buf+T.last_lit]=255&Y,T.last_lit++,O===0?T.dyn_ltree[2*Y]++:(T.matches++,O--,T.dyn_ltree[2*(k[Y]+d+1)]++,T.dyn_dtree[2*K(O)]++),T.last_lit===T.lit_bufsize-1},s._tr_align=function(T){ie(T,2,3),oe(T,S,q),(function(O){O.bi_valid===16?(ce(O,O.bi_buf),O.bi_buf=0,O.bi_valid=0):8<=O.bi_valid&&(O.pending_buf[O.pending++]=255&O.bi_buf,O.bi_buf>>=8,O.bi_valid-=8)})(T)}},{"../utils/common":41}],53:[function(i,n,s){n.exports=function(){this.input=null,this.next_in=0,this.avail_in=0,this.total_in=0,this.output=null,this.next_out=0,this.avail_out=0,this.total_out=0,this.msg="",this.state=null,this.data_type=2,this.adler=0}},{}],54:[function(i,n,s){(function(o){(function(a,r){if(!a.setImmediate){var l,c,u,d,h=1,f={},v=!1,m=a.document,b=Object.getPrototypeOf&&Object.getPrototypeOf(a);b=b&&b.setTimeout?b:a,l={}.toString.call(a.process)==="[object process]"?function(w){process.nextTick(function(){x(w)})}:(function(){if(a.postMessage&&!a.importScripts){var w=!0,$=a.onmessage;return a.onmessage=function(){w=!1},a.postMessage("","*"),a.onmessage=$,w}})()?(d="setImmediate$"+Math.random()+"$",a.addEventListener?a.addEventListener("message",S,!1):a.attachEvent("onmessage",S),function(w){a.postMessage(d+w,"*")}):a.MessageChannel?((u=new MessageChannel).port1.onmessage=function(w){x(w.data)},function(w){u.port2.postMessage(w)}):m&&"onreadystatechange"in m.createElement("script")?(c=m.documentElement,function(w){var $=m.createElement("script");$.onreadystatechange=function(){x(w),$.onreadystatechange=null,c.removeChild($),$=null},c.appendChild($)}):function(w){setTimeout(x,0,w)},b.setImmediate=function(w){typeof w!="function"&&(w=new Function(""+w));for(var $=new Array(arguments.length-1),E=0;E<$.length;E++)$[E]=arguments[E+1];var C={callback:w,args:$};return f[h]=C,l(h),h++},b.clearImmediate=y}function y(w){delete f[w]}function x(w){if(v)setTimeout(x,0,w);else{var $=f[w];if($){v=!0;try{(function(E){var C=E.callback,L=E.args;switch(L.length){case 0:C();break;case 1:C(L[0]);break;case 2:C(L[0],L[1]);break;case 3:C(L[0],L[1],L[2]);break;default:C.apply(r,L)}})($)}finally{y(w),v=!1}}}}function S(w){w.source===a&&typeof w.data=="string"&&w.data.indexOf(d)===0&&x(+w.data.slice(d.length))}})(typeof self>"u"?o===void 0?this:o:self)}).call(this,typeof cs<"u"?cs:typeof self<"u"?self:typeof window<"u"?window:{})},{}]},{},[10])(10)})})(ho)),ho.exports}var hg=pg();const Yl=fg(hg);function Zl(e){const t=(e||"").trim();return t?`即现（${t}）`:"即现"}async function Jl(e,t){var i,n,s;if(!t)return"";if(typeof document<"u"){const o=document.querySelector(`.protyle-title[data-node-id="${t}"] .protyle-title__input`)||document.querySelector(`.protyle[data-doc-id="${t}"] .protyle-title__input`)||(e.getActiveDocumentId()===t?document.querySelector(".layout__wnd--active .protyle-title__input"):null)||document.querySelector(".protyle-title__input"),a=((o==null?void 0:o.innerText)||(o==null?void 0:o.textContent)||"").trim();if(a)return a}if(e.latestCompiledDoc&&e.latestCompiledDoc.docId===t){const o=(i=e.latestCompiledDoc.slides)==null?void 0:i[0],a=(n=o==null?void 0:o.blocks)==null?void 0:n.find(r=>r.type==="h"||r.type==="NodeHeading");if(a!=null&&a.content)return a.content.trim()}try{const o=await dn(`SELECT content FROM blocks WHERE id = '${t}' AND type = 'd' LIMIT 1`).catch(()=>[]);if(Array.isArray(o)&&o.length>0&&((s=o[0])!=null&&s.content))return String(o[0].content).trim()}catch{}return""}async function mg(e,t,i){var c,u,d;const n=Fw(),s=!!((c=n==null?void 0:n.isPinned)!=null&&c.value),o=String(((u=n==null?void 0:n.pinnedDocId)==null?void 0:u.value)||"");if(s&&o&&i&&i!==o)return;const a=i||(s&&o?o:e.currentDocId||e.getActiveDocumentId());let r=(t||"").trim();!r&&a&&(r=typeof e.fetchDocumentTitle=="function"?await e.fetchDocumentTitle(a):await Jl(e,a));const l=Zl(r);if(e.previewTab&&typeof e.previewTab.updateTitle=="function"){e.previewTab.updateTitle(l),e.previewTab.headElement&&e.previewTab.headElement.setAttribute("title",l);return}if(typeof document<"u"){const h=Array.from(document.querySelectorAll('.layout-tab-bar .item[data-type="tab-header"]'));for(const f of h){const v=f.querySelector(".item__text"),m=((d=v==null?void 0:v.textContent)==null?void 0:d.trim())||"";if(m.includes("Slidev 演示预览")||m.startsWith("即现")){v&&(v.textContent=l),f.setAttribute("title",l);break}}}}function $n(e){return(e||"").replace(/[/\\?%*:|"<>]/g,"_").replace(/_+/g,"_").trim().replace(/^_+|_+$/g,"")||"presentation"}async function Ii(e,t,i){var s,o;const n=t||(e==null?void 0:e.docId)||"";if(i&&typeof i.fetchDocumentTitle=="function"&&n)try{const a=await i.fetchDocumentTitle(n);if(a&&a.trim())return $n(a)}catch{}if(typeof document<"u")try{const a=(n?document.querySelector(`.protyle-title[data-node-id="${n}"] .protyle-title__input`):null)||(n?document.querySelector(`.protyle[data-doc-id="${n}"] .protyle-title__input`):null)||document.querySelector(".layout__wnd--active .protyle-title__input")||document.querySelector(".protyle-title__input"),r=((a==null?void 0:a.innerText)||(a==null?void 0:a.textContent)||"").trim();if(r)return $n(r)}catch{}if((s=e==null?void 0:e.config)!=null&&s.title&&e.config.title.trim()&&e.config.title.trim().toLowerCase()!=="presentation")return $n(e.config.title);if(e!=null&&e.slides&&e.slides.length>0){const r=(o=e.slides[0].blocks)==null?void 0:o.find(c=>c.type==="h"||c.type==="NodeHeading"),l=((r==null?void 0:r.content)||"").replace(/^#+\s*/,"").trim();if(l)return $n(l)}return"presentation"}function gg(e,t){if(typeof document>"u")return!1;const i=URL.createObjectURL(t),n=document.createElement("a");return n.href=i,n.download=e,document.body.appendChild(n),n.click(),document.body.removeChild(n),URL.revokeObjectURL(i),!0}function la(e,t){if(typeof document>"u")return!1;const i=document.createElement("a");return i.href=t,i.download=e,document.body.appendChild(i),i.click(),document.body.removeChild(i),!0}async function vg(e){if(typeof navigator>"u"||!navigator.clipboard||typeof ClipboardItem>"u")return!1;try{const i=await(await fetch(e)).blob();return await navigator.clipboard.write([new ClipboardItem({[i.type||"image/png"]:i})]),!0}catch(t){return console.warn("[image-exporter] 复制图像至剪贴板失败:",t),!1}}async function zo(e,t){return new Promise(i=>{let n=[],s=null;const o=()=>{s&&(clearTimeout(s),s=null),n.forEach(l=>l()),n=[]};s=setTimeout(()=>{o(),i({success:!1,error:"单页截图超时（沙箱无响应）"})},2e4);const a=e.onCapturePageDone(l=>{o(),i({success:!0,dataUrl:l.dataUrl})});n.push(a);const r=e.onCaptureError(l=>{o(),i({success:!1,error:l})});n.push(r),e.startImageExport({mode:"current",scale:(t==null?void 0:t.scale)||2,format:(t==null?void 0:t.format)||"png"})})}async function Xl(e,t){const i=[],n=$n((t==null?void 0:t.title)||"presentation");return new Promise(s=>{let o=[],a=null;const r=()=>{a&&(clearTimeout(a),a=null),o.forEach(f=>f()),o=[]},l=()=>{a&&clearTimeout(a),a=setTimeout(()=>{r(),s({success:!1,error:"幻灯片逐页导出超时（沙箱无响应）"})},35e3)};l();const c=e.onCaptureProgress(f=>{var v;l(),(v=t==null?void 0:t.onProgress)==null||v.call(t,f.current,f.total,f.pageIndex)});o.push(c);const u=e.onCapturePageDone(f=>{l(),(f.mode==="all"||!f.mode)&&i.push({pageIndex:f.pageIndex,dataUrl:f.dataUrl})});o.push(u);const d=async()=>{r();try{if(i.length===0){s({success:!1,error:"未采集到幻灯片图像数据"});return}const f=new Yl,v=(t==null?void 0:t.format)==="jpeg"?"jpg":"png";for(const y of i){const x=String(y.pageIndex).padStart(2,"0"),S=y.dataUrl.split(",")[1];f.file(`slide-${x}.${v}`,S,{base64:!0})}const m=await f.generateAsync({type:"blob",compression:"DEFLATE"}),b=gg(`${n}.zip`,m);s({success:b,total:i.length})}catch(f){s({success:!1,error:(f==null?void 0:f.message)||String(f)})}};o.push(e.onCaptureComplete(d));const h=e.onCaptureError(f=>{r(),s({success:!1,error:f})});o.push(h),e.startImageExport({mode:"all",scale:(t==null?void 0:t.scale)||2,format:(t==null?void 0:t.format)||"png"})})}async function Ql(e,t){if(typeof document>"u")return{success:!1,error:"环境不支持 DOM 沙箱挂载"};const i=document.createElement("iframe");i.style.position="fixed",i.style.left="-9999px",i.style.top="-9999px",i.style.width="1920px",i.style.height="1080px",i.style.opacity="0",i.style.pointerEvents="none",i.src="/plugins/siyuan-live-slides/slides-client/index.html?headless=true",document.body.appendChild(i);const n=new Qn;n.attach(i);try{if(await new Promise((s,o)=>{const a=setTimeout(()=>o(new Error("静默后台沙箱加载超时")),12e3);n.onClientReady(()=>{clearTimeout(a),s()})}),n.updateSlides(e.slides,e.config,e.fullMarkdown),await new Promise(s=>setTimeout(s,250)),(t==null?void 0:t.mode)==="current"){const s=await zo(n,t);return{success:s.success,total:1,error:s.error}}else{const s=(t==null?void 0:t.title)||await Ii(e,e.docId);return await Xl(n,{...t,title:s})}}catch(s){return{success:!1,error:(s==null?void 0:s.message)||String(s)}}finally{n.detach(),i.remove()}}const bg=1500,yg=500,kg=4,wg=new Set(["INPUT","TEXTAREA","SELECT"]);function ec(e){const t=e;return!t||!t.tagName?!1:wg.has(t.tagName)||t.isContentEditable===!0}function xg(e){let t="",i=!1,n=null,s=null;function o(){e.onStateChange&&e.onStateChange({display:t,invalid:i})}function a(){n&&(clearTimeout(n),n=null),s&&(clearTimeout(s),s=null)}function r(){a(),t="",i=!1,o()}function l(){n&&clearTimeout(n),n=setTimeout(r,bg)}function c(){n&&(clearTimeout(n),n=null),i=!0,o(),s&&clearTimeout(s),s=setTimeout(r,yg)}function u(d){if(e.isEnabled&&!e.isEnabled()||ec(d.target)||d.isComposing||d.ctrlKey||d.metaKey||d.altKey)return!1;if(/^[0-9]$/.test(d.key))return i||t.length>=kg||(t+=d.key,o(),l()),!0;if(d.key==="Enter"){if(!t||i)return!1;const f=parseInt(t,10),v=e.getTotalPages();return!isNaN(f)&&f>=1&&v>0&&f<=v?(r(),e.onJump(f),!0):(c(),!0)}return d.key==="Escape"&&(t||i)?(r(),!0):!1}return{handleKeydown:u,getState:()=>({display:t,invalid:i}),clear:r}}const Sg={class:"spm-slides-tab__toolbar"},Cg={class:"spm-slides-tab__nav"},_g=["disabled"],$g={class:"spm-page-badge"},Ig=["disabled"],Mg=["aria-label"],Tg=["aria-label"],Eg={class:"spm-slides-tab__tools"},Ag={key:3,class:"spm-export-image-dropdown",style:{position:"relative",display:"inline-flex","align-items":"center"}},Bg={key:0,class:"b3-menu b3-menu--context",style:{position:"absolute",top:"calc(100% + 4px)",right:"0","z-index":"100","min-width":"190px","box-shadow":"var(--b3-point-shadow)","border-radius":"4px",background:"var(--b3-theme-surface)"}},Dg=["src"],Lg=At({__name:"SlidesPreviewTab",setup(e,{expose:t}){const i=Nt("plugin"),n=Nt("sandboxBridge",new Qn),s=new jm(n),o=new Cp,a=ve("web-sandbox"),r=ve(3030),l=ve(null),c=ve(!1),u=ve(null),d=ve(1),h=ve(1),f=ve(!1),v=ve(!1),m=ve(!1),b=ve("siyuan"),y=ve(""),x=ve(""),S=ve(""),w=ve(!1),$=ve(!1),E=ve(""),C=ve(""),L=ve(!1),z=xg({getTotalPages:()=>h.value,isEnabled:()=>!v.value,onJump:A=>_(A),onStateChange:A=>{C.value=A.display,L.value=A.invalid}});function H(A){if(A.key==="o"||A.key==="O"){if(v.value||A.isComposing||A.ctrlKey||A.metaKey||A.altKey||ec(A.target))return;A.preventDefault(),q();return}z.handleKeydown(A)&&A.preventDefault()}function q(){var A,R;if(a.value==="pro-cli"){(A=u.value)==null||A.focus(),ue.showMessage("Pro 模式使用官方原生总览：在画面内按 O 呼出");return}n.toggleOverview(),(R=u.value)==null||R.focus()}function _(A){var R;d.value=A,a.value==="pro-cli"?o.nativeBridge.navigateToPage(A):n.navigatePage(A),(R=u.value)==null||R.focus()}const N=ve("/plugins/siyuan-live-slides/slides-client/index.html");let k=null,U=null,F=null,M=null,B=null,P=null,se=null,G=null;gn(()=>{u.value&&(n.attach(u.value),o.nativeBridge.attach(u.value)),k=n.onSlideChanged((A,R)=>{d.value=A,h.value=R}),U=n.onBlockClicked((A,R)=>{d.value=R,s.setActiveBlockId(A),A||On(),i&&typeof i.handleBlockClickedFromSlide=="function"?i.handleBlockClickedFromSlide(A,R):A&&Vi(A,i==null?void 0:i.app)}),F=n.onOpenInEditor((A,R)=>{d.value=R,s.setActiveBlockId(A),Vi(A,i==null?void 0:i.app)}),M=o.nativeBridge.onPageChanged((A,R)=>{d.value=A,h.value=R}),B=n.onOpenPeekDrawer(async A=>{const R=qs();if(A.peekType==="siyuan"&&R.enableWebServeJump){let Z=!1;if(G&&G.docId===A.target)Z=!0;else if(G&&G.slides&&G.slides.some(te=>{var ne;return(ne=te.blocks)==null?void 0:ne.some(ge=>ge.id===A.target)}))Z=!1;else try{const te=await dn(`SELECT id, root_id, type FROM blocks WHERE id = '${A.target}' LIMIT 1`);te&&te.length>0&&(Z=te[0].type==="d"||te[0].id===te[0].root_id)}catch(te){console.warn("[SlidesPreviewTab] detect block type failed:",te)}b.value="web",w.value=!0,x.value=Al(R.webServeUrl,A.target,{focus:!Z}),S.value=A.title||`${Z?"思源文档":"思源块"}: ${A.target.slice(0,8)}`,v.value=!0,n.freezeKeyboardNav(!0)}else{if(b.value=A.peekType,A.peekType==="siyuan")y.value=A.target,S.value=A.title||`块速览: ${A.target.slice(0,8)}`;else{const Z=Fl(A.target);if(Z.external){he(A.target);return}w.value=!0,x.value=Z.url,S.value=A.title||Z.url}v.value=!0,n.freezeKeyboardNav(!0)}}),P=n.onRequestToggleFullscreen(()=>{W()}),se=n.onOpenPresenter(()=>{g()}),typeof document<"u"&&document.addEventListener("fullscreenchange",D)}),Us(()=>{typeof document<"u"&&document.removeEventListener("fullscreenchange",D),B&&B(),P&&P(),se&&se(),k&&k(),U&&U(),F&&F(),M&&M(),n.detach(),z.clear(),s.destroy(),o.destroy()});async function K(){if(a.value==="web-sandbox"){if(!G){ue.showMessage("请先在主编辑区打开演示文档");return}ue.showMessage("正在探测本地 Node 环境并编排 Slidev Pro 进程...");const A=await o.startProMode(G,ko);if(!A.success){ue.showMessage(`无法启动官方 Pro 模式：${A.error}`);return}a.value="pro-cli",r.value=A.port||3030,N.value=A.url,u.value&&o.nativeBridge.attach(u.value),ue.showMessage(`🟢 已成功接入官方原生 Slidev 服务 (端口: ${r.value})`)}else o.stopProMode(),a.value="web-sandbox",N.value="/plugins/siyuan-live-slides/slides-client/index.html",u.value&&n.attach(u.value),ue.showMessage("已切回内置高保真沙箱")}function ce(){$.value=!$.value,$.value?(E.value=(G==null?void 0:G.docId)||"",i&&typeof i.updatePreviewTabHeader=="function"&&i.updatePreviewTabHeader("",E.value)):(E.value="",ke(),i&&typeof i.updatePreviewTabHeader=="function"&&i.updatePreviewTabHeader())}let ie=0;function oe(A){if(v.value||Math.abs(A.deltaY)<Math.abs(A.deltaX)||Math.abs(A.deltaY)<15)return;const R=Date.now();R-ie<280||(ie=R,A.deltaY>0?be():re())}function re(){if(d.value>1){const A=d.value-1;d.value=A,a.value==="pro-cli"?o.nativeBridge.navigateToPage(A):n.navigatePage(A)}}function be(){if(d.value<h.value){const A=d.value+1;d.value=A,a.value==="pro-cli"?o.nativeBridge.navigateToPage(A):n.navigatePage(A)}}function ke(){i&&typeof i.compileCurrentDocument=="function"?i.compileCurrentDocument():i!=null&&i.eventBus&&typeof i.eventBus.emit=="function"&&i.eventBus.emit("slides:request-compile")}function le(){v.value=!1,n.freezeKeyboardNav(!1)}function J(){le()}function he(A){var ne,ge;const R=/^file:/i.test(A),Z=R||/^[a-zA-Z]:[\\/]/.test(A),te=Mt("electron");if(Z&&typeof((ne=te==null?void 0:te.shell)==null?void 0:ne.openPath)=="function"){te.shell.openPath(R?Hl(A):A),ue.showMessage("本地文件不在思源工作区内，已交由系统默认浏览器打开");return}typeof((ge=te==null?void 0:te.shell)==null?void 0:ge.openExternal)=="function"?te.shell.openExternal(A).catch(()=>{typeof window<"u"&&window.open(A,"_blank")}):typeof window<"u"&&window.open(A,"_blank"),ue.showMessage("该地址无法在速览抽屉内加载，已交由系统默认浏览器打开")}function D(){typeof document<"u"&&(c.value=!!document.fullscreenElement,n.postMessage("FULLSCREEN_CHANGED",{isFullscreen:c.value}))}function W(){const A=l.value||u.value;A&&(document.fullscreenElement?document.exitFullscreen().then(()=>{n.postMessage("FULLSCREEN_CHANGED",{isFullscreen:!1})}).catch(()=>{}):A.requestFullscreen().then(()=>{n.postMessage("FULLSCREEN_CHANGED",{isFullscreen:!0})}).catch(()=>{}))}function g(){i&&typeof i.openPresenterTab=="function"&&i.openPresenterTab()}async function V(){if(!G){ue.showMessage("请先在主编辑区打开幻灯片文档");return}const A=await Ii(G,i==null?void 0:i.currentDocId,i),R=Gl(G,{title:A});Kl(`${A}.html`,R)&&ue.showMessage(`已开始下载单文件离线 HTML 演示包 (${A}.html)`)}function j(){if(!G){ue.showMessage("请先在主编辑区打开幻灯片文档");return}ql(G)&&ue.showMessage("已唤起打印视窗，请在打印选项中选择「另存为 PDF」")}const I=ve(!1);async function T(){if(I.value){ue.showMessage("正在逐页导出幻灯片图片中，请稍候...",2e3);return}if(!G){ue.showMessage("请先在主编辑区打开幻灯片文档");return}I.value=!0;try{ue.showMessage("正在逐页导出幻灯片图片...",2e3);const A=await Ii(G,i==null?void 0:i.currentDocId,i),R=await Xl(n,{title:A,onProgress:(Z,te)=>{ue.showMessage(`正在导出幻灯片图片 (${Z} / ${te})...`,1500)}});R.success?ue.showMessage(`🎉 成功导出 ${R.total||0} 张高清图片并保存为 ${A}.zip！`,4e3):ue.showMessage(`导出图片失败：${R.error||"未知异常"}`)}finally{I.value=!1}}async function O(){if(!G){ue.showMessage("请先在主编辑区打开幻灯片文档");return}ue.showMessage("正在导出当前幻灯片图片...",1500);const A=await zo(n);if(A.success&&A.dataUrl){const R=await Ii(G,i==null?void 0:i.currentDocId,i),Z=d.value||1,ne=(h.value||1)>1?`${R}-${Z}.png`:`${R}.png`;la(ne,A.dataUrl),ue.showMessage(`已下载当前页高清图片 (${ne})`)}else ue.showMessage(`导出当前页图片失败：${A.error||"未知异常"}`)}async function Y(){if(!G){ue.showMessage("请先在主编辑区打开幻灯片文档");return}ue.showMessage("正在复制当前幻灯片截图到剪贴板...",1500);const A=await zo(n);if(A.success&&A.dataUrl)if(await vg(A.dataUrl))ue.showMessage(`已成功将第 ${d.value||1} 页幻灯片复制到剪贴板！`);else{const Z=await Ii(G,i==null?void 0:i.currentDocId,i),te=d.value||1,ge=(h.value||1)>1?`${Z}-${te}.png`:`${Z}.png`;la(ge,A.dataUrl),ue.showMessage(`剪贴板权限不可用，已自动下载为 ${ge}`)}else ue.showMessage(`复制失败：${A.error||"未知异常"}`)}return t({updateDocument(A,R){$.value&&E.value&&R&&R!==E.value||(G=A,$.value&&!E.value&&(E.value=A.docId),h.value=A.slides.length,s.setDocId(A.docId),s.updateSlidesIndex(A.slides),a.value==="pro-cli"?o.scaffolder.scaffold(A,ko).catch(()=>{}):n.updateSlides(A.slides,A.config,A.fullMarkdown,A.customThemeCss),i&&typeof i.updatePreviewTabHeader=="function"&&i.updatePreviewTabHeader("",A.docId))},navigateToBlock(A){s.onCursorFocusBlock(A)},isPinned:$,pinnedDocId:E,engineMode:a,toggleEngineMode:K}),(A,R)=>(X(),ee("div",{class:"spm-slides-preview-tab",onKeydown:H},[p("div",Sg,[p("div",Cg,[p("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s",disabled:d.value<=1,"aria-label":"上一页",onClick:re},[ae(pe,{name:"chevron-left"})],8,_g),p("span",$g,Ce(d.value)+" / "+Ce(h.value||1),1),p("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s",disabled:d.value>=h.value,"aria-label":"下一页",onClick:be},[ae(pe,{name:"chevron-right"})],8,Ig),p("button",{class:$e(["spm-icon-btn b3-tooltips b3-tooltips__s",{"is-primary":$.value}]),"aria-label":$.value?"已锁定当前文档（点击解除）："+E.value:"点击锁定当前文档（不随主编辑区切换）",onClick:ce},[ae(pe,{name:"pin"}),p("span",null,Ce($.value?"已锁定":"跟随"),1)],10,Mg),me($t)("proMode")?(X(),ee("button",{key:0,class:$e(["spm-icon-btn b3-tooltips b3-tooltips__s",{"is-primary":a.value==="pro-cli"}]),"aria-label":a.value==="pro-cli"?"当前：官方原生 Pro 模式 (localhost:"+r.value+")，点击切回沙箱":"当前：内置高保真沙箱，点击切换官方原生 Pro 模式",onClick:K},[ae(pe,{name:"rocket"}),p("span",null,Ce(a.value==="pro-cli"?"Pro ("+r.value+")":"沙箱"),1)],10,Tg)):Te("",!0)]),p("div",Eg,[p("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"缩略图总览 (O)",onClick:q},[ae(pe,{name:"columns"})]),me($t)("presenterMode")?(X(),ee("button",{key:0,class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"双屏演讲者视图 (Presenter Mode ⌥M)",onClick:g},[ae(pe,{name:"presenter"})])):Te("",!0),me($t)("exportHtml")?(X(),ee("button",{key:1,class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"导出单文件 HTML 演示包",onClick:V},[ae(pe,{name:"export-html"})])):Te("",!0),me($t)("exportPdf")?(X(),ee("button",{key:2,class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"导出 16:9 PDF 演示讲义",onClick:j},[ae(pe,{name:"export-pdf"})])):Te("",!0),me($t)("exportImage")?(X(),ee("div",Ag,[p("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"导出幻灯片为图片包 (ZIP)",onClick:T},[ae(pe,{name:"export-image"})]),p("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s",style:{padding:"2px 2px","margin-left":"-4px"},"aria-label":"更多图片导出选项",onClick:R[0]||(R[0]=Yt(Z=>f.value=!f.value,["stop"]))},[ae(pe,{name:"chevron-down"})]),f.value?(X(),ee("div",Bg,[p("button",{class:"b3-menu__item",onClick:R[1]||(R[1]=Z=>{T(),f.value=!1})},[...R[6]||(R[6]=[p("span",{class:"b3-menu__label"},"📦 导出全篇为图片包 (ZIP)",-1)])]),p("button",{class:"b3-menu__item",onClick:R[2]||(R[2]=Z=>{O(),f.value=!1})},[...R[7]||(R[7]=[p("span",{class:"b3-menu__label"},"🖼️ 导出当前页为图片 (PNG)",-1)])]),p("button",{class:"b3-menu__item",onClick:R[3]||(R[3]=Z=>{Y(),f.value=!1})},[...R[8]||(R[8]=[p("span",{class:"b3-menu__label"},"📋 复制当前页至剪贴板",-1)])])])):Te("",!0)])):Te("",!0),p("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"重新编译并刷新",onClick:ke},[ae(pe,{name:"refresh"})]),p("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"全屏放映",onClick:W},[ae(pe,{name:"fullscreen"})])])]),p("div",{ref_key:"fullscreenContainerRef",ref:l,class:"spm-slides-tab__viewport spm-slides-fullscreen-container",onWheel:oe},[p("iframe",{ref_key:"sandboxIframeRef",ref:u,class:"spm-slides-tab__iframe",src:N.value,frameborder:"0",allow:"fullscreen; autoplay"},null,8,Dg),ae(em,{visible:v.value,"onUpdate:visible":R[4]||(R[4]=Z=>v.value=Z),"is-maximized":m.value,"onUpdate:isMaximized":R[5]||(R[5]=Z=>m.value=Z),title:S.value,onClose:le},{default:el(()=>[b.value==="siyuan"&&y.value?(X(),Zt(cm,{key:0,"block-id":y.value,title:S.value,plugin:me(i),onExternalJump:J},null,8,["block-id","title","plugin"])):Te("",!0),w.value?Pt((X(),Zt(Hm,{key:1,visible:v.value&&b.value==="web",url:x.value,title:S.value,onExternalJump:J},null,8,["visible","url","title"])),[[Do,b.value==="web"]]):Te("",!0)]),_:1},8,["visible","is-maximized","title"]),Pt(p("div",{class:$e(["spm-jump-badge",{"is-invalid":L.value}])},Ce(C.value),3),[[Do,C.value]])],544)],32))}}),Pg=ei(Lg,[["__scopeId","data-v-2bf44815"]]);function tc(e){if(!e||e.length===0)return{maxStep:0,blockMap:new Map,idMap:new Map};const t=new Map,i=new Map,n=new Map;let s=0;const o=(r,l)=>{t.set(r,l);const c=r.id||r.blockId;c&&i.set(c,l)},a=e.filter(r=>r.slot!=="slot-divider-right");for(const r of a){if(r.parentContainerId&&r.parentClicks&&r.parentClicks.trim()!==""&&!n.has(r.parentContainerId)){const d=String(r.parentClicks).trim();if(/^\d+$/.test(d)){const h=parseInt(d,10);s=Math.max(s,h),n.set(r.parentContainerId,h)}else s+=1,n.set(r.parentContainerId,s)}if(!!!(r.clicks&&String(r.clicks).trim()!=="")){if(r.parentContainerId&&n.has(r.parentContainerId)){const d=n.get(r.parentContainerId);o(r,{type:"step",step:d})}else o(r,{type:"always"});continue}const c=String(r.clicks).trim();if(!c){s+=1,o(r,{type:"step",step:s});continue}if(c.startsWith("[")&&c.endsWith("]"))try{const d=JSON.parse(c);if(Array.isArray(d)&&d.length>=2){const h=Math.min(Number(d[0]),Number(d[1])),f=Math.max(Number(d[0]),Number(d[1]));if(!isNaN(h)&&!isNaN(f)){s=Math.max(s,f),o(r,{type:"range",min:h,max:f});continue}}}catch{}if(c.toLowerCase()==="hide"){s+=1,o(r,{type:"hide",step:s});continue}if(/^\+\d+$/.test(c)||c==="true"){const d=c==="true"?1:parseInt(c.slice(1),10)||1;s+=d,o(r,{type:"step",step:s});continue}if(/^-\d+$/.test(c)){const d=parseInt(c.slice(1),10)||1;s=Math.max(1,s-d),o(r,{type:"step",step:s});continue}if(/^\d+$/.test(c)){const d=parseInt(c,10);if(!isNaN(d)){s=Math.max(s,d),o(r,{type:"step",step:d});continue}}const u=parseInt(c,10);!isNaN(u)&&u>0?(s=Math.max(s,u),o(r,{type:"step",step:u})):(s+=1,o(r,{type:"step",step:s}))}return{maxStep:s,blockMap:t,idMap:i}}function Og(e,t,i){if(!e)return"v-click-visible";const n=e.id||e.blockId,s=i.blockMap.get(e)||(n?i.idMap.get(n):null);return!s||s.type==="always"?"v-click-visible":s.type==="range"?t>=s.min&&t<=s.max?"v-click-visible":"v-click-hidden":s.type==="hide"?t<s.step?"v-click-visible":"v-click-hidden":s.type==="step"?t>=s.step?"v-click-visible":"v-click-hidden":"v-click-visible"}const Ho=980;function Rg(e){if(!e)return 0;const i=tc(e.blocks||[]).maxStep||0,n=e.frontmatter||{},s=n.mask;if(s!=="down"&&s!=="right")return i;const o=hd(n.maskRatio),r=n.maskInitial==="revealed"?Math.max(0,o.steps-1):o.steps;return Math.max(i,r)}function Ng(e,t=Ho){const i=(e||"16/9").trim();let n=16/9;if(i==="4/3"||i==="4:3")n=4/3;else if(i==="16/10"||i==="16:10")n=16/10;else if(i.includes("/")||i.includes(":")){const o=i.includes("/")?"/":":",a=i.split(o).map(r=>parseFloat(r.trim()));a.length===2&&a[0]>0&&a[1]>0&&!isNaN(a[0])&&!isNaN(a[1])&&(n=a[0]/a[1])}else{const o=parseFloat(i);!isNaN(o)&&o>.2&&o<5&&(n=o)}const s=Math.ceil(t/n);return{baseWidth:t,baseHeight:s,ratio:n}}function ca(e,t,i=Ho,n=552,s=16){const o=i>0?i:Ho,a=n>0?n:552,r=Math.max(0,e-s),l=Math.max(0,t-s);if(r<=0||l<=0)return{scale:.36,boxWidth:Math.round(o*.36),boxHeight:Math.round(a*.36)};const c=Math.min(r/o,l/a),u=Math.max(.08,Math.min(1.5,Number(c.toFixed(4))));return{scale:u,boxWidth:Math.max(1,Math.round(o*u)),boxHeight:Math.max(1,Math.round(a*u))}}function zg(e){return{...e,frontmatter:{...e.frontmatter||{}},blocks:Array.isArray(e.blocks)?e.blocks.map(t=>({...t,attrs:t.attrs?{...t.attrs}:void 0,attributes:t.attributes?{...t.attributes}:void 0,motion:t.motion?{...t.motion}:void 0,children:Array.isArray(t.children)?t.children.map(i=>({...i,attrs:i.attrs?{...i.attrs}:void 0,attributes:i.attributes?{...i.attributes}:void 0})):void 0})):[]}}function da(e,t){if(!e)return"";const i=zg(e),n=i.frontmatter||{},s=n.layout||"default",o=(t==null?void 0:t.config)||{};(s==="image-right"||s==="image-left")&&!n.image&&!n.background&&o.image&&(n.image=o.image);const a=typeof(t==null?void 0:t.currentStep)=="number",r=a?Math.max(0,t.currentStep):0,l=a?tc(i.blocks||[]):null,u=Vl(i,{containerClassName:"slide-block",leftColClass:"pdf-col pdf-col--left two-cols-left",rightColClass:"pdf-col pdf-col--right two-cols-right",allSlides:(t==null?void 0:t.allSlides)||[],currentPageIndex:(t==null?void 0:t.pageIndex)||i.pageIndex||1,highlight:!0,blockClassResolver:l?S=>{if(Og(S,r,l)==="v-click-hidden")return"presenter-v-click-pending";if(r>0){const $=S.id||S.blockId,E=l.blockMap.get(S)||($?l.idMap.get($):void 0);if((E==null?void 0:E.type)==="step"&&E.step===r||(E==null?void 0:E.type)==="range"&&E.min===r)return"presenter-v-click-active"}return""}:void 0}).replace(/<video\b([^>]*)>/gi,(S,w)=>{let $=w.replace(/\bcontrols\b/gi,"").trim();return/\bmuted\b/i.test($)||($+=" muted"),`<video ${$.trim()}>`}),d=n.spacing,h=d&&d!=="inherit"?d:o.spacing||"normal",f=["slide-content",`layout-${s}`,`spacing-${h}`,n.class||"",n.layoutClass||""].filter(Boolean).join(" "),v=[],m=(n.background||"").trim();if(m)if(/^(?:https?:\/\/|\/|data:|assets\/|\.\/assets\/)/i.test(m)){const S=m.startsWith("assets/")?`/${m}`:m.startsWith("./assets/")?m.slice(1):m;v.push(`background-image:url('${rt(S)}');background-size:cover;background-position:center;background-repeat:no-repeat;`)}else v.push(`background:${rt(m)};`);const b=typeof n.zoom=="number"?n.zoom:typeof n.zoom=="string"?parseFloat(n.zoom):1,y=!isNaN(b)&&b>0?b:1;y!==1&&v.push(`width:${(100/y).toFixed(2)}%;height:${(100/y).toFixed(2)}%;transform-origin:top left;transform:scale(${y});`);const x=v.length>0?` style="${v.join("")}"`:"";return`<div class="${rt(f)}"${x}>${u}</div>`}const Hg={class:"presenter-header"},Fg={class:"presenter-title-area"},jg={class:"presenter-brand"},Wg={class:"header-pills"},Ug={class:"pill pill-page"},Vg={key:0,class:"pill pill-step"},Gg={class:"header-toolbar"},Kg={class:"timer-capsule"},qg={class:"timer-digits"},Yg={class:"timer-actions"},Zg=["aria-label"],Jg={class:"wall-clock b3-tooltips b3-tooltips__sw","aria-label":"系统当前时间"},Xg={key:0,class:"presenter-grid"},Qg={class:"slide-panels"},ev={class:"panel-box current-slide-panel"},tv={class:"panel-header"},iv={class:"panel-header-left"},nv={class:"panel-page-num"},sv={class:"panel-header-meta"},ov={key:0,class:"panel-step-pill"},rv={class:"panel-layout-pill"},av=["aria-label"],lv=["data-theme","data-slides-theme","data-normalize-headings","data-hide-unordered-markers","data-hide-ordered-markers","innerHTML"],cv={key:1,class:"panel-fallback"},dv=["aria-label"],uv={class:"panel-header"},fv={class:"panel-header-left"},pv={key:0,class:"panel-page-num"},hv={class:"panel-header-meta"},mv={key:0,class:"panel-end-pill"},gv={key:1,class:"panel-layout-pill"},vv=["aria-label"],bv=["data-theme","data-slides-theme","data-normalize-headings","data-hide-unordered-markers","data-hide-ordered-markers","innerHTML"],yv={key:1,class:"panel-fallback"},kv={class:"notes-panel"},wv={class:"panel-header"},xv={class:"panel-header-left"},Sv={class:"notes-size-controls"},Cv=["disabled"],_v={class:"notes-size-value"},$v=["disabled"],Iv={key:1,class:"presenter-empty"},Mv={class:"empty-icon-wrap"},Tv={class:"empty-actions"},Ev={class:"presenter-actions"},Av={class:"nav-btn-group"},Bv=["disabled"],Dv=["disabled"],Lv={class:"actions-center"},Pv={class:"center-meta"},Ov={class:"progress-pill"},Rv={class:"nav-btn-group"},Nv=["aria-label"],zv={class:"step-dots-text"},Hv=["disabled"],Fv=["disabled"],jv=280,Wv=15,Uv=At({__name:"SlidesPresenterTab",setup(e,{expose:t}){const i=Nt("plugin"),n=Nt("sandboxBridge",new Qn),s=ve([]),o=ve({}),a=ve(1),r=ve(0),l=ve(0),c=ve(0),u=xe(()=>s.value.length||l.value),d=ve(null),h=ve(null),f=ve({width:0,height:0}),v=ve({width:0,height:0}),m=xe(()=>{var de;return Ng((de=o.value)==null?void 0:de.aspectRatio)}),b=xe(()=>{var de;return((de=o.value)==null?void 0:de.theme)||"default"}),y=xe(()=>{var de;return((de=o.value)==null?void 0:de.colorSchema)==="light"?"light":"dark"}),x=xe(()=>{var de;return!!((de=o.value)!=null&&de.normalizeHeadingSizes)}),S=xe(()=>{var de;return((de=o.value)==null?void 0:de.showUnorderedListMarkers)===!1}),w=xe(()=>{var de;return((de=o.value)==null?void 0:de.showOrderedListMarkers)===!1}),$=xe(()=>ca(f.value.width,f.value.height,m.value.baseWidth,m.value.baseHeight,14)),E=xe(()=>ca(v.value.width,v.value.height,m.value.baseWidth,m.value.baseHeight,14));function C(){d.value&&(f.value={width:d.value.clientWidth,height:d.value.clientHeight}),h.value&&(v.value={width:h.value.clientWidth,height:h.value.clientHeight})}let L=null;function z(){typeof window>"u"||typeof window.ResizeObserver!="function"||(L||(L=new window.ResizeObserver(()=>{C()})),L.disconnect(),d.value&&L.observe(d.value),h.value&&L.observe(h.value))}Ui([d,h,u],()=>{Is(()=>{z(),C()})},{flush:"post"});const H=ve(0),q=ve(!0);let _=null,N=Date.now(),k=0;const U=xe(()=>{const de=String(Math.floor(H.value/60)).padStart(2,"0"),fe=String(H.value%60).padStart(2,"0");return`${de}:${fe}`});function F(){if(q.value){const de=k+(Date.now()-N);H.value=Math.floor(de/1e3)}}function M(){q.value?(k+=Date.now()-N,q.value=!1):(N=Date.now(),q.value=!0,F())}function B(){N=Date.now(),k=0,H.value=0}const P=ve("");let se=null;function G(){const de=new Date,fe=String(de.getHours()).padStart(2,"0"),Ye=String(de.getMinutes()).padStart(2,"0");P.value=`${fe}:${Ye}`}const K=xe(()=>s.value.length===0?null:s.value[a.value-1]||null),ce=xe(()=>a.value>=s.value.length?null:s.value[a.value]||null),ie=xe(()=>K.value?Rg(K.value):c.value),oe=xe(()=>a.value>1||r.value>0),re=xe(()=>a.value<u.value||r.value<ie.value),be=xe(()=>da(K.value,{config:o.value,allSlides:s.value,pageIndex:a.value,currentStep:r.value})),ke=xe(()=>da(ce.value,{config:o.value,allSlides:s.value,pageIndex:a.value+1})),le=xe(()=>{var fe;if(!K.value)return"无内容";const de=(fe=K.value.blocks)==null?void 0:fe[0];return(de==null?void 0:de.content)||(de==null?void 0:de.rawMarkdown)||`第 ${a.value} 页`});function J(de){return(de||[]).slice(1).map(fe=>(fe.content||fe.rawMarkdown||"").trim()).filter(fe=>fe&&!/^(image\s+)?assets\/\S*$/i.test(fe)&&!/^!\[[^\]]*\]\(assets\/[^)]*\)$/.test(fe)).join(" | ").slice(0,120)}const he=xe(()=>{var de;return J((de=K.value)==null?void 0:de.blocks)}),D=xe(()=>{var fe;if(!ce.value)return"演示结束";const de=(fe=ce.value.blocks)==null?void 0:fe[0];return(de==null?void 0:de.content)||(de==null?void 0:de.rawMarkdown)||`第 ${a.value+1} 页`}),W=xe(()=>ce.value?J(ce.value.blocks):"这是最后一页"),g=xe(()=>{var de;return((de=K.value)==null?void 0:de.notes)||""}),V=ve(20);function j(){V.value<36&&(V.value+=2)}function I(){V.value>14&&(V.value-=2)}const T=xe(()=>u.value<=1?100:Math.round(a.value/u.value*100));let O=null;try{O=new BroadcastChannel("siyuan-slides-sync"),O.onmessage=de=>{const fe=de.data;if(fe&&(fe.type==="SYNC_PAGE"&&typeof fe.page=="number"&&(a.value=fe.page,r.value=typeof fe.step=="number"?Math.max(0,fe.step):0,typeof fe.maxStep=="number"&&(c.value=Math.max(0,fe.maxStep))),fe.type==="SYNC_SLIDES"&&Array.isArray(fe.slides)&&(s.value=fe.slides,fe.config&&typeof fe.config=="object"&&(o.value=fe.config)),fe.type==="REQUEST_SYNC"&&s.value.length>0))try{O==null||O.postMessage({type:"SYNC_SLIDES",slides:JSON.parse(JSON.stringify(s.value)),config:JSON.parse(JSON.stringify(o.value||{}))}),O==null||O.postMessage({type:"SYNC_PAGE",page:a.value,step:r.value,maxStep:ie.value})}catch{}}}catch{O=null}function Y(de,fe=0){const Ye=Number(de)||1,Ne=Math.max(0,Number(fe)||0);n.navigatePage(Ye,Ne);try{O==null||O.postMessage({type:"SYNC_PAGE",page:Ye,step:Ne,maxStep:ie.value})}catch{}}function A(){if(r.value<ie.value){r.value++,Y(a.value,r.value);return}a.value<u.value&&(a.value++,r.value=0,Y(a.value,0))}function R(){if(r.value>0){r.value--,Y(a.value,r.value);return}a.value>1&&(a.value--,r.value=0,Y(a.value,0))}function Z(){a.value<u.value&&(a.value++,r.value=0,Y(a.value,0))}function te(){a.value>1&&(a.value--,r.value=0,Y(a.value,0))}function ne(){a.value=1,r.value=0,B(),Y(1,0)}function ge(){const de=i;typeof(de==null?void 0:de.openBottomPreviewTab)=="function"&&de.openBottomPreviewTab()}function Ie(){const de=i;typeof(de==null?void 0:de.openStandalonePreviewWindow)=="function"&&de.openStandalonePreviewWindow()}function _e(de){var fe,Ye;if(!(de.key===" "&&((Ye=(fe=de.target)==null?void 0:fe.closest)!=null&&Ye.call(fe,"button")))){if(de.shiftKey&&de.key==="ArrowRight"||de.key==="ArrowDown"){de.preventDefault(),Z();return}if(de.shiftKey&&de.key==="ArrowLeft"||de.key==="ArrowUp"){de.preventDefault(),te();return}de.key==="ArrowRight"||de.key===" "||de.key==="PageDown"?(de.preventDefault(),A()):(de.key==="ArrowLeft"||de.key==="PageUp")&&(de.preventDefault(),R())}}let Le=0;function Ue(de){var Ne,He;if(Math.abs(de.deltaY)<Wv)return;const fe=(He=(Ne=de.target)==null?void 0:Ne.closest)==null?void 0:He.call(Ne,".notes-content");if(fe){const ot=fe.scrollHeight-fe.clientHeight;if(ot>2&&(de.deltaY>0&&fe.scrollTop<ot-1||de.deltaY<0&&fe.scrollTop>1))return}const Ye=Date.now();Ye-Le<jv||(Le=Ye,de.deltaY>0?A():R())}let qe=null;return gn(()=>{var fe;N=Date.now(),k=0,_=window.setInterval(F,500),typeof document<"u"&&document.addEventListener("visibilitychange",F),G(),se=window.setInterval(G,1e3),qe=n.onSlideChanged((Ye,Ne,He,ot,ti)=>{a.value=Ye,Ne>0&&(l.value=Ne),typeof ot=="number"&&(r.value=Math.max(0,ot)),typeof ti=="number"&&(c.value=Math.max(0,ti))});try{O==null||O.postMessage({type:"REQUEST_SYNC"})}catch{}const de=i==null?void 0:i.latestCompiledDoc;(fe=de==null?void 0:de.slides)!=null&&fe.length&&(s.value=de.slides,de.config&&(o.value=de.config)),typeof window<"u"&&window.addEventListener("resize",C),Is(()=>{z(),C()})}),Us(()=>{_&&(window.clearInterval(_),_=null),typeof document<"u"&&document.removeEventListener("visibilitychange",F),se&&(window.clearInterval(se),se=null),qe&&qe(),typeof window<"u"&&window.removeEventListener("resize",C),L&&(L.disconnect(),L=null);try{O==null||O.close()}catch{}O=null}),t({updateDocument(de){var fe;(fe=de==null?void 0:de.slides)!=null&&fe.length&&(s.value=de.slides),de!=null&&de.config&&(o.value=de.config)}}),(de,fe)=>{var Ye,Ne,He;return X(),ee("div",{class:"spm-presenter-tab",tabindex:"0",onKeydown:_e,onWheel:Ue},[p("header",Hg,[p("div",Fg,[p("div",jg,[ae(pe,{name:"presenter",class:"brand-icon"}),fe[1]||(fe[1]=p("span",{class:"title-name"},"演讲者控制台",-1))]),p("div",Wg,[p("span",Ug,"P."+Ce(a.value)+" / "+Ce(u.value||1),1),ie.value>0?(X(),ee("span",Vg,[ae(pe,{name:"step",class:"pill-icon"}),_t(" 步进 "+Ce(r.value)+" / "+Ce(ie.value),1)])):Te("",!0)])]),p("div",Gg,[p("button",{class:"btn-tool b3-tooltips b3-tooltips__s","aria-label":"弹出大屏放映独立窗口 (16:9)",onClick:Ie},[ae(pe,{name:"window"}),fe[2]||(fe[2]=p("span",{class:"btn-tool-label"},"独立放映",-1))]),p("div",Kg,[ae(pe,{name:"clock",class:"timer-icon"}),p("span",qg,Ce(U.value),1),p("div",Yg,[p("button",{class:"timer-btn b3-tooltips b3-tooltips__s","aria-label":q.value?"暂停计时":"继续计时",onClick:M},[ae(pe,{name:q.value?"pause":"play"},null,8,["name"])],8,Zg),p("button",{class:"timer-btn b3-tooltips b3-tooltips__s","aria-label":"重置计时",onClick:B},[ae(pe,{name:"reset"})])])]),p("div",Jg,[p("span",null,Ce(P.value),1)])])]),u.value>0?(X(),ee("main",Xg,[p("section",Qg,[p("div",ev,[p("div",tv,[p("div",iv,[fe[3]||(fe[3]=p("span",{class:"panel-tag is-current"},"当前放映",-1)),p("span",nv,"P."+Ce(a.value),1)]),p("div",sv,[ie.value>0?(X(),ee("span",ov," 步进 "+Ce(r.value)+" / "+Ce(ie.value),1)):Te("",!0),p("span",rv,Ce(((Ne=(Ye=K.value)==null?void 0:Ye.frontmatter)==null?void 0:Ne.layout)||"default"),1)])]),p("div",{ref_key:"currentPreviewRef",ref:d,class:"panel-preview","aria-label":le.value},[K.value?(X(),ee("div",{key:0,class:"presenter-thumb-box",style:qt({width:$.value.boxWidth+"px",height:$.value.boxHeight+"px"})},[p("div",{class:$e(["presenter-thumb-viewport slide-viewport","slides-theme-"+b.value]),"data-theme":y.value,"data-slides-theme":b.value,"data-normalize-headings":x.value?"true":"false","data-hide-unordered-markers":S.value?"true":"false","data-hide-ordered-markers":w.value?"true":"false",style:qt({width:m.value.baseWidth+"px",height:m.value.baseHeight+"px",transform:"scale("+$.value.scale+")"}),innerHTML:be.value},null,14,lv)],4)):(X(),ee("div",cv,[p("h2",null,Ce(le.value),1),p("p",null,Ce(he.value),1)]))],8,av)]),p("div",{class:$e(["panel-box next-slide-panel",{"is-clickable":!!ce.value,"b3-tooltips b3-tooltips__n":!!ce.value}]),"aria-label":ce.value?"点击直接跳至下一页":"",onClick:fe[0]||(fe[0]=ot=>ce.value&&Z())},[p("div",uv,[p("div",fv,[fe[4]||(fe[4]=p("span",{class:"panel-tag"},"下一页预告",-1)),a.value<u.value?(X(),ee("span",pv,"P."+Ce(a.value+1),1)):Te("",!0)]),p("div",hv,[a.value>=u.value?(X(),ee("span",mv,"已到尾页")):ce.value?(X(),ee("span",gv,Ce(((He=ce.value.frontmatter)==null?void 0:He.layout)||"default"),1)):Te("",!0)])]),p("div",{ref_key:"nextPreviewRef",ref:h,class:"panel-preview panel-preview--dim","aria-label":D.value},[ce.value?(X(),ee("div",{key:0,class:"presenter-thumb-box",style:qt({width:E.value.boxWidth+"px",height:E.value.boxHeight+"px"})},[p("div",{class:$e(["presenter-thumb-viewport slide-viewport","slides-theme-"+b.value]),"data-theme":y.value,"data-slides-theme":b.value,"data-normalize-headings":x.value?"true":"false","data-hide-unordered-markers":S.value?"true":"false","data-hide-ordered-markers":w.value?"true":"false",style:qt({width:m.value.baseWidth+"px",height:m.value.baseHeight+"px",transform:"scale("+E.value.scale+")"}),innerHTML:ke.value},null,14,bv)],4)):(X(),ee("div",yv,[p("h2",null,Ce(D.value),1),p("p",null,Ce(W.value),1)]))],8,vv)],10,dv)]),p("section",kv,[p("div",wv,[p("div",xv,[ae(pe,{name:"notes",class:"panel-title-icon"}),fe[5]||(fe[5]=p("span",null,"讲稿备忘",-1))]),p("div",Sv,[p("button",{class:"notes-btn b3-tooltips b3-tooltips__w","aria-label":"减小字体",disabled:V.value<=14,onClick:I},[ae(pe,{name:"minus"})],8,Cv),p("span",_v,Ce(V.value)+"px",1),p("button",{class:"notes-btn b3-tooltips b3-tooltips__w","aria-label":"增大字体",disabled:V.value>=36,onClick:j},[ae(pe,{name:"plus"})],8,$v)])]),p("div",{class:$e(["notes-content",{"is-empty":!g.value}]),style:qt({fontSize:V.value+"px"})},Ce(g.value||"（本页未设置演讲者备忘录）"),7)])])):(X(),ee("main",Iv,[p("div",Mv,[ae(pe,{name:"refresh",class:"empty-icon"})]),fe[8]||(fe[8]=p("h2",null,"等待大屏放映数据",-1)),fe[9]||(fe[9]=p("p",null,"未检测到活跃的幻灯片数据，请先开启大屏放映端。",-1)),p("div",Tv,[p("button",{class:"btn-empty-action b3-tooltips b3-tooltips__n","aria-label":"在思源中打开底部演示预览页签",onClick:ge},[ae(pe,{name:"presenter"}),fe[6]||(fe[6]=p("span",null,"打开大屏放映页签",-1))]),p("button",{class:"btn-empty-action btn-empty-action--popout b3-tooltips b3-tooltips__n","aria-label":"将放映端弹出为独立窗口 (16:9)",onClick:Ie},[ae(pe,{name:"window"}),fe[7]||(fe[7]=p("span",null,"弹出独立放映窗口",-1))])])])),p("footer",Ev,[p("div",Av,[p("button",{class:"btn-nav btn-nav--slide b3-tooltips b3-tooltips__ne",disabled:a.value<=1,"aria-label":"快速返回上一页 (Shift + ←)",onClick:te},[ae(pe,{name:"chevrons-left"}),fe[10]||(fe[10]=p("span",null,"上一页",-1))],8,Bv),p("button",{class:"btn-nav btn-nav--step b3-tooltips b3-tooltips__n",disabled:!oe.value,"aria-label":"回退一步 (←)",onClick:R},[ae(pe,{name:"chevron-left"}),fe[11]||(fe[11]=p("span",null,"上一步",-1))],8,Dv)]),p("div",Lv,[p("div",Pv,[p("span",Ov,Ce(T.value)+"%",1)]),p("button",{class:"btn-restart b3-tooltips b3-tooltips__n","aria-label":"从第一页重新放映 (Home)",onClick:ne},[ae(pe,{name:"reset"}),fe[12]||(fe[12]=p("span",null,"重头放映",-1))])]),p("div",Rv,[ie.value>0?(X(),ee("div",{key:0,class:"step-dots-bar b3-tooltips b3-tooltips__n","aria-label":`步进进度: ${r.value} / ${ie.value}`},[(X(!0),ee(Xe,null,xt(ie.value,ot=>(X(),ee("span",{key:ot,class:$e(["step-dot",{"is-active":ot<=r.value}])},null,2))),128)),p("span",zv,Ce(r.value)+"/"+Ce(ie.value),1)],8,Nv)):Te("",!0),p("button",{class:"btn-nav btn-nav--step btn-nav--primary b3-tooltips b3-tooltips__n",disabled:!re.value,"aria-label":"触发下一步骤或进入下一页 (Space / →)",onClick:A},[fe[13]||(fe[13]=p("span",null,"下一步",-1)),ae(pe,{name:"chevron-right"})],8,Hv),p("button",{class:"btn-nav btn-nav--slide b3-tooltips b3-tooltips__nw",disabled:a.value>=u.value,"aria-label":"跳过本页剩余步骤，直接进入下一页 (Shift + →)",onClick:Z},[fe[14]||(fe[14]=p("span",null,"下一页",-1)),ae(pe,{name:"chevrons-right"})],8,Fv)])])],32)}}}),Vv=ei(Uv,[["__scopeId","data-v-c103f4a6"]]),Gv={class:"spm-layout-picker"},Kv={class:"spm-layout-picker__grid"},qv=["title","onClick"],Yv={class:"spm-layout-icon"},Zv={class:"spm-layout-label"},Jv=At({__name:"LayoutPicker",props:{modelValue:{}},emits:["update:modelValue","change"],setup(e,{emit:t}){const i=e,n=t,s=[{name:"cover",label:"封面",desc:"大标题与副标题封面页"},{name:"default",label:"标准",desc:"标题在上方，内容在下方"},{name:"two-cols",label:"双栏",desc:"左右双栏对比展示"},{name:"cols-header",label:"表头多栏",desc:"顶部通栏标题，下方自适应 2~N 栏"},{name:"clover",label:"四叶草",desc:"2x2 田字型四象限卡片布局"},{name:"image-right",label:"图右",desc:"左侧为内容，右侧全屏背景图"},{name:"image-left",label:"图左",desc:"左侧全屏背景图，右侧为内容"},{name:"center",label:"居中",desc:"内容全屏垂直水平居中"},{name:"fact",label:"大字报",desc:"核心数据或指标突出展示"},{name:"intro",label:"介绍",desc:"演讲者自我介绍或章节导览"},{name:"quote",label:"引言",desc:"名人名言与强调段落"}];function o(r){return i.modelValue===r||r==="cols-header"&&(i.modelValue==="two-cols-header"||i.modelValue==="three-cols-header")}function a(r){n("update:modelValue",r),n("change",r)}return(r,l)=>(X(),ee("div",Gv,[l[0]||(l[0]=p("div",{class:"spm-layout-picker__header"},"选择页面版式",-1)),p("div",Kv,[(X(),ee(Xe,null,xt(s,c=>p("div",{key:c.name,class:$e(["spm-layout-item",{active:o(c.name)}]),title:c.desc,onClick:u=>a(c.name)},[p("div",Yv,[ae(pe,{name:"layout-"+c.name},null,8,["name"])]),p("span",Zv,Ce(c.label),1)],10,qv)),64))])]))}}),Xv=ei(Jv,[["__scopeId","data-v-96c8a248"]]),Qv={key:0,class:"spm-transition-selector__header"},eb={class:"spm-transition-list"},tb=["onClick"],ib={class:"spm-transition-meta"},nb={class:"spm-transition-label"},sb={class:"spm-transition-preview-box"},ob=At({__name:"TransitionSelector",props:{modelValue:{},hideHeader:{type:Boolean},title:{}},emits:["update:modelValue","change"],setup(e,{emit:t}){const i=t,n=[{name:"slide-left",label:"向左滑入",desc:"向左滑入：页面从右侧向左平滑推入，最通用标准的横向幻灯片动效"},{name:"slide-right",label:"向右滑入",desc:"向右滑入：页面从左侧向右平滑推入，适合倒序回退或逆向章节叙述"},{name:"slide-up",label:"向上推入",desc:"向上推入：页面从底部向上平滑推入，适合纵向展开或纵深层级展示"},{name:"fade",label:"淡入淡出",desc:"淡入淡出：透明度平滑渐变过度，典雅柔和，适合学术长篇与沉浸叙事"},{name:"zoom",label:"缩放进入",desc:"缩放进入：页面由中心向外平滑放大，富有动感冲击力，适合聚焦重点"}];function s(o){i("update:modelValue",o),i("change",o)}return(o,a)=>(X(),ee("div",{class:$e(["spm-transition-selector",{"spm-transition-selector--no-header":e.hideHeader}])},[e.hideHeader?Te("",!0):(X(),ee("div",Qv,Ce(e.title||"转场动效"),1)),p("div",eb,[(X(),ee(Xe,null,xt(n,r=>p("div",{key:r.name,class:$e(["spm-transition-item",{active:e.modelValue===r.name}]),onClick:l=>s(r.name)},[p("div",ib,[p("span",nb,Ce(r.label),1)]),p("div",sb,[p("div",{class:$e(["spm-anim-cube","anim-"+r.name])},null,2)])],10,tb)),64))])],2))}}),ic=ei(ob,[["__scopeId","data-v-b5051f69"]]),rb={class:"spm-section spm-section--page"},ab={class:"spm-section-header"},lb={key:0,class:"spm-card-control",style:{"border-left":"3px solid var(--b3-theme-primary)",background:"rgba(var(--b3-theme-primary-rgb, 66, 133, 244), 0.06)",padding:"8px 12px","margin-top":"6px"}},cb={style:{display:"flex","align-items":"center","justify-content":"space-between",gap:"8px"}},db={style:{"font-size":"11px",display:"flex","align-items":"center",gap:"6px",flex:"1"}},ub={key:1,class:"spm-card-control"},fb={class:"spm-control-header"},pb={class:"spm-control-title-group"},hb={class:"spm-control-title"},mb={class:"spm-quick-chips"},gb=["onClick"],vb={style:{display:"flex",gap:"6px","align-items":"center","margin-top":"6px"}},bb=["value"],yb=["aria-label"],kb={key:1,class:"spm-icon-btn b3-tooltips b3-tooltips__sw",disabled:"",style:{opacity:"0.45",cursor:"not-allowed",padding:"0 8px",height:"26px","font-size":"11px","white-space":"nowrap","flex-shrink":"0"},"aria-label":"当前页未检测到调整过列宽的横向超级块"},wb={key:0,style:{"margin-top":"6px","font-size":"11px",opacity:"0.85",display:"flex","align-items":"center",gap:"4px"}},xb={style:{background:"rgba(125, 125, 125, 0.15)",padding:"1px 4px","border-radius":"3px","font-weight":"bold"}},Sb={key:1,style:{"margin-top":"6px","font-size":"11px",opacity:"0.6",display:"flex","align-items":"center",gap:"4px"}},Cb={class:"spm-card-control"},_b={class:"spm-control-header"},$b={class:"spm-control-title-group"},Ib={class:"spm-control-title"},Mb={class:"spm-segmented-group"},Tb={key:0,style:{"margin-top":"10px",display:"flex","flex-direction":"column",gap:"8px"}},Eb={style:{display:"flex","align-items":"center","justify-content":"space-between"}},Ab=["aria-label"],Bb={class:"spm-quick-chips"},Db=["onClick"],Lb=["value"],Pb={style:{"font-size":"10.5px",opacity:"0.6","line-height":"1.35","margin-top":"-2px"}},Ob={style:{display:"flex",gap:"8px","margin-top":"2px"}},Rb={style:{flex:"1"}},Nb={class:"spm-segmented-group"},zb={style:{flex:"1"}},Hb={class:"spm-segmented-group"},Fb={class:"spm-card-control"},jb={class:"spm-control-header"},Wb={class:"spm-control-title-group"},Ub={class:"spm-control-title"},Vb={class:"spm-segmented-group"},Gb={class:"spm-card-control"},Kb={class:"spm-control-header"},qb={class:"spm-control-title-group"},Yb={class:"spm-control-title"},Zb={class:"spm-quick-chips"},Jb=["onClick"],Xb=["value"],Qb={key:2,class:"spm-card-control"},e1={class:"spm-control-header"},t1={class:"spm-control-title-group"},i1={class:"spm-control-title"},n1={class:"spm-quick-chips"},s1=["onClick"],o1=["value"],r1={class:"spm-card-control"},a1={class:"spm-control-header"},l1={class:"spm-control-title-group"},c1={class:"spm-control-title"},d1={key:0,class:"spm-note-status-box"},u1=["title"],f1={class:"spm-action-grid",style:{"margin-top":"6px"}},p1={key:1,class:"spm-note-empty-box"},h1={class:"spm-batch-actions-box",style:{"margin-top":"8px","border-top":"1px dashed var(--b3-border-color, #e2e8f0)","padding-top":"8px"}},m1={class:"spm-action-grid"},g1=["disabled"],v1=["disabled"],b1={class:"spm-card-control"},y1={class:"spm-action-grid"},k1=At({__name:"PageInspectorSection",props:{pageLayout:{},pageTransition:{},pageBackground:{},pageSpacing:{},pageImage:{},pageNotes:{},pageIndex:{},pageLayoutRatio:{},pageMask:{},pageMaskRatio:{},pageMaskStyle:{},pageMaskInitial:{},detectedSbRatio:{},detectedSbInfo:{},isBatchProcessing:{type:Boolean}},emits:["update:pageLayout","update:pageTransition","update:pageBackground","update:pageSpacing","update:pageImage","update:pageLayoutRatio","update:pageMask","update:pageMaskRatio","update:pageMaskStyle","update:pageMaskInitial","applySuperBlockLayout","resetSuperblockRatio","addNoteBlock","locateNoteBlock","generateNotes","batchAppendNotes","batchDeleteNotes","insertDividerAfter","deleteDivider"],setup(e,{emit:t}){const i=e,n=t,s=[{label:"1:1 (2步)",value:"1:1"},{label:"1:1:1 (3步)",value:"1:1:1"},{label:"1:2:1 (非等宽)",value:"1:2:1"},{label:"1:1:1:1 (4步)",value:"1:1:1:1"}],o=xe(()=>{const S=i.pageMask;return S==="clockwise"||S==="counter-clockwise"||S==="cw"||S==="ccw"}),a=xe(()=>o.value?"1:1:1:1":"1:1"),r=xe(()=>i.pageMaskRatio||a.value);function l(S){n("update:pageMask",S),(!i.pageMaskRatio||i.pageMaskRatio==="1:1")&&n("update:pageMaskRatio","1:1:1:1")}function c(S){n("update:pageMask",S),(!i.pageMaskRatio||i.pageMaskRatio==="1:1:1:1")&&n("update:pageMaskRatio","1:1")}const u=xe(()=>i.pageMask==="clockwise"||i.pageMask==="counter-clockwise"||i.pageMask==="cw"||i.pageMask==="ccw"?`时钟走时规则：
• 顺时针：左上 → 右上 → 右下 → 左下
• 逆时针：左上 → 左下 → 右下 → 右上
• 每次点击时针旋转 90° 并扇形扫开 1/4 象限，全部揭开后翻页`:`输入规则：
• 权重比例（项数决定步数）：如 1:1 (2步等分)、1:1:1 (3步等分)、1:2:1 (按权重累计分段)
• 绝对百分比：如 25:75:100 或 30:80 (指定每步展开的累计百分比)
• 每次点击或按空格/向右键展露下一段，全部揭开后翻页`),d=xe(()=>["two-cols","cols-header","two-cols-header","three-cols-header","image-left","image-right"].includes(i.pageLayout)),h=xe(()=>{var $,E;if(i.pageLayout==="two-cols-header"||i.pageLayout==="two-cols"||i.pageLayout==="image-left"||i.pageLayout==="image-right")return 2;if(i.pageLayout==="three-cols-header")return 3;const S=(i.pageLayoutRatio||"").trim();if(S.includes(":")){const C=S.split(":").filter(Boolean).length;if(C>=2&&C<=6)return C}const w=(i.detectedSbRatio||"").trim();if(w.includes(":")){const C=w.split(":").filter(Boolean).length;if(C>=2&&C<=6)return C}if(($=i.detectedSbInfo)!=null&&$.colCount&&i.detectedSbInfo.colCount>=2)return Math.min(i.detectedSbInfo.colCount,6);if((E=i.detectedSbInfo)!=null&&E.slots&&Array.isArray(i.detectedSbInfo.slots)){const C=i.detectedSbInfo.slots.length;if(C>=2&&C<=6)return C}return 2}),f=xe(()=>{const S=h.value;return S===3?[{label:"默认 1:1:1",value:""},{label:"1:2:1 (主中)",value:"1:2:1"},{label:"2:1:1 (主左)",value:"2:1:1"},{label:"1:1:2 (主右)",value:"1:1:2"},{label:"1:3:1",value:"1:3:1"}]:S===4?[{label:"默认 1:1:1:1",value:""},{label:"1:2:2:1",value:"1:2:2:1"},{label:"2:1:1:2",value:"2:1:1:2"}]:S===5?[{label:"默认 1:1:1:1:1",value:""}]:S===6?[{label:"默认 1:1:1:1:1:1",value:""}]:[{label:"默认 1:1",value:""},{label:"1:2",value:"1:2"},{label:"2:1",value:"2:1"},{label:"3:7",value:"3:7"},{label:"7:3",value:"7:3"},{label:"4:6",value:"4:6"},{label:"6:4",value:"6:4"}]}),v=xe(()=>i.pageLayoutRatio||"");function m(){const S=h.value||2,w=Array(S).fill("1").join(":");n("update:pageLayoutRatio",w),n("resetSuperblockRatio")}const b=xe(()=>{if(!i.pageNotes)return"";const S=i.pageNotes.replace(/[\r\n]+/g," ").trim();return S.length>50?S.slice(0,50)+"...":S}),y=[{label:"默认",value:""},{label:"暗黑 #1e1e24",value:"#1e1e24"},{label:"极夜 #0f172a",value:"#0f172a"},{label:"极简白 #ffffff",value:"#ffffff"}],x=[{label:"默认封面",value:"https://cover.sli.dev"},{label:"清空配图",value:""}];return(S,w)=>(X(),ee("div",rb,[p("div",ab,[p("span",null,"幻灯片页面设置"+Ce(e.pageIndex?` (第 ${e.pageIndex} 页)`:""),1)]),ae(Xv,{"model-value":e.pageLayout,onChange:w[0]||(w[0]=$=>S.$emit("update:pageLayout",$))},null,8,["model-value"]),!d.value&&e.pageLayout!=="clover"&&e.detectedSbRatio?(X(),ee("div",lb,[p("div",cb,[p("div",db,[ae(pe,{name:"sparkles"}),p("span",null,[w[33]||(w[33]=_t("检测到本页横向超级块列宽比例：",-1)),p("b",null,Ce(e.detectedSbRatio),1)])]),p("button",{class:"spm-btn-action b3-tooltips b3-tooltips__sw","aria-label":"一键应用超级块列宽并设为分栏",style:{padding:"2px 8px",height:"26px","font-size":"11px","flex-shrink":"0",background:"var(--b3-theme-primary)",color:"#fff",display:"inline-flex","align-items":"center",gap:"4px"},onClick:w[1]||(w[1]=$=>S.$emit("applySuperBlockLayout",e.detectedSbInfo||{recommendedLayout:"two-cols",ratio:e.detectedSbRatio}))},[ae(pe,{name:"columns"}),w[34]||(w[34]=p("span",null,"设为分栏",-1))])])])):Te("",!0),d.value?(X(),ee("div",ub,[p("div",fb,[p("div",pb,[p("div",hb,[ae(pe,{name:"ratio"}),w[35]||(w[35]=p("span",null,"分栏比例",-1))]),w[36]||(w[36]=p("span",{class:"spm-control-desc"},"设置各列横向空间占比，默认平均分配",-1))])]),p("div",mb,[(X(!0),ee(Xe,null,xt(f.value,$=>(X(),ee("button",{key:$.value,class:$e(["spm-chip",{active:v.value===$.value}]),onClick:E=>S.$emit("update:pageLayoutRatio",$.value)},Ce($.label),11,gb))),128))]),p("div",vb,[p("input",{value:e.pageLayoutRatio||"",class:"spm-input",style:{flex:"1","min-width":"0"},placeholder:"自定义比例（如 1:2 或 30:70，留空为默认）",onInput:w[2]||(w[2]=$=>S.$emit("update:pageLayoutRatio",$.target.value)),onChange:w[3]||(w[3]=$=>S.$emit("update:pageLayoutRatio",$.target.value))},null,40,bb),e.detectedSbRatio?(X(),ee("button",{key:0,class:"spm-icon-btn b3-tooltips b3-tooltips__sw","aria-label":`读取超级块列宽比例 (${e.detectedSbRatio}) 并应用`,style:{padding:"0 8px",height:"26px","font-size":"11px","white-space":"nowrap","flex-shrink":"0"},onClick:w[4]||(w[4]=$=>S.$emit("update:pageLayoutRatio",e.detectedSbRatio))},[ae(pe,{name:"sparkles"}),w[37]||(w[37]=p("span",null,"读取",-1))],8,yb)):(X(),ee("button",kb,[ae(pe,{name:"sparkles"}),w[38]||(w[38]=p("span",null,"读取",-1))])),p("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__sw","aria-label":"重置为等宽平均分布",style:{padding:"0 8px",height:"26px","font-size":"11px","white-space":"nowrap","flex-shrink":"0"},onClick:m},[ae(pe,{name:"reset"}),w[39]||(w[39]=p("span",null,"重置",-1))])]),e.detectedSbRatio?(X(),ee("div",wb,[ae(pe,{name:"ratio"}),w[40]||(w[40]=p("span",null,"检测到思源超级块宽度：",-1)),p("code",xb,Ce(e.detectedSbRatio),1)])):(X(),ee("div",Sb,[ae(pe,{name:"ratio"}),w[41]||(w[41]=p("span",null,"未检测到调宽超级块（默认各列平均分配）",-1))]))])):Te("",!0),ae(ic,{"model-value":e.pageTransition,onChange:w[5]||(w[5]=$=>S.$emit("update:pageTransition",$))},null,8,["model-value"]),p("div",Cb,[p("div",_b,[p("div",$b,[p("div",Ib,[ae(pe,{name:"sparkles"}),w[42]||(w[42]=p("span",null,"页面动态蒙版",-1))]),w[43]||(w[43]=p("span",{class:"spm-control-desc"},"随着点击操作分段展露正文内容",-1))])]),p("div",Mb,[p("button",{class:$e(["spm-segmented-item",{active:!e.pageMask}]),onClick:w[6]||(w[6]=$=>S.$emit("update:pageMask",""))}," 关闭 ",2),p("button",{class:$e(["spm-segmented-item",{active:e.pageMask==="down"}]),onClick:w[7]||(w[7]=$=>c("down"))}," 从上至下 ",2),p("button",{class:$e(["spm-segmented-item",{active:e.pageMask==="right"}]),onClick:w[8]||(w[8]=$=>c("right"))}," 从左至右 ",2),p("button",{class:$e(["spm-segmented-item",{active:e.pageMask==="clockwise"||e.pageMask==="cw"}]),onClick:w[9]||(w[9]=$=>l("clockwise"))}," 顺时针 ↻ ",2),p("button",{class:$e(["spm-segmented-item",{active:e.pageMask==="counter-clockwise"||e.pageMask==="ccw"}]),onClick:w[10]||(w[10]=$=>l("counter-clockwise"))}," 逆时针 ↺ ",2)]),e.pageMask?(X(),ee("div",Tb,[p("div",Eb,[w[45]||(w[45]=p("div",{style:{"font-size":"11px",opacity:"0.85","font-weight":"500"}},"展露比例 / 断点",-1)),p("span",{class:"b3-tooltips b3-tooltips__sw","aria-label":u.value,style:{cursor:"help",opacity:"0.75",display:"inline-flex","align-items":"center",gap:"3px","font-size":"11px"}},[ae(pe,{name:"help"}),w[44]||(w[44]=p("span",null,"输入规则",-1))],8,Ab)]),p("div",Bb,[(X(),ee(Xe,null,xt(s,$=>p("button",{key:$.value,class:$e(["spm-chip",{active:r.value===$.value}]),onClick:E=>S.$emit("update:pageMaskRatio",$.value)},Ce($.label),11,Db)),64))]),p("input",{value:r.value,class:"spm-input",style:{width:"100%"},placeholder:"自定义比例或断点（如 1:2:1 或 25:75:100）",onInput:w[11]||(w[11]=$=>S.$emit("update:pageMaskRatio",$.target.value)),onChange:w[12]||(w[12]=$=>S.$emit("update:pageMaskRatio",$.target.value))},null,40,Lb),p("div",Pb,Ce(e.pageMask==="clockwise"||e.pageMask==="counter-clockwise"||e.pageMask==="cw"||e.pageMask==="ccw"?"时钟走时蒙版：默认 4 步旋转展露（1:1:1:1，每步 25% 扇形面积）":"提示：支持权重比（如 1:2:1）或绝对断点（如 25:75:100），冒号项数决定点击步数"),1),p("div",Ob,[p("div",Rb,[w[46]||(w[46]=p("div",{style:{"font-size":"11px",opacity:"0.85","margin-bottom":"4px"}},"遮盖质感",-1)),p("div",Nb,[p("button",{class:$e(["spm-segmented-item",{active:!e.pageMaskStyle||e.pageMaskStyle==="solid"}]),onClick:w[13]||(w[13]=$=>S.$emit("update:pageMaskStyle","solid"))}," 背景同色 ",2),p("button",{class:$e(["spm-segmented-item",{active:e.pageMaskStyle==="blur"}]),onClick:w[14]||(w[14]=$=>S.$emit("update:pageMaskStyle","blur"))}," 磨砂毛玻璃 ",2)])]),p("div",zb,[w[47]||(w[47]=p("div",{style:{"font-size":"11px",opacity:"0.85","margin-bottom":"4px"}},"初始展露",-1)),p("div",Hb,[p("button",{class:$e(["spm-segmented-item",{active:!e.pageMaskInitial||e.pageMaskInitial==="hidden"}]),onClick:w[15]||(w[15]=$=>S.$emit("update:pageMaskInitial","hidden"))}," 完全遮盖 ",2),p("button",{class:$e(["spm-segmented-item",{active:e.pageMaskInitial==="revealed"}]),onClick:w[16]||(w[16]=$=>S.$emit("update:pageMaskInitial","revealed"))}," 首段可见 ",2)])])])])):Te("",!0)]),p("div",Fb,[p("div",jb,[p("div",Wb,[p("div",Ub,[ae(pe,{name:"ratio"}),w[48]||(w[48]=p("span",null,"页面间距",-1))]),w[49]||(w[49]=p("span",{class:"spm-control-desc"},"覆盖本页内边距与顶部标题间距",-1))])]),p("div",Vb,[p("button",{class:$e(["spm-segmented-item",{active:!e.pageSpacing||e.pageSpacing==="inherit"}]),onClick:w[17]||(w[17]=$=>S.$emit("update:pageSpacing","inherit"))}," 继承全局 ",2),p("button",{class:$e(["spm-segmented-item",{active:e.pageSpacing==="compact"}]),onClick:w[18]||(w[18]=$=>S.$emit("update:pageSpacing","compact"))}," 紧凑 ",2),p("button",{class:$e(["spm-segmented-item",{active:e.pageSpacing==="normal"}]),onClick:w[19]||(w[19]=$=>S.$emit("update:pageSpacing","normal"))}," 标准 ",2),p("button",{class:$e(["spm-segmented-item",{active:e.pageSpacing==="loose"}]),onClick:w[20]||(w[20]=$=>S.$emit("update:pageSpacing","loose"))}," 宽松 ",2)])]),p("div",Gb,[p("div",Kb,[p("div",qb,[p("div",Yb,[ae(pe,{name:"palette"}),w[50]||(w[50]=p("span",null,"页面背景",-1))]),w[51]||(w[51]=p("span",{class:"spm-control-desc"},"设置当前页特定底色或壁纸",-1))])]),p("div",Zb,[(X(),ee(Xe,null,xt(y,$=>p("button",{key:$.value,class:$e(["spm-chip",{active:e.pageBackground===$.value}]),onClick:E=>S.$emit("update:pageBackground",$.value)},Ce($.label),11,Jb)),64))]),p("input",{value:e.pageBackground,class:"spm-input",placeholder:"自定义颜色代码或资源路径",onInput:w[21]||(w[21]=$=>S.$emit("update:pageBackground",$.target.value)),onChange:w[22]||(w[22]=$=>S.$emit("update:pageBackground",$.target.value))},null,40,Xb)]),e.pageLayout==="image-right"||e.pageLayout==="image-left"||e.pageImage?(X(),ee("div",Qb,[p("div",e1,[p("div",t1,[p("div",i1,[ae(pe,{name:"image"}),w[52]||(w[52]=p("span",null,"页面图片",-1))]),w[53]||(w[53]=p("span",{class:"spm-control-desc"},"图文分栏或页面专属配图 URL / 资源路径",-1))])]),p("div",n1,[(X(),ee(Xe,null,xt(x,$=>p("button",{key:$.value,class:$e(["spm-chip",{active:e.pageImage===$.value}]),onClick:E=>S.$emit("update:pageImage",$.value)},Ce($.label),11,s1)),64))]),p("input",{value:e.pageImage,class:"spm-input",placeholder:"网络图片 URL (如 https://cover.sli.dev) 或 assets/...",onInput:w[23]||(w[23]=$=>S.$emit("update:pageImage",$.target.value)),onChange:w[24]||(w[24]=$=>S.$emit("update:pageImage",$.target.value))},null,40,o1)])):Te("",!0),p("div",r1,[p("div",a1,[p("div",l1,[p("div",c1,[ae(pe,{name:"presenter"}),w[54]||(w[54]=p("span",null,"演讲者提词",-1))]),w[55]||(w[55]=p("span",{class:"spm-control-desc"},"正文备注块驱动 · 仅演讲者视图可见",-1))]),me($t)("aiScript")?(X(),ee("button",{key:0,class:"spm-btn-text b3-tooltips b3-tooltips__sw","aria-label":"AI 自动生成本页讲稿提示块",onClick:w[25]||(w[25]=$=>S.$emit("generateNotes"))},[ae(pe,{name:"sparkles"}),w[56]||(w[56]=p("span",null,"AI 讲稿",-1))])):Te("",!0)]),e.pageNotes?(X(),ee("div",d1,[w[59]||(w[59]=p("div",{class:"spm-note-status-badge"},[p("span",{class:"spm-badge-dot"}),p("span",null,"已配置正文讲稿")],-1)),p("div",{class:"spm-note-preview-text",title:e.pageNotes},Ce(b.value),9,u1),p("div",f1,[p("button",{class:"spm-btn-action b3-tooltips b3-tooltips__se","aria-label":"在正文编辑区定位并高亮此讲稿备注块",onClick:w[26]||(w[26]=$=>S.$emit("locateNoteBlock"))},[ae(pe,{name:"search"}),w[57]||(w[57]=p("span",null,"定位讲稿块",-1))]),p("button",{class:"spm-btn-action b3-tooltips b3-tooltips__sw","aria-label":"在本页末尾追加新的讲稿提示块",onClick:w[27]||(w[27]=$=>S.$emit("addNoteBlock"))},[ae(pe,{name:"insert-below"}),w[58]||(w[58]=p("span",null,"追加讲稿块",-1))])])])):(X(),ee("div",p1,[w[61]||(w[61]=p("div",{class:"spm-note-empty-hint"},"本页暂无讲稿备注块",-1)),p("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s",style:{width:"100%","margin-top":"6px"},"aria-label":"在当前页末尾插入默认演讲备注提示块",onClick:w[28]||(w[28]=$=>S.$emit("addNoteBlock"))},[ae(pe,{name:"insert-below"}),w[60]||(w[60]=p("span",null,"添加讲稿备注块",-1))])])),p("div",h1,[p("div",m1,[p("button",{class:"spm-btn-action b3-tooltips b3-tooltips__se",disabled:e.isBatchProcessing,style:qt(e.isBatchProcessing?"opacity: 0.5; cursor: not-allowed;":""),"aria-label":"在所有尚未配置讲稿的页面末尾批量追加讲稿提示块",onClick:w[29]||(w[29]=$=>S.$emit("batchAppendNotes"))},[ae(pe,{name:"insert-below"}),w[62]||(w[62]=p("span",null,"全部追加",-1))],12,g1),p("button",{class:"spm-btn-action spm-btn-danger b3-tooltips b3-tooltips__sw",disabled:e.isBatchProcessing,style:qt(e.isBatchProcessing?"opacity: 0.5; cursor: not-allowed;":""),"aria-label":"批量物理删除正文中的全部讲稿备注块（涉及全部页）",onClick:w[30]||(w[30]=$=>S.$emit("batchDeleteNotes"))},[ae(pe,{name:"trash"}),w[63]||(w[63]=p("span",null,"全部删除",-1))],12,v1)])])]),p("div",b1,[w[66]||(w[66]=p("div",{class:"spm-control-header"},[p("div",{class:"spm-control-title-group"},[p("span",{class:"spm-control-title"},"分页快捷操作")])],-1)),p("div",y1,[p("button",{class:"spm-btn-action b3-tooltips b3-tooltips__se","aria-label":"在此分页符之后插入新的空白分页",onClick:w[31]||(w[31]=$=>S.$emit("insertDividerAfter"))},[ae(pe,{name:"insert-below"}),w[64]||(w[64]=p("span",null,"插入新页",-1))]),p("button",{class:"spm-btn-action spm-btn-danger b3-tooltips b3-tooltips__sw","aria-label":"彻底删除当前分页符（合并前后页面）",onClick:w[32]||(w[32]=$=>S.$emit("deleteDivider"))},[ae(pe,{name:"trash"}),w[65]||(w[65]=p("span",null,"删除此页",-1))])])])]))}}),w1=ei(k1,[["__scopeId","data-v-61712dad"]]),x1={class:"spm-section spm-section--block"},S1={key:0,class:"spm-card-control",style:{"border-left":"3px solid var(--b3-theme-primary)"}},C1={class:"spm-control-header"},_1={class:"spm-control-title-group"},$1={class:"spm-control-title"},I1={style:{background:"var(--b3-theme-surface)",border:"1px solid var(--b3-theme-surface-lighter)","border-radius":"6px",padding:"10px","margin-bottom":"8px"}},M1={style:{display:"flex","align-items":"center","justify-content":"space-between","margin-bottom":"4px"}},T1={style:{"font-size":"12px","font-weight":"500",display:"flex","align-items":"center",gap:"4px"}},E1={key:0},A1={key:1},B1={style:{background:"rgba(var(--b3-theme-primary-rgb, 59, 130, 246), 0.16)",color:"var(--b3-theme-primary)",border:"1px solid rgba(var(--b3-theme-primary-rgb, 59, 130, 246), 0.3)",padding:"2px 6px","border-radius":"4px","font-weight":"bold","font-size":"12px"}},D1={style:{"font-size":"11px",opacity:"0.75","line-height":"1.4"}},L1={class:"spm-action-grid"},P1={class:"spm-card-control"},O1={class:"spm-control-header"},R1={class:"spm-control-title-group"},N1={class:"spm-control-title"},z1=["aria-label"],H1=["checked"],F1={key:1,class:"spm-card-control"},j1={class:"spm-control-header"},W1={class:"spm-control-title-group"},U1={class:"spm-control-title"},V1={class:"spm-quick-chips"},G1={key:2,class:"spm-card-control"},K1={class:"spm-control-header"},q1={class:"spm-control-title-group"},Y1={class:"spm-control-title"},Z1={class:"spm-video-settings-grid",style:{display:"grid","grid-template-columns":"1fr 1fr",gap:"8px","margin-top":"8px"}},J1={class:"spm-toggle-item",style:{display:"flex","align-items":"center","justify-content":"space-between",padding:"4px 6px",background:"rgba(125,125,125,0.06)","border-radius":"4px"}},X1={style:{"font-size":"11px",display:"inline-flex","align-items":"center",gap:"4px"}},Q1=["aria-label"],ey=["checked"],ty={class:"spm-toggle-item",style:{display:"flex","align-items":"center","justify-content":"space-between",padding:"4px 6px",background:"rgba(125,125,125,0.06)","border-radius":"4px"}},iy={style:{"font-size":"11px",display:"inline-flex","align-items":"center",gap:"4px"}},ny=["aria-label"],sy=["checked"],oy={class:"spm-toggle-item",style:{display:"flex","align-items":"center","justify-content":"space-between",padding:"4px 6px",background:"rgba(125,125,125,0.06)","border-radius":"4px"}},ry={style:{"font-size":"11px",display:"inline-flex","align-items":"center",gap:"4px"}},ay=["aria-label"],ly=["checked"],cy={class:"spm-toggle-item",style:{display:"flex","align-items":"center","justify-content":"space-between",padding:"4px 6px",background:"rgba(125,125,125,0.06)","border-radius":"4px"}},dy={style:{"font-size":"11px",display:"inline-flex","align-items":"center",gap:"4px"}},uy=["aria-label"],fy=["checked"],py={class:"spm-card-control"},hy={class:"spm-control-header"},my={class:"spm-control-title-group"},gy={class:"spm-control-title"},vy=["aria-label"],by=["checked"],yy={key:0,class:"spm-quick-chips"},ky=["onClick"],wy={key:1,class:"spm-inherit-tip",style:{"margin-top":"6px",padding:"4px 8px",background:"rgba(var(--b3-theme-primary-rgb, 59, 130, 246), 0.08)","border-radius":"4px","font-size":"11px",opacity:"0.85",display:"flex","align-items":"center",gap:"4px"}},xy={class:"spm-card-control"},Sy={class:"spm-control-header"},Cy={class:"spm-control-title-group"},_y={class:"spm-control-title"},$y=["aria-label"],Iy=["checked"],My={key:0,class:"spm-quick-chips"},Ty=["onClick"],Ey={key:1,class:"spm-motion-details",style:{display:"flex","flex-direction":"column",gap:"4px","margin-top":"4px"}},Ay={style:{display:"flex",gap:"8px","justify-content":"space-between","font-size":"11px",opacity:"0.8"}},By={style:{display:"flex",gap:"6px"}},Dy=["value"],Ly=["value"],Py={key:3,class:"spm-card-control"},Oy={class:"spm-control-header"},Ry={class:"spm-control-title-group"},Ny={class:"spm-control-title"},zy={class:"spm-control-desc"},Hy={class:"spm-segmented-group"},Fy=["onClick"],jy={key:4,class:"spm-card-control"},Wy={class:"spm-control-header"},Uy={class:"spm-control-title-group"},Vy={class:"spm-control-title"},Gy={class:"spm-quick-chips"},Ky=["onClick"],qy=["value"],Yy={key:5,class:"spm-card-control"},Zy={class:"spm-control-header"},Jy={class:"spm-control-title-group"},Xy={class:"spm-control-title"},Qy={class:"spm-quick-chips"},e0=["onClick"],t0=["value"],i0={class:"spm-card-control"},n0={class:"spm-action-grid"},s0=["aria-label"],o0=At({__name:"BlockInspectorSection",props:{elemClick:{},elemMotion:{},elemSlot:{},elemShikiLines:{},elemMaxHeight:{},isCodeBlock:{type:Boolean},isImage:{type:Boolean},isVideo:{type:Boolean},videoAutoplay:{type:Boolean},videoLoop:{type:Boolean},videoMuted:{type:Boolean},videoControls:{type:Boolean},hasBlockAttrs:{type:Boolean},isNote:{type:Boolean},imageRole:{},currentSlideLayout:{},isSuperBlock:{type:Boolean},parentElemClick:{},parentContainerSlot:{},parentContainerId:{},detectedSbInfo:{}},emits:["toggleNote","toggleElemClick","update:elemClick","update:elemMotion","update:elemSlot","update:elemShikiLines","update:elemMaxHeight","applySuperBlockLayout","applySuperBlockRatio","insertDividerBefore","insertDividerAfter","setTwoColsContrast","clearBlockAttrs","update:imageRole","toggleVideoAutoplay","toggleVideoLoop","toggleVideoMuted","toggleVideoControls"],setup(e,{emit:t}){const i=e,n=xe(()=>{const E=i.currentSlideLayout||"";return["col-1","col-2","col-3","col-4","col-5","col-6"].includes(i.elemSlot)?"cols-header":E}),s=xe(()=>{const E=n.value;return["two-cols","cols-header","two-cols-header","three-cols-header"].includes(E)}),o=xe(()=>{var C,L,z,H;if((C=i.detectedSbInfo)!=null&&C.colCount&&i.detectedSbInfo.colCount>=2)return Math.min(i.detectedSbInfo.colCount,6);const E=(L=i.elemSlot)==null?void 0:L.match(/^col-(\d+)$/);if(E){const q=parseInt(E[1],10);if(q>=2&&q<=6)return Math.max(q,3)}if(i.currentSlideLayout==="three-cols-header")return 3;if(i.currentSlideLayout==="two-cols-header"||i.currentSlideLayout==="two-cols")return 2;if((H=(z=i.detectedSbInfo)==null?void 0:z.ratio)!=null&&H.includes(":")){const q=i.detectedSbInfo.ratio.split(":").filter(Boolean);if(q.length>=2)return Math.min(q.length,6)}return 3}),a=xe(()=>{const E=n.value;return E==="cols-header"?"多栏插槽归属":E==="three-cols-header"?"三栏插槽归属":E==="two-cols-header"?"带表头双栏插槽":"多栏插槽归属"}),r=xe(()=>{const E=n.value;return E==="cols-header"?`在 cols-header 表头多栏（${o.value} 栏）中的内容块位置`:E==="three-cols-header"?"在 three-cols-header 版式中的内容块位置":E==="two-cols-header"?"在 two-cols-header 版式中的内容块位置":E==="two-cols"?"在 two-cols 双栏版式中的归属":"在当前分栏版式中的内容块位置"}),l=xe(()=>{const E=n.value;if(E==="two-cols")return[{value:"",label:"默认 (左)"},{value:"right",label:"右栏"}];if(E==="two-cols-header")return[{value:"",label:"默认"},{value:"header",label:"表头"},{value:"left",label:"左栏"},{value:"right",label:"右栏"}];if(E==="three-cols-header")return[{value:"",label:"默认"},{value:"header",label:"表头"},{value:"col-1",label:"第 1 栏"},{value:"col-2",label:"第 2 栏"},{value:"col-3",label:"第 3 栏"}];const C=o.value,L=[{value:"",label:"默认"},{value:"header",label:"表头"}];for(let z=1;z<=C;z++)L.push({value:`col-${z}`,label:`第 ${z} 栏`});return L});function c(E){const C=i.elemSlot||"";return E?C===E||E==="col-1"&&C==="left"||E==="col-2"&&C==="center"||E==="col-3"&&C==="right"&&o.value===3||E==="col-2"&&C==="right"&&o.value===2||E==="left"&&C==="col-1"||E==="right"&&(C==="col-2"||C==="col-3"):!C||C==="default"}const u=t,d=[{label:"上浮",value:"slide-up"},{label:"淡入",value:"fade-in"},{label:"下沉",value:"slide-down"},{label:"左滑",value:"slide-left"},{label:"右滑",value:"slide-right"},{label:"缩放",value:"zoom-in"},{label:"弹性",value:"bounce"}],h=xe(()=>{if(!i.elemMotion||i.elemMotion.trim()===""||i.elemMotion.trim()==="none")return null;try{const E=JSON.parse(i.elemMotion);if(typeof E=="object"&&E!==null)return{preset:E.preset||E.type||"slide-up",duration:typeof E.duration=="number"?E.duration:0,delay:typeof E.delay=="number"?E.delay:0}}catch{}return{preset:i.elemMotion.trim(),duration:0,delay:0}}),f=xe(()=>!!h.value),v=xe(()=>{var E;return((E=h.value)==null?void 0:E.preset)||"slide-up"}),m=xe(()=>{var E;return((E=h.value)==null?void 0:E.duration)||0}),b=xe(()=>{var E;return((E=h.value)==null?void 0:E.delay)||0});function y(){f.value?u("update:elemMotion",""):u("update:elemMotion","slide-up")}function x(E){$(E,m.value,b.value)}function S(E){$(v.value,E,b.value)}function w(E){$(v.value,m.value,E)}function $(E,C,L){if(!E||E==="none"){u("update:elemMotion","");return}if(!C&&!L){u("update:elemMotion",E);return}const z={preset:E};C>0&&(z.duration=C),L>0&&(z.delay=L),u("update:elemMotion",JSON.stringify(z))}return(E,C)=>{var L,z,H,q,_,N;return X(),ee("div",x1,[C[62]||(C[62]=p("div",{class:"spm-section-header"},[p("span",null,"元素动效与排版")],-1)),e.isSuperBlock||(L=e.detectedSbInfo)!=null&&L.hasSuperBlock?(X(),ee("div",S1,[p("div",C1,[p("div",_1,[p("div",$1,[ae(pe,{name:"ratio"}),C[24]||(C[24]=p("span",null,"超级块列宽与布局",-1))]),C[25]||(C[25]=p("span",{class:"spm-control-desc"},"读取思源超级块列宽并一键同步到幻灯片分栏",-1))])]),p("div",I1,[p("div",M1,[p("div",T1,[ae(pe,{name:"ratio"}),(z=e.detectedSbInfo)!=null&&z.isCustomWidth?(X(),ee("span",E1,"已识别自定义列宽比例")):(X(),ee("span",A1,"识别到 "+Ce(((H=e.detectedSbInfo)==null?void 0:H.colCount)||2)+" 列超级块分栏",1))]),p("code",B1,Ce(((q=e.detectedSbInfo)==null?void 0:q.ratio)||"1:1"),1)]),p("div",D1,Ce((_=e.detectedSbInfo)!=null&&_.isCustomWidth?"检测到已调节子块宽度，可一键应用为当前页分栏比例。":"当前超级块子列为思源默认均宽，可在思源中拖动调节或直接应用。"),1)]),p("div",L1,[p("button",{class:"spm-btn-action b3-tooltips b3-tooltips__se","aria-label":"一键将当前页版式切换为对应双栏/三栏，并写入此列宽比例",style:{background:"rgba(var(--b3-theme-primary-rgb, 59, 130, 246), 0.16)",color:"var(--b3-theme-primary)","font-weight":"500",border:"1px solid rgba(var(--b3-theme-primary-rgb, 59, 130, 246), 0.3)"},onClick:C[0]||(C[0]=k=>E.$emit("applySuperBlockLayout",e.detectedSbInfo))},[ae(pe,{name:"sparkles"}),C[26]||(C[26]=p("span",null,"应用版式与比例",-1))]),p("button",{class:"spm-btn-action b3-tooltips b3-tooltips__sw","aria-label":"仅将提取的比值写入当前页的分栏比例属性",onClick:C[1]||(C[1]=k=>{var U;return E.$emit("applySuperBlockRatio",((U=e.detectedSbInfo)==null?void 0:U.ratio)||"1:1")})},[ae(pe,{name:"check"}),p("span",null,"应用比例 ("+Ce(((N=e.detectedSbInfo)==null?void 0:N.ratio)||"1:1")+")",1)])])])):Te("",!0),p("div",P1,[p("div",O1,[p("div",R1,[p("div",N1,[ae(pe,{name:"presenter"}),C[27]||(C[27]=p("span",null,"设为讲稿备注",-1))]),C[28]||(C[28]=p("span",{class:"spm-control-desc"},"作为当前页演讲提词，不在幻灯片中渲染",-1))]),p("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":e.isNote?"取消讲稿备注":"设为讲稿备注"},[p("input",{type:"checkbox",checked:!!e.isNote,onChange:C[2]||(C[2]=k=>E.$emit("toggleNote"))},null,40,H1),C[29]||(C[29]=p("span",{class:"spm-switch-slider"},null,-1))],8,z1)])]),e.isImage||e.imageRole?(X(),ee("div",F1,[p("div",j1,[p("div",W1,[p("div",U1,[ae(pe,{name:"image"}),C[30]||(C[30]=p("span",null,"图片角色与分栏",-1))]),C[31]||(C[31]=p("span",{class:"spm-control-desc"},"设为幻灯片背景图或图文分栏配图",-1))])]),p("div",V1,[p("button",{class:$e(["spm-chip",{active:!e.imageRole}]),onClick:C[3]||(C[3]=k=>E.$emit("update:imageRole",""))}," 普通内容 ",2),p("button",{class:$e(["spm-chip",{active:e.imageRole==="background"}]),onClick:C[4]||(C[4]=k=>E.$emit("update:imageRole","background"))},[ae(pe,{name:"image"}),C[32]||(C[32]=p("span",null,"背景图",-1))],2),p("button",{class:$e(["spm-chip",{active:e.imageRole==="image-left"}]),onClick:C[5]||(C[5]=k=>E.$emit("update:imageRole","image-left"))},[ae(pe,{name:"image-left"}),C[33]||(C[33]=p("span",null,"图左",-1))],2),p("button",{class:$e(["spm-chip",{active:e.imageRole==="image-right"}]),onClick:C[6]||(C[6]=k=>E.$emit("update:imageRole","image-right"))},[ae(pe,{name:"image-right"}),C[34]||(C[34]=p("span",null,"图右",-1))],2)])])):Te("",!0),e.isVideo?(X(),ee("div",G1,[p("div",K1,[p("div",q1,[p("div",Y1,[ae(pe,{name:"video"}),C[35]||(C[35]=p("span",null,"视频播放设置",-1))]),C[36]||(C[36]=p("span",{class:"spm-control-desc"},"配置播放器控制条、自动播放与循环",-1))])]),p("div",Z1,[p("div",J1,[p("span",X1,[ae(pe,{name:"sliders"}),C[37]||(C[37]=_t(" 控制条",-1))]),p("label",{class:"spm-switch b3-tooltips b3-tooltips__se","aria-label":e.videoControls?"关闭控制条":"开启控制条"},[p("input",{type:"checkbox",checked:!!e.videoControls,onChange:C[7]||(C[7]=k=>E.$emit("toggleVideoControls"))},null,40,ey),C[38]||(C[38]=p("span",{class:"spm-switch-slider"},null,-1))],8,Q1)]),p("div",ty,[p("span",iy,[ae(pe,{name:"video"}),C[39]||(C[39]=_t(" 自动播放",-1))]),p("label",{class:"spm-switch b3-tooltips b3-tooltips__sw","aria-label":e.videoAutoplay?"关闭自动播放":"开启自动播放"},[p("input",{type:"checkbox",checked:!!e.videoAutoplay,onChange:C[8]||(C[8]=k=>E.$emit("toggleVideoAutoplay"))},null,40,sy),C[40]||(C[40]=p("span",{class:"spm-switch-slider"},null,-1))],8,ny)]),p("div",oy,[p("span",ry,[ae(pe,{name:"repeat"}),C[41]||(C[41]=_t(" 循环播放",-1))]),p("label",{class:"spm-switch b3-tooltips b3-tooltips__se","aria-label":e.videoLoop?"关闭循环播放":"开启循环播放"},[p("input",{type:"checkbox",checked:!!e.videoLoop,onChange:C[9]||(C[9]=k=>E.$emit("toggleVideoLoop"))},null,40,ly),C[42]||(C[42]=p("span",{class:"spm-switch-slider"},null,-1))],8,ay)]),p("div",cy,[p("span",dy,[ae(pe,{name:"volume-x"}),C[43]||(C[43]=_t(" 静音播放",-1))]),p("label",{class:"spm-switch b3-tooltips b3-tooltips__sw","aria-label":e.videoMuted?"关闭静音":"开启静音"},[p("input",{type:"checkbox",checked:!!e.videoMuted,onChange:C[10]||(C[10]=k=>E.$emit("toggleVideoMuted"))},null,40,fy),C[44]||(C[44]=p("span",{class:"spm-switch-slider"},null,-1))],8,uy)])])])):Te("",!0),p("div",py,[p("div",hy,[p("div",my,[p("div",gy,[ae(pe,{name:"step"}),C[45]||(C[45]=p("span",null,"逐步呈现",-1))]),C[46]||(C[46]=p("span",{class:"spm-control-desc"},"放映时按步长逐个呈现",-1))]),p("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":e.elemClick?"关闭逐步呈现":"开启逐步呈现 (+1)"},[p("input",{type:"checkbox",checked:!!e.elemClick,onChange:C[11]||(C[11]=k=>E.$emit("toggleElemClick"))},null,40,by),C[47]||(C[47]=p("span",{class:"spm-switch-slider"},null,-1))],8,vy)]),e.elemClick?(X(),ee("div",yy,[(X(),ee(Xe,null,xt(["+1","1","2","hide"],k=>p("button",{key:k,class:$e(["spm-chip",{active:e.elemClick===k}]),onClick:U=>E.$emit("update:elemClick",k)},Ce(k==="+1"?"顺延 (+1)":k==="hide"?"隐藏":"第 "+k+" 步"),11,ky)),64))])):e.parentElemClick?(X(),ee("div",wy,[ae(pe,{name:"check"}),C[48]||(C[48]=p("span",null,"未单独开启逐步呈现：当前跟随整栏同时出现",-1))])):Te("",!0)]),p("div",xy,[p("div",Sy,[p("div",Cy,[p("div",_y,[ae(pe,{name:"motion"}),C[49]||(C[49]=p("span",null,"入场微动效",-1))]),C[50]||(C[50]=p("span",{class:"spm-control-desc"},"为当前块添加平滑位移与渐入动画",-1))]),p("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":f.value?"关闭微动效":"开启微动效"},[p("input",{type:"checkbox",checked:f.value,onChange:y},null,40,Iy),C[51]||(C[51]=p("span",{class:"spm-switch-slider"},null,-1))],8,$y)]),f.value?(X(),ee("div",My,[(X(),ee(Xe,null,xt(d,k=>p("button",{key:k.value,class:$e(["spm-chip",{active:v.value===k.value}]),onClick:U=>x(k.value)},Ce(k.label),11,Ty)),64))])):Te("",!0),f.value?(X(),ee("div",Ey,[p("div",Ay,[p("span",null,"时长: "+Ce(m.value?m.value+"ms":"默认 (450ms)"),1),p("span",null,"延迟: "+Ce(b.value?b.value+"ms":"0ms"),1)]),p("div",By,[p("select",{class:"spm-select",style:{flex:"1"},value:m.value,onChange:C[12]||(C[12]=k=>S(Number(k.target.value)))},[...C[52]||(C[52]=[p("option",{value:0},"默认耗时",-1),p("option",{value:200},"极速 (200ms)",-1),p("option",{value:350},"较快 (350ms)",-1),p("option",{value:500},"平滑 (500ms)",-1),p("option",{value:800},"缓慢 (800ms)",-1)])],40,Dy),p("select",{class:"spm-select",style:{flex:"1"},value:b.value,onChange:C[13]||(C[13]=k=>w(Number(k.target.value)))},[...C[53]||(C[53]=[p("option",{value:0},"无延迟",-1),p("option",{value:150},"延迟 150ms",-1),p("option",{value:300},"延迟 300ms",-1),p("option",{value:500},"延迟 500ms",-1)])],40,Ly)])])):Te("",!0)]),s.value||e.elemSlot?(X(),ee("div",Py,[p("div",Oy,[p("div",Ry,[p("div",Ny,[ae(pe,{name:"columns"}),p("span",null,Ce(a.value),1)]),p("span",zy,Ce(r.value),1)])]),p("div",Hy,[(X(!0),ee(Xe,null,xt(l.value,k=>(X(),ee("button",{key:k.value,class:$e(["spm-segmented-item",{active:c(k.value)}]),onClick:U=>E.$emit("update:elemSlot",k.value)},Ce(k.label),11,Fy))),128))])])):Te("",!0),e.isCodeBlock?(X(),ee("div",jy,[p("div",Wy,[p("div",Uy,[p("div",Vy,[ae(pe,{name:"code"}),C[54]||(C[54]=p("span",null,"代码逐行聚光",-1))]),C[55]||(C[55]=p("span",{class:"spm-control-desc"},"翻页时动态聚光高亮特定行",-1))])]),p("div",Gy,[(X(),ee(Xe,null,xt(["1-3","all","1|2|3","2-5"],k=>p("button",{key:k,class:$e(["spm-chip",{active:e.elemShikiLines===k}]),onClick:U=>E.$emit("update:elemShikiLines",k)},Ce(k),11,Ky)),64)),e.elemShikiLines?(X(),ee("button",{key:0,class:"spm-chip spm-chip-clear",onClick:C[14]||(C[14]=k=>E.$emit("update:elemShikiLines",""))}," 清空 ")):Te("",!0)]),p("input",{value:e.elemShikiLines,class:"spm-input",placeholder:"自定义高亮区间，如 1-3|5|all",onInput:C[15]||(C[15]=k=>E.$emit("update:elemShikiLines",k.target.value)),onChange:C[16]||(C[16]=k=>E.$emit("update:elemShikiLines",k.target.value))},null,40,qy)])):Te("",!0),e.isCodeBlock?(X(),ee("div",Yy,[p("div",Zy,[p("div",Jy,[p("div",Xy,[ae(pe,{name:"code"}),C[56]||(C[56]=p("span",null,"代码块限高",-1))]),C[57]||(C[57]=p("span",{class:"spm-control-desc"},"超出限高自动竖向滚动，弱提示滚动条",-1))])]),p("div",Qy,[(X(),ee(Xe,null,xt(["240px","320px","400px","50vh"],k=>p("button",{key:k,class:$e(["spm-chip",{active:e.elemMaxHeight===k}]),onClick:U=>E.$emit("update:elemMaxHeight",k)},Ce(k),11,e0)),64)),e.elemMaxHeight?(X(),ee("button",{key:0,class:"spm-chip spm-chip-clear",onClick:C[17]||(C[17]=k=>E.$emit("update:elemMaxHeight",""))}," 自适应 ")):Te("",!0)]),p("input",{value:e.elemMaxHeight,class:"spm-input",placeholder:"自适应高度，或输入 350px、50vh",onInput:C[18]||(C[18]=k=>E.$emit("update:elemMaxHeight",k.target.value)),onChange:C[19]||(C[19]=k=>E.$emit("update:elemMaxHeight",k.target.value))},null,40,t0)])):Te("",!0),p("div",i0,[C[61]||(C[61]=p("div",{class:"spm-control-header"},[p("div",{class:"spm-control-title-group"},[p("span",{class:"spm-control-title"},"快捷操作")])],-1)),p("div",n0,[p("button",{class:"spm-btn-action b3-tooltips b3-tooltips__se","aria-label":"在当前块上方插入幻灯片分页线 (---)",onClick:C[20]||(C[20]=k=>E.$emit("insertDividerBefore"))},[ae(pe,{name:"insert-above"}),C[58]||(C[58]=p("span",null,"上方分页",-1))]),p("button",{class:"spm-btn-action b3-tooltips b3-tooltips__sw","aria-label":"在当前块下方插入幻灯片分页线 (---)",onClick:C[21]||(C[21]=k=>E.$emit("insertDividerAfter"))},[ae(pe,{name:"insert-below"}),C[59]||(C[59]=p("span",null,"下方分页",-1))]),p("button",{class:"spm-btn-action b3-tooltips b3-tooltips__se","aria-label":n.value==="three-cols-header"?"将当前块属性设为三栏第1栏归属":"将当前块属性设为双栏左侧归属",onClick:C[22]||(C[22]=k=>E.$emit("setTwoColsContrast"))},[ae(pe,{name:"columns"}),p("span",null,Ce(n.value==="three-cols-header"?"设为第1栏":"设为双栏"),1)],8,s0),e.hasBlockAttrs?(X(),ee("button",{key:0,class:"spm-btn-action spm-btn-danger b3-tooltips b3-tooltips__sw","aria-label":"一键移除本块所有 custom-slides 属性",onClick:C[23]||(C[23]=k=>E.$emit("clearBlockAttrs"))},[ae(pe,{name:"broom"}),C[60]||(C[60]=p("span",null,"清除属性",-1))])):Te("",!0)])])])}}}),r0={class:"spm-section spm-section--doc"},a0={class:"spm-card-control"},l0={class:"spm-control-header"},c0={class:"spm-control-title-group"},d0={class:"spm-control-title"},u0={class:"spm-segmented-group"},f0=["aria-label","onClick"],p0={class:"spm-card-control"},h0={class:"spm-control-header"},m0={class:"spm-control-title-group"},g0={class:"spm-control-title"},v0={class:"spm-segmented-group"},b0={class:"spm-card-control"},y0={class:"spm-control-header"},k0={class:"spm-control-title-group"},w0={class:"spm-control-title"},x0={class:"spm-segmented-group"},S0={class:"spm-card-control"},C0={class:"spm-control-header"},_0={class:"spm-control-title-group"},$0={class:"spm-control-title"},I0={class:"spm-card-control"},M0={class:"spm-control-header"},T0={class:"spm-control-title-group"},E0={class:"spm-control-title"},A0=["aria-label"],B0=["checked"],D0={key:0,class:"spm-control-body",style:{"margin-top":"8px"}},L0=["value"],P0={class:"spm-card-control"},O0={class:"spm-control-header"},R0={class:"spm-control-title-group"},N0={class:"spm-control-title"},z0=["aria-label"],H0=["checked"],F0={class:"spm-card-control"},j0={class:"spm-control-header"},W0={class:"spm-control-title-group"},U0={class:"spm-control-title"},V0={class:"spm-list-markers-toggles",style:{display:"flex",gap:"8px","margin-top":"8px"}},G0={class:"spm-marker-toggle-item",style:{flex:"1",display:"flex","align-items":"center","justify-content":"space-between",padding:"6px 10px",background:"var(--b3-theme-surface)",border:"1px solid var(--b3-border-color)","border-radius":"4px"}},K0=["aria-label"],q0=["checked"],Y0={class:"spm-marker-toggle-item",style:{flex:"1",display:"flex","align-items":"center","justify-content":"space-between",padding:"6px 10px",background:"var(--b3-theme-surface)",border:"1px solid var(--b3-border-color)","border-radius":"4px"}},Z0=["aria-label"],J0=["checked"],X0={class:"spm-card-control"},Q0={class:"spm-action-grid"},ek=["disabled"],tk=["disabled"],ik=["disabled","aria-label"],nk=At({__name:"DocInspectorSection",props:{docTheme:{},docAspectRatio:{},docDefaultTransition:{},docSpacing:{},isExportingImages:{type:Boolean},isBatchProcessing:{type:Boolean}},emits:["update:docTheme","update:docAspectRatio","update:docDefaultTransition","update:docSpacing","openBottomPreview","openPresenter","identifyNotes","autoAnimate","aiAutoSplit","exportHtml","exportPdf","exportImages"],setup(e){const t=Nt("plugin"),i=Ut,n=[{value:"default",label:"默认 default",desc:"官方默认科技风：现代无衬线排版与清新代码语法高亮，通用汇报与技术分享首选"},{value:"seriph",label:"优雅 seriph",desc:"典雅学术衬线风：书卷学术质感、衬线字体典雅庄重，适合学术论文、人文讲座与深度阅读"},{value:"apple-basic",label:"极简 apple",desc:"苹果发布会极简风：大字号、高对比度与极致留白，适合产品发布、方案演讲与纯粹视觉呈现"}];function s(u){oi({enableWebServeJump:u}),t&&typeof t.saveGlobalSettings=="function"&&t.saveGlobalSettings({enableWebServeJump:u})}async function o(u){var d;oi({normalizeHeadingSizes:u}),t&&typeof t.saveGlobalSettings=="function"&&await t.saveGlobalSettings({normalizeHeadingSizes:u}),t&&typeof t.compileCurrentDocument=="function"&&t.compileCurrentDocument(t.currentDocId||((d=t.getActiveDocumentId)==null?void 0:d.call(t)))}async function a(u){var d;oi({showUnorderedListMarkers:u}),t&&typeof t.saveGlobalSettings=="function"&&await t.saveGlobalSettings({showUnorderedListMarkers:u}),t&&typeof t.compileCurrentDocument=="function"&&t.compileCurrentDocument(t.currentDocId||((d=t.getActiveDocumentId)==null?void 0:d.call(t)))}async function r(u){var d;oi({showOrderedListMarkers:u}),t&&typeof t.saveGlobalSettings=="function"&&await t.saveGlobalSettings({showOrderedListMarkers:u}),t&&typeof t.compileCurrentDocument=="function"&&t.compileCurrentDocument(t.currentDocId||((d=t.getActiveDocumentId)==null?void 0:d.call(t)))}function l(u){oi({webServeUrl:u})}function c(u){oi({webServeUrl:u}),t&&typeof t.saveGlobalSettings=="function"&&t.saveGlobalSettings({webServeUrl:u})}return(u,d)=>(X(),ee("div",r0,[d[52]||(d[52]=p("div",{class:"spm-section-header"},[p("span",null,"全局演示配置")],-1)),p("div",a0,[p("div",l0,[p("div",c0,[p("div",d0,[ae(pe,{name:"palette"}),d[23]||(d[23]=p("span",null,"幻灯片主题",-1))]),d[24]||(d[24]=p("span",{class:"spm-control-desc"},"全局幻灯片视觉设计范式",-1))])]),p("div",u0,[(X(),ee(Xe,null,xt(n,h=>p("button",{key:h.value,class:$e(["spm-segmented-item b3-tooltips b3-tooltips__s",{active:e.docTheme===h.value}]),"aria-label":h.desc,onClick:f=>u.$emit("update:docTheme",h.value)},Ce(h.label),11,f0)),64))])]),p("div",p0,[p("div",h0,[p("div",m0,[p("div",g0,[ae(pe,{name:"ratio"}),d[25]||(d[25]=p("span",null,"画幅比例",-1))]),d[26]||(d[26]=p("span",{class:"spm-control-desc"},"演讲屏幕投影宽高比",-1))])]),p("div",v0,[p("button",{class:$e(["spm-segmented-item",{active:e.docAspectRatio==="16/9"}]),onClick:d[0]||(d[0]=h=>u.$emit("update:docAspectRatio","16/9"))}," 16 : 9 (宽屏) ",2),p("button",{class:$e(["spm-segmented-item",{active:e.docAspectRatio==="4/3"}]),onClick:d[1]||(d[1]=h=>u.$emit("update:docAspectRatio","4/3"))}," 4 : 3 (标屏) ",2),p("button",{class:$e(["spm-segmented-item",{active:e.docAspectRatio==="16/10"}]),onClick:d[2]||(d[2]=h=>u.$emit("update:docAspectRatio","16/10"))}," 16 : 10 ",2)])]),p("div",b0,[p("div",y0,[p("div",k0,[p("div",w0,[ae(pe,{name:"ratio"}),d[27]||(d[27]=p("span",null,"间距风格",-1))]),d[28]||(d[28]=p("span",{class:"spm-control-desc"},"内边距与顶部标题下边距预设",-1))])]),p("div",x0,[p("button",{class:$e(["spm-segmented-item b3-tooltips b3-tooltips__se",{active:(e.docSpacing||"normal")==="compact"}]),"aria-label":"紧凑排版：上下 20px / 左右 36px",onClick:d[3]||(d[3]=h=>u.$emit("update:docSpacing","compact"))}," 紧凑 ",2),p("button",{class:$e(["spm-segmented-item b3-tooltips b3-tooltips__s",{active:(e.docSpacing||"normal")==="normal"}]),"aria-label":"标准排版：上下 32px / 左右 48px（推荐默认）",onClick:d[4]||(d[4]=h=>u.$emit("update:docSpacing","normal"))}," 标准 ",2),p("button",{class:$e(["spm-segmented-item b3-tooltips b3-tooltips__sw",{active:(e.docSpacing||"normal")==="loose"}]),"aria-label":"宽松排版：上下 48px / 左右 56px",onClick:d[5]||(d[5]=h=>u.$emit("update:docSpacing","loose"))}," 宽松 ",2)])]),p("div",S0,[p("div",C0,[p("div",_0,[p("div",$0,[ae(pe,{name:"transition"}),d[29]||(d[29]=p("span",null,"全局默认转场",-1))]),d[30]||(d[30]=p("span",{class:"spm-control-desc"},"页面切换过渡动效（未单设转场的页面将继承此动效）",-1))])]),ae(ic,{"model-value":e.docDefaultTransition,"hide-header":!0,onChange:d[6]||(d[6]=h=>u.$emit("update:docDefaultTransition",h))},null,8,["model-value"])]),p("div",I0,[p("div",M0,[p("div",T0,[p("div",E0,[ae(pe,{name:"external-link"}),d[31]||(d[31]=p("span",null,"本地网络伺服预览",-1))]),d[32]||(d[32]=p("span",{class:"spm-control-desc"},"点击文档/块链接以 Webview 抽屉呈现，支持外跳",-1))]),p("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":me(i).enableWebServeJump?"关闭本地网络伺服预览":"开启本地网络伺服预览"},[p("input",{type:"checkbox",checked:me(i).enableWebServeJump,onChange:d[7]||(d[7]=h=>s(h.target.checked))},null,40,B0),d[33]||(d[33]=p("span",{class:"spm-switch-slider"},null,-1))],8,A0)]),me(i).enableWebServeJump?(X(),ee("div",D0,[p("input",{value:me(i).webServeUrl,class:"spm-input",placeholder:"http://127.0.0.1:6806",spellcheck:"false",onKeydown:d[8]||(d[8]=Yt(()=>{},["stop"])),onKeyup:d[9]||(d[9]=Yt(()=>{},["stop"])),onInput:d[10]||(d[10]=h=>l(h.target.value)),onChange:d[11]||(d[11]=h=>c(h.target.value))},null,40,L0),d[34]||(d[34]=p("span",{class:"spm-control-desc",style:{display:"block","margin-top":"4px","font-size":"11px",opacity:"0.8"}}," 默认伺服地址为 http://127.0.0.1:6806。开启后点击块链接将在 Webview 抽屉中打开，点击抽屉顶部『外跳』可在外部浏览器打开 ",-1))])):Te("",!0)]),p("div",P0,[p("div",O0,[p("div",R0,[p("div",N0,[ae(pe,{name:"type"}),d[35]||(d[35]=p("span",null,"固定特定标题大小",-1))]),d[36]||(d[36]=p("span",{class:"spm-control-desc"},"除封面外页首标题按 H2、多栏内首标题按 H3 大小展示",-1))]),p("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":me(i).normalizeHeadingSizes?"关闭固定特定标题大小":"开启固定特定标题大小"},[p("input",{type:"checkbox",checked:me(i).normalizeHeadingSizes,onChange:d[12]||(d[12]=h=>o(h.target.checked))},null,40,H0),d[37]||(d[37]=p("span",{class:"spm-switch-slider"},null,-1))],8,z0)])]),p("div",F0,[p("div",j0,[p("div",W0,[p("div",U0,[ae(pe,{name:"list"}),d[38]||(d[38]=p("span",null,"列表前缀标记",-1))]),d[39]||(d[39]=p("span",{class:"spm-control-desc"},"分别控制正文中无序列表圆点与有序列表数字序号的呈现",-1))])]),p("div",V0,[p("div",G0,[d[41]||(d[41]=p("span",{style:{"font-size":"12px",color:"var(--b3-theme-on-surface)"}},"无序圆点",-1)),p("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":me(i).showUnorderedListMarkers?"关闭无序列表圆点显示":"开启无序列表圆点显示"},[p("input",{type:"checkbox",checked:me(i).showUnorderedListMarkers,onChange:d[13]||(d[13]=h=>a(h.target.checked))},null,40,q0),d[40]||(d[40]=p("span",{class:"spm-switch-slider"},null,-1))],8,K0)]),p("div",Y0,[d[43]||(d[43]=p("span",{style:{"font-size":"12px",color:"var(--b3-theme-on-surface)"}},"有序序号",-1)),p("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":me(i).showOrderedListMarkers?"关闭有序列表序号显示":"开启有序列表序号显示"},[p("input",{type:"checkbox",checked:me(i).showOrderedListMarkers,onChange:d[14]||(d[14]=h=>r(h.target.checked))},null,40,J0),d[42]||(d[42]=p("span",{class:"spm-switch-slider"},null,-1))],8,Z0)])])]),p("div",X0,[d[51]||(d[51]=p("div",{class:"spm-control-header"},[p("div",{class:"spm-control-title-group"},[p("span",{class:"spm-control-title"},"演示全局操作")])],-1)),p("div",Q0,[p("button",{class:"spm-btn-action b3-tooltips b3-tooltips__sw","aria-label":"在当前文档下方开启分屏同步预览 (Alt+P)",onClick:d[15]||(d[15]=h=>u.$emit("openBottomPreview"))},[ae(pe,{name:"split-preview"}),d[44]||(d[44]=p("span",null,"分屏预览",-1))]),me($t)("presenterMode")?(X(),ee("button",{key:0,class:"spm-btn-action b3-tooltips b3-tooltips__sw","aria-label":"打开双屏演讲者控制台视窗 (Alt+M)",onClick:d[16]||(d[16]=h=>u.$emit("openPresenter"))},[ae(pe,{name:"presenter"}),d[45]||(d[45]=p("span",null,"演讲者视图",-1))])):Te("",!0),p("button",{class:"spm-btn-action b3-tooltips b3-tooltips__sw","aria-label":"识别各页分隔线前未设属性的提示块/引用块为标准讲稿备注",disabled:e.isBatchProcessing,onClick:d[17]||(d[17]=h=>u.$emit("identifyNotes"))},[ae(pe,{name:"notes"}),d[46]||(d[46]=p("span",null,"识别讲稿块",-1))],8,ek),p("button",{class:"spm-btn-action b3-tooltips b3-tooltips__sw","aria-label":"自动为正文各页标题及首块之外的后续内容块配置顺延 (+1) 逐步呈现动效",disabled:e.isBatchProcessing,onClick:d[18]||(d[18]=h=>u.$emit("autoAnimate"))},[ae(pe,{name:"step"}),d[47]||(d[47]=p("span",null,"智能动效",-1))],8,tk),me($t)("aiScript")?(X(),ee("button",{key:1,class:"spm-btn-action b3-tooltips b3-tooltips__se","aria-label":"智能分析长文本结构并给出大纲分页插入建议",onClick:d[19]||(d[19]=h=>u.$emit("aiAutoSplit"))},[ae(pe,{name:"sparkles"}),d[48]||(d[48]=p("span",null,"AI 智能分页",-1))])):Te("",!0),me($t)("exportHtml")?(X(),ee("button",{key:2,class:"spm-btn-action b3-tooltips b3-tooltips__sw","aria-label":"打包导出离线单文件 HTML 幻灯片",onClick:d[20]||(d[20]=h=>u.$emit("exportHtml"))},[ae(pe,{name:"export-html"}),d[49]||(d[49]=p("span",null,"导出 HTML",-1))])):Te("",!0),me($t)("exportPdf")?(X(),ee("button",{key:3,class:"spm-btn-action b3-tooltips b3-tooltips__se","aria-label":"打印生成 16:9 高清演示 PDF 讲义",onClick:d[21]||(d[21]=h=>u.$emit("exportPdf"))},[ae(pe,{name:"export-pdf"}),d[50]||(d[50]=p("span",null,"导出 PDF",-1))])):Te("",!0),me($t)("exportImage")?(X(),ee("button",{key:4,class:$e(["spm-btn-action b3-tooltips b3-tooltips__s",{"is-loading":e.isExportingImages}]),disabled:e.isExportingImages,"aria-label":e.isExportingImages?"正在逐页导出高清图片包，请稍候...":"逐页导出高清图片包 (ZIP)",onClick:d[22]||(d[22]=h=>u.$emit("exportImages"))},[ae(pe,{name:"export-image"}),p("span",null,Ce(e.isExportingImages?"正在导出...":"导出图片"),1)],10,ik)):Te("",!0)])])]))}}),sk=/\.(?:png|jpe?g|gif|svg|webp|avif|ico|bmp|tiff?|mp4|webm|mp3|wav|ogg)$/i,ok=/\.(?:ts|js|mjs|cjs|jsx|tsx|vue|json|css|scss|less|html|py|rs|go|java|c|cpp|h|sh|bash|yaml|yml|toml)$/i;async function rk(e){const t=await Yl.loadAsync(e),i={},n=[];let s="",o="";const a=[];t.forEach((l,c)=>{!c.dir&&!l.startsWith("__MACOSX")&&!l.includes("node_modules/")&&a.push({path:l,file:c})});let r=a.find(l=>l.path.toLowerCase()==="slides.md");r||(r=a.find(l=>l.path.toLowerCase().endsWith("/slides.md"))),r||(r=a.find(l=>l.path.toLowerCase().endsWith(".md"))),r&&(s=await r.file.async("string"),o=r.path);for(const l of a){const c=l.path;if(c.toLowerCase().endsWith(".md")||ok.test(c)||c.includes("snippets/")){const u=await l.file.async("string");i[c]=u;const d=c.split("/");d.length>1&&(i[d.slice(1).join("/")]=u)}else if(sk.test(c)){const u=await l.file.async("uint8array"),d=c.split("/").pop()||c,h=typeof Blob<"u"?new Blob([u]):void 0;n.push({zipPath:c,fileName:d,data:u,blob:h})}}return{entryMarkdown:s,entryMarkdownPath:o,virtualFiles:i,assets:n}}function ak(e,t){if(Object.keys(t).length===0)return e;function i(s){const o=s.trim().replace(/^['"]|['"]$/g,""),a=o.split("/").pop()||o;if(t[o])return t[o];const r=o.replace(/^\.?\//,"");return t[r]?t[r]:t[a]?t[a]:null}function n(s){let o=s;return o=o.replace(/!\[(.*?)\]\((.*?)\)/g,(a,r,l)=>{const c=i(l);return c?`![${r}](${c})`:a}),o=o.replace(/\bsrc=["'](.*?)["']/gi,(a,r)=>{const l=i(r);return l?`src="${l}"`:a}),o}for(const s of e.slides)if(s.rawMarkdown=n(s.rawMarkdown),s.pageAttrs["custom-slides-background"]){const o=s.pageAttrs["custom-slides-background"],a=i(o);a&&(s.pageAttrs["custom-slides-background"]=a)}if(e.flattenedMarkdown=n(e.flattenedMarkdown),e.docRootAttrs["custom-slides-background"]){const s=e.docRootAttrs["custom-slides-background"],o=i(s);o&&(e.docRootAttrs["custom-slides-background"]=o)}return e}function nc(e){try{if(typeof process<"u"&&typeof require<"u"){const t=require("fs");if(t.existsSync(e))return t.readFileSync(e,"utf-8")}}catch{}return null}function lk(e,t){const i=e.match(/^[ \t]*<<<[ \t]+([^\s]+)/);if(!i)return null;const n=i[1].trim(),s=n.indexOf("#"),o=s!==-1?n.slice(0,s):n,a=s!==-1?n.slice(s+1):"",r=o.replace(/^@\//,"").replace(/^\.\//,""),l=(t==null?void 0:t.virtualFiles)||{};let c=l[o]||l[r]||l[`./${r}`]||l[`@/${r}`];if(!c&&Object.keys(l).length>0){const f=r.split("/").pop();for(const[v,m]of Object.entries(l))if(v.endsWith(`/${r}`)||f&&v.endsWith(`/${f}`)){c=m;break}}if(!c){const f=[];if(t!=null&&t.baseDir)try{const v=require("path");f.push(v.resolve(t.baseDir,r)),f.push(v.resolve(t.baseDir,o))}catch{}try{const v=require("path");f.push(v.resolve(process.cwd(),r))}catch{}for(const v of f){const m=nc(v);if(m!==null){c=m;break}}}if(!c){const f=zl||{};if(c=f[o]||f[r]||f[`snippets/${r}`],!c){const v=r.split("/").pop();for(const[m,b]of Object.entries(f))if(m.endsWith(`/${r}`)||v&&m.endsWith(`/${v}`)){c=b;break}}}if(!c)return null;let u=c;if(a){const f=new RegExp(`(?:\\/\\/|\\/\\*|#)?\\s*#(?:region|REGION)\\s+${a}[^\\r\\n]*\\r?\\n([\\s\\S]*?)(?:\\/\\/|\\/\\*|#)?\\s*#(?:endregion|ENDREGION)\\s+${a}`,"i"),v=c.match(f);if(v){const m=c.match(/^(\/\/\s*Inside[^\r\n]+\r?\n)/i);u=(m?m[1]:"")+v[1].trimEnd()}}const d=r.match(/\.([a-zA-Z0-9]+)$/);return`\`\`\`${d?d[1]:""}
${u}
\`\`\``}function ck(e){let t=!1,i=!1;for(let n=0;n<e.length;n++){const s=e[n];if(s==="'"&&!i)t=!t;else if(s==='"'&&!t)i=!i;else if(s==="#"&&!t&&!i)return e.slice(0,n).trim()}return e.trim()}function gs(e){const t={},i=e.split(/\r?\n/);let n=0;for(;n<i.length;){const s=i[n],o=s.trim();if(!o||o.startsWith("#")){n++;continue}const a=s.indexOf(":");if(a>0){const r=s.slice(0,a).trim();let l=s.slice(a+1).trim();if(l==="|"||l===">"){n++;const c=[];let u=-1;for(;n<i.length;){const d=i[n];if(!d.trim()){c.push(""),n++;continue}const f=d.match(/^(\s+)/),v=f?f[1].length:0;if(u===-1&&(u=v),v<u)break;c.push(d.slice(u)),n++}for(;c.length>0&&c[c.length-1]==="";)c.pop();t[r]=l===">"?c.join(" "):c.join(`
`);continue}if(l=ck(l),!l){let c=n+1;const u=[];let d=-1;for(;c<i.length;){const h=i[c],f=h.trim();if(!f||f.startsWith("#")){d!==-1&&u.push(""),c++;continue}const v=h.match(/^(\s+)/),m=v?v[1].length:0;if(d===-1)if(m>0)d=m;else break;if(m<d)break;u.push(h.slice(d)),c++}if(u.length>0){t[r]=gs(u.join(`
`)),n=c;continue}}l.startsWith('"')&&l.endsWith('"')||l.startsWith("'")&&l.endsWith("'")?l=l.slice(1,-1):l==="true"?l=!0:l==="false"?l=!1:l==="null"?l=null:/^-?\d+(?:\.\d+)?$/.test(l)&&(l=Number(l)),t[r]=l}n++}return t}const dk=/^\s*```ya?ml([\s\S]*?)```/;function ua(e){let t={},i=e.trim();const n=i.match(/^---[^\n\r]*\r?\n([\s\S]*?)\r?\n---(?=[ \t]*(?:\r?\n|$))/);if(n&&!n[1].includes("```")){const o=gs(n[1]);if(Object.keys(o).length>0||!n[1].trim())return t=o,i=i.slice(n[0].length).trim(),{frontmatter:t,content:i}}if(i.startsWith("---")){const o=i.match(/^---[^\n\r]*(?:\r?\n|$)/);o&&(i=i.slice(o[0].length).trim())}const s=i.match(dk);if(s)t=gs(s[1]),i=i.slice(s[0].length).trim();else{const o=i.split(/\r?\n/),a=[];let r=0;for(let l=0;l<o.length;l++){const c=o[l].trim();if(!c){if(a.length>0){r=l+1;break}continue}if(/^[a-zA-Z0-9_-]+\s*:\s*.*/.test(c)&&!c.startsWith("<")&&!c.startsWith("#"))a.push(c);else{r=l;break}}a.length>0&&(t=gs(a.join(`
`)),i=o.slice(r).join(`
`).trim())}return{frontmatter:t,content:i}}function uk(e){const t=e.split(/\r?\n/),i=[];let n=0,s=!1;function o(a){if(n>=a)return;const r=t.slice(n,a).join(`
`).trim();r&&i.push(r),n=a+1}for(let a=0;a<t.length;a++){const l=t[a].trimEnd();if(s){l.includes("-->")&&(s=!1);continue}if(l.startsWith("<!--")){l.includes("-->")||(s=!0);continue}if(l.startsWith("---")){o(a);const c=t[a+1];let u=!1,d=-1;const h=c?c.trim():"";if(l.replace(/^-+/,"").trim()===""&&h.length>0){for(let f=a+1;f<t.length;f++){const v=t[f].trimEnd();if(v.startsWith("```"))break;if(v==="---"){d=f;break}}d!==-1&&d-a<=60&&t.slice(a+1,d).some(m=>{const b=m.trim();return b.length>0&&!b.startsWith("#")&&/^[a-zA-Z0-9_$-]+\s*:\s*.*/.test(b)})&&(u=!0)}u&&d!==-1&&(n=a,a=d)}else if(l.trimStart().startsWith("```")){const c=l.match(/^\s*`+/),u=c?c[0].trim():"```";let d=a+1;for(;d<t.length&&!t[d].trimStart().startsWith(u);d++);d<t.length&&(a=d)}}return n<t.length&&o(t.length),i}function vs(e,t={}){const{stripNotesFromMarkdown:i=!0,cleanVClicks:n=!0,cleanShikiLines:s=!0,cleanSlots:o=!0,isolateStyleTags:a=!0,cleanHtmlToMarkdown:r=!0,wrapSuperBlocks:l=!0,virtualFiles:c={}}=t;let u=e;u&&!u.trimStart().startsWith("---")&&(u=`---

${u.trimStart()}`);const d=uk(u),h={};let f="",v="",m=0;if(d.length>0){const H=d[0],q=ua(H),_=Object.keys(q.frontmatter).length>0,N=q.content.length>0;_&&!N&&d.length>1?(m=1,b(q.frontmatter)):_&&b(q.frontmatter)}function b(H){f=H.title||"",H.theme&&(h[Rn]=String(H.theme)),H.aspectRatio&&(h[Nn]=String(H.aspectRatio)),H.highlighter&&(h[wa]=String(H.highlighter)),H.transition&&(h[zn]=String(H.transition)),H.colorSchema&&(h[xa]=String(H.colorSchema)),H.layout&&(h[Se]=String(H.layout)),H.background&&(h[st]=String(H.background)),H.image&&(h[Ot]=String(H.image)),H.class&&(h[Qi]=String(H.class));for(const[q,_]of Object.entries(H))["theme","aspectRatio","highlighter","transition","colorSchema","title","layout","background","image","class"].includes(q)||(h[`custom-slides-${q}`]=typeof _=="object"?JSON.stringify(_):String(_))}const y=[];let x=0,S=0,w=0,$=0;const E=new Set,C={};let L=1;for(let H=m;H<d.length;H++){const q=d[H],{frontmatter:_,content:N}=ua(q),k=q.match(/^\s*(?:---\s*)?src:\s*([^\n\r]+)/m),U=_.src||(k?k[1]:void 0);if(U){const le=String(U).trim().replace(/^['"]|['"]$/g,"");let J=c[le]||c[le.replace(/^\.\//,"")]||c[`pages/${le.replace(/^.*pages\//,"")}`];if(!J){const D=le.replace(/^\.\//,""),W=[];if(t.baseDir)try{const g=require("path");W.push(g.resolve(t.baseDir,D)),W.push(g.resolve(t.baseDir,le))}catch{}try{const g=require("path");W.push(g.resolve(process.cwd(),D)),W.push(g.resolve(process.cwd(),le))}catch{}for(const g of W){const V=nc(g);if(V!==null){J=V;break}}}const he={};_.layout&&(he[Se]=String(_.layout)),_.transition&&(he[gt]=String(_.transition)),_.background&&(he[st]=String(_.background)),_.image&&(he[Ot]=String(_.image)),_.class&&(he[Qi]=String(_.class));for(const[D,W]of Object.entries(_))["src","layout","transition","background","image","class"].includes(D)||(he[`custom-slides-${D}`]=typeof W=="object"?JSON.stringify(W):String(W));if(J){const D=vs(J,{...t,virtualFiles:c});for(const W of D.slides){W.pageIndex=L++,W.pageAttrs={...he,...W.pageAttrs},y.push(W);const g=W.pageAttrs[Se]||"default";C[g]=(C[g]||0)+1}continue}else{y.push({pageIndex:L++,pageAttrs:{...he,"custom-slides-src":le},notes:"",rawMarkdown:`> 📄 **引入外部幻灯片页面**: \`${le}\`
>
> *提示：如需展示该页面完整内容，请将关联子页面一同打包为 .zip 或通过本地工程导入。*`,hasVueComponent:!1,hasStyleTag:!1,assetReferences:[]});const D=he[Se]||"default";C[D]=(C[D]||0)+1;continue}}const F={};_.layout&&(F[Se]=String(_.layout)),_.transition&&(F[gt]=String(_.transition)),_.background&&(F[st]=String(_.background)),_.image&&(F[Ot]=String(_.image)),_.class&&(F[Qi]=String(_.class)),_.mask&&(F[en]=String(_.mask)),(_.maskRatio||_["mask-ratio"])&&(F[Fi]=String(_.maskRatio||_["mask-ratio"])),(_.maskStyle||_["mask-style"])&&(F[tn]=String(_.maskStyle||_["mask-style"])),(_.maskInitial||_["mask-initial"])&&(F[nn]=String(_.maskInitial||_["mask-initial"]));for(const[le,J]of Object.entries(_))["layout","transition","background","image","class","mask","maskRatio","mask-ratio","maskStyle","mask-style","maskInitial","mask-initial"].includes(le)||(F[`custom-slides-${le}`]=typeof J=="object"?JSON.stringify(J):String(J));let M=N;const B=[];let P=M.replace(/(?:^[ \t]*(`{3,}|~{3,})[^\n\r]*\r?\n[\s\S]*?\r?\n[ \t]*\1(?=[ \t]*(?:\r?\n|$)))/gm,le=>{const J=`__CODE_TOKEN_NOTE_${B.length}__`;return B.push(le),J});P=P.replace(/(`+)(?:[^\n\r`]|(?!\1)`)+?\1/g,le=>{const J=`__CODE_TOKEN_NOTE_${B.length}__`;return B.push(le),J});let se="";const G=Array.from(P.matchAll(/<!--([\s\S]*?)-->/g));if(G.length>0){const le=G[G.length-1],J=P.slice(le.index+le[0].length).trim();if(!J||!J.replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi,"").trim()){const D=le[1].trim();D.startsWith("TODO:")||(se=D,x++),i&&(P=P.slice(0,le.index).trimEnd()+P.slice(le.index+le[0].length))}}i&&(P=P.replace(/<!--(?![\s\S]*?TODO:)[\s\S]*?-->/g,"").trim());for(let le=0;le<B.length;le++)P=P.replace(`__CODE_TOKEN_NOTE_${le}__`,()=>B[le]);if(M=P,se){for(let he=0;he<B.length;he++)se=se.replace(`__CODE_TOKEN_NOTE_${he}__`,()=>B[he]);const J=`> [!NOTE] 💡 演讲备注
${se.split(/\r?\n/).map(he=>`> ${he}`).join(`
`)}
{: custom-slides-note="true"}`;M=M?`${M}

${J}`:J}let K=!1;if(/<style\b/i.test(M)){K=!0;const le=M.match(/<style\b[^>]*>([\s\S]*?)<\/style>/gi);if(le){for(const J of le){const he=J.replace(/<style\b[^>]*>|<\/style>/gi,"").trim();v=v?`${v}

${he}`:he}a&&(M=M.replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi,"").trim())}}const ce=M.match(/<v-click[^>]*>|<v-clicks[^>]*>|v-click=/g);ce&&(S+=ce.length);const ie=M.match(/```\w+\s+\{[^}]+\}/g);ie&&(w+=ie.length);const oe=M.match(/::\w+::|<template\s+#[^>]+>/g);if(oe&&($+=oe.length),M=M.replace(/^[ \t]*<<<[ \t]+([^\n\r]+)/gm,le=>lk(le,{...t,virtualFiles:c})||le),n&&(M=M.replace(/<v-click(?:\s+at="[^"]*")?(?:\s+hide)?>\s*([\s\S]*?)\s*<\/v-click>/gi,"$1")),s&&(M=M.replace(/(^```\w+(?:[ \t]+\[[^\]]*\])?)[ \t]+\{[^}]+\}(?:[ \t]+\w+)?/gm,"$1"),M=M.replace(/^\$\$\s+\{[^}]+\}/gm,()=>"$$")),o&&(M=M.replace(/^::\w+::\s*$/gm,"")),r&&(M=Qf(M)),l){let le=M.trim(),J="";const he=le.lastIndexOf("> [!NOTE] 💡 演讲备注");if(he!==-1&&(J=le.slice(he),le=le.slice(0,he).trim()),(_.layout==="image-left"||_.layout==="image-right")&&_.image){const D=String(_.image).trim(),W=_.layout==="image-left"?"image-left":"image-right",g=`![配图](${D})
{: custom-slides-layout="${W}" }`;_.layout==="image-left"?le=`{{{col

${g}

${le}

}}}`:le=`{{{col

${le}

${g}

}}}`}if(_.background){const W=`![背景图](${String(_.background).trim()})
{: custom-slides-role="background" }`;le=le?`${W}

${le}`:W}M=J?`${le}

${J}`:le}const re=fk(M);F[st]&&re.push(F[st]),F[Ot]&&re.push(F[Ot]);for(const le of re)E.add(le);const be=/<[A-Z][a-zA-Z0-9]+/.test(M),ke=F[Se]||(L===1?h[Se]||"cover":"default");C[ke]=(C[ke]||0)+1,y.push({pageIndex:L++,pageAttrs:F,notes:se,rawMarkdown:M,hasVueComponent:be,hasStyleTag:K,assetReferences:re})}if(!f&&y.length>0){const H=y[0].rawMarkdown.match(/^#\s+(.+)$/m);H&&(f=H[1].trim())}v&&(h["custom-slides-custom-css"]=v);let z=y.map(H=>`---

${H.rawMarkdown}`).join(`

`);return z.trimStart().startsWith("---")||(z=`---

${z.trimStart()}`),{docTitle:f||"Slidev 演示文稿",docRootAttrs:h,slides:y,totalSlides:y.length,stats:{totalNotes:x,totalVClicks:S,totalShikiHighlights:w,totalSlots:$,discoveredAssets:Array.from(E),layoutDistribution:C},flattenedMarkdown:z,customCss:v}}function fk(e){const t=[],i=/!\[.*?\]\((.*?)\)/g;let n;for(;(n=i.exec(e))!==null;){const o=n[1].split(/\s+/)[0].trim();o&&t.push(o)}const s=/<(?:img|video|source|audio)\b[^>]*src=["'](.*?)["']/gi;for(;(n=s.exec(e))!==null;){const o=n[1].trim();o&&t.push(o)}return t}function sc(e){if(!e)return!1;const t=String(e.type||"").toLowerCase(),i=String(e.markdown||"").trim(),n=String(e.content||"").trim();return t==="tb"||t==="thematic-break"||t==="nodethematicbreak"||i==="---"||i==="***"||n==="---"||n==="***"}function pk(e){return(e.trim()||"Slidev 演示文稿").replace(/[\\/:*?"<>|]/g,"_")}async function hk(e,t,i=ze){const n=e.filter(sc);let s=0;if(n.length>=t.length)for(let o=0;o<t.length;o++){const a=t[o],r=n[o];r&&r.id&&Object.keys(a.pageAttrs||{}).length>0&&(await i(r.id,a.pageAttrs),s++)}else for(let o=1;o<t.length;o++){const a=t[o],r=n[o-1];r&&r.id&&Object.keys(a.pageAttrs||{}).length>0&&(await i(r.id,a.pageAttrs),s++)}return s}async function mk(e,t=ze){let i=!1,n=0;for(const s of e){if(sc(s)){i=!1;continue}const o=(s.markdown||s.content||"").trim();if(o==="::right::"||o.startsWith("::right::")){i=!0;continue}i&&s.id&&(await t(s.id,{[Me]:"right"}).catch(()=>{}),n++)}return n}async function gk(e,t,i=ga){const n={};if(!t||t.length===0)return n;const s=[];for(const o of t){const a=new File([o.data],o.fileName,{type:"application/octet-stream"});s.push(a)}try{const o=await i("/data/assets",s);if(o!=null&&o.succMap)for(const[a,r]of Object.entries(o.succMap))n[a]=String(r)}catch(o){console.warn("上传本地静态资产失败，保留原路径:",o)}return Object.keys(n).length>0&&ak(e,n),n}async function vk(e){var x;const{presentation:t,notebookId:i,docTitle:n,extractedAssets:s=[],uploadAssets:o=!0,autoPreview:a=!0,plugin:r,api:l={}}=e,c=l.uploadFn||ga,u=l.createDocFn||ad,d=l.setAttrsFn||ze,h=l.getChildBlocksFn||Yn,f=l.openTabFn||ue.openTab,v=l.showMessageFn||ue.showMessage;o&&s.length>0&&await gk(t,s,c);const m=pk(n),b=`/${m}`,y=await u(i,b,t.flattenedMarkdown);if(!y)throw new Error("思源内核创建文档失败，未返回有效 DocumentId");try{const S=((x=t.slides[0])==null?void 0:x.pageAttrs)||{};await d(y,{...S,...t.docRootAttrs});const w=await h(y).catch(()=>[]);Array.isArray(w)&&w.length>0&&(await hk(w,t.slides,d),await mk(w,d))}catch(S){console.warn("[SlidesImport] 版式属性回填阶段遇到警告:",S),v(`⚠️ 文档已创建(${m})，但部分版式属性回填未完全完成: ${S.message||String(S)}`,6e3)}return v(`🎉 成功导入 Slidev 演示文档《${m}》！`),a&&r&&(r.currentDocId=y,await f({app:r.app,doc:{id:y}}),r.openBottomPreviewTab&&r.openBottomPreviewTab()),y}function bk(e){const t=ve("file"),i=ve(!1),n=ve(!1),s=ve(""),o=ve(null),a=ve(null),r=ve(""),l=ve(0),c=ve(""),u=ve([]),d=ve(null),h=ve(""),f=ve([]),v=ve(""),m=ve(!0),b=ve(!0),y=ve(!0),x=ve(!0),S=xe(()=>{const M=l.value;if(M===0)return"0 B";const B=1024,P=["B","KB","MB","GB"],se=Math.floor(Math.log(M)/Math.log(B));return`${(M/B**se).toFixed(1)} ${P[se]}`}),w=xe(()=>{var M;return((M=d.value)==null?void 0:M.docRootAttrs["custom-slides-theme"])||"default"}),$=xe(()=>{var M;return u.value.length>0?u.value.length:((M=d.value)==null?void 0:M.stats.discoveredAssets.length)||0}),E=xe(()=>{var B;const M=((B=d.value)==null?void 0:B.stats.layoutDistribution)||{};return Object.entries(M).map(([P,se])=>({name:P,count:se}))});async function C(M=rd){try{const B=await M();B!=null&&B.notebooks&&Array.isArray(B.notebooks)&&(f.value=B.notebooks.filter(P=>!P.closed),f.value.length>0&&!v.value&&(v.value=f.value[0].id))}catch(B){console.warn("获取笔记本列表失败:",B)}}function L(){var M;(M=o.value)==null||M.click()}function z(){a.value=null,r.value="",l.value=0,d.value=null,u.value=[],s.value=""}let H=0;async function q(M){const B=++H;s.value="",a.value=M,r.value=M.name,l.value=M.size;try{if(M.name.toLowerCase().endsWith(".zip")){const se=await M.arrayBuffer();if(B!==H)return;const G=await rk(se);if(B!==H)return;if(!G.entryMarkdown){s.value="未在 Zip 压缩包中找到 slides.md 或任何有效的 Markdown 入口文件";return}u.value=G.assets;const K=vs(G.entryMarkdown,{stripNotesFromMarkdown:b.value,cleanHtmlToMarkdown:m.value,cleanSlots:!1,virtualFiles:G.virtualFiles});if(B!==H)return;d.value=K,h.value=K.docTitle||M.name.replace(/\.zip$/i,"")}else{const se=await M.text();if(B!==H)return;u.value=[];const G=M.path||"",K=G?G.replace(/[\\/][^\\/]+$/,""):"",ce=vs(se,{stripNotesFromMarkdown:b.value,cleanHtmlToMarkdown:m.value,cleanSlots:!1,baseDir:K||void 0});if(B!==H)return;d.value=ce,h.value=ce.docTitle||M.name.replace(/\.md$/i,"")}}catch(P){if(B!==H)return;console.error("解析文件失败:",P),s.value=`解析文件失败: ${P.message||String(P)}`}}function _(){if(s.value="",!c.value.trim()){d.value=null;return}try{const M=vs(c.value,{stripNotesFromMarkdown:b.value,cleanHtmlToMarkdown:m.value,cleanSlots:!1});d.value=M,h.value=M.docTitle||"Slidev 演示文稿"}catch(M){s.value=`解析 Markdown 源码失败: ${M.message||String(M)}`}}async function N(){a.value?await q(a.value):c.value&&_()}async function k(M){const B=M.target;B.files&&B.files[0]&&await q(B.files[0])}async function U(M){var B;i.value=!1,(B=M.dataTransfer)!=null&&B.files&&M.dataTransfer.files[0]&&await q(M.dataTransfer.files[0])}async function F(M=e){if(d.value){if(!v.value&&f.value.length>0&&(v.value=f.value[0].id),!v.value){s.value="请先选择目标笔记本";return}n.value=!0,s.value="";try{return await vk({presentation:d.value,notebookId:v.value,docTitle:h.value,extractedAssets:u.value,uploadAssets:y.value,autoPreview:x.value,plugin:M})}catch(B){console.error("导入 Slidev 演示失败:",B),s.value=`导入执行失败: ${B.message||String(B)}`}finally{n.value=!1}}}return{inputMode:t,isDragging:i,isImporting:n,errorMessage:s,fileInputRef:o,selectedFile:a,selectedFileName:r,selectedFileSize:l,rawMarkdownText:c,extractedAssets:u,parsedPresentation:d,customDocTitle:h,notebooks:f,selectedNotebookId:v,optCleanHtml:m,optStripNotes:b,optUploadAssets:y,optAutoPreview:x,formattedFileSize:S,currentTheme:w,extractedAssetsCount:$,layoutChips:E,fetchNotebooks:C,triggerFileInput:L,clearFile:z,processFile:q,onFileSelected:k,onFileDrop:U,onTextChange:_,reprocessCurrentInput:N,handleConfirmImport:F}}const yk={class:"spm-import-dialog"},kk={class:"spm-tabs-header"},wk={class:"spm-dialog-body"},xk={key:0,class:"spm-file-section"},Sk={key:0,class:"spm-dropzone-prompt"},Ck={class:"spm-dropzone-icon"},_k={key:1,class:"spm-dropzone-active"},$k={class:"spm-file-badge"},Ik={class:"spm-file-size"},Mk={key:1,class:"spm-text-section"},Tk={key:2,class:"spm-error-banner"},Ek={key:3,class:"spm-preview-card"},Ak={class:"spm-preview-card__header"},Bk={style:{display:"inline-flex","align-items":"center",gap:"4px"}},Dk={class:"spm-config-grid"},Lk={class:"spm-form-item"},Pk={class:"spm-form-item"},Ok=["value"],Rk={class:"spm-stats-grid"},Nk={class:"spm-stat-box"},zk={class:"spm-stat-value"},Hk={class:"spm-stat-box"},Fk={class:"spm-stat-value"},jk={class:"spm-stat-box"},Wk={class:"spm-stat-value"},Uk={class:"spm-stat-box"},Vk={class:"spm-stat-value"},Gk={key:0,class:"spm-chips-row"},Kk={class:"spm-options-group"},qk={class:"spm-checkbox-label"},Yk={class:"spm-checkbox-label"},Zk={class:"spm-checkbox-label"},Jk={class:"spm-checkbox-label"},Xk={class:"spm-dialog-footer"},Qk=["disabled"],ew=["disabled"],tw={key:0,style:{display:"inline-flex","align-items":"center",gap:"4px"}},iw={key:1,style:{display:"inline-flex","align-items":"center",gap:"4px"}},nw=At({__name:"SlidesImportDialog",emits:["close","success"],setup(e,{emit:t}){const i=t,n=Nt("plugin"),{inputMode:s,isDragging:o,isImporting:a,errorMessage:r,fileInputRef:l,selectedFileName:c,rawMarkdownText:u,extractedAssetsCount:d,parsedPresentation:h,customDocTitle:f,notebooks:v,selectedNotebookId:m,optCleanHtml:b,optStripNotes:y,optUploadAssets:x,optAutoPreview:S,formattedFileSize:w,currentTheme:$,layoutChips:E,fetchNotebooks:C,triggerFileInput:L,clearFile:z,onFileSelected:H,onFileDrop:q,onTextChange:_,reprocessCurrentInput:N,handleConfirmImport:k}=bk(n);gn(async()=>{await C()});async function U(){const M=await k();M&&(i("success",{docId:M}),i("close"))}function F(){i("close")}return(M,B)=>(X(),ee("div",{class:"spm-modal-overlay",onClick:Yt(F,["self"])},[p("div",yk,[p("div",{class:"spm-dialog-header"},[B[18]||(B[18]=p("div",{class:"spm-dialog-title"},[p("svg",{class:"spm-dialog-icon","aria-hidden":"true"},[p("use",{"xlink:href":"#iconSlides"})]),p("span",null,"导入 Slidev 演示文档")],-1)),p("button",{class:"spm-close-btn",title:"关闭",onClick:F},"✕")]),p("div",kk,[p("button",{class:$e(["spm-tab-btn",{active:me(s)==="file"}]),onClick:B[0]||(B[0]=P=>s.value="file")},[ae(pe,{name:"package"}),B[19]||(B[19]=p("span",null,"文件 / 压缩包导入 (.zip / .md)",-1))],2),p("button",{class:$e(["spm-tab-btn",{active:me(s)==="text"}]),onClick:B[1]||(B[1]=P=>s.value="text")},[ae(pe,{name:"notes"}),B[20]||(B[20]=p("span",null,"粘贴 Markdown 源码",-1))],2)]),p("div",wk,[me(s)==="file"?(X(),ee("div",xk,[p("div",{class:$e(["spm-dropzone",{dragover:me(o),"has-file":!!me(c)}]),onDragover:B[4]||(B[4]=Yt(P=>o.value=!0,["prevent"])),onDragleave:B[5]||(B[5]=Yt(P=>o.value=!1,["prevent"])),onDrop:B[6]||(B[6]=Yt((...P)=>me(q)&&me(q)(...P),["prevent"])),onClick:B[7]||(B[7]=(...P)=>me(L)&&me(L)(...P))},[p("input",{ref_key:"fileInputRef",ref:l,type:"file",accept:".zip,.md",class:"spm-hidden-input",onChange:B[2]||(B[2]=(...P)=>me(H)&&me(H)(...P))},null,544),me(c)?(X(),ee("div",_k,[p("span",$k,[ae(pe,{name:"notes"}),_t(" "+Ce(me(c)),1)]),p("span",Ik,"("+Ce(me(w))+")",1),p("button",{class:"spm-btn-text",onClick:B[3]||(B[3]=Yt((...P)=>me(z)&&me(z)(...P),["stop"]))},"更换文件")])):(X(),ee("div",Sk,[p("span",Ck,[ae(pe,{name:"folder",style:{"font-size":"32px"}})]),B[21]||(B[21]=p("p",{class:"spm-dropzone-text"},"点击选择文件，或直接拖拽文件至此处",-1)),B[22]||(B[22]=p("p",{class:"spm-dropzone-hint"},[_t(" 支持 Slidev 完整工程 "),p("strong",null,".zip"),_t("（自动解包 public/ 静态素材）或单文件 "),p("strong",null,".md")],-1))]))],34)])):(X(),ee("div",Mk,[Pt(p("textarea",{"onUpdate:modelValue":B[8]||(B[8]=P=>tt(u)?u.value=P:null),class:"spm-textarea spm-source-editor",rows:"8",placeholder:"在此直接粘贴包含 Frontmatter 的 Slidev slides.md 源码...",onInput:B[9]||(B[9]=(...P)=>me(_)&&me(_)(...P))},null,544),[[Lo,me(u)]])])),me(r)?(X(),ee("div",Tk," ⚠️ "+Ce(me(r)),1)):Te("",!0),me(h)?(X(),ee("div",Ek,[p("div",Ak,[p("span",Bk,[ae(pe,{name:"sparkles"}),B[23]||(B[23]=_t(" 演示解析摘要",-1))]),B[24]||(B[24]=p("span",{class:"spm-badge-success"},"预检就绪",-1))]),p("div",Dk,[p("div",Lk,[B[25]||(B[25]=p("label",{class:"spm-form-label"},"笔记文档标题",-1)),Pt(p("input",{"onUpdate:modelValue":B[10]||(B[10]=P=>tt(f)?f.value=P:null),class:"spm-input",placeholder:"思源新文档标题"},null,512),[[Lo,me(f)]])]),p("div",Pk,[B[26]||(B[26]=p("label",{class:"spm-form-label"},"存放目标笔记本",-1)),Pt(p("select",{"onUpdate:modelValue":B[11]||(B[11]=P=>tt(m)?m.value=P:null),class:"spm-select"},[(X(!0),ee(Xe,null,xt(me(v),P=>(X(),ee("option",{key:P.id,value:P.id},Ce(P.name),9,Ok))),128))],512),[[Df,me(m)]])])]),p("div",Rk,[p("div",Nk,[p("span",zk,Ce(me(h).totalSlides),1),B[27]||(B[27]=p("span",{class:"spm-stat-label"},"幻灯片页数",-1))]),p("div",Hk,[p("span",Fk,Ce(me($)),1),B[28]||(B[28]=p("span",{class:"spm-stat-label"},"演示主题",-1))]),p("div",jk,[p("span",Wk,Ce(me(h).stats.totalNotes),1),B[29]||(B[29]=p("span",{class:"spm-stat-label"},"演讲者提词",-1))]),p("div",Uk,[p("span",Vk,Ce(me(d)),1),B[30]||(B[30]=p("span",{class:"spm-stat-label"},"关联本地素材",-1))])]),me(E).length>0?(X(),ee("div",Gk,[B[31]||(B[31]=p("span",{class:"spm-chips-label"},"页面版式分布：",-1)),(X(!0),ee(Xe,null,xt(me(E),P=>(X(),ee("span",{key:P.name,class:"spm-chip-badge"},Ce(P.name)+": "+Ce(P.count),1))),128))])):Te("",!0),p("div",Kk,[p("label",qk,[Pt(p("input",{"onUpdate:modelValue":B[12]||(B[12]=P=>tt(b)?b.value=P:null),type:"checkbox",onChange:B[13]||(B[13]=(...P)=>me(N)&&me(N)(...P))},null,544),[[as,me(b)]]),B[32]||(B[32]=p("span",null,"智能剥离展示型 HTML 容器为干净原生的 Markdown 笔记块",-1))]),p("label",Yk,[Pt(p("input",{"onUpdate:modelValue":B[14]||(B[14]=P=>tt(y)?y.value=P:null),type:"checkbox",onChange:B[15]||(B[15]=(...P)=>me(N)&&me(N)(...P))},null,544),[[as,me(y)]]),B[33]||(B[33]=p("span",null,"提取演讲者提词到块属性并保持正文笔记清爽",-1))]),p("label",Zk,[Pt(p("input",{"onUpdate:modelValue":B[16]||(B[16]=P=>tt(x)?x.value=P:null),type:"checkbox"},null,512),[[as,me(x)]]),B[34]||(B[34]=p("span",null,"自动上传关联素材至思源资产库并重写路径 (assets/...)",-1))]),p("label",Jk,[Pt(p("input",{"onUpdate:modelValue":B[17]||(B[17]=P=>tt(S)?S.value=P:null),type:"checkbox"},null,512),[[as,me(S)]]),B[35]||(B[35]=p("span",null,"导入后自动打开新文档并开启下方分屏放映预览",-1))])])])):Te("",!0)]),p("div",Xk,[p("button",{class:"spm-btn-secondary",disabled:me(a),onClick:F}," 取消 ",8,Qk),p("button",{class:"spm-btn-primary",disabled:!me(h)||me(a),onClick:U},[me(a)?(X(),ee("span",tw,[ae(pe,{name:"refresh"}),B[36]||(B[36]=_t(" 正在导入生成中...",-1))])):(X(),ee("span",iw,[ae(pe,{name:"rocket"}),B[37]||(B[37]=_t(" 确认导入思源笔记",-1))]))],8,ew)])])]))}}),sw=ei(nw,[["__scopeId","data-v-c56a3d7e"]]);function hr(e){return e?e==="NodeThematicBreak"||e==="tb"||e==="thematic-break":!1}function ow(e,t){var r;if(!e||e.length===0)return null;const i=t.activeBlockId||"",n=t.currentTopBlockId||i,s=t.currentPageDividerId||"",o=t.activeBlockType||"";if(hr(o)&&i){let l=e.find(c=>c.startBlockId===i);if(l||(l=e.find(c=>{var u,d;return((d=(u=c.blocks)==null?void 0:u[0])==null?void 0:d.id)===i}),l)||(l=e.find(c=>{var u;return(u=c.allBlockIds)==null?void 0:u.includes(i)}),l))return l}if(s){let l=e.find(c=>c.startBlockId===s);if(l||(l=e.find(c=>{var u,d;return((d=(u=c.blocks)==null?void 0:u[0])==null?void 0:d.id)===s}),l))return l}if(i){let l=e.find(u=>u.startBlockId===i);if(l||(l=e.find(u=>{var d,h;return((d=u.blocks)==null?void 0:d.some(f=>f.id===i))||((h=u.allBlockIds)==null?void 0:h.includes(i))}),l)||n&&n!==i&&(l=e.find(u=>{var d,h;return((d=u.blocks)==null?void 0:d.some(f=>f.id===n))||((h=u.allBlockIds)==null?void 0:h.includes(n))}),l)||(l=e.find(u=>{var d;return(d=u.noteBlocks)==null?void 0:d.some(h=>h.id===i||h.id===n)}),l))return l;const c=(r=t.activeBlockAttrs)==null?void 0:r[Me];if(c&&["col-1","col-2","col-3"].includes(c)&&(l=e.find(u=>{var d,h;return((d=u.frontmatter)==null?void 0:d.layout)==="three-cols-header"||((h=u.blocks)==null?void 0:h.some(f=>f.slot==="col-1"||f.slot==="col-2"||f.slot==="col-3"))}),l))return l}return e[0]||null}function et(e,t){var s;if(typeof document>"u"||!e)return;const i=(s=globalThis.CSS)!=null&&s.escape?globalThis.CSS.escape(e):e.replace(/"/g,'\\"'),n=document.querySelectorAll(`[data-node-id="${i}"]`);!n||n.length===0||n.forEach(o=>{for(const[a,r]of Object.entries(t))r!=null&&r!==""?o.setAttribute(a,String(r)):o.removeAttribute(a)})}function rw(e){if(typeof document>"u")return;const t=`.protyle-wysiwyg [${Se}], .protyle-wysiwyg [${Ze}], .protyle-wysiwyg [custom-slides-layout], .protyle-wysiwyg [custom-slides-role]`,i=document.querySelectorAll(t);!i||i.length===0||i.forEach(n=>{const s=n.getAttribute("data-node-id");if(!s){n.removeAttribute(Se),n.removeAttribute("custom-slides-layout"),n.removeAttribute(Ze),n.removeAttribute("custom-slides-role");return}const o=e.get(s),a=(o==null?void 0:o[Se])||(o==null?void 0:o["custom-slides-layout"])||"",r=n.getAttribute(Se)||n.getAttribute("custom-slides-layout");r&&r!==a&&(a?n.setAttribute(Se,a):(n.removeAttribute(Se),n.removeAttribute("custom-slides-layout")));const l=(o==null?void 0:o[Ze])||(o==null?void 0:o["custom-slides-role"])||"",c=n.getAttribute(Ze)||n.getAttribute("custom-slides-role");c&&c!==l&&(l?n.setAttribute(Ze,l):(n.removeAttribute(Ze),n.removeAttribute("custom-slides-role")))})}function aw(e,t){if(!t)return!1;if(e===t||typeof document>"u")return!0;const i=document.querySelector(`.protyle-wysiwyg [data-node-id="${t}"]`)||document.querySelector(`[data-node-id="${t}"]`);if(!i)return!1;const n=i.querySelector(":scope > [data-node-id], :scope > div > [data-node-id]");return(n==null?void 0:n.getAttribute("data-node-id"))===e}function lw(e){let t=null;function i(c="已同步"){e.saveStatus.value=c,t&&(typeof window<"u"?window.clearTimeout(t):clearTimeout(t));const u=()=>{e.saveStatus.value=""};typeof window<"u"?t=window.setTimeout(u,1200):t=setTimeout(u,1200)}async function n(c){var f;const u=e.activeBlockId.value||e.currentDocId.value;if(!u)return;for(const[v,m]of Object.entries(c))e.activeBlockAttrs.value[v]=m;De.setBlockAttrOverride(u,c),et(u,c);const d=(f=e.parentContainerId)==null?void 0:f.value,h=!!(d&&aw(u,d));if(Re in c&&h&&d){const v=c[Re];e.parentContainerClicks&&(e.parentContainerClicks.value=v),De.setBlockAttrOverride(d,{[Re]:v}),et(d,{[Re]:v}),ze(d,{[Re]:v}).catch(()=>{})}if(Se in c){const v=c[Se];e.currentPageDividerLayout.value=v,e.targetSlide.value&&(e.targetSlide.value.frontmatter||(e.targetSlide.value.frontmatter={}),e.targetSlide.value.frontmatter.layout=v)}if(wt in c){const v=c[wt];e.targetSlide.value&&(e.targetSlide.value.frontmatter||(e.targetSlide.value.frontmatter={}),e.targetSlide.value.frontmatter.layoutRatio=v)}i("保存中...");try{await ze(u,c),i("已同步"),e.plugin&&await e.plugin.compileCurrentDocument()}catch{i("同步失败")}}async function s(c,u){await n({[c]:u})}function o(){var u;return(e.activeBlockType.value==="NodeThematicBreak"||e.activeBlockType.value==="NodeThematicBreakBlock"||e.activeBlockType.value==="hr"||e.activeBlockType.value==="thematicbreak")&&e.activeBlockId.value?e.activeBlockId.value:e.currentPageDividerId.value?e.currentPageDividerId.value:(u=e.targetSlide.value)!=null&&u.startBlockId&&e.targetSlide.value.startBlockId!==e.currentDocId.value?e.targetSlide.value.startBlockId:e.currentDocId.value}async function a(c,u){const d=o();if(d){d===e.activeBlockId.value&&(e.activeBlockAttrs.value[c]=u),De.setBlockAttrOverride(d,{[c]:u}),et(d,{[c]:u}),c===Se&&(e.currentPageDividerLayout.value=u,e.targetSlide.value&&(e.targetSlide.value.frontmatter||(e.targetSlide.value.frontmatter={}),e.targetSlide.value.frontmatter.layout=u)),c===wt&&e.targetSlide.value&&(e.targetSlide.value.frontmatter||(e.targetSlide.value.frontmatter={}),e.targetSlide.value.frontmatter.layoutRatio=u),i("保存中...");try{await ze(d,{[c]:u}),i("已同步"),e.plugin&&await e.plugin.compileCurrentDocument()}catch{i("同步失败")}}}async function r(c,u){const d=o();if(!d)return;const h={[Se]:c,[wt]:u};d===e.activeBlockId.value&&(e.activeBlockAttrs.value[Se]=c,e.activeBlockAttrs.value[wt]=u),e.currentPageDividerLayout.value=c,De.setBlockAttrOverride(d,h),et(d,h),e.targetSlide.value&&(e.targetSlide.value.frontmatter||(e.targetSlide.value.frontmatter={}),e.targetSlide.value.frontmatter.layout=c,e.targetSlide.value.frontmatter.layoutRatio=u),i("应用排版中...");try{await ze(d,h),i("已应用分栏与比例"),e.plugin&&await e.plugin.compileCurrentDocument()}catch{i("应用失败")}}async function l(c,u){var h;const d=e.currentDocId.value||e.activeBlockId.value;if(d){e.activeBlockAttrs.value[c]=u,De.setBlockAttrOverride(d,{[c]:u}),et(d,{[c]:u}),(h=e.latestDoc.value)!=null&&h.config&&(c===Rn&&(e.latestDoc.value.config.theme=u),c===Nn&&(e.latestDoc.value.config.aspectRatio=u),c===zn&&(e.latestDoc.value.config.defaultTransition=u)),i("更新中...");try{await ze(d,{[c]:u}),i("已更新"),e.plugin&&await e.plugin.compileCurrentDocument(d)}catch{i("更新失败")}}}return{triggerSaveNotice:i,saveAttrs:n,saveAttr:s,getPageTargetBlockId:o,savePageAttr:a,applyPageLayoutAndRatio:r,saveDocAttr:l}}function fa(e){const t=(e.blocks||[]).filter(o=>{const a=(o.content||o.rawMarkdown||"").trim();return a&&a!=="---"});if(t.length===0)return"本页暂无内容，建议过渡承接上下文。";const i=[],n=[];for(const o of t){const a=(o.content||o.rawMarkdown||"").trim();a&&(o.type==="h"||a.startsWith("#")?i.push(a.replace(/^#+\s*/,"")):n.push(a.slice(0,50)))}const s=[];return i.length>0&&s.push(`【核心重点】：${i.join("、")}`),n.length>0&&(s.push("【口播要点】："),n.slice(0,3).forEach((o,a)=>{s.push(`${a+1}. 讲解 ${o}`)})),s.push("【过渡提示】：注意观察听众反应，适时抛出互动提问。"),s.join(`
`)}async function oc(e,t){const i=e.blocks&&e.blocks.length>0?e.blocks.map(n=>(n.content||n.rawMarkdown||"").trim()).filter(n=>n&&n!=="---").join(`
`):(e.rawMarkdown||"").replace(/^---\s*$/gm,"").trim();if(t&&i){const n=`你是一位专业的演讲教练。请根据以下幻灯片内容，提炼出简短精炼的演讲口播提词卡（Notes），包含核心观点与口播要点，总字数在 150 字以内：
${i}`;try{const s=await t(n);if(s&&s.trim())return{notes:s.trim(),isAiGenerated:!0}}catch(s){return{notes:fa(e),isAiGenerated:!1,error:(s==null?void 0:s.message)||"AI 调用异常"}}}return{notes:fa(e),isAiGenerated:!1}}async function cw(e,t){return(await oc(e,t)).notes}function dw(e){if(!e)return!1;const t=String(e.type||"").toLowerCase();return!!(t==="callout"||t==="nodecallout"||t==="b"||t==="nodeblockquote"||String(e.markdown||"").trim().startsWith(">"))}function uw(e,t){if(!((t==null?void 0:t[Ge])==="true"||(t==null?void 0:t["slides-note"])==="true"))return!1;const n=(e||"").trim();return/^>\s*\[!NOTE\]\s*(?:💡\s*)?(?:演讲备注|讲稿备注)/i.test(n)}async function fw(e,t){const n=await((t==null?void 0:t.getChildBlocksFn)||Yn)(e).catch(()=>[]);if(!Array.isArray(n)||n.length===0)return[];const s=[];let o=[];for(const r of n){if(Kn({...r,ial:{...r.ial||{},...De.getBlockAttrOverride(r.id)||{}}})){if(s.length===0&&o.length===0)continue;s.push(o),o=[];continue}o.push(r)}s.push(o);const a=[];for(let r=0;r<s.length;r++){const l=s[r];if(!l||l.length===0)continue;let c=null;for(let v=l.length-1;v>=0;v--){const m=l[v];if(!((m.type==="p"||m.type==="NodeParagraph")&&!(m.content||"").trim()&&!(m.markdown||"").trim())){c=m;break}}if(!c||!dw(c))continue;const u=De.getBlockAttrOverride(c.id)||{};let d={...c.ial||{},...u};if(!d[Ge]&&!d["slides-note"]&&(t!=null&&t.getBlockAttrsFn)){const v=await t.getBlockAttrsFn(c.id).catch(()=>({}));d={...d,...v,...u}}let h=c.markdown||c.content||"";if(t!=null&&t.getBlockKramdownFn)try{const v=await t.getBlockKramdownFn(c.id);v!=null&&v.kramdown&&(h=v.kramdown)}catch{}if(uw(h,d))continue;const f=dr(h)||h.replace(/<[^>]+>/g,"").trim();a.push({id:c.id,pageIndex:r+1,type:c.type,sourceMarkdown:h,cleanContent:f||"在此输入本页讲稿提词..."})}return a}async function pw(e,t,i){const n=(i==null?void 0:i.updateBlockFn)||yo,s=(i==null?void 0:i.setBlockAttrsFn)||ze,o=(i==null?void 0:i.syncDomFn)||et,r=`> [!NOTE] 💡 演讲备注
${t.split(/\r?\n/).map(l=>`> ${l}`).join(`
`)}
{: ${Ge}="true"}`;await n("markdown",r,e),await s(e,{[Ge]:"true"}),De.setBlockAttrOverride(e,{[Ge]:"true"}),o(e,{[Ge]:"true"})}async function rc(e,t){const i=(t==null?void 0:t.showMessageFn)||ue.showMessage,n=(t==null?void 0:t.confirmFn)||ue.confirm;if(!e)return i("请先在主编辑区打开幻灯片文档"),{totalScanned:0,matchedCount:0,successCount:0,errorCount:0};const s=await fw(e,t);if(s.length===0)return i("未发现待规范化的候选讲稿块"),{totalScanned:0,matchedCount:0,successCount:0,errorCount:0};const o=s.length;return new Promise(a=>{n("识别讲稿块",`扫描检测到 ${o} 处候选讲稿块（提示块或引用块），是否确认将其规范化为标准演讲备注？`,async()=>{var c;i(`正在批量规范化 ${o} 个讲稿块...`);let r=0,l=0;for(const u of s)try{await pw(u.id,u.cleanContent,t),r++}catch(d){console.error(`[SiYuanLiveSlides] 规范化讲稿块 ${u.id} 失败:`,d),l++}(c=t==null?void 0:t.onSuccessNotice)==null||c.call(t,"已规范化讲稿"),i(`已成功识别并规范化 ${r} 个讲稿块`),t!=null&&t.compileFn&&await t.compileFn().catch(()=>{}),a({totalScanned:o,matchedCount:o,successCount:r,errorCount:l})},()=>{a({totalScanned:o,matchedCount:o,successCount:0,errorCount:0})})})}function hw(e,t){const i=ve(!1),{triggerSaveNotice:n}=t;async function s(h){var $,E,C,L,z,H,q,_;const m=`> [!NOTE] 💡 演讲备注
${(h||"在此输入本页讲稿提词...").split(/\r?\n/).map(N=>`> ${N}`).join(`
`)}
{: custom-slides-note="true"}`,b=(($=e.latestDoc.value)==null?void 0:$.slides)||[],y=e.targetSlide.value,x=y?b.findIndex(N=>N===y):-1;let S=null;if(x!==-1&&x<b.length-1){const N=b[x+1];S=await zi("markdown",m,N.startBlockId)}else{const N=((E=y==null?void 0:y.noteBlocks)==null?void 0:E.slice(-1)[0])||((C=y==null?void 0:y.blocks)==null?void 0:C.slice(-1)[0]),k=(N==null?void 0:N.id)||(y==null?void 0:y.startBlockId);k?S=await zi("markdown",m,void 0,k):S=await bo("markdown",m,e.currentDocId.value)}const w=((H=(z=(L=S==null?void 0:S[0])==null?void 0:L.doOperations)==null?void 0:z[0])==null?void 0:H.id)||((q=S==null?void 0:S[0])==null?void 0:q.id);return w&&(await ze(w,{[Ge]:"true"}),De.setBlockAttrOverride(w,{[Ge]:"true"}),Vi(w,(_=e.plugin)==null?void 0:_.app)),e.plugin&&await e.plugin.compileCurrentDocument(),w}async function o(){const h=e.activeBlockId.value;if(h)if(e.isNoteBlock.value){n("取消中...");try{await ze(h,{[Ge]:"","slides-note":""}),De.setBlockAttrOverride(h,{[Ge]:"","slides-note":""}),et(h,{[Ge]:"","slides-note":""}),delete e.activeBlockAttrs.value[Ge],delete e.activeBlockAttrs.value["slides-note"],n("已取消备注"),ue.showMessage("已取消讲稿备注"),e.plugin&&await e.plugin.compileCurrentDocument()}catch(f){console.error("[SiYuanLiveSlides] 取消讲稿备注失败:",f),n("取消失败"),ue.showMessage("取消讲稿备注失败")}}else{n("转换中...");try{let f=e.rawSnippet.value;try{const y=await ld(h);y!=null&&y.kramdown&&(f=y.kramdown)}catch{}const b=`> [!NOTE] 💡 演讲备注
${(dr(f)||f.replace(/<[^>]+>/g,"").trim()||"在此输入本页讲稿提词...").split(/\r?\n/).map(y=>`> ${y}`).join(`
`)}
{: custom-slides-note="true"}`;await yo("markdown",b,h),await ze(h,{[Ge]:"true"}),De.setBlockAttrOverride(h,{[Ge]:"true"}),et(h,{[Ge]:"true"}),e.activeBlockAttrs.value[Ge]="true",e.activeBlockType.value="NodeCallout",n("已设为讲稿备注"),ue.showMessage("已转为讲稿备注提示块（不在幻灯片中渲染）"),e.plugin&&await e.plugin.compileCurrentDocument()}catch(f){console.error("[SiYuanLiveSlides] 转换讲稿备注提示块失败:",f),n("设置失败"),ue.showMessage("转为讲稿备注提示块失败")}}}async function a(){try{await s(),ue.showMessage("已在正文末尾插入讲稿备注提示块")}catch(h){ue.showMessage("插入讲稿备注块失败"),console.error(h)}}function r(){var v;const h=e.currentSlideNoteBlockId.value;if(!h){ue.showMessage("未找到本页关联的讲稿备注块");return}Vi(h,(v=e.plugin)==null?void 0:v.app)?ue.showMessage("已在编辑区定位讲稿备注块"):ue.showMessage("定位讲稿备注块失败")}async function l(){var v;if(!e.currentDocId.value)return;const h=e.targetSlide.value||{startBlockId:e.activeBlockId.value||e.currentDocId.value,blocks:e.rawSnippet.value&&e.rawSnippet.value!=="---"?[{id:e.activeBlockId.value,type:e.activeBlockType.value,content:e.rawSnippet.value,rawMarkdown:""}]:[],rawMarkdown:e.rawSnippet.value&&e.rawSnippet.value!=="---"?e.rawSnippet.value:""};ue.showMessage("正在调用思源 AI 提炼本页讲稿提词...");const f=await oc(h,ba);if(f.notes){const m=e.currentSlideNoteBlockId.value;if(m){const b=`> [!NOTE] 💡 演讲备注
${f.notes.split(/\r?\n/).map(y=>`> ${y}`).join(`
`)}
{: custom-slides-note="true"}`;await yo("markdown",b,m),await ze(m,{[Ge]:"true"}),De.setBlockAttrOverride(m,{[Ge]:"true"}),Vi(m,(v=e.plugin)==null?void 0:v.app)}else await s(f.notes);f.isAiGenerated?ue.showMessage("思源 AI 演讲提词卡生成成功！"):ue.showMessage("未获取到思源 AI 响应，已生成预设提词卡模板",5e3),e.plugin&&await e.plugin.compileCurrentDocument()}}async function c(){var m;if(i.value)return;const h=((m=e.latestDoc.value)==null?void 0:m.slides)||[];if(h.length===0){ue.showMessage("当前文档无幻灯片页面");return}const f=h.map((b,y)=>({slide:b,idx:y})).filter(({slide:b})=>{var S;const y=Array.isArray(b.noteBlocks)&&b.noteBlocks.length>0,x=!!((S=b.notes)!=null&&S.trim());return!y&&!x});if(f.length===0){ue.showMessage("所有幻灯片页面均已存在讲稿备注块，无需追加");return}const v=f.length;ue.confirm("批量追加讲稿备注",`将在未配置讲稿的 ${v} 页末尾自动插入讲稿提示块，是否继续？`,async()=>{var y,x,S,w,$,E;if(i.value)return;i.value=!0,ue.showMessage("正在批量追加讲稿块...");let b=0;try{const z=`> [!NOTE] 💡 演讲备注
${"在此输入本页讲稿提词...".split(/\r?\n/).map(H=>`> ${H}`).join(`
`)}
{: custom-slides-note="true"}`;for(const{slide:H,idx:q}of f)try{let _=null;if(q<h.length-1){const k=h[q+1];_=await zi("markdown",z,k.startBlockId)}else{const k=((y=H==null?void 0:H.noteBlocks)==null?void 0:y.slice(-1)[0])||((x=H==null?void 0:H.blocks)==null?void 0:x.slice(-1)[0]),U=(k==null?void 0:k.id)||(H==null?void 0:H.startBlockId);U?_=await zi("markdown",z,void 0,U):_=await bo("markdown",z,e.currentDocId.value)}const N=(($=(w=(S=_==null?void 0:_[0])==null?void 0:S.doOperations)==null?void 0:w[0])==null?void 0:$.id)||((E=_==null?void 0:_[0])==null?void 0:E.id);N&&(await ze(N,{[Ge]:"true"}),De.setBlockAttrOverride(N,{[Ge]:"true"})),b++}catch(_){console.error(`[SiYuanLiveSlides] 为第 ${q+1} 页追加讲稿块失败:`,_)}e.plugin&&await e.plugin.compileCurrentDocument(),ue.showMessage(`已成功为 ${b} 页追加讲稿备注块`)}catch(C){console.error("[SiYuanLiveSlides] 批量追加讲稿块失败:",C),ue.showMessage("批量追加讲稿块时出现异常")}finally{i.value=!1}})}async function u(){var b;if(i.value)return;const h=((b=e.latestDoc.value)==null?void 0:b.slides)||[];if(h.length===0){ue.showMessage("当前文档无幻灯片页面");return}const f=[];for(const y of h)if(y.noteBlocks&&y.noteBlocks.length>0)for(const x of y.noteBlocks)x.id&&f.push({id:x.id,pageIndex:y.pageIndex});if(f.length===0){ue.showMessage("当前文档中没有讲稿备注块，无需删除");return}const v=new Set(f.map(y=>y.pageIndex)).size,m=f.length;ue.confirm("危险操作：批量删除所有讲稿块",`此操作将从正文中物理删除全部 ${m} 个讲稿备注块（涉及 ${v} 页），删除后无法撤销。是否确认继续？`,async()=>{if(i.value)return;i.value=!0,ue.showMessage("正在批量删除讲稿块...");let y=0;try{for(const x of f)try{await va(x.id),De.clearBlockAttrOverride(x.id),y++}catch(S){console.error(`[SiYuanLiveSlides] 删除讲稿块 ${x.id} 失败:`,S)}e.activeBlockId.value&&f.some(x=>x.id===e.activeBlockId.value)&&(delete e.activeBlockAttrs.value[Ge],delete e.activeBlockAttrs.value["slides-note"]),e.plugin&&await e.plugin.compileCurrentDocument(),ue.showMessage(`已成功删除全部 ${y} 个讲稿备注块`)}catch(x){console.error("[SiYuanLiveSlides] 批量删除讲稿块失败:",x),ue.showMessage("批量删除讲稿块时出现异常")}finally{i.value=!1}})}async function d(){var f;const h=e.currentDocId.value||((f=e.plugin)==null?void 0:f.currentDocId);if(!h){ue.showMessage("请先在主编辑区打开幻灯片文档");return}if(i.value){ue.showMessage("正在批量处理中，请稍候...");return}i.value=!0;try{await rc(h,{onSuccessNotice:n,compileFn:async()=>{e.plugin&&await e.plugin.compileCurrentDocument()}})}finally{i.value=!1}}return{isBatchProcessing:i,createNoteBlockOnCurrentSlide:s,onToggleNoteBlock:o,onAddNoteBlock:a,onLocateNoteBlock:r,onGenerateNotesWithAI:l,onBatchAppendNotes:c,onBatchDeleteNotes:u,onIdentifyNotesBlocks:d}}function mw(e){if(!e)return!1;const t=String(e.type||"").toLowerCase();if(t==="h"||t==="nodeheading")return!0;const i=String(e.subType||"").toLowerCase();if(/^h[1-6]$/.test(i))return!0;const n=String(e.rawMarkdown||e.markdown||"").trim();return!!/^#{1,6}\s+/.test(n)}function gw(e){if(!e)return!1;const t=String(e.type||"").toLowerCase();return t==="i"||t==="nodelistitem"}function vw(e){const t=[],i=n=>{var s,o,a,r,l,c,u,d,h,f,v;for(const m of n){if(!m||m.isNote||((s=m.attributes)==null?void 0:s[Ge])==="true"||((o=m.attributes)==null?void 0:o["slides-note"])==="true"||((a=m.ial)==null?void 0:a[Ge])==="true"||((r=m.ial)==null?void 0:r["slides-note"])==="true"||m.type==="tb"||m.type==="thematic-break"||m.type==="NodeThematicBreak"||String(m.markdown||m.rawMarkdown||"").trim()==="---"||m.slot==="slot-divider-right"||String(m.rawMarkdown||m.markdown||"").trim()==="::right::")continue;if(mw(m)){t.push({id:m.id,type:m.type,isHeading:!0,currentClicks:m.clicks||((l=m.attributes)==null?void 0:l[Re])||((c=m.ial)==null?void 0:c[Re]),rawBlock:m});continue}if(gw(m)){t.push({id:m.id,type:m.type||"i",isHeading:!1,currentClicks:m.clicks||((u=m.attributes)==null?void 0:u[Re])||((d=m.ial)==null?void 0:d[Re]),rawBlock:m});continue}const b=m.children&&m.children.length>0?m.children:(h=m.rawNode)==null?void 0:h.children;if(Array.isArray(b)&&b.length>0){i(b);continue}t.push({id:m.id,type:m.type,isHeading:!1,currentClicks:m.clicks||((f=m.attributes)==null?void 0:f[Re])||((v=m.ial)==null?void 0:v[Re]),rawBlock:m})}};return i(e||[]),t}function bw(e){var s;if(e.pageIndex===1||((s=e.frontmatter)==null?void 0:s.layout)==="cover")return[];const t=vw(e.blocks||[]);if(t.length===0)return[];let i=-1;for(let o=0;o<t.length;o++)if(!t[o].isHeading){i=o;break}if(i===-1)return[];const n=[];for(let o=i+1;o<t.length;o++){const a=t[o];!!!(a.currentClicks&&String(a.currentClicks).trim()!=="")&&a.id&&n.push({blockId:a.id,pageIndex:e.pageIndex,targetClick:"+1"})}return n}async function yw(e,t){const n=await((t==null?void 0:t.compileDocFn)||(a=>De.compile(a)))(e).catch(()=>null);if(!n||!Array.isArray(n.slides)||n.slides.length===0)return{totalPages:0,animatedPagesCount:0,targets:[]};const s=[],o=new Set;for(const a of n.slides){const r=bw(a);r.length>0&&(s.push(...r),o.add(a.pageIndex))}return{totalPages:n.slides.length,animatedPagesCount:o.size,targets:s}}async function ac(e,t){const i=(t==null?void 0:t.showMessageFn)||ue.showMessage,n=(t==null?void 0:t.confirmFn)||ue.confirm,s=(t==null?void 0:t.setBlockAttrsFn)||ze,o=(t==null?void 0:t.syncDomFn)||et;if(!e)return i("请先在主编辑区打开幻灯片文档"),{totalPages:0,animatedPagesCount:0,targets:[],successCount:0,errorCount:0};const a=await yw(e,t);if(a.targets.length===0)return i("未检测到需要配置顺延动效的后续块"),{...a,successCount:0,errorCount:0};const r=a.targets.length,l=a.animatedPagesCount;return new Promise(c=>{n("智能设置动效",`扫描检测到可为 ${l} 页中的 ${r} 个后续块配置顺延 (+1) 动效，是否继续？`,async()=>{var h;i(`正在批量配置 ${r} 个后续块动效...`);let u=0,d=0;for(const f of a.targets)try{await s(f.blockId,{[Re]:f.targetClick}),De.setBlockAttrOverride(f.blockId,{[Re]:f.targetClick}),o(f.blockId,{[Re]:f.targetClick}),u++}catch(v){console.error(`[SiYuanLiveSlides] 为块 ${f.blockId} 配置动效失败:`,v),d++}(h=t==null?void 0:t.onSuccessNotice)==null||h.call(t,"已配置智能动效"),i(`已成功为 ${u} 个后续块配置顺延 (+1) 动效`),t!=null&&t.compileCurrentDocFn&&await t.compileCurrentDocFn().catch(()=>{}),c({...a,successCount:u,errorCount:d})},()=>{c({...a,successCount:0,errorCount:0})})})}function kw(e,t){const{saveAttr:i,saveAttrs:n,savePageAttr:s}=t;async function o(){(e.videoAutoplay.value?"false":"true")==="true"?(await n({[Ni]:"true",[Xi]:"true"}),e.activeBlockAttrs.value[Ni]="true",e.activeBlockAttrs.value[Xi]="true"):(await i(Ni,"false"),e.activeBlockAttrs.value[Ni]="false")}async function a(){const L=e.videoLoop.value?"false":"true";await i(ws,L)}async function r(){const L=e.videoMuted.value?"false":"true";await i(Xi,L)}async function l(){const L=e.videoControls.value?"false":"true";await i(xs,L)}async function c(L){var N;const z=e.activeBlockId.value;if(!z)return;const H=e.rawSnippet.value||"",q=Ti(H)||"",_=e.currentPageDividerId.value||e.currentDocId.value;if(L)if(L==="background"){const k={[Ze]:"background",[Se]:""};_&&q&&(e.pageBackground.value=q,await ze(_,{[st]:q}).catch(()=>{}),De.setBlockAttrOverride(_,{[st]:q}),et(_,{[st]:q}),e.targetSlide.value&&(e.targetSlide.value.frontmatter||(e.targetSlide.value.frontmatter={}),e.targetSlide.value.frontmatter.background=q)),await n(k)}else(L===Ss||L===Cs)&&await n({[Se]:L,[Ze]:""});else{const k={[Ze]:"",[Se]:""};if(e.activeBlockAttrs.value[st]==="true"&&(k[st]=""),_&&q&&e.pageBackground.value===q&&(e.pageBackground.value="",await ze(_,{[st]:""}).catch(()=>{}),De.setBlockAttrOverride(_,{[st]:""}),et(_,{[st]:""}),(N=e.targetSlide.value)!=null&&N.frontmatter&&delete e.targetSlide.value.frontmatter.background),await n(k),typeof document<"u"){const U=document.querySelector(`.protyle-wysiwyg [data-node-id="${z}"]`),F=U==null?void 0:U.closest('[data-type="NodeListItem"]'),M=F==null?void 0:F.getAttribute("data-node-id");if(M&&M!==z){const B={[Se]:"",[Ze]:""};et(M,B),De.setBlockAttrOverride(M,B),await ze(M,B).catch(()=>{})}}}}function u(){e.elemClick.value?i(Re,""):i(Re,"+1")}function d(L){i(Re,L)}function h(L){i(Jt,L)}function f(L){(e.activeBlockAttrs.value[Me]||"")===L?i(Me,""):i(Me,L)}function v(L){e.elemShikiLines.value=L,i(Gi,L)}function m(L){const z=L?L.trim():"",H=/^\d+$/.test(z)?`${z}px`:z;e.elemMaxHeight.value=H,i(Hn,H)}async function b(){const L=e.currentSlideLayout.value==="three-cols-header";await i(Me,L?"col-1":"left"),ue.showMessage(L?"已将当前块设置为第 1 栏":"已将当前块设置为双栏左栏")}async function y(){const L=e.activeBlockId.value;if(!L)return;const z={[Re]:"",[Jt]:"",[Me]:"",[Gi]:"",[Hn]:"",[Ge]:"","slides-note":"",[Se]:"",[wt]:"",[Ze]:"",[gt]:"",[st]:"",[Ot]:"",[Ni]:"",[ws]:"",[Xi]:"",[xs]:""};if(et(L,z),await ze(L,z),De.clearBlockAttrOverride(L),typeof document<"u"){const H=document.querySelector(`.protyle-wysiwyg [data-node-id="${L}"]`),q=H==null?void 0:H.closest('[data-type="NodeListItem"]'),_=q==null?void 0:q.getAttribute("data-node-id");_&&_!==L&&(et(_,z),await ze(_,z).catch(()=>{}),De.clearBlockAttrOverride(_))}e.activeBlockAttrs.value={},e.elemShikiLines.value="",e.elemMaxHeight.value="",e.pageBackground.value="",e.pageImage.value="",ue.showMessage("已清除本块演示属性"),e.plugin&&await e.plugin.compileCurrentDocument()}async function x(){if(e.activeBlockId.value)try{await zi("markdown","---",e.activeBlockId.value,void 0),ue.showMessage("已在上方插入分页符"),e.plugin&&e.plugin.compileCurrentDocument()}catch{ue.showMessage("插入分页符失败")}}async function S(){const L=e.activeBlockId.value||e.currentDocId.value;if(L)try{await zi("markdown","---",void 0,L),ue.showMessage("已在下方插入分页符"),e.plugin&&e.plugin.compileCurrentDocument()}catch{ue.showMessage("插入分页符失败")}}async function w(){if(e.activeBlockId.value)try{await va(e.activeBlockId.value),ue.showMessage("已删除该分页符"),e.activeBlockId.value="",e.activeBlockType.value="",e.plugin&&e.plugin.compileCurrentDocument()}catch{ue.showMessage("删除失败")}}async function $(){var L,z;try{let H=null;if(typeof document<"u"){const _=e.activeBlockId.value;if(_){const N=document.querySelector(`.protyle-wysiwyg [data-node-id="${_}"]`);N&&(H=N.getAttribute("data-type")==="NodeSuperBlock"?N:N.closest('[data-type="NodeSuperBlock"]'))}if(!H){const N=e.currentPageDividerId.value||(e.activeBlockType.value==="hr"||e.activeBlockType.value==="NodeThematicBreak"?e.activeBlockId.value:"");if(N){const k=document.querySelector(`.protyle-wysiwyg [data-node-id="${N}"]`);if(k){let U=k.nextElementSibling;for(;U&&!(U.getAttribute("data-type")==="NodeThematicBreak"||(L=U.classList)!=null&&L.contains("protyle-wysiwyg__block--hr"));){const F=U.getAttribute("data-type")==="NodeSuperBlock"?U:U.querySelector('[data-type="NodeSuperBlock"]');if(F){H=F;break}U=U.nextElementSibling}}}else{const k=document.querySelector('.protyle-wysiwyg [data-type="NodeThematicBreak"], .protyle-wysiwyg .protyle-wysiwyg__block--hr'),U=Array.from(document.querySelectorAll('.protyle-wysiwyg [data-type="NodeSuperBlock"]'));for(const F of U)if(!k||F.compareDocumentPosition(k)&Node.DOCUMENT_POSITION_FOLLOWING){H=F;break}}}}const q=[];if(H){const _=Array.from(H.querySelectorAll(":scope > [data-node-id]"));for(const N of _){const k=N.getAttribute("data-node-id");k&&(q.push(k),N.removeAttribute("style"))}}else if((z=e.targetSlide.value)!=null&&z.blocks){for(const _ of e.targetSlide.value.blocks)if(_.children&&_.children.length>=2){for(const N of _.children)N.id&&q.push(N.id);break}}if(q.length>0)for(const _ of q)await ze(_,{style:""}).catch(()=>{});await s(wt,""),ue.showMessage("已重置超级块为平均分布比例"),e.plugin&&await e.plugin.compileCurrentDocument()}catch(H){console.error("[layout-actions] resetSuperBlockWidth error:",H),ue.showMessage("重置超级块比例失败")}}async function E(){var L,z,H;try{let q=null;if(typeof document<"u"){const N=e.currentPageDividerId.value||(e.activeBlockType.value==="hr"||e.activeBlockType.value==="NodeThematicBreak"?e.activeBlockId.value:""),k=e.activeBlockId.value;let U=[];if(N){const B=document.querySelector(`.protyle-wysiwyg [data-node-id="${N}"]`);if(B){let P=B.nextElementSibling;for(;P&&!(P.getAttribute("data-type")==="NodeThematicBreak"||(L=P.classList)!=null&&L.contains("protyle-wysiwyg__block--hr"));)U.push(P),P=P.nextElementSibling}}else{const B=document.querySelector('.protyle-wysiwyg [data-type="NodeThematicBreak"], .protyle-wysiwyg .protyle-wysiwyg__block--hr'),P=Array.from(document.querySelectorAll(".protyle-wysiwyg > [data-node-id]"));for(const se of P)if(!B||se.compareDocumentPosition(B)&Node.DOCUMENT_POSITION_FOLLOWING)U.push(se);else break}const F=[];let M;for(const B of U){const P=B.getAttribute("data-type");P==="NodeHeading"&&(M=B.getAttribute("data-node-id")||void 0);const se=[];P==="NodeSuperBlock"?se.push(B):se.push(...Array.from(B.querySelectorAll('[data-type="NodeSuperBlock"]')));for(const G of se){if((G.getAttribute("data-sb-layout")||"").toLowerCase()==="row")continue;const ce=G.getAttribute("data-node-id")||"";let ie=[];const oe=Array.from(G.querySelectorAll('[data-type="NodeListItem"]'));if(oe.length===4&&(ie=oe.map(re=>re.getAttribute("data-node-id")).filter(Boolean)),ie.length!==4){const re=Array.from(G.querySelectorAll(":scope > [data-node-id]"));re.length===4&&(ie=re.map(be=>be.getAttribute("data-node-id")).filter(Boolean))}ie.length===4&&F.push({sbId:ce,itemIds:ie,headerId:M})}}F.length>0&&(k&&(q=F.find(B=>{if(B.sbId===k||B.itemIds.includes(k))return!0;const P=document.querySelector(`.protyle-wysiwyg [data-node-id="${B.sbId}"]`),se=document.querySelector(`.protyle-wysiwyg [data-node-id="${k}"]`);return!!(P&&se&&P.contains(se))})||null),q||(q=F[0]))}if(!q&&((z=e.targetSlide.value)!=null&&z.blocks)){const N=e.targetSlide.value,k=[];for(const F of N.blocks)F.rawNode?k.push(F.rawNode):k.push({id:F.id,type:F.type,content:F.content,markdown:F.rawMarkdown,children:F.children,ial:F.attributes||F.ial||{}});const U=Yf(k,e.activeBlockId.value);U&&U.items.length===4&&(q={sbId:U.superBlockNode.id,itemIds:U.items.map(F=>F.id),headerId:(H=U.headerNode)==null?void 0:H.id})}const _=e.currentPageDividerId.value||e.currentDocId.value;if(_&&(e.currentPageDividerLayout.value="clover",e.targetSlide.value&&(e.targetSlide.value.frontmatter||(e.targetSlide.value.frontmatter={}),e.targetSlide.value.frontmatter.layout="clover"),De.setBlockAttrOverride(_,{[Se]:"clover"}),et(_,{[Se]:"clover"}),await ze(_,{[Se]:"clover"}).catch(()=>{})),q&&q.itemIds.length>0){q.headerId&&(De.setBlockAttrOverride(q.headerId,{[Me]:"header"}),et(q.headerId,{[Me]:"header"}),await ze(q.headerId,{[Me]:"header"}).catch(()=>{}));const N=Math.min(4,q.itemIds.length);for(let k=0;k<N;k++){const U=q.itemIds[k],F=`col-${k+1}`;De.setBlockAttrOverride(U,{[Me]:F}),et(U,{[Me]:F}),await ze(U,{[Me]:F}).catch(()=>{})}}return ue.showMessage("已将本页版式设为四叶草（田字型）布局"),e.plugin&&await e.plugin.compileCurrentDocument(),!0}catch(q){return console.error("[layout-actions] applyCloverLayout error:",q),ue.showMessage("配置四叶草布局失败",4e3,"error"),!1}}async function C(){var z,H;const L=e.currentDocId.value||((z=e.plugin)==null?void 0:z.currentDocId);if(!L){ue.showMessage("请先在主编辑区打开幻灯片文档");return}if((H=t.isBatchProcessing)!=null&&H.value){ue.showMessage("正在批量处理中，请稍候...");return}t.isBatchProcessing&&(t.isBatchProcessing.value=!0);try{await ac(L,{onSuccessNotice:t.triggerSaveNotice,compileCurrentDocFn:async()=>{e.plugin&&await e.plugin.compileCurrentDocument()}})}finally{t.isBatchProcessing&&(t.isBatchProcessing.value=!1)}}return{onToggleVideoAutoplay:o,onToggleVideoLoop:a,onToggleVideoMuted:r,onToggleVideoControls:l,onImageRoleChange:c,toggleElemClick:u,onElemClickStepChange:d,onElemMotionChange:h,onElemSlotChange:f,onElemShikiLinesChange:v,onElemMaxHeightChange:m,onSetTwoColsContrast:b,onClearBlockAttrs:y,onInsertDividerBefore:x,onInsertDividerAfter:S,onDeleteCurrentBlock:w,resetSuperBlockWidth:$,applyCloverLayout:E,onAutoAnimateDocument:C}}function ww(e){const{triggerSaveNotice:t,saveAttrs:i,saveAttr:n,savePageAttr:s,applyPageLayoutAndRatio:o,saveDocAttr:a}=lw(e),r=hw(e,{triggerSaveNotice:t}),l=kw(e,{saveAttr:n,saveAttrs:i,savePageAttr:s,triggerSaveNotice:t,isBatchProcessing:r.isBatchProcessing});async function c(){var y;if(!e.latestDoc.value){ue.showMessage("请先在主编辑区打开幻灯片文档");return}const f=e.latestDoc.value,v=await Ii(f,(y=e.currentDocId)==null?void 0:y.value,e.plugin),m=Gl(f,{title:v});Kl(`${v}.html`,m)&&ue.showMessage(`已开始下载单文件离线 HTML 演示包 (${v}.html)`)}function u(){if(!e.latestDoc.value){ue.showMessage("请先在主编辑区打开幻灯片文档");return}ql(e.latestDoc.value)&&ue.showMessage("已唤起打印视窗，请在打印选项中选择「另存为 PDF」")}const d=ve(!1);async function h(){var f;if(d.value){ue.showMessage("正在导出图片中，请稍候...",2e3);return}if(!e.latestDoc.value){ue.showMessage("请先在主编辑区打开幻灯片文档");return}d.value=!0;try{ue.showMessage("正在启动后台沙箱并逐页导出幻灯片图片...");const v=e.latestDoc.value,m=await Ii(v,(f=e.currentDocId)==null?void 0:f.value,e.plugin),b=await Ql(v,{title:m,onProgress:(y,x)=>{ue.showMessage(`正在导出幻灯片图片 (${y} / ${x})...`,2e3)}});b.success?ue.showMessage(`🎉 成功导出 ${b.total||0} 张幻灯片高清图片并已保存为 ${m}.zip！`,4e3):ue.showMessage(`导出图片失败：${b.error||"未知异常"}`)}finally{d.value=!1}}return{triggerSaveNotice:t,saveAttrs:i,saveAttr:n,savePageAttr:s,applyPageLayoutAndRatio:o,saveDocAttr:a,onToggleVideoAutoplay:l.onToggleVideoAutoplay,onToggleVideoLoop:l.onToggleVideoLoop,onToggleVideoMuted:l.onToggleVideoMuted,onToggleVideoControls:l.onToggleVideoControls,onImageRoleChange:l.onImageRoleChange,onToggleNoteBlock:r.onToggleNoteBlock,createNoteBlockOnCurrentSlide:r.createNoteBlockOnCurrentSlide,onAddNoteBlock:r.onAddNoteBlock,onLocateNoteBlock:r.onLocateNoteBlock,onGenerateNotesWithAI:r.onGenerateNotesWithAI,isBatchProcessing:r.isBatchProcessing,onBatchAppendNotes:r.onBatchAppendNotes,onBatchDeleteNotes:r.onBatchDeleteNotes,onIdentifyNotesBlocks:r.onIdentifyNotesBlocks,toggleElemClick:l.toggleElemClick,onElemClickStepChange:l.onElemClickStepChange,onElemMotionChange:l.onElemMotionChange,onElemSlotChange:l.onElemSlotChange,onElemShikiLinesChange:l.onElemShikiLinesChange,onElemMaxHeightChange:l.onElemMaxHeightChange,onSetTwoColsContrast:l.onSetTwoColsContrast,onClearBlockAttrs:l.onClearBlockAttrs,onInsertDividerBefore:l.onInsertDividerBefore,onInsertDividerAfter:l.onInsertDividerAfter,onDeleteCurrentBlock:l.onDeleteCurrentBlock,resetSuperBlockWidth:l.resetSuperBlockWidth,applyCloverLayout:l.applyCloverLayout,onAutoAnimateDocument:l.onAutoAnimateDocument,isExportingImages:d,onExportHtml:c,onExportPdf:u,onExportImages:h}}function xw(e){const t=xe(()=>hr(e.activeBlockType.value));function i(n){const{attrKey:s,fallback:o,mode:a="defined"}=n,r=l=>a==="truthy"?l:l!==void 0;return xe(()=>{if(t.value){const c=e.activeBlockAttrs.value[s];if(r(c))return c}const l=e.currentPageDividerId.value||(t.value?e.activeBlockId.value:"");if(l){const c=De.getBlockAttrOverride(l);if(r(c==null?void 0:c[s]))return c[s]}return o()})}return{isDivider:t,resolvePageAttr:i}}function Sw(e,t){const i=[];let s=0;for(let o=0;o<e.length;o++){const a=e[o];if(Kn(a)){s=0;continue}const r=a.markdown||a.content||"";if(!(o===0)){if(a.type==="h"&&(a.subType==="h1"||r.startsWith("# "))){i.push({blockId:a.id,recommendedLayout:"cover",reason:"检测到一级核心章节标题，建议作为新幻灯片封面/大章"}),s=0;continue}if(a.type==="h"&&(a.subType==="h2"||r.startsWith("## "))){i.push({blockId:a.id,recommendedLayout:"default",reason:"检测到二级分论点标题，建议开启新页"}),s=0;continue}}if(s++,s>=6&&o<e.length-1){const c=e[o+1];Kn(c)||(i.push({blockId:c.id,recommendedLayout:"default",reason:"当前页已达容量上限 (避免信息超载)，建议在此分页"}),s=0)}}return i}async function lc(e){if(!e.currentDocId&&typeof document<"u"){const o=document.querySelector(".protyle-content[data-doc-id]");e.currentDocId=(o==null?void 0:o.getAttribute("data-doc-id"))||""}if(!e.currentDocId){ue.showMessage("请先打开一篇思源笔记文档");return}const t=await Yn(e.currentDocId).catch(()=>[]);if(!t||t.length===0){ue.showMessage("当前文档无内容，无需断页");return}const i=t.map(o=>({id:o.id,type:o.type,subType:o.subType,content:o.content||"",markdown:o.markdown||""})),n=Sw(i);if(n.length===0){ue.showMessage("AI 分析完毕：当前文档篇幅合理，暂无分页建议");return}ue.showMessage(`AI 分析完毕：发现 ${n.length} 处建议分页点，正在自动插入分页分割线...`);let s=0;for(const o of n)try{await zi("markdown","---",void 0,o.blockId),await ze(o.blockId,{"custom-slides-layout":o.recommendedLayout}),s++}catch(a){console.warn("Failed to insert divider:",a)}ue.showMessage(`已成功在 ${s} 处插入分页线并重新编译`),e.compileCurrentDocument(e.currentDocId)}const Cw={class:"spm-slides-inspector"},_w={class:"spm-inspector-topbar"},$w={class:"spm-inspector-title"},Iw={class:"slides-icon",style:{fill:"none !important"},"aria-hidden":"true",viewBox:"0 0 24 24"},Mw={class:"spm-inspector-topbar-actions"},Tw={class:"spm-target-banner"},Ew={class:"spm-target-info"},Aw=["aria-label"],Bw={key:0,class:"spm-save-status"},Dw=["title"],Lw={class:"spm-inspector-body"},Pw=At({__name:"SlidesInspectorDockView",setup(e,{expose:t}){const i=Nt("plugin"),n=ve(!1);function s(Q){n.value=!1,c.value=Q.docId,i!=null&&i.compileCurrentDocument&&i.compileCurrentDocument(Q.docId)}const o=ve(""),a=ve(""),r=ve({}),l=ve(""),c=ve(""),u=ve(""),d=ve(""),h=ve(""),f=ve(""),v=ve(""),m=ve(""),b=ve(null),y=ve(""),x=ve("");function S(){var we;const Q=o.value||c.value;Q&&typeof navigator<"u"&&(we=navigator==null?void 0:navigator.clipboard)!=null&&we.writeText&&navigator.clipboard.writeText(Q).then(()=>{x.value="已复制！",setTimeout(()=>{x.value=""},1500)}).catch(()=>{})}const w=xe(()=>hr(a.value)),$=xe(()=>a.value==="NodeCodeBlock"),E=ve(!1),C=xe(()=>{if(E.value||Ue.value)return!0;const Q=l.value||"";return!!Ti(Q)}),L=xe(()=>{const Q=a.value||"";if(Q==="NodeVideo"||Q==="video")return!0;const we=l.value||"";return!!(/<video\b/i.test(we)||/\.mp4\b/i.test(we))}),z=xe(()=>!o.value||o.value===c.value||a.value==="doc"||a.value==="NodeDocument"),H=xe(()=>{const Q=o.value||c.value||"";return Q.length>8?Q.slice(-8):Q||"无"}),q=xe(()=>l.value?l.value.replace(/<[^>]+>/g,"").replace(/[\r\n]+/g," ").trim().slice(0,45):""),_=xe(()=>{if(w.value)return"分页符 (---)";if(z.value)return"全局文档";if(L.value)return"视频块";let Q="内容块";switch(a.value){case"NodeHeading":Q="标题块";break;case"NodeParagraph":Q="段落块";break;case"NodeCodeBlock":Q="代码块";break;case"NodeVideo":Q="视频块";break;case"NodeList":case"NodeListItem":Q="列表项";break;case"NodeBlockquote":Q="引述块";break;case"NodeTable":Q="表格块";break;case"NodeSuperBlock":case"s":case"sb":Q="超级块";break;default:Q="内容块";break}return f.value?v.value?`${v.value.replace(/^col-(\d+)$/,"第 $1 栏")} › ${Q}`:`分栏容器 › ${Q}`:Q}),N=xe(()=>w.value?"tag-divider":z.value?"tag-doc":"tag-block"),k=xe(()=>r.value[Se]||"default"),U=xe(()=>r.value[gt]||"slide-left"),F=ve(""),M=ve(""),B=xe(()=>r.value[In]||"inherit"),P=xe(()=>{var Q;return ow((Q=b.value)==null?void 0:Q.slides,{activeBlockId:o.value,activeBlockType:a.value,currentTopBlockId:u.value,currentPageDividerId:d.value,activeBlockAttrs:r.value})}),se=xe(()=>{var Q;return((Q=P.value)==null?void 0:Q.notes)||""}),G=xe(()=>{var Q,we,Ae;return((Ae=(we=(Q=P.value)==null?void 0:Q.noteBlocks)==null?void 0:we[0])==null?void 0:Ae.id)||""}),K=xe(()=>{var We,Ve,Oe,ft,ts,vi;if(w.value){const it=r.value[Se]||r.value["custom-slides-layout"];if(it)return it}const Q=r.value[Me]||r.value["custom-slides-slot"];if(Q&&(["col-1","col-2","col-3"].includes(Q)||/^col-\d+$/.test(Q)))return"cols-header";if(h.value)return h.value;const we=d.value||(w.value?o.value:"");if(we){const it=De.getBlockAttrOverride(we);if(it!=null&&it[Se])return it[Se]}if(we&&((We=b.value)!=null&&We.slides)){const it=b.value.slides.find(qi=>qi.startBlockId===we);if((Ve=it==null?void 0:it.frontmatter)!=null&&Ve.layout)return it.frontmatter.layout}if((ft=(Oe=P.value)==null?void 0:Oe.frontmatter)!=null&&ft.layout)return P.value.frontmatter.layout;if((vi=(ts=P.value)==null?void 0:ts.blocks)!=null&&vi.some(it=>it.slot&&(["col-1","col-2","col-3"].includes(it.slot)||/^col-\d+$/.test(it.slot))))return"cols-header";const Ae=De.getBlockAttrOverride(c.value);return Ae!=null&&Ae[Se]?Ae[Se]:"default"}),ce=xw({activeBlockId:o,activeBlockType:a,activeBlockAttrs:r,currentPageDividerId:d}),ie=ce.resolvePageAttr({attrKey:wt,mode:"truthy",fallback:()=>{var Q,we;return((we=(Q=P.value)==null?void 0:Q.frontmatter)==null?void 0:we.layoutRatio)||""}}),oe=ce.resolvePageAttr({attrKey:en,fallback:()=>{var Q,we;return((we=(Q=P.value)==null?void 0:Q.frontmatter)==null?void 0:we.mask)||""}}),re=ce.resolvePageAttr({attrKey:Fi,fallback:()=>{var Q,we;return((we=(Q=P.value)==null?void 0:Q.frontmatter)==null?void 0:we.maskRatio)||""}}),be=ce.resolvePageAttr({attrKey:tn,fallback:()=>{var Q,we;return((we=(Q=P.value)==null?void 0:Q.frontmatter)==null?void 0:we.maskStyle)||"solid"}}),ke=ce.resolvePageAttr({attrKey:nn,fallback:()=>{var Q,we;return((we=(Q=P.value)==null?void 0:Q.frontmatter)==null?void 0:we.maskInitial)||"hidden"}});function le(Q){if(!Q||(Q.getAttribute("data-sb-layout")||"").toLowerCase()!=="col")return null;const Ae=Array.from(Q.querySelectorAll(":scope > [data-node-id]"));if(Ae.length<2)return null;const We=Ae.length,Ve=Ae.map(vi=>{const it=vi.getAttribute("style")||"",qi=it.match(/calc\(\s*([\d.]+)%/);if(qi)return parseFloat(qi[1]);const yn=it.match(/(?:^|;|\s)width:\s*([\d.]+)%/i);return yn?parseFloat(yn[1]):null});let Oe="",ft=!1;if(Ve.some(vi=>vi!==null)){ft=!0;const vi=Ve.reduce((Pe,pt)=>Pe+(pt||0),0),it=Ve.filter(Pe=>Pe===null).length,qi=it>0?Math.max(0,100-vi)/it:100/Ae.length,yn=Ve.map(Pe=>Pe!==null?Pe:qi),Xc=yn.reduce((Pe,pt)=>Pe+pt,0)||1,kn=yn.map(Pe=>Pe/Xc*100);if(kn.length===2){const[Pe]=kn;if(Pe>=48&&Pe<=52)Oe="1:1";else if(Pe>=31&&Pe<=35)Oe="1:2";else if(Pe>=65&&Pe<=69)Oe="2:1";else if(Pe>=28&&Pe<=32)Oe="3:7";else if(Pe>=68&&Pe<=72)Oe="7:3";else if(Pe>=38&&Pe<=42)Oe="4:6";else if(Pe>=58&&Pe<=62)Oe="6:4";else{const pt=Math.round(Pe);Oe=`${pt}:${100-pt}`}}else if(kn.length===3){const[Pe,pt,bi]=kn;if(Pe>=31&&Pe<=35&&pt>=31&&pt<=35&&bi>=31&&bi<=35)Oe="1:1:1";else if(Pe>=23&&Pe<=27&&pt>=48&&pt<=52&&bi>=23&&bi<=27)Oe="1:2:1";else if(Pe>=48&&Pe<=52&&pt>=23&&pt<=27&&bi>=23&&bi<=27)Oe="2:1:1";else if(Pe>=23&&Pe<=27&&pt>=23&&pt<=27&&bi>=48&&bi<=52)Oe="1:1:2";else{const yr=Math.round(Pe),kr=Math.round(pt);Oe=`${yr}:${kr}:${100-yr-kr}`}}else Oe=kn.map(Pe=>Math.round(Pe)).join(":")}else ft=!1,Oe=Array.from({length:We},()=>1).join(":");const ts=We>=2?"cols-header":"two-cols";return{hasSuperBlock:!0,colCount:We,ratio:Oe,isCustomWidth:ft,recommendedLayout:ts}}function J(Q){if(!(Q!=null&&Q.blocks))return null;for(const we of Q.blocks){const Ae=we.rawNode;if(Ae&&at(Ae)&&Qt(Ae)){const Ve=vn(Ae).length,Oe=cr(Ae);return{hasSuperBlock:!0,colCount:Ve,ratio:Oe||Array.from({length:Ve},()=>1).join(":"),isCustomWidth:!!Oe,recommendedLayout:Ve>=2?"cols-header":"two-cols"}}}return null}const he=xe(()=>{var Q;if(typeof document<"u"){const we=o.value;if(we){const We=document.querySelector(`.protyle-wysiwyg [data-node-id="${we}"]`);if(We){const Ve=We.getAttribute("data-type")==="NodeSuperBlock"?We:We.closest('[data-type="NodeSuperBlock"]');if(Ve){const Oe=le(Ve);if(Oe)return Oe}}}const Ae=d.value||(w.value?o.value:"");if(Ae){const We=document.querySelector(`.protyle-wysiwyg [data-node-id="${Ae}"]`);if(We){let Ve=We.nextElementSibling;for(;Ve&&!(Ve.getAttribute("data-type")==="NodeThematicBreak"||(Q=Ve.classList)!=null&&Q.contains("protyle-wysiwyg__block--hr"));){const Oe=Ve.getAttribute("data-type")==="NodeSuperBlock"?Ve:Ve.querySelector('[data-type="NodeSuperBlock"]');if(Oe){const ft=le(Oe);if(ft)return ft}Ve=Ve.nextElementSibling}}}else{const We=document.querySelector('.protyle-wysiwyg [data-type="NodeThematicBreak"], .protyle-wysiwyg .protyle-wysiwyg__block--hr'),Ve=Array.from(document.querySelectorAll('.protyle-wysiwyg [data-type="NodeSuperBlock"]'));for(const Oe of Ve)if(!We||Oe.compareDocumentPosition(We)&Node.DOCUMENT_POSITION_FOLLOWING){const ft=le(Oe);if(ft)return ft}}}return J(P.value)}),D=xe(()=>{var Q;return((Q=he.value)==null?void 0:Q.ratio)||""}),W=xe(()=>{const Q=a.value||"";if(Q==="NodeSuperBlock"||Q==="s"||Q==="sb")return!0;if(typeof document<"u"&&o.value){const we=document.querySelector(`.protyle-wysiwyg [data-node-id="${o.value}"]`);if(we!=null&&we.closest('[data-type="NodeSuperBlock"]'))return!0}return!1}),g=xe(()=>{var Q;return((Q=P.value)==null?void 0:Q.pageIndex)||1}),V=xe(()=>!!(r.value[Ge]||r.value["slides-note"]));function j(){if(!f.value)return!1;if(o.value===f.value||typeof document>"u")return!0;const Q=document.querySelector(`.protyle-wysiwyg [data-node-id="${f.value}"]`)||document.querySelector(`[data-node-id="${f.value}"]`);if(!Q)return!1;const we=Q.querySelector(":scope > [data-node-id], :scope > div > [data-node-id]");return(we==null?void 0:we.getAttribute("data-node-id"))===o.value}const I=xe(()=>{var we;if(r.value[Re]!==void 0)return r.value[Re]||"";if(f.value&&j())return m.value||"";if(f.value)return"";const Q=o.value;if(Q&&((we=P.value)!=null&&we.blocks)){const Ae=P.value.blocks.find(We=>We.id===Q);if(Ae!=null&&Ae.clicks)return Ae.clicks}return""}),T=xe(()=>{var we;if(r.value[Jt])return r.value[Jt];const Q=o.value;if(Q&&((we=P.value)!=null&&we.blocks)){const Ae=P.value.blocks.find(We=>We.id===Q);if(Ae!=null&&Ae.motion)return typeof Ae.motion=="string"?Ae.motion:JSON.stringify(Ae.motion)}return""}),O=xe(()=>{var we;if(r.value[Me])return r.value[Me];const Q=o.value;if(Q&&((we=P.value)!=null&&we.blocks)){const Ae=P.value.blocks.find(We=>We.id===Q);if(Ae!=null&&Ae.slot)return Ae.slot}return""}),Y=ve(""),A=ve(""),R=xe(()=>r.value[Ni]==="true"),Z=xe(()=>r.value[ws]==="true"),te=xe(()=>r.value[Xi]==="true"),ne=xe(()=>r.value[xs]!=="false"),ge=xe(()=>{var Q,we;return((we=(Q=b.value)==null?void 0:Q.config)==null?void 0:we.theme)||r.value[Rn]||"default"}),Ie=xe(()=>{var Q,we;return((we=(Q=b.value)==null?void 0:Q.config)==null?void 0:we.aspectRatio)||r.value[Nn]||"16/9"}),_e=xe(()=>{var Q,we;return((we=(Q=b.value)==null?void 0:Q.config)==null?void 0:we.defaultTransition)||r.value[zn]||"slide-left"}),Le=xe(()=>{var Q,we;return((we=(Q=b.value)==null?void 0:Q.config)==null?void 0:we.spacing)||r.value[wo]||"normal"}),Ue=xe(()=>{var Ve,Oe;if((r.value[Ze]||r.value["slides-role"])===Sa||r.value[st]==="true")return"background";const we=r.value[Se]||r.value["slides-layout"];if(we==="image-left"||we==="image-right")return we;const Ae=l.value||"",We=Ti(Ae);if(We&&((Oe=(Ve=P.value)==null?void 0:Ve.frontmatter)!=null&&Oe.background)){const ft=P.value.frontmatter.background;if(ft===We||ft.endsWith(We)||We.endsWith(ft))return"background"}return""}),qe=xe(()=>!!(r.value[Re]||r.value[Jt]||r.value[Me]||r.value[Gi]||r.value[Ge]||r.value["slides-note"]||r.value[Ze]||r.value[Se]||r.value[Ni]||r.value[ws]||r.value[Xi]||r.value[xs])),{saveAttr:de,savePageAttr:fe,applyPageLayoutAndRatio:Ye,applyCloverLayout:Ne,resetSuperBlockWidth:He,saveDocAttr:ot,onToggleVideoAutoplay:ti,onToggleVideoLoop:Ys,onToggleVideoMuted:Zs,onToggleVideoControls:es,onImageRoleChange:Ai,onToggleNoteBlock:Ki,onAddNoteBlock:pc,onLocateNoteBlock:hc,onGenerateNotesWithAI:mc,isBatchProcessing:mr,onBatchAppendNotes:gc,onBatchDeleteNotes:vc,onIdentifyNotesBlocks:bc,onAutoAnimateDocument:yc,toggleElemClick:kc,onElemClickStepChange:wc,onElemMotionChange:xc,onElemSlotChange:Sc,onElemShikiLinesChange:Cc,onElemMaxHeightChange:_c,onSetTwoColsContrast:$c,onClearBlockAttrs:Ic,onInsertDividerBefore:Mc,onInsertDividerAfter:gr,onDeleteCurrentBlock:Tc,onExportHtml:Ec,onExportPdf:Ac,onExportImages:Bc,isExportingImages:Dc}=ww({activeBlockId:o,activeBlockType:a,activeBlockAttrs:r,rawSnippet:l,currentDocId:c,currentPageDividerId:d,currentPageDividerLayout:h,parentContainerId:f,parentContainerClicks:m,latestDoc:b,targetSlide:P,currentSlideNoteBlockId:G,currentSlideLayout:K,isNoteBlock:V,elemClick:I,videoAutoplay:R,videoLoop:Z,videoMuted:te,videoControls:ne,pageBackground:F,pageImage:M,elemShikiLines:Y,elemMaxHeight:A,saveStatus:y,plugin:i});async function Lc(Q){if(Q==="clover"){if(!await Ne())return}else fe(Se,Q)}function Pc(Q){fe(wt,Q)}async function Oc(Q){await fe(en,Q),(Q==="clockwise"||Q==="counter-clockwise"||Q==="cw"||Q==="ccw")&&(!re.value||re.value==="1:1")&&await fe(Fi,"1:1:1:1")}function Rc(Q){fe(Fi,Q)}function Nc(Q){fe(tn,Q)}function zc(Q){fe(nn,Q)}function vr(Q){if(!Q)return;const we=Q.recommendedLayout||(Q.colCount&&Q.colCount>=2?"cols-header":"two-cols"),Ae=Q.ratio||(Q.colCount?Array(Q.colCount).fill(1).join(":"):"1:1");Ye(we,Ae)}function Hc(Q){fe(wt,Q)}async function Fc(){await He()}function jc(Q){de(gt,Q)}function Wc(Q){F.value=Q,de(st,Q)}function Uc(Q){M.value=Q,de(Ot,Q)}function Vc(Q){de(In,Q==="inherit"?"":Q)}function Gc(Q){ot(Rn,Q)}function Kc(Q){ot(Nn,Q)}function qc(Q){ot(zn,Q)}function Yc(Q){ot(wo,Q)}function br(){i!=null&&i.openBottomPreviewTab&&i.openBottomPreviewTab()}function Zc(){i!=null&&i.openPresenterTab&&i.openPresenterTab()}function Jc(){i&&$t("aiScript")&&lc(i)}return t({setActiveBlock(Q){o.value=Q.id,a.value=Q.type,r.value={...Q.attrs},l.value=Q.content||Q.markdown||"",u.value=Q.topBlockId||Q.id,d.value=Q.pageDividerId||"",h.value=Q.pageDividerLayout||"",f.value=Q.parentContainerId||"",v.value=Q.parentContainerSlot||"",m.value=Q.parentContainerClicks||"",Q.rootId?c.value=Q.rootId:(Q.type==="doc"||Q.type==="NodeDocument")&&Q.id&&(c.value=Q.id),F.value=Q.attrs[st]||"",M.value=Q.attrs[Ot]||"",Y.value=Q.attrs[Gi]||"",A.value=Q.attrs[Hn]||"",E.value=!!Q.isImage},updateDocument(Q){b.value=Q,c.value=Q.docId},openImportDialog(){n.value=!0},setCurrentDocId(Q){c.value=Q}}),(Q,we)=>(X(),ee("div",Cw,[p("div",_w,[p("div",$w,[(X(),ee("svg",Iw,[...we[2]||(we[2]=[p("rect",{x:"2",y:"3",width:"20",height:"14",rx:"2"},null,-1),p("line",{x1:"8",y1:"21",x2:"16",y2:"21"},null,-1),p("line",{x1:"12",y1:"17",x2:"12",y2:"21"},null,-1)])])),we[3]||(we[3]=p("span",null,"演示配置",-1))]),p("div",Mw,[me($t)("import")?(X(),ee("button",{key:0,class:"spm-icon-btn b3-tooltips b3-tooltips__sw","aria-label":"导入 Slidev 演示文档 (.md / .zip)",onClick:we[0]||(we[0]=Ae=>n.value=!0)},[ae(pe,{name:"import"}),we[4]||(we[4]=p("span",null,"导入",-1))])):Te("",!0),p("button",{class:"spm-icon-btn is-primary b3-tooltips b3-tooltips__sw","aria-label":"在下方分屏开启幻灯片预览 (Alt+P)",onClick:br},[ae(pe,{name:"split-preview"}),we[5]||(we[5]=p("span",null,"分屏预览",-1))])])]),p("div",Tw,[p("div",Ew,[p("span",{class:$e(["spm-target-tag",N.value])},Ce(_.value),3),p("span",{class:"spm-target-id b3-tooltips b3-tooltips__se","aria-label":x.value||"点击复制 ID: "+(o.value||c.value),onClick:S},[ae(pe,{name:"copy"}),p("span",null,"#"+Ce(H.value),1)],8,Aw)]),y.value?(X(),ee("span",Bw,"● "+Ce(y.value),1)):Te("",!0)]),q.value?(X(),ee("div",{key:0,class:"spm-context-quote",title:l.value},Ce(q.value),9,Dw)):Te("",!0),p("div",Lw,[w.value?(X(),Zt(w1,{key:0,"page-layout":k.value,"page-layout-ratio":me(ie),"page-mask":me(oe),"page-mask-ratio":me(re),"page-mask-style":me(be),"page-mask-initial":me(ke),"detected-sb-ratio":D.value,"detected-sb-info":he.value,"page-transition":U.value,"page-background":F.value,"page-spacing":B.value,"page-image":M.value,"page-notes":se.value,"page-index":g.value,"onUpdate:pageLayout":Lc,"onUpdate:pageLayoutRatio":Pc,"onUpdate:pageMask":Oc,"onUpdate:pageMaskRatio":Rc,"onUpdate:pageMaskStyle":Nc,"onUpdate:pageMaskInitial":zc,onApplySuperBlockLayout:vr,onResetSuperblockRatio:Fc,"onUpdate:pageTransition":jc,"onUpdate:pageBackground":Wc,"onUpdate:pageSpacing":Vc,"onUpdate:pageImage":Uc,onAddNoteBlock:me(pc),onLocateNoteBlock:me(hc),onGenerateNotes:me(mc),onBatchAppendNotes:me(gc),onBatchDeleteNotes:me(vc),"is-batch-processing":me(mr),onInsertDividerAfter:me(gr),onDeleteDivider:me(Tc)},null,8,["page-layout","page-layout-ratio","page-mask","page-mask-ratio","page-mask-style","page-mask-initial","detected-sb-ratio","detected-sb-info","page-transition","page-background","page-spacing","page-image","page-notes","page-index","onAddNoteBlock","onLocateNoteBlock","onGenerateNotes","onBatchAppendNotes","onBatchDeleteNotes","is-batch-processing","onInsertDividerAfter","onDeleteDivider"])):o.value&&!z.value?(X(),Zt(o0,{key:1,"elem-click":I.value,"elem-motion":T.value,"elem-slot":O.value,"elem-shiki-lines":Y.value,"elem-max-height":A.value,"is-code-block":$.value,"is-image":C.value,"is-video":L.value,"is-super-block":W.value,"detected-sb-info":he.value,"video-autoplay":R.value,"video-loop":Z.value,"video-muted":te.value,"video-controls":ne.value,"has-block-attrs":qe.value,"is-note":V.value,"image-role":Ue.value,"current-slide-layout":K.value,"parent-elem-click":m.value,"parent-container-slot":v.value,"parent-container-id":f.value,onToggleNote:me(Ki),onToggleElemClick:me(kc),onToggleVideoAutoplay:me(ti),onToggleVideoLoop:me(Ys),onToggleVideoMuted:me(Zs),onToggleVideoControls:me(es),"onUpdate:imageRole":me(Ai),"onUpdate:elemClick":me(wc),"onUpdate:elemMotion":me(xc),"onUpdate:elemSlot":me(Sc),"onUpdate:elemShikiLines":me(Cc),"onUpdate:elemMaxHeight":me(_c),onApplySuperBlockLayout:vr,onApplySuperBlockRatio:Hc,onInsertDividerBefore:me(Mc),onInsertDividerAfter:me(gr),onSetTwoColsContrast:me($c),onClearBlockAttrs:me(Ic)},null,8,["elem-click","elem-motion","elem-slot","elem-shiki-lines","elem-max-height","is-code-block","is-image","is-video","is-super-block","detected-sb-info","video-autoplay","video-loop","video-muted","video-controls","has-block-attrs","is-note","image-role","current-slide-layout","parent-elem-click","parent-container-slot","parent-container-id","onToggleNote","onToggleElemClick","onToggleVideoAutoplay","onToggleVideoLoop","onToggleVideoMuted","onToggleVideoControls","onUpdate:imageRole","onUpdate:elemClick","onUpdate:elemMotion","onUpdate:elemSlot","onUpdate:elemShikiLines","onUpdate:elemMaxHeight","onInsertDividerBefore","onInsertDividerAfter","onSetTwoColsContrast","onClearBlockAttrs"])):(X(),Zt(nk,{key:2,"doc-theme":ge.value,"doc-aspect-ratio":Ie.value,"doc-default-transition":_e.value,"doc-spacing":Le.value,"is-exporting-images":me(Dc),"is-batch-processing":me(mr),"onUpdate:docTheme":Gc,"onUpdate:docAspectRatio":Kc,"onUpdate:docDefaultTransition":qc,"onUpdate:docSpacing":Yc,onOpenBottomPreview:br,onOpenPresenter:Zc,onIdentifyNotes:me(bc),onAutoAnimate:me(yc),onAiAutoSplit:Jc,onExportHtml:me(Ec),onExportPdf:me(Ac),onExportImages:me(Bc)},null,8,["doc-theme","doc-aspect-ratio","doc-default-transition","doc-spacing","is-exporting-images","is-batch-processing","onIdentifyNotes","onAutoAnimate","onExportHtml","onExportPdf","onExportImages"]))]),n.value&&me($t)("import")?(X(),Zt(sw,{key:1,onClose:we[1]||(we[1]=Ae=>n.value=!1),onSuccess:s})):Te("",!0)]))}}),Ow=2e3,Rw=600;function Nw(e){return!e||typeof e.closest!="function"?!1:!!e.closest(".fn__none")}function mo(e){if(!e||typeof e.isConnected=="boolean"&&!e.isConnected)return!1;if(pa(e))return!0;const t=e.firstElementChild;return!!(t&&pa(t))}function pa(e){return typeof e.getClientRects=="function"&&e.getClientRects().length>0?!0:typeof e.offsetWidth=="number"&&e.offsetWidth>0&&e.offsetHeight>0}function zw(){const e=typeof globalThis<"u"?globalThis.IntersectionObserver:void 0;return typeof e=="function"?e:void 0}class Hw{constructor(){ye(this,"consumers",new Map);ye(this,"seq",0);ye(this,"verifyTimer",null)}register(t,i,n){if(!i)return()=>{};const s=++this.seq,o=zw(),a={kind:t,element:i,visible:!1,measureOnDemand:!o,observer:null,onVisible:n};return o?(a.observer=new o(r=>{var u;const l=r[r.length-1];if(!l)return;const c=l.isIntersecting&&!a.visible;a.visible=l.isIntersecting,c&&((u=a.onVisible)==null||u.call(a))}),a.observer.observe(i)):a.visible=mo(i),this.consumers.set(s,a),()=>{var r;(r=a.observer)==null||r.disconnect(),this.consumers.delete(s),this.consumers.size===0&&this.stopVerifyTimer()}}clear(){var t;for(const i of this.consumers.values())(t=i.observer)==null||t.disconnect();this.consumers.clear(),this.stopVerifyTimer()}get size(){return this.consumers.size}getVisibility(){if(this.consumers.size===0)return"none";if(typeof document<"u"&&document.visibilityState==="hidden")return"hidden";for(const t of this.consumers.values())if(t.measureOnDemand?mo(t.element):this.isRecordVisible(t))return"visible";return this.ensureVerifyTimer(),"hidden"}hasVisibleConsumer(){return this.getVisibility()==="visible"}isRecordVisible(t){return t.visible?!0:!Nw(t.element)}ensureVerifyTimer(){if(this.verifyTimer!==null||typeof setTimeout!="function")return;let t=!1;for(const i of this.consumers.values())if(!i.measureOnDemand){t=!0;break}t&&(this.verifyTimer=setTimeout(()=>{var i;this.verifyTimer=null;for(const n of this.consumers.values())if(!n.visible&&mo(n.element)){n.visible=!0,(i=n.onVisible)==null||i.call(n);return}},Ow))}stopVerifyTimer(){this.verifyTimer!==null&&(clearTimeout(this.verifyTimer),this.verifyTimer=null)}}const bs=new Hw,bn=new Qn;function cc(e,t,i){const n=()=>{var o;try{(o=i==null?void 0:i.flushDirtyCompile)==null||o.call(i)}catch{}},s=bs.register(e,t,n);return n(),s}let Si=null,Dt=null,ys=null;function Fw(){return Dt}function jw(e,t){Si&&dc(),Si=ar(Pg),Si.provide("plugin",t),Si.provide("sandboxBridge",bn);const i=Si.mount(e);return Dt=i,ys=cc("preview",e,t),i}function dc(e){ys&&(ys(),ys=null),Si&&(Si.unmount(),Si=null,Dt=null)}function Ww(){return Dt!==null}let Ci=null,Hi=null;function Uw(e,t){return Ci&&uc(),Ci=ar(Vv),Ci.provide("plugin",t),Ci.provide("sandboxBridge",bn),Hi=Ci.mount(e),Hi}function uc(e){Ci&&(Ci.unmount(),Ci=null,Hi=null)}function Vw(e){try{const t=new BroadcastChannel("siyuan-slides-sync");t.postMessage({type:"SYNC_SLIDES",slides:e.slides||[],config:e.config||{}}),t.close()}catch{}}let _i=null,It=null,ks=null;function Gw(e,t){_i&&fc(),_i=ar(Pw),_i.provide("plugin",t),_i.provide("sandboxBridge",bn);const i=_i.mount(e);return It=i,ks=cc("dock",e,t),i}function fc(e){ks&&(ks(),ks=null),_i&&(_i.unmount(),_i=null,It=null)}function Kw(e,t){It!=null&&It.updateDocument&&It.updateDocument(e),Dt!=null&&Dt.updateDocument?Dt.updateDocument(e,t):(bn.updateSlides(e.slides,e.config,e.fullMarkdown),Vw(e)),Hi!=null&&Hi.updateDocument&&Hi.updateDocument(e)}function Fo(e){Dt!=null&&Dt.navigateToBlock?Dt.navigateToBlock(e):bn.highlightElement(e)}function Ji(e){It!=null&&It.setActiveBlock&&It.setActiveBlock(e)}function qw(){return ri("import")?!1:It!=null&&It.openImportDialog?(It.openImportDialog(),!0):!1}const Yw=[{id:"slides-cover",name:"幻灯片 - 封面页 (Cover)",open:!0,attrs:[{key:Ri,value:"true"},{key:Se,value:"cover"},{key:gt,value:"fade"}]},{id:"slides-two-cols",name:"幻灯片 - 双栏对比 (Two Columns)",open:!0,attrs:[{key:Ri,value:"true"},{key:Se,value:"two-cols"},{key:gt,value:"slide-left"}]},{id:"slides-fact",name:"幻灯片 - 大字报与核心指标 (Fact)",open:!0,attrs:[{key:Ri,value:"true"},{key:Se,value:"fact"},{key:gt,value:"zoom"}]},{id:"slides-intro",name:"幻灯片 - 章节导引与作者 (Intro)",open:!0,attrs:[{key:Ri,value:"true"},{key:Se,value:"intro"},{key:gt,value:"slide-up"}]},{id:"slides-quote",name:"幻灯片 - 金句与强调 (Quote)",open:!0,attrs:[{key:Ri,value:"true"},{key:Se,value:"quote"},{key:gt,value:"fade"}]},{id:"slides-elem-click",name:"元素 - 顺延逐步呈现 (v-click)",open:!0,attrs:[{key:Re,value:"+1"}]},{id:"slides-elem-click-hide",name:"元素 - 隐藏直到激活 (v-click:hide)",open:!0,attrs:[{key:Re,value:"hide"}]},{id:"slides-elem-slot-right",name:"元素 - 双栏右栏归属 (Slot: Right)",open:!0,attrs:[{key:Me,value:"right"}]},{id:"slides-shiki-lines",name:"代码 - 逐行聚光高亮 (Shiki)",open:!0,attrs:[{key:Gi,value:"1-3"}]}];class go{getPresetTemplates(){return Yw}buildScanSlidesBlocksSql(t="custom-slides-"){return`SELECT block_id, name, value FROM attributes WHERE name LIKE '${t}%' ORDER BY block_id ASC`}buildTransitionStatsSql(){return`SELECT value, count(1) as count FROM attributes WHERE name = '${gt}' GROUP BY value ORDER BY count DESC`}async batchUpdateTransitions(t,i,n,s){const o=`SELECT block_id FROM attributes WHERE name = '${gt}' AND value = '${t}'`,a=await n(o);let r=0;if(Array.isArray(a))for(const l of a){const c=l.block_id||l.blockId;c&&(await s(c,{[gt]:i}),r++)}return{updatedCount:r}}async batchUpdateLayout(t,i,n,s){const o=`SELECT block_id FROM attributes WHERE name = '${Se}' AND value = '${t}'`,a=await n(o);let r=0;if(Array.isArray(a))for(const l of a){const c=l.block_id||l.blockId;c&&(await s(c,{[Se]:i}),r++)}return{updatedCount:r}}exportTemplatesJson(){const t=this.getPresetTemplates();return JSON.stringify({templates:t,counter:t.length},null,2)}formatTransitionSummary(t){return!t||t.length===0?"全库目前暂无已设置即现转场效果的块":`全库即现转场分布统计：${t.map(n=>`${n.value}: ${n.count} 个`).join("，")}`}}function Zw(e){if(e.addCommand({langKey:"slidesPresentation",langText:"即现: 在文档下方开启分屏演示预览",hotkey:"⌥P",enabled:()=>!0,execute:()=>{e.openBottomPreviewTab()}}),ri("import")||e.addCommand({langKey:"slidesImport",langText:"即现: 导入 Slidev 演示文档 (.md / .zip)",hotkey:"⌥I",enabled:()=>!0,execute:()=>{qw()||ue.showMessage("请先在右侧栏打开「即现演示配置」Dock 面板以呼起导入窗口")}}),e.addCommand({langKey:"slidesInitAttrs",langText:"即现: 初始化当前文档演示属性",hotkey:"",enabled:()=>!0,execute:async()=>{if(!e.currentDocId){const t=document.querySelector(".protyle-content[data-doc-id]");e.currentDocId=(t==null?void 0:t.getAttribute("data-doc-id"))||""}e.currentDocId&&(await ze(e.currentDocId,{"custom-slides-theme":"default","custom-slides-aspect-ratio":"16/9","custom-slides-default-transition":"slide-left"}),ue.showMessage("已为当前文档初始化即现演示属性"),e.compileCurrentDocument(e.currentDocId))}}),ri("aiScript")||e.addCommand({langKey:"slidesAiSplit",langText:"即现 AI: 智能大纲断页建议与自动分页",hotkey:"",enabled:()=>!0,execute:()=>lc(e)}),ri("aiScript")||e.addCommand({langKey:"slidesAiNotes",langText:"即现 AI: 自动为当前文档生成演讲者提词卡 (Notes)",hotkey:"",enabled:()=>!0,execute:async()=>{var l,c,u,d;if(!e.currentDocId){const h=document.querySelector(".protyle-content[data-doc-id]");e.currentDocId=(h==null?void 0:h.getAttribute("data-doc-id"))||""}if(!e.currentDocId){ue.showMessage("请先打开一篇思源笔记文档");return}ue.showMessage("正在调用思源 AI 提炼演讲者口播提词...");const t=await Yn(e.currentDocId).catch(()=>[]),i={startBlockId:e.currentDocId,blocks:t.map(h=>({id:h.id,type:h.type,content:h.content||"",rawMarkdown:h.markdown||""})),rawMarkdown:""},o=`> [!NOTE] 💡 演讲备注
${(await cw(i,ba)).split(/\r?\n/).map(h=>`> ${h}`).join(`
`)}
{: custom-slides-note="true"}`,a=await bo("markdown",o,e.currentDocId).catch(()=>null),r=((u=(c=(l=a==null?void 0:a[0])==null?void 0:l.doOperations)==null?void 0:c[0])==null?void 0:u.id)||((d=a==null?void 0:a[0])==null?void 0:d.id);r&&(await ze(r,{"custom-slides-note":"true"}),De.setBlockAttrOverride(r,{"custom-slides-note":"true"}),Vi(r,e.app)),ue.showMessage("已成功生成口播提词卡并插入为正文讲稿备注块"),e.compileCurrentDocument(e.currentDocId)}}),e.addCommand({langKey:"slidesIdentifyNotes",langText:"即现演示: 识别正文讲稿块并规范化",hotkey:"",enabled:()=>!0,execute:async()=>{let t=e.currentDocId;if(!t){const i=document.querySelector(".protyle-content[data-doc-id]");t=(i==null?void 0:i.getAttribute("data-doc-id"))||"",t&&(e.currentDocId=t)}if(!t){ue.showMessage("请先在主编辑区打开幻灯片文档");return}await rc(t,{compileFn:async()=>{await e.compileCurrentDocument(t)}})}}),e.addCommand({langKey:"slidesAutoAnimate",langText:"即现演示: 智能配置演示动效",hotkey:"",enabled:()=>!0,execute:async()=>{let t=e.currentDocId;if(!t){const i=document.querySelector(".protyle-content[data-doc-id]");t=(i==null?void 0:i.getAttribute("data-doc-id"))||"",t&&(e.currentDocId=t)}if(!t){ue.showMessage("请先在主编辑区打开幻灯片文档");return}await ac(t,{compileCurrentDocFn:async()=>{await e.compileCurrentDocument(t)}})}}),e.addCommand({langKey:"slidesBatchTransitions",langText:"即现协同: 统计全库转场效果分布",hotkey:"",enabled:()=>!0,execute:async()=>{const t=new go,i=t.buildTransitionStatsSql(),n=await dn(i).catch(()=>[]),s=t.formatTransitionSummary(n||[]);ue.showMessage(s)}}),e.addCommand({langKey:"slidesExportTemplates",langText:"即现协同: 复制即现预设属性模板至剪贴板",hotkey:"",enabled:()=>!0,execute:async()=>{const i=new go().exportTemplatesJson();typeof navigator<"u"&&navigator.clipboard?(await navigator.clipboard.writeText(i),ue.showMessage("已将即现属性模板 JSON 复制至剪贴板，可直接导入属性管家")):ue.showMessage(`已生成模板数据（请在控制台查看）：
`+i)}}),e.addCommand({langKey:"slidesBatchReplaceTransition",langText:"即现协同: 批量替换全库淡入淡出转场为滑动 (fade -> slide-left)",hotkey:"",enabled:()=>!0,execute:async()=>{const i=await new go().batchUpdateTransitions("fade","slide-left",n=>dn(n).catch(()=>[]),(n,s)=>ze(n,s));ue.showMessage(`全库批量替换完成：已将 ${i.updatedCount} 处 fade 转场更新为 slide-left`),e.compileCurrentDocument()}}),ri("presenterMode")||e.addCommand({langKey:"slidesPresenterMode",langText:"即现: 打开双屏演讲者控制台 (Presenter Mode)",hotkey:"⌥M",enabled:()=>!0,execute:()=>{e.openPresenterTab()}}),ri("proMode")||(e.addCommand({langKey:"slidesExportCliMd",langText:"即现 Pro: 导出 Slidev 标准 slides.md 文档 (下载到本地)",hotkey:"",enabled:()=>!0,execute:async()=>{if(e.latestCompiledDoc||await e.compileCurrentDocument(),!e.latestCompiledDoc){ue.showMessage("请先打开并放映一篇思源笔记文档");return}e.cliBridge.downloadSlidesMd(e.latestCompiledDoc,`slides-${e.currentDocId||"demo"}.md`)&&ue.showMessage("已生成标准 Slidev Markdown 并触发下载，可在本地使用 npx @slidev/cli 运行")}}),e.addCommand({langKey:"slidesProbeCliDevServer",langText:"即现 Pro: 检测本地 Slidev CLI DevServer 状态 (localhost:3030)",hotkey:"",enabled:()=>!0,execute:async()=>{ue.showMessage("正在探测本地 Slidev CLI DevServer (http://localhost:3030)..."),await e.cliBridge.probeServer(1500)?ue.showMessage("🟢 本地 Slidev CLI DevServer 运行正常！可直接在浏览器访问 http://localhost:3030"):ue.showMessage("⚪ 未检测到运行中的本地 Slidev CLI DevServer (端口 3030 未开启)")}}),e.addCommand({langKey:"slidesSyncToCliWorkspace",langText:"即现 Pro: 同步 slides.md 至思源工作空间存储目录",hotkey:"",enabled:()=>!0,execute:async()=>{if(e.latestCompiledDoc||await e.compileCurrentDocument(),!e.latestCompiledDoc){ue.showMessage("请先打开并放映一篇思源笔记文档");return}const t=await e.cliBridge.syncToWorkspaceFile(e.latestCompiledDoc,"/data/storage/petal/siyuan-live-slides/slides.md",ko);t.success?ue.showMessage(`已成功同步最新 slides.md 至工作空间：${t.path}`):ue.showMessage(`同步失败：${t.error}`)}})),!ri("exportImage")){let t=!1;e.addCommand({langKey:"slidesExportImagesZip",langText:"即现: 逐页导出幻灯片为高清图片包 (ZIP)",hotkey:"",enabled:()=>!0,execute:async()=>{if(t){ue.showMessage("正在导出图片中，请稍候...",2e3);return}if(e.latestCompiledDoc||await e.compileCurrentDocument(),!e.latestCompiledDoc){ue.showMessage("请先打开并放映一篇思源笔记文档");return}t=!0;try{ue.showMessage("正在启动后台沙箱并逐页导出幻灯片图片...");const i=e.latestCompiledDoc,n=await Ii(i,e.currentDocId,e),s=await Ql(i,{title:n,onProgress:(o,a)=>{ue.showMessage(`正在导出幻灯片图片 (${o} / ${a})...`,2e3)}});s.success?ue.showMessage(`🎉 成功导出 ${s.total||0} 张幻灯片高清图片并已保存为 ${n}.zip！`,4e3):ue.showMessage(`导出图片失败：${s.error||"未知异常"}`)}finally{t=!1}}})}}class Jw{constructor(t=400){ye(this,"entries",new Map);this.ttlMs=t}get(t,i=Date.now()){if(!t)return;const n=this.entries.get(t);if(n){if(i-n.at>this.ttlMs){this.entries.delete(t);return}return n.attrs}}set(t,i,n=Date.now()){!t||!i||this.entries.set(t,{attrs:i,at:n})}invalidate(t){t?this.entries.delete(t):this.entries.clear()}get size(){return this.entries.size}}function Xw(e){const t=new Map;if(!(e!=null&&e.slides))return t;const i=n=>{for(const s of n||[])s!=null&&s.id&&s.ial&&t.set(s.id,s.ial)};for(const n of e.slides)i(n.blocks),i(n.noteBlocks);return t}class Qw{constructor(t=150){ye(this,"lastBlockId","");ye(this,"lastAt",0);this.windowMs=t}shouldSkip(t,i=Date.now()){return t&&t===this.lastBlockId&&i-this.lastAt<this.windowMs?!0:(this.lastBlockId=t,this.lastAt=i,!1)}reset(){this.lastBlockId="",this.lastAt=0}}class e2{constructor(){ye(this,"attrCache",new Jw);ye(this,"compiledIalIndex",{doc:null,map:new Map});ye(this,"locatingLockUntil",0);ye(this,"lockedTargetBlockId","");ye(this,"lastKnownPageDividerId","");ye(this,"lastKnownDocId","")}isLocatingLocked(t){return Date.now()<this.locatingLockUntil?!(t&&t===this.lockedTargetBlockId):!1}async resolveBlockAttrs(t,i){if(!t)return{};const n=De.getBlockAttrOverride(t),s=this.getCompiledIal(i,t);if(n||s)return{...s||{},...n||{}};const o=this.attrCache.get(t);if(o)return o;const a=await jo(t).catch(()=>({}))||{};return this.attrCache.set(t,a),a}getCompiledIal(t,i){if(t)return this.compiledIalIndex.doc!==t&&(this.compiledIalIndex={doc:t,map:Xw(t)}),this.compiledIalIndex.map.get(i)}invalidateAttrCache(t){this.attrCache.invalidate(t)}getActiveDocumentId(){if(typeof document>"u")return"";const t=document.querySelector(".layout__wnd--active .protyle-title[data-node-id]")||document.querySelector(".item--focus .protyle-title[data-node-id]")||document.querySelector(".protyle-title[data-node-id]"),i=t==null?void 0:t.getAttribute("data-node-id");if(i)return i;const n=document.querySelector(".protyle .protyle-title[data-node-id]"),s=n==null?void 0:n.getAttribute("data-node-id");if(s)return s;const o=document.querySelector("[data-doc-id]"),a=o==null?void 0:o.getAttribute("data-doc-id");return a||""}resolveDocIdFromElement(t,i=""){const n=t.closest(".protyle-title"),s=n==null?void 0:n.getAttribute("data-node-id");if(s)return s;const o=t.closest(".protyle"),a=o==null?void 0:o.querySelector(".protyle-title"),r=a==null?void 0:a.getAttribute("data-node-id");if(r)return r;const l=t.closest("[data-doc-id]"),c=l==null?void 0:l.getAttribute("data-doc-id");if(c)return c;const u=this.getActiveDocumentId();return u||i}async switchToDocGlobalInspector(t,i){var o;if(!t)return;let n=i||"";if(!n&&typeof document<"u"){const a=document.querySelector(`.protyle-title[data-node-id="${t}"] .protyle-title__input`)||document.querySelector(`.protyle[data-doc-id="${t}"] .protyle-title__input`)||document.querySelector(".protyle-title__input");n=((o=a==null?void 0:a.innerText)==null?void 0:o.trim())||""}const s=await this.resolveBlockAttrs(t,null);Ji({id:t,rootId:t,type:"doc",content:n,attrs:s,isDivider:!1,isCode:!1}),Fo(t)}handleBlockClickedFromSlide(t,i,n,s,o){var c,u,d,h;if(!t){On();const f=typeof o=="number"&&o>0?o:1,v=((c=s==null?void 0:s.slides)==null?void 0:c[f-1])||((u=s==null?void 0:s.slides)==null?void 0:u[0]);if(v){const m=v.startBlockId||"",b=((d=v.frontmatter)==null?void 0:d.layout)||"",y={"custom-slides-layout":b,...v.frontmatter};return Ji({id:m,rootId:n,type:"NodeThematicBreak",attrs:y,isDivider:!0,isCode:!1,isImage:!1,pageDividerId:m,pageDividerLayout:b}),this.resolveBlockAttrs(m,s).then(x=>{x&&Object.keys(x).length>0&&Ji({id:m,rootId:n,type:"NodeThematicBreak",attrs:{...y,...x},isDivider:!0,isCode:!1,isImage:!1,pageDividerId:m,pageDividerLayout:b})}),!0}else return this.switchToDocGlobalInspector(n),!0}this.lockedTargetBlockId=t,this.locatingLockUntil=Date.now()+500;const a=Vi(t,i),r=typeof document<"u"?document.querySelector(`.protyle-wysiwyg [data-node-id="${t}"]`)||document.querySelector(`[data-node-id="${t}"]`):null,l=(r==null?void 0:r.getAttribute("data-type"))||"";if(r)this.syncInspectorBlock(r,t,l,n,s);else{let f="",v="";if(s!=null&&s.slides){const m=s.slides.find(b=>{var y,x,S;return b.startBlockId===t||((y=b.blocks)==null?void 0:y.some(w=>w.id===t))||((x=b.allBlockIds)==null?void 0:x.includes(t))||((S=b.noteBlocks)==null?void 0:S.some(w=>w.id===t))});m!=null&&m.startBlockId&&(f=m.startBlockId),(h=m==null?void 0:m.frontmatter)!=null&&h.layout&&(v=m.frontmatter.layout)}this.resolveBlockAttrs(t,s).then(async m=>{if(f&&!v){const b=De.getBlockAttrOverride(f);if(b!=null&&b[Se]||b!=null&&b["custom-slides-layout"])v=b[Se]||b["custom-slides-layout"]||"";else{const y=await this.resolveBlockAttrs(f,s);v=y[Se]||y["custom-slides-layout"]||"",y&&Object.keys(y).length>0&&De.setBlockAttrOverride(f,y)}}Ji({id:t,rootId:n,type:l||"NodeParagraph",attrs:m||{},pageDividerId:f,pageDividerLayout:v})}).catch(()=>{})}return a}async syncInspectorBlock(t,i,n,s,o){var U,F,M,B,P,se,G,K,ce;if(this.isLocatingLocked(i))return;let a=t,r=i,l=n;const c=typeof(t==null?void 0:t.closest)=="function"?t.closest('[data-type="NodeCallout"]'):null;if(c&&c!==t){const ie=c.getAttribute("data-node-id");if(ie){const oe=await this.resolveBlockAttrs(ie,o),re=De.getBlockAttrOverride(ie)||{},be={...oe,...re};(be[Ge]||be["slides-note"])&&(a=c,r=ie,l="NodeCallout")}}const u=a.closest(".protyle-wysiwyg > [data-node-id]")||a,d=(u==null?void 0:u.getAttribute("data-node-id"))||r,h=l==="NodeThematicBreak"||l==="tb"||l==="thematic-break"||(u==null?void 0:u.getAttribute("data-type"))==="NodeThematicBreak"||(u==null?void 0:u.getAttribute("data-type"))==="tb"||!!((U=u==null?void 0:u.classList)!=null&&U.contains("hr")),f=l==="NodeCodeBlock",v=((F=a.innerText)==null?void 0:F.trim())||"",m=await this.resolveBlockAttrs(r,o),b=De.getBlockAttrOverride(r)||{},y={...m,...b};let x="",S="";if(h)x=r,S=y[Se]||y["custom-slides-layout"]||"";else{let ie=u.previousElementSibling;for(;ie;){const oe=ie.getAttribute("data-type");if(oe==="NodeThematicBreak"||oe==="tb"||(M=ie.classList)!=null&&M.contains("hr")){x=ie.getAttribute("data-node-id")||"";break}ie=ie.previousElementSibling}}if(o!=null&&o.slides){const ie=[r,d];let oe=a.parentElement;for(;oe&&!oe.classList.contains("protyle-wysiwyg");){const be=oe.getAttribute("data-node-id");be&&!ie.includes(be)&&ie.push(be),oe=oe.parentElement}const re=o.slides.find(be=>{var ke,le,J;return ie.includes(be.startBlockId)||((ke=be.blocks)==null?void 0:ke.some(he=>ie.includes(he.id)))||((le=be.allBlockIds)==null?void 0:le.some(he=>ie.includes(he)))||((J=be.noteBlocks)==null?void 0:J.some(he=>ie.includes(he.id)))});re&&(!x&&re.startBlockId&&(x=re.startBlockId),!S&&((B=re.frontmatter)!=null&&B.layout)&&(S=re.frontmatter.layout))}if(x?(this.lastKnownDocId=s,this.lastKnownPageDividerId=x):s&&this.lastKnownDocId===s&&this.lastKnownPageDividerId&&(!u.previousElementSibling&&(((P=u.parentElement)==null?void 0:P.scrollTop)||0)===0||(x=this.lastKnownPageDividerId)),x){const ie=De.getBlockAttrOverride(x);if(ie&&(Se in ie||"custom-slides-layout"in ie)&&(S=ie[Se]||ie["custom-slides-layout"]||""),!S&&(o!=null&&o.slides)){const oe=o.slides.find(re=>re.startBlockId===x);(se=oe==null?void 0:oe.frontmatter)!=null&&se.layout&&(S=oe.frontmatter.layout)}if(!S){const oe=await this.resolveBlockAttrs(x,o);S=oe[Se]||oe["custom-slides-layout"]||"",oe&&Object.keys(oe).length>0&&De.setBlockAttrOverride(x,oe)}et(x,{[Se]:S||""})}else if(s){const ie=De.getBlockAttrOverride(s);ie&&(Se in ie||"custom-slides-layout"in ie)?S=ie[Se]||ie["custom-slides-layout"]||"":!S&&((ce=(K=(G=o==null?void 0:o.slides)==null?void 0:G[0])==null?void 0:K.frontmatter)!=null&&ce.layout)&&(S=o.slides[0].frontmatter.layout)}const w=a.getAttribute(Se)||a.getAttribute("custom-slides-layout"),$=y[Se]||y["custom-slides-layout"]||"";w&&w!==$&&et(r,{[Se]:$});const E=a.getAttribute(Ze)||a.getAttribute("custom-slides-role"),C=y[Ze]||y["custom-slides-role"]||"";E&&E!==C&&et(r,{[Ze]:C});let L="",z="",H="";const q=a.closest('[data-type="NodeListItem"]');if(q&&q!==a){const ie=q.getAttribute("data-node-id");if(ie){L=ie;const oe=await this.resolveBlockAttrs(ie,o),re=De.getBlockAttrOverride(ie)||{},be={...oe,...re};z=be[Me]||"",H=be[Re]||"";const ke=be[Se]||be["custom-slides-layout"]||"",le=q.getAttribute(Se)||q.getAttribute("custom-slides-layout");le&&le!==ke&&et(ie,{[Se]:ke});const J=be[Ze]||be["custom-slides-role"]||"",he=q.getAttribute(Ze)||q.getAttribute("custom-slides-role");he&&he!==J&&et(ie,{[Ze]:J})}}const _=!!a.querySelector("img, span[data-type='img']"),N=(a.innerText||"").replace(/[\r\n\t\s]+/g," ").trim(),k=_&&N.length<=50;Ji({id:r,rootId:s,type:l,content:v,attrs:y,isDivider:h,isCode:f,isImage:k,topBlockId:d,pageDividerId:x,pageDividerLayout:S,parentContainerId:L,parentContainerSlot:z,parentContainerClicks:H})}patchThematicBreakTransactions(t){if((t==null?void 0:t.cmd)==="transactions"&&Array.isArray(t.data)){for(const i of t.data)if(Array.isArray(i==null?void 0:i.doOperations)){for(const n of i.doOperations)if((n==null?void 0:n.action)==="updateAttrs"&&n.id&&n.data){const s=n.data.old||{},o=n.data.new||{},a={};for(const r of Object.keys(s))r in o||(a[r]="");for(const[r,l]of Object.entries(o))a[r]=String(l??"");et(n.id,a),De.setBlockAttrOverride(n.id,a)}}}}purgeStaleDomSlidesAttrs(t){var s,o,a;if(typeof document>"u"||!t)return;const i=new Map;if(Array.isArray(t.slides))for(const r of t.slides){if(r.startBlockId){const l=i.get(r.startBlockId)||{};(s=r.frontmatter)!=null&&s.layout&&(l[Se]=r.frontmatter.layout),i.set(r.startBlockId,l)}if(Array.isArray(r.blocks)){for(const l of r.blocks)if(l.id){const c=i.get(l.id)||{};(o=l.ial)!=null&&o[Se]&&(c[Se]=l.ial[Se]),(a=l.ial)!=null&&a[Ze]&&(c[Ze]=l.ial[Ze]),Object.keys(c).length>0&&i.set(l.id,c)}}}const n=De.getAllAttrOverrides();for(const[r,l]of n.entries()){const c=i.get(r)||{};l[Se]!==void 0&&(c[Se]=l[Se]),l[Ze]!==void 0&&(c[Ze]=l[Ze]),i.set(r,c)}rw(i)}}const ki=new e2;class t2{constructor(){ye(this,"state","IDLE");ye(this,"inFlightDocId",null);ye(this,"pendingDocs",new Set);ye(this,"lastPendingDocId",null);ye(this,"generation",0)}get currentState(){return this.state}get isRunning(){return this.state==="COMPILING"}get runningDocId(){return this.inFlightDocId}get pending(){return this.lastPendingDocId}get pendingList(){return Array.from(this.pendingDocs)}tryBegin(t){return this.state==="COMPILING"||this.inFlightDocId!==null?(this.pendingDocs.add(t),this.lastPendingDocId=t,null):(this.state="COMPILING",this.inFlightDocId=t,++this.generation)}isStale(t){return t!==this.generation}finishBatch(){this.state="IDLE",this.inFlightDocId=null,this.lastPendingDocId=null;const t=Array.from(this.pendingDocs);return this.pendingDocs.clear(),t}finish(){const t=this.finishBatch();return t.length>0?t[t.length-1]:null}reset(){this.state="IDLE",this.inFlightDocId=null,this.pendingDocs.clear(),this.lastPendingDocId=null,this.generation=0}}const i2=150,n2=`<symbol id="iconSlides" viewBox="0 0 1024 1024">
  <path fill="currentColor" d="M128 160h768c35.3 0 64 28.7 64 64v480c0 35.3-28.7 64-64 64H128c-35.3 0-64-28.7-64-64V224c0-35.3 28.7-64 64-64z m64 64v480h640V224H192z m128 640h384v64H320z"/>
  <path fill="currentColor" d="M416 336l256 144-256 144z"/>
</symbol>`,s2="slides-dock",vo="slides-preview-tab",ha="slides-presenter-tab",ma=jf;class o2 extends ue.Plugin{constructor(){super(...arguments);ye(this,"isMobile",!1);ye(this,"currentDocId","");ye(this,"previewTab",null);ye(this,"latestCompiledDoc",null);ye(this,"cliBridge",new ur);ye(this,"debounceTimer",null);ye(this,"activeCursorBlockId","");ye(this,"cancelledCursorBlockId","");ye(this,"compileScheduler",new t2);ye(this,"dirtyDocId",null);ye(this,"inspectorSyncThrottle",new Qw);ye(this,"onSwitchProtyleBound",this.onSwitchProtyle.bind(this));ye(this,"onWsMainBound",this.onWsMain.bind(this));ye(this,"onBlockClickedBound",this.onBlockClickedFromSlide.bind(this));ye(this,"onEditorClickBound",this.onEditorClick.bind(this));ye(this,"onSelectionChangeBound",this.onSelectionChange.bind(this));ye(this,"onClickEditorContentBound",this.onClickEditorContent.bind(this));ye(this,"onVisibilityChangeBound",this.onVisibilityChange.bind(this))}async onload(){const i=ue.getFrontend();this.isMobile=i==="mobile"||i==="browser-mobile",await this.loadGlobalSettings(),this.addIcons(n2),this.addTopBar({id:"slides-topbar-play",icon:"iconSlides",title:"即现演示",position:"right",callback:()=>{this.openBottomPreviewTab()}}),Zw(this);const n=this;if(this.addTab({type:vo,init(s){var r;const o=this||s;n.previewTab=(o==null?void 0:o.tab)||null,jw(o.element,n);const a=(r=o==null?void 0:o.data)==null?void 0:r.docId;a&&!n.getActiveDocumentId()&&n.compileCurrentDocument(a,{reason:"explicit"}),n.updatePreviewTabHeader()},destroy(){n.previewTab===(this==null?void 0:this.tab)&&(n.previewTab=null),dc(this.element)}}),this.addTab({type:ha,init(s){Uw((this||s).element,n)},destroy(){uc(this.element)}}),this.addDock({config:{position:"RightTop",size:{width:320,height:0},icon:"iconSlides",title:"即现演示配置"},data:{},type:s2,init(){Gw(this.element,n)},destroy(){fc(this.element)}}),this.eventBus&&typeof this.eventBus.emit!="function"&&(this.eventBus.emit=(s,o)=>{try{typeof window<"u"&&window.dispatchEvent(new CustomEvent(`siyuan-event-${s}`,{detail:o}))}catch{}}),this.eventBus.on("switch-protyle",this.onSwitchProtyleBound),this.eventBus.on("ws-main",this.onWsMainBound),this.eventBus.on("slides:request-compile",()=>this.compileCurrentDocument()),this.eventBus.on("slides:block-clicked",this.onBlockClickedBound),this.eventBus.on("click-editorcontent",this.onClickEditorContentBound),typeof document<"u"&&(document.addEventListener("click",this.onEditorClickBound,!0),document.addEventListener("selectionchange",this.onSelectionChangeBound),document.addEventListener("visibilitychange",this.onVisibilityChangeBound)),typeof document<"u"){const s=()=>{const o=this.getActiveDocumentId();o&&(o!==this.currentDocId&&(this.currentDocId=o,this.updatePreviewTabHeader("",o)),this.latestCompiledDoc||this.markCompileDirty(o))};setTimeout(s,300),setTimeout(s,1e3)}}async onDataChanged(i){await this.loadGlobalSettings(),this.currentDocId&&this.markCompileDirty(this.currentDocId)}async loadGlobalSettings(){try{const i=await this.loadData(ma),n=Wf(i);return oi(n),n}catch{return oi($i),$i}}async saveGlobalSettings(i){const n=qs(),s=oi({...n,...i||{}});try{await this.saveData(ma,s)}catch(a){console.error("保存即现全局配置失败",a)}const o=this.currentDocId||this.getActiveDocumentId();return o&&this.markCompileDirty(o),s}onunload(){this.debounceTimer&&(window.clearTimeout(this.debounceTimer),this.debounceTimer=null),this.compileScheduler.reset(),this.inspectorSyncThrottle.reset(),this.dirtyDocId=null,bs.clear(),this.eventBus.off("switch-protyle",this.onSwitchProtyleBound),this.eventBus.off("ws-main",this.onWsMainBound),this.eventBus.off("click-editorcontent",this.onClickEditorContentBound),typeof document<"u"&&(document.removeEventListener("click",this.onEditorClickBound,!0),document.removeEventListener("selectionchange",this.onSelectionChangeBound),document.removeEventListener("visibilitychange",this.onVisibilityChangeBound)),bn.detach()}onVisibilityChange(){typeof document<"u"&&document.visibilityState==="visible"&&this.flushDirtyCompile()}async openBottomPreviewTab(){this.currentDocId||(this.currentDocId=this.getActiveDocumentId());const i=this.currentDocId?await this.fetchDocumentTitle(this.currentDocId):"",n=this.buildPreviewTabTitle(i);await ue.openTab({app:this.app,custom:{id:this.name+vo,title:n,icon:"iconSlides",data:{docId:this.currentDocId}},position:"bottom"}),this.currentDocId&&this.compileCurrentDocument(this.currentDocId),this.updatePreviewTabHeader(i,this.currentDocId)}async openPresenterTab(){ri("presenterMode")||(Ww()||await this.openBottomPreviewTab(),await ue.openTab({app:this.app,custom:{id:this.name+ha,title:"演讲者控制台",icon:"iconSlides",data:{}},position:"right"}))}async openStandalonePreviewWindow(){this.currentDocId||(this.currentDocId=this.getActiveDocumentId()),this.currentDocId&&!this.latestCompiledDoc&&await this.compileCurrentDocument(this.currentDocId,{reason:"explicit"});const i=ue.getFrontend();if(i==="browser-desktop"||i==="browser-mobile"){typeof window<"u"&&typeof window.open=="function"&&window.open("/plugins/siyuan-live-slides/slides-client/index.html","SlidesBigScreenWindow","width=1280,height=760,menubar=no,toolbar=no,location=no,status=no");return}let n=this.previewTab;if(!n){const s=this.currentDocId?await this.fetchDocumentTitle(this.currentDocId):"",o=this.buildPreviewTabTitle(s),a=await ue.openTab({app:this.app,custom:{id:this.name+vo,title:o,icon:"iconSlides",data:{docId:this.currentDocId}},position:"bottom"});n=this.previewTab||a}n&&(this.currentDocId&&n.model&&(n.model.data={...n.model.data||{},docId:this.currentDocId}),ue.openWindow({tab:n,width:1280,height:760}))}async onSwitchProtyle(i){var a,r,l,c,u;const n=(a=i.detail)==null?void 0:a.protyle,s=(r=n==null?void 0:n.block)==null?void 0:r.rootID,o=((u=(c=(l=n==null?void 0:n.title)==null?void 0:l.editElement)==null?void 0:c.textContent)==null?void 0:u.trim())||"";if(s&&s!==this.currentDocId){this.cancelledCursorBlockId="",this.currentDocId=s,this.activeCursorBlockId=s;const d=await jo(s).catch(()=>({}));Ji({id:s,rootId:s,type:"doc",attrs:d}),this.markCompileDirty(s),this.updatePreviewTabHeader(o,s)}}onClickEditorContent(i){var o,a;const n=i==null?void 0:i.detail;if(!n)return;const s=(a=(o=n.protyle)==null?void 0:o.block)==null?void 0:a.rootID;s&&(!this.currentDocId||this.currentDocId!==s)&&(this.currentDocId=s),n.event&&this.onEditorClick(n.event)}buildPreviewTabTitle(i){return Zl(i)}async fetchDocumentTitle(i){return Jl(this,i)}async updatePreviewTabHeader(i,n){return mg(this,i,n)}getActiveDocumentId(){return ki.getActiveDocumentId()}resolveDocIdFromElement(i){return ki.resolveDocIdFromElement(i,this.currentDocId)}async switchToDocGlobalInspector(i,n){i&&(this.activeCursorBlockId=i,this.currentDocId=i,await ki.switchToDocGlobalInspector(i,n))}onWsMain(i){const n=i.detail;n&&n.cmd==="transactions"&&(ki.patchThematicBreakTransactions(n),this.markCompileDirty())}markCompileDirty(i){const n=i||this.currentDocId||this.getActiveDocumentId();n&&(this.currentDocId||(this.currentDocId=n),this.dirtyDocId=n,this.scheduleDirtyCompile())}scheduleDirtyCompile(i=i2){if(this.debounceTimer&&(window.clearTimeout(this.debounceTimer),this.debounceTimer=null),!this.dirtyDocId)return;const n=bs.getVisibility();if(n==="none")return;const s=n==="visible"?i:Math.max(i,Rw);this.debounceTimer=window.setTimeout(()=>{this.debounceTimer=null;const o=this.dirtyDocId;this.dirtyDocId=null,o&&this.compileCurrentDocument(o,{reason:"auto"})},s)}flushDirtyCompile(){this.dirtyDocId&&this.scheduleDirtyCompile(0)}handleBlockClickedFromSlide(i,n){return i?(this.cancelledCursorBlockId="",this.activeCursorBlockId=i):(this.cancelledCursorBlockId=this.activeCursorBlockId,this.activeCursorBlockId=""),ki.handleBlockClickedFromSlide(i,this.app,this.currentDocId,this.latestCompiledDoc,n)}onBlockClickedFromSlide(i){const n=(i==null?void 0:i.detail)||i;n!=null&&n.blockId&&this.handleBlockClickedFromSlide(n.blockId,n.page)}onEditorClick(i){const n=i.target;if(!n)return;const s=n.closest(".protyle-title")||n.closest(".protyle-background");if(!!(s||n.closest(".protyle-content")&&!n.closest(".protyle-wysiwyg")&&!n.closest(".protyle-breadcrumb")&&!n.closest(".protyle-gutters"))){const u=this.resolveDocIdFromElement(n);if(u&&this.activeCursorBlockId!==u){const d=s||document.querySelector(`.protyle-title[data-node-id="${u}"]`)||document.querySelector(`.protyle[data-doc-id="${u}"] .protyle-title`),h=d==null?void 0:d.querySelector(".protyle-title__input"),f=((h==null?void 0:h.innerText)||(d==null?void 0:d.innerText)||"").trim();this.switchToDocGlobalInspector(u,f)}return}if(!n.closest(".protyle-wysiwyg"))return;const r=n.closest("[data-node-id]");if(!r)return;const l=r.getAttribute("data-node-id"),c=r.getAttribute("data-type")||"";l&&(this.cancelledCursorBlockId="",this.currentDocId||(this.currentDocId=this.resolveDocIdFromElement(n)||""),this.currentDocId&&!this.latestCompiledDoc&&this.markCompileDirty(this.currentDocId),l!==this.activeCursorBlockId&&(this.activeCursorBlockId=l,Fo(l)),this.syncInspectorBlock(r,l,c))}onSelectionChange(){if(typeof window>"u")return;const i=window.getSelection();if(!i||i.rangeCount===0)return;const n=i.anchorNode;if(!n)return;const s=n.nodeType===Node.ELEMENT_NODE?n:n.parentElement;if(!s)return;const o=s.closest(".protyle-title");if(!!(o||s.closest(".protyle-content")&&!s.closest(".protyle-wysiwyg"))){const u=this.resolveDocIdFromElement(s);if(u&&this.activeCursorBlockId!==u){const d=o||document.querySelector(`.protyle-title[data-node-id="${u}"]`)||document.querySelector(`.protyle[data-doc-id="${u}"] .protyle-title`),h=d==null?void 0:d.querySelector(".protyle-title__input"),f=((h==null?void 0:h.innerText)||(d==null?void 0:d.innerText)||"").trim();this.switchToDocGlobalInspector(u,f)}return}if(!s.closest(".protyle-wysiwyg"))return;const r=s.closest("[data-node-id]"),l=r==null?void 0:r.getAttribute("data-node-id"),c=(r==null?void 0:r.getAttribute("data-type"))||"";if(r&&l){if(ki.isLocatingLocked(l))return;if(this.currentDocId||(this.currentDocId=this.resolveDocIdFromElement(s)||""),this.currentDocId&&!this.latestCompiledDoc&&this.markCompileDirty(this.currentDocId),l!==this.activeCursorBlockId){if(l===this.cancelledCursorBlockId)return;this.activeCursorBlockId=l,Fo(l)}this.syncInspectorBlock(r,l,c)}}async syncInspectorBlock(i,n,s){this.inspectorSyncThrottle.shouldSkip(n)||await ki.syncInspectorBlock(i,n,s,this.currentDocId,this.latestCompiledDoc)}async compileCurrentDocument(i,n){const s=(n==null?void 0:n.reason)??"explicit";let o=i||this.currentDocId;if(!o){const r=this.getActiveDocumentId();if(r)this.currentDocId=r,o=r;else return}if(s==="auto"&&bs.getVisibility()==="none"){this.dirtyDocId=o;return}const a=this.compileScheduler.tryBegin(o);if(a!==null){this.dirtyDocId===o&&(this.dirtyDocId=null);try{const r=await De.compile(o),l=!!this.currentDocId&&o!==this.currentDocId;!this.compileScheduler.isStale(a)&&!l&&(this.currentDocId||(this.currentDocId=o),this.latestCompiledDoc=r,Kw(r,o),this.updatePreviewTabHeader("",o),this.purgeStaleDomSlidesAttrs(r))}catch(r){console.error("[SiYuanLiveSlides] Failed to compile document:",r)}finally{const r=this.compileScheduler.finishBatch(),l=r.length>0?r[0]:this.compileScheduler.finish();l&&this.markCompileDirty(l);for(let c=1;c<r.length;c++)this.markCompileDirty(r[c])}}}purgeStaleDomSlidesAttrs(i){ki.purgeStaleDomSlidesAttrs(i)}}module.exports=o2;
