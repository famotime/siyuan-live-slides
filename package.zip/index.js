"use strict";var nd=Object.create;var Xs=Object.defineProperty;var sd=Object.getOwnPropertyDescriptor;var od=Object.getOwnPropertyNames;var rd=Object.getPrototypeOf,ad=Object.prototype.hasOwnProperty;var ld=(e,t,i)=>t in e?Xs(e,t,{enumerable:!0,configurable:!0,writable:!0,value:i}):e[t]=i;var cd=(e,t,i,n)=>{if(t&&typeof t=="object"||typeof t=="function")for(let s of od(t))!ad.call(e,s)&&s!==i&&Xs(e,s,{get:()=>t[s],enumerable:!(n=sd(t,s))||n.enumerable});return e};var is=(e,t,i)=>(i=e!=null?nd(rd(e)):{},cd(t||!e||!e.__esModule?Xs(i,"default",{value:e,enumerable:!0}):i,e));var be=(e,t,i)=>ld(e,typeof t!="symbol"?t+"":t,i);const ce=require("siyuan");async function yt(e,t){const i=await ce.fetchSyncPost(e,t);return i.code===0?i.data:null}async function dd(){return yt("/api/notebook/lsNotebooks","")}async function ud(e,t,i){return yt("/api/filetree/createDocWithMd",{notebook:e,path:t,markdown:i})}async function ya(e,t){const i=new FormData;i.append("assetsDirPath",e);for(const s of t)i.append("file[]",s);return yt("/api/asset/upload",i)}async function zi(e,t,i,n,s){return yt("/api/block/insertBlock",{dataType:e,data:t,nextID:i,previousID:n,parentID:s})}async function yo(e,t,i){return yt("/api/block/appendBlock",{dataType:e,data:t,parentID:i})}async function ko(e,t,i){return yt("/api/block/updateBlock",{dataType:e,data:t,id:i})}async function ka(e){return yt("/api/block/deleteBlock",{id:e})}async function fd(e){return yt("/api/block/getBlockKramdown",{id:e})}async function Yn(e){return yt("/api/block/getChildBlocks",{id:e})}async function pd(e){return yt("/api/block/getDocBlocksOrders",{id:e})}async function Fe(e,t){return yt("/api/attr/setBlockAttrs",{id:e,attrs:t})}async function Wo(e){return yt("/api/attr/getBlockAttrs",{id:e})}async function un(e){return yt("/api/query/sql",{stmt:e})}async function wo(e,t,i){const n=new FormData;return n.append("path",e),n.append("isDir",t.toString()),n.append("modTime",Math.floor(Date.now()/1e3).toString()),n.append("file",i),yt("/api/file/putFile",n)}async function wa(e){const t="/api/ai/chatGPT";try{const i=await yt(t,{msg:e});return typeof i=="string"&&i.trim().length>0?i.trim():i&&typeof i.content=="string"&&i.content.trim().length>0?i.content.trim():null}catch{return null}}async function hd(){return yt("/api/storage/getInlineStyles","")}function xr(e){return e.markdown&&e.markdown.trim()?e.markdown.trim():e.content&&e.content.trim()?e.content.trim():""}function xa(e){const t={};if(!e)return t;const i=e.replace(/^\{:\s*/,"").replace(/\s*\}$/,""),n=/([\w-]+)=(?:"([^"]*)"|'([^']*)'|(\S+))/g;let s;for(;(s=n.exec(i))!==null;){const o=s[1],a=s[2]??s[3]??s[4]??"";t[o]=a}return t}const Sa=/\(\(([0-9a-zA-Z-]+)(?:\s*(?:'([^']*)'|"([^"]*)"|([^\)]+?)))?\s*\)\)/g;function md(e){const t=[];if(!e)return t;const i=new RegExp(Sa.source,"g");let n;for(;(n=i.exec(e))!==null;){const s=n[2]??n[3]??n[4];t.push({fullMatch:n[0],blockId:n[1],anchorText:s?s.trim():void 0})}return t}function gd(e,t){if(!e)return"";const i=new RegExp(Sa.source,"g");return e.replace(i,(n,s,o,a,r)=>{const l=(o??a??r??"").trim();if(t&&t[s]){const d=t[s].trim();return`<div class="slides-block-ref" data-ref-id="${s}">${d}</div>`}const c=l||`Ref(${s.slice(0,8)})`;return`<a href="siyuan://blocks/${s}" data-ref-id="${s}" class="slides-ref-tag">🔗 ${c}</a>`})}const Nn="custom-slides-theme",zn="custom-slides-aspect-ratio",Ca="custom-slides-highlighter",Hn="custom-slides-default-transition",_a="custom-slides-color-schema",xo="custom-slides-spacing",ws="custom-slides-background",Sr="custom-slides-show-unordered-list-markers",Cr="custom-slides-show-ordered-list-markers",Ri="custom-slides-slide",ke="custom-slides-layout",gt="custom-slides-transition",st="custom-slides-background",Rt="custom-slides-image",Qs="custom-slides-notes",en="custom-slides-class",Mn="custom-slides-spacing",vt="custom-slides-layout-ratio",tn="custom-slides-mask",Fi="custom-slides-mask-ratio",nn="custom-slides-mask-style",sn="custom-slides-mask-initial",Ne="custom-slides-click",Xt="custom-slides-motion",Gi="custom-slides-shiki-lines",Me="custom-slides-slot",qe="custom-slides-note",Ze="custom-slides-role",Fn="custom-slides-max-height",Ni="custom-slides-autoplay",xs="custom-slides-loop",Qi="custom-slides-muted",Ss="custom-slides-controls",$a="background",Cs="image-left",_s="image-right";function on(e){return e==="cols-header"||e==="two-cols-header"||e==="three-cols-header"}function vd(e,t=2){const i=t===4?[25,50,75,100]:[50,100],n=t===4?4:2;if(!e||typeof e!="string")return{steps:n,breakpoints:i};const s=e.trim();if(!s||t===4&&(s==="1:1"||s==="1"))return{steps:n,breakpoints:i};const o=s.split(":").map(u=>parseFloat(u.trim())).filter(u=>!isNaN(u)&&u>0);if(o.length===0)return{steps:n,breakpoints:i};if(o.length===1){const u=Math.min(100,Math.max(1,o[0]));return u===100?{steps:1,breakpoints:[100]}:{steps:2,breakpoints:[Math.round(u*100)/100,100]}}const a=o.every((u,f)=>f===0||u>o[f-1]),r=o[o.length-1];if(a&&(r===100||o.some(u=>u>10))){const u=o.map(f=>Math.min(100,Math.round(f*100)/100));return u[u.length-1]<100&&u.push(100),{steps:u.length,breakpoints:u}}const c=o.reduce((u,f)=>u+f,0);if(c<=0)return{steps:n,breakpoints:i};let d=0;const p=[];for(let u=0;u<o.length;u++)d+=o[u],u===o.length-1?p.push(100):p.push(Math.round(d/c*1e4)/100);return{steps:p.length,breakpoints:p}}function Ia(e){if(!e)return!1;const t=e.trim();return t.startsWith("assets/")||t.startsWith("./assets/")||t.startsWith("/assets/")}function Ma(e){const t=e.trim();return t.startsWith("./assets/")?t.slice(2):t.startsWith("/assets/")?t.slice(1):t}function _t(e,t){if(!Ia(e))return e;const i=Ma(e);return t!=null&&t.base64Map&&t.base64Map[i]?t.base64Map[i]:t!=null&&t.baseUrl?`${t.baseUrl.replace(/\/+$/,"")}/${i}`:`/${i}`}function bd(e,t){if(!e)return"";let i=e;return i=i.replace(/!\[(.*?)\]\(((?:\.\/|\/)?assets\/[^\s)]+)\)/g,(n,s,o)=>{const a=_t(o,t);return`![${s}](${a})`}),i=i.replace(/(<(?:img|video|audio|source)\b[^>]*?\bsrc=["'])((?:\.\/|\/)?assets\/[^"']+)(["'][^>]*>)/gi,(n,s,o,a)=>{const r=_t(o,t);return`${s}${r}${a}`}),i=i.replace(/(url\(\s*["']?)((?:\.\/|\/)?assets\/[^"')]+)(["']?\s*\))/gi,(n,s,o,a)=>{const r=_t(o,t);return`${s}${r}${a}`}),i}/**
* @vue/shared v3.5.40
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/function Uo(e){const t=Object.create(null);for(const i of e.split(","))t[i]=1;return i=>i in t}const Je={},rn=[],Qt=()=>{},Ta=()=>!1,Ps=e=>e.charCodeAt(0)===111&&e.charCodeAt(1)===110&&(e.charCodeAt(2)>122||e.charCodeAt(2)<97),Os=e=>e.startsWith("onUpdate:"),ut=Object.assign,Vo=(e,t)=>{const i=e.indexOf(t);i>-1&&e.splice(i,1)},yd=Object.prototype.hasOwnProperty,Ve=(e,t)=>yd.call(e,t),Ee=Array.isArray,an=e=>Zn(e)==="[object Map]",mn=e=>Zn(e)==="[object Set]",_r=e=>Zn(e)==="[object Date]",Be=e=>typeof e=="function",nt=e=>typeof e=="string",Ht=e=>typeof e=="symbol",Ye=e=>e!==null&&typeof e=="object",Ea=e=>(Ye(e)||Be(e))&&Be(e.then)&&Be(e.catch),Aa=Object.prototype.toString,Zn=e=>Aa.call(e),kd=e=>Zn(e).slice(8,-1),Ba=e=>Zn(e)==="[object Object]",Go=e=>nt(e)&&e!=="NaN"&&e[0]!=="-"&&""+parseInt(e,10)===e,Tn=Uo(",key,ref,ref_for,ref_key,onVnodeBeforeMount,onVnodeMounted,onVnodeBeforeUpdate,onVnodeUpdated,onVnodeBeforeUnmount,onVnodeUnmounted"),Rs=e=>{const t=Object.create(null);return(i=>t[i]||(t[i]=e(i)))},wd=/-\w/g,St=Rs(e=>e.replace(wd,t=>t.slice(1).toUpperCase())),xd=/\B([A-Z])/g,Ei=Rs(e=>e.replace(xd,"-$1").toLowerCase()),Ns=Rs(e=>e.charAt(0).toUpperCase()+e.slice(1)),eo=Rs(e=>e?`on${Ns(e)}`:""),qt=(e,t)=>!Object.is(e,t),us=(e,...t)=>{for(let i=0;i<e.length;i++)e[i](...t)},Da=(e,t,i,n=!1)=>{Object.defineProperty(e,t,{configurable:!0,enumerable:!1,writable:n,value:i})},zs=e=>{const t=parseFloat(e);return isNaN(t)?e:t};let $r;const Hs=()=>$r||($r=typeof globalThis<"u"?globalThis:typeof self<"u"?self:typeof window<"u"?window:typeof global<"u"?global:{});function Yt(e){if(Ee(e)){const t={};for(let i=0;i<e.length;i++){const n=e[i],s=nt(n)?$d(n):Yt(n);if(s)for(const o in s)t[o]=s[o]}return t}else if(nt(e)||Ye(e))return e}const Sd=/;(?![^(]*\))/g,Cd=/:([^]+)/,_d=/\/\*[^]*?\*\//g;function $d(e){const t={};return e.replace(_d,"").split(Sd).forEach(i=>{if(i){const n=i.split(Cd);n.length>1&&(t[n[0].trim()]=n[1].trim())}}),t}function Ce(e){let t="";if(nt(e))t=e;else if(Ee(e))for(let i=0;i<e.length;i++){const n=Ce(e[i]);n&&(t+=n+" ")}else if(Ye(e))for(const i in e)e[i]&&(t+=i+" ");return t.trim()}const Id="itemscope,allowfullscreen,formnovalidate,ismap,nomodule,novalidate,readonly",Md=Uo(Id);function La(e){return!!e||e===""}function Td(e,t){if(e.length!==t.length)return!1;let i=!0;for(let n=0;i&&n<e.length;n++)i=gn(e[n],t[n]);return i}function gn(e,t){if(e===t)return!0;let i=_r(e),n=_r(t);if(i||n)return i&&n?e.getTime()===t.getTime():!1;if(i=Ht(e),n=Ht(t),i||n)return e===t;if(i=Ee(e),n=Ee(t),i||n)return i&&n?Td(e,t):!1;if(i=Ye(e),n=Ye(t),i||n){if(!i||!n)return!1;const s=Object.keys(e).length,o=Object.keys(t).length;if(s!==o)return!1;for(const a in e){const r=e.hasOwnProperty(a),l=t.hasOwnProperty(a);if(r&&!l||!r&&l||!gn(e[a],t[a]))return!1}}return String(e)===String(t)}function Ko(e,t){return e.findIndex(i=>gn(i,t))}const Pa=e=>!!(e&&e.__v_isRef===!0),we=e=>nt(e)?e:e==null?"":Ee(e)||Ye(e)&&(e.toString===Aa||!Be(e.toString))?Pa(e)?we(e.value):JSON.stringify(e,Oa,2):String(e),Oa=(e,t)=>Pa(t)?Oa(e,t.value):an(t)?{[`Map(${t.size})`]:[...t.entries()].reduce((i,[n,s],o)=>(i[to(n,o)+" =>"]=s,i),{})}:mn(t)?{[`Set(${t.size})`]:[...t.values()].map(i=>to(i))}:Ht(t)?to(t):Ye(t)&&!Ee(t)&&!Ba(t)?String(t):t,to=(e,t="")=>{var i;return Ht(e)?`Symbol(${(i=e.description)!=null?i:t})`:e};/**
* @vue/reactivity v3.5.40
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/let ct;class Ed{constructor(t=!1){this.detached=t,this._active=!0,this._on=0,this.effects=[],this.cleanups=[],this._isPaused=!1,this._warnOnRun=!0,this.__v_skip=!0,!t&&ct&&(ct.active?(this.parent=ct,this.index=(ct.scopes||(ct.scopes=[])).push(this)-1):(this._active=!1,this._warnOnRun=!1))}get active(){return this._active}pause(){if(this._active){this._isPaused=!0;let t,i;if(this.scopes){const n=this.scopes.slice();for(t=0,i=n.length;t<i;t++)n[t].pause()}for(t=0,i=this.effects.length;t<i;t++)this.effects[t].pause()}}resume(){if(this._active&&this._isPaused){this._isPaused=!1;let t,i;if(this.scopes){const s=this.scopes.slice();for(t=0,i=s.length;t<i;t++)s[t].resume()}const n=this.effects.slice();for(t=0,i=n.length;t<i;t++)n[t].resume()}}run(t){if(this._active){const i=ct;try{return ct=this,t()}finally{ct=i}}}on(){++this._on===1&&(this.prevScope=ct,ct=this)}off(){if(this._on>0&&--this._on===0){if(ct===this)ct=this.prevScope;else{let t=ct;for(;t;){if(t.prevScope===this){t.prevScope=this.prevScope;break}t=t.prevScope}}this.prevScope=void 0}}stop(t){if(this._active){this._active=!1;let i,n;for(i=0,n=this.effects.length;i<n;i++)this.effects[i].stop();for(this.effects.length=0,i=0,n=this.cleanups.length;i<n;i++)this.cleanups[i]();if(this.cleanups.length=0,this.scopes){const s=this.scopes.slice();for(i=0,n=s.length;i<n;i++)s[i].stop(!0);this.scopes.length=0}if(!this.detached&&this.parent&&!t){const s=this.parent.scopes.pop();s&&s!==this&&(this.parent.scopes[this.index]=s,s.index=this.index)}this.parent=void 0}}}function Ad(){return ct}let Qe;const io=new WeakSet;class Ra{constructor(t){this.fn=t,this.deps=void 0,this.depsTail=void 0,this.flags=5,this.next=void 0,this.cleanup=void 0,this.scheduler=void 0,ct&&(ct.active?ct.effects.push(this):this.flags&=-2)}pause(){this.flags|=64}resume(){this.flags&64&&(this.flags&=-65,io.has(this)&&(io.delete(this),this.trigger()))}notify(){this.flags&2&&!(this.flags&32)||this.flags&8||za(this)}run(){if(!(this.flags&1))return this.fn();this.flags|=2,Ir(this),Ha(this);const t=Qe,i=Nt;Qe=this,Nt=!0;try{return this.fn()}finally{Fa(this),Qe=t,Nt=i,this.flags&=-3}}stop(){if(this.flags&1){for(let t=this.deps;t;t=t.nextDep)Zo(t);this.deps=this.depsTail=void 0,Ir(this),this.onStop&&this.onStop(),this.flags&=-2}}trigger(){this.flags&64?io.add(this):this.scheduler?this.scheduler():this.runIfDirty()}runIfDirty(){So(this)&&this.run()}get dirty(){return So(this)}}let Na=0,En,An;function za(e,t=!1){if(e.flags|=8,t){e.next=An,An=e;return}e.next=En,En=e}function qo(){Na++}function Yo(){if(--Na>0)return;if(An){let t=An;for(An=void 0;t;){const i=t.next;t.next=void 0,t.flags&=-9,t=i}}let e;for(;En;){let t=En;for(En=void 0;t;){const i=t.next;if(t.next=void 0,t.flags&=-9,t.flags&1)try{t.trigger()}catch(n){e||(e=n)}t=i}}if(e)throw e}function Ha(e){for(let t=e.deps;t;t=t.nextDep)t.version=-1,t.prevActiveLink=t.dep.activeLink,t.dep.activeLink=t}function Fa(e){let t,i=e.depsTail,n=i;for(;n;){const s=n.prevDep;n.version===-1?(n===i&&(i=s),Zo(n),Bd(n)):t=n,n.dep.activeLink=n.prevActiveLink,n.prevActiveLink=void 0,n=s}e.deps=t,e.depsTail=i}function So(e){for(let t=e.deps;t;t=t.nextDep)if(t.dep.version!==t.version||t.dep.computed&&(ja(t.dep.computed)||t.dep.version!==t.version))return!0;return!!e._dirty}function ja(e){if(e.flags&4&&!(e.flags&16)||(e.flags&=-17,e.globalVersion===jn)||(e.globalVersion=jn,!e.isSSR&&e.flags&128&&(!e.deps&&!e._dirty||!So(e))))return;e.flags|=2;const t=e.dep,i=Qe,n=Nt;Qe=e,Nt=!0;try{Ha(e);const s=e.fn(e._value);(t.version===0||qt(s,e._value))&&(e.flags|=128,e._value=s,t.version++)}catch(s){throw t.version++,s}finally{Qe=i,Nt=n,Fa(e),e.flags&=-3}}function Zo(e,t=!1){const{dep:i,prevSub:n,nextSub:s}=e;if(n&&(n.nextSub=s,e.prevSub=void 0),s&&(s.prevSub=n,e.nextSub=void 0),i.subs===e&&(i.subs=n,!n&&i.computed)){i.computed.flags&=-5;for(let o=i.computed.deps;o;o=o.nextDep)Zo(o,!0)}!t&&!--i.sc&&i.map&&i.map.delete(i.key)}function Bd(e){const{prevDep:t,nextDep:i}=e;t&&(t.nextDep=i,e.prevDep=void 0),i&&(i.prevDep=t,e.nextDep=void 0)}let Nt=!0;const Wa=[];function pi(){Wa.push(Nt),Nt=!1}function hi(){const e=Wa.pop();Nt=e===void 0?!0:e}function Ir(e){const{cleanup:t}=e;if(e.cleanup=void 0,t){const i=Qe;Qe=void 0;try{t()}finally{Qe=i}}}let jn=0;class Dd{constructor(t,i){this.sub=t,this.dep=i,this.version=i.version,this.nextDep=this.prevDep=this.nextSub=this.prevSub=this.prevActiveLink=void 0}}class Jo{constructor(t){this.computed=t,this.version=0,this.activeLink=void 0,this.subs=void 0,this.map=void 0,this.key=void 0,this.sc=0,this.__v_skip=!0}track(t){if(!Qe||!Nt||Qe===this.computed)return;let i=this.activeLink;if(i===void 0||i.sub!==Qe)i=this.activeLink=new Dd(Qe,this),Qe.deps?(i.prevDep=Qe.depsTail,Qe.depsTail.nextDep=i,Qe.depsTail=i):Qe.deps=Qe.depsTail=i,Ua(i);else if(i.version===-1&&(i.version=this.version,i.nextDep)){const n=i.nextDep;n.prevDep=i.prevDep,i.prevDep&&(i.prevDep.nextDep=n),i.prevDep=Qe.depsTail,i.nextDep=void 0,Qe.depsTail.nextDep=i,Qe.depsTail=i,Qe.deps===i&&(Qe.deps=n)}return i}trigger(t){this.version++,jn++,this.notify(t)}notify(t){qo();try{for(let i=this.subs;i;i=i.prevSub)i.sub.notify()&&i.sub.dep.notify()}finally{Yo()}}}function Ua(e){if(e.dep.sc++,e.sub.flags&4){const t=e.dep.computed;if(t&&!e.dep.subs){t.flags|=20;for(let n=t.deps;n;n=n.nextDep)Ua(n)}const i=e.dep.subs;i!==e&&(e.prevSub=i,i&&(i.nextSub=e)),e.dep.subs=e}}const Co=new WeakMap,ji=Symbol(""),_o=Symbol(""),Wn=Symbol("");function mt(e,t,i){if(Nt&&Qe){let n=Co.get(e);n||Co.set(e,n=new Map);let s=n.get(i);s||(n.set(i,s=new Jo),s.map=n,s.key=i),s.track()}}function li(e,t,i,n,s,o){const a=Co.get(e);if(!a){jn++;return}const r=l=>{l&&l.trigger()};if(qo(),t==="clear")a.forEach(r);else{const l=Ee(e),c=l&&Go(i);if(l&&i==="length"){const d=Number(n);a.forEach((p,u)=>{(u==="length"||u===Wn||!Ht(u)&&u>=d)&&r(p)})}else switch((i!==void 0||a.has(void 0))&&r(a.get(i)),c&&r(a.get(Wn)),t){case"add":l?c&&r(a.get("length")):(r(a.get(ji)),an(e)&&r(a.get(_o)));break;case"delete":l||(r(a.get(ji)),an(e)&&r(a.get(_o)));break;case"set":an(e)&&r(a.get(ji));break}}Yo()}function Zi(e){const t=Ue(e);return t===e?t:(mt(t,"iterate",Wn),Pt(e)?t:t.map(Ft))}function Fs(e){return mt(e=Ue(e),"iterate",Wn),e}function Gt(e,t){return mi(e)?fn(Wi(e)?Ft(t):t):Ft(t)}const Ld={__proto__:null,[Symbol.iterator](){return no(this,Symbol.iterator,e=>Gt(this,e))},concat(...e){return Zi(this).concat(...e.map(t=>Ee(t)?Zi(t):t))},entries(){return no(this,"entries",e=>(e[1]=Gt(this,e[1]),e))},every(e,t){return ni(this,"every",e,t,void 0,arguments)},filter(e,t){return ni(this,"filter",e,t,i=>i.map(n=>Gt(this,n)),arguments)},find(e,t){return ni(this,"find",e,t,i=>Gt(this,i),arguments)},findIndex(e,t){return ni(this,"findIndex",e,t,void 0,arguments)},findLast(e,t){return ni(this,"findLast",e,t,i=>Gt(this,i),arguments)},findLastIndex(e,t){return ni(this,"findLastIndex",e,t,void 0,arguments)},forEach(e,t){return ni(this,"forEach",e,t,void 0,arguments)},includes(...e){return so(this,"includes",e)},indexOf(...e){return so(this,"indexOf",e)},join(e){return Zi(this).join(e)},lastIndexOf(...e){return so(this,"lastIndexOf",e)},map(e,t){return ni(this,"map",e,t,void 0,arguments)},pop(){return xn(this,"pop")},push(...e){return xn(this,"push",e)},reduce(e,...t){return Mr(this,"reduce",e,t)},reduceRight(e,...t){return Mr(this,"reduceRight",e,t)},shift(){return xn(this,"shift")},some(e,t){return ni(this,"some",e,t,void 0,arguments)},splice(...e){return xn(this,"splice",e)},toReversed(){return Zi(this).toReversed()},toSorted(e){return Zi(this).toSorted(e)},toSpliced(...e){return Zi(this).toSpliced(...e)},unshift(...e){return xn(this,"unshift",e)},values(){return no(this,"values",e=>Gt(this,e))}};function no(e,t,i){const n=Fs(e),s=n[t]();return n!==e&&!Pt(e)&&(s._next=s.next,s.next=()=>{const o=s._next();return o.done||(o.value=i(o.value)),o}),s}const Pd=Array.prototype;function ni(e,t,i,n,s,o){const a=Fs(e),r=a!==e&&!Pt(e),l=a[t];if(l!==Pd[t]){const p=l.apply(e,o);return r?Ft(p):p}let c=i;a!==e&&(r?c=function(p,u){return i.call(this,Gt(e,p),u,e)}:i.length>2&&(c=function(p,u){return i.call(this,p,u,e)}));const d=l.call(a,c,n);return r&&s?s(d):d}function Mr(e,t,i,n){const s=Fs(e),o=s!==e&&!Pt(e);let a=i,r=!1;s!==e&&(o?(r=n.length===0,a=function(c,d,p){return r&&(r=!1,c=Gt(e,c)),i.call(this,c,Gt(e,d),p,e)}):i.length>3&&(a=function(c,d,p){return i.call(this,c,d,p,e)}));const l=s[t](a,...n);return r?Gt(e,l):l}function so(e,t,i){const n=Ue(e);mt(n,"iterate",Wn);const s=n[t](...i);return(s===-1||s===!1)&&er(i[0])?(i[0]=Ue(i[0]),n[t](...i)):s}function xn(e,t,i=[]){pi(),qo();const n=Ue(e)[t].apply(e,i);return Yo(),hi(),n}const Od=Uo("__proto__,__v_isRef,__isVue"),Va=new Set(Object.getOwnPropertyNames(Symbol).filter(e=>e!=="arguments"&&e!=="caller").map(e=>Symbol[e]).filter(Ht));function Rd(e){Ht(e)||(e=String(e));const t=Ue(this);return mt(t,"has",e),t.hasOwnProperty(e)}class Ga{constructor(t=!1,i=!1){this._isReadonly=t,this._isShallow=i}get(t,i,n){if(i==="__v_skip")return t.__v_skip;const s=this._isReadonly,o=this._isShallow;if(i==="__v_isReactive")return!s;if(i==="__v_isReadonly")return s;if(i==="__v_isShallow")return o;if(i==="__v_raw")return n===(s?o?Kd:Za:o?Ya:qa).get(t)||Object.getPrototypeOf(t)===Object.getPrototypeOf(n)?t:void 0;const a=Ee(t);if(!s){let l;if(a&&(l=Ld[i]))return l;if(i==="hasOwnProperty")return Rd}const r=Reflect.get(t,i,tt(t)?t:n);if((Ht(i)?Va.has(i):Od(i))||(s||mt(t,"get",i),o))return r;if(tt(r)){const l=a&&Go(i)?r:r.value;return s&&Ye(l)?Io(l):l}return Ye(r)?s?Io(r):js(r):r}}class Ka extends Ga{constructor(t=!1){super(!1,t)}set(t,i,n,s){let o=t[i];const a=Ee(t)&&Go(i);if(!this._isShallow){const c=mi(o);if(!Pt(n)&&!mi(n)&&(o=Ue(o),n=Ue(n)),!a&&tt(o)&&!tt(n))return c||(o.value=n),!0}const r=a?Number(i)<t.length:Ve(t,i),l=Reflect.set(t,i,n,tt(t)?t:s);return t===Ue(s)&&l&&(r?qt(n,o)&&li(t,"set",i,n):li(t,"add",i,n)),l}deleteProperty(t,i){const n=Ve(t,i);t[i];const s=Reflect.deleteProperty(t,i);return s&&n&&li(t,"delete",i,void 0),s}has(t,i){const n=Reflect.has(t,i);return(!Ht(i)||!Va.has(i))&&mt(t,"has",i),n}ownKeys(t){return mt(t,"iterate",Ee(t)?"length":ji),Reflect.ownKeys(t)}}class Nd extends Ga{constructor(t=!1){super(!0,t)}set(t,i){return!0}deleteProperty(t,i){return!0}}const zd=new Ka,Hd=new Nd,Fd=new Ka(!0);const $o=e=>e,ns=e=>Reflect.getPrototypeOf(e);function jd(e,t,i){return function(...n){const s=this.__v_raw,o=Ue(s),a=an(o),r=e==="entries"||e===Symbol.iterator&&a,l=e==="keys"&&a,c=s[e](...n),d=i?$o:t?fn:Ft;return!t&&mt(o,"iterate",l?_o:ji),ut(Object.create(c),{next(){const{value:p,done:u}=c.next();return u?{value:p,done:u}:{value:r?[d(p[0]),d(p[1])]:d(p),done:u}}})}}function ss(e){return function(...t){return e==="delete"?!1:e==="clear"?void 0:this}}function Wd(e,t){const i={get(s){const o=this.__v_raw,a=Ue(o),r=Ue(s);e||(qt(s,r)&&mt(a,"get",s),mt(a,"get",r));const{has:l}=ns(a),c=t?$o:e?fn:Ft;if(l.call(a,s))return c(o.get(s));if(l.call(a,r))return c(o.get(r));o!==a&&o.get(s)},get size(){const s=this.__v_raw;return!e&&mt(Ue(s),"iterate",ji),s.size},has(s){const o=this.__v_raw,a=Ue(o),r=Ue(s);return e||(qt(s,r)&&mt(a,"has",s),mt(a,"has",r)),s===r?o.has(s):o.has(s)||o.has(r)},forEach(s,o){const a=this,r=a.__v_raw,l=Ue(r),c=t?$o:e?fn:Ft;return!e&&mt(l,"iterate",ji),r.forEach((d,p)=>s.call(o,c(d),c(p),a))}};return ut(i,e?{add:ss("add"),set:ss("set"),delete:ss("delete"),clear:ss("clear")}:{add(s){const o=Ue(this),a=ns(o),r=Ue(s),l=!t&&!Pt(s)&&!mi(s)?r:s;return a.has.call(o,l)||qt(s,l)&&a.has.call(o,s)||qt(r,l)&&a.has.call(o,r)||(o.add(l),li(o,"add",l,l)),this},set(s,o){!t&&!Pt(o)&&!mi(o)&&(o=Ue(o));const a=Ue(this),{has:r,get:l}=ns(a);let c=r.call(a,s);c||(s=Ue(s),c=r.call(a,s));const d=l.call(a,s);return a.set(s,o),c?qt(o,d)&&li(a,"set",s,o):li(a,"add",s,o),this},delete(s){const o=Ue(this),{has:a,get:r}=ns(o);let l=a.call(o,s);l||(s=Ue(s),l=a.call(o,s)),r&&r.call(o,s);const c=o.delete(s);return l&&li(o,"delete",s,void 0),c},clear(){const s=Ue(this),o=s.size!==0,a=s.clear();return o&&li(s,"clear",void 0,void 0),a}}),["keys","values","entries",Symbol.iterator].forEach(s=>{i[s]=jd(s,e,t)}),i}function Xo(e,t){const i=Wd(e,t);return(n,s,o)=>s==="__v_isReactive"?!e:s==="__v_isReadonly"?e:s==="__v_raw"?n:Reflect.get(Ve(i,s)&&s in n?i:n,s,o)}const Ud={get:Xo(!1,!1)},Vd={get:Xo(!1,!0)},Gd={get:Xo(!0,!1)};const qa=new WeakMap,Ya=new WeakMap,Za=new WeakMap,Kd=new WeakMap;function qd(e){switch(e){case"Object":case"Array":return 1;case"Map":case"Set":case"WeakMap":case"WeakSet":return 2;default:return 0}}function js(e){return mi(e)?e:Qo(e,!1,zd,Ud,qa)}function Yd(e){return Qo(e,!1,Fd,Vd,Ya)}function Io(e){return Qo(e,!0,Hd,Gd,Za)}function Qo(e,t,i,n,s){if(!Ye(e)||e.__v_raw&&!(t&&e.__v_isReactive)||e.__v_skip||!Object.isExtensible(e))return e;const o=s.get(e);if(o)return o;const a=qd(kd(e));if(a===0)return e;const r=new Proxy(e,a===2?n:i);return s.set(e,r),r}function Wi(e){return mi(e)?Wi(e.__v_raw):!!(e&&e.__v_isReactive)}function mi(e){return!!(e&&e.__v_isReadonly)}function Pt(e){return!!(e&&e.__v_isShallow)}function er(e){return e?!!e.__v_raw:!1}function Ue(e){const t=e&&e.__v_raw;return t?Ue(t):e}function Zd(e){return!Ve(e,"__v_skip")&&Object.isExtensible(e)&&Da(e,"__v_skip",!0),e}const Ft=e=>Ye(e)?js(e):e,fn=e=>Ye(e)?Io(e):e;function tt(e){return e?e.__v_isRef===!0:!1}function ge(e){return Jd(e,!1)}function Jd(e,t){return tt(e)?e:new Xd(e,t)}class Xd{constructor(t,i){this.dep=new Jo,this.__v_isRef=!0,this.__v_isShallow=!1,this._rawValue=i?t:Ue(t),this._value=i?t:Ft(t),this.__v_isShallow=i}get value(){return this.dep.track(),this._value}set value(t){const i=this._rawValue,n=this.__v_isShallow||Pt(t)||mi(t);t=n?t:Ue(t),qt(t,i)&&(this._rawValue=t,this._value=n?t:Ft(t),this.dep.trigger())}}function he(e){return tt(e)?e.value:e}const Qd={get:(e,t,i)=>t==="__v_raw"?e:he(Reflect.get(e,t,i)),set:(e,t,i,n)=>{const s=e[t];return tt(s)&&!tt(i)?(s.value=i,!0):Reflect.set(e,t,i,n)}};function Ja(e){return Wi(e)?e:new Proxy(e,Qd)}class eu{constructor(t,i,n){this.fn=t,this.setter=i,this._value=void 0,this.dep=new Jo(this),this.__v_isRef=!0,this.deps=void 0,this.depsTail=void 0,this.flags=16,this.globalVersion=jn-1,this.next=void 0,this.effect=this,this.__v_isReadonly=!i,this.isSSR=n}notify(){if(this.flags|=16,!(this.flags&8)&&Qe!==this)return za(this,!0),!0}get value(){const t=this.dep.track();return ja(this),t&&(t.version=this.dep.version),this._value}set value(t){this.setter&&this.setter(t)}}function tu(e,t,i=!1){let n,s;return Be(e)?n=e:(n=e.get,s=e.set),new eu(n,s,i)}const os={},$s=new WeakMap;let Oi;function iu(e,t=!1,i=Oi){if(i){let n=$s.get(i);n||$s.set(i,n=[]),n.push(e)}}function nu(e,t,i=Je){const{immediate:n,deep:s,once:o,scheduler:a,augmentJob:r,call:l}=i,c=S=>s?S:Pt(S)||s===!1||s===0?ci(S,1):ci(S);let d,p,u,f,w=!1,m=!1;if(tt(e)?(p=()=>e.value,w=Pt(e)):Wi(e)?(p=()=>c(e),w=!0):Ee(e)?(m=!0,w=e.some(S=>Wi(S)||Pt(S)),p=()=>e.map(S=>{if(tt(S))return S.value;if(Wi(S))return c(S);if(Be(S))return l?l(S,2):S()})):Be(e)?t?p=l?()=>l(e,2):e:p=()=>{if(u){pi();try{u()}finally{hi()}}const S=Oi;Oi=d;try{return l?l(e,3,[f]):e(f)}finally{Oi=S}}:p=Qt,t&&s){const S=p,D=s===!0?1/0:s;p=()=>ci(S(),D)}const y=Ad(),b=()=>{d.stop(),y&&y.active&&Vo(y.effects,d)};if(o&&t){const S=t;t=(...D)=>{const A=S(...D);return b(),A}}let v=m?new Array(e.length).fill(os):os;const k=S=>{if(!(!(d.flags&1)||!d.dirty&&!S))if(t){const D=d.run();if(S||s||w||(m?D.some((A,C)=>qt(A,v[C])):qt(D,v))){u&&u();const A=Oi;Oi=d;try{const C=[D,v===os?void 0:m&&v[0]===os?[]:v,f];v=D,l?l(t,3,C):t(...C)}finally{Oi=A}}}else d.run()};return r&&r(k),d=new Ra(p),d.scheduler=a?()=>a(k,!1):k,f=S=>iu(S,!1,d),u=d.onStop=()=>{const S=$s.get(d);if(S){if(l)l(S,4);else for(const D of S)D();$s.delete(d)}},t?n?k(!0):v=d.run():a?a(k.bind(null,!0),!0):d.run(),b.pause=d.pause.bind(d),b.resume=d.resume.bind(d),b.stop=b,b}function ci(e,t=1/0,i){if(t<=0||!Ye(e)||e.__v_skip||(i=i||new Map,(i.get(e)||0)>=t))return e;if(i.set(e,t),t--,tt(e))ci(e.value,t,i);else if(Ee(e))for(let n=0;n<e.length;n++)ci(e[n],t,i);else if(mn(e)||an(e))e.forEach(n=>{ci(n,t,i)});else if(Ba(e)){for(const n in e)ci(e[n],t,i);for(const n of Object.getOwnPropertySymbols(e))Object.prototype.propertyIsEnumerable.call(e,n)&&ci(e[n],t,i)}return e}/**
* @vue/runtime-core v3.5.40
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/function Jn(e,t,i,n){try{return n?e(...n):e()}catch(s){Ws(s,t,i)}}function jt(e,t,i,n){if(Be(e)){const s=Jn(e,t,i,n);return s&&Ea(s)&&s.catch(o=>{Ws(o,t,i)}),s}if(Ee(e)){const s=[];for(let o=0;o<e.length;o++)s.push(jt(e[o],t,i,n));return s}}function Ws(e,t,i,n=!0){const s=t?t.vnode:null,{errorHandler:o,throwUnhandledErrorInProduction:a}=t&&t.appContext.config||Je;if(t){let r=t.parent;const l=t.proxy,c=`https://vuejs.org/error-reference/#runtime-${i}`;for(;r;){const d=r.ec;if(d){for(let p=0;p<d.length;p++)if(d[p](e,l,c)===!1)return}r=r.parent}if(o){pi(),Jn(o,null,10,[e,l,c]),hi();return}}su(e,i,s,n,a)}function su(e,t,i,n=!0,s=!1){if(s)throw e;console.error(e)}const wt=[];let Ut=-1;const ln=[];let xi=null,Ji=0;const Xa=Promise.resolve();let Is=null;function Ms(e){const t=Is||Xa;return e?t.then(this?e.bind(this):e):t}function ou(e){let t=Ut+1,i=wt.length;for(;t<i;){const n=t+i>>>1,s=wt[n],o=Un(s);o<e||o===e&&s.flags&2?t=n+1:i=n}return t}function tr(e){if(!(e.flags&1)){const t=Un(e),i=wt[wt.length-1];!i||!(e.flags&2)&&t>=Un(i)?wt.push(e):wt.splice(ou(t),0,e),e.flags|=1,Qa()}}function Qa(){Is||(Is=Xa.then(tl))}function ru(e){Ee(e)?ln.push(...e):xi&&e.id===-1?xi.splice(Ji+1,0,e):e.flags&1||(ln.push(e),e.flags|=1),Qa()}function Tr(e,t,i=Ut+1){for(;i<wt.length;i++){const n=wt[i];if(n&&n.flags&2){if(e&&n.id!==e.uid)continue;wt.splice(i,1),i--,n.flags&4&&(n.flags&=-2),n(),n.flags&4||(n.flags&=-2)}}}function el(e){if(ln.length){const t=[...new Set(ln)].sort((i,n)=>Un(i)-Un(n));if(ln.length=0,xi){xi.push(...t);return}for(xi=t,Ji=0;Ji<xi.length;Ji++){const i=xi[Ji];i.flags&4&&(i.flags&=-2),i.flags&8||i(),i.flags&=-2}xi=null,Ji=0}}const Un=e=>e.id==null?e.flags&2?-1:1/0:e.id;function tl(e){try{for(Ut=0;Ut<wt.length;Ut++){const t=wt[Ut];t&&!(t.flags&8)&&(t.flags&4&&(t.flags&=-2),Jn(t,t.i,t.i?15:14),t.flags&4||(t.flags&=-2))}}finally{for(;Ut<wt.length;Ut++){const t=wt[Ut];t&&(t.flags&=-2)}Ut=-1,wt.length=0,el(),Is=null,(wt.length||ln.length)&&tl()}}let dt=null,il=null;function Ts(e){const t=dt;return dt=e,il=e&&e.type.__scopeId||null,t}function nl(e,t=dt,i){if(!t||e._n)return e;const n=(...s)=>{n._d&&Fr(-1);const o=Ts(t),a=di.length;let r;try{r=e(...s)}finally{for(let l=di.length;l>a;l--)rr();Ts(o),n._d&&Fr(1)}return r};return n._n=!0,n._c=!0,n._d=!0,n}function Ot(e,t){if(dt===null)return e;const i=qs(dt),n=e.dirs||(e.dirs=[]);for(let s=0;s<t.length;s++){let[o,a,r,l=Je]=t[s];o&&(Be(o)&&(o={mounted:o,updated:o}),o.deep&&ci(a),n.push({dir:o,instance:i,value:a,oldValue:void 0,arg:r,modifiers:l}))}return e}function Bi(e,t,i,n){const s=e.dirs,o=t&&t.dirs;for(let a=0;a<s.length;a++){const r=s[a];o&&(r.oldValue=o[a].value);let l=r.dir[n];l&&(pi(),jt(l,i,8,[e.el,r,e,t]),hi())}}function au(e,t){if(bt){let i=bt.provides;const n=bt.parent&&bt.parent.provides;n===i&&(i=bt.provides=Object.create(n)),i[e]=t}}function zt(e,t,i=!1){const n=rf();if(n||dn){let s=dn?dn._context.provides:n?n.parent==null||n.ce?n.vnode.appContext&&n.vnode.appContext.provides:n.parent.provides:void 0;if(s&&e in s)return s[e];if(arguments.length>1)return i&&Be(t)?t.call(n&&n.proxy):t}}const lu=Symbol.for("v-scx"),cu=()=>zt(lu);function Ui(e,t,i){return sl(e,t,i)}function sl(e,t,i=Je){const{immediate:n,deep:s,flush:o,once:a}=i,r=ut({},i),l=t&&n||!t&&o!=="post";let c;if(Gn){if(o==="sync"){const f=cu();c=f.__watcherHandles||(f.__watcherHandles=[])}else if(!l){const f=()=>{};return f.stop=Qt,f.resume=Qt,f.pause=Qt,f}}const d=bt;r.call=(f,w,m)=>jt(f,d,w,m);let p=!1;o==="post"?r.scheduler=f=>{Ct(f,d&&d.suspense)}:o!=="sync"&&(p=!0,r.scheduler=(f,w)=>{w?f():tr(f)}),r.augmentJob=f=>{t&&(f.flags|=4),p&&(f.flags|=2,d&&(f.id=d.uid,f.i=d))};const u=nu(e,t,r);return Gn&&(c?c.push(u):l&&u()),u}function du(e,t,i){const n=this.proxy,s=nt(e)?e.includes(".")?ol(n,e):()=>n[e]:e.bind(n,n);let o;Be(t)?o=t:(o=t.handler,i=t);const a=Xn(this),r=sl(s,o.bind(n),i);return a(),r}function ol(e,t){const i=t.split(".");return()=>{let n=e;for(let s=0;s<i.length&&n;s++)n=n[i[s]];return n}}const uu=Symbol("_vte"),fu=e=>e.__isTeleport,oo=Symbol("_leaveCb");function ir(e,t){e.shapeFlag&6&&e.component?(e.transition=t,ir(e.component.subTree,t)):e.shapeFlag&128?(e.ssContent.transition=t.clone(e.ssContent),e.ssFallback.transition=t.clone(e.ssFallback)):e.transition=t}function Dt(e,t){return Be(e)?ut({name:e.name},t,{setup:e}):e}function rl(e){e.ids=[e.ids[0]+e.ids[2]+++"-",0,0]}function Er(e,t){let i;return!!((i=Object.getOwnPropertyDescriptor(e,t))&&!i.configurable)}const Es=new WeakMap;function Bn(e,t,i,n,s=!1){if(Ee(e)){e.forEach((m,y)=>Bn(m,t&&(Ee(t)?t[y]:t),i,n,s));return}if(cn(n)&&!s){n.shapeFlag&512&&n.type.__asyncResolved&&n.component.subTree.component&&Bn(e,t,i,n.component.subTree);return}const o=n.shapeFlag&4?qs(n.component):n.el,a=s?null:o,{i:r,r:l}=e,c=t&&t.r,d=r.refs===Je?r.refs={}:r.refs,p=r.setupState,u=Ue(p),f=p===Je?Ta:m=>Er(d,m)?!1:Ve(u,m),w=(m,y)=>!(y&&Er(d,y));if(c!=null&&c!==l){if(Ar(t),nt(c))d[c]=null,f(c)&&(p[c]=null);else if(tt(c)){const m=t;w(c,m.k)&&(c.value=null),m.k&&(d[m.k]=null)}}if(Be(l))Jn(l,r,12,[a,d]);else{const m=nt(l),y=tt(l);if(m||y){const b=()=>{if(e.f){const v=m?f(l)?p[l]:d[l]:w()||!e.k?l.value:d[e.k];if(s)Ee(v)&&Vo(v,o);else if(Ee(v))v.includes(o)||v.push(o);else if(m)d[l]=[o],f(l)&&(p[l]=d[l]);else{const k=[o];w(l,e.k)&&(l.value=k),e.k&&(d[e.k]=k)}}else m?(d[l]=a,f(l)&&(p[l]=a)):y&&(w(l,e.k)&&(l.value=a),e.k&&(d[e.k]=a))};if(a){const v=()=>{b(),Es.delete(e)};v.id=-1,Es.set(e,v),Ct(v,i)}else Ar(e),b()}}}function Ar(e){const t=Es.get(e);t&&(t.flags|=8,Es.delete(e))}Hs().requestIdleCallback;Hs().cancelIdleCallback;const cn=e=>!!e.type.__asyncLoader,al=e=>e.type.__isKeepAlive;function pu(e,t){ll(e,"a",t)}function hu(e,t){ll(e,"da",t)}function ll(e,t,i=bt){const n=e.__wdc||(e.__wdc=()=>{let s=i;for(;s;){if(s.isDeactivated)return;s=s.parent}return e()});if(Us(t,n,i),i){let s=i.parent;for(;s&&s.parent;)al(s.parent.vnode)&&mu(n,t,i,s),s=s.parent}}function mu(e,t,i,n){const s=Us(t,e,n,!0);Vs(()=>{Vo(n[t],s)},i)}function Us(e,t,i=bt,n=!1){if(i){const s=i[e]||(i[e]=[]),o=t.__weh||(t.__weh=(...a)=>{pi();const r=Xn(i),l=jt(t,i,e,a);return r(),hi(),l});return n?s.unshift(o):s.push(o),o}}const vi=e=>(t,i=bt)=>{(!Gn||e==="sp")&&Us(e,(...n)=>t(...n),i)},gu=vi("bm"),vn=vi("m"),vu=vi("bu"),bu=vi("u"),nr=vi("bum"),Vs=vi("um"),yu=vi("sp"),ku=vi("rtg"),wu=vi("rtc");function xu(e,t=bt){Us("ec",e,t)}const Su="components";function Cu(e,t){return $u(Su,e,!0,t)||e}const _u=Symbol.for("v-ndc");function $u(e,t,i=!0,n=!1){const s=dt||bt;if(s){const o=s.type;{const r=uf(o,!1);if(r&&(r===t||r===St(t)||r===Ns(St(t))))return o}const a=Br(s[e]||o[e],t)||Br(s.appContext[e],t);return!a&&n?o:a}}function Br(e,t){return e&&(e[t]||e[St(t)]||e[Ns(St(t))])}function xt(e,t,i,n){let s;const o=i,a=Ee(e);if(a||nt(e)){const r=a&&Wi(e);let l=!1,c=!1;r&&(l=!Pt(e),c=mi(e),e=Fs(e)),s=new Array(e.length);for(let d=0,p=e.length;d<p;d++)s[d]=t(l?c?fn(Ft(e[d])):Ft(e[d]):e[d],d,void 0,o)}else if(typeof e=="number"){s=new Array(e);for(let r=0;r<e;r++)s[r]=t(r+1,r,void 0,o)}else if(Ye(e))if(e[Symbol.iterator])s=Array.from(e,(r,l)=>t(r,l,void 0,o));else{const r=Object.keys(e);s=new Array(r.length);for(let l=0,c=r.length;l<c;l++){const d=r[l];s[l]=t(e[d],d,l,o)}}else s=[];return s}function rs(e,t,i={},n,s,o){if(dt.ce||dt.parent&&cn(dt.parent)&&dt.parent.ce){const c=i,d=Object.keys(c).length>0;return t!=="default"&&(c.name=t),J(),Jt(Xe,null,[re("slot",c,n&&n())],d?-2:64)}let a=e[t];a&&a._c&&(a._d=!1);const r=di.length;J();let l;try{const c=a&&cl(a(i)),d=i.key||o||c&&c.key;l=Jt(Xe,{key:(d&&!Ht(d)?d:`_${t}`)+(!c&&n?"_fb":"")},c||(n?n():[]),c&&e._===1?64:-2)}catch(c){for(let d=di.length;d>r;d--)rr();throw c}finally{a&&a._c&&(a._d=!0)}return l}function cl(e){return e.some(t=>ar(t)?!(t.type===gi||t.type===Xe&&!cl(t.children)):!0)?e:null}const Mo=e=>e?Tl(e)?qs(e):Mo(e.parent):null,Dn=ut(Object.create(null),{$:e=>e,$el:e=>e.vnode.el,$data:e=>e.data,$props:e=>e.props,$attrs:e=>e.attrs,$slots:e=>e.slots,$refs:e=>e.refs,$parent:e=>Mo(e.parent),$root:e=>Mo(e.root),$host:e=>e.ce,$emit:e=>e.emit,$options:e=>ul(e),$forceUpdate:e=>e.f||(e.f=()=>{tr(e.update)}),$nextTick:e=>e.n||(e.n=Ms.bind(e.proxy)),$watch:e=>du.bind(e)}),ro=(e,t)=>e!==Je&&!e.__isScriptSetup&&Ve(e,t),Iu={get({_:e},t){if(t==="__v_skip")return!0;const{ctx:i,setupState:n,data:s,props:o,accessCache:a,type:r,appContext:l}=e;if(t[0]!=="$"){const u=a[t];if(u!==void 0)switch(u){case 1:return n[t];case 2:return s[t];case 4:return i[t];case 3:return o[t]}else{if(ro(n,t))return a[t]=1,n[t];if(s!==Je&&Ve(s,t))return a[t]=2,s[t];if(Ve(o,t))return a[t]=3,o[t];if(i!==Je&&Ve(i,t))return a[t]=4,i[t];To&&(a[t]=0)}}const c=Dn[t];let d,p;if(c)return t==="$attrs"&&mt(e.attrs,"get",""),c(e);if((d=r.__cssModules)&&(d=d[t]))return d;if(i!==Je&&Ve(i,t))return a[t]=4,i[t];if(p=l.config.globalProperties,Ve(p,t))return p[t]},set({_:e},t,i){const{data:n,setupState:s,ctx:o}=e;return ro(s,t)?(s[t]=i,!0):n!==Je&&Ve(n,t)?(n[t]=i,!0):Ve(e.props,t)||t[0]==="$"&&t.slice(1)in e?!1:(o[t]=i,!0)},has({_:{data:e,setupState:t,accessCache:i,ctx:n,appContext:s,props:o,type:a}},r){let l;return!!(i[r]||e!==Je&&r[0]!=="$"&&Ve(e,r)||ro(t,r)||Ve(o,r)||Ve(n,r)||Ve(Dn,r)||Ve(s.config.globalProperties,r)||(l=a.__cssModules)&&l[r])},defineProperty(e,t,i){return i.get!=null?e._.accessCache[t]=0:Ve(i,"value")&&this.set(e,t,i.value,null),Reflect.defineProperty(e,t,i)}};function Dr(e){return Ee(e)?e.reduce((t,i)=>(t[i]=null,t),{}):e}let To=!0;function Mu(e){const t=ul(e),i=e.proxy,n=e.ctx;To=!1,t.beforeCreate&&Lr(t.beforeCreate,e,"bc");const{data:s,computed:o,methods:a,watch:r,provide:l,inject:c,created:d,beforeMount:p,mounted:u,beforeUpdate:f,updated:w,activated:m,deactivated:y,beforeDestroy:b,beforeUnmount:v,destroyed:k,unmounted:S,render:D,renderTracked:A,renderTriggered:C,errorCaptured:L,serverPrefetch:z,expose:N,inheritAttrs:K,components:_,directives:U,filters:x}=t;if(c&&Tu(c,n,null),a)for(const $ in a){const T=a[$];Be(T)&&(n[$]=T.bind(i))}if(s){const $=s.call(i,i);Ye($)&&(e.data=js($))}if(To=!0,o)for(const $ in o){const T=o[$],P=Be(T)?T.bind(i,i):Be(T.get)?T.get.bind(i,i):Qt,se=!Be(T)&&Be(T.set)?T.set.bind(i):Qt,V=ye({get:P,set:se});Object.defineProperty(n,$,{enumerable:!0,configurable:!0,get:()=>V.value,set:Y=>V.value=Y})}if(r)for(const $ in r)dl(r[$],n,i,$);if(l){const $=Be(l)?l.call(i):l;Reflect.ownKeys($).forEach(T=>{au(T,$[T])})}d&&Lr(d,e,"c");function O($,T){Ee(T)?T.forEach(P=>$(P.bind(i))):T&&$(T.bind(i))}if(O(gu,p),O(vn,u),O(vu,f),O(bu,w),O(pu,m),O(hu,y),O(xu,L),O(wu,A),O(ku,C),O(nr,v),O(Vs,S),O(yu,z),Ee(N))if(N.length){const $=e.exposed||(e.exposed={});N.forEach(T=>{Object.defineProperty($,T,{get:()=>i[T],set:P=>i[T]=P,enumerable:!0})})}else e.exposed||(e.exposed={});D&&e.render===Qt&&(e.render=D),K!=null&&(e.inheritAttrs=K),_&&(e.components=_),U&&(e.directives=U),z&&rl(e)}function Tu(e,t,i=Qt){Ee(e)&&(e=Eo(e));for(const n in e){const s=e[n];let o;Ye(s)?"default"in s?o=zt(s.from||n,s.default,!0):o=zt(s.from||n):o=zt(s),tt(o)?Object.defineProperty(t,n,{enumerable:!0,configurable:!0,get:()=>o.value,set:a=>o.value=a}):t[n]=o}}function Lr(e,t,i){jt(Ee(e)?e.map(n=>n.bind(t.proxy)):e.bind(t.proxy),t,i)}function dl(e,t,i,n){let s=n.includes(".")?ol(i,n):()=>i[n];if(nt(e)){const o=t[e];Be(o)&&Ui(s,o)}else if(Be(e))Ui(s,e.bind(i));else if(Ye(e))if(Ee(e))e.forEach(o=>dl(o,t,i,n));else{const o=Be(e.handler)?e.handler.bind(i):t[e.handler];Be(o)&&Ui(s,o,e)}}function ul(e){const t=e.type,{mixins:i,extends:n}=t,{mixins:s,optionsCache:o,config:{optionMergeStrategies:a}}=e.appContext,r=o.get(t);let l;return r?l=r:!s.length&&!i&&!n?l=t:(l={},s.length&&s.forEach(c=>As(l,c,a,!0)),As(l,t,a)),Ye(t)&&o.set(t,l),l}function As(e,t,i,n=!1){const{mixins:s,extends:o}=t;o&&As(e,o,i,!0),s&&s.forEach(a=>As(e,a,i,!0));for(const a in t)if(!(n&&a==="expose")){const r=Eu[a]||i&&i[a];e[a]=r?r(e[a],t[a]):t[a]}return e}const Eu={data:Pr,props:Or,emits:Or,methods:_n,computed:_n,beforeCreate:kt,created:kt,beforeMount:kt,mounted:kt,beforeUpdate:kt,updated:kt,beforeDestroy:kt,beforeUnmount:kt,destroyed:kt,unmounted:kt,activated:kt,deactivated:kt,errorCaptured:kt,serverPrefetch:kt,components:_n,directives:_n,watch:Bu,provide:Pr,inject:Au};function Pr(e,t){return t?e?function(){return ut(Be(e)?e.call(this,this):e,Be(t)?t.call(this,this):t)}:t:e}function Au(e,t){return _n(Eo(e),Eo(t))}function Eo(e){if(Ee(e)){const t={};for(let i=0;i<e.length;i++)t[e[i]]=e[i];return t}return e}function kt(e,t){return e?[...new Set([].concat(e,t))]:t}function _n(e,t){return e?ut(Object.create(null),e,t):t}function Or(e,t){return e?Ee(e)&&Ee(t)?[...new Set([...e,...t])]:ut(Object.create(null),Dr(e),Dr(t??{})):t}function Bu(e,t){if(!e)return t;if(!t)return e;const i=ut(Object.create(null),e);for(const n in t)i[n]=kt(e[n],t[n]);return i}function fl(){return{app:null,config:{isNativeTag:Ta,performance:!1,globalProperties:{},optionMergeStrategies:{},errorHandler:void 0,warnHandler:void 0,compilerOptions:{}},mixins:[],components:{},directives:{},provides:Object.create(null),optionsCache:new WeakMap,propsCache:new WeakMap,emitsCache:new WeakMap}}let Du=0;function Lu(e,t){return function(n,s=null){Be(n)||(n=ut({},n)),s!=null&&!Ye(s)&&(s=null);const o=fl(),a=new WeakSet,r=[];let l=!1;const c=o.app={_uid:Du++,_component:n,_props:s,_container:null,_context:o,_instance:null,version:pf,get config(){return o.config},set config(d){},use(d,...p){return a.has(d)||(d&&Be(d.install)?(a.add(d),d.install(c,...p)):Be(d)&&(a.add(d),d(c,...p))),c},mixin(d){return o.mixins.includes(d)||o.mixins.push(d),c},component(d,p){return p?(o.components[d]=p,c):o.components[d]},directive(d,p){return p?(o.directives[d]=p,c):o.directives[d]},mount(d,p,u){if(!l){const f=c._ceVNode||re(n,s);return f.appContext=o,u===!0?u="svg":u===!1&&(u=void 0),e(f,d,u),l=!0,c._container=d,d.__vue_app__=c,qs(f.component)}},onUnmount(d){r.push(d)},unmount(){l&&(jt(r,c._instance,16),e(null,c._container),delete c._container.__vue_app__)},provide(d,p){return o.provides[d]=p,c},runWithContext(d){const p=dn;dn=c;try{return d()}finally{dn=p}}};return c}}let dn=null;const Pu=(e,t)=>t==="modelValue"||t==="model-value"?e.modelModifiers:e[`${t}Modifiers`]||e[`${St(t)}Modifiers`]||e[`${Ei(t)}Modifiers`];function Ou(e,t,...i){if(e.isUnmounted)return;const n=e.vnode.props||Je;let s=i;const o=t.startsWith("update:"),a=o&&Pu(n,t.slice(7));a&&(a.trim&&(s=i.map(d=>nt(d)?d.trim():d)),a.number&&(s=i.map(zs)));let r,l=n[r=eo(t)]||n[r=eo(St(t))];!l&&o&&(l=n[r=eo(Ei(t))]),l&&jt(l,e,6,s);const c=n[r+"Once"];if(c){if(!e.emitted)e.emitted={};else if(e.emitted[r])return;e.emitted[r]=!0,jt(c,e,6,s)}}const Ru=new WeakMap;function pl(e,t,i=!1){const n=i?Ru:t.emitsCache,s=n.get(e);if(s!==void 0)return s;const o=e.emits;let a={},r=!1;if(!Be(e)){const l=c=>{const d=pl(c,t,!0);d&&(r=!0,ut(a,d))};!i&&t.mixins.length&&t.mixins.forEach(l),e.extends&&l(e.extends),e.mixins&&e.mixins.forEach(l)}return!o&&!r?(Ye(e)&&n.set(e,null),null):(Ee(o)?o.forEach(l=>a[l]=null):ut(a,o),Ye(e)&&n.set(e,a),a)}function Gs(e,t){return!e||!Ps(t)?!1:(t=t.slice(2),t=t==="Once"?t:t.replace(/Once$/,""),Ve(e,t[0].toLowerCase()+t.slice(1))||Ve(e,Ei(t))||Ve(e,t))}function Rr(e){const{type:t,vnode:i,proxy:n,withProxy:s,propsOptions:[o],slots:a,attrs:r,emit:l,render:c,renderCache:d,props:p,data:u,setupState:f,ctx:w,inheritAttrs:m}=e,y=Ts(e);let b,v;try{if(i.shapeFlag&4){const S=s||n,D=S;b=Kt(c.call(D,S,d,p,f,u,w)),v=r}else{const S=t;b=Kt(S.length>1?S(p,{attrs:r,slots:a,emit:l}):S(p,null)),v=t.props?r:Nu(r)}}catch(S){di.length=0,Ws(S,e,1),b=re(gi)}let k=b;if(v&&m!==!1){const S=Object.keys(v),{shapeFlag:D}=k;S.length&&D&7&&(o&&S.some(Os)&&(v=zu(v,o)),k=pn(k,v,!1,!0))}return i.dirs&&(k=pn(k,null,!1,!0),k.dirs=k.dirs?k.dirs.concat(i.dirs):i.dirs),i.transition&&ir(k,i.transition),b=k,Ts(y),b}const Nu=e=>{let t;for(const i in e)(i==="class"||i==="style"||Ps(i))&&((t||(t={}))[i]=e[i]);return t},zu=(e,t)=>{const i={};for(const n in e)(!Os(n)||!(n.slice(9)in t))&&(i[n]=e[n]);return i};function Hu(e,t,i){const{props:n,children:s,component:o}=e,{props:a,children:r,patchFlag:l}=t,c=o.emitsOptions;if(t.dirs||t.transition)return!0;if(i&&l>=0){if(l&1024)return!0;if(l&16)return n?Nr(n,a,c):!!a;if(l&8){const d=t.dynamicProps;for(let p=0;p<d.length;p++){const u=d[p];if(hl(a,n,u)&&!Gs(c,u))return!0}}}else return(s||r)&&(!r||!r.$stable)?!0:n===a?!1:n?a?Nr(n,a,c):!0:!!a;return!1}function Nr(e,t,i){const n=Object.keys(t);if(n.length!==Object.keys(e).length)return!0;for(let s=0;s<n.length;s++){const o=n[s];if(hl(t,e,o)&&!Gs(i,o))return!0}return!1}function hl(e,t,i){const n=e[i],s=t[i];return i==="style"&&Ye(n)&&Ye(s)?!gn(n,s):n!==s}function Fu({vnode:e,parent:t,suspense:i},n){for(;t;){const s=t.subTree;if(s.suspense&&s.suspense.activeBranch===e&&(s.suspense.vnode.el=s.el=n,e=s),s===e)(e=t.vnode).el=n,t=t.parent;else break}i&&i.activeBranch===e&&(i.vnode.el=n)}const ml={},gl=()=>Object.create(ml),vl=e=>Object.getPrototypeOf(e)===ml;function ju(e,t,i,n=!1){const s={},o=gl();e.propsDefaults=Object.create(null),bl(e,t,s,o);for(const a in e.propsOptions[0])a in s||(s[a]=void 0);i?e.props=n?s:Yd(s):e.type.props?e.props=s:e.props=o,e.attrs=o}function Wu(e,t,i,n){const{props:s,attrs:o,vnode:{patchFlag:a}}=e,r=Ue(s),[l]=e.propsOptions;let c=!1;if((n||a>0)&&!(a&16)){if(a&8){const d=e.vnode.dynamicProps;for(let p=0;p<d.length;p++){let u=d[p];if(Gs(e.emitsOptions,u))continue;const f=t[u];if(l)if(Ve(o,u))f!==o[u]&&(o[u]=f,c=!0);else{const w=St(u);s[w]=Ao(l,r,w,f,e,!1)}else f!==o[u]&&(o[u]=f,c=!0)}}}else{bl(e,t,s,o)&&(c=!0);let d;for(const p in r)(!t||!Ve(t,p)&&((d=Ei(p))===p||!Ve(t,d)))&&(l?i&&(i[p]!==void 0||i[d]!==void 0)&&(s[p]=Ao(l,r,p,void 0,e,!0)):delete s[p]);if(o!==r)for(const p in o)(!t||!Ve(t,p))&&(delete o[p],c=!0)}c&&li(e.attrs,"set","")}function bl(e,t,i,n){const[s,o]=e.propsOptions;let a=!1,r;if(t)for(let l in t){if(Tn(l))continue;const c=t[l];let d;s&&Ve(s,d=St(l))?!o||!o.includes(d)?i[d]=c:(r||(r={}))[d]=c:Gs(e.emitsOptions,l)||(!(l in n)||c!==n[l])&&(n[l]=c,a=!0)}if(o){const l=Ue(i),c=r||Je;for(let d=0;d<o.length;d++){const p=o[d];i[p]=Ao(s,l,p,c[p],e,!Ve(c,p))}}return a}function Ao(e,t,i,n,s,o){const a=e[i];if(a!=null){const r=Ve(a,"default");if(r&&n===void 0){const l=a.default;if(a.type!==Function&&!a.skipFactory&&Be(l)){const{propsDefaults:c}=s;if(i in c)n=c[i];else{const d=Xn(s);n=c[i]=l.call(null,t),d()}}else n=l;s.ce&&s.ce._setProp(i,n)}a[0]&&(o&&!r?n=!1:a[1]&&(n===""||n===Ei(i))&&(n=!0))}return n}const Uu=new WeakMap;function yl(e,t,i=!1){const n=i?Uu:t.propsCache,s=n.get(e);if(s)return s;const o=e.props,a={},r=[];let l=!1;if(!Be(e)){const d=p=>{l=!0;const[u,f]=yl(p,t,!0);ut(a,u),f&&r.push(...f)};!i&&t.mixins.length&&t.mixins.forEach(d),e.extends&&d(e.extends),e.mixins&&e.mixins.forEach(d)}if(!o&&!l)return Ye(e)&&n.set(e,rn),rn;if(Ee(o))for(let d=0;d<o.length;d++){const p=St(o[d]);zr(p)&&(a[p]=Je)}else if(o)for(const d in o){const p=St(d);if(zr(p)){const u=o[d],f=a[p]=Ee(u)||Be(u)?{type:u}:ut({},u),w=f.type;let m=!1,y=!0;if(Ee(w))for(let b=0;b<w.length;++b){const v=w[b],k=Be(v)&&v.name;if(k==="Boolean"){m=!0;break}else k==="String"&&(y=!1)}else m=Be(w)&&w.name==="Boolean";f[0]=m,f[1]=y,(m||Ve(f,"default"))&&r.push(p)}}const c=[a,r];return Ye(e)&&n.set(e,c),c}function zr(e){return e[0]!=="$"&&!Tn(e)}const sr=e=>e==="_"||e==="_ctx"||e==="$stable",or=e=>Ee(e)?e.map(Kt):[Kt(e)],Vu=(e,t,i)=>{if(t._n)return t;const n=nl((...s)=>or(t(...s)),i);return n._c=!1,n},kl=(e,t,i)=>{const n=e._ctx;for(const s in e){if(sr(s))continue;const o=e[s];if(Be(o))t[s]=Vu(s,o,n);else if(o!=null){const a=or(o);t[s]=()=>a}}},wl=(e,t)=>{const i=or(t);e.slots.default=()=>i},xl=(e,t,i)=>{for(const n in t)(i||!sr(n))&&(e[n]=t[n])},Gu=(e,t,i)=>{const n=e.slots=gl();if(e.vnode.shapeFlag&32){const s=t._;s?(xl(n,t,i),i&&Da(n,"_",s,!0)):kl(t,n)}else t&&wl(e,t)},Ku=(e,t,i)=>{const{vnode:n,slots:s}=e;let o=!0,a=Je;if(n.shapeFlag&32){const r=t._;r?i&&r===1?o=!1:xl(s,t,i):(o=!t.$stable,kl(t,s)),a=t}else t&&(wl(e,t),a={default:1});if(o)for(const r in s)!sr(r)&&a[r]==null&&delete s[r]},Ct=Xu;function qu(e){return Yu(e)}function Yu(e,t){const i=Hs();i.__VUE__=!0;const{insert:n,remove:s,patchProp:o,createElement:a,createText:r,createComment:l,setText:c,setElementText:d,parentNode:p,nextSibling:u,setScopeId:f=Qt,insertStaticContent:w}=e,m=(E,F,g,W=null,j=null,M=null,I=void 0,R=null,G=!!F.dynamicChildren)=>{if(E===F)return;E&&!Sn(E,F)&&(W=Ie(E),Y(E,j,M,!0),E=null),F.patchFlag===-2&&(G=!1,F.dynamicChildren=null);const{type:B,ref:H,shapeFlag:Z}=F;switch(B){case Ks:y(E,F,g,W);break;case gi:b(E,F,g,W);break;case fs:E==null&&v(F,g,W,I);break;case Xe:_(E,F,g,W,j,M,I,R,G);break;default:Z&1?D(E,F,g,W,j,M,I,R,G):Z&6?U(E,F,g,W,j,M,I,R,G):(Z&64||Z&128)&&B.process(E,F,g,W,j,M,I,R,G,X)}H!=null&&j?Bn(H,E&&E.ref,M,F||E,!F):H==null&&E&&E.ref!=null&&Bn(E.ref,null,M,E,!0)},y=(E,F,g,W)=>{if(E==null)n(F.el=r(F.children),g,W);else{const j=F.el=E.el;F.children!==E.children&&c(j,F.children)}},b=(E,F,g,W)=>{E==null?n(F.el=l(F.children||""),g,W):F.el=E.el},v=(E,F,g,W)=>{[E.el,E.anchor]=w(E.children,F,g,W,E.el,E.anchor)},k=({el:E,anchor:F},g,W)=>{let j;for(;E&&E!==F;)j=u(E),n(E,g,W),E=j;n(F,g,W)},S=({el:E,anchor:F})=>{let g;for(;E&&E!==F;)g=u(E),s(E),E=g;s(F)},D=(E,F,g,W,j,M,I,R,G)=>{if(F.type==="svg"?I="svg":F.type==="math"&&(I="mathml"),E==null)A(F,g,W,j,M,I,R,G);else{const B=E.el&&E.el._isVueCE?E.el:null;try{B&&B._beginPatch(),z(E,F,j,M,I,R,G)}finally{B&&B._endPatch()}}},A=(E,F,g,W,j,M,I,R)=>{let G,B;const{props:H,shapeFlag:Z,transition:te,dirs:ne}=E;if(G=E.el=a(E.type,M,H&&H.is,H),Z&8?d(G,E.children):Z&16&&L(E.children,G,null,W,j,ao(E,M),I,R),ne&&Bi(E,null,W,"created"),C(G,E,E.scopeId,I,W),H){for(const $e in H)$e!=="value"&&!Tn($e)&&o(G,$e,null,H[$e],M,W);"value"in H&&o(G,"value",null,H.value,M),(B=H.onVnodeBeforeMount)&&Wt(B,W,E)}ne&&Bi(E,null,W,"beforeMount");const me=Zu(j,te);me&&te.beforeEnter(G),n(G,F,g),((B=H&&H.onVnodeMounted)||me||ne)&&Ct(()=>{try{B&&Wt(B,W,E),me&&te.enter(G),ne&&Bi(E,null,W,"mounted")}finally{}},j)},C=(E,F,g,W,j)=>{if(g&&f(E,g),W)for(let M=0;M<W.length;M++)f(E,W[M]);if(j){let M=j.subTree;if(F===M||$l(M.type)&&(M.ssContent===F||M.ssFallback===F)){const I=j.vnode;C(E,I,I.scopeId,I.slotScopeIds,j.parent)}}},L=(E,F,g,W,j,M,I,R,G=0)=>{for(let B=G;B<E.length;B++){const H=E[B]=R?oi(E[B]):Kt(E[B]);m(null,H,F,g,W,j,M,I,R)}},z=(E,F,g,W,j,M,I)=>{const R=F.el=E.el;let{patchFlag:G,dynamicChildren:B,dirs:H}=F;G|=E.patchFlag&16;const Z=E.props||Je,te=F.props||Je;let ne;if(g&&Di(g,!1),(ne=te.onVnodeBeforeUpdate)&&Wt(ne,g,F,E),H&&Bi(F,E,g,"beforeUpdate"),g&&Di(g,!0),B&&(!E.dynamicChildren||E.dynamicChildren.length!==B.length)&&(G=0,I=!1,B=null),(Z.innerHTML&&te.innerHTML==null||Z.textContent&&te.textContent==null)&&d(R,""),B?N(E.dynamicChildren,B,R,g,W,ao(F,j),M):I||T(E,F,R,null,g,W,ao(F,j),M,!1),G>0){if(G&16)K(R,Z,te,g,j);else if(G&2&&Z.class!==te.class&&o(R,"class",null,te.class,j),G&4&&o(R,"style",Z.style,te.style,j),G&8){const me=F.dynamicProps;for(let $e=0;$e<me.length;$e++){const xe=me[$e],De=Z[xe],je=te[xe];(je!==De||xe==="value")&&o(R,xe,De,je,j,g)}}G&1&&E.children!==F.children&&d(R,F.children)}else!I&&B==null&&K(R,Z,te,g,j);((ne=te.onVnodeUpdated)||H)&&Ct(()=>{ne&&Wt(ne,g,F,E),H&&Bi(F,E,g,"updated")},W)},N=(E,F,g,W,j,M,I)=>{for(let R=0;R<F.length;R++){const G=E[R],B=F[R],H=G.el&&(G.type===Xe||!Sn(G,B)||G.shapeFlag&198)?p(G.el):g;m(G,B,H,null,W,j,M,I,!0)}},K=(E,F,g,W,j)=>{if(F!==g){if(F!==Je)for(const M in F)!Tn(M)&&!(M in g)&&o(E,M,F[M],null,j,W);for(const M in g){if(Tn(M))continue;const I=g[M],R=F[M];I!==R&&M!=="value"&&o(E,M,R,I,j,W)}"value"in g&&o(E,"value",F.value,g.value,j)}},_=(E,F,g,W,j,M,I,R,G)=>{const B=F.el=E?E.el:r(""),H=F.anchor=E?E.anchor:r("");let{patchFlag:Z,dynamicChildren:te,slotScopeIds:ne}=F;ne&&(R=R?R.concat(ne):ne),E==null?(n(B,g,W),n(H,g,W),L(F.children||[],g,H,j,M,I,R,G)):Z>0&&Z&64&&te&&E.dynamicChildren&&E.dynamicChildren.length===te.length?(N(E.dynamicChildren,te,g,j,M,I,R),(F.key!=null||j&&F===j.subTree)&&Sl(E,F,!0)):T(E,F,g,H,j,M,I,R,G)},U=(E,F,g,W,j,M,I,R,G)=>{F.slotScopeIds=R,E==null?F.shapeFlag&512?j.ctx.activate(F,g,W,I,G):x(F,g,W,j,M,I,G):q(E,F,G)},x=(E,F,g,W,j,M,I)=>{const R=E.component=of(E,W,j);if(al(E)&&(R.ctx.renderer=X),af(R,!1,I),R.asyncDep){if(j&&j.registerDep(R,O,I),!E.el){const G=R.subTree=re(gi);b(null,G,F,g),E.placeholder=G.el}}else O(R,E,F,g,j,M,I)},q=(E,F,g)=>{const W=F.component=E.component;if(Hu(E,F,g))if(W.asyncDep&&!W.asyncResolved){$(W,F,g);return}else W.next=F,W.update();else F.el=E.el,W.vnode=F},O=(E,F,g,W,j,M,I)=>{const R=()=>{if(E.isMounted){let{next:Z,bu:te,u:ne,parent:me,vnode:$e}=E;{const ae=Cl(E);if(ae){Z&&(Z.el=$e.el,$(E,Z,I)),ae.asyncDep.then(()=>{Ct(()=>{E.isUnmounted||B()},j)});return}}let xe=Z,De;Di(E,!1),Z?(Z.el=$e.el,$(E,Z,I)):Z=$e,te&&us(te),(De=Z.props&&Z.props.onVnodeBeforeUpdate)&&Wt(De,me,Z,$e),Di(E,!0);const je=Rr(E),ze=E.subTree;E.subTree=je,m(ze,je,p(ze.el),Ie(ze),E,j,M),Z.el=je.el,xe===null&&Fu(E,je.el),ne&&Ct(ne,j),(De=Z.props&&Z.props.onVnodeUpdated)&&Ct(()=>Wt(De,me,Z,$e),j)}else{let Z;const{el:te,props:ne}=F,{bm:me,m:$e,parent:xe,root:De,type:je}=E,ze=cn(F);Di(E,!1),me&&us(me),!ze&&(Z=ne&&ne.onVnodeBeforeMount)&&Wt(Z,xe,F),Di(E,!0);{De.ce&&De.ce._hasShadowRoot()&&De.ce._injectChildStyle(je,E.parent?E.parent.type:void 0);const ae=E.subTree=Rr(E);m(null,ae,g,W,E,j,M),F.el=ae.el}if($e&&Ct($e,j),!ze&&(Z=ne&&ne.onVnodeMounted)){const ae=F;Ct(()=>Wt(Z,xe,ae),j)}(F.shapeFlag&256||xe&&cn(xe.vnode)&&xe.vnode.shapeFlag&256)&&E.a&&Ct(E.a,j),E.isMounted=!0,F=g=W=null}};E.scope.on();const G=E.effect=new Ra(R);E.scope.off();const B=E.update=G.run.bind(G),H=E.job=G.runIfDirty.bind(G);H.i=E,H.id=E.uid,G.scheduler=()=>tr(H),Di(E,!0),B()},$=(E,F,g)=>{F.component=E;const W=E.vnode.props;E.vnode=F,E.next=null,Wu(E,F.props,W,g),Ku(E,F.children,g),pi(),Tr(E),hi()},T=(E,F,g,W,j,M,I,R,G=!1)=>{const B=E&&E.children,H=E?E.shapeFlag:0,Z=F.children,{patchFlag:te,shapeFlag:ne}=F;if(te>0){if(te&128){se(B,Z,g,W,j,M,I,R,G);return}else if(te&256){P(B,Z,g,W,j,M,I,R,G);return}}ne&8?(H&16&&Se(B,j,M),Z!==B&&d(g,Z)):H&16?ne&16?se(B,Z,g,W,j,M,I,R,G):Se(B,j,M,!0):(H&8&&d(g,""),ne&16&&L(Z,g,W,j,M,I,R,G))},P=(E,F,g,W,j,M,I,R,G)=>{E=E||rn,F=F||rn;const B=E.length,H=F.length,Z=Math.min(B,H);let te;for(te=0;te<Z;te++){const ne=F[te]=G?oi(F[te]):Kt(F[te]);m(E[te],ne,g,null,j,M,I,R,G)}B>H?Se(E,j,M,!0,!1,Z):L(F,g,W,j,M,I,R,G,Z)},se=(E,F,g,W,j,M,I,R,G)=>{let B=0;const H=F.length;let Z=E.length-1,te=H-1;for(;B<=Z&&B<=te;){const ne=E[B],me=F[B]=G?oi(F[B]):Kt(F[B]);if(Sn(ne,me))m(ne,me,g,null,j,M,I,R,G);else break;B++}for(;B<=Z&&B<=te;){const ne=E[Z],me=F[te]=G?oi(F[te]):Kt(F[te]);if(Sn(ne,me))m(ne,me,g,null,j,M,I,R,G);else break;Z--,te--}if(B>Z){if(B<=te){const ne=te+1,me=ne<H?F[ne].el:W;for(;B<=te;)m(null,F[B]=G?oi(F[B]):Kt(F[B]),g,me,j,M,I,R,G),B++}}else if(B>te)for(;B<=Z;)Y(E[B],j,M,!0),B++;else{const ne=B,me=B,$e=new Map;for(B=me;B<=te;B++){const He=F[B]=G?oi(F[B]):Kt(F[B]);He.key!=null&&$e.set(He.key,B)}let xe,De=0;const je=te-me+1;let ze=!1,ae=0;const ue=new Array(je);for(B=0;B<je;B++)ue[B]=0;for(B=ne;B<=Z;B++){const He=E[B];if(De>=je){Y(He,j,M,!0);continue}let We;if(He.key!=null)We=$e.get(He.key);else for(xe=me;xe<=te;xe++)if(ue[xe-me]===0&&Sn(He,F[xe])){We=xe;break}We===void 0?Y(He,j,M,!0):(ue[We-me]=B+1,We>=ae?ae=We:ze=!0,m(He,F[We],g,null,j,M,I,R,G),De++)}const Oe=ze?Ju(ue):rn;for(xe=Oe.length-1,B=je-1;B>=0;B--){const He=me+B,We=F[He],lt=F[He+1],Et=He+1<H?lt.el||_l(lt):W;ue[B]===0?m(null,We,g,Et,j,M,I,R,G):ze&&(xe<0||B!==Oe[xe]?V(We,g,Et,2):xe--)}}},V=(E,F,g,W,j=null)=>{const{el:M,type:I,transition:R,children:G,shapeFlag:B}=E;if(B&6){V(E.component.subTree,F,g,W);return}if(B&128){E.suspense.move(F,g,W);return}if(B&64){I.move(E,F,g,X);return}if(I===Xe){n(M,F,g);for(let Z=0;Z<G.length;Z++)V(G[Z],F,g,W);n(E.anchor,F,g);return}if(I===fs){k(E,F,g);return}if(W!==2&&B&1&&R)if(W===0)R.persisted&&!M[oo]?n(M,F,g):(R.beforeEnter(M),n(M,F,g),Ct(()=>R.enter(M),j));else{const{leave:Z,delayLeave:te,afterLeave:ne}=R,me=()=>{E.ctx.isUnmounted?s(M):n(M,F,g)},$e=()=>{const xe=M._isLeaving||!!M[oo];M._isLeaving&&M[oo](!0),R.persisted&&!xe?me():Z(M,()=>{me(),ne&&ne()})};te?te(M,me,$e):$e()}else n(M,F,g)},Y=(E,F,g,W=!1,j=!1)=>{const{type:M,props:I,ref:R,children:G,dynamicChildren:B,shapeFlag:H,patchFlag:Z,dirs:te,cacheIndex:ne,memo:me}=E;if(Z===-2&&(j=!1),R!=null&&(pi(),Bn(R,null,g,E,!0),hi()),ne!=null&&(F.renderCache[ne]=void 0),H&256){F.ctx.deactivate(E);return}const $e=H&1&&te,xe=!cn(E);let De;if(xe&&(De=I&&I.onVnodeBeforeUnmount)&&Wt(De,F,E),H&6)oe(E.component,g,W);else{if(H&128){E.suspense.unmount(g,W);return}$e&&Bi(E,null,F,"beforeUnmount"),H&64?E.type.remove(E,F,g,X,W):B&&!B.hasOnce&&(M!==Xe||Z>0&&Z&64)?Se(B,F,g,!1,!0):(M===Xe&&Z&384||!j&&H&16)&&Se(G,F,g),W&&le(E)}const je=me!=null&&ne==null;(xe&&(De=I&&I.onVnodeUnmounted)||$e||je)&&Ct(()=>{De&&Wt(De,F,E),$e&&Bi(E,null,F,"unmounted"),je&&(E.el=null)},g)},le=E=>{const{type:F,el:g,anchor:W,transition:j}=E;if(F===Xe){ie(g,W);return}if(F===fs){S(E);return}const M=()=>{s(g),j&&!j.persisted&&j.afterLeave&&j.afterLeave()};if(E.shapeFlag&1&&j&&!j.persisted){const{leave:I,delayLeave:R}=j,G=()=>I(g,M);R?R(E.el,M,G):G()}else M()},ie=(E,F)=>{let g;for(;E!==F;)g=u(E),s(E),E=g;s(F)},oe=(E,F,g)=>{const{bum:W,scope:j,job:M,subTree:I,um:R,m:G,a:B}=E;Hr(G),Hr(B),W&&us(W),j.stop(),M&&(M.flags|=8,Y(I,E,F,g)),R&&Ct(R,F),Ct(()=>{E.isUnmounted=!0},F)},Se=(E,F,g,W=!1,j=!1,M=0)=>{for(let I=M;I<E.length;I++)Y(E[I],F,g,W,j)},Ie=E=>{if(E.shapeFlag&6)return Ie(E.component.subTree);if(E.shapeFlag&128)return E.suspense.next();const F=u(E.anchor||E.el),g=F&&F[uu];return g?u(g):F};let _e=!1;const fe=(E,F,g)=>{let W;E==null?F._vnode&&(Y(F._vnode,null,null,!0),W=F._vnode.component):m(F._vnode||null,E,F,null,null,null,g),F._vnode=E,_e||(_e=!0,Tr(W),el(),_e=!1)},X={p:m,um:Y,m:V,r:le,mt:x,mc:L,pc:T,pbc:N,n:Ie,o:e};return{render:fe,hydrate:void 0,createApp:Lu(fe)}}function ao({type:e,props:t},i){return i==="svg"&&e==="foreignObject"||i==="mathml"&&e==="annotation-xml"&&t&&t.encoding&&t.encoding.includes("html")?void 0:i}function Di({effect:e,job:t},i){i?(e.flags|=32,t.flags|=4):(e.flags&=-33,t.flags&=-5)}function Zu(e,t){return(!e||e&&!e.pendingBranch)&&t&&!t.persisted}function Sl(e,t,i=!1){const n=e.children,s=t.children;if(Ee(n)&&Ee(s))for(let o=0;o<n.length;o++){const a=n[o];let r=s[o];r.shapeFlag&1&&!r.dynamicChildren&&((r.patchFlag<=0||r.patchFlag===32)&&(r=s[o]=oi(s[o]),r.el=a.el),!i&&r.patchFlag!==-2&&Sl(a,r)),r.type===Ks&&(r.patchFlag===-1&&(r=s[o]=oi(r)),r.el=a.el),r.type===gi&&!r.el&&(r.el=a.el)}}function Ju(e){const t=e.slice(),i=[0];let n,s,o,a,r;const l=e.length;for(n=0;n<l;n++){const c=e[n];if(c!==0){if(s=i[i.length-1],e[s]<c){t[n]=s,i.push(n);continue}for(o=0,a=i.length-1;o<a;)r=o+a>>1,e[i[r]]<c?o=r+1:a=r;c<e[i[o]]&&(o>0&&(t[n]=i[o-1]),i[o]=n)}}for(o=i.length,a=i[o-1];o-- >0;)i[o]=a,a=t[a];return i}function Cl(e){const t=e.subTree.component;if(t)return t.asyncDep&&!t.asyncResolved?t:Cl(t)}function Hr(e){if(e)for(let t=0;t<e.length;t++)e[t].flags|=8}function _l(e){if(e.placeholder)return e.placeholder;const t=e.component;return t?_l(t.subTree):null}const $l=e=>e.__isSuspense;function Xu(e,t){t&&t.pendingBranch?Ee(e)?t.effects.push(...e):t.effects.push(e):ru(e)}const Xe=Symbol.for("v-fgt"),Ks=Symbol.for("v-txt"),gi=Symbol.for("v-cmt"),fs=Symbol.for("v-stc"),di=[];let Bt=null;function J(e=!1){di.push(Bt=e?null:[])}function rr(){di.pop(),Bt=di[di.length-1]||null}let Vn=1;function Fr(e,t=!1){Vn+=e,e<0&&Bt&&t&&(Bt.hasOnce=!0)}function Il(e){return e.dynamicChildren=Vn>0?Bt||rn:null,rr(),Vn>0&&Bt&&Bt.push(e),e}function ee(e,t,i,n,s,o){return Il(h(e,t,i,n,s,o,!0))}function Jt(e,t,i,n,s){return Il(re(e,t,i,n,s,!0))}function ar(e){return e?e.__v_isVNode===!0:!1}function Sn(e,t){return e.type===t.type&&e.key===t.key}const Ml=({key:e})=>e??null,ps=({ref:e,ref_key:t,ref_for:i})=>(typeof e=="number"&&(e=""+e),e!=null?nt(e)||tt(e)||Be(e)?{i:dt,r:e,k:t,f:!!i}:e:null);function h(e,t=null,i=null,n=0,s=null,o=e===Xe?0:1,a=!1,r=!1){const l={__v_isVNode:!0,__v_skip:!0,type:e,props:t,key:t&&Ml(t),ref:t&&ps(t),scopeId:il,slotScopeIds:null,children:i,component:null,suspense:null,ssContent:null,ssFallback:null,dirs:null,transition:null,el:null,anchor:null,target:null,targetStart:null,targetAnchor:null,staticCount:0,shapeFlag:o,patchFlag:n,dynamicProps:s,dynamicChildren:null,appContext:null,ctx:dt};return r?(Bs(l,i),o&128&&e.normalize(l)):i&&(l.shapeFlag|=nt(i)?8:16),Vn>0&&!a&&Bt&&(l.patchFlag>0||o&6)&&l.patchFlag!==32&&Bt.push(l),l}const re=Qu;function Qu(e,t=null,i=null,n=0,s=null,o=!1){if((!e||e===_u)&&(e=gi),ar(e)){const r=pn(e,t,!0);return i&&Bs(r,i),Vn>0&&!o&&Bt&&(r.shapeFlag&6?Bt[Bt.indexOf(e)]=r:Bt.push(r)),r.patchFlag=-2,r}if(ff(e)&&(e=e.__vccOpts),t){t=ef(t);let{class:r,style:l}=t;r&&!nt(r)&&(t.class=Ce(r)),Ye(l)&&(er(l)&&!Ee(l)&&(l=ut({},l)),t.style=Yt(l))}const a=nt(e)?1:$l(e)?128:fu(e)?64:Ye(e)?4:Be(e)?2:0;return h(e,t,i,n,s,a,o,!0)}function ef(e){return e?er(e)||vl(e)?ut({},e):e:null}function pn(e,t,i=!1,n=!1){const{props:s,ref:o,patchFlag:a,children:r,transition:l}=e,c=t?tf(s||{},t):s,d={__v_isVNode:!0,__v_skip:!0,type:e.type,props:c,key:c&&Ml(c),ref:t&&t.ref?i&&o?Ee(o)?o.concat(ps(t)):[o,ps(t)]:ps(t):o,scopeId:e.scopeId,slotScopeIds:e.slotScopeIds,children:r,target:e.target,targetStart:e.targetStart,targetAnchor:e.targetAnchor,staticCount:e.staticCount,shapeFlag:e.shapeFlag,patchFlag:t&&e.type!==Xe?a===-1?16:a|16:a,dynamicProps:e.dynamicProps,dynamicChildren:e.dynamicChildren,appContext:e.appContext,dirs:e.dirs,transition:l,component:e.component,suspense:e.suspense,ssContent:e.ssContent&&pn(e.ssContent),ssFallback:e.ssFallback&&pn(e.ssFallback),placeholder:e.placeholder,el:e.el,anchor:e.anchor,ctx:e.ctx,ce:e.ce};return l&&n&&ir(d,l.clone(d)),d}function $t(e=" ",t=0){return re(Ks,null,e,t)}function ht(e,t){const i=re(fs,null,e);return i.staticCount=t,i}function Te(e="",t=!1){return t?(J(),Jt(gi,null,e)):re(gi,null,e)}function Kt(e){return e==null||typeof e=="boolean"?re(gi):Ee(e)?re(Xe,null,e.slice()):ar(e)?oi(e):re(Ks,null,String(e))}function oi(e){return e.el===null&&e.patchFlag!==-1||e.memo?e:pn(e)}function Bs(e,t){let i=0;const{shapeFlag:n}=e;if(t==null)t=null;else if(Ee(t))i=16;else if(typeof t=="object")if(n&65){const s=t.default;s&&(s._c&&(s._d=!1),Bs(e,s()),s._c&&(s._d=!0));return}else{i=32;const s=t._;!s&&!vl(t)?t._ctx=dt:s===3&&dt&&(dt.slots._===1?t._=1:(t._=2,e.patchFlag|=1024))}else if(Be(t)){if(n&65){Bs(e,{default:t});return}t={default:t,_ctx:dt},i=32}else t=String(t),n&64?(i=16,t=[$t(t)]):i=8;e.children=t,e.shapeFlag|=i}function tf(...e){const t={};for(let i=0;i<e.length;i++){const n=e[i];for(const s in n)if(s==="class")t.class!==n.class&&(t.class=Ce([t.class,n.class]));else if(s==="style")t.style=Yt([t.style,n.style]);else if(Ps(s)){const o=t[s],a=n[s];a&&o!==a&&!(Ee(o)&&o.includes(a))?t[s]=o?[].concat(o,a):a:a==null&&o==null&&!Os(s)&&(t[s]=a)}else s!==""&&(t[s]=n[s])}return t}function Wt(e,t,i,n=null){jt(e,t,7,[i,n])}const nf=fl();let sf=0;function of(e,t,i){const n=e.type,s=(t?t.appContext:e.appContext)||nf,o={uid:sf++,vnode:e,type:n,parent:t,appContext:s,root:null,next:null,subTree:null,effect:null,update:null,job:null,scope:new Ed(!0),render:null,proxy:null,exposed:null,exposeProxy:null,withProxy:null,provides:t?t.provides:Object.create(s.provides),ids:t?t.ids:["",0,0],accessCache:null,renderCache:[],components:null,directives:null,propsOptions:yl(n,s),emitsOptions:pl(n,s),emit:null,emitted:null,propsDefaults:Je,inheritAttrs:n.inheritAttrs,ctx:Je,data:Je,props:Je,attrs:Je,slots:Je,refs:Je,setupState:Je,setupContext:null,suspense:i,suspenseId:i?i.pendingId:0,asyncDep:null,asyncResolved:!1,isMounted:!1,isUnmounted:!1,isDeactivated:!1,bc:null,c:null,bm:null,m:null,bu:null,u:null,um:null,bum:null,da:null,a:null,rtg:null,rtc:null,ec:null,sp:null};return o.ctx={_:o},o.root=t?t.root:o,o.emit=Ou.bind(null,o),e.ce&&e.ce(o),o}let bt=null;const rf=()=>bt||dt;let Ds,Bo;{const e=Hs(),t=(i,n)=>{let s;return(s=e[i])||(s=e[i]=[]),s.push(n),o=>{s.length>1?s.forEach(a=>a(o)):s[0](o)}};Ds=t("__VUE_INSTANCE_SETTERS__",i=>bt=i),Bo=t("__VUE_SSR_SETTERS__",i=>Gn=i)}const Xn=e=>{const t=bt;return Ds(e),e.scope.on(),()=>{e.scope.off(),Ds(t)}},jr=()=>{bt&&bt.scope.off(),Ds(null)};function Tl(e){return e.vnode.shapeFlag&4}let Gn=!1;function af(e,t=!1,i=!1){t&&Bo(t);const{props:n,children:s}=e.vnode,o=Tl(e);ju(e,n,o,t),Gu(e,s,i||t);const a=o?lf(e,t):void 0;return t&&Bo(!1),a}function lf(e,t){const i=e.type;e.accessCache=Object.create(null),e.proxy=new Proxy(e.ctx,Iu);const{setup:n}=i;if(n){pi();const s=e.setupContext=n.length>1?df(e):null,o=Xn(e),a=Jn(n,e,0,[e.props,s]),r=Ea(a);if(hi(),o(),(r||e.sp)&&!cn(e)&&rl(e),r){if(a.then(jr,jr),t)return a.then(l=>{Wr(e,l)}).catch(l=>{Ws(l,e,0)});e.asyncDep=a}else Wr(e,a)}else El(e)}function Wr(e,t,i){Be(t)?e.type.__ssrInlineRender?e.ssrRender=t:e.render=t:Ye(t)&&(e.setupState=Ja(t)),El(e)}function El(e,t,i){const n=e.type;e.render||(e.render=n.render||Qt);{const s=Xn(e);pi();try{Mu(e)}finally{hi(),s()}}}const cf={get(e,t){return mt(e,"get",""),e[t]}};function df(e){const t=i=>{e.exposed=i||{}};return{attrs:new Proxy(e.attrs,cf),slots:e.slots,emit:e.emit,expose:t}}function qs(e){return e.exposed?e.exposeProxy||(e.exposeProxy=new Proxy(Ja(Zd(e.exposed)),{get(t,i){if(i in t)return t[i];if(i in Dn)return Dn[i](e)},has(t,i){return i in t||i in Dn}})):e.proxy}function uf(e,t=!0){return Be(e)?e.displayName||e.name:e.name||t&&e.__name}function ff(e){return Be(e)&&"__vccOpts"in e}const ye=(e,t)=>tu(e,t,Gn),pf="3.5.40";/**
* @vue/runtime-dom v3.5.40
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/let Do;const Ur=typeof window<"u"&&window.trustedTypes;if(Ur)try{Do=Ur.createPolicy("vue",{createHTML:e=>e})}catch{}const Al=Do?e=>Do.createHTML(e):e=>e,hf="http://www.w3.org/2000/svg",mf="http://www.w3.org/1998/Math/MathML",si=typeof document<"u"?document:null,Vr=si&&si.createElement("template"),gf={insert:(e,t,i)=>{t.insertBefore(e,i||null)},remove:e=>{const t=e.parentNode;t&&t.removeChild(e)},createElement:(e,t,i,n)=>{const s=t==="svg"?si.createElementNS(hf,e):t==="mathml"?si.createElementNS(mf,e):i?si.createElement(e,{is:i}):si.createElement(e);return e==="select"&&n&&n.multiple!=null&&s.setAttribute("multiple",n.multiple),s},createText:e=>si.createTextNode(e),createComment:e=>si.createComment(e),setText:(e,t)=>{e.nodeValue=t},setElementText:(e,t)=>{e.textContent=t},parentNode:e=>e.parentNode,nextSibling:e=>e.nextSibling,querySelector:e=>si.querySelector(e),setScopeId(e,t){e.setAttribute(t,"")},insertStaticContent(e,t,i,n,s,o){const a=i?i.previousSibling:t.lastChild;if(s&&(s===o||s.nextSibling))for(;t.insertBefore(s.cloneNode(!0),i),!(s===o||!(s=s.nextSibling)););else{Vr.innerHTML=Al(n==="svg"?`<svg>${e}</svg>`:n==="mathml"?`<math>${e}</math>`:e);const r=Vr.content;if(n==="svg"||n==="mathml"){const l=r.firstChild;for(;l.firstChild;)r.appendChild(l.firstChild);r.removeChild(l)}t.insertBefore(r,i)}return[a?a.nextSibling:t.firstChild,i?i.previousSibling:t.lastChild]}},vf=Symbol("_vtc");function bf(e,t,i){const n=e[vf];n&&(t=(t?[t,...n]:[...n]).join(" ")),t==null?e.removeAttribute("class"):i?e.setAttribute("class",t):e.className=t}const Ls=Symbol("_vod"),Bl=Symbol("_vsh"),Lo={name:"show",beforeMount(e,{value:t},{transition:i}){e[Ls]=e.style.display==="none"?"":e.style.display,i&&t?i.beforeEnter(e):Cn(e,t)},mounted(e,{value:t},{transition:i}){i&&t&&i.enter(e)},updated(e,{value:t,oldValue:i},{transition:n}){!t!=!i&&(n?t?(n.beforeEnter(e),Cn(e,!0),n.enter(e)):n.leave(e,()=>{Cn(e,!1)}):Cn(e,t))},beforeUnmount(e,{value:t}){Cn(e,t)}};function Cn(e,t){e.style.display=t?e[Ls]:"none",e[Bl]=!t}const yf=Symbol(""),kf=/(?:^|;)\s*display\s*:/;function wf(e,t,i){const n=e.style,s=nt(i);let o=!1;if(i&&!s){if(t)if(nt(t))for(const a of t.split(";")){const r=a.slice(0,a.indexOf(":")).trim();i[r]==null&&$n(n,r,"")}else for(const a in t)i[a]==null&&$n(n,a,"");for(const a in i){a==="display"&&(o=!0);const r=i[a];r!=null?Sf(e,a,!nt(t)&&t?t[a]:void 0,r)||$n(n,a,r):$n(n,a,"")}}else if(s){if(t!==i){const a=n[yf];a&&(i+=";"+a),n.cssText=i,o=kf.test(i)}}else t&&e.removeAttribute("style");Ls in e&&(e[Ls]=o?n.display:"",e[Bl]&&(n.display="none"))}const Gr=/\s*!important$/;function $n(e,t,i){if(Ee(i))i.forEach(n=>$n(e,t,n));else if(i==null&&(i=""),t.startsWith("--"))e.setProperty(t,i);else{const n=xf(e,t);Gr.test(i)?e.setProperty(Ei(n),i.replace(Gr,""),"important"):e[n]=i}}const Kr=["Webkit","Moz","ms"],lo={};function xf(e,t){const i=lo[t];if(i)return i;let n=St(t);if(n!=="filter"&&n in e)return lo[t]=n;n=Ns(n);for(let s=0;s<Kr.length;s++){const o=Kr[s]+n;if(o in e)return lo[t]=o}return t}function Sf(e,t,i,n){return e.tagName==="TEXTAREA"&&(t==="width"||t==="height")&&nt(n)&&i===n}const qr="http://www.w3.org/1999/xlink";function Yr(e,t,i,n,s,o=Md(t)){n&&t.startsWith("xlink:")?i==null?e.removeAttributeNS(qr,t.slice(6,t.length)):e.setAttributeNS(qr,t,i):i==null||o&&!La(i)?e.removeAttribute(t):e.setAttribute(t,o?"":Ht(i)?String(i):i)}function Zr(e,t,i,n,s){if(t==="innerHTML"||t==="textContent"){i!=null&&(e[t]=t==="innerHTML"?Al(i):i);return}const o=e.tagName;if(t==="value"&&o!=="PROGRESS"&&!o.includes("-")){const r=o==="OPTION"?e.getAttribute("value")||"":e.value,l=i==null?e.type==="checkbox"?"on":"":String(i);(r!==l||!("_value"in e))&&(e.value=l),i==null&&e.removeAttribute(t),e._value=i;return}let a=!1;if(i===""||i==null){const r=typeof e[t];r==="boolean"?i=La(i):i==null&&r==="string"?(i="",a=!0):r==="number"&&(i=0,a=!0)}try{e[t]=i}catch{}a&&e.removeAttribute(s||t)}function Si(e,t,i,n){e.addEventListener(t,i,n)}function Cf(e,t,i,n){e.removeEventListener(t,i,n)}const Jr=Symbol("_vei");function _f(e,t,i,n,s=null){const o=e[Jr]||(e[Jr]={}),a=o[t];if(n&&a)a.value=n;else{const[r,l]=Mf(t);if(n){const c=o[t]=Af(n,s);Si(e,r,c,l)}else a&&(Cf(e,r,a,l),o[t]=void 0)}}const $f=/(Once|Passive|Capture)$/,If=/^on:?(?:Once|Passive|Capture)$/;function Mf(e){let t,i;for(;(i=e.match($f))&&!If.test(e);)t||(t={}),e=e.slice(0,e.length-i[1].length),t[i[1].toLowerCase()]=!0;return[e[2]===":"?e.slice(3):Ei(e.slice(2)),t]}let co=0;const Tf=Promise.resolve(),Ef=()=>co||(Tf.then(()=>co=0),co=Date.now());function Af(e,t){const i=n=>{if(!n._vts)n._vts=Date.now();else if(n._vts<=i.attached)return;const s=i.value;if(Ee(s)){const o=n.stopImmediatePropagation;n.stopImmediatePropagation=()=>{o.call(n),n._stopped=!0};const a=s.slice(),r=[n];for(let l=0;l<a.length&&!n._stopped;l++){const c=a[l];c&&jt(c,t,5,r)}}else jt(s,t,5,[n])};return i.value=e,i.attached=Ef(),i}const Xr=e=>e.charCodeAt(0)===111&&e.charCodeAt(1)===110&&e.charCodeAt(2)>96&&e.charCodeAt(2)<123,Bf=(e,t,i,n,s,o)=>{const a=s==="svg";t==="class"?bf(e,n,a):t==="style"?wf(e,i,n):Ps(t)?Os(t)||_f(e,t,i,n,o):(t[0]==="."?(t=t.slice(1),!0):t[0]==="^"?(t=t.slice(1),!1):Df(e,t,n,a))?(Zr(e,t,n),!e.tagName.includes("-")&&(t==="value"||t==="checked"||t==="selected")&&Yr(e,t,n,a,o,t!=="value")):e._isVueCE&&(Lf(e,t)||e._def.__asyncLoader&&(/[A-Z]/.test(t)||!nt(n)))?Zr(e,St(t),n,o,t):(t==="true-value"?e._trueValue=n:t==="false-value"&&(e._falseValue=n),Yr(e,t,n,a))};function Df(e,t,i,n){if(n)return!!(t==="innerHTML"||t==="textContent"||t in e&&Xr(t)&&Be(i));if(t==="spellcheck"||t==="draggable"||t==="translate"||t==="autocorrect"||t==="sandbox"&&e.tagName==="IFRAME"||t==="form"||t==="list"&&e.tagName==="INPUT"||t==="type"&&e.tagName==="TEXTAREA")return!1;if(t==="width"||t==="height"){const s=e.tagName;if(s==="IMG"||s==="VIDEO"||s==="CANVAS"||s==="SOURCE")return!1}return Xr(t)&&nt(i)?!1:t in e}function Lf(e,t){const i=e._def.props;if(!i)return!1;const n=St(t);return Array.isArray(i)?i.some(s=>St(s)===n):Object.keys(i).some(s=>St(s)===n)}const hn=e=>{const t=e.props["onUpdate:modelValue"]||!1;return Ee(t)?i=>us(t,i):t};function Pf(e){e.target.composing=!0}function Qr(e){const t=e.target;t.composing&&(t.composing=!1,t.dispatchEvent(new Event("input")))}const ui=Symbol("_assign");function ea(e,t,i){return t&&(e=e.trim()),i&&(e=zs(e)),e}const Po={created(e,{modifiers:{lazy:t,trim:i,number:n}},s){e[ui]=hn(s);const o=n||s.props&&s.props.type==="number";Si(e,t?"change":"input",a=>{a.target.composing||e[ui](ea(e.value,i,o))}),(i||o)&&Si(e,"change",()=>{e.value=ea(e.value,i,o)}),t||(Si(e,"compositionstart",Pf),Si(e,"compositionend",Qr),Si(e,"change",Qr))},mounted(e,{value:t}){e.value=t??""},beforeUpdate(e,{value:t,oldValue:i,modifiers:{lazy:n,trim:s,number:o}},a){if(e[ui]=hn(a),e.composing)return;const r=(o||e.type==="number")&&!/^0\d/.test(e.value)?zs(e.value):e.value,l=t??"";if(r===l)return;const c=e.getRootNode();(c instanceof Document||c instanceof ShadowRoot)&&c.activeElement===e&&e.type!=="range"&&(n&&t===i||s&&e.value.trim()===l)||(e.value=l)}},as={deep:!0,created(e,t,i){e[ui]=hn(i),Si(e,"change",()=>{const n=e._modelValue,s=Kn(e),o=e.checked,a=e[ui];if(Ee(n)){const r=Ko(n,s),l=r!==-1;if(o&&!l)a(n.concat(s));else if(!o&&l){const c=[...n];c.splice(r,1),a(c)}}else if(mn(n)){const r=new Set(n);o?r.add(s):r.delete(s),a(r)}else a(Dl(e,o))})},mounted:ta,beforeUpdate(e,t,i){e[ui]=hn(i),ta(e,t,i)}};function ta(e,{value:t,oldValue:i},n){e._modelValue=t;let s;if(Ee(t))s=Ko(t,n.props.value)>-1;else if(mn(t))s=t.has(n.props.value);else{if(t===i)return;s=gn(t,Dl(e,!0))}e.checked!==s&&(e.checked=s)}const Of={deep:!0,created(e,{value:t,modifiers:{number:i}},n){e._modelValue=t,Si(e,"change",()=>{const s=Array.prototype.filter.call(e.options,o=>o.selected).map(o=>i?zs(Kn(o)):Kn(o));e[ui](e.multiple?mn(e._modelValue)?new Set(s):s:s[0]),e._assigning=!0,Ms(()=>{e._assigning=!1})}),e[ui]=hn(n)},mounted(e,{value:t}){ia(e,t)},beforeUpdate(e,{value:t},i){e._modelValue=t,e[ui]=hn(i)},updated(e,{value:t}){e._assigning||ia(e,t)}};function ia(e,t){const i=e.multiple,n=Ee(t);if(!(i&&!n&&!mn(t))){for(let s=0,o=e.options.length;s<o;s++){const a=e.options[s],r=Kn(a);if(i)if(n){const l=typeof r;l==="string"||l==="number"?a.selected=t.some(c=>String(c)===String(r)):a.selected=Ko(t,r)>-1}else a.selected=t.has(r);else if(gn(Kn(a),t)){e.selectedIndex!==s&&(e.selectedIndex=s);return}}!i&&e.selectedIndex!==-1&&(e.selectedIndex=-1)}}function Kn(e){return"_value"in e?e._value:e.value}function Dl(e,t){const i=t?"_trueValue":"_falseValue";return i in e?e[i]:t}const Rf=["ctrl","shift","alt","meta"],Nf={stop:e=>e.stopPropagation(),prevent:e=>e.preventDefault(),self:e=>e.target!==e.currentTarget,ctrl:e=>!e.ctrlKey,shift:e=>!e.shiftKey,alt:e=>!e.altKey,meta:e=>!e.metaKey,left:e=>"button"in e&&e.button!==0,middle:e=>"button"in e&&e.button!==1,right:e=>"button"in e&&e.button!==2,exact:(e,t)=>Rf.some(i=>e[`${i}Key`]&&!t.includes(i))},Zt=(e,t)=>{if(!e)return e;const i=e._withMods||(e._withMods={}),n=t.join(".");return i[n]||(i[n]=((s,...o)=>{for(let a=0;a<t.length;a++){const r=Nf[t[a]];if(r&&r(s,t))return}return e(s,...o)}))},zf={esc:"escape",space:" ",up:"arrow-up",left:"arrow-left",right:"arrow-right",down:"arrow-down",delete:"backspace"},Hf=(e,t)=>{const i=e._withKeys||(e._withKeys={}),n=t.join(".");return i[n]||(i[n]=(s=>{if(!("key"in s))return;const o=Ei(s.key);if(t.some(a=>a===o||zf[a]===o))return e(s)}))},Ff=ut({patchProp:Bf},gf);let na;function jf(){return na||(na=qu(Ff))}const lr=((...e)=>{const t=jf().createApp(...e),{mount:i}=t;return t.mount=n=>{const s=Uf(n);if(!s)return;const o=t._component;!Be(o)&&!o.render&&!o.template&&(o.template=s.innerHTML),s.nodeType===1&&(s.textContent="");const a=i(s,!1,Wf(s));return s instanceof Element&&(s.removeAttribute("v-cloak"),s.setAttribute("data-v-app","")),a},t});function Wf(e){if(e instanceof SVGElement)return"svg";if(typeof MathMLElement=="function"&&e instanceof MathMLElement)return"mathml"}function Uf(e){return nt(e)?document.querySelector(e):e}const Vf="slides-config.json",Ii={enableWebServeJump:!1,webServeUrl:"http://127.0.0.1:6806",normalizeHeadingSizes:!1,showUnorderedListMarkers:!0,showOrderedListMarkers:!0},Vt=js({...Ii});function Gf(e){if(!e||typeof e!="object")return{...Ii};const t=e;return{enableWebServeJump:!!t.enableWebServeJump,webServeUrl:typeof t.webServeUrl=="string"&&t.webServeUrl.trim()?t.webServeUrl.trim():Ii.webServeUrl,normalizeHeadingSizes:!!t.normalizeHeadingSizes,showUnorderedListMarkers:t.showUnorderedListMarkers!==void 0?!!t.showUnorderedListMarkers:Ii.showUnorderedListMarkers,showOrderedListMarkers:t.showOrderedListMarkers!==void 0?!!t.showOrderedListMarkers:Ii.showOrderedListMarkers}}function ri(e){if(!e||typeof e!="object")return{...Vt};const t=e;return t.enableWebServeJump!==void 0&&(Vt.enableWebServeJump=!!t.enableWebServeJump),t.webServeUrl!==void 0&&(Vt.webServeUrl=String(t.webServeUrl)),t.normalizeHeadingSizes!==void 0&&(Vt.normalizeHeadingSizes=!!t.normalizeHeadingSizes),t.showUnorderedListMarkers!==void 0&&(Vt.showUnorderedListMarkers=!!t.showUnorderedListMarkers),t.showOrderedListMarkers!==void 0&&(Vt.showOrderedListMarkers=!!t.showOrderedListMarkers),{...Vt}}function Ys(){return{...Vt}}function Ll(e,t,i){const n=(e||Ii.webServeUrl).trim(),s=n.startsWith("http://")||n.startsWith("https://")?n:`http://${n}`,o=(i==null?void 0:i.r)||Math.random().toString(36).slice(2,9).padEnd(7,"0");try{const a=new URL(s);let r=a.pathname.replace(/\/+$/,"");return r.endsWith("/stage/build/desktop")||(r=r?`${r}/stage/build/desktop`:"/stage/build/desktop"),a.pathname=`${r}/`,a.searchParams.set("id",t),i!=null&&i.focus&&a.searchParams.set("focus","1"),a.searchParams.set("r",o),a.toString()}catch{const a=i!=null&&i.focus?"&focus=1":"";return`${s.replace(/\/+$/,"")}/stage/build/desktop/?id=${t}${a}&r=${o}`}}const Li={theme:"default",aspectRatio:"16/9",highlighter:"shiki",defaultTransition:"slide-left",colorSchema:"auto",spacing:"normal",background:"",normalizeHeadingSizes:!1,showUnorderedListMarkers:!0,showOrderedListMarkers:!0};function Kf(e){var s,o,a,r,l,c,d,p;const t=Ys();if(!e)return{...Li,normalizeHeadingSizes:t.normalizeHeadingSizes,showUnorderedListMarkers:t.showUnorderedListMarkers,showOrderedListMarkers:t.showOrderedListMarkers};const i=e[Sr]!==void 0?e[Sr]!=="false":t.showUnorderedListMarkers,n=e[Cr]!==void 0?e[Cr]!=="false":t.showOrderedListMarkers;return{theme:((s=e[Nn])==null?void 0:s.trim())||Li.theme,aspectRatio:((o=e[zn])==null?void 0:o.trim())||Li.aspectRatio,highlighter:((a=e[Ca])==null?void 0:a.trim())||Li.highlighter,defaultTransition:((r=e[Hn])==null?void 0:r.trim())||Li.defaultTransition,colorSchema:((l=e[_a])==null?void 0:l.trim())||Li.colorSchema,spacing:((c=e[xo])==null?void 0:c.trim())||Li.spacing,background:((d=e[ws])==null?void 0:d.trim())||((p=e["slides-background"])==null?void 0:p.trim())||"",normalizeHeadingSizes:t.normalizeHeadingSizes,showUnorderedListMarkers:i,showOrderedListMarkers:n}}function Ki(e){var i,n,s,o,a;const t=(i=e.ial)==null?void 0:i[Ri];return!!(t&&(t==="true"||t==="page"||t==="cover"||t==="end")||e.type==="tb"||e.type==="thematic-break"||e.type==="NodeThematicBreak"||((n=e.markdown)==null?void 0:n.trim())==="---"||((s=e.markdown)==null?void 0:s.trim())==="***"||e.type==="b"&&(((o=e.markdown)==null?void 0:o.trim())==="---"||((a=e.content)==null?void 0:a.trim())==="---"))}function sa(e){const t={};let i="";if(!e)return{frontmatter:t,notes:i};e[ke]&&(t.layout=e[ke].trim()),e[gt]&&(t.transition=e[gt].trim()),e[st]&&(t.background=e[st].trim()),e[Rt]&&(t.image=e[Rt].trim()),e[en]&&(t.class=e[en].trim()),e[Mn]&&(t.spacing=e[Mn].trim()),e[vt]&&(t.layoutRatio=e[vt].trim()),e[tn]&&(t.mask=e[tn].trim()),e[Fi]&&(t.maskRatio=e[Fi].trim()),e[nn]&&(t.maskStyle=e[nn].trim()),e[sn]&&(t.maskInitial=e[sn].trim()),e[Qs]&&(i=e[Qs].trim());for(const[n,s]of Object.entries(e))if(n.startsWith("custom-slides-")&&![ke,vt,tn,Fi,nn,sn,gt,st,Rt,en,Mn,Qs,Ri].includes(n)){const o=n.replace(/^custom-slides-/,"");try{t[o]=JSON.parse(s)}catch{t[o]=s}}return{frontmatter:t,notes:i}}function oa(e){const t={};if(!e)return t;const i=e[qe]??e["slides-note"];i!=null&&i!==""&&i!=="false"&&i!=="0"&&(t.isNote=!0);const n=e[Ze]??e["slides-role"],s=e[st]??e["slides-background"];(n===$a||s==="true"||s==="1")&&(t.isBackground=!0);const o=e[ke]??e["slides-layout"];o===Cs||o===_s?t.imageLayout=o:(n===Cs||n===_s)&&(t.imageLayout=n);const a=e[Ne]??e["custom-slides-clicks"]??e["slides-click"]??e["slides-clicks"];if(a!=null&&(t.clicks=a.trim()),e[Xt])try{const r=JSON.parse(e[Xt]);typeof r=="object"&&r!==null?t.motion={preset:r.preset||r.type||"fade-in",...r}:t.motion={preset:String(r).trim()}}catch{t.motion={preset:e[Xt].trim()}}return e[Gi]&&(t.shikiLines=e[Gi].trim()),e[Fn]&&(t.maxHeight=e[Fn].trim()),e[Me]&&(t.slot=e[Me].trim()),e.style&&e.style.trim()&&(t.style=e.style.trim()),t}function fi(e,t){const i=(e||t||"").trim();if(!i)return null;const n=i.match(/!\[[\s\S]*?\]\(\s*([^\s)]+)(?:\s+(?:=["']?[^"'\s)]*["']?|["'][^"']*["']))*?\s*\)/);if(n)return n[1].trim();const s=i.match(/<img\b[^>]*?\bsrc=["']([^"']+)["']/i);if(s)return s[1].trim();const o=i.replace(/\{:[^}]*\}/g,"").trim();return/^(?:assets\/|https?:\/\/|\/|\.\.?\/)[^\s]+\.(?:png|jpe?g|gif|webp|svg|avif)(?:\?[^\s]*)?$/i.test(o)?o:null}function Ln(e){if(!e)return"";const t=e.split(/\r?\n/);if(t.length===0)return"";const i=t[0],n=i.match(/^(\s*)(?:[-*+]|\d+\.)\s+(.*)$/);if(!n)return e;const s=n[1].length,o=n[2].trim(),a=i.length-n[2].length;if(t.length===1)return o;const r=[o];for(let l=1;l<t.length;l++){const c=t[l];if(!c.trim()){r.push("");continue}const d=c.match(/^(\s*)/),p=d?d[1].length:0;p>=a?r.push(c.slice(a)):p>s?r.push(c.slice(p)):r.push(c)}return r.join(`
`)}function Ti(e){if(!e)return!1;const t=(e.type||"").toLowerCase();if(t==="i"||t==="nodelistitem"||t==="l"||t==="nodelist")return!0;const i=(e.markdown||e.rawMarkdown||e.content||"").trim();return!!/^(?:[-*+]|\d+\.)\s+/.test(i)}function uo(e,t=2){if(!e||typeof e!="string")return`repeat(${t}, 1fr)`;const i=e.trim();if(!i)return`repeat(${t}, 1fr)`;if(i.includes(":")){const s=i.split(":").map(o=>parseFloat(o.trim())).filter(o=>!isNaN(o)&&o>0);if(s.length>=2)return s.map(o=>`${o}fr`).join(" ")}const n=i.split(/\s+/).filter(Boolean);return n.length>=2?n.join(" "):`repeat(${t}, 1fr)`}function Pn(e){if(!e)return[];if(at(e)&&ei(e)&&!ti(e)){const n=bn(e),s=[];for(const o of n)s.push(...Pn(o));return s}const t=(e.type||"").toLowerCase();if(t==="l"||t==="nodelist"||t==="list"){if(e.children&&e.children.length>0){const a=e.children.filter(Ti);if(a.length>0)return a}const s=(e.markdown||e.content||"").trim().split(/\r?\n/),o=[];for(let a=0;a<s.length;a++)/^(?:[-*+]|\d+\.)\s+/.test(s[a])&&o.push(a);if(o.length>=2){const a=[];for(let r=0;r<o.length;r++){const l=o[r],c=r+1<o.length?o[r+1]:s.length,d=s.slice(l,c).join(`
`);a.push({id:`${e.id}-item-${r+1}`,type:"i",markdown:d,content:d,ial:{...e.ial||{}}})}return a}}return Ti(e)?[e]:[]}function cr(e){var s;if(!e||!at(e)||!ei(e)||ti(e))return null;const t=bn(e);if(t.length===0)return null;if(t.length===1&&at(t[0])&&ei(t[0])){const o=cr(t[0]);return o?{items:o.items,nestedSuperBlocks:[t[0],...o.nestedSuperBlocks]}:null}const i=[];for(const o of t)if(at(o)){i.push(o);const a=((s=o.children)==null?void 0:s.filter(at))||[];i.push(...a)}const n=t.map(Pn);if(n.length>=2&&n.every(o=>o.length>0)){const o=n.flat();if(o.length>=2&&o.length<=6)return{items:o,nestedSuperBlocks:i}}if(t.length===2){const o=Pn(t[0]),a=Pn(t[1]);if(o.length+a.length>=2&&o.length+a.length<=6&&(o.length>0||a.length>0))return{items:[...o,...a],nestedSuperBlocks:i}}return null}function qf(e){if(!e||!at(e)||!ei(e)||ti(e))return null;const t=cr(e);if(!t)return null;const{items:i,nestedSuperBlocks:n}=t;if(i.length<2||i.length>6)return null;const s=dr(e)||void 0,o=i.length;return{superBlockNode:e,nestedSuperBlocks:n,count:o,layout:"cols-header",items:i,slots:i.map((a,r)=>`col-${r+1}`),ratio:s}}function Pl(e){if(!e||!at(e)||!ei(e)||ti(e))return null;const t=bn(e);if(t.length===0)return null;const i=[];for(const n of t){const s=Pn(n);if(s.length===0)return null;i.push(...s)}return i}function Yf(e){if(!e||!at(e)||!ei(e)||ti(e))return null;const t=Pl(e);return!t||t.length===0||t.length>=2&&t.length<=6?null:{superBlockNode:e,items:t}}function Zf(e){if(!e||!at(e)||!ei(e)||ti(e))return null;const t=cr(e);if(t&&t.items.length===4)return t.items;const i=Pl(e);if(i&&i.length===4)return i;const n=bn(e);return n.length===4?n:null}function Jf(e,t){if(!e||e.length===0)return null;const i=[];function n(r,l){if(at(r)){const c=Zf(r);c&&c.length===4&&i.push({sbNode:r,items:c,topLevelIndex:l})}if(r.children&&r.children.length>0)for(const c of r.children)n(c,l)}for(let r=0;r<e.length;r++)n(e[r],r);if(i.length===0)return null;let s=null;t&&(s=i.find(r=>{if(r.sbNode.id===t||r.items.some(c=>c.id===t))return!0;const l=c=>c.id===t?!0:c.children?c.children.some(l):!1;return l(r.sbNode)})||null),s||(s=i[0]);const a=e.slice(0,s.topLevelIndex).slice().reverse().find(r=>Ol(r));return{superBlockNode:s.sbNode,items:s.items,headerNode:a}}function Xf(e,t,i){var d,p,u,f,w;const n=[],s=[],o=(i==null?void 0:i.tracked)||[],a=[];let r={pageTargetId:e,blocks:[]};a.push(r);for(let m=0;m<t.length;m++){const y=t[m];if(Ki(y)){if(a.length===1&&r.blocks.length===0){r.pageTargetId=y.id,r.blocks.push(y);continue}r={pageTargetId:y.id,blocks:[y]},a.push(r)}else r.blocks.push(y)}function l(m){const y=[];for(const b of m)at(b)&&y.push(b),b.children&&b.children.length>0&&y.push(...l(b.children));return y}function c(m,y,b){const v={blockId:m,attrs:y,previousAttrs:b};n.push(v),i!=null&&i.onTagChange&&i.onTagChange(v)}for(const m of a){const y=m.pageTargetId,b=t.find(A=>A.id===y),v=o.find(A=>A.pageTargetId===y);if(m.blocks.some(A=>{var C,L;return!!(ti(A)||Oo(A)&&(((C=A.ial)==null?void 0:C[ke])==="image-left"||((L=A.ial)==null?void 0:L[ke])==="image-right"))})){if(v){const A=v.headerId;if(A){c(A,{[Me]:""});const C=t.find(L=>L.id===A);C!=null&&C.ial&&(C.ial[Me]="")}for(const C of v.itemIds){c(C,{[Me]:""});const L=t.find(z=>z.id===C);L!=null&&L.ial&&(L.ial[Me]="")}}continue}let S=null,D=-1;for(let A=0;A<m.blocks.length;A++){const C=m.blocks[A],L=at(C)?[C,...l(C.children||[])]:C.children?l(C.children):[];for(const z of L){const N=qf(z);if(N){S=N,D=A;break}}if(S)break}if(S){const{superBlockNode:A,layout:C,items:L,slots:z}=S,K=m.blocks.slice(0,D).find($=>Ol($)),_=K==null?void 0:K.id,U=((d=b==null?void 0:b.ial)==null?void 0:d[ke])||"",x=U==="clover",q=x?"clover":C;if(U!==q&&(c(y,{[ke]:q},{[ke]:U}),b&&(b.ial||(b.ial={}),b.ial[ke]=q)),K){const $=((p=K.ial)==null?void 0:p[Me])||"";$!=="header"&&(c(K.id,{[Me]:"header"},{[Me]:$}),K.ial||(K.ial={}),K.ial[Me]="header")}if(v!=null&&v.headerId&&v.headerId!==_){c(v.headerId,{[Me]:""});const $=t.find(T=>T.id===v.headerId);$&&($.ial||($.ial={}),$.ial[Me]="")}const O=[];for(let $=0;$<L.length;$++){const T=L[$],P=z[$];O.push(T.id);const se=((u=T.ial)==null?void 0:u[Me])||"";if(se!==P&&(c(T.id,{[Me]:P},{[Me]:se}),T.ial||(T.ial={}),T.ial[Me]=P),T.children&&T.children.length>0)for(const V of T.children)V.ial||(V.ial={}),V.ial[Me]!==P&&(V.ial[Me]=P)}if(v!=null&&v.itemIds){for(const $ of v.itemIds)if(!O.includes($)){c($,{[Me]:""});const T=t.find(P=>P.id===$);T&&(T.ial||(T.ial={}),T.ial[Me]="")}}s.push({superBlockId:A.id,nestedSuperBlockIds:(f=S.nestedSuperBlocks)==null?void 0:f.map($=>$.id),pageTargetId:y,headerId:_,itemIds:O,layout:x?"clover":C})}else{let A=!1;const C=[];for(const N of m.blocks){const K=at(N)?[N,...l(N.children||[])]:N.children?l(N.children):[];for(const _ of K){const U=Yf(_);if(U){A=!0;for(const x of U.items)C.push(x.id)}}}const L=((w=b==null?void 0:b.ial)==null?void 0:w[ke])||"",z=on(L);if(v||A&&z){c(y,{[ke]:""},{[ke]:L}),b&&(b.ial||(b.ial={}),b.ial[ke]="");const N=v==null?void 0:v.headerId;if(N){c(N,{[Me]:""});const _=t.find(U=>U.id===N);_&&(_.ial||(_.ial={}),_.ial[Me]="")}const K=new Set([...(v==null?void 0:v.itemIds)||[],...C]);for(const _ of K){c(_,{[Me]:""});const U=t.find(x=>x.id===_);U&&(U.ial||(U.ial={}),U.ial[Me]="")}}}}return{changes:n,newTracked:s}}function at(e){if(!e)return!1;const t=(e.type||"").toLowerCase();return t==="s"||t==="sb"||t==="nodesuperblock"}function ei(e){if(!at(e))return!1;const t=(e.subType||"").toLowerCase();if(t==="col"||t==="h"||t==="horizontal")return!0;if(t==="row"||t==="v"||t==="vertical")return!1;if(e.ial){const n=(e.ial["data-sb-layout"]||e.ial.layout||"").toLowerCase();if(n==="col"||n==="h")return!0;if(n==="row"||n==="v")return!1}if(e.children&&e.children.length>0){for(const n of e.children)if(n.type==="NodeSuperBlockLayoutMarker"||n.type==="layout-marker"){const s=(n.content||n.markdown||"").trim().toLowerCase();if(s==="col"||s==="h")return!0;if(s==="row"||s==="v")return!1}}const i=(e.markdown||e.content||"").trim();return/^\{\{\{col\b/i.test(i)?!0:!/^\{\{\{row\b/i.test(i)}function Oo(e){return!e||Ti(e)||at(e)||!fi(e.markdown,e.content)?!1:(e.markdown||e.content||"").replace(/!\[.*?\]\([^)]+\)/g,"").replace(/<img\b[^>]*>/gi,"").replace(/\{:[^}]*\}/g,"").trim().length<=25}function dr(e){var u;if(!e||!at(e)||!ei(e))return null;const t=bn(e);if(!t||t.length<2)return null;const i=[];let n=!1;for(const f of t){const w=(((u=f.ial)==null?void 0:u.style)||f.style||"").trim();let m=null;if(w){const y=w.match(/calc\(\s*([\d.]+)%/i);if(y)m=parseFloat(y[1]);else{const b=w.match(/(?:^|;|\s)width:\s*([\d.]+)%/i);b&&(m=parseFloat(b[1]))}}m!==null&&!isNaN(m)&&m>0?(i.push(m),n=!0):i.push(null)}if(!n)return null;const s=t.length,o=i.reduce((f,w)=>f+(w||0),0),a=i.filter(f=>f===null).length,r=Math.max(0,100-o),l=a>0?r/a:100/s,c=i.map(f=>f!==null?f:l),d=c.reduce((f,w)=>f+w,0);if(d<=0)return null;const p=c.map(f=>f/d*100);if(p.length===2){const[f]=p;if(f>=48&&f<=52)return"1:1";if(f>=31&&f<=35)return"1:2";if(f>=65&&f<=69)return"2:1";if(f>=28&&f<=32)return"3:7";if(f>=68&&f<=72)return"7:3";if(f>=38&&f<=42)return"4:6";if(f>=58&&f<=62)return"6:4";if(f>=23&&f<=27)return"1:3";if(f>=73&&f<=77)return"3:1";const w=Math.round(f),m=100-w;return`${w}:${m}`}if(p.length===3){const[f,w,m]=p;if(f>=31&&f<=35&&w>=31&&w<=35&&m>=31&&m<=35)return"1:1:1";if(f>=23&&f<=27&&w>=48&&w<=52&&m>=23&&m<=27)return"1:2:1";if(f>=48&&f<=52&&w>=23&&w<=27&&m>=23&&m<=27)return"2:1:1";if(f>=23&&f<=27&&w>=23&&w<=27&&m>=48&&m<=52)return"1:1:2";if(f>=18&&f<=22&&w>=58&&w<=62&&m>=18&&m<=22)return"1:3:1";const y=Math.round(f),b=Math.round(w),v=100-y-b;return`${y}:${b}:${v}`}return p.map(f=>Math.round(f)).join(":")}function ti(e){if(!e||!at(e)||!ei(e))return null;const t=(e.children||[]).filter(o=>{const a=o.type||"";if(a==="NodeSuperBlockOpenMarker"||a==="NodeSuperBlockLayoutMarker"||a==="NodeSuperBlockCloseMarker"||a==="open-marker"||a==="layout-marker"||a==="close-marker")return!1;const r=(o.markdown||o.content||"").trim();return!(/^\{\{\{(?:col|row)?\s*$/i.test(r)||r==="}}}")});if(t.length<2)return null;const i=Oo(t[0]),n=Oo(t[t.length-1]),s=dr(e)||void 0;if(i&&!n){const o=fi(t[0].markdown,t[0].content);if(o)return{imageNode:t[0],imageUrl:o,layout:Cs,contentNodes:t.slice(1),ratio:s}}if(!i&&n){const o=fi(t[t.length-1].markdown,t[t.length-1].content);if(o)return{imageNode:t[t.length-1],imageUrl:o,layout:_s,contentNodes:t.slice(0,t.length-1),ratio:s}}return null}function Qf(e,t){const i=[];function n(s){for(const o of s){const a=ti(o);if(a){const{imageNode:r,layout:l,ratio:c}=a;r.ial||(r.ial={});const d=r.ial[ke];if(d!==l){const u={blockId:r.id,layout:l,previousLayout:d,ratio:c};r.ial[ke]=l,i.push(u),t&&t(u)}}o.children&&o.children.length>0&&n(o.children)}}return n(e),i}function bn(e){return(e.children||[]).filter(t=>{const i=t.type||"";if(i==="NodeSuperBlockOpenMarker"||i==="NodeSuperBlockLayoutMarker"||i==="NodeSuperBlockCloseMarker"||i==="open-marker"||i==="layout-marker"||i==="close-marker")return!1;const n=(t.markdown||t.content||"").trim();return!(/^\{\{\{(?:col|row)?\s*$/i.test(n)||n==="}}}")})}function Ol(e){if(!e)return!1;const t=(e.type||"").toLowerCase();if(t==="h"||t==="nodeheading"||/^h[1-6]$/i.test(e.subType||""))return!0;const i=(e.markdown||e.content||"").trim();return!!/^#{1,6}\s+/.test(i)}function Pi(e,t,i){let n="",s=0;const o=/<div\b([^>]*)>/gi;for(;s<e.length;){o.lastIndex=s;let a,r=!1,l=-1,c=0;for(;(a=o.exec(e))!==null;){const b=a[1].match(/\bclass=["']([^"']*)["']/i);if(b){const v=b[1];if(typeof t=="string"?v.split(/\s+/).includes(t):t.test(v)){r=!0,l=a.index,c=a[0].length;break}}}if(!r){n+=e.slice(s);break}n+=e.slice(s,l);const d=l+c;let p=1,u=-1,f=-1;const w=/<\/?div\b[^>]*>/gi;w.lastIndex=d;let m;for(;(m=w.exec(e))!==null;)if(m[0].startsWith("</")){if(p--,p===0){u=m.index,f=m.index+m[0].length;break}}else p++;if(u!==-1&&f!==-1){const y=e.slice(d,u);n+=i(y),s=f}else n+=e.slice(l,d),s=d}return n}function ep(e){const t=[];let i="",n=0;const s=/<div\b([^>]*)>/gi;for(;n<e.length;){s.lastIndex=n;let o,a=!1,r=-1,l=0;for(;(o=s.exec(e))!==null;){const m=o[1];if(/(?:\s@[a-zA-Z0-9_-]+=\s*["']|\s:[a-zA-Z0-9_-]+=\s*["']|\sv-[a-zA-Z0-9_.-]+|\shover:[a-zA-Z0-9_.-]+=\s*["']|\sgrid=["']~|\bclass=["'][^"']*\b(?:abs-br|slidev-icon-btn|grid\s+|grid$|grid-cols-|relative\b)\b[^"']*["']|\bstyle=["'][^"']*\bgrid-[^"']*["'])/i.test(m)){a=!0,r=o.index,l=o[0].length;break}}if(!a){i+=e.slice(n);break}i+=e.slice(n,r);const c=r+l;let d=1,p=-1,u=-1;const f=/<\/?div\b[^>]*>/gi;f.lastIndex=c;let w;for(;(w=f.exec(e))!==null;)if(w[0].startsWith("</")){if(d--,d===0){p=w.index,u=w.index+w[0].length;break}}else d++;if(p!==-1&&u!==-1){const m=e.slice(r,u),y=`__VUE_DIV_TOKEN_${t.length}__`;t.push(m),i+=y,n=u}else i+=e.slice(r,c),n=c}return{text:i,tokens:t}}function tp(e){const t=[];let i=e.replace(/(?:^[ \t]*(`{3,}|~{3,})[^\n\r]*\r?\n[\s\S]*?\r?\n[ \t]*\1(?=[ \t]*(?:\r?\n|$)))/gm,r=>{const l=`__CODE_TOKEN_${t.length}__`;return t.push(r),l});i=i.replace(/(`+)(?:[^\n\r`]|(?!\1)`)+?\1/g,r=>{const l=`__CODE_TOKEN_${t.length}__`;return t.push(r),l});const n=[];i=i.replace(/<script\b[^>]*>[\s\S]*?<\/script>/gi,r=>{const l=`__SCRIPT_TOKEN_${n.length}__`;return n.push(r),l});const{text:s,tokens:o}=ep(i);i=s;const a=[];i=i.replace(/<(?:[A-Z][a-zA-Z0-9_-]*|[a-z0-9_-]+:[a-z0-9_-]+|v-[a-z0-9_-]+|arrow\b|div\s+h-\d+)\b[^>]*\/>/gi,r=>{const l=`__VUE_COMP_TOKEN_${a.length}__`;return a.push(r),l}),i=i.replace(/<(v-[a-z0-9_-]+|button)\b([^>]*)>([\s\S]*?)<\/\1>/gi,r=>{const l=`__VUE_COMP_TOKEN_${a.length}__`;return a.push(r),l}),i=i.replace(/<img\b[^>]*?\bv-[a-z0-9_.-]+[^>]*\/?>/gi,r=>{const l=`__VUE_COMP_TOKEN_${a.length}__`;return a.push(r),l}),i=i.replace(/<(p|span)\b([^>]*?\bv-[a-z0-9_.-]+[^>]*)>([\s\S]*?)<\/\1>/gi,r=>{const l=`__VUE_COMP_TOKEN_${a.length}__`;return a.push(r),l}),i=i.replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi,""),i=i.replace(/<div class="terminal-bar">[\s\S]*?<\/div>/gi,""),i=i.replace(/<div class="cursor-line">[\s\S]*?<\/div>/gi,""),i=i.replace(/<span class="cursor">[\s\S]*?<\/span>/gi,""),i=i.replace(/<div class="stamp">\s*([\s\S]*?)\s*<\/div>/gi,`

*[$1]*

`),i=i.replace(/<div class="arrow">\s*([→\->]+)\s*<\/div>/gi,`

$1

`),i=i.replace(/<i>\s*[→\->]+\s*<\/i>/gi,""),i=i.replace(/<div class="prompt">\s*([\s\S]*?)\s*<\/div>/gi,(r,l)=>`
\`\`\`bash
${l.trim()}
\`\`\`
`),i=i.replace(/<p>\s*<i>\$<\/i>\s*([\s\S]*?)<\/p>/gi,(r,l)=>`
\`\`\`bash
$ ${l.trim()}
\`\`\`
`),i=i.replace(/<div class="statusline">\s*([\s\S]*?)\s*<\/div>/gi,(r,l)=>`
> ${Array.from(l.matchAll(/<span>([\s\S]*?)<\/span>/gi)).map(d=>`\`${d[1].trim()}\``).join(" | ")}
`),i=i.replace(/<div class="log-panel">\s*<pre>([\s\S]*?)<\/pre>\s*<\/div>/gi,(r,l)=>`
\`\`\`log
${l.replace(/<span[^>]*>([\s\S]*?)<\/span>/gi,"$1").trim()}
\`\`\`
`),i=Pi(i,"diff-grid",r=>{const l=Array.from(r.matchAll(/<div class="diff\s+([^"]*)">\s*<span>(.*?)<\/span>\s*<pre>([\s\S]*?)<\/pre>\s*<\/div>/gi));return l.length>0?`
`+l.map(c=>{const d=c[2].trim().toUpperCase(),p=c[3].trim();return`**${d}:**
\`\`\`yaml
${p}
\`\`\``}).join(`

`)+`
`:r}),i=Pi(i,"before-after",r=>{const l=r.match(/<div class="before">[\s\S]*?<small>(.*?)<\/small>[\s\S]*?<h2>(.*?)<\/h2>[\s\S]*?<p>(.*?)<\/p>\s*<\/div>/i),c=r.match(/<div class="after">[\s\S]*?<small>(.*?)<\/small>[\s\S]*?<h2>(.*?)<\/h2>[\s\S]*?<p>(.*?)<\/p>\s*<\/div>/i);let d=`
`;return l&&(d+=`### ${l[1]}
## ${l[2]}
${l[3]}

`),c&&(d+=`### ${c[1]}
## ${c[2]}
${c[3]}
`),d.trim()?d:r}),i=i.replace(/<ul\b[^>]*>([\s\S]*?)<\/ul>/gi,(r,l)=>{const c=Array.from(l.matchAll(/<li>\s*(?:<em>)?(\[[x ]\])(?:<\/em>)?\s*([\s\S]*?)<\/li>/gi));return c.length>0?`
`+c.map(d=>`- ${d[1]} ${d[2].trim()}`).join(`
`)+`
`:l}),i=Pi(i,"timeline",r=>{const l=Array.from(r.matchAll(/<div(?:\s+class="([^"]*)")?>\s*<time>([\s\S]*?)<\/time>\s*<b>([\s\S]*?)<\/b>\s*<span>([\s\S]*?)<\/span>\s*<\/div>/gi));return l.length>0?`

`+l.map(c=>{const d=c[1]||"";let p="-";return d.includes("warn")?p="- ⚠️":d.includes("bad")?p="- ❌":d.includes("ok")&&(p="- ✅"),`${p} **${c[2].trim()}** **${c[3].trim()}** — ${c[4].trim()}`}).join(`
`)+`

`:r}),i=Pi(i,"pipeline",r=>{const l=Array.from(r.matchAll(/<div(?:\s+class="([^"]*)")?>\s*<small>([\s\S]*?)<\/small>\s*<b>([\s\S]*?)<\/b>\s*<span>([\s\S]*?)<\/span>\s*<\/div>/gi));return l.length>0?`

`+l.map((c,d)=>{const u=(c[1]||"").includes("hot")?"⚠️ ":"";return`${d+1}. ${u}**${c[3].trim()}** (*${c[4].trim()}*)`}).join(`
`)+`

`:r}),i=Pi(i,"check-grid",r=>{const l=Array.from(r.matchAll(/<div>\s*<span class="([^"]*)"><\/span>\s*<b>([\s\S]*?)<\/b>\s*<p>([\s\S]*?)<\/p>\s*<\/div>/gi));return l.length>0?`

`+l.map(c=>`- ${(c[1]||"").includes("warn")?"⚠️":"✅"} **${c[2].trim()}**: ${c[3].trim()}`).join(`
`)+`

`:r}),i=Pi(i,"manifesto",r=>{const l=Array.from(r.matchAll(/<div>\s*<span>([\s\S]*?)<\/span>\s*<h2>([\s\S]*?)<\/h2>\s*<p>([\s\S]*?)<\/p>\s*<\/div>/gi));return l.length>0?`

`+l.map(c=>`## ${c[1].trim()} ${c[2].trim()}

${c[3].trim()}`).join(`

`)+`

`:r}),i=Pi(i,"split-note",r=>{const l=Array.from(r.matchAll(/<div>\s*<b>([\s\S]*?)<\/b>\s*<p>([\s\S]*?)<\/p>\s*<\/div>/gi));return l.length>0?`

`+l.map(c=>`> **${c[1].trim()}**: ${c[2].trim()}`).join(`
>
`)+`

`:r}),i=i.replace(/<div class="mechanism">\s*<b>([\s\S]*?)<\/b>\s*<p>([\s\S]*?)<\/p>\s*<\/div>/gi,(r,l,c)=>`

> **${l.trim()}**: ${c.trim()}

`),i=i.replace(/<pre>([\s\S]*?)<\/pre>/gi,(r,l)=>`
\`\`\`text
${l.replace(/<span[^>]*>([\s\S]*?)<\/span>/gi,"$1").trim()}
\`\`\`
`),i=i.replace(/<div class="page-head">\s*<span>([\s\S]*?)<\/span>\s*<b>([\s\S]*?)<\/b>\s*<\/div>/gi,`
### $1 ($2)
`),i=i.replace(/<h1\b[^>]*>([\s\S]*?)<\/h1>/gi,`
# $1
`),i=i.replace(/<h2\b[^>]*>([\s\S]*?)<\/h2>/gi,`
## $1
`),i=i.replace(/<h3\b[^>]*>([\s\S]*?)<\/h3>/gi,`
### $1
`),i=i.replace(/<h4\b[^>]*>([\s\S]*?)<\/h4>/gi,`
#### $1
`),i=i.replace(/<p\s+class="ok">\s*●\s*([\s\S]*?)<\/p>/gi,`
✅ **$1**
`),i=i.replace(/<p\s+class="caption">\s*([\s\S]*?)<\/p>/gi,`
> *$1*
`),i=i.replace(/<p\s+class="lead">\s*([\s\S]*?)<\/p>/gi,`
*$1*
`),i=i.replace(/<p\b([^>]*)>([\s\S]*?)<\/p>/gi,(r,l,c)=>/@|v-|:|class=/i.test(l)?r:`
${c.trim()}

`),i=i.replace(/<br\s*\/?>/gi,`
`),i=i.replace(/<hr\s*\/?>/gi,`
---
`),i=i.replace(/<b\b[^>]*>([\s\S]*?)<\/b>/gi,"**$1**"),i=i.replace(/<strong\b[^>]*>([\s\S]*?)<\/strong>/gi,"**$1**"),i=i.replace(/<i\b[^>]*>([\s\S]*?)<\/i>/gi,"*$1*"),i=i.replace(/<code\b[^>]*>([\s\S]*?)<\/code>/gi,(r,l)=>{if(l.startsWith("`")&&l.endsWith("`"))return l;if(l.includes("`")){const c=(l.match(/`+/g)||[]).reduce((p,u)=>Math.max(p,u.length),0),d="`".repeat(c+1);return`${d} ${l} ${d}`}return`\`${l}\``}),i=i.replace(/<small\b[^>]*>([\s\S]*?)<\/small>/gi,"*$1*"),i=i.replace(/\*{4}/g,"** **"),i=i.replace(/<li\b[^>]*>([\s\S]*?)<\/li>/gi,`- $1
`),i=i.replace(/<ul\b[^>]*>([\s\S]*?)<\/ul>/gi,`
$1
`),i=i.replace(/<ol\b[^>]*>([\s\S]*?)<\/ol>/gi,`
$1
`),i=i.replace(/<a\b([^>]*)href=["'](.*?)["']([^>]*)>([\s\S]*?)<\/a>/gi,(r,l,c,d,p)=>{const u=p.trim();return u.includes("<")||u.includes(`
`)?r:`[${u}](${c})`}),i=i.replace(/<blockquote\b[^>]*>([\s\S]*?)<\/blockquote>/gi,(r,l)=>`
`+l.trim().split(`
`).map(c=>`> ${c.trim()}`).join(`
`)+`
`),i=i.replace(/<span\b[^>]*data-type=["']block-ref["'][^>]*data-id=["']([0-9a-zA-Z-]+)["'][^>]*>([\s\S]*?)<\/span>/gi,(r,l,c)=>{const d=c.replace(/<[^>]+>/g,"").trim();return d?`((${l} '${d}'))`:`((${l}))`}),i=i.replace(/<span\b[^>]*data-type=["']a["'][^>]*data-href=["']([^"']+)["'][^>]*>([\s\S]*?)<\/span>/gi,(r,l,c)=>`[${c.replace(/<[^>]+>/g,"").trim()}](${l})`),i=i.replace(/<\/(?:div|section|header|footer|main|article|nav|aside)\b[^>]*>/gi,`
`),i=i.replace(/<(?:div|section|header|footer|main|article|nav|aside)\b[^>]*>/gi,""),i=i.replace(/<\/?span\b[^>]*>/gi,"");for(let r=0;r<a.length;r++)i=i.replace(`__VUE_COMP_TOKEN_${r}__`,()=>a[r]);for(let r=0;r<o.length;r++)i=i.replace(`__VUE_DIV_TOKEN_${r}__`,()=>o[r]);for(let r=0;r<n.length;r++)i=i.replace(`__SCRIPT_TOKEN_${r}__`,()=>n[r]);for(let r=0;r<t.length;r++)i=i.replace(`__CODE_TOKEN_${r}__`,()=>t[r]);return i=i.replace(/\n{3,}/g,`

`).trim(),i}function Rl(e){if(!e||typeof e!="string")return"";const t=[];let i=e.replace(/`([^`]+)`/g,n=>(t.push(n),`%%INLINE_CODE_${t.length-1}%%`));return i=i.replace(/(<\/[a-zA-Z0-9_-]+>)\s*\{:[^}]*\}/g,"$1"),i=i.replace(/(\[[^\]]+\]\([^)]+\))\s*\{:\s*style=["']([^"']*)["'][^}]*\}/g,'<span style="$2">$1</span>'),i=i.replace(/(\*\*[^*]+\*\*)\s*\{:\s*style=["']([^"']*)["'][^}]*\}/g,'<span style="$2">$1</span>'),i=i.replace(/(\*[^*]+\*)\s*\{:\s*style=["']([^"']*)["'][^}]*\}/g,'<span style="$2">$1</span>'),i=i.replace(/(~~[^~]+~~)\s*\{:\s*style=["']([^"']*)["'][^}]*\}/g,'<span style="$2">$1</span>'),i=i.replace(/([\p{L}\p{N}_\-]+)\s*\{:\s*style=["']([^"']*)["'][^}]*\}/gu,'<span style="$2">$1</span>'),i=i.replace(/\{:[^}]*\}/g,""),i=i.replace(/%%INLINE_CODE_(\d+)%%/g,(n,s)=>t[parseInt(s,10)]||""),i}function ip(e){const t=Object.entries(e).filter(([n,s])=>s!=null&&s!=="");return t.length===0?"":`---
${t.map(([n,s])=>typeof s=="string"?s.includes(":")||s.includes(`
`)||s.includes("#")?`${n}: "${s.replace(/"/g,'\\"')}"`:`${n}: ${s}`:`${n}: ${JSON.stringify(s)}`).join(`
`)}
---`}function np(e,t){if(!t||!e.startsWith("```"))return e;const i=e.indexOf(`
`);if(i===-1)return e;const n=e.slice(0,i).trim(),s=e.slice(i);return n.includes("{")?e:`${n} {${t}}${s}`}function Nl(e,t){if(t==null)return e;const i=t.trim();return i===""||i==="+1"?`<v-click>

${e}

</v-click>`:i==="hide"?`<v-click hide>

${e}

</v-click>`:`<v-click at="${i}">

${e}

</v-click>`}function sp(e){if(!e||!e.preset)return null;const t=e.preset.toLowerCase().trim();if(!t||t==="none")return null;let i={opacity:0},n={opacity:1};switch(t){case"slide-up":i={y:40,opacity:0},n={y:0,opacity:1};break;case"slide-down":i={y:-40,opacity:0},n={y:0,opacity:1};break;case"slide-left":i={x:40,opacity:0},n={x:0,opacity:1};break;case"slide-right":i={x:-40,opacity:0},n={x:0,opacity:1};break;case"zoom-in":case"pop":i={scale:.8,opacity:0},n={scale:1,opacity:1};break;case"bounce":i={y:40,opacity:0},n={y:0,opacity:1,transition:{type:"spring",damping:10,stiffness:100}};break;case"fade-in":default:i={opacity:0},n={opacity:1};break}e.initial&&typeof e.initial=="object"&&(i={...i,...e.initial}),e.enter&&typeof e.enter=="object"&&(n={...n,...e.enter});const s={...n.transition||{}};return typeof e.duration=="number"&&e.duration>0&&(s.duration=e.duration),typeof e.delay=="number"&&e.delay>0&&(s.delay=e.delay),Object.keys(s).length>0&&(n.transition=s),{initial:i,enter:n}}function ls(e,t,i,n,s){const o=t!=null&&t.trim()!=="",a=sp(i),r=s?/^\d+$/.test(s.trim())?`${s.trim()}px`:s.trim():"",l=r?`max-height:${r};overflow-y:auto`:"",c=[n==null?void 0:n.trim(),l].filter(Boolean).join(";"),d=c!==void 0&&c!=="",p=d?` style="${c.replace(/"/g,"&quot;")}" class="slide-styled-block"`:"";if(!o&&!a)return d?`<div${p}>

${e}

</div>`:e;if(o&&!a){if(d){const b=t.trim();let v="v-click";return b==="hide"?v="v-click.hide":b!==""&&b!=="+1"&&(v=`v-click="${b}"`),`<div ${v}${p}>

${e}

</div>`}return Nl(e,t)}const u=JSON.stringify(a.initial).replace(/"/g,"'"),f=JSON.stringify(a.enter).replace(/"/g,"'"),w=`v-motion :initial="${u}" :enter="${f}"`;if(!o)return`<div ${w}${p}>

${e}

</div>`;const m=t.trim();let y="v-click";return m==="hide"?y="v-click.hide":m!==""&&m!=="+1"&&(y=`v-click="${m}"`),`<div ${y} ${w}${p}>

${e}

</div>`}function ur(e){if(!e)return"";let t=e.trim();t=t.replace(/\{:[^}]*\}/g,"").trim(),t=t.replace(/^:::\s*[a-zA-Z0-9_-]*\s*\r?\n?/g,""),t=t.replace(/\r?\n?:::\s*$/g,"");let s=t.split(/\r?\n/).map(o=>o.trim().replace(/^>\s*/,"")).join(`
`).trim();return s=s.replace(/^\[!(?:NOTE|TIP|IMPORTANT|WARNING|CAUTION|[A-Za-z_-]+)\][^\r\n]*(?:\r?\n)?/i,"").trim(),s=s.replace(/^(?:💡|✏️|❗|⚠️|🚨|\s*)*(?:\*\*|__)?(?:演讲备注|演讲者提词|讲稿备注|演讲提词|备注|Notes?)(?:\*\*|__)?[:：]?\s*(?:\r?\n)?/i,"").trim(),s=s.replace(/^[-*+]\s+/,""),s=s.replace(/^\d+\.\s+/,""),s.trim()}function op(e){var n;if(e.subType&&/^h([1-6])$/i.test(e.subType))return parseInt(e.subType.slice(1),10);const i=(e.markdown||e.content||"").trim().match(/^(#{1,6})\s+/);return i?i[1].length:e.type==="h"?(n=e.ial)!=null&&n.subType&&/^h([1-6])$/i.test(e.ial.subType)?parseInt(e.ial.subType.slice(1),10):1:null}function zl(e,t=2){const i=Math.max(2,t);if(!e||e.length===0)return Array.from({length:i},()=>[]);if(e.length===1&&e[0].children&&e[0].children.length>=2){const c=e[0].children,d=Array.from({length:i},()=>[]),p=Math.min(i,c.length),u=Math.floor(c.length/p),f=c.length%p;let w=0;for(let m=0;m<p;m++){const y=u+(m<f?1:0);d[m]=c.slice(w,w+y),w+=y}return d}if(e.length===1){const c=e[0],p=(c.slot||"").trim().match(/^col-(\d+)$/i),u=p?parseInt(p[1],10):null,f=(c.rawMarkdown||c.content||"").trim(),w=f.split(/\r?\n/),m=[];for(let v=0;v<w.length;v++)/^[ \t]*[-*+]\s+|^[ \t]*\d+\.\s+/.test(w[v])&&m.push(v);if(m.length>=i){const v=Array.from({length:i},()=>[]);let k=0;for(let S=0;S<i;S++){const D=i-S,A=m.length-k,C=Math.ceil(A/D),L=m[k],z=k+C<m.length?m[k+C]:w.length,N=w.slice(L,z).join(`
`);v[S]=[{...c,id:S===0?c.id:`${c.id}-col${S+1}`,rawMarkdown:N,content:N}],k+=C}return v}const y=f.match(/<li[\s\S]*?<\/li>/gi);if(y&&y.length>=i){const v=Array.from({length:i},()=>[]);let k=0;for(let S=0;S<i;S++){const D=i-S,A=y.length-k,C=Math.ceil(A/D),L=`<ul>
${y.slice(k,k+C).join(`
`)}
</ul>`;v[S]=[{...c,id:S===0?c.id:`${c.id}-col${S+1}`,rawMarkdown:L,content:L}],k+=C}return v}const b=f.split(/\r?\n\s*\r?\n/).filter(v=>v.trim()!=="");if(b.length>=i){const v=Array.from({length:i},()=>[]);let k=0;for(let S=0;S<i;S++){const D=i-S,A=b.length-k,C=Math.ceil(A/D),L=b.slice(k,k+C).join(`

`);v[S]=[{...c,id:S===0?c.id:`${c.id}-col${S+1}`,rawMarkdown:L,content:L}],k+=C}return v}if(u&&u>=1&&u<=i){const v=Array.from({length:i},()=>[]);return v[u-1]=[c],v}return[[c],...Array.from({length:i-1},()=>[])]}const n=c=>{const d=(c.slot||"").trim();if(!d)return null;if(d==="left")return 1;if(d==="center")return 2;if(d==="right")return i===2?2:i;const p=d.match(/^col-(\d+)$/i);if(p){const u=parseInt(p[1],10);if(u>=1&&u<=i)return u}return null},s=e.map(n);if(s.some(c=>c!==null)){if(s.some(f=>f!==null&&f>=2)){const f=Array.from({length:i},()=>[]);let w=1;for(const y of e){const b=n(y);b!==null&&(w=b),f[w-1].push(y)}if(!e.some(y=>/^col-\d+$/i.test((y.slot||"").trim()))&&f[0].length===0){const y=f.filter(b=>b.length>0);if(y.length===1)return[y[0],...Array.from({length:i-1},()=>[])]}return f}const d=e.filter(f=>n(f)===1),p=e.filter(f=>n(f)===null),u=i-1;if(p.length>=u){const f=Math.floor(p.length/u),w=p.length%u,m=[d];let y=0;for(let b=0;b<u;b++){const v=f+(b<w?1:0);m.push(p.slice(y,y+v)),y+=v}return m}else if(p.length>0){const f=[d];for(let w=0;w<u;w++)f.push(w<p.length?[p[w]]:[]);return f}else return[d,...Array.from({length:u},()=>[])]}const a=c=>{if(c.type==="h"||c.subType&&/^h[1-6]$/i.test(c.subType))return!0;const d=(c.rawMarkdown||c.content||"").trim();return/^#{1,6}\s+/.test(d)},r=e.map((c,d)=>a(c)?d:-1).filter(c=>c!==-1);if(r.length>=i){const c=Array.from({length:i},()=>[]);for(let d=0;d<i;d++){const p=r[d],u=d+1<i?r[d+1]:e.length;c[d]=e.slice(p,u)}return c}if(e.length>=i){const c=Array.from({length:i},()=>[]);let d=0;for(let p=0;p<i;p++){const u=i-p,f=e.length-d,w=Math.ceil(f/u);c[p]=e.slice(d,d+w),d+=w}return c}if(e.length>1&&e.length<i){const c=Array.from({length:i},()=>[]);for(let d=0;d<e.length;d++)c[d]=[e[d]];return c}const l=Array.from({length:i},()=>[]);return l[0]=e,l}function ra(e,t,i,n){var w;const s=Kf(t),o=[],a=sa(t),r=s.background?_t(s.background,n):void 0;let l={pageIndex:1,startBlockId:e,frontmatter:{layout:a.frontmatter.layout||"cover",...a.frontmatter,...r?{background:r}:{}},notes:"",noteBlocks:[],blocks:[],rawMarkdown:"",allBlockIds:[e]};l.frontmatter.background&&(l.frontmatter.background=_t(l.frontmatter.background,n)),l.frontmatter.image&&(l.frontmatter.image=_t(l.frontmatter.image,n));const c=m=>{const y=[];for(let b=m;b<i.length&&!(b>m&&Ki(i[b]));b++)y.push(i[b]);return y},d=m=>{let y,b,v;const k=S=>{var z;if(y)return;const D=ti(S);if(D){y=D.layout,b=D.imageUrl,v=D.ratio;return}const A=xr(S),C=S.ial?{...S.ial}:{},L=oa(C);if(L.imageLayout==="image-left"||L.imageLayout==="image-right"){const N=fi(A,S.content);if(N){y=L.imageLayout,b=N,v=(z=S.ial)==null?void 0:z[vt];return}}if(S.children&&S.children.length>0){for(const N of S.children)if(k(N),y)return}};for(const S of m)if(k(S),y)break;return{foundLayout:y,foundImage:b,foundRatio:v}},p=(m,y)=>{const{foundLayout:b,foundImage:v,foundRatio:k}=d(y);b&&(m.frontmatter.layout=b,v&&(m.frontmatter.image=_t(v,n)),k&&!m.frontmatter.layoutRatio&&(m.frontmatter.layoutRatio=k))};p(l,c(0)),o.push(l);let u=[];for(let m=0;m<i.length;m++){const y=i[m];if(Ki(y)){u=[];const v=sa(y.ial);if(o.length===1&&l.blocks.length===0){l.startBlockId=y.id,l.allBlockIds||(l.allBlockIds=[]),l.allBlockIds.includes(y.id)||l.allBlockIds.push(y.id),v.frontmatter.layout&&(l.frontmatter.layout=v.frontmatter.layout),Object.assign(l.frontmatter,v.frontmatter),delete l.frontmatter.background,!v.frontmatter.image&&a.frontmatter.image&&(l.frontmatter.image=a.frontmatter.image),r&&(l.frontmatter.background=r),l.frontmatter.background&&(l.frontmatter.background=_t(l.frontmatter.background,n)),l.frontmatter.image&&(l.frontmatter.image=_t(l.frontmatter.image,n)),p(l,c(m+1));continue}l={pageIndex:o.length+1,startBlockId:y.id,frontmatter:{layout:v.frontmatter.layout||"default",...v.frontmatter,...r?{background:r}:{}},notes:"",noteBlocks:[],blocks:[],rawMarkdown:"",allBlockIds:[y.id]},r||delete l.frontmatter.background,l.frontmatter.background&&(l.frontmatter.background=_t(l.frontmatter.background,n)),l.frontmatter.image&&(l.frontmatter.image=_t(l.frontmatter.image,n)),p(l,c(m+1)),o.push(l);continue}const b=(v,k)=>{var oe,Se,Ie,_e,fe,X,pe;if(l.allBlockIds||(l.allBlockIds=[]),v.id&&!l.allBlockIds.includes(v.id)&&l.allBlockIds.push(v.id),v.children&&v.children.length>0){const E=F=>{for(const g of F)g.id&&!l.allBlockIds.includes(g.id)&&l.allBlockIds.push(g.id),g.children&&g.children.length>0&&E(g.children)};E(v.children)}let S=xr(v),D=v.ial?{...v.ial}:{};const A=S.match(/\{:\s*([^}]+)\s*\}\s*$/);A&&(D={...xa(A[0]),...D},S=S.slice(0,A.index).trim()),v.type!=="c"&&!S.startsWith("```")&&(S=Rl(S));let C=S.trim();if(/^\{\{\{(?:row|col)?\s*$/i.test(C)||C==="}}}")return;/^\{\{\{(?:row|col)?\s*\r?\n/i.test(C)&&/\r?\n\}\}\}$/.test(C)&&(S=C.replace(/^\{\{\{(?:row|col)?\s*\r?\n/i,"").replace(/\r?\n\}\}\}$/,"").trim(),C=S.trim());const L=oa(D);if(S=bd(S,n),S=gd(S,n==null?void 0:n.refContentMap),v.children&&v.children.length>0){const E=["custom-slides-autoplay","custom-slides-loop","custom-slides-muted","custom-slides-controls"],F=g=>{for(const W of g){if(W.ial)for(const[j,M]of Object.entries(W.ial))E.includes(j)&&!D[j]&&(D[j]=M);W.children&&W.children.length>0&&F(W.children)}};F(v.children)}const z=v.type==="video"||v.type==="NodeVideo"||/<video\b/i.test(S);if(z){const E=D["custom-slides-autoplay"]==="true",F=D["custom-slides-loop"]==="true",g=D["custom-slides-muted"]==="true"||E,W=D["custom-slides-controls"]==="false";S=S.replace(/<video\b([^>]*)>/gi,(j,M)=>{let I=M;return W?I=I.replace(/\bcontrols(?:="[^"]*")?/gi,"").trim():/controls/i.test(I)||(I+=" controls"),E&&!/autoplay/i.test(I)?I+=" autoplay playsinline":!E&&D["custom-slides-autoplay"]==="false"&&(I=I.replace(/\bautoplay\b/gi,"").replace(/\bplaysinline\b/gi,"").trim()),F&&!/loop/i.test(I)?I+=" loop":!F&&D["custom-slides-loop"]==="false"&&(I=I.replace(/\bloop\b/gi,"").trim()),g&&!/muted/i.test(I)?I+=" muted":!g&&D["custom-slides-muted"]==="false"&&(I=I.replace(/\bmuted\b/gi,"").trim()),`<video ${I.trim()}>`})}if(L.isBackground){const E=fi(S,v.content);if(E){l.frontmatter.background=_t(E,n);return}}const N=ti(v);if(N){l.frontmatter.layout=N.layout,l.frontmatter.image=_t(N.imageUrl,n),!l.frontmatter.layoutRatio&&N.ratio&&(l.frontmatter.layoutRatio=N.ratio);for(const E of N.contentNodes)b(E);return}if(L.imageLayout==="image-left"||L.imageLayout==="image-right"){const E=fi(S,v.content);if(E){l.frontmatter.layout=L.imageLayout,l.frontmatter.image=_t(E,n),!l.frontmatter.layoutRatio&&((oe=v.ial)!=null&&oe[vt])&&(l.frontmatter.layoutRatio=v.ial[vt]);return}}if(at(v)&&v.children&&v.children.length>0){for(const E of v.children)b(E);return}const K=!!(L.slot||k!=null&&k.defaultSlot||l.frontmatter.layout==="clover"||on(l.frontmatter.layout)||l.frontmatter.layout==="two-cols"),_=!!(v.children&&v.children.some(E=>{var F,g;return((F=E.ial)==null?void 0:F[Me])||((g=E.ial)==null?void 0:g[Ne])||E.children&&E.children.length>=2||E.children&&E.children.some(W=>{var j,M,I,R,G,B;return((j=W.ial)==null?void 0:j[Ne])||((M=W.ial)==null?void 0:M[Me])||((I=W.ial)==null?void 0:I[Ze])||((R=W.ial)==null?void 0:R[ke])||((G=W.ial)==null?void 0:G["custom-slides-role"])||((B=W.ial)==null?void 0:B["custom-slides-layout"])})}));if((v.type==="l"||v.type==="NodeList"||v.type==="list")&&v.children&&v.children.length>0&&(_||L.slot||L.clicks||K)){const E=/^\s*\d+\.\s+/m.test(v.markdown||"")||v.subType==="o"||v.subtype==="o";for(let F=0;F<v.children.length;F++){const g=v.children[F];L.slot&&(!g.ial||!g.ial[Me])&&(g.ial||(g.ial={}),g.ial[Me]=L.slot),b(g,{...k,parentClicks:L.clicks||(k==null?void 0:k.parentClicks),defaultSlot:L.slot||(k==null?void 0:k.defaultSlot),isParentListUnpacked:!0,isListItem:!0,listContext:{isOrdered:E,itemIndex:F+1}})}return}const U=!!(k!=null&&k.isParentListUnpacked),x=!!(v.children&&v.children.length>=2)||!!L.clicks||!!((Se=v.children)!=null&&Se.some(E=>{var F;return(F=E.ial)==null?void 0:F[Ne]}))||U||!v.markdown&&!!(v.children&&v.children.length>0);if(Ti(v)&&v.children&&v.children.length>0&&(K||U||L.clicks||v.children.some(E=>{var F;return(F=E.ial)==null?void 0:F[Ne]}))&&x){const E=!!(v.children&&v.children.length>=2),F=v.children.find(G=>!!(G.markdown||G.content||"").trim())||v.children[0],g=((Ie=F==null?void 0:F.ial)==null?void 0:Ie[Ne])||((_e=F==null?void 0:F.ial)==null?void 0:_e["custom-slides-click"]),W=!!(!L.clicks&&E&&g),j=L.clicks||(W?g:void 0)||(k==null?void 0:k.parentClicks),M=v.id||(k==null?void 0:k.parentContainerId),I=L.slot||(k==null?void 0:k.defaultSlot);let R=!0;for(const G of v.children){I&&(!G.ial||!G.ial[Me])&&(G.ial||(G.ial={}),G.ial[Me]=I);const B=!!(G.markdown||G.content||"").trim(),H=R&&B;if(H){if(!(l.frontmatter.layout==="image-right"||l.frontmatter.layout==="image-left")&&!!(l.frontmatter.layout==="clover"||on(l.frontmatter.layout)||l.frontmatter.layout==="two-cols")&&!!(k!=null&&k.defaultSlot||L.slot||(fe=v.ial)!=null&&fe[Me]))G.markdown&&(G.markdown=Ln(G.markdown)),G.content&&(G.content=Ln(G.content));else{const $e=!!((X=k==null?void 0:k.listContext)!=null&&X.isOrdered),xe=((pe=k==null?void 0:k.listContext)==null?void 0:pe.itemIndex)||1,De=$e?`${xe}. `:"- ",je=ze=>{if(!ze)return De.trim();const ae=ze.trim();return/^[-*+]\s+/.test(ae)||/^\d+\.\s+/.test(ae)?ze:`${De}${ze}`};G.markdown&&(G.markdown=je(G.markdown)),G.content&&(G.content=je(G.content))}R=!1}let Z=G;H&&j&&E?(Z={...G,ial:{...G.ial||{}}},delete Z.ial[Ne],delete Z.ial["custom-slides-click"]):!E&&j&&(Z={...G,ial:{...G.ial||{},[Ne]:j}}),b(Z,{...k,parentClicks:j,parentContainerId:M,defaultSlot:I,isListItem:!0})}return}if(L.isNote){const E=ur(S);E&&(l.notes?l.notes+=`

`+E:l.notes=E),l.noteBlocks||(l.noteBlocks=[]),l.noteBlocks.push({id:v.id,type:v.type,content:E||v.content||"",rawMarkdown:S,isNote:!0,attributes:v.ial});return}L.shikiLines&&(S=np(S,L.shikiLines)),C=S.trim();const q=(v.content||"").trim();if(C==="::right::"||q==="::right::"||/^<p>\s*::right::\s*<\/p>$/i.test(C)||C.startsWith("::right::")){l.blocks.push({id:v.id,type:v.type,content:"::right::",rawMarkdown:"::right::",slot:"slot-divider-right",attributes:v.ial});return}const $=op(v);let T=L.slot,P=L.clicks,se=L.motion,V={...v.ial||{}};if($!==null){for(;u.length>0&&u[u.length-1].level>=$;)u.pop();const E=u.length>0?u[u.length-1]:void 0;!T&&(E!=null&&E.slot)&&(T=E.slot),!P&&(E!=null&&E.clicks)&&!(k!=null&&k.parentContainerId)&&(P=E.clicks),!se&&(E!=null&&E.motion)&&(se=E.motion);const F={...(E==null?void 0:E.customAttrs)||{}};if(v.ial)for(const[g,W]of Object.entries(v.ial))g.startsWith("custom-slides-")&&!g.startsWith("custom-slides-slide")&&(F[g]=W);k!=null&&k.parentContainerId||u.push({level:$,slot:T,clicks:P,motion:se,customAttrs:F})}else{const E=u.length>0?u[u.length-1]:void 0;E&&(!T&&E.slot&&E.slot!=="header"&&(T=E.slot),!P&&E.clicks&&!(k!=null&&k.parentContainerId)&&(P=E.clicks),!se&&E.motion&&(se=E.motion),E.customAttrs&&(V={...E.customAttrs,...V}))}!T&&l.blocks.some(E=>E.slot==="slot-divider-right")&&(T="right"),!T&&(k!=null&&k.defaultSlot)&&(T=k.defaultSlot),T&&(V[Me]=T),P&&!V[Ne]&&(V[Ne]=P),se&&!V[Xt]&&(V[Xt]=JSON.stringify(se)),(z||D["custom-slides-autoplay"]||D["custom-slides-muted"])&&(D["custom-slides-autoplay"]&&(V["custom-slides-autoplay"]=D["custom-slides-autoplay"],D["custom-slides-autoplay"]==="true"&&!D["custom-slides-muted"]&&(V["custom-slides-muted"]="true")),D["custom-slides-loop"]&&(V["custom-slides-loop"]=D["custom-slides-loop"]),D["custom-slides-muted"]&&(V["custom-slides-muted"]=D["custom-slides-muted"]),D["custom-slides-controls"]&&(V["custom-slides-controls"]=D["custom-slides-controls"]));const Y=L.maxHeight?/^\d+$/.test(L.maxHeight.trim())?`${L.maxHeight.trim()}px`:L.maxHeight.trim():void 0,le=!!(k!=null&&k.isListItem||Ti(v)),ie={id:v.id,type:v.type,content:v.content||"",rawMarkdown:S,clicks:P,parentClicks:k==null?void 0:k.parentClicks,parentContainerId:k==null?void 0:k.parentContainerId,motion:se,shikiLines:L.shikiLines,maxHeight:Y,slot:T,attributes:V,attrs:V,rawNode:v,isListItem:le};l.blocks.push(ie)};b(y)}for(let m=0;m<o.length;m++){const y=o[m],b=[],v={...y.frontmatter};m===0&&(v.theme=s.theme,v.aspectRatio=s.aspectRatio,v.highlighter=s.highlighter,v.transition=y.frontmatter.transition||s.defaultTransition);const k=ip(v);k&&b.push(k);const S=y.blocks.filter(z=>z.slot!=="slot-divider-right"),D=z=>z.filter(N=>!!(N.rawMarkdown||N.content||"").trim()).map(N=>{var K;return ls(N.rawMarkdown,N.clicks,N.motion,(K=N.attributes)==null?void 0:K.style,N.maxHeight)}).join(`

`),A=z=>{const N=z.filter(x=>!!(x.rawMarkdown||x.content||"").trim());if(N.length===0)return;const K=N[0],_=(K.rawMarkdown||K.content||"").trim();(Ti(K)||/^(?:[-*+]|\d+\.)\s+/.test(_))&&(K.rawMarkdown=Ln(K.rawMarkdown||K.content||""),K.content=K.rawMarkdown)},C=z=>{var x,q;if(z.length===0)return"";A(z);const N=(x=z.find(O=>O.parentClicks))==null?void 0:x.parentClicks;if(!N)return z.filter(O=>!!(O.rawMarkdown||O.content||"").trim()).map(O=>{var $;return ls(O.rawMarkdown,O.clicks,O.motion,($=O.attributes)==null?void 0:$.style,O.maxHeight)}).join(`

`);const K=[];let _=[];const U=()=>{if(_.length===0)return;const O=_.map($=>($.rawMarkdown||$.content||"").trim()).filter(Boolean).join(`

`);O&&K.push(Nl(O,N)),_=[]};for(const O of z){if(!(O.rawMarkdown||O.content||"").trim())continue;!!(O.clicks&&O.clicks.trim()!=="")?(U(),K.push(ls(O.rawMarkdown,O.clicks,O.motion,(q=O.attributes)==null?void 0:q.style,O.maxHeight))):_.push(O)}return U(),K.join(`

`)},L=y.frontmatter.layout||"default";if(L==="clover"||on(L)){let z=[];const N=S.filter(O=>O.slot==="header");if(N.length>0)z=N;else if(S.length>0){const O=S.find($=>$.type==="h"&&(!$.slot||$.slot==="default"));O&&(z=[O])}const K=S.filter(O=>!z.includes(O));let _=2;if(L==="clover")_=4;else if(L==="three-cols-header")_=3;else if(L==="two-cols-header")_=2;else{let O=0;for(const $ of K){const T=($.slot||"").match(/^col-(\d+)$/i);T&&(O=Math.max(O,parseInt(T[1],10)))}if(O>=2)_=O;else if(y.frontmatter.layoutRatio){const $=y.frontmatter.layoutRatio.trim();if($.includes(":")){const T=$.split(":").map(P=>parseFloat(P.trim())).filter(P=>!isNaN(P)&&P>0);T.length>=2&&(_=T.length)}else{const T=$.split(/\s+/).filter(Boolean);T.length>=2&&(_=T.length)}}else K.length===1&&K[0].children&&K[0].children.length>=2&&(_=Math.min(6,K[0].children.length))}const U=zl(K,_);U.forEach((O,$)=>{const T=`col-${$+1}`;for(const P of O)(!P.slot||P.slot==="default")&&(P.slot=T);A(O)});const x=U.flat();if(K.length===1&&x.length>1){const O=y.blocks.findIndex($=>$.id===K[0].id);O!==-1&&y.blocks.splice(O,1,...x)}const q=D(z);if(q&&b.push(q),L==="two-cols-header"&&_===2){const O=C(U[0]||[]),$=C(U[1]||[]);O&&b.push(`::left::

${O}`),$&&b.push(`::right::

${$}`)}else U.forEach((O,$)=>{const T=C(O);T&&b.push(`::col-${$+1}::

${T}`)})}else if(L==="two-cols"){const z=S.filter(U=>U.slot==="left"),N=S.filter(U=>U.slot==="right");A(z),A(N);const K=D(z.length>0?z:S.filter(U=>U.slot!=="right")),_=D(N);b.push(K),_&&b.push(`::right::

${_}`)}else for(const z of S)b.push(ls(z.rawMarkdown,z.clicks||z.parentClicks,z.motion,(w=z.attributes)==null?void 0:w.style,z.maxHeight));y.notes&&b.push(`<!--
${y.notes}
-->`),y.rawMarkdown=b.join(`

`).trim()}const f=o.map(m=>m.rawMarkdown).filter(Boolean).join(`

---

`);return{docId:e,config:s,slides:o,fullMarkdown:f}}const Ro=`/* SiYuan Note Built-in Font & Background Styles for Slidev */
:root,
html:not(.dark),
[data-theme="light"],
[data-theme-mode="light"] {
  /* 思源基础卡片与主题色 (浅色模式 daylight) */
  --b3-card-error-color: #790600;
  --b3-card-error-background: #f5d1cf;
  --b3-card-warning-color: #8a4f00;
  --b3-card-warning-background: #ffe8c8;
  --b3-card-info-color: #005599;
  --b3-card-info-background: #d6eaf9;
  --b3-card-success-color: #006b04;
  --b3-card-success-background: #d7eed8;

  --b3-theme-primary: #3575f0;
  --b3-theme-secondary: #ff9200;
  --b3-theme-error: #d23f31;
  --b3-theme-background: #ffffff;
  --b3-theme-on-background: #222222;
  --b3-theme-on-surface: #5f6368;
  --b3-theme-surface-lighter: #e0e0e0;

  /* 13 种内置文字颜色 */
  --b3-font-color1: var(--b3-card-error-color);
  --b3-font-color2: var(--b3-card-warning-color);
  --b3-font-color3: var(--b3-card-info-color);
  --b3-font-color4: var(--b3-card-success-color);
  --b3-font-color5: var(--b3-theme-on-surface);
  --b3-font-color6: var(--b3-theme-primary);
  --b3-font-color7: var(--b3-theme-secondary);
  --b3-font-color8: var(--b3-theme-error);
  --b3-font-color9: #a40074;
  --b3-font-color10: #007080;
  --b3-font-color11: #006e2a;
  --b3-font-color12: #6b5a00;
  --b3-font-color13: var(--b3-theme-background);

  /* 13 种内置背景颜色 */
  --b3-font-background1: var(--b3-card-error-background);
  --b3-font-background2: var(--b3-card-warning-background);
  --b3-font-background3: var(--b3-card-info-background);
  --b3-font-background4: var(--b3-card-success-background);
  --b3-font-background5: #e2e3e4;
  --b3-font-background6: #acd0fc;
  --b3-font-background7: #fddaab;
  --b3-font-background8: #ffb0a9;
  --b3-font-background9: #fdbfff;
  --b3-font-background10: #b1ffff;
  --b3-font-background11: #affad1;
  --b3-font-background12: #fff88f;
  --b3-font-background13: var(--b3-theme-on-background);
}

html.dark,
[data-theme="dark"],
[data-theme-mode="dark"],
.theme-dark,
.dark {
  /* 思源基础卡片与主题色 (深色模式 midnight) */
  --b3-card-error-color: rgb(243, 153, 147);
  --b3-card-error-background: #442724;
  --b3-card-warning-color: rgb(255, 213, 153);
  --b3-card-warning-background: #554636;
  --b3-card-info-color: rgb(166, 213, 250);
  --b3-card-info-background: #28405c;
  --b3-card-success-color: rgb(183, 223, 185);
  --b3-card-success-background: #425347;

  --b3-theme-primary: #3575f0;
  --b3-theme-secondary: #ff9200;
  --b3-theme-error: #d23f31;
  --b3-theme-background: #1e1e1e;
  --b3-theme-on-background: #c8ccd6;
  --b3-theme-on-surface: #8b949e;
  --b3-theme-surface-lighter: #282a2e;

  /* 13 种内置文字颜色 */
  --b3-font-color1: var(--b3-card-error-color);
  --b3-font-color2: var(--b3-card-warning-color);
  --b3-font-color3: var(--b3-card-info-color);
  --b3-font-color4: var(--b3-card-success-color);
  --b3-font-color5: var(--b3-theme-on-surface);
  --b3-font-color6: var(--b3-theme-primary);
  --b3-font-color7: var(--b3-theme-secondary);
  --b3-font-color8: var(--b3-theme-error);
  --b3-font-color9: #f47c9c;
  --b3-font-color10: #4dd0e1;
  --b3-font-color11: #10df54;
  --b3-font-color12: #ecd424;
  --b3-font-color13: var(--b3-theme-background);

  /* 13 种内置背景颜色 */
  --b3-font-background1: var(--b3-card-error-background);
  --b3-font-background2: var(--b3-card-warning-background);
  --b3-font-background3: var(--b3-card-info-background);
  --b3-font-background4: var(--b3-card-success-background);
  --b3-font-background5: #3a3f42;
  --b3-font-background6: #031840;
  --b3-font-background7: #593905;
  --b3-font-background8: #3a0c09;
  --b3-font-background9: #4d1b40;
  --b3-font-background10: #1a5459;
  --b3-font-background11: #305415;
  --b3-font-background12: #4a4712;
  --b3-font-background13: var(--b3-theme-on-background);
}

@media (prefers-color-scheme: dark) {
  :root:not([data-theme="light"]):not([data-theme-mode="light"]):not(.light) {
    --b3-card-error-color: rgb(243, 153, 147);
    --b3-card-error-background: #442724;
    --b3-card-warning-color: rgb(255, 213, 153);
    --b3-card-warning-background: #554636;
    --b3-card-info-color: rgb(166, 213, 250);
    --b3-card-info-background: #28405c;
    --b3-card-success-color: rgb(183, 223, 185);
    --b3-card-success-background: #425347;

    --b3-theme-primary: #3575f0;
    --b3-theme-secondary: #ff9200;
    --b3-theme-error: #d23f31;
    --b3-theme-background: #1e1e1e;
    --b3-theme-on-background: #c8ccd6;
    --b3-theme-on-surface: #8b949e;
    --b3-theme-surface-lighter: #282a2e;

    --b3-font-color1: var(--b3-card-error-color);
    --b3-font-color2: var(--b3-card-warning-color);
    --b3-font-color3: var(--b3-card-info-color);
    --b3-font-color4: var(--b3-card-success-color);
    --b3-font-color5: var(--b3-theme-on-surface);
    --b3-font-color6: var(--b3-theme-primary);
    --b3-font-color7: var(--b3-theme-secondary);
    --b3-font-color8: var(--b3-theme-error);
    --b3-font-color9: #f47c9c;
    --b3-font-color10: #4dd0e1;
    --b3-font-color11: #10df54;
    --b3-font-color12: #ecd424;
    --b3-font-color13: var(--b3-theme-background);

    --b3-font-background1: var(--b3-card-error-background);
    --b3-font-background2: var(--b3-card-warning-background);
    --b3-font-background3: var(--b3-card-info-background);
    --b3-font-background4: var(--b3-card-success-background);
    --b3-font-background5: #3a3f42;
    --b3-font-background6: #031840;
    --b3-font-background7: #593905;
    --b3-font-background8: #3a0c09;
    --b3-font-background9: #4d1b40;
    --b3-font-background10: #1a5459;
    --b3-font-background11: #305415;
    --b3-font-background12: #4a4712;
    --b3-font-background13: var(--b3-theme-on-background);
  }
}

/* 演示块级样式排版增强 (带背景色时赋予呼吸内边距与舒适圆角) */
.slide-styled-block {
  border-radius: 6px;
  padding: 8px 14px;
  box-sizing: border-box;
  margin: 6px 0;
  transition: background-color 0.2s ease, color 0.2s ease;
}

/* 行内带背景色文本的精美圆角与微边距 */
span[style*="background-color"],
span[style*="background:"] {
  border-radius: 3px;
  padding: 1px 5px;
  box-decoration-break: clone;
  -webkit-box-decoration-break: clone;
}
`;function rp(e){var s,o,a,r,l,c,d,p,u,f,w,m;if(!e||typeof e!="object")return"";const t=[],i=[];if(Array.isArray(e.styles))for(const y of e.styles){if(!y||!y.id)continue;const b=`--b3-inline-style-${y.id}`;(s=y.light)!=null&&s.color&&t.push(`  ${b}-color: ${y.light.color};`),(o=y.light)!=null&&o.backgroundColor&&t.push(`  ${b}-background-color: ${y.light.backgroundColor};`),(a=y.dark)!=null&&a.color&&i.push(`  ${b}-color: ${y.dark.color};`),(r=y.dark)!=null&&r.backgroundColor&&i.push(`  ${b}-background-color: ${y.dark.backgroundColor};`)}if(e.builtin&&Array.isArray(e.builtin.colors))for(const y of e.builtin.colors){if(!y||typeof y.index!="number")continue;const b=y.index;(l=y.light)!=null&&l.color&&t.push(`  --b3-font-color${b}: ${y.light.color};`),(c=y.light)!=null&&c.backgroundColor&&t.push(`  --b3-font-background${b}: ${y.light.backgroundColor};`),(d=y.dark)!=null&&d.color&&i.push(`  --b3-font-color${b}: ${y.dark.color};`),(p=y.dark)!=null&&p.backgroundColor&&i.push(`  --b3-font-background${b}: ${y.dark.backgroundColor};`)}if(e.builtin&&Array.isArray(e.builtin.styles))for(const y of e.builtin.styles){if(!y||!y.id)continue;const b=y.id;(u=y.light)!=null&&u.color&&t.push(`  --b3-card-${b}-color: ${y.light.color};`),(f=y.light)!=null&&f.backgroundColor&&t.push(`  --b3-card-${b}-background: ${y.light.backgroundColor};`),(w=y.dark)!=null&&w.color&&i.push(`  --b3-card-${b}-color: ${y.dark.color};`),(m=y.dark)!=null&&m.backgroundColor&&i.push(`  --b3-card-${b}-background: ${y.dark.backgroundColor};`)}if(t.length===0&&i.length===0)return"";const n=[];return t.length>0&&n.push(`:root, html:not(.dark), [data-theme="light"] {
${t.join(`
`)}
}`),i.length>0&&n.push(`html.dark, [data-theme="dark"], .dark {
${i.join(`
`)}
}`),n.join(`

`)}function On(e){const t=rp(e);return t?`${Ro}

/* Custom Workspace Inline Styles */
${t}`:Ro}const fo=xa;function ap(e){const t=String((e==null?void 0:e.type)||"").toLowerCase();return t==="s"||t==="sb"||t==="nodesuperblock"||t==="l"||t==="nodelist"||t==="i"||t==="nodelistitem"||t==="b"||t==="nodeblockquote"}function lp(e,t){const i=new Map,n=[];if(!Array.isArray(t)||t.length===0)return{usable:!1,reason:"索引无行",leafPatch:i,rebuildRoots:n};const s=new Map;for(const o of t)o!=null&&o.id&&s.set(o.id,o);for(const o of e||[]){if(!(o!=null&&o.id))continue;const a=s.get(o.id);if(!a)continue;const r=o.content??"",l=o.markdown??"";(a.content??"")===r&&(a.markdown??"")===l||(ap(a)?n.push(o.id):i.set(o.id,{content:r,markdown:l}))}return{usable:!0,reason:"",leafPatch:i,rebuildRoots:n}}function cp(e){const t=String((e==null?void 0:e.type)||"").toLowerCase();return t==="h"||t==="nodeheading"}function No(e){return at(e)||e.type==="l"||e.type==="NodeList"||e.type==="i"||e.type==="NodeListItem"||e.type==="b"||e.type==="NodeBlockquote"}function dp(e,t,i,n=8,s){const o=new Map;for(const u of t)u!=null&&u.id&&o.set(u.id,u);const a=u=>({id:u.id,parent_id:u.parent_id,root_id:u.root_id||e,type:u.type,subType:u.subtype??u.subType??"",content:u.content||"",markdown:u.markdown||"",ial:i(u.id,u.ial),children:[]}),r=u=>{let f=u.parent_id,w=0;for(;f&&f!==e&&w++<16;){const m=o.get(f);if(!m||!cp(m))return f;f=m.parent_id}return f||e},l=new Map;for(const u of t){if(!(u!=null&&u.id)||u.id===e||s&&s.size>0&&!s.has(u.id))continue;const f=r(u),w=l.get(f);w?w.push(u):l.set(f,[u])}if(s&&s.size>0)for(const u of l.values())u.sort((f,w)=>(s.get(f.id)??Number.MAX_SAFE_INTEGER)-(s.get(w.id)??Number.MAX_SAFE_INTEGER));const c=new Map,d=(u,f)=>{const w=a(u);if(c.set(w.id,w),f>=n||!No(w))return w;const m=l.get(w.id);return m&&m.length>0&&(w.children=m.map(y=>d(y,f+1))),w};return{topLevel:(l.get(e)||[]).map(u=>d(u,0)),byId:c}}const up={getBlockAttrs:Wo,getChildBlocks:Yn,getDocBlocksOrders:pd,setBlockAttrs:Fe,sql:un,getBaseUrl:()=>typeof location<"u"?location.origin:"",getInlineStyles:hd};class fp{constructor(t){be(this,"deps");be(this,"attrOverrides",new Map);be(this,"trackedListSuperBlocks",new Map);be(this,"fallbackWarnedDocId","");this.deps={...up,...t||{}}}setBlockAttrOverride(t,i){if(!t||!i)return;const s={...this.attrOverrides.get(t)||{}};for(const[o,a]of Object.entries(i))a===""||a===null||a===void 0?delete s[o]:s[o]=String(a);Object.keys(s).length===0?this.attrOverrides.delete(t):this.attrOverrides.set(t,s)}getBlockAttrOverride(t){return this.attrOverrides.get(t)}getAllAttrOverrides(){return new Map(this.attrOverrides)}getTrackedListSuperBlocks(t){return this.trackedListSuperBlocks.get(t)||[]}clearBlockAttrOverride(t,i){if(!t)return;if(!i){this.attrOverrides.delete(t);return}const n=this.attrOverrides.get(t);n&&(delete n[i],Object.keys(n).length===0&&this.attrOverrides.delete(t))}clearAllOverrides(){this.attrOverrides.clear(),this.trackedListSuperBlocks.clear()}async compile(t){try{const i=await this.deps.getBlockAttrs(t).catch(()=>({}))||{},n=this.attrOverrides.get(t);n&&Object.assign(i,n);const s=await this.deps.getChildBlocks(t).catch(()=>[])||[],o=this.deps.getDocBlocksOrders?await this.deps.getDocBlocksOrders(t).catch(()=>[])||[]:[],a=new Map;for(let O=0;O<o.length;O++)o[O]&&a.set(o[O],O);const r=a.size>0,l=`SELECT id, parent_id, root_id, type, subtype, content, markdown, ial, sort, created FROM blocks WHERE root_id = '${t}' AND id != '${t}' ORDER BY sort ASC, created ASC LIMIT 99999`,c=await this.deps.sql(l).catch(()=>[])||[],d=lp(s,c),p=new Map;if(Array.isArray(c))for(const O of c)O.id&&O.ial&&p.set(O.id,fo(O.ial));const u=`SELECT block_id, name, value FROM attributes WHERE root_id = '${t}' AND type = 'b' LIMIT 99999`,f=await this.deps.sql(u).catch(()=>[])||[];if(Array.isArray(f)){for(const O of f)if(O.block_id&&O.name){let $=p.get(O.block_id);$||($={},p.set(O.block_id,$)),$[O.name]=O.value||""}}const w=(O,$)=>{const T={...p.get(O)||($?fo($):{})},P=this.attrOverrides.get(O);return P&&Object.assign(T,P),T},m=Array.isArray(c)&&c.length>0?dp(t,c,w,8,a):null,y=s.map(O=>O.id).filter(Boolean),b=O=>({id:O.id,parent_id:O.parent_id,root_id:O.root_id||t,type:O.type,subType:O.subType,content:O.content||"",markdown:O.markdown||"",ial:w(O.id,O.ial),children:O.children}),v=async(O,$=0)=>{if(!O||$>8||!No(O))return;const T=await this.deps.getChildBlocks(O.id).catch(()=>[])||[];if(!(!Array.isArray(T)||T.length===0)){O.children=T.filter(P=>P==null?void 0:P.id).map(P=>({id:P.id,parent_id:O.id,root_id:t,type:P.type,subType:P.subType,content:P.content||"",markdown:P.markdown||"",ial:w(P.id,P.ial),children:[]}));for(const P of O.children)await v(P,$+1)}},k=new Map;for(const O of c)O!=null&&O.id&&k.set(O.id,O);const S=y.every(O=>{const $=k.get(O);return!$||!!$.type});let D=[],A=!1;if(m&&d.usable&&r&&S){this.fallbackWarnedDocId="";for(const[$,T]of d.leafPatch){const P=m.byId.get($);P&&(P.content=T.content,P.markdown=T.markdown)}const O=new Map;for(const $ of s)$!=null&&$.id&&O.set($.id,$);for(const $ of d.rebuildRoots){const T=m.byId.get($),P=O.get($);T&&P&&(T.content=P.content||"",T.markdown=P.markdown||""),await v(T)}for(const $ of s){if(!($!=null&&$.id)||m.byId.has($.id))continue;const T=b($);await v(T),m.byId.set(T.id,T),m.topLevel.push(T)}D=m.topLevel.filter($=>a.has($.id)).sort(($,T)=>(a.get($.id)??0)-(a.get(T.id)??0))}else y.length>0?(A=!0,this.fallbackWarnedDocId!==t&&(this.fallbackWarnedDocId=t,console.warn(`[DocumentCompiler] 索引结构不可用，回退逐容器查询（较慢）doc=${t} 实时顶层=${y.length} 索引行=${c.length} 文档序=${o.length} 原因=${d.reason||"缺少实时文档序"}`)),D=s.map(O=>b(O))):m&&(D=m.topLevel);const C=async(O,$=0)=>{if(!(!O||O.length===0||$>8))for(const T of O){if(No(T)&&(!T.children||T.children.length===0)){let se=await this.deps.getChildBlocks(T.id).catch(()=>[]);if(!se||se.length===0){const V=`SELECT id, parent_id, root_id, type, subtype as subType, content, markdown, ial FROM blocks WHERE parent_id = '${T.id}' ORDER BY sort ASC, created ASC`;se=await this.deps.sql(V).catch(()=>[])||[]}if(Array.isArray(se)&&se.length>0){const V=new Set(D.map(le=>le.id)),Y=se.filter(le=>le.id!==T.id&&!V.has(le.id));Y.length>0&&(T.children=Y.map(le=>{const ie=p.get(le.id)||(le.ial?fo(le.ial):{}),oe=this.attrOverrides.get(le.id);return oe&&Object.assign(ie,oe),{id:le.id,parent_id:le.parent_id||T.id,root_id:le.root_id||t,type:le.type,subType:le.subType,content:le.content||"",markdown:le.markdown||"",ial:ie}}))}}T.children&&T.children.length>0&&await C(T.children,$+1)}};A&&await C(D);const L=O=>{var $,T;for(const P of O)if(P.children&&P.children.length>0){L(P.children);for(const se of P.children)if(se.ial)for(const[V,Y]of Object.entries(se.ial))V.startsWith("custom-slides-")&&!(($=P.ial)!=null&&$[V])&&(P.ial||(P.ial={}),P.ial[V]=Y);if(P.ial){for(const[se,V]of Object.entries(P.ial))if(se.startsWith("custom-slides-"))for(const Y of P.children)(Y.type==="video"||Y.type==="NodeVideo"||/<video\b/i.test(Y.markdown||Y.content||""))&&!((T=Y.ial)!=null&&T[se])&&(Y.ial||(Y.ial={}),Y.ial[se]=V)}}};L(D),Qf(D,O=>{const $={[ke]:O.layout};this.setBlockAttrOverride(O.blockId,$),(this.deps.setBlockAttrs||Fe)(O.blockId,$).catch(P=>{console.warn("[DocumentCompiler] Failed to auto-tag superblock image layout:",P)})});const z=this.trackedListSuperBlocks.get(t)||[],N=Xf(t,D,{tracked:z,onTagChange:O=>{this.setBlockAttrOverride(O.blockId,O.attrs),O.blockId===t&&Object.assign(i,O.attrs);const $=P=>{for(const se of P)se.id===O.blockId&&(se.ial||(se.ial={}),Object.assign(se.ial,O.attrs)),se.children&&se.children.length>0&&$(se.children)};$(D),(this.deps.setBlockAttrs||Fe)(O.blockId,O.attrs).catch(P=>{console.warn("[DocumentCompiler] Failed to auto-tag list superblock attrs:",P)})}});this.trackedListSuperBlocks.set(t,N.newTracked);const K=new Set,_=O=>{for(const $ of O){const T=$.markdown||$.content||"";if(T.includes("((")){const P=md(T);for(const se of P)K.add(se.blockId)}$.children&&$.children.length>0&&_($.children)}};_(D);const U={};if(K.size>0){const O=Array.from(K).map(T=>`'${T}'`).join(","),$=await this.deps.sql(`SELECT id, content, markdown FROM blocks WHERE id IN (${O})`).catch(()=>[])||[];if(Array.isArray($))for(const T of $)T.id&&(U[T.id]=T.markdown||T.content||"")}const x=this.deps.getBaseUrl?this.deps.getBaseUrl():"",q=ra(t,i,D,{baseUrl:x,refContentMap:U});try{const O=this.deps.getInlineStyles?await this.deps.getInlineStyles().catch(()=>null):null;q.customThemeCss=On(O)}catch{q.customThemeCss=On(null)}return q}catch(i){console.error("[DocumentCompilerService] Failed to compile document:",i);const n=ra(t,{},[],{});return n.customThemeCss=On(null),n}}}const Le=new fp;class fr{constructor(t){be(this,"devServerUrl","http://localhost:3030");be(this,"isConnected",!1);be(this,"lastSyncTime",null);t&&(this.devServerUrl=t)}getUrl(){return this.devServerUrl}setUrl(t){this.devServerUrl=t.replace(/\/+$/,"")}isServerConnected(){return this.isConnected}getLastSyncTime(){return this.lastSyncTime}async probeServer(t=1500){try{const i=new AbortController,n=setTimeout(()=>i.abort(),t),s=await fetch(this.devServerUrl,{method:"HEAD",mode:"no-cors",signal:i.signal}).catch(()=>null);return clearTimeout(n),this.isConnected=!!s,this.isConnected}catch{return this.isConnected=!1,!1}}buildStandardSlidevMarkdown(t){const i=t.config,n=["---",`theme: ${i.theme||"default"}`,`aspectRatio: "${i.aspectRatio||"16/9"}"`,`highlighter: ${i.highlighter||"shiki"}`,`transition: ${i.defaultTransition||"slide-left"}`];i.background&&n.push(`background: ${i.background}`),i.colorSchema&&i.colorSchema!=="auto"&&n.push(`colorSchema: ${i.colorSchema}`),n.push("drawings:","  persist: false","---","");const s=n.join(`
`),o=t.slides.map((l,c)=>{const d=l.frontmatter||{},p=[],u=c===0;d.layout&&d.layout!=="default"&&p.push(`layout: ${d.layout}`),d.transition&&p.push(`transition: ${d.transition}`),d.background&&p.push(`background: ${d.background}`),d.class&&p.push(`class: "${d.class}"`);let f="";p.length>0?f=u?"":`---
${p.join(`
`)}
---

`:u||(f=`---

`);let w="";if(d.layout==="two-cols"){const y=l.blocks.filter(S=>S.slot!=="right"),b=l.blocks.filter(S=>S.slot==="right"),v=y.map(S=>S.rawMarkdown||S.content||"").join(`

`),k=b.map(S=>S.rawMarkdown||S.content||"").join(`

`);w=`${v}

::right::

${k}`}else w=l.blocks.map(y=>y.rawMarkdown||y.content||"").join(`

`);let m="";return l.notes&&l.notes.trim()&&(m=`

<!--
${l.notes.trim()}
-->`),`${f}${w}${m}`}).join(`

`),a=[];t.config.normalizeHeadingSizes&&a.push(`/* Specific Heading Normalization */
.slidev-layout:not(.cover) > :is(h1, h2, h3, h4, h5, h6):first-child {
  font-size: 1.7rem !important;
}
.two-cols-header-top :is(h1, h2, h3, h4, h5, h6),
.cols-header-top :is(h1, h2, h3, h4, h5, h6),
.layout-header-section :is(h1, h2, h3, h4, h5, h6) {
  font-size: 1.7rem !important;
}
:is(.two-cols-left, .two-cols-right, .col, .col-1, .col-2, .col-3, .three-cols-col) > :is(h1, h2, h3, h4, h5, h6):first-child {
  font-size: 1.3rem !important;
}`),t.config.showUnorderedListMarkers===!1&&a.push(`/* Hide Unordered List Bullets */
ul, .slidev-layout ul, .slidev-layout li:has(ul) {
  list-style: none !important;
  list-style-type: none !important;
  padding-left: 0 !important;
}`),t.config.showOrderedListMarkers===!1&&a.push(`/* Hide Ordered List Numbers */
ol, .slidev-layout ol, .slidev-layout li:has(ol) {
  list-style: none !important;
  list-style-type: none !important;
  padding-left: 0 !important;
}`);let r="";return a.length>0&&(r=`

<style>
${a.join(`

`)}
</style>`),`${s}${o}${r}
`}async syncToWorkspaceFile(t,i="/data/storage/petal/siyuan-live-slides/slides.md",n){const s=this.buildStandardSlidevMarkdown(t);if(this.lastSyncTime=Date.now(),n)try{const o=typeof Blob<"u"?new Blob([s],{type:"text/markdown;charset=utf-8"}):Buffer.from(s,"utf-8");return await n(i,!1,o),{success:!0,path:i}}catch(o){return{success:!1,path:i,error:String(o)}}return{success:!0,path:i}}downloadSlidesMd(t,i="slides.md"){if(typeof window>"u"||typeof document>"u")return!1;const n=this.buildStandardSlidevMarkdown(t),s=new Blob([n],{type:"text/markdown;charset=utf-8"}),o=URL.createObjectURL(s),a=document.createElement("a");return a.href=o,a.download=i,document.body.appendChild(a),a.click(),document.body.removeChild(a),URL.revokeObjectURL(o),!0}}const pp={proMode:!1,presenterMode:!0,exportHtml:!1,exportPdf:!1,exportImage:!0,import:!1,aiScript:!0};function ai(e){return pp[e]===!1}function It(e){return!ai(e)}function hp(){if(typeof window<"u"&&typeof window.require=="function")return window.require.bind(window);if(typeof globalThis<"u"&&typeof globalThis.require=="function")return globalThis.require.bind(globalThis);if(typeof require=="function")return require}function Tt(e){const t=hp();if(t)try{return t(e)}catch{try{const i=e.startsWith("node:")?e.slice(5):`node:${e}`;return t(i)}catch{}}}function pr(){var t;if(typeof window<"u"&&window.process)return window.process;const e=Tt("process");return e&&e.versions?e:typeof process<"u"&&((t=process.versions)!=null&&t.node)?process:globalThis.process}function Hl(){var t,i;const e=pr();if(e&&((t=e.versions)!=null&&t.node))return!0;if(typeof window<"u"&&window.siyuan){const n=Tt("child_process");if(n&&typeof n.spawn=="function")return!0}return!!(typeof process<"u"&&((i=process.versions)!=null&&i.node))}function mp(){if(typeof window>"u"||!window.location)return!1;try{return new URLSearchParams(window.location.search).get("remote")==="1"}catch{return!1}}function qn(){const e=pr();if(e!=null&&e.platform)return e.platform;if(typeof process<"u"&&process.platform)return process.platform;const t=Tt("os");if(t&&typeof t.platform=="function")return t.platform();if(typeof navigator<"u"){const i=navigator.userAgent.toLowerCase();if(i.includes("win"))return"win32";if(i.includes("mac"))return"darwin";if(i.includes("linux"))return"linux"}return"web"}function Fl(){var n,s;const e=pr(),t={...(e==null?void 0:e.env)||{}};if(qn()==="win32"){const o=["C:\\Program Files\\nodejs","C:\\Program Files (x86)\\nodejs",(n=e==null?void 0:e.env)!=null&&n.APPDATA?`${e.env.APPDATA}\\npm`:"",(s=e==null?void 0:e.env)!=null&&s.USERPROFILE?`${e.env.USERPROFILE}\\AppData\\Roaming\\npm`:""].filter(Boolean),a=Object.keys(t).find(c=>c.toLowerCase()==="path")||"PATH",l=(t[a]||"").split(";").filter(Boolean);for(const c of o)c&&!l.some(d=>d.toLowerCase()===c.toLowerCase())&&l.push(c);t[a]=l.join(";")}return t}function zo(e){var i,n,s;if(!e)return"";if(/^[a-zA-Z]:[/\\]/.test(e))return e.replace(/\\/g,"/");let t="";if(typeof window<"u"&&((s=(n=(i=window.siyuan)==null?void 0:i.config)==null?void 0:n.system)!=null&&s.dataDir)&&(t=window.siyuan.config.system.dataDir.replace(/\\/g,"/")),t&&e.startsWith("/data/")){const o=e.slice(6);return`${t}/${o}`.replace(/\\/g,"/")}return e}function gp(){const e=Tt("os"),t=Tt("path");if(e&&typeof e.tmpdir=="function"){const i=e.tmpdir();return t&&typeof t.join=="function"?t.join(i,"siyuan-live-slides-pro").replace(/\\/g,"/"):`${i}/siyuan-live-slides-pro`.replace(/\\/g,"/")}return"/data/storage/petal/siyuan-live-slides/pro-workspace"}class hr{constructor(t){be(this,"runner");this.runner=t||hr.defaultRunner}static async defaultRunner(t,i){var n;try{let s=(n=Tt("child_process"))==null?void 0:n.execFile;if(!s){const l=await import("node:child_process").catch(()=>({}));s=l==null?void 0:l.execFile}if(!s)return{code:-1,stdout:"",stderr:"child_process execFile not available"};const a=qn()==="win32",r=Fl();return await new Promise(l=>{s(t,i,{timeout:5e3,shell:a,env:r},(c,d,p)=>{l({code:c?c.code||1:0,stdout:d?String(d).trim():"",stderr:p?String(p).trim():""})})})}catch(s){return{code:-1,stdout:"",stderr:String(s)}}}async detect(){const t=Hl(),i=qn();if(!t)return{hasNode:!1,hasSlidevCli:!1,platform:"browser",isDesktop:!1,error:"当前处于纯前端浏览器或移动端环境，无 Node.js 运行时支撑"};let n=!1,s,o=!1,a;try{const r=await this.runner("node",["-v"]);r.code===0&&r.stdout.startsWith("v")&&(n=!0,s=r.stdout)}catch{}if(n){try{const r=i==="win32"?"slidev.cmd":"slidev",l=await this.runner(r,["--version"]);l.code===0&&l.stdout&&(o=!0,a=l.stdout)}catch{}if(!o)try{const r=i==="win32"?"npx.cmd":"npx",l=await this.runner(r,["@slidev/cli","--version"]);l.code===0&&l.stdout&&(o=!0,a=l.stdout)}catch{}}return{hasNode:n,nodeVersion:s,hasSlidevCli:o,slidevVersion:a,platform:i,isDesktop:t}}}class vp{constructor(){be(this,"iframe",null);be(this,"isReady",!1);be(this,"pageChangedHandlers",[]);be(this,"readyHandlers",[]);be(this,"currentState",{no:1,clicks:0,total:1});this.handleWindowMessage=this.handleWindowMessage.bind(this)}getCurrentState(){return{...this.currentState}}attach(t){this.detach(),this.iframe=t,this.isReady=!1,typeof window<"u"&&window.addEventListener("message",this.handleWindowMessage)}detach(){typeof window<"u"&&window.removeEventListener("message",this.handleWindowMessage),this.iframe=null,this.isReady=!1}postMessage(t,i){var s;if(!((s=this.iframe)!=null&&s.contentWindow))return;const n={target:"slidev",sender:"siyuan",type:t,...i};try{this.iframe.contentWindow.postMessage(n,"*")}catch(o){console.warn("[NativeSlidesBridge] postMessage error:",o)}}navigateToPage(t){this.postMessage("navigate",{no:t})}next(){this.postMessage("next")}prev(){this.postMessage("prev")}nextClick(){this.postMessage("next-click")}prevClick(){this.postMessage("prev-click")}onPageChanged(t){return this.pageChangedHandlers.push(t),()=>{this.pageChangedHandlers=this.pageChangedHandlers.filter(i=>i!==t)}}onReady(t){return this.readyHandlers.push(t),()=>{this.readyHandlers=this.readyHandlers.filter(i=>i!==t)}}handleWindowMessage(t){const i=t.data;if(!(!i||i.target!=="slidev")){if(!this.isReady){this.isReady=!0;for(const n of this.readyHandlers)n()}if(i.type==="update-state"&&i.navState){const n=i.navState;this.currentState={no:n.no??this.currentState.no,clicks:n.clicks??this.currentState.clicks,total:n.total??this.currentState.total,hasNext:n.hasNext,hasPrev:n.hasPrev};for(const s of this.pageChangedHandlers)s(this.currentState.no,this.currentState.total||1,this.currentState)}else if(i.type==="navigate"&&typeof i.no=="number"){this.currentState.no=i.no;for(const n of this.pageChangedHandlers)n(i.no,this.currentState.total||1,this.currentState)}}}}class bp{constructor(t){be(this,"childProcess",null);be(this,"activePort",null);be(this,"isRunning",!1);be(this,"defaultPort");be(this,"maxPortRetries");be(this,"probeTimeoutMs");be(this,"customSpawner");be(this,"customPortChecker");this.defaultPort=(t==null?void 0:t.defaultPort)||3030,this.maxPortRetries=(t==null?void 0:t.maxPortRetries)||20,this.probeTimeoutMs=(t==null?void 0:t.probeTimeoutMs)||1e4,this.customSpawner=t==null?void 0:t.customSpawner,this.customPortChecker=t==null?void 0:t.customPortChecker}getActivePort(){return this.activePort}getIsRunning(){return this.isRunning}async isPortAvailable(t){if(this.customPortChecker)return this.customPortChecker(t);try{let i=Tt("net");return i||(i=await import("node:net").catch(()=>({}))),i!=null&&i.createServer?await new Promise(n=>{const s=i.createServer();s.once("error",()=>n(!1)),s.once("listening",()=>{s.close(()=>n(!0))}),s.listen(t,"127.0.0.1")}):!0}catch{return!0}}async allocPort(t){const i=t||this.defaultPort;for(let n=0;n<this.maxPortRetries;n++){const s=i+n;if(await this.isPortAvailable(s))return s}return i}async pollServerReady(t,i=8e3,n=300){const s=Date.now();for(;Date.now()-s<i;){try{const o=new AbortController,a=setTimeout(()=>o.abort(),n),r=await fetch(t,{method:"HEAD",mode:"no-cors",signal:o.signal}).catch(()=>null);if(clearTimeout(a),r)return!0}catch{}await new Promise(o=>setTimeout(o,n))}return!1}async startServer(t,i){var l,c;if(this.isRunning&&this.activePort)return{success:!0,port:this.activePort,url:`http://localhost:${this.activePort}?embedded=true`};const n=await this.allocPort(i);this.activePort=n;const o=qn()==="win32"?"npx.cmd":"npx",a=zo(t),r=["@slidev/cli",a,"--port",String(n),"--no-open"];try{if(this.customSpawner)this.childProcess=this.customSpawner(o,r,{detached:!1});else{let p=(l=Tt("child_process"))==null?void 0:l.spawn;if(!p){const w=await import("node:child_process").catch(()=>({}));p=w==null?void 0:w.spawn}if(!p)throw new Error("child_process spawn not available in current runtime");const u=a.includes("/")||a.includes("\\")?a.replace(/[/\\][^/\\]+$/,""):void 0,f=Fl();this.childProcess=p(o,r,{cwd:u,detached:!1,shell:!0,env:{...f,FORCE_COLOR:"1"}})}this.isRunning=!0,(c=this.childProcess)!=null&&c.on&&this.childProcess.on("exit",()=>{this.isRunning=!1,this.activePort=null,this.childProcess=null});const d=`http://localhost:${n}`;return!this.customSpawner&&!await this.pollServerReady(d,this.probeTimeoutMs)?(this.stopServer(),{success:!1,port:n,url:"",error:`Slidev DevServer 启动超时 (未在 ${this.probeTimeoutMs}ms 内响应端口 ${n})`}):{success:!0,port:n,url:`${d}?embedded=true`}}catch(d){return this.stopServer(),{success:!1,port:n,url:"",error:`唤起 Slidev 进程失败: ${String(d)}`}}}async stopServer(){var t;if(this.childProcess){const i=this.childProcess;this.childProcess=null;try{if(i.kill("SIGTERM"),qn()==="win32"&&i.pid&&!this.customSpawner){const s=(t=Tt("child_process"))==null?void 0:t.exec;if(s)await new Promise(o=>{const a=setTimeout(o,400);s(`taskkill /pid ${i.pid} /T /F`,()=>{clearTimeout(a),o()})});else{const o=await import("node:child_process").catch(()=>null);o!=null&&o.exec&&await new Promise(a=>{const r=setTimeout(a,400);o.exec(`taskkill /pid ${i.pid} /T /F`,()=>{clearTimeout(r),a()})})}}}catch{}}this.isRunning=!1,this.activePort=null}}class Qn{constructor(){be(this,"iframe",null);be(this,"isReady",!1);be(this,"pendingMessages",[]);be(this,"slideChangedHandlers",[]);be(this,"blockClickedHandlers",[]);be(this,"openInEditorHandlers",[]);be(this,"clientReadyHandlers",[]);be(this,"openPeekDrawerHandlers",[]);be(this,"toggleFullscreenHandlers",[]);be(this,"openPresenterHandlers",[]);be(this,"captureProgressHandlers",[]);be(this,"capturePageDoneHandlers",[]);be(this,"captureCompleteHandlers",[]);be(this,"captureErrorHandlers",[]);this.handleWindowMessage=this.handleWindowMessage.bind(this)}attach(t){this.detach(),this.iframe=t,this.isReady=!1,typeof window<"u"&&window.addEventListener("message",this.handleWindowMessage)}detach(){typeof window<"u"&&window.removeEventListener("message",this.handleWindowMessage),this.iframe=null,this.isReady=!1,this.pendingMessages=[]}resetReady(){this.isReady=!1}postMessage(t,i){var s;const n={source:"siyuan-slides-host",action:t,payload:i};if(!((s=this.iframe)!=null&&s.contentWindow)||!this.isReady){if(t==="UPDATE_SLIDES"||t==="NAVIGATE_PAGE"){const o=this.pendingMessages.findIndex(a=>a.action===t);o!==-1?this.pendingMessages[o]=n:this.pendingMessages.push(n)}else this.pendingMessages.length>=50&&this.pendingMessages.shift(),this.pendingMessages.push(n);return}try{this.iframe.contentWindow.postMessage(n,"*")}catch(o){console.warn("[WebSandboxBridge] postMessage error:",o)}}updateSlides(t,i,n,s){this.postMessage("UPDATE_SLIDES",{slides:t,config:i,fullMarkdown:n,customThemeCss:s})}navigatePage(t,i){const n={pageIndex:t};typeof i=="number"&&(n.step=i),this.postMessage("NAVIGATE_PAGE",n)}highlightElement(t){this.postMessage("HIGHLIGHT_ELEMENT",{targetBlockId:t})}nextStep(){this.postMessage("NEXT_STEP",{})}prevStep(){this.postMessage("PREV_STEP",{})}freezeKeyboardNav(t){this.postMessage("FREEZE_KEYBOARD_NAV",{frozen:t})}toggleOverview(){this.postMessage("TOGGLE_OVERVIEW",{})}startImageExport(t){this.postMessage("START_IMAGE_EXPORT",{captureOptions:t})}cancelImageExport(){this.postMessage("CANCEL_IMAGE_EXPORT",{})}onCaptureProgress(t){return this.captureProgressHandlers.push(t),()=>{this.captureProgressHandlers=this.captureProgressHandlers.filter(i=>i!==t)}}onCapturePageDone(t){return this.capturePageDoneHandlers.push(t),()=>{this.capturePageDoneHandlers=this.capturePageDoneHandlers.filter(i=>i!==t)}}onCaptureComplete(t){return this.captureCompleteHandlers.push(t),()=>{this.captureCompleteHandlers=this.captureCompleteHandlers.filter(i=>i!==t)}}onCaptureError(t){return this.captureErrorHandlers.push(t),()=>{this.captureErrorHandlers=this.captureErrorHandlers.filter(i=>i!==t)}}onSlideChanged(t){return this.slideChangedHandlers.push(t),()=>{this.slideChangedHandlers=this.slideChangedHandlers.filter(i=>i!==t)}}onBlockClicked(t){return this.blockClickedHandlers.push(t),()=>{this.blockClickedHandlers=this.blockClickedHandlers.filter(i=>i!==t)}}onOpenInEditor(t){return this.openInEditorHandlers.push(t),()=>{this.openInEditorHandlers=this.openInEditorHandlers.filter(i=>i!==t)}}onOpenPeekDrawer(t){return this.openPeekDrawerHandlers.push(t),()=>{this.openPeekDrawerHandlers=this.openPeekDrawerHandlers.filter(i=>i!==t)}}onRequestToggleFullscreen(t){return this.toggleFullscreenHandlers.push(t),()=>{this.toggleFullscreenHandlers=this.toggleFullscreenHandlers.filter(i=>i!==t)}}onOpenPresenter(t){return this.openPresenterHandlers.push(t),()=>{this.openPresenterHandlers=this.openPresenterHandlers.filter(i=>i!==t)}}onClientReady(t){return this.clientReadyHandlers.push(t),()=>{this.clientReadyHandlers=this.clientReadyHandlers.filter(i=>i!==t)}}handleWindowMessage(t){var n,s;const i=t.data;if(!(!i||i.source!=="siyuan-slides-client")&&!((n=this.iframe)!=null&&n.contentWindow&&t.source&&t.source!==this.iframe.contentWindow))switch(i.action){case"CLIENT_READY":for(this.isReady=!0;this.pendingMessages.length>0;){const o=this.pendingMessages.shift();o&&((s=this.iframe)!=null&&s.contentWindow)&&this.iframe.contentWindow.postMessage(o,"*")}for(const o of this.clientReadyHandlers)o();break;case"SLIDE_CHANGED":if(i.payload.currentPage!==void 0)for(const o of this.slideChangedHandlers)i.payload.currentStep!==void 0||i.payload.maxStep!==void 0?o(i.payload.currentPage,i.payload.totalPages||1,i.payload.currentBlockId||"",i.payload.currentStep,i.payload.maxStep):o(i.payload.currentPage,i.payload.totalPages||1,i.payload.currentBlockId||"");break;case"BLOCK_CLICKED":if(i.payload.clickedBlockId)for(const o of this.blockClickedHandlers)o(i.payload.clickedBlockId,i.payload.currentPage||1);break;case"OPEN_IN_EDITOR":if(i.payload.blockId||i.payload.clickedBlockId){const o=i.payload.blockId||i.payload.clickedBlockId||"";for(const a of this.openInEditorHandlers)a(o,i.payload.currentPage||1)}break;case"OPEN_PEEK_DRAWER":if(i.payload.peekType){const o=i.payload.blockId||i.payload.url||"",a={peekType:i.payload.peekType,target:o,title:i.payload.title};for(const r of this.openPeekDrawerHandlers)r(a)}break;case"REQUEST_TOGGLE_FULLSCREEN":for(const o of this.toggleFullscreenHandlers)o();break;case"OPEN_PRESENTER":for(const o of this.openPresenterHandlers)o();break;case"CAPTURE_PROGRESS":if(i.payload.captureProgress)for(const o of this.captureProgressHandlers)o(i.payload.captureProgress);break;case"CAPTURE_PAGE_DONE":if(i.payload.captureResult)for(const o of this.capturePageDoneHandlers)o(i.payload.captureResult);break;case"CAPTURE_COMPLETE":for(const o of this.captureCompleteHandlers)o({total:i.payload.totalPages||0});break;case"CAPTURE_ERROR":for(const o of this.captureErrorHandlers)o(i.payload.captureError||"未知沙箱截图异常");break}}}const jl={"snippets/external.ts":`// Inside ./snippets/external.ts
// #region snippet
export function emptyArray<T>(length: number) {
  return Array.from<T>({ length })
}
// #endregion snippet

export function sayHello() {
  console.log('Hello from snippets/external.ts')
}
`},yp=`<script setup lang="ts">
import { computed, useSlots } from 'vue'

const props = defineProps({
  layoutRatio: {
    type: String,
    default: '',
  },
  cols: {
    type: [Number, String],
    default: 0,
  },
})

const slots = useSlots()

const detectedColsCount = computed(() => {
  const explicitCols = Number(props.cols)
  if (explicitCols >= 2 && explicitCols <= 6) return explicitCols
  const r = (props.layoutRatio || '').trim()
  if (r.includes(':')) {
    const parts = r.split(':').map(p => parseFloat(p.trim())).filter(n => !isNaN(n) && n > 0)
    if (parts.length >= 2) return Math.min(parts.length, 6)
  }
  const tokens = r.split(/\\s+/).filter(Boolean)
  if (tokens.length >= 2) return Math.min(tokens.length, 6)
  for (let i = 6; i >= 3; i--) {
    if (slots[\`col-\${i}\`]) return i
  }
  if (slots['col-2'] || slots['right']) return 2
  return 2
})

const gridStyle = computed(() => {
  const r = props.layoutRatio || ''
  if (r) {
    if (r.includes(':')) {
      const parts = r.split(':').map(p => parseFloat(p.trim())).filter(n => !isNaN(n) && n > 0)
      if (parts.length >= 2) {
        return { gridTemplateColumns: parts.map(n => \`\${n}fr\`).join(' ') }
      }
    }
    const tokens = r.split(/\\s+/).filter(Boolean)
    if (tokens.length >= 2) {
      return { gridTemplateColumns: tokens.join(' ') }
    }
  }
  return { gridTemplateColumns: \`repeat(\${detectedColsCount.value}, minmax(0, 1fr))\` }
})
<\/script>

<template>
  <div class="slidev-layout cols-header w-full h-full flex flex-col">
    <div class="header-section mb-4 w-full">
      <slot />
    </div>
    <div class="grid gap-6 flex-1 items-stretch" :style="gridStyle">
      <div v-if="detectedColsCount >= 1" class="col-1 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-1"><slot name="left" /></slot>
      </div>
      <div v-if="detectedColsCount >= 2" class="col-2 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-2"><slot v-if="detectedColsCount === 2" name="right" /></slot>
      </div>
      <div v-if="detectedColsCount >= 3" class="col-3 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-3" />
      </div>
      <div v-if="detectedColsCount >= 4" class="col-4 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-4" />
      </div>
      <div v-if="detectedColsCount >= 5" class="col-5 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-5" />
      </div>
      <div v-if="detectedColsCount >= 6" class="col-6 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-6" />
      </div>
    </div>
  </div>
</template>
`,kp=`<script setup lang="ts">
import { computed } from 'vue'

const props = defineProps({
  layoutRatio: {
    type: String,
    default: '',
  },
})

const gridStyle = computed(() => {
  const r = props.layoutRatio || ''
  if (!r) return {}
  if (r.includes(':')) {
    const parts = r.split(':').map(p => parseFloat(p.trim())).filter(n => !isNaN(n) && n > 0)
    if (parts.length >= 2) {
      return { gridTemplateColumns: parts.map(n => \`\${n}fr\`).join(' ') }
    }
  }
  const tokens = r.split(/\\s+/).filter(Boolean)
  if (tokens.length >= 2) {
    return { gridTemplateColumns: tokens.join(' ') }
  }
  return {}
})
<\/script>

<template>
  <div class="slidev-layout three-cols-header w-full h-full flex flex-col">
    <div class="header-section mb-4 w-full">
      <slot />
    </div>
    <div class="grid gap-6 flex-1 items-stretch" :class="gridStyle.gridTemplateColumns ? '' : 'grid-cols-3'" :style="gridStyle">
      <div class="col-1 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-1" />
      </div>
      <div class="col-2 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-2" />
      </div>
      <div class="col-3 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-3" />
      </div>
    </div>
  </div>
</template>
`,wp=`<script setup lang="ts">
import { computed, useSlots } from 'vue'

const props = defineProps({
  mask: {
    type: String,
    default: '',
  },
  maskStyle: {
    type: String,
    default: 'solid',
  },
  maskInitial: {
    type: String,
    default: 'hidden',
  },
  clicks: {
    type: [Number, String],
    default: 0,
  },
})

const slots = useSlots()

const isClockMask = computed(() => {
  const m = props.mask || ''
  return m === 'clockwise' || m === 'counter-clockwise' || m === 'cw' || m === 'ccw'
})

const currentClockClicks = computed(() => {
  // 优先取 Slidev 全局 $slidev.nav.clicks，否则降级为 props.clicks
  // @ts-ignore
  const navClicks = typeof window !== 'undefined' && (window as any).$slidev?.nav?.clicks
  return typeof navClicks === 'number' ? navClicks : Number(props.clicks || 0)
})

const clockPercent = computed(() => {
  if (!isClockMask.value) return 100
  const isInitRev = props.maskInitial === 'revealed'
  const step = currentClockClicks.value
  const bps = [25, 50, 75, 100]
  if (step <= 0) return isInitRev ? bps[0] : 0
  const effectiveIdx = isInitRev ? step : (step - 1)
  if (effectiveIdx >= bps.length) return 100
  return bps[effectiveIdx] || 100
})

const clockNeedleAngle = computed(() => {
  const isCw = props.mask === 'clockwise' || props.mask === 'cw'
  const sweepDeg = Math.min(360, Math.max(0, (clockPercent.value / 100) * 360))
  return isCw ? (-180 + sweepDeg) : (-90 - sweepDeg)
})

const clockMaskOverlayStyle = computed(() => {
  if (!isClockMask.value) return {}
  const p = clockPercent.value
  const isCw = props.mask === 'clockwise' || props.mask === 'cw'
  const sweepDeg = Math.min(360, Math.max(0, (p / 100) * 360))
  let maskGrad = ''
  if (sweepDeg <= 0) {
    maskGrad = 'conic-gradient(from 0deg at 50% 50%, #000 0deg, #000 360deg)'
  } else if (sweepDeg >= 360) {
    maskGrad = 'conic-gradient(from 0deg at 50% 50%, transparent 0deg, transparent 360deg)'
  } else if (isCw) {
    maskGrad = \`conic-gradient(from 270deg at 50% 50%, transparent 0deg, transparent \${sweepDeg}deg, #000 \${sweepDeg}deg, #000 360deg)\`
  } else {
    const remDeg = 360 - sweepDeg
    maskGrad = \`conic-gradient(from 0deg at 50% 50%, #000 0deg, #000 \${remDeg}deg, transparent \${remDeg}deg, transparent 360deg)\`
  }
  return {
    WebkitMaskImage: maskGrad,
    maskImage: maskGrad,
  }
})
<\/script>

<template>
  <div class="slidev-layout clover w-full h-full flex flex-col">
    <div class="header-section mb-4 w-full">
      <slot />
    </div>
    <div class="relative flex-1 min-h-0 overflow-hidden">
      <div class="grid grid-cols-2 grid-rows-2 gap-6 w-full h-full items-stretch">
        <div class="col-1 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
          <slot name="col-1" />
        </div>
        <div class="col-2 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
          <slot name="col-2" />
        </div>
        <div class="col-3 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
          <slot name="col-3" />
        </div>
        <div class="col-4 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
          <slot name="col-4" />
        </div>
      </div>
      <div
        v-if="isClockMask"
        class="slides-mask-layer slides-mask-layer--clock pointer-events-none absolute inset-0 z-50 transition-opacity duration-300"
        :class="props.maskStyle === 'blur' ? 'slides-mask-layer--blur' : 'slides-mask-layer--solid'"
        :style="{ opacity: clockPercent >= 100 ? 0 : 1 }"
      >
        <div
          class="slides-mask-overlay absolute inset-0 w-full h-full"
          :class="props.maskStyle === 'blur' ? 'backdrop-blur-xl bg-white/70 dark:bg-black/70' : 'bg-[var(--slide-bg,#fff)] dark:bg-[var(--slide-bg,#121214)]'"
          :style="clockMaskOverlayStyle"
        />
        <div
          class="slides-mask-divider-line slides-mask-divider-line--clock absolute pointer-events-none transition-all duration-300"
          :style="{
            top: '50%',
            left: '50%',
            width: '55%',
            height: '2.5px',
            transformOrigin: '0% 50%',
            transform: \`translateY(-50%) rotate(\${clockNeedleAngle}deg)\`,
            opacity: (clockPercent <= 0 || clockPercent >= 100) ? 0 : 1,
            background: 'linear-gradient(90deg, var(--slide-accent, #3b82f6) 0%, var(--slide-accent, #3b82f6) 75%, transparent 100%)',
            boxShadow: '0 0 10px var(--slide-accent, #3b82f6), 0 0 4px var(--slide-accent, #3b82f6)',
          }"
        />
      </div>
    </div>
  </div>
</template>
`,xp=`// Auto-generated by SiYuan Slidev Studio
// 本地 HTML 链接（思源资产 / 工作区文件 / 绝对文件路径）速览判定
// 注意：需与 public/slides-client/index.html 中的拦截器保持同步
function isPeekableLocalHtml(href: string): boolean {
  const clean = (href || '').trim()
  if (!clean || clean.startsWith('#') || clean.startsWith('//')) return false
  if (!/\\.html?($|[?#])/i.test(clean)) return false
  if (/^https?:\\/\\//i.test(clean)) return false
  const scheme = /^([a-z][a-z0-9+.-]*):/i.exec(clean)
  if (!scheme) return true
  const schemeName = scheme[1].toLowerCase()
  if (schemeName === 'file') return true
  // Windows 盘符路径（D:\\\\docs\\\\demo.html）并非协议前缀
  return schemeName.length === 1 && /^[a-zA-Z]:[\\\\/]/.test(clean)
}

// 本地 HTML 链接预处理：思源资产统一指向内核 /assets/ 静态服务，其余原样转交宿主归一化
// 不基于 location 绝对化，保证 Pro 模式（Slidev dev server）与沙箱模式行为完全一致
function resolvePeekHref(href: string): string {
  const clean = (href || '').trim()
  if (/^(?:\\.\\/|\\/)?assets\\//.test(clean)) {
    return '/' + clean.replace(/^(?:\\.\\/|\\/)/, '')
  }
  return clean
}

export default function() {
  if (typeof window === 'undefined') return
  window.addEventListener('click', (e: MouseEvent) => {
    const target = e.target as HTMLElement | null
    if (!target || !target.closest) return

    const refEl = target.closest('[data-ref-id]')
    if (refEl) {
      const blockId = refEl.getAttribute('data-ref-id')
      if (blockId) {
        e.preventDefault()
        e.stopPropagation()
        window.parent.postMessage({
          source: 'siyuan-slides-client',
          action: 'OPEN_PEEK_DRAWER',
          payload: { peekType: 'siyuan', blockId, title: (refEl.innerText || refEl.title || '').trim() }
        }, '*')
        return
      }
    }

    const linkEl = target.closest('a') as HTMLAnchorElement | null
    if (linkEl) {
      const href = linkEl.getAttribute('href') || ''
      if (href.startsWith('siyuan://blocks/')) {
        e.preventDefault()
        e.stopPropagation()
        const cleanBlockId = href.replace('siyuan://blocks/', '').split('?')[0]
        window.parent.postMessage({
          source: 'siyuan-slides-client',
          action: 'OPEN_PEEK_DRAWER',
          payload: { peekType: 'siyuan', blockId: cleanBlockId, title: (linkEl.innerText || linkEl.title || '').trim() }
        }, '*')
      } else if (/^https?:\\/\\//i.test(href)) {
        e.preventDefault()
        e.stopPropagation()
        window.parent.postMessage({
          source: 'siyuan-slides-client',
          action: 'OPEN_PEEK_DRAWER',
          payload: { peekType: 'web', url: href, title: (linkEl.innerText || linkEl.title || '').trim() }
        }, '*')
      } else if (isPeekableLocalHtml(href)) {
        e.preventDefault()
        e.stopPropagation()
        window.parent.postMessage({
          source: 'siyuan-slides-client',
          action: 'OPEN_PEEK_DRAWER',
          payload: { peekType: 'web', url: resolvePeekHref(href), title: (linkEl.innerText || linkEl.title || '').trim() }
        }, '*')
      }
    }
  }, true)
}
`,Sp=`${Ro}

/* Auto-generated by SiYuan Slidev Studio */
.slides-ref-tag,
a.slides-ref-tag {
  display: inline-flex;
  align-items: center;
  background: color-mix(in srgb, var(--slides-theme-primary, #10b981) 12%, transparent);
  color: var(--slides-theme-primary, #10b981);
  border-radius: 4px;
  padding: 2px 8px;
  font-size: 0.88em;
  text-decoration: none;
  border: 1px solid color-mix(in srgb, var(--slides-theme-primary, #10b981) 25%, transparent);
  cursor: pointer;
  transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
  user-select: none;
}

.slides-ref-tag:hover,
a.slides-ref-tag:hover {
  background: color-mix(in srgb, var(--slides-theme-primary, #10b981) 22%, transparent);
  color: var(--slides-theme-primary, #10b981);
  border-color: color-mix(in srgb, var(--slides-theme-primary, #10b981) 55%, transparent);
  transform: translateY(-1px);
  box-shadow: 0 2px 8px color-mix(in srgb, var(--slides-theme-primary, #10b981) 20%, transparent);
}

.slides-block-ref {
  display: block;
  padding: 10px 14px;
  background: color-mix(in srgb, var(--slides-theme-primary, #10b981) 8%, transparent);
  border-left: 3px solid var(--slides-theme-primary, #10b981);
  border-radius: 0 6px 6px 0;
  margin: 8px 0;
  cursor: pointer;
  transition: background 0.2s ease;
}

.slides-block-ref:hover {
  background: color-mix(in srgb, var(--slides-theme-primary, #10b981) 15%, transparent);
}

/* 代码块自动换行与无横向滚动条 */
pre,
pre code {
  white-space: pre-wrap !important;
  word-break: break-all !important;
  overflow-wrap: anywhere !important;
  overflow-x: hidden !important;
  overflow-y: auto !important;
  max-width: 100% !important;
  box-sizing: border-box !important;
}

/* 弱提示滚动条样式 */
* {
  scrollbar-width: thin;
}
html:not(.dark) * {
  scrollbar-color: rgba(0, 0, 0, 0.15) transparent;
}
html.dark * {
  scrollbar-color: rgba(255, 255, 255, 0.20) transparent;
}
*::-webkit-scrollbar {
  width: 4px;
  height: 4px;
}
*::-webkit-scrollbar-track {
  background: transparent;
}
html:not(.dark) *::-webkit-scrollbar-thumb {
  background: rgba(0, 0, 0, 0.15);
  border-radius: 2px;
}
html:not(.dark) *:hover::-webkit-scrollbar-thumb,
html:not(.dark) *::-webkit-scrollbar-thumb:hover {
  background: rgba(0, 0, 0, 0.35);
}
html.dark *::-webkit-scrollbar-thumb {
  background: rgba(255, 255, 255, 0.20);
  border-radius: 2px;
}
html.dark *:hover::-webkit-scrollbar-thumb,
html.dark *::-webkit-scrollbar-thumb:hover {
  background: rgba(255, 255, 255, 0.45);
}

/* 多媒体（GIF动图、静态图片、MP4视频）最大化自适应且不超出视口：顶部对齐，横向居中 */
.slidev-layout img,
.slidev-layout video {
  max-width: 100% !important;
  max-height: 100% !important;
  width: auto;
  height: auto;
  object-fit: contain !important;
}
.three-cols-header video,
.two-cols-header video,
.grid-cols-3 video,
.grid-cols-2 video,
.col-1 video,
.col-2 video,
.col-3 video {
  width: auto !important;
  height: auto !important;
  max-width: 100% !important;
  max-height: 100% !important;
  object-fit: contain !important;
  display: block !important;
  margin: 0 auto !important;
}
.slide-list-media {
  display: flex !important;
  flex-direction: column !important;
  align-items: center !important;
  justify-content: flex-start !important;
  margin-top: 4px !important;
  margin-bottom: 4px !important;
  width: 100% !important;
  max-width: 100% !important;
  height: 100% !important;
  max-height: 100% !important;
  flex: 1 1 0% !important;
  overflow: hidden !important;
}
.slide-list-media img,
.slide-list-media video,
.slide-list-media .list-item-gif {
  width: auto !important;
  height: auto !important;
  max-width: 100% !important;
  max-height: 100% !important;
  object-fit: contain !important;
  border-radius: 6px !important;
  box-shadow: 0 3px 12px rgba(0, 0, 0, 0.14) !important;
  display: block !important;
  margin: 0 auto !important;
}
.slide-video-container {
  display: flex !important;
  flex-direction: column !important;
  justify-content: flex-start !important;
  align-items: center !important;
  width: 100% !important;
  max-height: 100% !important;
  margin: 6px 0 !important;
}
.slide-video-player {
  max-width: 100% !important;
  max-height: 100% !important;
  object-fit: contain !important;
  border-radius: 8px !important;
}

/* 两栏与多栏（超级块分栏）布局：紧凑自然行距，子列表保留圆点与层级缩进 */
.cols-header ul,
.three-cols-header ul,
.two-cols-header ul,
.two-cols ul,
.col-1 ul,
.col-2 ul,
.col-3 ul,
.col-4 ul,
.col-5 ul,
.col-6 ul,
.grid-cols-2 ul,
.grid-cols-3 ul {
  list-style: disc !important;
  list-style-type: disc !important;
  padding-left: 1.25em !important;
  margin-left: 0 !important;
  margin-top: 0 !important;
  margin-bottom: 8px !important;
  flex: 0 0 auto !important;
  height: auto !important;
  display: block !important;
}
.cols-header ol,
.three-cols-header ol,
.two-cols-header ol,
.two-cols ol,
.col-1 ol,
.col-2 ol,
.col-3 ol,
.col-4 ol,
.col-5 ol,
.col-6 ol,
.grid-cols-2 ol,
.grid-cols-3 ol {
  list-style: decimal !important;
  list-style-type: decimal !important;
  padding-left: 1.25em !important;
  margin-left: 0 !important;
  margin-top: 0 !important;
  margin-bottom: 8px !important;
  flex: 0 0 auto !important;
  height: auto !important;
  display: block !important;
}
.cols-header li,
.three-cols-header li,
.two-cols-header li,
.two-cols li,
.col-1 li,
.col-2 li,
.col-3 li,
.col-4 li,
.col-5 li,
.col-6 li,
.grid-cols-2 li,
.grid-cols-3 li {
  padding-left: 0.2em !important;
  margin-left: 0 !important;
  margin-bottom: 6px !important;
  flex: 0 0 auto !important;
  height: auto !important;
  display: list-item !important;
  line-height: 1.6 !important;
}
.cols-header ul ul,
.three-cols-header ul ul,
.two-cols-header ul ul,
.two-cols ul ul,
.col-1 ul ul,
.col-2 ul ul,
.col-3 ul ul,
.col-4 ul ul,
.col-5 ul ul,
.col-6 ul ul {
  list-style: circle !important;
  list-style-type: circle !important;
  padding-left: 1.25em !important;
  margin-top: 4px !important;
  margin-bottom: 4px !important;
}

/* 列表项内嵌标题与说明排版 */
.slide-list-item-title,
li > h1,
li > h2,
li > h3,
li > h4,
li > h5,
li > h6 {
  margin-top: 2px !important;
  margin-bottom: 6px !important;
  line-height: 1.35 !important;
  font-weight: 700 !important;
}
li > h1 { font-size: 1.6rem !important; }
li > h2 { font-size: 1.4rem !important; }
li > h3 { font-size: 1.22rem !important; }
li > h4 { font-size: 1.1rem !important; }
.slide-list-item-desc,
li > p {
  margin-top: 4px !important;
  margin-bottom: 6px !important;
  font-size: 1.05rem;
  line-height: 1.55;
  opacity: 0.92;
}
`;function Cp(e){var s;const t=[],i=/^[ \t]*<<<[ \t]+(?:@\/|\.\/|)([^\s#]+)(?:#[^\s]+)?/gm;let n;for(;(n=i.exec(e))!==null;){const o=(s=n[1])==null?void 0:s.trim();o&&!t.includes(o)&&t.push(o)}return t}class _p{constructor(t){be(this,"workspacePath");be(this,"slidesFileName");be(this,"cliBridge",new fr);const i=gp();!(t!=null&&t.workspacePath)||t.workspacePath.includes("/data/storage/petal/siyuan-live-slides/pro-workspace")?this.workspacePath=i:this.workspacePath=t.workspacePath,this.slidesFileName=(t==null?void 0:t.slidesFileName)||"slides.md"}getWorkspacePath(){return this.workspacePath}getSlidesPath(){return`${this.workspacePath}/${this.slidesFileName}`}generatePackageJson(t="default"){const i={name:"siyuan-live-slides-pro-workspace",type:"module",private:!0,scripts:{dev:"slidev --port 3030",build:"slidev build"},dependencies:{"@slidev/cli":"^53.0.0","@slidev/theme-default":"latest"}};return t&&t!=="default"&&(i.dependencies[`@slidev/theme-${t}`]="latest"),JSON.stringify(i,null,2)}buildSlidesMarkdown(t){return this.cliBridge.buildStandardSlidevMarkdown(t)}async scaffold(t,i){const n=this.buildSlidesMarkdown(t),s=this.generatePackageJson(t.config.theme),o=this.getSlidesPath(),a=`${this.workspacePath}/package.json`,r=zo(o),l=zo(a),c=Cp(n);c.includes("snippets/external.ts")||c.push("snippets/external.ts");const d=new Map;for(const k of c){const S=jl[k]||`// Auto-generated snippet placeholder for SiYuan Slidev
// #region snippet
// ${k}
// #endregion snippet
`;d.set(k,S)}t.slides.some(k=>{var S;return((S=k.frontmatter)==null?void 0:S.layout)==="cols-header"})&&d.set("layouts/cols-header.vue",yp),t.slides.some(k=>{var S;return((S=k.frontmatter)==null?void 0:S.layout)==="three-cols-header"})&&d.set("layouts/three-cols-header.vue",kp),t.slides.some(k=>{var S;return((S=k.frontmatter)==null?void 0:S.layout)==="clover"})&&d.set("layouts/clover.vue",wp),d.set("setup/root.ts",xp),d.set("styles/index.css",Sp);const w=Tt("fs"),m=Tt("path");let y=!1;const b=m!=null&&m.dirname?m.dirname(r):"",v=/^[a-zA-Z]:[/\\]/.test(r)||r.includes("siyuan-live-slides-pro");if(w&&m&&v)try{w.existsSync(b)||w.mkdirSync(b,{recursive:!0}),w.writeFileSync(l,s,"utf-8"),w.writeFileSync(r,n,"utf-8");for(const[k,S]of d.entries()){const D=m.join(b,k),A=m.dirname(D);w.existsSync(A)||w.mkdirSync(A,{recursive:!0}),w.existsSync(D)||w.writeFileSync(D,S,"utf-8")}y=!0}catch{}if(!y&&i)try{const k=typeof Blob<"u"?new Blob([n],{type:"text/markdown;charset=utf-8"}):Buffer.from(n,"utf-8"),S=typeof Blob<"u"?new Blob([s],{type:"application/json;charset=utf-8"}):Buffer.from(s,"utf-8");await i(a,!1,S),await i(o,!1,k);for(const[D,A]of d.entries()){const C=`${this.workspacePath}/${D}`,L=typeof Blob<"u"?new Blob([A],{type:"text/plain;charset=utf-8"}):Buffer.from(A,"utf-8");await i(C,!1,L).catch(()=>{})}return{success:!0,slidesPath:o,physicalSlidesPath:r,packageJsonPath:a}}catch(k){return{success:!1,slidesPath:o,physicalSlidesPath:r,packageJsonPath:a,error:String(k)}}return{success:!0,slidesPath:o,physicalSlidesPath:r,packageJsonPath:a}}}class $p{constructor(){be(this,"mode","web-sandbox");be(this,"webBridge");be(this,"cliBridge");be(this,"nativeBridge");be(this,"processManager");be(this,"scaffolder");be(this,"envDetector");this.webBridge=new Qn,this.cliBridge=new fr,this.nativeBridge=new vp,this.processManager=new bp,this.scaffolder=new _p,this.envDetector=new hr}getMode(){return this.mode}setMode(t){this.mode=t}async startProMode(t,i){if(!(await this.envDetector.detect()).hasNode)return{success:!1,url:"",error:"当前系统未检测到 Node.js 环境，无法拉起官方 Slidev CLI，建议继续使用内置高保真引擎"};const s=await this.scaffolder.scaffold(t,i);if(!s.success)return{success:!1,url:"",error:`初始化 Slidev 临时工作空间失败: ${s.error}`};const o=s.physicalSlidesPath||s.slidesPath,a=await this.processManager.startServer(o);return a.success?(this.mode="pro-cli",{success:!0,url:a.url,port:a.port}):{success:!1,url:"",error:a.error}}stopProMode(){this.processManager.stopServer(),this.mode="web-sandbox"}destroy(){this.webBridge.detach(),this.nativeBridge.detach(),this.processManager.stopServer()}}const Ip={class:"slides-icon",style:{fill:"none !important"},viewBox:"0 0 24 24",stroke:"currentColor","stroke-width":"1.75","stroke-linecap":"round","stroke-linejoin":"round","aria-hidden":"true"},Mp={key:0},Tp={key:1},Ep={key:2},Ap={key:3},Bp={key:4},Dp={key:5},Lp={key:6},Pp={key:7},Op={key:8},Rp={key:9},Np={key:10},zp={key:11},Hp={key:12},Fp={key:13},jp={key:14},Wp={key:15},Up={key:16},Vp={key:17},Gp={key:18},Kp={key:19},qp={key:20},Yp={key:21},Zp={key:22},Jp={key:23},Xp={key:24},Qp={key:25},eh={key:26},th={key:27},ih={key:28},nh={key:29},sh={key:30},oh={key:31},rh={key:32},ah={key:33},lh={key:34},ch={key:35},dh={key:36},uh={key:37},fh={key:38},ph={key:39},hh={key:40},mh={key:41},gh={key:42},vh={key:43},bh={key:44},yh={key:45},kh={key:46},wh={key:47},xh={key:48},Sh={key:49},Ch={key:50},_h={key:51},$h={key:52},Ih={key:53},Mh={key:54},Th={key:55},Eh={key:56},Ah={key:57},Bh={key:58},Dh={key:59},Lh={key:60},Ph={key:61},Oh={key:62},Rh={key:63},Nh={key:64},zh={key:65},Hh={key:66},Fh={key:67},jh={key:68},Wh={key:69},Uh={key:70},Vh={key:71},Gh={key:72},Kh=Dt({__name:"SlidesIcon",props:{name:{}},setup(e){return(t,i)=>(J(),ee("svg",Ip,[e.name==="fullscreen"||e.name==="maximize"?(J(),ee("g",Mp,[...i[0]||(i[0]=[h("polyline",{points:"15 3 21 3 21 9"},null,-1),h("polyline",{points:"9 21 3 21 3 15"},null,-1),h("polyline",{points:"21 15 21 21 15 21"},null,-1),h("polyline",{points:"3 9 3 3 9 3"},null,-1)])])):e.name==="minimize"?(J(),ee("g",Tp,[...i[1]||(i[1]=[h("polyline",{points:"4 14 10 14 10 20"},null,-1),h("polyline",{points:"20 10 14 10 14 4"},null,-1),h("line",{x1:"14",y1:"10",x2:"21",y2:"3"},null,-1),h("line",{x1:"3",y1:"21",x2:"10",y2:"14"},null,-1)])])):e.name==="close"||e.name==="x"?(J(),ee("g",Ep,[...i[2]||(i[2]=[h("line",{x1:"18",y1:"6",x2:"6",y2:"18"},null,-1),h("line",{x1:"6",y1:"6",x2:"18",y2:"18"},null,-1)])])):e.name==="edit"?(J(),ee("g",Ap,[...i[3]||(i[3]=[h("path",{d:"M12 20h9"},null,-1),h("path",{d:"M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z"},null,-1)])])):e.name==="eye"?(J(),ee("g",Bp,[...i[4]||(i[4]=[h("path",{d:"M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"},null,-1),h("circle",{cx:"12",cy:"12",r:"3"},null,-1)])])):e.name==="external-link"||e.name==="window"?(J(),ee("g",Dp,[...i[5]||(i[5]=[h("path",{d:"M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"},null,-1),h("polyline",{points:"15 3 21 3 21 9"},null,-1),h("line",{x1:"10",y1:"14",x2:"21",y2:"3"},null,-1)])])):e.name==="arrow-left"?(J(),ee("g",Lp,[...i[6]||(i[6]=[h("line",{x1:"19",y1:"12",x2:"5",y2:"12"},null,-1),h("polyline",{points:"12 19 5 12 12 5"},null,-1)])])):e.name==="arrow-right"?(J(),ee("g",Pp,[...i[7]||(i[7]=[h("line",{x1:"5",y1:"12",x2:"19",y2:"12"},null,-1),h("polyline",{points:"12 5 19 12 12 19"},null,-1)])])):e.name==="plus"?(J(),ee("g",Op,[...i[8]||(i[8]=[h("line",{x1:"12",y1:"5",x2:"12",y2:"19"},null,-1),h("line",{x1:"5",y1:"12",x2:"19",y2:"12"},null,-1)])])):e.name==="minus"?(J(),ee("g",Rp,[...i[9]||(i[9]=[h("line",{x1:"5",y1:"12",x2:"19",y2:"12"},null,-1)])])):e.name==="split-preview"?(J(),ee("g",Np,[...i[10]||(i[10]=[h("rect",{x:"3",y:"3",width:"18",height:"18",rx:"2"},null,-1),h("path",{d:"M12 3v18"},null,-1)])])):e.name==="import"?(J(),ee("g",zp,[...i[11]||(i[11]=[h("path",{d:"M4 17v2a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-2"},null,-1),h("polyline",{points:"7 9 12 14 17 9"},null,-1),h("line",{x1:"12",y1:"14",x2:"12",y2:"3"},null,-1)])])):e.name==="presenter"?(J(),ee("g",Hp,[...i[12]||(i[12]=[h("path",{d:"M2 3h20"},null,-1),h("path",{d:"M21 3v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V3"},null,-1),h("path",{d:"m7 21 5-5 5 5"},null,-1)])])):e.name==="video"?(J(),ee("g",Fp,[...i[13]||(i[13]=[h("polygon",{points:"23 7 16 12 23 17 23 7"},null,-1),h("rect",{x:"1",y:"5",width:"15",height:"14",rx:"2",ry:"2"},null,-1)])])):e.name==="step"?(J(),ee("g",jp,[...i[14]||(i[14]=[h("polygon",{points:"13 2 3 14 12 14 11 22 21 10 12 10 13 2"},null,-1)])])):e.name==="motion"?(J(),ee("g",Wp,[...i[15]||(i[15]=[h("path",{d:"M5 12h14"},null,-1),h("path",{d:"m12 5 7 7-7 7"},null,-1),h("path",{d:"M5 6h4"},null,-1),h("path",{d:"M5 18h4"},null,-1)])])):e.name==="columns"?(J(),ee("g",Up,[...i[16]||(i[16]=[h("rect",{x:"3",y:"3",width:"7",height:"18",rx:"1"},null,-1),h("rect",{x:"14",y:"3",width:"7",height:"18",rx:"1"},null,-1)])])):e.name==="code"?(J(),ee("g",Vp,[...i[17]||(i[17]=[h("polyline",{points:"16 18 22 12 16 6"},null,-1),h("polyline",{points:"8 6 2 12 8 18"},null,-1)])])):e.name==="list"?(J(),ee("g",Gp,[...i[18]||(i[18]=[ht('<line x1="8" y1="6" x2="21" y2="6" data-v-af7d02a2></line><line x1="8" y1="12" x2="21" y2="12" data-v-af7d02a2></line><line x1="8" y1="18" x2="21" y2="18" data-v-af7d02a2></line><line x1="3" y1="6" x2="3.01" y2="6" data-v-af7d02a2></line><line x1="3" y1="12" x2="3.01" y2="12" data-v-af7d02a2></line><line x1="3" y1="18" x2="3.01" y2="18" data-v-af7d02a2></line>',6)])])):e.name==="insert-above"?(J(),ee("g",Kp,[...i[19]||(i[19]=[h("line",{x1:"12",y1:"5",x2:"12",y2:"13"},null,-1),h("line",{x1:"8",y1:"9",x2:"16",y2:"9"},null,-1),h("path",{d:"M4 19h16","stroke-dasharray":"2 2"},null,-1)])])):e.name==="insert-below"?(J(),ee("g",qp,[...i[20]||(i[20]=[h("path",{d:"M4 5h16","stroke-dasharray":"2 2"},null,-1),h("line",{x1:"12",y1:"11",x2:"12",y2:"19"},null,-1),h("line",{x1:"8",y1:"15",x2:"16",y2:"15"},null,-1)])])):e.name==="broom"?(J(),ee("g",Yp,[...i[21]||(i[21]=[h("path",{d:"m18 15-6-6"},null,-1),h("path",{d:"M4 20h16"},null,-1),h("path",{d:"M6 14l8-8a2.8 2.8 0 0 1 4 4l-8 8H6v-4z"},null,-1)])])):e.name==="trash"?(J(),ee("g",Zp,[...i[22]||(i[22]=[h("path",{d:"M3 6h18"},null,-1),h("path",{d:"M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"},null,-1),h("path",{d:"M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"},null,-1)])])):e.name==="ai"||e.name==="sparkles"?(J(),ee("g",Jp,[...i[23]||(i[23]=[h("path",{d:"m12 3-1.9 5.8a2 2 0 0 1-1.3 1.3L3 12l5.8 1.9a2 2 0 0 1 1.3 1.3L12 21l1.9-5.8a2 2 0 0 1 1.3-1.3L21 12l-5.8-1.9a2 2 0 0 1-1.3-1.3L12 3z"},null,-1)])])):e.name==="palette"?(J(),ee("g",Xp,[...i[24]||(i[24]=[ht('<circle cx="13.5" cy="6.5" r=".5" fill="currentColor" data-v-af7d02a2></circle><circle cx="17.5" cy="10.5" r=".5" fill="currentColor" data-v-af7d02a2></circle><circle cx="8.5" cy="7.5" r=".5" fill="currentColor" data-v-af7d02a2></circle><circle cx="6.5" cy="12.5" r=".5" fill="currentColor" data-v-af7d02a2></circle><path d="M12 2C6.5 2 2 6.5 2 12s4.5 10 10 10c.9 0 1.5-.7 1.5-1.5 0-.4-.2-.8-.4-1.1-.3-.4-.4-.8-.4-1.4 0-1.1.9-2 2-2h2.3c3.9 0 7-3.1 7-7 0-5-4.5-9-10-9z" data-v-af7d02a2></path>',5)])])):e.name==="ratio"?(J(),ee("g",Qp,[...i[25]||(i[25]=[h("rect",{x:"2",y:"5",width:"20",height:"14",rx:"2"},null,-1),h("line",{x1:"2",y1:"10",x2:"22",y2:"10","stroke-dasharray":"2 2"},null,-1)])])):e.name==="transition"?(J(),ee("g",eh,[...i[26]||(i[26]=[h("path",{d:"M8 3 4 7l4 4"},null,-1),h("path",{d:"M4 7h16"},null,-1),h("path",{d:"m16 21 4-4-4-4"},null,-1),h("path",{d:"M20 17H4"},null,-1)])])):e.name==="export-html"?(J(),ee("g",th,[...i[27]||(i[27]=[h("polyline",{points:"16 16 12 12 8 16"},null,-1),h("line",{x1:"12",y1:"12",x2:"12",y2:"21"},null,-1),h("path",{d:"M20.4 16.3A5 5 0 0 0 18 7h-1.3A8 8 0 0 0 4 12.8a5 5 0 0 0 1.5 9.2"},null,-1)])])):e.name==="export-pdf"?(J(),ee("g",ih,[...i[28]||(i[28]=[h("polyline",{points:"6 9 6 2 18 2 18 9"},null,-1),h("path",{d:"M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"},null,-1),h("rect",{x:"6",y:"14",width:"12",height:"8"},null,-1)])])):e.name==="pin"?(J(),ee("g",nh,[...i[29]||(i[29]=[h("line",{x1:"12",y1:"17",x2:"12",y2:"22"},null,-1),h("path",{d:"M5 17h14v-2l-2-2V5l1-1V2H6v2l1 1v8l-2 2v2z"},null,-1)])])):e.name==="refresh"?(J(),ee("g",sh,[...i[30]||(i[30]=[h("path",{d:"M3 12a9 9 0 0 1 9-9 9.75 9.75 0 0 1 6.74 2.74L21 8"},null,-1),h("path",{d:"M21 3v5h-5"},null,-1),h("path",{d:"M21 12a9 9 0 0 1-9 9 9.75 9.75 0 0 1-6.74-2.74L3 16"},null,-1),h("path",{d:"M8 16H3v5"},null,-1)])])):e.name==="alert"||e.name==="warning"?(J(),ee("g",oh,[...i[31]||(i[31]=[h("path",{d:"M10.29 3.86 1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"},null,-1),h("line",{x1:"12",y1:"9",x2:"12",y2:"13"},null,-1),h("line",{x1:"12",y1:"17",x2:"12.01",y2:"17"},null,-1)])])):e.name==="chevron-left"?(J(),ee("g",rh,[...i[32]||(i[32]=[h("polyline",{points:"15 18 9 12 15 6"},null,-1)])])):e.name==="chevron-right"?(J(),ee("g",ah,[...i[33]||(i[33]=[h("polyline",{points:"9 18 15 12 9 6"},null,-1)])])):e.name==="chevron-down"?(J(),ee("g",lh,[...i[34]||(i[34]=[h("polyline",{points:"6 9 12 15 18 9"},null,-1)])])):e.name==="chevrons-left"?(J(),ee("g",ch,[...i[35]||(i[35]=[h("polyline",{points:"11 17 6 12 11 7"},null,-1),h("polyline",{points:"18 17 13 12 18 7"},null,-1)])])):e.name==="chevrons-right"?(J(),ee("g",dh,[...i[36]||(i[36]=[h("polyline",{points:"13 17 18 12 13 7"},null,-1),h("polyline",{points:"6 17 11 12 6 7"},null,-1)])])):e.name==="play"?(J(),ee("g",uh,[...i[37]||(i[37]=[h("polygon",{points:"6 3 20 12 6 21 6 3"},null,-1)])])):e.name==="pause"?(J(),ee("g",fh,[...i[38]||(i[38]=[h("line",{x1:"10",y1:"4",x2:"10",y2:"20"},null,-1),h("line",{x1:"14",y1:"4",x2:"14",y2:"20"},null,-1)])])):e.name==="clock"?(J(),ee("g",ph,[...i[39]||(i[39]=[h("circle",{cx:"12",cy:"12",r:"10"},null,-1),h("polyline",{points:"12 6 12 12 16 14"},null,-1)])])):e.name==="copy"?(J(),ee("g",hh,[...i[40]||(i[40]=[h("rect",{x:"9",y:"9",width:"13",height:"13",rx:"2",ry:"2"},null,-1),h("path",{d:"M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"},null,-1)])])):e.name==="image"||e.name==="export-image"?(J(),ee("g",mh,[...i[41]||(i[41]=[h("rect",{x:"3",y:"3",width:"18",height:"18",rx:"2",ry:"2"},null,-1),h("circle",{cx:"8.5",cy:"8.5",r:"1.5"},null,-1),h("polyline",{points:"21 15 16 10 5 21"},null,-1)])])):e.name==="search"?(J(),ee("g",gh,[...i[42]||(i[42]=[h("circle",{cx:"11",cy:"11",r:"7"},null,-1),h("line",{x1:"21",y1:"21",x2:"16.65",y2:"16.65"},null,-1)])])):e.name==="settings"||e.name==="gear"?(J(),ee("g",vh,[...i[43]||(i[43]=[h("circle",{cx:"12",cy:"12",r:"3"},null,-1),h("path",{d:"M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 1 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 1 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 1 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 1 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"},null,-1)])])):e.name==="notes"||e.name==="file-text"?(J(),ee("g",bh,[...i[44]||(i[44]=[ht('<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" data-v-af7d02a2></path><polyline points="14 2 14 8 20 8" data-v-af7d02a2></polyline><line x1="16" y1="13" x2="8" y2="13" data-v-af7d02a2></line><line x1="16" y1="17" x2="8" y2="17" data-v-af7d02a2></line><line x1="10" y1="9" x2="8" y2="9" data-v-af7d02a2></line>',5)])])):e.name==="focus"||e.name==="target"?(J(),ee("g",yh,[...i[45]||(i[45]=[h("circle",{cx:"12",cy:"12",r:"3",fill:"currentColor"},null,-1),h("path",{d:"M12 2v4M12 18v4M2 12h4M18 12h4",stroke:"currentColor","stroke-width":"2","stroke-linecap":"round"},null,-1),h("circle",{cx:"12",cy:"12",r:"7",fill:"none",stroke:"currentColor","stroke-width":"1.8"},null,-1)])])):e.name==="layout-cover"||e.name==="cover"?(J(),ee("g",kh,[...i[46]||(i[46]=[h("rect",{x:"2",y:"4",width:"20",height:"16",rx:"2"},null,-1),h("line",{x1:"9",y1:"8",x2:"15",y2:"8"},null,-1),h("line",{x1:"5.5",y1:"11.5",x2:"18.5",y2:"11.5"},null,-1),h("line",{x1:"7.5",y1:"15",x2:"16.5",y2:"15"},null,-1)])])):e.name==="layout-default"||e.name==="default"?(J(),ee("g",wh,[...i[47]||(i[47]=[ht('<rect x="2" y="4" width="20" height="16" rx="2" data-v-af7d02a2></rect><line x1="5" y1="8" x2="11.5" y2="8" data-v-af7d02a2></line><line x1="5" y1="11.5" x2="19" y2="11.5" data-v-af7d02a2></line><line x1="5" y1="14.5" x2="19" y2="14.5" data-v-af7d02a2></line><line x1="5" y1="17.5" x2="13.5" y2="17.5" data-v-af7d02a2></line>',5)])])):e.name==="layout-two-cols"||e.name==="two-cols"?(J(),ee("g",xh,[...i[48]||(i[48]=[ht('<rect x="2" y="4" width="20" height="16" rx="2" data-v-af7d02a2></rect><line x1="12" y1="4" x2="12" y2="20" stroke-dasharray="2 1.5" data-v-af7d02a2></line><line x1="5" y1="8" x2="9.5" y2="8" data-v-af7d02a2></line><line x1="5" y1="11.5" x2="9.5" y2="11.5" data-v-af7d02a2></line><line x1="5" y1="15" x2="8" y2="15" data-v-af7d02a2></line><line x1="14.5" y1="8" x2="19" y2="8" data-v-af7d02a2></line><line x1="14.5" y1="11.5" x2="19" y2="11.5" data-v-af7d02a2></line><line x1="14.5" y1="15" x2="17.5" y2="15" data-v-af7d02a2></line>',8)])])):e.name==="layout-two-cols-header"||e.name==="two-cols-header"?(J(),ee("g",Sh,[...i[49]||(i[49]=[ht('<rect x="2" y="4" width="20" height="16" rx="2" data-v-af7d02a2></rect><line x1="5" y1="7.5" x2="13" y2="7.5" data-v-af7d02a2></line><line x1="12" y1="10.5" x2="12" y2="18.5" stroke-dasharray="1.5 1.5" data-v-af7d02a2></line><line x1="5" y1="12" x2="9.5" y2="12" data-v-af7d02a2></line><line x1="5" y1="15.5" x2="8.5" y2="15.5" data-v-af7d02a2></line><line x1="14.5" y1="12" x2="19" y2="12" data-v-af7d02a2></line><line x1="14.5" y1="15.5" x2="18" y2="15.5" data-v-af7d02a2></line>',7)])])):e.name==="layout-cols-header"||e.name==="cols-header"||e.name==="layout-three-cols-header"||e.name==="three-cols-header"?(J(),ee("g",Ch,[...i[50]||(i[50]=[ht('<rect x="2" y="4" width="20" height="16" rx="2" data-v-af7d02a2></rect><line x1="5" y1="7.5" x2="13" y2="7.5" data-v-af7d02a2></line><line x1="9.3" y1="10.5" x2="9.3" y2="18.5" stroke-dasharray="1.5 1.5" data-v-af7d02a2></line><line x1="14.7" y1="10.5" x2="14.7" y2="18.5" stroke-dasharray="1.5 1.5" data-v-af7d02a2></line><line x1="4.5" y1="12" x2="7.5" y2="12" data-v-af7d02a2></line><line x1="4.5" y1="15.5" x2="7" y2="15.5" data-v-af7d02a2></line><line x1="10.5" y1="12" x2="13.5" y2="12" data-v-af7d02a2></line><line x1="10.5" y1="15.5" x2="13.5" y2="15.5" data-v-af7d02a2></line><line x1="16" y1="12" x2="19.5" y2="12" data-v-af7d02a2></line><line x1="16" y1="15.5" x2="18.5" y2="15.5" data-v-af7d02a2></line>',10)])])):e.name==="layout-clover"||e.name==="clover"?(J(),ee("g",_h,[...i[51]||(i[51]=[ht('<rect x="2" y="4" width="20" height="16" rx="2" data-v-af7d02a2></rect><line x1="5" y1="7" x2="13" y2="7" data-v-af7d02a2></line><line x1="4.5" y1="13.5" x2="19.5" y2="13.5" stroke-dasharray="1.5 1.5" data-v-af7d02a2></line><line x1="12" y1="9" x2="12" y2="18.5" stroke-dasharray="1.5 1.5" data-v-af7d02a2></line><line x1="5" y1="11" x2="9.5" y2="11" data-v-af7d02a2></line><line x1="14.5" y1="11" x2="19" y2="11" data-v-af7d02a2></line><line x1="5" y1="16" x2="9.5" y2="16" data-v-af7d02a2></line><line x1="14.5" y1="16" x2="19" y2="16" data-v-af7d02a2></line>',8)])])):e.name==="layout-image-right"||e.name==="image-right"?(J(),ee("g",$h,[...i[52]||(i[52]=[ht('<rect x="2" y="4" width="20" height="16" rx="2" data-v-af7d02a2></rect><line x1="12" y1="4" x2="12" y2="20" data-v-af7d02a2></line><line x1="4.5" y1="8" x2="9.5" y2="8" data-v-af7d02a2></line><line x1="4.5" y1="11.5" x2="10" y2="11.5" data-v-af7d02a2></line><line x1="4.5" y1="14.5" x2="8" y2="14.5" data-v-af7d02a2></line><circle cx="15.5" cy="8.5" r="1.2" data-v-af7d02a2></circle><polyline points="13 17 15.5 13 18 16 19.5 14" data-v-af7d02a2></polyline>',7)])])):e.name==="layout-image-left"||e.name==="image-left"?(J(),ee("g",Ih,[...i[53]||(i[53]=[ht('<rect x="2" y="4" width="20" height="16" rx="2" data-v-af7d02a2></rect><line x1="12" y1="4" x2="12" y2="20" data-v-af7d02a2></line><circle cx="6" cy="8.5" r="1.2" data-v-af7d02a2></circle><polyline points="3.5 17 6 13 8.5 16 10 14" data-v-af7d02a2></polyline><line x1="14.5" y1="8" x2="19.5" y2="8" data-v-af7d02a2></line><line x1="14.5" y1="11.5" x2="20" y2="11.5" data-v-af7d02a2></line><line x1="14.5" y1="14.5" x2="18" y2="14.5" data-v-af7d02a2></line>',7)])])):e.name==="layout-center"||e.name==="center"?(J(),ee("g",Mh,[...i[54]||(i[54]=[h("rect",{x:"2",y:"4",width:"20",height:"16",rx:"2"},null,-1),h("line",{x1:"6.5",y1:"9",x2:"17.5",y2:"9"},null,-1),h("line",{x1:"5",y1:"12",x2:"19",y2:"12"},null,-1),h("line",{x1:"8",y1:"15",x2:"16",y2:"15"},null,-1)])])):e.name==="layout-fact"||e.name==="fact"?(J(),ee("g",Th,[...i[55]||(i[55]=[ht('<rect x="2" y="4" width="20" height="16" rx="2" data-v-af7d02a2></rect><circle cx="8" cy="9" r="1.5" data-v-af7d02a2></circle><line x1="14" y1="8" x2="9" y2="14" data-v-af7d02a2></line><circle cx="15" cy="13" r="1.5" data-v-af7d02a2></circle><line x1="6.5" y1="17" x2="17.5" y2="17" data-v-af7d02a2></line>',5)])])):e.name==="layout-intro"||e.name==="intro"?(J(),ee("g",Eh,[...i[56]||(i[56]=[ht('<rect x="2" y="4" width="20" height="16" rx="2" data-v-af7d02a2></rect><circle cx="7.5" cy="9.5" r="2" data-v-af7d02a2></circle><path d="M4.5 16.5c0-1.8 1.3-3 3-3s3 1.2 3 3" data-v-af7d02a2></path><line x1="13" y1="9" x2="18.5" y2="9" data-v-af7d02a2></line><line x1="13" y1="12.5" x2="19.5" y2="12.5" data-v-af7d02a2></line><line x1="13" y1="15.5" x2="17" y2="15.5" data-v-af7d02a2></line>',6)])])):e.name==="layout-quote"||e.name==="quote"?(J(),ee("g",Ah,[...i[57]||(i[57]=[ht('<rect x="2" y="4" width="20" height="16" rx="2" data-v-af7d02a2></rect><path d="M6 7.5h2v2H6.5c0 1.2-.4 2-1.5 2.5" data-v-af7d02a2></path><path d="M9.5 7.5h2v2H10c0 1.2-.4 2-1.5 2.5" data-v-af7d02a2></path><line x1="6" y1="13.5" x2="18" y2="13.5" data-v-af7d02a2></line><line x1="12.5" y1="16.5" x2="17.5" y2="16.5" data-v-af7d02a2></line>',5)])])):e.name==="desktop"||e.name==="monitor"?(J(),ee("g",Bh,[...i[58]||(i[58]=[h("rect",{x:"2",y:"3",width:"20",height:"14",rx:"2"},null,-1),h("line",{x1:"8",y1:"21",x2:"16",y2:"21"},null,-1),h("line",{x1:"12",y1:"17",x2:"12",y2:"21"},null,-1)])])):e.name==="mobile"||e.name==="smartphone"||e.name==="phone"?(J(),ee("g",Dh,[...i[59]||(i[59]=[h("rect",{x:"5",y:"2",width:"14",height:"20",rx:"2",ry:"2"},null,-1),h("line",{x1:"12",y1:"18",x2:"12.01",y2:"18","stroke-width":"2","stroke-linecap":"round"},null,-1)])])):e.name==="type"||e.name==="heading"?(J(),ee("g",Lh,[...i[60]||(i[60]=[h("polyline",{points:"4 7 4 4 20 4 20 7"},null,-1),h("line",{x1:"9",y1:"20",x2:"15",y2:"20"},null,-1),h("line",{x1:"12",y1:"4",x2:"12",y2:"20"},null,-1)])])):e.name==="reset"||e.name==="undo"?(J(),ee("g",Ph,[...i[61]||(i[61]=[h("path",{d:"M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8"},null,-1),h("polyline",{points:"3 3 3 8 8 8"},null,-1)])])):e.name==="repeat"||e.name==="loop"?(J(),ee("g",Oh,[...i[62]||(i[62]=[h("path",{d:"m17 1 4 4-4 4"},null,-1),h("path",{d:"M3 11V9a4 4 0 0 1 4-4h14"},null,-1),h("path",{d:"m7 23-4-4 4-4"},null,-1),h("path",{d:"M21 13v2a4 4 0 0 1-4 4H3"},null,-1)])])):e.name==="volume-x"||e.name==="mute"?(J(),ee("g",Rh,[...i[63]||(i[63]=[h("polygon",{points:"11 5 6 9 2 9 2 15 6 15 11 19 11 5"},null,-1),h("line",{x1:"22",y1:"9",x2:"16",y2:"15"},null,-1),h("line",{x1:"16",y1:"9",x2:"22",y2:"15"},null,-1)])])):e.name==="sliders"||e.name==="controls"?(J(),ee("g",Nh,[...i[64]||(i[64]=[ht('<line x1="4" y1="21" x2="4" y2="14" data-v-af7d02a2></line><line x1="4" y1="10" x2="4" y2="3" data-v-af7d02a2></line><line x1="12" y1="21" x2="12" y2="12" data-v-af7d02a2></line><line x1="12" y1="8" x2="12" y2="3" data-v-af7d02a2></line><line x1="20" y1="21" x2="20" y2="16" data-v-af7d02a2></line><line x1="20" y1="12" x2="20" y2="3" data-v-af7d02a2></line><line x1="1" y1="14" x2="7" y2="14" data-v-af7d02a2></line><line x1="9" y1="8" x2="15" y2="8" data-v-af7d02a2></line><line x1="17" y1="16" x2="23" y2="16" data-v-af7d02a2></line>',9)])])):e.name==="package"||e.name==="zip"||e.name==="archive"?(J(),ee("g",zh,[...i[65]||(i[65]=[h("line",{x1:"16.5",y1:"9.4",x2:"7.5",y2:"4.21"},null,-1),h("path",{d:"M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"},null,-1),h("polyline",{points:"3.27 6.96 12 12.01 20.73 6.96"},null,-1),h("line",{x1:"12",y1:"22.08",x2:"12",y2:"12"},null,-1)])])):e.name==="folder"?(J(),ee("g",Hh,[...i[66]||(i[66]=[h("path",{d:"M4 20h16a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2h-7.93a2 2 0 0 1-1.66-.9l-.82-1.2A2 2 0 0 0 7.93 3H4a2 2 0 0 0-2 2v13c0 1.1.9 2 2 2Z"},null,-1)])])):e.name==="rocket"?(J(),ee("g",Fh,[...i[67]||(i[67]=[h("path",{d:"M4.5 16.5c-1.5 1.26-2 5-2 5s3.74-.5 5-2c.71-.84.7-2.13-.09-2.91a2.18 2.18 0 0 0-2.91-.09z"},null,-1),h("path",{d:"m12 15-3-3a22 22 0 0 1 2-3.95A12.88 12.88 0 0 1 22 2c0 2.72-.78 7.5-6 11a22.35 22.35 0 0 1-4 2z"},null,-1),h("path",{d:"M9 12H4s.55-3.03 2-4c1.62-1.08 5 0 5 0"},null,-1),h("path",{d:"M12 15v5s3.03-.55 4-2c1.08-1.62 0-5 0-5"},null,-1)])])):e.name==="wand"||e.name==="magic"?(J(),ee("g",jh,[...i[68]||(i[68]=[h("path",{d:"m19 2 2 2-6 6-2-2Z"},null,-1),h("path",{d:"m13 8 2 2"},null,-1),h("path",{d:"m3 21 9-9"},null,-1)])])):e.name==="image-left"?(J(),ee("g",Wh,[...i[69]||(i[69]=[ht('<rect x="2" y="4" width="20" height="16" rx="2" data-v-af7d02a2></rect><rect x="4" y="6" width="6" height="12" rx="1" data-v-af7d02a2></rect><line x1="13" y1="8" x2="19" y2="8" data-v-af7d02a2></line><line x1="13" y1="12" x2="19" y2="12" data-v-af7d02a2></line><line x1="13" y1="16" x2="17" y2="16" data-v-af7d02a2></line>',5)])])):e.name==="image-right"?(J(),ee("g",Uh,[...i[70]||(i[70]=[ht('<rect x="2" y="4" width="20" height="16" rx="2" data-v-af7d02a2></rect><rect x="14" y="6" width="6" height="12" rx="1" data-v-af7d02a2></rect><line x1="5" y1="8" x2="11" y2="8" data-v-af7d02a2></line><line x1="5" y1="12" x2="11" y2="12" data-v-af7d02a2></line><line x1="5" y1="16" x2="9" y2="16" data-v-af7d02a2></line>',5)])])):e.name==="help"||e.name==="question"||e.name==="info"?(J(),ee("g",Vh,[...i[71]||(i[71]=[h("circle",{cx:"12",cy:"12",r:"10"},null,-1),h("path",{d:"M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"},null,-1),h("line",{x1:"12",y1:"17",x2:"12.01",y2:"17"},null,-1)])])):(J(),ee("g",Gh,[...i[72]||(i[72]=[h("rect",{x:"2",y:"3",width:"20",height:"14",rx:"2"},null,-1),h("line",{x1:"8",y1:"21",x2:"16",y2:"21"},null,-1),h("line",{x1:"12",y1:"17",x2:"12",y2:"21"},null,-1)])]))]))}}),ii=(e,t)=>{const i=e.__vccOpts||e;for(const[n,s]of t)i[n]=s;return i},de=ii(Kh,[["__scopeId","data-v-af7d02a2"]]),qh={class:"spm-immersion-header"},Yh={class:"spm-immersion-header__left"},Zh={class:"spm-immersion-title"},Jh={class:"spm-immersion-header__center"},Xh={class:"spm-immersion-header__actions"},Qh=["aria-label"],em={class:"spm-immersion-body"},tm=Dt({__name:"ImmersionDrawerContainer",props:{visible:{type:Boolean,default:!1},isMaximized:{type:Boolean,default:!1},title:{default:"速览"},closeOnClickMask:{type:Boolean,default:!0}},emits:["update:visible","update:isMaximized","close","toggle-maximize"],setup(e,{emit:t}){const i=e,n=t;function s(){n("update:visible",!1),n("close")}function o(){i.closeOnClickMask&&s()}function a(){n("update:isMaximized",!i.isMaximized),n("toggle-maximize")}function r(l){(l.key===" "||l.key==="ArrowLeft"||l.key==="ArrowRight"||l.key==="PageUp"||l.key==="PageDown")&&l.stopPropagation(),l.key==="Escape"&&(l.preventDefault(),l.stopPropagation(),s())}return(l,c)=>Ot((J(),ee("div",{class:Ce(["spm-immersion-container",{"is-maximized":e.isMaximized}]),onKeydown:Zt(r,["stop"])},[h("div",{class:"spm-immersion-mask",onClick:o}),h("div",{class:Ce(["spm-immersion-drawer",{"is-maximized":e.isMaximized}])},[h("div",qh,[h("div",Yh,[rs(l.$slots,"header-left",{},()=>[h("span",Zh,we(e.title),1)])]),h("div",Jh,[rs(l.$slots,"header-center",{},void 0)]),h("div",Xh,[rs(l.$slots,"header-actions",{},void 0),h("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":e.isMaximized?"还原抽屉宽度 (70%)":"最大化填满视口 (100%)",onClick:a},[re(de,{name:e.isMaximized?"minimize":"maximize"},null,8,["name"])],8,Qh),h("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"关闭速览 (ESC)",onClick:s},[re(de,{name:"close"})])])]),h("div",em,[rs(l.$slots,"default",{},void 0)])],2)],34)),[[Lo,e.visible]])}}),im=ii(tm,[["__scopeId","data-v-1359fecb"]]),nm={class:"spm-protyle-drawer"},sm={class:"spm-protyle-drawer__subbar"},om={class:"spm-protyle-drawer__nav"},rm=["title"],am={class:"spm-protyle-drawer__actions"},lm=["aria-label"],cm=["aria-label"],dm=Dt({__name:"ProtylePeekDrawer",props:{blockId:{},title:{},plugin:{}},emits:["external-jump"],setup(e,{emit:t}){const i=t,n=e,s=ge(n.blockId),o=ge(n.title||""),a=ge(!1),r=ge(!0),l=ge(!1),c=ge(""),d=Vt,p=ge([]),u=ge(null);let f=null;Ui(()=>n.blockId,C=>{C&&C!==s.value&&(s.value=C,o.value=n.title||"",p.value=[],m(C))}),vn(()=>{s.value&&m(s.value)}),nr(()=>{y()});async function w(C){try{const L=await un(`SELECT id, root_id, type, content FROM blocks WHERE id = '${C}' LIMIT 1`);if(Array.isArray(L)&&L.length>0){const z=L[0];c.value=z.root_id||"";const N=z.id===z.root_id||z.type==="d";l.value=N,r.value=!N,!o.value&&z.content&&(o.value=z.content.trim().slice(0,30));return}}catch(L){console.warn("[ProtylePeekDrawer] detectBlockType query failed:",L)}l.value=!1,r.value=!0}async function m(C,L){if(!u.value||!C)return;y(),await w(C),typeof L=="boolean"&&(r.value=!l.value&&L);let z,N;r.value&&!l.value?(z=["cb-get-all","cb-get-hl","cb-get-focus"],N={background:!1,title:!1,gutter:!0,breadcrumbDocName:!0,scroll:!0}):(z=["cb-get-context","cb-get-hl"],N={background:!0,title:!0,gutter:!0,breadcrumbDocName:!0,scroll:!0});try{f=new ce.Protyle(n.plugin.app,u.value,{blockId:C,action:z,render:N}),!a.value&&f&&typeof f.disable=="function"&&f.disable()}catch(K){console.error("[ProtylePeekDrawer] Failed to instantiate Protyle:",K)}}function y(){if(f){try{typeof f.destroy=="function"&&f.destroy()}catch(C){console.warn("[ProtylePeekDrawer] Error destroying protyle:",C)}f=null}u.value&&(u.value.innerHTML="")}function b(){l.value||(r.value=!r.value,m(s.value,r.value))}function v(){a.value=!a.value,f&&(a.value?(typeof f.enable=="function"&&f.enable(),typeof f.focus=="function"&&f.focus()):typeof f.disable=="function"&&f.disable())}function k(){if(s.value)try{ce.openWindow({doc:{id:s.value},alwaysOnTop:!0})}catch(C){console.warn("[ProtylePeekDrawer] openWindow failed:",C)}}function S(){var z;if(!s.value)return;const C=Ys(),L=Ll(C.webServeUrl,s.value,{focus:!l.value});if(typeof window<"u"){const N=Tt("electron");(z=N==null?void 0:N.shell)!=null&&z.openExternal?N.shell.openExternal(L).catch(()=>{window.open(L,"_blank")}):window.open(L,"_blank")}i("external-jump",L)}function D(){if(p.value.length>0){const C=p.value.pop();C&&(s.value=C.blockId,o.value=C.title,r.value=C.isFocusMode,l.value=C.isDoc,m(C.blockId,C.isFocusMode))}}function A(C){const L=C.target;if(!L)return;const z=L.closest('[data-type="block-ref"]');if(z){const K=z.getAttribute("data-id");if(K&&K!==s.value){C.preventDefault(),C.stopPropagation(),p.value.push({blockId:s.value,title:o.value||s.value,isFocusMode:r.value,isDoc:l.value}),s.value=K,o.value=z.innerText.trim()||K,m(K);return}}const N=L.closest("a");if(N&&N.href&&N.href.startsWith("siyuan://blocks/")){C.preventDefault(),C.stopPropagation();const K=N.href.replace("siyuan://blocks/","").split("?")[0];K&&K!==s.value&&(p.value.push({blockId:s.value,title:o.value||s.value,isFocusMode:r.value,isDoc:l.value}),s.value=K,o.value=N.innerText.trim()||K,m(K))}}return(C,L)=>(J(),ee("div",nm,[h("div",sm,[h("div",om,[p.value.length>0?(J(),ee("button",{key:0,class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"返回上层引用文档或块",onClick:D},[re(de,{name:"arrow-left"}),L[0]||(L[0]=h("span",null,"返回",-1))])):Te("",!0),h("span",{class:Ce(["spm-protyle-badge",{"is-focus":r.value&&!l.value}])},we(r.value&&!l.value?"思源块聚焦":"思源文档速览"),3),h("span",{class:"spm-protyle-id",title:o.value||s.value},we(o.value||s.value),9,rm)]),h("div",am,[l.value?Te("",!0):(J(),ee("button",{key:0,class:Ce(["spm-icon-btn b3-tooltips b3-tooltips__s",{"is-primary":r.value}]),"aria-label":r.value?"当前为块聚焦模式（点击展开所属文档全文）":"当前为文档全文模式（点击切回仅聚焦当前块）",onClick:b},[re(de,{name:r.value?"focus":"file-text"},null,8,["name"]),h("span",null,we(r.value?"块聚焦":"展开全文"),1)],10,lm)),h("button",{class:Ce(["spm-icon-btn b3-tooltips b3-tooltips__s",{"is-primary":a.value}]),"aria-label":a.value?"当前为即时编辑模式（点击切回只读）":"当前为只读速览模式（点击解锁即时编辑）",onClick:v},[re(de,{name:a.value?"edit":"eye"},null,8,["name"]),h("span",null,we(a.value?"编辑中":"只读"),1)],10,cm),h("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"在置顶独立窗口中打开 (保留完整侧边栏与插件)",onClick:k},[re(de,{name:"window"}),L[1]||(L[1]=h("span",null,"独立窗口",-1))]),he(d).enableWebServeJump?(J(),ee("button",{key:1,class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"在系统默认浏览器中打开 (外跳)",onClick:S},[re(de,{name:"external-link"}),L[2]||(L[2]=h("span",null,"外跳",-1))])):Te("",!0)])]),h("div",{ref_key:"mountEl",ref:u,class:Ce(["spm-protyle-mount",{"is-focus-mode":r.value&&!l.value}]),onClick:A},null,2)]))}}),um=ii(dm,[["__scopeId","data-v-0d6e2df3"]]),fm=/^(https?|file|data|blob|mailto|tel|ftp|ftps|siyuan|about|chrome|ws|wss):/i,pm=/\.(html?|xhtml|pdf|png|jpe?g|gif|svg|webp|avif|ico|mp4|webm|mov|mp3|wav|m4a|ogg|json|md|markdown|txt|csv|zip|tar|gz|7z|rar|js|mjs|css|xml|yaml|yml|toml|ipynb|docx?|xlsx?|pptx?)$/i;function aa(e){let t=e||"";try{t=decodeURIComponent(t)}catch{}t=t.replace(/\\/g,"/");const i=/(?:^|\/)data\/assets\/(.+)$/i.exec(t);if(i)return`/assets/${i[1]}`;const n=/(?:^|\/)data\/plugins\/(.+)$/i.exec(t);return n?`/plugins/${n[1]}`:null}function Wl(e){const t=(e||"").replace(/^file:\/\//i,"");let i=t;try{i=decodeURIComponent(t)}catch{}if(i.startsWith("/"))return/^\/([a-zA-Z]:[\\/])/.exec(i)?i.slice(1):i;const n=i.indexOf("/");return n>=0?i.slice(n):i}function hm(e){const t=e.split(/[/?#]/)[0];return!t||pm.test(t)?!1:/^(localhost|\d{1,3}(\.\d{1,3}){3})(:\d+)?$/i.test(t)?!0:/^[a-z0-9-]+(\.[a-z0-9-]+)+(:\d+)?$/i.test(t)}function mm(e){const t=e.indexOf("#"),i=t>=0?e.slice(t):"",n=t>=0?e.slice(0,t):e,s=n.indexOf("?"),o=s>=0?n.slice(0,s):n,a=s>=0?n.slice(s+1):"";if(!/^\/?assets\/.+\.html?$/i.test(o))return e;const r=new URLSearchParams(a);return r.get("iframe")==="true"||r.get("download")==="true"?e:(r.set("iframe","true"),`${o}?${r.toString()}${i}`)}function Ul(e){const t=gm(e);return t.external||!t.url?t:{url:mm(t.url),external:!1}}function gm(e){const t=(e||"").trim();if(!t)return{url:"",external:!1};if(/^https?:\/\//i.test(t))return{url:t,external:!1};if(t.startsWith("//"))return{url:`https:${t}`,external:!1};if(/^(siyuan|data|blob|about):/i.test(t))return{url:t,external:!1};if(Ia(t))return{url:`/${Ma(t)}`,external:!1};if(/^file:/i.test(t)){const n=aa(Wl(t));return n?{url:n,external:!1}:{url:t,external:!0}}if(/^[a-zA-Z]:[\\/]/.test(t)||t.startsWith("\\\\")){const n=aa(t);return n?{url:n,external:!1}:{url:t,external:!0}}return fm.test(t)?{url:t,external:!0}:hm(t)?{url:`https://${t}`,external:!1}:{url:`/${t.replace(/^(?:\.{1,2}\/)+/,"").replace(/^\/+/,"")}`,external:!1}}const vm={class:"spm-webview-drawer"},bm={class:"spm-webview-toolbar"},ym={class:"spm-webview-toolbar__nav"},km=["disabled"],wm=["disabled"],xm=["aria-label"],Sm={class:"spm-webview-toolbar__address"},Cm=["aria-label"],_m={class:"spm-webview-toolbar__actions"},$m=["aria-label"],Im={class:"spm-zoom-controller"},Mm=["disabled"],Tm=["disabled"],Em={key:1,class:"spm-webview-fallback"},Am=["src"],Bm={key:2,class:"spm-load-error"},Dm={class:"spm-load-error__code"},Lm={class:"spm-load-error__code-num"},Pm={class:"spm-load-error__url"},Om={class:"spm-load-error__hint"},Rm={class:"spm-load-error__actions"},la="Mozilla/5.0 (iPhone; CPU iPhone OS 17_4_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.4.1 Mobile/15E148 Safari/604.1",Vl="siyuan-slides-peek-view-mode";let Gl="desktop";function Nm(){if(typeof window<"u"&&window.localStorage)try{const e=window.localStorage.getItem(Vl);if(e==="mobile"||e==="desktop")return e}catch{}return Gl}function zm(e){if(Gl=e,typeof window<"u"&&window.localStorage)try{window.localStorage.setItem(Vl,e)}catch{}}function Hm(e){switch((e||"").toUpperCase()){case"ERR_PROXY_CONNECTION_FAILED":return"无法连接到代理服务器：请在思源「设置 → 网络代理」中填写公司代理地址，或切换为「使用系统代理」。";case"ERR_TUNNEL_CONNECTION_FAILED":return"HTTPS 代理隧道建立失败：请将思源「网络代理」的类型设为 HTTPS 并确认地址正确。";case"ERR_MANDATORY_PROXY_CONFIGURATION_FAILED":return"强制代理配置获取失败：公司 PAC 脚本不可用，请在思源「网络代理」中改为手动填写代理地址。";case"ERR_NAME_NOT_RESOLVED":case"ERR_NAME_RESOLUTION_FAILED":return"域名解析失败：内网环境访问外网通常需要配置代理或 DNS。";case"ERR_INTERNET_DISCONNECTED":return"当前网络不可用：请检查网络连接。";case"ERR_CONNECTION_TIMED_OUT":case"ERR_TIMED_OUT":return"连接超时：该地址可能需要通过代理才能访问。";case"ERR_CONNECTION_REFUSED":return"连接被拒绝：目标服务未在监听，或思源本地内核尚未启动。";case"ERR_CERT_AUTHORITY_INVALID":case"ERR_CERT_COMMON_NAME_INVALID":case"ERR_CERT_DATE_INVALID":return"证书校验失败：若公司网络使用 TLS 拦截，需将根证书导入思源所用系统的证书库。";default:return"若处于公司内网，请优先检查思源「设置 → 网络代理」是否已配置为可用代理（支持「使用系统代理」）。"}}const Fm=Dt({__name:"WebviewPeekDrawer",props:{url:{},title:{},visible:{type:Boolean,default:!0}},emits:["external-jump"],setup(e,{emit:t}){const i=t,n=e,s=ge(Hl()&&!mp()),o=ge(n.url),a=ge(n.url),r=n.url,l=ge(!1),c=ge(null),d=ge(!1),p=ge(!1),u=ge(1),f=ge(!1),w=ge(Nm());let m=typeof navigator<"u"&&!navigator.userAgent.includes("iPhone")?navigator.userAgent:"";const y=ye(()=>w.value==="mobile"?la:m||void 0),b=ge(null),v=ge(null);let k=null,S=null,D=null;Ui(()=>n.url,X=>{X&&X!==o.value&&(o.value=X,a.value=X,w.value==="mobile"&&N(!1),b.value&&typeof b.value.loadURL=="function"&&b.value.loadURL(X))}),Ui(()=>n.visible,X=>{if(X)le(),w.value==="mobile"&&N(!1);else if(b.value)try{typeof b.value.stop=="function"&&b.value.stop()}catch{}}),vn(()=>{A(),v.value&&typeof ResizeObserver<"u"&&(k=new ResizeObserver(()=>{const X=b.value;if(X&&typeof X.invalidate=="function")try{X.invalidate()}catch{}}),k.observe(v.value)),S=X=>{var E;const pe=X.message||((E=X.error)==null?void 0:E.message);if(typeof pe=="string"&&pe.includes("Invalid guestInstanceId"))return X.preventDefault(),X.stopImmediatePropagation(),!0},window.addEventListener("error",S,!0),D=X=>{const pe=X.reason,E=typeof pe=="string"?pe:pe==null?void 0:pe.message;typeof E=="string"&&E.includes("Invalid guestInstanceId")&&X.preventDefault()},window.addEventListener("unhandledrejection",D)}),nr(()=>{if(C(),k&&(k.disconnect(),k=null),S&&(window.removeEventListener("error",S,!0),S=null),D&&(window.removeEventListener("unhandledrejection",D),D=null),b.value)try{typeof b.value.stop=="function"&&b.value.stop()}catch{}});function A(){const X=b.value;X&&(X.addEventListener("dom-ready",L),X.addEventListener("did-start-loading",K),X.addEventListener("did-stop-loading",x),X.addEventListener("did-navigate",q),X.addEventListener("did-navigate-in-page",O),X.addEventListener("new-window",$),X.addEventListener("did-fail-load",_),X.addEventListener("did-fail-provisional-load",_))}function C(){const X=b.value;if(X)try{X.removeEventListener("dom-ready",L),X.removeEventListener("did-start-loading",K),X.removeEventListener("did-stop-loading",x),X.removeEventListener("did-navigate",q),X.removeEventListener("did-navigate-in-page",O),X.removeEventListener("new-window",$),X.removeEventListener("did-fail-load",_),X.removeEventListener("did-fail-provisional-load",_)}catch{}}function L(){const X=b.value;if(X&&typeof X.getUserAgent=="function"&&!m)try{const pe=X.getUserAgent();pe&&!pe.includes("iPhone")&&(m=pe)}catch{}w.value==="mobile"&&N(!1),le(),T()}function z(){const X=w.value==="mobile"?"desktop":"mobile";w.value=X,zm(X),N(!0)}function N(X=!1){const pe=b.value;if(!pe)return;const E=w.value==="mobile"?la:m;if(typeof pe.setUserAgent=="function"&&E)try{pe.setUserAgent(E)}catch(F){console.warn("[WebviewPeekDrawer] setUserAgent error:",F)}if(X&&typeof pe.reload=="function")try{pe.reload()}catch(F){console.warn("[WebviewPeekDrawer] reload error:",F)}}function K(){l.value=!0,c.value=null}function _(X){if(X&&X.isMainFrame===!1||X&&Number(X.errorCode)===-3)return;const pe=String((X==null?void 0:X.errorDescription)||"ERR_FAILED");c.value={errorCode:Number((X==null?void 0:X.errorCode)??0),description:pe,validatedURL:String((X==null?void 0:X.validatedURL)||o.value),hint:Hm(pe)},l.value=!1}function U(){c.value=null,V()}function x(){if(l.value=!1,T(),b.value&&typeof b.value.getURL=="function"){const X=b.value.getURL();X&&X!=="about:blank"&&(o.value=X,a.value=X)}}function q(X){X!=null&&X.url&&(o.value=X.url,a.value=X.url),T()}function O(X){X!=null&&X.url&&(o.value=X.url,a.value=X.url),T()}function $(X){X&&X.url&&(X.preventDefault(),b.value&&typeof b.value.loadURL=="function"&&b.value.loadURL(X.url))}function T(){const X=b.value;X&&(typeof X.canGoBack=="function"&&(d.value=X.canGoBack()),typeof X.canGoForward=="function"&&(p.value=X.canGoForward()))}function P(){b.value&&typeof b.value.goBack=="function"&&b.value.goBack()}function se(){b.value&&typeof b.value.goForward=="function"&&b.value.goForward()}function V(){b.value&&typeof b.value.reload=="function"&&b.value.reload()}function Y(){const X=Ul(a.value);if(X.url){if(X.external){o.value=X.url,fe();return}o.value=X.url,a.value=X.url,b.value&&typeof b.value.loadURL=="function"&&b.value.loadURL(X.url)}}function le(){const X=b.value;if(X&&typeof X.setZoomFactor=="function")try{X.setZoomFactor(u.value)}catch(pe){console.warn("[WebviewPeekDrawer] setZoomFactor error:",pe)}}function ie(){u.value=Math.min(2.5,Math.round((u.value+.1)*10)/10),le()}function oe(){u.value=Math.max(.5,Math.round((u.value-.1)*10)/10),le()}function Se(){u.value=1,le()}function Ie(X){X.preventDefault(),X.deltaY<0?ie():X.deltaY>0&&oe()}async function _e(){if(typeof navigator<"u"&&navigator.clipboard)try{await navigator.clipboard.writeText(o.value),f.value=!0,setTimeout(()=>{f.value=!1},2e3)}catch(X){console.warn("Copy url failed:",X)}}function fe(){var pe;const X=o.value;if(typeof window<"u"){const E=Tt("electron");(pe=E==null?void 0:E.shell)!=null&&pe.openExternal?E.shell.openExternal(X).catch(()=>{window.open(X,"_blank")}):window.open(X,"_blank")}i("external-jump",X)}return(X,pe)=>{const E=Cu("webview");return J(),ee("div",vm,[h("div",bm,[h("div",ym,[h("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s",disabled:!d.value,"aria-label":"后退",onClick:P},[re(de,{name:"arrow-left"})],8,km),h("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s",disabled:!p.value,"aria-label":"前进",onClick:se},[re(de,{name:"arrow-right"})],8,wm),h("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":l.value?"正在加载...":"刷新页面",onClick:V},[re(de,{name:"refresh"})],8,xm)]),h("div",Sm,[Ot(h("input",{"onUpdate:modelValue":pe[0]||(pe[0]=F=>a.value=F),type:"text",class:"b3-text-field spm-url-input",placeholder:"https://...",spellcheck:"false",onKeydown:Hf(Y,["enter"])},null,544),[[Po,a.value]]),h("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":f.value?"已复制地址！":"复制网址",onClick:_e},[re(de,{name:"copy"})],8,Cm)]),h("div",_m,[h("button",{class:Ce(["spm-icon-btn spm-mode-toggle b3-tooltips b3-tooltips__s",{"is-active":w.value==="mobile"}]),"aria-label":w.value==="mobile"?"当前为手机视图，点击切换为桌面视图":"当前为桌面视图，点击切换为手机视图",onClick:z},[re(de,{name:w.value==="mobile"?"mobile":"desktop"},null,8,["name"])],10,$m),h("div",Im,[h("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"缩小 (Ctrl + -)",disabled:u.value<=.5,onClick:oe},[re(de,{name:"minus"})],8,Mm),h("button",{class:"spm-zoom-badge b3-tooltips b3-tooltips__s","aria-label":"重置 100% (Ctrl + 0)",onClick:Se},we(Math.round(u.value*100))+"% ",1),h("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"放大 (Ctrl + +)",disabled:u.value>=2.5,onClick:ie},[re(de,{name:"plus"})],8,Tm)]),h("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"在系统默认浏览器中打开 ↗",onClick:fe},[re(de,{name:"external-link"}),pe[1]||(pe[1]=h("span",null,"外跳",-1))])])]),h("div",{ref_key:"containerEl",ref:v,class:Ce(["spm-webview-body",{"is-mobile":w.value==="mobile"}]),onWheel:Zt(Ie,["ctrl"])},[h("div",{class:Ce(["spm-webview-viewport",{"is-mobile":w.value==="mobile"}])},[s.value?(J(),Jt(E,{key:0,ref_key:"webviewRef",ref:b,class:"spm-webview-frame",src:he(r),useragent:y.value,allowpopups:"true",style:{position:"absolute",top:"0",left:"0",width:"100%",height:"100%",display:"inline-flex"}},null,8,["src","useragent"])):(J(),ee("div",Em,[h("iframe",{class:"spm-webview-fallback-frame",src:o.value,frameborder:"0",sandbox:"allow-scripts allow-same-origin allow-forms allow-popups"},null,8,Am),h("div",{class:"spm-fallback-bar"},[pe[2]||(pe[2]=h("span",null,"如页面受同源策略 (X-Frame-Options) 拦截无法显示，请",-1)),h("button",{class:"spm-icon-btn is-primary",onClick:fe}," 在新标签页中打开 ↗ ")])])),c.value?(J(),ee("div",Bm,[re(de,{name:"alert",class:"spm-load-error__icon"}),pe[5]||(pe[5]=h("div",{class:"spm-load-error__title"},"页面加载失败",-1)),h("div",Dm,[$t(we(c.value.description)+" ",1),h("span",Lm,"("+we(c.value.errorCode)+")",1)]),h("div",Pm,we(c.value.validatedURL),1),h("p",Om,we(c.value.hint),1),h("div",Rm,[h("button",{class:"spm-icon-btn","aria-label":"重试",onClick:U},[re(de,{name:"refresh"}),pe[3]||(pe[3]=h("span",null,"重试",-1))]),h("button",{class:"spm-icon-btn is-primary","aria-label":"用系统浏览器打开",onClick:fe},[re(de,{name:"external-link"}),pe[4]||(pe[4]=h("span",null,"用系统浏览器打开 ↗",-1))])])])):Te("",!0)],2)],34)])}}}),jm=ii(Fm,[["__scopeId","data-v-6e363f73"]]);class Wm{constructor(){be(this,"timers",new Map)}debounce(t,i,n=150){this.cancel(t);const s=setTimeout(()=>{this.timers.delete(t),i()},n);this.timers.set(t,s)}cancel(t){this.timers.has(t)&&(clearTimeout(this.timers.get(t)),this.timers.delete(t))}cancelAll(){for(const t of this.timers.values())clearTimeout(t);this.timers.clear()}hasPending(t){return this.timers.has(t)}}class Um{constructor(t){be(this,"blockToPageMap",new Map);be(this,"debounceCtrl",new Wm);be(this,"activeBlockId","");be(this,"activePageIndex",1);be(this,"currentDocId","");be(this,"bridge",null);t&&(this.bridge=t)}setBridge(t){this.bridge=t}setDocId(t){this.currentDocId=t}updateSlidesIndex(t){this.blockToPageMap.clear();for(const i of t){i.startBlockId&&this.blockToPageMap.set(i.startBlockId,i.pageIndex);for(const n of i.blocks)this.blockToPageMap.set(n.id,i.pageIndex)}}getPageByBlockId(t){return this.blockToPageMap.get(t)??null}onCursorFocusBlock(t){if(!t||t===this.activeBlockId)return;this.activeBlockId=t;let i=this.getPageByBlockId(t);!i&&(t===this.currentDocId||!this.currentDocId&&this.blockToPageMap.size>0)&&(i=1),i&&this.debounceCtrl.debounce("cursor-navigate",()=>{this.activePageIndex=i,this.bridge&&(this.bridge.navigatePage(i),this.bridge.highlightElement(t))},100)}getActiveBlockId(){return this.activeBlockId}setActiveBlockId(t){this.activeBlockId=t,t||this.debounceCtrl.cancel("cursor-navigate");const i=this.getPageByBlockId(t);i&&(this.activePageIndex=i)}getActivePageIndex(){return this.activePageIndex}destroy(){this.debounceCtrl.cancelAll(),this.blockToPageMap.clear(),this.bridge=null}}let At=null,hs=null,ms="";function Rn(){var e,t;if(hs&&(clearTimeout(hs),hs=null),At){try{At.classList.remove("protyle-wysiwyg--select"),ms?At.style.outline=ms:typeof((e=At.style)==null?void 0:e.removeProperty)=="function"?At.style.removeProperty("outline"):At.style&&(At.style.outline=""),typeof((t=At.style)==null?void 0:t.removeProperty)=="function"?At.style.removeProperty("transition"):At.style&&(At.style.transition="")}catch(i){console.warn("[SelectionMirror] clear activeHighlightEl failed:",i)}At=null,ms=""}if(typeof document<"u"&&typeof document.querySelectorAll=="function")try{document.querySelectorAll(".protyle-wysiwyg [data-node-id].protyle-wysiwyg--select, .protyle-wysiwyg [data-node-id][style*='outline']").forEach(n=>{var o,a;n.classList.remove("protyle-wysiwyg--select");const s=((o=n.style)==null?void 0:o.outline)||"";(s.includes("#3b82f6")||s.includes("rgb(59, 130, 246)")||s.includes("59, 130, 246"))&&(typeof((a=n.style)==null?void 0:a.removeProperty)=="function"?(n.style.removeProperty("outline"),n.style.removeProperty("transition")):n.style&&(n.style.outline="",n.style.transition=""))})}catch{}}function Vi(e,t){var a,r,l,c;if(!e||typeof document>"u")return Rn(),!1;Rn();const i=(a=globalThis.CSS)!=null&&a.escape?globalThis.CSS.escape(e):e.replace(/"/g,'\\"'),n=document.querySelector(`.protyle-wysiwyg [data-node-id="${i}"]`)||document.querySelector(`[data-node-id="${i}"]`);if(!n){if(t)try{return ce.openTab({app:t,doc:{id:e,action:["cb-get-hl","cb-get-focus","cb-get-context"]}}),!0}catch(d){console.warn("[SelectionMirror] openTab fallback failed:",d)}return!1}try{n.scrollIntoView({behavior:"smooth",block:"center",inline:"nearest"})}catch{(r=n.scrollIntoView)==null||r.call(n)}try{(l=n.focus)==null||l.call(n,{preventScroll:!0})}catch{}const s=((c=n.style)==null?void 0:c.outline)||"";return ms=s.includes("#3b82f6")||s.includes("rgb(59, 130, 246)")||s.includes("59, 130, 246")?"":s,n.classList.add("protyle-wysiwyg--select"),n.style&&(n.style.outline="2px solid #3b82f6",n.style.transition="outline 0.2s ease"),At=n,hs=setTimeout(()=>{Rn()},500),!0}function Vm(e){if(!e)return"";const t=e.split(`
`).map(a=>a.trim()).filter(Boolean);if(t.length===0)return"";if(!t.some(a=>/^#{1,6}\s+/.test(a)))return t.map(a=>rt(a)).join("<br/>");const n=[];let s=[];const o=()=>{if(s.length>0){const a=s.map(r=>rt(r)).join("<br/>");n.push(`<p class="slide-list-item-desc">${a}</p>`),s=[]}};for(const a of t){const r=a.match(/^(#{1,6})\s+(.*)$/);if(r){o();const l=r[1].length,c=r[2].trim();n.push(`<h${l} class="slide-list-item-title">${rt(c)}</h${l}>`)}else s.push(a)}return o(),n.join(`
`)}function Gm(e){if(e.length===0)return"";const t=[],i=e[0],n=i.match(/^(#{1,6})\s+(.*)$/);if(n){const s=n[1].length,o=n[2].trim();t.push(`<h${s} class="slide-list-item-title">${rt(o)}</h${s}>`)}else t.push(`<p class="slide-list-item-title">${rt(i)}</p>`);if(e.length>1){const s=e.slice(1);let o=[];const a=()=>{if(o.length>0){const r=o.map(l=>rt(l)).join("<br/>");t.push(`<p class="slide-list-item-desc">${r}</p>`),o=[]}};for(const r of s){const l=r.match(/^(#{1,6})\s+(.*)$/);if(l){a();const c=l[1].length,d=l[2].trim();t.push(`<h${c} class="slide-list-item-title">${rt(d)}</h${c}>`)}else o.push(r)}a()}return t.join(`
`)+(t.length>0?`
`:"")}function Kl(e,t,i){var u,f,w,m;const n=e.split(`
`);if(!n.some(y=>/^(\s*)([-*+]|\d+\.)\s+/.test(y)))return(i!=null&&i.isListItem||(i==null?void 0:i.type)==="i")&&!(i!=null&&i.isColFirst)?`<ul class="slide-list slide-list--unordered">
<li class="slide-list-item">${rt(e)}</li>
</ul>`:null;const o=[],a=[];let r=!1;for(let y=0;y<n.length;y++){const b=n[y];if(!b.trim())continue;const v=b.match(/^(\s*)[-*+]\s+\[([ xX])\]\s+(.*)$/);if(v){const A=v[1].length,C=Math.floor(A/2);a.push({type:"task",level:C,checked:v[2].toLowerCase()==="x",text:v[3],media:[]});continue}const k=b.match(/^(\s*)[-*+]\s+(.*)$/);if(k){const A=k[1].length,C=Math.floor(A/2);a.push({type:"unordered",level:C,text:k[2],media:[]});continue}const S=b.match(/^(\s*)\d+\.\s+(.*)$/);if(S){a.length===0&&(r=!0);const A=S[1].length,C=Math.floor(A/2);a.push({type:"ordered",level:C,text:S[2],media:[]});continue}const D=b.trim();if(!(!D||/^\{:.*?\}$/.test(D)))if(a.length>0){const A=D.match(/^!\[(.*?)\]\((.*?)\)(?:\{:?[^}]*\})?$/);if(A){const z=/\.gif(?:\?|$)/i.test(A[2])?"list-item-gif":"list-item-img";a[a.length-1].media||(a[a.length-1].media=[]),a[a.length-1].media.push(`<div class="slide-list-media"><img alt="${ot(A[1])}" src="${A[2]}" class="${z}" /></div>`);continue}if(D.match(/^<img\b[\s\S]*?\/?>$/i)){const L=D.replace(/\s+style="[^"]*"/gi,"");a[a.length-1].media||(a[a.length-1].media=[]),a[a.length-1].media.push(`<div class="slide-list-media">${L}</div>`);continue}if(/<video\b/i.test(D)){let L=D;if(!/<\/video>/i.test(L))for(;y+1<n.length&&!/<\/video>/i.test(L);)y++,L+=" "+n[y].trim();const z=((u=i==null?void 0:i.attributes)==null?void 0:u["custom-slides-autoplay"])==="true"||/autoplay/i.test(L),N=((f=i==null?void 0:i.attributes)==null?void 0:f["custom-slides-loop"])==="true"||/loop/i.test(L),K=((w=i==null?void 0:i.attributes)==null?void 0:w["custom-slides-muted"])==="true"||z||/muted/i.test(L),_=((m=i==null?void 0:i.attributes)==null?void 0:m["custom-slides-controls"])==="false",U=L.match(/\bsrc=["']([^"']+)["']/i),x=U?U[1]:"",q=['class="slide-video-player"'];_||q.push("controls"),z&&(q.push("autoplay"),q.push("playsinline")),N&&q.push("loop"),K&&q.push("muted"),q.push('preload="metadata"'),x&&q.push(`src="${x}"`);const O=L.match(/<video[^>]*>([\s\S]*?)<\/video>/i);let $=O?O[1].trim():"";!$&&x&&($=`<source src="${x}" type="video/mp4" />您的浏览器不支持视频播放。`),a[a.length-1].media||(a[a.length-1].media=[]),a[a.length-1].media.push(`<div class="slide-list-media slide-video-container slide-media-container" data-autoplay="${z?"true":"false"}" data-muted="${K?"true":"false"}"><video ${q.join(" ")}>${$}</video></div>`);continue}a[a.length-1].text+=`
`+D}else o.push(D)}if(a.length===0)return null;const l=r?"ol":"ul",c=(t==null?void 0:t.listClassName)||(r?"pdf-list pdf-list--ordered":"pdf-list pdf-list--unordered"),d=a.map(y=>{const b=Vm(y.text),v=y.media&&y.media.length>0?`
${y.media.join(`
`)}`:"",k=y.level||0,S=k>0?` style="margin-left:${(k*1.25).toFixed(2)}em;${y.type==="unordered"?`list-style-type:${k%2===1?"circle":"square"} !important;`:""}"`:"",D=k>0?" slide-list-item--nested":"";if(y.type==="task"){const C=y.checked?' checked=""':"";return`<li class="pdf-task-item${D}"${S}><label><input type="checkbox" disabled=""${C}/> <span>${b}</span></label>${v}</li>`}return`<li${D?` class="${D.trim()}"`:""}${S}>${b}${v}</li>`}).join(`
`);return`${Gm(o)}<${l} class="${c}">
${d}
</${l}>`}function Km(e,t,i){const n=(t==null?void 0:t.containerClassName)||"pdf-block",s=e.split(/\r?\n/),o=[];let a=[];for(let c=0;c<s.length;c++){const d=s[c],p=d.trim();if(/^#{1,6}\s+/.test(p)){a.length>0&&(o.push(a.join(`
`)),a=[]),o.push(p);continue}if(!p){a.length>0&&(o.push(a.join(`
`)),a=[]);continue}if(/^!\[.*?\]\(.*?\)$/.test(p)){a.length>0&&(o.push(a.join(`
`)),a=[]),o.push(p);continue}if(/<video\b/i.test(p)){a.length>0&&(o.push(a.join(`
`)),a=[]);let u=p;if(!/<\/video>/i.test(u))for(;c+1<s.length&&!/<\/video>/i.test(u);)c++,u+=`
`+s[c];o.push(u);continue}a.push(d)}a.length>0&&o.push(a.join(`
`));let r=!0;return o.map(c=>{var w,m,y,b;const d=c.trim();if(!d)return"";const p=d.match(/^(#{1,6})\s+(.*)$/);if(p){r=!1;const v=p[1].length;return`<h${v} class="slide-list-item-title">${rt(p[2].trim())}</h${v}>`}const u=d.match(/^!\[(.*?)\]\((.*?)\)$/);if(u){const v=/\.gif(?:\?|$)/i.test(u[2]),k=(t==null?void 0:t.imageClassName)||(v?"list-item-gif":"pdf-image slide-media-img");return`<div class="${n} ${n}--image slide-media-block slide-media-container slide-list-media"><img alt="${ot(u[1])}" src="${u[2]}" class="${k}" /></div>`}if(/<video\b/i.test(d)){const v=((w=i==null?void 0:i.attributes)==null?void 0:w["custom-slides-autoplay"])==="true"||/autoplay/i.test(d),k=((m=i==null?void 0:i.attributes)==null?void 0:m["custom-slides-loop"])==="true"||/loop/i.test(d),S=((y=i==null?void 0:i.attributes)==null?void 0:y["custom-slides-muted"])==="true"||v||/muted/i.test(d),D=((b=i==null?void 0:i.attributes)==null?void 0:b["custom-slides-controls"])==="false",A=d.match(/\bsrc=["']([^"']+)["']/i),C=A?A[1]:"",L=['class="slide-video-player"'];D||L.push("controls"),v&&L.push("autoplay playsinline"),k&&L.push("loop"),S&&L.push("muted"),L.push('preload="metadata"'),C&&L.push(`src="${C}"`);const z=d.match(/<video[^>]*>([\s\S]*?)<\/video>/i);let N=z?z[1].trim():"";return!N&&C&&(N=`<source src="${C}" type="video/mp4" />您的浏览器不支持视频播放。`),`<div class="${n} ${n}--video slide-media-block slide-video-container slide-media-container" data-autoplay="${v?"true":"false"}" data-muted="${S?"true":"false"}"><video ${L.join(" ")}>${N}</video></div>`}const f=Kl(d,t,i);if(f)return r=!1,f;if(r){r=!1;const v=d.split(/\r?\n/).map(A=>A.trim()).filter(Boolean);if(v.length===1)return`<p class="slide-list-item-title">${rt(v[0])}</p>`;const k=v[0],D=v.slice(1).map(A=>rt(A)).join("<br/>");return`<p class="slide-list-item-title">${rt(k)}</p>
<p class="slide-list-item-desc">${D}</p>`}return`<p class="slide-list-item-desc">${rt(d)}</p>`}).filter(Boolean).join(`
`)}function po(e){if(!e)return!1;if(e.type==="h"||e.type==="NodeHeading")return!0;const t=(e.rawMarkdown||e.content||"").trim();return/^#{1,6}\s+/.test(t)}function ql(e,t){var r,l,c,d,p,u,f,w;const i=((r=e.frontmatter)==null?void 0:r.layout)||"default",s=(e.blocks||[]).filter(m=>m.slot!=="slot-divider-right"),a=i==="cover"?null:s.find(po);if(i==="two-cols"){const m=s.some(K=>K.slot==="right");let y=[],b=[];if(m)y=s.filter(K=>K.slot!=="right"),b=s.filter(K=>K.slot==="right");else{const K=Math.ceil(s.length/2);y=s.slice(0,K),b=s.slice(K)}const v=K=>{const _=K.filter(U=>!!(U.rawMarkdown||U.content||"").trim());if(_.length>0){const U=_[0],x=(U.rawMarkdown||U.content||"").trim();(Ti(U)||/^(?:[-*+]|\d+\.)\s+/.test(x))&&(U.rawMarkdown=Ln(U.rawMarkdown||U.content||""),U.content=U.rawMarkdown)}};v(y),v(b);const k=y.map(K=>ki(K,t)).join(`
`),S=b.map(K=>ki(K,t)).join(`
`),D=(t==null?void 0:t.twoColsWrapperClass)||"pdf-two-cols-wrapper layout-two-cols-grid",A=(l=e.frontmatter)!=null&&l.layoutClass?` ${e.frontmatter.layoutClass}`:"",C=(t==null?void 0:t.leftColClass)||"pdf-col pdf-col--left",L=(t==null?void 0:t.rightColClass)||"pdf-col pdf-col--right",N=`style="grid-template-columns: ${uo((c=e.frontmatter)==null?void 0:c.layoutRatio,2)};"`;return`
      <div class="${D}${A}" ${N}>
        <div class="${C}">${k}</div>
        <div class="${L}">${S}</div>
      </div>
    `}if(i==="clover"||on(i)){const m=i==="clover";let y=[];const b=s.filter(q=>q.slot==="header");if(b.length>0)y=b;else if(s.length>0){const q=s.find(O=>O.type==="h"&&(!O.slot||O.slot==="default"));q&&(y=[q])}const v=s.filter(q=>!y.includes(q));let k=2;if(m)k=4;else if(i==="three-cols-header")k=3;else if(i==="two-cols-header")k=2;else{let q=0;for(const O of v){const $=(O.slot||"").match(/^col-(\d+)$/i);$&&(q=Math.max(q,parseInt($[1],10)))}if(q>=2)k=q;else if((d=e.frontmatter)!=null&&d.layoutRatio){const O=e.frontmatter.layoutRatio.trim();if(O.includes(":")){const $=O.split(":").map(T=>parseFloat(T.trim())).filter(T=>!isNaN(T)&&T>0);$.length>=2&&(k=$.length)}else{const $=O.split(/\s+/).filter(Boolean);$.length>=2&&(k=$.length)}}else v.length===1&&v[0].children&&v[0].children.length>=2&&(k=Math.min(6,v[0].children.length))}const S=zl(v,k),D=v.some(q=>q.slot&&/^(?:col-\d+|left|right)$/i.test(q.slot)),A=i==="clover"||i==="two-cols-header"||i==="three-cols-header"||on(i)&&D,C=q=>{const O=q.filter(T=>!!(T.rawMarkdown||T.content||"").trim());if(A&&O.length>0){const T=O[0],P=(T.rawMarkdown||T.content||"").trim();(Ti(T)||/^(?:[-*+]|\d+\.)\s+/.test(P))&&(T.rawMarkdown=Ln(T.rawMarkdown||T.content||""),T.content=T.rawMarkdown),T.isColFirst=!0}const $=A?O.find(po):null;return O.map(T=>ki(T,{...t,extraClassName:T===$?"slides-col-first-heading-block":""})).join(`
`)},L=y.find(po),z=y.map(q=>ki(q,{...t,extraClassName:q===L?"slides-page-first-heading-block":""})).join(`
`),N=m?"repeat(2, minmax(0, 1fr))":uo((p=e.frontmatter)==null?void 0:p.layoutRatio,k),K=m?`style="grid-template-columns: ${N}; grid-template-rows: repeat(2, minmax(0, 1fr));"`:`style="grid-template-columns: ${N};"`,_=[m?"layout-clover-container":"layout-cols-header-container",k===2?"layout-two-cols-header-container":"",k===3?"layout-three-cols-header-container":"",`layout-${i}-container`,A?"has-superblock-cols":""].filter(Boolean).join(" "),U=[m?"layout-clover-grid pdf-clover-wrapper":"layout-cols-wrapper layout-cols-grid",k===2?"pdf-two-cols-wrapper layout-two-cols-grid":"",k===3?"pdf-three-cols-wrapper layout-three-cols-grid":"",A?"has-superblock-cols":""].filter(Boolean).join(" "),x=S.map((q,O)=>{const $=O+1;return`<div class="${["pdf-col",k===2&&$===1?"pdf-col--left":"",k===2&&$===2?"pdf-col--right":"",`pdf-col--${$}`,`col-${$}`].filter(Boolean).join(" ")}">${C(q)}</div>`}).join(`
`);return`
      <div class="${_}">
        <div class="layout-header-section">${z}</div>
        <div class="${U}" ${K}>
          ${x}
        </div>
      </div>
    `}if(i==="image-right"||i==="image-left"){const m=i==="image-right",y=s.map(A=>ki(A,t)).join(`
`),b=((u=e.frontmatter)==null?void 0:u.image)||((f=e.frontmatter)==null?void 0:f.background)||"",v=`<div class="pdf-image-col" style="background-image:url('${ot(b)}');background-size:cover;background-position:center;background-repeat:no-repeat;width:100%;height:100%;position:relative;overflow:hidden;"><img src="${ot(b)}" style="width:100%;height:100%;object-fit:cover;object-position:center;display:block;" onerror="this.style.display='none'" alt="Slide cover" /></div>`,k=`<div class="pdf-content-col" style="padding:48px 56px;display:flex;flex-direction:column;justify-content:flex-start;height:100%;box-sizing:border-box;overflow-y:auto;">${y}</div>`,S=m?`${k}
${v}`:`${v}
${k}`;return`
      <div class="layout-image-cols-grid" style="display:grid;grid-template-columns:${uo((w=e.frontmatter)==null?void 0:w.layoutRatio,2)};grid-template-rows:100%;width:100%;height:100%;position:absolute;top:0;left:0;right:0;bottom:0;box-sizing:border-box;">
        ${S}
      </div>
    `}return i==="fact"?`<div class="layout-fact-container">${s.map(y=>ki(y,t)).join(`
`)}</div>`:i==="cover"?`<div class="layout-cover-container">${s.map(y=>ki(y,t)).join(`
`)}</div>`:s.map(m=>ki(m,{...t,extraClassName:m===a?"slides-page-first-heading-block":""})).join(`
`)}function ot(e){return e?e.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&#039;"):""}function qm(e){if(!e||e.trim()===""||e.trim()==="all")return"all";const t=new Set,i=e.split("|");for(const n of i){const s=n.trim();if(s==="all")return"all";if(s.includes("-")){const[o,a]=s.split("-"),r=parseInt(o,10),l=parseInt(a,10);if(!isNaN(r)&&!isNaN(l))for(let c=Math.min(r,l);c<=Math.max(r,l);c++)t.add(c)}else{const o=parseInt(s,10);isNaN(o)||t.add(o)}}return t}const Ym=new Set(["kbd","mark","sub","sup","span","a","br","b","i","u","s","del","em","strong","code","small","abbr","ruby","rt","rp","v-mark","img","video","source","picture"]);function rt(e){if(!e)return"";const t=Rl(e),i=[],n=t.replace(/<\/?([a-zA-Z0-9_-]+)(?:\s+[^<>]*)?\/?>/g,(o,a)=>{const r=a.toLowerCase();if(!Ym.has(r)||/on\w+\s*=|javascript:/i.test(o))return o;if(r==="v-mark"){const l=o.match(/type=["']?([a-zA-Z-]+)["']?/),c=l?l[1]:"circle";return o.startsWith("</")?i.push("</mark>"):i.push(`<mark class="v-mark v-mark--${c}">`),`%%SAFE_HTML_${i.length-1}%%`}return i.push(o),`%%SAFE_HTML_${i.length-1}%%`});let s=ot(n);return s=s.replace(/\(\(([0-9a-zA-Z-]+)(?:\s*(?:&#039;([^&#]*)&#039;|&quot;([^&]*)&quot;|'([^']*)'|"([^"]*)"|([^\)]+?)))?\s*\)\)/g,(o,a,r,l,c,d,p)=>{const f=(r??l??c??d??p??"").trim()||`Ref(${a.slice(0,8)})`;return`<a href="siyuan://blocks/${a}" data-ref-id="${a}" class="slides-ref-tag">🔗 ${f}</a>`}),s=s.replace(/\$([^$\n]+)\$/g,'<span class="katex-inline font-math"><em>$1</em></span>'),s=s.replace(/!\[(.*?)\]\((.*?)\)/g,(o,a,r)=>{const c=/\.gif(?:\?|$)/i.test(r)?"slide-inline-img list-item-gif":"slide-inline-img";return`<img alt="${a}" src="${r}" class="${c}" />`}),s=s.replace(/\[(.*?)\]\((.*?)\)/g,(o,a,r)=>{if(r.startsWith("siyuan://blocks/")){const l=r.replace("siyuan://blocks/","").split("?")[0];return`<a href="${r}" data-ref-id="${l}" class="slides-ref-tag">🔗 ${a}</a>`}return`<a href="${r}" target="_blank" rel="noopener noreferrer" class="slides-link">${a}</a>`}),s=s.replace(/(^|[\s(])(siyuan:\/\/blocks\/([0-9a-zA-Z-]+)(?:\?[^\s\)]*)?)/g,(o,a,r,l)=>`${a}<a href="${r}" data-ref-id="${l}" class="slides-ref-tag">🔗 ${r}</a>`),s=s.replace(/\*\*(.*?)\*\*/g,"<strong>$1</strong>"),s=s.replace(/\*(.*?)\*/g,"<em>$1</em>"),s=s.replace(/~~(.*?)~~/g,"<del>$1</del>"),s=s.replace(/`([^`]+)`/g,"<code>$1</code>"),s=s.replace(/%%SAFE_HTML_(\d+)%%/g,(o,a)=>{const r=parseInt(a,10);return i[r]||""}),s}function Zm(e,t="pdf-table"){if(e.length<2)return"";const i=e.map(l=>l.trim().replace(/^\|/,"").replace(/\|$/,"").split("|").map(c=>c.trim())),n=i[0];let s=[],o=1;e.length>=2&&i[1].every(l=>/^:?-+:?$/.test(l))&&(s=i[1].map(l=>l.startsWith(":")&&l.endsWith(":")?"center":l.endsWith(":")?"right":"left"),o=2);const a=`<thead><tr>${n.map((l,c)=>`<th${s[c]?` style="text-align: ${s[c]}"`:""}>${rt(l)}</th>`).join("")}</tr></thead>`,r=i.slice(o).map(l=>`<tr>${l.map((c,d)=>`<td${s[d]?` style="text-align: ${s[d]}"`:""}>${rt(c)}</td>`).join("")}</tr>`).join("");return`<table class="${t}">${a}<tbody>${r}</tbody></table>`}function ho(e){return String(e||"").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;")}function ca(e,t="ts"){if(!e)return"";if(e.trim().startsWith("//"))return`<span class="token-comment">${ho(e)}</span>`;const i=[];function n(o,a){return i.push(`<span class="${o}">${ho(a)}</span>`),`__TOK_${i.length-1}__`}let s=e.replace(/(['"`])(.*?)\1/g,(o,a,r)=>n("token-string",`${a}${r}${a}`));return s=s.replace(/\b(import|export|from|const|let|var|function|return|default|type|interface|class|new|async|await)\b/g,o=>n("token-keyword",o)),s=s.replace(/\b(computed|ref|number|string|boolean|void|Array)\b/g,o=>n("token-type",o)),s=s.replace(/\b(\d+)\b/g,o=>n("token-number",o)),s=ho(s),s=s.replace(/__TOK_(\d+)__/g,(o,a)=>i[parseInt(a,10)]||""),s}function Jm(e,t){if(!e)return null;const i=e.frontmatter||{};if(i.hideInToc===!0||i.hideInToc==="true")return null;let n=(i.title||"").trim(),s=i.level?parseInt(i.level,10):0;if(!n){const o=e.blocks||[];for(const a of o){const l=(a.rawMarkdown||a.content||"").trim().match(/^(#{1,6})\s+(.*)$/);if(l){s||(s=l[1].length),n=l[2].trim();break}}}return n?((!s||isNaN(s))&&(s=1),{pageIndex:e.pageIndex||t,title:n,level:s}):null}function Xm(e,t=1,i={}){const n=i.minDepth!==void 0?Number(i.minDepth):1,s=i.maxDepth!==void 0?Number(i.maxDepth):1/0,o=[];Array.isArray(e)&&e.forEach((c,d)=>{const p=Jm(c,d+1);p&&o.push(p)});const a=[];let r=null;for(const c of o){const d={...c,active:c.pageIndex===t,hasActiveChild:!1,children:[]};c.level===1||a.length===0?(a.push(d),r=d):r?(d.active&&(r.hasActiveChild=!0),r.children.push(d)):a.push(d)}function l(c,d=1){if(d>s)return[];const p=[];for(const u of c){const f=l(u.children,d+1);d>=n?p.push({...u,children:f}):p.push(...f)}return p}return l(a,1)}function Qm(e,t=1,i={}){const n=Xm(e,t,i),s=i.columns?Number(i.columns):1,o=s>1?` style="column-count: ${s};"`:"",a=i.textSm?" text-sm":"";function r(c,d=1){if(!c||c.length===0)return"";const p=`slides-toc-list slides-toc-list-level-${d}`,u=c.map(f=>{const w=f.active?" slides-toc-item-active":f.hasActiveChild?" slides-toc-item-parent-active":"",m=f.children&&f.children.length>0?r(f.children,d+1):"";let y=rt(f.title);return y.includes("LaTeX")&&(y=y.replace(/\$\\LaTeX\$/g,'<span class="font-math">L<sup>A</sup>T<sub>E</sub>X</span>')),`
        <li class="slides-toc-item${w}" data-page="${f.pageIndex}">
          <a class="slides-toc-link" href="javascript:void(0)">
            <span class="slides-toc-title">${y}</span>
          </a>
          ${m}
        </li>
      `}).join("");return`<ol class="${p}">${u}</ol>`}const l=r(n,1);return`<div class="slides-toc${a}"${o}>${l}</div>`}function ki(e,t){var D,A,C,L,z,N,K,_,U,x,q,O;let i="",n="",s="";const o=[];(D=e.motion)!=null&&D.preset&&e.motion.preset!=="none"&&(i=` slides-motion-${e.motion.preset.toLowerCase()}`,typeof e.motion.duration=="number"&&e.motion.duration>0&&o.push(`--motion-duration:${e.motion.duration}ms`),typeof e.motion.delay=="number"&&e.motion.delay>0&&o.push(`--motion-delay:${e.motion.delay}ms`));const a=((A=e.attributes)==null?void 0:A.style)||"";a&&(o.push(a),s=" slide-styled-block"),o.length>0&&(n=` style="${ot(o.join(";"))}"`);const r=(t==null?void 0:t.containerClassName)||"pdf-block",l=t!=null&&t.extraClassName?` ${t.extraClassName}`:"",c=t!=null&&t.blockClassResolver?t.blockClassResolver(e):"",d=c?` ${c}`:"",p=`${r}${i}${s}${l}${d}`,u=(e.rawMarkdown||e.content||"").trim();if(!u)return`<div class="${p}"${n}></div>`;if(u.includes('class="slides-block-ref"')||u.includes('class="slides-ref-tag"'))return`<div class="${p}"${n}>${u}</div>`;if(u.startsWith("$$")&&u.endsWith("$$")){const $=u.slice(2,-2).trim();return`<div class="${p} katex-display-container"${n}><div class="katex-display font-math"><em>${ot($)}</em></div></div>`}const f=u.match(/^(#{1,6})\s+(.*)$/);if(f){const $=f[1].length,T=rt(f[2]),se=!!(e.isColFirst||e.type==="i"&&((C=t==null?void 0:t.extraClassName)!=null&&C.includes("slides-col-first-heading-block")))?' class="slide-list-item-title"':"";return`<div class="${p}"${n}><h${$}${se}>${T}</h${$}></div>`}if(u.startsWith(":::")){const $=u.split(`
`),P=$[0].replace(/^:::\s*/,"").trim()||"info",se=$.slice(1,$[$.length-1].startsWith(":::")?-1:void 0).join(`
`),V=(t==null?void 0:t.calloutClassName)||"pdf-callout";return`<div class="${p}"${n}><div class="${V} ${V}--${P}"><div class="${V}-title">${P.toUpperCase()}</div><div class="${V}-body">${rt(se)}</div></div></div>`}if(u.startsWith("<<<")){const P=`// Inside ./snippets/external.ts
export function emptyArray<T>(length: number) {
  return Array.from<T>({ length })
}`.split(`
`).map((ie,oe)=>`<span class="code-line shiki-focus"><span class="line-no">${oe+1}</span><span class="line-content">${ca(ie,"ts")}</span></span>`).join(`
`),se=(t==null?void 0:t.codeClassName)||"pdf-code shiki-container",V=((L=e.attrs)==null?void 0:L["custom-slides-max-height"])||((z=e.attributes)==null?void 0:z["custom-slides-max-height"])||e.maxHeight||"",Y=V?/^\d+$/.test(String(V).trim())?`${String(V).trim()}px`:String(V).trim():"",le=Y?` style="max-height:${ot(Y)};overflow-y:auto;"`:"";return`<div class="${p}"${n}><pre class="${se}"${le}><span class="lang-badge">TS</span><code>${P}</code></pre></div>`}if(u.startsWith("<style")||u.startsWith("<!-- Inline style -->")||u.startsWith(`<!--
Notes`))return"";if(u.startsWith("```")){const $=u.split(`
`),T=$[0].slice(3).trim(),P=T.match(/^([^\s{\[]+)/),se=P?P[1]:"",V=T.match(/\[([^\]]+)\]/),Y=V?V[1]:"",le=T.includes("twoslash"),ie=e.shikiLines||((N=T.match(/\{([^}]+)\}/))==null?void 0:N[1])||"",oe=qm(ie),Se=$.length>2?$[$.length-1]==="```"?$.slice(1,-1):$.slice(1):[u.slice(3).replace(/```$/,"")],Ie=(t==null?void 0:t.codeClassName)||"pdf-code shiki-container",_e=Y?`${Ie} has-filename`:Ie,fe=oe!=="all",X=Se.map((j,M)=>{const I=M+1,G=oe==="all"||oe.has(I)?"code-line shiki-focus":fe?"code-line shiki-dimmed":"code-line";let H=(t==null?void 0:t.highlight)===!0?ca(j,se):ot(j);return le&&j.includes("doubled.value = 2")?(H=H.replace(/(\bvalue\b)/,'<span class="twoslash-error-wavy">$1</span>'),`<span class="${G}"><span class="line-no">${I}</span><span class="line-content">${H}</span></span>
<div class="twoslash-popup-error"><span style="color:#ef4444;font-weight:bold;margin-right:4px;">✕</span> Cannot assign to 'value' because it is a read-only property.</div>`):`<span class="${G}"><span class="line-no">${I}</span><span class="line-content">${H}</span></span>`}).join(`
`),pe=se?`<span class="lang-badge">${ot(se)}</span>`:"",E=Y?`<span class="code-filename">${ot(Y)}</span>`:"",F=((K=e.attrs)==null?void 0:K["custom-slides-max-height"])||((_=e.attributes)==null?void 0:_["custom-slides-max-height"])||e.maxHeight||"",g=F?/^\d+$/.test(String(F).trim())?`${String(F).trim()}px`:String(F).trim():"",W=g?` style="max-height:${ot(g)};overflow-y:auto;"`:"";return`<div class="${p}"${n}><pre class="${_e}"${W}>${E}${pe}<code>${X}</code></pre></div>`}if(u.includes("|")&&u.split(`
`).filter($=>$.trim().startsWith("|")).length>=2){const $=u.split(`
`).filter(P=>P.trim().startsWith("|")),T=Zm($,t==null?void 0:t.tableClassName);return`<div class="${p}"${n}>${T}</div>`}if(u.startsWith("> ")){const $=(t==null?void 0:t.quoteClassName)||"pdf-quote";return`<div class="${p}"${n}><blockquote class="${$}"><p>${rt(u.slice(2))}</p></blockquote></div>`}const w=/<video\b/i.test(u)||e.type==="video"||e.type==="NodeVideo",m=/^(\s*)([-*+]|\d+\.)\s+/m.test(u),y=/(?:^|\n)\s*#{1,6}\s+/.test(u);if(w&&!m&&!y&&!u.includes(`
`)){const $=((U=e.attributes)==null?void 0:U["custom-slides-autoplay"])==="true"||/autoplay/i.test(u),T=((x=e.attributes)==null?void 0:x["custom-slides-loop"])==="true"||/loop/i.test(u),P=((q=e.attributes)==null?void 0:q["custom-slides-muted"])==="true"||$||/muted/i.test(u),se=((O=e.attributes)==null?void 0:O["custom-slides-controls"])==="false",V=u.match(/\bsrc=["']([^"']+)["']/i),Y=V?V[1]:"",le=['class="slide-video-player"'];se||le.push("controls"),$&&(le.push("autoplay"),le.push("playsinline")),T&&le.push("loop"),P&&le.push("muted"),le.push('preload="auto"'),Y&&le.push(`src="${Y}"`);const ie=u.match(/<video[^>]*>([\s\S]*?)<\/video>/i);let oe=ie?ie[1].trim():"";return!oe&&Y&&(oe=`<source src="${Y}" type="video/mp4" />您的浏览器不支持视频播放。`),`<div class="${p} ${p}--video slide-media-block slide-video-container slide-media-container" data-autoplay="${$?"true":"false"}" data-muted="${P?"true":"false"}"${n}><video ${le.join(" ")}>${oe}</video></div>`}const b=u.match(/^!\[(.*?)\]\((.*?)\)$/);if(b){const $=(t==null?void 0:t.imageClassName)||"pdf-image slide-media-img";return`<div class="${p} ${p}--image slide-media-block slide-media-container"${n}><img alt="${ot(b[1])}" src="${b[2]}" class="${$}" /></div>`}const v=Kl(u,t,e);if(v)return`<div class="${p} pdf-list-item"${n}>${v}</div>`;if(/<(?:Toc|toc)\b/i.test(u)&&!u.startsWith("```")){const $=u.match(/minDepth=["']?(\d+)["']?/i),T=u.match(/maxDepth=["']?(\d+)["']?/i),P=u.match(/columns=["']?(\d+)["']?/i),se=(t==null?void 0:t.allSlides)||[];return`<div class="${p}"${n}>${Qm(se,(t==null?void 0:t.currentPageIndex)||1,{minDepth:$?parseInt($[1],10):1,maxDepth:T?parseInt(T[1],10):1/0,columns:P?parseInt(P[1],10):1,textSm:u.includes("text-sm")})}</div>`}if(u.includes(`
`)||y){const $=Km(u,t,e);if($)return`<div class="${p}"${n}>${$}</div>`}const S=!!e.isColFirst?' class="slide-list-item-title"':"";return`<div class="${p}"${n}><p${S}>${rt(u)}</p></div>`}function eg(e){return`
    ${On(e)}

    :root {
      --slide-bg: #ffffff;
      --slide-text: #1a1a1a;
      --slide-accent: #3b82f6;
      --slide-font: system-ui, -apple-system, sans-serif;
    }
    [data-theme="dark"] {
      --slide-bg: #121214;
      --slide-text: #e2e8f0;
      --slide-accent: #60a5fa;
    }

    /* 1. 默认科技主题 Default */
    [data-slides-theme="default"],
    .slides-theme-default {
      --slide-font: system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "PingFang SC", "Microsoft YaHei", sans-serif;
      --slide-accent: #10b981;
    }
    [data-theme="light"][data-slides-theme="default"],
    [data-theme="light"] .slides-theme-default {
      --slide-bg: #ffffff;
      --slide-text: #1e293b;
      --slide-accent: #059669;
    }
    [data-theme="dark"][data-slides-theme="default"],
    [data-theme="dark"] .slides-theme-default {
      --slide-bg: #121214;
      --slide-text: #e2e8f0;
      --slide-accent: #34d399;
    }
    .slides-theme-default .layout-cover h1,
    .slides-theme-default .layout-cover .slide-block h1 {
      font-size: 3.8rem !important;
      font-weight: 800 !important;
      line-height: 1.15 !important;
      letter-spacing: -0.025em !important;
      margin-bottom: 18px !important;
      background: linear-gradient(135deg, #10b981, #06b6d4) !important;
      -webkit-background-clip: text !important;
      -webkit-text-fill-color: transparent !important;
    }
    .slides-theme-default .layout-cover h2,
    .slides-theme-default .layout-cover .slide-block h2 {
      font-size: 1.85rem !important;
      font-weight: 600 !important;
      opacity: 0.85 !important;
      margin-bottom: 12px !important;
    }
    .slides-theme-default .layout-cover p,
    .slides-theme-default .layout-cover .slide-block p {
      font-size: 1.45rem !important;
      line-height: 1.5 !important;
      opacity: 0.85 !important;
    }

    /* 2. 优雅衬线主题 Seriph */
    [data-slides-theme="seriph"],
    .slides-theme-seriph {
      --slide-font: "PT Serif", "Charter", "Georgia", "Cambria", "Times New Roman", "Source Han Serif SC", "Noto Serif SC", "Songti SC", "SimSun", serif;
      --slide-accent: #b45309;
      letter-spacing: 0.015em;
    }
    [data-theme="light"][data-slides-theme="seriph"],
    [data-theme="light"] .slides-theme-seriph {
      --slide-bg: #fdfbf7;
      --slide-text: #2a2521;
      --slide-accent: #b45309;
    }
    [data-theme="dark"][data-slides-theme="seriph"],
    [data-theme="dark"] .slides-theme-seriph {
      --slide-bg: #1c1a17;
      --slide-text: #e8e3d9;
      --slide-accent: #f59e0b;
    }
    .slides-theme-seriph,
    .slides-theme-seriph .slide-content {
      font-family: var(--slide-font) !important;
      line-height: 1.72;
    }
    .slides-theme-seriph h1,
    .slides-theme-seriph h2,
    .slides-theme-seriph h3 {
      font-family: var(--slide-font) !important;
      letter-spacing: 0.025em;
      font-weight: 700;
    }
    .slides-theme-seriph .layout-cover h1 {
      background: none !important;
      -webkit-background-clip: initial !important;
      -webkit-text-fill-color: initial !important;
      color: var(--slide-accent) !important;
      font-size: 3.4rem !important;
      border-bottom: 2px solid var(--slide-accent);
      display: inline-block;
      padding-bottom: 10px;
    }

    /* 3. 极简发布会主题 Apple Basic */
    [data-slides-theme="apple-basic"],
    .slides-theme-apple-basic {
      --slide-font: -apple-system, "SF Pro Display", "SF Pro Text", BlinkMacSystemFont, "PingFang SC", "Helvetica Neue", sans-serif;
      --slide-accent: #0071e3;
    }
    [data-theme="light"][data-slides-theme="apple-basic"],
    [data-theme="light"] .slides-theme-apple-basic {
      --slide-bg: #ffffff;
      --slide-text: #1d1d1f;
      --slide-accent: #0071e3;
    }
    [data-theme="dark"][data-slides-theme="apple-basic"],
    [data-theme="dark"] .slides-theme-apple-basic {
      --slide-bg: #000000;
      --slide-text: #f5f5f7;
      --slide-accent: #2997ff;
    }
    .slides-theme-apple-basic,
    .slides-theme-apple-basic .slide-content {
      font-family: var(--slide-font) !important;
    }
    .slides-theme-apple-basic h1,
    .slides-theme-apple-basic h2,
    .slides-theme-apple-basic h3 {
      letter-spacing: -0.035em;
      font-weight: 800;
    }
    .slides-theme-apple-basic .layout-cover h1 {
      background: none !important;
      -webkit-background-clip: initial !important;
      -webkit-text-fill-color: initial !important;
      color: var(--slide-text) !important;
      font-size: 3.8rem !important;
      letter-spacing: -0.04em !important;
    }
    .slides-theme-apple-basic .layout-cover p {
      color: #86868b !important;
      font-size: 1.35rem !important;
    }

    * { box-sizing: border-box; margin: 0; padding: 0; }
    html, body {
      width: 100%; height: 100%; overflow: hidden;
      background: #0f1115; font-family: var(--slide-font);
      display: flex; justify-content: center; align-items: center;
    }
    #app { width: 100%; height: 100%; position: relative; overflow: hidden; }
    .slide-viewport {
      position: absolute; left: 50%; top: 50%;
      background: var(--slide-bg); color: var(--slide-text);
      box-shadow: 0 10px 30px rgba(0,0,0,0.5); border-radius: 8px; overflow: hidden;
      display: flex; flex-direction: column; flex-shrink: 0;
      transform: translate(-50%, -50%) scale(var(--slides-slide-scale, 1));
      transform-origin: center center; will-change: transform;
      transition: background 0.3s ease, color 0.3s ease, border-radius 0.2s ease, box-shadow 0.2s ease;
    }
    :fullscreen .slide-viewport, .is-fullscreen .slide-viewport {
      border-radius: 0 !important; box-shadow: none !important;
    }
    .slide-content {
      position: relative;
      width: 100%;
      height: 100%;
      min-height: 100%;
      flex: 1 1 0%;
      padding: var(--slides-padding-y, 32px) var(--slides-padding-x, 48px);
      display: flex;
      flex-direction: column;
      overflow: hidden;
      box-sizing: border-box;
    }

    /* 间距预设风格 */
    .slide-content.spacing-compact,
    .slide-viewport[data-spacing="compact"] .slide-content,
    [data-slides-spacing="compact"] {
      --slides-padding-y: 20px;
      --slides-padding-x: 36px;
      --slides-header-gap: 10px;
      --slides-title-margin-bottom: 6px;
    }
    .slide-content.spacing-normal,
    .slide-viewport[data-spacing="normal"] .slide-content,
    [data-slides-spacing="normal"] {
      --slides-padding-y: 32px;
      --slides-padding-x: 48px;
      --slides-header-gap: 16px;
      --slides-title-margin-bottom: 10px;
    }
    .slide-content.spacing-loose,
    .slide-viewport[data-spacing="loose"] .slide-content,
    [data-slides-spacing="loose"] {
      --slides-padding-y: 48px;
      --slides-padding-x: 56px;
      --slides-header-gap: 24px;
      --slides-title-margin-bottom: 16px;
    }

    .layout-cover { justify-content: center; align-items: center; text-align: center; }
    .layout-cover h1, .layout-cover .slide-block h1 { font-size: 3.8rem !important; font-weight: 800 !important; line-height: 1.15 !important; letter-spacing: -0.025em !important; margin-bottom: 16px !important; }
    .layout-cover h2, .layout-cover .slide-block h2 { font-size: 1.85rem !important; font-weight: 600 !important; opacity: 0.85 !important; margin-bottom: 12px !important; }
    .layout-cover p, .layout-cover .slide-block p { font-size: 1.45rem !important; line-height: 1.5 !important; opacity: 0.85 !important; }
    .two-cols-left, .two-cols-right { min-width: 0; width: 100%; display: flex; flex-direction: column; box-sizing: border-box; overflow-wrap: break-word; word-break: break-word; }
    .pdf-two-cols-wrapper,
    .layout-two-cols-grid,
    .layout-cols-wrapper,
    .layout-cols-grid {
      display: grid;
      grid-template-columns: var(--slide-grid-cols, minmax(0, 1fr) minmax(0, 1fr));
      grid-template-rows: minmax(0, 1fr) !important;
      gap: 32px;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      overflow: hidden !important;
    }
    .layout-cols-header-container,
    .layout-two-cols-header-container,
    .layout-three-cols-header-container,
    .layout-clover-container {
      display: flex;
      flex-direction: column;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      overflow: hidden !important;
    }
    .layout-header-section {
      width: 100%;
      margin-bottom: var(--slides-header-gap, 16px) !important;
      flex-shrink: 0;
    }
    .layout-header-section h1,
    .layout-header-section h2,
    .layout-header-section h3 {
      margin-bottom: var(--slides-title-margin-bottom, 10px) !important;
    }
    .pdf-three-cols-wrapper,
    .layout-three-cols-grid {
      display: grid;
      grid-template-columns: var(--slide-grid-cols, minmax(0, 1fr) minmax(0, 1fr) minmax(0, 1fr));
      grid-template-rows: minmax(0, 1fr) !important;
      gap: 24px;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      box-sizing: border-box;
      overflow: hidden !important;
    }
    .pdf-clover-wrapper,
    .layout-clover-grid {
      display: grid;
      grid-template-columns: repeat(2, minmax(0, 1fr)) !important;
      grid-template-rows: repeat(2, minmax(0, 1fr)) !important;
      gap: 20px;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      box-sizing: border-box;
      overflow: hidden !important;
    }
    .layout-clover-grid .pdf-col {
      background: transparent !important;
      border: none !important;
      box-shadow: none !important;
    }
    .pdf-col {
      display: flex;
      flex-direction: column;
      gap: 14px;
      min-width: 0;
      width: 100%;
      max-width: 100%;
      height: 100%;
      max-height: 100%;
      min-height: 0;
      justify-content: flex-start;
      box-sizing: border-box;
      overflow: hidden;
      overflow-wrap: break-word;
      word-break: break-word;
      white-space: normal;
    }
    .pdf-col * {
      overflow-wrap: break-word;
      word-break: break-word;
      box-sizing: border-box;
    }
    /* 表头多栏内超级块子块首个列表项去圆点后居中显示标题/首行文本 (仅在存在超级块分栏时生效) */
    .has-superblock-cols .pdf-col > *:first-child .slide-list-item-title,
    .has-superblock-cols .pdf-col > *:first-child :is(h1, h2, h3, h4, h5, h6),
    .has-superblock-cols .pdf-col > *:first-child p.slide-list-item-title,
    .has-superblock-cols .pdf-col > *:first-child p:first-of-type,
    .has-superblock-cols .pdf-col > *:first-child p:first-child,
    .has-superblock-cols .pdf-col > *:first-child :is(ul, ol) > li:first-child,
    .has-superblock-cols .pdf-col > *:first-child .slide-list > .slide-list-item:first-child,
    .has-superblock-cols .pdf-col > *:first-child .pdf-list > li:first-child,
    .has-superblock-cols .slides-col-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    .has-superblock-cols .slides-col-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      list-style: none !important;
      list-style-type: none !important;
      text-align: center !important;
      margin-left: 0 !important;
      padding-left: 0 !important;
      width: 100% !important;
    }

    /* 彻底清除首个列表项的原生圆点 Marker (仅在存在超级块分栏时生效) */
    .has-superblock-cols .pdf-col > *:first-child :is(ul, ol) > li:first-child::marker {
      content: "" !important;
      display: none !important;
    }

    /* 确保首个列表项内部内联与块级元素居中 (仅在存在超级块分栏时生效) */
    .has-superblock-cols .pdf-col > *:first-child :is(ul, ol) > li:first-child * {
      text-align: center !important;
    }

    /* 栏内说明段落与列表项：左对齐，自然阅读排版 */
    .has-superblock-cols .pdf-col .slide-list-item-desc,
    .has-superblock-cols .pdf-col li:not(:first-child) {
      text-align: left !important;
    }

    /* 全局特定标题大小规范化 (除封面外页首首个标题按 H2 1.7rem，表头多栏内首个标题按 H3 1.3rem) */
    [data-normalize-headings="true"] .slides-page-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .slides-page-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .slide-content:not(.layout-cover) > :is(.pdf-block, .slide-block):first-child :is(h1, h2, h3, h4, h5, h6),
    [data-normalize-headings="true"] .slide-content:not(.layout-cover) > .layout-header-section :is(.pdf-block, .slide-block):first-child :is(h1, h2, h3, h4, h5, h6),
    [data-normalize-headings="true"] .slide-content:not(.layout-cover) > :not(.layout-cols-wrapper):not(.pdf-two-cols-wrapper):not(.layout-image-cols-grid):first-child :is(h1, h2, h3, h4, h5, h6) {
      font-size: 1.7rem !important;
      font-weight: 600 !important;
      line-height: 1.25 !important;
      margin-bottom: 10px !important;
    }

    [data-normalize-headings="true"] .has-superblock-cols .slides-col-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .has-superblock-cols .slides-col-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .has-superblock-cols .pdf-col > *:first-child :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      font-size: 1.3rem !important;
      font-weight: 600 !important;
      line-height: 1.3 !important;
      margin-bottom: 8px !important;
      text-align: center !important;
    }

    /* 图左与图右版式标题完全保留用户原始字号与默认排版，不进行任何固定大小规范化 */
    [data-normalize-headings="true"] :is(.layout-image-left, .layout-image-right, .image-left-content, .image-right-content) :is(h1, h2, h3, h4, h5, h6) {
      text-align: left !important;
    }
    .pdf-col pre,
    .two-cols-left pre,
    .two-cols-right pre,
    .image-right-content pre,
    .image-left-content pre {
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      overflow-x: hidden !important;
      overflow-y: auto !important;
      max-width: 100% !important;
      box-sizing: border-box !important;
    }
    .slide-content.layout-image-right, .slide-content.layout-image-left {
      padding: 0;
      display: grid;
      grid-template-columns: var(--slide-grid-cols, minmax(0, 1fr) minmax(0, 1fr));
      grid-template-rows: 100%;
      width: 100%;
      height: 100%;
      position: absolute;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      box-sizing: border-box;
    }
    .image-right-content, .image-left-content {
      padding: 44px 50px;
      display: flex;
      flex-direction: column;
      justify-content: flex-start;
      overflow-y: auto;
      width: 100%;
      height: 100%;
      box-sizing: border-box;
    }
    .image-right-img-container, .image-left-img-container {
      width: 100%;
      height: 100%;
      overflow: hidden;
      position: relative;
      background: #18181b;
      display: flex;
      align-items: center;
      justify-content: center;
    }
    .image-right-img, .image-left-img {
      width: 100%;
      height: 100%;
      object-fit: cover;
      object-position: center;
      display: block;
    }
    .slide-block { margin-bottom: 14px; line-height: 1.6; }
    .slide-block h1 { font-size: 2.2rem; margin-bottom: 12px; }
    .slide-block h2 { font-size: 1.7rem; margin-bottom: 10px; }
    .slide-block p { font-size: 1.15rem; }
    .slide-block ul, .slide-block ol, .pdf-list {
      padding-left: 28px;
      margin: 8px 0;
      display: flex;
      flex-direction: column;
      gap: 6px;
    }
    .slide-block li, .pdf-list li {
      font-size: 1.15rem;
      line-height: 1.6;
    }
    .pdf-task-item {
      list-style: none;
      margin-left: -20px;
      display: flex;
      align-items: center;
      gap: 8px;
    }
    .pdf-task-item input[type="checkbox"] {
      width: 1.15em;
      height: 1.15em;
      cursor: pointer;
    }

    /* 两栏与三栏及多栏（超级块分栏）布局：紧凑自然行距，子列表保留圆点与层级缩进 */
    .layout-two-cols ul,
    .layout-cols-header ul,
    .layout-two-cols-header ul,
    .layout-three-cols ul,
    .layout-three-cols-header ul,
    .two-cols-left ul,
    .two-cols-right ul,
    .three-cols-col ul,
    .col ul,
    .pdf-col ul,
    .layout-two-cols-grid .pdf-list,
    .layout-three-cols-grid .pdf-list,
    .layout-cols-grid .pdf-list,
    .layout-two-cols-grid .pdf-list--unordered,
    .layout-three-cols-grid .pdf-list--unordered,
    .layout-cols-grid .pdf-list--unordered {
      list-style: disc !important;
      list-style-type: disc !important;
      padding-left: 1.25em !important;
      margin-left: 0 !important;
      margin-top: 0 !important;
      margin-bottom: 8px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: block !important;
    }

    .layout-two-cols ol,
    .layout-cols-header ol,
    .layout-two-cols-header ol,
    .layout-three-cols ol,
    .layout-three-cols-header ol,
    .two-cols-left ol,
    .two-cols-right ol,
    .three-cols-col ol,
    .col ol,
    .pdf-col ol,
    .layout-two-cols-grid .pdf-list--ordered,
    .layout-three-cols-grid .pdf-list--ordered,
    .layout-cols-grid .pdf-list--ordered {
      list-style: decimal !important;
      list-style-type: decimal !important;
      padding-left: 1.25em !important;
      margin-left: 0 !important;
      margin-top: 0 !important;
      margin-bottom: 8px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: block !important;
    }

    .layout-two-cols li,
    .layout-cols-header li,
    .layout-two-cols-header li,
    .layout-three-cols li,
    .layout-three-cols-header li,
    .two-cols-left li,
    .two-cols-right li,
    .three-cols-col li,
    .col li,
    .pdf-col li,
    .pdf-col .pdf-list-item {
      padding-left: 0.2em !important;
      margin-left: 0 !important;
      margin-bottom: 6px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: list-item !important;
      line-height: 1.6 !important;
    }

    .layout-two-cols ul ul,
    .layout-three-cols ul ul,
    .three-cols-col ul ul,
    .pdf-col ul ul {
      list-style: circle !important;
      list-style-type: circle !important;
      padding-left: 1.25em !important;
      margin-top: 4px !important;
      margin-bottom: 4px !important;
    }

    /* 列表项内嵌标题与说明排版 */
    .slide-list-item-title,
    .pdf-list li > h1,
    .pdf-list li > h2,
    .pdf-list li > h3,
    .pdf-list li > h4,
    .pdf-list li > h5,
    .pdf-list li > h6,
    li > h1.slide-list-item-title,
    li > h2.slide-list-item-title,
    li > h3.slide-list-item-title,
    li > h4.slide-list-item-title {
      margin-top: 2px !important;
      margin-bottom: 6px !important;
      line-height: 1.35 !important;
      font-weight: 700 !important;
    }
    .pdf-list li > h1, li > h1.slide-list-item-title { font-size: 1.6rem !important; }
    .pdf-list li > h2, li > h2.slide-list-item-title { font-size: 1.4rem !important; }
    .pdf-list li > h3, li > h3.slide-list-item-title { font-size: 1.22rem !important; }
    .pdf-list li > h4, li > h4.slide-list-item-title { font-size: 1.1rem !important; }

    /* 全局特定标题大小规范化后置强力锁定 (防止被列表项内部字号覆盖) */
    [data-normalize-headings="true"] .slides-page-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .slides-page-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      font-size: 1.7rem !important;
      font-weight: 600 !important;
      line-height: 1.25 !important;
      margin-bottom: 10px !important;
    }
    [data-normalize-headings="true"] .slides-col-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .slides-col-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] :is(.layout-cols-wrapper, .pdf-two-cols-wrapper, .layout-cols-header-container, .layout-cols-grid) .pdf-col > *:first-child :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] :is(.two-cols-left, .two-cols-right, .pdf-col, .col) > *:first-child :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      font-size: 1.3rem !important;
      font-weight: 600 !important;
      line-height: 1.3 !important;
      margin-bottom: 8px !important;
      text-align: center !important;
    }
    /* 基础列表项前缀样式 */
    .slide-block ul,
    .slide-list--unordered,
    .pdf-list--unordered {
      list-style: disc !important;
      list-style-type: disc !important;
    }
    .slide-block ol,
    .slide-list--ordered,
    .pdf-list--ordered {
      list-style: decimal !important;
      list-style-type: decimal !important;
    }
    .slide-block li,
    .slide-list-item,
    .pdf-list-item,
    .pdf-list li {
      display: list-item !important;
    }

    /* 隐藏无序列表前缀标记 */
    [data-hide-unordered-markers="true"] :is(ul, .slide-list, .slide-list--unordered, .pdf-list, .pdf-list--unordered),
    [data-hide-unordered-markers="true"] :is(ul, .slide-list, .slide-list--unordered, .pdf-list, .pdf-list--unordered) > li,
    [data-hide-unordered-markers="true"] li.slide-list-item,
    [data-hide-unordered-markers="true"] ul > li {
      list-style: none !important;
      list-style-type: none !important;
      padding-left: 0 !important;
      margin-left: 0 !important;
    }
    [data-hide-unordered-markers="true"] :is(ul, .slide-list, .slide-list--unordered, .pdf-list, .pdf-list--unordered) > li::marker,
    [data-hide-unordered-markers="true"] li.slide-list-item::marker {
      content: "" !important;
      display: none !important;
    }

    /* 隐藏有序列表前缀标记 */
    [data-hide-ordered-markers="true"] :is(ol, .slide-list, .slide-list--ordered, .pdf-list, .pdf-list--ordered),
    [data-hide-ordered-markers="true"] :is(ol, .slide-list, .slide-list--ordered, .pdf-list, .pdf-list--ordered) > li,
    [data-hide-ordered-markers="true"] li.slide-list-item,
    [data-hide-ordered-markers="true"] ol > li {
      list-style: none !important;
      list-style-type: none !important;
      padding-left: 0 !important;
      margin-left: 0 !important;
    }
    [data-hide-ordered-markers="true"] :is(ol, .slide-list, .slide-list--ordered, .pdf-list, .pdf-list--ordered) > li::marker,
    [data-hide-ordered-markers="true"] li.slide-list-item::marker {
      content: "" !important;
      display: none !important;
    }

    .slide-list-item-desc,
    .pdf-list li > p {
      margin-top: 4px !important;
      margin-bottom: 6px !important;
      font-size: 1.05rem;
      line-height: 1.55;
      opacity: 0.92;
    }

    /* 多媒体（GIF动图、静态图片、MP4视频）全视口最大化自适应且不超出视口 */
    .slide-media-block,
    .slide-media-container,
    .slide-video-container,
    .slide-block--media,
    .slide-block--image,
    .slide-block--video,
    .slide-block:has(> img),
    .slide-block:has(> .slide-media-container),
    .slide-block:has(> p > img:only-child),
    .slide-block:has(> .slide-video-container),
    .slide-block:has(> video) {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      min-width: 0 !important;
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
      justify-content: center !important;
      width: 100% !important;
      height: 100% !important;
      max-height: 100% !important;
      overflow: hidden !important;
      margin: 4px 0 !important;
      box-sizing: border-box !important;
    }

    .two-cols-left > .slide-block,
    .two-cols-right > .slide-block,
    .three-cols-col > .slide-block,
    .pdf-col > .slide-block,
    .pdf-col .slide-block {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      max-height: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      width: 100% !important;
      height: 100% !important;
      box-sizing: border-box !important;
      overflow: hidden !important;
      margin-bottom: 0 !important;
    }

    /* 列内列表项的标题与段落文字：固定高度，不压缩 */
    .two-cols-left .slide-list-item-title,
    .two-cols-right .slide-list-item-title,
    .three-cols-col .slide-list-item-title,
    .pdf-col .slide-list-item-title,
    .two-cols-left h1, .two-cols-left h2, .two-cols-left h3, .two-cols-left h4, .two-cols-left h5, .two-cols-left h6,
    .two-cols-right h1, .two-cols-right h2, .two-cols-right h3, .two-cols-right h4, .two-cols-right h5, .two-cols-right h6,
    .three-cols-col h1, .three-cols-col h2, .three-cols-col h3, .three-cols-col h4, .three-cols-col h5, .three-cols-col h6,
    .pdf-col h1, .pdf-col h2, .pdf-col h3, .pdf-col h4, .pdf-col h5, .pdf-col h6,
    .three-cols-col .slide-list-item-desc,
    .pdf-col .slide-list-item-desc {
      flex: 0 0 auto !important;
      margin-top: 0 !important;
      margin-bottom: 6px !important;
    }

    /* 列内媒体容器：填满标题下方所有剩余垂直空间，纵向顶部对齐，横向居中，无溢出 */
    .two-cols-left .slide-list-media,
    .two-cols-right .slide-list-media,
    .three-cols-col .slide-list-media,
    .pdf-col .slide-list-media,
    .two-cols-left .slide-video-container,
    .two-cols-right .slide-video-container,
    .three-cols-col .slide-video-container,
    .pdf-col .slide-video-container,
    .two-cols-left .slide-media-container,
    .two-cols-right .slide-media-container,
    .three-cols-col .slide-media-container,
    .pdf-col .slide-media-container {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      min-width: 0 !important;
      width: 100% !important;
      height: 100% !important;
      max-height: 100% !important;
      max-width: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
      justify-content: flex-start !important;
      overflow: hidden !important;
      margin: 0 !important;
      padding: 0 !important;
      box-sizing: border-box !important;
    }

    /* 列内多媒体播放器：以 contain 模式等比缩放完整可见，绝对不超高超宽、不产生遮挡与滚动条 */
    .two-cols-left video,
    .two-cols-right video,
    .three-cols-col video,
    .pdf-col video,
    .two-cols-left img,
    .two-cols-right img,
    .three-cols-col img,
    .pdf-col img,
    .two-cols-left .slide-video-player,
    .two-cols-right .slide-video-player,
    .three-cols-col .slide-video-player,
    .pdf-col .slide-video-player,
    .layout-three-cols-grid video,
    .layout-two-cols-grid video,
    .layout-three-cols-grid img,
    .layout-two-cols-grid img {
      max-width: 100% !important;
      max-height: 100% !important;
      width: auto !important;
      height: auto !important;
      min-width: 0 !important;
      min-height: 0 !important;
      object-fit: contain !important;
      display: block !important;
      margin: 0 auto !important;
      cursor: zoom-in;
    }

    .slide-block img,
    .slide-media-img,
    .slide-media-container img,
    .slide-video-player,
    video.slide-video-player,
    .slide-block video {
      max-width: 100% !important;
      max-height: 100% !important;
      width: auto !important;
      height: auto !important;
      min-width: 0 !important;
      min-height: 0 !important;
      object-fit: contain !important;
      display: block !important;
      margin: 0 auto !important;
      border-radius: 8px;
      box-shadow: 0 4px 16px rgba(0, 0, 0, 0.16);
      background: transparent;
      outline: none;
      cursor: zoom-in;
    }

    .slide-list-media {
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
      justify-content: flex-start !important;
      width: 100% !important;
      max-width: 100% !important;
      height: 100% !important;
      max-height: 100% !important;
      flex: 1 1 0% !important;
      margin-top: 4px !important;
      margin-bottom: 4px !important;
      min-height: 0 !important;
      overflow: hidden !important;
      box-sizing: border-box !important;
    }
    .slide-list-media img,
    .slide-list-media video,
    .slide-list-media .list-item-gif,
    .slide-list-media .slide-video-player {
      max-width: 100% !important;
      max-height: 100% !important;
      width: auto !important;
      height: auto !important;
      min-width: 0 !important;
      min-height: 0 !important;
      object-fit: contain !important;
      border-radius: 6px !important;
      box-shadow: 0 3px 12px rgba(0, 0, 0, 0.14) !important;
      display: block !important;
      margin: 0 auto !important;
      cursor: zoom-in;
    }

    .slide-block:has(.slide-list-media) {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      height: 100% !important;
      max-height: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      overflow: hidden !important;
    }
    .slide-block:has(.slide-list-media) .pdf-list,
    .slide-block:has(.slide-list-media) ul,
    .slide-block:has(.slide-list-media) ol {
      display: block !important;
      flex: 1 1 auto;
      min-height: 0;
      max-height: 100%;
      overflow: visible !important;
      list-style: disc !important;
      list-style-type: disc !important;
    }
    .slide-block:has(.slide-list-media) li,
    .slide-block:has(.slide-list-media) .slide-list-item,
    .slide-block:has(.slide-list-media) .pdf-list-item,
    .slide-block:has(.slide-media-container) li,
    .slide-block:has(.slide-video-container) li,
    .layout-cols-wrapper li:has(.slide-list-media),
    .layout-cols-header-container li:has(.slide-list-media),
    .two-cols-left li:has(.slide-list-media),
    .two-cols-right li:has(.slide-list-media),
    .three-cols-col li:has(.slide-list-media),
    .pdf-col li:has(.slide-list-media),
    li:has(.slide-list-media),
    li:has(.slide-video-container),
    li:has(.slide-media-container) {
      display: list-item !important;
      list-style-type: disc !important;
      flex: 0 0 auto !important;
      height: auto !important;
      max-height: none !important;
      overflow: visible !important;
      margin-bottom: 6px !important;
    }

    .layout-two-cols .slide-media-block,
    .layout-two-cols .slide-video-container,
    .layout-two-cols .slide-media-container,
    .layout-three-cols .slide-media-block,
    .layout-three-cols .slide-video-container,
    .layout-three-cols .slide-media-container {
      max-width: 100% !important;
      max-height: 100% !important;
      width: 100% !important;
      height: 100% !important;
      min-width: 0 !important;
      min-height: 0 !important;
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
      justify-content: flex-start !important;
      overflow: hidden !important;
    }

    /* Lightbox 大图与视频灯箱模态窗口 */
    .slides-lightbox {
      position: fixed;
      top: 0;
      left: 0;
      width: 100vw;
      height: 100vh;
      background: rgba(0, 0, 0, 0.88);
      backdrop-filter: blur(8px);
      z-index: 999999;
      display: none;
      align-items: center;
      justify-content: center;
      cursor: zoom-out;
      opacity: 0;
      transition: opacity 0.2s cubic-bezier(0.16, 1, 0.3, 1);
    }
    .slides-lightbox.active {
      display: flex;
      opacity: 1;
    }
    .slides-lightbox-content {
      position: relative;
      max-width: 92vw;
      max-height: 92vh;
      display: flex;
      align-items: center;
      justify-content: center;
      cursor: default;
    }
    .slides-lightbox-img {
      max-width: 92vw;
      max-height: 92vh;
      object-fit: contain;
      border-radius: 8px;
      box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.75);
      user-select: none;
      -webkit-user-drag: none;
      touch-action: none;
    }
    .slides-lightbox-video {
      max-width: 92vw;
      max-height: 92vh;
      border-radius: 8px;
      box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.75);
    }
    .slides-lightbox-close {
      position: absolute;
      top: 24px;
      right: 28px;
      width: 40px;
      height: 40px;
      background: rgba(255, 255, 255, 0.2);
      border: 1px solid rgba(255, 255, 255, 0.35);
      border-radius: 50%;
      color: #fff;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 22px;
      cursor: pointer;
      transition: background 0.2s, transform 0.2s;
      z-index: 1000000;
    }
    .slides-lightbox-close:hover {
      background: rgba(255, 255, 255, 0.35);
      transform: scale(1.05);
    }

    img.slide-inline-img {
      max-width: 100% !important;
      max-height: min(320px, 40vh) !important;
      object-fit: contain !important;
      vertical-align: middle;
      border-radius: 4px;
    }
    kbd {
      display: inline-block;
      padding: 2px 7px;
      font-family: ui-monospace, SFMono-Regular, "SF Mono", Menlo, Consolas, "Liberation Mono", monospace;
      font-size: 0.85em;
      font-weight: 600;
      line-height: 1.25;
      color: inherit;
      background: rgba(125, 125, 125, 0.12);
      border: 1px solid rgba(125, 125, 125, 0.35);
      border-bottom-width: 2px;
      border-radius: 5px;
      box-shadow: 0 1px 2px rgba(0, 0, 0, 0.12);
      margin: 0 2px;
      vertical-align: middle;
      white-space: nowrap;
    }
    [data-theme="dark"] kbd, .theme-dark kbd {
      background: rgba(255, 255, 255, 0.1);
      border-color: rgba(255, 255, 255, 0.25);
      border-bottom-color: rgba(255, 255, 255, 0.4);
      color: #f1f5f9;
      box-shadow: 0 1px 2px rgba(0, 0, 0, 0.4);
    }
    .slide-block pre,
    pre {
      background: rgba(0, 0, 0, 0.1);
      padding: 12px;
      border-radius: 6px;
      font-family: "JetBrains Mono", Consolas, monospace;
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      overflow-x: hidden !important;
      overflow-y: auto !important;
      max-width: 100% !important;
      box-sizing: border-box !important;
    }
    .slide-block pre code,
    pre code {
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      display: block !important;
      width: 100% !important;
      box-sizing: border-box !important;
    }
    .code-line {
      display: flex !important;
      align-items: flex-start !important;
      width: 100% !important;
      box-sizing: border-box !important;
      line-height: 1.6;
    }
    .code-line .line-no {
      display: inline-block !important;
      flex-shrink: 0 !important;
      min-width: 2.2em !important;
      text-align: right !important;
      margin-right: 12px !important;
      user-select: none !important;
      opacity: 0.45 !important;
    }
    .code-line .line-content {
      flex: 1 1 0% !important;
      min-width: 0 !important;
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
    }
    /* 弱提示滚动条样式 */
    * {
      scrollbar-width: thin;
      scrollbar-color: rgba(255, 255, 255, 0.20) transparent;
    }
    *::-webkit-scrollbar {
      width: 4px;
      height: 4px;
    }
    *::-webkit-scrollbar-track {
      background: transparent;
    }
    *::-webkit-scrollbar-thumb {
      background: rgba(255, 255, 255, 0.20);
      border-radius: 2px;
      transition: background 0.2s ease;
    }
    *:hover::-webkit-scrollbar-thumb,
    *::-webkit-scrollbar-thumb:hover {
      background: rgba(255, 255, 255, 0.45);
    }
    /* Slidev Micro-motion Keyframes & Presets */
    @keyframes slidesMotionFadeIn { from { opacity: 0; } to { opacity: 1; } }
    @keyframes slidesMotionSlideUp { from { opacity: 0; transform: translateY(40px); } to { opacity: 1; transform: translateY(0); } }
    @keyframes slidesMotionSlideDown { from { opacity: 0; transform: translateY(-40px); } to { opacity: 1; transform: translateY(0); } }
    @keyframes slidesMotionSlideLeft { from { opacity: 0; transform: translateX(40px); } to { opacity: 1; transform: translateX(0); } }
    @keyframes slidesMotionSlideRight { from { opacity: 0; transform: translateX(-40px); } to { opacity: 1; transform: translateX(0); } }
    @keyframes slidesMotionZoomIn { from { opacity: 0; transform: scale(0.8); } to { opacity: 1; transform: scale(1); } }
    @keyframes slidesMotionBounce {
      0% { opacity: 0; transform: translateY(40px); }
      60% { opacity: 1; transform: translateY(-8px); }
      80% { transform: translateY(4px); }
      100% { transform: translateY(0); }
    }
    .slides-motion-fade-in { animation: slidesMotionFadeIn var(--motion-duration, 0.4s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slides-motion-slide-up { animation: slidesMotionSlideUp var(--motion-duration, 0.45s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slides-motion-slide-down { animation: slidesMotionSlideDown var(--motion-duration, 0.45s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slides-motion-slide-left { animation: slidesMotionSlideLeft var(--motion-duration, 0.45s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slides-motion-slide-right { animation: slidesMotionSlideRight var(--motion-duration, 0.45s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slides-motion-zoom-in, .slides-motion-pop { animation: slidesMotionZoomIn var(--motion-duration, 0.4s) cubic-bezier(0.34, 1.56, 0.64, 1) var(--motion-delay, 0s) both; }
    .slides-motion-bounce { animation: slidesMotionBounce var(--motion-duration, 0.6s) cubic-bezier(0.34, 1.56, 0.64, 1) var(--motion-delay, 0s) both; }
    .controls {
      position: absolute; bottom: 16px; display: flex; gap: 12px; align-items: center;
      background: rgba(24, 24, 27, 0.8); backdrop-filter: blur(8px);
      padding: 6px 18px; border-radius: 20px; color: #fff; font-size: 13px; z-index: 10;
      opacity: 0; pointer-events: auto;
      transition: opacity 0.3s cubic-bezier(0.16, 1, 0.3, 1), transform 0.3s cubic-bezier(0.16, 1, 0.3, 1);
    }
    .controls::before {
      content: ""; position: absolute; top: -20px; bottom: -16px; left: -24px; right: -24px;
    }
    .controls:hover, .controls:focus-within {
      opacity: 1; transform: translateY(-2px);
    }
    .controls button { background: transparent; border: none; color: inherit; cursor: pointer; padding: 2px 6px; }

    /* Slidev Native Icons & Interactive Buttons */
    .slidev-icon-btn {
      display: inline-flex !important; flex-direction: row !important; align-items: center !important; justify-content: center !important;
      padding: 0.35rem 0.5rem; border-radius: 0.375rem; background: transparent;
      border: 1px solid transparent; color: inherit; font-size: inherit; line-height: 1;
      cursor: pointer; opacity: 0.8; transition: all 0.2s ease; text-decoration: none;
      vertical-align: middle; user-select: none; margin: 0 4px;
    }
    .slidev-icon-btn:hover { opacity: 1; background: rgba(255, 255, 255, 0.12); border-color: rgba(255, 255, 255, 0.15); }

    /* 组件从上到下按顺序流式渲染，避免相互重叠 */
    .slide-block > div + div { margin-top: 14px; }

    /* 同一个 div 内的按钮/链接从左到右水平渲染 */
    .slide-block div:has(> .slidev-icon-btn),
    .slide-block div:has(> button),
    .slide-block [class*="abs-"],
    .slides-btn-row {
      display: inline-flex !important;
      flex-direction: row !important;
      align-items: center !important;
      justify-content: center !important;
      flex-wrap: wrap !important;
      gap: 8px !important;
    }

    /* Position Shortcuts 适配：在组件流中保持从上到下排列，不脱离流产生重叠 */
    .slide-block .abs-br,
    .slide-block .abs-bl,
    .slide-block .abs-tr,
    .slide-block .abs-tl,
    .slide-block [class*="abs-"] {
      position: relative !important;
      bottom: auto !important;
      right: auto !important;
      top: auto !important;
      left: auto !important;
      margin: 0.75rem auto !important;
    }

    .slide-block--absolute { position: relative !important; margin-bottom: 14px !important; padding: 0 !important; background: transparent !important; }
    .slide-block--absolute:hover { background: transparent !important; }
    .mt-12 { margin-top: 3rem !important; }
    .py-1 { padding-top: 0.25rem !important; padding-bottom: 0.25rem !important; }
    .m-6 { margin: 1.5rem !important; }
    .text-xl { font-size: 1.25rem !important; }
    [hover\\:bg~="white"][hover\\:bg~="op-10"]:hover,
    [hover\\:bg="white op-10"]:hover { background: rgba(255, 255, 255, 0.1) !important; border-radius: 4px; }
    .cursor-pointer, [data-clickable] { cursor: pointer; }
    /* Slidev 规范链接排版 (继承正文颜色，虚线底边，Hover 时平滑点亮为主题色并转为实线) */
    .slide-content a:not(.slides-ref-tag):not(.slidev-icon-btn):not(.slides-toc-link),
    .slide-block a:not(.slides-ref-tag):not(.slidev-icon-btn):not(.slides-toc-link),
    a.slides-link {
      color: inherit;
      text-decoration: none;
      border-bottom: 1px dashed currentColor;
      transition: color 0.2s cubic-bezier(0.4, 0, 0.2, 1),
                  border-color 0.2s cubic-bezier(0.4, 0, 0.2, 1),
                  border-bottom-style 0.2s cubic-bezier(0.4, 0, 0.2, 1);
      cursor: pointer;
    }
    .slide-content a:not(.slides-ref-tag):not(.slidev-icon-btn):not(.slides-toc-link):hover,
    .slide-block a:not(.slides-ref-tag):not(.slidev-icon-btn):not(.slides-toc-link):hover,
    a.slides-link:hover {
      color: var(--slide-accent);
      border-bottom-style: solid;
      border-bottom-color: var(--slide-accent);
    }
    .slides-ref-tag, a.slides-ref-tag {
      display: inline-flex;
      align-items: center;
      background: color-mix(in srgb, var(--slide-accent) 12%, transparent);
      color: var(--slide-accent);
      border-radius: 4px;
      padding: 2px 8px;
      font-size: 0.88em;
      text-decoration: none;
      cursor: pointer;
      margin: 2px 4px 2px 0;
      border: 1px solid color-mix(in srgb, var(--slide-accent) 25%, transparent);
      transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
    }
    .slides-ref-tag:hover, a.slides-ref-tag:hover {
      background: color-mix(in srgb, var(--slide-accent) 22%, transparent);
      color: var(--slide-accent);
      border-color: color-mix(in srgb, var(--slide-accent) 55%, transparent);
      transform: translateY(-1px);
      box-shadow: 0 2px 8px color-mix(in srgb, var(--slide-accent) 20%, transparent);
    }
    .slides-block-ref {
      display: block;
      padding: 10px 14px;
      background: color-mix(in srgb, var(--slide-accent) 8%, transparent);
      border-left: 3px solid var(--slide-accent);
      border-radius: 0 6px 6px 0;
      margin: 8px 0;
      cursor: pointer;
      transition: background 0.2s ease;
    }
    .slides-block-ref:hover {
      background: color-mix(in srgb, var(--slide-accent) 15%, transparent);
    }

    /* 页面动态蒙版 (Dynamic Mask) GPU 合成器硬件加速体系 */
    .slides-mask-body-container {
      position: relative;
      width: 100%;
      height: 100%;
      min-height: 0;
      flex: 1;
      display: flex;
      flex-direction: column;
      overflow: hidden !important;
      contain: layout paint;
      isolation: isolate;
    }
    .slides-mask-body-container--has-mask {
      overflow: hidden !important;
      /* 向左右、向下突破父容器内边距，完全贴合幻灯片视口边缘 */
      margin-left: calc(-1 * var(--slides-padding-x, 48px)) !important;
      margin-right: calc(-1 * var(--slides-padding-x, 48px)) !important;
      margin-bottom: calc(-1 * var(--slides-padding-y, 32px)) !important;
      padding-left: var(--slides-padding-x, 48px) !important;
      padding-right: var(--slides-padding-x, 48px) !important;
      padding-bottom: var(--slides-padding-y, 32px) !important;
      width: calc(100% + 2 * var(--slides-padding-x, 48px)) !important;
      box-sizing: border-box !important;
    }
    /* 无标题且首个元素即为蒙版正文容器时，向上同步扩展至顶部边缘 */
    .slide-content-wrapper > .slides-mask-body-container--has-mask:first-child,
    .slide-content > .slides-mask-body-container--has-mask:first-child {
      margin-top: calc(-1 * var(--slides-padding-y, 32px)) !important;
      padding-top: var(--slides-padding-y, 32px) !important;
    }
    /* 针对全屏零内边距特殊布局（如 image-right/image-left），重置内边距变量避免越界 */
    .slide-content-wrapper.layout-image-right,
    .slide-content-wrapper.layout-image-left,
    .slide-content.layout-image-right,
    .slide-content.layout-image-left {
      --slides-padding-x: 0px !important;
      --slides-padding-y: 0px !important;
    }
    /* 蒙版运动总图层：纯 GPU Compositor 硬件加速 translate3d */
    .slides-mask-layer {
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      pointer-events: none;
      z-index: 50;
      will-change: transform, opacity;
      transform: translate3d(0, 0, 0);
      backface-visibility: hidden;
      transition: transform 0.42s cubic-bezier(0.2, 0, 0, 1),
                  opacity 0.42s cubic-bezier(0.2, 0, 0, 1);
    }
    /* 蒙版内部遮罩层：纯色或磨砂玻璃 */
    .slides-mask-overlay {
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      pointer-events: none;
    }
    .slides-mask-layer--solid .slides-mask-overlay,
    .slides-mask-overlay--solid {
      background: var(--slide-bg, #ffffff);
    }
    [data-theme="dark"] .slides-mask-layer--solid .slides-mask-overlay,
    [data-theme="dark"] .slides-mask-overlay--solid {
      background: var(--slide-bg, #121214);
    }
    .slides-mask-layer--blur .slides-mask-overlay,
    .slides-mask-overlay--blur {
      backdrop-filter: blur(30px) saturate(180%);
      -webkit-backdrop-filter: blur(30px) saturate(180%);
      background: color-mix(in srgb, var(--slide-bg, #ffffff) 90%, transparent);
    }
    [data-theme="dark"] .slides-mask-layer--blur .slides-mask-overlay,
    [data-theme="dark"] .slides-mask-overlay--blur {
      background: color-mix(in srgb, var(--slide-bg, #121214) 90%, transparent);
    }
    /* 动态展露分界提示线：物理内嵌于蒙版边缘，相对坐标永为 0，绝对物理同步 */
    .slides-mask-divider-line {
      position: absolute;
      pointer-events: none;
      z-index: 51;
      opacity: 0;
      transition: opacity 0.3s ease;
    }
    .slides-mask-layer--down .slides-mask-divider-line,
    .slides-mask-divider-line--down {
      top: 0;
      left: 0;
      right: 0;
      height: 2.5px;
      transform: translateY(-50%);
      background: linear-gradient(90deg, transparent 0%, var(--slide-accent, #3b82f6) 6%, var(--slide-accent, #3b82f6) 94%, transparent 100%);
      box-shadow: 0 0 10px var(--slide-accent, #3b82f6), 0 0 4px var(--slide-accent, #3b82f6);
    }
    .slides-mask-layer--right .slides-mask-divider-line,
    .slides-mask-divider-line--right {
      top: 0;
      bottom: 0;
      left: 0;
      width: 2.5px;
      transform: translateX(-50%);
      background: linear-gradient(180deg, transparent 0%, var(--slide-accent, #3b82f6) 6%, var(--slide-accent, #3b82f6) 94%, transparent 100%);
      box-shadow: 0 0 10px var(--slide-accent, #3b82f6), 0 0 4px var(--slide-accent, #3b82f6);
    }
    .slides-mask-layer--clockwise,
    .slides-mask-layer--counter-clockwise,
    .slides-mask-layer--cw,
    .slides-mask-layer--ccw,
    .slides-mask-layer--clock {
      transform: none !important;
    }
    .slides-mask-layer--clockwise .slides-mask-divider-line,
    .slides-mask-layer--counter-clockwise .slides-mask-divider-line,
    .slides-mask-layer--cw .slides-mask-divider-line,
    .slides-mask-layer--ccw .slides-mask-divider-line,
    .slides-mask-layer--clock .slides-mask-divider-line,
    .slides-mask-divider-line--clock,
    .slides-mask-divider-line--clockwise,
    .slides-mask-divider-line--counter-clockwise {
      top: 50%;
      left: 50%;
      right: auto;
      bottom: auto;
      width: 55%;
      height: 2.5px;
      transform-origin: 0% 50%;
      transform: translateY(-50%) rotate(-180deg);
      background: linear-gradient(90deg, var(--slide-accent, #3b82f6) 0%, var(--slide-accent, #3b82f6) 75%, transparent 100%);
      box-shadow: 0 0 10px var(--slide-accent, #3b82f6), 0 0 4px var(--slide-accent, #3b82f6);
      transition: transform 0.42s cubic-bezier(0.2, 0, 0, 1), opacity 0.3s ease;
      will-change: transform, opacity;
    }
    .slides-mask-layer--counter-clockwise .slides-mask-divider-line,
    .slides-mask-divider-line--counter-clockwise {
      transform: translateY(-50%) rotate(-90deg);
    }`}function tg(){return`    (function() {
      const data = window.__SLIDES_DATA__ || { slides: [] };
      const slides = data.slides || [];
      let currentIndex = 0;

      const container = document.getElementById("slide-container");
      const pageNum = document.getElementById("page-num");
      const btnPrev = document.getElementById("btn-prev");
      const btnNext = document.getElementById("btn-next");
      const btnFullscreen = document.getElementById("btn-fullscreen");

      // 「数字+回车」跳页输入角标：右下角悬浮显示，独立于缩放视口
      const jumpBadge = document.createElement("div");
      jumpBadge.className = "jump-page-indicator";
      jumpBadge.style.display = "none";
      document.body.appendChild(jumpBadge);
      const jumpStyle = document.createElement("style");
      jumpStyle.textContent = ".jump-page-indicator{position:fixed;right:16px;bottom:16px;z-index:1000;min-width:40px;padding:4px 12px;border-radius:18px;background:rgba(24,24,27,0.8);backdrop-filter:blur(12px);-webkit-backdrop-filter:blur(12px);border:1px solid rgba(255,255,255,0.12);color:#f4f4f5;font-size:14px;font-variant-numeric:tabular-nums;text-align:center;pointer-events:none;box-shadow:0 4px 16px rgba(0,0,0,0.35);}.jump-page-indicator.is-invalid{background:rgba(153,27,27,0.85);border-color:rgba(248,113,113,0.5);color:#fecaca;animation:jump-indicator-shake 0.4s ease;}@keyframes jump-indicator-shake{0%,100%{transform:translateX(0);}25%{transform:translateX(-4px);}50%{transform:translateX(4px);}75%{transform:translateX(-2px);}}";
      document.head.appendChild(jumpStyle);

`}function ig(){return`      // ========= 缩略图总览层（o 键呼出，方向键/数字+回车/点选跳页） =========
      const OVERVIEW_CARD_W = 236;
      let overviewOpen = false;
      let overviewFocus = 1;
      let overviewBuilt = false;
      let overviewObserver = null;
      const overviewOverlay = document.createElement("div");
      overviewOverlay.className = "slides-overview";
      overviewOverlay.style.display = "none";
      const overviewGrid = document.createElement("div");
      overviewGrid.className = "slides-overview-grid";
      const overviewHint = document.createElement("div");
      overviewHint.className = "slides-overview-hint";
      overviewHint.textContent = "← → ↑ ↓ 移动 · Enter 跳转 · 数字直达 · Esc / O 关闭";
      overviewOverlay.appendChild(overviewGrid);
      overviewOverlay.appendChild(overviewHint);
      document.body.appendChild(overviewOverlay);
      overviewOverlay.addEventListener("click", (e) => {
        if (e.target === overviewOverlay) closeOverview();
      });
      const overviewStyle = document.createElement("style");
      overviewStyle.textContent = ".slides-overview{position:fixed;inset:0;z-index:900;overflow-y:auto;background:rgba(13,16,22,0.88);backdrop-filter:blur(18px);-webkit-backdrop-filter:blur(18px);padding:36px 44px 20px;box-sizing:border-box;}.slides-overview-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(236px,1fr));gap:18px;max-width:1440px;margin:0 auto;}.slides-overview-card{cursor:pointer;border-radius:10px;border:2px solid rgba(255,255,255,0.12);background:rgba(255,255,255,0.04);overflow:hidden;transition:border-color 0.15s ease,transform 0.15s ease,box-shadow 0.15s ease;}.slides-overview-card:hover{border-color:rgba(255,255,255,0.38);transform:translateY(-2px);}.slides-overview-card.is-active{border-color:var(--slide-accent,#3b82f6);box-shadow:0 0 0 1px var(--slide-accent,#3b82f6),0 8px 24px rgba(0,0,0,0.4);}.slides-overview-canvas-box{position:relative;overflow:hidden;background:var(--slide-bg,#ffffff);}.slides-overview-canvas{position:absolute;top:0;left:0;transform-origin:top left;pointer-events:none;}.slides-overview-canvas *{scrollbar-width:none;}.slides-overview-caption{display:flex;align-items:center;gap:8px;padding:6px 10px;font-size:12px;color:rgba(255,255,255,0.72);border-top:1px solid rgba(255,255,255,0.08);background:rgba(13,16,22,0.6);}.slides-overview-page-no{flex-shrink:0;font-variant-numeric:tabular-nums;font-weight:600;color:#f4f4f5;background:rgba(255,255,255,0.16);border-radius:8px;padding:0 7px;line-height:18px;}.slides-overview-page-no.is-current{background:var(--slide-accent,#10b981);color:#0b1210;}.slides-overview-title{white-space:nowrap;overflow:hidden;text-overflow:ellipsis;user-select:none;}.slides-overview-hint{text-align:center;margin:18px 0 8px;font-size:12px;color:rgba(255,255,255,0.45);user-select:none;}";
      document.head.appendChild(overviewStyle);

      const baseWidth = 980;
      const aspectStr = (data.config && data.config.aspectRatio) || "16/9";
      let ratioNum = 16 / 9;
      if (aspectStr === "4/3") ratioNum = 4 / 3;
      else if (aspectStr === "16/10") ratioNum = 16 / 10;
      else if (typeof aspectStr === "string" && aspectStr.includes("/")) {
        const parts = aspectStr.split("/").map(Number);
        if (parts[0] && parts[1]) ratioNum = parts[0] / parts[1];
      }
      const baseHeight = Math.ceil(baseWidth / ratioNum);
      const viewport = document.getElementById("viewport");

`}function ng(){return`      function updateScale() {
        if (!viewport) return;
        const isFull = !!document.fullscreenElement;
        const padX = isFull ? 0 : 20;
        const padY = isFull ? 0 : 32;
        const availW = Math.max(100, window.innerWidth - padX);
        const availH = Math.max(100, window.innerHeight - padY);
        const scale = Math.min(availW / baseWidth, availH / baseHeight);
        viewport.style.width = baseWidth + "px";
        viewport.style.height = baseHeight + "px";
        viewport.style.transform = "translate(-50%, -50%) scale(" + scale + ")";
        viewport.style.setProperty("--slides-slide-scale", scale);
        if (isFull) document.body.classList.add("is-fullscreen");
        else document.body.classList.remove("is-fullscreen");
      }

      window.addEventListener("resize", updateScale);
      document.addEventListener("fullscreenchange", updateScale);

      function parseMaskRatio(ratioStr, defaultSteps) {
        var defSteps = (defaultSteps === 4) ? 4 : 2;
        var defBps = (defaultSteps === 4) ? [25, 50, 75, 100] : [50, 100];
        if (!ratioStr || typeof ratioStr !== "string") {
          return { steps: defSteps, breakpoints: defBps };
        }
        var clean = ratioStr.trim();
        if (!clean || (defaultSteps === 4 && (clean === "1:1" || clean === "1"))) return { steps: defSteps, breakpoints: defBps };
        var parts = clean.split(":").map(function(p) { return parseFloat(p.trim()); }).filter(function(n) { return !isNaN(n) && n > 0; });
        if (parts.length === 0) return { steps: defSteps, breakpoints: defBps };
        if (parts.length === 1) {
          var val = Math.min(100, Math.max(1, parts[0]));
          if (val === 100) return { steps: 1, breakpoints: [100] };
          return { steps: 2, breakpoints: [Math.round(val * 100) / 100, 100] };
        }
        var isMonotonic = parts.every(function(val, idx) { return idx === 0 || val > parts[idx - 1]; });
        var maxVal = parts[parts.length - 1];
        if (isMonotonic && (maxVal === 100 || parts.some(function(p) { return p > 10; }))) {
          var bps = parts.map(function(p) { return Math.min(100, Math.round(p * 100) / 100); });
          if (bps[bps.length - 1] < 100) bps.push(100);
          return { steps: bps.length, breakpoints: bps };
        }
        var totalWeight = parts.reduce(function(acc, cur) { return acc + cur; }, 0);
        if (totalWeight <= 0) return { steps: defSteps, breakpoints: defBps };
        var accumulated = 0;
        var bps = [];
        for (var i = 0; i < parts.length; i++) {
          accumulated += parts[i];
          if (i === parts.length - 1) {
            bps.push(100);
          } else {
            bps.push(Math.round((accumulated / totalWeight) * 10000) / 100);
          }
        }
        return { steps: bps.length, breakpoints: bps };
      }

      let currentMaskStep = 0;
      let currentMaskConfig = null;
      let maskLayerEl = null;
      let maskOverlayEl = null;
      let maskDividerEl = null;

      function updateMaskVisual() {
        if (!currentMaskConfig || !maskLayerEl) return;
        const p = (currentMaskStep <= 0)
          ? (currentMaskConfig.isInitialRevealed ? currentMaskConfig.breakpoints[0] : 0)
          : (currentMaskStep >= currentMaskConfig.totalSteps
              ? 100
              : currentMaskConfig.breakpoints[currentMaskConfig.isInitialRevealed ? currentMaskStep : (currentMaskStep - 1)]);

        if (currentMaskConfig.isClock) {
          const isCw = currentMaskConfig.direction === "clockwise" || currentMaskConfig.direction === "cw";
          const sweepDeg = Math.min(360, Math.max(0, (p / 100) * 360));
          const needleAngle = isCw ? (-180 + sweepDeg) : (-90 - sweepDeg);

          if (maskOverlayEl) {
            let maskGrad = "";
            if (sweepDeg <= 0) {
              maskGrad = "conic-gradient(from 0deg at 50% 50%, #000 0deg, #000 360deg)";
            } else if (sweepDeg >= 360) {
              maskGrad = "conic-gradient(from 0deg at 50% 50%, transparent 0deg, transparent 360deg)";
            } else if (isCw) {
              maskGrad = "conic-gradient(from 270deg at 50% 50%, transparent 0deg, transparent " + sweepDeg + "deg, #000 " + sweepDeg + "deg, #000 360deg)";
            } else {
              const remDeg = 360 - sweepDeg;
              maskGrad = "conic-gradient(from 0deg at 50% 50%, #000 0deg, #000 " + remDeg + "deg, transparent " + remDeg + "deg, transparent 360deg)";
            }
            maskOverlayEl.style.webkitMaskImage = maskGrad;
            maskOverlayEl.style.maskImage = maskGrad;
          }

          if (maskDividerEl) {
            maskDividerEl.style.transform = "translateY(-50%) rotate(" + needleAngle + "deg)";
            maskDividerEl.style.opacity = (p <= 0 || p >= 100) ? "0" : "1";
          }

          if (p >= 100) {
            maskLayerEl.style.opacity = "0";
            maskLayerEl.style.pointerEvents = "none";
          } else {
            maskLayerEl.style.opacity = "1";
            maskLayerEl.style.pointerEvents = "none";
          }
          return;
        }

        const isDown = currentMaskConfig.direction === "down";
        if (p >= 100) {
          maskLayerEl.style.transform = isDown ? "translate3d(0, 100%, 0)" : "translate3d(100%, 0, 0)";
          maskLayerEl.style.opacity = "0";
          maskLayerEl.style.pointerEvents = "none";
          if (maskDividerEl) maskDividerEl.style.opacity = "0";
        } else {
          maskLayerEl.style.transform = isDown ? ("translate3d(0, " + p + "%, 0)") : ("translate3d(" + p + "%, 0, 0)");
          maskLayerEl.style.opacity = "1";
          maskLayerEl.style.pointerEvents = "none";
          if (maskDividerEl) {
            maskDividerEl.style.opacity = (p <= 0) ? "0" : "1";
          }
        }
      }

      function goNext() {
        if (currentMaskConfig && currentMaskStep < currentMaskConfig.totalSteps) {
          currentMaskStep++;
          updateMaskVisual();
          return;
        }
        renderSlide(currentIndex + 1);
      }

      function goPrev() {
        if (currentMaskConfig && currentMaskStep > (currentMaskConfig.isInitialRevealed ? 1 : 0)) {
          currentMaskStep--;
          updateMaskVisual();
          return;
        }
        // FSM-9 优化：回退至上一页时传递 backward 方向，使上一页遮罩处于完全展开状态
        renderSlide(currentIndex - 1, "backward");
      }

`}function sg(){return`      function cleanCardListItemMarkdown(rawMarkdown) {
        if (!rawMarkdown) return "";
        let cleaned = rawMarkdown.replace(/^[ 	]*[-*+]s+|^[ 	]*d+.s+/, "");
        cleaned = cleaned.replace(/
[ 	]{2,4}/g, "
");
        return cleaned.trim();
      }

      function isHeadingBlock(b) {
        if (!b) return false;
        if (b.type === "h" || b.type === "NodeHeading") return true;
        if (b.subType && /^h[1-6]$/i.test(b.subType)) return true;
        const md = (b.rawMarkdown || b.content || "").trim();
        if (/^#{1,6}s+/.test(md)) return true;
        if (/^(?:[-*+]|d+.)s+#{1,6}s+/.test(md)) return true;
        return false;
      }

      function cleanColList(blocks) {
        const valid = (blocks || []).filter(b => Boolean((b.rawMarkdown || b.content || "").trim()));
        if (valid.length === 0) return valid;
        const first = valid[0];
        const md = (first.rawMarkdown || first.content || "").trim();
        const isList = /^(?:[-*+]|d+.)s+/.test(md) || first.type === "i" || first.type === "l";
        if (isList) {
          first.rawMarkdown = cleanCardListItemMarkdown(first.rawMarkdown || first.content || "");
          first.content = first.rawMarkdown;
        }
        return valid;
      }

      function renderBlock(block, extraClass) {
        const div = document.createElement("div");
        div.className = "slide-block" + (extraClass ? " " + extraClass : "");
        if (block && block.motion && block.motion.preset && block.motion.preset !== "none") {
          div.classList.add("slides-motion-" + block.motion.preset.toLowerCase());
          if (typeof block.motion.duration === "number" && block.motion.duration > 0) {
            div.style.setProperty("--motion-duration", block.motion.duration + "ms");
          }
          if (typeof block.motion.delay === "number" && block.motion.delay > 0) {
            div.style.setProperty("--motion-delay", block.motion.delay + "ms");
          }
        }
        const md = block.rawMarkdown || block.content || "";

        if (md.includes('class="slides-block-ref"') || md.includes('class="slides-ref-tag"')) {
          div.innerHTML = md;
          return div;
        }

        const CARBON_MAP = {
          'carbon:arrow-right': '<svg viewBox="0 0 32 32" width="1.2em" height="1.2em" fill="currentColor" style="display:inline-block;vertical-align:middle;"><path d="m18 6l-1.43 1.393L24.15 15H4v2h20.15l-7.58 7.573L18 26l10-10z"/></svg>',
          'carbon:arrow-left': '<svg viewBox="0 0 32 32" width="1.2em" height="1.2em" fill="currentColor" style="display:inline-block;vertical-align:middle;"><path d="m14 26l1.43-1.393L7.85 17H28v-2H7.85l7.58-7.573L14 6L4 16z"/></svg>',
          'carbon:edit': '<svg viewBox="0 0 32 32" width="1.2em" height="1.2em" fill="currentColor" style="display:inline-block;vertical-align:middle;"><path d="M2 26h28v2H2zM25.4 9c.8-.8.8-2 0-2.8l-3.6-3.6c-.8-.8-2-.8-2.8 0l-15 15V24h6.4l15-15zM20.4 4L24 7.6l-2.4 2.4l-3.6-3.6L20.4 4zM6 22v-3.6l11-11l3.6 3.6l-11 11H6z"/></svg>',
          'carbon:logo-github': '<svg viewBox="0 0 32 32" width="1.2em" height="1.2em" fill="currentColor" style="display:inline-block;vertical-align:middle;"><path fill-rule="evenodd" d="M16 2a14 14 0 0 0-4.43 27.28c.7.13 1-.3 1-.67v-2.38c-3.89.84-4.71-1.88-4.71-1.88a3.7 3.7 0 0 0-1.56-2.05c-1.27-.86.1-.85.1-.85a2.94 2.94 0 0 1 2.14 1.44a3 3 0 0 0 4.08 1.16a2.93 2.93 0 0 1 .89-1.87c-3.1-.35-6.36-1.55-6.36-6.9a5.4 5.4 0 0 1 1.44-3.75a5 5 0 0 1 .14-3.71s1.17-.38 3.85 1.43a13.3 13.3 0 0 1 7 0c2.67-1.81 3.84-1.43 3.84-1.43a5 5 0 0 1 .14 3.71a5.4 5.4 0 0 1 1.44 3.75c0 5.37-3.27 6.54-6.38 6.89a3.35 3.35 0 0 1 1.26 2.61v3.87c0 .38.26.81 1 .67A14 14 0 0 0 16 2"/></svg>'
        };

        if (/@\\w+=['"]|v-\\w+|<button|<a\\b|<carbon:|^<div/i.test(md)) {
          if (md.includes('abs-br') || md.includes('abs-bl') || md.includes('abs-tr') || md.includes('abs-tl') || md.includes('absolute')) {
            div.classList.add("slide-block--absolute");
          }
          let renderedHtml = md;
          for (const [tag, svg] of Object.entries(CARBON_MAP)) {
            const regex = new RegExp("<" + tag + "\\\\s*\\\\/?>", "gi");
            renderedHtml = renderedHtml.replace(regex, svg);
            const regexDash = new RegExp("<" + tag.replace(":", "-") + "\\\\s*\\\\/?>", "gi");
            renderedHtml = renderedHtml.replace(regexDash, svg);
          }
          div.innerHTML = renderedHtml;

          // 挂载交互事件监听
          const nextBtns = div.querySelectorAll('[\\\\@click*="nav.next"], [\\\\@click*="next"]');
          nextBtns.forEach(btn => {
            btn.style.cursor = "pointer";
            btn.addEventListener("click", (e) => {
              e.stopPropagation();
              renderSlide(currentIndex + 1);
            });
          });

          const prevBtns = div.querySelectorAll('[\\\\@click*="nav.prev"], [\\\\@click*="prev"]');
          prevBtns.forEach(btn => {
            btn.style.cursor = "pointer";
            btn.addEventListener("click", (e) => {
              e.stopPropagation();
              renderSlide(currentIndex - 1);
            });
          });

          return div;
        }

        const hasHeadingTag = /(?:^|
)s*#{1,6}s+/.test(md);
        const hMatch = md.match(/^(#{1,6})\\s+(.*)$/);

        if (hMatch) {
          const level = hMatch[1].length;
          let th = hMatch[2].trim().replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
          div.innerHTML = "<h" + level + ">" + th + "</h" + level + ">";
        }
        else if (md.startsWith("\`\`\`")) {
          const customMaxHeight = block?.attributes?.["custom-slides-max-height"] || block?.attrs?.["custom-slides-max-height"] || block?.maxHeight || "";
          const heightStyle = customMaxHeight ? ' style="max-height:' + customMaxHeight + ';overflow-y:auto;"' : "";
          div.innerHTML = "<pre" + heightStyle + "><code>" + md.slice(3, -3) + "</code></pre>";
        }
        else if (md.startsWith("> ")) div.innerHTML = "<blockquote><p>" + md.slice(2) + "</p></blockquote>";
        else if ((/<video\b/i.test(md) || (block && (block.type === "video" || block.type === "NodeVideo"))) && !/^(s*)([-*+]|d+.)s+/m.test(md) && !hasHeadingTag && !md.includes("
")) {
          div.classList.add("slide-video-container", "slide-media-container", "slide-media-block");
          const isAutoplay = block && block.attributes && block.attributes["custom-slides-autoplay"] === "true";
          const isLoop = block && block.attributes && block.attributes["custom-slides-loop"] === "true";
          const isMuted = block && block.attributes && (block.attributes["custom-slides-muted"] === "true" || isAutoplay);
          const hideControls = block && block.attributes && block.attributes["custom-slides-controls"] === "false";
          let videoHtml = md;
          if (hideControls) videoHtml = videoHtml.replace(/\bcontrols(?:="[^"]*")?/gi, "").trim();
          else if (!videoHtml.includes("controls")) videoHtml = videoHtml.replace("<video", "<video controls");
          if (isAutoplay && !videoHtml.includes("autoplay")) videoHtml = videoHtml.replace("<video", "<video autoplay playsinline");
          if (isLoop && !videoHtml.includes("loop")) videoHtml = videoHtml.replace("<video", "<video loop");
          if (isMuted && !videoHtml.includes("muted")) videoHtml = videoHtml.replace("<video", "<video muted");
          videoHtml = videoHtml.replace("<video", '<video class="slide-video-player"');
          div.setAttribute("data-autoplay", isAutoplay ? "true" : "false");
          div.innerHTML = videoHtml;
        }
        else if (
          /^(s*)([-*+]|d+.)s+/m.test(md) ||
          (md.includes("
") && /^(s*)([-*+]|d+.)s+/m.test(md.split("
").slice(1).join("
"))) ||
          ((block && (block.isListItem || block.type === "i")) && !block.isColFirst)
        ) {
          div.classList.add("pdf-list-item");
          const lines = md.split("
");
          let isOrdered = false;
          const items = [];
          const leadLines = [];
          for (let i = 0; i < lines.length; i++) {
            const line = lines[i];
            const tr = line.trim();
            if (!tr || /^{:.*?}$/.test(tr)) continue;
            const um = line.match(/^(s*)[-*+]s+(.*)$/);
            const om = line.match(/^(s*)d+.s+(.*)$/);
            if (um) {
              const indent = um[1].length;
              items.push({ type: "unordered", level: Math.floor(indent / 2), text: um[2], media: [] });
              continue;
            }
            if (om) {
              if (items.length === 0) isOrdered = true;
              const indent = om[1].length;
              items.push({ type: "ordered", level: Math.floor(indent / 2), text: om[2], media: [] });
              continue;
            }
            if (items.length > 0) {
              const im = tr.match(/^![(.*?)]((.*?))(?:{:?[^}]*})?$/);
              if (im) {
                const isGif = /.gif(?:?|$)/i.test(im[2]);
                items[items.length - 1].media.push('<div class="slide-list-media"><img alt="' + im[1] + '" src="' + im[2] + '" class="' + (isGif ? 'list-item-gif' : 'list-item-img') + '" /></div>');
                continue;
              }
              const hm = tr.match(/^<img\b[sS]*?/?>$/i);
              if (hm) {
                const cleanTr = tr.replace(/s+style="[^"]*"/gi, "");
                items[items.length - 1].media.push('<div class="slide-list-media">' + cleanTr + '</div>');
                continue;
              }
              if (/<video\b/i.test(tr)) {
                let vHtml = tr;
                if (!/</video>/i.test(vHtml)) {
                  while (i + 1 < lines.length && !/</video>/i.test(vHtml)) {
                    i++;
                    vHtml += " " + lines[i].trim();
                  }
                }
                const isAutoplay = block && block.attributes && block.attributes["custom-slides-autoplay"] === "true";
                const isLoop = block && block.attributes && block.attributes["custom-slides-loop"] === "true";
                const isMuted = block && block.attributes && (block.attributes["custom-slides-muted"] === "true" || isAutoplay);
                const hideControls = block && block.attributes && block.attributes["custom-slides-controls"] === "false";
                if (hideControls) vHtml = vHtml.replace(/\bcontrols(?:="[^"]*")?/gi, "").trim();
                else if (!vHtml.includes("controls")) vHtml = vHtml.replace("<video", "<video controls");
                if (isAutoplay && !vHtml.includes("autoplay")) vHtml = vHtml.replace("<video", "<video autoplay playsinline");
                if (isLoop && !vHtml.includes("loop")) vHtml = vHtml.replace("<video", "<video loop");
                if (isMuted && !vHtml.includes("muted")) vHtml = vHtml.replace("<video", "<video muted");
                vHtml = vHtml.replace("<video", '<video class="slide-video-player"');
                items[items.length - 1].media.push('<div class="slide-list-media slide-video-container slide-media-container" data-autoplay="' + (isAutoplay ? 'true' : 'false') + '">' + vHtml + '</div>');
                continue;
              }
              items[items.length - 1].text += "
" + tr;
            } else {
              leadLines.push(tr);
            }
          }

          if (items.length === 0 && (block && (block.isListItem || block.type === "i")) && !block.isColFirst) {
            items.push({ type: "unordered", level: 0, text: md, media: [] });
            leadLines.length = 0;
          }

          let leadHtml = "";
          if (leadLines.length > 0) {
            const lParts = [];
            const firstL = leadLines[0];
            const fhm = firstL.match(/^(#{1,6})s+(.*)$/);
            if (fhm) {
              const lvl = fhm[1].length;
              let th = fhm[2].trim().replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
              lParts.push('<h' + lvl + ' class="slide-list-item-title">' + th + '</h' + lvl + '>');
            } else {
              let th = firstL.trim().replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
              lParts.push('<p class="slide-list-item-title">' + th + '</p>');
            }
            if (leadLines.length > 1) {
              const dLines = leadLines.slice(1);
              let pL = [];
              const flushLeadP = () => {
                if (pL.length > 0) {
                  let txt = pL.map(l => l.replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>")).join("<br/>");
                  lParts.push('<p class="slide-list-item-desc">' + txt + '</p>');
                  pL = [];
                }
              };
              for (const l of dLines) {
                const hm = l.match(/^(#{1,6})s+(.*)$/);
                if (hm) {
                  flushLeadP();
                  const lvl = hm[1].length;
                  let th = hm[2].trim().replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
                  lParts.push('<h' + lvl + ' class="slide-list-item-title">' + th + '</h' + lvl + '>');
                } else {
                  pL.push(l);
                }
              }
              flushLeadP();
            }
            leadHtml = lParts.join("
") + "
";
          }

          const tag = isOrdered ? "ol" : "ul";
          const listCls = isOrdered ? "pdf-list pdf-list--ordered" : "pdf-list pdf-list--unordered";
          const liHtml = items.map(it => {
            const med = it.media && it.media.length ? "
" + it.media.join("
") : "";
            const lines = (it.text || "").split("
").map(l => l.trim()).filter(Boolean);
            const hasHeading = lines.some(l => /^#{1,6}s+/.test(l));
            const lvl = it.level || 0;
            const nStyle = lvl > 0 ? ' style="margin-left:' + (lvl * 1.25).toFixed(2) + 'em;' + (it.type === 'unordered' ? 'list-style-type:' + (lvl % 2 === 1 ? 'circle' : 'square') + ' !important;' : '') + '"' : "";
            const nClass = lvl > 0 ? " slide-list-item--nested" : "";
            const clsAttr = nClass ? ' class="' + nClass.trim() + '"' : "";
            if (!hasHeading) {
              let h = lines.map(l => l.replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>")).join("<br/>");
              return '<li' + clsAttr + nStyle + '>' + h + med + '</li>';
            }
            const parts = [];
            let pLines = [];
            const flushP = () => {
              if (pLines.length > 0) {
                let ph = pLines.map(l => l.replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>")).join("<br/>");
                parts.push('<p class="slide-list-item-desc">' + ph + '</p>');
                pLines = [];
              }
            };
            for (const l of lines) {
              const hm = l.match(/^(#{1,6})s+(.*)$/);
              if (hm) {
                flushP();
                const hl = hm[1].length;
                let th = hm[2].trim().replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
                parts.push('<h' + hl + ' class="slide-list-item-title">' + th + '</h' + hl + '>');
              } else {
                pLines.push(l);
              }
            }
            flushP();
            return '<li' + clsAttr + nStyle + '>' + parts.join("
") + med + '</li>';
          }).join("
");
          div.innerHTML = leadHtml + "<" + tag + " class="" + listCls + "">
" + liHtml + "
</" + tag + ">";
        }
        else {
          // 复合块（包含换行、标题或媒体）高保真解析
          const lines = md.split(/\r?
/);
          const subBlocks = [];
          let current = [];
          for (let i = 0; i < lines.length; i++) {
            const line = lines[i];
            const trimmed = line.trim();
            if (/^#{1,6}s+/.test(trimmed)) {
              if (current.length > 0) { subBlocks.push(current.join("
")); current = []; }
              subBlocks.push(trimmed);
              continue;
            }
            if (!trimmed) {
              if (current.length > 0) { subBlocks.push(current.join("
")); current = []; }
              continue;
            }
            if (/^![.*?](.*?)$/.test(trimmed)) {
              if (current.length > 0) { subBlocks.push(current.join("
")); current = []; }
              subBlocks.push(trimmed);
              continue;
            }
            if (/<video\b/i.test(trimmed)) {
              if (current.length > 0) { subBlocks.push(current.join("
")); current = []; }
              let vRaw = trimmed;
              if (!/</video>/i.test(vRaw)) {
                while (i + 1 < lines.length && !/</video>/i.test(vRaw)) {
                  i++;
                  vRaw += "
" + lines[i];
                }
              }
              subBlocks.push(vRaw);
              continue;
            }
            current.push(line);
          }
          if (current.length > 0) subBlocks.push(current.join("
"));

          if (subBlocks.length > 1 || (subBlocks.length === 1 && /^#{1,6}s+/.test(subBlocks[0].trim()))) {
            let isFirstParagraph = true;
            const htmlParts = subBlocks.map(sub => {
              const t = sub.trim();
              if (!t) return "";
              const hm = t.match(/^(#{1,6})s+(.*)$/);
              if (hm) {
                isFirstParagraph = false;
                const hl = hm[1].length;
                let th = hm[2].trim().replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
                return '<h' + hl + ' class="slide-list-item-title">' + th + '</h' + hl + '>';
              }
              const im = t.match(/^![(.*?)]((.*?))$/);
              if (im) {
                return '<div class="slide-media-block slide-media-container slide-list-media"><img alt="' + im[1] + '" src="' + im[2] + '" class="slide-media-img" /></div>';
              }
              if (/<video\b/i.test(t)) {
                return '<div class="slide-media-block slide-video-container slide-media-container">' + t + '</div>';
              }
              if (isFirstParagraph) {
                isFirstParagraph = false;
                const subLines = t.split(/\r?
/).map(l => l.trim()).filter(Boolean);
                if (subLines.length === 1) {
                  let ph = subLines[0].replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
                  return '<p class="slide-list-item-title">' + ph + '</p>';
                }
                let titleHtml = subLines[0].replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
                let descHtml = subLines.slice(1).map(l => l.replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>")).join("<br/>");
                return '<p class="slide-list-item-title">' + titleHtml + '</p>
<p class="slide-list-item-desc">' + descHtml + '</p>';
              }
              let ph = t.replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
              return '<p class="slide-list-item-desc">' + ph + '</p>';
            }).filter(Boolean);
            div.innerHTML = htmlParts.join("
");
          } else {
            const imgMatch = md.match(/!\\[(.*?)\\]\\((.*?)\\)/);
            if (imgMatch) {
              div.classList.add("slide-media-container", "slide-media-block", "slide-block--image");
              div.innerHTML = '<img alt="' + imgMatch[1] + '" src="' + imgMatch[2] + '" class="slide-media-img" />';
            } else {
              let html = md.replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
              const pCls = (block && block.isColFirst) ? ' class="slide-list-item-title"' : '';
              div.innerHTML = "<p" + pCls + ">" + html + "</p>";
            }
          }
        }
        return div;
      }

`}function og(){return`      function renderSlide(idx, direction) {
        if (slides.length === 0) return;
        currentIndex = Math.max(0, Math.min(idx, slides.length - 1));
        const slide = slides[currentIndex];
        pageNum.textContent = (currentIndex + 1) + " / " + slides.length;

        const pageSp = slide.frontmatter?.spacing;
        const currentSpacing = (pageSp && pageSp !== "inherit") ? pageSp : (data.config?.spacing || "normal");
        container.className = "slide-content layout-" + (slide.frontmatter?.layout || "default") + " spacing-" + currentSpacing;
        if (viewport) viewport.setAttribute("data-spacing", currentSpacing);
        container.innerHTML = "";

        const z = typeof slide.frontmatter?.zoom === "number" && slide.frontmatter.zoom > 0 ? slide.frontmatter.zoom : 1;
        if (z !== 1) {
          container.style.width = (100 / z) + "%";
          container.style.height = (100 / z) + "%";
          container.style.transformOrigin = "top left";
          container.style.transform = "scale(" + z + ")";
        } else {
          container.style.width = "100%";
          container.style.height = "100%";
          container.style.transform = "none";
        }

        const slideBg = slide.frontmatter?.background || (data.config && data.config.background);
        if (slideBg) {
          if (/^(http|\\/|data:|assets\\/)/.test(slideBg)) {
            container.style.backgroundImage = 'url("' + slideBg + '")';
            container.style.backgroundSize = "cover";
            container.style.backgroundPosition = "center";
          } else {
            container.style.backgroundImage = "none";
            container.style.background = slideBg;
          }
        } else {
          container.style.backgroundImage = "none";
          container.style.background = "";
        }

        maskOverlayEl = null;
        maskDividerEl = null;
        const maskDir = slide.frontmatter?.mask;
        const isClock = maskDir === "clockwise" || maskDir === "counter-clockwise" || maskDir === "cw" || maskDir === "ccw";
        if (maskDir === "down" || maskDir === "right" || isClock) {
          const isClover = slide.frontmatter?.layout === "clover";
          const ratioInfo = parseMaskRatio(slide.frontmatter.maskRatio, (isClock || isClover) ? 4 : 2);
          const isInitRev = slide.frontmatter.maskInitial === "revealed";
          currentMaskConfig = {
            direction: isClock ? ((maskDir === "cw" || maskDir === "clockwise") ? "clockwise" : "counter-clockwise") : maskDir,
            isClock: isClock,
            totalSteps: isInitRev ? Math.max(0, ratioInfo.steps - 1) : ratioInfo.steps,
            rawSteps: ratioInfo.steps,
            breakpoints: ratioInfo.breakpoints,
            isInitialRevealed: isInitRev,
            style: slide.frontmatter.maskStyle || "solid",
          };
          // FSM-9 优化：后退进入历史页时，遮罩与逐步呈现处于全部揭开完成状态，避免上一页重新变为全黑遮盖
          currentMaskStep = (direction === "backward") ? currentMaskConfig.totalSteps : 0;
        } else {
          currentMaskConfig = null;
          currentMaskStep = 0;
        }

        function createMaskElements() {
          if (!currentMaskConfig) return null;
          const layer = document.createElement("div");
          layer.className = "slides-mask-layer slides-mask-layer--" + currentMaskConfig.style + " slides-mask-layer--" + currentMaskConfig.direction + (currentMaskConfig.isClock ? " slides-mask-layer--clock" : "");
          const overlay = document.createElement("div");
          overlay.className = "slides-mask-overlay";
          const divider = document.createElement("div");
          divider.className = "slides-mask-divider-line" + (currentMaskConfig.isClock ? " slides-mask-divider-line--clock" : "");
          divider.style.opacity = "0";
          if (currentMaskConfig.isClock) {
            const isCw = currentMaskConfig.direction === "clockwise" || currentMaskConfig.direction === "cw";
            divider.style.transform = isCw ? "translateY(-50%) rotate(-180deg)" : "translateY(-50%) rotate(-90deg)";
          }
          layer.appendChild(overlay);
          layer.appendChild(divider);
          maskLayerEl = layer;
          maskOverlayEl = overlay;
          maskDividerEl = divider;
          return { layer, overlay, divider };
        }

        if (slide.frontmatter?.layout === "two-cols") {
          const bodyWrap = document.createElement("div");
          bodyWrap.className = "slides-mask-body-container" + (currentMaskConfig ? " slides-mask-body-container--has-mask" : "");
          bodyWrap.style.display = "flex";
          bodyWrap.style.flexDirection = "row";
          bodyWrap.style.gap = "2rem";
          bodyWrap.style.width = "100%";
          bodyWrap.style.height = "100%";

          const leftCol = document.createElement("div");
          leftCol.className = "two-cols-left";
          const rightCol = document.createElement("div");
          rightCol.className = "two-cols-right";

          const blocks = (slide.blocks || []).filter(b => b.slot !== "slot-divider-right");
          let leftList = [];
          let rightList = [];
          for (const block of blocks) {
            if (block.slot === "right") rightList.push(block);
            else leftList.push(block);
          }
          leftList = cleanColList(leftList);
          rightList = cleanColList(rightList);
          const isCover = slide.frontmatter?.layout === "cover";
          const leftFirstH = !isCover ? leftList.find(isHeadingBlock) : null;
          const rightFirstH = !isCover ? rightList.find(isHeadingBlock) : null;
          for (const b of leftList) leftCol.appendChild(renderBlock(b, b === leftFirstH ? "slides-col-first-heading-block" : ""));
          for (const b of rightList) rightCol.appendChild(renderBlock(b, b === rightFirstH ? "slides-col-first-heading-block" : ""));
          bodyWrap.appendChild(leftCol);
          bodyWrap.appendChild(rightCol);

          const maskEls = createMaskElements();
          if (maskEls) {
            bodyWrap.appendChild(maskEls.layer);
          }
          container.appendChild(bodyWrap);
        } else if (slide.frontmatter?.layout === "cols-header" || slide.frontmatter?.layout === "two-cols-header" || slide.frontmatter?.layout === "three-cols-header" || slide.frontmatter?.layout === "clover") {
          const isCover = slide.frontmatter?.layout === "cover";
          const isClover = slide.frontmatter?.layout === "clover";
          const blocks = (slide.blocks || []).filter(b => b.slot !== "slot-divider-right");
          let headerBlocks = blocks.filter(b => b.slot === "header");
          if (headerBlocks.length === 0 && blocks.length > 0) {
            const candidate = blocks.find(b => b.type === "h" && (!b.slot || b.slot === "default"));
            if (candidate) headerBlocks = [candidate];
          }
          const rem = blocks.filter(b => !headerBlocks.includes(b));

          let targetCols = isClover ? 4 : 2;
          if (isClover) {
            targetCols = 4;
          } else if (slide.frontmatter?.layout === "three-cols-header") {
            targetCols = 3;
          } else if (slide.frontmatter?.layout === "two-cols-header") {
            targetCols = 2;
          } else {
            let maxCol = 0;
            for (const b of rem) {
              const m = (b.slot || "").match(/^col-(d+)$/i);
              if (m) maxCol = Math.max(maxCol, parseInt(m[1], 10));
            }
            if (maxCol >= 2) {
              targetCols = maxCol;
            } else if (slide.frontmatter?.layoutRatio) {
              const r = slide.frontmatter.layoutRatio.trim();
              if (r.includes(":")) {
                const parts = r.split(":").map(p => parseFloat(p.trim())).filter(n => !isNaN(n) && n > 0);
                if (parts.length >= 2) targetCols = parts.length;
              }
            }
          }

          const hasColSlots = rem.some(b => b.slot && /^col-d+$/i.test(b.slot));
          const isSuperBlockCols = isClover || hasColSlots;

          const containerDiv = document.createElement("div");
          containerDiv.className = (isClover ? "layout-clover-container" : ("layout-cols-header-container " + (targetCols === 2 ? "layout-two-cols-header-container" : (targetCols === 3 ? "layout-three-cols-header-container" : "")))) + (isSuperBlockCols ? " has-superblock-cols" : "");
          const headerDiv = document.createElement("div");
          headerDiv.className = "layout-header-section";
          const gridDiv = document.createElement("div");
          gridDiv.className = (isClover ? "layout-clover-grid pdf-clover-wrapper" : ("layout-cols-wrapper layout-cols-grid " + (targetCols === 2 ? "pdf-two-cols-wrapper layout-two-cols-grid" : (targetCols === 3 ? "pdf-three-cols-wrapper layout-three-cols-grid" : "")))) + (isSuperBlockCols ? " has-superblock-cols" : "") + (currentMaskConfig ? " slides-mask-body-container slides-mask-body-container--has-mask" : "");

          const gridCols = isClover ? "repeat(2, minmax(0, 1fr))" : parseRatioToGridCols(slide.frontmatter?.layoutRatio, targetCols);
          if (gridCols) gridDiv.style.gridTemplateColumns = gridCols;
          if (isClover) gridDiv.style.gridTemplateRows = "repeat(2, minmax(0, 1fr))";

          let colsList = [];
          for (let i = 0; i < targetCols; i++) colsList.push([]);
          const hasExplicitCols = rem.some(b => b.slot && (b.slot.startsWith("col-") || b.slot === "left" || b.slot === "right" || b.slot === "center"));
          if (hasExplicitCols && rem.length > 1) {
            for (const b of rem) {
              let idx = 0;
              if (b.slot === "left" || b.slot === "col-1") idx = 0;
              else if (b.slot === "center" || b.slot === "col-2") idx = 1;
              else if (b.slot === "right") idx = targetCols === 2 ? 1 : targetCols - 1;
              else {
                const m = (b.slot || "").match(/^col-(d+)$/i);
                if (m) idx = Math.min(targetCols - 1, Math.max(0, parseInt(m[1], 10) - 1));
              }
              colsList[idx].push(b);
            }
            const hasExplicitColN = rem.some(b => /^col-d+$/i.test((b.slot || "").trim()));
            if (!hasExplicitColN && colsList[0].length === 0) {
              const nonEmptyCols = colsList.filter(c => c.length > 0);
              if (nonEmptyCols.length === 1) {
                colsList = [nonEmptyCols[0], ...Array.from({ length: targetCols - 1 }, () => [])];
              }
            }
          } else if (rem.length === 1) {
            colsList[0] = [rem[0]];
          } else {
            let cur = 0;
            for (let i = 0; i < targetCols; i++) {
              const remainingCols = targetCols - i;
              const remainingItems = rem.length - cur;
              const take = Math.ceil(remainingItems / remainingCols);
              colsList[i] = rem.slice(cur, cur + take);
              cur += take;
            }
          }

          const headerFirstH = !isCover ? headerBlocks.find(isHeadingBlock) : null;
          for (const b of headerBlocks) headerDiv.appendChild(renderBlock(b, b === headerFirstH ? "slides-page-first-heading-block" : ""));
          containerDiv.appendChild(headerDiv);

          colsList.forEach((colBlocks, idx) => {
            const colDiv = document.createElement("div");
            colDiv.className = "pdf-col pdf-col--" + (idx + 1) + " col-" + (idx + 1) + (targetCols === 2 && idx === 0 ? " pdf-col--left" : "") + (targetCols === 2 && idx === 1 ? " pdf-col--right" : "");
            const cleaned = cleanColList(colBlocks);
            const colFirstH = !isCover ? (cleaned.find(isHeadingBlock) || cleaned[0]) : null;
            for (const b of cleaned) colDiv.appendChild(renderBlock(b, b === colFirstH ? "slides-col-first-heading-block" : ""));
            gridDiv.appendChild(colDiv);
          });

          const maskEls = createMaskElements();
          if (maskEls) {
            gridDiv.appendChild(maskEls.layer);
          }

          containerDiv.appendChild(gridDiv);
          container.appendChild(containerDiv);
        } else if (slide.frontmatter?.layout === "image-right" || slide.frontmatter?.layout === "image-left") {
          const isImageRight = slide.frontmatter?.layout === "image-right";
          const isCover = slide.frontmatter?.layout === "cover";
          const allBlocks = slide.blocks || [];
          const pageFirstH = !isCover ? allBlocks.find(isHeadingBlock) : null;

          if (pageFirstH) {
            container.appendChild(renderBlock(pageFirstH, "slides-page-first-heading-block"));
          }

          const bodyWrap = document.createElement("div");
          bodyWrap.className = "slides-mask-body-container" + (currentMaskConfig ? " slides-mask-body-container--has-mask" : "");
          bodyWrap.style.display = "flex";
          bodyWrap.style.flexDirection = isImageRight ? "row" : "row-reverse";
          bodyWrap.style.gap = "2rem";
          bodyWrap.style.width = "100%";
          bodyWrap.style.height = "100%";
          bodyWrap.style.minHeight = "0";
          bodyWrap.style.flex = "1";

          const contentCol = document.createElement("div");
          contentCol.className = isImageRight ? "image-right-content" : "image-left-content";

          for (const block of allBlocks) {
            if (block === pageFirstH) continue;
            contentCol.appendChild(renderBlock(block, ""));
          }

          const imgCol = document.createElement("div");
          imgCol.className = isImageRight ? "image-right-img-container" : "image-left-img-container";
          const img = document.createElement("img");
          img.className = isImageRight ? "image-right-img" : "image-left-img";
          img.src = slide.frontmatter?.image || slide.frontmatter?.background || "";
          img.alt = "Slide cover";
          img.onerror = function() {
            this.src = "https://fastly.jsdelivr.net/gh/slidevjs/slidev-covers@main/static/2HmfbSpvcos.webp";
          };
          imgCol.appendChild(img);

          bodyWrap.appendChild(contentCol);
          bodyWrap.appendChild(imgCol);

          const maskEls = createMaskElements();
          if (maskEls) {
            bodyWrap.appendChild(maskEls.layer);
          }
          container.appendChild(bodyWrap);
        } else {
          const isCover = slide.frontmatter?.layout === "cover";
          const validBlocks = (slide.blocks || []).filter(b => b.slot !== "slot-divider-right");
          const pageFirstH = !isCover ? validBlocks.find(isHeadingBlock) : null;

          if (pageFirstH) {
            container.appendChild(renderBlock(pageFirstH, "slides-page-first-heading-block"));
          }

          const bodyWrap = document.createElement("div");
          bodyWrap.className = "slides-mask-body-container" + (currentMaskConfig ? " slides-mask-body-container--has-mask" : "");

          for (const block of validBlocks) {
            if (block === pageFirstH) continue;
            bodyWrap.appendChild(renderBlock(block, ""));
          }

          const maskEls = createMaskElements();
          if (maskEls) {
            bodyWrap.appendChild(maskEls.layer);
          }
          container.appendChild(bodyWrap);
        }

        updateMaskVisual();
        if (currentMaskConfig && maskLayerEl) {
          requestAnimationFrame(() => {
            if (maskLayerEl) void maskLayerEl.offsetHeight;
          });
        }

        function syncAutoplayVideos() {
          const doSync = () => {
            const videos = container.querySelectorAll("video");
            videos.forEach((v) => {
              const box = v.closest("[data-autoplay]");
              const isAuto = v.hasAttribute("autoplay") || v.autoplay || (box && box.getAttribute("data-autoplay") === "true");
              if (isAuto) {
                v.muted = true;
                v.defaultMuted = true;
                v.setAttribute("muted", "");
                v.playsInline = true;
                v.setAttribute("playsinline", "");
                const playFn = () => {
                  if (!v.paused) return;
                  v.muted = true;
                  v.defaultMuted = true;
                  const p = v.play();
                  if (p !== undefined) {
                    p.catch(() => {
                      v.muted = true;
                      v.defaultMuted = true;
                      setTimeout(() => { if (v.paused) v.play().catch(() => {}); }, 150);
                    });
                  }
                };
                playFn();
                if (!v.__autoplayBound) {
                  v.__autoplayBound = true;
                  v.addEventListener("loadedmetadata", playFn);
                  v.addEventListener("canplay", playFn);
                }
              }
            });
          };
          setTimeout(doSync, 60);
          setTimeout(doSync, 200);
        }
        syncAutoplayVideos();
      }

      // Lightbox 控制逻辑
      const lightbox = document.getElementById("slides-lightbox");
      const lightboxContent = document.getElementById("lightbox-content");
      const lightboxClose = document.getElementById("lightbox-close");
      let isLightboxOpen = false;

`}function rg(){return`      let lightboxScale = 1.0;
      let lightboxTranslateX = 0;
      let lightboxTranslateY = 0;
      let isLightboxDragging = false;
      let lightboxDragStartX = 0;
      let lightboxDragStartY = 0;
      let lightboxInitialTx = 0;
      let lightboxInitialTy = 0;
      let lightboxHasMoved = false;
      let lightboxMediaType = "";

      function updateLightboxImgTransform(animate) {
        if (!lightboxContent) return;
        const img = lightboxContent.querySelector(".slides-lightbox-img");
        if (!img) return;
        img.style.transformOrigin = "center center";
        img.style.transform = "translate(" + lightboxTranslateX + "px, " + lightboxTranslateY + "px) scale(" + lightboxScale + ")";
        img.style.transition = animate ? "transform 0.12s cubic-bezier(0.16, 1, 0.3, 1)" : "none";
        img.style.cursor = lightboxScale > 1.0 ? (isLightboxDragging ? "grabbing" : "grab") : "zoom-in";
      }

      function resetLightboxZoom() {
        lightboxScale = 1.0;
        lightboxTranslateX = 0;
        lightboxTranslateY = 0;
        isLightboxDragging = false;
        lightboxHasMoved = false;
        updateLightboxImgTransform(false);
      }

      function openLightbox(type, src, alt) {
        if (!lightbox || !lightboxContent) return;
        lightboxContent.innerHTML = "";
        lightboxMediaType = type;
        resetLightboxZoom();
        if (type === "video") {
          const v = document.createElement("video");
          v.className = "slides-lightbox-video";
          v.src = src;
          v.controls = true;
          v.autoplay = true;
          v.playsInline = true;
          lightboxContent.appendChild(v);
        } else {
          const img = document.createElement("img");
          img.className = "slides-lightbox-img";
          img.src = src;
          img.alt = alt || "";
          lightboxContent.appendChild(img);
          updateLightboxImgTransform(false);
        }
        lightbox.classList.add("active");
        isLightboxOpen = true;
      }

      function closeLightbox() {
        if (!lightbox) return;
        const v = lightbox.querySelector("video");
        if (v) v.pause();
        lightbox.classList.remove("active");
        if (lightboxContent) lightboxContent.innerHTML = "";
        isLightboxOpen = false;
        lightboxMediaType = "";
        resetLightboxZoom();
      }

      function handleLightboxWheel(e) {
        if (!lightboxContent || lightboxMediaType !== "image") return;
        const img = lightboxContent.querySelector(".slides-lightbox-img");
        if (!img) return;
        e.preventDefault();
        e.stopPropagation();
        if (Math.abs(e.deltaY) < 1) return;

        const factor = e.deltaY < 0 ? 1.2 : 1 / 1.2;
        const currentScale = lightboxScale;
        let nextScale = currentScale * factor;

        if (nextScale <= 1.02) {
          resetLightboxZoom();
          return;
        }
        if (nextScale > 5.0) {
          nextScale = 5.0;
        }

        const rect = img.getBoundingClientRect();
        const currentCenterX = rect.left + rect.width / 2;
        const currentCenterY = rect.top + rect.height / 2;
        const origCenterX = currentCenterX - lightboxTranslateX;
        const origCenterY = currentCenterY - lightboxTranslateY;

        const nextTx = (e.clientX - origCenterX) * (1 - nextScale / currentScale) + lightboxTranslateX * (nextScale / currentScale);
        const nextTy = (e.clientY - origCenterY) * (1 - nextScale / currentScale) + lightboxTranslateY * (nextScale / currentScale);

        lightboxTranslateX = Math.round(nextTx * 10) / 10;
        lightboxTranslateY = Math.round(nextTy * 10) / 10;
        lightboxScale = Math.round(nextScale * 1000) / 1000;
        updateLightboxImgTransform(true);
      }

      if (lightboxContent) {
        lightboxContent.addEventListener("pointerdown", (e) => {
          if (e.button !== 0 || lightboxMediaType !== "image" || lightboxScale <= 1.0) return;
          const img = lightboxContent.querySelector(".slides-lightbox-img");
          if (!img || (e.target !== img && !img.contains(e.target))) return;
          e.preventDefault();
          e.stopPropagation();
          isLightboxDragging = true;
          lightboxDragStartX = e.clientX;
          lightboxDragStartY = e.clientY;
          lightboxInitialTx = lightboxTranslateX;
          lightboxInitialTy = lightboxTranslateY;
          lightboxHasMoved = false;
          if (img.setPointerCapture) {
            try { img.setPointerCapture(e.pointerId); } catch (_) {}
          }
          updateLightboxImgTransform(false);
        });

        window.addEventListener("pointermove", (e) => {
          if (!isLightboxDragging || lightboxMediaType !== "image") return;
          e.preventDefault();
          e.stopPropagation();
          const dx = e.clientX - lightboxDragStartX;
          const dy = e.clientY - lightboxDragStartY;
          if (Math.abs(dx) > 3 || Math.abs(dy) > 3) {
            lightboxHasMoved = true;
          }
          lightboxTranslateX = Math.round((lightboxInitialTx + dx) * 10) / 10;
          lightboxTranslateY = Math.round((lightboxInitialTy + dy) * 10) / 10;
          updateLightboxImgTransform(false);
        });

        const onLightboxPointerEnd = (e) => {
          if (!isLightboxDragging) return;
          isLightboxDragging = false;
          const img = lightboxContent ? lightboxContent.querySelector(".slides-lightbox-img") : null;
          if (img && img.releasePointerCapture) {
            try { img.releasePointerCapture(e.pointerId); } catch (_) {}
          }
          updateLightboxImgTransform(false);
        };
        window.addEventListener("pointerup", onLightboxPointerEnd);
        window.addEventListener("pointercancel", onLightboxPointerEnd);

        lightboxContent.addEventListener("dblclick", (e) => {
          if (lightboxMediaType !== "image") return;
          const img = lightboxContent.querySelector(".slides-lightbox-img");
          if (!img || (e.target !== img && !img.contains(e.target))) return;
          e.preventDefault();
          e.stopPropagation();
          if (lightboxScale > 1.05 || lightboxTranslateX !== 0 || lightboxTranslateY !== 0) {
            resetLightboxZoom();
          } else {
            const targetScale = 2.0;
            const rect = img.getBoundingClientRect();
            const currentCenterX = rect.left + rect.width / 2;
            const currentCenterY = rect.top + rect.height / 2;
            const origCenterX = currentCenterX - lightboxTranslateX;
            const origCenterY = currentCenterY - lightboxTranslateY;
            lightboxTranslateX = Math.round(((e.clientX - origCenterX) * (1 - targetScale / 1.0)) * 10) / 10;
            lightboxTranslateY = Math.round(((e.clientY - origCenterY) * (1 - targetScale / 1.0)) * 10) / 10;
            lightboxScale = targetScale;
            updateLightboxImgTransform(true);
          }
        });
      }

      if (lightboxClose) {
        lightboxClose.addEventListener("click", (e) => {
          e.stopPropagation();
          closeLightbox();
        });
      }
      if (lightbox) {
        lightbox.addEventListener("click", (e) => {
          if (e.target === lightbox || e.target === lightboxClose) {
            if (lightboxHasMoved) {
              lightboxHasMoved = false;
              return;
            }
            e.stopPropagation();
            closeLightbox();
          }
        });
      }

      btnPrev.addEventListener("click", () => goPrev());
      btnNext.addEventListener("click", () => goNext());
      btnFullscreen.addEventListener("click", () => {
        if (!document.fullscreenElement) {
          document.documentElement.requestFullscreen().then(() => updateScale()).catch(() => {});
        } else {
          document.exitFullscreen().then(() => updateScale()).catch(() => {});
        }
      });

      // 「数字+回车」跳页输入状态：数字缓冲实时回显，Esc/超时清空，越界红色抖动提示
      let jumpDisplay = "";
      let jumpInvalid = false;
      let jumpIdleTimer = null;
      let jumpFlashTimer = null;

`}function ag(){return`      function hideJumpIndicator() {
        jumpDisplay = "";
        jumpInvalid = false;
        jumpBadge.style.display = "none";
        jumpBadge.classList.remove("is-invalid");
        if (jumpIdleTimer) { clearTimeout(jumpIdleTimer); jumpIdleTimer = null; }
        if (jumpFlashTimer) { clearTimeout(jumpFlashTimer); jumpFlashTimer = null; }
      }

      function renderJumpBadge() {
        jumpBadge.textContent = jumpDisplay;
        jumpBadge.style.display = jumpDisplay ? "block" : "none";
        jumpBadge.classList.toggle("is-invalid", jumpInvalid);
      }

      function armJumpIdleTimer() {
        if (jumpIdleTimer) clearTimeout(jumpIdleTimer);
        jumpIdleTimer = setTimeout(hideJumpIndicator, 1500);
      }

      function flashJumpInvalid() {
        if (jumpIdleTimer) { clearTimeout(jumpIdleTimer); jumpIdleTimer = null; }
        jumpInvalid = true;
        renderJumpBadge();
        if (jumpFlashTimer) clearTimeout(jumpFlashTimer);
        jumpFlashTimer = setTimeout(hideJumpIndicator, 500);
      }

      function isEditableKeyTarget(t) {
        if (!t || !t.tagName) return false;
        return t.tagName === "INPUT" || t.tagName === "TEXTAREA" || t.tagName === "SELECT" || t.isContentEditable === true;
      }

`}function lg(){return`      function getSlideOverviewTitle(slide) {
        const fm = slide?.frontmatter || {};
        if (fm.title) return String(fm.title);
        const blocks = slide?.blocks || [];
        for (const b of blocks) {
          if (b.type === "h" || /^h[1-6]$/i.test(b.subType || "")) {
            const md = (b.rawMarkdown || b.content || "").trim();
            return md.replace(/^#{1,6}s+/, "").replace(/[*_\`]/g, "").slice(0, 40);
          }
        }
        return "";
      }

      // 把任意一页渲染为静态缩略图：复用 renderBlock 与主渲染同名版式类，导出样式自动生效
      function buildOverviewThumbInto(canvas, slide) {
        const fm = slide.frontmatter || {};
        const layout = fm.layout || "default";
        const blocks = (slide.blocks || []).filter((b) => b.slot !== "slot-divider-right");
        let headerBlocks = blocks.filter((b) => b.slot === "header");
        if (headerBlocks.length === 0 && blocks.length > 0) {
          const candidate = blocks.find((b) => b.type === "h" && (!b.slot || b.slot === "default"));
          if (candidate) headerBlocks = [candidate];
        }
        const rem = blocks.filter((b) => !headerBlocks.includes(b));
        let bodyEl = null;

        if (layout === "cols-header" || layout === "two-cols-header" || layout === "three-cols-header" || layout === "clover") {
          const isClover = layout === "clover";
          let targetCols = isClover ? 4 : 2;
          if (layout === "three-cols-header") targetCols = 3;
          else if (layout === "two-cols-header") targetCols = 2;
          else if (!isClover) {
            let maxCol = 0;
            for (const b of rem) {
              const m = (b.slot || "").match(/^col-(d+)$/i);
              if (m) maxCol = Math.max(maxCol, parseInt(m[1], 10));
            }
            if (maxCol >= 2) targetCols = maxCol;
            else if (fm.layoutRatio) {
              const r = String(fm.layoutRatio).trim();
              if (r.includes(":")) {
                const parts = r.split(":").map((p) => parseFloat(p.trim())).filter((n) => !isNaN(n) && n > 0);
                if (parts.length >= 2) targetCols = parts.length;
              }
            }
          }
          const hasColSlots = rem.some((b) => b.slot && /^col-d+$/i.test(b.slot));
          const containerDiv = document.createElement("div");
          containerDiv.className = (isClover ? "layout-clover-container" : ("layout-cols-header-container " + (targetCols === 2 ? "layout-two-cols-header-container" : (targetCols === 3 ? "layout-three-cols-header-container" : "")))) + (hasColSlots || isClover ? " has-superblock-cols" : "");
          const headerDiv = document.createElement("div");
          headerDiv.className = "layout-header-section";
          for (const b of headerBlocks) headerDiv.appendChild(renderBlock(b, ""));
          containerDiv.appendChild(headerDiv);
          const gridDiv = document.createElement("div");
          gridDiv.className = (isClover ? "layout-clover-grid pdf-clover-wrapper" : ("layout-cols-wrapper layout-cols-grid " + (targetCols === 2 ? "pdf-two-cols-wrapper layout-two-cols-grid" : (targetCols === 3 ? "pdf-three-cols-wrapper layout-three-cols-grid" : "")))) + (hasColSlots || isClover ? " has-superblock-cols" : "");
          const gridCols = isClover ? "repeat(2, minmax(0, 1fr))" : parseRatioToGridCols(fm.layoutRatio, targetCols);
          if (gridCols) gridDiv.style.gridTemplateColumns = gridCols;
          if (isClover) gridDiv.style.gridTemplateRows = "repeat(2, minmax(0, 1fr))";
          let colsList = [];
          for (let i = 0; i < targetCols; i++) colsList.push([]);
          const hasExplicitCols = rem.some((b) => b.slot && (b.slot.startsWith("col-") || b.slot === "left" || b.slot === "right" || b.slot === "center"));
          if (hasExplicitCols && rem.length > 1) {
            for (const b of rem) {
              let idx = 0;
              if (b.slot === "left" || b.slot === "col-1") idx = 0;
              else if (b.slot === "center" || b.slot === "col-2") idx = 1;
              else if (b.slot === "right") idx = targetCols === 2 ? 1 : targetCols - 1;
              else {
                const m = (b.slot || "").match(/^col-(d+)$/i);
                if (m) idx = Math.min(targetCols - 1, Math.max(0, parseInt(m[1], 10) - 1));
              }
              colsList[idx].push(b);
            }
            const hasExplicitColN = rem.some(b => /^col-d+$/i.test((b.slot || "").trim()));
            if (!hasExplicitColN && colsList[0].length === 0) {
              const nonEmptyCols = colsList.filter(c => c.length > 0);
              if (nonEmptyCols.length === 1) {
                colsList = [nonEmptyCols[0], ...Array.from({ length: targetCols - 1 }, () => [])];
              }
            }
          } else if (rem.length === 1) {
            colsList[0] = [rem[0]];
          } else {
            let cur = 0;
            for (let i = 0; i < targetCols; i++) {
              const remainingCols = targetCols - i;
              const remainingItems = rem.length - cur;
              const take = Math.ceil(remainingItems / remainingCols);
              colsList[i] = rem.slice(cur, cur + take);
              cur += take;
            }
          }
          colsList.forEach((colBlocks, idx) => {
            const colDiv = document.createElement("div");
            colDiv.className = "pdf-col pdf-col--" + (idx + 1) + " col-" + (idx + 1) + (targetCols === 2 && idx === 0 ? " pdf-col--left" : "") + (targetCols === 2 && idx === 1 ? " pdf-col--right" : "");
            const cleaned = cleanColList(colBlocks);
            for (const b of cleaned) colDiv.appendChild(renderBlock(b, ""));
            gridDiv.appendChild(colDiv);
          });
          containerDiv.appendChild(gridDiv);
          bodyEl = containerDiv;
        } else if (layout === "two-cols") {
          bodyEl = document.createElement("div");
          bodyEl.style.display = "flex";
          bodyEl.style.flexDirection = "row";
          bodyEl.style.gap = "2rem";
          bodyEl.style.width = "100%";
          bodyEl.style.flex = "1";
          bodyEl.style.minHeight = "0";
          let leftList = [];
          let rightList = [];
          for (const b of blocks) {
            if (b.slot === "right") rightList.push(b);
            else leftList.push(b);
          }
          const leftCol = document.createElement("div");
          leftCol.className = "two-cols-left";
          const rightCol = document.createElement("div");
          rightCol.className = "two-cols-right";
          for (const b of cleanColList(leftList)) leftCol.appendChild(renderBlock(b, ""));
          for (const b of cleanColList(rightList)) rightCol.appendChild(renderBlock(b, ""));
          bodyEl.appendChild(leftCol);
          bodyEl.appendChild(rightCol);
        } else if (layout === "image-right" || layout === "image-left") {
          const isImageRight = layout === "image-right";
          bodyEl = document.createElement("div");
          bodyEl.style.display = "flex";
          bodyEl.style.flexDirection = isImageRight ? "row" : "row-reverse";
          bodyEl.style.gap = "2rem";
          bodyEl.style.width = "100%";
          bodyEl.style.flex = "1";
          bodyEl.style.minHeight = "0";
          const contentCol = document.createElement("div");
          contentCol.className = isImageRight ? "image-right-content" : "image-left-content";
          for (const b of blocks) contentCol.appendChild(renderBlock(b, ""));
          const imgCol = document.createElement("div");
          imgCol.className = isImageRight ? "image-right-img-container" : "image-left-img-container";
          const url = fm.image || fm.background || "";
          if (url) {
            const img = document.createElement("img");
            img.className = isImageRight ? "image-right-img" : "image-left-img";
            img.src = url;
            img.alt = "Slide cover";
            imgCol.appendChild(img);
          }
          bodyEl.appendChild(contentCol);
          bodyEl.appendChild(imgCol);
        } else {
          bodyEl = document.createElement("div");
          for (const b of blocks) bodyEl.appendChild(renderBlock(b, ""));
        }
        canvas.appendChild(bodyEl);
      }

      function buildOverviewCards() {
        if (overviewBuilt) return;
        overviewBuilt = true;
        const scale = OVERVIEW_CARD_W / baseWidth;
        const canvasH = Math.round(baseHeight * scale);
        slides.forEach((slide, idx) => {
          const card = document.createElement("div");
          card.className = "slides-overview-card";
          card.dataset.idx = String(idx);
          const box = document.createElement("div");
          box.className = "slides-overview-canvas-box";
          box.style.height = canvasH + "px";
          const fm = slide.frontmatter || {};
          const spacing = (fm.spacing && fm.spacing !== "inherit") ? fm.spacing : ((data.config && data.config.spacing) || "normal");
          const canvas = document.createElement("div");
          canvas.className = "slides-overview-canvas slide-content layout-" + (fm.layout || "default") + " spacing-" + spacing;
          canvas.style.width = baseWidth + "px";
          canvas.style.height = baseHeight + "px";
          canvas.style.transform = "scale(" + scale + ")";
          const bg = fm.background || (data.config && data.config.background);
          if (bg) {
            if (/^(http|/|data:|assets/)/.test(bg)) {
              canvas.style.backgroundImage = 'url("' + bg + '")';
              canvas.style.backgroundSize = "cover";
              canvas.style.backgroundPosition = "center";
            } else {
              canvas.style.background = bg;
            }
          }
          box.appendChild(canvas);
          const caption = document.createElement("div");
          caption.className = "slides-overview-caption";
          const pageNo = document.createElement("span");
          pageNo.className = "slides-overview-page-no";
          pageNo.textContent = String(idx + 1);
          caption.appendChild(pageNo);
          const title = getSlideOverviewTitle(slide);
          if (title) {
            const titleEl = document.createElement("span");
            titleEl.className = "slides-overview-title";
            titleEl.textContent = title;
            caption.appendChild(titleEl);
          }
          card.appendChild(box);
          card.appendChild(caption);
          card.addEventListener("click", (e) => {
            e.stopPropagation();
            goFromOverview(idx + 1);
          });
          overviewGrid.appendChild(card);
        });
        updateOverviewCurrentMark();
      }

      function renderOverviewThumb(card) {
        if (!card || card.dataset.rendered === "1") return;
        const idx = Number(card.dataset.idx);
        const slide = slides[idx];
        const canvas = card.querySelector(".slides-overview-canvas");
        if (slide && canvas) buildOverviewThumbInto(canvas, slide);
        card.dataset.rendered = "1";
      }

      function ensureOverviewObserver() {
        if (overviewObserver || typeof window.IntersectionObserver !== "function") return;
        overviewObserver = new IntersectionObserver((entries) => {
          for (const en of entries) {
            if (!en.isIntersecting) continue;
            overviewObserver.unobserve(en.target);
            renderOverviewThumb(en.target);
          }
        }, { rootMargin: "240px" });
      }

      function observeOverviewCards() {
        if (!overviewObserver) return;
        const cards = overviewGrid.children;
        for (let i = 0; i < cards.length; i++) {
          if (cards[i].dataset.rendered !== "1") overviewObserver.observe(cards[i]);
        }
      }

      function updateOverviewCurrentMark() {
        const cards = overviewGrid.children;
        for (let i = 0; i < cards.length; i++) {
          const pageNo = cards[i].querySelector(".slides-overview-page-no");
          if (pageNo) pageNo.classList.toggle("is-current", i === currentIndex);
        }
      }

      function setOverviewFocus(page) {
        const total = slides.length || 1;
        overviewFocus = Math.min(Math.max(1, page), total);
        const cards = overviewGrid.children;
        for (let i = 0; i < cards.length; i++) {
          cards[i].classList.toggle("is-active", i + 1 === overviewFocus);
        }
        const el = cards[overviewFocus - 1];
        if (el && el.scrollIntoView) el.scrollIntoView({ block: "nearest", behavior: "smooth" });
      }

      function getOverviewCols() {
        if (!overviewGrid || !overviewGrid.clientWidth) return 1;
        return Math.max(1, Math.round(overviewGrid.clientWidth / (OVERVIEW_CARD_W + 18)));
      }

      function goFromOverview(page) {
        const p = parseInt(page, 10);
        if (isNaN(p) || p < 1 || p > slides.length) return;
        closeOverview();
        renderSlide(p - 1);
        updateOverviewCurrentMark();
      }

      function openOverview() {
        if (slides.length === 0) return;
        buildOverviewCards();
        overviewOpen = true;
        overviewOverlay.style.display = "block";
        ensureOverviewObserver();
        if (overviewObserver) {
          observeOverviewCards();
        } else {
          const cards = overviewGrid.children;
          for (let i = 0; i < cards.length; i++) renderOverviewThumb(cards[i]);
        }
        setOverviewFocus(currentIndex + 1);
      }

      function closeOverview() {
        overviewOpen = false;
        overviewOverlay.style.display = "none";
        hideJumpIndicator();
        if (overviewObserver) {
          const cards = overviewGrid.children;
          for (let i = 0; i < cards.length; i++) overviewObserver.unobserve(cards[i]);
        }
      }

      function toggleOverview() {
        if (overviewOpen) closeOverview();
        else openOverview();
      }

      // 总览打开期间接管全部按键：修复上游总览中空格/PGUP/PGDN 仍会翻页的漏洞
      function handleOverviewKeyDown(e) {
        if (e.ctrlKey || e.metaKey || e.altKey) return;
        if (e.isComposing || isEditableKeyTarget(e.target)) return;
        if (/^[0-9]$/.test(e.key)) {
          if (!jumpInvalid && jumpDisplay.length < 4) {
            jumpDisplay += e.key;
            const p = parseInt(jumpDisplay, 10);
            if (!isNaN(p) && p >= 1 && p <= slides.length) setOverviewFocus(p);
            renderJumpBadge();
            armJumpIdleTimer();
          }
          e.preventDefault();
          return;
        }
        if (e.key === "Enter" && jumpDisplay) {
          if (!jumpInvalid) {
            const page = parseInt(jumpDisplay, 10);
            if (!isNaN(page) && page >= 1 && page <= slides.length) {
              goFromOverview(page);
            } else {
              flashJumpInvalid();
            }
          }
          e.preventDefault();
          return;
        }
        if ((e.key === "Escape" || e.key === "Esc") && (jumpDisplay || jumpInvalid)) {
          hideJumpIndicator();
          e.preventDefault();
          return;
        }
        if (e.key === "ArrowRight") {
          e.preventDefault();
          setOverviewFocus(overviewFocus + 1);
          return;
        }
        if (e.key === "ArrowLeft") {
          e.preventDefault();
          setOverviewFocus(overviewFocus - 1);
          return;
        }
        if (e.key === "ArrowDown" || e.key === "PageDown") {
          e.preventDefault();
          setOverviewFocus(overviewFocus + getOverviewCols());
          return;
        }
        if (e.key === "ArrowUp" || e.key === "PageUp") {
          e.preventDefault();
          setOverviewFocus(overviewFocus - getOverviewCols());
          return;
        }
        if (e.key === " ") {
          e.preventDefault();
          return;
        }
        if (e.key === "Enter") {
          e.preventDefault();
          goFromOverview(overviewFocus);
          return;
        }
        if (e.key === "Escape" || e.key === "Esc" || e.key === "o" || e.key === "O") {
          e.preventDefault();
          closeOverview();
        }
      }

      window.addEventListener("keydown", (e) => {
        if (e.key === "Escape" || e.key === "Esc") {
          if (isLightboxOpen) {
            closeLightbox();
            e.preventDefault();
            return;
          }
        }
        if (isLightboxOpen) return;
        // 总览打开期间全部按键由总览层接管
        if (overviewOpen) {
          handleOverviewKeyDown(e);
          return;
        }
        // 「数字+回车」跳页：可输入元素、修饰键、IME 组合输入中不拦截
        if (!e.ctrlKey && !e.metaKey && !e.altKey && !e.isComposing && !isEditableKeyTarget(e.target)) {
          if (/^[0-9]$/.test(e.key)) {
            if (!jumpInvalid && jumpDisplay.length < 4) {
              jumpDisplay += e.key;
              renderJumpBadge();
              armJumpIdleTimer();
            }
            e.preventDefault();
            return;
          }
          if (e.key === "Enter" && jumpDisplay) {
            if (!jumpInvalid) {
              const page = parseInt(jumpDisplay, 10);
              if (!isNaN(page) && page >= 1 && page <= slides.length) {
                hideJumpIndicator();
                renderSlide(page - 1);
              } else {
                flashJumpInvalid();
              }
            }
            e.preventDefault();
            return;
          }
          if ((e.key === "Escape" || e.key === "Esc") && (jumpDisplay || jumpInvalid)) {
            hideJumpIndicator();
            e.preventDefault();
            return;
          }
          if (e.key === "o" || e.key === "O") {
            e.preventDefault();
            toggleOverview();
            return;
          }
        }
        if (e.key === "ArrowRight" || e.key === " " || e.key === "ArrowDown") goNext();
        if (e.key === "ArrowLeft" || e.key === "ArrowUp") goPrev();
        if (e.key === "f" || e.key === "F") btnFullscreen.click();
      });

      // 监听鼠标滚轮上下翻页调度
      let lastWheelTime = 0;
      const WHEEL_COOLDOWN_MS = 280;
      const WHEEL_DELTA_THRESHOLD = 15;

`}function cg(){return`      function canElementScrollY(el, deltaY) {
        let cur = el;
        while (cur && cur !== document.body && cur !== document.documentElement) {
          if (cur.classList && (cur.classList.contains("slides-viewport") || cur.classList.contains("slides-stage") || cur.classList.contains("slide-container"))) {
            break;
          }
          const style = window.getComputedStyle(cur);
          const overflowY = style.overflowY;
          if (overflowY === "auto" || overflowY === "scroll") {
            const maxScroll = cur.scrollHeight - cur.clientHeight;
            if (maxScroll > 2) {
              if (deltaY > 0 && cur.scrollTop < maxScroll - 1) return true;
              if (deltaY < 0 && cur.scrollTop > 1) return true;
            }
          }
          cur = cur.parentElement;
        }
        return false;
      }

      window.addEventListener("wheel", (e) => {
        if (isLightboxOpen) {
          if (typeof handleLightboxWheel === "function") {
            handleLightboxWheel(e);
          }
          return;
        }
        // 总览打开时滚轮交给总览列表原生滚动，不触发翻页
        if (overviewOpen) return;
        if (Math.abs(e.deltaY) < Math.abs(e.deltaX)) return;
        if (Math.abs(e.deltaY) < WHEEL_DELTA_THRESHOLD) return;

        const target = e.target instanceof Element ? e.target : e.target?.parentElement;
        if (target && canElementScrollY(target, e.deltaY)) return;

        e.preventDefault();
        const now = Date.now();
        if (now - lastWheelTime < WHEEL_COOLDOWN_MS) return;
        lastWheelTime = now;

        if (e.deltaY > 0) {
          goNext();
        } else {
          goPrev();
        }
      }, { passive: false });

      document.addEventListener("click", (e) => {
        if (isLightboxOpen) {
          if (typeof lightboxHasMoved !== "undefined" && lightboxHasMoved) {
            lightboxHasMoved = false;
            e.stopPropagation();
            return;
          }
          const target = e.target instanceof Element ? e.target : e.target?.parentElement;
          const isMediaItself = target && target.closest && target.closest(".slides-lightbox-img, .slides-lightbox-video");
          if (!isMediaItself) {
            e.stopPropagation();
            closeLightbox();
          }
          return;
        }
        // 总览打开时空白点击由总览层自身处理，不触发底层翻页
        if (overviewOpen) return;
        if (e.button !== 0) return;
        const targetEl = e.target instanceof Element ? e.target : e.target?.parentElement;
        if (!targetEl || !targetEl.closest) return;

        const hasPendingMask = currentMaskConfig && (currentMaskStep < currentMaskConfig.totalSteps);
        if (hasPendingMask) {
          const isBottomControls = targetEl.closest(".controls-bar, .controls, .slides-toc");
          if (isBottomControls) return;
          e.preventDefault();
          e.stopPropagation();
          goNext();
          return;
        }

        const refEl = targetEl.closest("[data-ref-id]");
        if (refEl) {
          const id = refEl.getAttribute("data-ref-id");
          if (id) {
            window.open("siyuan://blocks/" + id, "_blank");
            return;
          }
        }

        // 媒体点击唤起 Lightbox 放大模态
        const mediaEl = targetEl.closest(".slide-content img, .slide-content video");
        if (mediaEl && !mediaEl.closest(".controls, .controls-bar, button, a")) {
          e.stopPropagation();
          const isVideo = mediaEl.tagName.toLowerCase() === "video";
          const src = isVideo ? (mediaEl.currentSrc || mediaEl.src || mediaEl.querySelector("source")?.src) : mediaEl.src;
          if (src) {
            openLightbox(isVideo ? "video" : "image", src, mediaEl.alt || "");
            return;
          }
        }

        const selection = window.getSelection ? window.getSelection().toString().trim() : "";
        if (selection.length > 0) return;

        const isComponent = targetEl.closest(
          ".slide-block, .controls-bar, .image-right-img-container, .image-left-img-container, .controls, img, video, audio, button, a, input, textarea, select, [data-clickable], [data-ref-id], .slides-toc, .empty-state"
        );
        if (isComponent) return;

        const isLeft = e.clientX < window.innerWidth / 2;
        if (isLeft) {
          goPrev();
        } else {
          goNext();
        }
      });

      renderSlide(0);
      updateScale();
    })();`}function dg(){return[tg(),ig(),ng(),sg(),og(),rg(),ag(),lg(),cg()].join("")}function Yl(e,t){const i=(t==null?void 0:t.title)||"即现演示文稿";let n=e.slides;if(t!=null&&t.inlineAssetBase64Map&&Object.keys(t.inlineAssetBase64Map).length>0){const a=t.inlineAssetBase64Map;n=e.slides.map(r=>{let l=r.rawMarkdown;for(const[p,u]of Object.entries(a))l.includes(p)&&(l=l.split(p).join(u));const c=r.blocks.map(p=>{let u=p.rawMarkdown;for(const[f,w]of Object.entries(a))u.includes(f)&&(u=u.split(f).join(w));return{...p,rawMarkdown:u}});let d=r.frontmatter?{...r.frontmatter}:r.frontmatter;if(d){if(typeof d.background=="string")for(const[p,u]of Object.entries(a))d.background.includes(p)&&(d.background=d.background.split(p).join(u));if(typeof d.image=="string")for(const[p,u]of Object.entries(a))d.image.includes(p)&&(d.image=d.image.split(p).join(u))}return{...r,rawMarkdown:l,blocks:c,frontmatter:d}})}const s=JSON.stringify(n),o=JSON.stringify(e.config);return`<!DOCTYPE html>
<html lang="zh-CN">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${ot(i)}</title>
  <style>
${eg(t==null?void 0:t.customInlineStyles)}
  </style>
  <script>
    // 注入演示数据载荷
    window.__SLIDES_DATA__ = {
      docId: ${JSON.stringify(e.docId)},
      slides: ${s},
      config: ${o}
    };
  <\/script>
</head>
<body>
  <div id="app" data-normalize-headings="${e.config.normalizeHeadingSizes?"true":"false"}" data-hide-unordered-markers="${e.config.showUnorderedListMarkers===!1?"true":"false"}" data-hide-ordered-markers="${e.config.showOrderedListMarkers===!1?"true":"false"}">
    <div class="slide-viewport slides-theme-${e.config.theme||"default"}" id="viewport" data-slides-theme="${e.config.theme||"default"}">
      <div class="slide-content" id="slide-container"></div>
    </div>
    <div class="controls">
      <button id="btn-prev">◀ 上一页</button>
      <span id="page-num">1 / 1</span>
      <button id="btn-next">下一页 ▶</button>
      <button id="btn-fullscreen">全屏</button>
    </div>
    <!-- 全屏媒体灯箱 (Lightbox) 模态窗口 -->
    <div id="slides-lightbox" class="slides-lightbox">
      <button class="slides-lightbox-close" id="lightbox-close" aria-label="关闭 (Esc)">✕</button>
      <div class="slides-lightbox-content" id="lightbox-content"></div>
    </div>
  </div>

  <script>
${dg()}
  <\/script>
</body>
</html>`}function Zl(e,t){if(typeof document>"u")return!1;const i=new Blob([t],{type:"text/html;charset=utf-8"}),n=URL.createObjectURL(i),s=document.createElement("a");return s.href=n,s.download=e.endsWith(".html")?e:`${e}.html`,document.body.appendChild(s),s.click(),document.body.removeChild(s),URL.revokeObjectURL(n),!0}function ug(e){switch(e){case"4:3":return"size: 12in 9in;";case"A4-landscape":return"size: 297mm 210mm;";case"A4-portrait":return"size: 210mm 297mm;";case"16:9":default:return"size: 16in 9in;"}}function fg(e){const t=ug(e==null?void 0:e.pageRatio);return`
    ${On(e==null?void 0:e.customInlineStyles)}

    @page {
      ${t}
      margin: 0;
    }
    * {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
      -webkit-print-color-adjust: exact !important;
      print-color-adjust: exact !important;
    }
    body {
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "PingFang SC", "Microsoft YaHei", sans-serif;
      background: #f8fafc;
      color: #1e293b;
    }
    .pdf-slide-page {
      width: 100vw;
      height: 100vh;
      page-break-after: always;
      break-after: page;
      padding: var(--slides-padding-y, 36px) var(--slides-padding-x, 56px);
      display: flex;
      flex-direction: column;
      position: relative;
      background: #ffffff;
      overflow: hidden;
    }
    .pdf-slide-page.spacing-compact {
      --slides-padding-y: 20px;
      --slides-padding-x: 36px;
      --slides-header-gap: 10px;
      --slides-title-margin-bottom: 6px;
    }
    .pdf-slide-page.spacing-normal {
      --slides-padding-y: 36px;
      --slides-padding-x: 56px;
      --slides-header-gap: 16px;
      --slides-title-margin-bottom: 10px;
    }
    .pdf-slide-page.spacing-loose {
      --slides-padding-y: 48px;
      --slides-padding-x: 64px;
      --slides-header-gap: 24px;
      --slides-title-margin-bottom: 16px;
    }
    .pdf-slide-page.theme-dark {
      background: #0f1117;
      color: #f1f5f9;
    }
    .pdf-slide-header {
      font-size: 13px;
      color: #64748b;
      margin-bottom: 24px;
      display: flex;
      justify-content: space-between;
      border-bottom: 1px solid #e2e8f0;
      padding-bottom: 8px;
    }
    .theme-dark .pdf-slide-header {
      border-bottom-color: #2e3346;
      color: #94a3b8;
    }
    .pdf-slide-body {
      flex: 1;
      display: flex;
      flex-direction: column;
      gap: 16px;
      font-size: 20px;
      line-height: 1.6;
      overflow: hidden;
    }
    .pdf-block h1 { font-size: 2.5rem; font-weight: 800; color: #2563eb; margin-bottom: 12px; }
    .pdf-block h2 { font-size: 1.9rem; font-weight: 700; color: #1d4ed8; margin-bottom: 10px; }
    .pdf-block h3 { font-size: 1.4rem; font-weight: 600; margin-bottom: 8px; }
    .pdf-block h4 { font-size: 1.2rem; font-weight: 600; margin-bottom: 6px; }
    .pdf-block p { font-size: 1.15rem; color: inherit; }
    .pdf-code,
    pre {
      background: #f1f5f9;
      padding: 14px 18px;
      border-radius: 6px;
      font-family: "JetBrains Mono", Consolas, monospace;
      font-size: 0.95rem;
      border-left: 4px solid #3b82f6;
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      max-width: 100% !important;
      box-sizing: border-box !important;
    }
    .pdf-code code,
    pre code {
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      display: block !important;
      width: 100% !important;
      box-sizing: border-box !important;
    }
    .code-line {
      display: flex !important;
      align-items: flex-start !important;
      width: 100% !important;
      box-sizing: border-box !important;
      line-height: 1.6;
    }
    .code-line .line-no {
      display: inline-block !important;
      flex-shrink: 0 !important;
      min-width: 2.2em !important;
      text-align: right !important;
      margin-right: 12px !important;
      user-select: none !important;
      opacity: 0.45 !important;
    }
    .code-line .line-content {
      flex: 1 1 0% !important;
      min-width: 0 !important;
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
    }
    .theme-dark .pdf-code {
      background: #1e1e24;
      border-left-color: #60a5fa;
    }
    .pdf-quote {
      border-left: 4px solid #10b981;
      background: rgba(16, 185, 129, 0.08);
      padding: 10px 16px;
      border-radius: 0 4px 4px 0;
      font-style: italic;
    }
    .pdf-image,
    .slide-media-img {
      max-width: 100% !important;
      max-height: 48vh !important;
      width: auto !important;
      height: auto !important;
      object-fit: contain !important;
      border-radius: 6px;
      margin: auto;
      display: block;
    }
    .slide-media-block,
    .slide-media-container,
    .slide-video-container {
      display: flex;
      flex-direction: column;
      justify-content: center;
      align-items: center;
      width: 100%;
      max-height: 48vh;
      margin: 8px 0;
      overflow: hidden;
    }
    .slide-list-media {
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: flex-start;
      margin-top: 8px;
      margin-bottom: 6px;
      max-width: 100%;
      overflow: hidden;
    }
    .slide-list-media img,
    .slide-list-media video,
    .slide-list-media .list-item-gif {
      max-width: 100% !important;
      max-height: min(280px, 36vh) !important;
      width: auto !important;
      height: auto !important;
      min-width: 0 !important;
      min-height: 0 !important;
      object-fit: contain !important;
      border-radius: 6px;
      display: block;
      margin: 0 auto !important;
    }
    .slide-video-player {
      max-width: 100% !important;
      max-height: 48vh !important;
      width: auto !important;
      height: auto !important;
      object-fit: contain !important;
      border-radius: 6px;
      background: #000;
      border: 1px solid #cbd5e1;
    }
    .pdf-two-cols-wrapper,
    .layout-two-cols-grid,
    .layout-cols-wrapper,
    .layout-cols-grid {
      display: grid;
      grid-template-columns: minmax(0, 1fr) minmax(0, 1fr);
      grid-template-rows: minmax(0, 1fr) !important;
      gap: 36px;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      overflow: hidden !important;
    }
    .layout-cols-header-container,
    .layout-two-cols-header-container,
    .layout-three-cols-header-container,
    .layout-clover-container {
      display: flex;
      flex-direction: column;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      overflow: hidden !important;
    }
    .layout-header-section {
      width: 100%;
      margin-bottom: var(--slides-header-gap, 16px) !important;
      flex-shrink: 0;
    }
    .layout-header-section h1,
    .layout-header-section h2,
    .layout-header-section h3 {
      margin-bottom: var(--slides-title-margin-bottom, 10px) !important;
    }
    .pdf-three-cols-wrapper,
    .layout-three-cols-grid {
      display: grid;
      grid-template-columns: minmax(0, 1fr) minmax(0, 1fr) minmax(0, 1fr);
      grid-template-rows: minmax(0, 1fr) !important;
      gap: 24px;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      box-sizing: border-box;
      overflow: hidden !important;
    }
    .pdf-clover-wrapper,
    .layout-clover-grid {
      display: grid;
      grid-template-columns: repeat(2, minmax(0, 1fr)) !important;
      grid-template-rows: repeat(2, minmax(0, 1fr)) !important;
      gap: 20px;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      box-sizing: border-box;
      overflow: hidden !important;
    }
    .layout-clover-grid .pdf-col {
      background: transparent !important;
      border: none !important;
      box-shadow: none !important;
    }
    .pdf-col {
      display: flex;
      flex-direction: column;
      gap: 14px;
      min-width: 0;
      width: 100%;
      max-width: 100%;
      height: 100%;
      max-height: 100%;
      min-height: 0;
      justify-content: flex-start;
      overflow: hidden;
      box-sizing: border-box;
      overflow-wrap: break-word;
      word-break: break-word;
      white-space: normal;
    }
    /* 表头多栏内超级块子块首个列表项去圆点后居中显示标题/首行文本 (仅在存在超级块分栏时生效) */
    .has-superblock-cols .pdf-col > *:first-child .slide-list-item-title,
    .has-superblock-cols .pdf-col > *:first-child :is(h1, h2, h3, h4, h5, h6),
    .has-superblock-cols .pdf-col > *:first-child p.slide-list-item-title,
    .has-superblock-cols .pdf-col > *:first-child p:first-of-type,
    .has-superblock-cols .pdf-col > *:first-child p:first-child,
    .has-superblock-cols .pdf-col > *:first-child :is(ul, ol) > li:first-child,
    .has-superblock-cols .pdf-col > *:first-child .slide-list > .slide-list-item:first-child,
    .has-superblock-cols .pdf-col > *:first-child .pdf-list > li:first-child,
    .has-superblock-cols .slides-col-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    .has-superblock-cols .slides-col-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      list-style: none !important;
      list-style-type: none !important;
      text-align: center !important;
      margin-left: 0 !important;
      padding-left: 0 !important;
      width: 100% !important;
    }

    /* 彻底清除首个列表项的原生圆点 Marker (仅在存在超级块分栏时生效) */
    .has-superblock-cols .pdf-col > *:first-child :is(ul, ol) > li:first-child::marker {
      content: "" !important;
      display: none !important;
    }

    /* 确保首个列表项内部内联与块级元素居中 (仅在存在超级块分栏时生效) */
    .has-superblock-cols .pdf-col > *:first-child :is(ul, ol) > li:first-child * {
      text-align: center !important;
    }

    /* 栏内说明段落与列表项：左对齐，自然阅读排版 */
    .has-superblock-cols .pdf-col .slide-list-item-desc,
    .has-superblock-cols .pdf-col li:not(:first-child) {
      text-align: left !important;
    }

    /* 全局特定标题大小规范化 (除封面外页首首个标题按 H2 1.7rem，表头多栏内首个标题按 H3 1.3rem) */
    [data-normalize-headings="true"] .slides-page-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .slides-page-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .pdf-slide:not(.layout-cover) > :is(.pdf-block, .slide-block):first-child :is(h1, h2, h3, h4, h5, h6),
    [data-normalize-headings="true"] .pdf-slide:not(.layout-cover) > .layout-header-section :is(.pdf-block, .slide-block):first-child :is(h1, h2, h3, h4, h5, h6),
    [data-normalize-headings="true"] .pdf-slide:not(.layout-cover) > :not(.layout-cols-wrapper):not(.pdf-two-cols-wrapper):not(.layout-image-cols-grid):first-child :is(h1, h2, h3, h4, h5, h6) {
      font-size: 1.7rem !important;
      font-weight: 600 !important;
      line-height: 1.25 !important;
      margin-bottom: 10px !important;
    }

    [data-normalize-headings="true"] .has-superblock-cols .slides-col-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .has-superblock-cols .slides-col-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .has-superblock-cols .pdf-col > *:first-child :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      font-size: 1.3rem !important;
      font-weight: 600 !important;
      line-height: 1.3 !important;
      margin-bottom: 8px !important;
      text-align: center !important;
    }

    /* 图左与图右版式标题完全保留用户原始字号与默认排版，不进行任何固定大小规范化 */
    [data-normalize-headings="true"] :is(.layout-image-left, .layout-image-right, .image-left-content, .image-right-content) :is(h1, h2, h3, h4, h5, h6) {
      text-align: left !important;
    }
    .pdf-col > .pdf-block,
    .pdf-col > .slide-block {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      max-height: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      width: 100% !important;
      height: 100% !important;
      box-sizing: border-box !important;
      overflow: hidden !important;
    }
    .pdf-col .slide-list-item-title,
    .pdf-col h1, .pdf-col h2, .pdf-col h3, .pdf-col h4, .pdf-col h5, .pdf-col h6,
    .pdf-col .slide-list-item-desc {
      flex: 0 0 auto !important;
      margin-top: 0 !important;
      margin-bottom: 6px !important;
    }
    .pdf-col .slide-list-media,
    .pdf-col .slide-video-container,
    .pdf-col .slide-media-container {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      min-width: 0 !important;
      width: 100% !important;
      height: 100% !important;
      max-height: 100% !important;
      max-width: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
      justify-content: flex-start !important;
      overflow: hidden !important;
      margin: 0 !important;
      padding: 0 !important;
      box-sizing: border-box !important;
    }
    .pdf-col li:has(.slide-list-media),
    .pdf-col li:has(.slide-media-container),
    .pdf-col li:has(.slide-video-container),
    .pdf-col li:has(img),
    .pdf-col li:has(video),
    .pdf-col .pdf-list-item:has(.slide-list-media),
    .pdf-col .pdf-list-item:has(.slide-media-container),
    .pdf-col .pdf-list-item:has(.slide-video-container),
    .pdf-col .pdf-list-item:has(img),
    .pdf-col .pdf-list-item:has(video) {
      display: list-item !important;
      list-style-type: disc !important;
      flex: 0 0 auto !important;
      height: auto !important;
      max-height: none !important;
      overflow: visible !important;
      margin-bottom: 6px !important;
    }
    .pdf-col video,
    .layout-three-cols-grid video,
    .layout-two-cols-grid video,
    .pdf-col img,
    .layout-three-cols-grid img,
    .layout-two-cols-grid img,
    .pdf-col .slide-video-player {
      max-width: 100% !important;
      max-height: 100% !important;
      width: auto !important;
      height: auto !important;
      min-width: 0 !important;
      min-height: 0 !important;
      object-fit: contain !important;
      display: block !important;
      margin: 0 auto !important;
    }
    .pdf-col * {
      overflow-wrap: break-word;
      word-break: break-word;
      box-sizing: border-box;
    }
    .pdf-col pre {
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      max-width: 100% !important;
      box-sizing: border-box !important;
    }
    .pdf-list-item {
      padding-left: 20px;
    }
    .pdf-list {
      padding-left: 24px;
      margin: 8px 0;
      display: flex;
      flex-direction: column;
      gap: 6px;
    }
    .pdf-list li {
      font-size: 1.15rem;
      line-height: 1.6;
    }
    .pdf-task-item {
      list-style: none;
      margin-left: -20px;
      display: flex;
      align-items: center;
      gap: 8px;
    }
    .pdf-task-item input[type="checkbox"] {
      width: 1.15em;
      height: 1.15em;
      cursor: pointer;
    }
    /* 两栏与三栏及多栏（超级块分栏）布局：紧凑自然行距，子列表保留圆点与层级缩进 */
    .layout-two-cols ul,
    .layout-cols-header ul,
    .layout-two-cols-header ul,
    .layout-three-cols ul,
    .layout-three-cols-header ul,
    .two-cols-left ul,
    .two-cols-right ul,
    .three-cols-col ul,
    .col ul,
    .pdf-two-cols-wrapper ul,
    .pdf-three-cols-wrapper ul,
    .pdf-col ul,
    .layout-two-cols-grid .pdf-list,
    .layout-three-cols-grid .pdf-list,
    .layout-cols-grid .pdf-list,
    .layout-two-cols-grid .pdf-list--unordered,
    .layout-three-cols-grid .pdf-list--unordered,
    .layout-cols-grid .pdf-list--unordered {
      list-style: disc !important;
      list-style-type: disc !important;
      padding-left: 1.25em !important;
      margin-left: 0 !important;
      margin-top: 0 !important;
      margin-bottom: 8px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: block !important;
    }
    .layout-two-cols ol,
    .layout-cols-header ol,
    .layout-two-cols-header ol,
    .layout-three-cols ol,
    .layout-three-cols-header ol,
    .two-cols-left ol,
    .two-cols-right ol,
    .three-cols-col ol,
    .col ol,
    .pdf-two-cols-wrapper ol,
    .pdf-three-cols-wrapper ol,
    .pdf-col ol,
    .layout-two-cols-grid .pdf-list--ordered,
    .layout-three-cols-grid .pdf-list--ordered,
    .layout-cols-grid .pdf-list--ordered {
      list-style: decimal !important;
      list-style-type: decimal !important;
      padding-left: 1.25em !important;
      margin-left: 0 !important;
      margin-top: 0 !important;
      margin-bottom: 8px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: block !important;
    }
    .layout-two-cols li,
    .layout-cols-header li,
    .layout-two-cols-header li,
    .layout-three-cols li,
    .layout-three-cols-header li,
    .two-cols-left li,
    .two-cols-right li,
    .three-cols-col li,
    .col li,
    .pdf-col li,
    .pdf-col .pdf-list-item {
      padding-left: 0.2em !important;
      margin-left: 0 !important;
      margin-bottom: 6px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: list-item !important;
      line-height: 1.6 !important;
    }
    .layout-two-cols ul ul,
    .layout-three-cols ul ul,
    .three-cols-col ul ul,
    .pdf-col ul ul {
      list-style: circle !important;
      list-style-type: circle !important;
      padding-left: 1.25em !important;
      margin-top: 4px !important;
      margin-bottom: 4px !important;
    }
    /* 列表项内嵌标题与说明排版 */
    .slide-list-item-title,
    .pdf-list li > h1,
    .pdf-list li > h2,
    .pdf-list li > h3,
    .pdf-list li > h4,
    .pdf-list li > h5,
    .pdf-list li > h6,
    li > h1.slide-list-item-title,
    li > h2.slide-list-item-title,
    li > h3.slide-list-item-title,
    li > h4.slide-list-item-title {
      margin-top: 2px !important;
      margin-bottom: 6px !important;
      line-height: 1.35 !important;
      font-weight: 700 !important;
    }
    .pdf-list li > h1, li > h1.slide-list-item-title { font-size: 1.6rem !important; }
    .pdf-list li > h2, li > h2.slide-list-item-title { font-size: 1.4rem !important; }
    .pdf-list li > h3, li > h3.slide-list-item-title { font-size: 1.22rem !important; }
    .pdf-list li > h4, li > h4.slide-list-item-title { font-size: 1.1rem !important; }

    /* 全局特定标题大小规范化后置强力锁定 (防止被列表项内部字号覆盖) */
    [data-normalize-headings="true"] .slides-page-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .slides-page-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      font-size: 1.7rem !important;
      font-weight: 600 !important;
      line-height: 1.25 !important;
      margin-bottom: 10px !important;
    }
    [data-normalize-headings="true"] .has-superblock-cols .slides-col-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .has-superblock-cols .slides-col-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .has-superblock-cols .pdf-col > *:first-child :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      font-size: 1.3rem !important;
      font-weight: 600 !important;
      line-height: 1.3 !important;
      margin-bottom: 8px !important;
      text-align: center !important;
    }
    /* 基础列表项前缀样式 */
    .slide-block ul,
    .slide-list--unordered,
    .pdf-list--unordered {
      list-style: disc !important;
      list-style-type: disc !important;
    }
    .slide-block ol,
    .slide-list--ordered,
    .pdf-list--ordered {
      list-style: decimal !important;
      list-style-type: decimal !important;
    }
    .slide-block li,
    .slide-list-item,
    .pdf-list-item,
    .pdf-list li {
      display: list-item !important;
    }

    /* 隐藏无序列表前缀标记 */
    [data-hide-unordered-markers="true"] :is(ul, .slide-list, .slide-list--unordered, .pdf-list, .pdf-list--unordered),
    [data-hide-unordered-markers="true"] :is(ul, .slide-list, .slide-list--unordered, .pdf-list, .pdf-list--unordered) > li,
    [data-hide-unordered-markers="true"] li.slide-list-item,
    [data-hide-unordered-markers="true"] ul > li {
      list-style: none !important;
      list-style-type: none !important;
      padding-left: 0 !important;
      margin-left: 0 !important;
    }
    [data-hide-unordered-markers="true"] :is(ul, .slide-list, .slide-list--unordered, .pdf-list, .pdf-list--unordered) > li::marker,
    [data-hide-unordered-markers="true"] li.slide-list-item::marker {
      content: "" !important;
      display: none !important;
    }

    /* 隐藏有序列表前缀标记 */
    [data-hide-ordered-markers="true"] :is(ol, .slide-list, .slide-list--ordered, .pdf-list, .pdf-list--ordered),
    [data-hide-ordered-markers="true"] :is(ol, .slide-list, .slide-list--ordered, .pdf-list, .pdf-list--ordered) > li,
    [data-hide-ordered-markers="true"] li.slide-list-item,
    [data-hide-ordered-markers="true"] ol > li {
      list-style: none !important;
      list-style-type: none !important;
      padding-left: 0 !important;
      margin-left: 0 !important;
    }
    [data-hide-ordered-markers="true"] :is(ol, .slide-list, .slide-list--ordered, .pdf-list, .pdf-list--ordered) > li::marker,
    [data-hide-ordered-markers="true"] li.slide-list-item::marker {
      content: "" !important;
      display: none !important;
    }

    .slide-list-item-desc,
    .pdf-list li > p {
      margin-top: 4px !important;
      margin-bottom: 6px !important;
      font-size: 1.05rem;
      line-height: 1.55;
      opacity: 0.92;
    }
    kbd {
      display: inline-block;
      padding: 2px 7px;
      font-family: ui-monospace, SFMono-Regular, "SF Mono", Menlo, Consolas, "Liberation Mono", monospace;
      font-size: 0.85em;
      font-weight: 600;
      line-height: 1.25;
      color: inherit;
      background: rgba(125, 125, 125, 0.12);
      border: 1px solid rgba(125, 125, 125, 0.35);
      border-bottom-width: 2px;
      border-radius: 5px;
      box-shadow: 0 1px 2px rgba(0, 0, 0, 0.12);
      margin: 0 2px;
      vertical-align: middle;
      white-space: nowrap;
    }
    .theme-dark kbd {
      background: rgba(255, 255, 255, 0.1);
      border-color: rgba(255, 255, 255, 0.25);
      border-bottom-color: rgba(255, 255, 255, 0.4);
      color: #f1f5f9;
      box-shadow: 0 1px 2px rgba(0, 0, 0, 0.4);
    }
    a {
      color: inherit;
      text-decoration: none;
      border-bottom: 1px dashed currentColor;
    }
    .slides-ref-tag, a.slides-ref-tag {
      display: inline-flex;
      align-items: center;
      background: rgba(16, 185, 129, 0.1);
      color: #059669;
      border: 1px solid rgba(16, 185, 129, 0.25);
      border-radius: 4px;
      padding: 2px 8px;
      font-size: 0.88em;
      text-decoration: none;
      margin: 2px 4px 2px 0;
    }
    .theme-dark .slides-ref-tag, .theme-dark a.slides-ref-tag {
      background: rgba(52, 211, 153, 0.15);
      color: #34d399;
      border-color: rgba(52, 211, 153, 0.3);
    }
    .slides-block-ref, .pdf-block--ref {
      background: rgba(16, 185, 129, 0.06);
      border-left: 3px solid #059669;
      border-radius: 0 6px 6px 0;
      padding: 10px 14px;
      margin: 8px 0;
    }
    .theme-dark .slides-block-ref, .theme-dark .pdf-block--ref {
      background: rgba(52, 211, 153, 0.08);
      border-left-color: #34d399;
    }
    .pdf-slide-notes {
      font-size: 14px;
      color: #059669;
      border-top: 1px dashed #cbd5e1;
      padding-top: 12px;
      margin-top: auto;
      line-height: 1.5;
    }
    .theme-dark .pdf-slide-notes {
      color: #34d399;
      border-top-color: #334155;
    }
    /* Layouts */
    .layout-cover .pdf-slide-body {
      justify-content: center;
      align-items: center;
      text-align: center;
    }
    .layout-cover h1 {
      font-size: 3.2rem;
    }
    .layout-center .pdf-slide-body {
      justify-content: center;
      align-items: center;
      text-align: center;
    }
    .layout-fact .pdf-slide-body {
      justify-content: center;
      align-items: center;
      text-align: center;
    }
    .layout-fact h1 {
      font-size: 4.5rem;
      color: #ef4444;
    }
    @media print {
      .slides-motion-fade-in,
      .slides-motion-slide-up,
      .slides-motion-slide-down,
      .slides-motion-slide-left,
      .slides-motion-slide-right,
      .slides-motion-zoom-in,
      .slides-motion-pop,
      .slides-motion-bounce {
        animation: none !important;
        opacity: 1 !important;
        transform: none !important;
      }
      /* PDF 打印讲义下禁用动态蒙版遮挡，保证内容 100% 完整可见 */
      .slides-mask-layer,
      .slides-mask-overlay,
      .slides-mask-divider-line {
        display: none !important;
        opacity: 0 !important;
        mask: none !important;
        -webkit-mask: none !important;
      }
      .slides-mask-body-container {
        clip-path: none !important;
        -webkit-clip-path: none !important;
        overflow: visible !important;
      }
    }
  `}function pg(e,t){const i="即现演示讲义",n="16:9",s="light",o=e.slides.map((a,r)=>{const l=a.frontmatter.layout||"default",c=a.frontmatter.spacing,d=c&&c!=="inherit"?c:e.config.spacing||"normal",p=ql(a),u=`${r+1} / ${e.slides.length}`;return`
      <section class="pdf-slide-page layout-${l} theme-${s} spacing-${d}">
        <header class="pdf-slide-header">
          <span class="pdf-doc-title">${ot(i)}</span>
          ${`<span class="pdf-page-badge">P. ${u}</span>`}
        </header>
        <div class="pdf-slide-body">
          ${p}
        </div>
        ${a.notes?`
          <footer class="pdf-slide-notes">
            <strong>演讲备注:</strong> ${ot(a.notes)}
          </footer>
        `:""}
      </section>
    `}).join(`
`);return`<!DOCTYPE html>
<html lang="zh-CN">
<head>
  <meta charset="UTF-8">
  <title>${ot(i)} - 高保真讲义</title>
  <style>
    ${fg({pageRatio:n,customInlineStyles:t==null?void 0:t.customInlineStyles})}
  </style>
</head>
<body data-normalize-headings="${e.config.normalizeHeadingSizes?"true":"false"}" data-hide-unordered-markers="${e.config.showUnorderedListMarkers===!1?"true":"false"}" data-hide-ordered-markers="${e.config.showOrderedListMarkers===!1?"true":"false"}">
  ${o}
</body>
</html>`}function Jl(e,t){var s;if(typeof window>"u"||typeof document>"u")return!1;const i=pg(e,t);try{const o=document.createElement("iframe");o.style.position="fixed",o.style.right="0",o.style.bottom="0",o.style.width="0",o.style.height="0",o.style.border="none",o.style.visibility="hidden",document.body.appendChild(o);const a=(s=o.contentWindow)==null?void 0:s.document;if(a)return a.open(),a.write(i),a.close(),setTimeout(()=>{var r,l;try{(r=o.contentWindow)==null||r.focus(),(l=o.contentWindow)==null||l.print()}finally{setTimeout(()=>{o.remove()},2e3)}},350),!0}catch(o){console.warn("[pdf-exporter] iframe 打印模式异常，降级尝试 window.open:",o)}const n=window.open("","_blank");return n?(n.document.write(i),n.document.close(),n.focus(),setTimeout(()=>{n.print(),n.close()},350),!0):!1}var cs=typeof globalThis<"u"?globalThis:typeof window<"u"?window:typeof global<"u"?global:typeof self<"u"?self:{};function hg(e){return e&&e.__esModule&&Object.prototype.hasOwnProperty.call(e,"default")?e.default:e}function ds(e){throw new Error('Could not dynamically require "'+e+'". Please configure the dynamicRequireTargets or/and ignoreDynamicRequires option of @rollup/plugin-commonjs appropriately for this require call to work.')}var mo={exports:{}};/*!

JSZip v3.10.1 - A JavaScript class for generating and reading zip files
<http://stuartk.com/jszip>

(c) 2009-2016 Stuart Knightley <stuart [at] stuartk.com>
Dual licenced under the MIT license or GPLv3. See https://raw.github.com/Stuk/jszip/main/LICENSE.markdown.

JSZip uses the library pako released under the MIT license :
https://github.com/nodeca/pako/blob/main/LICENSE
*/var da;function mg(){return da||(da=1,(function(e,t){(function(i){e.exports=i()})(function(){return(function i(n,s,o){function a(c,d){if(!s[c]){if(!n[c]){var p=typeof ds=="function"&&ds;if(!d&&p)return p(c,!0);if(r)return r(c,!0);var u=new Error("Cannot find module '"+c+"'");throw u.code="MODULE_NOT_FOUND",u}var f=s[c]={exports:{}};n[c][0].call(f.exports,function(w){var m=n[c][1][w];return a(m||w)},f,f.exports,i,n,s,o)}return s[c].exports}for(var r=typeof ds=="function"&&ds,l=0;l<o.length;l++)a(o[l]);return a})({1:[function(i,n,s){var o=i("./utils"),a=i("./support"),r="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";s.encode=function(l){for(var c,d,p,u,f,w,m,y=[],b=0,v=l.length,k=v,S=o.getTypeOf(l)!=="string";b<l.length;)k=v-b,p=S?(c=l[b++],d=b<v?l[b++]:0,b<v?l[b++]:0):(c=l.charCodeAt(b++),d=b<v?l.charCodeAt(b++):0,b<v?l.charCodeAt(b++):0),u=c>>2,f=(3&c)<<4|d>>4,w=1<k?(15&d)<<2|p>>6:64,m=2<k?63&p:64,y.push(r.charAt(u)+r.charAt(f)+r.charAt(w)+r.charAt(m));return y.join("")},s.decode=function(l){var c,d,p,u,f,w,m=0,y=0,b="data:";if(l.substr(0,b.length)===b)throw new Error("Invalid base64 input, it looks like a data url.");var v,k=3*(l=l.replace(/[^A-Za-z0-9+/=]/g,"")).length/4;if(l.charAt(l.length-1)===r.charAt(64)&&k--,l.charAt(l.length-2)===r.charAt(64)&&k--,k%1!=0)throw new Error("Invalid base64 input, bad content length.");for(v=a.uint8array?new Uint8Array(0|k):new Array(0|k);m<l.length;)c=r.indexOf(l.charAt(m++))<<2|(u=r.indexOf(l.charAt(m++)))>>4,d=(15&u)<<4|(f=r.indexOf(l.charAt(m++)))>>2,p=(3&f)<<6|(w=r.indexOf(l.charAt(m++))),v[y++]=c,f!==64&&(v[y++]=d),w!==64&&(v[y++]=p);return v}},{"./support":30,"./utils":32}],2:[function(i,n,s){var o=i("./external"),a=i("./stream/DataWorker"),r=i("./stream/Crc32Probe"),l=i("./stream/DataLengthProbe");function c(d,p,u,f,w){this.compressedSize=d,this.uncompressedSize=p,this.crc32=u,this.compression=f,this.compressedContent=w}c.prototype={getContentWorker:function(){var d=new a(o.Promise.resolve(this.compressedContent)).pipe(this.compression.uncompressWorker()).pipe(new l("data_length")),p=this;return d.on("end",function(){if(this.streamInfo.data_length!==p.uncompressedSize)throw new Error("Bug : uncompressed data size mismatch")}),d},getCompressedWorker:function(){return new a(o.Promise.resolve(this.compressedContent)).withStreamInfo("compressedSize",this.compressedSize).withStreamInfo("uncompressedSize",this.uncompressedSize).withStreamInfo("crc32",this.crc32).withStreamInfo("compression",this.compression)}},c.createWorkerFrom=function(d,p,u){return d.pipe(new r).pipe(new l("uncompressedSize")).pipe(p.compressWorker(u)).pipe(new l("compressedSize")).withStreamInfo("compression",p)},n.exports=c},{"./external":6,"./stream/Crc32Probe":25,"./stream/DataLengthProbe":26,"./stream/DataWorker":27}],3:[function(i,n,s){var o=i("./stream/GenericWorker");s.STORE={magic:"\0\0",compressWorker:function(){return new o("STORE compression")},uncompressWorker:function(){return new o("STORE decompression")}},s.DEFLATE=i("./flate")},{"./flate":7,"./stream/GenericWorker":28}],4:[function(i,n,s){var o=i("./utils"),a=(function(){for(var r,l=[],c=0;c<256;c++){r=c;for(var d=0;d<8;d++)r=1&r?3988292384^r>>>1:r>>>1;l[c]=r}return l})();n.exports=function(r,l){return r!==void 0&&r.length?o.getTypeOf(r)!=="string"?(function(c,d,p,u){var f=a,w=u+p;c^=-1;for(var m=u;m<w;m++)c=c>>>8^f[255&(c^d[m])];return-1^c})(0|l,r,r.length,0):(function(c,d,p,u){var f=a,w=u+p;c^=-1;for(var m=u;m<w;m++)c=c>>>8^f[255&(c^d.charCodeAt(m))];return-1^c})(0|l,r,r.length,0):0}},{"./utils":32}],5:[function(i,n,s){s.base64=!1,s.binary=!1,s.dir=!1,s.createFolders=!0,s.date=null,s.compression=null,s.compressionOptions=null,s.comment=null,s.unixPermissions=null,s.dosPermissions=null},{}],6:[function(i,n,s){var o=null;o=typeof Promise<"u"?Promise:i("lie"),n.exports={Promise:o}},{lie:37}],7:[function(i,n,s){var o=typeof Uint8Array<"u"&&typeof Uint16Array<"u"&&typeof Uint32Array<"u",a=i("pako"),r=i("./utils"),l=i("./stream/GenericWorker"),c=o?"uint8array":"array";function d(p,u){l.call(this,"FlateWorker/"+p),this._pako=null,this._pakoAction=p,this._pakoOptions=u,this.meta={}}s.magic="\b\0",r.inherits(d,l),d.prototype.processChunk=function(p){this.meta=p.meta,this._pako===null&&this._createPako(),this._pako.push(r.transformTo(c,p.data),!1)},d.prototype.flush=function(){l.prototype.flush.call(this),this._pako===null&&this._createPako(),this._pako.push([],!0)},d.prototype.cleanUp=function(){l.prototype.cleanUp.call(this),this._pako=null},d.prototype._createPako=function(){this._pako=new a[this._pakoAction]({raw:!0,level:this._pakoOptions.level||-1});var p=this;this._pako.onData=function(u){p.push({data:u,meta:p.meta})}},s.compressWorker=function(p){return new d("Deflate",p)},s.uncompressWorker=function(){return new d("Inflate",{})}},{"./stream/GenericWorker":28,"./utils":32,pako:38}],8:[function(i,n,s){function o(f,w){var m,y="";for(m=0;m<w;m++)y+=String.fromCharCode(255&f),f>>>=8;return y}function a(f,w,m,y,b,v){var k,S,D=f.file,A=f.compression,C=v!==c.utf8encode,L=r.transformTo("string",v(D.name)),z=r.transformTo("string",c.utf8encode(D.name)),N=D.comment,K=r.transformTo("string",v(N)),_=r.transformTo("string",c.utf8encode(N)),U=z.length!==D.name.length,x=_.length!==N.length,q="",O="",$="",T=D.dir,P=D.date,se={crc32:0,compressedSize:0,uncompressedSize:0};w&&!m||(se.crc32=f.crc32,se.compressedSize=f.compressedSize,se.uncompressedSize=f.uncompressedSize);var V=0;w&&(V|=8),C||!U&&!x||(V|=2048);var Y=0,le=0;T&&(Y|=16),b==="UNIX"?(le=798,Y|=(function(oe,Se){var Ie=oe;return oe||(Ie=Se?16893:33204),(65535&Ie)<<16})(D.unixPermissions,T)):(le=20,Y|=(function(oe){return 63&(oe||0)})(D.dosPermissions)),k=P.getUTCHours(),k<<=6,k|=P.getUTCMinutes(),k<<=5,k|=P.getUTCSeconds()/2,S=P.getUTCFullYear()-1980,S<<=4,S|=P.getUTCMonth()+1,S<<=5,S|=P.getUTCDate(),U&&(O=o(1,1)+o(d(L),4)+z,q+="up"+o(O.length,2)+O),x&&($=o(1,1)+o(d(K),4)+_,q+="uc"+o($.length,2)+$);var ie="";return ie+=`
\0`,ie+=o(V,2),ie+=A.magic,ie+=o(k,2),ie+=o(S,2),ie+=o(se.crc32,4),ie+=o(se.compressedSize,4),ie+=o(se.uncompressedSize,4),ie+=o(L.length,2),ie+=o(q.length,2),{fileRecord:p.LOCAL_FILE_HEADER+ie+L+q,dirRecord:p.CENTRAL_FILE_HEADER+o(le,2)+ie+o(K.length,2)+"\0\0\0\0"+o(Y,4)+o(y,4)+L+q+K}}var r=i("../utils"),l=i("../stream/GenericWorker"),c=i("../utf8"),d=i("../crc32"),p=i("../signature");function u(f,w,m,y){l.call(this,"ZipFileWorker"),this.bytesWritten=0,this.zipComment=w,this.zipPlatform=m,this.encodeFileName=y,this.streamFiles=f,this.accumulate=!1,this.contentBuffer=[],this.dirRecords=[],this.currentSourceOffset=0,this.entriesCount=0,this.currentFile=null,this._sources=[]}r.inherits(u,l),u.prototype.push=function(f){var w=f.meta.percent||0,m=this.entriesCount,y=this._sources.length;this.accumulate?this.contentBuffer.push(f):(this.bytesWritten+=f.data.length,l.prototype.push.call(this,{data:f.data,meta:{currentFile:this.currentFile,percent:m?(w+100*(m-y-1))/m:100}}))},u.prototype.openedSource=function(f){this.currentSourceOffset=this.bytesWritten,this.currentFile=f.file.name;var w=this.streamFiles&&!f.file.dir;if(w){var m=a(f,w,!1,this.currentSourceOffset,this.zipPlatform,this.encodeFileName);this.push({data:m.fileRecord,meta:{percent:0}})}else this.accumulate=!0},u.prototype.closedSource=function(f){this.accumulate=!1;var w=this.streamFiles&&!f.file.dir,m=a(f,w,!0,this.currentSourceOffset,this.zipPlatform,this.encodeFileName);if(this.dirRecords.push(m.dirRecord),w)this.push({data:(function(y){return p.DATA_DESCRIPTOR+o(y.crc32,4)+o(y.compressedSize,4)+o(y.uncompressedSize,4)})(f),meta:{percent:100}});else for(this.push({data:m.fileRecord,meta:{percent:0}});this.contentBuffer.length;)this.push(this.contentBuffer.shift());this.currentFile=null},u.prototype.flush=function(){for(var f=this.bytesWritten,w=0;w<this.dirRecords.length;w++)this.push({data:this.dirRecords[w],meta:{percent:100}});var m=this.bytesWritten-f,y=(function(b,v,k,S,D){var A=r.transformTo("string",D(S));return p.CENTRAL_DIRECTORY_END+"\0\0\0\0"+o(b,2)+o(b,2)+o(v,4)+o(k,4)+o(A.length,2)+A})(this.dirRecords.length,m,f,this.zipComment,this.encodeFileName);this.push({data:y,meta:{percent:100}})},u.prototype.prepareNextSource=function(){this.previous=this._sources.shift(),this.openedSource(this.previous.streamInfo),this.isPaused?this.previous.pause():this.previous.resume()},u.prototype.registerPrevious=function(f){this._sources.push(f);var w=this;return f.on("data",function(m){w.processChunk(m)}),f.on("end",function(){w.closedSource(w.previous.streamInfo),w._sources.length?w.prepareNextSource():w.end()}),f.on("error",function(m){w.error(m)}),this},u.prototype.resume=function(){return!!l.prototype.resume.call(this)&&(!this.previous&&this._sources.length?(this.prepareNextSource(),!0):this.previous||this._sources.length||this.generatedError?void 0:(this.end(),!0))},u.prototype.error=function(f){var w=this._sources;if(!l.prototype.error.call(this,f))return!1;for(var m=0;m<w.length;m++)try{w[m].error(f)}catch{}return!0},u.prototype.lock=function(){l.prototype.lock.call(this);for(var f=this._sources,w=0;w<f.length;w++)f[w].lock()},n.exports=u},{"../crc32":4,"../signature":23,"../stream/GenericWorker":28,"../utf8":31,"../utils":32}],9:[function(i,n,s){var o=i("../compressions"),a=i("./ZipFileWorker");s.generateWorker=function(r,l,c){var d=new a(l.streamFiles,c,l.platform,l.encodeFileName),p=0;try{r.forEach(function(u,f){p++;var w=(function(v,k){var S=v||k,D=o[S];if(!D)throw new Error(S+" is not a valid compression method !");return D})(f.options.compression,l.compression),m=f.options.compressionOptions||l.compressionOptions||{},y=f.dir,b=f.date;f._compressWorker(w,m).withStreamInfo("file",{name:u,dir:y,date:b,comment:f.comment||"",unixPermissions:f.unixPermissions,dosPermissions:f.dosPermissions}).pipe(d)}),d.entriesCount=p}catch(u){d.error(u)}return d}},{"../compressions":3,"./ZipFileWorker":8}],10:[function(i,n,s){function o(){if(!(this instanceof o))return new o;if(arguments.length)throw new Error("The constructor with parameters has been removed in JSZip 3.0, please check the upgrade guide.");this.files=Object.create(null),this.comment=null,this.root="",this.clone=function(){var a=new o;for(var r in this)typeof this[r]!="function"&&(a[r]=this[r]);return a}}(o.prototype=i("./object")).loadAsync=i("./load"),o.support=i("./support"),o.defaults=i("./defaults"),o.version="3.10.1",o.loadAsync=function(a,r){return new o().loadAsync(a,r)},o.external=i("./external"),n.exports=o},{"./defaults":5,"./external":6,"./load":11,"./object":15,"./support":30}],11:[function(i,n,s){var o=i("./utils"),a=i("./external"),r=i("./utf8"),l=i("./zipEntries"),c=i("./stream/Crc32Probe"),d=i("./nodejsUtils");function p(u){return new a.Promise(function(f,w){var m=u.decompressed.getContentWorker().pipe(new c);m.on("error",function(y){w(y)}).on("end",function(){m.streamInfo.crc32!==u.decompressed.crc32?w(new Error("Corrupted zip : CRC32 mismatch")):f()}).resume()})}n.exports=function(u,f){var w=this;return f=o.extend(f||{},{base64:!1,checkCRC32:!1,optimizedBinaryString:!1,createFolders:!1,decodeFileName:r.utf8decode}),d.isNode&&d.isStream(u)?a.Promise.reject(new Error("JSZip can't accept a stream when loading a zip file.")):o.prepareContent("the loaded zip file",u,!0,f.optimizedBinaryString,f.base64).then(function(m){var y=new l(f);return y.load(m),y}).then(function(m){var y=[a.Promise.resolve(m)],b=m.files;if(f.checkCRC32)for(var v=0;v<b.length;v++)y.push(p(b[v]));return a.Promise.all(y)}).then(function(m){for(var y=m.shift(),b=y.files,v=0;v<b.length;v++){var k=b[v],S=k.fileNameStr,D=o.resolve(k.fileNameStr);w.file(D,k.decompressed,{binary:!0,optimizedBinaryString:!0,date:k.date,dir:k.dir,comment:k.fileCommentStr.length?k.fileCommentStr:null,unixPermissions:k.unixPermissions,dosPermissions:k.dosPermissions,createFolders:f.createFolders}),k.dir||(w.file(D).unsafeOriginalName=S)}return y.zipComment.length&&(w.comment=y.zipComment),w})}},{"./external":6,"./nodejsUtils":14,"./stream/Crc32Probe":25,"./utf8":31,"./utils":32,"./zipEntries":33}],12:[function(i,n,s){var o=i("../utils"),a=i("../stream/GenericWorker");function r(l,c){a.call(this,"Nodejs stream input adapter for "+l),this._upstreamEnded=!1,this._bindStream(c)}o.inherits(r,a),r.prototype._bindStream=function(l){var c=this;(this._stream=l).pause(),l.on("data",function(d){c.push({data:d,meta:{percent:0}})}).on("error",function(d){c.isPaused?this.generatedError=d:c.error(d)}).on("end",function(){c.isPaused?c._upstreamEnded=!0:c.end()})},r.prototype.pause=function(){return!!a.prototype.pause.call(this)&&(this._stream.pause(),!0)},r.prototype.resume=function(){return!!a.prototype.resume.call(this)&&(this._upstreamEnded?this.end():this._stream.resume(),!0)},n.exports=r},{"../stream/GenericWorker":28,"../utils":32}],13:[function(i,n,s){var o=i("readable-stream").Readable;function a(r,l,c){o.call(this,l),this._helper=r;var d=this;r.on("data",function(p,u){d.push(p)||d._helper.pause(),c&&c(u)}).on("error",function(p){d.emit("error",p)}).on("end",function(){d.push(null)})}i("../utils").inherits(a,o),a.prototype._read=function(){this._helper.resume()},n.exports=a},{"../utils":32,"readable-stream":16}],14:[function(i,n,s){n.exports={isNode:typeof Buffer<"u",newBufferFrom:function(o,a){if(Buffer.from&&Buffer.from!==Uint8Array.from)return Buffer.from(o,a);if(typeof o=="number")throw new Error('The "data" argument must not be a number');return new Buffer(o,a)},allocBuffer:function(o){if(Buffer.alloc)return Buffer.alloc(o);var a=new Buffer(o);return a.fill(0),a},isBuffer:function(o){return Buffer.isBuffer(o)},isStream:function(o){return o&&typeof o.on=="function"&&typeof o.pause=="function"&&typeof o.resume=="function"}}},{}],15:[function(i,n,s){function o(D,A,C){var L,z=r.getTypeOf(A),N=r.extend(C||{},d);N.date=N.date||new Date,N.compression!==null&&(N.compression=N.compression.toUpperCase()),typeof N.unixPermissions=="string"&&(N.unixPermissions=parseInt(N.unixPermissions,8)),N.unixPermissions&&16384&N.unixPermissions&&(N.dir=!0),N.dosPermissions&&16&N.dosPermissions&&(N.dir=!0),N.dir&&(D=b(D)),N.createFolders&&(L=y(D))&&v.call(this,L,!0);var K=z==="string"&&N.binary===!1&&N.base64===!1;C&&C.binary!==void 0||(N.binary=!K),(A instanceof p&&A.uncompressedSize===0||N.dir||!A||A.length===0)&&(N.base64=!1,N.binary=!0,A="",N.compression="STORE",z="string");var _=null;_=A instanceof p||A instanceof l?A:w.isNode&&w.isStream(A)?new m(D,A):r.prepareContent(D,A,N.binary,N.optimizedBinaryString,N.base64);var U=new u(D,_,N);this.files[D]=U}var a=i("./utf8"),r=i("./utils"),l=i("./stream/GenericWorker"),c=i("./stream/StreamHelper"),d=i("./defaults"),p=i("./compressedObject"),u=i("./zipObject"),f=i("./generate"),w=i("./nodejsUtils"),m=i("./nodejs/NodejsStreamInputAdapter"),y=function(D){D.slice(-1)==="/"&&(D=D.substring(0,D.length-1));var A=D.lastIndexOf("/");return 0<A?D.substring(0,A):""},b=function(D){return D.slice(-1)!=="/"&&(D+="/"),D},v=function(D,A){return A=A!==void 0?A:d.createFolders,D=b(D),this.files[D]||o.call(this,D,null,{dir:!0,createFolders:A}),this.files[D]};function k(D){return Object.prototype.toString.call(D)==="[object RegExp]"}var S={load:function(){throw new Error("This method has been removed in JSZip 3.0, please check the upgrade guide.")},forEach:function(D){var A,C,L;for(A in this.files)L=this.files[A],(C=A.slice(this.root.length,A.length))&&A.slice(0,this.root.length)===this.root&&D(C,L)},filter:function(D){var A=[];return this.forEach(function(C,L){D(C,L)&&A.push(L)}),A},file:function(D,A,C){if(arguments.length!==1)return D=this.root+D,o.call(this,D,A,C),this;if(k(D)){var L=D;return this.filter(function(N,K){return!K.dir&&L.test(N)})}var z=this.files[this.root+D];return z&&!z.dir?z:null},folder:function(D){if(!D)return this;if(k(D))return this.filter(function(z,N){return N.dir&&D.test(z)});var A=this.root+D,C=v.call(this,A),L=this.clone();return L.root=C.name,L},remove:function(D){D=this.root+D;var A=this.files[D];if(A||(D.slice(-1)!=="/"&&(D+="/"),A=this.files[D]),A&&!A.dir)delete this.files[D];else for(var C=this.filter(function(z,N){return N.name.slice(0,D.length)===D}),L=0;L<C.length;L++)delete this.files[C[L].name];return this},generate:function(){throw new Error("This method has been removed in JSZip 3.0, please check the upgrade guide.")},generateInternalStream:function(D){var A,C={};try{if((C=r.extend(D||{},{streamFiles:!1,compression:"STORE",compressionOptions:null,type:"",platform:"DOS",comment:null,mimeType:"application/zip",encodeFileName:a.utf8encode})).type=C.type.toLowerCase(),C.compression=C.compression.toUpperCase(),C.type==="binarystring"&&(C.type="string"),!C.type)throw new Error("No output type specified.");r.checkSupport(C.type),C.platform!=="darwin"&&C.platform!=="freebsd"&&C.platform!=="linux"&&C.platform!=="sunos"||(C.platform="UNIX"),C.platform==="win32"&&(C.platform="DOS");var L=C.comment||this.comment||"";A=f.generateWorker(this,C,L)}catch(z){(A=new l("error")).error(z)}return new c(A,C.type||"string",C.mimeType)},generateAsync:function(D,A){return this.generateInternalStream(D).accumulate(A)},generateNodeStream:function(D,A){return(D=D||{}).type||(D.type="nodebuffer"),this.generateInternalStream(D).toNodejsStream(A)}};n.exports=S},{"./compressedObject":2,"./defaults":5,"./generate":9,"./nodejs/NodejsStreamInputAdapter":12,"./nodejsUtils":14,"./stream/GenericWorker":28,"./stream/StreamHelper":29,"./utf8":31,"./utils":32,"./zipObject":35}],16:[function(i,n,s){n.exports=i("stream")},{stream:void 0}],17:[function(i,n,s){var o=i("./DataReader");function a(r){o.call(this,r);for(var l=0;l<this.data.length;l++)r[l]=255&r[l]}i("../utils").inherits(a,o),a.prototype.byteAt=function(r){return this.data[this.zero+r]},a.prototype.lastIndexOfSignature=function(r){for(var l=r.charCodeAt(0),c=r.charCodeAt(1),d=r.charCodeAt(2),p=r.charCodeAt(3),u=this.length-4;0<=u;--u)if(this.data[u]===l&&this.data[u+1]===c&&this.data[u+2]===d&&this.data[u+3]===p)return u-this.zero;return-1},a.prototype.readAndCheckSignature=function(r){var l=r.charCodeAt(0),c=r.charCodeAt(1),d=r.charCodeAt(2),p=r.charCodeAt(3),u=this.readData(4);return l===u[0]&&c===u[1]&&d===u[2]&&p===u[3]},a.prototype.readData=function(r){if(this.checkOffset(r),r===0)return[];var l=this.data.slice(this.zero+this.index,this.zero+this.index+r);return this.index+=r,l},n.exports=a},{"../utils":32,"./DataReader":18}],18:[function(i,n,s){var o=i("../utils");function a(r){this.data=r,this.length=r.length,this.index=0,this.zero=0}a.prototype={checkOffset:function(r){this.checkIndex(this.index+r)},checkIndex:function(r){if(this.length<this.zero+r||r<0)throw new Error("End of data reached (data length = "+this.length+", asked index = "+r+"). Corrupted zip ?")},setIndex:function(r){this.checkIndex(r),this.index=r},skip:function(r){this.setIndex(this.index+r)},byteAt:function(){},readInt:function(r){var l,c=0;for(this.checkOffset(r),l=this.index+r-1;l>=this.index;l--)c=(c<<8)+this.byteAt(l);return this.index+=r,c},readString:function(r){return o.transformTo("string",this.readData(r))},readData:function(){},lastIndexOfSignature:function(){},readAndCheckSignature:function(){},readDate:function(){var r=this.readInt(4);return new Date(Date.UTC(1980+(r>>25&127),(r>>21&15)-1,r>>16&31,r>>11&31,r>>5&63,(31&r)<<1))}},n.exports=a},{"../utils":32}],19:[function(i,n,s){var o=i("./Uint8ArrayReader");function a(r){o.call(this,r)}i("../utils").inherits(a,o),a.prototype.readData=function(r){this.checkOffset(r);var l=this.data.slice(this.zero+this.index,this.zero+this.index+r);return this.index+=r,l},n.exports=a},{"../utils":32,"./Uint8ArrayReader":21}],20:[function(i,n,s){var o=i("./DataReader");function a(r){o.call(this,r)}i("../utils").inherits(a,o),a.prototype.byteAt=function(r){return this.data.charCodeAt(this.zero+r)},a.prototype.lastIndexOfSignature=function(r){return this.data.lastIndexOf(r)-this.zero},a.prototype.readAndCheckSignature=function(r){return r===this.readData(4)},a.prototype.readData=function(r){this.checkOffset(r);var l=this.data.slice(this.zero+this.index,this.zero+this.index+r);return this.index+=r,l},n.exports=a},{"../utils":32,"./DataReader":18}],21:[function(i,n,s){var o=i("./ArrayReader");function a(r){o.call(this,r)}i("../utils").inherits(a,o),a.prototype.readData=function(r){if(this.checkOffset(r),r===0)return new Uint8Array(0);var l=this.data.subarray(this.zero+this.index,this.zero+this.index+r);return this.index+=r,l},n.exports=a},{"../utils":32,"./ArrayReader":17}],22:[function(i,n,s){var o=i("../utils"),a=i("../support"),r=i("./ArrayReader"),l=i("./StringReader"),c=i("./NodeBufferReader"),d=i("./Uint8ArrayReader");n.exports=function(p){var u=o.getTypeOf(p);return o.checkSupport(u),u!=="string"||a.uint8array?u==="nodebuffer"?new c(p):a.uint8array?new d(o.transformTo("uint8array",p)):new r(o.transformTo("array",p)):new l(p)}},{"../support":30,"../utils":32,"./ArrayReader":17,"./NodeBufferReader":19,"./StringReader":20,"./Uint8ArrayReader":21}],23:[function(i,n,s){s.LOCAL_FILE_HEADER="PK",s.CENTRAL_FILE_HEADER="PK",s.CENTRAL_DIRECTORY_END="PK",s.ZIP64_CENTRAL_DIRECTORY_LOCATOR="PK\x07",s.ZIP64_CENTRAL_DIRECTORY_END="PK",s.DATA_DESCRIPTOR="PK\x07\b"},{}],24:[function(i,n,s){var o=i("./GenericWorker"),a=i("../utils");function r(l){o.call(this,"ConvertWorker to "+l),this.destType=l}a.inherits(r,o),r.prototype.processChunk=function(l){this.push({data:a.transformTo(this.destType,l.data),meta:l.meta})},n.exports=r},{"../utils":32,"./GenericWorker":28}],25:[function(i,n,s){var o=i("./GenericWorker"),a=i("../crc32");function r(){o.call(this,"Crc32Probe"),this.withStreamInfo("crc32",0)}i("../utils").inherits(r,o),r.prototype.processChunk=function(l){this.streamInfo.crc32=a(l.data,this.streamInfo.crc32||0),this.push(l)},n.exports=r},{"../crc32":4,"../utils":32,"./GenericWorker":28}],26:[function(i,n,s){var o=i("../utils"),a=i("./GenericWorker");function r(l){a.call(this,"DataLengthProbe for "+l),this.propName=l,this.withStreamInfo(l,0)}o.inherits(r,a),r.prototype.processChunk=function(l){if(l){var c=this.streamInfo[this.propName]||0;this.streamInfo[this.propName]=c+l.data.length}a.prototype.processChunk.call(this,l)},n.exports=r},{"../utils":32,"./GenericWorker":28}],27:[function(i,n,s){var o=i("../utils"),a=i("./GenericWorker");function r(l){a.call(this,"DataWorker");var c=this;this.dataIsReady=!1,this.index=0,this.max=0,this.data=null,this.type="",this._tickScheduled=!1,l.then(function(d){c.dataIsReady=!0,c.data=d,c.max=d&&d.length||0,c.type=o.getTypeOf(d),c.isPaused||c._tickAndRepeat()},function(d){c.error(d)})}o.inherits(r,a),r.prototype.cleanUp=function(){a.prototype.cleanUp.call(this),this.data=null},r.prototype.resume=function(){return!!a.prototype.resume.call(this)&&(!this._tickScheduled&&this.dataIsReady&&(this._tickScheduled=!0,o.delay(this._tickAndRepeat,[],this)),!0)},r.prototype._tickAndRepeat=function(){this._tickScheduled=!1,this.isPaused||this.isFinished||(this._tick(),this.isFinished||(o.delay(this._tickAndRepeat,[],this),this._tickScheduled=!0))},r.prototype._tick=function(){if(this.isPaused||this.isFinished)return!1;var l=null,c=Math.min(this.max,this.index+16384);if(this.index>=this.max)return this.end();switch(this.type){case"string":l=this.data.substring(this.index,c);break;case"uint8array":l=this.data.subarray(this.index,c);break;case"array":case"nodebuffer":l=this.data.slice(this.index,c)}return this.index=c,this.push({data:l,meta:{percent:this.max?this.index/this.max*100:0}})},n.exports=r},{"../utils":32,"./GenericWorker":28}],28:[function(i,n,s){function o(a){this.name=a||"default",this.streamInfo={},this.generatedError=null,this.extraStreamInfo={},this.isPaused=!0,this.isFinished=!1,this.isLocked=!1,this._listeners={data:[],end:[],error:[]},this.previous=null}o.prototype={push:function(a){this.emit("data",a)},end:function(){if(this.isFinished)return!1;this.flush();try{this.emit("end"),this.cleanUp(),this.isFinished=!0}catch(a){this.emit("error",a)}return!0},error:function(a){return!this.isFinished&&(this.isPaused?this.generatedError=a:(this.isFinished=!0,this.emit("error",a),this.previous&&this.previous.error(a),this.cleanUp()),!0)},on:function(a,r){return this._listeners[a].push(r),this},cleanUp:function(){this.streamInfo=this.generatedError=this.extraStreamInfo=null,this._listeners=[]},emit:function(a,r){if(this._listeners[a])for(var l=0;l<this._listeners[a].length;l++)this._listeners[a][l].call(this,r)},pipe:function(a){return a.registerPrevious(this)},registerPrevious:function(a){if(this.isLocked)throw new Error("The stream '"+this+"' has already been used.");this.streamInfo=a.streamInfo,this.mergeStreamInfo(),this.previous=a;var r=this;return a.on("data",function(l){r.processChunk(l)}),a.on("end",function(){r.end()}),a.on("error",function(l){r.error(l)}),this},pause:function(){return!this.isPaused&&!this.isFinished&&(this.isPaused=!0,this.previous&&this.previous.pause(),!0)},resume:function(){if(!this.isPaused||this.isFinished)return!1;var a=this.isPaused=!1;return this.generatedError&&(this.error(this.generatedError),a=!0),this.previous&&this.previous.resume(),!a},flush:function(){},processChunk:function(a){this.push(a)},withStreamInfo:function(a,r){return this.extraStreamInfo[a]=r,this.mergeStreamInfo(),this},mergeStreamInfo:function(){for(var a in this.extraStreamInfo)Object.prototype.hasOwnProperty.call(this.extraStreamInfo,a)&&(this.streamInfo[a]=this.extraStreamInfo[a])},lock:function(){if(this.isLocked)throw new Error("The stream '"+this+"' has already been used.");this.isLocked=!0,this.previous&&this.previous.lock()},toString:function(){var a="Worker "+this.name;return this.previous?this.previous+" -> "+a:a}},n.exports=o},{}],29:[function(i,n,s){var o=i("../utils"),a=i("./ConvertWorker"),r=i("./GenericWorker"),l=i("../base64"),c=i("../support"),d=i("../external"),p=null;if(c.nodestream)try{p=i("../nodejs/NodejsStreamOutputAdapter")}catch{}function u(w,m){return new d.Promise(function(y,b){var v=[],k=w._internalType,S=w._outputType,D=w._mimeType;w.on("data",function(A,C){v.push(A),m&&m(C)}).on("error",function(A){v=[],b(A)}).on("end",function(){try{var A=(function(C,L,z){switch(C){case"blob":return o.newBlob(o.transformTo("arraybuffer",L),z);case"base64":return l.encode(L);default:return o.transformTo(C,L)}})(S,(function(C,L){var z,N=0,K=null,_=0;for(z=0;z<L.length;z++)_+=L[z].length;switch(C){case"string":return L.join("");case"array":return Array.prototype.concat.apply([],L);case"uint8array":for(K=new Uint8Array(_),z=0;z<L.length;z++)K.set(L[z],N),N+=L[z].length;return K;case"nodebuffer":return Buffer.concat(L);default:throw new Error("concat : unsupported type '"+C+"'")}})(k,v),D);y(A)}catch(C){b(C)}v=[]}).resume()})}function f(w,m,y){var b=m;switch(m){case"blob":case"arraybuffer":b="uint8array";break;case"base64":b="string"}try{this._internalType=b,this._outputType=m,this._mimeType=y,o.checkSupport(b),this._worker=w.pipe(new a(b)),w.lock()}catch(v){this._worker=new r("error"),this._worker.error(v)}}f.prototype={accumulate:function(w){return u(this,w)},on:function(w,m){var y=this;return w==="data"?this._worker.on(w,function(b){m.call(y,b.data,b.meta)}):this._worker.on(w,function(){o.delay(m,arguments,y)}),this},resume:function(){return o.delay(this._worker.resume,[],this._worker),this},pause:function(){return this._worker.pause(),this},toNodejsStream:function(w){if(o.checkSupport("nodestream"),this._outputType!=="nodebuffer")throw new Error(this._outputType+" is not supported by this method");return new p(this,{objectMode:this._outputType!=="nodebuffer"},w)}},n.exports=f},{"../base64":1,"../external":6,"../nodejs/NodejsStreamOutputAdapter":13,"../support":30,"../utils":32,"./ConvertWorker":24,"./GenericWorker":28}],30:[function(i,n,s){if(s.base64=!0,s.array=!0,s.string=!0,s.arraybuffer=typeof ArrayBuffer<"u"&&typeof Uint8Array<"u",s.nodebuffer=typeof Buffer<"u",s.uint8array=typeof Uint8Array<"u",typeof ArrayBuffer>"u")s.blob=!1;else{var o=new ArrayBuffer(0);try{s.blob=new Blob([o],{type:"application/zip"}).size===0}catch{try{var a=new(self.BlobBuilder||self.WebKitBlobBuilder||self.MozBlobBuilder||self.MSBlobBuilder);a.append(o),s.blob=a.getBlob("application/zip").size===0}catch{s.blob=!1}}}try{s.nodestream=!!i("readable-stream").Readable}catch{s.nodestream=!1}},{"readable-stream":16}],31:[function(i,n,s){for(var o=i("./utils"),a=i("./support"),r=i("./nodejsUtils"),l=i("./stream/GenericWorker"),c=new Array(256),d=0;d<256;d++)c[d]=252<=d?6:248<=d?5:240<=d?4:224<=d?3:192<=d?2:1;c[254]=c[254]=1;function p(){l.call(this,"utf-8 decode"),this.leftOver=null}function u(){l.call(this,"utf-8 encode")}s.utf8encode=function(f){return a.nodebuffer?r.newBufferFrom(f,"utf-8"):(function(w){var m,y,b,v,k,S=w.length,D=0;for(v=0;v<S;v++)(64512&(y=w.charCodeAt(v)))==55296&&v+1<S&&(64512&(b=w.charCodeAt(v+1)))==56320&&(y=65536+(y-55296<<10)+(b-56320),v++),D+=y<128?1:y<2048?2:y<65536?3:4;for(m=a.uint8array?new Uint8Array(D):new Array(D),v=k=0;k<D;v++)(64512&(y=w.charCodeAt(v)))==55296&&v+1<S&&(64512&(b=w.charCodeAt(v+1)))==56320&&(y=65536+(y-55296<<10)+(b-56320),v++),y<128?m[k++]=y:(y<2048?m[k++]=192|y>>>6:(y<65536?m[k++]=224|y>>>12:(m[k++]=240|y>>>18,m[k++]=128|y>>>12&63),m[k++]=128|y>>>6&63),m[k++]=128|63&y);return m})(f)},s.utf8decode=function(f){return a.nodebuffer?o.transformTo("nodebuffer",f).toString("utf-8"):(function(w){var m,y,b,v,k=w.length,S=new Array(2*k);for(m=y=0;m<k;)if((b=w[m++])<128)S[y++]=b;else if(4<(v=c[b]))S[y++]=65533,m+=v-1;else{for(b&=v===2?31:v===3?15:7;1<v&&m<k;)b=b<<6|63&w[m++],v--;1<v?S[y++]=65533:b<65536?S[y++]=b:(b-=65536,S[y++]=55296|b>>10&1023,S[y++]=56320|1023&b)}return S.length!==y&&(S.subarray?S=S.subarray(0,y):S.length=y),o.applyFromCharCode(S)})(f=o.transformTo(a.uint8array?"uint8array":"array",f))},o.inherits(p,l),p.prototype.processChunk=function(f){var w=o.transformTo(a.uint8array?"uint8array":"array",f.data);if(this.leftOver&&this.leftOver.length){if(a.uint8array){var m=w;(w=new Uint8Array(m.length+this.leftOver.length)).set(this.leftOver,0),w.set(m,this.leftOver.length)}else w=this.leftOver.concat(w);this.leftOver=null}var y=(function(v,k){var S;for((k=k||v.length)>v.length&&(k=v.length),S=k-1;0<=S&&(192&v[S])==128;)S--;return S<0||S===0?k:S+c[v[S]]>k?S:k})(w),b=w;y!==w.length&&(a.uint8array?(b=w.subarray(0,y),this.leftOver=w.subarray(y,w.length)):(b=w.slice(0,y),this.leftOver=w.slice(y,w.length))),this.push({data:s.utf8decode(b),meta:f.meta})},p.prototype.flush=function(){this.leftOver&&this.leftOver.length&&(this.push({data:s.utf8decode(this.leftOver),meta:{}}),this.leftOver=null)},s.Utf8DecodeWorker=p,o.inherits(u,l),u.prototype.processChunk=function(f){this.push({data:s.utf8encode(f.data),meta:f.meta})},s.Utf8EncodeWorker=u},{"./nodejsUtils":14,"./stream/GenericWorker":28,"./support":30,"./utils":32}],32:[function(i,n,s){var o=i("./support"),a=i("./base64"),r=i("./nodejsUtils"),l=i("./external");function c(m){return m}function d(m,y){for(var b=0;b<m.length;++b)y[b]=255&m.charCodeAt(b);return y}i("setimmediate"),s.newBlob=function(m,y){s.checkSupport("blob");try{return new Blob([m],{type:y})}catch{try{var b=new(self.BlobBuilder||self.WebKitBlobBuilder||self.MozBlobBuilder||self.MSBlobBuilder);return b.append(m),b.getBlob(y)}catch{throw new Error("Bug : can't construct the Blob.")}}};var p={stringifyByChunk:function(m,y,b){var v=[],k=0,S=m.length;if(S<=b)return String.fromCharCode.apply(null,m);for(;k<S;)y==="array"||y==="nodebuffer"?v.push(String.fromCharCode.apply(null,m.slice(k,Math.min(k+b,S)))):v.push(String.fromCharCode.apply(null,m.subarray(k,Math.min(k+b,S)))),k+=b;return v.join("")},stringifyByChar:function(m){for(var y="",b=0;b<m.length;b++)y+=String.fromCharCode(m[b]);return y},applyCanBeUsed:{uint8array:(function(){try{return o.uint8array&&String.fromCharCode.apply(null,new Uint8Array(1)).length===1}catch{return!1}})(),nodebuffer:(function(){try{return o.nodebuffer&&String.fromCharCode.apply(null,r.allocBuffer(1)).length===1}catch{return!1}})()}};function u(m){var y=65536,b=s.getTypeOf(m),v=!0;if(b==="uint8array"?v=p.applyCanBeUsed.uint8array:b==="nodebuffer"&&(v=p.applyCanBeUsed.nodebuffer),v)for(;1<y;)try{return p.stringifyByChunk(m,b,y)}catch{y=Math.floor(y/2)}return p.stringifyByChar(m)}function f(m,y){for(var b=0;b<m.length;b++)y[b]=m[b];return y}s.applyFromCharCode=u;var w={};w.string={string:c,array:function(m){return d(m,new Array(m.length))},arraybuffer:function(m){return w.string.uint8array(m).buffer},uint8array:function(m){return d(m,new Uint8Array(m.length))},nodebuffer:function(m){return d(m,r.allocBuffer(m.length))}},w.array={string:u,array:c,arraybuffer:function(m){return new Uint8Array(m).buffer},uint8array:function(m){return new Uint8Array(m)},nodebuffer:function(m){return r.newBufferFrom(m)}},w.arraybuffer={string:function(m){return u(new Uint8Array(m))},array:function(m){return f(new Uint8Array(m),new Array(m.byteLength))},arraybuffer:c,uint8array:function(m){return new Uint8Array(m)},nodebuffer:function(m){return r.newBufferFrom(new Uint8Array(m))}},w.uint8array={string:u,array:function(m){return f(m,new Array(m.length))},arraybuffer:function(m){return m.buffer},uint8array:c,nodebuffer:function(m){return r.newBufferFrom(m)}},w.nodebuffer={string:u,array:function(m){return f(m,new Array(m.length))},arraybuffer:function(m){return w.nodebuffer.uint8array(m).buffer},uint8array:function(m){return f(m,new Uint8Array(m.length))},nodebuffer:c},s.transformTo=function(m,y){if(y=y||"",!m)return y;s.checkSupport(m);var b=s.getTypeOf(y);return w[b][m](y)},s.resolve=function(m){for(var y=m.split("/"),b=[],v=0;v<y.length;v++){var k=y[v];k==="."||k===""&&v!==0&&v!==y.length-1||(k===".."?b.pop():b.push(k))}return b.join("/")},s.getTypeOf=function(m){return typeof m=="string"?"string":Object.prototype.toString.call(m)==="[object Array]"?"array":o.nodebuffer&&r.isBuffer(m)?"nodebuffer":o.uint8array&&m instanceof Uint8Array?"uint8array":o.arraybuffer&&m instanceof ArrayBuffer?"arraybuffer":void 0},s.checkSupport=function(m){if(!o[m.toLowerCase()])throw new Error(m+" is not supported by this platform")},s.MAX_VALUE_16BITS=65535,s.MAX_VALUE_32BITS=-1,s.pretty=function(m){var y,b,v="";for(b=0;b<(m||"").length;b++)v+="\\x"+((y=m.charCodeAt(b))<16?"0":"")+y.toString(16).toUpperCase();return v},s.delay=function(m,y,b){setImmediate(function(){m.apply(b||null,y||[])})},s.inherits=function(m,y){function b(){}b.prototype=y.prototype,m.prototype=new b},s.extend=function(){var m,y,b={};for(m=0;m<arguments.length;m++)for(y in arguments[m])Object.prototype.hasOwnProperty.call(arguments[m],y)&&b[y]===void 0&&(b[y]=arguments[m][y]);return b},s.prepareContent=function(m,y,b,v,k){return l.Promise.resolve(y).then(function(S){return o.blob&&(S instanceof Blob||["[object File]","[object Blob]"].indexOf(Object.prototype.toString.call(S))!==-1)&&typeof FileReader<"u"?new l.Promise(function(D,A){var C=new FileReader;C.onload=function(L){D(L.target.result)},C.onerror=function(L){A(L.target.error)},C.readAsArrayBuffer(S)}):S}).then(function(S){var D=s.getTypeOf(S);return D?(D==="arraybuffer"?S=s.transformTo("uint8array",S):D==="string"&&(k?S=a.decode(S):b&&v!==!0&&(S=(function(A){return d(A,o.uint8array?new Uint8Array(A.length):new Array(A.length))})(S))),S):l.Promise.reject(new Error("Can't read the data of '"+m+"'. Is it in a supported JavaScript type (String, Blob, ArrayBuffer, etc) ?"))})}},{"./base64":1,"./external":6,"./nodejsUtils":14,"./support":30,setimmediate:54}],33:[function(i,n,s){var o=i("./reader/readerFor"),a=i("./utils"),r=i("./signature"),l=i("./zipEntry"),c=i("./support");function d(p){this.files=[],this.loadOptions=p}d.prototype={checkSignature:function(p){if(!this.reader.readAndCheckSignature(p)){this.reader.index-=4;var u=this.reader.readString(4);throw new Error("Corrupted zip or bug: unexpected signature ("+a.pretty(u)+", expected "+a.pretty(p)+")")}},isSignature:function(p,u){var f=this.reader.index;this.reader.setIndex(p);var w=this.reader.readString(4)===u;return this.reader.setIndex(f),w},readBlockEndOfCentral:function(){this.diskNumber=this.reader.readInt(2),this.diskWithCentralDirStart=this.reader.readInt(2),this.centralDirRecordsOnThisDisk=this.reader.readInt(2),this.centralDirRecords=this.reader.readInt(2),this.centralDirSize=this.reader.readInt(4),this.centralDirOffset=this.reader.readInt(4),this.zipCommentLength=this.reader.readInt(2);var p=this.reader.readData(this.zipCommentLength),u=c.uint8array?"uint8array":"array",f=a.transformTo(u,p);this.zipComment=this.loadOptions.decodeFileName(f)},readBlockZip64EndOfCentral:function(){this.zip64EndOfCentralSize=this.reader.readInt(8),this.reader.skip(4),this.diskNumber=this.reader.readInt(4),this.diskWithCentralDirStart=this.reader.readInt(4),this.centralDirRecordsOnThisDisk=this.reader.readInt(8),this.centralDirRecords=this.reader.readInt(8),this.centralDirSize=this.reader.readInt(8),this.centralDirOffset=this.reader.readInt(8),this.zip64ExtensibleData={};for(var p,u,f,w=this.zip64EndOfCentralSize-44;0<w;)p=this.reader.readInt(2),u=this.reader.readInt(4),f=this.reader.readData(u),this.zip64ExtensibleData[p]={id:p,length:u,value:f}},readBlockZip64EndOfCentralLocator:function(){if(this.diskWithZip64CentralDirStart=this.reader.readInt(4),this.relativeOffsetEndOfZip64CentralDir=this.reader.readInt(8),this.disksCount=this.reader.readInt(4),1<this.disksCount)throw new Error("Multi-volumes zip are not supported")},readLocalFiles:function(){var p,u;for(p=0;p<this.files.length;p++)u=this.files[p],this.reader.setIndex(u.localHeaderOffset),this.checkSignature(r.LOCAL_FILE_HEADER),u.readLocalPart(this.reader),u.handleUTF8(),u.processAttributes()},readCentralDir:function(){var p;for(this.reader.setIndex(this.centralDirOffset);this.reader.readAndCheckSignature(r.CENTRAL_FILE_HEADER);)(p=new l({zip64:this.zip64},this.loadOptions)).readCentralPart(this.reader),this.files.push(p);if(this.centralDirRecords!==this.files.length&&this.centralDirRecords!==0&&this.files.length===0)throw new Error("Corrupted zip or bug: expected "+this.centralDirRecords+" records in central dir, got "+this.files.length)},readEndOfCentral:function(){var p=this.reader.lastIndexOfSignature(r.CENTRAL_DIRECTORY_END);if(p<0)throw this.isSignature(0,r.LOCAL_FILE_HEADER)?new Error("Corrupted zip: can't find end of central directory"):new Error("Can't find end of central directory : is this a zip file ? If it is, see https://stuk.github.io/jszip/documentation/howto/read_zip.html");this.reader.setIndex(p);var u=p;if(this.checkSignature(r.CENTRAL_DIRECTORY_END),this.readBlockEndOfCentral(),this.diskNumber===a.MAX_VALUE_16BITS||this.diskWithCentralDirStart===a.MAX_VALUE_16BITS||this.centralDirRecordsOnThisDisk===a.MAX_VALUE_16BITS||this.centralDirRecords===a.MAX_VALUE_16BITS||this.centralDirSize===a.MAX_VALUE_32BITS||this.centralDirOffset===a.MAX_VALUE_32BITS){if(this.zip64=!0,(p=this.reader.lastIndexOfSignature(r.ZIP64_CENTRAL_DIRECTORY_LOCATOR))<0)throw new Error("Corrupted zip: can't find the ZIP64 end of central directory locator");if(this.reader.setIndex(p),this.checkSignature(r.ZIP64_CENTRAL_DIRECTORY_LOCATOR),this.readBlockZip64EndOfCentralLocator(),!this.isSignature(this.relativeOffsetEndOfZip64CentralDir,r.ZIP64_CENTRAL_DIRECTORY_END)&&(this.relativeOffsetEndOfZip64CentralDir=this.reader.lastIndexOfSignature(r.ZIP64_CENTRAL_DIRECTORY_END),this.relativeOffsetEndOfZip64CentralDir<0))throw new Error("Corrupted zip: can't find the ZIP64 end of central directory");this.reader.setIndex(this.relativeOffsetEndOfZip64CentralDir),this.checkSignature(r.ZIP64_CENTRAL_DIRECTORY_END),this.readBlockZip64EndOfCentral()}var f=this.centralDirOffset+this.centralDirSize;this.zip64&&(f+=20,f+=12+this.zip64EndOfCentralSize);var w=u-f;if(0<w)this.isSignature(u,r.CENTRAL_FILE_HEADER)||(this.reader.zero=w);else if(w<0)throw new Error("Corrupted zip: missing "+Math.abs(w)+" bytes.")},prepareReader:function(p){this.reader=o(p)},load:function(p){this.prepareReader(p),this.readEndOfCentral(),this.readCentralDir(),this.readLocalFiles()}},n.exports=d},{"./reader/readerFor":22,"./signature":23,"./support":30,"./utils":32,"./zipEntry":34}],34:[function(i,n,s){var o=i("./reader/readerFor"),a=i("./utils"),r=i("./compressedObject"),l=i("./crc32"),c=i("./utf8"),d=i("./compressions"),p=i("./support");function u(f,w){this.options=f,this.loadOptions=w}u.prototype={isEncrypted:function(){return(1&this.bitFlag)==1},useUTF8:function(){return(2048&this.bitFlag)==2048},readLocalPart:function(f){var w,m;if(f.skip(22),this.fileNameLength=f.readInt(2),m=f.readInt(2),this.fileName=f.readData(this.fileNameLength),f.skip(m),this.compressedSize===-1||this.uncompressedSize===-1)throw new Error("Bug or corrupted zip : didn't get enough information from the central directory (compressedSize === -1 || uncompressedSize === -1)");if((w=(function(y){for(var b in d)if(Object.prototype.hasOwnProperty.call(d,b)&&d[b].magic===y)return d[b];return null})(this.compressionMethod))===null)throw new Error("Corrupted zip : compression "+a.pretty(this.compressionMethod)+" unknown (inner file : "+a.transformTo("string",this.fileName)+")");this.decompressed=new r(this.compressedSize,this.uncompressedSize,this.crc32,w,f.readData(this.compressedSize))},readCentralPart:function(f){this.versionMadeBy=f.readInt(2),f.skip(2),this.bitFlag=f.readInt(2),this.compressionMethod=f.readString(2),this.date=f.readDate(),this.crc32=f.readInt(4),this.compressedSize=f.readInt(4),this.uncompressedSize=f.readInt(4);var w=f.readInt(2);if(this.extraFieldsLength=f.readInt(2),this.fileCommentLength=f.readInt(2),this.diskNumberStart=f.readInt(2),this.internalFileAttributes=f.readInt(2),this.externalFileAttributes=f.readInt(4),this.localHeaderOffset=f.readInt(4),this.isEncrypted())throw new Error("Encrypted zip are not supported");f.skip(w),this.readExtraFields(f),this.parseZIP64ExtraField(f),this.fileComment=f.readData(this.fileCommentLength)},processAttributes:function(){this.unixPermissions=null,this.dosPermissions=null;var f=this.versionMadeBy>>8;this.dir=!!(16&this.externalFileAttributes),f==0&&(this.dosPermissions=63&this.externalFileAttributes),f==3&&(this.unixPermissions=this.externalFileAttributes>>16&65535),this.dir||this.fileNameStr.slice(-1)!=="/"||(this.dir=!0)},parseZIP64ExtraField:function(){if(this.extraFields[1]){var f=o(this.extraFields[1].value);this.uncompressedSize===a.MAX_VALUE_32BITS&&(this.uncompressedSize=f.readInt(8)),this.compressedSize===a.MAX_VALUE_32BITS&&(this.compressedSize=f.readInt(8)),this.localHeaderOffset===a.MAX_VALUE_32BITS&&(this.localHeaderOffset=f.readInt(8)),this.diskNumberStart===a.MAX_VALUE_32BITS&&(this.diskNumberStart=f.readInt(4))}},readExtraFields:function(f){var w,m,y,b=f.index+this.extraFieldsLength;for(this.extraFields||(this.extraFields={});f.index+4<b;)w=f.readInt(2),m=f.readInt(2),y=f.readData(m),this.extraFields[w]={id:w,length:m,value:y};f.setIndex(b)},handleUTF8:function(){var f=p.uint8array?"uint8array":"array";if(this.useUTF8())this.fileNameStr=c.utf8decode(this.fileName),this.fileCommentStr=c.utf8decode(this.fileComment);else{var w=this.findExtraFieldUnicodePath();if(w!==null)this.fileNameStr=w;else{var m=a.transformTo(f,this.fileName);this.fileNameStr=this.loadOptions.decodeFileName(m)}var y=this.findExtraFieldUnicodeComment();if(y!==null)this.fileCommentStr=y;else{var b=a.transformTo(f,this.fileComment);this.fileCommentStr=this.loadOptions.decodeFileName(b)}}},findExtraFieldUnicodePath:function(){var f=this.extraFields[28789];if(f){var w=o(f.value);return w.readInt(1)!==1||l(this.fileName)!==w.readInt(4)?null:c.utf8decode(w.readData(f.length-5))}return null},findExtraFieldUnicodeComment:function(){var f=this.extraFields[25461];if(f){var w=o(f.value);return w.readInt(1)!==1||l(this.fileComment)!==w.readInt(4)?null:c.utf8decode(w.readData(f.length-5))}return null}},n.exports=u},{"./compressedObject":2,"./compressions":3,"./crc32":4,"./reader/readerFor":22,"./support":30,"./utf8":31,"./utils":32}],35:[function(i,n,s){function o(w,m,y){this.name=w,this.dir=y.dir,this.date=y.date,this.comment=y.comment,this.unixPermissions=y.unixPermissions,this.dosPermissions=y.dosPermissions,this._data=m,this._dataBinary=y.binary,this.options={compression:y.compression,compressionOptions:y.compressionOptions}}var a=i("./stream/StreamHelper"),r=i("./stream/DataWorker"),l=i("./utf8"),c=i("./compressedObject"),d=i("./stream/GenericWorker");o.prototype={internalStream:function(w){var m=null,y="string";try{if(!w)throw new Error("No output type specified.");var b=(y=w.toLowerCase())==="string"||y==="text";y!=="binarystring"&&y!=="text"||(y="string"),m=this._decompressWorker();var v=!this._dataBinary;v&&!b&&(m=m.pipe(new l.Utf8EncodeWorker)),!v&&b&&(m=m.pipe(new l.Utf8DecodeWorker))}catch(k){(m=new d("error")).error(k)}return new a(m,y,"")},async:function(w,m){return this.internalStream(w).accumulate(m)},nodeStream:function(w,m){return this.internalStream(w||"nodebuffer").toNodejsStream(m)},_compressWorker:function(w,m){if(this._data instanceof c&&this._data.compression.magic===w.magic)return this._data.getCompressedWorker();var y=this._decompressWorker();return this._dataBinary||(y=y.pipe(new l.Utf8EncodeWorker)),c.createWorkerFrom(y,w,m)},_decompressWorker:function(){return this._data instanceof c?this._data.getContentWorker():this._data instanceof d?this._data:new r(this._data)}};for(var p=["asText","asBinary","asNodeBuffer","asUint8Array","asArrayBuffer"],u=function(){throw new Error("This method has been removed in JSZip 3.0, please check the upgrade guide.")},f=0;f<p.length;f++)o.prototype[p[f]]=u;n.exports=o},{"./compressedObject":2,"./stream/DataWorker":27,"./stream/GenericWorker":28,"./stream/StreamHelper":29,"./utf8":31}],36:[function(i,n,s){(function(o){var a,r,l=o.MutationObserver||o.WebKitMutationObserver;if(l){var c=0,d=new l(w),p=o.document.createTextNode("");d.observe(p,{characterData:!0}),a=function(){p.data=c=++c%2}}else if(o.setImmediate||o.MessageChannel===void 0)a="document"in o&&"onreadystatechange"in o.document.createElement("script")?function(){var m=o.document.createElement("script");m.onreadystatechange=function(){w(),m.onreadystatechange=null,m.parentNode.removeChild(m),m=null},o.document.documentElement.appendChild(m)}:function(){setTimeout(w,0)};else{var u=new o.MessageChannel;u.port1.onmessage=w,a=function(){u.port2.postMessage(0)}}var f=[];function w(){var m,y;r=!0;for(var b=f.length;b;){for(y=f,f=[],m=-1;++m<b;)y[m]();b=f.length}r=!1}n.exports=function(m){f.push(m)!==1||r||a()}}).call(this,typeof cs<"u"?cs:typeof self<"u"?self:typeof window<"u"?window:{})},{}],37:[function(i,n,s){var o=i("immediate");function a(){}var r={},l=["REJECTED"],c=["FULFILLED"],d=["PENDING"];function p(b){if(typeof b!="function")throw new TypeError("resolver must be a function");this.state=d,this.queue=[],this.outcome=void 0,b!==a&&m(this,b)}function u(b,v,k){this.promise=b,typeof v=="function"&&(this.onFulfilled=v,this.callFulfilled=this.otherCallFulfilled),typeof k=="function"&&(this.onRejected=k,this.callRejected=this.otherCallRejected)}function f(b,v,k){o(function(){var S;try{S=v(k)}catch(D){return r.reject(b,D)}S===b?r.reject(b,new TypeError("Cannot resolve promise with itself")):r.resolve(b,S)})}function w(b){var v=b&&b.then;if(b&&(typeof b=="object"||typeof b=="function")&&typeof v=="function")return function(){v.apply(b,arguments)}}function m(b,v){var k=!1;function S(C){k||(k=!0,r.reject(b,C))}function D(C){k||(k=!0,r.resolve(b,C))}var A=y(function(){v(D,S)});A.status==="error"&&S(A.value)}function y(b,v){var k={};try{k.value=b(v),k.status="success"}catch(S){k.status="error",k.value=S}return k}(n.exports=p).prototype.finally=function(b){if(typeof b!="function")return this;var v=this.constructor;return this.then(function(k){return v.resolve(b()).then(function(){return k})},function(k){return v.resolve(b()).then(function(){throw k})})},p.prototype.catch=function(b){return this.then(null,b)},p.prototype.then=function(b,v){if(typeof b!="function"&&this.state===c||typeof v!="function"&&this.state===l)return this;var k=new this.constructor(a);return this.state!==d?f(k,this.state===c?b:v,this.outcome):this.queue.push(new u(k,b,v)),k},u.prototype.callFulfilled=function(b){r.resolve(this.promise,b)},u.prototype.otherCallFulfilled=function(b){f(this.promise,this.onFulfilled,b)},u.prototype.callRejected=function(b){r.reject(this.promise,b)},u.prototype.otherCallRejected=function(b){f(this.promise,this.onRejected,b)},r.resolve=function(b,v){var k=y(w,v);if(k.status==="error")return r.reject(b,k.value);var S=k.value;if(S)m(b,S);else{b.state=c,b.outcome=v;for(var D=-1,A=b.queue.length;++D<A;)b.queue[D].callFulfilled(v)}return b},r.reject=function(b,v){b.state=l,b.outcome=v;for(var k=-1,S=b.queue.length;++k<S;)b.queue[k].callRejected(v);return b},p.resolve=function(b){return b instanceof this?b:r.resolve(new this(a),b)},p.reject=function(b){var v=new this(a);return r.reject(v,b)},p.all=function(b){var v=this;if(Object.prototype.toString.call(b)!=="[object Array]")return this.reject(new TypeError("must be an array"));var k=b.length,S=!1;if(!k)return this.resolve([]);for(var D=new Array(k),A=0,C=-1,L=new this(a);++C<k;)z(b[C],C);return L;function z(N,K){v.resolve(N).then(function(_){D[K]=_,++A!==k||S||(S=!0,r.resolve(L,D))},function(_){S||(S=!0,r.reject(L,_))})}},p.race=function(b){var v=this;if(Object.prototype.toString.call(b)!=="[object Array]")return this.reject(new TypeError("must be an array"));var k=b.length,S=!1;if(!k)return this.resolve([]);for(var D=-1,A=new this(a);++D<k;)C=b[D],v.resolve(C).then(function(L){S||(S=!0,r.resolve(A,L))},function(L){S||(S=!0,r.reject(A,L))});var C;return A}},{immediate:36}],38:[function(i,n,s){var o={};(0,i("./lib/utils/common").assign)(o,i("./lib/deflate"),i("./lib/inflate"),i("./lib/zlib/constants")),n.exports=o},{"./lib/deflate":39,"./lib/inflate":40,"./lib/utils/common":41,"./lib/zlib/constants":44}],39:[function(i,n,s){var o=i("./zlib/deflate"),a=i("./utils/common"),r=i("./utils/strings"),l=i("./zlib/messages"),c=i("./zlib/zstream"),d=Object.prototype.toString,p=0,u=-1,f=0,w=8;function m(b){if(!(this instanceof m))return new m(b);this.options=a.assign({level:u,method:w,chunkSize:16384,windowBits:15,memLevel:8,strategy:f,to:""},b||{});var v=this.options;v.raw&&0<v.windowBits?v.windowBits=-v.windowBits:v.gzip&&0<v.windowBits&&v.windowBits<16&&(v.windowBits+=16),this.err=0,this.msg="",this.ended=!1,this.chunks=[],this.strm=new c,this.strm.avail_out=0;var k=o.deflateInit2(this.strm,v.level,v.method,v.windowBits,v.memLevel,v.strategy);if(k!==p)throw new Error(l[k]);if(v.header&&o.deflateSetHeader(this.strm,v.header),v.dictionary){var S;if(S=typeof v.dictionary=="string"?r.string2buf(v.dictionary):d.call(v.dictionary)==="[object ArrayBuffer]"?new Uint8Array(v.dictionary):v.dictionary,(k=o.deflateSetDictionary(this.strm,S))!==p)throw new Error(l[k]);this._dict_set=!0}}function y(b,v){var k=new m(v);if(k.push(b,!0),k.err)throw k.msg||l[k.err];return k.result}m.prototype.push=function(b,v){var k,S,D=this.strm,A=this.options.chunkSize;if(this.ended)return!1;S=v===~~v?v:v===!0?4:0,typeof b=="string"?D.input=r.string2buf(b):d.call(b)==="[object ArrayBuffer]"?D.input=new Uint8Array(b):D.input=b,D.next_in=0,D.avail_in=D.input.length;do{if(D.avail_out===0&&(D.output=new a.Buf8(A),D.next_out=0,D.avail_out=A),(k=o.deflate(D,S))!==1&&k!==p)return this.onEnd(k),!(this.ended=!0);D.avail_out!==0&&(D.avail_in!==0||S!==4&&S!==2)||(this.options.to==="string"?this.onData(r.buf2binstring(a.shrinkBuf(D.output,D.next_out))):this.onData(a.shrinkBuf(D.output,D.next_out)))}while((0<D.avail_in||D.avail_out===0)&&k!==1);return S===4?(k=o.deflateEnd(this.strm),this.onEnd(k),this.ended=!0,k===p):S!==2||(this.onEnd(p),!(D.avail_out=0))},m.prototype.onData=function(b){this.chunks.push(b)},m.prototype.onEnd=function(b){b===p&&(this.options.to==="string"?this.result=this.chunks.join(""):this.result=a.flattenChunks(this.chunks)),this.chunks=[],this.err=b,this.msg=this.strm.msg},s.Deflate=m,s.deflate=y,s.deflateRaw=function(b,v){return(v=v||{}).raw=!0,y(b,v)},s.gzip=function(b,v){return(v=v||{}).gzip=!0,y(b,v)}},{"./utils/common":41,"./utils/strings":42,"./zlib/deflate":46,"./zlib/messages":51,"./zlib/zstream":53}],40:[function(i,n,s){var o=i("./zlib/inflate"),a=i("./utils/common"),r=i("./utils/strings"),l=i("./zlib/constants"),c=i("./zlib/messages"),d=i("./zlib/zstream"),p=i("./zlib/gzheader"),u=Object.prototype.toString;function f(m){if(!(this instanceof f))return new f(m);this.options=a.assign({chunkSize:16384,windowBits:0,to:""},m||{});var y=this.options;y.raw&&0<=y.windowBits&&y.windowBits<16&&(y.windowBits=-y.windowBits,y.windowBits===0&&(y.windowBits=-15)),!(0<=y.windowBits&&y.windowBits<16)||m&&m.windowBits||(y.windowBits+=32),15<y.windowBits&&y.windowBits<48&&(15&y.windowBits)==0&&(y.windowBits|=15),this.err=0,this.msg="",this.ended=!1,this.chunks=[],this.strm=new d,this.strm.avail_out=0;var b=o.inflateInit2(this.strm,y.windowBits);if(b!==l.Z_OK)throw new Error(c[b]);this.header=new p,o.inflateGetHeader(this.strm,this.header)}function w(m,y){var b=new f(y);if(b.push(m,!0),b.err)throw b.msg||c[b.err];return b.result}f.prototype.push=function(m,y){var b,v,k,S,D,A,C=this.strm,L=this.options.chunkSize,z=this.options.dictionary,N=!1;if(this.ended)return!1;v=y===~~y?y:y===!0?l.Z_FINISH:l.Z_NO_FLUSH,typeof m=="string"?C.input=r.binstring2buf(m):u.call(m)==="[object ArrayBuffer]"?C.input=new Uint8Array(m):C.input=m,C.next_in=0,C.avail_in=C.input.length;do{if(C.avail_out===0&&(C.output=new a.Buf8(L),C.next_out=0,C.avail_out=L),(b=o.inflate(C,l.Z_NO_FLUSH))===l.Z_NEED_DICT&&z&&(A=typeof z=="string"?r.string2buf(z):u.call(z)==="[object ArrayBuffer]"?new Uint8Array(z):z,b=o.inflateSetDictionary(this.strm,A)),b===l.Z_BUF_ERROR&&N===!0&&(b=l.Z_OK,N=!1),b!==l.Z_STREAM_END&&b!==l.Z_OK)return this.onEnd(b),!(this.ended=!0);C.next_out&&(C.avail_out!==0&&b!==l.Z_STREAM_END&&(C.avail_in!==0||v!==l.Z_FINISH&&v!==l.Z_SYNC_FLUSH)||(this.options.to==="string"?(k=r.utf8border(C.output,C.next_out),S=C.next_out-k,D=r.buf2string(C.output,k),C.next_out=S,C.avail_out=L-S,S&&a.arraySet(C.output,C.output,k,S,0),this.onData(D)):this.onData(a.shrinkBuf(C.output,C.next_out)))),C.avail_in===0&&C.avail_out===0&&(N=!0)}while((0<C.avail_in||C.avail_out===0)&&b!==l.Z_STREAM_END);return b===l.Z_STREAM_END&&(v=l.Z_FINISH),v===l.Z_FINISH?(b=o.inflateEnd(this.strm),this.onEnd(b),this.ended=!0,b===l.Z_OK):v!==l.Z_SYNC_FLUSH||(this.onEnd(l.Z_OK),!(C.avail_out=0))},f.prototype.onData=function(m){this.chunks.push(m)},f.prototype.onEnd=function(m){m===l.Z_OK&&(this.options.to==="string"?this.result=this.chunks.join(""):this.result=a.flattenChunks(this.chunks)),this.chunks=[],this.err=m,this.msg=this.strm.msg},s.Inflate=f,s.inflate=w,s.inflateRaw=function(m,y){return(y=y||{}).raw=!0,w(m,y)},s.ungzip=w},{"./utils/common":41,"./utils/strings":42,"./zlib/constants":44,"./zlib/gzheader":47,"./zlib/inflate":49,"./zlib/messages":51,"./zlib/zstream":53}],41:[function(i,n,s){var o=typeof Uint8Array<"u"&&typeof Uint16Array<"u"&&typeof Int32Array<"u";s.assign=function(l){for(var c=Array.prototype.slice.call(arguments,1);c.length;){var d=c.shift();if(d){if(typeof d!="object")throw new TypeError(d+"must be non-object");for(var p in d)d.hasOwnProperty(p)&&(l[p]=d[p])}}return l},s.shrinkBuf=function(l,c){return l.length===c?l:l.subarray?l.subarray(0,c):(l.length=c,l)};var a={arraySet:function(l,c,d,p,u){if(c.subarray&&l.subarray)l.set(c.subarray(d,d+p),u);else for(var f=0;f<p;f++)l[u+f]=c[d+f]},flattenChunks:function(l){var c,d,p,u,f,w;for(c=p=0,d=l.length;c<d;c++)p+=l[c].length;for(w=new Uint8Array(p),c=u=0,d=l.length;c<d;c++)f=l[c],w.set(f,u),u+=f.length;return w}},r={arraySet:function(l,c,d,p,u){for(var f=0;f<p;f++)l[u+f]=c[d+f]},flattenChunks:function(l){return[].concat.apply([],l)}};s.setTyped=function(l){l?(s.Buf8=Uint8Array,s.Buf16=Uint16Array,s.Buf32=Int32Array,s.assign(s,a)):(s.Buf8=Array,s.Buf16=Array,s.Buf32=Array,s.assign(s,r))},s.setTyped(o)},{}],42:[function(i,n,s){var o=i("./common"),a=!0,r=!0;try{String.fromCharCode.apply(null,[0])}catch{a=!1}try{String.fromCharCode.apply(null,new Uint8Array(1))}catch{r=!1}for(var l=new o.Buf8(256),c=0;c<256;c++)l[c]=252<=c?6:248<=c?5:240<=c?4:224<=c?3:192<=c?2:1;function d(p,u){if(u<65537&&(p.subarray&&r||!p.subarray&&a))return String.fromCharCode.apply(null,o.shrinkBuf(p,u));for(var f="",w=0;w<u;w++)f+=String.fromCharCode(p[w]);return f}l[254]=l[254]=1,s.string2buf=function(p){var u,f,w,m,y,b=p.length,v=0;for(m=0;m<b;m++)(64512&(f=p.charCodeAt(m)))==55296&&m+1<b&&(64512&(w=p.charCodeAt(m+1)))==56320&&(f=65536+(f-55296<<10)+(w-56320),m++),v+=f<128?1:f<2048?2:f<65536?3:4;for(u=new o.Buf8(v),m=y=0;y<v;m++)(64512&(f=p.charCodeAt(m)))==55296&&m+1<b&&(64512&(w=p.charCodeAt(m+1)))==56320&&(f=65536+(f-55296<<10)+(w-56320),m++),f<128?u[y++]=f:(f<2048?u[y++]=192|f>>>6:(f<65536?u[y++]=224|f>>>12:(u[y++]=240|f>>>18,u[y++]=128|f>>>12&63),u[y++]=128|f>>>6&63),u[y++]=128|63&f);return u},s.buf2binstring=function(p){return d(p,p.length)},s.binstring2buf=function(p){for(var u=new o.Buf8(p.length),f=0,w=u.length;f<w;f++)u[f]=p.charCodeAt(f);return u},s.buf2string=function(p,u){var f,w,m,y,b=u||p.length,v=new Array(2*b);for(f=w=0;f<b;)if((m=p[f++])<128)v[w++]=m;else if(4<(y=l[m]))v[w++]=65533,f+=y-1;else{for(m&=y===2?31:y===3?15:7;1<y&&f<b;)m=m<<6|63&p[f++],y--;1<y?v[w++]=65533:m<65536?v[w++]=m:(m-=65536,v[w++]=55296|m>>10&1023,v[w++]=56320|1023&m)}return d(v,w)},s.utf8border=function(p,u){var f;for((u=u||p.length)>p.length&&(u=p.length),f=u-1;0<=f&&(192&p[f])==128;)f--;return f<0||f===0?u:f+l[p[f]]>u?f:u}},{"./common":41}],43:[function(i,n,s){n.exports=function(o,a,r,l){for(var c=65535&o|0,d=o>>>16&65535|0,p=0;r!==0;){for(r-=p=2e3<r?2e3:r;d=d+(c=c+a[l++]|0)|0,--p;);c%=65521,d%=65521}return c|d<<16|0}},{}],44:[function(i,n,s){n.exports={Z_NO_FLUSH:0,Z_PARTIAL_FLUSH:1,Z_SYNC_FLUSH:2,Z_FULL_FLUSH:3,Z_FINISH:4,Z_BLOCK:5,Z_TREES:6,Z_OK:0,Z_STREAM_END:1,Z_NEED_DICT:2,Z_ERRNO:-1,Z_STREAM_ERROR:-2,Z_DATA_ERROR:-3,Z_BUF_ERROR:-5,Z_NO_COMPRESSION:0,Z_BEST_SPEED:1,Z_BEST_COMPRESSION:9,Z_DEFAULT_COMPRESSION:-1,Z_FILTERED:1,Z_HUFFMAN_ONLY:2,Z_RLE:3,Z_FIXED:4,Z_DEFAULT_STRATEGY:0,Z_BINARY:0,Z_TEXT:1,Z_UNKNOWN:2,Z_DEFLATED:8}},{}],45:[function(i,n,s){var o=(function(){for(var a,r=[],l=0;l<256;l++){a=l;for(var c=0;c<8;c++)a=1&a?3988292384^a>>>1:a>>>1;r[l]=a}return r})();n.exports=function(a,r,l,c){var d=o,p=c+l;a^=-1;for(var u=c;u<p;u++)a=a>>>8^d[255&(a^r[u])];return-1^a}},{}],46:[function(i,n,s){var o,a=i("../utils/common"),r=i("./trees"),l=i("./adler32"),c=i("./crc32"),d=i("./messages"),p=0,u=4,f=0,w=-2,m=-1,y=4,b=2,v=8,k=9,S=286,D=30,A=19,C=2*S+1,L=15,z=3,N=258,K=N+z+1,_=42,U=113,x=1,q=2,O=3,$=4;function T(g,W){return g.msg=d[W],W}function P(g){return(g<<1)-(4<g?9:0)}function se(g){for(var W=g.length;0<=--W;)g[W]=0}function V(g){var W=g.state,j=W.pending;j>g.avail_out&&(j=g.avail_out),j!==0&&(a.arraySet(g.output,W.pending_buf,W.pending_out,j,g.next_out),g.next_out+=j,W.pending_out+=j,g.total_out+=j,g.avail_out-=j,W.pending-=j,W.pending===0&&(W.pending_out=0))}function Y(g,W){r._tr_flush_block(g,0<=g.block_start?g.block_start:-1,g.strstart-g.block_start,W),g.block_start=g.strstart,V(g.strm)}function le(g,W){g.pending_buf[g.pending++]=W}function ie(g,W){g.pending_buf[g.pending++]=W>>>8&255,g.pending_buf[g.pending++]=255&W}function oe(g,W){var j,M,I=g.max_chain_length,R=g.strstart,G=g.prev_length,B=g.nice_match,H=g.strstart>g.w_size-K?g.strstart-(g.w_size-K):0,Z=g.window,te=g.w_mask,ne=g.prev,me=g.strstart+N,$e=Z[R+G-1],xe=Z[R+G];g.prev_length>=g.good_match&&(I>>=2),B>g.lookahead&&(B=g.lookahead);do if(Z[(j=W)+G]===xe&&Z[j+G-1]===$e&&Z[j]===Z[R]&&Z[++j]===Z[R+1]){R+=2,j++;do;while(Z[++R]===Z[++j]&&Z[++R]===Z[++j]&&Z[++R]===Z[++j]&&Z[++R]===Z[++j]&&Z[++R]===Z[++j]&&Z[++R]===Z[++j]&&Z[++R]===Z[++j]&&Z[++R]===Z[++j]&&R<me);if(M=N-(me-R),R=me-N,G<M){if(g.match_start=W,B<=(G=M))break;$e=Z[R+G-1],xe=Z[R+G]}}while((W=ne[W&te])>H&&--I!=0);return G<=g.lookahead?G:g.lookahead}function Se(g){var W,j,M,I,R,G,B,H,Z,te,ne=g.w_size;do{if(I=g.window_size-g.lookahead-g.strstart,g.strstart>=ne+(ne-K)){for(a.arraySet(g.window,g.window,ne,ne,0),g.match_start-=ne,g.strstart-=ne,g.block_start-=ne,W=j=g.hash_size;M=g.head[--W],g.head[W]=ne<=M?M-ne:0,--j;);for(W=j=ne;M=g.prev[--W],g.prev[W]=ne<=M?M-ne:0,--j;);I+=ne}if(g.strm.avail_in===0)break;if(G=g.strm,B=g.window,H=g.strstart+g.lookahead,Z=I,te=void 0,te=G.avail_in,Z<te&&(te=Z),j=te===0?0:(G.avail_in-=te,a.arraySet(B,G.input,G.next_in,te,H),G.state.wrap===1?G.adler=l(G.adler,B,te,H):G.state.wrap===2&&(G.adler=c(G.adler,B,te,H)),G.next_in+=te,G.total_in+=te,te),g.lookahead+=j,g.lookahead+g.insert>=z)for(R=g.strstart-g.insert,g.ins_h=g.window[R],g.ins_h=(g.ins_h<<g.hash_shift^g.window[R+1])&g.hash_mask;g.insert&&(g.ins_h=(g.ins_h<<g.hash_shift^g.window[R+z-1])&g.hash_mask,g.prev[R&g.w_mask]=g.head[g.ins_h],g.head[g.ins_h]=R,R++,g.insert--,!(g.lookahead+g.insert<z)););}while(g.lookahead<K&&g.strm.avail_in!==0)}function Ie(g,W){for(var j,M;;){if(g.lookahead<K){if(Se(g),g.lookahead<K&&W===p)return x;if(g.lookahead===0)break}if(j=0,g.lookahead>=z&&(g.ins_h=(g.ins_h<<g.hash_shift^g.window[g.strstart+z-1])&g.hash_mask,j=g.prev[g.strstart&g.w_mask]=g.head[g.ins_h],g.head[g.ins_h]=g.strstart),j!==0&&g.strstart-j<=g.w_size-K&&(g.match_length=oe(g,j)),g.match_length>=z)if(M=r._tr_tally(g,g.strstart-g.match_start,g.match_length-z),g.lookahead-=g.match_length,g.match_length<=g.max_lazy_match&&g.lookahead>=z){for(g.match_length--;g.strstart++,g.ins_h=(g.ins_h<<g.hash_shift^g.window[g.strstart+z-1])&g.hash_mask,j=g.prev[g.strstart&g.w_mask]=g.head[g.ins_h],g.head[g.ins_h]=g.strstart,--g.match_length!=0;);g.strstart++}else g.strstart+=g.match_length,g.match_length=0,g.ins_h=g.window[g.strstart],g.ins_h=(g.ins_h<<g.hash_shift^g.window[g.strstart+1])&g.hash_mask;else M=r._tr_tally(g,0,g.window[g.strstart]),g.lookahead--,g.strstart++;if(M&&(Y(g,!1),g.strm.avail_out===0))return x}return g.insert=g.strstart<z-1?g.strstart:z-1,W===u?(Y(g,!0),g.strm.avail_out===0?O:$):g.last_lit&&(Y(g,!1),g.strm.avail_out===0)?x:q}function _e(g,W){for(var j,M,I;;){if(g.lookahead<K){if(Se(g),g.lookahead<K&&W===p)return x;if(g.lookahead===0)break}if(j=0,g.lookahead>=z&&(g.ins_h=(g.ins_h<<g.hash_shift^g.window[g.strstart+z-1])&g.hash_mask,j=g.prev[g.strstart&g.w_mask]=g.head[g.ins_h],g.head[g.ins_h]=g.strstart),g.prev_length=g.match_length,g.prev_match=g.match_start,g.match_length=z-1,j!==0&&g.prev_length<g.max_lazy_match&&g.strstart-j<=g.w_size-K&&(g.match_length=oe(g,j),g.match_length<=5&&(g.strategy===1||g.match_length===z&&4096<g.strstart-g.match_start)&&(g.match_length=z-1)),g.prev_length>=z&&g.match_length<=g.prev_length){for(I=g.strstart+g.lookahead-z,M=r._tr_tally(g,g.strstart-1-g.prev_match,g.prev_length-z),g.lookahead-=g.prev_length-1,g.prev_length-=2;++g.strstart<=I&&(g.ins_h=(g.ins_h<<g.hash_shift^g.window[g.strstart+z-1])&g.hash_mask,j=g.prev[g.strstart&g.w_mask]=g.head[g.ins_h],g.head[g.ins_h]=g.strstart),--g.prev_length!=0;);if(g.match_available=0,g.match_length=z-1,g.strstart++,M&&(Y(g,!1),g.strm.avail_out===0))return x}else if(g.match_available){if((M=r._tr_tally(g,0,g.window[g.strstart-1]))&&Y(g,!1),g.strstart++,g.lookahead--,g.strm.avail_out===0)return x}else g.match_available=1,g.strstart++,g.lookahead--}return g.match_available&&(M=r._tr_tally(g,0,g.window[g.strstart-1]),g.match_available=0),g.insert=g.strstart<z-1?g.strstart:z-1,W===u?(Y(g,!0),g.strm.avail_out===0?O:$):g.last_lit&&(Y(g,!1),g.strm.avail_out===0)?x:q}function fe(g,W,j,M,I){this.good_length=g,this.max_lazy=W,this.nice_length=j,this.max_chain=M,this.func=I}function X(){this.strm=null,this.status=0,this.pending_buf=null,this.pending_buf_size=0,this.pending_out=0,this.pending=0,this.wrap=0,this.gzhead=null,this.gzindex=0,this.method=v,this.last_flush=-1,this.w_size=0,this.w_bits=0,this.w_mask=0,this.window=null,this.window_size=0,this.prev=null,this.head=null,this.ins_h=0,this.hash_size=0,this.hash_bits=0,this.hash_mask=0,this.hash_shift=0,this.block_start=0,this.match_length=0,this.prev_match=0,this.match_available=0,this.strstart=0,this.match_start=0,this.lookahead=0,this.prev_length=0,this.max_chain_length=0,this.max_lazy_match=0,this.level=0,this.strategy=0,this.good_match=0,this.nice_match=0,this.dyn_ltree=new a.Buf16(2*C),this.dyn_dtree=new a.Buf16(2*(2*D+1)),this.bl_tree=new a.Buf16(2*(2*A+1)),se(this.dyn_ltree),se(this.dyn_dtree),se(this.bl_tree),this.l_desc=null,this.d_desc=null,this.bl_desc=null,this.bl_count=new a.Buf16(L+1),this.heap=new a.Buf16(2*S+1),se(this.heap),this.heap_len=0,this.heap_max=0,this.depth=new a.Buf16(2*S+1),se(this.depth),this.l_buf=0,this.lit_bufsize=0,this.last_lit=0,this.d_buf=0,this.opt_len=0,this.static_len=0,this.matches=0,this.insert=0,this.bi_buf=0,this.bi_valid=0}function pe(g){var W;return g&&g.state?(g.total_in=g.total_out=0,g.data_type=b,(W=g.state).pending=0,W.pending_out=0,W.wrap<0&&(W.wrap=-W.wrap),W.status=W.wrap?_:U,g.adler=W.wrap===2?0:1,W.last_flush=p,r._tr_init(W),f):T(g,w)}function E(g){var W=pe(g);return W===f&&(function(j){j.window_size=2*j.w_size,se(j.head),j.max_lazy_match=o[j.level].max_lazy,j.good_match=o[j.level].good_length,j.nice_match=o[j.level].nice_length,j.max_chain_length=o[j.level].max_chain,j.strstart=0,j.block_start=0,j.lookahead=0,j.insert=0,j.match_length=j.prev_length=z-1,j.match_available=0,j.ins_h=0})(g.state),W}function F(g,W,j,M,I,R){if(!g)return w;var G=1;if(W===m&&(W=6),M<0?(G=0,M=-M):15<M&&(G=2,M-=16),I<1||k<I||j!==v||M<8||15<M||W<0||9<W||R<0||y<R)return T(g,w);M===8&&(M=9);var B=new X;return(g.state=B).strm=g,B.wrap=G,B.gzhead=null,B.w_bits=M,B.w_size=1<<B.w_bits,B.w_mask=B.w_size-1,B.hash_bits=I+7,B.hash_size=1<<B.hash_bits,B.hash_mask=B.hash_size-1,B.hash_shift=~~((B.hash_bits+z-1)/z),B.window=new a.Buf8(2*B.w_size),B.head=new a.Buf16(B.hash_size),B.prev=new a.Buf16(B.w_size),B.lit_bufsize=1<<I+6,B.pending_buf_size=4*B.lit_bufsize,B.pending_buf=new a.Buf8(B.pending_buf_size),B.d_buf=1*B.lit_bufsize,B.l_buf=3*B.lit_bufsize,B.level=W,B.strategy=R,B.method=j,E(g)}o=[new fe(0,0,0,0,function(g,W){var j=65535;for(j>g.pending_buf_size-5&&(j=g.pending_buf_size-5);;){if(g.lookahead<=1){if(Se(g),g.lookahead===0&&W===p)return x;if(g.lookahead===0)break}g.strstart+=g.lookahead,g.lookahead=0;var M=g.block_start+j;if((g.strstart===0||g.strstart>=M)&&(g.lookahead=g.strstart-M,g.strstart=M,Y(g,!1),g.strm.avail_out===0)||g.strstart-g.block_start>=g.w_size-K&&(Y(g,!1),g.strm.avail_out===0))return x}return g.insert=0,W===u?(Y(g,!0),g.strm.avail_out===0?O:$):(g.strstart>g.block_start&&(Y(g,!1),g.strm.avail_out),x)}),new fe(4,4,8,4,Ie),new fe(4,5,16,8,Ie),new fe(4,6,32,32,Ie),new fe(4,4,16,16,_e),new fe(8,16,32,32,_e),new fe(8,16,128,128,_e),new fe(8,32,128,256,_e),new fe(32,128,258,1024,_e),new fe(32,258,258,4096,_e)],s.deflateInit=function(g,W){return F(g,W,v,15,8,0)},s.deflateInit2=F,s.deflateReset=E,s.deflateResetKeep=pe,s.deflateSetHeader=function(g,W){return g&&g.state?g.state.wrap!==2?w:(g.state.gzhead=W,f):w},s.deflate=function(g,W){var j,M,I,R;if(!g||!g.state||5<W||W<0)return g?T(g,w):w;if(M=g.state,!g.output||!g.input&&g.avail_in!==0||M.status===666&&W!==u)return T(g,g.avail_out===0?-5:w);if(M.strm=g,j=M.last_flush,M.last_flush=W,M.status===_)if(M.wrap===2)g.adler=0,le(M,31),le(M,139),le(M,8),M.gzhead?(le(M,(M.gzhead.text?1:0)+(M.gzhead.hcrc?2:0)+(M.gzhead.extra?4:0)+(M.gzhead.name?8:0)+(M.gzhead.comment?16:0)),le(M,255&M.gzhead.time),le(M,M.gzhead.time>>8&255),le(M,M.gzhead.time>>16&255),le(M,M.gzhead.time>>24&255),le(M,M.level===9?2:2<=M.strategy||M.level<2?4:0),le(M,255&M.gzhead.os),M.gzhead.extra&&M.gzhead.extra.length&&(le(M,255&M.gzhead.extra.length),le(M,M.gzhead.extra.length>>8&255)),M.gzhead.hcrc&&(g.adler=c(g.adler,M.pending_buf,M.pending,0)),M.gzindex=0,M.status=69):(le(M,0),le(M,0),le(M,0),le(M,0),le(M,0),le(M,M.level===9?2:2<=M.strategy||M.level<2?4:0),le(M,3),M.status=U);else{var G=v+(M.w_bits-8<<4)<<8;G|=(2<=M.strategy||M.level<2?0:M.level<6?1:M.level===6?2:3)<<6,M.strstart!==0&&(G|=32),G+=31-G%31,M.status=U,ie(M,G),M.strstart!==0&&(ie(M,g.adler>>>16),ie(M,65535&g.adler)),g.adler=1}if(M.status===69)if(M.gzhead.extra){for(I=M.pending;M.gzindex<(65535&M.gzhead.extra.length)&&(M.pending!==M.pending_buf_size||(M.gzhead.hcrc&&M.pending>I&&(g.adler=c(g.adler,M.pending_buf,M.pending-I,I)),V(g),I=M.pending,M.pending!==M.pending_buf_size));)le(M,255&M.gzhead.extra[M.gzindex]),M.gzindex++;M.gzhead.hcrc&&M.pending>I&&(g.adler=c(g.adler,M.pending_buf,M.pending-I,I)),M.gzindex===M.gzhead.extra.length&&(M.gzindex=0,M.status=73)}else M.status=73;if(M.status===73)if(M.gzhead.name){I=M.pending;do{if(M.pending===M.pending_buf_size&&(M.gzhead.hcrc&&M.pending>I&&(g.adler=c(g.adler,M.pending_buf,M.pending-I,I)),V(g),I=M.pending,M.pending===M.pending_buf_size)){R=1;break}R=M.gzindex<M.gzhead.name.length?255&M.gzhead.name.charCodeAt(M.gzindex++):0,le(M,R)}while(R!==0);M.gzhead.hcrc&&M.pending>I&&(g.adler=c(g.adler,M.pending_buf,M.pending-I,I)),R===0&&(M.gzindex=0,M.status=91)}else M.status=91;if(M.status===91)if(M.gzhead.comment){I=M.pending;do{if(M.pending===M.pending_buf_size&&(M.gzhead.hcrc&&M.pending>I&&(g.adler=c(g.adler,M.pending_buf,M.pending-I,I)),V(g),I=M.pending,M.pending===M.pending_buf_size)){R=1;break}R=M.gzindex<M.gzhead.comment.length?255&M.gzhead.comment.charCodeAt(M.gzindex++):0,le(M,R)}while(R!==0);M.gzhead.hcrc&&M.pending>I&&(g.adler=c(g.adler,M.pending_buf,M.pending-I,I)),R===0&&(M.status=103)}else M.status=103;if(M.status===103&&(M.gzhead.hcrc?(M.pending+2>M.pending_buf_size&&V(g),M.pending+2<=M.pending_buf_size&&(le(M,255&g.adler),le(M,g.adler>>8&255),g.adler=0,M.status=U)):M.status=U),M.pending!==0){if(V(g),g.avail_out===0)return M.last_flush=-1,f}else if(g.avail_in===0&&P(W)<=P(j)&&W!==u)return T(g,-5);if(M.status===666&&g.avail_in!==0)return T(g,-5);if(g.avail_in!==0||M.lookahead!==0||W!==p&&M.status!==666){var B=M.strategy===2?(function(H,Z){for(var te;;){if(H.lookahead===0&&(Se(H),H.lookahead===0)){if(Z===p)return x;break}if(H.match_length=0,te=r._tr_tally(H,0,H.window[H.strstart]),H.lookahead--,H.strstart++,te&&(Y(H,!1),H.strm.avail_out===0))return x}return H.insert=0,Z===u?(Y(H,!0),H.strm.avail_out===0?O:$):H.last_lit&&(Y(H,!1),H.strm.avail_out===0)?x:q})(M,W):M.strategy===3?(function(H,Z){for(var te,ne,me,$e,xe=H.window;;){if(H.lookahead<=N){if(Se(H),H.lookahead<=N&&Z===p)return x;if(H.lookahead===0)break}if(H.match_length=0,H.lookahead>=z&&0<H.strstart&&(ne=xe[me=H.strstart-1])===xe[++me]&&ne===xe[++me]&&ne===xe[++me]){$e=H.strstart+N;do;while(ne===xe[++me]&&ne===xe[++me]&&ne===xe[++me]&&ne===xe[++me]&&ne===xe[++me]&&ne===xe[++me]&&ne===xe[++me]&&ne===xe[++me]&&me<$e);H.match_length=N-($e-me),H.match_length>H.lookahead&&(H.match_length=H.lookahead)}if(H.match_length>=z?(te=r._tr_tally(H,1,H.match_length-z),H.lookahead-=H.match_length,H.strstart+=H.match_length,H.match_length=0):(te=r._tr_tally(H,0,H.window[H.strstart]),H.lookahead--,H.strstart++),te&&(Y(H,!1),H.strm.avail_out===0))return x}return H.insert=0,Z===u?(Y(H,!0),H.strm.avail_out===0?O:$):H.last_lit&&(Y(H,!1),H.strm.avail_out===0)?x:q})(M,W):o[M.level].func(M,W);if(B!==O&&B!==$||(M.status=666),B===x||B===O)return g.avail_out===0&&(M.last_flush=-1),f;if(B===q&&(W===1?r._tr_align(M):W!==5&&(r._tr_stored_block(M,0,0,!1),W===3&&(se(M.head),M.lookahead===0&&(M.strstart=0,M.block_start=0,M.insert=0))),V(g),g.avail_out===0))return M.last_flush=-1,f}return W!==u?f:M.wrap<=0?1:(M.wrap===2?(le(M,255&g.adler),le(M,g.adler>>8&255),le(M,g.adler>>16&255),le(M,g.adler>>24&255),le(M,255&g.total_in),le(M,g.total_in>>8&255),le(M,g.total_in>>16&255),le(M,g.total_in>>24&255)):(ie(M,g.adler>>>16),ie(M,65535&g.adler)),V(g),0<M.wrap&&(M.wrap=-M.wrap),M.pending!==0?f:1)},s.deflateEnd=function(g){var W;return g&&g.state?(W=g.state.status)!==_&&W!==69&&W!==73&&W!==91&&W!==103&&W!==U&&W!==666?T(g,w):(g.state=null,W===U?T(g,-3):f):w},s.deflateSetDictionary=function(g,W){var j,M,I,R,G,B,H,Z,te=W.length;if(!g||!g.state||(R=(j=g.state).wrap)===2||R===1&&j.status!==_||j.lookahead)return w;for(R===1&&(g.adler=l(g.adler,W,te,0)),j.wrap=0,te>=j.w_size&&(R===0&&(se(j.head),j.strstart=0,j.block_start=0,j.insert=0),Z=new a.Buf8(j.w_size),a.arraySet(Z,W,te-j.w_size,j.w_size,0),W=Z,te=j.w_size),G=g.avail_in,B=g.next_in,H=g.input,g.avail_in=te,g.next_in=0,g.input=W,Se(j);j.lookahead>=z;){for(M=j.strstart,I=j.lookahead-(z-1);j.ins_h=(j.ins_h<<j.hash_shift^j.window[M+z-1])&j.hash_mask,j.prev[M&j.w_mask]=j.head[j.ins_h],j.head[j.ins_h]=M,M++,--I;);j.strstart=M,j.lookahead=z-1,Se(j)}return j.strstart+=j.lookahead,j.block_start=j.strstart,j.insert=j.lookahead,j.lookahead=0,j.match_length=j.prev_length=z-1,j.match_available=0,g.next_in=B,g.input=H,g.avail_in=G,j.wrap=R,f},s.deflateInfo="pako deflate (from Nodeca project)"},{"../utils/common":41,"./adler32":43,"./crc32":45,"./messages":51,"./trees":52}],47:[function(i,n,s){n.exports=function(){this.text=0,this.time=0,this.xflags=0,this.os=0,this.extra=null,this.extra_len=0,this.name="",this.comment="",this.hcrc=0,this.done=!1}},{}],48:[function(i,n,s){n.exports=function(o,a){var r,l,c,d,p,u,f,w,m,y,b,v,k,S,D,A,C,L,z,N,K,_,U,x,q;r=o.state,l=o.next_in,x=o.input,c=l+(o.avail_in-5),d=o.next_out,q=o.output,p=d-(a-o.avail_out),u=d+(o.avail_out-257),f=r.dmax,w=r.wsize,m=r.whave,y=r.wnext,b=r.window,v=r.hold,k=r.bits,S=r.lencode,D=r.distcode,A=(1<<r.lenbits)-1,C=(1<<r.distbits)-1;e:do{k<15&&(v+=x[l++]<<k,k+=8,v+=x[l++]<<k,k+=8),L=S[v&A];t:for(;;){if(v>>>=z=L>>>24,k-=z,(z=L>>>16&255)===0)q[d++]=65535&L;else{if(!(16&z)){if((64&z)==0){L=S[(65535&L)+(v&(1<<z)-1)];continue t}if(32&z){r.mode=12;break e}o.msg="invalid literal/length code",r.mode=30;break e}N=65535&L,(z&=15)&&(k<z&&(v+=x[l++]<<k,k+=8),N+=v&(1<<z)-1,v>>>=z,k-=z),k<15&&(v+=x[l++]<<k,k+=8,v+=x[l++]<<k,k+=8),L=D[v&C];i:for(;;){if(v>>>=z=L>>>24,k-=z,!(16&(z=L>>>16&255))){if((64&z)==0){L=D[(65535&L)+(v&(1<<z)-1)];continue i}o.msg="invalid distance code",r.mode=30;break e}if(K=65535&L,k<(z&=15)&&(v+=x[l++]<<k,(k+=8)<z&&(v+=x[l++]<<k,k+=8)),f<(K+=v&(1<<z)-1)){o.msg="invalid distance too far back",r.mode=30;break e}if(v>>>=z,k-=z,(z=d-p)<K){if(m<(z=K-z)&&r.sane){o.msg="invalid distance too far back",r.mode=30;break e}if(U=b,(_=0)===y){if(_+=w-z,z<N){for(N-=z;q[d++]=b[_++],--z;);_=d-K,U=q}}else if(y<z){if(_+=w+y-z,(z-=y)<N){for(N-=z;q[d++]=b[_++],--z;);if(_=0,y<N){for(N-=z=y;q[d++]=b[_++],--z;);_=d-K,U=q}}}else if(_+=y-z,z<N){for(N-=z;q[d++]=b[_++],--z;);_=d-K,U=q}for(;2<N;)q[d++]=U[_++],q[d++]=U[_++],q[d++]=U[_++],N-=3;N&&(q[d++]=U[_++],1<N&&(q[d++]=U[_++]))}else{for(_=d-K;q[d++]=q[_++],q[d++]=q[_++],q[d++]=q[_++],2<(N-=3););N&&(q[d++]=q[_++],1<N&&(q[d++]=q[_++]))}break}}break}}while(l<c&&d<u);l-=N=k>>3,v&=(1<<(k-=N<<3))-1,o.next_in=l,o.next_out=d,o.avail_in=l<c?c-l+5:5-(l-c),o.avail_out=d<u?u-d+257:257-(d-u),r.hold=v,r.bits=k}},{}],49:[function(i,n,s){var o=i("../utils/common"),a=i("./adler32"),r=i("./crc32"),l=i("./inffast"),c=i("./inftrees"),d=1,p=2,u=0,f=-2,w=1,m=852,y=592;function b(_){return(_>>>24&255)+(_>>>8&65280)+((65280&_)<<8)+((255&_)<<24)}function v(){this.mode=0,this.last=!1,this.wrap=0,this.havedict=!1,this.flags=0,this.dmax=0,this.check=0,this.total=0,this.head=null,this.wbits=0,this.wsize=0,this.whave=0,this.wnext=0,this.window=null,this.hold=0,this.bits=0,this.length=0,this.offset=0,this.extra=0,this.lencode=null,this.distcode=null,this.lenbits=0,this.distbits=0,this.ncode=0,this.nlen=0,this.ndist=0,this.have=0,this.next=null,this.lens=new o.Buf16(320),this.work=new o.Buf16(288),this.lendyn=null,this.distdyn=null,this.sane=0,this.back=0,this.was=0}function k(_){var U;return _&&_.state?(U=_.state,_.total_in=_.total_out=U.total=0,_.msg="",U.wrap&&(_.adler=1&U.wrap),U.mode=w,U.last=0,U.havedict=0,U.dmax=32768,U.head=null,U.hold=0,U.bits=0,U.lencode=U.lendyn=new o.Buf32(m),U.distcode=U.distdyn=new o.Buf32(y),U.sane=1,U.back=-1,u):f}function S(_){var U;return _&&_.state?((U=_.state).wsize=0,U.whave=0,U.wnext=0,k(_)):f}function D(_,U){var x,q;return _&&_.state?(q=_.state,U<0?(x=0,U=-U):(x=1+(U>>4),U<48&&(U&=15)),U&&(U<8||15<U)?f:(q.window!==null&&q.wbits!==U&&(q.window=null),q.wrap=x,q.wbits=U,S(_))):f}function A(_,U){var x,q;return _?(q=new v,(_.state=q).window=null,(x=D(_,U))!==u&&(_.state=null),x):f}var C,L,z=!0;function N(_){if(z){var U;for(C=new o.Buf32(512),L=new o.Buf32(32),U=0;U<144;)_.lens[U++]=8;for(;U<256;)_.lens[U++]=9;for(;U<280;)_.lens[U++]=7;for(;U<288;)_.lens[U++]=8;for(c(d,_.lens,0,288,C,0,_.work,{bits:9}),U=0;U<32;)_.lens[U++]=5;c(p,_.lens,0,32,L,0,_.work,{bits:5}),z=!1}_.lencode=C,_.lenbits=9,_.distcode=L,_.distbits=5}function K(_,U,x,q){var O,$=_.state;return $.window===null&&($.wsize=1<<$.wbits,$.wnext=0,$.whave=0,$.window=new o.Buf8($.wsize)),q>=$.wsize?(o.arraySet($.window,U,x-$.wsize,$.wsize,0),$.wnext=0,$.whave=$.wsize):(q<(O=$.wsize-$.wnext)&&(O=q),o.arraySet($.window,U,x-q,O,$.wnext),(q-=O)?(o.arraySet($.window,U,x-q,q,0),$.wnext=q,$.whave=$.wsize):($.wnext+=O,$.wnext===$.wsize&&($.wnext=0),$.whave<$.wsize&&($.whave+=O))),0}s.inflateReset=S,s.inflateReset2=D,s.inflateResetKeep=k,s.inflateInit=function(_){return A(_,15)},s.inflateInit2=A,s.inflate=function(_,U){var x,q,O,$,T,P,se,V,Y,le,ie,oe,Se,Ie,_e,fe,X,pe,E,F,g,W,j,M,I=0,R=new o.Buf8(4),G=[16,17,18,0,8,7,9,6,10,5,11,4,12,3,13,2,14,1,15];if(!_||!_.state||!_.output||!_.input&&_.avail_in!==0)return f;(x=_.state).mode===12&&(x.mode=13),T=_.next_out,O=_.output,se=_.avail_out,$=_.next_in,q=_.input,P=_.avail_in,V=x.hold,Y=x.bits,le=P,ie=se,W=u;e:for(;;)switch(x.mode){case w:if(x.wrap===0){x.mode=13;break}for(;Y<16;){if(P===0)break e;P--,V+=q[$++]<<Y,Y+=8}if(2&x.wrap&&V===35615){R[x.check=0]=255&V,R[1]=V>>>8&255,x.check=r(x.check,R,2,0),Y=V=0,x.mode=2;break}if(x.flags=0,x.head&&(x.head.done=!1),!(1&x.wrap)||(((255&V)<<8)+(V>>8))%31){_.msg="incorrect header check",x.mode=30;break}if((15&V)!=8){_.msg="unknown compression method",x.mode=30;break}if(Y-=4,g=8+(15&(V>>>=4)),x.wbits===0)x.wbits=g;else if(g>x.wbits){_.msg="invalid window size",x.mode=30;break}x.dmax=1<<g,_.adler=x.check=1,x.mode=512&V?10:12,Y=V=0;break;case 2:for(;Y<16;){if(P===0)break e;P--,V+=q[$++]<<Y,Y+=8}if(x.flags=V,(255&x.flags)!=8){_.msg="unknown compression method",x.mode=30;break}if(57344&x.flags){_.msg="unknown header flags set",x.mode=30;break}x.head&&(x.head.text=V>>8&1),512&x.flags&&(R[0]=255&V,R[1]=V>>>8&255,x.check=r(x.check,R,2,0)),Y=V=0,x.mode=3;case 3:for(;Y<32;){if(P===0)break e;P--,V+=q[$++]<<Y,Y+=8}x.head&&(x.head.time=V),512&x.flags&&(R[0]=255&V,R[1]=V>>>8&255,R[2]=V>>>16&255,R[3]=V>>>24&255,x.check=r(x.check,R,4,0)),Y=V=0,x.mode=4;case 4:for(;Y<16;){if(P===0)break e;P--,V+=q[$++]<<Y,Y+=8}x.head&&(x.head.xflags=255&V,x.head.os=V>>8),512&x.flags&&(R[0]=255&V,R[1]=V>>>8&255,x.check=r(x.check,R,2,0)),Y=V=0,x.mode=5;case 5:if(1024&x.flags){for(;Y<16;){if(P===0)break e;P--,V+=q[$++]<<Y,Y+=8}x.length=V,x.head&&(x.head.extra_len=V),512&x.flags&&(R[0]=255&V,R[1]=V>>>8&255,x.check=r(x.check,R,2,0)),Y=V=0}else x.head&&(x.head.extra=null);x.mode=6;case 6:if(1024&x.flags&&(P<(oe=x.length)&&(oe=P),oe&&(x.head&&(g=x.head.extra_len-x.length,x.head.extra||(x.head.extra=new Array(x.head.extra_len)),o.arraySet(x.head.extra,q,$,oe,g)),512&x.flags&&(x.check=r(x.check,q,oe,$)),P-=oe,$+=oe,x.length-=oe),x.length))break e;x.length=0,x.mode=7;case 7:if(2048&x.flags){if(P===0)break e;for(oe=0;g=q[$+oe++],x.head&&g&&x.length<65536&&(x.head.name+=String.fromCharCode(g)),g&&oe<P;);if(512&x.flags&&(x.check=r(x.check,q,oe,$)),P-=oe,$+=oe,g)break e}else x.head&&(x.head.name=null);x.length=0,x.mode=8;case 8:if(4096&x.flags){if(P===0)break e;for(oe=0;g=q[$+oe++],x.head&&g&&x.length<65536&&(x.head.comment+=String.fromCharCode(g)),g&&oe<P;);if(512&x.flags&&(x.check=r(x.check,q,oe,$)),P-=oe,$+=oe,g)break e}else x.head&&(x.head.comment=null);x.mode=9;case 9:if(512&x.flags){for(;Y<16;){if(P===0)break e;P--,V+=q[$++]<<Y,Y+=8}if(V!==(65535&x.check)){_.msg="header crc mismatch",x.mode=30;break}Y=V=0}x.head&&(x.head.hcrc=x.flags>>9&1,x.head.done=!0),_.adler=x.check=0,x.mode=12;break;case 10:for(;Y<32;){if(P===0)break e;P--,V+=q[$++]<<Y,Y+=8}_.adler=x.check=b(V),Y=V=0,x.mode=11;case 11:if(x.havedict===0)return _.next_out=T,_.avail_out=se,_.next_in=$,_.avail_in=P,x.hold=V,x.bits=Y,2;_.adler=x.check=1,x.mode=12;case 12:if(U===5||U===6)break e;case 13:if(x.last){V>>>=7&Y,Y-=7&Y,x.mode=27;break}for(;Y<3;){if(P===0)break e;P--,V+=q[$++]<<Y,Y+=8}switch(x.last=1&V,Y-=1,3&(V>>>=1)){case 0:x.mode=14;break;case 1:if(N(x),x.mode=20,U!==6)break;V>>>=2,Y-=2;break e;case 2:x.mode=17;break;case 3:_.msg="invalid block type",x.mode=30}V>>>=2,Y-=2;break;case 14:for(V>>>=7&Y,Y-=7&Y;Y<32;){if(P===0)break e;P--,V+=q[$++]<<Y,Y+=8}if((65535&V)!=(V>>>16^65535)){_.msg="invalid stored block lengths",x.mode=30;break}if(x.length=65535&V,Y=V=0,x.mode=15,U===6)break e;case 15:x.mode=16;case 16:if(oe=x.length){if(P<oe&&(oe=P),se<oe&&(oe=se),oe===0)break e;o.arraySet(O,q,$,oe,T),P-=oe,$+=oe,se-=oe,T+=oe,x.length-=oe;break}x.mode=12;break;case 17:for(;Y<14;){if(P===0)break e;P--,V+=q[$++]<<Y,Y+=8}if(x.nlen=257+(31&V),V>>>=5,Y-=5,x.ndist=1+(31&V),V>>>=5,Y-=5,x.ncode=4+(15&V),V>>>=4,Y-=4,286<x.nlen||30<x.ndist){_.msg="too many length or distance symbols",x.mode=30;break}x.have=0,x.mode=18;case 18:for(;x.have<x.ncode;){for(;Y<3;){if(P===0)break e;P--,V+=q[$++]<<Y,Y+=8}x.lens[G[x.have++]]=7&V,V>>>=3,Y-=3}for(;x.have<19;)x.lens[G[x.have++]]=0;if(x.lencode=x.lendyn,x.lenbits=7,j={bits:x.lenbits},W=c(0,x.lens,0,19,x.lencode,0,x.work,j),x.lenbits=j.bits,W){_.msg="invalid code lengths set",x.mode=30;break}x.have=0,x.mode=19;case 19:for(;x.have<x.nlen+x.ndist;){for(;fe=(I=x.lencode[V&(1<<x.lenbits)-1])>>>16&255,X=65535&I,!((_e=I>>>24)<=Y);){if(P===0)break e;P--,V+=q[$++]<<Y,Y+=8}if(X<16)V>>>=_e,Y-=_e,x.lens[x.have++]=X;else{if(X===16){for(M=_e+2;Y<M;){if(P===0)break e;P--,V+=q[$++]<<Y,Y+=8}if(V>>>=_e,Y-=_e,x.have===0){_.msg="invalid bit length repeat",x.mode=30;break}g=x.lens[x.have-1],oe=3+(3&V),V>>>=2,Y-=2}else if(X===17){for(M=_e+3;Y<M;){if(P===0)break e;P--,V+=q[$++]<<Y,Y+=8}Y-=_e,g=0,oe=3+(7&(V>>>=_e)),V>>>=3,Y-=3}else{for(M=_e+7;Y<M;){if(P===0)break e;P--,V+=q[$++]<<Y,Y+=8}Y-=_e,g=0,oe=11+(127&(V>>>=_e)),V>>>=7,Y-=7}if(x.have+oe>x.nlen+x.ndist){_.msg="invalid bit length repeat",x.mode=30;break}for(;oe--;)x.lens[x.have++]=g}}if(x.mode===30)break;if(x.lens[256]===0){_.msg="invalid code -- missing end-of-block",x.mode=30;break}if(x.lenbits=9,j={bits:x.lenbits},W=c(d,x.lens,0,x.nlen,x.lencode,0,x.work,j),x.lenbits=j.bits,W){_.msg="invalid literal/lengths set",x.mode=30;break}if(x.distbits=6,x.distcode=x.distdyn,j={bits:x.distbits},W=c(p,x.lens,x.nlen,x.ndist,x.distcode,0,x.work,j),x.distbits=j.bits,W){_.msg="invalid distances set",x.mode=30;break}if(x.mode=20,U===6)break e;case 20:x.mode=21;case 21:if(6<=P&&258<=se){_.next_out=T,_.avail_out=se,_.next_in=$,_.avail_in=P,x.hold=V,x.bits=Y,l(_,ie),T=_.next_out,O=_.output,se=_.avail_out,$=_.next_in,q=_.input,P=_.avail_in,V=x.hold,Y=x.bits,x.mode===12&&(x.back=-1);break}for(x.back=0;fe=(I=x.lencode[V&(1<<x.lenbits)-1])>>>16&255,X=65535&I,!((_e=I>>>24)<=Y);){if(P===0)break e;P--,V+=q[$++]<<Y,Y+=8}if(fe&&(240&fe)==0){for(pe=_e,E=fe,F=X;fe=(I=x.lencode[F+((V&(1<<pe+E)-1)>>pe)])>>>16&255,X=65535&I,!(pe+(_e=I>>>24)<=Y);){if(P===0)break e;P--,V+=q[$++]<<Y,Y+=8}V>>>=pe,Y-=pe,x.back+=pe}if(V>>>=_e,Y-=_e,x.back+=_e,x.length=X,fe===0){x.mode=26;break}if(32&fe){x.back=-1,x.mode=12;break}if(64&fe){_.msg="invalid literal/length code",x.mode=30;break}x.extra=15&fe,x.mode=22;case 22:if(x.extra){for(M=x.extra;Y<M;){if(P===0)break e;P--,V+=q[$++]<<Y,Y+=8}x.length+=V&(1<<x.extra)-1,V>>>=x.extra,Y-=x.extra,x.back+=x.extra}x.was=x.length,x.mode=23;case 23:for(;fe=(I=x.distcode[V&(1<<x.distbits)-1])>>>16&255,X=65535&I,!((_e=I>>>24)<=Y);){if(P===0)break e;P--,V+=q[$++]<<Y,Y+=8}if((240&fe)==0){for(pe=_e,E=fe,F=X;fe=(I=x.distcode[F+((V&(1<<pe+E)-1)>>pe)])>>>16&255,X=65535&I,!(pe+(_e=I>>>24)<=Y);){if(P===0)break e;P--,V+=q[$++]<<Y,Y+=8}V>>>=pe,Y-=pe,x.back+=pe}if(V>>>=_e,Y-=_e,x.back+=_e,64&fe){_.msg="invalid distance code",x.mode=30;break}x.offset=X,x.extra=15&fe,x.mode=24;case 24:if(x.extra){for(M=x.extra;Y<M;){if(P===0)break e;P--,V+=q[$++]<<Y,Y+=8}x.offset+=V&(1<<x.extra)-1,V>>>=x.extra,Y-=x.extra,x.back+=x.extra}if(x.offset>x.dmax){_.msg="invalid distance too far back",x.mode=30;break}x.mode=25;case 25:if(se===0)break e;if(oe=ie-se,x.offset>oe){if((oe=x.offset-oe)>x.whave&&x.sane){_.msg="invalid distance too far back",x.mode=30;break}Se=oe>x.wnext?(oe-=x.wnext,x.wsize-oe):x.wnext-oe,oe>x.length&&(oe=x.length),Ie=x.window}else Ie=O,Se=T-x.offset,oe=x.length;for(se<oe&&(oe=se),se-=oe,x.length-=oe;O[T++]=Ie[Se++],--oe;);x.length===0&&(x.mode=21);break;case 26:if(se===0)break e;O[T++]=x.length,se--,x.mode=21;break;case 27:if(x.wrap){for(;Y<32;){if(P===0)break e;P--,V|=q[$++]<<Y,Y+=8}if(ie-=se,_.total_out+=ie,x.total+=ie,ie&&(_.adler=x.check=x.flags?r(x.check,O,ie,T-ie):a(x.check,O,ie,T-ie)),ie=se,(x.flags?V:b(V))!==x.check){_.msg="incorrect data check",x.mode=30;break}Y=V=0}x.mode=28;case 28:if(x.wrap&&x.flags){for(;Y<32;){if(P===0)break e;P--,V+=q[$++]<<Y,Y+=8}if(V!==(4294967295&x.total)){_.msg="incorrect length check",x.mode=30;break}Y=V=0}x.mode=29;case 29:W=1;break e;case 30:W=-3;break e;case 31:return-4;case 32:default:return f}return _.next_out=T,_.avail_out=se,_.next_in=$,_.avail_in=P,x.hold=V,x.bits=Y,(x.wsize||ie!==_.avail_out&&x.mode<30&&(x.mode<27||U!==4))&&K(_,_.output,_.next_out,ie-_.avail_out)?(x.mode=31,-4):(le-=_.avail_in,ie-=_.avail_out,_.total_in+=le,_.total_out+=ie,x.total+=ie,x.wrap&&ie&&(_.adler=x.check=x.flags?r(x.check,O,ie,_.next_out-ie):a(x.check,O,ie,_.next_out-ie)),_.data_type=x.bits+(x.last?64:0)+(x.mode===12?128:0)+(x.mode===20||x.mode===15?256:0),(le==0&&ie===0||U===4)&&W===u&&(W=-5),W)},s.inflateEnd=function(_){if(!_||!_.state)return f;var U=_.state;return U.window&&(U.window=null),_.state=null,u},s.inflateGetHeader=function(_,U){var x;return _&&_.state?(2&(x=_.state).wrap)==0?f:((x.head=U).done=!1,u):f},s.inflateSetDictionary=function(_,U){var x,q=U.length;return _&&_.state?(x=_.state).wrap!==0&&x.mode!==11?f:x.mode===11&&a(1,U,q,0)!==x.check?-3:K(_,U,q,q)?(x.mode=31,-4):(x.havedict=1,u):f},s.inflateInfo="pako inflate (from Nodeca project)"},{"../utils/common":41,"./adler32":43,"./crc32":45,"./inffast":48,"./inftrees":50}],50:[function(i,n,s){var o=i("../utils/common"),a=[3,4,5,6,7,8,9,10,11,13,15,17,19,23,27,31,35,43,51,59,67,83,99,115,131,163,195,227,258,0,0],r=[16,16,16,16,16,16,16,16,17,17,17,17,18,18,18,18,19,19,19,19,20,20,20,20,21,21,21,21,16,72,78],l=[1,2,3,4,5,7,9,13,17,25,33,49,65,97,129,193,257,385,513,769,1025,1537,2049,3073,4097,6145,8193,12289,16385,24577,0,0],c=[16,16,16,16,17,17,18,18,19,19,20,20,21,21,22,22,23,23,24,24,25,25,26,26,27,27,28,28,29,29,64,64];n.exports=function(d,p,u,f,w,m,y,b){var v,k,S,D,A,C,L,z,N,K=b.bits,_=0,U=0,x=0,q=0,O=0,$=0,T=0,P=0,se=0,V=0,Y=null,le=0,ie=new o.Buf16(16),oe=new o.Buf16(16),Se=null,Ie=0;for(_=0;_<=15;_++)ie[_]=0;for(U=0;U<f;U++)ie[p[u+U]]++;for(O=K,q=15;1<=q&&ie[q]===0;q--);if(q<O&&(O=q),q===0)return w[m++]=20971520,w[m++]=20971520,b.bits=1,0;for(x=1;x<q&&ie[x]===0;x++);for(O<x&&(O=x),_=P=1;_<=15;_++)if(P<<=1,(P-=ie[_])<0)return-1;if(0<P&&(d===0||q!==1))return-1;for(oe[1]=0,_=1;_<15;_++)oe[_+1]=oe[_]+ie[_];for(U=0;U<f;U++)p[u+U]!==0&&(y[oe[p[u+U]]++]=U);if(C=d===0?(Y=Se=y,19):d===1?(Y=a,le-=257,Se=r,Ie-=257,256):(Y=l,Se=c,-1),_=x,A=m,T=U=V=0,S=-1,D=(se=1<<($=O))-1,d===1&&852<se||d===2&&592<se)return 1;for(;;){for(L=_-T,N=y[U]<C?(z=0,y[U]):y[U]>C?(z=Se[Ie+y[U]],Y[le+y[U]]):(z=96,0),v=1<<_-T,x=k=1<<$;w[A+(V>>T)+(k-=v)]=L<<24|z<<16|N|0,k!==0;);for(v=1<<_-1;V&v;)v>>=1;if(v!==0?(V&=v-1,V+=v):V=0,U++,--ie[_]==0){if(_===q)break;_=p[u+y[U]]}if(O<_&&(V&D)!==S){for(T===0&&(T=O),A+=x,P=1<<($=_-T);$+T<q&&!((P-=ie[$+T])<=0);)$++,P<<=1;if(se+=1<<$,d===1&&852<se||d===2&&592<se)return 1;w[S=V&D]=O<<24|$<<16|A-m|0}}return V!==0&&(w[A+V]=_-T<<24|64<<16|0),b.bits=O,0}},{"../utils/common":41}],51:[function(i,n,s){n.exports={2:"need dictionary",1:"stream end",0:"","-1":"file error","-2":"stream error","-3":"data error","-4":"insufficient memory","-5":"buffer error","-6":"incompatible version"}},{}],52:[function(i,n,s){var o=i("../utils/common"),a=0,r=1;function l(I){for(var R=I.length;0<=--R;)I[R]=0}var c=0,d=29,p=256,u=p+1+d,f=30,w=19,m=2*u+1,y=15,b=16,v=7,k=256,S=16,D=17,A=18,C=[0,0,0,0,0,0,0,0,1,1,1,1,2,2,2,2,3,3,3,3,4,4,4,4,5,5,5,5,0],L=[0,0,0,0,1,1,2,2,3,3,4,4,5,5,6,6,7,7,8,8,9,9,10,10,11,11,12,12,13,13],z=[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,2,3,7],N=[16,17,18,0,8,7,9,6,10,5,11,4,12,3,13,2,14,1,15],K=new Array(2*(u+2));l(K);var _=new Array(2*f);l(_);var U=new Array(512);l(U);var x=new Array(256);l(x);var q=new Array(d);l(q);var O,$,T,P=new Array(f);function se(I,R,G,B,H){this.static_tree=I,this.extra_bits=R,this.extra_base=G,this.elems=B,this.max_length=H,this.has_stree=I&&I.length}function V(I,R){this.dyn_tree=I,this.max_code=0,this.stat_desc=R}function Y(I){return I<256?U[I]:U[256+(I>>>7)]}function le(I,R){I.pending_buf[I.pending++]=255&R,I.pending_buf[I.pending++]=R>>>8&255}function ie(I,R,G){I.bi_valid>b-G?(I.bi_buf|=R<<I.bi_valid&65535,le(I,I.bi_buf),I.bi_buf=R>>b-I.bi_valid,I.bi_valid+=G-b):(I.bi_buf|=R<<I.bi_valid&65535,I.bi_valid+=G)}function oe(I,R,G){ie(I,G[2*R],G[2*R+1])}function Se(I,R){for(var G=0;G|=1&I,I>>>=1,G<<=1,0<--R;);return G>>>1}function Ie(I,R,G){var B,H,Z=new Array(y+1),te=0;for(B=1;B<=y;B++)Z[B]=te=te+G[B-1]<<1;for(H=0;H<=R;H++){var ne=I[2*H+1];ne!==0&&(I[2*H]=Se(Z[ne]++,ne))}}function _e(I){var R;for(R=0;R<u;R++)I.dyn_ltree[2*R]=0;for(R=0;R<f;R++)I.dyn_dtree[2*R]=0;for(R=0;R<w;R++)I.bl_tree[2*R]=0;I.dyn_ltree[2*k]=1,I.opt_len=I.static_len=0,I.last_lit=I.matches=0}function fe(I){8<I.bi_valid?le(I,I.bi_buf):0<I.bi_valid&&(I.pending_buf[I.pending++]=I.bi_buf),I.bi_buf=0,I.bi_valid=0}function X(I,R,G,B){var H=2*R,Z=2*G;return I[H]<I[Z]||I[H]===I[Z]&&B[R]<=B[G]}function pe(I,R,G){for(var B=I.heap[G],H=G<<1;H<=I.heap_len&&(H<I.heap_len&&X(R,I.heap[H+1],I.heap[H],I.depth)&&H++,!X(R,B,I.heap[H],I.depth));)I.heap[G]=I.heap[H],G=H,H<<=1;I.heap[G]=B}function E(I,R,G){var B,H,Z,te,ne=0;if(I.last_lit!==0)for(;B=I.pending_buf[I.d_buf+2*ne]<<8|I.pending_buf[I.d_buf+2*ne+1],H=I.pending_buf[I.l_buf+ne],ne++,B===0?oe(I,H,R):(oe(I,(Z=x[H])+p+1,R),(te=C[Z])!==0&&ie(I,H-=q[Z],te),oe(I,Z=Y(--B),G),(te=L[Z])!==0&&ie(I,B-=P[Z],te)),ne<I.last_lit;);oe(I,k,R)}function F(I,R){var G,B,H,Z=R.dyn_tree,te=R.stat_desc.static_tree,ne=R.stat_desc.has_stree,me=R.stat_desc.elems,$e=-1;for(I.heap_len=0,I.heap_max=m,G=0;G<me;G++)Z[2*G]!==0?(I.heap[++I.heap_len]=$e=G,I.depth[G]=0):Z[2*G+1]=0;for(;I.heap_len<2;)Z[2*(H=I.heap[++I.heap_len]=$e<2?++$e:0)]=1,I.depth[H]=0,I.opt_len--,ne&&(I.static_len-=te[2*H+1]);for(R.max_code=$e,G=I.heap_len>>1;1<=G;G--)pe(I,Z,G);for(H=me;G=I.heap[1],I.heap[1]=I.heap[I.heap_len--],pe(I,Z,1),B=I.heap[1],I.heap[--I.heap_max]=G,I.heap[--I.heap_max]=B,Z[2*H]=Z[2*G]+Z[2*B],I.depth[H]=(I.depth[G]>=I.depth[B]?I.depth[G]:I.depth[B])+1,Z[2*G+1]=Z[2*B+1]=H,I.heap[1]=H++,pe(I,Z,1),2<=I.heap_len;);I.heap[--I.heap_max]=I.heap[1],(function(xe,De){var je,ze,ae,ue,Oe,He,We=De.dyn_tree,lt=De.max_code,Et=De.stat_desc.static_tree,Zs=De.stat_desc.has_stree,Js=De.stat_desc.extra_bits,es=De.stat_desc.extra_base,Ai=De.stat_desc.max_length,qi=0;for(ue=0;ue<=y;ue++)xe.bl_count[ue]=0;for(We[2*xe.heap[xe.heap_max]+1]=0,je=xe.heap_max+1;je<m;je++)Ai<(ue=We[2*We[2*(ze=xe.heap[je])+1]+1]+1)&&(ue=Ai,qi++),We[2*ze+1]=ue,lt<ze||(xe.bl_count[ue]++,Oe=0,es<=ze&&(Oe=Js[ze-es]),He=We[2*ze],xe.opt_len+=He*(ue+Oe),Zs&&(xe.static_len+=He*(Et[2*ze+1]+Oe)));if(qi!==0){do{for(ue=Ai-1;xe.bl_count[ue]===0;)ue--;xe.bl_count[ue]--,xe.bl_count[ue+1]+=2,xe.bl_count[Ai]--,qi-=2}while(0<qi);for(ue=Ai;ue!==0;ue--)for(ze=xe.bl_count[ue];ze!==0;)lt<(ae=xe.heap[--je])||(We[2*ae+1]!==ue&&(xe.opt_len+=(ue-We[2*ae+1])*We[2*ae],We[2*ae+1]=ue),ze--)}})(I,R),Ie(Z,$e,I.bl_count)}function g(I,R,G){var B,H,Z=-1,te=R[1],ne=0,me=7,$e=4;for(te===0&&(me=138,$e=3),R[2*(G+1)+1]=65535,B=0;B<=G;B++)H=te,te=R[2*(B+1)+1],++ne<me&&H===te||(ne<$e?I.bl_tree[2*H]+=ne:H!==0?(H!==Z&&I.bl_tree[2*H]++,I.bl_tree[2*S]++):ne<=10?I.bl_tree[2*D]++:I.bl_tree[2*A]++,Z=H,$e=(ne=0)===te?(me=138,3):H===te?(me=6,3):(me=7,4))}function W(I,R,G){var B,H,Z=-1,te=R[1],ne=0,me=7,$e=4;for(te===0&&(me=138,$e=3),B=0;B<=G;B++)if(H=te,te=R[2*(B+1)+1],!(++ne<me&&H===te)){if(ne<$e)for(;oe(I,H,I.bl_tree),--ne!=0;);else H!==0?(H!==Z&&(oe(I,H,I.bl_tree),ne--),oe(I,S,I.bl_tree),ie(I,ne-3,2)):ne<=10?(oe(I,D,I.bl_tree),ie(I,ne-3,3)):(oe(I,A,I.bl_tree),ie(I,ne-11,7));Z=H,$e=(ne=0)===te?(me=138,3):H===te?(me=6,3):(me=7,4)}}l(P);var j=!1;function M(I,R,G,B){ie(I,(c<<1)+(B?1:0),3),(function(H,Z,te,ne){fe(H),le(H,te),le(H,~te),o.arraySet(H.pending_buf,H.window,Z,te,H.pending),H.pending+=te})(I,R,G)}s._tr_init=function(I){j||((function(){var R,G,B,H,Z,te=new Array(y+1);for(H=B=0;H<d-1;H++)for(q[H]=B,R=0;R<1<<C[H];R++)x[B++]=H;for(x[B-1]=H,H=Z=0;H<16;H++)for(P[H]=Z,R=0;R<1<<L[H];R++)U[Z++]=H;for(Z>>=7;H<f;H++)for(P[H]=Z<<7,R=0;R<1<<L[H]-7;R++)U[256+Z++]=H;for(G=0;G<=y;G++)te[G]=0;for(R=0;R<=143;)K[2*R+1]=8,R++,te[8]++;for(;R<=255;)K[2*R+1]=9,R++,te[9]++;for(;R<=279;)K[2*R+1]=7,R++,te[7]++;for(;R<=287;)K[2*R+1]=8,R++,te[8]++;for(Ie(K,u+1,te),R=0;R<f;R++)_[2*R+1]=5,_[2*R]=Se(R,5);O=new se(K,C,p+1,u,y),$=new se(_,L,0,f,y),T=new se(new Array(0),z,0,w,v)})(),j=!0),I.l_desc=new V(I.dyn_ltree,O),I.d_desc=new V(I.dyn_dtree,$),I.bl_desc=new V(I.bl_tree,T),I.bi_buf=0,I.bi_valid=0,_e(I)},s._tr_stored_block=M,s._tr_flush_block=function(I,R,G,B){var H,Z,te=0;0<I.level?(I.strm.data_type===2&&(I.strm.data_type=(function(ne){var me,$e=4093624447;for(me=0;me<=31;me++,$e>>>=1)if(1&$e&&ne.dyn_ltree[2*me]!==0)return a;if(ne.dyn_ltree[18]!==0||ne.dyn_ltree[20]!==0||ne.dyn_ltree[26]!==0)return r;for(me=32;me<p;me++)if(ne.dyn_ltree[2*me]!==0)return r;return a})(I)),F(I,I.l_desc),F(I,I.d_desc),te=(function(ne){var me;for(g(ne,ne.dyn_ltree,ne.l_desc.max_code),g(ne,ne.dyn_dtree,ne.d_desc.max_code),F(ne,ne.bl_desc),me=w-1;3<=me&&ne.bl_tree[2*N[me]+1]===0;me--);return ne.opt_len+=3*(me+1)+5+5+4,me})(I),H=I.opt_len+3+7>>>3,(Z=I.static_len+3+7>>>3)<=H&&(H=Z)):H=Z=G+5,G+4<=H&&R!==-1?M(I,R,G,B):I.strategy===4||Z===H?(ie(I,2+(B?1:0),3),E(I,K,_)):(ie(I,4+(B?1:0),3),(function(ne,me,$e,xe){var De;for(ie(ne,me-257,5),ie(ne,$e-1,5),ie(ne,xe-4,4),De=0;De<xe;De++)ie(ne,ne.bl_tree[2*N[De]+1],3);W(ne,ne.dyn_ltree,me-1),W(ne,ne.dyn_dtree,$e-1)})(I,I.l_desc.max_code+1,I.d_desc.max_code+1,te+1),E(I,I.dyn_ltree,I.dyn_dtree)),_e(I),B&&fe(I)},s._tr_tally=function(I,R,G){return I.pending_buf[I.d_buf+2*I.last_lit]=R>>>8&255,I.pending_buf[I.d_buf+2*I.last_lit+1]=255&R,I.pending_buf[I.l_buf+I.last_lit]=255&G,I.last_lit++,R===0?I.dyn_ltree[2*G]++:(I.matches++,R--,I.dyn_ltree[2*(x[G]+p+1)]++,I.dyn_dtree[2*Y(R)]++),I.last_lit===I.lit_bufsize-1},s._tr_align=function(I){ie(I,2,3),oe(I,k,K),(function(R){R.bi_valid===16?(le(R,R.bi_buf),R.bi_buf=0,R.bi_valid=0):8<=R.bi_valid&&(R.pending_buf[R.pending++]=255&R.bi_buf,R.bi_buf>>=8,R.bi_valid-=8)})(I)}},{"../utils/common":41}],53:[function(i,n,s){n.exports=function(){this.input=null,this.next_in=0,this.avail_in=0,this.total_in=0,this.output=null,this.next_out=0,this.avail_out=0,this.total_out=0,this.msg="",this.state=null,this.data_type=2,this.adler=0}},{}],54:[function(i,n,s){(function(o){(function(a,r){if(!a.setImmediate){var l,c,d,p,u=1,f={},w=!1,m=a.document,y=Object.getPrototypeOf&&Object.getPrototypeOf(a);y=y&&y.setTimeout?y:a,l={}.toString.call(a.process)==="[object process]"?function(S){process.nextTick(function(){v(S)})}:(function(){if(a.postMessage&&!a.importScripts){var S=!0,D=a.onmessage;return a.onmessage=function(){S=!1},a.postMessage("","*"),a.onmessage=D,S}})()?(p="setImmediate$"+Math.random()+"$",a.addEventListener?a.addEventListener("message",k,!1):a.attachEvent("onmessage",k),function(S){a.postMessage(p+S,"*")}):a.MessageChannel?((d=new MessageChannel).port1.onmessage=function(S){v(S.data)},function(S){d.port2.postMessage(S)}):m&&"onreadystatechange"in m.createElement("script")?(c=m.documentElement,function(S){var D=m.createElement("script");D.onreadystatechange=function(){v(S),D.onreadystatechange=null,c.removeChild(D),D=null},c.appendChild(D)}):function(S){setTimeout(v,0,S)},y.setImmediate=function(S){typeof S!="function"&&(S=new Function(""+S));for(var D=new Array(arguments.length-1),A=0;A<D.length;A++)D[A]=arguments[A+1];var C={callback:S,args:D};return f[u]=C,l(u),u++},y.clearImmediate=b}function b(S){delete f[S]}function v(S){if(w)setTimeout(v,0,S);else{var D=f[S];if(D){w=!0;try{(function(A){var C=A.callback,L=A.args;switch(L.length){case 0:C();break;case 1:C(L[0]);break;case 2:C(L[0],L[1]);break;case 3:C(L[0],L[1],L[2]);break;default:C.apply(r,L)}})(D)}finally{b(S),w=!1}}}}function k(S){S.source===a&&typeof S.data=="string"&&S.data.indexOf(p)===0&&v(+S.data.slice(p.length))}})(typeof self>"u"?o===void 0?this:o:self)}).call(this,typeof cs<"u"?cs:typeof self<"u"?self:typeof window<"u"?window:{})},{}]},{},[10])(10)})})(mo)),mo.exports}var gg=mg();const Xl=hg(gg);function Ql(e){const t=(e||"").trim();return t?`即现（${t}）`:"即现"}async function ec(e,t){var i,n,s;if(!t)return"";if(typeof document<"u"){const o=document.querySelector(`.protyle-title[data-node-id="${t}"] .protyle-title__input`)||document.querySelector(`.protyle[data-doc-id="${t}"] .protyle-title__input`)||(e.getActiveDocumentId()===t?document.querySelector(".layout__wnd--active .protyle-title__input"):null)||document.querySelector(".protyle-title__input"),a=((o==null?void 0:o.innerText)||(o==null?void 0:o.textContent)||"").trim();if(a)return a}if(e.latestCompiledDoc&&e.latestCompiledDoc.docId===t){const o=(i=e.latestCompiledDoc.slides)==null?void 0:i[0],a=(n=o==null?void 0:o.blocks)==null?void 0:n.find(r=>r.type==="h"||r.type==="NodeHeading");if(a!=null&&a.content)return a.content.trim()}try{const o=await un(`SELECT content FROM blocks WHERE id = '${t}' AND type = 'd' LIMIT 1`).catch(()=>[]);if(Array.isArray(o)&&o.length>0&&((s=o[0])!=null&&s.content))return String(o[0].content).trim()}catch{}return""}async function vg(e,t,i){var c,d,p;const n=Vw(),s=!!((c=n==null?void 0:n.isPinned)!=null&&c.value),o=String(((d=n==null?void 0:n.pinnedDocId)==null?void 0:d.value)||"");if(s&&o&&i&&i!==o)return;const a=i||(s&&o?o:e.currentDocId||e.getActiveDocumentId());let r=(t||"").trim();!r&&a&&(r=typeof e.fetchDocumentTitle=="function"?await e.fetchDocumentTitle(a):await ec(e,a));const l=Ql(r);if(e.previewTab&&typeof e.previewTab.updateTitle=="function"){e.previewTab.updateTitle(l),e.previewTab.headElement&&e.previewTab.headElement.setAttribute("title",l);return}if(typeof document<"u"){const u=Array.from(document.querySelectorAll('.layout-tab-bar .item[data-type="tab-header"]'));for(const f of u){const w=f.querySelector(".item__text"),m=((p=w==null?void 0:w.textContent)==null?void 0:p.trim())||"";if(m.includes("Slidev 演示预览")||m.startsWith("即现")){w&&(w.textContent=l),f.setAttribute("title",l);break}}}}function In(e){return(e||"").replace(/[/\\?%*:|"<>]/g,"_").replace(/_+/g,"_").trim().replace(/^_+|_+$/g,"")||"presentation"}async function Mi(e,t,i){var s,o;const n=t||(e==null?void 0:e.docId)||"";if(i&&typeof i.fetchDocumentTitle=="function"&&n)try{const a=await i.fetchDocumentTitle(n);if(a&&a.trim())return In(a)}catch{}if(typeof document<"u")try{const a=(n?document.querySelector(`.protyle-title[data-node-id="${n}"] .protyle-title__input`):null)||(n?document.querySelector(`.protyle[data-doc-id="${n}"] .protyle-title__input`):null)||document.querySelector(".layout__wnd--active .protyle-title__input")||document.querySelector(".protyle-title__input"),r=((a==null?void 0:a.innerText)||(a==null?void 0:a.textContent)||"").trim();if(r)return In(r)}catch{}if((s=e==null?void 0:e.config)!=null&&s.title&&e.config.title.trim()&&e.config.title.trim().toLowerCase()!=="presentation")return In(e.config.title);if(e!=null&&e.slides&&e.slides.length>0){const r=(o=e.slides[0].blocks)==null?void 0:o.find(c=>c.type==="h"||c.type==="NodeHeading"),l=((r==null?void 0:r.content)||"").replace(/^#+\s*/,"").trim();if(l)return In(l)}return"presentation"}function bg(e,t){if(typeof document>"u")return!1;const i=URL.createObjectURL(t),n=document.createElement("a");return n.href=i,n.download=e,document.body.appendChild(n),n.click(),document.body.removeChild(n),URL.revokeObjectURL(i),!0}function ua(e,t){if(typeof document>"u")return!1;const i=document.createElement("a");return i.href=t,i.download=e,document.body.appendChild(i),i.click(),document.body.removeChild(i),!0}async function yg(e){if(typeof navigator>"u"||!navigator.clipboard||typeof ClipboardItem>"u")return!1;try{const i=await(await fetch(e)).blob();return await navigator.clipboard.write([new ClipboardItem({[i.type||"image/png"]:i})]),!0}catch(t){return console.warn("[image-exporter] 复制图像至剪贴板失败:",t),!1}}async function Ho(e,t){return new Promise(i=>{let n=[],s=null;const o=()=>{s&&(clearTimeout(s),s=null),n.forEach(l=>l()),n=[]};s=setTimeout(()=>{o(),i({success:!1,error:"单页截图超时（沙箱无响应）"})},2e4);const a=e.onCapturePageDone(l=>{o(),i({success:!0,dataUrl:l.dataUrl})});n.push(a);const r=e.onCaptureError(l=>{o(),i({success:!1,error:l})});n.push(r),e.startImageExport({mode:"current",scale:(t==null?void 0:t.scale)||2,format:(t==null?void 0:t.format)||"png"})})}async function tc(e,t){const i=[],n=In((t==null?void 0:t.title)||"presentation");return new Promise(s=>{let o=[],a=null;const r=()=>{a&&(clearTimeout(a),a=null),o.forEach(f=>f()),o=[]},l=()=>{a&&clearTimeout(a),a=setTimeout(()=>{r(),s({success:!1,error:"幻灯片逐页导出超时（沙箱无响应）"})},35e3)};l();const c=e.onCaptureProgress(f=>{var w;l(),(w=t==null?void 0:t.onProgress)==null||w.call(t,f.current,f.total,f.pageIndex)});o.push(c);const d=e.onCapturePageDone(f=>{l(),(f.mode==="all"||!f.mode)&&i.push({pageIndex:f.pageIndex,dataUrl:f.dataUrl})});o.push(d);const p=async()=>{r();try{if(i.length===0){s({success:!1,error:"未采集到幻灯片图像数据"});return}const f=new Xl,w=(t==null?void 0:t.format)==="jpeg"?"jpg":"png";for(const b of i){const v=String(b.pageIndex).padStart(2,"0"),k=b.dataUrl.split(",")[1];f.file(`slide-${v}.${w}`,k,{base64:!0})}const m=await f.generateAsync({type:"blob",compression:"DEFLATE"}),y=bg(`${n}.zip`,m);s({success:y,total:i.length})}catch(f){s({success:!1,error:(f==null?void 0:f.message)||String(f)})}};o.push(e.onCaptureComplete(p));const u=e.onCaptureError(f=>{r(),s({success:!1,error:f})});o.push(u),e.startImageExport({mode:"all",scale:(t==null?void 0:t.scale)||2,format:(t==null?void 0:t.format)||"png"})})}async function ic(e,t){if(typeof document>"u")return{success:!1,error:"环境不支持 DOM 沙箱挂载"};const i=document.createElement("iframe");i.style.position="fixed",i.style.left="-9999px",i.style.top="-9999px",i.style.width="1920px",i.style.height="1080px",i.style.opacity="0",i.style.pointerEvents="none",i.src="/plugins/siyuan-live-slides/slides-client/index.html?headless=true",document.body.appendChild(i);const n=new Qn;n.attach(i);try{if(await new Promise((s,o)=>{const a=setTimeout(()=>o(new Error("静默后台沙箱加载超时")),12e3);n.onClientReady(()=>{clearTimeout(a),s()})}),n.updateSlides(e.slides,e.config,e.fullMarkdown),await new Promise(s=>setTimeout(s,250)),(t==null?void 0:t.mode)==="current"){const s=await Ho(n,t);return{success:s.success,total:1,error:s.error}}else{const s=(t==null?void 0:t.title)||await Mi(e,e.docId);return await tc(n,{...t,title:s})}}catch(s){return{success:!1,error:(s==null?void 0:s.message)||String(s)}}finally{n.detach(),i.remove()}}const kg=1500,wg=500,xg=4,Sg=new Set(["INPUT","TEXTAREA","SELECT"]);function nc(e){const t=e;return!t||!t.tagName?!1:Sg.has(t.tagName)||t.isContentEditable===!0}function Cg(e){let t="",i=!1,n=null,s=null;function o(){e.onStateChange&&e.onStateChange({display:t,invalid:i})}function a(){n&&(clearTimeout(n),n=null),s&&(clearTimeout(s),s=null)}function r(){a(),t="",i=!1,o()}function l(){n&&clearTimeout(n),n=setTimeout(r,kg)}function c(){n&&(clearTimeout(n),n=null),i=!0,o(),s&&clearTimeout(s),s=setTimeout(r,wg)}function d(p){if(e.isEnabled&&!e.isEnabled()||nc(p.target)||p.isComposing||p.ctrlKey||p.metaKey||p.altKey)return!1;if(/^[0-9]$/.test(p.key))return i||t.length>=xg||(t+=p.key,o(),l()),!0;if(p.key==="Enter"){if(!t||i)return!1;const f=parseInt(t,10),w=e.getTotalPages();return!isNaN(f)&&f>=1&&w>0&&f<=w?(r(),e.onJump(f),!0):(c(),!0)}return p.key==="Escape"&&(t||i)?(r(),!0):!1}return{handleKeydown:d,getState:()=>({display:t,invalid:i}),clear:r}}const _g={class:"spm-slides-tab__toolbar"},$g={class:"spm-slides-tab__nav"},Ig=["disabled"],Mg={class:"spm-page-badge"},Tg=["disabled"],Eg=["aria-label"],Ag=["aria-label"],Bg={class:"spm-slides-tab__tools"},Dg={key:3,class:"spm-export-image-dropdown",style:{position:"relative",display:"inline-flex","align-items":"center"}},Lg={key:0,class:"b3-menu b3-menu--context",style:{position:"absolute",top:"calc(100% + 4px)",right:"0","z-index":"100","min-width":"190px","box-shadow":"var(--b3-point-shadow)","border-radius":"4px",background:"var(--b3-theme-surface)"}},Pg=["src"],Og=Dt({__name:"SlidesPreviewTab",setup(e,{expose:t}){const i=zt("plugin"),n=zt("sandboxBridge",new Qn),s=new Um(n),o=new $p,a=ge("web-sandbox"),r=ge(3030),l=ge(null),c=ge(!1),d=ge(null),p=ge(1),u=ge(1),f=ge(!1),w=ge(!1),m=ge(!1),y=ge("siyuan"),b=ge(""),v=ge(""),k=ge(""),S=ge(!1),D=ge(!1),A=ge(""),C=ge(""),L=ge(!1),z=Cg({getTotalPages:()=>u.value,isEnabled:()=>!w.value,onJump:B=>_(B),onStateChange:B=>{C.value=B.display,L.value=B.invalid}});function N(B){if(B.key==="o"||B.key==="O"){if(w.value||B.isComposing||B.ctrlKey||B.metaKey||B.altKey||nc(B.target))return;B.preventDefault(),K();return}z.handleKeydown(B)&&B.preventDefault()}function K(){var B,H;if(a.value==="pro-cli"){(B=d.value)==null||B.focus(),ce.showMessage("Pro 模式使用官方原生总览：在画面内按 O 呼出");return}n.toggleOverview(),(H=d.value)==null||H.focus()}function _(B){var H;p.value=B,a.value==="pro-cli"?o.nativeBridge.navigateToPage(B):n.navigatePage(B),(H=d.value)==null||H.focus()}const U=ge("/plugins/siyuan-live-slides/slides-client/index.html");let x=null,q=null,O=null,$=null,T=null,P=null,se=null,V=null;vn(()=>{d.value&&(n.attach(d.value),o.nativeBridge.attach(d.value)),x=n.onSlideChanged((B,H)=>{p.value=B,u.value=H}),q=n.onBlockClicked((B,H)=>{p.value=H,s.setActiveBlockId(B),B||Rn(),i&&typeof i.handleBlockClickedFromSlide=="function"?i.handleBlockClickedFromSlide(B,H):B&&Vi(B,i==null?void 0:i.app)}),O=n.onOpenInEditor((B,H)=>{p.value=H,s.setActiveBlockId(B),Vi(B,i==null?void 0:i.app)}),$=o.nativeBridge.onPageChanged((B,H)=>{p.value=B,u.value=H}),T=n.onOpenPeekDrawer(async B=>{const H=Ys();if(B.peekType==="siyuan"&&H.enableWebServeJump){let Z=!1;if(V&&V.docId===B.target)Z=!0;else if(V&&V.slides&&V.slides.some(te=>{var ne;return(ne=te.blocks)==null?void 0:ne.some(me=>me.id===B.target)}))Z=!1;else try{const te=await un(`SELECT id, root_id, type FROM blocks WHERE id = '${B.target}' LIMIT 1`);te&&te.length>0&&(Z=te[0].type==="d"||te[0].id===te[0].root_id)}catch(te){console.warn("[SlidesPreviewTab] detect block type failed:",te)}y.value="web",S.value=!0,v.value=Ll(H.webServeUrl,B.target,{focus:!Z}),k.value=B.title||`${Z?"思源文档":"思源块"}: ${B.target.slice(0,8)}`,w.value=!0,n.freezeKeyboardNav(!0)}else{if(y.value=B.peekType,B.peekType==="siyuan")b.value=B.target,k.value=B.title||`块速览: ${B.target.slice(0,8)}`;else{const Z=Ul(B.target);if(Z.external){pe(B.target);return}S.value=!0,v.value=Z.url,k.value=B.title||Z.url}w.value=!0,n.freezeKeyboardNav(!0)}}),P=n.onRequestToggleFullscreen(()=>{F()}),se=n.onOpenPresenter(()=>{g()}),typeof document<"u"&&document.addEventListener("fullscreenchange",E)}),Vs(()=>{typeof document<"u"&&document.removeEventListener("fullscreenchange",E),T&&T(),P&&P(),se&&se(),x&&x(),q&&q(),O&&O(),$&&$(),n.detach(),z.clear(),s.destroy(),o.destroy()});async function Y(){if(a.value==="web-sandbox"){if(!V){ce.showMessage("请先在主编辑区打开演示文档");return}ce.showMessage("正在探测本地 Node 环境并编排 Slidev Pro 进程...");const B=await o.startProMode(V,wo);if(!B.success){ce.showMessage(`无法启动官方 Pro 模式：${B.error}`);return}a.value="pro-cli",r.value=B.port||3030,U.value=B.url,d.value&&o.nativeBridge.attach(d.value),ce.showMessage(`🟢 已成功接入官方原生 Slidev 服务 (端口: ${r.value})`)}else o.stopProMode(),a.value="web-sandbox",U.value="/plugins/siyuan-live-slides/slides-client/index.html",d.value&&n.attach(d.value),ce.showMessage("已切回内置高保真沙箱")}function le(){D.value=!D.value,D.value?(A.value=(V==null?void 0:V.docId)||"",i&&typeof i.updatePreviewTabHeader=="function"&&i.updatePreviewTabHeader("",A.value)):(A.value="",_e(),i&&typeof i.updatePreviewTabHeader=="function"&&i.updatePreviewTabHeader())}let ie=0;function oe(B){if(w.value||Math.abs(B.deltaY)<Math.abs(B.deltaX)||Math.abs(B.deltaY)<15)return;const H=Date.now();H-ie<280||(ie=H,B.deltaY>0?Ie():Se())}function Se(){if(p.value>1){const B=p.value-1;p.value=B,a.value==="pro-cli"?o.nativeBridge.navigateToPage(B):n.navigatePage(B)}}function Ie(){if(p.value<u.value){const B=p.value+1;p.value=B,a.value==="pro-cli"?o.nativeBridge.navigateToPage(B):n.navigatePage(B)}}function _e(){i&&typeof i.compileCurrentDocument=="function"?i.compileCurrentDocument():i!=null&&i.eventBus&&typeof i.eventBus.emit=="function"&&i.eventBus.emit("slides:request-compile")}function fe(){w.value=!1,n.freezeKeyboardNav(!1)}function X(){fe()}function pe(B){var ne,me;const H=/^file:/i.test(B),Z=H||/^[a-zA-Z]:[\\/]/.test(B),te=Tt("electron");if(Z&&typeof((ne=te==null?void 0:te.shell)==null?void 0:ne.openPath)=="function"){te.shell.openPath(H?Wl(B):B),ce.showMessage("本地文件不在思源工作区内，已交由系统默认浏览器打开");return}typeof((me=te==null?void 0:te.shell)==null?void 0:me.openExternal)=="function"?te.shell.openExternal(B).catch(()=>{typeof window<"u"&&window.open(B,"_blank")}):typeof window<"u"&&window.open(B,"_blank"),ce.showMessage("该地址无法在速览抽屉内加载，已交由系统默认浏览器打开")}function E(){typeof document<"u"&&(c.value=!!document.fullscreenElement,n.postMessage("FULLSCREEN_CHANGED",{isFullscreen:c.value}))}function F(){const B=l.value||d.value;B&&(document.fullscreenElement?document.exitFullscreen().then(()=>{n.postMessage("FULLSCREEN_CHANGED",{isFullscreen:!1})}).catch(()=>{}):B.requestFullscreen().then(()=>{n.postMessage("FULLSCREEN_CHANGED",{isFullscreen:!0})}).catch(()=>{}))}function g(){i&&typeof i.openPresenterTab=="function"&&i.openPresenterTab()}async function W(){if(!V){ce.showMessage("请先在主编辑区打开幻灯片文档");return}const B=await Mi(V,i==null?void 0:i.currentDocId,i),H=Yl(V,{title:B});Zl(`${B}.html`,H)&&ce.showMessage(`已开始下载单文件离线 HTML 演示包 (${B}.html)`)}function j(){if(!V){ce.showMessage("请先在主编辑区打开幻灯片文档");return}Jl(V)&&ce.showMessage("已唤起打印视窗，请在打印选项中选择「另存为 PDF」")}const M=ge(!1);async function I(){if(M.value){ce.showMessage("正在逐页导出幻灯片图片中，请稍候...",2e3);return}if(!V){ce.showMessage("请先在主编辑区打开幻灯片文档");return}M.value=!0;try{ce.showMessage("正在逐页导出幻灯片图片...",2e3);const B=await Mi(V,i==null?void 0:i.currentDocId,i),H=await tc(n,{title:B,onProgress:(Z,te)=>{ce.showMessage(`正在导出幻灯片图片 (${Z} / ${te})...`,1500)}});H.success?ce.showMessage(`🎉 成功导出 ${H.total||0} 张高清图片并保存为 ${B}.zip！`,4e3):ce.showMessage(`导出图片失败：${H.error||"未知异常"}`)}finally{M.value=!1}}async function R(){if(!V){ce.showMessage("请先在主编辑区打开幻灯片文档");return}ce.showMessage("正在导出当前幻灯片图片...",1500);const B=await Ho(n);if(B.success&&B.dataUrl){const H=await Mi(V,i==null?void 0:i.currentDocId,i),Z=p.value||1,ne=(u.value||1)>1?`${H}-${Z}.png`:`${H}.png`;ua(ne,B.dataUrl),ce.showMessage(`已下载当前页高清图片 (${ne})`)}else ce.showMessage(`导出当前页图片失败：${B.error||"未知异常"}`)}async function G(){if(!V){ce.showMessage("请先在主编辑区打开幻灯片文档");return}ce.showMessage("正在复制当前幻灯片截图到剪贴板...",1500);const B=await Ho(n);if(B.success&&B.dataUrl)if(await yg(B.dataUrl))ce.showMessage(`已成功将第 ${p.value||1} 页幻灯片复制到剪贴板！`);else{const Z=await Mi(V,i==null?void 0:i.currentDocId,i),te=p.value||1,me=(u.value||1)>1?`${Z}-${te}.png`:`${Z}.png`;ua(me,B.dataUrl),ce.showMessage(`剪贴板权限不可用，已自动下载为 ${me}`)}else ce.showMessage(`复制失败：${B.error||"未知异常"}`)}return t({updateDocument(B,H){D.value&&A.value&&H&&H!==A.value||(V=B,D.value&&!A.value&&(A.value=B.docId),u.value=B.slides.length,s.setDocId(B.docId),s.updateSlidesIndex(B.slides),a.value==="pro-cli"?o.scaffolder.scaffold(B,wo).catch(()=>{}):n.updateSlides(B.slides,B.config,B.fullMarkdown,B.customThemeCss),i&&typeof i.updatePreviewTabHeader=="function"&&i.updatePreviewTabHeader("",B.docId))},navigateToBlock(B){s.onCursorFocusBlock(B)},isPinned:D,pinnedDocId:A,engineMode:a,toggleEngineMode:Y}),(B,H)=>(J(),ee("div",{class:"spm-slides-preview-tab",onKeydown:N},[h("div",_g,[h("div",$g,[h("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s",disabled:p.value<=1,"aria-label":"上一页",onClick:Se},[re(de,{name:"chevron-left"})],8,Ig),h("span",Mg,we(p.value)+" / "+we(u.value||1),1),h("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s",disabled:p.value>=u.value,"aria-label":"下一页",onClick:Ie},[re(de,{name:"chevron-right"})],8,Tg),h("button",{class:Ce(["spm-icon-btn b3-tooltips b3-tooltips__s",{"is-primary":D.value}]),"aria-label":D.value?"已锁定当前文档（点击解除）："+A.value:"点击锁定当前文档（不随主编辑区切换）",onClick:le},[re(de,{name:"pin"}),h("span",null,we(D.value?"已锁定":"跟随"),1)],10,Eg),he(It)("proMode")?(J(),ee("button",{key:0,class:Ce(["spm-icon-btn b3-tooltips b3-tooltips__s",{"is-primary":a.value==="pro-cli"}]),"aria-label":a.value==="pro-cli"?"当前：官方原生 Pro 模式 (localhost:"+r.value+")，点击切回沙箱":"当前：内置高保真沙箱，点击切换官方原生 Pro 模式",onClick:Y},[re(de,{name:"rocket"}),h("span",null,we(a.value==="pro-cli"?"Pro ("+r.value+")":"沙箱"),1)],10,Ag)):Te("",!0)]),h("div",Bg,[h("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"缩略图总览 (O)",onClick:K},[re(de,{name:"columns"})]),he(It)("presenterMode")?(J(),ee("button",{key:0,class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"双屏演讲者视图 (Presenter Mode ⌥M)",onClick:g},[re(de,{name:"presenter"})])):Te("",!0),he(It)("exportHtml")?(J(),ee("button",{key:1,class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"导出单文件 HTML 演示包",onClick:W},[re(de,{name:"export-html"})])):Te("",!0),he(It)("exportPdf")?(J(),ee("button",{key:2,class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"导出 16:9 PDF 演示讲义",onClick:j},[re(de,{name:"export-pdf"})])):Te("",!0),he(It)("exportImage")?(J(),ee("div",Dg,[h("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"导出幻灯片为图片包 (ZIP)",onClick:I},[re(de,{name:"export-image"})]),h("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s",style:{padding:"2px 2px","margin-left":"-4px"},"aria-label":"更多图片导出选项",onClick:H[0]||(H[0]=Zt(Z=>f.value=!f.value,["stop"]))},[re(de,{name:"chevron-down"})]),f.value?(J(),ee("div",Lg,[h("button",{class:"b3-menu__item",onClick:H[1]||(H[1]=Z=>{I(),f.value=!1})},[...H[6]||(H[6]=[h("span",{class:"b3-menu__label"},"📦 导出全篇为图片包 (ZIP)",-1)])]),h("button",{class:"b3-menu__item",onClick:H[2]||(H[2]=Z=>{R(),f.value=!1})},[...H[7]||(H[7]=[h("span",{class:"b3-menu__label"},"🖼️ 导出当前页为图片 (PNG)",-1)])]),h("button",{class:"b3-menu__item",onClick:H[3]||(H[3]=Z=>{G(),f.value=!1})},[...H[8]||(H[8]=[h("span",{class:"b3-menu__label"},"📋 复制当前页至剪贴板",-1)])])])):Te("",!0)])):Te("",!0),h("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"重新编译并刷新",onClick:_e},[re(de,{name:"refresh"})]),h("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"全屏放映",onClick:F},[re(de,{name:"fullscreen"})])])]),h("div",{ref_key:"fullscreenContainerRef",ref:l,class:"spm-slides-tab__viewport spm-slides-fullscreen-container",onWheel:oe},[h("iframe",{ref_key:"sandboxIframeRef",ref:d,class:"spm-slides-tab__iframe",src:U.value,frameborder:"0",allow:"fullscreen; autoplay"},null,8,Pg),re(im,{visible:w.value,"onUpdate:visible":H[4]||(H[4]=Z=>w.value=Z),"is-maximized":m.value,"onUpdate:isMaximized":H[5]||(H[5]=Z=>m.value=Z),title:k.value,onClose:fe},{default:nl(()=>[y.value==="siyuan"&&b.value?(J(),Jt(um,{key:0,"block-id":b.value,title:k.value,plugin:he(i),onExternalJump:X},null,8,["block-id","title","plugin"])):Te("",!0),S.value?Ot((J(),Jt(jm,{key:1,visible:w.value&&y.value==="web",url:v.value,title:k.value,onExternalJump:X},null,8,["visible","url","title"])),[[Lo,y.value==="web"]]):Te("",!0)]),_:1},8,["visible","is-maximized","title"]),Ot(h("div",{class:Ce(["spm-jump-badge",{"is-invalid":L.value}])},we(C.value),3),[[Lo,C.value]])],544)],32))}}),Rg=ii(Og,[["__scopeId","data-v-2bf44815"]]);function sc(e){if(!e||e.length===0)return{maxStep:0,blockMap:new Map,idMap:new Map};const t=new Map,i=new Map,n=new Map;let s=0;const o=(r,l)=>{t.set(r,l);const c=r.id||r.blockId;c&&i.set(c,l)},a=e.filter(r=>r.slot!=="slot-divider-right");for(const r of a){if(r.parentContainerId&&r.parentClicks&&r.parentClicks.trim()!==""&&!n.has(r.parentContainerId)){const p=String(r.parentClicks).trim();if(/^\d+$/.test(p)){const u=parseInt(p,10);s=Math.max(s,u),n.set(r.parentContainerId,u)}else s+=1,n.set(r.parentContainerId,s)}if(!!!(r.clicks&&String(r.clicks).trim()!=="")){if(r.parentContainerId&&n.has(r.parentContainerId)){const p=n.get(r.parentContainerId);o(r,{type:"step",step:p})}else o(r,{type:"always"});continue}const c=String(r.clicks).trim();if(!c){s+=1,o(r,{type:"step",step:s});continue}if(c.startsWith("[")&&c.endsWith("]"))try{const p=JSON.parse(c);if(Array.isArray(p)&&p.length>=2){const u=Math.min(Number(p[0]),Number(p[1])),f=Math.max(Number(p[0]),Number(p[1]));if(!isNaN(u)&&!isNaN(f)){s=Math.max(s,f),o(r,{type:"range",min:u,max:f});continue}}}catch{}if(c.toLowerCase()==="hide"){s+=1,o(r,{type:"hide",step:s});continue}if(/^\+\d+$/.test(c)||c==="true"){const p=c==="true"?1:parseInt(c.slice(1),10)||1;s+=p,o(r,{type:"step",step:s});continue}if(/^-\d+$/.test(c)){const p=parseInt(c.slice(1),10)||1;s=Math.max(1,s-p),o(r,{type:"step",step:s});continue}if(/^\d+$/.test(c)){const p=parseInt(c,10);if(!isNaN(p)){s=Math.max(s,p),o(r,{type:"step",step:p});continue}}const d=parseInt(c,10);!isNaN(d)&&d>0?(s=Math.max(s,d),o(r,{type:"step",step:d})):(s+=1,o(r,{type:"step",step:s}))}return{maxStep:s,blockMap:t,idMap:i}}function Ng(e,t,i){if(!e)return"v-click-visible";const n=e.id||e.blockId,s=i.blockMap.get(e)||(n?i.idMap.get(n):null);return!s||s.type==="always"?"v-click-visible":s.type==="range"?t>=s.min&&t<=s.max?"v-click-visible":"v-click-hidden":s.type==="hide"?t<s.step?"v-click-visible":"v-click-hidden":s.type==="step"?t>=s.step?"v-click-visible":"v-click-hidden":"v-click-visible"}const Fo=980;function zg(e){if(!e)return 0;const i=sc(e.blocks||[]).maxStep||0,n=e.frontmatter||{},s=n.mask;if(s!=="down"&&s!=="right")return i;const o=vd(n.maskRatio),r=n.maskInitial==="revealed"?Math.max(0,o.steps-1):o.steps;return Math.max(i,r)}function Hg(e,t=Fo){const i=(e||"16/9").trim();let n=16/9;if(i==="4/3"||i==="4:3")n=4/3;else if(i==="16/10"||i==="16:10")n=16/10;else if(i.includes("/")||i.includes(":")){const o=i.includes("/")?"/":":",a=i.split(o).map(r=>parseFloat(r.trim()));a.length===2&&a[0]>0&&a[1]>0&&!isNaN(a[0])&&!isNaN(a[1])&&(n=a[0]/a[1])}else{const o=parseFloat(i);!isNaN(o)&&o>.2&&o<5&&(n=o)}const s=Math.ceil(t/n);return{baseWidth:t,baseHeight:s,ratio:n}}function fa(e,t,i=Fo,n=552,s=16){const o=i>0?i:Fo,a=n>0?n:552,r=Math.max(0,e-s),l=Math.max(0,t-s);if(r<=0||l<=0)return{scale:.36,boxWidth:Math.round(o*.36),boxHeight:Math.round(a*.36)};const c=Math.min(r/o,l/a),d=Math.max(.08,Math.min(1.5,Number(c.toFixed(4))));return{scale:d,boxWidth:Math.max(1,Math.round(o*d)),boxHeight:Math.max(1,Math.round(a*d))}}function Fg(e){return{...e,frontmatter:{...e.frontmatter||{}},blocks:Array.isArray(e.blocks)?e.blocks.map(t=>({...t,attrs:t.attrs?{...t.attrs}:void 0,attributes:t.attributes?{...t.attributes}:void 0,motion:t.motion?{...t.motion}:void 0,children:Array.isArray(t.children)?t.children.map(i=>({...i,attrs:i.attrs?{...i.attrs}:void 0,attributes:i.attributes?{...i.attributes}:void 0})):void 0})):[]}}function pa(e,t){if(!e)return"";const i=Fg(e),n=i.frontmatter||{},s=n.layout||"default",o=(t==null?void 0:t.config)||{};(s==="image-right"||s==="image-left")&&!n.image&&!n.background&&o.image&&(n.image=o.image);const a=typeof(t==null?void 0:t.currentStep)=="number",r=a?Math.max(0,t.currentStep):0,l=a?sc(i.blocks||[]):null,d=ql(i,{containerClassName:"slide-block",leftColClass:"pdf-col pdf-col--left two-cols-left",rightColClass:"pdf-col pdf-col--right two-cols-right",allSlides:(t==null?void 0:t.allSlides)||[],currentPageIndex:(t==null?void 0:t.pageIndex)||i.pageIndex||1,highlight:!0,blockClassResolver:l?k=>{if(Ng(k,r,l)==="v-click-hidden")return"presenter-v-click-pending";if(r>0){const D=k.id||k.blockId,A=l.blockMap.get(k)||(D?l.idMap.get(D):void 0);if((A==null?void 0:A.type)==="step"&&A.step===r||(A==null?void 0:A.type)==="range"&&A.min===r)return"presenter-v-click-active"}return""}:void 0}).replace(/<video\b([^>]*)>/gi,(k,S)=>{let D=S.replace(/\bcontrols\b/gi,"").trim();return/\bmuted\b/i.test(D)||(D+=" muted"),`<video ${D.trim()}>`}),p=n.spacing,u=p&&p!=="inherit"?p:o.spacing||"normal",f=["slide-content",`layout-${s}`,`spacing-${u}`,n.class||"",n.layoutClass||""].filter(Boolean).join(" "),w=[],m=(n.background||"").trim();if(m)if(/^(?:https?:\/\/|\/|data:|assets\/|\.\/assets\/)/i.test(m)){const k=m.startsWith("assets/")?`/${m}`:m.startsWith("./assets/")?m.slice(1):m;w.push(`background-image:url('${ot(k)}');background-size:cover;background-position:center;background-repeat:no-repeat;`)}else w.push(`background:${ot(m)};`);const y=typeof n.zoom=="number"?n.zoom:typeof n.zoom=="string"?parseFloat(n.zoom):1,b=!isNaN(y)&&y>0?y:1;b!==1&&w.push(`width:${(100/b).toFixed(2)}%;height:${(100/b).toFixed(2)}%;transform-origin:top left;transform:scale(${b});`);const v=w.length>0?` style="${w.join("")}"`:"";return`<div class="${ot(f)}"${v}>${d}</div>`}const jg={class:"presenter-header"},Wg={class:"presenter-title-area"},Ug={class:"presenter-brand"},Vg={class:"header-pills"},Gg={class:"pill pill-page"},Kg={key:0,class:"pill pill-step"},qg={class:"header-toolbar"},Yg={class:"timer-capsule"},Zg={class:"timer-digits"},Jg={class:"timer-actions"},Xg=["aria-label"],Qg={class:"wall-clock b3-tooltips b3-tooltips__sw","aria-label":"系统当前时间"},ev={key:0,class:"presenter-grid"},tv={class:"slide-panels"},iv={class:"panel-box current-slide-panel"},nv={class:"panel-header"},sv={class:"panel-header-left"},ov={class:"panel-page-num"},rv={class:"panel-header-meta"},av={key:0,class:"panel-step-pill"},lv={class:"panel-layout-pill"},cv=["aria-label"],dv=["data-theme","data-slides-theme","data-normalize-headings","data-hide-unordered-markers","data-hide-ordered-markers","innerHTML"],uv={key:1,class:"panel-fallback"},fv=["aria-label"],pv={class:"panel-header"},hv={class:"panel-header-left"},mv={key:0,class:"panel-page-num"},gv={class:"panel-header-meta"},vv={key:0,class:"panel-end-pill"},bv={key:1,class:"panel-layout-pill"},yv=["aria-label"],kv=["data-theme","data-slides-theme","data-normalize-headings","data-hide-unordered-markers","data-hide-ordered-markers","innerHTML"],wv={key:1,class:"panel-fallback"},xv={class:"notes-panel"},Sv={class:"panel-header"},Cv={class:"panel-header-left"},_v={class:"notes-size-controls"},$v=["disabled"],Iv={class:"notes-size-value"},Mv=["disabled"],Tv={key:1,class:"presenter-empty"},Ev={class:"empty-icon-wrap"},Av={class:"empty-actions"},Bv={class:"presenter-actions"},Dv={class:"nav-btn-group"},Lv=["disabled"],Pv=["disabled"],Ov={class:"actions-center"},Rv={class:"center-meta"},Nv={class:"progress-pill"},zv={class:"nav-btn-group"},Hv=["aria-label"],Fv={class:"step-dots-text"},jv=["disabled"],Wv=["disabled"],Uv=280,Vv=15,Gv=Dt({__name:"SlidesPresenterTab",setup(e,{expose:t}){const i=zt("plugin"),n=zt("sandboxBridge",new Qn),s=ge([]),o=ge({}),a=ge(1),r=ge(0),l=ge(0),c=ge(0),d=ye(()=>s.value.length||l.value),p=ge(null),u=ge(null),f=ge({width:0,height:0}),w=ge({width:0,height:0}),m=ye(()=>{var ae;return Hg((ae=o.value)==null?void 0:ae.aspectRatio)}),y=ye(()=>{var ae;return((ae=o.value)==null?void 0:ae.theme)||"default"}),b=ye(()=>{var ae;return((ae=o.value)==null?void 0:ae.colorSchema)==="light"?"light":"dark"}),v=ye(()=>{var ae;return!!((ae=o.value)!=null&&ae.normalizeHeadingSizes)}),k=ye(()=>{var ae;return((ae=o.value)==null?void 0:ae.showUnorderedListMarkers)===!1}),S=ye(()=>{var ae;return((ae=o.value)==null?void 0:ae.showOrderedListMarkers)===!1}),D=ye(()=>fa(f.value.width,f.value.height,m.value.baseWidth,m.value.baseHeight,14)),A=ye(()=>fa(w.value.width,w.value.height,m.value.baseWidth,m.value.baseHeight,14));function C(){p.value&&(f.value={width:p.value.clientWidth,height:p.value.clientHeight}),u.value&&(w.value={width:u.value.clientWidth,height:u.value.clientHeight})}let L=null;function z(){typeof window>"u"||typeof window.ResizeObserver!="function"||(L||(L=new window.ResizeObserver(()=>{C()})),L.disconnect(),p.value&&L.observe(p.value),u.value&&L.observe(u.value))}Ui([p,u,d],()=>{Ms(()=>{z(),C()})},{flush:"post"});const N=ge(0),K=ge(!0);let _=null,U=Date.now(),x=0;const q=ye(()=>{const ae=String(Math.floor(N.value/60)).padStart(2,"0"),ue=String(N.value%60).padStart(2,"0");return`${ae}:${ue}`});function O(){if(K.value){const ae=x+(Date.now()-U);N.value=Math.floor(ae/1e3)}}function $(){K.value?(x+=Date.now()-U,K.value=!1):(U=Date.now(),K.value=!0,O())}function T(){U=Date.now(),x=0,N.value=0}const P=ge("");let se=null;function V(){const ae=new Date,ue=String(ae.getHours()).padStart(2,"0"),Oe=String(ae.getMinutes()).padStart(2,"0");P.value=`${ue}:${Oe}`}const Y=ye(()=>s.value.length===0?null:s.value[a.value-1]||null),le=ye(()=>a.value>=s.value.length?null:s.value[a.value]||null),ie=ye(()=>Y.value?zg(Y.value):c.value),oe=ye(()=>a.value>1||r.value>0),Se=ye(()=>a.value<d.value||r.value<ie.value),Ie=ye(()=>pa(Y.value,{config:o.value,allSlides:s.value,pageIndex:a.value,currentStep:r.value})),_e=ye(()=>pa(le.value,{config:o.value,allSlides:s.value,pageIndex:a.value+1})),fe=ye(()=>{var ue;if(!Y.value)return"无内容";const ae=(ue=Y.value.blocks)==null?void 0:ue[0];return(ae==null?void 0:ae.content)||(ae==null?void 0:ae.rawMarkdown)||`第 ${a.value} 页`});function X(ae){return(ae||[]).slice(1).map(ue=>(ue.content||ue.rawMarkdown||"").trim()).filter(ue=>ue&&!/^(image\s+)?assets\/\S*$/i.test(ue)&&!/^!\[[^\]]*\]\(assets\/[^)]*\)$/.test(ue)).join(" | ").slice(0,120)}const pe=ye(()=>{var ae;return X((ae=Y.value)==null?void 0:ae.blocks)}),E=ye(()=>{var ue;if(!le.value)return"演示结束";const ae=(ue=le.value.blocks)==null?void 0:ue[0];return(ae==null?void 0:ae.content)||(ae==null?void 0:ae.rawMarkdown)||`第 ${a.value+1} 页`}),F=ye(()=>le.value?X(le.value.blocks):"这是最后一页"),g=ye(()=>{var ae;return((ae=Y.value)==null?void 0:ae.notes)||""}),W=ge(20);function j(){W.value<36&&(W.value+=2)}function M(){W.value>14&&(W.value-=2)}const I=ye(()=>d.value<=1?100:Math.round(a.value/d.value*100));let R=null;try{R=new BroadcastChannel("siyuan-slides-sync"),R.onmessage=ae=>{const ue=ae.data;if(ue&&(ue.type==="SYNC_PAGE"&&typeof ue.page=="number"&&(a.value=ue.page,r.value=typeof ue.step=="number"?Math.max(0,ue.step):0,typeof ue.maxStep=="number"&&(c.value=Math.max(0,ue.maxStep))),ue.type==="SYNC_SLIDES"&&Array.isArray(ue.slides)&&(s.value=ue.slides,ue.config&&typeof ue.config=="object"&&(o.value=ue.config)),ue.type==="REQUEST_SYNC"&&s.value.length>0))try{R==null||R.postMessage({type:"SYNC_SLIDES",slides:JSON.parse(JSON.stringify(s.value)),config:JSON.parse(JSON.stringify(o.value||{}))}),R==null||R.postMessage({type:"SYNC_PAGE",page:a.value,step:r.value,maxStep:ie.value})}catch{}}}catch{R=null}function G(ae,ue=0){const Oe=Number(ae)||1,He=Math.max(0,Number(ue)||0);n.navigatePage(Oe,He);try{R==null||R.postMessage({type:"SYNC_PAGE",page:Oe,step:He,maxStep:ie.value})}catch{}}function B(){if(r.value<ie.value){r.value++,G(a.value,r.value);return}a.value<d.value&&(a.value++,r.value=0,G(a.value,0))}function H(){if(r.value>0){r.value--,G(a.value,r.value);return}a.value>1&&(a.value--,r.value=0,G(a.value,0))}function Z(){a.value<d.value&&(a.value++,r.value=0,G(a.value,0))}function te(){a.value>1&&(a.value--,r.value=0,G(a.value,0))}function ne(){a.value=1,r.value=0,T(),G(1,0)}function me(){const ae=i;typeof(ae==null?void 0:ae.openBottomPreviewTab)=="function"&&ae.openBottomPreviewTab()}function $e(){const ae=i;typeof(ae==null?void 0:ae.openStandalonePreviewWindow)=="function"&&ae.openStandalonePreviewWindow()}function xe(ae){var ue,Oe;if(!(ae.key===" "&&((Oe=(ue=ae.target)==null?void 0:ue.closest)!=null&&Oe.call(ue,"button")))){if(ae.shiftKey&&ae.key==="ArrowRight"||ae.key==="ArrowDown"){ae.preventDefault(),Z();return}if(ae.shiftKey&&ae.key==="ArrowLeft"||ae.key==="ArrowUp"){ae.preventDefault(),te();return}ae.key==="ArrowRight"||ae.key===" "||ae.key==="PageDown"?(ae.preventDefault(),B()):(ae.key==="ArrowLeft"||ae.key==="PageUp")&&(ae.preventDefault(),H())}}let De=0;function je(ae){var He,We;if(Math.abs(ae.deltaY)<Vv)return;const ue=(We=(He=ae.target)==null?void 0:He.closest)==null?void 0:We.call(He,".notes-content");if(ue){const lt=ue.scrollHeight-ue.clientHeight;if(lt>2&&(ae.deltaY>0&&ue.scrollTop<lt-1||ae.deltaY<0&&ue.scrollTop>1))return}const Oe=Date.now();Oe-De<Uv||(De=Oe,ae.deltaY>0?B():H())}let ze=null;return vn(()=>{var ue;U=Date.now(),x=0,_=window.setInterval(O,500),typeof document<"u"&&document.addEventListener("visibilitychange",O),V(),se=window.setInterval(V,1e3),ze=n.onSlideChanged((Oe,He,We,lt,Et)=>{a.value=Oe,He>0&&(l.value=He),typeof lt=="number"&&(r.value=Math.max(0,lt)),typeof Et=="number"&&(c.value=Math.max(0,Et))});try{R==null||R.postMessage({type:"REQUEST_SYNC"})}catch{}const ae=i==null?void 0:i.latestCompiledDoc;(ue=ae==null?void 0:ae.slides)!=null&&ue.length&&(s.value=ae.slides,ae.config&&(o.value=ae.config)),typeof window<"u"&&window.addEventListener("resize",C),Ms(()=>{z(),C()})}),Vs(()=>{_&&(window.clearInterval(_),_=null),typeof document<"u"&&document.removeEventListener("visibilitychange",O),se&&(window.clearInterval(se),se=null),ze&&ze(),typeof window<"u"&&window.removeEventListener("resize",C),L&&(L.disconnect(),L=null);try{R==null||R.close()}catch{}R=null}),t({updateDocument(ae){var ue;(ue=ae==null?void 0:ae.slides)!=null&&ue.length&&(s.value=ae.slides),ae!=null&&ae.config&&(o.value=ae.config)}}),(ae,ue)=>{var Oe,He,We;return J(),ee("div",{class:"spm-presenter-tab",tabindex:"0",onKeydown:xe,onWheel:je},[h("header",jg,[h("div",Wg,[h("div",Ug,[re(de,{name:"presenter",class:"brand-icon"}),ue[1]||(ue[1]=h("span",{class:"title-name"},"演讲者控制台",-1))]),h("div",Vg,[h("span",Gg,"P."+we(a.value)+" / "+we(d.value||1),1),ie.value>0?(J(),ee("span",Kg,[re(de,{name:"step",class:"pill-icon"}),$t(" 步进 "+we(r.value)+" / "+we(ie.value),1)])):Te("",!0)])]),h("div",qg,[h("button",{class:"btn-tool b3-tooltips b3-tooltips__s","aria-label":"弹出大屏放映独立窗口 (16:9)",onClick:$e},[re(de,{name:"window"}),ue[2]||(ue[2]=h("span",{class:"btn-tool-label"},"独立放映",-1))]),h("div",Yg,[re(de,{name:"clock",class:"timer-icon"}),h("span",Zg,we(q.value),1),h("div",Jg,[h("button",{class:"timer-btn b3-tooltips b3-tooltips__s","aria-label":K.value?"暂停计时":"继续计时",onClick:$},[re(de,{name:K.value?"pause":"play"},null,8,["name"])],8,Xg),h("button",{class:"timer-btn b3-tooltips b3-tooltips__s","aria-label":"重置计时",onClick:T},[re(de,{name:"reset"})])])]),h("div",Qg,[h("span",null,we(P.value),1)])])]),d.value>0?(J(),ee("main",ev,[h("section",tv,[h("div",iv,[h("div",nv,[h("div",sv,[ue[3]||(ue[3]=h("span",{class:"panel-tag is-current"},"当前放映",-1)),h("span",ov,"P."+we(a.value),1)]),h("div",rv,[ie.value>0?(J(),ee("span",av," 步进 "+we(r.value)+" / "+we(ie.value),1)):Te("",!0),h("span",lv,we(((He=(Oe=Y.value)==null?void 0:Oe.frontmatter)==null?void 0:He.layout)||"default"),1)])]),h("div",{ref_key:"currentPreviewRef",ref:p,class:"panel-preview","aria-label":fe.value},[Y.value?(J(),ee("div",{key:0,class:"presenter-thumb-box",style:Yt({width:D.value.boxWidth+"px",height:D.value.boxHeight+"px"})},[h("div",{class:Ce(["presenter-thumb-viewport slide-viewport","slides-theme-"+y.value]),"data-theme":b.value,"data-slides-theme":y.value,"data-normalize-headings":v.value?"true":"false","data-hide-unordered-markers":k.value?"true":"false","data-hide-ordered-markers":S.value?"true":"false",style:Yt({width:m.value.baseWidth+"px",height:m.value.baseHeight+"px",transform:"scale("+D.value.scale+")"}),innerHTML:Ie.value},null,14,dv)],4)):(J(),ee("div",uv,[h("h2",null,we(fe.value),1),h("p",null,we(pe.value),1)]))],8,cv)]),h("div",{class:Ce(["panel-box next-slide-panel",{"is-clickable":!!le.value,"b3-tooltips b3-tooltips__n":!!le.value}]),"aria-label":le.value?"点击直接跳至下一页":"",onClick:ue[0]||(ue[0]=lt=>le.value&&Z())},[h("div",pv,[h("div",hv,[ue[4]||(ue[4]=h("span",{class:"panel-tag"},"下一页预告",-1)),a.value<d.value?(J(),ee("span",mv,"P."+we(a.value+1),1)):Te("",!0)]),h("div",gv,[a.value>=d.value?(J(),ee("span",vv,"已到尾页")):le.value?(J(),ee("span",bv,we(((We=le.value.frontmatter)==null?void 0:We.layout)||"default"),1)):Te("",!0)])]),h("div",{ref_key:"nextPreviewRef",ref:u,class:"panel-preview panel-preview--dim","aria-label":E.value},[le.value?(J(),ee("div",{key:0,class:"presenter-thumb-box",style:Yt({width:A.value.boxWidth+"px",height:A.value.boxHeight+"px"})},[h("div",{class:Ce(["presenter-thumb-viewport slide-viewport","slides-theme-"+y.value]),"data-theme":b.value,"data-slides-theme":y.value,"data-normalize-headings":v.value?"true":"false","data-hide-unordered-markers":k.value?"true":"false","data-hide-ordered-markers":S.value?"true":"false",style:Yt({width:m.value.baseWidth+"px",height:m.value.baseHeight+"px",transform:"scale("+A.value.scale+")"}),innerHTML:_e.value},null,14,kv)],4)):(J(),ee("div",wv,[h("h2",null,we(E.value),1),h("p",null,we(F.value),1)]))],8,yv)],10,fv)]),h("section",xv,[h("div",Sv,[h("div",Cv,[re(de,{name:"notes",class:"panel-title-icon"}),ue[5]||(ue[5]=h("span",null,"讲稿备忘",-1))]),h("div",_v,[h("button",{class:"notes-btn b3-tooltips b3-tooltips__w","aria-label":"减小字体",disabled:W.value<=14,onClick:M},[re(de,{name:"minus"})],8,$v),h("span",Iv,we(W.value)+"px",1),h("button",{class:"notes-btn b3-tooltips b3-tooltips__w","aria-label":"增大字体",disabled:W.value>=36,onClick:j},[re(de,{name:"plus"})],8,Mv)])]),h("div",{class:Ce(["notes-content",{"is-empty":!g.value}]),style:Yt({fontSize:W.value+"px"})},we(g.value||"（本页未设置演讲者备忘录）"),7)])])):(J(),ee("main",Tv,[h("div",Ev,[re(de,{name:"refresh",class:"empty-icon"})]),ue[8]||(ue[8]=h("h2",null,"等待大屏放映数据",-1)),ue[9]||(ue[9]=h("p",null,"未检测到活跃的幻灯片数据，请先开启大屏放映端。",-1)),h("div",Av,[h("button",{class:"btn-empty-action b3-tooltips b3-tooltips__n","aria-label":"在思源中打开底部演示预览页签",onClick:me},[re(de,{name:"presenter"}),ue[6]||(ue[6]=h("span",null,"打开大屏放映页签",-1))]),h("button",{class:"btn-empty-action btn-empty-action--popout b3-tooltips b3-tooltips__n","aria-label":"将放映端弹出为独立窗口 (16:9)",onClick:$e},[re(de,{name:"window"}),ue[7]||(ue[7]=h("span",null,"弹出独立放映窗口",-1))])])])),h("footer",Bv,[h("div",Dv,[h("button",{class:"btn-nav btn-nav--slide b3-tooltips b3-tooltips__ne",disabled:a.value<=1,"aria-label":"快速返回上一页 (Shift + ←)",onClick:te},[re(de,{name:"chevrons-left"}),ue[10]||(ue[10]=h("span",null,"上一页",-1))],8,Lv),h("button",{class:"btn-nav btn-nav--step b3-tooltips b3-tooltips__n",disabled:!oe.value,"aria-label":"回退一步 (←)",onClick:H},[re(de,{name:"chevron-left"}),ue[11]||(ue[11]=h("span",null,"上一步",-1))],8,Pv)]),h("div",Ov,[h("div",Rv,[h("span",Nv,we(I.value)+"%",1)]),h("button",{class:"btn-restart b3-tooltips b3-tooltips__n","aria-label":"从第一页重新放映 (Home)",onClick:ne},[re(de,{name:"reset"}),ue[12]||(ue[12]=h("span",null,"重头放映",-1))])]),h("div",zv,[ie.value>0?(J(),ee("div",{key:0,class:"step-dots-bar b3-tooltips b3-tooltips__n","aria-label":`步进进度: ${r.value} / ${ie.value}`},[(J(!0),ee(Xe,null,xt(ie.value,lt=>(J(),ee("span",{key:lt,class:Ce(["step-dot",{"is-active":lt<=r.value}])},null,2))),128)),h("span",Fv,we(r.value)+"/"+we(ie.value),1)],8,Hv)):Te("",!0),h("button",{class:"btn-nav btn-nav--step btn-nav--primary b3-tooltips b3-tooltips__n",disabled:!Se.value,"aria-label":"触发下一步骤或进入下一页 (Space / →)",onClick:B},[ue[13]||(ue[13]=h("span",null,"下一步",-1)),re(de,{name:"chevron-right"})],8,jv),h("button",{class:"btn-nav btn-nav--slide b3-tooltips b3-tooltips__nw",disabled:a.value>=d.value,"aria-label":"跳过本页剩余步骤，直接进入下一页 (Shift + →)",onClick:Z},[ue[14]||(ue[14]=h("span",null,"下一页",-1)),re(de,{name:"chevrons-right"})],8,Wv)])])],32)}}}),Kv=ii(Gv,[["__scopeId","data-v-c103f4a6"]]),qv={class:"spm-layout-picker"},Yv={class:"spm-layout-picker__grid"},Zv=["title","onClick"],Jv={class:"spm-layout-icon"},Xv={class:"spm-layout-label"},Qv=Dt({__name:"LayoutPicker",props:{modelValue:{}},emits:["update:modelValue","change"],setup(e,{emit:t}){const i=e,n=t,s=[{name:"cover",label:"封面",desc:"大标题与副标题封面页"},{name:"default",label:"标准",desc:"标题在上方，内容在下方"},{name:"two-cols",label:"双栏",desc:"左右双栏对比展示"},{name:"cols-header",label:"表头多栏",desc:"顶部通栏标题，下方自适应 2~N 栏"},{name:"clover",label:"四叶草",desc:"2x2 田字型四象限卡片布局"},{name:"image-right",label:"图右",desc:"左侧为内容，右侧全屏背景图"},{name:"image-left",label:"图左",desc:"左侧全屏背景图，右侧为内容"},{name:"center",label:"居中",desc:"内容全屏垂直水平居中"},{name:"fact",label:"大字报",desc:"核心数据或指标突出展示"},{name:"intro",label:"介绍",desc:"演讲者自我介绍或章节导览"},{name:"quote",label:"引言",desc:"名人名言与强调段落"}];function o(r){return i.modelValue===r||r==="cols-header"&&(i.modelValue==="two-cols-header"||i.modelValue==="three-cols-header")}function a(r){n("update:modelValue",r),n("change",r)}return(r,l)=>(J(),ee("div",qv,[l[0]||(l[0]=h("div",{class:"spm-layout-picker__header"},"选择页面版式",-1)),h("div",Yv,[(J(),ee(Xe,null,xt(s,c=>h("div",{key:c.name,class:Ce(["spm-layout-item",{active:o(c.name)}]),title:c.desc,onClick:d=>a(c.name)},[h("div",Jv,[re(de,{name:"layout-"+c.name},null,8,["name"])]),h("span",Xv,we(c.label),1)],10,Zv)),64))])]))}}),eb=ii(Qv,[["__scopeId","data-v-96c8a248"]]),tb={key:0,class:"spm-transition-selector__header"},ib={class:"spm-transition-list"},nb=["onClick"],sb={class:"spm-transition-meta"},ob={class:"spm-transition-label"},rb={class:"spm-transition-preview-box"},ab=Dt({__name:"TransitionSelector",props:{modelValue:{},hideHeader:{type:Boolean},title:{}},emits:["update:modelValue","change"],setup(e,{emit:t}){const i=t,n=[{name:"slide-left",label:"向左滑入",desc:"向左滑入：页面从右侧向左平滑推入，最通用标准的横向幻灯片动效"},{name:"slide-right",label:"向右滑入",desc:"向右滑入：页面从左侧向右平滑推入，适合倒序回退或逆向章节叙述"},{name:"slide-up",label:"向上推入",desc:"向上推入：页面从底部向上平滑推入，适合纵向展开或纵深层级展示"},{name:"fade",label:"淡入淡出",desc:"淡入淡出：透明度平滑渐变过度，典雅柔和，适合学术长篇与沉浸叙事"},{name:"zoom",label:"缩放进入",desc:"缩放进入：页面由中心向外平滑放大，富有动感冲击力，适合聚焦重点"}];function s(o){i("update:modelValue",o),i("change",o)}return(o,a)=>(J(),ee("div",{class:Ce(["spm-transition-selector",{"spm-transition-selector--no-header":e.hideHeader}])},[e.hideHeader?Te("",!0):(J(),ee("div",tb,we(e.title||"转场动效"),1)),h("div",ib,[(J(),ee(Xe,null,xt(n,r=>h("div",{key:r.name,class:Ce(["spm-transition-item",{active:e.modelValue===r.name}]),onClick:l=>s(r.name)},[h("div",sb,[h("span",ob,we(r.label),1)]),h("div",rb,[h("div",{class:Ce(["spm-anim-cube","anim-"+r.name])},null,2)])],10,nb)),64))])],2))}}),oc=ii(ab,[["__scopeId","data-v-b5051f69"]]),lb={class:"spm-section spm-section--page"},cb={class:"spm-section-header"},db={key:0,class:"spm-card-control",style:{"border-left":"3px solid var(--b3-theme-primary)",background:"rgba(var(--b3-theme-primary-rgb, 66, 133, 244), 0.06)",padding:"8px 12px","margin-top":"6px"}},ub={style:{display:"flex","align-items":"center","justify-content":"space-between",gap:"8px"}},fb={style:{"font-size":"11px",display:"flex","align-items":"center",gap:"6px",flex:"1"}},pb={key:1,class:"spm-card-control"},hb={class:"spm-control-header"},mb={class:"spm-control-title-group"},gb={class:"spm-control-title"},vb={class:"spm-quick-chips"},bb=["onClick"],yb={style:{display:"flex",gap:"6px","align-items":"center","margin-top":"6px"}},kb=["value"],wb=["aria-label"],xb={key:1,class:"spm-icon-btn b3-tooltips b3-tooltips__sw",disabled:"",style:{opacity:"0.45",cursor:"not-allowed",padding:"0 8px",height:"26px","font-size":"11px","white-space":"nowrap","flex-shrink":"0"},"aria-label":"当前页未检测到调整过列宽的横向超级块"},Sb={key:0,style:{"margin-top":"6px","font-size":"11px",opacity:"0.85",display:"flex","align-items":"center",gap:"4px"}},Cb={style:{background:"rgba(125, 125, 125, 0.15)",padding:"1px 4px","border-radius":"3px","font-weight":"bold"}},_b={key:1,style:{"margin-top":"6px","font-size":"11px",opacity:"0.6",display:"flex","align-items":"center",gap:"4px"}},$b={class:"spm-card-control"},Ib={class:"spm-control-header"},Mb={class:"spm-control-title-group"},Tb={class:"spm-control-title"},Eb={class:"spm-segmented-group"},Ab={key:0,style:{"margin-top":"10px",display:"flex","flex-direction":"column",gap:"8px"}},Bb={style:{display:"flex","align-items":"center","justify-content":"space-between"}},Db=["aria-label"],Lb={class:"spm-quick-chips"},Pb=["onClick"],Ob=["value"],Rb={style:{"font-size":"10.5px",opacity:"0.6","line-height":"1.35","margin-top":"-2px"}},Nb={style:{display:"flex",gap:"8px","margin-top":"2px"}},zb={style:{flex:"1"}},Hb={class:"spm-segmented-group"},Fb={style:{flex:"1"}},jb={class:"spm-segmented-group"},Wb={class:"spm-card-control"},Ub={class:"spm-control-header"},Vb={class:"spm-control-title-group"},Gb={class:"spm-control-title"},Kb={class:"spm-segmented-group"},qb={key:2,class:"spm-card-control"},Yb={class:"spm-control-header"},Zb={class:"spm-control-title-group"},Jb={class:"spm-control-title"},Xb={class:"spm-quick-chips"},Qb=["onClick"],e1=["value"],t1={class:"spm-card-control"},i1={class:"spm-control-header"},n1={class:"spm-control-title-group"},s1={class:"spm-control-title"},o1={key:0,class:"spm-note-status-box"},r1=["title"],a1={class:"spm-action-grid",style:{"margin-top":"6px"}},l1={key:1,class:"spm-note-empty-box"},c1={class:"spm-batch-actions-box",style:{"margin-top":"8px","border-top":"1px dashed var(--b3-border-color, #e2e8f0)","padding-top":"8px"}},d1={class:"spm-action-grid"},u1=["disabled"],f1=["disabled"],p1={class:"spm-card-control"},h1={class:"spm-action-grid"},m1=Dt({__name:"PageInspectorSection",props:{pageLayout:{},pageTransition:{},pageSpacing:{},pageImage:{},pageNotes:{},pageIndex:{},pageLayoutRatio:{},pageMask:{},pageMaskRatio:{},pageMaskStyle:{},pageMaskInitial:{},detectedSbRatio:{},detectedSbInfo:{},isBatchProcessing:{type:Boolean}},emits:["update:pageLayout","update:pageTransition","update:pageSpacing","update:pageImage","update:pageLayoutRatio","update:pageMask","update:pageMaskRatio","update:pageMaskStyle","update:pageMaskInitial","applySuperBlockLayout","resetSuperblockRatio","addNoteBlock","locateNoteBlock","generateNotes","batchAppendNotes","batchDeleteNotes","insertDividerAfter","deleteDivider"],setup(e,{emit:t}){const i=e,n=t,s=[{label:"1:1 (2步)",value:"1:1"},{label:"1:1:1 (3步)",value:"1:1:1"},{label:"1:2:1 (非等宽)",value:"1:2:1"},{label:"1:1:1:1 (4步)",value:"1:1:1:1"}],o=ye(()=>{const v=i.pageMask;return v==="clockwise"||v==="counter-clockwise"||v==="cw"||v==="ccw"}),a=ye(()=>o.value?"1:1:1:1":"1:1"),r=ye(()=>i.pageMaskRatio||a.value);function l(v){n("update:pageMask",v),(!i.pageMaskRatio||i.pageMaskRatio==="1:1")&&n("update:pageMaskRatio","1:1:1:1")}function c(v){n("update:pageMask",v),(!i.pageMaskRatio||i.pageMaskRatio==="1:1:1:1")&&n("update:pageMaskRatio","1:1")}const d=ye(()=>i.pageMask==="clockwise"||i.pageMask==="counter-clockwise"||i.pageMask==="cw"||i.pageMask==="ccw"?`时钟走时规则：
• 顺时针：左上 → 右上 → 右下 → 左下
• 逆时针：左上 → 左下 → 右下 → 右上
• 每次点击时针旋转 90° 并扇形扫开 1/4 象限，全部揭开后翻页`:`输入规则：
• 权重比例（项数决定步数）：如 1:1 (2步等分)、1:1:1 (3步等分)、1:2:1 (按权重累计分段)
• 绝对百分比：如 25:75:100 或 30:80 (指定每步展开的累计百分比)
• 每次点击或按空格/向右键展露下一段，全部揭开后翻页`),p=ye(()=>["two-cols","cols-header","two-cols-header","three-cols-header","image-left","image-right"].includes(i.pageLayout)),u=ye(()=>{var S,D;if(i.pageLayout==="two-cols-header"||i.pageLayout==="two-cols"||i.pageLayout==="image-left"||i.pageLayout==="image-right")return 2;if(i.pageLayout==="three-cols-header")return 3;const v=(i.pageLayoutRatio||"").trim();if(v.includes(":")){const A=v.split(":").filter(Boolean).length;if(A>=2&&A<=6)return A}const k=(i.detectedSbRatio||"").trim();if(k.includes(":")){const A=k.split(":").filter(Boolean).length;if(A>=2&&A<=6)return A}if((S=i.detectedSbInfo)!=null&&S.colCount&&i.detectedSbInfo.colCount>=2)return Math.min(i.detectedSbInfo.colCount,6);if((D=i.detectedSbInfo)!=null&&D.slots&&Array.isArray(i.detectedSbInfo.slots)){const A=i.detectedSbInfo.slots.length;if(A>=2&&A<=6)return A}return 2}),f=ye(()=>{const v=u.value;return v===3?[{label:"默认 1:1:1",value:""},{label:"1:2:1 (主中)",value:"1:2:1"},{label:"2:1:1 (主左)",value:"2:1:1"},{label:"1:1:2 (主右)",value:"1:1:2"},{label:"1:3:1",value:"1:3:1"}]:v===4?[{label:"默认 1:1:1:1",value:""},{label:"1:2:2:1",value:"1:2:2:1"},{label:"2:1:1:2",value:"2:1:1:2"}]:v===5?[{label:"默认 1:1:1:1:1",value:""}]:v===6?[{label:"默认 1:1:1:1:1:1",value:""}]:[{label:"默认 1:1",value:""},{label:"1:2",value:"1:2"},{label:"2:1",value:"2:1"},{label:"3:7",value:"3:7"},{label:"7:3",value:"7:3"},{label:"4:6",value:"4:6"},{label:"6:4",value:"6:4"}]}),w=ye(()=>i.pageLayoutRatio||"");function m(){const v=u.value||2,k=Array(v).fill("1").join(":");n("update:pageLayoutRatio",k),n("resetSuperblockRatio")}const y=ye(()=>{if(!i.pageNotes)return"";const v=i.pageNotes.replace(/[\r\n]+/g," ").trim();return v.length>50?v.slice(0,50)+"...":v}),b=[{label:"默认封面",value:"https://cover.sli.dev"},{label:"清空配图",value:""}];return(v,k)=>(J(),ee("div",lb,[h("div",cb,[h("span",null,"幻灯片页面设置"+we(e.pageIndex?` (第 ${e.pageIndex} 页)`:""),1)]),re(eb,{"model-value":e.pageLayout,onChange:k[0]||(k[0]=S=>v.$emit("update:pageLayout",S))},null,8,["model-value"]),!p.value&&e.pageLayout!=="clover"&&e.detectedSbRatio?(J(),ee("div",db,[h("div",ub,[h("div",fb,[re(de,{name:"sparkles"}),h("span",null,[k[31]||(k[31]=$t("检测到本页横向超级块列宽比例：",-1)),h("b",null,we(e.detectedSbRatio),1)])]),h("button",{class:"spm-btn-action b3-tooltips b3-tooltips__sw","aria-label":"一键应用超级块列宽并设为分栏",style:{padding:"2px 8px",height:"26px","font-size":"11px","flex-shrink":"0",background:"var(--b3-theme-primary)",color:"#fff",display:"inline-flex","align-items":"center",gap:"4px"},onClick:k[1]||(k[1]=S=>v.$emit("applySuperBlockLayout",e.detectedSbInfo||{recommendedLayout:"two-cols",ratio:e.detectedSbRatio}))},[re(de,{name:"columns"}),k[32]||(k[32]=h("span",null,"设为分栏",-1))])])])):Te("",!0),p.value?(J(),ee("div",pb,[h("div",hb,[h("div",mb,[h("div",gb,[re(de,{name:"ratio"}),k[33]||(k[33]=h("span",null,"分栏比例",-1))]),k[34]||(k[34]=h("span",{class:"spm-control-desc"},"设置各列横向空间占比，默认平均分配",-1))])]),h("div",vb,[(J(!0),ee(Xe,null,xt(f.value,S=>(J(),ee("button",{key:S.value,class:Ce(["spm-chip",{active:w.value===S.value}]),onClick:D=>v.$emit("update:pageLayoutRatio",S.value)},we(S.label),11,bb))),128))]),h("div",yb,[h("input",{value:e.pageLayoutRatio||"",class:"spm-input",style:{flex:"1","min-width":"0"},placeholder:"自定义比例（如 1:2 或 30:70，留空为默认）",onInput:k[2]||(k[2]=S=>v.$emit("update:pageLayoutRatio",S.target.value)),onChange:k[3]||(k[3]=S=>v.$emit("update:pageLayoutRatio",S.target.value))},null,40,kb),e.detectedSbRatio?(J(),ee("button",{key:0,class:"spm-icon-btn b3-tooltips b3-tooltips__sw","aria-label":`读取超级块列宽比例 (${e.detectedSbRatio}) 并应用`,style:{padding:"0 8px",height:"26px","font-size":"11px","white-space":"nowrap","flex-shrink":"0"},onClick:k[4]||(k[4]=S=>v.$emit("update:pageLayoutRatio",e.detectedSbRatio))},[re(de,{name:"sparkles"}),k[35]||(k[35]=h("span",null,"读取",-1))],8,wb)):(J(),ee("button",xb,[re(de,{name:"sparkles"}),k[36]||(k[36]=h("span",null,"读取",-1))])),h("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__sw","aria-label":"重置为等宽平均分布",style:{padding:"0 8px",height:"26px","font-size":"11px","white-space":"nowrap","flex-shrink":"0"},onClick:m},[re(de,{name:"reset"}),k[37]||(k[37]=h("span",null,"重置",-1))])]),e.detectedSbRatio?(J(),ee("div",Sb,[re(de,{name:"ratio"}),k[38]||(k[38]=h("span",null,"检测到思源超级块宽度：",-1)),h("code",Cb,we(e.detectedSbRatio),1)])):(J(),ee("div",_b,[re(de,{name:"ratio"}),k[39]||(k[39]=h("span",null,"未检测到调宽超级块（默认各列平均分配）",-1))]))])):Te("",!0),re(oc,{"model-value":e.pageTransition,onChange:k[5]||(k[5]=S=>v.$emit("update:pageTransition",S))},null,8,["model-value"]),h("div",$b,[h("div",Ib,[h("div",Mb,[h("div",Tb,[re(de,{name:"sparkles"}),k[40]||(k[40]=h("span",null,"页面动态蒙版",-1))]),k[41]||(k[41]=h("span",{class:"spm-control-desc"},"随着点击操作分段展露正文内容",-1))])]),h("div",Eb,[h("button",{class:Ce(["spm-segmented-item",{active:!e.pageMask}]),onClick:k[6]||(k[6]=S=>v.$emit("update:pageMask",""))}," 关闭 ",2),h("button",{class:Ce(["spm-segmented-item",{active:e.pageMask==="down"}]),onClick:k[7]||(k[7]=S=>c("down"))}," 从上至下 ",2),h("button",{class:Ce(["spm-segmented-item",{active:e.pageMask==="right"}]),onClick:k[8]||(k[8]=S=>c("right"))}," 从左至右 ",2),h("button",{class:Ce(["spm-segmented-item",{active:e.pageMask==="clockwise"||e.pageMask==="cw"}]),onClick:k[9]||(k[9]=S=>l("clockwise"))}," 顺时针 ↻ ",2),h("button",{class:Ce(["spm-segmented-item",{active:e.pageMask==="counter-clockwise"||e.pageMask==="ccw"}]),onClick:k[10]||(k[10]=S=>l("counter-clockwise"))}," 逆时针 ↺ ",2)]),e.pageMask?(J(),ee("div",Ab,[h("div",Bb,[k[43]||(k[43]=h("div",{style:{"font-size":"11px",opacity:"0.85","font-weight":"500"}},"展露比例 / 断点",-1)),h("span",{class:"b3-tooltips b3-tooltips__sw","aria-label":d.value,style:{cursor:"help",opacity:"0.75",display:"inline-flex","align-items":"center",gap:"3px","font-size":"11px"}},[re(de,{name:"help"}),k[42]||(k[42]=h("span",null,"输入规则",-1))],8,Db)]),h("div",Lb,[(J(),ee(Xe,null,xt(s,S=>h("button",{key:S.value,class:Ce(["spm-chip",{active:r.value===S.value}]),onClick:D=>v.$emit("update:pageMaskRatio",S.value)},we(S.label),11,Pb)),64))]),h("input",{value:r.value,class:"spm-input",style:{width:"100%"},placeholder:"自定义比例或断点（如 1:2:1 或 25:75:100）",onInput:k[11]||(k[11]=S=>v.$emit("update:pageMaskRatio",S.target.value)),onChange:k[12]||(k[12]=S=>v.$emit("update:pageMaskRatio",S.target.value))},null,40,Ob),h("div",Rb,we(e.pageMask==="clockwise"||e.pageMask==="counter-clockwise"||e.pageMask==="cw"||e.pageMask==="ccw"?"时钟走时蒙版：默认 4 步旋转展露（1:1:1:1，每步 25% 扇形面积）":"提示：支持权重比（如 1:2:1）或绝对断点（如 25:75:100），冒号项数决定点击步数"),1),h("div",Nb,[h("div",zb,[k[44]||(k[44]=h("div",{style:{"font-size":"11px",opacity:"0.85","margin-bottom":"4px"}},"遮盖质感",-1)),h("div",Hb,[h("button",{class:Ce(["spm-segmented-item",{active:!e.pageMaskStyle||e.pageMaskStyle==="solid"}]),onClick:k[13]||(k[13]=S=>v.$emit("update:pageMaskStyle","solid"))}," 背景同色 ",2),h("button",{class:Ce(["spm-segmented-item",{active:e.pageMaskStyle==="blur"}]),onClick:k[14]||(k[14]=S=>v.$emit("update:pageMaskStyle","blur"))}," 磨砂毛玻璃 ",2)])]),h("div",Fb,[k[45]||(k[45]=h("div",{style:{"font-size":"11px",opacity:"0.85","margin-bottom":"4px"}},"初始展露",-1)),h("div",jb,[h("button",{class:Ce(["spm-segmented-item",{active:!e.pageMaskInitial||e.pageMaskInitial==="hidden"}]),onClick:k[15]||(k[15]=S=>v.$emit("update:pageMaskInitial","hidden"))}," 完全遮盖 ",2),h("button",{class:Ce(["spm-segmented-item",{active:e.pageMaskInitial==="revealed"}]),onClick:k[16]||(k[16]=S=>v.$emit("update:pageMaskInitial","revealed"))}," 首段可见 ",2)])])])])):Te("",!0)]),h("div",Wb,[h("div",Ub,[h("div",Vb,[h("div",Gb,[re(de,{name:"ratio"}),k[46]||(k[46]=h("span",null,"页面间距",-1))]),k[47]||(k[47]=h("span",{class:"spm-control-desc"},"覆盖本页内边距与顶部标题间距",-1))])]),h("div",Kb,[h("button",{class:Ce(["spm-segmented-item",{active:!e.pageSpacing||e.pageSpacing==="inherit"}]),onClick:k[17]||(k[17]=S=>v.$emit("update:pageSpacing","inherit"))}," 继承全局 ",2),h("button",{class:Ce(["spm-segmented-item",{active:e.pageSpacing==="compact"}]),onClick:k[18]||(k[18]=S=>v.$emit("update:pageSpacing","compact"))}," 紧凑 ",2),h("button",{class:Ce(["spm-segmented-item",{active:e.pageSpacing==="normal"}]),onClick:k[19]||(k[19]=S=>v.$emit("update:pageSpacing","normal"))}," 标准 ",2),h("button",{class:Ce(["spm-segmented-item",{active:e.pageSpacing==="loose"}]),onClick:k[20]||(k[20]=S=>v.$emit("update:pageSpacing","loose"))}," 宽松 ",2)])]),e.pageLayout==="image-right"||e.pageLayout==="image-left"||e.pageImage?(J(),ee("div",qb,[h("div",Yb,[h("div",Zb,[h("div",Jb,[re(de,{name:"image"}),k[48]||(k[48]=h("span",null,"页面图片",-1))]),k[49]||(k[49]=h("span",{class:"spm-control-desc"},"图文分栏或页面专属配图 URL / 资源路径",-1))])]),h("div",Xb,[(J(),ee(Xe,null,xt(b,S=>h("button",{key:S.value,class:Ce(["spm-chip",{active:e.pageImage===S.value}]),onClick:D=>v.$emit("update:pageImage",S.value)},we(S.label),11,Qb)),64))]),h("input",{value:e.pageImage,class:"spm-input",placeholder:"网络图片 URL (如 https://cover.sli.dev) 或 assets/...",onInput:k[21]||(k[21]=S=>v.$emit("update:pageImage",S.target.value)),onChange:k[22]||(k[22]=S=>v.$emit("update:pageImage",S.target.value))},null,40,e1)])):Te("",!0),h("div",t1,[h("div",i1,[h("div",n1,[h("div",s1,[re(de,{name:"presenter"}),k[50]||(k[50]=h("span",null,"演讲者提词",-1))]),k[51]||(k[51]=h("span",{class:"spm-control-desc"},"正文备注块驱动 · 仅演讲者视图可见",-1))]),he(It)("aiScript")?(J(),ee("button",{key:0,class:"spm-btn-text b3-tooltips b3-tooltips__sw","aria-label":"AI 自动生成本页讲稿提示块",onClick:k[23]||(k[23]=S=>v.$emit("generateNotes"))},[re(de,{name:"sparkles"}),k[52]||(k[52]=h("span",null,"AI 讲稿",-1))])):Te("",!0)]),e.pageNotes?(J(),ee("div",o1,[k[55]||(k[55]=h("div",{class:"spm-note-status-badge"},[h("span",{class:"spm-badge-dot"}),h("span",null,"已配置正文讲稿")],-1)),h("div",{class:"spm-note-preview-text",title:e.pageNotes},we(y.value),9,r1),h("div",a1,[h("button",{class:"spm-btn-action b3-tooltips b3-tooltips__se","aria-label":"在正文编辑区定位并高亮此讲稿备注块",onClick:k[24]||(k[24]=S=>v.$emit("locateNoteBlock"))},[re(de,{name:"search"}),k[53]||(k[53]=h("span",null,"定位讲稿块",-1))]),h("button",{class:"spm-btn-action b3-tooltips b3-tooltips__sw","aria-label":"在本页末尾追加新的讲稿提示块",onClick:k[25]||(k[25]=S=>v.$emit("addNoteBlock"))},[re(de,{name:"insert-below"}),k[54]||(k[54]=h("span",null,"追加讲稿块",-1))])])])):(J(),ee("div",l1,[k[57]||(k[57]=h("div",{class:"spm-note-empty-hint"},"本页暂无讲稿备注块",-1)),h("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s",style:{width:"100%","margin-top":"6px"},"aria-label":"在当前页末尾插入默认演讲备注提示块",onClick:k[26]||(k[26]=S=>v.$emit("addNoteBlock"))},[re(de,{name:"insert-below"}),k[56]||(k[56]=h("span",null,"添加讲稿备注块",-1))])])),h("div",c1,[h("div",d1,[h("button",{class:"spm-btn-action b3-tooltips b3-tooltips__se",disabled:e.isBatchProcessing,style:Yt(e.isBatchProcessing?"opacity: 0.5; cursor: not-allowed;":""),"aria-label":"在所有尚未配置讲稿的页面末尾批量追加讲稿提示块",onClick:k[27]||(k[27]=S=>v.$emit("batchAppendNotes"))},[re(de,{name:"insert-below"}),k[58]||(k[58]=h("span",null,"全部追加",-1))],12,u1),h("button",{class:"spm-btn-action spm-btn-danger b3-tooltips b3-tooltips__sw",disabled:e.isBatchProcessing,style:Yt(e.isBatchProcessing?"opacity: 0.5; cursor: not-allowed;":""),"aria-label":"批量物理删除正文中的全部讲稿备注块（涉及全部页）",onClick:k[28]||(k[28]=S=>v.$emit("batchDeleteNotes"))},[re(de,{name:"trash"}),k[59]||(k[59]=h("span",null,"全部删除",-1))],12,f1)])])]),h("div",p1,[k[62]||(k[62]=h("div",{class:"spm-control-header"},[h("div",{class:"spm-control-title-group"},[h("span",{class:"spm-control-title"},"分页快捷操作")])],-1)),h("div",h1,[h("button",{class:"spm-btn-action b3-tooltips b3-tooltips__se","aria-label":"在此分页符之后插入新的空白分页",onClick:k[29]||(k[29]=S=>v.$emit("insertDividerAfter"))},[re(de,{name:"insert-below"}),k[60]||(k[60]=h("span",null,"插入新页",-1))]),h("button",{class:"spm-btn-action spm-btn-danger b3-tooltips b3-tooltips__sw","aria-label":"彻底删除当前分页符（合并前后页面）",onClick:k[30]||(k[30]=S=>v.$emit("deleteDivider"))},[re(de,{name:"trash"}),k[61]||(k[61]=h("span",null,"删除此页",-1))])])])]))}}),g1=ii(m1,[["__scopeId","data-v-2b63202b"]]),v1={class:"spm-section spm-section--block"},b1={key:0,class:"spm-card-control",style:{"border-left":"3px solid var(--b3-theme-primary)"}},y1={class:"spm-control-header"},k1={class:"spm-control-title-group"},w1={class:"spm-control-title"},x1={style:{background:"var(--b3-theme-surface)",border:"1px solid var(--b3-theme-surface-lighter)","border-radius":"6px",padding:"10px","margin-bottom":"8px"}},S1={style:{display:"flex","align-items":"center","justify-content":"space-between","margin-bottom":"4px"}},C1={style:{"font-size":"12px","font-weight":"500",display:"flex","align-items":"center",gap:"4px"}},_1={key:0},$1={key:1},I1={style:{background:"rgba(var(--b3-theme-primary-rgb, 59, 130, 246), 0.16)",color:"var(--b3-theme-primary)",border:"1px solid rgba(var(--b3-theme-primary-rgb, 59, 130, 246), 0.3)",padding:"2px 6px","border-radius":"4px","font-weight":"bold","font-size":"12px"}},M1={style:{"font-size":"11px",opacity:"0.75","line-height":"1.4"}},T1={class:"spm-action-grid"},E1={class:"spm-card-control"},A1={class:"spm-control-header"},B1={class:"spm-control-title-group"},D1={class:"spm-control-title"},L1=["aria-label"],P1=["checked"],O1={key:1,class:"spm-card-control"},R1={class:"spm-control-header"},N1={class:"spm-control-title-group"},z1={class:"spm-control-title"},H1={class:"spm-quick-chips"},F1={key:2,class:"spm-card-control"},j1={class:"spm-control-header"},W1={class:"spm-control-title-group"},U1={class:"spm-control-title"},V1={class:"spm-video-settings-grid",style:{display:"grid","grid-template-columns":"1fr 1fr",gap:"8px","margin-top":"8px"}},G1={class:"spm-toggle-item",style:{display:"flex","align-items":"center","justify-content":"space-between",padding:"4px 6px",background:"rgba(125,125,125,0.06)","border-radius":"4px"}},K1={style:{"font-size":"11px",display:"inline-flex","align-items":"center",gap:"4px"}},q1=["aria-label"],Y1=["checked"],Z1={class:"spm-toggle-item",style:{display:"flex","align-items":"center","justify-content":"space-between",padding:"4px 6px",background:"rgba(125,125,125,0.06)","border-radius":"4px"}},J1={style:{"font-size":"11px",display:"inline-flex","align-items":"center",gap:"4px"}},X1=["aria-label"],Q1=["checked"],ey={class:"spm-toggle-item",style:{display:"flex","align-items":"center","justify-content":"space-between",padding:"4px 6px",background:"rgba(125,125,125,0.06)","border-radius":"4px"}},ty={style:{"font-size":"11px",display:"inline-flex","align-items":"center",gap:"4px"}},iy=["aria-label"],ny=["checked"],sy={class:"spm-toggle-item",style:{display:"flex","align-items":"center","justify-content":"space-between",padding:"4px 6px",background:"rgba(125,125,125,0.06)","border-radius":"4px"}},oy={style:{"font-size":"11px",display:"inline-flex","align-items":"center",gap:"4px"}},ry=["aria-label"],ay=["checked"],ly={class:"spm-card-control"},cy={class:"spm-control-header"},dy={class:"spm-control-title-group"},uy={class:"spm-control-title"},fy=["aria-label"],py=["checked"],hy={key:0,class:"spm-quick-chips"},my=["onClick"],gy={key:1,class:"spm-inherit-tip",style:{"margin-top":"6px",padding:"4px 8px",background:"rgba(var(--b3-theme-primary-rgb, 59, 130, 246), 0.08)","border-radius":"4px","font-size":"11px",opacity:"0.85",display:"flex","align-items":"center",gap:"4px"}},vy={class:"spm-card-control"},by={class:"spm-control-header"},yy={class:"spm-control-title-group"},ky={class:"spm-control-title"},wy=["aria-label"],xy=["checked"],Sy={key:0,class:"spm-quick-chips"},Cy=["onClick"],_y={key:1,class:"spm-motion-details",style:{display:"flex","flex-direction":"column",gap:"4px","margin-top":"4px"}},$y={style:{display:"flex",gap:"8px","justify-content":"space-between","font-size":"11px",opacity:"0.8"}},Iy={style:{display:"flex",gap:"6px"}},My=["value"],Ty=["value"],Ey={key:3,class:"spm-card-control"},Ay={class:"spm-control-header"},By={class:"spm-control-title-group"},Dy={class:"spm-control-title"},Ly={class:"spm-control-desc"},Py={class:"spm-segmented-group"},Oy=["onClick"],Ry={key:4,class:"spm-card-control"},Ny={class:"spm-control-header"},zy={class:"spm-control-title-group"},Hy={class:"spm-control-title"},Fy={class:"spm-quick-chips"},jy=["onClick"],Wy=["value"],Uy={key:5,class:"spm-card-control"},Vy={class:"spm-control-header"},Gy={class:"spm-control-title-group"},Ky={class:"spm-control-title"},qy={class:"spm-quick-chips"},Yy=["onClick"],Zy=["value"],Jy={class:"spm-card-control"},Xy={class:"spm-action-grid"},Qy=["aria-label"],e0=Dt({__name:"BlockInspectorSection",props:{elemClick:{},elemMotion:{},elemSlot:{},elemShikiLines:{},elemMaxHeight:{},isCodeBlock:{type:Boolean},isImage:{type:Boolean},isVideo:{type:Boolean},videoAutoplay:{type:Boolean},videoLoop:{type:Boolean},videoMuted:{type:Boolean},videoControls:{type:Boolean},hasBlockAttrs:{type:Boolean},isNote:{type:Boolean},imageRole:{},currentSlideLayout:{},isSuperBlock:{type:Boolean},parentElemClick:{},parentContainerSlot:{},parentContainerId:{},detectedSbInfo:{}},emits:["toggleNote","toggleElemClick","update:elemClick","update:elemMotion","update:elemSlot","update:elemShikiLines","update:elemMaxHeight","applySuperBlockLayout","applySuperBlockRatio","insertDividerBefore","insertDividerAfter","setTwoColsContrast","clearBlockAttrs","update:imageRole","toggleVideoAutoplay","toggleVideoLoop","toggleVideoMuted","toggleVideoControls"],setup(e,{emit:t}){const i=e,n=ye(()=>{const A=i.currentSlideLayout||"";return["col-1","col-2","col-3","col-4","col-5","col-6"].includes(i.elemSlot)?"cols-header":A}),s=ye(()=>{const A=n.value;return["two-cols","cols-header","two-cols-header","three-cols-header"].includes(A)}),o=ye(()=>{var C,L,z,N;if((C=i.detectedSbInfo)!=null&&C.colCount&&i.detectedSbInfo.colCount>=2)return Math.min(i.detectedSbInfo.colCount,6);const A=(L=i.elemSlot)==null?void 0:L.match(/^col-(\d+)$/);if(A){const K=parseInt(A[1],10);if(K>=2&&K<=6)return Math.max(K,3)}if(i.currentSlideLayout==="three-cols-header")return 3;if(i.currentSlideLayout==="two-cols-header"||i.currentSlideLayout==="two-cols")return 2;if((N=(z=i.detectedSbInfo)==null?void 0:z.ratio)!=null&&N.includes(":")){const K=i.detectedSbInfo.ratio.split(":").filter(Boolean);if(K.length>=2)return Math.min(K.length,6)}return 3}),a=ye(()=>{const A=n.value;return A==="cols-header"?"多栏插槽归属":A==="three-cols-header"?"三栏插槽归属":A==="two-cols-header"?"带表头双栏插槽":"多栏插槽归属"}),r=ye(()=>{const A=n.value;return A==="cols-header"?`在 cols-header 表头多栏（${o.value} 栏）中的内容块位置`:A==="three-cols-header"?"在 three-cols-header 版式中的内容块位置":A==="two-cols-header"?"在 two-cols-header 版式中的内容块位置":A==="two-cols"?"在 two-cols 双栏版式中的归属":"在当前分栏版式中的内容块位置"}),l=ye(()=>{const A=n.value;if(A==="two-cols")return[{value:"",label:"默认 (左)"},{value:"right",label:"右栏"}];if(A==="two-cols-header")return[{value:"",label:"默认"},{value:"header",label:"表头"},{value:"left",label:"左栏"},{value:"right",label:"右栏"}];if(A==="three-cols-header")return[{value:"",label:"默认"},{value:"header",label:"表头"},{value:"col-1",label:"第 1 栏"},{value:"col-2",label:"第 2 栏"},{value:"col-3",label:"第 3 栏"}];const C=o.value,L=[{value:"",label:"默认"},{value:"header",label:"表头"}];for(let z=1;z<=C;z++)L.push({value:`col-${z}`,label:`第 ${z} 栏`});return L});function c(A){const C=i.elemSlot||"";return A?C===A||A==="col-1"&&C==="left"||A==="col-2"&&C==="center"||A==="col-3"&&C==="right"&&o.value===3||A==="col-2"&&C==="right"&&o.value===2||A==="left"&&C==="col-1"||A==="right"&&(C==="col-2"||C==="col-3"):!C||C==="default"}const d=t,p=[{label:"上浮",value:"slide-up"},{label:"淡入",value:"fade-in"},{label:"下沉",value:"slide-down"},{label:"左滑",value:"slide-left"},{label:"右滑",value:"slide-right"},{label:"缩放",value:"zoom-in"},{label:"弹性",value:"bounce"}],u=ye(()=>{if(!i.elemMotion||i.elemMotion.trim()===""||i.elemMotion.trim()==="none")return null;try{const A=JSON.parse(i.elemMotion);if(typeof A=="object"&&A!==null)return{preset:A.preset||A.type||"slide-up",duration:typeof A.duration=="number"?A.duration:0,delay:typeof A.delay=="number"?A.delay:0}}catch{}return{preset:i.elemMotion.trim(),duration:0,delay:0}}),f=ye(()=>!!u.value),w=ye(()=>{var A;return((A=u.value)==null?void 0:A.preset)||"slide-up"}),m=ye(()=>{var A;return((A=u.value)==null?void 0:A.duration)||0}),y=ye(()=>{var A;return((A=u.value)==null?void 0:A.delay)||0});function b(){f.value?d("update:elemMotion",""):d("update:elemMotion","slide-up")}function v(A){D(A,m.value,y.value)}function k(A){D(w.value,A,y.value)}function S(A){D(w.value,m.value,A)}function D(A,C,L){if(!A||A==="none"){d("update:elemMotion","");return}if(!C&&!L){d("update:elemMotion",A);return}const z={preset:A};C>0&&(z.duration=C),L>0&&(z.delay=L),d("update:elemMotion",JSON.stringify(z))}return(A,C)=>{var L,z,N,K,_,U;return J(),ee("div",v1,[C[62]||(C[62]=h("div",{class:"spm-section-header"},[h("span",null,"元素动效与排版")],-1)),e.isSuperBlock||(L=e.detectedSbInfo)!=null&&L.hasSuperBlock?(J(),ee("div",b1,[h("div",y1,[h("div",k1,[h("div",w1,[re(de,{name:"ratio"}),C[24]||(C[24]=h("span",null,"超级块列宽与布局",-1))]),C[25]||(C[25]=h("span",{class:"spm-control-desc"},"读取思源超级块列宽并一键同步到幻灯片分栏",-1))])]),h("div",x1,[h("div",S1,[h("div",C1,[re(de,{name:"ratio"}),(z=e.detectedSbInfo)!=null&&z.isCustomWidth?(J(),ee("span",_1,"已识别自定义列宽比例")):(J(),ee("span",$1,"识别到 "+we(((N=e.detectedSbInfo)==null?void 0:N.colCount)||2)+" 列超级块分栏",1))]),h("code",I1,we(((K=e.detectedSbInfo)==null?void 0:K.ratio)||"1:1"),1)]),h("div",M1,we((_=e.detectedSbInfo)!=null&&_.isCustomWidth?"检测到已调节子块宽度，可一键应用为当前页分栏比例。":"当前超级块子列为思源默认均宽，可在思源中拖动调节或直接应用。"),1)]),h("div",T1,[h("button",{class:"spm-btn-action b3-tooltips b3-tooltips__se","aria-label":"一键将当前页版式切换为对应双栏/三栏，并写入此列宽比例",style:{background:"rgba(var(--b3-theme-primary-rgb, 59, 130, 246), 0.16)",color:"var(--b3-theme-primary)","font-weight":"500",border:"1px solid rgba(var(--b3-theme-primary-rgb, 59, 130, 246), 0.3)"},onClick:C[0]||(C[0]=x=>A.$emit("applySuperBlockLayout",e.detectedSbInfo))},[re(de,{name:"sparkles"}),C[26]||(C[26]=h("span",null,"应用版式与比例",-1))]),h("button",{class:"spm-btn-action b3-tooltips b3-tooltips__sw","aria-label":"仅将提取的比值写入当前页的分栏比例属性",onClick:C[1]||(C[1]=x=>{var q;return A.$emit("applySuperBlockRatio",((q=e.detectedSbInfo)==null?void 0:q.ratio)||"1:1")})},[re(de,{name:"check"}),h("span",null,"应用比例 ("+we(((U=e.detectedSbInfo)==null?void 0:U.ratio)||"1:1")+")",1)])])])):Te("",!0),h("div",E1,[h("div",A1,[h("div",B1,[h("div",D1,[re(de,{name:"presenter"}),C[27]||(C[27]=h("span",null,"设为讲稿备注",-1))]),C[28]||(C[28]=h("span",{class:"spm-control-desc"},"作为当前页演讲提词，不在幻灯片中渲染",-1))]),h("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":e.isNote?"取消讲稿备注":"设为讲稿备注"},[h("input",{type:"checkbox",checked:!!e.isNote,onChange:C[2]||(C[2]=x=>A.$emit("toggleNote"))},null,40,P1),C[29]||(C[29]=h("span",{class:"spm-switch-slider"},null,-1))],8,L1)])]),e.isImage||e.imageRole?(J(),ee("div",O1,[h("div",R1,[h("div",N1,[h("div",z1,[re(de,{name:"image"}),C[30]||(C[30]=h("span",null,"图片角色与分栏",-1))]),C[31]||(C[31]=h("span",{class:"spm-control-desc"},"设为幻灯片背景图或图文分栏配图",-1))])]),h("div",H1,[h("button",{class:Ce(["spm-chip",{active:!e.imageRole}]),onClick:C[3]||(C[3]=x=>A.$emit("update:imageRole",""))}," 普通内容 ",2),h("button",{class:Ce(["spm-chip",{active:e.imageRole==="background"}]),onClick:C[4]||(C[4]=x=>A.$emit("update:imageRole","background"))},[re(de,{name:"image"}),C[32]||(C[32]=h("span",null,"背景图",-1))],2),h("button",{class:Ce(["spm-chip",{active:e.imageRole==="image-left"}]),onClick:C[5]||(C[5]=x=>A.$emit("update:imageRole","image-left"))},[re(de,{name:"image-left"}),C[33]||(C[33]=h("span",null,"图左",-1))],2),h("button",{class:Ce(["spm-chip",{active:e.imageRole==="image-right"}]),onClick:C[6]||(C[6]=x=>A.$emit("update:imageRole","image-right"))},[re(de,{name:"image-right"}),C[34]||(C[34]=h("span",null,"图右",-1))],2)])])):Te("",!0),e.isVideo?(J(),ee("div",F1,[h("div",j1,[h("div",W1,[h("div",U1,[re(de,{name:"video"}),C[35]||(C[35]=h("span",null,"视频播放设置",-1))]),C[36]||(C[36]=h("span",{class:"spm-control-desc"},"配置播放器控制条、自动播放与循环",-1))])]),h("div",V1,[h("div",G1,[h("span",K1,[re(de,{name:"sliders"}),C[37]||(C[37]=$t(" 控制条",-1))]),h("label",{class:"spm-switch b3-tooltips b3-tooltips__se","aria-label":e.videoControls?"关闭控制条":"开启控制条"},[h("input",{type:"checkbox",checked:!!e.videoControls,onChange:C[7]||(C[7]=x=>A.$emit("toggleVideoControls"))},null,40,Y1),C[38]||(C[38]=h("span",{class:"spm-switch-slider"},null,-1))],8,q1)]),h("div",Z1,[h("span",J1,[re(de,{name:"video"}),C[39]||(C[39]=$t(" 自动播放",-1))]),h("label",{class:"spm-switch b3-tooltips b3-tooltips__sw","aria-label":e.videoAutoplay?"关闭自动播放":"开启自动播放"},[h("input",{type:"checkbox",checked:!!e.videoAutoplay,onChange:C[8]||(C[8]=x=>A.$emit("toggleVideoAutoplay"))},null,40,Q1),C[40]||(C[40]=h("span",{class:"spm-switch-slider"},null,-1))],8,X1)]),h("div",ey,[h("span",ty,[re(de,{name:"repeat"}),C[41]||(C[41]=$t(" 循环播放",-1))]),h("label",{class:"spm-switch b3-tooltips b3-tooltips__se","aria-label":e.videoLoop?"关闭循环播放":"开启循环播放"},[h("input",{type:"checkbox",checked:!!e.videoLoop,onChange:C[9]||(C[9]=x=>A.$emit("toggleVideoLoop"))},null,40,ny),C[42]||(C[42]=h("span",{class:"spm-switch-slider"},null,-1))],8,iy)]),h("div",sy,[h("span",oy,[re(de,{name:"volume-x"}),C[43]||(C[43]=$t(" 静音播放",-1))]),h("label",{class:"spm-switch b3-tooltips b3-tooltips__sw","aria-label":e.videoMuted?"关闭静音":"开启静音"},[h("input",{type:"checkbox",checked:!!e.videoMuted,onChange:C[10]||(C[10]=x=>A.$emit("toggleVideoMuted"))},null,40,ay),C[44]||(C[44]=h("span",{class:"spm-switch-slider"},null,-1))],8,ry)])])])):Te("",!0),h("div",ly,[h("div",cy,[h("div",dy,[h("div",uy,[re(de,{name:"step"}),C[45]||(C[45]=h("span",null,"逐步呈现",-1))]),C[46]||(C[46]=h("span",{class:"spm-control-desc"},"放映时按步长逐个呈现",-1))]),h("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":e.elemClick?"关闭逐步呈现":"开启逐步呈现 (+1)"},[h("input",{type:"checkbox",checked:!!e.elemClick,onChange:C[11]||(C[11]=x=>A.$emit("toggleElemClick"))},null,40,py),C[47]||(C[47]=h("span",{class:"spm-switch-slider"},null,-1))],8,fy)]),e.elemClick?(J(),ee("div",hy,[(J(),ee(Xe,null,xt(["+1","1","2","hide"],x=>h("button",{key:x,class:Ce(["spm-chip",{active:e.elemClick===x}]),onClick:q=>A.$emit("update:elemClick",x)},we(x==="+1"?"顺延 (+1)":x==="hide"?"隐藏":"第 "+x+" 步"),11,my)),64))])):e.parentElemClick?(J(),ee("div",gy,[re(de,{name:"check"}),C[48]||(C[48]=h("span",null,"未单独开启逐步呈现：当前跟随整栏同时出现",-1))])):Te("",!0)]),h("div",vy,[h("div",by,[h("div",yy,[h("div",ky,[re(de,{name:"motion"}),C[49]||(C[49]=h("span",null,"入场微动效",-1))]),C[50]||(C[50]=h("span",{class:"spm-control-desc"},"为当前块添加平滑位移与渐入动画",-1))]),h("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":f.value?"关闭微动效":"开启微动效"},[h("input",{type:"checkbox",checked:f.value,onChange:b},null,40,xy),C[51]||(C[51]=h("span",{class:"spm-switch-slider"},null,-1))],8,wy)]),f.value?(J(),ee("div",Sy,[(J(),ee(Xe,null,xt(p,x=>h("button",{key:x.value,class:Ce(["spm-chip",{active:w.value===x.value}]),onClick:q=>v(x.value)},we(x.label),11,Cy)),64))])):Te("",!0),f.value?(J(),ee("div",_y,[h("div",$y,[h("span",null,"时长: "+we(m.value?m.value+"ms":"默认 (450ms)"),1),h("span",null,"延迟: "+we(y.value?y.value+"ms":"0ms"),1)]),h("div",Iy,[h("select",{class:"spm-select",style:{flex:"1"},value:m.value,onChange:C[12]||(C[12]=x=>k(Number(x.target.value)))},[...C[52]||(C[52]=[h("option",{value:0},"默认耗时",-1),h("option",{value:200},"极速 (200ms)",-1),h("option",{value:350},"较快 (350ms)",-1),h("option",{value:500},"平滑 (500ms)",-1),h("option",{value:800},"缓慢 (800ms)",-1)])],40,My),h("select",{class:"spm-select",style:{flex:"1"},value:y.value,onChange:C[13]||(C[13]=x=>S(Number(x.target.value)))},[...C[53]||(C[53]=[h("option",{value:0},"无延迟",-1),h("option",{value:150},"延迟 150ms",-1),h("option",{value:300},"延迟 300ms",-1),h("option",{value:500},"延迟 500ms",-1)])],40,Ty)])])):Te("",!0)]),s.value||e.elemSlot?(J(),ee("div",Ey,[h("div",Ay,[h("div",By,[h("div",Dy,[re(de,{name:"columns"}),h("span",null,we(a.value),1)]),h("span",Ly,we(r.value),1)])]),h("div",Py,[(J(!0),ee(Xe,null,xt(l.value,x=>(J(),ee("button",{key:x.value,class:Ce(["spm-segmented-item",{active:c(x.value)}]),onClick:q=>A.$emit("update:elemSlot",x.value)},we(x.label),11,Oy))),128))])])):Te("",!0),e.isCodeBlock?(J(),ee("div",Ry,[h("div",Ny,[h("div",zy,[h("div",Hy,[re(de,{name:"code"}),C[54]||(C[54]=h("span",null,"代码逐行聚光",-1))]),C[55]||(C[55]=h("span",{class:"spm-control-desc"},"翻页时动态聚光高亮特定行",-1))])]),h("div",Fy,[(J(),ee(Xe,null,xt(["1-3","all","1|2|3","2-5"],x=>h("button",{key:x,class:Ce(["spm-chip",{active:e.elemShikiLines===x}]),onClick:q=>A.$emit("update:elemShikiLines",x)},we(x),11,jy)),64)),e.elemShikiLines?(J(),ee("button",{key:0,class:"spm-chip spm-chip-clear",onClick:C[14]||(C[14]=x=>A.$emit("update:elemShikiLines",""))}," 清空 ")):Te("",!0)]),h("input",{value:e.elemShikiLines,class:"spm-input",placeholder:"自定义高亮区间，如 1-3|5|all",onInput:C[15]||(C[15]=x=>A.$emit("update:elemShikiLines",x.target.value)),onChange:C[16]||(C[16]=x=>A.$emit("update:elemShikiLines",x.target.value))},null,40,Wy)])):Te("",!0),e.isCodeBlock?(J(),ee("div",Uy,[h("div",Vy,[h("div",Gy,[h("div",Ky,[re(de,{name:"code"}),C[56]||(C[56]=h("span",null,"代码块限高",-1))]),C[57]||(C[57]=h("span",{class:"spm-control-desc"},"超出限高自动竖向滚动，弱提示滚动条",-1))])]),h("div",qy,[(J(),ee(Xe,null,xt(["240px","320px","400px","50vh"],x=>h("button",{key:x,class:Ce(["spm-chip",{active:e.elemMaxHeight===x}]),onClick:q=>A.$emit("update:elemMaxHeight",x)},we(x),11,Yy)),64)),e.elemMaxHeight?(J(),ee("button",{key:0,class:"spm-chip spm-chip-clear",onClick:C[17]||(C[17]=x=>A.$emit("update:elemMaxHeight",""))}," 自适应 ")):Te("",!0)]),h("input",{value:e.elemMaxHeight,class:"spm-input",placeholder:"自适应高度，或输入 350px、50vh",onInput:C[18]||(C[18]=x=>A.$emit("update:elemMaxHeight",x.target.value)),onChange:C[19]||(C[19]=x=>A.$emit("update:elemMaxHeight",x.target.value))},null,40,Zy)])):Te("",!0),h("div",Jy,[C[61]||(C[61]=h("div",{class:"spm-control-header"},[h("div",{class:"spm-control-title-group"},[h("span",{class:"spm-control-title"},"快捷操作")])],-1)),h("div",Xy,[h("button",{class:"spm-btn-action b3-tooltips b3-tooltips__se","aria-label":"在当前块上方插入幻灯片分页线 (---)",onClick:C[20]||(C[20]=x=>A.$emit("insertDividerBefore"))},[re(de,{name:"insert-above"}),C[58]||(C[58]=h("span",null,"上方分页",-1))]),h("button",{class:"spm-btn-action b3-tooltips b3-tooltips__sw","aria-label":"在当前块下方插入幻灯片分页线 (---)",onClick:C[21]||(C[21]=x=>A.$emit("insertDividerAfter"))},[re(de,{name:"insert-below"}),C[59]||(C[59]=h("span",null,"下方分页",-1))]),h("button",{class:"spm-btn-action b3-tooltips b3-tooltips__se","aria-label":n.value==="three-cols-header"?"将当前块属性设为三栏第1栏归属":"将当前块属性设为双栏左侧归属",onClick:C[22]||(C[22]=x=>A.$emit("setTwoColsContrast"))},[re(de,{name:"columns"}),h("span",null,we(n.value==="three-cols-header"?"设为第1栏":"设为双栏"),1)],8,Qy),e.hasBlockAttrs?(J(),ee("button",{key:0,class:"spm-btn-action spm-btn-danger b3-tooltips b3-tooltips__sw","aria-label":"一键移除本块所有 custom-slides 属性",onClick:C[23]||(C[23]=x=>A.$emit("clearBlockAttrs"))},[re(de,{name:"broom"}),C[60]||(C[60]=h("span",null,"清除属性",-1))])):Te("",!0)])])])}}}),t0={class:"spm-section spm-section--doc"},i0={class:"spm-card-control"},n0={class:"spm-control-header"},s0={class:"spm-control-title-group"},o0={class:"spm-control-title"},r0={class:"spm-segmented-group"},a0=["aria-label","onClick"],l0={class:"spm-card-control"},c0={class:"spm-control-header"},d0={class:"spm-control-title-group"},u0={class:"spm-control-title"},f0={class:"spm-quick-chips"},p0=["onClick"],h0=["value"],m0={class:"spm-card-control"},g0={class:"spm-control-header"},v0={class:"spm-control-title-group"},b0={class:"spm-control-title"},y0={class:"spm-segmented-group"},k0={class:"spm-card-control"},w0={class:"spm-control-header"},x0={class:"spm-control-title-group"},S0={class:"spm-control-title"},C0={class:"spm-segmented-group"},_0={class:"spm-card-control"},$0={class:"spm-control-header"},I0={class:"spm-control-title-group"},M0={class:"spm-control-title"},T0={class:"spm-card-control"},E0={class:"spm-control-header"},A0={class:"spm-control-title-group"},B0={class:"spm-control-title"},D0=["aria-label"],L0=["checked"],P0={key:0,class:"spm-control-body",style:{"margin-top":"8px"}},O0=["value"],R0={class:"spm-card-control"},N0={class:"spm-control-header"},z0={class:"spm-control-title-group"},H0={class:"spm-control-title"},F0=["aria-label"],j0=["checked"],W0={class:"spm-card-control"},U0={class:"spm-control-header"},V0={class:"spm-control-title-group"},G0={class:"spm-control-title"},K0={class:"spm-list-markers-toggles",style:{display:"flex",gap:"8px","margin-top":"8px"}},q0={class:"spm-marker-toggle-item",style:{flex:"1",display:"flex","align-items":"center","justify-content":"space-between",padding:"6px 10px",background:"var(--b3-theme-surface)",border:"1px solid var(--b3-border-color)","border-radius":"4px"}},Y0=["aria-label"],Z0=["checked"],J0={class:"spm-marker-toggle-item",style:{flex:"1",display:"flex","align-items":"center","justify-content":"space-between",padding:"6px 10px",background:"var(--b3-theme-surface)",border:"1px solid var(--b3-border-color)","border-radius":"4px"}},X0=["aria-label"],Q0=["checked"],ek={class:"spm-card-control"},tk={class:"spm-action-grid"},ik=["disabled"],nk=["disabled"],sk=["disabled","aria-label"],ok=Dt({__name:"DocInspectorSection",props:{docTheme:{},docBackground:{},docAspectRatio:{},docDefaultTransition:{},docSpacing:{},isExportingImages:{type:Boolean},isBatchProcessing:{type:Boolean}},emits:["update:docTheme","update:docBackground","update:docAspectRatio","update:docDefaultTransition","update:docSpacing","openBottomPreview","openPresenter","identifyNotes","autoAnimate","aiAutoSplit","exportHtml","exportPdf","exportImages"],setup(e){const t=zt("plugin"),i=Vt,n=[{value:"default",label:"默认 default",desc:"官方默认科技风：现代无衬线排版与清新代码语法高亮，通用汇报与技术分享首选"},{value:"seriph",label:"优雅 seriph",desc:"典雅学术衬线风：书卷学术质感、衬线字体典雅庄重，适合学术论文、人文讲座与深度阅读"},{value:"apple-basic",label:"极简 apple",desc:"苹果发布会极简风：大字号、高对比度与极致留白，适合产品发布、方案演讲与纯粹视觉呈现"}];function s(p){ri({enableWebServeJump:p}),t&&typeof t.saveGlobalSettings=="function"&&t.saveGlobalSettings({enableWebServeJump:p})}async function o(p){var u;ri({normalizeHeadingSizes:p}),t&&typeof t.saveGlobalSettings=="function"&&await t.saveGlobalSettings({normalizeHeadingSizes:p}),t&&typeof t.compileCurrentDocument=="function"&&t.compileCurrentDocument(t.currentDocId||((u=t.getActiveDocumentId)==null?void 0:u.call(t)))}async function a(p){var u;ri({showUnorderedListMarkers:p}),t&&typeof t.saveGlobalSettings=="function"&&await t.saveGlobalSettings({showUnorderedListMarkers:p}),t&&typeof t.compileCurrentDocument=="function"&&t.compileCurrentDocument(t.currentDocId||((u=t.getActiveDocumentId)==null?void 0:u.call(t)))}async function r(p){var u;ri({showOrderedListMarkers:p}),t&&typeof t.saveGlobalSettings=="function"&&await t.saveGlobalSettings({showOrderedListMarkers:p}),t&&typeof t.compileCurrentDocument=="function"&&t.compileCurrentDocument(t.currentDocId||((u=t.getActiveDocumentId)==null?void 0:u.call(t)))}function l(p){ri({webServeUrl:p})}function c(p){ri({webServeUrl:p}),t&&typeof t.saveGlobalSettings=="function"&&t.saveGlobalSettings({webServeUrl:p})}const d=[{label:"默认",value:""},{label:"极简白",value:"#ffffff"},{label:"柔和灰",value:"#f8fafc"},{label:"暗黑 #1e1e24",value:"#1e1e24"},{label:"极夜 #0f172a",value:"#0f172a"},{label:"雅蓝渐变",value:"linear-gradient(135deg, #1e293b 0%, #0f172a 100%)"},{label:"极光渐变",value:"linear-gradient(135deg, #0f172a 0%, #1e1b4b 100%)"},{label:"晨雾渐变",value:"linear-gradient(135deg, #f8fafc 0%, #e2e8f0 100%)"}];return(p,u)=>(J(),ee("div",t0,[u[56]||(u[56]=h("div",{class:"spm-section-header"},[h("span",null,"全局演示配置")],-1)),h("div",i0,[h("div",n0,[h("div",s0,[h("div",o0,[re(de,{name:"palette"}),u[25]||(u[25]=h("span",null,"幻灯片主题",-1))]),u[26]||(u[26]=h("span",{class:"spm-control-desc"},"全局幻灯片视觉设计范式",-1))])]),h("div",r0,[(J(),ee(Xe,null,xt(n,f=>h("button",{key:f.value,class:Ce(["spm-segmented-item b3-tooltips b3-tooltips__s",{active:e.docTheme===f.value}]),"aria-label":f.desc,onClick:w=>p.$emit("update:docTheme",f.value)},we(f.label),11,a0)),64))])]),h("div",l0,[h("div",c0,[h("div",d0,[h("div",u0,[re(de,{name:"palette"}),u[27]||(u[27]=h("span",null,"演示背景",-1))]),u[28]||(u[28]=h("span",{class:"spm-control-desc"},"全篇幻灯片统一底色、微渐变或壁纸",-1))])]),h("div",f0,[(J(),ee(Xe,null,xt(d,f=>h("button",{key:f.value,class:Ce(["spm-chip",{active:(e.docBackground||"")===f.value}]),onClick:w=>p.$emit("update:docBackground",f.value)},we(f.label),11,p0)),64))]),h("input",{value:e.docBackground||"",class:"spm-input",placeholder:"自定义颜色 (#1e1e24)、渐变或资源路径 (assets/...)",onInput:u[0]||(u[0]=f=>p.$emit("update:docBackground",f.target.value)),onChange:u[1]||(u[1]=f=>p.$emit("update:docBackground",f.target.value))},null,40,h0)]),h("div",m0,[h("div",g0,[h("div",v0,[h("div",b0,[re(de,{name:"ratio"}),u[29]||(u[29]=h("span",null,"画幅比例",-1))]),u[30]||(u[30]=h("span",{class:"spm-control-desc"},"演讲屏幕投影宽高比",-1))])]),h("div",y0,[h("button",{class:Ce(["spm-segmented-item",{active:e.docAspectRatio==="16/9"}]),onClick:u[2]||(u[2]=f=>p.$emit("update:docAspectRatio","16/9"))}," 16 : 9 (宽屏) ",2),h("button",{class:Ce(["spm-segmented-item",{active:e.docAspectRatio==="4/3"}]),onClick:u[3]||(u[3]=f=>p.$emit("update:docAspectRatio","4/3"))}," 4 : 3 (标屏) ",2),h("button",{class:Ce(["spm-segmented-item",{active:e.docAspectRatio==="16/10"}]),onClick:u[4]||(u[4]=f=>p.$emit("update:docAspectRatio","16/10"))}," 16 : 10 ",2)])]),h("div",k0,[h("div",w0,[h("div",x0,[h("div",S0,[re(de,{name:"ratio"}),u[31]||(u[31]=h("span",null,"间距风格",-1))]),u[32]||(u[32]=h("span",{class:"spm-control-desc"},"内边距与顶部标题下边距预设",-1))])]),h("div",C0,[h("button",{class:Ce(["spm-segmented-item b3-tooltips b3-tooltips__se",{active:(e.docSpacing||"normal")==="compact"}]),"aria-label":"紧凑排版：上下 20px / 左右 36px",onClick:u[5]||(u[5]=f=>p.$emit("update:docSpacing","compact"))}," 紧凑 ",2),h("button",{class:Ce(["spm-segmented-item b3-tooltips b3-tooltips__s",{active:(e.docSpacing||"normal")==="normal"}]),"aria-label":"标准排版：上下 32px / 左右 48px（推荐默认）",onClick:u[6]||(u[6]=f=>p.$emit("update:docSpacing","normal"))}," 标准 ",2),h("button",{class:Ce(["spm-segmented-item b3-tooltips b3-tooltips__sw",{active:(e.docSpacing||"normal")==="loose"}]),"aria-label":"宽松排版：上下 48px / 左右 56px",onClick:u[7]||(u[7]=f=>p.$emit("update:docSpacing","loose"))}," 宽松 ",2)])]),h("div",_0,[h("div",$0,[h("div",I0,[h("div",M0,[re(de,{name:"transition"}),u[33]||(u[33]=h("span",null,"全局默认转场",-1))]),u[34]||(u[34]=h("span",{class:"spm-control-desc"},"页面切换过渡动效（未单设转场的页面将继承此动效）",-1))])]),re(oc,{"model-value":e.docDefaultTransition,"hide-header":!0,onChange:u[8]||(u[8]=f=>p.$emit("update:docDefaultTransition",f))},null,8,["model-value"])]),h("div",T0,[h("div",E0,[h("div",A0,[h("div",B0,[re(de,{name:"external-link"}),u[35]||(u[35]=h("span",null,"本地网络伺服预览",-1))]),u[36]||(u[36]=h("span",{class:"spm-control-desc"},"点击文档/块链接以 Webview 抽屉呈现，支持外跳",-1))]),h("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":he(i).enableWebServeJump?"关闭本地网络伺服预览":"开启本地网络伺服预览"},[h("input",{type:"checkbox",checked:he(i).enableWebServeJump,onChange:u[9]||(u[9]=f=>s(f.target.checked))},null,40,L0),u[37]||(u[37]=h("span",{class:"spm-switch-slider"},null,-1))],8,D0)]),he(i).enableWebServeJump?(J(),ee("div",P0,[h("input",{value:he(i).webServeUrl,class:"spm-input",placeholder:"http://127.0.0.1:6806",spellcheck:"false",onKeydown:u[10]||(u[10]=Zt(()=>{},["stop"])),onKeyup:u[11]||(u[11]=Zt(()=>{},["stop"])),onInput:u[12]||(u[12]=f=>l(f.target.value)),onChange:u[13]||(u[13]=f=>c(f.target.value))},null,40,O0),u[38]||(u[38]=h("span",{class:"spm-control-desc",style:{display:"block","margin-top":"4px","font-size":"11px",opacity:"0.8"}}," 默认伺服地址为 http://127.0.0.1:6806。开启后点击块链接将在 Webview 抽屉中打开，点击抽屉顶部『外跳』可在外部浏览器打开 ",-1))])):Te("",!0)]),h("div",R0,[h("div",N0,[h("div",z0,[h("div",H0,[re(de,{name:"type"}),u[39]||(u[39]=h("span",null,"固定特定标题大小",-1))]),u[40]||(u[40]=h("span",{class:"spm-control-desc"},"除封面外页首标题按 H2、多栏内首标题按 H3 大小展示",-1))]),h("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":he(i).normalizeHeadingSizes?"关闭固定特定标题大小":"开启固定特定标题大小"},[h("input",{type:"checkbox",checked:he(i).normalizeHeadingSizes,onChange:u[14]||(u[14]=f=>o(f.target.checked))},null,40,j0),u[41]||(u[41]=h("span",{class:"spm-switch-slider"},null,-1))],8,F0)])]),h("div",W0,[h("div",U0,[h("div",V0,[h("div",G0,[re(de,{name:"list"}),u[42]||(u[42]=h("span",null,"列表前缀标记",-1))]),u[43]||(u[43]=h("span",{class:"spm-control-desc"},"分别控制正文中无序列表圆点与有序列表数字序号的呈现",-1))])]),h("div",K0,[h("div",q0,[u[45]||(u[45]=h("span",{style:{"font-size":"12px",color:"var(--b3-theme-on-surface)"}},"无序圆点",-1)),h("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":he(i).showUnorderedListMarkers?"关闭无序列表圆点显示":"开启无序列表圆点显示"},[h("input",{type:"checkbox",checked:he(i).showUnorderedListMarkers,onChange:u[15]||(u[15]=f=>a(f.target.checked))},null,40,Z0),u[44]||(u[44]=h("span",{class:"spm-switch-slider"},null,-1))],8,Y0)]),h("div",J0,[u[47]||(u[47]=h("span",{style:{"font-size":"12px",color:"var(--b3-theme-on-surface)"}},"有序序号",-1)),h("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":he(i).showOrderedListMarkers?"关闭有序列表序号显示":"开启有序列表序号显示"},[h("input",{type:"checkbox",checked:he(i).showOrderedListMarkers,onChange:u[16]||(u[16]=f=>r(f.target.checked))},null,40,Q0),u[46]||(u[46]=h("span",{class:"spm-switch-slider"},null,-1))],8,X0)])])]),h("div",ek,[u[55]||(u[55]=h("div",{class:"spm-control-header"},[h("div",{class:"spm-control-title-group"},[h("span",{class:"spm-control-title"},"演示全局操作")])],-1)),h("div",tk,[h("button",{class:"spm-btn-action b3-tooltips b3-tooltips__sw","aria-label":"在当前文档下方开启分屏同步预览 (Alt+P)",onClick:u[17]||(u[17]=f=>p.$emit("openBottomPreview"))},[re(de,{name:"split-preview"}),u[48]||(u[48]=h("span",null,"分屏预览",-1))]),he(It)("presenterMode")?(J(),ee("button",{key:0,class:"spm-btn-action b3-tooltips b3-tooltips__sw","aria-label":"打开双屏演讲者控制台视窗 (Alt+M)",onClick:u[18]||(u[18]=f=>p.$emit("openPresenter"))},[re(de,{name:"presenter"}),u[49]||(u[49]=h("span",null,"演讲者视图",-1))])):Te("",!0),h("button",{class:"spm-btn-action b3-tooltips b3-tooltips__sw","aria-label":"识别各页分隔线前未设属性的提示块/引用块为标准讲稿备注",disabled:e.isBatchProcessing,onClick:u[19]||(u[19]=f=>p.$emit("identifyNotes"))},[re(de,{name:"notes"}),u[50]||(u[50]=h("span",null,"识别讲稿块",-1))],8,ik),h("button",{class:"spm-btn-action b3-tooltips b3-tooltips__sw","aria-label":"自动为正文各页标题及首块之外的后续内容块配置顺延 (+1) 逐步呈现动效",disabled:e.isBatchProcessing,onClick:u[20]||(u[20]=f=>p.$emit("autoAnimate"))},[re(de,{name:"step"}),u[51]||(u[51]=h("span",null,"智能动效",-1))],8,nk),he(It)("aiScript")?(J(),ee("button",{key:1,class:"spm-btn-action b3-tooltips b3-tooltips__se","aria-label":"智能分析长文本大纲与篇幅，自动插入分页线",onClick:u[21]||(u[21]=f=>p.$emit("aiAutoSplit"))},[re(de,{name:"sparkles"}),u[52]||(u[52]=h("span",null,"智能分页",-1))])):Te("",!0),he(It)("exportHtml")?(J(),ee("button",{key:2,class:"spm-btn-action b3-tooltips b3-tooltips__sw","aria-label":"打包导出离线单文件 HTML 幻灯片",onClick:u[22]||(u[22]=f=>p.$emit("exportHtml"))},[re(de,{name:"export-html"}),u[53]||(u[53]=h("span",null,"导出 HTML",-1))])):Te("",!0),he(It)("exportPdf")?(J(),ee("button",{key:3,class:"spm-btn-action b3-tooltips b3-tooltips__se","aria-label":"打印生成 16:9 高清演示 PDF 讲义",onClick:u[23]||(u[23]=f=>p.$emit("exportPdf"))},[re(de,{name:"export-pdf"}),u[54]||(u[54]=h("span",null,"导出 PDF",-1))])):Te("",!0),he(It)("exportImage")?(J(),ee("button",{key:4,class:Ce(["spm-btn-action b3-tooltips b3-tooltips__s",{"is-loading":e.isExportingImages}]),disabled:e.isExportingImages,"aria-label":e.isExportingImages?"正在逐页导出高清图片包，请稍候...":"逐页导出高清图片包 (ZIP)",onClick:u[24]||(u[24]=f=>p.$emit("exportImages"))},[re(de,{name:"export-image"}),h("span",null,we(e.isExportingImages?"正在导出...":"导出图片"),1)],10,sk)):Te("",!0)])])]))}}),rk=/\.(?:png|jpe?g|gif|svg|webp|avif|ico|bmp|tiff?|mp4|webm|mp3|wav|ogg)$/i,ak=/\.(?:ts|js|mjs|cjs|jsx|tsx|vue|json|css|scss|less|html|py|rs|go|java|c|cpp|h|sh|bash|yaml|yml|toml)$/i;async function lk(e){const t=await Xl.loadAsync(e),i={},n=[];let s="",o="";const a=[];t.forEach((l,c)=>{!c.dir&&!l.startsWith("__MACOSX")&&!l.includes("node_modules/")&&a.push({path:l,file:c})});let r=a.find(l=>l.path.toLowerCase()==="slides.md");r||(r=a.find(l=>l.path.toLowerCase().endsWith("/slides.md"))),r||(r=a.find(l=>l.path.toLowerCase().endsWith(".md"))),r&&(s=await r.file.async("string"),o=r.path);for(const l of a){const c=l.path;if(c.toLowerCase().endsWith(".md")||ak.test(c)||c.includes("snippets/")){const d=await l.file.async("string");i[c]=d;const p=c.split("/");p.length>1&&(i[p.slice(1).join("/")]=d)}else if(rk.test(c)){const d=await l.file.async("uint8array"),p=c.split("/").pop()||c,u=typeof Blob<"u"?new Blob([d]):void 0;n.push({zipPath:c,fileName:p,data:d,blob:u})}}return{entryMarkdown:s,entryMarkdownPath:o,virtualFiles:i,assets:n}}function ck(e,t){if(Object.keys(t).length===0)return e;function i(s){const o=s.trim().replace(/^['"]|['"]$/g,""),a=o.split("/").pop()||o;if(t[o])return t[o];const r=o.replace(/^\.?\//,"");return t[r]?t[r]:t[a]?t[a]:null}function n(s){let o=s;return o=o.replace(/!\[(.*?)\]\((.*?)\)/g,(a,r,l)=>{const c=i(l);return c?`![${r}](${c})`:a}),o=o.replace(/\bsrc=["'](.*?)["']/gi,(a,r)=>{const l=i(r);return l?`src="${l}"`:a}),o}for(const s of e.slides)if(s.rawMarkdown=n(s.rawMarkdown),s.pageAttrs["custom-slides-background"]){const o=s.pageAttrs["custom-slides-background"],a=i(o);a&&(s.pageAttrs["custom-slides-background"]=a)}if(e.flattenedMarkdown=n(e.flattenedMarkdown),e.docRootAttrs["custom-slides-background"]){const s=e.docRootAttrs["custom-slides-background"],o=i(s);o&&(e.docRootAttrs["custom-slides-background"]=o)}return e}function rc(e){try{if(typeof process<"u"&&typeof require<"u"){const t=require("fs");if(t.existsSync(e))return t.readFileSync(e,"utf-8")}}catch{}return null}function dk(e,t){const i=e.match(/^[ \t]*<<<[ \t]+([^\s]+)/);if(!i)return null;const n=i[1].trim(),s=n.indexOf("#"),o=s!==-1?n.slice(0,s):n,a=s!==-1?n.slice(s+1):"",r=o.replace(/^@\//,"").replace(/^\.\//,""),l=(t==null?void 0:t.virtualFiles)||{};let c=l[o]||l[r]||l[`./${r}`]||l[`@/${r}`];if(!c&&Object.keys(l).length>0){const f=r.split("/").pop();for(const[w,m]of Object.entries(l))if(w.endsWith(`/${r}`)||f&&w.endsWith(`/${f}`)){c=m;break}}if(!c){const f=[];if(t!=null&&t.baseDir)try{const w=require("path");f.push(w.resolve(t.baseDir,r)),f.push(w.resolve(t.baseDir,o))}catch{}try{const w=require("path");f.push(w.resolve(process.cwd(),r))}catch{}for(const w of f){const m=rc(w);if(m!==null){c=m;break}}}if(!c){const f=jl||{};if(c=f[o]||f[r]||f[`snippets/${r}`],!c){const w=r.split("/").pop();for(const[m,y]of Object.entries(f))if(m.endsWith(`/${r}`)||w&&m.endsWith(`/${w}`)){c=y;break}}}if(!c)return null;let d=c;if(a){const f=new RegExp(`(?:\\/\\/|\\/\\*|#)?\\s*#(?:region|REGION)\\s+${a}[^\\r\\n]*\\r?\\n([\\s\\S]*?)(?:\\/\\/|\\/\\*|#)?\\s*#(?:endregion|ENDREGION)\\s+${a}`,"i"),w=c.match(f);if(w){const m=c.match(/^(\/\/\s*Inside[^\r\n]+\r?\n)/i);d=(m?m[1]:"")+w[1].trimEnd()}}const p=r.match(/\.([a-zA-Z0-9]+)$/);return`\`\`\`${p?p[1]:""}
${d}
\`\`\``}function uk(e){let t=!1,i=!1;for(let n=0;n<e.length;n++){const s=e[n];if(s==="'"&&!i)t=!t;else if(s==='"'&&!t)i=!i;else if(s==="#"&&!t&&!i)return e.slice(0,n).trim()}return e.trim()}function gs(e){const t={},i=e.split(/\r?\n/);let n=0;for(;n<i.length;){const s=i[n],o=s.trim();if(!o||o.startsWith("#")){n++;continue}const a=s.indexOf(":");if(a>0){const r=s.slice(0,a).trim();let l=s.slice(a+1).trim();if(l==="|"||l===">"){n++;const c=[];let d=-1;for(;n<i.length;){const p=i[n];if(!p.trim()){c.push(""),n++;continue}const f=p.match(/^(\s+)/),w=f?f[1].length:0;if(d===-1&&(d=w),w<d)break;c.push(p.slice(d)),n++}for(;c.length>0&&c[c.length-1]==="";)c.pop();t[r]=l===">"?c.join(" "):c.join(`
`);continue}if(l=uk(l),!l){let c=n+1;const d=[];let p=-1;for(;c<i.length;){const u=i[c],f=u.trim();if(!f||f.startsWith("#")){p!==-1&&d.push(""),c++;continue}const w=u.match(/^(\s+)/),m=w?w[1].length:0;if(p===-1)if(m>0)p=m;else break;if(m<p)break;d.push(u.slice(p)),c++}if(d.length>0){t[r]=gs(d.join(`
`)),n=c;continue}}l.startsWith('"')&&l.endsWith('"')||l.startsWith("'")&&l.endsWith("'")?l=l.slice(1,-1):l==="true"?l=!0:l==="false"?l=!1:l==="null"?l=null:/^-?\d+(?:\.\d+)?$/.test(l)&&(l=Number(l)),t[r]=l}n++}return t}const fk=/^\s*```ya?ml([\s\S]*?)```/;function ha(e){let t={},i=e.trim();const n=i.match(/^---[^\n\r]*\r?\n([\s\S]*?)\r?\n---(?=[ \t]*(?:\r?\n|$))/);if(n&&!n[1].includes("```")){const o=gs(n[1]);if(Object.keys(o).length>0||!n[1].trim())return t=o,i=i.slice(n[0].length).trim(),{frontmatter:t,content:i}}if(i.startsWith("---")){const o=i.match(/^---[^\n\r]*(?:\r?\n|$)/);o&&(i=i.slice(o[0].length).trim())}const s=i.match(fk);if(s)t=gs(s[1]),i=i.slice(s[0].length).trim();else{const o=i.split(/\r?\n/),a=[];let r=0;for(let l=0;l<o.length;l++){const c=o[l].trim();if(!c){if(a.length>0){r=l+1;break}continue}if(/^[a-zA-Z0-9_-]+\s*:\s*.*/.test(c)&&!c.startsWith("<")&&!c.startsWith("#"))a.push(c);else{r=l;break}}a.length>0&&(t=gs(a.join(`
`)),i=o.slice(r).join(`
`).trim())}return{frontmatter:t,content:i}}function pk(e){const t=e.split(/\r?\n/),i=[];let n=0,s=!1;function o(a){if(n>=a)return;const r=t.slice(n,a).join(`
`).trim();r&&i.push(r),n=a+1}for(let a=0;a<t.length;a++){const l=t[a].trimEnd();if(s){l.includes("-->")&&(s=!1);continue}if(l.startsWith("<!--")){l.includes("-->")||(s=!0);continue}if(l.startsWith("---")){o(a);const c=t[a+1];let d=!1,p=-1;const u=c?c.trim():"";if(l.replace(/^-+/,"").trim()===""&&u.length>0){for(let f=a+1;f<t.length;f++){const w=t[f].trimEnd();if(w.startsWith("```"))break;if(w==="---"){p=f;break}}p!==-1&&p-a<=60&&t.slice(a+1,p).some(m=>{const y=m.trim();return y.length>0&&!y.startsWith("#")&&/^[a-zA-Z0-9_$-]+\s*:\s*.*/.test(y)})&&(d=!0)}d&&p!==-1&&(n=a,a=p)}else if(l.trimStart().startsWith("```")){const c=l.match(/^\s*`+/),d=c?c[0].trim():"```";let p=a+1;for(;p<t.length&&!t[p].trimStart().startsWith(d);p++);p<t.length&&(a=p)}}return n<t.length&&o(t.length),i}function vs(e,t={}){const{stripNotesFromMarkdown:i=!0,cleanVClicks:n=!0,cleanShikiLines:s=!0,cleanSlots:o=!0,isolateStyleTags:a=!0,cleanHtmlToMarkdown:r=!0,wrapSuperBlocks:l=!0,virtualFiles:c={}}=t;let d=e;d&&!d.trimStart().startsWith("---")&&(d=`---

${d.trimStart()}`);const p=pk(d),u={};let f="",w="",m=0;if(p.length>0){const N=p[0],K=ha(N),_=Object.keys(K.frontmatter).length>0,U=K.content.length>0;_&&!U&&p.length>1?(m=1,y(K.frontmatter)):_&&y(K.frontmatter)}function y(N){f=N.title||"",N.theme&&(u[Nn]=String(N.theme)),N.aspectRatio&&(u[zn]=String(N.aspectRatio)),N.highlighter&&(u[Ca]=String(N.highlighter)),N.transition&&(u[Hn]=String(N.transition)),N.colorSchema&&(u[_a]=String(N.colorSchema)),N.layout&&(u[ke]=String(N.layout)),N.background&&(u[st]=String(N.background)),N.image&&(u[Rt]=String(N.image)),N.class&&(u[en]=String(N.class));for(const[K,_]of Object.entries(N))["theme","aspectRatio","highlighter","transition","colorSchema","title","layout","background","image","class"].includes(K)||(u[`custom-slides-${K}`]=typeof _=="object"?JSON.stringify(_):String(_))}const b=[];let v=0,k=0,S=0,D=0;const A=new Set,C={};let L=1;for(let N=m;N<p.length;N++){const K=p[N],{frontmatter:_,content:U}=ha(K),x=K.match(/^\s*(?:---\s*)?src:\s*([^\n\r]+)/m),q=_.src||(x?x[1]:void 0);if(q){const fe=String(q).trim().replace(/^['"]|['"]$/g,"");let X=c[fe]||c[fe.replace(/^\.\//,"")]||c[`pages/${fe.replace(/^.*pages\//,"")}`];if(!X){const E=fe.replace(/^\.\//,""),F=[];if(t.baseDir)try{const g=require("path");F.push(g.resolve(t.baseDir,E)),F.push(g.resolve(t.baseDir,fe))}catch{}try{const g=require("path");F.push(g.resolve(process.cwd(),E)),F.push(g.resolve(process.cwd(),fe))}catch{}for(const g of F){const W=rc(g);if(W!==null){X=W;break}}}const pe={};_.layout&&(pe[ke]=String(_.layout)),_.transition&&(pe[gt]=String(_.transition)),_.background&&(pe[st]=String(_.background)),_.image&&(pe[Rt]=String(_.image)),_.class&&(pe[en]=String(_.class));for(const[E,F]of Object.entries(_))["src","layout","transition","background","image","class"].includes(E)||(pe[`custom-slides-${E}`]=typeof F=="object"?JSON.stringify(F):String(F));if(X){const E=vs(X,{...t,virtualFiles:c});for(const F of E.slides){F.pageIndex=L++,F.pageAttrs={...pe,...F.pageAttrs},b.push(F);const g=F.pageAttrs[ke]||"default";C[g]=(C[g]||0)+1}continue}else{b.push({pageIndex:L++,pageAttrs:{...pe,"custom-slides-src":fe},notes:"",rawMarkdown:`> 📄 **引入外部幻灯片页面**: \`${fe}\`
>
> *提示：如需展示该页面完整内容，请将关联子页面一同打包为 .zip 或通过本地工程导入。*`,hasVueComponent:!1,hasStyleTag:!1,assetReferences:[]});const E=pe[ke]||"default";C[E]=(C[E]||0)+1;continue}}const O={};_.layout&&(O[ke]=String(_.layout)),_.transition&&(O[gt]=String(_.transition)),_.background&&(O[st]=String(_.background)),_.image&&(O[Rt]=String(_.image)),_.class&&(O[en]=String(_.class)),_.mask&&(O[tn]=String(_.mask)),(_.maskRatio||_["mask-ratio"])&&(O[Fi]=String(_.maskRatio||_["mask-ratio"])),(_.maskStyle||_["mask-style"])&&(O[nn]=String(_.maskStyle||_["mask-style"])),(_.maskInitial||_["mask-initial"])&&(O[sn]=String(_.maskInitial||_["mask-initial"]));for(const[fe,X]of Object.entries(_))["layout","transition","background","image","class","mask","maskRatio","mask-ratio","maskStyle","mask-style","maskInitial","mask-initial"].includes(fe)||(O[`custom-slides-${fe}`]=typeof X=="object"?JSON.stringify(X):String(X));let $=U;const T=[];let P=$.replace(/(?:^[ \t]*(`{3,}|~{3,})[^\n\r]*\r?\n[\s\S]*?\r?\n[ \t]*\1(?=[ \t]*(?:\r?\n|$)))/gm,fe=>{const X=`__CODE_TOKEN_NOTE_${T.length}__`;return T.push(fe),X});P=P.replace(/(`+)(?:[^\n\r`]|(?!\1)`)+?\1/g,fe=>{const X=`__CODE_TOKEN_NOTE_${T.length}__`;return T.push(fe),X});let se="";const V=Array.from(P.matchAll(/<!--([\s\S]*?)-->/g));if(V.length>0){const fe=V[V.length-1],X=P.slice(fe.index+fe[0].length).trim();if(!X||!X.replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi,"").trim()){const E=fe[1].trim();E.startsWith("TODO:")||(se=E,v++),i&&(P=P.slice(0,fe.index).trimEnd()+P.slice(fe.index+fe[0].length))}}i&&(P=P.replace(/<!--(?![\s\S]*?TODO:)[\s\S]*?-->/g,"").trim());for(let fe=0;fe<T.length;fe++)P=P.replace(`__CODE_TOKEN_NOTE_${fe}__`,()=>T[fe]);if($=P,se){for(let pe=0;pe<T.length;pe++)se=se.replace(`__CODE_TOKEN_NOTE_${pe}__`,()=>T[pe]);const X=`> [!NOTE] 💡 演讲备注
${se.split(/\r?\n/).map(pe=>`> ${pe}`).join(`
`)}
{: custom-slides-note="true"}`;$=$?`${$}

${X}`:X}let Y=!1;if(/<style\b/i.test($)){Y=!0;const fe=$.match(/<style\b[^>]*>([\s\S]*?)<\/style>/gi);if(fe){for(const X of fe){const pe=X.replace(/<style\b[^>]*>|<\/style>/gi,"").trim();w=w?`${w}

${pe}`:pe}a&&($=$.replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi,"").trim())}}const le=$.match(/<v-click[^>]*>|<v-clicks[^>]*>|v-click=/g);le&&(k+=le.length);const ie=$.match(/```\w+\s+\{[^}]+\}/g);ie&&(S+=ie.length);const oe=$.match(/::\w+::|<template\s+#[^>]+>/g);if(oe&&(D+=oe.length),$=$.replace(/^[ \t]*<<<[ \t]+([^\n\r]+)/gm,fe=>dk(fe,{...t,virtualFiles:c})||fe),n&&($=$.replace(/<v-click(?:\s+at="[^"]*")?(?:\s+hide)?>\s*([\s\S]*?)\s*<\/v-click>/gi,"$1")),s&&($=$.replace(/(^```\w+(?:[ \t]+\[[^\]]*\])?)[ \t]+\{[^}]+\}(?:[ \t]+\w+)?/gm,"$1"),$=$.replace(/^\$\$\s+\{[^}]+\}/gm,()=>"$$")),o&&($=$.replace(/^::\w+::\s*$/gm,"")),r&&($=tp($)),l){let fe=$.trim(),X="";const pe=fe.lastIndexOf("> [!NOTE] 💡 演讲备注");if(pe!==-1&&(X=fe.slice(pe),fe=fe.slice(0,pe).trim()),(_.layout==="image-left"||_.layout==="image-right")&&_.image){const E=String(_.image).trim(),F=_.layout==="image-left"?"image-left":"image-right",g=`![配图](${E})
{: custom-slides-layout="${F}" }`;_.layout==="image-left"?fe=`{{{col

${g}

${fe}

}}}`:fe=`{{{col

${fe}

${g}

}}}`}if(_.background){const F=`![背景图](${String(_.background).trim()})
{: custom-slides-role="background" }`;fe=fe?`${F}

${fe}`:F}$=X?`${fe}

${X}`:fe}const Se=hk($);O[st]&&Se.push(O[st]),O[Rt]&&Se.push(O[Rt]);for(const fe of Se)A.add(fe);const Ie=/<[A-Z][a-zA-Z0-9]+/.test($),_e=O[ke]||(L===1?u[ke]||"cover":"default");C[_e]=(C[_e]||0)+1,b.push({pageIndex:L++,pageAttrs:O,notes:se,rawMarkdown:$,hasVueComponent:Ie,hasStyleTag:Y,assetReferences:Se})}if(!f&&b.length>0){const N=b[0].rawMarkdown.match(/^#\s+(.+)$/m);N&&(f=N[1].trim())}w&&(u["custom-slides-custom-css"]=w);let z=b.map(N=>`---

${N.rawMarkdown}`).join(`

`);return z.trimStart().startsWith("---")||(z=`---

${z.trimStart()}`),{docTitle:f||"Slidev 演示文稿",docRootAttrs:u,slides:b,totalSlides:b.length,stats:{totalNotes:v,totalVClicks:k,totalShikiHighlights:S,totalSlots:D,discoveredAssets:Array.from(A),layoutDistribution:C},flattenedMarkdown:z,customCss:w}}function hk(e){const t=[],i=/!\[.*?\]\((.*?)\)/g;let n;for(;(n=i.exec(e))!==null;){const o=n[1].split(/\s+/)[0].trim();o&&t.push(o)}const s=/<(?:img|video|source|audio)\b[^>]*src=["'](.*?)["']/gi;for(;(n=s.exec(e))!==null;){const o=n[1].trim();o&&t.push(o)}return t}function ac(e){if(!e)return!1;const t=String(e.type||"").toLowerCase(),i=String(e.markdown||"").trim(),n=String(e.content||"").trim();return t==="tb"||t==="thematic-break"||t==="nodethematicbreak"||i==="---"||i==="***"||n==="---"||n==="***"}function mk(e){return(e.trim()||"Slidev 演示文稿").replace(/[\\/:*?"<>|]/g,"_")}async function gk(e,t,i=Fe){const n=e.filter(ac);let s=0;if(n.length>=t.length)for(let o=0;o<t.length;o++){const a=t[o],r=n[o];r&&r.id&&Object.keys(a.pageAttrs||{}).length>0&&(await i(r.id,a.pageAttrs),s++)}else for(let o=1;o<t.length;o++){const a=t[o],r=n[o-1];r&&r.id&&Object.keys(a.pageAttrs||{}).length>0&&(await i(r.id,a.pageAttrs),s++)}return s}async function vk(e,t=Fe){let i=!1,n=0;for(const s of e){if(ac(s)){i=!1;continue}const o=(s.markdown||s.content||"").trim();if(o==="::right::"||o.startsWith("::right::")){i=!0;continue}i&&s.id&&(await t(s.id,{[Me]:"right"}).catch(()=>{}),n++)}return n}async function bk(e,t,i=ya){const n={};if(!t||t.length===0)return n;const s=[];for(const o of t){const a=new File([o.data],o.fileName,{type:"application/octet-stream"});s.push(a)}try{const o=await i("/data/assets",s);if(o!=null&&o.succMap)for(const[a,r]of Object.entries(o.succMap))n[a]=String(r)}catch(o){console.warn("上传本地静态资产失败，保留原路径:",o)}return Object.keys(n).length>0&&ck(e,n),n}async function yk(e){var v;const{presentation:t,notebookId:i,docTitle:n,extractedAssets:s=[],uploadAssets:o=!0,autoPreview:a=!0,plugin:r,api:l={}}=e,c=l.uploadFn||ya,d=l.createDocFn||ud,p=l.setAttrsFn||Fe,u=l.getChildBlocksFn||Yn,f=l.openTabFn||ce.openTab,w=l.showMessageFn||ce.showMessage;o&&s.length>0&&await bk(t,s,c);const m=mk(n),y=`/${m}`,b=await d(i,y,t.flattenedMarkdown);if(!b)throw new Error("思源内核创建文档失败，未返回有效 DocumentId");try{const k=((v=t.slides[0])==null?void 0:v.pageAttrs)||{};await p(b,{...k,...t.docRootAttrs});const S=await u(b).catch(()=>[]);Array.isArray(S)&&S.length>0&&(await gk(S,t.slides,p),await vk(S,p))}catch(k){console.warn("[SlidesImport] 版式属性回填阶段遇到警告:",k),w(`⚠️ 文档已创建(${m})，但部分版式属性回填未完全完成: ${k.message||String(k)}`,6e3)}return w(`🎉 成功导入 Slidev 演示文档《${m}》！`),a&&r&&(r.currentDocId=b,await f({app:r.app,doc:{id:b}}),r.openBottomPreviewTab&&r.openBottomPreviewTab()),b}function kk(e){const t=ge("file"),i=ge(!1),n=ge(!1),s=ge(""),o=ge(null),a=ge(null),r=ge(""),l=ge(0),c=ge(""),d=ge([]),p=ge(null),u=ge(""),f=ge([]),w=ge(""),m=ge(!0),y=ge(!0),b=ge(!0),v=ge(!0),k=ye(()=>{const $=l.value;if($===0)return"0 B";const T=1024,P=["B","KB","MB","GB"],se=Math.floor(Math.log($)/Math.log(T));return`${($/T**se).toFixed(1)} ${P[se]}`}),S=ye(()=>{var $;return(($=p.value)==null?void 0:$.docRootAttrs["custom-slides-theme"])||"default"}),D=ye(()=>{var $;return d.value.length>0?d.value.length:(($=p.value)==null?void 0:$.stats.discoveredAssets.length)||0}),A=ye(()=>{var T;const $=((T=p.value)==null?void 0:T.stats.layoutDistribution)||{};return Object.entries($).map(([P,se])=>({name:P,count:se}))});async function C($=dd){try{const T=await $();T!=null&&T.notebooks&&Array.isArray(T.notebooks)&&(f.value=T.notebooks.filter(P=>!P.closed),f.value.length>0&&!w.value&&(w.value=f.value[0].id))}catch(T){console.warn("获取笔记本列表失败:",T)}}function L(){var $;($=o.value)==null||$.click()}function z(){a.value=null,r.value="",l.value=0,p.value=null,d.value=[],s.value=""}let N=0;async function K($){const T=++N;s.value="",a.value=$,r.value=$.name,l.value=$.size;try{if($.name.toLowerCase().endsWith(".zip")){const se=await $.arrayBuffer();if(T!==N)return;const V=await lk(se);if(T!==N)return;if(!V.entryMarkdown){s.value="未在 Zip 压缩包中找到 slides.md 或任何有效的 Markdown 入口文件";return}d.value=V.assets;const Y=vs(V.entryMarkdown,{stripNotesFromMarkdown:y.value,cleanHtmlToMarkdown:m.value,cleanSlots:!1,virtualFiles:V.virtualFiles});if(T!==N)return;p.value=Y,u.value=Y.docTitle||$.name.replace(/\.zip$/i,"")}else{const se=await $.text();if(T!==N)return;d.value=[];const V=$.path||"",Y=V?V.replace(/[\\/][^\\/]+$/,""):"",le=vs(se,{stripNotesFromMarkdown:y.value,cleanHtmlToMarkdown:m.value,cleanSlots:!1,baseDir:Y||void 0});if(T!==N)return;p.value=le,u.value=le.docTitle||$.name.replace(/\.md$/i,"")}}catch(P){if(T!==N)return;console.error("解析文件失败:",P),s.value=`解析文件失败: ${P.message||String(P)}`}}function _(){if(s.value="",!c.value.trim()){p.value=null;return}try{const $=vs(c.value,{stripNotesFromMarkdown:y.value,cleanHtmlToMarkdown:m.value,cleanSlots:!1});p.value=$,u.value=$.docTitle||"Slidev 演示文稿"}catch($){s.value=`解析 Markdown 源码失败: ${$.message||String($)}`}}async function U(){a.value?await K(a.value):c.value&&_()}async function x($){const T=$.target;T.files&&T.files[0]&&await K(T.files[0])}async function q($){var T;i.value=!1,(T=$.dataTransfer)!=null&&T.files&&$.dataTransfer.files[0]&&await K($.dataTransfer.files[0])}async function O($=e){if(p.value){if(!w.value&&f.value.length>0&&(w.value=f.value[0].id),!w.value){s.value="请先选择目标笔记本";return}n.value=!0,s.value="";try{return await yk({presentation:p.value,notebookId:w.value,docTitle:u.value,extractedAssets:d.value,uploadAssets:b.value,autoPreview:v.value,plugin:$})}catch(T){console.error("导入 Slidev 演示失败:",T),s.value=`导入执行失败: ${T.message||String(T)}`}finally{n.value=!1}}}return{inputMode:t,isDragging:i,isImporting:n,errorMessage:s,fileInputRef:o,selectedFile:a,selectedFileName:r,selectedFileSize:l,rawMarkdownText:c,extractedAssets:d,parsedPresentation:p,customDocTitle:u,notebooks:f,selectedNotebookId:w,optCleanHtml:m,optStripNotes:y,optUploadAssets:b,optAutoPreview:v,formattedFileSize:k,currentTheme:S,extractedAssetsCount:D,layoutChips:A,fetchNotebooks:C,triggerFileInput:L,clearFile:z,processFile:K,onFileSelected:x,onFileDrop:q,onTextChange:_,reprocessCurrentInput:U,handleConfirmImport:O}}const wk={class:"spm-import-dialog"},xk={class:"spm-tabs-header"},Sk={class:"spm-dialog-body"},Ck={key:0,class:"spm-file-section"},_k={key:0,class:"spm-dropzone-prompt"},$k={class:"spm-dropzone-icon"},Ik={key:1,class:"spm-dropzone-active"},Mk={class:"spm-file-badge"},Tk={class:"spm-file-size"},Ek={key:1,class:"spm-text-section"},Ak={key:2,class:"spm-error-banner"},Bk={key:3,class:"spm-preview-card"},Dk={class:"spm-preview-card__header"},Lk={style:{display:"inline-flex","align-items":"center",gap:"4px"}},Pk={class:"spm-config-grid"},Ok={class:"spm-form-item"},Rk={class:"spm-form-item"},Nk=["value"],zk={class:"spm-stats-grid"},Hk={class:"spm-stat-box"},Fk={class:"spm-stat-value"},jk={class:"spm-stat-box"},Wk={class:"spm-stat-value"},Uk={class:"spm-stat-box"},Vk={class:"spm-stat-value"},Gk={class:"spm-stat-box"},Kk={class:"spm-stat-value"},qk={key:0,class:"spm-chips-row"},Yk={class:"spm-options-group"},Zk={class:"spm-checkbox-label"},Jk={class:"spm-checkbox-label"},Xk={class:"spm-checkbox-label"},Qk={class:"spm-checkbox-label"},ew={class:"spm-dialog-footer"},tw=["disabled"],iw=["disabled"],nw={key:0,style:{display:"inline-flex","align-items":"center",gap:"4px"}},sw={key:1,style:{display:"inline-flex","align-items":"center",gap:"4px"}},ow=Dt({__name:"SlidesImportDialog",emits:["close","success"],setup(e,{emit:t}){const i=t,n=zt("plugin"),{inputMode:s,isDragging:o,isImporting:a,errorMessage:r,fileInputRef:l,selectedFileName:c,rawMarkdownText:d,extractedAssetsCount:p,parsedPresentation:u,customDocTitle:f,notebooks:w,selectedNotebookId:m,optCleanHtml:y,optStripNotes:b,optUploadAssets:v,optAutoPreview:k,formattedFileSize:S,currentTheme:D,layoutChips:A,fetchNotebooks:C,triggerFileInput:L,clearFile:z,onFileSelected:N,onFileDrop:K,onTextChange:_,reprocessCurrentInput:U,handleConfirmImport:x}=kk(n);vn(async()=>{await C()});async function q(){const $=await x();$&&(i("success",{docId:$}),i("close"))}function O(){i("close")}return($,T)=>(J(),ee("div",{class:"spm-modal-overlay",onClick:Zt(O,["self"])},[h("div",wk,[h("div",{class:"spm-dialog-header"},[T[18]||(T[18]=h("div",{class:"spm-dialog-title"},[h("svg",{class:"spm-dialog-icon","aria-hidden":"true"},[h("use",{"xlink:href":"#iconSlides"})]),h("span",null,"导入 Slidev 演示文档")],-1)),h("button",{class:"spm-close-btn",title:"关闭",onClick:O},"✕")]),h("div",xk,[h("button",{class:Ce(["spm-tab-btn",{active:he(s)==="file"}]),onClick:T[0]||(T[0]=P=>s.value="file")},[re(de,{name:"package"}),T[19]||(T[19]=h("span",null,"文件 / 压缩包导入 (.zip / .md)",-1))],2),h("button",{class:Ce(["spm-tab-btn",{active:he(s)==="text"}]),onClick:T[1]||(T[1]=P=>s.value="text")},[re(de,{name:"notes"}),T[20]||(T[20]=h("span",null,"粘贴 Markdown 源码",-1))],2)]),h("div",Sk,[he(s)==="file"?(J(),ee("div",Ck,[h("div",{class:Ce(["spm-dropzone",{dragover:he(o),"has-file":!!he(c)}]),onDragover:T[4]||(T[4]=Zt(P=>o.value=!0,["prevent"])),onDragleave:T[5]||(T[5]=Zt(P=>o.value=!1,["prevent"])),onDrop:T[6]||(T[6]=Zt((...P)=>he(K)&&he(K)(...P),["prevent"])),onClick:T[7]||(T[7]=(...P)=>he(L)&&he(L)(...P))},[h("input",{ref_key:"fileInputRef",ref:l,type:"file",accept:".zip,.md",class:"spm-hidden-input",onChange:T[2]||(T[2]=(...P)=>he(N)&&he(N)(...P))},null,544),he(c)?(J(),ee("div",Ik,[h("span",Mk,[re(de,{name:"notes"}),$t(" "+we(he(c)),1)]),h("span",Tk,"("+we(he(S))+")",1),h("button",{class:"spm-btn-text",onClick:T[3]||(T[3]=Zt((...P)=>he(z)&&he(z)(...P),["stop"]))},"更换文件")])):(J(),ee("div",_k,[h("span",$k,[re(de,{name:"folder",style:{"font-size":"32px"}})]),T[21]||(T[21]=h("p",{class:"spm-dropzone-text"},"点击选择文件，或直接拖拽文件至此处",-1)),T[22]||(T[22]=h("p",{class:"spm-dropzone-hint"},[$t(" 支持 Slidev 完整工程 "),h("strong",null,".zip"),$t("（自动解包 public/ 静态素材）或单文件 "),h("strong",null,".md")],-1))]))],34)])):(J(),ee("div",Ek,[Ot(h("textarea",{"onUpdate:modelValue":T[8]||(T[8]=P=>tt(d)?d.value=P:null),class:"spm-textarea spm-source-editor",rows:"8",placeholder:"在此直接粘贴包含 Frontmatter 的 Slidev slides.md 源码...",onInput:T[9]||(T[9]=(...P)=>he(_)&&he(_)(...P))},null,544),[[Po,he(d)]])])),he(r)?(J(),ee("div",Ak," ⚠️ "+we(he(r)),1)):Te("",!0),he(u)?(J(),ee("div",Bk,[h("div",Dk,[h("span",Lk,[re(de,{name:"sparkles"}),T[23]||(T[23]=$t(" 演示解析摘要",-1))]),T[24]||(T[24]=h("span",{class:"spm-badge-success"},"预检就绪",-1))]),h("div",Pk,[h("div",Ok,[T[25]||(T[25]=h("label",{class:"spm-form-label"},"笔记文档标题",-1)),Ot(h("input",{"onUpdate:modelValue":T[10]||(T[10]=P=>tt(f)?f.value=P:null),class:"spm-input",placeholder:"思源新文档标题"},null,512),[[Po,he(f)]])]),h("div",Rk,[T[26]||(T[26]=h("label",{class:"spm-form-label"},"存放目标笔记本",-1)),Ot(h("select",{"onUpdate:modelValue":T[11]||(T[11]=P=>tt(m)?m.value=P:null),class:"spm-select"},[(J(!0),ee(Xe,null,xt(he(w),P=>(J(),ee("option",{key:P.id,value:P.id},we(P.name),9,Nk))),128))],512),[[Of,he(m)]])])]),h("div",zk,[h("div",Hk,[h("span",Fk,we(he(u).totalSlides),1),T[27]||(T[27]=h("span",{class:"spm-stat-label"},"幻灯片页数",-1))]),h("div",jk,[h("span",Wk,we(he(D)),1),T[28]||(T[28]=h("span",{class:"spm-stat-label"},"演示主题",-1))]),h("div",Uk,[h("span",Vk,we(he(u).stats.totalNotes),1),T[29]||(T[29]=h("span",{class:"spm-stat-label"},"演讲者提词",-1))]),h("div",Gk,[h("span",Kk,we(he(p)),1),T[30]||(T[30]=h("span",{class:"spm-stat-label"},"关联本地素材",-1))])]),he(A).length>0?(J(),ee("div",qk,[T[31]||(T[31]=h("span",{class:"spm-chips-label"},"页面版式分布：",-1)),(J(!0),ee(Xe,null,xt(he(A),P=>(J(),ee("span",{key:P.name,class:"spm-chip-badge"},we(P.name)+": "+we(P.count),1))),128))])):Te("",!0),h("div",Yk,[h("label",Zk,[Ot(h("input",{"onUpdate:modelValue":T[12]||(T[12]=P=>tt(y)?y.value=P:null),type:"checkbox",onChange:T[13]||(T[13]=(...P)=>he(U)&&he(U)(...P))},null,544),[[as,he(y)]]),T[32]||(T[32]=h("span",null,"智能剥离展示型 HTML 容器为干净原生的 Markdown 笔记块",-1))]),h("label",Jk,[Ot(h("input",{"onUpdate:modelValue":T[14]||(T[14]=P=>tt(b)?b.value=P:null),type:"checkbox",onChange:T[15]||(T[15]=(...P)=>he(U)&&he(U)(...P))},null,544),[[as,he(b)]]),T[33]||(T[33]=h("span",null,"提取演讲者提词到块属性并保持正文笔记清爽",-1))]),h("label",Xk,[Ot(h("input",{"onUpdate:modelValue":T[16]||(T[16]=P=>tt(v)?v.value=P:null),type:"checkbox"},null,512),[[as,he(v)]]),T[34]||(T[34]=h("span",null,"自动上传关联素材至思源资产库并重写路径 (assets/...)",-1))]),h("label",Qk,[Ot(h("input",{"onUpdate:modelValue":T[17]||(T[17]=P=>tt(k)?k.value=P:null),type:"checkbox"},null,512),[[as,he(k)]]),T[35]||(T[35]=h("span",null,"导入后自动打开新文档并开启下方分屏放映预览",-1))])])])):Te("",!0)]),h("div",ew,[h("button",{class:"spm-btn-secondary",disabled:he(a),onClick:O}," 取消 ",8,tw),h("button",{class:"spm-btn-primary",disabled:!he(u)||he(a),onClick:q},[he(a)?(J(),ee("span",nw,[re(de,{name:"refresh"}),T[36]||(T[36]=$t(" 正在导入生成中...",-1))])):(J(),ee("span",sw,[re(de,{name:"rocket"}),T[37]||(T[37]=$t(" 确认导入思源笔记",-1))]))],8,iw)])])]))}}),rw=ii(ow,[["__scopeId","data-v-c56a3d7e"]]);function mr(e){return e?e==="NodeThematicBreak"||e==="tb"||e==="thematic-break":!1}function aw(e,t){var r;if(!e||e.length===0)return null;const i=t.activeBlockId||"",n=t.currentTopBlockId||i,s=t.currentPageDividerId||"",o=t.activeBlockType||"";if(mr(o)&&i){let l=e.find(c=>c.startBlockId===i);if(l||(l=e.find(c=>{var d,p;return((p=(d=c.blocks)==null?void 0:d[0])==null?void 0:p.id)===i}),l)||(l=e.find(c=>{var d;return(d=c.allBlockIds)==null?void 0:d.includes(i)}),l))return l}if(s){let l=e.find(c=>c.startBlockId===s);if(l||(l=e.find(c=>{var d,p;return((p=(d=c.blocks)==null?void 0:d[0])==null?void 0:p.id)===s}),l))return l}if(i){let l=e.find(d=>d.startBlockId===i);if(l||(l=e.find(d=>{var p,u;return((p=d.blocks)==null?void 0:p.some(f=>f.id===i))||((u=d.allBlockIds)==null?void 0:u.includes(i))}),l)||n&&n!==i&&(l=e.find(d=>{var p,u;return((p=d.blocks)==null?void 0:p.some(f=>f.id===n))||((u=d.allBlockIds)==null?void 0:u.includes(n))}),l)||(l=e.find(d=>{var p;return(p=d.noteBlocks)==null?void 0:p.some(u=>u.id===i||u.id===n)}),l))return l;const c=(r=t.activeBlockAttrs)==null?void 0:r[Me];if(c&&["col-1","col-2","col-3"].includes(c)&&(l=e.find(d=>{var p,u;return((p=d.frontmatter)==null?void 0:p.layout)==="three-cols-header"||((u=d.blocks)==null?void 0:u.some(f=>f.slot==="col-1"||f.slot==="col-2"||f.slot==="col-3"))}),l))return l}return e[0]||null}function et(e,t){var s;if(typeof document>"u"||!e)return;const i=(s=globalThis.CSS)!=null&&s.escape?globalThis.CSS.escape(e):e.replace(/"/g,'\\"'),n=document.querySelectorAll(`[data-node-id="${i}"]`);!n||n.length===0||n.forEach(o=>{for(const[a,r]of Object.entries(t))r!=null&&r!==""?o.setAttribute(a,String(r)):o.removeAttribute(a)})}function lw(e){if(typeof document>"u")return;const t=`.protyle-wysiwyg [${ke}], .protyle-wysiwyg [${Ze}], .protyle-wysiwyg [custom-slides-layout], .protyle-wysiwyg [custom-slides-role]`,i=document.querySelectorAll(t);!i||i.length===0||i.forEach(n=>{const s=n.getAttribute("data-node-id");if(!s){n.removeAttribute(ke),n.removeAttribute("custom-slides-layout"),n.removeAttribute(Ze),n.removeAttribute("custom-slides-role");return}const o=e.get(s),a=(o==null?void 0:o[ke])||(o==null?void 0:o["custom-slides-layout"])||"",r=n.getAttribute(ke)||n.getAttribute("custom-slides-layout");r&&r!==a&&(a?n.setAttribute(ke,a):(n.removeAttribute(ke),n.removeAttribute("custom-slides-layout")));const l=(o==null?void 0:o[Ze])||(o==null?void 0:o["custom-slides-role"])||"",c=n.getAttribute(Ze)||n.getAttribute("custom-slides-role");c&&c!==l&&(l?n.setAttribute(Ze,l):(n.removeAttribute(Ze),n.removeAttribute("custom-slides-role")))})}function cw(e,t){if(!t)return!1;if(e===t||typeof document>"u")return!0;const i=document.querySelector(`.protyle-wysiwyg [data-node-id="${t}"]`)||document.querySelector(`[data-node-id="${t}"]`);if(!i)return!1;const n=i.querySelector(":scope > [data-node-id], :scope > div > [data-node-id]");return(n==null?void 0:n.getAttribute("data-node-id"))===e}function dw(e){let t=null;function i(c="已同步"){e.saveStatus.value=c,t&&(typeof window<"u"?window.clearTimeout(t):clearTimeout(t));const d=()=>{e.saveStatus.value=""};typeof window<"u"?t=window.setTimeout(d,1200):t=setTimeout(d,1200)}async function n(c){var f;const d=e.activeBlockId.value||e.currentDocId.value;if(!d)return;for(const[w,m]of Object.entries(c))e.activeBlockAttrs.value[w]=m;Le.setBlockAttrOverride(d,c),et(d,c);const p=(f=e.parentContainerId)==null?void 0:f.value,u=!!(p&&cw(d,p));if(Ne in c&&u&&p){const w=c[Ne];e.parentContainerClicks&&(e.parentContainerClicks.value=w),Le.setBlockAttrOverride(p,{[Ne]:w}),et(p,{[Ne]:w}),Fe(p,{[Ne]:w}).catch(()=>{})}if(ke in c){const w=c[ke];e.currentPageDividerLayout.value=w,e.targetSlide.value&&(e.targetSlide.value.frontmatter||(e.targetSlide.value.frontmatter={}),e.targetSlide.value.frontmatter.layout=w)}if(vt in c){const w=c[vt];e.targetSlide.value&&(e.targetSlide.value.frontmatter||(e.targetSlide.value.frontmatter={}),e.targetSlide.value.frontmatter.layoutRatio=w)}i("保存中...");try{await Fe(d,c),i("已同步"),e.plugin&&await e.plugin.compileCurrentDocument()}catch{i("同步失败")}}async function s(c,d){await n({[c]:d})}function o(){var d;return(e.activeBlockType.value==="NodeThematicBreak"||e.activeBlockType.value==="NodeThematicBreakBlock"||e.activeBlockType.value==="hr"||e.activeBlockType.value==="thematicbreak")&&e.activeBlockId.value?e.activeBlockId.value:e.currentPageDividerId.value?e.currentPageDividerId.value:(d=e.targetSlide.value)!=null&&d.startBlockId&&e.targetSlide.value.startBlockId!==e.currentDocId.value?e.targetSlide.value.startBlockId:e.currentDocId.value}async function a(c,d){const p=o();if(p){p===e.activeBlockId.value&&(e.activeBlockAttrs.value[c]=d),Le.setBlockAttrOverride(p,{[c]:d}),et(p,{[c]:d}),c===ke&&(e.currentPageDividerLayout.value=d,e.targetSlide.value&&(e.targetSlide.value.frontmatter||(e.targetSlide.value.frontmatter={}),e.targetSlide.value.frontmatter.layout=d)),c===vt&&e.targetSlide.value&&(e.targetSlide.value.frontmatter||(e.targetSlide.value.frontmatter={}),e.targetSlide.value.frontmatter.layoutRatio=d),i("保存中...");try{await Fe(p,{[c]:d}),i("已同步"),e.plugin&&await e.plugin.compileCurrentDocument()}catch{i("同步失败")}}}async function r(c,d){const p=o();if(!p)return;const u={[ke]:c,[vt]:d};p===e.activeBlockId.value&&(e.activeBlockAttrs.value[ke]=c,e.activeBlockAttrs.value[vt]=d),e.currentPageDividerLayout.value=c,Le.setBlockAttrOverride(p,u),et(p,u),e.targetSlide.value&&(e.targetSlide.value.frontmatter||(e.targetSlide.value.frontmatter={}),e.targetSlide.value.frontmatter.layout=c,e.targetSlide.value.frontmatter.layoutRatio=d),i("应用排版中...");try{await Fe(p,u),i("已应用分栏与比例"),e.plugin&&await e.plugin.compileCurrentDocument()}catch{i("应用失败")}}async function l(c,d){var u;const p=e.currentDocId.value||e.activeBlockId.value;if(p){e.activeBlockAttrs.value[c]=d,Le.setBlockAttrOverride(p,{[c]:d}),et(p,{[c]:d}),(u=e.latestDoc.value)!=null&&u.config&&(c===Nn&&(e.latestDoc.value.config.theme=d),c===zn&&(e.latestDoc.value.config.aspectRatio=d),c===Hn&&(e.latestDoc.value.config.defaultTransition=d),c===ws&&(e.latestDoc.value.config.background=d)),i("更新中...");try{await Fe(p,{[c]:d}),i("已更新"),e.plugin&&await e.plugin.compileCurrentDocument(p)}catch{i("更新失败")}}}return{triggerSaveNotice:i,saveAttrs:n,saveAttr:s,getPageTargetBlockId:o,savePageAttr:a,applyPageLayoutAndRatio:r,saveDocAttr:l}}function ma(e){const t=(e.blocks||[]).filter(o=>{const a=(o.content||o.rawMarkdown||"").trim();return a&&a!=="---"});if(t.length===0)return"本页暂无内容，建议过渡承接上下文。";const i=[],n=[];for(const o of t){const a=(o.content||o.rawMarkdown||"").trim();a&&(o.type==="h"||a.startsWith("#")?i.push(a.replace(/^#+\s*/,"")):n.push(a.slice(0,50)))}const s=[];return i.length>0&&s.push(`【核心重点】：${i.join("、")}`),n.length>0&&(s.push("【口播要点】："),n.slice(0,3).forEach((o,a)=>{s.push(`${a+1}. 讲解 ${o}`)})),s.push("【过渡提示】：注意观察听众反应，适时抛出互动提问。"),s.join(`
`)}async function lc(e,t){const i=e.blocks&&e.blocks.length>0?e.blocks.map(n=>(n.content||n.rawMarkdown||"").trim()).filter(n=>n&&n!=="---").join(`
`):(e.rawMarkdown||"").replace(/^---\s*$/gm,"").trim();if(t&&i){const n=`你是一位专业的演讲教练。请根据以下幻灯片内容，提炼出简短精炼的演讲口播提词卡（Notes），包含核心观点与口播要点，总字数在 150 字以内：
${i}`;try{const s=await t(n);if(s&&s.trim())return{notes:s.trim(),isAiGenerated:!0}}catch(s){return{notes:ma(e),isAiGenerated:!1,error:(s==null?void 0:s.message)||"AI 调用异常"}}}return{notes:ma(e),isAiGenerated:!1}}async function uw(e,t){return(await lc(e,t)).notes}function fw(e){if(!e)return!1;const t=String(e.type||"").toLowerCase();return!!(t==="callout"||t==="nodecallout"||t==="b"||t==="nodeblockquote"||String(e.markdown||"").trim().startsWith(">"))}function pw(e,t){if(!((t==null?void 0:t[qe])==="true"||(t==null?void 0:t["slides-note"])==="true"))return!1;const n=(e||"").trim();return/^>\s*\[!NOTE\]\s*(?:💡\s*)?(?:演讲备注|讲稿备注)/i.test(n)}async function hw(e,t){const n=await((t==null?void 0:t.getChildBlocksFn)||Yn)(e).catch(()=>[]);if(!Array.isArray(n)||n.length===0)return[];const s=[];let o=[];for(const r of n){if(Ki({...r,ial:{...r.ial||{},...Le.getBlockAttrOverride(r.id)||{}}})){if(s.length===0&&o.length===0)continue;s.push(o),o=[];continue}o.push(r)}s.push(o);const a=[];for(let r=0;r<s.length;r++){const l=s[r];if(!l||l.length===0)continue;let c=null;for(let w=l.length-1;w>=0;w--){const m=l[w];if(!((m.type==="p"||m.type==="NodeParagraph")&&!(m.content||"").trim()&&!(m.markdown||"").trim())){c=m;break}}if(!c||!fw(c))continue;const d=Le.getBlockAttrOverride(c.id)||{};let p={...c.ial||{},...d};if(!p[qe]&&!p["slides-note"]&&(t!=null&&t.getBlockAttrsFn)){const w=await t.getBlockAttrsFn(c.id).catch(()=>({}));p={...p,...w,...d}}let u=c.markdown||c.content||"";if(t!=null&&t.getBlockKramdownFn)try{const w=await t.getBlockKramdownFn(c.id);w!=null&&w.kramdown&&(u=w.kramdown)}catch{}if(pw(u,p))continue;const f=ur(u)||u.replace(/<[^>]+>/g,"").trim();a.push({id:c.id,pageIndex:r+1,type:c.type,sourceMarkdown:u,cleanContent:f||"在此输入本页讲稿提词..."})}return a}async function mw(e,t,i){const n=(i==null?void 0:i.updateBlockFn)||ko,s=(i==null?void 0:i.setBlockAttrsFn)||Fe,o=(i==null?void 0:i.syncDomFn)||et,r=`> [!NOTE] 💡 演讲备注
${t.split(/\r?\n/).map(l=>`> ${l}`).join(`
`)}
{: ${qe}="true"}`;await n("markdown",r,e),await s(e,{[qe]:"true"}),Le.setBlockAttrOverride(e,{[qe]:"true"}),o(e,{[qe]:"true"})}async function cc(e,t){const i=(t==null?void 0:t.showMessageFn)||ce.showMessage,n=(t==null?void 0:t.confirmFn)||ce.confirm;if(!e)return i("请先在主编辑区打开幻灯片文档"),{totalScanned:0,matchedCount:0,successCount:0,errorCount:0};const s=await hw(e,t);if(s.length===0)return i("未发现待规范化的候选讲稿块"),{totalScanned:0,matchedCount:0,successCount:0,errorCount:0};const o=s.length;return new Promise(a=>{n("识别讲稿块",`扫描检测到 ${o} 处候选讲稿块（提示块或引用块），是否确认将其规范化为标准演讲备注？`,async()=>{var c;i(`正在批量规范化 ${o} 个讲稿块...`);let r=0,l=0;for(const d of s)try{await mw(d.id,d.cleanContent,t),r++}catch(p){console.error(`[SiYuanLiveSlides] 规范化讲稿块 ${d.id} 失败:`,p),l++}(c=t==null?void 0:t.onSuccessNotice)==null||c.call(t,"已规范化讲稿"),i(`已成功识别并规范化 ${r} 个讲稿块`),t!=null&&t.compileFn&&await t.compileFn().catch(()=>{}),a({totalScanned:o,matchedCount:o,successCount:r,errorCount:l})},()=>{a({totalScanned:o,matchedCount:o,successCount:0,errorCount:0})})})}function gw(e,t){const i=ge(!1),{triggerSaveNotice:n}=t;async function s(u){var D,A,C,L,z,N,K,_;const m=`> [!NOTE] 💡 演讲备注
${(u||"在此输入本页讲稿提词...").split(/\r?\n/).map(U=>`> ${U}`).join(`
`)}
{: custom-slides-note="true"}`,y=((D=e.latestDoc.value)==null?void 0:D.slides)||[],b=e.targetSlide.value,v=b?y.findIndex(U=>U===b):-1;let k=null;if(v!==-1&&v<y.length-1){const U=y[v+1];k=await zi("markdown",m,U.startBlockId)}else{const U=((A=b==null?void 0:b.noteBlocks)==null?void 0:A.slice(-1)[0])||((C=b==null?void 0:b.blocks)==null?void 0:C.slice(-1)[0]),x=(U==null?void 0:U.id)||(b==null?void 0:b.startBlockId);x?k=await zi("markdown",m,void 0,x):k=await yo("markdown",m,e.currentDocId.value)}const S=((N=(z=(L=k==null?void 0:k[0])==null?void 0:L.doOperations)==null?void 0:z[0])==null?void 0:N.id)||((K=k==null?void 0:k[0])==null?void 0:K.id);return S&&(await Fe(S,{[qe]:"true"}),Le.setBlockAttrOverride(S,{[qe]:"true"}),Vi(S,(_=e.plugin)==null?void 0:_.app)),e.plugin&&await e.plugin.compileCurrentDocument(),S}async function o(){const u=e.activeBlockId.value;if(u)if(e.isNoteBlock.value){n("取消中...");try{await Fe(u,{[qe]:"","slides-note":""}),Le.setBlockAttrOverride(u,{[qe]:"","slides-note":""}),et(u,{[qe]:"","slides-note":""}),delete e.activeBlockAttrs.value[qe],delete e.activeBlockAttrs.value["slides-note"],n("已取消备注"),ce.showMessage("已取消讲稿备注"),e.plugin&&await e.plugin.compileCurrentDocument()}catch(f){console.error("[SiYuanLiveSlides] 取消讲稿备注失败:",f),n("取消失败"),ce.showMessage("取消讲稿备注失败")}}else{n("转换中...");try{let f=e.rawSnippet.value;try{const b=await fd(u);b!=null&&b.kramdown&&(f=b.kramdown)}catch{}const y=`> [!NOTE] 💡 演讲备注
${(ur(f)||f.replace(/<[^>]+>/g,"").trim()||"在此输入本页讲稿提词...").split(/\r?\n/).map(b=>`> ${b}`).join(`
`)}
{: custom-slides-note="true"}`;await ko("markdown",y,u),await Fe(u,{[qe]:"true"}),Le.setBlockAttrOverride(u,{[qe]:"true"}),et(u,{[qe]:"true"}),e.activeBlockAttrs.value[qe]="true",e.activeBlockType.value="NodeCallout",n("已设为讲稿备注"),ce.showMessage("已转为讲稿备注提示块（不在幻灯片中渲染）"),e.plugin&&await e.plugin.compileCurrentDocument()}catch(f){console.error("[SiYuanLiveSlides] 转换讲稿备注提示块失败:",f),n("设置失败"),ce.showMessage("转为讲稿备注提示块失败")}}}async function a(){try{await s(),ce.showMessage("已在正文末尾插入讲稿备注提示块")}catch(u){ce.showMessage("插入讲稿备注块失败"),console.error(u)}}function r(){var w;const u=e.currentSlideNoteBlockId.value;if(!u){ce.showMessage("未找到本页关联的讲稿备注块");return}Vi(u,(w=e.plugin)==null?void 0:w.app)?ce.showMessage("已在编辑区定位讲稿备注块"):ce.showMessage("定位讲稿备注块失败")}async function l(){var w;if(!e.currentDocId.value)return;const u=e.targetSlide.value||{startBlockId:e.activeBlockId.value||e.currentDocId.value,blocks:e.rawSnippet.value&&e.rawSnippet.value!=="---"?[{id:e.activeBlockId.value,type:e.activeBlockType.value,content:e.rawSnippet.value,rawMarkdown:""}]:[],rawMarkdown:e.rawSnippet.value&&e.rawSnippet.value!=="---"?e.rawSnippet.value:""};ce.showMessage("正在调用思源 AI 提炼本页讲稿提词...");const f=await lc(u,wa);if(f.notes){const m=e.currentSlideNoteBlockId.value;if(m){const y=`> [!NOTE] 💡 演讲备注
${f.notes.split(/\r?\n/).map(b=>`> ${b}`).join(`
`)}
{: custom-slides-note="true"}`;await ko("markdown",y,m),await Fe(m,{[qe]:"true"}),Le.setBlockAttrOverride(m,{[qe]:"true"}),Vi(m,(w=e.plugin)==null?void 0:w.app)}else await s(f.notes);f.isAiGenerated?ce.showMessage("思源 AI 演讲提词卡生成成功！"):ce.showMessage("未获取到思源 AI 响应，已生成预设提词卡模板",5e3),e.plugin&&await e.plugin.compileCurrentDocument()}}async function c(){var m;if(i.value)return;const u=((m=e.latestDoc.value)==null?void 0:m.slides)||[];if(u.length===0){ce.showMessage("当前文档无幻灯片页面");return}const f=u.map((y,b)=>({slide:y,idx:b})).filter(({slide:y})=>{var k;const b=Array.isArray(y.noteBlocks)&&y.noteBlocks.length>0,v=!!((k=y.notes)!=null&&k.trim());return!b&&!v});if(f.length===0){ce.showMessage("所有幻灯片页面均已存在讲稿备注块，无需追加");return}const w=f.length;ce.confirm("批量追加讲稿备注",`将在未配置讲稿的 ${w} 页末尾自动插入讲稿提示块，是否继续？`,async()=>{var b,v,k,S,D,A;if(i.value)return;i.value=!0,ce.showMessage("正在批量追加讲稿块...");let y=0;try{const z=`> [!NOTE] 💡 演讲备注
${"在此输入本页讲稿提词...".split(/\r?\n/).map(N=>`> ${N}`).join(`
`)}
{: custom-slides-note="true"}`;for(const{slide:N,idx:K}of f)try{let _=null;if(K<u.length-1){const x=u[K+1];_=await zi("markdown",z,x.startBlockId)}else{const x=((b=N==null?void 0:N.noteBlocks)==null?void 0:b.slice(-1)[0])||((v=N==null?void 0:N.blocks)==null?void 0:v.slice(-1)[0]),q=(x==null?void 0:x.id)||(N==null?void 0:N.startBlockId);q?_=await zi("markdown",z,void 0,q):_=await yo("markdown",z,e.currentDocId.value)}const U=((D=(S=(k=_==null?void 0:_[0])==null?void 0:k.doOperations)==null?void 0:S[0])==null?void 0:D.id)||((A=_==null?void 0:_[0])==null?void 0:A.id);U&&(await Fe(U,{[qe]:"true"}),Le.setBlockAttrOverride(U,{[qe]:"true"})),y++}catch(_){console.error(`[SiYuanLiveSlides] 为第 ${K+1} 页追加讲稿块失败:`,_)}e.plugin&&await e.plugin.compileCurrentDocument(),ce.showMessage(`已成功为 ${y} 页追加讲稿备注块`)}catch(C){console.error("[SiYuanLiveSlides] 批量追加讲稿块失败:",C),ce.showMessage("批量追加讲稿块时出现异常")}finally{i.value=!1}})}async function d(){var y;if(i.value)return;const u=((y=e.latestDoc.value)==null?void 0:y.slides)||[];if(u.length===0){ce.showMessage("当前文档无幻灯片页面");return}const f=[];for(const b of u)if(b.noteBlocks&&b.noteBlocks.length>0)for(const v of b.noteBlocks)v.id&&f.push({id:v.id,pageIndex:b.pageIndex});if(f.length===0){ce.showMessage("当前文档中没有讲稿备注块，无需删除");return}const w=new Set(f.map(b=>b.pageIndex)).size,m=f.length;ce.confirm("危险操作：批量删除所有讲稿块",`此操作将从正文中物理删除全部 ${m} 个讲稿备注块（涉及 ${w} 页），删除后无法撤销。是否确认继续？`,async()=>{if(i.value)return;i.value=!0,ce.showMessage("正在批量删除讲稿块...");let b=0;try{for(const v of f)try{await ka(v.id),Le.clearBlockAttrOverride(v.id),b++}catch(k){console.error(`[SiYuanLiveSlides] 删除讲稿块 ${v.id} 失败:`,k)}e.activeBlockId.value&&f.some(v=>v.id===e.activeBlockId.value)&&(delete e.activeBlockAttrs.value[qe],delete e.activeBlockAttrs.value["slides-note"]),e.plugin&&await e.plugin.compileCurrentDocument(),ce.showMessage(`已成功删除全部 ${b} 个讲稿备注块`)}catch(v){console.error("[SiYuanLiveSlides] 批量删除讲稿块失败:",v),ce.showMessage("批量删除讲稿块时出现异常")}finally{i.value=!1}})}async function p(){var f;const u=e.currentDocId.value||((f=e.plugin)==null?void 0:f.currentDocId);if(!u){ce.showMessage("请先在主编辑区打开幻灯片文档");return}if(i.value){ce.showMessage("正在批量处理中，请稍候...");return}i.value=!0;try{await cc(u,{onSuccessNotice:n,compileFn:async()=>{e.plugin&&await e.plugin.compileCurrentDocument()}})}finally{i.value=!1}}return{isBatchProcessing:i,createNoteBlockOnCurrentSlide:s,onToggleNoteBlock:o,onAddNoteBlock:a,onLocateNoteBlock:r,onGenerateNotesWithAI:l,onBatchAppendNotes:c,onBatchDeleteNotes:d,onIdentifyNotesBlocks:p}}function vw(e){if(!e)return!1;const t=String(e.type||"").toLowerCase();if(t==="h"||t==="nodeheading")return!0;const i=String(e.subType||"").toLowerCase();if(/^h[1-6]$/.test(i))return!0;const n=String(e.rawMarkdown||e.markdown||"").trim();return!!/^#{1,6}\s+/.test(n)}function bw(e){if(!e)return!1;const t=String(e.type||"").toLowerCase();return t==="i"||t==="nodelistitem"}function yw(e){const t=[],i=n=>{var s,o,a,r,l,c,d,p,u,f,w;for(const m of n){if(!m||m.isNote||((s=m.attributes)==null?void 0:s[qe])==="true"||((o=m.attributes)==null?void 0:o["slides-note"])==="true"||((a=m.ial)==null?void 0:a[qe])==="true"||((r=m.ial)==null?void 0:r["slides-note"])==="true"||m.type==="tb"||m.type==="thematic-break"||m.type==="NodeThematicBreak"||String(m.markdown||m.rawMarkdown||"").trim()==="---"||m.slot==="slot-divider-right"||String(m.rawMarkdown||m.markdown||"").trim()==="::right::")continue;if(vw(m)){t.push({id:m.id,type:m.type,isHeading:!0,currentClicks:m.clicks||((l=m.attributes)==null?void 0:l[Ne])||((c=m.ial)==null?void 0:c[Ne]),rawBlock:m});continue}if(bw(m)){t.push({id:m.id,type:m.type||"i",isHeading:!1,currentClicks:m.clicks||((d=m.attributes)==null?void 0:d[Ne])||((p=m.ial)==null?void 0:p[Ne]),rawBlock:m});continue}const y=m.children&&m.children.length>0?m.children:(u=m.rawNode)==null?void 0:u.children;if(Array.isArray(y)&&y.length>0){i(y);continue}t.push({id:m.id,type:m.type,isHeading:!1,currentClicks:m.clicks||((f=m.attributes)==null?void 0:f[Ne])||((w=m.ial)==null?void 0:w[Ne]),rawBlock:m})}};return i(e||[]),t}function kw(e){var s;if(e.pageIndex===1||((s=e.frontmatter)==null?void 0:s.layout)==="cover")return[];const t=yw(e.blocks||[]);if(t.length===0)return[];let i=-1;for(let o=0;o<t.length;o++)if(!t[o].isHeading){i=o;break}if(i===-1)return[];const n=[];for(let o=i+1;o<t.length;o++){const a=t[o];!!!(a.currentClicks&&String(a.currentClicks).trim()!=="")&&a.id&&n.push({blockId:a.id,pageIndex:e.pageIndex,targetClick:"+1"})}return n}async function ww(e,t){const n=await((t==null?void 0:t.compileDocFn)||(a=>Le.compile(a)))(e).catch(()=>null);if(!n||!Array.isArray(n.slides)||n.slides.length===0)return{totalPages:0,animatedPagesCount:0,targets:[]};const s=[],o=new Set;for(const a of n.slides){const r=kw(a);r.length>0&&(s.push(...r),o.add(a.pageIndex))}return{totalPages:n.slides.length,animatedPagesCount:o.size,targets:s}}async function dc(e,t){const i=(t==null?void 0:t.showMessageFn)||ce.showMessage,n=(t==null?void 0:t.confirmFn)||ce.confirm,s=(t==null?void 0:t.setBlockAttrsFn)||Fe,o=(t==null?void 0:t.syncDomFn)||et;if(!e)return i("请先在主编辑区打开幻灯片文档"),{totalPages:0,animatedPagesCount:0,targets:[],successCount:0,errorCount:0};const a=await ww(e,t);if(a.targets.length===0)return i("未检测到需要配置顺延动效的后续块"),{...a,successCount:0,errorCount:0};const r=a.targets.length,l=a.animatedPagesCount;return new Promise(c=>{n("智能设置动效",`扫描检测到可为 ${l} 页中的 ${r} 个后续块配置顺延 (+1) 动效，是否继续？`,async()=>{var u;i(`正在批量配置 ${r} 个后续块动效...`);let d=0,p=0;for(const f of a.targets)try{await s(f.blockId,{[Ne]:f.targetClick}),Le.setBlockAttrOverride(f.blockId,{[Ne]:f.targetClick}),o(f.blockId,{[Ne]:f.targetClick}),d++}catch(w){console.error(`[SiYuanLiveSlides] 为块 ${f.blockId} 配置动效失败:`,w),p++}(u=t==null?void 0:t.onSuccessNotice)==null||u.call(t,"已配置智能动效"),i(`已成功为 ${d} 个后续块配置顺延 (+1) 动效`),t!=null&&t.compileCurrentDocFn&&await t.compileCurrentDocFn().catch(()=>{}),c({...a,successCount:d,errorCount:p})},()=>{c({...a,successCount:0,errorCount:0})})})}function xw(e,t){const{saveAttr:i,saveAttrs:n,savePageAttr:s}=t;async function o(){(e.videoAutoplay.value?"false":"true")==="true"?(await n({[Ni]:"true",[Qi]:"true"}),e.activeBlockAttrs.value[Ni]="true",e.activeBlockAttrs.value[Qi]="true"):(await i(Ni,"false"),e.activeBlockAttrs.value[Ni]="false")}async function a(){const L=e.videoLoop.value?"false":"true";await i(xs,L)}async function r(){const L=e.videoMuted.value?"false":"true";await i(Qi,L)}async function l(){const L=e.videoControls.value?"false":"true";await i(Ss,L)}async function c(L){var U,x;const z=e.activeBlockId.value;if(!z)return;const N=e.rawSnippet.value||"",K=fi(N)||"",_=e.currentPageDividerId.value||e.currentDocId.value;if(L)if(L==="background"){const q={[Ze]:"background",[ke]:""};_&&K&&(e.pageBackground&&(e.pageBackground.value=K),await Fe(_,{[st]:K}).catch(()=>{}),Le.setBlockAttrOverride(_,{[st]:K}),et(_,{[st]:K}),e.targetSlide.value&&(e.targetSlide.value.frontmatter||(e.targetSlide.value.frontmatter={}),e.targetSlide.value.frontmatter.background=K)),await n(q)}else(L===Cs||L===_s)&&await n({[ke]:L,[Ze]:""});else{const q={[Ze]:"",[ke]:""};if(e.activeBlockAttrs.value[st]==="true"&&(q[st]=""),_&&K&&((U=e.pageBackground)==null?void 0:U.value)===K&&(e.pageBackground&&(e.pageBackground.value=""),await Fe(_,{[st]:""}).catch(()=>{}),Le.setBlockAttrOverride(_,{[st]:""}),et(_,{[st]:""}),(x=e.targetSlide.value)!=null&&x.frontmatter&&delete e.targetSlide.value.frontmatter.background),await n(q),typeof document<"u"){const O=document.querySelector(`.protyle-wysiwyg [data-node-id="${z}"]`),$=O==null?void 0:O.closest('[data-type="NodeListItem"]'),T=$==null?void 0:$.getAttribute("data-node-id");if(T&&T!==z){const P={[ke]:"",[Ze]:""};et(T,P),Le.setBlockAttrOverride(T,P),await Fe(T,P).catch(()=>{})}}}}function d(){e.elemClick.value?i(Ne,""):i(Ne,"+1")}function p(L){i(Ne,L)}function u(L){i(Xt,L)}function f(L){(e.activeBlockAttrs.value[Me]||"")===L?i(Me,""):i(Me,L)}function w(L){e.elemShikiLines.value=L,i(Gi,L)}function m(L){const z=L?L.trim():"",N=/^\d+$/.test(z)?`${z}px`:z;e.elemMaxHeight.value=N,i(Fn,N)}async function y(){const L=e.currentSlideLayout.value==="three-cols-header";await i(Me,L?"col-1":"left"),ce.showMessage(L?"已将当前块设置为第 1 栏":"已将当前块设置为双栏左栏")}async function b(){const L=e.activeBlockId.value;if(!L)return;const z={[Ne]:"",[Xt]:"",[Me]:"",[Gi]:"",[Fn]:"",[qe]:"","slides-note":"",[ke]:"",[vt]:"",[Ze]:"",[gt]:"",[st]:"",[Rt]:"",[Ni]:"",[xs]:"",[Qi]:"",[Ss]:""};if(et(L,z),await Fe(L,z),Le.clearBlockAttrOverride(L),typeof document<"u"){const N=document.querySelector(`.protyle-wysiwyg [data-node-id="${L}"]`),K=N==null?void 0:N.closest('[data-type="NodeListItem"]'),_=K==null?void 0:K.getAttribute("data-node-id");_&&_!==L&&(et(_,z),await Fe(_,z).catch(()=>{}),Le.clearBlockAttrOverride(_))}e.activeBlockAttrs.value={},e.elemShikiLines.value="",e.elemMaxHeight.value="",e.pageBackground&&(e.pageBackground.value=""),e.pageImage.value="",ce.showMessage("已清除本块演示属性"),e.plugin&&await e.plugin.compileCurrentDocument()}async function v(){if(e.activeBlockId.value)try{await zi("markdown","---",e.activeBlockId.value,void 0),ce.showMessage("已在上方插入分页符"),e.plugin&&e.plugin.compileCurrentDocument()}catch{ce.showMessage("插入分页符失败")}}async function k(){const L=e.activeBlockId.value||e.currentDocId.value;if(L)try{await zi("markdown","---",void 0,L),ce.showMessage("已在下方插入分页符"),e.plugin&&e.plugin.compileCurrentDocument()}catch{ce.showMessage("插入分页符失败")}}async function S(){if(e.activeBlockId.value)try{await ka(e.activeBlockId.value),ce.showMessage("已删除该分页符"),e.activeBlockId.value="",e.activeBlockType.value="",e.plugin&&e.plugin.compileCurrentDocument()}catch{ce.showMessage("删除失败")}}async function D(){var L,z;try{let N=null;if(typeof document<"u"){const _=e.activeBlockId.value;if(_){const U=document.querySelector(`.protyle-wysiwyg [data-node-id="${_}"]`);U&&(N=U.getAttribute("data-type")==="NodeSuperBlock"?U:U.closest('[data-type="NodeSuperBlock"]'))}if(!N){const U=e.currentPageDividerId.value||(e.activeBlockType.value==="hr"||e.activeBlockType.value==="NodeThematicBreak"?e.activeBlockId.value:"");if(U){const x=document.querySelector(`.protyle-wysiwyg [data-node-id="${U}"]`);if(x){let q=x.nextElementSibling;for(;q&&!(q.getAttribute("data-type")==="NodeThematicBreak"||(L=q.classList)!=null&&L.contains("protyle-wysiwyg__block--hr"));){const O=q.getAttribute("data-type")==="NodeSuperBlock"?q:q.querySelector('[data-type="NodeSuperBlock"]');if(O){N=O;break}q=q.nextElementSibling}}}else{const x=document.querySelector('.protyle-wysiwyg [data-type="NodeThematicBreak"], .protyle-wysiwyg .protyle-wysiwyg__block--hr'),q=Array.from(document.querySelectorAll('.protyle-wysiwyg [data-type="NodeSuperBlock"]'));for(const O of q)if(!x||O.compareDocumentPosition(x)&Node.DOCUMENT_POSITION_FOLLOWING){N=O;break}}}}const K=[];if(N){const _=Array.from(N.querySelectorAll(":scope > [data-node-id]"));for(const U of _){const x=U.getAttribute("data-node-id");x&&(K.push(x),U.removeAttribute("style"))}}else if((z=e.targetSlide.value)!=null&&z.blocks){for(const _ of e.targetSlide.value.blocks)if(_.children&&_.children.length>=2){for(const U of _.children)U.id&&K.push(U.id);break}}if(K.length>0)for(const _ of K)await Fe(_,{style:""}).catch(()=>{});await s(vt,""),ce.showMessage("已重置超级块为平均分布比例"),e.plugin&&await e.plugin.compileCurrentDocument()}catch(N){console.error("[layout-actions] resetSuperBlockWidth error:",N),ce.showMessage("重置超级块比例失败")}}async function A(){var L,z,N;try{let K=null;if(typeof document<"u"){const U=e.currentPageDividerId.value||(e.activeBlockType.value==="hr"||e.activeBlockType.value==="NodeThematicBreak"?e.activeBlockId.value:""),x=e.activeBlockId.value;let q=[];if(U){const T=document.querySelector(`.protyle-wysiwyg [data-node-id="${U}"]`);if(T){let P=T.nextElementSibling;for(;P&&!(P.getAttribute("data-type")==="NodeThematicBreak"||(L=P.classList)!=null&&L.contains("protyle-wysiwyg__block--hr"));)q.push(P),P=P.nextElementSibling}}else{const T=document.querySelector('.protyle-wysiwyg [data-type="NodeThematicBreak"], .protyle-wysiwyg .protyle-wysiwyg__block--hr'),P=Array.from(document.querySelectorAll(".protyle-wysiwyg > [data-node-id]"));for(const se of P)if(!T||se.compareDocumentPosition(T)&Node.DOCUMENT_POSITION_FOLLOWING)q.push(se);else break}const O=[];let $;for(const T of q){const P=T.getAttribute("data-type");P==="NodeHeading"&&($=T.getAttribute("data-node-id")||void 0);const se=[];P==="NodeSuperBlock"?se.push(T):se.push(...Array.from(T.querySelectorAll('[data-type="NodeSuperBlock"]')));for(const V of se){if((V.getAttribute("data-sb-layout")||"").toLowerCase()==="row")continue;const le=V.getAttribute("data-node-id")||"";let ie=[];const oe=Array.from(V.querySelectorAll('[data-type="NodeListItem"]'));if(oe.length===4&&(ie=oe.map(Se=>Se.getAttribute("data-node-id")).filter(Boolean)),ie.length!==4){const Se=Array.from(V.querySelectorAll(":scope > [data-node-id]"));Se.length===4&&(ie=Se.map(Ie=>Ie.getAttribute("data-node-id")).filter(Boolean))}ie.length===4&&O.push({sbId:le,itemIds:ie,headerId:$})}}O.length>0&&(x&&(K=O.find(T=>{if(T.sbId===x||T.itemIds.includes(x))return!0;const P=document.querySelector(`.protyle-wysiwyg [data-node-id="${T.sbId}"]`),se=document.querySelector(`.protyle-wysiwyg [data-node-id="${x}"]`);return!!(P&&se&&P.contains(se))})||null),K||(K=O[0]))}if(!K&&((z=e.targetSlide.value)!=null&&z.blocks)){const U=e.targetSlide.value,x=[];for(const O of U.blocks)O.rawNode?x.push(O.rawNode):x.push({id:O.id,type:O.type,content:O.content,markdown:O.rawMarkdown,children:O.children,ial:O.attributes||O.ial||{}});const q=Jf(x,e.activeBlockId.value);q&&q.items.length===4&&(K={sbId:q.superBlockNode.id,itemIds:q.items.map(O=>O.id),headerId:(N=q.headerNode)==null?void 0:N.id})}const _=e.currentPageDividerId.value||e.currentDocId.value;if(_&&(e.currentPageDividerLayout.value="clover",e.targetSlide.value&&(e.targetSlide.value.frontmatter||(e.targetSlide.value.frontmatter={}),e.targetSlide.value.frontmatter.layout="clover"),Le.setBlockAttrOverride(_,{[ke]:"clover"}),et(_,{[ke]:"clover"}),await Fe(_,{[ke]:"clover"}).catch(()=>{})),K&&K.itemIds.length>0){K.headerId&&(Le.setBlockAttrOverride(K.headerId,{[Me]:"header"}),et(K.headerId,{[Me]:"header"}),await Fe(K.headerId,{[Me]:"header"}).catch(()=>{}));const U=Math.min(4,K.itemIds.length);for(let x=0;x<U;x++){const q=K.itemIds[x],O=`col-${x+1}`;Le.setBlockAttrOverride(q,{[Me]:O}),et(q,{[Me]:O}),await Fe(q,{[Me]:O}).catch(()=>{})}}return ce.showMessage("已将本页版式设为四叶草（田字型）布局"),e.plugin&&await e.plugin.compileCurrentDocument(),!0}catch(K){return console.error("[layout-actions] applyCloverLayout error:",K),ce.showMessage("配置四叶草布局失败",4e3,"error"),!1}}async function C(){var z,N;const L=e.currentDocId.value||((z=e.plugin)==null?void 0:z.currentDocId);if(!L){ce.showMessage("请先在主编辑区打开幻灯片文档");return}if((N=t.isBatchProcessing)!=null&&N.value){ce.showMessage("正在批量处理中，请稍候...");return}t.isBatchProcessing&&(t.isBatchProcessing.value=!0);try{await dc(L,{onSuccessNotice:t.triggerSaveNotice,compileCurrentDocFn:async()=>{e.plugin&&await e.plugin.compileCurrentDocument()}})}finally{t.isBatchProcessing&&(t.isBatchProcessing.value=!1)}}return{onToggleVideoAutoplay:o,onToggleVideoLoop:a,onToggleVideoMuted:r,onToggleVideoControls:l,onImageRoleChange:c,toggleElemClick:d,onElemClickStepChange:p,onElemMotionChange:u,onElemSlotChange:f,onElemShikiLinesChange:w,onElemMaxHeightChange:m,onSetTwoColsContrast:y,onClearBlockAttrs:b,onInsertDividerBefore:v,onInsertDividerAfter:k,onDeleteCurrentBlock:S,resetSuperBlockWidth:D,applyCloverLayout:A,onAutoAnimateDocument:C}}function Sw(e){const{triggerSaveNotice:t,saveAttrs:i,saveAttr:n,savePageAttr:s,applyPageLayoutAndRatio:o,saveDocAttr:a}=dw(e),r=gw(e,{triggerSaveNotice:t}),l=xw(e,{saveAttr:n,saveAttrs:i,savePageAttr:s,triggerSaveNotice:t,isBatchProcessing:r.isBatchProcessing});async function c(){var b;if(!e.latestDoc.value){ce.showMessage("请先在主编辑区打开幻灯片文档");return}const f=e.latestDoc.value,w=await Mi(f,(b=e.currentDocId)==null?void 0:b.value,e.plugin),m=Yl(f,{title:w});Zl(`${w}.html`,m)&&ce.showMessage(`已开始下载单文件离线 HTML 演示包 (${w}.html)`)}function d(){if(!e.latestDoc.value){ce.showMessage("请先在主编辑区打开幻灯片文档");return}Jl(e.latestDoc.value)&&ce.showMessage("已唤起打印视窗，请在打印选项中选择「另存为 PDF」")}const p=ge(!1);async function u(){var f;if(p.value){ce.showMessage("正在导出图片中，请稍候...",2e3);return}if(!e.latestDoc.value){ce.showMessage("请先在主编辑区打开幻灯片文档");return}p.value=!0;try{ce.showMessage("正在启动后台沙箱并逐页导出幻灯片图片...");const w=e.latestDoc.value,m=await Mi(w,(f=e.currentDocId)==null?void 0:f.value,e.plugin),y=await ic(w,{title:m,onProgress:(b,v)=>{ce.showMessage(`正在导出幻灯片图片 (${b} / ${v})...`,2e3)}});y.success?ce.showMessage(`🎉 成功导出 ${y.total||0} 张幻灯片高清图片并已保存为 ${m}.zip！`,4e3):ce.showMessage(`导出图片失败：${y.error||"未知异常"}`)}finally{p.value=!1}}return{triggerSaveNotice:t,saveAttrs:i,saveAttr:n,savePageAttr:s,applyPageLayoutAndRatio:o,saveDocAttr:a,onToggleVideoAutoplay:l.onToggleVideoAutoplay,onToggleVideoLoop:l.onToggleVideoLoop,onToggleVideoMuted:l.onToggleVideoMuted,onToggleVideoControls:l.onToggleVideoControls,onImageRoleChange:l.onImageRoleChange,onToggleNoteBlock:r.onToggleNoteBlock,createNoteBlockOnCurrentSlide:r.createNoteBlockOnCurrentSlide,onAddNoteBlock:r.onAddNoteBlock,onLocateNoteBlock:r.onLocateNoteBlock,onGenerateNotesWithAI:r.onGenerateNotesWithAI,isBatchProcessing:r.isBatchProcessing,onBatchAppendNotes:r.onBatchAppendNotes,onBatchDeleteNotes:r.onBatchDeleteNotes,onIdentifyNotesBlocks:r.onIdentifyNotesBlocks,toggleElemClick:l.toggleElemClick,onElemClickStepChange:l.onElemClickStepChange,onElemMotionChange:l.onElemMotionChange,onElemSlotChange:l.onElemSlotChange,onElemShikiLinesChange:l.onElemShikiLinesChange,onElemMaxHeightChange:l.onElemMaxHeightChange,onSetTwoColsContrast:l.onSetTwoColsContrast,onClearBlockAttrs:l.onClearBlockAttrs,onInsertDividerBefore:l.onInsertDividerBefore,onInsertDividerAfter:l.onInsertDividerAfter,onDeleteCurrentBlock:l.onDeleteCurrentBlock,resetSuperBlockWidth:l.resetSuperBlockWidth,applyCloverLayout:l.applyCloverLayout,onAutoAnimateDocument:l.onAutoAnimateDocument,isExportingImages:p,onExportHtml:c,onExportPdf:d,onExportImages:u}}function Cw(e){const t=ye(()=>mr(e.activeBlockType.value));function i(n){const{attrKey:s,fallback:o,mode:a="defined"}=n,r=l=>a==="truthy"?l:l!==void 0;return ye(()=>{if(t.value){const c=e.activeBlockAttrs.value[s];if(r(c))return c}const l=e.currentPageDividerId.value||(t.value?e.activeBlockId.value:"");if(l){const c=Le.getBlockAttrOverride(l);if(r(c==null?void 0:c[s]))return c[s]}return o()})}return{isDivider:t,resolvePageAttr:i}}function _w(e){if(e.type==="h"){if(e.subType==="h1")return 1;if(e.subType==="h2")return 2;if(e.subType==="h3")return 3}const t=(e.markdown||e.content||"").trimStart();return t.startsWith("# ")?1:t.startsWith("## ")?2:t.startsWith("### ")?3:null}function $w(e,t){for(let i=t-1;i>=0;i--){const n=e[i];if(Ki(n)||(n.content||n.markdown||"").trim())return n}return null}function Iw(e,t){const i=[],n=new Set,s=6;let o=0;for(let a=0;a<e.length;a++){const r=e[a];if(Ki(r)){o=0;continue}const l=$w(e,a),c=!l||Ki(l),d=_w(r);if(d===1||d===2||d===3){if(!c&&o>0&&!n.has(r.id)){const u=d===1?"cover":"default",f=d===1?"检测到一级核心章节标题，建议作为新幻灯片封面/大章":d===2?"检测到二级分论点标题，建议开启新页":"检测到三级要点标题，建议开启新页";i.push({blockId:r.id,recommendedLayout:u,reason:f}),n.add(r.id)}o=1;continue}if(o>=s&&!c&&o>0&&!n.has(r.id)){i.push({blockId:r.id,recommendedLayout:"default",reason:"当前页已达容量上限 (避免信息超载)，建议在此分页"}),n.add(r.id),o=1;continue}o++}return i}async function uc(e){if(!e.currentDocId&&typeof document<"u"){const o=document.querySelector(".protyle-content[data-doc-id]");e.currentDocId=(o==null?void 0:o.getAttribute("data-doc-id"))||""}if(!e.currentDocId){ce.showMessage("请先打开一篇思源笔记文档");return}const t=await Yn(e.currentDocId).catch(()=>[]);if(!t||t.length===0){ce.showMessage("当前文档无内容，无需断页");return}const i=t.map(o=>({id:o.id,type:o.type,subType:o.subType,content:o.content||"",markdown:o.markdown||""})),n=Iw(i);if(n.length===0){ce.showMessage("智能分析完毕：当前文档结构合理，暂无新增分页建议");return}ce.showMessage(`智能分析完毕：发现 ${n.length} 处建议分页点，正在自动插入分页线...`);let s=0;for(const o of n)try{await zi("markdown","---",void 0,o.blockId),await Fe(o.blockId,{"custom-slides-layout":o.recommendedLayout}),s++}catch(a){console.warn("Failed to insert divider:",a)}ce.showMessage(`已成功在 ${s} 处插入分页线并重新编译`),e.compileCurrentDocument(e.currentDocId)}const Mw={class:"spm-slides-inspector"},Tw={class:"spm-inspector-topbar"},Ew={class:"spm-inspector-title"},Aw={class:"slides-icon",style:{fill:"none !important"},"aria-hidden":"true",viewBox:"0 0 24 24"},Bw={class:"spm-inspector-topbar-actions"},Dw={class:"spm-target-banner"},Lw={class:"spm-target-info"},Pw=["aria-label"],Ow={key:0,class:"spm-save-status"},Rw=["title"],Nw={class:"spm-inspector-body"},zw=Dt({__name:"SlidesInspectorDockView",setup(e,{expose:t}){const i=zt("plugin"),n=ge(!1);function s(Q){n.value=!1,c.value=Q.docId,i!=null&&i.compileCurrentDocument&&i.compileCurrentDocument(Q.docId)}const o=ge(""),a=ge(""),r=ge({}),l=ge(""),c=ge(""),d=ge(""),p=ge(""),u=ge(""),f=ge(""),w=ge(""),m=ge(""),y=ge(null),b=ge(""),v=ge("");function k(){var ve;const Q=o.value||c.value;Q&&typeof navigator<"u"&&(ve=navigator==null?void 0:navigator.clipboard)!=null&&ve.writeText&&navigator.clipboard.writeText(Q).then(()=>{v.value="已复制！",setTimeout(()=>{v.value=""},1500)}).catch(()=>{})}const S=ye(()=>mr(a.value)),D=ye(()=>a.value==="NodeCodeBlock"),A=ge(!1),C=ye(()=>{if(A.value||ze.value)return!0;const Q=l.value||"";return!!fi(Q)}),L=ye(()=>{const Q=a.value||"";if(Q==="NodeVideo"||Q==="video")return!0;const ve=l.value||"";return!!(/<video\b/i.test(ve)||/\.mp4\b/i.test(ve))}),z=ye(()=>!o.value||o.value===c.value||a.value==="doc"||a.value==="NodeDocument"),N=ye(()=>{const Q=o.value||c.value||"";return Q.length>8?Q.slice(-8):Q||"无"}),K=ye(()=>l.value?l.value.replace(/<[^>]+>/g,"").replace(/[\r\n]+/g," ").trim().slice(0,45):""),_=ye(()=>{if(S.value)return"分页符 (---)";if(z.value)return"全局文档";if(L.value)return"视频块";let Q="内容块";switch(a.value){case"NodeHeading":Q="标题块";break;case"NodeParagraph":Q="段落块";break;case"NodeCodeBlock":Q="代码块";break;case"NodeVideo":Q="视频块";break;case"NodeList":case"NodeListItem":Q="列表项";break;case"NodeBlockquote":Q="引述块";break;case"NodeTable":Q="表格块";break;case"NodeSuperBlock":case"s":case"sb":Q="超级块";break;default:Q="内容块";break}return f.value?w.value?`${w.value.replace(/^col-(\d+)$/,"第 $1 栏")} › ${Q}`:`分栏容器 › ${Q}`:Q}),U=ye(()=>S.value?"tag-divider":z.value?"tag-doc":"tag-block"),x=ye(()=>r.value[ke]||"default"),q=ye(()=>r.value[gt]||"slide-left"),O=ge(""),$=ge(""),T=ye(()=>r.value[Mn]||"inherit"),P=ye(()=>{var Q;return aw((Q=y.value)==null?void 0:Q.slides,{activeBlockId:o.value,activeBlockType:a.value,currentTopBlockId:d.value,currentPageDividerId:p.value,activeBlockAttrs:r.value})}),se=ye(()=>{var Q;return((Q=P.value)==null?void 0:Q.notes)||""}),V=ye(()=>{var Q,ve,Ae;return((Ae=(ve=(Q=P.value)==null?void 0:Q.noteBlocks)==null?void 0:ve[0])==null?void 0:Ae.id)||""}),Y=ye(()=>{var Ge,Ke,Re,ft,ts,bi;if(S.value){const it=r.value[ke]||r.value["custom-slides-layout"];if(it)return it}const Q=r.value[Me]||r.value["custom-slides-slot"];if(Q&&(["col-1","col-2","col-3"].includes(Q)||/^col-\d+$/.test(Q)))return"cols-header";if(u.value)return u.value;const ve=p.value||(S.value?o.value:"");if(ve){const it=Le.getBlockAttrOverride(ve);if(it!=null&&it[ke])return it[ke]}if(ve&&((Ge=y.value)!=null&&Ge.slides)){const it=y.value.slides.find(Yi=>Yi.startBlockId===ve);if((Ke=it==null?void 0:it.frontmatter)!=null&&Ke.layout)return it.frontmatter.layout}if((ft=(Re=P.value)==null?void 0:Re.frontmatter)!=null&&ft.layout)return P.value.frontmatter.layout;if((bi=(ts=P.value)==null?void 0:ts.blocks)!=null&&bi.some(it=>it.slot&&(["col-1","col-2","col-3"].includes(it.slot)||/^col-\d+$/.test(it.slot))))return"cols-header";const Ae=Le.getBlockAttrOverride(c.value);return Ae!=null&&Ae[ke]?Ae[ke]:"default"}),le=Cw({activeBlockId:o,activeBlockType:a,activeBlockAttrs:r,currentPageDividerId:p}),ie=le.resolvePageAttr({attrKey:vt,mode:"truthy",fallback:()=>{var Q,ve;return((ve=(Q=P.value)==null?void 0:Q.frontmatter)==null?void 0:ve.layoutRatio)||""}}),oe=le.resolvePageAttr({attrKey:tn,fallback:()=>{var Q,ve;return((ve=(Q=P.value)==null?void 0:Q.frontmatter)==null?void 0:ve.mask)||""}}),Se=le.resolvePageAttr({attrKey:Fi,fallback:()=>{var Q,ve;return((ve=(Q=P.value)==null?void 0:Q.frontmatter)==null?void 0:ve.maskRatio)||""}}),Ie=le.resolvePageAttr({attrKey:nn,fallback:()=>{var Q,ve;return((ve=(Q=P.value)==null?void 0:Q.frontmatter)==null?void 0:ve.maskStyle)||"solid"}}),_e=le.resolvePageAttr({attrKey:sn,fallback:()=>{var Q,ve;return((ve=(Q=P.value)==null?void 0:Q.frontmatter)==null?void 0:ve.maskInitial)||"hidden"}});function fe(Q){if(!Q||(Q.getAttribute("data-sb-layout")||"").toLowerCase()!=="col")return null;const Ae=Array.from(Q.querySelectorAll(":scope > [data-node-id]"));if(Ae.length<2)return null;const Ge=Ae.length,Ke=Ae.map(bi=>{const it=bi.getAttribute("style")||"",Yi=it.match(/calc\(\s*([\d.]+)%/);if(Yi)return parseFloat(Yi[1]);const kn=it.match(/(?:^|;|\s)width:\s*([\d.]+)%/i);return kn?parseFloat(kn[1]):null});let Re="",ft=!1;if(Ke.some(bi=>bi!==null)){ft=!0;const bi=Ke.reduce((Pe,pt)=>Pe+(pt||0),0),it=Ke.filter(Pe=>Pe===null).length,Yi=it>0?Math.max(0,100-bi)/it:100/Ae.length,kn=Ke.map(Pe=>Pe!==null?Pe:Yi),id=kn.reduce((Pe,pt)=>Pe+pt,0)||1,wn=kn.map(Pe=>Pe/id*100);if(wn.length===2){const[Pe]=wn;if(Pe>=48&&Pe<=52)Re="1:1";else if(Pe>=31&&Pe<=35)Re="1:2";else if(Pe>=65&&Pe<=69)Re="2:1";else if(Pe>=28&&Pe<=32)Re="3:7";else if(Pe>=68&&Pe<=72)Re="7:3";else if(Pe>=38&&Pe<=42)Re="4:6";else if(Pe>=58&&Pe<=62)Re="6:4";else{const pt=Math.round(Pe);Re=`${pt}:${100-pt}`}}else if(wn.length===3){const[Pe,pt,yi]=wn;if(Pe>=31&&Pe<=35&&pt>=31&&pt<=35&&yi>=31&&yi<=35)Re="1:1:1";else if(Pe>=23&&Pe<=27&&pt>=48&&pt<=52&&yi>=23&&yi<=27)Re="1:2:1";else if(Pe>=48&&Pe<=52&&pt>=23&&pt<=27&&yi>=23&&yi<=27)Re="2:1:1";else if(Pe>=23&&Pe<=27&&pt>=23&&pt<=27&&yi>=48&&yi<=52)Re="1:1:2";else{const kr=Math.round(Pe),wr=Math.round(pt);Re=`${kr}:${wr}:${100-kr-wr}`}}else Re=wn.map(Pe=>Math.round(Pe)).join(":")}else ft=!1,Re=Array.from({length:Ge},()=>1).join(":");const ts=Ge>=2?"cols-header":"two-cols";return{hasSuperBlock:!0,colCount:Ge,ratio:Re,isCustomWidth:ft,recommendedLayout:ts}}function X(Q){if(!(Q!=null&&Q.blocks))return null;for(const ve of Q.blocks){const Ae=ve.rawNode;if(Ae&&at(Ae)&&ei(Ae)){const Ke=bn(Ae).length,Re=dr(Ae);return{hasSuperBlock:!0,colCount:Ke,ratio:Re||Array.from({length:Ke},()=>1).join(":"),isCustomWidth:!!Re,recommendedLayout:Ke>=2?"cols-header":"two-cols"}}}return null}const pe=ye(()=>{var Q;if(typeof document<"u"){const ve=o.value;if(ve){const Ge=document.querySelector(`.protyle-wysiwyg [data-node-id="${ve}"]`);if(Ge){const Ke=Ge.getAttribute("data-type")==="NodeSuperBlock"?Ge:Ge.closest('[data-type="NodeSuperBlock"]');if(Ke){const Re=fe(Ke);if(Re)return Re}}}const Ae=p.value||(S.value?o.value:"");if(Ae){const Ge=document.querySelector(`.protyle-wysiwyg [data-node-id="${Ae}"]`);if(Ge){let Ke=Ge.nextElementSibling;for(;Ke&&!(Ke.getAttribute("data-type")==="NodeThematicBreak"||(Q=Ke.classList)!=null&&Q.contains("protyle-wysiwyg__block--hr"));){const Re=Ke.getAttribute("data-type")==="NodeSuperBlock"?Ke:Ke.querySelector('[data-type="NodeSuperBlock"]');if(Re){const ft=fe(Re);if(ft)return ft}Ke=Ke.nextElementSibling}}}else{const Ge=document.querySelector('.protyle-wysiwyg [data-type="NodeThematicBreak"], .protyle-wysiwyg .protyle-wysiwyg__block--hr'),Ke=Array.from(document.querySelectorAll('.protyle-wysiwyg [data-type="NodeSuperBlock"]'));for(const Re of Ke)if(!Ge||Re.compareDocumentPosition(Ge)&Node.DOCUMENT_POSITION_FOLLOWING){const ft=fe(Re);if(ft)return ft}}}return X(P.value)}),E=ye(()=>{var Q;return((Q=pe.value)==null?void 0:Q.ratio)||""}),F=ye(()=>{const Q=a.value||"";if(Q==="NodeSuperBlock"||Q==="s"||Q==="sb")return!0;if(typeof document<"u"&&o.value){const ve=document.querySelector(`.protyle-wysiwyg [data-node-id="${o.value}"]`);if(ve!=null&&ve.closest('[data-type="NodeSuperBlock"]'))return!0}return!1}),g=ye(()=>{var Q;return((Q=P.value)==null?void 0:Q.pageIndex)||1}),W=ye(()=>!!(r.value[qe]||r.value["slides-note"]));function j(){if(!f.value)return!1;if(o.value===f.value||typeof document>"u")return!0;const Q=document.querySelector(`.protyle-wysiwyg [data-node-id="${f.value}"]`)||document.querySelector(`[data-node-id="${f.value}"]`);if(!Q)return!1;const ve=Q.querySelector(":scope > [data-node-id], :scope > div > [data-node-id]");return(ve==null?void 0:ve.getAttribute("data-node-id"))===o.value}const M=ye(()=>{var ve;if(r.value[Ne]!==void 0)return r.value[Ne]||"";if(f.value&&j())return m.value||"";if(f.value)return"";const Q=o.value;if(Q&&((ve=P.value)!=null&&ve.blocks)){const Ae=P.value.blocks.find(Ge=>Ge.id===Q);if(Ae!=null&&Ae.clicks)return Ae.clicks}return""}),I=ye(()=>{var ve;if(r.value[Xt])return r.value[Xt];const Q=o.value;if(Q&&((ve=P.value)!=null&&ve.blocks)){const Ae=P.value.blocks.find(Ge=>Ge.id===Q);if(Ae!=null&&Ae.motion)return typeof Ae.motion=="string"?Ae.motion:JSON.stringify(Ae.motion)}return""}),R=ye(()=>{var ve;if(r.value[Me])return r.value[Me];const Q=o.value;if(Q&&((ve=P.value)!=null&&ve.blocks)){const Ae=P.value.blocks.find(Ge=>Ge.id===Q);if(Ae!=null&&Ae.slot)return Ae.slot}return""}),G=ge(""),B=ge(""),H=ye(()=>r.value[Ni]==="true"),Z=ye(()=>r.value[xs]==="true"),te=ye(()=>r.value[Qi]==="true"),ne=ye(()=>r.value[Ss]!=="false"),me=ye(()=>{var Q,ve;return((ve=(Q=y.value)==null?void 0:Q.config)==null?void 0:ve.theme)||r.value[Nn]||"default"}),$e=ye(()=>{var Q,ve;return((ve=(Q=y.value)==null?void 0:Q.config)==null?void 0:ve.aspectRatio)||r.value[zn]||"16/9"}),xe=ye(()=>{var Q,ve;return((ve=(Q=y.value)==null?void 0:Q.config)==null?void 0:ve.defaultTransition)||r.value[Hn]||"slide-left"}),De=ye(()=>{var Q,ve;return((ve=(Q=y.value)==null?void 0:Q.config)==null?void 0:ve.spacing)||r.value[xo]||"normal"}),je=ye(()=>{var Q,ve;return((ve=(Q=y.value)==null?void 0:Q.config)==null?void 0:ve.background)||r.value[ws]||""}),ze=ye(()=>{var Ke,Re;if((r.value[Ze]||r.value["slides-role"])===$a||r.value[st]==="true")return"background";const ve=r.value[ke]||r.value["slides-layout"];if(ve==="image-left"||ve==="image-right")return ve;const Ae=l.value||"",Ge=fi(Ae);if(Ge&&((Re=(Ke=P.value)==null?void 0:Ke.frontmatter)!=null&&Re.background)){const ft=P.value.frontmatter.background;if(ft===Ge||ft.endsWith(Ge)||Ge.endsWith(ft))return"background"}return""}),ae=ye(()=>!!(r.value[Ne]||r.value[Xt]||r.value[Me]||r.value[Gi]||r.value[qe]||r.value["slides-note"]||r.value[Ze]||r.value[ke]||r.value[Ni]||r.value[xs]||r.value[Qi]||r.value[Ss])),{saveAttr:ue,savePageAttr:Oe,applyPageLayoutAndRatio:He,applyCloverLayout:We,resetSuperBlockWidth:lt,saveDocAttr:Et,onToggleVideoAutoplay:Zs,onToggleVideoLoop:Js,onToggleVideoMuted:es,onToggleVideoControls:Ai,onImageRoleChange:qi,onToggleNoteBlock:gc,onAddNoteBlock:vc,onLocateNoteBlock:bc,onGenerateNotesWithAI:yc,isBatchProcessing:gr,onBatchAppendNotes:kc,onBatchDeleteNotes:wc,onIdentifyNotesBlocks:xc,onAutoAnimateDocument:Sc,toggleElemClick:Cc,onElemClickStepChange:_c,onElemMotionChange:$c,onElemSlotChange:Ic,onElemShikiLinesChange:Mc,onElemMaxHeightChange:Tc,onSetTwoColsContrast:Ec,onClearBlockAttrs:Ac,onInsertDividerBefore:Bc,onInsertDividerAfter:vr,onDeleteCurrentBlock:Dc,onExportHtml:Lc,onExportPdf:Pc,onExportImages:Oc,isExportingImages:Rc}=Sw({activeBlockId:o,activeBlockType:a,activeBlockAttrs:r,rawSnippet:l,currentDocId:c,currentPageDividerId:p,currentPageDividerLayout:u,parentContainerId:f,parentContainerClicks:m,latestDoc:y,targetSlide:P,currentSlideNoteBlockId:V,currentSlideLayout:Y,isNoteBlock:W,elemClick:M,videoAutoplay:H,videoLoop:Z,videoMuted:te,videoControls:ne,pageBackground:O,pageImage:$,elemShikiLines:G,elemMaxHeight:B,saveStatus:b,plugin:i});async function Nc(Q){if(Q==="clover"){if(!await We())return}else Oe(ke,Q)}function zc(Q){Oe(vt,Q)}async function Hc(Q){await Oe(tn,Q),(Q==="clockwise"||Q==="counter-clockwise"||Q==="cw"||Q==="ccw")&&(!Se.value||Se.value==="1:1")&&await Oe(Fi,"1:1:1:1")}function Fc(Q){Oe(Fi,Q)}function jc(Q){Oe(nn,Q)}function Wc(Q){Oe(sn,Q)}function br(Q){if(!Q)return;const ve=Q.recommendedLayout||(Q.colCount&&Q.colCount>=2?"cols-header":"two-cols"),Ae=Q.ratio||(Q.colCount?Array(Q.colCount).fill(1).join(":"):"1:1");He(ve,Ae)}function Uc(Q){Oe(vt,Q)}async function Vc(){await lt()}function Gc(Q){ue(gt,Q)}function Kc(Q){$.value=Q,ue(Rt,Q)}function qc(Q){ue(Mn,Q==="inherit"?"":Q)}function Yc(Q){Et(Nn,Q)}function Zc(Q){Et(ws,Q)}function Jc(Q){Et(zn,Q)}function Xc(Q){Et(Hn,Q)}function Qc(Q){Et(xo,Q)}function yr(){i!=null&&i.openBottomPreviewTab&&i.openBottomPreviewTab()}function ed(){i!=null&&i.openPresenterTab&&i.openPresenterTab()}function td(){i&&It("aiScript")&&uc(i)}return t({setActiveBlock(Q){o.value=Q.id,a.value=Q.type,r.value={...Q.attrs},l.value=Q.content||Q.markdown||"",d.value=Q.topBlockId||Q.id,p.value=Q.pageDividerId||"",u.value=Q.pageDividerLayout||"",f.value=Q.parentContainerId||"",w.value=Q.parentContainerSlot||"",m.value=Q.parentContainerClicks||"",Q.rootId?c.value=Q.rootId:(Q.type==="doc"||Q.type==="NodeDocument")&&Q.id&&(c.value=Q.id),O.value=Q.attrs[st]||"",$.value=Q.attrs[Rt]||"",G.value=Q.attrs[Gi]||"",B.value=Q.attrs[Fn]||"",A.value=!!Q.isImage},updateDocument(Q){y.value=Q,c.value=Q.docId},openImportDialog(){n.value=!0},setCurrentDocId(Q){c.value=Q}}),(Q,ve)=>(J(),ee("div",Mw,[h("div",Tw,[h("div",Ew,[(J(),ee("svg",Aw,[...ve[2]||(ve[2]=[h("rect",{x:"2",y:"3",width:"20",height:"14",rx:"2"},null,-1),h("line",{x1:"8",y1:"21",x2:"16",y2:"21"},null,-1),h("line",{x1:"12",y1:"17",x2:"12",y2:"21"},null,-1)])])),ve[3]||(ve[3]=h("span",null,"演示配置",-1))]),h("div",Bw,[he(It)("import")?(J(),ee("button",{key:0,class:"spm-icon-btn b3-tooltips b3-tooltips__sw","aria-label":"导入 Slidev 演示文档 (.md / .zip)",onClick:ve[0]||(ve[0]=Ae=>n.value=!0)},[re(de,{name:"import"}),ve[4]||(ve[4]=h("span",null,"导入",-1))])):Te("",!0),h("button",{class:"spm-icon-btn is-primary b3-tooltips b3-tooltips__sw","aria-label":"在下方分屏开启幻灯片预览 (Alt+P)",onClick:yr},[re(de,{name:"split-preview"}),ve[5]||(ve[5]=h("span",null,"分屏预览",-1))])])]),h("div",Dw,[h("div",Lw,[h("span",{class:Ce(["spm-target-tag",U.value])},we(_.value),3),h("span",{class:"spm-target-id b3-tooltips b3-tooltips__se","aria-label":v.value||"点击复制 ID: "+(o.value||c.value),onClick:k},[re(de,{name:"copy"}),h("span",null,"#"+we(N.value),1)],8,Pw)]),b.value?(J(),ee("span",Ow,"● "+we(b.value),1)):Te("",!0)]),K.value?(J(),ee("div",{key:0,class:"spm-context-quote",title:l.value},we(K.value),9,Rw)):Te("",!0),h("div",Nw,[S.value?(J(),Jt(g1,{key:0,"page-layout":x.value,"page-layout-ratio":he(ie),"page-mask":he(oe),"page-mask-ratio":he(Se),"page-mask-style":he(Ie),"page-mask-initial":he(_e),"detected-sb-ratio":E.value,"detected-sb-info":pe.value,"page-transition":q.value,"page-spacing":T.value,"page-image":$.value,"page-notes":se.value,"page-index":g.value,"onUpdate:pageLayout":Nc,"onUpdate:pageLayoutRatio":zc,"onUpdate:pageMask":Hc,"onUpdate:pageMaskRatio":Fc,"onUpdate:pageMaskStyle":jc,"onUpdate:pageMaskInitial":Wc,onApplySuperBlockLayout:br,onResetSuperblockRatio:Vc,"onUpdate:pageTransition":Gc,"onUpdate:pageSpacing":qc,"onUpdate:pageImage":Kc,onAddNoteBlock:he(vc),onLocateNoteBlock:he(bc),onGenerateNotes:he(yc),onBatchAppendNotes:he(kc),onBatchDeleteNotes:he(wc),"is-batch-processing":he(gr),onInsertDividerAfter:he(vr),onDeleteDivider:he(Dc)},null,8,["page-layout","page-layout-ratio","page-mask","page-mask-ratio","page-mask-style","page-mask-initial","detected-sb-ratio","detected-sb-info","page-transition","page-spacing","page-image","page-notes","page-index","onAddNoteBlock","onLocateNoteBlock","onGenerateNotes","onBatchAppendNotes","onBatchDeleteNotes","is-batch-processing","onInsertDividerAfter","onDeleteDivider"])):o.value&&!z.value?(J(),Jt(e0,{key:1,"elem-click":M.value,"elem-motion":I.value,"elem-slot":R.value,"elem-shiki-lines":G.value,"elem-max-height":B.value,"is-code-block":D.value,"is-image":C.value,"is-video":L.value,"is-super-block":F.value,"detected-sb-info":pe.value,"video-autoplay":H.value,"video-loop":Z.value,"video-muted":te.value,"video-controls":ne.value,"has-block-attrs":ae.value,"is-note":W.value,"image-role":ze.value,"current-slide-layout":Y.value,"parent-elem-click":m.value,"parent-container-slot":w.value,"parent-container-id":f.value,onToggleNote:he(gc),onToggleElemClick:he(Cc),onToggleVideoAutoplay:he(Zs),onToggleVideoLoop:he(Js),onToggleVideoMuted:he(es),onToggleVideoControls:he(Ai),"onUpdate:imageRole":he(qi),"onUpdate:elemClick":he(_c),"onUpdate:elemMotion":he($c),"onUpdate:elemSlot":he(Ic),"onUpdate:elemShikiLines":he(Mc),"onUpdate:elemMaxHeight":he(Tc),onApplySuperBlockLayout:br,onApplySuperBlockRatio:Uc,onInsertDividerBefore:he(Bc),onInsertDividerAfter:he(vr),onSetTwoColsContrast:he(Ec),onClearBlockAttrs:he(Ac)},null,8,["elem-click","elem-motion","elem-slot","elem-shiki-lines","elem-max-height","is-code-block","is-image","is-video","is-super-block","detected-sb-info","video-autoplay","video-loop","video-muted","video-controls","has-block-attrs","is-note","image-role","current-slide-layout","parent-elem-click","parent-container-slot","parent-container-id","onToggleNote","onToggleElemClick","onToggleVideoAutoplay","onToggleVideoLoop","onToggleVideoMuted","onToggleVideoControls","onUpdate:imageRole","onUpdate:elemClick","onUpdate:elemMotion","onUpdate:elemSlot","onUpdate:elemShikiLines","onUpdate:elemMaxHeight","onInsertDividerBefore","onInsertDividerAfter","onSetTwoColsContrast","onClearBlockAttrs"])):(J(),Jt(ok,{key:2,"doc-theme":me.value,"doc-background":je.value,"doc-aspect-ratio":$e.value,"doc-default-transition":xe.value,"doc-spacing":De.value,"is-exporting-images":he(Rc),"is-batch-processing":he(gr),"onUpdate:docTheme":Yc,"onUpdate:docBackground":Zc,"onUpdate:docAspectRatio":Jc,"onUpdate:docDefaultTransition":Xc,"onUpdate:docSpacing":Qc,onOpenBottomPreview:yr,onOpenPresenter:ed,onIdentifyNotes:he(xc),onAutoAnimate:he(Sc),onAiAutoSplit:td,onExportHtml:he(Lc),onExportPdf:he(Pc),onExportImages:he(Oc)},null,8,["doc-theme","doc-background","doc-aspect-ratio","doc-default-transition","doc-spacing","is-exporting-images","is-batch-processing","onIdentifyNotes","onAutoAnimate","onExportHtml","onExportPdf","onExportImages"]))]),n.value&&he(It)("import")?(J(),Jt(rw,{key:1,onClose:ve[1]||(ve[1]=Ae=>n.value=!1),onSuccess:s})):Te("",!0)]))}}),Hw=2e3,Fw=600;function jw(e){return!e||typeof e.closest!="function"?!1:!!e.closest(".fn__none")}function go(e){if(!e||typeof e.isConnected=="boolean"&&!e.isConnected)return!1;if(ga(e))return!0;const t=e.firstElementChild;return!!(t&&ga(t))}function ga(e){return typeof e.getClientRects=="function"&&e.getClientRects().length>0?!0:typeof e.offsetWidth=="number"&&e.offsetWidth>0&&e.offsetHeight>0}function Ww(){const e=typeof globalThis<"u"?globalThis.IntersectionObserver:void 0;return typeof e=="function"?e:void 0}class Uw{constructor(){be(this,"consumers",new Map);be(this,"seq",0);be(this,"verifyTimer",null)}register(t,i,n){if(!i)return()=>{};const s=++this.seq,o=Ww(),a={kind:t,element:i,visible:!1,measureOnDemand:!o,observer:null,onVisible:n};return o?(a.observer=new o(r=>{var d;const l=r[r.length-1];if(!l)return;const c=l.isIntersecting&&!a.visible;a.visible=l.isIntersecting,c&&((d=a.onVisible)==null||d.call(a))}),a.observer.observe(i)):a.visible=go(i),this.consumers.set(s,a),()=>{var r;(r=a.observer)==null||r.disconnect(),this.consumers.delete(s),this.consumers.size===0&&this.stopVerifyTimer()}}clear(){var t;for(const i of this.consumers.values())(t=i.observer)==null||t.disconnect();this.consumers.clear(),this.stopVerifyTimer()}get size(){return this.consumers.size}getVisibility(){if(this.consumers.size===0)return"none";if(typeof document<"u"&&document.visibilityState==="hidden")return"hidden";for(const t of this.consumers.values())if(t.measureOnDemand?go(t.element):this.isRecordVisible(t))return"visible";return this.ensureVerifyTimer(),"hidden"}hasVisibleConsumer(){return this.getVisibility()==="visible"}isRecordVisible(t){return t.visible?!0:!jw(t.element)}ensureVerifyTimer(){if(this.verifyTimer!==null||typeof setTimeout!="function")return;let t=!1;for(const i of this.consumers.values())if(!i.measureOnDemand){t=!0;break}t&&(this.verifyTimer=setTimeout(()=>{var i;this.verifyTimer=null;for(const n of this.consumers.values())if(!n.visible&&go(n.element)){n.visible=!0,(i=n.onVisible)==null||i.call(n);return}},Hw))}stopVerifyTimer(){this.verifyTimer!==null&&(clearTimeout(this.verifyTimer),this.verifyTimer=null)}}const bs=new Uw,yn=new Qn;function fc(e,t,i){const n=()=>{var o;try{(o=i==null?void 0:i.flushDirtyCompile)==null||o.call(i)}catch{}},s=bs.register(e,t,n);return n(),s}let Ci=null,Lt=null,ys=null;function Vw(){return Lt}function Gw(e,t){Ci&&pc(),Ci=lr(Rg),Ci.provide("plugin",t),Ci.provide("sandboxBridge",yn);const i=Ci.mount(e);return Lt=i,ys=fc("preview",e,t),i}function pc(e){ys&&(ys(),ys=null),Ci&&(Ci.unmount(),Ci=null,Lt=null)}function Kw(){return Lt!==null}let _i=null,Hi=null;function qw(e,t){return _i&&hc(),_i=lr(Kv),_i.provide("plugin",t),_i.provide("sandboxBridge",yn),Hi=_i.mount(e),Hi}function hc(e){_i&&(_i.unmount(),_i=null,Hi=null)}function Yw(e){try{const t=new BroadcastChannel("siyuan-slides-sync");t.postMessage({type:"SYNC_SLIDES",slides:e.slides||[],config:e.config||{}}),t.close()}catch{}}let $i=null,Mt=null,ks=null;function Zw(e,t){$i&&mc(),$i=lr(zw),$i.provide("plugin",t),$i.provide("sandboxBridge",yn);const i=$i.mount(e);return Mt=i,ks=fc("dock",e,t),i}function mc(e){ks&&(ks(),ks=null),$i&&($i.unmount(),$i=null,Mt=null)}function Jw(e,t){Mt!=null&&Mt.updateDocument&&Mt.updateDocument(e),Lt!=null&&Lt.updateDocument?Lt.updateDocument(e,t):(yn.updateSlides(e.slides,e.config,e.fullMarkdown),Yw(e)),Hi!=null&&Hi.updateDocument&&Hi.updateDocument(e)}function jo(e){Lt!=null&&Lt.navigateToBlock?Lt.navigateToBlock(e):yn.highlightElement(e)}function Xi(e){Mt!=null&&Mt.setActiveBlock&&Mt.setActiveBlock(e)}function Xw(){return ai("import")?!1:Mt!=null&&Mt.openImportDialog?(Mt.openImportDialog(),!0):!1}const Qw=[{id:"slides-cover",name:"幻灯片 - 封面页 (Cover)",open:!0,attrs:[{key:Ri,value:"true"},{key:ke,value:"cover"},{key:gt,value:"fade"}]},{id:"slides-two-cols",name:"幻灯片 - 双栏对比 (Two Columns)",open:!0,attrs:[{key:Ri,value:"true"},{key:ke,value:"two-cols"},{key:gt,value:"slide-left"}]},{id:"slides-fact",name:"幻灯片 - 大字报与核心指标 (Fact)",open:!0,attrs:[{key:Ri,value:"true"},{key:ke,value:"fact"},{key:gt,value:"zoom"}]},{id:"slides-intro",name:"幻灯片 - 章节导引与作者 (Intro)",open:!0,attrs:[{key:Ri,value:"true"},{key:ke,value:"intro"},{key:gt,value:"slide-up"}]},{id:"slides-quote",name:"幻灯片 - 金句与强调 (Quote)",open:!0,attrs:[{key:Ri,value:"true"},{key:ke,value:"quote"},{key:gt,value:"fade"}]},{id:"slides-elem-click",name:"元素 - 顺延逐步呈现 (v-click)",open:!0,attrs:[{key:Ne,value:"+1"}]},{id:"slides-elem-click-hide",name:"元素 - 隐藏直到激活 (v-click:hide)",open:!0,attrs:[{key:Ne,value:"hide"}]},{id:"slides-elem-slot-right",name:"元素 - 双栏右栏归属 (Slot: Right)",open:!0,attrs:[{key:Me,value:"right"}]},{id:"slides-shiki-lines",name:"代码 - 逐行聚光高亮 (Shiki)",open:!0,attrs:[{key:Gi,value:"1-3"}]}];class vo{getPresetTemplates(){return Qw}buildScanSlidesBlocksSql(t="custom-slides-"){return`SELECT block_id, name, value FROM attributes WHERE name LIKE '${t}%' ORDER BY block_id ASC`}buildTransitionStatsSql(){return`SELECT value, count(1) as count FROM attributes WHERE name = '${gt}' GROUP BY value ORDER BY count DESC`}async batchUpdateTransitions(t,i,n,s){const o=`SELECT block_id FROM attributes WHERE name = '${gt}' AND value = '${t}'`,a=await n(o);let r=0;if(Array.isArray(a))for(const l of a){const c=l.block_id||l.blockId;c&&(await s(c,{[gt]:i}),r++)}return{updatedCount:r}}async batchUpdateLayout(t,i,n,s){const o=`SELECT block_id FROM attributes WHERE name = '${ke}' AND value = '${t}'`,a=await n(o);let r=0;if(Array.isArray(a))for(const l of a){const c=l.block_id||l.blockId;c&&(await s(c,{[ke]:i}),r++)}return{updatedCount:r}}exportTemplatesJson(){const t=this.getPresetTemplates();return JSON.stringify({templates:t,counter:t.length},null,2)}formatTransitionSummary(t){return!t||t.length===0?"全库目前暂无已设置即现转场效果的块":`全库即现转场分布统计：${t.map(n=>`${n.value}: ${n.count} 个`).join("，")}`}}function e2(e){if(e.addCommand({langKey:"slidesPresentation",langText:"即现: 在文档下方开启分屏演示预览",hotkey:"⌥P",enabled:()=>!0,execute:()=>{e.openBottomPreviewTab()}}),ai("import")||e.addCommand({langKey:"slidesImport",langText:"即现: 导入 Slidev 演示文档 (.md / .zip)",hotkey:"⌥I",enabled:()=>!0,execute:()=>{Xw()||ce.showMessage("请先在右侧栏打开「即现演示配置」Dock 面板以呼起导入窗口")}}),e.addCommand({langKey:"slidesInitAttrs",langText:"即现: 初始化当前文档演示属性",hotkey:"",enabled:()=>!0,execute:async()=>{if(!e.currentDocId){const t=document.querySelector(".protyle-content[data-doc-id]");e.currentDocId=(t==null?void 0:t.getAttribute("data-doc-id"))||""}e.currentDocId&&(await Fe(e.currentDocId,{"custom-slides-theme":"default","custom-slides-aspect-ratio":"16/9","custom-slides-default-transition":"slide-left"}),ce.showMessage("已为当前文档初始化即现演示属性"),e.compileCurrentDocument(e.currentDocId))}}),ai("aiScript")||e.addCommand({langKey:"slidesAiSplit",langText:"即现: 智能大纲断页建议与自动分页",hotkey:"",enabled:()=>!0,execute:()=>uc(e)}),ai("aiScript")||e.addCommand({langKey:"slidesAiNotes",langText:"即现 AI: 自动为当前文档生成演讲者提词卡 (Notes)",hotkey:"",enabled:()=>!0,execute:async()=>{var l,c,d,p;if(!e.currentDocId){const u=document.querySelector(".protyle-content[data-doc-id]");e.currentDocId=(u==null?void 0:u.getAttribute("data-doc-id"))||""}if(!e.currentDocId){ce.showMessage("请先打开一篇思源笔记文档");return}ce.showMessage("正在调用思源 AI 提炼演讲者口播提词...");const t=await Yn(e.currentDocId).catch(()=>[]),i={startBlockId:e.currentDocId,blocks:t.map(u=>({id:u.id,type:u.type,content:u.content||"",rawMarkdown:u.markdown||""})),rawMarkdown:""},o=`> [!NOTE] 💡 演讲备注
${(await uw(i,wa)).split(/\r?\n/).map(u=>`> ${u}`).join(`
`)}
{: custom-slides-note="true"}`,a=await yo("markdown",o,e.currentDocId).catch(()=>null),r=((d=(c=(l=a==null?void 0:a[0])==null?void 0:l.doOperations)==null?void 0:c[0])==null?void 0:d.id)||((p=a==null?void 0:a[0])==null?void 0:p.id);r&&(await Fe(r,{"custom-slides-note":"true"}),Le.setBlockAttrOverride(r,{"custom-slides-note":"true"}),Vi(r,e.app)),ce.showMessage("已成功生成口播提词卡并插入为正文讲稿备注块"),e.compileCurrentDocument(e.currentDocId)}}),e.addCommand({langKey:"slidesIdentifyNotes",langText:"即现演示: 识别正文讲稿块并规范化",hotkey:"",enabled:()=>!0,execute:async()=>{let t=e.currentDocId;if(!t){const i=document.querySelector(".protyle-content[data-doc-id]");t=(i==null?void 0:i.getAttribute("data-doc-id"))||"",t&&(e.currentDocId=t)}if(!t){ce.showMessage("请先在主编辑区打开幻灯片文档");return}await cc(t,{compileFn:async()=>{await e.compileCurrentDocument(t)}})}}),e.addCommand({langKey:"slidesAutoAnimate",langText:"即现演示: 智能配置演示动效",hotkey:"",enabled:()=>!0,execute:async()=>{let t=e.currentDocId;if(!t){const i=document.querySelector(".protyle-content[data-doc-id]");t=(i==null?void 0:i.getAttribute("data-doc-id"))||"",t&&(e.currentDocId=t)}if(!t){ce.showMessage("请先在主编辑区打开幻灯片文档");return}await dc(t,{compileCurrentDocFn:async()=>{await e.compileCurrentDocument(t)}})}}),e.addCommand({langKey:"slidesBatchTransitions",langText:"即现协同: 统计全库转场效果分布",hotkey:"",enabled:()=>!0,execute:async()=>{const t=new vo,i=t.buildTransitionStatsSql(),n=await un(i).catch(()=>[]),s=t.formatTransitionSummary(n||[]);ce.showMessage(s)}}),e.addCommand({langKey:"slidesExportTemplates",langText:"即现协同: 复制即现预设属性模板至剪贴板",hotkey:"",enabled:()=>!0,execute:async()=>{const i=new vo().exportTemplatesJson();typeof navigator<"u"&&navigator.clipboard?(await navigator.clipboard.writeText(i),ce.showMessage("已将即现属性模板 JSON 复制至剪贴板，可直接导入属性管家")):ce.showMessage(`已生成模板数据（请在控制台查看）：
`+i)}}),e.addCommand({langKey:"slidesBatchReplaceTransition",langText:"即现协同: 批量替换全库淡入淡出转场为滑动 (fade -> slide-left)",hotkey:"",enabled:()=>!0,execute:async()=>{const i=await new vo().batchUpdateTransitions("fade","slide-left",n=>un(n).catch(()=>[]),(n,s)=>Fe(n,s));ce.showMessage(`全库批量替换完成：已将 ${i.updatedCount} 处 fade 转场更新为 slide-left`),e.compileCurrentDocument()}}),ai("presenterMode")||e.addCommand({langKey:"slidesPresenterMode",langText:"即现: 打开双屏演讲者控制台 (Presenter Mode)",hotkey:"⌥M",enabled:()=>!0,execute:()=>{e.openPresenterTab()}}),ai("proMode")||(e.addCommand({langKey:"slidesExportCliMd",langText:"即现 Pro: 导出 Slidev 标准 slides.md 文档 (下载到本地)",hotkey:"",enabled:()=>!0,execute:async()=>{if(e.latestCompiledDoc||await e.compileCurrentDocument(),!e.latestCompiledDoc){ce.showMessage("请先打开并放映一篇思源笔记文档");return}e.cliBridge.downloadSlidesMd(e.latestCompiledDoc,`slides-${e.currentDocId||"demo"}.md`)&&ce.showMessage("已生成标准 Slidev Markdown 并触发下载，可在本地使用 npx @slidev/cli 运行")}}),e.addCommand({langKey:"slidesProbeCliDevServer",langText:"即现 Pro: 检测本地 Slidev CLI DevServer 状态 (localhost:3030)",hotkey:"",enabled:()=>!0,execute:async()=>{ce.showMessage("正在探测本地 Slidev CLI DevServer (http://localhost:3030)..."),await e.cliBridge.probeServer(1500)?ce.showMessage("🟢 本地 Slidev CLI DevServer 运行正常！可直接在浏览器访问 http://localhost:3030"):ce.showMessage("⚪ 未检测到运行中的本地 Slidev CLI DevServer (端口 3030 未开启)")}}),e.addCommand({langKey:"slidesSyncToCliWorkspace",langText:"即现 Pro: 同步 slides.md 至思源工作空间存储目录",hotkey:"",enabled:()=>!0,execute:async()=>{if(e.latestCompiledDoc||await e.compileCurrentDocument(),!e.latestCompiledDoc){ce.showMessage("请先打开并放映一篇思源笔记文档");return}const t=await e.cliBridge.syncToWorkspaceFile(e.latestCompiledDoc,"/data/storage/petal/siyuan-live-slides/slides.md",wo);t.success?ce.showMessage(`已成功同步最新 slides.md 至工作空间：${t.path}`):ce.showMessage(`同步失败：${t.error}`)}})),!ai("exportImage")){let t=!1;e.addCommand({langKey:"slidesExportImagesZip",langText:"即现: 逐页导出幻灯片为高清图片包 (ZIP)",hotkey:"",enabled:()=>!0,execute:async()=>{if(t){ce.showMessage("正在导出图片中，请稍候...",2e3);return}if(e.latestCompiledDoc||await e.compileCurrentDocument(),!e.latestCompiledDoc){ce.showMessage("请先打开并放映一篇思源笔记文档");return}t=!0;try{ce.showMessage("正在启动后台沙箱并逐页导出幻灯片图片...");const i=e.latestCompiledDoc,n=await Mi(i,e.currentDocId,e),s=await ic(i,{title:n,onProgress:(o,a)=>{ce.showMessage(`正在导出幻灯片图片 (${o} / ${a})...`,2e3)}});s.success?ce.showMessage(`🎉 成功导出 ${s.total||0} 张幻灯片高清图片并已保存为 ${n}.zip！`,4e3):ce.showMessage(`导出图片失败：${s.error||"未知异常"}`)}finally{t=!1}}})}}class t2{constructor(t=400){be(this,"entries",new Map);this.ttlMs=t}get(t,i=Date.now()){if(!t)return;const n=this.entries.get(t);if(n){if(i-n.at>this.ttlMs){this.entries.delete(t);return}return n.attrs}}set(t,i,n=Date.now()){!t||!i||this.entries.set(t,{attrs:i,at:n})}invalidate(t){t?this.entries.delete(t):this.entries.clear()}get size(){return this.entries.size}}function i2(e){const t=new Map;if(!(e!=null&&e.slides))return t;const i=n=>{for(const s of n||[])s!=null&&s.id&&s.ial&&t.set(s.id,s.ial)};for(const n of e.slides)i(n.blocks),i(n.noteBlocks);return t}class n2{constructor(t=150){be(this,"lastBlockId","");be(this,"lastAt",0);this.windowMs=t}shouldSkip(t,i=Date.now()){return t&&t===this.lastBlockId&&i-this.lastAt<this.windowMs?!0:(this.lastBlockId=t,this.lastAt=i,!1)}reset(){this.lastBlockId="",this.lastAt=0}}class s2{constructor(){be(this,"attrCache",new t2);be(this,"compiledIalIndex",{doc:null,map:new Map});be(this,"locatingLockUntil",0);be(this,"lockedTargetBlockId","");be(this,"lastKnownPageDividerId","");be(this,"lastKnownDocId","")}isLocatingLocked(t){return Date.now()<this.locatingLockUntil?!(t&&t===this.lockedTargetBlockId):!1}async resolveBlockAttrs(t,i){if(!t)return{};const n=Le.getBlockAttrOverride(t),s=this.getCompiledIal(i,t);if(n||s)return{...s||{},...n||{}};const o=this.attrCache.get(t);if(o)return o;const a=await Wo(t).catch(()=>({}))||{};return this.attrCache.set(t,a),a}getCompiledIal(t,i){if(t)return this.compiledIalIndex.doc!==t&&(this.compiledIalIndex={doc:t,map:i2(t)}),this.compiledIalIndex.map.get(i)}invalidateAttrCache(t){this.attrCache.invalidate(t)}getActiveDocumentId(){if(typeof document>"u")return"";const t=document.querySelector(".layout__wnd--active .protyle-title[data-node-id]")||document.querySelector(".item--focus .protyle-title[data-node-id]")||document.querySelector(".protyle-title[data-node-id]"),i=t==null?void 0:t.getAttribute("data-node-id");if(i)return i;const n=document.querySelector(".protyle .protyle-title[data-node-id]"),s=n==null?void 0:n.getAttribute("data-node-id");if(s)return s;const o=document.querySelector("[data-doc-id]"),a=o==null?void 0:o.getAttribute("data-doc-id");return a||""}resolveDocIdFromElement(t,i=""){const n=t.closest(".protyle-title"),s=n==null?void 0:n.getAttribute("data-node-id");if(s)return s;const o=t.closest(".protyle"),a=o==null?void 0:o.querySelector(".protyle-title"),r=a==null?void 0:a.getAttribute("data-node-id");if(r)return r;const l=t.closest("[data-doc-id]"),c=l==null?void 0:l.getAttribute("data-doc-id");if(c)return c;const d=this.getActiveDocumentId();return d||i}async switchToDocGlobalInspector(t,i){var o;if(!t)return;let n=i||"";if(!n&&typeof document<"u"){const a=document.querySelector(`.protyle-title[data-node-id="${t}"] .protyle-title__input`)||document.querySelector(`.protyle[data-doc-id="${t}"] .protyle-title__input`)||document.querySelector(".protyle-title__input");n=((o=a==null?void 0:a.innerText)==null?void 0:o.trim())||""}const s=await this.resolveBlockAttrs(t,null);Xi({id:t,rootId:t,type:"doc",content:n,attrs:s,isDivider:!1,isCode:!1}),jo(t)}handleBlockClickedFromSlide(t,i,n,s,o){var c,d,p,u;if(!t){Rn();const f=typeof o=="number"&&o>0?o:1,w=((c=s==null?void 0:s.slides)==null?void 0:c[f-1])||((d=s==null?void 0:s.slides)==null?void 0:d[0]);if(w){const m=w.startBlockId||"",y=((p=w.frontmatter)==null?void 0:p.layout)||"",b={"custom-slides-layout":y,...w.frontmatter};return Xi({id:m,rootId:n,type:"NodeThematicBreak",attrs:b,isDivider:!0,isCode:!1,isImage:!1,pageDividerId:m,pageDividerLayout:y}),this.resolveBlockAttrs(m,s).then(v=>{v&&Object.keys(v).length>0&&Xi({id:m,rootId:n,type:"NodeThematicBreak",attrs:{...b,...v},isDivider:!0,isCode:!1,isImage:!1,pageDividerId:m,pageDividerLayout:y})}),!0}else return this.switchToDocGlobalInspector(n),!0}this.lockedTargetBlockId=t,this.locatingLockUntil=Date.now()+500;const a=Vi(t,i),r=typeof document<"u"?document.querySelector(`.protyle-wysiwyg [data-node-id="${t}"]`)||document.querySelector(`[data-node-id="${t}"]`):null,l=(r==null?void 0:r.getAttribute("data-type"))||"";if(r)this.syncInspectorBlock(r,t,l,n,s);else{let f="",w="";if(s!=null&&s.slides){const m=s.slides.find(y=>{var b,v,k;return y.startBlockId===t||((b=y.blocks)==null?void 0:b.some(S=>S.id===t))||((v=y.allBlockIds)==null?void 0:v.includes(t))||((k=y.noteBlocks)==null?void 0:k.some(S=>S.id===t))});m!=null&&m.startBlockId&&(f=m.startBlockId),(u=m==null?void 0:m.frontmatter)!=null&&u.layout&&(w=m.frontmatter.layout)}this.resolveBlockAttrs(t,s).then(async m=>{if(f&&!w){const y=Le.getBlockAttrOverride(f);if(y!=null&&y[ke]||y!=null&&y["custom-slides-layout"])w=y[ke]||y["custom-slides-layout"]||"";else{const b=await this.resolveBlockAttrs(f,s);w=b[ke]||b["custom-slides-layout"]||"",b&&Object.keys(b).length>0&&Le.setBlockAttrOverride(f,b)}}Xi({id:t,rootId:n,type:l||"NodeParagraph",attrs:m||{},pageDividerId:f,pageDividerLayout:w})}).catch(()=>{})}return a}async syncInspectorBlock(t,i,n,s,o){var q,O,$,T,P,se,V,Y,le;if(this.isLocatingLocked(i))return;let a=t,r=i,l=n;const c=typeof(t==null?void 0:t.closest)=="function"?t.closest('[data-type="NodeCallout"]'):null;if(c&&c!==t){const ie=c.getAttribute("data-node-id");if(ie){const oe=await this.resolveBlockAttrs(ie,o),Se=Le.getBlockAttrOverride(ie)||{},Ie={...oe,...Se};(Ie[qe]||Ie["slides-note"])&&(a=c,r=ie,l="NodeCallout")}}const d=a.closest(".protyle-wysiwyg > [data-node-id]")||a,p=(d==null?void 0:d.getAttribute("data-node-id"))||r,u=l==="NodeThematicBreak"||l==="tb"||l==="thematic-break"||(d==null?void 0:d.getAttribute("data-type"))==="NodeThematicBreak"||(d==null?void 0:d.getAttribute("data-type"))==="tb"||!!((q=d==null?void 0:d.classList)!=null&&q.contains("hr")),f=l==="NodeCodeBlock",w=((O=a.innerText)==null?void 0:O.trim())||"",m=await this.resolveBlockAttrs(r,o),y=Le.getBlockAttrOverride(r)||{},b={...m,...y};let v="",k="";if(u)v=r,k=b[ke]||b["custom-slides-layout"]||"";else{let ie=d.previousElementSibling;for(;ie;){const oe=ie.getAttribute("data-type");if(oe==="NodeThematicBreak"||oe==="tb"||($=ie.classList)!=null&&$.contains("hr")){v=ie.getAttribute("data-node-id")||"";break}ie=ie.previousElementSibling}}if(o!=null&&o.slides){const ie=[r,p];let oe=a.parentElement;for(;oe&&!oe.classList.contains("protyle-wysiwyg");){const Ie=oe.getAttribute("data-node-id");Ie&&!ie.includes(Ie)&&ie.push(Ie),oe=oe.parentElement}const Se=o.slides.find(Ie=>{var _e,fe,X;return ie.includes(Ie.startBlockId)||((_e=Ie.blocks)==null?void 0:_e.some(pe=>ie.includes(pe.id)))||((fe=Ie.allBlockIds)==null?void 0:fe.some(pe=>ie.includes(pe)))||((X=Ie.noteBlocks)==null?void 0:X.some(pe=>ie.includes(pe.id)))});Se&&(!v&&Se.startBlockId&&(v=Se.startBlockId),!k&&((T=Se.frontmatter)!=null&&T.layout)&&(k=Se.frontmatter.layout))}if(v?(this.lastKnownDocId=s,this.lastKnownPageDividerId=v):s&&this.lastKnownDocId===s&&this.lastKnownPageDividerId&&(!d.previousElementSibling&&(((P=d.parentElement)==null?void 0:P.scrollTop)||0)===0||(v=this.lastKnownPageDividerId)),v){const ie=Le.getBlockAttrOverride(v);if(ie&&(ke in ie||"custom-slides-layout"in ie)&&(k=ie[ke]||ie["custom-slides-layout"]||""),!k&&(o!=null&&o.slides)){const oe=o.slides.find(Se=>Se.startBlockId===v);(se=oe==null?void 0:oe.frontmatter)!=null&&se.layout&&(k=oe.frontmatter.layout)}if(!k){const oe=await this.resolveBlockAttrs(v,o);k=oe[ke]||oe["custom-slides-layout"]||"",oe&&Object.keys(oe).length>0&&Le.setBlockAttrOverride(v,oe)}et(v,{[ke]:k||""})}else if(s){const ie=Le.getBlockAttrOverride(s);ie&&(ke in ie||"custom-slides-layout"in ie)?k=ie[ke]||ie["custom-slides-layout"]||"":!k&&((le=(Y=(V=o==null?void 0:o.slides)==null?void 0:V[0])==null?void 0:Y.frontmatter)!=null&&le.layout)&&(k=o.slides[0].frontmatter.layout)}const S=a.getAttribute(ke)||a.getAttribute("custom-slides-layout"),D=b[ke]||b["custom-slides-layout"]||"";S&&S!==D&&et(r,{[ke]:D});const A=a.getAttribute(Ze)||a.getAttribute("custom-slides-role"),C=b[Ze]||b["custom-slides-role"]||"";A&&A!==C&&et(r,{[Ze]:C});let L="",z="",N="";const K=a.closest('[data-type="NodeListItem"]');if(K&&K!==a){const ie=K.getAttribute("data-node-id");if(ie){L=ie;const oe=await this.resolveBlockAttrs(ie,o),Se=Le.getBlockAttrOverride(ie)||{},Ie={...oe,...Se};z=Ie[Me]||"",N=Ie[Ne]||"";const _e=Ie[ke]||Ie["custom-slides-layout"]||"",fe=K.getAttribute(ke)||K.getAttribute("custom-slides-layout");fe&&fe!==_e&&et(ie,{[ke]:_e});const X=Ie[Ze]||Ie["custom-slides-role"]||"",pe=K.getAttribute(Ze)||K.getAttribute("custom-slides-role");pe&&pe!==X&&et(ie,{[Ze]:X})}}const _=!!a.querySelector("img, span[data-type='img']"),U=(a.innerText||"").replace(/[\r\n\t\s]+/g," ").trim(),x=_&&U.length<=50;Xi({id:r,rootId:s,type:l,content:w,attrs:b,isDivider:u,isCode:f,isImage:x,topBlockId:p,pageDividerId:v,pageDividerLayout:k,parentContainerId:L,parentContainerSlot:z,parentContainerClicks:N})}patchThematicBreakTransactions(t){if((t==null?void 0:t.cmd)==="transactions"&&Array.isArray(t.data)){for(const i of t.data)if(Array.isArray(i==null?void 0:i.doOperations)){for(const n of i.doOperations)if((n==null?void 0:n.action)==="updateAttrs"&&n.id&&n.data){const s=n.data.old||{},o=n.data.new||{},a={};for(const r of Object.keys(s))r in o||(a[r]="");for(const[r,l]of Object.entries(o))a[r]=String(l??"");et(n.id,a),Le.setBlockAttrOverride(n.id,a)}}}}purgeStaleDomSlidesAttrs(t){var s,o,a;if(typeof document>"u"||!t)return;const i=new Map;if(Array.isArray(t.slides))for(const r of t.slides){if(r.startBlockId){const l=i.get(r.startBlockId)||{};(s=r.frontmatter)!=null&&s.layout&&(l[ke]=r.frontmatter.layout),i.set(r.startBlockId,l)}if(Array.isArray(r.blocks)){for(const l of r.blocks)if(l.id){const c=i.get(l.id)||{};(o=l.ial)!=null&&o[ke]&&(c[ke]=l.ial[ke]),(a=l.ial)!=null&&a[Ze]&&(c[Ze]=l.ial[Ze]),Object.keys(c).length>0&&i.set(l.id,c)}}}const n=Le.getAllAttrOverrides();for(const[r,l]of n.entries()){const c=i.get(r)||{};l[ke]!==void 0&&(c[ke]=l[ke]),l[Ze]!==void 0&&(c[Ze]=l[Ze]),i.set(r,c)}lw(i)}}const wi=new s2;class o2{constructor(){be(this,"state","IDLE");be(this,"inFlightDocId",null);be(this,"pendingDocs",new Set);be(this,"lastPendingDocId",null);be(this,"generation",0)}get currentState(){return this.state}get isRunning(){return this.state==="COMPILING"}get runningDocId(){return this.inFlightDocId}get pending(){return this.lastPendingDocId}get pendingList(){return Array.from(this.pendingDocs)}tryBegin(t){return this.state==="COMPILING"||this.inFlightDocId!==null?(this.pendingDocs.add(t),this.lastPendingDocId=t,null):(this.state="COMPILING",this.inFlightDocId=t,++this.generation)}isStale(t){return t!==this.generation}finishBatch(){this.state="IDLE",this.inFlightDocId=null,this.lastPendingDocId=null;const t=Array.from(this.pendingDocs);return this.pendingDocs.clear(),t}finish(){const t=this.finishBatch();return t.length>0?t[t.length-1]:null}reset(){this.state="IDLE",this.inFlightDocId=null,this.pendingDocs.clear(),this.lastPendingDocId=null,this.generation=0}}const r2=150,a2=`<symbol id="iconSlides" viewBox="0 0 1024 1024">
  <path fill="currentColor" d="M128 160h768c35.3 0 64 28.7 64 64v480c0 35.3-28.7 64-64 64H128c-35.3 0-64-28.7-64-64V224c0-35.3 28.7-64 64-64z m64 64v480h640V224H192z m128 640h384v64H320z"/>
  <path fill="currentColor" d="M416 336l256 144-256 144z"/>
</symbol>`,l2="slides-dock",bo="slides-preview-tab",va="slides-presenter-tab",ba=Vf;class c2 extends ce.Plugin{constructor(){super(...arguments);be(this,"isMobile",!1);be(this,"currentDocId","");be(this,"previewTab",null);be(this,"latestCompiledDoc",null);be(this,"cliBridge",new fr);be(this,"debounceTimer",null);be(this,"activeCursorBlockId","");be(this,"cancelledCursorBlockId","");be(this,"compileScheduler",new o2);be(this,"dirtyDocId",null);be(this,"inspectorSyncThrottle",new n2);be(this,"onSwitchProtyleBound",this.onSwitchProtyle.bind(this));be(this,"onWsMainBound",this.onWsMain.bind(this));be(this,"onBlockClickedBound",this.onBlockClickedFromSlide.bind(this));be(this,"onEditorClickBound",this.onEditorClick.bind(this));be(this,"onSelectionChangeBound",this.onSelectionChange.bind(this));be(this,"onClickEditorContentBound",this.onClickEditorContent.bind(this));be(this,"onVisibilityChangeBound",this.onVisibilityChange.bind(this))}async onload(){const i=ce.getFrontend();this.isMobile=i==="mobile"||i==="browser-mobile",await this.loadGlobalSettings(),this.addIcons(a2),this.addTopBar({id:"slides-topbar-play",icon:"iconSlides",title:"即现演示",position:"right",callback:()=>{this.openBottomPreviewTab()}}),e2(this);const n=this;if(this.addTab({type:bo,init(s){var r;const o=this||s;n.previewTab=(o==null?void 0:o.tab)||null,Gw(o.element,n);const a=(r=o==null?void 0:o.data)==null?void 0:r.docId;a&&!n.getActiveDocumentId()&&n.compileCurrentDocument(a,{reason:"explicit"}),n.updatePreviewTabHeader()},destroy(){n.previewTab===(this==null?void 0:this.tab)&&(n.previewTab=null),pc(this.element)}}),this.addTab({type:va,init(s){qw((this||s).element,n)},destroy(){hc(this.element)}}),this.addDock({config:{position:"RightTop",size:{width:320,height:0},icon:"iconSlides",title:"即现演示配置"},data:{},type:l2,init(){Zw(this.element,n)},destroy(){mc(this.element)}}),this.eventBus&&typeof this.eventBus.emit!="function"&&(this.eventBus.emit=(s,o)=>{try{typeof window<"u"&&window.dispatchEvent(new CustomEvent(`siyuan-event-${s}`,{detail:o}))}catch{}}),this.eventBus.on("switch-protyle",this.onSwitchProtyleBound),this.eventBus.on("ws-main",this.onWsMainBound),this.eventBus.on("slides:request-compile",()=>this.compileCurrentDocument()),this.eventBus.on("slides:block-clicked",this.onBlockClickedBound),this.eventBus.on("click-editorcontent",this.onClickEditorContentBound),typeof document<"u"&&(document.addEventListener("click",this.onEditorClickBound,!0),document.addEventListener("selectionchange",this.onSelectionChangeBound),document.addEventListener("visibilitychange",this.onVisibilityChangeBound)),typeof document<"u"){const s=()=>{const o=this.getActiveDocumentId();o&&(o!==this.currentDocId&&(this.currentDocId=o,this.updatePreviewTabHeader("",o)),this.latestCompiledDoc||this.markCompileDirty(o))};setTimeout(s,300),setTimeout(s,1e3)}}async onDataChanged(i){await this.loadGlobalSettings(),this.currentDocId&&this.markCompileDirty(this.currentDocId)}async loadGlobalSettings(){try{const i=await this.loadData(ba),n=Gf(i);return ri(n),n}catch{return ri(Ii),Ii}}async saveGlobalSettings(i){const n=Ys(),s=ri({...n,...i||{}});try{await this.saveData(ba,s)}catch(a){console.error("保存即现全局配置失败",a)}const o=this.currentDocId||this.getActiveDocumentId();return o&&this.markCompileDirty(o),s}onunload(){this.debounceTimer&&(window.clearTimeout(this.debounceTimer),this.debounceTimer=null),this.compileScheduler.reset(),this.inspectorSyncThrottle.reset(),this.dirtyDocId=null,bs.clear(),this.eventBus.off("switch-protyle",this.onSwitchProtyleBound),this.eventBus.off("ws-main",this.onWsMainBound),this.eventBus.off("click-editorcontent",this.onClickEditorContentBound),typeof document<"u"&&(document.removeEventListener("click",this.onEditorClickBound,!0),document.removeEventListener("selectionchange",this.onSelectionChangeBound),document.removeEventListener("visibilitychange",this.onVisibilityChangeBound)),yn.detach()}onVisibilityChange(){typeof document<"u"&&document.visibilityState==="visible"&&this.flushDirtyCompile()}async openBottomPreviewTab(){this.currentDocId||(this.currentDocId=this.getActiveDocumentId());const i=this.currentDocId?await this.fetchDocumentTitle(this.currentDocId):"",n=this.buildPreviewTabTitle(i);await ce.openTab({app:this.app,custom:{id:this.name+bo,title:n,icon:"iconSlides",data:{docId:this.currentDocId}},position:"bottom"}),this.currentDocId&&this.compileCurrentDocument(this.currentDocId),this.updatePreviewTabHeader(i,this.currentDocId)}async openPresenterTab(){ai("presenterMode")||(Kw()||await this.openBottomPreviewTab(),await ce.openTab({app:this.app,custom:{id:this.name+va,title:"演讲者控制台",icon:"iconSlides",data:{}},position:"right"}))}async openStandalonePreviewWindow(){this.currentDocId||(this.currentDocId=this.getActiveDocumentId()),this.currentDocId&&!this.latestCompiledDoc&&await this.compileCurrentDocument(this.currentDocId,{reason:"explicit"});const i=ce.getFrontend();if(i==="browser-desktop"||i==="browser-mobile"){typeof window<"u"&&typeof window.open=="function"&&window.open("/plugins/siyuan-live-slides/slides-client/index.html","SlidesBigScreenWindow","width=1280,height=760,menubar=no,toolbar=no,location=no,status=no");return}let n=this.previewTab;if(!n){const s=this.currentDocId?await this.fetchDocumentTitle(this.currentDocId):"",o=this.buildPreviewTabTitle(s),a=await ce.openTab({app:this.app,custom:{id:this.name+bo,title:o,icon:"iconSlides",data:{docId:this.currentDocId}},position:"bottom"});n=this.previewTab||a}n&&(this.currentDocId&&n.model&&(n.model.data={...n.model.data||{},docId:this.currentDocId}),ce.openWindow({tab:n,width:1280,height:760}))}async onSwitchProtyle(i){var a,r,l,c,d;const n=(a=i.detail)==null?void 0:a.protyle,s=(r=n==null?void 0:n.block)==null?void 0:r.rootID,o=((d=(c=(l=n==null?void 0:n.title)==null?void 0:l.editElement)==null?void 0:c.textContent)==null?void 0:d.trim())||"";if(s&&s!==this.currentDocId){this.cancelledCursorBlockId="",this.currentDocId=s,this.activeCursorBlockId=s;const p=await Wo(s).catch(()=>({}));Xi({id:s,rootId:s,type:"doc",attrs:p}),this.markCompileDirty(s),this.updatePreviewTabHeader(o,s)}}onClickEditorContent(i){var o,a;const n=i==null?void 0:i.detail;if(!n)return;const s=(a=(o=n.protyle)==null?void 0:o.block)==null?void 0:a.rootID;s&&(!this.currentDocId||this.currentDocId!==s)&&(this.currentDocId=s),n.event&&this.onEditorClick(n.event)}buildPreviewTabTitle(i){return Ql(i)}async fetchDocumentTitle(i){return ec(this,i)}async updatePreviewTabHeader(i,n){return vg(this,i,n)}getActiveDocumentId(){return wi.getActiveDocumentId()}resolveDocIdFromElement(i){return wi.resolveDocIdFromElement(i,this.currentDocId)}async switchToDocGlobalInspector(i,n){i&&(this.activeCursorBlockId=i,this.currentDocId=i,await wi.switchToDocGlobalInspector(i,n))}onWsMain(i){const n=i.detail;n&&n.cmd==="transactions"&&(wi.patchThematicBreakTransactions(n),this.markCompileDirty())}markCompileDirty(i){const n=i||this.currentDocId||this.getActiveDocumentId();n&&(this.currentDocId||(this.currentDocId=n),this.dirtyDocId=n,this.scheduleDirtyCompile())}scheduleDirtyCompile(i=r2){if(this.debounceTimer&&(window.clearTimeout(this.debounceTimer),this.debounceTimer=null),!this.dirtyDocId)return;const n=bs.getVisibility();if(n==="none")return;const s=n==="visible"?i:Math.max(i,Fw);this.debounceTimer=window.setTimeout(()=>{this.debounceTimer=null;const o=this.dirtyDocId;this.dirtyDocId=null,o&&this.compileCurrentDocument(o,{reason:"auto"})},s)}flushDirtyCompile(){this.dirtyDocId&&this.scheduleDirtyCompile(0)}handleBlockClickedFromSlide(i,n){return i?(this.cancelledCursorBlockId="",this.activeCursorBlockId=i):(this.cancelledCursorBlockId=this.activeCursorBlockId,this.activeCursorBlockId=""),wi.handleBlockClickedFromSlide(i,this.app,this.currentDocId,this.latestCompiledDoc,n)}onBlockClickedFromSlide(i){const n=(i==null?void 0:i.detail)||i;n!=null&&n.blockId&&this.handleBlockClickedFromSlide(n.blockId,n.page)}onEditorClick(i){const n=i.target;if(!n)return;const s=n.closest(".protyle-title")||n.closest(".protyle-background");if(!!(s||n.closest(".protyle-content")&&!n.closest(".protyle-wysiwyg")&&!n.closest(".protyle-breadcrumb")&&!n.closest(".protyle-gutters"))){const d=this.resolveDocIdFromElement(n);if(d&&this.activeCursorBlockId!==d){const p=s||document.querySelector(`.protyle-title[data-node-id="${d}"]`)||document.querySelector(`.protyle[data-doc-id="${d}"] .protyle-title`),u=p==null?void 0:p.querySelector(".protyle-title__input"),f=((u==null?void 0:u.innerText)||(p==null?void 0:p.innerText)||"").trim();this.switchToDocGlobalInspector(d,f)}return}if(!n.closest(".protyle-wysiwyg"))return;const r=n.closest("[data-node-id]");if(!r)return;const l=r.getAttribute("data-node-id"),c=r.getAttribute("data-type")||"";l&&(this.cancelledCursorBlockId="",this.currentDocId||(this.currentDocId=this.resolveDocIdFromElement(n)||""),this.currentDocId&&!this.latestCompiledDoc&&this.markCompileDirty(this.currentDocId),l!==this.activeCursorBlockId&&(this.activeCursorBlockId=l,jo(l)),this.syncInspectorBlock(r,l,c))}onSelectionChange(){if(typeof window>"u")return;const i=window.getSelection();if(!i||i.rangeCount===0)return;const n=i.anchorNode;if(!n)return;const s=n.nodeType===Node.ELEMENT_NODE?n:n.parentElement;if(!s)return;const o=s.closest(".protyle-title");if(!!(o||s.closest(".protyle-content")&&!s.closest(".protyle-wysiwyg"))){const d=this.resolveDocIdFromElement(s);if(d&&this.activeCursorBlockId!==d){const p=o||document.querySelector(`.protyle-title[data-node-id="${d}"]`)||document.querySelector(`.protyle[data-doc-id="${d}"] .protyle-title`),u=p==null?void 0:p.querySelector(".protyle-title__input"),f=((u==null?void 0:u.innerText)||(p==null?void 0:p.innerText)||"").trim();this.switchToDocGlobalInspector(d,f)}return}if(!s.closest(".protyle-wysiwyg"))return;const r=s.closest("[data-node-id]"),l=r==null?void 0:r.getAttribute("data-node-id"),c=(r==null?void 0:r.getAttribute("data-type"))||"";if(r&&l){if(wi.isLocatingLocked(l))return;if(this.currentDocId||(this.currentDocId=this.resolveDocIdFromElement(s)||""),this.currentDocId&&!this.latestCompiledDoc&&this.markCompileDirty(this.currentDocId),l!==this.activeCursorBlockId){if(l===this.cancelledCursorBlockId)return;this.activeCursorBlockId=l,jo(l)}this.syncInspectorBlock(r,l,c)}}async syncInspectorBlock(i,n,s){this.inspectorSyncThrottle.shouldSkip(n)||await wi.syncInspectorBlock(i,n,s,this.currentDocId,this.latestCompiledDoc)}async compileCurrentDocument(i,n){const s=(n==null?void 0:n.reason)??"explicit";let o=i||this.currentDocId;if(!o){const r=this.getActiveDocumentId();if(r)this.currentDocId=r,o=r;else return}if(s==="auto"&&bs.getVisibility()==="none"){this.dirtyDocId=o;return}const a=this.compileScheduler.tryBegin(o);if(a!==null){this.dirtyDocId===o&&(this.dirtyDocId=null);try{const r=await Le.compile(o),l=!!this.currentDocId&&o!==this.currentDocId;!this.compileScheduler.isStale(a)&&!l&&(this.currentDocId||(this.currentDocId=o),this.latestCompiledDoc=r,Jw(r,o),this.updatePreviewTabHeader("",o),this.purgeStaleDomSlidesAttrs(r))}catch(r){console.error("[SiYuanLiveSlides] Failed to compile document:",r)}finally{const r=this.compileScheduler.finishBatch(),l=r.length>0?r[0]:this.compileScheduler.finish();l&&this.markCompileDirty(l);for(let c=1;c<r.length;c++)this.markCompileDirty(r[c])}}}purgeStaleDomSlidesAttrs(i){wi.purgeStaleDomSlidesAttrs(i)}}module.exports=c2;
