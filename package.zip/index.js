"use strict";var ca=Object.create;var yo=Object.defineProperty;var da=Object.getOwnPropertyDescriptor;var ua=Object.getOwnPropertyNames;var fa=Object.getPrototypeOf,pa=Object.prototype.hasOwnProperty;var ha=(t,i,e)=>i in t?yo(t,i,{enumerable:!0,configurable:!0,writable:!0,value:e}):t[i]=e;var ma=(t,i,e,o)=>{if(i&&typeof i=="object"||typeof i=="function")for(let n of ua(i))!pa.call(t,n)&&n!==e&&yo(t,n,{get:()=>i[n],enumerable:!(o=da(i,n))||o.enumerable});return t};var An=(t,i,e)=>(e=t!=null?ca(fa(t)):{},ma(i||!t||!t.__esModule?yo(e,"default",{value:t,enumerable:!0}):e,t));var kt=(t,i,e)=>ha(t,typeof i!="symbol"?i+"":i,e);const mt=require("siyuan");async function de(t,i){const e=await mt.fetchSyncPost(t,i);return e.code===0?e.data:null}async function ga(){return de("/api/notebook/lsNotebooks","")}async function va(t,i,e){return de("/api/filetree/createDocWithMd",{notebook:t,path:i,markdown:e})}async function br(t,i){const e=new FormData;e.append("assetsDirPath",t);for(const n of i)e.append("file[]",n);return de("/api/asset/upload",e)}async function Qi(t,i,e,o,n){return de("/api/block/insertBlock",{dataType:t,data:i,nextID:e,previousID:o,parentID:n})}async function yr(t,i,e){return de("/api/block/appendBlock",{dataType:t,data:i,parentID:e})}async function Ts(t,i,e){return de("/api/block/updateBlock",{dataType:t,data:i,id:e})}async function ba(t){return de("/api/block/deleteBlock",{id:t})}async function ya(t){return de("/api/block/getBlockKramdown",{id:t})}async function Hn(t){return de("/api/block/getChildBlocks",{id:t})}async function Dt(t,i){return de("/api/attr/setBlockAttrs",{id:t,attrs:i})}async function Ue(t){return de("/api/attr/getBlockAttrs",{id:t})}async function dn(t){return de("/api/query/sql",{stmt:t})}async function Lo(t,i,e){const o=new FormData;return o.append("path",t),o.append("isDir",i.toString()),o.append("modTime",Math.floor(Date.now()/1e3).toString()),o.append("file",e),de("/api/file/putFile",o)}async function kr(t){const i="/api/ai/chatGPT";try{const e=await de(i,{msg:t});return typeof e=="string"&&e.trim().length>0?e.trim():e&&typeof e.content=="string"&&e.content.trim().length>0?e.content.trim():null}catch{return null}}async function ka(){return de("/api/storage/getInlineStyles","")}const wr=/\(\(([0-9a-zA-Z-]+)(?:\s*(?:'([^']*)'|"([^"]*)"|([^\)]+?)))?\s*\)\)/g;function wa(t){const i=[];if(!t)return i;const e=new RegExp(wr.source,"g");let o;for(;(o=e.exec(t))!==null;){const n=o[2]??o[3]??o[4];i.push({fullMatch:o[0],blockId:o[1],anchorText:n?n.trim():void 0})}return i}function xa(t,i){if(!t)return"";const e=new RegExp(wr.source,"g");return t.replace(e,(o,n,r,l,s)=>{const a=(r??l??s??"").trim();if(i&&i[n]){const d=i[n].trim();return`<div class="slidev-block-ref" data-ref-id="${n}">${d}</div>`}const c=a||`Ref(${n.slice(0,8)})`;return`<a href="siyuan://blocks/${n}" data-ref-id="${n}" class="slidev-ref-tag">🔗 ${c}</a>`})}const un="custom-slidev-theme",fn="custom-slidev-aspect-ratio",xr="custom-slidev-highlighter",pn="custom-slidev-default-transition",_r="custom-slidev-color-schema",Po="custom-slidev-spacing",vi="custom-slidev-slide",dt="custom-slidev-layout",qt="custom-slidev-transition",zt="custom-slidev-background",Se="custom-slidev-image",Di="custom-slidev-notes",Li="custom-slidev-class",nn="custom-slidev-spacing",ke="custom-slidev-click",Ne="custom-slidev-motion",Ci="custom-slidev-shiki-lines",At="custom-slidev-slot",Jt="custom-slidev-note",jt="custom-slidev-role",hn="custom-slidev-max-height",bi="custom-slidev-autoplay",Un="custom-slidev-loop",Mi="custom-slidev-muted",Wn="custom-slidev-controls",Sr="background",Vn="image-left",Kn="image-right";function _a(t){return t.markdown&&t.markdown.trim()?t.markdown.trim():t.content&&t.content.trim()?t.content.trim():""}function Sa(t){const i={};if(!t)return i;const e=t.replace(/^\{:\s*/,"").replace(/\s*\}$/,""),o=/([\w-]+)=(?:"([^"]*)"|'([^']*)'|(\S+))/g;let n;for(;(n=o.exec(e))!==null;){const r=n[1],l=n[2]??n[3]??n[4]??"";i[r]=l}return i}function Ca(t){if(!t)return!1;const i=t.trim();return i.startsWith("assets/")||i.startsWith("./assets/")||i.startsWith("/assets/")}function $a(t){const i=t.trim();return i.startsWith("./assets/")?i.slice(2):i.startsWith("/assets/")?i.slice(1):i}function ye(t,i){if(!Ca(t))return t;const e=$a(t);return i!=null&&i.base64Map&&i.base64Map[e]?i.base64Map[e]:i!=null&&i.baseUrl?`${i.baseUrl.replace(/\/+$/,"")}/${e}`:`/${e}`}function Ia(t,i){if(!t)return"";let e=t;return e=e.replace(/!\[(.*?)\]\(((?:\.\/|\/)?assets\/[^\s)]+)\)/g,(o,n,r)=>{const l=ye(r,i);return`![${n}](${l})`}),e=e.replace(/(<(?:img|video|audio|source)\b[^>]*?\bsrc=["'])((?:\.\/|\/)?assets\/[^"']+)(["'][^>]*>)/gi,(o,n,r,l)=>{const s=ye(r,i);return`${n}${s}${l}`}),e=e.replace(/(url\(\s*["']?)((?:\.\/|\/)?assets\/[^"')]+)(["']?\s*\))/gi,(o,n,r,l)=>{const s=ye(r,i);return`${n}${s}${l}`}),e}const ui={theme:"default",aspectRatio:"16/9",highlighter:"shiki",defaultTransition:"slide-left",colorSchema:"auto",spacing:"normal"};function Aa(t){var i,e,o,n,r,l;return t?{theme:((i=t[un])==null?void 0:i.trim())||ui.theme,aspectRatio:((e=t[fn])==null?void 0:e.trim())||ui.aspectRatio,highlighter:((o=t[xr])==null?void 0:o.trim())||ui.highlighter,defaultTransition:((n=t[pn])==null?void 0:n.trim())||ui.defaultTransition,colorSchema:((r=t[_r])==null?void 0:r.trim())||ui.colorSchema,spacing:((l=t[Po])==null?void 0:l.trim())||ui.spacing}:{...ui}}function qn(t){var e,o,n,r,l;const i=(e=t.ial)==null?void 0:e[vi];return!!(i&&(i==="true"||i==="page"||i==="cover"||i==="end")||t.type==="tb"||t.type==="thematic-break"||t.type==="NodeThematicBreak"||((o=t.markdown)==null?void 0:o.trim())==="---"||((n=t.markdown)==null?void 0:n.trim())==="***"||t.type==="b"&&(((r=t.markdown)==null?void 0:r.trim())==="---"||((l=t.content)==null?void 0:l.trim())==="---"))}function Es(t){const i={};let e="";if(!t)return{frontmatter:i,notes:e};t[dt]&&(i.layout=t[dt].trim()),t[qt]&&(i.transition=t[qt].trim()),t[zt]&&(i.background=t[zt].trim()),t[Se]&&(i.image=t[Se].trim()),t[Li]&&(i.class=t[Li].trim()),t[nn]&&(i.spacing=t[nn].trim()),t[Di]&&(e=t[Di].trim());for(const[o,n]of Object.entries(t))if(o.startsWith("custom-slidev-")&&![dt,qt,zt,Se,Li,nn,Di,vi].includes(o)){const r=o.replace(/^custom-slidev-/,"");try{i[r]=JSON.parse(n)}catch{i[r]=n}}return{frontmatter:i,notes:e}}function Ta(t){const i={};if(!t)return i;const e=t[Jt]??t["slidev-note"];e!=null&&e!==""&&e!=="false"&&e!=="0"&&(i.isNote=!0);const o=t[jt]??t["slidev-role"],n=t[zt]??t["slidev-background"];(o===Sr||n==="true"||n==="1")&&(i.isBackground=!0);const r=t[dt]??t["slidev-layout"];r===Vn||r===Kn?i.imageLayout=r:(o===Vn||o===Kn)&&(i.imageLayout=o);const l=t[ke]??t["custom-slidev-clicks"]??t["slidev-click"]??t["slidev-clicks"];if(l!=null&&(i.clicks=l.trim()),t[Ne])try{const s=JSON.parse(t[Ne]);typeof s=="object"&&s!==null?i.motion={preset:s.preset||s.type||"fade-in",...s}:i.motion={preset:String(s).trim()}}catch{i.motion={preset:t[Ne].trim()}}return t[Ci]&&(i.shikiLines=t[Ci].trim()),t[hn]&&(i.maxHeight=t[hn].trim()),t[At]&&(i.slot=t[At].trim()),t.style&&t.style.trim()&&(i.style=t.style.trim()),i}function li(t,i){const e=(t||i||"").trim();if(!e)return null;const o=e.match(/!\[[\s\S]*?\]\(\s*([^\s)]+)(?:\s+(?:=["']?[^"'\s)]*["']?|["'][^"']*["']))*?\s*\)/);if(o)return o[1].trim();const n=e.match(/<img\b[^>]*?\bsrc=["']([^"']+)["']/i);if(n)return n[1].trim();const r=e.replace(/\{:[^}]*\}/g,"").trim();return/^(?:assets\/|https?:\/\/|\/|\.\.?\/)[^\s]+\.(?:png|jpe?g|gif|webp|svg|avif)(?:\?[^\s]*)?$/i.test(r)?r:null}function Oo(t){if(!t)return"";const i=t.split(/\r?\n/);if(i.length===0)return"";const e=i[0],o=e.match(/^(\s*)(?:[-*+]|\d+\.)\s+(.*)$/);if(!o)return t;const n=o[1].length,r=o[2].trim(),l=e.length-o[2].length;if(i.length===1)return r;const s=[r];for(let a=1;a<i.length;a++){const c=i[a];if(!c.trim()){s.push("");continue}const d=c.match(/^(\s*)/),f=d?d[1].length:0;f>=l?s.push(c.slice(l)):f>n?s.push(c.slice(f)):s.push(c)}return s.join(`
`)}function ji(t){if(!t)return!1;const i=(t.type||"").toLowerCase();if(i==="i"||i==="nodelistitem"||i==="l"||i==="nodelist")return!0;const e=(t.markdown||t.rawMarkdown||t.content||"").trim();return!!/^(?:[-*+]|\d+\.)\s+/.test(e)}function yi(t){if(!t)return[];if(re(t)&&$i(t)&&!ai(t)){const o=Qo(t),n=[];for(const r of o)n.push(...yi(r));return n}const i=(t.type||"").toLowerCase();if(i==="l"||i==="nodelist"||i==="list"){if(t.children&&t.children.length>0){const l=t.children.filter(ji);if(l.length>0)return l}const n=(t.markdown||t.content||"").trim().split(/\r?\n/),r=[];for(let l=0;l<n.length;l++)/^(?:[-*+]|\d+\.)\s+/.test(n[l])&&r.push(l);if(r.length>=2){const l=[];for(let s=0;s<r.length;s++){const a=r[s],c=s+1<r.length?r[s+1]:n.length,d=n.slice(a,c).join(`
`);l.push({id:`${t.id}-item-${s+1}`,type:"i",markdown:d,content:d,ial:{...t.ial||{}}})}return l}}return ji(t)?[t]:[]}function Cr(t){var o;if(!t||!re(t)||!$i(t)||ai(t))return null;const i=Qo(t);if(i.length===0)return null;if(i.length===1&&re(i[0])&&$i(i[0])){const n=Cr(i[0]);return n?{items:n.items,nestedSuperBlocks:[i[0],...n.nestedSuperBlocks]}:null}const e=[];for(const n of i)if(re(n)){e.push(n);const r=((o=n.children)==null?void 0:o.filter(re))||[];e.push(...r)}if(i.length===3){const n=yi(i[0]),r=yi(i[1]),l=yi(i[2]);if(n.length===1&&r.length===1&&l.length===1)return{items:[n[0],r[0],l[0]],nestedSuperBlocks:e}}if(i.length===2){const n=yi(i[0]),r=yi(i[1]);if(n.length===2&&r.length===1)return{items:[n[0],n[1],r[0]],nestedSuperBlocks:e};if(n.length===1&&r.length===2)return{items:[n[0],r[0],r[1]],nestedSuperBlocks:e};if(n.length===1&&r.length===1)return{items:[n[0],r[0]],nestedSuperBlocks:e}}return null}function Ea(t){if(!t||!re(t)||!$i(t)||ai(t))return null;const i=Cr(t);if(!i)return null;const{items:e,nestedSuperBlocks:o}=i;return e.length!==2&&e.length!==3?null:e.length===2?{superBlockNode:t,nestedSuperBlocks:o,count:2,layout:"two-cols-header",items:e,slots:["left","right"]}:{superBlockNode:t,nestedSuperBlocks:o,count:3,layout:"three-cols-header",items:e,slots:["col-1","col-2","col-3"]}}function Ba(t){if(!t||!re(t)||!$i(t)||ai(t))return null;const i=Qo(t);if(i.length===0)return null;const e=[];for(const o of i){const n=yi(o);if(n.length===0)return null;e.push(...n)}return e}function Ma(t){if(!t||!re(t)||!$i(t)||ai(t))return null;const i=Ba(t);return!i||i.length===0||i.length===2||i.length===3?null:{superBlockNode:t,items:i}}function Da(t,i,e){var d,f,g,u,k;const o=[],n=[],r=(e==null?void 0:e.tracked)||[],l=[];let s={pageTargetId:t,blocks:[]};l.push(s);for(let h=0;h<i.length;h++){const y=i[h];if(qn(y)){if(l.length===1&&s.blocks.length===0){s.pageTargetId=y.id,s.blocks.push(y);continue}s={pageTargetId:y.id,blocks:[y]},l.push(s)}else s.blocks.push(y)}function a(h){const y=[];for(const b of h)re(b)&&y.push(b),b.children&&b.children.length>0&&y.push(...a(b.children));return y}function c(h,y,b){const w={blockId:h,attrs:y,previousAttrs:b};o.push(w),e!=null&&e.onTagChange&&e.onTagChange(w)}for(const h of l){const y=h.pageTargetId,b=i.find(_=>_.id===y),w=r.find(_=>_.pageTargetId===y);if(h.blocks.some(_=>{var I,L;return!!(ai(_)||Ro(_)&&(((I=_.ial)==null?void 0:I[dt])==="image-left"||((L=_.ial)==null?void 0:L[dt])==="image-right"))})){if(w){const _=w.headerId;if(_){c(_,{[At]:""});const I=i.find(L=>L.id===_);I!=null&&I.ial&&(I.ial[At]="")}for(const I of w.itemIds){c(I,{[At]:""});const L=i.find(M=>M.id===I);L!=null&&L.ial&&(L.ial[At]="")}}continue}let T=null,x=-1;for(let _=0;_<h.blocks.length;_++){const I=h.blocks[_],L=re(I)?[I,...a(I.children||[])]:I.children?a(I.children):[];for(const M of L){const F=Ea(M);if(F){T=F,x=_;break}}if(T)break}if(T){const{superBlockNode:_,layout:I,items:L,slots:M}=T,J=h.blocks.slice(0,x).find(O=>Pa(O)),E=J==null?void 0:J.id,A=((d=b==null?void 0:b.ial)==null?void 0:d[dt])||"";if(A!==I&&(c(y,{[dt]:I},{[dt]:A}),b&&(b.ial||(b.ial={}),b.ial[dt]=I)),J){const O=((f=J.ial)==null?void 0:f[At])||"";O!=="header"&&(c(J.id,{[At]:"header"},{[At]:O}),J.ial||(J.ial={}),J.ial[At]="header")}if(w!=null&&w.headerId&&w.headerId!==E){c(w.headerId,{[At]:""});const O=i.find(z=>z.id===w.headerId);O&&(O.ial||(O.ial={}),O.ial[At]="")}const v=[];for(let O=0;O<L.length;O++){const z=L[O],P=M[O];v.push(z.id);const K=((g=z.ial)==null?void 0:g[At])||"";if(K!==P&&(c(z.id,{[At]:P},{[At]:K}),z.ial||(z.ial={}),z.ial[At]=P),z.children&&z.children.length>0)for(const H of z.children)H.ial||(H.ial={}),H.ial[At]!==P&&(H.ial[At]=P)}if(w!=null&&w.itemIds){for(const O of w.itemIds)if(!v.includes(O)){c(O,{[At]:""});const z=i.find(P=>P.id===O);z&&(z.ial||(z.ial={}),z.ial[At]="")}}n.push({superBlockId:_.id,nestedSuperBlockIds:(u=T.nestedSuperBlocks)==null?void 0:u.map(O=>O.id),pageTargetId:y,headerId:E,itemIds:v,layout:I})}else{let _=!1;const I=[];for(const F of h.blocks){const J=re(F)?[F,...a(F.children||[])]:F.children?a(F.children):[];for(const E of J){const A=Ma(E);if(A){_=!0;for(const v of A.items)I.push(v.id)}}}const L=((k=b==null?void 0:b.ial)==null?void 0:k[dt])||"";if(w||_&&(L==="two-cols-header"||L==="three-cols-header")){c(y,{[dt]:""},{[dt]:L}),b&&(b.ial||(b.ial={}),b.ial[dt]="");const F=w==null?void 0:w.headerId;if(F){c(F,{[At]:""});const E=i.find(A=>A.id===F);E&&(E.ial||(E.ial={}),E.ial[At]="")}const J=new Set([...(w==null?void 0:w.itemIds)||[],...I]);for(const E of J){c(E,{[At]:""});const A=i.find(v=>v.id===E);A&&(A.ial||(A.ial={}),A.ial[At]="")}}}}return{changes:o,newTracked:n}}function re(t){if(!t)return!1;const i=(t.type||"").toLowerCase();return i==="s"||i==="sb"||i==="nodesuperblock"}function $i(t){if(!re(t))return!1;const i=(t.subType||"").toLowerCase();if(i==="col"||i==="h"||i==="horizontal")return!0;if(i==="row"||i==="v"||i==="vertical")return!1;if(t.ial){const o=(t.ial["data-sb-layout"]||t.ial.layout||"").toLowerCase();if(o==="col"||o==="h")return!0;if(o==="row"||o==="v")return!1}if(t.children&&t.children.length>0){for(const o of t.children)if(o.type==="NodeSuperBlockLayoutMarker"||o.type==="layout-marker"){const n=(o.content||o.markdown||"").trim().toLowerCase();if(n==="col"||n==="h")return!0;if(n==="row"||n==="v")return!1}}const e=(t.markdown||t.content||"").trim();return/^\{\{\{col\b/i.test(e)?!0:!/^\{\{\{row\b/i.test(e)}function Ro(t){return!t||ji(t)||re(t)||!li(t.markdown,t.content)?!1:(t.markdown||t.content||"").replace(/!\[.*?\]\([^)]+\)/g,"").replace(/<img\b[^>]*>/gi,"").replace(/\{:[^}]*\}/g,"").trim().length<=25}function ai(t){if(!t||!re(t)||!$i(t))return null;const i=(t.children||[]).filter(n=>{const r=n.type||"";if(r==="NodeSuperBlockOpenMarker"||r==="NodeSuperBlockLayoutMarker"||r==="NodeSuperBlockCloseMarker"||r==="open-marker"||r==="layout-marker"||r==="close-marker")return!1;const l=(n.markdown||n.content||"").trim();return!(/^\{\{\{(?:col|row)?\s*$/i.test(l)||l==="}}}")});if(i.length<2)return null;const e=Ro(i[0]),o=Ro(i[i.length-1]);if(e&&!o){const n=li(i[0].markdown,i[0].content);if(n)return{imageNode:i[0],imageUrl:n,layout:Vn,contentNodes:i.slice(1)}}if(!e&&o){const n=li(i[i.length-1].markdown,i[i.length-1].content);if(n)return{imageNode:i[i.length-1],imageUrl:n,layout:Kn,contentNodes:i.slice(0,i.length-1)}}return null}function La(t,i){const e=[];function o(n){for(const r of n){const l=ai(r);if(l){const{imageNode:s,layout:a}=l;s.ial||(s.ial={});const c=s.ial[dt];if(c!==a){const d={blockId:s.id,layout:a,previousLayout:c};s.ial[dt]=a,e.push(d),i&&i(d)}}r.children&&r.children.length>0&&o(r.children)}}return o(t),e}function Qo(t){return(t.children||[]).filter(i=>{const e=i.type||"";if(e==="NodeSuperBlockOpenMarker"||e==="NodeSuperBlockLayoutMarker"||e==="NodeSuperBlockCloseMarker"||e==="open-marker"||e==="layout-marker"||e==="close-marker")return!1;const o=(i.markdown||i.content||"").trim();return!(/^\{\{\{(?:col|row)?\s*$/i.test(o)||o==="}}}")})}function Pa(t){if(!t)return!1;const i=(t.type||"").toLowerCase();if(i==="h"||i==="nodeheading"||/^h[1-6]$/i.test(t.subType||""))return!0;const e=(t.markdown||t.content||"").trim();return!!/^#{1,6}\s+/.test(e)}function fi(t,i,e){let o="",n=0;const r=/<div\b([^>]*)>/gi;for(;n<t.length;){r.lastIndex=n;let l,s=!1,a=-1,c=0;for(;(l=r.exec(t))!==null;){const b=l[1].match(/\bclass=["']([^"']*)["']/i);if(b){const w=b[1];if(typeof i=="string"?w.split(/\s+/).includes(i):i.test(w)){s=!0,a=l.index,c=l[0].length;break}}}if(!s){o+=t.slice(n);break}o+=t.slice(n,a);const d=a+c;let f=1,g=-1,u=-1;const k=/<\/?div\b[^>]*>/gi;k.lastIndex=d;let h;for(;(h=k.exec(t))!==null;)if(h[0].startsWith("</")){if(f--,f===0){g=h.index,u=h.index+h[0].length;break}}else f++;if(g!==-1&&u!==-1){const y=t.slice(d,g);o+=e(y),n=u}else o+=t.slice(a,d),n=d}return o}function Oa(t){const i=[];let e="",o=0;const n=/<div\b([^>]*)>/gi;for(;o<t.length;){n.lastIndex=o;let r,l=!1,s=-1,a=0;for(;(r=n.exec(t))!==null;){const h=r[1];if(/(?:\s@[a-zA-Z0-9_-]+=\s*["']|\s:[a-zA-Z0-9_-]+=\s*["']|\sv-[a-zA-Z0-9_.-]+|\shover:[a-zA-Z0-9_.-]+=\s*["']|\sgrid=["']~|\bclass=["'][^"']*\b(?:abs-br|slidev-icon-btn|grid\s+|grid$|grid-cols-|relative\b)\b[^"']*["']|\bstyle=["'][^"']*\bgrid-[^"']*["'])/i.test(h)){l=!0,s=r.index,a=r[0].length;break}}if(!l){e+=t.slice(o);break}e+=t.slice(o,s);const c=s+a;let d=1,f=-1,g=-1;const u=/<\/?div\b[^>]*>/gi;u.lastIndex=c;let k;for(;(k=u.exec(t))!==null;)if(k[0].startsWith("</")){if(d--,d===0){f=k.index,g=k.index+k[0].length;break}}else d++;if(f!==-1&&g!==-1){const h=t.slice(s,g),y=`__VUE_DIV_TOKEN_${i.length}__`;i.push(h),e+=y,o=g}else e+=t.slice(s,c),o=c}return{text:e,tokens:i}}function Ra(t){const i=[];let e=t.replace(/(?:^[ \t]*(`{3,}|~{3,})[^\n\r]*\r?\n[\s\S]*?\r?\n[ \t]*\1(?=[ \t]*(?:\r?\n|$)))/gm,s=>{const a=`__CODE_TOKEN_${i.length}__`;return i.push(s),a});e=e.replace(/(`+)(?:[^\n\r`]|(?!\1)`)+?\1/g,s=>{const a=`__CODE_TOKEN_${i.length}__`;return i.push(s),a});const o=[];e=e.replace(/<script\b[^>]*>[\s\S]*?<\/script>/gi,s=>{const a=`__SCRIPT_TOKEN_${o.length}__`;return o.push(s),a});const{text:n,tokens:r}=Oa(e);e=n;const l=[];e=e.replace(/<(?:[A-Z][a-zA-Z0-9_-]*|[a-z0-9_-]+:[a-z0-9_-]+|v-[a-z0-9_-]+|arrow\b|div\s+h-\d+)\b[^>]*\/>/gi,s=>{const a=`__VUE_COMP_TOKEN_${l.length}__`;return l.push(s),a}),e=e.replace(/<(v-[a-z0-9_-]+|button)\b([^>]*)>([\s\S]*?)<\/\1>/gi,s=>{const a=`__VUE_COMP_TOKEN_${l.length}__`;return l.push(s),a}),e=e.replace(/<img\b[^>]*?\bv-[a-z0-9_.-]+[^>]*\/?>/gi,s=>{const a=`__VUE_COMP_TOKEN_${l.length}__`;return l.push(s),a}),e=e.replace(/<(p|span)\b([^>]*?\bv-[a-z0-9_.-]+[^>]*)>([\s\S]*?)<\/\1>/gi,s=>{const a=`__VUE_COMP_TOKEN_${l.length}__`;return l.push(s),a}),e=e.replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi,""),e=e.replace(/<div class="terminal-bar">[\s\S]*?<\/div>/gi,""),e=e.replace(/<div class="cursor-line">[\s\S]*?<\/div>/gi,""),e=e.replace(/<span class="cursor">[\s\S]*?<\/span>/gi,""),e=e.replace(/<div class="stamp">\s*([\s\S]*?)\s*<\/div>/gi,`

*[$1]*

`),e=e.replace(/<div class="arrow">\s*([→\->]+)\s*<\/div>/gi,`

$1

`),e=e.replace(/<i>\s*[→\->]+\s*<\/i>/gi,""),e=e.replace(/<div class="prompt">\s*([\s\S]*?)\s*<\/div>/gi,(s,a)=>`
\`\`\`bash
${a.trim()}
\`\`\`
`),e=e.replace(/<p>\s*<i>\$<\/i>\s*([\s\S]*?)<\/p>/gi,(s,a)=>`
\`\`\`bash
$ ${a.trim()}
\`\`\`
`),e=e.replace(/<div class="statusline">\s*([\s\S]*?)\s*<\/div>/gi,(s,a)=>`
> ${Array.from(a.matchAll(/<span>([\s\S]*?)<\/span>/gi)).map(d=>`\`${d[1].trim()}\``).join(" | ")}
`),e=e.replace(/<div class="log-panel">\s*<pre>([\s\S]*?)<\/pre>\s*<\/div>/gi,(s,a)=>`
\`\`\`log
${a.replace(/<span[^>]*>([\s\S]*?)<\/span>/gi,"$1").trim()}
\`\`\`
`),e=fi(e,"diff-grid",s=>{const a=Array.from(s.matchAll(/<div class="diff\s+([^"]*)">\s*<span>(.*?)<\/span>\s*<pre>([\s\S]*?)<\/pre>\s*<\/div>/gi));return a.length>0?`
`+a.map(c=>{const d=c[2].trim().toUpperCase(),f=c[3].trim();return`**${d}:**
\`\`\`yaml
${f}
\`\`\``}).join(`

`)+`
`:s}),e=fi(e,"before-after",s=>{const a=s.match(/<div class="before">[\s\S]*?<small>(.*?)<\/small>[\s\S]*?<h2>(.*?)<\/h2>[\s\S]*?<p>(.*?)<\/p>\s*<\/div>/i),c=s.match(/<div class="after">[\s\S]*?<small>(.*?)<\/small>[\s\S]*?<h2>(.*?)<\/h2>[\s\S]*?<p>(.*?)<\/p>\s*<\/div>/i);let d=`
`;return a&&(d+=`### ${a[1]}
## ${a[2]}
${a[3]}

`),c&&(d+=`### ${c[1]}
## ${c[2]}
${c[3]}
`),d.trim()?d:s}),e=e.replace(/<ul\b[^>]*>([\s\S]*?)<\/ul>/gi,(s,a)=>{const c=Array.from(a.matchAll(/<li>\s*(?:<em>)?(\[[x ]\])(?:<\/em>)?\s*([\s\S]*?)<\/li>/gi));return c.length>0?`
`+c.map(d=>`- ${d[1]} ${d[2].trim()}`).join(`
`)+`
`:a}),e=fi(e,"timeline",s=>{const a=Array.from(s.matchAll(/<div(?:\s+class="([^"]*)")?>\s*<time>([\s\S]*?)<\/time>\s*<b>([\s\S]*?)<\/b>\s*<span>([\s\S]*?)<\/span>\s*<\/div>/gi));return a.length>0?`

`+a.map(c=>{const d=c[1]||"";let f="-";return d.includes("warn")?f="- ⚠️":d.includes("bad")?f="- ❌":d.includes("ok")&&(f="- ✅"),`${f} **${c[2].trim()}** **${c[3].trim()}** — ${c[4].trim()}`}).join(`
`)+`

`:s}),e=fi(e,"pipeline",s=>{const a=Array.from(s.matchAll(/<div(?:\s+class="([^"]*)")?>\s*<small>([\s\S]*?)<\/small>\s*<b>([\s\S]*?)<\/b>\s*<span>([\s\S]*?)<\/span>\s*<\/div>/gi));return a.length>0?`

`+a.map((c,d)=>{const g=(c[1]||"").includes("hot")?"⚠️ ":"";return`${d+1}. ${g}**${c[3].trim()}** (*${c[4].trim()}*)`}).join(`
`)+`

`:s}),e=fi(e,"check-grid",s=>{const a=Array.from(s.matchAll(/<div>\s*<span class="([^"]*)"><\/span>\s*<b>([\s\S]*?)<\/b>\s*<p>([\s\S]*?)<\/p>\s*<\/div>/gi));return a.length>0?`

`+a.map(c=>`- ${(c[1]||"").includes("warn")?"⚠️":"✅"} **${c[2].trim()}**: ${c[3].trim()}`).join(`
`)+`

`:s}),e=fi(e,"manifesto",s=>{const a=Array.from(s.matchAll(/<div>\s*<span>([\s\S]*?)<\/span>\s*<h2>([\s\S]*?)<\/h2>\s*<p>([\s\S]*?)<\/p>\s*<\/div>/gi));return a.length>0?`

`+a.map(c=>`## ${c[1].trim()} ${c[2].trim()}

${c[3].trim()}`).join(`

`)+`

`:s}),e=fi(e,"split-note",s=>{const a=Array.from(s.matchAll(/<div>\s*<b>([\s\S]*?)<\/b>\s*<p>([\s\S]*?)<\/p>\s*<\/div>/gi));return a.length>0?`

`+a.map(c=>`> **${c[1].trim()}**: ${c[2].trim()}`).join(`
>
`)+`

`:s}),e=e.replace(/<div class="mechanism">\s*<b>([\s\S]*?)<\/b>\s*<p>([\s\S]*?)<\/p>\s*<\/div>/gi,(s,a,c)=>`

> **${a.trim()}**: ${c.trim()}

`),e=e.replace(/<pre>([\s\S]*?)<\/pre>/gi,(s,a)=>`
\`\`\`text
${a.replace(/<span[^>]*>([\s\S]*?)<\/span>/gi,"$1").trim()}
\`\`\`
`),e=e.replace(/<div class="page-head">\s*<span>([\s\S]*?)<\/span>\s*<b>([\s\S]*?)<\/b>\s*<\/div>/gi,`
### $1 ($2)
`),e=e.replace(/<h1\b[^>]*>([\s\S]*?)<\/h1>/gi,`
# $1
`),e=e.replace(/<h2\b[^>]*>([\s\S]*?)<\/h2>/gi,`
## $1
`),e=e.replace(/<h3\b[^>]*>([\s\S]*?)<\/h3>/gi,`
### $1
`),e=e.replace(/<h4\b[^>]*>([\s\S]*?)<\/h4>/gi,`
#### $1
`),e=e.replace(/<p\s+class="ok">\s*●\s*([\s\S]*?)<\/p>/gi,`
✅ **$1**
`),e=e.replace(/<p\s+class="caption">\s*([\s\S]*?)<\/p>/gi,`
> *$1*
`),e=e.replace(/<p\s+class="lead">\s*([\s\S]*?)<\/p>/gi,`
*$1*
`),e=e.replace(/<p\b([^>]*)>([\s\S]*?)<\/p>/gi,(s,a,c)=>/@|v-|:|class=/i.test(a)?s:`
${c.trim()}

`),e=e.replace(/<br\s*\/?>/gi,`
`),e=e.replace(/<hr\s*\/?>/gi,`
---
`),e=e.replace(/<b\b[^>]*>([\s\S]*?)<\/b>/gi,"**$1**"),e=e.replace(/<strong\b[^>]*>([\s\S]*?)<\/strong>/gi,"**$1**"),e=e.replace(/<i\b[^>]*>([\s\S]*?)<\/i>/gi,"*$1*"),e=e.replace(/<code\b[^>]*>([\s\S]*?)<\/code>/gi,(s,a)=>{if(a.startsWith("`")&&a.endsWith("`"))return a;if(a.includes("`")){const c=(a.match(/`+/g)||[]).reduce((f,g)=>Math.max(f,g.length),0),d="`".repeat(c+1);return`${d} ${a} ${d}`}return`\`${a}\``}),e=e.replace(/<small\b[^>]*>([\s\S]*?)<\/small>/gi,"*$1*"),e=e.replace(/\*{4}/g,"** **"),e=e.replace(/<li\b[^>]*>([\s\S]*?)<\/li>/gi,`- $1
`),e=e.replace(/<ul\b[^>]*>([\s\S]*?)<\/ul>/gi,`
$1
`),e=e.replace(/<ol\b[^>]*>([\s\S]*?)<\/ol>/gi,`
$1
`),e=e.replace(/<a\b([^>]*)href=["'](.*?)["']([^>]*)>([\s\S]*?)<\/a>/gi,(s,a,c,d,f)=>{const g=f.trim();return g.includes("<")||g.includes(`
`)?s:`[${g}](${c})`}),e=e.replace(/<blockquote\b[^>]*>([\s\S]*?)<\/blockquote>/gi,(s,a)=>`
`+a.trim().split(`
`).map(c=>`> ${c.trim()}`).join(`
`)+`
`),e=e.replace(/<span\b[^>]*data-type=["']block-ref["'][^>]*data-id=["']([0-9a-zA-Z-]+)["'][^>]*>([\s\S]*?)<\/span>/gi,(s,a,c)=>{const d=c.replace(/<[^>]+>/g,"").trim();return d?`((${a} '${d}'))`:`((${a}))`}),e=e.replace(/<span\b[^>]*data-type=["']a["'][^>]*data-href=["']([^"']+)["'][^>]*>([\s\S]*?)<\/span>/gi,(s,a,c)=>`[${c.replace(/<[^>]+>/g,"").trim()}](${a})`),e=e.replace(/<\/(?:div|section|header|footer|main|article|nav|aside)\b[^>]*>/gi,`
`),e=e.replace(/<(?:div|section|header|footer|main|article|nav|aside)\b[^>]*>/gi,""),e=e.replace(/<\/?span\b[^>]*>/gi,"");for(let s=0;s<l.length;s++)e=e.replace(`__VUE_COMP_TOKEN_${s}__`,l[s]);for(let s=0;s<r.length;s++)e=e.replace(`__VUE_DIV_TOKEN_${s}__`,r[s]);for(let s=0;s<o.length;s++)e=e.replace(`__SCRIPT_TOKEN_${s}__`,o[s]);for(let s=0;s<i.length;s++)e=e.replace(`__CODE_TOKEN_${s}__`,i[s]);return e=e.replace(/\n{3,}/g,`

`).trim(),e}function $r(t){if(!t||typeof t!="string")return"";const i=[];let e=t.replace(/`([^`]+)`/g,o=>(i.push(o),`%%INLINE_CODE_${i.length-1}%%`));return e=e.replace(/(<\/[a-zA-Z0-9_-]+>)\s*\{:[^}]*\}/g,"$1"),e=e.replace(/(\[[^\]]+\]\([^)]+\))\s*\{:\s*style=["']([^"']*)["'][^}]*\}/g,'<span style="$2">$1</span>'),e=e.replace(/(\*\*[^*]+\*\*)\s*\{:\s*style=["']([^"']*)["'][^}]*\}/g,'<span style="$2">$1</span>'),e=e.replace(/(\*[^*]+\*)\s*\{:\s*style=["']([^"']*)["'][^}]*\}/g,'<span style="$2">$1</span>'),e=e.replace(/(~~[^~]+~~)\s*\{:\s*style=["']([^"']*)["'][^}]*\}/g,'<span style="$2">$1</span>'),e=e.replace(/([\p{L}\p{N}_\-]+)\s*\{:\s*style=["']([^"']*)["'][^}]*\}/gu,'<span style="$2">$1</span>'),e=e.replace(/\{:[^}]*\}/g,""),e=e.replace(/%%INLINE_CODE_(\d+)%%/g,(o,n)=>i[parseInt(n,10)]||""),e}function za(t){const i=Object.entries(t).filter(([o,n])=>n!=null&&n!=="");return i.length===0?"":`---
${i.map(([o,n])=>typeof n=="string"?n.includes(":")||n.includes(`
`)||n.includes("#")?`${o}: "${n.replace(/"/g,'\\"')}"`:`${o}: ${n}`:`${o}: ${JSON.stringify(n)}`).join(`
`)}
---`}function Na(t,i){if(!i||!t.startsWith("```"))return t;const e=t.indexOf(`
`);if(e===-1)return t;const o=t.slice(0,e).trim(),n=t.slice(e);return o.includes("{")?t:`${o} {${i}}${n}`}function Fa(t,i){if(i==null)return t;const e=i.trim();return e===""||e==="+1"?`<v-click>

${t}

</v-click>`:e==="hide"?`<v-click hide>

${t}

</v-click>`:`<v-click at="${e}">

${t}

</v-click>`}function ja(t){if(!t||!t.preset)return null;const i=t.preset.toLowerCase().trim();if(!i||i==="none")return null;let e={opacity:0},o={opacity:1};switch(i){case"slide-up":e={y:40,opacity:0},o={y:0,opacity:1};break;case"slide-down":e={y:-40,opacity:0},o={y:0,opacity:1};break;case"slide-left":e={x:40,opacity:0},o={x:0,opacity:1};break;case"slide-right":e={x:-40,opacity:0},o={x:0,opacity:1};break;case"zoom-in":case"pop":e={scale:.8,opacity:0},o={scale:1,opacity:1};break;case"bounce":e={y:40,opacity:0},o={y:0,opacity:1,transition:{type:"spring",damping:10,stiffness:100}};break;case"fade-in":default:e={opacity:0},o={opacity:1};break}t.initial&&typeof t.initial=="object"&&(e={...e,...t.initial}),t.enter&&typeof t.enter=="object"&&(o={...o,...t.enter});const n={...o.transition||{}};return typeof t.duration=="number"&&t.duration>0&&(n.duration=t.duration),typeof t.delay=="number"&&t.delay>0&&(n.delay=t.delay),Object.keys(n).length>0&&(o.transition=n),{initial:e,enter:o}}function Bs(t,i,e,o){const n=i!=null&&i.trim()!=="",r=ja(e),l=o==null?void 0:o.trim(),s=l!==void 0&&l!=="",a=s?` style="${l.replace(/"/g,"&quot;")}" class="slide-styled-block"`:"";if(!n&&!r)return s?`<div${a}>

${t}

</div>`:t;if(n&&!r){if(s){const k=i.trim();let h="v-click";return k==="hide"?h="v-click.hide":k!==""&&k!=="+1"&&(h=`v-click="${k}"`),`<div ${h}${a}>

${t}

</div>`}return Fa(t,i)}const c=JSON.stringify(r.initial).replace(/"/g,"'"),d=JSON.stringify(r.enter).replace(/"/g,"'"),f=`v-motion :initial="${c}" :enter="${d}"`;if(!n)return`<div ${f}${a}>

${t}

</div>`;const g=i.trim();let u="v-click";return g==="hide"?u="v-click.hide":g!==""&&g!=="+1"&&(u=`v-click="${g}"`),`<div ${u} ${f}${a}>

${t}

</div>`}function Ir(t){if(!t)return"";let i=t.trim();i=i.replace(/\{:[^}]*\}/g,"").trim(),i=i.replace(/^:::\s*[a-zA-Z0-9_-]*\s*\r?\n?/g,""),i=i.replace(/\r?\n?:::\s*$/g,"");let n=i.split(/\r?\n/).map(r=>r.trim().replace(/^>\s*/,"")).join(`
`).trim();return n=n.replace(/^\[!(?:NOTE|TIP|IMPORTANT|WARNING|CAUTION|[A-Za-z_-]+)\][^\r\n]*(?:\r?\n)?/i,"").trim(),n=n.replace(/^(?:💡|✏️|❗|⚠️|🚨|\s*)*(?:\*\*|__)?(?:演讲备注|演讲者提词|讲稿备注|演讲提词|备注|Notes?)(?:\*\*|__)?[:：]?\s*(?:\r?\n)?/i,"").trim(),n=n.replace(/^[-*+]\s+/,""),n=n.replace(/^\d+\.\s+/,""),n.trim()}function Ha(t){var o;if(t.subType&&/^h([1-6])$/i.test(t.subType))return parseInt(t.subType.slice(1),10);const e=(t.markdown||t.content||"").trim().match(/^(#{1,6})\s+/);return e?e[1].length:t.type==="h"?(o=t.ial)!=null&&o.subType&&/^h([1-6])$/i.test(t.ial.subType)?parseInt(t.ial.subType.slice(1),10):1:null}function Ar(t){if(!t||t.length===0)return{col1:[],col2:[],col3:[]};if(t.length===1&&t[0].children&&t[0].children.length>=2){const l=t[0].children;if(l.length>=3){const s=Math.ceil(l.length/3),a=Math.ceil((l.length-s)/2);return{col1:l.slice(0,s),col2:l.slice(s,s+a),col3:l.slice(s+a)}}else return{col1:[l[0]],col2:[l[1]],col3:[]}}const i=l=>{const s=l.slot||"";return s==="col-1"||s==="left"?1:s==="col-2"||s==="center"?2:s==="col-3"||s==="right"?3:null},e=t.map(i);if(e.some(l=>l!==null)){const l=e.includes(2),s=e.includes(3);if(l||s){const d=[],f=[],g=[];let u=1;for(const k of t){const h=i(k);h!==null&&(u=h),u===1?d.push(k):u===2?f.push(k):g.push(k)}return{col1:d,col2:f,col3:g}}const a=t.filter(d=>i(d)===1),c=t.filter(d=>i(d)===null);if(c.length>=2){const d=Math.ceil(c.length/2);return{col1:a,col2:c.slice(0,d),col3:c.slice(d)}}else return c.length===1?{col1:a,col2:c,col3:[]}:{col1:a,col2:[],col3:[]}}const n=l=>{if(l.type==="h"||l.subType&&/^h[1-6]$/i.test(l.subType))return!0;const s=(l.rawMarkdown||l.content||"").trim();return/^#{1,6}\s+/.test(s)},r=t.map((l,s)=>n(l)?s:-1).filter(l=>l!==-1);if(r.length>=3)return{col1:t.slice(0,r[1]),col2:t.slice(r[1],r[2]),col3:t.slice(r[2])};if(t.length>=3){const l=Math.ceil(t.length/3),s=Math.ceil((t.length-l)/2);return{col1:t.slice(0,l),col2:t.slice(l,l+s),col3:t.slice(l+s)}}if(t.length===2)return{col1:[t[0]],col2:[t[1]],col3:[]};if(t.length===1){const l=t[0],s=(l.rawMarkdown||l.content||"").trim(),a=s.split(/\r?\n/),c=[];for(let g=0;g<a.length;g++)/^[ \t]*[-*+]\s+|^[ \t]*\d+\.\s+/.test(a[g])&&c.push(g);if(c.length>=3){const g=Math.ceil(c.length/3),u=Math.ceil((c.length-g)/2),k=a.slice(c[0],c[g]).join(`
`),h=a.slice(c[g],c[g+u]).join(`
`),y=a.slice(c[g+u]).join(`
`);return{col1:[{...l,rawMarkdown:k,content:k}],col2:[{...l,id:`${l.id}-col2`,rawMarkdown:h,content:h}],col3:[{...l,id:`${l.id}-col3`,rawMarkdown:y,content:y}]}}const d=s.match(/<li[\s\S]*?<\/li>/gi);if(d&&d.length>=3){const g=Math.ceil(d.length/3),u=Math.ceil((d.length-g)/2),k=`<ul>
${d.slice(0,g).join(`
`)}
</ul>`,h=`<ul>
${d.slice(g,g+u).join(`
`)}
</ul>`,y=`<ul>
${d.slice(g+u).join(`
`)}
</ul>`;return{col1:[{...l,rawMarkdown:k,content:k}],col2:[{...l,id:`${l.id}-col2`,rawMarkdown:h,content:h}],col3:[{...l,id:`${l.id}-col3`,rawMarkdown:y,content:y}]}}const f=s.split(/\r?\n\s*\r?\n/).filter(g=>g.trim()!=="");if(f.length>=3){const g=Math.ceil(f.length/3),u=Math.ceil((f.length-g)/2);return{col1:[{...l,rawMarkdown:f.slice(0,g).join(`

`),content:f.slice(0,g).join(`

`)}],col2:[{...l,id:`${l.id}-col2`,rawMarkdown:f.slice(g,g+u).join(`

`),content:f.slice(g,g+u).join(`

`)}],col3:[{...l,id:`${l.id}-col3`,rawMarkdown:f.slice(g+u).join(`

`),content:f.slice(g+u).join(`

`)}]}}}return{col1:t,col2:[],col3:[]}}function Ms(t,i,e,o){var d;const n=Aa(i),r=[],l=Es(i);let s={pageIndex:1,startBlockId:t,frontmatter:{layout:l.frontmatter.layout||"cover",...l.frontmatter},notes:"",noteBlocks:[],blocks:[],rawMarkdown:"",allBlockIds:[t]};s.frontmatter.background&&(s.frontmatter.background=ye(s.frontmatter.background,o)),s.frontmatter.image&&(s.frontmatter.image=ye(s.frontmatter.image,o)),r.push(s);let a=[];for(const f of e){if(qn(f)){a=[];const u=Es(f.ial);if(r.length===1&&s.blocks.length===0){s.startBlockId=f.id,s.allBlockIds||(s.allBlockIds=[]),s.allBlockIds.includes(f.id)||s.allBlockIds.push(f.id),u.frontmatter.layout&&(s.frontmatter.layout=u.frontmatter.layout),Object.assign(s.frontmatter,u.frontmatter),!u.frontmatter.image&&l.frontmatter.image&&(s.frontmatter.image=l.frontmatter.image),!u.frontmatter.background&&l.frontmatter.background&&(s.frontmatter.background=l.frontmatter.background),s.frontmatter.background&&(s.frontmatter.background=ye(s.frontmatter.background,o)),s.frontmatter.image&&(s.frontmatter.image=ye(s.frontmatter.image,o));continue}s={pageIndex:r.length+1,startBlockId:f.id,frontmatter:{layout:u.frontmatter.layout||"default",...u.frontmatter},notes:"",noteBlocks:[],blocks:[],rawMarkdown:"",allBlockIds:[f.id]},s.frontmatter.background&&(s.frontmatter.background=ye(s.frontmatter.background,o)),s.frontmatter.image&&(s.frontmatter.image=ye(s.frontmatter.image,o)),r.push(s);continue}const g=u=>{if(s.allBlockIds||(s.allBlockIds=[]),u.id&&!s.allBlockIds.includes(u.id)&&s.allBlockIds.push(u.id),u.children&&u.children.length>0){const A=v=>{for(const O of v)O.id&&!s.allBlockIds.includes(O.id)&&s.allBlockIds.push(O.id),O.children&&O.children.length>0&&A(O.children)};A(u.children)}let k=_a(u),h=u.ial?{...u.ial}:{};const y=k.match(/\{:\s*([^}]+)\s*\}\s*$/);y&&(h={...Sa(y[0]),...h},k=k.slice(0,y.index).trim()),u.type!=="c"&&!k.startsWith("```")&&(k=$r(k));let b=k.trim();if(/^\{\{\{(?:row|col)?\s*$/i.test(b)||b==="}}}")return;/^\{\{\{(?:row|col)?\s*\r?\n/i.test(b)&&/\r?\n\}\}\}$/.test(b)&&(k=b.replace(/^\{\{\{(?:row|col)?\s*\r?\n/i,"").replace(/\r?\n\}\}\}$/,"").trim(),b=k.trim());const w=Ta(h);if(k=Ia(k,o),k=xa(k,o==null?void 0:o.refContentMap),u.children&&u.children.length>0){const A=v=>{for(const O of v){if(O.ial)for(const[z,P]of Object.entries(O.ial))z.startsWith("custom-slidev-")&&!h[z]&&(h[z]=P);O.children&&O.children.length>0&&A(O.children)}};A(u.children)}const S=u.type==="video"||u.type==="NodeVideo"||/<video\b/i.test(k);if(S){const A=h["custom-slidev-autoplay"]==="true",v=h["custom-slidev-loop"]==="true",O=h["custom-slidev-muted"]==="true"||A,z=h["custom-slidev-controls"]==="false";k=k.replace(/<video\b([^>]*)>/gi,(P,K)=>{let H=K;return z?H=H.replace(/\bcontrols(?:="[^"]*")?/gi,"").trim():/controls/i.test(H)||(H+=" controls"),A&&!/autoplay/i.test(H)?H+=" autoplay playsinline":!A&&h["custom-slidev-autoplay"]==="false"&&(H=H.replace(/\bautoplay\b/gi,"").replace(/\bplaysinline\b/gi,"").trim()),v&&!/loop/i.test(H)?H+=" loop":!v&&h["custom-slidev-loop"]==="false"&&(H=H.replace(/\bloop\b/gi,"").trim()),O&&!/muted/i.test(H)?H+=" muted":!O&&h["custom-slidev-muted"]==="false"&&(H=H.replace(/\bmuted\b/gi,"").trim()),`<video ${H.trim()}>`})}if(w.isBackground){const A=li(k,u.content);if(A){s.frontmatter.background=ye(A,o);return}}const T=ai(u);if(T){s.frontmatter.layout=T.layout,s.frontmatter.image=ye(T.imageUrl,o);for(const A of T.contentNodes)g(A);return}if(w.imageLayout==="image-left"||w.imageLayout==="image-right"){const A=li(k,u.content);if(A){s.frontmatter.layout=w.imageLayout,s.frontmatter.image=ye(A,o);return}}if(re(u)&&u.children&&u.children.length>0){for(const A of u.children)g(A);return}if((u.type==="l"||u.type==="NodeList"||u.type==="list")&&u.children&&u.children.length>0&&(u.children.some(A=>{var v;return(v=A.ial)==null?void 0:v[At]})||w.slot)){for(const A of u.children)w.slot&&(!A.ial||!A.ial[At])&&(A.ial||(A.ial={}),A.ial[At]=w.slot),g(A);return}if(w.isNote){const A=Ir(k);A&&(s.notes?s.notes+=`

`+A:s.notes=A),s.noteBlocks||(s.noteBlocks=[]),s.noteBlocks.push({id:u.id,type:u.type,content:A||u.content||"",rawMarkdown:k,isNote:!0,attributes:u.ial});return}w.shikiLines&&(k=Na(k,w.shikiLines)),b=k.trim();const x=(u.content||"").trim();if(b==="::right::"||x==="::right::"||/^<p>\s*::right::\s*<\/p>$/i.test(b)||b.startsWith("::right::")){s.blocks.push({id:u.id,type:u.type,content:"::right::",rawMarkdown:"::right::",slot:"slot-divider-right",attributes:u.ial});return}const I=Ha(u);let L=w.slot,M=w.clicks,F=w.motion,J={...u.ial||{}};if(I!==null){for(;a.length>0&&a[a.length-1].level>=I;)a.pop();const A=a.length>0?a[a.length-1]:void 0;!L&&(A!=null&&A.slot)&&(L=A.slot),!M&&(A!=null&&A.clicks)&&(M=A.clicks),!F&&(A!=null&&A.motion)&&(F=A.motion);const v={...(A==null?void 0:A.customAttrs)||{}};if(u.ial)for(const[O,z]of Object.entries(u.ial))O.startsWith("custom-slidev-")&&!O.startsWith("custom-slidev-slide")&&(v[O]=z);a.push({level:I,slot:L,clicks:M,motion:F,customAttrs:v})}else{const A=a.length>0?a[a.length-1]:void 0;A&&(!L&&A.slot&&A.slot!=="header"&&(L=A.slot),!M&&A.clicks&&(M=A.clicks),!F&&A.motion&&(F=A.motion),A.customAttrs&&(J={...A.customAttrs,...J}))}!L&&s.blocks.some(A=>A.slot==="slot-divider-right")&&(L="right"),L&&(J[At]=L),M&&!J[ke]&&(J[ke]=M),F&&!J[Ne]&&(J[Ne]=JSON.stringify(F)),(S||h["custom-slidev-autoplay"]||h["custom-slidev-muted"])&&(h["custom-slidev-autoplay"]&&(J["custom-slidev-autoplay"]=h["custom-slidev-autoplay"],h["custom-slidev-autoplay"]==="true"&&!h["custom-slidev-muted"]&&(J["custom-slidev-muted"]="true")),h["custom-slidev-loop"]&&(J["custom-slidev-loop"]=h["custom-slidev-loop"]),h["custom-slidev-muted"]&&(J["custom-slidev-muted"]=h["custom-slidev-muted"]),h["custom-slidev-controls"]&&(J["custom-slidev-controls"]=h["custom-slidev-controls"]));const E={id:u.id,type:u.type,content:u.content||"",rawMarkdown:k,clicks:M,motion:F,shikiLines:w.shikiLines,slot:L,attributes:J};s.blocks.push(E)};g(f)}for(let f=0;f<r.length;f++){const g=r[f],u=[],k={...g.frontmatter};f===0&&(k.theme=n.theme,k.aspectRatio=n.aspectRatio,k.highlighter=n.highlighter,k.transition=g.frontmatter.transition||n.defaultTransition);const h=za(k);h&&u.push(h);const y=g.blocks.filter(x=>x.slot!=="slot-divider-right"),b=x=>x.filter(_=>!!(_.rawMarkdown||_.content||"").trim()).map(_=>{var I;return Bs(_.rawMarkdown,_.clicks,_.motion,(I=_.attributes)==null?void 0:I.style)}).join(`

`),w=x=>{const _=x.filter(F=>!!(F.rawMarkdown||F.content||"").trim());if(_.length===0)return;const I=_[0],L=(I.rawMarkdown||I.content||"").trim();(ji(I)||/^(?:[-*+]|\d+\.)\s+/.test(L))&&(I.rawMarkdown=Oo(I.rawMarkdown||I.content||""),I.content=I.rawMarkdown)},S=x=>x.length===0?"":(w(x),b(x)),T=g.frontmatter.layout||"default";if(T==="two-cols-header"){let x=[];const _=y.filter(A=>A.slot==="header");if(_.length>0)x=_;else if(y.length>0){const A=y.find(v=>v.type==="h"&&(!v.slot||v.slot==="default"));A&&(x=[A])}const I=y.filter(A=>!x.includes(A)),L=I.filter(A=>A.slot==="right"||A.slot==="col-2"),M=I.filter(A=>!L.includes(A));w(M),w(L);const F=b(x),J=S(M),E=S(L);F&&u.push(F),J&&u.push(`::left::

${J}`),E&&u.push(`::right::

${E}`)}else if(T==="three-cols-header"){let x=[];const _=y.filter(z=>z.slot==="header");if(_.length>0)x=_;else if(y.length>0){const z=y.find(P=>P.type==="h"&&(!P.slot||P.slot==="default"));z&&(x=[z])}const I=y.filter(z=>!x.includes(z)),L=Ar(I),M=L.col1,F=L.col2,J=L.col3;for(const z of M)z.slot||(z.slot="col-1");for(const z of F)z.slot||(z.slot="col-2");for(const z of J)z.slot||(z.slot="col-3");if(w(M),w(F),w(J),I.length===1&&(F.length>0||J.length>0)){const z=g.blocks.findIndex(P=>P.id===I[0].id);z!==-1&&g.blocks.splice(z,1,...M,...F,...J)}const E=b(x),A=S(M),v=S(F),O=S(J);E&&u.push(E),A&&u.push(`::col-1::

${A}`),v&&u.push(`::col-2::

${v}`),O&&u.push(`::col-3::

${O}`)}else if(T==="two-cols"){const x=y.filter(M=>M.slot==="left"),_=y.filter(M=>M.slot==="right");w(x),w(_);const I=b(x.length>0?x:y.filter(M=>M.slot!=="right")),L=b(_);u.push(I),L&&u.push(`::right::

${L}`)}else for(const x of y)u.push(Bs(x.rawMarkdown,x.clicks,x.motion,(d=x.attributes)==null?void 0:d.style));g.notes&&u.push(`<!--
${g.notes}
-->`),g.rawMarkdown=u.join(`

`).trim()}const c=r.map(f=>f.rawMarkdown).filter(Boolean).join(`

---

`);return{docId:t,config:n,slides:r,fullMarkdown:c}}const zo=`/* SiYuan Note Built-in Font & Background Styles for Slidev */
:root,
html:not(.dark),
[data-theme="light"],
[data-theme-mode="light"] {
  /* 思源基础卡片与主题色 (浅色模式 daylight) */
  --b3-card-error-color: #790600;
  --b3-card-error-background: #f5d1cf;
  --b3-card-warning-color: #8a4f00;
  --b3-card-warning-background: #ffe8c8;
  --b3-card-info-color: #005599;
  --b3-card-info-background: #d6eaf9;
  --b3-card-success-color: #006b04;
  --b3-card-success-background: #d7eed8;

  --b3-theme-primary: #3575f0;
  --b3-theme-secondary: #ff9200;
  --b3-theme-error: #d23f31;
  --b3-theme-background: #ffffff;
  --b3-theme-on-background: #222222;
  --b3-theme-on-surface: #5f6368;
  --b3-theme-surface-lighter: #e0e0e0;

  /* 13 种内置文字颜色 */
  --b3-font-color1: var(--b3-card-error-color);
  --b3-font-color2: var(--b3-card-warning-color);
  --b3-font-color3: var(--b3-card-info-color);
  --b3-font-color4: var(--b3-card-success-color);
  --b3-font-color5: var(--b3-theme-on-surface);
  --b3-font-color6: var(--b3-theme-primary);
  --b3-font-color7: var(--b3-theme-secondary);
  --b3-font-color8: var(--b3-theme-error);
  --b3-font-color9: #a40074;
  --b3-font-color10: #007080;
  --b3-font-color11: #006e2a;
  --b3-font-color12: #6b5a00;
  --b3-font-color13: var(--b3-theme-background);

  /* 13 种内置背景颜色 */
  --b3-font-background1: var(--b3-card-error-background);
  --b3-font-background2: var(--b3-card-warning-background);
  --b3-font-background3: var(--b3-card-info-background);
  --b3-font-background4: var(--b3-card-success-background);
  --b3-font-background5: #e2e3e4;
  --b3-font-background6: #acd0fc;
  --b3-font-background7: #fddaab;
  --b3-font-background8: #ffb0a9;
  --b3-font-background9: #fdbfff;
  --b3-font-background10: #b1ffff;
  --b3-font-background11: #affad1;
  --b3-font-background12: #fff88f;
  --b3-font-background13: var(--b3-theme-on-background);
}

html.dark,
[data-theme="dark"],
[data-theme-mode="dark"],
.theme-dark,
.dark {
  /* 思源基础卡片与主题色 (深色模式 midnight) */
  --b3-card-error-color: rgb(243, 153, 147);
  --b3-card-error-background: #442724;
  --b3-card-warning-color: rgb(255, 213, 153);
  --b3-card-warning-background: #554636;
  --b3-card-info-color: rgb(166, 213, 250);
  --b3-card-info-background: #28405c;
  --b3-card-success-color: rgb(183, 223, 185);
  --b3-card-success-background: #425347;

  --b3-theme-primary: #3575f0;
  --b3-theme-secondary: #ff9200;
  --b3-theme-error: #d23f31;
  --b3-theme-background: #1e1e1e;
  --b3-theme-on-background: #c8ccd6;
  --b3-theme-on-surface: #8b949e;
  --b3-theme-surface-lighter: #282a2e;

  /* 13 种内置文字颜色 */
  --b3-font-color1: var(--b3-card-error-color);
  --b3-font-color2: var(--b3-card-warning-color);
  --b3-font-color3: var(--b3-card-info-color);
  --b3-font-color4: var(--b3-card-success-color);
  --b3-font-color5: var(--b3-theme-on-surface);
  --b3-font-color6: var(--b3-theme-primary);
  --b3-font-color7: var(--b3-theme-secondary);
  --b3-font-color8: var(--b3-theme-error);
  --b3-font-color9: #f47c9c;
  --b3-font-color10: #4dd0e1;
  --b3-font-color11: #10df54;
  --b3-font-color12: #ecd424;
  --b3-font-color13: var(--b3-theme-background);

  /* 13 种内置背景颜色 */
  --b3-font-background1: var(--b3-card-error-background);
  --b3-font-background2: var(--b3-card-warning-background);
  --b3-font-background3: var(--b3-card-info-background);
  --b3-font-background4: var(--b3-card-success-background);
  --b3-font-background5: #3a3f42;
  --b3-font-background6: #031840;
  --b3-font-background7: #593905;
  --b3-font-background8: #3a0c09;
  --b3-font-background9: #4d1b40;
  --b3-font-background10: #1a5459;
  --b3-font-background11: #305415;
  --b3-font-background12: #4a4712;
  --b3-font-background13: var(--b3-theme-on-background);
}

@media (prefers-color-scheme: dark) {
  :root:not([data-theme="light"]):not([data-theme-mode="light"]):not(.light) {
    --b3-card-error-color: rgb(243, 153, 147);
    --b3-card-error-background: #442724;
    --b3-card-warning-color: rgb(255, 213, 153);
    --b3-card-warning-background: #554636;
    --b3-card-info-color: rgb(166, 213, 250);
    --b3-card-info-background: #28405c;
    --b3-card-success-color: rgb(183, 223, 185);
    --b3-card-success-background: #425347;

    --b3-theme-primary: #3575f0;
    --b3-theme-secondary: #ff9200;
    --b3-theme-error: #d23f31;
    --b3-theme-background: #1e1e1e;
    --b3-theme-on-background: #c8ccd6;
    --b3-theme-on-surface: #8b949e;
    --b3-theme-surface-lighter: #282a2e;

    --b3-font-color1: var(--b3-card-error-color);
    --b3-font-color2: var(--b3-card-warning-color);
    --b3-font-color3: var(--b3-card-info-color);
    --b3-font-color4: var(--b3-card-success-color);
    --b3-font-color5: var(--b3-theme-on-surface);
    --b3-font-color6: var(--b3-theme-primary);
    --b3-font-color7: var(--b3-theme-secondary);
    --b3-font-color8: var(--b3-theme-error);
    --b3-font-color9: #f47c9c;
    --b3-font-color10: #4dd0e1;
    --b3-font-color11: #10df54;
    --b3-font-color12: #ecd424;
    --b3-font-color13: var(--b3-theme-background);

    --b3-font-background1: var(--b3-card-error-background);
    --b3-font-background2: var(--b3-card-warning-background);
    --b3-font-background3: var(--b3-card-info-background);
    --b3-font-background4: var(--b3-card-success-background);
    --b3-font-background5: #3a3f42;
    --b3-font-background6: #031840;
    --b3-font-background7: #593905;
    --b3-font-background8: #3a0c09;
    --b3-font-background9: #4d1b40;
    --b3-font-background10: #1a5459;
    --b3-font-background11: #305415;
    --b3-font-background12: #4a4712;
    --b3-font-background13: var(--b3-theme-on-background);
  }
}

/* 演示块级样式排版增强 (带背景色时赋予呼吸内边距与舒适圆角) */
.slide-styled-block {
  border-radius: 6px;
  padding: 8px 14px;
  box-sizing: border-box;
  margin: 6px 0;
  transition: background-color 0.2s ease, color 0.2s ease;
}

/* 行内带背景色文本的精美圆角与微边距 */
span[style*="background-color"],
span[style*="background:"] {
  border-radius: 3px;
  padding: 1px 5px;
  box-decoration-break: clone;
  -webkit-box-decoration-break: clone;
}
`;function Ua(t){var n,r,l,s,a,c,d,f,g,u,k,h;if(!t||typeof t!="object")return"";const i=[],e=[];if(Array.isArray(t.styles))for(const y of t.styles){if(!y||!y.id)continue;const b=`--b3-inline-style-${y.id}`;(n=y.light)!=null&&n.color&&i.push(`  ${b}-color: ${y.light.color};`),(r=y.light)!=null&&r.backgroundColor&&i.push(`  ${b}-background-color: ${y.light.backgroundColor};`),(l=y.dark)!=null&&l.color&&e.push(`  ${b}-color: ${y.dark.color};`),(s=y.dark)!=null&&s.backgroundColor&&e.push(`  ${b}-background-color: ${y.dark.backgroundColor};`)}if(t.builtin&&Array.isArray(t.builtin.colors))for(const y of t.builtin.colors){if(!y||typeof y.index!="number")continue;const b=y.index;(a=y.light)!=null&&a.color&&i.push(`  --b3-font-color${b}: ${y.light.color};`),(c=y.light)!=null&&c.backgroundColor&&i.push(`  --b3-font-background${b}: ${y.light.backgroundColor};`),(d=y.dark)!=null&&d.color&&e.push(`  --b3-font-color${b}: ${y.dark.color};`),(f=y.dark)!=null&&f.backgroundColor&&e.push(`  --b3-font-background${b}: ${y.dark.backgroundColor};`)}if(t.builtin&&Array.isArray(t.builtin.styles))for(const y of t.builtin.styles){if(!y||!y.id)continue;const b=y.id;(g=y.light)!=null&&g.color&&i.push(`  --b3-card-${b}-color: ${y.light.color};`),(u=y.light)!=null&&u.backgroundColor&&i.push(`  --b3-card-${b}-background: ${y.light.backgroundColor};`),(k=y.dark)!=null&&k.color&&e.push(`  --b3-card-${b}-color: ${y.dark.color};`),(h=y.dark)!=null&&h.backgroundColor&&e.push(`  --b3-card-${b}-background: ${y.dark.backgroundColor};`)}if(i.length===0&&e.length===0)return"";const o=[];return i.length>0&&o.push(`:root, html:not(.dark), [data-theme="light"] {
${i.join(`
`)}
}`),e.length>0&&o.push(`html.dark, [data-theme="dark"], .dark {
${e.join(`
`)}
}`),o.join(`

`)}function on(t){const i=Ua(t);return i?`${zo}

/* Custom Workspace Inline Styles */
${i}`:zo}function ko(t){const i={};if(!t||typeof t!="string")return i;const e=t.replace(/^\{:\s*/,"").replace(/\s*\}$/,""),o=/([\w-]+)=(?:"([^"]*)"|'([^']*)'|(\S+))/g;let n;for(;(n=o.exec(e))!==null;){const r=n[1],l=n[2]??n[3]??n[4]??"";i[r]=l}return i}const Wa={getBlockAttrs:Ue,getChildBlocks:Hn,setBlockAttrs:Dt,sql:dn,getBaseUrl:()=>typeof location<"u"?location.origin:"",getInlineStyles:ka};class Va{constructor(i){kt(this,"deps");kt(this,"attrOverrides",new Map);kt(this,"trackedListSuperBlocks",new Map);this.deps={...Wa,...i||{}}}setBlockAttrOverride(i,e){if(!i||!e)return;const n={...this.attrOverrides.get(i)||{}};for(const[r,l]of Object.entries(e))l===""||l===null||l===void 0?delete n[r]:n[r]=String(l);Object.keys(n).length===0?this.attrOverrides.delete(i):this.attrOverrides.set(i,n)}getBlockAttrOverride(i){return this.attrOverrides.get(i)}getAllAttrOverrides(){return new Map(this.attrOverrides)}getTrackedListSuperBlocks(i){return this.trackedListSuperBlocks.get(i)||[]}clearBlockAttrOverride(i,e){if(!i)return;if(!e){this.attrOverrides.delete(i);return}const o=this.attrOverrides.get(i);o&&(delete o[e],Object.keys(o).length===0&&this.attrOverrides.delete(i))}clearAllOverrides(){this.attrOverrides.clear(),this.trackedListSuperBlocks.clear()}async compile(i){try{const e=await this.deps.getBlockAttrs(i).catch(()=>({}))||{},o=this.attrOverrides.get(i);o&&Object.assign(e,o);let n=await this.deps.getChildBlocks(i).catch(()=>[]);const r=`SELECT id, ial FROM blocks WHERE root_id = '${i}' LIMIT 99999`,l=await this.deps.sql(r).catch(()=>[])||[],s=new Map;if(Array.isArray(l))for(const S of l)S.id&&S.ial&&s.set(S.id,ko(S.ial));const a=`SELECT block_id, name, value FROM attributes WHERE root_id = '${i}' AND type = 'b' LIMIT 99999`,c=await this.deps.sql(a).catch(()=>[])||[];if(Array.isArray(c)){for(const S of c)if(S.block_id&&S.name){let T=s.get(S.block_id);T||(T={},s.set(S.block_id,T)),T[S.name]=S.value||""}}if(!n||n.length===0){const S=`SELECT id, parent_id, root_id, type, sub_type as subType, content, markdown, ial FROM blocks WHERE root_id = '${i}' AND id != '${i}' ORDER BY created ASC LIMIT 99999`;n=await this.deps.sql(S).catch(()=>[])||[]}const d=(n||[]).map(S=>{const T=s.get(S.id)||(S.ial?ko(S.ial):{}),x=this.attrOverrides.get(S.id);return x&&Object.assign(T,x),{id:S.id,parent_id:S.parent_id,root_id:S.root_id||i,type:S.type,subType:S.subType,content:S.content||"",markdown:S.markdown||"",ial:T,children:S.children}}),f=async(S,T=0)=>{if(!(!S||S.length===0||T>8))for(const x of S){if((re(x)||x.type==="l"||x.type==="NodeList"||x.type==="i"||x.type==="NodeListItem"||x.type==="b"||x.type==="NodeBlockquote")&&(!x.children||x.children.length===0)){let I=await this.deps.getChildBlocks(x.id).catch(()=>[]);if(!I||I.length===0){const L=`SELECT id, parent_id, root_id, type, sub_type as subType, content, markdown, ial FROM blocks WHERE parent_id = '${x.id}' ORDER BY sort ASC, created ASC`;I=await this.deps.sql(L).catch(()=>[])||[]}Array.isArray(I)&&I.length>0&&(x.children=I.map(L=>{const M=s.get(L.id)||(L.ial?ko(L.ial):{}),F=this.attrOverrides.get(L.id);return F&&Object.assign(M,F),{id:L.id,parent_id:L.parent_id||x.id,root_id:L.root_id||i,type:L.type,subType:L.subType,content:L.content||"",markdown:L.markdown||"",ial:M}}))}x.children&&x.children.length>0&&await f(x.children,T+1)}};await f(d);const g=S=>{var T,x;for(const _ of S)if(_.children&&_.children.length>0){g(_.children);for(const I of _.children)if(I.ial)for(const[L,M]of Object.entries(I.ial))L.startsWith("custom-slidev-")&&!((T=_.ial)!=null&&T[L])&&(_.ial||(_.ial={}),_.ial[L]=M);if(_.ial){for(const[I,L]of Object.entries(_.ial))if(I.startsWith("custom-slidev-"))for(const M of _.children)(M.type==="video"||M.type==="NodeVideo"||/<video\b/i.test(M.markdown||M.content||""))&&!((x=M.ial)!=null&&x[I])&&(M.ial||(M.ial={}),M.ial[I]=L)}}};g(d),La(d,S=>{this.setBlockAttrOverride(S.blockId,{[dt]:S.layout}),(this.deps.setBlockAttrs||Dt)(S.blockId,{[dt]:S.layout}).catch(x=>{console.warn("[DocumentCompiler] Failed to auto-tag superblock image layout:",x)})});const u=this.trackedListSuperBlocks.get(i)||[],k=Da(i,d,{tracked:u,onTagChange:S=>{this.setBlockAttrOverride(S.blockId,S.attrs),S.blockId===i&&Object.assign(e,S.attrs);const T=_=>{for(const I of _)I.id===S.blockId&&(I.ial||(I.ial={}),Object.assign(I.ial,S.attrs)),I.children&&I.children.length>0&&T(I.children)};T(d),(this.deps.setBlockAttrs||Dt)(S.blockId,S.attrs).catch(_=>{console.warn("[DocumentCompiler] Failed to auto-tag list superblock attrs:",_)})}});this.trackedListSuperBlocks.set(i,k.newTracked);const h=new Set;for(const S of d){const T=S.markdown||S.content||"";if(T.includes("((")){const x=wa(T);for(const _ of x)h.add(_.blockId)}}const y={};if(h.size>0){const S=Array.from(h).map(x=>`'${x}'`).join(","),T=await this.deps.sql(`SELECT id, content, markdown FROM blocks WHERE id IN (${S})`).catch(()=>[])||[];if(Array.isArray(T))for(const x of T)x.id&&(y[x.id]=x.markdown||x.content||"")}const b=this.deps.getBaseUrl?this.deps.getBaseUrl():"",w=Ms(i,e,d,{baseUrl:b,refContentMap:y});try{const S=this.deps.getInlineStyles?await this.deps.getInlineStyles().catch(()=>null):null;w.customThemeCss=on(S)}catch{w.customThemeCss=on(null)}return w}catch(e){console.error("[DocumentCompilerService] Failed to compile document:",e);const o=Ms(i,{},[],{});return o.customThemeCss=on(null),o}}}const Rt=new Va;class ts{constructor(i){kt(this,"devServerUrl","http://localhost:3030");kt(this,"isConnected",!1);kt(this,"lastSyncTime",null);i&&(this.devServerUrl=i)}getUrl(){return this.devServerUrl}setUrl(i){this.devServerUrl=i.replace(/\/+$/,"")}isServerConnected(){return this.isConnected}getLastSyncTime(){return this.lastSyncTime}async probeServer(i=1500){try{const e=new AbortController,o=setTimeout(()=>e.abort(),i),n=await fetch(this.devServerUrl,{method:"HEAD",mode:"no-cors",signal:e.signal}).catch(()=>null);return clearTimeout(o),this.isConnected=!!n,this.isConnected}catch{return this.isConnected=!1,!1}}buildStandardSlidevMarkdown(i){const e=i.config,o=["---",`theme: ${e.theme||"default"}`,`aspectRatio: "${e.aspectRatio||"16/9"}"`,`highlighter: ${e.highlighter||"shiki"}`,`transition: ${e.defaultTransition||"slide-left"}`];e.colorSchema&&e.colorSchema!=="auto"&&o.push(`colorSchema: ${e.colorSchema}`),o.push("drawings:","  persist: false","---","");const n=o.join(`
`),r=i.slides.map((l,s)=>{const a=l.frontmatter||{},c=[],d=s===0;a.layout&&a.layout!=="default"&&c.push(`layout: ${a.layout}`),a.transition&&c.push(`transition: ${a.transition}`),a.background&&c.push(`background: ${a.background}`),a.class&&c.push(`class: "${a.class}"`);let f="";c.length>0?f=d?"":`---
${c.join(`
`)}
---

`:d||(f=`---

`);let g="";if(a.layout==="two-cols"){const k=l.blocks.filter(w=>w.slot!=="right"),h=l.blocks.filter(w=>w.slot==="right"),y=k.map(w=>w.rawMarkdown||w.content||"").join(`

`),b=h.map(w=>w.rawMarkdown||w.content||"").join(`

`);g=`${y}

::right::

${b}`}else g=l.blocks.map(k=>k.rawMarkdown||k.content||"").join(`

`);let u="";return l.notes&&l.notes.trim()&&(u=`

<!--
${l.notes.trim()}
-->`),`${f}${g}${u}`}).join(`

`);return`${n}${r}
`}async syncToWorkspaceFile(i,e="/data/storage/petal/siyuan-slidev/slides.md",o){const n=this.buildStandardSlidevMarkdown(i);if(this.lastSyncTime=Date.now(),o)try{const r=typeof Blob<"u"?new Blob([n],{type:"text/markdown;charset=utf-8"}):Buffer.from(n,"utf-8");return await o(e,!1,r),{success:!0,path:e}}catch(r){return{success:!1,path:e,error:String(r)}}return{success:!0,path:e}}downloadSlidesMd(i,e="slides.md"){if(typeof window>"u"||typeof document>"u")return!1;const o=this.buildStandardSlidevMarkdown(i),n=new Blob([o],{type:"text/markdown;charset=utf-8"}),r=URL.createObjectURL(n),l=document.createElement("a");return l.href=r,l.download=e,document.body.appendChild(l),l.click(),document.body.removeChild(l),URL.revokeObjectURL(r),!0}}/**
* @vue/shared v3.5.40
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/function es(t){const i=Object.create(null);for(const e of t.split(","))i[e]=1;return e=>e in i}const Nt={},Pi=[],Fe=()=>{},Tr=()=>!1,no=t=>t.charCodeAt(0)===111&&t.charCodeAt(1)===110&&(t.charCodeAt(2)>122||t.charCodeAt(2)<97),oo=t=>t.startsWith("onUpdate:"),ie=Object.assign,is=(t,i)=>{const e=t.indexOf(i);e>-1&&t.splice(e,1)},Ka=Object.prototype.hasOwnProperty,Bt=(t,i)=>Ka.call(t,i),Ct=Array.isArray,Oi=t=>xn(t)==="[object Map]",Ki=t=>xn(t)==="[object Set]",Ds=t=>xn(t)==="[object Date]",It=t=>typeof t=="function",Gt=t=>typeof t=="string",Ae=t=>typeof t=="symbol",Ot=t=>t!==null&&typeof t=="object",Er=t=>(Ot(t)||It(t))&&It(t.then)&&It(t.catch),Br=Object.prototype.toString,xn=t=>Br.call(t),qa=t=>xn(t).slice(8,-1),Mr=t=>xn(t)==="[object Object]",ns=t=>Gt(t)&&t!=="NaN"&&t[0]!=="-"&&""+parseInt(t,10)===t,sn=es(",key,ref,ref_for,ref_key,onVnodeBeforeMount,onVnodeMounted,onVnodeBeforeUpdate,onVnodeUpdated,onVnodeBeforeUnmount,onVnodeUnmounted"),so=t=>{const i=Object.create(null);return(e=>i[e]||(i[e]=t(e)))},Ga=/-\w/g,ce=so(t=>t.replace(Ga,i=>i.slice(1).toUpperCase())),Za=/\B([A-Z])/g,ci=so(t=>t.replace(Za,"-$1").toLowerCase()),ro=so(t=>t.charAt(0).toUpperCase()+t.slice(1)),wo=so(t=>t?`on${ro(t)}`:""),Re=(t,i)=>!Object.is(t,i),On=(t,...i)=>{for(let e=0;e<t.length;e++)t[e](...i)},Dr=(t,i,e,o=!1)=>{Object.defineProperty(t,i,{configurable:!0,enumerable:!1,writable:o,value:e})},lo=t=>{const i=parseFloat(t);return isNaN(i)?t:i};let Ls;const ao=()=>Ls||(Ls=typeof globalThis<"u"?globalThis:typeof self<"u"?self:typeof window<"u"?window:typeof global<"u"?global:{});function os(t){if(Ct(t)){const i={};for(let e=0;e<t.length;e++){const o=t[e],n=Gt(o)?Qa(o):os(o);if(n)for(const r in n)i[r]=n[r]}return i}else if(Gt(t)||Ot(t))return t}const Ya=/;(?![^(]*\))/g,Ja=/:([^]+)/,Xa=/\/\*[^]*?\*\//g;function Qa(t){const i={};return t.replace(Xa,"").split(Ya).forEach(e=>{if(e){const o=e.split(Ja);o.length>1&&(i[o[0].trim()]=o[1].trim())}}),i}function $t(t){let i="";if(Gt(t))i=t;else if(Ct(t))for(let e=0;e<t.length;e++){const o=$t(t[e]);o&&(i+=o+" ")}else if(Ot(t))for(const e in t)t[e]&&(i+=e+" ");return i.trim()}const tc="itemscope,allowfullscreen,formnovalidate,ismap,nomodule,novalidate,readonly",ec=es(tc);function Lr(t){return!!t||t===""}function ic(t,i){if(t.length!==i.length)return!1;let e=!0;for(let o=0;e&&o<t.length;o++)e=qi(t[o],i[o]);return e}function qi(t,i){if(t===i)return!0;let e=Ds(t),o=Ds(i);if(e||o)return e&&o?t.getTime()===i.getTime():!1;if(e=Ae(t),o=Ae(i),e||o)return t===i;if(e=Ct(t),o=Ct(i),e||o)return e&&o?ic(t,i):!1;if(e=Ot(t),o=Ot(i),e||o){if(!e||!o)return!1;const n=Object.keys(t).length,r=Object.keys(i).length;if(n!==r)return!1;for(const l in t){const s=t.hasOwnProperty(l),a=i.hasOwnProperty(l);if(s&&!a||!s&&a||!qi(t[l],i[l]))return!1}}return String(t)===String(i)}function ss(t,i){return t.findIndex(e=>qi(e,i))}const Pr=t=>!!(t&&t.__v_isRef===!0),_t=t=>Gt(t)?t:t==null?"":Ct(t)||Ot(t)&&(t.toString===Br||!It(t.toString))?Pr(t)?_t(t.value):JSON.stringify(t,Or,2):String(t),Or=(t,i)=>Pr(i)?Or(t,i.value):Oi(i)?{[`Map(${i.size})`]:[...i.entries()].reduce((e,[o,n],r)=>(e[xo(o,r)+" =>"]=n,e),{})}:Ki(i)?{[`Set(${i.size})`]:[...i.values()].map(e=>xo(e))}:Ae(i)?xo(i):Ot(i)&&!Ct(i)&&!Mr(i)?String(i):i,xo=(t,i="")=>{var e;return Ae(t)?`Symbol(${(e=t.description)!=null?e:i})`:t};/**
* @vue/reactivity v3.5.40
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/let Xt;class nc{constructor(i=!1){this.detached=i,this._active=!0,this._on=0,this.effects=[],this.cleanups=[],this._isPaused=!1,this._warnOnRun=!0,this.__v_skip=!0,!i&&Xt&&(Xt.active?(this.parent=Xt,this.index=(Xt.scopes||(Xt.scopes=[])).push(this)-1):(this._active=!1,this._warnOnRun=!1))}get active(){return this._active}pause(){if(this._active){this._isPaused=!0;let i,e;if(this.scopes){const o=this.scopes.slice();for(i=0,e=o.length;i<e;i++)o[i].pause()}for(i=0,e=this.effects.length;i<e;i++)this.effects[i].pause()}}resume(){if(this._active&&this._isPaused){this._isPaused=!1;let i,e;if(this.scopes){const n=this.scopes.slice();for(i=0,e=n.length;i<e;i++)n[i].resume()}const o=this.effects.slice();for(i=0,e=o.length;i<e;i++)o[i].resume()}}run(i){if(this._active){const e=Xt;try{return Xt=this,i()}finally{Xt=e}}}on(){++this._on===1&&(this.prevScope=Xt,Xt=this)}off(){if(this._on>0&&--this._on===0){if(Xt===this)Xt=this.prevScope;else{let i=Xt;for(;i;){if(i.prevScope===this){i.prevScope=this.prevScope;break}i=i.prevScope}}this.prevScope=void 0}}stop(i){if(this._active){this._active=!1;let e,o;for(e=0,o=this.effects.length;e<o;e++)this.effects[e].stop();for(this.effects.length=0,e=0,o=this.cleanups.length;e<o;e++)this.cleanups[e]();if(this.cleanups.length=0,this.scopes){const n=this.scopes.slice();for(e=0,o=n.length;e<o;e++)n[e].stop(!0);this.scopes.length=0}if(!this.detached&&this.parent&&!i){const n=this.parent.scopes.pop();n&&n!==this&&(this.parent.scopes[this.index]=n,n.index=this.index)}this.parent=void 0}}}function oc(){return Xt}let Ft;const _o=new WeakSet;class Rr{constructor(i){this.fn=i,this.deps=void 0,this.depsTail=void 0,this.flags=5,this.next=void 0,this.cleanup=void 0,this.scheduler=void 0,Xt&&(Xt.active?Xt.effects.push(this):this.flags&=-2)}pause(){this.flags|=64}resume(){this.flags&64&&(this.flags&=-65,_o.has(this)&&(_o.delete(this),this.trigger()))}notify(){this.flags&2&&!(this.flags&32)||this.flags&8||Nr(this)}run(){if(!(this.flags&1))return this.fn();this.flags|=2,Ps(this),Fr(this);const i=Ft,e=Ie;Ft=this,Ie=!0;try{return this.fn()}finally{jr(this),Ft=i,Ie=e,this.flags&=-3}}stop(){if(this.flags&1){for(let i=this.deps;i;i=i.nextDep)as(i);this.deps=this.depsTail=void 0,Ps(this),this.onStop&&this.onStop(),this.flags&=-2}}trigger(){this.flags&64?_o.add(this):this.scheduler?this.scheduler():this.runIfDirty()}runIfDirty(){No(this)&&this.run()}get dirty(){return No(this)}}let zr=0,rn,ln;function Nr(t,i=!1){if(t.flags|=8,i){t.next=ln,ln=t;return}t.next=rn,rn=t}function rs(){zr++}function ls(){if(--zr>0)return;if(ln){let i=ln;for(ln=void 0;i;){const e=i.next;i.next=void 0,i.flags&=-9,i=e}}let t;for(;rn;){let i=rn;for(rn=void 0;i;){const e=i.next;if(i.next=void 0,i.flags&=-9,i.flags&1)try{i.trigger()}catch(o){t||(t=o)}i=e}}if(t)throw t}function Fr(t){for(let i=t.deps;i;i=i.nextDep)i.version=-1,i.prevActiveLink=i.dep.activeLink,i.dep.activeLink=i}function jr(t){let i,e=t.depsTail,o=e;for(;o;){const n=o.prevDep;o.version===-1?(o===e&&(e=n),as(o),sc(o)):i=o,o.dep.activeLink=o.prevActiveLink,o.prevActiveLink=void 0,o=n}t.deps=i,t.depsTail=e}function No(t){for(let i=t.deps;i;i=i.nextDep)if(i.dep.version!==i.version||i.dep.computed&&(Hr(i.dep.computed)||i.dep.version!==i.version))return!0;return!!t._dirty}function Hr(t){if(t.flags&4&&!(t.flags&16)||(t.flags&=-17,t.globalVersion===mn)||(t.globalVersion=mn,!t.isSSR&&t.flags&128&&(!t.deps&&!t._dirty||!No(t))))return;t.flags|=2;const i=t.dep,e=Ft,o=Ie;Ft=t,Ie=!0;try{Fr(t);const n=t.fn(t._value);(i.version===0||Re(n,t._value))&&(t.flags|=128,t._value=n,i.version++)}catch(n){throw i.version++,n}finally{Ft=e,Ie=o,jr(t),t.flags&=-3}}function as(t,i=!1){const{dep:e,prevSub:o,nextSub:n}=t;if(o&&(o.nextSub=n,t.prevSub=void 0),n&&(n.prevSub=o,t.nextSub=void 0),e.subs===t&&(e.subs=o,!o&&e.computed)){e.computed.flags&=-5;for(let r=e.computed.deps;r;r=r.nextDep)as(r,!0)}!i&&!--e.sc&&e.map&&e.map.delete(e.key)}function sc(t){const{prevDep:i,nextDep:e}=t;i&&(i.nextDep=e,t.prevDep=void 0),e&&(e.prevDep=i,t.nextDep=void 0)}let Ie=!0;const Ur=[];function Je(){Ur.push(Ie),Ie=!1}function Xe(){const t=Ur.pop();Ie=t===void 0?!0:t}function Ps(t){const{cleanup:i}=t;if(t.cleanup=void 0,i){const e=Ft;Ft=void 0;try{i()}finally{Ft=e}}}let mn=0;class rc{constructor(i,e){this.sub=i,this.dep=e,this.version=e.version,this.nextDep=this.prevDep=this.nextSub=this.prevSub=this.prevActiveLink=void 0}}class cs{constructor(i){this.computed=i,this.version=0,this.activeLink=void 0,this.subs=void 0,this.map=void 0,this.key=void 0,this.sc=0,this.__v_skip=!0}track(i){if(!Ft||!Ie||Ft===this.computed)return;let e=this.activeLink;if(e===void 0||e.sub!==Ft)e=this.activeLink=new rc(Ft,this),Ft.deps?(e.prevDep=Ft.depsTail,Ft.depsTail.nextDep=e,Ft.depsTail=e):Ft.deps=Ft.depsTail=e,Wr(e);else if(e.version===-1&&(e.version=this.version,e.nextDep)){const o=e.nextDep;o.prevDep=e.prevDep,e.prevDep&&(e.prevDep.nextDep=o),e.prevDep=Ft.depsTail,e.nextDep=void 0,Ft.depsTail.nextDep=e,Ft.depsTail=e,Ft.deps===e&&(Ft.deps=o)}return e}trigger(i){this.version++,mn++,this.notify(i)}notify(i){rs();try{for(let e=this.subs;e;e=e.prevSub)e.sub.notify()&&e.sub.dep.notify()}finally{ls()}}}function Wr(t){if(t.dep.sc++,t.sub.flags&4){const i=t.dep.computed;if(i&&!t.dep.subs){i.flags|=20;for(let o=i.deps;o;o=o.nextDep)Wr(o)}const e=t.dep.subs;e!==t&&(t.prevSub=e,e&&(e.nextSub=t)),t.dep.subs=t}}const Fo=new WeakMap,wi=Symbol(""),jo=Symbol(""),gn=Symbol("");function oe(t,i,e){if(Ie&&Ft){let o=Fo.get(t);o||Fo.set(t,o=new Map);let n=o.get(e);n||(o.set(e,n=new cs),n.map=o,n.key=e),n.track()}}function Ke(t,i,e,o,n,r){const l=Fo.get(t);if(!l){mn++;return}const s=a=>{a&&a.trigger()};if(rs(),i==="clear")l.forEach(s);else{const a=Ct(t),c=a&&ns(e);if(a&&e==="length"){const d=Number(o);l.forEach((f,g)=>{(g==="length"||g===gn||!Ae(g)&&g>=d)&&s(f)})}else switch((e!==void 0||l.has(void 0))&&s(l.get(e)),c&&s(l.get(gn)),i){case"add":a?c&&s(l.get("length")):(s(l.get(wi)),Oi(t)&&s(l.get(jo)));break;case"delete":a||(s(l.get(wi)),Oi(t)&&s(l.get(jo)));break;case"set":Oi(t)&&s(l.get(wi));break}}ls()}function Ei(t){const i=Et(t);return i===t?i:(oe(i,"iterate",gn),we(t)?i:i.map(Te))}function co(t){return oe(t=Et(t),"iterate",gn),t}function Pe(t,i){return Qe(t)?Hi(xi(t)?Te(i):i):Te(i)}const lc={__proto__:null,[Symbol.iterator](){return So(this,Symbol.iterator,t=>Pe(this,t))},concat(...t){return Ei(this).concat(...t.map(i=>Ct(i)?Ei(i):i))},entries(){return So(this,"entries",t=>(t[1]=Pe(this,t[1]),t))},every(t,i){return He(this,"every",t,i,void 0,arguments)},filter(t,i){return He(this,"filter",t,i,e=>e.map(o=>Pe(this,o)),arguments)},find(t,i){return He(this,"find",t,i,e=>Pe(this,e),arguments)},findIndex(t,i){return He(this,"findIndex",t,i,void 0,arguments)},findLast(t,i){return He(this,"findLast",t,i,e=>Pe(this,e),arguments)},findLastIndex(t,i){return He(this,"findLastIndex",t,i,void 0,arguments)},forEach(t,i){return He(this,"forEach",t,i,void 0,arguments)},includes(...t){return Co(this,"includes",t)},indexOf(...t){return Co(this,"indexOf",t)},join(t){return Ei(this).join(t)},lastIndexOf(...t){return Co(this,"lastIndexOf",t)},map(t,i){return He(this,"map",t,i,void 0,arguments)},pop(){return Yi(this,"pop")},push(...t){return Yi(this,"push",t)},reduce(t,...i){return Os(this,"reduce",t,i)},reduceRight(t,...i){return Os(this,"reduceRight",t,i)},shift(){return Yi(this,"shift")},some(t,i){return He(this,"some",t,i,void 0,arguments)},splice(...t){return Yi(this,"splice",t)},toReversed(){return Ei(this).toReversed()},toSorted(t){return Ei(this).toSorted(t)},toSpliced(...t){return Ei(this).toSpliced(...t)},unshift(...t){return Yi(this,"unshift",t)},values(){return So(this,"values",t=>Pe(this,t))}};function So(t,i,e){const o=co(t),n=o[i]();return o!==t&&!we(t)&&(n._next=n.next,n.next=()=>{const r=n._next();return r.done||(r.value=e(r.value)),r}),n}const ac=Array.prototype;function He(t,i,e,o,n,r){const l=co(t),s=l!==t&&!we(t),a=l[i];if(a!==ac[i]){const f=a.apply(t,r);return s?Te(f):f}let c=e;l!==t&&(s?c=function(f,g){return e.call(this,Pe(t,f),g,t)}:e.length>2&&(c=function(f,g){return e.call(this,f,g,t)}));const d=a.call(l,c,o);return s&&n?n(d):d}function Os(t,i,e,o){const n=co(t),r=n!==t&&!we(t);let l=e,s=!1;n!==t&&(r?(s=o.length===0,l=function(c,d,f){return s&&(s=!1,c=Pe(t,c)),e.call(this,c,Pe(t,d),f,t)}):e.length>3&&(l=function(c,d,f){return e.call(this,c,d,f,t)}));const a=n[i](l,...o);return s?Pe(t,a):a}function Co(t,i,e){const o=Et(t);oe(o,"iterate",gn);const n=o[i](...e);return(n===-1||n===!1)&&fs(e[0])?(e[0]=Et(e[0]),o[i](...e)):n}function Yi(t,i,e=[]){Je(),rs();const o=Et(t)[i].apply(t,e);return ls(),Xe(),o}const cc=es("__proto__,__v_isRef,__isVue"),Vr=new Set(Object.getOwnPropertyNames(Symbol).filter(t=>t!=="arguments"&&t!=="caller").map(t=>Symbol[t]).filter(Ae));function dc(t){Ae(t)||(t=String(t));const i=Et(this);return oe(i,"has",t),i.hasOwnProperty(t)}class Kr{constructor(i=!1,e=!1){this._isReadonly=i,this._isShallow=e}get(i,e,o){if(e==="__v_skip")return i.__v_skip;const n=this._isReadonly,r=this._isShallow;if(e==="__v_isReactive")return!n;if(e==="__v_isReadonly")return n;if(e==="__v_isShallow")return r;if(e==="__v_raw")return o===(n?r?kc:Yr:r?Zr:Gr).get(i)||Object.getPrototypeOf(i)===Object.getPrototypeOf(o)?i:void 0;const l=Ct(i);if(!n){let a;if(l&&(a=lc[e]))return a;if(e==="hasOwnProperty")return dc}const s=Reflect.get(i,e,Vt(i)?i:o);if((Ae(e)?Vr.has(e):cc(e))||(n||oe(i,"get",e),r))return s;if(Vt(s)){const a=l&&ns(e)?s:s.value;return n&&Ot(a)?Uo(a):a}return Ot(s)?n?Uo(s):uo(s):s}}class qr extends Kr{constructor(i=!1){super(!1,i)}set(i,e,o,n){let r=i[e];const l=Ct(i)&&ns(e);if(!this._isShallow){const c=Qe(r);if(!we(o)&&!Qe(o)&&(r=Et(r),o=Et(o)),!l&&Vt(r)&&!Vt(o))return c||(r.value=o),!0}const s=l?Number(e)<i.length:Bt(i,e),a=Reflect.set(i,e,o,Vt(i)?i:n);return i===Et(n)&&a&&(s?Re(o,r)&&Ke(i,"set",e,o):Ke(i,"add",e,o)),a}deleteProperty(i,e){const o=Bt(i,e);i[e];const n=Reflect.deleteProperty(i,e);return n&&o&&Ke(i,"delete",e,void 0),n}has(i,e){const o=Reflect.has(i,e);return(!Ae(e)||!Vr.has(e))&&oe(i,"has",e),o}ownKeys(i){return oe(i,"iterate",Ct(i)?"length":wi),Reflect.ownKeys(i)}}class uc extends Kr{constructor(i=!1){super(!0,i)}set(i,e){return!0}deleteProperty(i,e){return!0}}const fc=new qr,pc=new uc,hc=new qr(!0);const Ho=t=>t,Tn=t=>Reflect.getPrototypeOf(t);function mc(t,i,e){return function(...o){const n=this.__v_raw,r=Et(n),l=Oi(r),s=t==="entries"||t===Symbol.iterator&&l,a=t==="keys"&&l,c=n[t](...o),d=e?Ho:i?Hi:Te;return!i&&oe(r,"iterate",a?jo:wi),ie(Object.create(c),{next(){const{value:f,done:g}=c.next();return g?{value:f,done:g}:{value:s?[d(f[0]),d(f[1])]:d(f),done:g}}})}}function En(t){return function(...i){return t==="delete"?!1:t==="clear"?void 0:this}}function gc(t,i){const e={get(n){const r=this.__v_raw,l=Et(r),s=Et(n);t||(Re(n,s)&&oe(l,"get",n),oe(l,"get",s));const{has:a}=Tn(l),c=i?Ho:t?Hi:Te;if(a.call(l,n))return c(r.get(n));if(a.call(l,s))return c(r.get(s));r!==l&&r.get(n)},get size(){const n=this.__v_raw;return!t&&oe(Et(n),"iterate",wi),n.size},has(n){const r=this.__v_raw,l=Et(r),s=Et(n);return t||(Re(n,s)&&oe(l,"has",n),oe(l,"has",s)),n===s?r.has(n):r.has(n)||r.has(s)},forEach(n,r){const l=this,s=l.__v_raw,a=Et(s),c=i?Ho:t?Hi:Te;return!t&&oe(a,"iterate",wi),s.forEach((d,f)=>n.call(r,c(d),c(f),l))}};return ie(e,t?{add:En("add"),set:En("set"),delete:En("delete"),clear:En("clear")}:{add(n){const r=Et(this),l=Tn(r),s=Et(n),a=!i&&!we(n)&&!Qe(n)?s:n;return l.has.call(r,a)||Re(n,a)&&l.has.call(r,n)||Re(s,a)&&l.has.call(r,s)||(r.add(a),Ke(r,"add",a,a)),this},set(n,r){!i&&!we(r)&&!Qe(r)&&(r=Et(r));const l=Et(this),{has:s,get:a}=Tn(l);let c=s.call(l,n);c||(n=Et(n),c=s.call(l,n));const d=a.call(l,n);return l.set(n,r),c?Re(r,d)&&Ke(l,"set",n,r):Ke(l,"add",n,r),this},delete(n){const r=Et(this),{has:l,get:s}=Tn(r);let a=l.call(r,n);a||(n=Et(n),a=l.call(r,n)),s&&s.call(r,n);const c=r.delete(n);return a&&Ke(r,"delete",n,void 0),c},clear(){const n=Et(this),r=n.size!==0,l=n.clear();return r&&Ke(n,"clear",void 0,void 0),l}}),["keys","values","entries",Symbol.iterator].forEach(n=>{e[n]=mc(n,t,i)}),e}function ds(t,i){const e=gc(t,i);return(o,n,r)=>n==="__v_isReactive"?!t:n==="__v_isReadonly"?t:n==="__v_raw"?o:Reflect.get(Bt(e,n)&&n in o?e:o,n,r)}const vc={get:ds(!1,!1)},bc={get:ds(!1,!0)},yc={get:ds(!0,!1)};const Gr=new WeakMap,Zr=new WeakMap,Yr=new WeakMap,kc=new WeakMap;function wc(t){switch(t){case"Object":case"Array":return 1;case"Map":case"Set":case"WeakMap":case"WeakSet":return 2;default:return 0}}function uo(t){return Qe(t)?t:us(t,!1,fc,vc,Gr)}function xc(t){return us(t,!1,hc,bc,Zr)}function Uo(t){return us(t,!0,pc,yc,Yr)}function us(t,i,e,o,n){if(!Ot(t)||t.__v_raw&&!(i&&t.__v_isReactive)||t.__v_skip||!Object.isExtensible(t))return t;const r=n.get(t);if(r)return r;const l=wc(qa(t));if(l===0)return t;const s=new Proxy(t,l===2?o:e);return n.set(t,s),s}function xi(t){return Qe(t)?xi(t.__v_raw):!!(t&&t.__v_isReactive)}function Qe(t){return!!(t&&t.__v_isReadonly)}function we(t){return!!(t&&t.__v_isShallow)}function fs(t){return t?!!t.__v_raw:!1}function Et(t){const i=t&&t.__v_raw;return i?Et(i):t}function _c(t){return!Bt(t,"__v_skip")&&Object.isExtensible(t)&&Dr(t,"__v_skip",!0),t}const Te=t=>Ot(t)?uo(t):t,Hi=t=>Ot(t)?Uo(t):t;function Vt(t){return t?t.__v_isRef===!0:!1}function ft(t){return Sc(t,!1)}function Sc(t,i){return Vt(t)?t:new Cc(t,i)}class Cc{constructor(i,e){this.dep=new cs,this.__v_isRef=!0,this.__v_isShallow=!1,this._rawValue=e?i:Et(i),this._value=e?i:Te(i),this.__v_isShallow=e}get value(){return this.dep.track(),this._value}set value(i){const e=this._rawValue,o=this.__v_isShallow||we(i)||Qe(i);i=o?i:Et(i),Re(i,e)&&(this._rawValue=i,this._value=o?i:Te(i),this.dep.trigger())}}function ht(t){return Vt(t)?t.value:t}const $c={get:(t,i,e)=>i==="__v_raw"?t:ht(Reflect.get(t,i,e)),set:(t,i,e,o)=>{const n=t[i];return Vt(n)&&!Vt(e)?(n.value=e,!0):Reflect.set(t,i,e,o)}};function Jr(t){return xi(t)?t:new Proxy(t,$c)}class Ic{constructor(i,e,o){this.fn=i,this.setter=e,this._value=void 0,this.dep=new cs(this),this.__v_isRef=!0,this.deps=void 0,this.depsTail=void 0,this.flags=16,this.globalVersion=mn-1,this.next=void 0,this.effect=this,this.__v_isReadonly=!e,this.isSSR=o}notify(){if(this.flags|=16,!(this.flags&8)&&Ft!==this)return Nr(this,!0),!0}get value(){const i=this.dep.track();return Hr(this),i&&(i.version=this.dep.version),this._value}set value(i){this.setter&&this.setter(i)}}function Ac(t,i,e=!1){let o,n;return It(t)?o=t:(o=t.get,n=t.set),new Ic(o,n,e)}const Bn={},Gn=new WeakMap;let gi;function Tc(t,i=!1,e=gi){if(e){let o=Gn.get(e);o||Gn.set(e,o=[]),o.push(t)}}function Ec(t,i,e=Nt){const{immediate:o,deep:n,once:r,scheduler:l,augmentJob:s,call:a}=e,c=T=>n?T:we(T)||n===!1||n===0?qe(T,1):qe(T);let d,f,g,u,k=!1,h=!1;if(Vt(t)?(f=()=>t.value,k=we(t)):xi(t)?(f=()=>c(t),k=!0):Ct(t)?(h=!0,k=t.some(T=>xi(T)||we(T)),f=()=>t.map(T=>{if(Vt(T))return T.value;if(xi(T))return c(T);if(It(T))return a?a(T,2):T()})):It(t)?i?f=a?()=>a(t,2):t:f=()=>{if(g){Je();try{g()}finally{Xe()}}const T=gi;gi=d;try{return a?a(t,3,[u]):t(u)}finally{gi=T}}:f=Fe,i&&n){const T=f,x=n===!0?1/0:n;f=()=>qe(T(),x)}const y=oc(),b=()=>{d.stop(),y&&y.active&&is(y.effects,d)};if(r&&i){const T=i;i=(...x)=>{const _=T(...x);return b(),_}}let w=h?new Array(t.length).fill(Bn):Bn;const S=T=>{if(!(!(d.flags&1)||!d.dirty&&!T))if(i){const x=d.run();if(T||n||k||(h?x.some((_,I)=>Re(_,w[I])):Re(x,w))){g&&g();const _=gi;gi=d;try{const I=[x,w===Bn?void 0:h&&w[0]===Bn?[]:w,u];w=x,a?a(i,3,I):i(...I)}finally{gi=_}}}else d.run()};return s&&s(S),d=new Rr(f),d.scheduler=l?()=>l(S,!1):S,u=T=>Tc(T,!1,d),g=d.onStop=()=>{const T=Gn.get(d);if(T){if(a)a(T,4);else for(const x of T)x();Gn.delete(d)}},i?o?S(!0):w=d.run():l?l(S.bind(null,!0),!0):d.run(),b.pause=d.pause.bind(d),b.resume=d.resume.bind(d),b.stop=b,b}function qe(t,i=1/0,e){if(i<=0||!Ot(t)||t.__v_skip||(e=e||new Map,(e.get(t)||0)>=i))return t;if(e.set(t,i),i--,Vt(t))qe(t.value,i,e);else if(Ct(t))for(let o=0;o<t.length;o++)qe(t[o],i,e);else if(Ki(t)||Oi(t))t.forEach(o=>{qe(o,i,e)});else if(Mr(t)){for(const o in t)qe(t[o],i,e);for(const o of Object.getOwnPropertySymbols(t))Object.prototype.propertyIsEnumerable.call(t,o)&&qe(t[o],i,e)}return t}/**
* @vue/runtime-core v3.5.40
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/function _n(t,i,e,o){try{return o?t(...o):t()}catch(n){fo(n,i,e)}}function Ee(t,i,e,o){if(It(t)){const n=_n(t,i,e,o);return n&&Er(n)&&n.catch(r=>{fo(r,i,e)}),n}if(Ct(t)){const n=[];for(let r=0;r<t.length;r++)n.push(Ee(t[r],i,e,o));return n}}function fo(t,i,e,o=!0){const n=i?i.vnode:null,{errorHandler:r,throwUnhandledErrorInProduction:l}=i&&i.appContext.config||Nt;if(i){let s=i.parent;const a=i.proxy,c=`https://vuejs.org/error-reference/#runtime-${e}`;for(;s;){const d=s.ec;if(d){for(let f=0;f<d.length;f++)if(d[f](t,a,c)===!1)return}s=s.parent}if(r){Je(),_n(r,null,10,[t,a,c]),Xe();return}}Bc(t,e,n,o,l)}function Bc(t,i,e,o=!0,n=!1){if(n)throw t;console.error(t)}const ae=[];let Le=-1;const Ri=[];let ni=null,Bi=0;const Xr=Promise.resolve();let Zn=null;function Qr(t){const i=Zn||Xr;return t?i.then(this?t.bind(this):t):i}function Mc(t){let i=Le+1,e=ae.length;for(;i<e;){const o=i+e>>>1,n=ae[o],r=vn(n);r<t||r===t&&n.flags&2?i=o+1:e=o}return i}function ps(t){if(!(t.flags&1)){const i=vn(t),e=ae[ae.length-1];!e||!(t.flags&2)&&i>=vn(e)?ae.push(t):ae.splice(Mc(i),0,t),t.flags|=1,tl()}}function tl(){Zn||(Zn=Xr.then(il))}function Dc(t){Ct(t)?Ri.push(...t):ni&&t.id===-1?ni.splice(Bi+1,0,t):t.flags&1||(Ri.push(t),t.flags|=1),tl()}function Rs(t,i,e=Le+1){for(;e<ae.length;e++){const o=ae[e];if(o&&o.flags&2){if(t&&o.id!==t.uid)continue;ae.splice(e,1),e--,o.flags&4&&(o.flags&=-2),o(),o.flags&4||(o.flags&=-2)}}}function el(t){if(Ri.length){const i=[...new Set(Ri)].sort((e,o)=>vn(e)-vn(o));if(Ri.length=0,ni){ni.push(...i);return}for(ni=i,Bi=0;Bi<ni.length;Bi++){const e=ni[Bi];e.flags&4&&(e.flags&=-2),e.flags&8||e(),e.flags&=-2}ni=null,Bi=0}}const vn=t=>t.id==null?t.flags&2?-1:1/0:t.id;function il(t){try{for(Le=0;Le<ae.length;Le++){const i=ae[Le];i&&!(i.flags&8)&&(i.flags&4&&(i.flags&=-2),_n(i,i.i,i.i?15:14),i.flags&4||(i.flags&=-2))}}finally{for(;Le<ae.length;Le++){const i=ae[Le];i&&(i.flags&=-2)}Le=-1,ae.length=0,el(),Zn=null,(ae.length||Ri.length)&&il()}}let ee=null,nl=null;function Yn(t){const i=ee;return ee=t,nl=t&&t.type.__scopeId||null,i}function ol(t,i=ee,e){if(!i||t._n)return t;const o=(...n)=>{o._d&&Zs(-1);const r=Yn(i),l=Ze.length;let s;try{s=t(...n)}finally{for(let a=Ze.length;a>l;a--)ys();Yn(r),o._d&&Zs(1)}return s};return o._n=!0,o._c=!0,o._d=!0,o}function _e(t,i){if(ee===null)return t;const e=go(ee),o=t.dirs||(t.dirs=[]);for(let n=0;n<i.length;n++){let[r,l,s,a=Nt]=i[n];r&&(It(r)&&(r={mounted:r,updated:r}),r.deep&&qe(l),o.push({dir:r,instance:e,value:l,oldValue:void 0,arg:s,modifiers:a}))}return t}function pi(t,i,e,o){const n=t.dirs,r=i&&i.dirs;for(let l=0;l<n.length;l++){const s=n[l];r&&(s.oldValue=r[l].value);let a=s.dir[o];a&&(Je(),Ee(a,e,8,[t.el,s,t,i]),Xe())}}function Lc(t,i){if(se){let e=se.provides;const o=se.parent&&se.parent.provides;o===e&&(e=se.provides=Object.create(o)),e[t]=i}}function Ge(t,i,e=!1){const o=Md();if(o||Ni){let n=Ni?Ni._context.provides:o?o.parent==null||o.ce?o.vnode.appContext&&o.vnode.appContext.provides:o.parent.provides:void 0;if(n&&t in n)return n[t];if(arguments.length>1)return e&&It(i)?i.call(o&&o.proxy):i}}const Pc=Symbol.for("v-scx"),Oc=()=>Ge(Pc);function _i(t,i,e){return sl(t,i,e)}function sl(t,i,e=Nt){const{immediate:o,deep:n,flush:r,once:l}=e,s=ie({},e),a=i&&o||!i&&r!=="post";let c;if(yn){if(r==="sync"){const u=Oc();c=u.__watcherHandles||(u.__watcherHandles=[])}else if(!a){const u=()=>{};return u.stop=Fe,u.resume=Fe,u.pause=Fe,u}}const d=se;s.call=(u,k,h)=>Ee(u,d,k,h);let f=!1;r==="post"?s.scheduler=u=>{ue(u,d&&d.suspense)}:r!=="sync"&&(f=!0,s.scheduler=(u,k)=>{k?u():ps(u)}),s.augmentJob=u=>{i&&(u.flags|=4),f&&(u.flags|=2,d&&(u.id=d.uid,u.i=d))};const g=Ec(t,i,s);return yn&&(c?c.push(g):a&&g()),g}function Rc(t,i,e){const o=this.proxy,n=Gt(t)?t.includes(".")?rl(o,t):()=>o[t]:t.bind(o,o);let r;It(i)?r=i:(r=i.handler,e=i);const l=Cn(this),s=sl(n,r.bind(o),e);return l(),s}function rl(t,i){const e=i.split(".");return()=>{let o=t;for(let n=0;n<e.length&&o;n++)o=o[e[n]];return o}}const zc=Symbol("_vte"),Nc=t=>t.__isTeleport,$o=Symbol("_leaveCb");function hs(t,i){t.shapeFlag&6&&t.component?(t.transition=i,hs(t.component.subTree,i)):t.shapeFlag&128?(t.ssContent.transition=i.clone(t.ssContent),t.ssFallback.transition=i.clone(t.ssFallback)):t.transition=i}function he(t,i){return It(t)?ie({name:t.name},i,{setup:t}):t}function ll(t){t.ids=[t.ids[0]+t.ids[2]+++"-",0,0]}function zs(t,i){let e;return!!((e=Object.getOwnPropertyDescriptor(t,i))&&!e.configurable)}const Jn=new WeakMap;function an(t,i,e,o,n=!1){if(Ct(t)){t.forEach((h,y)=>an(h,i&&(Ct(i)?i[y]:i),e,o,n));return}if(zi(o)&&!n){o.shapeFlag&512&&o.type.__asyncResolved&&o.component.subTree.component&&an(t,i,e,o.component.subTree);return}const r=o.shapeFlag&4?go(o.component):o.el,l=n?null:r,{i:s,r:a}=t,c=i&&i.r,d=s.refs===Nt?s.refs={}:s.refs,f=s.setupState,g=Et(f),u=f===Nt?Tr:h=>zs(d,h)?!1:Bt(g,h),k=(h,y)=>!(y&&zs(d,y));if(c!=null&&c!==a){if(Ns(i),Gt(c))d[c]=null,u(c)&&(f[c]=null);else if(Vt(c)){const h=i;k(c,h.k)&&(c.value=null),h.k&&(d[h.k]=null)}}if(It(a))_n(a,s,12,[l,d]);else{const h=Gt(a),y=Vt(a);if(h||y){const b=()=>{if(t.f){const w=h?u(a)?f[a]:d[a]:k()||!t.k?a.value:d[t.k];if(n)Ct(w)&&is(w,r);else if(Ct(w))w.includes(r)||w.push(r);else if(h)d[a]=[r],u(a)&&(f[a]=d[a]);else{const S=[r];k(a,t.k)&&(a.value=S),t.k&&(d[t.k]=S)}}else h?(d[a]=l,u(a)&&(f[a]=l)):y&&(k(a,t.k)&&(a.value=l),t.k&&(d[t.k]=l))};if(l){const w=()=>{b(),Jn.delete(t)};w.id=-1,Jn.set(t,w),ue(w,e)}else Ns(t),b()}}}function Ns(t){const i=Jn.get(t);i&&(i.flags|=8,Jn.delete(t))}ao().requestIdleCallback;ao().cancelIdleCallback;const zi=t=>!!t.type.__asyncLoader,al=t=>t.type.__isKeepAlive;function Fc(t,i){cl(t,"a",i)}function jc(t,i){cl(t,"da",i)}function cl(t,i,e=se){const o=t.__wdc||(t.__wdc=()=>{let n=e;for(;n;){if(n.isDeactivated)return;n=n.parent}return t()});if(po(i,o,e),e){let n=e.parent;for(;n&&n.parent;)al(n.parent.vnode)&&Hc(o,i,e,n),n=n.parent}}function Hc(t,i,e,o){const n=po(i,t,o,!0);gs(()=>{is(o[i],n)},e)}function po(t,i,e=se,o=!1){if(e){const n=e[t]||(e[t]=[]),r=i.__weh||(i.__weh=(...l)=>{Je();const s=Cn(e),a=Ee(i,e,t,l);return s(),Xe(),a});return o?n.unshift(r):n.push(r),r}}const ei=t=>(i,e=se)=>{(!yn||t==="sp")&&po(t,(...o)=>i(...o),e)},Uc=ei("bm"),Sn=ei("m"),Wc=ei("bu"),Vc=ei("u"),ms=ei("bum"),gs=ei("um"),Kc=ei("sp"),qc=ei("rtg"),Gc=ei("rtc");function Zc(t,i=se){po("ec",t,i)}const Yc="components";function Jc(t,i){return Qc(Yc,t,!0,i)||t}const Xc=Symbol.for("v-ndc");function Qc(t,i,e=!0,o=!1){const n=ee||se;if(n){const r=n.type;{const s=Rd(r,!1);if(s&&(s===i||s===ce(i)||s===ro(ce(i))))return r}const l=Fs(n[t]||r[t],i)||Fs(n.appContext[t],i);return!l&&o?r:l}}function Fs(t,i){return t&&(t[i]||t[ce(i)]||t[ro(ce(i))])}function ge(t,i,e,o){let n;const r=e,l=Ct(t);if(l||Gt(t)){const s=l&&xi(t);let a=!1,c=!1;s&&(a=!we(t),c=Qe(t),t=co(t)),n=new Array(t.length);for(let d=0,f=t.length;d<f;d++)n[d]=i(a?c?Hi(Te(t[d])):Te(t[d]):t[d],d,void 0,r)}else if(typeof t=="number"){n=new Array(t);for(let s=0;s<t;s++)n[s]=i(s+1,s,void 0,r)}else if(Ot(t))if(t[Symbol.iterator])n=Array.from(t,(s,a)=>i(s,a,void 0,r));else{const s=Object.keys(t);n=new Array(s.length);for(let a=0,c=s.length;a<c;a++){const d=s[a];n[a]=i(t[d],d,a,r)}}else n=[];return n}function Mn(t,i,e={},o,n,r){if(ee.ce||ee.parent&&zi(ee.parent)&&ee.parent.ce){const c=e,d=Object.keys(c).length>0;return i!=="default"&&(c.name=i),tt(),$e(Ut,null,[ut("slot",c,o&&o())],d?-2:64)}let l=t[i];l&&l._c&&(l._d=!1);const s=Ze.length;tt();let a;try{const c=l&&dl(l(e)),d=e.key||r||c&&c.key;a=$e(Ut,{key:(d&&!Ae(d)?d:`_${i}`)+(!c&&o?"_fb":"")},c||(o?o():[]),c&&t._===1?64:-2)}catch(c){for(let d=Ze.length;d>s;d--)ys();throw c}finally{l&&l._c&&(l._d=!0)}return a}function dl(t){return t.some(i=>ks(i)?!(i.type===ti||i.type===Ut&&!dl(i.children)):!0)?t:null}const Wo=t=>t?El(t)?go(t):Wo(t.parent):null,cn=ie(Object.create(null),{$:t=>t,$el:t=>t.vnode.el,$data:t=>t.data,$props:t=>t.props,$attrs:t=>t.attrs,$slots:t=>t.slots,$refs:t=>t.refs,$parent:t=>Wo(t.parent),$root:t=>Wo(t.root),$host:t=>t.ce,$emit:t=>t.emit,$options:t=>fl(t),$forceUpdate:t=>t.f||(t.f=()=>{ps(t.update)}),$nextTick:t=>t.n||(t.n=Qr.bind(t.proxy)),$watch:t=>Rc.bind(t)}),Io=(t,i)=>t!==Nt&&!t.__isScriptSetup&&Bt(t,i),td={get({_:t},i){if(i==="__v_skip")return!0;const{ctx:e,setupState:o,data:n,props:r,accessCache:l,type:s,appContext:a}=t;if(i[0]!=="$"){const g=l[i];if(g!==void 0)switch(g){case 1:return o[i];case 2:return n[i];case 4:return e[i];case 3:return r[i]}else{if(Io(o,i))return l[i]=1,o[i];if(n!==Nt&&Bt(n,i))return l[i]=2,n[i];if(Bt(r,i))return l[i]=3,r[i];if(e!==Nt&&Bt(e,i))return l[i]=4,e[i];Vo&&(l[i]=0)}}const c=cn[i];let d,f;if(c)return i==="$attrs"&&oe(t.attrs,"get",""),c(t);if((d=s.__cssModules)&&(d=d[i]))return d;if(e!==Nt&&Bt(e,i))return l[i]=4,e[i];if(f=a.config.globalProperties,Bt(f,i))return f[i]},set({_:t},i,e){const{data:o,setupState:n,ctx:r}=t;return Io(n,i)?(n[i]=e,!0):o!==Nt&&Bt(o,i)?(o[i]=e,!0):Bt(t.props,i)||i[0]==="$"&&i.slice(1)in t?!1:(r[i]=e,!0)},has({_:{data:t,setupState:i,accessCache:e,ctx:o,appContext:n,props:r,type:l}},s){let a;return!!(e[s]||t!==Nt&&s[0]!=="$"&&Bt(t,s)||Io(i,s)||Bt(r,s)||Bt(o,s)||Bt(cn,s)||Bt(n.config.globalProperties,s)||(a=l.__cssModules)&&a[s])},defineProperty(t,i,e){return e.get!=null?t._.accessCache[i]=0:Bt(e,"value")&&this.set(t,i,e.value,null),Reflect.defineProperty(t,i,e)}};function js(t){return Ct(t)?t.reduce((i,e)=>(i[e]=null,i),{}):t}let Vo=!0;function ed(t){const i=fl(t),e=t.proxy,o=t.ctx;Vo=!1,i.beforeCreate&&Hs(i.beforeCreate,t,"bc");const{data:n,computed:r,methods:l,watch:s,provide:a,inject:c,created:d,beforeMount:f,mounted:g,beforeUpdate:u,updated:k,activated:h,deactivated:y,beforeDestroy:b,beforeUnmount:w,destroyed:S,unmounted:T,render:x,renderTracked:_,renderTriggered:I,errorCaptured:L,serverPrefetch:M,expose:F,inheritAttrs:J,components:E,directives:A,filters:v}=i;if(c&&id(c,o,null),l)for(const P in l){const K=l[P];It(K)&&(o[P]=K.bind(e))}if(n){const P=n.call(e,e);Ot(P)&&(t.data=uo(P))}if(Vo=!0,r)for(const P in r){const K=r[P],H=It(K)?K.bind(e,e):It(K.get)?K.get.bind(e,e):Fe,et=!It(K)&&It(K.set)?K.set.bind(e):Fe,V=St({get:H,set:et});Object.defineProperty(o,P,{enumerable:!0,configurable:!0,get:()=>V.value,set:G=>V.value=G})}if(s)for(const P in s)ul(s[P],o,e,P);if(a){const P=It(a)?a.call(e):a;Reflect.ownKeys(P).forEach(K=>{Lc(K,P[K])})}d&&Hs(d,t,"c");function z(P,K){Ct(K)?K.forEach(H=>P(H.bind(e))):K&&P(K.bind(e))}if(z(Uc,f),z(Sn,g),z(Wc,u),z(Vc,k),z(Fc,h),z(jc,y),z(Zc,L),z(Gc,_),z(qc,I),z(ms,w),z(gs,T),z(Kc,M),Ct(F))if(F.length){const P=t.exposed||(t.exposed={});F.forEach(K=>{Object.defineProperty(P,K,{get:()=>e[K],set:H=>e[K]=H,enumerable:!0})})}else t.exposed||(t.exposed={});x&&t.render===Fe&&(t.render=x),J!=null&&(t.inheritAttrs=J),E&&(t.components=E),A&&(t.directives=A),M&&ll(t)}function id(t,i,e=Fe){Ct(t)&&(t=Ko(t));for(const o in t){const n=t[o];let r;Ot(n)?"default"in n?r=Ge(n.from||o,n.default,!0):r=Ge(n.from||o):r=Ge(n),Vt(r)?Object.defineProperty(i,o,{enumerable:!0,configurable:!0,get:()=>r.value,set:l=>r.value=l}):i[o]=r}}function Hs(t,i,e){Ee(Ct(t)?t.map(o=>o.bind(i.proxy)):t.bind(i.proxy),i,e)}function ul(t,i,e,o){let n=o.includes(".")?rl(e,o):()=>e[o];if(Gt(t)){const r=i[t];It(r)&&_i(n,r)}else if(It(t))_i(n,t.bind(e));else if(Ot(t))if(Ct(t))t.forEach(r=>ul(r,i,e,o));else{const r=It(t.handler)?t.handler.bind(e):i[t.handler];It(r)&&_i(n,r,t)}}function fl(t){const i=t.type,{mixins:e,extends:o}=i,{mixins:n,optionsCache:r,config:{optionMergeStrategies:l}}=t.appContext,s=r.get(i);let a;return s?a=s:!n.length&&!e&&!o?a=i:(a={},n.length&&n.forEach(c=>Xn(a,c,l,!0)),Xn(a,i,l)),Ot(i)&&r.set(i,a),a}function Xn(t,i,e,o=!1){const{mixins:n,extends:r}=i;r&&Xn(t,r,e,!0),n&&n.forEach(l=>Xn(t,l,e,!0));for(const l in i)if(!(o&&l==="expose")){const s=nd[l]||e&&e[l];t[l]=s?s(t[l],i[l]):i[l]}return t}const nd={data:Us,props:Ws,emits:Ws,methods:tn,computed:tn,beforeCreate:le,created:le,beforeMount:le,mounted:le,beforeUpdate:le,updated:le,beforeDestroy:le,beforeUnmount:le,destroyed:le,unmounted:le,activated:le,deactivated:le,errorCaptured:le,serverPrefetch:le,components:tn,directives:tn,watch:sd,provide:Us,inject:od};function Us(t,i){return i?t?function(){return ie(It(t)?t.call(this,this):t,It(i)?i.call(this,this):i)}:i:t}function od(t,i){return tn(Ko(t),Ko(i))}function Ko(t){if(Ct(t)){const i={};for(let e=0;e<t.length;e++)i[t[e]]=t[e];return i}return t}function le(t,i){return t?[...new Set([].concat(t,i))]:i}function tn(t,i){return t?ie(Object.create(null),t,i):i}function Ws(t,i){return t?Ct(t)&&Ct(i)?[...new Set([...t,...i])]:ie(Object.create(null),js(t),js(i??{})):i}function sd(t,i){if(!t)return i;if(!i)return t;const e=ie(Object.create(null),t);for(const o in i)e[o]=le(t[o],i[o]);return e}function pl(){return{app:null,config:{isNativeTag:Tr,performance:!1,globalProperties:{},optionMergeStrategies:{},errorHandler:void 0,warnHandler:void 0,compilerOptions:{}},mixins:[],components:{},directives:{},provides:Object.create(null),optionsCache:new WeakMap,propsCache:new WeakMap,emitsCache:new WeakMap}}let rd=0;function ld(t,i){return function(o,n=null){It(o)||(o=ie({},o)),n!=null&&!Ot(n)&&(n=null);const r=pl(),l=new WeakSet,s=[];let a=!1;const c=r.app={_uid:rd++,_component:o,_props:n,_container:null,_context:r,_instance:null,version:Nd,get config(){return r.config},set config(d){},use(d,...f){return l.has(d)||(d&&It(d.install)?(l.add(d),d.install(c,...f)):It(d)&&(l.add(d),d(c,...f))),c},mixin(d){return r.mixins.includes(d)||r.mixins.push(d),c},component(d,f){return f?(r.components[d]=f,c):r.components[d]},directive(d,f){return f?(r.directives[d]=f,c):r.directives[d]},mount(d,f,g){if(!a){const u=c._ceVNode||ut(o,n);return u.appContext=r,g===!0?g="svg":g===!1&&(g=void 0),t(u,d,g),a=!0,c._container=d,d.__vue_app__=c,go(u.component)}},onUnmount(d){s.push(d)},unmount(){a&&(Ee(s,c._instance,16),t(null,c._container),delete c._container.__vue_app__)},provide(d,f){return r.provides[d]=f,c},runWithContext(d){const f=Ni;Ni=c;try{return d()}finally{Ni=f}}};return c}}let Ni=null;const ad=(t,i)=>i==="modelValue"||i==="model-value"?t.modelModifiers:t[`${i}Modifiers`]||t[`${ce(i)}Modifiers`]||t[`${ci(i)}Modifiers`];function cd(t,i,...e){if(t.isUnmounted)return;const o=t.vnode.props||Nt;let n=e;const r=i.startsWith("update:"),l=r&&ad(o,i.slice(7));l&&(l.trim&&(n=e.map(d=>Gt(d)?d.trim():d)),l.number&&(n=e.map(lo)));let s,a=o[s=wo(i)]||o[s=wo(ce(i))];!a&&r&&(a=o[s=wo(ci(i))]),a&&Ee(a,t,6,n);const c=o[s+"Once"];if(c){if(!t.emitted)t.emitted={};else if(t.emitted[s])return;t.emitted[s]=!0,Ee(c,t,6,n)}}const dd=new WeakMap;function hl(t,i,e=!1){const o=e?dd:i.emitsCache,n=o.get(t);if(n!==void 0)return n;const r=t.emits;let l={},s=!1;if(!It(t)){const a=c=>{const d=hl(c,i,!0);d&&(s=!0,ie(l,d))};!e&&i.mixins.length&&i.mixins.forEach(a),t.extends&&a(t.extends),t.mixins&&t.mixins.forEach(a)}return!r&&!s?(Ot(t)&&o.set(t,null),null):(Ct(r)?r.forEach(a=>l[a]=null):ie(l,r),Ot(t)&&o.set(t,l),l)}function ho(t,i){return!t||!no(i)?!1:(i=i.slice(2),i=i==="Once"?i:i.replace(/Once$/,""),Bt(t,i[0].toLowerCase()+i.slice(1))||Bt(t,ci(i))||Bt(t,i))}function Vs(t){const{type:i,vnode:e,proxy:o,withProxy:n,propsOptions:[r],slots:l,attrs:s,emit:a,render:c,renderCache:d,props:f,data:g,setupState:u,ctx:k,inheritAttrs:h}=t,y=Yn(t);let b,w;try{if(e.shapeFlag&4){const T=n||o,x=T;b=Oe(c.call(x,T,d,f,u,g,k)),w=s}else{const T=i;b=Oe(T.length>1?T(f,{attrs:s,slots:l,emit:a}):T(f,null)),w=i.props?s:ud(s)}}catch(T){Ze.length=0,fo(T,t,1),b=ut(ti)}let S=b;if(w&&h!==!1){const T=Object.keys(w),{shapeFlag:x}=S;T.length&&x&7&&(r&&T.some(oo)&&(w=fd(w,r)),S=Ui(S,w,!1,!0))}return e.dirs&&(S=Ui(S,null,!1,!0),S.dirs=S.dirs?S.dirs.concat(e.dirs):e.dirs),e.transition&&hs(S,e.transition),b=S,Yn(y),b}const ud=t=>{let i;for(const e in t)(e==="class"||e==="style"||no(e))&&((i||(i={}))[e]=t[e]);return i},fd=(t,i)=>{const e={};for(const o in t)(!oo(o)||!(o.slice(9)in i))&&(e[o]=t[o]);return e};function pd(t,i,e){const{props:o,children:n,component:r}=t,{props:l,children:s,patchFlag:a}=i,c=r.emitsOptions;if(i.dirs||i.transition)return!0;if(e&&a>=0){if(a&1024)return!0;if(a&16)return o?Ks(o,l,c):!!l;if(a&8){const d=i.dynamicProps;for(let f=0;f<d.length;f++){const g=d[f];if(ml(l,o,g)&&!ho(c,g))return!0}}}else return(n||s)&&(!s||!s.$stable)?!0:o===l?!1:o?l?Ks(o,l,c):!0:!!l;return!1}function Ks(t,i,e){const o=Object.keys(i);if(o.length!==Object.keys(t).length)return!0;for(let n=0;n<o.length;n++){const r=o[n];if(ml(i,t,r)&&!ho(e,r))return!0}return!1}function ml(t,i,e){const o=t[e],n=i[e];return e==="style"&&Ot(o)&&Ot(n)?!qi(o,n):o!==n}function hd({vnode:t,parent:i,suspense:e},o){for(;i;){const n=i.subTree;if(n.suspense&&n.suspense.activeBranch===t&&(n.suspense.vnode.el=n.el=o,t=n),n===t)(t=i.vnode).el=o,i=i.parent;else break}e&&e.activeBranch===t&&(e.vnode.el=o)}const gl={},vl=()=>Object.create(gl),bl=t=>Object.getPrototypeOf(t)===gl;function md(t,i,e,o=!1){const n={},r=vl();t.propsDefaults=Object.create(null),yl(t,i,n,r);for(const l in t.propsOptions[0])l in n||(n[l]=void 0);e?t.props=o?n:xc(n):t.type.props?t.props=n:t.props=r,t.attrs=r}function gd(t,i,e,o){const{props:n,attrs:r,vnode:{patchFlag:l}}=t,s=Et(n),[a]=t.propsOptions;let c=!1;if((o||l>0)&&!(l&16)){if(l&8){const d=t.vnode.dynamicProps;for(let f=0;f<d.length;f++){let g=d[f];if(ho(t.emitsOptions,g))continue;const u=i[g];if(a)if(Bt(r,g))u!==r[g]&&(r[g]=u,c=!0);else{const k=ce(g);n[k]=qo(a,s,k,u,t,!1)}else u!==r[g]&&(r[g]=u,c=!0)}}}else{yl(t,i,n,r)&&(c=!0);let d;for(const f in s)(!i||!Bt(i,f)&&((d=ci(f))===f||!Bt(i,d)))&&(a?e&&(e[f]!==void 0||e[d]!==void 0)&&(n[f]=qo(a,s,f,void 0,t,!0)):delete n[f]);if(r!==s)for(const f in r)(!i||!Bt(i,f))&&(delete r[f],c=!0)}c&&Ke(t.attrs,"set","")}function yl(t,i,e,o){const[n,r]=t.propsOptions;let l=!1,s;if(i)for(let a in i){if(sn(a))continue;const c=i[a];let d;n&&Bt(n,d=ce(a))?!r||!r.includes(d)?e[d]=c:(s||(s={}))[d]=c:ho(t.emitsOptions,a)||(!(a in o)||c!==o[a])&&(o[a]=c,l=!0)}if(r){const a=Et(e),c=s||Nt;for(let d=0;d<r.length;d++){const f=r[d];e[f]=qo(n,a,f,c[f],t,!Bt(c,f))}}return l}function qo(t,i,e,o,n,r){const l=t[e];if(l!=null){const s=Bt(l,"default");if(s&&o===void 0){const a=l.default;if(l.type!==Function&&!l.skipFactory&&It(a)){const{propsDefaults:c}=n;if(e in c)o=c[e];else{const d=Cn(n);o=c[e]=a.call(null,i),d()}}else o=a;n.ce&&n.ce._setProp(e,o)}l[0]&&(r&&!s?o=!1:l[1]&&(o===""||o===ci(e))&&(o=!0))}return o}const vd=new WeakMap;function kl(t,i,e=!1){const o=e?vd:i.propsCache,n=o.get(t);if(n)return n;const r=t.props,l={},s=[];let a=!1;if(!It(t)){const d=f=>{a=!0;const[g,u]=kl(f,i,!0);ie(l,g),u&&s.push(...u)};!e&&i.mixins.length&&i.mixins.forEach(d),t.extends&&d(t.extends),t.mixins&&t.mixins.forEach(d)}if(!r&&!a)return Ot(t)&&o.set(t,Pi),Pi;if(Ct(r))for(let d=0;d<r.length;d++){const f=ce(r[d]);qs(f)&&(l[f]=Nt)}else if(r)for(const d in r){const f=ce(d);if(qs(f)){const g=r[d],u=l[f]=Ct(g)||It(g)?{type:g}:ie({},g),k=u.type;let h=!1,y=!0;if(Ct(k))for(let b=0;b<k.length;++b){const w=k[b],S=It(w)&&w.name;if(S==="Boolean"){h=!0;break}else S==="String"&&(y=!1)}else h=It(k)&&k.name==="Boolean";u[0]=h,u[1]=y,(h||Bt(u,"default"))&&s.push(f)}}const c=[l,s];return Ot(t)&&o.set(t,c),c}function qs(t){return t[0]!=="$"&&!sn(t)}const vs=t=>t==="_"||t==="_ctx"||t==="$stable",bs=t=>Ct(t)?t.map(Oe):[Oe(t)],bd=(t,i,e)=>{if(i._n)return i;const o=ol((...n)=>bs(i(...n)),e);return o._c=!1,o},wl=(t,i,e)=>{const o=t._ctx;for(const n in t){if(vs(n))continue;const r=t[n];if(It(r))i[n]=bd(n,r,o);else if(r!=null){const l=bs(r);i[n]=()=>l}}},xl=(t,i)=>{const e=bs(i);t.slots.default=()=>e},_l=(t,i,e)=>{for(const o in i)(e||!vs(o))&&(t[o]=i[o])},yd=(t,i,e)=>{const o=t.slots=vl();if(t.vnode.shapeFlag&32){const n=i._;n?(_l(o,i,e),e&&Dr(o,"_",n,!0)):wl(i,o)}else i&&xl(t,i)},kd=(t,i,e)=>{const{vnode:o,slots:n}=t;let r=!0,l=Nt;if(o.shapeFlag&32){const s=i._;s?e&&s===1?r=!1:_l(n,i,e):(r=!i.$stable,wl(i,n)),l=i}else i&&(xl(t,i),l={default:1});if(r)for(const s in n)!vs(s)&&l[s]==null&&delete n[s]},ue=Cd;function wd(t){return xd(t)}function xd(t,i){const e=ao();e.__VUE__=!0;const{insert:o,remove:n,patchProp:r,createElement:l,createText:s,createComment:a,setText:c,setElementText:d,parentNode:f,nextSibling:g,setScopeId:u=Fe,insertStaticContent:k}=t,h=(B,N,p,j=null,R=null,C=null,$=void 0,D=null,q=!!N.dynamicChildren)=>{if(B===N)return;B&&!Ji(B,N)&&(j=pt(B),G(B,R,C,!0),B=null),N.patchFlag===-2&&(q=!1,N.dynamicChildren=null);const{type:W,ref:U,shapeFlag:Z}=N;switch(W){case mo:y(B,N,p,j);break;case ti:b(B,N,p,j);break;case Rn:B==null&&w(N,p,j,$);break;case Ut:E(B,N,p,j,R,C,$,D,q);break;default:Z&1?x(B,N,p,j,R,C,$,D,q):Z&6?A(B,N,p,j,R,C,$,D,q):(Z&64||Z&128)&&W.process(B,N,p,j,R,C,$,D,q,rt)}U!=null&&R?an(U,B&&B.ref,C,N||B,!N):U==null&&B&&B.ref!=null&&an(B.ref,null,C,B,!0)},y=(B,N,p,j)=>{if(B==null)o(N.el=s(N.children),p,j);else{const R=N.el=B.el;N.children!==B.children&&c(R,N.children)}},b=(B,N,p,j)=>{B==null?o(N.el=a(N.children||""),p,j):N.el=B.el},w=(B,N,p,j)=>{[B.el,B.anchor]=k(B.children,N,p,j,B.el,B.anchor)},S=({el:B,anchor:N},p,j)=>{let R;for(;B&&B!==N;)R=g(B),o(B,p,j),B=R;o(N,p,j)},T=({el:B,anchor:N})=>{let p;for(;B&&B!==N;)p=g(B),n(B),B=p;n(N)},x=(B,N,p,j,R,C,$,D,q)=>{if(N.type==="svg"?$="svg":N.type==="math"&&($="mathml"),B==null)_(N,p,j,R,C,$,D,q);else{const W=B.el&&B.el._isVueCE?B.el:null;try{W&&W._beginPatch(),M(B,N,R,C,$,D,q)}finally{W&&W._endPatch()}}},_=(B,N,p,j,R,C,$,D)=>{let q,W;const{props:U,shapeFlag:Z,transition:it,dirs:Q}=B;if(q=B.el=l(B.type,C,U&&U.is,U),Z&8?d(q,B.children):Z&16&&L(B.children,q,null,j,R,Ao(B,C),$,D),Q&&pi(B,null,j,"created"),I(q,B,B.scopeId,$,j),U){for(const wt in U)wt!=="value"&&!sn(wt)&&r(q,wt,null,U[wt],C,j);"value"in U&&r(q,"value",null,U.value,C),(W=U.onVnodeBeforeMount)&&Me(W,j,B)}Q&&pi(B,null,j,"beforeMount");const ct=_d(R,it);ct&&it.beforeEnter(q),o(q,N,p),((W=U&&U.onVnodeMounted)||ct||Q)&&ue(()=>{try{W&&Me(W,j,B),ct&&it.enter(q),Q&&pi(B,null,j,"mounted")}finally{}},R)},I=(B,N,p,j,R)=>{if(p&&u(B,p),j)for(let C=0;C<j.length;C++)u(B,j[C]);if(R){let C=R.subTree;if(N===C||Il(C.type)&&(C.ssContent===N||C.ssFallback===N)){const $=R.vnode;I(B,$,$.scopeId,$.slotScopeIds,R.parent)}}},L=(B,N,p,j,R,C,$,D,q=0)=>{for(let W=q;W<B.length;W++){const U=B[W]=D?Ve(B[W]):Oe(B[W]);h(null,U,N,p,j,R,C,$,D)}},M=(B,N,p,j,R,C,$)=>{const D=N.el=B.el;let{patchFlag:q,dynamicChildren:W,dirs:U}=N;q|=B.patchFlag&16;const Z=B.props||Nt,it=N.props||Nt;let Q;if(p&&hi(p,!1),(Q=it.onVnodeBeforeUpdate)&&Me(Q,p,N,B),U&&pi(N,B,p,"beforeUpdate"),p&&hi(p,!0),W&&(!B.dynamicChildren||B.dynamicChildren.length!==W.length)&&(q=0,$=!1,W=null),(Z.innerHTML&&it.innerHTML==null||Z.textContent&&it.textContent==null)&&d(D,""),W?F(B.dynamicChildren,W,D,p,j,Ao(N,R),C):$||K(B,N,D,null,p,j,Ao(N,R),C,!1),q>0){if(q&16)J(D,Z,it,p,R);else if(q&2&&Z.class!==it.class&&r(D,"class",null,it.class,R),q&4&&r(D,"style",Z.style,it.style,R),q&8){const ct=N.dynamicProps;for(let wt=0;wt<ct.length;wt++){const bt=ct[wt],Tt=Z[bt],Ht=it[bt];(Ht!==Tt||bt==="value")&&r(D,bt,Tt,Ht,R,p)}}q&1&&B.children!==N.children&&d(D,N.children)}else!$&&W==null&&J(D,Z,it,p,R);((Q=it.onVnodeUpdated)||U)&&ue(()=>{Q&&Me(Q,p,N,B),U&&pi(N,B,p,"updated")},j)},F=(B,N,p,j,R,C,$)=>{for(let D=0;D<N.length;D++){const q=B[D],W=N[D],U=q.el&&(q.type===Ut||!Ji(q,W)||q.shapeFlag&198)?f(q.el):p;h(q,W,U,null,j,R,C,$,!0)}},J=(B,N,p,j,R)=>{if(N!==p){if(N!==Nt)for(const C in N)!sn(C)&&!(C in p)&&r(B,C,N[C],null,R,j);for(const C in p){if(sn(C))continue;const $=p[C],D=N[C];$!==D&&C!=="value"&&r(B,C,D,$,R,j)}"value"in p&&r(B,"value",N.value,p.value,R)}},E=(B,N,p,j,R,C,$,D,q)=>{const W=N.el=B?B.el:s(""),U=N.anchor=B?B.anchor:s("");let{patchFlag:Z,dynamicChildren:it,slotScopeIds:Q}=N;Q&&(D=D?D.concat(Q):Q),B==null?(o(W,p,j),o(U,p,j),L(N.children||[],p,U,R,C,$,D,q)):Z>0&&Z&64&&it&&B.dynamicChildren&&B.dynamicChildren.length===it.length?(F(B.dynamicChildren,it,p,R,C,$,D),(N.key!=null||R&&N===R.subTree)&&Sl(B,N,!0)):K(B,N,p,U,R,C,$,D,q)},A=(B,N,p,j,R,C,$,D,q)=>{N.slotScopeIds=D,B==null?N.shapeFlag&512?R.ctx.activate(N,p,j,$,q):v(N,p,j,R,C,$,q):O(B,N,q)},v=(B,N,p,j,R,C,$)=>{const D=B.component=Bd(B,j,R);if(al(B)&&(D.ctx.renderer=rt),Dd(D,!1,$),D.asyncDep){if(R&&R.registerDep(D,z,$),!B.el){const q=D.subTree=ut(ti);b(null,q,N,p),B.placeholder=q.el}}else z(D,B,N,p,R,C,$)},O=(B,N,p)=>{const j=N.component=B.component;if(pd(B,N,p))if(j.asyncDep&&!j.asyncResolved){P(j,N,p);return}else j.next=N,j.update();else N.el=B.el,j.vnode=N},z=(B,N,p,j,R,C,$)=>{const D=()=>{if(B.isMounted){let{next:Z,bu:it,u:Q,parent:ct,vnode:wt}=B;{const Yt=Cl(B);if(Yt){Z&&(Z.el=wt.el,P(B,Z,$)),Yt.asyncDep.then(()=>{ue(()=>{B.isUnmounted||W()},R)});return}}let bt=Z,Tt;hi(B,!1),Z?(Z.el=wt.el,P(B,Z,$)):Z=wt,it&&On(it),(Tt=Z.props&&Z.props.onVnodeBeforeUpdate)&&Me(Tt,ct,Z,wt),hi(B,!0);const Ht=Vs(B),Wt=B.subTree;B.subTree=Ht,h(Wt,Ht,f(Wt.el),pt(Wt),B,R,C),Z.el=Ht.el,bt===null&&hd(B,Ht.el),Q&&ue(Q,R),(Tt=Z.props&&Z.props.onVnodeUpdated)&&ue(()=>Me(Tt,ct,Z,wt),R)}else{let Z;const{el:it,props:Q}=N,{bm:ct,m:wt,parent:bt,root:Tt,type:Ht}=B,Wt=zi(N);hi(B,!1),ct&&On(ct),!Wt&&(Z=Q&&Q.onVnodeBeforeMount)&&Me(Z,bt,N),hi(B,!0);{Tt.ce&&Tt.ce._hasShadowRoot()&&Tt.ce._injectChildStyle(Ht,B.parent?B.parent.type:void 0);const Yt=B.subTree=Vs(B);h(null,Yt,p,j,B,R,C),N.el=Yt.el}if(wt&&ue(wt,R),!Wt&&(Z=Q&&Q.onVnodeMounted)){const Yt=N;ue(()=>Me(Z,bt,Yt),R)}(N.shapeFlag&256||bt&&zi(bt.vnode)&&bt.vnode.shapeFlag&256)&&B.a&&ue(B.a,R),B.isMounted=!0,N=p=j=null}};B.scope.on();const q=B.effect=new Rr(D);B.scope.off();const W=B.update=q.run.bind(q),U=B.job=q.runIfDirty.bind(q);U.i=B,U.id=B.uid,q.scheduler=()=>ps(U),hi(B,!0),W()},P=(B,N,p)=>{N.component=B;const j=B.vnode.props;B.vnode=N,B.next=null,gd(B,N.props,j,p),kd(B,N.children,p),Je(),Rs(B),Xe()},K=(B,N,p,j,R,C,$,D,q=!1)=>{const W=B&&B.children,U=B?B.shapeFlag:0,Z=N.children,{patchFlag:it,shapeFlag:Q}=N;if(it>0){if(it&128){et(W,Z,p,j,R,C,$,D,q);return}else if(it&256){H(W,Z,p,j,R,C,$,D,q);return}}Q&8?(U&16&&X(W,R,C),Z!==W&&d(p,Z)):U&16?Q&16?et(W,Z,p,j,R,C,$,D,q):X(W,R,C,!0):(U&8&&d(p,""),Q&16&&L(Z,p,j,R,C,$,D,q))},H=(B,N,p,j,R,C,$,D,q)=>{B=B||Pi,N=N||Pi;const W=B.length,U=N.length,Z=Math.min(W,U);let it;for(it=0;it<Z;it++){const Q=N[it]=q?Ve(N[it]):Oe(N[it]);h(B[it],Q,p,null,R,C,$,D,q)}W>U?X(B,R,C,!0,!1,Z):L(N,p,j,R,C,$,D,q,Z)},et=(B,N,p,j,R,C,$,D,q)=>{let W=0;const U=N.length;let Z=B.length-1,it=U-1;for(;W<=Z&&W<=it;){const Q=B[W],ct=N[W]=q?Ve(N[W]):Oe(N[W]);if(Ji(Q,ct))h(Q,ct,p,null,R,C,$,D,q);else break;W++}for(;W<=Z&&W<=it;){const Q=B[Z],ct=N[it]=q?Ve(N[it]):Oe(N[it]);if(Ji(Q,ct))h(Q,ct,p,null,R,C,$,D,q);else break;Z--,it--}if(W>Z){if(W<=it){const Q=it+1,ct=Q<U?N[Q].el:j;for(;W<=it;)h(null,N[W]=q?Ve(N[W]):Oe(N[W]),p,ct,R,C,$,D,q),W++}}else if(W>it)for(;W<=Z;)G(B[W],R,C,!0),W++;else{const Q=W,ct=W,wt=new Map;for(W=ct;W<=it;W++){const Zt=N[W]=q?Ve(N[W]):Oe(N[W]);Zt.key!=null&&wt.set(Zt.key,W)}let bt,Tt=0;const Ht=it-ct+1;let Wt=!1,Yt=0;const Mt=new Array(Ht);for(W=0;W<Ht;W++)Mt[W]=0;for(W=Q;W<=Z;W++){const Zt=B[W];if(Tt>=Ht){G(Zt,R,C,!0);continue}let Kt;if(Zt.key!=null)Kt=wt.get(Zt.key);else for(bt=ct;bt<=it;bt++)if(Mt[bt-ct]===0&&Ji(Zt,N[bt])){Kt=bt;break}Kt===void 0?G(Zt,R,C,!0):(Mt[Kt-ct]=W+1,Kt>=Yt?Yt=Kt:Wt=!0,h(Zt,N[Kt],p,null,R,C,$,D,q),Tt++)}const je=Wt?Sd(Mt):Pi;for(bt=je.length-1,W=Ht-1;W>=0;W--){const Zt=ct+W,Kt=N[Zt],ii=N[Zt+1],Ii=Zt+1<U?ii.el||$l(ii):j;Mt[W]===0?h(null,Kt,p,Ii,R,C,$,D,q):Wt&&(bt<0||W!==je[bt]?V(Kt,p,Ii,2):bt--)}}},V=(B,N,p,j,R=null)=>{const{el:C,type:$,transition:D,children:q,shapeFlag:W}=B;if(W&6){V(B.component.subTree,N,p,j);return}if(W&128){B.suspense.move(N,p,j);return}if(W&64){$.move(B,N,p,rt);return}if($===Ut){o(C,N,p);for(let Z=0;Z<q.length;Z++)V(q[Z],N,p,j);o(B.anchor,N,p);return}if($===Rn){S(B,N,p);return}if(j!==2&&W&1&&D)if(j===0)D.persisted&&!C[$o]?o(C,N,p):(D.beforeEnter(C),o(C,N,p),ue(()=>D.enter(C),R));else{const{leave:Z,delayLeave:it,afterLeave:Q}=D,ct=()=>{B.ctx.isUnmounted?n(C):o(C,N,p)},wt=()=>{const bt=C._isLeaving||!!C[$o];C._isLeaving&&C[$o](!0),D.persisted&&!bt?ct():Z(C,()=>{ct(),Q&&Q()})};it?it(C,ct,wt):wt()}else o(C,N,p)},G=(B,N,p,j=!1,R=!1)=>{const{type:C,props:$,ref:D,children:q,dynamicChildren:W,shapeFlag:U,patchFlag:Z,dirs:it,cacheIndex:Q,memo:ct}=B;if(Z===-2&&(R=!1),D!=null&&(Je(),an(D,null,p,B,!0),Xe()),Q!=null&&(N.renderCache[Q]=void 0),U&256){N.ctx.deactivate(B);return}const wt=U&1&&it,bt=!zi(B);let Tt;if(bt&&(Tt=$&&$.onVnodeBeforeUnmount)&&Me(Tt,N,B),U&6)ot(B.component,p,j);else{if(U&128){B.suspense.unmount(p,j);return}wt&&pi(B,null,N,"beforeUnmount"),U&64?B.type.remove(B,N,p,rt,j):W&&!W.hasOnce&&(C!==Ut||Z>0&&Z&64)?X(W,N,p,!1,!0):(C===Ut&&Z&384||!R&&U&16)&&X(q,N,p),j&&lt(B)}const Ht=ct!=null&&Q==null;(bt&&(Tt=$&&$.onVnodeUnmounted)||wt||Ht)&&ue(()=>{Tt&&Me(Tt,N,B),wt&&pi(B,null,N,"unmounted"),Ht&&(B.el=null)},p)},lt=B=>{const{type:N,el:p,anchor:j,transition:R}=B;if(N===Ut){at(p,j);return}if(N===Rn){T(B);return}const C=()=>{n(p),R&&!R.persisted&&R.afterLeave&&R.afterLeave()};if(B.shapeFlag&1&&R&&!R.persisted){const{leave:$,delayLeave:D}=R,q=()=>$(p,C);D?D(B.el,C,q):q()}else C()},at=(B,N)=>{let p;for(;B!==N;)p=g(B),n(B),B=p;n(N)},ot=(B,N,p)=>{const{bum:j,scope:R,job:C,subTree:$,um:D,m:q,a:W}=B;Gs(q),Gs(W),j&&On(j),R.stop(),C&&(C.flags|=8,G($,B,N,p)),D&&ue(D,N),ue(()=>{B.isUnmounted=!0},N)},X=(B,N,p,j=!1,R=!1,C=0)=>{for(let $=C;$<B.length;$++)G(B[$],N,p,j,R)},pt=B=>{if(B.shapeFlag&6)return pt(B.component.subTree);if(B.shapeFlag&128)return B.suspense.next();const N=g(B.anchor||B.el),p=N&&N[zc];return p?g(p):N};let gt=!1;const Y=(B,N,p)=>{let j;B==null?N._vnode&&(G(N._vnode,null,null,!0),j=N._vnode.component):h(N._vnode||null,B,N,null,null,null,p),N._vnode=B,gt||(gt=!0,Rs(j),el(),gt=!1)},rt={p:h,um:G,m:V,r:lt,mt:v,mc:L,pc:K,pbc:F,n:pt,o:t};return{render:Y,hydrate:void 0,createApp:ld(Y)}}function Ao({type:t,props:i},e){return e==="svg"&&t==="foreignObject"||e==="mathml"&&t==="annotation-xml"&&i&&i.encoding&&i.encoding.includes("html")?void 0:e}function hi({effect:t,job:i},e){e?(t.flags|=32,i.flags|=4):(t.flags&=-33,i.flags&=-5)}function _d(t,i){return(!t||t&&!t.pendingBranch)&&i&&!i.persisted}function Sl(t,i,e=!1){const o=t.children,n=i.children;if(Ct(o)&&Ct(n))for(let r=0;r<o.length;r++){const l=o[r];let s=n[r];s.shapeFlag&1&&!s.dynamicChildren&&((s.patchFlag<=0||s.patchFlag===32)&&(s=n[r]=Ve(n[r]),s.el=l.el),!e&&s.patchFlag!==-2&&Sl(l,s)),s.type===mo&&(s.patchFlag===-1&&(s=n[r]=Ve(s)),s.el=l.el),s.type===ti&&!s.el&&(s.el=l.el)}}function Sd(t){const i=t.slice(),e=[0];let o,n,r,l,s;const a=t.length;for(o=0;o<a;o++){const c=t[o];if(c!==0){if(n=e[e.length-1],t[n]<c){i[o]=n,e.push(o);continue}for(r=0,l=e.length-1;r<l;)s=r+l>>1,t[e[s]]<c?r=s+1:l=s;c<t[e[r]]&&(r>0&&(i[o]=e[r-1]),e[r]=o)}}for(r=e.length,l=e[r-1];r-- >0;)e[r]=l,l=i[l];return e}function Cl(t){const i=t.subTree.component;if(i)return i.asyncDep&&!i.asyncResolved?i:Cl(i)}function Gs(t){if(t)for(let i=0;i<t.length;i++)t[i].flags|=8}function $l(t){if(t.placeholder)return t.placeholder;const i=t.component;return i?$l(i.subTree):null}const Il=t=>t.__isSuspense;function Cd(t,i){i&&i.pendingBranch?Ct(t)?i.effects.push(...t):i.effects.push(t):Dc(t)}const Ut=Symbol.for("v-fgt"),mo=Symbol.for("v-txt"),ti=Symbol.for("v-cmt"),Rn=Symbol.for("v-stc"),Ze=[];let ve=null;function tt(t=!1){Ze.push(ve=t?null:[])}function ys(){Ze.pop(),ve=Ze[Ze.length-1]||null}let bn=1;function Zs(t,i=!1){bn+=t,t<0&&ve&&i&&(ve.hasOnce=!0)}function Al(t){return t.dynamicChildren=bn>0?ve||Pi:null,ys(),bn>0&&ve&&ve.push(t),t}function nt(t,i,e,o,n,r){return Al(m(t,i,e,o,n,r,!0))}function $e(t,i,e,o,n){return Al(ut(t,i,e,o,n,!0))}function ks(t){return t?t.__v_isVNode===!0:!1}function Ji(t,i){return t.type===i.type&&t.key===i.key}const Tl=({key:t})=>t??null,zn=({ref:t,ref_key:i,ref_for:e})=>(typeof t=="number"&&(t=""+t),t!=null?Gt(t)||Vt(t)||It(t)?{i:ee,r:t,k:i,f:!!e}:t:null);function m(t,i=null,e=null,o=0,n=null,r=t===Ut?0:1,l=!1,s=!1){const a={__v_isVNode:!0,__v_skip:!0,type:t,props:i,key:i&&Tl(i),ref:i&&zn(i),scopeId:nl,slotScopeIds:null,children:e,component:null,suspense:null,ssContent:null,ssFallback:null,dirs:null,transition:null,el:null,anchor:null,target:null,targetStart:null,targetAnchor:null,staticCount:0,shapeFlag:r,patchFlag:o,dynamicProps:n,dynamicChildren:null,appContext:null,ctx:ee};return s?(Qn(a,e),r&128&&t.normalize(a)):e&&(a.shapeFlag|=Gt(e)?8:16),bn>0&&!l&&ve&&(a.patchFlag>0||r&6)&&a.patchFlag!==32&&ve.push(a),a}const ut=$d;function $d(t,i=null,e=null,o=0,n=null,r=!1){if((!t||t===Xc)&&(t=ti),ks(t)){const s=Ui(t,i,!0);return e&&Qn(s,e),bn>0&&!r&&ve&&(s.shapeFlag&6?ve[ve.indexOf(t)]=s:ve.push(s)),s.patchFlag=-2,s}if(zd(t)&&(t=t.__vccOpts),i){i=Id(i);let{class:s,style:a}=i;s&&!Gt(s)&&(i.class=$t(s)),Ot(a)&&(fs(a)&&!Ct(a)&&(a=ie({},a)),i.style=os(a))}const l=Gt(t)?1:Il(t)?128:Nc(t)?64:Ot(t)?4:It(t)?2:0;return m(t,i,e,o,n,l,r,!0)}function Id(t){return t?fs(t)||bl(t)?ie({},t):t:null}function Ui(t,i,e=!1,o=!1){const{props:n,ref:r,patchFlag:l,children:s,transition:a}=t,c=i?Ad(n||{},i):n,d={__v_isVNode:!0,__v_skip:!0,type:t.type,props:c,key:c&&Tl(c),ref:i&&i.ref?e&&r?Ct(r)?r.concat(zn(i)):[r,zn(i)]:zn(i):r,scopeId:t.scopeId,slotScopeIds:t.slotScopeIds,children:s,target:t.target,targetStart:t.targetStart,targetAnchor:t.targetAnchor,staticCount:t.staticCount,shapeFlag:t.shapeFlag,patchFlag:i&&t.type!==Ut?l===-1?16:l|16:l,dynamicProps:t.dynamicProps,dynamicChildren:t.dynamicChildren,appContext:t.appContext,dirs:t.dirs,transition:a,component:t.component,suspense:t.suspense,ssContent:t.ssContent&&Ui(t.ssContent),ssFallback:t.ssFallback&&Ui(t.ssFallback),placeholder:t.placeholder,el:t.el,anchor:t.anchor,ctx:t.ctx,ce:t.ce};return a&&o&&hs(d,a.clone(d)),d}function Go(t=" ",i=0){return ut(mo,null,t,i)}function xe(t,i){const e=ut(Rn,null,t);return e.staticCount=i,e}function Pt(t="",i=!1){return i?(tt(),$e(ti,null,t)):ut(ti,null,t)}function Oe(t){return t==null||typeof t=="boolean"?ut(ti):Ct(t)?ut(Ut,null,t.slice()):ks(t)?Ve(t):ut(mo,null,String(t))}function Ve(t){return t.el===null&&t.patchFlag!==-1||t.memo?t:Ui(t)}function Qn(t,i){let e=0;const{shapeFlag:o}=t;if(i==null)i=null;else if(Ct(i))e=16;else if(typeof i=="object")if(o&65){const n=i.default;n&&(n._c&&(n._d=!1),Qn(t,n()),n._c&&(n._d=!0));return}else{e=32;const n=i._;!n&&!bl(i)?i._ctx=ee:n===3&&ee&&(ee.slots._===1?i._=1:(i._=2,t.patchFlag|=1024))}else if(It(i)){if(o&65){Qn(t,{default:i});return}i={default:i,_ctx:ee},e=32}else i=String(i),o&64?(e=16,i=[Go(i)]):e=8;t.children=i,t.shapeFlag|=e}function Ad(...t){const i={};for(let e=0;e<t.length;e++){const o=t[e];for(const n in o)if(n==="class")i.class!==o.class&&(i.class=$t([i.class,o.class]));else if(n==="style")i.style=os([i.style,o.style]);else if(no(n)){const r=i[n],l=o[n];l&&r!==l&&!(Ct(r)&&r.includes(l))?i[n]=r?[].concat(r,l):l:l==null&&r==null&&!oo(n)&&(i[n]=l)}else n!==""&&(i[n]=o[n])}return i}function Me(t,i,e,o=null){Ee(t,i,7,[e,o])}const Td=pl();let Ed=0;function Bd(t,i,e){const o=t.type,n=(i?i.appContext:t.appContext)||Td,r={uid:Ed++,vnode:t,type:o,parent:i,appContext:n,root:null,next:null,subTree:null,effect:null,update:null,job:null,scope:new nc(!0),render:null,proxy:null,exposed:null,exposeProxy:null,withProxy:null,provides:i?i.provides:Object.create(n.provides),ids:i?i.ids:["",0,0],accessCache:null,renderCache:[],components:null,directives:null,propsOptions:kl(o,n),emitsOptions:hl(o,n),emit:null,emitted:null,propsDefaults:Nt,inheritAttrs:o.inheritAttrs,ctx:Nt,data:Nt,props:Nt,attrs:Nt,slots:Nt,refs:Nt,setupState:Nt,setupContext:null,suspense:e,suspenseId:e?e.pendingId:0,asyncDep:null,asyncResolved:!1,isMounted:!1,isUnmounted:!1,isDeactivated:!1,bc:null,c:null,bm:null,m:null,bu:null,u:null,um:null,bum:null,da:null,a:null,rtg:null,rtc:null,ec:null,sp:null};return r.ctx={_:r},r.root=i?i.root:r,r.emit=cd.bind(null,r),t.ce&&t.ce(r),r}let se=null;const Md=()=>se||ee;let to,Zo;{const t=ao(),i=(e,o)=>{let n;return(n=t[e])||(n=t[e]=[]),n.push(o),r=>{n.length>1?n.forEach(l=>l(r)):n[0](r)}};to=i("__VUE_INSTANCE_SETTERS__",e=>se=e),Zo=i("__VUE_SSR_SETTERS__",e=>yn=e)}const Cn=t=>{const i=se;return to(t),t.scope.on(),()=>{t.scope.off(),to(i)}},Ys=()=>{se&&se.scope.off(),to(null)};function El(t){return t.vnode.shapeFlag&4}let yn=!1;function Dd(t,i=!1,e=!1){i&&Zo(i);const{props:o,children:n}=t.vnode,r=El(t);md(t,o,r,i),yd(t,n,e||i);const l=r?Ld(t,i):void 0;return i&&Zo(!1),l}function Ld(t,i){const e=t.type;t.accessCache=Object.create(null),t.proxy=new Proxy(t.ctx,td);const{setup:o}=e;if(o){Je();const n=t.setupContext=o.length>1?Od(t):null,r=Cn(t),l=_n(o,t,0,[t.props,n]),s=Er(l);if(Xe(),r(),(s||t.sp)&&!zi(t)&&ll(t),s){if(l.then(Ys,Ys),i)return l.then(a=>{Js(t,a)}).catch(a=>{fo(a,t,0)});t.asyncDep=l}else Js(t,l)}else Bl(t)}function Js(t,i,e){It(i)?t.type.__ssrInlineRender?t.ssrRender=i:t.render=i:Ot(i)&&(t.setupState=Jr(i)),Bl(t)}function Bl(t,i,e){const o=t.type;t.render||(t.render=o.render||Fe);{const n=Cn(t);Je();try{ed(t)}finally{Xe(),n()}}}const Pd={get(t,i){return oe(t,"get",""),t[i]}};function Od(t){const i=e=>{t.exposed=e||{}};return{attrs:new Proxy(t.attrs,Pd),slots:t.slots,emit:t.emit,expose:i}}function go(t){return t.exposed?t.exposeProxy||(t.exposeProxy=new Proxy(Jr(_c(t.exposed)),{get(i,e){if(e in i)return i[e];if(e in cn)return cn[e](t)},has(i,e){return e in i||e in cn}})):t.proxy}function Rd(t,i=!0){return It(t)?t.displayName||t.name:t.name||i&&t.__name}function zd(t){return It(t)&&"__vccOpts"in t}const St=(t,i)=>Ac(t,i,yn),Nd="3.5.40";/**
* @vue/runtime-dom v3.5.40
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/let Yo;const Xs=typeof window<"u"&&window.trustedTypes;if(Xs)try{Yo=Xs.createPolicy("vue",{createHTML:t=>t})}catch{}const Ml=Yo?t=>Yo.createHTML(t):t=>t,Fd="http://www.w3.org/2000/svg",jd="http://www.w3.org/1998/Math/MathML",We=typeof document<"u"?document:null,Qs=We&&We.createElement("template"),Hd={insert:(t,i,e)=>{i.insertBefore(t,e||null)},remove:t=>{const i=t.parentNode;i&&i.removeChild(t)},createElement:(t,i,e,o)=>{const n=i==="svg"?We.createElementNS(Fd,t):i==="mathml"?We.createElementNS(jd,t):e?We.createElement(t,{is:e}):We.createElement(t);return t==="select"&&o&&o.multiple!=null&&n.setAttribute("multiple",o.multiple),n},createText:t=>We.createTextNode(t),createComment:t=>We.createComment(t),setText:(t,i)=>{t.nodeValue=i},setElementText:(t,i)=>{t.textContent=i},parentNode:t=>t.parentNode,nextSibling:t=>t.nextSibling,querySelector:t=>We.querySelector(t),setScopeId(t,i){t.setAttribute(i,"")},insertStaticContent(t,i,e,o,n,r){const l=e?e.previousSibling:i.lastChild;if(n&&(n===r||n.nextSibling))for(;i.insertBefore(n.cloneNode(!0),e),!(n===r||!(n=n.nextSibling)););else{Qs.innerHTML=Ml(o==="svg"?`<svg>${t}</svg>`:o==="mathml"?`<math>${t}</math>`:t);const s=Qs.content;if(o==="svg"||o==="mathml"){const a=s.firstChild;for(;a.firstChild;)s.appendChild(a.firstChild);s.removeChild(a)}i.insertBefore(s,e)}return[l?l.nextSibling:i.firstChild,e?e.previousSibling:i.lastChild]}},Ud=Symbol("_vtc");function Wd(t,i,e){const o=t[Ud];o&&(i=(i?[i,...o]:[...o]).join(" ")),i==null?t.removeAttribute("class"):e?t.setAttribute("class",i):t.className=i}const eo=Symbol("_vod"),Dl=Symbol("_vsh"),Ll={name:"show",beforeMount(t,{value:i},{transition:e}){t[eo]=t.style.display==="none"?"":t.style.display,e&&i?e.beforeEnter(t):Xi(t,i)},mounted(t,{value:i},{transition:e}){e&&i&&e.enter(t)},updated(t,{value:i,oldValue:e},{transition:o}){!i!=!e&&(o?i?(o.beforeEnter(t),Xi(t,!0),o.enter(t)):o.leave(t,()=>{Xi(t,!1)}):Xi(t,i))},beforeUnmount(t,{value:i}){Xi(t,i)}};function Xi(t,i){t.style.display=i?t[eo]:"none",t[Dl]=!i}const Vd=Symbol(""),Kd=/(?:^|;)\s*display\s*:/;function qd(t,i,e){const o=t.style,n=Gt(e);let r=!1;if(e&&!n){if(i)if(Gt(i))for(const l of i.split(";")){const s=l.slice(0,l.indexOf(":")).trim();e[s]==null&&en(o,s,"")}else for(const l in i)e[l]==null&&en(o,l,"");for(const l in e){l==="display"&&(r=!0);const s=e[l];s!=null?Zd(t,l,!Gt(i)&&i?i[l]:void 0,s)||en(o,l,s):en(o,l,"")}}else if(n){if(i!==e){const l=o[Vd];l&&(e+=";"+l),o.cssText=e,r=Kd.test(e)}}else i&&t.removeAttribute("style");eo in t&&(t[eo]=r?o.display:"",t[Dl]&&(o.display="none"))}const tr=/\s*!important$/;function en(t,i,e){if(Ct(e))e.forEach(o=>en(t,i,o));else if(e==null&&(e=""),i.startsWith("--"))t.setProperty(i,e);else{const o=Gd(t,i);tr.test(e)?t.setProperty(ci(o),e.replace(tr,""),"important"):t[o]=e}}const er=["Webkit","Moz","ms"],To={};function Gd(t,i){const e=To[i];if(e)return e;let o=ce(i);if(o!=="filter"&&o in t)return To[i]=o;o=ro(o);for(let n=0;n<er.length;n++){const r=er[n]+o;if(r in t)return To[i]=r}return i}function Zd(t,i,e,o){return t.tagName==="TEXTAREA"&&(i==="width"||i==="height")&&Gt(o)&&e===o}const ir="http://www.w3.org/1999/xlink";function nr(t,i,e,o,n,r=ec(i)){o&&i.startsWith("xlink:")?e==null?t.removeAttributeNS(ir,i.slice(6,i.length)):t.setAttributeNS(ir,i,e):e==null||r&&!Lr(e)?t.removeAttribute(i):t.setAttribute(i,r?"":Ae(e)?String(e):e)}function or(t,i,e,o,n){if(i==="innerHTML"||i==="textContent"){e!=null&&(t[i]=i==="innerHTML"?Ml(e):e);return}const r=t.tagName;if(i==="value"&&r!=="PROGRESS"&&!r.includes("-")){const s=r==="OPTION"?t.getAttribute("value")||"":t.value,a=e==null?t.type==="checkbox"?"on":"":String(e);(s!==a||!("_value"in t))&&(t.value=a),e==null&&t.removeAttribute(i),t._value=e;return}let l=!1;if(e===""||e==null){const s=typeof t[i];s==="boolean"?e=Lr(e):e==null&&s==="string"?(e="",l=!0):s==="number"&&(e=0,l=!0)}try{t[i]=e}catch{}l&&t.removeAttribute(n||i)}function oi(t,i,e,o){t.addEventListener(i,e,o)}function Yd(t,i,e,o){t.removeEventListener(i,e,o)}const sr=Symbol("_vei");function Jd(t,i,e,o,n=null){const r=t[sr]||(t[sr]={}),l=r[i];if(o&&l)l.value=o;else{const[s,a]=tu(i);if(o){const c=r[i]=nu(o,n);oi(t,s,c,a)}else l&&(Yd(t,s,l,a),r[i]=void 0)}}const Xd=/(Once|Passive|Capture)$/,Qd=/^on:?(?:Once|Passive|Capture)$/;function tu(t){let i,e;for(;(e=t.match(Xd))&&!Qd.test(t);)i||(i={}),t=t.slice(0,t.length-e[1].length),i[e[1].toLowerCase()]=!0;return[t[2]===":"?t.slice(3):ci(t.slice(2)),i]}let Eo=0;const eu=Promise.resolve(),iu=()=>Eo||(eu.then(()=>Eo=0),Eo=Date.now());function nu(t,i){const e=o=>{if(!o._vts)o._vts=Date.now();else if(o._vts<=e.attached)return;const n=e.value;if(Ct(n)){const r=o.stopImmediatePropagation;o.stopImmediatePropagation=()=>{r.call(o),o._stopped=!0};const l=n.slice(),s=[o];for(let a=0;a<l.length&&!o._stopped;a++){const c=l[a];c&&Ee(c,i,5,s)}}else Ee(n,i,5,[o])};return e.value=t,e.attached=iu(),e}const rr=t=>t.charCodeAt(0)===111&&t.charCodeAt(1)===110&&t.charCodeAt(2)>96&&t.charCodeAt(2)<123,ou=(t,i,e,o,n,r)=>{const l=n==="svg";i==="class"?Wd(t,o,l):i==="style"?qd(t,e,o):no(i)?oo(i)||Jd(t,i,e,o,r):(i[0]==="."?(i=i.slice(1),!0):i[0]==="^"?(i=i.slice(1),!1):su(t,i,o,l))?(or(t,i,o),!t.tagName.includes("-")&&(i==="value"||i==="checked"||i==="selected")&&nr(t,i,o,l,r,i!=="value")):t._isVueCE&&(ru(t,i)||t._def.__asyncLoader&&(/[A-Z]/.test(i)||!Gt(o)))?or(t,ce(i),o,r,i):(i==="true-value"?t._trueValue=o:i==="false-value"&&(t._falseValue=o),nr(t,i,o,l))};function su(t,i,e,o){if(o)return!!(i==="innerHTML"||i==="textContent"||i in t&&rr(i)&&It(e));if(i==="spellcheck"||i==="draggable"||i==="translate"||i==="autocorrect"||i==="sandbox"&&t.tagName==="IFRAME"||i==="form"||i==="list"&&t.tagName==="INPUT"||i==="type"&&t.tagName==="TEXTAREA")return!1;if(i==="width"||i==="height"){const n=t.tagName;if(n==="IMG"||n==="VIDEO"||n==="CANVAS"||n==="SOURCE")return!1}return rr(i)&&Gt(e)?!1:i in t}function ru(t,i){const e=t._def.props;if(!e)return!1;const o=ce(i);return Array.isArray(e)?e.some(n=>ce(n)===o):Object.keys(e).some(n=>ce(n)===o)}const Wi=t=>{const i=t.props["onUpdate:modelValue"]||!1;return Ct(i)?e=>On(i,e):i};function lu(t){t.target.composing=!0}function lr(t){const i=t.target;i.composing&&(i.composing=!1,i.dispatchEvent(new Event("input")))}const Ye=Symbol("_assign");function ar(t,i,e){return i&&(t=t.trim()),e&&(t=lo(t)),t}const io={created(t,{modifiers:{lazy:i,trim:e,number:o}},n){t[Ye]=Wi(n);const r=o||n.props&&n.props.type==="number";oi(t,i?"change":"input",l=>{l.target.composing||t[Ye](ar(t.value,e,r))}),(e||r)&&oi(t,"change",()=>{t.value=ar(t.value,e,r)}),i||(oi(t,"compositionstart",lu),oi(t,"compositionend",lr),oi(t,"change",lr))},mounted(t,{value:i}){t.value=i??""},beforeUpdate(t,{value:i,oldValue:e,modifiers:{lazy:o,trim:n,number:r}},l){if(t[Ye]=Wi(l),t.composing)return;const s=(r||t.type==="number")&&!/^0\d/.test(t.value)?lo(t.value):t.value,a=i??"";if(s===a)return;const c=t.getRootNode();(c instanceof Document||c instanceof ShadowRoot)&&c.activeElement===t&&t.type!=="range"&&(o&&i===e||n&&t.value.trim()===a)||(t.value=a)}},Dn={deep:!0,created(t,i,e){t[Ye]=Wi(e),oi(t,"change",()=>{const o=t._modelValue,n=kn(t),r=t.checked,l=t[Ye];if(Ct(o)){const s=ss(o,n),a=s!==-1;if(r&&!a)l(o.concat(n));else if(!r&&a){const c=[...o];c.splice(s,1),l(c)}}else if(Ki(o)){const s=new Set(o);r?s.add(n):s.delete(n),l(s)}else l(Pl(t,r))})},mounted:cr,beforeUpdate(t,i,e){t[Ye]=Wi(e),cr(t,i,e)}};function cr(t,{value:i,oldValue:e},o){t._modelValue=i;let n;if(Ct(i))n=ss(i,o.props.value)>-1;else if(Ki(i))n=i.has(o.props.value);else{if(i===e)return;n=qi(i,Pl(t,!0))}t.checked!==n&&(t.checked=n)}const au={deep:!0,created(t,{value:i,modifiers:{number:e}},o){t._modelValue=i,oi(t,"change",()=>{const n=Array.prototype.filter.call(t.options,r=>r.selected).map(r=>e?lo(kn(r)):kn(r));t[Ye](t.multiple?Ki(t._modelValue)?new Set(n):n:n[0]),t._assigning=!0,Qr(()=>{t._assigning=!1})}),t[Ye]=Wi(o)},mounted(t,{value:i}){dr(t,i)},beforeUpdate(t,{value:i},e){t._modelValue=i,t[Ye]=Wi(e)},updated(t,{value:i}){t._assigning||dr(t,i)}};function dr(t,i){const e=t.multiple,o=Ct(i);if(!(e&&!o&&!Ki(i))){for(let n=0,r=t.options.length;n<r;n++){const l=t.options[n],s=kn(l);if(e)if(o){const a=typeof s;a==="string"||a==="number"?l.selected=i.some(c=>String(c)===String(s)):l.selected=ss(i,s)>-1}else l.selected=i.has(s);else if(qi(kn(l),i)){t.selectedIndex!==n&&(t.selectedIndex=n);return}}!e&&t.selectedIndex!==-1&&(t.selectedIndex=-1)}}function kn(t){return"_value"in t?t._value:t.value}function Pl(t,i){const e=i?"_trueValue":"_falseValue";return e in t?t[e]:i}const cu=["ctrl","shift","alt","meta"],du={stop:t=>t.stopPropagation(),prevent:t=>t.preventDefault(),self:t=>t.target!==t.currentTarget,ctrl:t=>!t.ctrlKey,shift:t=>!t.shiftKey,alt:t=>!t.altKey,meta:t=>!t.metaKey,left:t=>"button"in t&&t.button!==0,middle:t=>"button"in t&&t.button!==1,right:t=>"button"in t&&t.button!==2,exact:(t,i)=>cu.some(e=>t[`${e}Key`]&&!i.includes(e))},Ce=(t,i)=>{if(!t)return t;const e=t._withMods||(t._withMods={}),o=i.join(".");return e[o]||(e[o]=((n,...r)=>{for(let l=0;l<i.length;l++){const s=du[i[l]];if(s&&s(n,i))return}return t(n,...r)}))},uu={esc:"escape",space:" ",up:"arrow-up",left:"arrow-left",right:"arrow-right",down:"arrow-down",delete:"backspace"},fu=(t,i)=>{const e=t._withKeys||(t._withKeys={}),o=i.join(".");return e[o]||(e[o]=(n=>{if(!("key"in n))return;const r=ci(n.key);if(i.some(l=>l===r||uu[l]===r))return t(n)}))},pu=ie({patchProp:ou},Hd);let ur;function hu(){return ur||(ur=wd(pu))}const Ol=((...t)=>{const i=hu().createApp(...t),{mount:e}=i;return i.mount=o=>{const n=gu(o);if(!n)return;const r=i._component;!It(r)&&!r.render&&!r.template&&(r.template=n.innerHTML),n.nodeType===1&&(n.textContent="");const l=e(n,!1,mu(n));return n instanceof Element&&(n.removeAttribute("v-cloak"),n.setAttribute("data-v-app","")),l},i});function mu(t){if(t instanceof SVGElement)return"svg";if(typeof MathMLElement=="function"&&t instanceof MathMLElement)return"mathml"}function gu(t){return Gt(t)?document.querySelector(t):t}function vu(){if(typeof window<"u"&&typeof window.require=="function")return window.require.bind(window);if(typeof globalThis<"u"&&typeof globalThis.require=="function")return globalThis.require.bind(globalThis);if(typeof require=="function")return require}function be(t){const i=vu();if(i)try{return i(t)}catch{try{const e=t.startsWith("node:")?t.slice(5):`node:${t}`;return i(e)}catch{}}}function ws(){var i;if(typeof window<"u"&&window.process)return window.process;const t=be("process");return t&&t.versions?t:typeof process<"u"&&((i=process.versions)!=null&&i.node)?process:globalThis.process}function Rl(){var i,e;const t=ws();if(t&&((i=t.versions)!=null&&i.node))return!0;if(typeof window<"u"&&window.siyuan){const o=be("child_process");if(o&&typeof o.spawn=="function")return!0}return!!(typeof process<"u"&&((e=process.versions)!=null&&e.node))}function wn(){const t=ws();if(t!=null&&t.platform)return t.platform;if(typeof process<"u"&&process.platform)return process.platform;const i=be("os");if(i&&typeof i.platform=="function")return i.platform();if(typeof navigator<"u"){const e=navigator.userAgent.toLowerCase();if(e.includes("win"))return"win32";if(e.includes("mac"))return"darwin";if(e.includes("linux"))return"linux"}return"web"}function zl(){var o,n;const t=ws(),i={...(t==null?void 0:t.env)||{}};if(wn()==="win32"){const r=["C:\\Program Files\\nodejs","C:\\Program Files (x86)\\nodejs",(o=t==null?void 0:t.env)!=null&&o.APPDATA?`${t.env.APPDATA}\\npm`:"",(n=t==null?void 0:t.env)!=null&&n.USERPROFILE?`${t.env.USERPROFILE}\\AppData\\Roaming\\npm`:""].filter(Boolean),l=Object.keys(i).find(c=>c.toLowerCase()==="path")||"PATH",a=(i[l]||"").split(";").filter(Boolean);for(const c of r)c&&!a.some(d=>d.toLowerCase()===c.toLowerCase())&&a.push(c);i[l]=a.join(";")}return i}function Jo(t){var e,o,n;if(!t)return"";if(/^[a-zA-Z]:[/\\]/.test(t))return t.replace(/\\/g,"/");let i="";if(typeof window<"u"&&((n=(o=(e=window.siyuan)==null?void 0:e.config)==null?void 0:o.system)!=null&&n.dataDir)&&(i=window.siyuan.config.system.dataDir.replace(/\\/g,"/")),i&&t.startsWith("/data/")){const r=t.slice(6);return`${i}/${r}`.replace(/\\/g,"/")}return t}function bu(){const t=be("os"),i=be("path");if(t&&typeof t.tmpdir=="function"){const e=t.tmpdir();return i&&typeof i.join=="function"?i.join(e,"siyuan-slidev-pro").replace(/\\/g,"/"):`${e}/siyuan-slidev-pro`.replace(/\\/g,"/")}return"/data/storage/petal/siyuan-slidev/pro-workspace"}class xs{constructor(i){kt(this,"runner");this.runner=i||xs.defaultRunner}static async defaultRunner(i,e){var o;try{let n=(o=be("child_process"))==null?void 0:o.execFile;if(!n){const a=await import("node:child_process").catch(()=>({}));n=a==null?void 0:a.execFile}if(!n)return{code:-1,stdout:"",stderr:"child_process execFile not available"};const l=wn()==="win32",s=zl();return await new Promise(a=>{n(i,e,{timeout:5e3,shell:l,env:s},(c,d,f)=>{a({code:c?c.code||1:0,stdout:d?String(d).trim():"",stderr:f?String(f).trim():""})})})}catch(n){return{code:-1,stdout:"",stderr:String(n)}}}async detect(){const i=Rl(),e=wn();if(!i)return{hasNode:!1,hasSlidevCli:!1,platform:"browser",isDesktop:!1,error:"当前处于纯前端浏览器或移动端环境，无 Node.js 运行时支撑"};let o=!1,n,r=!1,l;try{const s=await this.runner("node",["-v"]);s.code===0&&s.stdout.startsWith("v")&&(o=!0,n=s.stdout)}catch{}if(o){try{const s=e==="win32"?"slidev.cmd":"slidev",a=await this.runner(s,["--version"]);a.code===0&&a.stdout&&(r=!0,l=a.stdout)}catch{}if(!r)try{const s=e==="win32"?"npx.cmd":"npx",a=await this.runner(s,["@slidev/cli","--version"]);a.code===0&&a.stdout&&(r=!0,l=a.stdout)}catch{}}return{hasNode:o,nodeVersion:n,hasSlidevCli:r,slidevVersion:l,platform:e,isDesktop:i}}}class yu{constructor(){kt(this,"iframe",null);kt(this,"isReady",!1);kt(this,"pageChangedHandlers",[]);kt(this,"readyHandlers",[]);kt(this,"currentState",{no:1,clicks:0,total:1});this.handleWindowMessage=this.handleWindowMessage.bind(this)}getCurrentState(){return{...this.currentState}}attach(i){this.detach(),this.iframe=i,this.isReady=!1,typeof window<"u"&&window.addEventListener("message",this.handleWindowMessage)}detach(){typeof window<"u"&&window.removeEventListener("message",this.handleWindowMessage),this.iframe=null,this.isReady=!1}postMessage(i,e){var n;if(!((n=this.iframe)!=null&&n.contentWindow))return;const o={target:"slidev",sender:"siyuan",type:i,...e};try{this.iframe.contentWindow.postMessage(o,"*")}catch(r){console.warn("[NativeSlidevBridge] postMessage error:",r)}}navigateToPage(i){this.postMessage("navigate",{no:i})}next(){this.postMessage("next")}prev(){this.postMessage("prev")}nextClick(){this.postMessage("next-click")}prevClick(){this.postMessage("prev-click")}onPageChanged(i){return this.pageChangedHandlers.push(i),()=>{this.pageChangedHandlers=this.pageChangedHandlers.filter(e=>e!==i)}}onReady(i){return this.readyHandlers.push(i),()=>{this.readyHandlers=this.readyHandlers.filter(e=>e!==i)}}handleWindowMessage(i){const e=i.data;if(!(!e||e.target!=="slidev")){if(!this.isReady){this.isReady=!0;for(const o of this.readyHandlers)o()}if(e.type==="update-state"&&e.navState){const o=e.navState;this.currentState={no:o.no??this.currentState.no,clicks:o.clicks??this.currentState.clicks,total:o.total??this.currentState.total,hasNext:o.hasNext,hasPrev:o.hasPrev};for(const n of this.pageChangedHandlers)n(this.currentState.no,this.currentState.total||1,this.currentState)}else if(e.type==="navigate"&&typeof e.no=="number"){this.currentState.no=e.no;for(const o of this.pageChangedHandlers)o(e.no,this.currentState.total||1,this.currentState)}}}}class ku{constructor(i){kt(this,"childProcess",null);kt(this,"activePort",null);kt(this,"isRunning",!1);kt(this,"defaultPort");kt(this,"maxPortRetries");kt(this,"probeTimeoutMs");kt(this,"customSpawner");kt(this,"customPortChecker");this.defaultPort=(i==null?void 0:i.defaultPort)||3030,this.maxPortRetries=(i==null?void 0:i.maxPortRetries)||20,this.probeTimeoutMs=(i==null?void 0:i.probeTimeoutMs)||1e4,this.customSpawner=i==null?void 0:i.customSpawner,this.customPortChecker=i==null?void 0:i.customPortChecker}getActivePort(){return this.activePort}getIsRunning(){return this.isRunning}async isPortAvailable(i){if(this.customPortChecker)return this.customPortChecker(i);try{let e=be("net");return e||(e=await import("node:net").catch(()=>({}))),e!=null&&e.createServer?await new Promise(o=>{const n=e.createServer();n.once("error",()=>o(!1)),n.once("listening",()=>{n.close(()=>o(!0))}),n.listen(i,"127.0.0.1")}):!0}catch{return!0}}async allocPort(i){const e=i||this.defaultPort;for(let o=0;o<this.maxPortRetries;o++){const n=e+o;if(await this.isPortAvailable(n))return n}return e}async pollServerReady(i,e=8e3,o=300){const n=Date.now();for(;Date.now()-n<e;){try{const r=new AbortController,l=setTimeout(()=>r.abort(),o),s=await fetch(i,{method:"HEAD",mode:"no-cors",signal:r.signal}).catch(()=>null);if(clearTimeout(l),s)return!0}catch{}await new Promise(r=>setTimeout(r,o))}return!1}async startServer(i,e){var a,c;if(this.isRunning&&this.activePort)return{success:!0,port:this.activePort,url:`http://localhost:${this.activePort}?embedded=true`};const o=await this.allocPort(e);this.activePort=o;const r=wn()==="win32"?"npx.cmd":"npx",l=Jo(i),s=["@slidev/cli",l,"--port",String(o),"--no-open"];try{if(this.customSpawner)this.childProcess=this.customSpawner(r,s,{detached:!1});else{let f=(a=be("child_process"))==null?void 0:a.spawn;if(!f){const k=await import("node:child_process").catch(()=>({}));f=k==null?void 0:k.spawn}if(!f)throw new Error("child_process spawn not available in current runtime");const g=l.includes("/")||l.includes("\\")?l.replace(/[/\\][^/\\]+$/,""):void 0,u=zl();this.childProcess=f(r,s,{cwd:g,detached:!1,shell:!0,env:{...u,FORCE_COLOR:"1"}})}this.isRunning=!0,(c=this.childProcess)!=null&&c.on&&this.childProcess.on("exit",()=>{this.isRunning=!1,this.activePort=null,this.childProcess=null});const d=`http://localhost:${o}`;return!this.customSpawner&&!await this.pollServerReady(d,this.probeTimeoutMs)?(this.stopServer(),{success:!1,port:o,url:"",error:`Slidev DevServer 启动超时 (未在 ${this.probeTimeoutMs}ms 内响应端口 ${o})`}):{success:!0,port:o,url:`${d}?embedded=true`}}catch(d){return this.stopServer(),{success:!1,port:o,url:"",error:`唤起 Slidev 进程失败: ${String(d)}`}}}stopServer(){var i;if(this.childProcess){try{if(this.childProcess.kill("SIGTERM"),wn()==="win32"&&this.childProcess.pid&&!this.customSpawner){const o=(i=be("child_process"))==null?void 0:i.exec;o?o(`taskkill /pid ${this.childProcess.pid} /T /F`,()=>{}):import("node:child_process").then(({exec:n})=>{var r;n(`taskkill /pid ${(r=this.childProcess)==null?void 0:r.pid} /T /F`,()=>{})}).catch(()=>{})}}catch{}this.childProcess=null}this.isRunning=!1,this.activePort=null}}class _s{constructor(){kt(this,"iframe",null);kt(this,"isReady",!1);kt(this,"pendingMessages",[]);kt(this,"slideChangedHandlers",[]);kt(this,"blockClickedHandlers",[]);kt(this,"openInEditorHandlers",[]);kt(this,"clientReadyHandlers",[]);kt(this,"openPeekDrawerHandlers",[]);kt(this,"toggleFullscreenHandlers",[]);this.handleWindowMessage=this.handleWindowMessage.bind(this)}attach(i){this.detach(),this.iframe=i,this.isReady=!1,typeof window<"u"&&window.addEventListener("message",this.handleWindowMessage)}detach(){typeof window<"u"&&window.removeEventListener("message",this.handleWindowMessage),this.iframe=null,this.isReady=!1,this.pendingMessages=[]}postMessage(i,e){var n;const o={source:"siyuan-slidev-host",action:i,payload:e};if(!((n=this.iframe)!=null&&n.contentWindow)||!this.isReady){this.pendingMessages.push(o);return}try{this.iframe.contentWindow.postMessage(o,"*")}catch(r){console.warn("[WebSandboxBridge] postMessage error:",r)}}updateSlides(i,e,o,n){this.postMessage("UPDATE_SLIDES",{slides:i,config:e,fullMarkdown:o,customThemeCss:n})}navigatePage(i){this.postMessage("NAVIGATE_PAGE",{pageIndex:i})}highlightElement(i){this.postMessage("HIGHLIGHT_ELEMENT",{targetBlockId:i})}nextStep(){this.postMessage("NEXT_STEP",{})}prevStep(){this.postMessage("PREV_STEP",{})}freezeKeyboardNav(i){this.postMessage("FREEZE_KEYBOARD_NAV",{frozen:i})}onSlideChanged(i){return this.slideChangedHandlers.push(i),()=>{this.slideChangedHandlers=this.slideChangedHandlers.filter(e=>e!==i)}}onBlockClicked(i){return this.blockClickedHandlers.push(i),()=>{this.blockClickedHandlers=this.blockClickedHandlers.filter(e=>e!==i)}}onOpenInEditor(i){return this.openInEditorHandlers.push(i),()=>{this.openInEditorHandlers=this.openInEditorHandlers.filter(e=>e!==i)}}onOpenPeekDrawer(i){return this.openPeekDrawerHandlers.push(i),()=>{this.openPeekDrawerHandlers=this.openPeekDrawerHandlers.filter(e=>e!==i)}}onRequestToggleFullscreen(i){return this.toggleFullscreenHandlers.push(i),()=>{this.toggleFullscreenHandlers=this.toggleFullscreenHandlers.filter(e=>e!==i)}}onClientReady(i){return this.clientReadyHandlers.push(i),()=>{this.clientReadyHandlers=this.clientReadyHandlers.filter(e=>e!==i)}}handleWindowMessage(i){var o;const e=i.data;if(!(!e||e.source!=="siyuan-slidev-client"))switch(e.action){case"CLIENT_READY":for(this.isReady=!0;this.pendingMessages.length>0;){const n=this.pendingMessages.shift();n&&((o=this.iframe)!=null&&o.contentWindow)&&this.iframe.contentWindow.postMessage(n,"*")}for(const n of this.clientReadyHandlers)n();break;case"SLIDE_CHANGED":if(e.payload.currentPage!==void 0)for(const n of this.slideChangedHandlers)n(e.payload.currentPage,e.payload.totalPages||1,e.payload.currentBlockId||"");break;case"BLOCK_CLICKED":if(e.payload.clickedBlockId)for(const n of this.blockClickedHandlers)n(e.payload.clickedBlockId,e.payload.currentPage||1);break;case"OPEN_IN_EDITOR":if(e.payload.blockId||e.payload.clickedBlockId){const n=e.payload.blockId||e.payload.clickedBlockId||"";for(const r of this.openInEditorHandlers)r(n,e.payload.currentPage||1)}break;case"OPEN_PEEK_DRAWER":if(e.payload.peekType){const n=e.payload.blockId||e.payload.url||"",r={peekType:e.payload.peekType,target:n,title:e.payload.title};for(const l of this.openPeekDrawerHandlers)l(r)}break;case"REQUEST_TOGGLE_FULLSCREEN":for(const n of this.toggleFullscreenHandlers)n();break}}}const Nl={"snippets/external.ts":`// Inside ./snippets/external.ts
// #region snippet
export function emptyArray<T>(length: number) {
  return Array.from<T>({ length })
}
// #endregion snippet

export function sayHello() {
  console.log('Hello from snippets/external.ts')
}
`},wu=`<template>
  <div class="slidev-layout three-cols-header w-full h-full flex flex-col">
    <div class="header-section mb-4 w-full">
      <slot />
    </div>
    <div class="grid grid-cols-3 gap-6 flex-1 items-stretch">
      <div class="col-1 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-1" />
      </div>
      <div class="col-2 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-2" />
      </div>
      <div class="col-3 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-3" />
      </div>
    </div>
  </div>
</template>
`,xu=`// Auto-generated by SiYuan Slidev Studio
export default function() {
  if (typeof window === 'undefined') return
  window.addEventListener('click', (e: MouseEvent) => {
    const target = e.target as HTMLElement | null
    if (!target || !target.closest) return

    const refEl = target.closest('[data-ref-id]')
    if (refEl) {
      const blockId = refEl.getAttribute('data-ref-id')
      if (blockId) {
        e.preventDefault()
        e.stopPropagation()
        window.parent.postMessage({
          source: 'siyuan-slidev-client',
          action: 'OPEN_PEEK_DRAWER',
          payload: { peekType: 'siyuan', blockId, title: (refEl.innerText || refEl.title || '').trim() }
        }, '*')
        return
      }
    }

    const linkEl = target.closest('a') as HTMLAnchorElement | null
    if (linkEl) {
      const href = linkEl.getAttribute('href') || ''
      if (href.startsWith('siyuan://blocks/')) {
        e.preventDefault()
        e.stopPropagation()
        const cleanBlockId = href.replace('siyuan://blocks/', '').split('?')[0]
        window.parent.postMessage({
          source: 'siyuan-slidev-client',
          action: 'OPEN_PEEK_DRAWER',
          payload: { peekType: 'siyuan', blockId: cleanBlockId, title: (linkEl.innerText || linkEl.title || '').trim() }
        }, '*')
      } else if (/^https?:\\/\\//i.test(href)) {
        e.preventDefault()
        e.stopPropagation()
        window.parent.postMessage({
          source: 'siyuan-slidev-client',
          action: 'OPEN_PEEK_DRAWER',
          payload: { peekType: 'web', url: href, title: (linkEl.innerText || linkEl.title || '').trim() }
        }, '*')
      }
    }
  }, true)
}
`,_u=`${zo}

/* Auto-generated by SiYuan Slidev Studio */
.slidev-ref-tag,
a.slidev-ref-tag {
  display: inline-flex;
  align-items: center;
  background: color-mix(in srgb, var(--slidev-theme-primary, #10b981) 12%, transparent);
  color: var(--slidev-theme-primary, #10b981);
  border-radius: 4px;
  padding: 2px 8px;
  font-size: 0.88em;
  text-decoration: none;
  border: 1px solid color-mix(in srgb, var(--slidev-theme-primary, #10b981) 25%, transparent);
  cursor: pointer;
  transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
  user-select: none;
}

.slidev-ref-tag:hover,
a.slidev-ref-tag:hover {
  background: color-mix(in srgb, var(--slidev-theme-primary, #10b981) 22%, transparent);
  color: var(--slidev-theme-primary, #10b981);
  border-color: color-mix(in srgb, var(--slidev-theme-primary, #10b981) 55%, transparent);
  transform: translateY(-1px);
  box-shadow: 0 2px 8px color-mix(in srgb, var(--slidev-theme-primary, #10b981) 20%, transparent);
}

.slidev-block-ref {
  display: block;
  padding: 10px 14px;
  background: color-mix(in srgb, var(--slidev-theme-primary, #10b981) 8%, transparent);
  border-left: 3px solid var(--slidev-theme-primary, #10b981);
  border-radius: 0 6px 6px 0;
  margin: 8px 0;
  cursor: pointer;
  transition: background 0.2s ease;
}

.slidev-block-ref:hover {
  background: color-mix(in srgb, var(--slidev-theme-primary, #10b981) 15%, transparent);
}

/* 代码块自动换行与无横向滚动条 */
pre,
pre code {
  white-space: pre-wrap !important;
  word-break: break-all !important;
  overflow-wrap: anywhere !important;
  overflow-x: hidden !important;
  overflow-y: auto !important;
  max-width: 100% !important;
  box-sizing: border-box !important;
}

/* 弱提示滚动条样式 */
* {
  scrollbar-width: thin;
}
html:not(.dark) * {
  scrollbar-color: rgba(0, 0, 0, 0.15) transparent;
}
html.dark * {
  scrollbar-color: rgba(255, 255, 255, 0.20) transparent;
}
*::-webkit-scrollbar {
  width: 4px;
  height: 4px;
}
*::-webkit-scrollbar-track {
  background: transparent;
}
html:not(.dark) *::-webkit-scrollbar-thumb {
  background: rgba(0, 0, 0, 0.15);
  border-radius: 2px;
}
html:not(.dark) *:hover::-webkit-scrollbar-thumb,
html:not(.dark) *::-webkit-scrollbar-thumb:hover {
  background: rgba(0, 0, 0, 0.35);
}
html.dark *::-webkit-scrollbar-thumb {
  background: rgba(255, 255, 255, 0.20);
  border-radius: 2px;
}
html.dark *:hover::-webkit-scrollbar-thumb,
html.dark *::-webkit-scrollbar-thumb:hover {
  background: rgba(255, 255, 255, 0.45);
}

/* 多媒体（GIF动图、静态图片、MP4视频）最大化自适应且不超出视口：顶部对齐，横向居中 */
.slidev-layout img,
.slidev-layout video {
  max-width: 100% !important;
  max-height: 100% !important;
  width: auto;
  height: auto;
  object-fit: contain !important;
}
.three-cols-header video,
.two-cols-header video,
.grid-cols-3 video,
.grid-cols-2 video,
.col-1 video,
.col-2 video,
.col-3 video {
  width: auto !important;
  height: auto !important;
  max-width: 100% !important;
  max-height: 100% !important;
  object-fit: contain !important;
  display: block !important;
  margin: 0 auto !important;
}
.slide-list-media {
  display: flex !important;
  flex-direction: column !important;
  align-items: center !important;
  justify-content: flex-start !important;
  margin-top: 4px !important;
  margin-bottom: 4px !important;
  width: 100% !important;
  max-width: 100% !important;
  height: 100% !important;
  max-height: 100% !important;
  flex: 1 1 0% !important;
  overflow: hidden !important;
}
.slide-list-media img,
.slide-list-media video,
.slide-list-media .list-item-gif {
  width: auto !important;
  height: auto !important;
  max-width: 100% !important;
  max-height: 100% !important;
  object-fit: contain !important;
  border-radius: 6px !important;
  box-shadow: 0 3px 12px rgba(0, 0, 0, 0.14) !important;
  display: block !important;
  margin: 0 auto !important;
}
.slide-video-container {
  display: flex !important;
  flex-direction: column !important;
  justify-content: flex-start !important;
  align-items: center !important;
  width: 100% !important;
  max-height: 100% !important;
  margin: 6px 0 !important;
}
.slide-video-player {
  max-width: 100% !important;
  max-height: 100% !important;
  object-fit: contain !important;
  border-radius: 8px !important;
}

/* 两栏与三栏（超级块分栏）布局：紧凑自然行距，子列表保留圆点与层级缩进 */
.three-cols-header ul,
.two-cols-header ul,
.two-cols ul,
.col-1 ul,
.col-2 ul,
.col-3 ul,
.grid-cols-2 ul,
.grid-cols-3 ul {
  list-style: disc !important;
  list-style-type: disc !important;
  padding-left: 1.25em !important;
  margin-left: 0 !important;
  margin-top: 0 !important;
  margin-bottom: 8px !important;
  flex: 0 0 auto !important;
  height: auto !important;
  display: block !important;
}
.three-cols-header ol,
.two-cols-header ol,
.two-cols ol,
.col-1 ol,
.col-2 ol,
.col-3 ol,
.grid-cols-2 ol,
.grid-cols-3 ol {
  list-style: decimal !important;
  list-style-type: decimal !important;
  padding-left: 1.25em !important;
  margin-left: 0 !important;
  margin-top: 0 !important;
  margin-bottom: 8px !important;
  flex: 0 0 auto !important;
  height: auto !important;
  display: block !important;
}
.three-cols-header li,
.two-cols-header li,
.two-cols li,
.col-1 li,
.col-2 li,
.col-3 li,
.grid-cols-2 li,
.grid-cols-3 li {
  padding-left: 0.2em !important;
  margin-left: 0 !important;
  margin-bottom: 6px !important;
  flex: 0 0 auto !important;
  height: auto !important;
  display: list-item !important;
  line-height: 1.6 !important;
}
.three-cols-header ul ul,
.two-cols-header ul ul,
.two-cols ul ul,
.col-1 ul ul,
.col-2 ul ul,
.col-3 ul ul {
  list-style: circle !important;
  list-style-type: circle !important;
  padding-left: 1.25em !important;
  margin-top: 4px !important;
  margin-bottom: 4px !important;
}

/* 列表项内嵌标题与说明排版 */
.slide-list-item-title,
li > h1,
li > h2,
li > h3,
li > h4,
li > h5,
li > h6 {
  margin-top: 2px !important;
  margin-bottom: 6px !important;
  line-height: 1.35 !important;
  font-weight: 700 !important;
}
li > h1 { font-size: 1.6rem !important; }
li > h2 { font-size: 1.4rem !important; }
li > h3 { font-size: 1.22rem !important; }
li > h4 { font-size: 1.1rem !important; }
.slide-list-item-desc,
li > p {
  margin-top: 4px !important;
  margin-bottom: 6px !important;
  font-size: 1.05rem;
  line-height: 1.55;
  opacity: 0.92;
}
`;function Su(t){var n;const i=[],e=/^[ \t]*<<<[ \t]+(?:@\/|\.\/|)([^\s#]+)(?:#[^\s]+)?/gm;let o;for(;(o=e.exec(t))!==null;){const r=(n=o[1])==null?void 0:n.trim();r&&!i.includes(r)&&i.push(r)}return i}class Cu{constructor(i){kt(this,"workspacePath");kt(this,"slidesFileName");kt(this,"cliBridge",new ts);const e=bu();!(i!=null&&i.workspacePath)||i.workspacePath.includes("/data/storage/petal/siyuan-slidev/pro-workspace")?this.workspacePath=e:this.workspacePath=i.workspacePath,this.slidesFileName=(i==null?void 0:i.slidesFileName)||"slides.md"}getWorkspacePath(){return this.workspacePath}getSlidesPath(){return`${this.workspacePath}/${this.slidesFileName}`}generatePackageJson(i="default"){const e={name:"siyuan-slidev-pro-workspace",type:"module",private:!0,scripts:{dev:"slidev --port 3030",build:"slidev build"},dependencies:{"@slidev/cli":"^53.0.0","@slidev/theme-default":"latest"}};return i&&i!=="default"&&(e.dependencies[`@slidev/theme-${i}`]="latest"),JSON.stringify(e,null,2)}buildSlidesMarkdown(i){return this.cliBridge.buildStandardSlidevMarkdown(i)}async scaffold(i,e){const o=this.buildSlidesMarkdown(i),n=this.generatePackageJson(i.config.theme),r=this.getSlidesPath(),l=`${this.workspacePath}/package.json`,s=Jo(r),a=Jo(l),c=Su(o);c.includes("snippets/external.ts")||c.push("snippets/external.ts");const d=new Map;for(const b of c){const w=Nl[b]||`// Auto-generated snippet placeholder for SiYuan Slidev
// #region snippet
// ${b}
// #endregion snippet
`;d.set(b,w)}i.slides.some(b=>{var w;return((w=b.frontmatter)==null?void 0:w.layout)==="three-cols-header"})&&d.set("layouts/three-cols-header.vue",wu),d.set("setup/root.ts",xu),d.set("styles/index.css",_u);const g=be("fs"),u=be("path");let k=!1;const h=u!=null&&u.dirname?u.dirname(s):"",y=/^[a-zA-Z]:[/\\]/.test(s)||s.includes("siyuan-slidev-pro");if(g&&u&&y)try{g.existsSync(h)||g.mkdirSync(h,{recursive:!0}),g.writeFileSync(a,n,"utf-8"),g.writeFileSync(s,o,"utf-8");for(const[b,w]of d.entries()){const S=u.join(h,b),T=u.dirname(S);g.existsSync(T)||g.mkdirSync(T,{recursive:!0}),g.existsSync(S)||g.writeFileSync(S,w,"utf-8")}k=!0}catch{}if(!k&&e)try{const b=typeof Blob<"u"?new Blob([o],{type:"text/markdown;charset=utf-8"}):Buffer.from(o,"utf-8"),w=typeof Blob<"u"?new Blob([n],{type:"application/json;charset=utf-8"}):Buffer.from(n,"utf-8");await e(l,!1,w),await e(r,!1,b);for(const[S,T]of d.entries()){const x=`${this.workspacePath}/${S}`,_=typeof Blob<"u"?new Blob([T],{type:"text/plain;charset=utf-8"}):Buffer.from(T,"utf-8");await e(x,!1,_).catch(()=>{})}return{success:!0,slidesPath:r,physicalSlidesPath:s,packageJsonPath:l}}catch(b){return{success:!1,slidesPath:r,physicalSlidesPath:s,packageJsonPath:l,error:String(b)}}return{success:!0,slidesPath:r,physicalSlidesPath:s,packageJsonPath:l}}}class $u{constructor(){kt(this,"mode","web-sandbox");kt(this,"webBridge");kt(this,"cliBridge");kt(this,"nativeBridge");kt(this,"processManager");kt(this,"scaffolder");kt(this,"envDetector");this.webBridge=new _s,this.cliBridge=new ts,this.nativeBridge=new yu,this.processManager=new ku,this.scaffolder=new Cu,this.envDetector=new xs}getMode(){return this.mode}setMode(i){this.mode=i}async startProMode(i,e){if(!(await this.envDetector.detect()).hasNode)return{success:!1,url:"",error:"当前系统未检测到 Node.js 环境，无法拉起官方 Slidev CLI，建议继续使用内置高保真引擎"};const n=await this.scaffolder.scaffold(i,e);if(!n.success)return{success:!1,url:"",error:`初始化 Slidev 临时工作空间失败: ${n.error}`};const r=n.physicalSlidesPath||n.slidesPath,l=await this.processManager.startServer(r);return l.success?(this.mode="pro-cli",{success:!0,url:l.url,port:l.port}):{success:!1,url:"",error:l.error}}stopProMode(){this.processManager.stopServer(),this.mode="web-sandbox"}destroy(){this.webBridge.detach(),this.nativeBridge.detach(),this.processManager.stopServer()}}const Iu={class:"slidev-icon",style:{fill:"none !important"},viewBox:"0 0 24 24",stroke:"currentColor","stroke-width":"1.75","stroke-linecap":"round","stroke-linejoin":"round","aria-hidden":"true"},Au={key:0},Tu={key:1},Eu={key:2},Bu={key:3},Mu={key:4},Du={key:5},Lu={key:6},Pu={key:7},Ou={key:8},Ru={key:9},zu={key:10},Nu={key:11},Fu={key:12},ju={key:13},Hu={key:14},Uu={key:15},Wu={key:16},Vu={key:17},Ku={key:18},qu={key:19},Gu={key:20},Zu={key:21},Yu={key:22},Ju={key:23},Xu={key:24},Qu={key:25},tf={key:26},ef={key:27},nf={key:28},of={key:29},sf={key:30},rf={key:31},lf={key:32},af={key:33},cf={key:34},df={key:35},uf={key:36},ff={key:37},pf={key:38},hf={key:39},mf={key:40},gf={key:41},vf={key:42},bf={key:43},yf={key:44},kf={key:45},wf={key:46},xf={key:47},_f={key:48},Sf={key:49},Cf={key:50},$f={key:51},If={key:52},Af=he({__name:"SlidevIcon",props:{name:{}},setup(t){return(i,e)=>(tt(),nt("svg",Iu,[t.name==="fullscreen"||t.name==="maximize"?(tt(),nt("g",Au,[...e[0]||(e[0]=[m("polyline",{points:"15 3 21 3 21 9"},null,-1),m("polyline",{points:"9 21 3 21 3 15"},null,-1),m("polyline",{points:"21 15 21 21 15 21"},null,-1),m("polyline",{points:"3 9 3 3 9 3"},null,-1)])])):t.name==="minimize"?(tt(),nt("g",Tu,[...e[1]||(e[1]=[m("polyline",{points:"4 14 10 14 10 20"},null,-1),m("polyline",{points:"20 10 14 10 14 4"},null,-1),m("line",{x1:"14",y1:"10",x2:"21",y2:"3"},null,-1),m("line",{x1:"3",y1:"21",x2:"10",y2:"14"},null,-1)])])):t.name==="close"||t.name==="x"?(tt(),nt("g",Eu,[...e[2]||(e[2]=[m("line",{x1:"18",y1:"6",x2:"6",y2:"18"},null,-1),m("line",{x1:"6",y1:"6",x2:"18",y2:"18"},null,-1)])])):t.name==="edit"?(tt(),nt("g",Bu,[...e[3]||(e[3]=[m("path",{d:"M12 20h9"},null,-1),m("path",{d:"M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z"},null,-1)])])):t.name==="eye"?(tt(),nt("g",Mu,[...e[4]||(e[4]=[m("path",{d:"M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"},null,-1),m("circle",{cx:"12",cy:"12",r:"3"},null,-1)])])):t.name==="external-link"||t.name==="window"?(tt(),nt("g",Du,[...e[5]||(e[5]=[m("path",{d:"M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"},null,-1),m("polyline",{points:"15 3 21 3 21 9"},null,-1),m("line",{x1:"10",y1:"14",x2:"21",y2:"3"},null,-1)])])):t.name==="arrow-left"?(tt(),nt("g",Lu,[...e[6]||(e[6]=[m("line",{x1:"19",y1:"12",x2:"5",y2:"12"},null,-1),m("polyline",{points:"12 19 5 12 12 5"},null,-1)])])):t.name==="arrow-right"?(tt(),nt("g",Pu,[...e[7]||(e[7]=[m("line",{x1:"5",y1:"12",x2:"19",y2:"12"},null,-1),m("polyline",{points:"12 5 19 12 12 19"},null,-1)])])):t.name==="plus"?(tt(),nt("g",Ou,[...e[8]||(e[8]=[m("line",{x1:"12",y1:"5",x2:"12",y2:"19"},null,-1),m("line",{x1:"5",y1:"12",x2:"19",y2:"12"},null,-1)])])):t.name==="minus"?(tt(),nt("g",Ru,[...e[9]||(e[9]=[m("line",{x1:"5",y1:"12",x2:"19",y2:"12"},null,-1)])])):t.name==="split-preview"?(tt(),nt("g",zu,[...e[10]||(e[10]=[m("rect",{x:"3",y:"3",width:"18",height:"18",rx:"2"},null,-1),m("path",{d:"M12 3v18"},null,-1)])])):t.name==="import"?(tt(),nt("g",Nu,[...e[11]||(e[11]=[m("path",{d:"M4 17v2a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-2"},null,-1),m("polyline",{points:"7 9 12 14 17 9"},null,-1),m("line",{x1:"12",y1:"14",x2:"12",y2:"3"},null,-1)])])):t.name==="presenter"?(tt(),nt("g",Fu,[...e[12]||(e[12]=[m("path",{d:"M2 3h20"},null,-1),m("path",{d:"M21 3v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V3"},null,-1),m("path",{d:"m7 21 5-5 5 5"},null,-1)])])):t.name==="video"?(tt(),nt("g",ju,[...e[13]||(e[13]=[m("polygon",{points:"23 7 16 12 23 17 23 7"},null,-1),m("rect",{x:"1",y:"5",width:"15",height:"14",rx:"2",ry:"2"},null,-1)])])):t.name==="step"?(tt(),nt("g",Hu,[...e[14]||(e[14]=[m("polygon",{points:"13 2 3 14 12 14 11 22 21 10 12 10 13 2"},null,-1)])])):t.name==="motion"?(tt(),nt("g",Uu,[...e[15]||(e[15]=[m("path",{d:"M5 12h14"},null,-1),m("path",{d:"m12 5 7 7-7 7"},null,-1),m("path",{d:"M5 6h4"},null,-1),m("path",{d:"M5 18h4"},null,-1)])])):t.name==="columns"?(tt(),nt("g",Wu,[...e[16]||(e[16]=[m("rect",{x:"3",y:"3",width:"7",height:"18",rx:"1"},null,-1),m("rect",{x:"14",y:"3",width:"7",height:"18",rx:"1"},null,-1)])])):t.name==="code"?(tt(),nt("g",Vu,[...e[17]||(e[17]=[m("polyline",{points:"16 18 22 12 16 6"},null,-1),m("polyline",{points:"8 6 2 12 8 18"},null,-1)])])):t.name==="insert-above"?(tt(),nt("g",Ku,[...e[18]||(e[18]=[m("line",{x1:"12",y1:"5",x2:"12",y2:"13"},null,-1),m("line",{x1:"8",y1:"9",x2:"16",y2:"9"},null,-1),m("path",{d:"M4 19h16","stroke-dasharray":"2 2"},null,-1)])])):t.name==="insert-below"?(tt(),nt("g",qu,[...e[19]||(e[19]=[m("path",{d:"M4 5h16","stroke-dasharray":"2 2"},null,-1),m("line",{x1:"12",y1:"11",x2:"12",y2:"19"},null,-1),m("line",{x1:"8",y1:"15",x2:"16",y2:"15"},null,-1)])])):t.name==="broom"?(tt(),nt("g",Gu,[...e[20]||(e[20]=[m("path",{d:"m18 15-6-6"},null,-1),m("path",{d:"M4 20h16"},null,-1),m("path",{d:"M6 14l8-8a2.8 2.8 0 0 1 4 4l-8 8H6v-4z"},null,-1)])])):t.name==="trash"?(tt(),nt("g",Zu,[...e[21]||(e[21]=[m("path",{d:"M3 6h18"},null,-1),m("path",{d:"M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"},null,-1),m("path",{d:"M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"},null,-1)])])):t.name==="ai"||t.name==="sparkles"?(tt(),nt("g",Yu,[...e[22]||(e[22]=[m("path",{d:"m12 3-1.9 5.8a2 2 0 0 1-1.3 1.3L3 12l5.8 1.9a2 2 0 0 1 1.3 1.3L12 21l1.9-5.8a2 2 0 0 1 1.3-1.3L21 12l-5.8-1.9a2 2 0 0 1-1.3-1.3L12 3z"},null,-1)])])):t.name==="palette"?(tt(),nt("g",Ju,[...e[23]||(e[23]=[xe('<circle cx="13.5" cy="6.5" r=".5" fill="currentColor" data-v-b8552023></circle><circle cx="17.5" cy="10.5" r=".5" fill="currentColor" data-v-b8552023></circle><circle cx="8.5" cy="7.5" r=".5" fill="currentColor" data-v-b8552023></circle><circle cx="6.5" cy="12.5" r=".5" fill="currentColor" data-v-b8552023></circle><path d="M12 2C6.5 2 2 6.5 2 12s4.5 10 10 10c.9 0 1.5-.7 1.5-1.5 0-.4-.2-.8-.4-1.1-.3-.4-.4-.8-.4-1.4 0-1.1.9-2 2-2h2.3c3.9 0 7-3.1 7-7 0-5-4.5-9-10-9z" data-v-b8552023></path>',5)])])):t.name==="ratio"?(tt(),nt("g",Xu,[...e[24]||(e[24]=[m("rect",{x:"2",y:"5",width:"20",height:"14",rx:"2"},null,-1),m("line",{x1:"2",y1:"10",x2:"22",y2:"10","stroke-dasharray":"2 2"},null,-1)])])):t.name==="transition"?(tt(),nt("g",Qu,[...e[25]||(e[25]=[m("path",{d:"M8 3 4 7l4 4"},null,-1),m("path",{d:"M4 7h16"},null,-1),m("path",{d:"m16 21 4-4-4-4"},null,-1),m("path",{d:"M20 17H4"},null,-1)])])):t.name==="export-html"?(tt(),nt("g",tf,[...e[26]||(e[26]=[m("polyline",{points:"16 16 12 12 8 16"},null,-1),m("line",{x1:"12",y1:"12",x2:"12",y2:"21"},null,-1),m("path",{d:"M20.4 16.3A5 5 0 0 0 18 7h-1.3A8 8 0 0 0 4 12.8a5 5 0 0 0 1.5 9.2"},null,-1)])])):t.name==="export-pdf"?(tt(),nt("g",ef,[...e[27]||(e[27]=[m("polyline",{points:"6 9 6 2 18 2 18 9"},null,-1),m("path",{d:"M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"},null,-1),m("rect",{x:"6",y:"14",width:"12",height:"8"},null,-1)])])):t.name==="pin"?(tt(),nt("g",nf,[...e[28]||(e[28]=[m("line",{x1:"12",y1:"17",x2:"12",y2:"22"},null,-1),m("path",{d:"M5 17h14v-2l-2-2V5l1-1V2H6v2l1 1v8l-2 2v2z"},null,-1)])])):t.name==="refresh"?(tt(),nt("g",of,[...e[29]||(e[29]=[m("path",{d:"M3 12a9 9 0 0 1 9-9 9.75 9.75 0 0 1 6.74 2.74L21 8"},null,-1),m("path",{d:"M21 3v5h-5"},null,-1),m("path",{d:"M21 12a9 9 0 0 1-9 9 9.75 9.75 0 0 1-6.74-2.74L3 16"},null,-1),m("path",{d:"M8 16H3v5"},null,-1)])])):t.name==="outline"?(tt(),nt("g",sf,[...e[30]||(e[30]=[m("line",{x1:"3",y1:"6",x2:"21",y2:"6"},null,-1),m("line",{x1:"3",y1:"12",x2:"21",y2:"12"},null,-1),m("line",{x1:"3",y1:"18",x2:"21",y2:"18"},null,-1)])])):t.name==="chevron-left"?(tt(),nt("g",rf,[...e[31]||(e[31]=[m("polyline",{points:"15 18 9 12 15 6"},null,-1)])])):t.name==="chevron-right"?(tt(),nt("g",lf,[...e[32]||(e[32]=[m("polyline",{points:"9 18 15 12 9 6"},null,-1)])])):t.name==="copy"?(tt(),nt("g",af,[...e[33]||(e[33]=[m("rect",{x:"9",y:"9",width:"13",height:"13",rx:"2",ry:"2"},null,-1),m("path",{d:"M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"},null,-1)])])):t.name==="image"?(tt(),nt("g",cf,[...e[34]||(e[34]=[m("rect",{x:"3",y:"3",width:"18",height:"18",rx:"2",ry:"2"},null,-1),m("circle",{cx:"8.5",cy:"8.5",r:"1.5"},null,-1),m("polyline",{points:"21 15 16 10 5 21"},null,-1)])])):t.name==="search"?(tt(),nt("g",df,[...e[35]||(e[35]=[m("circle",{cx:"11",cy:"11",r:"7"},null,-1),m("line",{x1:"21",y1:"21",x2:"16.65",y2:"16.65"},null,-1)])])):t.name==="settings"||t.name==="gear"?(tt(),nt("g",uf,[...e[36]||(e[36]=[m("circle",{cx:"12",cy:"12",r:"3"},null,-1),m("path",{d:"M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 1 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 1 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 1 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 1 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"},null,-1)])])):t.name==="notes"||t.name==="file-text"?(tt(),nt("g",ff,[...e[37]||(e[37]=[xe('<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" data-v-b8552023></path><polyline points="14 2 14 8 20 8" data-v-b8552023></polyline><line x1="16" y1="13" x2="8" y2="13" data-v-b8552023></line><line x1="16" y1="17" x2="8" y2="17" data-v-b8552023></line><line x1="10" y1="9" x2="8" y2="9" data-v-b8552023></line>',5)])])):t.name==="focus"||t.name==="target"?(tt(),nt("g",pf,[...e[38]||(e[38]=[m("circle",{cx:"12",cy:"12",r:"3",fill:"currentColor"},null,-1),m("path",{d:"M12 2v4M12 18v4M2 12h4M18 12h4",stroke:"currentColor","stroke-width":"2","stroke-linecap":"round"},null,-1),m("circle",{cx:"12",cy:"12",r:"7",fill:"none",stroke:"currentColor","stroke-width":"1.8"},null,-1)])])):t.name==="layout-cover"||t.name==="cover"?(tt(),nt("g",hf,[...e[39]||(e[39]=[m("rect",{x:"2",y:"4",width:"20",height:"16",rx:"2"},null,-1),m("line",{x1:"9",y1:"8",x2:"15",y2:"8"},null,-1),m("line",{x1:"5.5",y1:"11.5",x2:"18.5",y2:"11.5"},null,-1),m("line",{x1:"7.5",y1:"15",x2:"16.5",y2:"15"},null,-1)])])):t.name==="layout-default"||t.name==="default"?(tt(),nt("g",mf,[...e[40]||(e[40]=[xe('<rect x="2" y="4" width="20" height="16" rx="2" data-v-b8552023></rect><line x1="5" y1="8" x2="11.5" y2="8" data-v-b8552023></line><line x1="5" y1="11.5" x2="19" y2="11.5" data-v-b8552023></line><line x1="5" y1="14.5" x2="19" y2="14.5" data-v-b8552023></line><line x1="5" y1="17.5" x2="13.5" y2="17.5" data-v-b8552023></line>',5)])])):t.name==="layout-two-cols"||t.name==="two-cols"?(tt(),nt("g",gf,[...e[41]||(e[41]=[xe('<rect x="2" y="4" width="20" height="16" rx="2" data-v-b8552023></rect><line x1="12" y1="4" x2="12" y2="20" stroke-dasharray="2 1.5" data-v-b8552023></line><line x1="5" y1="8" x2="9.5" y2="8" data-v-b8552023></line><line x1="5" y1="11.5" x2="9.5" y2="11.5" data-v-b8552023></line><line x1="5" y1="15" x2="8" y2="15" data-v-b8552023></line><line x1="14.5" y1="8" x2="19" y2="8" data-v-b8552023></line><line x1="14.5" y1="11.5" x2="19" y2="11.5" data-v-b8552023></line><line x1="14.5" y1="15" x2="17.5" y2="15" data-v-b8552023></line>',8)])])):t.name==="layout-two-cols-header"||t.name==="two-cols-header"?(tt(),nt("g",vf,[...e[42]||(e[42]=[xe('<rect x="2" y="4" width="20" height="16" rx="2" data-v-b8552023></rect><line x1="5" y1="7.5" x2="13" y2="7.5" data-v-b8552023></line><line x1="12" y1="10.5" x2="12" y2="18.5" stroke-dasharray="1.5 1.5" data-v-b8552023></line><line x1="5" y1="12" x2="9.5" y2="12" data-v-b8552023></line><line x1="5" y1="15.5" x2="8.5" y2="15.5" data-v-b8552023></line><line x1="14.5" y1="12" x2="19" y2="12" data-v-b8552023></line><line x1="14.5" y1="15.5" x2="18" y2="15.5" data-v-b8552023></line>',7)])])):t.name==="layout-three-cols-header"||t.name==="three-cols-header"?(tt(),nt("g",bf,[...e[43]||(e[43]=[xe('<rect x="2" y="4" width="20" height="16" rx="2" data-v-b8552023></rect><line x1="5" y1="7.5" x2="13" y2="7.5" data-v-b8552023></line><line x1="9.3" y1="10.5" x2="9.3" y2="18.5" stroke-dasharray="1.5 1.5" data-v-b8552023></line><line x1="14.7" y1="10.5" x2="14.7" y2="18.5" stroke-dasharray="1.5 1.5" data-v-b8552023></line><line x1="4.5" y1="12" x2="7.5" y2="12" data-v-b8552023></line><line x1="4.5" y1="15.5" x2="7" y2="15.5" data-v-b8552023></line><line x1="10.5" y1="12" x2="13.5" y2="12" data-v-b8552023></line><line x1="10.5" y1="15.5" x2="13.5" y2="15.5" data-v-b8552023></line><line x1="16" y1="12" x2="19.5" y2="12" data-v-b8552023></line><line x1="16" y1="15.5" x2="18.5" y2="15.5" data-v-b8552023></line>',10)])])):t.name==="layout-image-right"||t.name==="image-right"?(tt(),nt("g",yf,[...e[44]||(e[44]=[xe('<rect x="2" y="4" width="20" height="16" rx="2" data-v-b8552023></rect><line x1="12" y1="4" x2="12" y2="20" data-v-b8552023></line><line x1="4.5" y1="8" x2="9.5" y2="8" data-v-b8552023></line><line x1="4.5" y1="11.5" x2="10" y2="11.5" data-v-b8552023></line><line x1="4.5" y1="14.5" x2="8" y2="14.5" data-v-b8552023></line><circle cx="15.5" cy="8.5" r="1.2" data-v-b8552023></circle><polyline points="13 17 15.5 13 18 16 19.5 14" data-v-b8552023></polyline>',7)])])):t.name==="layout-image-left"||t.name==="image-left"?(tt(),nt("g",kf,[...e[45]||(e[45]=[xe('<rect x="2" y="4" width="20" height="16" rx="2" data-v-b8552023></rect><line x1="12" y1="4" x2="12" y2="20" data-v-b8552023></line><circle cx="6" cy="8.5" r="1.2" data-v-b8552023></circle><polyline points="3.5 17 6 13 8.5 16 10 14" data-v-b8552023></polyline><line x1="14.5" y1="8" x2="19.5" y2="8" data-v-b8552023></line><line x1="14.5" y1="11.5" x2="20" y2="11.5" data-v-b8552023></line><line x1="14.5" y1="14.5" x2="18" y2="14.5" data-v-b8552023></line>',7)])])):t.name==="layout-center"||t.name==="center"?(tt(),nt("g",wf,[...e[46]||(e[46]=[m("rect",{x:"2",y:"4",width:"20",height:"16",rx:"2"},null,-1),m("line",{x1:"6.5",y1:"9",x2:"17.5",y2:"9"},null,-1),m("line",{x1:"5",y1:"12",x2:"19",y2:"12"},null,-1),m("line",{x1:"8",y1:"15",x2:"16",y2:"15"},null,-1)])])):t.name==="layout-fact"||t.name==="fact"?(tt(),nt("g",xf,[...e[47]||(e[47]=[xe('<rect x="2" y="4" width="20" height="16" rx="2" data-v-b8552023></rect><circle cx="8" cy="9" r="1.5" data-v-b8552023></circle><line x1="14" y1="8" x2="9" y2="14" data-v-b8552023></line><circle cx="15" cy="13" r="1.5" data-v-b8552023></circle><line x1="6.5" y1="17" x2="17.5" y2="17" data-v-b8552023></line>',5)])])):t.name==="layout-intro"||t.name==="intro"?(tt(),nt("g",_f,[...e[48]||(e[48]=[xe('<rect x="2" y="4" width="20" height="16" rx="2" data-v-b8552023></rect><circle cx="7.5" cy="9.5" r="2" data-v-b8552023></circle><path d="M4.5 16.5c0-1.8 1.3-3 3-3s3 1.2 3 3" data-v-b8552023></path><line x1="13" y1="9" x2="18.5" y2="9" data-v-b8552023></line><line x1="13" y1="12.5" x2="19.5" y2="12.5" data-v-b8552023></line><line x1="13" y1="15.5" x2="17" y2="15.5" data-v-b8552023></line>',6)])])):t.name==="layout-quote"||t.name==="quote"?(tt(),nt("g",Sf,[...e[49]||(e[49]=[xe('<rect x="2" y="4" width="20" height="16" rx="2" data-v-b8552023></rect><path d="M6 7.5h2v2H6.5c0 1.2-.4 2-1.5 2.5" data-v-b8552023></path><path d="M9.5 7.5h2v2H10c0 1.2-.4 2-1.5 2.5" data-v-b8552023></path><line x1="6" y1="13.5" x2="18" y2="13.5" data-v-b8552023></line><line x1="12.5" y1="16.5" x2="17.5" y2="16.5" data-v-b8552023></line>',5)])])):t.name==="desktop"||t.name==="monitor"?(tt(),nt("g",Cf,[...e[50]||(e[50]=[m("rect",{x:"2",y:"3",width:"20",height:"14",rx:"2"},null,-1),m("line",{x1:"8",y1:"21",x2:"16",y2:"21"},null,-1),m("line",{x1:"12",y1:"17",x2:"12",y2:"21"},null,-1)])])):t.name==="mobile"||t.name==="smartphone"||t.name==="phone"?(tt(),nt("g",$f,[...e[51]||(e[51]=[m("rect",{x:"5",y:"2",width:"14",height:"20",rx:"2",ry:"2"},null,-1),m("line",{x1:"12",y1:"18",x2:"12.01",y2:"18","stroke-width":"2","stroke-linecap":"round"},null,-1)])])):(tt(),nt("g",If,[...e[52]||(e[52]=[m("rect",{x:"2",y:"3",width:"20",height:"14",rx:"2"},null,-1),m("line",{x1:"8",y1:"21",x2:"16",y2:"21"},null,-1),m("line",{x1:"12",y1:"17",x2:"12",y2:"21"},null,-1)])]))]))}}),Be=(t,i)=>{const e=t.__vccOpts||t;for(const[o,n]of i)e[o]=n;return e},yt=Be(Af,[["__scopeId","data-v-b8552023"]]);function Qt(t,i){var n;if(typeof document>"u"||!t)return;const e=(n=globalThis.CSS)!=null&&n.escape?globalThis.CSS.escape(t):t.replace(/"/g,'\\"'),o=document.querySelectorAll(`[data-node-id="${e}"]`);!o||o.length===0||o.forEach(r=>{for(const[l,s]of Object.entries(i))s!=null&&s!==""?r.setAttribute(l,String(s)):r.removeAttribute(l)})}function Tf(t){if(typeof document>"u")return;const i=`.protyle-wysiwyg [${dt}], .protyle-wysiwyg [${jt}], .protyle-wysiwyg [custom-slidev-layout], .protyle-wysiwyg [custom-slidev-role]`,e=document.querySelectorAll(i);!e||e.length===0||e.forEach(o=>{const n=o.getAttribute("data-node-id");if(!n){o.removeAttribute(dt),o.removeAttribute("custom-slidev-layout"),o.removeAttribute(jt),o.removeAttribute("custom-slidev-role");return}const r=t.get(n),l=(r==null?void 0:r[dt])||(r==null?void 0:r["custom-slidev-layout"])||"",s=o.getAttribute(dt)||o.getAttribute("custom-slidev-layout");s&&s!==l&&(l?o.setAttribute(dt,l):(o.removeAttribute(dt),o.removeAttribute("custom-slidev-layout")));const a=(r==null?void 0:r[jt])||(r==null?void 0:r["custom-slidev-role"])||"",c=o.getAttribute(jt)||o.getAttribute("custom-slidev-role");c&&c!==a&&(a?o.setAttribute(jt,a):(o.removeAttribute(jt),o.removeAttribute("custom-slidev-role")))})}const Ef={class:"spm-layout-picker"},Bf={class:"spm-layout-picker__grid"},Mf=["title","onClick"],Df={class:"spm-layout-icon"},Lf={class:"spm-layout-label"},Pf=he({__name:"LayoutPicker",props:{modelValue:{}},emits:["update:modelValue","change"],setup(t,{emit:i}){const e=i,o=[{name:"cover",label:"封面",desc:"大标题与副标题封面页"},{name:"default",label:"标准",desc:"标题在上方，内容在下方"},{name:"two-cols",label:"双栏",desc:"左右双栏对比展示"},{name:"two-cols-header",label:"表头双栏",desc:"顶部通栏标题，下方左右双栏"},{name:"three-cols-header",label:"表头三栏",desc:"顶部通栏标题，下方等宽三栏"},{name:"image-right",label:"图右",desc:"左侧为内容，右侧全屏背景图"},{name:"image-left",label:"图左",desc:"左侧全屏背景图，右侧为内容"},{name:"center",label:"居中",desc:"内容全屏垂直水平居中"},{name:"fact",label:"大字报",desc:"核心数据或指标突出展示"},{name:"intro",label:"介绍",desc:"演讲者自我介绍或章节导览"},{name:"quote",label:"引言",desc:"名人名言与强调段落"}];function n(r){e("update:modelValue",r),e("change",r)}return(r,l)=>(tt(),nt("div",Ef,[l[0]||(l[0]=m("div",{class:"spm-layout-picker__header"},"选择页面版式",-1)),m("div",Bf,[(tt(),nt(Ut,null,ge(o,s=>m("div",{key:s.name,class:$t(["spm-layout-item",{active:t.modelValue===s.name}]),title:s.desc,onClick:a=>n(s.name)},[m("div",Df,[ut(yt,{name:"layout-"+s.name},null,8,["name"])]),m("span",Lf,_t(s.label),1)],10,Mf)),64))])]))}}),Fl=Be(Pf,[["__scopeId","data-v-c57441d5"]]),Of={key:0,class:"spm-transition-selector__header"},Rf={class:"spm-transition-list"},zf=["onClick"],Nf={class:"spm-transition-meta"},Ff={class:"spm-transition-label"},jf={class:"spm-transition-name"},Hf={class:"spm-transition-preview-box"},Uf=he({__name:"TransitionSelector",props:{modelValue:{},hideHeader:{type:Boolean},title:{}},emits:["update:modelValue","change"],setup(t,{emit:i}){const e=i,o=[{name:"slide-left",label:"向左滑入",desc:"向左滑入 (slide-left)：页面从右侧向左平滑推入，最通用标准的横向幻灯片动效"},{name:"slide-right",label:"向右滑入",desc:"向右滑入 (slide-right)：页面从左侧向右平滑推入，适合倒序回退或逆向章节叙述"},{name:"slide-up",label:"向上推入",desc:"向上推入 (slide-up)：页面从底部向上平滑推入，适合纵向展开或纵深层级展示"},{name:"fade",label:"淡入淡出",desc:"淡入淡出 (fade)：透明度平滑渐变过度，典雅柔和，适合学术长篇与沉浸叙事"},{name:"zoom",label:"缩放进入",desc:"缩放进入 (zoom)：页面由中心向外平滑放大，富有动感冲击力，适合聚焦重点"}];function n(r){e("update:modelValue",r),e("change",r)}return(r,l)=>(tt(),nt("div",{class:$t(["spm-transition-selector",{"spm-transition-selector--no-header":t.hideHeader}])},[t.hideHeader?Pt("",!0):(tt(),nt("div",Of,_t(t.title||"转场动效"),1)),m("div",Rf,[(tt(),nt(Ut,null,ge(o,s=>m("div",{key:s.name,class:$t(["spm-transition-item",{active:t.modelValue===s.name}]),onClick:a=>n(s.name)},[m("div",Nf,[m("span",Ff,_t(s.label),1),m("span",jf,"("+_t(s.name)+")",1)]),m("div",Hf,[m("div",{class:$t(["spm-anim-cube","anim-"+s.name])},null,2)])],10,zf)),64))])],2))}}),Ss=Be(Uf,[["__scopeId","data-v-b0aa61ff"]]),Wf={class:"spm-divider-popover"},Vf={class:"spm-divider-popover__title"},Kf={class:"spm-form-item"},qf={class:"spm-popover-footer"},Gf={class:"spm-save-hint"},Zf=he({__name:"QuickDividerPopover",props:{blockId:{},initialAttrs:{}},emits:["close","updated"],setup(t,{emit:i}){var g,u,k;const e=t,o=i,n=ft(((g=e.initialAttrs)==null?void 0:g[dt])||"default"),r=ft(((u=e.initialAttrs)==null?void 0:u[qt])||"slide-left"),l=ft(((k=e.initialAttrs)==null?void 0:k[zt])||""),s=ft("");_i(()=>e.initialAttrs,h=>{n.value=(h==null?void 0:h[dt])||"default",r.value=(h==null?void 0:h[qt])||"slide-left",l.value=(h==null?void 0:h[zt])||""},{deep:!0});async function a(h,y){if(e.blockId){s.value="正在同步...",Rt.setBlockAttrOverride(e.blockId,{[h]:y}),Qt(e.blockId,{[h]:y});try{await Dt(e.blockId,{[h]:y}),s.value="已同步至块属性",o("updated",{[h]:y}),setTimeout(()=>{s.value=""},1500)}catch{s.value="同步失败"}}}function c(h){a(dt,h)}function d(h){a(qt,h)}function f(){a(zt,l.value.trim())}return(h,y)=>(tt(),nt("div",Wf,[m("div",Vf,[y[4]||(y[4]=m("span",null,"幻灯片页面设置",-1)),m("button",{class:"spm-close-btn",onClick:y[0]||(y[0]=b=>o("close"))},"✕")]),ut(Fl,{modelValue:n.value,"onUpdate:modelValue":y[1]||(y[1]=b=>n.value=b),onChange:c},null,8,["modelValue"]),ut(Ss,{modelValue:r.value,"onUpdate:modelValue":y[2]||(y[2]=b=>r.value=b),onChange:d},null,8,["modelValue"]),m("div",Kf,[y[5]||(y[5]=m("label",{class:"spm-form-label"},"页面背景",-1)),_e(m("input",{"onUpdate:modelValue":y[3]||(y[3]=b=>l.value=b),class:"spm-input",placeholder:"assets/bg.jpg 或颜色值 (#1e1e24)",onBlur:f},null,544),[[io,l.value]])]),m("div",qf,[m("span",Gf,_t(s.value),1)])]))}}),Yf=Be(Zf,[["__scopeId","data-v-e4871368"]]),Jf={class:"spm-slide-inspector"},Xf={class:"spm-inspector-header"},Qf={class:"spm-inspector-list"},tp=["onClick"],ep={class:"spm-card-top"},ip={class:"spm-card-badge"},np={class:"spm-card-layout"},op=["onClick"],sp={class:"spm-card-preview"},rp={key:0,class:"spm-card-notes",title:"演讲备忘录"},lp={class:"spm-inspector-modal-content"},ap=he({__name:"SlideInspector",props:{slides:{},currentActivePage:{}},emits:["navigate","refresh"],setup(t,{emit:i}){const e=i,o=ft(null);function n(c){o.value=c}function r(c){const d={};return c.frontmatter.layout&&(d[dt]=c.frontmatter.layout),c.frontmatter.transition&&(d[qt]=c.frontmatter.transition),c.frontmatter.background&&(d[zt]=c.frontmatter.background),c.notes&&(d[Di]=c.notes),d}function l(c){o.value&&(c[dt]&&(o.value.frontmatter.layout=c[dt]),c[qt]&&(o.value.frontmatter.transition=c[qt]),c[zt]&&(o.value.frontmatter.background=c[zt]),c[Di]&&(o.value.notes=c[Di]),e("refresh"))}function s(c){e("navigate",c)}function a(c){if(!c.blocks||c.blocks.length===0)return"(空白页)";const d=c.blocks[0],f=d.content||d.rawMarkdown||"";return f.slice(0,40)+(f.length>40?"...":"")}return(c,d)=>(tt(),nt("div",Jf,[m("div",Xf,[m("span",null,"幻灯片大纲 ("+_t(t.slides.length)+" 页)",1)]),m("div",Qf,[(tt(!0),nt(Ut,null,ge(t.slides,f=>(tt(),nt("div",{key:f.pageIndex,class:$t(["spm-card",{active:t.currentActivePage===f.pageIndex}]),onClick:g=>s(f.pageIndex)},[m("div",ep,[m("span",ip,"P"+_t(f.pageIndex),1),m("span",np,_t(f.frontmatter.layout||"default"),1),m("button",{class:"spm-card-btn-edit",title:"配置此页版式与属性",onClick:Ce(g=>n(f),["stop"])},[ut(yt,{name:"settings"})],8,op)]),m("div",sp,_t(a(f)),1),f.notes?(tt(),nt("div",rp,[ut(yt,{name:"notes",style:{"font-size":"11px","margin-right":"3px"}}),m("span",null,_t(f.notes),1)])):Pt("",!0)],10,tp))),128))]),o.value?(tt(),nt("div",{key:0,class:"spm-inspector-modal-mask",onClick:d[1]||(d[1]=Ce(f=>o.value=null,["self"]))},[m("div",lp,[ut(Yf,{"block-id":o.value.startBlockId,"initial-attrs":r(o.value),onClose:d[0]||(d[0]=f=>o.value=null),onUpdated:l},null,8,["block-id","initial-attrs"])])])):Pt("",!0)]))}}),cp=Be(ap,[["__scopeId","data-v-68b25edd"]]),dp={class:"spm-immersion-header"},up={class:"spm-immersion-header__left"},fp={class:"spm-immersion-title"},pp={class:"spm-immersion-header__center"},hp={class:"spm-immersion-header__actions"},mp=["aria-label"],gp={class:"spm-immersion-body"},vp=he({__name:"ImmersionDrawerContainer",props:{visible:{type:Boolean,default:!1},isMaximized:{type:Boolean,default:!1},title:{default:"速览"},closeOnClickMask:{type:Boolean,default:!0}},emits:["update:visible","update:isMaximized","close","toggle-maximize"],setup(t,{emit:i}){const e=t,o=i;function n(){o("update:visible",!1),o("close")}function r(){e.closeOnClickMask&&n()}function l(){o("update:isMaximized",!e.isMaximized),o("toggle-maximize")}function s(a){(a.key===" "||a.key==="ArrowLeft"||a.key==="ArrowRight"||a.key==="PageUp"||a.key==="PageDown")&&a.stopPropagation(),a.key==="Escape"&&(a.preventDefault(),a.stopPropagation(),n())}return(a,c)=>_e((tt(),nt("div",{class:$t(["spm-immersion-container",{"is-maximized":t.isMaximized}]),onKeydown:Ce(s,["stop"])},[m("div",{class:"spm-immersion-mask",onClick:r}),m("div",{class:$t(["spm-immersion-drawer",{"is-maximized":t.isMaximized}])},[m("div",dp,[m("div",up,[Mn(a.$slots,"header-left",{},()=>[m("span",fp,_t(t.title),1)])]),m("div",pp,[Mn(a.$slots,"header-center",{},void 0)]),m("div",hp,[Mn(a.$slots,"header-actions",{},void 0),m("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":t.isMaximized?"还原抽屉宽度 (70%)":"最大化填满视口 (100%)",onClick:l},[ut(yt,{name:t.isMaximized?"minimize":"maximize"},null,8,["name"])],8,mp),m("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"关闭速览 (ESC)",onClick:n},[ut(yt,{name:"close"})])])]),m("div",gp,[Mn(a.$slots,"default",{},void 0)])],2)],34)),[[Ll,t.visible]])}}),bp=Be(vp,[["__scopeId","data-v-3f1665db"]]),yp="slidev-config.json",Vi={enableWebServeJump:!1,webServeUrl:"http://127.0.0.1:6806"},ki=uo({...Vi});function kp(t){if(!t||typeof t!="object")return{...Vi};const i=t;return{enableWebServeJump:!!i.enableWebServeJump,webServeUrl:typeof i.webServeUrl=="string"&&i.webServeUrl.trim()?i.webServeUrl.trim():Vi.webServeUrl}}function Fi(t){if(!t||typeof t!="object")return{...ki};const i=t;return i.enableWebServeJump!==void 0&&(ki.enableWebServeJump=!!i.enableWebServeJump),i.webServeUrl!==void 0&&(ki.webServeUrl=String(i.webServeUrl)),{...ki}}function Cs(){return{...ki}}function jl(t,i,e){const o=(t||Vi.webServeUrl).trim(),n=o.startsWith("http://")||o.startsWith("https://")?o:`http://${o}`,r=(e==null?void 0:e.r)||Math.random().toString(36).slice(2,9).padEnd(7,"0");try{const l=new URL(n);let s=l.pathname.replace(/\/+$/,"");return s.endsWith("/stage/build/desktop")||(s=s?`${s}/stage/build/desktop`:"/stage/build/desktop"),l.pathname=`${s}/`,l.searchParams.set("id",i),e!=null&&e.focus&&l.searchParams.set("focus","1"),l.searchParams.set("r",r),l.toString()}catch{const l=e!=null&&e.focus?"&focus=1":"";return`${n.replace(/\/+$/,"")}/stage/build/desktop/?id=${i}${l}&r=${r}`}}const wp={class:"spm-protyle-drawer"},xp={class:"spm-protyle-drawer__subbar"},_p={class:"spm-protyle-drawer__nav"},Sp=["title"],Cp={class:"spm-protyle-drawer__actions"},$p=["aria-label"],Ip=["aria-label"],Ap=he({__name:"ProtylePeekDrawer",props:{blockId:{},title:{},plugin:{}},emits:["external-jump"],setup(t,{emit:i}){const e=i,o=t,n=ft(o.blockId),r=ft(o.title||""),l=ft(!1),s=ft(!0),a=ft(!1),c=ft(""),d=ki,f=ft([]),g=ft(null);let u=null;_i(()=>o.blockId,I=>{I&&I!==n.value&&(n.value=I,r.value=o.title||"",f.value=[],h(I))}),Sn(()=>{n.value&&h(n.value)}),ms(()=>{y()});async function k(I){try{const L=await dn(`SELECT id, root_id, type, content FROM blocks WHERE id = '${I}' LIMIT 1`);if(Array.isArray(L)&&L.length>0){const M=L[0];c.value=M.root_id||"";const F=M.id===M.root_id||M.type==="d";a.value=F,s.value=!F,!r.value&&M.content&&(r.value=M.content.trim().slice(0,30));return}}catch(L){console.warn("[ProtylePeekDrawer] detectBlockType query failed:",L)}a.value=!1,s.value=!0}async function h(I,L){if(!g.value||!I)return;y(),await k(I),typeof L=="boolean"&&(s.value=!a.value&&L);let M,F;s.value&&!a.value?(M=["cb-get-all","cb-get-hl","cb-get-focus"],F={background:!1,title:!1,gutter:!0,breadcrumbDocName:!0,scroll:!0}):(M=["cb-get-context","cb-get-hl"],F={background:!0,title:!0,gutter:!0,breadcrumbDocName:!0,scroll:!0});try{u=new mt.Protyle(o.plugin.app,g.value,{blockId:I,action:M,render:F}),!l.value&&u&&typeof u.disable=="function"&&u.disable()}catch(J){console.error("[ProtylePeekDrawer] Failed to instantiate Protyle:",J)}}function y(){if(u){try{typeof u.destroy=="function"&&u.destroy()}catch(I){console.warn("[ProtylePeekDrawer] Error destroying protyle:",I)}u=null}g.value&&(g.value.innerHTML="")}function b(){a.value||(s.value=!s.value,h(n.value,s.value))}function w(){l.value=!l.value,u&&(l.value?(typeof u.enable=="function"&&u.enable(),typeof u.focus=="function"&&u.focus()):typeof u.disable=="function"&&u.disable())}function S(){if(n.value)try{mt.openWindow({doc:{id:n.value},alwaysOnTop:!0})}catch(I){console.warn("[ProtylePeekDrawer] openWindow failed:",I)}}function T(){var M;if(!n.value)return;const I=Cs(),L=jl(I.webServeUrl,n.value,{focus:!a.value});if(typeof window<"u"){const F=be("electron");(M=F==null?void 0:F.shell)!=null&&M.openExternal?F.shell.openExternal(L).catch(()=>{window.open(L,"_blank")}):window.open(L,"_blank")}e("external-jump",L)}function x(){if(f.value.length>0){const I=f.value.pop();I&&(n.value=I.blockId,r.value=I.title,s.value=I.isFocusMode,a.value=I.isDoc,h(I.blockId,I.isFocusMode))}}function _(I){const L=I.target;if(!L)return;const M=L.closest('[data-type="block-ref"]');if(M){const J=M.getAttribute("data-id");if(J&&J!==n.value){I.preventDefault(),I.stopPropagation(),f.value.push({blockId:n.value,title:r.value||n.value,isFocusMode:s.value,isDoc:a.value}),n.value=J,r.value=M.innerText.trim()||J,h(J);return}}const F=L.closest("a");if(F&&F.href&&F.href.startsWith("siyuan://blocks/")){I.preventDefault(),I.stopPropagation();const J=F.href.replace("siyuan://blocks/","").split("?")[0];J&&J!==n.value&&(f.value.push({blockId:n.value,title:r.value||n.value,isFocusMode:s.value,isDoc:a.value}),n.value=J,r.value=F.innerText.trim()||J,h(J))}}return(I,L)=>(tt(),nt("div",wp,[m("div",xp,[m("div",_p,[f.value.length>0?(tt(),nt("button",{key:0,class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"返回上层引用文档或块",onClick:x},[ut(yt,{name:"arrow-left"}),L[0]||(L[0]=m("span",null,"返回",-1))])):Pt("",!0),m("span",{class:$t(["spm-protyle-badge",{"is-focus":s.value&&!a.value}])},_t(s.value&&!a.value?"思源块聚焦":"思源文档速览"),3),m("span",{class:"spm-protyle-id",title:r.value||n.value},_t(r.value||n.value),9,Sp)]),m("div",Cp,[a.value?Pt("",!0):(tt(),nt("button",{key:0,class:$t(["spm-icon-btn b3-tooltips b3-tooltips__s",{"is-primary":s.value}]),"aria-label":s.value?"当前为块聚焦模式（点击展开所属文档全文）":"当前为文档全文模式（点击切回仅聚焦当前块）",onClick:b},[ut(yt,{name:s.value?"focus":"file-text"},null,8,["name"]),m("span",null,_t(s.value?"块聚焦":"展开全文"),1)],10,$p)),m("button",{class:$t(["spm-icon-btn b3-tooltips b3-tooltips__s",{"is-primary":l.value}]),"aria-label":l.value?"当前为即时编辑模式（点击切回只读）":"当前为只读速览模式（点击解锁即时编辑）",onClick:w},[ut(yt,{name:l.value?"edit":"eye"},null,8,["name"]),m("span",null,_t(l.value?"编辑中":"只读"),1)],10,Ip),m("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"在置顶独立窗口中打开 (保留完整侧边栏与插件)",onClick:S},[ut(yt,{name:"window"}),L[1]||(L[1]=m("span",null,"独立窗口",-1))]),ht(d).enableWebServeJump?(tt(),nt("button",{key:1,class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"在系统默认浏览器中打开 (外跳)",onClick:T},[ut(yt,{name:"external-link"}),L[2]||(L[2]=m("span",null,"外跳",-1))])):Pt("",!0)])]),m("div",{ref_key:"mountEl",ref:g,class:$t(["spm-protyle-mount",{"is-focus-mode":s.value&&!a.value}]),onClick:_},null,2)]))}}),Tp=Be(Ap,[["__scopeId","data-v-7e586ef3"]]),Ep={class:"spm-webview-drawer"},Bp={class:"spm-webview-toolbar"},Mp={class:"spm-webview-toolbar__nav"},Dp=["disabled"],Lp=["disabled"],Pp=["aria-label"],Op={class:"spm-webview-toolbar__address"},Rp=["aria-label"],zp={class:"spm-webview-toolbar__actions"},Np=["aria-label"],Fp={class:"spm-zoom-controller"},jp=["disabled"],Hp=["disabled"],Up={key:1,class:"spm-webview-fallback"},Wp=["src"],fr="Mozilla/5.0 (iPhone; CPU iPhone OS 17_4_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.4.1 Mobile/15E148 Safari/604.1",Hl="siyuan-slidev-peek-view-mode";let Ul="desktop";function Vp(){if(typeof window<"u"&&window.localStorage)try{const t=window.localStorage.getItem(Hl);if(t==="mobile"||t==="desktop")return t}catch{}return Ul}function Kp(t){if(Ul=t,typeof window<"u"&&window.localStorage)try{window.localStorage.setItem(Hl,t)}catch{}}const qp=he({__name:"WebviewPeekDrawer",props:{url:{},title:{},visible:{type:Boolean,default:!0}},emits:["external-jump"],setup(t,{emit:i}){const e=i,o=t,n=ft(Rl()),r=ft(o.url),l=ft(o.url),s=ft(!1),a=ft(!1),c=ft(!1),d=ft(1),f=ft(!1),g=ft(Vp());let u=typeof navigator<"u"&&!navigator.userAgent.includes("iPhone")?navigator.userAgent:"";const k=St(()=>g.value==="mobile"?fr:u||void 0),h=ft(null),y=ft(null);let b=null,w=null,S=null;_i(()=>o.url,X=>{X&&X!==r.value&&(r.value=X,l.value=X,g.value==="mobile"&&L(!1),h.value&&typeof h.value.loadURL=="function"&&h.value.loadURL(X))}),_i(()=>o.visible,X=>{if(X)H(),g.value==="mobile"&&L(!1);else if(h.value)try{typeof h.value.stop=="function"&&h.value.stop()}catch{}}),Sn(()=>{T(),y.value&&typeof ResizeObserver<"u"&&(b=new ResizeObserver(()=>{const X=h.value;if(X&&typeof X.invalidate=="function")try{X.invalidate()}catch{}}),b.observe(y.value)),w=X=>{var gt;const pt=X.message||((gt=X.error)==null?void 0:gt.message);if(typeof pt=="string"&&pt.includes("Invalid guestInstanceId"))return X.preventDefault(),X.stopImmediatePropagation(),!0},window.addEventListener("error",w,!0),S=X=>{const pt=X.reason,gt=typeof pt=="string"?pt:pt==null?void 0:pt.message;typeof gt=="string"&&gt.includes("Invalid guestInstanceId")&&X.preventDefault()},window.addEventListener("unhandledrejection",S)}),ms(()=>{if(x(),b&&(b.disconnect(),b=null),w&&(window.removeEventListener("error",w,!0),w=null),S&&(window.removeEventListener("unhandledrejection",S),S=null),h.value)try{typeof h.value.stop=="function"&&h.value.stop()}catch{}});function T(){const X=h.value;X&&(X.addEventListener("dom-ready",_),X.addEventListener("did-start-loading",M),X.addEventListener("did-stop-loading",F),X.addEventListener("did-navigate",J),X.addEventListener("did-navigate-in-page",E),X.addEventListener("new-window",A))}function x(){const X=h.value;if(X)try{X.removeEventListener("dom-ready",_),X.removeEventListener("did-start-loading",M),X.removeEventListener("did-stop-loading",F),X.removeEventListener("did-navigate",J),X.removeEventListener("did-navigate-in-page",E),X.removeEventListener("new-window",A)}catch{}}function _(){const X=h.value;if(X&&typeof X.getUserAgent=="function"&&!u)try{const pt=X.getUserAgent();pt&&!pt.includes("iPhone")&&(u=pt)}catch{}g.value==="mobile"&&L(!1),H(),v()}function I(){const X=g.value==="mobile"?"desktop":"mobile";g.value=X,Kp(X),L(!0)}function L(X=!1){const pt=h.value;if(!pt)return;const gt=g.value==="mobile"?fr:u;if(typeof pt.setUserAgent=="function"&&gt)try{pt.setUserAgent(gt)}catch(Y){console.warn("[WebviewPeekDrawer] setUserAgent error:",Y)}if(X&&typeof pt.reload=="function")try{pt.reload()}catch(Y){console.warn("[WebviewPeekDrawer] reload error:",Y)}}function M(){s.value=!0}function F(){if(s.value=!1,v(),h.value&&typeof h.value.getURL=="function"){const X=h.value.getURL();X&&X!=="about:blank"&&(r.value=X,l.value=X)}}function J(X){X!=null&&X.url&&(r.value=X.url,l.value=X.url),v()}function E(X){X!=null&&X.url&&(r.value=X.url,l.value=X.url),v()}function A(X){X&&X.url&&(X.preventDefault(),h.value&&typeof h.value.loadURL=="function"&&h.value.loadURL(X.url))}function v(){const X=h.value;X&&(typeof X.canGoBack=="function"&&(a.value=X.canGoBack()),typeof X.canGoForward=="function"&&(c.value=X.canGoForward()))}function O(){h.value&&typeof h.value.goBack=="function"&&h.value.goBack()}function z(){h.value&&typeof h.value.goForward=="function"&&h.value.goForward()}function P(){h.value&&typeof h.value.reload=="function"&&h.value.reload()}function K(){let X=l.value.trim();X&&(/^https?:\/\//i.test(X)||(X=`https://${X}`),r.value=X,l.value=X,h.value&&typeof h.value.loadURL=="function"&&h.value.loadURL(X))}function H(){const X=h.value;if(X&&typeof X.setZoomFactor=="function")try{X.setZoomFactor(d.value)}catch(pt){console.warn("[WebviewPeekDrawer] setZoomFactor error:",pt)}}function et(){d.value=Math.min(2.5,Math.round((d.value+.1)*10)/10),H()}function V(){d.value=Math.max(.5,Math.round((d.value-.1)*10)/10),H()}function G(){d.value=1,H()}function lt(X){X.preventDefault(),X.deltaY<0?et():X.deltaY>0&&V()}async function at(){if(typeof navigator<"u"&&navigator.clipboard)try{await navigator.clipboard.writeText(r.value),f.value=!0,setTimeout(()=>{f.value=!1},2e3)}catch(X){console.warn("Copy url failed:",X)}}function ot(){var pt;const X=r.value;if(typeof window<"u"){const gt=be("electron");(pt=gt==null?void 0:gt.shell)!=null&&pt.openExternal?gt.shell.openExternal(X).catch(()=>{window.open(X,"_blank")}):window.open(X,"_blank")}e("external-jump",X)}return(X,pt)=>{const gt=Jc("webview");return tt(),nt("div",Ep,[m("div",Bp,[m("div",Mp,[m("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s",disabled:!a.value,"aria-label":"后退",onClick:O},[ut(yt,{name:"arrow-left"})],8,Dp),m("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s",disabled:!c.value,"aria-label":"前进",onClick:z},[ut(yt,{name:"arrow-right"})],8,Lp),m("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":s.value?"正在加载...":"刷新页面",onClick:P},[ut(yt,{name:"refresh"})],8,Pp)]),m("div",Op,[_e(m("input",{"onUpdate:modelValue":pt[0]||(pt[0]=Y=>l.value=Y),type:"text",class:"b3-text-field spm-url-input",placeholder:"https://...",spellcheck:"false",onKeydown:fu(K,["enter"])},null,544),[[io,l.value]]),m("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":f.value?"已复制地址！":"复制网址",onClick:at},[ut(yt,{name:"copy"})],8,Rp)]),m("div",zp,[m("button",{class:$t(["spm-icon-btn spm-mode-toggle b3-tooltips b3-tooltips__s",{"is-active":g.value==="mobile"}]),"aria-label":g.value==="mobile"?"当前为手机视图，点击切换为桌面视图":"当前为桌面视图，点击切换为手机视图",onClick:I},[ut(yt,{name:g.value==="mobile"?"mobile":"desktop"},null,8,["name"])],10,Np),m("div",Fp,[m("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"缩小 (Ctrl + -)",disabled:d.value<=.5,onClick:V},[ut(yt,{name:"minus"})],8,jp),m("button",{class:"spm-zoom-badge b3-tooltips b3-tooltips__s","aria-label":"重置 100% (Ctrl + 0)",onClick:G},_t(Math.round(d.value*100))+"% ",1),m("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"放大 (Ctrl + +)",disabled:d.value>=2.5,onClick:et},[ut(yt,{name:"plus"})],8,Hp)]),m("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"在系统默认浏览器中打开 ↗",onClick:ot},[ut(yt,{name:"external-link"}),pt[1]||(pt[1]=m("span",null,"外跳",-1))])])]),m("div",{ref_key:"containerEl",ref:y,class:$t(["spm-webview-body",{"is-mobile":g.value==="mobile"}]),onWheel:Ce(lt,["ctrl"])},[m("div",{class:$t(["spm-webview-viewport",{"is-mobile":g.value==="mobile"}])},[n.value?(tt(),$e(gt,{key:0,ref_key:"webviewRef",ref:h,class:"spm-webview-frame",src:r.value,useragent:k.value,allowpopups:"true",partition:"persist:slidev-peek",style:{position:"absolute",top:"0",left:"0",width:"100%",height:"100%",display:"inline-flex"}},null,8,["src","useragent"])):(tt(),nt("div",Up,[m("iframe",{class:"spm-webview-fallback-frame",src:r.value,frameborder:"0",sandbox:"allow-scripts allow-same-origin allow-forms allow-popups"},null,8,Wp),m("div",{class:"spm-fallback-bar"},[pt[2]||(pt[2]=m("span",null,"如页面受同源策略 (X-Frame-Options) 拦截无法显示，请",-1)),m("button",{class:"spm-icon-btn is-primary",onClick:ot}," 在新标签页中打开 ↗ ")])]))],2)],34)])}}}),Gp=Be(qp,[["__scopeId","data-v-40e35375"]]);class Zp{constructor(){kt(this,"timers",new Map)}debounce(i,e,o=150){this.cancel(i);const n=setTimeout(()=>{this.timers.delete(i),e()},o);this.timers.set(i,n)}cancel(i){this.timers.has(i)&&(clearTimeout(this.timers.get(i)),this.timers.delete(i))}cancelAll(){for(const i of this.timers.values())clearTimeout(i);this.timers.clear()}hasPending(i){return this.timers.has(i)}}class Yp{constructor(i){kt(this,"blockToPageMap",new Map);kt(this,"debounceCtrl",new Zp);kt(this,"activeBlockId","");kt(this,"activePageIndex",1);kt(this,"currentDocId","");kt(this,"bridge",null);i&&(this.bridge=i)}setBridge(i){this.bridge=i}setDocId(i){this.currentDocId=i}updateSlidesIndex(i){this.blockToPageMap.clear();for(const e of i){e.startBlockId&&this.blockToPageMap.set(e.startBlockId,e.pageIndex);for(const o of e.blocks)this.blockToPageMap.set(o.id,e.pageIndex)}}getPageByBlockId(i){return this.blockToPageMap.get(i)??null}onCursorFocusBlock(i){if(!i||i===this.activeBlockId)return;this.activeBlockId=i;let e=this.getPageByBlockId(i);!e&&(i===this.currentDocId||!this.currentDocId&&this.blockToPageMap.size>0)&&(e=1),e&&this.debounceCtrl.debounce("cursor-navigate",()=>{this.activePageIndex=e,this.bridge&&(this.bridge.navigatePage(e),this.bridge.highlightElement(i))},100)}getActiveBlockId(){return this.activeBlockId}setActiveBlockId(i){this.activeBlockId=i;const e=this.getPageByBlockId(i);e&&(this.activePageIndex=e)}getActivePageIndex(){return this.activePageIndex}destroy(){this.debounceCtrl.cancelAll(),this.blockToPageMap.clear(),this.bridge=null}}function Si(t,i){var r,l;if(!t||typeof document>"u")return!1;const e=(r=globalThis.CSS)!=null&&r.escape?globalThis.CSS.escape(t):t.replace(/"/g,'\\"'),o=document.querySelector(`.protyle-wysiwyg [data-node-id="${e}"]`)||document.querySelector(`[data-node-id="${e}"]`);if(!o){if(i)try{return mt.openTab({app:i,doc:{id:t,action:["cb-get-hl","cb-get-focus","cb-get-context"]}}),!0}catch(s){console.warn("[SelectionMirror] openTab fallback failed:",s)}return!1}try{o.scrollIntoView({behavior:"smooth",block:"center",inline:"nearest"})}catch{o.scrollIntoView()}try{(l=o.focus)==null||l.call(o,{preventScroll:!0})}catch{}o.classList.add("protyle-wysiwyg--select");const n=o.style.outline;return o.style.outline="2px solid #3b82f6",o.style.transition="outline 0.3s ease",setTimeout(()=>{o.classList.remove("protyle-wysiwyg--select"),o.style.outline=n},1200),!0}function Jp(t){if(!t)return"";const i=t.split(`
`).map(l=>l.trim()).filter(Boolean);if(i.length===0)return"";if(!i.some(l=>/^#{1,6}\s+/.test(l)))return fe(i.join(" "));const o=[];let n=[];const r=()=>{if(n.length>0){const l=n.join(" ");o.push(`<p class="slide-list-item-desc">${fe(l)}</p>`),n=[]}};for(const l of i){const s=l.match(/^(#{1,6})\s+(.*)$/);if(s){r();const a=s[1].length,c=s[2].trim();o.push(`<h${a} class="slide-list-item-title">${fe(c)}</h${a}>`)}else n.push(l)}return r(),o.join(`
`)}function Xp(t){if(t.length===0)return"";const i=[];let e=[];const o=r=>{if(e.length>0){const l=e.join(" "),s=r?"slide-list-item-title":"slide-list-item-desc";i.push(`<p class="${s}">${fe(l)}</p>`),e=[]}};let n=!0;for(const r of t){const l=r.match(/^(#{1,6})\s+(.*)$/);if(l){o(n);const s=l[1].length,a=l[2].trim();i.push(`<h${s} class="slide-list-item-title">${fe(a)}</h${s}>`),n=!1}else e.push(r)}return o(n),i.join(`
`)+(i.length>0?`
`:"")}function Wl(t,i,e){var g,u,k,h;const o=t.split(`
`);if(!o.some(y=>/^(\s*)([-*+]|\d+\.)\s+/.test(y)))return null;const r=[],l=[];let s=!1;for(let y=0;y<o.length;y++){const b=o[y];if(!b.trim())continue;const w=b.match(/^(\s*)[-*+]\s+\[([ xX])\]\s+(.*)$/);if(w){const _=w[1].length,I=Math.floor(_/2);l.push({type:"task",level:I,checked:w[2].toLowerCase()==="x",text:w[3],media:[]});continue}const S=b.match(/^(\s*)[-*+]\s+(.*)$/);if(S){const _=S[1].length,I=Math.floor(_/2);l.push({type:"unordered",level:I,text:S[2],media:[]});continue}const T=b.match(/^(\s*)\d+\.\s+(.*)$/);if(T){l.length===0&&(s=!0);const _=T[1].length,I=Math.floor(_/2);l.push({type:"ordered",level:I,text:T[2],media:[]});continue}const x=b.trim();if(!(!x||/^\{:.*?\}$/.test(x)))if(l.length>0){const _=x.match(/^!\[(.*?)\]\((.*?)\)(?:\{:?[^}]*\})?$/);if(_){const M=/\.gif(?:\?|$)/i.test(_[2])?"list-item-gif":"list-item-img";l[l.length-1].media||(l[l.length-1].media=[]),l[l.length-1].media.push(`<div class="slide-list-media"><img alt="${te(_[1])}" src="${_[2]}" class="${M}" /></div>`);continue}if(x.match(/^<img\b[\s\S]*?\/?>$/i)){const L=x.replace(/\s+style="[^"]*"/gi,"");l[l.length-1].media||(l[l.length-1].media=[]),l[l.length-1].media.push(`<div class="slide-list-media">${L}</div>`);continue}if(/<video\b/i.test(x)){let L=x;if(!/<\/video>/i.test(L))for(;y+1<o.length&&!/<\/video>/i.test(L);)y++,L+=" "+o[y].trim();const M=((g=e==null?void 0:e.attributes)==null?void 0:g["custom-slidev-autoplay"])==="true"||/autoplay/i.test(L),F=((u=e==null?void 0:e.attributes)==null?void 0:u["custom-slidev-loop"])==="true"||/loop/i.test(L),J=((k=e==null?void 0:e.attributes)==null?void 0:k["custom-slidev-muted"])==="true"||M||/muted/i.test(L),E=((h=e==null?void 0:e.attributes)==null?void 0:h["custom-slidev-controls"])==="false",A=L.match(/\bsrc=["']([^"']+)["']/i),v=A?A[1]:"",O=['class="slide-video-player"'];E||O.push("controls"),M&&(O.push("autoplay"),O.push("playsinline")),F&&O.push("loop"),J&&O.push("muted"),O.push('preload="metadata"'),v&&O.push(`src="${v}"`);const z=L.match(/<video[^>]*>([\s\S]*?)<\/video>/i);let P=z?z[1].trim():"";!P&&v&&(P=`<source src="${v}" type="video/mp4" />您的浏览器不支持视频播放。`),l[l.length-1].media||(l[l.length-1].media=[]),l[l.length-1].media.push(`<div class="slide-list-media slide-video-container slide-media-container" data-autoplay="${M?"true":"false"}" data-muted="${J?"true":"false"}"><video ${O.join(" ")}>${P}</video></div>`);continue}l[l.length-1].text+=`
`+x}else r.push(x)}if(l.length===0)return null;const a=s?"ol":"ul",c=s?"pdf-list pdf-list--ordered":"pdf-list pdf-list--unordered",d=l.map(y=>{const b=Jp(y.text),w=y.media&&y.media.length>0?`
${y.media.join(`
`)}`:"",S=y.level||0,T=S>0?` style="margin-left:${(S*1.25).toFixed(2)}em;${y.type==="unordered"?`list-style-type:${S%2===1?"circle":"square"} !important;`:""}"`:"",x=S>0?" slide-list-item--nested":"";if(y.type==="task"){const I=y.checked?' checked=""':"";return`<li class="pdf-task-item${x}"${T}><label><input type="checkbox" disabled=""${I}/> <span>${b}</span></label>${w}</li>`}return`<li${x?` class="${x.trim()}"`:""}${T}>${b}${w}</li>`}).join(`
`);return`${Xp(r)}<${a} class="${c}">
${d}
</${a}>`}function Qp(t,i,e){const o="pdf-block",n=t.split(/\r?\n/),r=[];let l=[];for(let a=0;a<n.length;a++){const c=n[a],d=c.trim();if(/^#{1,6}\s+/.test(d)){l.length>0&&(r.push(l.join(`
`)),l=[]),r.push(d);continue}if(!d){l.length>0&&(r.push(l.join(`
`)),l=[]);continue}if(/^!\[.*?\]\(.*?\)$/.test(d)){l.length>0&&(r.push(l.join(`
`)),l=[]),r.push(d);continue}if(/<video\b/i.test(d)){l.length>0&&(r.push(l.join(`
`)),l=[]);let f=d;if(!/<\/video>/i.test(f))for(;a+1<n.length&&!/<\/video>/i.test(f);)a++,f+=`
`+n[a];r.push(f);continue}l.push(c)}return l.length>0&&r.push(l.join(`
`)),r.map(a=>{var u,k,h,y;const c=a.trim();if(!c)return"";const d=c.match(/^(#{1,6})\s+(.*)$/);if(d){const b=d[1].length;return`<h${b} class="slide-list-item-title">${fe(d[2].trim())}</h${b}>`}const f=c.match(/^!\[(.*?)\]\((.*?)\)$/);if(f){const w=/\.gif(?:\?|$)/i.test(f[2])?"list-item-gif":"pdf-image slide-media-img";return`<div class="${o} ${o}--image slide-media-block slide-media-container slide-list-media"><img alt="${te(f[1])}" src="${f[2]}" class="${w}" /></div>`}if(/<video\b/i.test(c)){const b=((u=e==null?void 0:e.attributes)==null?void 0:u["custom-slidev-autoplay"])==="true"||/autoplay/i.test(c),w=((k=e==null?void 0:e.attributes)==null?void 0:k["custom-slidev-loop"])==="true"||/loop/i.test(c),S=((h=e==null?void 0:e.attributes)==null?void 0:h["custom-slidev-muted"])==="true"||b||/muted/i.test(c),T=((y=e==null?void 0:e.attributes)==null?void 0:y["custom-slidev-controls"])==="false",x=c.match(/\bsrc=["']([^"']+)["']/i),_=x?x[1]:"",I=['class="slide-video-player"'];T||I.push("controls"),b&&I.push("autoplay playsinline"),w&&I.push("loop"),S&&I.push("muted"),I.push('preload="metadata"'),_&&I.push(`src="${_}"`);const L=c.match(/<video[^>]*>([\s\S]*?)<\/video>/i);let M=L?L[1].trim():"";return!M&&_&&(M=`<source src="${_}" type="video/mp4" />您的浏览器不支持视频播放。`),`<div class="${o} ${o}--video slide-media-block slide-video-container slide-media-container" data-autoplay="${b?"true":"false"}" data-muted="${S?"true":"false"}"><video ${I.join(" ")}>${M}</video></div>`}const g=Wl(c,i,e);return g||`<p class="slide-list-item-desc">${fe(c)}</p>`}).filter(Boolean).join(`
`)}function th(t,i){var r,l,s,a;const e=((r=t.frontmatter)==null?void 0:r.layout)||"default",n=(t.blocks||[]).filter(c=>c.slot!=="slot-divider-right");if(e==="two-cols"){const c=n.some(w=>w.slot==="right");let d=[],f=[];if(c)d=n.filter(w=>w.slot!=="right"),f=n.filter(w=>w.slot==="right");else{const w=Math.ceil(n.length/2);d=n.slice(0,w),f=n.slice(w)}const g=d.map(w=>De(w,i)).join(`
`),u=f.map(w=>De(w,i)).join(`
`),k="pdf-two-cols-wrapper layout-two-cols-grid",h=(l=t.frontmatter)!=null&&l.layoutClass?` ${t.frontmatter.layoutClass}`:"";return`
      <div class="${k}${h}">
        <div class="pdf-col pdf-col--left">${g}</div>
        <div class="pdf-col pdf-col--right">${u}</div>
      </div>
    `}if(e==="two-cols-header"){let c=[];const d=n.filter(w=>w.slot==="header");if(d.length>0)c=d;else if(n.length>0){const w=n.find(S=>S.type==="h"&&(!S.slot||S.slot==="default"));w&&(c=[w])}const f=n.filter(w=>!c.includes(w)),g=f.filter(w=>w.slot==="right"||w.slot==="col-2"),u=f.filter(w=>!g.includes(w)),k=w=>{const S=w.filter(T=>!!(T.rawMarkdown||T.content||"").trim());if(S.length>0){const T=S[0],x=(T.rawMarkdown||T.content||"").trim();(ji(T)||/^(?:[-*+]|\d+\.)\s+/.test(x))&&(T.rawMarkdown=Oo(T.rawMarkdown||T.content||""),T.content=T.rawMarkdown)}return S.map(T=>De(T,i)).join(`
`)},h=c.map(w=>De(w,i)).join(`
`),y=k(u),b=k(g);return`
      <div class="layout-two-cols-header-container">
        <div class="layout-header-section">${h}</div>
        <div class="pdf-two-cols-wrapper layout-two-cols-grid">
          <div class="pdf-col pdf-col--left">${y}</div>
          <div class="pdf-col pdf-col--right">${b}</div>
        </div>
      </div>
    `}if(e==="three-cols-header"){let c=[];const d=n.filter(T=>T.slot==="header");if(d.length>0)c=d;else if(n.length>0){const T=n.find(x=>x.type==="h"&&(!x.slot||x.slot==="default"));T&&(c=[T])}const f=n.filter(T=>!c.includes(T)),{col1:g,col2:u,col3:k}=Ar(f),h=T=>{const x=T.filter(_=>!!(_.rawMarkdown||_.content||"").trim());if(x.length>0){const _=x[0],I=(_.rawMarkdown||_.content||"").trim();(ji(_)||/^(?:[-*+]|\d+\.)\s+/.test(I))&&(_.rawMarkdown=Oo(_.rawMarkdown||_.content||""),_.content=_.rawMarkdown)}return x.map(_=>De(_,i)).join(`
`)},y=c.map(T=>De(T,i)).join(`
`),b=h(g),w=h(u),S=h(k);return`
      <div class="layout-three-cols-header-container">
        <div class="layout-header-section">${y}</div>
        <div class="pdf-three-cols-wrapper layout-three-cols-grid">
          <div class="pdf-col pdf-col--1">${b}</div>
          <div class="pdf-col pdf-col--2">${w}</div>
          <div class="pdf-col pdf-col--3">${S}</div>
        </div>
      </div>
    `}if(e==="image-right"||e==="image-left"){const c=e==="image-right",d=n.map(h=>De(h,i)).join(`
`),f=((s=t.frontmatter)==null?void 0:s.image)||((a=t.frontmatter)==null?void 0:a.background)||"",g=`<div class="pdf-image-col" style="background-image:url('${te(f)}');background-size:cover;background-position:center;background-repeat:no-repeat;width:100%;height:100%;position:relative;overflow:hidden;"><img src="${te(f)}" style="width:100%;height:100%;object-fit:cover;object-position:center;display:block;" onerror="this.style.display='none'" alt="Slide cover" /></div>`,u=`<div class="pdf-content-col" style="padding:48px 56px;display:flex;flex-direction:column;justify-content:flex-start;height:100%;box-sizing:border-box;overflow-y:auto;">${d}</div>`;return`
      <div class="layout-image-cols-grid" style="display:grid;grid-template-columns:1fr 1fr;grid-template-rows:100%;width:100%;height:100%;position:absolute;top:0;left:0;right:0;bottom:0;box-sizing:border-box;">
        ${c?`${u}
${g}`:`${g}
${u}`}
      </div>
    `}return e==="fact"?`<div class="layout-fact-container">${n.map(d=>De(d,i)).join(`
`)}</div>`:e==="cover"?`<div class="layout-cover-container">${n.map(d=>De(d,i)).join(`
`)}</div>`:n.map(c=>De(c,i)).join(`
`)}function te(t){return t?t.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&#039;"):""}function eh(t){if(!t||t.trim()===""||t.trim()==="all")return"all";const i=new Set,e=t.split("|");for(const o of e){const n=o.trim();if(n==="all")return"all";if(n.includes("-")){const[r,l]=n.split("-"),s=parseInt(r,10),a=parseInt(l,10);if(!isNaN(s)&&!isNaN(a))for(let c=Math.min(s,a);c<=Math.max(s,a);c++)i.add(c)}else{const r=parseInt(n,10);isNaN(r)||i.add(r)}}return i}const ih=new Set(["kbd","mark","sub","sup","span","a","br","b","i","u","s","del","em","strong","code","small","abbr","ruby","rt","rp","v-mark","img","video","source","picture"]);function fe(t){if(!t)return"";const i=$r(t),e=[],o=i.replace(/<\/?([a-zA-Z0-9_-]+)(?:\s+[^<>]*)?\/?>/g,(r,l)=>{const s=l.toLowerCase();if(!ih.has(s)||/on\w+\s*=|javascript:/i.test(r))return r;if(s==="v-mark"){const a=r.match(/type=["']?([a-zA-Z-]+)["']?/),c=a?a[1]:"circle";return r.startsWith("</")?e.push("</mark>"):e.push(`<mark class="v-mark v-mark--${c}">`),`%%SAFE_HTML_${e.length-1}%%`}return e.push(r),`%%SAFE_HTML_${e.length-1}%%`});let n=te(o);return n=n.replace(/\(\(([0-9a-zA-Z-]+)(?:\s*(?:&#039;([^&#]*)&#039;|&quot;([^&]*)&quot;|'([^']*)'|"([^"]*)"|([^\)]+?)))?\s*\)\)/g,(r,l,s,a,c,d,f)=>{const u=(s??a??c??d??f??"").trim()||`Ref(${l.slice(0,8)})`;return`<a href="siyuan://blocks/${l}" data-ref-id="${l}" class="slidev-ref-tag">🔗 ${u}</a>`}),n=n.replace(/\$([^$\n]+)\$/g,'<span class="katex-inline font-math"><em>$1</em></span>'),n=n.replace(/!\[(.*?)\]\((.*?)\)/g,(r,l,s)=>{const c=/\.gif(?:\?|$)/i.test(s)?"slide-inline-img list-item-gif":"slide-inline-img";return`<img alt="${l}" src="${s}" class="${c}" />`}),n=n.replace(/\[(.*?)\]\((.*?)\)/g,(r,l,s)=>{if(s.startsWith("siyuan://blocks/")){const a=s.replace("siyuan://blocks/","").split("?")[0];return`<a href="${s}" data-ref-id="${a}" class="slidev-ref-tag">🔗 ${l}</a>`}return`<a href="${s}" target="_blank" rel="noopener noreferrer" class="slidev-link">${l}</a>`}),n=n.replace(/(^|[\s(])(siyuan:\/\/blocks\/([0-9a-zA-Z-]+)(?:\?[^\s\)]*)?)/g,(r,l,s,a)=>`${l}<a href="${s}" data-ref-id="${a}" class="slidev-ref-tag">🔗 ${s}</a>`),n=n.replace(/\*\*(.*?)\*\*/g,"<strong>$1</strong>"),n=n.replace(/\*(.*?)\*/g,"<em>$1</em>"),n=n.replace(/~~(.*?)~~/g,"<del>$1</del>"),n=n.replace(/`([^`]+)`/g,"<code>$1</code>"),n=n.replace(/%%SAFE_HTML_(\d+)%%/g,(r,l)=>{const s=parseInt(l,10);return e[s]||""}),n}function nh(t,i="pdf-table"){if(t.length<2)return"";const e=t.map(a=>a.trim().replace(/^\|/,"").replace(/\|$/,"").split("|").map(c=>c.trim())),o=e[0];let n=[],r=1;t.length>=2&&e[1].every(a=>/^:?-+:?$/.test(a))&&(n=e[1].map(a=>a.startsWith(":")&&a.endsWith(":")?"center":a.endsWith(":")?"right":"left"),r=2);const l=`<thead><tr>${o.map((a,c)=>`<th${n[c]?` style="text-align: ${n[c]}"`:""}>${fe(a)}</th>`).join("")}</tr></thead>`,s=e.slice(r).map(a=>`<tr>${a.map((c,d)=>`<td${n[d]?` style="text-align: ${n[d]}"`:""}>${fe(c)}</td>`).join("")}</tr>`).join("");return`<table class="${i}">${l}<tbody>${s}</tbody></table>`}function Bo(t){return String(t||"").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;")}function oh(t,i="ts"){if(!t)return"";if(t.trim().startsWith("//"))return`<span class="token-comment">${Bo(t)}</span>`;const e=[];function o(r,l){return e.push(`<span class="${r}">${Bo(l)}</span>`),`__TOK_${e.length-1}__`}let n=t.replace(/(['"`])(.*?)\1/g,(r,l,s)=>o("token-string",`${l}${s}${l}`));return n=n.replace(/\b(import|export|from|const|let|var|function|return|default|type|interface|class|new|async|await)\b/g,r=>o("token-keyword",r)),n=n.replace(/\b(computed|ref|number|string|boolean|void|Array)\b/g,r=>o("token-type",r)),n=n.replace(/\b(\d+)\b/g,r=>o("token-number",r)),n=Bo(n),n=n.replace(/__TOK_(\d+)__/g,(r,l)=>e[parseInt(l,10)]||""),n}function sh(t,i){if(!t)return null;const e=t.frontmatter||{};if(e.hideInToc===!0||e.hideInToc==="true")return null;let o=(e.title||"").trim(),n=e.level?parseInt(e.level,10):0;if(!o){const r=t.blocks||[];for(const l of r){const a=(l.rawMarkdown||l.content||"").trim().match(/^(#{1,6})\s+(.*)$/);if(a){n||(n=a[1].length),o=a[2].trim();break}}}return o?((!n||isNaN(n))&&(n=1),{pageIndex:t.pageIndex||i,title:o,level:n}):null}function rh(t,i=1,e={}){const o=e.minDepth!==void 0?Number(e.minDepth):1,n=e.maxDepth!==void 0?Number(e.maxDepth):1/0,r=[];Array.isArray(t)&&t.forEach((c,d)=>{const f=sh(c,d+1);f&&r.push(f)});const l=[];let s=null;for(const c of r){const d={...c,active:c.pageIndex===i,hasActiveChild:!1,children:[]};c.level===1||l.length===0?(l.push(d),s=d):s?(d.active&&(s.hasActiveChild=!0),s.children.push(d)):l.push(d)}function a(c,d=1){if(d>n)return[];const f=[];for(const g of c){const u=a(g.children,d+1);d>=o?f.push({...g,children:u}):f.push(...u)}return f}return a(l,1)}function lh(t,i=1,e={}){const o=rh(t,i,e),n=e.columns?Number(e.columns):1,r=n>1?` style="column-count: ${n};"`:"",l=e.textSm?" text-sm":"";function s(c,d=1){if(!c||c.length===0)return"";const f=`slidev-toc-list slidev-toc-list-level-${d}`,g=c.map(u=>{const k=u.active?" slidev-toc-item-active":u.hasActiveChild?" slidev-toc-item-parent-active":"",h=u.children&&u.children.length>0?s(u.children,d+1):"";let y=fe(u.title);return y.includes("LaTeX")&&(y=y.replace(/\$\\LaTeX\$/g,'<span class="font-math">L<sup>A</sup>T<sub>E</sub>X</span>')),`
        <li class="slidev-toc-item${k}" data-page="${u.pageIndex}">
          <a class="slidev-toc-link" href="javascript:void(0)">
            <span class="slidev-toc-title">${y}</span>
          </a>
          ${h}
        </li>
      `}).join("");return`<ol class="${f}">${g}</ol>`}const a=s(o,1);return`<div class="slidev-toc${l}"${r}>${a}</div>`}function De(t,i){var y,b,w,S,T,x,_,I,L;let e="",o="",n="";const r=[];(y=t.motion)!=null&&y.preset&&t.motion.preset!=="none"&&(e=` slidev-motion-${t.motion.preset.toLowerCase()}`,typeof t.motion.duration=="number"&&t.motion.duration>0&&r.push(`--motion-duration:${t.motion.duration}ms`),typeof t.motion.delay=="number"&&t.motion.delay>0&&r.push(`--motion-delay:${t.motion.delay}ms`));const l=((b=t.attributes)==null?void 0:b.style)||"";l&&(r.push(l),n=" slide-styled-block"),r.length>0&&(o=` style="${te(r.join(";"))}"`);const a=`pdf-block${e}${n}`,c=(t.rawMarkdown||t.content||"").trim();if(!c)return`<div class="${a}"${o}></div>`;if(c.includes('class="slidev-block-ref"')||c.includes('class="slidev-ref-tag"'))return`<div class="${a}"${o}>${c}</div>`;if(c.startsWith("$$")&&c.endsWith("$$")){const M=c.slice(2,-2).trim();return`<div class="${a} katex-display-container"${o}><div class="katex-display font-math"><em>${te(M)}</em></div></div>`}const d=c.match(/^(#{1,6})\s+(.*)$/);if(d){const M=d[1].length,F=fe(d[2]);return`<div class="${a}"${o}><h${M}>${F}</h${M}></div>`}if(c.startsWith(":::")){const M=c.split(`
`),J=M[0].replace(/^:::\s*/,"").trim()||"info",E=M.slice(1,M[M.length-1].startsWith(":::")?-1:void 0).join(`
`),A="pdf-callout";return`<div class="${a}"${o}><div class="${A} ${A}--${J}"><div class="${A}-title">${J.toUpperCase()}</div><div class="${A}-body">${fe(E)}</div></div></div>`}if(c.startsWith("<<<")){const J=`// Inside ./snippets/external.ts
export function emptyArray<T>(length: number) {
  return Array.from<T>({ length })
}`.split(`
`).map((O,z)=>`<span class="code-line shiki-focus"><span class="line-no">${z+1}</span><span class="line-content">${oh(O,"ts")}</span></span>`).join(`
`),E="pdf-code shiki-container",A=((w=t.attrs)==null?void 0:w["custom-slidev-max-height"])||t.maxHeight||"",v=A?` style="max-height:${te(A)};overflow-y:auto;"`:"";return`<div class="${a}"${o}><pre class="${E}"${v}><span class="lang-badge">TS</span><code>${J}</code></pre></div>`}if(c.startsWith("<style")||c.startsWith("<!-- Inline style -->")||c.startsWith(`<!--
Notes`))return"";if(c.startsWith("```")){const M=c.split(`
`),F=M[0].slice(3).trim(),J=F.match(/^([^\s{\[]+)/),E=J?J[1]:"",A=F.match(/\[([^\]]+)\]/),v=A?A[1]:"",O=F.includes("twoslash"),z=t.shikiLines||((S=F.match(/\{([^}]+)\}/))==null?void 0:S[1])||"",P=eh(z),K=M.length>2?M[M.length-1]==="```"?M.slice(1,-1):M.slice(1):[c.slice(3).replace(/```$/,"")],H="pdf-code shiki-container",et=v?`${H} has-filename`:H,V=P!=="all",G=K.map((pt,gt)=>{const Y=gt+1,vt=P==="all"||P.has(Y)?"code-line shiki-focus":V?"code-line shiki-dimmed":"code-line";let B=te(pt);return O&&pt.includes("doubled.value = 2")?(B=B.replace(/(\bvalue\b)/,'<span class="twoslash-error-wavy">$1</span>'),`<span class="${vt}"><span class="line-no">${Y}</span><span class="line-content">${B}</span></span>
<div class="twoslash-popup-error"><span style="color:#ef4444;font-weight:bold;margin-right:4px;">✕</span> Cannot assign to 'value' because it is a read-only property.</div>`):`<span class="${vt}"><span class="line-no">${Y}</span><span class="line-content">${B}</span></span>`}).join(`
`),lt=E?`<span class="lang-badge">${te(E)}</span>`:"",at=v?`<span class="code-filename">${te(v)}</span>`:"",ot=((T=t.attrs)==null?void 0:T["custom-slidev-max-height"])||t.maxHeight||"",X=ot?` style="max-height:${te(ot)};overflow-y:auto;"`:"";return`<div class="${a}"${o}><pre class="${et}"${X}>${at}${lt}<code>${G}</code></pre></div>`}if(c.includes("|")&&c.split(`
`).filter(M=>M.trim().startsWith("|")).length>=2){const M=c.split(`
`).filter(J=>J.trim().startsWith("|")),F=nh(M,i==null?void 0:i.tableClassName);return`<div class="${a}"${o}>${F}</div>`}if(c.startsWith("> "))return`<div class="${a}"${o}><blockquote class="pdf-quote"><p>${fe(c.slice(2))}</p></blockquote></div>`;const f=/<video\b/i.test(c)||t.type==="video"||t.type==="NodeVideo",g=/^(\s*)([-*+]|\d+\.)\s+/m.test(c),u=/(?:^|\n)\s*#{1,6}\s+/.test(c);if(f&&!g&&!u&&!c.includes(`
`)){const M=((x=t.attributes)==null?void 0:x["custom-slidev-autoplay"])==="true"||/autoplay/i.test(c),F=((_=t.attributes)==null?void 0:_["custom-slidev-loop"])==="true"||/loop/i.test(c),J=((I=t.attributes)==null?void 0:I["custom-slidev-muted"])==="true"||M||/muted/i.test(c),E=((L=t.attributes)==null?void 0:L["custom-slidev-controls"])==="false",A=c.match(/\bsrc=["']([^"']+)["']/i),v=A?A[1]:"",O=['class="slide-video-player"'];E||O.push("controls"),M&&(O.push("autoplay"),O.push("playsinline")),F&&O.push("loop"),J&&O.push("muted"),O.push('preload="metadata"'),v&&O.push(`src="${v}"`);const z=c.match(/<video[^>]*>([\s\S]*?)<\/video>/i);let P=z?z[1].trim():"";return!P&&v&&(P=`<source src="${v}" type="video/mp4" />您的浏览器不支持视频播放。`),`<div class="${a} ${a}--video slide-media-block slide-video-container slide-media-container" data-autoplay="${M?"true":"false"}" data-muted="${J?"true":"false"}"${o}><video ${O.join(" ")}>${P}</video></div>`}const k=c.match(/^!\[(.*?)\]\((.*?)\)$/);if(k)return`<div class="${a} ${a}--image slide-media-block slide-media-container"${o}><img alt="${te(k[1])}" src="${k[2]}" class="pdf-image slide-media-img" /></div>`;const h=Wl(c,i,t);if(h)return`<div class="${a} pdf-list-item"${o}>${h}</div>`;if(/<(?:Toc|toc)\b/i.test(c)&&!c.startsWith("```")){const M=c.match(/minDepth=["']?(\d+)["']?/i),F=c.match(/maxDepth=["']?(\d+)["']?/i),J=c.match(/columns=["']?(\d+)["']?/i);return`<div class="${a}"${o}>${lh([],1,{minDepth:M?parseInt(M[1],10):1,maxDepth:F?parseInt(F[1],10):1/0,columns:J?parseInt(J[1],10):1,textSm:c.includes("text-sm")})}</div>`}if(c.includes(`
`)||u){const M=Qp(c,i,t);if(M)return`<div class="${a}"${o}>${M}</div>`}return`<div class="${a}"${o}><p>${fe(c)}</p></div>`}function ah(t){return`
    ${on(t)}

    :root {
      --slide-bg: #ffffff;
      --slide-text: #1a1a1a;
      --slide-accent: #3b82f6;
      --slide-font: system-ui, -apple-system, sans-serif;
    }
    [data-theme="dark"] {
      --slide-bg: #121214;
      --slide-text: #e2e8f0;
      --slide-accent: #60a5fa;
    }

    /* 1. 默认科技主题 Default */
    [data-slidev-theme="default"],
    .slidev-theme-default {
      --slide-font: system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "PingFang SC", "Microsoft YaHei", sans-serif;
      --slide-accent: #10b981;
    }
    [data-theme="light"][data-slidev-theme="default"],
    [data-theme="light"] .slidev-theme-default {
      --slide-bg: #ffffff;
      --slide-text: #1e293b;
      --slide-accent: #059669;
    }
    [data-theme="dark"][data-slidev-theme="default"],
    [data-theme="dark"] .slidev-theme-default {
      --slide-bg: #121214;
      --slide-text: #e2e8f0;
      --slide-accent: #34d399;
    }
    .slidev-theme-default .layout-cover h1,
    .slidev-theme-default .layout-cover .slide-block h1 {
      font-size: 3.8rem !important;
      font-weight: 800 !important;
      line-height: 1.15 !important;
      letter-spacing: -0.025em !important;
      margin-bottom: 18px !important;
      background: linear-gradient(135deg, #10b981, #06b6d4) !important;
      -webkit-background-clip: text !important;
      -webkit-text-fill-color: transparent !important;
    }
    .slidev-theme-default .layout-cover h2,
    .slidev-theme-default .layout-cover .slide-block h2 {
      font-size: 1.85rem !important;
      font-weight: 600 !important;
      opacity: 0.85 !important;
      margin-bottom: 12px !important;
    }
    .slidev-theme-default .layout-cover p,
    .slidev-theme-default .layout-cover .slide-block p {
      font-size: 1.45rem !important;
      line-height: 1.5 !important;
      opacity: 0.85 !important;
    }

    /* 2. 优雅衬线主题 Seriph */
    [data-slidev-theme="seriph"],
    .slidev-theme-seriph {
      --slide-font: "PT Serif", "Charter", "Georgia", "Cambria", "Times New Roman", "Source Han Serif SC", "Noto Serif SC", "Songti SC", "SimSun", serif;
      --slide-accent: #b45309;
      letter-spacing: 0.015em;
    }
    [data-theme="light"][data-slidev-theme="seriph"],
    [data-theme="light"] .slidev-theme-seriph {
      --slide-bg: #fdfbf7;
      --slide-text: #2a2521;
      --slide-accent: #b45309;
    }
    [data-theme="dark"][data-slidev-theme="seriph"],
    [data-theme="dark"] .slidev-theme-seriph {
      --slide-bg: #1c1a17;
      --slide-text: #e8e3d9;
      --slide-accent: #f59e0b;
    }
    .slidev-theme-seriph,
    .slidev-theme-seriph .slide-content {
      font-family: var(--slide-font) !important;
      line-height: 1.72;
    }
    .slidev-theme-seriph h1,
    .slidev-theme-seriph h2,
    .slidev-theme-seriph h3 {
      font-family: var(--slide-font) !important;
      letter-spacing: 0.025em;
      font-weight: 700;
    }
    .slidev-theme-seriph .layout-cover h1 {
      background: none !important;
      -webkit-background-clip: initial !important;
      -webkit-text-fill-color: initial !important;
      color: var(--slide-accent) !important;
      font-size: 3.4rem !important;
      border-bottom: 2px solid var(--slide-accent);
      display: inline-block;
      padding-bottom: 10px;
    }

    /* 3. 极简发布会主题 Apple Basic */
    [data-slidev-theme="apple-basic"],
    .slidev-theme-apple-basic {
      --slide-font: -apple-system, "SF Pro Display", "SF Pro Text", BlinkMacSystemFont, "PingFang SC", "Helvetica Neue", sans-serif;
      --slide-accent: #0071e3;
    }
    [data-theme="light"][data-slidev-theme="apple-basic"],
    [data-theme="light"] .slidev-theme-apple-basic {
      --slide-bg: #ffffff;
      --slide-text: #1d1d1f;
      --slide-accent: #0071e3;
    }
    [data-theme="dark"][data-slidev-theme="apple-basic"],
    [data-theme="dark"] .slidev-theme-apple-basic {
      --slide-bg: #000000;
      --slide-text: #f5f5f7;
      --slide-accent: #2997ff;
    }
    .slidev-theme-apple-basic,
    .slidev-theme-apple-basic .slide-content {
      font-family: var(--slide-font) !important;
    }
    .slidev-theme-apple-basic h1,
    .slidev-theme-apple-basic h2,
    .slidev-theme-apple-basic h3 {
      letter-spacing: -0.035em;
      font-weight: 800;
    }
    .slidev-theme-apple-basic .layout-cover h1 {
      background: none !important;
      -webkit-background-clip: initial !important;
      -webkit-text-fill-color: initial !important;
      color: var(--slide-text) !important;
      font-size: 3.8rem !important;
      letter-spacing: -0.04em !important;
    }
    .slidev-theme-apple-basic .layout-cover p {
      color: #86868b !important;
      font-size: 1.35rem !important;
    }

    * { box-sizing: border-box; margin: 0; padding: 0; }
    html, body {
      width: 100%; height: 100%; overflow: hidden;
      background: #0f1115; font-family: var(--slide-font);
      display: flex; justify-content: center; align-items: center;
    }
    #app { width: 100%; height: 100%; position: relative; overflow: hidden; }
    .slide-viewport {
      position: absolute; left: 50%; top: 50%;
      background: var(--slide-bg); color: var(--slide-text);
      box-shadow: 0 10px 30px rgba(0,0,0,0.5); border-radius: 8px; overflow: hidden;
      display: flex; flex-direction: column; flex-shrink: 0;
      transform: translate(-50%, -50%) scale(var(--slidev-slide-scale, 1));
      transform-origin: center center; will-change: transform;
      transition: background 0.3s ease, color 0.3s ease, border-radius 0.2s ease, box-shadow 0.2s ease;
    }
    :fullscreen .slide-viewport, .is-fullscreen .slide-viewport {
      border-radius: 0 !important; box-shadow: none !important;
    }
    .slide-content {
      position: relative;
      width: 100%;
      height: 100%;
      min-height: 100%;
      flex: 1 1 0%;
      padding: var(--slidev-padding-y, 32px) var(--slidev-padding-x, 48px);
      display: flex;
      flex-direction: column;
      overflow: hidden;
      box-sizing: border-box;
    }

    /* 间距预设风格 */
    .slide-content.spacing-compact,
    .slide-viewport[data-spacing="compact"] .slide-content,
    [data-slidev-spacing="compact"] {
      --slidev-padding-y: 20px;
      --slidev-padding-x: 36px;
      --slidev-header-gap: 10px;
      --slidev-title-margin-bottom: 6px;
    }
    .slide-content.spacing-normal,
    .slide-viewport[data-spacing="normal"] .slide-content,
    [data-slidev-spacing="normal"] {
      --slidev-padding-y: 32px;
      --slidev-padding-x: 48px;
      --slidev-header-gap: 16px;
      --slidev-title-margin-bottom: 10px;
    }
    .slide-content.spacing-loose,
    .slide-viewport[data-spacing="loose"] .slide-content,
    [data-slidev-spacing="loose"] {
      --slidev-padding-y: 48px;
      --slidev-padding-x: 56px;
      --slidev-header-gap: 24px;
      --slidev-title-margin-bottom: 16px;
    }

    .layout-cover { justify-content: center; align-items: center; text-align: center; }
    .layout-cover h1, .layout-cover .slide-block h1 { font-size: 3.8rem !important; font-weight: 800 !important; line-height: 1.15 !important; letter-spacing: -0.025em !important; margin-bottom: 16px !important; }
    .layout-cover h2, .layout-cover .slide-block h2 { font-size: 1.85rem !important; font-weight: 600 !important; opacity: 0.85 !important; margin-bottom: 12px !important; }
    .layout-cover p, .layout-cover .slide-block p { font-size: 1.45rem !important; line-height: 1.5 !important; opacity: 0.85 !important; }
    .two-cols-left, .two-cols-right { min-width: 0; width: 100%; display: flex; flex-direction: column; box-sizing: border-box; overflow-wrap: break-word; word-break: break-word; }
    .pdf-two-cols-wrapper,
    .layout-two-cols-grid {
      display: grid;
      grid-template-columns: minmax(0, 1fr) minmax(0, 1fr);
      grid-template-rows: minmax(0, 1fr) !important;
      gap: 32px;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      overflow: hidden !important;
    }
    .layout-two-cols-header-container,
    .layout-three-cols-header-container {
      display: flex;
      flex-direction: column;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      overflow: hidden !important;
    }
    .layout-header-section {
      width: 100%;
      margin-bottom: var(--slidev-header-gap, 16px) !important;
      flex-shrink: 0;
    }
    .layout-header-section h1,
    .layout-header-section h2,
    .layout-header-section h3 {
      margin-bottom: var(--slidev-title-margin-bottom, 10px) !important;
    }
    .pdf-three-cols-wrapper,
    .layout-three-cols-grid {
      display: grid;
      grid-template-columns: minmax(0, 1fr) minmax(0, 1fr) minmax(0, 1fr);
      grid-template-rows: minmax(0, 1fr) !important;
      gap: 24px;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      box-sizing: border-box;
      overflow: hidden !important;
    }
    .pdf-col {
      display: flex;
      flex-direction: column;
      gap: 14px;
      min-width: 0;
      width: 100%;
      max-width: 100%;
      height: 100%;
      max-height: 100%;
      min-height: 0;
      justify-content: flex-start;
      box-sizing: border-box;
      overflow: hidden;
      overflow-wrap: break-word;
      word-break: break-word;
      white-space: normal;
    }
    .pdf-col * {
      overflow-wrap: break-word;
      word-break: break-word;
      box-sizing: border-box;
    }
    .pdf-col pre,
    .two-cols-left pre,
    .two-cols-right pre,
    .image-right-content pre,
    .image-left-content pre {
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      overflow-x: hidden !important;
      overflow-y: auto !important;
      max-width: 100% !important;
      box-sizing: border-box !important;
    }
    .slide-content.layout-image-right, .slide-content.layout-image-left {
      padding: 0;
      display: grid;
      grid-template-columns: minmax(0, 1fr) minmax(0, 1fr);
      grid-template-rows: 100%;
      width: 100%;
      height: 100%;
      position: absolute;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      box-sizing: border-box;
    }
    .image-right-content, .image-left-content {
      padding: 44px 50px;
      display: flex;
      flex-direction: column;
      justify-content: flex-start;
      overflow-y: auto;
      width: 100%;
      height: 100%;
      box-sizing: border-box;
    }
    .image-right-img-container, .image-left-img-container {
      width: 100%;
      height: 100%;
      overflow: hidden;
      position: relative;
      background: #18181b;
      display: flex;
      align-items: center;
      justify-content: center;
    }
    .image-right-img, .image-left-img {
      width: 100%;
      height: 100%;
      object-fit: cover;
      object-position: center;
      display: block;
    }
    .slide-block { margin-bottom: 14px; line-height: 1.6; }
    .slide-block h1 { font-size: 2.2rem; margin-bottom: 12px; }
    .slide-block h2 { font-size: 1.7rem; margin-bottom: 10px; }
    .slide-block p { font-size: 1.15rem; }
    .slide-block ul, .slide-block ol, .pdf-list {
      padding-left: 28px;
      margin: 8px 0;
      display: flex;
      flex-direction: column;
      gap: 6px;
    }
    .slide-block li, .pdf-list li {
      font-size: 1.15rem;
      line-height: 1.6;
    }
    .pdf-task-item {
      list-style: none;
      margin-left: -20px;
      display: flex;
      align-items: center;
      gap: 8px;
    }
    .pdf-task-item input[type="checkbox"] {
      width: 1.15em;
      height: 1.15em;
      cursor: pointer;
    }

    /* 两栏与三栏（超级块分栏）布局：紧凑自然行距，子列表保留圆点与层级缩进 */
    .layout-two-cols ul,
    .layout-two-cols-header ul,
    .layout-three-cols ul,
    .layout-three-cols-header ul,
    .two-cols-left ul,
    .two-cols-right ul,
    .three-cols-col ul,
    .pdf-col ul,
    .layout-two-cols-grid .pdf-list,
    .layout-three-cols-grid .pdf-list,
    .layout-two-cols-grid .pdf-list--unordered,
    .layout-three-cols-grid .pdf-list--unordered {
      list-style: disc !important;
      list-style-type: disc !important;
      padding-left: 1.25em !important;
      margin-left: 0 !important;
      margin-top: 0 !important;
      margin-bottom: 8px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: block !important;
    }

    .layout-two-cols ol,
    .layout-two-cols-header ol,
    .layout-three-cols ol,
    .layout-three-cols-header ol,
    .two-cols-left ol,
    .two-cols-right ol,
    .three-cols-col ol,
    .pdf-col ol,
    .layout-two-cols-grid .pdf-list--ordered,
    .layout-three-cols-grid .pdf-list--ordered {
      list-style: decimal !important;
      list-style-type: decimal !important;
      padding-left: 1.25em !important;
      margin-left: 0 !important;
      margin-top: 0 !important;
      margin-bottom: 8px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: block !important;
    }

    .layout-two-cols li,
    .layout-two-cols-header li,
    .layout-three-cols li,
    .layout-three-cols-header li,
    .two-cols-left li,
    .two-cols-right li,
    .three-cols-col li,
    .pdf-col li,
    .pdf-col .pdf-list-item {
      padding-left: 0.2em !important;
      margin-left: 0 !important;
      margin-bottom: 6px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: list-item !important;
      line-height: 1.6 !important;
    }

    .layout-two-cols ul ul,
    .layout-three-cols ul ul,
    .three-cols-col ul ul,
    .pdf-col ul ul {
      list-style: circle !important;
      list-style-type: circle !important;
      padding-left: 1.25em !important;
      margin-top: 4px !important;
      margin-bottom: 4px !important;
    }

    /* 列表项内嵌标题与说明排版 */
    .slide-list-item-title,
    .pdf-list li > h1,
    .pdf-list li > h2,
    .pdf-list li > h3,
    .pdf-list li > h4,
    .pdf-list li > h5,
    .pdf-list li > h6,
    li > h1.slide-list-item-title,
    li > h2.slide-list-item-title,
    li > h3.slide-list-item-title,
    li > h4.slide-list-item-title {
      margin-top: 2px !important;
      margin-bottom: 6px !important;
      line-height: 1.35 !important;
      font-weight: 700 !important;
    }
    .pdf-list li > h1, li > h1.slide-list-item-title { font-size: 1.6rem !important; }
    .pdf-list li > h2, li > h2.slide-list-item-title { font-size: 1.4rem !important; }
    .pdf-list li > h3, li > h3.slide-list-item-title { font-size: 1.22rem !important; }
    .pdf-list li > h4, li > h4.slide-list-item-title { font-size: 1.1rem !important; }
    .slide-list-item-desc,
    .pdf-list li > p {
      margin-top: 4px !important;
      margin-bottom: 6px !important;
      font-size: 1.05rem;
      line-height: 1.55;
      opacity: 0.92;
    }

    /* 多媒体（GIF动图、静态图片、MP4视频）全视口最大化自适应且不超出视口 */
    .slide-media-block,
    .slide-media-container,
    .slide-video-container,
    .slide-block--media,
    .slide-block--image,
    .slide-block--video,
    .slide-block:has(> img),
    .slide-block:has(> .slide-media-container),
    .slide-block:has(> p > img:only-child),
    .slide-block:has(> .slide-video-container),
    .slide-block:has(> video) {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      min-width: 0 !important;
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
      justify-content: center !important;
      width: 100% !important;
      height: 100% !important;
      max-height: 100% !important;
      overflow: hidden !important;
      margin: 4px 0 !important;
      box-sizing: border-box !important;
    }

    .two-cols-left > .slide-block,
    .two-cols-right > .slide-block,
    .three-cols-col > .slide-block,
    .pdf-col > .slide-block,
    .pdf-col .slide-block {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      max-height: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      width: 100% !important;
      height: 100% !important;
      box-sizing: border-box !important;
      overflow: hidden !important;
      margin-bottom: 0 !important;
    }

    /* 列内列表项的标题与段落文字：固定高度，不压缩 */
    .two-cols-left .slide-list-item-title,
    .two-cols-right .slide-list-item-title,
    .three-cols-col .slide-list-item-title,
    .pdf-col .slide-list-item-title,
    .two-cols-left h1, .two-cols-left h2, .two-cols-left h3, .two-cols-left h4, .two-cols-left h5, .two-cols-left h6,
    .two-cols-right h1, .two-cols-right h2, .two-cols-right h3, .two-cols-right h4, .two-cols-right h5, .two-cols-right h6,
    .three-cols-col h1, .three-cols-col h2, .three-cols-col h3, .three-cols-col h4, .three-cols-col h5, .three-cols-col h6,
    .pdf-col h1, .pdf-col h2, .pdf-col h3, .pdf-col h4, .pdf-col h5, .pdf-col h6,
    .three-cols-col .slide-list-item-desc,
    .pdf-col .slide-list-item-desc {
      flex: 0 0 auto !important;
      margin-top: 0 !important;
      margin-bottom: 6px !important;
    }

    /* 列内媒体容器：填满标题下方所有剩余垂直空间，纵向顶部对齐，横向居中，无溢出 */
    .two-cols-left .slide-list-media,
    .two-cols-right .slide-list-media,
    .three-cols-col .slide-list-media,
    .pdf-col .slide-list-media,
    .two-cols-left .slide-video-container,
    .two-cols-right .slide-video-container,
    .three-cols-col .slide-video-container,
    .pdf-col .slide-video-container,
    .two-cols-left .slide-media-container,
    .two-cols-right .slide-media-container,
    .three-cols-col .slide-media-container,
    .pdf-col .slide-media-container {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      min-width: 0 !important;
      width: 100% !important;
      height: 100% !important;
      max-height: 100% !important;
      max-width: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
      justify-content: flex-start !important;
      overflow: hidden !important;
      margin: 0 !important;
      padding: 0 !important;
      box-sizing: border-box !important;
    }

    /* 列内多媒体播放器：以 contain 模式等比缩放完整可见，绝对不超高超宽、不产生遮挡与滚动条 */
    .two-cols-left video,
    .two-cols-right video,
    .three-cols-col video,
    .pdf-col video,
    .two-cols-left img,
    .two-cols-right img,
    .three-cols-col img,
    .pdf-col img,
    .two-cols-left .slide-video-player,
    .two-cols-right .slide-video-player,
    .three-cols-col .slide-video-player,
    .pdf-col .slide-video-player,
    .layout-three-cols-grid video,
    .layout-two-cols-grid video,
    .layout-three-cols-grid img,
    .layout-two-cols-grid img {
      max-width: 100% !important;
      max-height: 100% !important;
      width: auto !important;
      height: auto !important;
      min-width: 0 !important;
      min-height: 0 !important;
      object-fit: contain !important;
      display: block !important;
      margin: 0 auto !important;
      cursor: zoom-in;
    }

    .slide-block img,
    .slide-media-img,
    .slide-media-container img,
    .slide-video-player,
    video.slide-video-player,
    .slide-block video {
      max-width: 100% !important;
      max-height: 100% !important;
      width: auto !important;
      height: auto !important;
      min-width: 0 !important;
      min-height: 0 !important;
      object-fit: contain !important;
      display: block !important;
      margin: 0 auto !important;
      border-radius: 8px;
      box-shadow: 0 4px 16px rgba(0, 0, 0, 0.16);
      background: transparent;
      outline: none;
      cursor: zoom-in;
    }

    .slide-list-media {
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
      justify-content: flex-start !important;
      width: 100% !important;
      max-width: 100% !important;
      height: 100% !important;
      max-height: 100% !important;
      flex: 1 1 0% !important;
      margin-top: 4px !important;
      margin-bottom: 4px !important;
      min-height: 0 !important;
      overflow: hidden !important;
      box-sizing: border-box !important;
    }
    .slide-list-media img,
    .slide-list-media video,
    .slide-list-media .list-item-gif,
    .slide-list-media .slide-video-player {
      max-width: 100% !important;
      max-height: 100% !important;
      width: auto !important;
      height: auto !important;
      min-width: 0 !important;
      min-height: 0 !important;
      object-fit: contain !important;
      border-radius: 6px !important;
      box-shadow: 0 3px 12px rgba(0, 0, 0, 0.14) !important;
      display: block !important;
      margin: 0 auto !important;
      cursor: zoom-in;
    }

    .slide-block:has(.slide-list-media) {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      height: 100% !important;
      max-height: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      overflow: hidden !important;
    }
    .slide-block:has(.slide-list-media) .pdf-list,
    .slide-block:has(.slide-list-media) ul,
    .slide-block:has(.slide-list-media) ol {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      height: 100% !important;
      max-height: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      overflow: hidden !important;
      overflow-y: hidden !important;
    }
    .slide-block:has(.slide-list-media) li,
    .slide-block:has(.slide-list-media) .slide-list-item,
    .slide-block:has(.slide-list-media) .pdf-list-item,
    .slide-block:has(.slide-media-container) li,
    .slide-block:has(.slide-video-container) li,
    .two-cols-left li:has(.slide-list-media),
    .two-cols-right li:has(.slide-list-media),
    .three-cols-col li:has(.slide-list-media),
    .pdf-col li:has(.slide-list-media),
    li:has(.slide-list-media),
    li:has(.slide-video-container),
    li:has(.slide-media-container) {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      height: 100% !important;
      max-height: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      overflow: hidden !important;
      margin-bottom: 0 !important;
    }

    .layout-two-cols .slide-media-block,
    .layout-two-cols .slide-video-container,
    .layout-two-cols .slide-media-container,
    .layout-three-cols .slide-media-block,
    .layout-three-cols .slide-video-container,
    .layout-three-cols .slide-media-container {
      max-width: 100% !important;
      max-height: 100% !important;
      width: 100% !important;
      height: 100% !important;
      min-width: 0 !important;
      min-height: 0 !important;
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
      justify-content: flex-start !important;
      overflow: hidden !important;
    }

    /* Lightbox 大图与视频灯箱模态窗口 */
    .slidev-lightbox {
      position: fixed;
      top: 0;
      left: 0;
      width: 100vw;
      height: 100vh;
      background: rgba(0, 0, 0, 0.88);
      backdrop-filter: blur(8px);
      z-index: 999999;
      display: none;
      align-items: center;
      justify-content: center;
      cursor: zoom-out;
      opacity: 0;
      transition: opacity 0.2s cubic-bezier(0.16, 1, 0.3, 1);
    }
    .slidev-lightbox.active {
      display: flex;
      opacity: 1;
    }
    .slidev-lightbox-content {
      position: relative;
      max-width: 92vw;
      max-height: 92vh;
      display: flex;
      align-items: center;
      justify-content: center;
      cursor: default;
    }
    .slidev-lightbox-img {
      max-width: 92vw;
      max-height: 92vh;
      object-fit: contain;
      border-radius: 8px;
      box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.75);
    }
    .slidev-lightbox-video {
      max-width: 92vw;
      max-height: 92vh;
      border-radius: 8px;
      box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.75);
    }
    .slidev-lightbox-close {
      position: absolute;
      top: 24px;
      right: 28px;
      width: 40px;
      height: 40px;
      background: rgba(255, 255, 255, 0.2);
      border: 1px solid rgba(255, 255, 255, 0.35);
      border-radius: 50%;
      color: #fff;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 22px;
      cursor: pointer;
      transition: background 0.2s, transform 0.2s;
      z-index: 1000000;
    }
    .slidev-lightbox-close:hover {
      background: rgba(255, 255, 255, 0.35);
      transform: scale(1.05);
    }

    img.slide-inline-img {
      max-width: 100% !important;
      max-height: min(320px, 40vh) !important;
      object-fit: contain !important;
      vertical-align: middle;
      border-radius: 4px;
    }
    kbd {
      display: inline-block;
      padding: 2px 7px;
      font-family: ui-monospace, SFMono-Regular, "SF Mono", Menlo, Consolas, "Liberation Mono", monospace;
      font-size: 0.85em;
      font-weight: 600;
      line-height: 1.25;
      color: inherit;
      background: rgba(125, 125, 125, 0.12);
      border: 1px solid rgba(125, 125, 125, 0.35);
      border-bottom-width: 2px;
      border-radius: 5px;
      box-shadow: 0 1px 2px rgba(0, 0, 0, 0.12);
      margin: 0 2px;
      vertical-align: middle;
      white-space: nowrap;
    }
    [data-theme="dark"] kbd, .theme-dark kbd {
      background: rgba(255, 255, 255, 0.1);
      border-color: rgba(255, 255, 255, 0.25);
      border-bottom-color: rgba(255, 255, 255, 0.4);
      color: #f1f5f9;
      box-shadow: 0 1px 2px rgba(0, 0, 0, 0.4);
    }
    .slide-block pre,
    pre {
      background: rgba(0, 0, 0, 0.1);
      padding: 12px;
      border-radius: 6px;
      font-family: "JetBrains Mono", Consolas, monospace;
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      overflow-x: hidden !important;
      overflow-y: auto !important;
      max-width: 100% !important;
      box-sizing: border-box !important;
    }
    .slide-block pre code,
    pre code {
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      display: block !important;
      width: 100% !important;
      box-sizing: border-box !important;
    }
    .code-line {
      display: flex !important;
      align-items: flex-start !important;
      width: 100% !important;
      box-sizing: border-box !important;
      line-height: 1.6;
    }
    .code-line .line-no {
      display: inline-block !important;
      flex-shrink: 0 !important;
      min-width: 2.2em !important;
      text-align: right !important;
      margin-right: 12px !important;
      user-select: none !important;
      opacity: 0.45 !important;
    }
    .code-line .line-content {
      flex: 1 1 0% !important;
      min-width: 0 !important;
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
    }
    /* 弱提示滚动条样式 */
    * {
      scrollbar-width: thin;
      scrollbar-color: rgba(255, 255, 255, 0.20) transparent;
    }
    *::-webkit-scrollbar {
      width: 4px;
      height: 4px;
    }
    *::-webkit-scrollbar-track {
      background: transparent;
    }
    *::-webkit-scrollbar-thumb {
      background: rgba(255, 255, 255, 0.20);
      border-radius: 2px;
      transition: background 0.2s ease;
    }
    *:hover::-webkit-scrollbar-thumb,
    *::-webkit-scrollbar-thumb:hover {
      background: rgba(255, 255, 255, 0.45);
    }
    /* Slidev Micro-motion Keyframes & Presets */
    @keyframes slidevMotionFadeIn { from { opacity: 0; } to { opacity: 1; } }
    @keyframes slidevMotionSlideUp { from { opacity: 0; transform: translateY(40px); } to { opacity: 1; transform: translateY(0); } }
    @keyframes slidevMotionSlideDown { from { opacity: 0; transform: translateY(-40px); } to { opacity: 1; transform: translateY(0); } }
    @keyframes slidevMotionSlideLeft { from { opacity: 0; transform: translateX(40px); } to { opacity: 1; transform: translateX(0); } }
    @keyframes slidevMotionSlideRight { from { opacity: 0; transform: translateX(-40px); } to { opacity: 1; transform: translateX(0); } }
    @keyframes slidevMotionZoomIn { from { opacity: 0; transform: scale(0.8); } to { opacity: 1; transform: scale(1); } }
    @keyframes slidevMotionBounce {
      0% { opacity: 0; transform: translateY(40px); }
      60% { opacity: 1; transform: translateY(-8px); }
      80% { transform: translateY(4px); }
      100% { transform: translateY(0); }
    }
    .slidev-motion-fade-in { animation: slidevMotionFadeIn var(--motion-duration, 0.4s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slidev-motion-slide-up { animation: slidevMotionSlideUp var(--motion-duration, 0.45s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slidev-motion-slide-down { animation: slidevMotionSlideDown var(--motion-duration, 0.45s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slidev-motion-slide-left { animation: slidevMotionSlideLeft var(--motion-duration, 0.45s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slidev-motion-slide-right { animation: slidevMotionSlideRight var(--motion-duration, 0.45s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slidev-motion-zoom-in, .slidev-motion-pop { animation: slidevMotionZoomIn var(--motion-duration, 0.4s) cubic-bezier(0.34, 1.56, 0.64, 1) var(--motion-delay, 0s) both; }
    .slidev-motion-bounce { animation: slidevMotionBounce var(--motion-duration, 0.6s) cubic-bezier(0.34, 1.56, 0.64, 1) var(--motion-delay, 0s) both; }
    .controls {
      position: absolute; bottom: 16px; display: flex; gap: 12px; align-items: center;
      background: rgba(24, 24, 27, 0.8); backdrop-filter: blur(8px);
      padding: 6px 18px; border-radius: 20px; color: #fff; font-size: 13px; z-index: 10;
    }
    .controls button { background: transparent; border: none; color: inherit; cursor: pointer; padding: 2px 6px; }

    /* Slidev Native Icons & Interactive Buttons */
    .slidev-icon-btn {
      display: inline-flex !important; flex-direction: row !important; align-items: center !important; justify-content: center !important;
      padding: 0.35rem 0.5rem; border-radius: 0.375rem; background: transparent;
      border: 1px solid transparent; color: inherit; font-size: inherit; line-height: 1;
      cursor: pointer; opacity: 0.8; transition: all 0.2s ease; text-decoration: none;
      vertical-align: middle; user-select: none; margin: 0 4px;
    }
    .slidev-icon-btn:hover { opacity: 1; background: rgba(255, 255, 255, 0.12); border-color: rgba(255, 255, 255, 0.15); }

    /* 组件从上到下按顺序流式渲染，避免相互重叠 */
    .slide-block > div + div { margin-top: 14px; }

    /* 同一个 div 内的按钮/链接从左到右水平渲染 */
    .slide-block div:has(> .slidev-icon-btn),
    .slide-block div:has(> button),
    .slide-block [class*="abs-"],
    .slidev-btn-row {
      display: inline-flex !important;
      flex-direction: row !important;
      align-items: center !important;
      justify-content: center !important;
      flex-wrap: wrap !important;
      gap: 8px !important;
    }

    /* Position Shortcuts 适配：在组件流中保持从上到下排列，不脱离流产生重叠 */
    .slide-block .abs-br,
    .slide-block .abs-bl,
    .slide-block .abs-tr,
    .slide-block .abs-tl,
    .slide-block [class*="abs-"] {
      position: relative !important;
      bottom: auto !important;
      right: auto !important;
      top: auto !important;
      left: auto !important;
      margin: 0.75rem auto !important;
    }

    .slide-block--absolute { position: relative !important; margin-bottom: 14px !important; padding: 0 !important; background: transparent !important; }
    .slide-block--absolute:hover { background: transparent !important; }
    .mt-12 { margin-top: 3rem !important; }
    .py-1 { padding-top: 0.25rem !important; padding-bottom: 0.25rem !important; }
    .m-6 { margin: 1.5rem !important; }
    .text-xl { font-size: 1.25rem !important; }
    [hover\\:bg~="white"][hover\\:bg~="op-10"]:hover,
    [hover\\:bg="white op-10"]:hover { background: rgba(255, 255, 255, 0.1) !important; border-radius: 4px; }
    .cursor-pointer, [data-clickable] { cursor: pointer; }
    /* Slidev 规范链接排版 (继承正文颜色，虚线底边，Hover 时平滑点亮为主题色并转为实线) */
    .slide-content a:not(.slidev-ref-tag):not(.slidev-icon-btn):not(.slidev-toc-link),
    .slide-block a:not(.slidev-ref-tag):not(.slidev-icon-btn):not(.slidev-toc-link),
    a.slidev-link {
      color: inherit;
      text-decoration: none;
      border-bottom: 1px dashed currentColor;
      transition: color 0.2s cubic-bezier(0.4, 0, 0.2, 1),
                  border-color 0.2s cubic-bezier(0.4, 0, 0.2, 1),
                  border-bottom-style 0.2s cubic-bezier(0.4, 0, 0.2, 1);
      cursor: pointer;
    }
    .slide-content a:not(.slidev-ref-tag):not(.slidev-icon-btn):not(.slidev-toc-link):hover,
    .slide-block a:not(.slidev-ref-tag):not(.slidev-icon-btn):not(.slidev-toc-link):hover,
    a.slidev-link:hover {
      color: var(--slide-accent);
      border-bottom-style: solid;
      border-bottom-color: var(--slide-accent);
    }
    .slidev-ref-tag, a.slidev-ref-tag {
      display: inline-flex;
      align-items: center;
      background: color-mix(in srgb, var(--slide-accent) 12%, transparent);
      color: var(--slide-accent);
      border-radius: 4px;
      padding: 2px 8px;
      font-size: 0.88em;
      text-decoration: none;
      cursor: pointer;
      margin: 2px 4px 2px 0;
      border: 1px solid color-mix(in srgb, var(--slide-accent) 25%, transparent);
      transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
    }
    .slidev-ref-tag:hover, a.slidev-ref-tag:hover {
      background: color-mix(in srgb, var(--slide-accent) 22%, transparent);
      color: var(--slide-accent);
      border-color: color-mix(in srgb, var(--slide-accent) 55%, transparent);
      transform: translateY(-1px);
      box-shadow: 0 2px 8px color-mix(in srgb, var(--slide-accent) 20%, transparent);
    }
    .slidev-block-ref {
      display: block;
      padding: 10px 14px;
      background: color-mix(in srgb, var(--slide-accent) 8%, transparent);
      border-left: 3px solid var(--slide-accent);
      border-radius: 0 6px 6px 0;
      margin: 8px 0;
      cursor: pointer;
      transition: background 0.2s ease;
    }
    .slidev-block-ref:hover {
      background: color-mix(in srgb, var(--slide-accent) 15%, transparent);
    }`}function ch(){return`    (function() {
      const data = window.__SLIDEV_DATA__ || { slides: [] };
      const slides = data.slides || [];
      let currentIndex = 0;

      const container = document.getElementById("slide-container");
      const pageNum = document.getElementById("page-num");
      const btnPrev = document.getElementById("btn-prev");
      const btnNext = document.getElementById("btn-next");
      const btnFullscreen = document.getElementById("btn-fullscreen");

      const baseWidth = 980;
      const aspectStr = (data.config && data.config.aspectRatio) || "16/9";
      let ratioNum = 16 / 9;
      if (aspectStr === "4/3") ratioNum = 4 / 3;
      else if (aspectStr === "16/10") ratioNum = 16 / 10;
      else if (typeof aspectStr === "string" && aspectStr.includes("/")) {
        const parts = aspectStr.split("/").map(Number);
        if (parts[0] && parts[1]) ratioNum = parts[0] / parts[1];
      }
      const baseHeight = Math.ceil(baseWidth / ratioNum);
      const viewport = document.getElementById("viewport");

      function updateScale() {
        if (!viewport) return;
        const isFull = !!document.fullscreenElement;
        const padX = isFull ? 0 : 20;
        const padY = isFull ? 0 : 32;
        const availW = Math.max(100, window.innerWidth - padX);
        const availH = Math.max(100, window.innerHeight - padY);
        const scale = Math.min(availW / baseWidth, availH / baseHeight);
        viewport.style.width = baseWidth + "px";
        viewport.style.height = baseHeight + "px";
        viewport.style.transform = "translate(-50%, -50%) scale(" + scale + ")";
        viewport.style.setProperty("--slidev-slide-scale", scale);
        if (isFull) document.body.classList.add("is-fullscreen");
        else document.body.classList.remove("is-fullscreen");
      }

      window.addEventListener("resize", updateScale);
      document.addEventListener("fullscreenchange", updateScale);

      function cleanCardListItemMarkdown(rawMarkdown) {
        if (!rawMarkdown) return "";
        let cleaned = rawMarkdown.replace(/^[ 	]*[-*+]s+|^[ 	]*d+.s+/, "");
        cleaned = cleaned.replace(/
[ 	]{2,4}/g, "
");
        return cleaned.trim();
      }

      function cleanColList(blocks) {
        const valid = (blocks || []).filter(b => Boolean((b.rawMarkdown || b.content || "").trim()));
        if (valid.length === 0) return valid;
        const first = valid[0];
        const md = (first.rawMarkdown || first.content || "").trim();
        const isList = /^(?:[-*+]|d+.)s+/.test(md) || first.type === "i" || first.type === "l";
        if (isList) {
          first.rawMarkdown = cleanCardListItemMarkdown(first.rawMarkdown || first.content || "");
          first.content = first.rawMarkdown;
        }
        return valid;
      }

      function renderBlock(block) {
        const div = document.createElement("div");
        div.className = "slide-block";
        if (block && block.motion && block.motion.preset && block.motion.preset !== "none") {
          div.classList.add("slidev-motion-" + block.motion.preset.toLowerCase());
          if (typeof block.motion.duration === "number" && block.motion.duration > 0) {
            div.style.setProperty("--motion-duration", block.motion.duration + "ms");
          }
          if (typeof block.motion.delay === "number" && block.motion.delay > 0) {
            div.style.setProperty("--motion-delay", block.motion.delay + "ms");
          }
        }
        const md = block.rawMarkdown || block.content || "";

        if (md.includes('class="slidev-block-ref"') || md.includes('class="slidev-ref-tag"')) {
          div.innerHTML = md;
          return div;
        }

        const CARBON_MAP = {
          'carbon:arrow-right': '<svg viewBox="0 0 32 32" width="1.2em" height="1.2em" fill="currentColor" style="display:inline-block;vertical-align:middle;"><path d="m18 6l-1.43 1.393L24.15 15H4v2h20.15l-7.58 7.573L18 26l10-10z"/></svg>',
          'carbon:arrow-left': '<svg viewBox="0 0 32 32" width="1.2em" height="1.2em" fill="currentColor" style="display:inline-block;vertical-align:middle;"><path d="m14 26l1.43-1.393L7.85 17H28v-2H7.85l7.58-7.573L14 6L4 16z"/></svg>',
          'carbon:edit': '<svg viewBox="0 0 32 32" width="1.2em" height="1.2em" fill="currentColor" style="display:inline-block;vertical-align:middle;"><path d="M2 26h28v2H2zM25.4 9c.8-.8.8-2 0-2.8l-3.6-3.6c-.8-.8-2-.8-2.8 0l-15 15V24h6.4l15-15zM20.4 4L24 7.6l-2.4 2.4l-3.6-3.6L20.4 4zM6 22v-3.6l11-11l3.6 3.6l-11 11H6z"/></svg>',
          'carbon:logo-github': '<svg viewBox="0 0 32 32" width="1.2em" height="1.2em" fill="currentColor" style="display:inline-block;vertical-align:middle;"><path fill-rule="evenodd" d="M16 2a14 14 0 0 0-4.43 27.28c.7.13 1-.3 1-.67v-2.38c-3.89.84-4.71-1.88-4.71-1.88a3.7 3.7 0 0 0-1.56-2.05c-1.27-.86.1-.85.1-.85a2.94 2.94 0 0 1 2.14 1.44a3 3 0 0 0 4.08 1.16a2.93 2.93 0 0 1 .89-1.87c-3.1-.35-6.36-1.55-6.36-6.9a5.4 5.4 0 0 1 1.44-3.75a5 5 0 0 1 .14-3.71s1.17-.38 3.85 1.43a13.3 13.3 0 0 1 7 0c2.67-1.81 3.84-1.43 3.84-1.43a5 5 0 0 1 .14 3.71a5.4 5.4 0 0 1 1.44 3.75c0 5.37-3.27 6.54-6.38 6.89a3.35 3.35 0 0 1 1.26 2.61v3.87c0 .38.26.81 1 .67A14 14 0 0 0 16 2"/></svg>'
        };

        if (/@\\w+=['"]|v-\\w+|<button|<a\\b|<carbon:|^<div/i.test(md)) {
          if (md.includes('abs-br') || md.includes('abs-bl') || md.includes('abs-tr') || md.includes('abs-tl') || md.includes('absolute')) {
            div.classList.add("slide-block--absolute");
          }
          let renderedHtml = md;
          for (const [tag, svg] of Object.entries(CARBON_MAP)) {
            const regex = new RegExp("<" + tag + "\\\\s*\\\\/?>", "gi");
            renderedHtml = renderedHtml.replace(regex, svg);
            const regexDash = new RegExp("<" + tag.replace(":", "-") + "\\\\s*\\\\/?>", "gi");
            renderedHtml = renderedHtml.replace(regexDash, svg);
          }
          div.innerHTML = renderedHtml;

          // 挂载交互事件监听
          const nextBtns = div.querySelectorAll('[\\\\@click*="nav.next"], [\\\\@click*="next"]');
          nextBtns.forEach(btn => {
            btn.style.cursor = "pointer";
            btn.addEventListener("click", (e) => {
              e.stopPropagation();
              renderSlide(currentIndex + 1);
            });
          });

          const prevBtns = div.querySelectorAll('[\\\\@click*="nav.prev"], [\\\\@click*="prev"]');
          prevBtns.forEach(btn => {
            btn.style.cursor = "pointer";
            btn.addEventListener("click", (e) => {
              e.stopPropagation();
              renderSlide(currentIndex - 1);
            });
          });

          return div;
        }

        const hasHeadingTag = /(?:^|
)s*#{1,6}s+/.test(md);

        if (md.startsWith("### ")) div.innerHTML = "<h3>" + md.slice(4) + "</h3>";
        else if (md.startsWith("## ")) div.innerHTML = "<h2>" + md.slice(3) + "</h2>";
        else if (md.startsWith("# ")) div.innerHTML = "<h1>" + md.slice(2) + "</h1>";
        else if (md.startsWith("\`\`\`")) {
          const customMaxHeight = block?.attributes?.["custom-slidev-max-height"] || block?.attrs?.["custom-slidev-max-height"] || block?.maxHeight || "";
          const heightStyle = customMaxHeight ? ' style="max-height:' + customMaxHeight + ';overflow-y:auto;"' : "";
          div.innerHTML = "<pre" + heightStyle + "><code>" + md.slice(3, -3) + "</code></pre>";
        }
        else if (md.startsWith("> ")) div.innerHTML = "<blockquote><p>" + md.slice(2) + "</p></blockquote>";
        else if ((/<video\b/i.test(md) || (block && (block.type === "video" || block.type === "NodeVideo"))) && !/^(s*)([-*+]|d+.)s+/m.test(md) && !hasHeadingTag && !md.includes("
")) {
          div.classList.add("slide-video-container", "slide-media-container", "slide-media-block");
          const isAutoplay = block && block.attributes && block.attributes["custom-slidev-autoplay"] === "true";
          const isLoop = block && block.attributes && block.attributes["custom-slidev-loop"] === "true";
          const isMuted = block && block.attributes && (block.attributes["custom-slidev-muted"] === "true" || isAutoplay);
          const hideControls = block && block.attributes && block.attributes["custom-slidev-controls"] === "false";
          let videoHtml = md;
          if (hideControls) videoHtml = videoHtml.replace(/\bcontrols(?:="[^"]*")?/gi, "").trim();
          else if (!videoHtml.includes("controls")) videoHtml = videoHtml.replace("<video", "<video controls");
          if (isAutoplay && !videoHtml.includes("autoplay")) videoHtml = videoHtml.replace("<video", "<video autoplay playsinline");
          if (isLoop && !videoHtml.includes("loop")) videoHtml = videoHtml.replace("<video", "<video loop");
          if (isMuted && !videoHtml.includes("muted")) videoHtml = videoHtml.replace("<video", "<video muted");
          videoHtml = videoHtml.replace("<video", '<video class="slide-video-player"');
          div.setAttribute("data-autoplay", isAutoplay ? "true" : "false");
          div.innerHTML = videoHtml;
        }
        else if (/^(s*)([-*+]|d+.)s+/m.test(md) || (md.includes("
") && /^(s*)([-*+]|d+.)s+/m.test(md.split("
").slice(1).join("
")))) {
          div.classList.add("pdf-list-item");
          const lines = md.split("
");
          let isOrdered = false;
          const items = [];
          const leadLines = [];
          for (let i = 0; i < lines.length; i++) {
            const line = lines[i];
            const tr = line.trim();
            if (!tr || /^{:.*?}$/.test(tr)) continue;
            const um = line.match(/^(s*)[-*+]s+(.*)$/);
            const om = line.match(/^(s*)d+.s+(.*)$/);
            if (um) {
              const indent = um[1].length;
              items.push({ type: "unordered", level: Math.floor(indent / 2), text: um[2], media: [] });
              continue;
            }
            if (om) {
              if (items.length === 0) isOrdered = true;
              const indent = om[1].length;
              items.push({ type: "ordered", level: Math.floor(indent / 2), text: om[2], media: [] });
              continue;
            }
            if (items.length > 0) {
              const im = tr.match(/^![(.*?)]((.*?))(?:{:?[^}]*})?$/);
              if (im) {
                const isGif = /.gif(?:?|$)/i.test(im[2]);
                items[items.length - 1].media.push('<div class="slide-list-media"><img alt="' + im[1] + '" src="' + im[2] + '" class="' + (isGif ? 'list-item-gif' : 'list-item-img') + '" /></div>');
                continue;
              }
              const hm = tr.match(/^<img\b[sS]*?/?>$/i);
              if (hm) {
                const cleanTr = tr.replace(/s+style="[^"]*"/gi, "");
                items[items.length - 1].media.push('<div class="slide-list-media">' + cleanTr + '</div>');
                continue;
              }
              if (/<video\b/i.test(tr)) {
                let vHtml = tr;
                if (!/</video>/i.test(vHtml)) {
                  while (i + 1 < lines.length && !/</video>/i.test(vHtml)) {
                    i++;
                    vHtml += " " + lines[i].trim();
                  }
                }
                const isAutoplay = block && block.attributes && block.attributes["custom-slidev-autoplay"] === "true";
                const isLoop = block && block.attributes && block.attributes["custom-slidev-loop"] === "true";
                const isMuted = block && block.attributes && (block.attributes["custom-slidev-muted"] === "true" || isAutoplay);
                const hideControls = block && block.attributes && block.attributes["custom-slidev-controls"] === "false";
                if (hideControls) vHtml = vHtml.replace(/\bcontrols(?:="[^"]*")?/gi, "").trim();
                else if (!vHtml.includes("controls")) vHtml = vHtml.replace("<video", "<video controls");
                if (isAutoplay && !vHtml.includes("autoplay")) vHtml = vHtml.replace("<video", "<video autoplay playsinline");
                if (isLoop && !vHtml.includes("loop")) vHtml = vHtml.replace("<video", "<video loop");
                if (isMuted && !vHtml.includes("muted")) vHtml = vHtml.replace("<video", "<video muted");
                vHtml = vHtml.replace("<video", '<video class="slide-video-player"');
                items[items.length - 1].media.push('<div class="slide-list-media slide-video-container slide-media-container" data-autoplay="' + (isAutoplay ? 'true' : 'false') + '">' + vHtml + '</div>');
                continue;
              }
              items[items.length - 1].text += "
" + tr;
            } else {
              leadLines.push(tr);
            }
          }

          let leadHtml = "";
          if (leadLines.length > 0) {
            const lParts = [];
            let pL = [];
            const flushLeadP = (isF) => {
              if (pL.length > 0) {
                let txt = pL.join(" ").replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
                lParts.push('<p class="' + (isF ? "slide-list-item-title" : "slide-list-item-desc") + '">' + txt + '</p>');
                pL = [];
              }
            };
            let isF = true;
            for (const l of leadLines) {
              const hm = l.match(/^(#{1,6})s+(.*)$/);
              if (hm) {
                flushLeadP(isF);
                const lvl = hm[1].length;
                let th = hm[2].trim().replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
                lParts.push('<h' + lvl + ' class="slide-list-item-title">' + th + '</h' + lvl + '>');
                isF = false;
              } else {
                pL.push(l);
              }
            }
            flushLeadP(isF);
            leadHtml = lParts.join("
") + "
";
          }

          const tag = isOrdered ? "ol" : "ul";
          const listCls = isOrdered ? "pdf-list pdf-list--ordered" : "pdf-list pdf-list--unordered";
          const liHtml = items.map(it => {
            const med = it.media && it.media.length ? "
" + it.media.join("
") : "";
            const lines = (it.text || "").split("
").map(l => l.trim()).filter(Boolean);
            const hasHeading = lines.some(l => /^#{1,6}s+/.test(l));
            const lvl = it.level || 0;
            const nStyle = lvl > 0 ? ' style="margin-left:' + (lvl * 1.25).toFixed(2) + 'em;' + (it.type === 'unordered' ? 'list-style-type:' + (lvl % 2 === 1 ? 'circle' : 'square') + ' !important;' : '') + '"' : "";
            const nClass = lvl > 0 ? " slide-list-item--nested" : "";
            const clsAttr = nClass ? ' class="' + nClass.trim() + '"' : "";
            if (!hasHeading) {
              let h = it.text.replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
              return '<li' + clsAttr + nStyle + '>' + h + med + '</li>';
            }
            const parts = [];
            let pLines = [];
            const flushP = () => {
              if (pLines.length > 0) {
                let ph = pLines.join(" ").replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
                parts.push('<p class="slide-list-item-desc">' + ph + '</p>');
                pLines = [];
              }
            };
            for (const l of lines) {
              const hm = l.match(/^(#{1,6})s+(.*)$/);
              if (hm) {
                flushP();
                const hl = hm[1].length;
                let th = hm[2].trim().replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
                parts.push('<h' + hl + ' class="slide-list-item-title">' + th + '</h' + hl + '>');
              } else {
                pLines.push(l);
              }
            }
            flushP();
            return '<li' + clsAttr + nStyle + '>' + parts.join("
") + med + '</li>';
          }).join("
");
          div.innerHTML = leadHtml + "<" + tag + " class="" + listCls + "">
" + liHtml + "
</" + tag + ">";
        }
        else {
          // 复合块（包含换行、标题或媒体）高保真解析
          const lines = md.split(/\r?
/);
          const subBlocks = [];
          let current = [];
          for (let i = 0; i < lines.length; i++) {
            const line = lines[i];
            const trimmed = line.trim();
            if (/^#{1,6}s+/.test(trimmed)) {
              if (current.length > 0) { subBlocks.push(current.join("
")); current = []; }
              subBlocks.push(trimmed);
              continue;
            }
            if (!trimmed) {
              if (current.length > 0) { subBlocks.push(current.join("
")); current = []; }
              continue;
            }
            if (/^![.*?](.*?)$/.test(trimmed)) {
              if (current.length > 0) { subBlocks.push(current.join("
")); current = []; }
              subBlocks.push(trimmed);
              continue;
            }
            if (/<video\b/i.test(trimmed)) {
              if (current.length > 0) { subBlocks.push(current.join("
")); current = []; }
              let vRaw = trimmed;
              if (!/</video>/i.test(vRaw)) {
                while (i + 1 < lines.length && !/</video>/i.test(vRaw)) {
                  i++;
                  vRaw += "
" + lines[i];
                }
              }
              subBlocks.push(vRaw);
              continue;
            }
            current.push(line);
          }
          if (current.length > 0) subBlocks.push(current.join("
"));

          if (subBlocks.length > 1 || (subBlocks.length === 1 && /^#{1,6}s+/.test(subBlocks[0].trim()))) {
            const htmlParts = subBlocks.map(sub => {
              const t = sub.trim();
              if (!t) return "";
              const hm = t.match(/^(#{1,6})s+(.*)$/);
              if (hm) {
                const hl = hm[1].length;
                let th = hm[2].trim().replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
                return '<h' + hl + ' class="slide-list-item-title">' + th + '</h' + hl + '>';
              }
              const im = t.match(/^![(.*?)]((.*?))$/);
              if (im) {
                return '<div class="slide-media-block slide-media-container slide-list-media"><img alt="' + im[1] + '" src="' + im[2] + '" class="slide-media-img" /></div>';
              }
              if (/<video\b/i.test(t)) {
                return '<div class="slide-media-block slide-video-container slide-media-container">' + t + '</div>';
              }
              let ph = t.replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
              return '<p class="slide-list-item-desc">' + ph + '</p>';
            }).filter(Boolean);
            div.innerHTML = htmlParts.join("
");
          } else {
            const imgMatch = md.match(/!\\[(.*?)\\]\\((.*?)\\)/);
            if (imgMatch) {
              div.classList.add("slide-media-container", "slide-media-block", "slide-block--image");
              div.innerHTML = '<img alt="' + imgMatch[1] + '" src="' + imgMatch[2] + '" class="slide-media-img" />';
            } else {
              let html = md.replace(/\\*\\*(.*?)\\*\\*/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
              div.innerHTML = "<p>" + html + "</p>";
            }
          }
        }
        return div;
      }

      function renderSlide(idx) {
        if (slides.length === 0) return;
        currentIndex = Math.max(0, Math.min(idx, slides.length - 1));
        const slide = slides[currentIndex];
        pageNum.textContent = (currentIndex + 1) + " / " + slides.length;

        const pageSp = slide.frontmatter?.spacing;
        const currentSpacing = (pageSp && pageSp !== "inherit") ? pageSp : (data.config?.spacing || "normal");
        container.className = "slide-content layout-" + (slide.frontmatter?.layout || "default") + " spacing-" + currentSpacing;
        if (viewport) viewport.setAttribute("data-spacing", currentSpacing);
        container.innerHTML = "";

        const z = typeof slide.frontmatter?.zoom === "number" && slide.frontmatter.zoom > 0 ? slide.frontmatter.zoom : 1;
        if (z !== 1) {
          container.style.width = (100 / z) + "%";
          container.style.height = (100 / z) + "%";
          container.style.transformOrigin = "top left";
          container.style.transform = "scale(" + z + ")";
        } else {
          container.style.width = "100%";
          container.style.height = "100%";
          container.style.transform = "none";
        }

        if (slide.frontmatter?.layout === "two-cols") {
          const leftCol = document.createElement("div");
          leftCol.className = "two-cols-left";
          const rightCol = document.createElement("div");
          rightCol.className = "two-cols-right";

          const blocks = (slide.blocks || []).filter(b => b.slot !== "slot-divider-right");
          let leftList = [];
          let rightList = [];
          for (const block of blocks) {
            if (block.slot === "right") rightList.push(block);
            else leftList.push(block);
          }
          leftList = cleanColList(leftList);
          rightList = cleanColList(rightList);
          for (const b of leftList) leftCol.appendChild(renderBlock(b));
          for (const b of rightList) rightCol.appendChild(renderBlock(b));
          container.appendChild(leftCol);
          container.appendChild(rightCol);
        } else if (slide.frontmatter?.layout === "two-cols-header") {
          const containerDiv = document.createElement("div");
          containerDiv.className = "layout-two-cols-header-container";
          const headerDiv = document.createElement("div");
          headerDiv.className = "layout-header-section";
          const gridDiv = document.createElement("div");
          gridDiv.className = "pdf-two-cols-wrapper layout-two-cols-grid";
          const leftCol = document.createElement("div");
          leftCol.className = "pdf-col pdf-col--left";
          const rightCol = document.createElement("div");
          rightCol.className = "pdf-col pdf-col--right";

          const blocks = (slide.blocks || []).filter(b => b.slot !== "slot-divider-right");
          let headerBlocks = blocks.filter(b => b.slot === "header");
          if (headerBlocks.length === 0 && blocks.length > 0) {
            const candidate = blocks.find(b => b.type === "h" && (!b.slot || b.slot === "default"));
            if (candidate) headerBlocks = [candidate];
          }
          const rem = blocks.filter(b => !headerBlocks.includes(b));
          let leftList = [];
          let rightList = [];
          for (const b of rem) {
            if (b.slot === "right" || b.slot === "col-2") rightList.push(b);
            else leftList.push(b);
          }
          leftList = cleanColList(leftList);
          rightList = cleanColList(rightList);
          for (const b of headerBlocks) headerDiv.appendChild(renderBlock(b));
          for (const b of leftList) leftCol.appendChild(renderBlock(b));
          for (const b of rightList) rightCol.appendChild(renderBlock(b));
          gridDiv.appendChild(leftCol);
          gridDiv.appendChild(rightCol);
          containerDiv.appendChild(headerDiv);
          containerDiv.appendChild(gridDiv);
          container.appendChild(containerDiv);
        } else if (slide.frontmatter?.layout === "three-cols-header") {
          const containerDiv = document.createElement("div");
          containerDiv.className = "layout-three-cols-header-container";
          const headerDiv = document.createElement("div");
          headerDiv.className = "layout-header-section";
          const gridDiv = document.createElement("div");
          gridDiv.className = "pdf-three-cols-wrapper layout-three-cols-grid";
          const col1 = document.createElement("div");
          col1.className = "pdf-col pdf-col--1";
          const col2 = document.createElement("div");
          col2.className = "pdf-col pdf-col--2";
          const col3 = document.createElement("div");
          col3.className = "pdf-col pdf-col--3";

          const blocks = (slide.blocks || []).filter(b => b.slot !== "slot-divider-right");
          let headerBlocks = blocks.filter(b => b.slot === "header");
          if (headerBlocks.length === 0 && blocks.length > 0) {
            const candidate = blocks.find(b => b.type === "h" && (!b.slot || b.slot === "default"));
            if (candidate) headerBlocks = [candidate];
          }
          const rem = blocks.filter(b => !headerBlocks.includes(b));
          let c1 = [], c2 = [], c3 = [];
          const hasExplicitCols = rem.some(b => b.slot === "col-1" || b.slot === "col-2" || b.slot === "col-3" || b.slot === "center" || b.slot === "left" || b.slot === "right");
          if (hasExplicitCols) {
            c2 = rem.filter(b => b.slot === "col-2" || b.slot === "center");
            c3 = rem.filter(b => b.slot === "col-3" || b.slot === "right");
            c1 = rem.filter(b => !c2.includes(b) && !c3.includes(b));
          } else if (rem.length >= 3) {
            const count1 = Math.ceil(rem.length / 3);
            const count2 = Math.ceil((rem.length - count1) / 2);
            c1 = rem.slice(0, count1);
            c2 = rem.slice(count1, count1 + count2);
            c3 = rem.slice(count1 + count2);
          } else if (rem.length === 2) {
            c1 = [rem[0]];
            c2 = [rem[1]];
            c3 = [];
          } else if (rem.length === 1) {
            const lines = (rem[0].rawMarkdown || rem[0].content || "").trim().split(/\r?
/);
            const itemStartIndices = [];
            for (let i = 0; i < lines.length; i++) {
              if (/^[ 	]*[-*+]s+|^[ 	]*d+.s+/.test(lines[i])) itemStartIndices.push(i);
            }
            if (itemStartIndices.length >= 3) {
              const count1 = Math.ceil(itemStartIndices.length / 3);
              const count2 = Math.ceil((itemStartIndices.length - count1) / 2);
              const items1 = lines.slice(itemStartIndices[0], itemStartIndices[count1]).join("
");
              const items2 = lines.slice(itemStartIndices[count1], itemStartIndices[count1 + count2]).join("
");
              const items3 = lines.slice(itemStartIndices[count1 + count2]).join("
");
              c1 = [{ ...rem[0], rawMarkdown: items1, content: items1 }];
              c2 = [{ ...rem[0], id: rem[0].id + "-col2", rawMarkdown: items2, content: items2 }];
              c3 = [{ ...rem[0], id: rem[0].id + "-col3", rawMarkdown: items3, content: items3 }];
            } else {
              c1 = rem;
            }
          } else {
            c1 = rem;
          }
          c1 = cleanColList(c1);
          c2 = cleanColList(c2);
          c3 = cleanColList(c3);
          for (const b of headerBlocks) headerDiv.appendChild(renderBlock(b));
          for (const b of c1) col1.appendChild(renderBlock(b));
          for (const b of c2) col2.appendChild(renderBlock(b));
          for (const b of c3) col3.appendChild(renderBlock(b));
          gridDiv.appendChild(col1);
          gridDiv.appendChild(col2);
          gridDiv.appendChild(col3);
          containerDiv.appendChild(headerDiv);
          containerDiv.appendChild(gridDiv);
          container.appendChild(containerDiv);
        } else if (slide.frontmatter?.layout === "image-right" || slide.frontmatter?.layout === "image-left") {
          const isImageRight = slide.frontmatter?.layout === "image-right";
          const contentCol = document.createElement("div");
          contentCol.className = isImageRight ? "image-right-content" : "image-left-content";

          for (const block of (slide.blocks || [])) {
            contentCol.appendChild(renderBlock(block));
          }

          const imgCol = document.createElement("div");
          imgCol.className = isImageRight ? "image-right-img-container" : "image-left-img-container";
          const img = document.createElement("img");
          img.className = isImageRight ? "image-right-img" : "image-left-img";
          img.src = slide.frontmatter?.image || slide.frontmatter?.background || "";
          img.alt = "Slide cover";
          img.onerror = function() {
            this.src = "https://fastly.jsdelivr.net/gh/slidevjs/slidev-covers@main/static/2HmfbSpvcos.webp";
          };
          imgCol.appendChild(img);

          if (isImageRight) {
            container.appendChild(contentCol);
            container.appendChild(imgCol);
          } else {
            container.appendChild(imgCol);
            container.appendChild(contentCol);
          }
        } else {
          for (const block of (slide.blocks || [])) {
            container.appendChild(renderBlock(block));
          }
        }

        function syncAutoplayVideos() {
          const doSync = () => {
            const videos = container.querySelectorAll("video");
            videos.forEach((v) => {
              const box = v.closest("[data-autoplay]");
              const isAuto = v.hasAttribute("autoplay") || v.autoplay || (box && box.getAttribute("data-autoplay") === "true");
              if (isAuto) {
                v.muted = true;
                v.defaultMuted = true;
                v.setAttribute("muted", "");
                v.playsInline = true;
                v.setAttribute("playsinline", "");
                const playFn = () => {
                  if (!v.paused) return;
                  v.muted = true;
                  v.defaultMuted = true;
                  const p = v.play();
                  if (p !== undefined) {
                    p.catch(() => {
                      v.muted = true;
                      v.defaultMuted = true;
                      setTimeout(() => { if (v.paused) v.play().catch(() => {}); }, 150);
                    });
                  }
                };
                playFn();
                if (!v.__autoplayBound) {
                  v.__autoplayBound = true;
                  v.addEventListener("loadedmetadata", playFn);
                  v.addEventListener("canplay", playFn);
                }
              }
            });
          };
          setTimeout(doSync, 60);
          setTimeout(doSync, 200);
        }
        syncAutoplayVideos();
      }

      // Lightbox 控制逻辑
      const lightbox = document.getElementById("slidev-lightbox");
      const lightboxContent = document.getElementById("lightbox-content");
      const lightboxClose = document.getElementById("lightbox-close");
      let isLightboxOpen = false;

      function openLightbox(type, src, alt) {
        if (!lightbox || !lightboxContent) return;
        lightboxContent.innerHTML = "";
        if (type === "video") {
          const v = document.createElement("video");
          v.className = "slidev-lightbox-video";
          v.src = src;
          v.controls = true;
          v.autoplay = true;
          v.playsInline = true;
          lightboxContent.appendChild(v);
        } else {
          const img = document.createElement("img");
          img.className = "slidev-lightbox-img";
          img.src = src;
          img.alt = alt || "";
          lightboxContent.appendChild(img);
        }
        lightbox.classList.add("active");
        isLightboxOpen = true;
      }

      function closeLightbox() {
        if (!lightbox) return;
        const v = lightbox.querySelector("video");
        if (v) v.pause();
        lightbox.classList.remove("active");
        if (lightboxContent) lightboxContent.innerHTML = "";
        isLightboxOpen = false;
      }

      if (lightboxClose) {
        lightboxClose.addEventListener("click", (e) => {
          e.stopPropagation();
          closeLightbox();
        });
      }
      if (lightbox) {
        lightbox.addEventListener("click", (e) => {
          if (e.target === lightbox || e.target === lightboxClose) {
            e.stopPropagation();
            closeLightbox();
          }
        });
      }

      btnPrev.addEventListener("click", () => renderSlide(currentIndex - 1));
      btnNext.addEventListener("click", () => renderSlide(currentIndex + 1));
      btnFullscreen.addEventListener("click", () => {
        if (!document.fullscreenElement) {
          document.documentElement.requestFullscreen().then(() => updateScale()).catch(() => {});
        } else {
          document.exitFullscreen().then(() => updateScale()).catch(() => {});
        }
      });

      window.addEventListener("keydown", (e) => {
        if (e.key === "Escape" || e.key === "Esc") {
          if (isLightboxOpen) {
            closeLightbox();
            e.preventDefault();
            return;
          }
        }
        if (isLightboxOpen) return;
        if (e.key === "ArrowRight" || e.key === " ") renderSlide(currentIndex + 1);
        if (e.key === "ArrowLeft") renderSlide(currentIndex - 1);
        if (e.key === "f" || e.key === "F") btnFullscreen.click();
      });

      document.addEventListener("click", (e) => {
        if (isLightboxOpen) return;
        if (e.button !== 0) return;
        const targetEl = e.target instanceof Element ? e.target : e.target?.parentElement;
        if (!targetEl || !targetEl.closest) return;

        const refEl = targetEl.closest("[data-ref-id]");
        if (refEl) {
          const id = refEl.getAttribute("data-ref-id");
          if (id) {
            window.open("siyuan://blocks/" + id, "_blank");
            return;
          }
        }

        // 媒体点击唤起 Lightbox 放大模态
        const mediaEl = targetEl.closest(".slide-content img, .slide-content video");
        if (mediaEl && !mediaEl.closest(".controls, button, a")) {
          e.stopPropagation();
          const isVideo = mediaEl.tagName.toLowerCase() === "video";
          const src = isVideo ? (mediaEl.currentSrc || mediaEl.src || mediaEl.querySelector("source")?.src) : mediaEl.src;
          if (src) {
            openLightbox(isVideo ? "video" : "image", src, mediaEl.alt || "");
            return;
          }
        }

        const selection = window.getSelection ? window.getSelection().toString().trim() : "";
        if (selection.length > 0) return;

        const isComponent = targetEl.closest(
          ".slide-block, .controls-bar, .image-right-img-container, .image-left-img-container, img, video, audio, button, a, input, textarea, select, [data-clickable], [data-ref-id], .slidev-toc, .empty-state"
        );
        if (isComponent) return;

        const isLeft = e.clientX < window.innerWidth / 2;
        if (isLeft) {
          renderSlide(currentIndex - 1);
        } else {
          renderSlide(currentIndex + 1);
        }
      });

      renderSlide(0);
      updateScale();
    })();`}function Vl(t,i){const e="Slidev 演示文稿";let o=t.slides;const n=JSON.stringify(o),r=JSON.stringify(t.config);return`<!DOCTYPE html>
<html lang="zh-CN">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${te(e)}</title>
  <style>
${ah(i==null?void 0:i.customInlineStyles)}
  </style>
  <script>
    // 注入演示数据载荷
    window.__SLIDEV_DATA__ = {
      docId: ${JSON.stringify(t.docId)},
      slides: ${n},
      config: ${r}
    };
  <\/script>
</head>
<body>
  <div id="app">
    <div class="slide-viewport slidev-theme-${t.config.theme||"default"}" id="viewport" data-slidev-theme="${t.config.theme||"default"}">
      <div class="slide-content" id="slide-container"></div>
    </div>
    <div class="controls">
      <button id="btn-prev">◀ 上一页</button>
      <span id="page-num">1 / 1</span>
      <button id="btn-next">下一页 ▶</button>
      <button id="btn-fullscreen">⛶ 全屏</button>
    </div>
    <!-- 全屏媒体灯箱 (Lightbox) 模态窗口 -->
    <div id="slidev-lightbox" class="slidev-lightbox">
      <button class="slidev-lightbox-close" id="lightbox-close" aria-label="关闭 (Esc)">✕</button>
      <div class="slidev-lightbox-content" id="lightbox-content"></div>
    </div>
  </div>

  <script>
${ch()}
  <\/script>
</body>
</html>`}function Kl(t,i){if(typeof document>"u")return!1;const e=new Blob([i],{type:"text/html;charset=utf-8"}),o=URL.createObjectURL(e),n=document.createElement("a");return n.href=o,n.download=t.endsWith(".html")?t:`${t}.html`,document.body.appendChild(n),n.click(),document.body.removeChild(n),URL.revokeObjectURL(o),!0}function dh(t){switch(t){case"4:3":return"size: 12in 9in;";case"A4-landscape":return"size: 297mm 210mm;";case"A4-portrait":return"size: 210mm 297mm;";case"16:9":default:return"size: 16in 9in;"}}function uh(t){const i=dh(t==null?void 0:t.pageRatio);return`
    ${on(t==null?void 0:t.customInlineStyles)}

    @page {
      ${i}
      margin: 0;
    }
    * {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
      -webkit-print-color-adjust: exact !important;
      print-color-adjust: exact !important;
    }
    body {
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "PingFang SC", "Microsoft YaHei", sans-serif;
      background: #f8fafc;
      color: #1e293b;
    }
    .pdf-slide-page {
      width: 100vw;
      height: 100vh;
      page-break-after: always;
      break-after: page;
      padding: var(--slidev-padding-y, 36px) var(--slidev-padding-x, 56px);
      display: flex;
      flex-direction: column;
      position: relative;
      background: #ffffff;
      overflow: hidden;
    }
    .pdf-slide-page.spacing-compact {
      --slidev-padding-y: 20px;
      --slidev-padding-x: 36px;
      --slidev-header-gap: 10px;
      --slidev-title-margin-bottom: 6px;
    }
    .pdf-slide-page.spacing-normal {
      --slidev-padding-y: 36px;
      --slidev-padding-x: 56px;
      --slidev-header-gap: 16px;
      --slidev-title-margin-bottom: 10px;
    }
    .pdf-slide-page.spacing-loose {
      --slidev-padding-y: 48px;
      --slidev-padding-x: 64px;
      --slidev-header-gap: 24px;
      --slidev-title-margin-bottom: 16px;
    }
    .pdf-slide-page.theme-dark {
      background: #0f1117;
      color: #f1f5f9;
    }
    .pdf-slide-header {
      font-size: 13px;
      color: #64748b;
      margin-bottom: 24px;
      display: flex;
      justify-content: space-between;
      border-bottom: 1px solid #e2e8f0;
      padding-bottom: 8px;
    }
    .theme-dark .pdf-slide-header {
      border-bottom-color: #2e3346;
      color: #94a3b8;
    }
    .pdf-slide-body {
      flex: 1;
      display: flex;
      flex-direction: column;
      gap: 16px;
      font-size: 20px;
      line-height: 1.6;
      overflow: hidden;
    }
    .pdf-block h1 { font-size: 2.5rem; font-weight: 800; color: #2563eb; margin-bottom: 12px; }
    .pdf-block h2 { font-size: 1.9rem; font-weight: 700; color: #1d4ed8; margin-bottom: 10px; }
    .pdf-block h3 { font-size: 1.4rem; font-weight: 600; margin-bottom: 8px; }
    .pdf-block h4 { font-size: 1.2rem; font-weight: 600; margin-bottom: 6px; }
    .pdf-block p { font-size: 1.15rem; color: inherit; }
    .pdf-code,
    pre {
      background: #f1f5f9;
      padding: 14px 18px;
      border-radius: 6px;
      font-family: "JetBrains Mono", Consolas, monospace;
      font-size: 0.95rem;
      border-left: 4px solid #3b82f6;
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      max-width: 100% !important;
      box-sizing: border-box !important;
    }
    .pdf-code code,
    pre code {
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      display: block !important;
      width: 100% !important;
      box-sizing: border-box !important;
    }
    .code-line {
      display: flex !important;
      align-items: flex-start !important;
      width: 100% !important;
      box-sizing: border-box !important;
      line-height: 1.6;
    }
    .code-line .line-no {
      display: inline-block !important;
      flex-shrink: 0 !important;
      min-width: 2.2em !important;
      text-align: right !important;
      margin-right: 12px !important;
      user-select: none !important;
      opacity: 0.45 !important;
    }
    .code-line .line-content {
      flex: 1 1 0% !important;
      min-width: 0 !important;
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
    }
    .theme-dark .pdf-code {
      background: #1e1e24;
      border-left-color: #60a5fa;
    }
    .pdf-quote {
      border-left: 4px solid #10b981;
      background: rgba(16, 185, 129, 0.08);
      padding: 10px 16px;
      border-radius: 0 4px 4px 0;
      font-style: italic;
    }
    .pdf-image,
    .slide-media-img {
      max-width: 100% !important;
      max-height: 48vh !important;
      width: auto !important;
      height: auto !important;
      object-fit: contain !important;
      border-radius: 6px;
      margin: auto;
      display: block;
    }
    .slide-media-block,
    .slide-media-container,
    .slide-video-container {
      display: flex;
      flex-direction: column;
      justify-content: center;
      align-items: center;
      width: 100%;
      max-height: 48vh;
      margin: 8px 0;
      overflow: hidden;
    }
    .slide-list-media {
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: flex-start;
      margin-top: 8px;
      margin-bottom: 6px;
      max-width: 100%;
      overflow: hidden;
    }
    .slide-list-media img,
    .slide-list-media video,
    .slide-list-media .list-item-gif {
      max-width: 100% !important;
      max-height: min(280px, 36vh) !important;
      width: auto !important;
      height: auto !important;
      min-width: 0 !important;
      min-height: 0 !important;
      object-fit: contain !important;
      border-radius: 6px;
      display: block;
      margin: 0 auto !important;
    }
    .slide-video-player {
      max-width: 100% !important;
      max-height: 48vh !important;
      width: auto !important;
      height: auto !important;
      object-fit: contain !important;
      border-radius: 6px;
      background: #000;
      border: 1px solid #cbd5e1;
    }
    .pdf-two-cols-wrapper,
    .layout-two-cols-grid {
      display: grid;
      grid-template-columns: minmax(0, 1fr) minmax(0, 1fr);
      grid-template-rows: minmax(0, 1fr) !important;
      gap: 36px;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      overflow: hidden !important;
    }
    .layout-two-cols-header-container,
    .layout-three-cols-header-container {
      display: flex;
      flex-direction: column;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      overflow: hidden !important;
    }
    .layout-header-section {
      width: 100%;
      margin-bottom: var(--slidev-header-gap, 16px) !important;
      flex-shrink: 0;
    }
    .layout-header-section h1,
    .layout-header-section h2,
    .layout-header-section h3 {
      margin-bottom: var(--slidev-title-margin-bottom, 10px) !important;
    }
    .pdf-three-cols-wrapper,
    .layout-three-cols-grid {
      display: grid;
      grid-template-columns: minmax(0, 1fr) minmax(0, 1fr) minmax(0, 1fr);
      grid-template-rows: minmax(0, 1fr) !important;
      gap: 24px;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      box-sizing: border-box;
      overflow: hidden !important;
    }
    .pdf-col {
      display: flex;
      flex-direction: column;
      gap: 14px;
      min-width: 0;
      width: 100%;
      max-width: 100%;
      height: 100%;
      max-height: 100%;
      min-height: 0;
      justify-content: flex-start;
      overflow: hidden;
      box-sizing: border-box;
      overflow-wrap: break-word;
      word-break: break-word;
      white-space: normal;
    }
    .pdf-col > .pdf-block,
    .pdf-col > .slide-block {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      max-height: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      width: 100% !important;
      height: 100% !important;
      box-sizing: border-box !important;
      overflow: hidden !important;
    }
    .pdf-col .slide-list-item-title,
    .pdf-col h1, .pdf-col h2, .pdf-col h3, .pdf-col h4, .pdf-col h5, .pdf-col h6,
    .pdf-col .slide-list-item-desc {
      flex: 0 0 auto !important;
      margin-top: 0 !important;
      margin-bottom: 6px !important;
    }
    .pdf-col .slide-list-media,
    .pdf-col .slide-video-container,
    .pdf-col .slide-media-container {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      min-width: 0 !important;
      width: 100% !important;
      height: 100% !important;
      max-height: 100% !important;
      max-width: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
      justify-content: flex-start !important;
      overflow: hidden !important;
      margin: 0 !important;
      padding: 0 !important;
      box-sizing: border-box !important;
    }
    .pdf-col li:has(.slide-list-media),
    .pdf-col li:has(.slide-media-container),
    .pdf-col li:has(.slide-video-container),
    .pdf-col li:has(img),
    .pdf-col li:has(video),
    .pdf-col .pdf-list-item:has(.slide-list-media),
    .pdf-col .pdf-list-item:has(.slide-media-container),
    .pdf-col .pdf-list-item:has(.slide-video-container),
    .pdf-col .pdf-list-item:has(img),
    .pdf-col .pdf-list-item:has(video) {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      height: 100% !important;
      max-height: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      overflow: hidden !important;
      margin-bottom: 0 !important;
    }
    .pdf-col video,
    .layout-three-cols-grid video,
    .layout-two-cols-grid video,
    .pdf-col img,
    .layout-three-cols-grid img,
    .layout-two-cols-grid img,
    .pdf-col .slide-video-player {
      max-width: 100% !important;
      max-height: 100% !important;
      width: auto !important;
      height: auto !important;
      min-width: 0 !important;
      min-height: 0 !important;
      object-fit: contain !important;
      display: block !important;
      margin: 0 auto !important;
    }
    .pdf-col * {
      overflow-wrap: break-word;
      word-break: break-word;
      box-sizing: border-box;
    }
    .pdf-col pre {
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      max-width: 100% !important;
      box-sizing: border-box !important;
    }
    .pdf-list-item {
      padding-left: 20px;
    }
    .pdf-list {
      padding-left: 24px;
      margin: 8px 0;
      display: flex;
      flex-direction: column;
      gap: 6px;
    }
    .pdf-list li {
      font-size: 1.15rem;
      line-height: 1.6;
    }
    .pdf-task-item {
      list-style: none;
      margin-left: -20px;
      display: flex;
      align-items: center;
      gap: 8px;
    }
    .pdf-task-item input[type="checkbox"] {
      width: 1.15em;
      height: 1.15em;
      cursor: pointer;
    }
    /* 两栏与三栏（超级块分栏）布局：紧凑自然行距，子列表保留圆点与层级缩进 */
    .layout-two-cols ul,
    .layout-two-cols-header ul,
    .layout-three-cols ul,
    .layout-three-cols-header ul,
    .two-cols-left ul,
    .two-cols-right ul,
    .three-cols-col ul,
    .pdf-two-cols-wrapper ul,
    .pdf-three-cols-wrapper ul,
    .pdf-col ul,
    .layout-two-cols-grid .pdf-list,
    .layout-three-cols-grid .pdf-list,
    .layout-two-cols-grid .pdf-list--unordered,
    .layout-three-cols-grid .pdf-list--unordered {
      list-style: disc !important;
      list-style-type: disc !important;
      padding-left: 1.25em !important;
      margin-left: 0 !important;
      margin-top: 0 !important;
      margin-bottom: 8px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: block !important;
    }
    .layout-two-cols ol,
    .layout-two-cols-header ol,
    .layout-three-cols ol,
    .layout-three-cols-header ol,
    .two-cols-left ol,
    .two-cols-right ol,
    .three-cols-col ol,
    .pdf-two-cols-wrapper ol,
    .pdf-three-cols-wrapper ol,
    .pdf-col ol,
    .layout-two-cols-grid .pdf-list--ordered,
    .layout-three-cols-grid .pdf-list--ordered {
      list-style: decimal !important;
      list-style-type: decimal !important;
      padding-left: 1.25em !important;
      margin-left: 0 !important;
      margin-top: 0 !important;
      margin-bottom: 8px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: block !important;
    }
    .layout-two-cols li,
    .layout-two-cols-header li,
    .layout-three-cols li,
    .layout-three-cols-header li,
    .two-cols-left li,
    .two-cols-right li,
    .three-cols-col li,
    .pdf-col li,
    .pdf-col .pdf-list-item {
      padding-left: 0.2em !important;
      margin-left: 0 !important;
      margin-bottom: 6px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: list-item !important;
      line-height: 1.6 !important;
    }
    .layout-two-cols ul ul,
    .layout-three-cols ul ul,
    .three-cols-col ul ul,
    .pdf-col ul ul {
      list-style: circle !important;
      list-style-type: circle !important;
      padding-left: 1.25em !important;
      margin-top: 4px !important;
      margin-bottom: 4px !important;
    }
    /* 列表项内嵌标题与说明排版 */
    .slide-list-item-title,
    .pdf-list li > h1,
    .pdf-list li > h2,
    .pdf-list li > h3,
    .pdf-list li > h4,
    .pdf-list li > h5,
    .pdf-list li > h6,
    li > h1.slide-list-item-title,
    li > h2.slide-list-item-title,
    li > h3.slide-list-item-title,
    li > h4.slide-list-item-title {
      margin-top: 2px !important;
      margin-bottom: 6px !important;
      line-height: 1.35 !important;
      font-weight: 700 !important;
    }
    .pdf-list li > h1, li > h1.slide-list-item-title { font-size: 1.6rem !important; }
    .pdf-list li > h2, li > h2.slide-list-item-title { font-size: 1.4rem !important; }
    .pdf-list li > h3, li > h3.slide-list-item-title { font-size: 1.22rem !important; }
    .pdf-list li > h4, li > h4.slide-list-item-title { font-size: 1.1rem !important; }
    .slide-list-item-desc,
    .pdf-list li > p {
      margin-top: 4px !important;
      margin-bottom: 6px !important;
      font-size: 1.05rem;
      line-height: 1.55;
      opacity: 0.92;
    }
    kbd {
      display: inline-block;
      padding: 2px 7px;
      font-family: ui-monospace, SFMono-Regular, "SF Mono", Menlo, Consolas, "Liberation Mono", monospace;
      font-size: 0.85em;
      font-weight: 600;
      line-height: 1.25;
      color: inherit;
      background: rgba(125, 125, 125, 0.12);
      border: 1px solid rgba(125, 125, 125, 0.35);
      border-bottom-width: 2px;
      border-radius: 5px;
      box-shadow: 0 1px 2px rgba(0, 0, 0, 0.12);
      margin: 0 2px;
      vertical-align: middle;
      white-space: nowrap;
    }
    .theme-dark kbd {
      background: rgba(255, 255, 255, 0.1);
      border-color: rgba(255, 255, 255, 0.25);
      border-bottom-color: rgba(255, 255, 255, 0.4);
      color: #f1f5f9;
      box-shadow: 0 1px 2px rgba(0, 0, 0, 0.4);
    }
    a {
      color: inherit;
      text-decoration: none;
      border-bottom: 1px dashed currentColor;
    }
    .slidev-ref-tag, a.slidev-ref-tag {
      display: inline-flex;
      align-items: center;
      background: rgba(16, 185, 129, 0.1);
      color: #059669;
      border: 1px solid rgba(16, 185, 129, 0.25);
      border-radius: 4px;
      padding: 2px 8px;
      font-size: 0.88em;
      text-decoration: none;
      margin: 2px 4px 2px 0;
    }
    .theme-dark .slidev-ref-tag, .theme-dark a.slidev-ref-tag {
      background: rgba(52, 211, 153, 0.15);
      color: #34d399;
      border-color: rgba(52, 211, 153, 0.3);
    }
    .slidev-block-ref, .pdf-block--ref {
      background: rgba(16, 185, 129, 0.06);
      border-left: 3px solid #059669;
      border-radius: 0 6px 6px 0;
      padding: 10px 14px;
      margin: 8px 0;
    }
    .theme-dark .slidev-block-ref, .theme-dark .pdf-block--ref {
      background: rgba(52, 211, 153, 0.08);
      border-left-color: #34d399;
    }
    .pdf-slide-notes {
      font-size: 14px;
      color: #059669;
      border-top: 1px dashed #cbd5e1;
      padding-top: 12px;
      margin-top: auto;
      line-height: 1.5;
    }
    .theme-dark .pdf-slide-notes {
      color: #34d399;
      border-top-color: #334155;
    }
    /* Layouts */
    .layout-cover .pdf-slide-body {
      justify-content: center;
      align-items: center;
      text-align: center;
    }
    .layout-cover h1 {
      font-size: 3.2rem;
    }
    .layout-center .pdf-slide-body {
      justify-content: center;
      align-items: center;
      text-align: center;
    }
    .layout-fact .pdf-slide-body {
      justify-content: center;
      align-items: center;
      text-align: center;
    }
    .layout-fact h1 {
      font-size: 4.5rem;
      color: #ef4444;
    }
    @media print {
      .slidev-motion-fade-in,
      .slidev-motion-slide-up,
      .slidev-motion-slide-down,
      .slidev-motion-slide-left,
      .slidev-motion-slide-right,
      .slidev-motion-zoom-in,
      .slidev-motion-pop,
      .slidev-motion-bounce {
        animation: none !important;
        opacity: 1 !important;
        transform: none !important;
      }
    }
  `}function fh(t,i){const e="Slidev 演示讲义",o="16:9",n="light",r=t.slides.map((l,s)=>{const a=l.frontmatter.layout||"default",c=l.frontmatter.spacing,d=c&&c!=="inherit"?c:t.config.spacing||"normal",f=th(l),g=`${s+1} / ${t.slides.length}`;return`
      <section class="pdf-slide-page layout-${a} theme-${n} spacing-${d}">
        <header class="pdf-slide-header">
          <span class="pdf-doc-title">${te(e)}</span>
          ${`<span class="pdf-page-badge">P. ${g}</span>`}
        </header>
        <div class="pdf-slide-body">
          ${f}
        </div>
        ${l.notes?`
          <footer class="pdf-slide-notes">
            <strong>演讲备注:</strong> ${te(l.notes)}
          </footer>
        `:""}
      </section>
    `}).join(`
`);return`<!DOCTYPE html>
<html lang="zh-CN">
<head>
  <meta charset="UTF-8">
  <title>${te(e)} - 高保真讲义</title>
  <style>
    ${uh({pageRatio:o,customInlineStyles:i==null?void 0:i.customInlineStyles})}
  </style>
</head>
<body>
  ${r}
</body>
</html>`}function ql(t,i){var n;if(typeof window>"u"||typeof document>"u")return!1;const e=fh(t,i);try{const r=document.createElement("iframe");r.style.position="fixed",r.style.right="0",r.style.bottom="0",r.style.width="0",r.style.height="0",r.style.border="none",r.style.visibility="hidden",document.body.appendChild(r);const l=(n=r.contentWindow)==null?void 0:n.document;if(l)return l.open(),l.write(e),l.close(),setTimeout(()=>{var s,a;try{(s=r.contentWindow)==null||s.focus(),(a=r.contentWindow)==null||a.print()}finally{setTimeout(()=>{r.remove()},2e3)}},350),!0}catch(r){console.warn("[pdf-exporter] iframe 打印模式异常，降级尝试 window.open:",r)}const o=window.open("","_blank");return o?(o.document.write(e),o.document.close(),o.focus(),setTimeout(()=>{o.print(),o.close()},350),!0):!1}const ph={class:"spm-slidev-preview-tab"},hh={class:"spm-slidev-tab__toolbar"},mh={class:"spm-slidev-tab__actions"},gh=["disabled"],vh={class:"spm-page-badge"},bh=["disabled"],yh=["aria-label"],kh=["aria-label"],wh=["src"],xh=he({__name:"SlidevPreviewTab",setup(t,{expose:i}){const e=Ge("plugin"),o=Ge("sandboxBridge",new _s),n=new Yp(o),r=new $u,l=ft("web-sandbox"),s=ft(3030),a=ft(null),c=ft(!1),d=ft(null),f=ft(1),g=ft(1),u=ft([]),k=ft(!1),h=ft(!1),y=ft(!1),b=ft("siyuan"),w=ft(""),S=ft(""),T=ft(""),x=ft(!1),_=ft(!1),I=ft(""),L=ft("/plugins/siyuan-slidev/slidev-client/index.html");let M=null,F=null,J=null,E=null,A=null,v=null,O=null;Sn(()=>{d.value&&(o.attach(d.value),r.nativeBridge.attach(d.value)),M=o.onSlideChanged((Y,rt)=>{f.value=Y,g.value=rt}),F=o.onBlockClicked((Y,rt)=>{f.value=rt,n.setActiveBlockId(Y),e&&typeof e.handleBlockClickedFromSlide=="function"?e.handleBlockClickedFromSlide(Y,rt):Si(Y,e==null?void 0:e.app)}),J=o.onOpenInEditor((Y,rt)=>{f.value=rt,n.setActiveBlockId(Y),Si(Y,e==null?void 0:e.app)}),E=r.nativeBridge.onPageChanged((Y,rt)=>{f.value=Y,g.value=rt}),A=o.onOpenPeekDrawer(async Y=>{const rt=Cs();if(Y.peekType==="siyuan"&&rt.enableWebServeJump){let vt=!1;if(O&&O.docId===Y.target)vt=!0;else if(O&&O.slides&&O.slides.some(B=>{var N;return(N=B.blocks)==null?void 0:N.some(p=>p.id===Y.target)}))vt=!1;else try{const B=await dn(`SELECT id, root_id, type FROM blocks WHERE id = '${Y.target}' LIMIT 1`);B&&B.length>0&&(vt=B[0].type==="d"||B[0].id===B[0].root_id)}catch(B){console.warn("[SlidevPreviewTab] detect block type failed:",B)}b.value="web",x.value=!0,S.value=jl(rt.webServeUrl,Y.target,{focus:!vt}),T.value=Y.title||`${vt?"思源文档":"思源块"}: ${Y.target.slice(0,8)}`,h.value=!0,o.freezeKeyboardNav(!0)}else b.value=Y.peekType,Y.peekType==="siyuan"?(w.value=Y.target,T.value=Y.title||`块速览: ${Y.target.slice(0,8)}`):(x.value=!0,S.value=Y.target,T.value=Y.title||Y.target),h.value=!0,o.freezeKeyboardNav(!0)}),v=o.onRequestToggleFullscreen(()=>{ot()}),typeof document<"u"&&document.addEventListener("fullscreenchange",at)}),gs(()=>{typeof document<"u"&&document.removeEventListener("fullscreenchange",at),A&&A(),v&&v(),M&&M(),F&&F(),J&&J(),E&&E(),o.detach(),n.destroy(),r.destroy()});async function z(){if(l.value==="web-sandbox"){if(!O){mt.showMessage("请先在主编辑区打开演示文档");return}mt.showMessage("正在探测本地 Node 环境并编排 Slidev Pro 进程...");const Y=await r.startProMode(O,Lo);if(!Y.success){mt.showMessage(`无法启动官方 Pro 模式：${Y.error}`);return}l.value="pro-cli",s.value=Y.port||3030,L.value=Y.url,d.value&&r.nativeBridge.attach(d.value),mt.showMessage(`🟢 已成功接入官方原生 Slidev 服务 (端口: ${s.value})`)}else r.stopProMode(),l.value="web-sandbox",L.value="/plugins/siyuan-slidev/slidev-client/index.html",d.value&&o.attach(d.value),mt.showMessage("已切回内置高保真沙箱")}function P(){_.value=!_.value,_.value?I.value=(O==null?void 0:O.docId)||"":(I.value="",V())}function K(){f.value>1&&(l.value==="pro-cli"?r.nativeBridge.navigateToPage(f.value-1):o.navigatePage(f.value-1))}function H(){f.value<g.value&&(l.value==="pro-cli"?r.nativeBridge.navigateToPage(f.value+1):o.navigatePage(f.value+1))}function et(Y){f.value=Y,l.value==="pro-cli"?r.nativeBridge.navigateToPage(Y):o.navigatePage(Y)}function V(){e&&typeof e.compileCurrentDocument=="function"?e.compileCurrentDocument():e!=null&&e.eventBus&&typeof e.eventBus.emit=="function"&&e.eventBus.emit("slidev:request-compile")}function G(){h.value=!1,o.freezeKeyboardNav(!1)}function lt(){G()}function at(){typeof document<"u"&&(c.value=!!document.fullscreenElement,o.postMessage("FULLSCREEN_CHANGED",{isFullscreen:c.value}))}function ot(){const Y=a.value||d.value;Y&&(document.fullscreenElement?document.exitFullscreen().then(()=>{o.postMessage("FULLSCREEN_CHANGED",{isFullscreen:!1})}).catch(()=>{}):Y.requestFullscreen().then(()=>{o.postMessage("FULLSCREEN_CHANGED",{isFullscreen:!0})}).catch(()=>{}))}function X(){window.open("/plugins/siyuan-slidev/slidev-client/presenter.html","SlidevPresenter","width=1200,height=800")}function pt(){if(!O){mt.showMessage("请先在主编辑区打开幻灯片文档");return}const Y=Vl(O);Kl("presentation.html",Y)&&mt.showMessage("已开始下载单文件离线 HTML 演示包")}function gt(){if(!O){mt.showMessage("请先在主编辑区打开幻灯片文档");return}ql(O)&&mt.showMessage("已唤起打印视窗，请在打印选项中选择「另存为 PDF」")}return i({updateDocument(Y,rt){_.value&&I.value&&rt&&rt!==I.value||(O=Y,_.value&&!I.value&&(I.value=Y.docId),u.value=Y.slides,g.value=Y.slides.length,n.setDocId(Y.docId),n.updateSlidesIndex(Y.slides),l.value==="pro-cli"?r.scaffolder.scaffold(Y,Lo).catch(()=>{}):o.updateSlides(Y.slides,Y.config,Y.fullMarkdown,Y.customThemeCss))},navigateToBlock(Y){n.onCursorFocusBlock(Y)},isPinned:_,pinnedDocId:I,engineMode:l,toggleEngineMode:z}),(Y,rt)=>(tt(),nt("div",ph,[m("div",hh,[rt[4]||(rt[4]=m("div",{class:"spm-slidev-tab__title"},[m("svg",{class:"spm-slidev-tab__icon","aria-hidden":"true"},[m("use",{"xlink:href":"#iconSlidev"})]),m("span",null,"Slidev 演示预览")],-1)),m("div",mh,[m("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s",disabled:f.value<=1,"aria-label":"上一页",onClick:K},[ut(yt,{name:"chevron-left"})],8,gh),m("span",vh,_t(f.value)+" / "+_t(g.value||1),1),m("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s",disabled:f.value>=g.value,"aria-label":"下一页",onClick:H},[ut(yt,{name:"chevron-right"})],8,bh),m("button",{class:$t(["spm-icon-btn b3-tooltips b3-tooltips__s",{"is-primary":_.value}]),"aria-label":_.value?"已锁定当前文档（点击解除）："+I.value:"点击锁定当前文档（不随主编辑区切换）",onClick:P},[ut(yt,{name:"pin"}),m("span",null,_t(_.value?"已锁定":"跟随"),1)],10,yh),m("button",{class:$t(["spm-icon-btn b3-tooltips b3-tooltips__s",{"is-primary":l.value==="pro-cli"}]),"aria-label":l.value==="pro-cli"?"当前：官方原生 Pro 模式 (localhost:"+s.value+")，点击切回沙箱":"当前：内置高保真沙箱，点击切换官方原生 Pro 模式",onClick:z},[ut(yt,{name:"step"}),m("span",null,_t(l.value==="pro-cli"?"Pro ("+s.value+")":"沙箱"),1)],10,kh),rt[3]||(rt[3]=m("span",{class:"spm-toolbar-divider"},null,-1)),m("button",{class:$t(["spm-icon-btn b3-tooltips b3-tooltips__s",{"is-primary":k.value}]),"aria-label":"切换幻灯片大纲抽屉",onClick:rt[0]||(rt[0]=vt=>k.value=!k.value)},[ut(yt,{name:"outline"})],2),m("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"双屏演讲者视图 (Presenter Mode ⌥M)",onClick:X},[ut(yt,{name:"presenter"})]),m("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"导出单文件 HTML 演示包",onClick:pt},[ut(yt,{name:"export-html"})]),m("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"导出 16:9 PDF 演示讲义",onClick:gt},[ut(yt,{name:"export-pdf"})]),m("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"重新编译并刷新",onClick:V},[ut(yt,{name:"refresh"})]),m("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"全屏放映",onClick:ot},[ut(yt,{name:"fullscreen"})])])]),m("div",{ref_key:"fullscreenContainerRef",ref:a,class:"spm-slidev-tab__viewport spm-slidev-fullscreen-container"},[m("iframe",{ref_key:"sandboxIframeRef",ref:d,class:"spm-slidev-tab__iframe",src:L.value,frameborder:"0",allow:"fullscreen; autoplay"},null,8,wh),ut(bp,{visible:h.value,"onUpdate:visible":rt[1]||(rt[1]=vt=>h.value=vt),"is-maximized":y.value,"onUpdate:isMaximized":rt[2]||(rt[2]=vt=>y.value=vt),title:T.value,onClose:G},{default:ol(()=>[b.value==="siyuan"&&w.value?(tt(),$e(Tp,{key:0,"block-id":w.value,title:T.value,plugin:ht(e),onExternalJump:lt},null,8,["block-id","title","plugin"])):Pt("",!0),x.value?_e((tt(),$e(Gp,{key:1,visible:h.value&&b.value==="web",url:S.value,title:T.value,onExternalJump:lt},null,8,["visible","url","title"])),[[Ll,b.value==="web"]]):Pt("",!0)]),_:1},8,["visible","is-maximized","title"])],512),k.value&&u.value.length>0?(tt(),$e(cp,{key:0,slides:u.value,"current-active-page":f.value,onNavigate:et,onRefresh:V},null,8,["slides","current-active-page"])):Pt("",!0)]))}}),_h=Be(xh,[["__scopeId","data-v-2622f6d8"]]),Sh={class:"spm-section spm-section--page"},Ch={class:"spm-section-header"},$h={class:"spm-card-control"},Ih={class:"spm-control-header"},Ah={class:"spm-control-title-group"},Th={class:"spm-control-title"},Eh={class:"spm-segmented-group"},Bh={class:"spm-card-control"},Mh={class:"spm-control-header"},Dh={class:"spm-control-title-group"},Lh={class:"spm-control-title"},Ph={class:"spm-quick-chips"},Oh=["onClick"],Rh=["value"],zh={key:0,class:"spm-card-control"},Nh={class:"spm-control-header"},Fh={class:"spm-control-title-group"},jh={class:"spm-control-title"},Hh={class:"spm-quick-chips"},Uh=["onClick"],Wh=["value"],Vh={class:"spm-card-control"},Kh={class:"spm-control-header"},qh={class:"spm-control-title-group"},Gh={class:"spm-control-title"},Zh={key:0,class:"spm-note-status-box"},Yh=["title"],Jh={class:"spm-action-grid",style:{"margin-top":"6px"}},Xh={key:1,class:"spm-note-empty-box"},Qh={class:"spm-card-control"},tm={class:"spm-action-grid"},em=he({__name:"PageInspectorSection",props:{pageLayout:{},pageTransition:{},pageBackground:{},pageSpacing:{},pageImage:{},pageNotes:{},pageIndex:{}},emits:["update:pageLayout","update:pageTransition","update:pageBackground","update:pageSpacing","update:pageImage","addNoteBlock","locateNoteBlock","generateNotes","insertDividerAfter","deleteDivider"],setup(t,{emit:i}){const e=t,o=St(()=>{if(!e.pageNotes)return"";const l=e.pageNotes.replace(/[\r\n]+/g," ").trim();return l.length>50?l.slice(0,50)+"...":l}),n=[{label:"默认",value:""},{label:"暗黑 #1e1e24",value:"#1e1e24"},{label:"极夜 #0f172a",value:"#0f172a"},{label:"极简白 #ffffff",value:"#ffffff"}],r=[{label:"默认封面",value:"https://cover.sli.dev"},{label:"清空配图",value:""}];return(l,s)=>(tt(),nt("div",Sh,[m("div",Ch,[m("span",null,"幻灯片页面设置"+_t(t.pageIndex?` (第 ${t.pageIndex} 页)`:""),1)]),ut(Fl,{"model-value":t.pageLayout,onChange:s[0]||(s[0]=a=>l.$emit("update:pageLayout",a))},null,8,["model-value"]),ut(Ss,{"model-value":t.pageTransition,onChange:s[1]||(s[1]=a=>l.$emit("update:pageTransition",a))},null,8,["model-value"]),m("div",$h,[m("div",Ih,[m("div",Ah,[m("div",Th,[ut(yt,{name:"ratio"}),s[16]||(s[16]=m("span",null,"页面间距 (Spacing)",-1))]),s[17]||(s[17]=m("span",{class:"spm-control-desc"},"覆盖本页内边距与顶部标题间距",-1))])]),m("div",Eh,[m("button",{class:$t(["spm-segmented-item",{active:!t.pageSpacing||t.pageSpacing==="inherit"}]),onClick:s[2]||(s[2]=a=>l.$emit("update:pageSpacing","inherit"))}," 继承全局 ",2),m("button",{class:$t(["spm-segmented-item",{active:t.pageSpacing==="compact"}]),onClick:s[3]||(s[3]=a=>l.$emit("update:pageSpacing","compact"))}," 紧凑 ",2),m("button",{class:$t(["spm-segmented-item",{active:t.pageSpacing==="normal"}]),onClick:s[4]||(s[4]=a=>l.$emit("update:pageSpacing","normal"))}," 标准 ",2),m("button",{class:$t(["spm-segmented-item",{active:t.pageSpacing==="loose"}]),onClick:s[5]||(s[5]=a=>l.$emit("update:pageSpacing","loose"))}," 宽松 ",2)])]),m("div",Bh,[m("div",Mh,[m("div",Dh,[m("div",Lh,[ut(yt,{name:"palette"}),s[18]||(s[18]=m("span",null,"页面背景 (Background)",-1))]),s[19]||(s[19]=m("span",{class:"spm-control-desc"},"设置当前页特定底色或壁纸",-1))])]),m("div",Ph,[(tt(),nt(Ut,null,ge(n,a=>m("button",{key:a.value,class:$t(["spm-chip",{active:t.pageBackground===a.value}]),onClick:c=>l.$emit("update:pageBackground",a.value)},_t(a.label),11,Oh)),64))]),m("input",{value:t.pageBackground,class:"spm-input",placeholder:"自定义颜色代码或资源路径",onInput:s[6]||(s[6]=a=>l.$emit("update:pageBackground",a.target.value)),onChange:s[7]||(s[7]=a=>l.$emit("update:pageBackground",a.target.value))},null,40,Rh)]),t.pageLayout==="image-right"||t.pageLayout==="image-left"||t.pageImage?(tt(),nt("div",zh,[m("div",Nh,[m("div",Fh,[m("div",jh,[ut(yt,{name:"image"}),s[20]||(s[20]=m("span",null,"页面图片 (Image)",-1))]),s[21]||(s[21]=m("span",{class:"spm-control-desc"},"图文分栏或页面专属配图 URL / 资源路径",-1))])]),m("div",Hh,[(tt(),nt(Ut,null,ge(r,a=>m("button",{key:a.value,class:$t(["spm-chip",{active:t.pageImage===a.value}]),onClick:c=>l.$emit("update:pageImage",a.value)},_t(a.label),11,Uh)),64))]),m("input",{value:t.pageImage,class:"spm-input",placeholder:"网络图片 URL (如 https://cover.sli.dev) 或 assets/...",onInput:s[8]||(s[8]=a=>l.$emit("update:pageImage",a.target.value)),onChange:s[9]||(s[9]=a=>l.$emit("update:pageImage",a.target.value))},null,40,Wh)])):Pt("",!0),m("div",Vh,[m("div",Kh,[m("div",qh,[m("div",Gh,[ut(yt,{name:"presenter"}),s[22]||(s[22]=m("span",null,"演讲者提词 (Notes)",-1))]),s[23]||(s[23]=m("span",{class:"spm-control-desc"},"正文备注块驱动 · 仅演讲者视图可见",-1))]),m("button",{class:"spm-btn-text b3-tooltips b3-tooltips__w","aria-label":"AI 自动生成本页讲稿提示块",onClick:s[10]||(s[10]=a=>l.$emit("generateNotes"))},[ut(yt,{name:"sparkles"}),s[24]||(s[24]=m("span",null,"AI 讲稿",-1))])]),t.pageNotes?(tt(),nt("div",Zh,[s[27]||(s[27]=m("div",{class:"spm-note-status-badge"},[m("span",{class:"spm-badge-dot"}),m("span",null,"已配置正文讲稿")],-1)),m("div",{class:"spm-note-preview-text",title:t.pageNotes},_t(o.value),9,Yh),m("div",Jh,[m("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"在正文编辑区定位并高亮此讲稿备注块",onClick:s[11]||(s[11]=a=>l.$emit("locateNoteBlock"))},[ut(yt,{name:"search"}),s[25]||(s[25]=m("span",null,"定位讲稿块",-1))]),m("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"在本页末尾追加新的讲稿提示块",onClick:s[12]||(s[12]=a=>l.$emit("addNoteBlock"))},[ut(yt,{name:"insert-below"}),s[26]||(s[26]=m("span",null,"追加讲稿块",-1))])])])):(tt(),nt("div",Xh,[s[29]||(s[29]=m("div",{class:"spm-note-empty-hint"},"本页暂无讲稿备注块",-1)),m("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s",style:{width:"100%","margin-top":"6px"},"aria-label":"在当前页末尾插入默认演讲备注提示块",onClick:s[13]||(s[13]=a=>l.$emit("addNoteBlock"))},[ut(yt,{name:"insert-below"}),s[28]||(s[28]=m("span",null,"添加讲稿备注块",-1))])]))]),m("div",Qh,[s[32]||(s[32]=m("div",{class:"spm-control-header"},[m("div",{class:"spm-control-title-group"},[m("span",{class:"spm-control-title"},"分页快捷操作")])],-1)),m("div",tm,[m("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"在此分页符之后插入新的空白分页",onClick:s[14]||(s[14]=a=>l.$emit("insertDividerAfter"))},[ut(yt,{name:"insert-below"}),s[30]||(s[30]=m("span",null,"插入新页",-1))]),m("button",{class:"spm-btn-action spm-btn-danger b3-tooltips b3-tooltips__s","aria-label":"彻底删除当前分页符（合并前后页面）",onClick:s[15]||(s[15]=a=>l.$emit("deleteDivider"))},[ut(yt,{name:"trash"}),s[31]||(s[31]=m("span",null,"删除此页",-1))])])])]))}}),im=Be(em,[["__scopeId","data-v-4f1fa626"]]),nm={class:"spm-section spm-section--block"},om={class:"spm-card-control"},sm={class:"spm-control-header"},rm={class:"spm-control-title-group"},lm={class:"spm-control-title"},am=["aria-label"],cm=["checked"],dm={key:0,class:"spm-card-control"},um={class:"spm-control-header"},fm={class:"spm-control-title-group"},pm={class:"spm-control-title"},hm={class:"spm-quick-chips"},mm={key:1,class:"spm-card-control"},gm={class:"spm-control-header"},vm={class:"spm-control-title-group"},bm={class:"spm-control-title"},ym={class:"spm-video-settings-grid",style:{display:"grid","grid-template-columns":"1fr 1fr",gap:"8px","margin-top":"8px"}},km={class:"spm-toggle-item",style:{display:"flex","align-items":"center","justify-content":"space-between",padding:"4px 6px",background:"rgba(125,125,125,0.06)","border-radius":"4px"}},wm=["aria-label"],xm=["checked"],_m={class:"spm-toggle-item",style:{display:"flex","align-items":"center","justify-content":"space-between",padding:"4px 6px",background:"rgba(125,125,125,0.06)","border-radius":"4px"}},Sm=["aria-label"],Cm=["checked"],$m={class:"spm-toggle-item",style:{display:"flex","align-items":"center","justify-content":"space-between",padding:"4px 6px",background:"rgba(125,125,125,0.06)","border-radius":"4px"}},Im=["aria-label"],Am=["checked"],Tm={class:"spm-toggle-item",style:{display:"flex","align-items":"center","justify-content":"space-between",padding:"4px 6px",background:"rgba(125,125,125,0.06)","border-radius":"4px"}},Em=["aria-label"],Bm=["checked"],Mm={class:"spm-card-control"},Dm={class:"spm-control-header"},Lm={class:"spm-control-title-group"},Pm={class:"spm-control-title"},Om=["aria-label"],Rm=["checked"],zm={key:0,class:"spm-quick-chips"},Nm=["onClick"],Fm={class:"spm-card-control"},jm={class:"spm-control-header"},Hm={class:"spm-control-title-group"},Um={class:"spm-control-title"},Wm=["aria-label"],Vm=["checked"],Km={key:0,class:"spm-quick-chips"},qm=["onClick"],Gm={key:1,class:"spm-motion-details",style:{display:"flex","flex-direction":"column",gap:"4px","margin-top":"4px"}},Zm={style:{display:"flex",gap:"8px","justify-content":"space-between","font-size":"11px",opacity:"0.8"}},Ym={style:{display:"flex",gap:"6px"}},Jm=["value"],Xm=["value"],Qm={key:2,class:"spm-card-control"},tg={class:"spm-control-header"},eg={class:"spm-control-title-group"},ig={class:"spm-control-title"},ng={class:"spm-control-desc"},og={class:"spm-segmented-group"},sg=["onClick"],rg={key:3,class:"spm-card-control"},lg={class:"spm-control-header"},ag={class:"spm-control-title-group"},cg={class:"spm-control-title"},dg={class:"spm-quick-chips"},ug=["onClick"],fg=["value"],pg={key:4,class:"spm-card-control"},hg={class:"spm-control-header"},mg={class:"spm-control-title-group"},gg={class:"spm-control-title"},vg={class:"spm-quick-chips"},bg=["onClick"],yg=["value"],kg={class:"spm-card-control"},wg={class:"spm-action-grid"},xg=["aria-label"],_g=he({__name:"BlockInspectorSection",props:{elemClick:{},elemMotion:{},elemSlot:{},elemShikiLines:{},elemMaxHeight:{},isCodeBlock:{type:Boolean},isImage:{type:Boolean},isVideo:{type:Boolean},videoAutoplay:{type:Boolean},videoLoop:{type:Boolean},videoMuted:{type:Boolean},videoControls:{type:Boolean},hasBlockAttrs:{type:Boolean},isNote:{type:Boolean},imageRole:{},currentSlideLayout:{}},emits:["toggleNote","toggleElemClick","update:elemClick","update:elemMotion","update:elemSlot","update:elemShikiLines","update:elemMaxHeight","insertDividerBefore","insertDividerAfter","setTwoColsContrast","clearBlockAttrs","update:imageRole","toggleVideoAutoplay","toggleVideoLoop","toggleVideoMuted","toggleVideoControls"],setup(t,{emit:i}){const e=t,o=St(()=>{const x=e.currentSlideLayout||"";return["col-1","col-2","col-3"].includes(e.elemSlot)?"three-cols-header":x}),n=St(()=>{const x=o.value;return["two-cols","two-cols-header","three-cols-header"].includes(x)}),r=St(()=>{const x=o.value;return x==="three-cols-header"?"三栏插槽归属 (Slot)":x==="two-cols-header"?"带表头双栏插槽 (Slot)":"多栏插槽归属 (Slot)"}),l=St(()=>{const x=o.value;return x==="three-cols-header"?"在 three-cols-header 版式中的内容块位置":x==="two-cols-header"?"在 two-cols-header 版式中的内容块位置":x==="two-cols"?"在 two-cols 双栏版式中的归属":"在当前分栏版式中的内容块位置"}),s=St(()=>{const x=o.value;return x==="three-cols-header"?[{value:"",label:"默认"},{value:"header",label:"表头"},{value:"col-1",label:"第 1 栏"},{value:"col-2",label:"第 2 栏"},{value:"col-3",label:"第 3 栏"}]:x==="two-cols-header"?[{value:"",label:"默认"},{value:"header",label:"表头"},{value:"left",label:"左栏"},{value:"right",label:"右栏"}]:x==="two-cols"?[{value:"",label:"默认 (左)"},{value:"right",label:"右栏"}]:[{value:"",label:"默认"},{value:"header",label:"表头"},{value:"left",label:"左栏"},{value:"right",label:"右栏"}]});function a(x){const _=e.elemSlot||"";return x?_===x||x==="col-1"&&_==="left"||x==="col-2"&&_==="center"||x==="col-3"&&_==="right"||x==="left"&&_==="col-1"||x==="right"&&(_==="col-2"||_==="col-3"):!_||_==="default"}const c=i,d=[{label:"上浮 (slide-up)",value:"slide-up"},{label:"淡入 (fade-in)",value:"fade-in"},{label:"下沉 (slide-down)",value:"slide-down"},{label:"左滑 (slide-left)",value:"slide-left"},{label:"右滑 (slide-right)",value:"slide-right"},{label:"缩放 (zoom-in)",value:"zoom-in"},{label:"弹性 (bounce)",value:"bounce"}],f=St(()=>{if(!e.elemMotion||e.elemMotion.trim()===""||e.elemMotion.trim()==="none")return null;try{const x=JSON.parse(e.elemMotion);if(typeof x=="object"&&x!==null)return{preset:x.preset||x.type||"slide-up",duration:typeof x.duration=="number"?x.duration:0,delay:typeof x.delay=="number"?x.delay:0}}catch{}return{preset:e.elemMotion.trim(),duration:0,delay:0}}),g=St(()=>!!f.value),u=St(()=>{var x;return((x=f.value)==null?void 0:x.preset)||"slide-up"}),k=St(()=>{var x;return((x=f.value)==null?void 0:x.duration)||0}),h=St(()=>{var x;return((x=f.value)==null?void 0:x.delay)||0});function y(){g.value?c("update:elemMotion",""):c("update:elemMotion","slide-up")}function b(x){T(x,k.value,h.value)}function w(x){T(u.value,x,h.value)}function S(x){T(u.value,k.value,x)}function T(x,_,I){if(!x||x==="none"){c("update:elemMotion","");return}if(!_&&!I){c("update:elemMotion",x);return}const L={preset:x};_>0&&(L.duration=_),I>0&&(L.delay=I),c("update:elemMotion",JSON.stringify(L))}return(x,_)=>(tt(),nt("div",nm,[_[53]||(_[53]=m("div",{class:"spm-section-header"},[m("span",null,"元素动效与排版")],-1)),m("div",om,[m("div",sm,[m("div",rm,[m("div",lm,[ut(yt,{name:"presenter"}),_[22]||(_[22]=m("span",null,"设为讲稿备注 (slidev-note)",-1))]),_[23]||(_[23]=m("span",{class:"spm-control-desc"},"作为当前页演讲提词，不在幻灯片中渲染",-1))]),m("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":t.isNote?"取消讲稿备注":"设为讲稿备注"},[m("input",{type:"checkbox",checked:!!t.isNote,onChange:_[0]||(_[0]=I=>x.$emit("toggleNote"))},null,40,cm),_[24]||(_[24]=m("span",{class:"spm-switch-slider"},null,-1))],8,am)])]),t.isImage||t.imageRole?(tt(),nt("div",dm,[m("div",um,[m("div",fm,[m("div",pm,[ut(yt,{name:"image"}),_[25]||(_[25]=m("span",null,"图片角色与分栏 (Image & Layout)",-1))]),_[26]||(_[26]=m("span",{class:"spm-control-desc"},"设为幻灯片背景图或图文分栏配图",-1))])]),m("div",hm,[m("button",{class:$t(["spm-chip",{active:!t.imageRole}]),onClick:_[1]||(_[1]=I=>x.$emit("update:imageRole",""))}," 普通内容 ",2),m("button",{class:$t(["spm-chip",{active:t.imageRole==="background"}]),onClick:_[2]||(_[2]=I=>x.$emit("update:imageRole","background"))}," 🖼️ 背景图 ",2),m("button",{class:$t(["spm-chip",{active:t.imageRole==="image-left"}]),onClick:_[3]||(_[3]=I=>x.$emit("update:imageRole","image-left"))}," 🎨 图左 ",2),m("button",{class:$t(["spm-chip",{active:t.imageRole==="image-right"}]),onClick:_[4]||(_[4]=I=>x.$emit("update:imageRole","image-right"))}," 🖼️ 图右 ",2)])])):Pt("",!0),t.isVideo?(tt(),nt("div",mm,[m("div",gm,[m("div",vm,[m("div",bm,[ut(yt,{name:"video"}),_[27]||(_[27]=m("span",null,"视频播放设置 (Video Playback)",-1))]),_[28]||(_[28]=m("span",{class:"spm-control-desc"},"配置播放器控制条、自动播放与循环",-1))])]),m("div",ym,[m("div",km,[_[30]||(_[30]=m("span",{style:{"font-size":"11px"}},"🎛️ 控制条",-1)),m("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":t.videoControls?"关闭控制条":"开启控制条"},[m("input",{type:"checkbox",checked:!!t.videoControls,onChange:_[5]||(_[5]=I=>x.$emit("toggleVideoControls"))},null,40,xm),_[29]||(_[29]=m("span",{class:"spm-switch-slider"},null,-1))],8,wm)]),m("div",_m,[_[32]||(_[32]=m("span",{style:{"font-size":"11px"}},"▶️ 自动播放",-1)),m("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":t.videoAutoplay?"关闭自动播放":"开启自动播放"},[m("input",{type:"checkbox",checked:!!t.videoAutoplay,onChange:_[6]||(_[6]=I=>x.$emit("toggleVideoAutoplay"))},null,40,Cm),_[31]||(_[31]=m("span",{class:"spm-switch-slider"},null,-1))],8,Sm)]),m("div",$m,[_[34]||(_[34]=m("span",{style:{"font-size":"11px"}},"🔁 循环播放",-1)),m("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":t.videoLoop?"关闭循环播放":"开启循环播放"},[m("input",{type:"checkbox",checked:!!t.videoLoop,onChange:_[7]||(_[7]=I=>x.$emit("toggleVideoLoop"))},null,40,Am),_[33]||(_[33]=m("span",{class:"spm-switch-slider"},null,-1))],8,Im)]),m("div",Tm,[_[36]||(_[36]=m("span",{style:{"font-size":"11px"}},"🔇 静音播放",-1)),m("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":t.videoMuted?"关闭静音":"开启静音"},[m("input",{type:"checkbox",checked:!!t.videoMuted,onChange:_[8]||(_[8]=I=>x.$emit("toggleVideoMuted"))},null,40,Bm),_[35]||(_[35]=m("span",{class:"spm-switch-slider"},null,-1))],8,Em)])])])):Pt("",!0),m("div",Mm,[m("div",Dm,[m("div",Lm,[m("div",Pm,[ut(yt,{name:"step"}),_[37]||(_[37]=m("span",null,"逐步呈现 (v-click)",-1))]),_[38]||(_[38]=m("span",{class:"spm-control-desc"},"放映时按步长逐个呈现",-1))]),m("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":t.elemClick?"关闭逐步呈现":"开启逐步呈现 (+1)"},[m("input",{type:"checkbox",checked:!!t.elemClick,onChange:_[9]||(_[9]=I=>x.$emit("toggleElemClick"))},null,40,Rm),_[39]||(_[39]=m("span",{class:"spm-switch-slider"},null,-1))],8,Om)]),t.elemClick?(tt(),nt("div",zm,[(tt(),nt(Ut,null,ge(["+1","1","2","hide"],I=>m("button",{key:I,class:$t(["spm-chip",{active:t.elemClick===I}]),onClick:L=>x.$emit("update:elemClick",I)},_t(I==="+1"?"顺延 (+1)":I==="hide"?"隐藏 (hide)":"第 "+I+" 步"),11,Nm)),64))])):Pt("",!0)]),m("div",Fm,[m("div",jm,[m("div",Hm,[m("div",Um,[ut(yt,{name:"motion"}),_[40]||(_[40]=m("span",null,"入场微动效 (v-motion)",-1))]),_[41]||(_[41]=m("span",{class:"spm-control-desc"},"为当前块添加平滑位移与渐入动画",-1))]),m("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":g.value?"关闭微动效":"开启微动效 (slide-up)"},[m("input",{type:"checkbox",checked:g.value,onChange:y},null,40,Vm),_[42]||(_[42]=m("span",{class:"spm-switch-slider"},null,-1))],8,Wm)]),g.value?(tt(),nt("div",Km,[(tt(),nt(Ut,null,ge(d,I=>m("button",{key:I.value,class:$t(["spm-chip",{active:u.value===I.value}]),onClick:L=>b(I.value)},_t(I.label),11,qm)),64))])):Pt("",!0),g.value?(tt(),nt("div",Gm,[m("div",Zm,[m("span",null,"时长: "+_t(k.value?k.value+"ms":"默认 (450ms)"),1),m("span",null,"延迟: "+_t(h.value?h.value+"ms":"0ms"),1)]),m("div",Ym,[m("select",{class:"spm-select",style:{flex:"1"},value:k.value,onChange:_[10]||(_[10]=I=>w(Number(I.target.value)))},[..._[43]||(_[43]=[m("option",{value:0},"默认耗时",-1),m("option",{value:200},"极速 (200ms)",-1),m("option",{value:350},"较快 (350ms)",-1),m("option",{value:500},"平滑 (500ms)",-1),m("option",{value:800},"缓慢 (800ms)",-1)])],40,Jm),m("select",{class:"spm-select",style:{flex:"1"},value:h.value,onChange:_[11]||(_[11]=I=>S(Number(I.target.value)))},[..._[44]||(_[44]=[m("option",{value:0},"无延迟",-1),m("option",{value:150},"延迟 150ms",-1),m("option",{value:300},"延迟 300ms",-1),m("option",{value:500},"延迟 500ms",-1)])],40,Xm)])])):Pt("",!0)]),n.value||t.elemSlot?(tt(),nt("div",Qm,[m("div",tg,[m("div",eg,[m("div",ig,[ut(yt,{name:"columns"}),m("span",null,_t(r.value),1)]),m("span",ng,_t(l.value),1)])]),m("div",og,[(tt(!0),nt(Ut,null,ge(s.value,I=>(tt(),nt("button",{key:I.value,class:$t(["spm-segmented-item",{active:a(I.value)}]),onClick:L=>x.$emit("update:elemSlot",I.value)},_t(I.label),11,sg))),128))])])):Pt("",!0),t.isCodeBlock?(tt(),nt("div",rg,[m("div",lg,[m("div",ag,[m("div",cg,[ut(yt,{name:"code"}),_[45]||(_[45]=m("span",null,"代码逐行聚光 (Shiki)",-1))]),_[46]||(_[46]=m("span",{class:"spm-control-desc"},"翻页时动态聚光高亮特定行",-1))])]),m("div",dg,[(tt(),nt(Ut,null,ge(["1-3","all","1|2|3","2-5"],I=>m("button",{key:I,class:$t(["spm-chip",{active:t.elemShikiLines===I}]),onClick:L=>x.$emit("update:elemShikiLines",I)},_t(I),11,ug)),64)),t.elemShikiLines?(tt(),nt("button",{key:0,class:"spm-chip spm-chip-clear",onClick:_[12]||(_[12]=I=>x.$emit("update:elemShikiLines",""))}," 清空 ")):Pt("",!0)]),m("input",{value:t.elemShikiLines,class:"spm-input",placeholder:"自定义高亮区间，如 1-3|5|all",onInput:_[13]||(_[13]=I=>x.$emit("update:elemShikiLines",I.target.value)),onChange:_[14]||(_[14]=I=>x.$emit("update:elemShikiLines",I.target.value))},null,40,fg)])):Pt("",!0),t.isCodeBlock?(tt(),nt("div",pg,[m("div",hg,[m("div",mg,[m("div",gg,[ut(yt,{name:"code"}),_[47]||(_[47]=m("span",null,"代码块限高 (Max Height)",-1))]),_[48]||(_[48]=m("span",{class:"spm-control-desc"},"超出限高自动竖向滚动，弱提示滚动条",-1))])]),m("div",vg,[(tt(),nt(Ut,null,ge(["240px","320px","400px","50vh"],I=>m("button",{key:I,class:$t(["spm-chip",{active:t.elemMaxHeight===I}]),onClick:L=>x.$emit("update:elemMaxHeight",I)},_t(I),11,bg)),64)),t.elemMaxHeight?(tt(),nt("button",{key:0,class:"spm-chip spm-chip-clear",onClick:_[15]||(_[15]=I=>x.$emit("update:elemMaxHeight",""))}," 自适应 ")):Pt("",!0)]),m("input",{value:t.elemMaxHeight,class:"spm-input",placeholder:"自适应高度，或输入 350px、50vh",onInput:_[16]||(_[16]=I=>x.$emit("update:elemMaxHeight",I.target.value)),onChange:_[17]||(_[17]=I=>x.$emit("update:elemMaxHeight",I.target.value))},null,40,yg)])):Pt("",!0),m("div",kg,[_[52]||(_[52]=m("div",{class:"spm-control-header"},[m("div",{class:"spm-control-title-group"},[m("span",{class:"spm-control-title"},"快捷操作")])],-1)),m("div",wg,[m("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"在当前块上方插入幻灯片分页线 (---)",onClick:_[18]||(_[18]=I=>x.$emit("insertDividerBefore"))},[ut(yt,{name:"insert-above"}),_[49]||(_[49]=m("span",null,"上方分页",-1))]),m("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"在当前块下方插入幻灯片分页线 (---)",onClick:_[19]||(_[19]=I=>x.$emit("insertDividerAfter"))},[ut(yt,{name:"insert-below"}),_[50]||(_[50]=m("span",null,"下方分页",-1))]),m("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":o.value==="three-cols-header"?"将当前块属性设为三栏第1栏归属 (slot: col-1)":"将当前块属性设为双栏左侧归属 (slot: left)",onClick:_[20]||(_[20]=I=>x.$emit("setTwoColsContrast"))},[ut(yt,{name:"columns"}),m("span",null,_t(o.value==="three-cols-header"?"设为第1栏":"设为双栏"),1)],8,xg),t.hasBlockAttrs?(tt(),nt("button",{key:0,class:"spm-btn-action spm-btn-danger b3-tooltips b3-tooltips__s","aria-label":"一键移除本块所有 custom-slidev 属性",onClick:_[21]||(_[21]=I=>x.$emit("clearBlockAttrs"))},[ut(yt,{name:"broom"}),_[51]||(_[51]=m("span",null,"清除属性",-1))])):Pt("",!0)])])]))}}),Sg={class:"spm-section spm-section--doc"},Cg={class:"spm-card-control"},$g={class:"spm-control-header"},Ig={class:"spm-control-title-group"},Ag={class:"spm-control-title"},Tg={class:"spm-segmented-group"},Eg=["aria-label","onClick"],Bg={class:"spm-card-control"},Mg={class:"spm-control-header"},Dg={class:"spm-control-title-group"},Lg={class:"spm-control-title"},Pg={class:"spm-segmented-group"},Og={class:"spm-card-control"},Rg={class:"spm-control-header"},zg={class:"spm-control-title-group"},Ng={class:"spm-control-title"},Fg={class:"spm-segmented-group"},jg={class:"spm-card-control"},Hg={class:"spm-control-header"},Ug={class:"spm-control-title-group"},Wg={class:"spm-control-title"},Vg={class:"spm-card-control"},Kg={class:"spm-control-header"},qg={class:"spm-control-title-group"},Gg={class:"spm-control-title"},Zg=["aria-label"],Yg=["checked"],Jg={key:0,class:"spm-control-body",style:{"margin-top":"8px"}},Xg=["value"],Qg={class:"spm-card-control"},tv={class:"spm-action-grid"},ev=he({__name:"DocInspectorSection",props:{docTheme:{},docAspectRatio:{},docDefaultTransition:{},docSpacing:{}},emits:["update:docTheme","update:docAspectRatio","update:docDefaultTransition","update:docSpacing","openBottomPreview","openPresenter","aiAutoSplit","exportHtml","exportPdf"],setup(t){const i=Ge("plugin"),e=ki,o=[{value:"default",label:"默认 default",desc:"官方默认科技风：现代无衬线排版与清新代码语法高亮，通用汇报与技术分享首选"},{value:"seriph",label:"优雅 seriph",desc:"典雅学术衬线风：书卷学术质感、衬线字体典雅庄重，适合学术论文、人文讲座与深度阅读"},{value:"apple-basic",label:"极简 apple",desc:"苹果发布会极简风：大字号、高对比度与极致留白，适合产品发布、方案演讲与纯粹视觉呈现"}];function n(s){Fi({enableWebServeJump:s}),i&&typeof i.saveGlobalSettings=="function"&&i.saveGlobalSettings({enableWebServeJump:s})}function r(s){Fi({webServeUrl:s})}function l(s){Fi({webServeUrl:s}),i&&typeof i.saveGlobalSettings=="function"&&i.saveGlobalSettings({webServeUrl:s})}return(s,a)=>(tt(),nt("div",Sg,[a[35]||(a[35]=m("div",{class:"spm-section-header"},[m("span",null,"全局演示配置")],-1)),m("div",Cg,[m("div",$g,[m("div",Ig,[m("div",Ag,[ut(yt,{name:"palette"}),a[17]||(a[17]=m("span",null,"幻灯片主题 (Theme)",-1))]),a[18]||(a[18]=m("span",{class:"spm-control-desc"},"全局 Slidev 视觉设计范式",-1))])]),m("div",Tg,[(tt(),nt(Ut,null,ge(o,c=>m("button",{key:c.value,class:$t(["spm-segmented-item b3-tooltips b3-tooltips__s",{active:t.docTheme===c.value}]),"aria-label":c.desc,onClick:d=>s.$emit("update:docTheme",c.value)},_t(c.label),11,Eg)),64))])]),m("div",Bg,[m("div",Mg,[m("div",Dg,[m("div",Lg,[ut(yt,{name:"ratio"}),a[19]||(a[19]=m("span",null,"画幅比例 (Aspect Ratio)",-1))]),a[20]||(a[20]=m("span",{class:"spm-control-desc"},"演讲屏幕投影宽高比",-1))])]),m("div",Pg,[m("button",{class:$t(["spm-segmented-item",{active:t.docAspectRatio==="16/9"}]),onClick:a[0]||(a[0]=c=>s.$emit("update:docAspectRatio","16/9"))}," 16 : 9 (宽屏) ",2),m("button",{class:$t(["spm-segmented-item",{active:t.docAspectRatio==="4/3"}]),onClick:a[1]||(a[1]=c=>s.$emit("update:docAspectRatio","4/3"))}," 4 : 3 (标屏) ",2),m("button",{class:$t(["spm-segmented-item",{active:t.docAspectRatio==="16/10"}]),onClick:a[2]||(a[2]=c=>s.$emit("update:docAspectRatio","16/10"))}," 16 : 10 ",2)])]),m("div",Og,[m("div",Rg,[m("div",zg,[m("div",Ng,[ut(yt,{name:"ratio"}),a[21]||(a[21]=m("span",null,"间距风格 (Spacing)",-1))]),a[22]||(a[22]=m("span",{class:"spm-control-desc"},"内边距与顶部标题下边距预设",-1))])]),m("div",Fg,[m("button",{class:$t(["spm-segmented-item b3-tooltips b3-tooltips__s",{active:(t.docSpacing||"normal")==="compact"}]),"aria-label":"紧凑排版：上下 20px / 左右 36px，释放垂直空间，适配图文分栏",onClick:a[3]||(a[3]=c=>s.$emit("update:docSpacing","compact"))}," 紧凑 (Compact) ",2),m("button",{class:$t(["spm-segmented-item b3-tooltips b3-tooltips__s",{active:(t.docSpacing||"normal")==="normal"}]),"aria-label":"标准排版：上下 32px / 左右 48px，协调美观（推荐默认）",onClick:a[4]||(a[4]=c=>s.$emit("update:docSpacing","normal"))}," 标准 (Normal) ",2),m("button",{class:$t(["spm-segmented-item b3-tooltips b3-tooltips__s",{active:(t.docSpacing||"normal")==="loose"}]),"aria-label":"宽松排版：上下 48px / 左右 56px，大留白适合极简大字",onClick:a[5]||(a[5]=c=>s.$emit("update:docSpacing","loose"))}," 宽松 (Loose) ",2)])]),m("div",jg,[m("div",Hg,[m("div",Ug,[m("div",Wg,[ut(yt,{name:"transition"}),a[23]||(a[23]=m("span",null,"全局默认转场",-1))]),a[24]||(a[24]=m("span",{class:"spm-control-desc"},"页面切换过渡动效（未单设转场的页面将继承此动效）",-1))])]),ut(Ss,{"model-value":t.docDefaultTransition,"hide-header":!0,onChange:a[6]||(a[6]=c=>s.$emit("update:docDefaultTransition",c))},null,8,["model-value"])]),m("div",Vg,[m("div",Kg,[m("div",qg,[m("div",Gg,[ut(yt,{name:"external-link"}),a[25]||(a[25]=m("span",null,"本地网络伺服预览 (Web Serve)",-1))]),a[26]||(a[26]=m("span",{class:"spm-control-desc"},"点击文档/块链接以 Webview 抽屉呈现，支持外跳",-1))]),m("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":ht(e).enableWebServeJump?"关闭本地网络伺服预览":"开启本地网络伺服预览"},[m("input",{type:"checkbox",checked:ht(e).enableWebServeJump,onChange:a[7]||(a[7]=c=>n(c.target.checked))},null,40,Yg),a[27]||(a[27]=m("span",{class:"spm-switch-slider"},null,-1))],8,Zg)]),ht(e).enableWebServeJump?(tt(),nt("div",Jg,[m("input",{value:ht(e).webServeUrl,class:"spm-input",placeholder:"http://127.0.0.1:6806",spellcheck:"false",onKeydown:a[8]||(a[8]=Ce(()=>{},["stop"])),onKeyup:a[9]||(a[9]=Ce(()=>{},["stop"])),onInput:a[10]||(a[10]=c=>r(c.target.value)),onChange:a[11]||(a[11]=c=>l(c.target.value))},null,40,Xg),a[28]||(a[28]=m("span",{class:"spm-control-desc",style:{display:"block","margin-top":"4px","font-size":"11px",opacity:"0.8"}}," 默认伺服地址为 http://127.0.0.1:6806。开启后点击块链接将在 Webview 抽屉中打开，点击抽屉顶部『外跳』可在外部浏览器打开 ",-1))])):Pt("",!0)]),m("div",Qg,[a[34]||(a[34]=m("div",{class:"spm-control-header"},[m("div",{class:"spm-control-title-group"},[m("span",{class:"spm-control-title"},"演示全局操作")])],-1)),m("div",tv,[m("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"在当前文档下方开启分屏同步预览 (Alt+P)",onClick:a[12]||(a[12]=c=>s.$emit("openBottomPreview"))},[ut(yt,{name:"split-preview"}),a[29]||(a[29]=m("span",null,"分屏预览",-1))]),m("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"打开双屏演讲者控制台视窗 (Alt+M)",onClick:a[13]||(a[13]=c=>s.$emit("openPresenter"))},[ut(yt,{name:"presenter"}),a[30]||(a[30]=m("span",null,"演讲者视图",-1))]),m("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"智能分析长文本结构并给出大纲分页插入建议",onClick:a[14]||(a[14]=c=>s.$emit("aiAutoSplit"))},[ut(yt,{name:"sparkles"}),a[31]||(a[31]=m("span",null,"AI 智能分页",-1))]),m("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"打包导出离线单文件 HTML 幻灯片",onClick:a[15]||(a[15]=c=>s.$emit("exportHtml"))},[ut(yt,{name:"export-html"}),a[32]||(a[32]=m("span",null,"导出 HTML",-1))]),m("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"打印生成 16:9 高清演示 PDF 讲义",onClick:a[16]||(a[16]=c=>s.$emit("exportPdf"))},[ut(yt,{name:"export-pdf"}),a[33]||(a[33]=m("span",null,"导出 PDF",-1))])])])]))}});var Ln=typeof globalThis<"u"?globalThis:typeof window<"u"?window:typeof global<"u"?global:typeof self<"u"?self:{};function iv(t){return t&&t.__esModule&&Object.prototype.hasOwnProperty.call(t,"default")?t.default:t}function Pn(t){throw new Error('Could not dynamically require "'+t+'". Please configure the dynamicRequireTargets or/and ignoreDynamicRequires option of @rollup/plugin-commonjs appropriately for this require call to work.')}var Mo={exports:{}};/*!

JSZip v3.10.1 - A JavaScript class for generating and reading zip files
<http://stuartk.com/jszip>

(c) 2009-2016 Stuart Knightley <stuart [at] stuartk.com>
Dual licenced under the MIT license or GPLv3. See https://raw.github.com/Stuk/jszip/main/LICENSE.markdown.

JSZip uses the library pako released under the MIT license :
https://github.com/nodeca/pako/blob/main/LICENSE
*/var pr;function nv(){return pr||(pr=1,(function(t,i){(function(e){t.exports=e()})(function(){return(function e(o,n,r){function l(c,d){if(!n[c]){if(!o[c]){var f=typeof Pn=="function"&&Pn;if(!d&&f)return f(c,!0);if(s)return s(c,!0);var g=new Error("Cannot find module '"+c+"'");throw g.code="MODULE_NOT_FOUND",g}var u=n[c]={exports:{}};o[c][0].call(u.exports,function(k){var h=o[c][1][k];return l(h||k)},u,u.exports,e,o,n,r)}return n[c].exports}for(var s=typeof Pn=="function"&&Pn,a=0;a<r.length;a++)l(r[a]);return l})({1:[function(e,o,n){var r=e("./utils"),l=e("./support"),s="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";n.encode=function(a){for(var c,d,f,g,u,k,h,y=[],b=0,w=a.length,S=w,T=r.getTypeOf(a)!=="string";b<a.length;)S=w-b,f=T?(c=a[b++],d=b<w?a[b++]:0,b<w?a[b++]:0):(c=a.charCodeAt(b++),d=b<w?a.charCodeAt(b++):0,b<w?a.charCodeAt(b++):0),g=c>>2,u=(3&c)<<4|d>>4,k=1<S?(15&d)<<2|f>>6:64,h=2<S?63&f:64,y.push(s.charAt(g)+s.charAt(u)+s.charAt(k)+s.charAt(h));return y.join("")},n.decode=function(a){var c,d,f,g,u,k,h=0,y=0,b="data:";if(a.substr(0,b.length)===b)throw new Error("Invalid base64 input, it looks like a data url.");var w,S=3*(a=a.replace(/[^A-Za-z0-9+/=]/g,"")).length/4;if(a.charAt(a.length-1)===s.charAt(64)&&S--,a.charAt(a.length-2)===s.charAt(64)&&S--,S%1!=0)throw new Error("Invalid base64 input, bad content length.");for(w=l.uint8array?new Uint8Array(0|S):new Array(0|S);h<a.length;)c=s.indexOf(a.charAt(h++))<<2|(g=s.indexOf(a.charAt(h++)))>>4,d=(15&g)<<4|(u=s.indexOf(a.charAt(h++)))>>2,f=(3&u)<<6|(k=s.indexOf(a.charAt(h++))),w[y++]=c,u!==64&&(w[y++]=d),k!==64&&(w[y++]=f);return w}},{"./support":30,"./utils":32}],2:[function(e,o,n){var r=e("./external"),l=e("./stream/DataWorker"),s=e("./stream/Crc32Probe"),a=e("./stream/DataLengthProbe");function c(d,f,g,u,k){this.compressedSize=d,this.uncompressedSize=f,this.crc32=g,this.compression=u,this.compressedContent=k}c.prototype={getContentWorker:function(){var d=new l(r.Promise.resolve(this.compressedContent)).pipe(this.compression.uncompressWorker()).pipe(new a("data_length")),f=this;return d.on("end",function(){if(this.streamInfo.data_length!==f.uncompressedSize)throw new Error("Bug : uncompressed data size mismatch")}),d},getCompressedWorker:function(){return new l(r.Promise.resolve(this.compressedContent)).withStreamInfo("compressedSize",this.compressedSize).withStreamInfo("uncompressedSize",this.uncompressedSize).withStreamInfo("crc32",this.crc32).withStreamInfo("compression",this.compression)}},c.createWorkerFrom=function(d,f,g){return d.pipe(new s).pipe(new a("uncompressedSize")).pipe(f.compressWorker(g)).pipe(new a("compressedSize")).withStreamInfo("compression",f)},o.exports=c},{"./external":6,"./stream/Crc32Probe":25,"./stream/DataLengthProbe":26,"./stream/DataWorker":27}],3:[function(e,o,n){var r=e("./stream/GenericWorker");n.STORE={magic:"\0\0",compressWorker:function(){return new r("STORE compression")},uncompressWorker:function(){return new r("STORE decompression")}},n.DEFLATE=e("./flate")},{"./flate":7,"./stream/GenericWorker":28}],4:[function(e,o,n){var r=e("./utils"),l=(function(){for(var s,a=[],c=0;c<256;c++){s=c;for(var d=0;d<8;d++)s=1&s?3988292384^s>>>1:s>>>1;a[c]=s}return a})();o.exports=function(s,a){return s!==void 0&&s.length?r.getTypeOf(s)!=="string"?(function(c,d,f,g){var u=l,k=g+f;c^=-1;for(var h=g;h<k;h++)c=c>>>8^u[255&(c^d[h])];return-1^c})(0|a,s,s.length,0):(function(c,d,f,g){var u=l,k=g+f;c^=-1;for(var h=g;h<k;h++)c=c>>>8^u[255&(c^d.charCodeAt(h))];return-1^c})(0|a,s,s.length,0):0}},{"./utils":32}],5:[function(e,o,n){n.base64=!1,n.binary=!1,n.dir=!1,n.createFolders=!0,n.date=null,n.compression=null,n.compressionOptions=null,n.comment=null,n.unixPermissions=null,n.dosPermissions=null},{}],6:[function(e,o,n){var r=null;r=typeof Promise<"u"?Promise:e("lie"),o.exports={Promise:r}},{lie:37}],7:[function(e,o,n){var r=typeof Uint8Array<"u"&&typeof Uint16Array<"u"&&typeof Uint32Array<"u",l=e("pako"),s=e("./utils"),a=e("./stream/GenericWorker"),c=r?"uint8array":"array";function d(f,g){a.call(this,"FlateWorker/"+f),this._pako=null,this._pakoAction=f,this._pakoOptions=g,this.meta={}}n.magic="\b\0",s.inherits(d,a),d.prototype.processChunk=function(f){this.meta=f.meta,this._pako===null&&this._createPako(),this._pako.push(s.transformTo(c,f.data),!1)},d.prototype.flush=function(){a.prototype.flush.call(this),this._pako===null&&this._createPako(),this._pako.push([],!0)},d.prototype.cleanUp=function(){a.prototype.cleanUp.call(this),this._pako=null},d.prototype._createPako=function(){this._pako=new l[this._pakoAction]({raw:!0,level:this._pakoOptions.level||-1});var f=this;this._pako.onData=function(g){f.push({data:g,meta:f.meta})}},n.compressWorker=function(f){return new d("Deflate",f)},n.uncompressWorker=function(){return new d("Inflate",{})}},{"./stream/GenericWorker":28,"./utils":32,pako:38}],8:[function(e,o,n){function r(u,k){var h,y="";for(h=0;h<k;h++)y+=String.fromCharCode(255&u),u>>>=8;return y}function l(u,k,h,y,b,w){var S,T,x=u.file,_=u.compression,I=w!==c.utf8encode,L=s.transformTo("string",w(x.name)),M=s.transformTo("string",c.utf8encode(x.name)),F=x.comment,J=s.transformTo("string",w(F)),E=s.transformTo("string",c.utf8encode(F)),A=M.length!==x.name.length,v=E.length!==F.length,O="",z="",P="",K=x.dir,H=x.date,et={crc32:0,compressedSize:0,uncompressedSize:0};k&&!h||(et.crc32=u.crc32,et.compressedSize=u.compressedSize,et.uncompressedSize=u.uncompressedSize);var V=0;k&&(V|=8),I||!A&&!v||(V|=2048);var G=0,lt=0;K&&(G|=16),b==="UNIX"?(lt=798,G|=(function(ot,X){var pt=ot;return ot||(pt=X?16893:33204),(65535&pt)<<16})(x.unixPermissions,K)):(lt=20,G|=(function(ot){return 63&(ot||0)})(x.dosPermissions)),S=H.getUTCHours(),S<<=6,S|=H.getUTCMinutes(),S<<=5,S|=H.getUTCSeconds()/2,T=H.getUTCFullYear()-1980,T<<=4,T|=H.getUTCMonth()+1,T<<=5,T|=H.getUTCDate(),A&&(z=r(1,1)+r(d(L),4)+M,O+="up"+r(z.length,2)+z),v&&(P=r(1,1)+r(d(J),4)+E,O+="uc"+r(P.length,2)+P);var at="";return at+=`
\0`,at+=r(V,2),at+=_.magic,at+=r(S,2),at+=r(T,2),at+=r(et.crc32,4),at+=r(et.compressedSize,4),at+=r(et.uncompressedSize,4),at+=r(L.length,2),at+=r(O.length,2),{fileRecord:f.LOCAL_FILE_HEADER+at+L+O,dirRecord:f.CENTRAL_FILE_HEADER+r(lt,2)+at+r(J.length,2)+"\0\0\0\0"+r(G,4)+r(y,4)+L+O+J}}var s=e("../utils"),a=e("../stream/GenericWorker"),c=e("../utf8"),d=e("../crc32"),f=e("../signature");function g(u,k,h,y){a.call(this,"ZipFileWorker"),this.bytesWritten=0,this.zipComment=k,this.zipPlatform=h,this.encodeFileName=y,this.streamFiles=u,this.accumulate=!1,this.contentBuffer=[],this.dirRecords=[],this.currentSourceOffset=0,this.entriesCount=0,this.currentFile=null,this._sources=[]}s.inherits(g,a),g.prototype.push=function(u){var k=u.meta.percent||0,h=this.entriesCount,y=this._sources.length;this.accumulate?this.contentBuffer.push(u):(this.bytesWritten+=u.data.length,a.prototype.push.call(this,{data:u.data,meta:{currentFile:this.currentFile,percent:h?(k+100*(h-y-1))/h:100}}))},g.prototype.openedSource=function(u){this.currentSourceOffset=this.bytesWritten,this.currentFile=u.file.name;var k=this.streamFiles&&!u.file.dir;if(k){var h=l(u,k,!1,this.currentSourceOffset,this.zipPlatform,this.encodeFileName);this.push({data:h.fileRecord,meta:{percent:0}})}else this.accumulate=!0},g.prototype.closedSource=function(u){this.accumulate=!1;var k=this.streamFiles&&!u.file.dir,h=l(u,k,!0,this.currentSourceOffset,this.zipPlatform,this.encodeFileName);if(this.dirRecords.push(h.dirRecord),k)this.push({data:(function(y){return f.DATA_DESCRIPTOR+r(y.crc32,4)+r(y.compressedSize,4)+r(y.uncompressedSize,4)})(u),meta:{percent:100}});else for(this.push({data:h.fileRecord,meta:{percent:0}});this.contentBuffer.length;)this.push(this.contentBuffer.shift());this.currentFile=null},g.prototype.flush=function(){for(var u=this.bytesWritten,k=0;k<this.dirRecords.length;k++)this.push({data:this.dirRecords[k],meta:{percent:100}});var h=this.bytesWritten-u,y=(function(b,w,S,T,x){var _=s.transformTo("string",x(T));return f.CENTRAL_DIRECTORY_END+"\0\0\0\0"+r(b,2)+r(b,2)+r(w,4)+r(S,4)+r(_.length,2)+_})(this.dirRecords.length,h,u,this.zipComment,this.encodeFileName);this.push({data:y,meta:{percent:100}})},g.prototype.prepareNextSource=function(){this.previous=this._sources.shift(),this.openedSource(this.previous.streamInfo),this.isPaused?this.previous.pause():this.previous.resume()},g.prototype.registerPrevious=function(u){this._sources.push(u);var k=this;return u.on("data",function(h){k.processChunk(h)}),u.on("end",function(){k.closedSource(k.previous.streamInfo),k._sources.length?k.prepareNextSource():k.end()}),u.on("error",function(h){k.error(h)}),this},g.prototype.resume=function(){return!!a.prototype.resume.call(this)&&(!this.previous&&this._sources.length?(this.prepareNextSource(),!0):this.previous||this._sources.length||this.generatedError?void 0:(this.end(),!0))},g.prototype.error=function(u){var k=this._sources;if(!a.prototype.error.call(this,u))return!1;for(var h=0;h<k.length;h++)try{k[h].error(u)}catch{}return!0},g.prototype.lock=function(){a.prototype.lock.call(this);for(var u=this._sources,k=0;k<u.length;k++)u[k].lock()},o.exports=g},{"../crc32":4,"../signature":23,"../stream/GenericWorker":28,"../utf8":31,"../utils":32}],9:[function(e,o,n){var r=e("../compressions"),l=e("./ZipFileWorker");n.generateWorker=function(s,a,c){var d=new l(a.streamFiles,c,a.platform,a.encodeFileName),f=0;try{s.forEach(function(g,u){f++;var k=(function(w,S){var T=w||S,x=r[T];if(!x)throw new Error(T+" is not a valid compression method !");return x})(u.options.compression,a.compression),h=u.options.compressionOptions||a.compressionOptions||{},y=u.dir,b=u.date;u._compressWorker(k,h).withStreamInfo("file",{name:g,dir:y,date:b,comment:u.comment||"",unixPermissions:u.unixPermissions,dosPermissions:u.dosPermissions}).pipe(d)}),d.entriesCount=f}catch(g){d.error(g)}return d}},{"../compressions":3,"./ZipFileWorker":8}],10:[function(e,o,n){function r(){if(!(this instanceof r))return new r;if(arguments.length)throw new Error("The constructor with parameters has been removed in JSZip 3.0, please check the upgrade guide.");this.files=Object.create(null),this.comment=null,this.root="",this.clone=function(){var l=new r;for(var s in this)typeof this[s]!="function"&&(l[s]=this[s]);return l}}(r.prototype=e("./object")).loadAsync=e("./load"),r.support=e("./support"),r.defaults=e("./defaults"),r.version="3.10.1",r.loadAsync=function(l,s){return new r().loadAsync(l,s)},r.external=e("./external"),o.exports=r},{"./defaults":5,"./external":6,"./load":11,"./object":15,"./support":30}],11:[function(e,o,n){var r=e("./utils"),l=e("./external"),s=e("./utf8"),a=e("./zipEntries"),c=e("./stream/Crc32Probe"),d=e("./nodejsUtils");function f(g){return new l.Promise(function(u,k){var h=g.decompressed.getContentWorker().pipe(new c);h.on("error",function(y){k(y)}).on("end",function(){h.streamInfo.crc32!==g.decompressed.crc32?k(new Error("Corrupted zip : CRC32 mismatch")):u()}).resume()})}o.exports=function(g,u){var k=this;return u=r.extend(u||{},{base64:!1,checkCRC32:!1,optimizedBinaryString:!1,createFolders:!1,decodeFileName:s.utf8decode}),d.isNode&&d.isStream(g)?l.Promise.reject(new Error("JSZip can't accept a stream when loading a zip file.")):r.prepareContent("the loaded zip file",g,!0,u.optimizedBinaryString,u.base64).then(function(h){var y=new a(u);return y.load(h),y}).then(function(h){var y=[l.Promise.resolve(h)],b=h.files;if(u.checkCRC32)for(var w=0;w<b.length;w++)y.push(f(b[w]));return l.Promise.all(y)}).then(function(h){for(var y=h.shift(),b=y.files,w=0;w<b.length;w++){var S=b[w],T=S.fileNameStr,x=r.resolve(S.fileNameStr);k.file(x,S.decompressed,{binary:!0,optimizedBinaryString:!0,date:S.date,dir:S.dir,comment:S.fileCommentStr.length?S.fileCommentStr:null,unixPermissions:S.unixPermissions,dosPermissions:S.dosPermissions,createFolders:u.createFolders}),S.dir||(k.file(x).unsafeOriginalName=T)}return y.zipComment.length&&(k.comment=y.zipComment),k})}},{"./external":6,"./nodejsUtils":14,"./stream/Crc32Probe":25,"./utf8":31,"./utils":32,"./zipEntries":33}],12:[function(e,o,n){var r=e("../utils"),l=e("../stream/GenericWorker");function s(a,c){l.call(this,"Nodejs stream input adapter for "+a),this._upstreamEnded=!1,this._bindStream(c)}r.inherits(s,l),s.prototype._bindStream=function(a){var c=this;(this._stream=a).pause(),a.on("data",function(d){c.push({data:d,meta:{percent:0}})}).on("error",function(d){c.isPaused?this.generatedError=d:c.error(d)}).on("end",function(){c.isPaused?c._upstreamEnded=!0:c.end()})},s.prototype.pause=function(){return!!l.prototype.pause.call(this)&&(this._stream.pause(),!0)},s.prototype.resume=function(){return!!l.prototype.resume.call(this)&&(this._upstreamEnded?this.end():this._stream.resume(),!0)},o.exports=s},{"../stream/GenericWorker":28,"../utils":32}],13:[function(e,o,n){var r=e("readable-stream").Readable;function l(s,a,c){r.call(this,a),this._helper=s;var d=this;s.on("data",function(f,g){d.push(f)||d._helper.pause(),c&&c(g)}).on("error",function(f){d.emit("error",f)}).on("end",function(){d.push(null)})}e("../utils").inherits(l,r),l.prototype._read=function(){this._helper.resume()},o.exports=l},{"../utils":32,"readable-stream":16}],14:[function(e,o,n){o.exports={isNode:typeof Buffer<"u",newBufferFrom:function(r,l){if(Buffer.from&&Buffer.from!==Uint8Array.from)return Buffer.from(r,l);if(typeof r=="number")throw new Error('The "data" argument must not be a number');return new Buffer(r,l)},allocBuffer:function(r){if(Buffer.alloc)return Buffer.alloc(r);var l=new Buffer(r);return l.fill(0),l},isBuffer:function(r){return Buffer.isBuffer(r)},isStream:function(r){return r&&typeof r.on=="function"&&typeof r.pause=="function"&&typeof r.resume=="function"}}},{}],15:[function(e,o,n){function r(x,_,I){var L,M=s.getTypeOf(_),F=s.extend(I||{},d);F.date=F.date||new Date,F.compression!==null&&(F.compression=F.compression.toUpperCase()),typeof F.unixPermissions=="string"&&(F.unixPermissions=parseInt(F.unixPermissions,8)),F.unixPermissions&&16384&F.unixPermissions&&(F.dir=!0),F.dosPermissions&&16&F.dosPermissions&&(F.dir=!0),F.dir&&(x=b(x)),F.createFolders&&(L=y(x))&&w.call(this,L,!0);var J=M==="string"&&F.binary===!1&&F.base64===!1;I&&I.binary!==void 0||(F.binary=!J),(_ instanceof f&&_.uncompressedSize===0||F.dir||!_||_.length===0)&&(F.base64=!1,F.binary=!0,_="",F.compression="STORE",M="string");var E=null;E=_ instanceof f||_ instanceof a?_:k.isNode&&k.isStream(_)?new h(x,_):s.prepareContent(x,_,F.binary,F.optimizedBinaryString,F.base64);var A=new g(x,E,F);this.files[x]=A}var l=e("./utf8"),s=e("./utils"),a=e("./stream/GenericWorker"),c=e("./stream/StreamHelper"),d=e("./defaults"),f=e("./compressedObject"),g=e("./zipObject"),u=e("./generate"),k=e("./nodejsUtils"),h=e("./nodejs/NodejsStreamInputAdapter"),y=function(x){x.slice(-1)==="/"&&(x=x.substring(0,x.length-1));var _=x.lastIndexOf("/");return 0<_?x.substring(0,_):""},b=function(x){return x.slice(-1)!=="/"&&(x+="/"),x},w=function(x,_){return _=_!==void 0?_:d.createFolders,x=b(x),this.files[x]||r.call(this,x,null,{dir:!0,createFolders:_}),this.files[x]};function S(x){return Object.prototype.toString.call(x)==="[object RegExp]"}var T={load:function(){throw new Error("This method has been removed in JSZip 3.0, please check the upgrade guide.")},forEach:function(x){var _,I,L;for(_ in this.files)L=this.files[_],(I=_.slice(this.root.length,_.length))&&_.slice(0,this.root.length)===this.root&&x(I,L)},filter:function(x){var _=[];return this.forEach(function(I,L){x(I,L)&&_.push(L)}),_},file:function(x,_,I){if(arguments.length!==1)return x=this.root+x,r.call(this,x,_,I),this;if(S(x)){var L=x;return this.filter(function(F,J){return!J.dir&&L.test(F)})}var M=this.files[this.root+x];return M&&!M.dir?M:null},folder:function(x){if(!x)return this;if(S(x))return this.filter(function(M,F){return F.dir&&x.test(M)});var _=this.root+x,I=w.call(this,_),L=this.clone();return L.root=I.name,L},remove:function(x){x=this.root+x;var _=this.files[x];if(_||(x.slice(-1)!=="/"&&(x+="/"),_=this.files[x]),_&&!_.dir)delete this.files[x];else for(var I=this.filter(function(M,F){return F.name.slice(0,x.length)===x}),L=0;L<I.length;L++)delete this.files[I[L].name];return this},generate:function(){throw new Error("This method has been removed in JSZip 3.0, please check the upgrade guide.")},generateInternalStream:function(x){var _,I={};try{if((I=s.extend(x||{},{streamFiles:!1,compression:"STORE",compressionOptions:null,type:"",platform:"DOS",comment:null,mimeType:"application/zip",encodeFileName:l.utf8encode})).type=I.type.toLowerCase(),I.compression=I.compression.toUpperCase(),I.type==="binarystring"&&(I.type="string"),!I.type)throw new Error("No output type specified.");s.checkSupport(I.type),I.platform!=="darwin"&&I.platform!=="freebsd"&&I.platform!=="linux"&&I.platform!=="sunos"||(I.platform="UNIX"),I.platform==="win32"&&(I.platform="DOS");var L=I.comment||this.comment||"";_=u.generateWorker(this,I,L)}catch(M){(_=new a("error")).error(M)}return new c(_,I.type||"string",I.mimeType)},generateAsync:function(x,_){return this.generateInternalStream(x).accumulate(_)},generateNodeStream:function(x,_){return(x=x||{}).type||(x.type="nodebuffer"),this.generateInternalStream(x).toNodejsStream(_)}};o.exports=T},{"./compressedObject":2,"./defaults":5,"./generate":9,"./nodejs/NodejsStreamInputAdapter":12,"./nodejsUtils":14,"./stream/GenericWorker":28,"./stream/StreamHelper":29,"./utf8":31,"./utils":32,"./zipObject":35}],16:[function(e,o,n){o.exports=e("stream")},{stream:void 0}],17:[function(e,o,n){var r=e("./DataReader");function l(s){r.call(this,s);for(var a=0;a<this.data.length;a++)s[a]=255&s[a]}e("../utils").inherits(l,r),l.prototype.byteAt=function(s){return this.data[this.zero+s]},l.prototype.lastIndexOfSignature=function(s){for(var a=s.charCodeAt(0),c=s.charCodeAt(1),d=s.charCodeAt(2),f=s.charCodeAt(3),g=this.length-4;0<=g;--g)if(this.data[g]===a&&this.data[g+1]===c&&this.data[g+2]===d&&this.data[g+3]===f)return g-this.zero;return-1},l.prototype.readAndCheckSignature=function(s){var a=s.charCodeAt(0),c=s.charCodeAt(1),d=s.charCodeAt(2),f=s.charCodeAt(3),g=this.readData(4);return a===g[0]&&c===g[1]&&d===g[2]&&f===g[3]},l.prototype.readData=function(s){if(this.checkOffset(s),s===0)return[];var a=this.data.slice(this.zero+this.index,this.zero+this.index+s);return this.index+=s,a},o.exports=l},{"../utils":32,"./DataReader":18}],18:[function(e,o,n){var r=e("../utils");function l(s){this.data=s,this.length=s.length,this.index=0,this.zero=0}l.prototype={checkOffset:function(s){this.checkIndex(this.index+s)},checkIndex:function(s){if(this.length<this.zero+s||s<0)throw new Error("End of data reached (data length = "+this.length+", asked index = "+s+"). Corrupted zip ?")},setIndex:function(s){this.checkIndex(s),this.index=s},skip:function(s){this.setIndex(this.index+s)},byteAt:function(){},readInt:function(s){var a,c=0;for(this.checkOffset(s),a=this.index+s-1;a>=this.index;a--)c=(c<<8)+this.byteAt(a);return this.index+=s,c},readString:function(s){return r.transformTo("string",this.readData(s))},readData:function(){},lastIndexOfSignature:function(){},readAndCheckSignature:function(){},readDate:function(){var s=this.readInt(4);return new Date(Date.UTC(1980+(s>>25&127),(s>>21&15)-1,s>>16&31,s>>11&31,s>>5&63,(31&s)<<1))}},o.exports=l},{"../utils":32}],19:[function(e,o,n){var r=e("./Uint8ArrayReader");function l(s){r.call(this,s)}e("../utils").inherits(l,r),l.prototype.readData=function(s){this.checkOffset(s);var a=this.data.slice(this.zero+this.index,this.zero+this.index+s);return this.index+=s,a},o.exports=l},{"../utils":32,"./Uint8ArrayReader":21}],20:[function(e,o,n){var r=e("./DataReader");function l(s){r.call(this,s)}e("../utils").inherits(l,r),l.prototype.byteAt=function(s){return this.data.charCodeAt(this.zero+s)},l.prototype.lastIndexOfSignature=function(s){return this.data.lastIndexOf(s)-this.zero},l.prototype.readAndCheckSignature=function(s){return s===this.readData(4)},l.prototype.readData=function(s){this.checkOffset(s);var a=this.data.slice(this.zero+this.index,this.zero+this.index+s);return this.index+=s,a},o.exports=l},{"../utils":32,"./DataReader":18}],21:[function(e,o,n){var r=e("./ArrayReader");function l(s){r.call(this,s)}e("../utils").inherits(l,r),l.prototype.readData=function(s){if(this.checkOffset(s),s===0)return new Uint8Array(0);var a=this.data.subarray(this.zero+this.index,this.zero+this.index+s);return this.index+=s,a},o.exports=l},{"../utils":32,"./ArrayReader":17}],22:[function(e,o,n){var r=e("../utils"),l=e("../support"),s=e("./ArrayReader"),a=e("./StringReader"),c=e("./NodeBufferReader"),d=e("./Uint8ArrayReader");o.exports=function(f){var g=r.getTypeOf(f);return r.checkSupport(g),g!=="string"||l.uint8array?g==="nodebuffer"?new c(f):l.uint8array?new d(r.transformTo("uint8array",f)):new s(r.transformTo("array",f)):new a(f)}},{"../support":30,"../utils":32,"./ArrayReader":17,"./NodeBufferReader":19,"./StringReader":20,"./Uint8ArrayReader":21}],23:[function(e,o,n){n.LOCAL_FILE_HEADER="PK",n.CENTRAL_FILE_HEADER="PK",n.CENTRAL_DIRECTORY_END="PK",n.ZIP64_CENTRAL_DIRECTORY_LOCATOR="PK\x07",n.ZIP64_CENTRAL_DIRECTORY_END="PK",n.DATA_DESCRIPTOR="PK\x07\b"},{}],24:[function(e,o,n){var r=e("./GenericWorker"),l=e("../utils");function s(a){r.call(this,"ConvertWorker to "+a),this.destType=a}l.inherits(s,r),s.prototype.processChunk=function(a){this.push({data:l.transformTo(this.destType,a.data),meta:a.meta})},o.exports=s},{"../utils":32,"./GenericWorker":28}],25:[function(e,o,n){var r=e("./GenericWorker"),l=e("../crc32");function s(){r.call(this,"Crc32Probe"),this.withStreamInfo("crc32",0)}e("../utils").inherits(s,r),s.prototype.processChunk=function(a){this.streamInfo.crc32=l(a.data,this.streamInfo.crc32||0),this.push(a)},o.exports=s},{"../crc32":4,"../utils":32,"./GenericWorker":28}],26:[function(e,o,n){var r=e("../utils"),l=e("./GenericWorker");function s(a){l.call(this,"DataLengthProbe for "+a),this.propName=a,this.withStreamInfo(a,0)}r.inherits(s,l),s.prototype.processChunk=function(a){if(a){var c=this.streamInfo[this.propName]||0;this.streamInfo[this.propName]=c+a.data.length}l.prototype.processChunk.call(this,a)},o.exports=s},{"../utils":32,"./GenericWorker":28}],27:[function(e,o,n){var r=e("../utils"),l=e("./GenericWorker");function s(a){l.call(this,"DataWorker");var c=this;this.dataIsReady=!1,this.index=0,this.max=0,this.data=null,this.type="",this._tickScheduled=!1,a.then(function(d){c.dataIsReady=!0,c.data=d,c.max=d&&d.length||0,c.type=r.getTypeOf(d),c.isPaused||c._tickAndRepeat()},function(d){c.error(d)})}r.inherits(s,l),s.prototype.cleanUp=function(){l.prototype.cleanUp.call(this),this.data=null},s.prototype.resume=function(){return!!l.prototype.resume.call(this)&&(!this._tickScheduled&&this.dataIsReady&&(this._tickScheduled=!0,r.delay(this._tickAndRepeat,[],this)),!0)},s.prototype._tickAndRepeat=function(){this._tickScheduled=!1,this.isPaused||this.isFinished||(this._tick(),this.isFinished||(r.delay(this._tickAndRepeat,[],this),this._tickScheduled=!0))},s.prototype._tick=function(){if(this.isPaused||this.isFinished)return!1;var a=null,c=Math.min(this.max,this.index+16384);if(this.index>=this.max)return this.end();switch(this.type){case"string":a=this.data.substring(this.index,c);break;case"uint8array":a=this.data.subarray(this.index,c);break;case"array":case"nodebuffer":a=this.data.slice(this.index,c)}return this.index=c,this.push({data:a,meta:{percent:this.max?this.index/this.max*100:0}})},o.exports=s},{"../utils":32,"./GenericWorker":28}],28:[function(e,o,n){function r(l){this.name=l||"default",this.streamInfo={},this.generatedError=null,this.extraStreamInfo={},this.isPaused=!0,this.isFinished=!1,this.isLocked=!1,this._listeners={data:[],end:[],error:[]},this.previous=null}r.prototype={push:function(l){this.emit("data",l)},end:function(){if(this.isFinished)return!1;this.flush();try{this.emit("end"),this.cleanUp(),this.isFinished=!0}catch(l){this.emit("error",l)}return!0},error:function(l){return!this.isFinished&&(this.isPaused?this.generatedError=l:(this.isFinished=!0,this.emit("error",l),this.previous&&this.previous.error(l),this.cleanUp()),!0)},on:function(l,s){return this._listeners[l].push(s),this},cleanUp:function(){this.streamInfo=this.generatedError=this.extraStreamInfo=null,this._listeners=[]},emit:function(l,s){if(this._listeners[l])for(var a=0;a<this._listeners[l].length;a++)this._listeners[l][a].call(this,s)},pipe:function(l){return l.registerPrevious(this)},registerPrevious:function(l){if(this.isLocked)throw new Error("The stream '"+this+"' has already been used.");this.streamInfo=l.streamInfo,this.mergeStreamInfo(),this.previous=l;var s=this;return l.on("data",function(a){s.processChunk(a)}),l.on("end",function(){s.end()}),l.on("error",function(a){s.error(a)}),this},pause:function(){return!this.isPaused&&!this.isFinished&&(this.isPaused=!0,this.previous&&this.previous.pause(),!0)},resume:function(){if(!this.isPaused||this.isFinished)return!1;var l=this.isPaused=!1;return this.generatedError&&(this.error(this.generatedError),l=!0),this.previous&&this.previous.resume(),!l},flush:function(){},processChunk:function(l){this.push(l)},withStreamInfo:function(l,s){return this.extraStreamInfo[l]=s,this.mergeStreamInfo(),this},mergeStreamInfo:function(){for(var l in this.extraStreamInfo)Object.prototype.hasOwnProperty.call(this.extraStreamInfo,l)&&(this.streamInfo[l]=this.extraStreamInfo[l])},lock:function(){if(this.isLocked)throw new Error("The stream '"+this+"' has already been used.");this.isLocked=!0,this.previous&&this.previous.lock()},toString:function(){var l="Worker "+this.name;return this.previous?this.previous+" -> "+l:l}},o.exports=r},{}],29:[function(e,o,n){var r=e("../utils"),l=e("./ConvertWorker"),s=e("./GenericWorker"),a=e("../base64"),c=e("../support"),d=e("../external"),f=null;if(c.nodestream)try{f=e("../nodejs/NodejsStreamOutputAdapter")}catch{}function g(k,h){return new d.Promise(function(y,b){var w=[],S=k._internalType,T=k._outputType,x=k._mimeType;k.on("data",function(_,I){w.push(_),h&&h(I)}).on("error",function(_){w=[],b(_)}).on("end",function(){try{var _=(function(I,L,M){switch(I){case"blob":return r.newBlob(r.transformTo("arraybuffer",L),M);case"base64":return a.encode(L);default:return r.transformTo(I,L)}})(T,(function(I,L){var M,F=0,J=null,E=0;for(M=0;M<L.length;M++)E+=L[M].length;switch(I){case"string":return L.join("");case"array":return Array.prototype.concat.apply([],L);case"uint8array":for(J=new Uint8Array(E),M=0;M<L.length;M++)J.set(L[M],F),F+=L[M].length;return J;case"nodebuffer":return Buffer.concat(L);default:throw new Error("concat : unsupported type '"+I+"'")}})(S,w),x);y(_)}catch(I){b(I)}w=[]}).resume()})}function u(k,h,y){var b=h;switch(h){case"blob":case"arraybuffer":b="uint8array";break;case"base64":b="string"}try{this._internalType=b,this._outputType=h,this._mimeType=y,r.checkSupport(b),this._worker=k.pipe(new l(b)),k.lock()}catch(w){this._worker=new s("error"),this._worker.error(w)}}u.prototype={accumulate:function(k){return g(this,k)},on:function(k,h){var y=this;return k==="data"?this._worker.on(k,function(b){h.call(y,b.data,b.meta)}):this._worker.on(k,function(){r.delay(h,arguments,y)}),this},resume:function(){return r.delay(this._worker.resume,[],this._worker),this},pause:function(){return this._worker.pause(),this},toNodejsStream:function(k){if(r.checkSupport("nodestream"),this._outputType!=="nodebuffer")throw new Error(this._outputType+" is not supported by this method");return new f(this,{objectMode:this._outputType!=="nodebuffer"},k)}},o.exports=u},{"../base64":1,"../external":6,"../nodejs/NodejsStreamOutputAdapter":13,"../support":30,"../utils":32,"./ConvertWorker":24,"./GenericWorker":28}],30:[function(e,o,n){if(n.base64=!0,n.array=!0,n.string=!0,n.arraybuffer=typeof ArrayBuffer<"u"&&typeof Uint8Array<"u",n.nodebuffer=typeof Buffer<"u",n.uint8array=typeof Uint8Array<"u",typeof ArrayBuffer>"u")n.blob=!1;else{var r=new ArrayBuffer(0);try{n.blob=new Blob([r],{type:"application/zip"}).size===0}catch{try{var l=new(self.BlobBuilder||self.WebKitBlobBuilder||self.MozBlobBuilder||self.MSBlobBuilder);l.append(r),n.blob=l.getBlob("application/zip").size===0}catch{n.blob=!1}}}try{n.nodestream=!!e("readable-stream").Readable}catch{n.nodestream=!1}},{"readable-stream":16}],31:[function(e,o,n){for(var r=e("./utils"),l=e("./support"),s=e("./nodejsUtils"),a=e("./stream/GenericWorker"),c=new Array(256),d=0;d<256;d++)c[d]=252<=d?6:248<=d?5:240<=d?4:224<=d?3:192<=d?2:1;c[254]=c[254]=1;function f(){a.call(this,"utf-8 decode"),this.leftOver=null}function g(){a.call(this,"utf-8 encode")}n.utf8encode=function(u){return l.nodebuffer?s.newBufferFrom(u,"utf-8"):(function(k){var h,y,b,w,S,T=k.length,x=0;for(w=0;w<T;w++)(64512&(y=k.charCodeAt(w)))==55296&&w+1<T&&(64512&(b=k.charCodeAt(w+1)))==56320&&(y=65536+(y-55296<<10)+(b-56320),w++),x+=y<128?1:y<2048?2:y<65536?3:4;for(h=l.uint8array?new Uint8Array(x):new Array(x),w=S=0;S<x;w++)(64512&(y=k.charCodeAt(w)))==55296&&w+1<T&&(64512&(b=k.charCodeAt(w+1)))==56320&&(y=65536+(y-55296<<10)+(b-56320),w++),y<128?h[S++]=y:(y<2048?h[S++]=192|y>>>6:(y<65536?h[S++]=224|y>>>12:(h[S++]=240|y>>>18,h[S++]=128|y>>>12&63),h[S++]=128|y>>>6&63),h[S++]=128|63&y);return h})(u)},n.utf8decode=function(u){return l.nodebuffer?r.transformTo("nodebuffer",u).toString("utf-8"):(function(k){var h,y,b,w,S=k.length,T=new Array(2*S);for(h=y=0;h<S;)if((b=k[h++])<128)T[y++]=b;else if(4<(w=c[b]))T[y++]=65533,h+=w-1;else{for(b&=w===2?31:w===3?15:7;1<w&&h<S;)b=b<<6|63&k[h++],w--;1<w?T[y++]=65533:b<65536?T[y++]=b:(b-=65536,T[y++]=55296|b>>10&1023,T[y++]=56320|1023&b)}return T.length!==y&&(T.subarray?T=T.subarray(0,y):T.length=y),r.applyFromCharCode(T)})(u=r.transformTo(l.uint8array?"uint8array":"array",u))},r.inherits(f,a),f.prototype.processChunk=function(u){var k=r.transformTo(l.uint8array?"uint8array":"array",u.data);if(this.leftOver&&this.leftOver.length){if(l.uint8array){var h=k;(k=new Uint8Array(h.length+this.leftOver.length)).set(this.leftOver,0),k.set(h,this.leftOver.length)}else k=this.leftOver.concat(k);this.leftOver=null}var y=(function(w,S){var T;for((S=S||w.length)>w.length&&(S=w.length),T=S-1;0<=T&&(192&w[T])==128;)T--;return T<0||T===0?S:T+c[w[T]]>S?T:S})(k),b=k;y!==k.length&&(l.uint8array?(b=k.subarray(0,y),this.leftOver=k.subarray(y,k.length)):(b=k.slice(0,y),this.leftOver=k.slice(y,k.length))),this.push({data:n.utf8decode(b),meta:u.meta})},f.prototype.flush=function(){this.leftOver&&this.leftOver.length&&(this.push({data:n.utf8decode(this.leftOver),meta:{}}),this.leftOver=null)},n.Utf8DecodeWorker=f,r.inherits(g,a),g.prototype.processChunk=function(u){this.push({data:n.utf8encode(u.data),meta:u.meta})},n.Utf8EncodeWorker=g},{"./nodejsUtils":14,"./stream/GenericWorker":28,"./support":30,"./utils":32}],32:[function(e,o,n){var r=e("./support"),l=e("./base64"),s=e("./nodejsUtils"),a=e("./external");function c(h){return h}function d(h,y){for(var b=0;b<h.length;++b)y[b]=255&h.charCodeAt(b);return y}e("setimmediate"),n.newBlob=function(h,y){n.checkSupport("blob");try{return new Blob([h],{type:y})}catch{try{var b=new(self.BlobBuilder||self.WebKitBlobBuilder||self.MozBlobBuilder||self.MSBlobBuilder);return b.append(h),b.getBlob(y)}catch{throw new Error("Bug : can't construct the Blob.")}}};var f={stringifyByChunk:function(h,y,b){var w=[],S=0,T=h.length;if(T<=b)return String.fromCharCode.apply(null,h);for(;S<T;)y==="array"||y==="nodebuffer"?w.push(String.fromCharCode.apply(null,h.slice(S,Math.min(S+b,T)))):w.push(String.fromCharCode.apply(null,h.subarray(S,Math.min(S+b,T)))),S+=b;return w.join("")},stringifyByChar:function(h){for(var y="",b=0;b<h.length;b++)y+=String.fromCharCode(h[b]);return y},applyCanBeUsed:{uint8array:(function(){try{return r.uint8array&&String.fromCharCode.apply(null,new Uint8Array(1)).length===1}catch{return!1}})(),nodebuffer:(function(){try{return r.nodebuffer&&String.fromCharCode.apply(null,s.allocBuffer(1)).length===1}catch{return!1}})()}};function g(h){var y=65536,b=n.getTypeOf(h),w=!0;if(b==="uint8array"?w=f.applyCanBeUsed.uint8array:b==="nodebuffer"&&(w=f.applyCanBeUsed.nodebuffer),w)for(;1<y;)try{return f.stringifyByChunk(h,b,y)}catch{y=Math.floor(y/2)}return f.stringifyByChar(h)}function u(h,y){for(var b=0;b<h.length;b++)y[b]=h[b];return y}n.applyFromCharCode=g;var k={};k.string={string:c,array:function(h){return d(h,new Array(h.length))},arraybuffer:function(h){return k.string.uint8array(h).buffer},uint8array:function(h){return d(h,new Uint8Array(h.length))},nodebuffer:function(h){return d(h,s.allocBuffer(h.length))}},k.array={string:g,array:c,arraybuffer:function(h){return new Uint8Array(h).buffer},uint8array:function(h){return new Uint8Array(h)},nodebuffer:function(h){return s.newBufferFrom(h)}},k.arraybuffer={string:function(h){return g(new Uint8Array(h))},array:function(h){return u(new Uint8Array(h),new Array(h.byteLength))},arraybuffer:c,uint8array:function(h){return new Uint8Array(h)},nodebuffer:function(h){return s.newBufferFrom(new Uint8Array(h))}},k.uint8array={string:g,array:function(h){return u(h,new Array(h.length))},arraybuffer:function(h){return h.buffer},uint8array:c,nodebuffer:function(h){return s.newBufferFrom(h)}},k.nodebuffer={string:g,array:function(h){return u(h,new Array(h.length))},arraybuffer:function(h){return k.nodebuffer.uint8array(h).buffer},uint8array:function(h){return u(h,new Uint8Array(h.length))},nodebuffer:c},n.transformTo=function(h,y){if(y=y||"",!h)return y;n.checkSupport(h);var b=n.getTypeOf(y);return k[b][h](y)},n.resolve=function(h){for(var y=h.split("/"),b=[],w=0;w<y.length;w++){var S=y[w];S==="."||S===""&&w!==0&&w!==y.length-1||(S===".."?b.pop():b.push(S))}return b.join("/")},n.getTypeOf=function(h){return typeof h=="string"?"string":Object.prototype.toString.call(h)==="[object Array]"?"array":r.nodebuffer&&s.isBuffer(h)?"nodebuffer":r.uint8array&&h instanceof Uint8Array?"uint8array":r.arraybuffer&&h instanceof ArrayBuffer?"arraybuffer":void 0},n.checkSupport=function(h){if(!r[h.toLowerCase()])throw new Error(h+" is not supported by this platform")},n.MAX_VALUE_16BITS=65535,n.MAX_VALUE_32BITS=-1,n.pretty=function(h){var y,b,w="";for(b=0;b<(h||"").length;b++)w+="\\x"+((y=h.charCodeAt(b))<16?"0":"")+y.toString(16).toUpperCase();return w},n.delay=function(h,y,b){setImmediate(function(){h.apply(b||null,y||[])})},n.inherits=function(h,y){function b(){}b.prototype=y.prototype,h.prototype=new b},n.extend=function(){var h,y,b={};for(h=0;h<arguments.length;h++)for(y in arguments[h])Object.prototype.hasOwnProperty.call(arguments[h],y)&&b[y]===void 0&&(b[y]=arguments[h][y]);return b},n.prepareContent=function(h,y,b,w,S){return a.Promise.resolve(y).then(function(T){return r.blob&&(T instanceof Blob||["[object File]","[object Blob]"].indexOf(Object.prototype.toString.call(T))!==-1)&&typeof FileReader<"u"?new a.Promise(function(x,_){var I=new FileReader;I.onload=function(L){x(L.target.result)},I.onerror=function(L){_(L.target.error)},I.readAsArrayBuffer(T)}):T}).then(function(T){var x=n.getTypeOf(T);return x?(x==="arraybuffer"?T=n.transformTo("uint8array",T):x==="string"&&(S?T=l.decode(T):b&&w!==!0&&(T=(function(_){return d(_,r.uint8array?new Uint8Array(_.length):new Array(_.length))})(T))),T):a.Promise.reject(new Error("Can't read the data of '"+h+"'. Is it in a supported JavaScript type (String, Blob, ArrayBuffer, etc) ?"))})}},{"./base64":1,"./external":6,"./nodejsUtils":14,"./support":30,setimmediate:54}],33:[function(e,o,n){var r=e("./reader/readerFor"),l=e("./utils"),s=e("./signature"),a=e("./zipEntry"),c=e("./support");function d(f){this.files=[],this.loadOptions=f}d.prototype={checkSignature:function(f){if(!this.reader.readAndCheckSignature(f)){this.reader.index-=4;var g=this.reader.readString(4);throw new Error("Corrupted zip or bug: unexpected signature ("+l.pretty(g)+", expected "+l.pretty(f)+")")}},isSignature:function(f,g){var u=this.reader.index;this.reader.setIndex(f);var k=this.reader.readString(4)===g;return this.reader.setIndex(u),k},readBlockEndOfCentral:function(){this.diskNumber=this.reader.readInt(2),this.diskWithCentralDirStart=this.reader.readInt(2),this.centralDirRecordsOnThisDisk=this.reader.readInt(2),this.centralDirRecords=this.reader.readInt(2),this.centralDirSize=this.reader.readInt(4),this.centralDirOffset=this.reader.readInt(4),this.zipCommentLength=this.reader.readInt(2);var f=this.reader.readData(this.zipCommentLength),g=c.uint8array?"uint8array":"array",u=l.transformTo(g,f);this.zipComment=this.loadOptions.decodeFileName(u)},readBlockZip64EndOfCentral:function(){this.zip64EndOfCentralSize=this.reader.readInt(8),this.reader.skip(4),this.diskNumber=this.reader.readInt(4),this.diskWithCentralDirStart=this.reader.readInt(4),this.centralDirRecordsOnThisDisk=this.reader.readInt(8),this.centralDirRecords=this.reader.readInt(8),this.centralDirSize=this.reader.readInt(8),this.centralDirOffset=this.reader.readInt(8),this.zip64ExtensibleData={};for(var f,g,u,k=this.zip64EndOfCentralSize-44;0<k;)f=this.reader.readInt(2),g=this.reader.readInt(4),u=this.reader.readData(g),this.zip64ExtensibleData[f]={id:f,length:g,value:u}},readBlockZip64EndOfCentralLocator:function(){if(this.diskWithZip64CentralDirStart=this.reader.readInt(4),this.relativeOffsetEndOfZip64CentralDir=this.reader.readInt(8),this.disksCount=this.reader.readInt(4),1<this.disksCount)throw new Error("Multi-volumes zip are not supported")},readLocalFiles:function(){var f,g;for(f=0;f<this.files.length;f++)g=this.files[f],this.reader.setIndex(g.localHeaderOffset),this.checkSignature(s.LOCAL_FILE_HEADER),g.readLocalPart(this.reader),g.handleUTF8(),g.processAttributes()},readCentralDir:function(){var f;for(this.reader.setIndex(this.centralDirOffset);this.reader.readAndCheckSignature(s.CENTRAL_FILE_HEADER);)(f=new a({zip64:this.zip64},this.loadOptions)).readCentralPart(this.reader),this.files.push(f);if(this.centralDirRecords!==this.files.length&&this.centralDirRecords!==0&&this.files.length===0)throw new Error("Corrupted zip or bug: expected "+this.centralDirRecords+" records in central dir, got "+this.files.length)},readEndOfCentral:function(){var f=this.reader.lastIndexOfSignature(s.CENTRAL_DIRECTORY_END);if(f<0)throw this.isSignature(0,s.LOCAL_FILE_HEADER)?new Error("Corrupted zip: can't find end of central directory"):new Error("Can't find end of central directory : is this a zip file ? If it is, see https://stuk.github.io/jszip/documentation/howto/read_zip.html");this.reader.setIndex(f);var g=f;if(this.checkSignature(s.CENTRAL_DIRECTORY_END),this.readBlockEndOfCentral(),this.diskNumber===l.MAX_VALUE_16BITS||this.diskWithCentralDirStart===l.MAX_VALUE_16BITS||this.centralDirRecordsOnThisDisk===l.MAX_VALUE_16BITS||this.centralDirRecords===l.MAX_VALUE_16BITS||this.centralDirSize===l.MAX_VALUE_32BITS||this.centralDirOffset===l.MAX_VALUE_32BITS){if(this.zip64=!0,(f=this.reader.lastIndexOfSignature(s.ZIP64_CENTRAL_DIRECTORY_LOCATOR))<0)throw new Error("Corrupted zip: can't find the ZIP64 end of central directory locator");if(this.reader.setIndex(f),this.checkSignature(s.ZIP64_CENTRAL_DIRECTORY_LOCATOR),this.readBlockZip64EndOfCentralLocator(),!this.isSignature(this.relativeOffsetEndOfZip64CentralDir,s.ZIP64_CENTRAL_DIRECTORY_END)&&(this.relativeOffsetEndOfZip64CentralDir=this.reader.lastIndexOfSignature(s.ZIP64_CENTRAL_DIRECTORY_END),this.relativeOffsetEndOfZip64CentralDir<0))throw new Error("Corrupted zip: can't find the ZIP64 end of central directory");this.reader.setIndex(this.relativeOffsetEndOfZip64CentralDir),this.checkSignature(s.ZIP64_CENTRAL_DIRECTORY_END),this.readBlockZip64EndOfCentral()}var u=this.centralDirOffset+this.centralDirSize;this.zip64&&(u+=20,u+=12+this.zip64EndOfCentralSize);var k=g-u;if(0<k)this.isSignature(g,s.CENTRAL_FILE_HEADER)||(this.reader.zero=k);else if(k<0)throw new Error("Corrupted zip: missing "+Math.abs(k)+" bytes.")},prepareReader:function(f){this.reader=r(f)},load:function(f){this.prepareReader(f),this.readEndOfCentral(),this.readCentralDir(),this.readLocalFiles()}},o.exports=d},{"./reader/readerFor":22,"./signature":23,"./support":30,"./utils":32,"./zipEntry":34}],34:[function(e,o,n){var r=e("./reader/readerFor"),l=e("./utils"),s=e("./compressedObject"),a=e("./crc32"),c=e("./utf8"),d=e("./compressions"),f=e("./support");function g(u,k){this.options=u,this.loadOptions=k}g.prototype={isEncrypted:function(){return(1&this.bitFlag)==1},useUTF8:function(){return(2048&this.bitFlag)==2048},readLocalPart:function(u){var k,h;if(u.skip(22),this.fileNameLength=u.readInt(2),h=u.readInt(2),this.fileName=u.readData(this.fileNameLength),u.skip(h),this.compressedSize===-1||this.uncompressedSize===-1)throw new Error("Bug or corrupted zip : didn't get enough information from the central directory (compressedSize === -1 || uncompressedSize === -1)");if((k=(function(y){for(var b in d)if(Object.prototype.hasOwnProperty.call(d,b)&&d[b].magic===y)return d[b];return null})(this.compressionMethod))===null)throw new Error("Corrupted zip : compression "+l.pretty(this.compressionMethod)+" unknown (inner file : "+l.transformTo("string",this.fileName)+")");this.decompressed=new s(this.compressedSize,this.uncompressedSize,this.crc32,k,u.readData(this.compressedSize))},readCentralPart:function(u){this.versionMadeBy=u.readInt(2),u.skip(2),this.bitFlag=u.readInt(2),this.compressionMethod=u.readString(2),this.date=u.readDate(),this.crc32=u.readInt(4),this.compressedSize=u.readInt(4),this.uncompressedSize=u.readInt(4);var k=u.readInt(2);if(this.extraFieldsLength=u.readInt(2),this.fileCommentLength=u.readInt(2),this.diskNumberStart=u.readInt(2),this.internalFileAttributes=u.readInt(2),this.externalFileAttributes=u.readInt(4),this.localHeaderOffset=u.readInt(4),this.isEncrypted())throw new Error("Encrypted zip are not supported");u.skip(k),this.readExtraFields(u),this.parseZIP64ExtraField(u),this.fileComment=u.readData(this.fileCommentLength)},processAttributes:function(){this.unixPermissions=null,this.dosPermissions=null;var u=this.versionMadeBy>>8;this.dir=!!(16&this.externalFileAttributes),u==0&&(this.dosPermissions=63&this.externalFileAttributes),u==3&&(this.unixPermissions=this.externalFileAttributes>>16&65535),this.dir||this.fileNameStr.slice(-1)!=="/"||(this.dir=!0)},parseZIP64ExtraField:function(){if(this.extraFields[1]){var u=r(this.extraFields[1].value);this.uncompressedSize===l.MAX_VALUE_32BITS&&(this.uncompressedSize=u.readInt(8)),this.compressedSize===l.MAX_VALUE_32BITS&&(this.compressedSize=u.readInt(8)),this.localHeaderOffset===l.MAX_VALUE_32BITS&&(this.localHeaderOffset=u.readInt(8)),this.diskNumberStart===l.MAX_VALUE_32BITS&&(this.diskNumberStart=u.readInt(4))}},readExtraFields:function(u){var k,h,y,b=u.index+this.extraFieldsLength;for(this.extraFields||(this.extraFields={});u.index+4<b;)k=u.readInt(2),h=u.readInt(2),y=u.readData(h),this.extraFields[k]={id:k,length:h,value:y};u.setIndex(b)},handleUTF8:function(){var u=f.uint8array?"uint8array":"array";if(this.useUTF8())this.fileNameStr=c.utf8decode(this.fileName),this.fileCommentStr=c.utf8decode(this.fileComment);else{var k=this.findExtraFieldUnicodePath();if(k!==null)this.fileNameStr=k;else{var h=l.transformTo(u,this.fileName);this.fileNameStr=this.loadOptions.decodeFileName(h)}var y=this.findExtraFieldUnicodeComment();if(y!==null)this.fileCommentStr=y;else{var b=l.transformTo(u,this.fileComment);this.fileCommentStr=this.loadOptions.decodeFileName(b)}}},findExtraFieldUnicodePath:function(){var u=this.extraFields[28789];if(u){var k=r(u.value);return k.readInt(1)!==1||a(this.fileName)!==k.readInt(4)?null:c.utf8decode(k.readData(u.length-5))}return null},findExtraFieldUnicodeComment:function(){var u=this.extraFields[25461];if(u){var k=r(u.value);return k.readInt(1)!==1||a(this.fileComment)!==k.readInt(4)?null:c.utf8decode(k.readData(u.length-5))}return null}},o.exports=g},{"./compressedObject":2,"./compressions":3,"./crc32":4,"./reader/readerFor":22,"./support":30,"./utf8":31,"./utils":32}],35:[function(e,o,n){function r(k,h,y){this.name=k,this.dir=y.dir,this.date=y.date,this.comment=y.comment,this.unixPermissions=y.unixPermissions,this.dosPermissions=y.dosPermissions,this._data=h,this._dataBinary=y.binary,this.options={compression:y.compression,compressionOptions:y.compressionOptions}}var l=e("./stream/StreamHelper"),s=e("./stream/DataWorker"),a=e("./utf8"),c=e("./compressedObject"),d=e("./stream/GenericWorker");r.prototype={internalStream:function(k){var h=null,y="string";try{if(!k)throw new Error("No output type specified.");var b=(y=k.toLowerCase())==="string"||y==="text";y!=="binarystring"&&y!=="text"||(y="string"),h=this._decompressWorker();var w=!this._dataBinary;w&&!b&&(h=h.pipe(new a.Utf8EncodeWorker)),!w&&b&&(h=h.pipe(new a.Utf8DecodeWorker))}catch(S){(h=new d("error")).error(S)}return new l(h,y,"")},async:function(k,h){return this.internalStream(k).accumulate(h)},nodeStream:function(k,h){return this.internalStream(k||"nodebuffer").toNodejsStream(h)},_compressWorker:function(k,h){if(this._data instanceof c&&this._data.compression.magic===k.magic)return this._data.getCompressedWorker();var y=this._decompressWorker();return this._dataBinary||(y=y.pipe(new a.Utf8EncodeWorker)),c.createWorkerFrom(y,k,h)},_decompressWorker:function(){return this._data instanceof c?this._data.getContentWorker():this._data instanceof d?this._data:new s(this._data)}};for(var f=["asText","asBinary","asNodeBuffer","asUint8Array","asArrayBuffer"],g=function(){throw new Error("This method has been removed in JSZip 3.0, please check the upgrade guide.")},u=0;u<f.length;u++)r.prototype[f[u]]=g;o.exports=r},{"./compressedObject":2,"./stream/DataWorker":27,"./stream/GenericWorker":28,"./stream/StreamHelper":29,"./utf8":31}],36:[function(e,o,n){(function(r){var l,s,a=r.MutationObserver||r.WebKitMutationObserver;if(a){var c=0,d=new a(k),f=r.document.createTextNode("");d.observe(f,{characterData:!0}),l=function(){f.data=c=++c%2}}else if(r.setImmediate||r.MessageChannel===void 0)l="document"in r&&"onreadystatechange"in r.document.createElement("script")?function(){var h=r.document.createElement("script");h.onreadystatechange=function(){k(),h.onreadystatechange=null,h.parentNode.removeChild(h),h=null},r.document.documentElement.appendChild(h)}:function(){setTimeout(k,0)};else{var g=new r.MessageChannel;g.port1.onmessage=k,l=function(){g.port2.postMessage(0)}}var u=[];function k(){var h,y;s=!0;for(var b=u.length;b;){for(y=u,u=[],h=-1;++h<b;)y[h]();b=u.length}s=!1}o.exports=function(h){u.push(h)!==1||s||l()}}).call(this,typeof Ln<"u"?Ln:typeof self<"u"?self:typeof window<"u"?window:{})},{}],37:[function(e,o,n){var r=e("immediate");function l(){}var s={},a=["REJECTED"],c=["FULFILLED"],d=["PENDING"];function f(b){if(typeof b!="function")throw new TypeError("resolver must be a function");this.state=d,this.queue=[],this.outcome=void 0,b!==l&&h(this,b)}function g(b,w,S){this.promise=b,typeof w=="function"&&(this.onFulfilled=w,this.callFulfilled=this.otherCallFulfilled),typeof S=="function"&&(this.onRejected=S,this.callRejected=this.otherCallRejected)}function u(b,w,S){r(function(){var T;try{T=w(S)}catch(x){return s.reject(b,x)}T===b?s.reject(b,new TypeError("Cannot resolve promise with itself")):s.resolve(b,T)})}function k(b){var w=b&&b.then;if(b&&(typeof b=="object"||typeof b=="function")&&typeof w=="function")return function(){w.apply(b,arguments)}}function h(b,w){var S=!1;function T(I){S||(S=!0,s.reject(b,I))}function x(I){S||(S=!0,s.resolve(b,I))}var _=y(function(){w(x,T)});_.status==="error"&&T(_.value)}function y(b,w){var S={};try{S.value=b(w),S.status="success"}catch(T){S.status="error",S.value=T}return S}(o.exports=f).prototype.finally=function(b){if(typeof b!="function")return this;var w=this.constructor;return this.then(function(S){return w.resolve(b()).then(function(){return S})},function(S){return w.resolve(b()).then(function(){throw S})})},f.prototype.catch=function(b){return this.then(null,b)},f.prototype.then=function(b,w){if(typeof b!="function"&&this.state===c||typeof w!="function"&&this.state===a)return this;var S=new this.constructor(l);return this.state!==d?u(S,this.state===c?b:w,this.outcome):this.queue.push(new g(S,b,w)),S},g.prototype.callFulfilled=function(b){s.resolve(this.promise,b)},g.prototype.otherCallFulfilled=function(b){u(this.promise,this.onFulfilled,b)},g.prototype.callRejected=function(b){s.reject(this.promise,b)},g.prototype.otherCallRejected=function(b){u(this.promise,this.onRejected,b)},s.resolve=function(b,w){var S=y(k,w);if(S.status==="error")return s.reject(b,S.value);var T=S.value;if(T)h(b,T);else{b.state=c,b.outcome=w;for(var x=-1,_=b.queue.length;++x<_;)b.queue[x].callFulfilled(w)}return b},s.reject=function(b,w){b.state=a,b.outcome=w;for(var S=-1,T=b.queue.length;++S<T;)b.queue[S].callRejected(w);return b},f.resolve=function(b){return b instanceof this?b:s.resolve(new this(l),b)},f.reject=function(b){var w=new this(l);return s.reject(w,b)},f.all=function(b){var w=this;if(Object.prototype.toString.call(b)!=="[object Array]")return this.reject(new TypeError("must be an array"));var S=b.length,T=!1;if(!S)return this.resolve([]);for(var x=new Array(S),_=0,I=-1,L=new this(l);++I<S;)M(b[I],I);return L;function M(F,J){w.resolve(F).then(function(E){x[J]=E,++_!==S||T||(T=!0,s.resolve(L,x))},function(E){T||(T=!0,s.reject(L,E))})}},f.race=function(b){var w=this;if(Object.prototype.toString.call(b)!=="[object Array]")return this.reject(new TypeError("must be an array"));var S=b.length,T=!1;if(!S)return this.resolve([]);for(var x=-1,_=new this(l);++x<S;)I=b[x],w.resolve(I).then(function(L){T||(T=!0,s.resolve(_,L))},function(L){T||(T=!0,s.reject(_,L))});var I;return _}},{immediate:36}],38:[function(e,o,n){var r={};(0,e("./lib/utils/common").assign)(r,e("./lib/deflate"),e("./lib/inflate"),e("./lib/zlib/constants")),o.exports=r},{"./lib/deflate":39,"./lib/inflate":40,"./lib/utils/common":41,"./lib/zlib/constants":44}],39:[function(e,o,n){var r=e("./zlib/deflate"),l=e("./utils/common"),s=e("./utils/strings"),a=e("./zlib/messages"),c=e("./zlib/zstream"),d=Object.prototype.toString,f=0,g=-1,u=0,k=8;function h(b){if(!(this instanceof h))return new h(b);this.options=l.assign({level:g,method:k,chunkSize:16384,windowBits:15,memLevel:8,strategy:u,to:""},b||{});var w=this.options;w.raw&&0<w.windowBits?w.windowBits=-w.windowBits:w.gzip&&0<w.windowBits&&w.windowBits<16&&(w.windowBits+=16),this.err=0,this.msg="",this.ended=!1,this.chunks=[],this.strm=new c,this.strm.avail_out=0;var S=r.deflateInit2(this.strm,w.level,w.method,w.windowBits,w.memLevel,w.strategy);if(S!==f)throw new Error(a[S]);if(w.header&&r.deflateSetHeader(this.strm,w.header),w.dictionary){var T;if(T=typeof w.dictionary=="string"?s.string2buf(w.dictionary):d.call(w.dictionary)==="[object ArrayBuffer]"?new Uint8Array(w.dictionary):w.dictionary,(S=r.deflateSetDictionary(this.strm,T))!==f)throw new Error(a[S]);this._dict_set=!0}}function y(b,w){var S=new h(w);if(S.push(b,!0),S.err)throw S.msg||a[S.err];return S.result}h.prototype.push=function(b,w){var S,T,x=this.strm,_=this.options.chunkSize;if(this.ended)return!1;T=w===~~w?w:w===!0?4:0,typeof b=="string"?x.input=s.string2buf(b):d.call(b)==="[object ArrayBuffer]"?x.input=new Uint8Array(b):x.input=b,x.next_in=0,x.avail_in=x.input.length;do{if(x.avail_out===0&&(x.output=new l.Buf8(_),x.next_out=0,x.avail_out=_),(S=r.deflate(x,T))!==1&&S!==f)return this.onEnd(S),!(this.ended=!0);x.avail_out!==0&&(x.avail_in!==0||T!==4&&T!==2)||(this.options.to==="string"?this.onData(s.buf2binstring(l.shrinkBuf(x.output,x.next_out))):this.onData(l.shrinkBuf(x.output,x.next_out)))}while((0<x.avail_in||x.avail_out===0)&&S!==1);return T===4?(S=r.deflateEnd(this.strm),this.onEnd(S),this.ended=!0,S===f):T!==2||(this.onEnd(f),!(x.avail_out=0))},h.prototype.onData=function(b){this.chunks.push(b)},h.prototype.onEnd=function(b){b===f&&(this.options.to==="string"?this.result=this.chunks.join(""):this.result=l.flattenChunks(this.chunks)),this.chunks=[],this.err=b,this.msg=this.strm.msg},n.Deflate=h,n.deflate=y,n.deflateRaw=function(b,w){return(w=w||{}).raw=!0,y(b,w)},n.gzip=function(b,w){return(w=w||{}).gzip=!0,y(b,w)}},{"./utils/common":41,"./utils/strings":42,"./zlib/deflate":46,"./zlib/messages":51,"./zlib/zstream":53}],40:[function(e,o,n){var r=e("./zlib/inflate"),l=e("./utils/common"),s=e("./utils/strings"),a=e("./zlib/constants"),c=e("./zlib/messages"),d=e("./zlib/zstream"),f=e("./zlib/gzheader"),g=Object.prototype.toString;function u(h){if(!(this instanceof u))return new u(h);this.options=l.assign({chunkSize:16384,windowBits:0,to:""},h||{});var y=this.options;y.raw&&0<=y.windowBits&&y.windowBits<16&&(y.windowBits=-y.windowBits,y.windowBits===0&&(y.windowBits=-15)),!(0<=y.windowBits&&y.windowBits<16)||h&&h.windowBits||(y.windowBits+=32),15<y.windowBits&&y.windowBits<48&&(15&y.windowBits)==0&&(y.windowBits|=15),this.err=0,this.msg="",this.ended=!1,this.chunks=[],this.strm=new d,this.strm.avail_out=0;var b=r.inflateInit2(this.strm,y.windowBits);if(b!==a.Z_OK)throw new Error(c[b]);this.header=new f,r.inflateGetHeader(this.strm,this.header)}function k(h,y){var b=new u(y);if(b.push(h,!0),b.err)throw b.msg||c[b.err];return b.result}u.prototype.push=function(h,y){var b,w,S,T,x,_,I=this.strm,L=this.options.chunkSize,M=this.options.dictionary,F=!1;if(this.ended)return!1;w=y===~~y?y:y===!0?a.Z_FINISH:a.Z_NO_FLUSH,typeof h=="string"?I.input=s.binstring2buf(h):g.call(h)==="[object ArrayBuffer]"?I.input=new Uint8Array(h):I.input=h,I.next_in=0,I.avail_in=I.input.length;do{if(I.avail_out===0&&(I.output=new l.Buf8(L),I.next_out=0,I.avail_out=L),(b=r.inflate(I,a.Z_NO_FLUSH))===a.Z_NEED_DICT&&M&&(_=typeof M=="string"?s.string2buf(M):g.call(M)==="[object ArrayBuffer]"?new Uint8Array(M):M,b=r.inflateSetDictionary(this.strm,_)),b===a.Z_BUF_ERROR&&F===!0&&(b=a.Z_OK,F=!1),b!==a.Z_STREAM_END&&b!==a.Z_OK)return this.onEnd(b),!(this.ended=!0);I.next_out&&(I.avail_out!==0&&b!==a.Z_STREAM_END&&(I.avail_in!==0||w!==a.Z_FINISH&&w!==a.Z_SYNC_FLUSH)||(this.options.to==="string"?(S=s.utf8border(I.output,I.next_out),T=I.next_out-S,x=s.buf2string(I.output,S),I.next_out=T,I.avail_out=L-T,T&&l.arraySet(I.output,I.output,S,T,0),this.onData(x)):this.onData(l.shrinkBuf(I.output,I.next_out)))),I.avail_in===0&&I.avail_out===0&&(F=!0)}while((0<I.avail_in||I.avail_out===0)&&b!==a.Z_STREAM_END);return b===a.Z_STREAM_END&&(w=a.Z_FINISH),w===a.Z_FINISH?(b=r.inflateEnd(this.strm),this.onEnd(b),this.ended=!0,b===a.Z_OK):w!==a.Z_SYNC_FLUSH||(this.onEnd(a.Z_OK),!(I.avail_out=0))},u.prototype.onData=function(h){this.chunks.push(h)},u.prototype.onEnd=function(h){h===a.Z_OK&&(this.options.to==="string"?this.result=this.chunks.join(""):this.result=l.flattenChunks(this.chunks)),this.chunks=[],this.err=h,this.msg=this.strm.msg},n.Inflate=u,n.inflate=k,n.inflateRaw=function(h,y){return(y=y||{}).raw=!0,k(h,y)},n.ungzip=k},{"./utils/common":41,"./utils/strings":42,"./zlib/constants":44,"./zlib/gzheader":47,"./zlib/inflate":49,"./zlib/messages":51,"./zlib/zstream":53}],41:[function(e,o,n){var r=typeof Uint8Array<"u"&&typeof Uint16Array<"u"&&typeof Int32Array<"u";n.assign=function(a){for(var c=Array.prototype.slice.call(arguments,1);c.length;){var d=c.shift();if(d){if(typeof d!="object")throw new TypeError(d+"must be non-object");for(var f in d)d.hasOwnProperty(f)&&(a[f]=d[f])}}return a},n.shrinkBuf=function(a,c){return a.length===c?a:a.subarray?a.subarray(0,c):(a.length=c,a)};var l={arraySet:function(a,c,d,f,g){if(c.subarray&&a.subarray)a.set(c.subarray(d,d+f),g);else for(var u=0;u<f;u++)a[g+u]=c[d+u]},flattenChunks:function(a){var c,d,f,g,u,k;for(c=f=0,d=a.length;c<d;c++)f+=a[c].length;for(k=new Uint8Array(f),c=g=0,d=a.length;c<d;c++)u=a[c],k.set(u,g),g+=u.length;return k}},s={arraySet:function(a,c,d,f,g){for(var u=0;u<f;u++)a[g+u]=c[d+u]},flattenChunks:function(a){return[].concat.apply([],a)}};n.setTyped=function(a){a?(n.Buf8=Uint8Array,n.Buf16=Uint16Array,n.Buf32=Int32Array,n.assign(n,l)):(n.Buf8=Array,n.Buf16=Array,n.Buf32=Array,n.assign(n,s))},n.setTyped(r)},{}],42:[function(e,o,n){var r=e("./common"),l=!0,s=!0;try{String.fromCharCode.apply(null,[0])}catch{l=!1}try{String.fromCharCode.apply(null,new Uint8Array(1))}catch{s=!1}for(var a=new r.Buf8(256),c=0;c<256;c++)a[c]=252<=c?6:248<=c?5:240<=c?4:224<=c?3:192<=c?2:1;function d(f,g){if(g<65537&&(f.subarray&&s||!f.subarray&&l))return String.fromCharCode.apply(null,r.shrinkBuf(f,g));for(var u="",k=0;k<g;k++)u+=String.fromCharCode(f[k]);return u}a[254]=a[254]=1,n.string2buf=function(f){var g,u,k,h,y,b=f.length,w=0;for(h=0;h<b;h++)(64512&(u=f.charCodeAt(h)))==55296&&h+1<b&&(64512&(k=f.charCodeAt(h+1)))==56320&&(u=65536+(u-55296<<10)+(k-56320),h++),w+=u<128?1:u<2048?2:u<65536?3:4;for(g=new r.Buf8(w),h=y=0;y<w;h++)(64512&(u=f.charCodeAt(h)))==55296&&h+1<b&&(64512&(k=f.charCodeAt(h+1)))==56320&&(u=65536+(u-55296<<10)+(k-56320),h++),u<128?g[y++]=u:(u<2048?g[y++]=192|u>>>6:(u<65536?g[y++]=224|u>>>12:(g[y++]=240|u>>>18,g[y++]=128|u>>>12&63),g[y++]=128|u>>>6&63),g[y++]=128|63&u);return g},n.buf2binstring=function(f){return d(f,f.length)},n.binstring2buf=function(f){for(var g=new r.Buf8(f.length),u=0,k=g.length;u<k;u++)g[u]=f.charCodeAt(u);return g},n.buf2string=function(f,g){var u,k,h,y,b=g||f.length,w=new Array(2*b);for(u=k=0;u<b;)if((h=f[u++])<128)w[k++]=h;else if(4<(y=a[h]))w[k++]=65533,u+=y-1;else{for(h&=y===2?31:y===3?15:7;1<y&&u<b;)h=h<<6|63&f[u++],y--;1<y?w[k++]=65533:h<65536?w[k++]=h:(h-=65536,w[k++]=55296|h>>10&1023,w[k++]=56320|1023&h)}return d(w,k)},n.utf8border=function(f,g){var u;for((g=g||f.length)>f.length&&(g=f.length),u=g-1;0<=u&&(192&f[u])==128;)u--;return u<0||u===0?g:u+a[f[u]]>g?u:g}},{"./common":41}],43:[function(e,o,n){o.exports=function(r,l,s,a){for(var c=65535&r|0,d=r>>>16&65535|0,f=0;s!==0;){for(s-=f=2e3<s?2e3:s;d=d+(c=c+l[a++]|0)|0,--f;);c%=65521,d%=65521}return c|d<<16|0}},{}],44:[function(e,o,n){o.exports={Z_NO_FLUSH:0,Z_PARTIAL_FLUSH:1,Z_SYNC_FLUSH:2,Z_FULL_FLUSH:3,Z_FINISH:4,Z_BLOCK:5,Z_TREES:6,Z_OK:0,Z_STREAM_END:1,Z_NEED_DICT:2,Z_ERRNO:-1,Z_STREAM_ERROR:-2,Z_DATA_ERROR:-3,Z_BUF_ERROR:-5,Z_NO_COMPRESSION:0,Z_BEST_SPEED:1,Z_BEST_COMPRESSION:9,Z_DEFAULT_COMPRESSION:-1,Z_FILTERED:1,Z_HUFFMAN_ONLY:2,Z_RLE:3,Z_FIXED:4,Z_DEFAULT_STRATEGY:0,Z_BINARY:0,Z_TEXT:1,Z_UNKNOWN:2,Z_DEFLATED:8}},{}],45:[function(e,o,n){var r=(function(){for(var l,s=[],a=0;a<256;a++){l=a;for(var c=0;c<8;c++)l=1&l?3988292384^l>>>1:l>>>1;s[a]=l}return s})();o.exports=function(l,s,a,c){var d=r,f=c+a;l^=-1;for(var g=c;g<f;g++)l=l>>>8^d[255&(l^s[g])];return-1^l}},{}],46:[function(e,o,n){var r,l=e("../utils/common"),s=e("./trees"),a=e("./adler32"),c=e("./crc32"),d=e("./messages"),f=0,g=4,u=0,k=-2,h=-1,y=4,b=2,w=8,S=9,T=286,x=30,_=19,I=2*T+1,L=15,M=3,F=258,J=F+M+1,E=42,A=113,v=1,O=2,z=3,P=4;function K(p,j){return p.msg=d[j],j}function H(p){return(p<<1)-(4<p?9:0)}function et(p){for(var j=p.length;0<=--j;)p[j]=0}function V(p){var j=p.state,R=j.pending;R>p.avail_out&&(R=p.avail_out),R!==0&&(l.arraySet(p.output,j.pending_buf,j.pending_out,R,p.next_out),p.next_out+=R,j.pending_out+=R,p.total_out+=R,p.avail_out-=R,j.pending-=R,j.pending===0&&(j.pending_out=0))}function G(p,j){s._tr_flush_block(p,0<=p.block_start?p.block_start:-1,p.strstart-p.block_start,j),p.block_start=p.strstart,V(p.strm)}function lt(p,j){p.pending_buf[p.pending++]=j}function at(p,j){p.pending_buf[p.pending++]=j>>>8&255,p.pending_buf[p.pending++]=255&j}function ot(p,j){var R,C,$=p.max_chain_length,D=p.strstart,q=p.prev_length,W=p.nice_match,U=p.strstart>p.w_size-J?p.strstart-(p.w_size-J):0,Z=p.window,it=p.w_mask,Q=p.prev,ct=p.strstart+F,wt=Z[D+q-1],bt=Z[D+q];p.prev_length>=p.good_match&&($>>=2),W>p.lookahead&&(W=p.lookahead);do if(Z[(R=j)+q]===bt&&Z[R+q-1]===wt&&Z[R]===Z[D]&&Z[++R]===Z[D+1]){D+=2,R++;do;while(Z[++D]===Z[++R]&&Z[++D]===Z[++R]&&Z[++D]===Z[++R]&&Z[++D]===Z[++R]&&Z[++D]===Z[++R]&&Z[++D]===Z[++R]&&Z[++D]===Z[++R]&&Z[++D]===Z[++R]&&D<ct);if(C=F-(ct-D),D=ct-F,q<C){if(p.match_start=j,W<=(q=C))break;wt=Z[D+q-1],bt=Z[D+q]}}while((j=Q[j&it])>U&&--$!=0);return q<=p.lookahead?q:p.lookahead}function X(p){var j,R,C,$,D,q,W,U,Z,it,Q=p.w_size;do{if($=p.window_size-p.lookahead-p.strstart,p.strstart>=Q+(Q-J)){for(l.arraySet(p.window,p.window,Q,Q,0),p.match_start-=Q,p.strstart-=Q,p.block_start-=Q,j=R=p.hash_size;C=p.head[--j],p.head[j]=Q<=C?C-Q:0,--R;);for(j=R=Q;C=p.prev[--j],p.prev[j]=Q<=C?C-Q:0,--R;);$+=Q}if(p.strm.avail_in===0)break;if(q=p.strm,W=p.window,U=p.strstart+p.lookahead,Z=$,it=void 0,it=q.avail_in,Z<it&&(it=Z),R=it===0?0:(q.avail_in-=it,l.arraySet(W,q.input,q.next_in,it,U),q.state.wrap===1?q.adler=a(q.adler,W,it,U):q.state.wrap===2&&(q.adler=c(q.adler,W,it,U)),q.next_in+=it,q.total_in+=it,it),p.lookahead+=R,p.lookahead+p.insert>=M)for(D=p.strstart-p.insert,p.ins_h=p.window[D],p.ins_h=(p.ins_h<<p.hash_shift^p.window[D+1])&p.hash_mask;p.insert&&(p.ins_h=(p.ins_h<<p.hash_shift^p.window[D+M-1])&p.hash_mask,p.prev[D&p.w_mask]=p.head[p.ins_h],p.head[p.ins_h]=D,D++,p.insert--,!(p.lookahead+p.insert<M)););}while(p.lookahead<J&&p.strm.avail_in!==0)}function pt(p,j){for(var R,C;;){if(p.lookahead<J){if(X(p),p.lookahead<J&&j===f)return v;if(p.lookahead===0)break}if(R=0,p.lookahead>=M&&(p.ins_h=(p.ins_h<<p.hash_shift^p.window[p.strstart+M-1])&p.hash_mask,R=p.prev[p.strstart&p.w_mask]=p.head[p.ins_h],p.head[p.ins_h]=p.strstart),R!==0&&p.strstart-R<=p.w_size-J&&(p.match_length=ot(p,R)),p.match_length>=M)if(C=s._tr_tally(p,p.strstart-p.match_start,p.match_length-M),p.lookahead-=p.match_length,p.match_length<=p.max_lazy_match&&p.lookahead>=M){for(p.match_length--;p.strstart++,p.ins_h=(p.ins_h<<p.hash_shift^p.window[p.strstart+M-1])&p.hash_mask,R=p.prev[p.strstart&p.w_mask]=p.head[p.ins_h],p.head[p.ins_h]=p.strstart,--p.match_length!=0;);p.strstart++}else p.strstart+=p.match_length,p.match_length=0,p.ins_h=p.window[p.strstart],p.ins_h=(p.ins_h<<p.hash_shift^p.window[p.strstart+1])&p.hash_mask;else C=s._tr_tally(p,0,p.window[p.strstart]),p.lookahead--,p.strstart++;if(C&&(G(p,!1),p.strm.avail_out===0))return v}return p.insert=p.strstart<M-1?p.strstart:M-1,j===g?(G(p,!0),p.strm.avail_out===0?z:P):p.last_lit&&(G(p,!1),p.strm.avail_out===0)?v:O}function gt(p,j){for(var R,C,$;;){if(p.lookahead<J){if(X(p),p.lookahead<J&&j===f)return v;if(p.lookahead===0)break}if(R=0,p.lookahead>=M&&(p.ins_h=(p.ins_h<<p.hash_shift^p.window[p.strstart+M-1])&p.hash_mask,R=p.prev[p.strstart&p.w_mask]=p.head[p.ins_h],p.head[p.ins_h]=p.strstart),p.prev_length=p.match_length,p.prev_match=p.match_start,p.match_length=M-1,R!==0&&p.prev_length<p.max_lazy_match&&p.strstart-R<=p.w_size-J&&(p.match_length=ot(p,R),p.match_length<=5&&(p.strategy===1||p.match_length===M&&4096<p.strstart-p.match_start)&&(p.match_length=M-1)),p.prev_length>=M&&p.match_length<=p.prev_length){for($=p.strstart+p.lookahead-M,C=s._tr_tally(p,p.strstart-1-p.prev_match,p.prev_length-M),p.lookahead-=p.prev_length-1,p.prev_length-=2;++p.strstart<=$&&(p.ins_h=(p.ins_h<<p.hash_shift^p.window[p.strstart+M-1])&p.hash_mask,R=p.prev[p.strstart&p.w_mask]=p.head[p.ins_h],p.head[p.ins_h]=p.strstart),--p.prev_length!=0;);if(p.match_available=0,p.match_length=M-1,p.strstart++,C&&(G(p,!1),p.strm.avail_out===0))return v}else if(p.match_available){if((C=s._tr_tally(p,0,p.window[p.strstart-1]))&&G(p,!1),p.strstart++,p.lookahead--,p.strm.avail_out===0)return v}else p.match_available=1,p.strstart++,p.lookahead--}return p.match_available&&(C=s._tr_tally(p,0,p.window[p.strstart-1]),p.match_available=0),p.insert=p.strstart<M-1?p.strstart:M-1,j===g?(G(p,!0),p.strm.avail_out===0?z:P):p.last_lit&&(G(p,!1),p.strm.avail_out===0)?v:O}function Y(p,j,R,C,$){this.good_length=p,this.max_lazy=j,this.nice_length=R,this.max_chain=C,this.func=$}function rt(){this.strm=null,this.status=0,this.pending_buf=null,this.pending_buf_size=0,this.pending_out=0,this.pending=0,this.wrap=0,this.gzhead=null,this.gzindex=0,this.method=w,this.last_flush=-1,this.w_size=0,this.w_bits=0,this.w_mask=0,this.window=null,this.window_size=0,this.prev=null,this.head=null,this.ins_h=0,this.hash_size=0,this.hash_bits=0,this.hash_mask=0,this.hash_shift=0,this.block_start=0,this.match_length=0,this.prev_match=0,this.match_available=0,this.strstart=0,this.match_start=0,this.lookahead=0,this.prev_length=0,this.max_chain_length=0,this.max_lazy_match=0,this.level=0,this.strategy=0,this.good_match=0,this.nice_match=0,this.dyn_ltree=new l.Buf16(2*I),this.dyn_dtree=new l.Buf16(2*(2*x+1)),this.bl_tree=new l.Buf16(2*(2*_+1)),et(this.dyn_ltree),et(this.dyn_dtree),et(this.bl_tree),this.l_desc=null,this.d_desc=null,this.bl_desc=null,this.bl_count=new l.Buf16(L+1),this.heap=new l.Buf16(2*T+1),et(this.heap),this.heap_len=0,this.heap_max=0,this.depth=new l.Buf16(2*T+1),et(this.depth),this.l_buf=0,this.lit_bufsize=0,this.last_lit=0,this.d_buf=0,this.opt_len=0,this.static_len=0,this.matches=0,this.insert=0,this.bi_buf=0,this.bi_valid=0}function vt(p){var j;return p&&p.state?(p.total_in=p.total_out=0,p.data_type=b,(j=p.state).pending=0,j.pending_out=0,j.wrap<0&&(j.wrap=-j.wrap),j.status=j.wrap?E:A,p.adler=j.wrap===2?0:1,j.last_flush=f,s._tr_init(j),u):K(p,k)}function B(p){var j=vt(p);return j===u&&(function(R){R.window_size=2*R.w_size,et(R.head),R.max_lazy_match=r[R.level].max_lazy,R.good_match=r[R.level].good_length,R.nice_match=r[R.level].nice_length,R.max_chain_length=r[R.level].max_chain,R.strstart=0,R.block_start=0,R.lookahead=0,R.insert=0,R.match_length=R.prev_length=M-1,R.match_available=0,R.ins_h=0})(p.state),j}function N(p,j,R,C,$,D){if(!p)return k;var q=1;if(j===h&&(j=6),C<0?(q=0,C=-C):15<C&&(q=2,C-=16),$<1||S<$||R!==w||C<8||15<C||j<0||9<j||D<0||y<D)return K(p,k);C===8&&(C=9);var W=new rt;return(p.state=W).strm=p,W.wrap=q,W.gzhead=null,W.w_bits=C,W.w_size=1<<W.w_bits,W.w_mask=W.w_size-1,W.hash_bits=$+7,W.hash_size=1<<W.hash_bits,W.hash_mask=W.hash_size-1,W.hash_shift=~~((W.hash_bits+M-1)/M),W.window=new l.Buf8(2*W.w_size),W.head=new l.Buf16(W.hash_size),W.prev=new l.Buf16(W.w_size),W.lit_bufsize=1<<$+6,W.pending_buf_size=4*W.lit_bufsize,W.pending_buf=new l.Buf8(W.pending_buf_size),W.d_buf=1*W.lit_bufsize,W.l_buf=3*W.lit_bufsize,W.level=j,W.strategy=D,W.method=R,B(p)}r=[new Y(0,0,0,0,function(p,j){var R=65535;for(R>p.pending_buf_size-5&&(R=p.pending_buf_size-5);;){if(p.lookahead<=1){if(X(p),p.lookahead===0&&j===f)return v;if(p.lookahead===0)break}p.strstart+=p.lookahead,p.lookahead=0;var C=p.block_start+R;if((p.strstart===0||p.strstart>=C)&&(p.lookahead=p.strstart-C,p.strstart=C,G(p,!1),p.strm.avail_out===0)||p.strstart-p.block_start>=p.w_size-J&&(G(p,!1),p.strm.avail_out===0))return v}return p.insert=0,j===g?(G(p,!0),p.strm.avail_out===0?z:P):(p.strstart>p.block_start&&(G(p,!1),p.strm.avail_out),v)}),new Y(4,4,8,4,pt),new Y(4,5,16,8,pt),new Y(4,6,32,32,pt),new Y(4,4,16,16,gt),new Y(8,16,32,32,gt),new Y(8,16,128,128,gt),new Y(8,32,128,256,gt),new Y(32,128,258,1024,gt),new Y(32,258,258,4096,gt)],n.deflateInit=function(p,j){return N(p,j,w,15,8,0)},n.deflateInit2=N,n.deflateReset=B,n.deflateResetKeep=vt,n.deflateSetHeader=function(p,j){return p&&p.state?p.state.wrap!==2?k:(p.state.gzhead=j,u):k},n.deflate=function(p,j){var R,C,$,D;if(!p||!p.state||5<j||j<0)return p?K(p,k):k;if(C=p.state,!p.output||!p.input&&p.avail_in!==0||C.status===666&&j!==g)return K(p,p.avail_out===0?-5:k);if(C.strm=p,R=C.last_flush,C.last_flush=j,C.status===E)if(C.wrap===2)p.adler=0,lt(C,31),lt(C,139),lt(C,8),C.gzhead?(lt(C,(C.gzhead.text?1:0)+(C.gzhead.hcrc?2:0)+(C.gzhead.extra?4:0)+(C.gzhead.name?8:0)+(C.gzhead.comment?16:0)),lt(C,255&C.gzhead.time),lt(C,C.gzhead.time>>8&255),lt(C,C.gzhead.time>>16&255),lt(C,C.gzhead.time>>24&255),lt(C,C.level===9?2:2<=C.strategy||C.level<2?4:0),lt(C,255&C.gzhead.os),C.gzhead.extra&&C.gzhead.extra.length&&(lt(C,255&C.gzhead.extra.length),lt(C,C.gzhead.extra.length>>8&255)),C.gzhead.hcrc&&(p.adler=c(p.adler,C.pending_buf,C.pending,0)),C.gzindex=0,C.status=69):(lt(C,0),lt(C,0),lt(C,0),lt(C,0),lt(C,0),lt(C,C.level===9?2:2<=C.strategy||C.level<2?4:0),lt(C,3),C.status=A);else{var q=w+(C.w_bits-8<<4)<<8;q|=(2<=C.strategy||C.level<2?0:C.level<6?1:C.level===6?2:3)<<6,C.strstart!==0&&(q|=32),q+=31-q%31,C.status=A,at(C,q),C.strstart!==0&&(at(C,p.adler>>>16),at(C,65535&p.adler)),p.adler=1}if(C.status===69)if(C.gzhead.extra){for($=C.pending;C.gzindex<(65535&C.gzhead.extra.length)&&(C.pending!==C.pending_buf_size||(C.gzhead.hcrc&&C.pending>$&&(p.adler=c(p.adler,C.pending_buf,C.pending-$,$)),V(p),$=C.pending,C.pending!==C.pending_buf_size));)lt(C,255&C.gzhead.extra[C.gzindex]),C.gzindex++;C.gzhead.hcrc&&C.pending>$&&(p.adler=c(p.adler,C.pending_buf,C.pending-$,$)),C.gzindex===C.gzhead.extra.length&&(C.gzindex=0,C.status=73)}else C.status=73;if(C.status===73)if(C.gzhead.name){$=C.pending;do{if(C.pending===C.pending_buf_size&&(C.gzhead.hcrc&&C.pending>$&&(p.adler=c(p.adler,C.pending_buf,C.pending-$,$)),V(p),$=C.pending,C.pending===C.pending_buf_size)){D=1;break}D=C.gzindex<C.gzhead.name.length?255&C.gzhead.name.charCodeAt(C.gzindex++):0,lt(C,D)}while(D!==0);C.gzhead.hcrc&&C.pending>$&&(p.adler=c(p.adler,C.pending_buf,C.pending-$,$)),D===0&&(C.gzindex=0,C.status=91)}else C.status=91;if(C.status===91)if(C.gzhead.comment){$=C.pending;do{if(C.pending===C.pending_buf_size&&(C.gzhead.hcrc&&C.pending>$&&(p.adler=c(p.adler,C.pending_buf,C.pending-$,$)),V(p),$=C.pending,C.pending===C.pending_buf_size)){D=1;break}D=C.gzindex<C.gzhead.comment.length?255&C.gzhead.comment.charCodeAt(C.gzindex++):0,lt(C,D)}while(D!==0);C.gzhead.hcrc&&C.pending>$&&(p.adler=c(p.adler,C.pending_buf,C.pending-$,$)),D===0&&(C.status=103)}else C.status=103;if(C.status===103&&(C.gzhead.hcrc?(C.pending+2>C.pending_buf_size&&V(p),C.pending+2<=C.pending_buf_size&&(lt(C,255&p.adler),lt(C,p.adler>>8&255),p.adler=0,C.status=A)):C.status=A),C.pending!==0){if(V(p),p.avail_out===0)return C.last_flush=-1,u}else if(p.avail_in===0&&H(j)<=H(R)&&j!==g)return K(p,-5);if(C.status===666&&p.avail_in!==0)return K(p,-5);if(p.avail_in!==0||C.lookahead!==0||j!==f&&C.status!==666){var W=C.strategy===2?(function(U,Z){for(var it;;){if(U.lookahead===0&&(X(U),U.lookahead===0)){if(Z===f)return v;break}if(U.match_length=0,it=s._tr_tally(U,0,U.window[U.strstart]),U.lookahead--,U.strstart++,it&&(G(U,!1),U.strm.avail_out===0))return v}return U.insert=0,Z===g?(G(U,!0),U.strm.avail_out===0?z:P):U.last_lit&&(G(U,!1),U.strm.avail_out===0)?v:O})(C,j):C.strategy===3?(function(U,Z){for(var it,Q,ct,wt,bt=U.window;;){if(U.lookahead<=F){if(X(U),U.lookahead<=F&&Z===f)return v;if(U.lookahead===0)break}if(U.match_length=0,U.lookahead>=M&&0<U.strstart&&(Q=bt[ct=U.strstart-1])===bt[++ct]&&Q===bt[++ct]&&Q===bt[++ct]){wt=U.strstart+F;do;while(Q===bt[++ct]&&Q===bt[++ct]&&Q===bt[++ct]&&Q===bt[++ct]&&Q===bt[++ct]&&Q===bt[++ct]&&Q===bt[++ct]&&Q===bt[++ct]&&ct<wt);U.match_length=F-(wt-ct),U.match_length>U.lookahead&&(U.match_length=U.lookahead)}if(U.match_length>=M?(it=s._tr_tally(U,1,U.match_length-M),U.lookahead-=U.match_length,U.strstart+=U.match_length,U.match_length=0):(it=s._tr_tally(U,0,U.window[U.strstart]),U.lookahead--,U.strstart++),it&&(G(U,!1),U.strm.avail_out===0))return v}return U.insert=0,Z===g?(G(U,!0),U.strm.avail_out===0?z:P):U.last_lit&&(G(U,!1),U.strm.avail_out===0)?v:O})(C,j):r[C.level].func(C,j);if(W!==z&&W!==P||(C.status=666),W===v||W===z)return p.avail_out===0&&(C.last_flush=-1),u;if(W===O&&(j===1?s._tr_align(C):j!==5&&(s._tr_stored_block(C,0,0,!1),j===3&&(et(C.head),C.lookahead===0&&(C.strstart=0,C.block_start=0,C.insert=0))),V(p),p.avail_out===0))return C.last_flush=-1,u}return j!==g?u:C.wrap<=0?1:(C.wrap===2?(lt(C,255&p.adler),lt(C,p.adler>>8&255),lt(C,p.adler>>16&255),lt(C,p.adler>>24&255),lt(C,255&p.total_in),lt(C,p.total_in>>8&255),lt(C,p.total_in>>16&255),lt(C,p.total_in>>24&255)):(at(C,p.adler>>>16),at(C,65535&p.adler)),V(p),0<C.wrap&&(C.wrap=-C.wrap),C.pending!==0?u:1)},n.deflateEnd=function(p){var j;return p&&p.state?(j=p.state.status)!==E&&j!==69&&j!==73&&j!==91&&j!==103&&j!==A&&j!==666?K(p,k):(p.state=null,j===A?K(p,-3):u):k},n.deflateSetDictionary=function(p,j){var R,C,$,D,q,W,U,Z,it=j.length;if(!p||!p.state||(D=(R=p.state).wrap)===2||D===1&&R.status!==E||R.lookahead)return k;for(D===1&&(p.adler=a(p.adler,j,it,0)),R.wrap=0,it>=R.w_size&&(D===0&&(et(R.head),R.strstart=0,R.block_start=0,R.insert=0),Z=new l.Buf8(R.w_size),l.arraySet(Z,j,it-R.w_size,R.w_size,0),j=Z,it=R.w_size),q=p.avail_in,W=p.next_in,U=p.input,p.avail_in=it,p.next_in=0,p.input=j,X(R);R.lookahead>=M;){for(C=R.strstart,$=R.lookahead-(M-1);R.ins_h=(R.ins_h<<R.hash_shift^R.window[C+M-1])&R.hash_mask,R.prev[C&R.w_mask]=R.head[R.ins_h],R.head[R.ins_h]=C,C++,--$;);R.strstart=C,R.lookahead=M-1,X(R)}return R.strstart+=R.lookahead,R.block_start=R.strstart,R.insert=R.lookahead,R.lookahead=0,R.match_length=R.prev_length=M-1,R.match_available=0,p.next_in=W,p.input=U,p.avail_in=q,R.wrap=D,u},n.deflateInfo="pako deflate (from Nodeca project)"},{"../utils/common":41,"./adler32":43,"./crc32":45,"./messages":51,"./trees":52}],47:[function(e,o,n){o.exports=function(){this.text=0,this.time=0,this.xflags=0,this.os=0,this.extra=null,this.extra_len=0,this.name="",this.comment="",this.hcrc=0,this.done=!1}},{}],48:[function(e,o,n){o.exports=function(r,l){var s,a,c,d,f,g,u,k,h,y,b,w,S,T,x,_,I,L,M,F,J,E,A,v,O;s=r.state,a=r.next_in,v=r.input,c=a+(r.avail_in-5),d=r.next_out,O=r.output,f=d-(l-r.avail_out),g=d+(r.avail_out-257),u=s.dmax,k=s.wsize,h=s.whave,y=s.wnext,b=s.window,w=s.hold,S=s.bits,T=s.lencode,x=s.distcode,_=(1<<s.lenbits)-1,I=(1<<s.distbits)-1;t:do{S<15&&(w+=v[a++]<<S,S+=8,w+=v[a++]<<S,S+=8),L=T[w&_];e:for(;;){if(w>>>=M=L>>>24,S-=M,(M=L>>>16&255)===0)O[d++]=65535&L;else{if(!(16&M)){if((64&M)==0){L=T[(65535&L)+(w&(1<<M)-1)];continue e}if(32&M){s.mode=12;break t}r.msg="invalid literal/length code",s.mode=30;break t}F=65535&L,(M&=15)&&(S<M&&(w+=v[a++]<<S,S+=8),F+=w&(1<<M)-1,w>>>=M,S-=M),S<15&&(w+=v[a++]<<S,S+=8,w+=v[a++]<<S,S+=8),L=x[w&I];i:for(;;){if(w>>>=M=L>>>24,S-=M,!(16&(M=L>>>16&255))){if((64&M)==0){L=x[(65535&L)+(w&(1<<M)-1)];continue i}r.msg="invalid distance code",s.mode=30;break t}if(J=65535&L,S<(M&=15)&&(w+=v[a++]<<S,(S+=8)<M&&(w+=v[a++]<<S,S+=8)),u<(J+=w&(1<<M)-1)){r.msg="invalid distance too far back",s.mode=30;break t}if(w>>>=M,S-=M,(M=d-f)<J){if(h<(M=J-M)&&s.sane){r.msg="invalid distance too far back",s.mode=30;break t}if(A=b,(E=0)===y){if(E+=k-M,M<F){for(F-=M;O[d++]=b[E++],--M;);E=d-J,A=O}}else if(y<M){if(E+=k+y-M,(M-=y)<F){for(F-=M;O[d++]=b[E++],--M;);if(E=0,y<F){for(F-=M=y;O[d++]=b[E++],--M;);E=d-J,A=O}}}else if(E+=y-M,M<F){for(F-=M;O[d++]=b[E++],--M;);E=d-J,A=O}for(;2<F;)O[d++]=A[E++],O[d++]=A[E++],O[d++]=A[E++],F-=3;F&&(O[d++]=A[E++],1<F&&(O[d++]=A[E++]))}else{for(E=d-J;O[d++]=O[E++],O[d++]=O[E++],O[d++]=O[E++],2<(F-=3););F&&(O[d++]=O[E++],1<F&&(O[d++]=O[E++]))}break}}break}}while(a<c&&d<g);a-=F=S>>3,w&=(1<<(S-=F<<3))-1,r.next_in=a,r.next_out=d,r.avail_in=a<c?c-a+5:5-(a-c),r.avail_out=d<g?g-d+257:257-(d-g),s.hold=w,s.bits=S}},{}],49:[function(e,o,n){var r=e("../utils/common"),l=e("./adler32"),s=e("./crc32"),a=e("./inffast"),c=e("./inftrees"),d=1,f=2,g=0,u=-2,k=1,h=852,y=592;function b(E){return(E>>>24&255)+(E>>>8&65280)+((65280&E)<<8)+((255&E)<<24)}function w(){this.mode=0,this.last=!1,this.wrap=0,this.havedict=!1,this.flags=0,this.dmax=0,this.check=0,this.total=0,this.head=null,this.wbits=0,this.wsize=0,this.whave=0,this.wnext=0,this.window=null,this.hold=0,this.bits=0,this.length=0,this.offset=0,this.extra=0,this.lencode=null,this.distcode=null,this.lenbits=0,this.distbits=0,this.ncode=0,this.nlen=0,this.ndist=0,this.have=0,this.next=null,this.lens=new r.Buf16(320),this.work=new r.Buf16(288),this.lendyn=null,this.distdyn=null,this.sane=0,this.back=0,this.was=0}function S(E){var A;return E&&E.state?(A=E.state,E.total_in=E.total_out=A.total=0,E.msg="",A.wrap&&(E.adler=1&A.wrap),A.mode=k,A.last=0,A.havedict=0,A.dmax=32768,A.head=null,A.hold=0,A.bits=0,A.lencode=A.lendyn=new r.Buf32(h),A.distcode=A.distdyn=new r.Buf32(y),A.sane=1,A.back=-1,g):u}function T(E){var A;return E&&E.state?((A=E.state).wsize=0,A.whave=0,A.wnext=0,S(E)):u}function x(E,A){var v,O;return E&&E.state?(O=E.state,A<0?(v=0,A=-A):(v=1+(A>>4),A<48&&(A&=15)),A&&(A<8||15<A)?u:(O.window!==null&&O.wbits!==A&&(O.window=null),O.wrap=v,O.wbits=A,T(E))):u}function _(E,A){var v,O;return E?(O=new w,(E.state=O).window=null,(v=x(E,A))!==g&&(E.state=null),v):u}var I,L,M=!0;function F(E){if(M){var A;for(I=new r.Buf32(512),L=new r.Buf32(32),A=0;A<144;)E.lens[A++]=8;for(;A<256;)E.lens[A++]=9;for(;A<280;)E.lens[A++]=7;for(;A<288;)E.lens[A++]=8;for(c(d,E.lens,0,288,I,0,E.work,{bits:9}),A=0;A<32;)E.lens[A++]=5;c(f,E.lens,0,32,L,0,E.work,{bits:5}),M=!1}E.lencode=I,E.lenbits=9,E.distcode=L,E.distbits=5}function J(E,A,v,O){var z,P=E.state;return P.window===null&&(P.wsize=1<<P.wbits,P.wnext=0,P.whave=0,P.window=new r.Buf8(P.wsize)),O>=P.wsize?(r.arraySet(P.window,A,v-P.wsize,P.wsize,0),P.wnext=0,P.whave=P.wsize):(O<(z=P.wsize-P.wnext)&&(z=O),r.arraySet(P.window,A,v-O,z,P.wnext),(O-=z)?(r.arraySet(P.window,A,v-O,O,0),P.wnext=O,P.whave=P.wsize):(P.wnext+=z,P.wnext===P.wsize&&(P.wnext=0),P.whave<P.wsize&&(P.whave+=z))),0}n.inflateReset=T,n.inflateReset2=x,n.inflateResetKeep=S,n.inflateInit=function(E){return _(E,15)},n.inflateInit2=_,n.inflate=function(E,A){var v,O,z,P,K,H,et,V,G,lt,at,ot,X,pt,gt,Y,rt,vt,B,N,p,j,R,C,$=0,D=new r.Buf8(4),q=[16,17,18,0,8,7,9,6,10,5,11,4,12,3,13,2,14,1,15];if(!E||!E.state||!E.output||!E.input&&E.avail_in!==0)return u;(v=E.state).mode===12&&(v.mode=13),K=E.next_out,z=E.output,et=E.avail_out,P=E.next_in,O=E.input,H=E.avail_in,V=v.hold,G=v.bits,lt=H,at=et,j=g;t:for(;;)switch(v.mode){case k:if(v.wrap===0){v.mode=13;break}for(;G<16;){if(H===0)break t;H--,V+=O[P++]<<G,G+=8}if(2&v.wrap&&V===35615){D[v.check=0]=255&V,D[1]=V>>>8&255,v.check=s(v.check,D,2,0),G=V=0,v.mode=2;break}if(v.flags=0,v.head&&(v.head.done=!1),!(1&v.wrap)||(((255&V)<<8)+(V>>8))%31){E.msg="incorrect header check",v.mode=30;break}if((15&V)!=8){E.msg="unknown compression method",v.mode=30;break}if(G-=4,p=8+(15&(V>>>=4)),v.wbits===0)v.wbits=p;else if(p>v.wbits){E.msg="invalid window size",v.mode=30;break}v.dmax=1<<p,E.adler=v.check=1,v.mode=512&V?10:12,G=V=0;break;case 2:for(;G<16;){if(H===0)break t;H--,V+=O[P++]<<G,G+=8}if(v.flags=V,(255&v.flags)!=8){E.msg="unknown compression method",v.mode=30;break}if(57344&v.flags){E.msg="unknown header flags set",v.mode=30;break}v.head&&(v.head.text=V>>8&1),512&v.flags&&(D[0]=255&V,D[1]=V>>>8&255,v.check=s(v.check,D,2,0)),G=V=0,v.mode=3;case 3:for(;G<32;){if(H===0)break t;H--,V+=O[P++]<<G,G+=8}v.head&&(v.head.time=V),512&v.flags&&(D[0]=255&V,D[1]=V>>>8&255,D[2]=V>>>16&255,D[3]=V>>>24&255,v.check=s(v.check,D,4,0)),G=V=0,v.mode=4;case 4:for(;G<16;){if(H===0)break t;H--,V+=O[P++]<<G,G+=8}v.head&&(v.head.xflags=255&V,v.head.os=V>>8),512&v.flags&&(D[0]=255&V,D[1]=V>>>8&255,v.check=s(v.check,D,2,0)),G=V=0,v.mode=5;case 5:if(1024&v.flags){for(;G<16;){if(H===0)break t;H--,V+=O[P++]<<G,G+=8}v.length=V,v.head&&(v.head.extra_len=V),512&v.flags&&(D[0]=255&V,D[1]=V>>>8&255,v.check=s(v.check,D,2,0)),G=V=0}else v.head&&(v.head.extra=null);v.mode=6;case 6:if(1024&v.flags&&(H<(ot=v.length)&&(ot=H),ot&&(v.head&&(p=v.head.extra_len-v.length,v.head.extra||(v.head.extra=new Array(v.head.extra_len)),r.arraySet(v.head.extra,O,P,ot,p)),512&v.flags&&(v.check=s(v.check,O,ot,P)),H-=ot,P+=ot,v.length-=ot),v.length))break t;v.length=0,v.mode=7;case 7:if(2048&v.flags){if(H===0)break t;for(ot=0;p=O[P+ot++],v.head&&p&&v.length<65536&&(v.head.name+=String.fromCharCode(p)),p&&ot<H;);if(512&v.flags&&(v.check=s(v.check,O,ot,P)),H-=ot,P+=ot,p)break t}else v.head&&(v.head.name=null);v.length=0,v.mode=8;case 8:if(4096&v.flags){if(H===0)break t;for(ot=0;p=O[P+ot++],v.head&&p&&v.length<65536&&(v.head.comment+=String.fromCharCode(p)),p&&ot<H;);if(512&v.flags&&(v.check=s(v.check,O,ot,P)),H-=ot,P+=ot,p)break t}else v.head&&(v.head.comment=null);v.mode=9;case 9:if(512&v.flags){for(;G<16;){if(H===0)break t;H--,V+=O[P++]<<G,G+=8}if(V!==(65535&v.check)){E.msg="header crc mismatch",v.mode=30;break}G=V=0}v.head&&(v.head.hcrc=v.flags>>9&1,v.head.done=!0),E.adler=v.check=0,v.mode=12;break;case 10:for(;G<32;){if(H===0)break t;H--,V+=O[P++]<<G,G+=8}E.adler=v.check=b(V),G=V=0,v.mode=11;case 11:if(v.havedict===0)return E.next_out=K,E.avail_out=et,E.next_in=P,E.avail_in=H,v.hold=V,v.bits=G,2;E.adler=v.check=1,v.mode=12;case 12:if(A===5||A===6)break t;case 13:if(v.last){V>>>=7&G,G-=7&G,v.mode=27;break}for(;G<3;){if(H===0)break t;H--,V+=O[P++]<<G,G+=8}switch(v.last=1&V,G-=1,3&(V>>>=1)){case 0:v.mode=14;break;case 1:if(F(v),v.mode=20,A!==6)break;V>>>=2,G-=2;break t;case 2:v.mode=17;break;case 3:E.msg="invalid block type",v.mode=30}V>>>=2,G-=2;break;case 14:for(V>>>=7&G,G-=7&G;G<32;){if(H===0)break t;H--,V+=O[P++]<<G,G+=8}if((65535&V)!=(V>>>16^65535)){E.msg="invalid stored block lengths",v.mode=30;break}if(v.length=65535&V,G=V=0,v.mode=15,A===6)break t;case 15:v.mode=16;case 16:if(ot=v.length){if(H<ot&&(ot=H),et<ot&&(ot=et),ot===0)break t;r.arraySet(z,O,P,ot,K),H-=ot,P+=ot,et-=ot,K+=ot,v.length-=ot;break}v.mode=12;break;case 17:for(;G<14;){if(H===0)break t;H--,V+=O[P++]<<G,G+=8}if(v.nlen=257+(31&V),V>>>=5,G-=5,v.ndist=1+(31&V),V>>>=5,G-=5,v.ncode=4+(15&V),V>>>=4,G-=4,286<v.nlen||30<v.ndist){E.msg="too many length or distance symbols",v.mode=30;break}v.have=0,v.mode=18;case 18:for(;v.have<v.ncode;){for(;G<3;){if(H===0)break t;H--,V+=O[P++]<<G,G+=8}v.lens[q[v.have++]]=7&V,V>>>=3,G-=3}for(;v.have<19;)v.lens[q[v.have++]]=0;if(v.lencode=v.lendyn,v.lenbits=7,R={bits:v.lenbits},j=c(0,v.lens,0,19,v.lencode,0,v.work,R),v.lenbits=R.bits,j){E.msg="invalid code lengths set",v.mode=30;break}v.have=0,v.mode=19;case 19:for(;v.have<v.nlen+v.ndist;){for(;Y=($=v.lencode[V&(1<<v.lenbits)-1])>>>16&255,rt=65535&$,!((gt=$>>>24)<=G);){if(H===0)break t;H--,V+=O[P++]<<G,G+=8}if(rt<16)V>>>=gt,G-=gt,v.lens[v.have++]=rt;else{if(rt===16){for(C=gt+2;G<C;){if(H===0)break t;H--,V+=O[P++]<<G,G+=8}if(V>>>=gt,G-=gt,v.have===0){E.msg="invalid bit length repeat",v.mode=30;break}p=v.lens[v.have-1],ot=3+(3&V),V>>>=2,G-=2}else if(rt===17){for(C=gt+3;G<C;){if(H===0)break t;H--,V+=O[P++]<<G,G+=8}G-=gt,p=0,ot=3+(7&(V>>>=gt)),V>>>=3,G-=3}else{for(C=gt+7;G<C;){if(H===0)break t;H--,V+=O[P++]<<G,G+=8}G-=gt,p=0,ot=11+(127&(V>>>=gt)),V>>>=7,G-=7}if(v.have+ot>v.nlen+v.ndist){E.msg="invalid bit length repeat",v.mode=30;break}for(;ot--;)v.lens[v.have++]=p}}if(v.mode===30)break;if(v.lens[256]===0){E.msg="invalid code -- missing end-of-block",v.mode=30;break}if(v.lenbits=9,R={bits:v.lenbits},j=c(d,v.lens,0,v.nlen,v.lencode,0,v.work,R),v.lenbits=R.bits,j){E.msg="invalid literal/lengths set",v.mode=30;break}if(v.distbits=6,v.distcode=v.distdyn,R={bits:v.distbits},j=c(f,v.lens,v.nlen,v.ndist,v.distcode,0,v.work,R),v.distbits=R.bits,j){E.msg="invalid distances set",v.mode=30;break}if(v.mode=20,A===6)break t;case 20:v.mode=21;case 21:if(6<=H&&258<=et){E.next_out=K,E.avail_out=et,E.next_in=P,E.avail_in=H,v.hold=V,v.bits=G,a(E,at),K=E.next_out,z=E.output,et=E.avail_out,P=E.next_in,O=E.input,H=E.avail_in,V=v.hold,G=v.bits,v.mode===12&&(v.back=-1);break}for(v.back=0;Y=($=v.lencode[V&(1<<v.lenbits)-1])>>>16&255,rt=65535&$,!((gt=$>>>24)<=G);){if(H===0)break t;H--,V+=O[P++]<<G,G+=8}if(Y&&(240&Y)==0){for(vt=gt,B=Y,N=rt;Y=($=v.lencode[N+((V&(1<<vt+B)-1)>>vt)])>>>16&255,rt=65535&$,!(vt+(gt=$>>>24)<=G);){if(H===0)break t;H--,V+=O[P++]<<G,G+=8}V>>>=vt,G-=vt,v.back+=vt}if(V>>>=gt,G-=gt,v.back+=gt,v.length=rt,Y===0){v.mode=26;break}if(32&Y){v.back=-1,v.mode=12;break}if(64&Y){E.msg="invalid literal/length code",v.mode=30;break}v.extra=15&Y,v.mode=22;case 22:if(v.extra){for(C=v.extra;G<C;){if(H===0)break t;H--,V+=O[P++]<<G,G+=8}v.length+=V&(1<<v.extra)-1,V>>>=v.extra,G-=v.extra,v.back+=v.extra}v.was=v.length,v.mode=23;case 23:for(;Y=($=v.distcode[V&(1<<v.distbits)-1])>>>16&255,rt=65535&$,!((gt=$>>>24)<=G);){if(H===0)break t;H--,V+=O[P++]<<G,G+=8}if((240&Y)==0){for(vt=gt,B=Y,N=rt;Y=($=v.distcode[N+((V&(1<<vt+B)-1)>>vt)])>>>16&255,rt=65535&$,!(vt+(gt=$>>>24)<=G);){if(H===0)break t;H--,V+=O[P++]<<G,G+=8}V>>>=vt,G-=vt,v.back+=vt}if(V>>>=gt,G-=gt,v.back+=gt,64&Y){E.msg="invalid distance code",v.mode=30;break}v.offset=rt,v.extra=15&Y,v.mode=24;case 24:if(v.extra){for(C=v.extra;G<C;){if(H===0)break t;H--,V+=O[P++]<<G,G+=8}v.offset+=V&(1<<v.extra)-1,V>>>=v.extra,G-=v.extra,v.back+=v.extra}if(v.offset>v.dmax){E.msg="invalid distance too far back",v.mode=30;break}v.mode=25;case 25:if(et===0)break t;if(ot=at-et,v.offset>ot){if((ot=v.offset-ot)>v.whave&&v.sane){E.msg="invalid distance too far back",v.mode=30;break}X=ot>v.wnext?(ot-=v.wnext,v.wsize-ot):v.wnext-ot,ot>v.length&&(ot=v.length),pt=v.window}else pt=z,X=K-v.offset,ot=v.length;for(et<ot&&(ot=et),et-=ot,v.length-=ot;z[K++]=pt[X++],--ot;);v.length===0&&(v.mode=21);break;case 26:if(et===0)break t;z[K++]=v.length,et--,v.mode=21;break;case 27:if(v.wrap){for(;G<32;){if(H===0)break t;H--,V|=O[P++]<<G,G+=8}if(at-=et,E.total_out+=at,v.total+=at,at&&(E.adler=v.check=v.flags?s(v.check,z,at,K-at):l(v.check,z,at,K-at)),at=et,(v.flags?V:b(V))!==v.check){E.msg="incorrect data check",v.mode=30;break}G=V=0}v.mode=28;case 28:if(v.wrap&&v.flags){for(;G<32;){if(H===0)break t;H--,V+=O[P++]<<G,G+=8}if(V!==(4294967295&v.total)){E.msg="incorrect length check",v.mode=30;break}G=V=0}v.mode=29;case 29:j=1;break t;case 30:j=-3;break t;case 31:return-4;case 32:default:return u}return E.next_out=K,E.avail_out=et,E.next_in=P,E.avail_in=H,v.hold=V,v.bits=G,(v.wsize||at!==E.avail_out&&v.mode<30&&(v.mode<27||A!==4))&&J(E,E.output,E.next_out,at-E.avail_out)?(v.mode=31,-4):(lt-=E.avail_in,at-=E.avail_out,E.total_in+=lt,E.total_out+=at,v.total+=at,v.wrap&&at&&(E.adler=v.check=v.flags?s(v.check,z,at,E.next_out-at):l(v.check,z,at,E.next_out-at)),E.data_type=v.bits+(v.last?64:0)+(v.mode===12?128:0)+(v.mode===20||v.mode===15?256:0),(lt==0&&at===0||A===4)&&j===g&&(j=-5),j)},n.inflateEnd=function(E){if(!E||!E.state)return u;var A=E.state;return A.window&&(A.window=null),E.state=null,g},n.inflateGetHeader=function(E,A){var v;return E&&E.state?(2&(v=E.state).wrap)==0?u:((v.head=A).done=!1,g):u},n.inflateSetDictionary=function(E,A){var v,O=A.length;return E&&E.state?(v=E.state).wrap!==0&&v.mode!==11?u:v.mode===11&&l(1,A,O,0)!==v.check?-3:J(E,A,O,O)?(v.mode=31,-4):(v.havedict=1,g):u},n.inflateInfo="pako inflate (from Nodeca project)"},{"../utils/common":41,"./adler32":43,"./crc32":45,"./inffast":48,"./inftrees":50}],50:[function(e,o,n){var r=e("../utils/common"),l=[3,4,5,6,7,8,9,10,11,13,15,17,19,23,27,31,35,43,51,59,67,83,99,115,131,163,195,227,258,0,0],s=[16,16,16,16,16,16,16,16,17,17,17,17,18,18,18,18,19,19,19,19,20,20,20,20,21,21,21,21,16,72,78],a=[1,2,3,4,5,7,9,13,17,25,33,49,65,97,129,193,257,385,513,769,1025,1537,2049,3073,4097,6145,8193,12289,16385,24577,0,0],c=[16,16,16,16,17,17,18,18,19,19,20,20,21,21,22,22,23,23,24,24,25,25,26,26,27,27,28,28,29,29,64,64];o.exports=function(d,f,g,u,k,h,y,b){var w,S,T,x,_,I,L,M,F,J=b.bits,E=0,A=0,v=0,O=0,z=0,P=0,K=0,H=0,et=0,V=0,G=null,lt=0,at=new r.Buf16(16),ot=new r.Buf16(16),X=null,pt=0;for(E=0;E<=15;E++)at[E]=0;for(A=0;A<u;A++)at[f[g+A]]++;for(z=J,O=15;1<=O&&at[O]===0;O--);if(O<z&&(z=O),O===0)return k[h++]=20971520,k[h++]=20971520,b.bits=1,0;for(v=1;v<O&&at[v]===0;v++);for(z<v&&(z=v),E=H=1;E<=15;E++)if(H<<=1,(H-=at[E])<0)return-1;if(0<H&&(d===0||O!==1))return-1;for(ot[1]=0,E=1;E<15;E++)ot[E+1]=ot[E]+at[E];for(A=0;A<u;A++)f[g+A]!==0&&(y[ot[f[g+A]]++]=A);if(I=d===0?(G=X=y,19):d===1?(G=l,lt-=257,X=s,pt-=257,256):(G=a,X=c,-1),E=v,_=h,K=A=V=0,T=-1,x=(et=1<<(P=z))-1,d===1&&852<et||d===2&&592<et)return 1;for(;;){for(L=E-K,F=y[A]<I?(M=0,y[A]):y[A]>I?(M=X[pt+y[A]],G[lt+y[A]]):(M=96,0),w=1<<E-K,v=S=1<<P;k[_+(V>>K)+(S-=w)]=L<<24|M<<16|F|0,S!==0;);for(w=1<<E-1;V&w;)w>>=1;if(w!==0?(V&=w-1,V+=w):V=0,A++,--at[E]==0){if(E===O)break;E=f[g+y[A]]}if(z<E&&(V&x)!==T){for(K===0&&(K=z),_+=v,H=1<<(P=E-K);P+K<O&&!((H-=at[P+K])<=0);)P++,H<<=1;if(et+=1<<P,d===1&&852<et||d===2&&592<et)return 1;k[T=V&x]=z<<24|P<<16|_-h|0}}return V!==0&&(k[_+V]=E-K<<24|64<<16|0),b.bits=z,0}},{"../utils/common":41}],51:[function(e,o,n){o.exports={2:"need dictionary",1:"stream end",0:"","-1":"file error","-2":"stream error","-3":"data error","-4":"insufficient memory","-5":"buffer error","-6":"incompatible version"}},{}],52:[function(e,o,n){var r=e("../utils/common"),l=0,s=1;function a($){for(var D=$.length;0<=--D;)$[D]=0}var c=0,d=29,f=256,g=f+1+d,u=30,k=19,h=2*g+1,y=15,b=16,w=7,S=256,T=16,x=17,_=18,I=[0,0,0,0,0,0,0,0,1,1,1,1,2,2,2,2,3,3,3,3,4,4,4,4,5,5,5,5,0],L=[0,0,0,0,1,1,2,2,3,3,4,4,5,5,6,6,7,7,8,8,9,9,10,10,11,11,12,12,13,13],M=[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,2,3,7],F=[16,17,18,0,8,7,9,6,10,5,11,4,12,3,13,2,14,1,15],J=new Array(2*(g+2));a(J);var E=new Array(2*u);a(E);var A=new Array(512);a(A);var v=new Array(256);a(v);var O=new Array(d);a(O);var z,P,K,H=new Array(u);function et($,D,q,W,U){this.static_tree=$,this.extra_bits=D,this.extra_base=q,this.elems=W,this.max_length=U,this.has_stree=$&&$.length}function V($,D){this.dyn_tree=$,this.max_code=0,this.stat_desc=D}function G($){return $<256?A[$]:A[256+($>>>7)]}function lt($,D){$.pending_buf[$.pending++]=255&D,$.pending_buf[$.pending++]=D>>>8&255}function at($,D,q){$.bi_valid>b-q?($.bi_buf|=D<<$.bi_valid&65535,lt($,$.bi_buf),$.bi_buf=D>>b-$.bi_valid,$.bi_valid+=q-b):($.bi_buf|=D<<$.bi_valid&65535,$.bi_valid+=q)}function ot($,D,q){at($,q[2*D],q[2*D+1])}function X($,D){for(var q=0;q|=1&$,$>>>=1,q<<=1,0<--D;);return q>>>1}function pt($,D,q){var W,U,Z=new Array(y+1),it=0;for(W=1;W<=y;W++)Z[W]=it=it+q[W-1]<<1;for(U=0;U<=D;U++){var Q=$[2*U+1];Q!==0&&($[2*U]=X(Z[Q]++,Q))}}function gt($){var D;for(D=0;D<g;D++)$.dyn_ltree[2*D]=0;for(D=0;D<u;D++)$.dyn_dtree[2*D]=0;for(D=0;D<k;D++)$.bl_tree[2*D]=0;$.dyn_ltree[2*S]=1,$.opt_len=$.static_len=0,$.last_lit=$.matches=0}function Y($){8<$.bi_valid?lt($,$.bi_buf):0<$.bi_valid&&($.pending_buf[$.pending++]=$.bi_buf),$.bi_buf=0,$.bi_valid=0}function rt($,D,q,W){var U=2*D,Z=2*q;return $[U]<$[Z]||$[U]===$[Z]&&W[D]<=W[q]}function vt($,D,q){for(var W=$.heap[q],U=q<<1;U<=$.heap_len&&(U<$.heap_len&&rt(D,$.heap[U+1],$.heap[U],$.depth)&&U++,!rt(D,W,$.heap[U],$.depth));)$.heap[q]=$.heap[U],q=U,U<<=1;$.heap[q]=W}function B($,D,q){var W,U,Z,it,Q=0;if($.last_lit!==0)for(;W=$.pending_buf[$.d_buf+2*Q]<<8|$.pending_buf[$.d_buf+2*Q+1],U=$.pending_buf[$.l_buf+Q],Q++,W===0?ot($,U,D):(ot($,(Z=v[U])+f+1,D),(it=I[Z])!==0&&at($,U-=O[Z],it),ot($,Z=G(--W),q),(it=L[Z])!==0&&at($,W-=H[Z],it)),Q<$.last_lit;);ot($,S,D)}function N($,D){var q,W,U,Z=D.dyn_tree,it=D.stat_desc.static_tree,Q=D.stat_desc.has_stree,ct=D.stat_desc.elems,wt=-1;for($.heap_len=0,$.heap_max=h,q=0;q<ct;q++)Z[2*q]!==0?($.heap[++$.heap_len]=wt=q,$.depth[q]=0):Z[2*q+1]=0;for(;$.heap_len<2;)Z[2*(U=$.heap[++$.heap_len]=wt<2?++wt:0)]=1,$.depth[U]=0,$.opt_len--,Q&&($.static_len-=it[2*U+1]);for(D.max_code=wt,q=$.heap_len>>1;1<=q;q--)vt($,Z,q);for(U=ct;q=$.heap[1],$.heap[1]=$.heap[$.heap_len--],vt($,Z,1),W=$.heap[1],$.heap[--$.heap_max]=q,$.heap[--$.heap_max]=W,Z[2*U]=Z[2*q]+Z[2*W],$.depth[U]=($.depth[q]>=$.depth[W]?$.depth[q]:$.depth[W])+1,Z[2*q+1]=Z[2*W+1]=U,$.heap[1]=U++,vt($,Z,1),2<=$.heap_len;);$.heap[--$.heap_max]=$.heap[1],(function(bt,Tt){var Ht,Wt,Yt,Mt,je,Zt,Kt=Tt.dyn_tree,ii=Tt.max_code,Ii=Tt.stat_desc.static_tree,vo=Tt.stat_desc.has_stree,bo=Tt.stat_desc.extra_bits,In=Tt.stat_desc.extra_base,di=Tt.stat_desc.max_length,Ai=0;for(Mt=0;Mt<=y;Mt++)bt.bl_count[Mt]=0;for(Kt[2*bt.heap[bt.heap_max]+1]=0,Ht=bt.heap_max+1;Ht<h;Ht++)di<(Mt=Kt[2*Kt[2*(Wt=bt.heap[Ht])+1]+1]+1)&&(Mt=di,Ai++),Kt[2*Wt+1]=Mt,ii<Wt||(bt.bl_count[Mt]++,je=0,In<=Wt&&(je=bo[Wt-In]),Zt=Kt[2*Wt],bt.opt_len+=Zt*(Mt+je),vo&&(bt.static_len+=Zt*(Ii[2*Wt+1]+je)));if(Ai!==0){do{for(Mt=di-1;bt.bl_count[Mt]===0;)Mt--;bt.bl_count[Mt]--,bt.bl_count[Mt+1]+=2,bt.bl_count[di]--,Ai-=2}while(0<Ai);for(Mt=di;Mt!==0;Mt--)for(Wt=bt.bl_count[Mt];Wt!==0;)ii<(Yt=bt.heap[--Ht])||(Kt[2*Yt+1]!==Mt&&(bt.opt_len+=(Mt-Kt[2*Yt+1])*Kt[2*Yt],Kt[2*Yt+1]=Mt),Wt--)}})($,D),pt(Z,wt,$.bl_count)}function p($,D,q){var W,U,Z=-1,it=D[1],Q=0,ct=7,wt=4;for(it===0&&(ct=138,wt=3),D[2*(q+1)+1]=65535,W=0;W<=q;W++)U=it,it=D[2*(W+1)+1],++Q<ct&&U===it||(Q<wt?$.bl_tree[2*U]+=Q:U!==0?(U!==Z&&$.bl_tree[2*U]++,$.bl_tree[2*T]++):Q<=10?$.bl_tree[2*x]++:$.bl_tree[2*_]++,Z=U,wt=(Q=0)===it?(ct=138,3):U===it?(ct=6,3):(ct=7,4))}function j($,D,q){var W,U,Z=-1,it=D[1],Q=0,ct=7,wt=4;for(it===0&&(ct=138,wt=3),W=0;W<=q;W++)if(U=it,it=D[2*(W+1)+1],!(++Q<ct&&U===it)){if(Q<wt)for(;ot($,U,$.bl_tree),--Q!=0;);else U!==0?(U!==Z&&(ot($,U,$.bl_tree),Q--),ot($,T,$.bl_tree),at($,Q-3,2)):Q<=10?(ot($,x,$.bl_tree),at($,Q-3,3)):(ot($,_,$.bl_tree),at($,Q-11,7));Z=U,wt=(Q=0)===it?(ct=138,3):U===it?(ct=6,3):(ct=7,4)}}a(H);var R=!1;function C($,D,q,W){at($,(c<<1)+(W?1:0),3),(function(U,Z,it,Q){Y(U),lt(U,it),lt(U,~it),r.arraySet(U.pending_buf,U.window,Z,it,U.pending),U.pending+=it})($,D,q)}n._tr_init=function($){R||((function(){var D,q,W,U,Z,it=new Array(y+1);for(U=W=0;U<d-1;U++)for(O[U]=W,D=0;D<1<<I[U];D++)v[W++]=U;for(v[W-1]=U,U=Z=0;U<16;U++)for(H[U]=Z,D=0;D<1<<L[U];D++)A[Z++]=U;for(Z>>=7;U<u;U++)for(H[U]=Z<<7,D=0;D<1<<L[U]-7;D++)A[256+Z++]=U;for(q=0;q<=y;q++)it[q]=0;for(D=0;D<=143;)J[2*D+1]=8,D++,it[8]++;for(;D<=255;)J[2*D+1]=9,D++,it[9]++;for(;D<=279;)J[2*D+1]=7,D++,it[7]++;for(;D<=287;)J[2*D+1]=8,D++,it[8]++;for(pt(J,g+1,it),D=0;D<u;D++)E[2*D+1]=5,E[2*D]=X(D,5);z=new et(J,I,f+1,g,y),P=new et(E,L,0,u,y),K=new et(new Array(0),M,0,k,w)})(),R=!0),$.l_desc=new V($.dyn_ltree,z),$.d_desc=new V($.dyn_dtree,P),$.bl_desc=new V($.bl_tree,K),$.bi_buf=0,$.bi_valid=0,gt($)},n._tr_stored_block=C,n._tr_flush_block=function($,D,q,W){var U,Z,it=0;0<$.level?($.strm.data_type===2&&($.strm.data_type=(function(Q){var ct,wt=4093624447;for(ct=0;ct<=31;ct++,wt>>>=1)if(1&wt&&Q.dyn_ltree[2*ct]!==0)return l;if(Q.dyn_ltree[18]!==0||Q.dyn_ltree[20]!==0||Q.dyn_ltree[26]!==0)return s;for(ct=32;ct<f;ct++)if(Q.dyn_ltree[2*ct]!==0)return s;return l})($)),N($,$.l_desc),N($,$.d_desc),it=(function(Q){var ct;for(p(Q,Q.dyn_ltree,Q.l_desc.max_code),p(Q,Q.dyn_dtree,Q.d_desc.max_code),N(Q,Q.bl_desc),ct=k-1;3<=ct&&Q.bl_tree[2*F[ct]+1]===0;ct--);return Q.opt_len+=3*(ct+1)+5+5+4,ct})($),U=$.opt_len+3+7>>>3,(Z=$.static_len+3+7>>>3)<=U&&(U=Z)):U=Z=q+5,q+4<=U&&D!==-1?C($,D,q,W):$.strategy===4||Z===U?(at($,2+(W?1:0),3),B($,J,E)):(at($,4+(W?1:0),3),(function(Q,ct,wt,bt){var Tt;for(at(Q,ct-257,5),at(Q,wt-1,5),at(Q,bt-4,4),Tt=0;Tt<bt;Tt++)at(Q,Q.bl_tree[2*F[Tt]+1],3);j(Q,Q.dyn_ltree,ct-1),j(Q,Q.dyn_dtree,wt-1)})($,$.l_desc.max_code+1,$.d_desc.max_code+1,it+1),B($,$.dyn_ltree,$.dyn_dtree)),gt($),W&&Y($)},n._tr_tally=function($,D,q){return $.pending_buf[$.d_buf+2*$.last_lit]=D>>>8&255,$.pending_buf[$.d_buf+2*$.last_lit+1]=255&D,$.pending_buf[$.l_buf+$.last_lit]=255&q,$.last_lit++,D===0?$.dyn_ltree[2*q]++:($.matches++,D--,$.dyn_ltree[2*(v[q]+f+1)]++,$.dyn_dtree[2*G(D)]++),$.last_lit===$.lit_bufsize-1},n._tr_align=function($){at($,2,3),ot($,S,J),(function(D){D.bi_valid===16?(lt(D,D.bi_buf),D.bi_buf=0,D.bi_valid=0):8<=D.bi_valid&&(D.pending_buf[D.pending++]=255&D.bi_buf,D.bi_buf>>=8,D.bi_valid-=8)})($)}},{"../utils/common":41}],53:[function(e,o,n){o.exports=function(){this.input=null,this.next_in=0,this.avail_in=0,this.total_in=0,this.output=null,this.next_out=0,this.avail_out=0,this.total_out=0,this.msg="",this.state=null,this.data_type=2,this.adler=0}},{}],54:[function(e,o,n){(function(r){(function(l,s){if(!l.setImmediate){var a,c,d,f,g=1,u={},k=!1,h=l.document,y=Object.getPrototypeOf&&Object.getPrototypeOf(l);y=y&&y.setTimeout?y:l,a={}.toString.call(l.process)==="[object process]"?function(T){process.nextTick(function(){w(T)})}:(function(){if(l.postMessage&&!l.importScripts){var T=!0,x=l.onmessage;return l.onmessage=function(){T=!1},l.postMessage("","*"),l.onmessage=x,T}})()?(f="setImmediate$"+Math.random()+"$",l.addEventListener?l.addEventListener("message",S,!1):l.attachEvent("onmessage",S),function(T){l.postMessage(f+T,"*")}):l.MessageChannel?((d=new MessageChannel).port1.onmessage=function(T){w(T.data)},function(T){d.port2.postMessage(T)}):h&&"onreadystatechange"in h.createElement("script")?(c=h.documentElement,function(T){var x=h.createElement("script");x.onreadystatechange=function(){w(T),x.onreadystatechange=null,c.removeChild(x),x=null},c.appendChild(x)}):function(T){setTimeout(w,0,T)},y.setImmediate=function(T){typeof T!="function"&&(T=new Function(""+T));for(var x=new Array(arguments.length-1),_=0;_<x.length;_++)x[_]=arguments[_+1];var I={callback:T,args:x};return u[g]=I,a(g),g++},y.clearImmediate=b}function b(T){delete u[T]}function w(T){if(k)setTimeout(w,0,T);else{var x=u[T];if(x){k=!0;try{(function(_){var I=_.callback,L=_.args;switch(L.length){case 0:I();break;case 1:I(L[0]);break;case 2:I(L[0],L[1]);break;case 3:I(L[0],L[1],L[2]);break;default:I.apply(s,L)}})(x)}finally{b(T),k=!1}}}}function S(T){T.source===l&&typeof T.data=="string"&&T.data.indexOf(f)===0&&w(+T.data.slice(f.length))}})(typeof self>"u"?r===void 0?this:r:self)}).call(this,typeof Ln<"u"?Ln:typeof self<"u"?self:typeof window<"u"?window:{})},{}]},{},[10])(10)})})(Mo)),Mo.exports}var ov=nv();const sv=iv(ov),rv=/\.(?:png|jpe?g|gif|svg|webp|avif|ico|bmp|tiff?|mp4|webm|mp3|wav|ogg)$/i,lv=/\.(?:ts|js|mjs|cjs|jsx|tsx|vue|json|css|scss|less|html|py|rs|go|java|c|cpp|h|sh|bash|yaml|yml|toml)$/i;async function av(t){const i=await sv.loadAsync(t),e={},o=[];let n="",r="";const l=[];i.forEach((a,c)=>{!c.dir&&!a.startsWith("__MACOSX")&&!a.includes("node_modules/")&&l.push({path:a,file:c})});let s=l.find(a=>a.path.toLowerCase()==="slides.md");s||(s=l.find(a=>a.path.toLowerCase().endsWith("/slides.md"))),s||(s=l.find(a=>a.path.toLowerCase().endsWith(".md"))),s&&(n=await s.file.async("string"),r=s.path);for(const a of l){const c=a.path;if(c.toLowerCase().endsWith(".md")||lv.test(c)||c.includes("snippets/")){const d=await a.file.async("string");e[c]=d;const f=c.split("/");f.length>1&&(e[f.slice(1).join("/")]=d)}else if(rv.test(c)){const d=await a.file.async("uint8array"),f=c.split("/").pop()||c,g=typeof Blob<"u"?new Blob([d]):void 0;o.push({zipPath:c,fileName:f,data:d,blob:g})}}return{entryMarkdown:n,entryMarkdownPath:r,virtualFiles:e,assets:o}}function cv(t,i){if(Object.keys(i).length===0)return t;function e(n){const r=n.trim().replace(/^['"]|['"]$/g,""),l=r.split("/").pop()||r;if(i[r])return i[r];const s=r.replace(/^\.?\//,"");return i[s]?i[s]:i[l]?i[l]:null}function o(n){let r=n;return r=r.replace(/!\[(.*?)\]\((.*?)\)/g,(l,s,a)=>{const c=e(a);return c?`![${s}](${c})`:l}),r=r.replace(/\bsrc=["'](.*?)["']/gi,(l,s)=>{const a=e(s);return a?`src="${a}"`:l}),r}for(const n of t.slides)if(n.rawMarkdown=o(n.rawMarkdown),n.pageAttrs["custom-slidev-background"]){const r=n.pageAttrs["custom-slidev-background"],l=e(r);l&&(n.pageAttrs["custom-slidev-background"]=l)}if(t.flattenedMarkdown=o(t.flattenedMarkdown),t.docRootAttrs["custom-slidev-background"]){const n=t.docRootAttrs["custom-slidev-background"],r=e(n);r&&(t.docRootAttrs["custom-slidev-background"]=r)}return t}function Gl(t){try{if(typeof process<"u"&&typeof require<"u"){const i=require("fs");if(i.existsSync(t))return i.readFileSync(t,"utf-8")}}catch{}return null}function dv(t,i){const e=t.match(/^[ \t]*<<<[ \t]+([^\s]+)/);if(!e)return null;const o=e[1].trim(),n=o.indexOf("#"),r=n!==-1?o.slice(0,n):o,l=n!==-1?o.slice(n+1):"",s=r.replace(/^@\//,"").replace(/^\.\//,""),a=(i==null?void 0:i.virtualFiles)||{};let c=a[r]||a[s]||a[`./${s}`]||a[`@/${s}`];if(!c&&Object.keys(a).length>0){const u=s.split("/").pop();for(const[k,h]of Object.entries(a))if(k.endsWith(`/${s}`)||u&&k.endsWith(`/${u}`)){c=h;break}}if(!c){const u=[];if(i!=null&&i.baseDir)try{const k=require("path");u.push(k.resolve(i.baseDir,s)),u.push(k.resolve(i.baseDir,r))}catch{}try{const k=require("path");u.push(k.resolve(process.cwd(),s))}catch{}for(const k of u){const h=Gl(k);if(h!==null){c=h;break}}}if(!c){const u=Nl||{};if(c=u[r]||u[s]||u[`snippets/${s}`],!c){const k=s.split("/").pop();for(const[h,y]of Object.entries(u))if(h.endsWith(`/${s}`)||k&&h.endsWith(`/${k}`)){c=y;break}}}if(!c)return null;let d=c;if(l){const u=new RegExp(`(?:\\/\\/|\\/\\*|#)?\\s*#(?:region|REGION)\\s+${l}[^\\r\\n]*\\r?\\n([\\s\\S]*?)(?:\\/\\/|\\/\\*|#)?\\s*#(?:endregion|ENDREGION)\\s+${l}`,"i"),k=c.match(u);if(k){const h=c.match(/^(\/\/\s*Inside[^\r\n]+\r?\n)/i);d=(h?h[1]:"")+k[1].trimEnd()}}const f=s.match(/\.([a-zA-Z0-9]+)$/);return`\`\`\`${f?f[1]:""}
${d}
\`\`\``}function uv(t){let i=!1,e=!1;for(let o=0;o<t.length;o++){const n=t[o];if(n==="'"&&!e)i=!i;else if(n==='"'&&!i)e=!e;else if(n==="#"&&!i&&!e)return t.slice(0,o).trim()}return t.trim()}function Nn(t){const i={},e=t.split(/\r?\n/);let o=0;for(;o<e.length;){const n=e[o],r=n.trim();if(!r||r.startsWith("#")){o++;continue}const l=n.indexOf(":");if(l>0){const s=n.slice(0,l).trim();let a=n.slice(l+1).trim();if(a==="|"||a===">"){o++;const c=[];let d=-1;for(;o<e.length;){const f=e[o];if(!f.trim()){c.push(""),o++;continue}const u=f.match(/^(\s+)/),k=u?u[1].length:0;if(d===-1&&(d=k),k<d)break;c.push(f.slice(d)),o++}for(;c.length>0&&c[c.length-1]==="";)c.pop();i[s]=a===">"?c.join(" "):c.join(`
`);continue}if(a=uv(a),!a){let c=o+1;const d=[];let f=-1;for(;c<e.length;){const g=e[c],u=g.trim();if(!u||u.startsWith("#")){f!==-1&&d.push(""),c++;continue}const k=g.match(/^(\s+)/),h=k?k[1].length:0;if(f===-1)if(h>0)f=h;else break;if(h<f)break;d.push(g.slice(f)),c++}if(d.length>0){i[s]=Nn(d.join(`
`)),o=c;continue}}a.startsWith('"')&&a.endsWith('"')||a.startsWith("'")&&a.endsWith("'")?a=a.slice(1,-1):a==="true"?a=!0:a==="false"?a=!1:a==="null"?a=null:/^-?\d+(?:\.\d+)?$/.test(a)&&(a=Number(a)),i[s]=a}o++}return i}const fv=/^\s*```ya?ml([\s\S]*?)```/;function hr(t){let i={},e=t.trim();const o=e.match(/^---[^\n\r]*\r?\n([\s\S]*?)\r?\n---(?=[ \t]*(?:\r?\n|$))/);if(o&&!o[1].includes("```")){const r=Nn(o[1]);if(Object.keys(r).length>0||!o[1].trim())return i=r,e=e.slice(o[0].length).trim(),{frontmatter:i,content:e}}if(e.startsWith("---")){const r=e.match(/^---[^\n\r]*(?:\r?\n|$)/);r&&(e=e.slice(r[0].length).trim())}const n=e.match(fv);if(n)i=Nn(n[1]),e=e.slice(n[0].length).trim();else{const r=e.split(/\r?\n/),l=[];let s=0;for(let a=0;a<r.length;a++){const c=r[a].trim();if(!c){if(l.length>0){s=a+1;break}continue}if(/^[a-zA-Z0-9_-]+\s*:\s*.*/.test(c)&&!c.startsWith("<")&&!c.startsWith("#"))l.push(c);else{s=a;break}}l.length>0&&(i=Nn(l.join(`
`)),e=r.slice(s).join(`
`).trim())}return{frontmatter:i,content:e}}function pv(t){const i=t.split(/\r?\n/),e=[];let o=0,n=!1;function r(l){if(o>=l)return;const s=i.slice(o,l).join(`
`).trim();s&&e.push(s),o=l+1}for(let l=0;l<i.length;l++){const a=i[l].trimEnd();if(n){a.includes("-->")&&(n=!1);continue}if(a.startsWith("<!--")){a.includes("-->")||(n=!0);continue}if(a.startsWith("---")){r(l);const c=i[l+1];if(c&&c.trim()&&a.replace(/^-+/,"").trim()==="")for(o=l,l+=1;l<i.length&&i[l].trimEnd()!=="---";l++);}else if(a.trimStart().startsWith("```")){const c=a.match(/^\s*`+/),d=c?c[0].trim():"```";let f=l+1;for(;f<i.length&&!i[f].trimStart().startsWith(d);f++);f<i.length&&(l=f)}}return o<i.length&&r(i.length),e}function Fn(t,i={}){const{stripNotesFromMarkdown:e=!0,cleanVClicks:o=!0,cleanShikiLines:n=!0,cleanSlots:r=!0,isolateStyleTags:l=!0,cleanHtmlToMarkdown:s=!0,wrapSuperBlocks:a=!0,virtualFiles:c={}}=i;let d=t;d&&!d.trimStart().startsWith("---")&&(d=`---

${d.trimStart()}`);const f=pv(d),g={};let u="",k="",h=0;if(f.length>0){const F=f[0],J=hr(F),E=Object.keys(J.frontmatter).length>0,A=J.content.length>0;E&&!A&&f.length>1?(h=1,y(J.frontmatter)):E&&y(J.frontmatter)}function y(F){u=F.title||"",F.theme&&(g[un]=String(F.theme)),F.aspectRatio&&(g[fn]=String(F.aspectRatio)),F.highlighter&&(g[xr]=String(F.highlighter)),F.transition&&(g[pn]=String(F.transition)),F.colorSchema&&(g[_r]=String(F.colorSchema)),F.layout&&(g[dt]=String(F.layout)),F.background&&(g[zt]=String(F.background)),F.image&&(g[Se]=String(F.image)),F.class&&(g[Li]=String(F.class));for(const[J,E]of Object.entries(F))["theme","aspectRatio","highlighter","transition","colorSchema","title","layout","background","image","class"].includes(J)||(g[`custom-slidev-${J}`]=typeof E=="object"?JSON.stringify(E):String(E))}const b=[];let w=0,S=0,T=0,x=0;const _=new Set,I={};let L=1;for(let F=h;F<f.length;F++){const J=f[F],{frontmatter:E,content:A}=hr(J),v=J.match(/^\s*(?:---\s*)?src:\s*([^\n\r]+)/m),O=E.src||(v?v[1]:void 0);if(O){const Y=String(O).trim().replace(/^['"]|['"]$/g,"");let rt=c[Y]||c[Y.replace(/^\.\//,"")]||c[`pages/${Y.replace(/^.*pages\//,"")}`];if(!rt){const B=Y.replace(/^\.\//,""),N=[];if(i.baseDir)try{const p=require("path");N.push(p.resolve(i.baseDir,B)),N.push(p.resolve(i.baseDir,Y))}catch{}try{const p=require("path");N.push(p.resolve(process.cwd(),B)),N.push(p.resolve(process.cwd(),Y))}catch{}for(const p of N){const j=Gl(p);if(j!==null){rt=j;break}}}const vt={};E.layout&&(vt[dt]=String(E.layout)),E.transition&&(vt[qt]=String(E.transition)),E.background&&(vt[zt]=String(E.background)),E.image&&(vt[Se]=String(E.image)),E.class&&(vt[Li]=String(E.class));for(const[B,N]of Object.entries(E))["src","layout","transition","background","image","class"].includes(B)||(vt[`custom-slidev-${B}`]=typeof N=="object"?JSON.stringify(N):String(N));if(rt){const B=Fn(rt,{...i,virtualFiles:c});for(const N of B.slides){N.pageIndex=L++,N.pageAttrs={...vt,...N.pageAttrs},b.push(N);const p=N.pageAttrs[dt]||"default";I[p]=(I[p]||0)+1}continue}else{b.push({pageIndex:L++,pageAttrs:{...vt,"custom-slidev-src":Y},notes:"",rawMarkdown:`> 📄 **引入外部幻灯片页面**: \`${Y}\`
>
> *提示：如需展示该页面完整内容，请将关联子页面一同打包为 .zip 或通过本地工程导入。*`,hasVueComponent:!1,hasStyleTag:!1,assetReferences:[]});const B=vt[dt]||"default";I[B]=(I[B]||0)+1;continue}}const z={};E.layout&&(z[dt]=String(E.layout)),E.transition&&(z[qt]=String(E.transition)),E.background&&(z[zt]=String(E.background)),E.image&&(z[Se]=String(E.image)),E.class&&(z[Li]=String(E.class));for(const[Y,rt]of Object.entries(E))["layout","transition","background","image","class"].includes(Y)||(z[`custom-slidev-${Y}`]=typeof rt=="object"?JSON.stringify(rt):String(rt));let P=A;const K=[];let H=P.replace(/(?:^[ \t]*(`{3,}|~{3,})[^\n\r]*\r?\n[\s\S]*?\r?\n[ \t]*\1(?=[ \t]*(?:\r?\n|$)))/gm,Y=>{const rt=`__CODE_TOKEN_NOTE_${K.length}__`;return K.push(Y),rt});H=H.replace(/(`+)(?:[^\n\r`]|(?!\1)`)+?\1/g,Y=>{const rt=`__CODE_TOKEN_NOTE_${K.length}__`;return K.push(Y),rt});let et="";const V=Array.from(H.matchAll(/<!--([\s\S]*?)-->/g));if(V.length>0){const Y=V[V.length-1],rt=H.slice(Y.index+Y[0].length).trim();if(!rt||!rt.replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi,"").trim()){const B=Y[1].trim();B.startsWith("TODO:")||(et=B,w++),e&&(H=H.slice(0,Y.index).trimEnd()+H.slice(Y.index+Y[0].length))}}e&&(H=H.replace(/<!--(?![\s\S]*?TODO:)[\s\S]*?-->/g,"").trim());for(let Y=0;Y<K.length;Y++)H=H.replace(`__CODE_TOKEN_NOTE_${Y}__`,K[Y]);if(P=H,et){for(let vt=0;vt<K.length;vt++)et=et.replace(`__CODE_TOKEN_NOTE_${vt}__`,K[vt]);const rt=`> [!NOTE] 💡 演讲备注
${et.split(/\r?\n/).map(vt=>`> ${vt}`).join(`
`)}
{: custom-slidev-note="true"}`;P=P?`${P}

${rt}`:rt}let G=!1;if(/<style\b/i.test(P)){G=!0;const Y=P.match(/<style\b[^>]*>([\s\S]*?)<\/style>/gi);if(Y){for(const rt of Y){const vt=rt.replace(/<style\b[^>]*>|<\/style>/gi,"").trim();k=k?`${k}

${vt}`:vt}l&&(P=P.replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi,"").trim())}}const lt=P.match(/<v-click[^>]*>|<v-clicks[^>]*>|v-click=/g);lt&&(S+=lt.length);const at=P.match(/```\w+\s+\{[^}]+\}/g);at&&(T+=at.length);const ot=P.match(/::\w+::|<template\s+#[^>]+>/g);if(ot&&(x+=ot.length),P=P.replace(/^[ \t]*<<<[ \t]+([^\n\r]+)/gm,Y=>dv(Y,{...i,virtualFiles:c})||Y),o&&(P=P.replace(/<v-click(?:\s+at="[^"]*")?(?:\s+hide)?>\s*([\s\S]*?)\s*<\/v-click>/gi,"$1")),n&&(P=P.replace(/(^```\w+(?:[ \t]+\[[^\]]*\])?)[ \t]+\{[^}]+\}(?:[ \t]+\w+)?/gm,"$1"),P=P.replace(/^\$\$\s+\{[^}]+\}/gm,()=>"$$")),r&&(P=P.replace(/^::\w+::\s*$/gm,"")),s&&(P=Ra(P)),a){let Y=P.trim(),rt="";const vt=Y.lastIndexOf("> [!NOTE] 💡 演讲备注");if(vt!==-1&&(rt=Y.slice(vt),Y=Y.slice(0,vt).trim()),(E.layout==="image-left"||E.layout==="image-right")&&E.image){const B=String(E.image).trim(),N=E.layout==="image-left"?"image-left":"image-right",p=`![配图](${B})
{: custom-slidev-layout="${N}" }`;E.layout==="image-left"?Y=`{{{col

${p}

${Y}

}}}`:Y=`{{{col

${Y}

${p}

}}}`}if(E.background){const N=`![背景图](${String(E.background).trim()})
{: custom-slidev-role="background" }`;Y=Y?`${N}

${Y}`:N}P=rt?`${Y}

${rt}`:Y}const X=hv(P);z[zt]&&X.push(z[zt]),z[Se]&&X.push(z[Se]);for(const Y of X)_.add(Y);const pt=/<[A-Z][a-zA-Z0-9]+/.test(P),gt=z[dt]||(L===1?g[dt]||"cover":"default");I[gt]=(I[gt]||0)+1,b.push({pageIndex:L++,pageAttrs:z,notes:et,rawMarkdown:P,hasVueComponent:pt,hasStyleTag:G,assetReferences:X})}if(!u&&b.length>0){const F=b[0].rawMarkdown.match(/^#\s+(.+)$/m);F&&(u=F[1].trim())}k&&(g["custom-slidev-custom-css"]=k);let M=b.map(F=>`---

${F.rawMarkdown}`).join(`

`);return M.trimStart().startsWith("---")||(M=`---

${M.trimStart()}`),{docTitle:u||"Slidev 演示文稿",docRootAttrs:g,slides:b,totalSlides:b.length,stats:{totalNotes:w,totalVClicks:S,totalShikiHighlights:T,totalSlots:x,discoveredAssets:Array.from(_),layoutDistribution:I},flattenedMarkdown:M,customCss:k}}function hv(t){const i=[],e=/!\[.*?\]\((.*?)\)/g;let o;for(;(o=e.exec(t))!==null;){const r=o[1].split(/\s+/)[0].trim();r&&i.push(r)}const n=/<(?:img|video|source|audio)\b[^>]*src=["'](.*?)["']/gi;for(;(o=n.exec(t))!==null;){const r=o[1].trim();r&&i.push(r)}return i}function Zl(t){if(!t)return!1;const i=String(t.type||"").toLowerCase(),e=String(t.markdown||"").trim(),o=String(t.content||"").trim();return i==="tb"||i==="thematic-break"||i==="nodethematicbreak"||e==="---"||e==="***"||o==="---"||o==="***"}function mv(t){return(t.trim()||"Slidev 演示文稿").replace(/[\\/:*?"<>|]/g,"_")}async function gv(t,i,e=Dt){const o=t.filter(Zl);let n=0;if(o.length>=i.length)for(let r=0;r<i.length;r++){const l=i[r],s=o[r];s&&s.id&&Object.keys(l.pageAttrs||{}).length>0&&(await e(s.id,l.pageAttrs),n++)}else for(let r=1;r<i.length;r++){const l=i[r],s=o[r-1];s&&s.id&&Object.keys(l.pageAttrs||{}).length>0&&(await e(s.id,l.pageAttrs),n++)}return n}async function vv(t,i=Dt){let e=!1,o=0;for(const n of t){if(Zl(n)){e=!1;continue}const r=(n.markdown||n.content||"").trim();if(r==="::right::"||r.startsWith("::right::")){e=!0;continue}e&&n.id&&(await i(n.id,{[At]:"right"}).catch(()=>{}),o++)}return o}async function bv(t,i,e=br){const o={};if(!i||i.length===0)return o;const n=[];for(const r of i){const l=new File([r.data],r.fileName,{type:"application/octet-stream"});n.push(l)}try{const r=await e("/data/assets",n);if(r!=null&&r.succMap)for(const[l,s]of Object.entries(r.succMap))o[l]=String(s)}catch(r){console.warn("上传本地静态资产失败，保留原路径:",r)}return Object.keys(o).length>0&&cv(t,o),o}async function yv(t){var T;const{presentation:i,notebookId:e,docTitle:o,extractedAssets:n=[],uploadAssets:r=!0,autoPreview:l=!0,plugin:s,api:a={}}=t,c=a.uploadFn||br,d=a.createDocFn||va,f=a.setAttrsFn||Dt,g=a.getChildBlocksFn||Hn,u=a.openTabFn||mt.openTab,k=a.showMessageFn||mt.showMessage;r&&n.length>0&&await bv(i,n,c);const h=mv(o),y=`/${h}`,b=await d(e,y,i.flattenedMarkdown);if(!b)throw new Error("思源内核创建文档失败，未返回有效 DocumentId");const w=((T=i.slides[0])==null?void 0:T.pageAttrs)||{};await f(b,{...w,...i.docRootAttrs});const S=await g(b).catch(()=>[]);return Array.isArray(S)&&S.length>0&&(await gv(S,i.slides,f),await vv(S,f)),k(`🎉 成功导入 Slidev 演示文档《${h}》！`),l&&s&&(s.currentDocId=b,await u({app:s.app,doc:{id:b}}),s.openBottomPreviewTab&&s.openBottomPreviewTab()),b}function kv(t){const i=ft("file"),e=ft(!1),o=ft(!1),n=ft(""),r=ft(null),l=ft(null),s=ft(""),a=ft(0),c=ft(""),d=ft([]),f=ft(null),g=ft(""),u=ft([]),k=ft(""),h=ft(!0),y=ft(!0),b=ft(!0),w=ft(!0),S=St(()=>{const z=a.value;if(z===0)return"0 B";const P=1024,K=["B","KB","MB","GB"],H=Math.floor(Math.log(z)/Math.log(P));return`${(z/P**H).toFixed(1)} ${K[H]}`}),T=St(()=>{var z;return((z=f.value)==null?void 0:z.docRootAttrs["custom-slidev-theme"])||"default"}),x=St(()=>{var z;return d.value.length>0?d.value.length:((z=f.value)==null?void 0:z.stats.discoveredAssets.length)||0}),_=St(()=>{var P;const z=((P=f.value)==null?void 0:P.stats.layoutDistribution)||{};return Object.entries(z).map(([K,H])=>({name:K,count:H}))});async function I(z=ga){try{const P=await z();P!=null&&P.notebooks&&Array.isArray(P.notebooks)&&(u.value=P.notebooks.filter(K=>!K.closed),u.value.length>0&&!k.value&&(k.value=u.value[0].id))}catch(P){console.warn("获取笔记本列表失败:",P)}}function L(){var z;(z=r.value)==null||z.click()}function M(){l.value=null,s.value="",a.value=0,f.value=null,d.value=[],n.value=""}async function F(z){n.value="",l.value=z,s.value=z.name,a.value=z.size;try{if(z.name.toLowerCase().endsWith(".zip")){const K=await z.arrayBuffer(),H=await av(K);if(!H.entryMarkdown){n.value="未在 Zip 压缩包中找到 slides.md 或任何有效的 Markdown 入口文件";return}d.value=H.assets;const et=Fn(H.entryMarkdown,{stripNotesFromMarkdown:y.value,cleanHtmlToMarkdown:h.value,cleanSlots:!1,virtualFiles:H.virtualFiles});f.value=et,g.value=et.docTitle||z.name.replace(/\.zip$/i,"")}else{const K=await z.text();d.value=[];const H=z.path||"",et=H?H.replace(/[\\/][^\\/]+$/,""):"",V=Fn(K,{stripNotesFromMarkdown:y.value,cleanHtmlToMarkdown:h.value,cleanSlots:!1,baseDir:et||void 0});f.value=V,g.value=V.docTitle||z.name.replace(/\.md$/i,"")}}catch(P){console.error("解析文件失败:",P),n.value=`解析文件失败: ${P.message||String(P)}`}}function J(){if(n.value="",!c.value.trim()){f.value=null;return}try{const z=Fn(c.value,{stripNotesFromMarkdown:y.value,cleanHtmlToMarkdown:h.value,cleanSlots:!1});f.value=z,g.value=z.docTitle||"Slidev 演示文稿"}catch(z){n.value=`解析 Markdown 源码失败: ${z.message||String(z)}`}}async function E(){l.value?await F(l.value):c.value&&J()}async function A(z){const P=z.target;P.files&&P.files[0]&&await F(P.files[0])}async function v(z){var P;e.value=!1,(P=z.dataTransfer)!=null&&P.files&&z.dataTransfer.files[0]&&await F(z.dataTransfer.files[0])}async function O(z=t){if(f.value){if(!k.value&&u.value.length>0&&(k.value=u.value[0].id),!k.value){n.value="请先选择目标笔记本";return}o.value=!0,n.value="";try{return await yv({presentation:f.value,notebookId:k.value,docTitle:g.value,extractedAssets:d.value,uploadAssets:b.value,autoPreview:w.value,plugin:z})}catch(P){console.error("导入 Slidev 演示失败:",P),n.value=`导入执行失败: ${P.message||String(P)}`}finally{o.value=!1}}}return{inputMode:i,isDragging:e,isImporting:o,errorMessage:n,fileInputRef:r,selectedFile:l,selectedFileName:s,selectedFileSize:a,rawMarkdownText:c,extractedAssets:d,parsedPresentation:f,customDocTitle:g,notebooks:u,selectedNotebookId:k,optCleanHtml:h,optStripNotes:y,optUploadAssets:b,optAutoPreview:w,formattedFileSize:S,currentTheme:T,extractedAssetsCount:x,layoutChips:_,fetchNotebooks:I,triggerFileInput:L,clearFile:M,processFile:F,onFileSelected:A,onFileDrop:v,onTextChange:J,reprocessCurrentInput:E,handleConfirmImport:O}}const wv={class:"spm-import-dialog"},xv={class:"spm-tabs-header"},_v={class:"spm-dialog-body"},Sv={key:0,class:"spm-file-section"},Cv={key:0,class:"spm-dropzone-prompt"},$v={key:1,class:"spm-dropzone-active"},Iv={class:"spm-file-badge"},Av={class:"spm-file-size"},Tv={key:1,class:"spm-text-section"},Ev={key:2,class:"spm-error-banner"},Bv={key:3,class:"spm-preview-card"},Mv={class:"spm-config-grid"},Dv={class:"spm-form-item"},Lv={class:"spm-form-item"},Pv=["value"],Ov={class:"spm-stats-grid"},Rv={class:"spm-stat-box"},zv={class:"spm-stat-value"},Nv={class:"spm-stat-box"},Fv={class:"spm-stat-value"},jv={class:"spm-stat-box"},Hv={class:"spm-stat-value"},Uv={class:"spm-stat-box"},Wv={class:"spm-stat-value"},Vv={key:0,class:"spm-chips-row"},Kv={class:"spm-options-group"},qv={class:"spm-checkbox-label"},Gv={class:"spm-checkbox-label"},Zv={class:"spm-checkbox-label"},Yv={class:"spm-checkbox-label"},Jv={class:"spm-dialog-footer"},Xv=["disabled"],Qv=["disabled"],tb={key:0},eb={key:1},ib=he({__name:"SlidevImportDialog",emits:["close","success"],setup(t,{emit:i}){const e=i,o=Ge("plugin"),{inputMode:n,isDragging:r,isImporting:l,errorMessage:s,fileInputRef:a,selectedFileName:c,rawMarkdownText:d,extractedAssetsCount:f,parsedPresentation:g,customDocTitle:u,notebooks:k,selectedNotebookId:h,optCleanHtml:y,optStripNotes:b,optUploadAssets:w,optAutoPreview:S,formattedFileSize:T,currentTheme:x,layoutChips:_,fetchNotebooks:I,triggerFileInput:L,clearFile:M,onFileSelected:F,onFileDrop:J,onTextChange:E,reprocessCurrentInput:A,handleConfirmImport:v}=kv(o);Sn(async()=>{await I()});async function O(){const P=await v();P&&(e("success",{docId:P}),e("close"))}function z(){e("close")}return(P,K)=>(tt(),nt("div",{class:"spm-modal-overlay",onClick:Ce(z,["self"])},[m("div",wv,[m("div",{class:"spm-dialog-header"},[K[18]||(K[18]=m("div",{class:"spm-dialog-title"},[m("svg",{class:"spm-dialog-icon","aria-hidden":"true"},[m("use",{"xlink:href":"#iconSlidev"})]),m("span",null,"导入 Slidev 演示文档")],-1)),m("button",{class:"spm-close-btn",title:"关闭",onClick:z},"✕")]),m("div",xv,[m("button",{class:$t(["spm-tab-btn",{active:ht(n)==="file"}]),onClick:K[0]||(K[0]=H=>n.value="file")}," 📦 文件 / 压缩包导入 (.zip / .md) ",2),m("button",{class:$t(["spm-tab-btn",{active:ht(n)==="text"}]),onClick:K[1]||(K[1]=H=>n.value="text")}," 📝 粘贴 Markdown 源码 ",2)]),m("div",_v,[ht(n)==="file"?(tt(),nt("div",Sv,[m("div",{class:$t(["spm-dropzone",{dragover:ht(r),"has-file":!!ht(c)}]),onDragover:K[4]||(K[4]=Ce(H=>r.value=!0,["prevent"])),onDragleave:K[5]||(K[5]=Ce(H=>r.value=!1,["prevent"])),onDrop:K[6]||(K[6]=Ce((...H)=>ht(J)&&ht(J)(...H),["prevent"])),onClick:K[7]||(K[7]=(...H)=>ht(L)&&ht(L)(...H))},[m("input",{ref_key:"fileInputRef",ref:a,type:"file",accept:".zip,.md",class:"spm-hidden-input",onChange:K[2]||(K[2]=(...H)=>ht(F)&&ht(F)(...H))},null,544),ht(c)?(tt(),nt("div",$v,[m("span",Iv,"📄 "+_t(ht(c)),1),m("span",Av,"("+_t(ht(T))+")",1),m("button",{class:"spm-btn-text",onClick:K[3]||(K[3]=Ce((...H)=>ht(M)&&ht(M)(...H),["stop"]))},"更换文件")])):(tt(),nt("div",Cv,[...K[19]||(K[19]=[m("span",{class:"spm-dropzone-icon"},"📁",-1),m("p",{class:"spm-dropzone-text"},"点击选择文件，或直接拖拽文件至此处",-1),m("p",{class:"spm-dropzone-hint"},[Go(" 支持 Slidev 完整工程 "),m("strong",null,".zip"),Go("（自动解包 public/ 静态素材）或单文件 "),m("strong",null,".md")],-1)])]))],34)])):(tt(),nt("div",Tv,[_e(m("textarea",{"onUpdate:modelValue":K[8]||(K[8]=H=>Vt(d)?d.value=H:null),class:"spm-textarea spm-source-editor",rows:"8",placeholder:"在此直接粘贴包含 Frontmatter 的 Slidev slides.md 源码...",onInput:K[9]||(K[9]=(...H)=>ht(E)&&ht(E)(...H))},null,544),[[io,ht(d)]])])),ht(s)?(tt(),nt("div",Ev," ⚠️ "+_t(ht(s)),1)):Pt("",!0),ht(g)?(tt(),nt("div",Bv,[K[31]||(K[31]=m("div",{class:"spm-preview-card__header"},[m("span",null,"✨ 演示解析摘要"),m("span",{class:"spm-badge-success"},"预检就绪")],-1)),m("div",Mv,[m("div",Dv,[K[20]||(K[20]=m("label",{class:"spm-form-label"},"笔记文档标题",-1)),_e(m("input",{"onUpdate:modelValue":K[10]||(K[10]=H=>Vt(u)?u.value=H:null),class:"spm-input",placeholder:"思源新文档标题"},null,512),[[io,ht(u)]])]),m("div",Lv,[K[21]||(K[21]=m("label",{class:"spm-form-label"},"存放目标笔记本",-1)),_e(m("select",{"onUpdate:modelValue":K[11]||(K[11]=H=>Vt(h)?h.value=H:null),class:"spm-select"},[(tt(!0),nt(Ut,null,ge(ht(k),H=>(tt(),nt("option",{key:H.id,value:H.id},_t(H.name),9,Pv))),128))],512),[[au,ht(h)]])])]),m("div",Ov,[m("div",Rv,[m("span",zv,_t(ht(g).totalSlides),1),K[22]||(K[22]=m("span",{class:"spm-stat-label"},"幻灯片页数",-1))]),m("div",Nv,[m("span",Fv,_t(ht(x)),1),K[23]||(K[23]=m("span",{class:"spm-stat-label"},"演示主题",-1))]),m("div",jv,[m("span",Hv,_t(ht(g).stats.totalNotes),1),K[24]||(K[24]=m("span",{class:"spm-stat-label"},"演讲者提词",-1))]),m("div",Uv,[m("span",Wv,_t(ht(f)),1),K[25]||(K[25]=m("span",{class:"spm-stat-label"},"关联本地素材",-1))])]),ht(_).length>0?(tt(),nt("div",Vv,[K[26]||(K[26]=m("span",{class:"spm-chips-label"},"页面版式分布：",-1)),(tt(!0),nt(Ut,null,ge(ht(_),H=>(tt(),nt("span",{key:H.name,class:"spm-chip-badge"},_t(H.name)+": "+_t(H.count),1))),128))])):Pt("",!0),m("div",Kv,[m("label",qv,[_e(m("input",{"onUpdate:modelValue":K[12]||(K[12]=H=>Vt(y)?y.value=H:null),type:"checkbox",onChange:K[13]||(K[13]=(...H)=>ht(A)&&ht(A)(...H))},null,544),[[Dn,ht(y)]]),K[27]||(K[27]=m("span",null,"智能剥离展示型 HTML 容器为干净原生的 Markdown 笔记块",-1))]),m("label",Gv,[_e(m("input",{"onUpdate:modelValue":K[14]||(K[14]=H=>Vt(b)?b.value=H:null),type:"checkbox",onChange:K[15]||(K[15]=(...H)=>ht(A)&&ht(A)(...H))},null,544),[[Dn,ht(b)]]),K[28]||(K[28]=m("span",null,"提取演讲者提词到块属性并保持正文笔记清爽",-1))]),m("label",Zv,[_e(m("input",{"onUpdate:modelValue":K[16]||(K[16]=H=>Vt(w)?w.value=H:null),type:"checkbox"},null,512),[[Dn,ht(w)]]),K[29]||(K[29]=m("span",null,"自动上传关联素材至思源资产库并重写路径 (assets/...)",-1))]),m("label",Yv,[_e(m("input",{"onUpdate:modelValue":K[17]||(K[17]=H=>Vt(S)?S.value=H:null),type:"checkbox"},null,512),[[Dn,ht(S)]]),K[30]||(K[30]=m("span",null,"导入后自动打开新文档并开启下方分屏放映预览",-1))])])])):Pt("",!0)]),m("div",Jv,[m("button",{class:"spm-btn-secondary",disabled:ht(l),onClick:z}," 取消 ",8,Xv),m("button",{class:"spm-btn-primary",disabled:!ht(g)||ht(l),onClick:O},[ht(l)?(tt(),nt("span",tb,"⏳ 正在导入生成中...")):(tt(),nt("span",eb,"🚀 确认导入思源笔记"))],8,Qv)])])]))}}),nb=Be(ib,[["__scopeId","data-v-59ad789d"]]);function Yl(t){return t?t==="NodeThematicBreak"||t==="tb"||t==="thematic-break":!1}function ob(t,i){var s;if(!t||t.length===0)return null;const e=i.activeBlockId||"",o=i.currentTopBlockId||e,n=i.currentPageDividerId||"",r=i.activeBlockType||"";if(Yl(r)&&e){let a=t.find(c=>c.startBlockId===e);if(a||(a=t.find(c=>{var d,f;return((f=(d=c.blocks)==null?void 0:d[0])==null?void 0:f.id)===e}),a)||(a=t.find(c=>{var d;return(d=c.allBlockIds)==null?void 0:d.includes(e)}),a))return a}if(n){let a=t.find(c=>c.startBlockId===n);if(a||(a=t.find(c=>{var d,f;return((f=(d=c.blocks)==null?void 0:d[0])==null?void 0:f.id)===n}),a))return a}if(e){let a=t.find(d=>d.startBlockId===e);if(a||(a=t.find(d=>{var f,g;return((f=d.blocks)==null?void 0:f.some(u=>u.id===e))||((g=d.allBlockIds)==null?void 0:g.includes(e))}),a)||o&&o!==e&&(a=t.find(d=>{var f,g;return((f=d.blocks)==null?void 0:f.some(u=>u.id===o))||((g=d.allBlockIds)==null?void 0:g.includes(o))}),a)||(a=t.find(d=>{var f;return(f=d.noteBlocks)==null?void 0:f.some(g=>g.id===e||g.id===o)}),a))return a;const c=(s=i.activeBlockAttrs)==null?void 0:s[At];if(c&&["col-1","col-2","col-3"].includes(c)&&(a=t.find(d=>{var f,g;return((f=d.frontmatter)==null?void 0:f.layout)==="three-cols-header"||((g=d.blocks)==null?void 0:g.some(u=>u.slot==="col-1"||u.slot==="col-2"||u.slot==="col-3"))}),a))return a}return t[0]||null}function mr(t,i){const e=(t.blocks||[]).filter(l=>{const s=(l.content||l.rawMarkdown||"").trim();return s&&s!=="---"});if(e.length===0)return"本页暂无内容，建议过渡承接上下文。";const o=[],n=[];for(const l of e){const s=(l.content||l.rawMarkdown||"").trim();s&&(l.type==="h"||s.startsWith("#")?o.push(s.replace(/^#+\s*/,"")):n.push(s.slice(0,50)))}const r=[];return o.length>0&&r.push(`【核心重点】：${o.join("、")}`),n.length>0&&(r.push("【口播要点】："),n.slice(0,3).forEach((l,s)=>{r.push(`${s+1}. 讲解 ${l}`)})),r.push("【过渡提示】：注意观察听众反应，适时抛出互动提问。"),r.join(`
`)}async function Jl(t,i){const e=t.blocks&&t.blocks.length>0?t.blocks.map(o=>(o.content||o.rawMarkdown||"").trim()).filter(o=>o&&o!=="---").join(`
`):(t.rawMarkdown||"").replace(/^---\s*$/gm,"").trim();if(i&&e){const o=`你是一位专业的演讲教练。请根据以下幻灯片内容，提炼出简短精炼的演讲口播提词卡（Notes），包含核心观点与口播要点，总字数在 150 字以内：
${e}`;try{const n=await i(o);if(n&&n.trim())return{notes:n.trim(),isAiGenerated:!0}}catch(n){return{notes:mr(t),isAiGenerated:!1,error:(n==null?void 0:n.message)||"AI 调用异常"}}}return{notes:mr(t),isAiGenerated:!1}}async function sb(t,i){return(await Jl(t,i)).notes}function rb(t){let i=null;function e(A="已同步"){t.saveStatus.value=A,i&&(typeof window<"u"?window.clearTimeout(i):clearTimeout(i));const v=()=>{t.saveStatus.value=""};typeof window<"u"?i=window.setTimeout(v,1200):i=setTimeout(v,1200)}async function o(A){const v=t.activeBlockId.value||t.currentDocId.value;if(v){for(const[O,z]of Object.entries(A))t.activeBlockAttrs.value[O]=z;if(Rt.setBlockAttrOverride(v,A),Qt(v,A),dt in A){const O=A[dt];t.currentPageDividerLayout.value=O,t.targetSlide.value&&(t.targetSlide.value.frontmatter||(t.targetSlide.value.frontmatter={}),t.targetSlide.value.frontmatter.layout=O)}e("保存中...");try{await Dt(v,A),e("已同步"),t.plugin&&await t.plugin.compileCurrentDocument()}catch{e("同步失败")}}}async function n(A,v){const O=t.activeBlockId.value||t.currentDocId.value;if(O){t.activeBlockAttrs.value[A]=v,Rt.setBlockAttrOverride(O,{[A]:v}),Qt(O,{[A]:v}),A===dt&&(t.currentPageDividerLayout.value=v,t.targetSlide.value&&(t.targetSlide.value.frontmatter||(t.targetSlide.value.frontmatter={}),t.targetSlide.value.frontmatter.layout=v)),e("保存中...");try{await Dt(O,{[A]:v}),e("已同步"),t.plugin&&await t.plugin.compileCurrentDocument()}catch{e("同步失败")}}}async function r(A,v){var z;const O=t.currentDocId.value||t.activeBlockId.value;if(O){t.activeBlockAttrs.value[A]=v,Rt.setBlockAttrOverride(O,{[A]:v}),Qt(O,{[A]:v}),(z=t.latestDoc.value)!=null&&z.config&&(A===un&&(t.latestDoc.value.config.theme=v),A===fn&&(t.latestDoc.value.config.aspectRatio=v),A===pn&&(t.latestDoc.value.config.defaultTransition=v)),e("更新中...");try{await Dt(O,{[A]:v}),e("已更新"),t.plugin&&await t.plugin.compileCurrentDocument(O)}catch{e("更新失败")}}}async function l(){(t.videoAutoplay.value?"false":"true")==="true"?(await o({[bi]:"true",[Mi]:"true"}),t.activeBlockAttrs.value[bi]="true",t.activeBlockAttrs.value[Mi]="true"):(await n(bi,"false"),t.activeBlockAttrs.value[bi]="false")}async function s(){const A=t.videoLoop.value?"false":"true";await n(Un,A)}async function a(){const A=t.videoMuted.value?"false":"true";await n(Mi,A)}async function c(){const A=t.videoControls.value?"false":"true";await n(Wn,A)}async function d(A){var K;const v=t.activeBlockId.value;if(!v)return;const O=t.rawSnippet.value||"",z=li(O)||"",P=t.currentPageDividerId.value||t.currentDocId.value;if(A)if(A==="background"){const H={[jt]:"background",[dt]:""};P&&z&&(t.pageBackground.value=z,await Dt(P,{[zt]:z}).catch(()=>{}),Rt.setBlockAttrOverride(P,{[zt]:z}),Qt(P,{[zt]:z}),t.targetSlide.value&&(t.targetSlide.value.frontmatter||(t.targetSlide.value.frontmatter={}),t.targetSlide.value.frontmatter.background=z)),await o(H)}else(A===Vn||A===Kn)&&await o({[dt]:A,[jt]:""});else{const H={[jt]:"",[dt]:""};if(t.activeBlockAttrs.value[zt]==="true"&&(H[zt]=""),P&&z&&t.pageBackground.value===z&&(t.pageBackground.value="",await Dt(P,{[zt]:""}).catch(()=>{}),Rt.setBlockAttrOverride(P,{[zt]:""}),Qt(P,{[zt]:""}),(K=t.targetSlide.value)!=null&&K.frontmatter&&delete t.targetSlide.value.frontmatter.background),await o(H),typeof document<"u"){const et=document.querySelector(`.protyle-wysiwyg [data-node-id="${v}"]`),V=et==null?void 0:et.closest('[data-type="NodeListItem"]'),G=V==null?void 0:V.getAttribute("data-node-id");if(G&&G!==v){const lt={[dt]:"",[jt]:""};Qt(G,lt),Rt.setBlockAttrOverride(G,lt),await Dt(G,lt).catch(()=>{})}}}}async function f(A){var G,lt,at,ot,X,pt,gt,Y;const z=`> [!NOTE] 💡 演讲备注
${(A||"在此输入本页讲稿提词...").split(/\r?\n/).map(rt=>`> ${rt}`).join(`
`)}
{: custom-slidev-note="true"}`,P=((G=t.latestDoc.value)==null?void 0:G.slides)||[],K=t.targetSlide.value,H=K?P.findIndex(rt=>rt===K):-1;let et=null;if(H!==-1&&H<P.length-1){const rt=P[H+1];et=await Qi("markdown",z,rt.startBlockId)}else{const rt=((lt=K==null?void 0:K.noteBlocks)==null?void 0:lt.slice(-1)[0])||((at=K==null?void 0:K.blocks)==null?void 0:at.slice(-1)[0]),vt=(rt==null?void 0:rt.id)||(K==null?void 0:K.startBlockId);vt?et=await Qi("markdown",z,void 0,vt):et=await yr("markdown",z,t.currentDocId.value)}const V=((pt=(X=(ot=et==null?void 0:et[0])==null?void 0:ot.doOperations)==null?void 0:X[0])==null?void 0:pt.id)||((gt=et==null?void 0:et[0])==null?void 0:gt.id);return V&&(await Dt(V,{[Jt]:"true"}),Rt.setBlockAttrOverride(V,{[Jt]:"true"}),Si(V,(Y=t.plugin)==null?void 0:Y.app)),t.plugin&&await t.plugin.compileCurrentDocument(),V}async function g(){const A=t.activeBlockId.value;if(A)if(t.isNoteBlock.value){e("取消中...");try{await Dt(A,{[Jt]:"","slidev-note":""}),Rt.setBlockAttrOverride(A,{[Jt]:"","slidev-note":""}),Qt(A,{[Jt]:"","slidev-note":""}),delete t.activeBlockAttrs.value[Jt],delete t.activeBlockAttrs.value["slidev-note"],e("已取消备注"),mt.showMessage("已取消讲稿备注"),t.plugin&&await t.plugin.compileCurrentDocument()}catch(v){console.error("[SiYuanSlidev] 取消讲稿备注失败:",v),e("取消失败"),mt.showMessage("取消讲稿备注失败")}}else{e("转换中...");try{let v=t.rawSnippet.value;try{const K=await ya(A);K!=null&&K.kramdown&&(v=K.kramdown)}catch{}const P=`> [!NOTE] 💡 演讲备注
${(Ir(v)||v.replace(/<[^>]+>/g,"").trim()||"在此输入本页讲稿提词...").split(/\r?\n/).map(K=>`> ${K}`).join(`
`)}
{: custom-slidev-note="true"}`;await Ts("markdown",P,A),await Dt(A,{[Jt]:"true"}),Rt.setBlockAttrOverride(A,{[Jt]:"true"}),Qt(A,{[Jt]:"true"}),t.activeBlockAttrs.value[Jt]="true",t.activeBlockType.value="NodeCallout",e("已设为讲稿备注"),mt.showMessage("已转为讲稿备注提示块（不在幻灯片中渲染）"),t.plugin&&await t.plugin.compileCurrentDocument()}catch(v){console.error("[SiYuanSlidev] 转换讲稿备注提示块失败:",v),e("设置失败"),mt.showMessage("转为讲稿备注提示块失败")}}}async function u(){try{await f(),mt.showMessage("已在正文末尾插入讲稿备注提示块")}catch(A){mt.showMessage("插入讲稿备注块失败"),console.error(A)}}function k(){var O;const A=t.currentSlideNoteBlockId.value;if(!A){mt.showMessage("未找到本页关联的讲稿备注块");return}Si(A,(O=t.plugin)==null?void 0:O.app)?mt.showMessage("已在编辑区定位讲稿备注块"):mt.showMessage("定位讲稿备注块失败")}async function h(){var O;if(!t.currentDocId.value)return;const A=t.targetSlide.value||{startBlockId:t.activeBlockId.value||t.currentDocId.value,blocks:t.rawSnippet.value&&t.rawSnippet.value!=="---"?[{id:t.activeBlockId.value,type:t.activeBlockType.value,content:t.rawSnippet.value,rawMarkdown:""}]:[],rawMarkdown:t.rawSnippet.value&&t.rawSnippet.value!=="---"?t.rawSnippet.value:""};mt.showMessage("正在调用思源 AI 提炼本页讲稿提词...");const v=await Jl(A,kr);if(v.notes){const z=t.currentSlideNoteBlockId.value;if(z){const P=`> [!NOTE] 💡 演讲备注
${v.notes.split(/\r?\n/).map(K=>`> ${K}`).join(`
`)}
{: custom-slidev-note="true"}`;await Ts("markdown",P,z),await Dt(z,{[Jt]:"true"}),Rt.setBlockAttrOverride(z,{[Jt]:"true"}),Si(z,(O=t.plugin)==null?void 0:O.app)}else await f(v.notes);v.isAiGenerated?mt.showMessage("思源 AI 演讲提词卡生成成功！"):mt.showMessage("未获取到思源 AI 响应，已生成预设提词卡模板",5e3),t.plugin&&await t.plugin.compileCurrentDocument()}}function y(){t.elemClick.value?n(ke,""):n(ke,"+1")}function b(A){n(ke,A)}function w(A){n(Ne,A)}function S(A){(t.activeBlockAttrs.value[At]||"")===A?n(At,""):n(At,A)}function T(A){t.elemShikiLines.value=A,n(Ci,A)}function x(A){t.elemMaxHeight.value=A,n(hn,A)}async function _(){const A=t.currentSlideLayout.value==="three-cols-header";await n(At,A?"col-1":"left"),mt.showMessage(A?"已将当前块设置为第 1 栏 (col-1)":"已将当前块设置为双栏左栏 (left)")}async function I(){const A=t.activeBlockId.value;if(!A)return;const v={[ke]:"",[Ne]:"",[At]:"",[Ci]:"",[hn]:"",[Jt]:"","slidev-note":"",[dt]:"",[jt]:"",[qt]:"",[zt]:"",[Se]:"",[bi]:"",[Un]:"",[Mi]:"",[Wn]:""};if(Qt(A,v),await Dt(A,v),Rt.clearBlockAttrOverride(A),typeof document<"u"){const O=document.querySelector(`.protyle-wysiwyg [data-node-id="${A}"]`),z=O==null?void 0:O.closest('[data-type="NodeListItem"]'),P=z==null?void 0:z.getAttribute("data-node-id");P&&P!==A&&(Qt(P,v),await Dt(P,v).catch(()=>{}),Rt.clearBlockAttrOverride(P))}t.activeBlockAttrs.value={},t.elemShikiLines.value="",t.elemMaxHeight.value="",t.pageBackground.value="",t.pageImage.value="",mt.showMessage("已清除本块演示属性"),t.plugin&&await t.plugin.compileCurrentDocument()}async function L(){if(t.activeBlockId.value)try{await Qi("markdown","---",t.activeBlockId.value,void 0),mt.showMessage("已在上方插入分页符 (---)"),t.plugin&&t.plugin.compileCurrentDocument()}catch{mt.showMessage("插入分页符失败")}}async function M(){const A=t.activeBlockId.value||t.currentDocId.value;if(A)try{await Qi("markdown","---",void 0,A),mt.showMessage("已在下方插入分页符 (---)"),t.plugin&&t.plugin.compileCurrentDocument()}catch{mt.showMessage("插入分页符失败")}}async function F(){if(t.activeBlockId.value)try{await ba(t.activeBlockId.value),mt.showMessage("已删除该分页符"),t.activeBlockId.value="",t.activeBlockType.value="",t.plugin&&t.plugin.compileCurrentDocument()}catch{mt.showMessage("删除失败")}}function J(){if(!t.latestDoc.value){mt.showMessage("请先在主编辑区打开幻灯片文档");return}const A=Vl(t.latestDoc.value);Kl("presentation.html",A)&&mt.showMessage("已开始下载单文件离线 HTML 演示包")}function E(){if(!t.latestDoc.value){mt.showMessage("请先在主编辑区打开幻灯片文档");return}ql(t.latestDoc.value)&&mt.showMessage("已唤起打印视窗，请在打印选项中选择「另存为 PDF」")}return{triggerSaveNotice:e,saveAttrs:o,saveAttr:n,saveDocAttr:r,onToggleVideoAutoplay:l,onToggleVideoLoop:s,onToggleVideoMuted:a,onToggleVideoControls:c,onImageRoleChange:d,onToggleNoteBlock:g,createNoteBlockOnCurrentSlide:f,onAddNoteBlock:u,onLocateNoteBlock:k,onGenerateNotesWithAI:h,toggleElemClick:y,onElemClickStepChange:b,onElemMotionChange:w,onElemSlotChange:S,onElemShikiLinesChange:T,onElemMaxHeightChange:x,onSetTwoColsContrast:_,onClearBlockAttrs:I,onInsertDividerBefore:L,onInsertDividerAfter:M,onDeleteCurrentBlock:F,onExportHtml:J,onExportPdf:E}}const lb={class:"spm-slidev-inspector"},ab={class:"spm-inspector-topbar"},cb={class:"spm-inspector-title"},db={class:"slidev-icon",style:{fill:"none !important"},"aria-hidden":"true",viewBox:"0 0 24 24"},ub={class:"spm-inspector-topbar-actions"},fb={class:"spm-target-banner"},pb={class:"spm-target-info"},hb=["aria-label"],mb={key:0,class:"spm-save-status"},gb=["title"],vb={class:"spm-inspector-body"},bb=he({__name:"SlidevInspectorDockView",setup(t,{expose:i}){const e=Ge("plugin"),o=ft(!1);function n(st){o.value=!1,c.value=st.docId,e!=null&&e.compileCurrentDocument&&e.compileCurrentDocument(st.docId)}const r=ft(""),l=ft(""),s=ft({}),a=ft(""),c=ft(""),d=ft(""),f=ft(""),g=ft(""),u=ft(null),k=ft(""),h=ft("");function y(){var xt;const st=r.value||c.value;st&&typeof navigator<"u"&&(xt=navigator==null?void 0:navigator.clipboard)!=null&&xt.writeText&&navigator.clipboard.writeText(st).then(()=>{h.value="已复制！",setTimeout(()=>{h.value=""},1500)}).catch(()=>{})}const b=St(()=>Yl(l.value)),w=St(()=>l.value==="NodeCodeBlock"),S=ft(!1),T=St(()=>{if(S.value||j.value)return!0;const st=a.value||"";return!!li(st)}),x=St(()=>{const st=l.value||"";if(st==="NodeVideo"||st==="video")return!0;const xt=a.value||"";return!!(/<video\b/i.test(xt)||/\.mp4\b/i.test(xt))}),_=St(()=>!r.value||r.value===c.value||l.value==="doc"||l.value==="NodeDocument"),I=St(()=>{const st=r.value||c.value||"";return st.length>8?st.slice(-8):st||"无"}),L=St(()=>a.value?a.value.replace(/<[^>]+>/g,"").replace(/[\r\n]+/g," ").trim().slice(0,45):""),M=St(()=>{if(b.value)return"分页符 (---)";if(_.value)return"全局文档";if(x.value)return"视频块";switch(l.value){case"NodeHeading":return"标题块";case"NodeParagraph":return"段落块";case"NodeCodeBlock":return"代码块";case"NodeVideo":return"视频块";case"NodeList":case"NodeListItem":return"列表项";case"NodeBlockquote":return"引述块";case"NodeTable":return"表格块";case"NodeSuperBlock":case"s":case"sb":return"超级块";default:return"内容块"}}),F=St(()=>b.value?"tag-divider":_.value?"tag-doc":"tag-block"),J=St(()=>s.value[dt]||"default"),E=St(()=>s.value[qt]||"slide-left"),A=ft(""),v=ft(""),O=St(()=>s.value[nn]||"inherit"),z=St(()=>{var st;return ob((st=u.value)==null?void 0:st.slides,{activeBlockId:r.value,activeBlockType:l.value,currentTopBlockId:d.value,currentPageDividerId:f.value,activeBlockAttrs:s.value})}),P=St(()=>{var st;return((st=z.value)==null?void 0:st.notes)||""}),K=St(()=>{var st,xt,Lt;return((Lt=(xt=(st=z.value)==null?void 0:st.noteBlocks)==null?void 0:xt[0])==null?void 0:Lt.id)||""}),H=St(()=>{var me,Gi,Zi,Ti,Is,As;if(b.value){const ne=s.value[dt]||s.value["custom-slidev-layout"];if(ne)return ne}const st=s.value[At]||s.value["custom-slidev-slot"];if(st&&["col-1","col-2","col-3"].includes(st))return"three-cols-header";if(g.value)return g.value;const xt=f.value||(b.value?r.value:"");if(xt){const ne=Rt.getBlockAttrOverride(xt);if(ne!=null&&ne[dt])return ne[dt]}if(xt&&((me=u.value)!=null&&me.slides)){const ne=u.value.slides.find(aa=>aa.startBlockId===xt);if((Gi=ne==null?void 0:ne.frontmatter)!=null&&Gi.layout)return ne.frontmatter.layout}if((Ti=(Zi=z.value)==null?void 0:Zi.frontmatter)!=null&&Ti.layout)return z.value.frontmatter.layout;if((As=(Is=z.value)==null?void 0:Is.blocks)!=null&&As.some(ne=>ne.slot==="col-1"||ne.slot==="col-2"||ne.slot==="col-3"))return"three-cols-header";const Lt=Rt.getBlockAttrOverride(c.value);return Lt!=null&&Lt[dt]?Lt[dt]:"default"}),et=St(()=>{var st;return((st=z.value)==null?void 0:st.pageIndex)||1}),V=St(()=>!!(s.value[Jt]||s.value["slidev-note"])),G=St(()=>{var xt;if(s.value[ke])return s.value[ke];const st=r.value;if(st&&((xt=z.value)!=null&&xt.blocks)){const Lt=z.value.blocks.find(me=>me.id===st);if(Lt!=null&&Lt.clicks)return Lt.clicks}return""}),lt=St(()=>{var xt;if(s.value[Ne])return s.value[Ne];const st=r.value;if(st&&((xt=z.value)!=null&&xt.blocks)){const Lt=z.value.blocks.find(me=>me.id===st);if(Lt!=null&&Lt.motion)return typeof Lt.motion=="string"?Lt.motion:JSON.stringify(Lt.motion)}return""}),at=St(()=>{var xt;if(s.value[At])return s.value[At];const st=r.value;if(st&&((xt=z.value)!=null&&xt.blocks)){const Lt=z.value.blocks.find(me=>me.id===st);if(Lt!=null&&Lt.slot)return Lt.slot}return""}),ot=ft(""),X=ft(""),pt=St(()=>s.value[bi]==="true"),gt=St(()=>s.value[Un]==="true"),Y=St(()=>s.value[Mi]==="true"),rt=St(()=>s.value[Wn]!=="false"),vt=St(()=>{var st,xt;return((xt=(st=u.value)==null?void 0:st.config)==null?void 0:xt.theme)||s.value[un]||"default"}),B=St(()=>{var st,xt;return((xt=(st=u.value)==null?void 0:st.config)==null?void 0:xt.aspectRatio)||s.value[fn]||"16/9"}),N=St(()=>{var st,xt;return((xt=(st=u.value)==null?void 0:st.config)==null?void 0:xt.defaultTransition)||s.value[pn]||"slide-left"}),p=St(()=>{var st,xt;return((xt=(st=u.value)==null?void 0:st.config)==null?void 0:xt.spacing)||s.value[Po]||"normal"}),j=St(()=>{var Gi,Zi;if((s.value[jt]||s.value["slidev-role"])===Sr||s.value[zt]==="true")return"background";const xt=s.value[dt]||s.value["slidev-layout"];if(xt==="image-left"||xt==="image-right")return xt;const Lt=a.value||"",me=li(Lt);if(me&&((Zi=(Gi=z.value)==null?void 0:Gi.frontmatter)!=null&&Zi.background)){const Ti=z.value.frontmatter.background;if(Ti===me||Ti.endsWith(me)||me.endsWith(Ti))return"background"}return""}),R=St(()=>!!(s.value[ke]||s.value[Ne]||s.value[At]||s.value[Ci]||s.value[Jt]||s.value["slidev-note"]||s.value[jt]||s.value[dt]||s.value[bi]||s.value[Un]||s.value[Mi]||s.value[Wn])),{saveAttr:C,saveDocAttr:$,onToggleVideoAutoplay:D,onToggleVideoLoop:q,onToggleVideoMuted:W,onToggleVideoControls:U,onImageRoleChange:Z,onToggleNoteBlock:it,onAddNoteBlock:Q,onLocateNoteBlock:ct,onGenerateNotesWithAI:wt,toggleElemClick:bt,onElemClickStepChange:Tt,onElemMotionChange:Ht,onElemSlotChange:Wt,onElemShikiLinesChange:Yt,onElemMaxHeightChange:Mt,onSetTwoColsContrast:je,onClearBlockAttrs:Zt,onInsertDividerBefore:Kt,onInsertDividerAfter:ii,onDeleteCurrentBlock:Ii,onExportHtml:vo,onExportPdf:bo}=rb({activeBlockId:r,activeBlockType:l,activeBlockAttrs:s,rawSnippet:a,currentDocId:c,currentPageDividerId:f,currentPageDividerLayout:g,latestDoc:u,targetSlide:z,currentSlideNoteBlockId:K,currentSlideLayout:H,isNoteBlock:V,elemClick:G,videoAutoplay:pt,videoLoop:gt,videoMuted:Y,videoControls:rt,pageBackground:A,pageImage:v,elemShikiLines:ot,elemMaxHeight:X,saveStatus:k,plugin:e});function In(st){C(dt,st)}function di(st){C(qt,st)}function Ai(st){A.value=st,C(zt,st)}function ta(st){v.value=st,C(Se,st)}function ea(st){C(nn,st==="inherit"?"":st)}function ia(st){$(un,st)}function na(st){$(fn,st)}function oa(st){$(pn,st)}function sa(st){$(Po,st)}function $s(){e!=null&&e.openBottomPreviewTab&&e.openBottomPreviewTab()}function ra(){typeof window<"u"&&window.open("/plugins/siyuan-slidev/slidev-client/presenter.html","SlidevPresenter","width=1200,height=800")}function la(){e!=null&&e.executeCommand&&e.executeCommand("slidevAiSplit")}return i({setActiveBlock(st){r.value=st.id,l.value=st.type,s.value={...st.attrs},a.value=st.content||st.markdown||"",d.value=st.topBlockId||st.id,f.value=st.pageDividerId||"",g.value=st.pageDividerLayout||"",st.rootId?c.value=st.rootId:(st.type==="doc"||st.type==="NodeDocument")&&st.id&&(c.value=st.id),A.value=st.attrs[zt]||"",v.value=st.attrs[Se]||"",ot.value=st.attrs[Ci]||"",X.value=st.attrs[hn]||"",S.value=!!st.isImage},updateDocument(st){u.value=st,c.value=st.docId},openImportDialog(){o.value=!0},setCurrentDocId(st){c.value=st}}),(st,xt)=>(tt(),nt("div",lb,[m("div",ab,[m("div",cb,[(tt(),nt("svg",db,[...xt[2]||(xt[2]=[m("rect",{x:"2",y:"3",width:"20",height:"14",rx:"2"},null,-1),m("line",{x1:"8",y1:"21",x2:"16",y2:"21"},null,-1),m("line",{x1:"12",y1:"17",x2:"12",y2:"21"},null,-1)])])),xt[3]||(xt[3]=m("span",null,"演示配置",-1))]),m("div",ub,[m("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"导入 Slidev 演示文档 (.md / .zip)",onClick:xt[0]||(xt[0]=Lt=>o.value=!0)},[ut(yt,{name:"import"}),xt[4]||(xt[4]=m("span",null,"导入",-1))]),m("button",{class:"spm-icon-btn is-primary b3-tooltips b3-tooltips__s","aria-label":"在下方分屏开启幻灯片预览 (Alt+P)",onClick:$s},[ut(yt,{name:"split-preview"}),xt[5]||(xt[5]=m("span",null,"分屏预览",-1))])])]),m("div",fb,[m("div",pb,[m("span",{class:$t(["spm-target-tag",F.value])},_t(M.value),3),m("span",{class:"spm-target-id b3-tooltips b3-tooltips__s","aria-label":h.value||"点击复制 ID: "+(r.value||c.value),onClick:y},[ut(yt,{name:"copy"}),m("span",null,"#"+_t(I.value),1)],8,hb)]),k.value?(tt(),nt("span",mb,"● "+_t(k.value),1)):Pt("",!0)]),L.value?(tt(),nt("div",{key:0,class:"spm-context-quote",title:a.value},_t(L.value),9,gb)):Pt("",!0),m("div",vb,[b.value?(tt(),$e(im,{key:0,"page-layout":J.value,"page-transition":E.value,"page-background":A.value,"page-spacing":O.value,"page-image":v.value,"page-notes":P.value,"page-index":et.value,"onUpdate:pageLayout":In,"onUpdate:pageTransition":di,"onUpdate:pageBackground":Ai,"onUpdate:pageSpacing":ea,"onUpdate:pageImage":ta,onAddNoteBlock:ht(Q),onLocateNoteBlock:ht(ct),onGenerateNotes:ht(wt),onInsertDividerAfter:ht(ii),onDeleteDivider:ht(Ii)},null,8,["page-layout","page-transition","page-background","page-spacing","page-image","page-notes","page-index","onAddNoteBlock","onLocateNoteBlock","onGenerateNotes","onInsertDividerAfter","onDeleteDivider"])):r.value&&!_.value?(tt(),$e(_g,{key:1,"elem-click":G.value,"elem-motion":lt.value,"elem-slot":at.value,"elem-shiki-lines":ot.value,"elem-max-height":X.value,"is-code-block":w.value,"is-image":T.value,"is-video":x.value,"video-autoplay":pt.value,"video-loop":gt.value,"video-muted":Y.value,"video-controls":rt.value,"has-block-attrs":R.value,"is-note":V.value,"image-role":j.value,"current-slide-layout":H.value,onToggleNote:ht(it),onToggleElemClick:ht(bt),onToggleVideoAutoplay:ht(D),onToggleVideoLoop:ht(q),onToggleVideoMuted:ht(W),onToggleVideoControls:ht(U),"onUpdate:imageRole":ht(Z),"onUpdate:elemClick":ht(Tt),"onUpdate:elemMotion":ht(Ht),"onUpdate:elemSlot":ht(Wt),"onUpdate:elemShikiLines":ht(Yt),"onUpdate:elemMaxHeight":ht(Mt),onInsertDividerBefore:ht(Kt),onInsertDividerAfter:ht(ii),onSetTwoColsContrast:ht(je),onClearBlockAttrs:ht(Zt)},null,8,["elem-click","elem-motion","elem-slot","elem-shiki-lines","elem-max-height","is-code-block","is-image","is-video","video-autoplay","video-loop","video-muted","video-controls","has-block-attrs","is-note","image-role","current-slide-layout","onToggleNote","onToggleElemClick","onToggleVideoAutoplay","onToggleVideoLoop","onToggleVideoMuted","onToggleVideoControls","onUpdate:imageRole","onUpdate:elemClick","onUpdate:elemMotion","onUpdate:elemSlot","onUpdate:elemShikiLines","onUpdate:elemMaxHeight","onInsertDividerBefore","onInsertDividerAfter","onSetTwoColsContrast","onClearBlockAttrs"])):(tt(),$e(ev,{key:2,"doc-theme":vt.value,"doc-aspect-ratio":B.value,"doc-default-transition":N.value,"doc-spacing":p.value,"onUpdate:docTheme":ia,"onUpdate:docAspectRatio":na,"onUpdate:docDefaultTransition":oa,"onUpdate:docSpacing":sa,onOpenBottomPreview:$s,onOpenPresenter:ra,onAiAutoSplit:la,onExportHtml:ht(vo),onExportPdf:ht(bo)},null,8,["doc-theme","doc-aspect-ratio","doc-default-transition","doc-spacing","onExportHtml","onExportPdf"]))]),o.value?(tt(),$e(nb,{key:1,onClose:xt[1]||(xt[1]=Lt=>o.value=!1),onSuccess:n})):Pt("",!0)]))}}),$n=new _s;let si=null,ze=null;function yb(t,i){si&&Xl(),si=Ol(_h),si.provide("plugin",i),si.provide("sandboxBridge",$n);const e=si.mount(t);return ze=e,e}function Xl(t){si&&(si.unmount(),si=null,ze=null)}let ri=null,pe=null;function kb(t,i){ri&&Ql(),ri=Ol(bb),ri.provide("plugin",i),ri.provide("sandboxBridge",$n);const e=ri.mount(t);return pe=e,e}function Ql(t){ri&&(ri.unmount(),ri=null,pe=null)}function wb(t,i){pe!=null&&pe.updateDocument&&pe.updateDocument(t),ze!=null&&ze.updateDocument?ze.updateDocument(t,i):$n.updateSlides(t.slides,t.config,t.fullMarkdown)}function Xo(t){ze!=null&&ze.navigateToBlock?ze.navigateToBlock(t):$n.highlightElement(t)}function jn(t){pe!=null&&pe.setActiveBlock&&pe.setActiveBlock(t)}function xb(){return pe!=null&&pe.openImportDialog?(pe.openImportDialog(),!0):!1}function _b(t,i){const e=[];let n=0;for(let r=0;r<t.length;r++){const l=t[r];if(qn(l)){n=0;continue}const s=l.markdown||l.content||"";if(!(r===0)){if(l.type==="h"&&(l.subType==="h1"||s.startsWith("# "))){e.push({blockId:l.id,recommendedLayout:"cover",reason:"检测到一级核心章节标题，建议作为新幻灯片封面/大章"}),n=0;continue}if(l.type==="h"&&(l.subType==="h2"||s.startsWith("## "))){e.push({blockId:l.id,recommendedLayout:"default",reason:"检测到二级分论点标题，建议开启新页"}),n=0;continue}}if(n++,n>=6&&r<t.length-1){const c=t[r+1];qn(c)||(e.push({blockId:c.id,recommendedLayout:"default",reason:"当前页已达容量上限 (避免信息超载)，建议在此分页"}),n=0)}}return e}const Sb=[{id:"slidev-cover",name:"幻灯片 - 封面页 (Cover)",open:!0,attrs:[{key:vi,value:"true"},{key:dt,value:"cover"},{key:qt,value:"fade"}]},{id:"slidev-two-cols",name:"幻灯片 - 双栏对比 (Two Columns)",open:!0,attrs:[{key:vi,value:"true"},{key:dt,value:"two-cols"},{key:qt,value:"slide-left"}]},{id:"slidev-fact",name:"幻灯片 - 大字报与核心指标 (Fact)",open:!0,attrs:[{key:vi,value:"true"},{key:dt,value:"fact"},{key:qt,value:"zoom"}]},{id:"slidev-intro",name:"幻灯片 - 章节导引与作者 (Intro)",open:!0,attrs:[{key:vi,value:"true"},{key:dt,value:"intro"},{key:qt,value:"slide-up"}]},{id:"slidev-quote",name:"幻灯片 - 金句与强调 (Quote)",open:!0,attrs:[{key:vi,value:"true"},{key:dt,value:"quote"},{key:qt,value:"fade"}]},{id:"slidev-elem-click",name:"元素 - 顺延逐步呈现 (v-click)",open:!0,attrs:[{key:ke,value:"+1"}]},{id:"slidev-elem-click-hide",name:"元素 - 隐藏直到激活 (v-click:hide)",open:!0,attrs:[{key:ke,value:"hide"}]},{id:"slidev-elem-slot-right",name:"元素 - 双栏右栏归属 (Slot: Right)",open:!0,attrs:[{key:At,value:"right"}]},{id:"slidev-shiki-lines",name:"代码 - 逐行聚光高亮 (Shiki)",open:!0,attrs:[{key:Ci,value:"1-3"}]}];class Do{getPresetTemplates(){return Sb}buildScanSlidevBlocksSql(i="custom-slidev-"){return`SELECT block_id, name, value FROM attributes WHERE name LIKE '${i}%' ORDER BY block_id ASC`}buildTransitionStatsSql(){return`SELECT value, count(1) as count FROM attributes WHERE name = '${qt}' GROUP BY value ORDER BY count DESC`}async batchUpdateTransitions(i,e,o,n){const r=`SELECT block_id FROM attributes WHERE name = '${qt}' AND value = '${i}'`,l=await o(r);let s=0;if(Array.isArray(l))for(const a of l){const c=a.block_id||a.blockId;c&&(await n(c,{[qt]:e}),s++)}return{updatedCount:s}}async batchUpdateLayout(i,e,o,n){const r=`SELECT block_id FROM attributes WHERE name = 'custom-slidev-layout' AND value = '${i}'`,l=await o(r);let s=0;if(Array.isArray(l))for(const a of l){const c=a.block_id||a.blockId;c&&(await n(c,{"custom-slidev-layout":e}),s++)}return{updatedCount:s}}exportTemplatesJson(){const i=this.getPresetTemplates();return JSON.stringify({templates:i,counter:i.length},null,2)}formatTransitionSummary(i){return!i||i.length===0?"全库目前暂无已设置 Slidev 转场效果的块":`全库 Slidev 转场分布统计：${i.map(o=>`${o.value}: ${o.count} 个`).join("，")}`}}function Cb(t){t.addCommand({langKey:"slidevPresentation",langText:"Slidev: 在文档下方开启分屏演示预览",hotkey:"⌥P",enabled:()=>!0,execute:()=>{t.openBottomPreviewTab()}}),t.addCommand({langKey:"slidevImport",langText:"Slidev: 导入 Slidev 演示文档 (.md / .zip)",hotkey:"⌥I",enabled:()=>!0,execute:()=>{xb()||mt.showMessage("请先在右侧栏打开「Slidev 演示配置」Dock 面板以呼起导入窗口")}}),t.addCommand({langKey:"slidevInitAttrs",langText:"Slidev: 初始化当前文档演示属性",hotkey:"",enabled:()=>!0,execute:async()=>{if(!t.currentDocId){const i=document.querySelector(".protyle-content[data-doc-id]");t.currentDocId=(i==null?void 0:i.getAttribute("data-doc-id"))||""}t.currentDocId&&(await Dt(t.currentDocId,{"custom-slidev-theme":"default","custom-slidev-aspect-ratio":"16/9","custom-slidev-default-transition":"slide-left"}),mt.showMessage("已为当前文档初始化 Slidev 演示属性"),t.compileCurrentDocument(t.currentDocId))}}),t.addCommand({langKey:"slidevAiSplit",langText:"Slidev AI: 智能大纲断页建议与自动分页",hotkey:"",enabled:()=>!0,execute:async()=>{if(!t.currentDocId){const r=document.querySelector(".protyle-content[data-doc-id]");t.currentDocId=(r==null?void 0:r.getAttribute("data-doc-id"))||""}if(!t.currentDocId){mt.showMessage("请先打开一篇思源笔记文档");return}const i=await Hn(t.currentDocId).catch(()=>[]);if(!i||i.length===0){mt.showMessage("当前文档无内容，无需断页");return}const e=i.map(r=>({id:r.id,type:r.type,subType:r.subType,content:r.content||"",markdown:r.markdown||""})),o=_b(e);if(o.length===0){mt.showMessage("AI 分析完毕：当前文档篇幅合理，暂无分页建议");return}mt.showMessage(`AI 分析完毕：发现 ${o.length} 处建议分页点，正在自动插入分页分割线...`);let n=0;for(const r of o)try{await Qi("markdown","---",void 0,r.blockId),await Dt(r.blockId,{"custom-slidev-layout":r.recommendedLayout}),n++}catch(l){console.warn("Failed to insert divider:",l)}mt.showMessage(`已成功在 ${n} 处插入分页线并重新编译`),t.compileCurrentDocument(t.currentDocId)}}),t.addCommand({langKey:"slidevAiNotes",langText:"Slidev AI: 自动为当前文档生成演讲者提词卡 (Notes)",hotkey:"",enabled:()=>!0,execute:async()=>{var a,c,d,f;if(!t.currentDocId){const g=document.querySelector(".protyle-content[data-doc-id]");t.currentDocId=(g==null?void 0:g.getAttribute("data-doc-id"))||""}if(!t.currentDocId){mt.showMessage("请先打开一篇思源笔记文档");return}mt.showMessage("正在调用思源 AI 提炼演讲者口播提词...");const i=await Hn(t.currentDocId).catch(()=>[]),e={startBlockId:t.currentDocId,blocks:i.map(g=>({id:g.id,type:g.type,content:g.content||"",rawMarkdown:g.markdown||""})),rawMarkdown:""},r=`> [!NOTE] 💡 演讲备注
${(await sb(e,kr)).split(/\r?\n/).map(g=>`> ${g}`).join(`
`)}
{: custom-slidev-note="true"}`,l=await yr("markdown",r,t.currentDocId).catch(()=>null),s=((d=(c=(a=l==null?void 0:l[0])==null?void 0:a.doOperations)==null?void 0:c[0])==null?void 0:d.id)||((f=l==null?void 0:l[0])==null?void 0:f.id);s&&(await Dt(s,{"custom-slidev-note":"true"}),Rt.setBlockAttrOverride(s,{"custom-slidev-note":"true"}),Si(s,t.app)),mt.showMessage("已成功生成口播提词卡并插入为正文讲稿备注块"),t.compileCurrentDocument(t.currentDocId)}}),t.addCommand({langKey:"slidevBatchTransitions",langText:"Slidev 协同: 统计全库转场效果分布",hotkey:"",enabled:()=>!0,execute:async()=>{const i=new Do,e=i.buildTransitionStatsSql(),o=await dn(e).catch(()=>[]),n=i.formatTransitionSummary(o||[]);mt.showMessage(n)}}),t.addCommand({langKey:"slidevExportTemplates",langText:"Slidev 协同: 复制 Slidev 预设属性模板至剪贴板",hotkey:"",enabled:()=>!0,execute:async()=>{const e=new Do().exportTemplatesJson();typeof navigator<"u"&&navigator.clipboard?(await navigator.clipboard.writeText(e),mt.showMessage("已将 Slidev 属性模板 JSON 复制至剪贴板，可直接导入属性管家")):mt.showMessage(`已生成模板数据（请在控制台查看）：
`+e)}}),t.addCommand({langKey:"slidevBatchReplaceTransition",langText:"Slidev 协同: 批量替换全库淡入淡出转场为滑动 (fade -> slide-left)",hotkey:"",enabled:()=>!0,execute:async()=>{const e=await new Do().batchUpdateTransitions("fade","slide-left",o=>dn(o).catch(()=>[]),(o,n)=>Dt(o,n));mt.showMessage(`全库批量替换完成：已将 ${e.updatedCount} 处 fade 转场更新为 slide-left`),t.compileCurrentDocument()}}),t.addCommand({langKey:"slidevPresenterMode",langText:"Slidev: 打开双屏演讲者控制台 (Presenter Mode)",hotkey:"⌥M",enabled:()=>!0,execute:()=>{typeof window<"u"&&window.open("/plugins/siyuan-slidev/slidev-client/presenter.html","SlidevPresenter","width=1200,height=800")}}),t.addCommand({langKey:"slidevExportCliMd",langText:"Slidev Pro: 导出 Slidev 标准 slides.md 文档 (下载到本地)",hotkey:"",enabled:()=>!0,execute:async()=>{if(t.latestCompiledDoc||await t.compileCurrentDocument(),!t.latestCompiledDoc){mt.showMessage("请先打开并放映一篇思源笔记文档");return}t.cliBridge.downloadSlidesMd(t.latestCompiledDoc,`slides-${t.currentDocId||"demo"}.md`)&&mt.showMessage("已生成标准 Slidev Markdown 并触发下载，可在本地使用 npx @slidev/cli 运行")}}),t.addCommand({langKey:"slidevProbeCliDevServer",langText:"Slidev Pro: 检测本地 Slidev CLI DevServer 状态 (localhost:3030)",hotkey:"",enabled:()=>!0,execute:async()=>{mt.showMessage("正在探测本地 Slidev CLI DevServer (http://localhost:3030)..."),await t.cliBridge.probeServer(1500)?mt.showMessage("🟢 本地 Slidev CLI DevServer 运行正常！可直接在浏览器访问 http://localhost:3030"):mt.showMessage("⚪ 未检测到运行中的本地 Slidev CLI DevServer (端口 3030 未开启)")}}),t.addCommand({langKey:"slidevSyncToCliWorkspace",langText:"Slidev Pro: 同步 slides.md 至思源工作空间存储目录",hotkey:"",enabled:()=>!0,execute:async()=>{if(t.latestCompiledDoc||await t.compileCurrentDocument(),!t.latestCompiledDoc){mt.showMessage("请先打开并放映一篇思源笔记文档");return}const i=await t.cliBridge.syncToWorkspaceFile(t.latestCompiledDoc,"/data/storage/petal/siyuan-slidev/slides.md",Lo);i.success?mt.showMessage(`已成功同步最新 slides.md 至工作空间：${i.path}`):mt.showMessage(`同步失败：${i.error}`)}})}class $b{getActiveDocumentId(){if(typeof document>"u")return"";const i=document.querySelector(".layout__wnd--active .protyle-title[data-node-id]")||document.querySelector(".item--focus .protyle-title[data-node-id]")||document.querySelector(".protyle-title[data-node-id]"),e=i==null?void 0:i.getAttribute("data-node-id");if(e)return e;const o=document.querySelector(".protyle .protyle-title[data-node-id]"),n=o==null?void 0:o.getAttribute("data-node-id");if(n)return n;const r=document.querySelector("[data-doc-id]"),l=r==null?void 0:r.getAttribute("data-doc-id");return l||""}resolveDocIdFromElement(i,e=""){const o=i.closest(".protyle-title"),n=o==null?void 0:o.getAttribute("data-node-id");if(n)return n;const r=i.closest(".protyle"),l=r==null?void 0:r.querySelector(".protyle-title"),s=l==null?void 0:l.getAttribute("data-node-id");if(s)return s;const a=i.closest("[data-doc-id]"),c=a==null?void 0:a.getAttribute("data-doc-id");if(c)return c;const d=this.getActiveDocumentId();return d||e}async switchToDocGlobalInspector(i,e){var r;if(!i)return;let o=e||"";if(!o&&typeof document<"u"){const l=document.querySelector(`.protyle-title[data-node-id="${i}"] .protyle-title__input`)||document.querySelector(`.protyle[data-doc-id="${i}"] .protyle-title__input`)||document.querySelector(".protyle-title__input");o=((r=l==null?void 0:l.innerText)==null?void 0:r.trim())||""}const n=await Ue(i).catch(()=>({}));jn({id:i,rootId:i,type:"doc",content:o,attrs:n,isDivider:!1,isCode:!1}),Xo(i)}handleBlockClickedFromSlide(i,e,o,n){var a;if(!i)return!1;const r=Si(i,e),l=document.querySelector(`.protyle-wysiwyg [data-node-id="${i}"]`)||document.querySelector(`[data-node-id="${i}"]`),s=(l==null?void 0:l.getAttribute("data-type"))||"";if(l)this.syncInspectorBlock(l,i,s,o,n);else{let c="",d="";if(n!=null&&n.slides){const f=n.slides.find(g=>{var u,k,h;return g.startBlockId===i||((u=g.blocks)==null?void 0:u.some(y=>y.id===i))||((k=g.allBlockIds)==null?void 0:k.includes(i))||((h=g.noteBlocks)==null?void 0:h.some(y=>y.id===i))});f!=null&&f.startBlockId&&(c=f.startBlockId),(a=f==null?void 0:f.frontmatter)!=null&&a.layout&&(d=f.frontmatter.layout)}Ue(i).then(async f=>{if(c&&!d){const g=Rt.getBlockAttrOverride(c);if(g!=null&&g[dt]||g!=null&&g["custom-slidev-layout"])d=g[dt]||g["custom-slidev-layout"]||"";else{const u=await Ue(c).catch(()=>({}))||{};d=u[dt]||u["custom-slidev-layout"]||"",u&&Object.keys(u).length>0&&Rt.setBlockAttrOverride(c,u)}}jn({id:i,rootId:o,type:s||"NodeParagraph",attrs:f||{},pageDividerId:c,pageDividerLayout:d})}).catch(()=>{})}return r}async syncInspectorBlock(i,e,o,n,r){var E,A,v,O,z,P,K,H;let l=i,s=e,a=o;const c=i.closest('[data-type="NodeCallout"]');if(c&&c!==i){const et=c.getAttribute("data-node-id");if(et){const V=await Ue(et).catch(()=>({}))||{},G=Rt.getBlockAttrOverride(et)||{},lt={...V,...G};(lt[Jt]||lt["slidev-note"])&&(l=c,s=et,a="NodeCallout")}}const d=l.closest(".protyle-wysiwyg > [data-node-id]")||l,f=(d==null?void 0:d.getAttribute("data-node-id"))||s,g=a==="NodeThematicBreak"||a==="tb"||a==="thematic-break"||(d==null?void 0:d.getAttribute("data-type"))==="NodeThematicBreak"||(d==null?void 0:d.getAttribute("data-type"))==="tb"||!!((E=d==null?void 0:d.classList)!=null&&E.contains("hr")),u=a==="NodeCodeBlock",k=((A=l.innerText)==null?void 0:A.trim())||"",h=await Ue(s).catch(()=>({}))||{},y=Rt.getBlockAttrOverride(s)||{},b={...h,...y};let w="",S="";if(g)w=s,S=b[dt]||b["custom-slidev-layout"]||"";else{let et=d.previousElementSibling;for(;et;){const V=et.getAttribute("data-type");if(V==="NodeThematicBreak"||V==="tb"||(v=et.classList)!=null&&v.contains("hr")){w=et.getAttribute("data-node-id")||"";break}et=et.previousElementSibling}}if(r!=null&&r.slides){const et=[s,f];let V=l.parentElement;for(;V&&!V.classList.contains("protyle-wysiwyg");){const lt=V.getAttribute("data-node-id");lt&&!et.includes(lt)&&et.push(lt),V=V.parentElement}const G=r.slides.find(lt=>{var at,ot,X;return et.includes(lt.startBlockId)||((at=lt.blocks)==null?void 0:at.some(pt=>et.includes(pt.id)))||((ot=lt.allBlockIds)==null?void 0:ot.some(pt=>et.includes(pt)))||((X=lt.noteBlocks)==null?void 0:X.some(pt=>et.includes(pt.id)))});G&&(!w&&G.startBlockId&&(w=G.startBlockId),!S&&((O=G.frontmatter)!=null&&O.layout)&&(S=G.frontmatter.layout))}if(w){const et=Rt.getBlockAttrOverride(w);if(et&&(dt in et||"custom-slidev-layout"in et)&&(S=et[dt]||et["custom-slidev-layout"]||""),!S&&(r!=null&&r.slides)){const V=r.slides.find(G=>G.startBlockId===w);(z=V==null?void 0:V.frontmatter)!=null&&z.layout&&(S=V.frontmatter.layout)}if(!S){const V=await Ue(w).catch(()=>({}))||{};S=V[dt]||V["custom-slidev-layout"]||"",V&&Object.keys(V).length>0&&Rt.setBlockAttrOverride(w,V)}Qt(w,{[dt]:S||""})}else if(n){const et=Rt.getBlockAttrOverride(n);et&&(dt in et||"custom-slidev-layout"in et)?S=et[dt]||et["custom-slidev-layout"]||"":!S&&((H=(K=(P=r==null?void 0:r.slides)==null?void 0:P[0])==null?void 0:K.frontmatter)!=null&&H.layout)&&(S=r.slides[0].frontmatter.layout)}const T=l.getAttribute(dt)||l.getAttribute("custom-slidev-layout"),x=b[dt]||b["custom-slidev-layout"]||"";T&&T!==x&&Qt(s,{[dt]:x});const _=l.getAttribute(jt)||l.getAttribute("custom-slidev-role"),I=b[jt]||b["custom-slidev-role"]||"";_&&_!==I&&Qt(s,{[jt]:I});const L=l.closest('[data-type="NodeListItem"]');if(L&&L!==l){const et=L.getAttribute("data-node-id");if(et){const V=await Ue(et).catch(()=>({}))||{},G=Rt.getBlockAttrOverride(et)||{},lt={...V,...G},at=lt[dt]||lt["custom-slidev-layout"]||"",ot=L.getAttribute(dt)||L.getAttribute("custom-slidev-layout");ot&&ot!==at&&Qt(et,{[dt]:at});const X=lt[jt]||lt["custom-slidev-role"]||"",pt=L.getAttribute(jt)||L.getAttribute("custom-slidev-role");pt&&pt!==X&&Qt(et,{[jt]:X})}}const M=!!l.querySelector("img, span[data-type='img']"),F=(l.innerText||"").replace(/[\r\n\t\s]+/g," ").trim(),J=M&&F.length<=50;jn({id:s,rootId:n,type:a,content:k,attrs:b,isDivider:g,isCode:u,isImage:J,topBlockId:f,pageDividerId:w,pageDividerLayout:S})}patchThematicBreakTransactions(i){if((i==null?void 0:i.cmd)==="transactions"&&Array.isArray(i.data)){for(const e of i.data)if(Array.isArray(e==null?void 0:e.doOperations)){for(const o of e.doOperations)if((o==null?void 0:o.action)==="updateAttrs"&&o.id&&o.data){const n=o.data.old||{},r=o.data.new||{},l={};for(const s of Object.keys(n))s in r||(l[s]="");for(const[s,a]of Object.entries(r))l[s]=String(a??"");Qt(o.id,l),Rt.setBlockAttrOverride(o.id,l)}}}}purgeStaleDomSlidevAttrs(i){var n,r,l;if(typeof document>"u"||!i)return;const e=new Map;if(Array.isArray(i.slides))for(const s of i.slides){if(s.startBlockId){const a=e.get(s.startBlockId)||{};(n=s.frontmatter)!=null&&n.layout&&(a[dt]=s.frontmatter.layout),e.set(s.startBlockId,a)}if(Array.isArray(s.blocks)){for(const a of s.blocks)if(a.id){const c=e.get(a.id)||{};(r=a.ial)!=null&&r[dt]&&(c[dt]=a.ial[dt]),(l=a.ial)!=null&&l[jt]&&(c[jt]=a.ial[jt]),Object.keys(c).length>0&&e.set(a.id,c)}}}const o=Rt.getAllAttrOverrides();for(const[s,a]of o.entries()){const c=e.get(s)||{};a[dt]!==void 0&&(c[dt]=a[dt]),a[jt]!==void 0&&(c[jt]=a[jt]),e.set(s,c)}Tf(e)}}const mi=new $b,Ib=`<symbol id="iconSlidev" viewBox="0 0 1024 1024">
  <path fill="currentColor" d="M128 160h768c35.3 0 64 28.7 64 64v480c0 35.3-28.7 64-64 64H128c-35.3 0-64-28.7-64-64V224c0-35.3 28.7-64 64-64z m64 64v480h640V224H192z m128 640h384v64H320z"/>
  <path fill="currentColor" d="M416 336l256 144-256 144z"/>
</symbol>`,Ab="slidev-dock",gr="slidev-preview-tab",vr=yp;class Tb extends mt.Plugin{constructor(){super(...arguments);kt(this,"isMobile",!1);kt(this,"currentDocId","");kt(this,"latestCompiledDoc",null);kt(this,"cliBridge",new ts);kt(this,"debounceTimer",null);kt(this,"activeCursorBlockId","");kt(this,"onSwitchProtyleBound",this.onSwitchProtyle.bind(this));kt(this,"onWsMainBound",this.onWsMain.bind(this));kt(this,"onBlockClickedBound",this.onBlockClickedFromSlide.bind(this));kt(this,"onClickEditorTitleIconBound",this.onClickEditorTitleIcon.bind(this));kt(this,"onEditorClickBound",this.onEditorClick.bind(this));kt(this,"onSelectionChangeBound",this.onSelectionChange.bind(this));kt(this,"onClickEditorContentBound",this.onClickEditorContent.bind(this))}async onload(){const e=mt.getFrontend();this.isMobile=e==="mobile"||e==="browser-mobile",await this.loadGlobalSettings(),this.addIcons(Ib),this.addTopBar({id:"slidev-topbar-play",icon:"iconSlidev",title:"Slidev 演示 (下方分屏)",position:"right",callback:()=>{this.openBottomPreviewTab()}}),Cb(this);const o=this;if(this.addTab({type:gr,init(){yb(this.element,o)},destroy(){Xl(this.element)}}),this.addDock({config:{position:"RightTop",size:{width:320,height:0},icon:"iconSlidev",title:"Slidev 演示配置"},data:{},type:Ab,init(){kb(this.element,o)},destroy(){Ql(this.element)}}),this.eventBus&&typeof this.eventBus.emit!="function"&&(this.eventBus.emit=(n,r)=>{try{typeof window<"u"&&window.dispatchEvent(new CustomEvent(`siyuan-event-${n}`,{detail:r}))}catch{}}),this.eventBus.on("switch-protyle",this.onSwitchProtyleBound),this.eventBus.on("ws-main",this.onWsMainBound),this.eventBus.on("slidev:request-compile",()=>this.compileCurrentDocument()),this.eventBus.on("slidev:block-clicked",this.onBlockClickedBound),this.eventBus.on("click-editortitleicon",this.onClickEditorTitleIconBound),this.eventBus.on("click-editorcontent",this.onClickEditorContentBound),typeof document<"u"&&(document.addEventListener("click",this.onEditorClickBound,!0),document.addEventListener("selectionchange",this.onSelectionChangeBound)),typeof document<"u"){const n=()=>{const r=this.getActiveDocumentId();r&&(r!==this.currentDocId&&(this.currentDocId=r),this.latestCompiledDoc||this.compileCurrentDocument(r))};setTimeout(n,300),setTimeout(n,1e3)}}async onDataChanged(e){await this.loadGlobalSettings(),this.currentDocId&&await this.compileCurrentDocument(this.currentDocId)}async loadGlobalSettings(){try{const e=await this.loadData(vr),o=kp(e);return Fi(o),o}catch{return Fi(Vi),Vi}}async saveGlobalSettings(e){const o=Cs(),n=Fi({...o,...e||{}});try{await this.saveData(vr,n)}catch(r){console.error("保存 Slidev 全局配置失败",r)}return n}onunload(){this.debounceTimer&&(window.clearTimeout(this.debounceTimer),this.debounceTimer=null),this.eventBus.off("switch-protyle",this.onSwitchProtyleBound),this.eventBus.off("ws-main",this.onWsMainBound),this.eventBus.off("click-editortitleicon",this.onClickEditorTitleIconBound),this.eventBus.off("click-editorcontent",this.onClickEditorContentBound),typeof document<"u"&&(document.removeEventListener("click",this.onEditorClickBound,!0),document.removeEventListener("selectionchange",this.onSelectionChangeBound)),$n.detach()}async openBottomPreviewTab(){this.currentDocId||(this.currentDocId=this.getActiveDocumentId()),await mt.openTab({app:this.app,custom:{id:this.name+gr,title:"Slidev 演示预览",icon:"iconSlidev",data:{docId:this.currentDocId}},position:"bottom"}),this.currentDocId&&this.compileCurrentDocument(this.currentDocId)}onClickEditorTitleIcon(e){var l;const o=e.detail,n=o==null?void 0:o.menu,r=((l=o==null?void 0:o.data)==null?void 0:l.id)||this.currentDocId;!n||!r||n.addItem({icon:"iconSlidev",label:"Slidev 全局演示配置",submenu:[{label:"初始化演示属性 (custom-slidev-*)",click:async()=>{await Dt(r,{"custom-slidev-theme":"default","custom-slidev-aspect-ratio":"16/9","custom-slidev-default-transition":"slide-left"}),mt.showMessage("已为当前文档初始化 Slidev 演示属性"),this.compileCurrentDocument(r)}},{type:"separator"},{label:"主题: 默认 (default)",click:async()=>{await Dt(r,{"custom-slidev-theme":"default"}),mt.showMessage("已切换为 default 主题"),this.compileCurrentDocument(r)}},{label:"主题: 优雅衬线 (seriph)",click:async()=>{await Dt(r,{"custom-slidev-theme":"seriph"}),mt.showMessage("已切换为 seriph 主题"),this.compileCurrentDocument(r)}},{label:"主题: 苹果极简 (apple-basic)",click:async()=>{await Dt(r,{"custom-slidev-theme":"apple-basic"}),mt.showMessage("已切换为 apple-basic 主题"),this.compileCurrentDocument(r)}},{type:"separator"},{label:"画幅: 16 / 9 (宽屏)",click:async()=>{await Dt(r,{"custom-slidev-aspect-ratio":"16/9"}),mt.showMessage("已切换画幅为 16/9"),this.compileCurrentDocument(r)}},{label:"画幅: 4 / 3 (标屏)",click:async()=>{await Dt(r,{"custom-slidev-aspect-ratio":"4/3"}),mt.showMessage("已切换画幅为 4/3"),this.compileCurrentDocument(r)}}]})}async onSwitchProtyle(e){var r,l;const o=(r=e.detail)==null?void 0:r.protyle,n=(l=o==null?void 0:o.block)==null?void 0:l.rootID;if(n&&n!==this.currentDocId){this.currentDocId=n,this.activeCursorBlockId=n;const s=await Ue(n).catch(()=>({}));jn({id:n,rootId:n,type:"doc",attrs:s}),this.compileCurrentDocument(n)}}onClickEditorContent(e){var r,l;const o=e==null?void 0:e.detail;if(!o)return;const n=(l=(r=o.protyle)==null?void 0:r.block)==null?void 0:l.rootID;n&&(!this.currentDocId||this.currentDocId!==n)&&(this.currentDocId=n),o.event&&this.onEditorClick(o.event)}getActiveDocumentId(){return mi.getActiveDocumentId()}resolveDocIdFromElement(e){return mi.resolveDocIdFromElement(e,this.currentDocId)}async switchToDocGlobalInspector(e,o){e&&(this.activeCursorBlockId=e,this.currentDocId=e,await mi.switchToDocGlobalInspector(e,o))}onWsMain(e){const o=e.detail;o&&(mi.patchThematicBreakTransactions(o),this.debounceTimer&&window.clearTimeout(this.debounceTimer),this.debounceTimer=window.setTimeout(()=>{this.compileCurrentDocument()},150))}handleBlockClickedFromSlide(e,o){return e?(this.activeCursorBlockId=e,mi.handleBlockClickedFromSlide(e,this.app,this.currentDocId,this.latestCompiledDoc)):!1}onBlockClickedFromSlide(e){const o=(e==null?void 0:e.detail)||e;o!=null&&o.blockId&&this.handleBlockClickedFromSlide(o.blockId,o.page)}onEditorClick(e){const o=e.target;if(!o)return;const n=o.closest(".protyle-title")||o.closest(".protyle-background");if(!!(n||o.closest(".protyle-content")&&!o.closest(".protyle-wysiwyg")&&!o.closest(".protyle-breadcrumb")&&!o.closest(".protyle-gutters"))){const d=this.resolveDocIdFromElement(o);if(d&&this.activeCursorBlockId!==d){const f=n||document.querySelector(`.protyle-title[data-node-id="${d}"]`)||document.querySelector(`.protyle[data-doc-id="${d}"] .protyle-title`),g=f==null?void 0:f.querySelector(".protyle-title__input"),u=((g==null?void 0:g.innerText)||(f==null?void 0:f.innerText)||"").trim();this.switchToDocGlobalInspector(d,u)}return}if(!o.closest(".protyle-wysiwyg"))return;const s=o.closest("[data-node-id]");if(!s)return;const a=s.getAttribute("data-node-id"),c=s.getAttribute("data-type")||"";a&&(this.currentDocId||(this.currentDocId=this.resolveDocIdFromElement(o)||""),this.currentDocId&&!this.latestCompiledDoc&&this.compileCurrentDocument(this.currentDocId),a!==this.activeCursorBlockId&&(this.activeCursorBlockId=a,Xo(a)),this.syncInspectorBlock(s,a,c))}onSelectionChange(){if(typeof window>"u")return;const e=window.getSelection();if(!e||e.rangeCount===0)return;const o=e.anchorNode;if(!o)return;const n=o.nodeType===Node.ELEMENT_NODE?o:o.parentElement;if(!n)return;const r=n.closest(".protyle-title");if(!!(r||n.closest(".protyle-content")&&!n.closest(".protyle-wysiwyg"))){const d=this.resolveDocIdFromElement(n);if(d&&this.activeCursorBlockId!==d){const f=r||document.querySelector(`.protyle-title[data-node-id="${d}"]`)||document.querySelector(`.protyle[data-doc-id="${d}"] .protyle-title`),g=f==null?void 0:f.querySelector(".protyle-title__input"),u=((g==null?void 0:g.innerText)||(f==null?void 0:f.innerText)||"").trim();this.switchToDocGlobalInspector(d,u)}return}if(!n.closest(".protyle-wysiwyg"))return;const s=n.closest("[data-node-id]"),a=s==null?void 0:s.getAttribute("data-node-id"),c=(s==null?void 0:s.getAttribute("data-type"))||"";s&&a&&(this.currentDocId||(this.currentDocId=this.resolveDocIdFromElement(n)||""),this.currentDocId&&!this.latestCompiledDoc&&this.compileCurrentDocument(this.currentDocId),a!==this.activeCursorBlockId&&(this.activeCursorBlockId=a,Xo(a)),this.syncInspectorBlock(s,a,c))}async syncInspectorBlock(e,o,n){await mi.syncInspectorBlock(e,o,n,this.currentDocId,this.latestCompiledDoc)}async compileCurrentDocument(e){let o=e||this.currentDocId;if(!o){const n=this.getActiveDocumentId();if(n)this.currentDocId=n,o=n;else return}try{const n=await Rt.compile(o);this.latestCompiledDoc=n,wb(n,o),this.purgeStaleDomSlidevAttrs(n)}catch(n){console.error("[SiYuanSlidev] Failed to compile document:",n)}}purgeStaleDomSlidevAttrs(e){mi.purgeStaleDomSlidevAttrs(e)}}module.exports=Tb;
