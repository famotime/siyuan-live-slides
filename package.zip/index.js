"use strict";var td=Object.create;var Js=Object.defineProperty;var id=Object.getOwnPropertyDescriptor;var nd=Object.getOwnPropertyNames;var sd=Object.getPrototypeOf,od=Object.prototype.hasOwnProperty;var rd=(e,t,i)=>t in e?Js(e,t,{enumerable:!0,configurable:!0,writable:!0,value:i}):e[t]=i;var ad=(e,t,i,n)=>{if(t&&typeof t=="object"||typeof t=="function")for(let s of nd(t))!od.call(e,s)&&s!==i&&Js(e,s,{get:()=>t[s],enumerable:!(n=id(t,s))||n.enumerable});return e};var is=(e,t,i)=>(i=e!=null?td(sd(e)):{},ad(t||!e||!e.__esModule?Js(i,"default",{value:e,enumerable:!0}):i,e));var ve=(e,t,i)=>rd(e,typeof t!="symbol"?t+"":t,i);const de=require("siyuan");async function yt(e,t){const i=await de.fetchSyncPost(e,t);return i.code===0?i.data:null}async function ld(){return yt("/api/notebook/lsNotebooks","")}async function cd(e,t,i){return yt("/api/filetree/createDocWithMd",{notebook:e,path:t,markdown:i})}async function ba(e,t){const i=new FormData;i.append("assetsDirPath",e);for(const s of t)i.append("file[]",s);return yt("/api/asset/upload",i)}async function zi(e,t,i,n,s){return yt("/api/block/insertBlock",{dataType:e,data:t,nextID:i,previousID:n,parentID:s})}async function bo(e,t,i){return yt("/api/block/appendBlock",{dataType:e,data:t,parentID:i})}async function yo(e,t,i){return yt("/api/block/updateBlock",{dataType:e,data:t,id:i})}async function ya(e){return yt("/api/block/deleteBlock",{id:e})}async function dd(e){return yt("/api/block/getBlockKramdown",{id:e})}async function Yn(e){return yt("/api/block/getChildBlocks",{id:e})}async function ud(e){return yt("/api/block/getDocBlocksOrders",{id:e})}async function He(e,t){return yt("/api/attr/setBlockAttrs",{id:e,attrs:t})}async function jo(e){return yt("/api/attr/getBlockAttrs",{id:e})}async function dn(e){return yt("/api/query/sql",{stmt:e})}async function ko(e,t,i){const n=new FormData;return n.append("path",e),n.append("isDir",t.toString()),n.append("modTime",Math.floor(Date.now()/1e3).toString()),n.append("file",i),yt("/api/file/putFile",n)}async function ka(e){const t="/api/ai/chatGPT";try{const i=await yt(t,{msg:e});return typeof i=="string"&&i.trim().length>0?i.trim():i&&typeof i.content=="string"&&i.content.trim().length>0?i.content.trim():null}catch{return null}}async function fd(){return yt("/api/storage/getInlineStyles","")}function wr(e){return e.markdown&&e.markdown.trim()?e.markdown.trim():e.content&&e.content.trim()?e.content.trim():""}function wa(e){const t={};if(!e)return t;const i=e.replace(/^\{:\s*/,"").replace(/\s*\}$/,""),n=/([\w-]+)=(?:"([^"]*)"|'([^']*)'|(\S+))/g;let s;for(;(s=n.exec(i))!==null;){const o=s[1],a=s[2]??s[3]??s[4]??"";t[o]=a}return t}const xa=/\(\(([0-9a-zA-Z-]+)(?:\s*(?:'([^']*)'|"([^"]*)"|([^\)]+?)))?\s*\)\)/g;function pd(e){const t=[];if(!e)return t;const i=new RegExp(xa.source,"g");let n;for(;(n=i.exec(e))!==null;){const s=n[2]??n[3]??n[4];t.push({fullMatch:n[0],blockId:n[1],anchorText:s?s.trim():void 0})}return t}function hd(e,t){if(!e)return"";const i=new RegExp(xa.source,"g");return e.replace(i,(n,s,o,a,r)=>{const l=(o??a??r??"").trim();if(t&&t[s]){const u=t[s].trim();return`<div class="slides-block-ref" data-ref-id="${s}">${u}</div>`}const c=l||`Ref(${s.slice(0,8)})`;return`<a href="siyuan://blocks/${s}" data-ref-id="${s}" class="slides-ref-tag">🔗 ${c}</a>`})}const Nn="custom-slides-theme",zn="custom-slides-aspect-ratio",Sa="custom-slides-highlighter",Hn="custom-slides-default-transition",Ca="custom-slides-color-schema",wo="custom-slides-spacing",xr="custom-slides-show-unordered-list-markers",Sr="custom-slides-show-ordered-list-markers",Ri="custom-slides-slide",ke="custom-slides-layout",gt="custom-slides-transition",st="custom-slides-background",Ot="custom-slides-image",Xs="custom-slides-notes",Qi="custom-slides-class",Mn="custom-slides-spacing",vt="custom-slides-layout-ratio",en="custom-slides-mask",Fi="custom-slides-mask-ratio",tn="custom-slides-mask-style",nn="custom-slides-mask-initial",Re="custom-slides-click",Jt="custom-slides-motion",Gi="custom-slides-shiki-lines",Me="custom-slides-slot",Ke="custom-slides-note",Ze="custom-slides-role",Fn="custom-slides-max-height",Ni="custom-slides-autoplay",ws="custom-slides-loop",Xi="custom-slides-muted",xs="custom-slides-controls",_a="background",Ss="image-left",Cs="image-right";function sn(e){return e==="cols-header"||e==="two-cols-header"||e==="three-cols-header"}function md(e,t=2){const i=t===4?[25,50,75,100]:[50,100],n=t===4?4:2;if(!e||typeof e!="string")return{steps:n,breakpoints:i};const s=e.trim();if(!s||t===4&&(s==="1:1"||s==="1"))return{steps:n,breakpoints:i};const o=s.split(":").map(h=>parseFloat(h.trim())).filter(h=>!isNaN(h)&&h>0);if(o.length===0)return{steps:n,breakpoints:i};if(o.length===1){const h=Math.min(100,Math.max(1,o[0]));return h===100?{steps:1,breakpoints:[100]}:{steps:2,breakpoints:[Math.round(h*100)/100,100]}}const a=o.every((h,p)=>p===0||h>o[p-1]),r=o[o.length-1];if(a&&(r===100||o.some(h=>h>10))){const h=o.map(p=>Math.min(100,Math.round(p*100)/100));return h[h.length-1]<100&&h.push(100),{steps:h.length,breakpoints:h}}const c=o.reduce((h,p)=>h+p,0);if(c<=0)return{steps:n,breakpoints:i};let u=0;const d=[];for(let h=0;h<o.length;h++)u+=o[h],h===o.length-1?d.push(100):d.push(Math.round(u/c*1e4)/100);return{steps:d.length,breakpoints:d}}function $a(e){if(!e)return!1;const t=e.trim();return t.startsWith("assets/")||t.startsWith("./assets/")||t.startsWith("/assets/")}function Ia(e){const t=e.trim();return t.startsWith("./assets/")?t.slice(2):t.startsWith("/assets/")?t.slice(1):t}function Et(e,t){if(!$a(e))return e;const i=Ia(e);return t!=null&&t.base64Map&&t.base64Map[i]?t.base64Map[i]:t!=null&&t.baseUrl?`${t.baseUrl.replace(/\/+$/,"")}/${i}`:`/${i}`}function gd(e,t){if(!e)return"";let i=e;return i=i.replace(/!\[(.*?)\]\(((?:\.\/|\/)?assets\/[^\s)]+)\)/g,(n,s,o)=>{const a=Et(o,t);return`![${s}](${a})`}),i=i.replace(/(<(?:img|video|audio|source)\b[^>]*?\bsrc=["'])((?:\.\/|\/)?assets\/[^"']+)(["'][^>]*>)/gi,(n,s,o,a)=>{const r=Et(o,t);return`${s}${r}${a}`}),i=i.replace(/(url\(\s*["']?)((?:\.\/|\/)?assets\/[^"')]+)(["']?\s*\))/gi,(n,s,o,a)=>{const r=Et(o,t);return`${s}${r}${a}`}),i}/**
* @vue/shared v3.5.40
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/function Wo(e){const t=Object.create(null);for(const i of e.split(","))t[i]=1;return i=>i in t}const Je={},on=[],Xt=()=>{},Ma=()=>!1,Ls=e=>e.charCodeAt(0)===111&&e.charCodeAt(1)===110&&(e.charCodeAt(2)>122||e.charCodeAt(2)<97),Ps=e=>e.startsWith("onUpdate:"),ut=Object.assign,Uo=(e,t)=>{const i=e.indexOf(t);i>-1&&e.splice(i,1)},vd=Object.prototype.hasOwnProperty,Ue=(e,t)=>vd.call(e,t),Ee=Array.isArray,rn=e=>Zn(e)==="[object Map]",mn=e=>Zn(e)==="[object Set]",Cr=e=>Zn(e)==="[object Date]",Be=e=>typeof e=="function",nt=e=>typeof e=="string",zt=e=>typeof e=="symbol",qe=e=>e!==null&&typeof e=="object",Ta=e=>(qe(e)||Be(e))&&Be(e.then)&&Be(e.catch),Ea=Object.prototype.toString,Zn=e=>Ea.call(e),bd=e=>Zn(e).slice(8,-1),Aa=e=>Zn(e)==="[object Object]",Vo=e=>nt(e)&&e!=="NaN"&&e[0]!=="-"&&""+parseInt(e,10)===e,Tn=Wo(",key,ref,ref_for,ref_key,onVnodeBeforeMount,onVnodeMounted,onVnodeBeforeUpdate,onVnodeUpdated,onVnodeBeforeUnmount,onVnodeUnmounted"),Os=e=>{const t=Object.create(null);return(i=>t[i]||(t[i]=e(i)))},yd=/-\w/g,St=Os(e=>e.replace(yd,t=>t.slice(1).toUpperCase())),kd=/\B([A-Z])/g,Ei=Os(e=>e.replace(kd,"-$1").toLowerCase()),Rs=Os(e=>e.charAt(0).toUpperCase()+e.slice(1)),Qs=Os(e=>e?`on${Rs(e)}`:""),Kt=(e,t)=>!Object.is(e,t),us=(e,...t)=>{for(let i=0;i<e.length;i++)e[i](...t)},Ba=(e,t,i,n=!1)=>{Object.defineProperty(e,t,{configurable:!0,enumerable:!1,writable:n,value:i})},Ns=e=>{const t=parseFloat(e);return isNaN(t)?e:t};let _r;const zs=()=>_r||(_r=typeof globalThis<"u"?globalThis:typeof self<"u"?self:typeof window<"u"?window:typeof global<"u"?global:{});function qt(e){if(Ee(e)){const t={};for(let i=0;i<e.length;i++){const n=e[i],s=nt(n)?Cd(n):qt(n);if(s)for(const o in s)t[o]=s[o]}return t}else if(nt(e)||qe(e))return e}const wd=/;(?![^(]*\))/g,xd=/:([^]+)/,Sd=/\/\*[^]*?\*\//g;function Cd(e){const t={};return e.replace(Sd,"").split(wd).forEach(i=>{if(i){const n=i.split(xd);n.length>1&&(t[n[0].trim()]=n[1].trim())}}),t}function Ce(e){let t="";if(nt(e))t=e;else if(Ee(e))for(let i=0;i<e.length;i++){const n=Ce(e[i]);n&&(t+=n+" ")}else if(qe(e))for(const i in e)e[i]&&(t+=i+" ");return t.trim()}const _d="itemscope,allowfullscreen,formnovalidate,ismap,nomodule,novalidate,readonly",$d=Wo(_d);function Da(e){return!!e||e===""}function Id(e,t){if(e.length!==t.length)return!1;let i=!0;for(let n=0;i&&n<e.length;n++)i=gn(e[n],t[n]);return i}function gn(e,t){if(e===t)return!0;let i=Cr(e),n=Cr(t);if(i||n)return i&&n?e.getTime()===t.getTime():!1;if(i=zt(e),n=zt(t),i||n)return e===t;if(i=Ee(e),n=Ee(t),i||n)return i&&n?Id(e,t):!1;if(i=qe(e),n=qe(t),i||n){if(!i||!n)return!1;const s=Object.keys(e).length,o=Object.keys(t).length;if(s!==o)return!1;for(const a in e){const r=e.hasOwnProperty(a),l=t.hasOwnProperty(a);if(r&&!l||!r&&l||!gn(e[a],t[a]))return!1}}return String(e)===String(t)}function Go(e,t){return e.findIndex(i=>gn(i,t))}const La=e=>!!(e&&e.__v_isRef===!0),we=e=>nt(e)?e:e==null?"":Ee(e)||qe(e)&&(e.toString===Ea||!Be(e.toString))?La(e)?we(e.value):JSON.stringify(e,Pa,2):String(e),Pa=(e,t)=>La(t)?Pa(e,t.value):rn(t)?{[`Map(${t.size})`]:[...t.entries()].reduce((i,[n,s],o)=>(i[eo(n,o)+" =>"]=s,i),{})}:mn(t)?{[`Set(${t.size})`]:[...t.values()].map(i=>eo(i))}:zt(t)?eo(t):qe(t)&&!Ee(t)&&!Aa(t)?String(t):t,eo=(e,t="")=>{var i;return zt(e)?`Symbol(${(i=e.description)!=null?i:t})`:e};/**
* @vue/reactivity v3.5.40
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/let ct;class Md{constructor(t=!1){this.detached=t,this._active=!0,this._on=0,this.effects=[],this.cleanups=[],this._isPaused=!1,this._warnOnRun=!0,this.__v_skip=!0,!t&&ct&&(ct.active?(this.parent=ct,this.index=(ct.scopes||(ct.scopes=[])).push(this)-1):(this._active=!1,this._warnOnRun=!1))}get active(){return this._active}pause(){if(this._active){this._isPaused=!0;let t,i;if(this.scopes){const n=this.scopes.slice();for(t=0,i=n.length;t<i;t++)n[t].pause()}for(t=0,i=this.effects.length;t<i;t++)this.effects[t].pause()}}resume(){if(this._active&&this._isPaused){this._isPaused=!1;let t,i;if(this.scopes){const s=this.scopes.slice();for(t=0,i=s.length;t<i;t++)s[t].resume()}const n=this.effects.slice();for(t=0,i=n.length;t<i;t++)n[t].resume()}}run(t){if(this._active){const i=ct;try{return ct=this,t()}finally{ct=i}}}on(){++this._on===1&&(this.prevScope=ct,ct=this)}off(){if(this._on>0&&--this._on===0){if(ct===this)ct=this.prevScope;else{let t=ct;for(;t;){if(t.prevScope===this){t.prevScope=this.prevScope;break}t=t.prevScope}}this.prevScope=void 0}}stop(t){if(this._active){this._active=!1;let i,n;for(i=0,n=this.effects.length;i<n;i++)this.effects[i].stop();for(this.effects.length=0,i=0,n=this.cleanups.length;i<n;i++)this.cleanups[i]();if(this.cleanups.length=0,this.scopes){const s=this.scopes.slice();for(i=0,n=s.length;i<n;i++)s[i].stop(!0);this.scopes.length=0}if(!this.detached&&this.parent&&!t){const s=this.parent.scopes.pop();s&&s!==this&&(this.parent.scopes[this.index]=s,s.index=this.index)}this.parent=void 0}}}function Td(){return ct}let Qe;const to=new WeakSet;class Oa{constructor(t){this.fn=t,this.deps=void 0,this.depsTail=void 0,this.flags=5,this.next=void 0,this.cleanup=void 0,this.scheduler=void 0,ct&&(ct.active?ct.effects.push(this):this.flags&=-2)}pause(){this.flags|=64}resume(){this.flags&64&&(this.flags&=-65,to.has(this)&&(to.delete(this),this.trigger()))}notify(){this.flags&2&&!(this.flags&32)||this.flags&8||Na(this)}run(){if(!(this.flags&1))return this.fn();this.flags|=2,$r(this),za(this);const t=Qe,i=Rt;Qe=this,Rt=!0;try{return this.fn()}finally{Ha(this),Qe=t,Rt=i,this.flags&=-3}}stop(){if(this.flags&1){for(let t=this.deps;t;t=t.nextDep)Yo(t);this.deps=this.depsTail=void 0,$r(this),this.onStop&&this.onStop(),this.flags&=-2}}trigger(){this.flags&64?to.add(this):this.scheduler?this.scheduler():this.runIfDirty()}runIfDirty(){xo(this)&&this.run()}get dirty(){return xo(this)}}let Ra=0,En,An;function Na(e,t=!1){if(e.flags|=8,t){e.next=An,An=e;return}e.next=En,En=e}function Ko(){Ra++}function qo(){if(--Ra>0)return;if(An){let t=An;for(An=void 0;t;){const i=t.next;t.next=void 0,t.flags&=-9,t=i}}let e;for(;En;){let t=En;for(En=void 0;t;){const i=t.next;if(t.next=void 0,t.flags&=-9,t.flags&1)try{t.trigger()}catch(n){e||(e=n)}t=i}}if(e)throw e}function za(e){for(let t=e.deps;t;t=t.nextDep)t.version=-1,t.prevActiveLink=t.dep.activeLink,t.dep.activeLink=t}function Ha(e){let t,i=e.depsTail,n=i;for(;n;){const s=n.prevDep;n.version===-1?(n===i&&(i=s),Yo(n),Ed(n)):t=n,n.dep.activeLink=n.prevActiveLink,n.prevActiveLink=void 0,n=s}e.deps=t,e.depsTail=i}function xo(e){for(let t=e.deps;t;t=t.nextDep)if(t.dep.version!==t.version||t.dep.computed&&(Fa(t.dep.computed)||t.dep.version!==t.version))return!0;return!!e._dirty}function Fa(e){if(e.flags&4&&!(e.flags&16)||(e.flags&=-17,e.globalVersion===jn)||(e.globalVersion=jn,!e.isSSR&&e.flags&128&&(!e.deps&&!e._dirty||!xo(e))))return;e.flags|=2;const t=e.dep,i=Qe,n=Rt;Qe=e,Rt=!0;try{za(e);const s=e.fn(e._value);(t.version===0||Kt(s,e._value))&&(e.flags|=128,e._value=s,t.version++)}catch(s){throw t.version++,s}finally{Qe=i,Rt=n,Ha(e),e.flags&=-3}}function Yo(e,t=!1){const{dep:i,prevSub:n,nextSub:s}=e;if(n&&(n.nextSub=s,e.prevSub=void 0),s&&(s.prevSub=n,e.nextSub=void 0),i.subs===e&&(i.subs=n,!n&&i.computed)){i.computed.flags&=-5;for(let o=i.computed.deps;o;o=o.nextDep)Yo(o,!0)}!t&&!--i.sc&&i.map&&i.map.delete(i.key)}function Ed(e){const{prevDep:t,nextDep:i}=e;t&&(t.nextDep=i,e.prevDep=void 0),i&&(i.prevDep=t,e.nextDep=void 0)}let Rt=!0;const ja=[];function pi(){ja.push(Rt),Rt=!1}function hi(){const e=ja.pop();Rt=e===void 0?!0:e}function $r(e){const{cleanup:t}=e;if(e.cleanup=void 0,t){const i=Qe;Qe=void 0;try{t()}finally{Qe=i}}}let jn=0;class Ad{constructor(t,i){this.sub=t,this.dep=i,this.version=i.version,this.nextDep=this.prevDep=this.nextSub=this.prevSub=this.prevActiveLink=void 0}}class Zo{constructor(t){this.computed=t,this.version=0,this.activeLink=void 0,this.subs=void 0,this.map=void 0,this.key=void 0,this.sc=0,this.__v_skip=!0}track(t){if(!Qe||!Rt||Qe===this.computed)return;let i=this.activeLink;if(i===void 0||i.sub!==Qe)i=this.activeLink=new Ad(Qe,this),Qe.deps?(i.prevDep=Qe.depsTail,Qe.depsTail.nextDep=i,Qe.depsTail=i):Qe.deps=Qe.depsTail=i,Wa(i);else if(i.version===-1&&(i.version=this.version,i.nextDep)){const n=i.nextDep;n.prevDep=i.prevDep,i.prevDep&&(i.prevDep.nextDep=n),i.prevDep=Qe.depsTail,i.nextDep=void 0,Qe.depsTail.nextDep=i,Qe.depsTail=i,Qe.deps===i&&(Qe.deps=n)}return i}trigger(t){this.version++,jn++,this.notify(t)}notify(t){Ko();try{for(let i=this.subs;i;i=i.prevSub)i.sub.notify()&&i.sub.dep.notify()}finally{qo()}}}function Wa(e){if(e.dep.sc++,e.sub.flags&4){const t=e.dep.computed;if(t&&!e.dep.subs){t.flags|=20;for(let n=t.deps;n;n=n.nextDep)Wa(n)}const i=e.dep.subs;i!==e&&(e.prevSub=i,i&&(i.nextSub=e)),e.dep.subs=e}}const So=new WeakMap,ji=Symbol(""),Co=Symbol(""),Wn=Symbol("");function mt(e,t,i){if(Rt&&Qe){let n=So.get(e);n||So.set(e,n=new Map);let s=n.get(i);s||(n.set(i,s=new Zo),s.map=n,s.key=i),s.track()}}function li(e,t,i,n,s,o){const a=So.get(e);if(!a){jn++;return}const r=l=>{l&&l.trigger()};if(Ko(),t==="clear")a.forEach(r);else{const l=Ee(e),c=l&&Vo(i);if(l&&i==="length"){const u=Number(n);a.forEach((d,h)=>{(h==="length"||h===Wn||!zt(h)&&h>=u)&&r(d)})}else switch((i!==void 0||a.has(void 0))&&r(a.get(i)),c&&r(a.get(Wn)),t){case"add":l?c&&r(a.get("length")):(r(a.get(ji)),rn(e)&&r(a.get(Co)));break;case"delete":l||(r(a.get(ji)),rn(e)&&r(a.get(Co)));break;case"set":rn(e)&&r(a.get(ji));break}}qo()}function Yi(e){const t=We(e);return t===e?t:(mt(t,"iterate",Wn),Lt(e)?t:t.map(Ht))}function Hs(e){return mt(e=We(e),"iterate",Wn),e}function Vt(e,t){return mi(e)?un(Wi(e)?Ht(t):t):Ht(t)}const Bd={__proto__:null,[Symbol.iterator](){return io(this,Symbol.iterator,e=>Vt(this,e))},concat(...e){return Yi(this).concat(...e.map(t=>Ee(t)?Yi(t):t))},entries(){return io(this,"entries",e=>(e[1]=Vt(this,e[1]),e))},every(e,t){return ni(this,"every",e,t,void 0,arguments)},filter(e,t){return ni(this,"filter",e,t,i=>i.map(n=>Vt(this,n)),arguments)},find(e,t){return ni(this,"find",e,t,i=>Vt(this,i),arguments)},findIndex(e,t){return ni(this,"findIndex",e,t,void 0,arguments)},findLast(e,t){return ni(this,"findLast",e,t,i=>Vt(this,i),arguments)},findLastIndex(e,t){return ni(this,"findLastIndex",e,t,void 0,arguments)},forEach(e,t){return ni(this,"forEach",e,t,void 0,arguments)},includes(...e){return no(this,"includes",e)},indexOf(...e){return no(this,"indexOf",e)},join(e){return Yi(this).join(e)},lastIndexOf(...e){return no(this,"lastIndexOf",e)},map(e,t){return ni(this,"map",e,t,void 0,arguments)},pop(){return xn(this,"pop")},push(...e){return xn(this,"push",e)},reduce(e,...t){return Ir(this,"reduce",e,t)},reduceRight(e,...t){return Ir(this,"reduceRight",e,t)},shift(){return xn(this,"shift")},some(e,t){return ni(this,"some",e,t,void 0,arguments)},splice(...e){return xn(this,"splice",e)},toReversed(){return Yi(this).toReversed()},toSorted(e){return Yi(this).toSorted(e)},toSpliced(...e){return Yi(this).toSpliced(...e)},unshift(...e){return xn(this,"unshift",e)},values(){return io(this,"values",e=>Vt(this,e))}};function io(e,t,i){const n=Hs(e),s=n[t]();return n!==e&&!Lt(e)&&(s._next=s.next,s.next=()=>{const o=s._next();return o.done||(o.value=i(o.value)),o}),s}const Dd=Array.prototype;function ni(e,t,i,n,s,o){const a=Hs(e),r=a!==e&&!Lt(e),l=a[t];if(l!==Dd[t]){const d=l.apply(e,o);return r?Ht(d):d}let c=i;a!==e&&(r?c=function(d,h){return i.call(this,Vt(e,d),h,e)}:i.length>2&&(c=function(d,h){return i.call(this,d,h,e)}));const u=l.call(a,c,n);return r&&s?s(u):u}function Ir(e,t,i,n){const s=Hs(e),o=s!==e&&!Lt(e);let a=i,r=!1;s!==e&&(o?(r=n.length===0,a=function(c,u,d){return r&&(r=!1,c=Vt(e,c)),i.call(this,c,Vt(e,u),d,e)}):i.length>3&&(a=function(c,u,d){return i.call(this,c,u,d,e)}));const l=s[t](a,...n);return r?Vt(e,l):l}function no(e,t,i){const n=We(e);mt(n,"iterate",Wn);const s=n[t](...i);return(s===-1||s===!1)&&Qo(i[0])?(i[0]=We(i[0]),n[t](...i)):s}function xn(e,t,i=[]){pi(),Ko();const n=We(e)[t].apply(e,i);return qo(),hi(),n}const Ld=Wo("__proto__,__v_isRef,__isVue"),Ua=new Set(Object.getOwnPropertyNames(Symbol).filter(e=>e!=="arguments"&&e!=="caller").map(e=>Symbol[e]).filter(zt));function Pd(e){zt(e)||(e=String(e));const t=We(this);return mt(t,"has",e),t.hasOwnProperty(e)}class Va{constructor(t=!1,i=!1){this._isReadonly=t,this._isShallow=i}get(t,i,n){if(i==="__v_skip")return t.__v_skip;const s=this._isReadonly,o=this._isShallow;if(i==="__v_isReactive")return!s;if(i==="__v_isReadonly")return s;if(i==="__v_isShallow")return o;if(i==="__v_raw")return n===(s?o?Vd:Ya:o?qa:Ka).get(t)||Object.getPrototypeOf(t)===Object.getPrototypeOf(n)?t:void 0;const a=Ee(t);if(!s){let l;if(a&&(l=Bd[i]))return l;if(i==="hasOwnProperty")return Pd}const r=Reflect.get(t,i,tt(t)?t:n);if((zt(i)?Ua.has(i):Ld(i))||(s||mt(t,"get",i),o))return r;if(tt(r)){const l=a&&Vo(i)?r:r.value;return s&&qe(l)?$o(l):l}return qe(r)?s?$o(r):Fs(r):r}}class Ga extends Va{constructor(t=!1){super(!1,t)}set(t,i,n,s){let o=t[i];const a=Ee(t)&&Vo(i);if(!this._isShallow){const c=mi(o);if(!Lt(n)&&!mi(n)&&(o=We(o),n=We(n)),!a&&tt(o)&&!tt(n))return c||(o.value=n),!0}const r=a?Number(i)<t.length:Ue(t,i),l=Reflect.set(t,i,n,tt(t)?t:s);return t===We(s)&&l&&(r?Kt(n,o)&&li(t,"set",i,n):li(t,"add",i,n)),l}deleteProperty(t,i){const n=Ue(t,i);t[i];const s=Reflect.deleteProperty(t,i);return s&&n&&li(t,"delete",i,void 0),s}has(t,i){const n=Reflect.has(t,i);return(!zt(i)||!Ua.has(i))&&mt(t,"has",i),n}ownKeys(t){return mt(t,"iterate",Ee(t)?"length":ji),Reflect.ownKeys(t)}}class Od extends Va{constructor(t=!1){super(!0,t)}set(t,i){return!0}deleteProperty(t,i){return!0}}const Rd=new Ga,Nd=new Od,zd=new Ga(!0);const _o=e=>e,ns=e=>Reflect.getPrototypeOf(e);function Hd(e,t,i){return function(...n){const s=this.__v_raw,o=We(s),a=rn(o),r=e==="entries"||e===Symbol.iterator&&a,l=e==="keys"&&a,c=s[e](...n),u=i?_o:t?un:Ht;return!t&&mt(o,"iterate",l?Co:ji),ut(Object.create(c),{next(){const{value:d,done:h}=c.next();return h?{value:d,done:h}:{value:r?[u(d[0]),u(d[1])]:u(d),done:h}}})}}function ss(e){return function(...t){return e==="delete"?!1:e==="clear"?void 0:this}}function Fd(e,t){const i={get(s){const o=this.__v_raw,a=We(o),r=We(s);e||(Kt(s,r)&&mt(a,"get",s),mt(a,"get",r));const{has:l}=ns(a),c=t?_o:e?un:Ht;if(l.call(a,s))return c(o.get(s));if(l.call(a,r))return c(o.get(r));o!==a&&o.get(s)},get size(){const s=this.__v_raw;return!e&&mt(We(s),"iterate",ji),s.size},has(s){const o=this.__v_raw,a=We(o),r=We(s);return e||(Kt(s,r)&&mt(a,"has",s),mt(a,"has",r)),s===r?o.has(s):o.has(s)||o.has(r)},forEach(s,o){const a=this,r=a.__v_raw,l=We(r),c=t?_o:e?un:Ht;return!e&&mt(l,"iterate",ji),r.forEach((u,d)=>s.call(o,c(u),c(d),a))}};return ut(i,e?{add:ss("add"),set:ss("set"),delete:ss("delete"),clear:ss("clear")}:{add(s){const o=We(this),a=ns(o),r=We(s),l=!t&&!Lt(s)&&!mi(s)?r:s;return a.has.call(o,l)||Kt(s,l)&&a.has.call(o,s)||Kt(r,l)&&a.has.call(o,r)||(o.add(l),li(o,"add",l,l)),this},set(s,o){!t&&!Lt(o)&&!mi(o)&&(o=We(o));const a=We(this),{has:r,get:l}=ns(a);let c=r.call(a,s);c||(s=We(s),c=r.call(a,s));const u=l.call(a,s);return a.set(s,o),c?Kt(o,u)&&li(a,"set",s,o):li(a,"add",s,o),this},delete(s){const o=We(this),{has:a,get:r}=ns(o);let l=a.call(o,s);l||(s=We(s),l=a.call(o,s)),r&&r.call(o,s);const c=o.delete(s);return l&&li(o,"delete",s,void 0),c},clear(){const s=We(this),o=s.size!==0,a=s.clear();return o&&li(s,"clear",void 0,void 0),a}}),["keys","values","entries",Symbol.iterator].forEach(s=>{i[s]=Hd(s,e,t)}),i}function Jo(e,t){const i=Fd(e,t);return(n,s,o)=>s==="__v_isReactive"?!e:s==="__v_isReadonly"?e:s==="__v_raw"?n:Reflect.get(Ue(i,s)&&s in n?i:n,s,o)}const jd={get:Jo(!1,!1)},Wd={get:Jo(!1,!0)},Ud={get:Jo(!0,!1)};const Ka=new WeakMap,qa=new WeakMap,Ya=new WeakMap,Vd=new WeakMap;function Gd(e){switch(e){case"Object":case"Array":return 1;case"Map":case"Set":case"WeakMap":case"WeakSet":return 2;default:return 0}}function Fs(e){return mi(e)?e:Xo(e,!1,Rd,jd,Ka)}function Kd(e){return Xo(e,!1,zd,Wd,qa)}function $o(e){return Xo(e,!0,Nd,Ud,Ya)}function Xo(e,t,i,n,s){if(!qe(e)||e.__v_raw&&!(t&&e.__v_isReactive)||e.__v_skip||!Object.isExtensible(e))return e;const o=s.get(e);if(o)return o;const a=Gd(bd(e));if(a===0)return e;const r=new Proxy(e,a===2?n:i);return s.set(e,r),r}function Wi(e){return mi(e)?Wi(e.__v_raw):!!(e&&e.__v_isReactive)}function mi(e){return!!(e&&e.__v_isReadonly)}function Lt(e){return!!(e&&e.__v_isShallow)}function Qo(e){return e?!!e.__v_raw:!1}function We(e){const t=e&&e.__v_raw;return t?We(t):e}function qd(e){return!Ue(e,"__v_skip")&&Object.isExtensible(e)&&Ba(e,"__v_skip",!0),e}const Ht=e=>qe(e)?Fs(e):e,un=e=>qe(e)?$o(e):e;function tt(e){return e?e.__v_isRef===!0:!1}function ge(e){return Yd(e,!1)}function Yd(e,t){return tt(e)?e:new Zd(e,t)}class Zd{constructor(t,i){this.dep=new Zo,this.__v_isRef=!0,this.__v_isShallow=!1,this._rawValue=i?t:We(t),this._value=i?t:Ht(t),this.__v_isShallow=i}get value(){return this.dep.track(),this._value}set value(t){const i=this._rawValue,n=this.__v_isShallow||Lt(t)||mi(t);t=n?t:We(t),Kt(t,i)&&(this._rawValue=t,this._value=n?t:Ht(t),this.dep.trigger())}}function he(e){return tt(e)?e.value:e}const Jd={get:(e,t,i)=>t==="__v_raw"?e:he(Reflect.get(e,t,i)),set:(e,t,i,n)=>{const s=e[t];return tt(s)&&!tt(i)?(s.value=i,!0):Reflect.set(e,t,i,n)}};function Za(e){return Wi(e)?e:new Proxy(e,Jd)}class Xd{constructor(t,i,n){this.fn=t,this.setter=i,this._value=void 0,this.dep=new Zo(this),this.__v_isRef=!0,this.deps=void 0,this.depsTail=void 0,this.flags=16,this.globalVersion=jn-1,this.next=void 0,this.effect=this,this.__v_isReadonly=!i,this.isSSR=n}notify(){if(this.flags|=16,!(this.flags&8)&&Qe!==this)return Na(this,!0),!0}get value(){const t=this.dep.track();return Fa(this),t&&(t.version=this.dep.version),this._value}set value(t){this.setter&&this.setter(t)}}function Qd(e,t,i=!1){let n,s;return Be(e)?n=e:(n=e.get,s=e.set),new Xd(n,s,i)}const os={},_s=new WeakMap;let Oi;function eu(e,t=!1,i=Oi){if(i){let n=_s.get(i);n||_s.set(i,n=[]),n.push(e)}}function tu(e,t,i=Je){const{immediate:n,deep:s,once:o,scheduler:a,augmentJob:r,call:l}=i,c=x=>s?x:Lt(x)||s===!1||s===0?ci(x,1):ci(x);let u,d,h,p,b=!1,m=!1;if(tt(e)?(d=()=>e.value,b=Lt(e)):Wi(e)?(d=()=>c(e),b=!0):Ee(e)?(m=!0,b=e.some(x=>Wi(x)||Lt(x)),d=()=>e.map(x=>{if(tt(x))return x.value;if(Wi(x))return c(x);if(Be(x))return l?l(x,2):x()})):Be(e)?t?d=l?()=>l(e,2):e:d=()=>{if(h){pi();try{h()}finally{hi()}}const x=Oi;Oi=u;try{return l?l(e,3,[p]):e(p)}finally{Oi=x}}:d=Xt,t&&s){const x=d,M=s===!0?1/0:s;d=()=>ci(x(),M)}const y=Td(),g=()=>{u.stop(),y&&y.active&&Uo(y.effects,u)};if(o&&t){const x=t;t=(...M)=>{const E=x(...M);return g(),E}}let w=m?new Array(e.length).fill(os):os;const S=x=>{if(!(!(u.flags&1)||!u.dirty&&!x))if(t){const M=u.run();if(x||s||b||(m?M.some((E,C)=>Kt(E,w[C])):Kt(M,w))){h&&h();const E=Oi;Oi=u;try{const C=[M,w===os?void 0:m&&w[0]===os?[]:w,p];w=M,l?l(t,3,C):t(...C)}finally{Oi=E}}}else u.run()};return r&&r(S),u=new Oa(d),u.scheduler=a?()=>a(S,!1):S,p=x=>eu(x,!1,u),h=u.onStop=()=>{const x=_s.get(u);if(x){if(l)l(x,4);else for(const M of x)M();_s.delete(u)}},t?n?S(!0):w=u.run():a?a(S.bind(null,!0),!0):u.run(),g.pause=u.pause.bind(u),g.resume=u.resume.bind(u),g.stop=g,g}function ci(e,t=1/0,i){if(t<=0||!qe(e)||e.__v_skip||(i=i||new Map,(i.get(e)||0)>=t))return e;if(i.set(e,t),t--,tt(e))ci(e.value,t,i);else if(Ee(e))for(let n=0;n<e.length;n++)ci(e[n],t,i);else if(mn(e)||rn(e))e.forEach(n=>{ci(n,t,i)});else if(Aa(e)){for(const n in e)ci(e[n],t,i);for(const n of Object.getOwnPropertySymbols(e))Object.prototype.propertyIsEnumerable.call(e,n)&&ci(e[n],t,i)}return e}/**
* @vue/runtime-core v3.5.40
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/function Jn(e,t,i,n){try{return n?e(...n):e()}catch(s){js(s,t,i)}}function Ft(e,t,i,n){if(Be(e)){const s=Jn(e,t,i,n);return s&&Ta(s)&&s.catch(o=>{js(o,t,i)}),s}if(Ee(e)){const s=[];for(let o=0;o<e.length;o++)s.push(Ft(e[o],t,i,n));return s}}function js(e,t,i,n=!0){const s=t?t.vnode:null,{errorHandler:o,throwUnhandledErrorInProduction:a}=t&&t.appContext.config||Je;if(t){let r=t.parent;const l=t.proxy,c=`https://vuejs.org/error-reference/#runtime-${i}`;for(;r;){const u=r.ec;if(u){for(let d=0;d<u.length;d++)if(u[d](e,l,c)===!1)return}r=r.parent}if(o){pi(),Jn(o,null,10,[e,l,c]),hi();return}}iu(e,i,s,n,a)}function iu(e,t,i,n=!0,s=!1){if(s)throw e;console.error(e)}const wt=[];let Wt=-1;const an=[];let xi=null,Zi=0;const Ja=Promise.resolve();let $s=null;function Is(e){const t=$s||Ja;return e?t.then(this?e.bind(this):e):t}function nu(e){let t=Wt+1,i=wt.length;for(;t<i;){const n=t+i>>>1,s=wt[n],o=Un(s);o<e||o===e&&s.flags&2?t=n+1:i=n}return t}function er(e){if(!(e.flags&1)){const t=Un(e),i=wt[wt.length-1];!i||!(e.flags&2)&&t>=Un(i)?wt.push(e):wt.splice(nu(t),0,e),e.flags|=1,Xa()}}function Xa(){$s||($s=Ja.then(el))}function su(e){Ee(e)?an.push(...e):xi&&e.id===-1?xi.splice(Zi+1,0,e):e.flags&1||(an.push(e),e.flags|=1),Xa()}function Mr(e,t,i=Wt+1){for(;i<wt.length;i++){const n=wt[i];if(n&&n.flags&2){if(e&&n.id!==e.uid)continue;wt.splice(i,1),i--,n.flags&4&&(n.flags&=-2),n(),n.flags&4||(n.flags&=-2)}}}function Qa(e){if(an.length){const t=[...new Set(an)].sort((i,n)=>Un(i)-Un(n));if(an.length=0,xi){xi.push(...t);return}for(xi=t,Zi=0;Zi<xi.length;Zi++){const i=xi[Zi];i.flags&4&&(i.flags&=-2),i.flags&8||i(),i.flags&=-2}xi=null,Zi=0}}const Un=e=>e.id==null?e.flags&2?-1:1/0:e.id;function el(e){try{for(Wt=0;Wt<wt.length;Wt++){const t=wt[Wt];t&&!(t.flags&8)&&(t.flags&4&&(t.flags&=-2),Jn(t,t.i,t.i?15:14),t.flags&4||(t.flags&=-2))}}finally{for(;Wt<wt.length;Wt++){const t=wt[Wt];t&&(t.flags&=-2)}Wt=-1,wt.length=0,Qa(),$s=null,(wt.length||an.length)&&el()}}let dt=null,tl=null;function Ms(e){const t=dt;return dt=e,tl=e&&e.type.__scopeId||null,t}function il(e,t=dt,i){if(!t||e._n)return e;const n=(...s)=>{n._d&&Hr(-1);const o=Ms(t),a=di.length;let r;try{r=e(...s)}finally{for(let l=di.length;l>a;l--)or();Ms(o),n._d&&Hr(1)}return r};return n._n=!0,n._c=!0,n._d=!0,n}function Pt(e,t){if(dt===null)return e;const i=Ks(dt),n=e.dirs||(e.dirs=[]);for(let s=0;s<t.length;s++){let[o,a,r,l=Je]=t[s];o&&(Be(o)&&(o={mounted:o,updated:o}),o.deep&&ci(a),n.push({dir:o,instance:i,value:a,oldValue:void 0,arg:r,modifiers:l}))}return e}function Bi(e,t,i,n){const s=e.dirs,o=t&&t.dirs;for(let a=0;a<s.length;a++){const r=s[a];o&&(r.oldValue=o[a].value);let l=r.dir[n];l&&(pi(),Ft(l,i,8,[e.el,r,e,t]),hi())}}function ou(e,t){if(bt){let i=bt.provides;const n=bt.parent&&bt.parent.provides;n===i&&(i=bt.provides=Object.create(n)),i[e]=t}}function Nt(e,t,i=!1){const n=sf();if(n||cn){let s=cn?cn._context.provides:n?n.parent==null||n.ce?n.vnode.appContext&&n.vnode.appContext.provides:n.parent.provides:void 0;if(s&&e in s)return s[e];if(arguments.length>1)return i&&Be(t)?t.call(n&&n.proxy):t}}const ru=Symbol.for("v-scx"),au=()=>Nt(ru);function Ui(e,t,i){return nl(e,t,i)}function nl(e,t,i=Je){const{immediate:n,deep:s,flush:o,once:a}=i,r=ut({},i),l=t&&n||!t&&o!=="post";let c;if(Gn){if(o==="sync"){const p=au();c=p.__watcherHandles||(p.__watcherHandles=[])}else if(!l){const p=()=>{};return p.stop=Xt,p.resume=Xt,p.pause=Xt,p}}const u=bt;r.call=(p,b,m)=>Ft(p,u,b,m);let d=!1;o==="post"?r.scheduler=p=>{Ct(p,u&&u.suspense)}:o!=="sync"&&(d=!0,r.scheduler=(p,b)=>{b?p():er(p)}),r.augmentJob=p=>{t&&(p.flags|=4),d&&(p.flags|=2,u&&(p.id=u.uid,p.i=u))};const h=tu(e,t,r);return Gn&&(c?c.push(h):l&&h()),h}function lu(e,t,i){const n=this.proxy,s=nt(e)?e.includes(".")?sl(n,e):()=>n[e]:e.bind(n,n);let o;Be(t)?o=t:(o=t.handler,i=t);const a=Xn(this),r=nl(s,o.bind(n),i);return a(),r}function sl(e,t){const i=t.split(".");return()=>{let n=e;for(let s=0;s<i.length&&n;s++)n=n[i[s]];return n}}const cu=Symbol("_vte"),du=e=>e.__isTeleport,so=Symbol("_leaveCb");function tr(e,t){e.shapeFlag&6&&e.component?(e.transition=t,tr(e.component.subTree,t)):e.shapeFlag&128?(e.ssContent.transition=t.clone(e.ssContent),e.ssFallback.transition=t.clone(e.ssFallback)):e.transition=t}function Bt(e,t){return Be(e)?ut({name:e.name},t,{setup:e}):e}function ol(e){e.ids=[e.ids[0]+e.ids[2]+++"-",0,0]}function Tr(e,t){let i;return!!((i=Object.getOwnPropertyDescriptor(e,t))&&!i.configurable)}const Ts=new WeakMap;function Bn(e,t,i,n,s=!1){if(Ee(e)){e.forEach((m,y)=>Bn(m,t&&(Ee(t)?t[y]:t),i,n,s));return}if(ln(n)&&!s){n.shapeFlag&512&&n.type.__asyncResolved&&n.component.subTree.component&&Bn(e,t,i,n.component.subTree);return}const o=n.shapeFlag&4?Ks(n.component):n.el,a=s?null:o,{i:r,r:l}=e,c=t&&t.r,u=r.refs===Je?r.refs={}:r.refs,d=r.setupState,h=We(d),p=d===Je?Ma:m=>Tr(u,m)?!1:Ue(h,m),b=(m,y)=>!(y&&Tr(u,y));if(c!=null&&c!==l){if(Er(t),nt(c))u[c]=null,p(c)&&(d[c]=null);else if(tt(c)){const m=t;b(c,m.k)&&(c.value=null),m.k&&(u[m.k]=null)}}if(Be(l))Jn(l,r,12,[a,u]);else{const m=nt(l),y=tt(l);if(m||y){const g=()=>{if(e.f){const w=m?p(l)?d[l]:u[l]:b()||!e.k?l.value:u[e.k];if(s)Ee(w)&&Uo(w,o);else if(Ee(w))w.includes(o)||w.push(o);else if(m)u[l]=[o],p(l)&&(d[l]=u[l]);else{const S=[o];b(l,e.k)&&(l.value=S),e.k&&(u[e.k]=S)}}else m?(u[l]=a,p(l)&&(d[l]=a)):y&&(b(l,e.k)&&(l.value=a),e.k&&(u[e.k]=a))};if(a){const w=()=>{g(),Ts.delete(e)};w.id=-1,Ts.set(e,w),Ct(w,i)}else Er(e),g()}}}function Er(e){const t=Ts.get(e);t&&(t.flags|=8,Ts.delete(e))}zs().requestIdleCallback;zs().cancelIdleCallback;const ln=e=>!!e.type.__asyncLoader,rl=e=>e.type.__isKeepAlive;function uu(e,t){al(e,"a",t)}function fu(e,t){al(e,"da",t)}function al(e,t,i=bt){const n=e.__wdc||(e.__wdc=()=>{let s=i;for(;s;){if(s.isDeactivated)return;s=s.parent}return e()});if(Ws(t,n,i),i){let s=i.parent;for(;s&&s.parent;)rl(s.parent.vnode)&&pu(n,t,i,s),s=s.parent}}function pu(e,t,i,n){const s=Ws(t,e,n,!0);Us(()=>{Uo(n[t],s)},i)}function Ws(e,t,i=bt,n=!1){if(i){const s=i[e]||(i[e]=[]),o=t.__weh||(t.__weh=(...a)=>{pi();const r=Xn(i),l=Ft(t,i,e,a);return r(),hi(),l});return n?s.unshift(o):s.push(o),o}}const vi=e=>(t,i=bt)=>{(!Gn||e==="sp")&&Ws(e,(...n)=>t(...n),i)},hu=vi("bm"),vn=vi("m"),mu=vi("bu"),gu=vi("u"),ir=vi("bum"),Us=vi("um"),vu=vi("sp"),bu=vi("rtg"),yu=vi("rtc");function ku(e,t=bt){Ws("ec",e,t)}const wu="components";function xu(e,t){return Cu(wu,e,!0,t)||e}const Su=Symbol.for("v-ndc");function Cu(e,t,i=!0,n=!1){const s=dt||bt;if(s){const o=s.type;{const r=cf(o,!1);if(r&&(r===t||r===St(t)||r===Rs(St(t))))return o}const a=Ar(s[e]||o[e],t)||Ar(s.appContext[e],t);return!a&&n?o:a}}function Ar(e,t){return e&&(e[t]||e[St(t)]||e[Rs(St(t))])}function xt(e,t,i,n){let s;const o=i,a=Ee(e);if(a||nt(e)){const r=a&&Wi(e);let l=!1,c=!1;r&&(l=!Lt(e),c=mi(e),e=Hs(e)),s=new Array(e.length);for(let u=0,d=e.length;u<d;u++)s[u]=t(l?c?un(Ht(e[u])):Ht(e[u]):e[u],u,void 0,o)}else if(typeof e=="number"){s=new Array(e);for(let r=0;r<e;r++)s[r]=t(r+1,r,void 0,o)}else if(qe(e))if(e[Symbol.iterator])s=Array.from(e,(r,l)=>t(r,l,void 0,o));else{const r=Object.keys(e);s=new Array(r.length);for(let l=0,c=r.length;l<c;l++){const u=r[l];s[l]=t(e[u],u,l,o)}}else s=[];return s}function rs(e,t,i={},n,s,o){if(dt.ce||dt.parent&&ln(dt.parent)&&dt.parent.ce){const c=i,u=Object.keys(c).length>0;return t!=="default"&&(c.name=t),J(),Zt(Xe,null,[ae("slot",c,n&&n())],u?-2:64)}let a=e[t];a&&a._c&&(a._d=!1);const r=di.length;J();let l;try{const c=a&&ll(a(i)),u=i.key||o||c&&c.key;l=Zt(Xe,{key:(u&&!zt(u)?u:`_${t}`)+(!c&&n?"_fb":"")},c||(n?n():[]),c&&e._===1?64:-2)}catch(c){for(let u=di.length;u>r;u--)or();throw c}finally{a&&a._c&&(a._d=!0)}return l}function ll(e){return e.some(t=>rr(t)?!(t.type===gi||t.type===Xe&&!ll(t.children)):!0)?e:null}const Io=e=>e?Ml(e)?Ks(e):Io(e.parent):null,Dn=ut(Object.create(null),{$:e=>e,$el:e=>e.vnode.el,$data:e=>e.data,$props:e=>e.props,$attrs:e=>e.attrs,$slots:e=>e.slots,$refs:e=>e.refs,$parent:e=>Io(e.parent),$root:e=>Io(e.root),$host:e=>e.ce,$emit:e=>e.emit,$options:e=>dl(e),$forceUpdate:e=>e.f||(e.f=()=>{er(e.update)}),$nextTick:e=>e.n||(e.n=Is.bind(e.proxy)),$watch:e=>lu.bind(e)}),oo=(e,t)=>e!==Je&&!e.__isScriptSetup&&Ue(e,t),_u={get({_:e},t){if(t==="__v_skip")return!0;const{ctx:i,setupState:n,data:s,props:o,accessCache:a,type:r,appContext:l}=e;if(t[0]!=="$"){const h=a[t];if(h!==void 0)switch(h){case 1:return n[t];case 2:return s[t];case 4:return i[t];case 3:return o[t]}else{if(oo(n,t))return a[t]=1,n[t];if(s!==Je&&Ue(s,t))return a[t]=2,s[t];if(Ue(o,t))return a[t]=3,o[t];if(i!==Je&&Ue(i,t))return a[t]=4,i[t];Mo&&(a[t]=0)}}const c=Dn[t];let u,d;if(c)return t==="$attrs"&&mt(e.attrs,"get",""),c(e);if((u=r.__cssModules)&&(u=u[t]))return u;if(i!==Je&&Ue(i,t))return a[t]=4,i[t];if(d=l.config.globalProperties,Ue(d,t))return d[t]},set({_:e},t,i){const{data:n,setupState:s,ctx:o}=e;return oo(s,t)?(s[t]=i,!0):n!==Je&&Ue(n,t)?(n[t]=i,!0):Ue(e.props,t)||t[0]==="$"&&t.slice(1)in e?!1:(o[t]=i,!0)},has({_:{data:e,setupState:t,accessCache:i,ctx:n,appContext:s,props:o,type:a}},r){let l;return!!(i[r]||e!==Je&&r[0]!=="$"&&Ue(e,r)||oo(t,r)||Ue(o,r)||Ue(n,r)||Ue(Dn,r)||Ue(s.config.globalProperties,r)||(l=a.__cssModules)&&l[r])},defineProperty(e,t,i){return i.get!=null?e._.accessCache[t]=0:Ue(i,"value")&&this.set(e,t,i.value,null),Reflect.defineProperty(e,t,i)}};function Br(e){return Ee(e)?e.reduce((t,i)=>(t[i]=null,t),{}):e}let Mo=!0;function $u(e){const t=dl(e),i=e.proxy,n=e.ctx;Mo=!1,t.beforeCreate&&Dr(t.beforeCreate,e,"bc");const{data:s,computed:o,methods:a,watch:r,provide:l,inject:c,created:u,beforeMount:d,mounted:h,beforeUpdate:p,updated:b,activated:m,deactivated:y,beforeDestroy:g,beforeUnmount:w,destroyed:S,unmounted:x,render:M,renderTracked:E,renderTriggered:C,errorCaptured:D,serverPrefetch:R,expose:N,inheritAttrs:K,components:$,directives:V,filters:k}=t;if(c&&Iu(c,n,null),a)for(const I in a){const A=a[I];Be(A)&&(n[I]=A.bind(i))}if(s){const I=s.call(i,i);qe(I)&&(e.data=Fs(I))}if(Mo=!0,o)for(const I in o){const A=o[I],O=Be(A)?A.bind(i,i):Be(A.get)?A.get.bind(i,i):Xt,ne=!Be(A)&&Be(A.set)?A.set.bind(i):Xt,G=ye({get:O,set:ne});Object.defineProperty(n,I,{enumerable:!0,configurable:!0,get:()=>G.value,set:q=>G.value=q})}if(r)for(const I in r)cl(r[I],n,i,I);if(l){const I=Be(l)?l.call(i):l;Reflect.ownKeys(I).forEach(A=>{ou(A,I[A])})}u&&Dr(u,e,"c");function H(I,A){Ee(A)?A.forEach(O=>I(O.bind(i))):A&&I(A.bind(i))}if(H(hu,d),H(vn,h),H(mu,p),H(gu,b),H(uu,m),H(fu,y),H(ku,D),H(yu,E),H(bu,C),H(ir,w),H(Us,x),H(vu,R),Ee(N))if(N.length){const I=e.exposed||(e.exposed={});N.forEach(A=>{Object.defineProperty(I,A,{get:()=>i[A],set:O=>i[A]=O,enumerable:!0})})}else e.exposed||(e.exposed={});M&&e.render===Xt&&(e.render=M),K!=null&&(e.inheritAttrs=K),$&&(e.components=$),V&&(e.directives=V),R&&ol(e)}function Iu(e,t,i=Xt){Ee(e)&&(e=To(e));for(const n in e){const s=e[n];let o;qe(s)?"default"in s?o=Nt(s.from||n,s.default,!0):o=Nt(s.from||n):o=Nt(s),tt(o)?Object.defineProperty(t,n,{enumerable:!0,configurable:!0,get:()=>o.value,set:a=>o.value=a}):t[n]=o}}function Dr(e,t,i){Ft(Ee(e)?e.map(n=>n.bind(t.proxy)):e.bind(t.proxy),t,i)}function cl(e,t,i,n){let s=n.includes(".")?sl(i,n):()=>i[n];if(nt(e)){const o=t[e];Be(o)&&Ui(s,o)}else if(Be(e))Ui(s,e.bind(i));else if(qe(e))if(Ee(e))e.forEach(o=>cl(o,t,i,n));else{const o=Be(e.handler)?e.handler.bind(i):t[e.handler];Be(o)&&Ui(s,o,e)}}function dl(e){const t=e.type,{mixins:i,extends:n}=t,{mixins:s,optionsCache:o,config:{optionMergeStrategies:a}}=e.appContext,r=o.get(t);let l;return r?l=r:!s.length&&!i&&!n?l=t:(l={},s.length&&s.forEach(c=>Es(l,c,a,!0)),Es(l,t,a)),qe(t)&&o.set(t,l),l}function Es(e,t,i,n=!1){const{mixins:s,extends:o}=t;o&&Es(e,o,i,!0),s&&s.forEach(a=>Es(e,a,i,!0));for(const a in t)if(!(n&&a==="expose")){const r=Mu[a]||i&&i[a];e[a]=r?r(e[a],t[a]):t[a]}return e}const Mu={data:Lr,props:Pr,emits:Pr,methods:_n,computed:_n,beforeCreate:kt,created:kt,beforeMount:kt,mounted:kt,beforeUpdate:kt,updated:kt,beforeDestroy:kt,beforeUnmount:kt,destroyed:kt,unmounted:kt,activated:kt,deactivated:kt,errorCaptured:kt,serverPrefetch:kt,components:_n,directives:_n,watch:Eu,provide:Lr,inject:Tu};function Lr(e,t){return t?e?function(){return ut(Be(e)?e.call(this,this):e,Be(t)?t.call(this,this):t)}:t:e}function Tu(e,t){return _n(To(e),To(t))}function To(e){if(Ee(e)){const t={};for(let i=0;i<e.length;i++)t[e[i]]=e[i];return t}return e}function kt(e,t){return e?[...new Set([].concat(e,t))]:t}function _n(e,t){return e?ut(Object.create(null),e,t):t}function Pr(e,t){return e?Ee(e)&&Ee(t)?[...new Set([...e,...t])]:ut(Object.create(null),Br(e),Br(t??{})):t}function Eu(e,t){if(!e)return t;if(!t)return e;const i=ut(Object.create(null),e);for(const n in t)i[n]=kt(e[n],t[n]);return i}function ul(){return{app:null,config:{isNativeTag:Ma,performance:!1,globalProperties:{},optionMergeStrategies:{},errorHandler:void 0,warnHandler:void 0,compilerOptions:{}},mixins:[],components:{},directives:{},provides:Object.create(null),optionsCache:new WeakMap,propsCache:new WeakMap,emitsCache:new WeakMap}}let Au=0;function Bu(e,t){return function(n,s=null){Be(n)||(n=ut({},n)),s!=null&&!qe(s)&&(s=null);const o=ul(),a=new WeakSet,r=[];let l=!1;const c=o.app={_uid:Au++,_component:n,_props:s,_container:null,_context:o,_instance:null,version:uf,get config(){return o.config},set config(u){},use(u,...d){return a.has(u)||(u&&Be(u.install)?(a.add(u),u.install(c,...d)):Be(u)&&(a.add(u),u(c,...d))),c},mixin(u){return o.mixins.includes(u)||o.mixins.push(u),c},component(u,d){return d?(o.components[u]=d,c):o.components[u]},directive(u,d){return d?(o.directives[u]=d,c):o.directives[u]},mount(u,d,h){if(!l){const p=c._ceVNode||ae(n,s);return p.appContext=o,h===!0?h="svg":h===!1&&(h=void 0),e(p,u,h),l=!0,c._container=u,u.__vue_app__=c,Ks(p.component)}},onUnmount(u){r.push(u)},unmount(){l&&(Ft(r,c._instance,16),e(null,c._container),delete c._container.__vue_app__)},provide(u,d){return o.provides[u]=d,c},runWithContext(u){const d=cn;cn=c;try{return u()}finally{cn=d}}};return c}}let cn=null;const Du=(e,t)=>t==="modelValue"||t==="model-value"?e.modelModifiers:e[`${t}Modifiers`]||e[`${St(t)}Modifiers`]||e[`${Ei(t)}Modifiers`];function Lu(e,t,...i){if(e.isUnmounted)return;const n=e.vnode.props||Je;let s=i;const o=t.startsWith("update:"),a=o&&Du(n,t.slice(7));a&&(a.trim&&(s=i.map(u=>nt(u)?u.trim():u)),a.number&&(s=i.map(Ns)));let r,l=n[r=Qs(t)]||n[r=Qs(St(t))];!l&&o&&(l=n[r=Qs(Ei(t))]),l&&Ft(l,e,6,s);const c=n[r+"Once"];if(c){if(!e.emitted)e.emitted={};else if(e.emitted[r])return;e.emitted[r]=!0,Ft(c,e,6,s)}}const Pu=new WeakMap;function fl(e,t,i=!1){const n=i?Pu:t.emitsCache,s=n.get(e);if(s!==void 0)return s;const o=e.emits;let a={},r=!1;if(!Be(e)){const l=c=>{const u=fl(c,t,!0);u&&(r=!0,ut(a,u))};!i&&t.mixins.length&&t.mixins.forEach(l),e.extends&&l(e.extends),e.mixins&&e.mixins.forEach(l)}return!o&&!r?(qe(e)&&n.set(e,null),null):(Ee(o)?o.forEach(l=>a[l]=null):ut(a,o),qe(e)&&n.set(e,a),a)}function Vs(e,t){return!e||!Ls(t)?!1:(t=t.slice(2),t=t==="Once"?t:t.replace(/Once$/,""),Ue(e,t[0].toLowerCase()+t.slice(1))||Ue(e,Ei(t))||Ue(e,t))}function Or(e){const{type:t,vnode:i,proxy:n,withProxy:s,propsOptions:[o],slots:a,attrs:r,emit:l,render:c,renderCache:u,props:d,data:h,setupState:p,ctx:b,inheritAttrs:m}=e,y=Ms(e);let g,w;try{if(i.shapeFlag&4){const x=s||n,M=x;g=Gt(c.call(M,x,u,d,p,h,b)),w=r}else{const x=t;g=Gt(x.length>1?x(d,{attrs:r,slots:a,emit:l}):x(d,null)),w=t.props?r:Ou(r)}}catch(x){di.length=0,js(x,e,1),g=ae(gi)}let S=g;if(w&&m!==!1){const x=Object.keys(w),{shapeFlag:M}=S;x.length&&M&7&&(o&&x.some(Ps)&&(w=Ru(w,o)),S=fn(S,w,!1,!0))}return i.dirs&&(S=fn(S,null,!1,!0),S.dirs=S.dirs?S.dirs.concat(i.dirs):i.dirs),i.transition&&tr(S,i.transition),g=S,Ms(y),g}const Ou=e=>{let t;for(const i in e)(i==="class"||i==="style"||Ls(i))&&((t||(t={}))[i]=e[i]);return t},Ru=(e,t)=>{const i={};for(const n in e)(!Ps(n)||!(n.slice(9)in t))&&(i[n]=e[n]);return i};function Nu(e,t,i){const{props:n,children:s,component:o}=e,{props:a,children:r,patchFlag:l}=t,c=o.emitsOptions;if(t.dirs||t.transition)return!0;if(i&&l>=0){if(l&1024)return!0;if(l&16)return n?Rr(n,a,c):!!a;if(l&8){const u=t.dynamicProps;for(let d=0;d<u.length;d++){const h=u[d];if(pl(a,n,h)&&!Vs(c,h))return!0}}}else return(s||r)&&(!r||!r.$stable)?!0:n===a?!1:n?a?Rr(n,a,c):!0:!!a;return!1}function Rr(e,t,i){const n=Object.keys(t);if(n.length!==Object.keys(e).length)return!0;for(let s=0;s<n.length;s++){const o=n[s];if(pl(t,e,o)&&!Vs(i,o))return!0}return!1}function pl(e,t,i){const n=e[i],s=t[i];return i==="style"&&qe(n)&&qe(s)?!gn(n,s):n!==s}function zu({vnode:e,parent:t,suspense:i},n){for(;t;){const s=t.subTree;if(s.suspense&&s.suspense.activeBranch===e&&(s.suspense.vnode.el=s.el=n,e=s),s===e)(e=t.vnode).el=n,t=t.parent;else break}i&&i.activeBranch===e&&(i.vnode.el=n)}const hl={},ml=()=>Object.create(hl),gl=e=>Object.getPrototypeOf(e)===hl;function Hu(e,t,i,n=!1){const s={},o=ml();e.propsDefaults=Object.create(null),vl(e,t,s,o);for(const a in e.propsOptions[0])a in s||(s[a]=void 0);i?e.props=n?s:Kd(s):e.type.props?e.props=s:e.props=o,e.attrs=o}function Fu(e,t,i,n){const{props:s,attrs:o,vnode:{patchFlag:a}}=e,r=We(s),[l]=e.propsOptions;let c=!1;if((n||a>0)&&!(a&16)){if(a&8){const u=e.vnode.dynamicProps;for(let d=0;d<u.length;d++){let h=u[d];if(Vs(e.emitsOptions,h))continue;const p=t[h];if(l)if(Ue(o,h))p!==o[h]&&(o[h]=p,c=!0);else{const b=St(h);s[b]=Eo(l,r,b,p,e,!1)}else p!==o[h]&&(o[h]=p,c=!0)}}}else{vl(e,t,s,o)&&(c=!0);let u;for(const d in r)(!t||!Ue(t,d)&&((u=Ei(d))===d||!Ue(t,u)))&&(l?i&&(i[d]!==void 0||i[u]!==void 0)&&(s[d]=Eo(l,r,d,void 0,e,!0)):delete s[d]);if(o!==r)for(const d in o)(!t||!Ue(t,d))&&(delete o[d],c=!0)}c&&li(e.attrs,"set","")}function vl(e,t,i,n){const[s,o]=e.propsOptions;let a=!1,r;if(t)for(let l in t){if(Tn(l))continue;const c=t[l];let u;s&&Ue(s,u=St(l))?!o||!o.includes(u)?i[u]=c:(r||(r={}))[u]=c:Vs(e.emitsOptions,l)||(!(l in n)||c!==n[l])&&(n[l]=c,a=!0)}if(o){const l=We(i),c=r||Je;for(let u=0;u<o.length;u++){const d=o[u];i[d]=Eo(s,l,d,c[d],e,!Ue(c,d))}}return a}function Eo(e,t,i,n,s,o){const a=e[i];if(a!=null){const r=Ue(a,"default");if(r&&n===void 0){const l=a.default;if(a.type!==Function&&!a.skipFactory&&Be(l)){const{propsDefaults:c}=s;if(i in c)n=c[i];else{const u=Xn(s);n=c[i]=l.call(null,t),u()}}else n=l;s.ce&&s.ce._setProp(i,n)}a[0]&&(o&&!r?n=!1:a[1]&&(n===""||n===Ei(i))&&(n=!0))}return n}const ju=new WeakMap;function bl(e,t,i=!1){const n=i?ju:t.propsCache,s=n.get(e);if(s)return s;const o=e.props,a={},r=[];let l=!1;if(!Be(e)){const u=d=>{l=!0;const[h,p]=bl(d,t,!0);ut(a,h),p&&r.push(...p)};!i&&t.mixins.length&&t.mixins.forEach(u),e.extends&&u(e.extends),e.mixins&&e.mixins.forEach(u)}if(!o&&!l)return qe(e)&&n.set(e,on),on;if(Ee(o))for(let u=0;u<o.length;u++){const d=St(o[u]);Nr(d)&&(a[d]=Je)}else if(o)for(const u in o){const d=St(u);if(Nr(d)){const h=o[u],p=a[d]=Ee(h)||Be(h)?{type:h}:ut({},h),b=p.type;let m=!1,y=!0;if(Ee(b))for(let g=0;g<b.length;++g){const w=b[g],S=Be(w)&&w.name;if(S==="Boolean"){m=!0;break}else S==="String"&&(y=!1)}else m=Be(b)&&b.name==="Boolean";p[0]=m,p[1]=y,(m||Ue(p,"default"))&&r.push(d)}}const c=[a,r];return qe(e)&&n.set(e,c),c}function Nr(e){return e[0]!=="$"&&!Tn(e)}const nr=e=>e==="_"||e==="_ctx"||e==="$stable",sr=e=>Ee(e)?e.map(Gt):[Gt(e)],Wu=(e,t,i)=>{if(t._n)return t;const n=il((...s)=>sr(t(...s)),i);return n._c=!1,n},yl=(e,t,i)=>{const n=e._ctx;for(const s in e){if(nr(s))continue;const o=e[s];if(Be(o))t[s]=Wu(s,o,n);else if(o!=null){const a=sr(o);t[s]=()=>a}}},kl=(e,t)=>{const i=sr(t);e.slots.default=()=>i},wl=(e,t,i)=>{for(const n in t)(i||!nr(n))&&(e[n]=t[n])},Uu=(e,t,i)=>{const n=e.slots=ml();if(e.vnode.shapeFlag&32){const s=t._;s?(wl(n,t,i),i&&Ba(n,"_",s,!0)):yl(t,n)}else t&&kl(e,t)},Vu=(e,t,i)=>{const{vnode:n,slots:s}=e;let o=!0,a=Je;if(n.shapeFlag&32){const r=t._;r?i&&r===1?o=!1:wl(s,t,i):(o=!t.$stable,yl(t,s)),a=t}else t&&(kl(e,t),a={default:1});if(o)for(const r in s)!nr(r)&&a[r]==null&&delete s[r]},Ct=Zu;function Gu(e){return Ku(e)}function Ku(e,t){const i=zs();i.__VUE__=!0;const{insert:n,remove:s,patchProp:o,createElement:a,createText:r,createComment:l,setText:c,setElementText:u,parentNode:d,nextSibling:h,setScopeId:p=Xt,insertStaticContent:b}=e,m=(L,j,v,U=null,W=null,_=null,T=void 0,P=null,Y=!!j.dynamicChildren)=>{if(L===j)return;L&&!Sn(L,j)&&(U=Ie(L),q(L,W,_,!0),L=null),j.patchFlag===-2&&(Y=!1,j.dynamicChildren=null);const{type:B,ref:z,shapeFlag:Z}=j;switch(B){case Gs:y(L,j,v,U);break;case gi:g(L,j,v,U);break;case fs:L==null&&w(j,v,U,T);break;case Xe:$(L,j,v,U,W,_,T,P,Y);break;default:Z&1?M(L,j,v,U,W,_,T,P,Y):Z&6?V(L,j,v,U,W,_,T,P,Y):(Z&64||Z&128)&&B.process(L,j,v,U,W,_,T,P,Y,X)}z!=null&&W?Bn(z,L&&L.ref,_,j||L,!j):z==null&&L&&L.ref!=null&&Bn(L.ref,null,_,L,!0)},y=(L,j,v,U)=>{if(L==null)n(j.el=r(j.children),v,U);else{const W=j.el=L.el;j.children!==L.children&&c(W,j.children)}},g=(L,j,v,U)=>{L==null?n(j.el=l(j.children||""),v,U):j.el=L.el},w=(L,j,v,U)=>{[L.el,L.anchor]=b(L.children,j,v,U,L.el,L.anchor)},S=({el:L,anchor:j},v,U)=>{let W;for(;L&&L!==j;)W=h(L),n(L,v,U),L=W;n(j,v,U)},x=({el:L,anchor:j})=>{let v;for(;L&&L!==j;)v=h(L),s(L),L=v;s(j)},M=(L,j,v,U,W,_,T,P,Y)=>{if(j.type==="svg"?T="svg":j.type==="math"&&(T="mathml"),L==null)E(j,v,U,W,_,T,P,Y);else{const B=L.el&&L.el._isVueCE?L.el:null;try{B&&B._beginPatch(),R(L,j,W,_,T,P,Y)}finally{B&&B._endPatch()}}},E=(L,j,v,U,W,_,T,P)=>{let Y,B;const{props:z,shapeFlag:Z,transition:ie,dirs:oe}=L;if(Y=L.el=a(L.type,_,z&&z.is,z),Z&8?u(Y,L.children):Z&16&&D(L.children,Y,null,U,W,ro(L,_),T,P),oe&&Bi(L,null,U,"created"),C(Y,L,L.scopeId,T,U),z){for(const $e in z)$e!=="value"&&!Tn($e)&&o(Y,$e,null,z[$e],_,U);"value"in z&&o(Y,"value",null,z.value,_),(B=z.onVnodeBeforeMount)&&jt(B,U,L)}oe&&Bi(L,null,U,"beforeMount");const me=qu(W,ie);me&&ie.beforeEnter(Y),n(Y,j,v),((B=z&&z.onVnodeMounted)||me||oe)&&Ct(()=>{try{B&&jt(B,U,L),me&&ie.enter(Y),oe&&Bi(L,null,U,"mounted")}finally{}},W)},C=(L,j,v,U,W)=>{if(v&&p(L,v),U)for(let _=0;_<U.length;_++)p(L,U[_]);if(W){let _=W.subTree;if(j===_||_l(_.type)&&(_.ssContent===j||_.ssFallback===j)){const T=W.vnode;C(L,T,T.scopeId,T.slotScopeIds,W.parent)}}},D=(L,j,v,U,W,_,T,P,Y=0)=>{for(let B=Y;B<L.length;B++){const z=L[B]=P?oi(L[B]):Gt(L[B]);m(null,z,j,v,U,W,_,T,P)}},R=(L,j,v,U,W,_,T)=>{const P=j.el=L.el;let{patchFlag:Y,dynamicChildren:B,dirs:z}=j;Y|=L.patchFlag&16;const Z=L.props||Je,ie=j.props||Je;let oe;if(v&&Di(v,!1),(oe=ie.onVnodeBeforeUpdate)&&jt(oe,v,j,L),z&&Bi(j,L,v,"beforeUpdate"),v&&Di(v,!0),B&&(!L.dynamicChildren||L.dynamicChildren.length!==B.length)&&(Y=0,T=!1,B=null),(Z.innerHTML&&ie.innerHTML==null||Z.textContent&&ie.textContent==null)&&u(P,""),B?N(L.dynamicChildren,B,P,v,U,ro(j,W),_):T||A(L,j,P,null,v,U,ro(j,W),_,!1),Y>0){if(Y&16)K(P,Z,ie,v,W);else if(Y&2&&Z.class!==ie.class&&o(P,"class",null,ie.class,W),Y&4&&o(P,"style",Z.style,ie.style,W),Y&8){const me=j.dynamicProps;for(let $e=0;$e<me.length;$e++){const xe=me[$e],De=Z[xe],Ne=ie[xe];(Ne!==De||xe==="value")&&o(P,xe,De,Ne,W,v)}}Y&1&&L.children!==j.children&&u(P,j.children)}else!T&&B==null&&K(P,Z,ie,v,W);((oe=ie.onVnodeUpdated)||z)&&Ct(()=>{oe&&jt(oe,v,j,L),z&&Bi(j,L,v,"updated")},U)},N=(L,j,v,U,W,_,T)=>{for(let P=0;P<j.length;P++){const Y=L[P],B=j[P],z=Y.el&&(Y.type===Xe||!Sn(Y,B)||Y.shapeFlag&198)?d(Y.el):v;m(Y,B,z,null,U,W,_,T,!0)}},K=(L,j,v,U,W)=>{if(j!==v){if(j!==Je)for(const _ in j)!Tn(_)&&!(_ in v)&&o(L,_,j[_],null,W,U);for(const _ in v){if(Tn(_))continue;const T=v[_],P=j[_];T!==P&&_!=="value"&&o(L,_,P,T,W,U)}"value"in v&&o(L,"value",j.value,v.value,W)}},$=(L,j,v,U,W,_,T,P,Y)=>{const B=j.el=L?L.el:r(""),z=j.anchor=L?L.anchor:r("");let{patchFlag:Z,dynamicChildren:ie,slotScopeIds:oe}=j;oe&&(P=P?P.concat(oe):oe),L==null?(n(B,v,U),n(z,v,U),D(j.children||[],v,z,W,_,T,P,Y)):Z>0&&Z&64&&ie&&L.dynamicChildren&&L.dynamicChildren.length===ie.length?(N(L.dynamicChildren,ie,v,W,_,T,P),(j.key!=null||W&&j===W.subTree)&&xl(L,j,!0)):A(L,j,v,z,W,_,T,P,Y)},V=(L,j,v,U,W,_,T,P,Y)=>{j.slotScopeIds=P,L==null?j.shapeFlag&512?W.ctx.activate(j,v,U,T,Y):k(j,v,U,W,_,T,Y):F(L,j,Y)},k=(L,j,v,U,W,_,T)=>{const P=L.component=nf(L,U,W);if(rl(L)&&(P.ctx.renderer=X),of(P,!1,T),P.asyncDep){if(W&&W.registerDep(P,H,T),!L.el){const Y=P.subTree=ae(gi);g(null,Y,j,v),L.placeholder=Y.el}}else H(P,L,j,v,W,_,T)},F=(L,j,v)=>{const U=j.component=L.component;if(Nu(L,j,v))if(U.asyncDep&&!U.asyncResolved){I(U,j,v);return}else U.next=j,U.update();else j.el=L.el,U.vnode=j},H=(L,j,v,U,W,_,T)=>{const P=()=>{if(L.isMounted){let{next:Z,bu:ie,u:oe,parent:me,vnode:$e}=L;{const le=Sl(L);if(le){Z&&(Z.el=$e.el,I(L,Z,T)),le.asyncDep.then(()=>{Ct(()=>{L.isUnmounted||B()},W)});return}}let xe=Z,De;Di(L,!1),Z?(Z.el=$e.el,I(L,Z,T)):Z=$e,ie&&us(ie),(De=Z.props&&Z.props.onVnodeBeforeUpdate)&&jt(De,me,Z,$e),Di(L,!0);const Ne=Or(L),Fe=L.subTree;L.subTree=Ne,m(Fe,Ne,d(Fe.el),Ie(Fe),L,W,_),Z.el=Ne.el,xe===null&&zu(L,Ne.el),oe&&Ct(oe,W),(De=Z.props&&Z.props.onVnodeUpdated)&&Ct(()=>jt(De,me,Z,$e),W)}else{let Z;const{el:ie,props:oe}=j,{bm:me,m:$e,parent:xe,root:De,type:Ne}=L,Fe=ln(j);Di(L,!1),me&&us(me),!Fe&&(Z=oe&&oe.onVnodeBeforeMount)&&jt(Z,xe,j),Di(L,!0);{De.ce&&De.ce._hasShadowRoot()&&De.ce._injectChildStyle(Ne,L.parent?L.parent.type:void 0);const le=L.subTree=Or(L);m(null,le,v,U,L,W,_),j.el=le.el}if($e&&Ct($e,W),!Fe&&(Z=oe&&oe.onVnodeMounted)){const le=j;Ct(()=>jt(Z,xe,le),W)}(j.shapeFlag&256||xe&&ln(xe.vnode)&&xe.vnode.shapeFlag&256)&&L.a&&Ct(L.a,W),L.isMounted=!0,j=v=U=null}};L.scope.on();const Y=L.effect=new Oa(P);L.scope.off();const B=L.update=Y.run.bind(Y),z=L.job=Y.runIfDirty.bind(Y);z.i=L,z.id=L.uid,Y.scheduler=()=>er(z),Di(L,!0),B()},I=(L,j,v)=>{j.component=L;const U=L.vnode.props;L.vnode=j,L.next=null,Fu(L,j.props,U,v),Vu(L,j.children,v),pi(),Mr(L),hi()},A=(L,j,v,U,W,_,T,P,Y=!1)=>{const B=L&&L.children,z=L?L.shapeFlag:0,Z=j.children,{patchFlag:ie,shapeFlag:oe}=j;if(ie>0){if(ie&128){ne(B,Z,v,U,W,_,T,P,Y);return}else if(ie&256){O(B,Z,v,U,W,_,T,P,Y);return}}oe&8?(z&16&&Se(B,W,_),Z!==B&&u(v,Z)):z&16?oe&16?ne(B,Z,v,U,W,_,T,P,Y):Se(B,W,_,!0):(z&8&&u(v,""),oe&16&&D(Z,v,U,W,_,T,P,Y))},O=(L,j,v,U,W,_,T,P,Y)=>{L=L||on,j=j||on;const B=L.length,z=j.length,Z=Math.min(B,z);let ie;for(ie=0;ie<Z;ie++){const oe=j[ie]=Y?oi(j[ie]):Gt(j[ie]);m(L[ie],oe,v,null,W,_,T,P,Y)}B>z?Se(L,W,_,!0,!1,Z):D(j,v,U,W,_,T,P,Y,Z)},ne=(L,j,v,U,W,_,T,P,Y)=>{let B=0;const z=j.length;let Z=L.length-1,ie=z-1;for(;B<=Z&&B<=ie;){const oe=L[B],me=j[B]=Y?oi(j[B]):Gt(j[B]);if(Sn(oe,me))m(oe,me,v,null,W,_,T,P,Y);else break;B++}for(;B<=Z&&B<=ie;){const oe=L[Z],me=j[ie]=Y?oi(j[ie]):Gt(j[ie]);if(Sn(oe,me))m(oe,me,v,null,W,_,T,P,Y);else break;Z--,ie--}if(B>Z){if(B<=ie){const oe=ie+1,me=oe<z?j[oe].el:U;for(;B<=ie;)m(null,j[B]=Y?oi(j[B]):Gt(j[B]),v,me,W,_,T,P,Y),B++}}else if(B>ie)for(;B<=Z;)q(L[B],W,_,!0),B++;else{const oe=B,me=B,$e=new Map;for(B=me;B<=ie;B++){const ze=j[B]=Y?oi(j[B]):Gt(j[B]);ze.key!=null&&$e.set(ze.key,B)}let xe,De=0;const Ne=ie-me+1;let Fe=!1,le=0;const ue=new Array(Ne);for(B=0;B<Ne;B++)ue[B]=0;for(B=oe;B<=Z;B++){const ze=L[B];if(De>=Ne){q(ze,W,_,!0);continue}let je;if(ze.key!=null)je=$e.get(ze.key);else for(xe=me;xe<=ie;xe++)if(ue[xe-me]===0&&Sn(ze,j[xe])){je=xe;break}je===void 0?q(ze,W,_,!0):(ue[je-me]=B+1,je>=le?le=je:Fe=!0,m(ze,j[je],v,null,W,_,T,P,Y),De++)}const Ye=Fe?Yu(ue):on;for(xe=Ye.length-1,B=Ne-1;B>=0;B--){const ze=me+B,je=j[ze],ot=j[ze+1],ii=ze+1<z?ot.el||Cl(ot):U;ue[B]===0?m(null,je,v,ii,W,_,T,P,Y):Fe&&(xe<0||B!==Ye[xe]?G(je,v,ii,2):xe--)}}},G=(L,j,v,U,W=null)=>{const{el:_,type:T,transition:P,children:Y,shapeFlag:B}=L;if(B&6){G(L.component.subTree,j,v,U);return}if(B&128){L.suspense.move(j,v,U);return}if(B&64){T.move(L,j,v,X);return}if(T===Xe){n(_,j,v);for(let Z=0;Z<Y.length;Z++)G(Y[Z],j,v,U);n(L.anchor,j,v);return}if(T===fs){S(L,j,v);return}if(U!==2&&B&1&&P)if(U===0)P.persisted&&!_[so]?n(_,j,v):(P.beforeEnter(_),n(_,j,v),Ct(()=>P.enter(_),W));else{const{leave:Z,delayLeave:ie,afterLeave:oe}=P,me=()=>{L.ctx.isUnmounted?s(_):n(_,j,v)},$e=()=>{const xe=_._isLeaving||!!_[so];_._isLeaving&&_[so](!0),P.persisted&&!xe?me():Z(_,()=>{me(),oe&&oe()})};ie?ie(_,me,$e):$e()}else n(_,j,v)},q=(L,j,v,U=!1,W=!1)=>{const{type:_,props:T,ref:P,children:Y,dynamicChildren:B,shapeFlag:z,patchFlag:Z,dirs:ie,cacheIndex:oe,memo:me}=L;if(Z===-2&&(W=!1),P!=null&&(pi(),Bn(P,null,v,L,!0),hi()),oe!=null&&(j.renderCache[oe]=void 0),z&256){j.ctx.deactivate(L);return}const $e=z&1&&ie,xe=!ln(L);let De;if(xe&&(De=T&&T.onVnodeBeforeUnmount)&&jt(De,j,L),z&6)re(L.component,v,U);else{if(z&128){L.suspense.unmount(v,U);return}$e&&Bi(L,null,j,"beforeUnmount"),z&64?L.type.remove(L,j,v,X,U):B&&!B.hasOnce&&(_!==Xe||Z>0&&Z&64)?Se(B,j,v,!1,!0):(_===Xe&&Z&384||!W&&z&16)&&Se(Y,j,v),U&&ce(L)}const Ne=me!=null&&oe==null;(xe&&(De=T&&T.onVnodeUnmounted)||$e||Ne)&&Ct(()=>{De&&jt(De,j,L),$e&&Bi(L,null,j,"unmounted"),Ne&&(L.el=null)},v)},ce=L=>{const{type:j,el:v,anchor:U,transition:W}=L;if(j===Xe){se(v,U);return}if(j===fs){x(L);return}const _=()=>{s(v),W&&!W.persisted&&W.afterLeave&&W.afterLeave()};if(L.shapeFlag&1&&W&&!W.persisted){const{leave:T,delayLeave:P}=W,Y=()=>T(v,_);P?P(L.el,_,Y):Y()}else _()},se=(L,j)=>{let v;for(;L!==j;)v=h(L),s(L),L=v;s(j)},re=(L,j,v)=>{const{bum:U,scope:W,job:_,subTree:T,um:P,m:Y,a:B}=L;zr(Y),zr(B),U&&us(U),W.stop(),_&&(_.flags|=8,q(T,L,j,v)),P&&Ct(P,j),Ct(()=>{L.isUnmounted=!0},j)},Se=(L,j,v,U=!1,W=!1,_=0)=>{for(let T=_;T<L.length;T++)q(L[T],j,v,U,W)},Ie=L=>{if(L.shapeFlag&6)return Ie(L.component.subTree);if(L.shapeFlag&128)return L.suspense.next();const j=h(L.anchor||L.el),v=j&&j[cu];return v?h(v):j};let _e=!1;const pe=(L,j,v)=>{let U;L==null?j._vnode&&(q(j._vnode,null,null,!0),U=j._vnode.component):m(j._vnode||null,L,j,null,null,null,v),j._vnode=L,_e||(_e=!0,Mr(U),Qa(),_e=!1)},X={p:m,um:q,m:G,r:ce,mt:k,mc:D,pc:A,pbc:N,n:Ie,o:e};return{render:pe,hydrate:void 0,createApp:Bu(pe)}}function ro({type:e,props:t},i){return i==="svg"&&e==="foreignObject"||i==="mathml"&&e==="annotation-xml"&&t&&t.encoding&&t.encoding.includes("html")?void 0:i}function Di({effect:e,job:t},i){i?(e.flags|=32,t.flags|=4):(e.flags&=-33,t.flags&=-5)}function qu(e,t){return(!e||e&&!e.pendingBranch)&&t&&!t.persisted}function xl(e,t,i=!1){const n=e.children,s=t.children;if(Ee(n)&&Ee(s))for(let o=0;o<n.length;o++){const a=n[o];let r=s[o];r.shapeFlag&1&&!r.dynamicChildren&&((r.patchFlag<=0||r.patchFlag===32)&&(r=s[o]=oi(s[o]),r.el=a.el),!i&&r.patchFlag!==-2&&xl(a,r)),r.type===Gs&&(r.patchFlag===-1&&(r=s[o]=oi(r)),r.el=a.el),r.type===gi&&!r.el&&(r.el=a.el)}}function Yu(e){const t=e.slice(),i=[0];let n,s,o,a,r;const l=e.length;for(n=0;n<l;n++){const c=e[n];if(c!==0){if(s=i[i.length-1],e[s]<c){t[n]=s,i.push(n);continue}for(o=0,a=i.length-1;o<a;)r=o+a>>1,e[i[r]]<c?o=r+1:a=r;c<e[i[o]]&&(o>0&&(t[n]=i[o-1]),i[o]=n)}}for(o=i.length,a=i[o-1];o-- >0;)i[o]=a,a=t[a];return i}function Sl(e){const t=e.subTree.component;if(t)return t.asyncDep&&!t.asyncResolved?t:Sl(t)}function zr(e){if(e)for(let t=0;t<e.length;t++)e[t].flags|=8}function Cl(e){if(e.placeholder)return e.placeholder;const t=e.component;return t?Cl(t.subTree):null}const _l=e=>e.__isSuspense;function Zu(e,t){t&&t.pendingBranch?Ee(e)?t.effects.push(...e):t.effects.push(e):su(e)}const Xe=Symbol.for("v-fgt"),Gs=Symbol.for("v-txt"),gi=Symbol.for("v-cmt"),fs=Symbol.for("v-stc"),di=[];let At=null;function J(e=!1){di.push(At=e?null:[])}function or(){di.pop(),At=di[di.length-1]||null}let Vn=1;function Hr(e,t=!1){Vn+=e,e<0&&At&&t&&(At.hasOnce=!0)}function $l(e){return e.dynamicChildren=Vn>0?At||on:null,or(),Vn>0&&At&&At.push(e),e}function te(e,t,i,n,s,o){return $l(f(e,t,i,n,s,o,!0))}function Zt(e,t,i,n,s){return $l(ae(e,t,i,n,s,!0))}function rr(e){return e?e.__v_isVNode===!0:!1}function Sn(e,t){return e.type===t.type&&e.key===t.key}const Il=({key:e})=>e??null,ps=({ref:e,ref_key:t,ref_for:i})=>(typeof e=="number"&&(e=""+e),e!=null?nt(e)||tt(e)||Be(e)?{i:dt,r:e,k:t,f:!!i}:e:null);function f(e,t=null,i=null,n=0,s=null,o=e===Xe?0:1,a=!1,r=!1){const l={__v_isVNode:!0,__v_skip:!0,type:e,props:t,key:t&&Il(t),ref:t&&ps(t),scopeId:tl,slotScopeIds:null,children:i,component:null,suspense:null,ssContent:null,ssFallback:null,dirs:null,transition:null,el:null,anchor:null,target:null,targetStart:null,targetAnchor:null,staticCount:0,shapeFlag:o,patchFlag:n,dynamicProps:s,dynamicChildren:null,appContext:null,ctx:dt};return r?(As(l,i),o&128&&e.normalize(l)):i&&(l.shapeFlag|=nt(i)?8:16),Vn>0&&!a&&At&&(l.patchFlag>0||o&6)&&l.patchFlag!==32&&At.push(l),l}const ae=Ju;function Ju(e,t=null,i=null,n=0,s=null,o=!1){if((!e||e===Su)&&(e=gi),rr(e)){const r=fn(e,t,!0);return i&&As(r,i),Vn>0&&!o&&At&&(r.shapeFlag&6?At[At.indexOf(e)]=r:At.push(r)),r.patchFlag=-2,r}if(df(e)&&(e=e.__vccOpts),t){t=Xu(t);let{class:r,style:l}=t;r&&!nt(r)&&(t.class=Ce(r)),qe(l)&&(Qo(l)&&!Ee(l)&&(l=ut({},l)),t.style=qt(l))}const a=nt(e)?1:_l(e)?128:du(e)?64:qe(e)?4:Be(e)?2:0;return f(e,t,i,n,s,a,o,!0)}function Xu(e){return e?Qo(e)||gl(e)?ut({},e):e:null}function fn(e,t,i=!1,n=!1){const{props:s,ref:o,patchFlag:a,children:r,transition:l}=e,c=t?Qu(s||{},t):s,u={__v_isVNode:!0,__v_skip:!0,type:e.type,props:c,key:c&&Il(c),ref:t&&t.ref?i&&o?Ee(o)?o.concat(ps(t)):[o,ps(t)]:ps(t):o,scopeId:e.scopeId,slotScopeIds:e.slotScopeIds,children:r,target:e.target,targetStart:e.targetStart,targetAnchor:e.targetAnchor,staticCount:e.staticCount,shapeFlag:e.shapeFlag,patchFlag:t&&e.type!==Xe?a===-1?16:a|16:a,dynamicProps:e.dynamicProps,dynamicChildren:e.dynamicChildren,appContext:e.appContext,dirs:e.dirs,transition:l,component:e.component,suspense:e.suspense,ssContent:e.ssContent&&fn(e.ssContent),ssFallback:e.ssFallback&&fn(e.ssFallback),placeholder:e.placeholder,el:e.el,anchor:e.anchor,ctx:e.ctx,ce:e.ce};return l&&n&&tr(u,l.clone(u)),u}function _t(e=" ",t=0){return ae(Gs,null,e,t)}function ht(e,t){const i=ae(fs,null,e);return i.staticCount=t,i}function Te(e="",t=!1){return t?(J(),Zt(gi,null,e)):ae(gi,null,e)}function Gt(e){return e==null||typeof e=="boolean"?ae(gi):Ee(e)?ae(Xe,null,e.slice()):rr(e)?oi(e):ae(Gs,null,String(e))}function oi(e){return e.el===null&&e.patchFlag!==-1||e.memo?e:fn(e)}function As(e,t){let i=0;const{shapeFlag:n}=e;if(t==null)t=null;else if(Ee(t))i=16;else if(typeof t=="object")if(n&65){const s=t.default;s&&(s._c&&(s._d=!1),As(e,s()),s._c&&(s._d=!0));return}else{i=32;const s=t._;!s&&!gl(t)?t._ctx=dt:s===3&&dt&&(dt.slots._===1?t._=1:(t._=2,e.patchFlag|=1024))}else if(Be(t)){if(n&65){As(e,{default:t});return}t={default:t,_ctx:dt},i=32}else t=String(t),n&64?(i=16,t=[_t(t)]):i=8;e.children=t,e.shapeFlag|=i}function Qu(...e){const t={};for(let i=0;i<e.length;i++){const n=e[i];for(const s in n)if(s==="class")t.class!==n.class&&(t.class=Ce([t.class,n.class]));else if(s==="style")t.style=qt([t.style,n.style]);else if(Ls(s)){const o=t[s],a=n[s];a&&o!==a&&!(Ee(o)&&o.includes(a))?t[s]=o?[].concat(o,a):a:a==null&&o==null&&!Ps(s)&&(t[s]=a)}else s!==""&&(t[s]=n[s])}return t}function jt(e,t,i,n=null){Ft(e,t,7,[i,n])}const ef=ul();let tf=0;function nf(e,t,i){const n=e.type,s=(t?t.appContext:e.appContext)||ef,o={uid:tf++,vnode:e,type:n,parent:t,appContext:s,root:null,next:null,subTree:null,effect:null,update:null,job:null,scope:new Md(!0),render:null,proxy:null,exposed:null,exposeProxy:null,withProxy:null,provides:t?t.provides:Object.create(s.provides),ids:t?t.ids:["",0,0],accessCache:null,renderCache:[],components:null,directives:null,propsOptions:bl(n,s),emitsOptions:fl(n,s),emit:null,emitted:null,propsDefaults:Je,inheritAttrs:n.inheritAttrs,ctx:Je,data:Je,props:Je,attrs:Je,slots:Je,refs:Je,setupState:Je,setupContext:null,suspense:i,suspenseId:i?i.pendingId:0,asyncDep:null,asyncResolved:!1,isMounted:!1,isUnmounted:!1,isDeactivated:!1,bc:null,c:null,bm:null,m:null,bu:null,u:null,um:null,bum:null,da:null,a:null,rtg:null,rtc:null,ec:null,sp:null};return o.ctx={_:o},o.root=t?t.root:o,o.emit=Lu.bind(null,o),e.ce&&e.ce(o),o}let bt=null;const sf=()=>bt||dt;let Bs,Ao;{const e=zs(),t=(i,n)=>{let s;return(s=e[i])||(s=e[i]=[]),s.push(n),o=>{s.length>1?s.forEach(a=>a(o)):s[0](o)}};Bs=t("__VUE_INSTANCE_SETTERS__",i=>bt=i),Ao=t("__VUE_SSR_SETTERS__",i=>Gn=i)}const Xn=e=>{const t=bt;return Bs(e),e.scope.on(),()=>{e.scope.off(),Bs(t)}},Fr=()=>{bt&&bt.scope.off(),Bs(null)};function Ml(e){return e.vnode.shapeFlag&4}let Gn=!1;function of(e,t=!1,i=!1){t&&Ao(t);const{props:n,children:s}=e.vnode,o=Ml(e);Hu(e,n,o,t),Uu(e,s,i||t);const a=o?rf(e,t):void 0;return t&&Ao(!1),a}function rf(e,t){const i=e.type;e.accessCache=Object.create(null),e.proxy=new Proxy(e.ctx,_u);const{setup:n}=i;if(n){pi();const s=e.setupContext=n.length>1?lf(e):null,o=Xn(e),a=Jn(n,e,0,[e.props,s]),r=Ta(a);if(hi(),o(),(r||e.sp)&&!ln(e)&&ol(e),r){if(a.then(Fr,Fr),t)return a.then(l=>{jr(e,l)}).catch(l=>{js(l,e,0)});e.asyncDep=a}else jr(e,a)}else Tl(e)}function jr(e,t,i){Be(t)?e.type.__ssrInlineRender?e.ssrRender=t:e.render=t:qe(t)&&(e.setupState=Za(t)),Tl(e)}function Tl(e,t,i){const n=e.type;e.render||(e.render=n.render||Xt);{const s=Xn(e);pi();try{$u(e)}finally{hi(),s()}}}const af={get(e,t){return mt(e,"get",""),e[t]}};function lf(e){const t=i=>{e.exposed=i||{}};return{attrs:new Proxy(e.attrs,af),slots:e.slots,emit:e.emit,expose:t}}function Ks(e){return e.exposed?e.exposeProxy||(e.exposeProxy=new Proxy(Za(qd(e.exposed)),{get(t,i){if(i in t)return t[i];if(i in Dn)return Dn[i](e)},has(t,i){return i in t||i in Dn}})):e.proxy}function cf(e,t=!0){return Be(e)?e.displayName||e.name:e.name||t&&e.__name}function df(e){return Be(e)&&"__vccOpts"in e}const ye=(e,t)=>Qd(e,t,Gn),uf="3.5.40";/**
* @vue/runtime-dom v3.5.40
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/let Bo;const Wr=typeof window<"u"&&window.trustedTypes;if(Wr)try{Bo=Wr.createPolicy("vue",{createHTML:e=>e})}catch{}const El=Bo?e=>Bo.createHTML(e):e=>e,ff="http://www.w3.org/2000/svg",pf="http://www.w3.org/1998/Math/MathML",si=typeof document<"u"?document:null,Ur=si&&si.createElement("template"),hf={insert:(e,t,i)=>{t.insertBefore(e,i||null)},remove:e=>{const t=e.parentNode;t&&t.removeChild(e)},createElement:(e,t,i,n)=>{const s=t==="svg"?si.createElementNS(ff,e):t==="mathml"?si.createElementNS(pf,e):i?si.createElement(e,{is:i}):si.createElement(e);return e==="select"&&n&&n.multiple!=null&&s.setAttribute("multiple",n.multiple),s},createText:e=>si.createTextNode(e),createComment:e=>si.createComment(e),setText:(e,t)=>{e.nodeValue=t},setElementText:(e,t)=>{e.textContent=t},parentNode:e=>e.parentNode,nextSibling:e=>e.nextSibling,querySelector:e=>si.querySelector(e),setScopeId(e,t){e.setAttribute(t,"")},insertStaticContent(e,t,i,n,s,o){const a=i?i.previousSibling:t.lastChild;if(s&&(s===o||s.nextSibling))for(;t.insertBefore(s.cloneNode(!0),i),!(s===o||!(s=s.nextSibling)););else{Ur.innerHTML=El(n==="svg"?`<svg>${e}</svg>`:n==="mathml"?`<math>${e}</math>`:e);const r=Ur.content;if(n==="svg"||n==="mathml"){const l=r.firstChild;for(;l.firstChild;)r.appendChild(l.firstChild);r.removeChild(l)}t.insertBefore(r,i)}return[a?a.nextSibling:t.firstChild,i?i.previousSibling:t.lastChild]}},mf=Symbol("_vtc");function gf(e,t,i){const n=e[mf];n&&(t=(t?[t,...n]:[...n]).join(" ")),t==null?e.removeAttribute("class"):i?e.setAttribute("class",t):e.className=t}const Ds=Symbol("_vod"),Al=Symbol("_vsh"),Do={name:"show",beforeMount(e,{value:t},{transition:i}){e[Ds]=e.style.display==="none"?"":e.style.display,i&&t?i.beforeEnter(e):Cn(e,t)},mounted(e,{value:t},{transition:i}){i&&t&&i.enter(e)},updated(e,{value:t,oldValue:i},{transition:n}){!t!=!i&&(n?t?(n.beforeEnter(e),Cn(e,!0),n.enter(e)):n.leave(e,()=>{Cn(e,!1)}):Cn(e,t))},beforeUnmount(e,{value:t}){Cn(e,t)}};function Cn(e,t){e.style.display=t?e[Ds]:"none",e[Al]=!t}const vf=Symbol(""),bf=/(?:^|;)\s*display\s*:/;function yf(e,t,i){const n=e.style,s=nt(i);let o=!1;if(i&&!s){if(t)if(nt(t))for(const a of t.split(";")){const r=a.slice(0,a.indexOf(":")).trim();i[r]==null&&$n(n,r,"")}else for(const a in t)i[a]==null&&$n(n,a,"");for(const a in i){a==="display"&&(o=!0);const r=i[a];r!=null?wf(e,a,!nt(t)&&t?t[a]:void 0,r)||$n(n,a,r):$n(n,a,"")}}else if(s){if(t!==i){const a=n[vf];a&&(i+=";"+a),n.cssText=i,o=bf.test(i)}}else t&&e.removeAttribute("style");Ds in e&&(e[Ds]=o?n.display:"",e[Al]&&(n.display="none"))}const Vr=/\s*!important$/;function $n(e,t,i){if(Ee(i))i.forEach(n=>$n(e,t,n));else if(i==null&&(i=""),t.startsWith("--"))e.setProperty(t,i);else{const n=kf(e,t);Vr.test(i)?e.setProperty(Ei(n),i.replace(Vr,""),"important"):e[n]=i}}const Gr=["Webkit","Moz","ms"],ao={};function kf(e,t){const i=ao[t];if(i)return i;let n=St(t);if(n!=="filter"&&n in e)return ao[t]=n;n=Rs(n);for(let s=0;s<Gr.length;s++){const o=Gr[s]+n;if(o in e)return ao[t]=o}return t}function wf(e,t,i,n){return e.tagName==="TEXTAREA"&&(t==="width"||t==="height")&&nt(n)&&i===n}const Kr="http://www.w3.org/1999/xlink";function qr(e,t,i,n,s,o=$d(t)){n&&t.startsWith("xlink:")?i==null?e.removeAttributeNS(Kr,t.slice(6,t.length)):e.setAttributeNS(Kr,t,i):i==null||o&&!Da(i)?e.removeAttribute(t):e.setAttribute(t,o?"":zt(i)?String(i):i)}function Yr(e,t,i,n,s){if(t==="innerHTML"||t==="textContent"){i!=null&&(e[t]=t==="innerHTML"?El(i):i);return}const o=e.tagName;if(t==="value"&&o!=="PROGRESS"&&!o.includes("-")){const r=o==="OPTION"?e.getAttribute("value")||"":e.value,l=i==null?e.type==="checkbox"?"on":"":String(i);(r!==l||!("_value"in e))&&(e.value=l),i==null&&e.removeAttribute(t),e._value=i;return}let a=!1;if(i===""||i==null){const r=typeof e[t];r==="boolean"?i=Da(i):i==null&&r==="string"?(i="",a=!0):r==="number"&&(i=0,a=!0)}try{e[t]=i}catch{}a&&e.removeAttribute(s||t)}function Si(e,t,i,n){e.addEventListener(t,i,n)}function xf(e,t,i,n){e.removeEventListener(t,i,n)}const Zr=Symbol("_vei");function Sf(e,t,i,n,s=null){const o=e[Zr]||(e[Zr]={}),a=o[t];if(n&&a)a.value=n;else{const[r,l]=$f(t);if(n){const c=o[t]=Tf(n,s);Si(e,r,c,l)}else a&&(xf(e,r,a,l),o[t]=void 0)}}const Cf=/(Once|Passive|Capture)$/,_f=/^on:?(?:Once|Passive|Capture)$/;function $f(e){let t,i;for(;(i=e.match(Cf))&&!_f.test(e);)t||(t={}),e=e.slice(0,e.length-i[1].length),t[i[1].toLowerCase()]=!0;return[e[2]===":"?e.slice(3):Ei(e.slice(2)),t]}let lo=0;const If=Promise.resolve(),Mf=()=>lo||(If.then(()=>lo=0),lo=Date.now());function Tf(e,t){const i=n=>{if(!n._vts)n._vts=Date.now();else if(n._vts<=i.attached)return;const s=i.value;if(Ee(s)){const o=n.stopImmediatePropagation;n.stopImmediatePropagation=()=>{o.call(n),n._stopped=!0};const a=s.slice(),r=[n];for(let l=0;l<a.length&&!n._stopped;l++){const c=a[l];c&&Ft(c,t,5,r)}}else Ft(s,t,5,[n])};return i.value=e,i.attached=Mf(),i}const Jr=e=>e.charCodeAt(0)===111&&e.charCodeAt(1)===110&&e.charCodeAt(2)>96&&e.charCodeAt(2)<123,Ef=(e,t,i,n,s,o)=>{const a=s==="svg";t==="class"?gf(e,n,a):t==="style"?yf(e,i,n):Ls(t)?Ps(t)||Sf(e,t,i,n,o):(t[0]==="."?(t=t.slice(1),!0):t[0]==="^"?(t=t.slice(1),!1):Af(e,t,n,a))?(Yr(e,t,n),!e.tagName.includes("-")&&(t==="value"||t==="checked"||t==="selected")&&qr(e,t,n,a,o,t!=="value")):e._isVueCE&&(Bf(e,t)||e._def.__asyncLoader&&(/[A-Z]/.test(t)||!nt(n)))?Yr(e,St(t),n,o,t):(t==="true-value"?e._trueValue=n:t==="false-value"&&(e._falseValue=n),qr(e,t,n,a))};function Af(e,t,i,n){if(n)return!!(t==="innerHTML"||t==="textContent"||t in e&&Jr(t)&&Be(i));if(t==="spellcheck"||t==="draggable"||t==="translate"||t==="autocorrect"||t==="sandbox"&&e.tagName==="IFRAME"||t==="form"||t==="list"&&e.tagName==="INPUT"||t==="type"&&e.tagName==="TEXTAREA")return!1;if(t==="width"||t==="height"){const s=e.tagName;if(s==="IMG"||s==="VIDEO"||s==="CANVAS"||s==="SOURCE")return!1}return Jr(t)&&nt(i)?!1:t in e}function Bf(e,t){const i=e._def.props;if(!i)return!1;const n=St(t);return Array.isArray(i)?i.some(s=>St(s)===n):Object.keys(i).some(s=>St(s)===n)}const pn=e=>{const t=e.props["onUpdate:modelValue"]||!1;return Ee(t)?i=>us(t,i):t};function Df(e){e.target.composing=!0}function Xr(e){const t=e.target;t.composing&&(t.composing=!1,t.dispatchEvent(new Event("input")))}const ui=Symbol("_assign");function Qr(e,t,i){return t&&(e=e.trim()),i&&(e=Ns(e)),e}const Lo={created(e,{modifiers:{lazy:t,trim:i,number:n}},s){e[ui]=pn(s);const o=n||s.props&&s.props.type==="number";Si(e,t?"change":"input",a=>{a.target.composing||e[ui](Qr(e.value,i,o))}),(i||o)&&Si(e,"change",()=>{e.value=Qr(e.value,i,o)}),t||(Si(e,"compositionstart",Df),Si(e,"compositionend",Xr),Si(e,"change",Xr))},mounted(e,{value:t}){e.value=t??""},beforeUpdate(e,{value:t,oldValue:i,modifiers:{lazy:n,trim:s,number:o}},a){if(e[ui]=pn(a),e.composing)return;const r=(o||e.type==="number")&&!/^0\d/.test(e.value)?Ns(e.value):e.value,l=t??"";if(r===l)return;const c=e.getRootNode();(c instanceof Document||c instanceof ShadowRoot)&&c.activeElement===e&&e.type!=="range"&&(n&&t===i||s&&e.value.trim()===l)||(e.value=l)}},as={deep:!0,created(e,t,i){e[ui]=pn(i),Si(e,"change",()=>{const n=e._modelValue,s=Kn(e),o=e.checked,a=e[ui];if(Ee(n)){const r=Go(n,s),l=r!==-1;if(o&&!l)a(n.concat(s));else if(!o&&l){const c=[...n];c.splice(r,1),a(c)}}else if(mn(n)){const r=new Set(n);o?r.add(s):r.delete(s),a(r)}else a(Bl(e,o))})},mounted:ea,beforeUpdate(e,t,i){e[ui]=pn(i),ea(e,t,i)}};function ea(e,{value:t,oldValue:i},n){e._modelValue=t;let s;if(Ee(t))s=Go(t,n.props.value)>-1;else if(mn(t))s=t.has(n.props.value);else{if(t===i)return;s=gn(t,Bl(e,!0))}e.checked!==s&&(e.checked=s)}const Lf={deep:!0,created(e,{value:t,modifiers:{number:i}},n){e._modelValue=t,Si(e,"change",()=>{const s=Array.prototype.filter.call(e.options,o=>o.selected).map(o=>i?Ns(Kn(o)):Kn(o));e[ui](e.multiple?mn(e._modelValue)?new Set(s):s:s[0]),e._assigning=!0,Is(()=>{e._assigning=!1})}),e[ui]=pn(n)},mounted(e,{value:t}){ta(e,t)},beforeUpdate(e,{value:t},i){e._modelValue=t,e[ui]=pn(i)},updated(e,{value:t}){e._assigning||ta(e,t)}};function ta(e,t){const i=e.multiple,n=Ee(t);if(!(i&&!n&&!mn(t))){for(let s=0,o=e.options.length;s<o;s++){const a=e.options[s],r=Kn(a);if(i)if(n){const l=typeof r;l==="string"||l==="number"?a.selected=t.some(c=>String(c)===String(r)):a.selected=Go(t,r)>-1}else a.selected=t.has(r);else if(gn(Kn(a),t)){e.selectedIndex!==s&&(e.selectedIndex=s);return}}!i&&e.selectedIndex!==-1&&(e.selectedIndex=-1)}}function Kn(e){return"_value"in e?e._value:e.value}function Bl(e,t){const i=t?"_trueValue":"_falseValue";return i in e?e[i]:t}const Pf=["ctrl","shift","alt","meta"],Of={stop:e=>e.stopPropagation(),prevent:e=>e.preventDefault(),self:e=>e.target!==e.currentTarget,ctrl:e=>!e.ctrlKey,shift:e=>!e.shiftKey,alt:e=>!e.altKey,meta:e=>!e.metaKey,left:e=>"button"in e&&e.button!==0,middle:e=>"button"in e&&e.button!==1,right:e=>"button"in e&&e.button!==2,exact:(e,t)=>Pf.some(i=>e[`${i}Key`]&&!t.includes(i))},Yt=(e,t)=>{if(!e)return e;const i=e._withMods||(e._withMods={}),n=t.join(".");return i[n]||(i[n]=((s,...o)=>{for(let a=0;a<t.length;a++){const r=Of[t[a]];if(r&&r(s,t))return}return e(s,...o)}))},Rf={esc:"escape",space:" ",up:"arrow-up",left:"arrow-left",right:"arrow-right",down:"arrow-down",delete:"backspace"},Nf=(e,t)=>{const i=e._withKeys||(e._withKeys={}),n=t.join(".");return i[n]||(i[n]=(s=>{if(!("key"in s))return;const o=Ei(s.key);if(t.some(a=>a===o||Rf[a]===o))return e(s)}))},zf=ut({patchProp:Ef},hf);let ia;function Hf(){return ia||(ia=Gu(zf))}const ar=((...e)=>{const t=Hf().createApp(...e),{mount:i}=t;return t.mount=n=>{const s=jf(n);if(!s)return;const o=t._component;!Be(o)&&!o.render&&!o.template&&(o.template=s.innerHTML),s.nodeType===1&&(s.textContent="");const a=i(s,!1,Ff(s));return s instanceof Element&&(s.removeAttribute("v-cloak"),s.setAttribute("data-v-app","")),a},t});function Ff(e){if(e instanceof SVGElement)return"svg";if(typeof MathMLElement=="function"&&e instanceof MathMLElement)return"mathml"}function jf(e){return nt(e)?document.querySelector(e):e}const Wf="slides-config.json",Ii={enableWebServeJump:!1,webServeUrl:"http://127.0.0.1:6806",normalizeHeadingSizes:!1,showUnorderedListMarkers:!0,showOrderedListMarkers:!0},Ut=Fs({...Ii});function Uf(e){if(!e||typeof e!="object")return{...Ii};const t=e;return{enableWebServeJump:!!t.enableWebServeJump,webServeUrl:typeof t.webServeUrl=="string"&&t.webServeUrl.trim()?t.webServeUrl.trim():Ii.webServeUrl,normalizeHeadingSizes:!!t.normalizeHeadingSizes,showUnorderedListMarkers:t.showUnorderedListMarkers!==void 0?!!t.showUnorderedListMarkers:Ii.showUnorderedListMarkers,showOrderedListMarkers:t.showOrderedListMarkers!==void 0?!!t.showOrderedListMarkers:Ii.showOrderedListMarkers}}function ri(e){if(!e||typeof e!="object")return{...Ut};const t=e;return t.enableWebServeJump!==void 0&&(Ut.enableWebServeJump=!!t.enableWebServeJump),t.webServeUrl!==void 0&&(Ut.webServeUrl=String(t.webServeUrl)),t.normalizeHeadingSizes!==void 0&&(Ut.normalizeHeadingSizes=!!t.normalizeHeadingSizes),t.showUnorderedListMarkers!==void 0&&(Ut.showUnorderedListMarkers=!!t.showUnorderedListMarkers),t.showOrderedListMarkers!==void 0&&(Ut.showOrderedListMarkers=!!t.showOrderedListMarkers),{...Ut}}function qs(){return{...Ut}}function Dl(e,t,i){const n=(e||Ii.webServeUrl).trim(),s=n.startsWith("http://")||n.startsWith("https://")?n:`http://${n}`,o=(i==null?void 0:i.r)||Math.random().toString(36).slice(2,9).padEnd(7,"0");try{const a=new URL(s);let r=a.pathname.replace(/\/+$/,"");return r.endsWith("/stage/build/desktop")||(r=r?`${r}/stage/build/desktop`:"/stage/build/desktop"),a.pathname=`${r}/`,a.searchParams.set("id",t),i!=null&&i.focus&&a.searchParams.set("focus","1"),a.searchParams.set("r",o),a.toString()}catch{const a=i!=null&&i.focus?"&focus=1":"";return`${s.replace(/\/+$/,"")}/stage/build/desktop/?id=${t}${a}&r=${o}`}}const Li={theme:"default",aspectRatio:"16/9",highlighter:"shiki",defaultTransition:"slide-left",colorSchema:"auto",spacing:"normal",normalizeHeadingSizes:!1,showUnorderedListMarkers:!0,showOrderedListMarkers:!0};function Vf(e){var s,o,a,r,l,c;const t=qs();if(!e)return{...Li,normalizeHeadingSizes:t.normalizeHeadingSizes,showUnorderedListMarkers:t.showUnorderedListMarkers,showOrderedListMarkers:t.showOrderedListMarkers};const i=e[xr]!==void 0?e[xr]!=="false":t.showUnorderedListMarkers,n=e[Sr]!==void 0?e[Sr]!=="false":t.showOrderedListMarkers;return{theme:((s=e[Nn])==null?void 0:s.trim())||Li.theme,aspectRatio:((o=e[zn])==null?void 0:o.trim())||Li.aspectRatio,highlighter:((a=e[Sa])==null?void 0:a.trim())||Li.highlighter,defaultTransition:((r=e[Hn])==null?void 0:r.trim())||Li.defaultTransition,colorSchema:((l=e[Ca])==null?void 0:l.trim())||Li.colorSchema,spacing:((c=e[wo])==null?void 0:c.trim())||Li.spacing,normalizeHeadingSizes:t.normalizeHeadingSizes,showUnorderedListMarkers:i,showOrderedListMarkers:n}}function hn(e){var i,n,s,o,a;const t=(i=e.ial)==null?void 0:i[Ri];return!!(t&&(t==="true"||t==="page"||t==="cover"||t==="end")||e.type==="tb"||e.type==="thematic-break"||e.type==="NodeThematicBreak"||((n=e.markdown)==null?void 0:n.trim())==="---"||((s=e.markdown)==null?void 0:s.trim())==="***"||e.type==="b"&&(((o=e.markdown)==null?void 0:o.trim())==="---"||((a=e.content)==null?void 0:a.trim())==="---"))}function na(e){const t={};let i="";if(!e)return{frontmatter:t,notes:i};e[ke]&&(t.layout=e[ke].trim()),e[gt]&&(t.transition=e[gt].trim()),e[st]&&(t.background=e[st].trim()),e[Ot]&&(t.image=e[Ot].trim()),e[Qi]&&(t.class=e[Qi].trim()),e[Mn]&&(t.spacing=e[Mn].trim()),e[vt]&&(t.layoutRatio=e[vt].trim()),e[en]&&(t.mask=e[en].trim()),e[Fi]&&(t.maskRatio=e[Fi].trim()),e[tn]&&(t.maskStyle=e[tn].trim()),e[nn]&&(t.maskInitial=e[nn].trim()),e[Xs]&&(i=e[Xs].trim());for(const[n,s]of Object.entries(e))if(n.startsWith("custom-slides-")&&![ke,vt,en,Fi,tn,nn,gt,st,Ot,Qi,Mn,Xs,Ri].includes(n)){const o=n.replace(/^custom-slides-/,"");try{t[o]=JSON.parse(s)}catch{t[o]=s}}return{frontmatter:t,notes:i}}function sa(e){const t={};if(!e)return t;const i=e[Ke]??e["slides-note"];i!=null&&i!==""&&i!=="false"&&i!=="0"&&(t.isNote=!0);const n=e[Ze]??e["slides-role"],s=e[st]??e["slides-background"];(n===_a||s==="true"||s==="1")&&(t.isBackground=!0);const o=e[ke]??e["slides-layout"];o===Ss||o===Cs?t.imageLayout=o:(n===Ss||n===Cs)&&(t.imageLayout=n);const a=e[Re]??e["custom-slides-clicks"]??e["slides-click"]??e["slides-clicks"];if(a!=null&&(t.clicks=a.trim()),e[Jt])try{const r=JSON.parse(e[Jt]);typeof r=="object"&&r!==null?t.motion={preset:r.preset||r.type||"fade-in",...r}:t.motion={preset:String(r).trim()}}catch{t.motion={preset:e[Jt].trim()}}return e[Gi]&&(t.shikiLines=e[Gi].trim()),e[Fn]&&(t.maxHeight=e[Fn].trim()),e[Me]&&(t.slot=e[Me].trim()),e.style&&e.style.trim()&&(t.style=e.style.trim()),t}function fi(e,t){const i=(e||t||"").trim();if(!i)return null;const n=i.match(/!\[[\s\S]*?\]\(\s*([^\s)]+)(?:\s+(?:=["']?[^"'\s)]*["']?|["'][^"']*["']))*?\s*\)/);if(n)return n[1].trim();const s=i.match(/<img\b[^>]*?\bsrc=["']([^"']+)["']/i);if(s)return s[1].trim();const o=i.replace(/\{:[^}]*\}/g,"").trim();return/^(?:assets\/|https?:\/\/|\/|\.\.?\/)[^\s]+\.(?:png|jpe?g|gif|webp|svg|avif)(?:\?[^\s]*)?$/i.test(o)?o:null}function Ln(e){if(!e)return"";const t=e.split(/\r?\n/);if(t.length===0)return"";const i=t[0],n=i.match(/^(\s*)(?:[-*+]|\d+\.)\s+(.*)$/);if(!n)return e;const s=n[1].length,o=n[2].trim(),a=i.length-n[2].length;if(t.length===1)return o;const r=[o];for(let l=1;l<t.length;l++){const c=t[l];if(!c.trim()){r.push("");continue}const u=c.match(/^(\s*)/),d=u?u[1].length:0;d>=a?r.push(c.slice(a)):d>s?r.push(c.slice(d)):r.push(c)}return r.join(`
`)}function Ti(e){if(!e)return!1;const t=(e.type||"").toLowerCase();if(t==="i"||t==="nodelistitem"||t==="l"||t==="nodelist")return!0;const i=(e.markdown||e.rawMarkdown||e.content||"").trim();return!!/^(?:[-*+]|\d+\.)\s+/.test(i)}function co(e,t=2){if(!e||typeof e!="string")return`repeat(${t}, 1fr)`;const i=e.trim();if(!i)return`repeat(${t}, 1fr)`;if(i.includes(":")){const s=i.split(":").map(o=>parseFloat(o.trim())).filter(o=>!isNaN(o)&&o>0);if(s.length>=2)return s.map(o=>`${o}fr`).join(" ")}const n=i.split(/\s+/).filter(Boolean);return n.length>=2?n.join(" "):`repeat(${t}, 1fr)`}function Pn(e){if(!e)return[];if(lt(e)&&Qt(e)&&!ei(e)){const n=bn(e),s=[];for(const o of n)s.push(...Pn(o));return s}const t=(e.type||"").toLowerCase();if(t==="l"||t==="nodelist"||t==="list"){if(e.children&&e.children.length>0){const a=e.children.filter(Ti);if(a.length>0)return a}const s=(e.markdown||e.content||"").trim().split(/\r?\n/),o=[];for(let a=0;a<s.length;a++)/^(?:[-*+]|\d+\.)\s+/.test(s[a])&&o.push(a);if(o.length>=2){const a=[];for(let r=0;r<o.length;r++){const l=o[r],c=r+1<o.length?o[r+1]:s.length,u=s.slice(l,c).join(`
`);a.push({id:`${e.id}-item-${r+1}`,type:"i",markdown:u,content:u,ial:{...e.ial||{}}})}return a}}return Ti(e)?[e]:[]}function lr(e){var s;if(!e||!lt(e)||!Qt(e)||ei(e))return null;const t=bn(e);if(t.length===0)return null;if(t.length===1&&lt(t[0])&&Qt(t[0])){const o=lr(t[0]);return o?{items:o.items,nestedSuperBlocks:[t[0],...o.nestedSuperBlocks]}:null}const i=[];for(const o of t)if(lt(o)){i.push(o);const a=((s=o.children)==null?void 0:s.filter(lt))||[];i.push(...a)}const n=t.map(Pn);if(n.length>=2&&n.every(o=>o.length>0)){const o=n.flat();if(o.length>=2&&o.length<=6)return{items:o,nestedSuperBlocks:i}}if(t.length===2){const o=Pn(t[0]),a=Pn(t[1]);if(o.length+a.length>=2&&o.length+a.length<=6&&(o.length>0||a.length>0))return{items:[...o,...a],nestedSuperBlocks:i}}return null}function Gf(e){if(!e||!lt(e)||!Qt(e)||ei(e))return null;const t=lr(e);if(!t)return null;const{items:i,nestedSuperBlocks:n}=t;if(i.length<2||i.length>6)return null;const s=cr(e)||void 0,o=i.length;return{superBlockNode:e,nestedSuperBlocks:n,count:o,layout:"cols-header",items:i,slots:i.map((a,r)=>`col-${r+1}`),ratio:s}}function Ll(e){if(!e||!lt(e)||!Qt(e)||ei(e))return null;const t=bn(e);if(t.length===0)return null;const i=[];for(const n of t){const s=Pn(n);if(s.length===0)return null;i.push(...s)}return i}function Kf(e){if(!e||!lt(e)||!Qt(e)||ei(e))return null;const t=Ll(e);return!t||t.length===0||t.length>=2&&t.length<=6?null:{superBlockNode:e,items:t}}function qf(e){if(!e||!lt(e)||!Qt(e)||ei(e))return null;const t=lr(e);if(t&&t.items.length===4)return t.items;const i=Ll(e);if(i&&i.length===4)return i;const n=bn(e);return n.length===4?n:null}function Yf(e,t){if(!e||e.length===0)return null;const i=[];function n(r,l){if(lt(r)){const c=qf(r);c&&c.length===4&&i.push({sbNode:r,items:c,topLevelIndex:l})}if(r.children&&r.children.length>0)for(const c of r.children)n(c,l)}for(let r=0;r<e.length;r++)n(e[r],r);if(i.length===0)return null;let s=null;t&&(s=i.find(r=>{if(r.sbNode.id===t||r.items.some(c=>c.id===t))return!0;const l=c=>c.id===t?!0:c.children?c.children.some(l):!1;return l(r.sbNode)})||null),s||(s=i[0]);const a=e.slice(0,s.topLevelIndex).slice().reverse().find(r=>Pl(r));return{superBlockNode:s.sbNode,items:s.items,headerNode:a}}function Zf(e,t,i){var u,d,h,p,b;const n=[],s=[],o=(i==null?void 0:i.tracked)||[],a=[];let r={pageTargetId:e,blocks:[]};a.push(r);for(let m=0;m<t.length;m++){const y=t[m];if(hn(y)){if(a.length===1&&r.blocks.length===0){r.pageTargetId=y.id,r.blocks.push(y);continue}r={pageTargetId:y.id,blocks:[y]},a.push(r)}else r.blocks.push(y)}function l(m){const y=[];for(const g of m)lt(g)&&y.push(g),g.children&&g.children.length>0&&y.push(...l(g.children));return y}function c(m,y,g){const w={blockId:m,attrs:y,previousAttrs:g};n.push(w),i!=null&&i.onTagChange&&i.onTagChange(w)}for(const m of a){const y=m.pageTargetId,g=t.find(E=>E.id===y),w=o.find(E=>E.pageTargetId===y);if(m.blocks.some(E=>{var C,D;return!!(ei(E)||Po(E)&&(((C=E.ial)==null?void 0:C[ke])==="image-left"||((D=E.ial)==null?void 0:D[ke])==="image-right"))})){if(w){const E=w.headerId;if(E){c(E,{[Me]:""});const C=t.find(D=>D.id===E);C!=null&&C.ial&&(C.ial[Me]="")}for(const C of w.itemIds){c(C,{[Me]:""});const D=t.find(R=>R.id===C);D!=null&&D.ial&&(D.ial[Me]="")}}continue}let x=null,M=-1;for(let E=0;E<m.blocks.length;E++){const C=m.blocks[E],D=lt(C)?[C,...l(C.children||[])]:C.children?l(C.children):[];for(const R of D){const N=Gf(R);if(N){x=N,M=E;break}}if(x)break}if(x){const{superBlockNode:E,layout:C,items:D,slots:R}=x,K=m.blocks.slice(0,M).find(I=>Pl(I)),$=K==null?void 0:K.id,V=((u=g==null?void 0:g.ial)==null?void 0:u[ke])||"",k=V==="clover",F=k?"clover":C;if(V!==F&&(c(y,{[ke]:F},{[ke]:V}),g&&(g.ial||(g.ial={}),g.ial[ke]=F)),K){const I=((d=K.ial)==null?void 0:d[Me])||"";I!=="header"&&(c(K.id,{[Me]:"header"},{[Me]:I}),K.ial||(K.ial={}),K.ial[Me]="header")}if(w!=null&&w.headerId&&w.headerId!==$){c(w.headerId,{[Me]:""});const I=t.find(A=>A.id===w.headerId);I&&(I.ial||(I.ial={}),I.ial[Me]="")}const H=[];for(let I=0;I<D.length;I++){const A=D[I],O=R[I];H.push(A.id);const ne=((h=A.ial)==null?void 0:h[Me])||"";if(ne!==O&&(c(A.id,{[Me]:O},{[Me]:ne}),A.ial||(A.ial={}),A.ial[Me]=O),A.children&&A.children.length>0)for(const G of A.children)G.ial||(G.ial={}),G.ial[Me]!==O&&(G.ial[Me]=O)}if(w!=null&&w.itemIds){for(const I of w.itemIds)if(!H.includes(I)){c(I,{[Me]:""});const A=t.find(O=>O.id===I);A&&(A.ial||(A.ial={}),A.ial[Me]="")}}s.push({superBlockId:E.id,nestedSuperBlockIds:(p=x.nestedSuperBlocks)==null?void 0:p.map(I=>I.id),pageTargetId:y,headerId:$,itemIds:H,layout:k?"clover":C})}else{let E=!1;const C=[];for(const N of m.blocks){const K=lt(N)?[N,...l(N.children||[])]:N.children?l(N.children):[];for(const $ of K){const V=Kf($);if(V){E=!0;for(const k of V.items)C.push(k.id)}}}const D=((b=g==null?void 0:g.ial)==null?void 0:b[ke])||"",R=sn(D);if(w||E&&R){c(y,{[ke]:""},{[ke]:D}),g&&(g.ial||(g.ial={}),g.ial[ke]="");const N=w==null?void 0:w.headerId;if(N){c(N,{[Me]:""});const $=t.find(V=>V.id===N);$&&($.ial||($.ial={}),$.ial[Me]="")}const K=new Set([...(w==null?void 0:w.itemIds)||[],...C]);for(const $ of K){c($,{[Me]:""});const V=t.find(k=>k.id===$);V&&(V.ial||(V.ial={}),V.ial[Me]="")}}}}return{changes:n,newTracked:s}}function lt(e){if(!e)return!1;const t=(e.type||"").toLowerCase();return t==="s"||t==="sb"||t==="nodesuperblock"}function Qt(e){if(!lt(e))return!1;const t=(e.subType||"").toLowerCase();if(t==="col"||t==="h"||t==="horizontal")return!0;if(t==="row"||t==="v"||t==="vertical")return!1;if(e.ial){const n=(e.ial["data-sb-layout"]||e.ial.layout||"").toLowerCase();if(n==="col"||n==="h")return!0;if(n==="row"||n==="v")return!1}if(e.children&&e.children.length>0){for(const n of e.children)if(n.type==="NodeSuperBlockLayoutMarker"||n.type==="layout-marker"){const s=(n.content||n.markdown||"").trim().toLowerCase();if(s==="col"||s==="h")return!0;if(s==="row"||s==="v")return!1}}const i=(e.markdown||e.content||"").trim();return/^\{\{\{col\b/i.test(i)?!0:!/^\{\{\{row\b/i.test(i)}function Po(e){return!e||Ti(e)||lt(e)||!fi(e.markdown,e.content)?!1:(e.markdown||e.content||"").replace(/!\[.*?\]\([^)]+\)/g,"").replace(/<img\b[^>]*>/gi,"").replace(/\{:[^}]*\}/g,"").trim().length<=25}function cr(e){var h;if(!e||!lt(e)||!Qt(e))return null;const t=bn(e);if(!t||t.length<2)return null;const i=[];let n=!1;for(const p of t){const b=(((h=p.ial)==null?void 0:h.style)||p.style||"").trim();let m=null;if(b){const y=b.match(/calc\(\s*([\d.]+)%/i);if(y)m=parseFloat(y[1]);else{const g=b.match(/(?:^|;|\s)width:\s*([\d.]+)%/i);g&&(m=parseFloat(g[1]))}}m!==null&&!isNaN(m)&&m>0?(i.push(m),n=!0):i.push(null)}if(!n)return null;const s=t.length,o=i.reduce((p,b)=>p+(b||0),0),a=i.filter(p=>p===null).length,r=Math.max(0,100-o),l=a>0?r/a:100/s,c=i.map(p=>p!==null?p:l),u=c.reduce((p,b)=>p+b,0);if(u<=0)return null;const d=c.map(p=>p/u*100);if(d.length===2){const[p]=d;if(p>=48&&p<=52)return"1:1";if(p>=31&&p<=35)return"1:2";if(p>=65&&p<=69)return"2:1";if(p>=28&&p<=32)return"3:7";if(p>=68&&p<=72)return"7:3";if(p>=38&&p<=42)return"4:6";if(p>=58&&p<=62)return"6:4";if(p>=23&&p<=27)return"1:3";if(p>=73&&p<=77)return"3:1";const b=Math.round(p),m=100-b;return`${b}:${m}`}if(d.length===3){const[p,b,m]=d;if(p>=31&&p<=35&&b>=31&&b<=35&&m>=31&&m<=35)return"1:1:1";if(p>=23&&p<=27&&b>=48&&b<=52&&m>=23&&m<=27)return"1:2:1";if(p>=48&&p<=52&&b>=23&&b<=27&&m>=23&&m<=27)return"2:1:1";if(p>=23&&p<=27&&b>=23&&b<=27&&m>=48&&m<=52)return"1:1:2";if(p>=18&&p<=22&&b>=58&&b<=62&&m>=18&&m<=22)return"1:3:1";const y=Math.round(p),g=Math.round(b),w=100-y-g;return`${y}:${g}:${w}`}return d.map(p=>Math.round(p)).join(":")}function ei(e){if(!e||!lt(e)||!Qt(e))return null;const t=(e.children||[]).filter(o=>{const a=o.type||"";if(a==="NodeSuperBlockOpenMarker"||a==="NodeSuperBlockLayoutMarker"||a==="NodeSuperBlockCloseMarker"||a==="open-marker"||a==="layout-marker"||a==="close-marker")return!1;const r=(o.markdown||o.content||"").trim();return!(/^\{\{\{(?:col|row)?\s*$/i.test(r)||r==="}}}")});if(t.length<2)return null;const i=Po(t[0]),n=Po(t[t.length-1]),s=cr(e)||void 0;if(i&&!n){const o=fi(t[0].markdown,t[0].content);if(o)return{imageNode:t[0],imageUrl:o,layout:Ss,contentNodes:t.slice(1),ratio:s}}if(!i&&n){const o=fi(t[t.length-1].markdown,t[t.length-1].content);if(o)return{imageNode:t[t.length-1],imageUrl:o,layout:Cs,contentNodes:t.slice(0,t.length-1),ratio:s}}return null}function Jf(e,t){const i=[];function n(s){for(const o of s){const a=ei(o);if(a){const{imageNode:r,layout:l,ratio:c}=a;r.ial||(r.ial={});const u=r.ial[ke];if(u!==l){const h={blockId:r.id,layout:l,previousLayout:u,ratio:c};r.ial[ke]=l,i.push(h),t&&t(h)}}o.children&&o.children.length>0&&n(o.children)}}return n(e),i}function bn(e){return(e.children||[]).filter(t=>{const i=t.type||"";if(i==="NodeSuperBlockOpenMarker"||i==="NodeSuperBlockLayoutMarker"||i==="NodeSuperBlockCloseMarker"||i==="open-marker"||i==="layout-marker"||i==="close-marker")return!1;const n=(t.markdown||t.content||"").trim();return!(/^\{\{\{(?:col|row)?\s*$/i.test(n)||n==="}}}")})}function Pl(e){if(!e)return!1;const t=(e.type||"").toLowerCase();if(t==="h"||t==="nodeheading"||/^h[1-6]$/i.test(e.subType||""))return!0;const i=(e.markdown||e.content||"").trim();return!!/^#{1,6}\s+/.test(i)}function Pi(e,t,i){let n="",s=0;const o=/<div\b([^>]*)>/gi;for(;s<e.length;){o.lastIndex=s;let a,r=!1,l=-1,c=0;for(;(a=o.exec(e))!==null;){const g=a[1].match(/\bclass=["']([^"']*)["']/i);if(g){const w=g[1];if(typeof t=="string"?w.split(/\s+/).includes(t):t.test(w)){r=!0,l=a.index,c=a[0].length;break}}}if(!r){n+=e.slice(s);break}n+=e.slice(s,l);const u=l+c;let d=1,h=-1,p=-1;const b=/<\/?div\b[^>]*>/gi;b.lastIndex=u;let m;for(;(m=b.exec(e))!==null;)if(m[0].startsWith("</")){if(d--,d===0){h=m.index,p=m.index+m[0].length;break}}else d++;if(h!==-1&&p!==-1){const y=e.slice(u,h);n+=i(y),s=p}else n+=e.slice(l,u),s=u}return n}function Xf(e){const t=[];let i="",n=0;const s=/<div\b([^>]*)>/gi;for(;n<e.length;){s.lastIndex=n;let o,a=!1,r=-1,l=0;for(;(o=s.exec(e))!==null;){const m=o[1];if(/(?:\s@[a-zA-Z0-9_-]+=\s*["']|\s:[a-zA-Z0-9_-]+=\s*["']|\sv-[a-zA-Z0-9_.-]+|\shover:[a-zA-Z0-9_.-]+=\s*["']|\sgrid=["']~|\bclass=["'][^"']*\b(?:abs-br|slidev-icon-btn|grid\s+|grid$|grid-cols-|relative\b)\b[^"']*["']|\bstyle=["'][^"']*\bgrid-[^"']*["'])/i.test(m)){a=!0,r=o.index,l=o[0].length;break}}if(!a){i+=e.slice(n);break}i+=e.slice(n,r);const c=r+l;let u=1,d=-1,h=-1;const p=/<\/?div\b[^>]*>/gi;p.lastIndex=c;let b;for(;(b=p.exec(e))!==null;)if(b[0].startsWith("</")){if(u--,u===0){d=b.index,h=b.index+b[0].length;break}}else u++;if(d!==-1&&h!==-1){const m=e.slice(r,h),y=`__VUE_DIV_TOKEN_${t.length}__`;t.push(m),i+=y,n=h}else i+=e.slice(r,c),n=c}return{text:i,tokens:t}}function Qf(e){const t=[];let i=e.replace(/(?:^[ \t]*(`{3,}|~{3,})[^\n\r]*\r?\n[\s\S]*?\r?\n[ \t]*\1(?=[ \t]*(?:\r?\n|$)))/gm,r=>{const l=`__CODE_TOKEN_${t.length}__`;return t.push(r),l});i=i.replace(/(`+)(?:[^\n\r`]|(?!\1)`)+?\1/g,r=>{const l=`__CODE_TOKEN_${t.length}__`;return t.push(r),l});const n=[];i=i.replace(/<script\b[^>]*>[\s\S]*?<\/script>/gi,r=>{const l=`__SCRIPT_TOKEN_${n.length}__`;return n.push(r),l});const{text:s,tokens:o}=Xf(i);i=s;const a=[];i=i.replace(/<(?:[A-Z][a-zA-Z0-9_-]*|[a-z0-9_-]+:[a-z0-9_-]+|v-[a-z0-9_-]+|arrow\b|div\s+h-\d+)\b[^>]*\/>/gi,r=>{const l=`__VUE_COMP_TOKEN_${a.length}__`;return a.push(r),l}),i=i.replace(/<(v-[a-z0-9_-]+|button)\b([^>]*)>([\s\S]*?)<\/\1>/gi,r=>{const l=`__VUE_COMP_TOKEN_${a.length}__`;return a.push(r),l}),i=i.replace(/<img\b[^>]*?\bv-[a-z0-9_.-]+[^>]*\/?>/gi,r=>{const l=`__VUE_COMP_TOKEN_${a.length}__`;return a.push(r),l}),i=i.replace(/<(p|span)\b([^>]*?\bv-[a-z0-9_.-]+[^>]*)>([\s\S]*?)<\/\1>/gi,r=>{const l=`__VUE_COMP_TOKEN_${a.length}__`;return a.push(r),l}),i=i.replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi,""),i=i.replace(/<div class="terminal-bar">[\s\S]*?<\/div>/gi,""),i=i.replace(/<div class="cursor-line">[\s\S]*?<\/div>/gi,""),i=i.replace(/<span class="cursor">[\s\S]*?<\/span>/gi,""),i=i.replace(/<div class="stamp">\s*([\s\S]*?)\s*<\/div>/gi,`

*[$1]*

`),i=i.replace(/<div class="arrow">\s*([→\->]+)\s*<\/div>/gi,`

$1

`),i=i.replace(/<i>\s*[→\->]+\s*<\/i>/gi,""),i=i.replace(/<div class="prompt">\s*([\s\S]*?)\s*<\/div>/gi,(r,l)=>`
\`\`\`bash
${l.trim()}
\`\`\`
`),i=i.replace(/<p>\s*<i>\$<\/i>\s*([\s\S]*?)<\/p>/gi,(r,l)=>`
\`\`\`bash
$ ${l.trim()}
\`\`\`
`),i=i.replace(/<div class="statusline">\s*([\s\S]*?)\s*<\/div>/gi,(r,l)=>`
> ${Array.from(l.matchAll(/<span>([\s\S]*?)<\/span>/gi)).map(u=>`\`${u[1].trim()}\``).join(" | ")}
`),i=i.replace(/<div class="log-panel">\s*<pre>([\s\S]*?)<\/pre>\s*<\/div>/gi,(r,l)=>`
\`\`\`log
${l.replace(/<span[^>]*>([\s\S]*?)<\/span>/gi,"$1").trim()}
\`\`\`
`),i=Pi(i,"diff-grid",r=>{const l=Array.from(r.matchAll(/<div class="diff\s+([^"]*)">\s*<span>(.*?)<\/span>\s*<pre>([\s\S]*?)<\/pre>\s*<\/div>/gi));return l.length>0?`
`+l.map(c=>{const u=c[2].trim().toUpperCase(),d=c[3].trim();return`**${u}:**
\`\`\`yaml
${d}
\`\`\``}).join(`

`)+`
`:r}),i=Pi(i,"before-after",r=>{const l=r.match(/<div class="before">[\s\S]*?<small>(.*?)<\/small>[\s\S]*?<h2>(.*?)<\/h2>[\s\S]*?<p>(.*?)<\/p>\s*<\/div>/i),c=r.match(/<div class="after">[\s\S]*?<small>(.*?)<\/small>[\s\S]*?<h2>(.*?)<\/h2>[\s\S]*?<p>(.*?)<\/p>\s*<\/div>/i);let u=`
`;return l&&(u+=`### ${l[1]}
## ${l[2]}
${l[3]}

`),c&&(u+=`### ${c[1]}
## ${c[2]}
${c[3]}
`),u.trim()?u:r}),i=i.replace(/<ul\b[^>]*>([\s\S]*?)<\/ul>/gi,(r,l)=>{const c=Array.from(l.matchAll(/<li>\s*(?:<em>)?(\[[x ]\])(?:<\/em>)?\s*([\s\S]*?)<\/li>/gi));return c.length>0?`
`+c.map(u=>`- ${u[1]} ${u[2].trim()}`).join(`
`)+`
`:l}),i=Pi(i,"timeline",r=>{const l=Array.from(r.matchAll(/<div(?:\s+class="([^"]*)")?>\s*<time>([\s\S]*?)<\/time>\s*<b>([\s\S]*?)<\/b>\s*<span>([\s\S]*?)<\/span>\s*<\/div>/gi));return l.length>0?`

`+l.map(c=>{const u=c[1]||"";let d="-";return u.includes("warn")?d="- ⚠️":u.includes("bad")?d="- ❌":u.includes("ok")&&(d="- ✅"),`${d} **${c[2].trim()}** **${c[3].trim()}** — ${c[4].trim()}`}).join(`
`)+`

`:r}),i=Pi(i,"pipeline",r=>{const l=Array.from(r.matchAll(/<div(?:\s+class="([^"]*)")?>\s*<small>([\s\S]*?)<\/small>\s*<b>([\s\S]*?)<\/b>\s*<span>([\s\S]*?)<\/span>\s*<\/div>/gi));return l.length>0?`

`+l.map((c,u)=>{const h=(c[1]||"").includes("hot")?"⚠️ ":"";return`${u+1}. ${h}**${c[3].trim()}** (*${c[4].trim()}*)`}).join(`
`)+`

`:r}),i=Pi(i,"check-grid",r=>{const l=Array.from(r.matchAll(/<div>\s*<span class="([^"]*)"><\/span>\s*<b>([\s\S]*?)<\/b>\s*<p>([\s\S]*?)<\/p>\s*<\/div>/gi));return l.length>0?`

`+l.map(c=>`- ${(c[1]||"").includes("warn")?"⚠️":"✅"} **${c[2].trim()}**: ${c[3].trim()}`).join(`
`)+`

`:r}),i=Pi(i,"manifesto",r=>{const l=Array.from(r.matchAll(/<div>\s*<span>([\s\S]*?)<\/span>\s*<h2>([\s\S]*?)<\/h2>\s*<p>([\s\S]*?)<\/p>\s*<\/div>/gi));return l.length>0?`

`+l.map(c=>`## ${c[1].trim()} ${c[2].trim()}

${c[3].trim()}`).join(`

`)+`

`:r}),i=Pi(i,"split-note",r=>{const l=Array.from(r.matchAll(/<div>\s*<b>([\s\S]*?)<\/b>\s*<p>([\s\S]*?)<\/p>\s*<\/div>/gi));return l.length>0?`

`+l.map(c=>`> **${c[1].trim()}**: ${c[2].trim()}`).join(`
>
`)+`

`:r}),i=i.replace(/<div class="mechanism">\s*<b>([\s\S]*?)<\/b>\s*<p>([\s\S]*?)<\/p>\s*<\/div>/gi,(r,l,c)=>`

> **${l.trim()}**: ${c.trim()}

`),i=i.replace(/<pre>([\s\S]*?)<\/pre>/gi,(r,l)=>`
\`\`\`text
${l.replace(/<span[^>]*>([\s\S]*?)<\/span>/gi,"$1").trim()}
\`\`\`
`),i=i.replace(/<div class="page-head">\s*<span>([\s\S]*?)<\/span>\s*<b>([\s\S]*?)<\/b>\s*<\/div>/gi,`
### $1 ($2)
`),i=i.replace(/<h1\b[^>]*>([\s\S]*?)<\/h1>/gi,`
# $1
`),i=i.replace(/<h2\b[^>]*>([\s\S]*?)<\/h2>/gi,`
## $1
`),i=i.replace(/<h3\b[^>]*>([\s\S]*?)<\/h3>/gi,`
### $1
`),i=i.replace(/<h4\b[^>]*>([\s\S]*?)<\/h4>/gi,`
#### $1
`),i=i.replace(/<p\s+class="ok">\s*●\s*([\s\S]*?)<\/p>/gi,`
✅ **$1**
`),i=i.replace(/<p\s+class="caption">\s*([\s\S]*?)<\/p>/gi,`
> *$1*
`),i=i.replace(/<p\s+class="lead">\s*([\s\S]*?)<\/p>/gi,`
*$1*
`),i=i.replace(/<p\b([^>]*)>([\s\S]*?)<\/p>/gi,(r,l,c)=>/@|v-|:|class=/i.test(l)?r:`
${c.trim()}

`),i=i.replace(/<br\s*\/?>/gi,`
`),i=i.replace(/<hr\s*\/?>/gi,`
---
`),i=i.replace(/<b\b[^>]*>([\s\S]*?)<\/b>/gi,"**$1**"),i=i.replace(/<strong\b[^>]*>([\s\S]*?)<\/strong>/gi,"**$1**"),i=i.replace(/<i\b[^>]*>([\s\S]*?)<\/i>/gi,"*$1*"),i=i.replace(/<code\b[^>]*>([\s\S]*?)<\/code>/gi,(r,l)=>{if(l.startsWith("`")&&l.endsWith("`"))return l;if(l.includes("`")){const c=(l.match(/`+/g)||[]).reduce((d,h)=>Math.max(d,h.length),0),u="`".repeat(c+1);return`${u} ${l} ${u}`}return`\`${l}\``}),i=i.replace(/<small\b[^>]*>([\s\S]*?)<\/small>/gi,"*$1*"),i=i.replace(/\*{4}/g,"** **"),i=i.replace(/<li\b[^>]*>([\s\S]*?)<\/li>/gi,`- $1
`),i=i.replace(/<ul\b[^>]*>([\s\S]*?)<\/ul>/gi,`
$1
`),i=i.replace(/<ol\b[^>]*>([\s\S]*?)<\/ol>/gi,`
$1
`),i=i.replace(/<a\b([^>]*)href=["'](.*?)["']([^>]*)>([\s\S]*?)<\/a>/gi,(r,l,c,u,d)=>{const h=d.trim();return h.includes("<")||h.includes(`
`)?r:`[${h}](${c})`}),i=i.replace(/<blockquote\b[^>]*>([\s\S]*?)<\/blockquote>/gi,(r,l)=>`
`+l.trim().split(`
`).map(c=>`> ${c.trim()}`).join(`
`)+`
`),i=i.replace(/<span\b[^>]*data-type=["']block-ref["'][^>]*data-id=["']([0-9a-zA-Z-]+)["'][^>]*>([\s\S]*?)<\/span>/gi,(r,l,c)=>{const u=c.replace(/<[^>]+>/g,"").trim();return u?`((${l} '${u}'))`:`((${l}))`}),i=i.replace(/<span\b[^>]*data-type=["']a["'][^>]*data-href=["']([^"']+)["'][^>]*>([\s\S]*?)<\/span>/gi,(r,l,c)=>`[${c.replace(/<[^>]+>/g,"").trim()}](${l})`),i=i.replace(/<\/(?:div|section|header|footer|main|article|nav|aside)\b[^>]*>/gi,`
`),i=i.replace(/<(?:div|section|header|footer|main|article|nav|aside)\b[^>]*>/gi,""),i=i.replace(/<\/?span\b[^>]*>/gi,"");for(let r=0;r<a.length;r++)i=i.replace(`__VUE_COMP_TOKEN_${r}__`,()=>a[r]);for(let r=0;r<o.length;r++)i=i.replace(`__VUE_DIV_TOKEN_${r}__`,()=>o[r]);for(let r=0;r<n.length;r++)i=i.replace(`__SCRIPT_TOKEN_${r}__`,()=>n[r]);for(let r=0;r<t.length;r++)i=i.replace(`__CODE_TOKEN_${r}__`,()=>t[r]);return i=i.replace(/\n{3,}/g,`

`).trim(),i}function Ol(e){if(!e||typeof e!="string")return"";const t=[];let i=e.replace(/`([^`]+)`/g,n=>(t.push(n),`%%INLINE_CODE_${t.length-1}%%`));return i=i.replace(/(<\/[a-zA-Z0-9_-]+>)\s*\{:[^}]*\}/g,"$1"),i=i.replace(/(\[[^\]]+\]\([^)]+\))\s*\{:\s*style=["']([^"']*)["'][^}]*\}/g,'<span style="$2">$1</span>'),i=i.replace(/(\*\*[^*]+\*\*)\s*\{:\s*style=["']([^"']*)["'][^}]*\}/g,'<span style="$2">$1</span>'),i=i.replace(/(\*[^*]+\*)\s*\{:\s*style=["']([^"']*)["'][^}]*\}/g,'<span style="$2">$1</span>'),i=i.replace(/(~~[^~]+~~)\s*\{:\s*style=["']([^"']*)["'][^}]*\}/g,'<span style="$2">$1</span>'),i=i.replace(/([\p{L}\p{N}_\-]+)\s*\{:\s*style=["']([^"']*)["'][^}]*\}/gu,'<span style="$2">$1</span>'),i=i.replace(/\{:[^}]*\}/g,""),i=i.replace(/%%INLINE_CODE_(\d+)%%/g,(n,s)=>t[parseInt(s,10)]||""),i}function ep(e){const t=Object.entries(e).filter(([n,s])=>s!=null&&s!=="");return t.length===0?"":`---
${t.map(([n,s])=>typeof s=="string"?s.includes(":")||s.includes(`
`)||s.includes("#")?`${n}: "${s.replace(/"/g,'\\"')}"`:`${n}: ${s}`:`${n}: ${JSON.stringify(s)}`).join(`
`)}
---`}function tp(e,t){if(!t||!e.startsWith("```"))return e;const i=e.indexOf(`
`);if(i===-1)return e;const n=e.slice(0,i).trim(),s=e.slice(i);return n.includes("{")?e:`${n} {${t}}${s}`}function Rl(e,t){if(t==null)return e;const i=t.trim();return i===""||i==="+1"?`<v-click>

${e}

</v-click>`:i==="hide"?`<v-click hide>

${e}

</v-click>`:`<v-click at="${i}">

${e}

</v-click>`}function ip(e){if(!e||!e.preset)return null;const t=e.preset.toLowerCase().trim();if(!t||t==="none")return null;let i={opacity:0},n={opacity:1};switch(t){case"slide-up":i={y:40,opacity:0},n={y:0,opacity:1};break;case"slide-down":i={y:-40,opacity:0},n={y:0,opacity:1};break;case"slide-left":i={x:40,opacity:0},n={x:0,opacity:1};break;case"slide-right":i={x:-40,opacity:0},n={x:0,opacity:1};break;case"zoom-in":case"pop":i={scale:.8,opacity:0},n={scale:1,opacity:1};break;case"bounce":i={y:40,opacity:0},n={y:0,opacity:1,transition:{type:"spring",damping:10,stiffness:100}};break;case"fade-in":default:i={opacity:0},n={opacity:1};break}e.initial&&typeof e.initial=="object"&&(i={...i,...e.initial}),e.enter&&typeof e.enter=="object"&&(n={...n,...e.enter});const s={...n.transition||{}};return typeof e.duration=="number"&&e.duration>0&&(s.duration=e.duration),typeof e.delay=="number"&&e.delay>0&&(s.delay=e.delay),Object.keys(s).length>0&&(n.transition=s),{initial:i,enter:n}}function ls(e,t,i,n,s){const o=t!=null&&t.trim()!=="",a=ip(i),r=s?/^\d+$/.test(s.trim())?`${s.trim()}px`:s.trim():"",l=r?`max-height:${r};overflow-y:auto`:"",c=[n==null?void 0:n.trim(),l].filter(Boolean).join(";"),u=c!==void 0&&c!=="",d=u?` style="${c.replace(/"/g,"&quot;")}" class="slide-styled-block"`:"";if(!o&&!a)return u?`<div${d}>

${e}

</div>`:e;if(o&&!a){if(u){const g=t.trim();let w="v-click";return g==="hide"?w="v-click.hide":g!==""&&g!=="+1"&&(w=`v-click="${g}"`),`<div ${w}${d}>

${e}

</div>`}return Rl(e,t)}const h=JSON.stringify(a.initial).replace(/"/g,"'"),p=JSON.stringify(a.enter).replace(/"/g,"'"),b=`v-motion :initial="${h}" :enter="${p}"`;if(!o)return`<div ${b}${d}>

${e}

</div>`;const m=t.trim();let y="v-click";return m==="hide"?y="v-click.hide":m!==""&&m!=="+1"&&(y=`v-click="${m}"`),`<div ${y} ${b}${d}>

${e}

</div>`}function dr(e){if(!e)return"";let t=e.trim();t=t.replace(/\{:[^}]*\}/g,"").trim(),t=t.replace(/^:::\s*[a-zA-Z0-9_-]*\s*\r?\n?/g,""),t=t.replace(/\r?\n?:::\s*$/g,"");let s=t.split(/\r?\n/).map(o=>o.trim().replace(/^>\s*/,"")).join(`
`).trim();return s=s.replace(/^\[!(?:NOTE|TIP|IMPORTANT|WARNING|CAUTION|[A-Za-z_-]+)\][^\r\n]*(?:\r?\n)?/i,"").trim(),s=s.replace(/^(?:💡|✏️|❗|⚠️|🚨|\s*)*(?:\*\*|__)?(?:演讲备注|演讲者提词|讲稿备注|演讲提词|备注|Notes?)(?:\*\*|__)?[:：]?\s*(?:\r?\n)?/i,"").trim(),s=s.replace(/^[-*+]\s+/,""),s=s.replace(/^\d+\.\s+/,""),s.trim()}function np(e){var n;if(e.subType&&/^h([1-6])$/i.test(e.subType))return parseInt(e.subType.slice(1),10);const i=(e.markdown||e.content||"").trim().match(/^(#{1,6})\s+/);return i?i[1].length:e.type==="h"?(n=e.ial)!=null&&n.subType&&/^h([1-6])$/i.test(e.ial.subType)?parseInt(e.ial.subType.slice(1),10):1:null}function Nl(e,t=2){const i=Math.max(2,t);if(!e||e.length===0)return Array.from({length:i},()=>[]);if(e.length===1&&e[0].children&&e[0].children.length>=2){const c=e[0].children,u=Array.from({length:i},()=>[]),d=Math.min(i,c.length),h=Math.floor(c.length/d),p=c.length%d;let b=0;for(let m=0;m<d;m++){const y=h+(m<p?1:0);u[m]=c.slice(b,b+y),b+=y}return u}if(e.length===1){const c=e[0],d=(c.slot||"").trim().match(/^col-(\d+)$/i),h=d?parseInt(d[1],10):null,p=(c.rawMarkdown||c.content||"").trim(),b=p.split(/\r?\n/),m=[];for(let w=0;w<b.length;w++)/^[ \t]*[-*+]\s+|^[ \t]*\d+\.\s+/.test(b[w])&&m.push(w);if(m.length>=i){const w=Array.from({length:i},()=>[]);let S=0;for(let x=0;x<i;x++){const M=i-x,E=m.length-S,C=Math.ceil(E/M),D=m[S],R=S+C<m.length?m[S+C]:b.length,N=b.slice(D,R).join(`
`);w[x]=[{...c,id:x===0?c.id:`${c.id}-col${x+1}`,rawMarkdown:N,content:N}],S+=C}return w}const y=p.match(/<li[\s\S]*?<\/li>/gi);if(y&&y.length>=i){const w=Array.from({length:i},()=>[]);let S=0;for(let x=0;x<i;x++){const M=i-x,E=y.length-S,C=Math.ceil(E/M),D=`<ul>
${y.slice(S,S+C).join(`
`)}
</ul>`;w[x]=[{...c,id:x===0?c.id:`${c.id}-col${x+1}`,rawMarkdown:D,content:D}],S+=C}return w}const g=p.split(/\r?\n\s*\r?\n/).filter(w=>w.trim()!=="");if(g.length>=i){const w=Array.from({length:i},()=>[]);let S=0;for(let x=0;x<i;x++){const M=i-x,E=g.length-S,C=Math.ceil(E/M),D=g.slice(S,S+C).join(`

`);w[x]=[{...c,id:x===0?c.id:`${c.id}-col${x+1}`,rawMarkdown:D,content:D}],S+=C}return w}if(h&&h>=1&&h<=i){const w=Array.from({length:i},()=>[]);return w[h-1]=[c],w}return[[c],...Array.from({length:i-1},()=>[])]}const n=c=>{const u=(c.slot||"").trim();if(!u)return null;if(u==="left")return 1;if(u==="center")return 2;if(u==="right")return i===2?2:i;const d=u.match(/^col-(\d+)$/i);if(d){const h=parseInt(d[1],10);if(h>=1&&h<=i)return h}return null},s=e.map(n);if(s.some(c=>c!==null)){if(s.some(p=>p!==null&&p>=2)){const p=Array.from({length:i},()=>[]);let b=1;for(const y of e){const g=n(y);g!==null&&(b=g),p[b-1].push(y)}if(!e.some(y=>/^col-\d+$/i.test((y.slot||"").trim()))&&p[0].length===0){const y=p.filter(g=>g.length>0);if(y.length===1)return[y[0],...Array.from({length:i-1},()=>[])]}return p}const u=e.filter(p=>n(p)===1),d=e.filter(p=>n(p)===null),h=i-1;if(d.length>=h){const p=Math.floor(d.length/h),b=d.length%h,m=[u];let y=0;for(let g=0;g<h;g++){const w=p+(g<b?1:0);m.push(d.slice(y,y+w)),y+=w}return m}else if(d.length>0){const p=[u];for(let b=0;b<h;b++)p.push(b<d.length?[d[b]]:[]);return p}else return[u,...Array.from({length:h},()=>[])]}const a=c=>{if(c.type==="h"||c.subType&&/^h[1-6]$/i.test(c.subType))return!0;const u=(c.rawMarkdown||c.content||"").trim();return/^#{1,6}\s+/.test(u)},r=e.map((c,u)=>a(c)?u:-1).filter(c=>c!==-1);if(r.length>=i){const c=Array.from({length:i},()=>[]);for(let u=0;u<i;u++){const d=r[u],h=u+1<i?r[u+1]:e.length;c[u]=e.slice(d,h)}return c}if(e.length>=i){const c=Array.from({length:i},()=>[]);let u=0;for(let d=0;d<i;d++){const h=i-d,p=e.length-u,b=Math.ceil(p/h);c[d]=e.slice(u,u+b),u+=b}return c}if(e.length>1&&e.length<i){const c=Array.from({length:i},()=>[]);for(let u=0;u<e.length;u++)c[u]=[e[u]];return c}const l=Array.from({length:i},()=>[]);return l[0]=e,l}function oa(e,t,i,n){var p;const s=Vf(t),o=[],a=na(t);let r={pageIndex:1,startBlockId:e,frontmatter:{layout:a.frontmatter.layout||"cover",...a.frontmatter},notes:"",noteBlocks:[],blocks:[],rawMarkdown:"",allBlockIds:[e]};r.frontmatter.background&&(r.frontmatter.background=Et(r.frontmatter.background,n)),r.frontmatter.image&&(r.frontmatter.image=Et(r.frontmatter.image,n));const l=b=>{const m=[];for(let y=b;y<i.length&&!(y>b&&hn(i[y]));y++)m.push(i[y]);return m},c=b=>{let m,y,g;const w=S=>{var D;if(m)return;const x=ei(S);if(x){m=x.layout,y=x.imageUrl,g=x.ratio;return}const M=wr(S),E=S.ial?{...S.ial}:{},C=sa(E);if(C.imageLayout==="image-left"||C.imageLayout==="image-right"){const R=fi(M,S.content);if(R){m=C.imageLayout,y=R,g=(D=S.ial)==null?void 0:D[vt];return}}if(S.children&&S.children.length>0){for(const R of S.children)if(w(R),m)return}};for(const S of b)if(w(S),m)break;return{foundLayout:m,foundImage:y,foundRatio:g}},u=(b,m)=>{const{foundLayout:y,foundImage:g,foundRatio:w}=c(m);y&&(b.frontmatter.layout=y,g&&(b.frontmatter.image=Et(g,n)),w&&!b.frontmatter.layoutRatio&&(b.frontmatter.layoutRatio=w))};u(r,l(0)),o.push(r);let d=[];for(let b=0;b<i.length;b++){const m=i[b];if(hn(m)){d=[];const g=na(m.ial);if(o.length===1&&r.blocks.length===0){r.startBlockId=m.id,r.allBlockIds||(r.allBlockIds=[]),r.allBlockIds.includes(m.id)||r.allBlockIds.push(m.id),g.frontmatter.layout&&(r.frontmatter.layout=g.frontmatter.layout),Object.assign(r.frontmatter,g.frontmatter),!g.frontmatter.image&&a.frontmatter.image&&(r.frontmatter.image=a.frontmatter.image),!g.frontmatter.background&&a.frontmatter.background&&(r.frontmatter.background=a.frontmatter.background),r.frontmatter.background&&(r.frontmatter.background=Et(r.frontmatter.background,n)),r.frontmatter.image&&(r.frontmatter.image=Et(r.frontmatter.image,n)),u(r,l(b+1));continue}r={pageIndex:o.length+1,startBlockId:m.id,frontmatter:{layout:g.frontmatter.layout||"default",...g.frontmatter},notes:"",noteBlocks:[],blocks:[],rawMarkdown:"",allBlockIds:[m.id]},r.frontmatter.background&&(r.frontmatter.background=Et(r.frontmatter.background,n)),r.frontmatter.image&&(r.frontmatter.image=Et(r.frontmatter.image,n)),u(r,l(b+1)),o.push(r);continue}const y=(g,w)=>{var se,re,Se,Ie,_e,pe,X;if(r.allBlockIds||(r.allBlockIds=[]),g.id&&!r.allBlockIds.includes(g.id)&&r.allBlockIds.push(g.id),g.children&&g.children.length>0){const Q=L=>{for(const j of L)j.id&&!r.allBlockIds.includes(j.id)&&r.allBlockIds.push(j.id),j.children&&j.children.length>0&&Q(j.children)};Q(g.children)}let S=wr(g),x=g.ial?{...g.ial}:{};const M=S.match(/\{:\s*([^}]+)\s*\}\s*$/);M&&(x={...wa(M[0]),...x},S=S.slice(0,M.index).trim()),g.type!=="c"&&!S.startsWith("```")&&(S=Ol(S));let E=S.trim();if(/^\{\{\{(?:row|col)?\s*$/i.test(E)||E==="}}}")return;/^\{\{\{(?:row|col)?\s*\r?\n/i.test(E)&&/\r?\n\}\}\}$/.test(E)&&(S=E.replace(/^\{\{\{(?:row|col)?\s*\r?\n/i,"").replace(/\r?\n\}\}\}$/,"").trim(),E=S.trim());const C=sa(x);if(S=gd(S,n),S=hd(S,n==null?void 0:n.refContentMap),g.children&&g.children.length>0){const Q=["custom-slides-autoplay","custom-slides-loop","custom-slides-muted","custom-slides-controls"],L=j=>{for(const v of j){if(v.ial)for(const[U,W]of Object.entries(v.ial))Q.includes(U)&&!x[U]&&(x[U]=W);v.children&&v.children.length>0&&L(v.children)}};L(g.children)}const D=g.type==="video"||g.type==="NodeVideo"||/<video\b/i.test(S);if(D){const Q=x["custom-slides-autoplay"]==="true",L=x["custom-slides-loop"]==="true",j=x["custom-slides-muted"]==="true"||Q,v=x["custom-slides-controls"]==="false";S=S.replace(/<video\b([^>]*)>/gi,(U,W)=>{let _=W;return v?_=_.replace(/\bcontrols(?:="[^"]*")?/gi,"").trim():/controls/i.test(_)||(_+=" controls"),Q&&!/autoplay/i.test(_)?_+=" autoplay playsinline":!Q&&x["custom-slides-autoplay"]==="false"&&(_=_.replace(/\bautoplay\b/gi,"").replace(/\bplaysinline\b/gi,"").trim()),L&&!/loop/i.test(_)?_+=" loop":!L&&x["custom-slides-loop"]==="false"&&(_=_.replace(/\bloop\b/gi,"").trim()),j&&!/muted/i.test(_)?_+=" muted":!j&&x["custom-slides-muted"]==="false"&&(_=_.replace(/\bmuted\b/gi,"").trim()),`<video ${_.trim()}>`})}if(C.isBackground){const Q=fi(S,g.content);if(Q){r.frontmatter.background=Et(Q,n);return}}const R=ei(g);if(R){r.frontmatter.layout=R.layout,r.frontmatter.image=Et(R.imageUrl,n),!r.frontmatter.layoutRatio&&R.ratio&&(r.frontmatter.layoutRatio=R.ratio);for(const Q of R.contentNodes)y(Q);return}if(C.imageLayout==="image-left"||C.imageLayout==="image-right"){const Q=fi(S,g.content);if(Q){r.frontmatter.layout=C.imageLayout,r.frontmatter.image=Et(Q,n),!r.frontmatter.layoutRatio&&((se=g.ial)!=null&&se[vt])&&(r.frontmatter.layoutRatio=g.ial[vt]);return}}if(lt(g)&&g.children&&g.children.length>0){for(const Q of g.children)y(Q);return}const N=!!(C.slot||w!=null&&w.defaultSlot||r.frontmatter.layout==="clover"||sn(r.frontmatter.layout)||r.frontmatter.layout==="two-cols"),K=!!(g.children&&g.children.some(Q=>{var L,j;return((L=Q.ial)==null?void 0:L[Me])||((j=Q.ial)==null?void 0:j[Re])||Q.children&&Q.children.length>=2||Q.children&&Q.children.some(v=>{var U,W,_,T,P,Y;return((U=v.ial)==null?void 0:U[Re])||((W=v.ial)==null?void 0:W[Me])||((_=v.ial)==null?void 0:_[Ze])||((T=v.ial)==null?void 0:T[ke])||((P=v.ial)==null?void 0:P["custom-slides-role"])||((Y=v.ial)==null?void 0:Y["custom-slides-layout"])})}));if((g.type==="l"||g.type==="NodeList"||g.type==="list")&&g.children&&g.children.length>0&&(K||C.slot||C.clicks||N)){const Q=/^\s*\d+\.\s+/m.test(g.markdown||"")||g.subType==="o"||g.subtype==="o";for(let L=0;L<g.children.length;L++){const j=g.children[L];C.slot&&(!j.ial||!j.ial[Me])&&(j.ial||(j.ial={}),j.ial[Me]=C.slot),y(j,{...w,parentClicks:C.clicks||(w==null?void 0:w.parentClicks),defaultSlot:C.slot||(w==null?void 0:w.defaultSlot),isParentListUnpacked:!0,isListItem:!0,listContext:{isOrdered:Q,itemIndex:L+1}})}return}const $=!!(w!=null&&w.isParentListUnpacked),V=!!(g.children&&g.children.length>=2)||!!C.clicks||!!((re=g.children)!=null&&re.some(Q=>{var L;return(L=Q.ial)==null?void 0:L[Re]}))||$||!g.markdown&&!!(g.children&&g.children.length>0);if(Ti(g)&&g.children&&g.children.length>0&&(N||$||C.clicks||g.children.some(Q=>{var L;return(L=Q.ial)==null?void 0:L[Re]}))&&V){const Q=!!(g.children&&g.children.length>=2),L=g.children.find(P=>!!(P.markdown||P.content||"").trim())||g.children[0],j=((Se=L==null?void 0:L.ial)==null?void 0:Se[Re])||((Ie=L==null?void 0:L.ial)==null?void 0:Ie["custom-slides-click"]),v=!!(!C.clicks&&Q&&j),U=C.clicks||(v?j:void 0)||(w==null?void 0:w.parentClicks),W=g.id||(w==null?void 0:w.parentContainerId),_=C.slot||(w==null?void 0:w.defaultSlot);let T=!0;for(const P of g.children){_&&(!P.ial||!P.ial[Me])&&(P.ial||(P.ial={}),P.ial[Me]=_);const Y=!!(P.markdown||P.content||"").trim(),B=T&&Y;if(B){if(!(r.frontmatter.layout==="image-right"||r.frontmatter.layout==="image-left")&&!!(r.frontmatter.layout==="clover"||sn(r.frontmatter.layout)||r.frontmatter.layout==="two-cols")&&!!(w!=null&&w.defaultSlot||C.slot||(_e=g.ial)!=null&&_e[Me]))P.markdown&&(P.markdown=Ln(P.markdown)),P.content&&(P.content=Ln(P.content));else{const me=!!((pe=w==null?void 0:w.listContext)!=null&&pe.isOrdered),$e=((X=w==null?void 0:w.listContext)==null?void 0:X.itemIndex)||1,xe=me?`${$e}. `:"- ",De=Ne=>{if(!Ne)return xe.trim();const Fe=Ne.trim();return/^[-*+]\s+/.test(Fe)||/^\d+\.\s+/.test(Fe)?Ne:`${xe}${Ne}`};P.markdown&&(P.markdown=De(P.markdown)),P.content&&(P.content=De(P.content))}T=!1}let z=P;B&&U&&Q?(z={...P,ial:{...P.ial||{}}},delete z.ial[Re],delete z.ial["custom-slides-click"]):!Q&&U&&(z={...P,ial:{...P.ial||{},[Re]:U}}),y(z,{...w,parentClicks:U,parentContainerId:W,defaultSlot:_,isListItem:!0})}return}if(C.isNote){const Q=dr(S);Q&&(r.notes?r.notes+=`

`+Q:r.notes=Q),r.noteBlocks||(r.noteBlocks=[]),r.noteBlocks.push({id:g.id,type:g.type,content:Q||g.content||"",rawMarkdown:S,isNote:!0,attributes:g.ial});return}C.shikiLines&&(S=tp(S,C.shikiLines)),E=S.trim();const k=(g.content||"").trim();if(E==="::right::"||k==="::right::"||/^<p>\s*::right::\s*<\/p>$/i.test(E)||E.startsWith("::right::")){r.blocks.push({id:g.id,type:g.type,content:"::right::",rawMarkdown:"::right::",slot:"slot-divider-right",attributes:g.ial});return}const H=np(g);let I=C.slot,A=C.clicks,O=C.motion,ne={...g.ial||{}};if(H!==null){for(;d.length>0&&d[d.length-1].level>=H;)d.pop();const Q=d.length>0?d[d.length-1]:void 0;!I&&(Q!=null&&Q.slot)&&(I=Q.slot),!A&&(Q!=null&&Q.clicks)&&!(w!=null&&w.parentContainerId)&&(A=Q.clicks),!O&&(Q!=null&&Q.motion)&&(O=Q.motion);const L={...(Q==null?void 0:Q.customAttrs)||{}};if(g.ial)for(const[j,v]of Object.entries(g.ial))j.startsWith("custom-slides-")&&!j.startsWith("custom-slides-slide")&&(L[j]=v);w!=null&&w.parentContainerId||d.push({level:H,slot:I,clicks:A,motion:O,customAttrs:L})}else{const Q=d.length>0?d[d.length-1]:void 0;Q&&(!I&&Q.slot&&Q.slot!=="header"&&(I=Q.slot),!A&&Q.clicks&&!(w!=null&&w.parentContainerId)&&(A=Q.clicks),!O&&Q.motion&&(O=Q.motion),Q.customAttrs&&(ne={...Q.customAttrs,...ne}))}!I&&r.blocks.some(Q=>Q.slot==="slot-divider-right")&&(I="right"),!I&&(w!=null&&w.defaultSlot)&&(I=w.defaultSlot),I&&(ne[Me]=I),A&&!ne[Re]&&(ne[Re]=A),O&&!ne[Jt]&&(ne[Jt]=JSON.stringify(O)),(D||x["custom-slides-autoplay"]||x["custom-slides-muted"])&&(x["custom-slides-autoplay"]&&(ne["custom-slides-autoplay"]=x["custom-slides-autoplay"],x["custom-slides-autoplay"]==="true"&&!x["custom-slides-muted"]&&(ne["custom-slides-muted"]="true")),x["custom-slides-loop"]&&(ne["custom-slides-loop"]=x["custom-slides-loop"]),x["custom-slides-muted"]&&(ne["custom-slides-muted"]=x["custom-slides-muted"]),x["custom-slides-controls"]&&(ne["custom-slides-controls"]=x["custom-slides-controls"]));const G=C.maxHeight?/^\d+$/.test(C.maxHeight.trim())?`${C.maxHeight.trim()}px`:C.maxHeight.trim():void 0,q=!!(w!=null&&w.isListItem||Ti(g)),ce={id:g.id,type:g.type,content:g.content||"",rawMarkdown:S,clicks:A,parentClicks:w==null?void 0:w.parentClicks,parentContainerId:w==null?void 0:w.parentContainerId,motion:O,shikiLines:C.shikiLines,maxHeight:G,slot:I,attributes:ne,attrs:ne,rawNode:g,isListItem:q};r.blocks.push(ce)};y(m)}for(let b=0;b<o.length;b++){const m=o[b],y=[],g={...m.frontmatter};b===0&&(g.theme=s.theme,g.aspectRatio=s.aspectRatio,g.highlighter=s.highlighter,g.transition=m.frontmatter.transition||s.defaultTransition);const w=ep(g);w&&y.push(w);const S=m.blocks.filter(D=>D.slot!=="slot-divider-right"),x=D=>D.filter(R=>!!(R.rawMarkdown||R.content||"").trim()).map(R=>{var N;return ls(R.rawMarkdown,R.clicks,R.motion,(N=R.attributes)==null?void 0:N.style,R.maxHeight)}).join(`

`),M=D=>{const R=D.filter(V=>!!(V.rawMarkdown||V.content||"").trim());if(R.length===0)return;const N=R[0],K=(N.rawMarkdown||N.content||"").trim();(Ti(N)||/^(?:[-*+]|\d+\.)\s+/.test(K))&&(N.rawMarkdown=Ln(N.rawMarkdown||N.content||""),N.content=N.rawMarkdown)},E=D=>{var V,k;if(D.length===0)return"";M(D);const R=(V=D.find(F=>F.parentClicks))==null?void 0:V.parentClicks;if(!R)return D.filter(F=>!!(F.rawMarkdown||F.content||"").trim()).map(F=>{var H;return ls(F.rawMarkdown,F.clicks,F.motion,(H=F.attributes)==null?void 0:H.style,F.maxHeight)}).join(`

`);const N=[];let K=[];const $=()=>{if(K.length===0)return;const F=K.map(H=>(H.rawMarkdown||H.content||"").trim()).filter(Boolean).join(`

`);F&&N.push(Rl(F,R)),K=[]};for(const F of D){if(!(F.rawMarkdown||F.content||"").trim())continue;!!(F.clicks&&F.clicks.trim()!=="")?($(),N.push(ls(F.rawMarkdown,F.clicks,F.motion,(k=F.attributes)==null?void 0:k.style,F.maxHeight))):K.push(F)}return $(),N.join(`

`)},C=m.frontmatter.layout||"default";if(C==="clover"||sn(C)){let D=[];const R=S.filter(F=>F.slot==="header");if(R.length>0)D=R;else if(S.length>0){const F=S.find(H=>H.type==="h"&&(!H.slot||H.slot==="default"));F&&(D=[F])}const N=S.filter(F=>!D.includes(F));let K=2;if(C==="clover")K=4;else if(C==="three-cols-header")K=3;else if(C==="two-cols-header")K=2;else{let F=0;for(const H of N){const I=(H.slot||"").match(/^col-(\d+)$/i);I&&(F=Math.max(F,parseInt(I[1],10)))}if(F>=2)K=F;else if(m.frontmatter.layoutRatio){const H=m.frontmatter.layoutRatio.trim();if(H.includes(":")){const I=H.split(":").map(A=>parseFloat(A.trim())).filter(A=>!isNaN(A)&&A>0);I.length>=2&&(K=I.length)}else{const I=H.split(/\s+/).filter(Boolean);I.length>=2&&(K=I.length)}}else N.length===1&&N[0].children&&N[0].children.length>=2&&(K=Math.min(6,N[0].children.length))}const $=Nl(N,K);$.forEach((F,H)=>{const I=`col-${H+1}`;for(const A of F)(!A.slot||A.slot==="default")&&(A.slot=I);M(F)});const V=$.flat();if(N.length===1&&V.length>1){const F=m.blocks.findIndex(H=>H.id===N[0].id);F!==-1&&m.blocks.splice(F,1,...V)}const k=x(D);if(k&&y.push(k),C==="two-cols-header"&&K===2){const F=E($[0]||[]),H=E($[1]||[]);F&&y.push(`::left::

${F}`),H&&y.push(`::right::

${H}`)}else $.forEach((F,H)=>{const I=E(F);I&&y.push(`::col-${H+1}::

${I}`)})}else if(C==="two-cols"){const D=S.filter($=>$.slot==="left"),R=S.filter($=>$.slot==="right");M(D),M(R);const N=x(D.length>0?D:S.filter($=>$.slot!=="right")),K=x(R);y.push(N),K&&y.push(`::right::

${K}`)}else for(const D of S)y.push(ls(D.rawMarkdown,D.clicks||D.parentClicks,D.motion,(p=D.attributes)==null?void 0:p.style,D.maxHeight));m.notes&&y.push(`<!--
${m.notes}
-->`),m.rawMarkdown=y.join(`

`).trim()}const h=o.map(b=>b.rawMarkdown).filter(Boolean).join(`

---

`);return{docId:e,config:s,slides:o,fullMarkdown:h}}const Oo=`/* SiYuan Note Built-in Font & Background Styles for Slidev */
:root,
html:not(.dark),
[data-theme="light"],
[data-theme-mode="light"] {
  /* 思源基础卡片与主题色 (浅色模式 daylight) */
  --b3-card-error-color: #790600;
  --b3-card-error-background: #f5d1cf;
  --b3-card-warning-color: #8a4f00;
  --b3-card-warning-background: #ffe8c8;
  --b3-card-info-color: #005599;
  --b3-card-info-background: #d6eaf9;
  --b3-card-success-color: #006b04;
  --b3-card-success-background: #d7eed8;

  --b3-theme-primary: #3575f0;
  --b3-theme-secondary: #ff9200;
  --b3-theme-error: #d23f31;
  --b3-theme-background: #ffffff;
  --b3-theme-on-background: #222222;
  --b3-theme-on-surface: #5f6368;
  --b3-theme-surface-lighter: #e0e0e0;

  /* 13 种内置文字颜色 */
  --b3-font-color1: var(--b3-card-error-color);
  --b3-font-color2: var(--b3-card-warning-color);
  --b3-font-color3: var(--b3-card-info-color);
  --b3-font-color4: var(--b3-card-success-color);
  --b3-font-color5: var(--b3-theme-on-surface);
  --b3-font-color6: var(--b3-theme-primary);
  --b3-font-color7: var(--b3-theme-secondary);
  --b3-font-color8: var(--b3-theme-error);
  --b3-font-color9: #a40074;
  --b3-font-color10: #007080;
  --b3-font-color11: #006e2a;
  --b3-font-color12: #6b5a00;
  --b3-font-color13: var(--b3-theme-background);

  /* 13 种内置背景颜色 */
  --b3-font-background1: var(--b3-card-error-background);
  --b3-font-background2: var(--b3-card-warning-background);
  --b3-font-background3: var(--b3-card-info-background);
  --b3-font-background4: var(--b3-card-success-background);
  --b3-font-background5: #e2e3e4;
  --b3-font-background6: #acd0fc;
  --b3-font-background7: #fddaab;
  --b3-font-background8: #ffb0a9;
  --b3-font-background9: #fdbfff;
  --b3-font-background10: #b1ffff;
  --b3-font-background11: #affad1;
  --b3-font-background12: #fff88f;
  --b3-font-background13: var(--b3-theme-on-background);
}

html.dark,
[data-theme="dark"],
[data-theme-mode="dark"],
.theme-dark,
.dark {
  /* 思源基础卡片与主题色 (深色模式 midnight) */
  --b3-card-error-color: rgb(243, 153, 147);
  --b3-card-error-background: #442724;
  --b3-card-warning-color: rgb(255, 213, 153);
  --b3-card-warning-background: #554636;
  --b3-card-info-color: rgb(166, 213, 250);
  --b3-card-info-background: #28405c;
  --b3-card-success-color: rgb(183, 223, 185);
  --b3-card-success-background: #425347;

  --b3-theme-primary: #3575f0;
  --b3-theme-secondary: #ff9200;
  --b3-theme-error: #d23f31;
  --b3-theme-background: #1e1e1e;
  --b3-theme-on-background: #c8ccd6;
  --b3-theme-on-surface: #8b949e;
  --b3-theme-surface-lighter: #282a2e;

  /* 13 种内置文字颜色 */
  --b3-font-color1: var(--b3-card-error-color);
  --b3-font-color2: var(--b3-card-warning-color);
  --b3-font-color3: var(--b3-card-info-color);
  --b3-font-color4: var(--b3-card-success-color);
  --b3-font-color5: var(--b3-theme-on-surface);
  --b3-font-color6: var(--b3-theme-primary);
  --b3-font-color7: var(--b3-theme-secondary);
  --b3-font-color8: var(--b3-theme-error);
  --b3-font-color9: #f47c9c;
  --b3-font-color10: #4dd0e1;
  --b3-font-color11: #10df54;
  --b3-font-color12: #ecd424;
  --b3-font-color13: var(--b3-theme-background);

  /* 13 种内置背景颜色 */
  --b3-font-background1: var(--b3-card-error-background);
  --b3-font-background2: var(--b3-card-warning-background);
  --b3-font-background3: var(--b3-card-info-background);
  --b3-font-background4: var(--b3-card-success-background);
  --b3-font-background5: #3a3f42;
  --b3-font-background6: #031840;
  --b3-font-background7: #593905;
  --b3-font-background8: #3a0c09;
  --b3-font-background9: #4d1b40;
  --b3-font-background10: #1a5459;
  --b3-font-background11: #305415;
  --b3-font-background12: #4a4712;
  --b3-font-background13: var(--b3-theme-on-background);
}

@media (prefers-color-scheme: dark) {
  :root:not([data-theme="light"]):not([data-theme-mode="light"]):not(.light) {
    --b3-card-error-color: rgb(243, 153, 147);
    --b3-card-error-background: #442724;
    --b3-card-warning-color: rgb(255, 213, 153);
    --b3-card-warning-background: #554636;
    --b3-card-info-color: rgb(166, 213, 250);
    --b3-card-info-background: #28405c;
    --b3-card-success-color: rgb(183, 223, 185);
    --b3-card-success-background: #425347;

    --b3-theme-primary: #3575f0;
    --b3-theme-secondary: #ff9200;
    --b3-theme-error: #d23f31;
    --b3-theme-background: #1e1e1e;
    --b3-theme-on-background: #c8ccd6;
    --b3-theme-on-surface: #8b949e;
    --b3-theme-surface-lighter: #282a2e;

    --b3-font-color1: var(--b3-card-error-color);
    --b3-font-color2: var(--b3-card-warning-color);
    --b3-font-color3: var(--b3-card-info-color);
    --b3-font-color4: var(--b3-card-success-color);
    --b3-font-color5: var(--b3-theme-on-surface);
    --b3-font-color6: var(--b3-theme-primary);
    --b3-font-color7: var(--b3-theme-secondary);
    --b3-font-color8: var(--b3-theme-error);
    --b3-font-color9: #f47c9c;
    --b3-font-color10: #4dd0e1;
    --b3-font-color11: #10df54;
    --b3-font-color12: #ecd424;
    --b3-font-color13: var(--b3-theme-background);

    --b3-font-background1: var(--b3-card-error-background);
    --b3-font-background2: var(--b3-card-warning-background);
    --b3-font-background3: var(--b3-card-info-background);
    --b3-font-background4: var(--b3-card-success-background);
    --b3-font-background5: #3a3f42;
    --b3-font-background6: #031840;
    --b3-font-background7: #593905;
    --b3-font-background8: #3a0c09;
    --b3-font-background9: #4d1b40;
    --b3-font-background10: #1a5459;
    --b3-font-background11: #305415;
    --b3-font-background12: #4a4712;
    --b3-font-background13: var(--b3-theme-on-background);
  }
}

/* 演示块级样式排版增强 (带背景色时赋予呼吸内边距与舒适圆角) */
.slide-styled-block {
  border-radius: 6px;
  padding: 8px 14px;
  box-sizing: border-box;
  margin: 6px 0;
  transition: background-color 0.2s ease, color 0.2s ease;
}

/* 行内带背景色文本的精美圆角与微边距 */
span[style*="background-color"],
span[style*="background:"] {
  border-radius: 3px;
  padding: 1px 5px;
  box-decoration-break: clone;
  -webkit-box-decoration-break: clone;
}
`;function sp(e){var s,o,a,r,l,c,u,d,h,p,b,m;if(!e||typeof e!="object")return"";const t=[],i=[];if(Array.isArray(e.styles))for(const y of e.styles){if(!y||!y.id)continue;const g=`--b3-inline-style-${y.id}`;(s=y.light)!=null&&s.color&&t.push(`  ${g}-color: ${y.light.color};`),(o=y.light)!=null&&o.backgroundColor&&t.push(`  ${g}-background-color: ${y.light.backgroundColor};`),(a=y.dark)!=null&&a.color&&i.push(`  ${g}-color: ${y.dark.color};`),(r=y.dark)!=null&&r.backgroundColor&&i.push(`  ${g}-background-color: ${y.dark.backgroundColor};`)}if(e.builtin&&Array.isArray(e.builtin.colors))for(const y of e.builtin.colors){if(!y||typeof y.index!="number")continue;const g=y.index;(l=y.light)!=null&&l.color&&t.push(`  --b3-font-color${g}: ${y.light.color};`),(c=y.light)!=null&&c.backgroundColor&&t.push(`  --b3-font-background${g}: ${y.light.backgroundColor};`),(u=y.dark)!=null&&u.color&&i.push(`  --b3-font-color${g}: ${y.dark.color};`),(d=y.dark)!=null&&d.backgroundColor&&i.push(`  --b3-font-background${g}: ${y.dark.backgroundColor};`)}if(e.builtin&&Array.isArray(e.builtin.styles))for(const y of e.builtin.styles){if(!y||!y.id)continue;const g=y.id;(h=y.light)!=null&&h.color&&t.push(`  --b3-card-${g}-color: ${y.light.color};`),(p=y.light)!=null&&p.backgroundColor&&t.push(`  --b3-card-${g}-background: ${y.light.backgroundColor};`),(b=y.dark)!=null&&b.color&&i.push(`  --b3-card-${g}-color: ${y.dark.color};`),(m=y.dark)!=null&&m.backgroundColor&&i.push(`  --b3-card-${g}-background: ${y.dark.backgroundColor};`)}if(t.length===0&&i.length===0)return"";const n=[];return t.length>0&&n.push(`:root, html:not(.dark), [data-theme="light"] {
${t.join(`
`)}
}`),i.length>0&&n.push(`html.dark, [data-theme="dark"], .dark {
${i.join(`
`)}
}`),n.join(`

`)}function On(e){const t=sp(e);return t?`${Oo}

/* Custom Workspace Inline Styles */
${t}`:Oo}const uo=wa;function op(e){const t=String((e==null?void 0:e.type)||"").toLowerCase();return t==="s"||t==="sb"||t==="nodesuperblock"||t==="l"||t==="nodelist"||t==="i"||t==="nodelistitem"||t==="b"||t==="nodeblockquote"}function rp(e,t){const i=new Map,n=[];if(!Array.isArray(t)||t.length===0)return{usable:!1,reason:"索引无行",leafPatch:i,rebuildRoots:n};const s=new Map;for(const o of t)o!=null&&o.id&&s.set(o.id,o);for(const o of e||[]){if(!(o!=null&&o.id))continue;const a=s.get(o.id);if(!a)continue;const r=o.content??"",l=o.markdown??"";(a.content??"")===r&&(a.markdown??"")===l||(op(a)?n.push(o.id):i.set(o.id,{content:r,markdown:l}))}return{usable:!0,reason:"",leafPatch:i,rebuildRoots:n}}function ap(e){const t=String((e==null?void 0:e.type)||"").toLowerCase();return t==="h"||t==="nodeheading"}function Ro(e){return lt(e)||e.type==="l"||e.type==="NodeList"||e.type==="i"||e.type==="NodeListItem"||e.type==="b"||e.type==="NodeBlockquote"}function lp(e,t,i,n=8,s){const o=new Map;for(const h of t)h!=null&&h.id&&o.set(h.id,h);const a=h=>({id:h.id,parent_id:h.parent_id,root_id:h.root_id||e,type:h.type,subType:h.subtype??h.subType??"",content:h.content||"",markdown:h.markdown||"",ial:i(h.id,h.ial),children:[]}),r=h=>{let p=h.parent_id,b=0;for(;p&&p!==e&&b++<16;){const m=o.get(p);if(!m||!ap(m))return p;p=m.parent_id}return p||e},l=new Map;for(const h of t){if(!(h!=null&&h.id)||h.id===e||s&&s.size>0&&!s.has(h.id))continue;const p=r(h),b=l.get(p);b?b.push(h):l.set(p,[h])}if(s&&s.size>0)for(const h of l.values())h.sort((p,b)=>(s.get(p.id)??Number.MAX_SAFE_INTEGER)-(s.get(b.id)??Number.MAX_SAFE_INTEGER));const c=new Map,u=(h,p)=>{const b=a(h);if(c.set(b.id,b),p>=n||!Ro(b))return b;const m=l.get(b.id);return m&&m.length>0&&(b.children=m.map(y=>u(y,p+1))),b};return{topLevel:(l.get(e)||[]).map(h=>u(h,0)),byId:c}}const cp={getBlockAttrs:jo,getChildBlocks:Yn,getDocBlocksOrders:ud,setBlockAttrs:He,sql:dn,getBaseUrl:()=>typeof location<"u"?location.origin:"",getInlineStyles:fd};class dp{constructor(t){ve(this,"deps");ve(this,"attrOverrides",new Map);ve(this,"trackedListSuperBlocks",new Map);ve(this,"fallbackWarnedDocId","");this.deps={...cp,...t||{}}}setBlockAttrOverride(t,i){if(!t||!i)return;const s={...this.attrOverrides.get(t)||{}};for(const[o,a]of Object.entries(i))a===""||a===null||a===void 0?delete s[o]:s[o]=String(a);Object.keys(s).length===0?this.attrOverrides.delete(t):this.attrOverrides.set(t,s)}getBlockAttrOverride(t){return this.attrOverrides.get(t)}getAllAttrOverrides(){return new Map(this.attrOverrides)}getTrackedListSuperBlocks(t){return this.trackedListSuperBlocks.get(t)||[]}clearBlockAttrOverride(t,i){if(!t)return;if(!i){this.attrOverrides.delete(t);return}const n=this.attrOverrides.get(t);n&&(delete n[i],Object.keys(n).length===0&&this.attrOverrides.delete(t))}clearAllOverrides(){this.attrOverrides.clear(),this.trackedListSuperBlocks.clear()}async compile(t){try{const i=await this.deps.getBlockAttrs(t).catch(()=>({}))||{},n=this.attrOverrides.get(t);n&&Object.assign(i,n);const s=await this.deps.getChildBlocks(t).catch(()=>[])||[],o=this.deps.getDocBlocksOrders?await this.deps.getDocBlocksOrders(t).catch(()=>[])||[]:[],a=new Map;for(let H=0;H<o.length;H++)o[H]&&a.set(o[H],H);const r=a.size>0,l=`SELECT id, parent_id, root_id, type, subtype, content, markdown, ial, sort, created FROM blocks WHERE root_id = '${t}' AND id != '${t}' ORDER BY sort ASC, created ASC LIMIT 99999`,c=await this.deps.sql(l).catch(()=>[])||[],u=rp(s,c),d=new Map;if(Array.isArray(c))for(const H of c)H.id&&H.ial&&d.set(H.id,uo(H.ial));const h=`SELECT block_id, name, value FROM attributes WHERE root_id = '${t}' AND type = 'b' LIMIT 99999`,p=await this.deps.sql(h).catch(()=>[])||[];if(Array.isArray(p)){for(const H of p)if(H.block_id&&H.name){let I=d.get(H.block_id);I||(I={},d.set(H.block_id,I)),I[H.name]=H.value||""}}const b=(H,I)=>{const A={...d.get(H)||(I?uo(I):{})},O=this.attrOverrides.get(H);return O&&Object.assign(A,O),A},m=Array.isArray(c)&&c.length>0?lp(t,c,b,8,a):null,y=s.map(H=>H.id).filter(Boolean),g=H=>({id:H.id,parent_id:H.parent_id,root_id:H.root_id||t,type:H.type,subType:H.subType,content:H.content||"",markdown:H.markdown||"",ial:b(H.id,H.ial),children:H.children}),w=async(H,I=0)=>{if(!H||I>8||!Ro(H))return;const A=await this.deps.getChildBlocks(H.id).catch(()=>[])||[];if(!(!Array.isArray(A)||A.length===0)){H.children=A.filter(O=>O==null?void 0:O.id).map(O=>({id:O.id,parent_id:H.id,root_id:t,type:O.type,subType:O.subType,content:O.content||"",markdown:O.markdown||"",ial:b(O.id,O.ial),children:[]}));for(const O of H.children)await w(O,I+1)}},S=new Map;for(const H of c)H!=null&&H.id&&S.set(H.id,H);const x=y.every(H=>{const I=S.get(H);return!I||!!I.type});let M=[],E=!1;if(m&&u.usable&&r&&x){this.fallbackWarnedDocId="";for(const[I,A]of u.leafPatch){const O=m.byId.get(I);O&&(O.content=A.content,O.markdown=A.markdown)}const H=new Map;for(const I of s)I!=null&&I.id&&H.set(I.id,I);for(const I of u.rebuildRoots){const A=m.byId.get(I),O=H.get(I);A&&O&&(A.content=O.content||"",A.markdown=O.markdown||""),await w(A)}for(const I of s){if(!(I!=null&&I.id)||m.byId.has(I.id))continue;const A=g(I);await w(A),m.byId.set(A.id,A),m.topLevel.push(A)}M=m.topLevel.filter(I=>a.has(I.id)).sort((I,A)=>(a.get(I.id)??0)-(a.get(A.id)??0))}else y.length>0?(E=!0,this.fallbackWarnedDocId!==t&&(this.fallbackWarnedDocId=t,console.warn(`[DocumentCompiler] 索引结构不可用，回退逐容器查询（较慢）doc=${t} 实时顶层=${y.length} 索引行=${c.length} 文档序=${o.length} 原因=${u.reason||"缺少实时文档序"}`)),M=s.map(H=>g(H))):m&&(M=m.topLevel);const C=async(H,I=0)=>{if(!(!H||H.length===0||I>8))for(const A of H){if(Ro(A)&&(!A.children||A.children.length===0)){let ne=await this.deps.getChildBlocks(A.id).catch(()=>[]);if(!ne||ne.length===0){const G=`SELECT id, parent_id, root_id, type, subtype as subType, content, markdown, ial FROM blocks WHERE parent_id = '${A.id}' ORDER BY sort ASC, created ASC`;ne=await this.deps.sql(G).catch(()=>[])||[]}if(Array.isArray(ne)&&ne.length>0){const G=new Set(M.map(ce=>ce.id)),q=ne.filter(ce=>ce.id!==A.id&&!G.has(ce.id));q.length>0&&(A.children=q.map(ce=>{const se=d.get(ce.id)||(ce.ial?uo(ce.ial):{}),re=this.attrOverrides.get(ce.id);return re&&Object.assign(se,re),{id:ce.id,parent_id:ce.parent_id||A.id,root_id:ce.root_id||t,type:ce.type,subType:ce.subType,content:ce.content||"",markdown:ce.markdown||"",ial:se}}))}}A.children&&A.children.length>0&&await C(A.children,I+1)}};E&&await C(M);const D=H=>{var I,A;for(const O of H)if(O.children&&O.children.length>0){D(O.children);for(const ne of O.children)if(ne.ial)for(const[G,q]of Object.entries(ne.ial))G.startsWith("custom-slides-")&&!((I=O.ial)!=null&&I[G])&&(O.ial||(O.ial={}),O.ial[G]=q);if(O.ial){for(const[ne,G]of Object.entries(O.ial))if(ne.startsWith("custom-slides-"))for(const q of O.children)(q.type==="video"||q.type==="NodeVideo"||/<video\b/i.test(q.markdown||q.content||""))&&!((A=q.ial)!=null&&A[ne])&&(q.ial||(q.ial={}),q.ial[ne]=G)}}};D(M),Jf(M,H=>{const I={[ke]:H.layout};this.setBlockAttrOverride(H.blockId,I),(this.deps.setBlockAttrs||He)(H.blockId,I).catch(O=>{console.warn("[DocumentCompiler] Failed to auto-tag superblock image layout:",O)})});const R=this.trackedListSuperBlocks.get(t)||[],N=Zf(t,M,{tracked:R,onTagChange:H=>{this.setBlockAttrOverride(H.blockId,H.attrs),H.blockId===t&&Object.assign(i,H.attrs);const I=O=>{for(const ne of O)ne.id===H.blockId&&(ne.ial||(ne.ial={}),Object.assign(ne.ial,H.attrs)),ne.children&&ne.children.length>0&&I(ne.children)};I(M),(this.deps.setBlockAttrs||He)(H.blockId,H.attrs).catch(O=>{console.warn("[DocumentCompiler] Failed to auto-tag list superblock attrs:",O)})}});this.trackedListSuperBlocks.set(t,N.newTracked);const K=new Set,$=H=>{for(const I of H){const A=I.markdown||I.content||"";if(A.includes("((")){const O=pd(A);for(const ne of O)K.add(ne.blockId)}I.children&&I.children.length>0&&$(I.children)}};$(M);const V={};if(K.size>0){const H=Array.from(K).map(A=>`'${A}'`).join(","),I=await this.deps.sql(`SELECT id, content, markdown FROM blocks WHERE id IN (${H})`).catch(()=>[])||[];if(Array.isArray(I))for(const A of I)A.id&&(V[A.id]=A.markdown||A.content||"")}const k=this.deps.getBaseUrl?this.deps.getBaseUrl():"",F=oa(t,i,M,{baseUrl:k,refContentMap:V});try{const H=this.deps.getInlineStyles?await this.deps.getInlineStyles().catch(()=>null):null;F.customThemeCss=On(H)}catch{F.customThemeCss=On(null)}return F}catch(i){console.error("[DocumentCompilerService] Failed to compile document:",i);const n=oa(t,{},[],{});return n.customThemeCss=On(null),n}}}const Le=new dp;class ur{constructor(t){ve(this,"devServerUrl","http://localhost:3030");ve(this,"isConnected",!1);ve(this,"lastSyncTime",null);t&&(this.devServerUrl=t)}getUrl(){return this.devServerUrl}setUrl(t){this.devServerUrl=t.replace(/\/+$/,"")}isServerConnected(){return this.isConnected}getLastSyncTime(){return this.lastSyncTime}async probeServer(t=1500){try{const i=new AbortController,n=setTimeout(()=>i.abort(),t),s=await fetch(this.devServerUrl,{method:"HEAD",mode:"no-cors",signal:i.signal}).catch(()=>null);return clearTimeout(n),this.isConnected=!!s,this.isConnected}catch{return this.isConnected=!1,!1}}buildStandardSlidevMarkdown(t){const i=t.config,n=["---",`theme: ${i.theme||"default"}`,`aspectRatio: "${i.aspectRatio||"16/9"}"`,`highlighter: ${i.highlighter||"shiki"}`,`transition: ${i.defaultTransition||"slide-left"}`];i.colorSchema&&i.colorSchema!=="auto"&&n.push(`colorSchema: ${i.colorSchema}`),n.push("drawings:","  persist: false","---","");const s=n.join(`
`),o=t.slides.map((l,c)=>{const u=l.frontmatter||{},d=[],h=c===0;u.layout&&u.layout!=="default"&&d.push(`layout: ${u.layout}`),u.transition&&d.push(`transition: ${u.transition}`),u.background&&d.push(`background: ${u.background}`),u.class&&d.push(`class: "${u.class}"`);let p="";d.length>0?p=h?"":`---
${d.join(`
`)}
---

`:h||(p=`---

`);let b="";if(u.layout==="two-cols"){const y=l.blocks.filter(x=>x.slot!=="right"),g=l.blocks.filter(x=>x.slot==="right"),w=y.map(x=>x.rawMarkdown||x.content||"").join(`

`),S=g.map(x=>x.rawMarkdown||x.content||"").join(`

`);b=`${w}

::right::

${S}`}else b=l.blocks.map(y=>y.rawMarkdown||y.content||"").join(`

`);let m="";return l.notes&&l.notes.trim()&&(m=`

<!--
${l.notes.trim()}
-->`),`${p}${b}${m}`}).join(`

`),a=[];t.config.normalizeHeadingSizes&&a.push(`/* Specific Heading Normalization */
.slidev-layout:not(.cover) > :is(h1, h2, h3, h4, h5, h6):first-child {
  font-size: 1.7rem !important;
}
.two-cols-header-top :is(h1, h2, h3, h4, h5, h6),
.cols-header-top :is(h1, h2, h3, h4, h5, h6),
.layout-header-section :is(h1, h2, h3, h4, h5, h6) {
  font-size: 1.7rem !important;
}
:is(.two-cols-left, .two-cols-right, .col, .col-1, .col-2, .col-3, .three-cols-col) > :is(h1, h2, h3, h4, h5, h6):first-child {
  font-size: 1.3rem !important;
}`),t.config.showUnorderedListMarkers===!1&&a.push(`/* Hide Unordered List Bullets */
ul, .slidev-layout ul, .slidev-layout li:has(ul) {
  list-style: none !important;
  list-style-type: none !important;
  padding-left: 0 !important;
}`),t.config.showOrderedListMarkers===!1&&a.push(`/* Hide Ordered List Numbers */
ol, .slidev-layout ol, .slidev-layout li:has(ol) {
  list-style: none !important;
  list-style-type: none !important;
  padding-left: 0 !important;
}`);let r="";return a.length>0&&(r=`

<style>
${a.join(`

`)}
</style>`),`${s}${o}${r}
`}async syncToWorkspaceFile(t,i="/data/storage/petal/siyuan-live-slides/slides.md",n){const s=this.buildStandardSlidevMarkdown(t);if(this.lastSyncTime=Date.now(),n)try{const o=typeof Blob<"u"?new Blob([s],{type:"text/markdown;charset=utf-8"}):Buffer.from(s,"utf-8");return await n(i,!1,o),{success:!0,path:i}}catch(o){return{success:!1,path:i,error:String(o)}}return{success:!0,path:i}}downloadSlidesMd(t,i="slides.md"){if(typeof window>"u"||typeof document>"u")return!1;const n=this.buildStandardSlidevMarkdown(t),s=new Blob([n],{type:"text/markdown;charset=utf-8"}),o=URL.createObjectURL(s),a=document.createElement("a");return a.href=o,a.download=i,document.body.appendChild(a),a.click(),document.body.removeChild(a),URL.revokeObjectURL(o),!0}}const up={proMode:!1,presenterMode:!0,exportHtml:!1,exportPdf:!1,exportImage:!0,import:!1,aiScript:!0};function ai(e){return up[e]===!1}function $t(e){return!ai(e)}function fp(){if(typeof window<"u"&&typeof window.require=="function")return window.require.bind(window);if(typeof globalThis<"u"&&typeof globalThis.require=="function")return globalThis.require.bind(globalThis);if(typeof require=="function")return require}function Mt(e){const t=fp();if(t)try{return t(e)}catch{try{const i=e.startsWith("node:")?e.slice(5):`node:${e}`;return t(i)}catch{}}}function fr(){var t;if(typeof window<"u"&&window.process)return window.process;const e=Mt("process");return e&&e.versions?e:typeof process<"u"&&((t=process.versions)!=null&&t.node)?process:globalThis.process}function zl(){var t,i;const e=fr();if(e&&((t=e.versions)!=null&&t.node))return!0;if(typeof window<"u"&&window.siyuan){const n=Mt("child_process");if(n&&typeof n.spawn=="function")return!0}return!!(typeof process<"u"&&((i=process.versions)!=null&&i.node))}function pp(){if(typeof window>"u"||!window.location)return!1;try{return new URLSearchParams(window.location.search).get("remote")==="1"}catch{return!1}}function qn(){const e=fr();if(e!=null&&e.platform)return e.platform;if(typeof process<"u"&&process.platform)return process.platform;const t=Mt("os");if(t&&typeof t.platform=="function")return t.platform();if(typeof navigator<"u"){const i=navigator.userAgent.toLowerCase();if(i.includes("win"))return"win32";if(i.includes("mac"))return"darwin";if(i.includes("linux"))return"linux"}return"web"}function Hl(){var n,s;const e=fr(),t={...(e==null?void 0:e.env)||{}};if(qn()==="win32"){const o=["C:\\Program Files\\nodejs","C:\\Program Files (x86)\\nodejs",(n=e==null?void 0:e.env)!=null&&n.APPDATA?`${e.env.APPDATA}\\npm`:"",(s=e==null?void 0:e.env)!=null&&s.USERPROFILE?`${e.env.USERPROFILE}\\AppData\\Roaming\\npm`:""].filter(Boolean),a=Object.keys(t).find(c=>c.toLowerCase()==="path")||"PATH",l=(t[a]||"").split(";").filter(Boolean);for(const c of o)c&&!l.some(u=>u.toLowerCase()===c.toLowerCase())&&l.push(c);t[a]=l.join(";")}return t}function No(e){var i,n,s;if(!e)return"";if(/^[a-zA-Z]:[/\\]/.test(e))return e.replace(/\\/g,"/");let t="";if(typeof window<"u"&&((s=(n=(i=window.siyuan)==null?void 0:i.config)==null?void 0:n.system)!=null&&s.dataDir)&&(t=window.siyuan.config.system.dataDir.replace(/\\/g,"/")),t&&e.startsWith("/data/")){const o=e.slice(6);return`${t}/${o}`.replace(/\\/g,"/")}return e}function hp(){const e=Mt("os"),t=Mt("path");if(e&&typeof e.tmpdir=="function"){const i=e.tmpdir();return t&&typeof t.join=="function"?t.join(i,"siyuan-live-slides-pro").replace(/\\/g,"/"):`${i}/siyuan-live-slides-pro`.replace(/\\/g,"/")}return"/data/storage/petal/siyuan-live-slides/pro-workspace"}class pr{constructor(t){ve(this,"runner");this.runner=t||pr.defaultRunner}static async defaultRunner(t,i){var n;try{let s=(n=Mt("child_process"))==null?void 0:n.execFile;if(!s){const l=await import("node:child_process").catch(()=>({}));s=l==null?void 0:l.execFile}if(!s)return{code:-1,stdout:"",stderr:"child_process execFile not available"};const a=qn()==="win32",r=Hl();return await new Promise(l=>{s(t,i,{timeout:5e3,shell:a,env:r},(c,u,d)=>{l({code:c?c.code||1:0,stdout:u?String(u).trim():"",stderr:d?String(d).trim():""})})})}catch(s){return{code:-1,stdout:"",stderr:String(s)}}}async detect(){const t=zl(),i=qn();if(!t)return{hasNode:!1,hasSlidevCli:!1,platform:"browser",isDesktop:!1,error:"当前处于纯前端浏览器或移动端环境，无 Node.js 运行时支撑"};let n=!1,s,o=!1,a;try{const r=await this.runner("node",["-v"]);r.code===0&&r.stdout.startsWith("v")&&(n=!0,s=r.stdout)}catch{}if(n){try{const r=i==="win32"?"slidev.cmd":"slidev",l=await this.runner(r,["--version"]);l.code===0&&l.stdout&&(o=!0,a=l.stdout)}catch{}if(!o)try{const r=i==="win32"?"npx.cmd":"npx",l=await this.runner(r,["@slidev/cli","--version"]);l.code===0&&l.stdout&&(o=!0,a=l.stdout)}catch{}}return{hasNode:n,nodeVersion:s,hasSlidevCli:o,slidevVersion:a,platform:i,isDesktop:t}}}class mp{constructor(){ve(this,"iframe",null);ve(this,"isReady",!1);ve(this,"pageChangedHandlers",[]);ve(this,"readyHandlers",[]);ve(this,"currentState",{no:1,clicks:0,total:1});this.handleWindowMessage=this.handleWindowMessage.bind(this)}getCurrentState(){return{...this.currentState}}attach(t){this.detach(),this.iframe=t,this.isReady=!1,typeof window<"u"&&window.addEventListener("message",this.handleWindowMessage)}detach(){typeof window<"u"&&window.removeEventListener("message",this.handleWindowMessage),this.iframe=null,this.isReady=!1}postMessage(t,i){var s;if(!((s=this.iframe)!=null&&s.contentWindow))return;const n={target:"slidev",sender:"siyuan",type:t,...i};try{this.iframe.contentWindow.postMessage(n,"*")}catch(o){console.warn("[NativeSlidesBridge] postMessage error:",o)}}navigateToPage(t){this.postMessage("navigate",{no:t})}next(){this.postMessage("next")}prev(){this.postMessage("prev")}nextClick(){this.postMessage("next-click")}prevClick(){this.postMessage("prev-click")}onPageChanged(t){return this.pageChangedHandlers.push(t),()=>{this.pageChangedHandlers=this.pageChangedHandlers.filter(i=>i!==t)}}onReady(t){return this.readyHandlers.push(t),()=>{this.readyHandlers=this.readyHandlers.filter(i=>i!==t)}}handleWindowMessage(t){const i=t.data;if(!(!i||i.target!=="slidev")){if(!this.isReady){this.isReady=!0;for(const n of this.readyHandlers)n()}if(i.type==="update-state"&&i.navState){const n=i.navState;this.currentState={no:n.no??this.currentState.no,clicks:n.clicks??this.currentState.clicks,total:n.total??this.currentState.total,hasNext:n.hasNext,hasPrev:n.hasPrev};for(const s of this.pageChangedHandlers)s(this.currentState.no,this.currentState.total||1,this.currentState)}else if(i.type==="navigate"&&typeof i.no=="number"){this.currentState.no=i.no;for(const n of this.pageChangedHandlers)n(i.no,this.currentState.total||1,this.currentState)}}}}class gp{constructor(t){ve(this,"childProcess",null);ve(this,"activePort",null);ve(this,"isRunning",!1);ve(this,"defaultPort");ve(this,"maxPortRetries");ve(this,"probeTimeoutMs");ve(this,"customSpawner");ve(this,"customPortChecker");this.defaultPort=(t==null?void 0:t.defaultPort)||3030,this.maxPortRetries=(t==null?void 0:t.maxPortRetries)||20,this.probeTimeoutMs=(t==null?void 0:t.probeTimeoutMs)||1e4,this.customSpawner=t==null?void 0:t.customSpawner,this.customPortChecker=t==null?void 0:t.customPortChecker}getActivePort(){return this.activePort}getIsRunning(){return this.isRunning}async isPortAvailable(t){if(this.customPortChecker)return this.customPortChecker(t);try{let i=Mt("net");return i||(i=await import("node:net").catch(()=>({}))),i!=null&&i.createServer?await new Promise(n=>{const s=i.createServer();s.once("error",()=>n(!1)),s.once("listening",()=>{s.close(()=>n(!0))}),s.listen(t,"127.0.0.1")}):!0}catch{return!0}}async allocPort(t){const i=t||this.defaultPort;for(let n=0;n<this.maxPortRetries;n++){const s=i+n;if(await this.isPortAvailable(s))return s}return i}async pollServerReady(t,i=8e3,n=300){const s=Date.now();for(;Date.now()-s<i;){try{const o=new AbortController,a=setTimeout(()=>o.abort(),n),r=await fetch(t,{method:"HEAD",mode:"no-cors",signal:o.signal}).catch(()=>null);if(clearTimeout(a),r)return!0}catch{}await new Promise(o=>setTimeout(o,n))}return!1}async startServer(t,i){var l,c;if(this.isRunning&&this.activePort)return{success:!0,port:this.activePort,url:`http://localhost:${this.activePort}?embedded=true`};const n=await this.allocPort(i);this.activePort=n;const o=qn()==="win32"?"npx.cmd":"npx",a=No(t),r=["@slidev/cli",a,"--port",String(n),"--no-open"];try{if(this.customSpawner)this.childProcess=this.customSpawner(o,r,{detached:!1});else{let d=(l=Mt("child_process"))==null?void 0:l.spawn;if(!d){const b=await import("node:child_process").catch(()=>({}));d=b==null?void 0:b.spawn}if(!d)throw new Error("child_process spawn not available in current runtime");const h=a.includes("/")||a.includes("\\")?a.replace(/[/\\][^/\\]+$/,""):void 0,p=Hl();this.childProcess=d(o,r,{cwd:h,detached:!1,shell:!0,env:{...p,FORCE_COLOR:"1"}})}this.isRunning=!0,(c=this.childProcess)!=null&&c.on&&this.childProcess.on("exit",()=>{this.isRunning=!1,this.activePort=null,this.childProcess=null});const u=`http://localhost:${n}`;return!this.customSpawner&&!await this.pollServerReady(u,this.probeTimeoutMs)?(this.stopServer(),{success:!1,port:n,url:"",error:`Slidev DevServer 启动超时 (未在 ${this.probeTimeoutMs}ms 内响应端口 ${n})`}):{success:!0,port:n,url:`${u}?embedded=true`}}catch(u){return this.stopServer(),{success:!1,port:n,url:"",error:`唤起 Slidev 进程失败: ${String(u)}`}}}async stopServer(){var t;if(this.childProcess){const i=this.childProcess;this.childProcess=null;try{if(i.kill("SIGTERM"),qn()==="win32"&&i.pid&&!this.customSpawner){const s=(t=Mt("child_process"))==null?void 0:t.exec;if(s)await new Promise(o=>{const a=setTimeout(o,400);s(`taskkill /pid ${i.pid} /T /F`,()=>{clearTimeout(a),o()})});else{const o=await import("node:child_process").catch(()=>null);o!=null&&o.exec&&await new Promise(a=>{const r=setTimeout(a,400);o.exec(`taskkill /pid ${i.pid} /T /F`,()=>{clearTimeout(r),a()})})}}}catch{}}this.isRunning=!1,this.activePort=null}}class Qn{constructor(){ve(this,"iframe",null);ve(this,"isReady",!1);ve(this,"pendingMessages",[]);ve(this,"slideChangedHandlers",[]);ve(this,"blockClickedHandlers",[]);ve(this,"openInEditorHandlers",[]);ve(this,"clientReadyHandlers",[]);ve(this,"openPeekDrawerHandlers",[]);ve(this,"toggleFullscreenHandlers",[]);ve(this,"openPresenterHandlers",[]);ve(this,"captureProgressHandlers",[]);ve(this,"capturePageDoneHandlers",[]);ve(this,"captureCompleteHandlers",[]);ve(this,"captureErrorHandlers",[]);this.handleWindowMessage=this.handleWindowMessage.bind(this)}attach(t){this.detach(),this.iframe=t,this.isReady=!1,typeof window<"u"&&window.addEventListener("message",this.handleWindowMessage)}detach(){typeof window<"u"&&window.removeEventListener("message",this.handleWindowMessage),this.iframe=null,this.isReady=!1,this.pendingMessages=[]}resetReady(){this.isReady=!1}postMessage(t,i){var s;const n={source:"siyuan-slides-host",action:t,payload:i};if(!((s=this.iframe)!=null&&s.contentWindow)||!this.isReady){if(t==="UPDATE_SLIDES"||t==="NAVIGATE_PAGE"){const o=this.pendingMessages.findIndex(a=>a.action===t);o!==-1?this.pendingMessages[o]=n:this.pendingMessages.push(n)}else this.pendingMessages.length>=50&&this.pendingMessages.shift(),this.pendingMessages.push(n);return}try{this.iframe.contentWindow.postMessage(n,"*")}catch(o){console.warn("[WebSandboxBridge] postMessage error:",o)}}updateSlides(t,i,n,s){this.postMessage("UPDATE_SLIDES",{slides:t,config:i,fullMarkdown:n,customThemeCss:s})}navigatePage(t,i){const n={pageIndex:t};typeof i=="number"&&(n.step=i),this.postMessage("NAVIGATE_PAGE",n)}highlightElement(t){this.postMessage("HIGHLIGHT_ELEMENT",{targetBlockId:t})}nextStep(){this.postMessage("NEXT_STEP",{})}prevStep(){this.postMessage("PREV_STEP",{})}freezeKeyboardNav(t){this.postMessage("FREEZE_KEYBOARD_NAV",{frozen:t})}toggleOverview(){this.postMessage("TOGGLE_OVERVIEW",{})}startImageExport(t){this.postMessage("START_IMAGE_EXPORT",{captureOptions:t})}cancelImageExport(){this.postMessage("CANCEL_IMAGE_EXPORT",{})}onCaptureProgress(t){return this.captureProgressHandlers.push(t),()=>{this.captureProgressHandlers=this.captureProgressHandlers.filter(i=>i!==t)}}onCapturePageDone(t){return this.capturePageDoneHandlers.push(t),()=>{this.capturePageDoneHandlers=this.capturePageDoneHandlers.filter(i=>i!==t)}}onCaptureComplete(t){return this.captureCompleteHandlers.push(t),()=>{this.captureCompleteHandlers=this.captureCompleteHandlers.filter(i=>i!==t)}}onCaptureError(t){return this.captureErrorHandlers.push(t),()=>{this.captureErrorHandlers=this.captureErrorHandlers.filter(i=>i!==t)}}onSlideChanged(t){return this.slideChangedHandlers.push(t),()=>{this.slideChangedHandlers=this.slideChangedHandlers.filter(i=>i!==t)}}onBlockClicked(t){return this.blockClickedHandlers.push(t),()=>{this.blockClickedHandlers=this.blockClickedHandlers.filter(i=>i!==t)}}onOpenInEditor(t){return this.openInEditorHandlers.push(t),()=>{this.openInEditorHandlers=this.openInEditorHandlers.filter(i=>i!==t)}}onOpenPeekDrawer(t){return this.openPeekDrawerHandlers.push(t),()=>{this.openPeekDrawerHandlers=this.openPeekDrawerHandlers.filter(i=>i!==t)}}onRequestToggleFullscreen(t){return this.toggleFullscreenHandlers.push(t),()=>{this.toggleFullscreenHandlers=this.toggleFullscreenHandlers.filter(i=>i!==t)}}onOpenPresenter(t){return this.openPresenterHandlers.push(t),()=>{this.openPresenterHandlers=this.openPresenterHandlers.filter(i=>i!==t)}}onClientReady(t){return this.clientReadyHandlers.push(t),()=>{this.clientReadyHandlers=this.clientReadyHandlers.filter(i=>i!==t)}}handleWindowMessage(t){var n,s;const i=t.data;if(!(!i||i.source!=="siyuan-slides-client")&&!((n=this.iframe)!=null&&n.contentWindow&&t.source&&t.source!==this.iframe.contentWindow))switch(i.action){case"CLIENT_READY":for(this.isReady=!0;this.pendingMessages.length>0;){const o=this.pendingMessages.shift();o&&((s=this.iframe)!=null&&s.contentWindow)&&this.iframe.contentWindow.postMessage(o,"*")}for(const o of this.clientReadyHandlers)o();break;case"SLIDE_CHANGED":if(i.payload.currentPage!==void 0)for(const o of this.slideChangedHandlers)i.payload.currentStep!==void 0||i.payload.maxStep!==void 0?o(i.payload.currentPage,i.payload.totalPages||1,i.payload.currentBlockId||"",i.payload.currentStep,i.payload.maxStep):o(i.payload.currentPage,i.payload.totalPages||1,i.payload.currentBlockId||"");break;case"BLOCK_CLICKED":if(i.payload.clickedBlockId)for(const o of this.blockClickedHandlers)o(i.payload.clickedBlockId,i.payload.currentPage||1);break;case"OPEN_IN_EDITOR":if(i.payload.blockId||i.payload.clickedBlockId){const o=i.payload.blockId||i.payload.clickedBlockId||"";for(const a of this.openInEditorHandlers)a(o,i.payload.currentPage||1)}break;case"OPEN_PEEK_DRAWER":if(i.payload.peekType){const o=i.payload.blockId||i.payload.url||"",a={peekType:i.payload.peekType,target:o,title:i.payload.title};for(const r of this.openPeekDrawerHandlers)r(a)}break;case"REQUEST_TOGGLE_FULLSCREEN":for(const o of this.toggleFullscreenHandlers)o();break;case"OPEN_PRESENTER":for(const o of this.openPresenterHandlers)o();break;case"CAPTURE_PROGRESS":if(i.payload.captureProgress)for(const o of this.captureProgressHandlers)o(i.payload.captureProgress);break;case"CAPTURE_PAGE_DONE":if(i.payload.captureResult)for(const o of this.capturePageDoneHandlers)o(i.payload.captureResult);break;case"CAPTURE_COMPLETE":for(const o of this.captureCompleteHandlers)o({total:i.payload.totalPages||0});break;case"CAPTURE_ERROR":for(const o of this.captureErrorHandlers)o(i.payload.captureError||"未知沙箱截图异常");break}}}const Fl={"snippets/external.ts":`// Inside ./snippets/external.ts
// #region snippet
export function emptyArray<T>(length: number) {
  return Array.from<T>({ length })
}
// #endregion snippet

export function sayHello() {
  console.log('Hello from snippets/external.ts')
}
`},vp=`<script setup lang="ts">
import { computed, useSlots } from 'vue'

const props = defineProps({
  layoutRatio: {
    type: String,
    default: '',
  },
  cols: {
    type: [Number, String],
    default: 0,
  },
})

const slots = useSlots()

const detectedColsCount = computed(() => {
  const explicitCols = Number(props.cols)
  if (explicitCols >= 2 && explicitCols <= 6) return explicitCols
  const r = (props.layoutRatio || '').trim()
  if (r.includes(':')) {
    const parts = r.split(':').map(p => parseFloat(p.trim())).filter(n => !isNaN(n) && n > 0)
    if (parts.length >= 2) return Math.min(parts.length, 6)
  }
  const tokens = r.split(/\\s+/).filter(Boolean)
  if (tokens.length >= 2) return Math.min(tokens.length, 6)
  for (let i = 6; i >= 3; i--) {
    if (slots[\`col-\${i}\`]) return i
  }
  if (slots['col-2'] || slots['right']) return 2
  return 2
})

const gridStyle = computed(() => {
  const r = props.layoutRatio || ''
  if (r) {
    if (r.includes(':')) {
      const parts = r.split(':').map(p => parseFloat(p.trim())).filter(n => !isNaN(n) && n > 0)
      if (parts.length >= 2) {
        return { gridTemplateColumns: parts.map(n => \`\${n}fr\`).join(' ') }
      }
    }
    const tokens = r.split(/\\s+/).filter(Boolean)
    if (tokens.length >= 2) {
      return { gridTemplateColumns: tokens.join(' ') }
    }
  }
  return { gridTemplateColumns: \`repeat(\${detectedColsCount.value}, minmax(0, 1fr))\` }
})
<\/script>

<template>
  <div class="slidev-layout cols-header w-full h-full flex flex-col">
    <div class="header-section mb-4 w-full">
      <slot />
    </div>
    <div class="grid gap-6 flex-1 items-stretch" :style="gridStyle">
      <div v-if="detectedColsCount >= 1" class="col-1 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-1"><slot name="left" /></slot>
      </div>
      <div v-if="detectedColsCount >= 2" class="col-2 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-2"><slot v-if="detectedColsCount === 2" name="right" /></slot>
      </div>
      <div v-if="detectedColsCount >= 3" class="col-3 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-3" />
      </div>
      <div v-if="detectedColsCount >= 4" class="col-4 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-4" />
      </div>
      <div v-if="detectedColsCount >= 5" class="col-5 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-5" />
      </div>
      <div v-if="detectedColsCount >= 6" class="col-6 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-6" />
      </div>
    </div>
  </div>
</template>
`,bp=`<script setup lang="ts">
import { computed } from 'vue'

const props = defineProps({
  layoutRatio: {
    type: String,
    default: '',
  },
})

const gridStyle = computed(() => {
  const r = props.layoutRatio || ''
  if (!r) return {}
  if (r.includes(':')) {
    const parts = r.split(':').map(p => parseFloat(p.trim())).filter(n => !isNaN(n) && n > 0)
    if (parts.length >= 2) {
      return { gridTemplateColumns: parts.map(n => \`\${n}fr\`).join(' ') }
    }
  }
  const tokens = r.split(/\\s+/).filter(Boolean)
  if (tokens.length >= 2) {
    return { gridTemplateColumns: tokens.join(' ') }
  }
  return {}
})
<\/script>

<template>
  <div class="slidev-layout three-cols-header w-full h-full flex flex-col">
    <div class="header-section mb-4 w-full">
      <slot />
    </div>
    <div class="grid gap-6 flex-1 items-stretch" :class="gridStyle.gridTemplateColumns ? '' : 'grid-cols-3'" :style="gridStyle">
      <div class="col-1 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-1" />
      </div>
      <div class="col-2 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-2" />
      </div>
      <div class="col-3 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-3" />
      </div>
    </div>
  </div>
</template>
`,yp=`<script setup lang="ts">
import { computed, useSlots } from 'vue'

const props = defineProps({
  mask: {
    type: String,
    default: '',
  },
  maskStyle: {
    type: String,
    default: 'solid',
  },
  maskInitial: {
    type: String,
    default: 'hidden',
  },
  clicks: {
    type: [Number, String],
    default: 0,
  },
})

const slots = useSlots()

const isClockMask = computed(() => {
  const m = props.mask || ''
  return m === 'clockwise' || m === 'counter-clockwise' || m === 'cw' || m === 'ccw'
})

const currentClockClicks = computed(() => {
  // 优先取 Slidev 全局 $slidev.nav.clicks，否则降级为 props.clicks
  // @ts-ignore
  const navClicks = typeof window !== 'undefined' && (window as any).$slidev?.nav?.clicks
  return typeof navClicks === 'number' ? navClicks : Number(props.clicks || 0)
})

const clockPercent = computed(() => {
  if (!isClockMask.value) return 100
  const isInitRev = props.maskInitial === 'revealed'
  const step = currentClockClicks.value
  const bps = [25, 50, 75, 100]
  if (step <= 0) return isInitRev ? bps[0] : 0
  const effectiveIdx = isInitRev ? step : (step - 1)
  if (effectiveIdx >= bps.length) return 100
  return bps[effectiveIdx] || 100
})

const clockNeedleAngle = computed(() => {
  const isCw = props.mask === 'clockwise' || props.mask === 'cw'
  const sweepDeg = Math.min(360, Math.max(0, (clockPercent.value / 100) * 360))
  return isCw ? (-180 + sweepDeg) : (-90 - sweepDeg)
})

const clockMaskOverlayStyle = computed(() => {
  if (!isClockMask.value) return {}
  const p = clockPercent.value
  const isCw = props.mask === 'clockwise' || props.mask === 'cw'
  const sweepDeg = Math.min(360, Math.max(0, (p / 100) * 360))
  let maskGrad = ''
  if (sweepDeg <= 0) {
    maskGrad = 'conic-gradient(from 0deg at 50% 50%, #000 0deg, #000 360deg)'
  } else if (sweepDeg >= 360) {
    maskGrad = 'conic-gradient(from 0deg at 50% 50%, transparent 0deg, transparent 360deg)'
  } else if (isCw) {
    maskGrad = \`conic-gradient(from 270deg at 50% 50%, transparent 0deg, transparent \${sweepDeg}deg, #000 \${sweepDeg}deg, #000 360deg)\`
  } else {
    const remDeg = 360 - sweepDeg
    maskGrad = \`conic-gradient(from 0deg at 50% 50%, #000 0deg, #000 \${remDeg}deg, transparent \${remDeg}deg, transparent 360deg)\`
  }
  return {
    WebkitMaskImage: maskGrad,
    maskImage: maskGrad,
  }
})
<\/script>

<template>
  <div class="slidev-layout clover w-full h-full flex flex-col">
    <div class="header-section mb-4 w-full">
      <slot />
    </div>
    <div class="relative flex-1 min-h-0 overflow-hidden">
      <div class="grid grid-cols-2 grid-rows-2 gap-6 w-full h-full items-stretch">
        <div class="col-1 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
          <slot name="col-1" />
        </div>
        <div class="col-2 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
          <slot name="col-2" />
        </div>
        <div class="col-3 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
          <slot name="col-3" />
        </div>
        <div class="col-4 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
          <slot name="col-4" />
        </div>
      </div>
      <div
        v-if="isClockMask"
        class="slides-mask-layer slides-mask-layer--clock pointer-events-none absolute inset-0 z-50 transition-opacity duration-300"
        :class="props.maskStyle === 'blur' ? 'slides-mask-layer--blur' : 'slides-mask-layer--solid'"
        :style="{ opacity: clockPercent >= 100 ? 0 : 1 }"
      >
        <div
          class="slides-mask-overlay absolute inset-0 w-full h-full"
          :class="props.maskStyle === 'blur' ? 'backdrop-blur-xl bg-white/70 dark:bg-black/70' : 'bg-[var(--slide-bg,#fff)] dark:bg-[var(--slide-bg,#121214)]'"
          :style="clockMaskOverlayStyle"
        />
        <div
          class="slides-mask-divider-line slides-mask-divider-line--clock absolute pointer-events-none transition-all duration-300"
          :style="{
            top: '50%',
            left: '50%',
            width: '55%',
            height: '2.5px',
            transformOrigin: '0% 50%',
            transform: \`translateY(-50%) rotate(\${clockNeedleAngle}deg)\`,
            opacity: (clockPercent <= 0 || clockPercent >= 100) ? 0 : 1,
            background: 'linear-gradient(90deg, var(--slide-accent, #3b82f6) 0%, var(--slide-accent, #3b82f6) 75%, transparent 100%)',
            boxShadow: '0 0 10px var(--slide-accent, #3b82f6), 0 0 4px var(--slide-accent, #3b82f6)',
          }"
        />
      </div>
    </div>
  </div>
</template>
`,kp=`// Auto-generated by SiYuan Slidev Studio
// 本地 HTML 链接（思源资产 / 工作区文件 / 绝对文件路径）速览判定
// 注意：需与 public/slides-client/index.html 中的拦截器保持同步
function isPeekableLocalHtml(href: string): boolean {
  const clean = (href || '').trim()
  if (!clean || clean.startsWith('#') || clean.startsWith('//')) return false
  if (!/\\.html?($|[?#])/i.test(clean)) return false
  if (/^https?:\\/\\//i.test(clean)) return false
  const scheme = /^([a-z][a-z0-9+.-]*):/i.exec(clean)
  if (!scheme) return true
  const schemeName = scheme[1].toLowerCase()
  if (schemeName === 'file') return true
  // Windows 盘符路径（D:\\\\docs\\\\demo.html）并非协议前缀
  return schemeName.length === 1 && /^[a-zA-Z]:[\\\\/]/.test(clean)
}

// 本地 HTML 链接预处理：思源资产统一指向内核 /assets/ 静态服务，其余原样转交宿主归一化
// 不基于 location 绝对化，保证 Pro 模式（Slidev dev server）与沙箱模式行为完全一致
function resolvePeekHref(href: string): string {
  const clean = (href || '').trim()
  if (/^(?:\\.\\/|\\/)?assets\\//.test(clean)) {
    return '/' + clean.replace(/^(?:\\.\\/|\\/)/, '')
  }
  return clean
}

export default function() {
  if (typeof window === 'undefined') return
  window.addEventListener('click', (e: MouseEvent) => {
    const target = e.target as HTMLElement | null
    if (!target || !target.closest) return

    const refEl = target.closest('[data-ref-id]')
    if (refEl) {
      const blockId = refEl.getAttribute('data-ref-id')
      if (blockId) {
        e.preventDefault()
        e.stopPropagation()
        window.parent.postMessage({
          source: 'siyuan-slides-client',
          action: 'OPEN_PEEK_DRAWER',
          payload: { peekType: 'siyuan', blockId, title: (refEl.innerText || refEl.title || '').trim() }
        }, '*')
        return
      }
    }

    const linkEl = target.closest('a') as HTMLAnchorElement | null
    if (linkEl) {
      const href = linkEl.getAttribute('href') || ''
      if (href.startsWith('siyuan://blocks/')) {
        e.preventDefault()
        e.stopPropagation()
        const cleanBlockId = href.replace('siyuan://blocks/', '').split('?')[0]
        window.parent.postMessage({
          source: 'siyuan-slides-client',
          action: 'OPEN_PEEK_DRAWER',
          payload: { peekType: 'siyuan', blockId: cleanBlockId, title: (linkEl.innerText || linkEl.title || '').trim() }
        }, '*')
      } else if (/^https?:\\/\\//i.test(href)) {
        e.preventDefault()
        e.stopPropagation()
        window.parent.postMessage({
          source: 'siyuan-slides-client',
          action: 'OPEN_PEEK_DRAWER',
          payload: { peekType: 'web', url: href, title: (linkEl.innerText || linkEl.title || '').trim() }
        }, '*')
      } else if (isPeekableLocalHtml(href)) {
        e.preventDefault()
        e.stopPropagation()
        window.parent.postMessage({
          source: 'siyuan-slides-client',
          action: 'OPEN_PEEK_DRAWER',
          payload: { peekType: 'web', url: resolvePeekHref(href), title: (linkEl.innerText || linkEl.title || '').trim() }
        }, '*')
      }
    }
  }, true)
}
`,wp=`${Oo}

/* Auto-generated by SiYuan Slidev Studio */
.slides-ref-tag,
a.slides-ref-tag {
  display: inline-flex;
  align-items: center;
  background: color-mix(in srgb, var(--slides-theme-primary, #10b981) 12%, transparent);
  color: var(--slides-theme-primary, #10b981);
  border-radius: 4px;
  padding: 2px 8px;
  font-size: 0.88em;
  text-decoration: none;
  border: 1px solid color-mix(in srgb, var(--slides-theme-primary, #10b981) 25%, transparent);
  cursor: pointer;
  transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
  user-select: none;
}

.slides-ref-tag:hover,
a.slides-ref-tag:hover {
  background: color-mix(in srgb, var(--slides-theme-primary, #10b981) 22%, transparent);
  color: var(--slides-theme-primary, #10b981);
  border-color: color-mix(in srgb, var(--slides-theme-primary, #10b981) 55%, transparent);
  transform: translateY(-1px);
  box-shadow: 0 2px 8px color-mix(in srgb, var(--slides-theme-primary, #10b981) 20%, transparent);
}

.slides-block-ref {
  display: block;
  padding: 10px 14px;
  background: color-mix(in srgb, var(--slides-theme-primary, #10b981) 8%, transparent);
  border-left: 3px solid var(--slides-theme-primary, #10b981);
  border-radius: 0 6px 6px 0;
  margin: 8px 0;
  cursor: pointer;
  transition: background 0.2s ease;
}

.slides-block-ref:hover {
  background: color-mix(in srgb, var(--slides-theme-primary, #10b981) 15%, transparent);
}

/* 代码块自动换行与无横向滚动条 */
pre,
pre code {
  white-space: pre-wrap !important;
  word-break: break-all !important;
  overflow-wrap: anywhere !important;
  overflow-x: hidden !important;
  overflow-y: auto !important;
  max-width: 100% !important;
  box-sizing: border-box !important;
}

/* 弱提示滚动条样式 */
* {
  scrollbar-width: thin;
}
html:not(.dark) * {
  scrollbar-color: rgba(0, 0, 0, 0.15) transparent;
}
html.dark * {
  scrollbar-color: rgba(255, 255, 255, 0.20) transparent;
}
*::-webkit-scrollbar {
  width: 4px;
  height: 4px;
}
*::-webkit-scrollbar-track {
  background: transparent;
}
html:not(.dark) *::-webkit-scrollbar-thumb {
  background: rgba(0, 0, 0, 0.15);
  border-radius: 2px;
}
html:not(.dark) *:hover::-webkit-scrollbar-thumb,
html:not(.dark) *::-webkit-scrollbar-thumb:hover {
  background: rgba(0, 0, 0, 0.35);
}
html.dark *::-webkit-scrollbar-thumb {
  background: rgba(255, 255, 255, 0.20);
  border-radius: 2px;
}
html.dark *:hover::-webkit-scrollbar-thumb,
html.dark *::-webkit-scrollbar-thumb:hover {
  background: rgba(255, 255, 255, 0.45);
}

/* 多媒体（GIF动图、静态图片、MP4视频）最大化自适应且不超出视口：顶部对齐，横向居中 */
.slidev-layout img,
.slidev-layout video {
  max-width: 100% !important;
  max-height: 100% !important;
  width: auto;
  height: auto;
  object-fit: contain !important;
}
.three-cols-header video,
.two-cols-header video,
.grid-cols-3 video,
.grid-cols-2 video,
.col-1 video,
.col-2 video,
.col-3 video {
  width: auto !important;
  height: auto !important;
  max-width: 100% !important;
  max-height: 100% !important;
  object-fit: contain !important;
  display: block !important;
  margin: 0 auto !important;
}
.slide-list-media {
  display: flex !important;
  flex-direction: column !important;
  align-items: center !important;
  justify-content: flex-start !important;
  margin-top: 4px !important;
  margin-bottom: 4px !important;
  width: 100% !important;
  max-width: 100% !important;
  height: 100% !important;
  max-height: 100% !important;
  flex: 1 1 0% !important;
  overflow: hidden !important;
}
.slide-list-media img,
.slide-list-media video,
.slide-list-media .list-item-gif {
  width: auto !important;
  height: auto !important;
  max-width: 100% !important;
  max-height: 100% !important;
  object-fit: contain !important;
  border-radius: 6px !important;
  box-shadow: 0 3px 12px rgba(0, 0, 0, 0.14) !important;
  display: block !important;
  margin: 0 auto !important;
}
.slide-video-container {
  display: flex !important;
  flex-direction: column !important;
  justify-content: flex-start !important;
  align-items: center !important;
  width: 100% !important;
  max-height: 100% !important;
  margin: 6px 0 !important;
}
.slide-video-player {
  max-width: 100% !important;
  max-height: 100% !important;
  object-fit: contain !important;
  border-radius: 8px !important;
}

/* 两栏与多栏（超级块分栏）布局：紧凑自然行距，子列表保留圆点与层级缩进 */
.cols-header ul,
.three-cols-header ul,
.two-cols-header ul,
.two-cols ul,
.col-1 ul,
.col-2 ul,
.col-3 ul,
.col-4 ul,
.col-5 ul,
.col-6 ul,
.grid-cols-2 ul,
.grid-cols-3 ul {
  list-style: disc !important;
  list-style-type: disc !important;
  padding-left: 1.25em !important;
  margin-left: 0 !important;
  margin-top: 0 !important;
  margin-bottom: 8px !important;
  flex: 0 0 auto !important;
  height: auto !important;
  display: block !important;
}
.cols-header ol,
.three-cols-header ol,
.two-cols-header ol,
.two-cols ol,
.col-1 ol,
.col-2 ol,
.col-3 ol,
.col-4 ol,
.col-5 ol,
.col-6 ol,
.grid-cols-2 ol,
.grid-cols-3 ol {
  list-style: decimal !important;
  list-style-type: decimal !important;
  padding-left: 1.25em !important;
  margin-left: 0 !important;
  margin-top: 0 !important;
  margin-bottom: 8px !important;
  flex: 0 0 auto !important;
  height: auto !important;
  display: block !important;
}
.cols-header li,
.three-cols-header li,
.two-cols-header li,
.two-cols li,
.col-1 li,
.col-2 li,
.col-3 li,
.col-4 li,
.col-5 li,
.col-6 li,
.grid-cols-2 li,
.grid-cols-3 li {
  padding-left: 0.2em !important;
  margin-left: 0 !important;
  margin-bottom: 6px !important;
  flex: 0 0 auto !important;
  height: auto !important;
  display: list-item !important;
  line-height: 1.6 !important;
}
.cols-header ul ul,
.three-cols-header ul ul,
.two-cols-header ul ul,
.two-cols ul ul,
.col-1 ul ul,
.col-2 ul ul,
.col-3 ul ul,
.col-4 ul ul,
.col-5 ul ul,
.col-6 ul ul {
  list-style: circle !important;
  list-style-type: circle !important;
  padding-left: 1.25em !important;
  margin-top: 4px !important;
  margin-bottom: 4px !important;
}

/* 列表项内嵌标题与说明排版 */
.slide-list-item-title,
li > h1,
li > h2,
li > h3,
li > h4,
li > h5,
li > h6 {
  margin-top: 2px !important;
  margin-bottom: 6px !important;
  line-height: 1.35 !important;
  font-weight: 700 !important;
}
li > h1 { font-size: 1.6rem !important; }
li > h2 { font-size: 1.4rem !important; }
li > h3 { font-size: 1.22rem !important; }
li > h4 { font-size: 1.1rem !important; }
.slide-list-item-desc,
li > p {
  margin-top: 4px !important;
  margin-bottom: 6px !important;
  font-size: 1.05rem;
  line-height: 1.55;
  opacity: 0.92;
}
`;function xp(e){var s;const t=[],i=/^[ \t]*<<<[ \t]+(?:@\/|\.\/|)([^\s#]+)(?:#[^\s]+)?/gm;let n;for(;(n=i.exec(e))!==null;){const o=(s=n[1])==null?void 0:s.trim();o&&!t.includes(o)&&t.push(o)}return t}class Sp{constructor(t){ve(this,"workspacePath");ve(this,"slidesFileName");ve(this,"cliBridge",new ur);const i=hp();!(t!=null&&t.workspacePath)||t.workspacePath.includes("/data/storage/petal/siyuan-live-slides/pro-workspace")?this.workspacePath=i:this.workspacePath=t.workspacePath,this.slidesFileName=(t==null?void 0:t.slidesFileName)||"slides.md"}getWorkspacePath(){return this.workspacePath}getSlidesPath(){return`${this.workspacePath}/${this.slidesFileName}`}generatePackageJson(t="default"){const i={name:"siyuan-live-slides-pro-workspace",type:"module",private:!0,scripts:{dev:"slidev --port 3030",build:"slidev build"},dependencies:{"@slidev/cli":"^53.0.0","@slidev/theme-default":"latest"}};return t&&t!=="default"&&(i.dependencies[`@slidev/theme-${t}`]="latest"),JSON.stringify(i,null,2)}buildSlidesMarkdown(t){return this.cliBridge.buildStandardSlidevMarkdown(t)}async scaffold(t,i){const n=this.buildSlidesMarkdown(t),s=this.generatePackageJson(t.config.theme),o=this.getSlidesPath(),a=`${this.workspacePath}/package.json`,r=No(o),l=No(a),c=xp(n);c.includes("snippets/external.ts")||c.push("snippets/external.ts");const u=new Map;for(const S of c){const x=Fl[S]||`// Auto-generated snippet placeholder for SiYuan Slidev
// #region snippet
// ${S}
// #endregion snippet
`;u.set(S,x)}t.slides.some(S=>{var x;return((x=S.frontmatter)==null?void 0:x.layout)==="cols-header"})&&u.set("layouts/cols-header.vue",vp),t.slides.some(S=>{var x;return((x=S.frontmatter)==null?void 0:x.layout)==="three-cols-header"})&&u.set("layouts/three-cols-header.vue",bp),t.slides.some(S=>{var x;return((x=S.frontmatter)==null?void 0:x.layout)==="clover"})&&u.set("layouts/clover.vue",yp),u.set("setup/root.ts",kp),u.set("styles/index.css",wp);const b=Mt("fs"),m=Mt("path");let y=!1;const g=m!=null&&m.dirname?m.dirname(r):"",w=/^[a-zA-Z]:[/\\]/.test(r)||r.includes("siyuan-live-slides-pro");if(b&&m&&w)try{b.existsSync(g)||b.mkdirSync(g,{recursive:!0}),b.writeFileSync(l,s,"utf-8"),b.writeFileSync(r,n,"utf-8");for(const[S,x]of u.entries()){const M=m.join(g,S),E=m.dirname(M);b.existsSync(E)||b.mkdirSync(E,{recursive:!0}),b.existsSync(M)||b.writeFileSync(M,x,"utf-8")}y=!0}catch{}if(!y&&i)try{const S=typeof Blob<"u"?new Blob([n],{type:"text/markdown;charset=utf-8"}):Buffer.from(n,"utf-8"),x=typeof Blob<"u"?new Blob([s],{type:"application/json;charset=utf-8"}):Buffer.from(s,"utf-8");await i(a,!1,x),await i(o,!1,S);for(const[M,E]of u.entries()){const C=`${this.workspacePath}/${M}`,D=typeof Blob<"u"?new Blob([E],{type:"text/plain;charset=utf-8"}):Buffer.from(E,"utf-8");await i(C,!1,D).catch(()=>{})}return{success:!0,slidesPath:o,physicalSlidesPath:r,packageJsonPath:a}}catch(S){return{success:!1,slidesPath:o,physicalSlidesPath:r,packageJsonPath:a,error:String(S)}}return{success:!0,slidesPath:o,physicalSlidesPath:r,packageJsonPath:a}}}class Cp{constructor(){ve(this,"mode","web-sandbox");ve(this,"webBridge");ve(this,"cliBridge");ve(this,"nativeBridge");ve(this,"processManager");ve(this,"scaffolder");ve(this,"envDetector");this.webBridge=new Qn,this.cliBridge=new ur,this.nativeBridge=new mp,this.processManager=new gp,this.scaffolder=new Sp,this.envDetector=new pr}getMode(){return this.mode}setMode(t){this.mode=t}async startProMode(t,i){if(!(await this.envDetector.detect()).hasNode)return{success:!1,url:"",error:"当前系统未检测到 Node.js 环境，无法拉起官方 Slidev CLI，建议继续使用内置高保真引擎"};const s=await this.scaffolder.scaffold(t,i);if(!s.success)return{success:!1,url:"",error:`初始化 Slidev 临时工作空间失败: ${s.error}`};const o=s.physicalSlidesPath||s.slidesPath,a=await this.processManager.startServer(o);return a.success?(this.mode="pro-cli",{success:!0,url:a.url,port:a.port}):{success:!1,url:"",error:a.error}}stopProMode(){this.processManager.stopServer(),this.mode="web-sandbox"}destroy(){this.webBridge.detach(),this.nativeBridge.detach(),this.processManager.stopServer()}}const _p={class:"slides-icon",style:{fill:"none !important"},viewBox:"0 0 24 24",stroke:"currentColor","stroke-width":"1.75","stroke-linecap":"round","stroke-linejoin":"round","aria-hidden":"true"},$p={key:0},Ip={key:1},Mp={key:2},Tp={key:3},Ep={key:4},Ap={key:5},Bp={key:6},Dp={key:7},Lp={key:8},Pp={key:9},Op={key:10},Rp={key:11},Np={key:12},zp={key:13},Hp={key:14},Fp={key:15},jp={key:16},Wp={key:17},Up={key:18},Vp={key:19},Gp={key:20},Kp={key:21},qp={key:22},Yp={key:23},Zp={key:24},Jp={key:25},Xp={key:26},Qp={key:27},eh={key:28},th={key:29},ih={key:30},nh={key:31},sh={key:32},oh={key:33},rh={key:34},ah={key:35},lh={key:36},ch={key:37},dh={key:38},uh={key:39},fh={key:40},ph={key:41},hh={key:42},mh={key:43},gh={key:44},vh={key:45},bh={key:46},yh={key:47},kh={key:48},wh={key:49},xh={key:50},Sh={key:51},Ch={key:52},_h={key:53},$h={key:54},Ih={key:55},Mh={key:56},Th={key:57},Eh={key:58},Ah={key:59},Bh={key:60},Dh={key:61},Lh={key:62},Ph={key:63},Oh={key:64},Rh={key:65},Nh={key:66},zh={key:67},Hh={key:68},Fh={key:69},jh={key:70},Wh={key:71},Uh={key:72},Vh=Bt({__name:"SlidesIcon",props:{name:{}},setup(e){return(t,i)=>(J(),te("svg",_p,[e.name==="fullscreen"||e.name==="maximize"?(J(),te("g",$p,[...i[0]||(i[0]=[f("polyline",{points:"15 3 21 3 21 9"},null,-1),f("polyline",{points:"9 21 3 21 3 15"},null,-1),f("polyline",{points:"21 15 21 21 15 21"},null,-1),f("polyline",{points:"3 9 3 3 9 3"},null,-1)])])):e.name==="minimize"?(J(),te("g",Ip,[...i[1]||(i[1]=[f("polyline",{points:"4 14 10 14 10 20"},null,-1),f("polyline",{points:"20 10 14 10 14 4"},null,-1),f("line",{x1:"14",y1:"10",x2:"21",y2:"3"},null,-1),f("line",{x1:"3",y1:"21",x2:"10",y2:"14"},null,-1)])])):e.name==="close"||e.name==="x"?(J(),te("g",Mp,[...i[2]||(i[2]=[f("line",{x1:"18",y1:"6",x2:"6",y2:"18"},null,-1),f("line",{x1:"6",y1:"6",x2:"18",y2:"18"},null,-1)])])):e.name==="edit"?(J(),te("g",Tp,[...i[3]||(i[3]=[f("path",{d:"M12 20h9"},null,-1),f("path",{d:"M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z"},null,-1)])])):e.name==="eye"?(J(),te("g",Ep,[...i[4]||(i[4]=[f("path",{d:"M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"},null,-1),f("circle",{cx:"12",cy:"12",r:"3"},null,-1)])])):e.name==="external-link"||e.name==="window"?(J(),te("g",Ap,[...i[5]||(i[5]=[f("path",{d:"M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"},null,-1),f("polyline",{points:"15 3 21 3 21 9"},null,-1),f("line",{x1:"10",y1:"14",x2:"21",y2:"3"},null,-1)])])):e.name==="arrow-left"?(J(),te("g",Bp,[...i[6]||(i[6]=[f("line",{x1:"19",y1:"12",x2:"5",y2:"12"},null,-1),f("polyline",{points:"12 19 5 12 12 5"},null,-1)])])):e.name==="arrow-right"?(J(),te("g",Dp,[...i[7]||(i[7]=[f("line",{x1:"5",y1:"12",x2:"19",y2:"12"},null,-1),f("polyline",{points:"12 5 19 12 12 19"},null,-1)])])):e.name==="plus"?(J(),te("g",Lp,[...i[8]||(i[8]=[f("line",{x1:"12",y1:"5",x2:"12",y2:"19"},null,-1),f("line",{x1:"5",y1:"12",x2:"19",y2:"12"},null,-1)])])):e.name==="minus"?(J(),te("g",Pp,[...i[9]||(i[9]=[f("line",{x1:"5",y1:"12",x2:"19",y2:"12"},null,-1)])])):e.name==="split-preview"?(J(),te("g",Op,[...i[10]||(i[10]=[f("rect",{x:"3",y:"3",width:"18",height:"18",rx:"2"},null,-1),f("path",{d:"M12 3v18"},null,-1)])])):e.name==="import"?(J(),te("g",Rp,[...i[11]||(i[11]=[f("path",{d:"M4 17v2a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-2"},null,-1),f("polyline",{points:"7 9 12 14 17 9"},null,-1),f("line",{x1:"12",y1:"14",x2:"12",y2:"3"},null,-1)])])):e.name==="presenter"?(J(),te("g",Np,[...i[12]||(i[12]=[f("path",{d:"M2 3h20"},null,-1),f("path",{d:"M21 3v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V3"},null,-1),f("path",{d:"m7 21 5-5 5 5"},null,-1)])])):e.name==="video"?(J(),te("g",zp,[...i[13]||(i[13]=[f("polygon",{points:"23 7 16 12 23 17 23 7"},null,-1),f("rect",{x:"1",y:"5",width:"15",height:"14",rx:"2",ry:"2"},null,-1)])])):e.name==="step"?(J(),te("g",Hp,[...i[14]||(i[14]=[f("polygon",{points:"13 2 3 14 12 14 11 22 21 10 12 10 13 2"},null,-1)])])):e.name==="motion"?(J(),te("g",Fp,[...i[15]||(i[15]=[f("path",{d:"M5 12h14"},null,-1),f("path",{d:"m12 5 7 7-7 7"},null,-1),f("path",{d:"M5 6h4"},null,-1),f("path",{d:"M5 18h4"},null,-1)])])):e.name==="columns"?(J(),te("g",jp,[...i[16]||(i[16]=[f("rect",{x:"3",y:"3",width:"7",height:"18",rx:"1"},null,-1),f("rect",{x:"14",y:"3",width:"7",height:"18",rx:"1"},null,-1)])])):e.name==="code"?(J(),te("g",Wp,[...i[17]||(i[17]=[f("polyline",{points:"16 18 22 12 16 6"},null,-1),f("polyline",{points:"8 6 2 12 8 18"},null,-1)])])):e.name==="list"?(J(),te("g",Up,[...i[18]||(i[18]=[ht('<line x1="8" y1="6" x2="21" y2="6" data-v-af7d02a2></line><line x1="8" y1="12" x2="21" y2="12" data-v-af7d02a2></line><line x1="8" y1="18" x2="21" y2="18" data-v-af7d02a2></line><line x1="3" y1="6" x2="3.01" y2="6" data-v-af7d02a2></line><line x1="3" y1="12" x2="3.01" y2="12" data-v-af7d02a2></line><line x1="3" y1="18" x2="3.01" y2="18" data-v-af7d02a2></line>',6)])])):e.name==="insert-above"?(J(),te("g",Vp,[...i[19]||(i[19]=[f("line",{x1:"12",y1:"5",x2:"12",y2:"13"},null,-1),f("line",{x1:"8",y1:"9",x2:"16",y2:"9"},null,-1),f("path",{d:"M4 19h16","stroke-dasharray":"2 2"},null,-1)])])):e.name==="insert-below"?(J(),te("g",Gp,[...i[20]||(i[20]=[f("path",{d:"M4 5h16","stroke-dasharray":"2 2"},null,-1),f("line",{x1:"12",y1:"11",x2:"12",y2:"19"},null,-1),f("line",{x1:"8",y1:"15",x2:"16",y2:"15"},null,-1)])])):e.name==="broom"?(J(),te("g",Kp,[...i[21]||(i[21]=[f("path",{d:"m18 15-6-6"},null,-1),f("path",{d:"M4 20h16"},null,-1),f("path",{d:"M6 14l8-8a2.8 2.8 0 0 1 4 4l-8 8H6v-4z"},null,-1)])])):e.name==="trash"?(J(),te("g",qp,[...i[22]||(i[22]=[f("path",{d:"M3 6h18"},null,-1),f("path",{d:"M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"},null,-1),f("path",{d:"M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"},null,-1)])])):e.name==="ai"||e.name==="sparkles"?(J(),te("g",Yp,[...i[23]||(i[23]=[f("path",{d:"m12 3-1.9 5.8a2 2 0 0 1-1.3 1.3L3 12l5.8 1.9a2 2 0 0 1 1.3 1.3L12 21l1.9-5.8a2 2 0 0 1 1.3-1.3L21 12l-5.8-1.9a2 2 0 0 1-1.3-1.3L12 3z"},null,-1)])])):e.name==="palette"?(J(),te("g",Zp,[...i[24]||(i[24]=[ht('<circle cx="13.5" cy="6.5" r=".5" fill="currentColor" data-v-af7d02a2></circle><circle cx="17.5" cy="10.5" r=".5" fill="currentColor" data-v-af7d02a2></circle><circle cx="8.5" cy="7.5" r=".5" fill="currentColor" data-v-af7d02a2></circle><circle cx="6.5" cy="12.5" r=".5" fill="currentColor" data-v-af7d02a2></circle><path d="M12 2C6.5 2 2 6.5 2 12s4.5 10 10 10c.9 0 1.5-.7 1.5-1.5 0-.4-.2-.8-.4-1.1-.3-.4-.4-.8-.4-1.4 0-1.1.9-2 2-2h2.3c3.9 0 7-3.1 7-7 0-5-4.5-9-10-9z" data-v-af7d02a2></path>',5)])])):e.name==="ratio"?(J(),te("g",Jp,[...i[25]||(i[25]=[f("rect",{x:"2",y:"5",width:"20",height:"14",rx:"2"},null,-1),f("line",{x1:"2",y1:"10",x2:"22",y2:"10","stroke-dasharray":"2 2"},null,-1)])])):e.name==="transition"?(J(),te("g",Xp,[...i[26]||(i[26]=[f("path",{d:"M8 3 4 7l4 4"},null,-1),f("path",{d:"M4 7h16"},null,-1),f("path",{d:"m16 21 4-4-4-4"},null,-1),f("path",{d:"M20 17H4"},null,-1)])])):e.name==="export-html"?(J(),te("g",Qp,[...i[27]||(i[27]=[f("polyline",{points:"16 16 12 12 8 16"},null,-1),f("line",{x1:"12",y1:"12",x2:"12",y2:"21"},null,-1),f("path",{d:"M20.4 16.3A5 5 0 0 0 18 7h-1.3A8 8 0 0 0 4 12.8a5 5 0 0 0 1.5 9.2"},null,-1)])])):e.name==="export-pdf"?(J(),te("g",eh,[...i[28]||(i[28]=[f("polyline",{points:"6 9 6 2 18 2 18 9"},null,-1),f("path",{d:"M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"},null,-1),f("rect",{x:"6",y:"14",width:"12",height:"8"},null,-1)])])):e.name==="pin"?(J(),te("g",th,[...i[29]||(i[29]=[f("line",{x1:"12",y1:"17",x2:"12",y2:"22"},null,-1),f("path",{d:"M5 17h14v-2l-2-2V5l1-1V2H6v2l1 1v8l-2 2v2z"},null,-1)])])):e.name==="refresh"?(J(),te("g",ih,[...i[30]||(i[30]=[f("path",{d:"M3 12a9 9 0 0 1 9-9 9.75 9.75 0 0 1 6.74 2.74L21 8"},null,-1),f("path",{d:"M21 3v5h-5"},null,-1),f("path",{d:"M21 12a9 9 0 0 1-9 9 9.75 9.75 0 0 1-6.74-2.74L3 16"},null,-1),f("path",{d:"M8 16H3v5"},null,-1)])])):e.name==="alert"||e.name==="warning"?(J(),te("g",nh,[...i[31]||(i[31]=[f("path",{d:"M10.29 3.86 1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"},null,-1),f("line",{x1:"12",y1:"9",x2:"12",y2:"13"},null,-1),f("line",{x1:"12",y1:"17",x2:"12.01",y2:"17"},null,-1)])])):e.name==="chevron-left"?(J(),te("g",sh,[...i[32]||(i[32]=[f("polyline",{points:"15 18 9 12 15 6"},null,-1)])])):e.name==="chevron-right"?(J(),te("g",oh,[...i[33]||(i[33]=[f("polyline",{points:"9 18 15 12 9 6"},null,-1)])])):e.name==="chevron-down"?(J(),te("g",rh,[...i[34]||(i[34]=[f("polyline",{points:"6 9 12 15 18 9"},null,-1)])])):e.name==="chevrons-left"?(J(),te("g",ah,[...i[35]||(i[35]=[f("polyline",{points:"11 17 6 12 11 7"},null,-1),f("polyline",{points:"18 17 13 12 18 7"},null,-1)])])):e.name==="chevrons-right"?(J(),te("g",lh,[...i[36]||(i[36]=[f("polyline",{points:"13 17 18 12 13 7"},null,-1),f("polyline",{points:"6 17 11 12 6 7"},null,-1)])])):e.name==="play"?(J(),te("g",ch,[...i[37]||(i[37]=[f("polygon",{points:"6 3 20 12 6 21 6 3"},null,-1)])])):e.name==="pause"?(J(),te("g",dh,[...i[38]||(i[38]=[f("line",{x1:"10",y1:"4",x2:"10",y2:"20"},null,-1),f("line",{x1:"14",y1:"4",x2:"14",y2:"20"},null,-1)])])):e.name==="clock"?(J(),te("g",uh,[...i[39]||(i[39]=[f("circle",{cx:"12",cy:"12",r:"10"},null,-1),f("polyline",{points:"12 6 12 12 16 14"},null,-1)])])):e.name==="copy"?(J(),te("g",fh,[...i[40]||(i[40]=[f("rect",{x:"9",y:"9",width:"13",height:"13",rx:"2",ry:"2"},null,-1),f("path",{d:"M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"},null,-1)])])):e.name==="image"||e.name==="export-image"?(J(),te("g",ph,[...i[41]||(i[41]=[f("rect",{x:"3",y:"3",width:"18",height:"18",rx:"2",ry:"2"},null,-1),f("circle",{cx:"8.5",cy:"8.5",r:"1.5"},null,-1),f("polyline",{points:"21 15 16 10 5 21"},null,-1)])])):e.name==="search"?(J(),te("g",hh,[...i[42]||(i[42]=[f("circle",{cx:"11",cy:"11",r:"7"},null,-1),f("line",{x1:"21",y1:"21",x2:"16.65",y2:"16.65"},null,-1)])])):e.name==="settings"||e.name==="gear"?(J(),te("g",mh,[...i[43]||(i[43]=[f("circle",{cx:"12",cy:"12",r:"3"},null,-1),f("path",{d:"M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 1 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 1 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 1 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 1 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"},null,-1)])])):e.name==="notes"||e.name==="file-text"?(J(),te("g",gh,[...i[44]||(i[44]=[ht('<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" data-v-af7d02a2></path><polyline points="14 2 14 8 20 8" data-v-af7d02a2></polyline><line x1="16" y1="13" x2="8" y2="13" data-v-af7d02a2></line><line x1="16" y1="17" x2="8" y2="17" data-v-af7d02a2></line><line x1="10" y1="9" x2="8" y2="9" data-v-af7d02a2></line>',5)])])):e.name==="focus"||e.name==="target"?(J(),te("g",vh,[...i[45]||(i[45]=[f("circle",{cx:"12",cy:"12",r:"3",fill:"currentColor"},null,-1),f("path",{d:"M12 2v4M12 18v4M2 12h4M18 12h4",stroke:"currentColor","stroke-width":"2","stroke-linecap":"round"},null,-1),f("circle",{cx:"12",cy:"12",r:"7",fill:"none",stroke:"currentColor","stroke-width":"1.8"},null,-1)])])):e.name==="layout-cover"||e.name==="cover"?(J(),te("g",bh,[...i[46]||(i[46]=[f("rect",{x:"2",y:"4",width:"20",height:"16",rx:"2"},null,-1),f("line",{x1:"9",y1:"8",x2:"15",y2:"8"},null,-1),f("line",{x1:"5.5",y1:"11.5",x2:"18.5",y2:"11.5"},null,-1),f("line",{x1:"7.5",y1:"15",x2:"16.5",y2:"15"},null,-1)])])):e.name==="layout-default"||e.name==="default"?(J(),te("g",yh,[...i[47]||(i[47]=[ht('<rect x="2" y="4" width="20" height="16" rx="2" data-v-af7d02a2></rect><line x1="5" y1="8" x2="11.5" y2="8" data-v-af7d02a2></line><line x1="5" y1="11.5" x2="19" y2="11.5" data-v-af7d02a2></line><line x1="5" y1="14.5" x2="19" y2="14.5" data-v-af7d02a2></line><line x1="5" y1="17.5" x2="13.5" y2="17.5" data-v-af7d02a2></line>',5)])])):e.name==="layout-two-cols"||e.name==="two-cols"?(J(),te("g",kh,[...i[48]||(i[48]=[ht('<rect x="2" y="4" width="20" height="16" rx="2" data-v-af7d02a2></rect><line x1="12" y1="4" x2="12" y2="20" stroke-dasharray="2 1.5" data-v-af7d02a2></line><line x1="5" y1="8" x2="9.5" y2="8" data-v-af7d02a2></line><line x1="5" y1="11.5" x2="9.5" y2="11.5" data-v-af7d02a2></line><line x1="5" y1="15" x2="8" y2="15" data-v-af7d02a2></line><line x1="14.5" y1="8" x2="19" y2="8" data-v-af7d02a2></line><line x1="14.5" y1="11.5" x2="19" y2="11.5" data-v-af7d02a2></line><line x1="14.5" y1="15" x2="17.5" y2="15" data-v-af7d02a2></line>',8)])])):e.name==="layout-two-cols-header"||e.name==="two-cols-header"?(J(),te("g",wh,[...i[49]||(i[49]=[ht('<rect x="2" y="4" width="20" height="16" rx="2" data-v-af7d02a2></rect><line x1="5" y1="7.5" x2="13" y2="7.5" data-v-af7d02a2></line><line x1="12" y1="10.5" x2="12" y2="18.5" stroke-dasharray="1.5 1.5" data-v-af7d02a2></line><line x1="5" y1="12" x2="9.5" y2="12" data-v-af7d02a2></line><line x1="5" y1="15.5" x2="8.5" y2="15.5" data-v-af7d02a2></line><line x1="14.5" y1="12" x2="19" y2="12" data-v-af7d02a2></line><line x1="14.5" y1="15.5" x2="18" y2="15.5" data-v-af7d02a2></line>',7)])])):e.name==="layout-cols-header"||e.name==="cols-header"||e.name==="layout-three-cols-header"||e.name==="three-cols-header"?(J(),te("g",xh,[...i[50]||(i[50]=[ht('<rect x="2" y="4" width="20" height="16" rx="2" data-v-af7d02a2></rect><line x1="5" y1="7.5" x2="13" y2="7.5" data-v-af7d02a2></line><line x1="9.3" y1="10.5" x2="9.3" y2="18.5" stroke-dasharray="1.5 1.5" data-v-af7d02a2></line><line x1="14.7" y1="10.5" x2="14.7" y2="18.5" stroke-dasharray="1.5 1.5" data-v-af7d02a2></line><line x1="4.5" y1="12" x2="7.5" y2="12" data-v-af7d02a2></line><line x1="4.5" y1="15.5" x2="7" y2="15.5" data-v-af7d02a2></line><line x1="10.5" y1="12" x2="13.5" y2="12" data-v-af7d02a2></line><line x1="10.5" y1="15.5" x2="13.5" y2="15.5" data-v-af7d02a2></line><line x1="16" y1="12" x2="19.5" y2="12" data-v-af7d02a2></line><line x1="16" y1="15.5" x2="18.5" y2="15.5" data-v-af7d02a2></line>',10)])])):e.name==="layout-clover"||e.name==="clover"?(J(),te("g",Sh,[...i[51]||(i[51]=[ht('<rect x="2" y="4" width="20" height="16" rx="2" data-v-af7d02a2></rect><line x1="5" y1="7" x2="13" y2="7" data-v-af7d02a2></line><line x1="4.5" y1="13.5" x2="19.5" y2="13.5" stroke-dasharray="1.5 1.5" data-v-af7d02a2></line><line x1="12" y1="9" x2="12" y2="18.5" stroke-dasharray="1.5 1.5" data-v-af7d02a2></line><line x1="5" y1="11" x2="9.5" y2="11" data-v-af7d02a2></line><line x1="14.5" y1="11" x2="19" y2="11" data-v-af7d02a2></line><line x1="5" y1="16" x2="9.5" y2="16" data-v-af7d02a2></line><line x1="14.5" y1="16" x2="19" y2="16" data-v-af7d02a2></line>',8)])])):e.name==="layout-image-right"||e.name==="image-right"?(J(),te("g",Ch,[...i[52]||(i[52]=[ht('<rect x="2" y="4" width="20" height="16" rx="2" data-v-af7d02a2></rect><line x1="12" y1="4" x2="12" y2="20" data-v-af7d02a2></line><line x1="4.5" y1="8" x2="9.5" y2="8" data-v-af7d02a2></line><line x1="4.5" y1="11.5" x2="10" y2="11.5" data-v-af7d02a2></line><line x1="4.5" y1="14.5" x2="8" y2="14.5" data-v-af7d02a2></line><circle cx="15.5" cy="8.5" r="1.2" data-v-af7d02a2></circle><polyline points="13 17 15.5 13 18 16 19.5 14" data-v-af7d02a2></polyline>',7)])])):e.name==="layout-image-left"||e.name==="image-left"?(J(),te("g",_h,[...i[53]||(i[53]=[ht('<rect x="2" y="4" width="20" height="16" rx="2" data-v-af7d02a2></rect><line x1="12" y1="4" x2="12" y2="20" data-v-af7d02a2></line><circle cx="6" cy="8.5" r="1.2" data-v-af7d02a2></circle><polyline points="3.5 17 6 13 8.5 16 10 14" data-v-af7d02a2></polyline><line x1="14.5" y1="8" x2="19.5" y2="8" data-v-af7d02a2></line><line x1="14.5" y1="11.5" x2="20" y2="11.5" data-v-af7d02a2></line><line x1="14.5" y1="14.5" x2="18" y2="14.5" data-v-af7d02a2></line>',7)])])):e.name==="layout-center"||e.name==="center"?(J(),te("g",$h,[...i[54]||(i[54]=[f("rect",{x:"2",y:"4",width:"20",height:"16",rx:"2"},null,-1),f("line",{x1:"6.5",y1:"9",x2:"17.5",y2:"9"},null,-1),f("line",{x1:"5",y1:"12",x2:"19",y2:"12"},null,-1),f("line",{x1:"8",y1:"15",x2:"16",y2:"15"},null,-1)])])):e.name==="layout-fact"||e.name==="fact"?(J(),te("g",Ih,[...i[55]||(i[55]=[ht('<rect x="2" y="4" width="20" height="16" rx="2" data-v-af7d02a2></rect><circle cx="8" cy="9" r="1.5" data-v-af7d02a2></circle><line x1="14" y1="8" x2="9" y2="14" data-v-af7d02a2></line><circle cx="15" cy="13" r="1.5" data-v-af7d02a2></circle><line x1="6.5" y1="17" x2="17.5" y2="17" data-v-af7d02a2></line>',5)])])):e.name==="layout-intro"||e.name==="intro"?(J(),te("g",Mh,[...i[56]||(i[56]=[ht('<rect x="2" y="4" width="20" height="16" rx="2" data-v-af7d02a2></rect><circle cx="7.5" cy="9.5" r="2" data-v-af7d02a2></circle><path d="M4.5 16.5c0-1.8 1.3-3 3-3s3 1.2 3 3" data-v-af7d02a2></path><line x1="13" y1="9" x2="18.5" y2="9" data-v-af7d02a2></line><line x1="13" y1="12.5" x2="19.5" y2="12.5" data-v-af7d02a2></line><line x1="13" y1="15.5" x2="17" y2="15.5" data-v-af7d02a2></line>',6)])])):e.name==="layout-quote"||e.name==="quote"?(J(),te("g",Th,[...i[57]||(i[57]=[ht('<rect x="2" y="4" width="20" height="16" rx="2" data-v-af7d02a2></rect><path d="M6 7.5h2v2H6.5c0 1.2-.4 2-1.5 2.5" data-v-af7d02a2></path><path d="M9.5 7.5h2v2H10c0 1.2-.4 2-1.5 2.5" data-v-af7d02a2></path><line x1="6" y1="13.5" x2="18" y2="13.5" data-v-af7d02a2></line><line x1="12.5" y1="16.5" x2="17.5" y2="16.5" data-v-af7d02a2></line>',5)])])):e.name==="desktop"||e.name==="monitor"?(J(),te("g",Eh,[...i[58]||(i[58]=[f("rect",{x:"2",y:"3",width:"20",height:"14",rx:"2"},null,-1),f("line",{x1:"8",y1:"21",x2:"16",y2:"21"},null,-1),f("line",{x1:"12",y1:"17",x2:"12",y2:"21"},null,-1)])])):e.name==="mobile"||e.name==="smartphone"||e.name==="phone"?(J(),te("g",Ah,[...i[59]||(i[59]=[f("rect",{x:"5",y:"2",width:"14",height:"20",rx:"2",ry:"2"},null,-1),f("line",{x1:"12",y1:"18",x2:"12.01",y2:"18","stroke-width":"2","stroke-linecap":"round"},null,-1)])])):e.name==="type"||e.name==="heading"?(J(),te("g",Bh,[...i[60]||(i[60]=[f("polyline",{points:"4 7 4 4 20 4 20 7"},null,-1),f("line",{x1:"9",y1:"20",x2:"15",y2:"20"},null,-1),f("line",{x1:"12",y1:"4",x2:"12",y2:"20"},null,-1)])])):e.name==="reset"||e.name==="undo"?(J(),te("g",Dh,[...i[61]||(i[61]=[f("path",{d:"M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8"},null,-1),f("polyline",{points:"3 3 3 8 8 8"},null,-1)])])):e.name==="repeat"||e.name==="loop"?(J(),te("g",Lh,[...i[62]||(i[62]=[f("path",{d:"m17 1 4 4-4 4"},null,-1),f("path",{d:"M3 11V9a4 4 0 0 1 4-4h14"},null,-1),f("path",{d:"m7 23-4-4 4-4"},null,-1),f("path",{d:"M21 13v2a4 4 0 0 1-4 4H3"},null,-1)])])):e.name==="volume-x"||e.name==="mute"?(J(),te("g",Ph,[...i[63]||(i[63]=[f("polygon",{points:"11 5 6 9 2 9 2 15 6 15 11 19 11 5"},null,-1),f("line",{x1:"22",y1:"9",x2:"16",y2:"15"},null,-1),f("line",{x1:"16",y1:"9",x2:"22",y2:"15"},null,-1)])])):e.name==="sliders"||e.name==="controls"?(J(),te("g",Oh,[...i[64]||(i[64]=[ht('<line x1="4" y1="21" x2="4" y2="14" data-v-af7d02a2></line><line x1="4" y1="10" x2="4" y2="3" data-v-af7d02a2></line><line x1="12" y1="21" x2="12" y2="12" data-v-af7d02a2></line><line x1="12" y1="8" x2="12" y2="3" data-v-af7d02a2></line><line x1="20" y1="21" x2="20" y2="16" data-v-af7d02a2></line><line x1="20" y1="12" x2="20" y2="3" data-v-af7d02a2></line><line x1="1" y1="14" x2="7" y2="14" data-v-af7d02a2></line><line x1="9" y1="8" x2="15" y2="8" data-v-af7d02a2></line><line x1="17" y1="16" x2="23" y2="16" data-v-af7d02a2></line>',9)])])):e.name==="package"||e.name==="zip"||e.name==="archive"?(J(),te("g",Rh,[...i[65]||(i[65]=[f("line",{x1:"16.5",y1:"9.4",x2:"7.5",y2:"4.21"},null,-1),f("path",{d:"M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"},null,-1),f("polyline",{points:"3.27 6.96 12 12.01 20.73 6.96"},null,-1),f("line",{x1:"12",y1:"22.08",x2:"12",y2:"12"},null,-1)])])):e.name==="folder"?(J(),te("g",Nh,[...i[66]||(i[66]=[f("path",{d:"M4 20h16a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2h-7.93a2 2 0 0 1-1.66-.9l-.82-1.2A2 2 0 0 0 7.93 3H4a2 2 0 0 0-2 2v13c0 1.1.9 2 2 2Z"},null,-1)])])):e.name==="rocket"?(J(),te("g",zh,[...i[67]||(i[67]=[f("path",{d:"M4.5 16.5c-1.5 1.26-2 5-2 5s3.74-.5 5-2c.71-.84.7-2.13-.09-2.91a2.18 2.18 0 0 0-2.91-.09z"},null,-1),f("path",{d:"m12 15-3-3a22 22 0 0 1 2-3.95A12.88 12.88 0 0 1 22 2c0 2.72-.78 7.5-6 11a22.35 22.35 0 0 1-4 2z"},null,-1),f("path",{d:"M9 12H4s.55-3.03 2-4c1.62-1.08 5 0 5 0"},null,-1),f("path",{d:"M12 15v5s3.03-.55 4-2c1.08-1.62 0-5 0-5"},null,-1)])])):e.name==="wand"||e.name==="magic"?(J(),te("g",Hh,[...i[68]||(i[68]=[f("path",{d:"m19 2 2 2-6 6-2-2Z"},null,-1),f("path",{d:"m13 8 2 2"},null,-1),f("path",{d:"m3 21 9-9"},null,-1)])])):e.name==="image-left"?(J(),te("g",Fh,[...i[69]||(i[69]=[ht('<rect x="2" y="4" width="20" height="16" rx="2" data-v-af7d02a2></rect><rect x="4" y="6" width="6" height="12" rx="1" data-v-af7d02a2></rect><line x1="13" y1="8" x2="19" y2="8" data-v-af7d02a2></line><line x1="13" y1="12" x2="19" y2="12" data-v-af7d02a2></line><line x1="13" y1="16" x2="17" y2="16" data-v-af7d02a2></line>',5)])])):e.name==="image-right"?(J(),te("g",jh,[...i[70]||(i[70]=[ht('<rect x="2" y="4" width="20" height="16" rx="2" data-v-af7d02a2></rect><rect x="14" y="6" width="6" height="12" rx="1" data-v-af7d02a2></rect><line x1="5" y1="8" x2="11" y2="8" data-v-af7d02a2></line><line x1="5" y1="12" x2="11" y2="12" data-v-af7d02a2></line><line x1="5" y1="16" x2="9" y2="16" data-v-af7d02a2></line>',5)])])):e.name==="help"||e.name==="question"||e.name==="info"?(J(),te("g",Wh,[...i[71]||(i[71]=[f("circle",{cx:"12",cy:"12",r:"10"},null,-1),f("path",{d:"M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"},null,-1),f("line",{x1:"12",y1:"17",x2:"12.01",y2:"17"},null,-1)])])):(J(),te("g",Uh,[...i[72]||(i[72]=[f("rect",{x:"2",y:"3",width:"20",height:"14",rx:"2"},null,-1),f("line",{x1:"8",y1:"21",x2:"16",y2:"21"},null,-1),f("line",{x1:"12",y1:"17",x2:"12",y2:"21"},null,-1)])]))]))}}),ti=(e,t)=>{const i=e.__vccOpts||e;for(const[n,s]of t)i[n]=s;return i},fe=ti(Vh,[["__scopeId","data-v-af7d02a2"]]),Gh={class:"spm-immersion-header"},Kh={class:"spm-immersion-header__left"},qh={class:"spm-immersion-title"},Yh={class:"spm-immersion-header__center"},Zh={class:"spm-immersion-header__actions"},Jh=["aria-label"],Xh={class:"spm-immersion-body"},Qh=Bt({__name:"ImmersionDrawerContainer",props:{visible:{type:Boolean,default:!1},isMaximized:{type:Boolean,default:!1},title:{default:"速览"},closeOnClickMask:{type:Boolean,default:!0}},emits:["update:visible","update:isMaximized","close","toggle-maximize"],setup(e,{emit:t}){const i=e,n=t;function s(){n("update:visible",!1),n("close")}function o(){i.closeOnClickMask&&s()}function a(){n("update:isMaximized",!i.isMaximized),n("toggle-maximize")}function r(l){(l.key===" "||l.key==="ArrowLeft"||l.key==="ArrowRight"||l.key==="PageUp"||l.key==="PageDown")&&l.stopPropagation(),l.key==="Escape"&&(l.preventDefault(),l.stopPropagation(),s())}return(l,c)=>Pt((J(),te("div",{class:Ce(["spm-immersion-container",{"is-maximized":e.isMaximized}]),onKeydown:Yt(r,["stop"])},[f("div",{class:"spm-immersion-mask",onClick:o}),f("div",{class:Ce(["spm-immersion-drawer",{"is-maximized":e.isMaximized}])},[f("div",Gh,[f("div",Kh,[rs(l.$slots,"header-left",{},()=>[f("span",qh,we(e.title),1)])]),f("div",Yh,[rs(l.$slots,"header-center",{},void 0)]),f("div",Zh,[rs(l.$slots,"header-actions",{},void 0),f("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":e.isMaximized?"还原抽屉宽度 (70%)":"最大化填满视口 (100%)",onClick:a},[ae(fe,{name:e.isMaximized?"minimize":"maximize"},null,8,["name"])],8,Jh),f("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"关闭速览 (ESC)",onClick:s},[ae(fe,{name:"close"})])])]),f("div",Xh,[rs(l.$slots,"default",{},void 0)])],2)],34)),[[Do,e.visible]])}}),em=ti(Qh,[["__scopeId","data-v-1359fecb"]]),tm={class:"spm-protyle-drawer"},im={class:"spm-protyle-drawer__subbar"},nm={class:"spm-protyle-drawer__nav"},sm=["title"],om={class:"spm-protyle-drawer__actions"},rm=["aria-label"],am=["aria-label"],lm=Bt({__name:"ProtylePeekDrawer",props:{blockId:{},title:{},plugin:{}},emits:["external-jump"],setup(e,{emit:t}){const i=t,n=e,s=ge(n.blockId),o=ge(n.title||""),a=ge(!1),r=ge(!0),l=ge(!1),c=ge(""),u=Ut,d=ge([]),h=ge(null);let p=null;Ui(()=>n.blockId,C=>{C&&C!==s.value&&(s.value=C,o.value=n.title||"",d.value=[],m(C))}),vn(()=>{s.value&&m(s.value)}),ir(()=>{y()});async function b(C){try{const D=await dn(`SELECT id, root_id, type, content FROM blocks WHERE id = '${C}' LIMIT 1`);if(Array.isArray(D)&&D.length>0){const R=D[0];c.value=R.root_id||"";const N=R.id===R.root_id||R.type==="d";l.value=N,r.value=!N,!o.value&&R.content&&(o.value=R.content.trim().slice(0,30));return}}catch(D){console.warn("[ProtylePeekDrawer] detectBlockType query failed:",D)}l.value=!1,r.value=!0}async function m(C,D){if(!h.value||!C)return;y(),await b(C),typeof D=="boolean"&&(r.value=!l.value&&D);let R,N;r.value&&!l.value?(R=["cb-get-all","cb-get-hl","cb-get-focus"],N={background:!1,title:!1,gutter:!0,breadcrumbDocName:!0,scroll:!0}):(R=["cb-get-context","cb-get-hl"],N={background:!0,title:!0,gutter:!0,breadcrumbDocName:!0,scroll:!0});try{p=new de.Protyle(n.plugin.app,h.value,{blockId:C,action:R,render:N}),!a.value&&p&&typeof p.disable=="function"&&p.disable()}catch(K){console.error("[ProtylePeekDrawer] Failed to instantiate Protyle:",K)}}function y(){if(p){try{typeof p.destroy=="function"&&p.destroy()}catch(C){console.warn("[ProtylePeekDrawer] Error destroying protyle:",C)}p=null}h.value&&(h.value.innerHTML="")}function g(){l.value||(r.value=!r.value,m(s.value,r.value))}function w(){a.value=!a.value,p&&(a.value?(typeof p.enable=="function"&&p.enable(),typeof p.focus=="function"&&p.focus()):typeof p.disable=="function"&&p.disable())}function S(){if(s.value)try{de.openWindow({doc:{id:s.value},alwaysOnTop:!0})}catch(C){console.warn("[ProtylePeekDrawer] openWindow failed:",C)}}function x(){var R;if(!s.value)return;const C=qs(),D=Dl(C.webServeUrl,s.value,{focus:!l.value});if(typeof window<"u"){const N=Mt("electron");(R=N==null?void 0:N.shell)!=null&&R.openExternal?N.shell.openExternal(D).catch(()=>{window.open(D,"_blank")}):window.open(D,"_blank")}i("external-jump",D)}function M(){if(d.value.length>0){const C=d.value.pop();C&&(s.value=C.blockId,o.value=C.title,r.value=C.isFocusMode,l.value=C.isDoc,m(C.blockId,C.isFocusMode))}}function E(C){const D=C.target;if(!D)return;const R=D.closest('[data-type="block-ref"]');if(R){const K=R.getAttribute("data-id");if(K&&K!==s.value){C.preventDefault(),C.stopPropagation(),d.value.push({blockId:s.value,title:o.value||s.value,isFocusMode:r.value,isDoc:l.value}),s.value=K,o.value=R.innerText.trim()||K,m(K);return}}const N=D.closest("a");if(N&&N.href&&N.href.startsWith("siyuan://blocks/")){C.preventDefault(),C.stopPropagation();const K=N.href.replace("siyuan://blocks/","").split("?")[0];K&&K!==s.value&&(d.value.push({blockId:s.value,title:o.value||s.value,isFocusMode:r.value,isDoc:l.value}),s.value=K,o.value=N.innerText.trim()||K,m(K))}}return(C,D)=>(J(),te("div",tm,[f("div",im,[f("div",nm,[d.value.length>0?(J(),te("button",{key:0,class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"返回上层引用文档或块",onClick:M},[ae(fe,{name:"arrow-left"}),D[0]||(D[0]=f("span",null,"返回",-1))])):Te("",!0),f("span",{class:Ce(["spm-protyle-badge",{"is-focus":r.value&&!l.value}])},we(r.value&&!l.value?"思源块聚焦":"思源文档速览"),3),f("span",{class:"spm-protyle-id",title:o.value||s.value},we(o.value||s.value),9,sm)]),f("div",om,[l.value?Te("",!0):(J(),te("button",{key:0,class:Ce(["spm-icon-btn b3-tooltips b3-tooltips__s",{"is-primary":r.value}]),"aria-label":r.value?"当前为块聚焦模式（点击展开所属文档全文）":"当前为文档全文模式（点击切回仅聚焦当前块）",onClick:g},[ae(fe,{name:r.value?"focus":"file-text"},null,8,["name"]),f("span",null,we(r.value?"块聚焦":"展开全文"),1)],10,rm)),f("button",{class:Ce(["spm-icon-btn b3-tooltips b3-tooltips__s",{"is-primary":a.value}]),"aria-label":a.value?"当前为即时编辑模式（点击切回只读）":"当前为只读速览模式（点击解锁即时编辑）",onClick:w},[ae(fe,{name:a.value?"edit":"eye"},null,8,["name"]),f("span",null,we(a.value?"编辑中":"只读"),1)],10,am),f("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"在置顶独立窗口中打开 (保留完整侧边栏与插件)",onClick:S},[ae(fe,{name:"window"}),D[1]||(D[1]=f("span",null,"独立窗口",-1))]),he(u).enableWebServeJump?(J(),te("button",{key:1,class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"在系统默认浏览器中打开 (外跳)",onClick:x},[ae(fe,{name:"external-link"}),D[2]||(D[2]=f("span",null,"外跳",-1))])):Te("",!0)])]),f("div",{ref_key:"mountEl",ref:h,class:Ce(["spm-protyle-mount",{"is-focus-mode":r.value&&!l.value}]),onClick:E},null,2)]))}}),cm=ti(lm,[["__scopeId","data-v-0d6e2df3"]]),dm=/^(https?|file|data|blob|mailto|tel|ftp|ftps|siyuan|about|chrome|ws|wss):/i,um=/\.(html?|xhtml|pdf|png|jpe?g|gif|svg|webp|avif|ico|mp4|webm|mov|mp3|wav|m4a|ogg|json|md|markdown|txt|csv|zip|tar|gz|7z|rar|js|mjs|css|xml|yaml|yml|toml|ipynb|docx?|xlsx?|pptx?)$/i;function ra(e){let t=e||"";try{t=decodeURIComponent(t)}catch{}t=t.replace(/\\/g,"/");const i=/(?:^|\/)data\/assets\/(.+)$/i.exec(t);if(i)return`/assets/${i[1]}`;const n=/(?:^|\/)data\/plugins\/(.+)$/i.exec(t);return n?`/plugins/${n[1]}`:null}function jl(e){const t=(e||"").replace(/^file:\/\//i,"");let i=t;try{i=decodeURIComponent(t)}catch{}if(i.startsWith("/"))return/^\/([a-zA-Z]:[\\/])/.exec(i)?i.slice(1):i;const n=i.indexOf("/");return n>=0?i.slice(n):i}function fm(e){const t=e.split(/[/?#]/)[0];return!t||um.test(t)?!1:/^(localhost|\d{1,3}(\.\d{1,3}){3})(:\d+)?$/i.test(t)?!0:/^[a-z0-9-]+(\.[a-z0-9-]+)+(:\d+)?$/i.test(t)}function pm(e){const t=e.indexOf("#"),i=t>=0?e.slice(t):"",n=t>=0?e.slice(0,t):e,s=n.indexOf("?"),o=s>=0?n.slice(0,s):n,a=s>=0?n.slice(s+1):"";if(!/^\/?assets\/.+\.html?$/i.test(o))return e;const r=new URLSearchParams(a);return r.get("iframe")==="true"||r.get("download")==="true"?e:(r.set("iframe","true"),`${o}?${r.toString()}${i}`)}function Wl(e){const t=hm(e);return t.external||!t.url?t:{url:pm(t.url),external:!1}}function hm(e){const t=(e||"").trim();if(!t)return{url:"",external:!1};if(/^https?:\/\//i.test(t))return{url:t,external:!1};if(t.startsWith("//"))return{url:`https:${t}`,external:!1};if(/^(siyuan|data|blob|about):/i.test(t))return{url:t,external:!1};if($a(t))return{url:`/${Ia(t)}`,external:!1};if(/^file:/i.test(t)){const n=ra(jl(t));return n?{url:n,external:!1}:{url:t,external:!0}}if(/^[a-zA-Z]:[\\/]/.test(t)||t.startsWith("\\\\")){const n=ra(t);return n?{url:n,external:!1}:{url:t,external:!0}}return dm.test(t)?{url:t,external:!0}:fm(t)?{url:`https://${t}`,external:!1}:{url:`/${t.replace(/^(?:\.{1,2}\/)+/,"").replace(/^\/+/,"")}`,external:!1}}const mm={class:"spm-webview-drawer"},gm={class:"spm-webview-toolbar"},vm={class:"spm-webview-toolbar__nav"},bm=["disabled"],ym=["disabled"],km=["aria-label"],wm={class:"spm-webview-toolbar__address"},xm=["aria-label"],Sm={class:"spm-webview-toolbar__actions"},Cm=["aria-label"],_m={class:"spm-zoom-controller"},$m=["disabled"],Im=["disabled"],Mm={key:1,class:"spm-webview-fallback"},Tm=["src"],Em={key:2,class:"spm-load-error"},Am={class:"spm-load-error__code"},Bm={class:"spm-load-error__code-num"},Dm={class:"spm-load-error__url"},Lm={class:"spm-load-error__hint"},Pm={class:"spm-load-error__actions"},aa="Mozilla/5.0 (iPhone; CPU iPhone OS 17_4_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.4.1 Mobile/15E148 Safari/604.1",Ul="siyuan-slides-peek-view-mode";let Vl="desktop";function Om(){if(typeof window<"u"&&window.localStorage)try{const e=window.localStorage.getItem(Ul);if(e==="mobile"||e==="desktop")return e}catch{}return Vl}function Rm(e){if(Vl=e,typeof window<"u"&&window.localStorage)try{window.localStorage.setItem(Ul,e)}catch{}}function Nm(e){switch((e||"").toUpperCase()){case"ERR_PROXY_CONNECTION_FAILED":return"无法连接到代理服务器：请在思源「设置 → 网络代理」中填写公司代理地址，或切换为「使用系统代理」。";case"ERR_TUNNEL_CONNECTION_FAILED":return"HTTPS 代理隧道建立失败：请将思源「网络代理」的类型设为 HTTPS 并确认地址正确。";case"ERR_MANDATORY_PROXY_CONFIGURATION_FAILED":return"强制代理配置获取失败：公司 PAC 脚本不可用，请在思源「网络代理」中改为手动填写代理地址。";case"ERR_NAME_NOT_RESOLVED":case"ERR_NAME_RESOLUTION_FAILED":return"域名解析失败：内网环境访问外网通常需要配置代理或 DNS。";case"ERR_INTERNET_DISCONNECTED":return"当前网络不可用：请检查网络连接。";case"ERR_CONNECTION_TIMED_OUT":case"ERR_TIMED_OUT":return"连接超时：该地址可能需要通过代理才能访问。";case"ERR_CONNECTION_REFUSED":return"连接被拒绝：目标服务未在监听，或思源本地内核尚未启动。";case"ERR_CERT_AUTHORITY_INVALID":case"ERR_CERT_COMMON_NAME_INVALID":case"ERR_CERT_DATE_INVALID":return"证书校验失败：若公司网络使用 TLS 拦截，需将根证书导入思源所用系统的证书库。";default:return"若处于公司内网，请优先检查思源「设置 → 网络代理」是否已配置为可用代理（支持「使用系统代理」）。"}}const zm=Bt({__name:"WebviewPeekDrawer",props:{url:{},title:{},visible:{type:Boolean,default:!0}},emits:["external-jump"],setup(e,{emit:t}){const i=t,n=e,s=ge(zl()&&!pp()),o=ge(n.url),a=ge(n.url),r=n.url,l=ge(!1),c=ge(null),u=ge(!1),d=ge(!1),h=ge(1),p=ge(!1),b=ge(Om());let m=typeof navigator<"u"&&!navigator.userAgent.includes("iPhone")?navigator.userAgent:"";const y=ye(()=>b.value==="mobile"?aa:m||void 0),g=ge(null),w=ge(null);let S=null,x=null,M=null;Ui(()=>n.url,X=>{X&&X!==o.value&&(o.value=X,a.value=X,b.value==="mobile"&&N(!1),g.value&&typeof g.value.loadURL=="function"&&g.value.loadURL(X))}),Ui(()=>n.visible,X=>{if(X)ce(),b.value==="mobile"&&N(!1);else if(g.value)try{typeof g.value.stop=="function"&&g.value.stop()}catch{}}),vn(()=>{E(),w.value&&typeof ResizeObserver<"u"&&(S=new ResizeObserver(()=>{const X=g.value;if(X&&typeof X.invalidate=="function")try{X.invalidate()}catch{}}),S.observe(w.value)),x=X=>{var L;const Q=X.message||((L=X.error)==null?void 0:L.message);if(typeof Q=="string"&&Q.includes("Invalid guestInstanceId"))return X.preventDefault(),X.stopImmediatePropagation(),!0},window.addEventListener("error",x,!0),M=X=>{const Q=X.reason,L=typeof Q=="string"?Q:Q==null?void 0:Q.message;typeof L=="string"&&L.includes("Invalid guestInstanceId")&&X.preventDefault()},window.addEventListener("unhandledrejection",M)}),ir(()=>{if(C(),S&&(S.disconnect(),S=null),x&&(window.removeEventListener("error",x,!0),x=null),M&&(window.removeEventListener("unhandledrejection",M),M=null),g.value)try{typeof g.value.stop=="function"&&g.value.stop()}catch{}});function E(){const X=g.value;X&&(X.addEventListener("dom-ready",D),X.addEventListener("did-start-loading",K),X.addEventListener("did-stop-loading",k),X.addEventListener("did-navigate",F),X.addEventListener("did-navigate-in-page",H),X.addEventListener("new-window",I),X.addEventListener("did-fail-load",$),X.addEventListener("did-fail-provisional-load",$))}function C(){const X=g.value;if(X)try{X.removeEventListener("dom-ready",D),X.removeEventListener("did-start-loading",K),X.removeEventListener("did-stop-loading",k),X.removeEventListener("did-navigate",F),X.removeEventListener("did-navigate-in-page",H),X.removeEventListener("new-window",I),X.removeEventListener("did-fail-load",$),X.removeEventListener("did-fail-provisional-load",$)}catch{}}function D(){const X=g.value;if(X&&typeof X.getUserAgent=="function"&&!m)try{const Q=X.getUserAgent();Q&&!Q.includes("iPhone")&&(m=Q)}catch{}b.value==="mobile"&&N(!1),ce(),A()}function R(){const X=b.value==="mobile"?"desktop":"mobile";b.value=X,Rm(X),N(!0)}function N(X=!1){const Q=g.value;if(!Q)return;const L=b.value==="mobile"?aa:m;if(typeof Q.setUserAgent=="function"&&L)try{Q.setUserAgent(L)}catch(j){console.warn("[WebviewPeekDrawer] setUserAgent error:",j)}if(X&&typeof Q.reload=="function")try{Q.reload()}catch(j){console.warn("[WebviewPeekDrawer] reload error:",j)}}function K(){l.value=!0,c.value=null}function $(X){if(X&&X.isMainFrame===!1||X&&Number(X.errorCode)===-3)return;const Q=String((X==null?void 0:X.errorDescription)||"ERR_FAILED");c.value={errorCode:Number((X==null?void 0:X.errorCode)??0),description:Q,validatedURL:String((X==null?void 0:X.validatedURL)||o.value),hint:Nm(Q)},l.value=!1}function V(){c.value=null,G()}function k(){if(l.value=!1,A(),g.value&&typeof g.value.getURL=="function"){const X=g.value.getURL();X&&X!=="about:blank"&&(o.value=X,a.value=X)}}function F(X){X!=null&&X.url&&(o.value=X.url,a.value=X.url),A()}function H(X){X!=null&&X.url&&(o.value=X.url,a.value=X.url),A()}function I(X){X&&X.url&&(X.preventDefault(),g.value&&typeof g.value.loadURL=="function"&&g.value.loadURL(X.url))}function A(){const X=g.value;X&&(typeof X.canGoBack=="function"&&(u.value=X.canGoBack()),typeof X.canGoForward=="function"&&(d.value=X.canGoForward()))}function O(){g.value&&typeof g.value.goBack=="function"&&g.value.goBack()}function ne(){g.value&&typeof g.value.goForward=="function"&&g.value.goForward()}function G(){g.value&&typeof g.value.reload=="function"&&g.value.reload()}function q(){const X=Wl(a.value);if(X.url){if(X.external){o.value=X.url,pe();return}o.value=X.url,a.value=X.url,g.value&&typeof g.value.loadURL=="function"&&g.value.loadURL(X.url)}}function ce(){const X=g.value;if(X&&typeof X.setZoomFactor=="function")try{X.setZoomFactor(h.value)}catch(Q){console.warn("[WebviewPeekDrawer] setZoomFactor error:",Q)}}function se(){h.value=Math.min(2.5,Math.round((h.value+.1)*10)/10),ce()}function re(){h.value=Math.max(.5,Math.round((h.value-.1)*10)/10),ce()}function Se(){h.value=1,ce()}function Ie(X){X.preventDefault(),X.deltaY<0?se():X.deltaY>0&&re()}async function _e(){if(typeof navigator<"u"&&navigator.clipboard)try{await navigator.clipboard.writeText(o.value),p.value=!0,setTimeout(()=>{p.value=!1},2e3)}catch(X){console.warn("Copy url failed:",X)}}function pe(){var Q;const X=o.value;if(typeof window<"u"){const L=Mt("electron");(Q=L==null?void 0:L.shell)!=null&&Q.openExternal?L.shell.openExternal(X).catch(()=>{window.open(X,"_blank")}):window.open(X,"_blank")}i("external-jump",X)}return(X,Q)=>{const L=xu("webview");return J(),te("div",mm,[f("div",gm,[f("div",vm,[f("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s",disabled:!u.value,"aria-label":"后退",onClick:O},[ae(fe,{name:"arrow-left"})],8,bm),f("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s",disabled:!d.value,"aria-label":"前进",onClick:ne},[ae(fe,{name:"arrow-right"})],8,ym),f("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":l.value?"正在加载...":"刷新页面",onClick:G},[ae(fe,{name:"refresh"})],8,km)]),f("div",wm,[Pt(f("input",{"onUpdate:modelValue":Q[0]||(Q[0]=j=>a.value=j),type:"text",class:"b3-text-field spm-url-input",placeholder:"https://...",spellcheck:"false",onKeydown:Nf(q,["enter"])},null,544),[[Lo,a.value]]),f("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":p.value?"已复制地址！":"复制网址",onClick:_e},[ae(fe,{name:"copy"})],8,xm)]),f("div",Sm,[f("button",{class:Ce(["spm-icon-btn spm-mode-toggle b3-tooltips b3-tooltips__s",{"is-active":b.value==="mobile"}]),"aria-label":b.value==="mobile"?"当前为手机视图，点击切换为桌面视图":"当前为桌面视图，点击切换为手机视图",onClick:R},[ae(fe,{name:b.value==="mobile"?"mobile":"desktop"},null,8,["name"])],10,Cm),f("div",_m,[f("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"缩小 (Ctrl + -)",disabled:h.value<=.5,onClick:re},[ae(fe,{name:"minus"})],8,$m),f("button",{class:"spm-zoom-badge b3-tooltips b3-tooltips__s","aria-label":"重置 100% (Ctrl + 0)",onClick:Se},we(Math.round(h.value*100))+"% ",1),f("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"放大 (Ctrl + +)",disabled:h.value>=2.5,onClick:se},[ae(fe,{name:"plus"})],8,Im)]),f("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"在系统默认浏览器中打开 ↗",onClick:pe},[ae(fe,{name:"external-link"}),Q[1]||(Q[1]=f("span",null,"外跳",-1))])])]),f("div",{ref_key:"containerEl",ref:w,class:Ce(["spm-webview-body",{"is-mobile":b.value==="mobile"}]),onWheel:Yt(Ie,["ctrl"])},[f("div",{class:Ce(["spm-webview-viewport",{"is-mobile":b.value==="mobile"}])},[s.value?(J(),Zt(L,{key:0,ref_key:"webviewRef",ref:g,class:"spm-webview-frame",src:he(r),useragent:y.value,allowpopups:"true",style:{position:"absolute",top:"0",left:"0",width:"100%",height:"100%",display:"inline-flex"}},null,8,["src","useragent"])):(J(),te("div",Mm,[f("iframe",{class:"spm-webview-fallback-frame",src:o.value,frameborder:"0",sandbox:"allow-scripts allow-same-origin allow-forms allow-popups"},null,8,Tm),f("div",{class:"spm-fallback-bar"},[Q[2]||(Q[2]=f("span",null,"如页面受同源策略 (X-Frame-Options) 拦截无法显示，请",-1)),f("button",{class:"spm-icon-btn is-primary",onClick:pe}," 在新标签页中打开 ↗ ")])])),c.value?(J(),te("div",Em,[ae(fe,{name:"alert",class:"spm-load-error__icon"}),Q[5]||(Q[5]=f("div",{class:"spm-load-error__title"},"页面加载失败",-1)),f("div",Am,[_t(we(c.value.description)+" ",1),f("span",Bm,"("+we(c.value.errorCode)+")",1)]),f("div",Dm,we(c.value.validatedURL),1),f("p",Lm,we(c.value.hint),1),f("div",Pm,[f("button",{class:"spm-icon-btn","aria-label":"重试",onClick:V},[ae(fe,{name:"refresh"}),Q[3]||(Q[3]=f("span",null,"重试",-1))]),f("button",{class:"spm-icon-btn is-primary","aria-label":"用系统浏览器打开",onClick:pe},[ae(fe,{name:"external-link"}),Q[4]||(Q[4]=f("span",null,"用系统浏览器打开 ↗",-1))])])])):Te("",!0)],2)],34)])}}}),Hm=ti(zm,[["__scopeId","data-v-6e363f73"]]);class Fm{constructor(){ve(this,"timers",new Map)}debounce(t,i,n=150){this.cancel(t);const s=setTimeout(()=>{this.timers.delete(t),i()},n);this.timers.set(t,s)}cancel(t){this.timers.has(t)&&(clearTimeout(this.timers.get(t)),this.timers.delete(t))}cancelAll(){for(const t of this.timers.values())clearTimeout(t);this.timers.clear()}hasPending(t){return this.timers.has(t)}}class jm{constructor(t){ve(this,"blockToPageMap",new Map);ve(this,"debounceCtrl",new Fm);ve(this,"activeBlockId","");ve(this,"activePageIndex",1);ve(this,"currentDocId","");ve(this,"bridge",null);t&&(this.bridge=t)}setBridge(t){this.bridge=t}setDocId(t){this.currentDocId=t}updateSlidesIndex(t){this.blockToPageMap.clear();for(const i of t){i.startBlockId&&this.blockToPageMap.set(i.startBlockId,i.pageIndex);for(const n of i.blocks)this.blockToPageMap.set(n.id,i.pageIndex)}}getPageByBlockId(t){return this.blockToPageMap.get(t)??null}onCursorFocusBlock(t){if(!t||t===this.activeBlockId)return;this.activeBlockId=t;let i=this.getPageByBlockId(t);!i&&(t===this.currentDocId||!this.currentDocId&&this.blockToPageMap.size>0)&&(i=1),i&&this.debounceCtrl.debounce("cursor-navigate",()=>{this.activePageIndex=i,this.bridge&&(this.bridge.navigatePage(i),this.bridge.highlightElement(t))},100)}getActiveBlockId(){return this.activeBlockId}setActiveBlockId(t){this.activeBlockId=t,t||this.debounceCtrl.cancel("cursor-navigate");const i=this.getPageByBlockId(t);i&&(this.activePageIndex=i)}getActivePageIndex(){return this.activePageIndex}destroy(){this.debounceCtrl.cancelAll(),this.blockToPageMap.clear(),this.bridge=null}}let Tt=null,hs=null,ms="";function Rn(){var e,t;if(hs&&(clearTimeout(hs),hs=null),Tt){try{Tt.classList.remove("protyle-wysiwyg--select"),ms?Tt.style.outline=ms:typeof((e=Tt.style)==null?void 0:e.removeProperty)=="function"?Tt.style.removeProperty("outline"):Tt.style&&(Tt.style.outline=""),typeof((t=Tt.style)==null?void 0:t.removeProperty)=="function"?Tt.style.removeProperty("transition"):Tt.style&&(Tt.style.transition="")}catch(i){console.warn("[SelectionMirror] clear activeHighlightEl failed:",i)}Tt=null,ms=""}if(typeof document<"u"&&typeof document.querySelectorAll=="function")try{document.querySelectorAll(".protyle-wysiwyg [data-node-id].protyle-wysiwyg--select, .protyle-wysiwyg [data-node-id][style*='outline']").forEach(n=>{var o,a;n.classList.remove("protyle-wysiwyg--select");const s=((o=n.style)==null?void 0:o.outline)||"";(s.includes("#3b82f6")||s.includes("rgb(59, 130, 246)")||s.includes("59, 130, 246"))&&(typeof((a=n.style)==null?void 0:a.removeProperty)=="function"?(n.style.removeProperty("outline"),n.style.removeProperty("transition")):n.style&&(n.style.outline="",n.style.transition=""))})}catch{}}function Vi(e,t){var a,r,l,c;if(!e||typeof document>"u")return Rn(),!1;Rn();const i=(a=globalThis.CSS)!=null&&a.escape?globalThis.CSS.escape(e):e.replace(/"/g,'\\"'),n=document.querySelector(`.protyle-wysiwyg [data-node-id="${i}"]`)||document.querySelector(`[data-node-id="${i}"]`);if(!n){if(t)try{return de.openTab({app:t,doc:{id:e,action:["cb-get-hl","cb-get-focus","cb-get-context"]}}),!0}catch(u){console.warn("[SelectionMirror] openTab fallback failed:",u)}return!1}try{n.scrollIntoView({behavior:"smooth",block:"center",inline:"nearest"})}catch{(r=n.scrollIntoView)==null||r.call(n)}try{(l=n.focus)==null||l.call(n,{preventScroll:!0})}catch{}const s=((c=n.style)==null?void 0:c.outline)||"";return ms=s.includes("#3b82f6")||s.includes("rgb(59, 130, 246)")||s.includes("59, 130, 246")?"":s,n.classList.add("protyle-wysiwyg--select"),n.style&&(n.style.outline="2px solid #3b82f6",n.style.transition="outline 0.2s ease"),Tt=n,hs=setTimeout(()=>{Rn()},500),!0}function Wm(e){if(!e)return"";const t=e.split(`
`).map(a=>a.trim()).filter(Boolean);if(t.length===0)return"";if(!t.some(a=>/^#{1,6}\s+/.test(a)))return t.map(a=>at(a)).join("<br/>");const n=[];let s=[];const o=()=>{if(s.length>0){const a=s.map(r=>at(r)).join("<br/>");n.push(`<p class="slide-list-item-desc">${a}</p>`),s=[]}};for(const a of t){const r=a.match(/^(#{1,6})\s+(.*)$/);if(r){o();const l=r[1].length,c=r[2].trim();n.push(`<h${l} class="slide-list-item-title">${at(c)}</h${l}>`)}else s.push(a)}return o(),n.join(`
`)}function Um(e){if(e.length===0)return"";const t=[],i=e[0],n=i.match(/^(#{1,6})\s+(.*)$/);if(n){const s=n[1].length,o=n[2].trim();t.push(`<h${s} class="slide-list-item-title">${at(o)}</h${s}>`)}else t.push(`<p class="slide-list-item-title">${at(i)}</p>`);if(e.length>1){const s=e.slice(1);let o=[];const a=()=>{if(o.length>0){const r=o.map(l=>at(l)).join("<br/>");t.push(`<p class="slide-list-item-desc">${r}</p>`),o=[]}};for(const r of s){const l=r.match(/^(#{1,6})\s+(.*)$/);if(l){a();const c=l[1].length,u=l[2].trim();t.push(`<h${c} class="slide-list-item-title">${at(u)}</h${c}>`)}else o.push(r)}a()}return t.join(`
`)+(t.length>0?`
`:"")}function Gl(e,t,i){var h,p,b,m;const n=e.split(`
`);if(!n.some(y=>/^(\s*)([-*+]|\d+\.)\s+/.test(y)))return(i!=null&&i.isListItem||(i==null?void 0:i.type)==="i")&&!(i!=null&&i.isColFirst)?`<ul class="slide-list slide-list--unordered">
<li class="slide-list-item">${at(e)}</li>
</ul>`:null;const o=[],a=[];let r=!1;for(let y=0;y<n.length;y++){const g=n[y];if(!g.trim())continue;const w=g.match(/^(\s*)[-*+]\s+\[([ xX])\]\s+(.*)$/);if(w){const E=w[1].length,C=Math.floor(E/2);a.push({type:"task",level:C,checked:w[2].toLowerCase()==="x",text:w[3],media:[]});continue}const S=g.match(/^(\s*)[-*+]\s+(.*)$/);if(S){const E=S[1].length,C=Math.floor(E/2);a.push({type:"unordered",level:C,text:S[2],media:[]});continue}const x=g.match(/^(\s*)\d+\.\s+(.*)$/);if(x){a.length===0&&(r=!0);const E=x[1].length,C=Math.floor(E/2);a.push({type:"ordered",level:C,text:x[2],media:[]});continue}const M=g.trim();if(!(!M||/^\{:.*?\}$/.test(M)))if(a.length>0){const E=M.match(/^!\[(.*?)\]\((.*?)\)(?:\{:?[^}]*\})?$/);if(E){const R=/\.gif(?:\?|$)/i.test(E[2])?"list-item-gif":"list-item-img";a[a.length-1].media||(a[a.length-1].media=[]),a[a.length-1].media.push(`<div class="slide-list-media"><img alt="${rt(E[1])}" src="${E[2]}" class="${R}" /></div>`);continue}if(M.match(/^<img\b[\s\S]*?\/?>$/i)){const D=M.replace(/\s+style="[^"]*"/gi,"");a[a.length-1].media||(a[a.length-1].media=[]),a[a.length-1].media.push(`<div class="slide-list-media">${D}</div>`);continue}if(/<video\b/i.test(M)){let D=M;if(!/<\/video>/i.test(D))for(;y+1<n.length&&!/<\/video>/i.test(D);)y++,D+=" "+n[y].trim();const R=((h=i==null?void 0:i.attributes)==null?void 0:h["custom-slides-autoplay"])==="true"||/autoplay/i.test(D),N=((p=i==null?void 0:i.attributes)==null?void 0:p["custom-slides-loop"])==="true"||/loop/i.test(D),K=((b=i==null?void 0:i.attributes)==null?void 0:b["custom-slides-muted"])==="true"||R||/muted/i.test(D),$=((m=i==null?void 0:i.attributes)==null?void 0:m["custom-slides-controls"])==="false",V=D.match(/\bsrc=["']([^"']+)["']/i),k=V?V[1]:"",F=['class="slide-video-player"'];$||F.push("controls"),R&&(F.push("autoplay"),F.push("playsinline")),N&&F.push("loop"),K&&F.push("muted"),F.push('preload="metadata"'),k&&F.push(`src="${k}"`);const H=D.match(/<video[^>]*>([\s\S]*?)<\/video>/i);let I=H?H[1].trim():"";!I&&k&&(I=`<source src="${k}" type="video/mp4" />您的浏览器不支持视频播放。`),a[a.length-1].media||(a[a.length-1].media=[]),a[a.length-1].media.push(`<div class="slide-list-media slide-video-container slide-media-container" data-autoplay="${R?"true":"false"}" data-muted="${K?"true":"false"}"><video ${F.join(" ")}>${I}</video></div>`);continue}a[a.length-1].text+=`
`+M}else o.push(M)}if(a.length===0)return null;const l=r?"ol":"ul",c=(t==null?void 0:t.listClassName)||(r?"pdf-list pdf-list--ordered":"pdf-list pdf-list--unordered"),u=a.map(y=>{const g=Wm(y.text),w=y.media&&y.media.length>0?`
${y.media.join(`
`)}`:"",S=y.level||0,x=S>0?` style="margin-left:${(S*1.25).toFixed(2)}em;${y.type==="unordered"?`list-style-type:${S%2===1?"circle":"square"} !important;`:""}"`:"",M=S>0?" slide-list-item--nested":"";if(y.type==="task"){const C=y.checked?' checked=""':"";return`<li class="pdf-task-item${M}"${x}><label><input type="checkbox" disabled=""${C}/> <span>${g}</span></label>${w}</li>`}return`<li${M?` class="${M.trim()}"`:""}${x}>${g}${w}</li>`}).join(`
`);return`${Um(o)}<${l} class="${c}">
${u}
</${l}>`}function Vm(e,t,i){const n=(t==null?void 0:t.containerClassName)||"pdf-block",s=e.split(/\r?\n/),o=[];let a=[];for(let c=0;c<s.length;c++){const u=s[c],d=u.trim();if(/^#{1,6}\s+/.test(d)){a.length>0&&(o.push(a.join(`
`)),a=[]),o.push(d);continue}if(!d){a.length>0&&(o.push(a.join(`
`)),a=[]);continue}if(/^!\[.*?\]\(.*?\)$/.test(d)){a.length>0&&(o.push(a.join(`
`)),a=[]),o.push(d);continue}if(/<video\b/i.test(d)){a.length>0&&(o.push(a.join(`
`)),a=[]);let h=d;if(!/<\/video>/i.test(h))for(;c+1<s.length&&!/<\/video>/i.test(h);)c++,h+=`
`+s[c];o.push(h);continue}a.push(u)}a.length>0&&o.push(a.join(`
`));let r=!0;return o.map(c=>{var b,m,y,g;const u=c.trim();if(!u)return"";const d=u.match(/^(#{1,6})\s+(.*)$/);if(d){r=!1;const w=d[1].length;return`<h${w} class="slide-list-item-title">${at(d[2].trim())}</h${w}>`}const h=u.match(/^!\[(.*?)\]\((.*?)\)$/);if(h){const w=/\.gif(?:\?|$)/i.test(h[2]),S=(t==null?void 0:t.imageClassName)||(w?"list-item-gif":"pdf-image slide-media-img");return`<div class="${n} ${n}--image slide-media-block slide-media-container slide-list-media"><img alt="${rt(h[1])}" src="${h[2]}" class="${S}" /></div>`}if(/<video\b/i.test(u)){const w=((b=i==null?void 0:i.attributes)==null?void 0:b["custom-slides-autoplay"])==="true"||/autoplay/i.test(u),S=((m=i==null?void 0:i.attributes)==null?void 0:m["custom-slides-loop"])==="true"||/loop/i.test(u),x=((y=i==null?void 0:i.attributes)==null?void 0:y["custom-slides-muted"])==="true"||w||/muted/i.test(u),M=((g=i==null?void 0:i.attributes)==null?void 0:g["custom-slides-controls"])==="false",E=u.match(/\bsrc=["']([^"']+)["']/i),C=E?E[1]:"",D=['class="slide-video-player"'];M||D.push("controls"),w&&D.push("autoplay playsinline"),S&&D.push("loop"),x&&D.push("muted"),D.push('preload="metadata"'),C&&D.push(`src="${C}"`);const R=u.match(/<video[^>]*>([\s\S]*?)<\/video>/i);let N=R?R[1].trim():"";return!N&&C&&(N=`<source src="${C}" type="video/mp4" />您的浏览器不支持视频播放。`),`<div class="${n} ${n}--video slide-media-block slide-video-container slide-media-container" data-autoplay="${w?"true":"false"}" data-muted="${x?"true":"false"}"><video ${D.join(" ")}>${N}</video></div>`}const p=Gl(u,t,i);if(p)return r=!1,p;if(r){r=!1;const w=u.split(/\r?\n/).map(E=>E.trim()).filter(Boolean);if(w.length===1)return`<p class="slide-list-item-title">${at(w[0])}</p>`;const S=w[0],M=w.slice(1).map(E=>at(E)).join("<br/>");return`<p class="slide-list-item-title">${at(S)}</p>
<p class="slide-list-item-desc">${M}</p>`}return`<p class="slide-list-item-desc">${at(u)}</p>`}).filter(Boolean).join(`
`)}function fo(e){if(!e)return!1;if(e.type==="h"||e.type==="NodeHeading")return!0;const t=(e.rawMarkdown||e.content||"").trim();return/^#{1,6}\s+/.test(t)}function Kl(e,t){var r,l,c,u,d,h,p,b;const i=((r=e.frontmatter)==null?void 0:r.layout)||"default",s=(e.blocks||[]).filter(m=>m.slot!=="slot-divider-right"),a=i==="cover"?null:s.find(fo);if(i==="two-cols"){const m=s.some(K=>K.slot==="right");let y=[],g=[];if(m)y=s.filter(K=>K.slot!=="right"),g=s.filter(K=>K.slot==="right");else{const K=Math.ceil(s.length/2);y=s.slice(0,K),g=s.slice(K)}const w=K=>{const $=K.filter(V=>!!(V.rawMarkdown||V.content||"").trim());if($.length>0){const V=$[0],k=(V.rawMarkdown||V.content||"").trim();(Ti(V)||/^(?:[-*+]|\d+\.)\s+/.test(k))&&(V.rawMarkdown=Ln(V.rawMarkdown||V.content||""),V.content=V.rawMarkdown)}};w(y),w(g);const S=y.map(K=>ki(K,t)).join(`
`),x=g.map(K=>ki(K,t)).join(`
`),M=(t==null?void 0:t.twoColsWrapperClass)||"pdf-two-cols-wrapper layout-two-cols-grid",E=(l=e.frontmatter)!=null&&l.layoutClass?` ${e.frontmatter.layoutClass}`:"",C=(t==null?void 0:t.leftColClass)||"pdf-col pdf-col--left",D=(t==null?void 0:t.rightColClass)||"pdf-col pdf-col--right",N=`style="grid-template-columns: ${co((c=e.frontmatter)==null?void 0:c.layoutRatio,2)};"`;return`
      <div class="${M}${E}" ${N}>
        <div class="${C}">${S}</div>
        <div class="${D}">${x}</div>
      </div>
    `}if(i==="clover"||sn(i)){const m=i==="clover";let y=[];const g=s.filter(F=>F.slot==="header");if(g.length>0)y=g;else if(s.length>0){const F=s.find(H=>H.type==="h"&&(!H.slot||H.slot==="default"));F&&(y=[F])}const w=s.filter(F=>!y.includes(F));let S=2;if(m)S=4;else if(i==="three-cols-header")S=3;else if(i==="two-cols-header")S=2;else{let F=0;for(const H of w){const I=(H.slot||"").match(/^col-(\d+)$/i);I&&(F=Math.max(F,parseInt(I[1],10)))}if(F>=2)S=F;else if((u=e.frontmatter)!=null&&u.layoutRatio){const H=e.frontmatter.layoutRatio.trim();if(H.includes(":")){const I=H.split(":").map(A=>parseFloat(A.trim())).filter(A=>!isNaN(A)&&A>0);I.length>=2&&(S=I.length)}else{const I=H.split(/\s+/).filter(Boolean);I.length>=2&&(S=I.length)}}else w.length===1&&w[0].children&&w[0].children.length>=2&&(S=Math.min(6,w[0].children.length))}const x=Nl(w,S),M=w.some(F=>F.slot&&/^(?:col-\d+|left|right)$/i.test(F.slot)),E=i==="clover"||i==="two-cols-header"||i==="three-cols-header"||sn(i)&&M,C=F=>{const H=F.filter(A=>!!(A.rawMarkdown||A.content||"").trim());if(E&&H.length>0){const A=H[0],O=(A.rawMarkdown||A.content||"").trim();(Ti(A)||/^(?:[-*+]|\d+\.)\s+/.test(O))&&(A.rawMarkdown=Ln(A.rawMarkdown||A.content||""),A.content=A.rawMarkdown),A.isColFirst=!0}const I=E?H.find(fo):null;return H.map(A=>ki(A,{...t,extraClassName:A===I?"slides-col-first-heading-block":""})).join(`
`)},D=y.find(fo),R=y.map(F=>ki(F,{...t,extraClassName:F===D?"slides-page-first-heading-block":""})).join(`
`),N=m?"repeat(2, minmax(0, 1fr))":co((d=e.frontmatter)==null?void 0:d.layoutRatio,S),K=m?`style="grid-template-columns: ${N}; grid-template-rows: repeat(2, minmax(0, 1fr));"`:`style="grid-template-columns: ${N};"`,$=[m?"layout-clover-container":"layout-cols-header-container",S===2?"layout-two-cols-header-container":"",S===3?"layout-three-cols-header-container":"",`layout-${i}-container`,E?"has-superblock-cols":""].filter(Boolean).join(" "),V=[m?"layout-clover-grid pdf-clover-wrapper":"layout-cols-wrapper layout-cols-grid",S===2?"pdf-two-cols-wrapper layout-two-cols-grid":"",S===3?"pdf-three-cols-wrapper layout-three-cols-grid":"",E?"has-superblock-cols":""].filter(Boolean).join(" "),k=x.map((F,H)=>{const I=H+1;return`<div class="${["pdf-col",S===2&&I===1?"pdf-col--left":"",S===2&&I===2?"pdf-col--right":"",`pdf-col--${I}`,`col-${I}`].filter(Boolean).join(" ")}">${C(F)}</div>`}).join(`
`);return`
      <div class="${$}">
        <div class="layout-header-section">${R}</div>
        <div class="${V}" ${K}>
          ${k}
        </div>
      </div>
    `}if(i==="image-right"||i==="image-left"){const m=i==="image-right",y=s.map(E=>ki(E,t)).join(`
`),g=((h=e.frontmatter)==null?void 0:h.image)||((p=e.frontmatter)==null?void 0:p.background)||"",w=`<div class="pdf-image-col" style="background-image:url('${rt(g)}');background-size:cover;background-position:center;background-repeat:no-repeat;width:100%;height:100%;position:relative;overflow:hidden;"><img src="${rt(g)}" style="width:100%;height:100%;object-fit:cover;object-position:center;display:block;" onerror="this.style.display='none'" alt="Slide cover" /></div>`,S=`<div class="pdf-content-col" style="padding:48px 56px;display:flex;flex-direction:column;justify-content:flex-start;height:100%;box-sizing:border-box;overflow-y:auto;">${y}</div>`,x=m?`${S}
${w}`:`${w}
${S}`;return`
      <div class="layout-image-cols-grid" style="display:grid;grid-template-columns:${co((b=e.frontmatter)==null?void 0:b.layoutRatio,2)};grid-template-rows:100%;width:100%;height:100%;position:absolute;top:0;left:0;right:0;bottom:0;box-sizing:border-box;">
        ${x}
      </div>
    `}return i==="fact"?`<div class="layout-fact-container">${s.map(y=>ki(y,t)).join(`
`)}</div>`:i==="cover"?`<div class="layout-cover-container">${s.map(y=>ki(y,t)).join(`
`)}</div>`:s.map(m=>ki(m,{...t,extraClassName:m===a?"slides-page-first-heading-block":""})).join(`
`)}function rt(e){return e?e.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&#039;"):""}function Gm(e){if(!e||e.trim()===""||e.trim()==="all")return"all";const t=new Set,i=e.split("|");for(const n of i){const s=n.trim();if(s==="all")return"all";if(s.includes("-")){const[o,a]=s.split("-"),r=parseInt(o,10),l=parseInt(a,10);if(!isNaN(r)&&!isNaN(l))for(let c=Math.min(r,l);c<=Math.max(r,l);c++)t.add(c)}else{const o=parseInt(s,10);isNaN(o)||t.add(o)}}return t}const Km=new Set(["kbd","mark","sub","sup","span","a","br","b","i","u","s","del","em","strong","code","small","abbr","ruby","rt","rp","v-mark","img","video","source","picture"]);function at(e){if(!e)return"";const t=Ol(e),i=[],n=t.replace(/<\/?([a-zA-Z0-9_-]+)(?:\s+[^<>]*)?\/?>/g,(o,a)=>{const r=a.toLowerCase();if(!Km.has(r)||/on\w+\s*=|javascript:/i.test(o))return o;if(r==="v-mark"){const l=o.match(/type=["']?([a-zA-Z-]+)["']?/),c=l?l[1]:"circle";return o.startsWith("</")?i.push("</mark>"):i.push(`<mark class="v-mark v-mark--${c}">`),`%%SAFE_HTML_${i.length-1}%%`}return i.push(o),`%%SAFE_HTML_${i.length-1}%%`});let s=rt(n);return s=s.replace(/\(\(([0-9a-zA-Z-]+)(?:\s*(?:&#039;([^&#]*)&#039;|&quot;([^&]*)&quot;|'([^']*)'|"([^"]*)"|([^\)]+?)))?\s*\)\)/g,(o,a,r,l,c,u,d)=>{const p=(r??l??c??u??d??"").trim()||`Ref(${a.slice(0,8)})`;return`<a href="siyuan://blocks/${a}" data-ref-id="${a}" class="slides-ref-tag">🔗 ${p}</a>`}),s=s.replace(/\$([^$\n]+)\$/g,'<span class="katex-inline font-math"><em>$1</em></span>'),s=s.replace(/!\[(.*?)\]\((.*?)\)/g,(o,a,r)=>{const c=/\.gif(?:\?|$)/i.test(r)?"slide-inline-img list-item-gif":"slide-inline-img";return`<img alt="${a}" src="${r}" class="${c}" />`}),s=s.replace(/\[(.*?)\]\((.*?)\)/g,(o,a,r)=>{if(r.startsWith("siyuan://blocks/")){const l=r.replace("siyuan://blocks/","").split("?")[0];return`<a href="${r}" data-ref-id="${l}" class="slides-ref-tag">🔗 ${a}</a>`}return`<a href="${r}" target="_blank" rel="noopener noreferrer" class="slides-link">${a}</a>`}),s=s.replace(/(^|[\s(])(siyuan:\/\/blocks\/([0-9a-zA-Z-]+)(?:\?[^\s\)]*)?)/g,(o,a,r,l)=>`${a}<a href="${r}" data-ref-id="${l}" class="slides-ref-tag">🔗 ${r}</a>`),s=s.replace(/\*\*(.*?)\*\*/g,"<strong>$1</strong>"),s=s.replace(/\*(.*?)\*/g,"<em>$1</em>"),s=s.replace(/~~(.*?)~~/g,"<del>$1</del>"),s=s.replace(/`([^`]+)`/g,"<code>$1</code>"),s=s.replace(/%%SAFE_HTML_(\d+)%%/g,(o,a)=>{const r=parseInt(a,10);return i[r]||""}),s}function qm(e,t="pdf-table"){if(e.length<2)return"";const i=e.map(l=>l.trim().replace(/^\|/,"").replace(/\|$/,"").split("|").map(c=>c.trim())),n=i[0];let s=[],o=1;e.length>=2&&i[1].every(l=>/^:?-+:?$/.test(l))&&(s=i[1].map(l=>l.startsWith(":")&&l.endsWith(":")?"center":l.endsWith(":")?"right":"left"),o=2);const a=`<thead><tr>${n.map((l,c)=>`<th${s[c]?` style="text-align: ${s[c]}"`:""}>${at(l)}</th>`).join("")}</tr></thead>`,r=i.slice(o).map(l=>`<tr>${l.map((c,u)=>`<td${s[u]?` style="text-align: ${s[u]}"`:""}>${at(c)}</td>`).join("")}</tr>`).join("");return`<table class="${t}">${a}<tbody>${r}</tbody></table>`}function po(e){return String(e||"").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;")}function la(e,t="ts"){if(!e)return"";if(e.trim().startsWith("//"))return`<span class="token-comment">${po(e)}</span>`;const i=[];function n(o,a){return i.push(`<span class="${o}">${po(a)}</span>`),`__TOK_${i.length-1}__`}let s=e.replace(/(['"`])(.*?)\1/g,(o,a,r)=>n("token-string",`${a}${r}${a}`));return s=s.replace(/\b(import|export|from|const|let|var|function|return|default|type|interface|class|new|async|await)\b/g,o=>n("token-keyword",o)),s=s.replace(/\b(computed|ref|number|string|boolean|void|Array)\b/g,o=>n("token-type",o)),s=s.replace(/\b(\d+)\b/g,o=>n("token-number",o)),s=po(s),s=s.replace(/__TOK_(\d+)__/g,(o,a)=>i[parseInt(a,10)]||""),s}function Ym(e,t){if(!e)return null;const i=e.frontmatter||{};if(i.hideInToc===!0||i.hideInToc==="true")return null;let n=(i.title||"").trim(),s=i.level?parseInt(i.level,10):0;if(!n){const o=e.blocks||[];for(const a of o){const l=(a.rawMarkdown||a.content||"").trim().match(/^(#{1,6})\s+(.*)$/);if(l){s||(s=l[1].length),n=l[2].trim();break}}}return n?((!s||isNaN(s))&&(s=1),{pageIndex:e.pageIndex||t,title:n,level:s}):null}function Zm(e,t=1,i={}){const n=i.minDepth!==void 0?Number(i.minDepth):1,s=i.maxDepth!==void 0?Number(i.maxDepth):1/0,o=[];Array.isArray(e)&&e.forEach((c,u)=>{const d=Ym(c,u+1);d&&o.push(d)});const a=[];let r=null;for(const c of o){const u={...c,active:c.pageIndex===t,hasActiveChild:!1,children:[]};c.level===1||a.length===0?(a.push(u),r=u):r?(u.active&&(r.hasActiveChild=!0),r.children.push(u)):a.push(u)}function l(c,u=1){if(u>s)return[];const d=[];for(const h of c){const p=l(h.children,u+1);u>=n?d.push({...h,children:p}):d.push(...p)}return d}return l(a,1)}function Jm(e,t=1,i={}){const n=Zm(e,t,i),s=i.columns?Number(i.columns):1,o=s>1?` style="column-count: ${s};"`:"",a=i.textSm?" text-sm":"";function r(c,u=1){if(!c||c.length===0)return"";const d=`slides-toc-list slides-toc-list-level-${u}`,h=c.map(p=>{const b=p.active?" slides-toc-item-active":p.hasActiveChild?" slides-toc-item-parent-active":"",m=p.children&&p.children.length>0?r(p.children,u+1):"";let y=at(p.title);return y.includes("LaTeX")&&(y=y.replace(/\$\\LaTeX\$/g,'<span class="font-math">L<sup>A</sup>T<sub>E</sub>X</span>')),`
        <li class="slides-toc-item${b}" data-page="${p.pageIndex}">
          <a class="slides-toc-link" href="javascript:void(0)">
            <span class="slides-toc-title">${y}</span>
          </a>
          ${m}
        </li>
      `}).join("");return`<ol class="${d}">${h}</ol>`}const l=r(n,1);return`<div class="slides-toc${a}"${o}>${l}</div>`}function ki(e,t){var M,E,C,D,R,N,K,$,V,k,F,H;let i="",n="",s="";const o=[];(M=e.motion)!=null&&M.preset&&e.motion.preset!=="none"&&(i=` slides-motion-${e.motion.preset.toLowerCase()}`,typeof e.motion.duration=="number"&&e.motion.duration>0&&o.push(`--motion-duration:${e.motion.duration}ms`),typeof e.motion.delay=="number"&&e.motion.delay>0&&o.push(`--motion-delay:${e.motion.delay}ms`));const a=((E=e.attributes)==null?void 0:E.style)||"";a&&(o.push(a),s=" slide-styled-block"),o.length>0&&(n=` style="${rt(o.join(";"))}"`);const r=(t==null?void 0:t.containerClassName)||"pdf-block",l=t!=null&&t.extraClassName?` ${t.extraClassName}`:"",c=t!=null&&t.blockClassResolver?t.blockClassResolver(e):"",u=c?` ${c}`:"",d=`${r}${i}${s}${l}${u}`,h=(e.rawMarkdown||e.content||"").trim();if(!h)return`<div class="${d}"${n}></div>`;if(h.includes('class="slides-block-ref"')||h.includes('class="slides-ref-tag"'))return`<div class="${d}"${n}>${h}</div>`;if(h.startsWith("$$")&&h.endsWith("$$")){const I=h.slice(2,-2).trim();return`<div class="${d} katex-display-container"${n}><div class="katex-display font-math"><em>${rt(I)}</em></div></div>`}const p=h.match(/^(#{1,6})\s+(.*)$/);if(p){const I=p[1].length,A=at(p[2]),ne=!!(e.isColFirst||e.type==="i"&&((C=t==null?void 0:t.extraClassName)!=null&&C.includes("slides-col-first-heading-block")))?' class="slide-list-item-title"':"";return`<div class="${d}"${n}><h${I}${ne}>${A}</h${I}></div>`}if(h.startsWith(":::")){const I=h.split(`
`),O=I[0].replace(/^:::\s*/,"").trim()||"info",ne=I.slice(1,I[I.length-1].startsWith(":::")?-1:void 0).join(`
`),G=(t==null?void 0:t.calloutClassName)||"pdf-callout";return`<div class="${d}"${n}><div class="${G} ${G}--${O}"><div class="${G}-title">${O.toUpperCase()}</div><div class="${G}-body">${at(ne)}</div></div></div>`}if(h.startsWith("<<<")){const O=`// Inside ./snippets/external.ts
export function emptyArray<T>(length: number) {
  return Array.from<T>({ length })
}`.split(`
`).map((se,re)=>`<span class="code-line shiki-focus"><span class="line-no">${re+1}</span><span class="line-content">${la(se,"ts")}</span></span>`).join(`
`),ne=(t==null?void 0:t.codeClassName)||"pdf-code shiki-container",G=((D=e.attrs)==null?void 0:D["custom-slides-max-height"])||((R=e.attributes)==null?void 0:R["custom-slides-max-height"])||e.maxHeight||"",q=G?/^\d+$/.test(String(G).trim())?`${String(G).trim()}px`:String(G).trim():"",ce=q?` style="max-height:${rt(q)};overflow-y:auto;"`:"";return`<div class="${d}"${n}><pre class="${ne}"${ce}><span class="lang-badge">TS</span><code>${O}</code></pre></div>`}if(h.startsWith("<style")||h.startsWith("<!-- Inline style -->")||h.startsWith(`<!--
Notes`))return"";if(h.startsWith("```")){const I=h.split(`
`),A=I[0].slice(3).trim(),O=A.match(/^([^\s{\[]+)/),ne=O?O[1]:"",G=A.match(/\[([^\]]+)\]/),q=G?G[1]:"",ce=A.includes("twoslash"),se=e.shikiLines||((N=A.match(/\{([^}]+)\}/))==null?void 0:N[1])||"",re=Gm(se),Se=I.length>2?I[I.length-1]==="```"?I.slice(1,-1):I.slice(1):[h.slice(3).replace(/```$/,"")],Ie=(t==null?void 0:t.codeClassName)||"pdf-code shiki-container",_e=q?`${Ie} has-filename`:Ie,pe=re!=="all",X=Se.map((W,_)=>{const T=_+1,Y=re==="all"||re.has(T)?"code-line shiki-focus":pe?"code-line shiki-dimmed":"code-line";let z=(t==null?void 0:t.highlight)===!0?la(W,ne):rt(W);return ce&&W.includes("doubled.value = 2")?(z=z.replace(/(\bvalue\b)/,'<span class="twoslash-error-wavy">$1</span>'),`<span class="${Y}"><span class="line-no">${T}</span><span class="line-content">${z}</span></span>
<div class="twoslash-popup-error"><span style="color:#ef4444;font-weight:bold;margin-right:4px;">✕</span> Cannot assign to 'value' because it is a read-only property.</div>`):`<span class="${Y}"><span class="line-no">${T}</span><span class="line-content">${z}</span></span>`}).join(`
`),Q=ne?`<span class="lang-badge">${rt(ne)}</span>`:"",L=q?`<span class="code-filename">${rt(q)}</span>`:"",j=((K=e.attrs)==null?void 0:K["custom-slides-max-height"])||(($=e.attributes)==null?void 0:$["custom-slides-max-height"])||e.maxHeight||"",v=j?/^\d+$/.test(String(j).trim())?`${String(j).trim()}px`:String(j).trim():"",U=v?` style="max-height:${rt(v)};overflow-y:auto;"`:"";return`<div class="${d}"${n}><pre class="${_e}"${U}>${L}${Q}<code>${X}</code></pre></div>`}if(h.includes("|")&&h.split(`
`).filter(I=>I.trim().startsWith("|")).length>=2){const I=h.split(`
`).filter(O=>O.trim().startsWith("|")),A=qm(I,t==null?void 0:t.tableClassName);return`<div class="${d}"${n}>${A}</div>`}if(h.startsWith("> ")){const I=(t==null?void 0:t.quoteClassName)||"pdf-quote";return`<div class="${d}"${n}><blockquote class="${I}"><p>${at(h.slice(2))}</p></blockquote></div>`}const b=/<video\b/i.test(h)||e.type==="video"||e.type==="NodeVideo",m=/^(\s*)([-*+]|\d+\.)\s+/m.test(h),y=/(?:^|\n)\s*#{1,6}\s+/.test(h);if(b&&!m&&!y&&!h.includes(`
`)){const I=((V=e.attributes)==null?void 0:V["custom-slides-autoplay"])==="true"||/autoplay/i.test(h),A=((k=e.attributes)==null?void 0:k["custom-slides-loop"])==="true"||/loop/i.test(h),O=((F=e.attributes)==null?void 0:F["custom-slides-muted"])==="true"||I||/muted/i.test(h),ne=((H=e.attributes)==null?void 0:H["custom-slides-controls"])==="false",G=h.match(/\bsrc=["']([^"']+)["']/i),q=G?G[1]:"",ce=['class="slide-video-player"'];ne||ce.push("controls"),I&&(ce.push("autoplay"),ce.push("playsinline")),A&&ce.push("loop"),O&&ce.push("muted"),ce.push('preload="auto"'),q&&ce.push(`src="${q}"`);const se=h.match(/<video[^>]*>([\s\S]*?)<\/video>/i);let re=se?se[1].trim():"";return!re&&q&&(re=`<source src="${q}" type="video/mp4" />您的浏览器不支持视频播放。`),`<div class="${d} ${d}--video slide-media-block slide-video-container slide-media-container" data-autoplay="${I?"true":"false"}" data-muted="${O?"true":"false"}"${n}><video ${ce.join(" ")}>${re}</video></div>`}const g=h.match(/^!\[(.*?)\]\((.*?)\)$/);if(g){const I=(t==null?void 0:t.imageClassName)||"pdf-image slide-media-img";return`<div class="${d} ${d}--image slide-media-block slide-media-container"${n}><img alt="${rt(g[1])}" src="${g[2]}" class="${I}" /></div>`}const w=Gl(h,t,e);if(w)return`<div class="${d} pdf-list-item"${n}>${w}</div>`;if(/<(?:Toc|toc)\b/i.test(h)&&!h.startsWith("```")){const I=h.match(/minDepth=["']?(\d+)["']?/i),A=h.match(/maxDepth=["']?(\d+)["']?/i),O=h.match(/columns=["']?(\d+)["']?/i),ne=(t==null?void 0:t.allSlides)||[];return`<div class="${d}"${n}>${Jm(ne,(t==null?void 0:t.currentPageIndex)||1,{minDepth:I?parseInt(I[1],10):1,maxDepth:A?parseInt(A[1],10):1/0,columns:O?parseInt(O[1],10):1,textSm:h.includes("text-sm")})}</div>`}if(h.includes(`
`)||y){const I=Vm(h,t,e);if(I)return`<div class="${d}"${n}>${I}</div>`}const x=!!e.isColFirst?' class="slide-list-item-title"':"";return`<div class="${d}"${n}><p${x}>${at(h)}</p></div>`}function Xm(e){return`
    ${On(e)}

    :root {
      --slide-bg: #ffffff;
      --slide-text: #1a1a1a;
      --slide-accent: #3b82f6;
      --slide-font: system-ui, -apple-system, sans-serif;
    }
    [data-theme="dark"] {
      --slide-bg: #121214;
      --slide-text: #e2e8f0;
      --slide-accent: #60a5fa;
    }

    /* 1. 默认科技主题 Default */
    [data-slides-theme="default"],
    .slides-theme-default {
      --slide-font: system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "PingFang SC", "Microsoft YaHei", sans-serif;
      --slide-accent: #10b981;
    }
    [data-theme="light"][data-slides-theme="default"],
    [data-theme="light"] .slides-theme-default {
      --slide-bg: #ffffff;
      --slide-text: #1e293b;
      --slide-accent: #059669;
    }
    [data-theme="dark"][data-slides-theme="default"],
    [data-theme="dark"] .slides-theme-default {
      --slide-bg: #121214;
      --slide-text: #e2e8f0;
      --slide-accent: #34d399;
    }
    .slides-theme-default .layout-cover h1,
    .slides-theme-default .layout-cover .slide-block h1 {
      font-size: 3.8rem !important;
      font-weight: 800 !important;
      line-height: 1.15 !important;
      letter-spacing: -0.025em !important;
      margin-bottom: 18px !important;
      background: linear-gradient(135deg, #10b981, #06b6d4) !important;
      -webkit-background-clip: text !important;
      -webkit-text-fill-color: transparent !important;
    }
    .slides-theme-default .layout-cover h2,
    .slides-theme-default .layout-cover .slide-block h2 {
      font-size: 1.85rem !important;
      font-weight: 600 !important;
      opacity: 0.85 !important;
      margin-bottom: 12px !important;
    }
    .slides-theme-default .layout-cover p,
    .slides-theme-default .layout-cover .slide-block p {
      font-size: 1.45rem !important;
      line-height: 1.5 !important;
      opacity: 0.85 !important;
    }

    /* 2. 优雅衬线主题 Seriph */
    [data-slides-theme="seriph"],
    .slides-theme-seriph {
      --slide-font: "PT Serif", "Charter", "Georgia", "Cambria", "Times New Roman", "Source Han Serif SC", "Noto Serif SC", "Songti SC", "SimSun", serif;
      --slide-accent: #b45309;
      letter-spacing: 0.015em;
    }
    [data-theme="light"][data-slides-theme="seriph"],
    [data-theme="light"] .slides-theme-seriph {
      --slide-bg: #fdfbf7;
      --slide-text: #2a2521;
      --slide-accent: #b45309;
    }
    [data-theme="dark"][data-slides-theme="seriph"],
    [data-theme="dark"] .slides-theme-seriph {
      --slide-bg: #1c1a17;
      --slide-text: #e8e3d9;
      --slide-accent: #f59e0b;
    }
    .slides-theme-seriph,
    .slides-theme-seriph .slide-content {
      font-family: var(--slide-font) !important;
      line-height: 1.72;
    }
    .slides-theme-seriph h1,
    .slides-theme-seriph h2,
    .slides-theme-seriph h3 {
      font-family: var(--slide-font) !important;
      letter-spacing: 0.025em;
      font-weight: 700;
    }
    .slides-theme-seriph .layout-cover h1 {
      background: none !important;
      -webkit-background-clip: initial !important;
      -webkit-text-fill-color: initial !important;
      color: var(--slide-accent) !important;
      font-size: 3.4rem !important;
      border-bottom: 2px solid var(--slide-accent);
      display: inline-block;
      padding-bottom: 10px;
    }

    /* 3. 极简发布会主题 Apple Basic */
    [data-slides-theme="apple-basic"],
    .slides-theme-apple-basic {
      --slide-font: -apple-system, "SF Pro Display", "SF Pro Text", BlinkMacSystemFont, "PingFang SC", "Helvetica Neue", sans-serif;
      --slide-accent: #0071e3;
    }
    [data-theme="light"][data-slides-theme="apple-basic"],
    [data-theme="light"] .slides-theme-apple-basic {
      --slide-bg: #ffffff;
      --slide-text: #1d1d1f;
      --slide-accent: #0071e3;
    }
    [data-theme="dark"][data-slides-theme="apple-basic"],
    [data-theme="dark"] .slides-theme-apple-basic {
      --slide-bg: #000000;
      --slide-text: #f5f5f7;
      --slide-accent: #2997ff;
    }
    .slides-theme-apple-basic,
    .slides-theme-apple-basic .slide-content {
      font-family: var(--slide-font) !important;
    }
    .slides-theme-apple-basic h1,
    .slides-theme-apple-basic h2,
    .slides-theme-apple-basic h3 {
      letter-spacing: -0.035em;
      font-weight: 800;
    }
    .slides-theme-apple-basic .layout-cover h1 {
      background: none !important;
      -webkit-background-clip: initial !important;
      -webkit-text-fill-color: initial !important;
      color: var(--slide-text) !important;
      font-size: 3.8rem !important;
      letter-spacing: -0.04em !important;
    }
    .slides-theme-apple-basic .layout-cover p {
      color: #86868b !important;
      font-size: 1.35rem !important;
    }

    * { box-sizing: border-box; margin: 0; padding: 0; }
    html, body {
      width: 100%; height: 100%; overflow: hidden;
      background: #0f1115; font-family: var(--slide-font);
      display: flex; justify-content: center; align-items: center;
    }
    #app { width: 100%; height: 100%; position: relative; overflow: hidden; }
    .slide-viewport {
      position: absolute; left: 50%; top: 50%;
      background: var(--slide-bg); color: var(--slide-text);
      box-shadow: 0 10px 30px rgba(0,0,0,0.5); border-radius: 8px; overflow: hidden;
      display: flex; flex-direction: column; flex-shrink: 0;
      transform: translate(-50%, -50%) scale(var(--slides-slide-scale, 1));
      transform-origin: center center; will-change: transform;
      transition: background 0.3s ease, color 0.3s ease, border-radius 0.2s ease, box-shadow 0.2s ease;
    }
    :fullscreen .slide-viewport, .is-fullscreen .slide-viewport {
      border-radius: 0 !important; box-shadow: none !important;
    }
    .slide-content {
      position: relative;
      width: 100%;
      height: 100%;
      min-height: 100%;
      flex: 1 1 0%;
      padding: var(--slides-padding-y, 32px) var(--slides-padding-x, 48px);
      display: flex;
      flex-direction: column;
      overflow: hidden;
      box-sizing: border-box;
    }

    /* 间距预设风格 */
    .slide-content.spacing-compact,
    .slide-viewport[data-spacing="compact"] .slide-content,
    [data-slides-spacing="compact"] {
      --slides-padding-y: 20px;
      --slides-padding-x: 36px;
      --slides-header-gap: 10px;
      --slides-title-margin-bottom: 6px;
    }
    .slide-content.spacing-normal,
    .slide-viewport[data-spacing="normal"] .slide-content,
    [data-slides-spacing="normal"] {
      --slides-padding-y: 32px;
      --slides-padding-x: 48px;
      --slides-header-gap: 16px;
      --slides-title-margin-bottom: 10px;
    }
    .slide-content.spacing-loose,
    .slide-viewport[data-spacing="loose"] .slide-content,
    [data-slides-spacing="loose"] {
      --slides-padding-y: 48px;
      --slides-padding-x: 56px;
      --slides-header-gap: 24px;
      --slides-title-margin-bottom: 16px;
    }

    .layout-cover { justify-content: center; align-items: center; text-align: center; }
    .layout-cover h1, .layout-cover .slide-block h1 { font-size: 3.8rem !important; font-weight: 800 !important; line-height: 1.15 !important; letter-spacing: -0.025em !important; margin-bottom: 16px !important; }
    .layout-cover h2, .layout-cover .slide-block h2 { font-size: 1.85rem !important; font-weight: 600 !important; opacity: 0.85 !important; margin-bottom: 12px !important; }
    .layout-cover p, .layout-cover .slide-block p { font-size: 1.45rem !important; line-height: 1.5 !important; opacity: 0.85 !important; }
    .two-cols-left, .two-cols-right { min-width: 0; width: 100%; display: flex; flex-direction: column; box-sizing: border-box; overflow-wrap: break-word; word-break: break-word; }
    .pdf-two-cols-wrapper,
    .layout-two-cols-grid,
    .layout-cols-wrapper,
    .layout-cols-grid {
      display: grid;
      grid-template-columns: var(--slide-grid-cols, minmax(0, 1fr) minmax(0, 1fr));
      grid-template-rows: minmax(0, 1fr) !important;
      gap: 32px;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      overflow: hidden !important;
    }
    .layout-cols-header-container,
    .layout-two-cols-header-container,
    .layout-three-cols-header-container,
    .layout-clover-container {
      display: flex;
      flex-direction: column;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      overflow: hidden !important;
    }
    .layout-header-section {
      width: 100%;
      margin-bottom: var(--slides-header-gap, 16px) !important;
      flex-shrink: 0;
    }
    .layout-header-section h1,
    .layout-header-section h2,
    .layout-header-section h3 {
      margin-bottom: var(--slides-title-margin-bottom, 10px) !important;
    }
    .pdf-three-cols-wrapper,
    .layout-three-cols-grid {
      display: grid;
      grid-template-columns: var(--slide-grid-cols, minmax(0, 1fr) minmax(0, 1fr) minmax(0, 1fr));
      grid-template-rows: minmax(0, 1fr) !important;
      gap: 24px;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      box-sizing: border-box;
      overflow: hidden !important;
    }
    .pdf-clover-wrapper,
    .layout-clover-grid {
      display: grid;
      grid-template-columns: repeat(2, minmax(0, 1fr)) !important;
      grid-template-rows: repeat(2, minmax(0, 1fr)) !important;
      gap: 20px;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      box-sizing: border-box;
      overflow: hidden !important;
    }
    .layout-clover-grid .pdf-col {
      background: transparent !important;
      border: none !important;
      box-shadow: none !important;
    }
    .pdf-col {
      display: flex;
      flex-direction: column;
      gap: 14px;
      min-width: 0;
      width: 100%;
      max-width: 100%;
      height: 100%;
      max-height: 100%;
      min-height: 0;
      justify-content: flex-start;
      box-sizing: border-box;
      overflow: hidden;
      overflow-wrap: break-word;
      word-break: break-word;
      white-space: normal;
    }
    .pdf-col * {
      overflow-wrap: break-word;
      word-break: break-word;
      box-sizing: border-box;
    }
    /* 表头多栏内超级块子块首个列表项去圆点后居中显示标题/首行文本 (仅在存在超级块分栏时生效) */
    .has-superblock-cols .pdf-col > *:first-child .slide-list-item-title,
    .has-superblock-cols .pdf-col > *:first-child :is(h1, h2, h3, h4, h5, h6),
    .has-superblock-cols .pdf-col > *:first-child p.slide-list-item-title,
    .has-superblock-cols .pdf-col > *:first-child p:first-of-type,
    .has-superblock-cols .pdf-col > *:first-child p:first-child,
    .has-superblock-cols .pdf-col > *:first-child :is(ul, ol) > li:first-child,
    .has-superblock-cols .pdf-col > *:first-child .slide-list > .slide-list-item:first-child,
    .has-superblock-cols .pdf-col > *:first-child .pdf-list > li:first-child,
    .has-superblock-cols .slides-col-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    .has-superblock-cols .slides-col-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      list-style: none !important;
      list-style-type: none !important;
      text-align: center !important;
      margin-left: 0 !important;
      padding-left: 0 !important;
      width: 100% !important;
    }

    /* 彻底清除首个列表项的原生圆点 Marker (仅在存在超级块分栏时生效) */
    .has-superblock-cols .pdf-col > *:first-child :is(ul, ol) > li:first-child::marker {
      content: "" !important;
      display: none !important;
    }

    /* 确保首个列表项内部内联与块级元素居中 (仅在存在超级块分栏时生效) */
    .has-superblock-cols .pdf-col > *:first-child :is(ul, ol) > li:first-child * {
      text-align: center !important;
    }

    /* 栏内说明段落与列表项：左对齐，自然阅读排版 */
    .has-superblock-cols .pdf-col .slide-list-item-desc,
    .has-superblock-cols .pdf-col li:not(:first-child) {
      text-align: left !important;
    }

    /* 全局特定标题大小规范化 (除封面外页首首个标题按 H2 1.7rem，表头多栏内首个标题按 H3 1.3rem) */
    [data-normalize-headings="true"] .slides-page-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .slides-page-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .slide-content:not(.layout-cover) > :is(.pdf-block, .slide-block):first-child :is(h1, h2, h3, h4, h5, h6),
    [data-normalize-headings="true"] .slide-content:not(.layout-cover) > .layout-header-section :is(.pdf-block, .slide-block):first-child :is(h1, h2, h3, h4, h5, h6),
    [data-normalize-headings="true"] .slide-content:not(.layout-cover) > :not(.layout-cols-wrapper):not(.pdf-two-cols-wrapper):not(.layout-image-cols-grid):first-child :is(h1, h2, h3, h4, h5, h6) {
      font-size: 1.7rem !important;
      font-weight: 600 !important;
      line-height: 1.25 !important;
      margin-bottom: 10px !important;
    }

    [data-normalize-headings="true"] .has-superblock-cols .slides-col-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .has-superblock-cols .slides-col-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .has-superblock-cols .pdf-col > *:first-child :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      font-size: 1.3rem !important;
      font-weight: 600 !important;
      line-height: 1.3 !important;
      margin-bottom: 8px !important;
      text-align: center !important;
    }

    /* 图左与图右版式标题完全保留用户原始字号与默认排版，不进行任何固定大小规范化 */
    [data-normalize-headings="true"] :is(.layout-image-left, .layout-image-right, .image-left-content, .image-right-content) :is(h1, h2, h3, h4, h5, h6) {
      text-align: left !important;
    }
    .pdf-col pre,
    .two-cols-left pre,
    .two-cols-right pre,
    .image-right-content pre,
    .image-left-content pre {
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      overflow-x: hidden !important;
      overflow-y: auto !important;
      max-width: 100% !important;
      box-sizing: border-box !important;
    }
    .slide-content.layout-image-right, .slide-content.layout-image-left {
      padding: 0;
      display: grid;
      grid-template-columns: var(--slide-grid-cols, minmax(0, 1fr) minmax(0, 1fr));
      grid-template-rows: 100%;
      width: 100%;
      height: 100%;
      position: absolute;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      box-sizing: border-box;
    }
    .image-right-content, .image-left-content {
      padding: 44px 50px;
      display: flex;
      flex-direction: column;
      justify-content: flex-start;
      overflow-y: auto;
      width: 100%;
      height: 100%;
      box-sizing: border-box;
    }
    .image-right-img-container, .image-left-img-container {
      width: 100%;
      height: 100%;
      overflow: hidden;
      position: relative;
      background: #18181b;
      display: flex;
      align-items: center;
      justify-content: center;
    }
    .image-right-img, .image-left-img {
      width: 100%;
      height: 100%;
      object-fit: cover;
      object-position: center;
      display: block;
    }
    .slide-block { margin-bottom: 14px; line-height: 1.6; }
    .slide-block h1 { font-size: 2.2rem; margin-bottom: 12px; }
    .slide-block h2 { font-size: 1.7rem; margin-bottom: 10px; }
    .slide-block p { font-size: 1.15rem; }
    .slide-block ul, .slide-block ol, .pdf-list {
      padding-left: 28px;
      margin: 8px 0;
      display: flex;
      flex-direction: column;
      gap: 6px;
    }
    .slide-block li, .pdf-list li {
      font-size: 1.15rem;
      line-height: 1.6;
    }
    .pdf-task-item {
      list-style: none;
      margin-left: -20px;
      display: flex;
      align-items: center;
      gap: 8px;
    }
    .pdf-task-item input[type="checkbox"] {
      width: 1.15em;
      height: 1.15em;
      cursor: pointer;
    }

    /* 两栏与三栏及多栏（超级块分栏）布局：紧凑自然行距，子列表保留圆点与层级缩进 */
    .layout-two-cols ul,
    .layout-cols-header ul,
    .layout-two-cols-header ul,
    .layout-three-cols ul,
    .layout-three-cols-header ul,
    .two-cols-left ul,
    .two-cols-right ul,
    .three-cols-col ul,
    .col ul,
    .pdf-col ul,
    .layout-two-cols-grid .pdf-list,
    .layout-three-cols-grid .pdf-list,
    .layout-cols-grid .pdf-list,
    .layout-two-cols-grid .pdf-list--unordered,
    .layout-three-cols-grid .pdf-list--unordered,
    .layout-cols-grid .pdf-list--unordered {
      list-style: disc !important;
      list-style-type: disc !important;
      padding-left: 1.25em !important;
      margin-left: 0 !important;
      margin-top: 0 !important;
      margin-bottom: 8px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: block !important;
    }

    .layout-two-cols ol,
    .layout-cols-header ol,
    .layout-two-cols-header ol,
    .layout-three-cols ol,
    .layout-three-cols-header ol,
    .two-cols-left ol,
    .two-cols-right ol,
    .three-cols-col ol,
    .col ol,
    .pdf-col ol,
    .layout-two-cols-grid .pdf-list--ordered,
    .layout-three-cols-grid .pdf-list--ordered,
    .layout-cols-grid .pdf-list--ordered {
      list-style: decimal !important;
      list-style-type: decimal !important;
      padding-left: 1.25em !important;
      margin-left: 0 !important;
      margin-top: 0 !important;
      margin-bottom: 8px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: block !important;
    }

    .layout-two-cols li,
    .layout-cols-header li,
    .layout-two-cols-header li,
    .layout-three-cols li,
    .layout-three-cols-header li,
    .two-cols-left li,
    .two-cols-right li,
    .three-cols-col li,
    .col li,
    .pdf-col li,
    .pdf-col .pdf-list-item {
      padding-left: 0.2em !important;
      margin-left: 0 !important;
      margin-bottom: 6px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: list-item !important;
      line-height: 1.6 !important;
    }

    .layout-two-cols ul ul,
    .layout-three-cols ul ul,
    .three-cols-col ul ul,
    .pdf-col ul ul {
      list-style: circle !important;
      list-style-type: circle !important;
      padding-left: 1.25em !important;
      margin-top: 4px !important;
      margin-bottom: 4px !important;
    }

    /* 列表项内嵌标题与说明排版 */
    .slide-list-item-title,
    .pdf-list li > h1,
    .pdf-list li > h2,
    .pdf-list li > h3,
    .pdf-list li > h4,
    .pdf-list li > h5,
    .pdf-list li > h6,
    li > h1.slide-list-item-title,
    li > h2.slide-list-item-title,
    li > h3.slide-list-item-title,
    li > h4.slide-list-item-title {
      margin-top: 2px !important;
      margin-bottom: 6px !important;
      line-height: 1.35 !important;
      font-weight: 700 !important;
    }
    .pdf-list li > h1, li > h1.slide-list-item-title { font-size: 1.6rem !important; }
    .pdf-list li > h2, li > h2.slide-list-item-title { font-size: 1.4rem !important; }
    .pdf-list li > h3, li > h3.slide-list-item-title { font-size: 1.22rem !important; }
    .pdf-list li > h4, li > h4.slide-list-item-title { font-size: 1.1rem !important; }

    /* 全局特定标题大小规范化后置强力锁定 (防止被列表项内部字号覆盖) */
    [data-normalize-headings="true"] .slides-page-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .slides-page-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      font-size: 1.7rem !important;
      font-weight: 600 !important;
      line-height: 1.25 !important;
      margin-bottom: 10px !important;
    }
    [data-normalize-headings="true"] .slides-col-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .slides-col-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] :is(.layout-cols-wrapper, .pdf-two-cols-wrapper, .layout-cols-header-container, .layout-cols-grid) .pdf-col > *:first-child :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] :is(.two-cols-left, .two-cols-right, .pdf-col, .col) > *:first-child :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      font-size: 1.3rem !important;
      font-weight: 600 !important;
      line-height: 1.3 !important;
      margin-bottom: 8px !important;
      text-align: center !important;
    }
    /* 基础列表项前缀样式 */
    .slide-block ul,
    .slide-list--unordered,
    .pdf-list--unordered {
      list-style: disc !important;
      list-style-type: disc !important;
    }
    .slide-block ol,
    .slide-list--ordered,
    .pdf-list--ordered {
      list-style: decimal !important;
      list-style-type: decimal !important;
    }
    .slide-block li,
    .slide-list-item,
    .pdf-list-item,
    .pdf-list li {
      display: list-item !important;
    }

    /* 隐藏无序列表前缀标记 */
    [data-hide-unordered-markers="true"] :is(ul, .slide-list, .slide-list--unordered, .pdf-list, .pdf-list--unordered),
    [data-hide-unordered-markers="true"] :is(ul, .slide-list, .slide-list--unordered, .pdf-list, .pdf-list--unordered) > li,
    [data-hide-unordered-markers="true"] li.slide-list-item,
    [data-hide-unordered-markers="true"] ul > li {
      list-style: none !important;
      list-style-type: none !important;
      padding-left: 0 !important;
      margin-left: 0 !important;
    }
    [data-hide-unordered-markers="true"] :is(ul, .slide-list, .slide-list--unordered, .pdf-list, .pdf-list--unordered) > li::marker,
    [data-hide-unordered-markers="true"] li.slide-list-item::marker {
      content: "" !important;
      display: none !important;
    }

    /* 隐藏有序列表前缀标记 */
    [data-hide-ordered-markers="true"] :is(ol, .slide-list, .slide-list--ordered, .pdf-list, .pdf-list--ordered),
    [data-hide-ordered-markers="true"] :is(ol, .slide-list, .slide-list--ordered, .pdf-list, .pdf-list--ordered) > li,
    [data-hide-ordered-markers="true"] li.slide-list-item,
    [data-hide-ordered-markers="true"] ol > li {
      list-style: none !important;
      list-style-type: none !important;
      padding-left: 0 !important;
      margin-left: 0 !important;
    }
    [data-hide-ordered-markers="true"] :is(ol, .slide-list, .slide-list--ordered, .pdf-list, .pdf-list--ordered) > li::marker,
    [data-hide-ordered-markers="true"] li.slide-list-item::marker {
      content: "" !important;
      display: none !important;
    }

    .slide-list-item-desc,
    .pdf-list li > p {
      margin-top: 4px !important;
      margin-bottom: 6px !important;
      font-size: 1.05rem;
      line-height: 1.55;
      opacity: 0.92;
    }

    /* 多媒体（GIF动图、静态图片、MP4视频）全视口最大化自适应且不超出视口 */
    .slide-media-block,
    .slide-media-container,
    .slide-video-container,
    .slide-block--media,
    .slide-block--image,
    .slide-block--video,
    .slide-block:has(> img),
    .slide-block:has(> .slide-media-container),
    .slide-block:has(> p > img:only-child),
    .slide-block:has(> .slide-video-container),
    .slide-block:has(> video) {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      min-width: 0 !important;
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
      justify-content: center !important;
      width: 100% !important;
      height: 100% !important;
      max-height: 100% !important;
      overflow: hidden !important;
      margin: 4px 0 !important;
      box-sizing: border-box !important;
    }

    .two-cols-left > .slide-block,
    .two-cols-right > .slide-block,
    .three-cols-col > .slide-block,
    .pdf-col > .slide-block,
    .pdf-col .slide-block {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      max-height: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      width: 100% !important;
      height: 100% !important;
      box-sizing: border-box !important;
      overflow: hidden !important;
      margin-bottom: 0 !important;
    }

    /* 列内列表项的标题与段落文字：固定高度，不压缩 */
    .two-cols-left .slide-list-item-title,
    .two-cols-right .slide-list-item-title,
    .three-cols-col .slide-list-item-title,
    .pdf-col .slide-list-item-title,
    .two-cols-left h1, .two-cols-left h2, .two-cols-left h3, .two-cols-left h4, .two-cols-left h5, .two-cols-left h6,
    .two-cols-right h1, .two-cols-right h2, .two-cols-right h3, .two-cols-right h4, .two-cols-right h5, .two-cols-right h6,
    .three-cols-col h1, .three-cols-col h2, .three-cols-col h3, .three-cols-col h4, .three-cols-col h5, .three-cols-col h6,
    .pdf-col h1, .pdf-col h2, .pdf-col h3, .pdf-col h4, .pdf-col h5, .pdf-col h6,
    .three-cols-col .slide-list-item-desc,
    .pdf-col .slide-list-item-desc {
      flex: 0 0 auto !important;
      margin-top: 0 !important;
      margin-bottom: 6px !important;
    }

    /* 列内媒体容器：填满标题下方所有剩余垂直空间，纵向顶部对齐，横向居中，无溢出 */
    .two-cols-left .slide-list-media,
    .two-cols-right .slide-list-media,
    .three-cols-col .slide-list-media,
    .pdf-col .slide-list-media,
    .two-cols-left .slide-video-container,
    .two-cols-right .slide-video-container,
    .three-cols-col .slide-video-container,
    .pdf-col .slide-video-container,
    .two-cols-left .slide-media-container,
    .two-cols-right .slide-media-container,
    .three-cols-col .slide-media-container,
    .pdf-col .slide-media-container {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      min-width: 0 !important;
      width: 100% !important;
      height: 100% !important;
      max-height: 100% !important;
      max-width: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
      justify-content: flex-start !important;
      overflow: hidden !important;
      margin: 0 !important;
      padding: 0 !important;
      box-sizing: border-box !important;
    }

    /* 列内多媒体播放器：以 contain 模式等比缩放完整可见，绝对不超高超宽、不产生遮挡与滚动条 */
    .two-cols-left video,
    .two-cols-right video,
    .three-cols-col video,
    .pdf-col video,
    .two-cols-left img,
    .two-cols-right img,
    .three-cols-col img,
    .pdf-col img,
    .two-cols-left .slide-video-player,
    .two-cols-right .slide-video-player,
    .three-cols-col .slide-video-player,
    .pdf-col .slide-video-player,
    .layout-three-cols-grid video,
    .layout-two-cols-grid video,
    .layout-three-cols-grid img,
    .layout-two-cols-grid img {
      max-width: 100% !important;
      max-height: 100% !important;
      width: auto !important;
      height: auto !important;
      min-width: 0 !important;
      min-height: 0 !important;
      object-fit: contain !important;
      display: block !important;
      margin: 0 auto !important;
      cursor: zoom-in;
    }

    .slide-block img,
    .slide-media-img,
    .slide-media-container img,
    .slide-video-player,
    video.slide-video-player,
    .slide-block video {
      max-width: 100% !important;
      max-height: 100% !important;
      width: auto !important;
      height: auto !important;
      min-width: 0 !important;
      min-height: 0 !important;
      object-fit: contain !important;
      display: block !important;
      margin: 0 auto !important;
      border-radius: 8px;
      box-shadow: 0 4px 16px rgba(0, 0, 0, 0.16);
      background: transparent;
      outline: none;
      cursor: zoom-in;
    }

    .slide-list-media {
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
      justify-content: flex-start !important;
      width: 100% !important;
      max-width: 100% !important;
      height: 100% !important;
      max-height: 100% !important;
      flex: 1 1 0% !important;
      margin-top: 4px !important;
      margin-bottom: 4px !important;
      min-height: 0 !important;
      overflow: hidden !important;
      box-sizing: border-box !important;
    }
    .slide-list-media img,
    .slide-list-media video,
    .slide-list-media .list-item-gif,
    .slide-list-media .slide-video-player {
      max-width: 100% !important;
      max-height: 100% !important;
      width: auto !important;
      height: auto !important;
      min-width: 0 !important;
      min-height: 0 !important;
      object-fit: contain !important;
      border-radius: 6px !important;
      box-shadow: 0 3px 12px rgba(0, 0, 0, 0.14) !important;
      display: block !important;
      margin: 0 auto !important;
      cursor: zoom-in;
    }

    .slide-block:has(.slide-list-media) {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      height: 100% !important;
      max-height: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      overflow: hidden !important;
    }
    .slide-block:has(.slide-list-media) .pdf-list,
    .slide-block:has(.slide-list-media) ul,
    .slide-block:has(.slide-list-media) ol {
      display: block !important;
      flex: 1 1 auto;
      min-height: 0;
      max-height: 100%;
      overflow: visible !important;
      list-style: disc !important;
      list-style-type: disc !important;
    }
    .slide-block:has(.slide-list-media) li,
    .slide-block:has(.slide-list-media) .slide-list-item,
    .slide-block:has(.slide-list-media) .pdf-list-item,
    .slide-block:has(.slide-media-container) li,
    .slide-block:has(.slide-video-container) li,
    .layout-cols-wrapper li:has(.slide-list-media),
    .layout-cols-header-container li:has(.slide-list-media),
    .two-cols-left li:has(.slide-list-media),
    .two-cols-right li:has(.slide-list-media),
    .three-cols-col li:has(.slide-list-media),
    .pdf-col li:has(.slide-list-media),
    li:has(.slide-list-media),
    li:has(.slide-video-container),
    li:has(.slide-media-container) {
      display: list-item !important;
      list-style-type: disc !important;
      flex: 0 0 auto !important;
      height: auto !important;
      max-height: none !important;
      overflow: visible !important;
      margin-bottom: 6px !important;
    }

    .layout-two-cols .slide-media-block,
    .layout-two-cols .slide-video-container,
    .layout-two-cols .slide-media-container,
    .layout-three-cols .slide-media-block,
    .layout-three-cols .slide-video-container,
    .layout-three-cols .slide-media-container {
      max-width: 100% !important;
      max-height: 100% !important;
      width: 100% !important;
      height: 100% !important;
      min-width: 0 !important;
      min-height: 0 !important;
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
      justify-content: flex-start !important;
      overflow: hidden !important;
    }

    /* Lightbox 大图与视频灯箱模态窗口 */
    .slides-lightbox {
      position: fixed;
      top: 0;
      left: 0;
      width: 100vw;
      height: 100vh;
      background: rgba(0, 0, 0, 0.88);
      backdrop-filter: blur(8px);
      z-index: 999999;
      display: none;
      align-items: center;
      justify-content: center;
      cursor: zoom-out;
      opacity: 0;
      transition: opacity 0.2s cubic-bezier(0.16, 1, 0.3, 1);
    }
    .slides-lightbox.active {
      display: flex;
      opacity: 1;
    }
    .slides-lightbox-content {
      position: relative;
      max-width: 92vw;
      max-height: 92vh;
      display: flex;
      align-items: center;
      justify-content: center;
      cursor: default;
    }
    .slides-lightbox-img {
      max-width: 92vw;
      max-height: 92vh;
      object-fit: contain;
      border-radius: 8px;
      box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.75);
      user-select: none;
      -webkit-user-drag: none;
      touch-action: none;
    }
    .slides-lightbox-video {
      max-width: 92vw;
      max-height: 92vh;
      border-radius: 8px;
      box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.75);
    }
    .slides-lightbox-close {
      position: absolute;
      top: 24px;
      right: 28px;
      width: 40px;
      height: 40px;
      background: rgba(255, 255, 255, 0.2);
      border: 1px solid rgba(255, 255, 255, 0.35);
      border-radius: 50%;
      color: #fff;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 22px;
      cursor: pointer;
      transition: background 0.2s, transform 0.2s;
      z-index: 1000000;
    }
    .slides-lightbox-close:hover {
      background: rgba(255, 255, 255, 0.35);
      transform: scale(1.05);
    }

    img.slide-inline-img {
      max-width: 100% !important;
      max-height: min(320px, 40vh) !important;
      object-fit: contain !important;
      vertical-align: middle;
      border-radius: 4px;
    }
    kbd {
      display: inline-block;
      padding: 2px 7px;
      font-family: ui-monospace, SFMono-Regular, "SF Mono", Menlo, Consolas, "Liberation Mono", monospace;
      font-size: 0.85em;
      font-weight: 600;
      line-height: 1.25;
      color: inherit;
      background: rgba(125, 125, 125, 0.12);
      border: 1px solid rgba(125, 125, 125, 0.35);
      border-bottom-width: 2px;
      border-radius: 5px;
      box-shadow: 0 1px 2px rgba(0, 0, 0, 0.12);
      margin: 0 2px;
      vertical-align: middle;
      white-space: nowrap;
    }
    [data-theme="dark"] kbd, .theme-dark kbd {
      background: rgba(255, 255, 255, 0.1);
      border-color: rgba(255, 255, 255, 0.25);
      border-bottom-color: rgba(255, 255, 255, 0.4);
      color: #f1f5f9;
      box-shadow: 0 1px 2px rgba(0, 0, 0, 0.4);
    }
    .slide-block pre,
    pre {
      background: rgba(0, 0, 0, 0.1);
      padding: 12px;
      border-radius: 6px;
      font-family: "JetBrains Mono", Consolas, monospace;
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      overflow-x: hidden !important;
      overflow-y: auto !important;
      max-width: 100% !important;
      box-sizing: border-box !important;
    }
    .slide-block pre code,
    pre code {
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      display: block !important;
      width: 100% !important;
      box-sizing: border-box !important;
    }
    .code-line {
      display: flex !important;
      align-items: flex-start !important;
      width: 100% !important;
      box-sizing: border-box !important;
      line-height: 1.6;
    }
    .code-line .line-no {
      display: inline-block !important;
      flex-shrink: 0 !important;
      min-width: 2.2em !important;
      text-align: right !important;
      margin-right: 12px !important;
      user-select: none !important;
      opacity: 0.45 !important;
    }
    .code-line .line-content {
      flex: 1 1 0% !important;
      min-width: 0 !important;
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
    }
    /* 弱提示滚动条样式 */
    * {
      scrollbar-width: thin;
      scrollbar-color: rgba(255, 255, 255, 0.20) transparent;
    }
    *::-webkit-scrollbar {
      width: 4px;
      height: 4px;
    }
    *::-webkit-scrollbar-track {
      background: transparent;
    }
    *::-webkit-scrollbar-thumb {
      background: rgba(255, 255, 255, 0.20);
      border-radius: 2px;
      transition: background 0.2s ease;
    }
    *:hover::-webkit-scrollbar-thumb,
    *::-webkit-scrollbar-thumb:hover {
      background: rgba(255, 255, 255, 0.45);
    }
    /* Slidev Micro-motion Keyframes & Presets */
    @keyframes slidesMotionFadeIn { from { opacity: 0; } to { opacity: 1; } }
    @keyframes slidesMotionSlideUp { from { opacity: 0; transform: translateY(40px); } to { opacity: 1; transform: translateY(0); } }
    @keyframes slidesMotionSlideDown { from { opacity: 0; transform: translateY(-40px); } to { opacity: 1; transform: translateY(0); } }
    @keyframes slidesMotionSlideLeft { from { opacity: 0; transform: translateX(40px); } to { opacity: 1; transform: translateX(0); } }
    @keyframes slidesMotionSlideRight { from { opacity: 0; transform: translateX(-40px); } to { opacity: 1; transform: translateX(0); } }
    @keyframes slidesMotionZoomIn { from { opacity: 0; transform: scale(0.8); } to { opacity: 1; transform: scale(1); } }
    @keyframes slidesMotionBounce {
      0% { opacity: 0; transform: translateY(40px); }
      60% { opacity: 1; transform: translateY(-8px); }
      80% { transform: translateY(4px); }
      100% { transform: translateY(0); }
    }
    .slides-motion-fade-in { animation: slidesMotionFadeIn var(--motion-duration, 0.4s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slides-motion-slide-up { animation: slidesMotionSlideUp var(--motion-duration, 0.45s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slides-motion-slide-down { animation: slidesMotionSlideDown var(--motion-duration, 0.45s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slides-motion-slide-left { animation: slidesMotionSlideLeft var(--motion-duration, 0.45s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slides-motion-slide-right { animation: slidesMotionSlideRight var(--motion-duration, 0.45s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slides-motion-zoom-in, .slides-motion-pop { animation: slidesMotionZoomIn var(--motion-duration, 0.4s) cubic-bezier(0.34, 1.56, 0.64, 1) var(--motion-delay, 0s) both; }
    .slides-motion-bounce { animation: slidesMotionBounce var(--motion-duration, 0.6s) cubic-bezier(0.34, 1.56, 0.64, 1) var(--motion-delay, 0s) both; }
    .controls {
      position: absolute; bottom: 16px; display: flex; gap: 12px; align-items: center;
      background: rgba(24, 24, 27, 0.8); backdrop-filter: blur(8px);
      padding: 6px 18px; border-radius: 20px; color: #fff; font-size: 13px; z-index: 10;
      opacity: 0; pointer-events: auto;
      transition: opacity 0.3s cubic-bezier(0.16, 1, 0.3, 1), transform 0.3s cubic-bezier(0.16, 1, 0.3, 1);
    }
    .controls::before {
      content: ""; position: absolute; top: -20px; bottom: -16px; left: -24px; right: -24px;
    }
    .controls:hover, .controls:focus-within {
      opacity: 1; transform: translateY(-2px);
    }
    .controls button { background: transparent; border: none; color: inherit; cursor: pointer; padding: 2px 6px; }

    /* Slidev Native Icons & Interactive Buttons */
    .slidev-icon-btn {
      display: inline-flex !important; flex-direction: row !important; align-items: center !important; justify-content: center !important;
      padding: 0.35rem 0.5rem; border-radius: 0.375rem; background: transparent;
      border: 1px solid transparent; color: inherit; font-size: inherit; line-height: 1;
      cursor: pointer; opacity: 0.8; transition: all 0.2s ease; text-decoration: none;
      vertical-align: middle; user-select: none; margin: 0 4px;
    }
    .slidev-icon-btn:hover { opacity: 1; background: rgba(255, 255, 255, 0.12); border-color: rgba(255, 255, 255, 0.15); }

    /* 组件从上到下按顺序流式渲染，避免相互重叠 */
    .slide-block > div + div { margin-top: 14px; }

    /* 同一个 div 内的按钮/链接从左到右水平渲染 */
    .slide-block div:has(> .slidev-icon-btn),
    .slide-block div:has(> button),
    .slide-block [class*="abs-"],
    .slides-btn-row {
      display: inline-flex !important;
      flex-direction: row !important;
      align-items: center !important;
      justify-content: center !important;
      flex-wrap: wrap !important;
      gap: 8px !important;
    }

    /* Position Shortcuts 适配：在组件流中保持从上到下排列，不脱离流产生重叠 */
    .slide-block .abs-br,
    .slide-block .abs-bl,
    .slide-block .abs-tr,
    .slide-block .abs-tl,
    .slide-block [class*="abs-"] {
      position: relative !important;
      bottom: auto !important;
      right: auto !important;
      top: auto !important;
      left: auto !important;
      margin: 0.75rem auto !important;
    }

    .slide-block--absolute { position: relative !important; margin-bottom: 14px !important; padding: 0 !important; background: transparent !important; }
    .slide-block--absolute:hover { background: transparent !important; }
    .mt-12 { margin-top: 3rem !important; }
    .py-1 { padding-top: 0.25rem !important; padding-bottom: 0.25rem !important; }
    .m-6 { margin: 1.5rem !important; }
    .text-xl { font-size: 1.25rem !important; }
    [hover\\:bg~="white"][hover\\:bg~="op-10"]:hover,
    [hover\\:bg="white op-10"]:hover { background: rgba(255, 255, 255, 0.1) !important; border-radius: 4px; }
    .cursor-pointer, [data-clickable] { cursor: pointer; }
    /* Slidev 规范链接排版 (继承正文颜色，虚线底边，Hover 时平滑点亮为主题色并转为实线) */
    .slide-content a:not(.slides-ref-tag):not(.slidev-icon-btn):not(.slides-toc-link),
    .slide-block a:not(.slides-ref-tag):not(.slidev-icon-btn):not(.slides-toc-link),
    a.slides-link {
      color: inherit;
      text-decoration: none;
      border-bottom: 1px dashed currentColor;
      transition: color 0.2s cubic-bezier(0.4, 0, 0.2, 1),
                  border-color 0.2s cubic-bezier(0.4, 0, 0.2, 1),
                  border-bottom-style 0.2s cubic-bezier(0.4, 0, 0.2, 1);
      cursor: pointer;
    }
    .slide-content a:not(.slides-ref-tag):not(.slidev-icon-btn):not(.slides-toc-link):hover,
    .slide-block a:not(.slides-ref-tag):not(.slidev-icon-btn):not(.slides-toc-link):hover,
    a.slides-link:hover {
      color: var(--slide-accent);
      border-bottom-style: solid;
      border-bottom-color: var(--slide-accent);
    }
    .slides-ref-tag, a.slides-ref-tag {
      display: inline-flex;
      align-items: center;
      background: color-mix(in srgb, var(--slide-accent) 12%, transparent);
      color: var(--slide-accent);
      border-radius: 4px;
      padding: 2px 8px;
      font-size: 0.88em;
      text-decoration: none;
      cursor: pointer;
      margin: 2px 4px 2px 0;
      border: 1px solid color-mix(in srgb, var(--slide-accent) 25%, transparent);
      transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
    }
    .slides-ref-tag:hover, a.slides-ref-tag:hover {
      background: color-mix(in srgb, var(--slide-accent) 22%, transparent);
      color: var(--slide-accent);
      border-color: color-mix(in srgb, var(--slide-accent) 55%, transparent);
      transform: translateY(-1px);
      box-shadow: 0 2px 8px color-mix(in srgb, var(--slide-accent) 20%, transparent);
    }
    .slides-block-ref {
      display: block;
      padding: 10px 14px;
      background: color-mix(in srgb, var(--slide-accent) 8%, transparent);
      border-left: 3px solid var(--slide-accent);
      border-radius: 0 6px 6px 0;
      margin: 8px 0;
      cursor: pointer;
      transition: background 0.2s ease;
    }
    .slides-block-ref:hover {
      background: color-mix(in srgb, var(--slide-accent) 15%, transparent);
    }

    /* 页面动态蒙版 (Dynamic Mask) GPU 合成器硬件加速体系 */
    .slides-mask-body-container {
      position: relative;
      width: 100%;
      height: 100%;
      min-height: 0;
      flex: 1;
      display: flex;
      flex-direction: column;
      overflow: hidden !important;
      contain: layout paint;
      isolation: isolate;
    }
    .slides-mask-body-container--has-mask {
      overflow: hidden !important;
      /* 向左右、向下突破父容器内边距，完全贴合幻灯片视口边缘 */
      margin-left: calc(-1 * var(--slides-padding-x, 48px)) !important;
      margin-right: calc(-1 * var(--slides-padding-x, 48px)) !important;
      margin-bottom: calc(-1 * var(--slides-padding-y, 32px)) !important;
      padding-left: var(--slides-padding-x, 48px) !important;
      padding-right: var(--slides-padding-x, 48px) !important;
      padding-bottom: var(--slides-padding-y, 32px) !important;
      width: calc(100% + 2 * var(--slides-padding-x, 48px)) !important;
      box-sizing: border-box !important;
    }
    /* 无标题且首个元素即为蒙版正文容器时，向上同步扩展至顶部边缘 */
    .slide-content-wrapper > .slides-mask-body-container--has-mask:first-child,
    .slide-content > .slides-mask-body-container--has-mask:first-child {
      margin-top: calc(-1 * var(--slides-padding-y, 32px)) !important;
      padding-top: var(--slides-padding-y, 32px) !important;
    }
    /* 针对全屏零内边距特殊布局（如 image-right/image-left），重置内边距变量避免越界 */
    .slide-content-wrapper.layout-image-right,
    .slide-content-wrapper.layout-image-left,
    .slide-content.layout-image-right,
    .slide-content.layout-image-left {
      --slides-padding-x: 0px !important;
      --slides-padding-y: 0px !important;
    }
    /* 蒙版运动总图层：纯 GPU Compositor 硬件加速 translate3d */
    .slides-mask-layer {
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      pointer-events: none;
      z-index: 50;
      will-change: transform, opacity;
      transform: translate3d(0, 0, 0);
      backface-visibility: hidden;
      transition: transform 0.42s cubic-bezier(0.2, 0, 0, 1),
                  opacity 0.42s cubic-bezier(0.2, 0, 0, 1);
    }
    /* 蒙版内部遮罩层：纯色或磨砂玻璃 */
    .slides-mask-overlay {
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      pointer-events: none;
    }
    .slides-mask-layer--solid .slides-mask-overlay,
    .slides-mask-overlay--solid {
      background: var(--slide-bg, #ffffff);
    }
    [data-theme="dark"] .slides-mask-layer--solid .slides-mask-overlay,
    [data-theme="dark"] .slides-mask-overlay--solid {
      background: var(--slide-bg, #121214);
    }
    .slides-mask-layer--blur .slides-mask-overlay,
    .slides-mask-overlay--blur {
      backdrop-filter: blur(30px) saturate(180%);
      -webkit-backdrop-filter: blur(30px) saturate(180%);
      background: color-mix(in srgb, var(--slide-bg, #ffffff) 90%, transparent);
    }
    [data-theme="dark"] .slides-mask-layer--blur .slides-mask-overlay,
    [data-theme="dark"] .slides-mask-overlay--blur {
      background: color-mix(in srgb, var(--slide-bg, #121214) 90%, transparent);
    }
    /* 动态展露分界提示线：物理内嵌于蒙版边缘，相对坐标永为 0，绝对物理同步 */
    .slides-mask-divider-line {
      position: absolute;
      pointer-events: none;
      z-index: 51;
      opacity: 0;
      transition: opacity 0.3s ease;
    }
    .slides-mask-layer--down .slides-mask-divider-line,
    .slides-mask-divider-line--down {
      top: 0;
      left: 0;
      right: 0;
      height: 2.5px;
      transform: translateY(-50%);
      background: linear-gradient(90deg, transparent 0%, var(--slide-accent, #3b82f6) 6%, var(--slide-accent, #3b82f6) 94%, transparent 100%);
      box-shadow: 0 0 10px var(--slide-accent, #3b82f6), 0 0 4px var(--slide-accent, #3b82f6);
    }
    .slides-mask-layer--right .slides-mask-divider-line,
    .slides-mask-divider-line--right {
      top: 0;
      bottom: 0;
      left: 0;
      width: 2.5px;
      transform: translateX(-50%);
      background: linear-gradient(180deg, transparent 0%, var(--slide-accent, #3b82f6) 6%, var(--slide-accent, #3b82f6) 94%, transparent 100%);
      box-shadow: 0 0 10px var(--slide-accent, #3b82f6), 0 0 4px var(--slide-accent, #3b82f6);
    }
    .slides-mask-layer--clockwise,
    .slides-mask-layer--counter-clockwise,
    .slides-mask-layer--cw,
    .slides-mask-layer--ccw,
    .slides-mask-layer--clock {
      transform: none !important;
    }
    .slides-mask-layer--clockwise .slides-mask-divider-line,
    .slides-mask-layer--counter-clockwise .slides-mask-divider-line,
    .slides-mask-layer--cw .slides-mask-divider-line,
    .slides-mask-layer--ccw .slides-mask-divider-line,
    .slides-mask-layer--clock .slides-mask-divider-line,
    .slides-mask-divider-line--clock,
    .slides-mask-divider-line--clockwise,
    .slides-mask-divider-line--counter-clockwise {
      top: 50%;
      left: 50%;
      right: auto;
      bottom: auto;
      width: 55%;
      height: 2.5px;
      transform-origin: 0% 50%;
      transform: translateY(-50%) rotate(-180deg);
      background: linear-gradient(90deg, var(--slide-accent, #3b82f6) 0%, var(--slide-accent, #3b82f6) 75%, transparent 100%);
      box-shadow: 0 0 10px var(--slide-accent, #3b82f6), 0 0 4px var(--slide-accent, #3b82f6);
      transition: transform 0.42s cubic-bezier(0.2, 0, 0, 1), opacity 0.3s ease;
      will-change: transform, opacity;
    }
    .slides-mask-layer--counter-clockwise .slides-mask-divider-line,
    .slides-mask-divider-line--counter-clockwise {
      transform: translateY(-50%) rotate(-90deg);
    }`}function Qm(){return`    (function() {
      const data = window.__SLIDES_DATA__ || { slides: [] };
      const slides = data.slides || [];
      let currentIndex = 0;

      const container = document.getElementById("slide-container");
      const pageNum = document.getElementById("page-num");
      const btnPrev = document.getElementById("btn-prev");
      const btnNext = document.getElementById("btn-next");
      const btnFullscreen = document.getElementById("btn-fullscreen");

      // 「数字+回车」跳页输入角标：右下角悬浮显示，独立于缩放视口
      const jumpBadge = document.createElement("div");
      jumpBadge.className = "jump-page-indicator";
      jumpBadge.style.display = "none";
      document.body.appendChild(jumpBadge);
      const jumpStyle = document.createElement("style");
      jumpStyle.textContent = ".jump-page-indicator{position:fixed;right:16px;bottom:16px;z-index:1000;min-width:40px;padding:4px 12px;border-radius:18px;background:rgba(24,24,27,0.8);backdrop-filter:blur(12px);-webkit-backdrop-filter:blur(12px);border:1px solid rgba(255,255,255,0.12);color:#f4f4f5;font-size:14px;font-variant-numeric:tabular-nums;text-align:center;pointer-events:none;box-shadow:0 4px 16px rgba(0,0,0,0.35);}.jump-page-indicator.is-invalid{background:rgba(153,27,27,0.85);border-color:rgba(248,113,113,0.5);color:#fecaca;animation:jump-indicator-shake 0.4s ease;}@keyframes jump-indicator-shake{0%,100%{transform:translateX(0);}25%{transform:translateX(-4px);}50%{transform:translateX(4px);}75%{transform:translateX(-2px);}}";
      document.head.appendChild(jumpStyle);

`}function eg(){return`      // ========= 缩略图总览层（o 键呼出，方向键/数字+回车/点选跳页） =========
      const OVERVIEW_CARD_W = 236;
      let overviewOpen = false;
      let overviewFocus = 1;
      let overviewBuilt = false;
      let overviewObserver = null;
      const overviewOverlay = document.createElement("div");
      overviewOverlay.className = "slides-overview";
      overviewOverlay.style.display = "none";
      const overviewGrid = document.createElement("div");
      overviewGrid.className = "slides-overview-grid";
      const overviewHint = document.createElement("div");
      overviewHint.className = "slides-overview-hint";
      overviewHint.textContent = "← → ↑ ↓ 移动 · Enter 跳转 · 数字直达 · Esc / O 关闭";
      overviewOverlay.appendChild(overviewGrid);
      overviewOverlay.appendChild(overviewHint);
      document.body.appendChild(overviewOverlay);
      overviewOverlay.addEventListener("click", (e) => {
        if (e.target === overviewOverlay) closeOverview();
      });
      const overviewStyle = document.createElement("style");
      overviewStyle.textContent = ".slides-overview{position:fixed;inset:0;z-index:900;overflow-y:auto;background:rgba(13,16,22,0.88);backdrop-filter:blur(18px);-webkit-backdrop-filter:blur(18px);padding:36px 44px 20px;box-sizing:border-box;}.slides-overview-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(236px,1fr));gap:18px;max-width:1440px;margin:0 auto;}.slides-overview-card{cursor:pointer;border-radius:10px;border:2px solid rgba(255,255,255,0.12);background:rgba(255,255,255,0.04);overflow:hidden;transition:border-color 0.15s ease,transform 0.15s ease,box-shadow 0.15s ease;}.slides-overview-card:hover{border-color:rgba(255,255,255,0.38);transform:translateY(-2px);}.slides-overview-card.is-active{border-color:var(--slide-accent,#3b82f6);box-shadow:0 0 0 1px var(--slide-accent,#3b82f6),0 8px 24px rgba(0,0,0,0.4);}.slides-overview-canvas-box{position:relative;overflow:hidden;background:var(--slide-bg,#ffffff);}.slides-overview-canvas{position:absolute;top:0;left:0;transform-origin:top left;pointer-events:none;}.slides-overview-canvas *{scrollbar-width:none;}.slides-overview-caption{display:flex;align-items:center;gap:8px;padding:6px 10px;font-size:12px;color:rgba(255,255,255,0.72);border-top:1px solid rgba(255,255,255,0.08);background:rgba(13,16,22,0.6);}.slides-overview-page-no{flex-shrink:0;font-variant-numeric:tabular-nums;font-weight:600;color:#f4f4f5;background:rgba(255,255,255,0.16);border-radius:8px;padding:0 7px;line-height:18px;}.slides-overview-page-no.is-current{background:var(--slide-accent,#10b981);color:#0b1210;}.slides-overview-title{white-space:nowrap;overflow:hidden;text-overflow:ellipsis;user-select:none;}.slides-overview-hint{text-align:center;margin:18px 0 8px;font-size:12px;color:rgba(255,255,255,0.45);user-select:none;}";
      document.head.appendChild(overviewStyle);

      const baseWidth = 980;
      const aspectStr = (data.config && data.config.aspectRatio) || "16/9";
      let ratioNum = 16 / 9;
      if (aspectStr === "4/3") ratioNum = 4 / 3;
      else if (aspectStr === "16/10") ratioNum = 16 / 10;
      else if (typeof aspectStr === "string" && aspectStr.includes("/")) {
        const parts = aspectStr.split("/").map(Number);
        if (parts[0] && parts[1]) ratioNum = parts[0] / parts[1];
      }
      const baseHeight = Math.ceil(baseWidth / ratioNum);
      const viewport = document.getElementById("viewport");

`}function tg(){return`      function updateScale() {
        if (!viewport) return;
        const isFull = !!document.fullscreenElement;
        const padX = isFull ? 0 : 20;
        const padY = isFull ? 0 : 32;
        const availW = Math.max(100, window.innerWidth - padX);
        const availH = Math.max(100, window.innerHeight - padY);
        const scale = Math.min(availW / baseWidth, availH / baseHeight);
        viewport.style.width = baseWidth + "px";
        viewport.style.height = baseHeight + "px";
        viewport.style.transform = "translate(-50%, -50%) scale(" + scale + ")";
        viewport.style.setProperty("--slides-slide-scale", scale);
        if (isFull) document.body.classList.add("is-fullscreen");
        else document.body.classList.remove("is-fullscreen");
      }

      window.addEventListener("resize", updateScale);
      document.addEventListener("fullscreenchange", updateScale);

      function parseMaskRatio(ratioStr, defaultSteps) {
        var defSteps = (defaultSteps === 4) ? 4 : 2;
        var defBps = (defaultSteps === 4) ? [25, 50, 75, 100] : [50, 100];
        if (!ratioStr || typeof ratioStr !== "string") {
          return { steps: defSteps, breakpoints: defBps };
        }
        var clean = ratioStr.trim();
        if (!clean || (defaultSteps === 4 && (clean === "1:1" || clean === "1"))) return { steps: defSteps, breakpoints: defBps };
        var parts = clean.split(":").map(function(p) { return parseFloat(p.trim()); }).filter(function(n) { return !isNaN(n) && n > 0; });
        if (parts.length === 0) return { steps: defSteps, breakpoints: defBps };
        if (parts.length === 1) {
          var val = Math.min(100, Math.max(1, parts[0]));
          if (val === 100) return { steps: 1, breakpoints: [100] };
          return { steps: 2, breakpoints: [Math.round(val * 100) / 100, 100] };
        }
        var isMonotonic = parts.every(function(val, idx) { return idx === 0 || val > parts[idx - 1]; });
        var maxVal = parts[parts.length - 1];
        if (isMonotonic && (maxVal === 100 || parts.some(function(p) { return p > 10; }))) {
          var bps = parts.map(function(p) { return Math.min(100, Math.round(p * 100) / 100); });
          if (bps[bps.length - 1] < 100) bps.push(100);
          return { steps: bps.length, breakpoints: bps };
        }
        var totalWeight = parts.reduce(function(acc, cur) { return acc + cur; }, 0);
        if (totalWeight <= 0) return { steps: defSteps, breakpoints: defBps };
        var accumulated = 0;
        var bps = [];
        for (var i = 0; i < parts.length; i++) {
          accumulated += parts[i];
          if (i === parts.length - 1) {
            bps.push(100);
          } else {
            bps.push(Math.round((accumulated / totalWeight) * 10000) / 100);
          }
        }
        return { steps: bps.length, breakpoints: bps };
      }

      let currentMaskStep = 0;
      let currentMaskConfig = null;
      let maskLayerEl = null;
      let maskOverlayEl = null;
      let maskDividerEl = null;

      function updateMaskVisual() {
        if (!currentMaskConfig || !maskLayerEl) return;
        const p = (currentMaskStep <= 0)
          ? (currentMaskConfig.isInitialRevealed ? currentMaskConfig.breakpoints[0] : 0)
          : (currentMaskStep >= currentMaskConfig.totalSteps
              ? 100
              : currentMaskConfig.breakpoints[currentMaskConfig.isInitialRevealed ? currentMaskStep : (currentMaskStep - 1)]);

        if (currentMaskConfig.isClock) {
          const isCw = currentMaskConfig.direction === "clockwise" || currentMaskConfig.direction === "cw";
          const sweepDeg = Math.min(360, Math.max(0, (p / 100) * 360));
          const needleAngle = isCw ? (-180 + sweepDeg) : (-90 - sweepDeg);

          if (maskOverlayEl) {
            let maskGrad = "";
            if (sweepDeg <= 0) {
              maskGrad = "conic-gradient(from 0deg at 50% 50%, #000 0deg, #000 360deg)";
            } else if (sweepDeg >= 360) {
              maskGrad = "conic-gradient(from 0deg at 50% 50%, transparent 0deg, transparent 360deg)";
            } else if (isCw) {
              maskGrad = "conic-gradient(from 270deg at 50% 50%, transparent 0deg, transparent " + sweepDeg + "deg, #000 " + sweepDeg + "deg, #000 360deg)";
            } else {
              const remDeg = 360 - sweepDeg;
              maskGrad = "conic-gradient(from 0deg at 50% 50%, #000 0deg, #000 " + remDeg + "deg, transparent " + remDeg + "deg, transparent 360deg)";
            }
            maskOverlayEl.style.webkitMaskImage = maskGrad;
            maskOverlayEl.style.maskImage = maskGrad;
          }

          if (maskDividerEl) {
            maskDividerEl.style.transform = "translateY(-50%) rotate(" + needleAngle + "deg)";
            maskDividerEl.style.opacity = (p <= 0 || p >= 100) ? "0" : "1";
          }

          if (p >= 100) {
            maskLayerEl.style.opacity = "0";
            maskLayerEl.style.pointerEvents = "none";
          } else {
            maskLayerEl.style.opacity = "1";
            maskLayerEl.style.pointerEvents = "none";
          }
          return;
        }

        const isDown = currentMaskConfig.direction === "down";
        if (p >= 100) {
          maskLayerEl.style.transform = isDown ? "translate3d(0, 100%, 0)" : "translate3d(100%, 0, 0)";
          maskLayerEl.style.opacity = "0";
          maskLayerEl.style.pointerEvents = "none";
          if (maskDividerEl) maskDividerEl.style.opacity = "0";
        } else {
          maskLayerEl.style.transform = isDown ? ("translate3d(0, " + p + "%, 0)") : ("translate3d(" + p + "%, 0, 0)");
          maskLayerEl.style.opacity = "1";
          maskLayerEl.style.pointerEvents = "none";
          if (maskDividerEl) {
            maskDividerEl.style.opacity = (p <= 0) ? "0" : "1";
          }
        }
      }

      function goNext() {
        if (currentMaskConfig && currentMaskStep < currentMaskConfig.totalSteps) {
          currentMaskStep++;
          updateMaskVisual();
          return;
        }
        renderSlide(currentIndex + 1);
      }

      function goPrev() {
        if (currentMaskConfig && currentMaskStep > (currentMaskConfig.isInitialRevealed ? 1 : 0)) {
          currentMaskStep--;
          updateMaskVisual();
          return;
        }
        // FSM-9 优化：回退至上一页时传递 backward 方向，使上一页遮罩处于完全展开状态
        renderSlide(currentIndex - 1, "backward");
      }

`}function ig(){return`      function cleanCardListItemMarkdown(rawMarkdown) {
        if (!rawMarkdown) return "";
        let cleaned = rawMarkdown.replace(/^[ 	]*[-*+]s+|^[ 	]*d+.s+/, "");
        cleaned = cleaned.replace(/
[ 	]{2,4}/g, "
");
        return cleaned.trim();
      }

      function isHeadingBlock(b) {
        if (!b) return false;
        if (b.type === "h" || b.type === "NodeHeading") return true;
        if (b.subType && /^h[1-6]$/i.test(b.subType)) return true;
        const md = (b.rawMarkdown || b.content || "").trim();
        if (/^#{1,6}s+/.test(md)) return true;
        if (/^(?:[-*+]|d+.)s+#{1,6}s+/.test(md)) return true;
        return false;
      }

      function cleanColList(blocks) {
        const valid = (blocks || []).filter(b => Boolean((b.rawMarkdown || b.content || "").trim()));
        if (valid.length === 0) return valid;
        const first = valid[0];
        const md = (first.rawMarkdown || first.content || "").trim();
        const isList = /^(?:[-*+]|d+.)s+/.test(md) || first.type === "i" || first.type === "l";
        if (isList) {
          first.rawMarkdown = cleanCardListItemMarkdown(first.rawMarkdown || first.content || "");
          first.content = first.rawMarkdown;
        }
        return valid;
      }

      function renderBlock(block, extraClass) {
        const div = document.createElement("div");
        div.className = "slide-block" + (extraClass ? " " + extraClass : "");
        if (block && block.motion && block.motion.preset && block.motion.preset !== "none") {
          div.classList.add("slides-motion-" + block.motion.preset.toLowerCase());
          if (typeof block.motion.duration === "number" && block.motion.duration > 0) {
            div.style.setProperty("--motion-duration", block.motion.duration + "ms");
          }
          if (typeof block.motion.delay === "number" && block.motion.delay > 0) {
            div.style.setProperty("--motion-delay", block.motion.delay + "ms");
          }
        }
        const md = block.rawMarkdown || block.content || "";

        if (md.includes('class="slides-block-ref"') || md.includes('class="slides-ref-tag"')) {
          div.innerHTML = md;
          return div;
        }

        const CARBON_MAP = {
          'carbon:arrow-right': '<svg viewBox="0 0 32 32" width="1.2em" height="1.2em" fill="currentColor" style="display:inline-block;vertical-align:middle;"><path d="m18 6l-1.43 1.393L24.15 15H4v2h20.15l-7.58 7.573L18 26l10-10z"/></svg>',
          'carbon:arrow-left': '<svg viewBox="0 0 32 32" width="1.2em" height="1.2em" fill="currentColor" style="display:inline-block;vertical-align:middle;"><path d="m14 26l1.43-1.393L7.85 17H28v-2H7.85l7.58-7.573L14 6L4 16z"/></svg>',
          'carbon:edit': '<svg viewBox="0 0 32 32" width="1.2em" height="1.2em" fill="currentColor" style="display:inline-block;vertical-align:middle;"><path d="M2 26h28v2H2zM25.4 9c.8-.8.8-2 0-2.8l-3.6-3.6c-.8-.8-2-.8-2.8 0l-15 15V24h6.4l15-15zM20.4 4L24 7.6l-2.4 2.4l-3.6-3.6L20.4 4zM6 22v-3.6l11-11l3.6 3.6l-11 11H6z"/></svg>',
          'carbon:logo-github': '<svg viewBox="0 0 32 32" width="1.2em" height="1.2em" fill="currentColor" style="display:inline-block;vertical-align:middle;"><path fill-rule="evenodd" d="M16 2a14 14 0 0 0-4.43 27.28c.7.13 1-.3 1-.67v-2.38c-3.89.84-4.71-1.88-4.71-1.88a3.7 3.7 0 0 0-1.56-2.05c-1.27-.86.1-.85.1-.85a2.94 2.94 0 0 1 2.14 1.44a3 3 0 0 0 4.08 1.16a2.93 2.93 0 0 1 .89-1.87c-3.1-.35-6.36-1.55-6.36-6.9a5.4 5.4 0 0 1 1.44-3.75a5 5 0 0 1 .14-3.71s1.17-.38 3.85 1.43a13.3 13.3 0 0 1 7 0c2.67-1.81 3.84-1.43 3.84-1.43a5 5 0 0 1 .14 3.71a5.4 5.4 0 0 1 1.44 3.75c0 5.37-3.27 6.54-6.38 6.89a3.35 3.35 0 0 1 1.26 2.61v3.87c0 .38.26.81 1 .67A14 14 0 0 0 16 2"/></svg>'
        };

        if (/@\\w+=['"]|v-\\w+|<button|<a\\b|<carbon:|^<div/i.test(md)) {
          if (md.includes('abs-br') || md.includes('abs-bl') || md.includes('abs-tr') || md.includes('abs-tl') || md.includes('absolute')) {
            div.classList.add("slide-block--absolute");
          }
          let renderedHtml = md;
          for (const [tag, svg] of Object.entries(CARBON_MAP)) {
            const regex = new RegExp("<" + tag + "\\\\s*\\\\/?>", "gi");
            renderedHtml = renderedHtml.replace(regex, svg);
            const regexDash = new RegExp("<" + tag.replace(":", "-") + "\\\\s*\\\\/?>", "gi");
            renderedHtml = renderedHtml.replace(regexDash, svg);
          }
          div.innerHTML = renderedHtml;

          // 挂载交互事件监听
          const nextBtns = div.querySelectorAll('[\\\\@click*="nav.next"], [\\\\@click*="next"]');
          nextBtns.forEach(btn => {
            btn.style.cursor = "pointer";
            btn.addEventListener("click", (e) => {
              e.stopPropagation();
              renderSlide(currentIndex + 1);
            });
          });

          const prevBtns = div.querySelectorAll('[\\\\@click*="nav.prev"], [\\\\@click*="prev"]');
          prevBtns.forEach(btn => {
            btn.style.cursor = "pointer";
            btn.addEventListener("click", (e) => {
              e.stopPropagation();
              renderSlide(currentIndex - 1);
            });
          });

          return div;
        }

        const hasHeadingTag = /(?:^|
)s*#{1,6}s+/.test(md);
        const hMatch = md.match(/^(#{1,6})\\s+(.*)$/);

        if (hMatch) {
          const level = hMatch[1].length;
          let th = hMatch[2].trim().replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
          div.innerHTML = "<h" + level + ">" + th + "</h" + level + ">";
        }
        else if (md.startsWith("\`\`\`")) {
          const customMaxHeight = block?.attributes?.["custom-slides-max-height"] || block?.attrs?.["custom-slides-max-height"] || block?.maxHeight || "";
          const heightStyle = customMaxHeight ? ' style="max-height:' + customMaxHeight + ';overflow-y:auto;"' : "";
          div.innerHTML = "<pre" + heightStyle + "><code>" + md.slice(3, -3) + "</code></pre>";
        }
        else if (md.startsWith("> ")) div.innerHTML = "<blockquote><p>" + md.slice(2) + "</p></blockquote>";
        else if ((/<video\b/i.test(md) || (block && (block.type === "video" || block.type === "NodeVideo"))) && !/^(s*)([-*+]|d+.)s+/m.test(md) && !hasHeadingTag && !md.includes("
")) {
          div.classList.add("slide-video-container", "slide-media-container", "slide-media-block");
          const isAutoplay = block && block.attributes && block.attributes["custom-slides-autoplay"] === "true";
          const isLoop = block && block.attributes && block.attributes["custom-slides-loop"] === "true";
          const isMuted = block && block.attributes && (block.attributes["custom-slides-muted"] === "true" || isAutoplay);
          const hideControls = block && block.attributes && block.attributes["custom-slides-controls"] === "false";
          let videoHtml = md;
          if (hideControls) videoHtml = videoHtml.replace(/\bcontrols(?:="[^"]*")?/gi, "").trim();
          else if (!videoHtml.includes("controls")) videoHtml = videoHtml.replace("<video", "<video controls");
          if (isAutoplay && !videoHtml.includes("autoplay")) videoHtml = videoHtml.replace("<video", "<video autoplay playsinline");
          if (isLoop && !videoHtml.includes("loop")) videoHtml = videoHtml.replace("<video", "<video loop");
          if (isMuted && !videoHtml.includes("muted")) videoHtml = videoHtml.replace("<video", "<video muted");
          videoHtml = videoHtml.replace("<video", '<video class="slide-video-player"');
          div.setAttribute("data-autoplay", isAutoplay ? "true" : "false");
          div.innerHTML = videoHtml;
        }
        else if (
          /^(s*)([-*+]|d+.)s+/m.test(md) ||
          (md.includes("
") && /^(s*)([-*+]|d+.)s+/m.test(md.split("
").slice(1).join("
"))) ||
          ((block && (block.isListItem || block.type === "i")) && !block.isColFirst)
        ) {
          div.classList.add("pdf-list-item");
          const lines = md.split("
");
          let isOrdered = false;
          const items = [];
          const leadLines = [];
          for (let i = 0; i < lines.length; i++) {
            const line = lines[i];
            const tr = line.trim();
            if (!tr || /^{:.*?}$/.test(tr)) continue;
            const um = line.match(/^(s*)[-*+]s+(.*)$/);
            const om = line.match(/^(s*)d+.s+(.*)$/);
            if (um) {
              const indent = um[1].length;
              items.push({ type: "unordered", level: Math.floor(indent / 2), text: um[2], media: [] });
              continue;
            }
            if (om) {
              if (items.length === 0) isOrdered = true;
              const indent = om[1].length;
              items.push({ type: "ordered", level: Math.floor(indent / 2), text: om[2], media: [] });
              continue;
            }
            if (items.length > 0) {
              const im = tr.match(/^![(.*?)]((.*?))(?:{:?[^}]*})?$/);
              if (im) {
                const isGif = /.gif(?:?|$)/i.test(im[2]);
                items[items.length - 1].media.push('<div class="slide-list-media"><img alt="' + im[1] + '" src="' + im[2] + '" class="' + (isGif ? 'list-item-gif' : 'list-item-img') + '" /></div>');
                continue;
              }
              const hm = tr.match(/^<img\b[sS]*?/?>$/i);
              if (hm) {
                const cleanTr = tr.replace(/s+style="[^"]*"/gi, "");
                items[items.length - 1].media.push('<div class="slide-list-media">' + cleanTr + '</div>');
                continue;
              }
              if (/<video\b/i.test(tr)) {
                let vHtml = tr;
                if (!/</video>/i.test(vHtml)) {
                  while (i + 1 < lines.length && !/</video>/i.test(vHtml)) {
                    i++;
                    vHtml += " " + lines[i].trim();
                  }
                }
                const isAutoplay = block && block.attributes && block.attributes["custom-slides-autoplay"] === "true";
                const isLoop = block && block.attributes && block.attributes["custom-slides-loop"] === "true";
                const isMuted = block && block.attributes && (block.attributes["custom-slides-muted"] === "true" || isAutoplay);
                const hideControls = block && block.attributes && block.attributes["custom-slides-controls"] === "false";
                if (hideControls) vHtml = vHtml.replace(/\bcontrols(?:="[^"]*")?/gi, "").trim();
                else if (!vHtml.includes("controls")) vHtml = vHtml.replace("<video", "<video controls");
                if (isAutoplay && !vHtml.includes("autoplay")) vHtml = vHtml.replace("<video", "<video autoplay playsinline");
                if (isLoop && !vHtml.includes("loop")) vHtml = vHtml.replace("<video", "<video loop");
                if (isMuted && !vHtml.includes("muted")) vHtml = vHtml.replace("<video", "<video muted");
                vHtml = vHtml.replace("<video", '<video class="slide-video-player"');
                items[items.length - 1].media.push('<div class="slide-list-media slide-video-container slide-media-container" data-autoplay="' + (isAutoplay ? 'true' : 'false') + '">' + vHtml + '</div>');
                continue;
              }
              items[items.length - 1].text += "
" + tr;
            } else {
              leadLines.push(tr);
            }
          }

          if (items.length === 0 && (block && (block.isListItem || block.type === "i")) && !block.isColFirst) {
            items.push({ type: "unordered", level: 0, text: md, media: [] });
            leadLines.length = 0;
          }

          let leadHtml = "";
          if (leadLines.length > 0) {
            const lParts = [];
            const firstL = leadLines[0];
            const fhm = firstL.match(/^(#{1,6})s+(.*)$/);
            if (fhm) {
              const lvl = fhm[1].length;
              let th = fhm[2].trim().replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
              lParts.push('<h' + lvl + ' class="slide-list-item-title">' + th + '</h' + lvl + '>');
            } else {
              let th = firstL.trim().replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
              lParts.push('<p class="slide-list-item-title">' + th + '</p>');
            }
            if (leadLines.length > 1) {
              const dLines = leadLines.slice(1);
              let pL = [];
              const flushLeadP = () => {
                if (pL.length > 0) {
                  let txt = pL.map(l => l.replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>")).join("<br/>");
                  lParts.push('<p class="slide-list-item-desc">' + txt + '</p>');
                  pL = [];
                }
              };
              for (const l of dLines) {
                const hm = l.match(/^(#{1,6})s+(.*)$/);
                if (hm) {
                  flushLeadP();
                  const lvl = hm[1].length;
                  let th = hm[2].trim().replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
                  lParts.push('<h' + lvl + ' class="slide-list-item-title">' + th + '</h' + lvl + '>');
                } else {
                  pL.push(l);
                }
              }
              flushLeadP();
            }
            leadHtml = lParts.join("
") + "
";
          }

          const tag = isOrdered ? "ol" : "ul";
          const listCls = isOrdered ? "pdf-list pdf-list--ordered" : "pdf-list pdf-list--unordered";
          const liHtml = items.map(it => {
            const med = it.media && it.media.length ? "
" + it.media.join("
") : "";
            const lines = (it.text || "").split("
").map(l => l.trim()).filter(Boolean);
            const hasHeading = lines.some(l => /^#{1,6}s+/.test(l));
            const lvl = it.level || 0;
            const nStyle = lvl > 0 ? ' style="margin-left:' + (lvl * 1.25).toFixed(2) + 'em;' + (it.type === 'unordered' ? 'list-style-type:' + (lvl % 2 === 1 ? 'circle' : 'square') + ' !important;' : '') + '"' : "";
            const nClass = lvl > 0 ? " slide-list-item--nested" : "";
            const clsAttr = nClass ? ' class="' + nClass.trim() + '"' : "";
            if (!hasHeading) {
              let h = lines.map(l => l.replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>")).join("<br/>");
              return '<li' + clsAttr + nStyle + '>' + h + med + '</li>';
            }
            const parts = [];
            let pLines = [];
            const flushP = () => {
              if (pLines.length > 0) {
                let ph = pLines.map(l => l.replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>")).join("<br/>");
                parts.push('<p class="slide-list-item-desc">' + ph + '</p>');
                pLines = [];
              }
            };
            for (const l of lines) {
              const hm = l.match(/^(#{1,6})s+(.*)$/);
              if (hm) {
                flushP();
                const hl = hm[1].length;
                let th = hm[2].trim().replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
                parts.push('<h' + hl + ' class="slide-list-item-title">' + th + '</h' + hl + '>');
              } else {
                pLines.push(l);
              }
            }
            flushP();
            return '<li' + clsAttr + nStyle + '>' + parts.join("
") + med + '</li>';
          }).join("
");
          div.innerHTML = leadHtml + "<" + tag + " class="" + listCls + "">
" + liHtml + "
</" + tag + ">";
        }
        else {
          // 复合块（包含换行、标题或媒体）高保真解析
          const lines = md.split(/\r?
/);
          const subBlocks = [];
          let current = [];
          for (let i = 0; i < lines.length; i++) {
            const line = lines[i];
            const trimmed = line.trim();
            if (/^#{1,6}s+/.test(trimmed)) {
              if (current.length > 0) { subBlocks.push(current.join("
")); current = []; }
              subBlocks.push(trimmed);
              continue;
            }
            if (!trimmed) {
              if (current.length > 0) { subBlocks.push(current.join("
")); current = []; }
              continue;
            }
            if (/^![.*?](.*?)$/.test(trimmed)) {
              if (current.length > 0) { subBlocks.push(current.join("
")); current = []; }
              subBlocks.push(trimmed);
              continue;
            }
            if (/<video\b/i.test(trimmed)) {
              if (current.length > 0) { subBlocks.push(current.join("
")); current = []; }
              let vRaw = trimmed;
              if (!/</video>/i.test(vRaw)) {
                while (i + 1 < lines.length && !/</video>/i.test(vRaw)) {
                  i++;
                  vRaw += "
" + lines[i];
                }
              }
              subBlocks.push(vRaw);
              continue;
            }
            current.push(line);
          }
          if (current.length > 0) subBlocks.push(current.join("
"));

          if (subBlocks.length > 1 || (subBlocks.length === 1 && /^#{1,6}s+/.test(subBlocks[0].trim()))) {
            let isFirstParagraph = true;
            const htmlParts = subBlocks.map(sub => {
              const t = sub.trim();
              if (!t) return "";
              const hm = t.match(/^(#{1,6})s+(.*)$/);
              if (hm) {
                isFirstParagraph = false;
                const hl = hm[1].length;
                let th = hm[2].trim().replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
                return '<h' + hl + ' class="slide-list-item-title">' + th + '</h' + hl + '>';
              }
              const im = t.match(/^![(.*?)]((.*?))$/);
              if (im) {
                return '<div class="slide-media-block slide-media-container slide-list-media"><img alt="' + im[1] + '" src="' + im[2] + '" class="slide-media-img" /></div>';
              }
              if (/<video\b/i.test(t)) {
                return '<div class="slide-media-block slide-video-container slide-media-container">' + t + '</div>';
              }
              if (isFirstParagraph) {
                isFirstParagraph = false;
                const subLines = t.split(/\r?
/).map(l => l.trim()).filter(Boolean);
                if (subLines.length === 1) {
                  let ph = subLines[0].replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
                  return '<p class="slide-list-item-title">' + ph + '</p>';
                }
                let titleHtml = subLines[0].replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
                let descHtml = subLines.slice(1).map(l => l.replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>")).join("<br/>");
                return '<p class="slide-list-item-title">' + titleHtml + '</p>
<p class="slide-list-item-desc">' + descHtml + '</p>';
              }
              let ph = t.replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
              return '<p class="slide-list-item-desc">' + ph + '</p>';
            }).filter(Boolean);
            div.innerHTML = htmlParts.join("
");
          } else {
            const imgMatch = md.match(/!\\[(.*?)\\]\\((.*?)\\)/);
            if (imgMatch) {
              div.classList.add("slide-media-container", "slide-media-block", "slide-block--image");
              div.innerHTML = '<img alt="' + imgMatch[1] + '" src="' + imgMatch[2] + '" class="slide-media-img" />';
            } else {
              let html = md.replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
              const pCls = (block && block.isColFirst) ? ' class="slide-list-item-title"' : '';
              div.innerHTML = "<p" + pCls + ">" + html + "</p>";
            }
          }
        }
        return div;
      }

`}function ng(){return`      function renderSlide(idx, direction) {
        if (slides.length === 0) return;
        currentIndex = Math.max(0, Math.min(idx, slides.length - 1));
        const slide = slides[currentIndex];
        pageNum.textContent = (currentIndex + 1) + " / " + slides.length;

        const pageSp = slide.frontmatter?.spacing;
        const currentSpacing = (pageSp && pageSp !== "inherit") ? pageSp : (data.config?.spacing || "normal");
        container.className = "slide-content layout-" + (slide.frontmatter?.layout || "default") + " spacing-" + currentSpacing;
        if (viewport) viewport.setAttribute("data-spacing", currentSpacing);
        container.innerHTML = "";

        const z = typeof slide.frontmatter?.zoom === "number" && slide.frontmatter.zoom > 0 ? slide.frontmatter.zoom : 1;
        if (z !== 1) {
          container.style.width = (100 / z) + "%";
          container.style.height = (100 / z) + "%";
          container.style.transformOrigin = "top left";
          container.style.transform = "scale(" + z + ")";
        } else {
          container.style.width = "100%";
          container.style.height = "100%";
          container.style.transform = "none";
        }

        maskOverlayEl = null;
        maskDividerEl = null;
        const maskDir = slide.frontmatter?.mask;
        const isClock = maskDir === "clockwise" || maskDir === "counter-clockwise" || maskDir === "cw" || maskDir === "ccw";
        if (maskDir === "down" || maskDir === "right" || isClock) {
          const isClover = slide.frontmatter?.layout === "clover";
          const ratioInfo = parseMaskRatio(slide.frontmatter.maskRatio, (isClock || isClover) ? 4 : 2);
          const isInitRev = slide.frontmatter.maskInitial === "revealed";
          currentMaskConfig = {
            direction: isClock ? ((maskDir === "cw" || maskDir === "clockwise") ? "clockwise" : "counter-clockwise") : maskDir,
            isClock: isClock,
            totalSteps: isInitRev ? Math.max(0, ratioInfo.steps - 1) : ratioInfo.steps,
            rawSteps: ratioInfo.steps,
            breakpoints: ratioInfo.breakpoints,
            isInitialRevealed: isInitRev,
            style: slide.frontmatter.maskStyle || "solid",
          };
          // FSM-9 优化：后退进入历史页时，遮罩与逐步呈现处于全部揭开完成状态，避免上一页重新变为全黑遮盖
          currentMaskStep = (direction === "backward") ? currentMaskConfig.totalSteps : 0;
        } else {
          currentMaskConfig = null;
          currentMaskStep = 0;
        }

        function createMaskElements() {
          if (!currentMaskConfig) return null;
          const layer = document.createElement("div");
          layer.className = "slides-mask-layer slides-mask-layer--" + currentMaskConfig.style + " slides-mask-layer--" + currentMaskConfig.direction + (currentMaskConfig.isClock ? " slides-mask-layer--clock" : "");
          const overlay = document.createElement("div");
          overlay.className = "slides-mask-overlay";
          const divider = document.createElement("div");
          divider.className = "slides-mask-divider-line" + (currentMaskConfig.isClock ? " slides-mask-divider-line--clock" : "");
          divider.style.opacity = "0";
          if (currentMaskConfig.isClock) {
            const isCw = currentMaskConfig.direction === "clockwise" || currentMaskConfig.direction === "cw";
            divider.style.transform = isCw ? "translateY(-50%) rotate(-180deg)" : "translateY(-50%) rotate(-90deg)";
          }
          layer.appendChild(overlay);
          layer.appendChild(divider);
          maskLayerEl = layer;
          maskOverlayEl = overlay;
          maskDividerEl = divider;
          return { layer, overlay, divider };
        }

        if (slide.frontmatter?.layout === "two-cols") {
          const bodyWrap = document.createElement("div");
          bodyWrap.className = "slides-mask-body-container" + (currentMaskConfig ? " slides-mask-body-container--has-mask" : "");
          bodyWrap.style.display = "flex";
          bodyWrap.style.flexDirection = "row";
          bodyWrap.style.gap = "2rem";
          bodyWrap.style.width = "100%";
          bodyWrap.style.height = "100%";

          const leftCol = document.createElement("div");
          leftCol.className = "two-cols-left";
          const rightCol = document.createElement("div");
          rightCol.className = "two-cols-right";

          const blocks = (slide.blocks || []).filter(b => b.slot !== "slot-divider-right");
          let leftList = [];
          let rightList = [];
          for (const block of blocks) {
            if (block.slot === "right") rightList.push(block);
            else leftList.push(block);
          }
          leftList = cleanColList(leftList);
          rightList = cleanColList(rightList);
          const isCover = slide.frontmatter?.layout === "cover";
          const leftFirstH = !isCover ? leftList.find(isHeadingBlock) : null;
          const rightFirstH = !isCover ? rightList.find(isHeadingBlock) : null;
          for (const b of leftList) leftCol.appendChild(renderBlock(b, b === leftFirstH ? "slides-col-first-heading-block" : ""));
          for (const b of rightList) rightCol.appendChild(renderBlock(b, b === rightFirstH ? "slides-col-first-heading-block" : ""));
          bodyWrap.appendChild(leftCol);
          bodyWrap.appendChild(rightCol);

          const maskEls = createMaskElements();
          if (maskEls) {
            bodyWrap.appendChild(maskEls.layer);
          }
          container.appendChild(bodyWrap);
        } else if (slide.frontmatter?.layout === "cols-header" || slide.frontmatter?.layout === "two-cols-header" || slide.frontmatter?.layout === "three-cols-header" || slide.frontmatter?.layout === "clover") {
          const isCover = slide.frontmatter?.layout === "cover";
          const isClover = slide.frontmatter?.layout === "clover";
          const blocks = (slide.blocks || []).filter(b => b.slot !== "slot-divider-right");
          let headerBlocks = blocks.filter(b => b.slot === "header");
          if (headerBlocks.length === 0 && blocks.length > 0) {
            const candidate = blocks.find(b => b.type === "h" && (!b.slot || b.slot === "default"));
            if (candidate) headerBlocks = [candidate];
          }
          const rem = blocks.filter(b => !headerBlocks.includes(b));

          let targetCols = isClover ? 4 : 2;
          if (isClover) {
            targetCols = 4;
          } else if (slide.frontmatter?.layout === "three-cols-header") {
            targetCols = 3;
          } else if (slide.frontmatter?.layout === "two-cols-header") {
            targetCols = 2;
          } else {
            let maxCol = 0;
            for (const b of rem) {
              const m = (b.slot || "").match(/^col-(d+)$/i);
              if (m) maxCol = Math.max(maxCol, parseInt(m[1], 10));
            }
            if (maxCol >= 2) {
              targetCols = maxCol;
            } else if (slide.frontmatter?.layoutRatio) {
              const r = slide.frontmatter.layoutRatio.trim();
              if (r.includes(":")) {
                const parts = r.split(":").map(p => parseFloat(p.trim())).filter(n => !isNaN(n) && n > 0);
                if (parts.length >= 2) targetCols = parts.length;
              }
            }
          }

          const hasColSlots = rem.some(b => b.slot && /^col-d+$/i.test(b.slot));
          const isSuperBlockCols = isClover || hasColSlots;

          const containerDiv = document.createElement("div");
          containerDiv.className = (isClover ? "layout-clover-container" : ("layout-cols-header-container " + (targetCols === 2 ? "layout-two-cols-header-container" : (targetCols === 3 ? "layout-three-cols-header-container" : "")))) + (isSuperBlockCols ? " has-superblock-cols" : "");
          const headerDiv = document.createElement("div");
          headerDiv.className = "layout-header-section";
          const gridDiv = document.createElement("div");
          gridDiv.className = (isClover ? "layout-clover-grid pdf-clover-wrapper" : ("layout-cols-wrapper layout-cols-grid " + (targetCols === 2 ? "pdf-two-cols-wrapper layout-two-cols-grid" : (targetCols === 3 ? "pdf-three-cols-wrapper layout-three-cols-grid" : "")))) + (isSuperBlockCols ? " has-superblock-cols" : "") + (currentMaskConfig ? " slides-mask-body-container slides-mask-body-container--has-mask" : "");

          const gridCols = isClover ? "repeat(2, minmax(0, 1fr))" : parseRatioToGridCols(slide.frontmatter?.layoutRatio, targetCols);
          if (gridCols) gridDiv.style.gridTemplateColumns = gridCols;
          if (isClover) gridDiv.style.gridTemplateRows = "repeat(2, minmax(0, 1fr))";

          let colsList = [];
          for (let i = 0; i < targetCols; i++) colsList.push([]);
          const hasExplicitCols = rem.some(b => b.slot && (b.slot.startsWith("col-") || b.slot === "left" || b.slot === "right" || b.slot === "center"));
          if (hasExplicitCols && rem.length > 1) {
            for (const b of rem) {
              let idx = 0;
              if (b.slot === "left" || b.slot === "col-1") idx = 0;
              else if (b.slot === "center" || b.slot === "col-2") idx = 1;
              else if (b.slot === "right") idx = targetCols === 2 ? 1 : targetCols - 1;
              else {
                const m = (b.slot || "").match(/^col-(d+)$/i);
                if (m) idx = Math.min(targetCols - 1, Math.max(0, parseInt(m[1], 10) - 1));
              }
              colsList[idx].push(b);
            }
            const hasExplicitColN = rem.some(b => /^col-d+$/i.test((b.slot || "").trim()));
            if (!hasExplicitColN && colsList[0].length === 0) {
              const nonEmptyCols = colsList.filter(c => c.length > 0);
              if (nonEmptyCols.length === 1) {
                colsList = [nonEmptyCols[0], ...Array.from({ length: targetCols - 1 }, () => [])];
              }
            }
          } else if (rem.length === 1) {
            colsList[0] = [rem[0]];
          } else {
            let cur = 0;
            for (let i = 0; i < targetCols; i++) {
              const remainingCols = targetCols - i;
              const remainingItems = rem.length - cur;
              const take = Math.ceil(remainingItems / remainingCols);
              colsList[i] = rem.slice(cur, cur + take);
              cur += take;
            }
          }

          const headerFirstH = !isCover ? headerBlocks.find(isHeadingBlock) : null;
          for (const b of headerBlocks) headerDiv.appendChild(renderBlock(b, b === headerFirstH ? "slides-page-first-heading-block" : ""));
          containerDiv.appendChild(headerDiv);

          colsList.forEach((colBlocks, idx) => {
            const colDiv = document.createElement("div");
            colDiv.className = "pdf-col pdf-col--" + (idx + 1) + " col-" + (idx + 1) + (targetCols === 2 && idx === 0 ? " pdf-col--left" : "") + (targetCols === 2 && idx === 1 ? " pdf-col--right" : "");
            const cleaned = cleanColList(colBlocks);
            const colFirstH = !isCover ? (cleaned.find(isHeadingBlock) || cleaned[0]) : null;
            for (const b of cleaned) colDiv.appendChild(renderBlock(b, b === colFirstH ? "slides-col-first-heading-block" : ""));
            gridDiv.appendChild(colDiv);
          });

          const maskEls = createMaskElements();
          if (maskEls) {
            gridDiv.appendChild(maskEls.layer);
          }

          containerDiv.appendChild(gridDiv);
          container.appendChild(containerDiv);
        } else if (slide.frontmatter?.layout === "image-right" || slide.frontmatter?.layout === "image-left") {
          const isImageRight = slide.frontmatter?.layout === "image-right";
          const isCover = slide.frontmatter?.layout === "cover";
          const allBlocks = slide.blocks || [];
          const pageFirstH = !isCover ? allBlocks.find(isHeadingBlock) : null;

          if (pageFirstH) {
            container.appendChild(renderBlock(pageFirstH, "slides-page-first-heading-block"));
          }

          const bodyWrap = document.createElement("div");
          bodyWrap.className = "slides-mask-body-container" + (currentMaskConfig ? " slides-mask-body-container--has-mask" : "");
          bodyWrap.style.display = "flex";
          bodyWrap.style.flexDirection = isImageRight ? "row" : "row-reverse";
          bodyWrap.style.gap = "2rem";
          bodyWrap.style.width = "100%";
          bodyWrap.style.height = "100%";
          bodyWrap.style.minHeight = "0";
          bodyWrap.style.flex = "1";

          const contentCol = document.createElement("div");
          contentCol.className = isImageRight ? "image-right-content" : "image-left-content";

          for (const block of allBlocks) {
            if (block === pageFirstH) continue;
            contentCol.appendChild(renderBlock(block, ""));
          }

          const imgCol = document.createElement("div");
          imgCol.className = isImageRight ? "image-right-img-container" : "image-left-img-container";
          const img = document.createElement("img");
          img.className = isImageRight ? "image-right-img" : "image-left-img";
          img.src = slide.frontmatter?.image || slide.frontmatter?.background || "";
          img.alt = "Slide cover";
          img.onerror = function() {
            this.src = "https://fastly.jsdelivr.net/gh/slidevjs/slidev-covers@main/static/2HmfbSpvcos.webp";
          };
          imgCol.appendChild(img);

          bodyWrap.appendChild(contentCol);
          bodyWrap.appendChild(imgCol);

          const maskEls = createMaskElements();
          if (maskEls) {
            bodyWrap.appendChild(maskEls.layer);
          }
          container.appendChild(bodyWrap);
        } else {
          const isCover = slide.frontmatter?.layout === "cover";
          const validBlocks = (slide.blocks || []).filter(b => b.slot !== "slot-divider-right");
          const pageFirstH = !isCover ? validBlocks.find(isHeadingBlock) : null;

          if (pageFirstH) {
            container.appendChild(renderBlock(pageFirstH, "slides-page-first-heading-block"));
          }

          const bodyWrap = document.createElement("div");
          bodyWrap.className = "slides-mask-body-container" + (currentMaskConfig ? " slides-mask-body-container--has-mask" : "");

          for (const block of validBlocks) {
            if (block === pageFirstH) continue;
            bodyWrap.appendChild(renderBlock(block, ""));
          }

          const maskEls = createMaskElements();
          if (maskEls) {
            bodyWrap.appendChild(maskEls.layer);
          }
          container.appendChild(bodyWrap);
        }

        updateMaskVisual();
        if (currentMaskConfig && maskLayerEl) {
          requestAnimationFrame(() => {
            if (maskLayerEl) void maskLayerEl.offsetHeight;
          });
        }

        function syncAutoplayVideos() {
          const doSync = () => {
            const videos = container.querySelectorAll("video");
            videos.forEach((v) => {
              const box = v.closest("[data-autoplay]");
              const isAuto = v.hasAttribute("autoplay") || v.autoplay || (box && box.getAttribute("data-autoplay") === "true");
              if (isAuto) {
                v.muted = true;
                v.defaultMuted = true;
                v.setAttribute("muted", "");
                v.playsInline = true;
                v.setAttribute("playsinline", "");
                const playFn = () => {
                  if (!v.paused) return;
                  v.muted = true;
                  v.defaultMuted = true;
                  const p = v.play();
                  if (p !== undefined) {
                    p.catch(() => {
                      v.muted = true;
                      v.defaultMuted = true;
                      setTimeout(() => { if (v.paused) v.play().catch(() => {}); }, 150);
                    });
                  }
                };
                playFn();
                if (!v.__autoplayBound) {
                  v.__autoplayBound = true;
                  v.addEventListener("loadedmetadata", playFn);
                  v.addEventListener("canplay", playFn);
                }
              }
            });
          };
          setTimeout(doSync, 60);
          setTimeout(doSync, 200);
        }
        syncAutoplayVideos();
      }

      // Lightbox 控制逻辑
      const lightbox = document.getElementById("slides-lightbox");
      const lightboxContent = document.getElementById("lightbox-content");
      const lightboxClose = document.getElementById("lightbox-close");
      let isLightboxOpen = false;

`}function sg(){return`      let lightboxScale = 1.0;
      let lightboxTranslateX = 0;
      let lightboxTranslateY = 0;
      let isLightboxDragging = false;
      let lightboxDragStartX = 0;
      let lightboxDragStartY = 0;
      let lightboxInitialTx = 0;
      let lightboxInitialTy = 0;
      let lightboxHasMoved = false;
      let lightboxMediaType = "";

      function updateLightboxImgTransform(animate) {
        if (!lightboxContent) return;
        const img = lightboxContent.querySelector(".slides-lightbox-img");
        if (!img) return;
        img.style.transformOrigin = "center center";
        img.style.transform = "translate(" + lightboxTranslateX + "px, " + lightboxTranslateY + "px) scale(" + lightboxScale + ")";
        img.style.transition = animate ? "transform 0.12s cubic-bezier(0.16, 1, 0.3, 1)" : "none";
        img.style.cursor = lightboxScale > 1.0 ? (isLightboxDragging ? "grabbing" : "grab") : "zoom-in";
      }

      function resetLightboxZoom() {
        lightboxScale = 1.0;
        lightboxTranslateX = 0;
        lightboxTranslateY = 0;
        isLightboxDragging = false;
        lightboxHasMoved = false;
        updateLightboxImgTransform(false);
      }

      function openLightbox(type, src, alt) {
        if (!lightbox || !lightboxContent) return;
        lightboxContent.innerHTML = "";
        lightboxMediaType = type;
        resetLightboxZoom();
        if (type === "video") {
          const v = document.createElement("video");
          v.className = "slides-lightbox-video";
          v.src = src;
          v.controls = true;
          v.autoplay = true;
          v.playsInline = true;
          lightboxContent.appendChild(v);
        } else {
          const img = document.createElement("img");
          img.className = "slides-lightbox-img";
          img.src = src;
          img.alt = alt || "";
          lightboxContent.appendChild(img);
          updateLightboxImgTransform(false);
        }
        lightbox.classList.add("active");
        isLightboxOpen = true;
      }

      function closeLightbox() {
        if (!lightbox) return;
        const v = lightbox.querySelector("video");
        if (v) v.pause();
        lightbox.classList.remove("active");
        if (lightboxContent) lightboxContent.innerHTML = "";
        isLightboxOpen = false;
        lightboxMediaType = "";
        resetLightboxZoom();
      }

      function handleLightboxWheel(e) {
        if (!lightboxContent || lightboxMediaType !== "image") return;
        const img = lightboxContent.querySelector(".slides-lightbox-img");
        if (!img) return;
        e.preventDefault();
        e.stopPropagation();
        if (Math.abs(e.deltaY) < 1) return;

        const factor = e.deltaY < 0 ? 1.2 : 1 / 1.2;
        const currentScale = lightboxScale;
        let nextScale = currentScale * factor;

        if (nextScale <= 1.02) {
          resetLightboxZoom();
          return;
        }
        if (nextScale > 5.0) {
          nextScale = 5.0;
        }

        const rect = img.getBoundingClientRect();
        const currentCenterX = rect.left + rect.width / 2;
        const currentCenterY = rect.top + rect.height / 2;
        const origCenterX = currentCenterX - lightboxTranslateX;
        const origCenterY = currentCenterY - lightboxTranslateY;

        const nextTx = (e.clientX - origCenterX) * (1 - nextScale / currentScale) + lightboxTranslateX * (nextScale / currentScale);
        const nextTy = (e.clientY - origCenterY) * (1 - nextScale / currentScale) + lightboxTranslateY * (nextScale / currentScale);

        lightboxTranslateX = Math.round(nextTx * 10) / 10;
        lightboxTranslateY = Math.round(nextTy * 10) / 10;
        lightboxScale = Math.round(nextScale * 1000) / 1000;
        updateLightboxImgTransform(true);
      }

      if (lightboxContent) {
        lightboxContent.addEventListener("pointerdown", (e) => {
          if (e.button !== 0 || lightboxMediaType !== "image" || lightboxScale <= 1.0) return;
          const img = lightboxContent.querySelector(".slides-lightbox-img");
          if (!img || (e.target !== img && !img.contains(e.target))) return;
          e.preventDefault();
          e.stopPropagation();
          isLightboxDragging = true;
          lightboxDragStartX = e.clientX;
          lightboxDragStartY = e.clientY;
          lightboxInitialTx = lightboxTranslateX;
          lightboxInitialTy = lightboxTranslateY;
          lightboxHasMoved = false;
          if (img.setPointerCapture) {
            try { img.setPointerCapture(e.pointerId); } catch (_) {}
          }
          updateLightboxImgTransform(false);
        });

        window.addEventListener("pointermove", (e) => {
          if (!isLightboxDragging || lightboxMediaType !== "image") return;
          e.preventDefault();
          e.stopPropagation();
          const dx = e.clientX - lightboxDragStartX;
          const dy = e.clientY - lightboxDragStartY;
          if (Math.abs(dx) > 3 || Math.abs(dy) > 3) {
            lightboxHasMoved = true;
          }
          lightboxTranslateX = Math.round((lightboxInitialTx + dx) * 10) / 10;
          lightboxTranslateY = Math.round((lightboxInitialTy + dy) * 10) / 10;
          updateLightboxImgTransform(false);
        });

        const onLightboxPointerEnd = (e) => {
          if (!isLightboxDragging) return;
          isLightboxDragging = false;
          const img = lightboxContent ? lightboxContent.querySelector(".slides-lightbox-img") : null;
          if (img && img.releasePointerCapture) {
            try { img.releasePointerCapture(e.pointerId); } catch (_) {}
          }
          updateLightboxImgTransform(false);
        };
        window.addEventListener("pointerup", onLightboxPointerEnd);
        window.addEventListener("pointercancel", onLightboxPointerEnd);

        lightboxContent.addEventListener("dblclick", (e) => {
          if (lightboxMediaType !== "image") return;
          const img = lightboxContent.querySelector(".slides-lightbox-img");
          if (!img || (e.target !== img && !img.contains(e.target))) return;
          e.preventDefault();
          e.stopPropagation();
          if (lightboxScale > 1.05 || lightboxTranslateX !== 0 || lightboxTranslateY !== 0) {
            resetLightboxZoom();
          } else {
            const targetScale = 2.0;
            const rect = img.getBoundingClientRect();
            const currentCenterX = rect.left + rect.width / 2;
            const currentCenterY = rect.top + rect.height / 2;
            const origCenterX = currentCenterX - lightboxTranslateX;
            const origCenterY = currentCenterY - lightboxTranslateY;
            lightboxTranslateX = Math.round(((e.clientX - origCenterX) * (1 - targetScale / 1.0)) * 10) / 10;
            lightboxTranslateY = Math.round(((e.clientY - origCenterY) * (1 - targetScale / 1.0)) * 10) / 10;
            lightboxScale = targetScale;
            updateLightboxImgTransform(true);
          }
        });
      }

      if (lightboxClose) {
        lightboxClose.addEventListener("click", (e) => {
          e.stopPropagation();
          closeLightbox();
        });
      }
      if (lightbox) {
        lightbox.addEventListener("click", (e) => {
          if (e.target === lightbox || e.target === lightboxClose) {
            if (lightboxHasMoved) {
              lightboxHasMoved = false;
              return;
            }
            e.stopPropagation();
            closeLightbox();
          }
        });
      }

      btnPrev.addEventListener("click", () => goPrev());
      btnNext.addEventListener("click", () => goNext());
      btnFullscreen.addEventListener("click", () => {
        if (!document.fullscreenElement) {
          document.documentElement.requestFullscreen().then(() => updateScale()).catch(() => {});
        } else {
          document.exitFullscreen().then(() => updateScale()).catch(() => {});
        }
      });

      // 「数字+回车」跳页输入状态：数字缓冲实时回显，Esc/超时清空，越界红色抖动提示
      let jumpDisplay = "";
      let jumpInvalid = false;
      let jumpIdleTimer = null;
      let jumpFlashTimer = null;

`}function og(){return`      function hideJumpIndicator() {
        jumpDisplay = "";
        jumpInvalid = false;
        jumpBadge.style.display = "none";
        jumpBadge.classList.remove("is-invalid");
        if (jumpIdleTimer) { clearTimeout(jumpIdleTimer); jumpIdleTimer = null; }
        if (jumpFlashTimer) { clearTimeout(jumpFlashTimer); jumpFlashTimer = null; }
      }

      function renderJumpBadge() {
        jumpBadge.textContent = jumpDisplay;
        jumpBadge.style.display = jumpDisplay ? "block" : "none";
        jumpBadge.classList.toggle("is-invalid", jumpInvalid);
      }

      function armJumpIdleTimer() {
        if (jumpIdleTimer) clearTimeout(jumpIdleTimer);
        jumpIdleTimer = setTimeout(hideJumpIndicator, 1500);
      }

      function flashJumpInvalid() {
        if (jumpIdleTimer) { clearTimeout(jumpIdleTimer); jumpIdleTimer = null; }
        jumpInvalid = true;
        renderJumpBadge();
        if (jumpFlashTimer) clearTimeout(jumpFlashTimer);
        jumpFlashTimer = setTimeout(hideJumpIndicator, 500);
      }

      function isEditableKeyTarget(t) {
        if (!t || !t.tagName) return false;
        return t.tagName === "INPUT" || t.tagName === "TEXTAREA" || t.tagName === "SELECT" || t.isContentEditable === true;
      }

`}function rg(){return`      function getSlideOverviewTitle(slide) {
        const fm = slide?.frontmatter || {};
        if (fm.title) return String(fm.title);
        const blocks = slide?.blocks || [];
        for (const b of blocks) {
          if (b.type === "h" || /^h[1-6]$/i.test(b.subType || "")) {
            const md = (b.rawMarkdown || b.content || "").trim();
            return md.replace(/^#{1,6}s+/, "").replace(/[*_\`]/g, "").slice(0, 40);
          }
        }
        return "";
      }

      // 把任意一页渲染为静态缩略图：复用 renderBlock 与主渲染同名版式类，导出样式自动生效
      function buildOverviewThumbInto(canvas, slide) {
        const fm = slide.frontmatter || {};
        const layout = fm.layout || "default";
        const blocks = (slide.blocks || []).filter((b) => b.slot !== "slot-divider-right");
        let headerBlocks = blocks.filter((b) => b.slot === "header");
        if (headerBlocks.length === 0 && blocks.length > 0) {
          const candidate = blocks.find((b) => b.type === "h" && (!b.slot || b.slot === "default"));
          if (candidate) headerBlocks = [candidate];
        }
        const rem = blocks.filter((b) => !headerBlocks.includes(b));
        let bodyEl = null;

        if (layout === "cols-header" || layout === "two-cols-header" || layout === "three-cols-header" || layout === "clover") {
          const isClover = layout === "clover";
          let targetCols = isClover ? 4 : 2;
          if (layout === "three-cols-header") targetCols = 3;
          else if (layout === "two-cols-header") targetCols = 2;
          else if (!isClover) {
            let maxCol = 0;
            for (const b of rem) {
              const m = (b.slot || "").match(/^col-(d+)$/i);
              if (m) maxCol = Math.max(maxCol, parseInt(m[1], 10));
            }
            if (maxCol >= 2) targetCols = maxCol;
            else if (fm.layoutRatio) {
              const r = String(fm.layoutRatio).trim();
              if (r.includes(":")) {
                const parts = r.split(":").map((p) => parseFloat(p.trim())).filter((n) => !isNaN(n) && n > 0);
                if (parts.length >= 2) targetCols = parts.length;
              }
            }
          }
          const hasColSlots = rem.some((b) => b.slot && /^col-d+$/i.test(b.slot));
          const containerDiv = document.createElement("div");
          containerDiv.className = (isClover ? "layout-clover-container" : ("layout-cols-header-container " + (targetCols === 2 ? "layout-two-cols-header-container" : (targetCols === 3 ? "layout-three-cols-header-container" : "")))) + (hasColSlots || isClover ? " has-superblock-cols" : "");
          const headerDiv = document.createElement("div");
          headerDiv.className = "layout-header-section";
          for (const b of headerBlocks) headerDiv.appendChild(renderBlock(b, ""));
          containerDiv.appendChild(headerDiv);
          const gridDiv = document.createElement("div");
          gridDiv.className = (isClover ? "layout-clover-grid pdf-clover-wrapper" : ("layout-cols-wrapper layout-cols-grid " + (targetCols === 2 ? "pdf-two-cols-wrapper layout-two-cols-grid" : (targetCols === 3 ? "pdf-three-cols-wrapper layout-three-cols-grid" : "")))) + (hasColSlots || isClover ? " has-superblock-cols" : "");
          const gridCols = isClover ? "repeat(2, minmax(0, 1fr))" : parseRatioToGridCols(fm.layoutRatio, targetCols);
          if (gridCols) gridDiv.style.gridTemplateColumns = gridCols;
          if (isClover) gridDiv.style.gridTemplateRows = "repeat(2, minmax(0, 1fr))";
          let colsList = [];
          for (let i = 0; i < targetCols; i++) colsList.push([]);
          const hasExplicitCols = rem.some((b) => b.slot && (b.slot.startsWith("col-") || b.slot === "left" || b.slot === "right" || b.slot === "center"));
          if (hasExplicitCols && rem.length > 1) {
            for (const b of rem) {
              let idx = 0;
              if (b.slot === "left" || b.slot === "col-1") idx = 0;
              else if (b.slot === "center" || b.slot === "col-2") idx = 1;
              else if (b.slot === "right") idx = targetCols === 2 ? 1 : targetCols - 1;
              else {
                const m = (b.slot || "").match(/^col-(d+)$/i);
                if (m) idx = Math.min(targetCols - 1, Math.max(0, parseInt(m[1], 10) - 1));
              }
              colsList[idx].push(b);
            }
            const hasExplicitColN = rem.some(b => /^col-d+$/i.test((b.slot || "").trim()));
            if (!hasExplicitColN && colsList[0].length === 0) {
              const nonEmptyCols = colsList.filter(c => c.length > 0);
              if (nonEmptyCols.length === 1) {
                colsList = [nonEmptyCols[0], ...Array.from({ length: targetCols - 1 }, () => [])];
              }
            }
          } else if (rem.length === 1) {
            colsList[0] = [rem[0]];
          } else {
            let cur = 0;
            for (let i = 0; i < targetCols; i++) {
              const remainingCols = targetCols - i;
              const remainingItems = rem.length - cur;
              const take = Math.ceil(remainingItems / remainingCols);
              colsList[i] = rem.slice(cur, cur + take);
              cur += take;
            }
          }
          colsList.forEach((colBlocks, idx) => {
            const colDiv = document.createElement("div");
            colDiv.className = "pdf-col pdf-col--" + (idx + 1) + " col-" + (idx + 1) + (targetCols === 2 && idx === 0 ? " pdf-col--left" : "") + (targetCols === 2 && idx === 1 ? " pdf-col--right" : "");
            const cleaned = cleanColList(colBlocks);
            for (const b of cleaned) colDiv.appendChild(renderBlock(b, ""));
            gridDiv.appendChild(colDiv);
          });
          containerDiv.appendChild(gridDiv);
          bodyEl = containerDiv;
        } else if (layout === "two-cols") {
          bodyEl = document.createElement("div");
          bodyEl.style.display = "flex";
          bodyEl.style.flexDirection = "row";
          bodyEl.style.gap = "2rem";
          bodyEl.style.width = "100%";
          bodyEl.style.flex = "1";
          bodyEl.style.minHeight = "0";
          let leftList = [];
          let rightList = [];
          for (const b of blocks) {
            if (b.slot === "right") rightList.push(b);
            else leftList.push(b);
          }
          const leftCol = document.createElement("div");
          leftCol.className = "two-cols-left";
          const rightCol = document.createElement("div");
          rightCol.className = "two-cols-right";
          for (const b of cleanColList(leftList)) leftCol.appendChild(renderBlock(b, ""));
          for (const b of cleanColList(rightList)) rightCol.appendChild(renderBlock(b, ""));
          bodyEl.appendChild(leftCol);
          bodyEl.appendChild(rightCol);
        } else if (layout === "image-right" || layout === "image-left") {
          const isImageRight = layout === "image-right";
          bodyEl = document.createElement("div");
          bodyEl.style.display = "flex";
          bodyEl.style.flexDirection = isImageRight ? "row" : "row-reverse";
          bodyEl.style.gap = "2rem";
          bodyEl.style.width = "100%";
          bodyEl.style.flex = "1";
          bodyEl.style.minHeight = "0";
          const contentCol = document.createElement("div");
          contentCol.className = isImageRight ? "image-right-content" : "image-left-content";
          for (const b of blocks) contentCol.appendChild(renderBlock(b, ""));
          const imgCol = document.createElement("div");
          imgCol.className = isImageRight ? "image-right-img-container" : "image-left-img-container";
          const url = fm.image || fm.background || "";
          if (url) {
            const img = document.createElement("img");
            img.className = isImageRight ? "image-right-img" : "image-left-img";
            img.src = url;
            img.alt = "Slide cover";
            imgCol.appendChild(img);
          }
          bodyEl.appendChild(contentCol);
          bodyEl.appendChild(imgCol);
        } else {
          bodyEl = document.createElement("div");
          for (const b of blocks) bodyEl.appendChild(renderBlock(b, ""));
        }
        canvas.appendChild(bodyEl);
      }

      function buildOverviewCards() {
        if (overviewBuilt) return;
        overviewBuilt = true;
        const scale = OVERVIEW_CARD_W / baseWidth;
        const canvasH = Math.round(baseHeight * scale);
        slides.forEach((slide, idx) => {
          const card = document.createElement("div");
          card.className = "slides-overview-card";
          card.dataset.idx = String(idx);
          const box = document.createElement("div");
          box.className = "slides-overview-canvas-box";
          box.style.height = canvasH + "px";
          const fm = slide.frontmatter || {};
          const spacing = (fm.spacing && fm.spacing !== "inherit") ? fm.spacing : ((data.config && data.config.spacing) || "normal");
          const canvas = document.createElement("div");
          canvas.className = "slides-overview-canvas slide-content layout-" + (fm.layout || "default") + " spacing-" + spacing;
          canvas.style.width = baseWidth + "px";
          canvas.style.height = baseHeight + "px";
          canvas.style.transform = "scale(" + scale + ")";
          const bg = fm.background;
          if (bg) {
            if (/^(http|/|data:|assets/)/.test(bg)) {
              canvas.style.backgroundImage = 'url("' + bg + '")';
              canvas.style.backgroundSize = "cover";
              canvas.style.backgroundPosition = "center";
            } else {
              canvas.style.background = bg;
            }
          }
          box.appendChild(canvas);
          const caption = document.createElement("div");
          caption.className = "slides-overview-caption";
          const pageNo = document.createElement("span");
          pageNo.className = "slides-overview-page-no";
          pageNo.textContent = String(idx + 1);
          caption.appendChild(pageNo);
          const title = getSlideOverviewTitle(slide);
          if (title) {
            const titleEl = document.createElement("span");
            titleEl.className = "slides-overview-title";
            titleEl.textContent = title;
            caption.appendChild(titleEl);
          }
          card.appendChild(box);
          card.appendChild(caption);
          card.addEventListener("click", (e) => {
            e.stopPropagation();
            goFromOverview(idx + 1);
          });
          overviewGrid.appendChild(card);
        });
        updateOverviewCurrentMark();
      }

      function renderOverviewThumb(card) {
        if (!card || card.dataset.rendered === "1") return;
        const idx = Number(card.dataset.idx);
        const slide = slides[idx];
        const canvas = card.querySelector(".slides-overview-canvas");
        if (slide && canvas) buildOverviewThumbInto(canvas, slide);
        card.dataset.rendered = "1";
      }

      function ensureOverviewObserver() {
        if (overviewObserver || typeof window.IntersectionObserver !== "function") return;
        overviewObserver = new IntersectionObserver((entries) => {
          for (const en of entries) {
            if (!en.isIntersecting) continue;
            overviewObserver.unobserve(en.target);
            renderOverviewThumb(en.target);
          }
        }, { rootMargin: "240px" });
      }

      function observeOverviewCards() {
        if (!overviewObserver) return;
        const cards = overviewGrid.children;
        for (let i = 0; i < cards.length; i++) {
          if (cards[i].dataset.rendered !== "1") overviewObserver.observe(cards[i]);
        }
      }

      function updateOverviewCurrentMark() {
        const cards = overviewGrid.children;
        for (let i = 0; i < cards.length; i++) {
          const pageNo = cards[i].querySelector(".slides-overview-page-no");
          if (pageNo) pageNo.classList.toggle("is-current", i === currentIndex);
        }
      }

      function setOverviewFocus(page) {
        const total = slides.length || 1;
        overviewFocus = Math.min(Math.max(1, page), total);
        const cards = overviewGrid.children;
        for (let i = 0; i < cards.length; i++) {
          cards[i].classList.toggle("is-active", i + 1 === overviewFocus);
        }
        const el = cards[overviewFocus - 1];
        if (el && el.scrollIntoView) el.scrollIntoView({ block: "nearest", behavior: "smooth" });
      }

      function getOverviewCols() {
        if (!overviewGrid || !overviewGrid.clientWidth) return 1;
        return Math.max(1, Math.round(overviewGrid.clientWidth / (OVERVIEW_CARD_W + 18)));
      }

      function goFromOverview(page) {
        const p = parseInt(page, 10);
        if (isNaN(p) || p < 1 || p > slides.length) return;
        closeOverview();
        renderSlide(p - 1);
        updateOverviewCurrentMark();
      }

      function openOverview() {
        if (slides.length === 0) return;
        buildOverviewCards();
        overviewOpen = true;
        overviewOverlay.style.display = "block";
        ensureOverviewObserver();
        if (overviewObserver) {
          observeOverviewCards();
        } else {
          const cards = overviewGrid.children;
          for (let i = 0; i < cards.length; i++) renderOverviewThumb(cards[i]);
        }
        setOverviewFocus(currentIndex + 1);
      }

      function closeOverview() {
        overviewOpen = false;
        overviewOverlay.style.display = "none";
        hideJumpIndicator();
        if (overviewObserver) {
          const cards = overviewGrid.children;
          for (let i = 0; i < cards.length; i++) overviewObserver.unobserve(cards[i]);
        }
      }

      function toggleOverview() {
        if (overviewOpen) closeOverview();
        else openOverview();
      }

      // 总览打开期间接管全部按键：修复上游总览中空格/PGUP/PGDN 仍会翻页的漏洞
      function handleOverviewKeyDown(e) {
        if (e.ctrlKey || e.metaKey || e.altKey) return;
        if (e.isComposing || isEditableKeyTarget(e.target)) return;
        if (/^[0-9]$/.test(e.key)) {
          if (!jumpInvalid && jumpDisplay.length < 4) {
            jumpDisplay += e.key;
            const p = parseInt(jumpDisplay, 10);
            if (!isNaN(p) && p >= 1 && p <= slides.length) setOverviewFocus(p);
            renderJumpBadge();
            armJumpIdleTimer();
          }
          e.preventDefault();
          return;
        }
        if (e.key === "Enter" && jumpDisplay) {
          if (!jumpInvalid) {
            const page = parseInt(jumpDisplay, 10);
            if (!isNaN(page) && page >= 1 && page <= slides.length) {
              goFromOverview(page);
            } else {
              flashJumpInvalid();
            }
          }
          e.preventDefault();
          return;
        }
        if ((e.key === "Escape" || e.key === "Esc") && (jumpDisplay || jumpInvalid)) {
          hideJumpIndicator();
          e.preventDefault();
          return;
        }
        if (e.key === "ArrowRight") {
          e.preventDefault();
          setOverviewFocus(overviewFocus + 1);
          return;
        }
        if (e.key === "ArrowLeft") {
          e.preventDefault();
          setOverviewFocus(overviewFocus - 1);
          return;
        }
        if (e.key === "ArrowDown" || e.key === "PageDown") {
          e.preventDefault();
          setOverviewFocus(overviewFocus + getOverviewCols());
          return;
        }
        if (e.key === "ArrowUp" || e.key === "PageUp") {
          e.preventDefault();
          setOverviewFocus(overviewFocus - getOverviewCols());
          return;
        }
        if (e.key === " ") {
          e.preventDefault();
          return;
        }
        if (e.key === "Enter") {
          e.preventDefault();
          goFromOverview(overviewFocus);
          return;
        }
        if (e.key === "Escape" || e.key === "Esc" || e.key === "o" || e.key === "O") {
          e.preventDefault();
          closeOverview();
        }
      }

      window.addEventListener("keydown", (e) => {
        if (e.key === "Escape" || e.key === "Esc") {
          if (isLightboxOpen) {
            closeLightbox();
            e.preventDefault();
            return;
          }
        }
        if (isLightboxOpen) return;
        // 总览打开期间全部按键由总览层接管
        if (overviewOpen) {
          handleOverviewKeyDown(e);
          return;
        }
        // 「数字+回车」跳页：可输入元素、修饰键、IME 组合输入中不拦截
        if (!e.ctrlKey && !e.metaKey && !e.altKey && !e.isComposing && !isEditableKeyTarget(e.target)) {
          if (/^[0-9]$/.test(e.key)) {
            if (!jumpInvalid && jumpDisplay.length < 4) {
              jumpDisplay += e.key;
              renderJumpBadge();
              armJumpIdleTimer();
            }
            e.preventDefault();
            return;
          }
          if (e.key === "Enter" && jumpDisplay) {
            if (!jumpInvalid) {
              const page = parseInt(jumpDisplay, 10);
              if (!isNaN(page) && page >= 1 && page <= slides.length) {
                hideJumpIndicator();
                renderSlide(page - 1);
              } else {
                flashJumpInvalid();
              }
            }
            e.preventDefault();
            return;
          }
          if ((e.key === "Escape" || e.key === "Esc") && (jumpDisplay || jumpInvalid)) {
            hideJumpIndicator();
            e.preventDefault();
            return;
          }
          if (e.key === "o" || e.key === "O") {
            e.preventDefault();
            toggleOverview();
            return;
          }
        }
        if (e.key === "ArrowRight" || e.key === " " || e.key === "ArrowDown") goNext();
        if (e.key === "ArrowLeft" || e.key === "ArrowUp") goPrev();
        if (e.key === "f" || e.key === "F") btnFullscreen.click();
      });

      // 监听鼠标滚轮上下翻页调度
      let lastWheelTime = 0;
      const WHEEL_COOLDOWN_MS = 280;
      const WHEEL_DELTA_THRESHOLD = 15;

`}function ag(){return`      function canElementScrollY(el, deltaY) {
        let cur = el;
        while (cur && cur !== document.body && cur !== document.documentElement) {
          if (cur.classList && (cur.classList.contains("slides-viewport") || cur.classList.contains("slides-stage") || cur.classList.contains("slide-container"))) {
            break;
          }
          const style = window.getComputedStyle(cur);
          const overflowY = style.overflowY;
          if (overflowY === "auto" || overflowY === "scroll") {
            const maxScroll = cur.scrollHeight - cur.clientHeight;
            if (maxScroll > 2) {
              if (deltaY > 0 && cur.scrollTop < maxScroll - 1) return true;
              if (deltaY < 0 && cur.scrollTop > 1) return true;
            }
          }
          cur = cur.parentElement;
        }
        return false;
      }

      window.addEventListener("wheel", (e) => {
        if (isLightboxOpen) {
          if (typeof handleLightboxWheel === "function") {
            handleLightboxWheel(e);
          }
          return;
        }
        // 总览打开时滚轮交给总览列表原生滚动，不触发翻页
        if (overviewOpen) return;
        if (Math.abs(e.deltaY) < Math.abs(e.deltaX)) return;
        if (Math.abs(e.deltaY) < WHEEL_DELTA_THRESHOLD) return;

        const target = e.target instanceof Element ? e.target : e.target?.parentElement;
        if (target && canElementScrollY(target, e.deltaY)) return;

        e.preventDefault();
        const now = Date.now();
        if (now - lastWheelTime < WHEEL_COOLDOWN_MS) return;
        lastWheelTime = now;

        if (e.deltaY > 0) {
          goNext();
        } else {
          goPrev();
        }
      }, { passive: false });

      document.addEventListener("click", (e) => {
        if (isLightboxOpen) {
          if (typeof lightboxHasMoved !== "undefined" && lightboxHasMoved) {
            lightboxHasMoved = false;
            e.stopPropagation();
            return;
          }
          const target = e.target instanceof Element ? e.target : e.target?.parentElement;
          const isMediaItself = target && target.closest && target.closest(".slides-lightbox-img, .slides-lightbox-video");
          if (!isMediaItself) {
            e.stopPropagation();
            closeLightbox();
          }
          return;
        }
        // 总览打开时空白点击由总览层自身处理，不触发底层翻页
        if (overviewOpen) return;
        if (e.button !== 0) return;
        const targetEl = e.target instanceof Element ? e.target : e.target?.parentElement;
        if (!targetEl || !targetEl.closest) return;

        const hasPendingMask = currentMaskConfig && (currentMaskStep < currentMaskConfig.totalSteps);
        if (hasPendingMask) {
          const isBottomControls = targetEl.closest(".controls-bar, .controls, .slides-toc");
          if (isBottomControls) return;
          e.preventDefault();
          e.stopPropagation();
          goNext();
          return;
        }

        const refEl = targetEl.closest("[data-ref-id]");
        if (refEl) {
          const id = refEl.getAttribute("data-ref-id");
          if (id) {
            window.open("siyuan://blocks/" + id, "_blank");
            return;
          }
        }

        // 媒体点击唤起 Lightbox 放大模态
        const mediaEl = targetEl.closest(".slide-content img, .slide-content video");
        if (mediaEl && !mediaEl.closest(".controls, .controls-bar, button, a")) {
          e.stopPropagation();
          const isVideo = mediaEl.tagName.toLowerCase() === "video";
          const src = isVideo ? (mediaEl.currentSrc || mediaEl.src || mediaEl.querySelector("source")?.src) : mediaEl.src;
          if (src) {
            openLightbox(isVideo ? "video" : "image", src, mediaEl.alt || "");
            return;
          }
        }

        const selection = window.getSelection ? window.getSelection().toString().trim() : "";
        if (selection.length > 0) return;

        const isComponent = targetEl.closest(
          ".slide-block, .controls-bar, .image-right-img-container, .image-left-img-container, .controls, img, video, audio, button, a, input, textarea, select, [data-clickable], [data-ref-id], .slides-toc, .empty-state"
        );
        if (isComponent) return;

        const isLeft = e.clientX < window.innerWidth / 2;
        if (isLeft) {
          goPrev();
        } else {
          goNext();
        }
      });

      renderSlide(0);
      updateScale();
    })();`}function lg(){return[Qm(),eg(),tg(),ig(),ng(),sg(),og(),rg(),ag()].join("")}function ql(e,t){const i=(t==null?void 0:t.title)||"即现演示文稿";let n=e.slides;if(t!=null&&t.inlineAssetBase64Map&&Object.keys(t.inlineAssetBase64Map).length>0){const a=t.inlineAssetBase64Map;n=e.slides.map(r=>{let l=r.rawMarkdown;for(const[d,h]of Object.entries(a))l.includes(d)&&(l=l.split(d).join(h));const c=r.blocks.map(d=>{let h=d.rawMarkdown;for(const[p,b]of Object.entries(a))h.includes(p)&&(h=h.split(p).join(b));return{...d,rawMarkdown:h}});let u=r.frontmatter?{...r.frontmatter}:r.frontmatter;if(u){if(typeof u.background=="string")for(const[d,h]of Object.entries(a))u.background.includes(d)&&(u.background=u.background.split(d).join(h));if(typeof u.image=="string")for(const[d,h]of Object.entries(a))u.image.includes(d)&&(u.image=u.image.split(d).join(h))}return{...r,rawMarkdown:l,blocks:c,frontmatter:u}})}const s=JSON.stringify(n),o=JSON.stringify(e.config);return`<!DOCTYPE html>
<html lang="zh-CN">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${rt(i)}</title>
  <style>
${Xm(t==null?void 0:t.customInlineStyles)}
  </style>
  <script>
    // 注入演示数据载荷
    window.__SLIDES_DATA__ = {
      docId: ${JSON.stringify(e.docId)},
      slides: ${s},
      config: ${o}
    };
  <\/script>
</head>
<body>
  <div id="app" data-normalize-headings="${e.config.normalizeHeadingSizes?"true":"false"}" data-hide-unordered-markers="${e.config.showUnorderedListMarkers===!1?"true":"false"}" data-hide-ordered-markers="${e.config.showOrderedListMarkers===!1?"true":"false"}">
    <div class="slide-viewport slides-theme-${e.config.theme||"default"}" id="viewport" data-slides-theme="${e.config.theme||"default"}">
      <div class="slide-content" id="slide-container"></div>
    </div>
    <div class="controls">
      <button id="btn-prev">◀ 上一页</button>
      <span id="page-num">1 / 1</span>
      <button id="btn-next">下一页 ▶</button>
      <button id="btn-fullscreen">全屏</button>
    </div>
    <!-- 全屏媒体灯箱 (Lightbox) 模态窗口 -->
    <div id="slides-lightbox" class="slides-lightbox">
      <button class="slides-lightbox-close" id="lightbox-close" aria-label="关闭 (Esc)">✕</button>
      <div class="slides-lightbox-content" id="lightbox-content"></div>
    </div>
  </div>

  <script>
${lg()}
  <\/script>
</body>
</html>`}function Yl(e,t){if(typeof document>"u")return!1;const i=new Blob([t],{type:"text/html;charset=utf-8"}),n=URL.createObjectURL(i),s=document.createElement("a");return s.href=n,s.download=e.endsWith(".html")?e:`${e}.html`,document.body.appendChild(s),s.click(),document.body.removeChild(s),URL.revokeObjectURL(n),!0}function cg(e){switch(e){case"4:3":return"size: 12in 9in;";case"A4-landscape":return"size: 297mm 210mm;";case"A4-portrait":return"size: 210mm 297mm;";case"16:9":default:return"size: 16in 9in;"}}function dg(e){const t=cg(e==null?void 0:e.pageRatio);return`
    ${On(e==null?void 0:e.customInlineStyles)}

    @page {
      ${t}
      margin: 0;
    }
    * {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
      -webkit-print-color-adjust: exact !important;
      print-color-adjust: exact !important;
    }
    body {
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "PingFang SC", "Microsoft YaHei", sans-serif;
      background: #f8fafc;
      color: #1e293b;
    }
    .pdf-slide-page {
      width: 100vw;
      height: 100vh;
      page-break-after: always;
      break-after: page;
      padding: var(--slides-padding-y, 36px) var(--slides-padding-x, 56px);
      display: flex;
      flex-direction: column;
      position: relative;
      background: #ffffff;
      overflow: hidden;
    }
    .pdf-slide-page.spacing-compact {
      --slides-padding-y: 20px;
      --slides-padding-x: 36px;
      --slides-header-gap: 10px;
      --slides-title-margin-bottom: 6px;
    }
    .pdf-slide-page.spacing-normal {
      --slides-padding-y: 36px;
      --slides-padding-x: 56px;
      --slides-header-gap: 16px;
      --slides-title-margin-bottom: 10px;
    }
    .pdf-slide-page.spacing-loose {
      --slides-padding-y: 48px;
      --slides-padding-x: 64px;
      --slides-header-gap: 24px;
      --slides-title-margin-bottom: 16px;
    }
    .pdf-slide-page.theme-dark {
      background: #0f1117;
      color: #f1f5f9;
    }
    .pdf-slide-header {
      font-size: 13px;
      color: #64748b;
      margin-bottom: 24px;
      display: flex;
      justify-content: space-between;
      border-bottom: 1px solid #e2e8f0;
      padding-bottom: 8px;
    }
    .theme-dark .pdf-slide-header {
      border-bottom-color: #2e3346;
      color: #94a3b8;
    }
    .pdf-slide-body {
      flex: 1;
      display: flex;
      flex-direction: column;
      gap: 16px;
      font-size: 20px;
      line-height: 1.6;
      overflow: hidden;
    }
    .pdf-block h1 { font-size: 2.5rem; font-weight: 800; color: #2563eb; margin-bottom: 12px; }
    .pdf-block h2 { font-size: 1.9rem; font-weight: 700; color: #1d4ed8; margin-bottom: 10px; }
    .pdf-block h3 { font-size: 1.4rem; font-weight: 600; margin-bottom: 8px; }
    .pdf-block h4 { font-size: 1.2rem; font-weight: 600; margin-bottom: 6px; }
    .pdf-block p { font-size: 1.15rem; color: inherit; }
    .pdf-code,
    pre {
      background: #f1f5f9;
      padding: 14px 18px;
      border-radius: 6px;
      font-family: "JetBrains Mono", Consolas, monospace;
      font-size: 0.95rem;
      border-left: 4px solid #3b82f6;
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      max-width: 100% !important;
      box-sizing: border-box !important;
    }
    .pdf-code code,
    pre code {
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      display: block !important;
      width: 100% !important;
      box-sizing: border-box !important;
    }
    .code-line {
      display: flex !important;
      align-items: flex-start !important;
      width: 100% !important;
      box-sizing: border-box !important;
      line-height: 1.6;
    }
    .code-line .line-no {
      display: inline-block !important;
      flex-shrink: 0 !important;
      min-width: 2.2em !important;
      text-align: right !important;
      margin-right: 12px !important;
      user-select: none !important;
      opacity: 0.45 !important;
    }
    .code-line .line-content {
      flex: 1 1 0% !important;
      min-width: 0 !important;
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
    }
    .theme-dark .pdf-code {
      background: #1e1e24;
      border-left-color: #60a5fa;
    }
    .pdf-quote {
      border-left: 4px solid #10b981;
      background: rgba(16, 185, 129, 0.08);
      padding: 10px 16px;
      border-radius: 0 4px 4px 0;
      font-style: italic;
    }
    .pdf-image,
    .slide-media-img {
      max-width: 100% !important;
      max-height: 48vh !important;
      width: auto !important;
      height: auto !important;
      object-fit: contain !important;
      border-radius: 6px;
      margin: auto;
      display: block;
    }
    .slide-media-block,
    .slide-media-container,
    .slide-video-container {
      display: flex;
      flex-direction: column;
      justify-content: center;
      align-items: center;
      width: 100%;
      max-height: 48vh;
      margin: 8px 0;
      overflow: hidden;
    }
    .slide-list-media {
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: flex-start;
      margin-top: 8px;
      margin-bottom: 6px;
      max-width: 100%;
      overflow: hidden;
    }
    .slide-list-media img,
    .slide-list-media video,
    .slide-list-media .list-item-gif {
      max-width: 100% !important;
      max-height: min(280px, 36vh) !important;
      width: auto !important;
      height: auto !important;
      min-width: 0 !important;
      min-height: 0 !important;
      object-fit: contain !important;
      border-radius: 6px;
      display: block;
      margin: 0 auto !important;
    }
    .slide-video-player {
      max-width: 100% !important;
      max-height: 48vh !important;
      width: auto !important;
      height: auto !important;
      object-fit: contain !important;
      border-radius: 6px;
      background: #000;
      border: 1px solid #cbd5e1;
    }
    .pdf-two-cols-wrapper,
    .layout-two-cols-grid,
    .layout-cols-wrapper,
    .layout-cols-grid {
      display: grid;
      grid-template-columns: minmax(0, 1fr) minmax(0, 1fr);
      grid-template-rows: minmax(0, 1fr) !important;
      gap: 36px;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      overflow: hidden !important;
    }
    .layout-cols-header-container,
    .layout-two-cols-header-container,
    .layout-three-cols-header-container,
    .layout-clover-container {
      display: flex;
      flex-direction: column;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      overflow: hidden !important;
    }
    .layout-header-section {
      width: 100%;
      margin-bottom: var(--slides-header-gap, 16px) !important;
      flex-shrink: 0;
    }
    .layout-header-section h1,
    .layout-header-section h2,
    .layout-header-section h3 {
      margin-bottom: var(--slides-title-margin-bottom, 10px) !important;
    }
    .pdf-three-cols-wrapper,
    .layout-three-cols-grid {
      display: grid;
      grid-template-columns: minmax(0, 1fr) minmax(0, 1fr) minmax(0, 1fr);
      grid-template-rows: minmax(0, 1fr) !important;
      gap: 24px;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      box-sizing: border-box;
      overflow: hidden !important;
    }
    .pdf-clover-wrapper,
    .layout-clover-grid {
      display: grid;
      grid-template-columns: repeat(2, minmax(0, 1fr)) !important;
      grid-template-rows: repeat(2, minmax(0, 1fr)) !important;
      gap: 20px;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      box-sizing: border-box;
      overflow: hidden !important;
    }
    .layout-clover-grid .pdf-col {
      background: transparent !important;
      border: none !important;
      box-shadow: none !important;
    }
    .pdf-col {
      display: flex;
      flex-direction: column;
      gap: 14px;
      min-width: 0;
      width: 100%;
      max-width: 100%;
      height: 100%;
      max-height: 100%;
      min-height: 0;
      justify-content: flex-start;
      overflow: hidden;
      box-sizing: border-box;
      overflow-wrap: break-word;
      word-break: break-word;
      white-space: normal;
    }
    /* 表头多栏内超级块子块首个列表项去圆点后居中显示标题/首行文本 (仅在存在超级块分栏时生效) */
    .has-superblock-cols .pdf-col > *:first-child .slide-list-item-title,
    .has-superblock-cols .pdf-col > *:first-child :is(h1, h2, h3, h4, h5, h6),
    .has-superblock-cols .pdf-col > *:first-child p.slide-list-item-title,
    .has-superblock-cols .pdf-col > *:first-child p:first-of-type,
    .has-superblock-cols .pdf-col > *:first-child p:first-child,
    .has-superblock-cols .pdf-col > *:first-child :is(ul, ol) > li:first-child,
    .has-superblock-cols .pdf-col > *:first-child .slide-list > .slide-list-item:first-child,
    .has-superblock-cols .pdf-col > *:first-child .pdf-list > li:first-child,
    .has-superblock-cols .slides-col-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    .has-superblock-cols .slides-col-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      list-style: none !important;
      list-style-type: none !important;
      text-align: center !important;
      margin-left: 0 !important;
      padding-left: 0 !important;
      width: 100% !important;
    }

    /* 彻底清除首个列表项的原生圆点 Marker (仅在存在超级块分栏时生效) */
    .has-superblock-cols .pdf-col > *:first-child :is(ul, ol) > li:first-child::marker {
      content: "" !important;
      display: none !important;
    }

    /* 确保首个列表项内部内联与块级元素居中 (仅在存在超级块分栏时生效) */
    .has-superblock-cols .pdf-col > *:first-child :is(ul, ol) > li:first-child * {
      text-align: center !important;
    }

    /* 栏内说明段落与列表项：左对齐，自然阅读排版 */
    .has-superblock-cols .pdf-col .slide-list-item-desc,
    .has-superblock-cols .pdf-col li:not(:first-child) {
      text-align: left !important;
    }

    /* 全局特定标题大小规范化 (除封面外页首首个标题按 H2 1.7rem，表头多栏内首个标题按 H3 1.3rem) */
    [data-normalize-headings="true"] .slides-page-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .slides-page-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .pdf-slide:not(.layout-cover) > :is(.pdf-block, .slide-block):first-child :is(h1, h2, h3, h4, h5, h6),
    [data-normalize-headings="true"] .pdf-slide:not(.layout-cover) > .layout-header-section :is(.pdf-block, .slide-block):first-child :is(h1, h2, h3, h4, h5, h6),
    [data-normalize-headings="true"] .pdf-slide:not(.layout-cover) > :not(.layout-cols-wrapper):not(.pdf-two-cols-wrapper):not(.layout-image-cols-grid):first-child :is(h1, h2, h3, h4, h5, h6) {
      font-size: 1.7rem !important;
      font-weight: 600 !important;
      line-height: 1.25 !important;
      margin-bottom: 10px !important;
    }

    [data-normalize-headings="true"] .has-superblock-cols .slides-col-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .has-superblock-cols .slides-col-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .has-superblock-cols .pdf-col > *:first-child :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      font-size: 1.3rem !important;
      font-weight: 600 !important;
      line-height: 1.3 !important;
      margin-bottom: 8px !important;
      text-align: center !important;
    }

    /* 图左与图右版式标题完全保留用户原始字号与默认排版，不进行任何固定大小规范化 */
    [data-normalize-headings="true"] :is(.layout-image-left, .layout-image-right, .image-left-content, .image-right-content) :is(h1, h2, h3, h4, h5, h6) {
      text-align: left !important;
    }
    .pdf-col > .pdf-block,
    .pdf-col > .slide-block {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      max-height: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      width: 100% !important;
      height: 100% !important;
      box-sizing: border-box !important;
      overflow: hidden !important;
    }
    .pdf-col .slide-list-item-title,
    .pdf-col h1, .pdf-col h2, .pdf-col h3, .pdf-col h4, .pdf-col h5, .pdf-col h6,
    .pdf-col .slide-list-item-desc {
      flex: 0 0 auto !important;
      margin-top: 0 !important;
      margin-bottom: 6px !important;
    }
    .pdf-col .slide-list-media,
    .pdf-col .slide-video-container,
    .pdf-col .slide-media-container {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      min-width: 0 !important;
      width: 100% !important;
      height: 100% !important;
      max-height: 100% !important;
      max-width: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
      justify-content: flex-start !important;
      overflow: hidden !important;
      margin: 0 !important;
      padding: 0 !important;
      box-sizing: border-box !important;
    }
    .pdf-col li:has(.slide-list-media),
    .pdf-col li:has(.slide-media-container),
    .pdf-col li:has(.slide-video-container),
    .pdf-col li:has(img),
    .pdf-col li:has(video),
    .pdf-col .pdf-list-item:has(.slide-list-media),
    .pdf-col .pdf-list-item:has(.slide-media-container),
    .pdf-col .pdf-list-item:has(.slide-video-container),
    .pdf-col .pdf-list-item:has(img),
    .pdf-col .pdf-list-item:has(video) {
      display: list-item !important;
      list-style-type: disc !important;
      flex: 0 0 auto !important;
      height: auto !important;
      max-height: none !important;
      overflow: visible !important;
      margin-bottom: 6px !important;
    }
    .pdf-col video,
    .layout-three-cols-grid video,
    .layout-two-cols-grid video,
    .pdf-col img,
    .layout-three-cols-grid img,
    .layout-two-cols-grid img,
    .pdf-col .slide-video-player {
      max-width: 100% !important;
      max-height: 100% !important;
      width: auto !important;
      height: auto !important;
      min-width: 0 !important;
      min-height: 0 !important;
      object-fit: contain !important;
      display: block !important;
      margin: 0 auto !important;
    }
    .pdf-col * {
      overflow-wrap: break-word;
      word-break: break-word;
      box-sizing: border-box;
    }
    .pdf-col pre {
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      max-width: 100% !important;
      box-sizing: border-box !important;
    }
    .pdf-list-item {
      padding-left: 20px;
    }
    .pdf-list {
      padding-left: 24px;
      margin: 8px 0;
      display: flex;
      flex-direction: column;
      gap: 6px;
    }
    .pdf-list li {
      font-size: 1.15rem;
      line-height: 1.6;
    }
    .pdf-task-item {
      list-style: none;
      margin-left: -20px;
      display: flex;
      align-items: center;
      gap: 8px;
    }
    .pdf-task-item input[type="checkbox"] {
      width: 1.15em;
      height: 1.15em;
      cursor: pointer;
    }
    /* 两栏与三栏及多栏（超级块分栏）布局：紧凑自然行距，子列表保留圆点与层级缩进 */
    .layout-two-cols ul,
    .layout-cols-header ul,
    .layout-two-cols-header ul,
    .layout-three-cols ul,
    .layout-three-cols-header ul,
    .two-cols-left ul,
    .two-cols-right ul,
    .three-cols-col ul,
    .col ul,
    .pdf-two-cols-wrapper ul,
    .pdf-three-cols-wrapper ul,
    .pdf-col ul,
    .layout-two-cols-grid .pdf-list,
    .layout-three-cols-grid .pdf-list,
    .layout-cols-grid .pdf-list,
    .layout-two-cols-grid .pdf-list--unordered,
    .layout-three-cols-grid .pdf-list--unordered,
    .layout-cols-grid .pdf-list--unordered {
      list-style: disc !important;
      list-style-type: disc !important;
      padding-left: 1.25em !important;
      margin-left: 0 !important;
      margin-top: 0 !important;
      margin-bottom: 8px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: block !important;
    }
    .layout-two-cols ol,
    .layout-cols-header ol,
    .layout-two-cols-header ol,
    .layout-three-cols ol,
    .layout-three-cols-header ol,
    .two-cols-left ol,
    .two-cols-right ol,
    .three-cols-col ol,
    .col ol,
    .pdf-two-cols-wrapper ol,
    .pdf-three-cols-wrapper ol,
    .pdf-col ol,
    .layout-two-cols-grid .pdf-list--ordered,
    .layout-three-cols-grid .pdf-list--ordered,
    .layout-cols-grid .pdf-list--ordered {
      list-style: decimal !important;
      list-style-type: decimal !important;
      padding-left: 1.25em !important;
      margin-left: 0 !important;
      margin-top: 0 !important;
      margin-bottom: 8px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: block !important;
    }
    .layout-two-cols li,
    .layout-cols-header li,
    .layout-two-cols-header li,
    .layout-three-cols li,
    .layout-three-cols-header li,
    .two-cols-left li,
    .two-cols-right li,
    .three-cols-col li,
    .col li,
    .pdf-col li,
    .pdf-col .pdf-list-item {
      padding-left: 0.2em !important;
      margin-left: 0 !important;
      margin-bottom: 6px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: list-item !important;
      line-height: 1.6 !important;
    }
    .layout-two-cols ul ul,
    .layout-three-cols ul ul,
    .three-cols-col ul ul,
    .pdf-col ul ul {
      list-style: circle !important;
      list-style-type: circle !important;
      padding-left: 1.25em !important;
      margin-top: 4px !important;
      margin-bottom: 4px !important;
    }
    /* 列表项内嵌标题与说明排版 */
    .slide-list-item-title,
    .pdf-list li > h1,
    .pdf-list li > h2,
    .pdf-list li > h3,
    .pdf-list li > h4,
    .pdf-list li > h5,
    .pdf-list li > h6,
    li > h1.slide-list-item-title,
    li > h2.slide-list-item-title,
    li > h3.slide-list-item-title,
    li > h4.slide-list-item-title {
      margin-top: 2px !important;
      margin-bottom: 6px !important;
      line-height: 1.35 !important;
      font-weight: 700 !important;
    }
    .pdf-list li > h1, li > h1.slide-list-item-title { font-size: 1.6rem !important; }
    .pdf-list li > h2, li > h2.slide-list-item-title { font-size: 1.4rem !important; }
    .pdf-list li > h3, li > h3.slide-list-item-title { font-size: 1.22rem !important; }
    .pdf-list li > h4, li > h4.slide-list-item-title { font-size: 1.1rem !important; }

    /* 全局特定标题大小规范化后置强力锁定 (防止被列表项内部字号覆盖) */
    [data-normalize-headings="true"] .slides-page-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .slides-page-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      font-size: 1.7rem !important;
      font-weight: 600 !important;
      line-height: 1.25 !important;
      margin-bottom: 10px !important;
    }
    [data-normalize-headings="true"] .has-superblock-cols .slides-col-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .has-superblock-cols .slides-col-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .has-superblock-cols .pdf-col > *:first-child :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      font-size: 1.3rem !important;
      font-weight: 600 !important;
      line-height: 1.3 !important;
      margin-bottom: 8px !important;
      text-align: center !important;
    }
    /* 基础列表项前缀样式 */
    .slide-block ul,
    .slide-list--unordered,
    .pdf-list--unordered {
      list-style: disc !important;
      list-style-type: disc !important;
    }
    .slide-block ol,
    .slide-list--ordered,
    .pdf-list--ordered {
      list-style: decimal !important;
      list-style-type: decimal !important;
    }
    .slide-block li,
    .slide-list-item,
    .pdf-list-item,
    .pdf-list li {
      display: list-item !important;
    }

    /* 隐藏无序列表前缀标记 */
    [data-hide-unordered-markers="true"] :is(ul, .slide-list, .slide-list--unordered, .pdf-list, .pdf-list--unordered),
    [data-hide-unordered-markers="true"] :is(ul, .slide-list, .slide-list--unordered, .pdf-list, .pdf-list--unordered) > li,
    [data-hide-unordered-markers="true"] li.slide-list-item,
    [data-hide-unordered-markers="true"] ul > li {
      list-style: none !important;
      list-style-type: none !important;
      padding-left: 0 !important;
      margin-left: 0 !important;
    }
    [data-hide-unordered-markers="true"] :is(ul, .slide-list, .slide-list--unordered, .pdf-list, .pdf-list--unordered) > li::marker,
    [data-hide-unordered-markers="true"] li.slide-list-item::marker {
      content: "" !important;
      display: none !important;
    }

    /* 隐藏有序列表前缀标记 */
    [data-hide-ordered-markers="true"] :is(ol, .slide-list, .slide-list--ordered, .pdf-list, .pdf-list--ordered),
    [data-hide-ordered-markers="true"] :is(ol, .slide-list, .slide-list--ordered, .pdf-list, .pdf-list--ordered) > li,
    [data-hide-ordered-markers="true"] li.slide-list-item,
    [data-hide-ordered-markers="true"] ol > li {
      list-style: none !important;
      list-style-type: none !important;
      padding-left: 0 !important;
      margin-left: 0 !important;
    }
    [data-hide-ordered-markers="true"] :is(ol, .slide-list, .slide-list--ordered, .pdf-list, .pdf-list--ordered) > li::marker,
    [data-hide-ordered-markers="true"] li.slide-list-item::marker {
      content: "" !important;
      display: none !important;
    }

    .slide-list-item-desc,
    .pdf-list li > p {
      margin-top: 4px !important;
      margin-bottom: 6px !important;
      font-size: 1.05rem;
      line-height: 1.55;
      opacity: 0.92;
    }
    kbd {
      display: inline-block;
      padding: 2px 7px;
      font-family: ui-monospace, SFMono-Regular, "SF Mono", Menlo, Consolas, "Liberation Mono", monospace;
      font-size: 0.85em;
      font-weight: 600;
      line-height: 1.25;
      color: inherit;
      background: rgba(125, 125, 125, 0.12);
      border: 1px solid rgba(125, 125, 125, 0.35);
      border-bottom-width: 2px;
      border-radius: 5px;
      box-shadow: 0 1px 2px rgba(0, 0, 0, 0.12);
      margin: 0 2px;
      vertical-align: middle;
      white-space: nowrap;
    }
    .theme-dark kbd {
      background: rgba(255, 255, 255, 0.1);
      border-color: rgba(255, 255, 255, 0.25);
      border-bottom-color: rgba(255, 255, 255, 0.4);
      color: #f1f5f9;
      box-shadow: 0 1px 2px rgba(0, 0, 0, 0.4);
    }
    a {
      color: inherit;
      text-decoration: none;
      border-bottom: 1px dashed currentColor;
    }
    .slides-ref-tag, a.slides-ref-tag {
      display: inline-flex;
      align-items: center;
      background: rgba(16, 185, 129, 0.1);
      color: #059669;
      border: 1px solid rgba(16, 185, 129, 0.25);
      border-radius: 4px;
      padding: 2px 8px;
      font-size: 0.88em;
      text-decoration: none;
      margin: 2px 4px 2px 0;
    }
    .theme-dark .slides-ref-tag, .theme-dark a.slides-ref-tag {
      background: rgba(52, 211, 153, 0.15);
      color: #34d399;
      border-color: rgba(52, 211, 153, 0.3);
    }
    .slides-block-ref, .pdf-block--ref {
      background: rgba(16, 185, 129, 0.06);
      border-left: 3px solid #059669;
      border-radius: 0 6px 6px 0;
      padding: 10px 14px;
      margin: 8px 0;
    }
    .theme-dark .slides-block-ref, .theme-dark .pdf-block--ref {
      background: rgba(52, 211, 153, 0.08);
      border-left-color: #34d399;
    }
    .pdf-slide-notes {
      font-size: 14px;
      color: #059669;
      border-top: 1px dashed #cbd5e1;
      padding-top: 12px;
      margin-top: auto;
      line-height: 1.5;
    }
    .theme-dark .pdf-slide-notes {
      color: #34d399;
      border-top-color: #334155;
    }
    /* Layouts */
    .layout-cover .pdf-slide-body {
      justify-content: center;
      align-items: center;
      text-align: center;
    }
    .layout-cover h1 {
      font-size: 3.2rem;
    }
    .layout-center .pdf-slide-body {
      justify-content: center;
      align-items: center;
      text-align: center;
    }
    .layout-fact .pdf-slide-body {
      justify-content: center;
      align-items: center;
      text-align: center;
    }
    .layout-fact h1 {
      font-size: 4.5rem;
      color: #ef4444;
    }
    @media print {
      .slides-motion-fade-in,
      .slides-motion-slide-up,
      .slides-motion-slide-down,
      .slides-motion-slide-left,
      .slides-motion-slide-right,
      .slides-motion-zoom-in,
      .slides-motion-pop,
      .slides-motion-bounce {
        animation: none !important;
        opacity: 1 !important;
        transform: none !important;
      }
      /* PDF 打印讲义下禁用动态蒙版遮挡，保证内容 100% 完整可见 */
      .slides-mask-layer,
      .slides-mask-overlay,
      .slides-mask-divider-line {
        display: none !important;
        opacity: 0 !important;
        mask: none !important;
        -webkit-mask: none !important;
      }
      .slides-mask-body-container {
        clip-path: none !important;
        -webkit-clip-path: none !important;
        overflow: visible !important;
      }
    }
  `}function ug(e,t){const i="即现演示讲义",n="16:9",s="light",o=e.slides.map((a,r)=>{const l=a.frontmatter.layout||"default",c=a.frontmatter.spacing,u=c&&c!=="inherit"?c:e.config.spacing||"normal",d=Kl(a),h=`${r+1} / ${e.slides.length}`;return`
      <section class="pdf-slide-page layout-${l} theme-${s} spacing-${u}">
        <header class="pdf-slide-header">
          <span class="pdf-doc-title">${rt(i)}</span>
          ${`<span class="pdf-page-badge">P. ${h}</span>`}
        </header>
        <div class="pdf-slide-body">
          ${d}
        </div>
        ${a.notes?`
          <footer class="pdf-slide-notes">
            <strong>演讲备注:</strong> ${rt(a.notes)}
          </footer>
        `:""}
      </section>
    `}).join(`
`);return`<!DOCTYPE html>
<html lang="zh-CN">
<head>
  <meta charset="UTF-8">
  <title>${rt(i)} - 高保真讲义</title>
  <style>
    ${dg({pageRatio:n,customInlineStyles:t==null?void 0:t.customInlineStyles})}
  </style>
</head>
<body data-normalize-headings="${e.config.normalizeHeadingSizes?"true":"false"}" data-hide-unordered-markers="${e.config.showUnorderedListMarkers===!1?"true":"false"}" data-hide-ordered-markers="${e.config.showOrderedListMarkers===!1?"true":"false"}">
  ${o}
</body>
</html>`}function Zl(e,t){var s;if(typeof window>"u"||typeof document>"u")return!1;const i=ug(e,t);try{const o=document.createElement("iframe");o.style.position="fixed",o.style.right="0",o.style.bottom="0",o.style.width="0",o.style.height="0",o.style.border="none",o.style.visibility="hidden",document.body.appendChild(o);const a=(s=o.contentWindow)==null?void 0:s.document;if(a)return a.open(),a.write(i),a.close(),setTimeout(()=>{var r,l;try{(r=o.contentWindow)==null||r.focus(),(l=o.contentWindow)==null||l.print()}finally{setTimeout(()=>{o.remove()},2e3)}},350),!0}catch(o){console.warn("[pdf-exporter] iframe 打印模式异常，降级尝试 window.open:",o)}const n=window.open("","_blank");return n?(n.document.write(i),n.document.close(),n.focus(),setTimeout(()=>{n.print(),n.close()},350),!0):!1}var cs=typeof globalThis<"u"?globalThis:typeof window<"u"?window:typeof global<"u"?global:typeof self<"u"?self:{};function fg(e){return e&&e.__esModule&&Object.prototype.hasOwnProperty.call(e,"default")?e.default:e}function ds(e){throw new Error('Could not dynamically require "'+e+'". Please configure the dynamicRequireTargets or/and ignoreDynamicRequires option of @rollup/plugin-commonjs appropriately for this require call to work.')}var ho={exports:{}};/*!

JSZip v3.10.1 - A JavaScript class for generating and reading zip files
<http://stuartk.com/jszip>

(c) 2009-2016 Stuart Knightley <stuart [at] stuartk.com>
Dual licenced under the MIT license or GPLv3. See https://raw.github.com/Stuk/jszip/main/LICENSE.markdown.

JSZip uses the library pako released under the MIT license :
https://github.com/nodeca/pako/blob/main/LICENSE
*/var ca;function pg(){return ca||(ca=1,(function(e,t){(function(i){e.exports=i()})(function(){return(function i(n,s,o){function a(c,u){if(!s[c]){if(!n[c]){var d=typeof ds=="function"&&ds;if(!u&&d)return d(c,!0);if(r)return r(c,!0);var h=new Error("Cannot find module '"+c+"'");throw h.code="MODULE_NOT_FOUND",h}var p=s[c]={exports:{}};n[c][0].call(p.exports,function(b){var m=n[c][1][b];return a(m||b)},p,p.exports,i,n,s,o)}return s[c].exports}for(var r=typeof ds=="function"&&ds,l=0;l<o.length;l++)a(o[l]);return a})({1:[function(i,n,s){var o=i("./utils"),a=i("./support"),r="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";s.encode=function(l){for(var c,u,d,h,p,b,m,y=[],g=0,w=l.length,S=w,x=o.getTypeOf(l)!=="string";g<l.length;)S=w-g,d=x?(c=l[g++],u=g<w?l[g++]:0,g<w?l[g++]:0):(c=l.charCodeAt(g++),u=g<w?l.charCodeAt(g++):0,g<w?l.charCodeAt(g++):0),h=c>>2,p=(3&c)<<4|u>>4,b=1<S?(15&u)<<2|d>>6:64,m=2<S?63&d:64,y.push(r.charAt(h)+r.charAt(p)+r.charAt(b)+r.charAt(m));return y.join("")},s.decode=function(l){var c,u,d,h,p,b,m=0,y=0,g="data:";if(l.substr(0,g.length)===g)throw new Error("Invalid base64 input, it looks like a data url.");var w,S=3*(l=l.replace(/[^A-Za-z0-9+/=]/g,"")).length/4;if(l.charAt(l.length-1)===r.charAt(64)&&S--,l.charAt(l.length-2)===r.charAt(64)&&S--,S%1!=0)throw new Error("Invalid base64 input, bad content length.");for(w=a.uint8array?new Uint8Array(0|S):new Array(0|S);m<l.length;)c=r.indexOf(l.charAt(m++))<<2|(h=r.indexOf(l.charAt(m++)))>>4,u=(15&h)<<4|(p=r.indexOf(l.charAt(m++)))>>2,d=(3&p)<<6|(b=r.indexOf(l.charAt(m++))),w[y++]=c,p!==64&&(w[y++]=u),b!==64&&(w[y++]=d);return w}},{"./support":30,"./utils":32}],2:[function(i,n,s){var o=i("./external"),a=i("./stream/DataWorker"),r=i("./stream/Crc32Probe"),l=i("./stream/DataLengthProbe");function c(u,d,h,p,b){this.compressedSize=u,this.uncompressedSize=d,this.crc32=h,this.compression=p,this.compressedContent=b}c.prototype={getContentWorker:function(){var u=new a(o.Promise.resolve(this.compressedContent)).pipe(this.compression.uncompressWorker()).pipe(new l("data_length")),d=this;return u.on("end",function(){if(this.streamInfo.data_length!==d.uncompressedSize)throw new Error("Bug : uncompressed data size mismatch")}),u},getCompressedWorker:function(){return new a(o.Promise.resolve(this.compressedContent)).withStreamInfo("compressedSize",this.compressedSize).withStreamInfo("uncompressedSize",this.uncompressedSize).withStreamInfo("crc32",this.crc32).withStreamInfo("compression",this.compression)}},c.createWorkerFrom=function(u,d,h){return u.pipe(new r).pipe(new l("uncompressedSize")).pipe(d.compressWorker(h)).pipe(new l("compressedSize")).withStreamInfo("compression",d)},n.exports=c},{"./external":6,"./stream/Crc32Probe":25,"./stream/DataLengthProbe":26,"./stream/DataWorker":27}],3:[function(i,n,s){var o=i("./stream/GenericWorker");s.STORE={magic:"\0\0",compressWorker:function(){return new o("STORE compression")},uncompressWorker:function(){return new o("STORE decompression")}},s.DEFLATE=i("./flate")},{"./flate":7,"./stream/GenericWorker":28}],4:[function(i,n,s){var o=i("./utils"),a=(function(){for(var r,l=[],c=0;c<256;c++){r=c;for(var u=0;u<8;u++)r=1&r?3988292384^r>>>1:r>>>1;l[c]=r}return l})();n.exports=function(r,l){return r!==void 0&&r.length?o.getTypeOf(r)!=="string"?(function(c,u,d,h){var p=a,b=h+d;c^=-1;for(var m=h;m<b;m++)c=c>>>8^p[255&(c^u[m])];return-1^c})(0|l,r,r.length,0):(function(c,u,d,h){var p=a,b=h+d;c^=-1;for(var m=h;m<b;m++)c=c>>>8^p[255&(c^u.charCodeAt(m))];return-1^c})(0|l,r,r.length,0):0}},{"./utils":32}],5:[function(i,n,s){s.base64=!1,s.binary=!1,s.dir=!1,s.createFolders=!0,s.date=null,s.compression=null,s.compressionOptions=null,s.comment=null,s.unixPermissions=null,s.dosPermissions=null},{}],6:[function(i,n,s){var o=null;o=typeof Promise<"u"?Promise:i("lie"),n.exports={Promise:o}},{lie:37}],7:[function(i,n,s){var o=typeof Uint8Array<"u"&&typeof Uint16Array<"u"&&typeof Uint32Array<"u",a=i("pako"),r=i("./utils"),l=i("./stream/GenericWorker"),c=o?"uint8array":"array";function u(d,h){l.call(this,"FlateWorker/"+d),this._pako=null,this._pakoAction=d,this._pakoOptions=h,this.meta={}}s.magic="\b\0",r.inherits(u,l),u.prototype.processChunk=function(d){this.meta=d.meta,this._pako===null&&this._createPako(),this._pako.push(r.transformTo(c,d.data),!1)},u.prototype.flush=function(){l.prototype.flush.call(this),this._pako===null&&this._createPako(),this._pako.push([],!0)},u.prototype.cleanUp=function(){l.prototype.cleanUp.call(this),this._pako=null},u.prototype._createPako=function(){this._pako=new a[this._pakoAction]({raw:!0,level:this._pakoOptions.level||-1});var d=this;this._pako.onData=function(h){d.push({data:h,meta:d.meta})}},s.compressWorker=function(d){return new u("Deflate",d)},s.uncompressWorker=function(){return new u("Inflate",{})}},{"./stream/GenericWorker":28,"./utils":32,pako:38}],8:[function(i,n,s){function o(p,b){var m,y="";for(m=0;m<b;m++)y+=String.fromCharCode(255&p),p>>>=8;return y}function a(p,b,m,y,g,w){var S,x,M=p.file,E=p.compression,C=w!==c.utf8encode,D=r.transformTo("string",w(M.name)),R=r.transformTo("string",c.utf8encode(M.name)),N=M.comment,K=r.transformTo("string",w(N)),$=r.transformTo("string",c.utf8encode(N)),V=R.length!==M.name.length,k=$.length!==N.length,F="",H="",I="",A=M.dir,O=M.date,ne={crc32:0,compressedSize:0,uncompressedSize:0};b&&!m||(ne.crc32=p.crc32,ne.compressedSize=p.compressedSize,ne.uncompressedSize=p.uncompressedSize);var G=0;b&&(G|=8),C||!V&&!k||(G|=2048);var q=0,ce=0;A&&(q|=16),g==="UNIX"?(ce=798,q|=(function(re,Se){var Ie=re;return re||(Ie=Se?16893:33204),(65535&Ie)<<16})(M.unixPermissions,A)):(ce=20,q|=(function(re){return 63&(re||0)})(M.dosPermissions)),S=O.getUTCHours(),S<<=6,S|=O.getUTCMinutes(),S<<=5,S|=O.getUTCSeconds()/2,x=O.getUTCFullYear()-1980,x<<=4,x|=O.getUTCMonth()+1,x<<=5,x|=O.getUTCDate(),V&&(H=o(1,1)+o(u(D),4)+R,F+="up"+o(H.length,2)+H),k&&(I=o(1,1)+o(u(K),4)+$,F+="uc"+o(I.length,2)+I);var se="";return se+=`
\0`,se+=o(G,2),se+=E.magic,se+=o(S,2),se+=o(x,2),se+=o(ne.crc32,4),se+=o(ne.compressedSize,4),se+=o(ne.uncompressedSize,4),se+=o(D.length,2),se+=o(F.length,2),{fileRecord:d.LOCAL_FILE_HEADER+se+D+F,dirRecord:d.CENTRAL_FILE_HEADER+o(ce,2)+se+o(K.length,2)+"\0\0\0\0"+o(q,4)+o(y,4)+D+F+K}}var r=i("../utils"),l=i("../stream/GenericWorker"),c=i("../utf8"),u=i("../crc32"),d=i("../signature");function h(p,b,m,y){l.call(this,"ZipFileWorker"),this.bytesWritten=0,this.zipComment=b,this.zipPlatform=m,this.encodeFileName=y,this.streamFiles=p,this.accumulate=!1,this.contentBuffer=[],this.dirRecords=[],this.currentSourceOffset=0,this.entriesCount=0,this.currentFile=null,this._sources=[]}r.inherits(h,l),h.prototype.push=function(p){var b=p.meta.percent||0,m=this.entriesCount,y=this._sources.length;this.accumulate?this.contentBuffer.push(p):(this.bytesWritten+=p.data.length,l.prototype.push.call(this,{data:p.data,meta:{currentFile:this.currentFile,percent:m?(b+100*(m-y-1))/m:100}}))},h.prototype.openedSource=function(p){this.currentSourceOffset=this.bytesWritten,this.currentFile=p.file.name;var b=this.streamFiles&&!p.file.dir;if(b){var m=a(p,b,!1,this.currentSourceOffset,this.zipPlatform,this.encodeFileName);this.push({data:m.fileRecord,meta:{percent:0}})}else this.accumulate=!0},h.prototype.closedSource=function(p){this.accumulate=!1;var b=this.streamFiles&&!p.file.dir,m=a(p,b,!0,this.currentSourceOffset,this.zipPlatform,this.encodeFileName);if(this.dirRecords.push(m.dirRecord),b)this.push({data:(function(y){return d.DATA_DESCRIPTOR+o(y.crc32,4)+o(y.compressedSize,4)+o(y.uncompressedSize,4)})(p),meta:{percent:100}});else for(this.push({data:m.fileRecord,meta:{percent:0}});this.contentBuffer.length;)this.push(this.contentBuffer.shift());this.currentFile=null},h.prototype.flush=function(){for(var p=this.bytesWritten,b=0;b<this.dirRecords.length;b++)this.push({data:this.dirRecords[b],meta:{percent:100}});var m=this.bytesWritten-p,y=(function(g,w,S,x,M){var E=r.transformTo("string",M(x));return d.CENTRAL_DIRECTORY_END+"\0\0\0\0"+o(g,2)+o(g,2)+o(w,4)+o(S,4)+o(E.length,2)+E})(this.dirRecords.length,m,p,this.zipComment,this.encodeFileName);this.push({data:y,meta:{percent:100}})},h.prototype.prepareNextSource=function(){this.previous=this._sources.shift(),this.openedSource(this.previous.streamInfo),this.isPaused?this.previous.pause():this.previous.resume()},h.prototype.registerPrevious=function(p){this._sources.push(p);var b=this;return p.on("data",function(m){b.processChunk(m)}),p.on("end",function(){b.closedSource(b.previous.streamInfo),b._sources.length?b.prepareNextSource():b.end()}),p.on("error",function(m){b.error(m)}),this},h.prototype.resume=function(){return!!l.prototype.resume.call(this)&&(!this.previous&&this._sources.length?(this.prepareNextSource(),!0):this.previous||this._sources.length||this.generatedError?void 0:(this.end(),!0))},h.prototype.error=function(p){var b=this._sources;if(!l.prototype.error.call(this,p))return!1;for(var m=0;m<b.length;m++)try{b[m].error(p)}catch{}return!0},h.prototype.lock=function(){l.prototype.lock.call(this);for(var p=this._sources,b=0;b<p.length;b++)p[b].lock()},n.exports=h},{"../crc32":4,"../signature":23,"../stream/GenericWorker":28,"../utf8":31,"../utils":32}],9:[function(i,n,s){var o=i("../compressions"),a=i("./ZipFileWorker");s.generateWorker=function(r,l,c){var u=new a(l.streamFiles,c,l.platform,l.encodeFileName),d=0;try{r.forEach(function(h,p){d++;var b=(function(w,S){var x=w||S,M=o[x];if(!M)throw new Error(x+" is not a valid compression method !");return M})(p.options.compression,l.compression),m=p.options.compressionOptions||l.compressionOptions||{},y=p.dir,g=p.date;p._compressWorker(b,m).withStreamInfo("file",{name:h,dir:y,date:g,comment:p.comment||"",unixPermissions:p.unixPermissions,dosPermissions:p.dosPermissions}).pipe(u)}),u.entriesCount=d}catch(h){u.error(h)}return u}},{"../compressions":3,"./ZipFileWorker":8}],10:[function(i,n,s){function o(){if(!(this instanceof o))return new o;if(arguments.length)throw new Error("The constructor with parameters has been removed in JSZip 3.0, please check the upgrade guide.");this.files=Object.create(null),this.comment=null,this.root="",this.clone=function(){var a=new o;for(var r in this)typeof this[r]!="function"&&(a[r]=this[r]);return a}}(o.prototype=i("./object")).loadAsync=i("./load"),o.support=i("./support"),o.defaults=i("./defaults"),o.version="3.10.1",o.loadAsync=function(a,r){return new o().loadAsync(a,r)},o.external=i("./external"),n.exports=o},{"./defaults":5,"./external":6,"./load":11,"./object":15,"./support":30}],11:[function(i,n,s){var o=i("./utils"),a=i("./external"),r=i("./utf8"),l=i("./zipEntries"),c=i("./stream/Crc32Probe"),u=i("./nodejsUtils");function d(h){return new a.Promise(function(p,b){var m=h.decompressed.getContentWorker().pipe(new c);m.on("error",function(y){b(y)}).on("end",function(){m.streamInfo.crc32!==h.decompressed.crc32?b(new Error("Corrupted zip : CRC32 mismatch")):p()}).resume()})}n.exports=function(h,p){var b=this;return p=o.extend(p||{},{base64:!1,checkCRC32:!1,optimizedBinaryString:!1,createFolders:!1,decodeFileName:r.utf8decode}),u.isNode&&u.isStream(h)?a.Promise.reject(new Error("JSZip can't accept a stream when loading a zip file.")):o.prepareContent("the loaded zip file",h,!0,p.optimizedBinaryString,p.base64).then(function(m){var y=new l(p);return y.load(m),y}).then(function(m){var y=[a.Promise.resolve(m)],g=m.files;if(p.checkCRC32)for(var w=0;w<g.length;w++)y.push(d(g[w]));return a.Promise.all(y)}).then(function(m){for(var y=m.shift(),g=y.files,w=0;w<g.length;w++){var S=g[w],x=S.fileNameStr,M=o.resolve(S.fileNameStr);b.file(M,S.decompressed,{binary:!0,optimizedBinaryString:!0,date:S.date,dir:S.dir,comment:S.fileCommentStr.length?S.fileCommentStr:null,unixPermissions:S.unixPermissions,dosPermissions:S.dosPermissions,createFolders:p.createFolders}),S.dir||(b.file(M).unsafeOriginalName=x)}return y.zipComment.length&&(b.comment=y.zipComment),b})}},{"./external":6,"./nodejsUtils":14,"./stream/Crc32Probe":25,"./utf8":31,"./utils":32,"./zipEntries":33}],12:[function(i,n,s){var o=i("../utils"),a=i("../stream/GenericWorker");function r(l,c){a.call(this,"Nodejs stream input adapter for "+l),this._upstreamEnded=!1,this._bindStream(c)}o.inherits(r,a),r.prototype._bindStream=function(l){var c=this;(this._stream=l).pause(),l.on("data",function(u){c.push({data:u,meta:{percent:0}})}).on("error",function(u){c.isPaused?this.generatedError=u:c.error(u)}).on("end",function(){c.isPaused?c._upstreamEnded=!0:c.end()})},r.prototype.pause=function(){return!!a.prototype.pause.call(this)&&(this._stream.pause(),!0)},r.prototype.resume=function(){return!!a.prototype.resume.call(this)&&(this._upstreamEnded?this.end():this._stream.resume(),!0)},n.exports=r},{"../stream/GenericWorker":28,"../utils":32}],13:[function(i,n,s){var o=i("readable-stream").Readable;function a(r,l,c){o.call(this,l),this._helper=r;var u=this;r.on("data",function(d,h){u.push(d)||u._helper.pause(),c&&c(h)}).on("error",function(d){u.emit("error",d)}).on("end",function(){u.push(null)})}i("../utils").inherits(a,o),a.prototype._read=function(){this._helper.resume()},n.exports=a},{"../utils":32,"readable-stream":16}],14:[function(i,n,s){n.exports={isNode:typeof Buffer<"u",newBufferFrom:function(o,a){if(Buffer.from&&Buffer.from!==Uint8Array.from)return Buffer.from(o,a);if(typeof o=="number")throw new Error('The "data" argument must not be a number');return new Buffer(o,a)},allocBuffer:function(o){if(Buffer.alloc)return Buffer.alloc(o);var a=new Buffer(o);return a.fill(0),a},isBuffer:function(o){return Buffer.isBuffer(o)},isStream:function(o){return o&&typeof o.on=="function"&&typeof o.pause=="function"&&typeof o.resume=="function"}}},{}],15:[function(i,n,s){function o(M,E,C){var D,R=r.getTypeOf(E),N=r.extend(C||{},u);N.date=N.date||new Date,N.compression!==null&&(N.compression=N.compression.toUpperCase()),typeof N.unixPermissions=="string"&&(N.unixPermissions=parseInt(N.unixPermissions,8)),N.unixPermissions&&16384&N.unixPermissions&&(N.dir=!0),N.dosPermissions&&16&N.dosPermissions&&(N.dir=!0),N.dir&&(M=g(M)),N.createFolders&&(D=y(M))&&w.call(this,D,!0);var K=R==="string"&&N.binary===!1&&N.base64===!1;C&&C.binary!==void 0||(N.binary=!K),(E instanceof d&&E.uncompressedSize===0||N.dir||!E||E.length===0)&&(N.base64=!1,N.binary=!0,E="",N.compression="STORE",R="string");var $=null;$=E instanceof d||E instanceof l?E:b.isNode&&b.isStream(E)?new m(M,E):r.prepareContent(M,E,N.binary,N.optimizedBinaryString,N.base64);var V=new h(M,$,N);this.files[M]=V}var a=i("./utf8"),r=i("./utils"),l=i("./stream/GenericWorker"),c=i("./stream/StreamHelper"),u=i("./defaults"),d=i("./compressedObject"),h=i("./zipObject"),p=i("./generate"),b=i("./nodejsUtils"),m=i("./nodejs/NodejsStreamInputAdapter"),y=function(M){M.slice(-1)==="/"&&(M=M.substring(0,M.length-1));var E=M.lastIndexOf("/");return 0<E?M.substring(0,E):""},g=function(M){return M.slice(-1)!=="/"&&(M+="/"),M},w=function(M,E){return E=E!==void 0?E:u.createFolders,M=g(M),this.files[M]||o.call(this,M,null,{dir:!0,createFolders:E}),this.files[M]};function S(M){return Object.prototype.toString.call(M)==="[object RegExp]"}var x={load:function(){throw new Error("This method has been removed in JSZip 3.0, please check the upgrade guide.")},forEach:function(M){var E,C,D;for(E in this.files)D=this.files[E],(C=E.slice(this.root.length,E.length))&&E.slice(0,this.root.length)===this.root&&M(C,D)},filter:function(M){var E=[];return this.forEach(function(C,D){M(C,D)&&E.push(D)}),E},file:function(M,E,C){if(arguments.length!==1)return M=this.root+M,o.call(this,M,E,C),this;if(S(M)){var D=M;return this.filter(function(N,K){return!K.dir&&D.test(N)})}var R=this.files[this.root+M];return R&&!R.dir?R:null},folder:function(M){if(!M)return this;if(S(M))return this.filter(function(R,N){return N.dir&&M.test(R)});var E=this.root+M,C=w.call(this,E),D=this.clone();return D.root=C.name,D},remove:function(M){M=this.root+M;var E=this.files[M];if(E||(M.slice(-1)!=="/"&&(M+="/"),E=this.files[M]),E&&!E.dir)delete this.files[M];else for(var C=this.filter(function(R,N){return N.name.slice(0,M.length)===M}),D=0;D<C.length;D++)delete this.files[C[D].name];return this},generate:function(){throw new Error("This method has been removed in JSZip 3.0, please check the upgrade guide.")},generateInternalStream:function(M){var E,C={};try{if((C=r.extend(M||{},{streamFiles:!1,compression:"STORE",compressionOptions:null,type:"",platform:"DOS",comment:null,mimeType:"application/zip",encodeFileName:a.utf8encode})).type=C.type.toLowerCase(),C.compression=C.compression.toUpperCase(),C.type==="binarystring"&&(C.type="string"),!C.type)throw new Error("No output type specified.");r.checkSupport(C.type),C.platform!=="darwin"&&C.platform!=="freebsd"&&C.platform!=="linux"&&C.platform!=="sunos"||(C.platform="UNIX"),C.platform==="win32"&&(C.platform="DOS");var D=C.comment||this.comment||"";E=p.generateWorker(this,C,D)}catch(R){(E=new l("error")).error(R)}return new c(E,C.type||"string",C.mimeType)},generateAsync:function(M,E){return this.generateInternalStream(M).accumulate(E)},generateNodeStream:function(M,E){return(M=M||{}).type||(M.type="nodebuffer"),this.generateInternalStream(M).toNodejsStream(E)}};n.exports=x},{"./compressedObject":2,"./defaults":5,"./generate":9,"./nodejs/NodejsStreamInputAdapter":12,"./nodejsUtils":14,"./stream/GenericWorker":28,"./stream/StreamHelper":29,"./utf8":31,"./utils":32,"./zipObject":35}],16:[function(i,n,s){n.exports=i("stream")},{stream:void 0}],17:[function(i,n,s){var o=i("./DataReader");function a(r){o.call(this,r);for(var l=0;l<this.data.length;l++)r[l]=255&r[l]}i("../utils").inherits(a,o),a.prototype.byteAt=function(r){return this.data[this.zero+r]},a.prototype.lastIndexOfSignature=function(r){for(var l=r.charCodeAt(0),c=r.charCodeAt(1),u=r.charCodeAt(2),d=r.charCodeAt(3),h=this.length-4;0<=h;--h)if(this.data[h]===l&&this.data[h+1]===c&&this.data[h+2]===u&&this.data[h+3]===d)return h-this.zero;return-1},a.prototype.readAndCheckSignature=function(r){var l=r.charCodeAt(0),c=r.charCodeAt(1),u=r.charCodeAt(2),d=r.charCodeAt(3),h=this.readData(4);return l===h[0]&&c===h[1]&&u===h[2]&&d===h[3]},a.prototype.readData=function(r){if(this.checkOffset(r),r===0)return[];var l=this.data.slice(this.zero+this.index,this.zero+this.index+r);return this.index+=r,l},n.exports=a},{"../utils":32,"./DataReader":18}],18:[function(i,n,s){var o=i("../utils");function a(r){this.data=r,this.length=r.length,this.index=0,this.zero=0}a.prototype={checkOffset:function(r){this.checkIndex(this.index+r)},checkIndex:function(r){if(this.length<this.zero+r||r<0)throw new Error("End of data reached (data length = "+this.length+", asked index = "+r+"). Corrupted zip ?")},setIndex:function(r){this.checkIndex(r),this.index=r},skip:function(r){this.setIndex(this.index+r)},byteAt:function(){},readInt:function(r){var l,c=0;for(this.checkOffset(r),l=this.index+r-1;l>=this.index;l--)c=(c<<8)+this.byteAt(l);return this.index+=r,c},readString:function(r){return o.transformTo("string",this.readData(r))},readData:function(){},lastIndexOfSignature:function(){},readAndCheckSignature:function(){},readDate:function(){var r=this.readInt(4);return new Date(Date.UTC(1980+(r>>25&127),(r>>21&15)-1,r>>16&31,r>>11&31,r>>5&63,(31&r)<<1))}},n.exports=a},{"../utils":32}],19:[function(i,n,s){var o=i("./Uint8ArrayReader");function a(r){o.call(this,r)}i("../utils").inherits(a,o),a.prototype.readData=function(r){this.checkOffset(r);var l=this.data.slice(this.zero+this.index,this.zero+this.index+r);return this.index+=r,l},n.exports=a},{"../utils":32,"./Uint8ArrayReader":21}],20:[function(i,n,s){var o=i("./DataReader");function a(r){o.call(this,r)}i("../utils").inherits(a,o),a.prototype.byteAt=function(r){return this.data.charCodeAt(this.zero+r)},a.prototype.lastIndexOfSignature=function(r){return this.data.lastIndexOf(r)-this.zero},a.prototype.readAndCheckSignature=function(r){return r===this.readData(4)},a.prototype.readData=function(r){this.checkOffset(r);var l=this.data.slice(this.zero+this.index,this.zero+this.index+r);return this.index+=r,l},n.exports=a},{"../utils":32,"./DataReader":18}],21:[function(i,n,s){var o=i("./ArrayReader");function a(r){o.call(this,r)}i("../utils").inherits(a,o),a.prototype.readData=function(r){if(this.checkOffset(r),r===0)return new Uint8Array(0);var l=this.data.subarray(this.zero+this.index,this.zero+this.index+r);return this.index+=r,l},n.exports=a},{"../utils":32,"./ArrayReader":17}],22:[function(i,n,s){var o=i("../utils"),a=i("../support"),r=i("./ArrayReader"),l=i("./StringReader"),c=i("./NodeBufferReader"),u=i("./Uint8ArrayReader");n.exports=function(d){var h=o.getTypeOf(d);return o.checkSupport(h),h!=="string"||a.uint8array?h==="nodebuffer"?new c(d):a.uint8array?new u(o.transformTo("uint8array",d)):new r(o.transformTo("array",d)):new l(d)}},{"../support":30,"../utils":32,"./ArrayReader":17,"./NodeBufferReader":19,"./StringReader":20,"./Uint8ArrayReader":21}],23:[function(i,n,s){s.LOCAL_FILE_HEADER="PK",s.CENTRAL_FILE_HEADER="PK",s.CENTRAL_DIRECTORY_END="PK",s.ZIP64_CENTRAL_DIRECTORY_LOCATOR="PK\x07",s.ZIP64_CENTRAL_DIRECTORY_END="PK",s.DATA_DESCRIPTOR="PK\x07\b"},{}],24:[function(i,n,s){var o=i("./GenericWorker"),a=i("../utils");function r(l){o.call(this,"ConvertWorker to "+l),this.destType=l}a.inherits(r,o),r.prototype.processChunk=function(l){this.push({data:a.transformTo(this.destType,l.data),meta:l.meta})},n.exports=r},{"../utils":32,"./GenericWorker":28}],25:[function(i,n,s){var o=i("./GenericWorker"),a=i("../crc32");function r(){o.call(this,"Crc32Probe"),this.withStreamInfo("crc32",0)}i("../utils").inherits(r,o),r.prototype.processChunk=function(l){this.streamInfo.crc32=a(l.data,this.streamInfo.crc32||0),this.push(l)},n.exports=r},{"../crc32":4,"../utils":32,"./GenericWorker":28}],26:[function(i,n,s){var o=i("../utils"),a=i("./GenericWorker");function r(l){a.call(this,"DataLengthProbe for "+l),this.propName=l,this.withStreamInfo(l,0)}o.inherits(r,a),r.prototype.processChunk=function(l){if(l){var c=this.streamInfo[this.propName]||0;this.streamInfo[this.propName]=c+l.data.length}a.prototype.processChunk.call(this,l)},n.exports=r},{"../utils":32,"./GenericWorker":28}],27:[function(i,n,s){var o=i("../utils"),a=i("./GenericWorker");function r(l){a.call(this,"DataWorker");var c=this;this.dataIsReady=!1,this.index=0,this.max=0,this.data=null,this.type="",this._tickScheduled=!1,l.then(function(u){c.dataIsReady=!0,c.data=u,c.max=u&&u.length||0,c.type=o.getTypeOf(u),c.isPaused||c._tickAndRepeat()},function(u){c.error(u)})}o.inherits(r,a),r.prototype.cleanUp=function(){a.prototype.cleanUp.call(this),this.data=null},r.prototype.resume=function(){return!!a.prototype.resume.call(this)&&(!this._tickScheduled&&this.dataIsReady&&(this._tickScheduled=!0,o.delay(this._tickAndRepeat,[],this)),!0)},r.prototype._tickAndRepeat=function(){this._tickScheduled=!1,this.isPaused||this.isFinished||(this._tick(),this.isFinished||(o.delay(this._tickAndRepeat,[],this),this._tickScheduled=!0))},r.prototype._tick=function(){if(this.isPaused||this.isFinished)return!1;var l=null,c=Math.min(this.max,this.index+16384);if(this.index>=this.max)return this.end();switch(this.type){case"string":l=this.data.substring(this.index,c);break;case"uint8array":l=this.data.subarray(this.index,c);break;case"array":case"nodebuffer":l=this.data.slice(this.index,c)}return this.index=c,this.push({data:l,meta:{percent:this.max?this.index/this.max*100:0}})},n.exports=r},{"../utils":32,"./GenericWorker":28}],28:[function(i,n,s){function o(a){this.name=a||"default",this.streamInfo={},this.generatedError=null,this.extraStreamInfo={},this.isPaused=!0,this.isFinished=!1,this.isLocked=!1,this._listeners={data:[],end:[],error:[]},this.previous=null}o.prototype={push:function(a){this.emit("data",a)},end:function(){if(this.isFinished)return!1;this.flush();try{this.emit("end"),this.cleanUp(),this.isFinished=!0}catch(a){this.emit("error",a)}return!0},error:function(a){return!this.isFinished&&(this.isPaused?this.generatedError=a:(this.isFinished=!0,this.emit("error",a),this.previous&&this.previous.error(a),this.cleanUp()),!0)},on:function(a,r){return this._listeners[a].push(r),this},cleanUp:function(){this.streamInfo=this.generatedError=this.extraStreamInfo=null,this._listeners=[]},emit:function(a,r){if(this._listeners[a])for(var l=0;l<this._listeners[a].length;l++)this._listeners[a][l].call(this,r)},pipe:function(a){return a.registerPrevious(this)},registerPrevious:function(a){if(this.isLocked)throw new Error("The stream '"+this+"' has already been used.");this.streamInfo=a.streamInfo,this.mergeStreamInfo(),this.previous=a;var r=this;return a.on("data",function(l){r.processChunk(l)}),a.on("end",function(){r.end()}),a.on("error",function(l){r.error(l)}),this},pause:function(){return!this.isPaused&&!this.isFinished&&(this.isPaused=!0,this.previous&&this.previous.pause(),!0)},resume:function(){if(!this.isPaused||this.isFinished)return!1;var a=this.isPaused=!1;return this.generatedError&&(this.error(this.generatedError),a=!0),this.previous&&this.previous.resume(),!a},flush:function(){},processChunk:function(a){this.push(a)},withStreamInfo:function(a,r){return this.extraStreamInfo[a]=r,this.mergeStreamInfo(),this},mergeStreamInfo:function(){for(var a in this.extraStreamInfo)Object.prototype.hasOwnProperty.call(this.extraStreamInfo,a)&&(this.streamInfo[a]=this.extraStreamInfo[a])},lock:function(){if(this.isLocked)throw new Error("The stream '"+this+"' has already been used.");this.isLocked=!0,this.previous&&this.previous.lock()},toString:function(){var a="Worker "+this.name;return this.previous?this.previous+" -> "+a:a}},n.exports=o},{}],29:[function(i,n,s){var o=i("../utils"),a=i("./ConvertWorker"),r=i("./GenericWorker"),l=i("../base64"),c=i("../support"),u=i("../external"),d=null;if(c.nodestream)try{d=i("../nodejs/NodejsStreamOutputAdapter")}catch{}function h(b,m){return new u.Promise(function(y,g){var w=[],S=b._internalType,x=b._outputType,M=b._mimeType;b.on("data",function(E,C){w.push(E),m&&m(C)}).on("error",function(E){w=[],g(E)}).on("end",function(){try{var E=(function(C,D,R){switch(C){case"blob":return o.newBlob(o.transformTo("arraybuffer",D),R);case"base64":return l.encode(D);default:return o.transformTo(C,D)}})(x,(function(C,D){var R,N=0,K=null,$=0;for(R=0;R<D.length;R++)$+=D[R].length;switch(C){case"string":return D.join("");case"array":return Array.prototype.concat.apply([],D);case"uint8array":for(K=new Uint8Array($),R=0;R<D.length;R++)K.set(D[R],N),N+=D[R].length;return K;case"nodebuffer":return Buffer.concat(D);default:throw new Error("concat : unsupported type '"+C+"'")}})(S,w),M);y(E)}catch(C){g(C)}w=[]}).resume()})}function p(b,m,y){var g=m;switch(m){case"blob":case"arraybuffer":g="uint8array";break;case"base64":g="string"}try{this._internalType=g,this._outputType=m,this._mimeType=y,o.checkSupport(g),this._worker=b.pipe(new a(g)),b.lock()}catch(w){this._worker=new r("error"),this._worker.error(w)}}p.prototype={accumulate:function(b){return h(this,b)},on:function(b,m){var y=this;return b==="data"?this._worker.on(b,function(g){m.call(y,g.data,g.meta)}):this._worker.on(b,function(){o.delay(m,arguments,y)}),this},resume:function(){return o.delay(this._worker.resume,[],this._worker),this},pause:function(){return this._worker.pause(),this},toNodejsStream:function(b){if(o.checkSupport("nodestream"),this._outputType!=="nodebuffer")throw new Error(this._outputType+" is not supported by this method");return new d(this,{objectMode:this._outputType!=="nodebuffer"},b)}},n.exports=p},{"../base64":1,"../external":6,"../nodejs/NodejsStreamOutputAdapter":13,"../support":30,"../utils":32,"./ConvertWorker":24,"./GenericWorker":28}],30:[function(i,n,s){if(s.base64=!0,s.array=!0,s.string=!0,s.arraybuffer=typeof ArrayBuffer<"u"&&typeof Uint8Array<"u",s.nodebuffer=typeof Buffer<"u",s.uint8array=typeof Uint8Array<"u",typeof ArrayBuffer>"u")s.blob=!1;else{var o=new ArrayBuffer(0);try{s.blob=new Blob([o],{type:"application/zip"}).size===0}catch{try{var a=new(self.BlobBuilder||self.WebKitBlobBuilder||self.MozBlobBuilder||self.MSBlobBuilder);a.append(o),s.blob=a.getBlob("application/zip").size===0}catch{s.blob=!1}}}try{s.nodestream=!!i("readable-stream").Readable}catch{s.nodestream=!1}},{"readable-stream":16}],31:[function(i,n,s){for(var o=i("./utils"),a=i("./support"),r=i("./nodejsUtils"),l=i("./stream/GenericWorker"),c=new Array(256),u=0;u<256;u++)c[u]=252<=u?6:248<=u?5:240<=u?4:224<=u?3:192<=u?2:1;c[254]=c[254]=1;function d(){l.call(this,"utf-8 decode"),this.leftOver=null}function h(){l.call(this,"utf-8 encode")}s.utf8encode=function(p){return a.nodebuffer?r.newBufferFrom(p,"utf-8"):(function(b){var m,y,g,w,S,x=b.length,M=0;for(w=0;w<x;w++)(64512&(y=b.charCodeAt(w)))==55296&&w+1<x&&(64512&(g=b.charCodeAt(w+1)))==56320&&(y=65536+(y-55296<<10)+(g-56320),w++),M+=y<128?1:y<2048?2:y<65536?3:4;for(m=a.uint8array?new Uint8Array(M):new Array(M),w=S=0;S<M;w++)(64512&(y=b.charCodeAt(w)))==55296&&w+1<x&&(64512&(g=b.charCodeAt(w+1)))==56320&&(y=65536+(y-55296<<10)+(g-56320),w++),y<128?m[S++]=y:(y<2048?m[S++]=192|y>>>6:(y<65536?m[S++]=224|y>>>12:(m[S++]=240|y>>>18,m[S++]=128|y>>>12&63),m[S++]=128|y>>>6&63),m[S++]=128|63&y);return m})(p)},s.utf8decode=function(p){return a.nodebuffer?o.transformTo("nodebuffer",p).toString("utf-8"):(function(b){var m,y,g,w,S=b.length,x=new Array(2*S);for(m=y=0;m<S;)if((g=b[m++])<128)x[y++]=g;else if(4<(w=c[g]))x[y++]=65533,m+=w-1;else{for(g&=w===2?31:w===3?15:7;1<w&&m<S;)g=g<<6|63&b[m++],w--;1<w?x[y++]=65533:g<65536?x[y++]=g:(g-=65536,x[y++]=55296|g>>10&1023,x[y++]=56320|1023&g)}return x.length!==y&&(x.subarray?x=x.subarray(0,y):x.length=y),o.applyFromCharCode(x)})(p=o.transformTo(a.uint8array?"uint8array":"array",p))},o.inherits(d,l),d.prototype.processChunk=function(p){var b=o.transformTo(a.uint8array?"uint8array":"array",p.data);if(this.leftOver&&this.leftOver.length){if(a.uint8array){var m=b;(b=new Uint8Array(m.length+this.leftOver.length)).set(this.leftOver,0),b.set(m,this.leftOver.length)}else b=this.leftOver.concat(b);this.leftOver=null}var y=(function(w,S){var x;for((S=S||w.length)>w.length&&(S=w.length),x=S-1;0<=x&&(192&w[x])==128;)x--;return x<0||x===0?S:x+c[w[x]]>S?x:S})(b),g=b;y!==b.length&&(a.uint8array?(g=b.subarray(0,y),this.leftOver=b.subarray(y,b.length)):(g=b.slice(0,y),this.leftOver=b.slice(y,b.length))),this.push({data:s.utf8decode(g),meta:p.meta})},d.prototype.flush=function(){this.leftOver&&this.leftOver.length&&(this.push({data:s.utf8decode(this.leftOver),meta:{}}),this.leftOver=null)},s.Utf8DecodeWorker=d,o.inherits(h,l),h.prototype.processChunk=function(p){this.push({data:s.utf8encode(p.data),meta:p.meta})},s.Utf8EncodeWorker=h},{"./nodejsUtils":14,"./stream/GenericWorker":28,"./support":30,"./utils":32}],32:[function(i,n,s){var o=i("./support"),a=i("./base64"),r=i("./nodejsUtils"),l=i("./external");function c(m){return m}function u(m,y){for(var g=0;g<m.length;++g)y[g]=255&m.charCodeAt(g);return y}i("setimmediate"),s.newBlob=function(m,y){s.checkSupport("blob");try{return new Blob([m],{type:y})}catch{try{var g=new(self.BlobBuilder||self.WebKitBlobBuilder||self.MozBlobBuilder||self.MSBlobBuilder);return g.append(m),g.getBlob(y)}catch{throw new Error("Bug : can't construct the Blob.")}}};var d={stringifyByChunk:function(m,y,g){var w=[],S=0,x=m.length;if(x<=g)return String.fromCharCode.apply(null,m);for(;S<x;)y==="array"||y==="nodebuffer"?w.push(String.fromCharCode.apply(null,m.slice(S,Math.min(S+g,x)))):w.push(String.fromCharCode.apply(null,m.subarray(S,Math.min(S+g,x)))),S+=g;return w.join("")},stringifyByChar:function(m){for(var y="",g=0;g<m.length;g++)y+=String.fromCharCode(m[g]);return y},applyCanBeUsed:{uint8array:(function(){try{return o.uint8array&&String.fromCharCode.apply(null,new Uint8Array(1)).length===1}catch{return!1}})(),nodebuffer:(function(){try{return o.nodebuffer&&String.fromCharCode.apply(null,r.allocBuffer(1)).length===1}catch{return!1}})()}};function h(m){var y=65536,g=s.getTypeOf(m),w=!0;if(g==="uint8array"?w=d.applyCanBeUsed.uint8array:g==="nodebuffer"&&(w=d.applyCanBeUsed.nodebuffer),w)for(;1<y;)try{return d.stringifyByChunk(m,g,y)}catch{y=Math.floor(y/2)}return d.stringifyByChar(m)}function p(m,y){for(var g=0;g<m.length;g++)y[g]=m[g];return y}s.applyFromCharCode=h;var b={};b.string={string:c,array:function(m){return u(m,new Array(m.length))},arraybuffer:function(m){return b.string.uint8array(m).buffer},uint8array:function(m){return u(m,new Uint8Array(m.length))},nodebuffer:function(m){return u(m,r.allocBuffer(m.length))}},b.array={string:h,array:c,arraybuffer:function(m){return new Uint8Array(m).buffer},uint8array:function(m){return new Uint8Array(m)},nodebuffer:function(m){return r.newBufferFrom(m)}},b.arraybuffer={string:function(m){return h(new Uint8Array(m))},array:function(m){return p(new Uint8Array(m),new Array(m.byteLength))},arraybuffer:c,uint8array:function(m){return new Uint8Array(m)},nodebuffer:function(m){return r.newBufferFrom(new Uint8Array(m))}},b.uint8array={string:h,array:function(m){return p(m,new Array(m.length))},arraybuffer:function(m){return m.buffer},uint8array:c,nodebuffer:function(m){return r.newBufferFrom(m)}},b.nodebuffer={string:h,array:function(m){return p(m,new Array(m.length))},arraybuffer:function(m){return b.nodebuffer.uint8array(m).buffer},uint8array:function(m){return p(m,new Uint8Array(m.length))},nodebuffer:c},s.transformTo=function(m,y){if(y=y||"",!m)return y;s.checkSupport(m);var g=s.getTypeOf(y);return b[g][m](y)},s.resolve=function(m){for(var y=m.split("/"),g=[],w=0;w<y.length;w++){var S=y[w];S==="."||S===""&&w!==0&&w!==y.length-1||(S===".."?g.pop():g.push(S))}return g.join("/")},s.getTypeOf=function(m){return typeof m=="string"?"string":Object.prototype.toString.call(m)==="[object Array]"?"array":o.nodebuffer&&r.isBuffer(m)?"nodebuffer":o.uint8array&&m instanceof Uint8Array?"uint8array":o.arraybuffer&&m instanceof ArrayBuffer?"arraybuffer":void 0},s.checkSupport=function(m){if(!o[m.toLowerCase()])throw new Error(m+" is not supported by this platform")},s.MAX_VALUE_16BITS=65535,s.MAX_VALUE_32BITS=-1,s.pretty=function(m){var y,g,w="";for(g=0;g<(m||"").length;g++)w+="\\x"+((y=m.charCodeAt(g))<16?"0":"")+y.toString(16).toUpperCase();return w},s.delay=function(m,y,g){setImmediate(function(){m.apply(g||null,y||[])})},s.inherits=function(m,y){function g(){}g.prototype=y.prototype,m.prototype=new g},s.extend=function(){var m,y,g={};for(m=0;m<arguments.length;m++)for(y in arguments[m])Object.prototype.hasOwnProperty.call(arguments[m],y)&&g[y]===void 0&&(g[y]=arguments[m][y]);return g},s.prepareContent=function(m,y,g,w,S){return l.Promise.resolve(y).then(function(x){return o.blob&&(x instanceof Blob||["[object File]","[object Blob]"].indexOf(Object.prototype.toString.call(x))!==-1)&&typeof FileReader<"u"?new l.Promise(function(M,E){var C=new FileReader;C.onload=function(D){M(D.target.result)},C.onerror=function(D){E(D.target.error)},C.readAsArrayBuffer(x)}):x}).then(function(x){var M=s.getTypeOf(x);return M?(M==="arraybuffer"?x=s.transformTo("uint8array",x):M==="string"&&(S?x=a.decode(x):g&&w!==!0&&(x=(function(E){return u(E,o.uint8array?new Uint8Array(E.length):new Array(E.length))})(x))),x):l.Promise.reject(new Error("Can't read the data of '"+m+"'. Is it in a supported JavaScript type (String, Blob, ArrayBuffer, etc) ?"))})}},{"./base64":1,"./external":6,"./nodejsUtils":14,"./support":30,setimmediate:54}],33:[function(i,n,s){var o=i("./reader/readerFor"),a=i("./utils"),r=i("./signature"),l=i("./zipEntry"),c=i("./support");function u(d){this.files=[],this.loadOptions=d}u.prototype={checkSignature:function(d){if(!this.reader.readAndCheckSignature(d)){this.reader.index-=4;var h=this.reader.readString(4);throw new Error("Corrupted zip or bug: unexpected signature ("+a.pretty(h)+", expected "+a.pretty(d)+")")}},isSignature:function(d,h){var p=this.reader.index;this.reader.setIndex(d);var b=this.reader.readString(4)===h;return this.reader.setIndex(p),b},readBlockEndOfCentral:function(){this.diskNumber=this.reader.readInt(2),this.diskWithCentralDirStart=this.reader.readInt(2),this.centralDirRecordsOnThisDisk=this.reader.readInt(2),this.centralDirRecords=this.reader.readInt(2),this.centralDirSize=this.reader.readInt(4),this.centralDirOffset=this.reader.readInt(4),this.zipCommentLength=this.reader.readInt(2);var d=this.reader.readData(this.zipCommentLength),h=c.uint8array?"uint8array":"array",p=a.transformTo(h,d);this.zipComment=this.loadOptions.decodeFileName(p)},readBlockZip64EndOfCentral:function(){this.zip64EndOfCentralSize=this.reader.readInt(8),this.reader.skip(4),this.diskNumber=this.reader.readInt(4),this.diskWithCentralDirStart=this.reader.readInt(4),this.centralDirRecordsOnThisDisk=this.reader.readInt(8),this.centralDirRecords=this.reader.readInt(8),this.centralDirSize=this.reader.readInt(8),this.centralDirOffset=this.reader.readInt(8),this.zip64ExtensibleData={};for(var d,h,p,b=this.zip64EndOfCentralSize-44;0<b;)d=this.reader.readInt(2),h=this.reader.readInt(4),p=this.reader.readData(h),this.zip64ExtensibleData[d]={id:d,length:h,value:p}},readBlockZip64EndOfCentralLocator:function(){if(this.diskWithZip64CentralDirStart=this.reader.readInt(4),this.relativeOffsetEndOfZip64CentralDir=this.reader.readInt(8),this.disksCount=this.reader.readInt(4),1<this.disksCount)throw new Error("Multi-volumes zip are not supported")},readLocalFiles:function(){var d,h;for(d=0;d<this.files.length;d++)h=this.files[d],this.reader.setIndex(h.localHeaderOffset),this.checkSignature(r.LOCAL_FILE_HEADER),h.readLocalPart(this.reader),h.handleUTF8(),h.processAttributes()},readCentralDir:function(){var d;for(this.reader.setIndex(this.centralDirOffset);this.reader.readAndCheckSignature(r.CENTRAL_FILE_HEADER);)(d=new l({zip64:this.zip64},this.loadOptions)).readCentralPart(this.reader),this.files.push(d);if(this.centralDirRecords!==this.files.length&&this.centralDirRecords!==0&&this.files.length===0)throw new Error("Corrupted zip or bug: expected "+this.centralDirRecords+" records in central dir, got "+this.files.length)},readEndOfCentral:function(){var d=this.reader.lastIndexOfSignature(r.CENTRAL_DIRECTORY_END);if(d<0)throw this.isSignature(0,r.LOCAL_FILE_HEADER)?new Error("Corrupted zip: can't find end of central directory"):new Error("Can't find end of central directory : is this a zip file ? If it is, see https://stuk.github.io/jszip/documentation/howto/read_zip.html");this.reader.setIndex(d);var h=d;if(this.checkSignature(r.CENTRAL_DIRECTORY_END),this.readBlockEndOfCentral(),this.diskNumber===a.MAX_VALUE_16BITS||this.diskWithCentralDirStart===a.MAX_VALUE_16BITS||this.centralDirRecordsOnThisDisk===a.MAX_VALUE_16BITS||this.centralDirRecords===a.MAX_VALUE_16BITS||this.centralDirSize===a.MAX_VALUE_32BITS||this.centralDirOffset===a.MAX_VALUE_32BITS){if(this.zip64=!0,(d=this.reader.lastIndexOfSignature(r.ZIP64_CENTRAL_DIRECTORY_LOCATOR))<0)throw new Error("Corrupted zip: can't find the ZIP64 end of central directory locator");if(this.reader.setIndex(d),this.checkSignature(r.ZIP64_CENTRAL_DIRECTORY_LOCATOR),this.readBlockZip64EndOfCentralLocator(),!this.isSignature(this.relativeOffsetEndOfZip64CentralDir,r.ZIP64_CENTRAL_DIRECTORY_END)&&(this.relativeOffsetEndOfZip64CentralDir=this.reader.lastIndexOfSignature(r.ZIP64_CENTRAL_DIRECTORY_END),this.relativeOffsetEndOfZip64CentralDir<0))throw new Error("Corrupted zip: can't find the ZIP64 end of central directory");this.reader.setIndex(this.relativeOffsetEndOfZip64CentralDir),this.checkSignature(r.ZIP64_CENTRAL_DIRECTORY_END),this.readBlockZip64EndOfCentral()}var p=this.centralDirOffset+this.centralDirSize;this.zip64&&(p+=20,p+=12+this.zip64EndOfCentralSize);var b=h-p;if(0<b)this.isSignature(h,r.CENTRAL_FILE_HEADER)||(this.reader.zero=b);else if(b<0)throw new Error("Corrupted zip: missing "+Math.abs(b)+" bytes.")},prepareReader:function(d){this.reader=o(d)},load:function(d){this.prepareReader(d),this.readEndOfCentral(),this.readCentralDir(),this.readLocalFiles()}},n.exports=u},{"./reader/readerFor":22,"./signature":23,"./support":30,"./utils":32,"./zipEntry":34}],34:[function(i,n,s){var o=i("./reader/readerFor"),a=i("./utils"),r=i("./compressedObject"),l=i("./crc32"),c=i("./utf8"),u=i("./compressions"),d=i("./support");function h(p,b){this.options=p,this.loadOptions=b}h.prototype={isEncrypted:function(){return(1&this.bitFlag)==1},useUTF8:function(){return(2048&this.bitFlag)==2048},readLocalPart:function(p){var b,m;if(p.skip(22),this.fileNameLength=p.readInt(2),m=p.readInt(2),this.fileName=p.readData(this.fileNameLength),p.skip(m),this.compressedSize===-1||this.uncompressedSize===-1)throw new Error("Bug or corrupted zip : didn't get enough information from the central directory (compressedSize === -1 || uncompressedSize === -1)");if((b=(function(y){for(var g in u)if(Object.prototype.hasOwnProperty.call(u,g)&&u[g].magic===y)return u[g];return null})(this.compressionMethod))===null)throw new Error("Corrupted zip : compression "+a.pretty(this.compressionMethod)+" unknown (inner file : "+a.transformTo("string",this.fileName)+")");this.decompressed=new r(this.compressedSize,this.uncompressedSize,this.crc32,b,p.readData(this.compressedSize))},readCentralPart:function(p){this.versionMadeBy=p.readInt(2),p.skip(2),this.bitFlag=p.readInt(2),this.compressionMethod=p.readString(2),this.date=p.readDate(),this.crc32=p.readInt(4),this.compressedSize=p.readInt(4),this.uncompressedSize=p.readInt(4);var b=p.readInt(2);if(this.extraFieldsLength=p.readInt(2),this.fileCommentLength=p.readInt(2),this.diskNumberStart=p.readInt(2),this.internalFileAttributes=p.readInt(2),this.externalFileAttributes=p.readInt(4),this.localHeaderOffset=p.readInt(4),this.isEncrypted())throw new Error("Encrypted zip are not supported");p.skip(b),this.readExtraFields(p),this.parseZIP64ExtraField(p),this.fileComment=p.readData(this.fileCommentLength)},processAttributes:function(){this.unixPermissions=null,this.dosPermissions=null;var p=this.versionMadeBy>>8;this.dir=!!(16&this.externalFileAttributes),p==0&&(this.dosPermissions=63&this.externalFileAttributes),p==3&&(this.unixPermissions=this.externalFileAttributes>>16&65535),this.dir||this.fileNameStr.slice(-1)!=="/"||(this.dir=!0)},parseZIP64ExtraField:function(){if(this.extraFields[1]){var p=o(this.extraFields[1].value);this.uncompressedSize===a.MAX_VALUE_32BITS&&(this.uncompressedSize=p.readInt(8)),this.compressedSize===a.MAX_VALUE_32BITS&&(this.compressedSize=p.readInt(8)),this.localHeaderOffset===a.MAX_VALUE_32BITS&&(this.localHeaderOffset=p.readInt(8)),this.diskNumberStart===a.MAX_VALUE_32BITS&&(this.diskNumberStart=p.readInt(4))}},readExtraFields:function(p){var b,m,y,g=p.index+this.extraFieldsLength;for(this.extraFields||(this.extraFields={});p.index+4<g;)b=p.readInt(2),m=p.readInt(2),y=p.readData(m),this.extraFields[b]={id:b,length:m,value:y};p.setIndex(g)},handleUTF8:function(){var p=d.uint8array?"uint8array":"array";if(this.useUTF8())this.fileNameStr=c.utf8decode(this.fileName),this.fileCommentStr=c.utf8decode(this.fileComment);else{var b=this.findExtraFieldUnicodePath();if(b!==null)this.fileNameStr=b;else{var m=a.transformTo(p,this.fileName);this.fileNameStr=this.loadOptions.decodeFileName(m)}var y=this.findExtraFieldUnicodeComment();if(y!==null)this.fileCommentStr=y;else{var g=a.transformTo(p,this.fileComment);this.fileCommentStr=this.loadOptions.decodeFileName(g)}}},findExtraFieldUnicodePath:function(){var p=this.extraFields[28789];if(p){var b=o(p.value);return b.readInt(1)!==1||l(this.fileName)!==b.readInt(4)?null:c.utf8decode(b.readData(p.length-5))}return null},findExtraFieldUnicodeComment:function(){var p=this.extraFields[25461];if(p){var b=o(p.value);return b.readInt(1)!==1||l(this.fileComment)!==b.readInt(4)?null:c.utf8decode(b.readData(p.length-5))}return null}},n.exports=h},{"./compressedObject":2,"./compressions":3,"./crc32":4,"./reader/readerFor":22,"./support":30,"./utf8":31,"./utils":32}],35:[function(i,n,s){function o(b,m,y){this.name=b,this.dir=y.dir,this.date=y.date,this.comment=y.comment,this.unixPermissions=y.unixPermissions,this.dosPermissions=y.dosPermissions,this._data=m,this._dataBinary=y.binary,this.options={compression:y.compression,compressionOptions:y.compressionOptions}}var a=i("./stream/StreamHelper"),r=i("./stream/DataWorker"),l=i("./utf8"),c=i("./compressedObject"),u=i("./stream/GenericWorker");o.prototype={internalStream:function(b){var m=null,y="string";try{if(!b)throw new Error("No output type specified.");var g=(y=b.toLowerCase())==="string"||y==="text";y!=="binarystring"&&y!=="text"||(y="string"),m=this._decompressWorker();var w=!this._dataBinary;w&&!g&&(m=m.pipe(new l.Utf8EncodeWorker)),!w&&g&&(m=m.pipe(new l.Utf8DecodeWorker))}catch(S){(m=new u("error")).error(S)}return new a(m,y,"")},async:function(b,m){return this.internalStream(b).accumulate(m)},nodeStream:function(b,m){return this.internalStream(b||"nodebuffer").toNodejsStream(m)},_compressWorker:function(b,m){if(this._data instanceof c&&this._data.compression.magic===b.magic)return this._data.getCompressedWorker();var y=this._decompressWorker();return this._dataBinary||(y=y.pipe(new l.Utf8EncodeWorker)),c.createWorkerFrom(y,b,m)},_decompressWorker:function(){return this._data instanceof c?this._data.getContentWorker():this._data instanceof u?this._data:new r(this._data)}};for(var d=["asText","asBinary","asNodeBuffer","asUint8Array","asArrayBuffer"],h=function(){throw new Error("This method has been removed in JSZip 3.0, please check the upgrade guide.")},p=0;p<d.length;p++)o.prototype[d[p]]=h;n.exports=o},{"./compressedObject":2,"./stream/DataWorker":27,"./stream/GenericWorker":28,"./stream/StreamHelper":29,"./utf8":31}],36:[function(i,n,s){(function(o){var a,r,l=o.MutationObserver||o.WebKitMutationObserver;if(l){var c=0,u=new l(b),d=o.document.createTextNode("");u.observe(d,{characterData:!0}),a=function(){d.data=c=++c%2}}else if(o.setImmediate||o.MessageChannel===void 0)a="document"in o&&"onreadystatechange"in o.document.createElement("script")?function(){var m=o.document.createElement("script");m.onreadystatechange=function(){b(),m.onreadystatechange=null,m.parentNode.removeChild(m),m=null},o.document.documentElement.appendChild(m)}:function(){setTimeout(b,0)};else{var h=new o.MessageChannel;h.port1.onmessage=b,a=function(){h.port2.postMessage(0)}}var p=[];function b(){var m,y;r=!0;for(var g=p.length;g;){for(y=p,p=[],m=-1;++m<g;)y[m]();g=p.length}r=!1}n.exports=function(m){p.push(m)!==1||r||a()}}).call(this,typeof cs<"u"?cs:typeof self<"u"?self:typeof window<"u"?window:{})},{}],37:[function(i,n,s){var o=i("immediate");function a(){}var r={},l=["REJECTED"],c=["FULFILLED"],u=["PENDING"];function d(g){if(typeof g!="function")throw new TypeError("resolver must be a function");this.state=u,this.queue=[],this.outcome=void 0,g!==a&&m(this,g)}function h(g,w,S){this.promise=g,typeof w=="function"&&(this.onFulfilled=w,this.callFulfilled=this.otherCallFulfilled),typeof S=="function"&&(this.onRejected=S,this.callRejected=this.otherCallRejected)}function p(g,w,S){o(function(){var x;try{x=w(S)}catch(M){return r.reject(g,M)}x===g?r.reject(g,new TypeError("Cannot resolve promise with itself")):r.resolve(g,x)})}function b(g){var w=g&&g.then;if(g&&(typeof g=="object"||typeof g=="function")&&typeof w=="function")return function(){w.apply(g,arguments)}}function m(g,w){var S=!1;function x(C){S||(S=!0,r.reject(g,C))}function M(C){S||(S=!0,r.resolve(g,C))}var E=y(function(){w(M,x)});E.status==="error"&&x(E.value)}function y(g,w){var S={};try{S.value=g(w),S.status="success"}catch(x){S.status="error",S.value=x}return S}(n.exports=d).prototype.finally=function(g){if(typeof g!="function")return this;var w=this.constructor;return this.then(function(S){return w.resolve(g()).then(function(){return S})},function(S){return w.resolve(g()).then(function(){throw S})})},d.prototype.catch=function(g){return this.then(null,g)},d.prototype.then=function(g,w){if(typeof g!="function"&&this.state===c||typeof w!="function"&&this.state===l)return this;var S=new this.constructor(a);return this.state!==u?p(S,this.state===c?g:w,this.outcome):this.queue.push(new h(S,g,w)),S},h.prototype.callFulfilled=function(g){r.resolve(this.promise,g)},h.prototype.otherCallFulfilled=function(g){p(this.promise,this.onFulfilled,g)},h.prototype.callRejected=function(g){r.reject(this.promise,g)},h.prototype.otherCallRejected=function(g){p(this.promise,this.onRejected,g)},r.resolve=function(g,w){var S=y(b,w);if(S.status==="error")return r.reject(g,S.value);var x=S.value;if(x)m(g,x);else{g.state=c,g.outcome=w;for(var M=-1,E=g.queue.length;++M<E;)g.queue[M].callFulfilled(w)}return g},r.reject=function(g,w){g.state=l,g.outcome=w;for(var S=-1,x=g.queue.length;++S<x;)g.queue[S].callRejected(w);return g},d.resolve=function(g){return g instanceof this?g:r.resolve(new this(a),g)},d.reject=function(g){var w=new this(a);return r.reject(w,g)},d.all=function(g){var w=this;if(Object.prototype.toString.call(g)!=="[object Array]")return this.reject(new TypeError("must be an array"));var S=g.length,x=!1;if(!S)return this.resolve([]);for(var M=new Array(S),E=0,C=-1,D=new this(a);++C<S;)R(g[C],C);return D;function R(N,K){w.resolve(N).then(function($){M[K]=$,++E!==S||x||(x=!0,r.resolve(D,M))},function($){x||(x=!0,r.reject(D,$))})}},d.race=function(g){var w=this;if(Object.prototype.toString.call(g)!=="[object Array]")return this.reject(new TypeError("must be an array"));var S=g.length,x=!1;if(!S)return this.resolve([]);for(var M=-1,E=new this(a);++M<S;)C=g[M],w.resolve(C).then(function(D){x||(x=!0,r.resolve(E,D))},function(D){x||(x=!0,r.reject(E,D))});var C;return E}},{immediate:36}],38:[function(i,n,s){var o={};(0,i("./lib/utils/common").assign)(o,i("./lib/deflate"),i("./lib/inflate"),i("./lib/zlib/constants")),n.exports=o},{"./lib/deflate":39,"./lib/inflate":40,"./lib/utils/common":41,"./lib/zlib/constants":44}],39:[function(i,n,s){var o=i("./zlib/deflate"),a=i("./utils/common"),r=i("./utils/strings"),l=i("./zlib/messages"),c=i("./zlib/zstream"),u=Object.prototype.toString,d=0,h=-1,p=0,b=8;function m(g){if(!(this instanceof m))return new m(g);this.options=a.assign({level:h,method:b,chunkSize:16384,windowBits:15,memLevel:8,strategy:p,to:""},g||{});var w=this.options;w.raw&&0<w.windowBits?w.windowBits=-w.windowBits:w.gzip&&0<w.windowBits&&w.windowBits<16&&(w.windowBits+=16),this.err=0,this.msg="",this.ended=!1,this.chunks=[],this.strm=new c,this.strm.avail_out=0;var S=o.deflateInit2(this.strm,w.level,w.method,w.windowBits,w.memLevel,w.strategy);if(S!==d)throw new Error(l[S]);if(w.header&&o.deflateSetHeader(this.strm,w.header),w.dictionary){var x;if(x=typeof w.dictionary=="string"?r.string2buf(w.dictionary):u.call(w.dictionary)==="[object ArrayBuffer]"?new Uint8Array(w.dictionary):w.dictionary,(S=o.deflateSetDictionary(this.strm,x))!==d)throw new Error(l[S]);this._dict_set=!0}}function y(g,w){var S=new m(w);if(S.push(g,!0),S.err)throw S.msg||l[S.err];return S.result}m.prototype.push=function(g,w){var S,x,M=this.strm,E=this.options.chunkSize;if(this.ended)return!1;x=w===~~w?w:w===!0?4:0,typeof g=="string"?M.input=r.string2buf(g):u.call(g)==="[object ArrayBuffer]"?M.input=new Uint8Array(g):M.input=g,M.next_in=0,M.avail_in=M.input.length;do{if(M.avail_out===0&&(M.output=new a.Buf8(E),M.next_out=0,M.avail_out=E),(S=o.deflate(M,x))!==1&&S!==d)return this.onEnd(S),!(this.ended=!0);M.avail_out!==0&&(M.avail_in!==0||x!==4&&x!==2)||(this.options.to==="string"?this.onData(r.buf2binstring(a.shrinkBuf(M.output,M.next_out))):this.onData(a.shrinkBuf(M.output,M.next_out)))}while((0<M.avail_in||M.avail_out===0)&&S!==1);return x===4?(S=o.deflateEnd(this.strm),this.onEnd(S),this.ended=!0,S===d):x!==2||(this.onEnd(d),!(M.avail_out=0))},m.prototype.onData=function(g){this.chunks.push(g)},m.prototype.onEnd=function(g){g===d&&(this.options.to==="string"?this.result=this.chunks.join(""):this.result=a.flattenChunks(this.chunks)),this.chunks=[],this.err=g,this.msg=this.strm.msg},s.Deflate=m,s.deflate=y,s.deflateRaw=function(g,w){return(w=w||{}).raw=!0,y(g,w)},s.gzip=function(g,w){return(w=w||{}).gzip=!0,y(g,w)}},{"./utils/common":41,"./utils/strings":42,"./zlib/deflate":46,"./zlib/messages":51,"./zlib/zstream":53}],40:[function(i,n,s){var o=i("./zlib/inflate"),a=i("./utils/common"),r=i("./utils/strings"),l=i("./zlib/constants"),c=i("./zlib/messages"),u=i("./zlib/zstream"),d=i("./zlib/gzheader"),h=Object.prototype.toString;function p(m){if(!(this instanceof p))return new p(m);this.options=a.assign({chunkSize:16384,windowBits:0,to:""},m||{});var y=this.options;y.raw&&0<=y.windowBits&&y.windowBits<16&&(y.windowBits=-y.windowBits,y.windowBits===0&&(y.windowBits=-15)),!(0<=y.windowBits&&y.windowBits<16)||m&&m.windowBits||(y.windowBits+=32),15<y.windowBits&&y.windowBits<48&&(15&y.windowBits)==0&&(y.windowBits|=15),this.err=0,this.msg="",this.ended=!1,this.chunks=[],this.strm=new u,this.strm.avail_out=0;var g=o.inflateInit2(this.strm,y.windowBits);if(g!==l.Z_OK)throw new Error(c[g]);this.header=new d,o.inflateGetHeader(this.strm,this.header)}function b(m,y){var g=new p(y);if(g.push(m,!0),g.err)throw g.msg||c[g.err];return g.result}p.prototype.push=function(m,y){var g,w,S,x,M,E,C=this.strm,D=this.options.chunkSize,R=this.options.dictionary,N=!1;if(this.ended)return!1;w=y===~~y?y:y===!0?l.Z_FINISH:l.Z_NO_FLUSH,typeof m=="string"?C.input=r.binstring2buf(m):h.call(m)==="[object ArrayBuffer]"?C.input=new Uint8Array(m):C.input=m,C.next_in=0,C.avail_in=C.input.length;do{if(C.avail_out===0&&(C.output=new a.Buf8(D),C.next_out=0,C.avail_out=D),(g=o.inflate(C,l.Z_NO_FLUSH))===l.Z_NEED_DICT&&R&&(E=typeof R=="string"?r.string2buf(R):h.call(R)==="[object ArrayBuffer]"?new Uint8Array(R):R,g=o.inflateSetDictionary(this.strm,E)),g===l.Z_BUF_ERROR&&N===!0&&(g=l.Z_OK,N=!1),g!==l.Z_STREAM_END&&g!==l.Z_OK)return this.onEnd(g),!(this.ended=!0);C.next_out&&(C.avail_out!==0&&g!==l.Z_STREAM_END&&(C.avail_in!==0||w!==l.Z_FINISH&&w!==l.Z_SYNC_FLUSH)||(this.options.to==="string"?(S=r.utf8border(C.output,C.next_out),x=C.next_out-S,M=r.buf2string(C.output,S),C.next_out=x,C.avail_out=D-x,x&&a.arraySet(C.output,C.output,S,x,0),this.onData(M)):this.onData(a.shrinkBuf(C.output,C.next_out)))),C.avail_in===0&&C.avail_out===0&&(N=!0)}while((0<C.avail_in||C.avail_out===0)&&g!==l.Z_STREAM_END);return g===l.Z_STREAM_END&&(w=l.Z_FINISH),w===l.Z_FINISH?(g=o.inflateEnd(this.strm),this.onEnd(g),this.ended=!0,g===l.Z_OK):w!==l.Z_SYNC_FLUSH||(this.onEnd(l.Z_OK),!(C.avail_out=0))},p.prototype.onData=function(m){this.chunks.push(m)},p.prototype.onEnd=function(m){m===l.Z_OK&&(this.options.to==="string"?this.result=this.chunks.join(""):this.result=a.flattenChunks(this.chunks)),this.chunks=[],this.err=m,this.msg=this.strm.msg},s.Inflate=p,s.inflate=b,s.inflateRaw=function(m,y){return(y=y||{}).raw=!0,b(m,y)},s.ungzip=b},{"./utils/common":41,"./utils/strings":42,"./zlib/constants":44,"./zlib/gzheader":47,"./zlib/inflate":49,"./zlib/messages":51,"./zlib/zstream":53}],41:[function(i,n,s){var o=typeof Uint8Array<"u"&&typeof Uint16Array<"u"&&typeof Int32Array<"u";s.assign=function(l){for(var c=Array.prototype.slice.call(arguments,1);c.length;){var u=c.shift();if(u){if(typeof u!="object")throw new TypeError(u+"must be non-object");for(var d in u)u.hasOwnProperty(d)&&(l[d]=u[d])}}return l},s.shrinkBuf=function(l,c){return l.length===c?l:l.subarray?l.subarray(0,c):(l.length=c,l)};var a={arraySet:function(l,c,u,d,h){if(c.subarray&&l.subarray)l.set(c.subarray(u,u+d),h);else for(var p=0;p<d;p++)l[h+p]=c[u+p]},flattenChunks:function(l){var c,u,d,h,p,b;for(c=d=0,u=l.length;c<u;c++)d+=l[c].length;for(b=new Uint8Array(d),c=h=0,u=l.length;c<u;c++)p=l[c],b.set(p,h),h+=p.length;return b}},r={arraySet:function(l,c,u,d,h){for(var p=0;p<d;p++)l[h+p]=c[u+p]},flattenChunks:function(l){return[].concat.apply([],l)}};s.setTyped=function(l){l?(s.Buf8=Uint8Array,s.Buf16=Uint16Array,s.Buf32=Int32Array,s.assign(s,a)):(s.Buf8=Array,s.Buf16=Array,s.Buf32=Array,s.assign(s,r))},s.setTyped(o)},{}],42:[function(i,n,s){var o=i("./common"),a=!0,r=!0;try{String.fromCharCode.apply(null,[0])}catch{a=!1}try{String.fromCharCode.apply(null,new Uint8Array(1))}catch{r=!1}for(var l=new o.Buf8(256),c=0;c<256;c++)l[c]=252<=c?6:248<=c?5:240<=c?4:224<=c?3:192<=c?2:1;function u(d,h){if(h<65537&&(d.subarray&&r||!d.subarray&&a))return String.fromCharCode.apply(null,o.shrinkBuf(d,h));for(var p="",b=0;b<h;b++)p+=String.fromCharCode(d[b]);return p}l[254]=l[254]=1,s.string2buf=function(d){var h,p,b,m,y,g=d.length,w=0;for(m=0;m<g;m++)(64512&(p=d.charCodeAt(m)))==55296&&m+1<g&&(64512&(b=d.charCodeAt(m+1)))==56320&&(p=65536+(p-55296<<10)+(b-56320),m++),w+=p<128?1:p<2048?2:p<65536?3:4;for(h=new o.Buf8(w),m=y=0;y<w;m++)(64512&(p=d.charCodeAt(m)))==55296&&m+1<g&&(64512&(b=d.charCodeAt(m+1)))==56320&&(p=65536+(p-55296<<10)+(b-56320),m++),p<128?h[y++]=p:(p<2048?h[y++]=192|p>>>6:(p<65536?h[y++]=224|p>>>12:(h[y++]=240|p>>>18,h[y++]=128|p>>>12&63),h[y++]=128|p>>>6&63),h[y++]=128|63&p);return h},s.buf2binstring=function(d){return u(d,d.length)},s.binstring2buf=function(d){for(var h=new o.Buf8(d.length),p=0,b=h.length;p<b;p++)h[p]=d.charCodeAt(p);return h},s.buf2string=function(d,h){var p,b,m,y,g=h||d.length,w=new Array(2*g);for(p=b=0;p<g;)if((m=d[p++])<128)w[b++]=m;else if(4<(y=l[m]))w[b++]=65533,p+=y-1;else{for(m&=y===2?31:y===3?15:7;1<y&&p<g;)m=m<<6|63&d[p++],y--;1<y?w[b++]=65533:m<65536?w[b++]=m:(m-=65536,w[b++]=55296|m>>10&1023,w[b++]=56320|1023&m)}return u(w,b)},s.utf8border=function(d,h){var p;for((h=h||d.length)>d.length&&(h=d.length),p=h-1;0<=p&&(192&d[p])==128;)p--;return p<0||p===0?h:p+l[d[p]]>h?p:h}},{"./common":41}],43:[function(i,n,s){n.exports=function(o,a,r,l){for(var c=65535&o|0,u=o>>>16&65535|0,d=0;r!==0;){for(r-=d=2e3<r?2e3:r;u=u+(c=c+a[l++]|0)|0,--d;);c%=65521,u%=65521}return c|u<<16|0}},{}],44:[function(i,n,s){n.exports={Z_NO_FLUSH:0,Z_PARTIAL_FLUSH:1,Z_SYNC_FLUSH:2,Z_FULL_FLUSH:3,Z_FINISH:4,Z_BLOCK:5,Z_TREES:6,Z_OK:0,Z_STREAM_END:1,Z_NEED_DICT:2,Z_ERRNO:-1,Z_STREAM_ERROR:-2,Z_DATA_ERROR:-3,Z_BUF_ERROR:-5,Z_NO_COMPRESSION:0,Z_BEST_SPEED:1,Z_BEST_COMPRESSION:9,Z_DEFAULT_COMPRESSION:-1,Z_FILTERED:1,Z_HUFFMAN_ONLY:2,Z_RLE:3,Z_FIXED:4,Z_DEFAULT_STRATEGY:0,Z_BINARY:0,Z_TEXT:1,Z_UNKNOWN:2,Z_DEFLATED:8}},{}],45:[function(i,n,s){var o=(function(){for(var a,r=[],l=0;l<256;l++){a=l;for(var c=0;c<8;c++)a=1&a?3988292384^a>>>1:a>>>1;r[l]=a}return r})();n.exports=function(a,r,l,c){var u=o,d=c+l;a^=-1;for(var h=c;h<d;h++)a=a>>>8^u[255&(a^r[h])];return-1^a}},{}],46:[function(i,n,s){var o,a=i("../utils/common"),r=i("./trees"),l=i("./adler32"),c=i("./crc32"),u=i("./messages"),d=0,h=4,p=0,b=-2,m=-1,y=4,g=2,w=8,S=9,x=286,M=30,E=19,C=2*x+1,D=15,R=3,N=258,K=N+R+1,$=42,V=113,k=1,F=2,H=3,I=4;function A(v,U){return v.msg=u[U],U}function O(v){return(v<<1)-(4<v?9:0)}function ne(v){for(var U=v.length;0<=--U;)v[U]=0}function G(v){var U=v.state,W=U.pending;W>v.avail_out&&(W=v.avail_out),W!==0&&(a.arraySet(v.output,U.pending_buf,U.pending_out,W,v.next_out),v.next_out+=W,U.pending_out+=W,v.total_out+=W,v.avail_out-=W,U.pending-=W,U.pending===0&&(U.pending_out=0))}function q(v,U){r._tr_flush_block(v,0<=v.block_start?v.block_start:-1,v.strstart-v.block_start,U),v.block_start=v.strstart,G(v.strm)}function ce(v,U){v.pending_buf[v.pending++]=U}function se(v,U){v.pending_buf[v.pending++]=U>>>8&255,v.pending_buf[v.pending++]=255&U}function re(v,U){var W,_,T=v.max_chain_length,P=v.strstart,Y=v.prev_length,B=v.nice_match,z=v.strstart>v.w_size-K?v.strstart-(v.w_size-K):0,Z=v.window,ie=v.w_mask,oe=v.prev,me=v.strstart+N,$e=Z[P+Y-1],xe=Z[P+Y];v.prev_length>=v.good_match&&(T>>=2),B>v.lookahead&&(B=v.lookahead);do if(Z[(W=U)+Y]===xe&&Z[W+Y-1]===$e&&Z[W]===Z[P]&&Z[++W]===Z[P+1]){P+=2,W++;do;while(Z[++P]===Z[++W]&&Z[++P]===Z[++W]&&Z[++P]===Z[++W]&&Z[++P]===Z[++W]&&Z[++P]===Z[++W]&&Z[++P]===Z[++W]&&Z[++P]===Z[++W]&&Z[++P]===Z[++W]&&P<me);if(_=N-(me-P),P=me-N,Y<_){if(v.match_start=U,B<=(Y=_))break;$e=Z[P+Y-1],xe=Z[P+Y]}}while((U=oe[U&ie])>z&&--T!=0);return Y<=v.lookahead?Y:v.lookahead}function Se(v){var U,W,_,T,P,Y,B,z,Z,ie,oe=v.w_size;do{if(T=v.window_size-v.lookahead-v.strstart,v.strstart>=oe+(oe-K)){for(a.arraySet(v.window,v.window,oe,oe,0),v.match_start-=oe,v.strstart-=oe,v.block_start-=oe,U=W=v.hash_size;_=v.head[--U],v.head[U]=oe<=_?_-oe:0,--W;);for(U=W=oe;_=v.prev[--U],v.prev[U]=oe<=_?_-oe:0,--W;);T+=oe}if(v.strm.avail_in===0)break;if(Y=v.strm,B=v.window,z=v.strstart+v.lookahead,Z=T,ie=void 0,ie=Y.avail_in,Z<ie&&(ie=Z),W=ie===0?0:(Y.avail_in-=ie,a.arraySet(B,Y.input,Y.next_in,ie,z),Y.state.wrap===1?Y.adler=l(Y.adler,B,ie,z):Y.state.wrap===2&&(Y.adler=c(Y.adler,B,ie,z)),Y.next_in+=ie,Y.total_in+=ie,ie),v.lookahead+=W,v.lookahead+v.insert>=R)for(P=v.strstart-v.insert,v.ins_h=v.window[P],v.ins_h=(v.ins_h<<v.hash_shift^v.window[P+1])&v.hash_mask;v.insert&&(v.ins_h=(v.ins_h<<v.hash_shift^v.window[P+R-1])&v.hash_mask,v.prev[P&v.w_mask]=v.head[v.ins_h],v.head[v.ins_h]=P,P++,v.insert--,!(v.lookahead+v.insert<R)););}while(v.lookahead<K&&v.strm.avail_in!==0)}function Ie(v,U){for(var W,_;;){if(v.lookahead<K){if(Se(v),v.lookahead<K&&U===d)return k;if(v.lookahead===0)break}if(W=0,v.lookahead>=R&&(v.ins_h=(v.ins_h<<v.hash_shift^v.window[v.strstart+R-1])&v.hash_mask,W=v.prev[v.strstart&v.w_mask]=v.head[v.ins_h],v.head[v.ins_h]=v.strstart),W!==0&&v.strstart-W<=v.w_size-K&&(v.match_length=re(v,W)),v.match_length>=R)if(_=r._tr_tally(v,v.strstart-v.match_start,v.match_length-R),v.lookahead-=v.match_length,v.match_length<=v.max_lazy_match&&v.lookahead>=R){for(v.match_length--;v.strstart++,v.ins_h=(v.ins_h<<v.hash_shift^v.window[v.strstart+R-1])&v.hash_mask,W=v.prev[v.strstart&v.w_mask]=v.head[v.ins_h],v.head[v.ins_h]=v.strstart,--v.match_length!=0;);v.strstart++}else v.strstart+=v.match_length,v.match_length=0,v.ins_h=v.window[v.strstart],v.ins_h=(v.ins_h<<v.hash_shift^v.window[v.strstart+1])&v.hash_mask;else _=r._tr_tally(v,0,v.window[v.strstart]),v.lookahead--,v.strstart++;if(_&&(q(v,!1),v.strm.avail_out===0))return k}return v.insert=v.strstart<R-1?v.strstart:R-1,U===h?(q(v,!0),v.strm.avail_out===0?H:I):v.last_lit&&(q(v,!1),v.strm.avail_out===0)?k:F}function _e(v,U){for(var W,_,T;;){if(v.lookahead<K){if(Se(v),v.lookahead<K&&U===d)return k;if(v.lookahead===0)break}if(W=0,v.lookahead>=R&&(v.ins_h=(v.ins_h<<v.hash_shift^v.window[v.strstart+R-1])&v.hash_mask,W=v.prev[v.strstart&v.w_mask]=v.head[v.ins_h],v.head[v.ins_h]=v.strstart),v.prev_length=v.match_length,v.prev_match=v.match_start,v.match_length=R-1,W!==0&&v.prev_length<v.max_lazy_match&&v.strstart-W<=v.w_size-K&&(v.match_length=re(v,W),v.match_length<=5&&(v.strategy===1||v.match_length===R&&4096<v.strstart-v.match_start)&&(v.match_length=R-1)),v.prev_length>=R&&v.match_length<=v.prev_length){for(T=v.strstart+v.lookahead-R,_=r._tr_tally(v,v.strstart-1-v.prev_match,v.prev_length-R),v.lookahead-=v.prev_length-1,v.prev_length-=2;++v.strstart<=T&&(v.ins_h=(v.ins_h<<v.hash_shift^v.window[v.strstart+R-1])&v.hash_mask,W=v.prev[v.strstart&v.w_mask]=v.head[v.ins_h],v.head[v.ins_h]=v.strstart),--v.prev_length!=0;);if(v.match_available=0,v.match_length=R-1,v.strstart++,_&&(q(v,!1),v.strm.avail_out===0))return k}else if(v.match_available){if((_=r._tr_tally(v,0,v.window[v.strstart-1]))&&q(v,!1),v.strstart++,v.lookahead--,v.strm.avail_out===0)return k}else v.match_available=1,v.strstart++,v.lookahead--}return v.match_available&&(_=r._tr_tally(v,0,v.window[v.strstart-1]),v.match_available=0),v.insert=v.strstart<R-1?v.strstart:R-1,U===h?(q(v,!0),v.strm.avail_out===0?H:I):v.last_lit&&(q(v,!1),v.strm.avail_out===0)?k:F}function pe(v,U,W,_,T){this.good_length=v,this.max_lazy=U,this.nice_length=W,this.max_chain=_,this.func=T}function X(){this.strm=null,this.status=0,this.pending_buf=null,this.pending_buf_size=0,this.pending_out=0,this.pending=0,this.wrap=0,this.gzhead=null,this.gzindex=0,this.method=w,this.last_flush=-1,this.w_size=0,this.w_bits=0,this.w_mask=0,this.window=null,this.window_size=0,this.prev=null,this.head=null,this.ins_h=0,this.hash_size=0,this.hash_bits=0,this.hash_mask=0,this.hash_shift=0,this.block_start=0,this.match_length=0,this.prev_match=0,this.match_available=0,this.strstart=0,this.match_start=0,this.lookahead=0,this.prev_length=0,this.max_chain_length=0,this.max_lazy_match=0,this.level=0,this.strategy=0,this.good_match=0,this.nice_match=0,this.dyn_ltree=new a.Buf16(2*C),this.dyn_dtree=new a.Buf16(2*(2*M+1)),this.bl_tree=new a.Buf16(2*(2*E+1)),ne(this.dyn_ltree),ne(this.dyn_dtree),ne(this.bl_tree),this.l_desc=null,this.d_desc=null,this.bl_desc=null,this.bl_count=new a.Buf16(D+1),this.heap=new a.Buf16(2*x+1),ne(this.heap),this.heap_len=0,this.heap_max=0,this.depth=new a.Buf16(2*x+1),ne(this.depth),this.l_buf=0,this.lit_bufsize=0,this.last_lit=0,this.d_buf=0,this.opt_len=0,this.static_len=0,this.matches=0,this.insert=0,this.bi_buf=0,this.bi_valid=0}function Q(v){var U;return v&&v.state?(v.total_in=v.total_out=0,v.data_type=g,(U=v.state).pending=0,U.pending_out=0,U.wrap<0&&(U.wrap=-U.wrap),U.status=U.wrap?$:V,v.adler=U.wrap===2?0:1,U.last_flush=d,r._tr_init(U),p):A(v,b)}function L(v){var U=Q(v);return U===p&&(function(W){W.window_size=2*W.w_size,ne(W.head),W.max_lazy_match=o[W.level].max_lazy,W.good_match=o[W.level].good_length,W.nice_match=o[W.level].nice_length,W.max_chain_length=o[W.level].max_chain,W.strstart=0,W.block_start=0,W.lookahead=0,W.insert=0,W.match_length=W.prev_length=R-1,W.match_available=0,W.ins_h=0})(v.state),U}function j(v,U,W,_,T,P){if(!v)return b;var Y=1;if(U===m&&(U=6),_<0?(Y=0,_=-_):15<_&&(Y=2,_-=16),T<1||S<T||W!==w||_<8||15<_||U<0||9<U||P<0||y<P)return A(v,b);_===8&&(_=9);var B=new X;return(v.state=B).strm=v,B.wrap=Y,B.gzhead=null,B.w_bits=_,B.w_size=1<<B.w_bits,B.w_mask=B.w_size-1,B.hash_bits=T+7,B.hash_size=1<<B.hash_bits,B.hash_mask=B.hash_size-1,B.hash_shift=~~((B.hash_bits+R-1)/R),B.window=new a.Buf8(2*B.w_size),B.head=new a.Buf16(B.hash_size),B.prev=new a.Buf16(B.w_size),B.lit_bufsize=1<<T+6,B.pending_buf_size=4*B.lit_bufsize,B.pending_buf=new a.Buf8(B.pending_buf_size),B.d_buf=1*B.lit_bufsize,B.l_buf=3*B.lit_bufsize,B.level=U,B.strategy=P,B.method=W,L(v)}o=[new pe(0,0,0,0,function(v,U){var W=65535;for(W>v.pending_buf_size-5&&(W=v.pending_buf_size-5);;){if(v.lookahead<=1){if(Se(v),v.lookahead===0&&U===d)return k;if(v.lookahead===0)break}v.strstart+=v.lookahead,v.lookahead=0;var _=v.block_start+W;if((v.strstart===0||v.strstart>=_)&&(v.lookahead=v.strstart-_,v.strstart=_,q(v,!1),v.strm.avail_out===0)||v.strstart-v.block_start>=v.w_size-K&&(q(v,!1),v.strm.avail_out===0))return k}return v.insert=0,U===h?(q(v,!0),v.strm.avail_out===0?H:I):(v.strstart>v.block_start&&(q(v,!1),v.strm.avail_out),k)}),new pe(4,4,8,4,Ie),new pe(4,5,16,8,Ie),new pe(4,6,32,32,Ie),new pe(4,4,16,16,_e),new pe(8,16,32,32,_e),new pe(8,16,128,128,_e),new pe(8,32,128,256,_e),new pe(32,128,258,1024,_e),new pe(32,258,258,4096,_e)],s.deflateInit=function(v,U){return j(v,U,w,15,8,0)},s.deflateInit2=j,s.deflateReset=L,s.deflateResetKeep=Q,s.deflateSetHeader=function(v,U){return v&&v.state?v.state.wrap!==2?b:(v.state.gzhead=U,p):b},s.deflate=function(v,U){var W,_,T,P;if(!v||!v.state||5<U||U<0)return v?A(v,b):b;if(_=v.state,!v.output||!v.input&&v.avail_in!==0||_.status===666&&U!==h)return A(v,v.avail_out===0?-5:b);if(_.strm=v,W=_.last_flush,_.last_flush=U,_.status===$)if(_.wrap===2)v.adler=0,ce(_,31),ce(_,139),ce(_,8),_.gzhead?(ce(_,(_.gzhead.text?1:0)+(_.gzhead.hcrc?2:0)+(_.gzhead.extra?4:0)+(_.gzhead.name?8:0)+(_.gzhead.comment?16:0)),ce(_,255&_.gzhead.time),ce(_,_.gzhead.time>>8&255),ce(_,_.gzhead.time>>16&255),ce(_,_.gzhead.time>>24&255),ce(_,_.level===9?2:2<=_.strategy||_.level<2?4:0),ce(_,255&_.gzhead.os),_.gzhead.extra&&_.gzhead.extra.length&&(ce(_,255&_.gzhead.extra.length),ce(_,_.gzhead.extra.length>>8&255)),_.gzhead.hcrc&&(v.adler=c(v.adler,_.pending_buf,_.pending,0)),_.gzindex=0,_.status=69):(ce(_,0),ce(_,0),ce(_,0),ce(_,0),ce(_,0),ce(_,_.level===9?2:2<=_.strategy||_.level<2?4:0),ce(_,3),_.status=V);else{var Y=w+(_.w_bits-8<<4)<<8;Y|=(2<=_.strategy||_.level<2?0:_.level<6?1:_.level===6?2:3)<<6,_.strstart!==0&&(Y|=32),Y+=31-Y%31,_.status=V,se(_,Y),_.strstart!==0&&(se(_,v.adler>>>16),se(_,65535&v.adler)),v.adler=1}if(_.status===69)if(_.gzhead.extra){for(T=_.pending;_.gzindex<(65535&_.gzhead.extra.length)&&(_.pending!==_.pending_buf_size||(_.gzhead.hcrc&&_.pending>T&&(v.adler=c(v.adler,_.pending_buf,_.pending-T,T)),G(v),T=_.pending,_.pending!==_.pending_buf_size));)ce(_,255&_.gzhead.extra[_.gzindex]),_.gzindex++;_.gzhead.hcrc&&_.pending>T&&(v.adler=c(v.adler,_.pending_buf,_.pending-T,T)),_.gzindex===_.gzhead.extra.length&&(_.gzindex=0,_.status=73)}else _.status=73;if(_.status===73)if(_.gzhead.name){T=_.pending;do{if(_.pending===_.pending_buf_size&&(_.gzhead.hcrc&&_.pending>T&&(v.adler=c(v.adler,_.pending_buf,_.pending-T,T)),G(v),T=_.pending,_.pending===_.pending_buf_size)){P=1;break}P=_.gzindex<_.gzhead.name.length?255&_.gzhead.name.charCodeAt(_.gzindex++):0,ce(_,P)}while(P!==0);_.gzhead.hcrc&&_.pending>T&&(v.adler=c(v.adler,_.pending_buf,_.pending-T,T)),P===0&&(_.gzindex=0,_.status=91)}else _.status=91;if(_.status===91)if(_.gzhead.comment){T=_.pending;do{if(_.pending===_.pending_buf_size&&(_.gzhead.hcrc&&_.pending>T&&(v.adler=c(v.adler,_.pending_buf,_.pending-T,T)),G(v),T=_.pending,_.pending===_.pending_buf_size)){P=1;break}P=_.gzindex<_.gzhead.comment.length?255&_.gzhead.comment.charCodeAt(_.gzindex++):0,ce(_,P)}while(P!==0);_.gzhead.hcrc&&_.pending>T&&(v.adler=c(v.adler,_.pending_buf,_.pending-T,T)),P===0&&(_.status=103)}else _.status=103;if(_.status===103&&(_.gzhead.hcrc?(_.pending+2>_.pending_buf_size&&G(v),_.pending+2<=_.pending_buf_size&&(ce(_,255&v.adler),ce(_,v.adler>>8&255),v.adler=0,_.status=V)):_.status=V),_.pending!==0){if(G(v),v.avail_out===0)return _.last_flush=-1,p}else if(v.avail_in===0&&O(U)<=O(W)&&U!==h)return A(v,-5);if(_.status===666&&v.avail_in!==0)return A(v,-5);if(v.avail_in!==0||_.lookahead!==0||U!==d&&_.status!==666){var B=_.strategy===2?(function(z,Z){for(var ie;;){if(z.lookahead===0&&(Se(z),z.lookahead===0)){if(Z===d)return k;break}if(z.match_length=0,ie=r._tr_tally(z,0,z.window[z.strstart]),z.lookahead--,z.strstart++,ie&&(q(z,!1),z.strm.avail_out===0))return k}return z.insert=0,Z===h?(q(z,!0),z.strm.avail_out===0?H:I):z.last_lit&&(q(z,!1),z.strm.avail_out===0)?k:F})(_,U):_.strategy===3?(function(z,Z){for(var ie,oe,me,$e,xe=z.window;;){if(z.lookahead<=N){if(Se(z),z.lookahead<=N&&Z===d)return k;if(z.lookahead===0)break}if(z.match_length=0,z.lookahead>=R&&0<z.strstart&&(oe=xe[me=z.strstart-1])===xe[++me]&&oe===xe[++me]&&oe===xe[++me]){$e=z.strstart+N;do;while(oe===xe[++me]&&oe===xe[++me]&&oe===xe[++me]&&oe===xe[++me]&&oe===xe[++me]&&oe===xe[++me]&&oe===xe[++me]&&oe===xe[++me]&&me<$e);z.match_length=N-($e-me),z.match_length>z.lookahead&&(z.match_length=z.lookahead)}if(z.match_length>=R?(ie=r._tr_tally(z,1,z.match_length-R),z.lookahead-=z.match_length,z.strstart+=z.match_length,z.match_length=0):(ie=r._tr_tally(z,0,z.window[z.strstart]),z.lookahead--,z.strstart++),ie&&(q(z,!1),z.strm.avail_out===0))return k}return z.insert=0,Z===h?(q(z,!0),z.strm.avail_out===0?H:I):z.last_lit&&(q(z,!1),z.strm.avail_out===0)?k:F})(_,U):o[_.level].func(_,U);if(B!==H&&B!==I||(_.status=666),B===k||B===H)return v.avail_out===0&&(_.last_flush=-1),p;if(B===F&&(U===1?r._tr_align(_):U!==5&&(r._tr_stored_block(_,0,0,!1),U===3&&(ne(_.head),_.lookahead===0&&(_.strstart=0,_.block_start=0,_.insert=0))),G(v),v.avail_out===0))return _.last_flush=-1,p}return U!==h?p:_.wrap<=0?1:(_.wrap===2?(ce(_,255&v.adler),ce(_,v.adler>>8&255),ce(_,v.adler>>16&255),ce(_,v.adler>>24&255),ce(_,255&v.total_in),ce(_,v.total_in>>8&255),ce(_,v.total_in>>16&255),ce(_,v.total_in>>24&255)):(se(_,v.adler>>>16),se(_,65535&v.adler)),G(v),0<_.wrap&&(_.wrap=-_.wrap),_.pending!==0?p:1)},s.deflateEnd=function(v){var U;return v&&v.state?(U=v.state.status)!==$&&U!==69&&U!==73&&U!==91&&U!==103&&U!==V&&U!==666?A(v,b):(v.state=null,U===V?A(v,-3):p):b},s.deflateSetDictionary=function(v,U){var W,_,T,P,Y,B,z,Z,ie=U.length;if(!v||!v.state||(P=(W=v.state).wrap)===2||P===1&&W.status!==$||W.lookahead)return b;for(P===1&&(v.adler=l(v.adler,U,ie,0)),W.wrap=0,ie>=W.w_size&&(P===0&&(ne(W.head),W.strstart=0,W.block_start=0,W.insert=0),Z=new a.Buf8(W.w_size),a.arraySet(Z,U,ie-W.w_size,W.w_size,0),U=Z,ie=W.w_size),Y=v.avail_in,B=v.next_in,z=v.input,v.avail_in=ie,v.next_in=0,v.input=U,Se(W);W.lookahead>=R;){for(_=W.strstart,T=W.lookahead-(R-1);W.ins_h=(W.ins_h<<W.hash_shift^W.window[_+R-1])&W.hash_mask,W.prev[_&W.w_mask]=W.head[W.ins_h],W.head[W.ins_h]=_,_++,--T;);W.strstart=_,W.lookahead=R-1,Se(W)}return W.strstart+=W.lookahead,W.block_start=W.strstart,W.insert=W.lookahead,W.lookahead=0,W.match_length=W.prev_length=R-1,W.match_available=0,v.next_in=B,v.input=z,v.avail_in=Y,W.wrap=P,p},s.deflateInfo="pako deflate (from Nodeca project)"},{"../utils/common":41,"./adler32":43,"./crc32":45,"./messages":51,"./trees":52}],47:[function(i,n,s){n.exports=function(){this.text=0,this.time=0,this.xflags=0,this.os=0,this.extra=null,this.extra_len=0,this.name="",this.comment="",this.hcrc=0,this.done=!1}},{}],48:[function(i,n,s){n.exports=function(o,a){var r,l,c,u,d,h,p,b,m,y,g,w,S,x,M,E,C,D,R,N,K,$,V,k,F;r=o.state,l=o.next_in,k=o.input,c=l+(o.avail_in-5),u=o.next_out,F=o.output,d=u-(a-o.avail_out),h=u+(o.avail_out-257),p=r.dmax,b=r.wsize,m=r.whave,y=r.wnext,g=r.window,w=r.hold,S=r.bits,x=r.lencode,M=r.distcode,E=(1<<r.lenbits)-1,C=(1<<r.distbits)-1;e:do{S<15&&(w+=k[l++]<<S,S+=8,w+=k[l++]<<S,S+=8),D=x[w&E];t:for(;;){if(w>>>=R=D>>>24,S-=R,(R=D>>>16&255)===0)F[u++]=65535&D;else{if(!(16&R)){if((64&R)==0){D=x[(65535&D)+(w&(1<<R)-1)];continue t}if(32&R){r.mode=12;break e}o.msg="invalid literal/length code",r.mode=30;break e}N=65535&D,(R&=15)&&(S<R&&(w+=k[l++]<<S,S+=8),N+=w&(1<<R)-1,w>>>=R,S-=R),S<15&&(w+=k[l++]<<S,S+=8,w+=k[l++]<<S,S+=8),D=M[w&C];i:for(;;){if(w>>>=R=D>>>24,S-=R,!(16&(R=D>>>16&255))){if((64&R)==0){D=M[(65535&D)+(w&(1<<R)-1)];continue i}o.msg="invalid distance code",r.mode=30;break e}if(K=65535&D,S<(R&=15)&&(w+=k[l++]<<S,(S+=8)<R&&(w+=k[l++]<<S,S+=8)),p<(K+=w&(1<<R)-1)){o.msg="invalid distance too far back",r.mode=30;break e}if(w>>>=R,S-=R,(R=u-d)<K){if(m<(R=K-R)&&r.sane){o.msg="invalid distance too far back",r.mode=30;break e}if(V=g,($=0)===y){if($+=b-R,R<N){for(N-=R;F[u++]=g[$++],--R;);$=u-K,V=F}}else if(y<R){if($+=b+y-R,(R-=y)<N){for(N-=R;F[u++]=g[$++],--R;);if($=0,y<N){for(N-=R=y;F[u++]=g[$++],--R;);$=u-K,V=F}}}else if($+=y-R,R<N){for(N-=R;F[u++]=g[$++],--R;);$=u-K,V=F}for(;2<N;)F[u++]=V[$++],F[u++]=V[$++],F[u++]=V[$++],N-=3;N&&(F[u++]=V[$++],1<N&&(F[u++]=V[$++]))}else{for($=u-K;F[u++]=F[$++],F[u++]=F[$++],F[u++]=F[$++],2<(N-=3););N&&(F[u++]=F[$++],1<N&&(F[u++]=F[$++]))}break}}break}}while(l<c&&u<h);l-=N=S>>3,w&=(1<<(S-=N<<3))-1,o.next_in=l,o.next_out=u,o.avail_in=l<c?c-l+5:5-(l-c),o.avail_out=u<h?h-u+257:257-(u-h),r.hold=w,r.bits=S}},{}],49:[function(i,n,s){var o=i("../utils/common"),a=i("./adler32"),r=i("./crc32"),l=i("./inffast"),c=i("./inftrees"),u=1,d=2,h=0,p=-2,b=1,m=852,y=592;function g($){return($>>>24&255)+($>>>8&65280)+((65280&$)<<8)+((255&$)<<24)}function w(){this.mode=0,this.last=!1,this.wrap=0,this.havedict=!1,this.flags=0,this.dmax=0,this.check=0,this.total=0,this.head=null,this.wbits=0,this.wsize=0,this.whave=0,this.wnext=0,this.window=null,this.hold=0,this.bits=0,this.length=0,this.offset=0,this.extra=0,this.lencode=null,this.distcode=null,this.lenbits=0,this.distbits=0,this.ncode=0,this.nlen=0,this.ndist=0,this.have=0,this.next=null,this.lens=new o.Buf16(320),this.work=new o.Buf16(288),this.lendyn=null,this.distdyn=null,this.sane=0,this.back=0,this.was=0}function S($){var V;return $&&$.state?(V=$.state,$.total_in=$.total_out=V.total=0,$.msg="",V.wrap&&($.adler=1&V.wrap),V.mode=b,V.last=0,V.havedict=0,V.dmax=32768,V.head=null,V.hold=0,V.bits=0,V.lencode=V.lendyn=new o.Buf32(m),V.distcode=V.distdyn=new o.Buf32(y),V.sane=1,V.back=-1,h):p}function x($){var V;return $&&$.state?((V=$.state).wsize=0,V.whave=0,V.wnext=0,S($)):p}function M($,V){var k,F;return $&&$.state?(F=$.state,V<0?(k=0,V=-V):(k=1+(V>>4),V<48&&(V&=15)),V&&(V<8||15<V)?p:(F.window!==null&&F.wbits!==V&&(F.window=null),F.wrap=k,F.wbits=V,x($))):p}function E($,V){var k,F;return $?(F=new w,($.state=F).window=null,(k=M($,V))!==h&&($.state=null),k):p}var C,D,R=!0;function N($){if(R){var V;for(C=new o.Buf32(512),D=new o.Buf32(32),V=0;V<144;)$.lens[V++]=8;for(;V<256;)$.lens[V++]=9;for(;V<280;)$.lens[V++]=7;for(;V<288;)$.lens[V++]=8;for(c(u,$.lens,0,288,C,0,$.work,{bits:9}),V=0;V<32;)$.lens[V++]=5;c(d,$.lens,0,32,D,0,$.work,{bits:5}),R=!1}$.lencode=C,$.lenbits=9,$.distcode=D,$.distbits=5}function K($,V,k,F){var H,I=$.state;return I.window===null&&(I.wsize=1<<I.wbits,I.wnext=0,I.whave=0,I.window=new o.Buf8(I.wsize)),F>=I.wsize?(o.arraySet(I.window,V,k-I.wsize,I.wsize,0),I.wnext=0,I.whave=I.wsize):(F<(H=I.wsize-I.wnext)&&(H=F),o.arraySet(I.window,V,k-F,H,I.wnext),(F-=H)?(o.arraySet(I.window,V,k-F,F,0),I.wnext=F,I.whave=I.wsize):(I.wnext+=H,I.wnext===I.wsize&&(I.wnext=0),I.whave<I.wsize&&(I.whave+=H))),0}s.inflateReset=x,s.inflateReset2=M,s.inflateResetKeep=S,s.inflateInit=function($){return E($,15)},s.inflateInit2=E,s.inflate=function($,V){var k,F,H,I,A,O,ne,G,q,ce,se,re,Se,Ie,_e,pe,X,Q,L,j,v,U,W,_,T=0,P=new o.Buf8(4),Y=[16,17,18,0,8,7,9,6,10,5,11,4,12,3,13,2,14,1,15];if(!$||!$.state||!$.output||!$.input&&$.avail_in!==0)return p;(k=$.state).mode===12&&(k.mode=13),A=$.next_out,H=$.output,ne=$.avail_out,I=$.next_in,F=$.input,O=$.avail_in,G=k.hold,q=k.bits,ce=O,se=ne,U=h;e:for(;;)switch(k.mode){case b:if(k.wrap===0){k.mode=13;break}for(;q<16;){if(O===0)break e;O--,G+=F[I++]<<q,q+=8}if(2&k.wrap&&G===35615){P[k.check=0]=255&G,P[1]=G>>>8&255,k.check=r(k.check,P,2,0),q=G=0,k.mode=2;break}if(k.flags=0,k.head&&(k.head.done=!1),!(1&k.wrap)||(((255&G)<<8)+(G>>8))%31){$.msg="incorrect header check",k.mode=30;break}if((15&G)!=8){$.msg="unknown compression method",k.mode=30;break}if(q-=4,v=8+(15&(G>>>=4)),k.wbits===0)k.wbits=v;else if(v>k.wbits){$.msg="invalid window size",k.mode=30;break}k.dmax=1<<v,$.adler=k.check=1,k.mode=512&G?10:12,q=G=0;break;case 2:for(;q<16;){if(O===0)break e;O--,G+=F[I++]<<q,q+=8}if(k.flags=G,(255&k.flags)!=8){$.msg="unknown compression method",k.mode=30;break}if(57344&k.flags){$.msg="unknown header flags set",k.mode=30;break}k.head&&(k.head.text=G>>8&1),512&k.flags&&(P[0]=255&G,P[1]=G>>>8&255,k.check=r(k.check,P,2,0)),q=G=0,k.mode=3;case 3:for(;q<32;){if(O===0)break e;O--,G+=F[I++]<<q,q+=8}k.head&&(k.head.time=G),512&k.flags&&(P[0]=255&G,P[1]=G>>>8&255,P[2]=G>>>16&255,P[3]=G>>>24&255,k.check=r(k.check,P,4,0)),q=G=0,k.mode=4;case 4:for(;q<16;){if(O===0)break e;O--,G+=F[I++]<<q,q+=8}k.head&&(k.head.xflags=255&G,k.head.os=G>>8),512&k.flags&&(P[0]=255&G,P[1]=G>>>8&255,k.check=r(k.check,P,2,0)),q=G=0,k.mode=5;case 5:if(1024&k.flags){for(;q<16;){if(O===0)break e;O--,G+=F[I++]<<q,q+=8}k.length=G,k.head&&(k.head.extra_len=G),512&k.flags&&(P[0]=255&G,P[1]=G>>>8&255,k.check=r(k.check,P,2,0)),q=G=0}else k.head&&(k.head.extra=null);k.mode=6;case 6:if(1024&k.flags&&(O<(re=k.length)&&(re=O),re&&(k.head&&(v=k.head.extra_len-k.length,k.head.extra||(k.head.extra=new Array(k.head.extra_len)),o.arraySet(k.head.extra,F,I,re,v)),512&k.flags&&(k.check=r(k.check,F,re,I)),O-=re,I+=re,k.length-=re),k.length))break e;k.length=0,k.mode=7;case 7:if(2048&k.flags){if(O===0)break e;for(re=0;v=F[I+re++],k.head&&v&&k.length<65536&&(k.head.name+=String.fromCharCode(v)),v&&re<O;);if(512&k.flags&&(k.check=r(k.check,F,re,I)),O-=re,I+=re,v)break e}else k.head&&(k.head.name=null);k.length=0,k.mode=8;case 8:if(4096&k.flags){if(O===0)break e;for(re=0;v=F[I+re++],k.head&&v&&k.length<65536&&(k.head.comment+=String.fromCharCode(v)),v&&re<O;);if(512&k.flags&&(k.check=r(k.check,F,re,I)),O-=re,I+=re,v)break e}else k.head&&(k.head.comment=null);k.mode=9;case 9:if(512&k.flags){for(;q<16;){if(O===0)break e;O--,G+=F[I++]<<q,q+=8}if(G!==(65535&k.check)){$.msg="header crc mismatch",k.mode=30;break}q=G=0}k.head&&(k.head.hcrc=k.flags>>9&1,k.head.done=!0),$.adler=k.check=0,k.mode=12;break;case 10:for(;q<32;){if(O===0)break e;O--,G+=F[I++]<<q,q+=8}$.adler=k.check=g(G),q=G=0,k.mode=11;case 11:if(k.havedict===0)return $.next_out=A,$.avail_out=ne,$.next_in=I,$.avail_in=O,k.hold=G,k.bits=q,2;$.adler=k.check=1,k.mode=12;case 12:if(V===5||V===6)break e;case 13:if(k.last){G>>>=7&q,q-=7&q,k.mode=27;break}for(;q<3;){if(O===0)break e;O--,G+=F[I++]<<q,q+=8}switch(k.last=1&G,q-=1,3&(G>>>=1)){case 0:k.mode=14;break;case 1:if(N(k),k.mode=20,V!==6)break;G>>>=2,q-=2;break e;case 2:k.mode=17;break;case 3:$.msg="invalid block type",k.mode=30}G>>>=2,q-=2;break;case 14:for(G>>>=7&q,q-=7&q;q<32;){if(O===0)break e;O--,G+=F[I++]<<q,q+=8}if((65535&G)!=(G>>>16^65535)){$.msg="invalid stored block lengths",k.mode=30;break}if(k.length=65535&G,q=G=0,k.mode=15,V===6)break e;case 15:k.mode=16;case 16:if(re=k.length){if(O<re&&(re=O),ne<re&&(re=ne),re===0)break e;o.arraySet(H,F,I,re,A),O-=re,I+=re,ne-=re,A+=re,k.length-=re;break}k.mode=12;break;case 17:for(;q<14;){if(O===0)break e;O--,G+=F[I++]<<q,q+=8}if(k.nlen=257+(31&G),G>>>=5,q-=5,k.ndist=1+(31&G),G>>>=5,q-=5,k.ncode=4+(15&G),G>>>=4,q-=4,286<k.nlen||30<k.ndist){$.msg="too many length or distance symbols",k.mode=30;break}k.have=0,k.mode=18;case 18:for(;k.have<k.ncode;){for(;q<3;){if(O===0)break e;O--,G+=F[I++]<<q,q+=8}k.lens[Y[k.have++]]=7&G,G>>>=3,q-=3}for(;k.have<19;)k.lens[Y[k.have++]]=0;if(k.lencode=k.lendyn,k.lenbits=7,W={bits:k.lenbits},U=c(0,k.lens,0,19,k.lencode,0,k.work,W),k.lenbits=W.bits,U){$.msg="invalid code lengths set",k.mode=30;break}k.have=0,k.mode=19;case 19:for(;k.have<k.nlen+k.ndist;){for(;pe=(T=k.lencode[G&(1<<k.lenbits)-1])>>>16&255,X=65535&T,!((_e=T>>>24)<=q);){if(O===0)break e;O--,G+=F[I++]<<q,q+=8}if(X<16)G>>>=_e,q-=_e,k.lens[k.have++]=X;else{if(X===16){for(_=_e+2;q<_;){if(O===0)break e;O--,G+=F[I++]<<q,q+=8}if(G>>>=_e,q-=_e,k.have===0){$.msg="invalid bit length repeat",k.mode=30;break}v=k.lens[k.have-1],re=3+(3&G),G>>>=2,q-=2}else if(X===17){for(_=_e+3;q<_;){if(O===0)break e;O--,G+=F[I++]<<q,q+=8}q-=_e,v=0,re=3+(7&(G>>>=_e)),G>>>=3,q-=3}else{for(_=_e+7;q<_;){if(O===0)break e;O--,G+=F[I++]<<q,q+=8}q-=_e,v=0,re=11+(127&(G>>>=_e)),G>>>=7,q-=7}if(k.have+re>k.nlen+k.ndist){$.msg="invalid bit length repeat",k.mode=30;break}for(;re--;)k.lens[k.have++]=v}}if(k.mode===30)break;if(k.lens[256]===0){$.msg="invalid code -- missing end-of-block",k.mode=30;break}if(k.lenbits=9,W={bits:k.lenbits},U=c(u,k.lens,0,k.nlen,k.lencode,0,k.work,W),k.lenbits=W.bits,U){$.msg="invalid literal/lengths set",k.mode=30;break}if(k.distbits=6,k.distcode=k.distdyn,W={bits:k.distbits},U=c(d,k.lens,k.nlen,k.ndist,k.distcode,0,k.work,W),k.distbits=W.bits,U){$.msg="invalid distances set",k.mode=30;break}if(k.mode=20,V===6)break e;case 20:k.mode=21;case 21:if(6<=O&&258<=ne){$.next_out=A,$.avail_out=ne,$.next_in=I,$.avail_in=O,k.hold=G,k.bits=q,l($,se),A=$.next_out,H=$.output,ne=$.avail_out,I=$.next_in,F=$.input,O=$.avail_in,G=k.hold,q=k.bits,k.mode===12&&(k.back=-1);break}for(k.back=0;pe=(T=k.lencode[G&(1<<k.lenbits)-1])>>>16&255,X=65535&T,!((_e=T>>>24)<=q);){if(O===0)break e;O--,G+=F[I++]<<q,q+=8}if(pe&&(240&pe)==0){for(Q=_e,L=pe,j=X;pe=(T=k.lencode[j+((G&(1<<Q+L)-1)>>Q)])>>>16&255,X=65535&T,!(Q+(_e=T>>>24)<=q);){if(O===0)break e;O--,G+=F[I++]<<q,q+=8}G>>>=Q,q-=Q,k.back+=Q}if(G>>>=_e,q-=_e,k.back+=_e,k.length=X,pe===0){k.mode=26;break}if(32&pe){k.back=-1,k.mode=12;break}if(64&pe){$.msg="invalid literal/length code",k.mode=30;break}k.extra=15&pe,k.mode=22;case 22:if(k.extra){for(_=k.extra;q<_;){if(O===0)break e;O--,G+=F[I++]<<q,q+=8}k.length+=G&(1<<k.extra)-1,G>>>=k.extra,q-=k.extra,k.back+=k.extra}k.was=k.length,k.mode=23;case 23:for(;pe=(T=k.distcode[G&(1<<k.distbits)-1])>>>16&255,X=65535&T,!((_e=T>>>24)<=q);){if(O===0)break e;O--,G+=F[I++]<<q,q+=8}if((240&pe)==0){for(Q=_e,L=pe,j=X;pe=(T=k.distcode[j+((G&(1<<Q+L)-1)>>Q)])>>>16&255,X=65535&T,!(Q+(_e=T>>>24)<=q);){if(O===0)break e;O--,G+=F[I++]<<q,q+=8}G>>>=Q,q-=Q,k.back+=Q}if(G>>>=_e,q-=_e,k.back+=_e,64&pe){$.msg="invalid distance code",k.mode=30;break}k.offset=X,k.extra=15&pe,k.mode=24;case 24:if(k.extra){for(_=k.extra;q<_;){if(O===0)break e;O--,G+=F[I++]<<q,q+=8}k.offset+=G&(1<<k.extra)-1,G>>>=k.extra,q-=k.extra,k.back+=k.extra}if(k.offset>k.dmax){$.msg="invalid distance too far back",k.mode=30;break}k.mode=25;case 25:if(ne===0)break e;if(re=se-ne,k.offset>re){if((re=k.offset-re)>k.whave&&k.sane){$.msg="invalid distance too far back",k.mode=30;break}Se=re>k.wnext?(re-=k.wnext,k.wsize-re):k.wnext-re,re>k.length&&(re=k.length),Ie=k.window}else Ie=H,Se=A-k.offset,re=k.length;for(ne<re&&(re=ne),ne-=re,k.length-=re;H[A++]=Ie[Se++],--re;);k.length===0&&(k.mode=21);break;case 26:if(ne===0)break e;H[A++]=k.length,ne--,k.mode=21;break;case 27:if(k.wrap){for(;q<32;){if(O===0)break e;O--,G|=F[I++]<<q,q+=8}if(se-=ne,$.total_out+=se,k.total+=se,se&&($.adler=k.check=k.flags?r(k.check,H,se,A-se):a(k.check,H,se,A-se)),se=ne,(k.flags?G:g(G))!==k.check){$.msg="incorrect data check",k.mode=30;break}q=G=0}k.mode=28;case 28:if(k.wrap&&k.flags){for(;q<32;){if(O===0)break e;O--,G+=F[I++]<<q,q+=8}if(G!==(4294967295&k.total)){$.msg="incorrect length check",k.mode=30;break}q=G=0}k.mode=29;case 29:U=1;break e;case 30:U=-3;break e;case 31:return-4;case 32:default:return p}return $.next_out=A,$.avail_out=ne,$.next_in=I,$.avail_in=O,k.hold=G,k.bits=q,(k.wsize||se!==$.avail_out&&k.mode<30&&(k.mode<27||V!==4))&&K($,$.output,$.next_out,se-$.avail_out)?(k.mode=31,-4):(ce-=$.avail_in,se-=$.avail_out,$.total_in+=ce,$.total_out+=se,k.total+=se,k.wrap&&se&&($.adler=k.check=k.flags?r(k.check,H,se,$.next_out-se):a(k.check,H,se,$.next_out-se)),$.data_type=k.bits+(k.last?64:0)+(k.mode===12?128:0)+(k.mode===20||k.mode===15?256:0),(ce==0&&se===0||V===4)&&U===h&&(U=-5),U)},s.inflateEnd=function($){if(!$||!$.state)return p;var V=$.state;return V.window&&(V.window=null),$.state=null,h},s.inflateGetHeader=function($,V){var k;return $&&$.state?(2&(k=$.state).wrap)==0?p:((k.head=V).done=!1,h):p},s.inflateSetDictionary=function($,V){var k,F=V.length;return $&&$.state?(k=$.state).wrap!==0&&k.mode!==11?p:k.mode===11&&a(1,V,F,0)!==k.check?-3:K($,V,F,F)?(k.mode=31,-4):(k.havedict=1,h):p},s.inflateInfo="pako inflate (from Nodeca project)"},{"../utils/common":41,"./adler32":43,"./crc32":45,"./inffast":48,"./inftrees":50}],50:[function(i,n,s){var o=i("../utils/common"),a=[3,4,5,6,7,8,9,10,11,13,15,17,19,23,27,31,35,43,51,59,67,83,99,115,131,163,195,227,258,0,0],r=[16,16,16,16,16,16,16,16,17,17,17,17,18,18,18,18,19,19,19,19,20,20,20,20,21,21,21,21,16,72,78],l=[1,2,3,4,5,7,9,13,17,25,33,49,65,97,129,193,257,385,513,769,1025,1537,2049,3073,4097,6145,8193,12289,16385,24577,0,0],c=[16,16,16,16,17,17,18,18,19,19,20,20,21,21,22,22,23,23,24,24,25,25,26,26,27,27,28,28,29,29,64,64];n.exports=function(u,d,h,p,b,m,y,g){var w,S,x,M,E,C,D,R,N,K=g.bits,$=0,V=0,k=0,F=0,H=0,I=0,A=0,O=0,ne=0,G=0,q=null,ce=0,se=new o.Buf16(16),re=new o.Buf16(16),Se=null,Ie=0;for($=0;$<=15;$++)se[$]=0;for(V=0;V<p;V++)se[d[h+V]]++;for(H=K,F=15;1<=F&&se[F]===0;F--);if(F<H&&(H=F),F===0)return b[m++]=20971520,b[m++]=20971520,g.bits=1,0;for(k=1;k<F&&se[k]===0;k++);for(H<k&&(H=k),$=O=1;$<=15;$++)if(O<<=1,(O-=se[$])<0)return-1;if(0<O&&(u===0||F!==1))return-1;for(re[1]=0,$=1;$<15;$++)re[$+1]=re[$]+se[$];for(V=0;V<p;V++)d[h+V]!==0&&(y[re[d[h+V]]++]=V);if(C=u===0?(q=Se=y,19):u===1?(q=a,ce-=257,Se=r,Ie-=257,256):(q=l,Se=c,-1),$=k,E=m,A=V=G=0,x=-1,M=(ne=1<<(I=H))-1,u===1&&852<ne||u===2&&592<ne)return 1;for(;;){for(D=$-A,N=y[V]<C?(R=0,y[V]):y[V]>C?(R=Se[Ie+y[V]],q[ce+y[V]]):(R=96,0),w=1<<$-A,k=S=1<<I;b[E+(G>>A)+(S-=w)]=D<<24|R<<16|N|0,S!==0;);for(w=1<<$-1;G&w;)w>>=1;if(w!==0?(G&=w-1,G+=w):G=0,V++,--se[$]==0){if($===F)break;$=d[h+y[V]]}if(H<$&&(G&M)!==x){for(A===0&&(A=H),E+=k,O=1<<(I=$-A);I+A<F&&!((O-=se[I+A])<=0);)I++,O<<=1;if(ne+=1<<I,u===1&&852<ne||u===2&&592<ne)return 1;b[x=G&M]=H<<24|I<<16|E-m|0}}return G!==0&&(b[E+G]=$-A<<24|64<<16|0),g.bits=H,0}},{"../utils/common":41}],51:[function(i,n,s){n.exports={2:"need dictionary",1:"stream end",0:"","-1":"file error","-2":"stream error","-3":"data error","-4":"insufficient memory","-5":"buffer error","-6":"incompatible version"}},{}],52:[function(i,n,s){var o=i("../utils/common"),a=0,r=1;function l(T){for(var P=T.length;0<=--P;)T[P]=0}var c=0,u=29,d=256,h=d+1+u,p=30,b=19,m=2*h+1,y=15,g=16,w=7,S=256,x=16,M=17,E=18,C=[0,0,0,0,0,0,0,0,1,1,1,1,2,2,2,2,3,3,3,3,4,4,4,4,5,5,5,5,0],D=[0,0,0,0,1,1,2,2,3,3,4,4,5,5,6,6,7,7,8,8,9,9,10,10,11,11,12,12,13,13],R=[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,2,3,7],N=[16,17,18,0,8,7,9,6,10,5,11,4,12,3,13,2,14,1,15],K=new Array(2*(h+2));l(K);var $=new Array(2*p);l($);var V=new Array(512);l(V);var k=new Array(256);l(k);var F=new Array(u);l(F);var H,I,A,O=new Array(p);function ne(T,P,Y,B,z){this.static_tree=T,this.extra_bits=P,this.extra_base=Y,this.elems=B,this.max_length=z,this.has_stree=T&&T.length}function G(T,P){this.dyn_tree=T,this.max_code=0,this.stat_desc=P}function q(T){return T<256?V[T]:V[256+(T>>>7)]}function ce(T,P){T.pending_buf[T.pending++]=255&P,T.pending_buf[T.pending++]=P>>>8&255}function se(T,P,Y){T.bi_valid>g-Y?(T.bi_buf|=P<<T.bi_valid&65535,ce(T,T.bi_buf),T.bi_buf=P>>g-T.bi_valid,T.bi_valid+=Y-g):(T.bi_buf|=P<<T.bi_valid&65535,T.bi_valid+=Y)}function re(T,P,Y){se(T,Y[2*P],Y[2*P+1])}function Se(T,P){for(var Y=0;Y|=1&T,T>>>=1,Y<<=1,0<--P;);return Y>>>1}function Ie(T,P,Y){var B,z,Z=new Array(y+1),ie=0;for(B=1;B<=y;B++)Z[B]=ie=ie+Y[B-1]<<1;for(z=0;z<=P;z++){var oe=T[2*z+1];oe!==0&&(T[2*z]=Se(Z[oe]++,oe))}}function _e(T){var P;for(P=0;P<h;P++)T.dyn_ltree[2*P]=0;for(P=0;P<p;P++)T.dyn_dtree[2*P]=0;for(P=0;P<b;P++)T.bl_tree[2*P]=0;T.dyn_ltree[2*S]=1,T.opt_len=T.static_len=0,T.last_lit=T.matches=0}function pe(T){8<T.bi_valid?ce(T,T.bi_buf):0<T.bi_valid&&(T.pending_buf[T.pending++]=T.bi_buf),T.bi_buf=0,T.bi_valid=0}function X(T,P,Y,B){var z=2*P,Z=2*Y;return T[z]<T[Z]||T[z]===T[Z]&&B[P]<=B[Y]}function Q(T,P,Y){for(var B=T.heap[Y],z=Y<<1;z<=T.heap_len&&(z<T.heap_len&&X(P,T.heap[z+1],T.heap[z],T.depth)&&z++,!X(P,B,T.heap[z],T.depth));)T.heap[Y]=T.heap[z],Y=z,z<<=1;T.heap[Y]=B}function L(T,P,Y){var B,z,Z,ie,oe=0;if(T.last_lit!==0)for(;B=T.pending_buf[T.d_buf+2*oe]<<8|T.pending_buf[T.d_buf+2*oe+1],z=T.pending_buf[T.l_buf+oe],oe++,B===0?re(T,z,P):(re(T,(Z=k[z])+d+1,P),(ie=C[Z])!==0&&se(T,z-=F[Z],ie),re(T,Z=q(--B),Y),(ie=D[Z])!==0&&se(T,B-=O[Z],ie)),oe<T.last_lit;);re(T,S,P)}function j(T,P){var Y,B,z,Z=P.dyn_tree,ie=P.stat_desc.static_tree,oe=P.stat_desc.has_stree,me=P.stat_desc.elems,$e=-1;for(T.heap_len=0,T.heap_max=m,Y=0;Y<me;Y++)Z[2*Y]!==0?(T.heap[++T.heap_len]=$e=Y,T.depth[Y]=0):Z[2*Y+1]=0;for(;T.heap_len<2;)Z[2*(z=T.heap[++T.heap_len]=$e<2?++$e:0)]=1,T.depth[z]=0,T.opt_len--,oe&&(T.static_len-=ie[2*z+1]);for(P.max_code=$e,Y=T.heap_len>>1;1<=Y;Y--)Q(T,Z,Y);for(z=me;Y=T.heap[1],T.heap[1]=T.heap[T.heap_len--],Q(T,Z,1),B=T.heap[1],T.heap[--T.heap_max]=Y,T.heap[--T.heap_max]=B,Z[2*z]=Z[2*Y]+Z[2*B],T.depth[z]=(T.depth[Y]>=T.depth[B]?T.depth[Y]:T.depth[B])+1,Z[2*Y+1]=Z[2*B+1]=z,T.heap[1]=z++,Q(T,Z,1),2<=T.heap_len;);T.heap[--T.heap_max]=T.heap[1],(function(xe,De){var Ne,Fe,le,ue,Ye,ze,je=De.dyn_tree,ot=De.max_code,ii=De.stat_desc.static_tree,Ys=De.stat_desc.has_stree,Zs=De.stat_desc.extra_bits,es=De.stat_desc.extra_base,Ai=De.stat_desc.max_length,Ki=0;for(ue=0;ue<=y;ue++)xe.bl_count[ue]=0;for(je[2*xe.heap[xe.heap_max]+1]=0,Ne=xe.heap_max+1;Ne<m;Ne++)Ai<(ue=je[2*je[2*(Fe=xe.heap[Ne])+1]+1]+1)&&(ue=Ai,Ki++),je[2*Fe+1]=ue,ot<Fe||(xe.bl_count[ue]++,Ye=0,es<=Fe&&(Ye=Zs[Fe-es]),ze=je[2*Fe],xe.opt_len+=ze*(ue+Ye),Ys&&(xe.static_len+=ze*(ii[2*Fe+1]+Ye)));if(Ki!==0){do{for(ue=Ai-1;xe.bl_count[ue]===0;)ue--;xe.bl_count[ue]--,xe.bl_count[ue+1]+=2,xe.bl_count[Ai]--,Ki-=2}while(0<Ki);for(ue=Ai;ue!==0;ue--)for(Fe=xe.bl_count[ue];Fe!==0;)ot<(le=xe.heap[--Ne])||(je[2*le+1]!==ue&&(xe.opt_len+=(ue-je[2*le+1])*je[2*le],je[2*le+1]=ue),Fe--)}})(T,P),Ie(Z,$e,T.bl_count)}function v(T,P,Y){var B,z,Z=-1,ie=P[1],oe=0,me=7,$e=4;for(ie===0&&(me=138,$e=3),P[2*(Y+1)+1]=65535,B=0;B<=Y;B++)z=ie,ie=P[2*(B+1)+1],++oe<me&&z===ie||(oe<$e?T.bl_tree[2*z]+=oe:z!==0?(z!==Z&&T.bl_tree[2*z]++,T.bl_tree[2*x]++):oe<=10?T.bl_tree[2*M]++:T.bl_tree[2*E]++,Z=z,$e=(oe=0)===ie?(me=138,3):z===ie?(me=6,3):(me=7,4))}function U(T,P,Y){var B,z,Z=-1,ie=P[1],oe=0,me=7,$e=4;for(ie===0&&(me=138,$e=3),B=0;B<=Y;B++)if(z=ie,ie=P[2*(B+1)+1],!(++oe<me&&z===ie)){if(oe<$e)for(;re(T,z,T.bl_tree),--oe!=0;);else z!==0?(z!==Z&&(re(T,z,T.bl_tree),oe--),re(T,x,T.bl_tree),se(T,oe-3,2)):oe<=10?(re(T,M,T.bl_tree),se(T,oe-3,3)):(re(T,E,T.bl_tree),se(T,oe-11,7));Z=z,$e=(oe=0)===ie?(me=138,3):z===ie?(me=6,3):(me=7,4)}}l(O);var W=!1;function _(T,P,Y,B){se(T,(c<<1)+(B?1:0),3),(function(z,Z,ie,oe){pe(z),ce(z,ie),ce(z,~ie),o.arraySet(z.pending_buf,z.window,Z,ie,z.pending),z.pending+=ie})(T,P,Y)}s._tr_init=function(T){W||((function(){var P,Y,B,z,Z,ie=new Array(y+1);for(z=B=0;z<u-1;z++)for(F[z]=B,P=0;P<1<<C[z];P++)k[B++]=z;for(k[B-1]=z,z=Z=0;z<16;z++)for(O[z]=Z,P=0;P<1<<D[z];P++)V[Z++]=z;for(Z>>=7;z<p;z++)for(O[z]=Z<<7,P=0;P<1<<D[z]-7;P++)V[256+Z++]=z;for(Y=0;Y<=y;Y++)ie[Y]=0;for(P=0;P<=143;)K[2*P+1]=8,P++,ie[8]++;for(;P<=255;)K[2*P+1]=9,P++,ie[9]++;for(;P<=279;)K[2*P+1]=7,P++,ie[7]++;for(;P<=287;)K[2*P+1]=8,P++,ie[8]++;for(Ie(K,h+1,ie),P=0;P<p;P++)$[2*P+1]=5,$[2*P]=Se(P,5);H=new ne(K,C,d+1,h,y),I=new ne($,D,0,p,y),A=new ne(new Array(0),R,0,b,w)})(),W=!0),T.l_desc=new G(T.dyn_ltree,H),T.d_desc=new G(T.dyn_dtree,I),T.bl_desc=new G(T.bl_tree,A),T.bi_buf=0,T.bi_valid=0,_e(T)},s._tr_stored_block=_,s._tr_flush_block=function(T,P,Y,B){var z,Z,ie=0;0<T.level?(T.strm.data_type===2&&(T.strm.data_type=(function(oe){var me,$e=4093624447;for(me=0;me<=31;me++,$e>>>=1)if(1&$e&&oe.dyn_ltree[2*me]!==0)return a;if(oe.dyn_ltree[18]!==0||oe.dyn_ltree[20]!==0||oe.dyn_ltree[26]!==0)return r;for(me=32;me<d;me++)if(oe.dyn_ltree[2*me]!==0)return r;return a})(T)),j(T,T.l_desc),j(T,T.d_desc),ie=(function(oe){var me;for(v(oe,oe.dyn_ltree,oe.l_desc.max_code),v(oe,oe.dyn_dtree,oe.d_desc.max_code),j(oe,oe.bl_desc),me=b-1;3<=me&&oe.bl_tree[2*N[me]+1]===0;me--);return oe.opt_len+=3*(me+1)+5+5+4,me})(T),z=T.opt_len+3+7>>>3,(Z=T.static_len+3+7>>>3)<=z&&(z=Z)):z=Z=Y+5,Y+4<=z&&P!==-1?_(T,P,Y,B):T.strategy===4||Z===z?(se(T,2+(B?1:0),3),L(T,K,$)):(se(T,4+(B?1:0),3),(function(oe,me,$e,xe){var De;for(se(oe,me-257,5),se(oe,$e-1,5),se(oe,xe-4,4),De=0;De<xe;De++)se(oe,oe.bl_tree[2*N[De]+1],3);U(oe,oe.dyn_ltree,me-1),U(oe,oe.dyn_dtree,$e-1)})(T,T.l_desc.max_code+1,T.d_desc.max_code+1,ie+1),L(T,T.dyn_ltree,T.dyn_dtree)),_e(T),B&&pe(T)},s._tr_tally=function(T,P,Y){return T.pending_buf[T.d_buf+2*T.last_lit]=P>>>8&255,T.pending_buf[T.d_buf+2*T.last_lit+1]=255&P,T.pending_buf[T.l_buf+T.last_lit]=255&Y,T.last_lit++,P===0?T.dyn_ltree[2*Y]++:(T.matches++,P--,T.dyn_ltree[2*(k[Y]+d+1)]++,T.dyn_dtree[2*q(P)]++),T.last_lit===T.lit_bufsize-1},s._tr_align=function(T){se(T,2,3),re(T,S,K),(function(P){P.bi_valid===16?(ce(P,P.bi_buf),P.bi_buf=0,P.bi_valid=0):8<=P.bi_valid&&(P.pending_buf[P.pending++]=255&P.bi_buf,P.bi_buf>>=8,P.bi_valid-=8)})(T)}},{"../utils/common":41}],53:[function(i,n,s){n.exports=function(){this.input=null,this.next_in=0,this.avail_in=0,this.total_in=0,this.output=null,this.next_out=0,this.avail_out=0,this.total_out=0,this.msg="",this.state=null,this.data_type=2,this.adler=0}},{}],54:[function(i,n,s){(function(o){(function(a,r){if(!a.setImmediate){var l,c,u,d,h=1,p={},b=!1,m=a.document,y=Object.getPrototypeOf&&Object.getPrototypeOf(a);y=y&&y.setTimeout?y:a,l={}.toString.call(a.process)==="[object process]"?function(x){process.nextTick(function(){w(x)})}:(function(){if(a.postMessage&&!a.importScripts){var x=!0,M=a.onmessage;return a.onmessage=function(){x=!1},a.postMessage("","*"),a.onmessage=M,x}})()?(d="setImmediate$"+Math.random()+"$",a.addEventListener?a.addEventListener("message",S,!1):a.attachEvent("onmessage",S),function(x){a.postMessage(d+x,"*")}):a.MessageChannel?((u=new MessageChannel).port1.onmessage=function(x){w(x.data)},function(x){u.port2.postMessage(x)}):m&&"onreadystatechange"in m.createElement("script")?(c=m.documentElement,function(x){var M=m.createElement("script");M.onreadystatechange=function(){w(x),M.onreadystatechange=null,c.removeChild(M),M=null},c.appendChild(M)}):function(x){setTimeout(w,0,x)},y.setImmediate=function(x){typeof x!="function"&&(x=new Function(""+x));for(var M=new Array(arguments.length-1),E=0;E<M.length;E++)M[E]=arguments[E+1];var C={callback:x,args:M};return p[h]=C,l(h),h++},y.clearImmediate=g}function g(x){delete p[x]}function w(x){if(b)setTimeout(w,0,x);else{var M=p[x];if(M){b=!0;try{(function(E){var C=E.callback,D=E.args;switch(D.length){case 0:C();break;case 1:C(D[0]);break;case 2:C(D[0],D[1]);break;case 3:C(D[0],D[1],D[2]);break;default:C.apply(r,D)}})(M)}finally{g(x),b=!1}}}}function S(x){x.source===a&&typeof x.data=="string"&&x.data.indexOf(d)===0&&w(+x.data.slice(d.length))}})(typeof self>"u"?o===void 0?this:o:self)}).call(this,typeof cs<"u"?cs:typeof self<"u"?self:typeof window<"u"?window:{})},{}]},{},[10])(10)})})(ho)),ho.exports}var hg=pg();const Jl=fg(hg);function Xl(e){const t=(e||"").trim();return t?`即现（${t}）`:"即现"}async function Ql(e,t){var i,n,s;if(!t)return"";if(typeof document<"u"){const o=document.querySelector(`.protyle-title[data-node-id="${t}"] .protyle-title__input`)||document.querySelector(`.protyle[data-doc-id="${t}"] .protyle-title__input`)||(e.getActiveDocumentId()===t?document.querySelector(".layout__wnd--active .protyle-title__input"):null)||document.querySelector(".protyle-title__input"),a=((o==null?void 0:o.innerText)||(o==null?void 0:o.textContent)||"").trim();if(a)return a}if(e.latestCompiledDoc&&e.latestCompiledDoc.docId===t){const o=(i=e.latestCompiledDoc.slides)==null?void 0:i[0],a=(n=o==null?void 0:o.blocks)==null?void 0:n.find(r=>r.type==="h"||r.type==="NodeHeading");if(a!=null&&a.content)return a.content.trim()}try{const o=await dn(`SELECT content FROM blocks WHERE id = '${t}' AND type = 'd' LIMIT 1`).catch(()=>[]);if(Array.isArray(o)&&o.length>0&&((s=o[0])!=null&&s.content))return String(o[0].content).trim()}catch{}return""}async function mg(e,t,i){var c,u,d;const n=Fw(),s=!!((c=n==null?void 0:n.isPinned)!=null&&c.value),o=String(((u=n==null?void 0:n.pinnedDocId)==null?void 0:u.value)||"");if(s&&o&&i&&i!==o)return;const a=i||(s&&o?o:e.currentDocId||e.getActiveDocumentId());let r=(t||"").trim();!r&&a&&(r=typeof e.fetchDocumentTitle=="function"?await e.fetchDocumentTitle(a):await Ql(e,a));const l=Xl(r);if(e.previewTab&&typeof e.previewTab.updateTitle=="function"){e.previewTab.updateTitle(l),e.previewTab.headElement&&e.previewTab.headElement.setAttribute("title",l);return}if(typeof document<"u"){const h=Array.from(document.querySelectorAll('.layout-tab-bar .item[data-type="tab-header"]'));for(const p of h){const b=p.querySelector(".item__text"),m=((d=b==null?void 0:b.textContent)==null?void 0:d.trim())||"";if(m.includes("Slidev 演示预览")||m.startsWith("即现")){b&&(b.textContent=l),p.setAttribute("title",l);break}}}}function In(e){return(e||"").replace(/[/\\?%*:|"<>]/g,"_").replace(/_+/g,"_").trim().replace(/^_+|_+$/g,"")||"presentation"}async function Mi(e,t,i){var s,o;const n=t||(e==null?void 0:e.docId)||"";if(i&&typeof i.fetchDocumentTitle=="function"&&n)try{const a=await i.fetchDocumentTitle(n);if(a&&a.trim())return In(a)}catch{}if(typeof document<"u")try{const a=(n?document.querySelector(`.protyle-title[data-node-id="${n}"] .protyle-title__input`):null)||(n?document.querySelector(`.protyle[data-doc-id="${n}"] .protyle-title__input`):null)||document.querySelector(".layout__wnd--active .protyle-title__input")||document.querySelector(".protyle-title__input"),r=((a==null?void 0:a.innerText)||(a==null?void 0:a.textContent)||"").trim();if(r)return In(r)}catch{}if((s=e==null?void 0:e.config)!=null&&s.title&&e.config.title.trim()&&e.config.title.trim().toLowerCase()!=="presentation")return In(e.config.title);if(e!=null&&e.slides&&e.slides.length>0){const r=(o=e.slides[0].blocks)==null?void 0:o.find(c=>c.type==="h"||c.type==="NodeHeading"),l=((r==null?void 0:r.content)||"").replace(/^#+\s*/,"").trim();if(l)return In(l)}return"presentation"}function gg(e,t){if(typeof document>"u")return!1;const i=URL.createObjectURL(t),n=document.createElement("a");return n.href=i,n.download=e,document.body.appendChild(n),n.click(),document.body.removeChild(n),URL.revokeObjectURL(i),!0}function da(e,t){if(typeof document>"u")return!1;const i=document.createElement("a");return i.href=t,i.download=e,document.body.appendChild(i),i.click(),document.body.removeChild(i),!0}async function vg(e){if(typeof navigator>"u"||!navigator.clipboard||typeof ClipboardItem>"u")return!1;try{const i=await(await fetch(e)).blob();return await navigator.clipboard.write([new ClipboardItem({[i.type||"image/png"]:i})]),!0}catch(t){return console.warn("[image-exporter] 复制图像至剪贴板失败:",t),!1}}async function zo(e,t){return new Promise(i=>{let n=[],s=null;const o=()=>{s&&(clearTimeout(s),s=null),n.forEach(l=>l()),n=[]};s=setTimeout(()=>{o(),i({success:!1,error:"单页截图超时（沙箱无响应）"})},2e4);const a=e.onCapturePageDone(l=>{o(),i({success:!0,dataUrl:l.dataUrl})});n.push(a);const r=e.onCaptureError(l=>{o(),i({success:!1,error:l})});n.push(r),e.startImageExport({mode:"current",scale:(t==null?void 0:t.scale)||2,format:(t==null?void 0:t.format)||"png"})})}async function ec(e,t){const i=[],n=In((t==null?void 0:t.title)||"presentation");return new Promise(s=>{let o=[],a=null;const r=()=>{a&&(clearTimeout(a),a=null),o.forEach(p=>p()),o=[]},l=()=>{a&&clearTimeout(a),a=setTimeout(()=>{r(),s({success:!1,error:"幻灯片逐页导出超时（沙箱无响应）"})},35e3)};l();const c=e.onCaptureProgress(p=>{var b;l(),(b=t==null?void 0:t.onProgress)==null||b.call(t,p.current,p.total,p.pageIndex)});o.push(c);const u=e.onCapturePageDone(p=>{l(),(p.mode==="all"||!p.mode)&&i.push({pageIndex:p.pageIndex,dataUrl:p.dataUrl})});o.push(u);const d=async()=>{r();try{if(i.length===0){s({success:!1,error:"未采集到幻灯片图像数据"});return}const p=new Jl,b=(t==null?void 0:t.format)==="jpeg"?"jpg":"png";for(const g of i){const w=String(g.pageIndex).padStart(2,"0"),S=g.dataUrl.split(",")[1];p.file(`slide-${w}.${b}`,S,{base64:!0})}const m=await p.generateAsync({type:"blob",compression:"DEFLATE"}),y=gg(`${n}.zip`,m);s({success:y,total:i.length})}catch(p){s({success:!1,error:(p==null?void 0:p.message)||String(p)})}};o.push(e.onCaptureComplete(d));const h=e.onCaptureError(p=>{r(),s({success:!1,error:p})});o.push(h),e.startImageExport({mode:"all",scale:(t==null?void 0:t.scale)||2,format:(t==null?void 0:t.format)||"png"})})}async function tc(e,t){if(typeof document>"u")return{success:!1,error:"环境不支持 DOM 沙箱挂载"};const i=document.createElement("iframe");i.style.position="fixed",i.style.left="-9999px",i.style.top="-9999px",i.style.width="1920px",i.style.height="1080px",i.style.opacity="0",i.style.pointerEvents="none",i.src="/plugins/siyuan-live-slides/slides-client/index.html?headless=true",document.body.appendChild(i);const n=new Qn;n.attach(i);try{if(await new Promise((s,o)=>{const a=setTimeout(()=>o(new Error("静默后台沙箱加载超时")),12e3);n.onClientReady(()=>{clearTimeout(a),s()})}),n.updateSlides(e.slides,e.config,e.fullMarkdown),await new Promise(s=>setTimeout(s,250)),(t==null?void 0:t.mode)==="current"){const s=await zo(n,t);return{success:s.success,total:1,error:s.error}}else{const s=(t==null?void 0:t.title)||await Mi(e,e.docId);return await ec(n,{...t,title:s})}}catch(s){return{success:!1,error:(s==null?void 0:s.message)||String(s)}}finally{n.detach(),i.remove()}}const bg=1500,yg=500,kg=4,wg=new Set(["INPUT","TEXTAREA","SELECT"]);function ic(e){const t=e;return!t||!t.tagName?!1:wg.has(t.tagName)||t.isContentEditable===!0}function xg(e){let t="",i=!1,n=null,s=null;function o(){e.onStateChange&&e.onStateChange({display:t,invalid:i})}function a(){n&&(clearTimeout(n),n=null),s&&(clearTimeout(s),s=null)}function r(){a(),t="",i=!1,o()}function l(){n&&clearTimeout(n),n=setTimeout(r,bg)}function c(){n&&(clearTimeout(n),n=null),i=!0,o(),s&&clearTimeout(s),s=setTimeout(r,yg)}function u(d){if(e.isEnabled&&!e.isEnabled()||ic(d.target)||d.isComposing||d.ctrlKey||d.metaKey||d.altKey)return!1;if(/^[0-9]$/.test(d.key))return i||t.length>=kg||(t+=d.key,o(),l()),!0;if(d.key==="Enter"){if(!t||i)return!1;const p=parseInt(t,10),b=e.getTotalPages();return!isNaN(p)&&p>=1&&b>0&&p<=b?(r(),e.onJump(p),!0):(c(),!0)}return d.key==="Escape"&&(t||i)?(r(),!0):!1}return{handleKeydown:u,getState:()=>({display:t,invalid:i}),clear:r}}const Sg={class:"spm-slides-tab__toolbar"},Cg={class:"spm-slides-tab__nav"},_g=["disabled"],$g={class:"spm-page-badge"},Ig=["disabled"],Mg=["aria-label"],Tg=["aria-label"],Eg={class:"spm-slides-tab__tools"},Ag={key:3,class:"spm-export-image-dropdown",style:{position:"relative",display:"inline-flex","align-items":"center"}},Bg={key:0,class:"b3-menu b3-menu--context",style:{position:"absolute",top:"calc(100% + 4px)",right:"0","z-index":"100","min-width":"190px","box-shadow":"var(--b3-point-shadow)","border-radius":"4px",background:"var(--b3-theme-surface)"}},Dg=["src"],Lg=Bt({__name:"SlidesPreviewTab",setup(e,{expose:t}){const i=Nt("plugin"),n=Nt("sandboxBridge",new Qn),s=new jm(n),o=new Cp,a=ge("web-sandbox"),r=ge(3030),l=ge(null),c=ge(!1),u=ge(null),d=ge(1),h=ge(1),p=ge(!1),b=ge(!1),m=ge(!1),y=ge("siyuan"),g=ge(""),w=ge(""),S=ge(""),x=ge(!1),M=ge(!1),E=ge(""),C=ge(""),D=ge(!1),R=xg({getTotalPages:()=>h.value,isEnabled:()=>!b.value,onJump:B=>$(B),onStateChange:B=>{C.value=B.display,D.value=B.invalid}});function N(B){if(B.key==="o"||B.key==="O"){if(b.value||B.isComposing||B.ctrlKey||B.metaKey||B.altKey||ic(B.target))return;B.preventDefault(),K();return}R.handleKeydown(B)&&B.preventDefault()}function K(){var B,z;if(a.value==="pro-cli"){(B=u.value)==null||B.focus(),de.showMessage("Pro 模式使用官方原生总览：在画面内按 O 呼出");return}n.toggleOverview(),(z=u.value)==null||z.focus()}function $(B){var z;d.value=B,a.value==="pro-cli"?o.nativeBridge.navigateToPage(B):n.navigatePage(B),(z=u.value)==null||z.focus()}const V=ge("/plugins/siyuan-live-slides/slides-client/index.html");let k=null,F=null,H=null,I=null,A=null,O=null,ne=null,G=null;vn(()=>{u.value&&(n.attach(u.value),o.nativeBridge.attach(u.value)),k=n.onSlideChanged((B,z)=>{d.value=B,h.value=z}),F=n.onBlockClicked((B,z)=>{d.value=z,s.setActiveBlockId(B),B||Rn(),i&&typeof i.handleBlockClickedFromSlide=="function"?i.handleBlockClickedFromSlide(B,z):B&&Vi(B,i==null?void 0:i.app)}),H=n.onOpenInEditor((B,z)=>{d.value=z,s.setActiveBlockId(B),Vi(B,i==null?void 0:i.app)}),I=o.nativeBridge.onPageChanged((B,z)=>{d.value=B,h.value=z}),A=n.onOpenPeekDrawer(async B=>{const z=qs();if(B.peekType==="siyuan"&&z.enableWebServeJump){let Z=!1;if(G&&G.docId===B.target)Z=!0;else if(G&&G.slides&&G.slides.some(ie=>{var oe;return(oe=ie.blocks)==null?void 0:oe.some(me=>me.id===B.target)}))Z=!1;else try{const ie=await dn(`SELECT id, root_id, type FROM blocks WHERE id = '${B.target}' LIMIT 1`);ie&&ie.length>0&&(Z=ie[0].type==="d"||ie[0].id===ie[0].root_id)}catch(ie){console.warn("[SlidesPreviewTab] detect block type failed:",ie)}y.value="web",x.value=!0,w.value=Dl(z.webServeUrl,B.target,{focus:!Z}),S.value=B.title||`${Z?"思源文档":"思源块"}: ${B.target.slice(0,8)}`,b.value=!0,n.freezeKeyboardNav(!0)}else{if(y.value=B.peekType,B.peekType==="siyuan")g.value=B.target,S.value=B.title||`块速览: ${B.target.slice(0,8)}`;else{const Z=Wl(B.target);if(Z.external){Q(B.target);return}x.value=!0,w.value=Z.url,S.value=B.title||Z.url}b.value=!0,n.freezeKeyboardNav(!0)}}),O=n.onRequestToggleFullscreen(()=>{j()}),ne=n.onOpenPresenter(()=>{v()}),typeof document<"u"&&document.addEventListener("fullscreenchange",L)}),Us(()=>{typeof document<"u"&&document.removeEventListener("fullscreenchange",L),A&&A(),O&&O(),ne&&ne(),k&&k(),F&&F(),H&&H(),I&&I(),n.detach(),R.clear(),s.destroy(),o.destroy()});async function q(){if(a.value==="web-sandbox"){if(!G){de.showMessage("请先在主编辑区打开演示文档");return}de.showMessage("正在探测本地 Node 环境并编排 Slidev Pro 进程...");const B=await o.startProMode(G,ko);if(!B.success){de.showMessage(`无法启动官方 Pro 模式：${B.error}`);return}a.value="pro-cli",r.value=B.port||3030,V.value=B.url,u.value&&o.nativeBridge.attach(u.value),de.showMessage(`🟢 已成功接入官方原生 Slidev 服务 (端口: ${r.value})`)}else o.stopProMode(),a.value="web-sandbox",V.value="/plugins/siyuan-live-slides/slides-client/index.html",u.value&&n.attach(u.value),de.showMessage("已切回内置高保真沙箱")}function ce(){M.value=!M.value,M.value?(E.value=(G==null?void 0:G.docId)||"",i&&typeof i.updatePreviewTabHeader=="function"&&i.updatePreviewTabHeader("",E.value)):(E.value="",_e(),i&&typeof i.updatePreviewTabHeader=="function"&&i.updatePreviewTabHeader())}let se=0;function re(B){if(b.value||Math.abs(B.deltaY)<Math.abs(B.deltaX)||Math.abs(B.deltaY)<15)return;const z=Date.now();z-se<280||(se=z,B.deltaY>0?Ie():Se())}function Se(){if(d.value>1){const B=d.value-1;d.value=B,a.value==="pro-cli"?o.nativeBridge.navigateToPage(B):n.navigatePage(B)}}function Ie(){if(d.value<h.value){const B=d.value+1;d.value=B,a.value==="pro-cli"?o.nativeBridge.navigateToPage(B):n.navigatePage(B)}}function _e(){i&&typeof i.compileCurrentDocument=="function"?i.compileCurrentDocument():i!=null&&i.eventBus&&typeof i.eventBus.emit=="function"&&i.eventBus.emit("slides:request-compile")}function pe(){b.value=!1,n.freezeKeyboardNav(!1)}function X(){pe()}function Q(B){var oe,me;const z=/^file:/i.test(B),Z=z||/^[a-zA-Z]:[\\/]/.test(B),ie=Mt("electron");if(Z&&typeof((oe=ie==null?void 0:ie.shell)==null?void 0:oe.openPath)=="function"){ie.shell.openPath(z?jl(B):B),de.showMessage("本地文件不在思源工作区内，已交由系统默认浏览器打开");return}typeof((me=ie==null?void 0:ie.shell)==null?void 0:me.openExternal)=="function"?ie.shell.openExternal(B).catch(()=>{typeof window<"u"&&window.open(B,"_blank")}):typeof window<"u"&&window.open(B,"_blank"),de.showMessage("该地址无法在速览抽屉内加载，已交由系统默认浏览器打开")}function L(){typeof document<"u"&&(c.value=!!document.fullscreenElement,n.postMessage("FULLSCREEN_CHANGED",{isFullscreen:c.value}))}function j(){const B=l.value||u.value;B&&(document.fullscreenElement?document.exitFullscreen().then(()=>{n.postMessage("FULLSCREEN_CHANGED",{isFullscreen:!1})}).catch(()=>{}):B.requestFullscreen().then(()=>{n.postMessage("FULLSCREEN_CHANGED",{isFullscreen:!0})}).catch(()=>{}))}function v(){i&&typeof i.openPresenterTab=="function"&&i.openPresenterTab()}async function U(){if(!G){de.showMessage("请先在主编辑区打开幻灯片文档");return}const B=await Mi(G,i==null?void 0:i.currentDocId,i),z=ql(G,{title:B});Yl(`${B}.html`,z)&&de.showMessage(`已开始下载单文件离线 HTML 演示包 (${B}.html)`)}function W(){if(!G){de.showMessage("请先在主编辑区打开幻灯片文档");return}Zl(G)&&de.showMessage("已唤起打印视窗，请在打印选项中选择「另存为 PDF」")}const _=ge(!1);async function T(){if(_.value){de.showMessage("正在逐页导出幻灯片图片中，请稍候...",2e3);return}if(!G){de.showMessage("请先在主编辑区打开幻灯片文档");return}_.value=!0;try{de.showMessage("正在逐页导出幻灯片图片...",2e3);const B=await Mi(G,i==null?void 0:i.currentDocId,i),z=await ec(n,{title:B,onProgress:(Z,ie)=>{de.showMessage(`正在导出幻灯片图片 (${Z} / ${ie})...`,1500)}});z.success?de.showMessage(`🎉 成功导出 ${z.total||0} 张高清图片并保存为 ${B}.zip！`,4e3):de.showMessage(`导出图片失败：${z.error||"未知异常"}`)}finally{_.value=!1}}async function P(){if(!G){de.showMessage("请先在主编辑区打开幻灯片文档");return}de.showMessage("正在导出当前幻灯片图片...",1500);const B=await zo(n);if(B.success&&B.dataUrl){const z=await Mi(G,i==null?void 0:i.currentDocId,i),Z=d.value||1,oe=(h.value||1)>1?`${z}-${Z}.png`:`${z}.png`;da(oe,B.dataUrl),de.showMessage(`已下载当前页高清图片 (${oe})`)}else de.showMessage(`导出当前页图片失败：${B.error||"未知异常"}`)}async function Y(){if(!G){de.showMessage("请先在主编辑区打开幻灯片文档");return}de.showMessage("正在复制当前幻灯片截图到剪贴板...",1500);const B=await zo(n);if(B.success&&B.dataUrl)if(await vg(B.dataUrl))de.showMessage(`已成功将第 ${d.value||1} 页幻灯片复制到剪贴板！`);else{const Z=await Mi(G,i==null?void 0:i.currentDocId,i),ie=d.value||1,me=(h.value||1)>1?`${Z}-${ie}.png`:`${Z}.png`;da(me,B.dataUrl),de.showMessage(`剪贴板权限不可用，已自动下载为 ${me}`)}else de.showMessage(`复制失败：${B.error||"未知异常"}`)}return t({updateDocument(B,z){M.value&&E.value&&z&&z!==E.value||(G=B,M.value&&!E.value&&(E.value=B.docId),h.value=B.slides.length,s.setDocId(B.docId),s.updateSlidesIndex(B.slides),a.value==="pro-cli"?o.scaffolder.scaffold(B,ko).catch(()=>{}):n.updateSlides(B.slides,B.config,B.fullMarkdown,B.customThemeCss),i&&typeof i.updatePreviewTabHeader=="function"&&i.updatePreviewTabHeader("",B.docId))},navigateToBlock(B){s.onCursorFocusBlock(B)},isPinned:M,pinnedDocId:E,engineMode:a,toggleEngineMode:q}),(B,z)=>(J(),te("div",{class:"spm-slides-preview-tab",onKeydown:N},[f("div",Sg,[f("div",Cg,[f("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s",disabled:d.value<=1,"aria-label":"上一页",onClick:Se},[ae(fe,{name:"chevron-left"})],8,_g),f("span",$g,we(d.value)+" / "+we(h.value||1),1),f("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s",disabled:d.value>=h.value,"aria-label":"下一页",onClick:Ie},[ae(fe,{name:"chevron-right"})],8,Ig),f("button",{class:Ce(["spm-icon-btn b3-tooltips b3-tooltips__s",{"is-primary":M.value}]),"aria-label":M.value?"已锁定当前文档（点击解除）："+E.value:"点击锁定当前文档（不随主编辑区切换）",onClick:ce},[ae(fe,{name:"pin"}),f("span",null,we(M.value?"已锁定":"跟随"),1)],10,Mg),he($t)("proMode")?(J(),te("button",{key:0,class:Ce(["spm-icon-btn b3-tooltips b3-tooltips__s",{"is-primary":a.value==="pro-cli"}]),"aria-label":a.value==="pro-cli"?"当前：官方原生 Pro 模式 (localhost:"+r.value+")，点击切回沙箱":"当前：内置高保真沙箱，点击切换官方原生 Pro 模式",onClick:q},[ae(fe,{name:"rocket"}),f("span",null,we(a.value==="pro-cli"?"Pro ("+r.value+")":"沙箱"),1)],10,Tg)):Te("",!0)]),f("div",Eg,[f("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"缩略图总览 (O)",onClick:K},[ae(fe,{name:"columns"})]),he($t)("presenterMode")?(J(),te("button",{key:0,class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"双屏演讲者视图 (Presenter Mode ⌥M)",onClick:v},[ae(fe,{name:"presenter"})])):Te("",!0),he($t)("exportHtml")?(J(),te("button",{key:1,class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"导出单文件 HTML 演示包",onClick:U},[ae(fe,{name:"export-html"})])):Te("",!0),he($t)("exportPdf")?(J(),te("button",{key:2,class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"导出 16:9 PDF 演示讲义",onClick:W},[ae(fe,{name:"export-pdf"})])):Te("",!0),he($t)("exportImage")?(J(),te("div",Ag,[f("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"导出幻灯片为图片包 (ZIP)",onClick:T},[ae(fe,{name:"export-image"})]),f("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s",style:{padding:"2px 2px","margin-left":"-4px"},"aria-label":"更多图片导出选项",onClick:z[0]||(z[0]=Yt(Z=>p.value=!p.value,["stop"]))},[ae(fe,{name:"chevron-down"})]),p.value?(J(),te("div",Bg,[f("button",{class:"b3-menu__item",onClick:z[1]||(z[1]=Z=>{T(),p.value=!1})},[...z[6]||(z[6]=[f("span",{class:"b3-menu__label"},"📦 导出全篇为图片包 (ZIP)",-1)])]),f("button",{class:"b3-menu__item",onClick:z[2]||(z[2]=Z=>{P(),p.value=!1})},[...z[7]||(z[7]=[f("span",{class:"b3-menu__label"},"🖼️ 导出当前页为图片 (PNG)",-1)])]),f("button",{class:"b3-menu__item",onClick:z[3]||(z[3]=Z=>{Y(),p.value=!1})},[...z[8]||(z[8]=[f("span",{class:"b3-menu__label"},"📋 复制当前页至剪贴板",-1)])])])):Te("",!0)])):Te("",!0),f("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"重新编译并刷新",onClick:_e},[ae(fe,{name:"refresh"})]),f("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"全屏放映",onClick:j},[ae(fe,{name:"fullscreen"})])])]),f("div",{ref_key:"fullscreenContainerRef",ref:l,class:"spm-slides-tab__viewport spm-slides-fullscreen-container",onWheel:re},[f("iframe",{ref_key:"sandboxIframeRef",ref:u,class:"spm-slides-tab__iframe",src:V.value,frameborder:"0",allow:"fullscreen; autoplay"},null,8,Dg),ae(em,{visible:b.value,"onUpdate:visible":z[4]||(z[4]=Z=>b.value=Z),"is-maximized":m.value,"onUpdate:isMaximized":z[5]||(z[5]=Z=>m.value=Z),title:S.value,onClose:pe},{default:il(()=>[y.value==="siyuan"&&g.value?(J(),Zt(cm,{key:0,"block-id":g.value,title:S.value,plugin:he(i),onExternalJump:X},null,8,["block-id","title","plugin"])):Te("",!0),x.value?Pt((J(),Zt(Hm,{key:1,visible:b.value&&y.value==="web",url:w.value,title:S.value,onExternalJump:X},null,8,["visible","url","title"])),[[Do,y.value==="web"]]):Te("",!0)]),_:1},8,["visible","is-maximized","title"]),Pt(f("div",{class:Ce(["spm-jump-badge",{"is-invalid":D.value}])},we(C.value),3),[[Do,C.value]])],544)],32))}}),Pg=ti(Lg,[["__scopeId","data-v-2bf44815"]]);function nc(e){if(!e||e.length===0)return{maxStep:0,blockMap:new Map,idMap:new Map};const t=new Map,i=new Map,n=new Map;let s=0;const o=(r,l)=>{t.set(r,l);const c=r.id||r.blockId;c&&i.set(c,l)},a=e.filter(r=>r.slot!=="slot-divider-right");for(const r of a){if(r.parentContainerId&&r.parentClicks&&r.parentClicks.trim()!==""&&!n.has(r.parentContainerId)){const d=String(r.parentClicks).trim();if(/^\d+$/.test(d)){const h=parseInt(d,10);s=Math.max(s,h),n.set(r.parentContainerId,h)}else s+=1,n.set(r.parentContainerId,s)}if(!!!(r.clicks&&String(r.clicks).trim()!=="")){if(r.parentContainerId&&n.has(r.parentContainerId)){const d=n.get(r.parentContainerId);o(r,{type:"step",step:d})}else o(r,{type:"always"});continue}const c=String(r.clicks).trim();if(!c){s+=1,o(r,{type:"step",step:s});continue}if(c.startsWith("[")&&c.endsWith("]"))try{const d=JSON.parse(c);if(Array.isArray(d)&&d.length>=2){const h=Math.min(Number(d[0]),Number(d[1])),p=Math.max(Number(d[0]),Number(d[1]));if(!isNaN(h)&&!isNaN(p)){s=Math.max(s,p),o(r,{type:"range",min:h,max:p});continue}}}catch{}if(c.toLowerCase()==="hide"){s+=1,o(r,{type:"hide",step:s});continue}if(/^\+\d+$/.test(c)||c==="true"){const d=c==="true"?1:parseInt(c.slice(1),10)||1;s+=d,o(r,{type:"step",step:s});continue}if(/^-\d+$/.test(c)){const d=parseInt(c.slice(1),10)||1;s=Math.max(1,s-d),o(r,{type:"step",step:s});continue}if(/^\d+$/.test(c)){const d=parseInt(c,10);if(!isNaN(d)){s=Math.max(s,d),o(r,{type:"step",step:d});continue}}const u=parseInt(c,10);!isNaN(u)&&u>0?(s=Math.max(s,u),o(r,{type:"step",step:u})):(s+=1,o(r,{type:"step",step:s}))}return{maxStep:s,blockMap:t,idMap:i}}function Og(e,t,i){if(!e)return"v-click-visible";const n=e.id||e.blockId,s=i.blockMap.get(e)||(n?i.idMap.get(n):null);return!s||s.type==="always"?"v-click-visible":s.type==="range"?t>=s.min&&t<=s.max?"v-click-visible":"v-click-hidden":s.type==="hide"?t<s.step?"v-click-visible":"v-click-hidden":s.type==="step"?t>=s.step?"v-click-visible":"v-click-hidden":"v-click-visible"}const Ho=980;function Rg(e){if(!e)return 0;const i=nc(e.blocks||[]).maxStep||0,n=e.frontmatter||{},s=n.mask;if(s!=="down"&&s!=="right")return i;const o=md(n.maskRatio),r=n.maskInitial==="revealed"?Math.max(0,o.steps-1):o.steps;return Math.max(i,r)}function Ng(e,t=Ho){const i=(e||"16/9").trim();let n=16/9;if(i==="4/3"||i==="4:3")n=4/3;else if(i==="16/10"||i==="16:10")n=16/10;else if(i.includes("/")||i.includes(":")){const o=i.includes("/")?"/":":",a=i.split(o).map(r=>parseFloat(r.trim()));a.length===2&&a[0]>0&&a[1]>0&&!isNaN(a[0])&&!isNaN(a[1])&&(n=a[0]/a[1])}else{const o=parseFloat(i);!isNaN(o)&&o>.2&&o<5&&(n=o)}const s=Math.ceil(t/n);return{baseWidth:t,baseHeight:s,ratio:n}}function ua(e,t,i=Ho,n=552,s=16){const o=i>0?i:Ho,a=n>0?n:552,r=Math.max(0,e-s),l=Math.max(0,t-s);if(r<=0||l<=0)return{scale:.36,boxWidth:Math.round(o*.36),boxHeight:Math.round(a*.36)};const c=Math.min(r/o,l/a),u=Math.max(.08,Math.min(1.5,Number(c.toFixed(4))));return{scale:u,boxWidth:Math.max(1,Math.round(o*u)),boxHeight:Math.max(1,Math.round(a*u))}}function zg(e){return{...e,frontmatter:{...e.frontmatter||{}},blocks:Array.isArray(e.blocks)?e.blocks.map(t=>({...t,attrs:t.attrs?{...t.attrs}:void 0,attributes:t.attributes?{...t.attributes}:void 0,motion:t.motion?{...t.motion}:void 0,children:Array.isArray(t.children)?t.children.map(i=>({...i,attrs:i.attrs?{...i.attrs}:void 0,attributes:i.attributes?{...i.attributes}:void 0})):void 0})):[]}}function fa(e,t){if(!e)return"";const i=zg(e),n=i.frontmatter||{},s=n.layout||"default",o=(t==null?void 0:t.config)||{};(s==="image-right"||s==="image-left")&&!n.image&&!n.background&&o.image&&(n.image=o.image);const a=typeof(t==null?void 0:t.currentStep)=="number",r=a?Math.max(0,t.currentStep):0,l=a?nc(i.blocks||[]):null,u=Kl(i,{containerClassName:"slide-block",leftColClass:"pdf-col pdf-col--left two-cols-left",rightColClass:"pdf-col pdf-col--right two-cols-right",allSlides:(t==null?void 0:t.allSlides)||[],currentPageIndex:(t==null?void 0:t.pageIndex)||i.pageIndex||1,highlight:!0,blockClassResolver:l?S=>{if(Og(S,r,l)==="v-click-hidden")return"presenter-v-click-pending";if(r>0){const M=S.id||S.blockId,E=l.blockMap.get(S)||(M?l.idMap.get(M):void 0);if((E==null?void 0:E.type)==="step"&&E.step===r||(E==null?void 0:E.type)==="range"&&E.min===r)return"presenter-v-click-active"}return""}:void 0}).replace(/<video\b([^>]*)>/gi,(S,x)=>{let M=x.replace(/\bcontrols\b/gi,"").trim();return/\bmuted\b/i.test(M)||(M+=" muted"),`<video ${M.trim()}>`}),d=n.spacing,h=d&&d!=="inherit"?d:o.spacing||"normal",p=["slide-content",`layout-${s}`,`spacing-${h}`,n.class||"",n.layoutClass||""].filter(Boolean).join(" "),b=[],m=(n.background||"").trim();if(m)if(/^(?:https?:\/\/|\/|data:|assets\/|\.\/assets\/)/i.test(m)){const S=m.startsWith("assets/")?`/${m}`:m.startsWith("./assets/")?m.slice(1):m;b.push(`background-image:url('${rt(S)}');background-size:cover;background-position:center;background-repeat:no-repeat;`)}else b.push(`background:${rt(m)};`);const y=typeof n.zoom=="number"?n.zoom:typeof n.zoom=="string"?parseFloat(n.zoom):1,g=!isNaN(y)&&y>0?y:1;g!==1&&b.push(`width:${(100/g).toFixed(2)}%;height:${(100/g).toFixed(2)}%;transform-origin:top left;transform:scale(${g});`);const w=b.length>0?` style="${b.join("")}"`:"";return`<div class="${rt(p)}"${w}>${u}</div>`}const Hg={class:"presenter-header"},Fg={class:"presenter-title-area"},jg={class:"presenter-brand"},Wg={class:"header-pills"},Ug={class:"pill pill-page"},Vg={key:0,class:"pill pill-step"},Gg={class:"header-toolbar"},Kg={class:"timer-capsule"},qg={class:"timer-digits"},Yg={class:"timer-actions"},Zg=["aria-label"],Jg={class:"wall-clock b3-tooltips b3-tooltips__sw","aria-label":"系统当前时间"},Xg={key:0,class:"presenter-grid"},Qg={class:"slide-panels"},ev={class:"panel-box current-slide-panel"},tv={class:"panel-header"},iv={class:"panel-header-left"},nv={class:"panel-page-num"},sv={class:"panel-header-meta"},ov={key:0,class:"panel-step-pill"},rv={class:"panel-layout-pill"},av=["aria-label"],lv=["data-theme","data-slides-theme","data-normalize-headings","data-hide-unordered-markers","data-hide-ordered-markers","innerHTML"],cv={key:1,class:"panel-fallback"},dv=["aria-label"],uv={class:"panel-header"},fv={class:"panel-header-left"},pv={key:0,class:"panel-page-num"},hv={class:"panel-header-meta"},mv={key:0,class:"panel-end-pill"},gv={key:1,class:"panel-layout-pill"},vv=["aria-label"],bv=["data-theme","data-slides-theme","data-normalize-headings","data-hide-unordered-markers","data-hide-ordered-markers","innerHTML"],yv={key:1,class:"panel-fallback"},kv={class:"notes-panel"},wv={class:"panel-header"},xv={class:"panel-header-left"},Sv={class:"notes-size-controls"},Cv=["disabled"],_v={class:"notes-size-value"},$v=["disabled"],Iv={key:1,class:"presenter-empty"},Mv={class:"empty-icon-wrap"},Tv={class:"empty-actions"},Ev={class:"presenter-actions"},Av={class:"nav-btn-group"},Bv=["disabled"],Dv=["disabled"],Lv={class:"actions-center"},Pv={class:"center-meta"},Ov={class:"progress-pill"},Rv={class:"nav-btn-group"},Nv=["aria-label"],zv={class:"step-dots-text"},Hv=["disabled"],Fv=["disabled"],jv=280,Wv=15,Uv=Bt({__name:"SlidesPresenterTab",setup(e,{expose:t}){const i=Nt("plugin"),n=Nt("sandboxBridge",new Qn),s=ge([]),o=ge({}),a=ge(1),r=ge(0),l=ge(0),c=ge(0),u=ye(()=>s.value.length||l.value),d=ge(null),h=ge(null),p=ge({width:0,height:0}),b=ge({width:0,height:0}),m=ye(()=>{var le;return Ng((le=o.value)==null?void 0:le.aspectRatio)}),y=ye(()=>{var le;return((le=o.value)==null?void 0:le.theme)||"default"}),g=ye(()=>{var le;return((le=o.value)==null?void 0:le.colorSchema)==="light"?"light":"dark"}),w=ye(()=>{var le;return!!((le=o.value)!=null&&le.normalizeHeadingSizes)}),S=ye(()=>{var le;return((le=o.value)==null?void 0:le.showUnorderedListMarkers)===!1}),x=ye(()=>{var le;return((le=o.value)==null?void 0:le.showOrderedListMarkers)===!1}),M=ye(()=>ua(p.value.width,p.value.height,m.value.baseWidth,m.value.baseHeight,14)),E=ye(()=>ua(b.value.width,b.value.height,m.value.baseWidth,m.value.baseHeight,14));function C(){d.value&&(p.value={width:d.value.clientWidth,height:d.value.clientHeight}),h.value&&(b.value={width:h.value.clientWidth,height:h.value.clientHeight})}let D=null;function R(){typeof window>"u"||typeof window.ResizeObserver!="function"||(D||(D=new window.ResizeObserver(()=>{C()})),D.disconnect(),d.value&&D.observe(d.value),h.value&&D.observe(h.value))}Ui([d,h,u],()=>{Is(()=>{R(),C()})},{flush:"post"});const N=ge(0),K=ge(!0);let $=null,V=Date.now(),k=0;const F=ye(()=>{const le=String(Math.floor(N.value/60)).padStart(2,"0"),ue=String(N.value%60).padStart(2,"0");return`${le}:${ue}`});function H(){if(K.value){const le=k+(Date.now()-V);N.value=Math.floor(le/1e3)}}function I(){K.value?(k+=Date.now()-V,K.value=!1):(V=Date.now(),K.value=!0,H())}function A(){V=Date.now(),k=0,N.value=0}const O=ge("");let ne=null;function G(){const le=new Date,ue=String(le.getHours()).padStart(2,"0"),Ye=String(le.getMinutes()).padStart(2,"0");O.value=`${ue}:${Ye}`}const q=ye(()=>s.value.length===0?null:s.value[a.value-1]||null),ce=ye(()=>a.value>=s.value.length?null:s.value[a.value]||null),se=ye(()=>q.value?Rg(q.value):c.value),re=ye(()=>a.value>1||r.value>0),Se=ye(()=>a.value<u.value||r.value<se.value),Ie=ye(()=>fa(q.value,{config:o.value,allSlides:s.value,pageIndex:a.value,currentStep:r.value})),_e=ye(()=>fa(ce.value,{config:o.value,allSlides:s.value,pageIndex:a.value+1})),pe=ye(()=>{var ue;if(!q.value)return"无内容";const le=(ue=q.value.blocks)==null?void 0:ue[0];return(le==null?void 0:le.content)||(le==null?void 0:le.rawMarkdown)||`第 ${a.value} 页`});function X(le){return(le||[]).slice(1).map(ue=>(ue.content||ue.rawMarkdown||"").trim()).filter(ue=>ue&&!/^(image\s+)?assets\/\S*$/i.test(ue)&&!/^!\[[^\]]*\]\(assets\/[^)]*\)$/.test(ue)).join(" | ").slice(0,120)}const Q=ye(()=>{var le;return X((le=q.value)==null?void 0:le.blocks)}),L=ye(()=>{var ue;if(!ce.value)return"演示结束";const le=(ue=ce.value.blocks)==null?void 0:ue[0];return(le==null?void 0:le.content)||(le==null?void 0:le.rawMarkdown)||`第 ${a.value+1} 页`}),j=ye(()=>ce.value?X(ce.value.blocks):"这是最后一页"),v=ye(()=>{var le;return((le=q.value)==null?void 0:le.notes)||""}),U=ge(20);function W(){U.value<36&&(U.value+=2)}function _(){U.value>14&&(U.value-=2)}const T=ye(()=>u.value<=1?100:Math.round(a.value/u.value*100));let P=null;try{P=new BroadcastChannel("siyuan-slides-sync"),P.onmessage=le=>{const ue=le.data;if(ue&&(ue.type==="SYNC_PAGE"&&typeof ue.page=="number"&&(a.value=ue.page,r.value=typeof ue.step=="number"?Math.max(0,ue.step):0,typeof ue.maxStep=="number"&&(c.value=Math.max(0,ue.maxStep))),ue.type==="SYNC_SLIDES"&&Array.isArray(ue.slides)&&(s.value=ue.slides,ue.config&&typeof ue.config=="object"&&(o.value=ue.config)),ue.type==="REQUEST_SYNC"&&s.value.length>0))try{P==null||P.postMessage({type:"SYNC_SLIDES",slides:JSON.parse(JSON.stringify(s.value)),config:JSON.parse(JSON.stringify(o.value||{}))}),P==null||P.postMessage({type:"SYNC_PAGE",page:a.value,step:r.value,maxStep:se.value})}catch{}}}catch{P=null}function Y(le,ue=0){const Ye=Number(le)||1,ze=Math.max(0,Number(ue)||0);n.navigatePage(Ye,ze);try{P==null||P.postMessage({type:"SYNC_PAGE",page:Ye,step:ze,maxStep:se.value})}catch{}}function B(){if(r.value<se.value){r.value++,Y(a.value,r.value);return}a.value<u.value&&(a.value++,r.value=0,Y(a.value,0))}function z(){if(r.value>0){r.value--,Y(a.value,r.value);return}a.value>1&&(a.value--,r.value=0,Y(a.value,0))}function Z(){a.value<u.value&&(a.value++,r.value=0,Y(a.value,0))}function ie(){a.value>1&&(a.value--,r.value=0,Y(a.value,0))}function oe(){a.value=1,r.value=0,A(),Y(1,0)}function me(){const le=i;typeof(le==null?void 0:le.openBottomPreviewTab)=="function"&&le.openBottomPreviewTab()}function $e(){const le=i;typeof(le==null?void 0:le.openStandalonePreviewWindow)=="function"&&le.openStandalonePreviewWindow()}function xe(le){var ue,Ye;if(!(le.key===" "&&((Ye=(ue=le.target)==null?void 0:ue.closest)!=null&&Ye.call(ue,"button")))){if(le.shiftKey&&le.key==="ArrowRight"||le.key==="ArrowDown"){le.preventDefault(),Z();return}if(le.shiftKey&&le.key==="ArrowLeft"||le.key==="ArrowUp"){le.preventDefault(),ie();return}le.key==="ArrowRight"||le.key===" "||le.key==="PageDown"?(le.preventDefault(),B()):(le.key==="ArrowLeft"||le.key==="PageUp")&&(le.preventDefault(),z())}}let De=0;function Ne(le){var ze,je;if(Math.abs(le.deltaY)<Wv)return;const ue=(je=(ze=le.target)==null?void 0:ze.closest)==null?void 0:je.call(ze,".notes-content");if(ue){const ot=ue.scrollHeight-ue.clientHeight;if(ot>2&&(le.deltaY>0&&ue.scrollTop<ot-1||le.deltaY<0&&ue.scrollTop>1))return}const Ye=Date.now();Ye-De<jv||(De=Ye,le.deltaY>0?B():z())}let Fe=null;return vn(()=>{var ue;V=Date.now(),k=0,$=window.setInterval(H,500),typeof document<"u"&&document.addEventListener("visibilitychange",H),G(),ne=window.setInterval(G,1e3),Fe=n.onSlideChanged((Ye,ze,je,ot,ii)=>{a.value=Ye,ze>0&&(l.value=ze),typeof ot=="number"&&(r.value=Math.max(0,ot)),typeof ii=="number"&&(c.value=Math.max(0,ii))});try{P==null||P.postMessage({type:"REQUEST_SYNC"})}catch{}const le=i==null?void 0:i.latestCompiledDoc;(ue=le==null?void 0:le.slides)!=null&&ue.length&&(s.value=le.slides,le.config&&(o.value=le.config)),typeof window<"u"&&window.addEventListener("resize",C),Is(()=>{R(),C()})}),Us(()=>{$&&(window.clearInterval($),$=null),typeof document<"u"&&document.removeEventListener("visibilitychange",H),ne&&(window.clearInterval(ne),ne=null),Fe&&Fe(),typeof window<"u"&&window.removeEventListener("resize",C),D&&(D.disconnect(),D=null);try{P==null||P.close()}catch{}P=null}),t({updateDocument(le){var ue;(ue=le==null?void 0:le.slides)!=null&&ue.length&&(s.value=le.slides),le!=null&&le.config&&(o.value=le.config)}}),(le,ue)=>{var Ye,ze,je;return J(),te("div",{class:"spm-presenter-tab",tabindex:"0",onKeydown:xe,onWheel:Ne},[f("header",Hg,[f("div",Fg,[f("div",jg,[ae(fe,{name:"presenter",class:"brand-icon"}),ue[1]||(ue[1]=f("span",{class:"title-name"},"演讲者控制台",-1))]),f("div",Wg,[f("span",Ug,"P."+we(a.value)+" / "+we(u.value||1),1),se.value>0?(J(),te("span",Vg,[ae(fe,{name:"step",class:"pill-icon"}),_t(" 步进 "+we(r.value)+" / "+we(se.value),1)])):Te("",!0)])]),f("div",Gg,[f("button",{class:"btn-tool b3-tooltips b3-tooltips__s","aria-label":"弹出大屏放映独立窗口 (16:9)",onClick:$e},[ae(fe,{name:"window"}),ue[2]||(ue[2]=f("span",{class:"btn-tool-label"},"独立放映",-1))]),f("div",Kg,[ae(fe,{name:"clock",class:"timer-icon"}),f("span",qg,we(F.value),1),f("div",Yg,[f("button",{class:"timer-btn b3-tooltips b3-tooltips__s","aria-label":K.value?"暂停计时":"继续计时",onClick:I},[ae(fe,{name:K.value?"pause":"play"},null,8,["name"])],8,Zg),f("button",{class:"timer-btn b3-tooltips b3-tooltips__s","aria-label":"重置计时",onClick:A},[ae(fe,{name:"reset"})])])]),f("div",Jg,[f("span",null,we(O.value),1)])])]),u.value>0?(J(),te("main",Xg,[f("section",Qg,[f("div",ev,[f("div",tv,[f("div",iv,[ue[3]||(ue[3]=f("span",{class:"panel-tag is-current"},"当前放映",-1)),f("span",nv,"P."+we(a.value),1)]),f("div",sv,[se.value>0?(J(),te("span",ov," 步进 "+we(r.value)+" / "+we(se.value),1)):Te("",!0),f("span",rv,we(((ze=(Ye=q.value)==null?void 0:Ye.frontmatter)==null?void 0:ze.layout)||"default"),1)])]),f("div",{ref_key:"currentPreviewRef",ref:d,class:"panel-preview","aria-label":pe.value},[q.value?(J(),te("div",{key:0,class:"presenter-thumb-box",style:qt({width:M.value.boxWidth+"px",height:M.value.boxHeight+"px"})},[f("div",{class:Ce(["presenter-thumb-viewport slide-viewport","slides-theme-"+y.value]),"data-theme":g.value,"data-slides-theme":y.value,"data-normalize-headings":w.value?"true":"false","data-hide-unordered-markers":S.value?"true":"false","data-hide-ordered-markers":x.value?"true":"false",style:qt({width:m.value.baseWidth+"px",height:m.value.baseHeight+"px",transform:"scale("+M.value.scale+")"}),innerHTML:Ie.value},null,14,lv)],4)):(J(),te("div",cv,[f("h2",null,we(pe.value),1),f("p",null,we(Q.value),1)]))],8,av)]),f("div",{class:Ce(["panel-box next-slide-panel",{"is-clickable":!!ce.value,"b3-tooltips b3-tooltips__n":!!ce.value}]),"aria-label":ce.value?"点击直接跳至下一页":"",onClick:ue[0]||(ue[0]=ot=>ce.value&&Z())},[f("div",uv,[f("div",fv,[ue[4]||(ue[4]=f("span",{class:"panel-tag"},"下一页预告",-1)),a.value<u.value?(J(),te("span",pv,"P."+we(a.value+1),1)):Te("",!0)]),f("div",hv,[a.value>=u.value?(J(),te("span",mv,"已到尾页")):ce.value?(J(),te("span",gv,we(((je=ce.value.frontmatter)==null?void 0:je.layout)||"default"),1)):Te("",!0)])]),f("div",{ref_key:"nextPreviewRef",ref:h,class:"panel-preview panel-preview--dim","aria-label":L.value},[ce.value?(J(),te("div",{key:0,class:"presenter-thumb-box",style:qt({width:E.value.boxWidth+"px",height:E.value.boxHeight+"px"})},[f("div",{class:Ce(["presenter-thumb-viewport slide-viewport","slides-theme-"+y.value]),"data-theme":g.value,"data-slides-theme":y.value,"data-normalize-headings":w.value?"true":"false","data-hide-unordered-markers":S.value?"true":"false","data-hide-ordered-markers":x.value?"true":"false",style:qt({width:m.value.baseWidth+"px",height:m.value.baseHeight+"px",transform:"scale("+E.value.scale+")"}),innerHTML:_e.value},null,14,bv)],4)):(J(),te("div",yv,[f("h2",null,we(L.value),1),f("p",null,we(j.value),1)]))],8,vv)],10,dv)]),f("section",kv,[f("div",wv,[f("div",xv,[ae(fe,{name:"notes",class:"panel-title-icon"}),ue[5]||(ue[5]=f("span",null,"讲稿备忘",-1))]),f("div",Sv,[f("button",{class:"notes-btn b3-tooltips b3-tooltips__w","aria-label":"减小字体",disabled:U.value<=14,onClick:_},[ae(fe,{name:"minus"})],8,Cv),f("span",_v,we(U.value)+"px",1),f("button",{class:"notes-btn b3-tooltips b3-tooltips__w","aria-label":"增大字体",disabled:U.value>=36,onClick:W},[ae(fe,{name:"plus"})],8,$v)])]),f("div",{class:Ce(["notes-content",{"is-empty":!v.value}]),style:qt({fontSize:U.value+"px"})},we(v.value||"（本页未设置演讲者备忘录）"),7)])])):(J(),te("main",Iv,[f("div",Mv,[ae(fe,{name:"refresh",class:"empty-icon"})]),ue[8]||(ue[8]=f("h2",null,"等待大屏放映数据",-1)),ue[9]||(ue[9]=f("p",null,"未检测到活跃的幻灯片数据，请先开启大屏放映端。",-1)),f("div",Tv,[f("button",{class:"btn-empty-action b3-tooltips b3-tooltips__n","aria-label":"在思源中打开底部演示预览页签",onClick:me},[ae(fe,{name:"presenter"}),ue[6]||(ue[6]=f("span",null,"打开大屏放映页签",-1))]),f("button",{class:"btn-empty-action btn-empty-action--popout b3-tooltips b3-tooltips__n","aria-label":"将放映端弹出为独立窗口 (16:9)",onClick:$e},[ae(fe,{name:"window"}),ue[7]||(ue[7]=f("span",null,"弹出独立放映窗口",-1))])])])),f("footer",Ev,[f("div",Av,[f("button",{class:"btn-nav btn-nav--slide b3-tooltips b3-tooltips__ne",disabled:a.value<=1,"aria-label":"快速返回上一页 (Shift + ←)",onClick:ie},[ae(fe,{name:"chevrons-left"}),ue[10]||(ue[10]=f("span",null,"上一页",-1))],8,Bv),f("button",{class:"btn-nav btn-nav--step b3-tooltips b3-tooltips__n",disabled:!re.value,"aria-label":"回退一步 (←)",onClick:z},[ae(fe,{name:"chevron-left"}),ue[11]||(ue[11]=f("span",null,"上一步",-1))],8,Dv)]),f("div",Lv,[f("div",Pv,[f("span",Ov,we(T.value)+"%",1)]),f("button",{class:"btn-restart b3-tooltips b3-tooltips__n","aria-label":"从第一页重新放映 (Home)",onClick:oe},[ae(fe,{name:"reset"}),ue[12]||(ue[12]=f("span",null,"重头放映",-1))])]),f("div",Rv,[se.value>0?(J(),te("div",{key:0,class:"step-dots-bar b3-tooltips b3-tooltips__n","aria-label":`步进进度: ${r.value} / ${se.value}`},[(J(!0),te(Xe,null,xt(se.value,ot=>(J(),te("span",{key:ot,class:Ce(["step-dot",{"is-active":ot<=r.value}])},null,2))),128)),f("span",zv,we(r.value)+"/"+we(se.value),1)],8,Nv)):Te("",!0),f("button",{class:"btn-nav btn-nav--step btn-nav--primary b3-tooltips b3-tooltips__n",disabled:!Se.value,"aria-label":"触发下一步骤或进入下一页 (Space / →)",onClick:B},[ue[13]||(ue[13]=f("span",null,"下一步",-1)),ae(fe,{name:"chevron-right"})],8,Hv),f("button",{class:"btn-nav btn-nav--slide b3-tooltips b3-tooltips__nw",disabled:a.value>=u.value,"aria-label":"跳过本页剩余步骤，直接进入下一页 (Shift + →)",onClick:Z},[ue[14]||(ue[14]=f("span",null,"下一页",-1)),ae(fe,{name:"chevrons-right"})],8,Fv)])])],32)}}}),Vv=ti(Uv,[["__scopeId","data-v-c103f4a6"]]),Gv={class:"spm-layout-picker"},Kv={class:"spm-layout-picker__grid"},qv=["title","onClick"],Yv={class:"spm-layout-icon"},Zv={class:"spm-layout-label"},Jv=Bt({__name:"LayoutPicker",props:{modelValue:{}},emits:["update:modelValue","change"],setup(e,{emit:t}){const i=e,n=t,s=[{name:"cover",label:"封面",desc:"大标题与副标题封面页"},{name:"default",label:"标准",desc:"标题在上方，内容在下方"},{name:"two-cols",label:"双栏",desc:"左右双栏对比展示"},{name:"cols-header",label:"表头多栏",desc:"顶部通栏标题，下方自适应 2~N 栏"},{name:"clover",label:"四叶草",desc:"2x2 田字型四象限卡片布局"},{name:"image-right",label:"图右",desc:"左侧为内容，右侧全屏背景图"},{name:"image-left",label:"图左",desc:"左侧全屏背景图，右侧为内容"},{name:"center",label:"居中",desc:"内容全屏垂直水平居中"},{name:"fact",label:"大字报",desc:"核心数据或指标突出展示"},{name:"intro",label:"介绍",desc:"演讲者自我介绍或章节导览"},{name:"quote",label:"引言",desc:"名人名言与强调段落"}];function o(r){return i.modelValue===r||r==="cols-header"&&(i.modelValue==="two-cols-header"||i.modelValue==="three-cols-header")}function a(r){n("update:modelValue",r),n("change",r)}return(r,l)=>(J(),te("div",Gv,[l[0]||(l[0]=f("div",{class:"spm-layout-picker__header"},"选择页面版式",-1)),f("div",Kv,[(J(),te(Xe,null,xt(s,c=>f("div",{key:c.name,class:Ce(["spm-layout-item",{active:o(c.name)}]),title:c.desc,onClick:u=>a(c.name)},[f("div",Yv,[ae(fe,{name:"layout-"+c.name},null,8,["name"])]),f("span",Zv,we(c.label),1)],10,qv)),64))])]))}}),Xv=ti(Jv,[["__scopeId","data-v-96c8a248"]]),Qv={key:0,class:"spm-transition-selector__header"},eb={class:"spm-transition-list"},tb=["onClick"],ib={class:"spm-transition-meta"},nb={class:"spm-transition-label"},sb={class:"spm-transition-preview-box"},ob=Bt({__name:"TransitionSelector",props:{modelValue:{},hideHeader:{type:Boolean},title:{}},emits:["update:modelValue","change"],setup(e,{emit:t}){const i=t,n=[{name:"slide-left",label:"向左滑入",desc:"向左滑入：页面从右侧向左平滑推入，最通用标准的横向幻灯片动效"},{name:"slide-right",label:"向右滑入",desc:"向右滑入：页面从左侧向右平滑推入，适合倒序回退或逆向章节叙述"},{name:"slide-up",label:"向上推入",desc:"向上推入：页面从底部向上平滑推入，适合纵向展开或纵深层级展示"},{name:"fade",label:"淡入淡出",desc:"淡入淡出：透明度平滑渐变过度，典雅柔和，适合学术长篇与沉浸叙事"},{name:"zoom",label:"缩放进入",desc:"缩放进入：页面由中心向外平滑放大，富有动感冲击力，适合聚焦重点"}];function s(o){i("update:modelValue",o),i("change",o)}return(o,a)=>(J(),te("div",{class:Ce(["spm-transition-selector",{"spm-transition-selector--no-header":e.hideHeader}])},[e.hideHeader?Te("",!0):(J(),te("div",Qv,we(e.title||"转场动效"),1)),f("div",eb,[(J(),te(Xe,null,xt(n,r=>f("div",{key:r.name,class:Ce(["spm-transition-item",{active:e.modelValue===r.name}]),onClick:l=>s(r.name)},[f("div",ib,[f("span",nb,we(r.label),1)]),f("div",sb,[f("div",{class:Ce(["spm-anim-cube","anim-"+r.name])},null,2)])],10,tb)),64))])],2))}}),sc=ti(ob,[["__scopeId","data-v-b5051f69"]]),rb={class:"spm-section spm-section--page"},ab={class:"spm-section-header"},lb={key:0,class:"spm-card-control",style:{"border-left":"3px solid var(--b3-theme-primary)",background:"rgba(var(--b3-theme-primary-rgb, 66, 133, 244), 0.06)",padding:"8px 12px","margin-top":"6px"}},cb={style:{display:"flex","align-items":"center","justify-content":"space-between",gap:"8px"}},db={style:{"font-size":"11px",display:"flex","align-items":"center",gap:"6px",flex:"1"}},ub={key:1,class:"spm-card-control"},fb={class:"spm-control-header"},pb={class:"spm-control-title-group"},hb={class:"spm-control-title"},mb={class:"spm-quick-chips"},gb=["onClick"],vb={style:{display:"flex",gap:"6px","align-items":"center","margin-top":"6px"}},bb=["value"],yb=["aria-label"],kb={key:1,class:"spm-icon-btn b3-tooltips b3-tooltips__sw",disabled:"",style:{opacity:"0.45",cursor:"not-allowed",padding:"0 8px",height:"26px","font-size":"11px","white-space":"nowrap","flex-shrink":"0"},"aria-label":"当前页未检测到调整过列宽的横向超级块"},wb={key:0,style:{"margin-top":"6px","font-size":"11px",opacity:"0.85",display:"flex","align-items":"center",gap:"4px"}},xb={style:{background:"rgba(125, 125, 125, 0.15)",padding:"1px 4px","border-radius":"3px","font-weight":"bold"}},Sb={key:1,style:{"margin-top":"6px","font-size":"11px",opacity:"0.6",display:"flex","align-items":"center",gap:"4px"}},Cb={class:"spm-card-control"},_b={class:"spm-control-header"},$b={class:"spm-control-title-group"},Ib={class:"spm-control-title"},Mb={class:"spm-segmented-group"},Tb={key:0,style:{"margin-top":"10px",display:"flex","flex-direction":"column",gap:"8px"}},Eb={style:{display:"flex","align-items":"center","justify-content":"space-between"}},Ab=["aria-label"],Bb={class:"spm-quick-chips"},Db=["onClick"],Lb=["value"],Pb={style:{"font-size":"10.5px",opacity:"0.6","line-height":"1.35","margin-top":"-2px"}},Ob={style:{display:"flex",gap:"8px","margin-top":"2px"}},Rb={style:{flex:"1"}},Nb={class:"spm-segmented-group"},zb={style:{flex:"1"}},Hb={class:"spm-segmented-group"},Fb={class:"spm-card-control"},jb={class:"spm-control-header"},Wb={class:"spm-control-title-group"},Ub={class:"spm-control-title"},Vb={class:"spm-segmented-group"},Gb={class:"spm-card-control"},Kb={class:"spm-control-header"},qb={class:"spm-control-title-group"},Yb={class:"spm-control-title"},Zb={class:"spm-quick-chips"},Jb=["onClick"],Xb=["value"],Qb={key:2,class:"spm-card-control"},e1={class:"spm-control-header"},t1={class:"spm-control-title-group"},i1={class:"spm-control-title"},n1={class:"spm-quick-chips"},s1=["onClick"],o1=["value"],r1={class:"spm-card-control"},a1={class:"spm-control-header"},l1={class:"spm-control-title-group"},c1={class:"spm-control-title"},d1={key:0,class:"spm-note-status-box"},u1=["title"],f1={class:"spm-action-grid",style:{"margin-top":"6px"}},p1={key:1,class:"spm-note-empty-box"},h1={class:"spm-batch-actions-box",style:{"margin-top":"8px","border-top":"1px dashed var(--b3-border-color, #e2e8f0)","padding-top":"8px"}},m1={class:"spm-action-grid"},g1=["disabled"],v1=["disabled"],b1={class:"spm-card-control"},y1={class:"spm-action-grid"},k1=Bt({__name:"PageInspectorSection",props:{pageLayout:{},pageTransition:{},pageBackground:{},pageSpacing:{},pageImage:{},pageNotes:{},pageIndex:{},pageLayoutRatio:{},pageMask:{},pageMaskRatio:{},pageMaskStyle:{},pageMaskInitial:{},detectedSbRatio:{},detectedSbInfo:{},isBatchProcessing:{type:Boolean}},emits:["update:pageLayout","update:pageTransition","update:pageBackground","update:pageSpacing","update:pageImage","update:pageLayoutRatio","update:pageMask","update:pageMaskRatio","update:pageMaskStyle","update:pageMaskInitial","applySuperBlockLayout","resetSuperblockRatio","addNoteBlock","locateNoteBlock","generateNotes","batchAppendNotes","batchDeleteNotes","insertDividerAfter","deleteDivider"],setup(e,{emit:t}){const i=e,n=t,s=[{label:"1:1 (2步)",value:"1:1"},{label:"1:1:1 (3步)",value:"1:1:1"},{label:"1:2:1 (非等宽)",value:"1:2:1"},{label:"1:1:1:1 (4步)",value:"1:1:1:1"}],o=ye(()=>{const S=i.pageMask;return S==="clockwise"||S==="counter-clockwise"||S==="cw"||S==="ccw"}),a=ye(()=>o.value?"1:1:1:1":"1:1"),r=ye(()=>i.pageMaskRatio||a.value);function l(S){n("update:pageMask",S),(!i.pageMaskRatio||i.pageMaskRatio==="1:1")&&n("update:pageMaskRatio","1:1:1:1")}function c(S){n("update:pageMask",S),(!i.pageMaskRatio||i.pageMaskRatio==="1:1:1:1")&&n("update:pageMaskRatio","1:1")}const u=ye(()=>i.pageMask==="clockwise"||i.pageMask==="counter-clockwise"||i.pageMask==="cw"||i.pageMask==="ccw"?`时钟走时规则：
• 顺时针：左上 → 右上 → 右下 → 左下
• 逆时针：左上 → 左下 → 右下 → 右上
• 每次点击时针旋转 90° 并扇形扫开 1/4 象限，全部揭开后翻页`:`输入规则：
• 权重比例（项数决定步数）：如 1:1 (2步等分)、1:1:1 (3步等分)、1:2:1 (按权重累计分段)
• 绝对百分比：如 25:75:100 或 30:80 (指定每步展开的累计百分比)
• 每次点击或按空格/向右键展露下一段，全部揭开后翻页`),d=ye(()=>["two-cols","cols-header","two-cols-header","three-cols-header","image-left","image-right"].includes(i.pageLayout)),h=ye(()=>{var M,E;if(i.pageLayout==="two-cols-header"||i.pageLayout==="two-cols"||i.pageLayout==="image-left"||i.pageLayout==="image-right")return 2;if(i.pageLayout==="three-cols-header")return 3;const S=(i.pageLayoutRatio||"").trim();if(S.includes(":")){const C=S.split(":").filter(Boolean).length;if(C>=2&&C<=6)return C}const x=(i.detectedSbRatio||"").trim();if(x.includes(":")){const C=x.split(":").filter(Boolean).length;if(C>=2&&C<=6)return C}if((M=i.detectedSbInfo)!=null&&M.colCount&&i.detectedSbInfo.colCount>=2)return Math.min(i.detectedSbInfo.colCount,6);if((E=i.detectedSbInfo)!=null&&E.slots&&Array.isArray(i.detectedSbInfo.slots)){const C=i.detectedSbInfo.slots.length;if(C>=2&&C<=6)return C}return 2}),p=ye(()=>{const S=h.value;return S===3?[{label:"默认 1:1:1",value:""},{label:"1:2:1 (主中)",value:"1:2:1"},{label:"2:1:1 (主左)",value:"2:1:1"},{label:"1:1:2 (主右)",value:"1:1:2"},{label:"1:3:1",value:"1:3:1"}]:S===4?[{label:"默认 1:1:1:1",value:""},{label:"1:2:2:1",value:"1:2:2:1"},{label:"2:1:1:2",value:"2:1:1:2"}]:S===5?[{label:"默认 1:1:1:1:1",value:""}]:S===6?[{label:"默认 1:1:1:1:1:1",value:""}]:[{label:"默认 1:1",value:""},{label:"1:2",value:"1:2"},{label:"2:1",value:"2:1"},{label:"3:7",value:"3:7"},{label:"7:3",value:"7:3"},{label:"4:6",value:"4:6"},{label:"6:4",value:"6:4"}]}),b=ye(()=>i.pageLayoutRatio||"");function m(){const S=h.value||2,x=Array(S).fill("1").join(":");n("update:pageLayoutRatio",x),n("resetSuperblockRatio")}const y=ye(()=>{if(!i.pageNotes)return"";const S=i.pageNotes.replace(/[\r\n]+/g," ").trim();return S.length>50?S.slice(0,50)+"...":S}),g=[{label:"默认",value:""},{label:"暗黑 #1e1e24",value:"#1e1e24"},{label:"极夜 #0f172a",value:"#0f172a"},{label:"极简白 #ffffff",value:"#ffffff"}],w=[{label:"默认封面",value:"https://cover.sli.dev"},{label:"清空配图",value:""}];return(S,x)=>(J(),te("div",rb,[f("div",ab,[f("span",null,"幻灯片页面设置"+we(e.pageIndex?` (第 ${e.pageIndex} 页)`:""),1)]),ae(Xv,{"model-value":e.pageLayout,onChange:x[0]||(x[0]=M=>S.$emit("update:pageLayout",M))},null,8,["model-value"]),!d.value&&e.pageLayout!=="clover"&&e.detectedSbRatio?(J(),te("div",lb,[f("div",cb,[f("div",db,[ae(fe,{name:"sparkles"}),f("span",null,[x[33]||(x[33]=_t("检测到本页横向超级块列宽比例：",-1)),f("b",null,we(e.detectedSbRatio),1)])]),f("button",{class:"spm-btn-action b3-tooltips b3-tooltips__sw","aria-label":"一键应用超级块列宽并设为分栏",style:{padding:"2px 8px",height:"26px","font-size":"11px","flex-shrink":"0",background:"var(--b3-theme-primary)",color:"#fff",display:"inline-flex","align-items":"center",gap:"4px"},onClick:x[1]||(x[1]=M=>S.$emit("applySuperBlockLayout",e.detectedSbInfo||{recommendedLayout:"two-cols",ratio:e.detectedSbRatio}))},[ae(fe,{name:"columns"}),x[34]||(x[34]=f("span",null,"设为分栏",-1))])])])):Te("",!0),d.value?(J(),te("div",ub,[f("div",fb,[f("div",pb,[f("div",hb,[ae(fe,{name:"ratio"}),x[35]||(x[35]=f("span",null,"分栏比例",-1))]),x[36]||(x[36]=f("span",{class:"spm-control-desc"},"设置各列横向空间占比，默认平均分配",-1))])]),f("div",mb,[(J(!0),te(Xe,null,xt(p.value,M=>(J(),te("button",{key:M.value,class:Ce(["spm-chip",{active:b.value===M.value}]),onClick:E=>S.$emit("update:pageLayoutRatio",M.value)},we(M.label),11,gb))),128))]),f("div",vb,[f("input",{value:e.pageLayoutRatio||"",class:"spm-input",style:{flex:"1","min-width":"0"},placeholder:"自定义比例（如 1:2 或 30:70，留空为默认）",onInput:x[2]||(x[2]=M=>S.$emit("update:pageLayoutRatio",M.target.value)),onChange:x[3]||(x[3]=M=>S.$emit("update:pageLayoutRatio",M.target.value))},null,40,bb),e.detectedSbRatio?(J(),te("button",{key:0,class:"spm-icon-btn b3-tooltips b3-tooltips__sw","aria-label":`读取超级块列宽比例 (${e.detectedSbRatio}) 并应用`,style:{padding:"0 8px",height:"26px","font-size":"11px","white-space":"nowrap","flex-shrink":"0"},onClick:x[4]||(x[4]=M=>S.$emit("update:pageLayoutRatio",e.detectedSbRatio))},[ae(fe,{name:"sparkles"}),x[37]||(x[37]=f("span",null,"读取",-1))],8,yb)):(J(),te("button",kb,[ae(fe,{name:"sparkles"}),x[38]||(x[38]=f("span",null,"读取",-1))])),f("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__sw","aria-label":"重置为等宽平均分布",style:{padding:"0 8px",height:"26px","font-size":"11px","white-space":"nowrap","flex-shrink":"0"},onClick:m},[ae(fe,{name:"reset"}),x[39]||(x[39]=f("span",null,"重置",-1))])]),e.detectedSbRatio?(J(),te("div",wb,[ae(fe,{name:"ratio"}),x[40]||(x[40]=f("span",null,"检测到思源超级块宽度：",-1)),f("code",xb,we(e.detectedSbRatio),1)])):(J(),te("div",Sb,[ae(fe,{name:"ratio"}),x[41]||(x[41]=f("span",null,"未检测到调宽超级块（默认各列平均分配）",-1))]))])):Te("",!0),ae(sc,{"model-value":e.pageTransition,onChange:x[5]||(x[5]=M=>S.$emit("update:pageTransition",M))},null,8,["model-value"]),f("div",Cb,[f("div",_b,[f("div",$b,[f("div",Ib,[ae(fe,{name:"sparkles"}),x[42]||(x[42]=f("span",null,"页面动态蒙版",-1))]),x[43]||(x[43]=f("span",{class:"spm-control-desc"},"随着点击操作分段展露正文内容",-1))])]),f("div",Mb,[f("button",{class:Ce(["spm-segmented-item",{active:!e.pageMask}]),onClick:x[6]||(x[6]=M=>S.$emit("update:pageMask",""))}," 关闭 ",2),f("button",{class:Ce(["spm-segmented-item",{active:e.pageMask==="down"}]),onClick:x[7]||(x[7]=M=>c("down"))}," 从上至下 ",2),f("button",{class:Ce(["spm-segmented-item",{active:e.pageMask==="right"}]),onClick:x[8]||(x[8]=M=>c("right"))}," 从左至右 ",2),f("button",{class:Ce(["spm-segmented-item",{active:e.pageMask==="clockwise"||e.pageMask==="cw"}]),onClick:x[9]||(x[9]=M=>l("clockwise"))}," 顺时针 ↻ ",2),f("button",{class:Ce(["spm-segmented-item",{active:e.pageMask==="counter-clockwise"||e.pageMask==="ccw"}]),onClick:x[10]||(x[10]=M=>l("counter-clockwise"))}," 逆时针 ↺ ",2)]),e.pageMask?(J(),te("div",Tb,[f("div",Eb,[x[45]||(x[45]=f("div",{style:{"font-size":"11px",opacity:"0.85","font-weight":"500"}},"展露比例 / 断点",-1)),f("span",{class:"b3-tooltips b3-tooltips__sw","aria-label":u.value,style:{cursor:"help",opacity:"0.75",display:"inline-flex","align-items":"center",gap:"3px","font-size":"11px"}},[ae(fe,{name:"help"}),x[44]||(x[44]=f("span",null,"输入规则",-1))],8,Ab)]),f("div",Bb,[(J(),te(Xe,null,xt(s,M=>f("button",{key:M.value,class:Ce(["spm-chip",{active:r.value===M.value}]),onClick:E=>S.$emit("update:pageMaskRatio",M.value)},we(M.label),11,Db)),64))]),f("input",{value:r.value,class:"spm-input",style:{width:"100%"},placeholder:"自定义比例或断点（如 1:2:1 或 25:75:100）",onInput:x[11]||(x[11]=M=>S.$emit("update:pageMaskRatio",M.target.value)),onChange:x[12]||(x[12]=M=>S.$emit("update:pageMaskRatio",M.target.value))},null,40,Lb),f("div",Pb,we(e.pageMask==="clockwise"||e.pageMask==="counter-clockwise"||e.pageMask==="cw"||e.pageMask==="ccw"?"时钟走时蒙版：默认 4 步旋转展露（1:1:1:1，每步 25% 扇形面积）":"提示：支持权重比（如 1:2:1）或绝对断点（如 25:75:100），冒号项数决定点击步数"),1),f("div",Ob,[f("div",Rb,[x[46]||(x[46]=f("div",{style:{"font-size":"11px",opacity:"0.85","margin-bottom":"4px"}},"遮盖质感",-1)),f("div",Nb,[f("button",{class:Ce(["spm-segmented-item",{active:!e.pageMaskStyle||e.pageMaskStyle==="solid"}]),onClick:x[13]||(x[13]=M=>S.$emit("update:pageMaskStyle","solid"))}," 背景同色 ",2),f("button",{class:Ce(["spm-segmented-item",{active:e.pageMaskStyle==="blur"}]),onClick:x[14]||(x[14]=M=>S.$emit("update:pageMaskStyle","blur"))}," 磨砂毛玻璃 ",2)])]),f("div",zb,[x[47]||(x[47]=f("div",{style:{"font-size":"11px",opacity:"0.85","margin-bottom":"4px"}},"初始展露",-1)),f("div",Hb,[f("button",{class:Ce(["spm-segmented-item",{active:!e.pageMaskInitial||e.pageMaskInitial==="hidden"}]),onClick:x[15]||(x[15]=M=>S.$emit("update:pageMaskInitial","hidden"))}," 完全遮盖 ",2),f("button",{class:Ce(["spm-segmented-item",{active:e.pageMaskInitial==="revealed"}]),onClick:x[16]||(x[16]=M=>S.$emit("update:pageMaskInitial","revealed"))}," 首段可见 ",2)])])])])):Te("",!0)]),f("div",Fb,[f("div",jb,[f("div",Wb,[f("div",Ub,[ae(fe,{name:"ratio"}),x[48]||(x[48]=f("span",null,"页面间距",-1))]),x[49]||(x[49]=f("span",{class:"spm-control-desc"},"覆盖本页内边距与顶部标题间距",-1))])]),f("div",Vb,[f("button",{class:Ce(["spm-segmented-item",{active:!e.pageSpacing||e.pageSpacing==="inherit"}]),onClick:x[17]||(x[17]=M=>S.$emit("update:pageSpacing","inherit"))}," 继承全局 ",2),f("button",{class:Ce(["spm-segmented-item",{active:e.pageSpacing==="compact"}]),onClick:x[18]||(x[18]=M=>S.$emit("update:pageSpacing","compact"))}," 紧凑 ",2),f("button",{class:Ce(["spm-segmented-item",{active:e.pageSpacing==="normal"}]),onClick:x[19]||(x[19]=M=>S.$emit("update:pageSpacing","normal"))}," 标准 ",2),f("button",{class:Ce(["spm-segmented-item",{active:e.pageSpacing==="loose"}]),onClick:x[20]||(x[20]=M=>S.$emit("update:pageSpacing","loose"))}," 宽松 ",2)])]),f("div",Gb,[f("div",Kb,[f("div",qb,[f("div",Yb,[ae(fe,{name:"palette"}),x[50]||(x[50]=f("span",null,"页面背景",-1))]),x[51]||(x[51]=f("span",{class:"spm-control-desc"},"设置当前页特定底色或壁纸",-1))])]),f("div",Zb,[(J(),te(Xe,null,xt(g,M=>f("button",{key:M.value,class:Ce(["spm-chip",{active:e.pageBackground===M.value}]),onClick:E=>S.$emit("update:pageBackground",M.value)},we(M.label),11,Jb)),64))]),f("input",{value:e.pageBackground,class:"spm-input",placeholder:"自定义颜色代码或资源路径",onInput:x[21]||(x[21]=M=>S.$emit("update:pageBackground",M.target.value)),onChange:x[22]||(x[22]=M=>S.$emit("update:pageBackground",M.target.value))},null,40,Xb)]),e.pageLayout==="image-right"||e.pageLayout==="image-left"||e.pageImage?(J(),te("div",Qb,[f("div",e1,[f("div",t1,[f("div",i1,[ae(fe,{name:"image"}),x[52]||(x[52]=f("span",null,"页面图片",-1))]),x[53]||(x[53]=f("span",{class:"spm-control-desc"},"图文分栏或页面专属配图 URL / 资源路径",-1))])]),f("div",n1,[(J(),te(Xe,null,xt(w,M=>f("button",{key:M.value,class:Ce(["spm-chip",{active:e.pageImage===M.value}]),onClick:E=>S.$emit("update:pageImage",M.value)},we(M.label),11,s1)),64))]),f("input",{value:e.pageImage,class:"spm-input",placeholder:"网络图片 URL (如 https://cover.sli.dev) 或 assets/...",onInput:x[23]||(x[23]=M=>S.$emit("update:pageImage",M.target.value)),onChange:x[24]||(x[24]=M=>S.$emit("update:pageImage",M.target.value))},null,40,o1)])):Te("",!0),f("div",r1,[f("div",a1,[f("div",l1,[f("div",c1,[ae(fe,{name:"presenter"}),x[54]||(x[54]=f("span",null,"演讲者提词",-1))]),x[55]||(x[55]=f("span",{class:"spm-control-desc"},"正文备注块驱动 · 仅演讲者视图可见",-1))]),he($t)("aiScript")?(J(),te("button",{key:0,class:"spm-btn-text b3-tooltips b3-tooltips__sw","aria-label":"AI 自动生成本页讲稿提示块",onClick:x[25]||(x[25]=M=>S.$emit("generateNotes"))},[ae(fe,{name:"sparkles"}),x[56]||(x[56]=f("span",null,"AI 讲稿",-1))])):Te("",!0)]),e.pageNotes?(J(),te("div",d1,[x[59]||(x[59]=f("div",{class:"spm-note-status-badge"},[f("span",{class:"spm-badge-dot"}),f("span",null,"已配置正文讲稿")],-1)),f("div",{class:"spm-note-preview-text",title:e.pageNotes},we(y.value),9,u1),f("div",f1,[f("button",{class:"spm-btn-action b3-tooltips b3-tooltips__se","aria-label":"在正文编辑区定位并高亮此讲稿备注块",onClick:x[26]||(x[26]=M=>S.$emit("locateNoteBlock"))},[ae(fe,{name:"search"}),x[57]||(x[57]=f("span",null,"定位讲稿块",-1))]),f("button",{class:"spm-btn-action b3-tooltips b3-tooltips__sw","aria-label":"在本页末尾追加新的讲稿提示块",onClick:x[27]||(x[27]=M=>S.$emit("addNoteBlock"))},[ae(fe,{name:"insert-below"}),x[58]||(x[58]=f("span",null,"追加讲稿块",-1))])])])):(J(),te("div",p1,[x[61]||(x[61]=f("div",{class:"spm-note-empty-hint"},"本页暂无讲稿备注块",-1)),f("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s",style:{width:"100%","margin-top":"6px"},"aria-label":"在当前页末尾插入默认演讲备注提示块",onClick:x[28]||(x[28]=M=>S.$emit("addNoteBlock"))},[ae(fe,{name:"insert-below"}),x[60]||(x[60]=f("span",null,"添加讲稿备注块",-1))])])),f("div",h1,[f("div",m1,[f("button",{class:"spm-btn-action b3-tooltips b3-tooltips__se",disabled:e.isBatchProcessing,style:qt(e.isBatchProcessing?"opacity: 0.5; cursor: not-allowed;":""),"aria-label":"在所有尚未配置讲稿的页面末尾批量追加讲稿提示块",onClick:x[29]||(x[29]=M=>S.$emit("batchAppendNotes"))},[ae(fe,{name:"insert-below"}),x[62]||(x[62]=f("span",null,"全部追加",-1))],12,g1),f("button",{class:"spm-btn-action spm-btn-danger b3-tooltips b3-tooltips__sw",disabled:e.isBatchProcessing,style:qt(e.isBatchProcessing?"opacity: 0.5; cursor: not-allowed;":""),"aria-label":"批量物理删除正文中的全部讲稿备注块（涉及全部页）",onClick:x[30]||(x[30]=M=>S.$emit("batchDeleteNotes"))},[ae(fe,{name:"trash"}),x[63]||(x[63]=f("span",null,"全部删除",-1))],12,v1)])])]),f("div",b1,[x[66]||(x[66]=f("div",{class:"spm-control-header"},[f("div",{class:"spm-control-title-group"},[f("span",{class:"spm-control-title"},"分页快捷操作")])],-1)),f("div",y1,[f("button",{class:"spm-btn-action b3-tooltips b3-tooltips__se","aria-label":"在此分页符之后插入新的空白分页",onClick:x[31]||(x[31]=M=>S.$emit("insertDividerAfter"))},[ae(fe,{name:"insert-below"}),x[64]||(x[64]=f("span",null,"插入新页",-1))]),f("button",{class:"spm-btn-action spm-btn-danger b3-tooltips b3-tooltips__sw","aria-label":"彻底删除当前分页符（合并前后页面）",onClick:x[32]||(x[32]=M=>S.$emit("deleteDivider"))},[ae(fe,{name:"trash"}),x[65]||(x[65]=f("span",null,"删除此页",-1))])])])]))}}),w1=ti(k1,[["__scopeId","data-v-61712dad"]]),x1={class:"spm-section spm-section--block"},S1={key:0,class:"spm-card-control",style:{"border-left":"3px solid var(--b3-theme-primary)"}},C1={class:"spm-control-header"},_1={class:"spm-control-title-group"},$1={class:"spm-control-title"},I1={style:{background:"var(--b3-theme-surface)",border:"1px solid var(--b3-theme-surface-lighter)","border-radius":"6px",padding:"10px","margin-bottom":"8px"}},M1={style:{display:"flex","align-items":"center","justify-content":"space-between","margin-bottom":"4px"}},T1={style:{"font-size":"12px","font-weight":"500",display:"flex","align-items":"center",gap:"4px"}},E1={key:0},A1={key:1},B1={style:{background:"rgba(var(--b3-theme-primary-rgb, 59, 130, 246), 0.16)",color:"var(--b3-theme-primary)",border:"1px solid rgba(var(--b3-theme-primary-rgb, 59, 130, 246), 0.3)",padding:"2px 6px","border-radius":"4px","font-weight":"bold","font-size":"12px"}},D1={style:{"font-size":"11px",opacity:"0.75","line-height":"1.4"}},L1={class:"spm-action-grid"},P1={class:"spm-card-control"},O1={class:"spm-control-header"},R1={class:"spm-control-title-group"},N1={class:"spm-control-title"},z1=["aria-label"],H1=["checked"],F1={key:1,class:"spm-card-control"},j1={class:"spm-control-header"},W1={class:"spm-control-title-group"},U1={class:"spm-control-title"},V1={class:"spm-quick-chips"},G1={key:2,class:"spm-card-control"},K1={class:"spm-control-header"},q1={class:"spm-control-title-group"},Y1={class:"spm-control-title"},Z1={class:"spm-video-settings-grid",style:{display:"grid","grid-template-columns":"1fr 1fr",gap:"8px","margin-top":"8px"}},J1={class:"spm-toggle-item",style:{display:"flex","align-items":"center","justify-content":"space-between",padding:"4px 6px",background:"rgba(125,125,125,0.06)","border-radius":"4px"}},X1={style:{"font-size":"11px",display:"inline-flex","align-items":"center",gap:"4px"}},Q1=["aria-label"],ey=["checked"],ty={class:"spm-toggle-item",style:{display:"flex","align-items":"center","justify-content":"space-between",padding:"4px 6px",background:"rgba(125,125,125,0.06)","border-radius":"4px"}},iy={style:{"font-size":"11px",display:"inline-flex","align-items":"center",gap:"4px"}},ny=["aria-label"],sy=["checked"],oy={class:"spm-toggle-item",style:{display:"flex","align-items":"center","justify-content":"space-between",padding:"4px 6px",background:"rgba(125,125,125,0.06)","border-radius":"4px"}},ry={style:{"font-size":"11px",display:"inline-flex","align-items":"center",gap:"4px"}},ay=["aria-label"],ly=["checked"],cy={class:"spm-toggle-item",style:{display:"flex","align-items":"center","justify-content":"space-between",padding:"4px 6px",background:"rgba(125,125,125,0.06)","border-radius":"4px"}},dy={style:{"font-size":"11px",display:"inline-flex","align-items":"center",gap:"4px"}},uy=["aria-label"],fy=["checked"],py={class:"spm-card-control"},hy={class:"spm-control-header"},my={class:"spm-control-title-group"},gy={class:"spm-control-title"},vy=["aria-label"],by=["checked"],yy={key:0,class:"spm-quick-chips"},ky=["onClick"],wy={key:1,class:"spm-inherit-tip",style:{"margin-top":"6px",padding:"4px 8px",background:"rgba(var(--b3-theme-primary-rgb, 59, 130, 246), 0.08)","border-radius":"4px","font-size":"11px",opacity:"0.85",display:"flex","align-items":"center",gap:"4px"}},xy={class:"spm-card-control"},Sy={class:"spm-control-header"},Cy={class:"spm-control-title-group"},_y={class:"spm-control-title"},$y=["aria-label"],Iy=["checked"],My={key:0,class:"spm-quick-chips"},Ty=["onClick"],Ey={key:1,class:"spm-motion-details",style:{display:"flex","flex-direction":"column",gap:"4px","margin-top":"4px"}},Ay={style:{display:"flex",gap:"8px","justify-content":"space-between","font-size":"11px",opacity:"0.8"}},By={style:{display:"flex",gap:"6px"}},Dy=["value"],Ly=["value"],Py={key:3,class:"spm-card-control"},Oy={class:"spm-control-header"},Ry={class:"spm-control-title-group"},Ny={class:"spm-control-title"},zy={class:"spm-control-desc"},Hy={class:"spm-segmented-group"},Fy=["onClick"],jy={key:4,class:"spm-card-control"},Wy={class:"spm-control-header"},Uy={class:"spm-control-title-group"},Vy={class:"spm-control-title"},Gy={class:"spm-quick-chips"},Ky=["onClick"],qy=["value"],Yy={key:5,class:"spm-card-control"},Zy={class:"spm-control-header"},Jy={class:"spm-control-title-group"},Xy={class:"spm-control-title"},Qy={class:"spm-quick-chips"},e0=["onClick"],t0=["value"],i0={class:"spm-card-control"},n0={class:"spm-action-grid"},s0=["aria-label"],o0=Bt({__name:"BlockInspectorSection",props:{elemClick:{},elemMotion:{},elemSlot:{},elemShikiLines:{},elemMaxHeight:{},isCodeBlock:{type:Boolean},isImage:{type:Boolean},isVideo:{type:Boolean},videoAutoplay:{type:Boolean},videoLoop:{type:Boolean},videoMuted:{type:Boolean},videoControls:{type:Boolean},hasBlockAttrs:{type:Boolean},isNote:{type:Boolean},imageRole:{},currentSlideLayout:{},isSuperBlock:{type:Boolean},parentElemClick:{},parentContainerSlot:{},parentContainerId:{},detectedSbInfo:{}},emits:["toggleNote","toggleElemClick","update:elemClick","update:elemMotion","update:elemSlot","update:elemShikiLines","update:elemMaxHeight","applySuperBlockLayout","applySuperBlockRatio","insertDividerBefore","insertDividerAfter","setTwoColsContrast","clearBlockAttrs","update:imageRole","toggleVideoAutoplay","toggleVideoLoop","toggleVideoMuted","toggleVideoControls"],setup(e,{emit:t}){const i=e,n=ye(()=>{const E=i.currentSlideLayout||"";return["col-1","col-2","col-3","col-4","col-5","col-6"].includes(i.elemSlot)?"cols-header":E}),s=ye(()=>{const E=n.value;return["two-cols","cols-header","two-cols-header","three-cols-header"].includes(E)}),o=ye(()=>{var C,D,R,N;if((C=i.detectedSbInfo)!=null&&C.colCount&&i.detectedSbInfo.colCount>=2)return Math.min(i.detectedSbInfo.colCount,6);const E=(D=i.elemSlot)==null?void 0:D.match(/^col-(\d+)$/);if(E){const K=parseInt(E[1],10);if(K>=2&&K<=6)return Math.max(K,3)}if(i.currentSlideLayout==="three-cols-header")return 3;if(i.currentSlideLayout==="two-cols-header"||i.currentSlideLayout==="two-cols")return 2;if((N=(R=i.detectedSbInfo)==null?void 0:R.ratio)!=null&&N.includes(":")){const K=i.detectedSbInfo.ratio.split(":").filter(Boolean);if(K.length>=2)return Math.min(K.length,6)}return 3}),a=ye(()=>{const E=n.value;return E==="cols-header"?"多栏插槽归属":E==="three-cols-header"?"三栏插槽归属":E==="two-cols-header"?"带表头双栏插槽":"多栏插槽归属"}),r=ye(()=>{const E=n.value;return E==="cols-header"?`在 cols-header 表头多栏（${o.value} 栏）中的内容块位置`:E==="three-cols-header"?"在 three-cols-header 版式中的内容块位置":E==="two-cols-header"?"在 two-cols-header 版式中的内容块位置":E==="two-cols"?"在 two-cols 双栏版式中的归属":"在当前分栏版式中的内容块位置"}),l=ye(()=>{const E=n.value;if(E==="two-cols")return[{value:"",label:"默认 (左)"},{value:"right",label:"右栏"}];if(E==="two-cols-header")return[{value:"",label:"默认"},{value:"header",label:"表头"},{value:"left",label:"左栏"},{value:"right",label:"右栏"}];if(E==="three-cols-header")return[{value:"",label:"默认"},{value:"header",label:"表头"},{value:"col-1",label:"第 1 栏"},{value:"col-2",label:"第 2 栏"},{value:"col-3",label:"第 3 栏"}];const C=o.value,D=[{value:"",label:"默认"},{value:"header",label:"表头"}];for(let R=1;R<=C;R++)D.push({value:`col-${R}`,label:`第 ${R} 栏`});return D});function c(E){const C=i.elemSlot||"";return E?C===E||E==="col-1"&&C==="left"||E==="col-2"&&C==="center"||E==="col-3"&&C==="right"&&o.value===3||E==="col-2"&&C==="right"&&o.value===2||E==="left"&&C==="col-1"||E==="right"&&(C==="col-2"||C==="col-3"):!C||C==="default"}const u=t,d=[{label:"上浮",value:"slide-up"},{label:"淡入",value:"fade-in"},{label:"下沉",value:"slide-down"},{label:"左滑",value:"slide-left"},{label:"右滑",value:"slide-right"},{label:"缩放",value:"zoom-in"},{label:"弹性",value:"bounce"}],h=ye(()=>{if(!i.elemMotion||i.elemMotion.trim()===""||i.elemMotion.trim()==="none")return null;try{const E=JSON.parse(i.elemMotion);if(typeof E=="object"&&E!==null)return{preset:E.preset||E.type||"slide-up",duration:typeof E.duration=="number"?E.duration:0,delay:typeof E.delay=="number"?E.delay:0}}catch{}return{preset:i.elemMotion.trim(),duration:0,delay:0}}),p=ye(()=>!!h.value),b=ye(()=>{var E;return((E=h.value)==null?void 0:E.preset)||"slide-up"}),m=ye(()=>{var E;return((E=h.value)==null?void 0:E.duration)||0}),y=ye(()=>{var E;return((E=h.value)==null?void 0:E.delay)||0});function g(){p.value?u("update:elemMotion",""):u("update:elemMotion","slide-up")}function w(E){M(E,m.value,y.value)}function S(E){M(b.value,E,y.value)}function x(E){M(b.value,m.value,E)}function M(E,C,D){if(!E||E==="none"){u("update:elemMotion","");return}if(!C&&!D){u("update:elemMotion",E);return}const R={preset:E};C>0&&(R.duration=C),D>0&&(R.delay=D),u("update:elemMotion",JSON.stringify(R))}return(E,C)=>{var D,R,N,K,$,V;return J(),te("div",x1,[C[62]||(C[62]=f("div",{class:"spm-section-header"},[f("span",null,"元素动效与排版")],-1)),e.isSuperBlock||(D=e.detectedSbInfo)!=null&&D.hasSuperBlock?(J(),te("div",S1,[f("div",C1,[f("div",_1,[f("div",$1,[ae(fe,{name:"ratio"}),C[24]||(C[24]=f("span",null,"超级块列宽与布局",-1))]),C[25]||(C[25]=f("span",{class:"spm-control-desc"},"读取思源超级块列宽并一键同步到幻灯片分栏",-1))])]),f("div",I1,[f("div",M1,[f("div",T1,[ae(fe,{name:"ratio"}),(R=e.detectedSbInfo)!=null&&R.isCustomWidth?(J(),te("span",E1,"已识别自定义列宽比例")):(J(),te("span",A1,"识别到 "+we(((N=e.detectedSbInfo)==null?void 0:N.colCount)||2)+" 列超级块分栏",1))]),f("code",B1,we(((K=e.detectedSbInfo)==null?void 0:K.ratio)||"1:1"),1)]),f("div",D1,we(($=e.detectedSbInfo)!=null&&$.isCustomWidth?"检测到已调节子块宽度，可一键应用为当前页分栏比例。":"当前超级块子列为思源默认均宽，可在思源中拖动调节或直接应用。"),1)]),f("div",L1,[f("button",{class:"spm-btn-action b3-tooltips b3-tooltips__se","aria-label":"一键将当前页版式切换为对应双栏/三栏，并写入此列宽比例",style:{background:"rgba(var(--b3-theme-primary-rgb, 59, 130, 246), 0.16)",color:"var(--b3-theme-primary)","font-weight":"500",border:"1px solid rgba(var(--b3-theme-primary-rgb, 59, 130, 246), 0.3)"},onClick:C[0]||(C[0]=k=>E.$emit("applySuperBlockLayout",e.detectedSbInfo))},[ae(fe,{name:"sparkles"}),C[26]||(C[26]=f("span",null,"应用版式与比例",-1))]),f("button",{class:"spm-btn-action b3-tooltips b3-tooltips__sw","aria-label":"仅将提取的比值写入当前页的分栏比例属性",onClick:C[1]||(C[1]=k=>{var F;return E.$emit("applySuperBlockRatio",((F=e.detectedSbInfo)==null?void 0:F.ratio)||"1:1")})},[ae(fe,{name:"check"}),f("span",null,"应用比例 ("+we(((V=e.detectedSbInfo)==null?void 0:V.ratio)||"1:1")+")",1)])])])):Te("",!0),f("div",P1,[f("div",O1,[f("div",R1,[f("div",N1,[ae(fe,{name:"presenter"}),C[27]||(C[27]=f("span",null,"设为讲稿备注",-1))]),C[28]||(C[28]=f("span",{class:"spm-control-desc"},"作为当前页演讲提词，不在幻灯片中渲染",-1))]),f("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":e.isNote?"取消讲稿备注":"设为讲稿备注"},[f("input",{type:"checkbox",checked:!!e.isNote,onChange:C[2]||(C[2]=k=>E.$emit("toggleNote"))},null,40,H1),C[29]||(C[29]=f("span",{class:"spm-switch-slider"},null,-1))],8,z1)])]),e.isImage||e.imageRole?(J(),te("div",F1,[f("div",j1,[f("div",W1,[f("div",U1,[ae(fe,{name:"image"}),C[30]||(C[30]=f("span",null,"图片角色与分栏",-1))]),C[31]||(C[31]=f("span",{class:"spm-control-desc"},"设为幻灯片背景图或图文分栏配图",-1))])]),f("div",V1,[f("button",{class:Ce(["spm-chip",{active:!e.imageRole}]),onClick:C[3]||(C[3]=k=>E.$emit("update:imageRole",""))}," 普通内容 ",2),f("button",{class:Ce(["spm-chip",{active:e.imageRole==="background"}]),onClick:C[4]||(C[4]=k=>E.$emit("update:imageRole","background"))},[ae(fe,{name:"image"}),C[32]||(C[32]=f("span",null,"背景图",-1))],2),f("button",{class:Ce(["spm-chip",{active:e.imageRole==="image-left"}]),onClick:C[5]||(C[5]=k=>E.$emit("update:imageRole","image-left"))},[ae(fe,{name:"image-left"}),C[33]||(C[33]=f("span",null,"图左",-1))],2),f("button",{class:Ce(["spm-chip",{active:e.imageRole==="image-right"}]),onClick:C[6]||(C[6]=k=>E.$emit("update:imageRole","image-right"))},[ae(fe,{name:"image-right"}),C[34]||(C[34]=f("span",null,"图右",-1))],2)])])):Te("",!0),e.isVideo?(J(),te("div",G1,[f("div",K1,[f("div",q1,[f("div",Y1,[ae(fe,{name:"video"}),C[35]||(C[35]=f("span",null,"视频播放设置",-1))]),C[36]||(C[36]=f("span",{class:"spm-control-desc"},"配置播放器控制条、自动播放与循环",-1))])]),f("div",Z1,[f("div",J1,[f("span",X1,[ae(fe,{name:"sliders"}),C[37]||(C[37]=_t(" 控制条",-1))]),f("label",{class:"spm-switch b3-tooltips b3-tooltips__se","aria-label":e.videoControls?"关闭控制条":"开启控制条"},[f("input",{type:"checkbox",checked:!!e.videoControls,onChange:C[7]||(C[7]=k=>E.$emit("toggleVideoControls"))},null,40,ey),C[38]||(C[38]=f("span",{class:"spm-switch-slider"},null,-1))],8,Q1)]),f("div",ty,[f("span",iy,[ae(fe,{name:"video"}),C[39]||(C[39]=_t(" 自动播放",-1))]),f("label",{class:"spm-switch b3-tooltips b3-tooltips__sw","aria-label":e.videoAutoplay?"关闭自动播放":"开启自动播放"},[f("input",{type:"checkbox",checked:!!e.videoAutoplay,onChange:C[8]||(C[8]=k=>E.$emit("toggleVideoAutoplay"))},null,40,sy),C[40]||(C[40]=f("span",{class:"spm-switch-slider"},null,-1))],8,ny)]),f("div",oy,[f("span",ry,[ae(fe,{name:"repeat"}),C[41]||(C[41]=_t(" 循环播放",-1))]),f("label",{class:"spm-switch b3-tooltips b3-tooltips__se","aria-label":e.videoLoop?"关闭循环播放":"开启循环播放"},[f("input",{type:"checkbox",checked:!!e.videoLoop,onChange:C[9]||(C[9]=k=>E.$emit("toggleVideoLoop"))},null,40,ly),C[42]||(C[42]=f("span",{class:"spm-switch-slider"},null,-1))],8,ay)]),f("div",cy,[f("span",dy,[ae(fe,{name:"volume-x"}),C[43]||(C[43]=_t(" 静音播放",-1))]),f("label",{class:"spm-switch b3-tooltips b3-tooltips__sw","aria-label":e.videoMuted?"关闭静音":"开启静音"},[f("input",{type:"checkbox",checked:!!e.videoMuted,onChange:C[10]||(C[10]=k=>E.$emit("toggleVideoMuted"))},null,40,fy),C[44]||(C[44]=f("span",{class:"spm-switch-slider"},null,-1))],8,uy)])])])):Te("",!0),f("div",py,[f("div",hy,[f("div",my,[f("div",gy,[ae(fe,{name:"step"}),C[45]||(C[45]=f("span",null,"逐步呈现",-1))]),C[46]||(C[46]=f("span",{class:"spm-control-desc"},"放映时按步长逐个呈现",-1))]),f("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":e.elemClick?"关闭逐步呈现":"开启逐步呈现 (+1)"},[f("input",{type:"checkbox",checked:!!e.elemClick,onChange:C[11]||(C[11]=k=>E.$emit("toggleElemClick"))},null,40,by),C[47]||(C[47]=f("span",{class:"spm-switch-slider"},null,-1))],8,vy)]),e.elemClick?(J(),te("div",yy,[(J(),te(Xe,null,xt(["+1","1","2","hide"],k=>f("button",{key:k,class:Ce(["spm-chip",{active:e.elemClick===k}]),onClick:F=>E.$emit("update:elemClick",k)},we(k==="+1"?"顺延 (+1)":k==="hide"?"隐藏":"第 "+k+" 步"),11,ky)),64))])):e.parentElemClick?(J(),te("div",wy,[ae(fe,{name:"check"}),C[48]||(C[48]=f("span",null,"未单独开启逐步呈现：当前跟随整栏同时出现",-1))])):Te("",!0)]),f("div",xy,[f("div",Sy,[f("div",Cy,[f("div",_y,[ae(fe,{name:"motion"}),C[49]||(C[49]=f("span",null,"入场微动效",-1))]),C[50]||(C[50]=f("span",{class:"spm-control-desc"},"为当前块添加平滑位移与渐入动画",-1))]),f("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":p.value?"关闭微动效":"开启微动效"},[f("input",{type:"checkbox",checked:p.value,onChange:g},null,40,Iy),C[51]||(C[51]=f("span",{class:"spm-switch-slider"},null,-1))],8,$y)]),p.value?(J(),te("div",My,[(J(),te(Xe,null,xt(d,k=>f("button",{key:k.value,class:Ce(["spm-chip",{active:b.value===k.value}]),onClick:F=>w(k.value)},we(k.label),11,Ty)),64))])):Te("",!0),p.value?(J(),te("div",Ey,[f("div",Ay,[f("span",null,"时长: "+we(m.value?m.value+"ms":"默认 (450ms)"),1),f("span",null,"延迟: "+we(y.value?y.value+"ms":"0ms"),1)]),f("div",By,[f("select",{class:"spm-select",style:{flex:"1"},value:m.value,onChange:C[12]||(C[12]=k=>S(Number(k.target.value)))},[...C[52]||(C[52]=[f("option",{value:0},"默认耗时",-1),f("option",{value:200},"极速 (200ms)",-1),f("option",{value:350},"较快 (350ms)",-1),f("option",{value:500},"平滑 (500ms)",-1),f("option",{value:800},"缓慢 (800ms)",-1)])],40,Dy),f("select",{class:"spm-select",style:{flex:"1"},value:y.value,onChange:C[13]||(C[13]=k=>x(Number(k.target.value)))},[...C[53]||(C[53]=[f("option",{value:0},"无延迟",-1),f("option",{value:150},"延迟 150ms",-1),f("option",{value:300},"延迟 300ms",-1),f("option",{value:500},"延迟 500ms",-1)])],40,Ly)])])):Te("",!0)]),s.value||e.elemSlot?(J(),te("div",Py,[f("div",Oy,[f("div",Ry,[f("div",Ny,[ae(fe,{name:"columns"}),f("span",null,we(a.value),1)]),f("span",zy,we(r.value),1)])]),f("div",Hy,[(J(!0),te(Xe,null,xt(l.value,k=>(J(),te("button",{key:k.value,class:Ce(["spm-segmented-item",{active:c(k.value)}]),onClick:F=>E.$emit("update:elemSlot",k.value)},we(k.label),11,Fy))),128))])])):Te("",!0),e.isCodeBlock?(J(),te("div",jy,[f("div",Wy,[f("div",Uy,[f("div",Vy,[ae(fe,{name:"code"}),C[54]||(C[54]=f("span",null,"代码逐行聚光",-1))]),C[55]||(C[55]=f("span",{class:"spm-control-desc"},"翻页时动态聚光高亮特定行",-1))])]),f("div",Gy,[(J(),te(Xe,null,xt(["1-3","all","1|2|3","2-5"],k=>f("button",{key:k,class:Ce(["spm-chip",{active:e.elemShikiLines===k}]),onClick:F=>E.$emit("update:elemShikiLines",k)},we(k),11,Ky)),64)),e.elemShikiLines?(J(),te("button",{key:0,class:"spm-chip spm-chip-clear",onClick:C[14]||(C[14]=k=>E.$emit("update:elemShikiLines",""))}," 清空 ")):Te("",!0)]),f("input",{value:e.elemShikiLines,class:"spm-input",placeholder:"自定义高亮区间，如 1-3|5|all",onInput:C[15]||(C[15]=k=>E.$emit("update:elemShikiLines",k.target.value)),onChange:C[16]||(C[16]=k=>E.$emit("update:elemShikiLines",k.target.value))},null,40,qy)])):Te("",!0),e.isCodeBlock?(J(),te("div",Yy,[f("div",Zy,[f("div",Jy,[f("div",Xy,[ae(fe,{name:"code"}),C[56]||(C[56]=f("span",null,"代码块限高",-1))]),C[57]||(C[57]=f("span",{class:"spm-control-desc"},"超出限高自动竖向滚动，弱提示滚动条",-1))])]),f("div",Qy,[(J(),te(Xe,null,xt(["240px","320px","400px","50vh"],k=>f("button",{key:k,class:Ce(["spm-chip",{active:e.elemMaxHeight===k}]),onClick:F=>E.$emit("update:elemMaxHeight",k)},we(k),11,e0)),64)),e.elemMaxHeight?(J(),te("button",{key:0,class:"spm-chip spm-chip-clear",onClick:C[17]||(C[17]=k=>E.$emit("update:elemMaxHeight",""))}," 自适应 ")):Te("",!0)]),f("input",{value:e.elemMaxHeight,class:"spm-input",placeholder:"自适应高度，或输入 350px、50vh",onInput:C[18]||(C[18]=k=>E.$emit("update:elemMaxHeight",k.target.value)),onChange:C[19]||(C[19]=k=>E.$emit("update:elemMaxHeight",k.target.value))},null,40,t0)])):Te("",!0),f("div",i0,[C[61]||(C[61]=f("div",{class:"spm-control-header"},[f("div",{class:"spm-control-title-group"},[f("span",{class:"spm-control-title"},"快捷操作")])],-1)),f("div",n0,[f("button",{class:"spm-btn-action b3-tooltips b3-tooltips__se","aria-label":"在当前块上方插入幻灯片分页线 (---)",onClick:C[20]||(C[20]=k=>E.$emit("insertDividerBefore"))},[ae(fe,{name:"insert-above"}),C[58]||(C[58]=f("span",null,"上方分页",-1))]),f("button",{class:"spm-btn-action b3-tooltips b3-tooltips__sw","aria-label":"在当前块下方插入幻灯片分页线 (---)",onClick:C[21]||(C[21]=k=>E.$emit("insertDividerAfter"))},[ae(fe,{name:"insert-below"}),C[59]||(C[59]=f("span",null,"下方分页",-1))]),f("button",{class:"spm-btn-action b3-tooltips b3-tooltips__se","aria-label":n.value==="three-cols-header"?"将当前块属性设为三栏第1栏归属":"将当前块属性设为双栏左侧归属",onClick:C[22]||(C[22]=k=>E.$emit("setTwoColsContrast"))},[ae(fe,{name:"columns"}),f("span",null,we(n.value==="three-cols-header"?"设为第1栏":"设为双栏"),1)],8,s0),e.hasBlockAttrs?(J(),te("button",{key:0,class:"spm-btn-action spm-btn-danger b3-tooltips b3-tooltips__sw","aria-label":"一键移除本块所有 custom-slides 属性",onClick:C[23]||(C[23]=k=>E.$emit("clearBlockAttrs"))},[ae(fe,{name:"broom"}),C[60]||(C[60]=f("span",null,"清除属性",-1))])):Te("",!0)])])])}}}),r0={class:"spm-section spm-section--doc"},a0={class:"spm-card-control"},l0={class:"spm-control-header"},c0={class:"spm-control-title-group"},d0={class:"spm-control-title"},u0={class:"spm-segmented-group"},f0=["aria-label","onClick"],p0={class:"spm-card-control"},h0={class:"spm-control-header"},m0={class:"spm-control-title-group"},g0={class:"spm-control-title"},v0={class:"spm-segmented-group"},b0={class:"spm-card-control"},y0={class:"spm-control-header"},k0={class:"spm-control-title-group"},w0={class:"spm-control-title"},x0={class:"spm-segmented-group"},S0={class:"spm-card-control"},C0={class:"spm-control-header"},_0={class:"spm-control-title-group"},$0={class:"spm-control-title"},I0={class:"spm-card-control"},M0={class:"spm-control-header"},T0={class:"spm-control-title-group"},E0={class:"spm-control-title"},A0=["aria-label"],B0=["checked"],D0={key:0,class:"spm-control-body",style:{"margin-top":"8px"}},L0=["value"],P0={class:"spm-card-control"},O0={class:"spm-control-header"},R0={class:"spm-control-title-group"},N0={class:"spm-control-title"},z0=["aria-label"],H0=["checked"],F0={class:"spm-card-control"},j0={class:"spm-control-header"},W0={class:"spm-control-title-group"},U0={class:"spm-control-title"},V0={class:"spm-list-markers-toggles",style:{display:"flex",gap:"8px","margin-top":"8px"}},G0={class:"spm-marker-toggle-item",style:{flex:"1",display:"flex","align-items":"center","justify-content":"space-between",padding:"6px 10px",background:"var(--b3-theme-surface)",border:"1px solid var(--b3-border-color)","border-radius":"4px"}},K0=["aria-label"],q0=["checked"],Y0={class:"spm-marker-toggle-item",style:{flex:"1",display:"flex","align-items":"center","justify-content":"space-between",padding:"6px 10px",background:"var(--b3-theme-surface)",border:"1px solid var(--b3-border-color)","border-radius":"4px"}},Z0=["aria-label"],J0=["checked"],X0={class:"spm-card-control"},Q0={class:"spm-action-grid"},ek=["disabled"],tk=["disabled"],ik=["disabled","aria-label"],nk=Bt({__name:"DocInspectorSection",props:{docTheme:{},docAspectRatio:{},docDefaultTransition:{},docSpacing:{},isExportingImages:{type:Boolean},isBatchProcessing:{type:Boolean}},emits:["update:docTheme","update:docAspectRatio","update:docDefaultTransition","update:docSpacing","openBottomPreview","openPresenter","identifyNotes","autoAnimate","aiAutoSplit","exportHtml","exportPdf","exportImages"],setup(e){const t=Nt("plugin"),i=Ut,n=[{value:"default",label:"默认 default",desc:"官方默认科技风：现代无衬线排版与清新代码语法高亮，通用汇报与技术分享首选"},{value:"seriph",label:"优雅 seriph",desc:"典雅学术衬线风：书卷学术质感、衬线字体典雅庄重，适合学术论文、人文讲座与深度阅读"},{value:"apple-basic",label:"极简 apple",desc:"苹果发布会极简风：大字号、高对比度与极致留白，适合产品发布、方案演讲与纯粹视觉呈现"}];function s(u){ri({enableWebServeJump:u}),t&&typeof t.saveGlobalSettings=="function"&&t.saveGlobalSettings({enableWebServeJump:u})}async function o(u){var d;ri({normalizeHeadingSizes:u}),t&&typeof t.saveGlobalSettings=="function"&&await t.saveGlobalSettings({normalizeHeadingSizes:u}),t&&typeof t.compileCurrentDocument=="function"&&t.compileCurrentDocument(t.currentDocId||((d=t.getActiveDocumentId)==null?void 0:d.call(t)))}async function a(u){var d;ri({showUnorderedListMarkers:u}),t&&typeof t.saveGlobalSettings=="function"&&await t.saveGlobalSettings({showUnorderedListMarkers:u}),t&&typeof t.compileCurrentDocument=="function"&&t.compileCurrentDocument(t.currentDocId||((d=t.getActiveDocumentId)==null?void 0:d.call(t)))}async function r(u){var d;ri({showOrderedListMarkers:u}),t&&typeof t.saveGlobalSettings=="function"&&await t.saveGlobalSettings({showOrderedListMarkers:u}),t&&typeof t.compileCurrentDocument=="function"&&t.compileCurrentDocument(t.currentDocId||((d=t.getActiveDocumentId)==null?void 0:d.call(t)))}function l(u){ri({webServeUrl:u})}function c(u){ri({webServeUrl:u}),t&&typeof t.saveGlobalSettings=="function"&&t.saveGlobalSettings({webServeUrl:u})}return(u,d)=>(J(),te("div",r0,[d[52]||(d[52]=f("div",{class:"spm-section-header"},[f("span",null,"全局演示配置")],-1)),f("div",a0,[f("div",l0,[f("div",c0,[f("div",d0,[ae(fe,{name:"palette"}),d[23]||(d[23]=f("span",null,"幻灯片主题",-1))]),d[24]||(d[24]=f("span",{class:"spm-control-desc"},"全局幻灯片视觉设计范式",-1))])]),f("div",u0,[(J(),te(Xe,null,xt(n,h=>f("button",{key:h.value,class:Ce(["spm-segmented-item b3-tooltips b3-tooltips__s",{active:e.docTheme===h.value}]),"aria-label":h.desc,onClick:p=>u.$emit("update:docTheme",h.value)},we(h.label),11,f0)),64))])]),f("div",p0,[f("div",h0,[f("div",m0,[f("div",g0,[ae(fe,{name:"ratio"}),d[25]||(d[25]=f("span",null,"画幅比例",-1))]),d[26]||(d[26]=f("span",{class:"spm-control-desc"},"演讲屏幕投影宽高比",-1))])]),f("div",v0,[f("button",{class:Ce(["spm-segmented-item",{active:e.docAspectRatio==="16/9"}]),onClick:d[0]||(d[0]=h=>u.$emit("update:docAspectRatio","16/9"))}," 16 : 9 (宽屏) ",2),f("button",{class:Ce(["spm-segmented-item",{active:e.docAspectRatio==="4/3"}]),onClick:d[1]||(d[1]=h=>u.$emit("update:docAspectRatio","4/3"))}," 4 : 3 (标屏) ",2),f("button",{class:Ce(["spm-segmented-item",{active:e.docAspectRatio==="16/10"}]),onClick:d[2]||(d[2]=h=>u.$emit("update:docAspectRatio","16/10"))}," 16 : 10 ",2)])]),f("div",b0,[f("div",y0,[f("div",k0,[f("div",w0,[ae(fe,{name:"ratio"}),d[27]||(d[27]=f("span",null,"间距风格",-1))]),d[28]||(d[28]=f("span",{class:"spm-control-desc"},"内边距与顶部标题下边距预设",-1))])]),f("div",x0,[f("button",{class:Ce(["spm-segmented-item b3-tooltips b3-tooltips__se",{active:(e.docSpacing||"normal")==="compact"}]),"aria-label":"紧凑排版：上下 20px / 左右 36px",onClick:d[3]||(d[3]=h=>u.$emit("update:docSpacing","compact"))}," 紧凑 ",2),f("button",{class:Ce(["spm-segmented-item b3-tooltips b3-tooltips__s",{active:(e.docSpacing||"normal")==="normal"}]),"aria-label":"标准排版：上下 32px / 左右 48px（推荐默认）",onClick:d[4]||(d[4]=h=>u.$emit("update:docSpacing","normal"))}," 标准 ",2),f("button",{class:Ce(["spm-segmented-item b3-tooltips b3-tooltips__sw",{active:(e.docSpacing||"normal")==="loose"}]),"aria-label":"宽松排版：上下 48px / 左右 56px",onClick:d[5]||(d[5]=h=>u.$emit("update:docSpacing","loose"))}," 宽松 ",2)])]),f("div",S0,[f("div",C0,[f("div",_0,[f("div",$0,[ae(fe,{name:"transition"}),d[29]||(d[29]=f("span",null,"全局默认转场",-1))]),d[30]||(d[30]=f("span",{class:"spm-control-desc"},"页面切换过渡动效（未单设转场的页面将继承此动效）",-1))])]),ae(sc,{"model-value":e.docDefaultTransition,"hide-header":!0,onChange:d[6]||(d[6]=h=>u.$emit("update:docDefaultTransition",h))},null,8,["model-value"])]),f("div",I0,[f("div",M0,[f("div",T0,[f("div",E0,[ae(fe,{name:"external-link"}),d[31]||(d[31]=f("span",null,"本地网络伺服预览",-1))]),d[32]||(d[32]=f("span",{class:"spm-control-desc"},"点击文档/块链接以 Webview 抽屉呈现，支持外跳",-1))]),f("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":he(i).enableWebServeJump?"关闭本地网络伺服预览":"开启本地网络伺服预览"},[f("input",{type:"checkbox",checked:he(i).enableWebServeJump,onChange:d[7]||(d[7]=h=>s(h.target.checked))},null,40,B0),d[33]||(d[33]=f("span",{class:"spm-switch-slider"},null,-1))],8,A0)]),he(i).enableWebServeJump?(J(),te("div",D0,[f("input",{value:he(i).webServeUrl,class:"spm-input",placeholder:"http://127.0.0.1:6806",spellcheck:"false",onKeydown:d[8]||(d[8]=Yt(()=>{},["stop"])),onKeyup:d[9]||(d[9]=Yt(()=>{},["stop"])),onInput:d[10]||(d[10]=h=>l(h.target.value)),onChange:d[11]||(d[11]=h=>c(h.target.value))},null,40,L0),d[34]||(d[34]=f("span",{class:"spm-control-desc",style:{display:"block","margin-top":"4px","font-size":"11px",opacity:"0.8"}}," 默认伺服地址为 http://127.0.0.1:6806。开启后点击块链接将在 Webview 抽屉中打开，点击抽屉顶部『外跳』可在外部浏览器打开 ",-1))])):Te("",!0)]),f("div",P0,[f("div",O0,[f("div",R0,[f("div",N0,[ae(fe,{name:"type"}),d[35]||(d[35]=f("span",null,"固定特定标题大小",-1))]),d[36]||(d[36]=f("span",{class:"spm-control-desc"},"除封面外页首标题按 H2、多栏内首标题按 H3 大小展示",-1))]),f("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":he(i).normalizeHeadingSizes?"关闭固定特定标题大小":"开启固定特定标题大小"},[f("input",{type:"checkbox",checked:he(i).normalizeHeadingSizes,onChange:d[12]||(d[12]=h=>o(h.target.checked))},null,40,H0),d[37]||(d[37]=f("span",{class:"spm-switch-slider"},null,-1))],8,z0)])]),f("div",F0,[f("div",j0,[f("div",W0,[f("div",U0,[ae(fe,{name:"list"}),d[38]||(d[38]=f("span",null,"列表前缀标记",-1))]),d[39]||(d[39]=f("span",{class:"spm-control-desc"},"分别控制正文中无序列表圆点与有序列表数字序号的呈现",-1))])]),f("div",V0,[f("div",G0,[d[41]||(d[41]=f("span",{style:{"font-size":"12px",color:"var(--b3-theme-on-surface)"}},"无序圆点",-1)),f("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":he(i).showUnorderedListMarkers?"关闭无序列表圆点显示":"开启无序列表圆点显示"},[f("input",{type:"checkbox",checked:he(i).showUnorderedListMarkers,onChange:d[13]||(d[13]=h=>a(h.target.checked))},null,40,q0),d[40]||(d[40]=f("span",{class:"spm-switch-slider"},null,-1))],8,K0)]),f("div",Y0,[d[43]||(d[43]=f("span",{style:{"font-size":"12px",color:"var(--b3-theme-on-surface)"}},"有序序号",-1)),f("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":he(i).showOrderedListMarkers?"关闭有序列表序号显示":"开启有序列表序号显示"},[f("input",{type:"checkbox",checked:he(i).showOrderedListMarkers,onChange:d[14]||(d[14]=h=>r(h.target.checked))},null,40,J0),d[42]||(d[42]=f("span",{class:"spm-switch-slider"},null,-1))],8,Z0)])])]),f("div",X0,[d[51]||(d[51]=f("div",{class:"spm-control-header"},[f("div",{class:"spm-control-title-group"},[f("span",{class:"spm-control-title"},"演示全局操作")])],-1)),f("div",Q0,[f("button",{class:"spm-btn-action b3-tooltips b3-tooltips__sw","aria-label":"在当前文档下方开启分屏同步预览 (Alt+P)",onClick:d[15]||(d[15]=h=>u.$emit("openBottomPreview"))},[ae(fe,{name:"split-preview"}),d[44]||(d[44]=f("span",null,"分屏预览",-1))]),he($t)("presenterMode")?(J(),te("button",{key:0,class:"spm-btn-action b3-tooltips b3-tooltips__sw","aria-label":"打开双屏演讲者控制台视窗 (Alt+M)",onClick:d[16]||(d[16]=h=>u.$emit("openPresenter"))},[ae(fe,{name:"presenter"}),d[45]||(d[45]=f("span",null,"演讲者视图",-1))])):Te("",!0),f("button",{class:"spm-btn-action b3-tooltips b3-tooltips__sw","aria-label":"识别各页分隔线前未设属性的提示块/引用块为标准讲稿备注",disabled:e.isBatchProcessing,onClick:d[17]||(d[17]=h=>u.$emit("identifyNotes"))},[ae(fe,{name:"notes"}),d[46]||(d[46]=f("span",null,"识别讲稿块",-1))],8,ek),f("button",{class:"spm-btn-action b3-tooltips b3-tooltips__sw","aria-label":"自动为正文各页标题及首块之外的后续内容块配置顺延 (+1) 逐步呈现动效",disabled:e.isBatchProcessing,onClick:d[18]||(d[18]=h=>u.$emit("autoAnimate"))},[ae(fe,{name:"step"}),d[47]||(d[47]=f("span",null,"智能动效",-1))],8,tk),he($t)("aiScript")?(J(),te("button",{key:1,class:"spm-btn-action b3-tooltips b3-tooltips__se","aria-label":"智能分析长文本结构并给出大纲分页插入建议",onClick:d[19]||(d[19]=h=>u.$emit("aiAutoSplit"))},[ae(fe,{name:"sparkles"}),d[48]||(d[48]=f("span",null,"AI 智能分页",-1))])):Te("",!0),he($t)("exportHtml")?(J(),te("button",{key:2,class:"spm-btn-action b3-tooltips b3-tooltips__sw","aria-label":"打包导出离线单文件 HTML 幻灯片",onClick:d[20]||(d[20]=h=>u.$emit("exportHtml"))},[ae(fe,{name:"export-html"}),d[49]||(d[49]=f("span",null,"导出 HTML",-1))])):Te("",!0),he($t)("exportPdf")?(J(),te("button",{key:3,class:"spm-btn-action b3-tooltips b3-tooltips__se","aria-label":"打印生成 16:9 高清演示 PDF 讲义",onClick:d[21]||(d[21]=h=>u.$emit("exportPdf"))},[ae(fe,{name:"export-pdf"}),d[50]||(d[50]=f("span",null,"导出 PDF",-1))])):Te("",!0),he($t)("exportImage")?(J(),te("button",{key:4,class:Ce(["spm-btn-action b3-tooltips b3-tooltips__s",{"is-loading":e.isExportingImages}]),disabled:e.isExportingImages,"aria-label":e.isExportingImages?"正在逐页导出高清图片包，请稍候...":"逐页导出高清图片包 (ZIP)",onClick:d[22]||(d[22]=h=>u.$emit("exportImages"))},[ae(fe,{name:"export-image"}),f("span",null,we(e.isExportingImages?"正在导出...":"导出图片"),1)],10,ik)):Te("",!0)])])]))}}),sk=/\.(?:png|jpe?g|gif|svg|webp|avif|ico|bmp|tiff?|mp4|webm|mp3|wav|ogg)$/i,ok=/\.(?:ts|js|mjs|cjs|jsx|tsx|vue|json|css|scss|less|html|py|rs|go|java|c|cpp|h|sh|bash|yaml|yml|toml)$/i;async function rk(e){const t=await Jl.loadAsync(e),i={},n=[];let s="",o="";const a=[];t.forEach((l,c)=>{!c.dir&&!l.startsWith("__MACOSX")&&!l.includes("node_modules/")&&a.push({path:l,file:c})});let r=a.find(l=>l.path.toLowerCase()==="slides.md");r||(r=a.find(l=>l.path.toLowerCase().endsWith("/slides.md"))),r||(r=a.find(l=>l.path.toLowerCase().endsWith(".md"))),r&&(s=await r.file.async("string"),o=r.path);for(const l of a){const c=l.path;if(c.toLowerCase().endsWith(".md")||ok.test(c)||c.includes("snippets/")){const u=await l.file.async("string");i[c]=u;const d=c.split("/");d.length>1&&(i[d.slice(1).join("/")]=u)}else if(sk.test(c)){const u=await l.file.async("uint8array"),d=c.split("/").pop()||c,h=typeof Blob<"u"?new Blob([u]):void 0;n.push({zipPath:c,fileName:d,data:u,blob:h})}}return{entryMarkdown:s,entryMarkdownPath:o,virtualFiles:i,assets:n}}function ak(e,t){if(Object.keys(t).length===0)return e;function i(s){const o=s.trim().replace(/^['"]|['"]$/g,""),a=o.split("/").pop()||o;if(t[o])return t[o];const r=o.replace(/^\.?\//,"");return t[r]?t[r]:t[a]?t[a]:null}function n(s){let o=s;return o=o.replace(/!\[(.*?)\]\((.*?)\)/g,(a,r,l)=>{const c=i(l);return c?`![${r}](${c})`:a}),o=o.replace(/\bsrc=["'](.*?)["']/gi,(a,r)=>{const l=i(r);return l?`src="${l}"`:a}),o}for(const s of e.slides)if(s.rawMarkdown=n(s.rawMarkdown),s.pageAttrs["custom-slides-background"]){const o=s.pageAttrs["custom-slides-background"],a=i(o);a&&(s.pageAttrs["custom-slides-background"]=a)}if(e.flattenedMarkdown=n(e.flattenedMarkdown),e.docRootAttrs["custom-slides-background"]){const s=e.docRootAttrs["custom-slides-background"],o=i(s);o&&(e.docRootAttrs["custom-slides-background"]=o)}return e}function oc(e){try{if(typeof process<"u"&&typeof require<"u"){const t=require("fs");if(t.existsSync(e))return t.readFileSync(e,"utf-8")}}catch{}return null}function lk(e,t){const i=e.match(/^[ \t]*<<<[ \t]+([^\s]+)/);if(!i)return null;const n=i[1].trim(),s=n.indexOf("#"),o=s!==-1?n.slice(0,s):n,a=s!==-1?n.slice(s+1):"",r=o.replace(/^@\//,"").replace(/^\.\//,""),l=(t==null?void 0:t.virtualFiles)||{};let c=l[o]||l[r]||l[`./${r}`]||l[`@/${r}`];if(!c&&Object.keys(l).length>0){const p=r.split("/").pop();for(const[b,m]of Object.entries(l))if(b.endsWith(`/${r}`)||p&&b.endsWith(`/${p}`)){c=m;break}}if(!c){const p=[];if(t!=null&&t.baseDir)try{const b=require("path");p.push(b.resolve(t.baseDir,r)),p.push(b.resolve(t.baseDir,o))}catch{}try{const b=require("path");p.push(b.resolve(process.cwd(),r))}catch{}for(const b of p){const m=oc(b);if(m!==null){c=m;break}}}if(!c){const p=Fl||{};if(c=p[o]||p[r]||p[`snippets/${r}`],!c){const b=r.split("/").pop();for(const[m,y]of Object.entries(p))if(m.endsWith(`/${r}`)||b&&m.endsWith(`/${b}`)){c=y;break}}}if(!c)return null;let u=c;if(a){const p=new RegExp(`(?:\\/\\/|\\/\\*|#)?\\s*#(?:region|REGION)\\s+${a}[^\\r\\n]*\\r?\\n([\\s\\S]*?)(?:\\/\\/|\\/\\*|#)?\\s*#(?:endregion|ENDREGION)\\s+${a}`,"i"),b=c.match(p);if(b){const m=c.match(/^(\/\/\s*Inside[^\r\n]+\r?\n)/i);u=(m?m[1]:"")+b[1].trimEnd()}}const d=r.match(/\.([a-zA-Z0-9]+)$/);return`\`\`\`${d?d[1]:""}
${u}
\`\`\``}function ck(e){let t=!1,i=!1;for(let n=0;n<e.length;n++){const s=e[n];if(s==="'"&&!i)t=!t;else if(s==='"'&&!t)i=!i;else if(s==="#"&&!t&&!i)return e.slice(0,n).trim()}return e.trim()}function gs(e){const t={},i=e.split(/\r?\n/);let n=0;for(;n<i.length;){const s=i[n],o=s.trim();if(!o||o.startsWith("#")){n++;continue}const a=s.indexOf(":");if(a>0){const r=s.slice(0,a).trim();let l=s.slice(a+1).trim();if(l==="|"||l===">"){n++;const c=[];let u=-1;for(;n<i.length;){const d=i[n];if(!d.trim()){c.push(""),n++;continue}const p=d.match(/^(\s+)/),b=p?p[1].length:0;if(u===-1&&(u=b),b<u)break;c.push(d.slice(u)),n++}for(;c.length>0&&c[c.length-1]==="";)c.pop();t[r]=l===">"?c.join(" "):c.join(`
`);continue}if(l=ck(l),!l){let c=n+1;const u=[];let d=-1;for(;c<i.length;){const h=i[c],p=h.trim();if(!p||p.startsWith("#")){d!==-1&&u.push(""),c++;continue}const b=h.match(/^(\s+)/),m=b?b[1].length:0;if(d===-1)if(m>0)d=m;else break;if(m<d)break;u.push(h.slice(d)),c++}if(u.length>0){t[r]=gs(u.join(`
`)),n=c;continue}}l.startsWith('"')&&l.endsWith('"')||l.startsWith("'")&&l.endsWith("'")?l=l.slice(1,-1):l==="true"?l=!0:l==="false"?l=!1:l==="null"?l=null:/^-?\d+(?:\.\d+)?$/.test(l)&&(l=Number(l)),t[r]=l}n++}return t}const dk=/^\s*```ya?ml([\s\S]*?)```/;function pa(e){let t={},i=e.trim();const n=i.match(/^---[^\n\r]*\r?\n([\s\S]*?)\r?\n---(?=[ \t]*(?:\r?\n|$))/);if(n&&!n[1].includes("```")){const o=gs(n[1]);if(Object.keys(o).length>0||!n[1].trim())return t=o,i=i.slice(n[0].length).trim(),{frontmatter:t,content:i}}if(i.startsWith("---")){const o=i.match(/^---[^\n\r]*(?:\r?\n|$)/);o&&(i=i.slice(o[0].length).trim())}const s=i.match(dk);if(s)t=gs(s[1]),i=i.slice(s[0].length).trim();else{const o=i.split(/\r?\n/),a=[];let r=0;for(let l=0;l<o.length;l++){const c=o[l].trim();if(!c){if(a.length>0){r=l+1;break}continue}if(/^[a-zA-Z0-9_-]+\s*:\s*.*/.test(c)&&!c.startsWith("<")&&!c.startsWith("#"))a.push(c);else{r=l;break}}a.length>0&&(t=gs(a.join(`
`)),i=o.slice(r).join(`
`).trim())}return{frontmatter:t,content:i}}function uk(e){const t=e.split(/\r?\n/),i=[];let n=0,s=!1;function o(a){if(n>=a)return;const r=t.slice(n,a).join(`
`).trim();r&&i.push(r),n=a+1}for(let a=0;a<t.length;a++){const l=t[a].trimEnd();if(s){l.includes("-->")&&(s=!1);continue}if(l.startsWith("<!--")){l.includes("-->")||(s=!0);continue}if(l.startsWith("---")){o(a);const c=t[a+1];let u=!1,d=-1;const h=c?c.trim():"";if(l.replace(/^-+/,"").trim()===""&&h.length>0){for(let p=a+1;p<t.length;p++){const b=t[p].trimEnd();if(b.startsWith("```"))break;if(b==="---"){d=p;break}}d!==-1&&d-a<=60&&t.slice(a+1,d).some(m=>{const y=m.trim();return y.length>0&&!y.startsWith("#")&&/^[a-zA-Z0-9_$-]+\s*:\s*.*/.test(y)})&&(u=!0)}u&&d!==-1&&(n=a,a=d)}else if(l.trimStart().startsWith("```")){const c=l.match(/^\s*`+/),u=c?c[0].trim():"```";let d=a+1;for(;d<t.length&&!t[d].trimStart().startsWith(u);d++);d<t.length&&(a=d)}}return n<t.length&&o(t.length),i}function vs(e,t={}){const{stripNotesFromMarkdown:i=!0,cleanVClicks:n=!0,cleanShikiLines:s=!0,cleanSlots:o=!0,isolateStyleTags:a=!0,cleanHtmlToMarkdown:r=!0,wrapSuperBlocks:l=!0,virtualFiles:c={}}=t;let u=e;u&&!u.trimStart().startsWith("---")&&(u=`---

${u.trimStart()}`);const d=uk(u),h={};let p="",b="",m=0;if(d.length>0){const N=d[0],K=pa(N),$=Object.keys(K.frontmatter).length>0,V=K.content.length>0;$&&!V&&d.length>1?(m=1,y(K.frontmatter)):$&&y(K.frontmatter)}function y(N){p=N.title||"",N.theme&&(h[Nn]=String(N.theme)),N.aspectRatio&&(h[zn]=String(N.aspectRatio)),N.highlighter&&(h[Sa]=String(N.highlighter)),N.transition&&(h[Hn]=String(N.transition)),N.colorSchema&&(h[Ca]=String(N.colorSchema)),N.layout&&(h[ke]=String(N.layout)),N.background&&(h[st]=String(N.background)),N.image&&(h[Ot]=String(N.image)),N.class&&(h[Qi]=String(N.class));for(const[K,$]of Object.entries(N))["theme","aspectRatio","highlighter","transition","colorSchema","title","layout","background","image","class"].includes(K)||(h[`custom-slides-${K}`]=typeof $=="object"?JSON.stringify($):String($))}const g=[];let w=0,S=0,x=0,M=0;const E=new Set,C={};let D=1;for(let N=m;N<d.length;N++){const K=d[N],{frontmatter:$,content:V}=pa(K),k=K.match(/^\s*(?:---\s*)?src:\s*([^\n\r]+)/m),F=$.src||(k?k[1]:void 0);if(F){const pe=String(F).trim().replace(/^['"]|['"]$/g,"");let X=c[pe]||c[pe.replace(/^\.\//,"")]||c[`pages/${pe.replace(/^.*pages\//,"")}`];if(!X){const L=pe.replace(/^\.\//,""),j=[];if(t.baseDir)try{const v=require("path");j.push(v.resolve(t.baseDir,L)),j.push(v.resolve(t.baseDir,pe))}catch{}try{const v=require("path");j.push(v.resolve(process.cwd(),L)),j.push(v.resolve(process.cwd(),pe))}catch{}for(const v of j){const U=oc(v);if(U!==null){X=U;break}}}const Q={};$.layout&&(Q[ke]=String($.layout)),$.transition&&(Q[gt]=String($.transition)),$.background&&(Q[st]=String($.background)),$.image&&(Q[Ot]=String($.image)),$.class&&(Q[Qi]=String($.class));for(const[L,j]of Object.entries($))["src","layout","transition","background","image","class"].includes(L)||(Q[`custom-slides-${L}`]=typeof j=="object"?JSON.stringify(j):String(j));if(X){const L=vs(X,{...t,virtualFiles:c});for(const j of L.slides){j.pageIndex=D++,j.pageAttrs={...Q,...j.pageAttrs},g.push(j);const v=j.pageAttrs[ke]||"default";C[v]=(C[v]||0)+1}continue}else{g.push({pageIndex:D++,pageAttrs:{...Q,"custom-slides-src":pe},notes:"",rawMarkdown:`> 📄 **引入外部幻灯片页面**: \`${pe}\`
>
> *提示：如需展示该页面完整内容，请将关联子页面一同打包为 .zip 或通过本地工程导入。*`,hasVueComponent:!1,hasStyleTag:!1,assetReferences:[]});const L=Q[ke]||"default";C[L]=(C[L]||0)+1;continue}}const H={};$.layout&&(H[ke]=String($.layout)),$.transition&&(H[gt]=String($.transition)),$.background&&(H[st]=String($.background)),$.image&&(H[Ot]=String($.image)),$.class&&(H[Qi]=String($.class)),$.mask&&(H[en]=String($.mask)),($.maskRatio||$["mask-ratio"])&&(H[Fi]=String($.maskRatio||$["mask-ratio"])),($.maskStyle||$["mask-style"])&&(H[tn]=String($.maskStyle||$["mask-style"])),($.maskInitial||$["mask-initial"])&&(H[nn]=String($.maskInitial||$["mask-initial"]));for(const[pe,X]of Object.entries($))["layout","transition","background","image","class","mask","maskRatio","mask-ratio","maskStyle","mask-style","maskInitial","mask-initial"].includes(pe)||(H[`custom-slides-${pe}`]=typeof X=="object"?JSON.stringify(X):String(X));let I=V;const A=[];let O=I.replace(/(?:^[ \t]*(`{3,}|~{3,})[^\n\r]*\r?\n[\s\S]*?\r?\n[ \t]*\1(?=[ \t]*(?:\r?\n|$)))/gm,pe=>{const X=`__CODE_TOKEN_NOTE_${A.length}__`;return A.push(pe),X});O=O.replace(/(`+)(?:[^\n\r`]|(?!\1)`)+?\1/g,pe=>{const X=`__CODE_TOKEN_NOTE_${A.length}__`;return A.push(pe),X});let ne="";const G=Array.from(O.matchAll(/<!--([\s\S]*?)-->/g));if(G.length>0){const pe=G[G.length-1],X=O.slice(pe.index+pe[0].length).trim();if(!X||!X.replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi,"").trim()){const L=pe[1].trim();L.startsWith("TODO:")||(ne=L,w++),i&&(O=O.slice(0,pe.index).trimEnd()+O.slice(pe.index+pe[0].length))}}i&&(O=O.replace(/<!--(?![\s\S]*?TODO:)[\s\S]*?-->/g,"").trim());for(let pe=0;pe<A.length;pe++)O=O.replace(`__CODE_TOKEN_NOTE_${pe}__`,()=>A[pe]);if(I=O,ne){for(let Q=0;Q<A.length;Q++)ne=ne.replace(`__CODE_TOKEN_NOTE_${Q}__`,()=>A[Q]);const X=`> [!NOTE] 💡 演讲备注
${ne.split(/\r?\n/).map(Q=>`> ${Q}`).join(`
`)}
{: custom-slides-note="true"}`;I=I?`${I}

${X}`:X}let q=!1;if(/<style\b/i.test(I)){q=!0;const pe=I.match(/<style\b[^>]*>([\s\S]*?)<\/style>/gi);if(pe){for(const X of pe){const Q=X.replace(/<style\b[^>]*>|<\/style>/gi,"").trim();b=b?`${b}

${Q}`:Q}a&&(I=I.replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi,"").trim())}}const ce=I.match(/<v-click[^>]*>|<v-clicks[^>]*>|v-click=/g);ce&&(S+=ce.length);const se=I.match(/```\w+\s+\{[^}]+\}/g);se&&(x+=se.length);const re=I.match(/::\w+::|<template\s+#[^>]+>/g);if(re&&(M+=re.length),I=I.replace(/^[ \t]*<<<[ \t]+([^\n\r]+)/gm,pe=>lk(pe,{...t,virtualFiles:c})||pe),n&&(I=I.replace(/<v-click(?:\s+at="[^"]*")?(?:\s+hide)?>\s*([\s\S]*?)\s*<\/v-click>/gi,"$1")),s&&(I=I.replace(/(^```\w+(?:[ \t]+\[[^\]]*\])?)[ \t]+\{[^}]+\}(?:[ \t]+\w+)?/gm,"$1"),I=I.replace(/^\$\$\s+\{[^}]+\}/gm,()=>"$$")),o&&(I=I.replace(/^::\w+::\s*$/gm,"")),r&&(I=Qf(I)),l){let pe=I.trim(),X="";const Q=pe.lastIndexOf("> [!NOTE] 💡 演讲备注");if(Q!==-1&&(X=pe.slice(Q),pe=pe.slice(0,Q).trim()),($.layout==="image-left"||$.layout==="image-right")&&$.image){const L=String($.image).trim(),j=$.layout==="image-left"?"image-left":"image-right",v=`![配图](${L})
{: custom-slides-layout="${j}" }`;$.layout==="image-left"?pe=`{{{col

${v}

${pe}

}}}`:pe=`{{{col

${pe}

${v}

}}}`}if($.background){const j=`![背景图](${String($.background).trim()})
{: custom-slides-role="background" }`;pe=pe?`${j}

${pe}`:j}I=X?`${pe}

${X}`:pe}const Se=fk(I);H[st]&&Se.push(H[st]),H[Ot]&&Se.push(H[Ot]);for(const pe of Se)E.add(pe);const Ie=/<[A-Z][a-zA-Z0-9]+/.test(I),_e=H[ke]||(D===1?h[ke]||"cover":"default");C[_e]=(C[_e]||0)+1,g.push({pageIndex:D++,pageAttrs:H,notes:ne,rawMarkdown:I,hasVueComponent:Ie,hasStyleTag:q,assetReferences:Se})}if(!p&&g.length>0){const N=g[0].rawMarkdown.match(/^#\s+(.+)$/m);N&&(p=N[1].trim())}b&&(h["custom-slides-custom-css"]=b);let R=g.map(N=>`---

${N.rawMarkdown}`).join(`

`);return R.trimStart().startsWith("---")||(R=`---

${R.trimStart()}`),{docTitle:p||"Slidev 演示文稿",docRootAttrs:h,slides:g,totalSlides:g.length,stats:{totalNotes:w,totalVClicks:S,totalShikiHighlights:x,totalSlots:M,discoveredAssets:Array.from(E),layoutDistribution:C},flattenedMarkdown:R,customCss:b}}function fk(e){const t=[],i=/!\[.*?\]\((.*?)\)/g;let n;for(;(n=i.exec(e))!==null;){const o=n[1].split(/\s+/)[0].trim();o&&t.push(o)}const s=/<(?:img|video|source|audio)\b[^>]*src=["'](.*?)["']/gi;for(;(n=s.exec(e))!==null;){const o=n[1].trim();o&&t.push(o)}return t}function rc(e){if(!e)return!1;const t=String(e.type||"").toLowerCase(),i=String(e.markdown||"").trim(),n=String(e.content||"").trim();return t==="tb"||t==="thematic-break"||t==="nodethematicbreak"||i==="---"||i==="***"||n==="---"||n==="***"}function pk(e){return(e.trim()||"Slidev 演示文稿").replace(/[\\/:*?"<>|]/g,"_")}async function hk(e,t,i=He){const n=e.filter(rc);let s=0;if(n.length>=t.length)for(let o=0;o<t.length;o++){const a=t[o],r=n[o];r&&r.id&&Object.keys(a.pageAttrs||{}).length>0&&(await i(r.id,a.pageAttrs),s++)}else for(let o=1;o<t.length;o++){const a=t[o],r=n[o-1];r&&r.id&&Object.keys(a.pageAttrs||{}).length>0&&(await i(r.id,a.pageAttrs),s++)}return s}async function mk(e,t=He){let i=!1,n=0;for(const s of e){if(rc(s)){i=!1;continue}const o=(s.markdown||s.content||"").trim();if(o==="::right::"||o.startsWith("::right::")){i=!0;continue}i&&s.id&&(await t(s.id,{[Me]:"right"}).catch(()=>{}),n++)}return n}async function gk(e,t,i=ba){const n={};if(!t||t.length===0)return n;const s=[];for(const o of t){const a=new File([o.data],o.fileName,{type:"application/octet-stream"});s.push(a)}try{const o=await i("/data/assets",s);if(o!=null&&o.succMap)for(const[a,r]of Object.entries(o.succMap))n[a]=String(r)}catch(o){console.warn("上传本地静态资产失败，保留原路径:",o)}return Object.keys(n).length>0&&ak(e,n),n}async function vk(e){var w;const{presentation:t,notebookId:i,docTitle:n,extractedAssets:s=[],uploadAssets:o=!0,autoPreview:a=!0,plugin:r,api:l={}}=e,c=l.uploadFn||ba,u=l.createDocFn||cd,d=l.setAttrsFn||He,h=l.getChildBlocksFn||Yn,p=l.openTabFn||de.openTab,b=l.showMessageFn||de.showMessage;o&&s.length>0&&await gk(t,s,c);const m=pk(n),y=`/${m}`,g=await u(i,y,t.flattenedMarkdown);if(!g)throw new Error("思源内核创建文档失败，未返回有效 DocumentId");try{const S=((w=t.slides[0])==null?void 0:w.pageAttrs)||{};await d(g,{...S,...t.docRootAttrs});const x=await h(g).catch(()=>[]);Array.isArray(x)&&x.length>0&&(await hk(x,t.slides,d),await mk(x,d))}catch(S){console.warn("[SlidesImport] 版式属性回填阶段遇到警告:",S),b(`⚠️ 文档已创建(${m})，但部分版式属性回填未完全完成: ${S.message||String(S)}`,6e3)}return b(`🎉 成功导入 Slidev 演示文档《${m}》！`),a&&r&&(r.currentDocId=g,await p({app:r.app,doc:{id:g}}),r.openBottomPreviewTab&&r.openBottomPreviewTab()),g}function bk(e){const t=ge("file"),i=ge(!1),n=ge(!1),s=ge(""),o=ge(null),a=ge(null),r=ge(""),l=ge(0),c=ge(""),u=ge([]),d=ge(null),h=ge(""),p=ge([]),b=ge(""),m=ge(!0),y=ge(!0),g=ge(!0),w=ge(!0),S=ye(()=>{const I=l.value;if(I===0)return"0 B";const A=1024,O=["B","KB","MB","GB"],ne=Math.floor(Math.log(I)/Math.log(A));return`${(I/A**ne).toFixed(1)} ${O[ne]}`}),x=ye(()=>{var I;return((I=d.value)==null?void 0:I.docRootAttrs["custom-slides-theme"])||"default"}),M=ye(()=>{var I;return u.value.length>0?u.value.length:((I=d.value)==null?void 0:I.stats.discoveredAssets.length)||0}),E=ye(()=>{var A;const I=((A=d.value)==null?void 0:A.stats.layoutDistribution)||{};return Object.entries(I).map(([O,ne])=>({name:O,count:ne}))});async function C(I=ld){try{const A=await I();A!=null&&A.notebooks&&Array.isArray(A.notebooks)&&(p.value=A.notebooks.filter(O=>!O.closed),p.value.length>0&&!b.value&&(b.value=p.value[0].id))}catch(A){console.warn("获取笔记本列表失败:",A)}}function D(){var I;(I=o.value)==null||I.click()}function R(){a.value=null,r.value="",l.value=0,d.value=null,u.value=[],s.value=""}let N=0;async function K(I){const A=++N;s.value="",a.value=I,r.value=I.name,l.value=I.size;try{if(I.name.toLowerCase().endsWith(".zip")){const ne=await I.arrayBuffer();if(A!==N)return;const G=await rk(ne);if(A!==N)return;if(!G.entryMarkdown){s.value="未在 Zip 压缩包中找到 slides.md 或任何有效的 Markdown 入口文件";return}u.value=G.assets;const q=vs(G.entryMarkdown,{stripNotesFromMarkdown:y.value,cleanHtmlToMarkdown:m.value,cleanSlots:!1,virtualFiles:G.virtualFiles});if(A!==N)return;d.value=q,h.value=q.docTitle||I.name.replace(/\.zip$/i,"")}else{const ne=await I.text();if(A!==N)return;u.value=[];const G=I.path||"",q=G?G.replace(/[\\/][^\\/]+$/,""):"",ce=vs(ne,{stripNotesFromMarkdown:y.value,cleanHtmlToMarkdown:m.value,cleanSlots:!1,baseDir:q||void 0});if(A!==N)return;d.value=ce,h.value=ce.docTitle||I.name.replace(/\.md$/i,"")}}catch(O){if(A!==N)return;console.error("解析文件失败:",O),s.value=`解析文件失败: ${O.message||String(O)}`}}function $(){if(s.value="",!c.value.trim()){d.value=null;return}try{const I=vs(c.value,{stripNotesFromMarkdown:y.value,cleanHtmlToMarkdown:m.value,cleanSlots:!1});d.value=I,h.value=I.docTitle||"Slidev 演示文稿"}catch(I){s.value=`解析 Markdown 源码失败: ${I.message||String(I)}`}}async function V(){a.value?await K(a.value):c.value&&$()}async function k(I){const A=I.target;A.files&&A.files[0]&&await K(A.files[0])}async function F(I){var A;i.value=!1,(A=I.dataTransfer)!=null&&A.files&&I.dataTransfer.files[0]&&await K(I.dataTransfer.files[0])}async function H(I=e){if(d.value){if(!b.value&&p.value.length>0&&(b.value=p.value[0].id),!b.value){s.value="请先选择目标笔记本";return}n.value=!0,s.value="";try{return await vk({presentation:d.value,notebookId:b.value,docTitle:h.value,extractedAssets:u.value,uploadAssets:g.value,autoPreview:w.value,plugin:I})}catch(A){console.error("导入 Slidev 演示失败:",A),s.value=`导入执行失败: ${A.message||String(A)}`}finally{n.value=!1}}}return{inputMode:t,isDragging:i,isImporting:n,errorMessage:s,fileInputRef:o,selectedFile:a,selectedFileName:r,selectedFileSize:l,rawMarkdownText:c,extractedAssets:u,parsedPresentation:d,customDocTitle:h,notebooks:p,selectedNotebookId:b,optCleanHtml:m,optStripNotes:y,optUploadAssets:g,optAutoPreview:w,formattedFileSize:S,currentTheme:x,extractedAssetsCount:M,layoutChips:E,fetchNotebooks:C,triggerFileInput:D,clearFile:R,processFile:K,onFileSelected:k,onFileDrop:F,onTextChange:$,reprocessCurrentInput:V,handleConfirmImport:H}}const yk={class:"spm-import-dialog"},kk={class:"spm-tabs-header"},wk={class:"spm-dialog-body"},xk={key:0,class:"spm-file-section"},Sk={key:0,class:"spm-dropzone-prompt"},Ck={class:"spm-dropzone-icon"},_k={key:1,class:"spm-dropzone-active"},$k={class:"spm-file-badge"},Ik={class:"spm-file-size"},Mk={key:1,class:"spm-text-section"},Tk={key:2,class:"spm-error-banner"},Ek={key:3,class:"spm-preview-card"},Ak={class:"spm-preview-card__header"},Bk={style:{display:"inline-flex","align-items":"center",gap:"4px"}},Dk={class:"spm-config-grid"},Lk={class:"spm-form-item"},Pk={class:"spm-form-item"},Ok=["value"],Rk={class:"spm-stats-grid"},Nk={class:"spm-stat-box"},zk={class:"spm-stat-value"},Hk={class:"spm-stat-box"},Fk={class:"spm-stat-value"},jk={class:"spm-stat-box"},Wk={class:"spm-stat-value"},Uk={class:"spm-stat-box"},Vk={class:"spm-stat-value"},Gk={key:0,class:"spm-chips-row"},Kk={class:"spm-options-group"},qk={class:"spm-checkbox-label"},Yk={class:"spm-checkbox-label"},Zk={class:"spm-checkbox-label"},Jk={class:"spm-checkbox-label"},Xk={class:"spm-dialog-footer"},Qk=["disabled"],ew=["disabled"],tw={key:0,style:{display:"inline-flex","align-items":"center",gap:"4px"}},iw={key:1,style:{display:"inline-flex","align-items":"center",gap:"4px"}},nw=Bt({__name:"SlidesImportDialog",emits:["close","success"],setup(e,{emit:t}){const i=t,n=Nt("plugin"),{inputMode:s,isDragging:o,isImporting:a,errorMessage:r,fileInputRef:l,selectedFileName:c,rawMarkdownText:u,extractedAssetsCount:d,parsedPresentation:h,customDocTitle:p,notebooks:b,selectedNotebookId:m,optCleanHtml:y,optStripNotes:g,optUploadAssets:w,optAutoPreview:S,formattedFileSize:x,currentTheme:M,layoutChips:E,fetchNotebooks:C,triggerFileInput:D,clearFile:R,onFileSelected:N,onFileDrop:K,onTextChange:$,reprocessCurrentInput:V,handleConfirmImport:k}=bk(n);vn(async()=>{await C()});async function F(){const I=await k();I&&(i("success",{docId:I}),i("close"))}function H(){i("close")}return(I,A)=>(J(),te("div",{class:"spm-modal-overlay",onClick:Yt(H,["self"])},[f("div",yk,[f("div",{class:"spm-dialog-header"},[A[18]||(A[18]=f("div",{class:"spm-dialog-title"},[f("svg",{class:"spm-dialog-icon","aria-hidden":"true"},[f("use",{"xlink:href":"#iconSlides"})]),f("span",null,"导入 Slidev 演示文档")],-1)),f("button",{class:"spm-close-btn",title:"关闭",onClick:H},"✕")]),f("div",kk,[f("button",{class:Ce(["spm-tab-btn",{active:he(s)==="file"}]),onClick:A[0]||(A[0]=O=>s.value="file")},[ae(fe,{name:"package"}),A[19]||(A[19]=f("span",null,"文件 / 压缩包导入 (.zip / .md)",-1))],2),f("button",{class:Ce(["spm-tab-btn",{active:he(s)==="text"}]),onClick:A[1]||(A[1]=O=>s.value="text")},[ae(fe,{name:"notes"}),A[20]||(A[20]=f("span",null,"粘贴 Markdown 源码",-1))],2)]),f("div",wk,[he(s)==="file"?(J(),te("div",xk,[f("div",{class:Ce(["spm-dropzone",{dragover:he(o),"has-file":!!he(c)}]),onDragover:A[4]||(A[4]=Yt(O=>o.value=!0,["prevent"])),onDragleave:A[5]||(A[5]=Yt(O=>o.value=!1,["prevent"])),onDrop:A[6]||(A[6]=Yt((...O)=>he(K)&&he(K)(...O),["prevent"])),onClick:A[7]||(A[7]=(...O)=>he(D)&&he(D)(...O))},[f("input",{ref_key:"fileInputRef",ref:l,type:"file",accept:".zip,.md",class:"spm-hidden-input",onChange:A[2]||(A[2]=(...O)=>he(N)&&he(N)(...O))},null,544),he(c)?(J(),te("div",_k,[f("span",$k,[ae(fe,{name:"notes"}),_t(" "+we(he(c)),1)]),f("span",Ik,"("+we(he(x))+")",1),f("button",{class:"spm-btn-text",onClick:A[3]||(A[3]=Yt((...O)=>he(R)&&he(R)(...O),["stop"]))},"更换文件")])):(J(),te("div",Sk,[f("span",Ck,[ae(fe,{name:"folder",style:{"font-size":"32px"}})]),A[21]||(A[21]=f("p",{class:"spm-dropzone-text"},"点击选择文件，或直接拖拽文件至此处",-1)),A[22]||(A[22]=f("p",{class:"spm-dropzone-hint"},[_t(" 支持 Slidev 完整工程 "),f("strong",null,".zip"),_t("（自动解包 public/ 静态素材）或单文件 "),f("strong",null,".md")],-1))]))],34)])):(J(),te("div",Mk,[Pt(f("textarea",{"onUpdate:modelValue":A[8]||(A[8]=O=>tt(u)?u.value=O:null),class:"spm-textarea spm-source-editor",rows:"8",placeholder:"在此直接粘贴包含 Frontmatter 的 Slidev slides.md 源码...",onInput:A[9]||(A[9]=(...O)=>he($)&&he($)(...O))},null,544),[[Lo,he(u)]])])),he(r)?(J(),te("div",Tk," ⚠️ "+we(he(r)),1)):Te("",!0),he(h)?(J(),te("div",Ek,[f("div",Ak,[f("span",Bk,[ae(fe,{name:"sparkles"}),A[23]||(A[23]=_t(" 演示解析摘要",-1))]),A[24]||(A[24]=f("span",{class:"spm-badge-success"},"预检就绪",-1))]),f("div",Dk,[f("div",Lk,[A[25]||(A[25]=f("label",{class:"spm-form-label"},"笔记文档标题",-1)),Pt(f("input",{"onUpdate:modelValue":A[10]||(A[10]=O=>tt(p)?p.value=O:null),class:"spm-input",placeholder:"思源新文档标题"},null,512),[[Lo,he(p)]])]),f("div",Pk,[A[26]||(A[26]=f("label",{class:"spm-form-label"},"存放目标笔记本",-1)),Pt(f("select",{"onUpdate:modelValue":A[11]||(A[11]=O=>tt(m)?m.value=O:null),class:"spm-select"},[(J(!0),te(Xe,null,xt(he(b),O=>(J(),te("option",{key:O.id,value:O.id},we(O.name),9,Ok))),128))],512),[[Lf,he(m)]])])]),f("div",Rk,[f("div",Nk,[f("span",zk,we(he(h).totalSlides),1),A[27]||(A[27]=f("span",{class:"spm-stat-label"},"幻灯片页数",-1))]),f("div",Hk,[f("span",Fk,we(he(M)),1),A[28]||(A[28]=f("span",{class:"spm-stat-label"},"演示主题",-1))]),f("div",jk,[f("span",Wk,we(he(h).stats.totalNotes),1),A[29]||(A[29]=f("span",{class:"spm-stat-label"},"演讲者提词",-1))]),f("div",Uk,[f("span",Vk,we(he(d)),1),A[30]||(A[30]=f("span",{class:"spm-stat-label"},"关联本地素材",-1))])]),he(E).length>0?(J(),te("div",Gk,[A[31]||(A[31]=f("span",{class:"spm-chips-label"},"页面版式分布：",-1)),(J(!0),te(Xe,null,xt(he(E),O=>(J(),te("span",{key:O.name,class:"spm-chip-badge"},we(O.name)+": "+we(O.count),1))),128))])):Te("",!0),f("div",Kk,[f("label",qk,[Pt(f("input",{"onUpdate:modelValue":A[12]||(A[12]=O=>tt(y)?y.value=O:null),type:"checkbox",onChange:A[13]||(A[13]=(...O)=>he(V)&&he(V)(...O))},null,544),[[as,he(y)]]),A[32]||(A[32]=f("span",null,"智能剥离展示型 HTML 容器为干净原生的 Markdown 笔记块",-1))]),f("label",Yk,[Pt(f("input",{"onUpdate:modelValue":A[14]||(A[14]=O=>tt(g)?g.value=O:null),type:"checkbox",onChange:A[15]||(A[15]=(...O)=>he(V)&&he(V)(...O))},null,544),[[as,he(g)]]),A[33]||(A[33]=f("span",null,"提取演讲者提词到块属性并保持正文笔记清爽",-1))]),f("label",Zk,[Pt(f("input",{"onUpdate:modelValue":A[16]||(A[16]=O=>tt(w)?w.value=O:null),type:"checkbox"},null,512),[[as,he(w)]]),A[34]||(A[34]=f("span",null,"自动上传关联素材至思源资产库并重写路径 (assets/...)",-1))]),f("label",Jk,[Pt(f("input",{"onUpdate:modelValue":A[17]||(A[17]=O=>tt(S)?S.value=O:null),type:"checkbox"},null,512),[[as,he(S)]]),A[35]||(A[35]=f("span",null,"导入后自动打开新文档并开启下方分屏放映预览",-1))])])])):Te("",!0)]),f("div",Xk,[f("button",{class:"spm-btn-secondary",disabled:he(a),onClick:H}," 取消 ",8,Qk),f("button",{class:"spm-btn-primary",disabled:!he(h)||he(a),onClick:F},[he(a)?(J(),te("span",tw,[ae(fe,{name:"refresh"}),A[36]||(A[36]=_t(" 正在导入生成中...",-1))])):(J(),te("span",iw,[ae(fe,{name:"rocket"}),A[37]||(A[37]=_t(" 确认导入思源笔记",-1))]))],8,ew)])])]))}}),sw=ti(nw,[["__scopeId","data-v-c56a3d7e"]]);function hr(e){return e?e==="NodeThematicBreak"||e==="tb"||e==="thematic-break":!1}function ow(e,t){var r;if(!e||e.length===0)return null;const i=t.activeBlockId||"",n=t.currentTopBlockId||i,s=t.currentPageDividerId||"",o=t.activeBlockType||"";if(hr(o)&&i){let l=e.find(c=>c.startBlockId===i);if(l||(l=e.find(c=>{var u,d;return((d=(u=c.blocks)==null?void 0:u[0])==null?void 0:d.id)===i}),l)||(l=e.find(c=>{var u;return(u=c.allBlockIds)==null?void 0:u.includes(i)}),l))return l}if(s){let l=e.find(c=>c.startBlockId===s);if(l||(l=e.find(c=>{var u,d;return((d=(u=c.blocks)==null?void 0:u[0])==null?void 0:d.id)===s}),l))return l}if(i){let l=e.find(u=>u.startBlockId===i);if(l||(l=e.find(u=>{var d,h;return((d=u.blocks)==null?void 0:d.some(p=>p.id===i))||((h=u.allBlockIds)==null?void 0:h.includes(i))}),l)||n&&n!==i&&(l=e.find(u=>{var d,h;return((d=u.blocks)==null?void 0:d.some(p=>p.id===n))||((h=u.allBlockIds)==null?void 0:h.includes(n))}),l)||(l=e.find(u=>{var d;return(d=u.noteBlocks)==null?void 0:d.some(h=>h.id===i||h.id===n)}),l))return l;const c=(r=t.activeBlockAttrs)==null?void 0:r[Me];if(c&&["col-1","col-2","col-3"].includes(c)&&(l=e.find(u=>{var d,h;return((d=u.frontmatter)==null?void 0:d.layout)==="three-cols-header"||((h=u.blocks)==null?void 0:h.some(p=>p.slot==="col-1"||p.slot==="col-2"||p.slot==="col-3"))}),l))return l}return e[0]||null}function et(e,t){var s;if(typeof document>"u"||!e)return;const i=(s=globalThis.CSS)!=null&&s.escape?globalThis.CSS.escape(e):e.replace(/"/g,'\\"'),n=document.querySelectorAll(`[data-node-id="${i}"]`);!n||n.length===0||n.forEach(o=>{for(const[a,r]of Object.entries(t))r!=null&&r!==""?o.setAttribute(a,String(r)):o.removeAttribute(a)})}function rw(e){if(typeof document>"u")return;const t=`.protyle-wysiwyg [${ke}], .protyle-wysiwyg [${Ze}], .protyle-wysiwyg [custom-slides-layout], .protyle-wysiwyg [custom-slides-role]`,i=document.querySelectorAll(t);!i||i.length===0||i.forEach(n=>{const s=n.getAttribute("data-node-id");if(!s){n.removeAttribute(ke),n.removeAttribute("custom-slides-layout"),n.removeAttribute(Ze),n.removeAttribute("custom-slides-role");return}const o=e.get(s),a=(o==null?void 0:o[ke])||(o==null?void 0:o["custom-slides-layout"])||"",r=n.getAttribute(ke)||n.getAttribute("custom-slides-layout");r&&r!==a&&(a?n.setAttribute(ke,a):(n.removeAttribute(ke),n.removeAttribute("custom-slides-layout")));const l=(o==null?void 0:o[Ze])||(o==null?void 0:o["custom-slides-role"])||"",c=n.getAttribute(Ze)||n.getAttribute("custom-slides-role");c&&c!==l&&(l?n.setAttribute(Ze,l):(n.removeAttribute(Ze),n.removeAttribute("custom-slides-role")))})}function aw(e,t){if(!t)return!1;if(e===t||typeof document>"u")return!0;const i=document.querySelector(`.protyle-wysiwyg [data-node-id="${t}"]`)||document.querySelector(`[data-node-id="${t}"]`);if(!i)return!1;const n=i.querySelector(":scope > [data-node-id], :scope > div > [data-node-id]");return(n==null?void 0:n.getAttribute("data-node-id"))===e}function lw(e){let t=null;function i(c="已同步"){e.saveStatus.value=c,t&&(typeof window<"u"?window.clearTimeout(t):clearTimeout(t));const u=()=>{e.saveStatus.value=""};typeof window<"u"?t=window.setTimeout(u,1200):t=setTimeout(u,1200)}async function n(c){var p;const u=e.activeBlockId.value||e.currentDocId.value;if(!u)return;for(const[b,m]of Object.entries(c))e.activeBlockAttrs.value[b]=m;Le.setBlockAttrOverride(u,c),et(u,c);const d=(p=e.parentContainerId)==null?void 0:p.value,h=!!(d&&aw(u,d));if(Re in c&&h&&d){const b=c[Re];e.parentContainerClicks&&(e.parentContainerClicks.value=b),Le.setBlockAttrOverride(d,{[Re]:b}),et(d,{[Re]:b}),He(d,{[Re]:b}).catch(()=>{})}if(ke in c){const b=c[ke];e.currentPageDividerLayout.value=b,e.targetSlide.value&&(e.targetSlide.value.frontmatter||(e.targetSlide.value.frontmatter={}),e.targetSlide.value.frontmatter.layout=b)}if(vt in c){const b=c[vt];e.targetSlide.value&&(e.targetSlide.value.frontmatter||(e.targetSlide.value.frontmatter={}),e.targetSlide.value.frontmatter.layoutRatio=b)}i("保存中...");try{await He(u,c),i("已同步"),e.plugin&&await e.plugin.compileCurrentDocument()}catch{i("同步失败")}}async function s(c,u){await n({[c]:u})}function o(){var u;return(e.activeBlockType.value==="NodeThematicBreak"||e.activeBlockType.value==="NodeThematicBreakBlock"||e.activeBlockType.value==="hr"||e.activeBlockType.value==="thematicbreak")&&e.activeBlockId.value?e.activeBlockId.value:e.currentPageDividerId.value?e.currentPageDividerId.value:(u=e.targetSlide.value)!=null&&u.startBlockId&&e.targetSlide.value.startBlockId!==e.currentDocId.value?e.targetSlide.value.startBlockId:e.currentDocId.value}async function a(c,u){const d=o();if(d){d===e.activeBlockId.value&&(e.activeBlockAttrs.value[c]=u),Le.setBlockAttrOverride(d,{[c]:u}),et(d,{[c]:u}),c===ke&&(e.currentPageDividerLayout.value=u,e.targetSlide.value&&(e.targetSlide.value.frontmatter||(e.targetSlide.value.frontmatter={}),e.targetSlide.value.frontmatter.layout=u)),c===vt&&e.targetSlide.value&&(e.targetSlide.value.frontmatter||(e.targetSlide.value.frontmatter={}),e.targetSlide.value.frontmatter.layoutRatio=u),i("保存中...");try{await He(d,{[c]:u}),i("已同步"),e.plugin&&await e.plugin.compileCurrentDocument()}catch{i("同步失败")}}}async function r(c,u){const d=o();if(!d)return;const h={[ke]:c,[vt]:u};d===e.activeBlockId.value&&(e.activeBlockAttrs.value[ke]=c,e.activeBlockAttrs.value[vt]=u),e.currentPageDividerLayout.value=c,Le.setBlockAttrOverride(d,h),et(d,h),e.targetSlide.value&&(e.targetSlide.value.frontmatter||(e.targetSlide.value.frontmatter={}),e.targetSlide.value.frontmatter.layout=c,e.targetSlide.value.frontmatter.layoutRatio=u),i("应用排版中...");try{await He(d,h),i("已应用分栏与比例"),e.plugin&&await e.plugin.compileCurrentDocument()}catch{i("应用失败")}}async function l(c,u){var h;const d=e.currentDocId.value||e.activeBlockId.value;if(d){e.activeBlockAttrs.value[c]=u,Le.setBlockAttrOverride(d,{[c]:u}),et(d,{[c]:u}),(h=e.latestDoc.value)!=null&&h.config&&(c===Nn&&(e.latestDoc.value.config.theme=u),c===zn&&(e.latestDoc.value.config.aspectRatio=u),c===Hn&&(e.latestDoc.value.config.defaultTransition=u)),i("更新中...");try{await He(d,{[c]:u}),i("已更新"),e.plugin&&await e.plugin.compileCurrentDocument(d)}catch{i("更新失败")}}}return{triggerSaveNotice:i,saveAttrs:n,saveAttr:s,getPageTargetBlockId:o,savePageAttr:a,applyPageLayoutAndRatio:r,saveDocAttr:l}}function ha(e){const t=(e.blocks||[]).filter(o=>{const a=(o.content||o.rawMarkdown||"").trim();return a&&a!=="---"});if(t.length===0)return"本页暂无内容，建议过渡承接上下文。";const i=[],n=[];for(const o of t){const a=(o.content||o.rawMarkdown||"").trim();a&&(o.type==="h"||a.startsWith("#")?i.push(a.replace(/^#+\s*/,"")):n.push(a.slice(0,50)))}const s=[];return i.length>0&&s.push(`【核心重点】：${i.join("、")}`),n.length>0&&(s.push("【口播要点】："),n.slice(0,3).forEach((o,a)=>{s.push(`${a+1}. 讲解 ${o}`)})),s.push("【过渡提示】：注意观察听众反应，适时抛出互动提问。"),s.join(`
`)}async function ac(e,t){const i=e.blocks&&e.blocks.length>0?e.blocks.map(n=>(n.content||n.rawMarkdown||"").trim()).filter(n=>n&&n!=="---").join(`
`):(e.rawMarkdown||"").replace(/^---\s*$/gm,"").trim();if(t&&i){const n=`你是一位专业的演讲教练。请根据以下幻灯片内容，提炼出简短精炼的演讲口播提词卡（Notes），包含核心观点与口播要点，总字数在 150 字以内：
${i}`;try{const s=await t(n);if(s&&s.trim())return{notes:s.trim(),isAiGenerated:!0}}catch(s){return{notes:ha(e),isAiGenerated:!1,error:(s==null?void 0:s.message)||"AI 调用异常"}}}return{notes:ha(e),isAiGenerated:!1}}async function cw(e,t){return(await ac(e,t)).notes}function dw(e){if(!e)return!1;const t=String(e.type||"").toLowerCase();return!!(t==="callout"||t==="nodecallout"||t==="b"||t==="nodeblockquote"||String(e.markdown||"").trim().startsWith(">"))}function uw(e,t){if(!((t==null?void 0:t[Ke])==="true"||(t==null?void 0:t["slides-note"])==="true"))return!1;const n=(e||"").trim();return/^>\s*\[!NOTE\]\s*(?:💡\s*)?(?:演讲备注|讲稿备注)/i.test(n)}async function fw(e,t){const n=await((t==null?void 0:t.getChildBlocksFn)||Yn)(e).catch(()=>[]);if(!Array.isArray(n)||n.length===0)return[];const s=[];let o=[];for(const r of n){if(hn({...r,ial:{...r.ial||{},...Le.getBlockAttrOverride(r.id)||{}}})){if(s.length===0&&o.length===0)continue;s.push(o),o=[];continue}o.push(r)}s.push(o);const a=[];for(let r=0;r<s.length;r++){const l=s[r];if(!l||l.length===0)continue;let c=null;for(let b=l.length-1;b>=0;b--){const m=l[b];if(!((m.type==="p"||m.type==="NodeParagraph")&&!(m.content||"").trim()&&!(m.markdown||"").trim())){c=m;break}}if(!c||!dw(c))continue;const u=Le.getBlockAttrOverride(c.id)||{};let d={...c.ial||{},...u};if(!d[Ke]&&!d["slides-note"]&&(t!=null&&t.getBlockAttrsFn)){const b=await t.getBlockAttrsFn(c.id).catch(()=>({}));d={...d,...b,...u}}let h=c.markdown||c.content||"";if(t!=null&&t.getBlockKramdownFn)try{const b=await t.getBlockKramdownFn(c.id);b!=null&&b.kramdown&&(h=b.kramdown)}catch{}if(uw(h,d))continue;const p=dr(h)||h.replace(/<[^>]+>/g,"").trim();a.push({id:c.id,pageIndex:r+1,type:c.type,sourceMarkdown:h,cleanContent:p||"在此输入本页讲稿提词..."})}return a}async function pw(e,t,i){const n=(i==null?void 0:i.updateBlockFn)||yo,s=(i==null?void 0:i.setBlockAttrsFn)||He,o=(i==null?void 0:i.syncDomFn)||et,r=`> [!NOTE] 💡 演讲备注
${t.split(/\r?\n/).map(l=>`> ${l}`).join(`
`)}
{: ${Ke}="true"}`;await n("markdown",r,e),await s(e,{[Ke]:"true"}),Le.setBlockAttrOverride(e,{[Ke]:"true"}),o(e,{[Ke]:"true"})}async function lc(e,t){const i=(t==null?void 0:t.showMessageFn)||de.showMessage,n=(t==null?void 0:t.confirmFn)||de.confirm;if(!e)return i("请先在主编辑区打开幻灯片文档"),{totalScanned:0,matchedCount:0,successCount:0,errorCount:0};const s=await fw(e,t);if(s.length===0)return i("未发现待规范化的候选讲稿块"),{totalScanned:0,matchedCount:0,successCount:0,errorCount:0};const o=s.length;return new Promise(a=>{n("识别讲稿块",`扫描检测到 ${o} 处候选讲稿块（提示块或引用块），是否确认将其规范化为标准演讲备注？`,async()=>{var c;i(`正在批量规范化 ${o} 个讲稿块...`);let r=0,l=0;for(const u of s)try{await pw(u.id,u.cleanContent,t),r++}catch(d){console.error(`[SiYuanLiveSlides] 规范化讲稿块 ${u.id} 失败:`,d),l++}(c=t==null?void 0:t.onSuccessNotice)==null||c.call(t,"已规范化讲稿"),i(`已成功识别并规范化 ${r} 个讲稿块`),t!=null&&t.compileFn&&await t.compileFn().catch(()=>{}),a({totalScanned:o,matchedCount:o,successCount:r,errorCount:l})},()=>{a({totalScanned:o,matchedCount:o,successCount:0,errorCount:0})})})}function hw(e,t){const i=ge(!1),{triggerSaveNotice:n}=t;async function s(h){var M,E,C,D,R,N,K,$;const m=`> [!NOTE] 💡 演讲备注
${(h||"在此输入本页讲稿提词...").split(/\r?\n/).map(V=>`> ${V}`).join(`
`)}
{: custom-slides-note="true"}`,y=((M=e.latestDoc.value)==null?void 0:M.slides)||[],g=e.targetSlide.value,w=g?y.findIndex(V=>V===g):-1;let S=null;if(w!==-1&&w<y.length-1){const V=y[w+1];S=await zi("markdown",m,V.startBlockId)}else{const V=((E=g==null?void 0:g.noteBlocks)==null?void 0:E.slice(-1)[0])||((C=g==null?void 0:g.blocks)==null?void 0:C.slice(-1)[0]),k=(V==null?void 0:V.id)||(g==null?void 0:g.startBlockId);k?S=await zi("markdown",m,void 0,k):S=await bo("markdown",m,e.currentDocId.value)}const x=((N=(R=(D=S==null?void 0:S[0])==null?void 0:D.doOperations)==null?void 0:R[0])==null?void 0:N.id)||((K=S==null?void 0:S[0])==null?void 0:K.id);return x&&(await He(x,{[Ke]:"true"}),Le.setBlockAttrOverride(x,{[Ke]:"true"}),Vi(x,($=e.plugin)==null?void 0:$.app)),e.plugin&&await e.plugin.compileCurrentDocument(),x}async function o(){const h=e.activeBlockId.value;if(h)if(e.isNoteBlock.value){n("取消中...");try{await He(h,{[Ke]:"","slides-note":""}),Le.setBlockAttrOverride(h,{[Ke]:"","slides-note":""}),et(h,{[Ke]:"","slides-note":""}),delete e.activeBlockAttrs.value[Ke],delete e.activeBlockAttrs.value["slides-note"],n("已取消备注"),de.showMessage("已取消讲稿备注"),e.plugin&&await e.plugin.compileCurrentDocument()}catch(p){console.error("[SiYuanLiveSlides] 取消讲稿备注失败:",p),n("取消失败"),de.showMessage("取消讲稿备注失败")}}else{n("转换中...");try{let p=e.rawSnippet.value;try{const g=await dd(h);g!=null&&g.kramdown&&(p=g.kramdown)}catch{}const y=`> [!NOTE] 💡 演讲备注
${(dr(p)||p.replace(/<[^>]+>/g,"").trim()||"在此输入本页讲稿提词...").split(/\r?\n/).map(g=>`> ${g}`).join(`
`)}
{: custom-slides-note="true"}`;await yo("markdown",y,h),await He(h,{[Ke]:"true"}),Le.setBlockAttrOverride(h,{[Ke]:"true"}),et(h,{[Ke]:"true"}),e.activeBlockAttrs.value[Ke]="true",e.activeBlockType.value="NodeCallout",n("已设为讲稿备注"),de.showMessage("已转为讲稿备注提示块（不在幻灯片中渲染）"),e.plugin&&await e.plugin.compileCurrentDocument()}catch(p){console.error("[SiYuanLiveSlides] 转换讲稿备注提示块失败:",p),n("设置失败"),de.showMessage("转为讲稿备注提示块失败")}}}async function a(){try{await s(),de.showMessage("已在正文末尾插入讲稿备注提示块")}catch(h){de.showMessage("插入讲稿备注块失败"),console.error(h)}}function r(){var b;const h=e.currentSlideNoteBlockId.value;if(!h){de.showMessage("未找到本页关联的讲稿备注块");return}Vi(h,(b=e.plugin)==null?void 0:b.app)?de.showMessage("已在编辑区定位讲稿备注块"):de.showMessage("定位讲稿备注块失败")}async function l(){var b;if(!e.currentDocId.value)return;const h=e.targetSlide.value||{startBlockId:e.activeBlockId.value||e.currentDocId.value,blocks:e.rawSnippet.value&&e.rawSnippet.value!=="---"?[{id:e.activeBlockId.value,type:e.activeBlockType.value,content:e.rawSnippet.value,rawMarkdown:""}]:[],rawMarkdown:e.rawSnippet.value&&e.rawSnippet.value!=="---"?e.rawSnippet.value:""};de.showMessage("正在调用思源 AI 提炼本页讲稿提词...");const p=await ac(h,ka);if(p.notes){const m=e.currentSlideNoteBlockId.value;if(m){const y=`> [!NOTE] 💡 演讲备注
${p.notes.split(/\r?\n/).map(g=>`> ${g}`).join(`
`)}
{: custom-slides-note="true"}`;await yo("markdown",y,m),await He(m,{[Ke]:"true"}),Le.setBlockAttrOverride(m,{[Ke]:"true"}),Vi(m,(b=e.plugin)==null?void 0:b.app)}else await s(p.notes);p.isAiGenerated?de.showMessage("思源 AI 演讲提词卡生成成功！"):de.showMessage("未获取到思源 AI 响应，已生成预设提词卡模板",5e3),e.plugin&&await e.plugin.compileCurrentDocument()}}async function c(){var m;if(i.value)return;const h=((m=e.latestDoc.value)==null?void 0:m.slides)||[];if(h.length===0){de.showMessage("当前文档无幻灯片页面");return}const p=h.map((y,g)=>({slide:y,idx:g})).filter(({slide:y})=>{var S;const g=Array.isArray(y.noteBlocks)&&y.noteBlocks.length>0,w=!!((S=y.notes)!=null&&S.trim());return!g&&!w});if(p.length===0){de.showMessage("所有幻灯片页面均已存在讲稿备注块，无需追加");return}const b=p.length;de.confirm("批量追加讲稿备注",`将在未配置讲稿的 ${b} 页末尾自动插入讲稿提示块，是否继续？`,async()=>{var g,w,S,x,M,E;if(i.value)return;i.value=!0,de.showMessage("正在批量追加讲稿块...");let y=0;try{const R=`> [!NOTE] 💡 演讲备注
${"在此输入本页讲稿提词...".split(/\r?\n/).map(N=>`> ${N}`).join(`
`)}
{: custom-slides-note="true"}`;for(const{slide:N,idx:K}of p)try{let $=null;if(K<h.length-1){const k=h[K+1];$=await zi("markdown",R,k.startBlockId)}else{const k=((g=N==null?void 0:N.noteBlocks)==null?void 0:g.slice(-1)[0])||((w=N==null?void 0:N.blocks)==null?void 0:w.slice(-1)[0]),F=(k==null?void 0:k.id)||(N==null?void 0:N.startBlockId);F?$=await zi("markdown",R,void 0,F):$=await bo("markdown",R,e.currentDocId.value)}const V=((M=(x=(S=$==null?void 0:$[0])==null?void 0:S.doOperations)==null?void 0:x[0])==null?void 0:M.id)||((E=$==null?void 0:$[0])==null?void 0:E.id);V&&(await He(V,{[Ke]:"true"}),Le.setBlockAttrOverride(V,{[Ke]:"true"})),y++}catch($){console.error(`[SiYuanLiveSlides] 为第 ${K+1} 页追加讲稿块失败:`,$)}e.plugin&&await e.plugin.compileCurrentDocument(),de.showMessage(`已成功为 ${y} 页追加讲稿备注块`)}catch(C){console.error("[SiYuanLiveSlides] 批量追加讲稿块失败:",C),de.showMessage("批量追加讲稿块时出现异常")}finally{i.value=!1}})}async function u(){var y;if(i.value)return;const h=((y=e.latestDoc.value)==null?void 0:y.slides)||[];if(h.length===0){de.showMessage("当前文档无幻灯片页面");return}const p=[];for(const g of h)if(g.noteBlocks&&g.noteBlocks.length>0)for(const w of g.noteBlocks)w.id&&p.push({id:w.id,pageIndex:g.pageIndex});if(p.length===0){de.showMessage("当前文档中没有讲稿备注块，无需删除");return}const b=new Set(p.map(g=>g.pageIndex)).size,m=p.length;de.confirm("危险操作：批量删除所有讲稿块",`此操作将从正文中物理删除全部 ${m} 个讲稿备注块（涉及 ${b} 页），删除后无法撤销。是否确认继续？`,async()=>{if(i.value)return;i.value=!0,de.showMessage("正在批量删除讲稿块...");let g=0;try{for(const w of p)try{await ya(w.id),Le.clearBlockAttrOverride(w.id),g++}catch(S){console.error(`[SiYuanLiveSlides] 删除讲稿块 ${w.id} 失败:`,S)}e.activeBlockId.value&&p.some(w=>w.id===e.activeBlockId.value)&&(delete e.activeBlockAttrs.value[Ke],delete e.activeBlockAttrs.value["slides-note"]),e.plugin&&await e.plugin.compileCurrentDocument(),de.showMessage(`已成功删除全部 ${g} 个讲稿备注块`)}catch(w){console.error("[SiYuanLiveSlides] 批量删除讲稿块失败:",w),de.showMessage("批量删除讲稿块时出现异常")}finally{i.value=!1}})}async function d(){var p;const h=e.currentDocId.value||((p=e.plugin)==null?void 0:p.currentDocId);if(!h){de.showMessage("请先在主编辑区打开幻灯片文档");return}if(i.value){de.showMessage("正在批量处理中，请稍候...");return}i.value=!0;try{await lc(h,{onSuccessNotice:n,compileFn:async()=>{e.plugin&&await e.plugin.compileCurrentDocument()}})}finally{i.value=!1}}return{isBatchProcessing:i,createNoteBlockOnCurrentSlide:s,onToggleNoteBlock:o,onAddNoteBlock:a,onLocateNoteBlock:r,onGenerateNotesWithAI:l,onBatchAppendNotes:c,onBatchDeleteNotes:u,onIdentifyNotesBlocks:d}}function mw(e){if(!e)return!1;const t=String(e.type||"").toLowerCase();if(t==="h"||t==="nodeheading")return!0;const i=String(e.subType||"").toLowerCase();if(/^h[1-6]$/.test(i))return!0;const n=String(e.rawMarkdown||e.markdown||"").trim();return!!/^#{1,6}\s+/.test(n)}function gw(e){if(!e)return!1;const t=String(e.type||"").toLowerCase();return t==="i"||t==="nodelistitem"}function vw(e){const t=[],i=n=>{var s,o,a,r,l,c,u,d,h,p,b;for(const m of n){if(!m||m.isNote||((s=m.attributes)==null?void 0:s[Ke])==="true"||((o=m.attributes)==null?void 0:o["slides-note"])==="true"||((a=m.ial)==null?void 0:a[Ke])==="true"||((r=m.ial)==null?void 0:r["slides-note"])==="true"||m.type==="tb"||m.type==="thematic-break"||m.type==="NodeThematicBreak"||String(m.markdown||m.rawMarkdown||"").trim()==="---"||m.slot==="slot-divider-right"||String(m.rawMarkdown||m.markdown||"").trim()==="::right::")continue;if(mw(m)){t.push({id:m.id,type:m.type,isHeading:!0,currentClicks:m.clicks||((l=m.attributes)==null?void 0:l[Re])||((c=m.ial)==null?void 0:c[Re]),rawBlock:m});continue}if(gw(m)){t.push({id:m.id,type:m.type||"i",isHeading:!1,currentClicks:m.clicks||((u=m.attributes)==null?void 0:u[Re])||((d=m.ial)==null?void 0:d[Re]),rawBlock:m});continue}const y=m.children&&m.children.length>0?m.children:(h=m.rawNode)==null?void 0:h.children;if(Array.isArray(y)&&y.length>0){i(y);continue}t.push({id:m.id,type:m.type,isHeading:!1,currentClicks:m.clicks||((p=m.attributes)==null?void 0:p[Re])||((b=m.ial)==null?void 0:b[Re]),rawBlock:m})}};return i(e||[]),t}function bw(e){var s;if(e.pageIndex===1||((s=e.frontmatter)==null?void 0:s.layout)==="cover")return[];const t=vw(e.blocks||[]);if(t.length===0)return[];let i=-1;for(let o=0;o<t.length;o++)if(!t[o].isHeading){i=o;break}if(i===-1)return[];const n=[];for(let o=i+1;o<t.length;o++){const a=t[o];!!!(a.currentClicks&&String(a.currentClicks).trim()!=="")&&a.id&&n.push({blockId:a.id,pageIndex:e.pageIndex,targetClick:"+1"})}return n}async function yw(e,t){const n=await((t==null?void 0:t.compileDocFn)||(a=>Le.compile(a)))(e).catch(()=>null);if(!n||!Array.isArray(n.slides)||n.slides.length===0)return{totalPages:0,animatedPagesCount:0,targets:[]};const s=[],o=new Set;for(const a of n.slides){const r=bw(a);r.length>0&&(s.push(...r),o.add(a.pageIndex))}return{totalPages:n.slides.length,animatedPagesCount:o.size,targets:s}}async function cc(e,t){const i=(t==null?void 0:t.showMessageFn)||de.showMessage,n=(t==null?void 0:t.confirmFn)||de.confirm,s=(t==null?void 0:t.setBlockAttrsFn)||He,o=(t==null?void 0:t.syncDomFn)||et;if(!e)return i("请先在主编辑区打开幻灯片文档"),{totalPages:0,animatedPagesCount:0,targets:[],successCount:0,errorCount:0};const a=await yw(e,t);if(a.targets.length===0)return i("未检测到需要配置顺延动效的后续块"),{...a,successCount:0,errorCount:0};const r=a.targets.length,l=a.animatedPagesCount;return new Promise(c=>{n("智能设置动效",`扫描检测到可为 ${l} 页中的 ${r} 个后续块配置顺延 (+1) 动效，是否继续？`,async()=>{var h;i(`正在批量配置 ${r} 个后续块动效...`);let u=0,d=0;for(const p of a.targets)try{await s(p.blockId,{[Re]:p.targetClick}),Le.setBlockAttrOverride(p.blockId,{[Re]:p.targetClick}),o(p.blockId,{[Re]:p.targetClick}),u++}catch(b){console.error(`[SiYuanLiveSlides] 为块 ${p.blockId} 配置动效失败:`,b),d++}(h=t==null?void 0:t.onSuccessNotice)==null||h.call(t,"已配置智能动效"),i(`已成功为 ${u} 个后续块配置顺延 (+1) 动效`),t!=null&&t.compileCurrentDocFn&&await t.compileCurrentDocFn().catch(()=>{}),c({...a,successCount:u,errorCount:d})},()=>{c({...a,successCount:0,errorCount:0})})})}function kw(e,t){const{saveAttr:i,saveAttrs:n,savePageAttr:s}=t;async function o(){(e.videoAutoplay.value?"false":"true")==="true"?(await n({[Ni]:"true",[Xi]:"true"}),e.activeBlockAttrs.value[Ni]="true",e.activeBlockAttrs.value[Xi]="true"):(await i(Ni,"false"),e.activeBlockAttrs.value[Ni]="false")}async function a(){const D=e.videoLoop.value?"false":"true";await i(ws,D)}async function r(){const D=e.videoMuted.value?"false":"true";await i(Xi,D)}async function l(){const D=e.videoControls.value?"false":"true";await i(xs,D)}async function c(D){var V;const R=e.activeBlockId.value;if(!R)return;const N=e.rawSnippet.value||"",K=fi(N)||"",$=e.currentPageDividerId.value||e.currentDocId.value;if(D)if(D==="background"){const k={[Ze]:"background",[ke]:""};$&&K&&(e.pageBackground.value=K,await He($,{[st]:K}).catch(()=>{}),Le.setBlockAttrOverride($,{[st]:K}),et($,{[st]:K}),e.targetSlide.value&&(e.targetSlide.value.frontmatter||(e.targetSlide.value.frontmatter={}),e.targetSlide.value.frontmatter.background=K)),await n(k)}else(D===Ss||D===Cs)&&await n({[ke]:D,[Ze]:""});else{const k={[Ze]:"",[ke]:""};if(e.activeBlockAttrs.value[st]==="true"&&(k[st]=""),$&&K&&e.pageBackground.value===K&&(e.pageBackground.value="",await He($,{[st]:""}).catch(()=>{}),Le.setBlockAttrOverride($,{[st]:""}),et($,{[st]:""}),(V=e.targetSlide.value)!=null&&V.frontmatter&&delete e.targetSlide.value.frontmatter.background),await n(k),typeof document<"u"){const F=document.querySelector(`.protyle-wysiwyg [data-node-id="${R}"]`),H=F==null?void 0:F.closest('[data-type="NodeListItem"]'),I=H==null?void 0:H.getAttribute("data-node-id");if(I&&I!==R){const A={[ke]:"",[Ze]:""};et(I,A),Le.setBlockAttrOverride(I,A),await He(I,A).catch(()=>{})}}}}function u(){e.elemClick.value?i(Re,""):i(Re,"+1")}function d(D){i(Re,D)}function h(D){i(Jt,D)}function p(D){(e.activeBlockAttrs.value[Me]||"")===D?i(Me,""):i(Me,D)}function b(D){e.elemShikiLines.value=D,i(Gi,D)}function m(D){const R=D?D.trim():"",N=/^\d+$/.test(R)?`${R}px`:R;e.elemMaxHeight.value=N,i(Fn,N)}async function y(){const D=e.currentSlideLayout.value==="three-cols-header";await i(Me,D?"col-1":"left"),de.showMessage(D?"已将当前块设置为第 1 栏":"已将当前块设置为双栏左栏")}async function g(){const D=e.activeBlockId.value;if(!D)return;const R={[Re]:"",[Jt]:"",[Me]:"",[Gi]:"",[Fn]:"",[Ke]:"","slides-note":"",[ke]:"",[vt]:"",[Ze]:"",[gt]:"",[st]:"",[Ot]:"",[Ni]:"",[ws]:"",[Xi]:"",[xs]:""};if(et(D,R),await He(D,R),Le.clearBlockAttrOverride(D),typeof document<"u"){const N=document.querySelector(`.protyle-wysiwyg [data-node-id="${D}"]`),K=N==null?void 0:N.closest('[data-type="NodeListItem"]'),$=K==null?void 0:K.getAttribute("data-node-id");$&&$!==D&&(et($,R),await He($,R).catch(()=>{}),Le.clearBlockAttrOverride($))}e.activeBlockAttrs.value={},e.elemShikiLines.value="",e.elemMaxHeight.value="",e.pageBackground.value="",e.pageImage.value="",de.showMessage("已清除本块演示属性"),e.plugin&&await e.plugin.compileCurrentDocument()}async function w(){if(e.activeBlockId.value)try{await zi("markdown","---",e.activeBlockId.value,void 0),de.showMessage("已在上方插入分页符"),e.plugin&&e.plugin.compileCurrentDocument()}catch{de.showMessage("插入分页符失败")}}async function S(){const D=e.activeBlockId.value||e.currentDocId.value;if(D)try{await zi("markdown","---",void 0,D),de.showMessage("已在下方插入分页符"),e.plugin&&e.plugin.compileCurrentDocument()}catch{de.showMessage("插入分页符失败")}}async function x(){if(e.activeBlockId.value)try{await ya(e.activeBlockId.value),de.showMessage("已删除该分页符"),e.activeBlockId.value="",e.activeBlockType.value="",e.plugin&&e.plugin.compileCurrentDocument()}catch{de.showMessage("删除失败")}}async function M(){var D,R;try{let N=null;if(typeof document<"u"){const $=e.activeBlockId.value;if($){const V=document.querySelector(`.protyle-wysiwyg [data-node-id="${$}"]`);V&&(N=V.getAttribute("data-type")==="NodeSuperBlock"?V:V.closest('[data-type="NodeSuperBlock"]'))}if(!N){const V=e.currentPageDividerId.value||(e.activeBlockType.value==="hr"||e.activeBlockType.value==="NodeThematicBreak"?e.activeBlockId.value:"");if(V){const k=document.querySelector(`.protyle-wysiwyg [data-node-id="${V}"]`);if(k){let F=k.nextElementSibling;for(;F&&!(F.getAttribute("data-type")==="NodeThematicBreak"||(D=F.classList)!=null&&D.contains("protyle-wysiwyg__block--hr"));){const H=F.getAttribute("data-type")==="NodeSuperBlock"?F:F.querySelector('[data-type="NodeSuperBlock"]');if(H){N=H;break}F=F.nextElementSibling}}}else{const k=document.querySelector('.protyle-wysiwyg [data-type="NodeThematicBreak"], .protyle-wysiwyg .protyle-wysiwyg__block--hr'),F=Array.from(document.querySelectorAll('.protyle-wysiwyg [data-type="NodeSuperBlock"]'));for(const H of F)if(!k||H.compareDocumentPosition(k)&Node.DOCUMENT_POSITION_FOLLOWING){N=H;break}}}}const K=[];if(N){const $=Array.from(N.querySelectorAll(":scope > [data-node-id]"));for(const V of $){const k=V.getAttribute("data-node-id");k&&(K.push(k),V.removeAttribute("style"))}}else if((R=e.targetSlide.value)!=null&&R.blocks){for(const $ of e.targetSlide.value.blocks)if($.children&&$.children.length>=2){for(const V of $.children)V.id&&K.push(V.id);break}}if(K.length>0)for(const $ of K)await He($,{style:""}).catch(()=>{});await s(vt,""),de.showMessage("已重置超级块为平均分布比例"),e.plugin&&await e.plugin.compileCurrentDocument()}catch(N){console.error("[layout-actions] resetSuperBlockWidth error:",N),de.showMessage("重置超级块比例失败")}}async function E(){var D,R,N;try{let K=null;if(typeof document<"u"){const V=e.currentPageDividerId.value||(e.activeBlockType.value==="hr"||e.activeBlockType.value==="NodeThematicBreak"?e.activeBlockId.value:""),k=e.activeBlockId.value;let F=[];if(V){const A=document.querySelector(`.protyle-wysiwyg [data-node-id="${V}"]`);if(A){let O=A.nextElementSibling;for(;O&&!(O.getAttribute("data-type")==="NodeThematicBreak"||(D=O.classList)!=null&&D.contains("protyle-wysiwyg__block--hr"));)F.push(O),O=O.nextElementSibling}}else{const A=document.querySelector('.protyle-wysiwyg [data-type="NodeThematicBreak"], .protyle-wysiwyg .protyle-wysiwyg__block--hr'),O=Array.from(document.querySelectorAll(".protyle-wysiwyg > [data-node-id]"));for(const ne of O)if(!A||ne.compareDocumentPosition(A)&Node.DOCUMENT_POSITION_FOLLOWING)F.push(ne);else break}const H=[];let I;for(const A of F){const O=A.getAttribute("data-type");O==="NodeHeading"&&(I=A.getAttribute("data-node-id")||void 0);const ne=[];O==="NodeSuperBlock"?ne.push(A):ne.push(...Array.from(A.querySelectorAll('[data-type="NodeSuperBlock"]')));for(const G of ne){if((G.getAttribute("data-sb-layout")||"").toLowerCase()==="row")continue;const ce=G.getAttribute("data-node-id")||"";let se=[];const re=Array.from(G.querySelectorAll('[data-type="NodeListItem"]'));if(re.length===4&&(se=re.map(Se=>Se.getAttribute("data-node-id")).filter(Boolean)),se.length!==4){const Se=Array.from(G.querySelectorAll(":scope > [data-node-id]"));Se.length===4&&(se=Se.map(Ie=>Ie.getAttribute("data-node-id")).filter(Boolean))}se.length===4&&H.push({sbId:ce,itemIds:se,headerId:I})}}H.length>0&&(k&&(K=H.find(A=>{if(A.sbId===k||A.itemIds.includes(k))return!0;const O=document.querySelector(`.protyle-wysiwyg [data-node-id="${A.sbId}"]`),ne=document.querySelector(`.protyle-wysiwyg [data-node-id="${k}"]`);return!!(O&&ne&&O.contains(ne))})||null),K||(K=H[0]))}if(!K&&((R=e.targetSlide.value)!=null&&R.blocks)){const V=e.targetSlide.value,k=[];for(const H of V.blocks)H.rawNode?k.push(H.rawNode):k.push({id:H.id,type:H.type,content:H.content,markdown:H.rawMarkdown,children:H.children,ial:H.attributes||H.ial||{}});const F=Yf(k,e.activeBlockId.value);F&&F.items.length===4&&(K={sbId:F.superBlockNode.id,itemIds:F.items.map(H=>H.id),headerId:(N=F.headerNode)==null?void 0:N.id})}const $=e.currentPageDividerId.value||e.currentDocId.value;if($&&(e.currentPageDividerLayout.value="clover",e.targetSlide.value&&(e.targetSlide.value.frontmatter||(e.targetSlide.value.frontmatter={}),e.targetSlide.value.frontmatter.layout="clover"),Le.setBlockAttrOverride($,{[ke]:"clover"}),et($,{[ke]:"clover"}),await He($,{[ke]:"clover"}).catch(()=>{})),K&&K.itemIds.length>0){K.headerId&&(Le.setBlockAttrOverride(K.headerId,{[Me]:"header"}),et(K.headerId,{[Me]:"header"}),await He(K.headerId,{[Me]:"header"}).catch(()=>{}));const V=Math.min(4,K.itemIds.length);for(let k=0;k<V;k++){const F=K.itemIds[k],H=`col-${k+1}`;Le.setBlockAttrOverride(F,{[Me]:H}),et(F,{[Me]:H}),await He(F,{[Me]:H}).catch(()=>{})}}return de.showMessage("已将本页版式设为四叶草（田字型）布局"),e.plugin&&await e.plugin.compileCurrentDocument(),!0}catch(K){return console.error("[layout-actions] applyCloverLayout error:",K),de.showMessage("配置四叶草布局失败",4e3,"error"),!1}}async function C(){var R,N;const D=e.currentDocId.value||((R=e.plugin)==null?void 0:R.currentDocId);if(!D){de.showMessage("请先在主编辑区打开幻灯片文档");return}if((N=t.isBatchProcessing)!=null&&N.value){de.showMessage("正在批量处理中，请稍候...");return}t.isBatchProcessing&&(t.isBatchProcessing.value=!0);try{await cc(D,{onSuccessNotice:t.triggerSaveNotice,compileCurrentDocFn:async()=>{e.plugin&&await e.plugin.compileCurrentDocument()}})}finally{t.isBatchProcessing&&(t.isBatchProcessing.value=!1)}}return{onToggleVideoAutoplay:o,onToggleVideoLoop:a,onToggleVideoMuted:r,onToggleVideoControls:l,onImageRoleChange:c,toggleElemClick:u,onElemClickStepChange:d,onElemMotionChange:h,onElemSlotChange:p,onElemShikiLinesChange:b,onElemMaxHeightChange:m,onSetTwoColsContrast:y,onClearBlockAttrs:g,onInsertDividerBefore:w,onInsertDividerAfter:S,onDeleteCurrentBlock:x,resetSuperBlockWidth:M,applyCloverLayout:E,onAutoAnimateDocument:C}}function ww(e){const{triggerSaveNotice:t,saveAttrs:i,saveAttr:n,savePageAttr:s,applyPageLayoutAndRatio:o,saveDocAttr:a}=lw(e),r=hw(e,{triggerSaveNotice:t}),l=kw(e,{saveAttr:n,saveAttrs:i,savePageAttr:s,triggerSaveNotice:t,isBatchProcessing:r.isBatchProcessing});async function c(){var g;if(!e.latestDoc.value){de.showMessage("请先在主编辑区打开幻灯片文档");return}const p=e.latestDoc.value,b=await Mi(p,(g=e.currentDocId)==null?void 0:g.value,e.plugin),m=ql(p,{title:b});Yl(`${b}.html`,m)&&de.showMessage(`已开始下载单文件离线 HTML 演示包 (${b}.html)`)}function u(){if(!e.latestDoc.value){de.showMessage("请先在主编辑区打开幻灯片文档");return}Zl(e.latestDoc.value)&&de.showMessage("已唤起打印视窗，请在打印选项中选择「另存为 PDF」")}const d=ge(!1);async function h(){var p;if(d.value){de.showMessage("正在导出图片中，请稍候...",2e3);return}if(!e.latestDoc.value){de.showMessage("请先在主编辑区打开幻灯片文档");return}d.value=!0;try{de.showMessage("正在启动后台沙箱并逐页导出幻灯片图片...");const b=e.latestDoc.value,m=await Mi(b,(p=e.currentDocId)==null?void 0:p.value,e.plugin),y=await tc(b,{title:m,onProgress:(g,w)=>{de.showMessage(`正在导出幻灯片图片 (${g} / ${w})...`,2e3)}});y.success?de.showMessage(`🎉 成功导出 ${y.total||0} 张幻灯片高清图片并已保存为 ${m}.zip！`,4e3):de.showMessage(`导出图片失败：${y.error||"未知异常"}`)}finally{d.value=!1}}return{triggerSaveNotice:t,saveAttrs:i,saveAttr:n,savePageAttr:s,applyPageLayoutAndRatio:o,saveDocAttr:a,onToggleVideoAutoplay:l.onToggleVideoAutoplay,onToggleVideoLoop:l.onToggleVideoLoop,onToggleVideoMuted:l.onToggleVideoMuted,onToggleVideoControls:l.onToggleVideoControls,onImageRoleChange:l.onImageRoleChange,onToggleNoteBlock:r.onToggleNoteBlock,createNoteBlockOnCurrentSlide:r.createNoteBlockOnCurrentSlide,onAddNoteBlock:r.onAddNoteBlock,onLocateNoteBlock:r.onLocateNoteBlock,onGenerateNotesWithAI:r.onGenerateNotesWithAI,isBatchProcessing:r.isBatchProcessing,onBatchAppendNotes:r.onBatchAppendNotes,onBatchDeleteNotes:r.onBatchDeleteNotes,onIdentifyNotesBlocks:r.onIdentifyNotesBlocks,toggleElemClick:l.toggleElemClick,onElemClickStepChange:l.onElemClickStepChange,onElemMotionChange:l.onElemMotionChange,onElemSlotChange:l.onElemSlotChange,onElemShikiLinesChange:l.onElemShikiLinesChange,onElemMaxHeightChange:l.onElemMaxHeightChange,onSetTwoColsContrast:l.onSetTwoColsContrast,onClearBlockAttrs:l.onClearBlockAttrs,onInsertDividerBefore:l.onInsertDividerBefore,onInsertDividerAfter:l.onInsertDividerAfter,onDeleteCurrentBlock:l.onDeleteCurrentBlock,resetSuperBlockWidth:l.resetSuperBlockWidth,applyCloverLayout:l.applyCloverLayout,onAutoAnimateDocument:l.onAutoAnimateDocument,isExportingImages:d,onExportHtml:c,onExportPdf:u,onExportImages:h}}function xw(e){const t=ye(()=>hr(e.activeBlockType.value));function i(n){const{attrKey:s,fallback:o,mode:a="defined"}=n,r=l=>a==="truthy"?l:l!==void 0;return ye(()=>{if(t.value){const c=e.activeBlockAttrs.value[s];if(r(c))return c}const l=e.currentPageDividerId.value||(t.value?e.activeBlockId.value:"");if(l){const c=Le.getBlockAttrOverride(l);if(r(c==null?void 0:c[s]))return c[s]}return o()})}return{isDivider:t,resolvePageAttr:i}}function Sw(e,t){const i=[];let s=0;for(let o=0;o<e.length;o++){const a=e[o];if(hn(a)){s=0;continue}const r=a.markdown||a.content||"";if(!(o===0)){if(a.type==="h"&&(a.subType==="h1"||r.startsWith("# "))){i.push({blockId:a.id,recommendedLayout:"cover",reason:"检测到一级核心章节标题，建议作为新幻灯片封面/大章"}),s=0;continue}if(a.type==="h"&&(a.subType==="h2"||r.startsWith("## "))){i.push({blockId:a.id,recommendedLayout:"default",reason:"检测到二级分论点标题，建议开启新页"}),s=0;continue}}if(s++,s>=6&&o<e.length-1){const c=e[o+1];hn(c)||(i.push({blockId:c.id,recommendedLayout:"default",reason:"当前页已达容量上限 (避免信息超载)，建议在此分页"}),s=0)}}return i}async function dc(e){if(!e.currentDocId&&typeof document<"u"){const o=document.querySelector(".protyle-content[data-doc-id]");e.currentDocId=(o==null?void 0:o.getAttribute("data-doc-id"))||""}if(!e.currentDocId){de.showMessage("请先打开一篇思源笔记文档");return}const t=await Yn(e.currentDocId).catch(()=>[]);if(!t||t.length===0){de.showMessage("当前文档无内容，无需断页");return}const i=t.map(o=>({id:o.id,type:o.type,subType:o.subType,content:o.content||"",markdown:o.markdown||""})),n=Sw(i);if(n.length===0){de.showMessage("AI 分析完毕：当前文档篇幅合理，暂无分页建议");return}de.showMessage(`AI 分析完毕：发现 ${n.length} 处建议分页点，正在自动插入分页分割线...`);let s=0;for(const o of n)try{await zi("markdown","---",void 0,o.blockId),await He(o.blockId,{"custom-slides-layout":o.recommendedLayout}),s++}catch(a){console.warn("Failed to insert divider:",a)}de.showMessage(`已成功在 ${s} 处插入分页线并重新编译`),e.compileCurrentDocument(e.currentDocId)}const Cw={class:"spm-slides-inspector"},_w={class:"spm-inspector-topbar"},$w={class:"spm-inspector-title"},Iw={class:"slides-icon",style:{fill:"none !important"},"aria-hidden":"true",viewBox:"0 0 24 24"},Mw={class:"spm-inspector-topbar-actions"},Tw={class:"spm-target-banner"},Ew={class:"spm-target-info"},Aw=["aria-label"],Bw={key:0,class:"spm-save-status"},Dw=["title"],Lw={class:"spm-inspector-body"},Pw=Bt({__name:"SlidesInspectorDockView",setup(e,{expose:t}){const i=Nt("plugin"),n=ge(!1);function s(ee){n.value=!1,c.value=ee.docId,i!=null&&i.compileCurrentDocument&&i.compileCurrentDocument(ee.docId)}const o=ge(""),a=ge(""),r=ge({}),l=ge(""),c=ge(""),u=ge(""),d=ge(""),h=ge(""),p=ge(""),b=ge(""),m=ge(""),y=ge(null),g=ge(""),w=ge("");function S(){var be;const ee=o.value||c.value;ee&&typeof navigator<"u"&&(be=navigator==null?void 0:navigator.clipboard)!=null&&be.writeText&&navigator.clipboard.writeText(ee).then(()=>{w.value="已复制！",setTimeout(()=>{w.value=""},1500)}).catch(()=>{})}const x=ye(()=>hr(a.value)),M=ye(()=>a.value==="NodeCodeBlock"),E=ge(!1),C=ye(()=>{if(E.value||Ne.value)return!0;const ee=l.value||"";return!!fi(ee)}),D=ye(()=>{const ee=a.value||"";if(ee==="NodeVideo"||ee==="video")return!0;const be=l.value||"";return!!(/<video\b/i.test(be)||/\.mp4\b/i.test(be))}),R=ye(()=>!o.value||o.value===c.value||a.value==="doc"||a.value==="NodeDocument"),N=ye(()=>{const ee=o.value||c.value||"";return ee.length>8?ee.slice(-8):ee||"无"}),K=ye(()=>l.value?l.value.replace(/<[^>]+>/g,"").replace(/[\r\n]+/g," ").trim().slice(0,45):""),$=ye(()=>{if(x.value)return"分页符 (---)";if(R.value)return"全局文档";if(D.value)return"视频块";let ee="内容块";switch(a.value){case"NodeHeading":ee="标题块";break;case"NodeParagraph":ee="段落块";break;case"NodeCodeBlock":ee="代码块";break;case"NodeVideo":ee="视频块";break;case"NodeList":case"NodeListItem":ee="列表项";break;case"NodeBlockquote":ee="引述块";break;case"NodeTable":ee="表格块";break;case"NodeSuperBlock":case"s":case"sb":ee="超级块";break;default:ee="内容块";break}return p.value?b.value?`${b.value.replace(/^col-(\d+)$/,"第 $1 栏")} › ${ee}`:`分栏容器 › ${ee}`:ee}),V=ye(()=>x.value?"tag-divider":R.value?"tag-doc":"tag-block"),k=ye(()=>r.value[ke]||"default"),F=ye(()=>r.value[gt]||"slide-left"),H=ge(""),I=ge(""),A=ye(()=>r.value[Mn]||"inherit"),O=ye(()=>{var ee;return ow((ee=y.value)==null?void 0:ee.slides,{activeBlockId:o.value,activeBlockType:a.value,currentTopBlockId:u.value,currentPageDividerId:d.value,activeBlockAttrs:r.value})}),ne=ye(()=>{var ee;return((ee=O.value)==null?void 0:ee.notes)||""}),G=ye(()=>{var ee,be,Ae;return((Ae=(be=(ee=O.value)==null?void 0:ee.noteBlocks)==null?void 0:be[0])==null?void 0:Ae.id)||""}),q=ye(()=>{var Ve,Ge,Oe,ft,ts,bi;if(x.value){const it=r.value[ke]||r.value["custom-slides-layout"];if(it)return it}const ee=r.value[Me]||r.value["custom-slides-slot"];if(ee&&(["col-1","col-2","col-3"].includes(ee)||/^col-\d+$/.test(ee)))return"cols-header";if(h.value)return h.value;const be=d.value||(x.value?o.value:"");if(be){const it=Le.getBlockAttrOverride(be);if(it!=null&&it[ke])return it[ke]}if(be&&((Ve=y.value)!=null&&Ve.slides)){const it=y.value.slides.find(qi=>qi.startBlockId===be);if((Ge=it==null?void 0:it.frontmatter)!=null&&Ge.layout)return it.frontmatter.layout}if((ft=(Oe=O.value)==null?void 0:Oe.frontmatter)!=null&&ft.layout)return O.value.frontmatter.layout;if((bi=(ts=O.value)==null?void 0:ts.blocks)!=null&&bi.some(it=>it.slot&&(["col-1","col-2","col-3"].includes(it.slot)||/^col-\d+$/.test(it.slot))))return"cols-header";const Ae=Le.getBlockAttrOverride(c.value);return Ae!=null&&Ae[ke]?Ae[ke]:"default"}),ce=xw({activeBlockId:o,activeBlockType:a,activeBlockAttrs:r,currentPageDividerId:d}),se=ce.resolvePageAttr({attrKey:vt,mode:"truthy",fallback:()=>{var ee,be;return((be=(ee=O.value)==null?void 0:ee.frontmatter)==null?void 0:be.layoutRatio)||""}}),re=ce.resolvePageAttr({attrKey:en,fallback:()=>{var ee,be;return((be=(ee=O.value)==null?void 0:ee.frontmatter)==null?void 0:be.mask)||""}}),Se=ce.resolvePageAttr({attrKey:Fi,fallback:()=>{var ee,be;return((be=(ee=O.value)==null?void 0:ee.frontmatter)==null?void 0:be.maskRatio)||""}}),Ie=ce.resolvePageAttr({attrKey:tn,fallback:()=>{var ee,be;return((be=(ee=O.value)==null?void 0:ee.frontmatter)==null?void 0:be.maskStyle)||"solid"}}),_e=ce.resolvePageAttr({attrKey:nn,fallback:()=>{var ee,be;return((be=(ee=O.value)==null?void 0:ee.frontmatter)==null?void 0:be.maskInitial)||"hidden"}});function pe(ee){if(!ee||(ee.getAttribute("data-sb-layout")||"").toLowerCase()!=="col")return null;const Ae=Array.from(ee.querySelectorAll(":scope > [data-node-id]"));if(Ae.length<2)return null;const Ve=Ae.length,Ge=Ae.map(bi=>{const it=bi.getAttribute("style")||"",qi=it.match(/calc\(\s*([\d.]+)%/);if(qi)return parseFloat(qi[1]);const kn=it.match(/(?:^|;|\s)width:\s*([\d.]+)%/i);return kn?parseFloat(kn[1]):null});let Oe="",ft=!1;if(Ge.some(bi=>bi!==null)){ft=!0;const bi=Ge.reduce((Pe,pt)=>Pe+(pt||0),0),it=Ge.filter(Pe=>Pe===null).length,qi=it>0?Math.max(0,100-bi)/it:100/Ae.length,kn=Ge.map(Pe=>Pe!==null?Pe:qi),ed=kn.reduce((Pe,pt)=>Pe+pt,0)||1,wn=kn.map(Pe=>Pe/ed*100);if(wn.length===2){const[Pe]=wn;if(Pe>=48&&Pe<=52)Oe="1:1";else if(Pe>=31&&Pe<=35)Oe="1:2";else if(Pe>=65&&Pe<=69)Oe="2:1";else if(Pe>=28&&Pe<=32)Oe="3:7";else if(Pe>=68&&Pe<=72)Oe="7:3";else if(Pe>=38&&Pe<=42)Oe="4:6";else if(Pe>=58&&Pe<=62)Oe="6:4";else{const pt=Math.round(Pe);Oe=`${pt}:${100-pt}`}}else if(wn.length===3){const[Pe,pt,yi]=wn;if(Pe>=31&&Pe<=35&&pt>=31&&pt<=35&&yi>=31&&yi<=35)Oe="1:1:1";else if(Pe>=23&&Pe<=27&&pt>=48&&pt<=52&&yi>=23&&yi<=27)Oe="1:2:1";else if(Pe>=48&&Pe<=52&&pt>=23&&pt<=27&&yi>=23&&yi<=27)Oe="2:1:1";else if(Pe>=23&&Pe<=27&&pt>=23&&pt<=27&&yi>=48&&yi<=52)Oe="1:1:2";else{const yr=Math.round(Pe),kr=Math.round(pt);Oe=`${yr}:${kr}:${100-yr-kr}`}}else Oe=wn.map(Pe=>Math.round(Pe)).join(":")}else ft=!1,Oe=Array.from({length:Ve},()=>1).join(":");const ts=Ve>=2?"cols-header":"two-cols";return{hasSuperBlock:!0,colCount:Ve,ratio:Oe,isCustomWidth:ft,recommendedLayout:ts}}function X(ee){if(!(ee!=null&&ee.blocks))return null;for(const be of ee.blocks){const Ae=be.rawNode;if(Ae&&lt(Ae)&&Qt(Ae)){const Ge=bn(Ae).length,Oe=cr(Ae);return{hasSuperBlock:!0,colCount:Ge,ratio:Oe||Array.from({length:Ge},()=>1).join(":"),isCustomWidth:!!Oe,recommendedLayout:Ge>=2?"cols-header":"two-cols"}}}return null}const Q=ye(()=>{var ee;if(typeof document<"u"){const be=o.value;if(be){const Ve=document.querySelector(`.protyle-wysiwyg [data-node-id="${be}"]`);if(Ve){const Ge=Ve.getAttribute("data-type")==="NodeSuperBlock"?Ve:Ve.closest('[data-type="NodeSuperBlock"]');if(Ge){const Oe=pe(Ge);if(Oe)return Oe}}}const Ae=d.value||(x.value?o.value:"");if(Ae){const Ve=document.querySelector(`.protyle-wysiwyg [data-node-id="${Ae}"]`);if(Ve){let Ge=Ve.nextElementSibling;for(;Ge&&!(Ge.getAttribute("data-type")==="NodeThematicBreak"||(ee=Ge.classList)!=null&&ee.contains("protyle-wysiwyg__block--hr"));){const Oe=Ge.getAttribute("data-type")==="NodeSuperBlock"?Ge:Ge.querySelector('[data-type="NodeSuperBlock"]');if(Oe){const ft=pe(Oe);if(ft)return ft}Ge=Ge.nextElementSibling}}}else{const Ve=document.querySelector('.protyle-wysiwyg [data-type="NodeThematicBreak"], .protyle-wysiwyg .protyle-wysiwyg__block--hr'),Ge=Array.from(document.querySelectorAll('.protyle-wysiwyg [data-type="NodeSuperBlock"]'));for(const Oe of Ge)if(!Ve||Oe.compareDocumentPosition(Ve)&Node.DOCUMENT_POSITION_FOLLOWING){const ft=pe(Oe);if(ft)return ft}}}return X(O.value)}),L=ye(()=>{var ee;return((ee=Q.value)==null?void 0:ee.ratio)||""}),j=ye(()=>{const ee=a.value||"";if(ee==="NodeSuperBlock"||ee==="s"||ee==="sb")return!0;if(typeof document<"u"&&o.value){const be=document.querySelector(`.protyle-wysiwyg [data-node-id="${o.value}"]`);if(be!=null&&be.closest('[data-type="NodeSuperBlock"]'))return!0}return!1}),v=ye(()=>{var ee;return((ee=O.value)==null?void 0:ee.pageIndex)||1}),U=ye(()=>!!(r.value[Ke]||r.value["slides-note"]));function W(){if(!p.value)return!1;if(o.value===p.value||typeof document>"u")return!0;const ee=document.querySelector(`.protyle-wysiwyg [data-node-id="${p.value}"]`)||document.querySelector(`[data-node-id="${p.value}"]`);if(!ee)return!1;const be=ee.querySelector(":scope > [data-node-id], :scope > div > [data-node-id]");return(be==null?void 0:be.getAttribute("data-node-id"))===o.value}const _=ye(()=>{var be;if(r.value[Re]!==void 0)return r.value[Re]||"";if(p.value&&W())return m.value||"";if(p.value)return"";const ee=o.value;if(ee&&((be=O.value)!=null&&be.blocks)){const Ae=O.value.blocks.find(Ve=>Ve.id===ee);if(Ae!=null&&Ae.clicks)return Ae.clicks}return""}),T=ye(()=>{var be;if(r.value[Jt])return r.value[Jt];const ee=o.value;if(ee&&((be=O.value)!=null&&be.blocks)){const Ae=O.value.blocks.find(Ve=>Ve.id===ee);if(Ae!=null&&Ae.motion)return typeof Ae.motion=="string"?Ae.motion:JSON.stringify(Ae.motion)}return""}),P=ye(()=>{var be;if(r.value[Me])return r.value[Me];const ee=o.value;if(ee&&((be=O.value)!=null&&be.blocks)){const Ae=O.value.blocks.find(Ve=>Ve.id===ee);if(Ae!=null&&Ae.slot)return Ae.slot}return""}),Y=ge(""),B=ge(""),z=ye(()=>r.value[Ni]==="true"),Z=ye(()=>r.value[ws]==="true"),ie=ye(()=>r.value[Xi]==="true"),oe=ye(()=>r.value[xs]!=="false"),me=ye(()=>{var ee,be;return((be=(ee=y.value)==null?void 0:ee.config)==null?void 0:be.theme)||r.value[Nn]||"default"}),$e=ye(()=>{var ee,be;return((be=(ee=y.value)==null?void 0:ee.config)==null?void 0:be.aspectRatio)||r.value[zn]||"16/9"}),xe=ye(()=>{var ee,be;return((be=(ee=y.value)==null?void 0:ee.config)==null?void 0:be.defaultTransition)||r.value[Hn]||"slide-left"}),De=ye(()=>{var ee,be;return((be=(ee=y.value)==null?void 0:ee.config)==null?void 0:be.spacing)||r.value[wo]||"normal"}),Ne=ye(()=>{var Ge,Oe;if((r.value[Ze]||r.value["slides-role"])===_a||r.value[st]==="true")return"background";const be=r.value[ke]||r.value["slides-layout"];if(be==="image-left"||be==="image-right")return be;const Ae=l.value||"",Ve=fi(Ae);if(Ve&&((Oe=(Ge=O.value)==null?void 0:Ge.frontmatter)!=null&&Oe.background)){const ft=O.value.frontmatter.background;if(ft===Ve||ft.endsWith(Ve)||Ve.endsWith(ft))return"background"}return""}),Fe=ye(()=>!!(r.value[Re]||r.value[Jt]||r.value[Me]||r.value[Gi]||r.value[Ke]||r.value["slides-note"]||r.value[Ze]||r.value[ke]||r.value[Ni]||r.value[ws]||r.value[Xi]||r.value[xs])),{saveAttr:le,savePageAttr:ue,applyPageLayoutAndRatio:Ye,applyCloverLayout:ze,resetSuperBlockWidth:je,saveDocAttr:ot,onToggleVideoAutoplay:ii,onToggleVideoLoop:Ys,onToggleVideoMuted:Zs,onToggleVideoControls:es,onImageRoleChange:Ai,onToggleNoteBlock:Ki,onAddNoteBlock:mc,onLocateNoteBlock:gc,onGenerateNotesWithAI:vc,isBatchProcessing:mr,onBatchAppendNotes:bc,onBatchDeleteNotes:yc,onIdentifyNotesBlocks:kc,onAutoAnimateDocument:wc,toggleElemClick:xc,onElemClickStepChange:Sc,onElemMotionChange:Cc,onElemSlotChange:_c,onElemShikiLinesChange:$c,onElemMaxHeightChange:Ic,onSetTwoColsContrast:Mc,onClearBlockAttrs:Tc,onInsertDividerBefore:Ec,onInsertDividerAfter:gr,onDeleteCurrentBlock:Ac,onExportHtml:Bc,onExportPdf:Dc,onExportImages:Lc,isExportingImages:Pc}=ww({activeBlockId:o,activeBlockType:a,activeBlockAttrs:r,rawSnippet:l,currentDocId:c,currentPageDividerId:d,currentPageDividerLayout:h,parentContainerId:p,parentContainerClicks:m,latestDoc:y,targetSlide:O,currentSlideNoteBlockId:G,currentSlideLayout:q,isNoteBlock:U,elemClick:_,videoAutoplay:z,videoLoop:Z,videoMuted:ie,videoControls:oe,pageBackground:H,pageImage:I,elemShikiLines:Y,elemMaxHeight:B,saveStatus:g,plugin:i});async function Oc(ee){if(ee==="clover"){if(!await ze())return}else ue(ke,ee)}function Rc(ee){ue(vt,ee)}async function Nc(ee){await ue(en,ee),(ee==="clockwise"||ee==="counter-clockwise"||ee==="cw"||ee==="ccw")&&(!Se.value||Se.value==="1:1")&&await ue(Fi,"1:1:1:1")}function zc(ee){ue(Fi,ee)}function Hc(ee){ue(tn,ee)}function Fc(ee){ue(nn,ee)}function vr(ee){if(!ee)return;const be=ee.recommendedLayout||(ee.colCount&&ee.colCount>=2?"cols-header":"two-cols"),Ae=ee.ratio||(ee.colCount?Array(ee.colCount).fill(1).join(":"):"1:1");Ye(be,Ae)}function jc(ee){ue(vt,ee)}async function Wc(){await je()}function Uc(ee){le(gt,ee)}function Vc(ee){H.value=ee,le(st,ee)}function Gc(ee){I.value=ee,le(Ot,ee)}function Kc(ee){le(Mn,ee==="inherit"?"":ee)}function qc(ee){ot(Nn,ee)}function Yc(ee){ot(zn,ee)}function Zc(ee){ot(Hn,ee)}function Jc(ee){ot(wo,ee)}function br(){i!=null&&i.openBottomPreviewTab&&i.openBottomPreviewTab()}function Xc(){i!=null&&i.openPresenterTab&&i.openPresenterTab()}function Qc(){i&&$t("aiScript")&&dc(i)}return t({setActiveBlock(ee){o.value=ee.id,a.value=ee.type,r.value={...ee.attrs},l.value=ee.content||ee.markdown||"",u.value=ee.topBlockId||ee.id,d.value=ee.pageDividerId||"",h.value=ee.pageDividerLayout||"",p.value=ee.parentContainerId||"",b.value=ee.parentContainerSlot||"",m.value=ee.parentContainerClicks||"",ee.rootId?c.value=ee.rootId:(ee.type==="doc"||ee.type==="NodeDocument")&&ee.id&&(c.value=ee.id),H.value=ee.attrs[st]||"",I.value=ee.attrs[Ot]||"",Y.value=ee.attrs[Gi]||"",B.value=ee.attrs[Fn]||"",E.value=!!ee.isImage},updateDocument(ee){y.value=ee,c.value=ee.docId},openImportDialog(){n.value=!0},setCurrentDocId(ee){c.value=ee}}),(ee,be)=>(J(),te("div",Cw,[f("div",_w,[f("div",$w,[(J(),te("svg",Iw,[...be[2]||(be[2]=[f("rect",{x:"2",y:"3",width:"20",height:"14",rx:"2"},null,-1),f("line",{x1:"8",y1:"21",x2:"16",y2:"21"},null,-1),f("line",{x1:"12",y1:"17",x2:"12",y2:"21"},null,-1)])])),be[3]||(be[3]=f("span",null,"演示配置",-1))]),f("div",Mw,[he($t)("import")?(J(),te("button",{key:0,class:"spm-icon-btn b3-tooltips b3-tooltips__sw","aria-label":"导入 Slidev 演示文档 (.md / .zip)",onClick:be[0]||(be[0]=Ae=>n.value=!0)},[ae(fe,{name:"import"}),be[4]||(be[4]=f("span",null,"导入",-1))])):Te("",!0),f("button",{class:"spm-icon-btn is-primary b3-tooltips b3-tooltips__sw","aria-label":"在下方分屏开启幻灯片预览 (Alt+P)",onClick:br},[ae(fe,{name:"split-preview"}),be[5]||(be[5]=f("span",null,"分屏预览",-1))])])]),f("div",Tw,[f("div",Ew,[f("span",{class:Ce(["spm-target-tag",V.value])},we($.value),3),f("span",{class:"spm-target-id b3-tooltips b3-tooltips__se","aria-label":w.value||"点击复制 ID: "+(o.value||c.value),onClick:S},[ae(fe,{name:"copy"}),f("span",null,"#"+we(N.value),1)],8,Aw)]),g.value?(J(),te("span",Bw,"● "+we(g.value),1)):Te("",!0)]),K.value?(J(),te("div",{key:0,class:"spm-context-quote",title:l.value},we(K.value),9,Dw)):Te("",!0),f("div",Lw,[x.value?(J(),Zt(w1,{key:0,"page-layout":k.value,"page-layout-ratio":he(se),"page-mask":he(re),"page-mask-ratio":he(Se),"page-mask-style":he(Ie),"page-mask-initial":he(_e),"detected-sb-ratio":L.value,"detected-sb-info":Q.value,"page-transition":F.value,"page-background":H.value,"page-spacing":A.value,"page-image":I.value,"page-notes":ne.value,"page-index":v.value,"onUpdate:pageLayout":Oc,"onUpdate:pageLayoutRatio":Rc,"onUpdate:pageMask":Nc,"onUpdate:pageMaskRatio":zc,"onUpdate:pageMaskStyle":Hc,"onUpdate:pageMaskInitial":Fc,onApplySuperBlockLayout:vr,onResetSuperblockRatio:Wc,"onUpdate:pageTransition":Uc,"onUpdate:pageBackground":Vc,"onUpdate:pageSpacing":Kc,"onUpdate:pageImage":Gc,onAddNoteBlock:he(mc),onLocateNoteBlock:he(gc),onGenerateNotes:he(vc),onBatchAppendNotes:he(bc),onBatchDeleteNotes:he(yc),"is-batch-processing":he(mr),onInsertDividerAfter:he(gr),onDeleteDivider:he(Ac)},null,8,["page-layout","page-layout-ratio","page-mask","page-mask-ratio","page-mask-style","page-mask-initial","detected-sb-ratio","detected-sb-info","page-transition","page-background","page-spacing","page-image","page-notes","page-index","onAddNoteBlock","onLocateNoteBlock","onGenerateNotes","onBatchAppendNotes","onBatchDeleteNotes","is-batch-processing","onInsertDividerAfter","onDeleteDivider"])):o.value&&!R.value?(J(),Zt(o0,{key:1,"elem-click":_.value,"elem-motion":T.value,"elem-slot":P.value,"elem-shiki-lines":Y.value,"elem-max-height":B.value,"is-code-block":M.value,"is-image":C.value,"is-video":D.value,"is-super-block":j.value,"detected-sb-info":Q.value,"video-autoplay":z.value,"video-loop":Z.value,"video-muted":ie.value,"video-controls":oe.value,"has-block-attrs":Fe.value,"is-note":U.value,"image-role":Ne.value,"current-slide-layout":q.value,"parent-elem-click":m.value,"parent-container-slot":b.value,"parent-container-id":p.value,onToggleNote:he(Ki),onToggleElemClick:he(xc),onToggleVideoAutoplay:he(ii),onToggleVideoLoop:he(Ys),onToggleVideoMuted:he(Zs),onToggleVideoControls:he(es),"onUpdate:imageRole":he(Ai),"onUpdate:elemClick":he(Sc),"onUpdate:elemMotion":he(Cc),"onUpdate:elemSlot":he(_c),"onUpdate:elemShikiLines":he($c),"onUpdate:elemMaxHeight":he(Ic),onApplySuperBlockLayout:vr,onApplySuperBlockRatio:jc,onInsertDividerBefore:he(Ec),onInsertDividerAfter:he(gr),onSetTwoColsContrast:he(Mc),onClearBlockAttrs:he(Tc)},null,8,["elem-click","elem-motion","elem-slot","elem-shiki-lines","elem-max-height","is-code-block","is-image","is-video","is-super-block","detected-sb-info","video-autoplay","video-loop","video-muted","video-controls","has-block-attrs","is-note","image-role","current-slide-layout","parent-elem-click","parent-container-slot","parent-container-id","onToggleNote","onToggleElemClick","onToggleVideoAutoplay","onToggleVideoLoop","onToggleVideoMuted","onToggleVideoControls","onUpdate:imageRole","onUpdate:elemClick","onUpdate:elemMotion","onUpdate:elemSlot","onUpdate:elemShikiLines","onUpdate:elemMaxHeight","onInsertDividerBefore","onInsertDividerAfter","onSetTwoColsContrast","onClearBlockAttrs"])):(J(),Zt(nk,{key:2,"doc-theme":me.value,"doc-aspect-ratio":$e.value,"doc-default-transition":xe.value,"doc-spacing":De.value,"is-exporting-images":he(Pc),"is-batch-processing":he(mr),"onUpdate:docTheme":qc,"onUpdate:docAspectRatio":Yc,"onUpdate:docDefaultTransition":Zc,"onUpdate:docSpacing":Jc,onOpenBottomPreview:br,onOpenPresenter:Xc,onIdentifyNotes:he(kc),onAutoAnimate:he(wc),onAiAutoSplit:Qc,onExportHtml:he(Bc),onExportPdf:he(Dc),onExportImages:he(Lc)},null,8,["doc-theme","doc-aspect-ratio","doc-default-transition","doc-spacing","is-exporting-images","is-batch-processing","onIdentifyNotes","onAutoAnimate","onExportHtml","onExportPdf","onExportImages"]))]),n.value&&he($t)("import")?(J(),Zt(sw,{key:1,onClose:be[1]||(be[1]=Ae=>n.value=!1),onSuccess:s})):Te("",!0)]))}}),Ow=2e3,Rw=600;function Nw(e){return!e||typeof e.closest!="function"?!1:!!e.closest(".fn__none")}function mo(e){if(!e||typeof e.isConnected=="boolean"&&!e.isConnected)return!1;if(ma(e))return!0;const t=e.firstElementChild;return!!(t&&ma(t))}function ma(e){return typeof e.getClientRects=="function"&&e.getClientRects().length>0?!0:typeof e.offsetWidth=="number"&&e.offsetWidth>0&&e.offsetHeight>0}function zw(){const e=typeof globalThis<"u"?globalThis.IntersectionObserver:void 0;return typeof e=="function"?e:void 0}class Hw{constructor(){ve(this,"consumers",new Map);ve(this,"seq",0);ve(this,"verifyTimer",null)}register(t,i,n){if(!i)return()=>{};const s=++this.seq,o=zw(),a={kind:t,element:i,visible:!1,measureOnDemand:!o,observer:null,onVisible:n};return o?(a.observer=new o(r=>{var u;const l=r[r.length-1];if(!l)return;const c=l.isIntersecting&&!a.visible;a.visible=l.isIntersecting,c&&((u=a.onVisible)==null||u.call(a))}),a.observer.observe(i)):a.visible=mo(i),this.consumers.set(s,a),()=>{var r;(r=a.observer)==null||r.disconnect(),this.consumers.delete(s),this.consumers.size===0&&this.stopVerifyTimer()}}clear(){var t;for(const i of this.consumers.values())(t=i.observer)==null||t.disconnect();this.consumers.clear(),this.stopVerifyTimer()}get size(){return this.consumers.size}getVisibility(){if(this.consumers.size===0)return"none";if(typeof document<"u"&&document.visibilityState==="hidden")return"hidden";for(const t of this.consumers.values())if(t.measureOnDemand?mo(t.element):this.isRecordVisible(t))return"visible";return this.ensureVerifyTimer(),"hidden"}hasVisibleConsumer(){return this.getVisibility()==="visible"}isRecordVisible(t){return t.visible?!0:!Nw(t.element)}ensureVerifyTimer(){if(this.verifyTimer!==null||typeof setTimeout!="function")return;let t=!1;for(const i of this.consumers.values())if(!i.measureOnDemand){t=!0;break}t&&(this.verifyTimer=setTimeout(()=>{var i;this.verifyTimer=null;for(const n of this.consumers.values())if(!n.visible&&mo(n.element)){n.visible=!0,(i=n.onVisible)==null||i.call(n);return}},Ow))}stopVerifyTimer(){this.verifyTimer!==null&&(clearTimeout(this.verifyTimer),this.verifyTimer=null)}}const bs=new Hw,yn=new Qn;function uc(e,t,i){const n=()=>{var o;try{(o=i==null?void 0:i.flushDirtyCompile)==null||o.call(i)}catch{}},s=bs.register(e,t,n);return n(),s}let Ci=null,Dt=null,ys=null;function Fw(){return Dt}function jw(e,t){Ci&&fc(),Ci=ar(Pg),Ci.provide("plugin",t),Ci.provide("sandboxBridge",yn);const i=Ci.mount(e);return Dt=i,ys=uc("preview",e,t),i}function fc(e){ys&&(ys(),ys=null),Ci&&(Ci.unmount(),Ci=null,Dt=null)}function Ww(){return Dt!==null}let _i=null,Hi=null;function Uw(e,t){return _i&&pc(),_i=ar(Vv),_i.provide("plugin",t),_i.provide("sandboxBridge",yn),Hi=_i.mount(e),Hi}function pc(e){_i&&(_i.unmount(),_i=null,Hi=null)}function Vw(e){try{const t=new BroadcastChannel("siyuan-slides-sync");t.postMessage({type:"SYNC_SLIDES",slides:e.slides||[],config:e.config||{}}),t.close()}catch{}}let $i=null,It=null,ks=null;function Gw(e,t){$i&&hc(),$i=ar(Pw),$i.provide("plugin",t),$i.provide("sandboxBridge",yn);const i=$i.mount(e);return It=i,ks=uc("dock",e,t),i}function hc(e){ks&&(ks(),ks=null),$i&&($i.unmount(),$i=null,It=null)}function Kw(e,t){It!=null&&It.updateDocument&&It.updateDocument(e),Dt!=null&&Dt.updateDocument?Dt.updateDocument(e,t):(yn.updateSlides(e.slides,e.config,e.fullMarkdown),Vw(e)),Hi!=null&&Hi.updateDocument&&Hi.updateDocument(e)}function Fo(e){Dt!=null&&Dt.navigateToBlock?Dt.navigateToBlock(e):yn.highlightElement(e)}function Ji(e){It!=null&&It.setActiveBlock&&It.setActiveBlock(e)}function qw(){return ai("import")?!1:It!=null&&It.openImportDialog?(It.openImportDialog(),!0):!1}const Yw=[{id:"slides-cover",name:"幻灯片 - 封面页 (Cover)",open:!0,attrs:[{key:Ri,value:"true"},{key:ke,value:"cover"},{key:gt,value:"fade"}]},{id:"slides-two-cols",name:"幻灯片 - 双栏对比 (Two Columns)",open:!0,attrs:[{key:Ri,value:"true"},{key:ke,value:"two-cols"},{key:gt,value:"slide-left"}]},{id:"slides-fact",name:"幻灯片 - 大字报与核心指标 (Fact)",open:!0,attrs:[{key:Ri,value:"true"},{key:ke,value:"fact"},{key:gt,value:"zoom"}]},{id:"slides-intro",name:"幻灯片 - 章节导引与作者 (Intro)",open:!0,attrs:[{key:Ri,value:"true"},{key:ke,value:"intro"},{key:gt,value:"slide-up"}]},{id:"slides-quote",name:"幻灯片 - 金句与强调 (Quote)",open:!0,attrs:[{key:Ri,value:"true"},{key:ke,value:"quote"},{key:gt,value:"fade"}]},{id:"slides-elem-click",name:"元素 - 顺延逐步呈现 (v-click)",open:!0,attrs:[{key:Re,value:"+1"}]},{id:"slides-elem-click-hide",name:"元素 - 隐藏直到激活 (v-click:hide)",open:!0,attrs:[{key:Re,value:"hide"}]},{id:"slides-elem-slot-right",name:"元素 - 双栏右栏归属 (Slot: Right)",open:!0,attrs:[{key:Me,value:"right"}]},{id:"slides-shiki-lines",name:"代码 - 逐行聚光高亮 (Shiki)",open:!0,attrs:[{key:Gi,value:"1-3"}]}];class go{getPresetTemplates(){return Yw}buildScanSlidesBlocksSql(t="custom-slides-"){return`SELECT block_id, name, value FROM attributes WHERE name LIKE '${t}%' ORDER BY block_id ASC`}buildTransitionStatsSql(){return`SELECT value, count(1) as count FROM attributes WHERE name = '${gt}' GROUP BY value ORDER BY count DESC`}async batchUpdateTransitions(t,i,n,s){const o=`SELECT block_id FROM attributes WHERE name = '${gt}' AND value = '${t}'`,a=await n(o);let r=0;if(Array.isArray(a))for(const l of a){const c=l.block_id||l.blockId;c&&(await s(c,{[gt]:i}),r++)}return{updatedCount:r}}async batchUpdateLayout(t,i,n,s){const o=`SELECT block_id FROM attributes WHERE name = '${ke}' AND value = '${t}'`,a=await n(o);let r=0;if(Array.isArray(a))for(const l of a){const c=l.block_id||l.blockId;c&&(await s(c,{[ke]:i}),r++)}return{updatedCount:r}}exportTemplatesJson(){const t=this.getPresetTemplates();return JSON.stringify({templates:t,counter:t.length},null,2)}formatTransitionSummary(t){return!t||t.length===0?"全库目前暂无已设置即现转场效果的块":`全库即现转场分布统计：${t.map(n=>`${n.value}: ${n.count} 个`).join("，")}`}}function Zw(e){if(e.addCommand({langKey:"slidesPresentation",langText:"即现: 在文档下方开启分屏演示预览",hotkey:"⌥P",enabled:()=>!0,execute:()=>{e.openBottomPreviewTab()}}),ai("import")||e.addCommand({langKey:"slidesImport",langText:"即现: 导入 Slidev 演示文档 (.md / .zip)",hotkey:"⌥I",enabled:()=>!0,execute:()=>{qw()||de.showMessage("请先在右侧栏打开「即现演示配置」Dock 面板以呼起导入窗口")}}),e.addCommand({langKey:"slidesInitAttrs",langText:"即现: 初始化当前文档演示属性",hotkey:"",enabled:()=>!0,execute:async()=>{if(!e.currentDocId){const t=document.querySelector(".protyle-content[data-doc-id]");e.currentDocId=(t==null?void 0:t.getAttribute("data-doc-id"))||""}e.currentDocId&&(await He(e.currentDocId,{"custom-slides-theme":"default","custom-slides-aspect-ratio":"16/9","custom-slides-default-transition":"slide-left"}),de.showMessage("已为当前文档初始化即现演示属性"),e.compileCurrentDocument(e.currentDocId))}}),ai("aiScript")||e.addCommand({langKey:"slidesAiSplit",langText:"即现 AI: 智能大纲断页建议与自动分页",hotkey:"",enabled:()=>!0,execute:()=>dc(e)}),ai("aiScript")||e.addCommand({langKey:"slidesAiNotes",langText:"即现 AI: 自动为当前文档生成演讲者提词卡 (Notes)",hotkey:"",enabled:()=>!0,execute:async()=>{var l,c,u,d;if(!e.currentDocId){const h=document.querySelector(".protyle-content[data-doc-id]");e.currentDocId=(h==null?void 0:h.getAttribute("data-doc-id"))||""}if(!e.currentDocId){de.showMessage("请先打开一篇思源笔记文档");return}de.showMessage("正在调用思源 AI 提炼演讲者口播提词...");const t=await Yn(e.currentDocId).catch(()=>[]),i={startBlockId:e.currentDocId,blocks:t.map(h=>({id:h.id,type:h.type,content:h.content||"",rawMarkdown:h.markdown||""})),rawMarkdown:""},o=`> [!NOTE] 💡 演讲备注
${(await cw(i,ka)).split(/\r?\n/).map(h=>`> ${h}`).join(`
`)}
{: custom-slides-note="true"}`,a=await bo("markdown",o,e.currentDocId).catch(()=>null),r=((u=(c=(l=a==null?void 0:a[0])==null?void 0:l.doOperations)==null?void 0:c[0])==null?void 0:u.id)||((d=a==null?void 0:a[0])==null?void 0:d.id);r&&(await He(r,{"custom-slides-note":"true"}),Le.setBlockAttrOverride(r,{"custom-slides-note":"true"}),Vi(r,e.app)),de.showMessage("已成功生成口播提词卡并插入为正文讲稿备注块"),e.compileCurrentDocument(e.currentDocId)}}),e.addCommand({langKey:"slidesIdentifyNotes",langText:"即现演示: 识别正文讲稿块并规范化",hotkey:"",enabled:()=>!0,execute:async()=>{let t=e.currentDocId;if(!t){const i=document.querySelector(".protyle-content[data-doc-id]");t=(i==null?void 0:i.getAttribute("data-doc-id"))||"",t&&(e.currentDocId=t)}if(!t){de.showMessage("请先在主编辑区打开幻灯片文档");return}await lc(t,{compileFn:async()=>{await e.compileCurrentDocument(t)}})}}),e.addCommand({langKey:"slidesAutoAnimate",langText:"即现演示: 智能配置演示动效",hotkey:"",enabled:()=>!0,execute:async()=>{let t=e.currentDocId;if(!t){const i=document.querySelector(".protyle-content[data-doc-id]");t=(i==null?void 0:i.getAttribute("data-doc-id"))||"",t&&(e.currentDocId=t)}if(!t){de.showMessage("请先在主编辑区打开幻灯片文档");return}await cc(t,{compileCurrentDocFn:async()=>{await e.compileCurrentDocument(t)}})}}),e.addCommand({langKey:"slidesBatchTransitions",langText:"即现协同: 统计全库转场效果分布",hotkey:"",enabled:()=>!0,execute:async()=>{const t=new go,i=t.buildTransitionStatsSql(),n=await dn(i).catch(()=>[]),s=t.formatTransitionSummary(n||[]);de.showMessage(s)}}),e.addCommand({langKey:"slidesExportTemplates",langText:"即现协同: 复制即现预设属性模板至剪贴板",hotkey:"",enabled:()=>!0,execute:async()=>{const i=new go().exportTemplatesJson();typeof navigator<"u"&&navigator.clipboard?(await navigator.clipboard.writeText(i),de.showMessage("已将即现属性模板 JSON 复制至剪贴板，可直接导入属性管家")):de.showMessage(`已生成模板数据（请在控制台查看）：
`+i)}}),e.addCommand({langKey:"slidesBatchReplaceTransition",langText:"即现协同: 批量替换全库淡入淡出转场为滑动 (fade -> slide-left)",hotkey:"",enabled:()=>!0,execute:async()=>{const i=await new go().batchUpdateTransitions("fade","slide-left",n=>dn(n).catch(()=>[]),(n,s)=>He(n,s));de.showMessage(`全库批量替换完成：已将 ${i.updatedCount} 处 fade 转场更新为 slide-left`),e.compileCurrentDocument()}}),ai("presenterMode")||e.addCommand({langKey:"slidesPresenterMode",langText:"即现: 打开双屏演讲者控制台 (Presenter Mode)",hotkey:"⌥M",enabled:()=>!0,execute:()=>{e.openPresenterTab()}}),ai("proMode")||(e.addCommand({langKey:"slidesExportCliMd",langText:"即现 Pro: 导出 Slidev 标准 slides.md 文档 (下载到本地)",hotkey:"",enabled:()=>!0,execute:async()=>{if(e.latestCompiledDoc||await e.compileCurrentDocument(),!e.latestCompiledDoc){de.showMessage("请先打开并放映一篇思源笔记文档");return}e.cliBridge.downloadSlidesMd(e.latestCompiledDoc,`slides-${e.currentDocId||"demo"}.md`)&&de.showMessage("已生成标准 Slidev Markdown 并触发下载，可在本地使用 npx @slidev/cli 运行")}}),e.addCommand({langKey:"slidesProbeCliDevServer",langText:"即现 Pro: 检测本地 Slidev CLI DevServer 状态 (localhost:3030)",hotkey:"",enabled:()=>!0,execute:async()=>{de.showMessage("正在探测本地 Slidev CLI DevServer (http://localhost:3030)..."),await e.cliBridge.probeServer(1500)?de.showMessage("🟢 本地 Slidev CLI DevServer 运行正常！可直接在浏览器访问 http://localhost:3030"):de.showMessage("⚪ 未检测到运行中的本地 Slidev CLI DevServer (端口 3030 未开启)")}}),e.addCommand({langKey:"slidesSyncToCliWorkspace",langText:"即现 Pro: 同步 slides.md 至思源工作空间存储目录",hotkey:"",enabled:()=>!0,execute:async()=>{if(e.latestCompiledDoc||await e.compileCurrentDocument(),!e.latestCompiledDoc){de.showMessage("请先打开并放映一篇思源笔记文档");return}const t=await e.cliBridge.syncToWorkspaceFile(e.latestCompiledDoc,"/data/storage/petal/siyuan-live-slides/slides.md",ko);t.success?de.showMessage(`已成功同步最新 slides.md 至工作空间：${t.path}`):de.showMessage(`同步失败：${t.error}`)}})),!ai("exportImage")){let t=!1;e.addCommand({langKey:"slidesExportImagesZip",langText:"即现: 逐页导出幻灯片为高清图片包 (ZIP)",hotkey:"",enabled:()=>!0,execute:async()=>{if(t){de.showMessage("正在导出图片中，请稍候...",2e3);return}if(e.latestCompiledDoc||await e.compileCurrentDocument(),!e.latestCompiledDoc){de.showMessage("请先打开并放映一篇思源笔记文档");return}t=!0;try{de.showMessage("正在启动后台沙箱并逐页导出幻灯片图片...");const i=e.latestCompiledDoc,n=await Mi(i,e.currentDocId,e),s=await tc(i,{title:n,onProgress:(o,a)=>{de.showMessage(`正在导出幻灯片图片 (${o} / ${a})...`,2e3)}});s.success?de.showMessage(`🎉 成功导出 ${s.total||0} 张幻灯片高清图片并已保存为 ${n}.zip！`,4e3):de.showMessage(`导出图片失败：${s.error||"未知异常"}`)}finally{t=!1}}})}}class Jw{constructor(t=400){ve(this,"entries",new Map);this.ttlMs=t}get(t,i=Date.now()){if(!t)return;const n=this.entries.get(t);if(n){if(i-n.at>this.ttlMs){this.entries.delete(t);return}return n.attrs}}set(t,i,n=Date.now()){!t||!i||this.entries.set(t,{attrs:i,at:n})}invalidate(t){t?this.entries.delete(t):this.entries.clear()}get size(){return this.entries.size}}function Xw(e){const t=new Map;if(!(e!=null&&e.slides))return t;const i=n=>{for(const s of n||[])s!=null&&s.id&&s.ial&&t.set(s.id,s.ial)};for(const n of e.slides)i(n.blocks),i(n.noteBlocks);return t}class Qw{constructor(t=150){ve(this,"lastBlockId","");ve(this,"lastAt",0);this.windowMs=t}shouldSkip(t,i=Date.now()){return t&&t===this.lastBlockId&&i-this.lastAt<this.windowMs?!0:(this.lastBlockId=t,this.lastAt=i,!1)}reset(){this.lastBlockId="",this.lastAt=0}}class e2{constructor(){ve(this,"attrCache",new Jw);ve(this,"compiledIalIndex",{doc:null,map:new Map});ve(this,"locatingLockUntil",0);ve(this,"lockedTargetBlockId","");ve(this,"lastKnownPageDividerId","");ve(this,"lastKnownDocId","")}isLocatingLocked(t){return Date.now()<this.locatingLockUntil?!(t&&t===this.lockedTargetBlockId):!1}async resolveBlockAttrs(t,i){if(!t)return{};const n=Le.getBlockAttrOverride(t),s=this.getCompiledIal(i,t);if(n||s)return{...s||{},...n||{}};const o=this.attrCache.get(t);if(o)return o;const a=await jo(t).catch(()=>({}))||{};return this.attrCache.set(t,a),a}getCompiledIal(t,i){if(t)return this.compiledIalIndex.doc!==t&&(this.compiledIalIndex={doc:t,map:Xw(t)}),this.compiledIalIndex.map.get(i)}invalidateAttrCache(t){this.attrCache.invalidate(t)}getActiveDocumentId(){if(typeof document>"u")return"";const t=document.querySelector(".layout__wnd--active .protyle-title[data-node-id]")||document.querySelector(".item--focus .protyle-title[data-node-id]")||document.querySelector(".protyle-title[data-node-id]"),i=t==null?void 0:t.getAttribute("data-node-id");if(i)return i;const n=document.querySelector(".protyle .protyle-title[data-node-id]"),s=n==null?void 0:n.getAttribute("data-node-id");if(s)return s;const o=document.querySelector("[data-doc-id]"),a=o==null?void 0:o.getAttribute("data-doc-id");return a||""}resolveDocIdFromElement(t,i=""){const n=t.closest(".protyle-title"),s=n==null?void 0:n.getAttribute("data-node-id");if(s)return s;const o=t.closest(".protyle"),a=o==null?void 0:o.querySelector(".protyle-title"),r=a==null?void 0:a.getAttribute("data-node-id");if(r)return r;const l=t.closest("[data-doc-id]"),c=l==null?void 0:l.getAttribute("data-doc-id");if(c)return c;const u=this.getActiveDocumentId();return u||i}async switchToDocGlobalInspector(t,i){var o;if(!t)return;let n=i||"";if(!n&&typeof document<"u"){const a=document.querySelector(`.protyle-title[data-node-id="${t}"] .protyle-title__input`)||document.querySelector(`.protyle[data-doc-id="${t}"] .protyle-title__input`)||document.querySelector(".protyle-title__input");n=((o=a==null?void 0:a.innerText)==null?void 0:o.trim())||""}const s=await this.resolveBlockAttrs(t,null);Ji({id:t,rootId:t,type:"doc",content:n,attrs:s,isDivider:!1,isCode:!1}),Fo(t)}handleBlockClickedFromSlide(t,i,n,s,o){var c,u,d,h;if(!t){Rn();const p=typeof o=="number"&&o>0?o:1,b=((c=s==null?void 0:s.slides)==null?void 0:c[p-1])||((u=s==null?void 0:s.slides)==null?void 0:u[0]);if(b){const m=b.startBlockId||"",y=((d=b.frontmatter)==null?void 0:d.layout)||"",g={"custom-slides-layout":y,...b.frontmatter};return Ji({id:m,rootId:n,type:"NodeThematicBreak",attrs:g,isDivider:!0,isCode:!1,isImage:!1,pageDividerId:m,pageDividerLayout:y}),this.resolveBlockAttrs(m,s).then(w=>{w&&Object.keys(w).length>0&&Ji({id:m,rootId:n,type:"NodeThematicBreak",attrs:{...g,...w},isDivider:!0,isCode:!1,isImage:!1,pageDividerId:m,pageDividerLayout:y})}),!0}else return this.switchToDocGlobalInspector(n),!0}this.lockedTargetBlockId=t,this.locatingLockUntil=Date.now()+500;const a=Vi(t,i),r=typeof document<"u"?document.querySelector(`.protyle-wysiwyg [data-node-id="${t}"]`)||document.querySelector(`[data-node-id="${t}"]`):null,l=(r==null?void 0:r.getAttribute("data-type"))||"";if(r)this.syncInspectorBlock(r,t,l,n,s);else{let p="",b="";if(s!=null&&s.slides){const m=s.slides.find(y=>{var g,w,S;return y.startBlockId===t||((g=y.blocks)==null?void 0:g.some(x=>x.id===t))||((w=y.allBlockIds)==null?void 0:w.includes(t))||((S=y.noteBlocks)==null?void 0:S.some(x=>x.id===t))});m!=null&&m.startBlockId&&(p=m.startBlockId),(h=m==null?void 0:m.frontmatter)!=null&&h.layout&&(b=m.frontmatter.layout)}this.resolveBlockAttrs(t,s).then(async m=>{if(p&&!b){const y=Le.getBlockAttrOverride(p);if(y!=null&&y[ke]||y!=null&&y["custom-slides-layout"])b=y[ke]||y["custom-slides-layout"]||"";else{const g=await this.resolveBlockAttrs(p,s);b=g[ke]||g["custom-slides-layout"]||"",g&&Object.keys(g).length>0&&Le.setBlockAttrOverride(p,g)}}Ji({id:t,rootId:n,type:l||"NodeParagraph",attrs:m||{},pageDividerId:p,pageDividerLayout:b})}).catch(()=>{})}return a}async syncInspectorBlock(t,i,n,s,o){var F,H,I,A,O,ne,G,q,ce;if(this.isLocatingLocked(i))return;let a=t,r=i,l=n;const c=typeof(t==null?void 0:t.closest)=="function"?t.closest('[data-type="NodeCallout"]'):null;if(c&&c!==t){const se=c.getAttribute("data-node-id");if(se){const re=await this.resolveBlockAttrs(se,o),Se=Le.getBlockAttrOverride(se)||{},Ie={...re,...Se};(Ie[Ke]||Ie["slides-note"])&&(a=c,r=se,l="NodeCallout")}}const u=a.closest(".protyle-wysiwyg > [data-node-id]")||a,d=(u==null?void 0:u.getAttribute("data-node-id"))||r,h=l==="NodeThematicBreak"||l==="tb"||l==="thematic-break"||(u==null?void 0:u.getAttribute("data-type"))==="NodeThematicBreak"||(u==null?void 0:u.getAttribute("data-type"))==="tb"||!!((F=u==null?void 0:u.classList)!=null&&F.contains("hr")),p=l==="NodeCodeBlock",b=((H=a.innerText)==null?void 0:H.trim())||"",m=await this.resolveBlockAttrs(r,o),y=Le.getBlockAttrOverride(r)||{},g={...m,...y};let w="",S="";if(h)w=r,S=g[ke]||g["custom-slides-layout"]||"";else{let se=u.previousElementSibling;for(;se;){const re=se.getAttribute("data-type");if(re==="NodeThematicBreak"||re==="tb"||(I=se.classList)!=null&&I.contains("hr")){w=se.getAttribute("data-node-id")||"";break}se=se.previousElementSibling}}if(o!=null&&o.slides){const se=[r,d];let re=a.parentElement;for(;re&&!re.classList.contains("protyle-wysiwyg");){const Ie=re.getAttribute("data-node-id");Ie&&!se.includes(Ie)&&se.push(Ie),re=re.parentElement}const Se=o.slides.find(Ie=>{var _e,pe,X;return se.includes(Ie.startBlockId)||((_e=Ie.blocks)==null?void 0:_e.some(Q=>se.includes(Q.id)))||((pe=Ie.allBlockIds)==null?void 0:pe.some(Q=>se.includes(Q)))||((X=Ie.noteBlocks)==null?void 0:X.some(Q=>se.includes(Q.id)))});Se&&(!w&&Se.startBlockId&&(w=Se.startBlockId),!S&&((A=Se.frontmatter)!=null&&A.layout)&&(S=Se.frontmatter.layout))}if(w?(this.lastKnownDocId=s,this.lastKnownPageDividerId=w):s&&this.lastKnownDocId===s&&this.lastKnownPageDividerId&&(!u.previousElementSibling&&(((O=u.parentElement)==null?void 0:O.scrollTop)||0)===0||(w=this.lastKnownPageDividerId)),w){const se=Le.getBlockAttrOverride(w);if(se&&(ke in se||"custom-slides-layout"in se)&&(S=se[ke]||se["custom-slides-layout"]||""),!S&&(o!=null&&o.slides)){const re=o.slides.find(Se=>Se.startBlockId===w);(ne=re==null?void 0:re.frontmatter)!=null&&ne.layout&&(S=re.frontmatter.layout)}if(!S){const re=await this.resolveBlockAttrs(w,o);S=re[ke]||re["custom-slides-layout"]||"",re&&Object.keys(re).length>0&&Le.setBlockAttrOverride(w,re)}et(w,{[ke]:S||""})}else if(s){const se=Le.getBlockAttrOverride(s);se&&(ke in se||"custom-slides-layout"in se)?S=se[ke]||se["custom-slides-layout"]||"":!S&&((ce=(q=(G=o==null?void 0:o.slides)==null?void 0:G[0])==null?void 0:q.frontmatter)!=null&&ce.layout)&&(S=o.slides[0].frontmatter.layout)}const x=a.getAttribute(ke)||a.getAttribute("custom-slides-layout"),M=g[ke]||g["custom-slides-layout"]||"";x&&x!==M&&et(r,{[ke]:M});const E=a.getAttribute(Ze)||a.getAttribute("custom-slides-role"),C=g[Ze]||g["custom-slides-role"]||"";E&&E!==C&&et(r,{[Ze]:C});let D="",R="",N="";const K=a.closest('[data-type="NodeListItem"]');if(K&&K!==a){const se=K.getAttribute("data-node-id");if(se){D=se;const re=await this.resolveBlockAttrs(se,o),Se=Le.getBlockAttrOverride(se)||{},Ie={...re,...Se};R=Ie[Me]||"",N=Ie[Re]||"";const _e=Ie[ke]||Ie["custom-slides-layout"]||"",pe=K.getAttribute(ke)||K.getAttribute("custom-slides-layout");pe&&pe!==_e&&et(se,{[ke]:_e});const X=Ie[Ze]||Ie["custom-slides-role"]||"",Q=K.getAttribute(Ze)||K.getAttribute("custom-slides-role");Q&&Q!==X&&et(se,{[Ze]:X})}}const $=!!a.querySelector("img, span[data-type='img']"),V=(a.innerText||"").replace(/[\r\n\t\s]+/g," ").trim(),k=$&&V.length<=50;Ji({id:r,rootId:s,type:l,content:b,attrs:g,isDivider:h,isCode:p,isImage:k,topBlockId:d,pageDividerId:w,pageDividerLayout:S,parentContainerId:D,parentContainerSlot:R,parentContainerClicks:N})}patchThematicBreakTransactions(t){if((t==null?void 0:t.cmd)==="transactions"&&Array.isArray(t.data)){for(const i of t.data)if(Array.isArray(i==null?void 0:i.doOperations)){for(const n of i.doOperations)if((n==null?void 0:n.action)==="updateAttrs"&&n.id&&n.data){const s=n.data.old||{},o=n.data.new||{},a={};for(const r of Object.keys(s))r in o||(a[r]="");for(const[r,l]of Object.entries(o))a[r]=String(l??"");et(n.id,a),Le.setBlockAttrOverride(n.id,a)}}}}purgeStaleDomSlidesAttrs(t){var s,o,a;if(typeof document>"u"||!t)return;const i=new Map;if(Array.isArray(t.slides))for(const r of t.slides){if(r.startBlockId){const l=i.get(r.startBlockId)||{};(s=r.frontmatter)!=null&&s.layout&&(l[ke]=r.frontmatter.layout),i.set(r.startBlockId,l)}if(Array.isArray(r.blocks)){for(const l of r.blocks)if(l.id){const c=i.get(l.id)||{};(o=l.ial)!=null&&o[ke]&&(c[ke]=l.ial[ke]),(a=l.ial)!=null&&a[Ze]&&(c[Ze]=l.ial[Ze]),Object.keys(c).length>0&&i.set(l.id,c)}}}const n=Le.getAllAttrOverrides();for(const[r,l]of n.entries()){const c=i.get(r)||{};l[ke]!==void 0&&(c[ke]=l[ke]),l[Ze]!==void 0&&(c[Ze]=l[Ze]),i.set(r,c)}rw(i)}}const wi=new e2;class t2{constructor(){ve(this,"state","IDLE");ve(this,"inFlightDocId",null);ve(this,"pendingDocs",new Set);ve(this,"lastPendingDocId",null);ve(this,"generation",0)}get currentState(){return this.state}get isRunning(){return this.state==="COMPILING"}get runningDocId(){return this.inFlightDocId}get pending(){return this.lastPendingDocId}get pendingList(){return Array.from(this.pendingDocs)}tryBegin(t){return this.state==="COMPILING"||this.inFlightDocId!==null?(this.pendingDocs.add(t),this.lastPendingDocId=t,null):(this.state="COMPILING",this.inFlightDocId=t,++this.generation)}isStale(t){return t!==this.generation}finishBatch(){this.state="IDLE",this.inFlightDocId=null,this.lastPendingDocId=null;const t=Array.from(this.pendingDocs);return this.pendingDocs.clear(),t}finish(){const t=this.finishBatch();return t.length>0?t[t.length-1]:null}reset(){this.state="IDLE",this.inFlightDocId=null,this.pendingDocs.clear(),this.lastPendingDocId=null,this.generation=0}}const i2=150,n2=`<symbol id="iconSlides" viewBox="0 0 1024 1024">
  <path fill="currentColor" d="M128 160h768c35.3 0 64 28.7 64 64v480c0 35.3-28.7 64-64 64H128c-35.3 0-64-28.7-64-64V224c0-35.3 28.7-64 64-64z m64 64v480h640V224H192z m128 640h384v64H320z"/>
  <path fill="currentColor" d="M416 336l256 144-256 144z"/>
</symbol>`,s2="slides-dock",vo="slides-preview-tab",ga="slides-presenter-tab",va=Wf;class o2 extends de.Plugin{constructor(){super(...arguments);ve(this,"isMobile",!1);ve(this,"currentDocId","");ve(this,"previewTab",null);ve(this,"latestCompiledDoc",null);ve(this,"cliBridge",new ur);ve(this,"debounceTimer",null);ve(this,"activeCursorBlockId","");ve(this,"cancelledCursorBlockId","");ve(this,"compileScheduler",new t2);ve(this,"dirtyDocId",null);ve(this,"inspectorSyncThrottle",new Qw);ve(this,"onSwitchProtyleBound",this.onSwitchProtyle.bind(this));ve(this,"onWsMainBound",this.onWsMain.bind(this));ve(this,"onBlockClickedBound",this.onBlockClickedFromSlide.bind(this));ve(this,"onEditorClickBound",this.onEditorClick.bind(this));ve(this,"onSelectionChangeBound",this.onSelectionChange.bind(this));ve(this,"onClickEditorContentBound",this.onClickEditorContent.bind(this));ve(this,"onVisibilityChangeBound",this.onVisibilityChange.bind(this))}async onload(){const i=de.getFrontend();this.isMobile=i==="mobile"||i==="browser-mobile",await this.loadGlobalSettings(),this.addIcons(n2),this.addTopBar({id:"slides-topbar-play",icon:"iconSlides",title:"即现演示",position:"right",callback:()=>{this.openBottomPreviewTab()}}),Zw(this);const n=this;if(this.addTab({type:vo,init(s){var r;const o=this||s;n.previewTab=(o==null?void 0:o.tab)||null,jw(o.element,n);const a=(r=o==null?void 0:o.data)==null?void 0:r.docId;a&&!n.getActiveDocumentId()&&n.compileCurrentDocument(a,{reason:"explicit"}),n.updatePreviewTabHeader()},destroy(){n.previewTab===(this==null?void 0:this.tab)&&(n.previewTab=null),fc(this.element)}}),this.addTab({type:ga,init(s){Uw((this||s).element,n)},destroy(){pc(this.element)}}),this.addDock({config:{position:"RightTop",size:{width:320,height:0},icon:"iconSlides",title:"即现演示配置"},data:{},type:s2,init(){Gw(this.element,n)},destroy(){hc(this.element)}}),this.eventBus&&typeof this.eventBus.emit!="function"&&(this.eventBus.emit=(s,o)=>{try{typeof window<"u"&&window.dispatchEvent(new CustomEvent(`siyuan-event-${s}`,{detail:o}))}catch{}}),this.eventBus.on("switch-protyle",this.onSwitchProtyleBound),this.eventBus.on("ws-main",this.onWsMainBound),this.eventBus.on("slides:request-compile",()=>this.compileCurrentDocument()),this.eventBus.on("slides:block-clicked",this.onBlockClickedBound),this.eventBus.on("click-editorcontent",this.onClickEditorContentBound),typeof document<"u"&&(document.addEventListener("click",this.onEditorClickBound,!0),document.addEventListener("selectionchange",this.onSelectionChangeBound),document.addEventListener("visibilitychange",this.onVisibilityChangeBound)),typeof document<"u"){const s=()=>{const o=this.getActiveDocumentId();o&&(o!==this.currentDocId&&(this.currentDocId=o,this.updatePreviewTabHeader("",o)),this.latestCompiledDoc||this.markCompileDirty(o))};setTimeout(s,300),setTimeout(s,1e3)}}async onDataChanged(i){await this.loadGlobalSettings(),this.currentDocId&&this.markCompileDirty(this.currentDocId)}async loadGlobalSettings(){try{const i=await this.loadData(va),n=Uf(i);return ri(n),n}catch{return ri(Ii),Ii}}async saveGlobalSettings(i){const n=qs(),s=ri({...n,...i||{}});try{await this.saveData(va,s)}catch(a){console.error("保存即现全局配置失败",a)}const o=this.currentDocId||this.getActiveDocumentId();return o&&this.markCompileDirty(o),s}onunload(){this.debounceTimer&&(window.clearTimeout(this.debounceTimer),this.debounceTimer=null),this.compileScheduler.reset(),this.inspectorSyncThrottle.reset(),this.dirtyDocId=null,bs.clear(),this.eventBus.off("switch-protyle",this.onSwitchProtyleBound),this.eventBus.off("ws-main",this.onWsMainBound),this.eventBus.off("click-editorcontent",this.onClickEditorContentBound),typeof document<"u"&&(document.removeEventListener("click",this.onEditorClickBound,!0),document.removeEventListener("selectionchange",this.onSelectionChangeBound),document.removeEventListener("visibilitychange",this.onVisibilityChangeBound)),yn.detach()}onVisibilityChange(){typeof document<"u"&&document.visibilityState==="visible"&&this.flushDirtyCompile()}async openBottomPreviewTab(){this.currentDocId||(this.currentDocId=this.getActiveDocumentId());const i=this.currentDocId?await this.fetchDocumentTitle(this.currentDocId):"",n=this.buildPreviewTabTitle(i);await de.openTab({app:this.app,custom:{id:this.name+vo,title:n,icon:"iconSlides",data:{docId:this.currentDocId}},position:"bottom"}),this.currentDocId&&this.compileCurrentDocument(this.currentDocId),this.updatePreviewTabHeader(i,this.currentDocId)}async openPresenterTab(){ai("presenterMode")||(Ww()||await this.openBottomPreviewTab(),await de.openTab({app:this.app,custom:{id:this.name+ga,title:"演讲者控制台",icon:"iconSlides",data:{}},position:"right"}))}async openStandalonePreviewWindow(){this.currentDocId||(this.currentDocId=this.getActiveDocumentId()),this.currentDocId&&!this.latestCompiledDoc&&await this.compileCurrentDocument(this.currentDocId,{reason:"explicit"});const i=de.getFrontend();if(i==="browser-desktop"||i==="browser-mobile"){typeof window<"u"&&typeof window.open=="function"&&window.open("/plugins/siyuan-live-slides/slides-client/index.html","SlidesBigScreenWindow","width=1280,height=760,menubar=no,toolbar=no,location=no,status=no");return}let n=this.previewTab;if(!n){const s=this.currentDocId?await this.fetchDocumentTitle(this.currentDocId):"",o=this.buildPreviewTabTitle(s),a=await de.openTab({app:this.app,custom:{id:this.name+vo,title:o,icon:"iconSlides",data:{docId:this.currentDocId}},position:"bottom"});n=this.previewTab||a}n&&(this.currentDocId&&n.model&&(n.model.data={...n.model.data||{},docId:this.currentDocId}),de.openWindow({tab:n,width:1280,height:760}))}async onSwitchProtyle(i){var a,r,l,c,u;const n=(a=i.detail)==null?void 0:a.protyle,s=(r=n==null?void 0:n.block)==null?void 0:r.rootID,o=((u=(c=(l=n==null?void 0:n.title)==null?void 0:l.editElement)==null?void 0:c.textContent)==null?void 0:u.trim())||"";if(s&&s!==this.currentDocId){this.cancelledCursorBlockId="",this.currentDocId=s,this.activeCursorBlockId=s;const d=await jo(s).catch(()=>({}));Ji({id:s,rootId:s,type:"doc",attrs:d}),this.markCompileDirty(s),this.updatePreviewTabHeader(o,s)}}onClickEditorContent(i){var o,a;const n=i==null?void 0:i.detail;if(!n)return;const s=(a=(o=n.protyle)==null?void 0:o.block)==null?void 0:a.rootID;s&&(!this.currentDocId||this.currentDocId!==s)&&(this.currentDocId=s),n.event&&this.onEditorClick(n.event)}buildPreviewTabTitle(i){return Xl(i)}async fetchDocumentTitle(i){return Ql(this,i)}async updatePreviewTabHeader(i,n){return mg(this,i,n)}getActiveDocumentId(){return wi.getActiveDocumentId()}resolveDocIdFromElement(i){return wi.resolveDocIdFromElement(i,this.currentDocId)}async switchToDocGlobalInspector(i,n){i&&(this.activeCursorBlockId=i,this.currentDocId=i,await wi.switchToDocGlobalInspector(i,n))}onWsMain(i){const n=i.detail;n&&n.cmd==="transactions"&&(wi.patchThematicBreakTransactions(n),this.markCompileDirty())}markCompileDirty(i){const n=i||this.currentDocId||this.getActiveDocumentId();n&&(this.currentDocId||(this.currentDocId=n),this.dirtyDocId=n,this.scheduleDirtyCompile())}scheduleDirtyCompile(i=i2){if(this.debounceTimer&&(window.clearTimeout(this.debounceTimer),this.debounceTimer=null),!this.dirtyDocId)return;const n=bs.getVisibility();if(n==="none")return;const s=n==="visible"?i:Math.max(i,Rw);this.debounceTimer=window.setTimeout(()=>{this.debounceTimer=null;const o=this.dirtyDocId;this.dirtyDocId=null,o&&this.compileCurrentDocument(o,{reason:"auto"})},s)}flushDirtyCompile(){this.dirtyDocId&&this.scheduleDirtyCompile(0)}handleBlockClickedFromSlide(i,n){return i?(this.cancelledCursorBlockId="",this.activeCursorBlockId=i):(this.cancelledCursorBlockId=this.activeCursorBlockId,this.activeCursorBlockId=""),wi.handleBlockClickedFromSlide(i,this.app,this.currentDocId,this.latestCompiledDoc,n)}onBlockClickedFromSlide(i){const n=(i==null?void 0:i.detail)||i;n!=null&&n.blockId&&this.handleBlockClickedFromSlide(n.blockId,n.page)}onEditorClick(i){const n=i.target;if(!n)return;const s=n.closest(".protyle-title")||n.closest(".protyle-background");if(!!(s||n.closest(".protyle-content")&&!n.closest(".protyle-wysiwyg")&&!n.closest(".protyle-breadcrumb")&&!n.closest(".protyle-gutters"))){const u=this.resolveDocIdFromElement(n);if(u&&this.activeCursorBlockId!==u){const d=s||document.querySelector(`.protyle-title[data-node-id="${u}"]`)||document.querySelector(`.protyle[data-doc-id="${u}"] .protyle-title`),h=d==null?void 0:d.querySelector(".protyle-title__input"),p=((h==null?void 0:h.innerText)||(d==null?void 0:d.innerText)||"").trim();this.switchToDocGlobalInspector(u,p)}return}if(!n.closest(".protyle-wysiwyg"))return;const r=n.closest("[data-node-id]");if(!r)return;const l=r.getAttribute("data-node-id"),c=r.getAttribute("data-type")||"";l&&(this.cancelledCursorBlockId="",this.currentDocId||(this.currentDocId=this.resolveDocIdFromElement(n)||""),this.currentDocId&&!this.latestCompiledDoc&&this.markCompileDirty(this.currentDocId),l!==this.activeCursorBlockId&&(this.activeCursorBlockId=l,Fo(l)),this.syncInspectorBlock(r,l,c))}onSelectionChange(){if(typeof window>"u")return;const i=window.getSelection();if(!i||i.rangeCount===0)return;const n=i.anchorNode;if(!n)return;const s=n.nodeType===Node.ELEMENT_NODE?n:n.parentElement;if(!s)return;const o=s.closest(".protyle-title");if(!!(o||s.closest(".protyle-content")&&!s.closest(".protyle-wysiwyg"))){const u=this.resolveDocIdFromElement(s);if(u&&this.activeCursorBlockId!==u){const d=o||document.querySelector(`.protyle-title[data-node-id="${u}"]`)||document.querySelector(`.protyle[data-doc-id="${u}"] .protyle-title`),h=d==null?void 0:d.querySelector(".protyle-title__input"),p=((h==null?void 0:h.innerText)||(d==null?void 0:d.innerText)||"").trim();this.switchToDocGlobalInspector(u,p)}return}if(!s.closest(".protyle-wysiwyg"))return;const r=s.closest("[data-node-id]"),l=r==null?void 0:r.getAttribute("data-node-id"),c=(r==null?void 0:r.getAttribute("data-type"))||"";if(r&&l){if(wi.isLocatingLocked(l))return;if(this.currentDocId||(this.currentDocId=this.resolveDocIdFromElement(s)||""),this.currentDocId&&!this.latestCompiledDoc&&this.markCompileDirty(this.currentDocId),l!==this.activeCursorBlockId){if(l===this.cancelledCursorBlockId)return;this.activeCursorBlockId=l,Fo(l)}this.syncInspectorBlock(r,l,c)}}async syncInspectorBlock(i,n,s){this.inspectorSyncThrottle.shouldSkip(n)||await wi.syncInspectorBlock(i,n,s,this.currentDocId,this.latestCompiledDoc)}async compileCurrentDocument(i,n){const s=(n==null?void 0:n.reason)??"explicit";let o=i||this.currentDocId;if(!o){const r=this.getActiveDocumentId();if(r)this.currentDocId=r,o=r;else return}if(s==="auto"&&bs.getVisibility()==="none"){this.dirtyDocId=o;return}const a=this.compileScheduler.tryBegin(o);if(a!==null){this.dirtyDocId===o&&(this.dirtyDocId=null);try{const r=await Le.compile(o),l=!!this.currentDocId&&o!==this.currentDocId;!this.compileScheduler.isStale(a)&&!l&&(this.currentDocId||(this.currentDocId=o),this.latestCompiledDoc=r,Kw(r,o),this.updatePreviewTabHeader("",o),this.purgeStaleDomSlidesAttrs(r))}catch(r){console.error("[SiYuanLiveSlides] Failed to compile document:",r)}finally{const r=this.compileScheduler.finishBatch(),l=r.length>0?r[0]:this.compileScheduler.finish();l&&this.markCompileDirty(l);for(let c=1;c<r.length;c++)this.markCompileDirty(r[c])}}}purgeStaleDomSlidesAttrs(i){wi.purgeStaleDomSlidesAttrs(i)}}module.exports=o2;
