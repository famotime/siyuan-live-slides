"use strict";var ld=Object.create;var Xs=Object.defineProperty;var cd=Object.getOwnPropertyDescriptor;var dd=Object.getOwnPropertyNames;var ud=Object.getPrototypeOf,fd=Object.prototype.hasOwnProperty;var pd=(e,t,i)=>t in e?Xs(e,t,{enumerable:!0,configurable:!0,writable:!0,value:i}):e[t]=i;var hd=(e,t,i,n)=>{if(t&&typeof t=="object"||typeof t=="function")for(let s of dd(t))!fd.call(e,s)&&s!==i&&Xs(e,s,{get:()=>t[s],enumerable:!(n=cd(t,s))||n.enumerable});return e};var is=(e,t,i)=>(i=e!=null?ld(ud(e)):{},hd(t||!e||!e.__esModule?Xs(i,"default",{value:e,enumerable:!0}):i,e));var be=(e,t,i)=>pd(e,typeof t!="symbol"?t+"":t,i);const ae=require("siyuan");async function kt(e,t){const i=await ae.fetchSyncPost(e,t);return i.code===0?i.data:null}async function md(){return kt("/api/notebook/lsNotebooks","")}async function gd(e,t,i){return kt("/api/filetree/createDocWithMd",{notebook:e,path:t,markdown:i})}async function Sa(e,t){const i=new FormData;i.append("assetsDirPath",e);for(const s of t)i.append("file[]",s);return kt("/api/asset/upload",i)}async function Hi(e,t,i,n,s){return kt("/api/block/insertBlock",{dataType:e,data:t,nextID:i,previousID:n,parentID:s})}async function wo(e,t,i){return kt("/api/block/appendBlock",{dataType:e,data:t,parentID:i})}async function xo(e,t,i){return kt("/api/block/updateBlock",{dataType:e,data:t,id:i})}async function Vo(e){return kt("/api/block/deleteBlock",{id:e})}async function vd(e){return kt("/api/block/getBlockKramdown",{id:e})}async function mn(e){return kt("/api/block/getChildBlocks",{id:e})}async function bd(e){return kt("/api/block/getDocBlocksOrders",{id:e})}async function Fe(e,t){return kt("/api/attr/setBlockAttrs",{id:e,attrs:t})}async function Go(e){return kt("/api/attr/getBlockAttrs",{id:e})}async function un(e){return kt("/api/query/sql",{stmt:e})}async function So(e,t,i){const n=new FormData;return n.append("path",e),n.append("isDir",t.toString()),n.append("modTime",Math.floor(Date.now()/1e3).toString()),n.append("file",i),kt("/api/file/putFile",n)}async function Ca(e){const t="/api/ai/chatGPT";try{const i=await kt(t,{msg:e});return typeof i=="string"&&i.trim().length>0?i.trim():i&&typeof i.content=="string"&&i.content.trim().length>0?i.content.trim():null}catch{return null}}async function yd(){return kt("/api/storage/getInlineStyles","")}function _r(e){return e.markdown&&e.markdown.trim()?e.markdown.trim():e.content&&e.content.trim()?e.content.trim():""}function _a(e){const t={};if(!e)return t;const i=e.replace(/^\{:\s*/,"").replace(/\s*\}$/,""),n=/([\w-]+)=(?:"([^"]*)"|'([^']*)'|(\S+))/g;let s;for(;(s=n.exec(i))!==null;){const o=s[1],a=s[2]??s[3]??s[4]??"";t[o]=a}return t}const $a=/\(\(([0-9a-zA-Z-]+)(?:\s*(?:'([^']*)'|"([^"]*)"|([^\)]+?)))?\s*\)\)/g;function kd(e){const t=[];if(!e)return t;const i=new RegExp($a.source,"g");let n;for(;(n=i.exec(e))!==null;){const s=n[2]??n[3]??n[4];t.push({fullMatch:n[0],blockId:n[1],anchorText:s?s.trim():void 0})}return t}function wd(e,t){if(!e)return"";const i=new RegExp($a.source,"g");return e.replace(i,(n,s,o,a,r)=>{const l=(o??a??r??"").trim();if(t&&t[s]){const u=t[s].trim();return`<div class="slides-block-ref" data-ref-id="${s}">${u}</div>`}const c=l||`Ref(${s.slice(0,8)})`;return`<a href="siyuan://blocks/${s}" data-ref-id="${s}" class="slides-ref-tag">🔗 ${c}</a>`})}const zn="custom-slides-theme",Hn="custom-slides-aspect-ratio",Ia="custom-slides-highlighter",Fn="custom-slides-default-transition",Ma="custom-slides-color-schema",Co="custom-slides-spacing",ws="custom-slides-background",$r="custom-slides-show-unordered-list-markers",Ir="custom-slides-show-ordered-list-markers",li="custom-slides-slide",ke="custom-slides-layout",vt="custom-slides-transition",st="custom-slides-background",Rt="custom-slides-image",Qs="custom-slides-notes",en="custom-slides-class",Tn="custom-slides-spacing",bt="custom-slides-layout-ratio",tn="custom-slides-mask",ji="custom-slides-mask-ratio",nn="custom-slides-mask-style",sn="custom-slides-mask-initial",Ne="custom-slides-click",Xt="custom-slides-motion",Ki="custom-slides-shiki-lines",Me="custom-slides-slot",qe="custom-slides-note",Ze="custom-slides-role",jn="custom-slides-max-height",zi="custom-slides-autoplay",xs="custom-slides-loop",Qi="custom-slides-muted",Ss="custom-slides-controls",Ta="background",Cs="image-left",_s="image-right";function on(e){return e==="cols-header"||e==="two-cols-header"||e==="three-cols-header"}function xd(e,t=2){const i=t===4?[25,50,75,100]:[50,100],n=t===4?4:2;if(!e||typeof e!="string")return{steps:n,breakpoints:i};const s=e.trim();if(!s||t===4&&(s==="1:1"||s==="1"))return{steps:n,breakpoints:i};const o=s.split(":").map(d=>parseFloat(d.trim())).filter(d=>!isNaN(d)&&d>0);if(o.length===0)return{steps:n,breakpoints:i};if(o.length===1){const d=Math.min(100,Math.max(1,o[0]));return d===100?{steps:1,breakpoints:[100]}:{steps:2,breakpoints:[Math.round(d*100)/100,100]}}const a=o.every((d,p)=>p===0||d>o[p-1]),r=o[o.length-1];if(a&&(r===100||o.some(d=>d>10))){const d=o.map(p=>Math.min(100,Math.round(p*100)/100));return d[d.length-1]<100&&d.push(100),{steps:d.length,breakpoints:d}}const c=o.reduce((d,p)=>d+p,0);if(c<=0)return{steps:n,breakpoints:i};let u=0;const f=[];for(let d=0;d<o.length;d++)u+=o[d],d===o.length-1?f.push(100):f.push(Math.round(u/c*1e4)/100);return{steps:f.length,breakpoints:f}}function Ea(e){if(!e)return!1;const t=e.trim();return t.startsWith("assets/")||t.startsWith("./assets/")||t.startsWith("/assets/")}function Aa(e){const t=e.trim();return t.startsWith("./assets/")?t.slice(2):t.startsWith("/assets/")?t.slice(1):t}function $t(e,t){if(!Ea(e))return e;const i=Aa(e);return t!=null&&t.base64Map&&t.base64Map[i]?t.base64Map[i]:t!=null&&t.baseUrl?`${t.baseUrl.replace(/\/+$/,"")}/${i}`:`/${i}`}function Sd(e,t){if(!e)return"";let i=e;return i=i.replace(/!\[(.*?)\]\(((?:\.\/|\/)?assets\/[^\s)]+)\)/g,(n,s,o)=>{const a=$t(o,t);return`![${s}](${a})`}),i=i.replace(/(<(?:img|video|audio|source)\b[^>]*?\bsrc=["'])((?:\.\/|\/)?assets\/[^"']+)(["'][^>]*>)/gi,(n,s,o,a)=>{const r=$t(o,t);return`${s}${r}${a}`}),i=i.replace(/(url\(\s*["']?)((?:\.\/|\/)?assets\/[^"')]+)(["']?\s*\))/gi,(n,s,o,a)=>{const r=$t(o,t);return`${s}${r}${a}`}),i}/**
* @vue/shared v3.5.40
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/function Ko(e){const t=Object.create(null);for(const i of e.split(","))t[i]=1;return i=>i in t}const Je={},rn=[],Qt=()=>{},Ba=()=>!1,Ps=e=>e.charCodeAt(0)===111&&e.charCodeAt(1)===110&&(e.charCodeAt(2)>122||e.charCodeAt(2)<97),Os=e=>e.startsWith("onUpdate:"),ut=Object.assign,qo=(e,t)=>{const i=e.indexOf(t);i>-1&&e.splice(i,1)},Cd=Object.prototype.hasOwnProperty,Ve=(e,t)=>Cd.call(e,t),Ee=Array.isArray,an=e=>Zn(e)==="[object Map]",gn=e=>Zn(e)==="[object Set]",Mr=e=>Zn(e)==="[object Date]",Be=e=>typeof e=="function",nt=e=>typeof e=="string",Ht=e=>typeof e=="symbol",Ye=e=>e!==null&&typeof e=="object",Da=e=>(Ye(e)||Be(e))&&Be(e.then)&&Be(e.catch),La=Object.prototype.toString,Zn=e=>La.call(e),_d=e=>Zn(e).slice(8,-1),Pa=e=>Zn(e)==="[object Object]",Yo=e=>nt(e)&&e!=="NaN"&&e[0]!=="-"&&""+parseInt(e,10)===e,En=Ko(",key,ref,ref_for,ref_key,onVnodeBeforeMount,onVnodeMounted,onVnodeBeforeUpdate,onVnodeUpdated,onVnodeBeforeUnmount,onVnodeUnmounted"),Rs=e=>{const t=Object.create(null);return(i=>t[i]||(t[i]=e(i)))},$d=/-\w/g,Ct=Rs(e=>e.replace($d,t=>t.slice(1).toUpperCase())),Id=/\B([A-Z])/g,Bi=Rs(e=>e.replace(Id,"-$1").toLowerCase()),Ns=Rs(e=>e.charAt(0).toUpperCase()+e.slice(1)),eo=Rs(e=>e?`on${Ns(e)}`:""),qt=(e,t)=>!Object.is(e,t),us=(e,...t)=>{for(let i=0;i<e.length;i++)e[i](...t)},Oa=(e,t,i,n=!1)=>{Object.defineProperty(e,t,{configurable:!0,enumerable:!1,writable:n,value:i})},zs=e=>{const t=parseFloat(e);return isNaN(t)?e:t};let Tr;const Hs=()=>Tr||(Tr=typeof globalThis<"u"?globalThis:typeof self<"u"?self:typeof window<"u"?window:typeof global<"u"?global:{});function Yt(e){if(Ee(e)){const t={};for(let i=0;i<e.length;i++){const n=e[i],s=nt(n)?Ad(n):Yt(n);if(s)for(const o in s)t[o]=s[o]}return t}else if(nt(e)||Ye(e))return e}const Md=/;(?![^(]*\))/g,Td=/:([^]+)/,Ed=/\/\*[^]*?\*\//g;function Ad(e){const t={};return e.replace(Ed,"").split(Md).forEach(i=>{if(i){const n=i.split(Td);n.length>1&&(t[n[0].trim()]=n[1].trim())}}),t}function Ce(e){let t="";if(nt(e))t=e;else if(Ee(e))for(let i=0;i<e.length;i++){const n=Ce(e[i]);n&&(t+=n+" ")}else if(Ye(e))for(const i in e)e[i]&&(t+=i+" ");return t.trim()}const Bd="itemscope,allowfullscreen,formnovalidate,ismap,nomodule,novalidate,readonly",Dd=Ko(Bd);function Ra(e){return!!e||e===""}function Ld(e,t){if(e.length!==t.length)return!1;let i=!0;for(let n=0;i&&n<e.length;n++)i=vn(e[n],t[n]);return i}function vn(e,t){if(e===t)return!0;let i=Mr(e),n=Mr(t);if(i||n)return i&&n?e.getTime()===t.getTime():!1;if(i=Ht(e),n=Ht(t),i||n)return e===t;if(i=Ee(e),n=Ee(t),i||n)return i&&n?Ld(e,t):!1;if(i=Ye(e),n=Ye(t),i||n){if(!i||!n)return!1;const s=Object.keys(e).length,o=Object.keys(t).length;if(s!==o)return!1;for(const a in e){const r=e.hasOwnProperty(a),l=t.hasOwnProperty(a);if(r&&!l||!r&&l||!vn(e[a],t[a]))return!1}}return String(e)===String(t)}function Zo(e,t){return e.findIndex(i=>vn(i,t))}const Na=e=>!!(e&&e.__v_isRef===!0),we=e=>nt(e)?e:e==null?"":Ee(e)||Ye(e)&&(e.toString===La||!Be(e.toString))?Na(e)?we(e.value):JSON.stringify(e,za,2):String(e),za=(e,t)=>Na(t)?za(e,t.value):an(t)?{[`Map(${t.size})`]:[...t.entries()].reduce((i,[n,s],o)=>(i[to(n,o)+" =>"]=s,i),{})}:gn(t)?{[`Set(${t.size})`]:[...t.values()].map(i=>to(i))}:Ht(t)?to(t):Ye(t)&&!Ee(t)&&!Pa(t)?String(t):t,to=(e,t="")=>{var i;return Ht(e)?`Symbol(${(i=e.description)!=null?i:t})`:e};/**
* @vue/reactivity v3.5.40
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/let ct;class Pd{constructor(t=!1){this.detached=t,this._active=!0,this._on=0,this.effects=[],this.cleanups=[],this._isPaused=!1,this._warnOnRun=!0,this.__v_skip=!0,!t&&ct&&(ct.active?(this.parent=ct,this.index=(ct.scopes||(ct.scopes=[])).push(this)-1):(this._active=!1,this._warnOnRun=!1))}get active(){return this._active}pause(){if(this._active){this._isPaused=!0;let t,i;if(this.scopes){const n=this.scopes.slice();for(t=0,i=n.length;t<i;t++)n[t].pause()}for(t=0,i=this.effects.length;t<i;t++)this.effects[t].pause()}}resume(){if(this._active&&this._isPaused){this._isPaused=!1;let t,i;if(this.scopes){const s=this.scopes.slice();for(t=0,i=s.length;t<i;t++)s[t].resume()}const n=this.effects.slice();for(t=0,i=n.length;t<i;t++)n[t].resume()}}run(t){if(this._active){const i=ct;try{return ct=this,t()}finally{ct=i}}}on(){++this._on===1&&(this.prevScope=ct,ct=this)}off(){if(this._on>0&&--this._on===0){if(ct===this)ct=this.prevScope;else{let t=ct;for(;t;){if(t.prevScope===this){t.prevScope=this.prevScope;break}t=t.prevScope}}this.prevScope=void 0}}stop(t){if(this._active){this._active=!1;let i,n;for(i=0,n=this.effects.length;i<n;i++)this.effects[i].stop();for(this.effects.length=0,i=0,n=this.cleanups.length;i<n;i++)this.cleanups[i]();if(this.cleanups.length=0,this.scopes){const s=this.scopes.slice();for(i=0,n=s.length;i<n;i++)s[i].stop(!0);this.scopes.length=0}if(!this.detached&&this.parent&&!t){const s=this.parent.scopes.pop();s&&s!==this&&(this.parent.scopes[this.index]=s,s.index=this.index)}this.parent=void 0}}}function Od(){return ct}let Qe;const io=new WeakSet;class Ha{constructor(t){this.fn=t,this.deps=void 0,this.depsTail=void 0,this.flags=5,this.next=void 0,this.cleanup=void 0,this.scheduler=void 0,ct&&(ct.active?ct.effects.push(this):this.flags&=-2)}pause(){this.flags|=64}resume(){this.flags&64&&(this.flags&=-65,io.has(this)&&(io.delete(this),this.trigger()))}notify(){this.flags&2&&!(this.flags&32)||this.flags&8||ja(this)}run(){if(!(this.flags&1))return this.fn();this.flags|=2,Er(this),Wa(this);const t=Qe,i=Nt;Qe=this,Nt=!0;try{return this.fn()}finally{Ua(this),Qe=t,Nt=i,this.flags&=-3}}stop(){if(this.flags&1){for(let t=this.deps;t;t=t.nextDep)Qo(t);this.deps=this.depsTail=void 0,Er(this),this.onStop&&this.onStop(),this.flags&=-2}}trigger(){this.flags&64?io.add(this):this.scheduler?this.scheduler():this.runIfDirty()}runIfDirty(){_o(this)&&this.run()}get dirty(){return _o(this)}}let Fa=0,An,Bn;function ja(e,t=!1){if(e.flags|=8,t){e.next=Bn,Bn=e;return}e.next=An,An=e}function Jo(){Fa++}function Xo(){if(--Fa>0)return;if(Bn){let t=Bn;for(Bn=void 0;t;){const i=t.next;t.next=void 0,t.flags&=-9,t=i}}let e;for(;An;){let t=An;for(An=void 0;t;){const i=t.next;if(t.next=void 0,t.flags&=-9,t.flags&1)try{t.trigger()}catch(n){e||(e=n)}t=i}}if(e)throw e}function Wa(e){for(let t=e.deps;t;t=t.nextDep)t.version=-1,t.prevActiveLink=t.dep.activeLink,t.dep.activeLink=t}function Ua(e){let t,i=e.depsTail,n=i;for(;n;){const s=n.prevDep;n.version===-1?(n===i&&(i=s),Qo(n),Rd(n)):t=n,n.dep.activeLink=n.prevActiveLink,n.prevActiveLink=void 0,n=s}e.deps=t,e.depsTail=i}function _o(e){for(let t=e.deps;t;t=t.nextDep)if(t.dep.version!==t.version||t.dep.computed&&(Va(t.dep.computed)||t.dep.version!==t.version))return!0;return!!e._dirty}function Va(e){if(e.flags&4&&!(e.flags&16)||(e.flags&=-17,e.globalVersion===Wn)||(e.globalVersion=Wn,!e.isSSR&&e.flags&128&&(!e.deps&&!e._dirty||!_o(e))))return;e.flags|=2;const t=e.dep,i=Qe,n=Nt;Qe=e,Nt=!0;try{Wa(e);const s=e.fn(e._value);(t.version===0||qt(s,e._value))&&(e.flags|=128,e._value=s,t.version++)}catch(s){throw t.version++,s}finally{Qe=i,Nt=n,Ua(e),e.flags&=-3}}function Qo(e,t=!1){const{dep:i,prevSub:n,nextSub:s}=e;if(n&&(n.nextSub=s,e.prevSub=void 0),s&&(s.prevSub=n,e.nextSub=void 0),i.subs===e&&(i.subs=n,!n&&i.computed)){i.computed.flags&=-5;for(let o=i.computed.deps;o;o=o.nextDep)Qo(o,!0)}!t&&!--i.sc&&i.map&&i.map.delete(i.key)}function Rd(e){const{prevDep:t,nextDep:i}=e;t&&(t.nextDep=i,e.prevDep=void 0),i&&(i.prevDep=t,e.nextDep=void 0)}let Nt=!0;const Ga=[];function mi(){Ga.push(Nt),Nt=!1}function gi(){const e=Ga.pop();Nt=e===void 0?!0:e}function Er(e){const{cleanup:t}=e;if(e.cleanup=void 0,t){const i=Qe;Qe=void 0;try{t()}finally{Qe=i}}}let Wn=0;class Nd{constructor(t,i){this.sub=t,this.dep=i,this.version=i.version,this.nextDep=this.prevDep=this.nextSub=this.prevSub=this.prevActiveLink=void 0}}class er{constructor(t){this.computed=t,this.version=0,this.activeLink=void 0,this.subs=void 0,this.map=void 0,this.key=void 0,this.sc=0,this.__v_skip=!0}track(t){if(!Qe||!Nt||Qe===this.computed)return;let i=this.activeLink;if(i===void 0||i.sub!==Qe)i=this.activeLink=new Nd(Qe,this),Qe.deps?(i.prevDep=Qe.depsTail,Qe.depsTail.nextDep=i,Qe.depsTail=i):Qe.deps=Qe.depsTail=i,Ka(i);else if(i.version===-1&&(i.version=this.version,i.nextDep)){const n=i.nextDep;n.prevDep=i.prevDep,i.prevDep&&(i.prevDep.nextDep=n),i.prevDep=Qe.depsTail,i.nextDep=void 0,Qe.depsTail.nextDep=i,Qe.depsTail=i,Qe.deps===i&&(Qe.deps=n)}return i}trigger(t){this.version++,Wn++,this.notify(t)}notify(t){Jo();try{for(let i=this.subs;i;i=i.prevSub)i.sub.notify()&&i.sub.dep.notify()}finally{Xo()}}}function Ka(e){if(e.dep.sc++,e.sub.flags&4){const t=e.dep.computed;if(t&&!e.dep.subs){t.flags|=20;for(let n=t.deps;n;n=n.nextDep)Ka(n)}const i=e.dep.subs;i!==e&&(e.prevSub=i,i&&(i.nextSub=e)),e.dep.subs=e}}const $o=new WeakMap,Wi=Symbol(""),Io=Symbol(""),Un=Symbol("");function mt(e,t,i){if(Nt&&Qe){let n=$o.get(e);n||$o.set(e,n=new Map);let s=n.get(i);s||(n.set(i,s=new er),s.map=n,s.key=i),s.track()}}function ci(e,t,i,n,s,o){const a=$o.get(e);if(!a){Wn++;return}const r=l=>{l&&l.trigger()};if(Jo(),t==="clear")a.forEach(r);else{const l=Ee(e),c=l&&Yo(i);if(l&&i==="length"){const u=Number(n);a.forEach((f,d)=>{(d==="length"||d===Un||!Ht(d)&&d>=u)&&r(f)})}else switch((i!==void 0||a.has(void 0))&&r(a.get(i)),c&&r(a.get(Un)),t){case"add":l?c&&r(a.get("length")):(r(a.get(Wi)),an(e)&&r(a.get(Io)));break;case"delete":l||(r(a.get(Wi)),an(e)&&r(a.get(Io)));break;case"set":an(e)&&r(a.get(Wi));break}}Xo()}function Zi(e){const t=Ue(e);return t===e?t:(mt(t,"iterate",Un),Pt(e)?t:t.map(Ft))}function Fs(e){return mt(e=Ue(e),"iterate",Un),e}function Gt(e,t){return vi(e)?fn(Ui(e)?Ft(t):t):Ft(t)}const zd={__proto__:null,[Symbol.iterator](){return no(this,Symbol.iterator,e=>Gt(this,e))},concat(...e){return Zi(this).concat(...e.map(t=>Ee(t)?Zi(t):t))},entries(){return no(this,"entries",e=>(e[1]=Gt(this,e[1]),e))},every(e,t){return ni(this,"every",e,t,void 0,arguments)},filter(e,t){return ni(this,"filter",e,t,i=>i.map(n=>Gt(this,n)),arguments)},find(e,t){return ni(this,"find",e,t,i=>Gt(this,i),arguments)},findIndex(e,t){return ni(this,"findIndex",e,t,void 0,arguments)},findLast(e,t){return ni(this,"findLast",e,t,i=>Gt(this,i),arguments)},findLastIndex(e,t){return ni(this,"findLastIndex",e,t,void 0,arguments)},forEach(e,t){return ni(this,"forEach",e,t,void 0,arguments)},includes(...e){return so(this,"includes",e)},indexOf(...e){return so(this,"indexOf",e)},join(e){return Zi(this).join(e)},lastIndexOf(...e){return so(this,"lastIndexOf",e)},map(e,t){return ni(this,"map",e,t,void 0,arguments)},pop(){return Sn(this,"pop")},push(...e){return Sn(this,"push",e)},reduce(e,...t){return Ar(this,"reduce",e,t)},reduceRight(e,...t){return Ar(this,"reduceRight",e,t)},shift(){return Sn(this,"shift")},some(e,t){return ni(this,"some",e,t,void 0,arguments)},splice(...e){return Sn(this,"splice",e)},toReversed(){return Zi(this).toReversed()},toSorted(e){return Zi(this).toSorted(e)},toSpliced(...e){return Zi(this).toSpliced(...e)},unshift(...e){return Sn(this,"unshift",e)},values(){return no(this,"values",e=>Gt(this,e))}};function no(e,t,i){const n=Fs(e),s=n[t]();return n!==e&&!Pt(e)&&(s._next=s.next,s.next=()=>{const o=s._next();return o.done||(o.value=i(o.value)),o}),s}const Hd=Array.prototype;function ni(e,t,i,n,s,o){const a=Fs(e),r=a!==e&&!Pt(e),l=a[t];if(l!==Hd[t]){const f=l.apply(e,o);return r?Ft(f):f}let c=i;a!==e&&(r?c=function(f,d){return i.call(this,Gt(e,f),d,e)}:i.length>2&&(c=function(f,d){return i.call(this,f,d,e)}));const u=l.call(a,c,n);return r&&s?s(u):u}function Ar(e,t,i,n){const s=Fs(e),o=s!==e&&!Pt(e);let a=i,r=!1;s!==e&&(o?(r=n.length===0,a=function(c,u,f){return r&&(r=!1,c=Gt(e,c)),i.call(this,c,Gt(e,u),f,e)}):i.length>3&&(a=function(c,u,f){return i.call(this,c,u,f,e)}));const l=s[t](a,...n);return r?Gt(e,l):l}function so(e,t,i){const n=Ue(e);mt(n,"iterate",Un);const s=n[t](...i);return(s===-1||s===!1)&&nr(i[0])?(i[0]=Ue(i[0]),n[t](...i)):s}function Sn(e,t,i=[]){mi(),Jo();const n=Ue(e)[t].apply(e,i);return Xo(),gi(),n}const Fd=Ko("__proto__,__v_isRef,__isVue"),qa=new Set(Object.getOwnPropertyNames(Symbol).filter(e=>e!=="arguments"&&e!=="caller").map(e=>Symbol[e]).filter(Ht));function jd(e){Ht(e)||(e=String(e));const t=Ue(this);return mt(t,"has",e),t.hasOwnProperty(e)}class Ya{constructor(t=!1,i=!1){this._isReadonly=t,this._isShallow=i}get(t,i,n){if(i==="__v_skip")return t.__v_skip;const s=this._isReadonly,o=this._isShallow;if(i==="__v_isReactive")return!s;if(i==="__v_isReadonly")return s;if(i==="__v_isShallow")return o;if(i==="__v_raw")return n===(s?o?Xd:Qa:o?Xa:Ja).get(t)||Object.getPrototypeOf(t)===Object.getPrototypeOf(n)?t:void 0;const a=Ee(t);if(!s){let l;if(a&&(l=zd[i]))return l;if(i==="hasOwnProperty")return jd}const r=Reflect.get(t,i,tt(t)?t:n);if((Ht(i)?qa.has(i):Fd(i))||(s||mt(t,"get",i),o))return r;if(tt(r)){const l=a&&Yo(i)?r:r.value;return s&&Ye(l)?To(l):l}return Ye(r)?s?To(r):js(r):r}}class Za extends Ya{constructor(t=!1){super(!1,t)}set(t,i,n,s){let o=t[i];const a=Ee(t)&&Yo(i);if(!this._isShallow){const c=vi(o);if(!Pt(n)&&!vi(n)&&(o=Ue(o),n=Ue(n)),!a&&tt(o)&&!tt(n))return c||(o.value=n),!0}const r=a?Number(i)<t.length:Ve(t,i),l=Reflect.set(t,i,n,tt(t)?t:s);return t===Ue(s)&&l&&(r?qt(n,o)&&ci(t,"set",i,n):ci(t,"add",i,n)),l}deleteProperty(t,i){const n=Ve(t,i);t[i];const s=Reflect.deleteProperty(t,i);return s&&n&&ci(t,"delete",i,void 0),s}has(t,i){const n=Reflect.has(t,i);return(!Ht(i)||!qa.has(i))&&mt(t,"has",i),n}ownKeys(t){return mt(t,"iterate",Ee(t)?"length":Wi),Reflect.ownKeys(t)}}class Wd extends Ya{constructor(t=!1){super(!0,t)}set(t,i){return!0}deleteProperty(t,i){return!0}}const Ud=new Za,Vd=new Wd,Gd=new Za(!0);const Mo=e=>e,ns=e=>Reflect.getPrototypeOf(e);function Kd(e,t,i){return function(...n){const s=this.__v_raw,o=Ue(s),a=an(o),r=e==="entries"||e===Symbol.iterator&&a,l=e==="keys"&&a,c=s[e](...n),u=i?Mo:t?fn:Ft;return!t&&mt(o,"iterate",l?Io:Wi),ut(Object.create(c),{next(){const{value:f,done:d}=c.next();return d?{value:f,done:d}:{value:r?[u(f[0]),u(f[1])]:u(f),done:d}}})}}function ss(e){return function(...t){return e==="delete"?!1:e==="clear"?void 0:this}}function qd(e,t){const i={get(s){const o=this.__v_raw,a=Ue(o),r=Ue(s);e||(qt(s,r)&&mt(a,"get",s),mt(a,"get",r));const{has:l}=ns(a),c=t?Mo:e?fn:Ft;if(l.call(a,s))return c(o.get(s));if(l.call(a,r))return c(o.get(r));o!==a&&o.get(s)},get size(){const s=this.__v_raw;return!e&&mt(Ue(s),"iterate",Wi),s.size},has(s){const o=this.__v_raw,a=Ue(o),r=Ue(s);return e||(qt(s,r)&&mt(a,"has",s),mt(a,"has",r)),s===r?o.has(s):o.has(s)||o.has(r)},forEach(s,o){const a=this,r=a.__v_raw,l=Ue(r),c=t?Mo:e?fn:Ft;return!e&&mt(l,"iterate",Wi),r.forEach((u,f)=>s.call(o,c(u),c(f),a))}};return ut(i,e?{add:ss("add"),set:ss("set"),delete:ss("delete"),clear:ss("clear")}:{add(s){const o=Ue(this),a=ns(o),r=Ue(s),l=!t&&!Pt(s)&&!vi(s)?r:s;return a.has.call(o,l)||qt(s,l)&&a.has.call(o,s)||qt(r,l)&&a.has.call(o,r)||(o.add(l),ci(o,"add",l,l)),this},set(s,o){!t&&!Pt(o)&&!vi(o)&&(o=Ue(o));const a=Ue(this),{has:r,get:l}=ns(a);let c=r.call(a,s);c||(s=Ue(s),c=r.call(a,s));const u=l.call(a,s);return a.set(s,o),c?qt(o,u)&&ci(a,"set",s,o):ci(a,"add",s,o),this},delete(s){const o=Ue(this),{has:a,get:r}=ns(o);let l=a.call(o,s);l||(s=Ue(s),l=a.call(o,s)),r&&r.call(o,s);const c=o.delete(s);return l&&ci(o,"delete",s,void 0),c},clear(){const s=Ue(this),o=s.size!==0,a=s.clear();return o&&ci(s,"clear",void 0,void 0),a}}),["keys","values","entries",Symbol.iterator].forEach(s=>{i[s]=Kd(s,e,t)}),i}function tr(e,t){const i=qd(e,t);return(n,s,o)=>s==="__v_isReactive"?!e:s==="__v_isReadonly"?e:s==="__v_raw"?n:Reflect.get(Ve(i,s)&&s in n?i:n,s,o)}const Yd={get:tr(!1,!1)},Zd={get:tr(!1,!0)},Jd={get:tr(!0,!1)};const Ja=new WeakMap,Xa=new WeakMap,Qa=new WeakMap,Xd=new WeakMap;function Qd(e){switch(e){case"Object":case"Array":return 1;case"Map":case"Set":case"WeakMap":case"WeakSet":return 2;default:return 0}}function js(e){return vi(e)?e:ir(e,!1,Ud,Yd,Ja)}function eu(e){return ir(e,!1,Gd,Zd,Xa)}function To(e){return ir(e,!0,Vd,Jd,Qa)}function ir(e,t,i,n,s){if(!Ye(e)||e.__v_raw&&!(t&&e.__v_isReactive)||e.__v_skip||!Object.isExtensible(e))return e;const o=s.get(e);if(o)return o;const a=Qd(_d(e));if(a===0)return e;const r=new Proxy(e,a===2?n:i);return s.set(e,r),r}function Ui(e){return vi(e)?Ui(e.__v_raw):!!(e&&e.__v_isReactive)}function vi(e){return!!(e&&e.__v_isReadonly)}function Pt(e){return!!(e&&e.__v_isShallow)}function nr(e){return e?!!e.__v_raw:!1}function Ue(e){const t=e&&e.__v_raw;return t?Ue(t):e}function tu(e){return!Ve(e,"__v_skip")&&Object.isExtensible(e)&&Oa(e,"__v_skip",!0),e}const Ft=e=>Ye(e)?js(e):e,fn=e=>Ye(e)?To(e):e;function tt(e){return e?e.__v_isRef===!0:!1}function ge(e){return iu(e,!1)}function iu(e,t){return tt(e)?e:new nu(e,t)}class nu{constructor(t,i){this.dep=new er,this.__v_isRef=!0,this.__v_isShallow=!1,this._rawValue=i?t:Ue(t),this._value=i?t:Ft(t),this.__v_isShallow=i}get value(){return this.dep.track(),this._value}set value(t){const i=this._rawValue,n=this.__v_isShallow||Pt(t)||vi(t);t=n?t:Ue(t),qt(t,i)&&(this._rawValue=t,this._value=n?t:Ft(t),this.dep.trigger())}}function he(e){return tt(e)?e.value:e}const su={get:(e,t,i)=>t==="__v_raw"?e:he(Reflect.get(e,t,i)),set:(e,t,i,n)=>{const s=e[t];return tt(s)&&!tt(i)?(s.value=i,!0):Reflect.set(e,t,i,n)}};function el(e){return Ui(e)?e:new Proxy(e,su)}class ou{constructor(t,i,n){this.fn=t,this.setter=i,this._value=void 0,this.dep=new er(this),this.__v_isRef=!0,this.deps=void 0,this.depsTail=void 0,this.flags=16,this.globalVersion=Wn-1,this.next=void 0,this.effect=this,this.__v_isReadonly=!i,this.isSSR=n}notify(){if(this.flags|=16,!(this.flags&8)&&Qe!==this)return ja(this,!0),!0}get value(){const t=this.dep.track();return Va(this),t&&(t.version=this.dep.version),this._value}set value(t){this.setter&&this.setter(t)}}function ru(e,t,i=!1){let n,s;return Be(e)?n=e:(n=e.get,s=e.set),new ou(n,s,i)}const os={},$s=new WeakMap;let Ni;function au(e,t=!1,i=Ni){if(i){let n=$s.get(i);n||$s.set(i,n=[]),n.push(e)}}function lu(e,t,i=Je){const{immediate:n,deep:s,once:o,scheduler:a,augmentJob:r,call:l}=i,c=S=>s?S:Pt(S)||s===!1||s===0?di(S,1):di(S);let u,f,d,p,w=!1,m=!1;if(tt(e)?(f=()=>e.value,w=Pt(e)):Ui(e)?(f=()=>c(e),w=!0):Ee(e)?(m=!0,w=e.some(S=>Ui(S)||Pt(S)),f=()=>e.map(S=>{if(tt(S))return S.value;if(Ui(S))return c(S);if(Be(S))return l?l(S,2):S()})):Be(e)?t?f=l?()=>l(e,2):e:f=()=>{if(d){mi();try{d()}finally{gi()}}const S=Ni;Ni=u;try{return l?l(e,3,[p]):e(p)}finally{Ni=S}}:f=Qt,t&&s){const S=f,B=s===!0?1/0:s;f=()=>di(S(),B)}const b=Od(),y=()=>{u.stop(),b&&b.active&&qo(b.effects,u)};if(o&&t){const S=t;t=(...B)=>{const A=S(...B);return y(),A}}let v=m?new Array(e.length).fill(os):os;const k=S=>{if(!(!(u.flags&1)||!u.dirty&&!S))if(t){const B=u.run();if(S||s||w||(m?B.some((A,C)=>qt(A,v[C])):qt(B,v))){d&&d();const A=Ni;Ni=u;try{const C=[B,v===os?void 0:m&&v[0]===os?[]:v,p];v=B,l?l(t,3,C):t(...C)}finally{Ni=A}}}else u.run()};return r&&r(k),u=new Ha(f),u.scheduler=a?()=>a(k,!1):k,p=S=>au(S,!1,u),d=u.onStop=()=>{const S=$s.get(u);if(S){if(l)l(S,4);else for(const B of S)B();$s.delete(u)}},t?n?k(!0):v=u.run():a?a(k.bind(null,!0),!0):u.run(),y.pause=u.pause.bind(u),y.resume=u.resume.bind(u),y.stop=y,y}function di(e,t=1/0,i){if(t<=0||!Ye(e)||e.__v_skip||(i=i||new Map,(i.get(e)||0)>=t))return e;if(i.set(e,t),t--,tt(e))di(e.value,t,i);else if(Ee(e))for(let n=0;n<e.length;n++)di(e[n],t,i);else if(gn(e)||an(e))e.forEach(n=>{di(n,t,i)});else if(Pa(e)){for(const n in e)di(e[n],t,i);for(const n of Object.getOwnPropertySymbols(e))Object.prototype.propertyIsEnumerable.call(e,n)&&di(e[n],t,i)}return e}/**
* @vue/runtime-core v3.5.40
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/function Jn(e,t,i,n){try{return n?e(...n):e()}catch(s){Ws(s,t,i)}}function jt(e,t,i,n){if(Be(e)){const s=Jn(e,t,i,n);return s&&Da(s)&&s.catch(o=>{Ws(o,t,i)}),s}if(Ee(e)){const s=[];for(let o=0;o<e.length;o++)s.push(jt(e[o],t,i,n));return s}}function Ws(e,t,i,n=!0){const s=t?t.vnode:null,{errorHandler:o,throwUnhandledErrorInProduction:a}=t&&t.appContext.config||Je;if(t){let r=t.parent;const l=t.proxy,c=`https://vuejs.org/error-reference/#runtime-${i}`;for(;r;){const u=r.ec;if(u){for(let f=0;f<u.length;f++)if(u[f](e,l,c)===!1)return}r=r.parent}if(o){mi(),Jn(o,null,10,[e,l,c]),gi();return}}cu(e,i,s,n,a)}function cu(e,t,i,n=!0,s=!1){if(s)throw e;console.error(e)}const xt=[];let Ut=-1;const ln=[];let Ci=null,Ji=0;const tl=Promise.resolve();let Is=null;function Ms(e){const t=Is||tl;return e?t.then(this?e.bind(this):e):t}function du(e){let t=Ut+1,i=xt.length;for(;t<i;){const n=t+i>>>1,s=xt[n],o=Vn(s);o<e||o===e&&s.flags&2?t=n+1:i=n}return t}function sr(e){if(!(e.flags&1)){const t=Vn(e),i=xt[xt.length-1];!i||!(e.flags&2)&&t>=Vn(i)?xt.push(e):xt.splice(du(t),0,e),e.flags|=1,il()}}function il(){Is||(Is=tl.then(sl))}function uu(e){Ee(e)?ln.push(...e):Ci&&e.id===-1?Ci.splice(Ji+1,0,e):e.flags&1||(ln.push(e),e.flags|=1),il()}function Br(e,t,i=Ut+1){for(;i<xt.length;i++){const n=xt[i];if(n&&n.flags&2){if(e&&n.id!==e.uid)continue;xt.splice(i,1),i--,n.flags&4&&(n.flags&=-2),n(),n.flags&4||(n.flags&=-2)}}}function nl(e){if(ln.length){const t=[...new Set(ln)].sort((i,n)=>Vn(i)-Vn(n));if(ln.length=0,Ci){Ci.push(...t);return}for(Ci=t,Ji=0;Ji<Ci.length;Ji++){const i=Ci[Ji];i.flags&4&&(i.flags&=-2),i.flags&8||i(),i.flags&=-2}Ci=null,Ji=0}}const Vn=e=>e.id==null?e.flags&2?-1:1/0:e.id;function sl(e){try{for(Ut=0;Ut<xt.length;Ut++){const t=xt[Ut];t&&!(t.flags&8)&&(t.flags&4&&(t.flags&=-2),Jn(t,t.i,t.i?15:14),t.flags&4||(t.flags&=-2))}}finally{for(;Ut<xt.length;Ut++){const t=xt[Ut];t&&(t.flags&=-2)}Ut=-1,xt.length=0,nl(),Is=null,(xt.length||ln.length)&&sl()}}let dt=null,ol=null;function Ts(e){const t=dt;return dt=e,ol=e&&e.type.__scopeId||null,t}function rl(e,t=dt,i){if(!t||e._n)return e;const n=(...s)=>{n._d&&Ur(-1);const o=Ts(t),a=fi.length;let r;try{r=e(...s)}finally{for(let l=fi.length;l>a;l--)cr();Ts(o),n._d&&Ur(1)}return r};return n._n=!0,n._c=!0,n._d=!0,n}function Ot(e,t){if(dt===null)return e;const i=qs(dt),n=e.dirs||(e.dirs=[]);for(let s=0;s<t.length;s++){let[o,a,r,l=Je]=t[s];o&&(Be(o)&&(o={mounted:o,updated:o}),o.deep&&di(a),n.push({dir:o,instance:i,value:a,oldValue:void 0,arg:r,modifiers:l}))}return e}function Li(e,t,i,n){const s=e.dirs,o=t&&t.dirs;for(let a=0;a<s.length;a++){const r=s[a];o&&(r.oldValue=o[a].value);let l=r.dir[n];l&&(mi(),jt(l,i,8,[e.el,r,e,t]),gi())}}function fu(e,t){if(yt){let i=yt.provides;const n=yt.parent&&yt.parent.provides;n===i&&(i=yt.provides=Object.create(n)),i[e]=t}}function zt(e,t,i=!1){const n=uf();if(n||dn){let s=dn?dn._context.provides:n?n.parent==null||n.ce?n.vnode.appContext&&n.vnode.appContext.provides:n.parent.provides:void 0;if(s&&e in s)return s[e];if(arguments.length>1)return i&&Be(t)?t.call(n&&n.proxy):t}}const pu=Symbol.for("v-scx"),hu=()=>zt(pu);function Vi(e,t,i){return al(e,t,i)}function al(e,t,i=Je){const{immediate:n,deep:s,flush:o,once:a}=i,r=ut({},i),l=t&&n||!t&&o!=="post";let c;if(Kn){if(o==="sync"){const p=hu();c=p.__watcherHandles||(p.__watcherHandles=[])}else if(!l){const p=()=>{};return p.stop=Qt,p.resume=Qt,p.pause=Qt,p}}const u=yt;r.call=(p,w,m)=>jt(p,u,w,m);let f=!1;o==="post"?r.scheduler=p=>{_t(p,u&&u.suspense)}:o!=="sync"&&(f=!0,r.scheduler=(p,w)=>{w?p():sr(p)}),r.augmentJob=p=>{t&&(p.flags|=4),f&&(p.flags|=2,u&&(p.id=u.uid,p.i=u))};const d=lu(e,t,r);return Kn&&(c?c.push(d):l&&d()),d}function mu(e,t,i){const n=this.proxy,s=nt(e)?e.includes(".")?ll(n,e):()=>n[e]:e.bind(n,n);let o;Be(t)?o=t:(o=t.handler,i=t);const a=Xn(this),r=al(s,o.bind(n),i);return a(),r}function ll(e,t){const i=t.split(".");return()=>{let n=e;for(let s=0;s<i.length&&n;s++)n=n[i[s]];return n}}const gu=Symbol("_vte"),vu=e=>e.__isTeleport,oo=Symbol("_leaveCb");function or(e,t){e.shapeFlag&6&&e.component?(e.transition=t,or(e.component.subTree,t)):e.shapeFlag&128?(e.ssContent.transition=t.clone(e.ssContent),e.ssFallback.transition=t.clone(e.ssFallback)):e.transition=t}function Dt(e,t){return Be(e)?ut({name:e.name},t,{setup:e}):e}function cl(e){e.ids=[e.ids[0]+e.ids[2]+++"-",0,0]}function Dr(e,t){let i;return!!((i=Object.getOwnPropertyDescriptor(e,t))&&!i.configurable)}const Es=new WeakMap;function Dn(e,t,i,n,s=!1){if(Ee(e)){e.forEach((m,b)=>Dn(m,t&&(Ee(t)?t[b]:t),i,n,s));return}if(cn(n)&&!s){n.shapeFlag&512&&n.type.__asyncResolved&&n.component.subTree.component&&Dn(e,t,i,n.component.subTree);return}const o=n.shapeFlag&4?qs(n.component):n.el,a=s?null:o,{i:r,r:l}=e,c=t&&t.r,u=r.refs===Je?r.refs={}:r.refs,f=r.setupState,d=Ue(f),p=f===Je?Ba:m=>Dr(u,m)?!1:Ve(d,m),w=(m,b)=>!(b&&Dr(u,b));if(c!=null&&c!==l){if(Lr(t),nt(c))u[c]=null,p(c)&&(f[c]=null);else if(tt(c)){const m=t;w(c,m.k)&&(c.value=null),m.k&&(u[m.k]=null)}}if(Be(l))Jn(l,r,12,[a,u]);else{const m=nt(l),b=tt(l);if(m||b){const y=()=>{if(e.f){const v=m?p(l)?f[l]:u[l]:w()||!e.k?l.value:u[e.k];if(s)Ee(v)&&qo(v,o);else if(Ee(v))v.includes(o)||v.push(o);else if(m)u[l]=[o],p(l)&&(f[l]=u[l]);else{const k=[o];w(l,e.k)&&(l.value=k),e.k&&(u[e.k]=k)}}else m?(u[l]=a,p(l)&&(f[l]=a)):b&&(w(l,e.k)&&(l.value=a),e.k&&(u[e.k]=a))};if(a){const v=()=>{y(),Es.delete(e)};v.id=-1,Es.set(e,v),_t(v,i)}else Lr(e),y()}}}function Lr(e){const t=Es.get(e);t&&(t.flags|=8,Es.delete(e))}Hs().requestIdleCallback;Hs().cancelIdleCallback;const cn=e=>!!e.type.__asyncLoader,dl=e=>e.type.__isKeepAlive;function bu(e,t){ul(e,"a",t)}function yu(e,t){ul(e,"da",t)}function ul(e,t,i=yt){const n=e.__wdc||(e.__wdc=()=>{let s=i;for(;s;){if(s.isDeactivated)return;s=s.parent}return e()});if(Us(t,n,i),i){let s=i.parent;for(;s&&s.parent;)dl(s.parent.vnode)&&ku(n,t,i,s),s=s.parent}}function ku(e,t,i,n){const s=Us(t,e,n,!0);Vs(()=>{qo(n[t],s)},i)}function Us(e,t,i=yt,n=!1){if(i){const s=i[e]||(i[e]=[]),o=t.__weh||(t.__weh=(...a)=>{mi();const r=Xn(i),l=jt(t,i,e,a);return r(),gi(),l});return n?s.unshift(o):s.push(o),o}}const yi=e=>(t,i=yt)=>{(!Kn||e==="sp")&&Us(e,(...n)=>t(...n),i)},wu=yi("bm"),bn=yi("m"),xu=yi("bu"),Su=yi("u"),rr=yi("bum"),Vs=yi("um"),Cu=yi("sp"),_u=yi("rtg"),$u=yi("rtc");function Iu(e,t=yt){Us("ec",e,t)}const Mu="components";function Tu(e,t){return Au(Mu,e,!0,t)||e}const Eu=Symbol.for("v-ndc");function Au(e,t,i=!0,n=!1){const s=dt||yt;if(s){const o=s.type;{const r=gf(o,!1);if(r&&(r===t||r===Ct(t)||r===Ns(Ct(t))))return o}const a=Pr(s[e]||o[e],t)||Pr(s.appContext[e],t);return!a&&n?o:a}}function Pr(e,t){return e&&(e[t]||e[Ct(t)]||e[Ns(Ct(t))])}function St(e,t,i,n){let s;const o=i,a=Ee(e);if(a||nt(e)){const r=a&&Ui(e);let l=!1,c=!1;r&&(l=!Pt(e),c=vi(e),e=Fs(e)),s=new Array(e.length);for(let u=0,f=e.length;u<f;u++)s[u]=t(l?c?fn(Ft(e[u])):Ft(e[u]):e[u],u,void 0,o)}else if(typeof e=="number"){s=new Array(e);for(let r=0;r<e;r++)s[r]=t(r+1,r,void 0,o)}else if(Ye(e))if(e[Symbol.iterator])s=Array.from(e,(r,l)=>t(r,l,void 0,o));else{const r=Object.keys(e);s=new Array(r.length);for(let l=0,c=r.length;l<c;l++){const u=r[l];s[l]=t(e[u],u,l,o)}}else s=[];return s}function rs(e,t,i={},n,s,o){if(dt.ce||dt.parent&&cn(dt.parent)&&dt.parent.ce){const c=i,u=Object.keys(c).length>0;return t!=="default"&&(c.name=t),J(),Jt(Xe,null,[oe("slot",c,n&&n())],u?-2:64)}let a=e[t];a&&a._c&&(a._d=!1);const r=fi.length;J();let l;try{const c=a&&fl(a(i)),u=i.key||o||c&&c.key;l=Jt(Xe,{key:(u&&!Ht(u)?u:`_${t}`)+(!c&&n?"_fb":"")},c||(n?n():[]),c&&e._===1?64:-2)}catch(c){for(let u=fi.length;u>r;u--)cr();throw c}finally{a&&a._c&&(a._d=!0)}return l}function fl(e){return e.some(t=>dr(t)?!(t.type===bi||t.type===Xe&&!fl(t.children)):!0)?e:null}const Eo=e=>e?Bl(e)?qs(e):Eo(e.parent):null,Ln=ut(Object.create(null),{$:e=>e,$el:e=>e.vnode.el,$data:e=>e.data,$props:e=>e.props,$attrs:e=>e.attrs,$slots:e=>e.slots,$refs:e=>e.refs,$parent:e=>Eo(e.parent),$root:e=>Eo(e.root),$host:e=>e.ce,$emit:e=>e.emit,$options:e=>hl(e),$forceUpdate:e=>e.f||(e.f=()=>{sr(e.update)}),$nextTick:e=>e.n||(e.n=Ms.bind(e.proxy)),$watch:e=>mu.bind(e)}),ro=(e,t)=>e!==Je&&!e.__isScriptSetup&&Ve(e,t),Bu={get({_:e},t){if(t==="__v_skip")return!0;const{ctx:i,setupState:n,data:s,props:o,accessCache:a,type:r,appContext:l}=e;if(t[0]!=="$"){const d=a[t];if(d!==void 0)switch(d){case 1:return n[t];case 2:return s[t];case 4:return i[t];case 3:return o[t]}else{if(ro(n,t))return a[t]=1,n[t];if(s!==Je&&Ve(s,t))return a[t]=2,s[t];if(Ve(o,t))return a[t]=3,o[t];if(i!==Je&&Ve(i,t))return a[t]=4,i[t];Ao&&(a[t]=0)}}const c=Ln[t];let u,f;if(c)return t==="$attrs"&&mt(e.attrs,"get",""),c(e);if((u=r.__cssModules)&&(u=u[t]))return u;if(i!==Je&&Ve(i,t))return a[t]=4,i[t];if(f=l.config.globalProperties,Ve(f,t))return f[t]},set({_:e},t,i){const{data:n,setupState:s,ctx:o}=e;return ro(s,t)?(s[t]=i,!0):n!==Je&&Ve(n,t)?(n[t]=i,!0):Ve(e.props,t)||t[0]==="$"&&t.slice(1)in e?!1:(o[t]=i,!0)},has({_:{data:e,setupState:t,accessCache:i,ctx:n,appContext:s,props:o,type:a}},r){let l;return!!(i[r]||e!==Je&&r[0]!=="$"&&Ve(e,r)||ro(t,r)||Ve(o,r)||Ve(n,r)||Ve(Ln,r)||Ve(s.config.globalProperties,r)||(l=a.__cssModules)&&l[r])},defineProperty(e,t,i){return i.get!=null?e._.accessCache[t]=0:Ve(i,"value")&&this.set(e,t,i.value,null),Reflect.defineProperty(e,t,i)}};function Or(e){return Ee(e)?e.reduce((t,i)=>(t[i]=null,t),{}):e}let Ao=!0;function Du(e){const t=hl(e),i=e.proxy,n=e.ctx;Ao=!1,t.beforeCreate&&Rr(t.beforeCreate,e,"bc");const{data:s,computed:o,methods:a,watch:r,provide:l,inject:c,created:u,beforeMount:f,mounted:d,beforeUpdate:p,updated:w,activated:m,deactivated:b,beforeDestroy:y,beforeUnmount:v,destroyed:k,unmounted:S,render:B,renderTracked:A,renderTriggered:C,errorCaptured:L,serverPrefetch:z,expose:N,inheritAttrs:K,components:_,directives:U,filters:x}=t;if(c&&Lu(c,n,null),a)for(const $ in a){const T=a[$];Be(T)&&(n[$]=T.bind(i))}if(s){const $=s.call(i,i);Ye($)&&(e.data=js($))}if(Ao=!0,o)for(const $ in o){const T=o[$],P=Be(T)?T.bind(i,i):Be(T.get)?T.get.bind(i,i):Qt,se=!Be(T)&&Be(T.set)?T.set.bind(i):Qt,V=ye({get:P,set:se});Object.defineProperty(n,$,{enumerable:!0,configurable:!0,get:()=>V.value,set:Y=>V.value=Y})}if(r)for(const $ in r)pl(r[$],n,i,$);if(l){const $=Be(l)?l.call(i):l;Reflect.ownKeys($).forEach(T=>{fu(T,$[T])})}u&&Rr(u,e,"c");function O($,T){Ee(T)?T.forEach(P=>$(P.bind(i))):T&&$(T.bind(i))}if(O(wu,f),O(bn,d),O(xu,p),O(Su,w),O(bu,m),O(yu,b),O(Iu,L),O($u,A),O(_u,C),O(rr,v),O(Vs,S),O(Cu,z),Ee(N))if(N.length){const $=e.exposed||(e.exposed={});N.forEach(T=>{Object.defineProperty($,T,{get:()=>i[T],set:P=>i[T]=P,enumerable:!0})})}else e.exposed||(e.exposed={});B&&e.render===Qt&&(e.render=B),K!=null&&(e.inheritAttrs=K),_&&(e.components=_),U&&(e.directives=U),z&&cl(e)}function Lu(e,t,i=Qt){Ee(e)&&(e=Bo(e));for(const n in e){const s=e[n];let o;Ye(s)?"default"in s?o=zt(s.from||n,s.default,!0):o=zt(s.from||n):o=zt(s),tt(o)?Object.defineProperty(t,n,{enumerable:!0,configurable:!0,get:()=>o.value,set:a=>o.value=a}):t[n]=o}}function Rr(e,t,i){jt(Ee(e)?e.map(n=>n.bind(t.proxy)):e.bind(t.proxy),t,i)}function pl(e,t,i,n){let s=n.includes(".")?ll(i,n):()=>i[n];if(nt(e)){const o=t[e];Be(o)&&Vi(s,o)}else if(Be(e))Vi(s,e.bind(i));else if(Ye(e))if(Ee(e))e.forEach(o=>pl(o,t,i,n));else{const o=Be(e.handler)?e.handler.bind(i):t[e.handler];Be(o)&&Vi(s,o,e)}}function hl(e){const t=e.type,{mixins:i,extends:n}=t,{mixins:s,optionsCache:o,config:{optionMergeStrategies:a}}=e.appContext,r=o.get(t);let l;return r?l=r:!s.length&&!i&&!n?l=t:(l={},s.length&&s.forEach(c=>As(l,c,a,!0)),As(l,t,a)),Ye(t)&&o.set(t,l),l}function As(e,t,i,n=!1){const{mixins:s,extends:o}=t;o&&As(e,o,i,!0),s&&s.forEach(a=>As(e,a,i,!0));for(const a in t)if(!(n&&a==="expose")){const r=Pu[a]||i&&i[a];e[a]=r?r(e[a],t[a]):t[a]}return e}const Pu={data:Nr,props:zr,emits:zr,methods:$n,computed:$n,beforeCreate:wt,created:wt,beforeMount:wt,mounted:wt,beforeUpdate:wt,updated:wt,beforeDestroy:wt,beforeUnmount:wt,destroyed:wt,unmounted:wt,activated:wt,deactivated:wt,errorCaptured:wt,serverPrefetch:wt,components:$n,directives:$n,watch:Ru,provide:Nr,inject:Ou};function Nr(e,t){return t?e?function(){return ut(Be(e)?e.call(this,this):e,Be(t)?t.call(this,this):t)}:t:e}function Ou(e,t){return $n(Bo(e),Bo(t))}function Bo(e){if(Ee(e)){const t={};for(let i=0;i<e.length;i++)t[e[i]]=e[i];return t}return e}function wt(e,t){return e?[...new Set([].concat(e,t))]:t}function $n(e,t){return e?ut(Object.create(null),e,t):t}function zr(e,t){return e?Ee(e)&&Ee(t)?[...new Set([...e,...t])]:ut(Object.create(null),Or(e),Or(t??{})):t}function Ru(e,t){if(!e)return t;if(!t)return e;const i=ut(Object.create(null),e);for(const n in t)i[n]=wt(e[n],t[n]);return i}function ml(){return{app:null,config:{isNativeTag:Ba,performance:!1,globalProperties:{},optionMergeStrategies:{},errorHandler:void 0,warnHandler:void 0,compilerOptions:{}},mixins:[],components:{},directives:{},provides:Object.create(null),optionsCache:new WeakMap,propsCache:new WeakMap,emitsCache:new WeakMap}}let Nu=0;function zu(e,t){return function(n,s=null){Be(n)||(n=ut({},n)),s!=null&&!Ye(s)&&(s=null);const o=ml(),a=new WeakSet,r=[];let l=!1;const c=o.app={_uid:Nu++,_component:n,_props:s,_container:null,_context:o,_instance:null,version:bf,get config(){return o.config},set config(u){},use(u,...f){return a.has(u)||(u&&Be(u.install)?(a.add(u),u.install(c,...f)):Be(u)&&(a.add(u),u(c,...f))),c},mixin(u){return o.mixins.includes(u)||o.mixins.push(u),c},component(u,f){return f?(o.components[u]=f,c):o.components[u]},directive(u,f){return f?(o.directives[u]=f,c):o.directives[u]},mount(u,f,d){if(!l){const p=c._ceVNode||oe(n,s);return p.appContext=o,d===!0?d="svg":d===!1&&(d=void 0),e(p,u,d),l=!0,c._container=u,u.__vue_app__=c,qs(p.component)}},onUnmount(u){r.push(u)},unmount(){l&&(jt(r,c._instance,16),e(null,c._container),delete c._container.__vue_app__)},provide(u,f){return o.provides[u]=f,c},runWithContext(u){const f=dn;dn=c;try{return u()}finally{dn=f}}};return c}}let dn=null;const Hu=(e,t)=>t==="modelValue"||t==="model-value"?e.modelModifiers:e[`${t}Modifiers`]||e[`${Ct(t)}Modifiers`]||e[`${Bi(t)}Modifiers`];function Fu(e,t,...i){if(e.isUnmounted)return;const n=e.vnode.props||Je;let s=i;const o=t.startsWith("update:"),a=o&&Hu(n,t.slice(7));a&&(a.trim&&(s=i.map(u=>nt(u)?u.trim():u)),a.number&&(s=i.map(zs)));let r,l=n[r=eo(t)]||n[r=eo(Ct(t))];!l&&o&&(l=n[r=eo(Bi(t))]),l&&jt(l,e,6,s);const c=n[r+"Once"];if(c){if(!e.emitted)e.emitted={};else if(e.emitted[r])return;e.emitted[r]=!0,jt(c,e,6,s)}}const ju=new WeakMap;function gl(e,t,i=!1){const n=i?ju:t.emitsCache,s=n.get(e);if(s!==void 0)return s;const o=e.emits;let a={},r=!1;if(!Be(e)){const l=c=>{const u=gl(c,t,!0);u&&(r=!0,ut(a,u))};!i&&t.mixins.length&&t.mixins.forEach(l),e.extends&&l(e.extends),e.mixins&&e.mixins.forEach(l)}return!o&&!r?(Ye(e)&&n.set(e,null),null):(Ee(o)?o.forEach(l=>a[l]=null):ut(a,o),Ye(e)&&n.set(e,a),a)}function Gs(e,t){return!e||!Ps(t)?!1:(t=t.slice(2),t=t==="Once"?t:t.replace(/Once$/,""),Ve(e,t[0].toLowerCase()+t.slice(1))||Ve(e,Bi(t))||Ve(e,t))}function Hr(e){const{type:t,vnode:i,proxy:n,withProxy:s,propsOptions:[o],slots:a,attrs:r,emit:l,render:c,renderCache:u,props:f,data:d,setupState:p,ctx:w,inheritAttrs:m}=e,b=Ts(e);let y,v;try{if(i.shapeFlag&4){const S=s||n,B=S;y=Kt(c.call(B,S,u,f,p,d,w)),v=r}else{const S=t;y=Kt(S.length>1?S(f,{attrs:r,slots:a,emit:l}):S(f,null)),v=t.props?r:Wu(r)}}catch(S){fi.length=0,Ws(S,e,1),y=oe(bi)}let k=y;if(v&&m!==!1){const S=Object.keys(v),{shapeFlag:B}=k;S.length&&B&7&&(o&&S.some(Os)&&(v=Uu(v,o)),k=pn(k,v,!1,!0))}return i.dirs&&(k=pn(k,null,!1,!0),k.dirs=k.dirs?k.dirs.concat(i.dirs):i.dirs),i.transition&&or(k,i.transition),y=k,Ts(b),y}const Wu=e=>{let t;for(const i in e)(i==="class"||i==="style"||Ps(i))&&((t||(t={}))[i]=e[i]);return t},Uu=(e,t)=>{const i={};for(const n in e)(!Os(n)||!(n.slice(9)in t))&&(i[n]=e[n]);return i};function Vu(e,t,i){const{props:n,children:s,component:o}=e,{props:a,children:r,patchFlag:l}=t,c=o.emitsOptions;if(t.dirs||t.transition)return!0;if(i&&l>=0){if(l&1024)return!0;if(l&16)return n?Fr(n,a,c):!!a;if(l&8){const u=t.dynamicProps;for(let f=0;f<u.length;f++){const d=u[f];if(vl(a,n,d)&&!Gs(c,d))return!0}}}else return(s||r)&&(!r||!r.$stable)?!0:n===a?!1:n?a?Fr(n,a,c):!0:!!a;return!1}function Fr(e,t,i){const n=Object.keys(t);if(n.length!==Object.keys(e).length)return!0;for(let s=0;s<n.length;s++){const o=n[s];if(vl(t,e,o)&&!Gs(i,o))return!0}return!1}function vl(e,t,i){const n=e[i],s=t[i];return i==="style"&&Ye(n)&&Ye(s)?!vn(n,s):n!==s}function Gu({vnode:e,parent:t,suspense:i},n){for(;t;){const s=t.subTree;if(s.suspense&&s.suspense.activeBranch===e&&(s.suspense.vnode.el=s.el=n,e=s),s===e)(e=t.vnode).el=n,t=t.parent;else break}i&&i.activeBranch===e&&(i.vnode.el=n)}const bl={},yl=()=>Object.create(bl),kl=e=>Object.getPrototypeOf(e)===bl;function Ku(e,t,i,n=!1){const s={},o=yl();e.propsDefaults=Object.create(null),wl(e,t,s,o);for(const a in e.propsOptions[0])a in s||(s[a]=void 0);i?e.props=n?s:eu(s):e.type.props?e.props=s:e.props=o,e.attrs=o}function qu(e,t,i,n){const{props:s,attrs:o,vnode:{patchFlag:a}}=e,r=Ue(s),[l]=e.propsOptions;let c=!1;if((n||a>0)&&!(a&16)){if(a&8){const u=e.vnode.dynamicProps;for(let f=0;f<u.length;f++){let d=u[f];if(Gs(e.emitsOptions,d))continue;const p=t[d];if(l)if(Ve(o,d))p!==o[d]&&(o[d]=p,c=!0);else{const w=Ct(d);s[w]=Do(l,r,w,p,e,!1)}else p!==o[d]&&(o[d]=p,c=!0)}}}else{wl(e,t,s,o)&&(c=!0);let u;for(const f in r)(!t||!Ve(t,f)&&((u=Bi(f))===f||!Ve(t,u)))&&(l?i&&(i[f]!==void 0||i[u]!==void 0)&&(s[f]=Do(l,r,f,void 0,e,!0)):delete s[f]);if(o!==r)for(const f in o)(!t||!Ve(t,f))&&(delete o[f],c=!0)}c&&ci(e.attrs,"set","")}function wl(e,t,i,n){const[s,o]=e.propsOptions;let a=!1,r;if(t)for(let l in t){if(En(l))continue;const c=t[l];let u;s&&Ve(s,u=Ct(l))?!o||!o.includes(u)?i[u]=c:(r||(r={}))[u]=c:Gs(e.emitsOptions,l)||(!(l in n)||c!==n[l])&&(n[l]=c,a=!0)}if(o){const l=Ue(i),c=r||Je;for(let u=0;u<o.length;u++){const f=o[u];i[f]=Do(s,l,f,c[f],e,!Ve(c,f))}}return a}function Do(e,t,i,n,s,o){const a=e[i];if(a!=null){const r=Ve(a,"default");if(r&&n===void 0){const l=a.default;if(a.type!==Function&&!a.skipFactory&&Be(l)){const{propsDefaults:c}=s;if(i in c)n=c[i];else{const u=Xn(s);n=c[i]=l.call(null,t),u()}}else n=l;s.ce&&s.ce._setProp(i,n)}a[0]&&(o&&!r?n=!1:a[1]&&(n===""||n===Bi(i))&&(n=!0))}return n}const Yu=new WeakMap;function xl(e,t,i=!1){const n=i?Yu:t.propsCache,s=n.get(e);if(s)return s;const o=e.props,a={},r=[];let l=!1;if(!Be(e)){const u=f=>{l=!0;const[d,p]=xl(f,t,!0);ut(a,d),p&&r.push(...p)};!i&&t.mixins.length&&t.mixins.forEach(u),e.extends&&u(e.extends),e.mixins&&e.mixins.forEach(u)}if(!o&&!l)return Ye(e)&&n.set(e,rn),rn;if(Ee(o))for(let u=0;u<o.length;u++){const f=Ct(o[u]);jr(f)&&(a[f]=Je)}else if(o)for(const u in o){const f=Ct(u);if(jr(f)){const d=o[u],p=a[f]=Ee(d)||Be(d)?{type:d}:ut({},d),w=p.type;let m=!1,b=!0;if(Ee(w))for(let y=0;y<w.length;++y){const v=w[y],k=Be(v)&&v.name;if(k==="Boolean"){m=!0;break}else k==="String"&&(b=!1)}else m=Be(w)&&w.name==="Boolean";p[0]=m,p[1]=b,(m||Ve(p,"default"))&&r.push(f)}}const c=[a,r];return Ye(e)&&n.set(e,c),c}function jr(e){return e[0]!=="$"&&!En(e)}const ar=e=>e==="_"||e==="_ctx"||e==="$stable",lr=e=>Ee(e)?e.map(Kt):[Kt(e)],Zu=(e,t,i)=>{if(t._n)return t;const n=rl((...s)=>lr(t(...s)),i);return n._c=!1,n},Sl=(e,t,i)=>{const n=e._ctx;for(const s in e){if(ar(s))continue;const o=e[s];if(Be(o))t[s]=Zu(s,o,n);else if(o!=null){const a=lr(o);t[s]=()=>a}}},Cl=(e,t)=>{const i=lr(t);e.slots.default=()=>i},_l=(e,t,i)=>{for(const n in t)(i||!ar(n))&&(e[n]=t[n])},Ju=(e,t,i)=>{const n=e.slots=yl();if(e.vnode.shapeFlag&32){const s=t._;s?(_l(n,t,i),i&&Oa(n,"_",s,!0)):Sl(t,n)}else t&&Cl(e,t)},Xu=(e,t,i)=>{const{vnode:n,slots:s}=e;let o=!0,a=Je;if(n.shapeFlag&32){const r=t._;r?i&&r===1?o=!1:_l(s,t,i):(o=!t.$stable,Sl(t,s)),a=t}else t&&(Cl(e,t),a={default:1});if(o)for(const r in s)!ar(r)&&a[r]==null&&delete s[r]},_t=sf;function Qu(e){return ef(e)}function ef(e,t){const i=Hs();i.__VUE__=!0;const{insert:n,remove:s,patchProp:o,createElement:a,createText:r,createComment:l,setText:c,setElementText:u,parentNode:f,nextSibling:d,setScopeId:p=Qt,insertStaticContent:w}=e,m=(E,F,g,W=null,j=null,M=null,I=void 0,R=null,G=!!F.dynamicChildren)=>{if(E===F)return;E&&!Cn(E,F)&&(W=Ie(E),Y(E,j,M,!0),E=null),F.patchFlag===-2&&(G=!1,F.dynamicChildren=null);const{type:D,ref:H,shapeFlag:Z}=F;switch(D){case Ks:b(E,F,g,W);break;case bi:y(E,F,g,W);break;case fs:E==null&&v(F,g,W,I);break;case Xe:_(E,F,g,W,j,M,I,R,G);break;default:Z&1?B(E,F,g,W,j,M,I,R,G):Z&6?U(E,F,g,W,j,M,I,R,G):(Z&64||Z&128)&&D.process(E,F,g,W,j,M,I,R,G,X)}H!=null&&j?Dn(H,E&&E.ref,M,F||E,!F):H==null&&E&&E.ref!=null&&Dn(E.ref,null,M,E,!0)},b=(E,F,g,W)=>{if(E==null)n(F.el=r(F.children),g,W);else{const j=F.el=E.el;F.children!==E.children&&c(j,F.children)}},y=(E,F,g,W)=>{E==null?n(F.el=l(F.children||""),g,W):F.el=E.el},v=(E,F,g,W)=>{[E.el,E.anchor]=w(E.children,F,g,W,E.el,E.anchor)},k=({el:E,anchor:F},g,W)=>{let j;for(;E&&E!==F;)j=d(E),n(E,g,W),E=j;n(F,g,W)},S=({el:E,anchor:F})=>{let g;for(;E&&E!==F;)g=d(E),s(E),E=g;s(F)},B=(E,F,g,W,j,M,I,R,G)=>{if(F.type==="svg"?I="svg":F.type==="math"&&(I="mathml"),E==null)A(F,g,W,j,M,I,R,G);else{const D=E.el&&E.el._isVueCE?E.el:null;try{D&&D._beginPatch(),z(E,F,j,M,I,R,G)}finally{D&&D._endPatch()}}},A=(E,F,g,W,j,M,I,R)=>{let G,D;const{props:H,shapeFlag:Z,transition:te,dirs:ne}=E;if(G=E.el=a(E.type,M,H&&H.is,H),Z&8?u(G,E.children):Z&16&&L(E.children,G,null,W,j,ao(E,M),I,R),ne&&Li(E,null,W,"created"),C(G,E,E.scopeId,I,W),H){for(const $e in H)$e!=="value"&&!En($e)&&o(G,$e,null,H[$e],M,W);"value"in H&&o(G,"value",null,H.value,M),(D=H.onVnodeBeforeMount)&&Wt(D,W,E)}ne&&Li(E,null,W,"beforeMount");const me=tf(j,te);me&&te.beforeEnter(G),n(G,F,g),((D=H&&H.onVnodeMounted)||me||ne)&&_t(()=>{try{D&&Wt(D,W,E),me&&te.enter(G),ne&&Li(E,null,W,"mounted")}finally{}},j)},C=(E,F,g,W,j)=>{if(g&&p(E,g),W)for(let M=0;M<W.length;M++)p(E,W[M]);if(j){let M=j.subTree;if(F===M||Tl(M.type)&&(M.ssContent===F||M.ssFallback===F)){const I=j.vnode;C(E,I,I.scopeId,I.slotScopeIds,j.parent)}}},L=(E,F,g,W,j,M,I,R,G=0)=>{for(let D=G;D<E.length;D++){const H=E[D]=R?oi(E[D]):Kt(E[D]);m(null,H,F,g,W,j,M,I,R)}},z=(E,F,g,W,j,M,I)=>{const R=F.el=E.el;let{patchFlag:G,dynamicChildren:D,dirs:H}=F;G|=E.patchFlag&16;const Z=E.props||Je,te=F.props||Je;let ne;if(g&&Pi(g,!1),(ne=te.onVnodeBeforeUpdate)&&Wt(ne,g,F,E),H&&Li(F,E,g,"beforeUpdate"),g&&Pi(g,!0),D&&(!E.dynamicChildren||E.dynamicChildren.length!==D.length)&&(G=0,I=!1,D=null),(Z.innerHTML&&te.innerHTML==null||Z.textContent&&te.textContent==null)&&u(R,""),D?N(E.dynamicChildren,D,R,g,W,ao(F,j),M):I||T(E,F,R,null,g,W,ao(F,j),M,!1),G>0){if(G&16)K(R,Z,te,g,j);else if(G&2&&Z.class!==te.class&&o(R,"class",null,te.class,j),G&4&&o(R,"style",Z.style,te.style,j),G&8){const me=F.dynamicProps;for(let $e=0;$e<me.length;$e++){const xe=me[$e],De=Z[xe],je=te[xe];(je!==De||xe==="value")&&o(R,xe,De,je,j,g)}}G&1&&E.children!==F.children&&u(R,F.children)}else!I&&D==null&&K(R,Z,te,g,j);((ne=te.onVnodeUpdated)||H)&&_t(()=>{ne&&Wt(ne,g,F,E),H&&Li(F,E,g,"updated")},W)},N=(E,F,g,W,j,M,I)=>{for(let R=0;R<F.length;R++){const G=E[R],D=F[R],H=G.el&&(G.type===Xe||!Cn(G,D)||G.shapeFlag&198)?f(G.el):g;m(G,D,H,null,W,j,M,I,!0)}},K=(E,F,g,W,j)=>{if(F!==g){if(F!==Je)for(const M in F)!En(M)&&!(M in g)&&o(E,M,F[M],null,j,W);for(const M in g){if(En(M))continue;const I=g[M],R=F[M];I!==R&&M!=="value"&&o(E,M,R,I,j,W)}"value"in g&&o(E,"value",F.value,g.value,j)}},_=(E,F,g,W,j,M,I,R,G)=>{const D=F.el=E?E.el:r(""),H=F.anchor=E?E.anchor:r("");let{patchFlag:Z,dynamicChildren:te,slotScopeIds:ne}=F;ne&&(R=R?R.concat(ne):ne),E==null?(n(D,g,W),n(H,g,W),L(F.children||[],g,H,j,M,I,R,G)):Z>0&&Z&64&&te&&E.dynamicChildren&&E.dynamicChildren.length===te.length?(N(E.dynamicChildren,te,g,j,M,I,R),(F.key!=null||j&&F===j.subTree)&&$l(E,F,!0)):T(E,F,g,H,j,M,I,R,G)},U=(E,F,g,W,j,M,I,R,G)=>{F.slotScopeIds=R,E==null?F.shapeFlag&512?j.ctx.activate(F,g,W,I,G):x(F,g,W,j,M,I,G):q(E,F,G)},x=(E,F,g,W,j,M,I)=>{const R=E.component=df(E,W,j);if(dl(E)&&(R.ctx.renderer=X),ff(R,!1,I),R.asyncDep){if(j&&j.registerDep(R,O,I),!E.el){const G=R.subTree=oe(bi);y(null,G,F,g),E.placeholder=G.el}}else O(R,E,F,g,j,M,I)},q=(E,F,g)=>{const W=F.component=E.component;if(Vu(E,F,g))if(W.asyncDep&&!W.asyncResolved){$(W,F,g);return}else W.next=F,W.update();else F.el=E.el,W.vnode=F},O=(E,F,g,W,j,M,I)=>{const R=()=>{if(E.isMounted){let{next:Z,bu:te,u:ne,parent:me,vnode:$e}=E;{const le=Il(E);if(le){Z&&(Z.el=$e.el,$(E,Z,I)),le.asyncDep.then(()=>{_t(()=>{E.isUnmounted||D()},j)});return}}let xe=Z,De;Pi(E,!1),Z?(Z.el=$e.el,$(E,Z,I)):Z=$e,te&&us(te),(De=Z.props&&Z.props.onVnodeBeforeUpdate)&&Wt(De,me,Z,$e),Pi(E,!0);const je=Hr(E),ze=E.subTree;E.subTree=je,m(ze,je,f(ze.el),Ie(ze),E,j,M),Z.el=je.el,xe===null&&Gu(E,je.el),ne&&_t(ne,j),(De=Z.props&&Z.props.onVnodeUpdated)&&_t(()=>Wt(De,me,Z,$e),j)}else{let Z;const{el:te,props:ne}=F,{bm:me,m:$e,parent:xe,root:De,type:je}=E,ze=cn(F);Pi(E,!1),me&&us(me),!ze&&(Z=ne&&ne.onVnodeBeforeMount)&&Wt(Z,xe,F),Pi(E,!0);{De.ce&&De.ce._hasShadowRoot()&&De.ce._injectChildStyle(je,E.parent?E.parent.type:void 0);const le=E.subTree=Hr(E);m(null,le,g,W,E,j,M),F.el=le.el}if($e&&_t($e,j),!ze&&(Z=ne&&ne.onVnodeMounted)){const le=F;_t(()=>Wt(Z,xe,le),j)}(F.shapeFlag&256||xe&&cn(xe.vnode)&&xe.vnode.shapeFlag&256)&&E.a&&_t(E.a,j),E.isMounted=!0,F=g=W=null}};E.scope.on();const G=E.effect=new Ha(R);E.scope.off();const D=E.update=G.run.bind(G),H=E.job=G.runIfDirty.bind(G);H.i=E,H.id=E.uid,G.scheduler=()=>sr(H),Pi(E,!0),D()},$=(E,F,g)=>{F.component=E;const W=E.vnode.props;E.vnode=F,E.next=null,qu(E,F.props,W,g),Xu(E,F.children,g),mi(),Br(E),gi()},T=(E,F,g,W,j,M,I,R,G=!1)=>{const D=E&&E.children,H=E?E.shapeFlag:0,Z=F.children,{patchFlag:te,shapeFlag:ne}=F;if(te>0){if(te&128){se(D,Z,g,W,j,M,I,R,G);return}else if(te&256){P(D,Z,g,W,j,M,I,R,G);return}}ne&8?(H&16&&Se(D,j,M),Z!==D&&u(g,Z)):H&16?ne&16?se(D,Z,g,W,j,M,I,R,G):Se(D,j,M,!0):(H&8&&u(g,""),ne&16&&L(Z,g,W,j,M,I,R,G))},P=(E,F,g,W,j,M,I,R,G)=>{E=E||rn,F=F||rn;const D=E.length,H=F.length,Z=Math.min(D,H);let te;for(te=0;te<Z;te++){const ne=F[te]=G?oi(F[te]):Kt(F[te]);m(E[te],ne,g,null,j,M,I,R,G)}D>H?Se(E,j,M,!0,!1,Z):L(F,g,W,j,M,I,R,G,Z)},se=(E,F,g,W,j,M,I,R,G)=>{let D=0;const H=F.length;let Z=E.length-1,te=H-1;for(;D<=Z&&D<=te;){const ne=E[D],me=F[D]=G?oi(F[D]):Kt(F[D]);if(Cn(ne,me))m(ne,me,g,null,j,M,I,R,G);else break;D++}for(;D<=Z&&D<=te;){const ne=E[Z],me=F[te]=G?oi(F[te]):Kt(F[te]);if(Cn(ne,me))m(ne,me,g,null,j,M,I,R,G);else break;Z--,te--}if(D>Z){if(D<=te){const ne=te+1,me=ne<H?F[ne].el:W;for(;D<=te;)m(null,F[D]=G?oi(F[D]):Kt(F[D]),g,me,j,M,I,R,G),D++}}else if(D>te)for(;D<=Z;)Y(E[D],j,M,!0),D++;else{const ne=D,me=D,$e=new Map;for(D=me;D<=te;D++){const He=F[D]=G?oi(F[D]):Kt(F[D]);He.key!=null&&$e.set(He.key,D)}let xe,De=0;const je=te-me+1;let ze=!1,le=0;const ue=new Array(je);for(D=0;D<je;D++)ue[D]=0;for(D=ne;D<=Z;D++){const He=E[D];if(De>=je){Y(He,j,M,!0);continue}let We;if(He.key!=null)We=$e.get(He.key);else for(xe=me;xe<=te;xe++)if(ue[xe-me]===0&&Cn(He,F[xe])){We=xe;break}We===void 0?Y(He,j,M,!0):(ue[We-me]=D+1,We>=le?le=We:ze=!0,m(He,F[We],g,null,j,M,I,R,G),De++)}const Oe=ze?nf(ue):rn;for(xe=Oe.length-1,D=je-1;D>=0;D--){const He=me+D,We=F[He],lt=F[He+1],Et=He+1<H?lt.el||Ml(lt):W;ue[D]===0?m(null,We,g,Et,j,M,I,R,G):ze&&(xe<0||D!==Oe[xe]?V(We,g,Et,2):xe--)}}},V=(E,F,g,W,j=null)=>{const{el:M,type:I,transition:R,children:G,shapeFlag:D}=E;if(D&6){V(E.component.subTree,F,g,W);return}if(D&128){E.suspense.move(F,g,W);return}if(D&64){I.move(E,F,g,X);return}if(I===Xe){n(M,F,g);for(let Z=0;Z<G.length;Z++)V(G[Z],F,g,W);n(E.anchor,F,g);return}if(I===fs){k(E,F,g);return}if(W!==2&&D&1&&R)if(W===0)R.persisted&&!M[oo]?n(M,F,g):(R.beforeEnter(M),n(M,F,g),_t(()=>R.enter(M),j));else{const{leave:Z,delayLeave:te,afterLeave:ne}=R,me=()=>{E.ctx.isUnmounted?s(M):n(M,F,g)},$e=()=>{const xe=M._isLeaving||!!M[oo];M._isLeaving&&M[oo](!0),R.persisted&&!xe?me():Z(M,()=>{me(),ne&&ne()})};te?te(M,me,$e):$e()}else n(M,F,g)},Y=(E,F,g,W=!1,j=!1)=>{const{type:M,props:I,ref:R,children:G,dynamicChildren:D,shapeFlag:H,patchFlag:Z,dirs:te,cacheIndex:ne,memo:me}=E;if(Z===-2&&(j=!1),R!=null&&(mi(),Dn(R,null,g,E,!0),gi()),ne!=null&&(F.renderCache[ne]=void 0),H&256){F.ctx.deactivate(E);return}const $e=H&1&&te,xe=!cn(E);let De;if(xe&&(De=I&&I.onVnodeBeforeUnmount)&&Wt(De,F,E),H&6)re(E.component,g,W);else{if(H&128){E.suspense.unmount(g,W);return}$e&&Li(E,null,F,"beforeUnmount"),H&64?E.type.remove(E,F,g,X,W):D&&!D.hasOnce&&(M!==Xe||Z>0&&Z&64)?Se(D,F,g,!1,!0):(M===Xe&&Z&384||!j&&H&16)&&Se(G,F,g),W&&ce(E)}const je=me!=null&&ne==null;(xe&&(De=I&&I.onVnodeUnmounted)||$e||je)&&_t(()=>{De&&Wt(De,F,E),$e&&Li(E,null,F,"unmounted"),je&&(E.el=null)},g)},ce=E=>{const{type:F,el:g,anchor:W,transition:j}=E;if(F===Xe){ie(g,W);return}if(F===fs){S(E);return}const M=()=>{s(g),j&&!j.persisted&&j.afterLeave&&j.afterLeave()};if(E.shapeFlag&1&&j&&!j.persisted){const{leave:I,delayLeave:R}=j,G=()=>I(g,M);R?R(E.el,M,G):G()}else M()},ie=(E,F)=>{let g;for(;E!==F;)g=d(E),s(E),E=g;s(F)},re=(E,F,g)=>{const{bum:W,scope:j,job:M,subTree:I,um:R,m:G,a:D}=E;Wr(G),Wr(D),W&&us(W),j.stop(),M&&(M.flags|=8,Y(I,E,F,g)),R&&_t(R,F),_t(()=>{E.isUnmounted=!0},F)},Se=(E,F,g,W=!1,j=!1,M=0)=>{for(let I=M;I<E.length;I++)Y(E[I],F,g,W,j)},Ie=E=>{if(E.shapeFlag&6)return Ie(E.component.subTree);if(E.shapeFlag&128)return E.suspense.next();const F=d(E.anchor||E.el),g=F&&F[gu];return g?d(g):F};let _e=!1;const fe=(E,F,g)=>{let W;E==null?F._vnode&&(Y(F._vnode,null,null,!0),W=F._vnode.component):m(F._vnode||null,E,F,null,null,null,g),F._vnode=E,_e||(_e=!0,Br(W),nl(),_e=!1)},X={p:m,um:Y,m:V,r:ce,mt:x,mc:L,pc:T,pbc:N,n:Ie,o:e};return{render:fe,hydrate:void 0,createApp:zu(fe)}}function ao({type:e,props:t},i){return i==="svg"&&e==="foreignObject"||i==="mathml"&&e==="annotation-xml"&&t&&t.encoding&&t.encoding.includes("html")?void 0:i}function Pi({effect:e,job:t},i){i?(e.flags|=32,t.flags|=4):(e.flags&=-33,t.flags&=-5)}function tf(e,t){return(!e||e&&!e.pendingBranch)&&t&&!t.persisted}function $l(e,t,i=!1){const n=e.children,s=t.children;if(Ee(n)&&Ee(s))for(let o=0;o<n.length;o++){const a=n[o];let r=s[o];r.shapeFlag&1&&!r.dynamicChildren&&((r.patchFlag<=0||r.patchFlag===32)&&(r=s[o]=oi(s[o]),r.el=a.el),!i&&r.patchFlag!==-2&&$l(a,r)),r.type===Ks&&(r.patchFlag===-1&&(r=s[o]=oi(r)),r.el=a.el),r.type===bi&&!r.el&&(r.el=a.el)}}function nf(e){const t=e.slice(),i=[0];let n,s,o,a,r;const l=e.length;for(n=0;n<l;n++){const c=e[n];if(c!==0){if(s=i[i.length-1],e[s]<c){t[n]=s,i.push(n);continue}for(o=0,a=i.length-1;o<a;)r=o+a>>1,e[i[r]]<c?o=r+1:a=r;c<e[i[o]]&&(o>0&&(t[n]=i[o-1]),i[o]=n)}}for(o=i.length,a=i[o-1];o-- >0;)i[o]=a,a=t[a];return i}function Il(e){const t=e.subTree.component;if(t)return t.asyncDep&&!t.asyncResolved?t:Il(t)}function Wr(e){if(e)for(let t=0;t<e.length;t++)e[t].flags|=8}function Ml(e){if(e.placeholder)return e.placeholder;const t=e.component;return t?Ml(t.subTree):null}const Tl=e=>e.__isSuspense;function sf(e,t){t&&t.pendingBranch?Ee(e)?t.effects.push(...e):t.effects.push(e):uu(e)}const Xe=Symbol.for("v-fgt"),Ks=Symbol.for("v-txt"),bi=Symbol.for("v-cmt"),fs=Symbol.for("v-stc"),fi=[];let Bt=null;function J(e=!1){fi.push(Bt=e?null:[])}function cr(){fi.pop(),Bt=fi[fi.length-1]||null}let Gn=1;function Ur(e,t=!1){Gn+=e,e<0&&Bt&&t&&(Bt.hasOnce=!0)}function El(e){return e.dynamicChildren=Gn>0?Bt||rn:null,cr(),Gn>0&&Bt&&Bt.push(e),e}function ee(e,t,i,n,s,o){return El(h(e,t,i,n,s,o,!0))}function Jt(e,t,i,n,s){return El(oe(e,t,i,n,s,!0))}function dr(e){return e?e.__v_isVNode===!0:!1}function Cn(e,t){return e.type===t.type&&e.key===t.key}const Al=({key:e})=>e??null,ps=({ref:e,ref_key:t,ref_for:i})=>(typeof e=="number"&&(e=""+e),e!=null?nt(e)||tt(e)||Be(e)?{i:dt,r:e,k:t,f:!!i}:e:null);function h(e,t=null,i=null,n=0,s=null,o=e===Xe?0:1,a=!1,r=!1){const l={__v_isVNode:!0,__v_skip:!0,type:e,props:t,key:t&&Al(t),ref:t&&ps(t),scopeId:ol,slotScopeIds:null,children:i,component:null,suspense:null,ssContent:null,ssFallback:null,dirs:null,transition:null,el:null,anchor:null,target:null,targetStart:null,targetAnchor:null,staticCount:0,shapeFlag:o,patchFlag:n,dynamicProps:s,dynamicChildren:null,appContext:null,ctx:dt};return r?(Bs(l,i),o&128&&e.normalize(l)):i&&(l.shapeFlag|=nt(i)?8:16),Gn>0&&!a&&Bt&&(l.patchFlag>0||o&6)&&l.patchFlag!==32&&Bt.push(l),l}const oe=of;function of(e,t=null,i=null,n=0,s=null,o=!1){if((!e||e===Eu)&&(e=bi),dr(e)){const r=pn(e,t,!0);return i&&Bs(r,i),Gn>0&&!o&&Bt&&(r.shapeFlag&6?Bt[Bt.indexOf(e)]=r:Bt.push(r)),r.patchFlag=-2,r}if(vf(e)&&(e=e.__vccOpts),t){t=rf(t);let{class:r,style:l}=t;r&&!nt(r)&&(t.class=Ce(r)),Ye(l)&&(nr(l)&&!Ee(l)&&(l=ut({},l)),t.style=Yt(l))}const a=nt(e)?1:Tl(e)?128:vu(e)?64:Ye(e)?4:Be(e)?2:0;return h(e,t,i,n,s,a,o,!0)}function rf(e){return e?nr(e)||kl(e)?ut({},e):e:null}function pn(e,t,i=!1,n=!1){const{props:s,ref:o,patchFlag:a,children:r,transition:l}=e,c=t?af(s||{},t):s,u={__v_isVNode:!0,__v_skip:!0,type:e.type,props:c,key:c&&Al(c),ref:t&&t.ref?i&&o?Ee(o)?o.concat(ps(t)):[o,ps(t)]:ps(t):o,scopeId:e.scopeId,slotScopeIds:e.slotScopeIds,children:r,target:e.target,targetStart:e.targetStart,targetAnchor:e.targetAnchor,staticCount:e.staticCount,shapeFlag:e.shapeFlag,patchFlag:t&&e.type!==Xe?a===-1?16:a|16:a,dynamicProps:e.dynamicProps,dynamicChildren:e.dynamicChildren,appContext:e.appContext,dirs:e.dirs,transition:l,component:e.component,suspense:e.suspense,ssContent:e.ssContent&&pn(e.ssContent),ssFallback:e.ssFallback&&pn(e.ssFallback),placeholder:e.placeholder,el:e.el,anchor:e.anchor,ctx:e.ctx,ce:e.ce};return l&&n&&or(u,l.clone(u)),u}function It(e=" ",t=0){return oe(Ks,null,e,t)}function ht(e,t){const i=oe(fs,null,e);return i.staticCount=t,i}function Te(e="",t=!1){return t?(J(),Jt(bi,null,e)):oe(bi,null,e)}function Kt(e){return e==null||typeof e=="boolean"?oe(bi):Ee(e)?oe(Xe,null,e.slice()):dr(e)?oi(e):oe(Ks,null,String(e))}function oi(e){return e.el===null&&e.patchFlag!==-1||e.memo?e:pn(e)}function Bs(e,t){let i=0;const{shapeFlag:n}=e;if(t==null)t=null;else if(Ee(t))i=16;else if(typeof t=="object")if(n&65){const s=t.default;s&&(s._c&&(s._d=!1),Bs(e,s()),s._c&&(s._d=!0));return}else{i=32;const s=t._;!s&&!kl(t)?t._ctx=dt:s===3&&dt&&(dt.slots._===1?t._=1:(t._=2,e.patchFlag|=1024))}else if(Be(t)){if(n&65){Bs(e,{default:t});return}t={default:t,_ctx:dt},i=32}else t=String(t),n&64?(i=16,t=[It(t)]):i=8;e.children=t,e.shapeFlag|=i}function af(...e){const t={};for(let i=0;i<e.length;i++){const n=e[i];for(const s in n)if(s==="class")t.class!==n.class&&(t.class=Ce([t.class,n.class]));else if(s==="style")t.style=Yt([t.style,n.style]);else if(Ps(s)){const o=t[s],a=n[s];a&&o!==a&&!(Ee(o)&&o.includes(a))?t[s]=o?[].concat(o,a):a:a==null&&o==null&&!Os(s)&&(t[s]=a)}else s!==""&&(t[s]=n[s])}return t}function Wt(e,t,i,n=null){jt(e,t,7,[i,n])}const lf=ml();let cf=0;function df(e,t,i){const n=e.type,s=(t?t.appContext:e.appContext)||lf,o={uid:cf++,vnode:e,type:n,parent:t,appContext:s,root:null,next:null,subTree:null,effect:null,update:null,job:null,scope:new Pd(!0),render:null,proxy:null,exposed:null,exposeProxy:null,withProxy:null,provides:t?t.provides:Object.create(s.provides),ids:t?t.ids:["",0,0],accessCache:null,renderCache:[],components:null,directives:null,propsOptions:xl(n,s),emitsOptions:gl(n,s),emit:null,emitted:null,propsDefaults:Je,inheritAttrs:n.inheritAttrs,ctx:Je,data:Je,props:Je,attrs:Je,slots:Je,refs:Je,setupState:Je,setupContext:null,suspense:i,suspenseId:i?i.pendingId:0,asyncDep:null,asyncResolved:!1,isMounted:!1,isUnmounted:!1,isDeactivated:!1,bc:null,c:null,bm:null,m:null,bu:null,u:null,um:null,bum:null,da:null,a:null,rtg:null,rtc:null,ec:null,sp:null};return o.ctx={_:o},o.root=t?t.root:o,o.emit=Fu.bind(null,o),e.ce&&e.ce(o),o}let yt=null;const uf=()=>yt||dt;let Ds,Lo;{const e=Hs(),t=(i,n)=>{let s;return(s=e[i])||(s=e[i]=[]),s.push(n),o=>{s.length>1?s.forEach(a=>a(o)):s[0](o)}};Ds=t("__VUE_INSTANCE_SETTERS__",i=>yt=i),Lo=t("__VUE_SSR_SETTERS__",i=>Kn=i)}const Xn=e=>{const t=yt;return Ds(e),e.scope.on(),()=>{e.scope.off(),Ds(t)}},Vr=()=>{yt&&yt.scope.off(),Ds(null)};function Bl(e){return e.vnode.shapeFlag&4}let Kn=!1;function ff(e,t=!1,i=!1){t&&Lo(t);const{props:n,children:s}=e.vnode,o=Bl(e);Ku(e,n,o,t),Ju(e,s,i||t);const a=o?pf(e,t):void 0;return t&&Lo(!1),a}function pf(e,t){const i=e.type;e.accessCache=Object.create(null),e.proxy=new Proxy(e.ctx,Bu);const{setup:n}=i;if(n){mi();const s=e.setupContext=n.length>1?mf(e):null,o=Xn(e),a=Jn(n,e,0,[e.props,s]),r=Da(a);if(gi(),o(),(r||e.sp)&&!cn(e)&&cl(e),r){if(a.then(Vr,Vr),t)return a.then(l=>{Gr(e,l)}).catch(l=>{Ws(l,e,0)});e.asyncDep=a}else Gr(e,a)}else Dl(e)}function Gr(e,t,i){Be(t)?e.type.__ssrInlineRender?e.ssrRender=t:e.render=t:Ye(t)&&(e.setupState=el(t)),Dl(e)}function Dl(e,t,i){const n=e.type;e.render||(e.render=n.render||Qt);{const s=Xn(e);mi();try{Du(e)}finally{gi(),s()}}}const hf={get(e,t){return mt(e,"get",""),e[t]}};function mf(e){const t=i=>{e.exposed=i||{}};return{attrs:new Proxy(e.attrs,hf),slots:e.slots,emit:e.emit,expose:t}}function qs(e){return e.exposed?e.exposeProxy||(e.exposeProxy=new Proxy(el(tu(e.exposed)),{get(t,i){if(i in t)return t[i];if(i in Ln)return Ln[i](e)},has(t,i){return i in t||i in Ln}})):e.proxy}function gf(e,t=!0){return Be(e)?e.displayName||e.name:e.name||t&&e.__name}function vf(e){return Be(e)&&"__vccOpts"in e}const ye=(e,t)=>ru(e,t,Kn),bf="3.5.40";/**
* @vue/runtime-dom v3.5.40
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/let Po;const Kr=typeof window<"u"&&window.trustedTypes;if(Kr)try{Po=Kr.createPolicy("vue",{createHTML:e=>e})}catch{}const Ll=Po?e=>Po.createHTML(e):e=>e,yf="http://www.w3.org/2000/svg",kf="http://www.w3.org/1998/Math/MathML",si=typeof document<"u"?document:null,qr=si&&si.createElement("template"),wf={insert:(e,t,i)=>{t.insertBefore(e,i||null)},remove:e=>{const t=e.parentNode;t&&t.removeChild(e)},createElement:(e,t,i,n)=>{const s=t==="svg"?si.createElementNS(yf,e):t==="mathml"?si.createElementNS(kf,e):i?si.createElement(e,{is:i}):si.createElement(e);return e==="select"&&n&&n.multiple!=null&&s.setAttribute("multiple",n.multiple),s},createText:e=>si.createTextNode(e),createComment:e=>si.createComment(e),setText:(e,t)=>{e.nodeValue=t},setElementText:(e,t)=>{e.textContent=t},parentNode:e=>e.parentNode,nextSibling:e=>e.nextSibling,querySelector:e=>si.querySelector(e),setScopeId(e,t){e.setAttribute(t,"")},insertStaticContent(e,t,i,n,s,o){const a=i?i.previousSibling:t.lastChild;if(s&&(s===o||s.nextSibling))for(;t.insertBefore(s.cloneNode(!0),i),!(s===o||!(s=s.nextSibling)););else{qr.innerHTML=Ll(n==="svg"?`<svg>${e}</svg>`:n==="mathml"?`<math>${e}</math>`:e);const r=qr.content;if(n==="svg"||n==="mathml"){const l=r.firstChild;for(;l.firstChild;)r.appendChild(l.firstChild);r.removeChild(l)}t.insertBefore(r,i)}return[a?a.nextSibling:t.firstChild,i?i.previousSibling:t.lastChild]}},xf=Symbol("_vtc");function Sf(e,t,i){const n=e[xf];n&&(t=(t?[t,...n]:[...n]).join(" ")),t==null?e.removeAttribute("class"):i?e.setAttribute("class",t):e.className=t}const Ls=Symbol("_vod"),Pl=Symbol("_vsh"),Oo={name:"show",beforeMount(e,{value:t},{transition:i}){e[Ls]=e.style.display==="none"?"":e.style.display,i&&t?i.beforeEnter(e):_n(e,t)},mounted(e,{value:t},{transition:i}){i&&t&&i.enter(e)},updated(e,{value:t,oldValue:i},{transition:n}){!t!=!i&&(n?t?(n.beforeEnter(e),_n(e,!0),n.enter(e)):n.leave(e,()=>{_n(e,!1)}):_n(e,t))},beforeUnmount(e,{value:t}){_n(e,t)}};function _n(e,t){e.style.display=t?e[Ls]:"none",e[Pl]=!t}const Cf=Symbol(""),_f=/(?:^|;)\s*display\s*:/;function $f(e,t,i){const n=e.style,s=nt(i);let o=!1;if(i&&!s){if(t)if(nt(t))for(const a of t.split(";")){const r=a.slice(0,a.indexOf(":")).trim();i[r]==null&&In(n,r,"")}else for(const a in t)i[a]==null&&In(n,a,"");for(const a in i){a==="display"&&(o=!0);const r=i[a];r!=null?Mf(e,a,!nt(t)&&t?t[a]:void 0,r)||In(n,a,r):In(n,a,"")}}else if(s){if(t!==i){const a=n[Cf];a&&(i+=";"+a),n.cssText=i,o=_f.test(i)}}else t&&e.removeAttribute("style");Ls in e&&(e[Ls]=o?n.display:"",e[Pl]&&(n.display="none"))}const Yr=/\s*!important$/;function In(e,t,i){if(Ee(i))i.forEach(n=>In(e,t,n));else if(i==null&&(i=""),t.startsWith("--"))e.setProperty(t,i);else{const n=If(e,t);Yr.test(i)?e.setProperty(Bi(n),i.replace(Yr,""),"important"):e[n]=i}}const Zr=["Webkit","Moz","ms"],lo={};function If(e,t){const i=lo[t];if(i)return i;let n=Ct(t);if(n!=="filter"&&n in e)return lo[t]=n;n=Ns(n);for(let s=0;s<Zr.length;s++){const o=Zr[s]+n;if(o in e)return lo[t]=o}return t}function Mf(e,t,i,n){return e.tagName==="TEXTAREA"&&(t==="width"||t==="height")&&nt(n)&&i===n}const Jr="http://www.w3.org/1999/xlink";function Xr(e,t,i,n,s,o=Dd(t)){n&&t.startsWith("xlink:")?i==null?e.removeAttributeNS(Jr,t.slice(6,t.length)):e.setAttributeNS(Jr,t,i):i==null||o&&!Ra(i)?e.removeAttribute(t):e.setAttribute(t,o?"":Ht(i)?String(i):i)}function Qr(e,t,i,n,s){if(t==="innerHTML"||t==="textContent"){i!=null&&(e[t]=t==="innerHTML"?Ll(i):i);return}const o=e.tagName;if(t==="value"&&o!=="PROGRESS"&&!o.includes("-")){const r=o==="OPTION"?e.getAttribute("value")||"":e.value,l=i==null?e.type==="checkbox"?"on":"":String(i);(r!==l||!("_value"in e))&&(e.value=l),i==null&&e.removeAttribute(t),e._value=i;return}let a=!1;if(i===""||i==null){const r=typeof e[t];r==="boolean"?i=Ra(i):i==null&&r==="string"?(i="",a=!0):r==="number"&&(i=0,a=!0)}try{e[t]=i}catch{}a&&e.removeAttribute(s||t)}function _i(e,t,i,n){e.addEventListener(t,i,n)}function Tf(e,t,i,n){e.removeEventListener(t,i,n)}const ea=Symbol("_vei");function Ef(e,t,i,n,s=null){const o=e[ea]||(e[ea]={}),a=o[t];if(n&&a)a.value=n;else{const[r,l]=Df(t);if(n){const c=o[t]=Of(n,s);_i(e,r,c,l)}else a&&(Tf(e,r,a,l),o[t]=void 0)}}const Af=/(Once|Passive|Capture)$/,Bf=/^on:?(?:Once|Passive|Capture)$/;function Df(e){let t,i;for(;(i=e.match(Af))&&!Bf.test(e);)t||(t={}),e=e.slice(0,e.length-i[1].length),t[i[1].toLowerCase()]=!0;return[e[2]===":"?e.slice(3):Bi(e.slice(2)),t]}let co=0;const Lf=Promise.resolve(),Pf=()=>co||(Lf.then(()=>co=0),co=Date.now());function Of(e,t){const i=n=>{if(!n._vts)n._vts=Date.now();else if(n._vts<=i.attached)return;const s=i.value;if(Ee(s)){const o=n.stopImmediatePropagation;n.stopImmediatePropagation=()=>{o.call(n),n._stopped=!0};const a=s.slice(),r=[n];for(let l=0;l<a.length&&!n._stopped;l++){const c=a[l];c&&jt(c,t,5,r)}}else jt(s,t,5,[n])};return i.value=e,i.attached=Pf(),i}const ta=e=>e.charCodeAt(0)===111&&e.charCodeAt(1)===110&&e.charCodeAt(2)>96&&e.charCodeAt(2)<123,Rf=(e,t,i,n,s,o)=>{const a=s==="svg";t==="class"?Sf(e,n,a):t==="style"?$f(e,i,n):Ps(t)?Os(t)||Ef(e,t,i,n,o):(t[0]==="."?(t=t.slice(1),!0):t[0]==="^"?(t=t.slice(1),!1):Nf(e,t,n,a))?(Qr(e,t,n),!e.tagName.includes("-")&&(t==="value"||t==="checked"||t==="selected")&&Xr(e,t,n,a,o,t!=="value")):e._isVueCE&&(zf(e,t)||e._def.__asyncLoader&&(/[A-Z]/.test(t)||!nt(n)))?Qr(e,Ct(t),n,o,t):(t==="true-value"?e._trueValue=n:t==="false-value"&&(e._falseValue=n),Xr(e,t,n,a))};function Nf(e,t,i,n){if(n)return!!(t==="innerHTML"||t==="textContent"||t in e&&ta(t)&&Be(i));if(t==="spellcheck"||t==="draggable"||t==="translate"||t==="autocorrect"||t==="sandbox"&&e.tagName==="IFRAME"||t==="form"||t==="list"&&e.tagName==="INPUT"||t==="type"&&e.tagName==="TEXTAREA")return!1;if(t==="width"||t==="height"){const s=e.tagName;if(s==="IMG"||s==="VIDEO"||s==="CANVAS"||s==="SOURCE")return!1}return ta(t)&&nt(i)?!1:t in e}function zf(e,t){const i=e._def.props;if(!i)return!1;const n=Ct(t);return Array.isArray(i)?i.some(s=>Ct(s)===n):Object.keys(i).some(s=>Ct(s)===n)}const hn=e=>{const t=e.props["onUpdate:modelValue"]||!1;return Ee(t)?i=>us(t,i):t};function Hf(e){e.target.composing=!0}function ia(e){const t=e.target;t.composing&&(t.composing=!1,t.dispatchEvent(new Event("input")))}const pi=Symbol("_assign");function na(e,t,i){return t&&(e=e.trim()),i&&(e=zs(e)),e}const Ro={created(e,{modifiers:{lazy:t,trim:i,number:n}},s){e[pi]=hn(s);const o=n||s.props&&s.props.type==="number";_i(e,t?"change":"input",a=>{a.target.composing||e[pi](na(e.value,i,o))}),(i||o)&&_i(e,"change",()=>{e.value=na(e.value,i,o)}),t||(_i(e,"compositionstart",Hf),_i(e,"compositionend",ia),_i(e,"change",ia))},mounted(e,{value:t}){e.value=t??""},beforeUpdate(e,{value:t,oldValue:i,modifiers:{lazy:n,trim:s,number:o}},a){if(e[pi]=hn(a),e.composing)return;const r=(o||e.type==="number")&&!/^0\d/.test(e.value)?zs(e.value):e.value,l=t??"";if(r===l)return;const c=e.getRootNode();(c instanceof Document||c instanceof ShadowRoot)&&c.activeElement===e&&e.type!=="range"&&(n&&t===i||s&&e.value.trim()===l)||(e.value=l)}},as={deep:!0,created(e,t,i){e[pi]=hn(i),_i(e,"change",()=>{const n=e._modelValue,s=qn(e),o=e.checked,a=e[pi];if(Ee(n)){const r=Zo(n,s),l=r!==-1;if(o&&!l)a(n.concat(s));else if(!o&&l){const c=[...n];c.splice(r,1),a(c)}}else if(gn(n)){const r=new Set(n);o?r.add(s):r.delete(s),a(r)}else a(Ol(e,o))})},mounted:sa,beforeUpdate(e,t,i){e[pi]=hn(i),sa(e,t,i)}};function sa(e,{value:t,oldValue:i},n){e._modelValue=t;let s;if(Ee(t))s=Zo(t,n.props.value)>-1;else if(gn(t))s=t.has(n.props.value);else{if(t===i)return;s=vn(t,Ol(e,!0))}e.checked!==s&&(e.checked=s)}const Ff={deep:!0,created(e,{value:t,modifiers:{number:i}},n){e._modelValue=t,_i(e,"change",()=>{const s=Array.prototype.filter.call(e.options,o=>o.selected).map(o=>i?zs(qn(o)):qn(o));e[pi](e.multiple?gn(e._modelValue)?new Set(s):s:s[0]),e._assigning=!0,Ms(()=>{e._assigning=!1})}),e[pi]=hn(n)},mounted(e,{value:t}){oa(e,t)},beforeUpdate(e,{value:t},i){e._modelValue=t,e[pi]=hn(i)},updated(e,{value:t}){e._assigning||oa(e,t)}};function oa(e,t){const i=e.multiple,n=Ee(t);if(!(i&&!n&&!gn(t))){for(let s=0,o=e.options.length;s<o;s++){const a=e.options[s],r=qn(a);if(i)if(n){const l=typeof r;l==="string"||l==="number"?a.selected=t.some(c=>String(c)===String(r)):a.selected=Zo(t,r)>-1}else a.selected=t.has(r);else if(vn(qn(a),t)){e.selectedIndex!==s&&(e.selectedIndex=s);return}}!i&&e.selectedIndex!==-1&&(e.selectedIndex=-1)}}function qn(e){return"_value"in e?e._value:e.value}function Ol(e,t){const i=t?"_trueValue":"_falseValue";return i in e?e[i]:t}const jf=["ctrl","shift","alt","meta"],Wf={stop:e=>e.stopPropagation(),prevent:e=>e.preventDefault(),self:e=>e.target!==e.currentTarget,ctrl:e=>!e.ctrlKey,shift:e=>!e.shiftKey,alt:e=>!e.altKey,meta:e=>!e.metaKey,left:e=>"button"in e&&e.button!==0,middle:e=>"button"in e&&e.button!==1,right:e=>"button"in e&&e.button!==2,exact:(e,t)=>jf.some(i=>e[`${i}Key`]&&!t.includes(i))},Zt=(e,t)=>{if(!e)return e;const i=e._withMods||(e._withMods={}),n=t.join(".");return i[n]||(i[n]=((s,...o)=>{for(let a=0;a<t.length;a++){const r=Wf[t[a]];if(r&&r(s,t))return}return e(s,...o)}))},Uf={esc:"escape",space:" ",up:"arrow-up",left:"arrow-left",right:"arrow-right",down:"arrow-down",delete:"backspace"},Vf=(e,t)=>{const i=e._withKeys||(e._withKeys={}),n=t.join(".");return i[n]||(i[n]=(s=>{if(!("key"in s))return;const o=Bi(s.key);if(t.some(a=>a===o||Uf[a]===o))return e(s)}))},Gf=ut({patchProp:Rf},wf);let ra;function Kf(){return ra||(ra=Qu(Gf))}const ur=((...e)=>{const t=Kf().createApp(...e),{mount:i}=t;return t.mount=n=>{const s=Yf(n);if(!s)return;const o=t._component;!Be(o)&&!o.render&&!o.template&&(o.template=s.innerHTML),s.nodeType===1&&(s.textContent="");const a=i(s,!1,qf(s));return s instanceof Element&&(s.removeAttribute("v-cloak"),s.setAttribute("data-v-app","")),a},t});function qf(e){if(e instanceof SVGElement)return"svg";if(typeof MathMLElement=="function"&&e instanceof MathMLElement)return"mathml"}function Yf(e){return nt(e)?document.querySelector(e):e}const Zf="slides-config.json",Ti={enableWebServeJump:!1,webServeUrl:"http://127.0.0.1:6806",normalizeHeadingSizes:!1,showUnorderedListMarkers:!0,showOrderedListMarkers:!0},Vt=js({...Ti});function Jf(e){if(!e||typeof e!="object")return{...Ti};const t=e;return{enableWebServeJump:!!t.enableWebServeJump,webServeUrl:typeof t.webServeUrl=="string"&&t.webServeUrl.trim()?t.webServeUrl.trim():Ti.webServeUrl,normalizeHeadingSizes:!!t.normalizeHeadingSizes,showUnorderedListMarkers:t.showUnorderedListMarkers!==void 0?!!t.showUnorderedListMarkers:Ti.showUnorderedListMarkers,showOrderedListMarkers:t.showOrderedListMarkers!==void 0?!!t.showOrderedListMarkers:Ti.showOrderedListMarkers}}function ri(e){if(!e||typeof e!="object")return{...Vt};const t=e;return t.enableWebServeJump!==void 0&&(Vt.enableWebServeJump=!!t.enableWebServeJump),t.webServeUrl!==void 0&&(Vt.webServeUrl=String(t.webServeUrl)),t.normalizeHeadingSizes!==void 0&&(Vt.normalizeHeadingSizes=!!t.normalizeHeadingSizes),t.showUnorderedListMarkers!==void 0&&(Vt.showUnorderedListMarkers=!!t.showUnorderedListMarkers),t.showOrderedListMarkers!==void 0&&(Vt.showOrderedListMarkers=!!t.showOrderedListMarkers),{...Vt}}function Ys(){return{...Vt}}function Rl(e,t,i){const n=(e||Ti.webServeUrl).trim(),s=n.startsWith("http://")||n.startsWith("https://")?n:`http://${n}`,o=(i==null?void 0:i.r)||Math.random().toString(36).slice(2,9).padEnd(7,"0");try{const a=new URL(s);let r=a.pathname.replace(/\/+$/,"");return r.endsWith("/stage/build/desktop")||(r=r?`${r}/stage/build/desktop`:"/stage/build/desktop"),a.pathname=`${r}/`,a.searchParams.set("id",t),i!=null&&i.focus&&a.searchParams.set("focus","1"),a.searchParams.set("r",o),a.toString()}catch{const a=i!=null&&i.focus?"&focus=1":"";return`${s.replace(/\/+$/,"")}/stage/build/desktop/?id=${t}${a}&r=${o}`}}const Oi={theme:"default",aspectRatio:"16/9",highlighter:"shiki",defaultTransition:"slide-left",colorSchema:"auto",spacing:"normal",background:"",normalizeHeadingSizes:!1,showUnorderedListMarkers:!0,showOrderedListMarkers:!0};function Xf(e){var s,o,a,r,l,c,u,f;const t=Ys();if(!e)return{...Oi,normalizeHeadingSizes:t.normalizeHeadingSizes,showUnorderedListMarkers:t.showUnorderedListMarkers,showOrderedListMarkers:t.showOrderedListMarkers};const i=e[$r]!==void 0?e[$r]!=="false":t.showUnorderedListMarkers,n=e[Ir]!==void 0?e[Ir]!=="false":t.showOrderedListMarkers;return{theme:((s=e[zn])==null?void 0:s.trim())||Oi.theme,aspectRatio:((o=e[Hn])==null?void 0:o.trim())||Oi.aspectRatio,highlighter:((a=e[Ia])==null?void 0:a.trim())||Oi.highlighter,defaultTransition:((r=e[Fn])==null?void 0:r.trim())||Oi.defaultTransition,colorSchema:((l=e[Ma])==null?void 0:l.trim())||Oi.colorSchema,spacing:((c=e[Co])==null?void 0:c.trim())||Oi.spacing,background:((u=e[ws])==null?void 0:u.trim())||((f=e["slides-background"])==null?void 0:f.trim())||"",normalizeHeadingSizes:t.normalizeHeadingSizes,showUnorderedListMarkers:i,showOrderedListMarkers:n}}function ui(e){var i,n,s,o,a;const t=(i=e.ial)==null?void 0:i[li];return!!(t&&(t==="true"||t==="page"||t==="cover"||t==="end")||e.type==="tb"||e.type==="thematic-break"||e.type==="NodeThematicBreak"||((n=e.markdown)==null?void 0:n.trim())==="---"||((s=e.markdown)==null?void 0:s.trim())==="***"||e.type==="b"&&(((o=e.markdown)==null?void 0:o.trim())==="---"||((a=e.content)==null?void 0:a.trim())==="---"))}function aa(e){const t={};let i="";if(!e)return{frontmatter:t,notes:i};e[ke]&&(t.layout=e[ke].trim()),e[vt]&&(t.transition=e[vt].trim()),e[st]&&(t.background=e[st].trim()),e[Rt]&&(t.image=e[Rt].trim()),e[en]&&(t.class=e[en].trim()),e[Tn]&&(t.spacing=e[Tn].trim()),e[bt]&&(t.layoutRatio=e[bt].trim()),e[tn]&&(t.mask=e[tn].trim()),e[ji]&&(t.maskRatio=e[ji].trim()),e[nn]&&(t.maskStyle=e[nn].trim()),e[sn]&&(t.maskInitial=e[sn].trim()),e[Qs]&&(i=e[Qs].trim());for(const[n,s]of Object.entries(e))if(n.startsWith("custom-slides-")&&![ke,bt,tn,ji,nn,sn,vt,st,Rt,en,Tn,Qs,li].includes(n)){const o=n.replace(/^custom-slides-/,"");try{t[o]=JSON.parse(s)}catch{t[o]=s}}return{frontmatter:t,notes:i}}function la(e){const t={};if(!e)return t;const i=e[qe]??e["slides-note"];i!=null&&i!==""&&i!=="false"&&i!=="0"&&(t.isNote=!0);const n=e[Ze]??e["slides-role"],s=e[st]??e["slides-background"];(n===Ta||s==="true"||s==="1")&&(t.isBackground=!0);const o=e[ke]??e["slides-layout"];o===Cs||o===_s?t.imageLayout=o:(n===Cs||n===_s)&&(t.imageLayout=n);const a=e[Ne]??e["custom-slides-clicks"]??e["slides-click"]??e["slides-clicks"];if(a!=null&&(t.clicks=a.trim()),e[Xt])try{const r=JSON.parse(e[Xt]);typeof r=="object"&&r!==null?t.motion={preset:r.preset||r.type||"fade-in",...r}:t.motion={preset:String(r).trim()}}catch{t.motion={preset:e[Xt].trim()}}return e[Ki]&&(t.shikiLines=e[Ki].trim()),e[jn]&&(t.maxHeight=e[jn].trim()),e[Me]&&(t.slot=e[Me].trim()),e.style&&e.style.trim()&&(t.style=e.style.trim()),t}function hi(e,t){const i=(e||t||"").trim();if(!i)return null;const n=i.match(/!\[[\s\S]*?\]\(\s*([^\s)]+)(?:\s+(?:=["']?[^"'\s)]*["']?|["'][^"']*["']))*?\s*\)/);if(n)return n[1].trim();const s=i.match(/<img\b[^>]*?\bsrc=["']([^"']+)["']/i);if(s)return s[1].trim();const o=i.replace(/\{:[^}]*\}/g,"").trim();return/^(?:assets\/|https?:\/\/|\/|\.\.?\/)[^\s]+\.(?:png|jpe?g|gif|webp|svg|avif)(?:\?[^\s]*)?$/i.test(o)?o:null}function Pn(e){if(!e)return"";const t=e.split(/\r?\n/);if(t.length===0)return"";const i=t[0],n=i.match(/^(\s*)(?:[-*+]|\d+\.)\s+(.*)$/);if(!n)return e;const s=n[1].length,o=n[2].trim(),a=i.length-n[2].length;if(t.length===1)return o;const r=[o];for(let l=1;l<t.length;l++){const c=t[l];if(!c.trim()){r.push("");continue}const u=c.match(/^(\s*)/),f=u?u[1].length:0;f>=a?r.push(c.slice(a)):f>s?r.push(c.slice(f)):r.push(c)}return r.join(`
`)}function Ai(e){if(!e)return!1;const t=(e.type||"").toLowerCase();if(t==="i"||t==="nodelistitem"||t==="l"||t==="nodelist")return!0;const i=(e.markdown||e.rawMarkdown||e.content||"").trim();return!!/^(?:[-*+]|\d+\.)\s+/.test(i)}function uo(e,t=2){if(!e||typeof e!="string")return`repeat(${t}, 1fr)`;const i=e.trim();if(!i)return`repeat(${t}, 1fr)`;if(i.includes(":")){const s=i.split(":").map(o=>parseFloat(o.trim())).filter(o=>!isNaN(o)&&o>0);if(s.length>=2)return s.map(o=>`${o}fr`).join(" ")}const n=i.split(/\s+/).filter(Boolean);return n.length>=2?n.join(" "):`repeat(${t}, 1fr)`}function On(e){if(!e)return[];if(at(e)&&ei(e)&&!ti(e)){const n=yn(e),s=[];for(const o of n)s.push(...On(o));return s}const t=(e.type||"").toLowerCase();if(t==="l"||t==="nodelist"||t==="list"){if(e.children&&e.children.length>0){const a=e.children.filter(Ai);if(a.length>0)return a}const s=(e.markdown||e.content||"").trim().split(/\r?\n/),o=[];for(let a=0;a<s.length;a++)/^(?:[-*+]|\d+\.)\s+/.test(s[a])&&o.push(a);if(o.length>=2){const a=[];for(let r=0;r<o.length;r++){const l=o[r],c=r+1<o.length?o[r+1]:s.length,u=s.slice(l,c).join(`
`);a.push({id:`${e.id}-item-${r+1}`,type:"i",markdown:u,content:u,ial:{...e.ial||{}}})}return a}}return Ai(e)?[e]:[]}function fr(e){var s;if(!e||!at(e)||!ei(e)||ti(e))return null;const t=yn(e);if(t.length===0)return null;if(t.length===1&&at(t[0])&&ei(t[0])){const o=fr(t[0]);return o?{items:o.items,nestedSuperBlocks:[t[0],...o.nestedSuperBlocks]}:null}const i=[];for(const o of t)if(at(o)){i.push(o);const a=((s=o.children)==null?void 0:s.filter(at))||[];i.push(...a)}const n=t.map(On);if(n.length>=2&&n.every(o=>o.length>0)){const o=n.flat();if(o.length>=2&&o.length<=6)return{items:o,nestedSuperBlocks:i}}if(t.length===2){const o=On(t[0]),a=On(t[1]);if(o.length+a.length>=2&&o.length+a.length<=6&&(o.length>0||a.length>0))return{items:[...o,...a],nestedSuperBlocks:i}}return null}function Qf(e){if(!e||!at(e)||!ei(e)||ti(e))return null;const t=fr(e);if(!t)return null;const{items:i,nestedSuperBlocks:n}=t;if(i.length<2||i.length>6)return null;const s=pr(e)||void 0,o=i.length;return{superBlockNode:e,nestedSuperBlocks:n,count:o,layout:"cols-header",items:i,slots:i.map((a,r)=>`col-${r+1}`),ratio:s}}function Nl(e){if(!e||!at(e)||!ei(e)||ti(e))return null;const t=yn(e);if(t.length===0)return null;const i=[];for(const n of t){const s=On(n);if(s.length===0)return null;i.push(...s)}return i}function ep(e){if(!e||!at(e)||!ei(e)||ti(e))return null;const t=Nl(e);return!t||t.length===0||t.length>=2&&t.length<=6?null:{superBlockNode:e,items:t}}function tp(e){if(!e||!at(e)||!ei(e)||ti(e))return null;const t=fr(e);if(t&&t.items.length===4)return t.items;const i=Nl(e);if(i&&i.length===4)return i;const n=yn(e);return n.length===4?n:null}function ip(e,t){if(!e||e.length===0)return null;const i=[];function n(r,l){if(at(r)){const c=tp(r);c&&c.length===4&&i.push({sbNode:r,items:c,topLevelIndex:l})}if(r.children&&r.children.length>0)for(const c of r.children)n(c,l)}for(let r=0;r<e.length;r++)n(e[r],r);if(i.length===0)return null;let s=null;t&&(s=i.find(r=>{if(r.sbNode.id===t||r.items.some(c=>c.id===t))return!0;const l=c=>c.id===t?!0:c.children?c.children.some(l):!1;return l(r.sbNode)})||null),s||(s=i[0]);const a=e.slice(0,s.topLevelIndex).slice().reverse().find(r=>zl(r));return{superBlockNode:s.sbNode,items:s.items,headerNode:a}}function np(e,t,i){var u,f,d,p,w;const n=[],s=[],o=(i==null?void 0:i.tracked)||[],a=[];let r={pageTargetId:e,blocks:[]};a.push(r);for(let m=0;m<t.length;m++){const b=t[m];if(ui(b)){if(a.length===1&&r.blocks.length===0){r.pageTargetId=b.id,r.blocks.push(b);continue}r={pageTargetId:b.id,blocks:[b]},a.push(r)}else r.blocks.push(b)}function l(m){const b=[];for(const y of m)at(y)&&b.push(y),y.children&&y.children.length>0&&b.push(...l(y.children));return b}function c(m,b,y){const v={blockId:m,attrs:b,previousAttrs:y};n.push(v),i!=null&&i.onTagChange&&i.onTagChange(v)}for(const m of a){const b=m.pageTargetId,y=t.find(A=>A.id===b),v=o.find(A=>A.pageTargetId===b);if(m.blocks.some(A=>{var C,L;return!!(ti(A)||No(A)&&(((C=A.ial)==null?void 0:C[ke])==="image-left"||((L=A.ial)==null?void 0:L[ke])==="image-right"))})){if(v){const A=v.headerId;if(A){c(A,{[Me]:""});const C=t.find(L=>L.id===A);C!=null&&C.ial&&(C.ial[Me]="")}for(const C of v.itemIds){c(C,{[Me]:""});const L=t.find(z=>z.id===C);L!=null&&L.ial&&(L.ial[Me]="")}}continue}let S=null,B=-1;for(let A=0;A<m.blocks.length;A++){const C=m.blocks[A],L=at(C)?[C,...l(C.children||[])]:C.children?l(C.children):[];for(const z of L){const N=Qf(z);if(N){S=N,B=A;break}}if(S)break}if(S){const{superBlockNode:A,layout:C,items:L,slots:z}=S,K=m.blocks.slice(0,B).find($=>zl($)),_=K==null?void 0:K.id,U=((u=y==null?void 0:y.ial)==null?void 0:u[ke])||"",x=U==="clover",q=x?"clover":C;if(U!==q&&(c(b,{[ke]:q},{[ke]:U}),y&&(y.ial||(y.ial={}),y.ial[ke]=q)),K){const $=((f=K.ial)==null?void 0:f[Me])||"";$!=="header"&&(c(K.id,{[Me]:"header"},{[Me]:$}),K.ial||(K.ial={}),K.ial[Me]="header")}if(v!=null&&v.headerId&&v.headerId!==_){c(v.headerId,{[Me]:""});const $=t.find(T=>T.id===v.headerId);$&&($.ial||($.ial={}),$.ial[Me]="")}const O=[];for(let $=0;$<L.length;$++){const T=L[$],P=z[$];O.push(T.id);const se=((d=T.ial)==null?void 0:d[Me])||"";if(se!==P&&(c(T.id,{[Me]:P},{[Me]:se}),T.ial||(T.ial={}),T.ial[Me]=P),T.children&&T.children.length>0)for(const V of T.children)V.ial||(V.ial={}),V.ial[Me]!==P&&(V.ial[Me]=P)}if(v!=null&&v.itemIds){for(const $ of v.itemIds)if(!O.includes($)){c($,{[Me]:""});const T=t.find(P=>P.id===$);T&&(T.ial||(T.ial={}),T.ial[Me]="")}}s.push({superBlockId:A.id,nestedSuperBlockIds:(p=S.nestedSuperBlocks)==null?void 0:p.map($=>$.id),pageTargetId:b,headerId:_,itemIds:O,layout:x?"clover":C})}else{let A=!1;const C=[];for(const N of m.blocks){const K=at(N)?[N,...l(N.children||[])]:N.children?l(N.children):[];for(const _ of K){const U=ep(_);if(U){A=!0;for(const x of U.items)C.push(x.id)}}}const L=((w=y==null?void 0:y.ial)==null?void 0:w[ke])||"",z=on(L);if(v||A&&z){c(b,{[ke]:""},{[ke]:L}),y&&(y.ial||(y.ial={}),y.ial[ke]="");const N=v==null?void 0:v.headerId;if(N){c(N,{[Me]:""});const _=t.find(U=>U.id===N);_&&(_.ial||(_.ial={}),_.ial[Me]="")}const K=new Set([...(v==null?void 0:v.itemIds)||[],...C]);for(const _ of K){c(_,{[Me]:""});const U=t.find(x=>x.id===_);U&&(U.ial||(U.ial={}),U.ial[Me]="")}}}}return{changes:n,newTracked:s}}function at(e){if(!e)return!1;const t=(e.type||"").toLowerCase();return t==="s"||t==="sb"||t==="nodesuperblock"}function ei(e){if(!at(e))return!1;const t=(e.subType||"").toLowerCase();if(t==="col"||t==="h"||t==="horizontal")return!0;if(t==="row"||t==="v"||t==="vertical")return!1;if(e.ial){const n=(e.ial["data-sb-layout"]||e.ial.layout||"").toLowerCase();if(n==="col"||n==="h")return!0;if(n==="row"||n==="v")return!1}if(e.children&&e.children.length>0){for(const n of e.children)if(n.type==="NodeSuperBlockLayoutMarker"||n.type==="layout-marker"){const s=(n.content||n.markdown||"").trim().toLowerCase();if(s==="col"||s==="h")return!0;if(s==="row"||s==="v")return!1}}const i=(e.markdown||e.content||"").trim();return/^\{\{\{col\b/i.test(i)?!0:!/^\{\{\{row\b/i.test(i)}function No(e){return!e||Ai(e)||at(e)||!hi(e.markdown,e.content)?!1:(e.markdown||e.content||"").replace(/!\[.*?\]\([^)]+\)/g,"").replace(/<img\b[^>]*>/gi,"").replace(/\{:[^}]*\}/g,"").trim().length<=25}function pr(e){var d;if(!e||!at(e)||!ei(e))return null;const t=yn(e);if(!t||t.length<2)return null;const i=[];let n=!1;for(const p of t){const w=(((d=p.ial)==null?void 0:d.style)||p.style||"").trim();let m=null;if(w){const b=w.match(/calc\(\s*([\d.]+)%/i);if(b)m=parseFloat(b[1]);else{const y=w.match(/(?:^|;|\s)width:\s*([\d.]+)%/i);y&&(m=parseFloat(y[1]))}}m!==null&&!isNaN(m)&&m>0?(i.push(m),n=!0):i.push(null)}if(!n)return null;const s=t.length,o=i.reduce((p,w)=>p+(w||0),0),a=i.filter(p=>p===null).length,r=Math.max(0,100-o),l=a>0?r/a:100/s,c=i.map(p=>p!==null?p:l),u=c.reduce((p,w)=>p+w,0);if(u<=0)return null;const f=c.map(p=>p/u*100);if(f.length===2){const[p]=f;if(p>=48&&p<=52)return"1:1";if(p>=31&&p<=35)return"1:2";if(p>=65&&p<=69)return"2:1";if(p>=28&&p<=32)return"3:7";if(p>=68&&p<=72)return"7:3";if(p>=38&&p<=42)return"4:6";if(p>=58&&p<=62)return"6:4";if(p>=23&&p<=27)return"1:3";if(p>=73&&p<=77)return"3:1";const w=Math.round(p),m=100-w;return`${w}:${m}`}if(f.length===3){const[p,w,m]=f;if(p>=31&&p<=35&&w>=31&&w<=35&&m>=31&&m<=35)return"1:1:1";if(p>=23&&p<=27&&w>=48&&w<=52&&m>=23&&m<=27)return"1:2:1";if(p>=48&&p<=52&&w>=23&&w<=27&&m>=23&&m<=27)return"2:1:1";if(p>=23&&p<=27&&w>=23&&w<=27&&m>=48&&m<=52)return"1:1:2";if(p>=18&&p<=22&&w>=58&&w<=62&&m>=18&&m<=22)return"1:3:1";const b=Math.round(p),y=Math.round(w),v=100-b-y;return`${b}:${y}:${v}`}return f.map(p=>Math.round(p)).join(":")}function ti(e){if(!e||!at(e)||!ei(e))return null;const t=(e.children||[]).filter(o=>{const a=o.type||"";if(a==="NodeSuperBlockOpenMarker"||a==="NodeSuperBlockLayoutMarker"||a==="NodeSuperBlockCloseMarker"||a==="open-marker"||a==="layout-marker"||a==="close-marker")return!1;const r=(o.markdown||o.content||"").trim();return!(/^\{\{\{(?:col|row)?\s*$/i.test(r)||r==="}}}")});if(t.length<2)return null;const i=No(t[0]),n=No(t[t.length-1]),s=pr(e)||void 0;if(i&&!n){const o=hi(t[0].markdown,t[0].content);if(o)return{imageNode:t[0],imageUrl:o,layout:Cs,contentNodes:t.slice(1),ratio:s}}if(!i&&n){const o=hi(t[t.length-1].markdown,t[t.length-1].content);if(o)return{imageNode:t[t.length-1],imageUrl:o,layout:_s,contentNodes:t.slice(0,t.length-1),ratio:s}}return null}function sp(e,t){const i=[];function n(s){for(const o of s){const a=ti(o);if(a){const{imageNode:r,layout:l,ratio:c}=a;r.ial||(r.ial={});const u=r.ial[ke];if(u!==l){const d={blockId:r.id,layout:l,previousLayout:u,ratio:c};r.ial[ke]=l,i.push(d),t&&t(d)}}o.children&&o.children.length>0&&n(o.children)}}return n(e),i}function yn(e){return(e.children||[]).filter(t=>{const i=t.type||"";if(i==="NodeSuperBlockOpenMarker"||i==="NodeSuperBlockLayoutMarker"||i==="NodeSuperBlockCloseMarker"||i==="open-marker"||i==="layout-marker"||i==="close-marker")return!1;const n=(t.markdown||t.content||"").trim();return!(/^\{\{\{(?:col|row)?\s*$/i.test(n)||n==="}}}")})}function zl(e){if(!e)return!1;const t=(e.type||"").toLowerCase();if(t==="h"||t==="nodeheading"||/^h[1-6]$/i.test(e.subType||""))return!0;const i=(e.markdown||e.content||"").trim();return!!/^#{1,6}\s+/.test(i)}function Ri(e,t,i){let n="",s=0;const o=/<div\b([^>]*)>/gi;for(;s<e.length;){o.lastIndex=s;let a,r=!1,l=-1,c=0;for(;(a=o.exec(e))!==null;){const y=a[1].match(/\bclass=["']([^"']*)["']/i);if(y){const v=y[1];if(typeof t=="string"?v.split(/\s+/).includes(t):t.test(v)){r=!0,l=a.index,c=a[0].length;break}}}if(!r){n+=e.slice(s);break}n+=e.slice(s,l);const u=l+c;let f=1,d=-1,p=-1;const w=/<\/?div\b[^>]*>/gi;w.lastIndex=u;let m;for(;(m=w.exec(e))!==null;)if(m[0].startsWith("</")){if(f--,f===0){d=m.index,p=m.index+m[0].length;break}}else f++;if(d!==-1&&p!==-1){const b=e.slice(u,d);n+=i(b),s=p}else n+=e.slice(l,u),s=u}return n}function op(e){const t=[];let i="",n=0;const s=/<div\b([^>]*)>/gi;for(;n<e.length;){s.lastIndex=n;let o,a=!1,r=-1,l=0;for(;(o=s.exec(e))!==null;){const m=o[1];if(/(?:\s@[a-zA-Z0-9_-]+=\s*["']|\s:[a-zA-Z0-9_-]+=\s*["']|\sv-[a-zA-Z0-9_.-]+|\shover:[a-zA-Z0-9_.-]+=\s*["']|\sgrid=["']~|\bclass=["'][^"']*\b(?:abs-br|slidev-icon-btn|grid\s+|grid$|grid-cols-|relative\b)\b[^"']*["']|\bstyle=["'][^"']*\bgrid-[^"']*["'])/i.test(m)){a=!0,r=o.index,l=o[0].length;break}}if(!a){i+=e.slice(n);break}i+=e.slice(n,r);const c=r+l;let u=1,f=-1,d=-1;const p=/<\/?div\b[^>]*>/gi;p.lastIndex=c;let w;for(;(w=p.exec(e))!==null;)if(w[0].startsWith("</")){if(u--,u===0){f=w.index,d=w.index+w[0].length;break}}else u++;if(f!==-1&&d!==-1){const m=e.slice(r,d),b=`__VUE_DIV_TOKEN_${t.length}__`;t.push(m),i+=b,n=d}else i+=e.slice(r,c),n=c}return{text:i,tokens:t}}function rp(e){const t=[];let i=e.replace(/(?:^[ \t]*(`{3,}|~{3,})[^\n\r]*\r?\n[\s\S]*?\r?\n[ \t]*\1(?=[ \t]*(?:\r?\n|$)))/gm,r=>{const l=`__CODE_TOKEN_${t.length}__`;return t.push(r),l});i=i.replace(/(`+)(?:[^\n\r`]|(?!\1)`)+?\1/g,r=>{const l=`__CODE_TOKEN_${t.length}__`;return t.push(r),l});const n=[];i=i.replace(/<script\b[^>]*>[\s\S]*?<\/script>/gi,r=>{const l=`__SCRIPT_TOKEN_${n.length}__`;return n.push(r),l});const{text:s,tokens:o}=op(i);i=s;const a=[];i=i.replace(/<(?:[A-Z][a-zA-Z0-9_-]*|[a-z0-9_-]+:[a-z0-9_-]+|v-[a-z0-9_-]+|arrow\b|div\s+h-\d+)\b[^>]*\/>/gi,r=>{const l=`__VUE_COMP_TOKEN_${a.length}__`;return a.push(r),l}),i=i.replace(/<(v-[a-z0-9_-]+|button)\b([^>]*)>([\s\S]*?)<\/\1>/gi,r=>{const l=`__VUE_COMP_TOKEN_${a.length}__`;return a.push(r),l}),i=i.replace(/<img\b[^>]*?\bv-[a-z0-9_.-]+[^>]*\/?>/gi,r=>{const l=`__VUE_COMP_TOKEN_${a.length}__`;return a.push(r),l}),i=i.replace(/<(p|span)\b([^>]*?\bv-[a-z0-9_.-]+[^>]*)>([\s\S]*?)<\/\1>/gi,r=>{const l=`__VUE_COMP_TOKEN_${a.length}__`;return a.push(r),l}),i=i.replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi,""),i=i.replace(/<div class="terminal-bar">[\s\S]*?<\/div>/gi,""),i=i.replace(/<div class="cursor-line">[\s\S]*?<\/div>/gi,""),i=i.replace(/<span class="cursor">[\s\S]*?<\/span>/gi,""),i=i.replace(/<div class="stamp">\s*([\s\S]*?)\s*<\/div>/gi,`

*[$1]*

`),i=i.replace(/<div class="arrow">\s*([→\->]+)\s*<\/div>/gi,`

$1

`),i=i.replace(/<i>\s*[→\->]+\s*<\/i>/gi,""),i=i.replace(/<div class="prompt">\s*([\s\S]*?)\s*<\/div>/gi,(r,l)=>`
\`\`\`bash
${l.trim()}
\`\`\`
`),i=i.replace(/<p>\s*<i>\$<\/i>\s*([\s\S]*?)<\/p>/gi,(r,l)=>`
\`\`\`bash
$ ${l.trim()}
\`\`\`
`),i=i.replace(/<div class="statusline">\s*([\s\S]*?)\s*<\/div>/gi,(r,l)=>`
> ${Array.from(l.matchAll(/<span>([\s\S]*?)<\/span>/gi)).map(u=>`\`${u[1].trim()}\``).join(" | ")}
`),i=i.replace(/<div class="log-panel">\s*<pre>([\s\S]*?)<\/pre>\s*<\/div>/gi,(r,l)=>`
\`\`\`log
${l.replace(/<span[^>]*>([\s\S]*?)<\/span>/gi,"$1").trim()}
\`\`\`
`),i=Ri(i,"diff-grid",r=>{const l=Array.from(r.matchAll(/<div class="diff\s+([^"]*)">\s*<span>(.*?)<\/span>\s*<pre>([\s\S]*?)<\/pre>\s*<\/div>/gi));return l.length>0?`
`+l.map(c=>{const u=c[2].trim().toUpperCase(),f=c[3].trim();return`**${u}:**
\`\`\`yaml
${f}
\`\`\``}).join(`

`)+`
`:r}),i=Ri(i,"before-after",r=>{const l=r.match(/<div class="before">[\s\S]*?<small>(.*?)<\/small>[\s\S]*?<h2>(.*?)<\/h2>[\s\S]*?<p>(.*?)<\/p>\s*<\/div>/i),c=r.match(/<div class="after">[\s\S]*?<small>(.*?)<\/small>[\s\S]*?<h2>(.*?)<\/h2>[\s\S]*?<p>(.*?)<\/p>\s*<\/div>/i);let u=`
`;return l&&(u+=`### ${l[1]}
## ${l[2]}
${l[3]}

`),c&&(u+=`### ${c[1]}
## ${c[2]}
${c[3]}
`),u.trim()?u:r}),i=i.replace(/<ul\b[^>]*>([\s\S]*?)<\/ul>/gi,(r,l)=>{const c=Array.from(l.matchAll(/<li>\s*(?:<em>)?(\[[x ]\])(?:<\/em>)?\s*([\s\S]*?)<\/li>/gi));return c.length>0?`
`+c.map(u=>`- ${u[1]} ${u[2].trim()}`).join(`
`)+`
`:l}),i=Ri(i,"timeline",r=>{const l=Array.from(r.matchAll(/<div(?:\s+class="([^"]*)")?>\s*<time>([\s\S]*?)<\/time>\s*<b>([\s\S]*?)<\/b>\s*<span>([\s\S]*?)<\/span>\s*<\/div>/gi));return l.length>0?`

`+l.map(c=>{const u=c[1]||"";let f="-";return u.includes("warn")?f="- ⚠️":u.includes("bad")?f="- ❌":u.includes("ok")&&(f="- ✅"),`${f} **${c[2].trim()}** **${c[3].trim()}** — ${c[4].trim()}`}).join(`
`)+`

`:r}),i=Ri(i,"pipeline",r=>{const l=Array.from(r.matchAll(/<div(?:\s+class="([^"]*)")?>\s*<small>([\s\S]*?)<\/small>\s*<b>([\s\S]*?)<\/b>\s*<span>([\s\S]*?)<\/span>\s*<\/div>/gi));return l.length>0?`

`+l.map((c,u)=>{const d=(c[1]||"").includes("hot")?"⚠️ ":"";return`${u+1}. ${d}**${c[3].trim()}** (*${c[4].trim()}*)`}).join(`
`)+`

`:r}),i=Ri(i,"check-grid",r=>{const l=Array.from(r.matchAll(/<div>\s*<span class="([^"]*)"><\/span>\s*<b>([\s\S]*?)<\/b>\s*<p>([\s\S]*?)<\/p>\s*<\/div>/gi));return l.length>0?`

`+l.map(c=>`- ${(c[1]||"").includes("warn")?"⚠️":"✅"} **${c[2].trim()}**: ${c[3].trim()}`).join(`
`)+`

`:r}),i=Ri(i,"manifesto",r=>{const l=Array.from(r.matchAll(/<div>\s*<span>([\s\S]*?)<\/span>\s*<h2>([\s\S]*?)<\/h2>\s*<p>([\s\S]*?)<\/p>\s*<\/div>/gi));return l.length>0?`

`+l.map(c=>`## ${c[1].trim()} ${c[2].trim()}

${c[3].trim()}`).join(`

`)+`

`:r}),i=Ri(i,"split-note",r=>{const l=Array.from(r.matchAll(/<div>\s*<b>([\s\S]*?)<\/b>\s*<p>([\s\S]*?)<\/p>\s*<\/div>/gi));return l.length>0?`

`+l.map(c=>`> **${c[1].trim()}**: ${c[2].trim()}`).join(`
>
`)+`

`:r}),i=i.replace(/<div class="mechanism">\s*<b>([\s\S]*?)<\/b>\s*<p>([\s\S]*?)<\/p>\s*<\/div>/gi,(r,l,c)=>`

> **${l.trim()}**: ${c.trim()}

`),i=i.replace(/<pre>([\s\S]*?)<\/pre>/gi,(r,l)=>`
\`\`\`text
${l.replace(/<span[^>]*>([\s\S]*?)<\/span>/gi,"$1").trim()}
\`\`\`
`),i=i.replace(/<div class="page-head">\s*<span>([\s\S]*?)<\/span>\s*<b>([\s\S]*?)<\/b>\s*<\/div>/gi,`
### $1 ($2)
`),i=i.replace(/<h1\b[^>]*>([\s\S]*?)<\/h1>/gi,`
# $1
`),i=i.replace(/<h2\b[^>]*>([\s\S]*?)<\/h2>/gi,`
## $1
`),i=i.replace(/<h3\b[^>]*>([\s\S]*?)<\/h3>/gi,`
### $1
`),i=i.replace(/<h4\b[^>]*>([\s\S]*?)<\/h4>/gi,`
#### $1
`),i=i.replace(/<p\s+class="ok">\s*●\s*([\s\S]*?)<\/p>/gi,`
✅ **$1**
`),i=i.replace(/<p\s+class="caption">\s*([\s\S]*?)<\/p>/gi,`
> *$1*
`),i=i.replace(/<p\s+class="lead">\s*([\s\S]*?)<\/p>/gi,`
*$1*
`),i=i.replace(/<p\b([^>]*)>([\s\S]*?)<\/p>/gi,(r,l,c)=>/@|v-|:|class=/i.test(l)?r:`
${c.trim()}

`),i=i.replace(/<br\s*\/?>/gi,`
`),i=i.replace(/<hr\s*\/?>/gi,`
---
`),i=i.replace(/<b\b[^>]*>([\s\S]*?)<\/b>/gi,"**$1**"),i=i.replace(/<strong\b[^>]*>([\s\S]*?)<\/strong>/gi,"**$1**"),i=i.replace(/<i\b[^>]*>([\s\S]*?)<\/i>/gi,"*$1*"),i=i.replace(/<code\b[^>]*>([\s\S]*?)<\/code>/gi,(r,l)=>{if(l.startsWith("`")&&l.endsWith("`"))return l;if(l.includes("`")){const c=(l.match(/`+/g)||[]).reduce((f,d)=>Math.max(f,d.length),0),u="`".repeat(c+1);return`${u} ${l} ${u}`}return`\`${l}\``}),i=i.replace(/<small\b[^>]*>([\s\S]*?)<\/small>/gi,"*$1*"),i=i.replace(/\*{4}/g,"** **"),i=i.replace(/<li\b[^>]*>([\s\S]*?)<\/li>/gi,`- $1
`),i=i.replace(/<ul\b[^>]*>([\s\S]*?)<\/ul>/gi,`
$1
`),i=i.replace(/<ol\b[^>]*>([\s\S]*?)<\/ol>/gi,`
$1
`),i=i.replace(/<a\b([^>]*)href=["'](.*?)["']([^>]*)>([\s\S]*?)<\/a>/gi,(r,l,c,u,f)=>{const d=f.trim();return d.includes("<")||d.includes(`
`)?r:`[${d}](${c})`}),i=i.replace(/<blockquote\b[^>]*>([\s\S]*?)<\/blockquote>/gi,(r,l)=>`
`+l.trim().split(`
`).map(c=>`> ${c.trim()}`).join(`
`)+`
`),i=i.replace(/<span\b[^>]*data-type=["']block-ref["'][^>]*data-id=["']([0-9a-zA-Z-]+)["'][^>]*>([\s\S]*?)<\/span>/gi,(r,l,c)=>{const u=c.replace(/<[^>]+>/g,"").trim();return u?`((${l} '${u}'))`:`((${l}))`}),i=i.replace(/<span\b[^>]*data-type=["']a["'][^>]*data-href=["']([^"']+)["'][^>]*>([\s\S]*?)<\/span>/gi,(r,l,c)=>`[${c.replace(/<[^>]+>/g,"").trim()}](${l})`),i=i.replace(/<\/(?:div|section|header|footer|main|article|nav|aside)\b[^>]*>/gi,`
`),i=i.replace(/<(?:div|section|header|footer|main|article|nav|aside)\b[^>]*>/gi,""),i=i.replace(/<\/?span\b[^>]*>/gi,"");for(let r=0;r<a.length;r++)i=i.replace(`__VUE_COMP_TOKEN_${r}__`,()=>a[r]);for(let r=0;r<o.length;r++)i=i.replace(`__VUE_DIV_TOKEN_${r}__`,()=>o[r]);for(let r=0;r<n.length;r++)i=i.replace(`__SCRIPT_TOKEN_${r}__`,()=>n[r]);for(let r=0;r<t.length;r++)i=i.replace(`__CODE_TOKEN_${r}__`,()=>t[r]);return i=i.replace(/\n{3,}/g,`

`).trim(),i}function Hl(e){if(!e||typeof e!="string")return"";const t=[];let i=e.replace(/`([^`]+)`/g,n=>(t.push(n),`%%INLINE_CODE_${t.length-1}%%`));return i=i.replace(/(<\/[a-zA-Z0-9_-]+>)\s*\{:[^}]*\}/g,"$1"),i=i.replace(/(\[[^\]]+\]\([^)]+\))\s*\{:\s*style=["']([^"']*)["'][^}]*\}/g,'<span style="$2">$1</span>'),i=i.replace(/(\*\*[^*]+\*\*)\s*\{:\s*style=["']([^"']*)["'][^}]*\}/g,'<span style="$2">$1</span>'),i=i.replace(/(\*[^*]+\*)\s*\{:\s*style=["']([^"']*)["'][^}]*\}/g,'<span style="$2">$1</span>'),i=i.replace(/(~~[^~]+~~)\s*\{:\s*style=["']([^"']*)["'][^}]*\}/g,'<span style="$2">$1</span>'),i=i.replace(/([\p{L}\p{N}_\-]+)\s*\{:\s*style=["']([^"']*)["'][^}]*\}/gu,'<span style="$2">$1</span>'),i=i.replace(/\{:[^}]*\}/g,""),i=i.replace(/%%INLINE_CODE_(\d+)%%/g,(n,s)=>t[parseInt(s,10)]||""),i}function ap(e){const t=Object.entries(e).filter(([n,s])=>s!=null&&s!=="");return t.length===0?"":`---
${t.map(([n,s])=>typeof s=="string"?s.includes(":")||s.includes(`
`)||s.includes("#")?`${n}: "${s.replace(/"/g,'\\"')}"`:`${n}: ${s}`:`${n}: ${JSON.stringify(s)}`).join(`
`)}
---`}function lp(e,t){if(!t||!e.startsWith("```"))return e;const i=e.indexOf(`
`);if(i===-1)return e;const n=e.slice(0,i).trim(),s=e.slice(i);return n.includes("{")?e:`${n} {${t}}${s}`}function Fl(e,t){if(t==null)return e;const i=t.trim();return i===""||i==="+1"?`<v-click>

${e}

</v-click>`:i==="hide"?`<v-click hide>

${e}

</v-click>`:`<v-click at="${i}">

${e}

</v-click>`}function cp(e){if(!e||!e.preset)return null;const t=e.preset.toLowerCase().trim();if(!t||t==="none")return null;let i={opacity:0},n={opacity:1};switch(t){case"slide-up":i={y:40,opacity:0},n={y:0,opacity:1};break;case"slide-down":i={y:-40,opacity:0},n={y:0,opacity:1};break;case"slide-left":i={x:40,opacity:0},n={x:0,opacity:1};break;case"slide-right":i={x:-40,opacity:0},n={x:0,opacity:1};break;case"zoom-in":case"pop":i={scale:.8,opacity:0},n={scale:1,opacity:1};break;case"bounce":i={y:40,opacity:0},n={y:0,opacity:1,transition:{type:"spring",damping:10,stiffness:100}};break;case"fade-in":default:i={opacity:0},n={opacity:1};break}e.initial&&typeof e.initial=="object"&&(i={...i,...e.initial}),e.enter&&typeof e.enter=="object"&&(n={...n,...e.enter});const s={...n.transition||{}};return typeof e.duration=="number"&&e.duration>0&&(s.duration=e.duration),typeof e.delay=="number"&&e.delay>0&&(s.delay=e.delay),Object.keys(s).length>0&&(n.transition=s),{initial:i,enter:n}}function ls(e,t,i,n,s){const o=t!=null&&t.trim()!=="",a=cp(i),r=s?/^\d+$/.test(s.trim())?`${s.trim()}px`:s.trim():"",l=r?`max-height:${r};overflow-y:auto`:"",c=[n==null?void 0:n.trim(),l].filter(Boolean).join(";"),u=c!==void 0&&c!=="",f=u?` style="${c.replace(/"/g,"&quot;")}" class="slide-styled-block"`:"";if(!o&&!a)return u?`<div${f}>

${e}

</div>`:e;if(o&&!a){if(u){const y=t.trim();let v="v-click";return y==="hide"?v="v-click.hide":y!==""&&y!=="+1"&&(v=`v-click="${y}"`),`<div ${v}${f}>

${e}

</div>`}return Fl(e,t)}const d=JSON.stringify(a.initial).replace(/"/g,"'"),p=JSON.stringify(a.enter).replace(/"/g,"'"),w=`v-motion :initial="${d}" :enter="${p}"`;if(!o)return`<div ${w}${f}>

${e}

</div>`;const m=t.trim();let b="v-click";return m==="hide"?b="v-click.hide":m!==""&&m!=="+1"&&(b=`v-click="${m}"`),`<div ${b} ${w}${f}>

${e}

</div>`}function hr(e){if(!e)return"";let t=e.trim();t=t.replace(/\{:[^}]*\}/g,"").trim(),t=t.replace(/^:::\s*[a-zA-Z0-9_-]*\s*\r?\n?/g,""),t=t.replace(/\r?\n?:::\s*$/g,"");let s=t.split(/\r?\n/).map(o=>o.trim().replace(/^>\s*/,"")).join(`
`).trim();return s=s.replace(/^\[!(?:NOTE|TIP|IMPORTANT|WARNING|CAUTION|[A-Za-z_-]+)\][^\r\n]*(?:\r?\n)?/i,"").trim(),s=s.replace(/^(?:💡|✏️|❗|⚠️|🚨|\s*)*(?:\*\*|__)?(?:演讲备注|演讲者提词|讲稿备注|演讲提词|备注|Notes?)(?:\*\*|__)?[:：]?\s*(?:\r?\n)?/i,"").trim(),s=s.replace(/^[-*+]\s+/,""),s=s.replace(/^\d+\.\s+/,""),s.trim()}function dp(e){var n;if(e.subType&&/^h([1-6])$/i.test(e.subType))return parseInt(e.subType.slice(1),10);const i=(e.markdown||e.content||"").trim().match(/^(#{1,6})\s+/);return i?i[1].length:e.type==="h"?(n=e.ial)!=null&&n.subType&&/^h([1-6])$/i.test(e.ial.subType)?parseInt(e.ial.subType.slice(1),10):1:null}function jl(e,t=2){const i=Math.max(2,t);if(!e||e.length===0)return Array.from({length:i},()=>[]);if(e.length===1&&e[0].children&&e[0].children.length>=2){const c=e[0].children,u=Array.from({length:i},()=>[]),f=Math.min(i,c.length),d=Math.floor(c.length/f),p=c.length%f;let w=0;for(let m=0;m<f;m++){const b=d+(m<p?1:0);u[m]=c.slice(w,w+b),w+=b}return u}if(e.length===1){const c=e[0],f=(c.slot||"").trim().match(/^col-(\d+)$/i),d=f?parseInt(f[1],10):null,p=(c.rawMarkdown||c.content||"").trim(),w=p.split(/\r?\n/),m=[];for(let v=0;v<w.length;v++)/^[ \t]*[-*+]\s+|^[ \t]*\d+\.\s+/.test(w[v])&&m.push(v);if(m.length>=i){const v=Array.from({length:i},()=>[]);let k=0;for(let S=0;S<i;S++){const B=i-S,A=m.length-k,C=Math.ceil(A/B),L=m[k],z=k+C<m.length?m[k+C]:w.length,N=w.slice(L,z).join(`
`);v[S]=[{...c,id:S===0?c.id:`${c.id}-col${S+1}`,rawMarkdown:N,content:N}],k+=C}return v}const b=p.match(/<li[\s\S]*?<\/li>/gi);if(b&&b.length>=i){const v=Array.from({length:i},()=>[]);let k=0;for(let S=0;S<i;S++){const B=i-S,A=b.length-k,C=Math.ceil(A/B),L=`<ul>
${b.slice(k,k+C).join(`
`)}
</ul>`;v[S]=[{...c,id:S===0?c.id:`${c.id}-col${S+1}`,rawMarkdown:L,content:L}],k+=C}return v}const y=p.split(/\r?\n\s*\r?\n/).filter(v=>v.trim()!=="");if(y.length>=i){const v=Array.from({length:i},()=>[]);let k=0;for(let S=0;S<i;S++){const B=i-S,A=y.length-k,C=Math.ceil(A/B),L=y.slice(k,k+C).join(`

`);v[S]=[{...c,id:S===0?c.id:`${c.id}-col${S+1}`,rawMarkdown:L,content:L}],k+=C}return v}if(d&&d>=1&&d<=i){const v=Array.from({length:i},()=>[]);return v[d-1]=[c],v}return[[c],...Array.from({length:i-1},()=>[])]}const n=c=>{const u=(c.slot||"").trim();if(!u)return null;if(u==="left")return 1;if(u==="center")return 2;if(u==="right")return i===2?2:i;const f=u.match(/^col-(\d+)$/i);if(f){const d=parseInt(f[1],10);if(d>=1&&d<=i)return d}return null},s=e.map(n);if(s.some(c=>c!==null)){if(s.some(p=>p!==null&&p>=2)){const p=Array.from({length:i},()=>[]);let w=1;for(const b of e){const y=n(b);y!==null&&(w=y),p[w-1].push(b)}if(!e.some(b=>/^col-\d+$/i.test((b.slot||"").trim()))&&p[0].length===0){const b=p.filter(y=>y.length>0);if(b.length===1)return[b[0],...Array.from({length:i-1},()=>[])]}return p}const u=e.filter(p=>n(p)===1),f=e.filter(p=>n(p)===null),d=i-1;if(f.length>=d){const p=Math.floor(f.length/d),w=f.length%d,m=[u];let b=0;for(let y=0;y<d;y++){const v=p+(y<w?1:0);m.push(f.slice(b,b+v)),b+=v}return m}else if(f.length>0){const p=[u];for(let w=0;w<d;w++)p.push(w<f.length?[f[w]]:[]);return p}else return[u,...Array.from({length:d},()=>[])]}const a=c=>{if(c.type==="h"||c.subType&&/^h[1-6]$/i.test(c.subType))return!0;const u=(c.rawMarkdown||c.content||"").trim();return/^#{1,6}\s+/.test(u)},r=e.map((c,u)=>a(c)?u:-1).filter(c=>c!==-1);if(r.length>=i){const c=Array.from({length:i},()=>[]);for(let u=0;u<i;u++){const f=r[u],d=u+1<i?r[u+1]:e.length;c[u]=e.slice(f,d)}return c}if(e.length>=i){const c=Array.from({length:i},()=>[]);let u=0;for(let f=0;f<i;f++){const d=i-f,p=e.length-u,w=Math.ceil(p/d);c[f]=e.slice(u,u+w),u+=w}return c}if(e.length>1&&e.length<i){const c=Array.from({length:i},()=>[]);for(let u=0;u<e.length;u++)c[u]=[e[u]];return c}const l=Array.from({length:i},()=>[]);return l[0]=e,l}function ca(e,t,i,n){var w;const s=Xf(t),o=[],a=aa(t),r=s.background?$t(s.background,n):void 0;let l={pageIndex:1,startBlockId:e,frontmatter:{layout:a.frontmatter.layout||"cover",...a.frontmatter,...r?{background:r}:{}},notes:"",noteBlocks:[],blocks:[],rawMarkdown:"",allBlockIds:[e]};l.frontmatter.background&&(l.frontmatter.background=$t(l.frontmatter.background,n)),l.frontmatter.image&&(l.frontmatter.image=$t(l.frontmatter.image,n));const c=m=>{const b=[];for(let y=m;y<i.length&&!(y>m&&ui(i[y]));y++)b.push(i[y]);return b},u=m=>{let b,y,v;const k=S=>{var z;if(b)return;const B=ti(S);if(B){b=B.layout,y=B.imageUrl,v=B.ratio;return}const A=_r(S),C=S.ial?{...S.ial}:{},L=la(C);if(L.imageLayout==="image-left"||L.imageLayout==="image-right"){const N=hi(A,S.content);if(N){b=L.imageLayout,y=N,v=(z=S.ial)==null?void 0:z[bt];return}}if(S.children&&S.children.length>0){for(const N of S.children)if(k(N),b)return}};for(const S of m)if(k(S),b)break;return{foundLayout:b,foundImage:y,foundRatio:v}},f=(m,b)=>{const{foundLayout:y,foundImage:v,foundRatio:k}=u(b);y&&(m.frontmatter.layout=y,v&&(m.frontmatter.image=$t(v,n)),k&&!m.frontmatter.layoutRatio&&(m.frontmatter.layoutRatio=k))};f(l,c(0)),o.push(l);let d=[];for(let m=0;m<i.length;m++){const b=i[m];if(ui(b)){d=[];const v=aa(b.ial);if(o.length===1&&l.blocks.length===0){l.startBlockId=b.id,l.allBlockIds||(l.allBlockIds=[]),l.allBlockIds.includes(b.id)||l.allBlockIds.push(b.id),v.frontmatter.layout&&(l.frontmatter.layout=v.frontmatter.layout),Object.assign(l.frontmatter,v.frontmatter),delete l.frontmatter.background,!v.frontmatter.image&&a.frontmatter.image&&(l.frontmatter.image=a.frontmatter.image),r&&(l.frontmatter.background=r),l.frontmatter.background&&(l.frontmatter.background=$t(l.frontmatter.background,n)),l.frontmatter.image&&(l.frontmatter.image=$t(l.frontmatter.image,n)),f(l,c(m+1));continue}l={pageIndex:o.length+1,startBlockId:b.id,frontmatter:{layout:v.frontmatter.layout||"default",...v.frontmatter,...r?{background:r}:{}},notes:"",noteBlocks:[],blocks:[],rawMarkdown:"",allBlockIds:[b.id]},r||delete l.frontmatter.background,l.frontmatter.background&&(l.frontmatter.background=$t(l.frontmatter.background,n)),l.frontmatter.image&&(l.frontmatter.image=$t(l.frontmatter.image,n)),f(l,c(m+1)),o.push(l);continue}const y=(v,k)=>{var re,Se,Ie,_e,fe,X,pe;if(l.allBlockIds||(l.allBlockIds=[]),v.id&&!l.allBlockIds.includes(v.id)&&l.allBlockIds.push(v.id),v.children&&v.children.length>0){const E=F=>{for(const g of F)g.id&&!l.allBlockIds.includes(g.id)&&l.allBlockIds.push(g.id),g.children&&g.children.length>0&&E(g.children)};E(v.children)}let S=_r(v),B=v.ial?{...v.ial}:{};const A=S.match(/\{:\s*([^}]+)\s*\}\s*$/);A&&(B={..._a(A[0]),...B},S=S.slice(0,A.index).trim()),v.type!=="c"&&!S.startsWith("```")&&(S=Hl(S));let C=S.trim();if(/^\{\{\{(?:row|col)?\s*$/i.test(C)||C==="}}}")return;/^\{\{\{(?:row|col)?\s*\r?\n/i.test(C)&&/\r?\n\}\}\}$/.test(C)&&(S=C.replace(/^\{\{\{(?:row|col)?\s*\r?\n/i,"").replace(/\r?\n\}\}\}$/,"").trim(),C=S.trim());const L=la(B);if(S=Sd(S,n),S=wd(S,n==null?void 0:n.refContentMap),v.children&&v.children.length>0){const E=["custom-slides-autoplay","custom-slides-loop","custom-slides-muted","custom-slides-controls"],F=g=>{for(const W of g){if(W.ial)for(const[j,M]of Object.entries(W.ial))E.includes(j)&&!B[j]&&(B[j]=M);W.children&&W.children.length>0&&F(W.children)}};F(v.children)}const z=v.type==="video"||v.type==="NodeVideo"||/<video\b/i.test(S);if(z){const E=B["custom-slides-autoplay"]==="true",F=B["custom-slides-loop"]==="true",g=B["custom-slides-muted"]==="true"||E,W=B["custom-slides-controls"]==="false";S=S.replace(/<video\b([^>]*)>/gi,(j,M)=>{let I=M;return W?I=I.replace(/\bcontrols(?:="[^"]*")?/gi,"").trim():/controls/i.test(I)||(I+=" controls"),E&&!/autoplay/i.test(I)?I+=" autoplay playsinline":!E&&B["custom-slides-autoplay"]==="false"&&(I=I.replace(/\bautoplay\b/gi,"").replace(/\bplaysinline\b/gi,"").trim()),F&&!/loop/i.test(I)?I+=" loop":!F&&B["custom-slides-loop"]==="false"&&(I=I.replace(/\bloop\b/gi,"").trim()),g&&!/muted/i.test(I)?I+=" muted":!g&&B["custom-slides-muted"]==="false"&&(I=I.replace(/\bmuted\b/gi,"").trim()),`<video ${I.trim()}>`})}if(L.isBackground){const E=hi(S,v.content);if(E){l.frontmatter.background=$t(E,n);return}}const N=ti(v);if(N){l.frontmatter.layout=N.layout,l.frontmatter.image=$t(N.imageUrl,n),!l.frontmatter.layoutRatio&&N.ratio&&(l.frontmatter.layoutRatio=N.ratio);for(const E of N.contentNodes)y(E);return}if(L.imageLayout==="image-left"||L.imageLayout==="image-right"){const E=hi(S,v.content);if(E){l.frontmatter.layout=L.imageLayout,l.frontmatter.image=$t(E,n),!l.frontmatter.layoutRatio&&((re=v.ial)!=null&&re[bt])&&(l.frontmatter.layoutRatio=v.ial[bt]);return}}if(at(v)&&v.children&&v.children.length>0){for(const E of v.children)y(E);return}const K=!!(L.slot||k!=null&&k.defaultSlot||l.frontmatter.layout==="clover"||on(l.frontmatter.layout)||l.frontmatter.layout==="two-cols"),_=!!(v.children&&v.children.some(E=>{var F,g;return((F=E.ial)==null?void 0:F[Me])||((g=E.ial)==null?void 0:g[Ne])||E.children&&E.children.length>=2||E.children&&E.children.some(W=>{var j,M,I,R,G,D;return((j=W.ial)==null?void 0:j[Ne])||((M=W.ial)==null?void 0:M[Me])||((I=W.ial)==null?void 0:I[Ze])||((R=W.ial)==null?void 0:R[ke])||((G=W.ial)==null?void 0:G["custom-slides-role"])||((D=W.ial)==null?void 0:D["custom-slides-layout"])})}));if((v.type==="l"||v.type==="NodeList"||v.type==="list")&&v.children&&v.children.length>0&&(_||L.slot||L.clicks||K)){const E=/^\s*\d+\.\s+/m.test(v.markdown||"")||v.subType==="o"||v.subtype==="o";for(let F=0;F<v.children.length;F++){const g=v.children[F];L.slot&&(!g.ial||!g.ial[Me])&&(g.ial||(g.ial={}),g.ial[Me]=L.slot),y(g,{...k,parentClicks:L.clicks||(k==null?void 0:k.parentClicks),defaultSlot:L.slot||(k==null?void 0:k.defaultSlot),isParentListUnpacked:!0,isListItem:!0,listContext:{isOrdered:E,itemIndex:F+1}})}return}const U=!!(k!=null&&k.isParentListUnpacked),x=!!(v.children&&v.children.length>=2)||!!L.clicks||!!((Se=v.children)!=null&&Se.some(E=>{var F;return(F=E.ial)==null?void 0:F[Ne]}))||U||!v.markdown&&!!(v.children&&v.children.length>0);if(Ai(v)&&v.children&&v.children.length>0&&(K||U||L.clicks||v.children.some(E=>{var F;return(F=E.ial)==null?void 0:F[Ne]}))&&x){const E=!!(v.children&&v.children.length>=2),F=v.children.find(G=>!!(G.markdown||G.content||"").trim())||v.children[0],g=((Ie=F==null?void 0:F.ial)==null?void 0:Ie[Ne])||((_e=F==null?void 0:F.ial)==null?void 0:_e["custom-slides-click"]),W=!!(!L.clicks&&E&&g),j=L.clicks||(W?g:void 0)||(k==null?void 0:k.parentClicks),M=v.id||(k==null?void 0:k.parentContainerId),I=L.slot||(k==null?void 0:k.defaultSlot);let R=!0;for(const G of v.children){I&&(!G.ial||!G.ial[Me])&&(G.ial||(G.ial={}),G.ial[Me]=I);const D=!!(G.markdown||G.content||"").trim(),H=R&&D;if(H){if(!(l.frontmatter.layout==="image-right"||l.frontmatter.layout==="image-left")&&!!(l.frontmatter.layout==="clover"||on(l.frontmatter.layout)||l.frontmatter.layout==="two-cols")&&!!(k!=null&&k.defaultSlot||L.slot||(fe=v.ial)!=null&&fe[Me]))G.markdown&&(G.markdown=Pn(G.markdown)),G.content&&(G.content=Pn(G.content));else{const $e=!!((X=k==null?void 0:k.listContext)!=null&&X.isOrdered),xe=((pe=k==null?void 0:k.listContext)==null?void 0:pe.itemIndex)||1,De=$e?`${xe}. `:"- ",je=ze=>{if(!ze)return De.trim();const le=ze.trim();return/^[-*+]\s+/.test(le)||/^\d+\.\s+/.test(le)?ze:`${De}${ze}`};G.markdown&&(G.markdown=je(G.markdown)),G.content&&(G.content=je(G.content))}R=!1}let Z=G;H&&j&&E?(Z={...G,ial:{...G.ial||{}}},delete Z.ial[Ne],delete Z.ial["custom-slides-click"]):!E&&j&&(Z={...G,ial:{...G.ial||{},[Ne]:j}}),y(Z,{...k,parentClicks:j,parentContainerId:M,defaultSlot:I,isListItem:!0})}return}if(L.isNote){const E=hr(S);E&&(l.notes?l.notes+=`

`+E:l.notes=E),l.noteBlocks||(l.noteBlocks=[]),l.noteBlocks.push({id:v.id,type:v.type,content:E||v.content||"",rawMarkdown:S,isNote:!0,attributes:v.ial});return}L.shikiLines&&(S=lp(S,L.shikiLines)),C=S.trim();const q=(v.content||"").trim();if(C==="::right::"||q==="::right::"||/^<p>\s*::right::\s*<\/p>$/i.test(C)||C.startsWith("::right::")){l.blocks.push({id:v.id,type:v.type,content:"::right::",rawMarkdown:"::right::",slot:"slot-divider-right",attributes:v.ial});return}const $=dp(v);let T=L.slot,P=L.clicks,se=L.motion,V={...v.ial||{}};if($!==null){for(;d.length>0&&d[d.length-1].level>=$;)d.pop();const E=d.length>0?d[d.length-1]:void 0;!T&&(E!=null&&E.slot)&&(T=E.slot),!P&&(E!=null&&E.clicks)&&!(k!=null&&k.parentContainerId)&&(P=E.clicks),!se&&(E!=null&&E.motion)&&(se=E.motion);const F={...(E==null?void 0:E.customAttrs)||{}};if(v.ial)for(const[g,W]of Object.entries(v.ial))g.startsWith("custom-slides-")&&!g.startsWith("custom-slides-slide")&&(F[g]=W);k!=null&&k.parentContainerId||d.push({level:$,slot:T,clicks:P,motion:se,customAttrs:F})}else{const E=d.length>0?d[d.length-1]:void 0;E&&(!T&&E.slot&&E.slot!=="header"&&(T=E.slot),!P&&E.clicks&&!(k!=null&&k.parentContainerId)&&(P=E.clicks),!se&&E.motion&&(se=E.motion),E.customAttrs&&(V={...E.customAttrs,...V}))}!T&&l.blocks.some(E=>E.slot==="slot-divider-right")&&(T="right"),!T&&(k!=null&&k.defaultSlot)&&(T=k.defaultSlot),T&&(V[Me]=T),P&&!V[Ne]&&(V[Ne]=P),se&&!V[Xt]&&(V[Xt]=JSON.stringify(se)),(z||B["custom-slides-autoplay"]||B["custom-slides-muted"])&&(B["custom-slides-autoplay"]&&(V["custom-slides-autoplay"]=B["custom-slides-autoplay"],B["custom-slides-autoplay"]==="true"&&!B["custom-slides-muted"]&&(V["custom-slides-muted"]="true")),B["custom-slides-loop"]&&(V["custom-slides-loop"]=B["custom-slides-loop"]),B["custom-slides-muted"]&&(V["custom-slides-muted"]=B["custom-slides-muted"]),B["custom-slides-controls"]&&(V["custom-slides-controls"]=B["custom-slides-controls"]));const Y=L.maxHeight?/^\d+$/.test(L.maxHeight.trim())?`${L.maxHeight.trim()}px`:L.maxHeight.trim():void 0,ce=!!(k!=null&&k.isListItem||Ai(v)),ie={id:v.id,type:v.type,content:v.content||"",rawMarkdown:S,clicks:P,parentClicks:k==null?void 0:k.parentClicks,parentContainerId:k==null?void 0:k.parentContainerId,motion:se,shikiLines:L.shikiLines,maxHeight:Y,slot:T,attributes:V,attrs:V,rawNode:v,isListItem:ce};l.blocks.push(ie)};y(b)}for(let m=0;m<o.length;m++){const b=o[m],y=[],v={...b.frontmatter};m===0&&(v.theme=s.theme,v.aspectRatio=s.aspectRatio,v.highlighter=s.highlighter,v.transition=b.frontmatter.transition||s.defaultTransition);const k=ap(v);k&&y.push(k);const S=b.blocks.filter(z=>z.slot!=="slot-divider-right"),B=z=>z.filter(N=>!!(N.rawMarkdown||N.content||"").trim()).map(N=>{var K;return ls(N.rawMarkdown,N.clicks,N.motion,(K=N.attributes)==null?void 0:K.style,N.maxHeight)}).join(`

`),A=z=>{const N=z.filter(x=>!!(x.rawMarkdown||x.content||"").trim());if(N.length===0)return;const K=N[0],_=(K.rawMarkdown||K.content||"").trim();(Ai(K)||/^(?:[-*+]|\d+\.)\s+/.test(_))&&(K.rawMarkdown=Pn(K.rawMarkdown||K.content||""),K.content=K.rawMarkdown)},C=z=>{var x,q;if(z.length===0)return"";A(z);const N=(x=z.find(O=>O.parentClicks))==null?void 0:x.parentClicks;if(!N)return z.filter(O=>!!(O.rawMarkdown||O.content||"").trim()).map(O=>{var $;return ls(O.rawMarkdown,O.clicks,O.motion,($=O.attributes)==null?void 0:$.style,O.maxHeight)}).join(`

`);const K=[];let _=[];const U=()=>{if(_.length===0)return;const O=_.map($=>($.rawMarkdown||$.content||"").trim()).filter(Boolean).join(`

`);O&&K.push(Fl(O,N)),_=[]};for(const O of z){if(!(O.rawMarkdown||O.content||"").trim())continue;!!(O.clicks&&O.clicks.trim()!=="")?(U(),K.push(ls(O.rawMarkdown,O.clicks,O.motion,(q=O.attributes)==null?void 0:q.style,O.maxHeight))):_.push(O)}return U(),K.join(`

`)},L=b.frontmatter.layout||"default";if(L==="clover"||on(L)){let z=[];const N=S.filter(O=>O.slot==="header");if(N.length>0)z=N;else if(S.length>0){const O=S.find($=>$.type==="h"&&(!$.slot||$.slot==="default"));O&&(z=[O])}const K=S.filter(O=>!z.includes(O));let _=2;if(L==="clover")_=4;else if(L==="three-cols-header")_=3;else if(L==="two-cols-header")_=2;else{let O=0;for(const $ of K){const T=($.slot||"").match(/^col-(\d+)$/i);T&&(O=Math.max(O,parseInt(T[1],10)))}if(O>=2)_=O;else if(b.frontmatter.layoutRatio){const $=b.frontmatter.layoutRatio.trim();if($.includes(":")){const T=$.split(":").map(P=>parseFloat(P.trim())).filter(P=>!isNaN(P)&&P>0);T.length>=2&&(_=T.length)}else{const T=$.split(/\s+/).filter(Boolean);T.length>=2&&(_=T.length)}}else K.length===1&&K[0].children&&K[0].children.length>=2&&(_=Math.min(6,K[0].children.length))}const U=jl(K,_);U.forEach((O,$)=>{const T=`col-${$+1}`;for(const P of O)(!P.slot||P.slot==="default")&&(P.slot=T);A(O)});const x=U.flat();if(K.length===1&&x.length>1){const O=b.blocks.findIndex($=>$.id===K[0].id);O!==-1&&b.blocks.splice(O,1,...x)}const q=B(z);if(q&&y.push(q),L==="two-cols-header"&&_===2){const O=C(U[0]||[]),$=C(U[1]||[]);O&&y.push(`::left::

${O}`),$&&y.push(`::right::

${$}`)}else U.forEach((O,$)=>{const T=C(O);T&&y.push(`::col-${$+1}::

${T}`)})}else if(L==="two-cols"){const z=S.filter(U=>U.slot==="left"),N=S.filter(U=>U.slot==="right");A(z),A(N);const K=B(z.length>0?z:S.filter(U=>U.slot!=="right")),_=B(N);y.push(K),_&&y.push(`::right::

${_}`)}else for(const z of S)y.push(ls(z.rawMarkdown,z.clicks||z.parentClicks,z.motion,(w=z.attributes)==null?void 0:w.style,z.maxHeight));b.notes&&y.push(`<!--
${b.notes}
-->`),b.rawMarkdown=y.join(`

`).trim()}const p=o.map(m=>m.rawMarkdown).filter(Boolean).join(`

---

`);return{docId:e,config:s,slides:o,fullMarkdown:p}}const zo=`/* SiYuan Note Built-in Font & Background Styles for Slidev */
:root,
html:not(.dark),
[data-theme="light"],
[data-theme-mode="light"] {
  /* 思源基础卡片与主题色 (浅色模式 daylight) */
  --b3-card-error-color: #790600;
  --b3-card-error-background: #f5d1cf;
  --b3-card-warning-color: #8a4f00;
  --b3-card-warning-background: #ffe8c8;
  --b3-card-info-color: #005599;
  --b3-card-info-background: #d6eaf9;
  --b3-card-success-color: #006b04;
  --b3-card-success-background: #d7eed8;

  --b3-theme-primary: #3575f0;
  --b3-theme-secondary: #ff9200;
  --b3-theme-error: #d23f31;
  --b3-theme-background: #ffffff;
  --b3-theme-on-background: #222222;
  --b3-theme-on-surface: #5f6368;
  --b3-theme-surface-lighter: #e0e0e0;

  /* 13 种内置文字颜色 */
  --b3-font-color1: var(--b3-card-error-color);
  --b3-font-color2: var(--b3-card-warning-color);
  --b3-font-color3: var(--b3-card-info-color);
  --b3-font-color4: var(--b3-card-success-color);
  --b3-font-color5: var(--b3-theme-on-surface);
  --b3-font-color6: var(--b3-theme-primary);
  --b3-font-color7: var(--b3-theme-secondary);
  --b3-font-color8: var(--b3-theme-error);
  --b3-font-color9: #a40074;
  --b3-font-color10: #007080;
  --b3-font-color11: #006e2a;
  --b3-font-color12: #6b5a00;
  --b3-font-color13: var(--b3-theme-background);

  /* 13 种内置背景颜色 */
  --b3-font-background1: var(--b3-card-error-background);
  --b3-font-background2: var(--b3-card-warning-background);
  --b3-font-background3: var(--b3-card-info-background);
  --b3-font-background4: var(--b3-card-success-background);
  --b3-font-background5: #e2e3e4;
  --b3-font-background6: #acd0fc;
  --b3-font-background7: #fddaab;
  --b3-font-background8: #ffb0a9;
  --b3-font-background9: #fdbfff;
  --b3-font-background10: #b1ffff;
  --b3-font-background11: #affad1;
  --b3-font-background12: #fff88f;
  --b3-font-background13: var(--b3-theme-on-background);
}

html.dark,
[data-theme="dark"],
[data-theme-mode="dark"],
.theme-dark,
.dark {
  /* 思源基础卡片与主题色 (深色模式 midnight) */
  --b3-card-error-color: rgb(243, 153, 147);
  --b3-card-error-background: #442724;
  --b3-card-warning-color: rgb(255, 213, 153);
  --b3-card-warning-background: #554636;
  --b3-card-info-color: rgb(166, 213, 250);
  --b3-card-info-background: #28405c;
  --b3-card-success-color: rgb(183, 223, 185);
  --b3-card-success-background: #425347;

  --b3-theme-primary: #3575f0;
  --b3-theme-secondary: #ff9200;
  --b3-theme-error: #d23f31;
  --b3-theme-background: #1e1e1e;
  --b3-theme-on-background: #c8ccd6;
  --b3-theme-on-surface: #8b949e;
  --b3-theme-surface-lighter: #282a2e;

  /* 13 种内置文字颜色 */
  --b3-font-color1: var(--b3-card-error-color);
  --b3-font-color2: var(--b3-card-warning-color);
  --b3-font-color3: var(--b3-card-info-color);
  --b3-font-color4: var(--b3-card-success-color);
  --b3-font-color5: var(--b3-theme-on-surface);
  --b3-font-color6: var(--b3-theme-primary);
  --b3-font-color7: var(--b3-theme-secondary);
  --b3-font-color8: var(--b3-theme-error);
  --b3-font-color9: #f47c9c;
  --b3-font-color10: #4dd0e1;
  --b3-font-color11: #10df54;
  --b3-font-color12: #ecd424;
  --b3-font-color13: var(--b3-theme-background);

  /* 13 种内置背景颜色 */
  --b3-font-background1: var(--b3-card-error-background);
  --b3-font-background2: var(--b3-card-warning-background);
  --b3-font-background3: var(--b3-card-info-background);
  --b3-font-background4: var(--b3-card-success-background);
  --b3-font-background5: #3a3f42;
  --b3-font-background6: #031840;
  --b3-font-background7: #593905;
  --b3-font-background8: #3a0c09;
  --b3-font-background9: #4d1b40;
  --b3-font-background10: #1a5459;
  --b3-font-background11: #305415;
  --b3-font-background12: #4a4712;
  --b3-font-background13: var(--b3-theme-on-background);
}

@media (prefers-color-scheme: dark) {
  :root:not([data-theme="light"]):not([data-theme-mode="light"]):not(.light) {
    --b3-card-error-color: rgb(243, 153, 147);
    --b3-card-error-background: #442724;
    --b3-card-warning-color: rgb(255, 213, 153);
    --b3-card-warning-background: #554636;
    --b3-card-info-color: rgb(166, 213, 250);
    --b3-card-info-background: #28405c;
    --b3-card-success-color: rgb(183, 223, 185);
    --b3-card-success-background: #425347;

    --b3-theme-primary: #3575f0;
    --b3-theme-secondary: #ff9200;
    --b3-theme-error: #d23f31;
    --b3-theme-background: #1e1e1e;
    --b3-theme-on-background: #c8ccd6;
    --b3-theme-on-surface: #8b949e;
    --b3-theme-surface-lighter: #282a2e;

    --b3-font-color1: var(--b3-card-error-color);
    --b3-font-color2: var(--b3-card-warning-color);
    --b3-font-color3: var(--b3-card-info-color);
    --b3-font-color4: var(--b3-card-success-color);
    --b3-font-color5: var(--b3-theme-on-surface);
    --b3-font-color6: var(--b3-theme-primary);
    --b3-font-color7: var(--b3-theme-secondary);
    --b3-font-color8: var(--b3-theme-error);
    --b3-font-color9: #f47c9c;
    --b3-font-color10: #4dd0e1;
    --b3-font-color11: #10df54;
    --b3-font-color12: #ecd424;
    --b3-font-color13: var(--b3-theme-background);

    --b3-font-background1: var(--b3-card-error-background);
    --b3-font-background2: var(--b3-card-warning-background);
    --b3-font-background3: var(--b3-card-info-background);
    --b3-font-background4: var(--b3-card-success-background);
    --b3-font-background5: #3a3f42;
    --b3-font-background6: #031840;
    --b3-font-background7: #593905;
    --b3-font-background8: #3a0c09;
    --b3-font-background9: #4d1b40;
    --b3-font-background10: #1a5459;
    --b3-font-background11: #305415;
    --b3-font-background12: #4a4712;
    --b3-font-background13: var(--b3-theme-on-background);
  }
}

/* 演示块级样式排版增强 (带背景色时赋予呼吸内边距与舒适圆角) */
.slide-styled-block {
  border-radius: 6px;
  padding: 8px 14px;
  box-sizing: border-box;
  margin: 6px 0;
  transition: background-color 0.2s ease, color 0.2s ease;
}

/* 行内带背景色文本的精美圆角与微边距 */
span[style*="background-color"],
span[style*="background:"] {
  border-radius: 3px;
  padding: 1px 5px;
  box-decoration-break: clone;
  -webkit-box-decoration-break: clone;
}
`;function up(e){var s,o,a,r,l,c,u,f,d,p,w,m;if(!e||typeof e!="object")return"";const t=[],i=[];if(Array.isArray(e.styles))for(const b of e.styles){if(!b||!b.id)continue;const y=`--b3-inline-style-${b.id}`;(s=b.light)!=null&&s.color&&t.push(`  ${y}-color: ${b.light.color};`),(o=b.light)!=null&&o.backgroundColor&&t.push(`  ${y}-background-color: ${b.light.backgroundColor};`),(a=b.dark)!=null&&a.color&&i.push(`  ${y}-color: ${b.dark.color};`),(r=b.dark)!=null&&r.backgroundColor&&i.push(`  ${y}-background-color: ${b.dark.backgroundColor};`)}if(e.builtin&&Array.isArray(e.builtin.colors))for(const b of e.builtin.colors){if(!b||typeof b.index!="number")continue;const y=b.index;(l=b.light)!=null&&l.color&&t.push(`  --b3-font-color${y}: ${b.light.color};`),(c=b.light)!=null&&c.backgroundColor&&t.push(`  --b3-font-background${y}: ${b.light.backgroundColor};`),(u=b.dark)!=null&&u.color&&i.push(`  --b3-font-color${y}: ${b.dark.color};`),(f=b.dark)!=null&&f.backgroundColor&&i.push(`  --b3-font-background${y}: ${b.dark.backgroundColor};`)}if(e.builtin&&Array.isArray(e.builtin.styles))for(const b of e.builtin.styles){if(!b||!b.id)continue;const y=b.id;(d=b.light)!=null&&d.color&&t.push(`  --b3-card-${y}-color: ${b.light.color};`),(p=b.light)!=null&&p.backgroundColor&&t.push(`  --b3-card-${y}-background: ${b.light.backgroundColor};`),(w=b.dark)!=null&&w.color&&i.push(`  --b3-card-${y}-color: ${b.dark.color};`),(m=b.dark)!=null&&m.backgroundColor&&i.push(`  --b3-card-${y}-background: ${b.dark.backgroundColor};`)}if(t.length===0&&i.length===0)return"";const n=[];return t.length>0&&n.push(`:root, html:not(.dark), [data-theme="light"] {
${t.join(`
`)}
}`),i.length>0&&n.push(`html.dark, [data-theme="dark"], .dark {
${i.join(`
`)}
}`),n.join(`

`)}function Rn(e){const t=up(e);return t?`${zo}

/* Custom Workspace Inline Styles */
${t}`:zo}const fo=_a;function fp(e){const t=String((e==null?void 0:e.type)||"").toLowerCase();return t==="s"||t==="sb"||t==="nodesuperblock"||t==="l"||t==="nodelist"||t==="i"||t==="nodelistitem"||t==="b"||t==="nodeblockquote"}function pp(e,t){const i=new Map,n=[];if(!Array.isArray(t)||t.length===0)return{usable:!1,reason:"索引无行",leafPatch:i,rebuildRoots:n};const s=new Map;for(const o of t)o!=null&&o.id&&s.set(o.id,o);for(const o of e||[]){if(!(o!=null&&o.id))continue;const a=s.get(o.id);if(!a)continue;const r=o.content??"",l=o.markdown??"";(a.content??"")===r&&(a.markdown??"")===l||(fp(a)?n.push(o.id):i.set(o.id,{content:r,markdown:l}))}return{usable:!0,reason:"",leafPatch:i,rebuildRoots:n}}function hp(e){const t=String((e==null?void 0:e.type)||"").toLowerCase();return t==="h"||t==="nodeheading"}function Ho(e){return at(e)||e.type==="l"||e.type==="NodeList"||e.type==="i"||e.type==="NodeListItem"||e.type==="b"||e.type==="NodeBlockquote"}function mp(e,t,i,n=8,s){const o=new Map;for(const d of t)d!=null&&d.id&&o.set(d.id,d);const a=d=>({id:d.id,parent_id:d.parent_id,root_id:d.root_id||e,type:d.type,subType:d.subtype??d.subType??"",content:d.content||"",markdown:d.markdown||"",ial:i(d.id,d.ial),children:[]}),r=d=>{let p=d.parent_id,w=0;for(;p&&p!==e&&w++<16;){const m=o.get(p);if(!m||!hp(m))return p;p=m.parent_id}return p||e},l=new Map;for(const d of t){if(!(d!=null&&d.id)||d.id===e||s&&s.size>0&&!s.has(d.id))continue;const p=r(d),w=l.get(p);w?w.push(d):l.set(p,[d])}if(s&&s.size>0)for(const d of l.values())d.sort((p,w)=>(s.get(p.id)??Number.MAX_SAFE_INTEGER)-(s.get(w.id)??Number.MAX_SAFE_INTEGER));const c=new Map,u=(d,p)=>{const w=a(d);if(c.set(w.id,w),p>=n||!Ho(w))return w;const m=l.get(w.id);return m&&m.length>0&&(w.children=m.map(b=>u(b,p+1))),w};return{topLevel:(l.get(e)||[]).map(d=>u(d,0)),byId:c}}const gp={getBlockAttrs:Go,getChildBlocks:mn,getDocBlocksOrders:bd,setBlockAttrs:Fe,sql:un,getBaseUrl:()=>typeof location<"u"?location.origin:"",getInlineStyles:yd};class vp{constructor(t){be(this,"deps");be(this,"attrOverrides",new Map);be(this,"trackedListSuperBlocks",new Map);be(this,"fallbackWarnedDocId","");this.deps={...gp,...t||{}}}setBlockAttrOverride(t,i){if(!t||!i)return;const s={...this.attrOverrides.get(t)||{}};for(const[o,a]of Object.entries(i))a===""||a===null||a===void 0?delete s[o]:s[o]=String(a);Object.keys(s).length===0?this.attrOverrides.delete(t):this.attrOverrides.set(t,s)}getBlockAttrOverride(t){return this.attrOverrides.get(t)}getAllAttrOverrides(){return new Map(this.attrOverrides)}getTrackedListSuperBlocks(t){return this.trackedListSuperBlocks.get(t)||[]}clearBlockAttrOverride(t,i){if(!t)return;if(!i){this.attrOverrides.delete(t);return}const n=this.attrOverrides.get(t);n&&(delete n[i],Object.keys(n).length===0&&this.attrOverrides.delete(t))}clearAllOverrides(){this.attrOverrides.clear(),this.trackedListSuperBlocks.clear()}async compile(t){try{const i=await this.deps.getBlockAttrs(t).catch(()=>({}))||{},n=this.attrOverrides.get(t);n&&Object.assign(i,n);const s=await this.deps.getChildBlocks(t).catch(()=>[])||[],o=this.deps.getDocBlocksOrders?await this.deps.getDocBlocksOrders(t).catch(()=>[])||[]:[],a=new Map;for(let O=0;O<o.length;O++)o[O]&&a.set(o[O],O);const r=a.size>0,l=`SELECT id, parent_id, root_id, type, subtype, content, markdown, ial, sort, created FROM blocks WHERE root_id = '${t}' AND id != '${t}' ORDER BY sort ASC, created ASC LIMIT 99999`,c=await this.deps.sql(l).catch(()=>[])||[],u=pp(s,c),f=new Map;if(Array.isArray(c))for(const O of c)O.id&&O.ial&&f.set(O.id,fo(O.ial));const d=`SELECT block_id, name, value FROM attributes WHERE root_id = '${t}' AND type = 'b' LIMIT 99999`,p=await this.deps.sql(d).catch(()=>[])||[];if(Array.isArray(p)){for(const O of p)if(O.block_id&&O.name){let $=f.get(O.block_id);$||($={},f.set(O.block_id,$)),$[O.name]=O.value||""}}const w=(O,$)=>{const T={...f.get(O)||($?fo($):{})},P=this.attrOverrides.get(O);return P&&Object.assign(T,P),T},m=Array.isArray(c)&&c.length>0?mp(t,c,w,8,a):null,b=s.map(O=>O.id).filter(Boolean),y=O=>({id:O.id,parent_id:O.parent_id,root_id:O.root_id||t,type:O.type,subType:O.subType,content:O.content||"",markdown:O.markdown||"",ial:w(O.id,O.ial),children:O.children}),v=async(O,$=0)=>{if(!O||$>8||!Ho(O))return;const T=await this.deps.getChildBlocks(O.id).catch(()=>[])||[];if(!(!Array.isArray(T)||T.length===0)){O.children=T.filter(P=>P==null?void 0:P.id).map(P=>({id:P.id,parent_id:O.id,root_id:t,type:P.type,subType:P.subType,content:P.content||"",markdown:P.markdown||"",ial:w(P.id,P.ial),children:[]}));for(const P of O.children)await v(P,$+1)}},k=new Map;for(const O of c)O!=null&&O.id&&k.set(O.id,O);const S=b.every(O=>{const $=k.get(O);return!$||!!$.type});let B=[],A=!1;if(m&&u.usable&&r&&S){this.fallbackWarnedDocId="";for(const[$,T]of u.leafPatch){const P=m.byId.get($);P&&(P.content=T.content,P.markdown=T.markdown)}const O=new Map;for(const $ of s)$!=null&&$.id&&O.set($.id,$);for(const $ of u.rebuildRoots){const T=m.byId.get($),P=O.get($);T&&P&&(T.content=P.content||"",T.markdown=P.markdown||""),await v(T)}for(const $ of s){if(!($!=null&&$.id)||m.byId.has($.id))continue;const T=y($);await v(T),m.byId.set(T.id,T),m.topLevel.push(T)}B=m.topLevel.filter($=>a.has($.id)).sort(($,T)=>(a.get($.id)??0)-(a.get(T.id)??0))}else b.length>0?(A=!0,this.fallbackWarnedDocId!==t&&(this.fallbackWarnedDocId=t,console.warn(`[DocumentCompiler] 索引结构不可用，回退逐容器查询（较慢）doc=${t} 实时顶层=${b.length} 索引行=${c.length} 文档序=${o.length} 原因=${u.reason||"缺少实时文档序"}`)),B=s.map(O=>y(O))):m&&(B=m.topLevel);const C=async(O,$=0)=>{if(!(!O||O.length===0||$>8))for(const T of O){if(Ho(T)&&(!T.children||T.children.length===0)){let se=await this.deps.getChildBlocks(T.id).catch(()=>[]);if(!se||se.length===0){const V=`SELECT id, parent_id, root_id, type, subtype as subType, content, markdown, ial FROM blocks WHERE parent_id = '${T.id}' ORDER BY sort ASC, created ASC`;se=await this.deps.sql(V).catch(()=>[])||[]}if(Array.isArray(se)&&se.length>0){const V=new Set(B.map(ce=>ce.id)),Y=se.filter(ce=>ce.id!==T.id&&!V.has(ce.id));Y.length>0&&(T.children=Y.map(ce=>{const ie=f.get(ce.id)||(ce.ial?fo(ce.ial):{}),re=this.attrOverrides.get(ce.id);return re&&Object.assign(ie,re),{id:ce.id,parent_id:ce.parent_id||T.id,root_id:ce.root_id||t,type:ce.type,subType:ce.subType,content:ce.content||"",markdown:ce.markdown||"",ial:ie}}))}}T.children&&T.children.length>0&&await C(T.children,$+1)}};A&&await C(B);const L=O=>{var $,T;for(const P of O)if(P.children&&P.children.length>0){L(P.children);for(const se of P.children)if(se.ial)for(const[V,Y]of Object.entries(se.ial))V.startsWith("custom-slides-")&&!(($=P.ial)!=null&&$[V])&&(P.ial||(P.ial={}),P.ial[V]=Y);if(P.ial){for(const[se,V]of Object.entries(P.ial))if(se.startsWith("custom-slides-"))for(const Y of P.children)(Y.type==="video"||Y.type==="NodeVideo"||/<video\b/i.test(Y.markdown||Y.content||""))&&!((T=Y.ial)!=null&&T[se])&&(Y.ial||(Y.ial={}),Y.ial[se]=V)}}};L(B),sp(B,O=>{const $={[ke]:O.layout};this.setBlockAttrOverride(O.blockId,$),(this.deps.setBlockAttrs||Fe)(O.blockId,$).catch(P=>{console.warn("[DocumentCompiler] Failed to auto-tag superblock image layout:",P)})});const z=this.trackedListSuperBlocks.get(t)||[],N=np(t,B,{tracked:z,onTagChange:O=>{this.setBlockAttrOverride(O.blockId,O.attrs),O.blockId===t&&Object.assign(i,O.attrs);const $=P=>{for(const se of P)se.id===O.blockId&&(se.ial||(se.ial={}),Object.assign(se.ial,O.attrs)),se.children&&se.children.length>0&&$(se.children)};$(B),(this.deps.setBlockAttrs||Fe)(O.blockId,O.attrs).catch(P=>{console.warn("[DocumentCompiler] Failed to auto-tag list superblock attrs:",P)})}});this.trackedListSuperBlocks.set(t,N.newTracked);const K=new Set,_=O=>{for(const $ of O){const T=$.markdown||$.content||"";if(T.includes("((")){const P=kd(T);for(const se of P)K.add(se.blockId)}$.children&&$.children.length>0&&_($.children)}};_(B);const U={};if(K.size>0){const O=Array.from(K).map(T=>`'${T}'`).join(","),$=await this.deps.sql(`SELECT id, content, markdown FROM blocks WHERE id IN (${O})`).catch(()=>[])||[];if(Array.isArray($))for(const T of $)T.id&&(U[T.id]=T.markdown||T.content||"")}const x=this.deps.getBaseUrl?this.deps.getBaseUrl():"",q=ca(t,i,B,{baseUrl:x,refContentMap:U});try{const O=this.deps.getInlineStyles?await this.deps.getInlineStyles().catch(()=>null):null;q.customThemeCss=Rn(O)}catch{q.customThemeCss=Rn(null)}return q}catch(i){console.error("[DocumentCompilerService] Failed to compile document:",i);const n=ca(t,{},[],{});return n.customThemeCss=Rn(null),n}}}const Le=new vp;class mr{constructor(t){be(this,"devServerUrl","http://localhost:3030");be(this,"isConnected",!1);be(this,"lastSyncTime",null);t&&(this.devServerUrl=t)}getUrl(){return this.devServerUrl}setUrl(t){this.devServerUrl=t.replace(/\/+$/,"")}isServerConnected(){return this.isConnected}getLastSyncTime(){return this.lastSyncTime}async probeServer(t=1500){try{const i=new AbortController,n=setTimeout(()=>i.abort(),t),s=await fetch(this.devServerUrl,{method:"HEAD",mode:"no-cors",signal:i.signal}).catch(()=>null);return clearTimeout(n),this.isConnected=!!s,this.isConnected}catch{return this.isConnected=!1,!1}}buildStandardSlidevMarkdown(t){const i=t.config,n=["---",`theme: ${i.theme||"default"}`,`aspectRatio: "${i.aspectRatio||"16/9"}"`,`highlighter: ${i.highlighter||"shiki"}`,`transition: ${i.defaultTransition||"slide-left"}`];i.background&&n.push(`background: ${i.background}`),i.colorSchema&&i.colorSchema!=="auto"&&n.push(`colorSchema: ${i.colorSchema}`),n.push("drawings:","  persist: false","---","");const s=n.join(`
`),o=t.slides.map((l,c)=>{const u=l.frontmatter||{},f=[],d=c===0;u.layout&&u.layout!=="default"&&f.push(`layout: ${u.layout}`),u.transition&&f.push(`transition: ${u.transition}`),u.background&&f.push(`background: ${u.background}`),u.class&&f.push(`class: "${u.class}"`);let p="";f.length>0?p=d?"":`---
${f.join(`
`)}
---

`:d||(p=`---

`);let w="";if(u.layout==="two-cols"){const b=l.blocks.filter(S=>S.slot!=="right"),y=l.blocks.filter(S=>S.slot==="right"),v=b.map(S=>S.rawMarkdown||S.content||"").join(`

`),k=y.map(S=>S.rawMarkdown||S.content||"").join(`

`);w=`${v}

::right::

${k}`}else w=l.blocks.map(b=>b.rawMarkdown||b.content||"").join(`

`);let m="";return l.notes&&l.notes.trim()&&(m=`

<!--
${l.notes.trim()}
-->`),`${p}${w}${m}`}).join(`

`),a=[];t.config.normalizeHeadingSizes&&a.push(`/* Specific Heading Normalization */
.slidev-layout:not(.cover) > :is(h1, h2, h3, h4, h5, h6):first-child {
  font-size: 1.7rem !important;
}
.two-cols-header-top :is(h1, h2, h3, h4, h5, h6),
.cols-header-top :is(h1, h2, h3, h4, h5, h6),
.layout-header-section :is(h1, h2, h3, h4, h5, h6) {
  font-size: 1.7rem !important;
}
:is(.two-cols-left, .two-cols-right, .col, .col-1, .col-2, .col-3, .three-cols-col) > :is(h1, h2, h3, h4, h5, h6):first-child {
  font-size: 1.3rem !important;
}`),t.config.showUnorderedListMarkers===!1&&a.push(`/* Hide Unordered List Bullets */
ul, .slidev-layout ul, .slidev-layout li:has(ul) {
  list-style: none !important;
  list-style-type: none !important;
  padding-left: 0 !important;
}`),t.config.showOrderedListMarkers===!1&&a.push(`/* Hide Ordered List Numbers */
ol, .slidev-layout ol, .slidev-layout li:has(ol) {
  list-style: none !important;
  list-style-type: none !important;
  padding-left: 0 !important;
}`);let r="";return a.length>0&&(r=`

<style>
${a.join(`

`)}
</style>`),`${s}${o}${r}
`}async syncToWorkspaceFile(t,i="/data/storage/petal/siyuan-live-slides/slides.md",n){const s=this.buildStandardSlidevMarkdown(t);if(this.lastSyncTime=Date.now(),n)try{const o=typeof Blob<"u"?new Blob([s],{type:"text/markdown;charset=utf-8"}):Buffer.from(s,"utf-8");return await n(i,!1,o),{success:!0,path:i}}catch(o){return{success:!1,path:i,error:String(o)}}return{success:!0,path:i}}downloadSlidesMd(t,i="slides.md"){if(typeof window>"u"||typeof document>"u")return!1;const n=this.buildStandardSlidevMarkdown(t),s=new Blob([n],{type:"text/markdown;charset=utf-8"}),o=URL.createObjectURL(s),a=document.createElement("a");return a.href=o,a.download=i,document.body.appendChild(a),a.click(),document.body.removeChild(a),URL.revokeObjectURL(o),!0}}const bp={proMode:!1,presenterMode:!0,exportHtml:!1,exportPdf:!1,exportImage:!0,import:!1,aiScript:!0};function ai(e){return bp[e]===!1}function gt(e){return!ai(e)}function yp(){if(typeof window<"u"&&typeof window.require=="function")return window.require.bind(window);if(typeof globalThis<"u"&&typeof globalThis.require=="function")return globalThis.require.bind(globalThis);if(typeof require=="function")return require}function Tt(e){const t=yp();if(t)try{return t(e)}catch{try{const i=e.startsWith("node:")?e.slice(5):`node:${e}`;return t(i)}catch{}}}function gr(){var t;if(typeof window<"u"&&window.process)return window.process;const e=Tt("process");return e&&e.versions?e:typeof process<"u"&&((t=process.versions)!=null&&t.node)?process:globalThis.process}function Wl(){var t,i;const e=gr();if(e&&((t=e.versions)!=null&&t.node))return!0;if(typeof window<"u"&&window.siyuan){const n=Tt("child_process");if(n&&typeof n.spawn=="function")return!0}return!!(typeof process<"u"&&((i=process.versions)!=null&&i.node))}function kp(){if(typeof window>"u"||!window.location)return!1;try{return new URLSearchParams(window.location.search).get("remote")==="1"}catch{return!1}}function Yn(){const e=gr();if(e!=null&&e.platform)return e.platform;if(typeof process<"u"&&process.platform)return process.platform;const t=Tt("os");if(t&&typeof t.platform=="function")return t.platform();if(typeof navigator<"u"){const i=navigator.userAgent.toLowerCase();if(i.includes("win"))return"win32";if(i.includes("mac"))return"darwin";if(i.includes("linux"))return"linux"}return"web"}function Ul(){var n,s;const e=gr(),t={...(e==null?void 0:e.env)||{}};if(Yn()==="win32"){const o=["C:\\Program Files\\nodejs","C:\\Program Files (x86)\\nodejs",(n=e==null?void 0:e.env)!=null&&n.APPDATA?`${e.env.APPDATA}\\npm`:"",(s=e==null?void 0:e.env)!=null&&s.USERPROFILE?`${e.env.USERPROFILE}\\AppData\\Roaming\\npm`:""].filter(Boolean),a=Object.keys(t).find(c=>c.toLowerCase()==="path")||"PATH",l=(t[a]||"").split(";").filter(Boolean);for(const c of o)c&&!l.some(u=>u.toLowerCase()===c.toLowerCase())&&l.push(c);t[a]=l.join(";")}return t}function Fo(e){var i,n,s;if(!e)return"";if(/^[a-zA-Z]:[/\\]/.test(e))return e.replace(/\\/g,"/");let t="";if(typeof window<"u"&&((s=(n=(i=window.siyuan)==null?void 0:i.config)==null?void 0:n.system)!=null&&s.dataDir)&&(t=window.siyuan.config.system.dataDir.replace(/\\/g,"/")),t&&e.startsWith("/data/")){const o=e.slice(6);return`${t}/${o}`.replace(/\\/g,"/")}return e}function wp(){const e=Tt("os"),t=Tt("path");if(e&&typeof e.tmpdir=="function"){const i=e.tmpdir();return t&&typeof t.join=="function"?t.join(i,"siyuan-live-slides-pro").replace(/\\/g,"/"):`${i}/siyuan-live-slides-pro`.replace(/\\/g,"/")}return"/data/storage/petal/siyuan-live-slides/pro-workspace"}class vr{constructor(t){be(this,"runner");this.runner=t||vr.defaultRunner}static async defaultRunner(t,i){var n;try{let s=(n=Tt("child_process"))==null?void 0:n.execFile;if(!s){const l=await import("node:child_process").catch(()=>({}));s=l==null?void 0:l.execFile}if(!s)return{code:-1,stdout:"",stderr:"child_process execFile not available"};const a=Yn()==="win32",r=Ul();return await new Promise(l=>{s(t,i,{timeout:5e3,shell:a,env:r},(c,u,f)=>{l({code:c?c.code||1:0,stdout:u?String(u).trim():"",stderr:f?String(f).trim():""})})})}catch(s){return{code:-1,stdout:"",stderr:String(s)}}}async detect(){const t=Wl(),i=Yn();if(!t)return{hasNode:!1,hasSlidevCli:!1,platform:"browser",isDesktop:!1,error:"当前处于纯前端浏览器或移动端环境，无 Node.js 运行时支撑"};let n=!1,s,o=!1,a;try{const r=await this.runner("node",["-v"]);r.code===0&&r.stdout.startsWith("v")&&(n=!0,s=r.stdout)}catch{}if(n){try{const r=i==="win32"?"slidev.cmd":"slidev",l=await this.runner(r,["--version"]);l.code===0&&l.stdout&&(o=!0,a=l.stdout)}catch{}if(!o)try{const r=i==="win32"?"npx.cmd":"npx",l=await this.runner(r,["@slidev/cli","--version"]);l.code===0&&l.stdout&&(o=!0,a=l.stdout)}catch{}}return{hasNode:n,nodeVersion:s,hasSlidevCli:o,slidevVersion:a,platform:i,isDesktop:t}}}class xp{constructor(){be(this,"iframe",null);be(this,"isReady",!1);be(this,"pageChangedHandlers",[]);be(this,"readyHandlers",[]);be(this,"currentState",{no:1,clicks:0,total:1});this.handleWindowMessage=this.handleWindowMessage.bind(this)}getCurrentState(){return{...this.currentState}}attach(t){this.detach(),this.iframe=t,this.isReady=!1,typeof window<"u"&&window.addEventListener("message",this.handleWindowMessage)}detach(){typeof window<"u"&&window.removeEventListener("message",this.handleWindowMessage),this.iframe=null,this.isReady=!1}postMessage(t,i){var s;if(!((s=this.iframe)!=null&&s.contentWindow))return;const n={target:"slidev",sender:"siyuan",type:t,...i};try{this.iframe.contentWindow.postMessage(n,"*")}catch(o){console.warn("[NativeSlidesBridge] postMessage error:",o)}}navigateToPage(t){this.postMessage("navigate",{no:t})}next(){this.postMessage("next")}prev(){this.postMessage("prev")}nextClick(){this.postMessage("next-click")}prevClick(){this.postMessage("prev-click")}onPageChanged(t){return this.pageChangedHandlers.push(t),()=>{this.pageChangedHandlers=this.pageChangedHandlers.filter(i=>i!==t)}}onReady(t){return this.readyHandlers.push(t),()=>{this.readyHandlers=this.readyHandlers.filter(i=>i!==t)}}handleWindowMessage(t){const i=t.data;if(!(!i||i.target!=="slidev")){if(!this.isReady){this.isReady=!0;for(const n of this.readyHandlers)n()}if(i.type==="update-state"&&i.navState){const n=i.navState;this.currentState={no:n.no??this.currentState.no,clicks:n.clicks??this.currentState.clicks,total:n.total??this.currentState.total,hasNext:n.hasNext,hasPrev:n.hasPrev};for(const s of this.pageChangedHandlers)s(this.currentState.no,this.currentState.total||1,this.currentState)}else if(i.type==="navigate"&&typeof i.no=="number"){this.currentState.no=i.no;for(const n of this.pageChangedHandlers)n(i.no,this.currentState.total||1,this.currentState)}}}}class Sp{constructor(t){be(this,"childProcess",null);be(this,"activePort",null);be(this,"isRunning",!1);be(this,"defaultPort");be(this,"maxPortRetries");be(this,"probeTimeoutMs");be(this,"customSpawner");be(this,"customPortChecker");this.defaultPort=(t==null?void 0:t.defaultPort)||3030,this.maxPortRetries=(t==null?void 0:t.maxPortRetries)||20,this.probeTimeoutMs=(t==null?void 0:t.probeTimeoutMs)||1e4,this.customSpawner=t==null?void 0:t.customSpawner,this.customPortChecker=t==null?void 0:t.customPortChecker}getActivePort(){return this.activePort}getIsRunning(){return this.isRunning}async isPortAvailable(t){if(this.customPortChecker)return this.customPortChecker(t);try{let i=Tt("net");return i||(i=await import("node:net").catch(()=>({}))),i!=null&&i.createServer?await new Promise(n=>{const s=i.createServer();s.once("error",()=>n(!1)),s.once("listening",()=>{s.close(()=>n(!0))}),s.listen(t,"127.0.0.1")}):!0}catch{return!0}}async allocPort(t){const i=t||this.defaultPort;for(let n=0;n<this.maxPortRetries;n++){const s=i+n;if(await this.isPortAvailable(s))return s}return i}async pollServerReady(t,i=8e3,n=300){const s=Date.now();for(;Date.now()-s<i;){try{const o=new AbortController,a=setTimeout(()=>o.abort(),n),r=await fetch(t,{method:"HEAD",mode:"no-cors",signal:o.signal}).catch(()=>null);if(clearTimeout(a),r)return!0}catch{}await new Promise(o=>setTimeout(o,n))}return!1}async startServer(t,i){var l,c;if(this.isRunning&&this.activePort)return{success:!0,port:this.activePort,url:`http://localhost:${this.activePort}?embedded=true`};const n=await this.allocPort(i);this.activePort=n;const o=Yn()==="win32"?"npx.cmd":"npx",a=Fo(t),r=["@slidev/cli",a,"--port",String(n),"--no-open"];try{if(this.customSpawner)this.childProcess=this.customSpawner(o,r,{detached:!1});else{let f=(l=Tt("child_process"))==null?void 0:l.spawn;if(!f){const w=await import("node:child_process").catch(()=>({}));f=w==null?void 0:w.spawn}if(!f)throw new Error("child_process spawn not available in current runtime");const d=a.includes("/")||a.includes("\\")?a.replace(/[/\\][^/\\]+$/,""):void 0,p=Ul();this.childProcess=f(o,r,{cwd:d,detached:!1,shell:!0,env:{...p,FORCE_COLOR:"1"}})}this.isRunning=!0,(c=this.childProcess)!=null&&c.on&&this.childProcess.on("exit",()=>{this.isRunning=!1,this.activePort=null,this.childProcess=null});const u=`http://localhost:${n}`;return!this.customSpawner&&!await this.pollServerReady(u,this.probeTimeoutMs)?(this.stopServer(),{success:!1,port:n,url:"",error:`Slidev DevServer 启动超时 (未在 ${this.probeTimeoutMs}ms 内响应端口 ${n})`}):{success:!0,port:n,url:`${u}?embedded=true`}}catch(u){return this.stopServer(),{success:!1,port:n,url:"",error:`唤起 Slidev 进程失败: ${String(u)}`}}}async stopServer(){var t;if(this.childProcess){const i=this.childProcess;this.childProcess=null;try{if(i.kill("SIGTERM"),Yn()==="win32"&&i.pid&&!this.customSpawner){const s=(t=Tt("child_process"))==null?void 0:t.exec;if(s)await new Promise(o=>{const a=setTimeout(o,400);s(`taskkill /pid ${i.pid} /T /F`,()=>{clearTimeout(a),o()})});else{const o=await import("node:child_process").catch(()=>null);o!=null&&o.exec&&await new Promise(a=>{const r=setTimeout(a,400);o.exec(`taskkill /pid ${i.pid} /T /F`,()=>{clearTimeout(r),a()})})}}}catch{}}this.isRunning=!1,this.activePort=null}}class Qn{constructor(){be(this,"iframe",null);be(this,"isReady",!1);be(this,"pendingMessages",[]);be(this,"slideChangedHandlers",[]);be(this,"blockClickedHandlers",[]);be(this,"openInEditorHandlers",[]);be(this,"clientReadyHandlers",[]);be(this,"openPeekDrawerHandlers",[]);be(this,"toggleFullscreenHandlers",[]);be(this,"openPresenterHandlers",[]);be(this,"captureProgressHandlers",[]);be(this,"capturePageDoneHandlers",[]);be(this,"captureCompleteHandlers",[]);be(this,"captureErrorHandlers",[]);this.handleWindowMessage=this.handleWindowMessage.bind(this)}attach(t){this.detach(),this.iframe=t,this.isReady=!1,typeof window<"u"&&window.addEventListener("message",this.handleWindowMessage)}detach(){typeof window<"u"&&window.removeEventListener("message",this.handleWindowMessage),this.iframe=null,this.isReady=!1,this.pendingMessages=[]}resetReady(){this.isReady=!1}postMessage(t,i){var s;const n={source:"siyuan-slides-host",action:t,payload:i};if(!((s=this.iframe)!=null&&s.contentWindow)||!this.isReady){if(t==="UPDATE_SLIDES"||t==="NAVIGATE_PAGE"){const o=this.pendingMessages.findIndex(a=>a.action===t);o!==-1?this.pendingMessages[o]=n:this.pendingMessages.push(n)}else this.pendingMessages.length>=50&&this.pendingMessages.shift(),this.pendingMessages.push(n);return}try{this.iframe.contentWindow.postMessage(n,"*")}catch(o){console.warn("[WebSandboxBridge] postMessage error:",o)}}updateSlides(t,i,n,s){this.postMessage("UPDATE_SLIDES",{slides:t,config:i,fullMarkdown:n,customThemeCss:s})}navigatePage(t,i){const n={pageIndex:t};typeof i=="number"&&(n.step=i),this.postMessage("NAVIGATE_PAGE",n)}highlightElement(t){this.postMessage("HIGHLIGHT_ELEMENT",{targetBlockId:t})}nextStep(){this.postMessage("NEXT_STEP",{})}prevStep(){this.postMessage("PREV_STEP",{})}freezeKeyboardNav(t){this.postMessage("FREEZE_KEYBOARD_NAV",{frozen:t})}toggleOverview(){this.postMessage("TOGGLE_OVERVIEW",{})}startImageExport(t){this.postMessage("START_IMAGE_EXPORT",{captureOptions:t})}cancelImageExport(){this.postMessage("CANCEL_IMAGE_EXPORT",{})}onCaptureProgress(t){return this.captureProgressHandlers.push(t),()=>{this.captureProgressHandlers=this.captureProgressHandlers.filter(i=>i!==t)}}onCapturePageDone(t){return this.capturePageDoneHandlers.push(t),()=>{this.capturePageDoneHandlers=this.capturePageDoneHandlers.filter(i=>i!==t)}}onCaptureComplete(t){return this.captureCompleteHandlers.push(t),()=>{this.captureCompleteHandlers=this.captureCompleteHandlers.filter(i=>i!==t)}}onCaptureError(t){return this.captureErrorHandlers.push(t),()=>{this.captureErrorHandlers=this.captureErrorHandlers.filter(i=>i!==t)}}onSlideChanged(t){return this.slideChangedHandlers.push(t),()=>{this.slideChangedHandlers=this.slideChangedHandlers.filter(i=>i!==t)}}onBlockClicked(t){return this.blockClickedHandlers.push(t),()=>{this.blockClickedHandlers=this.blockClickedHandlers.filter(i=>i!==t)}}onOpenInEditor(t){return this.openInEditorHandlers.push(t),()=>{this.openInEditorHandlers=this.openInEditorHandlers.filter(i=>i!==t)}}onOpenPeekDrawer(t){return this.openPeekDrawerHandlers.push(t),()=>{this.openPeekDrawerHandlers=this.openPeekDrawerHandlers.filter(i=>i!==t)}}onRequestToggleFullscreen(t){return this.toggleFullscreenHandlers.push(t),()=>{this.toggleFullscreenHandlers=this.toggleFullscreenHandlers.filter(i=>i!==t)}}onOpenPresenter(t){return this.openPresenterHandlers.push(t),()=>{this.openPresenterHandlers=this.openPresenterHandlers.filter(i=>i!==t)}}onClientReady(t){return this.clientReadyHandlers.push(t),()=>{this.clientReadyHandlers=this.clientReadyHandlers.filter(i=>i!==t)}}handleWindowMessage(t){var n,s;const i=t.data;if(!(!i||i.source!=="siyuan-slides-client")&&!((n=this.iframe)!=null&&n.contentWindow&&t.source&&t.source!==this.iframe.contentWindow))switch(i.action){case"CLIENT_READY":for(this.isReady=!0;this.pendingMessages.length>0;){const o=this.pendingMessages.shift();o&&((s=this.iframe)!=null&&s.contentWindow)&&this.iframe.contentWindow.postMessage(o,"*")}for(const o of this.clientReadyHandlers)o();break;case"SLIDE_CHANGED":if(i.payload.currentPage!==void 0)for(const o of this.slideChangedHandlers)i.payload.currentStep!==void 0||i.payload.maxStep!==void 0?o(i.payload.currentPage,i.payload.totalPages||1,i.payload.currentBlockId||"",i.payload.currentStep,i.payload.maxStep):o(i.payload.currentPage,i.payload.totalPages||1,i.payload.currentBlockId||"");break;case"BLOCK_CLICKED":if(i.payload.clickedBlockId)for(const o of this.blockClickedHandlers)o(i.payload.clickedBlockId,i.payload.currentPage||1);break;case"OPEN_IN_EDITOR":if(i.payload.blockId||i.payload.clickedBlockId){const o=i.payload.blockId||i.payload.clickedBlockId||"";for(const a of this.openInEditorHandlers)a(o,i.payload.currentPage||1)}break;case"OPEN_PEEK_DRAWER":if(i.payload.peekType){const o=i.payload.blockId||i.payload.url||"",a={peekType:i.payload.peekType,target:o,title:i.payload.title};for(const r of this.openPeekDrawerHandlers)r(a)}break;case"REQUEST_TOGGLE_FULLSCREEN":for(const o of this.toggleFullscreenHandlers)o();break;case"OPEN_PRESENTER":for(const o of this.openPresenterHandlers)o();break;case"CAPTURE_PROGRESS":if(i.payload.captureProgress)for(const o of this.captureProgressHandlers)o(i.payload.captureProgress);break;case"CAPTURE_PAGE_DONE":if(i.payload.captureResult)for(const o of this.capturePageDoneHandlers)o(i.payload.captureResult);break;case"CAPTURE_COMPLETE":for(const o of this.captureCompleteHandlers)o({total:i.payload.totalPages||0});break;case"CAPTURE_ERROR":for(const o of this.captureErrorHandlers)o(i.payload.captureError||"未知沙箱截图异常");break}}}const Vl={"snippets/external.ts":`// Inside ./snippets/external.ts
// #region snippet
export function emptyArray<T>(length: number) {
  return Array.from<T>({ length })
}
// #endregion snippet

export function sayHello() {
  console.log('Hello from snippets/external.ts')
}
`},Cp=`<script setup lang="ts">
import { computed, useSlots } from 'vue'

const props = defineProps({
  layoutRatio: {
    type: String,
    default: '',
  },
  cols: {
    type: [Number, String],
    default: 0,
  },
})

const slots = useSlots()

const detectedColsCount = computed(() => {
  const explicitCols = Number(props.cols)
  if (explicitCols >= 2 && explicitCols <= 6) return explicitCols
  const r = (props.layoutRatio || '').trim()
  if (r.includes(':')) {
    const parts = r.split(':').map(p => parseFloat(p.trim())).filter(n => !isNaN(n) && n > 0)
    if (parts.length >= 2) return Math.min(parts.length, 6)
  }
  const tokens = r.split(/\\s+/).filter(Boolean)
  if (tokens.length >= 2) return Math.min(tokens.length, 6)
  for (let i = 6; i >= 3; i--) {
    if (slots[\`col-\${i}\`]) return i
  }
  if (slots['col-2'] || slots['right']) return 2
  return 2
})

const gridStyle = computed(() => {
  const r = props.layoutRatio || ''
  if (r) {
    if (r.includes(':')) {
      const parts = r.split(':').map(p => parseFloat(p.trim())).filter(n => !isNaN(n) && n > 0)
      if (parts.length >= 2) {
        return { gridTemplateColumns: parts.map(n => \`\${n}fr\`).join(' ') }
      }
    }
    const tokens = r.split(/\\s+/).filter(Boolean)
    if (tokens.length >= 2) {
      return { gridTemplateColumns: tokens.join(' ') }
    }
  }
  return { gridTemplateColumns: \`repeat(\${detectedColsCount.value}, minmax(0, 1fr))\` }
})
<\/script>

<template>
  <div class="slidev-layout cols-header w-full h-full flex flex-col">
    <div class="header-section mb-4 w-full">
      <slot />
    </div>
    <div class="grid gap-6 flex-1 items-stretch" :style="gridStyle">
      <div v-if="detectedColsCount >= 1" class="col-1 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-1"><slot name="left" /></slot>
      </div>
      <div v-if="detectedColsCount >= 2" class="col-2 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-2"><slot v-if="detectedColsCount === 2" name="right" /></slot>
      </div>
      <div v-if="detectedColsCount >= 3" class="col-3 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-3" />
      </div>
      <div v-if="detectedColsCount >= 4" class="col-4 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-4" />
      </div>
      <div v-if="detectedColsCount >= 5" class="col-5 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-5" />
      </div>
      <div v-if="detectedColsCount >= 6" class="col-6 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-6" />
      </div>
    </div>
  </div>
</template>
`,_p=`<script setup lang="ts">
import { computed } from 'vue'

const props = defineProps({
  layoutRatio: {
    type: String,
    default: '',
  },
})

const gridStyle = computed(() => {
  const r = props.layoutRatio || ''
  if (!r) return {}
  if (r.includes(':')) {
    const parts = r.split(':').map(p => parseFloat(p.trim())).filter(n => !isNaN(n) && n > 0)
    if (parts.length >= 2) {
      return { gridTemplateColumns: parts.map(n => \`\${n}fr\`).join(' ') }
    }
  }
  const tokens = r.split(/\\s+/).filter(Boolean)
  if (tokens.length >= 2) {
    return { gridTemplateColumns: tokens.join(' ') }
  }
  return {}
})
<\/script>

<template>
  <div class="slidev-layout three-cols-header w-full h-full flex flex-col">
    <div class="header-section mb-4 w-full">
      <slot />
    </div>
    <div class="grid gap-6 flex-1 items-stretch" :class="gridStyle.gridTemplateColumns ? '' : 'grid-cols-3'" :style="gridStyle">
      <div class="col-1 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-1" />
      </div>
      <div class="col-2 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-2" />
      </div>
      <div class="col-3 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-3" />
      </div>
    </div>
  </div>
</template>
`,$p=`<script setup lang="ts">
import { computed, useSlots } from 'vue'

const props = defineProps({
  mask: {
    type: String,
    default: '',
  },
  maskStyle: {
    type: String,
    default: 'solid',
  },
  maskInitial: {
    type: String,
    default: 'hidden',
  },
  clicks: {
    type: [Number, String],
    default: 0,
  },
})

const slots = useSlots()

const isClockMask = computed(() => {
  const m = props.mask || ''
  return m === 'clockwise' || m === 'counter-clockwise' || m === 'cw' || m === 'ccw'
})

const currentClockClicks = computed(() => {
  // 优先取 Slidev 全局 $slidev.nav.clicks，否则降级为 props.clicks
  // @ts-ignore
  const navClicks = typeof window !== 'undefined' && (window as any).$slidev?.nav?.clicks
  return typeof navClicks === 'number' ? navClicks : Number(props.clicks || 0)
})

const clockPercent = computed(() => {
  if (!isClockMask.value) return 100
  const isInitRev = props.maskInitial === 'revealed'
  const step = currentClockClicks.value
  const bps = [25, 50, 75, 100]
  if (step <= 0) return isInitRev ? bps[0] : 0
  const effectiveIdx = isInitRev ? step : (step - 1)
  if (effectiveIdx >= bps.length) return 100
  return bps[effectiveIdx] || 100
})

const clockNeedleAngle = computed(() => {
  const isCw = props.mask === 'clockwise' || props.mask === 'cw'
  const sweepDeg = Math.min(360, Math.max(0, (clockPercent.value / 100) * 360))
  return isCw ? (-180 + sweepDeg) : (-90 - sweepDeg)
})

const clockMaskOverlayStyle = computed(() => {
  if (!isClockMask.value) return {}
  const p = clockPercent.value
  const isCw = props.mask === 'clockwise' || props.mask === 'cw'
  const sweepDeg = Math.min(360, Math.max(0, (p / 100) * 360))
  let maskGrad = ''
  if (sweepDeg <= 0) {
    maskGrad = 'conic-gradient(from 0deg at 50% 50%, #000 0deg, #000 360deg)'
  } else if (sweepDeg >= 360) {
    maskGrad = 'conic-gradient(from 0deg at 50% 50%, transparent 0deg, transparent 360deg)'
  } else if (isCw) {
    maskGrad = \`conic-gradient(from 270deg at 50% 50%, transparent 0deg, transparent \${sweepDeg}deg, #000 \${sweepDeg}deg, #000 360deg)\`
  } else {
    const remDeg = 360 - sweepDeg
    maskGrad = \`conic-gradient(from 0deg at 50% 50%, #000 0deg, #000 \${remDeg}deg, transparent \${remDeg}deg, transparent 360deg)\`
  }
  return {
    WebkitMaskImage: maskGrad,
    maskImage: maskGrad,
  }
})
<\/script>

<template>
  <div class="slidev-layout clover w-full h-full flex flex-col">
    <div class="header-section mb-4 w-full">
      <slot />
    </div>
    <div class="relative flex-1 min-h-0 overflow-hidden">
      <div class="grid grid-cols-2 grid-rows-2 gap-6 w-full h-full items-stretch">
        <div class="col-1 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
          <slot name="col-1" />
        </div>
        <div class="col-2 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
          <slot name="col-2" />
        </div>
        <div class="col-3 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
          <slot name="col-3" />
        </div>
        <div class="col-4 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
          <slot name="col-4" />
        </div>
      </div>
      <div
        v-if="isClockMask"
        class="slides-mask-layer slides-mask-layer--clock pointer-events-none absolute inset-0 z-50 transition-opacity duration-300"
        :class="props.maskStyle === 'blur' ? 'slides-mask-layer--blur' : 'slides-mask-layer--solid'"
        :style="{ opacity: clockPercent >= 100 ? 0 : 1 }"
      >
        <div
          class="slides-mask-overlay absolute inset-0 w-full h-full"
          :class="props.maskStyle === 'blur' ? 'backdrop-blur-xl bg-white/70 dark:bg-black/70' : 'bg-[var(--slide-bg,#fff)] dark:bg-[var(--slide-bg,#121214)]'"
          :style="clockMaskOverlayStyle"
        />
        <div
          class="slides-mask-divider-line slides-mask-divider-line--clock absolute pointer-events-none transition-all duration-300"
          :style="{
            top: '50%',
            left: '50%',
            width: '55%',
            height: '2.5px',
            transformOrigin: '0% 50%',
            transform: \`translateY(-50%) rotate(\${clockNeedleAngle}deg)\`,
            opacity: (clockPercent <= 0 || clockPercent >= 100) ? 0 : 1,
            background: 'linear-gradient(90deg, var(--slide-accent, #3b82f6) 0%, var(--slide-accent, #3b82f6) 75%, transparent 100%)',
            boxShadow: '0 0 10px var(--slide-accent, #3b82f6), 0 0 4px var(--slide-accent, #3b82f6)',
          }"
        />
      </div>
    </div>
  </div>
</template>
`,Ip=`// Auto-generated by SiYuan Slidev Studio
// 本地 HTML 链接（思源资产 / 工作区文件 / 绝对文件路径）速览判定
// 注意：需与 public/slides-client/index.html 中的拦截器保持同步
function isPeekableLocalHtml(href: string): boolean {
  const clean = (href || '').trim()
  if (!clean || clean.startsWith('#') || clean.startsWith('//')) return false
  if (!/\\.html?($|[?#])/i.test(clean)) return false
  if (/^https?:\\/\\//i.test(clean)) return false
  const scheme = /^([a-z][a-z0-9+.-]*):/i.exec(clean)
  if (!scheme) return true
  const schemeName = scheme[1].toLowerCase()
  if (schemeName === 'file') return true
  // Windows 盘符路径（D:\\\\docs\\\\demo.html）并非协议前缀
  return schemeName.length === 1 && /^[a-zA-Z]:[\\\\/]/.test(clean)
}

// 本地 HTML 链接预处理：思源资产统一指向内核 /assets/ 静态服务，其余原样转交宿主归一化
// 不基于 location 绝对化，保证 Pro 模式（Slidev dev server）与沙箱模式行为完全一致
function resolvePeekHref(href: string): string {
  const clean = (href || '').trim()
  if (/^(?:\\.\\/|\\/)?assets\\//.test(clean)) {
    return '/' + clean.replace(/^(?:\\.\\/|\\/)/, '')
  }
  return clean
}

export default function() {
  if (typeof window === 'undefined') return
  window.addEventListener('click', (e: MouseEvent) => {
    const target = e.target as HTMLElement | null
    if (!target || !target.closest) return

    const refEl = target.closest('[data-ref-id]')
    if (refEl) {
      const blockId = refEl.getAttribute('data-ref-id')
      if (blockId) {
        e.preventDefault()
        e.stopPropagation()
        window.parent.postMessage({
          source: 'siyuan-slides-client',
          action: 'OPEN_PEEK_DRAWER',
          payload: { peekType: 'siyuan', blockId, title: (refEl.innerText || refEl.title || '').trim() }
        }, '*')
        return
      }
    }

    const linkEl = target.closest('a') as HTMLAnchorElement | null
    if (linkEl) {
      const href = linkEl.getAttribute('href') || ''
      if (href.startsWith('siyuan://blocks/')) {
        e.preventDefault()
        e.stopPropagation()
        const cleanBlockId = href.replace('siyuan://blocks/', '').split('?')[0]
        window.parent.postMessage({
          source: 'siyuan-slides-client',
          action: 'OPEN_PEEK_DRAWER',
          payload: { peekType: 'siyuan', blockId: cleanBlockId, title: (linkEl.innerText || linkEl.title || '').trim() }
        }, '*')
      } else if (/^https?:\\/\\//i.test(href)) {
        e.preventDefault()
        e.stopPropagation()
        window.parent.postMessage({
          source: 'siyuan-slides-client',
          action: 'OPEN_PEEK_DRAWER',
          payload: { peekType: 'web', url: href, title: (linkEl.innerText || linkEl.title || '').trim() }
        }, '*')
      } else if (isPeekableLocalHtml(href)) {
        e.preventDefault()
        e.stopPropagation()
        window.parent.postMessage({
          source: 'siyuan-slides-client',
          action: 'OPEN_PEEK_DRAWER',
          payload: { peekType: 'web', url: resolvePeekHref(href), title: (linkEl.innerText || linkEl.title || '').trim() }
        }, '*')
      }
    }
  }, true)
}
`,Mp=`${zo}

/* Auto-generated by SiYuan Slidev Studio */
.slides-ref-tag,
a.slides-ref-tag {
  display: inline-flex;
  align-items: center;
  background: color-mix(in srgb, var(--slides-theme-primary, #10b981) 12%, transparent);
  color: var(--slides-theme-primary, #10b981);
  border-radius: 4px;
  padding: 2px 8px;
  font-size: 0.88em;
  text-decoration: none;
  border: 1px solid color-mix(in srgb, var(--slides-theme-primary, #10b981) 25%, transparent);
  cursor: pointer;
  transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
  user-select: none;
}

.slides-ref-tag:hover,
a.slides-ref-tag:hover {
  background: color-mix(in srgb, var(--slides-theme-primary, #10b981) 22%, transparent);
  color: var(--slides-theme-primary, #10b981);
  border-color: color-mix(in srgb, var(--slides-theme-primary, #10b981) 55%, transparent);
  transform: translateY(-1px);
  box-shadow: 0 2px 8px color-mix(in srgb, var(--slides-theme-primary, #10b981) 20%, transparent);
}

.slides-block-ref {
  display: block;
  padding: 10px 14px;
  background: color-mix(in srgb, var(--slides-theme-primary, #10b981) 8%, transparent);
  border-left: 3px solid var(--slides-theme-primary, #10b981);
  border-radius: 0 6px 6px 0;
  margin: 8px 0;
  cursor: pointer;
  transition: background 0.2s ease;
}

.slides-block-ref:hover {
  background: color-mix(in srgb, var(--slides-theme-primary, #10b981) 15%, transparent);
}

/* 代码块自动换行与无横向滚动条 */
pre,
pre code {
  white-space: pre-wrap !important;
  word-break: break-all !important;
  overflow-wrap: anywhere !important;
  overflow-x: hidden !important;
  overflow-y: auto !important;
  max-width: 100% !important;
  box-sizing: border-box !important;
}

/* 弱提示滚动条样式 */
* {
  scrollbar-width: thin;
}
html:not(.dark) * {
  scrollbar-color: rgba(0, 0, 0, 0.15) transparent;
}
html.dark * {
  scrollbar-color: rgba(255, 255, 255, 0.20) transparent;
}
*::-webkit-scrollbar {
  width: 4px;
  height: 4px;
}
*::-webkit-scrollbar-track {
  background: transparent;
}
html:not(.dark) *::-webkit-scrollbar-thumb {
  background: rgba(0, 0, 0, 0.15);
  border-radius: 2px;
}
html:not(.dark) *:hover::-webkit-scrollbar-thumb,
html:not(.dark) *::-webkit-scrollbar-thumb:hover {
  background: rgba(0, 0, 0, 0.35);
}
html.dark *::-webkit-scrollbar-thumb {
  background: rgba(255, 255, 255, 0.20);
  border-radius: 2px;
}
html.dark *:hover::-webkit-scrollbar-thumb,
html.dark *::-webkit-scrollbar-thumb:hover {
  background: rgba(255, 255, 255, 0.45);
}

/* 多媒体（GIF动图、静态图片、MP4视频）最大化自适应且不超出视口：顶部对齐，横向居中 */
.slidev-layout img,
.slidev-layout video {
  max-width: 100% !important;
  max-height: 100% !important;
  width: auto;
  height: auto;
  object-fit: contain !important;
}
.three-cols-header video,
.two-cols-header video,
.grid-cols-3 video,
.grid-cols-2 video,
.col-1 video,
.col-2 video,
.col-3 video {
  width: auto !important;
  height: auto !important;
  max-width: 100% !important;
  max-height: 100% !important;
  object-fit: contain !important;
  display: block !important;
  margin: 0 auto !important;
}
.slide-list-media {
  display: flex !important;
  flex-direction: column !important;
  align-items: center !important;
  justify-content: flex-start !important;
  margin-top: 4px !important;
  margin-bottom: 4px !important;
  width: 100% !important;
  max-width: 100% !important;
  height: 100% !important;
  max-height: 100% !important;
  flex: 1 1 0% !important;
  overflow: hidden !important;
}
.slide-list-media img,
.slide-list-media video,
.slide-list-media .list-item-gif {
  width: auto !important;
  height: auto !important;
  max-width: 100% !important;
  max-height: 100% !important;
  object-fit: contain !important;
  border-radius: 6px !important;
  box-shadow: 0 3px 12px rgba(0, 0, 0, 0.14) !important;
  display: block !important;
  margin: 0 auto !important;
}
.slide-video-container {
  display: flex !important;
  flex-direction: column !important;
  justify-content: flex-start !important;
  align-items: center !important;
  width: 100% !important;
  max-height: 100% !important;
  margin: 6px 0 !important;
}
.slide-video-player {
  max-width: 100% !important;
  max-height: 100% !important;
  object-fit: contain !important;
  border-radius: 8px !important;
}

/* 两栏与多栏（超级块分栏）布局：紧凑自然行距，子列表保留圆点与层级缩进 */
.cols-header ul,
.three-cols-header ul,
.two-cols-header ul,
.two-cols ul,
.col-1 ul,
.col-2 ul,
.col-3 ul,
.col-4 ul,
.col-5 ul,
.col-6 ul,
.grid-cols-2 ul,
.grid-cols-3 ul {
  list-style: disc !important;
  list-style-type: disc !important;
  padding-left: 1.25em !important;
  margin-left: 0 !important;
  margin-top: 0 !important;
  margin-bottom: 8px !important;
  flex: 0 0 auto !important;
  height: auto !important;
  display: block !important;
}
.cols-header ol,
.three-cols-header ol,
.two-cols-header ol,
.two-cols ol,
.col-1 ol,
.col-2 ol,
.col-3 ol,
.col-4 ol,
.col-5 ol,
.col-6 ol,
.grid-cols-2 ol,
.grid-cols-3 ol {
  list-style: decimal !important;
  list-style-type: decimal !important;
  padding-left: 1.25em !important;
  margin-left: 0 !important;
  margin-top: 0 !important;
  margin-bottom: 8px !important;
  flex: 0 0 auto !important;
  height: auto !important;
  display: block !important;
}
.cols-header li,
.three-cols-header li,
.two-cols-header li,
.two-cols li,
.col-1 li,
.col-2 li,
.col-3 li,
.col-4 li,
.col-5 li,
.col-6 li,
.grid-cols-2 li,
.grid-cols-3 li {
  padding-left: 0.2em !important;
  margin-left: 0 !important;
  margin-bottom: 6px !important;
  flex: 0 0 auto !important;
  height: auto !important;
  display: list-item !important;
  line-height: 1.6 !important;
}
.cols-header ul ul,
.three-cols-header ul ul,
.two-cols-header ul ul,
.two-cols ul ul,
.col-1 ul ul,
.col-2 ul ul,
.col-3 ul ul,
.col-4 ul ul,
.col-5 ul ul,
.col-6 ul ul {
  list-style: circle !important;
  list-style-type: circle !important;
  padding-left: 1.25em !important;
  margin-top: 4px !important;
  margin-bottom: 4px !important;
}

/* 列表项内嵌标题与说明排版 */
.slide-list-item-title,
li > h1,
li > h2,
li > h3,
li > h4,
li > h5,
li > h6 {
  margin-top: 2px !important;
  margin-bottom: 6px !important;
  line-height: 1.35 !important;
  font-weight: 700 !important;
}
li > h1 { font-size: 1.6rem !important; }
li > h2 { font-size: 1.4rem !important; }
li > h3 { font-size: 1.22rem !important; }
li > h4 { font-size: 1.1rem !important; }
.slide-list-item-desc,
li > p {
  margin-top: 4px !important;
  margin-bottom: 6px !important;
  font-size: 1.05rem;
  line-height: 1.55;
  opacity: 0.92;
}
`;function Tp(e){var s;const t=[],i=/^[ \t]*<<<[ \t]+(?:@\/|\.\/|)([^\s#]+)(?:#[^\s]+)?/gm;let n;for(;(n=i.exec(e))!==null;){const o=(s=n[1])==null?void 0:s.trim();o&&!t.includes(o)&&t.push(o)}return t}class Ep{constructor(t){be(this,"workspacePath");be(this,"slidesFileName");be(this,"cliBridge",new mr);const i=wp();!(t!=null&&t.workspacePath)||t.workspacePath.includes("/data/storage/petal/siyuan-live-slides/pro-workspace")?this.workspacePath=i:this.workspacePath=t.workspacePath,this.slidesFileName=(t==null?void 0:t.slidesFileName)||"slides.md"}getWorkspacePath(){return this.workspacePath}getSlidesPath(){return`${this.workspacePath}/${this.slidesFileName}`}generatePackageJson(t="default"){const i={name:"siyuan-live-slides-pro-workspace",type:"module",private:!0,scripts:{dev:"slidev --port 3030",build:"slidev build"},dependencies:{"@slidev/cli":"^53.0.0","@slidev/theme-default":"latest"}};return t&&t!=="default"&&(i.dependencies[`@slidev/theme-${t}`]="latest"),JSON.stringify(i,null,2)}buildSlidesMarkdown(t){return this.cliBridge.buildStandardSlidevMarkdown(t)}async scaffold(t,i){const n=this.buildSlidesMarkdown(t),s=this.generatePackageJson(t.config.theme),o=this.getSlidesPath(),a=`${this.workspacePath}/package.json`,r=Fo(o),l=Fo(a),c=Tp(n);c.includes("snippets/external.ts")||c.push("snippets/external.ts");const u=new Map;for(const k of c){const S=Vl[k]||`// Auto-generated snippet placeholder for SiYuan Slidev
// #region snippet
// ${k}
// #endregion snippet
`;u.set(k,S)}t.slides.some(k=>{var S;return((S=k.frontmatter)==null?void 0:S.layout)==="cols-header"})&&u.set("layouts/cols-header.vue",Cp),t.slides.some(k=>{var S;return((S=k.frontmatter)==null?void 0:S.layout)==="three-cols-header"})&&u.set("layouts/three-cols-header.vue",_p),t.slides.some(k=>{var S;return((S=k.frontmatter)==null?void 0:S.layout)==="clover"})&&u.set("layouts/clover.vue",$p),u.set("setup/root.ts",Ip),u.set("styles/index.css",Mp);const w=Tt("fs"),m=Tt("path");let b=!1;const y=m!=null&&m.dirname?m.dirname(r):"",v=/^[a-zA-Z]:[/\\]/.test(r)||r.includes("siyuan-live-slides-pro");if(w&&m&&v)try{w.existsSync(y)||w.mkdirSync(y,{recursive:!0}),w.writeFileSync(l,s,"utf-8"),w.writeFileSync(r,n,"utf-8");for(const[k,S]of u.entries()){const B=m.join(y,k),A=m.dirname(B);w.existsSync(A)||w.mkdirSync(A,{recursive:!0}),w.existsSync(B)||w.writeFileSync(B,S,"utf-8")}b=!0}catch{}if(!b&&i)try{const k=typeof Blob<"u"?new Blob([n],{type:"text/markdown;charset=utf-8"}):Buffer.from(n,"utf-8"),S=typeof Blob<"u"?new Blob([s],{type:"application/json;charset=utf-8"}):Buffer.from(s,"utf-8");await i(a,!1,S),await i(o,!1,k);for(const[B,A]of u.entries()){const C=`${this.workspacePath}/${B}`,L=typeof Blob<"u"?new Blob([A],{type:"text/plain;charset=utf-8"}):Buffer.from(A,"utf-8");await i(C,!1,L).catch(()=>{})}return{success:!0,slidesPath:o,physicalSlidesPath:r,packageJsonPath:a}}catch(k){return{success:!1,slidesPath:o,physicalSlidesPath:r,packageJsonPath:a,error:String(k)}}return{success:!0,slidesPath:o,physicalSlidesPath:r,packageJsonPath:a}}}class Ap{constructor(){be(this,"mode","web-sandbox");be(this,"webBridge");be(this,"cliBridge");be(this,"nativeBridge");be(this,"processManager");be(this,"scaffolder");be(this,"envDetector");this.webBridge=new Qn,this.cliBridge=new mr,this.nativeBridge=new xp,this.processManager=new Sp,this.scaffolder=new Ep,this.envDetector=new vr}getMode(){return this.mode}setMode(t){this.mode=t}async startProMode(t,i){if(!(await this.envDetector.detect()).hasNode)return{success:!1,url:"",error:"当前系统未检测到 Node.js 环境，无法拉起官方 Slidev CLI，建议继续使用内置高保真引擎"};const s=await this.scaffolder.scaffold(t,i);if(!s.success)return{success:!1,url:"",error:`初始化 Slidev 临时工作空间失败: ${s.error}`};const o=s.physicalSlidesPath||s.slidesPath,a=await this.processManager.startServer(o);return a.success?(this.mode="pro-cli",{success:!0,url:a.url,port:a.port}):{success:!1,url:"",error:a.error}}stopProMode(){this.processManager.stopServer(),this.mode="web-sandbox"}destroy(){this.webBridge.detach(),this.nativeBridge.detach(),this.processManager.stopServer()}}const Bp={class:"slides-icon",style:{fill:"none !important"},viewBox:"0 0 24 24",stroke:"currentColor","stroke-width":"1.75","stroke-linecap":"round","stroke-linejoin":"round","aria-hidden":"true"},Dp={key:0},Lp={key:1},Pp={key:2},Op={key:3},Rp={key:4},Np={key:5},zp={key:6},Hp={key:7},Fp={key:8},jp={key:9},Wp={key:10},Up={key:11},Vp={key:12},Gp={key:13},Kp={key:14},qp={key:15},Yp={key:16},Zp={key:17},Jp={key:18},Xp={key:19},Qp={key:20},eh={key:21},th={key:22},ih={key:23},nh={key:24},sh={key:25},oh={key:26},rh={key:27},ah={key:28},lh={key:29},ch={key:30},dh={key:31},uh={key:32},fh={key:33},ph={key:34},hh={key:35},mh={key:36},gh={key:37},vh={key:38},bh={key:39},yh={key:40},kh={key:41},wh={key:42},xh={key:43},Sh={key:44},Ch={key:45},_h={key:46},$h={key:47},Ih={key:48},Mh={key:49},Th={key:50},Eh={key:51},Ah={key:52},Bh={key:53},Dh={key:54},Lh={key:55},Ph={key:56},Oh={key:57},Rh={key:58},Nh={key:59},zh={key:60},Hh={key:61},Fh={key:62},jh={key:63},Wh={key:64},Uh={key:65},Vh={key:66},Gh={key:67},Kh={key:68},qh={key:69},Yh={key:70},Zh={key:71},Jh={key:72},Xh=Dt({__name:"SlidesIcon",props:{name:{}},setup(e){return(t,i)=>(J(),ee("svg",Bp,[e.name==="fullscreen"||e.name==="maximize"?(J(),ee("g",Dp,[...i[0]||(i[0]=[h("polyline",{points:"15 3 21 3 21 9"},null,-1),h("polyline",{points:"9 21 3 21 3 15"},null,-1),h("polyline",{points:"21 15 21 21 15 21"},null,-1),h("polyline",{points:"3 9 3 3 9 3"},null,-1)])])):e.name==="minimize"?(J(),ee("g",Lp,[...i[1]||(i[1]=[h("polyline",{points:"4 14 10 14 10 20"},null,-1),h("polyline",{points:"20 10 14 10 14 4"},null,-1),h("line",{x1:"14",y1:"10",x2:"21",y2:"3"},null,-1),h("line",{x1:"3",y1:"21",x2:"10",y2:"14"},null,-1)])])):e.name==="close"||e.name==="x"?(J(),ee("g",Pp,[...i[2]||(i[2]=[h("line",{x1:"18",y1:"6",x2:"6",y2:"18"},null,-1),h("line",{x1:"6",y1:"6",x2:"18",y2:"18"},null,-1)])])):e.name==="edit"?(J(),ee("g",Op,[...i[3]||(i[3]=[h("path",{d:"M12 20h9"},null,-1),h("path",{d:"M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z"},null,-1)])])):e.name==="eye"?(J(),ee("g",Rp,[...i[4]||(i[4]=[h("path",{d:"M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"},null,-1),h("circle",{cx:"12",cy:"12",r:"3"},null,-1)])])):e.name==="external-link"||e.name==="window"?(J(),ee("g",Np,[...i[5]||(i[5]=[h("path",{d:"M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"},null,-1),h("polyline",{points:"15 3 21 3 21 9"},null,-1),h("line",{x1:"10",y1:"14",x2:"21",y2:"3"},null,-1)])])):e.name==="arrow-left"?(J(),ee("g",zp,[...i[6]||(i[6]=[h("line",{x1:"19",y1:"12",x2:"5",y2:"12"},null,-1),h("polyline",{points:"12 19 5 12 12 5"},null,-1)])])):e.name==="arrow-right"?(J(),ee("g",Hp,[...i[7]||(i[7]=[h("line",{x1:"5",y1:"12",x2:"19",y2:"12"},null,-1),h("polyline",{points:"12 5 19 12 12 19"},null,-1)])])):e.name==="plus"?(J(),ee("g",Fp,[...i[8]||(i[8]=[h("line",{x1:"12",y1:"5",x2:"12",y2:"19"},null,-1),h("line",{x1:"5",y1:"12",x2:"19",y2:"12"},null,-1)])])):e.name==="minus"?(J(),ee("g",jp,[...i[9]||(i[9]=[h("line",{x1:"5",y1:"12",x2:"19",y2:"12"},null,-1)])])):e.name==="split-preview"?(J(),ee("g",Wp,[...i[10]||(i[10]=[h("rect",{x:"3",y:"3",width:"18",height:"18",rx:"2"},null,-1),h("path",{d:"M12 3v18"},null,-1)])])):e.name==="import"?(J(),ee("g",Up,[...i[11]||(i[11]=[h("path",{d:"M4 17v2a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-2"},null,-1),h("polyline",{points:"7 9 12 14 17 9"},null,-1),h("line",{x1:"12",y1:"14",x2:"12",y2:"3"},null,-1)])])):e.name==="presenter"?(J(),ee("g",Vp,[...i[12]||(i[12]=[h("path",{d:"M2 3h20"},null,-1),h("path",{d:"M21 3v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V3"},null,-1),h("path",{d:"m7 21 5-5 5 5"},null,-1)])])):e.name==="video"?(J(),ee("g",Gp,[...i[13]||(i[13]=[h("polygon",{points:"23 7 16 12 23 17 23 7"},null,-1),h("rect",{x:"1",y:"5",width:"15",height:"14",rx:"2",ry:"2"},null,-1)])])):e.name==="step"?(J(),ee("g",Kp,[...i[14]||(i[14]=[h("polygon",{points:"13 2 3 14 12 14 11 22 21 10 12 10 13 2"},null,-1)])])):e.name==="motion"?(J(),ee("g",qp,[...i[15]||(i[15]=[h("path",{d:"M5 12h14"},null,-1),h("path",{d:"m12 5 7 7-7 7"},null,-1),h("path",{d:"M5 6h4"},null,-1),h("path",{d:"M5 18h4"},null,-1)])])):e.name==="columns"?(J(),ee("g",Yp,[...i[16]||(i[16]=[h("rect",{x:"3",y:"3",width:"7",height:"18",rx:"1"},null,-1),h("rect",{x:"14",y:"3",width:"7",height:"18",rx:"1"},null,-1)])])):e.name==="code"?(J(),ee("g",Zp,[...i[17]||(i[17]=[h("polyline",{points:"16 18 22 12 16 6"},null,-1),h("polyline",{points:"8 6 2 12 8 18"},null,-1)])])):e.name==="list"?(J(),ee("g",Jp,[...i[18]||(i[18]=[ht('<line x1="8" y1="6" x2="21" y2="6" data-v-af7d02a2></line><line x1="8" y1="12" x2="21" y2="12" data-v-af7d02a2></line><line x1="8" y1="18" x2="21" y2="18" data-v-af7d02a2></line><line x1="3" y1="6" x2="3.01" y2="6" data-v-af7d02a2></line><line x1="3" y1="12" x2="3.01" y2="12" data-v-af7d02a2></line><line x1="3" y1="18" x2="3.01" y2="18" data-v-af7d02a2></line>',6)])])):e.name==="insert-above"?(J(),ee("g",Xp,[...i[19]||(i[19]=[h("line",{x1:"12",y1:"5",x2:"12",y2:"13"},null,-1),h("line",{x1:"8",y1:"9",x2:"16",y2:"9"},null,-1),h("path",{d:"M4 19h16","stroke-dasharray":"2 2"},null,-1)])])):e.name==="insert-below"?(J(),ee("g",Qp,[...i[20]||(i[20]=[h("path",{d:"M4 5h16","stroke-dasharray":"2 2"},null,-1),h("line",{x1:"12",y1:"11",x2:"12",y2:"19"},null,-1),h("line",{x1:"8",y1:"15",x2:"16",y2:"15"},null,-1)])])):e.name==="broom"?(J(),ee("g",eh,[...i[21]||(i[21]=[h("path",{d:"m18 15-6-6"},null,-1),h("path",{d:"M4 20h16"},null,-1),h("path",{d:"M6 14l8-8a2.8 2.8 0 0 1 4 4l-8 8H6v-4z"},null,-1)])])):e.name==="trash"?(J(),ee("g",th,[...i[22]||(i[22]=[h("path",{d:"M3 6h18"},null,-1),h("path",{d:"M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"},null,-1),h("path",{d:"M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"},null,-1)])])):e.name==="ai"||e.name==="sparkles"?(J(),ee("g",ih,[...i[23]||(i[23]=[h("path",{d:"m12 3-1.9 5.8a2 2 0 0 1-1.3 1.3L3 12l5.8 1.9a2 2 0 0 1 1.3 1.3L12 21l1.9-5.8a2 2 0 0 1 1.3-1.3L21 12l-5.8-1.9a2 2 0 0 1-1.3-1.3L12 3z"},null,-1)])])):e.name==="palette"?(J(),ee("g",nh,[...i[24]||(i[24]=[ht('<circle cx="13.5" cy="6.5" r=".5" fill="currentColor" data-v-af7d02a2></circle><circle cx="17.5" cy="10.5" r=".5" fill="currentColor" data-v-af7d02a2></circle><circle cx="8.5" cy="7.5" r=".5" fill="currentColor" data-v-af7d02a2></circle><circle cx="6.5" cy="12.5" r=".5" fill="currentColor" data-v-af7d02a2></circle><path d="M12 2C6.5 2 2 6.5 2 12s4.5 10 10 10c.9 0 1.5-.7 1.5-1.5 0-.4-.2-.8-.4-1.1-.3-.4-.4-.8-.4-1.4 0-1.1.9-2 2-2h2.3c3.9 0 7-3.1 7-7 0-5-4.5-9-10-9z" data-v-af7d02a2></path>',5)])])):e.name==="ratio"?(J(),ee("g",sh,[...i[25]||(i[25]=[h("rect",{x:"2",y:"5",width:"20",height:"14",rx:"2"},null,-1),h("line",{x1:"2",y1:"10",x2:"22",y2:"10","stroke-dasharray":"2 2"},null,-1)])])):e.name==="transition"?(J(),ee("g",oh,[...i[26]||(i[26]=[h("path",{d:"M8 3 4 7l4 4"},null,-1),h("path",{d:"M4 7h16"},null,-1),h("path",{d:"m16 21 4-4-4-4"},null,-1),h("path",{d:"M20 17H4"},null,-1)])])):e.name==="export-html"?(J(),ee("g",rh,[...i[27]||(i[27]=[h("polyline",{points:"16 16 12 12 8 16"},null,-1),h("line",{x1:"12",y1:"12",x2:"12",y2:"21"},null,-1),h("path",{d:"M20.4 16.3A5 5 0 0 0 18 7h-1.3A8 8 0 0 0 4 12.8a5 5 0 0 0 1.5 9.2"},null,-1)])])):e.name==="export-pdf"?(J(),ee("g",ah,[...i[28]||(i[28]=[h("polyline",{points:"6 9 6 2 18 2 18 9"},null,-1),h("path",{d:"M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"},null,-1),h("rect",{x:"6",y:"14",width:"12",height:"8"},null,-1)])])):e.name==="pin"?(J(),ee("g",lh,[...i[29]||(i[29]=[h("line",{x1:"12",y1:"17",x2:"12",y2:"22"},null,-1),h("path",{d:"M5 17h14v-2l-2-2V5l1-1V2H6v2l1 1v8l-2 2v2z"},null,-1)])])):e.name==="refresh"?(J(),ee("g",ch,[...i[30]||(i[30]=[h("path",{d:"M3 12a9 9 0 0 1 9-9 9.75 9.75 0 0 1 6.74 2.74L21 8"},null,-1),h("path",{d:"M21 3v5h-5"},null,-1),h("path",{d:"M21 12a9 9 0 0 1-9 9 9.75 9.75 0 0 1-6.74-2.74L3 16"},null,-1),h("path",{d:"M8 16H3v5"},null,-1)])])):e.name==="alert"||e.name==="warning"?(J(),ee("g",dh,[...i[31]||(i[31]=[h("path",{d:"M10.29 3.86 1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"},null,-1),h("line",{x1:"12",y1:"9",x2:"12",y2:"13"},null,-1),h("line",{x1:"12",y1:"17",x2:"12.01",y2:"17"},null,-1)])])):e.name==="chevron-left"?(J(),ee("g",uh,[...i[32]||(i[32]=[h("polyline",{points:"15 18 9 12 15 6"},null,-1)])])):e.name==="chevron-right"?(J(),ee("g",fh,[...i[33]||(i[33]=[h("polyline",{points:"9 18 15 12 9 6"},null,-1)])])):e.name==="chevron-down"?(J(),ee("g",ph,[...i[34]||(i[34]=[h("polyline",{points:"6 9 12 15 18 9"},null,-1)])])):e.name==="chevrons-left"?(J(),ee("g",hh,[...i[35]||(i[35]=[h("polyline",{points:"11 17 6 12 11 7"},null,-1),h("polyline",{points:"18 17 13 12 18 7"},null,-1)])])):e.name==="chevrons-right"?(J(),ee("g",mh,[...i[36]||(i[36]=[h("polyline",{points:"13 17 18 12 13 7"},null,-1),h("polyline",{points:"6 17 11 12 6 7"},null,-1)])])):e.name==="play"?(J(),ee("g",gh,[...i[37]||(i[37]=[h("polygon",{points:"6 3 20 12 6 21 6 3"},null,-1)])])):e.name==="pause"?(J(),ee("g",vh,[...i[38]||(i[38]=[h("line",{x1:"10",y1:"4",x2:"10",y2:"20"},null,-1),h("line",{x1:"14",y1:"4",x2:"14",y2:"20"},null,-1)])])):e.name==="clock"?(J(),ee("g",bh,[...i[39]||(i[39]=[h("circle",{cx:"12",cy:"12",r:"10"},null,-1),h("polyline",{points:"12 6 12 12 16 14"},null,-1)])])):e.name==="copy"?(J(),ee("g",yh,[...i[40]||(i[40]=[h("rect",{x:"9",y:"9",width:"13",height:"13",rx:"2",ry:"2"},null,-1),h("path",{d:"M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"},null,-1)])])):e.name==="image"||e.name==="export-image"?(J(),ee("g",kh,[...i[41]||(i[41]=[h("rect",{x:"3",y:"3",width:"18",height:"18",rx:"2",ry:"2"},null,-1),h("circle",{cx:"8.5",cy:"8.5",r:"1.5"},null,-1),h("polyline",{points:"21 15 16 10 5 21"},null,-1)])])):e.name==="search"?(J(),ee("g",wh,[...i[42]||(i[42]=[h("circle",{cx:"11",cy:"11",r:"7"},null,-1),h("line",{x1:"21",y1:"21",x2:"16.65",y2:"16.65"},null,-1)])])):e.name==="settings"||e.name==="gear"?(J(),ee("g",xh,[...i[43]||(i[43]=[h("circle",{cx:"12",cy:"12",r:"3"},null,-1),h("path",{d:"M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 1 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 1 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 1 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 1 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"},null,-1)])])):e.name==="notes"||e.name==="file-text"?(J(),ee("g",Sh,[...i[44]||(i[44]=[ht('<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" data-v-af7d02a2></path><polyline points="14 2 14 8 20 8" data-v-af7d02a2></polyline><line x1="16" y1="13" x2="8" y2="13" data-v-af7d02a2></line><line x1="16" y1="17" x2="8" y2="17" data-v-af7d02a2></line><line x1="10" y1="9" x2="8" y2="9" data-v-af7d02a2></line>',5)])])):e.name==="focus"||e.name==="target"?(J(),ee("g",Ch,[...i[45]||(i[45]=[h("circle",{cx:"12",cy:"12",r:"3",fill:"currentColor"},null,-1),h("path",{d:"M12 2v4M12 18v4M2 12h4M18 12h4",stroke:"currentColor","stroke-width":"2","stroke-linecap":"round"},null,-1),h("circle",{cx:"12",cy:"12",r:"7",fill:"none",stroke:"currentColor","stroke-width":"1.8"},null,-1)])])):e.name==="layout-cover"||e.name==="cover"?(J(),ee("g",_h,[...i[46]||(i[46]=[h("rect",{x:"2",y:"4",width:"20",height:"16",rx:"2"},null,-1),h("line",{x1:"9",y1:"8",x2:"15",y2:"8"},null,-1),h("line",{x1:"5.5",y1:"11.5",x2:"18.5",y2:"11.5"},null,-1),h("line",{x1:"7.5",y1:"15",x2:"16.5",y2:"15"},null,-1)])])):e.name==="layout-default"||e.name==="default"?(J(),ee("g",$h,[...i[47]||(i[47]=[ht('<rect x="2" y="4" width="20" height="16" rx="2" data-v-af7d02a2></rect><line x1="5" y1="8" x2="11.5" y2="8" data-v-af7d02a2></line><line x1="5" y1="11.5" x2="19" y2="11.5" data-v-af7d02a2></line><line x1="5" y1="14.5" x2="19" y2="14.5" data-v-af7d02a2></line><line x1="5" y1="17.5" x2="13.5" y2="17.5" data-v-af7d02a2></line>',5)])])):e.name==="layout-two-cols"||e.name==="two-cols"?(J(),ee("g",Ih,[...i[48]||(i[48]=[ht('<rect x="2" y="4" width="20" height="16" rx="2" data-v-af7d02a2></rect><line x1="12" y1="4" x2="12" y2="20" stroke-dasharray="2 1.5" data-v-af7d02a2></line><line x1="5" y1="8" x2="9.5" y2="8" data-v-af7d02a2></line><line x1="5" y1="11.5" x2="9.5" y2="11.5" data-v-af7d02a2></line><line x1="5" y1="15" x2="8" y2="15" data-v-af7d02a2></line><line x1="14.5" y1="8" x2="19" y2="8" data-v-af7d02a2></line><line x1="14.5" y1="11.5" x2="19" y2="11.5" data-v-af7d02a2></line><line x1="14.5" y1="15" x2="17.5" y2="15" data-v-af7d02a2></line>',8)])])):e.name==="layout-two-cols-header"||e.name==="two-cols-header"?(J(),ee("g",Mh,[...i[49]||(i[49]=[ht('<rect x="2" y="4" width="20" height="16" rx="2" data-v-af7d02a2></rect><line x1="5" y1="7.5" x2="13" y2="7.5" data-v-af7d02a2></line><line x1="12" y1="10.5" x2="12" y2="18.5" stroke-dasharray="1.5 1.5" data-v-af7d02a2></line><line x1="5" y1="12" x2="9.5" y2="12" data-v-af7d02a2></line><line x1="5" y1="15.5" x2="8.5" y2="15.5" data-v-af7d02a2></line><line x1="14.5" y1="12" x2="19" y2="12" data-v-af7d02a2></line><line x1="14.5" y1="15.5" x2="18" y2="15.5" data-v-af7d02a2></line>',7)])])):e.name==="layout-cols-header"||e.name==="cols-header"||e.name==="layout-three-cols-header"||e.name==="three-cols-header"?(J(),ee("g",Th,[...i[50]||(i[50]=[ht('<rect x="2" y="4" width="20" height="16" rx="2" data-v-af7d02a2></rect><line x1="5" y1="7.5" x2="13" y2="7.5" data-v-af7d02a2></line><line x1="9.3" y1="10.5" x2="9.3" y2="18.5" stroke-dasharray="1.5 1.5" data-v-af7d02a2></line><line x1="14.7" y1="10.5" x2="14.7" y2="18.5" stroke-dasharray="1.5 1.5" data-v-af7d02a2></line><line x1="4.5" y1="12" x2="7.5" y2="12" data-v-af7d02a2></line><line x1="4.5" y1="15.5" x2="7" y2="15.5" data-v-af7d02a2></line><line x1="10.5" y1="12" x2="13.5" y2="12" data-v-af7d02a2></line><line x1="10.5" y1="15.5" x2="13.5" y2="15.5" data-v-af7d02a2></line><line x1="16" y1="12" x2="19.5" y2="12" data-v-af7d02a2></line><line x1="16" y1="15.5" x2="18.5" y2="15.5" data-v-af7d02a2></line>',10)])])):e.name==="layout-clover"||e.name==="clover"?(J(),ee("g",Eh,[...i[51]||(i[51]=[ht('<rect x="2" y="4" width="20" height="16" rx="2" data-v-af7d02a2></rect><line x1="5" y1="7" x2="13" y2="7" data-v-af7d02a2></line><line x1="4.5" y1="13.5" x2="19.5" y2="13.5" stroke-dasharray="1.5 1.5" data-v-af7d02a2></line><line x1="12" y1="9" x2="12" y2="18.5" stroke-dasharray="1.5 1.5" data-v-af7d02a2></line><line x1="5" y1="11" x2="9.5" y2="11" data-v-af7d02a2></line><line x1="14.5" y1="11" x2="19" y2="11" data-v-af7d02a2></line><line x1="5" y1="16" x2="9.5" y2="16" data-v-af7d02a2></line><line x1="14.5" y1="16" x2="19" y2="16" data-v-af7d02a2></line>',8)])])):e.name==="layout-image-right"||e.name==="image-right"?(J(),ee("g",Ah,[...i[52]||(i[52]=[ht('<rect x="2" y="4" width="20" height="16" rx="2" data-v-af7d02a2></rect><line x1="12" y1="4" x2="12" y2="20" data-v-af7d02a2></line><line x1="4.5" y1="8" x2="9.5" y2="8" data-v-af7d02a2></line><line x1="4.5" y1="11.5" x2="10" y2="11.5" data-v-af7d02a2></line><line x1="4.5" y1="14.5" x2="8" y2="14.5" data-v-af7d02a2></line><circle cx="15.5" cy="8.5" r="1.2" data-v-af7d02a2></circle><polyline points="13 17 15.5 13 18 16 19.5 14" data-v-af7d02a2></polyline>',7)])])):e.name==="layout-image-left"||e.name==="image-left"?(J(),ee("g",Bh,[...i[53]||(i[53]=[ht('<rect x="2" y="4" width="20" height="16" rx="2" data-v-af7d02a2></rect><line x1="12" y1="4" x2="12" y2="20" data-v-af7d02a2></line><circle cx="6" cy="8.5" r="1.2" data-v-af7d02a2></circle><polyline points="3.5 17 6 13 8.5 16 10 14" data-v-af7d02a2></polyline><line x1="14.5" y1="8" x2="19.5" y2="8" data-v-af7d02a2></line><line x1="14.5" y1="11.5" x2="20" y2="11.5" data-v-af7d02a2></line><line x1="14.5" y1="14.5" x2="18" y2="14.5" data-v-af7d02a2></line>',7)])])):e.name==="layout-center"||e.name==="center"?(J(),ee("g",Dh,[...i[54]||(i[54]=[h("rect",{x:"2",y:"4",width:"20",height:"16",rx:"2"},null,-1),h("line",{x1:"6.5",y1:"9",x2:"17.5",y2:"9"},null,-1),h("line",{x1:"5",y1:"12",x2:"19",y2:"12"},null,-1),h("line",{x1:"8",y1:"15",x2:"16",y2:"15"},null,-1)])])):e.name==="layout-fact"||e.name==="fact"?(J(),ee("g",Lh,[...i[55]||(i[55]=[ht('<rect x="2" y="4" width="20" height="16" rx="2" data-v-af7d02a2></rect><circle cx="8" cy="9" r="1.5" data-v-af7d02a2></circle><line x1="14" y1="8" x2="9" y2="14" data-v-af7d02a2></line><circle cx="15" cy="13" r="1.5" data-v-af7d02a2></circle><line x1="6.5" y1="17" x2="17.5" y2="17" data-v-af7d02a2></line>',5)])])):e.name==="layout-intro"||e.name==="intro"?(J(),ee("g",Ph,[...i[56]||(i[56]=[ht('<rect x="2" y="4" width="20" height="16" rx="2" data-v-af7d02a2></rect><circle cx="7.5" cy="9.5" r="2" data-v-af7d02a2></circle><path d="M4.5 16.5c0-1.8 1.3-3 3-3s3 1.2 3 3" data-v-af7d02a2></path><line x1="13" y1="9" x2="18.5" y2="9" data-v-af7d02a2></line><line x1="13" y1="12.5" x2="19.5" y2="12.5" data-v-af7d02a2></line><line x1="13" y1="15.5" x2="17" y2="15.5" data-v-af7d02a2></line>',6)])])):e.name==="layout-quote"||e.name==="quote"?(J(),ee("g",Oh,[...i[57]||(i[57]=[ht('<rect x="2" y="4" width="20" height="16" rx="2" data-v-af7d02a2></rect><path d="M6 7.5h2v2H6.5c0 1.2-.4 2-1.5 2.5" data-v-af7d02a2></path><path d="M9.5 7.5h2v2H10c0 1.2-.4 2-1.5 2.5" data-v-af7d02a2></path><line x1="6" y1="13.5" x2="18" y2="13.5" data-v-af7d02a2></line><line x1="12.5" y1="16.5" x2="17.5" y2="16.5" data-v-af7d02a2></line>',5)])])):e.name==="desktop"||e.name==="monitor"?(J(),ee("g",Rh,[...i[58]||(i[58]=[h("rect",{x:"2",y:"3",width:"20",height:"14",rx:"2"},null,-1),h("line",{x1:"8",y1:"21",x2:"16",y2:"21"},null,-1),h("line",{x1:"12",y1:"17",x2:"12",y2:"21"},null,-1)])])):e.name==="mobile"||e.name==="smartphone"||e.name==="phone"?(J(),ee("g",Nh,[...i[59]||(i[59]=[h("rect",{x:"5",y:"2",width:"14",height:"20",rx:"2",ry:"2"},null,-1),h("line",{x1:"12",y1:"18",x2:"12.01",y2:"18","stroke-width":"2","stroke-linecap":"round"},null,-1)])])):e.name==="type"||e.name==="heading"?(J(),ee("g",zh,[...i[60]||(i[60]=[h("polyline",{points:"4 7 4 4 20 4 20 7"},null,-1),h("line",{x1:"9",y1:"20",x2:"15",y2:"20"},null,-1),h("line",{x1:"12",y1:"4",x2:"12",y2:"20"},null,-1)])])):e.name==="reset"||e.name==="undo"?(J(),ee("g",Hh,[...i[61]||(i[61]=[h("path",{d:"M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8"},null,-1),h("polyline",{points:"3 3 3 8 8 8"},null,-1)])])):e.name==="repeat"||e.name==="loop"?(J(),ee("g",Fh,[...i[62]||(i[62]=[h("path",{d:"m17 1 4 4-4 4"},null,-1),h("path",{d:"M3 11V9a4 4 0 0 1 4-4h14"},null,-1),h("path",{d:"m7 23-4-4 4-4"},null,-1),h("path",{d:"M21 13v2a4 4 0 0 1-4 4H3"},null,-1)])])):e.name==="volume-x"||e.name==="mute"?(J(),ee("g",jh,[...i[63]||(i[63]=[h("polygon",{points:"11 5 6 9 2 9 2 15 6 15 11 19 11 5"},null,-1),h("line",{x1:"22",y1:"9",x2:"16",y2:"15"},null,-1),h("line",{x1:"16",y1:"9",x2:"22",y2:"15"},null,-1)])])):e.name==="sliders"||e.name==="controls"?(J(),ee("g",Wh,[...i[64]||(i[64]=[ht('<line x1="4" y1="21" x2="4" y2="14" data-v-af7d02a2></line><line x1="4" y1="10" x2="4" y2="3" data-v-af7d02a2></line><line x1="12" y1="21" x2="12" y2="12" data-v-af7d02a2></line><line x1="12" y1="8" x2="12" y2="3" data-v-af7d02a2></line><line x1="20" y1="21" x2="20" y2="16" data-v-af7d02a2></line><line x1="20" y1="12" x2="20" y2="3" data-v-af7d02a2></line><line x1="1" y1="14" x2="7" y2="14" data-v-af7d02a2></line><line x1="9" y1="8" x2="15" y2="8" data-v-af7d02a2></line><line x1="17" y1="16" x2="23" y2="16" data-v-af7d02a2></line>',9)])])):e.name==="package"||e.name==="zip"||e.name==="archive"?(J(),ee("g",Uh,[...i[65]||(i[65]=[h("line",{x1:"16.5",y1:"9.4",x2:"7.5",y2:"4.21"},null,-1),h("path",{d:"M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"},null,-1),h("polyline",{points:"3.27 6.96 12 12.01 20.73 6.96"},null,-1),h("line",{x1:"12",y1:"22.08",x2:"12",y2:"12"},null,-1)])])):e.name==="folder"?(J(),ee("g",Vh,[...i[66]||(i[66]=[h("path",{d:"M4 20h16a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2h-7.93a2 2 0 0 1-1.66-.9l-.82-1.2A2 2 0 0 0 7.93 3H4a2 2 0 0 0-2 2v13c0 1.1.9 2 2 2Z"},null,-1)])])):e.name==="rocket"?(J(),ee("g",Gh,[...i[67]||(i[67]=[h("path",{d:"M4.5 16.5c-1.5 1.26-2 5-2 5s3.74-.5 5-2c.71-.84.7-2.13-.09-2.91a2.18 2.18 0 0 0-2.91-.09z"},null,-1),h("path",{d:"m12 15-3-3a22 22 0 0 1 2-3.95A12.88 12.88 0 0 1 22 2c0 2.72-.78 7.5-6 11a22.35 22.35 0 0 1-4 2z"},null,-1),h("path",{d:"M9 12H4s.55-3.03 2-4c1.62-1.08 5 0 5 0"},null,-1),h("path",{d:"M12 15v5s3.03-.55 4-2c1.08-1.62 0-5 0-5"},null,-1)])])):e.name==="wand"||e.name==="magic"?(J(),ee("g",Kh,[...i[68]||(i[68]=[h("path",{d:"m19 2 2 2-6 6-2-2Z"},null,-1),h("path",{d:"m13 8 2 2"},null,-1),h("path",{d:"m3 21 9-9"},null,-1)])])):e.name==="image-left"?(J(),ee("g",qh,[...i[69]||(i[69]=[ht('<rect x="2" y="4" width="20" height="16" rx="2" data-v-af7d02a2></rect><rect x="4" y="6" width="6" height="12" rx="1" data-v-af7d02a2></rect><line x1="13" y1="8" x2="19" y2="8" data-v-af7d02a2></line><line x1="13" y1="12" x2="19" y2="12" data-v-af7d02a2></line><line x1="13" y1="16" x2="17" y2="16" data-v-af7d02a2></line>',5)])])):e.name==="image-right"?(J(),ee("g",Yh,[...i[70]||(i[70]=[ht('<rect x="2" y="4" width="20" height="16" rx="2" data-v-af7d02a2></rect><rect x="14" y="6" width="6" height="12" rx="1" data-v-af7d02a2></rect><line x1="5" y1="8" x2="11" y2="8" data-v-af7d02a2></line><line x1="5" y1="12" x2="11" y2="12" data-v-af7d02a2></line><line x1="5" y1="16" x2="9" y2="16" data-v-af7d02a2></line>',5)])])):e.name==="help"||e.name==="question"||e.name==="info"?(J(),ee("g",Zh,[...i[71]||(i[71]=[h("circle",{cx:"12",cy:"12",r:"10"},null,-1),h("path",{d:"M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"},null,-1),h("line",{x1:"12",y1:"17",x2:"12.01",y2:"17"},null,-1)])])):(J(),ee("g",Jh,[...i[72]||(i[72]=[h("rect",{x:"2",y:"3",width:"20",height:"14",rx:"2"},null,-1),h("line",{x1:"8",y1:"21",x2:"16",y2:"21"},null,-1),h("line",{x1:"12",y1:"17",x2:"12",y2:"21"},null,-1)])]))]))}}),ii=(e,t)=>{const i=e.__vccOpts||e;for(const[n,s]of t)i[n]=s;return i},de=ii(Xh,[["__scopeId","data-v-af7d02a2"]]),Qh={class:"spm-immersion-header"},em={class:"spm-immersion-header__left"},tm={class:"spm-immersion-title"},im={class:"spm-immersion-header__center"},nm={class:"spm-immersion-header__actions"},sm=["aria-label"],om={class:"spm-immersion-body"},rm=Dt({__name:"ImmersionDrawerContainer",props:{visible:{type:Boolean,default:!1},isMaximized:{type:Boolean,default:!1},title:{default:"速览"},closeOnClickMask:{type:Boolean,default:!0}},emits:["update:visible","update:isMaximized","close","toggle-maximize"],setup(e,{emit:t}){const i=e,n=t;function s(){n("update:visible",!1),n("close")}function o(){i.closeOnClickMask&&s()}function a(){n("update:isMaximized",!i.isMaximized),n("toggle-maximize")}function r(l){(l.key===" "||l.key==="ArrowLeft"||l.key==="ArrowRight"||l.key==="PageUp"||l.key==="PageDown")&&l.stopPropagation(),l.key==="Escape"&&(l.preventDefault(),l.stopPropagation(),s())}return(l,c)=>Ot((J(),ee("div",{class:Ce(["spm-immersion-container",{"is-maximized":e.isMaximized}]),onKeydown:Zt(r,["stop"])},[h("div",{class:"spm-immersion-mask",onClick:o}),h("div",{class:Ce(["spm-immersion-drawer",{"is-maximized":e.isMaximized}])},[h("div",Qh,[h("div",em,[rs(l.$slots,"header-left",{},()=>[h("span",tm,we(e.title),1)])]),h("div",im,[rs(l.$slots,"header-center",{},void 0)]),h("div",nm,[rs(l.$slots,"header-actions",{},void 0),h("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":e.isMaximized?"还原抽屉宽度 (70%)":"最大化填满视口 (100%)",onClick:a},[oe(de,{name:e.isMaximized?"minimize":"maximize"},null,8,["name"])],8,sm),h("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"关闭速览 (ESC)",onClick:s},[oe(de,{name:"close"})])])]),h("div",om,[rs(l.$slots,"default",{},void 0)])],2)],34)),[[Oo,e.visible]])}}),am=ii(rm,[["__scopeId","data-v-1359fecb"]]),lm={class:"spm-protyle-drawer"},cm={class:"spm-protyle-drawer__subbar"},dm={class:"spm-protyle-drawer__nav"},um=["title"],fm={class:"spm-protyle-drawer__actions"},pm=["aria-label"],hm=["aria-label"],mm=Dt({__name:"ProtylePeekDrawer",props:{blockId:{},title:{},plugin:{}},emits:["external-jump"],setup(e,{emit:t}){const i=t,n=e,s=ge(n.blockId),o=ge(n.title||""),a=ge(!1),r=ge(!0),l=ge(!1),c=ge(""),u=Vt,f=ge([]),d=ge(null);let p=null;Vi(()=>n.blockId,C=>{C&&C!==s.value&&(s.value=C,o.value=n.title||"",f.value=[],m(C))}),bn(()=>{s.value&&m(s.value)}),rr(()=>{b()});async function w(C){try{const L=await un(`SELECT id, root_id, type, content FROM blocks WHERE id = '${C}' LIMIT 1`);if(Array.isArray(L)&&L.length>0){const z=L[0];c.value=z.root_id||"";const N=z.id===z.root_id||z.type==="d";l.value=N,r.value=!N,!o.value&&z.content&&(o.value=z.content.trim().slice(0,30));return}}catch(L){console.warn("[ProtylePeekDrawer] detectBlockType query failed:",L)}l.value=!1,r.value=!0}async function m(C,L){if(!d.value||!C)return;b(),await w(C),typeof L=="boolean"&&(r.value=!l.value&&L);let z,N;r.value&&!l.value?(z=["cb-get-all","cb-get-hl","cb-get-focus"],N={background:!1,title:!1,gutter:!0,breadcrumbDocName:!0,scroll:!0}):(z=["cb-get-context","cb-get-hl"],N={background:!0,title:!0,gutter:!0,breadcrumbDocName:!0,scroll:!0});try{p=new ae.Protyle(n.plugin.app,d.value,{blockId:C,action:z,render:N}),!a.value&&p&&typeof p.disable=="function"&&p.disable()}catch(K){console.error("[ProtylePeekDrawer] Failed to instantiate Protyle:",K)}}function b(){if(p){try{typeof p.destroy=="function"&&p.destroy()}catch(C){console.warn("[ProtylePeekDrawer] Error destroying protyle:",C)}p=null}d.value&&(d.value.innerHTML="")}function y(){l.value||(r.value=!r.value,m(s.value,r.value))}function v(){a.value=!a.value,p&&(a.value?(typeof p.enable=="function"&&p.enable(),typeof p.focus=="function"&&p.focus()):typeof p.disable=="function"&&p.disable())}function k(){if(s.value)try{ae.openWindow({doc:{id:s.value},alwaysOnTop:!0})}catch(C){console.warn("[ProtylePeekDrawer] openWindow failed:",C)}}function S(){var z;if(!s.value)return;const C=Ys(),L=Rl(C.webServeUrl,s.value,{focus:!l.value});if(typeof window<"u"){const N=Tt("electron");(z=N==null?void 0:N.shell)!=null&&z.openExternal?N.shell.openExternal(L).catch(()=>{window.open(L,"_blank")}):window.open(L,"_blank")}i("external-jump",L)}function B(){if(f.value.length>0){const C=f.value.pop();C&&(s.value=C.blockId,o.value=C.title,r.value=C.isFocusMode,l.value=C.isDoc,m(C.blockId,C.isFocusMode))}}function A(C){const L=C.target;if(!L)return;const z=L.closest('[data-type="block-ref"]');if(z){const K=z.getAttribute("data-id");if(K&&K!==s.value){C.preventDefault(),C.stopPropagation(),f.value.push({blockId:s.value,title:o.value||s.value,isFocusMode:r.value,isDoc:l.value}),s.value=K,o.value=z.innerText.trim()||K,m(K);return}}const N=L.closest("a");if(N&&N.href&&N.href.startsWith("siyuan://blocks/")){C.preventDefault(),C.stopPropagation();const K=N.href.replace("siyuan://blocks/","").split("?")[0];K&&K!==s.value&&(f.value.push({blockId:s.value,title:o.value||s.value,isFocusMode:r.value,isDoc:l.value}),s.value=K,o.value=N.innerText.trim()||K,m(K))}}return(C,L)=>(J(),ee("div",lm,[h("div",cm,[h("div",dm,[f.value.length>0?(J(),ee("button",{key:0,class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"返回上层引用文档或块",onClick:B},[oe(de,{name:"arrow-left"}),L[0]||(L[0]=h("span",null,"返回",-1))])):Te("",!0),h("span",{class:Ce(["spm-protyle-badge",{"is-focus":r.value&&!l.value}])},we(r.value&&!l.value?"思源块聚焦":"思源文档速览"),3),h("span",{class:"spm-protyle-id",title:o.value||s.value},we(o.value||s.value),9,um)]),h("div",fm,[l.value?Te("",!0):(J(),ee("button",{key:0,class:Ce(["spm-icon-btn b3-tooltips b3-tooltips__s",{"is-primary":r.value}]),"aria-label":r.value?"当前为块聚焦模式（点击展开所属文档全文）":"当前为文档全文模式（点击切回仅聚焦当前块）",onClick:y},[oe(de,{name:r.value?"focus":"file-text"},null,8,["name"]),h("span",null,we(r.value?"块聚焦":"展开全文"),1)],10,pm)),h("button",{class:Ce(["spm-icon-btn b3-tooltips b3-tooltips__s",{"is-primary":a.value}]),"aria-label":a.value?"当前为即时编辑模式（点击切回只读）":"当前为只读速览模式（点击解锁即时编辑）",onClick:v},[oe(de,{name:a.value?"edit":"eye"},null,8,["name"]),h("span",null,we(a.value?"编辑中":"只读"),1)],10,hm),h("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"在置顶独立窗口中打开 (保留完整侧边栏与插件)",onClick:k},[oe(de,{name:"window"}),L[1]||(L[1]=h("span",null,"独立窗口",-1))]),he(u).enableWebServeJump?(J(),ee("button",{key:1,class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"在系统默认浏览器中打开 (外跳)",onClick:S},[oe(de,{name:"external-link"}),L[2]||(L[2]=h("span",null,"外跳",-1))])):Te("",!0)])]),h("div",{ref_key:"mountEl",ref:d,class:Ce(["spm-protyle-mount",{"is-focus-mode":r.value&&!l.value}]),onClick:A},null,2)]))}}),gm=ii(mm,[["__scopeId","data-v-0d6e2df3"]]),vm=/^(https?|file|data|blob|mailto|tel|ftp|ftps|siyuan|about|chrome|ws|wss):/i,bm=/\.(html?|xhtml|pdf|png|jpe?g|gif|svg|webp|avif|ico|mp4|webm|mov|mp3|wav|m4a|ogg|json|md|markdown|txt|csv|zip|tar|gz|7z|rar|js|mjs|css|xml|yaml|yml|toml|ipynb|docx?|xlsx?|pptx?)$/i;function da(e){let t=e||"";try{t=decodeURIComponent(t)}catch{}t=t.replace(/\\/g,"/");const i=/(?:^|\/)data\/assets\/(.+)$/i.exec(t);if(i)return`/assets/${i[1]}`;const n=/(?:^|\/)data\/plugins\/(.+)$/i.exec(t);return n?`/plugins/${n[1]}`:null}function Gl(e){const t=(e||"").replace(/^file:\/\//i,"");let i=t;try{i=decodeURIComponent(t)}catch{}if(i.startsWith("/"))return/^\/([a-zA-Z]:[\\/])/.exec(i)?i.slice(1):i;const n=i.indexOf("/");return n>=0?i.slice(n):i}function ym(e){const t=e.split(/[/?#]/)[0];return!t||bm.test(t)?!1:/^(localhost|\d{1,3}(\.\d{1,3}){3})(:\d+)?$/i.test(t)?!0:/^[a-z0-9-]+(\.[a-z0-9-]+)+(:\d+)?$/i.test(t)}function km(e){const t=e.indexOf("#"),i=t>=0?e.slice(t):"",n=t>=0?e.slice(0,t):e,s=n.indexOf("?"),o=s>=0?n.slice(0,s):n,a=s>=0?n.slice(s+1):"";if(!/^\/?assets\/.+\.html?$/i.test(o))return e;const r=new URLSearchParams(a);return r.get("iframe")==="true"||r.get("download")==="true"?e:(r.set("iframe","true"),`${o}?${r.toString()}${i}`)}function Kl(e){const t=wm(e);return t.external||!t.url?t:{url:km(t.url),external:!1}}function wm(e){const t=(e||"").trim();if(!t)return{url:"",external:!1};if(/^https?:\/\//i.test(t))return{url:t,external:!1};if(t.startsWith("//"))return{url:`https:${t}`,external:!1};if(/^(siyuan|data|blob|about):/i.test(t))return{url:t,external:!1};if(Ea(t))return{url:`/${Aa(t)}`,external:!1};if(/^file:/i.test(t)){const n=da(Gl(t));return n?{url:n,external:!1}:{url:t,external:!0}}if(/^[a-zA-Z]:[\\/]/.test(t)||t.startsWith("\\\\")){const n=da(t);return n?{url:n,external:!1}:{url:t,external:!0}}return vm.test(t)?{url:t,external:!0}:ym(t)?{url:`https://${t}`,external:!1}:{url:`/${t.replace(/^(?:\.{1,2}\/)+/,"").replace(/^\/+/,"")}`,external:!1}}const xm={class:"spm-webview-drawer"},Sm={class:"spm-webview-toolbar"},Cm={class:"spm-webview-toolbar__nav"},_m=["disabled"],$m=["disabled"],Im=["aria-label"],Mm={class:"spm-webview-toolbar__address"},Tm=["aria-label"],Em={class:"spm-webview-toolbar__actions"},Am=["aria-label"],Bm={class:"spm-zoom-controller"},Dm=["disabled"],Lm=["disabled"],Pm={key:1,class:"spm-webview-fallback"},Om=["src"],Rm={key:2,class:"spm-load-error"},Nm={class:"spm-load-error__code"},zm={class:"spm-load-error__code-num"},Hm={class:"spm-load-error__url"},Fm={class:"spm-load-error__hint"},jm={class:"spm-load-error__actions"},ua="Mozilla/5.0 (iPhone; CPU iPhone OS 17_4_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.4.1 Mobile/15E148 Safari/604.1",ql="siyuan-slides-peek-view-mode";let Yl="desktop";function Wm(){if(typeof window<"u"&&window.localStorage)try{const e=window.localStorage.getItem(ql);if(e==="mobile"||e==="desktop")return e}catch{}return Yl}function Um(e){if(Yl=e,typeof window<"u"&&window.localStorage)try{window.localStorage.setItem(ql,e)}catch{}}function Vm(e){switch((e||"").toUpperCase()){case"ERR_PROXY_CONNECTION_FAILED":return"无法连接到代理服务器：请在思源「设置 → 网络代理」中填写公司代理地址，或切换为「使用系统代理」。";case"ERR_TUNNEL_CONNECTION_FAILED":return"HTTPS 代理隧道建立失败：请将思源「网络代理」的类型设为 HTTPS 并确认地址正确。";case"ERR_MANDATORY_PROXY_CONFIGURATION_FAILED":return"强制代理配置获取失败：公司 PAC 脚本不可用，请在思源「网络代理」中改为手动填写代理地址。";case"ERR_NAME_NOT_RESOLVED":case"ERR_NAME_RESOLUTION_FAILED":return"域名解析失败：内网环境访问外网通常需要配置代理或 DNS。";case"ERR_INTERNET_DISCONNECTED":return"当前网络不可用：请检查网络连接。";case"ERR_CONNECTION_TIMED_OUT":case"ERR_TIMED_OUT":return"连接超时：该地址可能需要通过代理才能访问。";case"ERR_CONNECTION_REFUSED":return"连接被拒绝：目标服务未在监听，或思源本地内核尚未启动。";case"ERR_CERT_AUTHORITY_INVALID":case"ERR_CERT_COMMON_NAME_INVALID":case"ERR_CERT_DATE_INVALID":return"证书校验失败：若公司网络使用 TLS 拦截，需将根证书导入思源所用系统的证书库。";default:return"若处于公司内网，请优先检查思源「设置 → 网络代理」是否已配置为可用代理（支持「使用系统代理」）。"}}const Gm=Dt({__name:"WebviewPeekDrawer",props:{url:{},title:{},visible:{type:Boolean,default:!0}},emits:["external-jump"],setup(e,{emit:t}){const i=t,n=e,s=ge(Wl()&&!kp()),o=ge(n.url),a=ge(n.url),r=n.url,l=ge(!1),c=ge(null),u=ge(!1),f=ge(!1),d=ge(1),p=ge(!1),w=ge(Wm());let m=typeof navigator<"u"&&!navigator.userAgent.includes("iPhone")?navigator.userAgent:"";const b=ye(()=>w.value==="mobile"?ua:m||void 0),y=ge(null),v=ge(null);let k=null,S=null,B=null;Vi(()=>n.url,X=>{X&&X!==o.value&&(o.value=X,a.value=X,w.value==="mobile"&&N(!1),y.value&&typeof y.value.loadURL=="function"&&y.value.loadURL(X))}),Vi(()=>n.visible,X=>{if(X)ce(),w.value==="mobile"&&N(!1);else if(y.value)try{typeof y.value.stop=="function"&&y.value.stop()}catch{}}),bn(()=>{A(),v.value&&typeof ResizeObserver<"u"&&(k=new ResizeObserver(()=>{const X=y.value;if(X&&typeof X.invalidate=="function")try{X.invalidate()}catch{}}),k.observe(v.value)),S=X=>{var E;const pe=X.message||((E=X.error)==null?void 0:E.message);if(typeof pe=="string"&&pe.includes("Invalid guestInstanceId"))return X.preventDefault(),X.stopImmediatePropagation(),!0},window.addEventListener("error",S,!0),B=X=>{const pe=X.reason,E=typeof pe=="string"?pe:pe==null?void 0:pe.message;typeof E=="string"&&E.includes("Invalid guestInstanceId")&&X.preventDefault()},window.addEventListener("unhandledrejection",B)}),rr(()=>{if(C(),k&&(k.disconnect(),k=null),S&&(window.removeEventListener("error",S,!0),S=null),B&&(window.removeEventListener("unhandledrejection",B),B=null),y.value)try{typeof y.value.stop=="function"&&y.value.stop()}catch{}});function A(){const X=y.value;X&&(X.addEventListener("dom-ready",L),X.addEventListener("did-start-loading",K),X.addEventListener("did-stop-loading",x),X.addEventListener("did-navigate",q),X.addEventListener("did-navigate-in-page",O),X.addEventListener("new-window",$),X.addEventListener("did-fail-load",_),X.addEventListener("did-fail-provisional-load",_))}function C(){const X=y.value;if(X)try{X.removeEventListener("dom-ready",L),X.removeEventListener("did-start-loading",K),X.removeEventListener("did-stop-loading",x),X.removeEventListener("did-navigate",q),X.removeEventListener("did-navigate-in-page",O),X.removeEventListener("new-window",$),X.removeEventListener("did-fail-load",_),X.removeEventListener("did-fail-provisional-load",_)}catch{}}function L(){const X=y.value;if(X&&typeof X.getUserAgent=="function"&&!m)try{const pe=X.getUserAgent();pe&&!pe.includes("iPhone")&&(m=pe)}catch{}w.value==="mobile"&&N(!1),ce(),T()}function z(){const X=w.value==="mobile"?"desktop":"mobile";w.value=X,Um(X),N(!0)}function N(X=!1){const pe=y.value;if(!pe)return;const E=w.value==="mobile"?ua:m;if(typeof pe.setUserAgent=="function"&&E)try{pe.setUserAgent(E)}catch(F){console.warn("[WebviewPeekDrawer] setUserAgent error:",F)}if(X&&typeof pe.reload=="function")try{pe.reload()}catch(F){console.warn("[WebviewPeekDrawer] reload error:",F)}}function K(){l.value=!0,c.value=null}function _(X){if(X&&X.isMainFrame===!1||X&&Number(X.errorCode)===-3)return;const pe=String((X==null?void 0:X.errorDescription)||"ERR_FAILED");c.value={errorCode:Number((X==null?void 0:X.errorCode)??0),description:pe,validatedURL:String((X==null?void 0:X.validatedURL)||o.value),hint:Vm(pe)},l.value=!1}function U(){c.value=null,V()}function x(){if(l.value=!1,T(),y.value&&typeof y.value.getURL=="function"){const X=y.value.getURL();X&&X!=="about:blank"&&(o.value=X,a.value=X)}}function q(X){X!=null&&X.url&&(o.value=X.url,a.value=X.url),T()}function O(X){X!=null&&X.url&&(o.value=X.url,a.value=X.url),T()}function $(X){X&&X.url&&(X.preventDefault(),y.value&&typeof y.value.loadURL=="function"&&y.value.loadURL(X.url))}function T(){const X=y.value;X&&(typeof X.canGoBack=="function"&&(u.value=X.canGoBack()),typeof X.canGoForward=="function"&&(f.value=X.canGoForward()))}function P(){y.value&&typeof y.value.goBack=="function"&&y.value.goBack()}function se(){y.value&&typeof y.value.goForward=="function"&&y.value.goForward()}function V(){y.value&&typeof y.value.reload=="function"&&y.value.reload()}function Y(){const X=Kl(a.value);if(X.url){if(X.external){o.value=X.url,fe();return}o.value=X.url,a.value=X.url,y.value&&typeof y.value.loadURL=="function"&&y.value.loadURL(X.url)}}function ce(){const X=y.value;if(X&&typeof X.setZoomFactor=="function")try{X.setZoomFactor(d.value)}catch(pe){console.warn("[WebviewPeekDrawer] setZoomFactor error:",pe)}}function ie(){d.value=Math.min(2.5,Math.round((d.value+.1)*10)/10),ce()}function re(){d.value=Math.max(.5,Math.round((d.value-.1)*10)/10),ce()}function Se(){d.value=1,ce()}function Ie(X){X.preventDefault(),X.deltaY<0?ie():X.deltaY>0&&re()}async function _e(){if(typeof navigator<"u"&&navigator.clipboard)try{await navigator.clipboard.writeText(o.value),p.value=!0,setTimeout(()=>{p.value=!1},2e3)}catch(X){console.warn("Copy url failed:",X)}}function fe(){var pe;const X=o.value;if(typeof window<"u"){const E=Tt("electron");(pe=E==null?void 0:E.shell)!=null&&pe.openExternal?E.shell.openExternal(X).catch(()=>{window.open(X,"_blank")}):window.open(X,"_blank")}i("external-jump",X)}return(X,pe)=>{const E=Tu("webview");return J(),ee("div",xm,[h("div",Sm,[h("div",Cm,[h("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s",disabled:!u.value,"aria-label":"后退",onClick:P},[oe(de,{name:"arrow-left"})],8,_m),h("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s",disabled:!f.value,"aria-label":"前进",onClick:se},[oe(de,{name:"arrow-right"})],8,$m),h("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":l.value?"正在加载...":"刷新页面",onClick:V},[oe(de,{name:"refresh"})],8,Im)]),h("div",Mm,[Ot(h("input",{"onUpdate:modelValue":pe[0]||(pe[0]=F=>a.value=F),type:"text",class:"b3-text-field spm-url-input",placeholder:"https://...",spellcheck:"false",onKeydown:Vf(Y,["enter"])},null,544),[[Ro,a.value]]),h("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":p.value?"已复制地址！":"复制网址",onClick:_e},[oe(de,{name:"copy"})],8,Tm)]),h("div",Em,[h("button",{class:Ce(["spm-icon-btn spm-mode-toggle b3-tooltips b3-tooltips__s",{"is-active":w.value==="mobile"}]),"aria-label":w.value==="mobile"?"当前为手机视图，点击切换为桌面视图":"当前为桌面视图，点击切换为手机视图",onClick:z},[oe(de,{name:w.value==="mobile"?"mobile":"desktop"},null,8,["name"])],10,Am),h("div",Bm,[h("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"缩小 (Ctrl + -)",disabled:d.value<=.5,onClick:re},[oe(de,{name:"minus"})],8,Dm),h("button",{class:"spm-zoom-badge b3-tooltips b3-tooltips__s","aria-label":"重置 100% (Ctrl + 0)",onClick:Se},we(Math.round(d.value*100))+"% ",1),h("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"放大 (Ctrl + +)",disabled:d.value>=2.5,onClick:ie},[oe(de,{name:"plus"})],8,Lm)]),h("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"在系统默认浏览器中打开 ↗",onClick:fe},[oe(de,{name:"external-link"}),pe[1]||(pe[1]=h("span",null,"外跳",-1))])])]),h("div",{ref_key:"containerEl",ref:v,class:Ce(["spm-webview-body",{"is-mobile":w.value==="mobile"}]),onWheel:Zt(Ie,["ctrl"])},[h("div",{class:Ce(["spm-webview-viewport",{"is-mobile":w.value==="mobile"}])},[s.value?(J(),Jt(E,{key:0,ref_key:"webviewRef",ref:y,class:"spm-webview-frame",src:he(r),useragent:b.value,allowpopups:"true",style:{position:"absolute",top:"0",left:"0",width:"100%",height:"100%",display:"inline-flex"}},null,8,["src","useragent"])):(J(),ee("div",Pm,[h("iframe",{class:"spm-webview-fallback-frame",src:o.value,frameborder:"0",sandbox:"allow-scripts allow-same-origin allow-forms allow-popups"},null,8,Om),h("div",{class:"spm-fallback-bar"},[pe[2]||(pe[2]=h("span",null,"如页面受同源策略 (X-Frame-Options) 拦截无法显示，请",-1)),h("button",{class:"spm-icon-btn is-primary",onClick:fe}," 在新标签页中打开 ↗ ")])])),c.value?(J(),ee("div",Rm,[oe(de,{name:"alert",class:"spm-load-error__icon"}),pe[5]||(pe[5]=h("div",{class:"spm-load-error__title"},"页面加载失败",-1)),h("div",Nm,[It(we(c.value.description)+" ",1),h("span",zm,"("+we(c.value.errorCode)+")",1)]),h("div",Hm,we(c.value.validatedURL),1),h("p",Fm,we(c.value.hint),1),h("div",jm,[h("button",{class:"spm-icon-btn","aria-label":"重试",onClick:U},[oe(de,{name:"refresh"}),pe[3]||(pe[3]=h("span",null,"重试",-1))]),h("button",{class:"spm-icon-btn is-primary","aria-label":"用系统浏览器打开",onClick:fe},[oe(de,{name:"external-link"}),pe[4]||(pe[4]=h("span",null,"用系统浏览器打开 ↗",-1))])])])):Te("",!0)],2)],34)])}}}),Km=ii(Gm,[["__scopeId","data-v-6e363f73"]]);class qm{constructor(){be(this,"timers",new Map)}debounce(t,i,n=150){this.cancel(t);const s=setTimeout(()=>{this.timers.delete(t),i()},n);this.timers.set(t,s)}cancel(t){this.timers.has(t)&&(clearTimeout(this.timers.get(t)),this.timers.delete(t))}cancelAll(){for(const t of this.timers.values())clearTimeout(t);this.timers.clear()}hasPending(t){return this.timers.has(t)}}class Ym{constructor(t){be(this,"blockToPageMap",new Map);be(this,"debounceCtrl",new qm);be(this,"activeBlockId","");be(this,"activePageIndex",1);be(this,"currentDocId","");be(this,"bridge",null);t&&(this.bridge=t)}setBridge(t){this.bridge=t}setDocId(t){this.currentDocId=t}updateSlidesIndex(t){this.blockToPageMap.clear();for(const i of t){i.startBlockId&&this.blockToPageMap.set(i.startBlockId,i.pageIndex);for(const n of i.blocks)this.blockToPageMap.set(n.id,i.pageIndex)}}getPageByBlockId(t){return this.blockToPageMap.get(t)??null}onCursorFocusBlock(t){if(!t||t===this.activeBlockId)return;this.activeBlockId=t;let i=this.getPageByBlockId(t);!i&&(t===this.currentDocId||!this.currentDocId&&this.blockToPageMap.size>0)&&(i=1),i&&this.debounceCtrl.debounce("cursor-navigate",()=>{this.activePageIndex=i,this.bridge&&(this.bridge.navigatePage(i),this.bridge.highlightElement(t))},100)}getActiveBlockId(){return this.activeBlockId}setActiveBlockId(t){this.activeBlockId=t,t||this.debounceCtrl.cancel("cursor-navigate");const i=this.getPageByBlockId(t);i&&(this.activePageIndex=i)}getActivePageIndex(){return this.activePageIndex}destroy(){this.debounceCtrl.cancelAll(),this.blockToPageMap.clear(),this.bridge=null}}let At=null,hs=null,ms="";function Nn(){var e,t;if(hs&&(clearTimeout(hs),hs=null),At){try{At.classList.remove("protyle-wysiwyg--select"),ms?At.style.outline=ms:typeof((e=At.style)==null?void 0:e.removeProperty)=="function"?At.style.removeProperty("outline"):At.style&&(At.style.outline=""),typeof((t=At.style)==null?void 0:t.removeProperty)=="function"?At.style.removeProperty("transition"):At.style&&(At.style.transition="")}catch(i){console.warn("[SelectionMirror] clear activeHighlightEl failed:",i)}At=null,ms=""}if(typeof document<"u"&&typeof document.querySelectorAll=="function")try{document.querySelectorAll(".protyle-wysiwyg [data-node-id].protyle-wysiwyg--select, .protyle-wysiwyg [data-node-id][style*='outline']").forEach(n=>{var o,a;n.classList.remove("protyle-wysiwyg--select");const s=((o=n.style)==null?void 0:o.outline)||"";(s.includes("#3b82f6")||s.includes("rgb(59, 130, 246)")||s.includes("59, 130, 246"))&&(typeof((a=n.style)==null?void 0:a.removeProperty)=="function"?(n.style.removeProperty("outline"),n.style.removeProperty("transition")):n.style&&(n.style.outline="",n.style.transition=""))})}catch{}}function Gi(e,t){var a,r,l,c;if(!e||typeof document>"u")return Nn(),!1;Nn();const i=(a=globalThis.CSS)!=null&&a.escape?globalThis.CSS.escape(e):e.replace(/"/g,'\\"'),n=document.querySelector(`.protyle-wysiwyg [data-node-id="${i}"]`)||document.querySelector(`[data-node-id="${i}"]`);if(!n){if(t)try{return ae.openTab({app:t,doc:{id:e,action:["cb-get-hl","cb-get-focus","cb-get-context"]}}),!0}catch(u){console.warn("[SelectionMirror] openTab fallback failed:",u)}return!1}try{n.scrollIntoView({behavior:"smooth",block:"center",inline:"nearest"})}catch{(r=n.scrollIntoView)==null||r.call(n)}try{(l=n.focus)==null||l.call(n,{preventScroll:!0})}catch{}const s=((c=n.style)==null?void 0:c.outline)||"";return ms=s.includes("#3b82f6")||s.includes("rgb(59, 130, 246)")||s.includes("59, 130, 246")?"":s,n.classList.add("protyle-wysiwyg--select"),n.style&&(n.style.outline="2px solid #3b82f6",n.style.transition="outline 0.2s ease"),At=n,hs=setTimeout(()=>{Nn()},500),!0}function Zm(e){if(!e)return"";const t=e.split(`
`).map(a=>a.trim()).filter(Boolean);if(t.length===0)return"";if(!t.some(a=>/^#{1,6}\s+/.test(a)))return t.map(a=>rt(a)).join("<br/>");const n=[];let s=[];const o=()=>{if(s.length>0){const a=s.map(r=>rt(r)).join("<br/>");n.push(`<p class="slide-list-item-desc">${a}</p>`),s=[]}};for(const a of t){const r=a.match(/^(#{1,6})\s+(.*)$/);if(r){o();const l=r[1].length,c=r[2].trim();n.push(`<h${l} class="slide-list-item-title">${rt(c)}</h${l}>`)}else s.push(a)}return o(),n.join(`
`)}function Jm(e){if(e.length===0)return"";const t=[],i=e[0],n=i.match(/^(#{1,6})\s+(.*)$/);if(n){const s=n[1].length,o=n[2].trim();t.push(`<h${s} class="slide-list-item-title">${rt(o)}</h${s}>`)}else t.push(`<p class="slide-list-item-title">${rt(i)}</p>`);if(e.length>1){const s=e.slice(1);let o=[];const a=()=>{if(o.length>0){const r=o.map(l=>rt(l)).join("<br/>");t.push(`<p class="slide-list-item-desc">${r}</p>`),o=[]}};for(const r of s){const l=r.match(/^(#{1,6})\s+(.*)$/);if(l){a();const c=l[1].length,u=l[2].trim();t.push(`<h${c} class="slide-list-item-title">${rt(u)}</h${c}>`)}else o.push(r)}a()}return t.join(`
`)+(t.length>0?`
`:"")}function Zl(e,t,i){var d,p,w,m;const n=e.split(`
`);if(!n.some(b=>/^(\s*)([-*+]|\d+\.)\s+/.test(b)))return(i!=null&&i.isListItem||(i==null?void 0:i.type)==="i")&&!(i!=null&&i.isColFirst)?`<ul class="slide-list slide-list--unordered">
<li class="slide-list-item">${rt(e)}</li>
</ul>`:null;const o=[],a=[];let r=!1;for(let b=0;b<n.length;b++){const y=n[b];if(!y.trim())continue;const v=y.match(/^(\s*)[-*+]\s+\[([ xX])\]\s+(.*)$/);if(v){const A=v[1].length,C=Math.floor(A/2);a.push({type:"task",level:C,checked:v[2].toLowerCase()==="x",text:v[3],media:[]});continue}const k=y.match(/^(\s*)[-*+]\s+(.*)$/);if(k){const A=k[1].length,C=Math.floor(A/2);a.push({type:"unordered",level:C,text:k[2],media:[]});continue}const S=y.match(/^(\s*)\d+\.\s+(.*)$/);if(S){a.length===0&&(r=!0);const A=S[1].length,C=Math.floor(A/2);a.push({type:"ordered",level:C,text:S[2],media:[]});continue}const B=y.trim();if(!(!B||/^\{:.*?\}$/.test(B)))if(a.length>0){const A=B.match(/^!\[(.*?)\]\((.*?)\)(?:\{:?[^}]*\})?$/);if(A){const z=/\.gif(?:\?|$)/i.test(A[2])?"list-item-gif":"list-item-img";a[a.length-1].media||(a[a.length-1].media=[]),a[a.length-1].media.push(`<div class="slide-list-media"><img alt="${ot(A[1])}" src="${A[2]}" class="${z}" /></div>`);continue}if(B.match(/^<img\b[\s\S]*?\/?>$/i)){const L=B.replace(/\s+style="[^"]*"/gi,"");a[a.length-1].media||(a[a.length-1].media=[]),a[a.length-1].media.push(`<div class="slide-list-media">${L}</div>`);continue}if(/<video\b/i.test(B)){let L=B;if(!/<\/video>/i.test(L))for(;b+1<n.length&&!/<\/video>/i.test(L);)b++,L+=" "+n[b].trim();const z=((d=i==null?void 0:i.attributes)==null?void 0:d["custom-slides-autoplay"])==="true"||/autoplay/i.test(L),N=((p=i==null?void 0:i.attributes)==null?void 0:p["custom-slides-loop"])==="true"||/loop/i.test(L),K=((w=i==null?void 0:i.attributes)==null?void 0:w["custom-slides-muted"])==="true"||z||/muted/i.test(L),_=((m=i==null?void 0:i.attributes)==null?void 0:m["custom-slides-controls"])==="false",U=L.match(/\bsrc=["']([^"']+)["']/i),x=U?U[1]:"",q=['class="slide-video-player"'];_||q.push("controls"),z&&(q.push("autoplay"),q.push("playsinline")),N&&q.push("loop"),K&&q.push("muted"),q.push('preload="metadata"'),x&&q.push(`src="${x}"`);const O=L.match(/<video[^>]*>([\s\S]*?)<\/video>/i);let $=O?O[1].trim():"";!$&&x&&($=`<source src="${x}" type="video/mp4" />您的浏览器不支持视频播放。`),a[a.length-1].media||(a[a.length-1].media=[]),a[a.length-1].media.push(`<div class="slide-list-media slide-video-container slide-media-container" data-autoplay="${z?"true":"false"}" data-muted="${K?"true":"false"}"><video ${q.join(" ")}>${$}</video></div>`);continue}a[a.length-1].text+=`
`+B}else o.push(B)}if(a.length===0)return null;const l=r?"ol":"ul",c=(t==null?void 0:t.listClassName)||(r?"pdf-list pdf-list--ordered":"pdf-list pdf-list--unordered"),u=a.map(b=>{const y=Zm(b.text),v=b.media&&b.media.length>0?`
${b.media.join(`
`)}`:"",k=b.level||0,S=k>0?` style="margin-left:${(k*1.25).toFixed(2)}em;${b.type==="unordered"?`list-style-type:${k%2===1?"circle":"square"} !important;`:""}"`:"",B=k>0?" slide-list-item--nested":"";if(b.type==="task"){const C=b.checked?' checked=""':"";return`<li class="pdf-task-item${B}"${S}><label><input type="checkbox" disabled=""${C}/> <span>${y}</span></label>${v}</li>`}return`<li${B?` class="${B.trim()}"`:""}${S}>${y}${v}</li>`}).join(`
`);return`${Jm(o)}<${l} class="${c}">
${u}
</${l}>`}function Xm(e,t,i){const n=(t==null?void 0:t.containerClassName)||"pdf-block",s=e.split(/\r?\n/),o=[];let a=[];for(let c=0;c<s.length;c++){const u=s[c],f=u.trim();if(/^#{1,6}\s+/.test(f)){a.length>0&&(o.push(a.join(`
`)),a=[]),o.push(f);continue}if(!f){a.length>0&&(o.push(a.join(`
`)),a=[]);continue}if(/^!\[.*?\]\(.*?\)$/.test(f)){a.length>0&&(o.push(a.join(`
`)),a=[]),o.push(f);continue}if(/<video\b/i.test(f)){a.length>0&&(o.push(a.join(`
`)),a=[]);let d=f;if(!/<\/video>/i.test(d))for(;c+1<s.length&&!/<\/video>/i.test(d);)c++,d+=`
`+s[c];o.push(d);continue}a.push(u)}a.length>0&&o.push(a.join(`
`));let r=!0;return o.map(c=>{var w,m,b,y;const u=c.trim();if(!u)return"";const f=u.match(/^(#{1,6})\s+(.*)$/);if(f){r=!1;const v=f[1].length;return`<h${v} class="slide-list-item-title">${rt(f[2].trim())}</h${v}>`}const d=u.match(/^!\[(.*?)\]\((.*?)\)$/);if(d){const v=/\.gif(?:\?|$)/i.test(d[2]),k=(t==null?void 0:t.imageClassName)||(v?"list-item-gif":"pdf-image slide-media-img");return`<div class="${n} ${n}--image slide-media-block slide-media-container slide-list-media"><img alt="${ot(d[1])}" src="${d[2]}" class="${k}" /></div>`}if(/<video\b/i.test(u)){const v=((w=i==null?void 0:i.attributes)==null?void 0:w["custom-slides-autoplay"])==="true"||/autoplay/i.test(u),k=((m=i==null?void 0:i.attributes)==null?void 0:m["custom-slides-loop"])==="true"||/loop/i.test(u),S=((b=i==null?void 0:i.attributes)==null?void 0:b["custom-slides-muted"])==="true"||v||/muted/i.test(u),B=((y=i==null?void 0:i.attributes)==null?void 0:y["custom-slides-controls"])==="false",A=u.match(/\bsrc=["']([^"']+)["']/i),C=A?A[1]:"",L=['class="slide-video-player"'];B||L.push("controls"),v&&L.push("autoplay playsinline"),k&&L.push("loop"),S&&L.push("muted"),L.push('preload="metadata"'),C&&L.push(`src="${C}"`);const z=u.match(/<video[^>]*>([\s\S]*?)<\/video>/i);let N=z?z[1].trim():"";return!N&&C&&(N=`<source src="${C}" type="video/mp4" />您的浏览器不支持视频播放。`),`<div class="${n} ${n}--video slide-media-block slide-video-container slide-media-container" data-autoplay="${v?"true":"false"}" data-muted="${S?"true":"false"}"><video ${L.join(" ")}>${N}</video></div>`}const p=Zl(u,t,i);if(p)return r=!1,p;if(r){r=!1;const v=u.split(/\r?\n/).map(A=>A.trim()).filter(Boolean);if(v.length===1)return`<p class="slide-list-item-title">${rt(v[0])}</p>`;const k=v[0],B=v.slice(1).map(A=>rt(A)).join("<br/>");return`<p class="slide-list-item-title">${rt(k)}</p>
<p class="slide-list-item-desc">${B}</p>`}return`<p class="slide-list-item-desc">${rt(u)}</p>`}).filter(Boolean).join(`
`)}function po(e){if(!e)return!1;if(e.type==="h"||e.type==="NodeHeading")return!0;const t=(e.rawMarkdown||e.content||"").trim();return/^#{1,6}\s+/.test(t)}function Jl(e,t){var r,l,c,u,f,d,p,w;const i=((r=e.frontmatter)==null?void 0:r.layout)||"default",s=(e.blocks||[]).filter(m=>m.slot!=="slot-divider-right"),a=i==="cover"?null:s.find(po);if(i==="two-cols"){const m=s.some(K=>K.slot==="right");let b=[],y=[];if(m)b=s.filter(K=>K.slot!=="right"),y=s.filter(K=>K.slot==="right");else{const K=Math.ceil(s.length/2);b=s.slice(0,K),y=s.slice(K)}const v=K=>{const _=K.filter(U=>!!(U.rawMarkdown||U.content||"").trim());if(_.length>0){const U=_[0],x=(U.rawMarkdown||U.content||"").trim();(Ai(U)||/^(?:[-*+]|\d+\.)\s+/.test(x))&&(U.rawMarkdown=Pn(U.rawMarkdown||U.content||""),U.content=U.rawMarkdown)}};v(b),v(y);const k=b.map(K=>xi(K,t)).join(`
`),S=y.map(K=>xi(K,t)).join(`
`),B=(t==null?void 0:t.twoColsWrapperClass)||"pdf-two-cols-wrapper layout-two-cols-grid",A=(l=e.frontmatter)!=null&&l.layoutClass?` ${e.frontmatter.layoutClass}`:"",C=(t==null?void 0:t.leftColClass)||"pdf-col pdf-col--left",L=(t==null?void 0:t.rightColClass)||"pdf-col pdf-col--right",N=`style="grid-template-columns: ${uo((c=e.frontmatter)==null?void 0:c.layoutRatio,2)};"`;return`
      <div class="${B}${A}" ${N}>
        <div class="${C}">${k}</div>
        <div class="${L}">${S}</div>
      </div>
    `}if(i==="clover"||on(i)){const m=i==="clover";let b=[];const y=s.filter(q=>q.slot==="header");if(y.length>0)b=y;else if(s.length>0){const q=s.find(O=>O.type==="h"&&(!O.slot||O.slot==="default"));q&&(b=[q])}const v=s.filter(q=>!b.includes(q));let k=2;if(m)k=4;else if(i==="three-cols-header")k=3;else if(i==="two-cols-header")k=2;else{let q=0;for(const O of v){const $=(O.slot||"").match(/^col-(\d+)$/i);$&&(q=Math.max(q,parseInt($[1],10)))}if(q>=2)k=q;else if((u=e.frontmatter)!=null&&u.layoutRatio){const O=e.frontmatter.layoutRatio.trim();if(O.includes(":")){const $=O.split(":").map(T=>parseFloat(T.trim())).filter(T=>!isNaN(T)&&T>0);$.length>=2&&(k=$.length)}else{const $=O.split(/\s+/).filter(Boolean);$.length>=2&&(k=$.length)}}else v.length===1&&v[0].children&&v[0].children.length>=2&&(k=Math.min(6,v[0].children.length))}const S=jl(v,k),B=v.some(q=>q.slot&&/^(?:col-\d+|left|right)$/i.test(q.slot)),A=i==="clover"||i==="two-cols-header"||i==="three-cols-header"||on(i)&&B,C=q=>{const O=q.filter(T=>!!(T.rawMarkdown||T.content||"").trim());if(A&&O.length>0){const T=O[0],P=(T.rawMarkdown||T.content||"").trim();(Ai(T)||/^(?:[-*+]|\d+\.)\s+/.test(P))&&(T.rawMarkdown=Pn(T.rawMarkdown||T.content||""),T.content=T.rawMarkdown),T.isColFirst=!0}const $=A?O.find(po):null;return O.map(T=>xi(T,{...t,extraClassName:T===$?"slides-col-first-heading-block":""})).join(`
`)},L=b.find(po),z=b.map(q=>xi(q,{...t,extraClassName:q===L?"slides-page-first-heading-block":""})).join(`
`),N=m?"repeat(2, minmax(0, 1fr))":uo((f=e.frontmatter)==null?void 0:f.layoutRatio,k),K=m?`style="grid-template-columns: ${N}; grid-template-rows: repeat(2, minmax(0, 1fr));"`:`style="grid-template-columns: ${N};"`,_=[m?"layout-clover-container":"layout-cols-header-container",k===2?"layout-two-cols-header-container":"",k===3?"layout-three-cols-header-container":"",`layout-${i}-container`,A?"has-superblock-cols":""].filter(Boolean).join(" "),U=[m?"layout-clover-grid pdf-clover-wrapper":"layout-cols-wrapper layout-cols-grid",k===2?"pdf-two-cols-wrapper layout-two-cols-grid":"",k===3?"pdf-three-cols-wrapper layout-three-cols-grid":"",A?"has-superblock-cols":""].filter(Boolean).join(" "),x=S.map((q,O)=>{const $=O+1;return`<div class="${["pdf-col",k===2&&$===1?"pdf-col--left":"",k===2&&$===2?"pdf-col--right":"",`pdf-col--${$}`,`col-${$}`].filter(Boolean).join(" ")}">${C(q)}</div>`}).join(`
`);return`
      <div class="${_}">
        <div class="layout-header-section">${z}</div>
        <div class="${U}" ${K}>
          ${x}
        </div>
      </div>
    `}if(i==="image-right"||i==="image-left"){const m=i==="image-right",b=s.map(A=>xi(A,t)).join(`
`),y=((d=e.frontmatter)==null?void 0:d.image)||((p=e.frontmatter)==null?void 0:p.background)||"",v=`<div class="pdf-image-col" style="background-image:url('${ot(y)}');background-size:cover;background-position:center;background-repeat:no-repeat;width:100%;height:100%;position:relative;overflow:hidden;"><img src="${ot(y)}" style="width:100%;height:100%;object-fit:cover;object-position:center;display:block;" onerror="this.style.display='none'" alt="Slide cover" /></div>`,k=`<div class="pdf-content-col" style="padding:48px 56px;display:flex;flex-direction:column;justify-content:flex-start;height:100%;box-sizing:border-box;overflow-y:auto;">${b}</div>`,S=m?`${k}
${v}`:`${v}
${k}`;return`
      <div class="layout-image-cols-grid" style="display:grid;grid-template-columns:${uo((w=e.frontmatter)==null?void 0:w.layoutRatio,2)};grid-template-rows:100%;width:100%;height:100%;position:absolute;top:0;left:0;right:0;bottom:0;box-sizing:border-box;">
        ${S}
      </div>
    `}return i==="fact"?`<div class="layout-fact-container">${s.map(b=>xi(b,t)).join(`
`)}</div>`:i==="cover"?`<div class="layout-cover-container">${s.map(b=>xi(b,t)).join(`
`)}</div>`:s.map(m=>xi(m,{...t,extraClassName:m===a?"slides-page-first-heading-block":""})).join(`
`)}function ot(e){return e?e.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&#039;"):""}function Qm(e){if(!e||e.trim()===""||e.trim()==="all")return"all";const t=new Set,i=e.split("|");for(const n of i){const s=n.trim();if(s==="all")return"all";if(s.includes("-")){const[o,a]=s.split("-"),r=parseInt(o,10),l=parseInt(a,10);if(!isNaN(r)&&!isNaN(l))for(let c=Math.min(r,l);c<=Math.max(r,l);c++)t.add(c)}else{const o=parseInt(s,10);isNaN(o)||t.add(o)}}return t}const eg=new Set(["kbd","mark","sub","sup","span","a","br","b","i","u","s","del","em","strong","code","small","abbr","ruby","rt","rp","v-mark","img","video","source","picture"]);function rt(e){if(!e)return"";const t=Hl(e),i=[],n=t.replace(/<\/?([a-zA-Z0-9_-]+)(?:\s+[^<>]*)?\/?>/g,(o,a)=>{const r=a.toLowerCase();if(!eg.has(r)||/on\w+\s*=|javascript:/i.test(o))return o;if(r==="v-mark"){const l=o.match(/type=["']?([a-zA-Z-]+)["']?/),c=l?l[1]:"circle";return o.startsWith("</")?i.push("</mark>"):i.push(`<mark class="v-mark v-mark--${c}">`),`%%SAFE_HTML_${i.length-1}%%`}return i.push(o),`%%SAFE_HTML_${i.length-1}%%`});let s=ot(n);return s=s.replace(/\(\(([0-9a-zA-Z-]+)(?:\s*(?:&#039;([^&#]*)&#039;|&quot;([^&]*)&quot;|'([^']*)'|"([^"]*)"|([^\)]+?)))?\s*\)\)/g,(o,a,r,l,c,u,f)=>{const p=(r??l??c??u??f??"").trim()||`Ref(${a.slice(0,8)})`;return`<a href="siyuan://blocks/${a}" data-ref-id="${a}" class="slides-ref-tag">🔗 ${p}</a>`}),s=s.replace(/\$([^$\n]+)\$/g,'<span class="katex-inline font-math"><em>$1</em></span>'),s=s.replace(/!\[(.*?)\]\((.*?)\)/g,(o,a,r)=>{const c=/\.gif(?:\?|$)/i.test(r)?"slide-inline-img list-item-gif":"slide-inline-img";return`<img alt="${a}" src="${r}" class="${c}" />`}),s=s.replace(/\[(.*?)\]\((.*?)\)/g,(o,a,r)=>{if(r.startsWith("siyuan://blocks/")){const l=r.replace("siyuan://blocks/","").split("?")[0];return`<a href="${r}" data-ref-id="${l}" class="slides-ref-tag">🔗 ${a}</a>`}return`<a href="${r}" target="_blank" rel="noopener noreferrer" class="slides-link">${a}</a>`}),s=s.replace(/(^|[\s(])(siyuan:\/\/blocks\/([0-9a-zA-Z-]+)(?:\?[^\s\)]*)?)/g,(o,a,r,l)=>`${a}<a href="${r}" data-ref-id="${l}" class="slides-ref-tag">🔗 ${r}</a>`),s=s.replace(/\*\*(.*?)\*\*/g,"<strong>$1</strong>"),s=s.replace(/\*(.*?)\*/g,"<em>$1</em>"),s=s.replace(/~~(.*?)~~/g,"<del>$1</del>"),s=s.replace(/`([^`]+)`/g,"<code>$1</code>"),s=s.replace(/%%SAFE_HTML_(\d+)%%/g,(o,a)=>{const r=parseInt(a,10);return i[r]||""}),s}function tg(e,t="pdf-table"){if(e.length<2)return"";const i=e.map(l=>l.trim().replace(/^\|/,"").replace(/\|$/,"").split("|").map(c=>c.trim())),n=i[0];let s=[],o=1;e.length>=2&&i[1].every(l=>/^:?-+:?$/.test(l))&&(s=i[1].map(l=>l.startsWith(":")&&l.endsWith(":")?"center":l.endsWith(":")?"right":"left"),o=2);const a=`<thead><tr>${n.map((l,c)=>`<th${s[c]?` style="text-align: ${s[c]}"`:""}>${rt(l)}</th>`).join("")}</tr></thead>`,r=i.slice(o).map(l=>`<tr>${l.map((c,u)=>`<td${s[u]?` style="text-align: ${s[u]}"`:""}>${rt(c)}</td>`).join("")}</tr>`).join("");return`<table class="${t}">${a}<tbody>${r}</tbody></table>`}function ho(e){return String(e||"").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;")}function fa(e,t="ts"){if(!e)return"";if(e.trim().startsWith("//"))return`<span class="token-comment">${ho(e)}</span>`;const i=[];function n(o,a){return i.push(`<span class="${o}">${ho(a)}</span>`),`__TOK_${i.length-1}__`}let s=e.replace(/(['"`])(.*?)\1/g,(o,a,r)=>n("token-string",`${a}${r}${a}`));return s=s.replace(/\b(import|export|from|const|let|var|function|return|default|type|interface|class|new|async|await)\b/g,o=>n("token-keyword",o)),s=s.replace(/\b(computed|ref|number|string|boolean|void|Array)\b/g,o=>n("token-type",o)),s=s.replace(/\b(\d+)\b/g,o=>n("token-number",o)),s=ho(s),s=s.replace(/__TOK_(\d+)__/g,(o,a)=>i[parseInt(a,10)]||""),s}function ig(e,t){if(!e)return null;const i=e.frontmatter||{};if(i.hideInToc===!0||i.hideInToc==="true")return null;let n=(i.title||"").trim(),s=i.level?parseInt(i.level,10):0;if(!n){const o=e.blocks||[];for(const a of o){const l=(a.rawMarkdown||a.content||"").trim().match(/^(#{1,6})\s+(.*)$/);if(l){s||(s=l[1].length),n=l[2].trim();break}}}return n?((!s||isNaN(s))&&(s=1),{pageIndex:e.pageIndex||t,title:n,level:s}):null}function ng(e,t=1,i={}){const n=i.minDepth!==void 0?Number(i.minDepth):1,s=i.maxDepth!==void 0?Number(i.maxDepth):1/0,o=[];Array.isArray(e)&&e.forEach((c,u)=>{const f=ig(c,u+1);f&&o.push(f)});const a=[];let r=null;for(const c of o){const u={...c,active:c.pageIndex===t,hasActiveChild:!1,children:[]};c.level===1||a.length===0?(a.push(u),r=u):r?(u.active&&(r.hasActiveChild=!0),r.children.push(u)):a.push(u)}function l(c,u=1){if(u>s)return[];const f=[];for(const d of c){const p=l(d.children,u+1);u>=n?f.push({...d,children:p}):f.push(...p)}return f}return l(a,1)}function sg(e,t=1,i={}){const n=ng(e,t,i),s=i.columns?Number(i.columns):1,o=s>1?` style="column-count: ${s};"`:"",a=i.textSm?" text-sm":"";function r(c,u=1){if(!c||c.length===0)return"";const f=`slides-toc-list slides-toc-list-level-${u}`,d=c.map(p=>{const w=p.active?" slides-toc-item-active":p.hasActiveChild?" slides-toc-item-parent-active":"",m=p.children&&p.children.length>0?r(p.children,u+1):"";let b=rt(p.title);return b.includes("LaTeX")&&(b=b.replace(/\$\\LaTeX\$/g,'<span class="font-math">L<sup>A</sup>T<sub>E</sub>X</span>')),`
        <li class="slides-toc-item${w}" data-page="${p.pageIndex}">
          <a class="slides-toc-link" href="javascript:void(0)">
            <span class="slides-toc-title">${b}</span>
          </a>
          ${m}
        </li>
      `}).join("");return`<ol class="${f}">${d}</ol>`}const l=r(n,1);return`<div class="slides-toc${a}"${o}>${l}</div>`}function xi(e,t){var B,A,C,L,z,N,K,_,U,x,q,O;let i="",n="",s="";const o=[];(B=e.motion)!=null&&B.preset&&e.motion.preset!=="none"&&(i=` slides-motion-${e.motion.preset.toLowerCase()}`,typeof e.motion.duration=="number"&&e.motion.duration>0&&o.push(`--motion-duration:${e.motion.duration}ms`),typeof e.motion.delay=="number"&&e.motion.delay>0&&o.push(`--motion-delay:${e.motion.delay}ms`));const a=((A=e.attributes)==null?void 0:A.style)||"";a&&(o.push(a),s=" slide-styled-block"),o.length>0&&(n=` style="${ot(o.join(";"))}"`);const r=(t==null?void 0:t.containerClassName)||"pdf-block",l=t!=null&&t.extraClassName?` ${t.extraClassName}`:"",c=t!=null&&t.blockClassResolver?t.blockClassResolver(e):"",u=c?` ${c}`:"",f=`${r}${i}${s}${l}${u}`,d=(e.rawMarkdown||e.content||"").trim();if(!d)return`<div class="${f}"${n}></div>`;if(d.includes('class="slides-block-ref"')||d.includes('class="slides-ref-tag"'))return`<div class="${f}"${n}>${d}</div>`;if(d.startsWith("$$")&&d.endsWith("$$")){const $=d.slice(2,-2).trim();return`<div class="${f} katex-display-container"${n}><div class="katex-display font-math"><em>${ot($)}</em></div></div>`}const p=d.match(/^(#{1,6})\s+(.*)$/);if(p){const $=p[1].length,T=rt(p[2]),se=!!(e.isColFirst||e.type==="i"&&((C=t==null?void 0:t.extraClassName)!=null&&C.includes("slides-col-first-heading-block")))?' class="slide-list-item-title"':"";return`<div class="${f}"${n}><h${$}${se}>${T}</h${$}></div>`}if(d.startsWith(":::")){const $=d.split(`
`),P=$[0].replace(/^:::\s*/,"").trim()||"info",se=$.slice(1,$[$.length-1].startsWith(":::")?-1:void 0).join(`
`),V=(t==null?void 0:t.calloutClassName)||"pdf-callout";return`<div class="${f}"${n}><div class="${V} ${V}--${P}"><div class="${V}-title">${P.toUpperCase()}</div><div class="${V}-body">${rt(se)}</div></div></div>`}if(d.startsWith("<<<")){const P=`// Inside ./snippets/external.ts
export function emptyArray<T>(length: number) {
  return Array.from<T>({ length })
}`.split(`
`).map((ie,re)=>`<span class="code-line shiki-focus"><span class="line-no">${re+1}</span><span class="line-content">${fa(ie,"ts")}</span></span>`).join(`
`),se=(t==null?void 0:t.codeClassName)||"pdf-code shiki-container",V=((L=e.attrs)==null?void 0:L["custom-slides-max-height"])||((z=e.attributes)==null?void 0:z["custom-slides-max-height"])||e.maxHeight||"",Y=V?/^\d+$/.test(String(V).trim())?`${String(V).trim()}px`:String(V).trim():"",ce=Y?` style="max-height:${ot(Y)};overflow-y:auto;"`:"";return`<div class="${f}"${n}><pre class="${se}"${ce}><span class="lang-badge">TS</span><code>${P}</code></pre></div>`}if(d.startsWith("<style")||d.startsWith("<!-- Inline style -->")||d.startsWith(`<!--
Notes`))return"";if(d.startsWith("```")){const $=d.split(`
`),T=$[0].slice(3).trim(),P=T.match(/^([^\s{\[]+)/),se=P?P[1]:"",V=T.match(/\[([^\]]+)\]/),Y=V?V[1]:"",ce=T.includes("twoslash"),ie=e.shikiLines||((N=T.match(/\{([^}]+)\}/))==null?void 0:N[1])||"",re=Qm(ie),Se=$.length>2?$[$.length-1]==="```"?$.slice(1,-1):$.slice(1):[d.slice(3).replace(/```$/,"")],Ie=(t==null?void 0:t.codeClassName)||"pdf-code shiki-container",_e=Y?`${Ie} has-filename`:Ie,fe=re!=="all",X=Se.map((j,M)=>{const I=M+1,G=re==="all"||re.has(I)?"code-line shiki-focus":fe?"code-line shiki-dimmed":"code-line";let H=(t==null?void 0:t.highlight)===!0?fa(j,se):ot(j);return ce&&j.includes("doubled.value = 2")?(H=H.replace(/(\bvalue\b)/,'<span class="twoslash-error-wavy">$1</span>'),`<span class="${G}"><span class="line-no">${I}</span><span class="line-content">${H}</span></span>
<div class="twoslash-popup-error"><span style="color:#ef4444;font-weight:bold;margin-right:4px;">✕</span> Cannot assign to 'value' because it is a read-only property.</div>`):`<span class="${G}"><span class="line-no">${I}</span><span class="line-content">${H}</span></span>`}).join(`
`),pe=se?`<span class="lang-badge">${ot(se)}</span>`:"",E=Y?`<span class="code-filename">${ot(Y)}</span>`:"",F=((K=e.attrs)==null?void 0:K["custom-slides-max-height"])||((_=e.attributes)==null?void 0:_["custom-slides-max-height"])||e.maxHeight||"",g=F?/^\d+$/.test(String(F).trim())?`${String(F).trim()}px`:String(F).trim():"",W=g?` style="max-height:${ot(g)};overflow-y:auto;"`:"";return`<div class="${f}"${n}><pre class="${_e}"${W}>${E}${pe}<code>${X}</code></pre></div>`}if(d.includes("|")&&d.split(`
`).filter($=>$.trim().startsWith("|")).length>=2){const $=d.split(`
`).filter(P=>P.trim().startsWith("|")),T=tg($,t==null?void 0:t.tableClassName);return`<div class="${f}"${n}>${T}</div>`}if(d.startsWith("> ")){const $=(t==null?void 0:t.quoteClassName)||"pdf-quote";return`<div class="${f}"${n}><blockquote class="${$}"><p>${rt(d.slice(2))}</p></blockquote></div>`}const w=/<video\b/i.test(d)||e.type==="video"||e.type==="NodeVideo",m=/^(\s*)([-*+]|\d+\.)\s+/m.test(d),b=/(?:^|\n)\s*#{1,6}\s+/.test(d);if(w&&!m&&!b&&!d.includes(`
`)){const $=((U=e.attributes)==null?void 0:U["custom-slides-autoplay"])==="true"||/autoplay/i.test(d),T=((x=e.attributes)==null?void 0:x["custom-slides-loop"])==="true"||/loop/i.test(d),P=((q=e.attributes)==null?void 0:q["custom-slides-muted"])==="true"||$||/muted/i.test(d),se=((O=e.attributes)==null?void 0:O["custom-slides-controls"])==="false",V=d.match(/\bsrc=["']([^"']+)["']/i),Y=V?V[1]:"",ce=['class="slide-video-player"'];se||ce.push("controls"),$&&(ce.push("autoplay"),ce.push("playsinline")),T&&ce.push("loop"),P&&ce.push("muted"),ce.push('preload="auto"'),Y&&ce.push(`src="${Y}"`);const ie=d.match(/<video[^>]*>([\s\S]*?)<\/video>/i);let re=ie?ie[1].trim():"";return!re&&Y&&(re=`<source src="${Y}" type="video/mp4" />您的浏览器不支持视频播放。`),`<div class="${f} ${f}--video slide-media-block slide-video-container slide-media-container" data-autoplay="${$?"true":"false"}" data-muted="${P?"true":"false"}"${n}><video ${ce.join(" ")}>${re}</video></div>`}const y=d.match(/^!\[(.*?)\]\((.*?)\)$/);if(y){const $=(t==null?void 0:t.imageClassName)||"pdf-image slide-media-img";return`<div class="${f} ${f}--image slide-media-block slide-media-container"${n}><img alt="${ot(y[1])}" src="${y[2]}" class="${$}" /></div>`}const v=Zl(d,t,e);if(v)return`<div class="${f} pdf-list-item"${n}>${v}</div>`;if(/<(?:Toc|toc)\b/i.test(d)&&!d.startsWith("```")){const $=d.match(/minDepth=["']?(\d+)["']?/i),T=d.match(/maxDepth=["']?(\d+)["']?/i),P=d.match(/columns=["']?(\d+)["']?/i),se=(t==null?void 0:t.allSlides)||[];return`<div class="${f}"${n}>${sg(se,(t==null?void 0:t.currentPageIndex)||1,{minDepth:$?parseInt($[1],10):1,maxDepth:T?parseInt(T[1],10):1/0,columns:P?parseInt(P[1],10):1,textSm:d.includes("text-sm")})}</div>`}if(d.includes(`
`)||b){const $=Xm(d,t,e);if($)return`<div class="${f}"${n}>${$}</div>`}const S=!!e.isColFirst?' class="slide-list-item-title"':"";return`<div class="${f}"${n}><p${S}>${rt(d)}</p></div>`}function og(e){return`
    ${Rn(e)}

    :root {
      --slide-bg: #ffffff;
      --slide-text: #1a1a1a;
      --slide-accent: #3b82f6;
      --slide-font: system-ui, -apple-system, sans-serif;
    }
    [data-theme="dark"] {
      --slide-bg: #121214;
      --slide-text: #e2e8f0;
      --slide-accent: #60a5fa;
    }

    /* 1. 默认科技主题 Default */
    [data-slides-theme="default"],
    .slides-theme-default {
      --slide-font: system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "PingFang SC", "Microsoft YaHei", sans-serif;
      --slide-accent: #10b981;
    }
    [data-theme="light"][data-slides-theme="default"],
    [data-theme="light"] .slides-theme-default {
      --slide-bg: #ffffff;
      --slide-text: #1e293b;
      --slide-accent: #059669;
    }
    [data-theme="dark"][data-slides-theme="default"],
    [data-theme="dark"] .slides-theme-default {
      --slide-bg: #121214;
      --slide-text: #e2e8f0;
      --slide-accent: #34d399;
    }
    .slides-theme-default .layout-cover h1,
    .slides-theme-default .layout-cover .slide-block h1 {
      font-size: 3.8rem !important;
      font-weight: 800 !important;
      line-height: 1.15 !important;
      letter-spacing: -0.025em !important;
      margin-bottom: 18px !important;
      background: linear-gradient(135deg, #10b981, #06b6d4) !important;
      -webkit-background-clip: text !important;
      -webkit-text-fill-color: transparent !important;
    }
    .slides-theme-default .layout-cover h2,
    .slides-theme-default .layout-cover .slide-block h2 {
      font-size: 1.85rem !important;
      font-weight: 600 !important;
      opacity: 0.85 !important;
      margin-bottom: 12px !important;
    }
    .slides-theme-default .layout-cover p,
    .slides-theme-default .layout-cover .slide-block p {
      font-size: 1.45rem !important;
      line-height: 1.5 !important;
      opacity: 0.85 !important;
    }

    /* 2. 优雅衬线主题 Seriph */
    [data-slides-theme="seriph"],
    .slides-theme-seriph {
      --slide-font: "PT Serif", "Charter", "Georgia", "Cambria", "Times New Roman", "Source Han Serif SC", "Noto Serif SC", "Songti SC", "SimSun", serif;
      --slide-accent: #b45309;
      letter-spacing: 0.015em;
    }
    [data-theme="light"][data-slides-theme="seriph"],
    [data-theme="light"] .slides-theme-seriph {
      --slide-bg: #fdfbf7;
      --slide-text: #2a2521;
      --slide-accent: #b45309;
    }
    [data-theme="dark"][data-slides-theme="seriph"],
    [data-theme="dark"] .slides-theme-seriph {
      --slide-bg: #1c1a17;
      --slide-text: #e8e3d9;
      --slide-accent: #f59e0b;
    }
    .slides-theme-seriph,
    .slides-theme-seriph .slide-content {
      font-family: var(--slide-font) !important;
      line-height: 1.72;
    }
    .slides-theme-seriph h1,
    .slides-theme-seriph h2,
    .slides-theme-seriph h3 {
      font-family: var(--slide-font) !important;
      letter-spacing: 0.025em;
      font-weight: 700;
    }
    .slides-theme-seriph .layout-cover h1 {
      background: none !important;
      -webkit-background-clip: initial !important;
      -webkit-text-fill-color: initial !important;
      color: var(--slide-accent) !important;
      font-size: 3.4rem !important;
      border-bottom: 2px solid var(--slide-accent);
      display: inline-block;
      padding-bottom: 10px;
    }

    /* 3. 极简发布会主题 Apple Basic */
    [data-slides-theme="apple-basic"],
    .slides-theme-apple-basic {
      --slide-font: -apple-system, "SF Pro Display", "SF Pro Text", BlinkMacSystemFont, "PingFang SC", "Helvetica Neue", sans-serif;
      --slide-accent: #0071e3;
    }
    [data-theme="light"][data-slides-theme="apple-basic"],
    [data-theme="light"] .slides-theme-apple-basic {
      --slide-bg: #ffffff;
      --slide-text: #1d1d1f;
      --slide-accent: #0071e3;
    }
    [data-theme="dark"][data-slides-theme="apple-basic"],
    [data-theme="dark"] .slides-theme-apple-basic {
      --slide-bg: #000000;
      --slide-text: #f5f5f7;
      --slide-accent: #2997ff;
    }
    .slides-theme-apple-basic,
    .slides-theme-apple-basic .slide-content {
      font-family: var(--slide-font) !important;
    }
    .slides-theme-apple-basic h1,
    .slides-theme-apple-basic h2,
    .slides-theme-apple-basic h3 {
      letter-spacing: -0.035em;
      font-weight: 800;
    }
    .slides-theme-apple-basic .layout-cover h1 {
      background: none !important;
      -webkit-background-clip: initial !important;
      -webkit-text-fill-color: initial !important;
      color: var(--slide-text) !important;
      font-size: 3.8rem !important;
      letter-spacing: -0.04em !important;
    }
    .slides-theme-apple-basic .layout-cover p {
      color: #86868b !important;
      font-size: 1.35rem !important;
    }

    * { box-sizing: border-box; margin: 0; padding: 0; }
    html, body {
      width: 100%; height: 100%; overflow: hidden;
      background: #0f1115; font-family: var(--slide-font);
      display: flex; justify-content: center; align-items: center;
    }
    #app { width: 100%; height: 100%; position: relative; overflow: hidden; }
    .slide-viewport {
      position: absolute; left: 50%; top: 50%;
      background: var(--slide-bg); color: var(--slide-text);
      box-shadow: 0 10px 30px rgba(0,0,0,0.5); border-radius: 8px; overflow: hidden;
      display: flex; flex-direction: column; flex-shrink: 0;
      transform: translate(-50%, -50%) scale(var(--slides-slide-scale, 1));
      transform-origin: center center; will-change: transform;
      transition: background 0.3s ease, color 0.3s ease, border-radius 0.2s ease, box-shadow 0.2s ease;
    }
    :fullscreen .slide-viewport, .is-fullscreen .slide-viewport {
      border-radius: 0 !important; box-shadow: none !important;
    }
    .slide-content {
      position: relative;
      width: 100%;
      height: 100%;
      min-height: 100%;
      flex: 1 1 0%;
      padding: var(--slides-padding-y, 32px) var(--slides-padding-x, 48px);
      display: flex;
      flex-direction: column;
      overflow: hidden;
      box-sizing: border-box;
    }

    /* 间距预设风格 */
    .slide-content.spacing-compact,
    .slide-viewport[data-spacing="compact"] .slide-content,
    [data-slides-spacing="compact"] {
      --slides-padding-y: 20px;
      --slides-padding-x: 36px;
      --slides-header-gap: 10px;
      --slides-title-margin-bottom: 6px;
    }
    .slide-content.spacing-normal,
    .slide-viewport[data-spacing="normal"] .slide-content,
    [data-slides-spacing="normal"] {
      --slides-padding-y: 32px;
      --slides-padding-x: 48px;
      --slides-header-gap: 16px;
      --slides-title-margin-bottom: 10px;
    }
    .slide-content.spacing-loose,
    .slide-viewport[data-spacing="loose"] .slide-content,
    [data-slides-spacing="loose"] {
      --slides-padding-y: 48px;
      --slides-padding-x: 56px;
      --slides-header-gap: 24px;
      --slides-title-margin-bottom: 16px;
    }

    .layout-cover { justify-content: center; align-items: center; text-align: center; }
    .layout-cover h1, .layout-cover .slide-block h1 { font-size: 3.8rem !important; font-weight: 800 !important; line-height: 1.15 !important; letter-spacing: -0.025em !important; margin-bottom: 16px !important; }
    .layout-cover h2, .layout-cover .slide-block h2 { font-size: 1.85rem !important; font-weight: 600 !important; opacity: 0.85 !important; margin-bottom: 12px !important; }
    .layout-cover p, .layout-cover .slide-block p { font-size: 1.45rem !important; line-height: 1.5 !important; opacity: 0.85 !important; }
    .two-cols-left, .two-cols-right { min-width: 0; width: 100%; display: flex; flex-direction: column; box-sizing: border-box; overflow-wrap: break-word; word-break: break-word; }
    .pdf-two-cols-wrapper,
    .layout-two-cols-grid,
    .layout-cols-wrapper,
    .layout-cols-grid {
      display: grid;
      grid-template-columns: var(--slide-grid-cols, minmax(0, 1fr) minmax(0, 1fr));
      grid-template-rows: minmax(0, 1fr) !important;
      gap: 32px;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      overflow: hidden !important;
    }
    .layout-cols-header-container,
    .layout-two-cols-header-container,
    .layout-three-cols-header-container,
    .layout-clover-container {
      display: flex;
      flex-direction: column;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      overflow: hidden !important;
    }
    .layout-header-section {
      width: 100%;
      margin-bottom: var(--slides-header-gap, 16px) !important;
      flex-shrink: 0;
    }
    .layout-header-section h1,
    .layout-header-section h2,
    .layout-header-section h3 {
      margin-bottom: var(--slides-title-margin-bottom, 10px) !important;
    }
    .pdf-three-cols-wrapper,
    .layout-three-cols-grid {
      display: grid;
      grid-template-columns: var(--slide-grid-cols, minmax(0, 1fr) minmax(0, 1fr) minmax(0, 1fr));
      grid-template-rows: minmax(0, 1fr) !important;
      gap: 24px;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      box-sizing: border-box;
      overflow: hidden !important;
    }
    .pdf-clover-wrapper,
    .layout-clover-grid {
      display: grid;
      grid-template-columns: repeat(2, minmax(0, 1fr)) !important;
      grid-template-rows: repeat(2, minmax(0, 1fr)) !important;
      gap: 20px;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      box-sizing: border-box;
      overflow: hidden !important;
    }
    .layout-clover-grid .pdf-col {
      background: transparent !important;
      border: none !important;
      box-shadow: none !important;
    }
    .pdf-col {
      display: flex;
      flex-direction: column;
      gap: 14px;
      min-width: 0;
      width: 100%;
      max-width: 100%;
      height: 100%;
      max-height: 100%;
      min-height: 0;
      justify-content: flex-start;
      box-sizing: border-box;
      overflow: hidden;
      overflow-wrap: break-word;
      word-break: break-word;
      white-space: normal;
    }
    .pdf-col * {
      overflow-wrap: break-word;
      word-break: break-word;
      box-sizing: border-box;
    }
    /* 表头多栏内超级块子块首个列表项去圆点后居中显示标题/首行文本 (仅在存在超级块分栏时生效) */
    .has-superblock-cols .pdf-col > *:first-child .slide-list-item-title,
    .has-superblock-cols .pdf-col > *:first-child :is(h1, h2, h3, h4, h5, h6),
    .has-superblock-cols .pdf-col > *:first-child p.slide-list-item-title,
    .has-superblock-cols .pdf-col > *:first-child p:first-of-type,
    .has-superblock-cols .pdf-col > *:first-child p:first-child,
    .has-superblock-cols .pdf-col > *:first-child :is(ul, ol) > li:first-child,
    .has-superblock-cols .pdf-col > *:first-child .slide-list > .slide-list-item:first-child,
    .has-superblock-cols .pdf-col > *:first-child .pdf-list > li:first-child,
    .has-superblock-cols .slides-col-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    .has-superblock-cols .slides-col-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      list-style: none !important;
      list-style-type: none !important;
      text-align: center !important;
      margin-left: 0 !important;
      padding-left: 0 !important;
      width: 100% !important;
    }

    /* 彻底清除首个列表项的原生圆点 Marker (仅在存在超级块分栏时生效) */
    .has-superblock-cols .pdf-col > *:first-child :is(ul, ol) > li:first-child::marker {
      content: "" !important;
      display: none !important;
    }

    /* 确保首个列表项内部内联与块级元素居中 (仅在存在超级块分栏时生效) */
    .has-superblock-cols .pdf-col > *:first-child :is(ul, ol) > li:first-child * {
      text-align: center !important;
    }

    /* 栏内说明段落与列表项：左对齐，自然阅读排版 */
    .has-superblock-cols .pdf-col .slide-list-item-desc,
    .has-superblock-cols .pdf-col li:not(:first-child) {
      text-align: left !important;
    }

    /* 全局特定标题大小规范化 (除封面外页首首个标题按 H2 1.7rem，表头多栏内首个标题按 H3 1.3rem) */
    [data-normalize-headings="true"] .slides-page-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .slides-page-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .slide-content:not(.layout-cover) > :is(.pdf-block, .slide-block):first-child :is(h1, h2, h3, h4, h5, h6),
    [data-normalize-headings="true"] .slide-content:not(.layout-cover) > .layout-header-section :is(.pdf-block, .slide-block):first-child :is(h1, h2, h3, h4, h5, h6),
    [data-normalize-headings="true"] .slide-content:not(.layout-cover) > :not(.layout-cols-wrapper):not(.pdf-two-cols-wrapper):not(.layout-image-cols-grid):first-child :is(h1, h2, h3, h4, h5, h6) {
      font-size: 1.7rem !important;
      font-weight: 600 !important;
      line-height: 1.25 !important;
      margin-bottom: 10px !important;
    }

    [data-normalize-headings="true"] .has-superblock-cols .slides-col-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .has-superblock-cols .slides-col-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .has-superblock-cols .pdf-col > *:first-child :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      font-size: 1.3rem !important;
      font-weight: 600 !important;
      line-height: 1.3 !important;
      margin-bottom: 8px !important;
      text-align: center !important;
    }

    /* 图左与图右版式标题完全保留用户原始字号与默认排版，不进行任何固定大小规范化 */
    [data-normalize-headings="true"] :is(.layout-image-left, .layout-image-right, .image-left-content, .image-right-content) :is(h1, h2, h3, h4, h5, h6) {
      text-align: left !important;
    }
    .pdf-col pre,
    .two-cols-left pre,
    .two-cols-right pre,
    .image-right-content pre,
    .image-left-content pre {
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      overflow-x: hidden !important;
      overflow-y: auto !important;
      max-width: 100% !important;
      box-sizing: border-box !important;
    }
    .slide-content.layout-image-right, .slide-content.layout-image-left {
      padding: 0;
      display: grid;
      grid-template-columns: var(--slide-grid-cols, minmax(0, 1fr) minmax(0, 1fr));
      grid-template-rows: 100%;
      width: 100%;
      height: 100%;
      position: absolute;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      box-sizing: border-box;
    }
    .image-right-content, .image-left-content {
      padding: 44px 50px;
      display: flex;
      flex-direction: column;
      justify-content: flex-start;
      overflow-y: auto;
      width: 100%;
      height: 100%;
      box-sizing: border-box;
    }
    .image-right-img-container, .image-left-img-container {
      width: 100%;
      height: 100%;
      overflow: hidden;
      position: relative;
      background: #18181b;
      display: flex;
      align-items: center;
      justify-content: center;
    }
    .image-right-img, .image-left-img {
      width: 100%;
      height: 100%;
      object-fit: cover;
      object-position: center;
      display: block;
    }
    .slide-block { margin-bottom: 14px; line-height: 1.6; }
    .slide-block h1 { font-size: 2.2rem; margin-bottom: 12px; }
    .slide-block h2 { font-size: 1.7rem; margin-bottom: 10px; }
    .slide-block p { font-size: 1.15rem; }
    .slide-block ul, .slide-block ol, .pdf-list {
      padding-left: 28px;
      margin: 8px 0;
      display: flex;
      flex-direction: column;
      gap: 6px;
    }
    .slide-block li, .pdf-list li {
      font-size: 1.15rem;
      line-height: 1.6;
    }
    .pdf-task-item {
      list-style: none;
      margin-left: -20px;
      display: flex;
      align-items: center;
      gap: 8px;
    }
    .pdf-task-item input[type="checkbox"] {
      width: 1.15em;
      height: 1.15em;
      cursor: pointer;
    }

    /* 两栏与三栏及多栏（超级块分栏）布局：紧凑自然行距，子列表保留圆点与层级缩进 */
    .layout-two-cols ul,
    .layout-cols-header ul,
    .layout-two-cols-header ul,
    .layout-three-cols ul,
    .layout-three-cols-header ul,
    .two-cols-left ul,
    .two-cols-right ul,
    .three-cols-col ul,
    .col ul,
    .pdf-col ul,
    .layout-two-cols-grid .pdf-list,
    .layout-three-cols-grid .pdf-list,
    .layout-cols-grid .pdf-list,
    .layout-two-cols-grid .pdf-list--unordered,
    .layout-three-cols-grid .pdf-list--unordered,
    .layout-cols-grid .pdf-list--unordered {
      list-style: disc !important;
      list-style-type: disc !important;
      padding-left: 1.25em !important;
      margin-left: 0 !important;
      margin-top: 0 !important;
      margin-bottom: 8px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: block !important;
    }

    .layout-two-cols ol,
    .layout-cols-header ol,
    .layout-two-cols-header ol,
    .layout-three-cols ol,
    .layout-three-cols-header ol,
    .two-cols-left ol,
    .two-cols-right ol,
    .three-cols-col ol,
    .col ol,
    .pdf-col ol,
    .layout-two-cols-grid .pdf-list--ordered,
    .layout-three-cols-grid .pdf-list--ordered,
    .layout-cols-grid .pdf-list--ordered {
      list-style: decimal !important;
      list-style-type: decimal !important;
      padding-left: 1.25em !important;
      margin-left: 0 !important;
      margin-top: 0 !important;
      margin-bottom: 8px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: block !important;
    }

    .layout-two-cols li,
    .layout-cols-header li,
    .layout-two-cols-header li,
    .layout-three-cols li,
    .layout-three-cols-header li,
    .two-cols-left li,
    .two-cols-right li,
    .three-cols-col li,
    .col li,
    .pdf-col li,
    .pdf-col .pdf-list-item {
      padding-left: 0.2em !important;
      margin-left: 0 !important;
      margin-bottom: 6px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: list-item !important;
      line-height: 1.6 !important;
    }

    .layout-two-cols ul ul,
    .layout-three-cols ul ul,
    .three-cols-col ul ul,
    .pdf-col ul ul {
      list-style: circle !important;
      list-style-type: circle !important;
      padding-left: 1.25em !important;
      margin-top: 4px !important;
      margin-bottom: 4px !important;
    }

    /* 列表项内嵌标题与说明排版 */
    .slide-list-item-title,
    .pdf-list li > h1,
    .pdf-list li > h2,
    .pdf-list li > h3,
    .pdf-list li > h4,
    .pdf-list li > h5,
    .pdf-list li > h6,
    li > h1.slide-list-item-title,
    li > h2.slide-list-item-title,
    li > h3.slide-list-item-title,
    li > h4.slide-list-item-title {
      margin-top: 2px !important;
      margin-bottom: 6px !important;
      line-height: 1.35 !important;
      font-weight: 700 !important;
    }
    .pdf-list li > h1, li > h1.slide-list-item-title { font-size: 1.6rem !important; }
    .pdf-list li > h2, li > h2.slide-list-item-title { font-size: 1.4rem !important; }
    .pdf-list li > h3, li > h3.slide-list-item-title { font-size: 1.22rem !important; }
    .pdf-list li > h4, li > h4.slide-list-item-title { font-size: 1.1rem !important; }

    /* 全局特定标题大小规范化后置强力锁定 (防止被列表项内部字号覆盖) */
    [data-normalize-headings="true"] .slides-page-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .slides-page-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      font-size: 1.7rem !important;
      font-weight: 600 !important;
      line-height: 1.25 !important;
      margin-bottom: 10px !important;
    }
    [data-normalize-headings="true"] .slides-col-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .slides-col-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] :is(.layout-cols-wrapper, .pdf-two-cols-wrapper, .layout-cols-header-container, .layout-cols-grid) .pdf-col > *:first-child :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] :is(.two-cols-left, .two-cols-right, .pdf-col, .col) > *:first-child :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      font-size: 1.3rem !important;
      font-weight: 600 !important;
      line-height: 1.3 !important;
      margin-bottom: 8px !important;
      text-align: center !important;
    }
    /* 基础列表项前缀样式 */
    .slide-block ul,
    .slide-list--unordered,
    .pdf-list--unordered {
      list-style: disc !important;
      list-style-type: disc !important;
    }
    .slide-block ol,
    .slide-list--ordered,
    .pdf-list--ordered {
      list-style: decimal !important;
      list-style-type: decimal !important;
    }
    .slide-block li,
    .slide-list-item,
    .pdf-list-item,
    .pdf-list li {
      display: list-item !important;
    }

    /* 隐藏无序列表前缀标记 */
    [data-hide-unordered-markers="true"] :is(ul, .slide-list, .slide-list--unordered, .pdf-list, .pdf-list--unordered),
    [data-hide-unordered-markers="true"] :is(ul, .slide-list, .slide-list--unordered, .pdf-list, .pdf-list--unordered) > li,
    [data-hide-unordered-markers="true"] li.slide-list-item,
    [data-hide-unordered-markers="true"] ul > li {
      list-style: none !important;
      list-style-type: none !important;
      padding-left: 0 !important;
      margin-left: 0 !important;
    }
    [data-hide-unordered-markers="true"] :is(ul, .slide-list, .slide-list--unordered, .pdf-list, .pdf-list--unordered) > li::marker,
    [data-hide-unordered-markers="true"] li.slide-list-item::marker {
      content: "" !important;
      display: none !important;
    }

    /* 隐藏有序列表前缀标记 */
    [data-hide-ordered-markers="true"] :is(ol, .slide-list, .slide-list--ordered, .pdf-list, .pdf-list--ordered),
    [data-hide-ordered-markers="true"] :is(ol, .slide-list, .slide-list--ordered, .pdf-list, .pdf-list--ordered) > li,
    [data-hide-ordered-markers="true"] li.slide-list-item,
    [data-hide-ordered-markers="true"] ol > li {
      list-style: none !important;
      list-style-type: none !important;
      padding-left: 0 !important;
      margin-left: 0 !important;
    }
    [data-hide-ordered-markers="true"] :is(ol, .slide-list, .slide-list--ordered, .pdf-list, .pdf-list--ordered) > li::marker,
    [data-hide-ordered-markers="true"] li.slide-list-item::marker {
      content: "" !important;
      display: none !important;
    }

    .slide-list-item-desc,
    .pdf-list li > p {
      margin-top: 4px !important;
      margin-bottom: 6px !important;
      font-size: 1.05rem;
      line-height: 1.55;
      opacity: 0.92;
    }

    /* 多媒体（GIF动图、静态图片、MP4视频）全视口最大化自适应且不超出视口 */
    .slide-media-block,
    .slide-media-container,
    .slide-video-container,
    .slide-block--media,
    .slide-block--image,
    .slide-block--video,
    .slide-block:has(> img),
    .slide-block:has(> .slide-media-container),
    .slide-block:has(> p > img:only-child),
    .slide-block:has(> .slide-video-container),
    .slide-block:has(> video) {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      min-width: 0 !important;
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
      justify-content: center !important;
      width: 100% !important;
      height: 100% !important;
      max-height: 100% !important;
      overflow: hidden !important;
      margin: 4px 0 !important;
      box-sizing: border-box !important;
    }

    .two-cols-left > .slide-block,
    .two-cols-right > .slide-block,
    .three-cols-col > .slide-block,
    .pdf-col > .slide-block,
    .pdf-col .slide-block {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      max-height: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      width: 100% !important;
      height: 100% !important;
      box-sizing: border-box !important;
      overflow: hidden !important;
      margin-bottom: 0 !important;
    }

    /* 列内列表项的标题与段落文字：固定高度，不压缩 */
    .two-cols-left .slide-list-item-title,
    .two-cols-right .slide-list-item-title,
    .three-cols-col .slide-list-item-title,
    .pdf-col .slide-list-item-title,
    .two-cols-left h1, .two-cols-left h2, .two-cols-left h3, .two-cols-left h4, .two-cols-left h5, .two-cols-left h6,
    .two-cols-right h1, .two-cols-right h2, .two-cols-right h3, .two-cols-right h4, .two-cols-right h5, .two-cols-right h6,
    .three-cols-col h1, .three-cols-col h2, .three-cols-col h3, .three-cols-col h4, .three-cols-col h5, .three-cols-col h6,
    .pdf-col h1, .pdf-col h2, .pdf-col h3, .pdf-col h4, .pdf-col h5, .pdf-col h6,
    .three-cols-col .slide-list-item-desc,
    .pdf-col .slide-list-item-desc {
      flex: 0 0 auto !important;
      margin-top: 0 !important;
      margin-bottom: 6px !important;
    }

    /* 列内媒体容器：填满标题下方所有剩余垂直空间，纵向顶部对齐，横向居中，无溢出 */
    .two-cols-left .slide-list-media,
    .two-cols-right .slide-list-media,
    .three-cols-col .slide-list-media,
    .pdf-col .slide-list-media,
    .two-cols-left .slide-video-container,
    .two-cols-right .slide-video-container,
    .three-cols-col .slide-video-container,
    .pdf-col .slide-video-container,
    .two-cols-left .slide-media-container,
    .two-cols-right .slide-media-container,
    .three-cols-col .slide-media-container,
    .pdf-col .slide-media-container {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      min-width: 0 !important;
      width: 100% !important;
      height: 100% !important;
      max-height: 100% !important;
      max-width: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
      justify-content: flex-start !important;
      overflow: hidden !important;
      margin: 0 !important;
      padding: 0 !important;
      box-sizing: border-box !important;
    }

    /* 列内多媒体播放器：以 contain 模式等比缩放完整可见，绝对不超高超宽、不产生遮挡与滚动条 */
    .two-cols-left video,
    .two-cols-right video,
    .three-cols-col video,
    .pdf-col video,
    .two-cols-left img,
    .two-cols-right img,
    .three-cols-col img,
    .pdf-col img,
    .two-cols-left .slide-video-player,
    .two-cols-right .slide-video-player,
    .three-cols-col .slide-video-player,
    .pdf-col .slide-video-player,
    .layout-three-cols-grid video,
    .layout-two-cols-grid video,
    .layout-three-cols-grid img,
    .layout-two-cols-grid img {
      max-width: 100% !important;
      max-height: 100% !important;
      width: auto !important;
      height: auto !important;
      min-width: 0 !important;
      min-height: 0 !important;
      object-fit: contain !important;
      display: block !important;
      margin: 0 auto !important;
      cursor: zoom-in;
    }

    .slide-block img,
    .slide-media-img,
    .slide-media-container img,
    .slide-video-player,
    video.slide-video-player,
    .slide-block video {
      max-width: 100% !important;
      max-height: 100% !important;
      width: auto !important;
      height: auto !important;
      min-width: 0 !important;
      min-height: 0 !important;
      object-fit: contain !important;
      display: block !important;
      margin: 0 auto !important;
      border-radius: 8px;
      box-shadow: 0 4px 16px rgba(0, 0, 0, 0.16);
      background: transparent;
      outline: none;
      cursor: zoom-in;
    }

    .slide-list-media {
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
      justify-content: flex-start !important;
      width: 100% !important;
      max-width: 100% !important;
      height: 100% !important;
      max-height: 100% !important;
      flex: 1 1 0% !important;
      margin-top: 4px !important;
      margin-bottom: 4px !important;
      min-height: 0 !important;
      overflow: hidden !important;
      box-sizing: border-box !important;
    }
    .slide-list-media img,
    .slide-list-media video,
    .slide-list-media .list-item-gif,
    .slide-list-media .slide-video-player {
      max-width: 100% !important;
      max-height: 100% !important;
      width: auto !important;
      height: auto !important;
      min-width: 0 !important;
      min-height: 0 !important;
      object-fit: contain !important;
      border-radius: 6px !important;
      box-shadow: 0 3px 12px rgba(0, 0, 0, 0.14) !important;
      display: block !important;
      margin: 0 auto !important;
      cursor: zoom-in;
    }

    .slide-block:has(.slide-list-media) {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      height: 100% !important;
      max-height: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      overflow: hidden !important;
    }
    .slide-block:has(.slide-list-media) .pdf-list,
    .slide-block:has(.slide-list-media) ul,
    .slide-block:has(.slide-list-media) ol {
      display: block !important;
      flex: 1 1 auto;
      min-height: 0;
      max-height: 100%;
      overflow: visible !important;
      list-style: disc !important;
      list-style-type: disc !important;
    }
    .slide-block:has(.slide-list-media) li,
    .slide-block:has(.slide-list-media) .slide-list-item,
    .slide-block:has(.slide-list-media) .pdf-list-item,
    .slide-block:has(.slide-media-container) li,
    .slide-block:has(.slide-video-container) li,
    .layout-cols-wrapper li:has(.slide-list-media),
    .layout-cols-header-container li:has(.slide-list-media),
    .two-cols-left li:has(.slide-list-media),
    .two-cols-right li:has(.slide-list-media),
    .three-cols-col li:has(.slide-list-media),
    .pdf-col li:has(.slide-list-media),
    li:has(.slide-list-media),
    li:has(.slide-video-container),
    li:has(.slide-media-container) {
      display: list-item !important;
      list-style-type: disc !important;
      flex: 0 0 auto !important;
      height: auto !important;
      max-height: none !important;
      overflow: visible !important;
      margin-bottom: 6px !important;
    }

    .layout-two-cols .slide-media-block,
    .layout-two-cols .slide-video-container,
    .layout-two-cols .slide-media-container,
    .layout-three-cols .slide-media-block,
    .layout-three-cols .slide-video-container,
    .layout-three-cols .slide-media-container {
      max-width: 100% !important;
      max-height: 100% !important;
      width: 100% !important;
      height: 100% !important;
      min-width: 0 !important;
      min-height: 0 !important;
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
      justify-content: flex-start !important;
      overflow: hidden !important;
    }

    /* Lightbox 大图与视频灯箱模态窗口 */
    .slides-lightbox {
      position: fixed;
      top: 0;
      left: 0;
      width: 100vw;
      height: 100vh;
      background: rgba(0, 0, 0, 0.88);
      backdrop-filter: blur(8px);
      z-index: 999999;
      display: none;
      align-items: center;
      justify-content: center;
      cursor: zoom-out;
      opacity: 0;
      transition: opacity 0.2s cubic-bezier(0.16, 1, 0.3, 1);
    }
    .slides-lightbox.active {
      display: flex;
      opacity: 1;
    }
    .slides-lightbox-content {
      position: relative;
      max-width: 92vw;
      max-height: 92vh;
      display: flex;
      align-items: center;
      justify-content: center;
      cursor: default;
    }
    .slides-lightbox-img {
      max-width: 92vw;
      max-height: 92vh;
      object-fit: contain;
      border-radius: 8px;
      box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.75);
      user-select: none;
      -webkit-user-drag: none;
      touch-action: none;
    }
    .slides-lightbox-video {
      max-width: 92vw;
      max-height: 92vh;
      border-radius: 8px;
      box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.75);
    }
    .slides-lightbox-close {
      position: absolute;
      top: 24px;
      right: 28px;
      width: 40px;
      height: 40px;
      background: rgba(255, 255, 255, 0.2);
      border: 1px solid rgba(255, 255, 255, 0.35);
      border-radius: 50%;
      color: #fff;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 22px;
      cursor: pointer;
      transition: background 0.2s, transform 0.2s;
      z-index: 1000000;
    }
    .slides-lightbox-close:hover {
      background: rgba(255, 255, 255, 0.35);
      transform: scale(1.05);
    }

    img.slide-inline-img {
      max-width: 100% !important;
      max-height: min(320px, 40vh) !important;
      object-fit: contain !important;
      vertical-align: middle;
      border-radius: 4px;
    }
    kbd {
      display: inline-block;
      padding: 2px 7px;
      font-family: ui-monospace, SFMono-Regular, "SF Mono", Menlo, Consolas, "Liberation Mono", monospace;
      font-size: 0.85em;
      font-weight: 600;
      line-height: 1.25;
      color: inherit;
      background: rgba(125, 125, 125, 0.12);
      border: 1px solid rgba(125, 125, 125, 0.35);
      border-bottom-width: 2px;
      border-radius: 5px;
      box-shadow: 0 1px 2px rgba(0, 0, 0, 0.12);
      margin: 0 2px;
      vertical-align: middle;
      white-space: nowrap;
    }
    [data-theme="dark"] kbd, .theme-dark kbd {
      background: rgba(255, 255, 255, 0.1);
      border-color: rgba(255, 255, 255, 0.25);
      border-bottom-color: rgba(255, 255, 255, 0.4);
      color: #f1f5f9;
      box-shadow: 0 1px 2px rgba(0, 0, 0, 0.4);
    }
    .slide-block pre,
    pre {
      background: rgba(0, 0, 0, 0.1);
      padding: 12px;
      border-radius: 6px;
      font-family: "JetBrains Mono", Consolas, monospace;
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      overflow-x: hidden !important;
      overflow-y: auto !important;
      max-width: 100% !important;
      box-sizing: border-box !important;
    }
    .slide-block pre code,
    pre code {
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      display: block !important;
      width: 100% !important;
      box-sizing: border-box !important;
    }
    .code-line {
      display: flex !important;
      align-items: flex-start !important;
      width: 100% !important;
      box-sizing: border-box !important;
      line-height: 1.6;
    }
    .code-line .line-no {
      display: inline-block !important;
      flex-shrink: 0 !important;
      min-width: 2.2em !important;
      text-align: right !important;
      margin-right: 12px !important;
      user-select: none !important;
      opacity: 0.45 !important;
    }
    .code-line .line-content {
      flex: 1 1 0% !important;
      min-width: 0 !important;
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
    }
    /* 弱提示滚动条样式 */
    * {
      scrollbar-width: thin;
      scrollbar-color: rgba(255, 255, 255, 0.20) transparent;
    }
    *::-webkit-scrollbar {
      width: 4px;
      height: 4px;
    }
    *::-webkit-scrollbar-track {
      background: transparent;
    }
    *::-webkit-scrollbar-thumb {
      background: rgba(255, 255, 255, 0.20);
      border-radius: 2px;
      transition: background 0.2s ease;
    }
    *:hover::-webkit-scrollbar-thumb,
    *::-webkit-scrollbar-thumb:hover {
      background: rgba(255, 255, 255, 0.45);
    }
    /* Slidev Micro-motion Keyframes & Presets */
    @keyframes slidesMotionFadeIn { from { opacity: 0; } to { opacity: 1; } }
    @keyframes slidesMotionSlideUp { from { opacity: 0; transform: translateY(40px); } to { opacity: 1; transform: translateY(0); } }
    @keyframes slidesMotionSlideDown { from { opacity: 0; transform: translateY(-40px); } to { opacity: 1; transform: translateY(0); } }
    @keyframes slidesMotionSlideLeft { from { opacity: 0; transform: translateX(40px); } to { opacity: 1; transform: translateX(0); } }
    @keyframes slidesMotionSlideRight { from { opacity: 0; transform: translateX(-40px); } to { opacity: 1; transform: translateX(0); } }
    @keyframes slidesMotionZoomIn { from { opacity: 0; transform: scale(0.8); } to { opacity: 1; transform: scale(1); } }
    @keyframes slidesMotionBounce {
      0% { opacity: 0; transform: translateY(40px); }
      60% { opacity: 1; transform: translateY(-8px); }
      80% { transform: translateY(4px); }
      100% { transform: translateY(0); }
    }
    .slides-motion-fade-in { animation: slidesMotionFadeIn var(--motion-duration, 0.4s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slides-motion-slide-up { animation: slidesMotionSlideUp var(--motion-duration, 0.45s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slides-motion-slide-down { animation: slidesMotionSlideDown var(--motion-duration, 0.45s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slides-motion-slide-left { animation: slidesMotionSlideLeft var(--motion-duration, 0.45s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slides-motion-slide-right { animation: slidesMotionSlideRight var(--motion-duration, 0.45s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slides-motion-zoom-in, .slides-motion-pop { animation: slidesMotionZoomIn var(--motion-duration, 0.4s) cubic-bezier(0.34, 1.56, 0.64, 1) var(--motion-delay, 0s) both; }
    .slides-motion-bounce { animation: slidesMotionBounce var(--motion-duration, 0.6s) cubic-bezier(0.34, 1.56, 0.64, 1) var(--motion-delay, 0s) both; }
    .controls {
      position: absolute; bottom: 16px; display: flex; gap: 12px; align-items: center;
      background: rgba(24, 24, 27, 0.8); backdrop-filter: blur(8px);
      padding: 6px 18px; border-radius: 20px; color: #fff; font-size: 13px; z-index: 10;
      opacity: 0; pointer-events: auto;
      transition: opacity 0.3s cubic-bezier(0.16, 1, 0.3, 1), transform 0.3s cubic-bezier(0.16, 1, 0.3, 1);
    }
    .controls::before {
      content: ""; position: absolute; top: -20px; bottom: -16px; left: -24px; right: -24px;
    }
    .controls:hover, .controls:focus-within {
      opacity: 1; transform: translateY(-2px);
    }
    .controls button { background: transparent; border: none; color: inherit; cursor: pointer; padding: 2px 6px; }

    /* Slidev Native Icons & Interactive Buttons */
    .slidev-icon-btn {
      display: inline-flex !important; flex-direction: row !important; align-items: center !important; justify-content: center !important;
      padding: 0.35rem 0.5rem; border-radius: 0.375rem; background: transparent;
      border: 1px solid transparent; color: inherit; font-size: inherit; line-height: 1;
      cursor: pointer; opacity: 0.8; transition: all 0.2s ease; text-decoration: none;
      vertical-align: middle; user-select: none; margin: 0 4px;
    }
    .slidev-icon-btn:hover { opacity: 1; background: rgba(255, 255, 255, 0.12); border-color: rgba(255, 255, 255, 0.15); }

    /* 组件从上到下按顺序流式渲染，避免相互重叠 */
    .slide-block > div + div { margin-top: 14px; }

    /* 同一个 div 内的按钮/链接从左到右水平渲染 */
    .slide-block div:has(> .slidev-icon-btn),
    .slide-block div:has(> button),
    .slide-block [class*="abs-"],
    .slides-btn-row {
      display: inline-flex !important;
      flex-direction: row !important;
      align-items: center !important;
      justify-content: center !important;
      flex-wrap: wrap !important;
      gap: 8px !important;
    }

    /* Position Shortcuts 适配：在组件流中保持从上到下排列，不脱离流产生重叠 */
    .slide-block .abs-br,
    .slide-block .abs-bl,
    .slide-block .abs-tr,
    .slide-block .abs-tl,
    .slide-block [class*="abs-"] {
      position: relative !important;
      bottom: auto !important;
      right: auto !important;
      top: auto !important;
      left: auto !important;
      margin: 0.75rem auto !important;
    }

    .slide-block--absolute { position: relative !important; margin-bottom: 14px !important; padding: 0 !important; background: transparent !important; }
    .slide-block--absolute:hover { background: transparent !important; }
    .mt-12 { margin-top: 3rem !important; }
    .py-1 { padding-top: 0.25rem !important; padding-bottom: 0.25rem !important; }
    .m-6 { margin: 1.5rem !important; }
    .text-xl { font-size: 1.25rem !important; }
    [hover\\:bg~="white"][hover\\:bg~="op-10"]:hover,
    [hover\\:bg="white op-10"]:hover { background: rgba(255, 255, 255, 0.1) !important; border-radius: 4px; }
    .cursor-pointer, [data-clickable] { cursor: pointer; }
    /* Slidev 规范链接排版 (继承正文颜色，虚线底边，Hover 时平滑点亮为主题色并转为实线) */
    .slide-content a:not(.slides-ref-tag):not(.slidev-icon-btn):not(.slides-toc-link),
    .slide-block a:not(.slides-ref-tag):not(.slidev-icon-btn):not(.slides-toc-link),
    a.slides-link {
      color: inherit;
      text-decoration: none;
      border-bottom: 1px dashed currentColor;
      transition: color 0.2s cubic-bezier(0.4, 0, 0.2, 1),
                  border-color 0.2s cubic-bezier(0.4, 0, 0.2, 1),
                  border-bottom-style 0.2s cubic-bezier(0.4, 0, 0.2, 1);
      cursor: pointer;
    }
    .slide-content a:not(.slides-ref-tag):not(.slidev-icon-btn):not(.slides-toc-link):hover,
    .slide-block a:not(.slides-ref-tag):not(.slidev-icon-btn):not(.slides-toc-link):hover,
    a.slides-link:hover {
      color: var(--slide-accent);
      border-bottom-style: solid;
      border-bottom-color: var(--slide-accent);
    }
    .slides-ref-tag, a.slides-ref-tag {
      display: inline-flex;
      align-items: center;
      background: color-mix(in srgb, var(--slide-accent) 12%, transparent);
      color: var(--slide-accent);
      border-radius: 4px;
      padding: 2px 8px;
      font-size: 0.88em;
      text-decoration: none;
      cursor: pointer;
      margin: 2px 4px 2px 0;
      border: 1px solid color-mix(in srgb, var(--slide-accent) 25%, transparent);
      transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
    }
    .slides-ref-tag:hover, a.slides-ref-tag:hover {
      background: color-mix(in srgb, var(--slide-accent) 22%, transparent);
      color: var(--slide-accent);
      border-color: color-mix(in srgb, var(--slide-accent) 55%, transparent);
      transform: translateY(-1px);
      box-shadow: 0 2px 8px color-mix(in srgb, var(--slide-accent) 20%, transparent);
    }
    .slides-block-ref {
      display: block;
      padding: 10px 14px;
      background: color-mix(in srgb, var(--slide-accent) 8%, transparent);
      border-left: 3px solid var(--slide-accent);
      border-radius: 0 6px 6px 0;
      margin: 8px 0;
      cursor: pointer;
      transition: background 0.2s ease;
    }
    .slides-block-ref:hover {
      background: color-mix(in srgb, var(--slide-accent) 15%, transparent);
    }

    /* 页面动态蒙版 (Dynamic Mask) GPU 合成器硬件加速体系 */
    .slides-mask-body-container {
      position: relative;
      width: 100%;
      height: 100%;
      min-height: 0;
      flex: 1;
      display: flex;
      flex-direction: column;
      overflow: hidden !important;
      contain: layout paint;
      isolation: isolate;
    }
    .slides-mask-body-container--has-mask {
      overflow: hidden !important;
      /* 向左右、向下突破父容器内边距，完全贴合幻灯片视口边缘 */
      margin-left: calc(-1 * var(--slides-padding-x, 48px)) !important;
      margin-right: calc(-1 * var(--slides-padding-x, 48px)) !important;
      margin-bottom: calc(-1 * var(--slides-padding-y, 32px)) !important;
      padding-left: var(--slides-padding-x, 48px) !important;
      padding-right: var(--slides-padding-x, 48px) !important;
      padding-bottom: var(--slides-padding-y, 32px) !important;
      width: calc(100% + 2 * var(--slides-padding-x, 48px)) !important;
      box-sizing: border-box !important;
    }
    /* 无标题且首个元素即为蒙版正文容器时，向上同步扩展至顶部边缘 */
    .slide-content-wrapper > .slides-mask-body-container--has-mask:first-child,
    .slide-content > .slides-mask-body-container--has-mask:first-child {
      margin-top: calc(-1 * var(--slides-padding-y, 32px)) !important;
      padding-top: var(--slides-padding-y, 32px) !important;
    }
    /* 针对全屏零内边距特殊布局（如 image-right/image-left），重置内边距变量避免越界 */
    .slide-content-wrapper.layout-image-right,
    .slide-content-wrapper.layout-image-left,
    .slide-content.layout-image-right,
    .slide-content.layout-image-left {
      --slides-padding-x: 0px !important;
      --slides-padding-y: 0px !important;
    }
    /* 蒙版运动总图层：纯 GPU Compositor 硬件加速 translate3d */
    .slides-mask-layer {
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      pointer-events: none;
      z-index: 50;
      will-change: transform, opacity;
      transform: translate3d(0, 0, 0);
      backface-visibility: hidden;
      transition: transform 0.42s cubic-bezier(0.2, 0, 0, 1),
                  opacity 0.42s cubic-bezier(0.2, 0, 0, 1);
    }
    /* 蒙版内部遮罩层：纯色或磨砂玻璃 */
    .slides-mask-overlay {
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      pointer-events: none;
    }
    .slides-mask-layer--solid .slides-mask-overlay,
    .slides-mask-overlay--solid {
      background: var(--slide-bg, #ffffff);
    }
    [data-theme="dark"] .slides-mask-layer--solid .slides-mask-overlay,
    [data-theme="dark"] .slides-mask-overlay--solid {
      background: var(--slide-bg, #121214);
    }
    .slides-mask-layer--blur .slides-mask-overlay,
    .slides-mask-overlay--blur {
      backdrop-filter: blur(30px) saturate(180%);
      -webkit-backdrop-filter: blur(30px) saturate(180%);
      background: color-mix(in srgb, var(--slide-bg, #ffffff) 90%, transparent);
    }
    [data-theme="dark"] .slides-mask-layer--blur .slides-mask-overlay,
    [data-theme="dark"] .slides-mask-overlay--blur {
      background: color-mix(in srgb, var(--slide-bg, #121214) 90%, transparent);
    }
    /* 动态展露分界提示线：物理内嵌于蒙版边缘，相对坐标永为 0，绝对物理同步 */
    .slides-mask-divider-line {
      position: absolute;
      pointer-events: none;
      z-index: 51;
      opacity: 0;
      transition: opacity 0.3s ease;
    }
    .slides-mask-layer--down .slides-mask-divider-line,
    .slides-mask-divider-line--down {
      top: 0;
      left: 0;
      right: 0;
      height: 2.5px;
      transform: translateY(-50%);
      background: linear-gradient(90deg, transparent 0%, var(--slide-accent, #3b82f6) 6%, var(--slide-accent, #3b82f6) 94%, transparent 100%);
      box-shadow: 0 0 10px var(--slide-accent, #3b82f6), 0 0 4px var(--slide-accent, #3b82f6);
    }
    .slides-mask-layer--right .slides-mask-divider-line,
    .slides-mask-divider-line--right {
      top: 0;
      bottom: 0;
      left: 0;
      width: 2.5px;
      transform: translateX(-50%);
      background: linear-gradient(180deg, transparent 0%, var(--slide-accent, #3b82f6) 6%, var(--slide-accent, #3b82f6) 94%, transparent 100%);
      box-shadow: 0 0 10px var(--slide-accent, #3b82f6), 0 0 4px var(--slide-accent, #3b82f6);
    }
    .slides-mask-layer--clockwise,
    .slides-mask-layer--counter-clockwise,
    .slides-mask-layer--cw,
    .slides-mask-layer--ccw,
    .slides-mask-layer--clock {
      transform: none !important;
    }
    .slides-mask-layer--clockwise .slides-mask-divider-line,
    .slides-mask-layer--counter-clockwise .slides-mask-divider-line,
    .slides-mask-layer--cw .slides-mask-divider-line,
    .slides-mask-layer--ccw .slides-mask-divider-line,
    .slides-mask-layer--clock .slides-mask-divider-line,
    .slides-mask-divider-line--clock,
    .slides-mask-divider-line--clockwise,
    .slides-mask-divider-line--counter-clockwise {
      top: 50%;
      left: 50%;
      right: auto;
      bottom: auto;
      width: 55%;
      height: 2.5px;
      transform-origin: 0% 50%;
      transform: translateY(-50%) rotate(-180deg);
      background: linear-gradient(90deg, var(--slide-accent, #3b82f6) 0%, var(--slide-accent, #3b82f6) 75%, transparent 100%);
      box-shadow: 0 0 10px var(--slide-accent, #3b82f6), 0 0 4px var(--slide-accent, #3b82f6);
      transition: transform 0.42s cubic-bezier(0.2, 0, 0, 1), opacity 0.3s ease;
      will-change: transform, opacity;
    }
    .slides-mask-layer--counter-clockwise .slides-mask-divider-line,
    .slides-mask-divider-line--counter-clockwise {
      transform: translateY(-50%) rotate(-90deg);
    }`}function rg(){return`    (function() {
      const data = window.__SLIDES_DATA__ || { slides: [] };
      const slides = data.slides || [];
      let currentIndex = 0;

      const container = document.getElementById("slide-container");
      const pageNum = document.getElementById("page-num");
      const btnPrev = document.getElementById("btn-prev");
      const btnNext = document.getElementById("btn-next");
      const btnFullscreen = document.getElementById("btn-fullscreen");

      // 「数字+回车」跳页输入角标：右下角悬浮显示，独立于缩放视口
      const jumpBadge = document.createElement("div");
      jumpBadge.className = "jump-page-indicator";
      jumpBadge.style.display = "none";
      document.body.appendChild(jumpBadge);
      const jumpStyle = document.createElement("style");
      jumpStyle.textContent = ".jump-page-indicator{position:fixed;right:16px;bottom:16px;z-index:1000;min-width:40px;padding:4px 12px;border-radius:18px;background:rgba(24,24,27,0.8);backdrop-filter:blur(12px);-webkit-backdrop-filter:blur(12px);border:1px solid rgba(255,255,255,0.12);color:#f4f4f5;font-size:14px;font-variant-numeric:tabular-nums;text-align:center;pointer-events:none;box-shadow:0 4px 16px rgba(0,0,0,0.35);}.jump-page-indicator.is-invalid{background:rgba(153,27,27,0.85);border-color:rgba(248,113,113,0.5);color:#fecaca;animation:jump-indicator-shake 0.4s ease;}@keyframes jump-indicator-shake{0%,100%{transform:translateX(0);}25%{transform:translateX(-4px);}50%{transform:translateX(4px);}75%{transform:translateX(-2px);}}";
      document.head.appendChild(jumpStyle);

`}function ag(){return`      // ========= 缩略图总览层（o 键呼出，方向键/数字+回车/点选跳页） =========
      const OVERVIEW_CARD_W = 236;
      let overviewOpen = false;
      let overviewFocus = 1;
      let overviewBuilt = false;
      let overviewObserver = null;
      const overviewOverlay = document.createElement("div");
      overviewOverlay.className = "slides-overview";
      overviewOverlay.style.display = "none";
      const overviewGrid = document.createElement("div");
      overviewGrid.className = "slides-overview-grid";
      const overviewHint = document.createElement("div");
      overviewHint.className = "slides-overview-hint";
      overviewHint.textContent = "← → ↑ ↓ 移动 · Enter 跳转 · 数字直达 · Esc / O 关闭";
      overviewOverlay.appendChild(overviewGrid);
      overviewOverlay.appendChild(overviewHint);
      document.body.appendChild(overviewOverlay);
      overviewOverlay.addEventListener("click", (e) => {
        if (e.target === overviewOverlay) closeOverview();
      });
      const overviewStyle = document.createElement("style");
      overviewStyle.textContent = ".slides-overview{position:fixed;inset:0;z-index:900;overflow-y:auto;background:rgba(13,16,22,0.88);backdrop-filter:blur(18px);-webkit-backdrop-filter:blur(18px);padding:36px 44px 20px;box-sizing:border-box;}.slides-overview-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(236px,1fr));gap:18px;max-width:1440px;margin:0 auto;}.slides-overview-card{cursor:pointer;border-radius:10px;border:2px solid rgba(255,255,255,0.12);background:rgba(255,255,255,0.04);overflow:hidden;transition:border-color 0.15s ease,transform 0.15s ease,box-shadow 0.15s ease;}.slides-overview-card:hover{border-color:rgba(255,255,255,0.38);transform:translateY(-2px);}.slides-overview-card.is-active{border-color:var(--slide-accent,#3b82f6);box-shadow:0 0 0 1px var(--slide-accent,#3b82f6),0 8px 24px rgba(0,0,0,0.4);}.slides-overview-canvas-box{position:relative;overflow:hidden;background:var(--slide-bg,#ffffff);}.slides-overview-canvas{position:absolute;top:0;left:0;transform-origin:top left;pointer-events:none;}.slides-overview-canvas *{scrollbar-width:none;}.slides-overview-caption{display:flex;align-items:center;gap:8px;padding:6px 10px;font-size:12px;color:rgba(255,255,255,0.72);border-top:1px solid rgba(255,255,255,0.08);background:rgba(13,16,22,0.6);}.slides-overview-page-no{flex-shrink:0;font-variant-numeric:tabular-nums;font-weight:600;color:#f4f4f5;background:rgba(255,255,255,0.16);border-radius:8px;padding:0 7px;line-height:18px;}.slides-overview-page-no.is-current{background:var(--slide-accent,#10b981);color:#0b1210;}.slides-overview-title{white-space:nowrap;overflow:hidden;text-overflow:ellipsis;user-select:none;}.slides-overview-hint{text-align:center;margin:18px 0 8px;font-size:12px;color:rgba(255,255,255,0.45);user-select:none;}";
      document.head.appendChild(overviewStyle);

      const baseWidth = 980;
      const aspectStr = (data.config && data.config.aspectRatio) || "16/9";
      let ratioNum = 16 / 9;
      if (aspectStr === "4/3") ratioNum = 4 / 3;
      else if (aspectStr === "16/10") ratioNum = 16 / 10;
      else if (typeof aspectStr === "string" && aspectStr.includes("/")) {
        const parts = aspectStr.split("/").map(Number);
        if (parts[0] && parts[1]) ratioNum = parts[0] / parts[1];
      }
      const baseHeight = Math.ceil(baseWidth / ratioNum);
      const viewport = document.getElementById("viewport");

`}function lg(){return`      function updateScale() {
        if (!viewport) return;
        const isFull = !!document.fullscreenElement;
        const padX = isFull ? 0 : 20;
        const padY = isFull ? 0 : 32;
        const availW = Math.max(100, window.innerWidth - padX);
        const availH = Math.max(100, window.innerHeight - padY);
        const scale = Math.min(availW / baseWidth, availH / baseHeight);
        viewport.style.width = baseWidth + "px";
        viewport.style.height = baseHeight + "px";
        viewport.style.transform = "translate(-50%, -50%) scale(" + scale + ")";
        viewport.style.setProperty("--slides-slide-scale", scale);
        if (isFull) document.body.classList.add("is-fullscreen");
        else document.body.classList.remove("is-fullscreen");
      }

      window.addEventListener("resize", updateScale);
      document.addEventListener("fullscreenchange", updateScale);

      function parseMaskRatio(ratioStr, defaultSteps) {
        var defSteps = (defaultSteps === 4) ? 4 : 2;
        var defBps = (defaultSteps === 4) ? [25, 50, 75, 100] : [50, 100];
        if (!ratioStr || typeof ratioStr !== "string") {
          return { steps: defSteps, breakpoints: defBps };
        }
        var clean = ratioStr.trim();
        if (!clean || (defaultSteps === 4 && (clean === "1:1" || clean === "1"))) return { steps: defSteps, breakpoints: defBps };
        var parts = clean.split(":").map(function(p) { return parseFloat(p.trim()); }).filter(function(n) { return !isNaN(n) && n > 0; });
        if (parts.length === 0) return { steps: defSteps, breakpoints: defBps };
        if (parts.length === 1) {
          var val = Math.min(100, Math.max(1, parts[0]));
          if (val === 100) return { steps: 1, breakpoints: [100] };
          return { steps: 2, breakpoints: [Math.round(val * 100) / 100, 100] };
        }
        var isMonotonic = parts.every(function(val, idx) { return idx === 0 || val > parts[idx - 1]; });
        var maxVal = parts[parts.length - 1];
        if (isMonotonic && (maxVal === 100 || parts.some(function(p) { return p > 10; }))) {
          var bps = parts.map(function(p) { return Math.min(100, Math.round(p * 100) / 100); });
          if (bps[bps.length - 1] < 100) bps.push(100);
          return { steps: bps.length, breakpoints: bps };
        }
        var totalWeight = parts.reduce(function(acc, cur) { return acc + cur; }, 0);
        if (totalWeight <= 0) return { steps: defSteps, breakpoints: defBps };
        var accumulated = 0;
        var bps = [];
        for (var i = 0; i < parts.length; i++) {
          accumulated += parts[i];
          if (i === parts.length - 1) {
            bps.push(100);
          } else {
            bps.push(Math.round((accumulated / totalWeight) * 10000) / 100);
          }
        }
        return { steps: bps.length, breakpoints: bps };
      }

      let currentMaskStep = 0;
      let currentMaskConfig = null;
      let maskLayerEl = null;
      let maskOverlayEl = null;
      let maskDividerEl = null;

      function updateMaskVisual() {
        if (!currentMaskConfig || !maskLayerEl) return;
        const p = (currentMaskStep <= 0)
          ? (currentMaskConfig.isInitialRevealed ? currentMaskConfig.breakpoints[0] : 0)
          : (currentMaskStep >= currentMaskConfig.totalSteps
              ? 100
              : currentMaskConfig.breakpoints[currentMaskConfig.isInitialRevealed ? currentMaskStep : (currentMaskStep - 1)]);

        if (currentMaskConfig.isClock) {
          const isCw = currentMaskConfig.direction === "clockwise" || currentMaskConfig.direction === "cw";
          const sweepDeg = Math.min(360, Math.max(0, (p / 100) * 360));
          const needleAngle = isCw ? (-180 + sweepDeg) : (-90 - sweepDeg);

          if (maskOverlayEl) {
            let maskGrad = "";
            if (sweepDeg <= 0) {
              maskGrad = "conic-gradient(from 0deg at 50% 50%, #000 0deg, #000 360deg)";
            } else if (sweepDeg >= 360) {
              maskGrad = "conic-gradient(from 0deg at 50% 50%, transparent 0deg, transparent 360deg)";
            } else if (isCw) {
              maskGrad = "conic-gradient(from 270deg at 50% 50%, transparent 0deg, transparent " + sweepDeg + "deg, #000 " + sweepDeg + "deg, #000 360deg)";
            } else {
              const remDeg = 360 - sweepDeg;
              maskGrad = "conic-gradient(from 0deg at 50% 50%, #000 0deg, #000 " + remDeg + "deg, transparent " + remDeg + "deg, transparent 360deg)";
            }
            maskOverlayEl.style.webkitMaskImage = maskGrad;
            maskOverlayEl.style.maskImage = maskGrad;
          }

          if (maskDividerEl) {
            maskDividerEl.style.transform = "translateY(-50%) rotate(" + needleAngle + "deg)";
            maskDividerEl.style.opacity = (p <= 0 || p >= 100) ? "0" : "1";
          }

          if (p >= 100) {
            maskLayerEl.style.opacity = "0";
            maskLayerEl.style.pointerEvents = "none";
          } else {
            maskLayerEl.style.opacity = "1";
            maskLayerEl.style.pointerEvents = "none";
          }
          return;
        }

        const isDown = currentMaskConfig.direction === "down";
        if (p >= 100) {
          maskLayerEl.style.transform = isDown ? "translate3d(0, 100%, 0)" : "translate3d(100%, 0, 0)";
          maskLayerEl.style.opacity = "0";
          maskLayerEl.style.pointerEvents = "none";
          if (maskDividerEl) maskDividerEl.style.opacity = "0";
        } else {
          maskLayerEl.style.transform = isDown ? ("translate3d(0, " + p + "%, 0)") : ("translate3d(" + p + "%, 0, 0)");
          maskLayerEl.style.opacity = "1";
          maskLayerEl.style.pointerEvents = "none";
          if (maskDividerEl) {
            maskDividerEl.style.opacity = (p <= 0) ? "0" : "1";
          }
        }
      }

      function goNext() {
        if (currentMaskConfig && currentMaskStep < currentMaskConfig.totalSteps) {
          currentMaskStep++;
          updateMaskVisual();
          return;
        }
        renderSlide(currentIndex + 1);
      }

      function goPrev() {
        if (currentMaskConfig && currentMaskStep > (currentMaskConfig.isInitialRevealed ? 1 : 0)) {
          currentMaskStep--;
          updateMaskVisual();
          return;
        }
        // FSM-9 优化：回退至上一页时传递 backward 方向，使上一页遮罩处于完全展开状态
        renderSlide(currentIndex - 1, "backward");
      }

`}function cg(){return`      function cleanCardListItemMarkdown(rawMarkdown) {
        if (!rawMarkdown) return "";
        let cleaned = rawMarkdown.replace(/^[ 	]*[-*+]s+|^[ 	]*d+.s+/, "");
        cleaned = cleaned.replace(/
[ 	]{2,4}/g, "
");
        return cleaned.trim();
      }

      function isHeadingBlock(b) {
        if (!b) return false;
        if (b.type === "h" || b.type === "NodeHeading") return true;
        if (b.subType && /^h[1-6]$/i.test(b.subType)) return true;
        const md = (b.rawMarkdown || b.content || "").trim();
        if (/^#{1,6}s+/.test(md)) return true;
        if (/^(?:[-*+]|d+.)s+#{1,6}s+/.test(md)) return true;
        return false;
      }

      function cleanColList(blocks) {
        const valid = (blocks || []).filter(b => Boolean((b.rawMarkdown || b.content || "").trim()));
        if (valid.length === 0) return valid;
        const first = valid[0];
        const md = (first.rawMarkdown || first.content || "").trim();
        const isList = /^(?:[-*+]|d+.)s+/.test(md) || first.type === "i" || first.type === "l";
        if (isList) {
          first.rawMarkdown = cleanCardListItemMarkdown(first.rawMarkdown || first.content || "");
          first.content = first.rawMarkdown;
        }
        return valid;
      }

      function renderBlock(block, extraClass) {
        const div = document.createElement("div");
        div.className = "slide-block" + (extraClass ? " " + extraClass : "");
        if (block && block.motion && block.motion.preset && block.motion.preset !== "none") {
          div.classList.add("slides-motion-" + block.motion.preset.toLowerCase());
          if (typeof block.motion.duration === "number" && block.motion.duration > 0) {
            div.style.setProperty("--motion-duration", block.motion.duration + "ms");
          }
          if (typeof block.motion.delay === "number" && block.motion.delay > 0) {
            div.style.setProperty("--motion-delay", block.motion.delay + "ms");
          }
        }
        const md = block.rawMarkdown || block.content || "";

        if (md.includes('class="slides-block-ref"') || md.includes('class="slides-ref-tag"')) {
          div.innerHTML = md;
          return div;
        }

        const CARBON_MAP = {
          'carbon:arrow-right': '<svg viewBox="0 0 32 32" width="1.2em" height="1.2em" fill="currentColor" style="display:inline-block;vertical-align:middle;"><path d="m18 6l-1.43 1.393L24.15 15H4v2h20.15l-7.58 7.573L18 26l10-10z"/></svg>',
          'carbon:arrow-left': '<svg viewBox="0 0 32 32" width="1.2em" height="1.2em" fill="currentColor" style="display:inline-block;vertical-align:middle;"><path d="m14 26l1.43-1.393L7.85 17H28v-2H7.85l7.58-7.573L14 6L4 16z"/></svg>',
          'carbon:edit': '<svg viewBox="0 0 32 32" width="1.2em" height="1.2em" fill="currentColor" style="display:inline-block;vertical-align:middle;"><path d="M2 26h28v2H2zM25.4 9c.8-.8.8-2 0-2.8l-3.6-3.6c-.8-.8-2-.8-2.8 0l-15 15V24h6.4l15-15zM20.4 4L24 7.6l-2.4 2.4l-3.6-3.6L20.4 4zM6 22v-3.6l11-11l3.6 3.6l-11 11H6z"/></svg>',
          'carbon:logo-github': '<svg viewBox="0 0 32 32" width="1.2em" height="1.2em" fill="currentColor" style="display:inline-block;vertical-align:middle;"><path fill-rule="evenodd" d="M16 2a14 14 0 0 0-4.43 27.28c.7.13 1-.3 1-.67v-2.38c-3.89.84-4.71-1.88-4.71-1.88a3.7 3.7 0 0 0-1.56-2.05c-1.27-.86.1-.85.1-.85a2.94 2.94 0 0 1 2.14 1.44a3 3 0 0 0 4.08 1.16a2.93 2.93 0 0 1 .89-1.87c-3.1-.35-6.36-1.55-6.36-6.9a5.4 5.4 0 0 1 1.44-3.75a5 5 0 0 1 .14-3.71s1.17-.38 3.85 1.43a13.3 13.3 0 0 1 7 0c2.67-1.81 3.84-1.43 3.84-1.43a5 5 0 0 1 .14 3.71a5.4 5.4 0 0 1 1.44 3.75c0 5.37-3.27 6.54-6.38 6.89a3.35 3.35 0 0 1 1.26 2.61v3.87c0 .38.26.81 1 .67A14 14 0 0 0 16 2"/></svg>'
        };

        if (/@\\w+=['"]|v-\\w+|<button|<a\\b|<carbon:|^<div/i.test(md)) {
          if (md.includes('abs-br') || md.includes('abs-bl') || md.includes('abs-tr') || md.includes('abs-tl') || md.includes('absolute')) {
            div.classList.add("slide-block--absolute");
          }
          let renderedHtml = md;
          for (const [tag, svg] of Object.entries(CARBON_MAP)) {
            const regex = new RegExp("<" + tag + "\\\\s*\\\\/?>", "gi");
            renderedHtml = renderedHtml.replace(regex, svg);
            const regexDash = new RegExp("<" + tag.replace(":", "-") + "\\\\s*\\\\/?>", "gi");
            renderedHtml = renderedHtml.replace(regexDash, svg);
          }
          div.innerHTML = renderedHtml;

          // 挂载交互事件监听
          const nextBtns = div.querySelectorAll('[\\\\@click*="nav.next"], [\\\\@click*="next"]');
          nextBtns.forEach(btn => {
            btn.style.cursor = "pointer";
            btn.addEventListener("click", (e) => {
              e.stopPropagation();
              renderSlide(currentIndex + 1);
            });
          });

          const prevBtns = div.querySelectorAll('[\\\\@click*="nav.prev"], [\\\\@click*="prev"]');
          prevBtns.forEach(btn => {
            btn.style.cursor = "pointer";
            btn.addEventListener("click", (e) => {
              e.stopPropagation();
              renderSlide(currentIndex - 1);
            });
          });

          return div;
        }

        const hasHeadingTag = /(?:^|
)s*#{1,6}s+/.test(md);
        const hMatch = md.match(/^(#{1,6})\\s+(.*)$/);

        if (hMatch) {
          const level = hMatch[1].length;
          let th = hMatch[2].trim().replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
          div.innerHTML = "<h" + level + ">" + th + "</h" + level + ">";
        }
        else if (md.startsWith("\`\`\`")) {
          const customMaxHeight = block?.attributes?.["custom-slides-max-height"] || block?.attrs?.["custom-slides-max-height"] || block?.maxHeight || "";
          const heightStyle = customMaxHeight ? ' style="max-height:' + customMaxHeight + ';overflow-y:auto;"' : "";
          div.innerHTML = "<pre" + heightStyle + "><code>" + md.slice(3, -3) + "</code></pre>";
        }
        else if (md.startsWith("> ")) div.innerHTML = "<blockquote><p>" + md.slice(2) + "</p></blockquote>";
        else if ((/<video\b/i.test(md) || (block && (block.type === "video" || block.type === "NodeVideo"))) && !/^(s*)([-*+]|d+.)s+/m.test(md) && !hasHeadingTag && !md.includes("
")) {
          div.classList.add("slide-video-container", "slide-media-container", "slide-media-block");
          const isAutoplay = block && block.attributes && block.attributes["custom-slides-autoplay"] === "true";
          const isLoop = block && block.attributes && block.attributes["custom-slides-loop"] === "true";
          const isMuted = block && block.attributes && (block.attributes["custom-slides-muted"] === "true" || isAutoplay);
          const hideControls = block && block.attributes && block.attributes["custom-slides-controls"] === "false";
          let videoHtml = md;
          if (hideControls) videoHtml = videoHtml.replace(/\bcontrols(?:="[^"]*")?/gi, "").trim();
          else if (!videoHtml.includes("controls")) videoHtml = videoHtml.replace("<video", "<video controls");
          if (isAutoplay && !videoHtml.includes("autoplay")) videoHtml = videoHtml.replace("<video", "<video autoplay playsinline");
          if (isLoop && !videoHtml.includes("loop")) videoHtml = videoHtml.replace("<video", "<video loop");
          if (isMuted && !videoHtml.includes("muted")) videoHtml = videoHtml.replace("<video", "<video muted");
          videoHtml = videoHtml.replace("<video", '<video class="slide-video-player"');
          div.setAttribute("data-autoplay", isAutoplay ? "true" : "false");
          div.innerHTML = videoHtml;
        }
        else if (
          /^(s*)([-*+]|d+.)s+/m.test(md) ||
          (md.includes("
") && /^(s*)([-*+]|d+.)s+/m.test(md.split("
").slice(1).join("
"))) ||
          ((block && (block.isListItem || block.type === "i")) && !block.isColFirst)
        ) {
          div.classList.add("pdf-list-item");
          const lines = md.split("
");
          let isOrdered = false;
          const items = [];
          const leadLines = [];
          for (let i = 0; i < lines.length; i++) {
            const line = lines[i];
            const tr = line.trim();
            if (!tr || /^{:.*?}$/.test(tr)) continue;
            const um = line.match(/^(s*)[-*+]s+(.*)$/);
            const om = line.match(/^(s*)d+.s+(.*)$/);
            if (um) {
              const indent = um[1].length;
              items.push({ type: "unordered", level: Math.floor(indent / 2), text: um[2], media: [] });
              continue;
            }
            if (om) {
              if (items.length === 0) isOrdered = true;
              const indent = om[1].length;
              items.push({ type: "ordered", level: Math.floor(indent / 2), text: om[2], media: [] });
              continue;
            }
            if (items.length > 0) {
              const im = tr.match(/^![(.*?)]((.*?))(?:{:?[^}]*})?$/);
              if (im) {
                const isGif = /.gif(?:?|$)/i.test(im[2]);
                items[items.length - 1].media.push('<div class="slide-list-media"><img alt="' + im[1] + '" src="' + im[2] + '" class="' + (isGif ? 'list-item-gif' : 'list-item-img') + '" /></div>');
                continue;
              }
              const hm = tr.match(/^<img\b[sS]*?/?>$/i);
              if (hm) {
                const cleanTr = tr.replace(/s+style="[^"]*"/gi, "");
                items[items.length - 1].media.push('<div class="slide-list-media">' + cleanTr + '</div>');
                continue;
              }
              if (/<video\b/i.test(tr)) {
                let vHtml = tr;
                if (!/</video>/i.test(vHtml)) {
                  while (i + 1 < lines.length && !/</video>/i.test(vHtml)) {
                    i++;
                    vHtml += " " + lines[i].trim();
                  }
                }
                const isAutoplay = block && block.attributes && block.attributes["custom-slides-autoplay"] === "true";
                const isLoop = block && block.attributes && block.attributes["custom-slides-loop"] === "true";
                const isMuted = block && block.attributes && (block.attributes["custom-slides-muted"] === "true" || isAutoplay);
                const hideControls = block && block.attributes && block.attributes["custom-slides-controls"] === "false";
                if (hideControls) vHtml = vHtml.replace(/\bcontrols(?:="[^"]*")?/gi, "").trim();
                else if (!vHtml.includes("controls")) vHtml = vHtml.replace("<video", "<video controls");
                if (isAutoplay && !vHtml.includes("autoplay")) vHtml = vHtml.replace("<video", "<video autoplay playsinline");
                if (isLoop && !vHtml.includes("loop")) vHtml = vHtml.replace("<video", "<video loop");
                if (isMuted && !vHtml.includes("muted")) vHtml = vHtml.replace("<video", "<video muted");
                vHtml = vHtml.replace("<video", '<video class="slide-video-player"');
                items[items.length - 1].media.push('<div class="slide-list-media slide-video-container slide-media-container" data-autoplay="' + (isAutoplay ? 'true' : 'false') + '">' + vHtml + '</div>');
                continue;
              }
              items[items.length - 1].text += "
" + tr;
            } else {
              leadLines.push(tr);
            }
          }

          if (items.length === 0 && (block && (block.isListItem || block.type === "i")) && !block.isColFirst) {
            items.push({ type: "unordered", level: 0, text: md, media: [] });
            leadLines.length = 0;
          }

          let leadHtml = "";
          if (leadLines.length > 0) {
            const lParts = [];
            const firstL = leadLines[0];
            const fhm = firstL.match(/^(#{1,6})s+(.*)$/);
            if (fhm) {
              const lvl = fhm[1].length;
              let th = fhm[2].trim().replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
              lParts.push('<h' + lvl + ' class="slide-list-item-title">' + th + '</h' + lvl + '>');
            } else {
              let th = firstL.trim().replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
              lParts.push('<p class="slide-list-item-title">' + th + '</p>');
            }
            if (leadLines.length > 1) {
              const dLines = leadLines.slice(1);
              let pL = [];
              const flushLeadP = () => {
                if (pL.length > 0) {
                  let txt = pL.map(l => l.replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>")).join("<br/>");
                  lParts.push('<p class="slide-list-item-desc">' + txt + '</p>');
                  pL = [];
                }
              };
              for (const l of dLines) {
                const hm = l.match(/^(#{1,6})s+(.*)$/);
                if (hm) {
                  flushLeadP();
                  const lvl = hm[1].length;
                  let th = hm[2].trim().replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
                  lParts.push('<h' + lvl + ' class="slide-list-item-title">' + th + '</h' + lvl + '>');
                } else {
                  pL.push(l);
                }
              }
              flushLeadP();
            }
            leadHtml = lParts.join("
") + "
";
          }

          const tag = isOrdered ? "ol" : "ul";
          const listCls = isOrdered ? "pdf-list pdf-list--ordered" : "pdf-list pdf-list--unordered";
          const liHtml = items.map(it => {
            const med = it.media && it.media.length ? "
" + it.media.join("
") : "";
            const lines = (it.text || "").split("
").map(l => l.trim()).filter(Boolean);
            const hasHeading = lines.some(l => /^#{1,6}s+/.test(l));
            const lvl = it.level || 0;
            const nStyle = lvl > 0 ? ' style="margin-left:' + (lvl * 1.25).toFixed(2) + 'em;' + (it.type === 'unordered' ? 'list-style-type:' + (lvl % 2 === 1 ? 'circle' : 'square') + ' !important;' : '') + '"' : "";
            const nClass = lvl > 0 ? " slide-list-item--nested" : "";
            const clsAttr = nClass ? ' class="' + nClass.trim() + '"' : "";
            if (!hasHeading) {
              let h = lines.map(l => l.replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>")).join("<br/>");
              return '<li' + clsAttr + nStyle + '>' + h + med + '</li>';
            }
            const parts = [];
            let pLines = [];
            const flushP = () => {
              if (pLines.length > 0) {
                let ph = pLines.map(l => l.replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>")).join("<br/>");
                parts.push('<p class="slide-list-item-desc">' + ph + '</p>');
                pLines = [];
              }
            };
            for (const l of lines) {
              const hm = l.match(/^(#{1,6})s+(.*)$/);
              if (hm) {
                flushP();
                const hl = hm[1].length;
                let th = hm[2].trim().replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
                parts.push('<h' + hl + ' class="slide-list-item-title">' + th + '</h' + hl + '>');
              } else {
                pLines.push(l);
              }
            }
            flushP();
            return '<li' + clsAttr + nStyle + '>' + parts.join("
") + med + '</li>';
          }).join("
");
          div.innerHTML = leadHtml + "<" + tag + " class="" + listCls + "">
" + liHtml + "
</" + tag + ">";
        }
        else {
          // 复合块（包含换行、标题或媒体）高保真解析
          const lines = md.split(/\r?
/);
          const subBlocks = [];
          let current = [];
          for (let i = 0; i < lines.length; i++) {
            const line = lines[i];
            const trimmed = line.trim();
            if (/^#{1,6}s+/.test(trimmed)) {
              if (current.length > 0) { subBlocks.push(current.join("
")); current = []; }
              subBlocks.push(trimmed);
              continue;
            }
            if (!trimmed) {
              if (current.length > 0) { subBlocks.push(current.join("
")); current = []; }
              continue;
            }
            if (/^![.*?](.*?)$/.test(trimmed)) {
              if (current.length > 0) { subBlocks.push(current.join("
")); current = []; }
              subBlocks.push(trimmed);
              continue;
            }
            if (/<video\b/i.test(trimmed)) {
              if (current.length > 0) { subBlocks.push(current.join("
")); current = []; }
              let vRaw = trimmed;
              if (!/</video>/i.test(vRaw)) {
                while (i + 1 < lines.length && !/</video>/i.test(vRaw)) {
                  i++;
                  vRaw += "
" + lines[i];
                }
              }
              subBlocks.push(vRaw);
              continue;
            }
            current.push(line);
          }
          if (current.length > 0) subBlocks.push(current.join("
"));

          if (subBlocks.length > 1 || (subBlocks.length === 1 && /^#{1,6}s+/.test(subBlocks[0].trim()))) {
            let isFirstParagraph = true;
            const htmlParts = subBlocks.map(sub => {
              const t = sub.trim();
              if (!t) return "";
              const hm = t.match(/^(#{1,6})s+(.*)$/);
              if (hm) {
                isFirstParagraph = false;
                const hl = hm[1].length;
                let th = hm[2].trim().replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
                return '<h' + hl + ' class="slide-list-item-title">' + th + '</h' + hl + '>';
              }
              const im = t.match(/^![(.*?)]((.*?))$/);
              if (im) {
                return '<div class="slide-media-block slide-media-container slide-list-media"><img alt="' + im[1] + '" src="' + im[2] + '" class="slide-media-img" /></div>';
              }
              if (/<video\b/i.test(t)) {
                return '<div class="slide-media-block slide-video-container slide-media-container">' + t + '</div>';
              }
              if (isFirstParagraph) {
                isFirstParagraph = false;
                const subLines = t.split(/\r?
/).map(l => l.trim()).filter(Boolean);
                if (subLines.length === 1) {
                  let ph = subLines[0].replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
                  return '<p class="slide-list-item-title">' + ph + '</p>';
                }
                let titleHtml = subLines[0].replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
                let descHtml = subLines.slice(1).map(l => l.replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>")).join("<br/>");
                return '<p class="slide-list-item-title">' + titleHtml + '</p>
<p class="slide-list-item-desc">' + descHtml + '</p>';
              }
              let ph = t.replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
              return '<p class="slide-list-item-desc">' + ph + '</p>';
            }).filter(Boolean);
            div.innerHTML = htmlParts.join("
");
          } else {
            const imgMatch = md.match(/!\\[(.*?)\\]\\((.*?)\\)/);
            if (imgMatch) {
              div.classList.add("slide-media-container", "slide-media-block", "slide-block--image");
              div.innerHTML = '<img alt="' + imgMatch[1] + '" src="' + imgMatch[2] + '" class="slide-media-img" />';
            } else {
              let html = md.replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
              const pCls = (block && block.isColFirst) ? ' class="slide-list-item-title"' : '';
              div.innerHTML = "<p" + pCls + ">" + html + "</p>";
            }
          }
        }
        return div;
      }

`}function dg(){return`      function renderSlide(idx, direction) {
        if (slides.length === 0) return;
        currentIndex = Math.max(0, Math.min(idx, slides.length - 1));
        const slide = slides[currentIndex];
        pageNum.textContent = (currentIndex + 1) + " / " + slides.length;

        const pageSp = slide.frontmatter?.spacing;
        const currentSpacing = (pageSp && pageSp !== "inherit") ? pageSp : (data.config?.spacing || "normal");
        container.className = "slide-content layout-" + (slide.frontmatter?.layout || "default") + " spacing-" + currentSpacing;
        if (viewport) viewport.setAttribute("data-spacing", currentSpacing);
        container.innerHTML = "";

        const z = typeof slide.frontmatter?.zoom === "number" && slide.frontmatter.zoom > 0 ? slide.frontmatter.zoom : 1;
        if (z !== 1) {
          container.style.width = (100 / z) + "%";
          container.style.height = (100 / z) + "%";
          container.style.transformOrigin = "top left";
          container.style.transform = "scale(" + z + ")";
        } else {
          container.style.width = "100%";
          container.style.height = "100%";
          container.style.transform = "none";
        }

        const slideBg = slide.frontmatter?.background || (data.config && data.config.background);
        if (slideBg) {
          if (/^(http|\\/|data:|assets\\/)/.test(slideBg)) {
            container.style.backgroundImage = 'url("' + slideBg + '")';
            container.style.backgroundSize = "cover";
            container.style.backgroundPosition = "center";
          } else {
            container.style.backgroundImage = "none";
            container.style.background = slideBg;
          }
        } else {
          container.style.backgroundImage = "none";
          container.style.background = "";
        }

        maskOverlayEl = null;
        maskDividerEl = null;
        const maskDir = slide.frontmatter?.mask;
        const isClock = maskDir === "clockwise" || maskDir === "counter-clockwise" || maskDir === "cw" || maskDir === "ccw";
        if (maskDir === "down" || maskDir === "right" || isClock) {
          const isClover = slide.frontmatter?.layout === "clover";
          const ratioInfo = parseMaskRatio(slide.frontmatter.maskRatio, (isClock || isClover) ? 4 : 2);
          const isInitRev = slide.frontmatter.maskInitial === "revealed";
          currentMaskConfig = {
            direction: isClock ? ((maskDir === "cw" || maskDir === "clockwise") ? "clockwise" : "counter-clockwise") : maskDir,
            isClock: isClock,
            totalSteps: isInitRev ? Math.max(0, ratioInfo.steps - 1) : ratioInfo.steps,
            rawSteps: ratioInfo.steps,
            breakpoints: ratioInfo.breakpoints,
            isInitialRevealed: isInitRev,
            style: slide.frontmatter.maskStyle || "solid",
          };
          // FSM-9 优化：后退进入历史页时，遮罩与逐步呈现处于全部揭开完成状态，避免上一页重新变为全黑遮盖
          currentMaskStep = (direction === "backward") ? currentMaskConfig.totalSteps : 0;
        } else {
          currentMaskConfig = null;
          currentMaskStep = 0;
        }

        function createMaskElements() {
          if (!currentMaskConfig) return null;
          const layer = document.createElement("div");
          layer.className = "slides-mask-layer slides-mask-layer--" + currentMaskConfig.style + " slides-mask-layer--" + currentMaskConfig.direction + (currentMaskConfig.isClock ? " slides-mask-layer--clock" : "");
          const overlay = document.createElement("div");
          overlay.className = "slides-mask-overlay";
          const divider = document.createElement("div");
          divider.className = "slides-mask-divider-line" + (currentMaskConfig.isClock ? " slides-mask-divider-line--clock" : "");
          divider.style.opacity = "0";
          if (currentMaskConfig.isClock) {
            const isCw = currentMaskConfig.direction === "clockwise" || currentMaskConfig.direction === "cw";
            divider.style.transform = isCw ? "translateY(-50%) rotate(-180deg)" : "translateY(-50%) rotate(-90deg)";
          }
          layer.appendChild(overlay);
          layer.appendChild(divider);
          maskLayerEl = layer;
          maskOverlayEl = overlay;
          maskDividerEl = divider;
          return { layer, overlay, divider };
        }

        if (slide.frontmatter?.layout === "two-cols") {
          const bodyWrap = document.createElement("div");
          bodyWrap.className = "slides-mask-body-container" + (currentMaskConfig ? " slides-mask-body-container--has-mask" : "");
          bodyWrap.style.display = "flex";
          bodyWrap.style.flexDirection = "row";
          bodyWrap.style.gap = "2rem";
          bodyWrap.style.width = "100%";
          bodyWrap.style.height = "100%";

          const leftCol = document.createElement("div");
          leftCol.className = "two-cols-left";
          const rightCol = document.createElement("div");
          rightCol.className = "two-cols-right";

          const blocks = (slide.blocks || []).filter(b => b.slot !== "slot-divider-right");
          let leftList = [];
          let rightList = [];
          for (const block of blocks) {
            if (block.slot === "right") rightList.push(block);
            else leftList.push(block);
          }
          leftList = cleanColList(leftList);
          rightList = cleanColList(rightList);
          const isCover = slide.frontmatter?.layout === "cover";
          const leftFirstH = !isCover ? leftList.find(isHeadingBlock) : null;
          const rightFirstH = !isCover ? rightList.find(isHeadingBlock) : null;
          for (const b of leftList) leftCol.appendChild(renderBlock(b, b === leftFirstH ? "slides-col-first-heading-block" : ""));
          for (const b of rightList) rightCol.appendChild(renderBlock(b, b === rightFirstH ? "slides-col-first-heading-block" : ""));
          bodyWrap.appendChild(leftCol);
          bodyWrap.appendChild(rightCol);

          const maskEls = createMaskElements();
          if (maskEls) {
            bodyWrap.appendChild(maskEls.layer);
          }
          container.appendChild(bodyWrap);
        } else if (slide.frontmatter?.layout === "cols-header" || slide.frontmatter?.layout === "two-cols-header" || slide.frontmatter?.layout === "three-cols-header" || slide.frontmatter?.layout === "clover") {
          const isCover = slide.frontmatter?.layout === "cover";
          const isClover = slide.frontmatter?.layout === "clover";
          const blocks = (slide.blocks || []).filter(b => b.slot !== "slot-divider-right");
          let headerBlocks = blocks.filter(b => b.slot === "header");
          if (headerBlocks.length === 0 && blocks.length > 0) {
            const candidate = blocks.find(b => b.type === "h" && (!b.slot || b.slot === "default"));
            if (candidate) headerBlocks = [candidate];
          }
          const rem = blocks.filter(b => !headerBlocks.includes(b));

          let targetCols = isClover ? 4 : 2;
          if (isClover) {
            targetCols = 4;
          } else if (slide.frontmatter?.layout === "three-cols-header") {
            targetCols = 3;
          } else if (slide.frontmatter?.layout === "two-cols-header") {
            targetCols = 2;
          } else {
            let maxCol = 0;
            for (const b of rem) {
              const m = (b.slot || "").match(/^col-(d+)$/i);
              if (m) maxCol = Math.max(maxCol, parseInt(m[1], 10));
            }
            if (maxCol >= 2) {
              targetCols = maxCol;
            } else if (slide.frontmatter?.layoutRatio) {
              const r = slide.frontmatter.layoutRatio.trim();
              if (r.includes(":")) {
                const parts = r.split(":").map(p => parseFloat(p.trim())).filter(n => !isNaN(n) && n > 0);
                if (parts.length >= 2) targetCols = parts.length;
              }
            }
          }

          const hasColSlots = rem.some(b => b.slot && /^col-d+$/i.test(b.slot));
          const isSuperBlockCols = isClover || hasColSlots;

          const containerDiv = document.createElement("div");
          containerDiv.className = (isClover ? "layout-clover-container" : ("layout-cols-header-container " + (targetCols === 2 ? "layout-two-cols-header-container" : (targetCols === 3 ? "layout-three-cols-header-container" : "")))) + (isSuperBlockCols ? " has-superblock-cols" : "");
          const headerDiv = document.createElement("div");
          headerDiv.className = "layout-header-section";
          const gridDiv = document.createElement("div");
          gridDiv.className = (isClover ? "layout-clover-grid pdf-clover-wrapper" : ("layout-cols-wrapper layout-cols-grid " + (targetCols === 2 ? "pdf-two-cols-wrapper layout-two-cols-grid" : (targetCols === 3 ? "pdf-three-cols-wrapper layout-three-cols-grid" : "")))) + (isSuperBlockCols ? " has-superblock-cols" : "") + (currentMaskConfig ? " slides-mask-body-container slides-mask-body-container--has-mask" : "");

          const gridCols = isClover ? "repeat(2, minmax(0, 1fr))" : parseRatioToGridCols(slide.frontmatter?.layoutRatio, targetCols);
          if (gridCols) gridDiv.style.gridTemplateColumns = gridCols;
          if (isClover) gridDiv.style.gridTemplateRows = "repeat(2, minmax(0, 1fr))";

          let colsList = [];
          for (let i = 0; i < targetCols; i++) colsList.push([]);
          const hasExplicitCols = rem.some(b => b.slot && (b.slot.startsWith("col-") || b.slot === "left" || b.slot === "right" || b.slot === "center"));
          if (hasExplicitCols && rem.length > 1) {
            for (const b of rem) {
              let idx = 0;
              if (b.slot === "left" || b.slot === "col-1") idx = 0;
              else if (b.slot === "center" || b.slot === "col-2") idx = 1;
              else if (b.slot === "right") idx = targetCols === 2 ? 1 : targetCols - 1;
              else {
                const m = (b.slot || "").match(/^col-(d+)$/i);
                if (m) idx = Math.min(targetCols - 1, Math.max(0, parseInt(m[1], 10) - 1));
              }
              colsList[idx].push(b);
            }
            const hasExplicitColN = rem.some(b => /^col-d+$/i.test((b.slot || "").trim()));
            if (!hasExplicitColN && colsList[0].length === 0) {
              const nonEmptyCols = colsList.filter(c => c.length > 0);
              if (nonEmptyCols.length === 1) {
                colsList = [nonEmptyCols[0], ...Array.from({ length: targetCols - 1 }, () => [])];
              }
            }
          } else if (rem.length === 1) {
            colsList[0] = [rem[0]];
          } else {
            let cur = 0;
            for (let i = 0; i < targetCols; i++) {
              const remainingCols = targetCols - i;
              const remainingItems = rem.length - cur;
              const take = Math.ceil(remainingItems / remainingCols);
              colsList[i] = rem.slice(cur, cur + take);
              cur += take;
            }
          }

          const headerFirstH = !isCover ? headerBlocks.find(isHeadingBlock) : null;
          for (const b of headerBlocks) headerDiv.appendChild(renderBlock(b, b === headerFirstH ? "slides-page-first-heading-block" : ""));
          containerDiv.appendChild(headerDiv);

          colsList.forEach((colBlocks, idx) => {
            const colDiv = document.createElement("div");
            colDiv.className = "pdf-col pdf-col--" + (idx + 1) + " col-" + (idx + 1) + (targetCols === 2 && idx === 0 ? " pdf-col--left" : "") + (targetCols === 2 && idx === 1 ? " pdf-col--right" : "");
            const cleaned = cleanColList(colBlocks);
            const colFirstH = !isCover ? (cleaned.find(isHeadingBlock) || cleaned[0]) : null;
            for (const b of cleaned) colDiv.appendChild(renderBlock(b, b === colFirstH ? "slides-col-first-heading-block" : ""));
            gridDiv.appendChild(colDiv);
          });

          const maskEls = createMaskElements();
          if (maskEls) {
            gridDiv.appendChild(maskEls.layer);
          }

          containerDiv.appendChild(gridDiv);
          container.appendChild(containerDiv);
        } else if (slide.frontmatter?.layout === "image-right" || slide.frontmatter?.layout === "image-left") {
          const isImageRight = slide.frontmatter?.layout === "image-right";
          const isCover = slide.frontmatter?.layout === "cover";
          const allBlocks = slide.blocks || [];
          const pageFirstH = !isCover ? allBlocks.find(isHeadingBlock) : null;

          if (pageFirstH) {
            container.appendChild(renderBlock(pageFirstH, "slides-page-first-heading-block"));
          }

          const bodyWrap = document.createElement("div");
          bodyWrap.className = "slides-mask-body-container" + (currentMaskConfig ? " slides-mask-body-container--has-mask" : "");
          bodyWrap.style.display = "flex";
          bodyWrap.style.flexDirection = isImageRight ? "row" : "row-reverse";
          bodyWrap.style.gap = "2rem";
          bodyWrap.style.width = "100%";
          bodyWrap.style.height = "100%";
          bodyWrap.style.minHeight = "0";
          bodyWrap.style.flex = "1";

          const contentCol = document.createElement("div");
          contentCol.className = isImageRight ? "image-right-content" : "image-left-content";

          for (const block of allBlocks) {
            if (block === pageFirstH) continue;
            contentCol.appendChild(renderBlock(block, ""));
          }

          const imgCol = document.createElement("div");
          imgCol.className = isImageRight ? "image-right-img-container" : "image-left-img-container";
          const img = document.createElement("img");
          img.className = isImageRight ? "image-right-img" : "image-left-img";
          img.src = slide.frontmatter?.image || slide.frontmatter?.background || "";
          img.alt = "Slide cover";
          img.onerror = function() {
            this.src = "https://fastly.jsdelivr.net/gh/slidevjs/slidev-covers@main/static/2HmfbSpvcos.webp";
          };
          imgCol.appendChild(img);

          bodyWrap.appendChild(contentCol);
          bodyWrap.appendChild(imgCol);

          const maskEls = createMaskElements();
          if (maskEls) {
            bodyWrap.appendChild(maskEls.layer);
          }
          container.appendChild(bodyWrap);
        } else {
          const isCover = slide.frontmatter?.layout === "cover";
          const validBlocks = (slide.blocks || []).filter(b => b.slot !== "slot-divider-right");
          const pageFirstH = !isCover ? validBlocks.find(isHeadingBlock) : null;

          if (pageFirstH) {
            container.appendChild(renderBlock(pageFirstH, "slides-page-first-heading-block"));
          }

          const bodyWrap = document.createElement("div");
          bodyWrap.className = "slides-mask-body-container" + (currentMaskConfig ? " slides-mask-body-container--has-mask" : "");

          for (const block of validBlocks) {
            if (block === pageFirstH) continue;
            bodyWrap.appendChild(renderBlock(block, ""));
          }

          const maskEls = createMaskElements();
          if (maskEls) {
            bodyWrap.appendChild(maskEls.layer);
          }
          container.appendChild(bodyWrap);
        }

        updateMaskVisual();
        if (currentMaskConfig && maskLayerEl) {
          requestAnimationFrame(() => {
            if (maskLayerEl) void maskLayerEl.offsetHeight;
          });
        }

        function syncAutoplayVideos() {
          const doSync = () => {
            const videos = container.querySelectorAll("video");
            videos.forEach((v) => {
              const box = v.closest("[data-autoplay]");
              const isAuto = v.hasAttribute("autoplay") || v.autoplay || (box && box.getAttribute("data-autoplay") === "true");
              if (isAuto) {
                v.muted = true;
                v.defaultMuted = true;
                v.setAttribute("muted", "");
                v.playsInline = true;
                v.setAttribute("playsinline", "");
                const playFn = () => {
                  if (!v.paused) return;
                  v.muted = true;
                  v.defaultMuted = true;
                  const p = v.play();
                  if (p !== undefined) {
                    p.catch(() => {
                      v.muted = true;
                      v.defaultMuted = true;
                      setTimeout(() => { if (v.paused) v.play().catch(() => {}); }, 150);
                    });
                  }
                };
                playFn();
                if (!v.__autoplayBound) {
                  v.__autoplayBound = true;
                  v.addEventListener("loadedmetadata", playFn);
                  v.addEventListener("canplay", playFn);
                }
              }
            });
          };
          setTimeout(doSync, 60);
          setTimeout(doSync, 200);
        }
        syncAutoplayVideos();
      }

      // Lightbox 控制逻辑
      const lightbox = document.getElementById("slides-lightbox");
      const lightboxContent = document.getElementById("lightbox-content");
      const lightboxClose = document.getElementById("lightbox-close");
      let isLightboxOpen = false;

`}function ug(){return`      let lightboxScale = 1.0;
      let lightboxTranslateX = 0;
      let lightboxTranslateY = 0;
      let isLightboxDragging = false;
      let lightboxDragStartX = 0;
      let lightboxDragStartY = 0;
      let lightboxInitialTx = 0;
      let lightboxInitialTy = 0;
      let lightboxHasMoved = false;
      let lightboxMediaType = "";

      function updateLightboxImgTransform(animate) {
        if (!lightboxContent) return;
        const img = lightboxContent.querySelector(".slides-lightbox-img");
        if (!img) return;
        img.style.transformOrigin = "center center";
        img.style.transform = "translate(" + lightboxTranslateX + "px, " + lightboxTranslateY + "px) scale(" + lightboxScale + ")";
        img.style.transition = animate ? "transform 0.12s cubic-bezier(0.16, 1, 0.3, 1)" : "none";
        img.style.cursor = lightboxScale > 1.0 ? (isLightboxDragging ? "grabbing" : "grab") : "zoom-in";
      }

      function resetLightboxZoom() {
        lightboxScale = 1.0;
        lightboxTranslateX = 0;
        lightboxTranslateY = 0;
        isLightboxDragging = false;
        lightboxHasMoved = false;
        updateLightboxImgTransform(false);
      }

      function openLightbox(type, src, alt) {
        if (!lightbox || !lightboxContent) return;
        lightboxContent.innerHTML = "";
        lightboxMediaType = type;
        resetLightboxZoom();
        if (type === "video") {
          const v = document.createElement("video");
          v.className = "slides-lightbox-video";
          v.src = src;
          v.controls = true;
          v.autoplay = true;
          v.playsInline = true;
          lightboxContent.appendChild(v);
        } else {
          const img = document.createElement("img");
          img.className = "slides-lightbox-img";
          img.src = src;
          img.alt = alt || "";
          lightboxContent.appendChild(img);
          updateLightboxImgTransform(false);
        }
        lightbox.classList.add("active");
        isLightboxOpen = true;
      }

      function closeLightbox() {
        if (!lightbox) return;
        const v = lightbox.querySelector("video");
        if (v) v.pause();
        lightbox.classList.remove("active");
        if (lightboxContent) lightboxContent.innerHTML = "";
        isLightboxOpen = false;
        lightboxMediaType = "";
        resetLightboxZoom();
      }

      function handleLightboxWheel(e) {
        if (!lightboxContent || lightboxMediaType !== "image") return;
        const img = lightboxContent.querySelector(".slides-lightbox-img");
        if (!img) return;
        e.preventDefault();
        e.stopPropagation();
        if (Math.abs(e.deltaY) < 1) return;

        const factor = e.deltaY < 0 ? 1.2 : 1 / 1.2;
        const currentScale = lightboxScale;
        let nextScale = currentScale * factor;

        if (nextScale <= 1.02) {
          resetLightboxZoom();
          return;
        }
        if (nextScale > 5.0) {
          nextScale = 5.0;
        }

        const rect = img.getBoundingClientRect();
        const currentCenterX = rect.left + rect.width / 2;
        const currentCenterY = rect.top + rect.height / 2;
        const origCenterX = currentCenterX - lightboxTranslateX;
        const origCenterY = currentCenterY - lightboxTranslateY;

        const nextTx = (e.clientX - origCenterX) * (1 - nextScale / currentScale) + lightboxTranslateX * (nextScale / currentScale);
        const nextTy = (e.clientY - origCenterY) * (1 - nextScale / currentScale) + lightboxTranslateY * (nextScale / currentScale);

        lightboxTranslateX = Math.round(nextTx * 10) / 10;
        lightboxTranslateY = Math.round(nextTy * 10) / 10;
        lightboxScale = Math.round(nextScale * 1000) / 1000;
        updateLightboxImgTransform(true);
      }

      if (lightboxContent) {
        lightboxContent.addEventListener("pointerdown", (e) => {
          if (e.button !== 0 || lightboxMediaType !== "image" || lightboxScale <= 1.0) return;
          const img = lightboxContent.querySelector(".slides-lightbox-img");
          if (!img || (e.target !== img && !img.contains(e.target))) return;
          e.preventDefault();
          e.stopPropagation();
          isLightboxDragging = true;
          lightboxDragStartX = e.clientX;
          lightboxDragStartY = e.clientY;
          lightboxInitialTx = lightboxTranslateX;
          lightboxInitialTy = lightboxTranslateY;
          lightboxHasMoved = false;
          if (img.setPointerCapture) {
            try { img.setPointerCapture(e.pointerId); } catch (_) {}
          }
          updateLightboxImgTransform(false);
        });

        window.addEventListener("pointermove", (e) => {
          if (!isLightboxDragging || lightboxMediaType !== "image") return;
          e.preventDefault();
          e.stopPropagation();
          const dx = e.clientX - lightboxDragStartX;
          const dy = e.clientY - lightboxDragStartY;
          if (Math.abs(dx) > 3 || Math.abs(dy) > 3) {
            lightboxHasMoved = true;
          }
          lightboxTranslateX = Math.round((lightboxInitialTx + dx) * 10) / 10;
          lightboxTranslateY = Math.round((lightboxInitialTy + dy) * 10) / 10;
          updateLightboxImgTransform(false);
        });

        const onLightboxPointerEnd = (e) => {
          if (!isLightboxDragging) return;
          isLightboxDragging = false;
          const img = lightboxContent ? lightboxContent.querySelector(".slides-lightbox-img") : null;
          if (img && img.releasePointerCapture) {
            try { img.releasePointerCapture(e.pointerId); } catch (_) {}
          }
          updateLightboxImgTransform(false);
        };
        window.addEventListener("pointerup", onLightboxPointerEnd);
        window.addEventListener("pointercancel", onLightboxPointerEnd);

        lightboxContent.addEventListener("dblclick", (e) => {
          if (lightboxMediaType !== "image") return;
          const img = lightboxContent.querySelector(".slides-lightbox-img");
          if (!img || (e.target !== img && !img.contains(e.target))) return;
          e.preventDefault();
          e.stopPropagation();
          if (lightboxScale > 1.05 || lightboxTranslateX !== 0 || lightboxTranslateY !== 0) {
            resetLightboxZoom();
          } else {
            const targetScale = 2.0;
            const rect = img.getBoundingClientRect();
            const currentCenterX = rect.left + rect.width / 2;
            const currentCenterY = rect.top + rect.height / 2;
            const origCenterX = currentCenterX - lightboxTranslateX;
            const origCenterY = currentCenterY - lightboxTranslateY;
            lightboxTranslateX = Math.round(((e.clientX - origCenterX) * (1 - targetScale / 1.0)) * 10) / 10;
            lightboxTranslateY = Math.round(((e.clientY - origCenterY) * (1 - targetScale / 1.0)) * 10) / 10;
            lightboxScale = targetScale;
            updateLightboxImgTransform(true);
          }
        });
      }

      if (lightboxClose) {
        lightboxClose.addEventListener("click", (e) => {
          e.stopPropagation();
          closeLightbox();
        });
      }
      if (lightbox) {
        lightbox.addEventListener("click", (e) => {
          if (e.target === lightbox || e.target === lightboxClose) {
            if (lightboxHasMoved) {
              lightboxHasMoved = false;
              return;
            }
            e.stopPropagation();
            closeLightbox();
          }
        });
      }

      btnPrev.addEventListener("click", () => goPrev());
      btnNext.addEventListener("click", () => goNext());
      btnFullscreen.addEventListener("click", () => {
        if (!document.fullscreenElement) {
          document.documentElement.requestFullscreen().then(() => updateScale()).catch(() => {});
        } else {
          document.exitFullscreen().then(() => updateScale()).catch(() => {});
        }
      });

      // 「数字+回车」跳页输入状态：数字缓冲实时回显，Esc/超时清空，越界红色抖动提示
      let jumpDisplay = "";
      let jumpInvalid = false;
      let jumpIdleTimer = null;
      let jumpFlashTimer = null;

`}function fg(){return`      function hideJumpIndicator() {
        jumpDisplay = "";
        jumpInvalid = false;
        jumpBadge.style.display = "none";
        jumpBadge.classList.remove("is-invalid");
        if (jumpIdleTimer) { clearTimeout(jumpIdleTimer); jumpIdleTimer = null; }
        if (jumpFlashTimer) { clearTimeout(jumpFlashTimer); jumpFlashTimer = null; }
      }

      function renderJumpBadge() {
        jumpBadge.textContent = jumpDisplay;
        jumpBadge.style.display = jumpDisplay ? "block" : "none";
        jumpBadge.classList.toggle("is-invalid", jumpInvalid);
      }

      function armJumpIdleTimer() {
        if (jumpIdleTimer) clearTimeout(jumpIdleTimer);
        jumpIdleTimer = setTimeout(hideJumpIndicator, 1500);
      }

      function flashJumpInvalid() {
        if (jumpIdleTimer) { clearTimeout(jumpIdleTimer); jumpIdleTimer = null; }
        jumpInvalid = true;
        renderJumpBadge();
        if (jumpFlashTimer) clearTimeout(jumpFlashTimer);
        jumpFlashTimer = setTimeout(hideJumpIndicator, 500);
      }

      function isEditableKeyTarget(t) {
        if (!t || !t.tagName) return false;
        return t.tagName === "INPUT" || t.tagName === "TEXTAREA" || t.tagName === "SELECT" || t.isContentEditable === true;
      }

`}function pg(){return`      function getSlideOverviewTitle(slide) {
        const fm = slide?.frontmatter || {};
        if (fm.title) return String(fm.title);
        const blocks = slide?.blocks || [];
        for (const b of blocks) {
          if (b.type === "h" || /^h[1-6]$/i.test(b.subType || "")) {
            const md = (b.rawMarkdown || b.content || "").trim();
            return md.replace(/^#{1,6}s+/, "").replace(/[*_\`]/g, "").slice(0, 40);
          }
        }
        return "";
      }

      // 把任意一页渲染为静态缩略图：复用 renderBlock 与主渲染同名版式类，导出样式自动生效
      function buildOverviewThumbInto(canvas, slide) {
        const fm = slide.frontmatter || {};
        const layout = fm.layout || "default";
        const blocks = (slide.blocks || []).filter((b) => b.slot !== "slot-divider-right");
        let headerBlocks = blocks.filter((b) => b.slot === "header");
        if (headerBlocks.length === 0 && blocks.length > 0) {
          const candidate = blocks.find((b) => b.type === "h" && (!b.slot || b.slot === "default"));
          if (candidate) headerBlocks = [candidate];
        }
        const rem = blocks.filter((b) => !headerBlocks.includes(b));
        let bodyEl = null;

        if (layout === "cols-header" || layout === "two-cols-header" || layout === "three-cols-header" || layout === "clover") {
          const isClover = layout === "clover";
          let targetCols = isClover ? 4 : 2;
          if (layout === "three-cols-header") targetCols = 3;
          else if (layout === "two-cols-header") targetCols = 2;
          else if (!isClover) {
            let maxCol = 0;
            for (const b of rem) {
              const m = (b.slot || "").match(/^col-(d+)$/i);
              if (m) maxCol = Math.max(maxCol, parseInt(m[1], 10));
            }
            if (maxCol >= 2) targetCols = maxCol;
            else if (fm.layoutRatio) {
              const r = String(fm.layoutRatio).trim();
              if (r.includes(":")) {
                const parts = r.split(":").map((p) => parseFloat(p.trim())).filter((n) => !isNaN(n) && n > 0);
                if (parts.length >= 2) targetCols = parts.length;
              }
            }
          }
          const hasColSlots = rem.some((b) => b.slot && /^col-d+$/i.test(b.slot));
          const containerDiv = document.createElement("div");
          containerDiv.className = (isClover ? "layout-clover-container" : ("layout-cols-header-container " + (targetCols === 2 ? "layout-two-cols-header-container" : (targetCols === 3 ? "layout-three-cols-header-container" : "")))) + (hasColSlots || isClover ? " has-superblock-cols" : "");
          const headerDiv = document.createElement("div");
          headerDiv.className = "layout-header-section";
          for (const b of headerBlocks) headerDiv.appendChild(renderBlock(b, ""));
          containerDiv.appendChild(headerDiv);
          const gridDiv = document.createElement("div");
          gridDiv.className = (isClover ? "layout-clover-grid pdf-clover-wrapper" : ("layout-cols-wrapper layout-cols-grid " + (targetCols === 2 ? "pdf-two-cols-wrapper layout-two-cols-grid" : (targetCols === 3 ? "pdf-three-cols-wrapper layout-three-cols-grid" : "")))) + (hasColSlots || isClover ? " has-superblock-cols" : "");
          const gridCols = isClover ? "repeat(2, minmax(0, 1fr))" : parseRatioToGridCols(fm.layoutRatio, targetCols);
          if (gridCols) gridDiv.style.gridTemplateColumns = gridCols;
          if (isClover) gridDiv.style.gridTemplateRows = "repeat(2, minmax(0, 1fr))";
          let colsList = [];
          for (let i = 0; i < targetCols; i++) colsList.push([]);
          const hasExplicitCols = rem.some((b) => b.slot && (b.slot.startsWith("col-") || b.slot === "left" || b.slot === "right" || b.slot === "center"));
          if (hasExplicitCols && rem.length > 1) {
            for (const b of rem) {
              let idx = 0;
              if (b.slot === "left" || b.slot === "col-1") idx = 0;
              else if (b.slot === "center" || b.slot === "col-2") idx = 1;
              else if (b.slot === "right") idx = targetCols === 2 ? 1 : targetCols - 1;
              else {
                const m = (b.slot || "").match(/^col-(d+)$/i);
                if (m) idx = Math.min(targetCols - 1, Math.max(0, parseInt(m[1], 10) - 1));
              }
              colsList[idx].push(b);
            }
            const hasExplicitColN = rem.some(b => /^col-d+$/i.test((b.slot || "").trim()));
            if (!hasExplicitColN && colsList[0].length === 0) {
              const nonEmptyCols = colsList.filter(c => c.length > 0);
              if (nonEmptyCols.length === 1) {
                colsList = [nonEmptyCols[0], ...Array.from({ length: targetCols - 1 }, () => [])];
              }
            }
          } else if (rem.length === 1) {
            colsList[0] = [rem[0]];
          } else {
            let cur = 0;
            for (let i = 0; i < targetCols; i++) {
              const remainingCols = targetCols - i;
              const remainingItems = rem.length - cur;
              const take = Math.ceil(remainingItems / remainingCols);
              colsList[i] = rem.slice(cur, cur + take);
              cur += take;
            }
          }
          colsList.forEach((colBlocks, idx) => {
            const colDiv = document.createElement("div");
            colDiv.className = "pdf-col pdf-col--" + (idx + 1) + " col-" + (idx + 1) + (targetCols === 2 && idx === 0 ? " pdf-col--left" : "") + (targetCols === 2 && idx === 1 ? " pdf-col--right" : "");
            const cleaned = cleanColList(colBlocks);
            for (const b of cleaned) colDiv.appendChild(renderBlock(b, ""));
            gridDiv.appendChild(colDiv);
          });
          containerDiv.appendChild(gridDiv);
          bodyEl = containerDiv;
        } else if (layout === "two-cols") {
          bodyEl = document.createElement("div");
          bodyEl.style.display = "flex";
          bodyEl.style.flexDirection = "row";
          bodyEl.style.gap = "2rem";
          bodyEl.style.width = "100%";
          bodyEl.style.flex = "1";
          bodyEl.style.minHeight = "0";
          let leftList = [];
          let rightList = [];
          for (const b of blocks) {
            if (b.slot === "right") rightList.push(b);
            else leftList.push(b);
          }
          const leftCol = document.createElement("div");
          leftCol.className = "two-cols-left";
          const rightCol = document.createElement("div");
          rightCol.className = "two-cols-right";
          for (const b of cleanColList(leftList)) leftCol.appendChild(renderBlock(b, ""));
          for (const b of cleanColList(rightList)) rightCol.appendChild(renderBlock(b, ""));
          bodyEl.appendChild(leftCol);
          bodyEl.appendChild(rightCol);
        } else if (layout === "image-right" || layout === "image-left") {
          const isImageRight = layout === "image-right";
          bodyEl = document.createElement("div");
          bodyEl.style.display = "flex";
          bodyEl.style.flexDirection = isImageRight ? "row" : "row-reverse";
          bodyEl.style.gap = "2rem";
          bodyEl.style.width = "100%";
          bodyEl.style.flex = "1";
          bodyEl.style.minHeight = "0";
          const contentCol = document.createElement("div");
          contentCol.className = isImageRight ? "image-right-content" : "image-left-content";
          for (const b of blocks) contentCol.appendChild(renderBlock(b, ""));
          const imgCol = document.createElement("div");
          imgCol.className = isImageRight ? "image-right-img-container" : "image-left-img-container";
          const url = fm.image || fm.background || "";
          if (url) {
            const img = document.createElement("img");
            img.className = isImageRight ? "image-right-img" : "image-left-img";
            img.src = url;
            img.alt = "Slide cover";
            imgCol.appendChild(img);
          }
          bodyEl.appendChild(contentCol);
          bodyEl.appendChild(imgCol);
        } else {
          bodyEl = document.createElement("div");
          for (const b of blocks) bodyEl.appendChild(renderBlock(b, ""));
        }
        canvas.appendChild(bodyEl);
      }

      function buildOverviewCards() {
        if (overviewBuilt) return;
        overviewBuilt = true;
        const scale = OVERVIEW_CARD_W / baseWidth;
        const canvasH = Math.round(baseHeight * scale);
        slides.forEach((slide, idx) => {
          const card = document.createElement("div");
          card.className = "slides-overview-card";
          card.dataset.idx = String(idx);
          const box = document.createElement("div");
          box.className = "slides-overview-canvas-box";
          box.style.height = canvasH + "px";
          const fm = slide.frontmatter || {};
          const spacing = (fm.spacing && fm.spacing !== "inherit") ? fm.spacing : ((data.config && data.config.spacing) || "normal");
          const canvas = document.createElement("div");
          canvas.className = "slides-overview-canvas slide-content layout-" + (fm.layout || "default") + " spacing-" + spacing;
          canvas.style.width = baseWidth + "px";
          canvas.style.height = baseHeight + "px";
          canvas.style.transform = "scale(" + scale + ")";
          const bg = fm.background || (data.config && data.config.background);
          if (bg) {
            if (/^(http|/|data:|assets/)/.test(bg)) {
              canvas.style.backgroundImage = 'url("' + bg + '")';
              canvas.style.backgroundSize = "cover";
              canvas.style.backgroundPosition = "center";
            } else {
              canvas.style.background = bg;
            }
          }
          box.appendChild(canvas);
          const caption = document.createElement("div");
          caption.className = "slides-overview-caption";
          const pageNo = document.createElement("span");
          pageNo.className = "slides-overview-page-no";
          pageNo.textContent = String(idx + 1);
          caption.appendChild(pageNo);
          const title = getSlideOverviewTitle(slide);
          if (title) {
            const titleEl = document.createElement("span");
            titleEl.className = "slides-overview-title";
            titleEl.textContent = title;
            caption.appendChild(titleEl);
          }
          card.appendChild(box);
          card.appendChild(caption);
          card.addEventListener("click", (e) => {
            e.stopPropagation();
            goFromOverview(idx + 1);
          });
          overviewGrid.appendChild(card);
        });
        updateOverviewCurrentMark();
      }

      function renderOverviewThumb(card) {
        if (!card || card.dataset.rendered === "1") return;
        const idx = Number(card.dataset.idx);
        const slide = slides[idx];
        const canvas = card.querySelector(".slides-overview-canvas");
        if (slide && canvas) buildOverviewThumbInto(canvas, slide);
        card.dataset.rendered = "1";
      }

      function ensureOverviewObserver() {
        if (overviewObserver || typeof window.IntersectionObserver !== "function") return;
        overviewObserver = new IntersectionObserver((entries) => {
          for (const en of entries) {
            if (!en.isIntersecting) continue;
            overviewObserver.unobserve(en.target);
            renderOverviewThumb(en.target);
          }
        }, { rootMargin: "240px" });
      }

      function observeOverviewCards() {
        if (!overviewObserver) return;
        const cards = overviewGrid.children;
        for (let i = 0; i < cards.length; i++) {
          if (cards[i].dataset.rendered !== "1") overviewObserver.observe(cards[i]);
        }
      }

      function updateOverviewCurrentMark() {
        const cards = overviewGrid.children;
        for (let i = 0; i < cards.length; i++) {
          const pageNo = cards[i].querySelector(".slides-overview-page-no");
          if (pageNo) pageNo.classList.toggle("is-current", i === currentIndex);
        }
      }

      function setOverviewFocus(page) {
        const total = slides.length || 1;
        overviewFocus = Math.min(Math.max(1, page), total);
        const cards = overviewGrid.children;
        for (let i = 0; i < cards.length; i++) {
          cards[i].classList.toggle("is-active", i + 1 === overviewFocus);
        }
        const el = cards[overviewFocus - 1];
        if (el && el.scrollIntoView) el.scrollIntoView({ block: "nearest", behavior: "smooth" });
      }

      function getOverviewCols() {
        if (!overviewGrid || !overviewGrid.clientWidth) return 1;
        return Math.max(1, Math.round(overviewGrid.clientWidth / (OVERVIEW_CARD_W + 18)));
      }

      function goFromOverview(page) {
        const p = parseInt(page, 10);
        if (isNaN(p) || p < 1 || p > slides.length) return;
        closeOverview();
        renderSlide(p - 1);
        updateOverviewCurrentMark();
      }

      function openOverview() {
        if (slides.length === 0) return;
        buildOverviewCards();
        overviewOpen = true;
        overviewOverlay.style.display = "block";
        ensureOverviewObserver();
        if (overviewObserver) {
          observeOverviewCards();
        } else {
          const cards = overviewGrid.children;
          for (let i = 0; i < cards.length; i++) renderOverviewThumb(cards[i]);
        }
        setOverviewFocus(currentIndex + 1);
      }

      function closeOverview() {
        overviewOpen = false;
        overviewOverlay.style.display = "none";
        hideJumpIndicator();
        if (overviewObserver) {
          const cards = overviewGrid.children;
          for (let i = 0; i < cards.length; i++) overviewObserver.unobserve(cards[i]);
        }
      }

      function toggleOverview() {
        if (overviewOpen) closeOverview();
        else openOverview();
      }

      // 总览打开期间接管全部按键：修复上游总览中空格/PGUP/PGDN 仍会翻页的漏洞
      function handleOverviewKeyDown(e) {
        if (e.ctrlKey || e.metaKey || e.altKey) return;
        if (e.isComposing || isEditableKeyTarget(e.target)) return;
        if (/^[0-9]$/.test(e.key)) {
          if (!jumpInvalid && jumpDisplay.length < 4) {
            jumpDisplay += e.key;
            const p = parseInt(jumpDisplay, 10);
            if (!isNaN(p) && p >= 1 && p <= slides.length) setOverviewFocus(p);
            renderJumpBadge();
            armJumpIdleTimer();
          }
          e.preventDefault();
          return;
        }
        if (e.key === "Enter" && jumpDisplay) {
          if (!jumpInvalid) {
            const page = parseInt(jumpDisplay, 10);
            if (!isNaN(page) && page >= 1 && page <= slides.length) {
              goFromOverview(page);
            } else {
              flashJumpInvalid();
            }
          }
          e.preventDefault();
          return;
        }
        if ((e.key === "Escape" || e.key === "Esc") && (jumpDisplay || jumpInvalid)) {
          hideJumpIndicator();
          e.preventDefault();
          return;
        }
        if (e.key === "ArrowRight") {
          e.preventDefault();
          setOverviewFocus(overviewFocus + 1);
          return;
        }
        if (e.key === "ArrowLeft") {
          e.preventDefault();
          setOverviewFocus(overviewFocus - 1);
          return;
        }
        if (e.key === "ArrowDown" || e.key === "PageDown") {
          e.preventDefault();
          setOverviewFocus(overviewFocus + getOverviewCols());
          return;
        }
        if (e.key === "ArrowUp" || e.key === "PageUp") {
          e.preventDefault();
          setOverviewFocus(overviewFocus - getOverviewCols());
          return;
        }
        if (e.key === " ") {
          e.preventDefault();
          return;
        }
        if (e.key === "Enter") {
          e.preventDefault();
          goFromOverview(overviewFocus);
          return;
        }
        if (e.key === "Escape" || e.key === "Esc" || e.key === "o" || e.key === "O") {
          e.preventDefault();
          closeOverview();
        }
      }

      window.addEventListener("keydown", (e) => {
        if (e.key === "Escape" || e.key === "Esc") {
          if (isLightboxOpen) {
            closeLightbox();
            e.preventDefault();
            return;
          }
        }
        if (isLightboxOpen) return;
        // 总览打开期间全部按键由总览层接管
        if (overviewOpen) {
          handleOverviewKeyDown(e);
          return;
        }
        // 「数字+回车」跳页：可输入元素、修饰键、IME 组合输入中不拦截
        if (!e.ctrlKey && !e.metaKey && !e.altKey && !e.isComposing && !isEditableKeyTarget(e.target)) {
          if (/^[0-9]$/.test(e.key)) {
            if (!jumpInvalid && jumpDisplay.length < 4) {
              jumpDisplay += e.key;
              renderJumpBadge();
              armJumpIdleTimer();
            }
            e.preventDefault();
            return;
          }
          if (e.key === "Enter" && jumpDisplay) {
            if (!jumpInvalid) {
              const page = parseInt(jumpDisplay, 10);
              if (!isNaN(page) && page >= 1 && page <= slides.length) {
                hideJumpIndicator();
                renderSlide(page - 1);
              } else {
                flashJumpInvalid();
              }
            }
            e.preventDefault();
            return;
          }
          if ((e.key === "Escape" || e.key === "Esc") && (jumpDisplay || jumpInvalid)) {
            hideJumpIndicator();
            e.preventDefault();
            return;
          }
          if (e.key === "o" || e.key === "O") {
            e.preventDefault();
            toggleOverview();
            return;
          }
        }
        if (e.key === "ArrowRight" || e.key === " " || e.key === "ArrowDown") goNext();
        if (e.key === "ArrowLeft" || e.key === "ArrowUp") goPrev();
        if (e.key === "f" || e.key === "F") btnFullscreen.click();
      });

      // 监听鼠标滚轮上下翻页调度
      let lastWheelTime = 0;
      const WHEEL_COOLDOWN_MS = 280;
      const WHEEL_DELTA_THRESHOLD = 15;

`}function hg(){return`      function canElementScrollY(el, deltaY) {
        let cur = el;
        while (cur && cur !== document.body && cur !== document.documentElement) {
          if (cur.classList && (cur.classList.contains("slides-viewport") || cur.classList.contains("slides-stage") || cur.classList.contains("slide-container"))) {
            break;
          }
          const style = window.getComputedStyle(cur);
          const overflowY = style.overflowY;
          if (overflowY === "auto" || overflowY === "scroll") {
            const maxScroll = cur.scrollHeight - cur.clientHeight;
            if (maxScroll > 2) {
              if (deltaY > 0 && cur.scrollTop < maxScroll - 1) return true;
              if (deltaY < 0 && cur.scrollTop > 1) return true;
            }
          }
          cur = cur.parentElement;
        }
        return false;
      }

      window.addEventListener("wheel", (e) => {
        if (isLightboxOpen) {
          if (typeof handleLightboxWheel === "function") {
            handleLightboxWheel(e);
          }
          return;
        }
        // 总览打开时滚轮交给总览列表原生滚动，不触发翻页
        if (overviewOpen) return;
        if (Math.abs(e.deltaY) < Math.abs(e.deltaX)) return;
        if (Math.abs(e.deltaY) < WHEEL_DELTA_THRESHOLD) return;

        const target = e.target instanceof Element ? e.target : e.target?.parentElement;
        if (target && canElementScrollY(target, e.deltaY)) return;

        e.preventDefault();
        const now = Date.now();
        if (now - lastWheelTime < WHEEL_COOLDOWN_MS) return;
        lastWheelTime = now;

        if (e.deltaY > 0) {
          goNext();
        } else {
          goPrev();
        }
      }, { passive: false });

      document.addEventListener("click", (e) => {
        if (isLightboxOpen) {
          if (typeof lightboxHasMoved !== "undefined" && lightboxHasMoved) {
            lightboxHasMoved = false;
            e.stopPropagation();
            return;
          }
          const target = e.target instanceof Element ? e.target : e.target?.parentElement;
          const isMediaItself = target && target.closest && target.closest(".slides-lightbox-img, .slides-lightbox-video");
          if (!isMediaItself) {
            e.stopPropagation();
            closeLightbox();
          }
          return;
        }
        // 总览打开时空白点击由总览层自身处理，不触发底层翻页
        if (overviewOpen) return;
        if (e.button !== 0) return;
        const targetEl = e.target instanceof Element ? e.target : e.target?.parentElement;
        if (!targetEl || !targetEl.closest) return;

        const hasPendingMask = currentMaskConfig && (currentMaskStep < currentMaskConfig.totalSteps);
        if (hasPendingMask) {
          const isBottomControls = targetEl.closest(".controls-bar, .controls, .slides-toc");
          if (isBottomControls) return;
          e.preventDefault();
          e.stopPropagation();
          goNext();
          return;
        }

        const refEl = targetEl.closest("[data-ref-id]");
        if (refEl) {
          const id = refEl.getAttribute("data-ref-id");
          if (id) {
            window.open("siyuan://blocks/" + id, "_blank");
            return;
          }
        }

        // 媒体点击唤起 Lightbox 放大模态
        const mediaEl = targetEl.closest(".slide-content img, .slide-content video");
        if (mediaEl && !mediaEl.closest(".controls, .controls-bar, button, a")) {
          e.stopPropagation();
          const isVideo = mediaEl.tagName.toLowerCase() === "video";
          const src = isVideo ? (mediaEl.currentSrc || mediaEl.src || mediaEl.querySelector("source")?.src) : mediaEl.src;
          if (src) {
            openLightbox(isVideo ? "video" : "image", src, mediaEl.alt || "");
            return;
          }
        }

        const selection = window.getSelection ? window.getSelection().toString().trim() : "";
        if (selection.length > 0) return;

        const isComponent = targetEl.closest(
          ".slide-block, .controls-bar, .image-right-img-container, .image-left-img-container, .controls, img, video, audio, button, a, input, textarea, select, [data-clickable], [data-ref-id], .slides-toc, .empty-state"
        );
        if (isComponent) return;

        const isLeft = e.clientX < window.innerWidth / 2;
        if (isLeft) {
          goPrev();
        } else {
          goNext();
        }
      });

      renderSlide(0);
      updateScale();
    })();`}function mg(){return[rg(),ag(),lg(),cg(),dg(),ug(),fg(),pg(),hg()].join("")}function Xl(e,t){const i=(t==null?void 0:t.title)||"即现演示文稿";let n=e.slides;if(t!=null&&t.inlineAssetBase64Map&&Object.keys(t.inlineAssetBase64Map).length>0){const a=t.inlineAssetBase64Map;n=e.slides.map(r=>{let l=r.rawMarkdown;for(const[f,d]of Object.entries(a))l.includes(f)&&(l=l.split(f).join(d));const c=r.blocks.map(f=>{let d=f.rawMarkdown;for(const[p,w]of Object.entries(a))d.includes(p)&&(d=d.split(p).join(w));return{...f,rawMarkdown:d}});let u=r.frontmatter?{...r.frontmatter}:r.frontmatter;if(u){if(typeof u.background=="string")for(const[f,d]of Object.entries(a))u.background.includes(f)&&(u.background=u.background.split(f).join(d));if(typeof u.image=="string")for(const[f,d]of Object.entries(a))u.image.includes(f)&&(u.image=u.image.split(f).join(d))}return{...r,rawMarkdown:l,blocks:c,frontmatter:u}})}const s=JSON.stringify(n),o=JSON.stringify(e.config);return`<!DOCTYPE html>
<html lang="zh-CN">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${ot(i)}</title>
  <style>
${og(t==null?void 0:t.customInlineStyles)}
  </style>
  <script>
    // 注入演示数据载荷
    window.__SLIDES_DATA__ = {
      docId: ${JSON.stringify(e.docId)},
      slides: ${s},
      config: ${o}
    };
  <\/script>
</head>
<body>
  <div id="app" data-normalize-headings="${e.config.normalizeHeadingSizes?"true":"false"}" data-hide-unordered-markers="${e.config.showUnorderedListMarkers===!1?"true":"false"}" data-hide-ordered-markers="${e.config.showOrderedListMarkers===!1?"true":"false"}">
    <div class="slide-viewport slides-theme-${e.config.theme||"default"}" id="viewport" data-slides-theme="${e.config.theme||"default"}">
      <div class="slide-content" id="slide-container"></div>
    </div>
    <div class="controls">
      <button id="btn-prev">◀ 上一页</button>
      <span id="page-num">1 / 1</span>
      <button id="btn-next">下一页 ▶</button>
      <button id="btn-fullscreen">全屏</button>
    </div>
    <!-- 全屏媒体灯箱 (Lightbox) 模态窗口 -->
    <div id="slides-lightbox" class="slides-lightbox">
      <button class="slides-lightbox-close" id="lightbox-close" aria-label="关闭 (Esc)">✕</button>
      <div class="slides-lightbox-content" id="lightbox-content"></div>
    </div>
  </div>

  <script>
${mg()}
  <\/script>
</body>
</html>`}function Ql(e,t){if(typeof document>"u")return!1;const i=new Blob([t],{type:"text/html;charset=utf-8"}),n=URL.createObjectURL(i),s=document.createElement("a");return s.href=n,s.download=e.endsWith(".html")?e:`${e}.html`,document.body.appendChild(s),s.click(),document.body.removeChild(s),URL.revokeObjectURL(n),!0}function gg(e){switch(e){case"4:3":return"size: 12in 9in;";case"A4-landscape":return"size: 297mm 210mm;";case"A4-portrait":return"size: 210mm 297mm;";case"16:9":default:return"size: 16in 9in;"}}function vg(e){const t=gg(e==null?void 0:e.pageRatio);return`
    ${Rn(e==null?void 0:e.customInlineStyles)}

    @page {
      ${t}
      margin: 0;
    }
    * {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
      -webkit-print-color-adjust: exact !important;
      print-color-adjust: exact !important;
    }
    body {
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "PingFang SC", "Microsoft YaHei", sans-serif;
      background: #f8fafc;
      color: #1e293b;
    }
    .pdf-slide-page {
      width: 100vw;
      height: 100vh;
      page-break-after: always;
      break-after: page;
      padding: var(--slides-padding-y, 36px) var(--slides-padding-x, 56px);
      display: flex;
      flex-direction: column;
      position: relative;
      background: #ffffff;
      overflow: hidden;
    }
    .pdf-slide-page.spacing-compact {
      --slides-padding-y: 20px;
      --slides-padding-x: 36px;
      --slides-header-gap: 10px;
      --slides-title-margin-bottom: 6px;
    }
    .pdf-slide-page.spacing-normal {
      --slides-padding-y: 36px;
      --slides-padding-x: 56px;
      --slides-header-gap: 16px;
      --slides-title-margin-bottom: 10px;
    }
    .pdf-slide-page.spacing-loose {
      --slides-padding-y: 48px;
      --slides-padding-x: 64px;
      --slides-header-gap: 24px;
      --slides-title-margin-bottom: 16px;
    }
    .pdf-slide-page.theme-dark {
      background: #0f1117;
      color: #f1f5f9;
    }
    .pdf-slide-header {
      font-size: 13px;
      color: #64748b;
      margin-bottom: 24px;
      display: flex;
      justify-content: space-between;
      border-bottom: 1px solid #e2e8f0;
      padding-bottom: 8px;
    }
    .theme-dark .pdf-slide-header {
      border-bottom-color: #2e3346;
      color: #94a3b8;
    }
    .pdf-slide-body {
      flex: 1;
      display: flex;
      flex-direction: column;
      gap: 16px;
      font-size: 20px;
      line-height: 1.6;
      overflow: hidden;
    }
    .pdf-block h1 { font-size: 2.5rem; font-weight: 800; color: #2563eb; margin-bottom: 12px; }
    .pdf-block h2 { font-size: 1.9rem; font-weight: 700; color: #1d4ed8; margin-bottom: 10px; }
    .pdf-block h3 { font-size: 1.4rem; font-weight: 600; margin-bottom: 8px; }
    .pdf-block h4 { font-size: 1.2rem; font-weight: 600; margin-bottom: 6px; }
    .pdf-block p { font-size: 1.15rem; color: inherit; }
    .pdf-code,
    pre {
      background: #f1f5f9;
      padding: 14px 18px;
      border-radius: 6px;
      font-family: "JetBrains Mono", Consolas, monospace;
      font-size: 0.95rem;
      border-left: 4px solid #3b82f6;
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      max-width: 100% !important;
      box-sizing: border-box !important;
    }
    .pdf-code code,
    pre code {
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      display: block !important;
      width: 100% !important;
      box-sizing: border-box !important;
    }
    .code-line {
      display: flex !important;
      align-items: flex-start !important;
      width: 100% !important;
      box-sizing: border-box !important;
      line-height: 1.6;
    }
    .code-line .line-no {
      display: inline-block !important;
      flex-shrink: 0 !important;
      min-width: 2.2em !important;
      text-align: right !important;
      margin-right: 12px !important;
      user-select: none !important;
      opacity: 0.45 !important;
    }
    .code-line .line-content {
      flex: 1 1 0% !important;
      min-width: 0 !important;
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
    }
    .theme-dark .pdf-code {
      background: #1e1e24;
      border-left-color: #60a5fa;
    }
    .pdf-quote {
      border-left: 4px solid #10b981;
      background: rgba(16, 185, 129, 0.08);
      padding: 10px 16px;
      border-radius: 0 4px 4px 0;
      font-style: italic;
    }
    .pdf-image,
    .slide-media-img {
      max-width: 100% !important;
      max-height: 48vh !important;
      width: auto !important;
      height: auto !important;
      object-fit: contain !important;
      border-radius: 6px;
      margin: auto;
      display: block;
    }
    .slide-media-block,
    .slide-media-container,
    .slide-video-container {
      display: flex;
      flex-direction: column;
      justify-content: center;
      align-items: center;
      width: 100%;
      max-height: 48vh;
      margin: 8px 0;
      overflow: hidden;
    }
    .slide-list-media {
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: flex-start;
      margin-top: 8px;
      margin-bottom: 6px;
      max-width: 100%;
      overflow: hidden;
    }
    .slide-list-media img,
    .slide-list-media video,
    .slide-list-media .list-item-gif {
      max-width: 100% !important;
      max-height: min(280px, 36vh) !important;
      width: auto !important;
      height: auto !important;
      min-width: 0 !important;
      min-height: 0 !important;
      object-fit: contain !important;
      border-radius: 6px;
      display: block;
      margin: 0 auto !important;
    }
    .slide-video-player {
      max-width: 100% !important;
      max-height: 48vh !important;
      width: auto !important;
      height: auto !important;
      object-fit: contain !important;
      border-radius: 6px;
      background: #000;
      border: 1px solid #cbd5e1;
    }
    .pdf-two-cols-wrapper,
    .layout-two-cols-grid,
    .layout-cols-wrapper,
    .layout-cols-grid {
      display: grid;
      grid-template-columns: minmax(0, 1fr) minmax(0, 1fr);
      grid-template-rows: minmax(0, 1fr) !important;
      gap: 36px;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      overflow: hidden !important;
    }
    .layout-cols-header-container,
    .layout-two-cols-header-container,
    .layout-three-cols-header-container,
    .layout-clover-container {
      display: flex;
      flex-direction: column;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      overflow: hidden !important;
    }
    .layout-header-section {
      width: 100%;
      margin-bottom: var(--slides-header-gap, 16px) !important;
      flex-shrink: 0;
    }
    .layout-header-section h1,
    .layout-header-section h2,
    .layout-header-section h3 {
      margin-bottom: var(--slides-title-margin-bottom, 10px) !important;
    }
    .pdf-three-cols-wrapper,
    .layout-three-cols-grid {
      display: grid;
      grid-template-columns: minmax(0, 1fr) minmax(0, 1fr) minmax(0, 1fr);
      grid-template-rows: minmax(0, 1fr) !important;
      gap: 24px;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      box-sizing: border-box;
      overflow: hidden !important;
    }
    .pdf-clover-wrapper,
    .layout-clover-grid {
      display: grid;
      grid-template-columns: repeat(2, minmax(0, 1fr)) !important;
      grid-template-rows: repeat(2, minmax(0, 1fr)) !important;
      gap: 20px;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      box-sizing: border-box;
      overflow: hidden !important;
    }
    .layout-clover-grid .pdf-col {
      background: transparent !important;
      border: none !important;
      box-shadow: none !important;
    }
    .pdf-col {
      display: flex;
      flex-direction: column;
      gap: 14px;
      min-width: 0;
      width: 100%;
      max-width: 100%;
      height: 100%;
      max-height: 100%;
      min-height: 0;
      justify-content: flex-start;
      overflow: hidden;
      box-sizing: border-box;
      overflow-wrap: break-word;
      word-break: break-word;
      white-space: normal;
    }
    /* 表头多栏内超级块子块首个列表项去圆点后居中显示标题/首行文本 (仅在存在超级块分栏时生效) */
    .has-superblock-cols .pdf-col > *:first-child .slide-list-item-title,
    .has-superblock-cols .pdf-col > *:first-child :is(h1, h2, h3, h4, h5, h6),
    .has-superblock-cols .pdf-col > *:first-child p.slide-list-item-title,
    .has-superblock-cols .pdf-col > *:first-child p:first-of-type,
    .has-superblock-cols .pdf-col > *:first-child p:first-child,
    .has-superblock-cols .pdf-col > *:first-child :is(ul, ol) > li:first-child,
    .has-superblock-cols .pdf-col > *:first-child .slide-list > .slide-list-item:first-child,
    .has-superblock-cols .pdf-col > *:first-child .pdf-list > li:first-child,
    .has-superblock-cols .slides-col-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    .has-superblock-cols .slides-col-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      list-style: none !important;
      list-style-type: none !important;
      text-align: center !important;
      margin-left: 0 !important;
      padding-left: 0 !important;
      width: 100% !important;
    }

    /* 彻底清除首个列表项的原生圆点 Marker (仅在存在超级块分栏时生效) */
    .has-superblock-cols .pdf-col > *:first-child :is(ul, ol) > li:first-child::marker {
      content: "" !important;
      display: none !important;
    }

    /* 确保首个列表项内部内联与块级元素居中 (仅在存在超级块分栏时生效) */
    .has-superblock-cols .pdf-col > *:first-child :is(ul, ol) > li:first-child * {
      text-align: center !important;
    }

    /* 栏内说明段落与列表项：左对齐，自然阅读排版 */
    .has-superblock-cols .pdf-col .slide-list-item-desc,
    .has-superblock-cols .pdf-col li:not(:first-child) {
      text-align: left !important;
    }

    /* 全局特定标题大小规范化 (除封面外页首首个标题按 H2 1.7rem，表头多栏内首个标题按 H3 1.3rem) */
    [data-normalize-headings="true"] .slides-page-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .slides-page-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .pdf-slide:not(.layout-cover) > :is(.pdf-block, .slide-block):first-child :is(h1, h2, h3, h4, h5, h6),
    [data-normalize-headings="true"] .pdf-slide:not(.layout-cover) > .layout-header-section :is(.pdf-block, .slide-block):first-child :is(h1, h2, h3, h4, h5, h6),
    [data-normalize-headings="true"] .pdf-slide:not(.layout-cover) > :not(.layout-cols-wrapper):not(.pdf-two-cols-wrapper):not(.layout-image-cols-grid):first-child :is(h1, h2, h3, h4, h5, h6) {
      font-size: 1.7rem !important;
      font-weight: 600 !important;
      line-height: 1.25 !important;
      margin-bottom: 10px !important;
    }

    [data-normalize-headings="true"] .has-superblock-cols .slides-col-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .has-superblock-cols .slides-col-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .has-superblock-cols .pdf-col > *:first-child :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      font-size: 1.3rem !important;
      font-weight: 600 !important;
      line-height: 1.3 !important;
      margin-bottom: 8px !important;
      text-align: center !important;
    }

    /* 图左与图右版式标题完全保留用户原始字号与默认排版，不进行任何固定大小规范化 */
    [data-normalize-headings="true"] :is(.layout-image-left, .layout-image-right, .image-left-content, .image-right-content) :is(h1, h2, h3, h4, h5, h6) {
      text-align: left !important;
    }
    .pdf-col > .pdf-block,
    .pdf-col > .slide-block {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      max-height: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      width: 100% !important;
      height: 100% !important;
      box-sizing: border-box !important;
      overflow: hidden !important;
    }
    .pdf-col .slide-list-item-title,
    .pdf-col h1, .pdf-col h2, .pdf-col h3, .pdf-col h4, .pdf-col h5, .pdf-col h6,
    .pdf-col .slide-list-item-desc {
      flex: 0 0 auto !important;
      margin-top: 0 !important;
      margin-bottom: 6px !important;
    }
    .pdf-col .slide-list-media,
    .pdf-col .slide-video-container,
    .pdf-col .slide-media-container {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      min-width: 0 !important;
      width: 100% !important;
      height: 100% !important;
      max-height: 100% !important;
      max-width: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
      justify-content: flex-start !important;
      overflow: hidden !important;
      margin: 0 !important;
      padding: 0 !important;
      box-sizing: border-box !important;
    }
    .pdf-col li:has(.slide-list-media),
    .pdf-col li:has(.slide-media-container),
    .pdf-col li:has(.slide-video-container),
    .pdf-col li:has(img),
    .pdf-col li:has(video),
    .pdf-col .pdf-list-item:has(.slide-list-media),
    .pdf-col .pdf-list-item:has(.slide-media-container),
    .pdf-col .pdf-list-item:has(.slide-video-container),
    .pdf-col .pdf-list-item:has(img),
    .pdf-col .pdf-list-item:has(video) {
      display: list-item !important;
      list-style-type: disc !important;
      flex: 0 0 auto !important;
      height: auto !important;
      max-height: none !important;
      overflow: visible !important;
      margin-bottom: 6px !important;
    }
    .pdf-col video,
    .layout-three-cols-grid video,
    .layout-two-cols-grid video,
    .pdf-col img,
    .layout-three-cols-grid img,
    .layout-two-cols-grid img,
    .pdf-col .slide-video-player {
      max-width: 100% !important;
      max-height: 100% !important;
      width: auto !important;
      height: auto !important;
      min-width: 0 !important;
      min-height: 0 !important;
      object-fit: contain !important;
      display: block !important;
      margin: 0 auto !important;
    }
    .pdf-col * {
      overflow-wrap: break-word;
      word-break: break-word;
      box-sizing: border-box;
    }
    .pdf-col pre {
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      max-width: 100% !important;
      box-sizing: border-box !important;
    }
    .pdf-list-item {
      padding-left: 20px;
    }
    .pdf-list {
      padding-left: 24px;
      margin: 8px 0;
      display: flex;
      flex-direction: column;
      gap: 6px;
    }
    .pdf-list li {
      font-size: 1.15rem;
      line-height: 1.6;
    }
    .pdf-task-item {
      list-style: none;
      margin-left: -20px;
      display: flex;
      align-items: center;
      gap: 8px;
    }
    .pdf-task-item input[type="checkbox"] {
      width: 1.15em;
      height: 1.15em;
      cursor: pointer;
    }
    /* 两栏与三栏及多栏（超级块分栏）布局：紧凑自然行距，子列表保留圆点与层级缩进 */
    .layout-two-cols ul,
    .layout-cols-header ul,
    .layout-two-cols-header ul,
    .layout-three-cols ul,
    .layout-three-cols-header ul,
    .two-cols-left ul,
    .two-cols-right ul,
    .three-cols-col ul,
    .col ul,
    .pdf-two-cols-wrapper ul,
    .pdf-three-cols-wrapper ul,
    .pdf-col ul,
    .layout-two-cols-grid .pdf-list,
    .layout-three-cols-grid .pdf-list,
    .layout-cols-grid .pdf-list,
    .layout-two-cols-grid .pdf-list--unordered,
    .layout-three-cols-grid .pdf-list--unordered,
    .layout-cols-grid .pdf-list--unordered {
      list-style: disc !important;
      list-style-type: disc !important;
      padding-left: 1.25em !important;
      margin-left: 0 !important;
      margin-top: 0 !important;
      margin-bottom: 8px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: block !important;
    }
    .layout-two-cols ol,
    .layout-cols-header ol,
    .layout-two-cols-header ol,
    .layout-three-cols ol,
    .layout-three-cols-header ol,
    .two-cols-left ol,
    .two-cols-right ol,
    .three-cols-col ol,
    .col ol,
    .pdf-two-cols-wrapper ol,
    .pdf-three-cols-wrapper ol,
    .pdf-col ol,
    .layout-two-cols-grid .pdf-list--ordered,
    .layout-three-cols-grid .pdf-list--ordered,
    .layout-cols-grid .pdf-list--ordered {
      list-style: decimal !important;
      list-style-type: decimal !important;
      padding-left: 1.25em !important;
      margin-left: 0 !important;
      margin-top: 0 !important;
      margin-bottom: 8px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: block !important;
    }
    .layout-two-cols li,
    .layout-cols-header li,
    .layout-two-cols-header li,
    .layout-three-cols li,
    .layout-three-cols-header li,
    .two-cols-left li,
    .two-cols-right li,
    .three-cols-col li,
    .col li,
    .pdf-col li,
    .pdf-col .pdf-list-item {
      padding-left: 0.2em !important;
      margin-left: 0 !important;
      margin-bottom: 6px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: list-item !important;
      line-height: 1.6 !important;
    }
    .layout-two-cols ul ul,
    .layout-three-cols ul ul,
    .three-cols-col ul ul,
    .pdf-col ul ul {
      list-style: circle !important;
      list-style-type: circle !important;
      padding-left: 1.25em !important;
      margin-top: 4px !important;
      margin-bottom: 4px !important;
    }
    /* 列表项内嵌标题与说明排版 */
    .slide-list-item-title,
    .pdf-list li > h1,
    .pdf-list li > h2,
    .pdf-list li > h3,
    .pdf-list li > h4,
    .pdf-list li > h5,
    .pdf-list li > h6,
    li > h1.slide-list-item-title,
    li > h2.slide-list-item-title,
    li > h3.slide-list-item-title,
    li > h4.slide-list-item-title {
      margin-top: 2px !important;
      margin-bottom: 6px !important;
      line-height: 1.35 !important;
      font-weight: 700 !important;
    }
    .pdf-list li > h1, li > h1.slide-list-item-title { font-size: 1.6rem !important; }
    .pdf-list li > h2, li > h2.slide-list-item-title { font-size: 1.4rem !important; }
    .pdf-list li > h3, li > h3.slide-list-item-title { font-size: 1.22rem !important; }
    .pdf-list li > h4, li > h4.slide-list-item-title { font-size: 1.1rem !important; }

    /* 全局特定标题大小规范化后置强力锁定 (防止被列表项内部字号覆盖) */
    [data-normalize-headings="true"] .slides-page-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .slides-page-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      font-size: 1.7rem !important;
      font-weight: 600 !important;
      line-height: 1.25 !important;
      margin-bottom: 10px !important;
    }
    [data-normalize-headings="true"] .has-superblock-cols .slides-col-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .has-superblock-cols .slides-col-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .has-superblock-cols .pdf-col > *:first-child :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      font-size: 1.3rem !important;
      font-weight: 600 !important;
      line-height: 1.3 !important;
      margin-bottom: 8px !important;
      text-align: center !important;
    }
    /* 基础列表项前缀样式 */
    .slide-block ul,
    .slide-list--unordered,
    .pdf-list--unordered {
      list-style: disc !important;
      list-style-type: disc !important;
    }
    .slide-block ol,
    .slide-list--ordered,
    .pdf-list--ordered {
      list-style: decimal !important;
      list-style-type: decimal !important;
    }
    .slide-block li,
    .slide-list-item,
    .pdf-list-item,
    .pdf-list li {
      display: list-item !important;
    }

    /* 隐藏无序列表前缀标记 */
    [data-hide-unordered-markers="true"] :is(ul, .slide-list, .slide-list--unordered, .pdf-list, .pdf-list--unordered),
    [data-hide-unordered-markers="true"] :is(ul, .slide-list, .slide-list--unordered, .pdf-list, .pdf-list--unordered) > li,
    [data-hide-unordered-markers="true"] li.slide-list-item,
    [data-hide-unordered-markers="true"] ul > li {
      list-style: none !important;
      list-style-type: none !important;
      padding-left: 0 !important;
      margin-left: 0 !important;
    }
    [data-hide-unordered-markers="true"] :is(ul, .slide-list, .slide-list--unordered, .pdf-list, .pdf-list--unordered) > li::marker,
    [data-hide-unordered-markers="true"] li.slide-list-item::marker {
      content: "" !important;
      display: none !important;
    }

    /* 隐藏有序列表前缀标记 */
    [data-hide-ordered-markers="true"] :is(ol, .slide-list, .slide-list--ordered, .pdf-list, .pdf-list--ordered),
    [data-hide-ordered-markers="true"] :is(ol, .slide-list, .slide-list--ordered, .pdf-list, .pdf-list--ordered) > li,
    [data-hide-ordered-markers="true"] li.slide-list-item,
    [data-hide-ordered-markers="true"] ol > li {
      list-style: none !important;
      list-style-type: none !important;
      padding-left: 0 !important;
      margin-left: 0 !important;
    }
    [data-hide-ordered-markers="true"] :is(ol, .slide-list, .slide-list--ordered, .pdf-list, .pdf-list--ordered) > li::marker,
    [data-hide-ordered-markers="true"] li.slide-list-item::marker {
      content: "" !important;
      display: none !important;
    }

    .slide-list-item-desc,
    .pdf-list li > p {
      margin-top: 4px !important;
      margin-bottom: 6px !important;
      font-size: 1.05rem;
      line-height: 1.55;
      opacity: 0.92;
    }
    kbd {
      display: inline-block;
      padding: 2px 7px;
      font-family: ui-monospace, SFMono-Regular, "SF Mono", Menlo, Consolas, "Liberation Mono", monospace;
      font-size: 0.85em;
      font-weight: 600;
      line-height: 1.25;
      color: inherit;
      background: rgba(125, 125, 125, 0.12);
      border: 1px solid rgba(125, 125, 125, 0.35);
      border-bottom-width: 2px;
      border-radius: 5px;
      box-shadow: 0 1px 2px rgba(0, 0, 0, 0.12);
      margin: 0 2px;
      vertical-align: middle;
      white-space: nowrap;
    }
    .theme-dark kbd {
      background: rgba(255, 255, 255, 0.1);
      border-color: rgba(255, 255, 255, 0.25);
      border-bottom-color: rgba(255, 255, 255, 0.4);
      color: #f1f5f9;
      box-shadow: 0 1px 2px rgba(0, 0, 0, 0.4);
    }
    a {
      color: inherit;
      text-decoration: none;
      border-bottom: 1px dashed currentColor;
    }
    .slides-ref-tag, a.slides-ref-tag {
      display: inline-flex;
      align-items: center;
      background: rgba(16, 185, 129, 0.1);
      color: #059669;
      border: 1px solid rgba(16, 185, 129, 0.25);
      border-radius: 4px;
      padding: 2px 8px;
      font-size: 0.88em;
      text-decoration: none;
      margin: 2px 4px 2px 0;
    }
    .theme-dark .slides-ref-tag, .theme-dark a.slides-ref-tag {
      background: rgba(52, 211, 153, 0.15);
      color: #34d399;
      border-color: rgba(52, 211, 153, 0.3);
    }
    .slides-block-ref, .pdf-block--ref {
      background: rgba(16, 185, 129, 0.06);
      border-left: 3px solid #059669;
      border-radius: 0 6px 6px 0;
      padding: 10px 14px;
      margin: 8px 0;
    }
    .theme-dark .slides-block-ref, .theme-dark .pdf-block--ref {
      background: rgba(52, 211, 153, 0.08);
      border-left-color: #34d399;
    }
    .pdf-slide-notes {
      font-size: 14px;
      color: #059669;
      border-top: 1px dashed #cbd5e1;
      padding-top: 12px;
      margin-top: auto;
      line-height: 1.5;
    }
    .theme-dark .pdf-slide-notes {
      color: #34d399;
      border-top-color: #334155;
    }
    /* Layouts */
    .layout-cover .pdf-slide-body {
      justify-content: center;
      align-items: center;
      text-align: center;
    }
    .layout-cover h1 {
      font-size: 3.2rem;
    }
    .layout-center .pdf-slide-body {
      justify-content: center;
      align-items: center;
      text-align: center;
    }
    .layout-fact .pdf-slide-body {
      justify-content: center;
      align-items: center;
      text-align: center;
    }
    .layout-fact h1 {
      font-size: 4.5rem;
      color: #ef4444;
    }
    @media print {
      .slides-motion-fade-in,
      .slides-motion-slide-up,
      .slides-motion-slide-down,
      .slides-motion-slide-left,
      .slides-motion-slide-right,
      .slides-motion-zoom-in,
      .slides-motion-pop,
      .slides-motion-bounce {
        animation: none !important;
        opacity: 1 !important;
        transform: none !important;
      }
      /* PDF 打印讲义下禁用动态蒙版遮挡，保证内容 100% 完整可见 */
      .slides-mask-layer,
      .slides-mask-overlay,
      .slides-mask-divider-line {
        display: none !important;
        opacity: 0 !important;
        mask: none !important;
        -webkit-mask: none !important;
      }
      .slides-mask-body-container {
        clip-path: none !important;
        -webkit-clip-path: none !important;
        overflow: visible !important;
      }
    }
  `}function bg(e,t){const i="即现演示讲义",n="16:9",s="light",o=e.slides.map((a,r)=>{const l=a.frontmatter.layout||"default",c=a.frontmatter.spacing,u=c&&c!=="inherit"?c:e.config.spacing||"normal",f=Jl(a),d=`${r+1} / ${e.slides.length}`;return`
      <section class="pdf-slide-page layout-${l} theme-${s} spacing-${u}">
        <header class="pdf-slide-header">
          <span class="pdf-doc-title">${ot(i)}</span>
          ${`<span class="pdf-page-badge">P. ${d}</span>`}
        </header>
        <div class="pdf-slide-body">
          ${f}
        </div>
        ${a.notes?`
          <footer class="pdf-slide-notes">
            <strong>演讲备注:</strong> ${ot(a.notes)}
          </footer>
        `:""}
      </section>
    `}).join(`
`);return`<!DOCTYPE html>
<html lang="zh-CN">
<head>
  <meta charset="UTF-8">
  <title>${ot(i)} - 高保真讲义</title>
  <style>
    ${vg({pageRatio:n,customInlineStyles:t==null?void 0:t.customInlineStyles})}
  </style>
</head>
<body data-normalize-headings="${e.config.normalizeHeadingSizes?"true":"false"}" data-hide-unordered-markers="${e.config.showUnorderedListMarkers===!1?"true":"false"}" data-hide-ordered-markers="${e.config.showOrderedListMarkers===!1?"true":"false"}">
  ${o}
</body>
</html>`}function ec(e,t){var s;if(typeof window>"u"||typeof document>"u")return!1;const i=bg(e,t);try{const o=document.createElement("iframe");o.style.position="fixed",o.style.right="0",o.style.bottom="0",o.style.width="0",o.style.height="0",o.style.border="none",o.style.visibility="hidden",document.body.appendChild(o);const a=(s=o.contentWindow)==null?void 0:s.document;if(a)return a.open(),a.write(i),a.close(),setTimeout(()=>{var r,l;try{(r=o.contentWindow)==null||r.focus(),(l=o.contentWindow)==null||l.print()}finally{setTimeout(()=>{o.remove()},2e3)}},350),!0}catch(o){console.warn("[pdf-exporter] iframe 打印模式异常，降级尝试 window.open:",o)}const n=window.open("","_blank");return n?(n.document.write(i),n.document.close(),n.focus(),setTimeout(()=>{n.print(),n.close()},350),!0):!1}var cs=typeof globalThis<"u"?globalThis:typeof window<"u"?window:typeof global<"u"?global:typeof self<"u"?self:{};function yg(e){return e&&e.__esModule&&Object.prototype.hasOwnProperty.call(e,"default")?e.default:e}function ds(e){throw new Error('Could not dynamically require "'+e+'". Please configure the dynamicRequireTargets or/and ignoreDynamicRequires option of @rollup/plugin-commonjs appropriately for this require call to work.')}var mo={exports:{}};/*!

JSZip v3.10.1 - A JavaScript class for generating and reading zip files
<http://stuartk.com/jszip>

(c) 2009-2016 Stuart Knightley <stuart [at] stuartk.com>
Dual licenced under the MIT license or GPLv3. See https://raw.github.com/Stuk/jszip/main/LICENSE.markdown.

JSZip uses the library pako released under the MIT license :
https://github.com/nodeca/pako/blob/main/LICENSE
*/var pa;function kg(){return pa||(pa=1,(function(e,t){(function(i){e.exports=i()})(function(){return(function i(n,s,o){function a(c,u){if(!s[c]){if(!n[c]){var f=typeof ds=="function"&&ds;if(!u&&f)return f(c,!0);if(r)return r(c,!0);var d=new Error("Cannot find module '"+c+"'");throw d.code="MODULE_NOT_FOUND",d}var p=s[c]={exports:{}};n[c][0].call(p.exports,function(w){var m=n[c][1][w];return a(m||w)},p,p.exports,i,n,s,o)}return s[c].exports}for(var r=typeof ds=="function"&&ds,l=0;l<o.length;l++)a(o[l]);return a})({1:[function(i,n,s){var o=i("./utils"),a=i("./support"),r="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";s.encode=function(l){for(var c,u,f,d,p,w,m,b=[],y=0,v=l.length,k=v,S=o.getTypeOf(l)!=="string";y<l.length;)k=v-y,f=S?(c=l[y++],u=y<v?l[y++]:0,y<v?l[y++]:0):(c=l.charCodeAt(y++),u=y<v?l.charCodeAt(y++):0,y<v?l.charCodeAt(y++):0),d=c>>2,p=(3&c)<<4|u>>4,w=1<k?(15&u)<<2|f>>6:64,m=2<k?63&f:64,b.push(r.charAt(d)+r.charAt(p)+r.charAt(w)+r.charAt(m));return b.join("")},s.decode=function(l){var c,u,f,d,p,w,m=0,b=0,y="data:";if(l.substr(0,y.length)===y)throw new Error("Invalid base64 input, it looks like a data url.");var v,k=3*(l=l.replace(/[^A-Za-z0-9+/=]/g,"")).length/4;if(l.charAt(l.length-1)===r.charAt(64)&&k--,l.charAt(l.length-2)===r.charAt(64)&&k--,k%1!=0)throw new Error("Invalid base64 input, bad content length.");for(v=a.uint8array?new Uint8Array(0|k):new Array(0|k);m<l.length;)c=r.indexOf(l.charAt(m++))<<2|(d=r.indexOf(l.charAt(m++)))>>4,u=(15&d)<<4|(p=r.indexOf(l.charAt(m++)))>>2,f=(3&p)<<6|(w=r.indexOf(l.charAt(m++))),v[b++]=c,p!==64&&(v[b++]=u),w!==64&&(v[b++]=f);return v}},{"./support":30,"./utils":32}],2:[function(i,n,s){var o=i("./external"),a=i("./stream/DataWorker"),r=i("./stream/Crc32Probe"),l=i("./stream/DataLengthProbe");function c(u,f,d,p,w){this.compressedSize=u,this.uncompressedSize=f,this.crc32=d,this.compression=p,this.compressedContent=w}c.prototype={getContentWorker:function(){var u=new a(o.Promise.resolve(this.compressedContent)).pipe(this.compression.uncompressWorker()).pipe(new l("data_length")),f=this;return u.on("end",function(){if(this.streamInfo.data_length!==f.uncompressedSize)throw new Error("Bug : uncompressed data size mismatch")}),u},getCompressedWorker:function(){return new a(o.Promise.resolve(this.compressedContent)).withStreamInfo("compressedSize",this.compressedSize).withStreamInfo("uncompressedSize",this.uncompressedSize).withStreamInfo("crc32",this.crc32).withStreamInfo("compression",this.compression)}},c.createWorkerFrom=function(u,f,d){return u.pipe(new r).pipe(new l("uncompressedSize")).pipe(f.compressWorker(d)).pipe(new l("compressedSize")).withStreamInfo("compression",f)},n.exports=c},{"./external":6,"./stream/Crc32Probe":25,"./stream/DataLengthProbe":26,"./stream/DataWorker":27}],3:[function(i,n,s){var o=i("./stream/GenericWorker");s.STORE={magic:"\0\0",compressWorker:function(){return new o("STORE compression")},uncompressWorker:function(){return new o("STORE decompression")}},s.DEFLATE=i("./flate")},{"./flate":7,"./stream/GenericWorker":28}],4:[function(i,n,s){var o=i("./utils"),a=(function(){for(var r,l=[],c=0;c<256;c++){r=c;for(var u=0;u<8;u++)r=1&r?3988292384^r>>>1:r>>>1;l[c]=r}return l})();n.exports=function(r,l){return r!==void 0&&r.length?o.getTypeOf(r)!=="string"?(function(c,u,f,d){var p=a,w=d+f;c^=-1;for(var m=d;m<w;m++)c=c>>>8^p[255&(c^u[m])];return-1^c})(0|l,r,r.length,0):(function(c,u,f,d){var p=a,w=d+f;c^=-1;for(var m=d;m<w;m++)c=c>>>8^p[255&(c^u.charCodeAt(m))];return-1^c})(0|l,r,r.length,0):0}},{"./utils":32}],5:[function(i,n,s){s.base64=!1,s.binary=!1,s.dir=!1,s.createFolders=!0,s.date=null,s.compression=null,s.compressionOptions=null,s.comment=null,s.unixPermissions=null,s.dosPermissions=null},{}],6:[function(i,n,s){var o=null;o=typeof Promise<"u"?Promise:i("lie"),n.exports={Promise:o}},{lie:37}],7:[function(i,n,s){var o=typeof Uint8Array<"u"&&typeof Uint16Array<"u"&&typeof Uint32Array<"u",a=i("pako"),r=i("./utils"),l=i("./stream/GenericWorker"),c=o?"uint8array":"array";function u(f,d){l.call(this,"FlateWorker/"+f),this._pako=null,this._pakoAction=f,this._pakoOptions=d,this.meta={}}s.magic="\b\0",r.inherits(u,l),u.prototype.processChunk=function(f){this.meta=f.meta,this._pako===null&&this._createPako(),this._pako.push(r.transformTo(c,f.data),!1)},u.prototype.flush=function(){l.prototype.flush.call(this),this._pako===null&&this._createPako(),this._pako.push([],!0)},u.prototype.cleanUp=function(){l.prototype.cleanUp.call(this),this._pako=null},u.prototype._createPako=function(){this._pako=new a[this._pakoAction]({raw:!0,level:this._pakoOptions.level||-1});var f=this;this._pako.onData=function(d){f.push({data:d,meta:f.meta})}},s.compressWorker=function(f){return new u("Deflate",f)},s.uncompressWorker=function(){return new u("Inflate",{})}},{"./stream/GenericWorker":28,"./utils":32,pako:38}],8:[function(i,n,s){function o(p,w){var m,b="";for(m=0;m<w;m++)b+=String.fromCharCode(255&p),p>>>=8;return b}function a(p,w,m,b,y,v){var k,S,B=p.file,A=p.compression,C=v!==c.utf8encode,L=r.transformTo("string",v(B.name)),z=r.transformTo("string",c.utf8encode(B.name)),N=B.comment,K=r.transformTo("string",v(N)),_=r.transformTo("string",c.utf8encode(N)),U=z.length!==B.name.length,x=_.length!==N.length,q="",O="",$="",T=B.dir,P=B.date,se={crc32:0,compressedSize:0,uncompressedSize:0};w&&!m||(se.crc32=p.crc32,se.compressedSize=p.compressedSize,se.uncompressedSize=p.uncompressedSize);var V=0;w&&(V|=8),C||!U&&!x||(V|=2048);var Y=0,ce=0;T&&(Y|=16),y==="UNIX"?(ce=798,Y|=(function(re,Se){var Ie=re;return re||(Ie=Se?16893:33204),(65535&Ie)<<16})(B.unixPermissions,T)):(ce=20,Y|=(function(re){return 63&(re||0)})(B.dosPermissions)),k=P.getUTCHours(),k<<=6,k|=P.getUTCMinutes(),k<<=5,k|=P.getUTCSeconds()/2,S=P.getUTCFullYear()-1980,S<<=4,S|=P.getUTCMonth()+1,S<<=5,S|=P.getUTCDate(),U&&(O=o(1,1)+o(u(L),4)+z,q+="up"+o(O.length,2)+O),x&&($=o(1,1)+o(u(K),4)+_,q+="uc"+o($.length,2)+$);var ie="";return ie+=`
\0`,ie+=o(V,2),ie+=A.magic,ie+=o(k,2),ie+=o(S,2),ie+=o(se.crc32,4),ie+=o(se.compressedSize,4),ie+=o(se.uncompressedSize,4),ie+=o(L.length,2),ie+=o(q.length,2),{fileRecord:f.LOCAL_FILE_HEADER+ie+L+q,dirRecord:f.CENTRAL_FILE_HEADER+o(ce,2)+ie+o(K.length,2)+"\0\0\0\0"+o(Y,4)+o(b,4)+L+q+K}}var r=i("../utils"),l=i("../stream/GenericWorker"),c=i("../utf8"),u=i("../crc32"),f=i("../signature");function d(p,w,m,b){l.call(this,"ZipFileWorker"),this.bytesWritten=0,this.zipComment=w,this.zipPlatform=m,this.encodeFileName=b,this.streamFiles=p,this.accumulate=!1,this.contentBuffer=[],this.dirRecords=[],this.currentSourceOffset=0,this.entriesCount=0,this.currentFile=null,this._sources=[]}r.inherits(d,l),d.prototype.push=function(p){var w=p.meta.percent||0,m=this.entriesCount,b=this._sources.length;this.accumulate?this.contentBuffer.push(p):(this.bytesWritten+=p.data.length,l.prototype.push.call(this,{data:p.data,meta:{currentFile:this.currentFile,percent:m?(w+100*(m-b-1))/m:100}}))},d.prototype.openedSource=function(p){this.currentSourceOffset=this.bytesWritten,this.currentFile=p.file.name;var w=this.streamFiles&&!p.file.dir;if(w){var m=a(p,w,!1,this.currentSourceOffset,this.zipPlatform,this.encodeFileName);this.push({data:m.fileRecord,meta:{percent:0}})}else this.accumulate=!0},d.prototype.closedSource=function(p){this.accumulate=!1;var w=this.streamFiles&&!p.file.dir,m=a(p,w,!0,this.currentSourceOffset,this.zipPlatform,this.encodeFileName);if(this.dirRecords.push(m.dirRecord),w)this.push({data:(function(b){return f.DATA_DESCRIPTOR+o(b.crc32,4)+o(b.compressedSize,4)+o(b.uncompressedSize,4)})(p),meta:{percent:100}});else for(this.push({data:m.fileRecord,meta:{percent:0}});this.contentBuffer.length;)this.push(this.contentBuffer.shift());this.currentFile=null},d.prototype.flush=function(){for(var p=this.bytesWritten,w=0;w<this.dirRecords.length;w++)this.push({data:this.dirRecords[w],meta:{percent:100}});var m=this.bytesWritten-p,b=(function(y,v,k,S,B){var A=r.transformTo("string",B(S));return f.CENTRAL_DIRECTORY_END+"\0\0\0\0"+o(y,2)+o(y,2)+o(v,4)+o(k,4)+o(A.length,2)+A})(this.dirRecords.length,m,p,this.zipComment,this.encodeFileName);this.push({data:b,meta:{percent:100}})},d.prototype.prepareNextSource=function(){this.previous=this._sources.shift(),this.openedSource(this.previous.streamInfo),this.isPaused?this.previous.pause():this.previous.resume()},d.prototype.registerPrevious=function(p){this._sources.push(p);var w=this;return p.on("data",function(m){w.processChunk(m)}),p.on("end",function(){w.closedSource(w.previous.streamInfo),w._sources.length?w.prepareNextSource():w.end()}),p.on("error",function(m){w.error(m)}),this},d.prototype.resume=function(){return!!l.prototype.resume.call(this)&&(!this.previous&&this._sources.length?(this.prepareNextSource(),!0):this.previous||this._sources.length||this.generatedError?void 0:(this.end(),!0))},d.prototype.error=function(p){var w=this._sources;if(!l.prototype.error.call(this,p))return!1;for(var m=0;m<w.length;m++)try{w[m].error(p)}catch{}return!0},d.prototype.lock=function(){l.prototype.lock.call(this);for(var p=this._sources,w=0;w<p.length;w++)p[w].lock()},n.exports=d},{"../crc32":4,"../signature":23,"../stream/GenericWorker":28,"../utf8":31,"../utils":32}],9:[function(i,n,s){var o=i("../compressions"),a=i("./ZipFileWorker");s.generateWorker=function(r,l,c){var u=new a(l.streamFiles,c,l.platform,l.encodeFileName),f=0;try{r.forEach(function(d,p){f++;var w=(function(v,k){var S=v||k,B=o[S];if(!B)throw new Error(S+" is not a valid compression method !");return B})(p.options.compression,l.compression),m=p.options.compressionOptions||l.compressionOptions||{},b=p.dir,y=p.date;p._compressWorker(w,m).withStreamInfo("file",{name:d,dir:b,date:y,comment:p.comment||"",unixPermissions:p.unixPermissions,dosPermissions:p.dosPermissions}).pipe(u)}),u.entriesCount=f}catch(d){u.error(d)}return u}},{"../compressions":3,"./ZipFileWorker":8}],10:[function(i,n,s){function o(){if(!(this instanceof o))return new o;if(arguments.length)throw new Error("The constructor with parameters has been removed in JSZip 3.0, please check the upgrade guide.");this.files=Object.create(null),this.comment=null,this.root="",this.clone=function(){var a=new o;for(var r in this)typeof this[r]!="function"&&(a[r]=this[r]);return a}}(o.prototype=i("./object")).loadAsync=i("./load"),o.support=i("./support"),o.defaults=i("./defaults"),o.version="3.10.1",o.loadAsync=function(a,r){return new o().loadAsync(a,r)},o.external=i("./external"),n.exports=o},{"./defaults":5,"./external":6,"./load":11,"./object":15,"./support":30}],11:[function(i,n,s){var o=i("./utils"),a=i("./external"),r=i("./utf8"),l=i("./zipEntries"),c=i("./stream/Crc32Probe"),u=i("./nodejsUtils");function f(d){return new a.Promise(function(p,w){var m=d.decompressed.getContentWorker().pipe(new c);m.on("error",function(b){w(b)}).on("end",function(){m.streamInfo.crc32!==d.decompressed.crc32?w(new Error("Corrupted zip : CRC32 mismatch")):p()}).resume()})}n.exports=function(d,p){var w=this;return p=o.extend(p||{},{base64:!1,checkCRC32:!1,optimizedBinaryString:!1,createFolders:!1,decodeFileName:r.utf8decode}),u.isNode&&u.isStream(d)?a.Promise.reject(new Error("JSZip can't accept a stream when loading a zip file.")):o.prepareContent("the loaded zip file",d,!0,p.optimizedBinaryString,p.base64).then(function(m){var b=new l(p);return b.load(m),b}).then(function(m){var b=[a.Promise.resolve(m)],y=m.files;if(p.checkCRC32)for(var v=0;v<y.length;v++)b.push(f(y[v]));return a.Promise.all(b)}).then(function(m){for(var b=m.shift(),y=b.files,v=0;v<y.length;v++){var k=y[v],S=k.fileNameStr,B=o.resolve(k.fileNameStr);w.file(B,k.decompressed,{binary:!0,optimizedBinaryString:!0,date:k.date,dir:k.dir,comment:k.fileCommentStr.length?k.fileCommentStr:null,unixPermissions:k.unixPermissions,dosPermissions:k.dosPermissions,createFolders:p.createFolders}),k.dir||(w.file(B).unsafeOriginalName=S)}return b.zipComment.length&&(w.comment=b.zipComment),w})}},{"./external":6,"./nodejsUtils":14,"./stream/Crc32Probe":25,"./utf8":31,"./utils":32,"./zipEntries":33}],12:[function(i,n,s){var o=i("../utils"),a=i("../stream/GenericWorker");function r(l,c){a.call(this,"Nodejs stream input adapter for "+l),this._upstreamEnded=!1,this._bindStream(c)}o.inherits(r,a),r.prototype._bindStream=function(l){var c=this;(this._stream=l).pause(),l.on("data",function(u){c.push({data:u,meta:{percent:0}})}).on("error",function(u){c.isPaused?this.generatedError=u:c.error(u)}).on("end",function(){c.isPaused?c._upstreamEnded=!0:c.end()})},r.prototype.pause=function(){return!!a.prototype.pause.call(this)&&(this._stream.pause(),!0)},r.prototype.resume=function(){return!!a.prototype.resume.call(this)&&(this._upstreamEnded?this.end():this._stream.resume(),!0)},n.exports=r},{"../stream/GenericWorker":28,"../utils":32}],13:[function(i,n,s){var o=i("readable-stream").Readable;function a(r,l,c){o.call(this,l),this._helper=r;var u=this;r.on("data",function(f,d){u.push(f)||u._helper.pause(),c&&c(d)}).on("error",function(f){u.emit("error",f)}).on("end",function(){u.push(null)})}i("../utils").inherits(a,o),a.prototype._read=function(){this._helper.resume()},n.exports=a},{"../utils":32,"readable-stream":16}],14:[function(i,n,s){n.exports={isNode:typeof Buffer<"u",newBufferFrom:function(o,a){if(Buffer.from&&Buffer.from!==Uint8Array.from)return Buffer.from(o,a);if(typeof o=="number")throw new Error('The "data" argument must not be a number');return new Buffer(o,a)},allocBuffer:function(o){if(Buffer.alloc)return Buffer.alloc(o);var a=new Buffer(o);return a.fill(0),a},isBuffer:function(o){return Buffer.isBuffer(o)},isStream:function(o){return o&&typeof o.on=="function"&&typeof o.pause=="function"&&typeof o.resume=="function"}}},{}],15:[function(i,n,s){function o(B,A,C){var L,z=r.getTypeOf(A),N=r.extend(C||{},u);N.date=N.date||new Date,N.compression!==null&&(N.compression=N.compression.toUpperCase()),typeof N.unixPermissions=="string"&&(N.unixPermissions=parseInt(N.unixPermissions,8)),N.unixPermissions&&16384&N.unixPermissions&&(N.dir=!0),N.dosPermissions&&16&N.dosPermissions&&(N.dir=!0),N.dir&&(B=y(B)),N.createFolders&&(L=b(B))&&v.call(this,L,!0);var K=z==="string"&&N.binary===!1&&N.base64===!1;C&&C.binary!==void 0||(N.binary=!K),(A instanceof f&&A.uncompressedSize===0||N.dir||!A||A.length===0)&&(N.base64=!1,N.binary=!0,A="",N.compression="STORE",z="string");var _=null;_=A instanceof f||A instanceof l?A:w.isNode&&w.isStream(A)?new m(B,A):r.prepareContent(B,A,N.binary,N.optimizedBinaryString,N.base64);var U=new d(B,_,N);this.files[B]=U}var a=i("./utf8"),r=i("./utils"),l=i("./stream/GenericWorker"),c=i("./stream/StreamHelper"),u=i("./defaults"),f=i("./compressedObject"),d=i("./zipObject"),p=i("./generate"),w=i("./nodejsUtils"),m=i("./nodejs/NodejsStreamInputAdapter"),b=function(B){B.slice(-1)==="/"&&(B=B.substring(0,B.length-1));var A=B.lastIndexOf("/");return 0<A?B.substring(0,A):""},y=function(B){return B.slice(-1)!=="/"&&(B+="/"),B},v=function(B,A){return A=A!==void 0?A:u.createFolders,B=y(B),this.files[B]||o.call(this,B,null,{dir:!0,createFolders:A}),this.files[B]};function k(B){return Object.prototype.toString.call(B)==="[object RegExp]"}var S={load:function(){throw new Error("This method has been removed in JSZip 3.0, please check the upgrade guide.")},forEach:function(B){var A,C,L;for(A in this.files)L=this.files[A],(C=A.slice(this.root.length,A.length))&&A.slice(0,this.root.length)===this.root&&B(C,L)},filter:function(B){var A=[];return this.forEach(function(C,L){B(C,L)&&A.push(L)}),A},file:function(B,A,C){if(arguments.length!==1)return B=this.root+B,o.call(this,B,A,C),this;if(k(B)){var L=B;return this.filter(function(N,K){return!K.dir&&L.test(N)})}var z=this.files[this.root+B];return z&&!z.dir?z:null},folder:function(B){if(!B)return this;if(k(B))return this.filter(function(z,N){return N.dir&&B.test(z)});var A=this.root+B,C=v.call(this,A),L=this.clone();return L.root=C.name,L},remove:function(B){B=this.root+B;var A=this.files[B];if(A||(B.slice(-1)!=="/"&&(B+="/"),A=this.files[B]),A&&!A.dir)delete this.files[B];else for(var C=this.filter(function(z,N){return N.name.slice(0,B.length)===B}),L=0;L<C.length;L++)delete this.files[C[L].name];return this},generate:function(){throw new Error("This method has been removed in JSZip 3.0, please check the upgrade guide.")},generateInternalStream:function(B){var A,C={};try{if((C=r.extend(B||{},{streamFiles:!1,compression:"STORE",compressionOptions:null,type:"",platform:"DOS",comment:null,mimeType:"application/zip",encodeFileName:a.utf8encode})).type=C.type.toLowerCase(),C.compression=C.compression.toUpperCase(),C.type==="binarystring"&&(C.type="string"),!C.type)throw new Error("No output type specified.");r.checkSupport(C.type),C.platform!=="darwin"&&C.platform!=="freebsd"&&C.platform!=="linux"&&C.platform!=="sunos"||(C.platform="UNIX"),C.platform==="win32"&&(C.platform="DOS");var L=C.comment||this.comment||"";A=p.generateWorker(this,C,L)}catch(z){(A=new l("error")).error(z)}return new c(A,C.type||"string",C.mimeType)},generateAsync:function(B,A){return this.generateInternalStream(B).accumulate(A)},generateNodeStream:function(B,A){return(B=B||{}).type||(B.type="nodebuffer"),this.generateInternalStream(B).toNodejsStream(A)}};n.exports=S},{"./compressedObject":2,"./defaults":5,"./generate":9,"./nodejs/NodejsStreamInputAdapter":12,"./nodejsUtils":14,"./stream/GenericWorker":28,"./stream/StreamHelper":29,"./utf8":31,"./utils":32,"./zipObject":35}],16:[function(i,n,s){n.exports=i("stream")},{stream:void 0}],17:[function(i,n,s){var o=i("./DataReader");function a(r){o.call(this,r);for(var l=0;l<this.data.length;l++)r[l]=255&r[l]}i("../utils").inherits(a,o),a.prototype.byteAt=function(r){return this.data[this.zero+r]},a.prototype.lastIndexOfSignature=function(r){for(var l=r.charCodeAt(0),c=r.charCodeAt(1),u=r.charCodeAt(2),f=r.charCodeAt(3),d=this.length-4;0<=d;--d)if(this.data[d]===l&&this.data[d+1]===c&&this.data[d+2]===u&&this.data[d+3]===f)return d-this.zero;return-1},a.prototype.readAndCheckSignature=function(r){var l=r.charCodeAt(0),c=r.charCodeAt(1),u=r.charCodeAt(2),f=r.charCodeAt(3),d=this.readData(4);return l===d[0]&&c===d[1]&&u===d[2]&&f===d[3]},a.prototype.readData=function(r){if(this.checkOffset(r),r===0)return[];var l=this.data.slice(this.zero+this.index,this.zero+this.index+r);return this.index+=r,l},n.exports=a},{"../utils":32,"./DataReader":18}],18:[function(i,n,s){var o=i("../utils");function a(r){this.data=r,this.length=r.length,this.index=0,this.zero=0}a.prototype={checkOffset:function(r){this.checkIndex(this.index+r)},checkIndex:function(r){if(this.length<this.zero+r||r<0)throw new Error("End of data reached (data length = "+this.length+", asked index = "+r+"). Corrupted zip ?")},setIndex:function(r){this.checkIndex(r),this.index=r},skip:function(r){this.setIndex(this.index+r)},byteAt:function(){},readInt:function(r){var l,c=0;for(this.checkOffset(r),l=this.index+r-1;l>=this.index;l--)c=(c<<8)+this.byteAt(l);return this.index+=r,c},readString:function(r){return o.transformTo("string",this.readData(r))},readData:function(){},lastIndexOfSignature:function(){},readAndCheckSignature:function(){},readDate:function(){var r=this.readInt(4);return new Date(Date.UTC(1980+(r>>25&127),(r>>21&15)-1,r>>16&31,r>>11&31,r>>5&63,(31&r)<<1))}},n.exports=a},{"../utils":32}],19:[function(i,n,s){var o=i("./Uint8ArrayReader");function a(r){o.call(this,r)}i("../utils").inherits(a,o),a.prototype.readData=function(r){this.checkOffset(r);var l=this.data.slice(this.zero+this.index,this.zero+this.index+r);return this.index+=r,l},n.exports=a},{"../utils":32,"./Uint8ArrayReader":21}],20:[function(i,n,s){var o=i("./DataReader");function a(r){o.call(this,r)}i("../utils").inherits(a,o),a.prototype.byteAt=function(r){return this.data.charCodeAt(this.zero+r)},a.prototype.lastIndexOfSignature=function(r){return this.data.lastIndexOf(r)-this.zero},a.prototype.readAndCheckSignature=function(r){return r===this.readData(4)},a.prototype.readData=function(r){this.checkOffset(r);var l=this.data.slice(this.zero+this.index,this.zero+this.index+r);return this.index+=r,l},n.exports=a},{"../utils":32,"./DataReader":18}],21:[function(i,n,s){var o=i("./ArrayReader");function a(r){o.call(this,r)}i("../utils").inherits(a,o),a.prototype.readData=function(r){if(this.checkOffset(r),r===0)return new Uint8Array(0);var l=this.data.subarray(this.zero+this.index,this.zero+this.index+r);return this.index+=r,l},n.exports=a},{"../utils":32,"./ArrayReader":17}],22:[function(i,n,s){var o=i("../utils"),a=i("../support"),r=i("./ArrayReader"),l=i("./StringReader"),c=i("./NodeBufferReader"),u=i("./Uint8ArrayReader");n.exports=function(f){var d=o.getTypeOf(f);return o.checkSupport(d),d!=="string"||a.uint8array?d==="nodebuffer"?new c(f):a.uint8array?new u(o.transformTo("uint8array",f)):new r(o.transformTo("array",f)):new l(f)}},{"../support":30,"../utils":32,"./ArrayReader":17,"./NodeBufferReader":19,"./StringReader":20,"./Uint8ArrayReader":21}],23:[function(i,n,s){s.LOCAL_FILE_HEADER="PK",s.CENTRAL_FILE_HEADER="PK",s.CENTRAL_DIRECTORY_END="PK",s.ZIP64_CENTRAL_DIRECTORY_LOCATOR="PK\x07",s.ZIP64_CENTRAL_DIRECTORY_END="PK",s.DATA_DESCRIPTOR="PK\x07\b"},{}],24:[function(i,n,s){var o=i("./GenericWorker"),a=i("../utils");function r(l){o.call(this,"ConvertWorker to "+l),this.destType=l}a.inherits(r,o),r.prototype.processChunk=function(l){this.push({data:a.transformTo(this.destType,l.data),meta:l.meta})},n.exports=r},{"../utils":32,"./GenericWorker":28}],25:[function(i,n,s){var o=i("./GenericWorker"),a=i("../crc32");function r(){o.call(this,"Crc32Probe"),this.withStreamInfo("crc32",0)}i("../utils").inherits(r,o),r.prototype.processChunk=function(l){this.streamInfo.crc32=a(l.data,this.streamInfo.crc32||0),this.push(l)},n.exports=r},{"../crc32":4,"../utils":32,"./GenericWorker":28}],26:[function(i,n,s){var o=i("../utils"),a=i("./GenericWorker");function r(l){a.call(this,"DataLengthProbe for "+l),this.propName=l,this.withStreamInfo(l,0)}o.inherits(r,a),r.prototype.processChunk=function(l){if(l){var c=this.streamInfo[this.propName]||0;this.streamInfo[this.propName]=c+l.data.length}a.prototype.processChunk.call(this,l)},n.exports=r},{"../utils":32,"./GenericWorker":28}],27:[function(i,n,s){var o=i("../utils"),a=i("./GenericWorker");function r(l){a.call(this,"DataWorker");var c=this;this.dataIsReady=!1,this.index=0,this.max=0,this.data=null,this.type="",this._tickScheduled=!1,l.then(function(u){c.dataIsReady=!0,c.data=u,c.max=u&&u.length||0,c.type=o.getTypeOf(u),c.isPaused||c._tickAndRepeat()},function(u){c.error(u)})}o.inherits(r,a),r.prototype.cleanUp=function(){a.prototype.cleanUp.call(this),this.data=null},r.prototype.resume=function(){return!!a.prototype.resume.call(this)&&(!this._tickScheduled&&this.dataIsReady&&(this._tickScheduled=!0,o.delay(this._tickAndRepeat,[],this)),!0)},r.prototype._tickAndRepeat=function(){this._tickScheduled=!1,this.isPaused||this.isFinished||(this._tick(),this.isFinished||(o.delay(this._tickAndRepeat,[],this),this._tickScheduled=!0))},r.prototype._tick=function(){if(this.isPaused||this.isFinished)return!1;var l=null,c=Math.min(this.max,this.index+16384);if(this.index>=this.max)return this.end();switch(this.type){case"string":l=this.data.substring(this.index,c);break;case"uint8array":l=this.data.subarray(this.index,c);break;case"array":case"nodebuffer":l=this.data.slice(this.index,c)}return this.index=c,this.push({data:l,meta:{percent:this.max?this.index/this.max*100:0}})},n.exports=r},{"../utils":32,"./GenericWorker":28}],28:[function(i,n,s){function o(a){this.name=a||"default",this.streamInfo={},this.generatedError=null,this.extraStreamInfo={},this.isPaused=!0,this.isFinished=!1,this.isLocked=!1,this._listeners={data:[],end:[],error:[]},this.previous=null}o.prototype={push:function(a){this.emit("data",a)},end:function(){if(this.isFinished)return!1;this.flush();try{this.emit("end"),this.cleanUp(),this.isFinished=!0}catch(a){this.emit("error",a)}return!0},error:function(a){return!this.isFinished&&(this.isPaused?this.generatedError=a:(this.isFinished=!0,this.emit("error",a),this.previous&&this.previous.error(a),this.cleanUp()),!0)},on:function(a,r){return this._listeners[a].push(r),this},cleanUp:function(){this.streamInfo=this.generatedError=this.extraStreamInfo=null,this._listeners=[]},emit:function(a,r){if(this._listeners[a])for(var l=0;l<this._listeners[a].length;l++)this._listeners[a][l].call(this,r)},pipe:function(a){return a.registerPrevious(this)},registerPrevious:function(a){if(this.isLocked)throw new Error("The stream '"+this+"' has already been used.");this.streamInfo=a.streamInfo,this.mergeStreamInfo(),this.previous=a;var r=this;return a.on("data",function(l){r.processChunk(l)}),a.on("end",function(){r.end()}),a.on("error",function(l){r.error(l)}),this},pause:function(){return!this.isPaused&&!this.isFinished&&(this.isPaused=!0,this.previous&&this.previous.pause(),!0)},resume:function(){if(!this.isPaused||this.isFinished)return!1;var a=this.isPaused=!1;return this.generatedError&&(this.error(this.generatedError),a=!0),this.previous&&this.previous.resume(),!a},flush:function(){},processChunk:function(a){this.push(a)},withStreamInfo:function(a,r){return this.extraStreamInfo[a]=r,this.mergeStreamInfo(),this},mergeStreamInfo:function(){for(var a in this.extraStreamInfo)Object.prototype.hasOwnProperty.call(this.extraStreamInfo,a)&&(this.streamInfo[a]=this.extraStreamInfo[a])},lock:function(){if(this.isLocked)throw new Error("The stream '"+this+"' has already been used.");this.isLocked=!0,this.previous&&this.previous.lock()},toString:function(){var a="Worker "+this.name;return this.previous?this.previous+" -> "+a:a}},n.exports=o},{}],29:[function(i,n,s){var o=i("../utils"),a=i("./ConvertWorker"),r=i("./GenericWorker"),l=i("../base64"),c=i("../support"),u=i("../external"),f=null;if(c.nodestream)try{f=i("../nodejs/NodejsStreamOutputAdapter")}catch{}function d(w,m){return new u.Promise(function(b,y){var v=[],k=w._internalType,S=w._outputType,B=w._mimeType;w.on("data",function(A,C){v.push(A),m&&m(C)}).on("error",function(A){v=[],y(A)}).on("end",function(){try{var A=(function(C,L,z){switch(C){case"blob":return o.newBlob(o.transformTo("arraybuffer",L),z);case"base64":return l.encode(L);default:return o.transformTo(C,L)}})(S,(function(C,L){var z,N=0,K=null,_=0;for(z=0;z<L.length;z++)_+=L[z].length;switch(C){case"string":return L.join("");case"array":return Array.prototype.concat.apply([],L);case"uint8array":for(K=new Uint8Array(_),z=0;z<L.length;z++)K.set(L[z],N),N+=L[z].length;return K;case"nodebuffer":return Buffer.concat(L);default:throw new Error("concat : unsupported type '"+C+"'")}})(k,v),B);b(A)}catch(C){y(C)}v=[]}).resume()})}function p(w,m,b){var y=m;switch(m){case"blob":case"arraybuffer":y="uint8array";break;case"base64":y="string"}try{this._internalType=y,this._outputType=m,this._mimeType=b,o.checkSupport(y),this._worker=w.pipe(new a(y)),w.lock()}catch(v){this._worker=new r("error"),this._worker.error(v)}}p.prototype={accumulate:function(w){return d(this,w)},on:function(w,m){var b=this;return w==="data"?this._worker.on(w,function(y){m.call(b,y.data,y.meta)}):this._worker.on(w,function(){o.delay(m,arguments,b)}),this},resume:function(){return o.delay(this._worker.resume,[],this._worker),this},pause:function(){return this._worker.pause(),this},toNodejsStream:function(w){if(o.checkSupport("nodestream"),this._outputType!=="nodebuffer")throw new Error(this._outputType+" is not supported by this method");return new f(this,{objectMode:this._outputType!=="nodebuffer"},w)}},n.exports=p},{"../base64":1,"../external":6,"../nodejs/NodejsStreamOutputAdapter":13,"../support":30,"../utils":32,"./ConvertWorker":24,"./GenericWorker":28}],30:[function(i,n,s){if(s.base64=!0,s.array=!0,s.string=!0,s.arraybuffer=typeof ArrayBuffer<"u"&&typeof Uint8Array<"u",s.nodebuffer=typeof Buffer<"u",s.uint8array=typeof Uint8Array<"u",typeof ArrayBuffer>"u")s.blob=!1;else{var o=new ArrayBuffer(0);try{s.blob=new Blob([o],{type:"application/zip"}).size===0}catch{try{var a=new(self.BlobBuilder||self.WebKitBlobBuilder||self.MozBlobBuilder||self.MSBlobBuilder);a.append(o),s.blob=a.getBlob("application/zip").size===0}catch{s.blob=!1}}}try{s.nodestream=!!i("readable-stream").Readable}catch{s.nodestream=!1}},{"readable-stream":16}],31:[function(i,n,s){for(var o=i("./utils"),a=i("./support"),r=i("./nodejsUtils"),l=i("./stream/GenericWorker"),c=new Array(256),u=0;u<256;u++)c[u]=252<=u?6:248<=u?5:240<=u?4:224<=u?3:192<=u?2:1;c[254]=c[254]=1;function f(){l.call(this,"utf-8 decode"),this.leftOver=null}function d(){l.call(this,"utf-8 encode")}s.utf8encode=function(p){return a.nodebuffer?r.newBufferFrom(p,"utf-8"):(function(w){var m,b,y,v,k,S=w.length,B=0;for(v=0;v<S;v++)(64512&(b=w.charCodeAt(v)))==55296&&v+1<S&&(64512&(y=w.charCodeAt(v+1)))==56320&&(b=65536+(b-55296<<10)+(y-56320),v++),B+=b<128?1:b<2048?2:b<65536?3:4;for(m=a.uint8array?new Uint8Array(B):new Array(B),v=k=0;k<B;v++)(64512&(b=w.charCodeAt(v)))==55296&&v+1<S&&(64512&(y=w.charCodeAt(v+1)))==56320&&(b=65536+(b-55296<<10)+(y-56320),v++),b<128?m[k++]=b:(b<2048?m[k++]=192|b>>>6:(b<65536?m[k++]=224|b>>>12:(m[k++]=240|b>>>18,m[k++]=128|b>>>12&63),m[k++]=128|b>>>6&63),m[k++]=128|63&b);return m})(p)},s.utf8decode=function(p){return a.nodebuffer?o.transformTo("nodebuffer",p).toString("utf-8"):(function(w){var m,b,y,v,k=w.length,S=new Array(2*k);for(m=b=0;m<k;)if((y=w[m++])<128)S[b++]=y;else if(4<(v=c[y]))S[b++]=65533,m+=v-1;else{for(y&=v===2?31:v===3?15:7;1<v&&m<k;)y=y<<6|63&w[m++],v--;1<v?S[b++]=65533:y<65536?S[b++]=y:(y-=65536,S[b++]=55296|y>>10&1023,S[b++]=56320|1023&y)}return S.length!==b&&(S.subarray?S=S.subarray(0,b):S.length=b),o.applyFromCharCode(S)})(p=o.transformTo(a.uint8array?"uint8array":"array",p))},o.inherits(f,l),f.prototype.processChunk=function(p){var w=o.transformTo(a.uint8array?"uint8array":"array",p.data);if(this.leftOver&&this.leftOver.length){if(a.uint8array){var m=w;(w=new Uint8Array(m.length+this.leftOver.length)).set(this.leftOver,0),w.set(m,this.leftOver.length)}else w=this.leftOver.concat(w);this.leftOver=null}var b=(function(v,k){var S;for((k=k||v.length)>v.length&&(k=v.length),S=k-1;0<=S&&(192&v[S])==128;)S--;return S<0||S===0?k:S+c[v[S]]>k?S:k})(w),y=w;b!==w.length&&(a.uint8array?(y=w.subarray(0,b),this.leftOver=w.subarray(b,w.length)):(y=w.slice(0,b),this.leftOver=w.slice(b,w.length))),this.push({data:s.utf8decode(y),meta:p.meta})},f.prototype.flush=function(){this.leftOver&&this.leftOver.length&&(this.push({data:s.utf8decode(this.leftOver),meta:{}}),this.leftOver=null)},s.Utf8DecodeWorker=f,o.inherits(d,l),d.prototype.processChunk=function(p){this.push({data:s.utf8encode(p.data),meta:p.meta})},s.Utf8EncodeWorker=d},{"./nodejsUtils":14,"./stream/GenericWorker":28,"./support":30,"./utils":32}],32:[function(i,n,s){var o=i("./support"),a=i("./base64"),r=i("./nodejsUtils"),l=i("./external");function c(m){return m}function u(m,b){for(var y=0;y<m.length;++y)b[y]=255&m.charCodeAt(y);return b}i("setimmediate"),s.newBlob=function(m,b){s.checkSupport("blob");try{return new Blob([m],{type:b})}catch{try{var y=new(self.BlobBuilder||self.WebKitBlobBuilder||self.MozBlobBuilder||self.MSBlobBuilder);return y.append(m),y.getBlob(b)}catch{throw new Error("Bug : can't construct the Blob.")}}};var f={stringifyByChunk:function(m,b,y){var v=[],k=0,S=m.length;if(S<=y)return String.fromCharCode.apply(null,m);for(;k<S;)b==="array"||b==="nodebuffer"?v.push(String.fromCharCode.apply(null,m.slice(k,Math.min(k+y,S)))):v.push(String.fromCharCode.apply(null,m.subarray(k,Math.min(k+y,S)))),k+=y;return v.join("")},stringifyByChar:function(m){for(var b="",y=0;y<m.length;y++)b+=String.fromCharCode(m[y]);return b},applyCanBeUsed:{uint8array:(function(){try{return o.uint8array&&String.fromCharCode.apply(null,new Uint8Array(1)).length===1}catch{return!1}})(),nodebuffer:(function(){try{return o.nodebuffer&&String.fromCharCode.apply(null,r.allocBuffer(1)).length===1}catch{return!1}})()}};function d(m){var b=65536,y=s.getTypeOf(m),v=!0;if(y==="uint8array"?v=f.applyCanBeUsed.uint8array:y==="nodebuffer"&&(v=f.applyCanBeUsed.nodebuffer),v)for(;1<b;)try{return f.stringifyByChunk(m,y,b)}catch{b=Math.floor(b/2)}return f.stringifyByChar(m)}function p(m,b){for(var y=0;y<m.length;y++)b[y]=m[y];return b}s.applyFromCharCode=d;var w={};w.string={string:c,array:function(m){return u(m,new Array(m.length))},arraybuffer:function(m){return w.string.uint8array(m).buffer},uint8array:function(m){return u(m,new Uint8Array(m.length))},nodebuffer:function(m){return u(m,r.allocBuffer(m.length))}},w.array={string:d,array:c,arraybuffer:function(m){return new Uint8Array(m).buffer},uint8array:function(m){return new Uint8Array(m)},nodebuffer:function(m){return r.newBufferFrom(m)}},w.arraybuffer={string:function(m){return d(new Uint8Array(m))},array:function(m){return p(new Uint8Array(m),new Array(m.byteLength))},arraybuffer:c,uint8array:function(m){return new Uint8Array(m)},nodebuffer:function(m){return r.newBufferFrom(new Uint8Array(m))}},w.uint8array={string:d,array:function(m){return p(m,new Array(m.length))},arraybuffer:function(m){return m.buffer},uint8array:c,nodebuffer:function(m){return r.newBufferFrom(m)}},w.nodebuffer={string:d,array:function(m){return p(m,new Array(m.length))},arraybuffer:function(m){return w.nodebuffer.uint8array(m).buffer},uint8array:function(m){return p(m,new Uint8Array(m.length))},nodebuffer:c},s.transformTo=function(m,b){if(b=b||"",!m)return b;s.checkSupport(m);var y=s.getTypeOf(b);return w[y][m](b)},s.resolve=function(m){for(var b=m.split("/"),y=[],v=0;v<b.length;v++){var k=b[v];k==="."||k===""&&v!==0&&v!==b.length-1||(k===".."?y.pop():y.push(k))}return y.join("/")},s.getTypeOf=function(m){return typeof m=="string"?"string":Object.prototype.toString.call(m)==="[object Array]"?"array":o.nodebuffer&&r.isBuffer(m)?"nodebuffer":o.uint8array&&m instanceof Uint8Array?"uint8array":o.arraybuffer&&m instanceof ArrayBuffer?"arraybuffer":void 0},s.checkSupport=function(m){if(!o[m.toLowerCase()])throw new Error(m+" is not supported by this platform")},s.MAX_VALUE_16BITS=65535,s.MAX_VALUE_32BITS=-1,s.pretty=function(m){var b,y,v="";for(y=0;y<(m||"").length;y++)v+="\\x"+((b=m.charCodeAt(y))<16?"0":"")+b.toString(16).toUpperCase();return v},s.delay=function(m,b,y){setImmediate(function(){m.apply(y||null,b||[])})},s.inherits=function(m,b){function y(){}y.prototype=b.prototype,m.prototype=new y},s.extend=function(){var m,b,y={};for(m=0;m<arguments.length;m++)for(b in arguments[m])Object.prototype.hasOwnProperty.call(arguments[m],b)&&y[b]===void 0&&(y[b]=arguments[m][b]);return y},s.prepareContent=function(m,b,y,v,k){return l.Promise.resolve(b).then(function(S){return o.blob&&(S instanceof Blob||["[object File]","[object Blob]"].indexOf(Object.prototype.toString.call(S))!==-1)&&typeof FileReader<"u"?new l.Promise(function(B,A){var C=new FileReader;C.onload=function(L){B(L.target.result)},C.onerror=function(L){A(L.target.error)},C.readAsArrayBuffer(S)}):S}).then(function(S){var B=s.getTypeOf(S);return B?(B==="arraybuffer"?S=s.transformTo("uint8array",S):B==="string"&&(k?S=a.decode(S):y&&v!==!0&&(S=(function(A){return u(A,o.uint8array?new Uint8Array(A.length):new Array(A.length))})(S))),S):l.Promise.reject(new Error("Can't read the data of '"+m+"'. Is it in a supported JavaScript type (String, Blob, ArrayBuffer, etc) ?"))})}},{"./base64":1,"./external":6,"./nodejsUtils":14,"./support":30,setimmediate:54}],33:[function(i,n,s){var o=i("./reader/readerFor"),a=i("./utils"),r=i("./signature"),l=i("./zipEntry"),c=i("./support");function u(f){this.files=[],this.loadOptions=f}u.prototype={checkSignature:function(f){if(!this.reader.readAndCheckSignature(f)){this.reader.index-=4;var d=this.reader.readString(4);throw new Error("Corrupted zip or bug: unexpected signature ("+a.pretty(d)+", expected "+a.pretty(f)+")")}},isSignature:function(f,d){var p=this.reader.index;this.reader.setIndex(f);var w=this.reader.readString(4)===d;return this.reader.setIndex(p),w},readBlockEndOfCentral:function(){this.diskNumber=this.reader.readInt(2),this.diskWithCentralDirStart=this.reader.readInt(2),this.centralDirRecordsOnThisDisk=this.reader.readInt(2),this.centralDirRecords=this.reader.readInt(2),this.centralDirSize=this.reader.readInt(4),this.centralDirOffset=this.reader.readInt(4),this.zipCommentLength=this.reader.readInt(2);var f=this.reader.readData(this.zipCommentLength),d=c.uint8array?"uint8array":"array",p=a.transformTo(d,f);this.zipComment=this.loadOptions.decodeFileName(p)},readBlockZip64EndOfCentral:function(){this.zip64EndOfCentralSize=this.reader.readInt(8),this.reader.skip(4),this.diskNumber=this.reader.readInt(4),this.diskWithCentralDirStart=this.reader.readInt(4),this.centralDirRecordsOnThisDisk=this.reader.readInt(8),this.centralDirRecords=this.reader.readInt(8),this.centralDirSize=this.reader.readInt(8),this.centralDirOffset=this.reader.readInt(8),this.zip64ExtensibleData={};for(var f,d,p,w=this.zip64EndOfCentralSize-44;0<w;)f=this.reader.readInt(2),d=this.reader.readInt(4),p=this.reader.readData(d),this.zip64ExtensibleData[f]={id:f,length:d,value:p}},readBlockZip64EndOfCentralLocator:function(){if(this.diskWithZip64CentralDirStart=this.reader.readInt(4),this.relativeOffsetEndOfZip64CentralDir=this.reader.readInt(8),this.disksCount=this.reader.readInt(4),1<this.disksCount)throw new Error("Multi-volumes zip are not supported")},readLocalFiles:function(){var f,d;for(f=0;f<this.files.length;f++)d=this.files[f],this.reader.setIndex(d.localHeaderOffset),this.checkSignature(r.LOCAL_FILE_HEADER),d.readLocalPart(this.reader),d.handleUTF8(),d.processAttributes()},readCentralDir:function(){var f;for(this.reader.setIndex(this.centralDirOffset);this.reader.readAndCheckSignature(r.CENTRAL_FILE_HEADER);)(f=new l({zip64:this.zip64},this.loadOptions)).readCentralPart(this.reader),this.files.push(f);if(this.centralDirRecords!==this.files.length&&this.centralDirRecords!==0&&this.files.length===0)throw new Error("Corrupted zip or bug: expected "+this.centralDirRecords+" records in central dir, got "+this.files.length)},readEndOfCentral:function(){var f=this.reader.lastIndexOfSignature(r.CENTRAL_DIRECTORY_END);if(f<0)throw this.isSignature(0,r.LOCAL_FILE_HEADER)?new Error("Corrupted zip: can't find end of central directory"):new Error("Can't find end of central directory : is this a zip file ? If it is, see https://stuk.github.io/jszip/documentation/howto/read_zip.html");this.reader.setIndex(f);var d=f;if(this.checkSignature(r.CENTRAL_DIRECTORY_END),this.readBlockEndOfCentral(),this.diskNumber===a.MAX_VALUE_16BITS||this.diskWithCentralDirStart===a.MAX_VALUE_16BITS||this.centralDirRecordsOnThisDisk===a.MAX_VALUE_16BITS||this.centralDirRecords===a.MAX_VALUE_16BITS||this.centralDirSize===a.MAX_VALUE_32BITS||this.centralDirOffset===a.MAX_VALUE_32BITS){if(this.zip64=!0,(f=this.reader.lastIndexOfSignature(r.ZIP64_CENTRAL_DIRECTORY_LOCATOR))<0)throw new Error("Corrupted zip: can't find the ZIP64 end of central directory locator");if(this.reader.setIndex(f),this.checkSignature(r.ZIP64_CENTRAL_DIRECTORY_LOCATOR),this.readBlockZip64EndOfCentralLocator(),!this.isSignature(this.relativeOffsetEndOfZip64CentralDir,r.ZIP64_CENTRAL_DIRECTORY_END)&&(this.relativeOffsetEndOfZip64CentralDir=this.reader.lastIndexOfSignature(r.ZIP64_CENTRAL_DIRECTORY_END),this.relativeOffsetEndOfZip64CentralDir<0))throw new Error("Corrupted zip: can't find the ZIP64 end of central directory");this.reader.setIndex(this.relativeOffsetEndOfZip64CentralDir),this.checkSignature(r.ZIP64_CENTRAL_DIRECTORY_END),this.readBlockZip64EndOfCentral()}var p=this.centralDirOffset+this.centralDirSize;this.zip64&&(p+=20,p+=12+this.zip64EndOfCentralSize);var w=d-p;if(0<w)this.isSignature(d,r.CENTRAL_FILE_HEADER)||(this.reader.zero=w);else if(w<0)throw new Error("Corrupted zip: missing "+Math.abs(w)+" bytes.")},prepareReader:function(f){this.reader=o(f)},load:function(f){this.prepareReader(f),this.readEndOfCentral(),this.readCentralDir(),this.readLocalFiles()}},n.exports=u},{"./reader/readerFor":22,"./signature":23,"./support":30,"./utils":32,"./zipEntry":34}],34:[function(i,n,s){var o=i("./reader/readerFor"),a=i("./utils"),r=i("./compressedObject"),l=i("./crc32"),c=i("./utf8"),u=i("./compressions"),f=i("./support");function d(p,w){this.options=p,this.loadOptions=w}d.prototype={isEncrypted:function(){return(1&this.bitFlag)==1},useUTF8:function(){return(2048&this.bitFlag)==2048},readLocalPart:function(p){var w,m;if(p.skip(22),this.fileNameLength=p.readInt(2),m=p.readInt(2),this.fileName=p.readData(this.fileNameLength),p.skip(m),this.compressedSize===-1||this.uncompressedSize===-1)throw new Error("Bug or corrupted zip : didn't get enough information from the central directory (compressedSize === -1 || uncompressedSize === -1)");if((w=(function(b){for(var y in u)if(Object.prototype.hasOwnProperty.call(u,y)&&u[y].magic===b)return u[y];return null})(this.compressionMethod))===null)throw new Error("Corrupted zip : compression "+a.pretty(this.compressionMethod)+" unknown (inner file : "+a.transformTo("string",this.fileName)+")");this.decompressed=new r(this.compressedSize,this.uncompressedSize,this.crc32,w,p.readData(this.compressedSize))},readCentralPart:function(p){this.versionMadeBy=p.readInt(2),p.skip(2),this.bitFlag=p.readInt(2),this.compressionMethod=p.readString(2),this.date=p.readDate(),this.crc32=p.readInt(4),this.compressedSize=p.readInt(4),this.uncompressedSize=p.readInt(4);var w=p.readInt(2);if(this.extraFieldsLength=p.readInt(2),this.fileCommentLength=p.readInt(2),this.diskNumberStart=p.readInt(2),this.internalFileAttributes=p.readInt(2),this.externalFileAttributes=p.readInt(4),this.localHeaderOffset=p.readInt(4),this.isEncrypted())throw new Error("Encrypted zip are not supported");p.skip(w),this.readExtraFields(p),this.parseZIP64ExtraField(p),this.fileComment=p.readData(this.fileCommentLength)},processAttributes:function(){this.unixPermissions=null,this.dosPermissions=null;var p=this.versionMadeBy>>8;this.dir=!!(16&this.externalFileAttributes),p==0&&(this.dosPermissions=63&this.externalFileAttributes),p==3&&(this.unixPermissions=this.externalFileAttributes>>16&65535),this.dir||this.fileNameStr.slice(-1)!=="/"||(this.dir=!0)},parseZIP64ExtraField:function(){if(this.extraFields[1]){var p=o(this.extraFields[1].value);this.uncompressedSize===a.MAX_VALUE_32BITS&&(this.uncompressedSize=p.readInt(8)),this.compressedSize===a.MAX_VALUE_32BITS&&(this.compressedSize=p.readInt(8)),this.localHeaderOffset===a.MAX_VALUE_32BITS&&(this.localHeaderOffset=p.readInt(8)),this.diskNumberStart===a.MAX_VALUE_32BITS&&(this.diskNumberStart=p.readInt(4))}},readExtraFields:function(p){var w,m,b,y=p.index+this.extraFieldsLength;for(this.extraFields||(this.extraFields={});p.index+4<y;)w=p.readInt(2),m=p.readInt(2),b=p.readData(m),this.extraFields[w]={id:w,length:m,value:b};p.setIndex(y)},handleUTF8:function(){var p=f.uint8array?"uint8array":"array";if(this.useUTF8())this.fileNameStr=c.utf8decode(this.fileName),this.fileCommentStr=c.utf8decode(this.fileComment);else{var w=this.findExtraFieldUnicodePath();if(w!==null)this.fileNameStr=w;else{var m=a.transformTo(p,this.fileName);this.fileNameStr=this.loadOptions.decodeFileName(m)}var b=this.findExtraFieldUnicodeComment();if(b!==null)this.fileCommentStr=b;else{var y=a.transformTo(p,this.fileComment);this.fileCommentStr=this.loadOptions.decodeFileName(y)}}},findExtraFieldUnicodePath:function(){var p=this.extraFields[28789];if(p){var w=o(p.value);return w.readInt(1)!==1||l(this.fileName)!==w.readInt(4)?null:c.utf8decode(w.readData(p.length-5))}return null},findExtraFieldUnicodeComment:function(){var p=this.extraFields[25461];if(p){var w=o(p.value);return w.readInt(1)!==1||l(this.fileComment)!==w.readInt(4)?null:c.utf8decode(w.readData(p.length-5))}return null}},n.exports=d},{"./compressedObject":2,"./compressions":3,"./crc32":4,"./reader/readerFor":22,"./support":30,"./utf8":31,"./utils":32}],35:[function(i,n,s){function o(w,m,b){this.name=w,this.dir=b.dir,this.date=b.date,this.comment=b.comment,this.unixPermissions=b.unixPermissions,this.dosPermissions=b.dosPermissions,this._data=m,this._dataBinary=b.binary,this.options={compression:b.compression,compressionOptions:b.compressionOptions}}var a=i("./stream/StreamHelper"),r=i("./stream/DataWorker"),l=i("./utf8"),c=i("./compressedObject"),u=i("./stream/GenericWorker");o.prototype={internalStream:function(w){var m=null,b="string";try{if(!w)throw new Error("No output type specified.");var y=(b=w.toLowerCase())==="string"||b==="text";b!=="binarystring"&&b!=="text"||(b="string"),m=this._decompressWorker();var v=!this._dataBinary;v&&!y&&(m=m.pipe(new l.Utf8EncodeWorker)),!v&&y&&(m=m.pipe(new l.Utf8DecodeWorker))}catch(k){(m=new u("error")).error(k)}return new a(m,b,"")},async:function(w,m){return this.internalStream(w).accumulate(m)},nodeStream:function(w,m){return this.internalStream(w||"nodebuffer").toNodejsStream(m)},_compressWorker:function(w,m){if(this._data instanceof c&&this._data.compression.magic===w.magic)return this._data.getCompressedWorker();var b=this._decompressWorker();return this._dataBinary||(b=b.pipe(new l.Utf8EncodeWorker)),c.createWorkerFrom(b,w,m)},_decompressWorker:function(){return this._data instanceof c?this._data.getContentWorker():this._data instanceof u?this._data:new r(this._data)}};for(var f=["asText","asBinary","asNodeBuffer","asUint8Array","asArrayBuffer"],d=function(){throw new Error("This method has been removed in JSZip 3.0, please check the upgrade guide.")},p=0;p<f.length;p++)o.prototype[f[p]]=d;n.exports=o},{"./compressedObject":2,"./stream/DataWorker":27,"./stream/GenericWorker":28,"./stream/StreamHelper":29,"./utf8":31}],36:[function(i,n,s){(function(o){var a,r,l=o.MutationObserver||o.WebKitMutationObserver;if(l){var c=0,u=new l(w),f=o.document.createTextNode("");u.observe(f,{characterData:!0}),a=function(){f.data=c=++c%2}}else if(o.setImmediate||o.MessageChannel===void 0)a="document"in o&&"onreadystatechange"in o.document.createElement("script")?function(){var m=o.document.createElement("script");m.onreadystatechange=function(){w(),m.onreadystatechange=null,m.parentNode.removeChild(m),m=null},o.document.documentElement.appendChild(m)}:function(){setTimeout(w,0)};else{var d=new o.MessageChannel;d.port1.onmessage=w,a=function(){d.port2.postMessage(0)}}var p=[];function w(){var m,b;r=!0;for(var y=p.length;y;){for(b=p,p=[],m=-1;++m<y;)b[m]();y=p.length}r=!1}n.exports=function(m){p.push(m)!==1||r||a()}}).call(this,typeof cs<"u"?cs:typeof self<"u"?self:typeof window<"u"?window:{})},{}],37:[function(i,n,s){var o=i("immediate");function a(){}var r={},l=["REJECTED"],c=["FULFILLED"],u=["PENDING"];function f(y){if(typeof y!="function")throw new TypeError("resolver must be a function");this.state=u,this.queue=[],this.outcome=void 0,y!==a&&m(this,y)}function d(y,v,k){this.promise=y,typeof v=="function"&&(this.onFulfilled=v,this.callFulfilled=this.otherCallFulfilled),typeof k=="function"&&(this.onRejected=k,this.callRejected=this.otherCallRejected)}function p(y,v,k){o(function(){var S;try{S=v(k)}catch(B){return r.reject(y,B)}S===y?r.reject(y,new TypeError("Cannot resolve promise with itself")):r.resolve(y,S)})}function w(y){var v=y&&y.then;if(y&&(typeof y=="object"||typeof y=="function")&&typeof v=="function")return function(){v.apply(y,arguments)}}function m(y,v){var k=!1;function S(C){k||(k=!0,r.reject(y,C))}function B(C){k||(k=!0,r.resolve(y,C))}var A=b(function(){v(B,S)});A.status==="error"&&S(A.value)}function b(y,v){var k={};try{k.value=y(v),k.status="success"}catch(S){k.status="error",k.value=S}return k}(n.exports=f).prototype.finally=function(y){if(typeof y!="function")return this;var v=this.constructor;return this.then(function(k){return v.resolve(y()).then(function(){return k})},function(k){return v.resolve(y()).then(function(){throw k})})},f.prototype.catch=function(y){return this.then(null,y)},f.prototype.then=function(y,v){if(typeof y!="function"&&this.state===c||typeof v!="function"&&this.state===l)return this;var k=new this.constructor(a);return this.state!==u?p(k,this.state===c?y:v,this.outcome):this.queue.push(new d(k,y,v)),k},d.prototype.callFulfilled=function(y){r.resolve(this.promise,y)},d.prototype.otherCallFulfilled=function(y){p(this.promise,this.onFulfilled,y)},d.prototype.callRejected=function(y){r.reject(this.promise,y)},d.prototype.otherCallRejected=function(y){p(this.promise,this.onRejected,y)},r.resolve=function(y,v){var k=b(w,v);if(k.status==="error")return r.reject(y,k.value);var S=k.value;if(S)m(y,S);else{y.state=c,y.outcome=v;for(var B=-1,A=y.queue.length;++B<A;)y.queue[B].callFulfilled(v)}return y},r.reject=function(y,v){y.state=l,y.outcome=v;for(var k=-1,S=y.queue.length;++k<S;)y.queue[k].callRejected(v);return y},f.resolve=function(y){return y instanceof this?y:r.resolve(new this(a),y)},f.reject=function(y){var v=new this(a);return r.reject(v,y)},f.all=function(y){var v=this;if(Object.prototype.toString.call(y)!=="[object Array]")return this.reject(new TypeError("must be an array"));var k=y.length,S=!1;if(!k)return this.resolve([]);for(var B=new Array(k),A=0,C=-1,L=new this(a);++C<k;)z(y[C],C);return L;function z(N,K){v.resolve(N).then(function(_){B[K]=_,++A!==k||S||(S=!0,r.resolve(L,B))},function(_){S||(S=!0,r.reject(L,_))})}},f.race=function(y){var v=this;if(Object.prototype.toString.call(y)!=="[object Array]")return this.reject(new TypeError("must be an array"));var k=y.length,S=!1;if(!k)return this.resolve([]);for(var B=-1,A=new this(a);++B<k;)C=y[B],v.resolve(C).then(function(L){S||(S=!0,r.resolve(A,L))},function(L){S||(S=!0,r.reject(A,L))});var C;return A}},{immediate:36}],38:[function(i,n,s){var o={};(0,i("./lib/utils/common").assign)(o,i("./lib/deflate"),i("./lib/inflate"),i("./lib/zlib/constants")),n.exports=o},{"./lib/deflate":39,"./lib/inflate":40,"./lib/utils/common":41,"./lib/zlib/constants":44}],39:[function(i,n,s){var o=i("./zlib/deflate"),a=i("./utils/common"),r=i("./utils/strings"),l=i("./zlib/messages"),c=i("./zlib/zstream"),u=Object.prototype.toString,f=0,d=-1,p=0,w=8;function m(y){if(!(this instanceof m))return new m(y);this.options=a.assign({level:d,method:w,chunkSize:16384,windowBits:15,memLevel:8,strategy:p,to:""},y||{});var v=this.options;v.raw&&0<v.windowBits?v.windowBits=-v.windowBits:v.gzip&&0<v.windowBits&&v.windowBits<16&&(v.windowBits+=16),this.err=0,this.msg="",this.ended=!1,this.chunks=[],this.strm=new c,this.strm.avail_out=0;var k=o.deflateInit2(this.strm,v.level,v.method,v.windowBits,v.memLevel,v.strategy);if(k!==f)throw new Error(l[k]);if(v.header&&o.deflateSetHeader(this.strm,v.header),v.dictionary){var S;if(S=typeof v.dictionary=="string"?r.string2buf(v.dictionary):u.call(v.dictionary)==="[object ArrayBuffer]"?new Uint8Array(v.dictionary):v.dictionary,(k=o.deflateSetDictionary(this.strm,S))!==f)throw new Error(l[k]);this._dict_set=!0}}function b(y,v){var k=new m(v);if(k.push(y,!0),k.err)throw k.msg||l[k.err];return k.result}m.prototype.push=function(y,v){var k,S,B=this.strm,A=this.options.chunkSize;if(this.ended)return!1;S=v===~~v?v:v===!0?4:0,typeof y=="string"?B.input=r.string2buf(y):u.call(y)==="[object ArrayBuffer]"?B.input=new Uint8Array(y):B.input=y,B.next_in=0,B.avail_in=B.input.length;do{if(B.avail_out===0&&(B.output=new a.Buf8(A),B.next_out=0,B.avail_out=A),(k=o.deflate(B,S))!==1&&k!==f)return this.onEnd(k),!(this.ended=!0);B.avail_out!==0&&(B.avail_in!==0||S!==4&&S!==2)||(this.options.to==="string"?this.onData(r.buf2binstring(a.shrinkBuf(B.output,B.next_out))):this.onData(a.shrinkBuf(B.output,B.next_out)))}while((0<B.avail_in||B.avail_out===0)&&k!==1);return S===4?(k=o.deflateEnd(this.strm),this.onEnd(k),this.ended=!0,k===f):S!==2||(this.onEnd(f),!(B.avail_out=0))},m.prototype.onData=function(y){this.chunks.push(y)},m.prototype.onEnd=function(y){y===f&&(this.options.to==="string"?this.result=this.chunks.join(""):this.result=a.flattenChunks(this.chunks)),this.chunks=[],this.err=y,this.msg=this.strm.msg},s.Deflate=m,s.deflate=b,s.deflateRaw=function(y,v){return(v=v||{}).raw=!0,b(y,v)},s.gzip=function(y,v){return(v=v||{}).gzip=!0,b(y,v)}},{"./utils/common":41,"./utils/strings":42,"./zlib/deflate":46,"./zlib/messages":51,"./zlib/zstream":53}],40:[function(i,n,s){var o=i("./zlib/inflate"),a=i("./utils/common"),r=i("./utils/strings"),l=i("./zlib/constants"),c=i("./zlib/messages"),u=i("./zlib/zstream"),f=i("./zlib/gzheader"),d=Object.prototype.toString;function p(m){if(!(this instanceof p))return new p(m);this.options=a.assign({chunkSize:16384,windowBits:0,to:""},m||{});var b=this.options;b.raw&&0<=b.windowBits&&b.windowBits<16&&(b.windowBits=-b.windowBits,b.windowBits===0&&(b.windowBits=-15)),!(0<=b.windowBits&&b.windowBits<16)||m&&m.windowBits||(b.windowBits+=32),15<b.windowBits&&b.windowBits<48&&(15&b.windowBits)==0&&(b.windowBits|=15),this.err=0,this.msg="",this.ended=!1,this.chunks=[],this.strm=new u,this.strm.avail_out=0;var y=o.inflateInit2(this.strm,b.windowBits);if(y!==l.Z_OK)throw new Error(c[y]);this.header=new f,o.inflateGetHeader(this.strm,this.header)}function w(m,b){var y=new p(b);if(y.push(m,!0),y.err)throw y.msg||c[y.err];return y.result}p.prototype.push=function(m,b){var y,v,k,S,B,A,C=this.strm,L=this.options.chunkSize,z=this.options.dictionary,N=!1;if(this.ended)return!1;v=b===~~b?b:b===!0?l.Z_FINISH:l.Z_NO_FLUSH,typeof m=="string"?C.input=r.binstring2buf(m):d.call(m)==="[object ArrayBuffer]"?C.input=new Uint8Array(m):C.input=m,C.next_in=0,C.avail_in=C.input.length;do{if(C.avail_out===0&&(C.output=new a.Buf8(L),C.next_out=0,C.avail_out=L),(y=o.inflate(C,l.Z_NO_FLUSH))===l.Z_NEED_DICT&&z&&(A=typeof z=="string"?r.string2buf(z):d.call(z)==="[object ArrayBuffer]"?new Uint8Array(z):z,y=o.inflateSetDictionary(this.strm,A)),y===l.Z_BUF_ERROR&&N===!0&&(y=l.Z_OK,N=!1),y!==l.Z_STREAM_END&&y!==l.Z_OK)return this.onEnd(y),!(this.ended=!0);C.next_out&&(C.avail_out!==0&&y!==l.Z_STREAM_END&&(C.avail_in!==0||v!==l.Z_FINISH&&v!==l.Z_SYNC_FLUSH)||(this.options.to==="string"?(k=r.utf8border(C.output,C.next_out),S=C.next_out-k,B=r.buf2string(C.output,k),C.next_out=S,C.avail_out=L-S,S&&a.arraySet(C.output,C.output,k,S,0),this.onData(B)):this.onData(a.shrinkBuf(C.output,C.next_out)))),C.avail_in===0&&C.avail_out===0&&(N=!0)}while((0<C.avail_in||C.avail_out===0)&&y!==l.Z_STREAM_END);return y===l.Z_STREAM_END&&(v=l.Z_FINISH),v===l.Z_FINISH?(y=o.inflateEnd(this.strm),this.onEnd(y),this.ended=!0,y===l.Z_OK):v!==l.Z_SYNC_FLUSH||(this.onEnd(l.Z_OK),!(C.avail_out=0))},p.prototype.onData=function(m){this.chunks.push(m)},p.prototype.onEnd=function(m){m===l.Z_OK&&(this.options.to==="string"?this.result=this.chunks.join(""):this.result=a.flattenChunks(this.chunks)),this.chunks=[],this.err=m,this.msg=this.strm.msg},s.Inflate=p,s.inflate=w,s.inflateRaw=function(m,b){return(b=b||{}).raw=!0,w(m,b)},s.ungzip=w},{"./utils/common":41,"./utils/strings":42,"./zlib/constants":44,"./zlib/gzheader":47,"./zlib/inflate":49,"./zlib/messages":51,"./zlib/zstream":53}],41:[function(i,n,s){var o=typeof Uint8Array<"u"&&typeof Uint16Array<"u"&&typeof Int32Array<"u";s.assign=function(l){for(var c=Array.prototype.slice.call(arguments,1);c.length;){var u=c.shift();if(u){if(typeof u!="object")throw new TypeError(u+"must be non-object");for(var f in u)u.hasOwnProperty(f)&&(l[f]=u[f])}}return l},s.shrinkBuf=function(l,c){return l.length===c?l:l.subarray?l.subarray(0,c):(l.length=c,l)};var a={arraySet:function(l,c,u,f,d){if(c.subarray&&l.subarray)l.set(c.subarray(u,u+f),d);else for(var p=0;p<f;p++)l[d+p]=c[u+p]},flattenChunks:function(l){var c,u,f,d,p,w;for(c=f=0,u=l.length;c<u;c++)f+=l[c].length;for(w=new Uint8Array(f),c=d=0,u=l.length;c<u;c++)p=l[c],w.set(p,d),d+=p.length;return w}},r={arraySet:function(l,c,u,f,d){for(var p=0;p<f;p++)l[d+p]=c[u+p]},flattenChunks:function(l){return[].concat.apply([],l)}};s.setTyped=function(l){l?(s.Buf8=Uint8Array,s.Buf16=Uint16Array,s.Buf32=Int32Array,s.assign(s,a)):(s.Buf8=Array,s.Buf16=Array,s.Buf32=Array,s.assign(s,r))},s.setTyped(o)},{}],42:[function(i,n,s){var o=i("./common"),a=!0,r=!0;try{String.fromCharCode.apply(null,[0])}catch{a=!1}try{String.fromCharCode.apply(null,new Uint8Array(1))}catch{r=!1}for(var l=new o.Buf8(256),c=0;c<256;c++)l[c]=252<=c?6:248<=c?5:240<=c?4:224<=c?3:192<=c?2:1;function u(f,d){if(d<65537&&(f.subarray&&r||!f.subarray&&a))return String.fromCharCode.apply(null,o.shrinkBuf(f,d));for(var p="",w=0;w<d;w++)p+=String.fromCharCode(f[w]);return p}l[254]=l[254]=1,s.string2buf=function(f){var d,p,w,m,b,y=f.length,v=0;for(m=0;m<y;m++)(64512&(p=f.charCodeAt(m)))==55296&&m+1<y&&(64512&(w=f.charCodeAt(m+1)))==56320&&(p=65536+(p-55296<<10)+(w-56320),m++),v+=p<128?1:p<2048?2:p<65536?3:4;for(d=new o.Buf8(v),m=b=0;b<v;m++)(64512&(p=f.charCodeAt(m)))==55296&&m+1<y&&(64512&(w=f.charCodeAt(m+1)))==56320&&(p=65536+(p-55296<<10)+(w-56320),m++),p<128?d[b++]=p:(p<2048?d[b++]=192|p>>>6:(p<65536?d[b++]=224|p>>>12:(d[b++]=240|p>>>18,d[b++]=128|p>>>12&63),d[b++]=128|p>>>6&63),d[b++]=128|63&p);return d},s.buf2binstring=function(f){return u(f,f.length)},s.binstring2buf=function(f){for(var d=new o.Buf8(f.length),p=0,w=d.length;p<w;p++)d[p]=f.charCodeAt(p);return d},s.buf2string=function(f,d){var p,w,m,b,y=d||f.length,v=new Array(2*y);for(p=w=0;p<y;)if((m=f[p++])<128)v[w++]=m;else if(4<(b=l[m]))v[w++]=65533,p+=b-1;else{for(m&=b===2?31:b===3?15:7;1<b&&p<y;)m=m<<6|63&f[p++],b--;1<b?v[w++]=65533:m<65536?v[w++]=m:(m-=65536,v[w++]=55296|m>>10&1023,v[w++]=56320|1023&m)}return u(v,w)},s.utf8border=function(f,d){var p;for((d=d||f.length)>f.length&&(d=f.length),p=d-1;0<=p&&(192&f[p])==128;)p--;return p<0||p===0?d:p+l[f[p]]>d?p:d}},{"./common":41}],43:[function(i,n,s){n.exports=function(o,a,r,l){for(var c=65535&o|0,u=o>>>16&65535|0,f=0;r!==0;){for(r-=f=2e3<r?2e3:r;u=u+(c=c+a[l++]|0)|0,--f;);c%=65521,u%=65521}return c|u<<16|0}},{}],44:[function(i,n,s){n.exports={Z_NO_FLUSH:0,Z_PARTIAL_FLUSH:1,Z_SYNC_FLUSH:2,Z_FULL_FLUSH:3,Z_FINISH:4,Z_BLOCK:5,Z_TREES:6,Z_OK:0,Z_STREAM_END:1,Z_NEED_DICT:2,Z_ERRNO:-1,Z_STREAM_ERROR:-2,Z_DATA_ERROR:-3,Z_BUF_ERROR:-5,Z_NO_COMPRESSION:0,Z_BEST_SPEED:1,Z_BEST_COMPRESSION:9,Z_DEFAULT_COMPRESSION:-1,Z_FILTERED:1,Z_HUFFMAN_ONLY:2,Z_RLE:3,Z_FIXED:4,Z_DEFAULT_STRATEGY:0,Z_BINARY:0,Z_TEXT:1,Z_UNKNOWN:2,Z_DEFLATED:8}},{}],45:[function(i,n,s){var o=(function(){for(var a,r=[],l=0;l<256;l++){a=l;for(var c=0;c<8;c++)a=1&a?3988292384^a>>>1:a>>>1;r[l]=a}return r})();n.exports=function(a,r,l,c){var u=o,f=c+l;a^=-1;for(var d=c;d<f;d++)a=a>>>8^u[255&(a^r[d])];return-1^a}},{}],46:[function(i,n,s){var o,a=i("../utils/common"),r=i("./trees"),l=i("./adler32"),c=i("./crc32"),u=i("./messages"),f=0,d=4,p=0,w=-2,m=-1,b=4,y=2,v=8,k=9,S=286,B=30,A=19,C=2*S+1,L=15,z=3,N=258,K=N+z+1,_=42,U=113,x=1,q=2,O=3,$=4;function T(g,W){return g.msg=u[W],W}function P(g){return(g<<1)-(4<g?9:0)}function se(g){for(var W=g.length;0<=--W;)g[W]=0}function V(g){var W=g.state,j=W.pending;j>g.avail_out&&(j=g.avail_out),j!==0&&(a.arraySet(g.output,W.pending_buf,W.pending_out,j,g.next_out),g.next_out+=j,W.pending_out+=j,g.total_out+=j,g.avail_out-=j,W.pending-=j,W.pending===0&&(W.pending_out=0))}function Y(g,W){r._tr_flush_block(g,0<=g.block_start?g.block_start:-1,g.strstart-g.block_start,W),g.block_start=g.strstart,V(g.strm)}function ce(g,W){g.pending_buf[g.pending++]=W}function ie(g,W){g.pending_buf[g.pending++]=W>>>8&255,g.pending_buf[g.pending++]=255&W}function re(g,W){var j,M,I=g.max_chain_length,R=g.strstart,G=g.prev_length,D=g.nice_match,H=g.strstart>g.w_size-K?g.strstart-(g.w_size-K):0,Z=g.window,te=g.w_mask,ne=g.prev,me=g.strstart+N,$e=Z[R+G-1],xe=Z[R+G];g.prev_length>=g.good_match&&(I>>=2),D>g.lookahead&&(D=g.lookahead);do if(Z[(j=W)+G]===xe&&Z[j+G-1]===$e&&Z[j]===Z[R]&&Z[++j]===Z[R+1]){R+=2,j++;do;while(Z[++R]===Z[++j]&&Z[++R]===Z[++j]&&Z[++R]===Z[++j]&&Z[++R]===Z[++j]&&Z[++R]===Z[++j]&&Z[++R]===Z[++j]&&Z[++R]===Z[++j]&&Z[++R]===Z[++j]&&R<me);if(M=N-(me-R),R=me-N,G<M){if(g.match_start=W,D<=(G=M))break;$e=Z[R+G-1],xe=Z[R+G]}}while((W=ne[W&te])>H&&--I!=0);return G<=g.lookahead?G:g.lookahead}function Se(g){var W,j,M,I,R,G,D,H,Z,te,ne=g.w_size;do{if(I=g.window_size-g.lookahead-g.strstart,g.strstart>=ne+(ne-K)){for(a.arraySet(g.window,g.window,ne,ne,0),g.match_start-=ne,g.strstart-=ne,g.block_start-=ne,W=j=g.hash_size;M=g.head[--W],g.head[W]=ne<=M?M-ne:0,--j;);for(W=j=ne;M=g.prev[--W],g.prev[W]=ne<=M?M-ne:0,--j;);I+=ne}if(g.strm.avail_in===0)break;if(G=g.strm,D=g.window,H=g.strstart+g.lookahead,Z=I,te=void 0,te=G.avail_in,Z<te&&(te=Z),j=te===0?0:(G.avail_in-=te,a.arraySet(D,G.input,G.next_in,te,H),G.state.wrap===1?G.adler=l(G.adler,D,te,H):G.state.wrap===2&&(G.adler=c(G.adler,D,te,H)),G.next_in+=te,G.total_in+=te,te),g.lookahead+=j,g.lookahead+g.insert>=z)for(R=g.strstart-g.insert,g.ins_h=g.window[R],g.ins_h=(g.ins_h<<g.hash_shift^g.window[R+1])&g.hash_mask;g.insert&&(g.ins_h=(g.ins_h<<g.hash_shift^g.window[R+z-1])&g.hash_mask,g.prev[R&g.w_mask]=g.head[g.ins_h],g.head[g.ins_h]=R,R++,g.insert--,!(g.lookahead+g.insert<z)););}while(g.lookahead<K&&g.strm.avail_in!==0)}function Ie(g,W){for(var j,M;;){if(g.lookahead<K){if(Se(g),g.lookahead<K&&W===f)return x;if(g.lookahead===0)break}if(j=0,g.lookahead>=z&&(g.ins_h=(g.ins_h<<g.hash_shift^g.window[g.strstart+z-1])&g.hash_mask,j=g.prev[g.strstart&g.w_mask]=g.head[g.ins_h],g.head[g.ins_h]=g.strstart),j!==0&&g.strstart-j<=g.w_size-K&&(g.match_length=re(g,j)),g.match_length>=z)if(M=r._tr_tally(g,g.strstart-g.match_start,g.match_length-z),g.lookahead-=g.match_length,g.match_length<=g.max_lazy_match&&g.lookahead>=z){for(g.match_length--;g.strstart++,g.ins_h=(g.ins_h<<g.hash_shift^g.window[g.strstart+z-1])&g.hash_mask,j=g.prev[g.strstart&g.w_mask]=g.head[g.ins_h],g.head[g.ins_h]=g.strstart,--g.match_length!=0;);g.strstart++}else g.strstart+=g.match_length,g.match_length=0,g.ins_h=g.window[g.strstart],g.ins_h=(g.ins_h<<g.hash_shift^g.window[g.strstart+1])&g.hash_mask;else M=r._tr_tally(g,0,g.window[g.strstart]),g.lookahead--,g.strstart++;if(M&&(Y(g,!1),g.strm.avail_out===0))return x}return g.insert=g.strstart<z-1?g.strstart:z-1,W===d?(Y(g,!0),g.strm.avail_out===0?O:$):g.last_lit&&(Y(g,!1),g.strm.avail_out===0)?x:q}function _e(g,W){for(var j,M,I;;){if(g.lookahead<K){if(Se(g),g.lookahead<K&&W===f)return x;if(g.lookahead===0)break}if(j=0,g.lookahead>=z&&(g.ins_h=(g.ins_h<<g.hash_shift^g.window[g.strstart+z-1])&g.hash_mask,j=g.prev[g.strstart&g.w_mask]=g.head[g.ins_h],g.head[g.ins_h]=g.strstart),g.prev_length=g.match_length,g.prev_match=g.match_start,g.match_length=z-1,j!==0&&g.prev_length<g.max_lazy_match&&g.strstart-j<=g.w_size-K&&(g.match_length=re(g,j),g.match_length<=5&&(g.strategy===1||g.match_length===z&&4096<g.strstart-g.match_start)&&(g.match_length=z-1)),g.prev_length>=z&&g.match_length<=g.prev_length){for(I=g.strstart+g.lookahead-z,M=r._tr_tally(g,g.strstart-1-g.prev_match,g.prev_length-z),g.lookahead-=g.prev_length-1,g.prev_length-=2;++g.strstart<=I&&(g.ins_h=(g.ins_h<<g.hash_shift^g.window[g.strstart+z-1])&g.hash_mask,j=g.prev[g.strstart&g.w_mask]=g.head[g.ins_h],g.head[g.ins_h]=g.strstart),--g.prev_length!=0;);if(g.match_available=0,g.match_length=z-1,g.strstart++,M&&(Y(g,!1),g.strm.avail_out===0))return x}else if(g.match_available){if((M=r._tr_tally(g,0,g.window[g.strstart-1]))&&Y(g,!1),g.strstart++,g.lookahead--,g.strm.avail_out===0)return x}else g.match_available=1,g.strstart++,g.lookahead--}return g.match_available&&(M=r._tr_tally(g,0,g.window[g.strstart-1]),g.match_available=0),g.insert=g.strstart<z-1?g.strstart:z-1,W===d?(Y(g,!0),g.strm.avail_out===0?O:$):g.last_lit&&(Y(g,!1),g.strm.avail_out===0)?x:q}function fe(g,W,j,M,I){this.good_length=g,this.max_lazy=W,this.nice_length=j,this.max_chain=M,this.func=I}function X(){this.strm=null,this.status=0,this.pending_buf=null,this.pending_buf_size=0,this.pending_out=0,this.pending=0,this.wrap=0,this.gzhead=null,this.gzindex=0,this.method=v,this.last_flush=-1,this.w_size=0,this.w_bits=0,this.w_mask=0,this.window=null,this.window_size=0,this.prev=null,this.head=null,this.ins_h=0,this.hash_size=0,this.hash_bits=0,this.hash_mask=0,this.hash_shift=0,this.block_start=0,this.match_length=0,this.prev_match=0,this.match_available=0,this.strstart=0,this.match_start=0,this.lookahead=0,this.prev_length=0,this.max_chain_length=0,this.max_lazy_match=0,this.level=0,this.strategy=0,this.good_match=0,this.nice_match=0,this.dyn_ltree=new a.Buf16(2*C),this.dyn_dtree=new a.Buf16(2*(2*B+1)),this.bl_tree=new a.Buf16(2*(2*A+1)),se(this.dyn_ltree),se(this.dyn_dtree),se(this.bl_tree),this.l_desc=null,this.d_desc=null,this.bl_desc=null,this.bl_count=new a.Buf16(L+1),this.heap=new a.Buf16(2*S+1),se(this.heap),this.heap_len=0,this.heap_max=0,this.depth=new a.Buf16(2*S+1),se(this.depth),this.l_buf=0,this.lit_bufsize=0,this.last_lit=0,this.d_buf=0,this.opt_len=0,this.static_len=0,this.matches=0,this.insert=0,this.bi_buf=0,this.bi_valid=0}function pe(g){var W;return g&&g.state?(g.total_in=g.total_out=0,g.data_type=y,(W=g.state).pending=0,W.pending_out=0,W.wrap<0&&(W.wrap=-W.wrap),W.status=W.wrap?_:U,g.adler=W.wrap===2?0:1,W.last_flush=f,r._tr_init(W),p):T(g,w)}function E(g){var W=pe(g);return W===p&&(function(j){j.window_size=2*j.w_size,se(j.head),j.max_lazy_match=o[j.level].max_lazy,j.good_match=o[j.level].good_length,j.nice_match=o[j.level].nice_length,j.max_chain_length=o[j.level].max_chain,j.strstart=0,j.block_start=0,j.lookahead=0,j.insert=0,j.match_length=j.prev_length=z-1,j.match_available=0,j.ins_h=0})(g.state),W}function F(g,W,j,M,I,R){if(!g)return w;var G=1;if(W===m&&(W=6),M<0?(G=0,M=-M):15<M&&(G=2,M-=16),I<1||k<I||j!==v||M<8||15<M||W<0||9<W||R<0||b<R)return T(g,w);M===8&&(M=9);var D=new X;return(g.state=D).strm=g,D.wrap=G,D.gzhead=null,D.w_bits=M,D.w_size=1<<D.w_bits,D.w_mask=D.w_size-1,D.hash_bits=I+7,D.hash_size=1<<D.hash_bits,D.hash_mask=D.hash_size-1,D.hash_shift=~~((D.hash_bits+z-1)/z),D.window=new a.Buf8(2*D.w_size),D.head=new a.Buf16(D.hash_size),D.prev=new a.Buf16(D.w_size),D.lit_bufsize=1<<I+6,D.pending_buf_size=4*D.lit_bufsize,D.pending_buf=new a.Buf8(D.pending_buf_size),D.d_buf=1*D.lit_bufsize,D.l_buf=3*D.lit_bufsize,D.level=W,D.strategy=R,D.method=j,E(g)}o=[new fe(0,0,0,0,function(g,W){var j=65535;for(j>g.pending_buf_size-5&&(j=g.pending_buf_size-5);;){if(g.lookahead<=1){if(Se(g),g.lookahead===0&&W===f)return x;if(g.lookahead===0)break}g.strstart+=g.lookahead,g.lookahead=0;var M=g.block_start+j;if((g.strstart===0||g.strstart>=M)&&(g.lookahead=g.strstart-M,g.strstart=M,Y(g,!1),g.strm.avail_out===0)||g.strstart-g.block_start>=g.w_size-K&&(Y(g,!1),g.strm.avail_out===0))return x}return g.insert=0,W===d?(Y(g,!0),g.strm.avail_out===0?O:$):(g.strstart>g.block_start&&(Y(g,!1),g.strm.avail_out),x)}),new fe(4,4,8,4,Ie),new fe(4,5,16,8,Ie),new fe(4,6,32,32,Ie),new fe(4,4,16,16,_e),new fe(8,16,32,32,_e),new fe(8,16,128,128,_e),new fe(8,32,128,256,_e),new fe(32,128,258,1024,_e),new fe(32,258,258,4096,_e)],s.deflateInit=function(g,W){return F(g,W,v,15,8,0)},s.deflateInit2=F,s.deflateReset=E,s.deflateResetKeep=pe,s.deflateSetHeader=function(g,W){return g&&g.state?g.state.wrap!==2?w:(g.state.gzhead=W,p):w},s.deflate=function(g,W){var j,M,I,R;if(!g||!g.state||5<W||W<0)return g?T(g,w):w;if(M=g.state,!g.output||!g.input&&g.avail_in!==0||M.status===666&&W!==d)return T(g,g.avail_out===0?-5:w);if(M.strm=g,j=M.last_flush,M.last_flush=W,M.status===_)if(M.wrap===2)g.adler=0,ce(M,31),ce(M,139),ce(M,8),M.gzhead?(ce(M,(M.gzhead.text?1:0)+(M.gzhead.hcrc?2:0)+(M.gzhead.extra?4:0)+(M.gzhead.name?8:0)+(M.gzhead.comment?16:0)),ce(M,255&M.gzhead.time),ce(M,M.gzhead.time>>8&255),ce(M,M.gzhead.time>>16&255),ce(M,M.gzhead.time>>24&255),ce(M,M.level===9?2:2<=M.strategy||M.level<2?4:0),ce(M,255&M.gzhead.os),M.gzhead.extra&&M.gzhead.extra.length&&(ce(M,255&M.gzhead.extra.length),ce(M,M.gzhead.extra.length>>8&255)),M.gzhead.hcrc&&(g.adler=c(g.adler,M.pending_buf,M.pending,0)),M.gzindex=0,M.status=69):(ce(M,0),ce(M,0),ce(M,0),ce(M,0),ce(M,0),ce(M,M.level===9?2:2<=M.strategy||M.level<2?4:0),ce(M,3),M.status=U);else{var G=v+(M.w_bits-8<<4)<<8;G|=(2<=M.strategy||M.level<2?0:M.level<6?1:M.level===6?2:3)<<6,M.strstart!==0&&(G|=32),G+=31-G%31,M.status=U,ie(M,G),M.strstart!==0&&(ie(M,g.adler>>>16),ie(M,65535&g.adler)),g.adler=1}if(M.status===69)if(M.gzhead.extra){for(I=M.pending;M.gzindex<(65535&M.gzhead.extra.length)&&(M.pending!==M.pending_buf_size||(M.gzhead.hcrc&&M.pending>I&&(g.adler=c(g.adler,M.pending_buf,M.pending-I,I)),V(g),I=M.pending,M.pending!==M.pending_buf_size));)ce(M,255&M.gzhead.extra[M.gzindex]),M.gzindex++;M.gzhead.hcrc&&M.pending>I&&(g.adler=c(g.adler,M.pending_buf,M.pending-I,I)),M.gzindex===M.gzhead.extra.length&&(M.gzindex=0,M.status=73)}else M.status=73;if(M.status===73)if(M.gzhead.name){I=M.pending;do{if(M.pending===M.pending_buf_size&&(M.gzhead.hcrc&&M.pending>I&&(g.adler=c(g.adler,M.pending_buf,M.pending-I,I)),V(g),I=M.pending,M.pending===M.pending_buf_size)){R=1;break}R=M.gzindex<M.gzhead.name.length?255&M.gzhead.name.charCodeAt(M.gzindex++):0,ce(M,R)}while(R!==0);M.gzhead.hcrc&&M.pending>I&&(g.adler=c(g.adler,M.pending_buf,M.pending-I,I)),R===0&&(M.gzindex=0,M.status=91)}else M.status=91;if(M.status===91)if(M.gzhead.comment){I=M.pending;do{if(M.pending===M.pending_buf_size&&(M.gzhead.hcrc&&M.pending>I&&(g.adler=c(g.adler,M.pending_buf,M.pending-I,I)),V(g),I=M.pending,M.pending===M.pending_buf_size)){R=1;break}R=M.gzindex<M.gzhead.comment.length?255&M.gzhead.comment.charCodeAt(M.gzindex++):0,ce(M,R)}while(R!==0);M.gzhead.hcrc&&M.pending>I&&(g.adler=c(g.adler,M.pending_buf,M.pending-I,I)),R===0&&(M.status=103)}else M.status=103;if(M.status===103&&(M.gzhead.hcrc?(M.pending+2>M.pending_buf_size&&V(g),M.pending+2<=M.pending_buf_size&&(ce(M,255&g.adler),ce(M,g.adler>>8&255),g.adler=0,M.status=U)):M.status=U),M.pending!==0){if(V(g),g.avail_out===0)return M.last_flush=-1,p}else if(g.avail_in===0&&P(W)<=P(j)&&W!==d)return T(g,-5);if(M.status===666&&g.avail_in!==0)return T(g,-5);if(g.avail_in!==0||M.lookahead!==0||W!==f&&M.status!==666){var D=M.strategy===2?(function(H,Z){for(var te;;){if(H.lookahead===0&&(Se(H),H.lookahead===0)){if(Z===f)return x;break}if(H.match_length=0,te=r._tr_tally(H,0,H.window[H.strstart]),H.lookahead--,H.strstart++,te&&(Y(H,!1),H.strm.avail_out===0))return x}return H.insert=0,Z===d?(Y(H,!0),H.strm.avail_out===0?O:$):H.last_lit&&(Y(H,!1),H.strm.avail_out===0)?x:q})(M,W):M.strategy===3?(function(H,Z){for(var te,ne,me,$e,xe=H.window;;){if(H.lookahead<=N){if(Se(H),H.lookahead<=N&&Z===f)return x;if(H.lookahead===0)break}if(H.match_length=0,H.lookahead>=z&&0<H.strstart&&(ne=xe[me=H.strstart-1])===xe[++me]&&ne===xe[++me]&&ne===xe[++me]){$e=H.strstart+N;do;while(ne===xe[++me]&&ne===xe[++me]&&ne===xe[++me]&&ne===xe[++me]&&ne===xe[++me]&&ne===xe[++me]&&ne===xe[++me]&&ne===xe[++me]&&me<$e);H.match_length=N-($e-me),H.match_length>H.lookahead&&(H.match_length=H.lookahead)}if(H.match_length>=z?(te=r._tr_tally(H,1,H.match_length-z),H.lookahead-=H.match_length,H.strstart+=H.match_length,H.match_length=0):(te=r._tr_tally(H,0,H.window[H.strstart]),H.lookahead--,H.strstart++),te&&(Y(H,!1),H.strm.avail_out===0))return x}return H.insert=0,Z===d?(Y(H,!0),H.strm.avail_out===0?O:$):H.last_lit&&(Y(H,!1),H.strm.avail_out===0)?x:q})(M,W):o[M.level].func(M,W);if(D!==O&&D!==$||(M.status=666),D===x||D===O)return g.avail_out===0&&(M.last_flush=-1),p;if(D===q&&(W===1?r._tr_align(M):W!==5&&(r._tr_stored_block(M,0,0,!1),W===3&&(se(M.head),M.lookahead===0&&(M.strstart=0,M.block_start=0,M.insert=0))),V(g),g.avail_out===0))return M.last_flush=-1,p}return W!==d?p:M.wrap<=0?1:(M.wrap===2?(ce(M,255&g.adler),ce(M,g.adler>>8&255),ce(M,g.adler>>16&255),ce(M,g.adler>>24&255),ce(M,255&g.total_in),ce(M,g.total_in>>8&255),ce(M,g.total_in>>16&255),ce(M,g.total_in>>24&255)):(ie(M,g.adler>>>16),ie(M,65535&g.adler)),V(g),0<M.wrap&&(M.wrap=-M.wrap),M.pending!==0?p:1)},s.deflateEnd=function(g){var W;return g&&g.state?(W=g.state.status)!==_&&W!==69&&W!==73&&W!==91&&W!==103&&W!==U&&W!==666?T(g,w):(g.state=null,W===U?T(g,-3):p):w},s.deflateSetDictionary=function(g,W){var j,M,I,R,G,D,H,Z,te=W.length;if(!g||!g.state||(R=(j=g.state).wrap)===2||R===1&&j.status!==_||j.lookahead)return w;for(R===1&&(g.adler=l(g.adler,W,te,0)),j.wrap=0,te>=j.w_size&&(R===0&&(se(j.head),j.strstart=0,j.block_start=0,j.insert=0),Z=new a.Buf8(j.w_size),a.arraySet(Z,W,te-j.w_size,j.w_size,0),W=Z,te=j.w_size),G=g.avail_in,D=g.next_in,H=g.input,g.avail_in=te,g.next_in=0,g.input=W,Se(j);j.lookahead>=z;){for(M=j.strstart,I=j.lookahead-(z-1);j.ins_h=(j.ins_h<<j.hash_shift^j.window[M+z-1])&j.hash_mask,j.prev[M&j.w_mask]=j.head[j.ins_h],j.head[j.ins_h]=M,M++,--I;);j.strstart=M,j.lookahead=z-1,Se(j)}return j.strstart+=j.lookahead,j.block_start=j.strstart,j.insert=j.lookahead,j.lookahead=0,j.match_length=j.prev_length=z-1,j.match_available=0,g.next_in=D,g.input=H,g.avail_in=G,j.wrap=R,p},s.deflateInfo="pako deflate (from Nodeca project)"},{"../utils/common":41,"./adler32":43,"./crc32":45,"./messages":51,"./trees":52}],47:[function(i,n,s){n.exports=function(){this.text=0,this.time=0,this.xflags=0,this.os=0,this.extra=null,this.extra_len=0,this.name="",this.comment="",this.hcrc=0,this.done=!1}},{}],48:[function(i,n,s){n.exports=function(o,a){var r,l,c,u,f,d,p,w,m,b,y,v,k,S,B,A,C,L,z,N,K,_,U,x,q;r=o.state,l=o.next_in,x=o.input,c=l+(o.avail_in-5),u=o.next_out,q=o.output,f=u-(a-o.avail_out),d=u+(o.avail_out-257),p=r.dmax,w=r.wsize,m=r.whave,b=r.wnext,y=r.window,v=r.hold,k=r.bits,S=r.lencode,B=r.distcode,A=(1<<r.lenbits)-1,C=(1<<r.distbits)-1;e:do{k<15&&(v+=x[l++]<<k,k+=8,v+=x[l++]<<k,k+=8),L=S[v&A];t:for(;;){if(v>>>=z=L>>>24,k-=z,(z=L>>>16&255)===0)q[u++]=65535&L;else{if(!(16&z)){if((64&z)==0){L=S[(65535&L)+(v&(1<<z)-1)];continue t}if(32&z){r.mode=12;break e}o.msg="invalid literal/length code",r.mode=30;break e}N=65535&L,(z&=15)&&(k<z&&(v+=x[l++]<<k,k+=8),N+=v&(1<<z)-1,v>>>=z,k-=z),k<15&&(v+=x[l++]<<k,k+=8,v+=x[l++]<<k,k+=8),L=B[v&C];i:for(;;){if(v>>>=z=L>>>24,k-=z,!(16&(z=L>>>16&255))){if((64&z)==0){L=B[(65535&L)+(v&(1<<z)-1)];continue i}o.msg="invalid distance code",r.mode=30;break e}if(K=65535&L,k<(z&=15)&&(v+=x[l++]<<k,(k+=8)<z&&(v+=x[l++]<<k,k+=8)),p<(K+=v&(1<<z)-1)){o.msg="invalid distance too far back",r.mode=30;break e}if(v>>>=z,k-=z,(z=u-f)<K){if(m<(z=K-z)&&r.sane){o.msg="invalid distance too far back",r.mode=30;break e}if(U=y,(_=0)===b){if(_+=w-z,z<N){for(N-=z;q[u++]=y[_++],--z;);_=u-K,U=q}}else if(b<z){if(_+=w+b-z,(z-=b)<N){for(N-=z;q[u++]=y[_++],--z;);if(_=0,b<N){for(N-=z=b;q[u++]=y[_++],--z;);_=u-K,U=q}}}else if(_+=b-z,z<N){for(N-=z;q[u++]=y[_++],--z;);_=u-K,U=q}for(;2<N;)q[u++]=U[_++],q[u++]=U[_++],q[u++]=U[_++],N-=3;N&&(q[u++]=U[_++],1<N&&(q[u++]=U[_++]))}else{for(_=u-K;q[u++]=q[_++],q[u++]=q[_++],q[u++]=q[_++],2<(N-=3););N&&(q[u++]=q[_++],1<N&&(q[u++]=q[_++]))}break}}break}}while(l<c&&u<d);l-=N=k>>3,v&=(1<<(k-=N<<3))-1,o.next_in=l,o.next_out=u,o.avail_in=l<c?c-l+5:5-(l-c),o.avail_out=u<d?d-u+257:257-(u-d),r.hold=v,r.bits=k}},{}],49:[function(i,n,s){var o=i("../utils/common"),a=i("./adler32"),r=i("./crc32"),l=i("./inffast"),c=i("./inftrees"),u=1,f=2,d=0,p=-2,w=1,m=852,b=592;function y(_){return(_>>>24&255)+(_>>>8&65280)+((65280&_)<<8)+((255&_)<<24)}function v(){this.mode=0,this.last=!1,this.wrap=0,this.havedict=!1,this.flags=0,this.dmax=0,this.check=0,this.total=0,this.head=null,this.wbits=0,this.wsize=0,this.whave=0,this.wnext=0,this.window=null,this.hold=0,this.bits=0,this.length=0,this.offset=0,this.extra=0,this.lencode=null,this.distcode=null,this.lenbits=0,this.distbits=0,this.ncode=0,this.nlen=0,this.ndist=0,this.have=0,this.next=null,this.lens=new o.Buf16(320),this.work=new o.Buf16(288),this.lendyn=null,this.distdyn=null,this.sane=0,this.back=0,this.was=0}function k(_){var U;return _&&_.state?(U=_.state,_.total_in=_.total_out=U.total=0,_.msg="",U.wrap&&(_.adler=1&U.wrap),U.mode=w,U.last=0,U.havedict=0,U.dmax=32768,U.head=null,U.hold=0,U.bits=0,U.lencode=U.lendyn=new o.Buf32(m),U.distcode=U.distdyn=new o.Buf32(b),U.sane=1,U.back=-1,d):p}function S(_){var U;return _&&_.state?((U=_.state).wsize=0,U.whave=0,U.wnext=0,k(_)):p}function B(_,U){var x,q;return _&&_.state?(q=_.state,U<0?(x=0,U=-U):(x=1+(U>>4),U<48&&(U&=15)),U&&(U<8||15<U)?p:(q.window!==null&&q.wbits!==U&&(q.window=null),q.wrap=x,q.wbits=U,S(_))):p}function A(_,U){var x,q;return _?(q=new v,(_.state=q).window=null,(x=B(_,U))!==d&&(_.state=null),x):p}var C,L,z=!0;function N(_){if(z){var U;for(C=new o.Buf32(512),L=new o.Buf32(32),U=0;U<144;)_.lens[U++]=8;for(;U<256;)_.lens[U++]=9;for(;U<280;)_.lens[U++]=7;for(;U<288;)_.lens[U++]=8;for(c(u,_.lens,0,288,C,0,_.work,{bits:9}),U=0;U<32;)_.lens[U++]=5;c(f,_.lens,0,32,L,0,_.work,{bits:5}),z=!1}_.lencode=C,_.lenbits=9,_.distcode=L,_.distbits=5}function K(_,U,x,q){var O,$=_.state;return $.window===null&&($.wsize=1<<$.wbits,$.wnext=0,$.whave=0,$.window=new o.Buf8($.wsize)),q>=$.wsize?(o.arraySet($.window,U,x-$.wsize,$.wsize,0),$.wnext=0,$.whave=$.wsize):(q<(O=$.wsize-$.wnext)&&(O=q),o.arraySet($.window,U,x-q,O,$.wnext),(q-=O)?(o.arraySet($.window,U,x-q,q,0),$.wnext=q,$.whave=$.wsize):($.wnext+=O,$.wnext===$.wsize&&($.wnext=0),$.whave<$.wsize&&($.whave+=O))),0}s.inflateReset=S,s.inflateReset2=B,s.inflateResetKeep=k,s.inflateInit=function(_){return A(_,15)},s.inflateInit2=A,s.inflate=function(_,U){var x,q,O,$,T,P,se,V,Y,ce,ie,re,Se,Ie,_e,fe,X,pe,E,F,g,W,j,M,I=0,R=new o.Buf8(4),G=[16,17,18,0,8,7,9,6,10,5,11,4,12,3,13,2,14,1,15];if(!_||!_.state||!_.output||!_.input&&_.avail_in!==0)return p;(x=_.state).mode===12&&(x.mode=13),T=_.next_out,O=_.output,se=_.avail_out,$=_.next_in,q=_.input,P=_.avail_in,V=x.hold,Y=x.bits,ce=P,ie=se,W=d;e:for(;;)switch(x.mode){case w:if(x.wrap===0){x.mode=13;break}for(;Y<16;){if(P===0)break e;P--,V+=q[$++]<<Y,Y+=8}if(2&x.wrap&&V===35615){R[x.check=0]=255&V,R[1]=V>>>8&255,x.check=r(x.check,R,2,0),Y=V=0,x.mode=2;break}if(x.flags=0,x.head&&(x.head.done=!1),!(1&x.wrap)||(((255&V)<<8)+(V>>8))%31){_.msg="incorrect header check",x.mode=30;break}if((15&V)!=8){_.msg="unknown compression method",x.mode=30;break}if(Y-=4,g=8+(15&(V>>>=4)),x.wbits===0)x.wbits=g;else if(g>x.wbits){_.msg="invalid window size",x.mode=30;break}x.dmax=1<<g,_.adler=x.check=1,x.mode=512&V?10:12,Y=V=0;break;case 2:for(;Y<16;){if(P===0)break e;P--,V+=q[$++]<<Y,Y+=8}if(x.flags=V,(255&x.flags)!=8){_.msg="unknown compression method",x.mode=30;break}if(57344&x.flags){_.msg="unknown header flags set",x.mode=30;break}x.head&&(x.head.text=V>>8&1),512&x.flags&&(R[0]=255&V,R[1]=V>>>8&255,x.check=r(x.check,R,2,0)),Y=V=0,x.mode=3;case 3:for(;Y<32;){if(P===0)break e;P--,V+=q[$++]<<Y,Y+=8}x.head&&(x.head.time=V),512&x.flags&&(R[0]=255&V,R[1]=V>>>8&255,R[2]=V>>>16&255,R[3]=V>>>24&255,x.check=r(x.check,R,4,0)),Y=V=0,x.mode=4;case 4:for(;Y<16;){if(P===0)break e;P--,V+=q[$++]<<Y,Y+=8}x.head&&(x.head.xflags=255&V,x.head.os=V>>8),512&x.flags&&(R[0]=255&V,R[1]=V>>>8&255,x.check=r(x.check,R,2,0)),Y=V=0,x.mode=5;case 5:if(1024&x.flags){for(;Y<16;){if(P===0)break e;P--,V+=q[$++]<<Y,Y+=8}x.length=V,x.head&&(x.head.extra_len=V),512&x.flags&&(R[0]=255&V,R[1]=V>>>8&255,x.check=r(x.check,R,2,0)),Y=V=0}else x.head&&(x.head.extra=null);x.mode=6;case 6:if(1024&x.flags&&(P<(re=x.length)&&(re=P),re&&(x.head&&(g=x.head.extra_len-x.length,x.head.extra||(x.head.extra=new Array(x.head.extra_len)),o.arraySet(x.head.extra,q,$,re,g)),512&x.flags&&(x.check=r(x.check,q,re,$)),P-=re,$+=re,x.length-=re),x.length))break e;x.length=0,x.mode=7;case 7:if(2048&x.flags){if(P===0)break e;for(re=0;g=q[$+re++],x.head&&g&&x.length<65536&&(x.head.name+=String.fromCharCode(g)),g&&re<P;);if(512&x.flags&&(x.check=r(x.check,q,re,$)),P-=re,$+=re,g)break e}else x.head&&(x.head.name=null);x.length=0,x.mode=8;case 8:if(4096&x.flags){if(P===0)break e;for(re=0;g=q[$+re++],x.head&&g&&x.length<65536&&(x.head.comment+=String.fromCharCode(g)),g&&re<P;);if(512&x.flags&&(x.check=r(x.check,q,re,$)),P-=re,$+=re,g)break e}else x.head&&(x.head.comment=null);x.mode=9;case 9:if(512&x.flags){for(;Y<16;){if(P===0)break e;P--,V+=q[$++]<<Y,Y+=8}if(V!==(65535&x.check)){_.msg="header crc mismatch",x.mode=30;break}Y=V=0}x.head&&(x.head.hcrc=x.flags>>9&1,x.head.done=!0),_.adler=x.check=0,x.mode=12;break;case 10:for(;Y<32;){if(P===0)break e;P--,V+=q[$++]<<Y,Y+=8}_.adler=x.check=y(V),Y=V=0,x.mode=11;case 11:if(x.havedict===0)return _.next_out=T,_.avail_out=se,_.next_in=$,_.avail_in=P,x.hold=V,x.bits=Y,2;_.adler=x.check=1,x.mode=12;case 12:if(U===5||U===6)break e;case 13:if(x.last){V>>>=7&Y,Y-=7&Y,x.mode=27;break}for(;Y<3;){if(P===0)break e;P--,V+=q[$++]<<Y,Y+=8}switch(x.last=1&V,Y-=1,3&(V>>>=1)){case 0:x.mode=14;break;case 1:if(N(x),x.mode=20,U!==6)break;V>>>=2,Y-=2;break e;case 2:x.mode=17;break;case 3:_.msg="invalid block type",x.mode=30}V>>>=2,Y-=2;break;case 14:for(V>>>=7&Y,Y-=7&Y;Y<32;){if(P===0)break e;P--,V+=q[$++]<<Y,Y+=8}if((65535&V)!=(V>>>16^65535)){_.msg="invalid stored block lengths",x.mode=30;break}if(x.length=65535&V,Y=V=0,x.mode=15,U===6)break e;case 15:x.mode=16;case 16:if(re=x.length){if(P<re&&(re=P),se<re&&(re=se),re===0)break e;o.arraySet(O,q,$,re,T),P-=re,$+=re,se-=re,T+=re,x.length-=re;break}x.mode=12;break;case 17:for(;Y<14;){if(P===0)break e;P--,V+=q[$++]<<Y,Y+=8}if(x.nlen=257+(31&V),V>>>=5,Y-=5,x.ndist=1+(31&V),V>>>=5,Y-=5,x.ncode=4+(15&V),V>>>=4,Y-=4,286<x.nlen||30<x.ndist){_.msg="too many length or distance symbols",x.mode=30;break}x.have=0,x.mode=18;case 18:for(;x.have<x.ncode;){for(;Y<3;){if(P===0)break e;P--,V+=q[$++]<<Y,Y+=8}x.lens[G[x.have++]]=7&V,V>>>=3,Y-=3}for(;x.have<19;)x.lens[G[x.have++]]=0;if(x.lencode=x.lendyn,x.lenbits=7,j={bits:x.lenbits},W=c(0,x.lens,0,19,x.lencode,0,x.work,j),x.lenbits=j.bits,W){_.msg="invalid code lengths set",x.mode=30;break}x.have=0,x.mode=19;case 19:for(;x.have<x.nlen+x.ndist;){for(;fe=(I=x.lencode[V&(1<<x.lenbits)-1])>>>16&255,X=65535&I,!((_e=I>>>24)<=Y);){if(P===0)break e;P--,V+=q[$++]<<Y,Y+=8}if(X<16)V>>>=_e,Y-=_e,x.lens[x.have++]=X;else{if(X===16){for(M=_e+2;Y<M;){if(P===0)break e;P--,V+=q[$++]<<Y,Y+=8}if(V>>>=_e,Y-=_e,x.have===0){_.msg="invalid bit length repeat",x.mode=30;break}g=x.lens[x.have-1],re=3+(3&V),V>>>=2,Y-=2}else if(X===17){for(M=_e+3;Y<M;){if(P===0)break e;P--,V+=q[$++]<<Y,Y+=8}Y-=_e,g=0,re=3+(7&(V>>>=_e)),V>>>=3,Y-=3}else{for(M=_e+7;Y<M;){if(P===0)break e;P--,V+=q[$++]<<Y,Y+=8}Y-=_e,g=0,re=11+(127&(V>>>=_e)),V>>>=7,Y-=7}if(x.have+re>x.nlen+x.ndist){_.msg="invalid bit length repeat",x.mode=30;break}for(;re--;)x.lens[x.have++]=g}}if(x.mode===30)break;if(x.lens[256]===0){_.msg="invalid code -- missing end-of-block",x.mode=30;break}if(x.lenbits=9,j={bits:x.lenbits},W=c(u,x.lens,0,x.nlen,x.lencode,0,x.work,j),x.lenbits=j.bits,W){_.msg="invalid literal/lengths set",x.mode=30;break}if(x.distbits=6,x.distcode=x.distdyn,j={bits:x.distbits},W=c(f,x.lens,x.nlen,x.ndist,x.distcode,0,x.work,j),x.distbits=j.bits,W){_.msg="invalid distances set",x.mode=30;break}if(x.mode=20,U===6)break e;case 20:x.mode=21;case 21:if(6<=P&&258<=se){_.next_out=T,_.avail_out=se,_.next_in=$,_.avail_in=P,x.hold=V,x.bits=Y,l(_,ie),T=_.next_out,O=_.output,se=_.avail_out,$=_.next_in,q=_.input,P=_.avail_in,V=x.hold,Y=x.bits,x.mode===12&&(x.back=-1);break}for(x.back=0;fe=(I=x.lencode[V&(1<<x.lenbits)-1])>>>16&255,X=65535&I,!((_e=I>>>24)<=Y);){if(P===0)break e;P--,V+=q[$++]<<Y,Y+=8}if(fe&&(240&fe)==0){for(pe=_e,E=fe,F=X;fe=(I=x.lencode[F+((V&(1<<pe+E)-1)>>pe)])>>>16&255,X=65535&I,!(pe+(_e=I>>>24)<=Y);){if(P===0)break e;P--,V+=q[$++]<<Y,Y+=8}V>>>=pe,Y-=pe,x.back+=pe}if(V>>>=_e,Y-=_e,x.back+=_e,x.length=X,fe===0){x.mode=26;break}if(32&fe){x.back=-1,x.mode=12;break}if(64&fe){_.msg="invalid literal/length code",x.mode=30;break}x.extra=15&fe,x.mode=22;case 22:if(x.extra){for(M=x.extra;Y<M;){if(P===0)break e;P--,V+=q[$++]<<Y,Y+=8}x.length+=V&(1<<x.extra)-1,V>>>=x.extra,Y-=x.extra,x.back+=x.extra}x.was=x.length,x.mode=23;case 23:for(;fe=(I=x.distcode[V&(1<<x.distbits)-1])>>>16&255,X=65535&I,!((_e=I>>>24)<=Y);){if(P===0)break e;P--,V+=q[$++]<<Y,Y+=8}if((240&fe)==0){for(pe=_e,E=fe,F=X;fe=(I=x.distcode[F+((V&(1<<pe+E)-1)>>pe)])>>>16&255,X=65535&I,!(pe+(_e=I>>>24)<=Y);){if(P===0)break e;P--,V+=q[$++]<<Y,Y+=8}V>>>=pe,Y-=pe,x.back+=pe}if(V>>>=_e,Y-=_e,x.back+=_e,64&fe){_.msg="invalid distance code",x.mode=30;break}x.offset=X,x.extra=15&fe,x.mode=24;case 24:if(x.extra){for(M=x.extra;Y<M;){if(P===0)break e;P--,V+=q[$++]<<Y,Y+=8}x.offset+=V&(1<<x.extra)-1,V>>>=x.extra,Y-=x.extra,x.back+=x.extra}if(x.offset>x.dmax){_.msg="invalid distance too far back",x.mode=30;break}x.mode=25;case 25:if(se===0)break e;if(re=ie-se,x.offset>re){if((re=x.offset-re)>x.whave&&x.sane){_.msg="invalid distance too far back",x.mode=30;break}Se=re>x.wnext?(re-=x.wnext,x.wsize-re):x.wnext-re,re>x.length&&(re=x.length),Ie=x.window}else Ie=O,Se=T-x.offset,re=x.length;for(se<re&&(re=se),se-=re,x.length-=re;O[T++]=Ie[Se++],--re;);x.length===0&&(x.mode=21);break;case 26:if(se===0)break e;O[T++]=x.length,se--,x.mode=21;break;case 27:if(x.wrap){for(;Y<32;){if(P===0)break e;P--,V|=q[$++]<<Y,Y+=8}if(ie-=se,_.total_out+=ie,x.total+=ie,ie&&(_.adler=x.check=x.flags?r(x.check,O,ie,T-ie):a(x.check,O,ie,T-ie)),ie=se,(x.flags?V:y(V))!==x.check){_.msg="incorrect data check",x.mode=30;break}Y=V=0}x.mode=28;case 28:if(x.wrap&&x.flags){for(;Y<32;){if(P===0)break e;P--,V+=q[$++]<<Y,Y+=8}if(V!==(4294967295&x.total)){_.msg="incorrect length check",x.mode=30;break}Y=V=0}x.mode=29;case 29:W=1;break e;case 30:W=-3;break e;case 31:return-4;case 32:default:return p}return _.next_out=T,_.avail_out=se,_.next_in=$,_.avail_in=P,x.hold=V,x.bits=Y,(x.wsize||ie!==_.avail_out&&x.mode<30&&(x.mode<27||U!==4))&&K(_,_.output,_.next_out,ie-_.avail_out)?(x.mode=31,-4):(ce-=_.avail_in,ie-=_.avail_out,_.total_in+=ce,_.total_out+=ie,x.total+=ie,x.wrap&&ie&&(_.adler=x.check=x.flags?r(x.check,O,ie,_.next_out-ie):a(x.check,O,ie,_.next_out-ie)),_.data_type=x.bits+(x.last?64:0)+(x.mode===12?128:0)+(x.mode===20||x.mode===15?256:0),(ce==0&&ie===0||U===4)&&W===d&&(W=-5),W)},s.inflateEnd=function(_){if(!_||!_.state)return p;var U=_.state;return U.window&&(U.window=null),_.state=null,d},s.inflateGetHeader=function(_,U){var x;return _&&_.state?(2&(x=_.state).wrap)==0?p:((x.head=U).done=!1,d):p},s.inflateSetDictionary=function(_,U){var x,q=U.length;return _&&_.state?(x=_.state).wrap!==0&&x.mode!==11?p:x.mode===11&&a(1,U,q,0)!==x.check?-3:K(_,U,q,q)?(x.mode=31,-4):(x.havedict=1,d):p},s.inflateInfo="pako inflate (from Nodeca project)"},{"../utils/common":41,"./adler32":43,"./crc32":45,"./inffast":48,"./inftrees":50}],50:[function(i,n,s){var o=i("../utils/common"),a=[3,4,5,6,7,8,9,10,11,13,15,17,19,23,27,31,35,43,51,59,67,83,99,115,131,163,195,227,258,0,0],r=[16,16,16,16,16,16,16,16,17,17,17,17,18,18,18,18,19,19,19,19,20,20,20,20,21,21,21,21,16,72,78],l=[1,2,3,4,5,7,9,13,17,25,33,49,65,97,129,193,257,385,513,769,1025,1537,2049,3073,4097,6145,8193,12289,16385,24577,0,0],c=[16,16,16,16,17,17,18,18,19,19,20,20,21,21,22,22,23,23,24,24,25,25,26,26,27,27,28,28,29,29,64,64];n.exports=function(u,f,d,p,w,m,b,y){var v,k,S,B,A,C,L,z,N,K=y.bits,_=0,U=0,x=0,q=0,O=0,$=0,T=0,P=0,se=0,V=0,Y=null,ce=0,ie=new o.Buf16(16),re=new o.Buf16(16),Se=null,Ie=0;for(_=0;_<=15;_++)ie[_]=0;for(U=0;U<p;U++)ie[f[d+U]]++;for(O=K,q=15;1<=q&&ie[q]===0;q--);if(q<O&&(O=q),q===0)return w[m++]=20971520,w[m++]=20971520,y.bits=1,0;for(x=1;x<q&&ie[x]===0;x++);for(O<x&&(O=x),_=P=1;_<=15;_++)if(P<<=1,(P-=ie[_])<0)return-1;if(0<P&&(u===0||q!==1))return-1;for(re[1]=0,_=1;_<15;_++)re[_+1]=re[_]+ie[_];for(U=0;U<p;U++)f[d+U]!==0&&(b[re[f[d+U]]++]=U);if(C=u===0?(Y=Se=b,19):u===1?(Y=a,ce-=257,Se=r,Ie-=257,256):(Y=l,Se=c,-1),_=x,A=m,T=U=V=0,S=-1,B=(se=1<<($=O))-1,u===1&&852<se||u===2&&592<se)return 1;for(;;){for(L=_-T,N=b[U]<C?(z=0,b[U]):b[U]>C?(z=Se[Ie+b[U]],Y[ce+b[U]]):(z=96,0),v=1<<_-T,x=k=1<<$;w[A+(V>>T)+(k-=v)]=L<<24|z<<16|N|0,k!==0;);for(v=1<<_-1;V&v;)v>>=1;if(v!==0?(V&=v-1,V+=v):V=0,U++,--ie[_]==0){if(_===q)break;_=f[d+b[U]]}if(O<_&&(V&B)!==S){for(T===0&&(T=O),A+=x,P=1<<($=_-T);$+T<q&&!((P-=ie[$+T])<=0);)$++,P<<=1;if(se+=1<<$,u===1&&852<se||u===2&&592<se)return 1;w[S=V&B]=O<<24|$<<16|A-m|0}}return V!==0&&(w[A+V]=_-T<<24|64<<16|0),y.bits=O,0}},{"../utils/common":41}],51:[function(i,n,s){n.exports={2:"need dictionary",1:"stream end",0:"","-1":"file error","-2":"stream error","-3":"data error","-4":"insufficient memory","-5":"buffer error","-6":"incompatible version"}},{}],52:[function(i,n,s){var o=i("../utils/common"),a=0,r=1;function l(I){for(var R=I.length;0<=--R;)I[R]=0}var c=0,u=29,f=256,d=f+1+u,p=30,w=19,m=2*d+1,b=15,y=16,v=7,k=256,S=16,B=17,A=18,C=[0,0,0,0,0,0,0,0,1,1,1,1,2,2,2,2,3,3,3,3,4,4,4,4,5,5,5,5,0],L=[0,0,0,0,1,1,2,2,3,3,4,4,5,5,6,6,7,7,8,8,9,9,10,10,11,11,12,12,13,13],z=[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,2,3,7],N=[16,17,18,0,8,7,9,6,10,5,11,4,12,3,13,2,14,1,15],K=new Array(2*(d+2));l(K);var _=new Array(2*p);l(_);var U=new Array(512);l(U);var x=new Array(256);l(x);var q=new Array(u);l(q);var O,$,T,P=new Array(p);function se(I,R,G,D,H){this.static_tree=I,this.extra_bits=R,this.extra_base=G,this.elems=D,this.max_length=H,this.has_stree=I&&I.length}function V(I,R){this.dyn_tree=I,this.max_code=0,this.stat_desc=R}function Y(I){return I<256?U[I]:U[256+(I>>>7)]}function ce(I,R){I.pending_buf[I.pending++]=255&R,I.pending_buf[I.pending++]=R>>>8&255}function ie(I,R,G){I.bi_valid>y-G?(I.bi_buf|=R<<I.bi_valid&65535,ce(I,I.bi_buf),I.bi_buf=R>>y-I.bi_valid,I.bi_valid+=G-y):(I.bi_buf|=R<<I.bi_valid&65535,I.bi_valid+=G)}function re(I,R,G){ie(I,G[2*R],G[2*R+1])}function Se(I,R){for(var G=0;G|=1&I,I>>>=1,G<<=1,0<--R;);return G>>>1}function Ie(I,R,G){var D,H,Z=new Array(b+1),te=0;for(D=1;D<=b;D++)Z[D]=te=te+G[D-1]<<1;for(H=0;H<=R;H++){var ne=I[2*H+1];ne!==0&&(I[2*H]=Se(Z[ne]++,ne))}}function _e(I){var R;for(R=0;R<d;R++)I.dyn_ltree[2*R]=0;for(R=0;R<p;R++)I.dyn_dtree[2*R]=0;for(R=0;R<w;R++)I.bl_tree[2*R]=0;I.dyn_ltree[2*k]=1,I.opt_len=I.static_len=0,I.last_lit=I.matches=0}function fe(I){8<I.bi_valid?ce(I,I.bi_buf):0<I.bi_valid&&(I.pending_buf[I.pending++]=I.bi_buf),I.bi_buf=0,I.bi_valid=0}function X(I,R,G,D){var H=2*R,Z=2*G;return I[H]<I[Z]||I[H]===I[Z]&&D[R]<=D[G]}function pe(I,R,G){for(var D=I.heap[G],H=G<<1;H<=I.heap_len&&(H<I.heap_len&&X(R,I.heap[H+1],I.heap[H],I.depth)&&H++,!X(R,D,I.heap[H],I.depth));)I.heap[G]=I.heap[H],G=H,H<<=1;I.heap[G]=D}function E(I,R,G){var D,H,Z,te,ne=0;if(I.last_lit!==0)for(;D=I.pending_buf[I.d_buf+2*ne]<<8|I.pending_buf[I.d_buf+2*ne+1],H=I.pending_buf[I.l_buf+ne],ne++,D===0?re(I,H,R):(re(I,(Z=x[H])+f+1,R),(te=C[Z])!==0&&ie(I,H-=q[Z],te),re(I,Z=Y(--D),G),(te=L[Z])!==0&&ie(I,D-=P[Z],te)),ne<I.last_lit;);re(I,k,R)}function F(I,R){var G,D,H,Z=R.dyn_tree,te=R.stat_desc.static_tree,ne=R.stat_desc.has_stree,me=R.stat_desc.elems,$e=-1;for(I.heap_len=0,I.heap_max=m,G=0;G<me;G++)Z[2*G]!==0?(I.heap[++I.heap_len]=$e=G,I.depth[G]=0):Z[2*G+1]=0;for(;I.heap_len<2;)Z[2*(H=I.heap[++I.heap_len]=$e<2?++$e:0)]=1,I.depth[H]=0,I.opt_len--,ne&&(I.static_len-=te[2*H+1]);for(R.max_code=$e,G=I.heap_len>>1;1<=G;G--)pe(I,Z,G);for(H=me;G=I.heap[1],I.heap[1]=I.heap[I.heap_len--],pe(I,Z,1),D=I.heap[1],I.heap[--I.heap_max]=G,I.heap[--I.heap_max]=D,Z[2*H]=Z[2*G]+Z[2*D],I.depth[H]=(I.depth[G]>=I.depth[D]?I.depth[G]:I.depth[D])+1,Z[2*G+1]=Z[2*D+1]=H,I.heap[1]=H++,pe(I,Z,1),2<=I.heap_len;);I.heap[--I.heap_max]=I.heap[1],(function(xe,De){var je,ze,le,ue,Oe,He,We=De.dyn_tree,lt=De.max_code,Et=De.stat_desc.static_tree,Zs=De.stat_desc.has_stree,Js=De.stat_desc.extra_bits,es=De.stat_desc.extra_base,Di=De.stat_desc.max_length,qi=0;for(ue=0;ue<=b;ue++)xe.bl_count[ue]=0;for(We[2*xe.heap[xe.heap_max]+1]=0,je=xe.heap_max+1;je<m;je++)Di<(ue=We[2*We[2*(ze=xe.heap[je])+1]+1]+1)&&(ue=Di,qi++),We[2*ze+1]=ue,lt<ze||(xe.bl_count[ue]++,Oe=0,es<=ze&&(Oe=Js[ze-es]),He=We[2*ze],xe.opt_len+=He*(ue+Oe),Zs&&(xe.static_len+=He*(Et[2*ze+1]+Oe)));if(qi!==0){do{for(ue=Di-1;xe.bl_count[ue]===0;)ue--;xe.bl_count[ue]--,xe.bl_count[ue+1]+=2,xe.bl_count[Di]--,qi-=2}while(0<qi);for(ue=Di;ue!==0;ue--)for(ze=xe.bl_count[ue];ze!==0;)lt<(le=xe.heap[--je])||(We[2*le+1]!==ue&&(xe.opt_len+=(ue-We[2*le+1])*We[2*le],We[2*le+1]=ue),ze--)}})(I,R),Ie(Z,$e,I.bl_count)}function g(I,R,G){var D,H,Z=-1,te=R[1],ne=0,me=7,$e=4;for(te===0&&(me=138,$e=3),R[2*(G+1)+1]=65535,D=0;D<=G;D++)H=te,te=R[2*(D+1)+1],++ne<me&&H===te||(ne<$e?I.bl_tree[2*H]+=ne:H!==0?(H!==Z&&I.bl_tree[2*H]++,I.bl_tree[2*S]++):ne<=10?I.bl_tree[2*B]++:I.bl_tree[2*A]++,Z=H,$e=(ne=0)===te?(me=138,3):H===te?(me=6,3):(me=7,4))}function W(I,R,G){var D,H,Z=-1,te=R[1],ne=0,me=7,$e=4;for(te===0&&(me=138,$e=3),D=0;D<=G;D++)if(H=te,te=R[2*(D+1)+1],!(++ne<me&&H===te)){if(ne<$e)for(;re(I,H,I.bl_tree),--ne!=0;);else H!==0?(H!==Z&&(re(I,H,I.bl_tree),ne--),re(I,S,I.bl_tree),ie(I,ne-3,2)):ne<=10?(re(I,B,I.bl_tree),ie(I,ne-3,3)):(re(I,A,I.bl_tree),ie(I,ne-11,7));Z=H,$e=(ne=0)===te?(me=138,3):H===te?(me=6,3):(me=7,4)}}l(P);var j=!1;function M(I,R,G,D){ie(I,(c<<1)+(D?1:0),3),(function(H,Z,te,ne){fe(H),ce(H,te),ce(H,~te),o.arraySet(H.pending_buf,H.window,Z,te,H.pending),H.pending+=te})(I,R,G)}s._tr_init=function(I){j||((function(){var R,G,D,H,Z,te=new Array(b+1);for(H=D=0;H<u-1;H++)for(q[H]=D,R=0;R<1<<C[H];R++)x[D++]=H;for(x[D-1]=H,H=Z=0;H<16;H++)for(P[H]=Z,R=0;R<1<<L[H];R++)U[Z++]=H;for(Z>>=7;H<p;H++)for(P[H]=Z<<7,R=0;R<1<<L[H]-7;R++)U[256+Z++]=H;for(G=0;G<=b;G++)te[G]=0;for(R=0;R<=143;)K[2*R+1]=8,R++,te[8]++;for(;R<=255;)K[2*R+1]=9,R++,te[9]++;for(;R<=279;)K[2*R+1]=7,R++,te[7]++;for(;R<=287;)K[2*R+1]=8,R++,te[8]++;for(Ie(K,d+1,te),R=0;R<p;R++)_[2*R+1]=5,_[2*R]=Se(R,5);O=new se(K,C,f+1,d,b),$=new se(_,L,0,p,b),T=new se(new Array(0),z,0,w,v)})(),j=!0),I.l_desc=new V(I.dyn_ltree,O),I.d_desc=new V(I.dyn_dtree,$),I.bl_desc=new V(I.bl_tree,T),I.bi_buf=0,I.bi_valid=0,_e(I)},s._tr_stored_block=M,s._tr_flush_block=function(I,R,G,D){var H,Z,te=0;0<I.level?(I.strm.data_type===2&&(I.strm.data_type=(function(ne){var me,$e=4093624447;for(me=0;me<=31;me++,$e>>>=1)if(1&$e&&ne.dyn_ltree[2*me]!==0)return a;if(ne.dyn_ltree[18]!==0||ne.dyn_ltree[20]!==0||ne.dyn_ltree[26]!==0)return r;for(me=32;me<f;me++)if(ne.dyn_ltree[2*me]!==0)return r;return a})(I)),F(I,I.l_desc),F(I,I.d_desc),te=(function(ne){var me;for(g(ne,ne.dyn_ltree,ne.l_desc.max_code),g(ne,ne.dyn_dtree,ne.d_desc.max_code),F(ne,ne.bl_desc),me=w-1;3<=me&&ne.bl_tree[2*N[me]+1]===0;me--);return ne.opt_len+=3*(me+1)+5+5+4,me})(I),H=I.opt_len+3+7>>>3,(Z=I.static_len+3+7>>>3)<=H&&(H=Z)):H=Z=G+5,G+4<=H&&R!==-1?M(I,R,G,D):I.strategy===4||Z===H?(ie(I,2+(D?1:0),3),E(I,K,_)):(ie(I,4+(D?1:0),3),(function(ne,me,$e,xe){var De;for(ie(ne,me-257,5),ie(ne,$e-1,5),ie(ne,xe-4,4),De=0;De<xe;De++)ie(ne,ne.bl_tree[2*N[De]+1],3);W(ne,ne.dyn_ltree,me-1),W(ne,ne.dyn_dtree,$e-1)})(I,I.l_desc.max_code+1,I.d_desc.max_code+1,te+1),E(I,I.dyn_ltree,I.dyn_dtree)),_e(I),D&&fe(I)},s._tr_tally=function(I,R,G){return I.pending_buf[I.d_buf+2*I.last_lit]=R>>>8&255,I.pending_buf[I.d_buf+2*I.last_lit+1]=255&R,I.pending_buf[I.l_buf+I.last_lit]=255&G,I.last_lit++,R===0?I.dyn_ltree[2*G]++:(I.matches++,R--,I.dyn_ltree[2*(x[G]+f+1)]++,I.dyn_dtree[2*Y(R)]++),I.last_lit===I.lit_bufsize-1},s._tr_align=function(I){ie(I,2,3),re(I,k,K),(function(R){R.bi_valid===16?(ce(R,R.bi_buf),R.bi_buf=0,R.bi_valid=0):8<=R.bi_valid&&(R.pending_buf[R.pending++]=255&R.bi_buf,R.bi_buf>>=8,R.bi_valid-=8)})(I)}},{"../utils/common":41}],53:[function(i,n,s){n.exports=function(){this.input=null,this.next_in=0,this.avail_in=0,this.total_in=0,this.output=null,this.next_out=0,this.avail_out=0,this.total_out=0,this.msg="",this.state=null,this.data_type=2,this.adler=0}},{}],54:[function(i,n,s){(function(o){(function(a,r){if(!a.setImmediate){var l,c,u,f,d=1,p={},w=!1,m=a.document,b=Object.getPrototypeOf&&Object.getPrototypeOf(a);b=b&&b.setTimeout?b:a,l={}.toString.call(a.process)==="[object process]"?function(S){process.nextTick(function(){v(S)})}:(function(){if(a.postMessage&&!a.importScripts){var S=!0,B=a.onmessage;return a.onmessage=function(){S=!1},a.postMessage("","*"),a.onmessage=B,S}})()?(f="setImmediate$"+Math.random()+"$",a.addEventListener?a.addEventListener("message",k,!1):a.attachEvent("onmessage",k),function(S){a.postMessage(f+S,"*")}):a.MessageChannel?((u=new MessageChannel).port1.onmessage=function(S){v(S.data)},function(S){u.port2.postMessage(S)}):m&&"onreadystatechange"in m.createElement("script")?(c=m.documentElement,function(S){var B=m.createElement("script");B.onreadystatechange=function(){v(S),B.onreadystatechange=null,c.removeChild(B),B=null},c.appendChild(B)}):function(S){setTimeout(v,0,S)},b.setImmediate=function(S){typeof S!="function"&&(S=new Function(""+S));for(var B=new Array(arguments.length-1),A=0;A<B.length;A++)B[A]=arguments[A+1];var C={callback:S,args:B};return p[d]=C,l(d),d++},b.clearImmediate=y}function y(S){delete p[S]}function v(S){if(w)setTimeout(v,0,S);else{var B=p[S];if(B){w=!0;try{(function(A){var C=A.callback,L=A.args;switch(L.length){case 0:C();break;case 1:C(L[0]);break;case 2:C(L[0],L[1]);break;case 3:C(L[0],L[1],L[2]);break;default:C.apply(r,L)}})(B)}finally{y(S),w=!1}}}}function k(S){S.source===a&&typeof S.data=="string"&&S.data.indexOf(f)===0&&v(+S.data.slice(f.length))}})(typeof self>"u"?o===void 0?this:o:self)}).call(this,typeof cs<"u"?cs:typeof self<"u"?self:typeof window<"u"?window:{})},{}]},{},[10])(10)})})(mo)),mo.exports}var wg=kg();const tc=yg(wg);function ic(e){const t=(e||"").trim();return t?`即现（${t}）`:"即现"}async function nc(e,t){var i,n,s;if(!t)return"";if(typeof document<"u"){const o=document.querySelector(`.protyle-title[data-node-id="${t}"] .protyle-title__input`)||document.querySelector(`.protyle[data-doc-id="${t}"] .protyle-title__input`)||(e.getActiveDocumentId()===t?document.querySelector(".layout__wnd--active .protyle-title__input"):null)||document.querySelector(".protyle-title__input"),a=((o==null?void 0:o.innerText)||(o==null?void 0:o.textContent)||"").trim();if(a)return a}if(e.latestCompiledDoc&&e.latestCompiledDoc.docId===t){const o=(i=e.latestCompiledDoc.slides)==null?void 0:i[0],a=(n=o==null?void 0:o.blocks)==null?void 0:n.find(r=>r.type==="h"||r.type==="NodeHeading");if(a!=null&&a.content)return a.content.trim()}try{const o=await un(`SELECT content FROM blocks WHERE id = '${t}' AND type = 'd' LIMIT 1`).catch(()=>[]);if(Array.isArray(o)&&o.length>0&&((s=o[0])!=null&&s.content))return String(o[0].content).trim()}catch{}return""}async function xg(e,t,i){var c,u,f;const n=Yw(),s=!!((c=n==null?void 0:n.isPinned)!=null&&c.value),o=String(((u=n==null?void 0:n.pinnedDocId)==null?void 0:u.value)||"");if(s&&o&&i&&i!==o)return;const a=i||(s&&o?o:e.currentDocId||e.getActiveDocumentId());let r=(t||"").trim();!r&&a&&(r=typeof e.fetchDocumentTitle=="function"?await e.fetchDocumentTitle(a):await nc(e,a));const l=ic(r);if(e.previewTab&&typeof e.previewTab.updateTitle=="function"){e.previewTab.updateTitle(l),e.previewTab.headElement&&e.previewTab.headElement.setAttribute("title",l);return}if(typeof document<"u"){const d=Array.from(document.querySelectorAll('.layout-tab-bar .item[data-type="tab-header"]'));for(const p of d){const w=p.querySelector(".item__text"),m=((f=w==null?void 0:w.textContent)==null?void 0:f.trim())||"";if(m.includes("Slidev 演示预览")||m.startsWith("即现")){w&&(w.textContent=l),p.setAttribute("title",l);break}}}}function Mn(e){return(e||"").replace(/[/\\?%*:|"<>]/g,"_").replace(/_+/g,"_").trim().replace(/^_+|_+$/g,"")||"presentation"}async function Ei(e,t,i){var s,o;const n=t||(e==null?void 0:e.docId)||"";if(i&&typeof i.fetchDocumentTitle=="function"&&n)try{const a=await i.fetchDocumentTitle(n);if(a&&a.trim())return Mn(a)}catch{}if(typeof document<"u")try{const a=(n?document.querySelector(`.protyle-title[data-node-id="${n}"] .protyle-title__input`):null)||(n?document.querySelector(`.protyle[data-doc-id="${n}"] .protyle-title__input`):null)||document.querySelector(".layout__wnd--active .protyle-title__input")||document.querySelector(".protyle-title__input"),r=((a==null?void 0:a.innerText)||(a==null?void 0:a.textContent)||"").trim();if(r)return Mn(r)}catch{}if((s=e==null?void 0:e.config)!=null&&s.title&&e.config.title.trim()&&e.config.title.trim().toLowerCase()!=="presentation")return Mn(e.config.title);if(e!=null&&e.slides&&e.slides.length>0){const r=(o=e.slides[0].blocks)==null?void 0:o.find(c=>c.type==="h"||c.type==="NodeHeading"),l=((r==null?void 0:r.content)||"").replace(/^#+\s*/,"").trim();if(l)return Mn(l)}return"presentation"}function Sg(e,t){if(typeof document>"u")return!1;const i=URL.createObjectURL(t),n=document.createElement("a");return n.href=i,n.download=e,document.body.appendChild(n),n.click(),document.body.removeChild(n),URL.revokeObjectURL(i),!0}function ha(e,t){if(typeof document>"u")return!1;const i=document.createElement("a");return i.href=t,i.download=e,document.body.appendChild(i),i.click(),document.body.removeChild(i),!0}async function Cg(e){if(typeof navigator>"u"||!navigator.clipboard||typeof ClipboardItem>"u")return!1;try{const i=await(await fetch(e)).blob();return await navigator.clipboard.write([new ClipboardItem({[i.type||"image/png"]:i})]),!0}catch(t){return console.warn("[image-exporter] 复制图像至剪贴板失败:",t),!1}}async function jo(e,t){return new Promise(i=>{let n=[],s=null;const o=()=>{s&&(clearTimeout(s),s=null),n.forEach(l=>l()),n=[]};s=setTimeout(()=>{o(),i({success:!1,error:"单页截图超时（沙箱无响应）"})},2e4);const a=e.onCapturePageDone(l=>{o(),i({success:!0,dataUrl:l.dataUrl})});n.push(a);const r=e.onCaptureError(l=>{o(),i({success:!1,error:l})});n.push(r),e.startImageExport({mode:"current",scale:(t==null?void 0:t.scale)||2,format:(t==null?void 0:t.format)||"png"})})}async function sc(e,t){const i=[],n=Mn((t==null?void 0:t.title)||"presentation");return new Promise(s=>{let o=[],a=null;const r=()=>{a&&(clearTimeout(a),a=null),o.forEach(p=>p()),o=[]},l=()=>{a&&clearTimeout(a),a=setTimeout(()=>{r(),s({success:!1,error:"幻灯片逐页导出超时（沙箱无响应）"})},35e3)};l();const c=e.onCaptureProgress(p=>{var w;l(),(w=t==null?void 0:t.onProgress)==null||w.call(t,p.current,p.total,p.pageIndex)});o.push(c);const u=e.onCapturePageDone(p=>{l(),(p.mode==="all"||!p.mode)&&i.push({pageIndex:p.pageIndex,dataUrl:p.dataUrl})});o.push(u);const f=async()=>{r();try{if(i.length===0){s({success:!1,error:"未采集到幻灯片图像数据"});return}const p=new tc,w=(t==null?void 0:t.format)==="jpeg"?"jpg":"png";for(const y of i){const v=String(y.pageIndex).padStart(2,"0"),k=y.dataUrl.split(",")[1];p.file(`slide-${v}.${w}`,k,{base64:!0})}const m=await p.generateAsync({type:"blob",compression:"DEFLATE"}),b=Sg(`${n}.zip`,m);s({success:b,total:i.length})}catch(p){s({success:!1,error:(p==null?void 0:p.message)||String(p)})}};o.push(e.onCaptureComplete(f));const d=e.onCaptureError(p=>{r(),s({success:!1,error:p})});o.push(d),e.startImageExport({mode:"all",scale:(t==null?void 0:t.scale)||2,format:(t==null?void 0:t.format)||"png"})})}async function oc(e,t){if(typeof document>"u")return{success:!1,error:"环境不支持 DOM 沙箱挂载"};const i=document.createElement("iframe");i.style.position="fixed",i.style.left="-9999px",i.style.top="-9999px",i.style.width="1920px",i.style.height="1080px",i.style.opacity="0",i.style.pointerEvents="none",i.src="/plugins/siyuan-live-slides/slides-client/index.html?headless=true",document.body.appendChild(i);const n=new Qn;n.attach(i);try{if(await new Promise((s,o)=>{const a=setTimeout(()=>o(new Error("静默后台沙箱加载超时")),12e3);n.onClientReady(()=>{clearTimeout(a),s()})}),n.updateSlides(e.slides,e.config,e.fullMarkdown),await new Promise(s=>setTimeout(s,250)),(t==null?void 0:t.mode)==="current"){const s=await jo(n,t);return{success:s.success,total:1,error:s.error}}else{const s=(t==null?void 0:t.title)||await Ei(e,e.docId);return await sc(n,{...t,title:s})}}catch(s){return{success:!1,error:(s==null?void 0:s.message)||String(s)}}finally{n.detach(),i.remove()}}const _g=1500,$g=500,Ig=4,Mg=new Set(["INPUT","TEXTAREA","SELECT"]);function rc(e){const t=e;return!t||!t.tagName?!1:Mg.has(t.tagName)||t.isContentEditable===!0}function Tg(e){let t="",i=!1,n=null,s=null;function o(){e.onStateChange&&e.onStateChange({display:t,invalid:i})}function a(){n&&(clearTimeout(n),n=null),s&&(clearTimeout(s),s=null)}function r(){a(),t="",i=!1,o()}function l(){n&&clearTimeout(n),n=setTimeout(r,_g)}function c(){n&&(clearTimeout(n),n=null),i=!0,o(),s&&clearTimeout(s),s=setTimeout(r,$g)}function u(f){if(e.isEnabled&&!e.isEnabled()||rc(f.target)||f.isComposing||f.ctrlKey||f.metaKey||f.altKey)return!1;if(/^[0-9]$/.test(f.key))return i||t.length>=Ig||(t+=f.key,o(),l()),!0;if(f.key==="Enter"){if(!t||i)return!1;const p=parseInt(t,10),w=e.getTotalPages();return!isNaN(p)&&p>=1&&w>0&&p<=w?(r(),e.onJump(p),!0):(c(),!0)}return f.key==="Escape"&&(t||i)?(r(),!0):!1}return{handleKeydown:u,getState:()=>({display:t,invalid:i}),clear:r}}const Eg={class:"spm-slides-tab__toolbar"},Ag={class:"spm-slides-tab__nav"},Bg=["disabled"],Dg={class:"spm-page-badge"},Lg=["disabled"],Pg=["aria-label"],Og=["aria-label"],Rg={class:"spm-slides-tab__tools"},Ng={key:3,class:"spm-export-image-dropdown",style:{position:"relative",display:"inline-flex","align-items":"center"}},zg={key:0,class:"b3-menu b3-menu--context",style:{position:"absolute",top:"calc(100% + 4px)",right:"0","z-index":"100","min-width":"190px","box-shadow":"var(--b3-point-shadow)","border-radius":"4px",background:"var(--b3-theme-surface)"}},Hg=["src"],Fg=Dt({__name:"SlidesPreviewTab",setup(e,{expose:t}){const i=zt("plugin"),n=zt("sandboxBridge",new Qn),s=new Ym(n),o=new Ap,a=ge("web-sandbox"),r=ge(3030),l=ge(null),c=ge(!1),u=ge(null),f=ge(1),d=ge(1),p=ge(!1),w=ge(!1),m=ge(!1),b=ge("siyuan"),y=ge(""),v=ge(""),k=ge(""),S=ge(!1),B=ge(!1),A=ge(""),C=ge(""),L=ge(!1),z=Tg({getTotalPages:()=>d.value,isEnabled:()=>!w.value,onJump:D=>_(D),onStateChange:D=>{C.value=D.display,L.value=D.invalid}});function N(D){if(D.key==="o"||D.key==="O"){if(w.value||D.isComposing||D.ctrlKey||D.metaKey||D.altKey||rc(D.target))return;D.preventDefault(),K();return}z.handleKeydown(D)&&D.preventDefault()}function K(){var D,H;if(a.value==="pro-cli"){(D=u.value)==null||D.focus(),ae.showMessage("Pro 模式使用官方原生总览：在画面内按 O 呼出");return}n.toggleOverview(),(H=u.value)==null||H.focus()}function _(D){var H;f.value=D,a.value==="pro-cli"?o.nativeBridge.navigateToPage(D):n.navigatePage(D),(H=u.value)==null||H.focus()}const U=ge("/plugins/siyuan-live-slides/slides-client/index.html");let x=null,q=null,O=null,$=null,T=null,P=null,se=null,V=null;bn(()=>{u.value&&(n.attach(u.value),o.nativeBridge.attach(u.value)),x=n.onSlideChanged((D,H)=>{f.value=D,d.value=H}),q=n.onBlockClicked((D,H)=>{f.value=H,s.setActiveBlockId(D),D||Nn(),i&&typeof i.handleBlockClickedFromSlide=="function"?i.handleBlockClickedFromSlide(D,H):D&&Gi(D,i==null?void 0:i.app)}),O=n.onOpenInEditor((D,H)=>{f.value=H,s.setActiveBlockId(D),Gi(D,i==null?void 0:i.app)}),$=o.nativeBridge.onPageChanged((D,H)=>{f.value=D,d.value=H}),T=n.onOpenPeekDrawer(async D=>{const H=Ys();if(D.peekType==="siyuan"&&H.enableWebServeJump){let Z=!1;if(V&&V.docId===D.target)Z=!0;else if(V&&V.slides&&V.slides.some(te=>{var ne;return(ne=te.blocks)==null?void 0:ne.some(me=>me.id===D.target)}))Z=!1;else try{const te=await un(`SELECT id, root_id, type FROM blocks WHERE id = '${D.target}' LIMIT 1`);te&&te.length>0&&(Z=te[0].type==="d"||te[0].id===te[0].root_id)}catch(te){console.warn("[SlidesPreviewTab] detect block type failed:",te)}b.value="web",S.value=!0,v.value=Rl(H.webServeUrl,D.target,{focus:!Z}),k.value=D.title||`${Z?"思源文档":"思源块"}: ${D.target.slice(0,8)}`,w.value=!0,n.freezeKeyboardNav(!0)}else{if(b.value=D.peekType,D.peekType==="siyuan")y.value=D.target,k.value=D.title||`块速览: ${D.target.slice(0,8)}`;else{const Z=Kl(D.target);if(Z.external){pe(D.target);return}S.value=!0,v.value=Z.url,k.value=D.title||Z.url}w.value=!0,n.freezeKeyboardNav(!0)}}),P=n.onRequestToggleFullscreen(()=>{F()}),se=n.onOpenPresenter(()=>{g()}),typeof document<"u"&&document.addEventListener("fullscreenchange",E)}),Vs(()=>{typeof document<"u"&&document.removeEventListener("fullscreenchange",E),T&&T(),P&&P(),se&&se(),x&&x(),q&&q(),O&&O(),$&&$(),n.detach(),z.clear(),s.destroy(),o.destroy()});async function Y(){if(a.value==="web-sandbox"){if(!V){ae.showMessage("请先在主编辑区打开演示文档");return}ae.showMessage("正在探测本地 Node 环境并编排 Slidev Pro 进程...");const D=await o.startProMode(V,So);if(!D.success){ae.showMessage(`无法启动官方 Pro 模式：${D.error}`);return}a.value="pro-cli",r.value=D.port||3030,U.value=D.url,u.value&&o.nativeBridge.attach(u.value),ae.showMessage(`🟢 已成功接入官方原生 Slidev 服务 (端口: ${r.value})`)}else o.stopProMode(),a.value="web-sandbox",U.value="/plugins/siyuan-live-slides/slides-client/index.html",u.value&&n.attach(u.value),ae.showMessage("已切回内置高保真沙箱")}function ce(){B.value=!B.value,B.value?(A.value=(V==null?void 0:V.docId)||"",i&&typeof i.updatePreviewTabHeader=="function"&&i.updatePreviewTabHeader("",A.value)):(A.value="",_e(),i&&typeof i.updatePreviewTabHeader=="function"&&i.updatePreviewTabHeader())}let ie=0;function re(D){if(w.value||Math.abs(D.deltaY)<Math.abs(D.deltaX)||Math.abs(D.deltaY)<15)return;const H=Date.now();H-ie<280||(ie=H,D.deltaY>0?Ie():Se())}function Se(){if(f.value>1){const D=f.value-1;f.value=D,a.value==="pro-cli"?o.nativeBridge.navigateToPage(D):n.navigatePage(D)}}function Ie(){if(f.value<d.value){const D=f.value+1;f.value=D,a.value==="pro-cli"?o.nativeBridge.navigateToPage(D):n.navigatePage(D)}}function _e(){i&&typeof i.compileCurrentDocument=="function"?i.compileCurrentDocument():i!=null&&i.eventBus&&typeof i.eventBus.emit=="function"&&i.eventBus.emit("slides:request-compile")}function fe(){w.value=!1,n.freezeKeyboardNav(!1)}function X(){fe()}function pe(D){var ne,me;const H=/^file:/i.test(D),Z=H||/^[a-zA-Z]:[\\/]/.test(D),te=Tt("electron");if(Z&&typeof((ne=te==null?void 0:te.shell)==null?void 0:ne.openPath)=="function"){te.shell.openPath(H?Gl(D):D),ae.showMessage("本地文件不在思源工作区内，已交由系统默认浏览器打开");return}typeof((me=te==null?void 0:te.shell)==null?void 0:me.openExternal)=="function"?te.shell.openExternal(D).catch(()=>{typeof window<"u"&&window.open(D,"_blank")}):typeof window<"u"&&window.open(D,"_blank"),ae.showMessage("该地址无法在速览抽屉内加载，已交由系统默认浏览器打开")}function E(){typeof document<"u"&&(c.value=!!document.fullscreenElement,n.postMessage("FULLSCREEN_CHANGED",{isFullscreen:c.value}))}function F(){const D=l.value||u.value;D&&(document.fullscreenElement?document.exitFullscreen().then(()=>{n.postMessage("FULLSCREEN_CHANGED",{isFullscreen:!1})}).catch(()=>{}):D.requestFullscreen().then(()=>{n.postMessage("FULLSCREEN_CHANGED",{isFullscreen:!0})}).catch(()=>{}))}function g(){i&&typeof i.openPresenterTab=="function"&&i.openPresenterTab()}async function W(){if(!V){ae.showMessage("请先在主编辑区打开幻灯片文档");return}const D=await Ei(V,i==null?void 0:i.currentDocId,i),H=Xl(V,{title:D});Ql(`${D}.html`,H)&&ae.showMessage(`已开始下载单文件离线 HTML 演示包 (${D}.html)`)}function j(){if(!V){ae.showMessage("请先在主编辑区打开幻灯片文档");return}ec(V)&&ae.showMessage("已唤起打印视窗，请在打印选项中选择「另存为 PDF」")}const M=ge(!1);async function I(){if(M.value){ae.showMessage("正在逐页导出幻灯片图片中，请稍候...",2e3);return}if(!V){ae.showMessage("请先在主编辑区打开幻灯片文档");return}M.value=!0;try{ae.showMessage("正在逐页导出幻灯片图片...",2e3);const D=await Ei(V,i==null?void 0:i.currentDocId,i),H=await sc(n,{title:D,onProgress:(Z,te)=>{ae.showMessage(`正在导出幻灯片图片 (${Z} / ${te})...`,1500)}});H.success?ae.showMessage(`🎉 成功导出 ${H.total||0} 张高清图片并保存为 ${D}.zip！`,4e3):ae.showMessage(`导出图片失败：${H.error||"未知异常"}`)}finally{M.value=!1}}async function R(){if(!V){ae.showMessage("请先在主编辑区打开幻灯片文档");return}ae.showMessage("正在导出当前幻灯片图片...",1500);const D=await jo(n);if(D.success&&D.dataUrl){const H=await Ei(V,i==null?void 0:i.currentDocId,i),Z=f.value||1,ne=(d.value||1)>1?`${H}-${Z}.png`:`${H}.png`;ha(ne,D.dataUrl),ae.showMessage(`已下载当前页高清图片 (${ne})`)}else ae.showMessage(`导出当前页图片失败：${D.error||"未知异常"}`)}async function G(){if(!V){ae.showMessage("请先在主编辑区打开幻灯片文档");return}ae.showMessage("正在复制当前幻灯片截图到剪贴板...",1500);const D=await jo(n);if(D.success&&D.dataUrl)if(await Cg(D.dataUrl))ae.showMessage(`已成功将第 ${f.value||1} 页幻灯片复制到剪贴板！`);else{const Z=await Ei(V,i==null?void 0:i.currentDocId,i),te=f.value||1,me=(d.value||1)>1?`${Z}-${te}.png`:`${Z}.png`;ha(me,D.dataUrl),ae.showMessage(`剪贴板权限不可用，已自动下载为 ${me}`)}else ae.showMessage(`复制失败：${D.error||"未知异常"}`)}return t({updateDocument(D,H){B.value&&A.value&&H&&H!==A.value||(V=D,B.value&&!A.value&&(A.value=D.docId),d.value=D.slides.length,s.setDocId(D.docId),s.updateSlidesIndex(D.slides),a.value==="pro-cli"?o.scaffolder.scaffold(D,So).catch(()=>{}):n.updateSlides(D.slides,D.config,D.fullMarkdown,D.customThemeCss),i&&typeof i.updatePreviewTabHeader=="function"&&i.updatePreviewTabHeader("",D.docId))},navigateToBlock(D){s.onCursorFocusBlock(D)},isPinned:B,pinnedDocId:A,engineMode:a,toggleEngineMode:Y}),(D,H)=>(J(),ee("div",{class:"spm-slides-preview-tab",onKeydown:N},[h("div",Eg,[h("div",Ag,[h("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s",disabled:f.value<=1,"aria-label":"上一页",onClick:Se},[oe(de,{name:"chevron-left"})],8,Bg),h("span",Dg,we(f.value)+" / "+we(d.value||1),1),h("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s",disabled:f.value>=d.value,"aria-label":"下一页",onClick:Ie},[oe(de,{name:"chevron-right"})],8,Lg),h("button",{class:Ce(["spm-icon-btn b3-tooltips b3-tooltips__s",{"is-primary":B.value}]),"aria-label":B.value?"已锁定当前文档（点击解除）："+A.value:"点击锁定当前文档（不随主编辑区切换）",onClick:ce},[oe(de,{name:"pin"}),h("span",null,we(B.value?"已锁定":"跟随"),1)],10,Pg),he(gt)("proMode")?(J(),ee("button",{key:0,class:Ce(["spm-icon-btn b3-tooltips b3-tooltips__s",{"is-primary":a.value==="pro-cli"}]),"aria-label":a.value==="pro-cli"?"当前：官方原生 Pro 模式 (localhost:"+r.value+")，点击切回沙箱":"当前：内置高保真沙箱，点击切换官方原生 Pro 模式",onClick:Y},[oe(de,{name:"rocket"}),h("span",null,we(a.value==="pro-cli"?"Pro ("+r.value+")":"沙箱"),1)],10,Og)):Te("",!0)]),h("div",Rg,[h("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"缩略图总览 (O)",onClick:K},[oe(de,{name:"columns"})]),he(gt)("presenterMode")?(J(),ee("button",{key:0,class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"双屏演讲者视图 (Presenter Mode ⌥M)",onClick:g},[oe(de,{name:"presenter"})])):Te("",!0),he(gt)("exportHtml")?(J(),ee("button",{key:1,class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"导出单文件 HTML 演示包",onClick:W},[oe(de,{name:"export-html"})])):Te("",!0),he(gt)("exportPdf")?(J(),ee("button",{key:2,class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"导出 16:9 PDF 演示讲义",onClick:j},[oe(de,{name:"export-pdf"})])):Te("",!0),he(gt)("exportImage")?(J(),ee("div",Ng,[h("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"导出幻灯片为图片包 (ZIP)",onClick:I},[oe(de,{name:"export-image"})]),h("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s",style:{padding:"2px 2px","margin-left":"-4px"},"aria-label":"更多图片导出选项",onClick:H[0]||(H[0]=Zt(Z=>p.value=!p.value,["stop"]))},[oe(de,{name:"chevron-down"})]),p.value?(J(),ee("div",zg,[h("button",{class:"b3-menu__item",onClick:H[1]||(H[1]=Z=>{I(),p.value=!1})},[...H[6]||(H[6]=[h("span",{class:"b3-menu__label"},"📦 导出全篇为图片包 (ZIP)",-1)])]),h("button",{class:"b3-menu__item",onClick:H[2]||(H[2]=Z=>{R(),p.value=!1})},[...H[7]||(H[7]=[h("span",{class:"b3-menu__label"},"🖼️ 导出当前页为图片 (PNG)",-1)])]),h("button",{class:"b3-menu__item",onClick:H[3]||(H[3]=Z=>{G(),p.value=!1})},[...H[8]||(H[8]=[h("span",{class:"b3-menu__label"},"📋 复制当前页至剪贴板",-1)])])])):Te("",!0)])):Te("",!0),h("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"重新编译并刷新",onClick:_e},[oe(de,{name:"refresh"})]),h("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"全屏放映",onClick:F},[oe(de,{name:"fullscreen"})])])]),h("div",{ref_key:"fullscreenContainerRef",ref:l,class:"spm-slides-tab__viewport spm-slides-fullscreen-container",onWheel:re},[h("iframe",{ref_key:"sandboxIframeRef",ref:u,class:"spm-slides-tab__iframe",src:U.value,frameborder:"0",allow:"fullscreen; autoplay"},null,8,Hg),oe(am,{visible:w.value,"onUpdate:visible":H[4]||(H[4]=Z=>w.value=Z),"is-maximized":m.value,"onUpdate:isMaximized":H[5]||(H[5]=Z=>m.value=Z),title:k.value,onClose:fe},{default:rl(()=>[b.value==="siyuan"&&y.value?(J(),Jt(gm,{key:0,"block-id":y.value,title:k.value,plugin:he(i),onExternalJump:X},null,8,["block-id","title","plugin"])):Te("",!0),S.value?Ot((J(),Jt(Km,{key:1,visible:w.value&&b.value==="web",url:v.value,title:k.value,onExternalJump:X},null,8,["visible","url","title"])),[[Oo,b.value==="web"]]):Te("",!0)]),_:1},8,["visible","is-maximized","title"]),Ot(h("div",{class:Ce(["spm-jump-badge",{"is-invalid":L.value}])},we(C.value),3),[[Oo,C.value]])],544)],32))}}),jg=ii(Fg,[["__scopeId","data-v-2bf44815"]]);function ac(e){if(!e||e.length===0)return{maxStep:0,blockMap:new Map,idMap:new Map};const t=new Map,i=new Map,n=new Map;let s=0;const o=(r,l)=>{t.set(r,l);const c=r.id||r.blockId;c&&i.set(c,l)},a=e.filter(r=>r.slot!=="slot-divider-right");for(const r of a){if(r.parentContainerId&&r.parentClicks&&r.parentClicks.trim()!==""&&!n.has(r.parentContainerId)){const f=String(r.parentClicks).trim();if(/^\d+$/.test(f)){const d=parseInt(f,10);s=Math.max(s,d),n.set(r.parentContainerId,d)}else s+=1,n.set(r.parentContainerId,s)}if(!!!(r.clicks&&String(r.clicks).trim()!=="")){if(r.parentContainerId&&n.has(r.parentContainerId)){const f=n.get(r.parentContainerId);o(r,{type:"step",step:f})}else o(r,{type:"always"});continue}const c=String(r.clicks).trim();if(!c){s+=1,o(r,{type:"step",step:s});continue}if(c.startsWith("[")&&c.endsWith("]"))try{const f=JSON.parse(c);if(Array.isArray(f)&&f.length>=2){const d=Math.min(Number(f[0]),Number(f[1])),p=Math.max(Number(f[0]),Number(f[1]));if(!isNaN(d)&&!isNaN(p)){s=Math.max(s,p),o(r,{type:"range",min:d,max:p});continue}}}catch{}if(c.toLowerCase()==="hide"){s+=1,o(r,{type:"hide",step:s});continue}if(/^\+\d+$/.test(c)||c==="true"){const f=c==="true"?1:parseInt(c.slice(1),10)||1;s+=f,o(r,{type:"step",step:s});continue}if(/^-\d+$/.test(c)){const f=parseInt(c.slice(1),10)||1;s=Math.max(1,s-f),o(r,{type:"step",step:s});continue}if(/^\d+$/.test(c)){const f=parseInt(c,10);if(!isNaN(f)){s=Math.max(s,f),o(r,{type:"step",step:f});continue}}const u=parseInt(c,10);!isNaN(u)&&u>0?(s=Math.max(s,u),o(r,{type:"step",step:u})):(s+=1,o(r,{type:"step",step:s}))}return{maxStep:s,blockMap:t,idMap:i}}function Wg(e,t,i){if(!e)return"v-click-visible";const n=e.id||e.blockId,s=i.blockMap.get(e)||(n?i.idMap.get(n):null);return!s||s.type==="always"?"v-click-visible":s.type==="range"?t>=s.min&&t<=s.max?"v-click-visible":"v-click-hidden":s.type==="hide"?t<s.step?"v-click-visible":"v-click-hidden":s.type==="step"?t>=s.step?"v-click-visible":"v-click-hidden":"v-click-visible"}const Wo=980;function Ug(e){if(!e)return 0;const i=ac(e.blocks||[]).maxStep||0,n=e.frontmatter||{},s=n.mask;if(s!=="down"&&s!=="right")return i;const o=xd(n.maskRatio),r=n.maskInitial==="revealed"?Math.max(0,o.steps-1):o.steps;return Math.max(i,r)}function Vg(e,t=Wo){const i=(e||"16/9").trim();let n=16/9;if(i==="4/3"||i==="4:3")n=4/3;else if(i==="16/10"||i==="16:10")n=16/10;else if(i.includes("/")||i.includes(":")){const o=i.includes("/")?"/":":",a=i.split(o).map(r=>parseFloat(r.trim()));a.length===2&&a[0]>0&&a[1]>0&&!isNaN(a[0])&&!isNaN(a[1])&&(n=a[0]/a[1])}else{const o=parseFloat(i);!isNaN(o)&&o>.2&&o<5&&(n=o)}const s=Math.ceil(t/n);return{baseWidth:t,baseHeight:s,ratio:n}}function ma(e,t,i=Wo,n=552,s=16){const o=i>0?i:Wo,a=n>0?n:552,r=Math.max(0,e-s),l=Math.max(0,t-s);if(r<=0||l<=0)return{scale:.36,boxWidth:Math.round(o*.36),boxHeight:Math.round(a*.36)};const c=Math.min(r/o,l/a),u=Math.max(.08,Math.min(1.5,Number(c.toFixed(4))));return{scale:u,boxWidth:Math.max(1,Math.round(o*u)),boxHeight:Math.max(1,Math.round(a*u))}}function Gg(e){return{...e,frontmatter:{...e.frontmatter||{}},blocks:Array.isArray(e.blocks)?e.blocks.map(t=>({...t,attrs:t.attrs?{...t.attrs}:void 0,attributes:t.attributes?{...t.attributes}:void 0,motion:t.motion?{...t.motion}:void 0,children:Array.isArray(t.children)?t.children.map(i=>({...i,attrs:i.attrs?{...i.attrs}:void 0,attributes:i.attributes?{...i.attributes}:void 0})):void 0})):[]}}function ga(e,t){if(!e)return"";const i=Gg(e),n=i.frontmatter||{},s=n.layout||"default",o=(t==null?void 0:t.config)||{};(s==="image-right"||s==="image-left")&&!n.image&&!n.background&&o.image&&(n.image=o.image);const a=typeof(t==null?void 0:t.currentStep)=="number",r=a?Math.max(0,t.currentStep):0,l=a?ac(i.blocks||[]):null,u=Jl(i,{containerClassName:"slide-block",leftColClass:"pdf-col pdf-col--left two-cols-left",rightColClass:"pdf-col pdf-col--right two-cols-right",allSlides:(t==null?void 0:t.allSlides)||[],currentPageIndex:(t==null?void 0:t.pageIndex)||i.pageIndex||1,highlight:!0,blockClassResolver:l?k=>{if(Wg(k,r,l)==="v-click-hidden")return"presenter-v-click-pending";if(r>0){const B=k.id||k.blockId,A=l.blockMap.get(k)||(B?l.idMap.get(B):void 0);if((A==null?void 0:A.type)==="step"&&A.step===r||(A==null?void 0:A.type)==="range"&&A.min===r)return"presenter-v-click-active"}return""}:void 0}).replace(/<video\b([^>]*)>/gi,(k,S)=>{let B=S.replace(/\bcontrols\b/gi,"").trim();return/\bmuted\b/i.test(B)||(B+=" muted"),`<video ${B.trim()}>`}),f=n.spacing,d=f&&f!=="inherit"?f:o.spacing||"normal",p=["slide-content",`layout-${s}`,`spacing-${d}`,n.class||"",n.layoutClass||""].filter(Boolean).join(" "),w=[],m=(n.background||"").trim();if(m)if(/^(?:https?:\/\/|\/|data:|assets\/|\.\/assets\/)/i.test(m)){const k=m.startsWith("assets/")?`/${m}`:m.startsWith("./assets/")?m.slice(1):m;w.push(`background-image:url('${ot(k)}');background-size:cover;background-position:center;background-repeat:no-repeat;`)}else w.push(`background:${ot(m)};`);const b=typeof n.zoom=="number"?n.zoom:typeof n.zoom=="string"?parseFloat(n.zoom):1,y=!isNaN(b)&&b>0?b:1;y!==1&&w.push(`width:${(100/y).toFixed(2)}%;height:${(100/y).toFixed(2)}%;transform-origin:top left;transform:scale(${y});`);const v=w.length>0?` style="${w.join("")}"`:"";return`<div class="${ot(p)}"${v}>${u}</div>`}const Kg={class:"presenter-header"},qg={class:"presenter-title-area"},Yg={class:"presenter-brand"},Zg={class:"header-pills"},Jg={class:"pill pill-page"},Xg={key:0,class:"pill pill-step"},Qg={class:"header-toolbar"},ev={class:"timer-capsule"},tv={class:"timer-digits"},iv={class:"timer-actions"},nv=["aria-label"],sv={class:"wall-clock b3-tooltips b3-tooltips__sw","aria-label":"系统当前时间"},ov={key:0,class:"presenter-grid"},rv={class:"slide-panels"},av={class:"panel-box current-slide-panel"},lv={class:"panel-header"},cv={class:"panel-header-left"},dv={class:"panel-page-num"},uv={class:"panel-header-meta"},fv={key:0,class:"panel-step-pill"},pv={class:"panel-layout-pill"},hv=["aria-label"],mv=["data-theme","data-slides-theme","data-normalize-headings","data-hide-unordered-markers","data-hide-ordered-markers","innerHTML"],gv={key:1,class:"panel-fallback"},vv=["aria-label"],bv={class:"panel-header"},yv={class:"panel-header-left"},kv={key:0,class:"panel-page-num"},wv={class:"panel-header-meta"},xv={key:0,class:"panel-end-pill"},Sv={key:1,class:"panel-layout-pill"},Cv=["aria-label"],_v=["data-theme","data-slides-theme","data-normalize-headings","data-hide-unordered-markers","data-hide-ordered-markers","innerHTML"],$v={key:1,class:"panel-fallback"},Iv={class:"notes-panel"},Mv={class:"panel-header"},Tv={class:"panel-header-left"},Ev={class:"notes-size-controls"},Av=["disabled"],Bv={class:"notes-size-value"},Dv=["disabled"],Lv={key:1,class:"presenter-empty"},Pv={class:"empty-icon-wrap"},Ov={class:"empty-actions"},Rv={class:"presenter-actions"},Nv={class:"nav-btn-group"},zv=["disabled"],Hv=["disabled"],Fv={class:"actions-center"},jv={class:"center-meta"},Wv={class:"progress-pill"},Uv={class:"nav-btn-group"},Vv=["aria-label"],Gv={class:"step-dots-text"},Kv=["disabled"],qv=["disabled"],Yv=280,Zv=15,Jv=Dt({__name:"SlidesPresenterTab",setup(e,{expose:t}){const i=zt("plugin"),n=zt("sandboxBridge",new Qn),s=ge([]),o=ge({}),a=ge(1),r=ge(0),l=ge(0),c=ge(0),u=ye(()=>s.value.length||l.value),f=ge(null),d=ge(null),p=ge({width:0,height:0}),w=ge({width:0,height:0}),m=ye(()=>{var le;return Vg((le=o.value)==null?void 0:le.aspectRatio)}),b=ye(()=>{var le;return((le=o.value)==null?void 0:le.theme)||"default"}),y=ye(()=>{var le;return((le=o.value)==null?void 0:le.colorSchema)==="light"?"light":"dark"}),v=ye(()=>{var le;return!!((le=o.value)!=null&&le.normalizeHeadingSizes)}),k=ye(()=>{var le;return((le=o.value)==null?void 0:le.showUnorderedListMarkers)===!1}),S=ye(()=>{var le;return((le=o.value)==null?void 0:le.showOrderedListMarkers)===!1}),B=ye(()=>ma(p.value.width,p.value.height,m.value.baseWidth,m.value.baseHeight,14)),A=ye(()=>ma(w.value.width,w.value.height,m.value.baseWidth,m.value.baseHeight,14));function C(){f.value&&(p.value={width:f.value.clientWidth,height:f.value.clientHeight}),d.value&&(w.value={width:d.value.clientWidth,height:d.value.clientHeight})}let L=null;function z(){typeof window>"u"||typeof window.ResizeObserver!="function"||(L||(L=new window.ResizeObserver(()=>{C()})),L.disconnect(),f.value&&L.observe(f.value),d.value&&L.observe(d.value))}Vi([f,d,u],()=>{Ms(()=>{z(),C()})},{flush:"post"});const N=ge(0),K=ge(!0);let _=null,U=Date.now(),x=0;const q=ye(()=>{const le=String(Math.floor(N.value/60)).padStart(2,"0"),ue=String(N.value%60).padStart(2,"0");return`${le}:${ue}`});function O(){if(K.value){const le=x+(Date.now()-U);N.value=Math.floor(le/1e3)}}function $(){K.value?(x+=Date.now()-U,K.value=!1):(U=Date.now(),K.value=!0,O())}function T(){U=Date.now(),x=0,N.value=0}const P=ge("");let se=null;function V(){const le=new Date,ue=String(le.getHours()).padStart(2,"0"),Oe=String(le.getMinutes()).padStart(2,"0");P.value=`${ue}:${Oe}`}const Y=ye(()=>s.value.length===0?null:s.value[a.value-1]||null),ce=ye(()=>a.value>=s.value.length?null:s.value[a.value]||null),ie=ye(()=>Y.value?Ug(Y.value):c.value),re=ye(()=>a.value>1||r.value>0),Se=ye(()=>a.value<u.value||r.value<ie.value),Ie=ye(()=>ga(Y.value,{config:o.value,allSlides:s.value,pageIndex:a.value,currentStep:r.value})),_e=ye(()=>ga(ce.value,{config:o.value,allSlides:s.value,pageIndex:a.value+1})),fe=ye(()=>{var ue;if(!Y.value)return"无内容";const le=(ue=Y.value.blocks)==null?void 0:ue[0];return(le==null?void 0:le.content)||(le==null?void 0:le.rawMarkdown)||`第 ${a.value} 页`});function X(le){return(le||[]).slice(1).map(ue=>(ue.content||ue.rawMarkdown||"").trim()).filter(ue=>ue&&!/^(image\s+)?assets\/\S*$/i.test(ue)&&!/^!\[[^\]]*\]\(assets\/[^)]*\)$/.test(ue)).join(" | ").slice(0,120)}const pe=ye(()=>{var le;return X((le=Y.value)==null?void 0:le.blocks)}),E=ye(()=>{var ue;if(!ce.value)return"演示结束";const le=(ue=ce.value.blocks)==null?void 0:ue[0];return(le==null?void 0:le.content)||(le==null?void 0:le.rawMarkdown)||`第 ${a.value+1} 页`}),F=ye(()=>ce.value?X(ce.value.blocks):"这是最后一页"),g=ye(()=>{var le;return((le=Y.value)==null?void 0:le.notes)||""}),W=ge(20);function j(){W.value<36&&(W.value+=2)}function M(){W.value>14&&(W.value-=2)}const I=ye(()=>u.value<=1?100:Math.round(a.value/u.value*100));let R=null;try{R=new BroadcastChannel("siyuan-slides-sync"),R.onmessage=le=>{const ue=le.data;if(ue&&(ue.type==="SYNC_PAGE"&&typeof ue.page=="number"&&(a.value=ue.page,r.value=typeof ue.step=="number"?Math.max(0,ue.step):0,typeof ue.maxStep=="number"&&(c.value=Math.max(0,ue.maxStep))),ue.type==="SYNC_SLIDES"&&Array.isArray(ue.slides)&&(s.value=ue.slides,ue.config&&typeof ue.config=="object"&&(o.value=ue.config)),ue.type==="REQUEST_SYNC"&&s.value.length>0))try{R==null||R.postMessage({type:"SYNC_SLIDES",slides:JSON.parse(JSON.stringify(s.value)),config:JSON.parse(JSON.stringify(o.value||{}))}),R==null||R.postMessage({type:"SYNC_PAGE",page:a.value,step:r.value,maxStep:ie.value})}catch{}}}catch{R=null}function G(le,ue=0){const Oe=Number(le)||1,He=Math.max(0,Number(ue)||0);n.navigatePage(Oe,He);try{R==null||R.postMessage({type:"SYNC_PAGE",page:Oe,step:He,maxStep:ie.value})}catch{}}function D(){if(r.value<ie.value){r.value++,G(a.value,r.value);return}a.value<u.value&&(a.value++,r.value=0,G(a.value,0))}function H(){if(r.value>0){r.value--,G(a.value,r.value);return}a.value>1&&(a.value--,r.value=0,G(a.value,0))}function Z(){a.value<u.value&&(a.value++,r.value=0,G(a.value,0))}function te(){a.value>1&&(a.value--,r.value=0,G(a.value,0))}function ne(){a.value=1,r.value=0,T(),G(1,0)}function me(){const le=i;typeof(le==null?void 0:le.openBottomPreviewTab)=="function"&&le.openBottomPreviewTab()}function $e(){const le=i;typeof(le==null?void 0:le.openStandalonePreviewWindow)=="function"&&le.openStandalonePreviewWindow()}function xe(le){var ue,Oe;if(!(le.key===" "&&((Oe=(ue=le.target)==null?void 0:ue.closest)!=null&&Oe.call(ue,"button")))){if(le.shiftKey&&le.key==="ArrowRight"||le.key==="ArrowDown"){le.preventDefault(),Z();return}if(le.shiftKey&&le.key==="ArrowLeft"||le.key==="ArrowUp"){le.preventDefault(),te();return}le.key==="ArrowRight"||le.key===" "||le.key==="PageDown"?(le.preventDefault(),D()):(le.key==="ArrowLeft"||le.key==="PageUp")&&(le.preventDefault(),H())}}let De=0;function je(le){var He,We;if(Math.abs(le.deltaY)<Zv)return;const ue=(We=(He=le.target)==null?void 0:He.closest)==null?void 0:We.call(He,".notes-content");if(ue){const lt=ue.scrollHeight-ue.clientHeight;if(lt>2&&(le.deltaY>0&&ue.scrollTop<lt-1||le.deltaY<0&&ue.scrollTop>1))return}const Oe=Date.now();Oe-De<Yv||(De=Oe,le.deltaY>0?D():H())}let ze=null;return bn(()=>{var ue;U=Date.now(),x=0,_=window.setInterval(O,500),typeof document<"u"&&document.addEventListener("visibilitychange",O),V(),se=window.setInterval(V,1e3),ze=n.onSlideChanged((Oe,He,We,lt,Et)=>{a.value=Oe,He>0&&(l.value=He),typeof lt=="number"&&(r.value=Math.max(0,lt)),typeof Et=="number"&&(c.value=Math.max(0,Et))});try{R==null||R.postMessage({type:"REQUEST_SYNC"})}catch{}const le=i==null?void 0:i.latestCompiledDoc;(ue=le==null?void 0:le.slides)!=null&&ue.length&&(s.value=le.slides,le.config&&(o.value=le.config)),typeof window<"u"&&window.addEventListener("resize",C),Ms(()=>{z(),C()})}),Vs(()=>{_&&(window.clearInterval(_),_=null),typeof document<"u"&&document.removeEventListener("visibilitychange",O),se&&(window.clearInterval(se),se=null),ze&&ze(),typeof window<"u"&&window.removeEventListener("resize",C),L&&(L.disconnect(),L=null);try{R==null||R.close()}catch{}R=null}),t({updateDocument(le){var ue;(ue=le==null?void 0:le.slides)!=null&&ue.length&&(s.value=le.slides),le!=null&&le.config&&(o.value=le.config)}}),(le,ue)=>{var Oe,He,We;return J(),ee("div",{class:"spm-presenter-tab",tabindex:"0",onKeydown:xe,onWheel:je},[h("header",Kg,[h("div",qg,[h("div",Yg,[oe(de,{name:"presenter",class:"brand-icon"}),ue[1]||(ue[1]=h("span",{class:"title-name"},"演讲者控制台",-1))]),h("div",Zg,[h("span",Jg,"P."+we(a.value)+" / "+we(u.value||1),1),ie.value>0?(J(),ee("span",Xg,[oe(de,{name:"step",class:"pill-icon"}),It(" 步进 "+we(r.value)+" / "+we(ie.value),1)])):Te("",!0)])]),h("div",Qg,[h("button",{class:"btn-tool b3-tooltips b3-tooltips__s","aria-label":"弹出大屏放映独立窗口 (16:9)",onClick:$e},[oe(de,{name:"window"}),ue[2]||(ue[2]=h("span",{class:"btn-tool-label"},"独立放映",-1))]),h("div",ev,[oe(de,{name:"clock",class:"timer-icon"}),h("span",tv,we(q.value),1),h("div",iv,[h("button",{class:"timer-btn b3-tooltips b3-tooltips__s","aria-label":K.value?"暂停计时":"继续计时",onClick:$},[oe(de,{name:K.value?"pause":"play"},null,8,["name"])],8,nv),h("button",{class:"timer-btn b3-tooltips b3-tooltips__s","aria-label":"重置计时",onClick:T},[oe(de,{name:"reset"})])])]),h("div",sv,[h("span",null,we(P.value),1)])])]),u.value>0?(J(),ee("main",ov,[h("section",rv,[h("div",av,[h("div",lv,[h("div",cv,[ue[3]||(ue[3]=h("span",{class:"panel-tag is-current"},"当前放映",-1)),h("span",dv,"P."+we(a.value),1)]),h("div",uv,[ie.value>0?(J(),ee("span",fv," 步进 "+we(r.value)+" / "+we(ie.value),1)):Te("",!0),h("span",pv,we(((He=(Oe=Y.value)==null?void 0:Oe.frontmatter)==null?void 0:He.layout)||"default"),1)])]),h("div",{ref_key:"currentPreviewRef",ref:f,class:"panel-preview","aria-label":fe.value},[Y.value?(J(),ee("div",{key:0,class:"presenter-thumb-box",style:Yt({width:B.value.boxWidth+"px",height:B.value.boxHeight+"px"})},[h("div",{class:Ce(["presenter-thumb-viewport slide-viewport","slides-theme-"+b.value]),"data-theme":y.value,"data-slides-theme":b.value,"data-normalize-headings":v.value?"true":"false","data-hide-unordered-markers":k.value?"true":"false","data-hide-ordered-markers":S.value?"true":"false",style:Yt({width:m.value.baseWidth+"px",height:m.value.baseHeight+"px",transform:"scale("+B.value.scale+")"}),innerHTML:Ie.value},null,14,mv)],4)):(J(),ee("div",gv,[h("h2",null,we(fe.value),1),h("p",null,we(pe.value),1)]))],8,hv)]),h("div",{class:Ce(["panel-box next-slide-panel",{"is-clickable":!!ce.value,"b3-tooltips b3-tooltips__n":!!ce.value}]),"aria-label":ce.value?"点击直接跳至下一页":"",onClick:ue[0]||(ue[0]=lt=>ce.value&&Z())},[h("div",bv,[h("div",yv,[ue[4]||(ue[4]=h("span",{class:"panel-tag"},"下一页预告",-1)),a.value<u.value?(J(),ee("span",kv,"P."+we(a.value+1),1)):Te("",!0)]),h("div",wv,[a.value>=u.value?(J(),ee("span",xv,"已到尾页")):ce.value?(J(),ee("span",Sv,we(((We=ce.value.frontmatter)==null?void 0:We.layout)||"default"),1)):Te("",!0)])]),h("div",{ref_key:"nextPreviewRef",ref:d,class:"panel-preview panel-preview--dim","aria-label":E.value},[ce.value?(J(),ee("div",{key:0,class:"presenter-thumb-box",style:Yt({width:A.value.boxWidth+"px",height:A.value.boxHeight+"px"})},[h("div",{class:Ce(["presenter-thumb-viewport slide-viewport","slides-theme-"+b.value]),"data-theme":y.value,"data-slides-theme":b.value,"data-normalize-headings":v.value?"true":"false","data-hide-unordered-markers":k.value?"true":"false","data-hide-ordered-markers":S.value?"true":"false",style:Yt({width:m.value.baseWidth+"px",height:m.value.baseHeight+"px",transform:"scale("+A.value.scale+")"}),innerHTML:_e.value},null,14,_v)],4)):(J(),ee("div",$v,[h("h2",null,we(E.value),1),h("p",null,we(F.value),1)]))],8,Cv)],10,vv)]),h("section",Iv,[h("div",Mv,[h("div",Tv,[oe(de,{name:"notes",class:"panel-title-icon"}),ue[5]||(ue[5]=h("span",null,"讲稿备忘",-1))]),h("div",Ev,[h("button",{class:"notes-btn b3-tooltips b3-tooltips__w","aria-label":"减小字体",disabled:W.value<=14,onClick:M},[oe(de,{name:"minus"})],8,Av),h("span",Bv,we(W.value)+"px",1),h("button",{class:"notes-btn b3-tooltips b3-tooltips__w","aria-label":"增大字体",disabled:W.value>=36,onClick:j},[oe(de,{name:"plus"})],8,Dv)])]),h("div",{class:Ce(["notes-content",{"is-empty":!g.value}]),style:Yt({fontSize:W.value+"px"})},we(g.value||"（本页未设置演讲者备忘录）"),7)])])):(J(),ee("main",Lv,[h("div",Pv,[oe(de,{name:"refresh",class:"empty-icon"})]),ue[8]||(ue[8]=h("h2",null,"等待大屏放映数据",-1)),ue[9]||(ue[9]=h("p",null,"未检测到活跃的幻灯片数据，请先开启大屏放映端。",-1)),h("div",Ov,[h("button",{class:"btn-empty-action b3-tooltips b3-tooltips__n","aria-label":"在思源中打开底部演示预览页签",onClick:me},[oe(de,{name:"presenter"}),ue[6]||(ue[6]=h("span",null,"打开大屏放映页签",-1))]),h("button",{class:"btn-empty-action btn-empty-action--popout b3-tooltips b3-tooltips__n","aria-label":"将放映端弹出为独立窗口 (16:9)",onClick:$e},[oe(de,{name:"window"}),ue[7]||(ue[7]=h("span",null,"弹出独立放映窗口",-1))])])])),h("footer",Rv,[h("div",Nv,[h("button",{class:"btn-nav btn-nav--slide b3-tooltips b3-tooltips__ne",disabled:a.value<=1,"aria-label":"快速返回上一页 (Shift + ←)",onClick:te},[oe(de,{name:"chevrons-left"}),ue[10]||(ue[10]=h("span",null,"上一页",-1))],8,zv),h("button",{class:"btn-nav btn-nav--step b3-tooltips b3-tooltips__n",disabled:!re.value,"aria-label":"回退一步 (←)",onClick:H},[oe(de,{name:"chevron-left"}),ue[11]||(ue[11]=h("span",null,"上一步",-1))],8,Hv)]),h("div",Fv,[h("div",jv,[h("span",Wv,we(I.value)+"%",1)]),h("button",{class:"btn-restart b3-tooltips b3-tooltips__n","aria-label":"从第一页重新放映 (Home)",onClick:ne},[oe(de,{name:"reset"}),ue[12]||(ue[12]=h("span",null,"重头放映",-1))])]),h("div",Uv,[ie.value>0?(J(),ee("div",{key:0,class:"step-dots-bar b3-tooltips b3-tooltips__n","aria-label":`步进进度: ${r.value} / ${ie.value}`},[(J(!0),ee(Xe,null,St(ie.value,lt=>(J(),ee("span",{key:lt,class:Ce(["step-dot",{"is-active":lt<=r.value}])},null,2))),128)),h("span",Gv,we(r.value)+"/"+we(ie.value),1)],8,Vv)):Te("",!0),h("button",{class:"btn-nav btn-nav--step btn-nav--primary b3-tooltips b3-tooltips__n",disabled:!Se.value,"aria-label":"触发下一步骤或进入下一页 (Space / →)",onClick:D},[ue[13]||(ue[13]=h("span",null,"下一步",-1)),oe(de,{name:"chevron-right"})],8,Kv),h("button",{class:"btn-nav btn-nav--slide b3-tooltips b3-tooltips__nw",disabled:a.value>=u.value,"aria-label":"跳过本页剩余步骤，直接进入下一页 (Shift + →)",onClick:Z},[ue[14]||(ue[14]=h("span",null,"下一页",-1)),oe(de,{name:"chevrons-right"})],8,qv)])])],32)}}}),Xv=ii(Jv,[["__scopeId","data-v-c103f4a6"]]),Qv={class:"spm-layout-picker"},eb={class:"spm-layout-picker__grid"},tb=["title","onClick"],ib={class:"spm-layout-icon"},nb={class:"spm-layout-label"},sb=Dt({__name:"LayoutPicker",props:{modelValue:{}},emits:["update:modelValue","change"],setup(e,{emit:t}){const i=e,n=t,s=[{name:"cover",label:"封面",desc:"大标题与副标题封面页"},{name:"default",label:"标准",desc:"标题在上方，内容在下方"},{name:"two-cols",label:"双栏",desc:"左右双栏对比展示"},{name:"cols-header",label:"表头多栏",desc:"顶部通栏标题，下方自适应 2~N 栏"},{name:"clover",label:"四叶草",desc:"2x2 田字型四象限卡片布局"},{name:"image-right",label:"图右",desc:"左侧为内容，右侧全屏背景图"},{name:"image-left",label:"图左",desc:"左侧全屏背景图，右侧为内容"},{name:"center",label:"居中",desc:"内容全屏垂直水平居中"},{name:"fact",label:"大字报",desc:"核心数据或指标突出展示"},{name:"intro",label:"介绍",desc:"演讲者自我介绍或章节导览"},{name:"quote",label:"引言",desc:"名人名言与强调段落"}];function o(r){return i.modelValue===r||r==="cols-header"&&(i.modelValue==="two-cols-header"||i.modelValue==="three-cols-header")}function a(r){n("update:modelValue",r),n("change",r)}return(r,l)=>(J(),ee("div",Qv,[l[0]||(l[0]=h("div",{class:"spm-layout-picker__header"},"选择页面版式",-1)),h("div",eb,[(J(),ee(Xe,null,St(s,c=>h("div",{key:c.name,class:Ce(["spm-layout-item",{active:o(c.name)}]),title:c.desc,onClick:u=>a(c.name)},[h("div",ib,[oe(de,{name:"layout-"+c.name},null,8,["name"])]),h("span",nb,we(c.label),1)],10,tb)),64))])]))}}),ob=ii(sb,[["__scopeId","data-v-96c8a248"]]),rb={key:0,class:"spm-transition-selector__header"},ab={class:"spm-transition-list"},lb=["onClick"],cb={class:"spm-transition-meta"},db={class:"spm-transition-label"},ub={class:"spm-transition-preview-box"},fb=Dt({__name:"TransitionSelector",props:{modelValue:{},hideHeader:{type:Boolean},title:{}},emits:["update:modelValue","change"],setup(e,{emit:t}){const i=t,n=[{name:"slide-left",label:"向左滑入",desc:"向左滑入：页面从右侧向左平滑推入，最通用标准的横向幻灯片动效"},{name:"slide-right",label:"向右滑入",desc:"向右滑入：页面从左侧向右平滑推入，适合倒序回退或逆向章节叙述"},{name:"slide-up",label:"向上推入",desc:"向上推入：页面从底部向上平滑推入，适合纵向展开或纵深层级展示"},{name:"fade",label:"淡入淡出",desc:"淡入淡出：透明度平滑渐变过度，典雅柔和，适合学术长篇与沉浸叙事"},{name:"zoom",label:"缩放进入",desc:"缩放进入：页面由中心向外平滑放大，富有动感冲击力，适合聚焦重点"}];function s(o){i("update:modelValue",o),i("change",o)}return(o,a)=>(J(),ee("div",{class:Ce(["spm-transition-selector",{"spm-transition-selector--no-header":e.hideHeader}])},[e.hideHeader?Te("",!0):(J(),ee("div",rb,we(e.title||"转场动效"),1)),h("div",ab,[(J(),ee(Xe,null,St(n,r=>h("div",{key:r.name,class:Ce(["spm-transition-item",{active:e.modelValue===r.name}]),onClick:l=>s(r.name)},[h("div",cb,[h("span",db,we(r.label),1)]),h("div",ub,[h("div",{class:Ce(["spm-anim-cube","anim-"+r.name])},null,2)])],10,lb)),64))])],2))}}),lc=ii(fb,[["__scopeId","data-v-b5051f69"]]),pb={class:"spm-section spm-section--page"},hb={class:"spm-section-header"},mb={key:0,class:"spm-card-control",style:{"border-left":"3px solid var(--b3-theme-primary)",background:"rgba(var(--b3-theme-primary-rgb, 66, 133, 244), 0.06)",padding:"8px 12px","margin-top":"6px"}},gb={style:{display:"flex","align-items":"center","justify-content":"space-between",gap:"8px"}},vb={style:{"font-size":"11px",display:"flex","align-items":"center",gap:"6px",flex:"1"}},bb={key:1,class:"spm-card-control"},yb={class:"spm-control-header"},kb={class:"spm-control-title-group"},wb={class:"spm-control-title"},xb={class:"spm-quick-chips"},Sb=["onClick"],Cb={style:{display:"flex",gap:"6px","align-items":"center","margin-top":"6px"}},_b=["value"],$b=["aria-label"],Ib={key:1,class:"spm-icon-btn b3-tooltips b3-tooltips__sw",disabled:"",style:{opacity:"0.45",cursor:"not-allowed",padding:"0 8px",height:"26px","font-size":"11px","white-space":"nowrap","flex-shrink":"0"},"aria-label":"当前页未检测到调整过列宽的横向超级块"},Mb={key:0,style:{"margin-top":"6px","font-size":"11px",opacity:"0.85",display:"flex","align-items":"center",gap:"4px"}},Tb={style:{background:"rgba(125, 125, 125, 0.15)",padding:"1px 4px","border-radius":"3px","font-weight":"bold"}},Eb={key:1,style:{"margin-top":"6px","font-size":"11px",opacity:"0.6",display:"flex","align-items":"center",gap:"4px"}},Ab={class:"spm-card-control"},Bb={class:"spm-control-header"},Db={class:"spm-control-title-group"},Lb={class:"spm-control-title"},Pb={class:"spm-segmented-group"},Ob={key:0,style:{"margin-top":"10px",display:"flex","flex-direction":"column",gap:"8px"}},Rb={style:{display:"flex","align-items":"center","justify-content":"space-between"}},Nb=["aria-label"],zb={class:"spm-quick-chips"},Hb=["onClick"],Fb=["value"],jb={style:{"font-size":"10.5px",opacity:"0.6","line-height":"1.35","margin-top":"-2px"}},Wb={style:{display:"flex",gap:"8px","margin-top":"2px"}},Ub={style:{flex:"1"}},Vb={class:"spm-segmented-group"},Gb={style:{flex:"1"}},Kb={class:"spm-segmented-group"},qb={class:"spm-card-control"},Yb={class:"spm-control-header"},Zb={class:"spm-control-title-group"},Jb={class:"spm-control-title"},Xb={class:"spm-segmented-group"},Qb={key:2,class:"spm-card-control"},e1={class:"spm-control-header"},t1={class:"spm-control-title-group"},i1={class:"spm-control-title"},n1={class:"spm-quick-chips"},s1=["onClick"],o1=["value"],r1={class:"spm-card-control"},a1={class:"spm-control-header"},l1={class:"spm-control-title-group"},c1={class:"spm-control-title"},d1={key:0,class:"spm-note-status-box"},u1=["title"],f1={class:"spm-action-grid",style:{"margin-top":"6px"}},p1={key:1,class:"spm-note-empty-box"},h1={class:"spm-batch-actions-box",style:{"margin-top":"8px","border-top":"1px dashed var(--b3-border-color, #e2e8f0)","padding-top":"8px"}},m1={class:"spm-action-grid"},g1=["disabled"],v1=["disabled"],b1={class:"spm-card-control"},y1={class:"spm-action-grid"},k1=Dt({__name:"PageInspectorSection",props:{pageLayout:{},pageTransition:{},pageSpacing:{},pageImage:{},pageNotes:{},pageIndex:{},pageLayoutRatio:{},pageMask:{},pageMaskRatio:{},pageMaskStyle:{},pageMaskInitial:{},detectedSbRatio:{},detectedSbInfo:{},isBatchProcessing:{type:Boolean}},emits:["update:pageLayout","update:pageTransition","update:pageSpacing","update:pageImage","update:pageLayoutRatio","update:pageMask","update:pageMaskRatio","update:pageMaskStyle","update:pageMaskInitial","applySuperBlockLayout","resetSuperblockRatio","addNoteBlock","locateNoteBlock","generateNotes","batchAppendNotes","batchDeleteNotes","insertDividerAfter","deleteDivider"],setup(e,{emit:t}){const i=e,n=t,s=[{label:"1:1 (2步)",value:"1:1"},{label:"1:1:1 (3步)",value:"1:1:1"},{label:"1:2:1 (非等宽)",value:"1:2:1"},{label:"1:1:1:1 (4步)",value:"1:1:1:1"}],o=ye(()=>{const v=i.pageMask;return v==="clockwise"||v==="counter-clockwise"||v==="cw"||v==="ccw"}),a=ye(()=>o.value?"1:1:1:1":"1:1"),r=ye(()=>i.pageMaskRatio||a.value);function l(v){n("update:pageMask",v),(!i.pageMaskRatio||i.pageMaskRatio==="1:1")&&n("update:pageMaskRatio","1:1:1:1")}function c(v){n("update:pageMask",v),(!i.pageMaskRatio||i.pageMaskRatio==="1:1:1:1")&&n("update:pageMaskRatio","1:1")}const u=ye(()=>i.pageMask==="clockwise"||i.pageMask==="counter-clockwise"||i.pageMask==="cw"||i.pageMask==="ccw"?`时钟走时规则：
• 顺时针：左上 → 右上 → 右下 → 左下
• 逆时针：左上 → 左下 → 右下 → 右上
• 每次点击时针旋转 90° 并扇形扫开 1/4 象限，全部揭开后翻页`:`输入规则：
• 权重比例（项数决定步数）：如 1:1 (2步等分)、1:1:1 (3步等分)、1:2:1 (按权重累计分段)
• 绝对百分比：如 25:75:100 或 30:80 (指定每步展开的累计百分比)
• 每次点击或按空格/向右键展露下一段，全部揭开后翻页`),f=ye(()=>["two-cols","cols-header","two-cols-header","three-cols-header","image-left","image-right"].includes(i.pageLayout)),d=ye(()=>{var S,B;if(i.pageLayout==="two-cols-header"||i.pageLayout==="two-cols"||i.pageLayout==="image-left"||i.pageLayout==="image-right")return 2;if(i.pageLayout==="three-cols-header")return 3;const v=(i.pageLayoutRatio||"").trim();if(v.includes(":")){const A=v.split(":").filter(Boolean).length;if(A>=2&&A<=6)return A}const k=(i.detectedSbRatio||"").trim();if(k.includes(":")){const A=k.split(":").filter(Boolean).length;if(A>=2&&A<=6)return A}if((S=i.detectedSbInfo)!=null&&S.colCount&&i.detectedSbInfo.colCount>=2)return Math.min(i.detectedSbInfo.colCount,6);if((B=i.detectedSbInfo)!=null&&B.slots&&Array.isArray(i.detectedSbInfo.slots)){const A=i.detectedSbInfo.slots.length;if(A>=2&&A<=6)return A}return 2}),p=ye(()=>{const v=d.value;return v===3?[{label:"默认 1:1:1",value:""},{label:"1:2:1 (主中)",value:"1:2:1"},{label:"2:1:1 (主左)",value:"2:1:1"},{label:"1:1:2 (主右)",value:"1:1:2"},{label:"1:3:1",value:"1:3:1"}]:v===4?[{label:"默认 1:1:1:1",value:""},{label:"1:2:2:1",value:"1:2:2:1"},{label:"2:1:1:2",value:"2:1:1:2"}]:v===5?[{label:"默认 1:1:1:1:1",value:""}]:v===6?[{label:"默认 1:1:1:1:1:1",value:""}]:[{label:"默认 1:1",value:""},{label:"1:2",value:"1:2"},{label:"2:1",value:"2:1"},{label:"3:7",value:"3:7"},{label:"7:3",value:"7:3"},{label:"4:6",value:"4:6"},{label:"6:4",value:"6:4"}]}),w=ye(()=>i.pageLayoutRatio||"");function m(){const v=d.value||2,k=Array(v).fill("1").join(":");n("update:pageLayoutRatio",k),n("resetSuperblockRatio")}const b=ye(()=>{if(!i.pageNotes)return"";const v=i.pageNotes.replace(/[\r\n]+/g," ").trim();return v.length>50?v.slice(0,50)+"...":v}),y=[{label:"默认封面",value:"https://cover.sli.dev"},{label:"清空配图",value:""}];return(v,k)=>(J(),ee("div",pb,[h("div",hb,[h("span",null,"幻灯片页面设置"+we(e.pageIndex?` (第 ${e.pageIndex} 页)`:""),1)]),oe(ob,{"model-value":e.pageLayout,onChange:k[0]||(k[0]=S=>v.$emit("update:pageLayout",S))},null,8,["model-value"]),!f.value&&e.pageLayout!=="clover"&&e.detectedSbRatio?(J(),ee("div",mb,[h("div",gb,[h("div",vb,[oe(de,{name:"sparkles"}),h("span",null,[k[31]||(k[31]=It("检测到本页横向超级块列宽比例：",-1)),h("b",null,we(e.detectedSbRatio),1)])]),h("button",{class:"spm-btn-action b3-tooltips b3-tooltips__sw","aria-label":"一键应用超级块列宽并设为分栏",style:{padding:"2px 8px",height:"26px","font-size":"11px","flex-shrink":"0",background:"var(--b3-theme-primary)",color:"#fff",display:"inline-flex","align-items":"center",gap:"4px"},onClick:k[1]||(k[1]=S=>v.$emit("applySuperBlockLayout",e.detectedSbInfo||{recommendedLayout:"two-cols",ratio:e.detectedSbRatio}))},[oe(de,{name:"columns"}),k[32]||(k[32]=h("span",null,"设为分栏",-1))])])])):Te("",!0),f.value?(J(),ee("div",bb,[h("div",yb,[h("div",kb,[h("div",wb,[oe(de,{name:"ratio"}),k[33]||(k[33]=h("span",null,"分栏比例",-1))]),k[34]||(k[34]=h("span",{class:"spm-control-desc"},"设置各列横向空间占比，默认平均分配",-1))])]),h("div",xb,[(J(!0),ee(Xe,null,St(p.value,S=>(J(),ee("button",{key:S.value,class:Ce(["spm-chip",{active:w.value===S.value}]),onClick:B=>v.$emit("update:pageLayoutRatio",S.value)},we(S.label),11,Sb))),128))]),h("div",Cb,[h("input",{value:e.pageLayoutRatio||"",class:"spm-input",style:{flex:"1","min-width":"0"},placeholder:"自定义比例（如 1:2 或 30:70，留空为默认）",onInput:k[2]||(k[2]=S=>v.$emit("update:pageLayoutRatio",S.target.value)),onChange:k[3]||(k[3]=S=>v.$emit("update:pageLayoutRatio",S.target.value))},null,40,_b),e.detectedSbRatio?(J(),ee("button",{key:0,class:"spm-icon-btn b3-tooltips b3-tooltips__sw","aria-label":`读取超级块列宽比例 (${e.detectedSbRatio}) 并应用`,style:{padding:"0 8px",height:"26px","font-size":"11px","white-space":"nowrap","flex-shrink":"0"},onClick:k[4]||(k[4]=S=>v.$emit("update:pageLayoutRatio",e.detectedSbRatio))},[oe(de,{name:"sparkles"}),k[35]||(k[35]=h("span",null,"读取",-1))],8,$b)):(J(),ee("button",Ib,[oe(de,{name:"sparkles"}),k[36]||(k[36]=h("span",null,"读取",-1))])),h("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__sw","aria-label":"重置为等宽平均分布",style:{padding:"0 8px",height:"26px","font-size":"11px","white-space":"nowrap","flex-shrink":"0"},onClick:m},[oe(de,{name:"reset"}),k[37]||(k[37]=h("span",null,"重置",-1))])]),e.detectedSbRatio?(J(),ee("div",Mb,[oe(de,{name:"ratio"}),k[38]||(k[38]=h("span",null,"检测到思源超级块宽度：",-1)),h("code",Tb,we(e.detectedSbRatio),1)])):(J(),ee("div",Eb,[oe(de,{name:"ratio"}),k[39]||(k[39]=h("span",null,"未检测到调宽超级块（默认各列平均分配）",-1))]))])):Te("",!0),oe(lc,{"model-value":e.pageTransition,onChange:k[5]||(k[5]=S=>v.$emit("update:pageTransition",S))},null,8,["model-value"]),h("div",Ab,[h("div",Bb,[h("div",Db,[h("div",Lb,[oe(de,{name:"sparkles"}),k[40]||(k[40]=h("span",null,"页面动态蒙版",-1))]),k[41]||(k[41]=h("span",{class:"spm-control-desc"},"随着点击操作分段展露正文内容",-1))])]),h("div",Pb,[h("button",{class:Ce(["spm-segmented-item",{active:!e.pageMask}]),onClick:k[6]||(k[6]=S=>v.$emit("update:pageMask",""))}," 关闭 ",2),h("button",{class:Ce(["spm-segmented-item",{active:e.pageMask==="down"}]),onClick:k[7]||(k[7]=S=>c("down"))}," 从上至下 ",2),h("button",{class:Ce(["spm-segmented-item",{active:e.pageMask==="right"}]),onClick:k[8]||(k[8]=S=>c("right"))}," 从左至右 ",2),h("button",{class:Ce(["spm-segmented-item",{active:e.pageMask==="clockwise"||e.pageMask==="cw"}]),onClick:k[9]||(k[9]=S=>l("clockwise"))}," 顺时针 ↻ ",2),h("button",{class:Ce(["spm-segmented-item",{active:e.pageMask==="counter-clockwise"||e.pageMask==="ccw"}]),onClick:k[10]||(k[10]=S=>l("counter-clockwise"))}," 逆时针 ↺ ",2)]),e.pageMask?(J(),ee("div",Ob,[h("div",Rb,[k[43]||(k[43]=h("div",{style:{"font-size":"11px",opacity:"0.85","font-weight":"500"}},"展露比例 / 断点",-1)),h("span",{class:"b3-tooltips b3-tooltips__sw","aria-label":u.value,style:{cursor:"help",opacity:"0.75",display:"inline-flex","align-items":"center",gap:"3px","font-size":"11px"}},[oe(de,{name:"help"}),k[42]||(k[42]=h("span",null,"输入规则",-1))],8,Nb)]),h("div",zb,[(J(),ee(Xe,null,St(s,S=>h("button",{key:S.value,class:Ce(["spm-chip",{active:r.value===S.value}]),onClick:B=>v.$emit("update:pageMaskRatio",S.value)},we(S.label),11,Hb)),64))]),h("input",{value:r.value,class:"spm-input",style:{width:"100%"},placeholder:"自定义比例或断点（如 1:2:1 或 25:75:100）",onInput:k[11]||(k[11]=S=>v.$emit("update:pageMaskRatio",S.target.value)),onChange:k[12]||(k[12]=S=>v.$emit("update:pageMaskRatio",S.target.value))},null,40,Fb),h("div",jb,we(e.pageMask==="clockwise"||e.pageMask==="counter-clockwise"||e.pageMask==="cw"||e.pageMask==="ccw"?"时钟走时蒙版：默认 4 步旋转展露（1:1:1:1，每步 25% 扇形面积）":"提示：支持权重比（如 1:2:1）或绝对断点（如 25:75:100），冒号项数决定点击步数"),1),h("div",Wb,[h("div",Ub,[k[44]||(k[44]=h("div",{style:{"font-size":"11px",opacity:"0.85","margin-bottom":"4px"}},"遮盖质感",-1)),h("div",Vb,[h("button",{class:Ce(["spm-segmented-item",{active:!e.pageMaskStyle||e.pageMaskStyle==="solid"}]),onClick:k[13]||(k[13]=S=>v.$emit("update:pageMaskStyle","solid"))}," 背景同色 ",2),h("button",{class:Ce(["spm-segmented-item",{active:e.pageMaskStyle==="blur"}]),onClick:k[14]||(k[14]=S=>v.$emit("update:pageMaskStyle","blur"))}," 磨砂毛玻璃 ",2)])]),h("div",Gb,[k[45]||(k[45]=h("div",{style:{"font-size":"11px",opacity:"0.85","margin-bottom":"4px"}},"初始展露",-1)),h("div",Kb,[h("button",{class:Ce(["spm-segmented-item",{active:!e.pageMaskInitial||e.pageMaskInitial==="hidden"}]),onClick:k[15]||(k[15]=S=>v.$emit("update:pageMaskInitial","hidden"))}," 完全遮盖 ",2),h("button",{class:Ce(["spm-segmented-item",{active:e.pageMaskInitial==="revealed"}]),onClick:k[16]||(k[16]=S=>v.$emit("update:pageMaskInitial","revealed"))}," 首段可见 ",2)])])])])):Te("",!0)]),h("div",qb,[h("div",Yb,[h("div",Zb,[h("div",Jb,[oe(de,{name:"ratio"}),k[46]||(k[46]=h("span",null,"页面间距",-1))]),k[47]||(k[47]=h("span",{class:"spm-control-desc"},"覆盖本页内边距与顶部标题间距",-1))])]),h("div",Xb,[h("button",{class:Ce(["spm-segmented-item",{active:!e.pageSpacing||e.pageSpacing==="inherit"}]),onClick:k[17]||(k[17]=S=>v.$emit("update:pageSpacing","inherit"))}," 继承全局 ",2),h("button",{class:Ce(["spm-segmented-item",{active:e.pageSpacing==="compact"}]),onClick:k[18]||(k[18]=S=>v.$emit("update:pageSpacing","compact"))}," 紧凑 ",2),h("button",{class:Ce(["spm-segmented-item",{active:e.pageSpacing==="normal"}]),onClick:k[19]||(k[19]=S=>v.$emit("update:pageSpacing","normal"))}," 标准 ",2),h("button",{class:Ce(["spm-segmented-item",{active:e.pageSpacing==="loose"}]),onClick:k[20]||(k[20]=S=>v.$emit("update:pageSpacing","loose"))}," 宽松 ",2)])]),e.pageLayout==="image-right"||e.pageLayout==="image-left"||e.pageImage?(J(),ee("div",Qb,[h("div",e1,[h("div",t1,[h("div",i1,[oe(de,{name:"image"}),k[48]||(k[48]=h("span",null,"页面图片",-1))]),k[49]||(k[49]=h("span",{class:"spm-control-desc"},"图文分栏或页面专属配图 URL / 资源路径",-1))])]),h("div",n1,[(J(),ee(Xe,null,St(y,S=>h("button",{key:S.value,class:Ce(["spm-chip",{active:e.pageImage===S.value}]),onClick:B=>v.$emit("update:pageImage",S.value)},we(S.label),11,s1)),64))]),h("input",{value:e.pageImage,class:"spm-input",placeholder:"网络图片 URL (如 https://cover.sli.dev) 或 assets/...",onInput:k[21]||(k[21]=S=>v.$emit("update:pageImage",S.target.value)),onChange:k[22]||(k[22]=S=>v.$emit("update:pageImage",S.target.value))},null,40,o1)])):Te("",!0),h("div",r1,[h("div",a1,[h("div",l1,[h("div",c1,[oe(de,{name:"presenter"}),k[50]||(k[50]=h("span",null,"演讲者提词",-1))]),k[51]||(k[51]=h("span",{class:"spm-control-desc"},"正文备注块驱动 · 仅演讲者视图可见",-1))]),he(gt)("aiScript")?(J(),ee("button",{key:0,class:"spm-btn-text b3-tooltips b3-tooltips__sw","aria-label":"AI 自动生成本页讲稿提示块",onClick:k[23]||(k[23]=S=>v.$emit("generateNotes"))},[oe(de,{name:"sparkles"}),k[52]||(k[52]=h("span",null,"AI 讲稿",-1))])):Te("",!0)]),e.pageNotes?(J(),ee("div",d1,[k[55]||(k[55]=h("div",{class:"spm-note-status-badge"},[h("span",{class:"spm-badge-dot"}),h("span",null,"已配置正文讲稿")],-1)),h("div",{class:"spm-note-preview-text",title:e.pageNotes},we(b.value),9,u1),h("div",f1,[h("button",{class:"spm-btn-action b3-tooltips b3-tooltips__se","aria-label":"在正文编辑区定位并高亮此讲稿备注块",onClick:k[24]||(k[24]=S=>v.$emit("locateNoteBlock"))},[oe(de,{name:"search"}),k[53]||(k[53]=h("span",null,"定位讲稿块",-1))]),h("button",{class:"spm-btn-action b3-tooltips b3-tooltips__sw","aria-label":"在本页末尾追加新的讲稿提示块",onClick:k[25]||(k[25]=S=>v.$emit("addNoteBlock"))},[oe(de,{name:"insert-below"}),k[54]||(k[54]=h("span",null,"追加讲稿块",-1))])])])):(J(),ee("div",p1,[k[57]||(k[57]=h("div",{class:"spm-note-empty-hint"},"本页暂无讲稿备注块",-1)),h("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s",style:{width:"100%","margin-top":"6px"},"aria-label":"在当前页末尾插入默认演讲备注提示块",onClick:k[26]||(k[26]=S=>v.$emit("addNoteBlock"))},[oe(de,{name:"insert-below"}),k[56]||(k[56]=h("span",null,"添加讲稿备注块",-1))])])),h("div",h1,[h("div",m1,[h("button",{class:"spm-btn-action b3-tooltips b3-tooltips__se",disabled:e.isBatchProcessing,style:Yt(e.isBatchProcessing?"opacity: 0.5; cursor: not-allowed;":""),"aria-label":"在所有尚未配置讲稿的页面末尾批量追加讲稿提示块",onClick:k[27]||(k[27]=S=>v.$emit("batchAppendNotes"))},[oe(de,{name:"insert-below"}),k[58]||(k[58]=h("span",null,"全部追加",-1))],12,g1),h("button",{class:"spm-btn-action spm-btn-danger b3-tooltips b3-tooltips__sw",disabled:e.isBatchProcessing,style:Yt(e.isBatchProcessing?"opacity: 0.5; cursor: not-allowed;":""),"aria-label":"批量物理删除正文中的全部讲稿备注块（涉及全部页）",onClick:k[28]||(k[28]=S=>v.$emit("batchDeleteNotes"))},[oe(de,{name:"trash"}),k[59]||(k[59]=h("span",null,"全部删除",-1))],12,v1)])])]),h("div",b1,[k[62]||(k[62]=h("div",{class:"spm-control-header"},[h("div",{class:"spm-control-title-group"},[h("span",{class:"spm-control-title"},"分页快捷操作")])],-1)),h("div",y1,[h("button",{class:"spm-btn-action b3-tooltips b3-tooltips__se","aria-label":"在此分页符之后插入新的空白分页",onClick:k[29]||(k[29]=S=>v.$emit("insertDividerAfter"))},[oe(de,{name:"insert-below"}),k[60]||(k[60]=h("span",null,"插入新页",-1))]),h("button",{class:"spm-btn-action spm-btn-danger b3-tooltips b3-tooltips__sw","aria-label":"彻底删除当前分页符（合并前后页面）",onClick:k[30]||(k[30]=S=>v.$emit("deleteDivider"))},[oe(de,{name:"trash"}),k[61]||(k[61]=h("span",null,"删除此页",-1))])])])]))}}),w1=ii(k1,[["__scopeId","data-v-2b63202b"]]),x1={class:"spm-section spm-section--block"},S1={key:0,class:"spm-card-control",style:{"border-left":"3px solid var(--b3-theme-primary)"}},C1={class:"spm-control-header"},_1={class:"spm-control-title-group"},$1={class:"spm-control-title"},I1={style:{background:"var(--b3-theme-surface)",border:"1px solid var(--b3-theme-surface-lighter)","border-radius":"6px",padding:"10px","margin-bottom":"8px"}},M1={style:{display:"flex","align-items":"center","justify-content":"space-between","margin-bottom":"4px"}},T1={style:{"font-size":"12px","font-weight":"500",display:"flex","align-items":"center",gap:"4px"}},E1={key:0},A1={key:1},B1={style:{background:"rgba(var(--b3-theme-primary-rgb, 59, 130, 246), 0.16)",color:"var(--b3-theme-primary)",border:"1px solid rgba(var(--b3-theme-primary-rgb, 59, 130, 246), 0.3)",padding:"2px 6px","border-radius":"4px","font-weight":"bold","font-size":"12px"}},D1={style:{"font-size":"11px",opacity:"0.75","line-height":"1.4"}},L1={class:"spm-action-grid"},P1={class:"spm-card-control"},O1={class:"spm-control-header"},R1={class:"spm-control-title-group"},N1={class:"spm-control-title"},z1=["aria-label"],H1=["checked"],F1={key:1,class:"spm-card-control"},j1={class:"spm-control-header"},W1={class:"spm-control-title-group"},U1={class:"spm-control-title"},V1={class:"spm-quick-chips"},G1={key:2,class:"spm-card-control"},K1={class:"spm-control-header"},q1={class:"spm-control-title-group"},Y1={class:"spm-control-title"},Z1={class:"spm-video-settings-grid",style:{display:"grid","grid-template-columns":"1fr 1fr",gap:"8px","margin-top":"8px"}},J1={class:"spm-toggle-item",style:{display:"flex","align-items":"center","justify-content":"space-between",padding:"4px 6px",background:"rgba(125,125,125,0.06)","border-radius":"4px"}},X1={style:{"font-size":"11px",display:"inline-flex","align-items":"center",gap:"4px"}},Q1=["aria-label"],ey=["checked"],ty={class:"spm-toggle-item",style:{display:"flex","align-items":"center","justify-content":"space-between",padding:"4px 6px",background:"rgba(125,125,125,0.06)","border-radius":"4px"}},iy={style:{"font-size":"11px",display:"inline-flex","align-items":"center",gap:"4px"}},ny=["aria-label"],sy=["checked"],oy={class:"spm-toggle-item",style:{display:"flex","align-items":"center","justify-content":"space-between",padding:"4px 6px",background:"rgba(125,125,125,0.06)","border-radius":"4px"}},ry={style:{"font-size":"11px",display:"inline-flex","align-items":"center",gap:"4px"}},ay=["aria-label"],ly=["checked"],cy={class:"spm-toggle-item",style:{display:"flex","align-items":"center","justify-content":"space-between",padding:"4px 6px",background:"rgba(125,125,125,0.06)","border-radius":"4px"}},dy={style:{"font-size":"11px",display:"inline-flex","align-items":"center",gap:"4px"}},uy=["aria-label"],fy=["checked"],py={class:"spm-card-control"},hy={class:"spm-control-header"},my={class:"spm-control-title-group"},gy={class:"spm-control-title"},vy=["aria-label"],by=["checked"],yy={key:0,class:"spm-quick-chips"},ky=["onClick"],wy={key:1,class:"spm-inherit-tip",style:{"margin-top":"6px",padding:"4px 8px",background:"rgba(var(--b3-theme-primary-rgb, 59, 130, 246), 0.08)","border-radius":"4px","font-size":"11px",opacity:"0.85",display:"flex","align-items":"center",gap:"4px"}},xy={class:"spm-card-control"},Sy={class:"spm-control-header"},Cy={class:"spm-control-title-group"},_y={class:"spm-control-title"},$y=["aria-label"],Iy=["checked"],My={key:0,class:"spm-quick-chips"},Ty=["onClick"],Ey={key:1,class:"spm-motion-details",style:{display:"flex","flex-direction":"column",gap:"4px","margin-top":"4px"}},Ay={style:{display:"flex",gap:"8px","justify-content":"space-between","font-size":"11px",opacity:"0.8"}},By={style:{display:"flex",gap:"6px"}},Dy=["value"],Ly=["value"],Py={key:3,class:"spm-card-control"},Oy={class:"spm-control-header"},Ry={class:"spm-control-title-group"},Ny={class:"spm-control-title"},zy={class:"spm-control-desc"},Hy={class:"spm-segmented-group"},Fy=["onClick"],jy={key:4,class:"spm-card-control"},Wy={class:"spm-control-header"},Uy={class:"spm-control-title-group"},Vy={class:"spm-control-title"},Gy={class:"spm-quick-chips"},Ky=["onClick"],qy=["value"],Yy={key:5,class:"spm-card-control"},Zy={class:"spm-control-header"},Jy={class:"spm-control-title-group"},Xy={class:"spm-control-title"},Qy={class:"spm-quick-chips"},e0=["onClick"],t0=["value"],i0={class:"spm-card-control"},n0={class:"spm-action-grid"},s0=["aria-label"],o0=Dt({__name:"BlockInspectorSection",props:{elemClick:{},elemMotion:{},elemSlot:{},elemShikiLines:{},elemMaxHeight:{},isCodeBlock:{type:Boolean},isImage:{type:Boolean},isVideo:{type:Boolean},videoAutoplay:{type:Boolean},videoLoop:{type:Boolean},videoMuted:{type:Boolean},videoControls:{type:Boolean},hasBlockAttrs:{type:Boolean},isNote:{type:Boolean},imageRole:{},currentSlideLayout:{},isSuperBlock:{type:Boolean},parentElemClick:{},parentContainerSlot:{},parentContainerId:{},detectedSbInfo:{}},emits:["toggleNote","toggleElemClick","update:elemClick","update:elemMotion","update:elemSlot","update:elemShikiLines","update:elemMaxHeight","applySuperBlockLayout","applySuperBlockRatio","insertDividerBefore","insertDividerAfter","setTwoColsContrast","clearBlockAttrs","update:imageRole","toggleVideoAutoplay","toggleVideoLoop","toggleVideoMuted","toggleVideoControls"],setup(e,{emit:t}){const i=e,n=ye(()=>{const A=i.currentSlideLayout||"";return["col-1","col-2","col-3","col-4","col-5","col-6"].includes(i.elemSlot)?"cols-header":A}),s=ye(()=>{const A=n.value;return["two-cols","cols-header","two-cols-header","three-cols-header"].includes(A)}),o=ye(()=>{var C,L,z,N;if((C=i.detectedSbInfo)!=null&&C.colCount&&i.detectedSbInfo.colCount>=2)return Math.min(i.detectedSbInfo.colCount,6);const A=(L=i.elemSlot)==null?void 0:L.match(/^col-(\d+)$/);if(A){const K=parseInt(A[1],10);if(K>=2&&K<=6)return Math.max(K,3)}if(i.currentSlideLayout==="three-cols-header")return 3;if(i.currentSlideLayout==="two-cols-header"||i.currentSlideLayout==="two-cols")return 2;if((N=(z=i.detectedSbInfo)==null?void 0:z.ratio)!=null&&N.includes(":")){const K=i.detectedSbInfo.ratio.split(":").filter(Boolean);if(K.length>=2)return Math.min(K.length,6)}return 3}),a=ye(()=>{const A=n.value;return A==="cols-header"?"多栏插槽归属":A==="three-cols-header"?"三栏插槽归属":A==="two-cols-header"?"带表头双栏插槽":"多栏插槽归属"}),r=ye(()=>{const A=n.value;return A==="cols-header"?`在 cols-header 表头多栏（${o.value} 栏）中的内容块位置`:A==="three-cols-header"?"在 three-cols-header 版式中的内容块位置":A==="two-cols-header"?"在 two-cols-header 版式中的内容块位置":A==="two-cols"?"在 two-cols 双栏版式中的归属":"在当前分栏版式中的内容块位置"}),l=ye(()=>{const A=n.value;if(A==="two-cols")return[{value:"",label:"默认 (左)"},{value:"right",label:"右栏"}];if(A==="two-cols-header")return[{value:"",label:"默认"},{value:"header",label:"表头"},{value:"left",label:"左栏"},{value:"right",label:"右栏"}];if(A==="three-cols-header")return[{value:"",label:"默认"},{value:"header",label:"表头"},{value:"col-1",label:"第 1 栏"},{value:"col-2",label:"第 2 栏"},{value:"col-3",label:"第 3 栏"}];const C=o.value,L=[{value:"",label:"默认"},{value:"header",label:"表头"}];for(let z=1;z<=C;z++)L.push({value:`col-${z}`,label:`第 ${z} 栏`});return L});function c(A){const C=i.elemSlot||"";return A?C===A||A==="col-1"&&C==="left"||A==="col-2"&&C==="center"||A==="col-3"&&C==="right"&&o.value===3||A==="col-2"&&C==="right"&&o.value===2||A==="left"&&C==="col-1"||A==="right"&&(C==="col-2"||C==="col-3"):!C||C==="default"}const u=t,f=[{label:"上浮",value:"slide-up"},{label:"淡入",value:"fade-in"},{label:"下沉",value:"slide-down"},{label:"左滑",value:"slide-left"},{label:"右滑",value:"slide-right"},{label:"缩放",value:"zoom-in"},{label:"弹性",value:"bounce"}],d=ye(()=>{if(!i.elemMotion||i.elemMotion.trim()===""||i.elemMotion.trim()==="none")return null;try{const A=JSON.parse(i.elemMotion);if(typeof A=="object"&&A!==null)return{preset:A.preset||A.type||"slide-up",duration:typeof A.duration=="number"?A.duration:0,delay:typeof A.delay=="number"?A.delay:0}}catch{}return{preset:i.elemMotion.trim(),duration:0,delay:0}}),p=ye(()=>!!d.value),w=ye(()=>{var A;return((A=d.value)==null?void 0:A.preset)||"slide-up"}),m=ye(()=>{var A;return((A=d.value)==null?void 0:A.duration)||0}),b=ye(()=>{var A;return((A=d.value)==null?void 0:A.delay)||0});function y(){p.value?u("update:elemMotion",""):u("update:elemMotion","slide-up")}function v(A){B(A,m.value,b.value)}function k(A){B(w.value,A,b.value)}function S(A){B(w.value,m.value,A)}function B(A,C,L){if(!A||A==="none"){u("update:elemMotion","");return}if(!C&&!L){u("update:elemMotion",A);return}const z={preset:A};C>0&&(z.duration=C),L>0&&(z.delay=L),u("update:elemMotion",JSON.stringify(z))}return(A,C)=>{var L,z,N,K,_,U;return J(),ee("div",x1,[C[62]||(C[62]=h("div",{class:"spm-section-header"},[h("span",null,"元素动效与排版")],-1)),e.isSuperBlock||(L=e.detectedSbInfo)!=null&&L.hasSuperBlock?(J(),ee("div",S1,[h("div",C1,[h("div",_1,[h("div",$1,[oe(de,{name:"ratio"}),C[24]||(C[24]=h("span",null,"超级块列宽与布局",-1))]),C[25]||(C[25]=h("span",{class:"spm-control-desc"},"读取思源超级块列宽并一键同步到幻灯片分栏",-1))])]),h("div",I1,[h("div",M1,[h("div",T1,[oe(de,{name:"ratio"}),(z=e.detectedSbInfo)!=null&&z.isCustomWidth?(J(),ee("span",E1,"已识别自定义列宽比例")):(J(),ee("span",A1,"识别到 "+we(((N=e.detectedSbInfo)==null?void 0:N.colCount)||2)+" 列超级块分栏",1))]),h("code",B1,we(((K=e.detectedSbInfo)==null?void 0:K.ratio)||"1:1"),1)]),h("div",D1,we((_=e.detectedSbInfo)!=null&&_.isCustomWidth?"检测到已调节子块宽度，可一键应用为当前页分栏比例。":"当前超级块子列为思源默认均宽，可在思源中拖动调节或直接应用。"),1)]),h("div",L1,[h("button",{class:"spm-btn-action b3-tooltips b3-tooltips__se","aria-label":"一键将当前页版式切换为对应双栏/三栏，并写入此列宽比例",style:{background:"rgba(var(--b3-theme-primary-rgb, 59, 130, 246), 0.16)",color:"var(--b3-theme-primary)","font-weight":"500",border:"1px solid rgba(var(--b3-theme-primary-rgb, 59, 130, 246), 0.3)"},onClick:C[0]||(C[0]=x=>A.$emit("applySuperBlockLayout",e.detectedSbInfo))},[oe(de,{name:"sparkles"}),C[26]||(C[26]=h("span",null,"应用版式与比例",-1))]),h("button",{class:"spm-btn-action b3-tooltips b3-tooltips__sw","aria-label":"仅将提取的比值写入当前页的分栏比例属性",onClick:C[1]||(C[1]=x=>{var q;return A.$emit("applySuperBlockRatio",((q=e.detectedSbInfo)==null?void 0:q.ratio)||"1:1")})},[oe(de,{name:"check"}),h("span",null,"应用比例 ("+we(((U=e.detectedSbInfo)==null?void 0:U.ratio)||"1:1")+")",1)])])])):Te("",!0),h("div",P1,[h("div",O1,[h("div",R1,[h("div",N1,[oe(de,{name:"presenter"}),C[27]||(C[27]=h("span",null,"设为讲稿备注",-1))]),C[28]||(C[28]=h("span",{class:"spm-control-desc"},"作为当前页演讲提词，不在幻灯片中渲染",-1))]),h("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":e.isNote?"取消讲稿备注":"设为讲稿备注"},[h("input",{type:"checkbox",checked:!!e.isNote,onChange:C[2]||(C[2]=x=>A.$emit("toggleNote"))},null,40,H1),C[29]||(C[29]=h("span",{class:"spm-switch-slider"},null,-1))],8,z1)])]),e.isImage||e.imageRole?(J(),ee("div",F1,[h("div",j1,[h("div",W1,[h("div",U1,[oe(de,{name:"image"}),C[30]||(C[30]=h("span",null,"图片角色与分栏",-1))]),C[31]||(C[31]=h("span",{class:"spm-control-desc"},"设为幻灯片背景图或图文分栏配图",-1))])]),h("div",V1,[h("button",{class:Ce(["spm-chip",{active:!e.imageRole}]),onClick:C[3]||(C[3]=x=>A.$emit("update:imageRole",""))}," 普通内容 ",2),h("button",{class:Ce(["spm-chip",{active:e.imageRole==="background"}]),onClick:C[4]||(C[4]=x=>A.$emit("update:imageRole","background"))},[oe(de,{name:"image"}),C[32]||(C[32]=h("span",null,"背景图",-1))],2),h("button",{class:Ce(["spm-chip",{active:e.imageRole==="image-left"}]),onClick:C[5]||(C[5]=x=>A.$emit("update:imageRole","image-left"))},[oe(de,{name:"image-left"}),C[33]||(C[33]=h("span",null,"图左",-1))],2),h("button",{class:Ce(["spm-chip",{active:e.imageRole==="image-right"}]),onClick:C[6]||(C[6]=x=>A.$emit("update:imageRole","image-right"))},[oe(de,{name:"image-right"}),C[34]||(C[34]=h("span",null,"图右",-1))],2)])])):Te("",!0),e.isVideo?(J(),ee("div",G1,[h("div",K1,[h("div",q1,[h("div",Y1,[oe(de,{name:"video"}),C[35]||(C[35]=h("span",null,"视频播放设置",-1))]),C[36]||(C[36]=h("span",{class:"spm-control-desc"},"配置播放器控制条、自动播放与循环",-1))])]),h("div",Z1,[h("div",J1,[h("span",X1,[oe(de,{name:"sliders"}),C[37]||(C[37]=It(" 控制条",-1))]),h("label",{class:"spm-switch b3-tooltips b3-tooltips__se","aria-label":e.videoControls?"关闭控制条":"开启控制条"},[h("input",{type:"checkbox",checked:!!e.videoControls,onChange:C[7]||(C[7]=x=>A.$emit("toggleVideoControls"))},null,40,ey),C[38]||(C[38]=h("span",{class:"spm-switch-slider"},null,-1))],8,Q1)]),h("div",ty,[h("span",iy,[oe(de,{name:"video"}),C[39]||(C[39]=It(" 自动播放",-1))]),h("label",{class:"spm-switch b3-tooltips b3-tooltips__sw","aria-label":e.videoAutoplay?"关闭自动播放":"开启自动播放"},[h("input",{type:"checkbox",checked:!!e.videoAutoplay,onChange:C[8]||(C[8]=x=>A.$emit("toggleVideoAutoplay"))},null,40,sy),C[40]||(C[40]=h("span",{class:"spm-switch-slider"},null,-1))],8,ny)]),h("div",oy,[h("span",ry,[oe(de,{name:"repeat"}),C[41]||(C[41]=It(" 循环播放",-1))]),h("label",{class:"spm-switch b3-tooltips b3-tooltips__se","aria-label":e.videoLoop?"关闭循环播放":"开启循环播放"},[h("input",{type:"checkbox",checked:!!e.videoLoop,onChange:C[9]||(C[9]=x=>A.$emit("toggleVideoLoop"))},null,40,ly),C[42]||(C[42]=h("span",{class:"spm-switch-slider"},null,-1))],8,ay)]),h("div",cy,[h("span",dy,[oe(de,{name:"volume-x"}),C[43]||(C[43]=It(" 静音播放",-1))]),h("label",{class:"spm-switch b3-tooltips b3-tooltips__sw","aria-label":e.videoMuted?"关闭静音":"开启静音"},[h("input",{type:"checkbox",checked:!!e.videoMuted,onChange:C[10]||(C[10]=x=>A.$emit("toggleVideoMuted"))},null,40,fy),C[44]||(C[44]=h("span",{class:"spm-switch-slider"},null,-1))],8,uy)])])])):Te("",!0),h("div",py,[h("div",hy,[h("div",my,[h("div",gy,[oe(de,{name:"step"}),C[45]||(C[45]=h("span",null,"逐步呈现",-1))]),C[46]||(C[46]=h("span",{class:"spm-control-desc"},"放映时按步长逐个呈现",-1))]),h("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":e.elemClick?"关闭逐步呈现":"开启逐步呈现 (+1)"},[h("input",{type:"checkbox",checked:!!e.elemClick,onChange:C[11]||(C[11]=x=>A.$emit("toggleElemClick"))},null,40,by),C[47]||(C[47]=h("span",{class:"spm-switch-slider"},null,-1))],8,vy)]),e.elemClick?(J(),ee("div",yy,[(J(),ee(Xe,null,St(["+1","1","2","hide"],x=>h("button",{key:x,class:Ce(["spm-chip",{active:e.elemClick===x}]),onClick:q=>A.$emit("update:elemClick",x)},we(x==="+1"?"顺延 (+1)":x==="hide"?"隐藏":"第 "+x+" 步"),11,ky)),64))])):e.parentElemClick?(J(),ee("div",wy,[oe(de,{name:"check"}),C[48]||(C[48]=h("span",null,"未单独开启逐步呈现：当前跟随整栏同时出现",-1))])):Te("",!0)]),h("div",xy,[h("div",Sy,[h("div",Cy,[h("div",_y,[oe(de,{name:"motion"}),C[49]||(C[49]=h("span",null,"入场微动效",-1))]),C[50]||(C[50]=h("span",{class:"spm-control-desc"},"为当前块添加平滑位移与渐入动画",-1))]),h("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":p.value?"关闭微动效":"开启微动效"},[h("input",{type:"checkbox",checked:p.value,onChange:y},null,40,Iy),C[51]||(C[51]=h("span",{class:"spm-switch-slider"},null,-1))],8,$y)]),p.value?(J(),ee("div",My,[(J(),ee(Xe,null,St(f,x=>h("button",{key:x.value,class:Ce(["spm-chip",{active:w.value===x.value}]),onClick:q=>v(x.value)},we(x.label),11,Ty)),64))])):Te("",!0),p.value?(J(),ee("div",Ey,[h("div",Ay,[h("span",null,"时长: "+we(m.value?m.value+"ms":"默认 (450ms)"),1),h("span",null,"延迟: "+we(b.value?b.value+"ms":"0ms"),1)]),h("div",By,[h("select",{class:"spm-select",style:{flex:"1"},value:m.value,onChange:C[12]||(C[12]=x=>k(Number(x.target.value)))},[...C[52]||(C[52]=[h("option",{value:0},"默认耗时",-1),h("option",{value:200},"极速 (200ms)",-1),h("option",{value:350},"较快 (350ms)",-1),h("option",{value:500},"平滑 (500ms)",-1),h("option",{value:800},"缓慢 (800ms)",-1)])],40,Dy),h("select",{class:"spm-select",style:{flex:"1"},value:b.value,onChange:C[13]||(C[13]=x=>S(Number(x.target.value)))},[...C[53]||(C[53]=[h("option",{value:0},"无延迟",-1),h("option",{value:150},"延迟 150ms",-1),h("option",{value:300},"延迟 300ms",-1),h("option",{value:500},"延迟 500ms",-1)])],40,Ly)])])):Te("",!0)]),s.value||e.elemSlot?(J(),ee("div",Py,[h("div",Oy,[h("div",Ry,[h("div",Ny,[oe(de,{name:"columns"}),h("span",null,we(a.value),1)]),h("span",zy,we(r.value),1)])]),h("div",Hy,[(J(!0),ee(Xe,null,St(l.value,x=>(J(),ee("button",{key:x.value,class:Ce(["spm-segmented-item",{active:c(x.value)}]),onClick:q=>A.$emit("update:elemSlot",x.value)},we(x.label),11,Fy))),128))])])):Te("",!0),e.isCodeBlock?(J(),ee("div",jy,[h("div",Wy,[h("div",Uy,[h("div",Vy,[oe(de,{name:"code"}),C[54]||(C[54]=h("span",null,"代码逐行聚光",-1))]),C[55]||(C[55]=h("span",{class:"spm-control-desc"},"翻页时动态聚光高亮特定行",-1))])]),h("div",Gy,[(J(),ee(Xe,null,St(["1-3","all","1|2|3","2-5"],x=>h("button",{key:x,class:Ce(["spm-chip",{active:e.elemShikiLines===x}]),onClick:q=>A.$emit("update:elemShikiLines",x)},we(x),11,Ky)),64)),e.elemShikiLines?(J(),ee("button",{key:0,class:"spm-chip spm-chip-clear",onClick:C[14]||(C[14]=x=>A.$emit("update:elemShikiLines",""))}," 清空 ")):Te("",!0)]),h("input",{value:e.elemShikiLines,class:"spm-input",placeholder:"自定义高亮区间，如 1-3|5|all",onInput:C[15]||(C[15]=x=>A.$emit("update:elemShikiLines",x.target.value)),onChange:C[16]||(C[16]=x=>A.$emit("update:elemShikiLines",x.target.value))},null,40,qy)])):Te("",!0),e.isCodeBlock?(J(),ee("div",Yy,[h("div",Zy,[h("div",Jy,[h("div",Xy,[oe(de,{name:"code"}),C[56]||(C[56]=h("span",null,"代码块限高",-1))]),C[57]||(C[57]=h("span",{class:"spm-control-desc"},"超出限高自动竖向滚动，弱提示滚动条",-1))])]),h("div",Qy,[(J(),ee(Xe,null,St(["240px","320px","400px","50vh"],x=>h("button",{key:x,class:Ce(["spm-chip",{active:e.elemMaxHeight===x}]),onClick:q=>A.$emit("update:elemMaxHeight",x)},we(x),11,e0)),64)),e.elemMaxHeight?(J(),ee("button",{key:0,class:"spm-chip spm-chip-clear",onClick:C[17]||(C[17]=x=>A.$emit("update:elemMaxHeight",""))}," 自适应 ")):Te("",!0)]),h("input",{value:e.elemMaxHeight,class:"spm-input",placeholder:"自适应高度，或输入 350px、50vh",onInput:C[18]||(C[18]=x=>A.$emit("update:elemMaxHeight",x.target.value)),onChange:C[19]||(C[19]=x=>A.$emit("update:elemMaxHeight",x.target.value))},null,40,t0)])):Te("",!0),h("div",i0,[C[61]||(C[61]=h("div",{class:"spm-control-header"},[h("div",{class:"spm-control-title-group"},[h("span",{class:"spm-control-title"},"快捷操作")])],-1)),h("div",n0,[h("button",{class:"spm-btn-action b3-tooltips b3-tooltips__se","aria-label":"在当前块上方插入幻灯片分页线 (---)",onClick:C[20]||(C[20]=x=>A.$emit("insertDividerBefore"))},[oe(de,{name:"insert-above"}),C[58]||(C[58]=h("span",null,"上方分页",-1))]),h("button",{class:"spm-btn-action b3-tooltips b3-tooltips__sw","aria-label":"在当前块下方插入幻灯片分页线 (---)",onClick:C[21]||(C[21]=x=>A.$emit("insertDividerAfter"))},[oe(de,{name:"insert-below"}),C[59]||(C[59]=h("span",null,"下方分页",-1))]),h("button",{class:"spm-btn-action b3-tooltips b3-tooltips__se","aria-label":n.value==="three-cols-header"?"将当前块属性设为三栏第1栏归属":"将当前块属性设为双栏左侧归属",onClick:C[22]||(C[22]=x=>A.$emit("setTwoColsContrast"))},[oe(de,{name:"columns"}),h("span",null,we(n.value==="three-cols-header"?"设为第1栏":"设为双栏"),1)],8,s0),e.hasBlockAttrs?(J(),ee("button",{key:0,class:"spm-btn-action spm-btn-danger b3-tooltips b3-tooltips__sw","aria-label":"一键移除本块所有 custom-slides 属性",onClick:C[23]||(C[23]=x=>A.$emit("clearBlockAttrs"))},[oe(de,{name:"broom"}),C[60]||(C[60]=h("span",null,"清除属性",-1))])):Te("",!0)])])])}}}),r0={class:"spm-section spm-section--doc"},a0={class:"spm-card-control"},l0={class:"spm-control-header"},c0={class:"spm-control-title-group"},d0={class:"spm-control-title"},u0={class:"spm-segmented-group"},f0=["aria-label","onClick"],p0={class:"spm-card-control"},h0={class:"spm-control-header"},m0={class:"spm-control-title-group"},g0={class:"spm-control-title"},v0={class:"spm-quick-chips"},b0=["onClick"],y0=["value"],k0={class:"spm-card-control"},w0={class:"spm-control-header"},x0={class:"spm-control-title-group"},S0={class:"spm-control-title"},C0={class:"spm-segmented-group"},_0={class:"spm-card-control"},$0={class:"spm-control-header"},I0={class:"spm-control-title-group"},M0={class:"spm-control-title"},T0={class:"spm-segmented-group"},E0={class:"spm-card-control"},A0={class:"spm-control-header"},B0={class:"spm-control-title-group"},D0={class:"spm-control-title"},L0={class:"spm-card-control"},P0={class:"spm-control-header"},O0={class:"spm-control-title-group"},R0={class:"spm-control-title"},N0=["aria-label"],z0=["checked"],H0={key:0,class:"spm-control-body",style:{"margin-top":"8px"}},F0=["value"],j0={class:"spm-card-control"},W0={class:"spm-control-header"},U0={class:"spm-control-title-group"},V0={class:"spm-control-title"},G0=["aria-label"],K0=["checked"],q0={class:"spm-card-control"},Y0={class:"spm-control-header"},Z0={class:"spm-control-title-group"},J0={class:"spm-control-title"},X0={class:"spm-list-markers-toggles",style:{display:"flex",gap:"8px","margin-top":"8px"}},Q0={class:"spm-marker-toggle-item",style:{flex:"1",display:"flex","align-items":"center","justify-content":"space-between",padding:"6px 10px",background:"var(--b3-theme-surface)",border:"1px solid var(--b3-border-color)","border-radius":"4px"}},ek=["aria-label"],tk=["checked"],ik={class:"spm-marker-toggle-item",style:{flex:"1",display:"flex","align-items":"center","justify-content":"space-between",padding:"6px 10px",background:"var(--b3-theme-surface)",border:"1px solid var(--b3-border-color)","border-radius":"4px"}},nk=["aria-label"],sk=["checked"],ok={class:"spm-card-control"},rk={class:"spm-action-grid"},ak=["disabled"],lk=["disabled"],ck=["disabled","aria-label"],dk=Dt({__name:"DocInspectorSection",props:{docTheme:{},docBackground:{},docAspectRatio:{},docDefaultTransition:{},docSpacing:{},isExportingImages:{type:Boolean},isBatchProcessing:{type:Boolean}},emits:["update:docTheme","update:docBackground","update:docAspectRatio","update:docDefaultTransition","update:docSpacing","openBottomPreview","openPresenter","identifyNotes","autoAnimate","aiAutoSplit","clearDividers","exportHtml","exportPdf","exportImages"],setup(e){const t=zt("plugin"),i=Vt,n=[{value:"default",label:"默认 default",desc:"官方默认科技风：现代无衬线排版与清新代码语法高亮，通用汇报与技术分享首选"},{value:"seriph",label:"优雅 seriph",desc:"典雅学术衬线风：书卷学术质感、衬线字体典雅庄重，适合学术论文、人文讲座与深度阅读"},{value:"apple-basic",label:"极简 apple",desc:"苹果发布会极简风：大字号、高对比度与极致留白，适合产品发布、方案演讲与纯粹视觉呈现"}];function s(f){ri({enableWebServeJump:f}),t&&typeof t.saveGlobalSettings=="function"&&t.saveGlobalSettings({enableWebServeJump:f})}async function o(f){var d;ri({normalizeHeadingSizes:f}),t&&typeof t.saveGlobalSettings=="function"&&await t.saveGlobalSettings({normalizeHeadingSizes:f}),t&&typeof t.compileCurrentDocument=="function"&&t.compileCurrentDocument(t.currentDocId||((d=t.getActiveDocumentId)==null?void 0:d.call(t)))}async function a(f){var d;ri({showUnorderedListMarkers:f}),t&&typeof t.saveGlobalSettings=="function"&&await t.saveGlobalSettings({showUnorderedListMarkers:f}),t&&typeof t.compileCurrentDocument=="function"&&t.compileCurrentDocument(t.currentDocId||((d=t.getActiveDocumentId)==null?void 0:d.call(t)))}async function r(f){var d;ri({showOrderedListMarkers:f}),t&&typeof t.saveGlobalSettings=="function"&&await t.saveGlobalSettings({showOrderedListMarkers:f}),t&&typeof t.compileCurrentDocument=="function"&&t.compileCurrentDocument(t.currentDocId||((d=t.getActiveDocumentId)==null?void 0:d.call(t)))}function l(f){ri({webServeUrl:f})}function c(f){ri({webServeUrl:f}),t&&typeof t.saveGlobalSettings=="function"&&t.saveGlobalSettings({webServeUrl:f})}const u=[{label:"默认",value:""},{label:"极简白",value:"#ffffff"},{label:"柔和灰",value:"#f8fafc"},{label:"暗黑 #1e1e24",value:"#1e1e24"},{label:"极夜 #0f172a",value:"#0f172a"},{label:"雅蓝渐变",value:"linear-gradient(135deg, #1e293b 0%, #0f172a 100%)"},{label:"极光渐变",value:"linear-gradient(135deg, #0f172a 0%, #1e1b4b 100%)"},{label:"晨雾渐变",value:"linear-gradient(135deg, #f8fafc 0%, #e2e8f0 100%)"}];return(f,d)=>(J(),ee("div",r0,[d[58]||(d[58]=h("div",{class:"spm-section-header"},[h("span",null,"全局演示配置")],-1)),h("div",a0,[h("div",l0,[h("div",c0,[h("div",d0,[oe(de,{name:"palette"}),d[26]||(d[26]=h("span",null,"幻灯片主题",-1))]),d[27]||(d[27]=h("span",{class:"spm-control-desc"},"全局幻灯片视觉设计范式",-1))])]),h("div",u0,[(J(),ee(Xe,null,St(n,p=>h("button",{key:p.value,class:Ce(["spm-segmented-item b3-tooltips b3-tooltips__s",{active:e.docTheme===p.value}]),"aria-label":p.desc,onClick:w=>f.$emit("update:docTheme",p.value)},we(p.label),11,f0)),64))])]),h("div",p0,[h("div",h0,[h("div",m0,[h("div",g0,[oe(de,{name:"palette"}),d[28]||(d[28]=h("span",null,"演示背景",-1))]),d[29]||(d[29]=h("span",{class:"spm-control-desc"},"全篇幻灯片统一底色、微渐变或壁纸",-1))])]),h("div",v0,[(J(),ee(Xe,null,St(u,p=>h("button",{key:p.value,class:Ce(["spm-chip",{active:(e.docBackground||"")===p.value}]),onClick:w=>f.$emit("update:docBackground",p.value)},we(p.label),11,b0)),64))]),h("input",{value:e.docBackground||"",class:"spm-input",placeholder:"自定义颜色 (#1e1e24)、渐变或资源路径 (assets/...)",onInput:d[0]||(d[0]=p=>f.$emit("update:docBackground",p.target.value)),onChange:d[1]||(d[1]=p=>f.$emit("update:docBackground",p.target.value))},null,40,y0)]),h("div",k0,[h("div",w0,[h("div",x0,[h("div",S0,[oe(de,{name:"ratio"}),d[30]||(d[30]=h("span",null,"画幅比例",-1))]),d[31]||(d[31]=h("span",{class:"spm-control-desc"},"演讲屏幕投影宽高比",-1))])]),h("div",C0,[h("button",{class:Ce(["spm-segmented-item",{active:e.docAspectRatio==="16/9"}]),onClick:d[2]||(d[2]=p=>f.$emit("update:docAspectRatio","16/9"))}," 16 : 9 (宽屏) ",2),h("button",{class:Ce(["spm-segmented-item",{active:e.docAspectRatio==="4/3"}]),onClick:d[3]||(d[3]=p=>f.$emit("update:docAspectRatio","4/3"))}," 4 : 3 (标屏) ",2),h("button",{class:Ce(["spm-segmented-item",{active:e.docAspectRatio==="16/10"}]),onClick:d[4]||(d[4]=p=>f.$emit("update:docAspectRatio","16/10"))}," 16 : 10 ",2)])]),h("div",_0,[h("div",$0,[h("div",I0,[h("div",M0,[oe(de,{name:"ratio"}),d[32]||(d[32]=h("span",null,"间距风格",-1))]),d[33]||(d[33]=h("span",{class:"spm-control-desc"},"内边距与顶部标题下边距预设",-1))])]),h("div",T0,[h("button",{class:Ce(["spm-segmented-item b3-tooltips b3-tooltips__se",{active:(e.docSpacing||"normal")==="compact"}]),"aria-label":"紧凑排版：上下 20px / 左右 36px",onClick:d[5]||(d[5]=p=>f.$emit("update:docSpacing","compact"))}," 紧凑 ",2),h("button",{class:Ce(["spm-segmented-item b3-tooltips b3-tooltips__s",{active:(e.docSpacing||"normal")==="normal"}]),"aria-label":"标准排版：上下 32px / 左右 48px（推荐默认）",onClick:d[6]||(d[6]=p=>f.$emit("update:docSpacing","normal"))}," 标准 ",2),h("button",{class:Ce(["spm-segmented-item b3-tooltips b3-tooltips__sw",{active:(e.docSpacing||"normal")==="loose"}]),"aria-label":"宽松排版：上下 48px / 左右 56px",onClick:d[7]||(d[7]=p=>f.$emit("update:docSpacing","loose"))}," 宽松 ",2)])]),h("div",E0,[h("div",A0,[h("div",B0,[h("div",D0,[oe(de,{name:"transition"}),d[34]||(d[34]=h("span",null,"全局默认转场",-1))]),d[35]||(d[35]=h("span",{class:"spm-control-desc"},"页面切换过渡动效（未单设转场的页面将继承此动效）",-1))])]),oe(lc,{"model-value":e.docDefaultTransition,"hide-header":!0,onChange:d[8]||(d[8]=p=>f.$emit("update:docDefaultTransition",p))},null,8,["model-value"])]),h("div",L0,[h("div",P0,[h("div",O0,[h("div",R0,[oe(de,{name:"external-link"}),d[36]||(d[36]=h("span",null,"本地网络伺服预览",-1))]),d[37]||(d[37]=h("span",{class:"spm-control-desc"},"点击文档/块链接以 Webview 抽屉呈现，支持外跳",-1))]),h("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":he(i).enableWebServeJump?"关闭本地网络伺服预览":"开启本地网络伺服预览"},[h("input",{type:"checkbox",checked:he(i).enableWebServeJump,onChange:d[9]||(d[9]=p=>s(p.target.checked))},null,40,z0),d[38]||(d[38]=h("span",{class:"spm-switch-slider"},null,-1))],8,N0)]),he(i).enableWebServeJump?(J(),ee("div",H0,[h("input",{value:he(i).webServeUrl,class:"spm-input",placeholder:"http://127.0.0.1:6806",spellcheck:"false",onKeydown:d[10]||(d[10]=Zt(()=>{},["stop"])),onKeyup:d[11]||(d[11]=Zt(()=>{},["stop"])),onInput:d[12]||(d[12]=p=>l(p.target.value)),onChange:d[13]||(d[13]=p=>c(p.target.value))},null,40,F0),d[39]||(d[39]=h("span",{class:"spm-control-desc",style:{display:"block","margin-top":"4px","font-size":"11px",opacity:"0.8"}}," 默认伺服地址为 http://127.0.0.1:6806。开启后点击块链接将在 Webview 抽屉中打开，点击抽屉顶部『外跳』可在外部浏览器打开 ",-1))])):Te("",!0)]),h("div",j0,[h("div",W0,[h("div",U0,[h("div",V0,[oe(de,{name:"type"}),d[40]||(d[40]=h("span",null,"固定特定标题大小",-1))]),d[41]||(d[41]=h("span",{class:"spm-control-desc"},"除封面外页首标题按 H2、多栏内首标题按 H3 大小展示",-1))]),h("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":he(i).normalizeHeadingSizes?"关闭固定特定标题大小":"开启固定特定标题大小"},[h("input",{type:"checkbox",checked:he(i).normalizeHeadingSizes,onChange:d[14]||(d[14]=p=>o(p.target.checked))},null,40,K0),d[42]||(d[42]=h("span",{class:"spm-switch-slider"},null,-1))],8,G0)])]),h("div",q0,[h("div",Y0,[h("div",Z0,[h("div",J0,[oe(de,{name:"list"}),d[43]||(d[43]=h("span",null,"列表前缀标记",-1))]),d[44]||(d[44]=h("span",{class:"spm-control-desc"},"分别控制正文中无序列表圆点与有序列表数字序号的呈现",-1))])]),h("div",X0,[h("div",Q0,[d[46]||(d[46]=h("span",{style:{"font-size":"12px",color:"var(--b3-theme-on-surface)"}},"无序圆点",-1)),h("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":he(i).showUnorderedListMarkers?"关闭无序列表圆点显示":"开启无序列表圆点显示"},[h("input",{type:"checkbox",checked:he(i).showUnorderedListMarkers,onChange:d[15]||(d[15]=p=>a(p.target.checked))},null,40,tk),d[45]||(d[45]=h("span",{class:"spm-switch-slider"},null,-1))],8,ek)]),h("div",ik,[d[48]||(d[48]=h("span",{style:{"font-size":"12px",color:"var(--b3-theme-on-surface)"}},"有序序号",-1)),h("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":he(i).showOrderedListMarkers?"关闭有序列表序号显示":"开启有序列表序号显示"},[h("input",{type:"checkbox",checked:he(i).showOrderedListMarkers,onChange:d[16]||(d[16]=p=>r(p.target.checked))},null,40,sk),d[47]||(d[47]=h("span",{class:"spm-switch-slider"},null,-1))],8,nk)])])]),h("div",ok,[d[57]||(d[57]=h("div",{class:"spm-control-header"},[h("div",{class:"spm-control-title-group"},[h("span",{class:"spm-control-title"},"演示全局操作")])],-1)),h("div",rk,[h("button",{class:"spm-btn-action b3-tooltips b3-tooltips__sw","aria-label":"在当前文档下方开启分屏同步预览 (Alt+P)",onClick:d[17]||(d[17]=p=>f.$emit("openBottomPreview"))},[oe(de,{name:"split-preview"}),d[49]||(d[49]=h("span",null,"分屏预览",-1))]),he(gt)("presenterMode")?(J(),ee("button",{key:0,class:"spm-btn-action b3-tooltips b3-tooltips__sw","aria-label":"打开双屏演讲者控制台视窗 (Alt+M)",onClick:d[18]||(d[18]=p=>f.$emit("openPresenter"))},[oe(de,{name:"presenter"}),d[50]||(d[50]=h("span",null,"演讲者视图",-1))])):Te("",!0),h("button",{class:"spm-btn-action b3-tooltips b3-tooltips__sw","aria-label":"识别各页分隔线前未设属性的提示块/引用块为标准讲稿备注",disabled:e.isBatchProcessing,onClick:d[19]||(d[19]=p=>f.$emit("identifyNotes"))},[oe(de,{name:"notes"}),d[51]||(d[51]=h("span",null,"识别讲稿块",-1))],8,ak),h("button",{class:"spm-btn-action b3-tooltips b3-tooltips__sw","aria-label":"自动为正文各页标题及首块之外的后续内容块配置顺延 (+1) 逐步呈现动效",disabled:e.isBatchProcessing,onClick:d[20]||(d[20]=p=>f.$emit("autoAnimate"))},[oe(de,{name:"step"}),d[52]||(d[52]=h("span",null,"智能动效",-1))],8,lk),he(gt)("aiScript")?(J(),ee("button",{key:1,class:"spm-btn-action b3-tooltips b3-tooltips__se","aria-label":"智能分析长文本大纲与篇幅，自动插入分页线",onClick:d[21]||(d[21]=p=>f.$emit("aiAutoSplit"))},[oe(de,{name:"sparkles"}),d[53]||(d[53]=h("span",null,"智能分页",-1))])):Te("",!0),he(gt)("aiScript")?(J(),ee("button",{key:2,class:"spm-btn-action b3-tooltips b3-tooltips__sw","aria-label":"一键清除当前文档中的所有幻灯片分页线",onClick:d[22]||(d[22]=p=>f.$emit("clearDividers"))},[oe(de,{name:"trash"}),d[54]||(d[54]=h("span",null,"清除分页",-1))])):Te("",!0),he(gt)("exportHtml")?(J(),ee("button",{key:3,class:"spm-btn-action b3-tooltips b3-tooltips__sw","aria-label":"打包导出离线单文件 HTML 幻灯片",onClick:d[23]||(d[23]=p=>f.$emit("exportHtml"))},[oe(de,{name:"export-html"}),d[55]||(d[55]=h("span",null,"导出 HTML",-1))])):Te("",!0),he(gt)("exportPdf")?(J(),ee("button",{key:4,class:"spm-btn-action b3-tooltips b3-tooltips__se","aria-label":"打印生成 16:9 高清演示 PDF 讲义",onClick:d[24]||(d[24]=p=>f.$emit("exportPdf"))},[oe(de,{name:"export-pdf"}),d[56]||(d[56]=h("span",null,"导出 PDF",-1))])):Te("",!0),he(gt)("exportImage")?(J(),ee("button",{key:5,class:Ce(["spm-btn-action b3-tooltips b3-tooltips__s",{"is-loading":e.isExportingImages}]),disabled:e.isExportingImages,"aria-label":e.isExportingImages?"正在逐页导出高清图片包，请稍候...":"逐页导出高清图片包 (ZIP)",onClick:d[25]||(d[25]=p=>f.$emit("exportImages"))},[oe(de,{name:"export-image"}),h("span",null,we(e.isExportingImages?"正在导出...":"导出图片"),1)],10,ck)):Te("",!0)])])]))}}),uk=/\.(?:png|jpe?g|gif|svg|webp|avif|ico|bmp|tiff?|mp4|webm|mp3|wav|ogg)$/i,fk=/\.(?:ts|js|mjs|cjs|jsx|tsx|vue|json|css|scss|less|html|py|rs|go|java|c|cpp|h|sh|bash|yaml|yml|toml)$/i;async function pk(e){const t=await tc.loadAsync(e),i={},n=[];let s="",o="";const a=[];t.forEach((l,c)=>{!c.dir&&!l.startsWith("__MACOSX")&&!l.includes("node_modules/")&&a.push({path:l,file:c})});let r=a.find(l=>l.path.toLowerCase()==="slides.md");r||(r=a.find(l=>l.path.toLowerCase().endsWith("/slides.md"))),r||(r=a.find(l=>l.path.toLowerCase().endsWith(".md"))),r&&(s=await r.file.async("string"),o=r.path);for(const l of a){const c=l.path;if(c.toLowerCase().endsWith(".md")||fk.test(c)||c.includes("snippets/")){const u=await l.file.async("string");i[c]=u;const f=c.split("/");f.length>1&&(i[f.slice(1).join("/")]=u)}else if(uk.test(c)){const u=await l.file.async("uint8array"),f=c.split("/").pop()||c,d=typeof Blob<"u"?new Blob([u]):void 0;n.push({zipPath:c,fileName:f,data:u,blob:d})}}return{entryMarkdown:s,entryMarkdownPath:o,virtualFiles:i,assets:n}}function hk(e,t){if(Object.keys(t).length===0)return e;function i(s){const o=s.trim().replace(/^['"]|['"]$/g,""),a=o.split("/").pop()||o;if(t[o])return t[o];const r=o.replace(/^\.?\//,"");return t[r]?t[r]:t[a]?t[a]:null}function n(s){let o=s;return o=o.replace(/!\[(.*?)\]\((.*?)\)/g,(a,r,l)=>{const c=i(l);return c?`![${r}](${c})`:a}),o=o.replace(/\bsrc=["'](.*?)["']/gi,(a,r)=>{const l=i(r);return l?`src="${l}"`:a}),o}for(const s of e.slides)if(s.rawMarkdown=n(s.rawMarkdown),s.pageAttrs["custom-slides-background"]){const o=s.pageAttrs["custom-slides-background"],a=i(o);a&&(s.pageAttrs["custom-slides-background"]=a)}if(e.flattenedMarkdown=n(e.flattenedMarkdown),e.docRootAttrs["custom-slides-background"]){const s=e.docRootAttrs["custom-slides-background"],o=i(s);o&&(e.docRootAttrs["custom-slides-background"]=o)}return e}function cc(e){try{if(typeof process<"u"&&typeof require<"u"){const t=require("fs");if(t.existsSync(e))return t.readFileSync(e,"utf-8")}}catch{}return null}function mk(e,t){const i=e.match(/^[ \t]*<<<[ \t]+([^\s]+)/);if(!i)return null;const n=i[1].trim(),s=n.indexOf("#"),o=s!==-1?n.slice(0,s):n,a=s!==-1?n.slice(s+1):"",r=o.replace(/^@\//,"").replace(/^\.\//,""),l=(t==null?void 0:t.virtualFiles)||{};let c=l[o]||l[r]||l[`./${r}`]||l[`@/${r}`];if(!c&&Object.keys(l).length>0){const p=r.split("/").pop();for(const[w,m]of Object.entries(l))if(w.endsWith(`/${r}`)||p&&w.endsWith(`/${p}`)){c=m;break}}if(!c){const p=[];if(t!=null&&t.baseDir)try{const w=require("path");p.push(w.resolve(t.baseDir,r)),p.push(w.resolve(t.baseDir,o))}catch{}try{const w=require("path");p.push(w.resolve(process.cwd(),r))}catch{}for(const w of p){const m=cc(w);if(m!==null){c=m;break}}}if(!c){const p=Vl||{};if(c=p[o]||p[r]||p[`snippets/${r}`],!c){const w=r.split("/").pop();for(const[m,b]of Object.entries(p))if(m.endsWith(`/${r}`)||w&&m.endsWith(`/${w}`)){c=b;break}}}if(!c)return null;let u=c;if(a){const p=new RegExp(`(?:\\/\\/|\\/\\*|#)?\\s*#(?:region|REGION)\\s+${a}[^\\r\\n]*\\r?\\n([\\s\\S]*?)(?:\\/\\/|\\/\\*|#)?\\s*#(?:endregion|ENDREGION)\\s+${a}`,"i"),w=c.match(p);if(w){const m=c.match(/^(\/\/\s*Inside[^\r\n]+\r?\n)/i);u=(m?m[1]:"")+w[1].trimEnd()}}const f=r.match(/\.([a-zA-Z0-9]+)$/);return`\`\`\`${f?f[1]:""}
${u}
\`\`\``}function gk(e){let t=!1,i=!1;for(let n=0;n<e.length;n++){const s=e[n];if(s==="'"&&!i)t=!t;else if(s==='"'&&!t)i=!i;else if(s==="#"&&!t&&!i)return e.slice(0,n).trim()}return e.trim()}function gs(e){const t={},i=e.split(/\r?\n/);let n=0;for(;n<i.length;){const s=i[n],o=s.trim();if(!o||o.startsWith("#")){n++;continue}const a=s.indexOf(":");if(a>0){const r=s.slice(0,a).trim();let l=s.slice(a+1).trim();if(l==="|"||l===">"){n++;const c=[];let u=-1;for(;n<i.length;){const f=i[n];if(!f.trim()){c.push(""),n++;continue}const p=f.match(/^(\s+)/),w=p?p[1].length:0;if(u===-1&&(u=w),w<u)break;c.push(f.slice(u)),n++}for(;c.length>0&&c[c.length-1]==="";)c.pop();t[r]=l===">"?c.join(" "):c.join(`
`);continue}if(l=gk(l),!l){let c=n+1;const u=[];let f=-1;for(;c<i.length;){const d=i[c],p=d.trim();if(!p||p.startsWith("#")){f!==-1&&u.push(""),c++;continue}const w=d.match(/^(\s+)/),m=w?w[1].length:0;if(f===-1)if(m>0)f=m;else break;if(m<f)break;u.push(d.slice(f)),c++}if(u.length>0){t[r]=gs(u.join(`
`)),n=c;continue}}l.startsWith('"')&&l.endsWith('"')||l.startsWith("'")&&l.endsWith("'")?l=l.slice(1,-1):l==="true"?l=!0:l==="false"?l=!1:l==="null"?l=null:/^-?\d+(?:\.\d+)?$/.test(l)&&(l=Number(l)),t[r]=l}n++}return t}const vk=/^\s*```ya?ml([\s\S]*?)```/;function va(e){let t={},i=e.trim();const n=i.match(/^---[^\n\r]*\r?\n([\s\S]*?)\r?\n---(?=[ \t]*(?:\r?\n|$))/);if(n&&!n[1].includes("```")){const o=gs(n[1]);if(Object.keys(o).length>0||!n[1].trim())return t=o,i=i.slice(n[0].length).trim(),{frontmatter:t,content:i}}if(i.startsWith("---")){const o=i.match(/^---[^\n\r]*(?:\r?\n|$)/);o&&(i=i.slice(o[0].length).trim())}const s=i.match(vk);if(s)t=gs(s[1]),i=i.slice(s[0].length).trim();else{const o=i.split(/\r?\n/),a=[];let r=0;for(let l=0;l<o.length;l++){const c=o[l].trim();if(!c){if(a.length>0){r=l+1;break}continue}if(/^[a-zA-Z0-9_-]+\s*:\s*.*/.test(c)&&!c.startsWith("<")&&!c.startsWith("#"))a.push(c);else{r=l;break}}a.length>0&&(t=gs(a.join(`
`)),i=o.slice(r).join(`
`).trim())}return{frontmatter:t,content:i}}function bk(e){const t=e.split(/\r?\n/),i=[];let n=0,s=!1;function o(a){if(n>=a)return;const r=t.slice(n,a).join(`
`).trim();r&&i.push(r),n=a+1}for(let a=0;a<t.length;a++){const l=t[a].trimEnd();if(s){l.includes("-->")&&(s=!1);continue}if(l.startsWith("<!--")){l.includes("-->")||(s=!0);continue}if(l.startsWith("---")){o(a);const c=t[a+1];let u=!1,f=-1;const d=c?c.trim():"";if(l.replace(/^-+/,"").trim()===""&&d.length>0){for(let p=a+1;p<t.length;p++){const w=t[p].trimEnd();if(w.startsWith("```"))break;if(w==="---"){f=p;break}}f!==-1&&f-a<=60&&t.slice(a+1,f).some(m=>{const b=m.trim();return b.length>0&&!b.startsWith("#")&&/^[a-zA-Z0-9_$-]+\s*:\s*.*/.test(b)})&&(u=!0)}u&&f!==-1&&(n=a,a=f)}else if(l.trimStart().startsWith("```")){const c=l.match(/^\s*`+/),u=c?c[0].trim():"```";let f=a+1;for(;f<t.length&&!t[f].trimStart().startsWith(u);f++);f<t.length&&(a=f)}}return n<t.length&&o(t.length),i}function vs(e,t={}){const{stripNotesFromMarkdown:i=!0,cleanVClicks:n=!0,cleanShikiLines:s=!0,cleanSlots:o=!0,isolateStyleTags:a=!0,cleanHtmlToMarkdown:r=!0,wrapSuperBlocks:l=!0,virtualFiles:c={}}=t;let u=e;u&&!u.trimStart().startsWith("---")&&(u=`---

${u.trimStart()}`);const f=bk(u),d={};let p="",w="",m=0;if(f.length>0){const N=f[0],K=va(N),_=Object.keys(K.frontmatter).length>0,U=K.content.length>0;_&&!U&&f.length>1?(m=1,b(K.frontmatter)):_&&b(K.frontmatter)}function b(N){p=N.title||"",N.theme&&(d[zn]=String(N.theme)),N.aspectRatio&&(d[Hn]=String(N.aspectRatio)),N.highlighter&&(d[Ia]=String(N.highlighter)),N.transition&&(d[Fn]=String(N.transition)),N.colorSchema&&(d[Ma]=String(N.colorSchema)),N.layout&&(d[ke]=String(N.layout)),N.background&&(d[st]=String(N.background)),N.image&&(d[Rt]=String(N.image)),N.class&&(d[en]=String(N.class));for(const[K,_]of Object.entries(N))["theme","aspectRatio","highlighter","transition","colorSchema","title","layout","background","image","class"].includes(K)||(d[`custom-slides-${K}`]=typeof _=="object"?JSON.stringify(_):String(_))}const y=[];let v=0,k=0,S=0,B=0;const A=new Set,C={};let L=1;for(let N=m;N<f.length;N++){const K=f[N],{frontmatter:_,content:U}=va(K),x=K.match(/^\s*(?:---\s*)?src:\s*([^\n\r]+)/m),q=_.src||(x?x[1]:void 0);if(q){const fe=String(q).trim().replace(/^['"]|['"]$/g,"");let X=c[fe]||c[fe.replace(/^\.\//,"")]||c[`pages/${fe.replace(/^.*pages\//,"")}`];if(!X){const E=fe.replace(/^\.\//,""),F=[];if(t.baseDir)try{const g=require("path");F.push(g.resolve(t.baseDir,E)),F.push(g.resolve(t.baseDir,fe))}catch{}try{const g=require("path");F.push(g.resolve(process.cwd(),E)),F.push(g.resolve(process.cwd(),fe))}catch{}for(const g of F){const W=cc(g);if(W!==null){X=W;break}}}const pe={};_.layout&&(pe[ke]=String(_.layout)),_.transition&&(pe[vt]=String(_.transition)),_.background&&(pe[st]=String(_.background)),_.image&&(pe[Rt]=String(_.image)),_.class&&(pe[en]=String(_.class));for(const[E,F]of Object.entries(_))["src","layout","transition","background","image","class"].includes(E)||(pe[`custom-slides-${E}`]=typeof F=="object"?JSON.stringify(F):String(F));if(X){const E=vs(X,{...t,virtualFiles:c});for(const F of E.slides){F.pageIndex=L++,F.pageAttrs={...pe,...F.pageAttrs},y.push(F);const g=F.pageAttrs[ke]||"default";C[g]=(C[g]||0)+1}continue}else{y.push({pageIndex:L++,pageAttrs:{...pe,"custom-slides-src":fe},notes:"",rawMarkdown:`> 📄 **引入外部幻灯片页面**: \`${fe}\`
>
> *提示：如需展示该页面完整内容，请将关联子页面一同打包为 .zip 或通过本地工程导入。*`,hasVueComponent:!1,hasStyleTag:!1,assetReferences:[]});const E=pe[ke]||"default";C[E]=(C[E]||0)+1;continue}}const O={};_.layout&&(O[ke]=String(_.layout)),_.transition&&(O[vt]=String(_.transition)),_.background&&(O[st]=String(_.background)),_.image&&(O[Rt]=String(_.image)),_.class&&(O[en]=String(_.class)),_.mask&&(O[tn]=String(_.mask)),(_.maskRatio||_["mask-ratio"])&&(O[ji]=String(_.maskRatio||_["mask-ratio"])),(_.maskStyle||_["mask-style"])&&(O[nn]=String(_.maskStyle||_["mask-style"])),(_.maskInitial||_["mask-initial"])&&(O[sn]=String(_.maskInitial||_["mask-initial"]));for(const[fe,X]of Object.entries(_))["layout","transition","background","image","class","mask","maskRatio","mask-ratio","maskStyle","mask-style","maskInitial","mask-initial"].includes(fe)||(O[`custom-slides-${fe}`]=typeof X=="object"?JSON.stringify(X):String(X));let $=U;const T=[];let P=$.replace(/(?:^[ \t]*(`{3,}|~{3,})[^\n\r]*\r?\n[\s\S]*?\r?\n[ \t]*\1(?=[ \t]*(?:\r?\n|$)))/gm,fe=>{const X=`__CODE_TOKEN_NOTE_${T.length}__`;return T.push(fe),X});P=P.replace(/(`+)(?:[^\n\r`]|(?!\1)`)+?\1/g,fe=>{const X=`__CODE_TOKEN_NOTE_${T.length}__`;return T.push(fe),X});let se="";const V=Array.from(P.matchAll(/<!--([\s\S]*?)-->/g));if(V.length>0){const fe=V[V.length-1],X=P.slice(fe.index+fe[0].length).trim();if(!X||!X.replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi,"").trim()){const E=fe[1].trim();E.startsWith("TODO:")||(se=E,v++),i&&(P=P.slice(0,fe.index).trimEnd()+P.slice(fe.index+fe[0].length))}}i&&(P=P.replace(/<!--(?![\s\S]*?TODO:)[\s\S]*?-->/g,"").trim());for(let fe=0;fe<T.length;fe++)P=P.replace(`__CODE_TOKEN_NOTE_${fe}__`,()=>T[fe]);if($=P,se){for(let pe=0;pe<T.length;pe++)se=se.replace(`__CODE_TOKEN_NOTE_${pe}__`,()=>T[pe]);const X=`> [!NOTE] 💡 演讲备注
${se.split(/\r?\n/).map(pe=>`> ${pe}`).join(`
`)}
{: custom-slides-note="true"}`;$=$?`${$}

${X}`:X}let Y=!1;if(/<style\b/i.test($)){Y=!0;const fe=$.match(/<style\b[^>]*>([\s\S]*?)<\/style>/gi);if(fe){for(const X of fe){const pe=X.replace(/<style\b[^>]*>|<\/style>/gi,"").trim();w=w?`${w}

${pe}`:pe}a&&($=$.replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi,"").trim())}}const ce=$.match(/<v-click[^>]*>|<v-clicks[^>]*>|v-click=/g);ce&&(k+=ce.length);const ie=$.match(/```\w+\s+\{[^}]+\}/g);ie&&(S+=ie.length);const re=$.match(/::\w+::|<template\s+#[^>]+>/g);if(re&&(B+=re.length),$=$.replace(/^[ \t]*<<<[ \t]+([^\n\r]+)/gm,fe=>mk(fe,{...t,virtualFiles:c})||fe),n&&($=$.replace(/<v-click(?:\s+at="[^"]*")?(?:\s+hide)?>\s*([\s\S]*?)\s*<\/v-click>/gi,"$1")),s&&($=$.replace(/(^```\w+(?:[ \t]+\[[^\]]*\])?)[ \t]+\{[^}]+\}(?:[ \t]+\w+)?/gm,"$1"),$=$.replace(/^\$\$\s+\{[^}]+\}/gm,()=>"$$")),o&&($=$.replace(/^::\w+::\s*$/gm,"")),r&&($=rp($)),l){let fe=$.trim(),X="";const pe=fe.lastIndexOf("> [!NOTE] 💡 演讲备注");if(pe!==-1&&(X=fe.slice(pe),fe=fe.slice(0,pe).trim()),(_.layout==="image-left"||_.layout==="image-right")&&_.image){const E=String(_.image).trim(),F=_.layout==="image-left"?"image-left":"image-right",g=`![配图](${E})
{: custom-slides-layout="${F}" }`;_.layout==="image-left"?fe=`{{{col

${g}

${fe}

}}}`:fe=`{{{col

${fe}

${g}

}}}`}if(_.background){const F=`![背景图](${String(_.background).trim()})
{: custom-slides-role="background" }`;fe=fe?`${F}

${fe}`:F}$=X?`${fe}

${X}`:fe}const Se=yk($);O[st]&&Se.push(O[st]),O[Rt]&&Se.push(O[Rt]);for(const fe of Se)A.add(fe);const Ie=/<[A-Z][a-zA-Z0-9]+/.test($),_e=O[ke]||(L===1?d[ke]||"cover":"default");C[_e]=(C[_e]||0)+1,y.push({pageIndex:L++,pageAttrs:O,notes:se,rawMarkdown:$,hasVueComponent:Ie,hasStyleTag:Y,assetReferences:Se})}if(!p&&y.length>0){const N=y[0].rawMarkdown.match(/^#\s+(.+)$/m);N&&(p=N[1].trim())}w&&(d["custom-slides-custom-css"]=w);let z=y.map(N=>`---

${N.rawMarkdown}`).join(`

`);return z.trimStart().startsWith("---")||(z=`---

${z.trimStart()}`),{docTitle:p||"Slidev 演示文稿",docRootAttrs:d,slides:y,totalSlides:y.length,stats:{totalNotes:v,totalVClicks:k,totalShikiHighlights:S,totalSlots:B,discoveredAssets:Array.from(A),layoutDistribution:C},flattenedMarkdown:z,customCss:w}}function yk(e){const t=[],i=/!\[.*?\]\((.*?)\)/g;let n;for(;(n=i.exec(e))!==null;){const o=n[1].split(/\s+/)[0].trim();o&&t.push(o)}const s=/<(?:img|video|source|audio)\b[^>]*src=["'](.*?)["']/gi;for(;(n=s.exec(e))!==null;){const o=n[1].trim();o&&t.push(o)}return t}function dc(e){if(!e)return!1;const t=String(e.type||"").toLowerCase(),i=String(e.markdown||"").trim(),n=String(e.content||"").trim();return t==="tb"||t==="thematic-break"||t==="nodethematicbreak"||i==="---"||i==="***"||n==="---"||n==="***"}function kk(e){return(e.trim()||"Slidev 演示文稿").replace(/[\\/:*?"<>|]/g,"_")}async function wk(e,t,i=Fe){const n=e.filter(dc);let s=0;if(n.length>=t.length)for(let o=0;o<t.length;o++){const a=t[o],r=n[o];r&&r.id&&Object.keys(a.pageAttrs||{}).length>0&&(await i(r.id,a.pageAttrs),s++)}else for(let o=1;o<t.length;o++){const a=t[o],r=n[o-1];r&&r.id&&Object.keys(a.pageAttrs||{}).length>0&&(await i(r.id,a.pageAttrs),s++)}return s}async function xk(e,t=Fe){let i=!1,n=0;for(const s of e){if(dc(s)){i=!1;continue}const o=(s.markdown||s.content||"").trim();if(o==="::right::"||o.startsWith("::right::")){i=!0;continue}i&&s.id&&(await t(s.id,{[Me]:"right"}).catch(()=>{}),n++)}return n}async function Sk(e,t,i=Sa){const n={};if(!t||t.length===0)return n;const s=[];for(const o of t){const a=new File([o.data],o.fileName,{type:"application/octet-stream"});s.push(a)}try{const o=await i("/data/assets",s);if(o!=null&&o.succMap)for(const[a,r]of Object.entries(o.succMap))n[a]=String(r)}catch(o){console.warn("上传本地静态资产失败，保留原路径:",o)}return Object.keys(n).length>0&&hk(e,n),n}async function Ck(e){var v;const{presentation:t,notebookId:i,docTitle:n,extractedAssets:s=[],uploadAssets:o=!0,autoPreview:a=!0,plugin:r,api:l={}}=e,c=l.uploadFn||Sa,u=l.createDocFn||gd,f=l.setAttrsFn||Fe,d=l.getChildBlocksFn||mn,p=l.openTabFn||ae.openTab,w=l.showMessageFn||ae.showMessage;o&&s.length>0&&await Sk(t,s,c);const m=kk(n),b=`/${m}`,y=await u(i,b,t.flattenedMarkdown);if(!y)throw new Error("思源内核创建文档失败，未返回有效 DocumentId");try{const k=((v=t.slides[0])==null?void 0:v.pageAttrs)||{};await f(y,{...k,...t.docRootAttrs});const S=await d(y).catch(()=>[]);Array.isArray(S)&&S.length>0&&(await wk(S,t.slides,f),await xk(S,f))}catch(k){console.warn("[SlidesImport] 版式属性回填阶段遇到警告:",k),w(`⚠️ 文档已创建(${m})，但部分版式属性回填未完全完成: ${k.message||String(k)}`,6e3)}return w(`🎉 成功导入 Slidev 演示文档《${m}》！`),a&&r&&(r.currentDocId=y,await p({app:r.app,doc:{id:y}}),r.openBottomPreviewTab&&r.openBottomPreviewTab()),y}function _k(e){const t=ge("file"),i=ge(!1),n=ge(!1),s=ge(""),o=ge(null),a=ge(null),r=ge(""),l=ge(0),c=ge(""),u=ge([]),f=ge(null),d=ge(""),p=ge([]),w=ge(""),m=ge(!0),b=ge(!0),y=ge(!0),v=ge(!0),k=ye(()=>{const $=l.value;if($===0)return"0 B";const T=1024,P=["B","KB","MB","GB"],se=Math.floor(Math.log($)/Math.log(T));return`${($/T**se).toFixed(1)} ${P[se]}`}),S=ye(()=>{var $;return(($=f.value)==null?void 0:$.docRootAttrs["custom-slides-theme"])||"default"}),B=ye(()=>{var $;return u.value.length>0?u.value.length:(($=f.value)==null?void 0:$.stats.discoveredAssets.length)||0}),A=ye(()=>{var T;const $=((T=f.value)==null?void 0:T.stats.layoutDistribution)||{};return Object.entries($).map(([P,se])=>({name:P,count:se}))});async function C($=md){try{const T=await $();T!=null&&T.notebooks&&Array.isArray(T.notebooks)&&(p.value=T.notebooks.filter(P=>!P.closed),p.value.length>0&&!w.value&&(w.value=p.value[0].id))}catch(T){console.warn("获取笔记本列表失败:",T)}}function L(){var $;($=o.value)==null||$.click()}function z(){a.value=null,r.value="",l.value=0,f.value=null,u.value=[],s.value=""}let N=0;async function K($){const T=++N;s.value="",a.value=$,r.value=$.name,l.value=$.size;try{if($.name.toLowerCase().endsWith(".zip")){const se=await $.arrayBuffer();if(T!==N)return;const V=await pk(se);if(T!==N)return;if(!V.entryMarkdown){s.value="未在 Zip 压缩包中找到 slides.md 或任何有效的 Markdown 入口文件";return}u.value=V.assets;const Y=vs(V.entryMarkdown,{stripNotesFromMarkdown:b.value,cleanHtmlToMarkdown:m.value,cleanSlots:!1,virtualFiles:V.virtualFiles});if(T!==N)return;f.value=Y,d.value=Y.docTitle||$.name.replace(/\.zip$/i,"")}else{const se=await $.text();if(T!==N)return;u.value=[];const V=$.path||"",Y=V?V.replace(/[\\/][^\\/]+$/,""):"",ce=vs(se,{stripNotesFromMarkdown:b.value,cleanHtmlToMarkdown:m.value,cleanSlots:!1,baseDir:Y||void 0});if(T!==N)return;f.value=ce,d.value=ce.docTitle||$.name.replace(/\.md$/i,"")}}catch(P){if(T!==N)return;console.error("解析文件失败:",P),s.value=`解析文件失败: ${P.message||String(P)}`}}function _(){if(s.value="",!c.value.trim()){f.value=null;return}try{const $=vs(c.value,{stripNotesFromMarkdown:b.value,cleanHtmlToMarkdown:m.value,cleanSlots:!1});f.value=$,d.value=$.docTitle||"Slidev 演示文稿"}catch($){s.value=`解析 Markdown 源码失败: ${$.message||String($)}`}}async function U(){a.value?await K(a.value):c.value&&_()}async function x($){const T=$.target;T.files&&T.files[0]&&await K(T.files[0])}async function q($){var T;i.value=!1,(T=$.dataTransfer)!=null&&T.files&&$.dataTransfer.files[0]&&await K($.dataTransfer.files[0])}async function O($=e){if(f.value){if(!w.value&&p.value.length>0&&(w.value=p.value[0].id),!w.value){s.value="请先选择目标笔记本";return}n.value=!0,s.value="";try{return await Ck({presentation:f.value,notebookId:w.value,docTitle:d.value,extractedAssets:u.value,uploadAssets:y.value,autoPreview:v.value,plugin:$})}catch(T){console.error("导入 Slidev 演示失败:",T),s.value=`导入执行失败: ${T.message||String(T)}`}finally{n.value=!1}}}return{inputMode:t,isDragging:i,isImporting:n,errorMessage:s,fileInputRef:o,selectedFile:a,selectedFileName:r,selectedFileSize:l,rawMarkdownText:c,extractedAssets:u,parsedPresentation:f,customDocTitle:d,notebooks:p,selectedNotebookId:w,optCleanHtml:m,optStripNotes:b,optUploadAssets:y,optAutoPreview:v,formattedFileSize:k,currentTheme:S,extractedAssetsCount:B,layoutChips:A,fetchNotebooks:C,triggerFileInput:L,clearFile:z,processFile:K,onFileSelected:x,onFileDrop:q,onTextChange:_,reprocessCurrentInput:U,handleConfirmImport:O}}const $k={class:"spm-import-dialog"},Ik={class:"spm-tabs-header"},Mk={class:"spm-dialog-body"},Tk={key:0,class:"spm-file-section"},Ek={key:0,class:"spm-dropzone-prompt"},Ak={class:"spm-dropzone-icon"},Bk={key:1,class:"spm-dropzone-active"},Dk={class:"spm-file-badge"},Lk={class:"spm-file-size"},Pk={key:1,class:"spm-text-section"},Ok={key:2,class:"spm-error-banner"},Rk={key:3,class:"spm-preview-card"},Nk={class:"spm-preview-card__header"},zk={style:{display:"inline-flex","align-items":"center",gap:"4px"}},Hk={class:"spm-config-grid"},Fk={class:"spm-form-item"},jk={class:"spm-form-item"},Wk=["value"],Uk={class:"spm-stats-grid"},Vk={class:"spm-stat-box"},Gk={class:"spm-stat-value"},Kk={class:"spm-stat-box"},qk={class:"spm-stat-value"},Yk={class:"spm-stat-box"},Zk={class:"spm-stat-value"},Jk={class:"spm-stat-box"},Xk={class:"spm-stat-value"},Qk={key:0,class:"spm-chips-row"},ew={class:"spm-options-group"},tw={class:"spm-checkbox-label"},iw={class:"spm-checkbox-label"},nw={class:"spm-checkbox-label"},sw={class:"spm-checkbox-label"},ow={class:"spm-dialog-footer"},rw=["disabled"],aw=["disabled"],lw={key:0,style:{display:"inline-flex","align-items":"center",gap:"4px"}},cw={key:1,style:{display:"inline-flex","align-items":"center",gap:"4px"}},dw=Dt({__name:"SlidesImportDialog",emits:["close","success"],setup(e,{emit:t}){const i=t,n=zt("plugin"),{inputMode:s,isDragging:o,isImporting:a,errorMessage:r,fileInputRef:l,selectedFileName:c,rawMarkdownText:u,extractedAssetsCount:f,parsedPresentation:d,customDocTitle:p,notebooks:w,selectedNotebookId:m,optCleanHtml:b,optStripNotes:y,optUploadAssets:v,optAutoPreview:k,formattedFileSize:S,currentTheme:B,layoutChips:A,fetchNotebooks:C,triggerFileInput:L,clearFile:z,onFileSelected:N,onFileDrop:K,onTextChange:_,reprocessCurrentInput:U,handleConfirmImport:x}=_k(n);bn(async()=>{await C()});async function q(){const $=await x();$&&(i("success",{docId:$}),i("close"))}function O(){i("close")}return($,T)=>(J(),ee("div",{class:"spm-modal-overlay",onClick:Zt(O,["self"])},[h("div",$k,[h("div",{class:"spm-dialog-header"},[T[18]||(T[18]=h("div",{class:"spm-dialog-title"},[h("svg",{class:"spm-dialog-icon","aria-hidden":"true"},[h("use",{"xlink:href":"#iconSlides"})]),h("span",null,"导入 Slidev 演示文档")],-1)),h("button",{class:"spm-close-btn",title:"关闭",onClick:O},"✕")]),h("div",Ik,[h("button",{class:Ce(["spm-tab-btn",{active:he(s)==="file"}]),onClick:T[0]||(T[0]=P=>s.value="file")},[oe(de,{name:"package"}),T[19]||(T[19]=h("span",null,"文件 / 压缩包导入 (.zip / .md)",-1))],2),h("button",{class:Ce(["spm-tab-btn",{active:he(s)==="text"}]),onClick:T[1]||(T[1]=P=>s.value="text")},[oe(de,{name:"notes"}),T[20]||(T[20]=h("span",null,"粘贴 Markdown 源码",-1))],2)]),h("div",Mk,[he(s)==="file"?(J(),ee("div",Tk,[h("div",{class:Ce(["spm-dropzone",{dragover:he(o),"has-file":!!he(c)}]),onDragover:T[4]||(T[4]=Zt(P=>o.value=!0,["prevent"])),onDragleave:T[5]||(T[5]=Zt(P=>o.value=!1,["prevent"])),onDrop:T[6]||(T[6]=Zt((...P)=>he(K)&&he(K)(...P),["prevent"])),onClick:T[7]||(T[7]=(...P)=>he(L)&&he(L)(...P))},[h("input",{ref_key:"fileInputRef",ref:l,type:"file",accept:".zip,.md",class:"spm-hidden-input",onChange:T[2]||(T[2]=(...P)=>he(N)&&he(N)(...P))},null,544),he(c)?(J(),ee("div",Bk,[h("span",Dk,[oe(de,{name:"notes"}),It(" "+we(he(c)),1)]),h("span",Lk,"("+we(he(S))+")",1),h("button",{class:"spm-btn-text",onClick:T[3]||(T[3]=Zt((...P)=>he(z)&&he(z)(...P),["stop"]))},"更换文件")])):(J(),ee("div",Ek,[h("span",Ak,[oe(de,{name:"folder",style:{"font-size":"32px"}})]),T[21]||(T[21]=h("p",{class:"spm-dropzone-text"},"点击选择文件，或直接拖拽文件至此处",-1)),T[22]||(T[22]=h("p",{class:"spm-dropzone-hint"},[It(" 支持 Slidev 完整工程 "),h("strong",null,".zip"),It("（自动解包 public/ 静态素材）或单文件 "),h("strong",null,".md")],-1))]))],34)])):(J(),ee("div",Pk,[Ot(h("textarea",{"onUpdate:modelValue":T[8]||(T[8]=P=>tt(u)?u.value=P:null),class:"spm-textarea spm-source-editor",rows:"8",placeholder:"在此直接粘贴包含 Frontmatter 的 Slidev slides.md 源码...",onInput:T[9]||(T[9]=(...P)=>he(_)&&he(_)(...P))},null,544),[[Ro,he(u)]])])),he(r)?(J(),ee("div",Ok," ⚠️ "+we(he(r)),1)):Te("",!0),he(d)?(J(),ee("div",Rk,[h("div",Nk,[h("span",zk,[oe(de,{name:"sparkles"}),T[23]||(T[23]=It(" 演示解析摘要",-1))]),T[24]||(T[24]=h("span",{class:"spm-badge-success"},"预检就绪",-1))]),h("div",Hk,[h("div",Fk,[T[25]||(T[25]=h("label",{class:"spm-form-label"},"笔记文档标题",-1)),Ot(h("input",{"onUpdate:modelValue":T[10]||(T[10]=P=>tt(p)?p.value=P:null),class:"spm-input",placeholder:"思源新文档标题"},null,512),[[Ro,he(p)]])]),h("div",jk,[T[26]||(T[26]=h("label",{class:"spm-form-label"},"存放目标笔记本",-1)),Ot(h("select",{"onUpdate:modelValue":T[11]||(T[11]=P=>tt(m)?m.value=P:null),class:"spm-select"},[(J(!0),ee(Xe,null,St(he(w),P=>(J(),ee("option",{key:P.id,value:P.id},we(P.name),9,Wk))),128))],512),[[Ff,he(m)]])])]),h("div",Uk,[h("div",Vk,[h("span",Gk,we(he(d).totalSlides),1),T[27]||(T[27]=h("span",{class:"spm-stat-label"},"幻灯片页数",-1))]),h("div",Kk,[h("span",qk,we(he(B)),1),T[28]||(T[28]=h("span",{class:"spm-stat-label"},"演示主题",-1))]),h("div",Yk,[h("span",Zk,we(he(d).stats.totalNotes),1),T[29]||(T[29]=h("span",{class:"spm-stat-label"},"演讲者提词",-1))]),h("div",Jk,[h("span",Xk,we(he(f)),1),T[30]||(T[30]=h("span",{class:"spm-stat-label"},"关联本地素材",-1))])]),he(A).length>0?(J(),ee("div",Qk,[T[31]||(T[31]=h("span",{class:"spm-chips-label"},"页面版式分布：",-1)),(J(!0),ee(Xe,null,St(he(A),P=>(J(),ee("span",{key:P.name,class:"spm-chip-badge"},we(P.name)+": "+we(P.count),1))),128))])):Te("",!0),h("div",ew,[h("label",tw,[Ot(h("input",{"onUpdate:modelValue":T[12]||(T[12]=P=>tt(b)?b.value=P:null),type:"checkbox",onChange:T[13]||(T[13]=(...P)=>he(U)&&he(U)(...P))},null,544),[[as,he(b)]]),T[32]||(T[32]=h("span",null,"智能剥离展示型 HTML 容器为干净原生的 Markdown 笔记块",-1))]),h("label",iw,[Ot(h("input",{"onUpdate:modelValue":T[14]||(T[14]=P=>tt(y)?y.value=P:null),type:"checkbox",onChange:T[15]||(T[15]=(...P)=>he(U)&&he(U)(...P))},null,544),[[as,he(y)]]),T[33]||(T[33]=h("span",null,"提取演讲者提词到块属性并保持正文笔记清爽",-1))]),h("label",nw,[Ot(h("input",{"onUpdate:modelValue":T[16]||(T[16]=P=>tt(v)?v.value=P:null),type:"checkbox"},null,512),[[as,he(v)]]),T[34]||(T[34]=h("span",null,"自动上传关联素材至思源资产库并重写路径 (assets/...)",-1))]),h("label",sw,[Ot(h("input",{"onUpdate:modelValue":T[17]||(T[17]=P=>tt(k)?k.value=P:null),type:"checkbox"},null,512),[[as,he(k)]]),T[35]||(T[35]=h("span",null,"导入后自动打开新文档并开启下方分屏放映预览",-1))])])])):Te("",!0)]),h("div",ow,[h("button",{class:"spm-btn-secondary",disabled:he(a),onClick:O}," 取消 ",8,rw),h("button",{class:"spm-btn-primary",disabled:!he(d)||he(a),onClick:q},[he(a)?(J(),ee("span",lw,[oe(de,{name:"refresh"}),T[36]||(T[36]=It(" 正在导入生成中...",-1))])):(J(),ee("span",cw,[oe(de,{name:"rocket"}),T[37]||(T[37]=It(" 确认导入思源笔记",-1))]))],8,aw)])])]))}}),uw=ii(dw,[["__scopeId","data-v-c56a3d7e"]]);function br(e){return e?e==="NodeThematicBreak"||e==="tb"||e==="thematic-break":!1}function fw(e,t){var r;if(!e||e.length===0)return null;const i=t.activeBlockId||"",n=t.currentTopBlockId||i,s=t.currentPageDividerId||"",o=t.activeBlockType||"";if(br(o)&&i){let l=e.find(c=>c.startBlockId===i);if(l||(l=e.find(c=>{var u,f;return((f=(u=c.blocks)==null?void 0:u[0])==null?void 0:f.id)===i}),l)||(l=e.find(c=>{var u;return(u=c.allBlockIds)==null?void 0:u.includes(i)}),l))return l}if(s){let l=e.find(c=>c.startBlockId===s);if(l||(l=e.find(c=>{var u,f;return((f=(u=c.blocks)==null?void 0:u[0])==null?void 0:f.id)===s}),l))return l}if(i){let l=e.find(u=>u.startBlockId===i);if(l||(l=e.find(u=>{var f,d;return((f=u.blocks)==null?void 0:f.some(p=>p.id===i))||((d=u.allBlockIds)==null?void 0:d.includes(i))}),l)||n&&n!==i&&(l=e.find(u=>{var f,d;return((f=u.blocks)==null?void 0:f.some(p=>p.id===n))||((d=u.allBlockIds)==null?void 0:d.includes(n))}),l)||(l=e.find(u=>{var f;return(f=u.noteBlocks)==null?void 0:f.some(d=>d.id===i||d.id===n)}),l))return l;const c=(r=t.activeBlockAttrs)==null?void 0:r[Me];if(c&&["col-1","col-2","col-3"].includes(c)&&(l=e.find(u=>{var f,d;return((f=u.frontmatter)==null?void 0:f.layout)==="three-cols-header"||((d=u.blocks)==null?void 0:d.some(p=>p.slot==="col-1"||p.slot==="col-2"||p.slot==="col-3"))}),l))return l}return e[0]||null}function et(e,t){var s;if(typeof document>"u"||!e)return;const i=(s=globalThis.CSS)!=null&&s.escape?globalThis.CSS.escape(e):e.replace(/"/g,'\\"'),n=document.querySelectorAll(`[data-node-id="${i}"]`);!n||n.length===0||n.forEach(o=>{for(const[a,r]of Object.entries(t))r!=null&&r!==""?o.setAttribute(a,String(r)):o.removeAttribute(a)})}function pw(e){if(typeof document>"u")return;const t=`.protyle-wysiwyg [${ke}], .protyle-wysiwyg [${Ze}], .protyle-wysiwyg [custom-slides-layout], .protyle-wysiwyg [custom-slides-role]`,i=document.querySelectorAll(t);!i||i.length===0||i.forEach(n=>{const s=n.getAttribute("data-node-id");if(!s){n.removeAttribute(ke),n.removeAttribute("custom-slides-layout"),n.removeAttribute(Ze),n.removeAttribute("custom-slides-role");return}const o=e.get(s),a=(o==null?void 0:o[ke])||(o==null?void 0:o["custom-slides-layout"])||"",r=n.getAttribute(ke)||n.getAttribute("custom-slides-layout");r&&r!==a&&(a?n.setAttribute(ke,a):(n.removeAttribute(ke),n.removeAttribute("custom-slides-layout")));const l=(o==null?void 0:o[Ze])||(o==null?void 0:o["custom-slides-role"])||"",c=n.getAttribute(Ze)||n.getAttribute("custom-slides-role");c&&c!==l&&(l?n.setAttribute(Ze,l):(n.removeAttribute(Ze),n.removeAttribute("custom-slides-role")))})}function hw(e,t){if(!t)return!1;if(e===t||typeof document>"u")return!0;const i=document.querySelector(`.protyle-wysiwyg [data-node-id="${t}"]`)||document.querySelector(`[data-node-id="${t}"]`);if(!i)return!1;const n=i.querySelector(":scope > [data-node-id], :scope > div > [data-node-id]");return(n==null?void 0:n.getAttribute("data-node-id"))===e}function mw(e){let t=null;function i(c="已同步"){e.saveStatus.value=c,t&&(typeof window<"u"?window.clearTimeout(t):clearTimeout(t));const u=()=>{e.saveStatus.value=""};typeof window<"u"?t=window.setTimeout(u,1200):t=setTimeout(u,1200)}async function n(c){var p;const u=e.activeBlockId.value||e.currentDocId.value;if(!u)return;for(const[w,m]of Object.entries(c))e.activeBlockAttrs.value[w]=m;Le.setBlockAttrOverride(u,c),et(u,c);const f=(p=e.parentContainerId)==null?void 0:p.value,d=!!(f&&hw(u,f));if(Ne in c&&d&&f){const w=c[Ne];e.parentContainerClicks&&(e.parentContainerClicks.value=w),Le.setBlockAttrOverride(f,{[Ne]:w}),et(f,{[Ne]:w}),Fe(f,{[Ne]:w}).catch(()=>{})}if(ke in c){const w=c[ke];e.currentPageDividerLayout.value=w,e.targetSlide.value&&(e.targetSlide.value.frontmatter||(e.targetSlide.value.frontmatter={}),e.targetSlide.value.frontmatter.layout=w)}if(bt in c){const w=c[bt];e.targetSlide.value&&(e.targetSlide.value.frontmatter||(e.targetSlide.value.frontmatter={}),e.targetSlide.value.frontmatter.layoutRatio=w)}i("保存中...");try{await Fe(u,c),i("已同步"),e.plugin&&await e.plugin.compileCurrentDocument()}catch{i("同步失败")}}async function s(c,u){await n({[c]:u})}function o(){var u;return(e.activeBlockType.value==="NodeThematicBreak"||e.activeBlockType.value==="NodeThematicBreakBlock"||e.activeBlockType.value==="hr"||e.activeBlockType.value==="thematicbreak")&&e.activeBlockId.value?e.activeBlockId.value:e.currentPageDividerId.value?e.currentPageDividerId.value:(u=e.targetSlide.value)!=null&&u.startBlockId&&e.targetSlide.value.startBlockId!==e.currentDocId.value?e.targetSlide.value.startBlockId:e.currentDocId.value}async function a(c,u){const f=o();if(f){f===e.activeBlockId.value&&(e.activeBlockAttrs.value[c]=u),Le.setBlockAttrOverride(f,{[c]:u}),et(f,{[c]:u}),c===ke&&(e.currentPageDividerLayout.value=u,e.targetSlide.value&&(e.targetSlide.value.frontmatter||(e.targetSlide.value.frontmatter={}),e.targetSlide.value.frontmatter.layout=u)),c===bt&&e.targetSlide.value&&(e.targetSlide.value.frontmatter||(e.targetSlide.value.frontmatter={}),e.targetSlide.value.frontmatter.layoutRatio=u),i("保存中...");try{await Fe(f,{[c]:u}),i("已同步"),e.plugin&&await e.plugin.compileCurrentDocument()}catch{i("同步失败")}}}async function r(c,u){const f=o();if(!f)return;const d={[ke]:c,[bt]:u};f===e.activeBlockId.value&&(e.activeBlockAttrs.value[ke]=c,e.activeBlockAttrs.value[bt]=u),e.currentPageDividerLayout.value=c,Le.setBlockAttrOverride(f,d),et(f,d),e.targetSlide.value&&(e.targetSlide.value.frontmatter||(e.targetSlide.value.frontmatter={}),e.targetSlide.value.frontmatter.layout=c,e.targetSlide.value.frontmatter.layoutRatio=u),i("应用排版中...");try{await Fe(f,d),i("已应用分栏与比例"),e.plugin&&await e.plugin.compileCurrentDocument()}catch{i("应用失败")}}async function l(c,u){var d;const f=e.currentDocId.value||e.activeBlockId.value;if(f){e.activeBlockAttrs.value[c]=u,Le.setBlockAttrOverride(f,{[c]:u}),et(f,{[c]:u}),(d=e.latestDoc.value)!=null&&d.config&&(c===zn&&(e.latestDoc.value.config.theme=u),c===Hn&&(e.latestDoc.value.config.aspectRatio=u),c===Fn&&(e.latestDoc.value.config.defaultTransition=u),c===ws&&(e.latestDoc.value.config.background=u)),i("更新中...");try{await Fe(f,{[c]:u}),i("已更新"),e.plugin&&await e.plugin.compileCurrentDocument(f)}catch{i("更新失败")}}}return{triggerSaveNotice:i,saveAttrs:n,saveAttr:s,getPageTargetBlockId:o,savePageAttr:a,applyPageLayoutAndRatio:r,saveDocAttr:l}}function ba(e){const t=(e.blocks||[]).filter(o=>{const a=(o.content||o.rawMarkdown||"").trim();return a&&a!=="---"});if(t.length===0)return"本页暂无内容，建议过渡承接上下文。";const i=[],n=[];for(const o of t){const a=(o.content||o.rawMarkdown||"").trim();a&&(o.type==="h"||a.startsWith("#")?i.push(a.replace(/^#+\s*/,"")):n.push(a.slice(0,50)))}const s=[];return i.length>0&&s.push(`【核心重点】：${i.join("、")}`),n.length>0&&(s.push("【口播要点】："),n.slice(0,3).forEach((o,a)=>{s.push(`${a+1}. 讲解 ${o}`)})),s.push("【过渡提示】：注意观察听众反应，适时抛出互动提问。"),s.join(`
`)}async function uc(e,t){const i=e.blocks&&e.blocks.length>0?e.blocks.map(n=>(n.content||n.rawMarkdown||"").trim()).filter(n=>n&&n!=="---").join(`
`):(e.rawMarkdown||"").replace(/^---\s*$/gm,"").trim();if(t&&i){const n=`你是一位专业的演讲教练。请根据以下幻灯片内容，提炼出简短精炼的演讲口播提词卡（Notes），包含核心观点与口播要点，总字数在 150 字以内：
${i}`;try{const s=await t(n);if(s&&s.trim())return{notes:s.trim(),isAiGenerated:!0}}catch(s){return{notes:ba(e),isAiGenerated:!1,error:(s==null?void 0:s.message)||"AI 调用异常"}}}return{notes:ba(e),isAiGenerated:!1}}async function gw(e,t){return(await uc(e,t)).notes}function vw(e){if(!e)return!1;const t=String(e.type||"").toLowerCase();return!!(t==="callout"||t==="nodecallout"||t==="b"||t==="nodeblockquote"||String(e.markdown||"").trim().startsWith(">"))}function bw(e,t){if(!((t==null?void 0:t[qe])==="true"||(t==null?void 0:t["slides-note"])==="true"))return!1;const n=(e||"").trim();return/^>\s*\[!NOTE\]\s*(?:💡\s*)?(?:演讲备注|讲稿备注)/i.test(n)}async function yw(e,t){const n=await((t==null?void 0:t.getChildBlocksFn)||mn)(e).catch(()=>[]);if(!Array.isArray(n)||n.length===0)return[];const s=[];let o=[];for(const r of n){if(ui({...r,ial:{...r.ial||{},...Le.getBlockAttrOverride(r.id)||{}}})){if(s.length===0&&o.length===0)continue;s.push(o),o=[];continue}o.push(r)}s.push(o);const a=[];for(let r=0;r<s.length;r++){const l=s[r];if(!l||l.length===0)continue;let c=null;for(let w=l.length-1;w>=0;w--){const m=l[w];if(!((m.type==="p"||m.type==="NodeParagraph")&&!(m.content||"").trim()&&!(m.markdown||"").trim())){c=m;break}}if(!c||!vw(c))continue;const u=Le.getBlockAttrOverride(c.id)||{};let f={...c.ial||{},...u};if(!f[qe]&&!f["slides-note"]&&(t!=null&&t.getBlockAttrsFn)){const w=await t.getBlockAttrsFn(c.id).catch(()=>({}));f={...f,...w,...u}}let d=c.markdown||c.content||"";if(t!=null&&t.getBlockKramdownFn)try{const w=await t.getBlockKramdownFn(c.id);w!=null&&w.kramdown&&(d=w.kramdown)}catch{}if(bw(d,f))continue;const p=hr(d)||d.replace(/<[^>]+>/g,"").trim();a.push({id:c.id,pageIndex:r+1,type:c.type,sourceMarkdown:d,cleanContent:p||"在此输入本页讲稿提词..."})}return a}async function kw(e,t,i){const n=(i==null?void 0:i.updateBlockFn)||xo,s=(i==null?void 0:i.setBlockAttrsFn)||Fe,o=(i==null?void 0:i.syncDomFn)||et,r=`> [!NOTE] 💡 演讲备注
${t.split(/\r?\n/).map(l=>`> ${l}`).join(`
`)}
{: ${qe}="true"}`;await n("markdown",r,e),await s(e,{[qe]:"true"}),Le.setBlockAttrOverride(e,{[qe]:"true"}),o(e,{[qe]:"true"})}async function fc(e,t){const i=(t==null?void 0:t.showMessageFn)||ae.showMessage,n=(t==null?void 0:t.confirmFn)||ae.confirm;if(!e)return i("请先在主编辑区打开幻灯片文档"),{totalScanned:0,matchedCount:0,successCount:0,errorCount:0};const s=await yw(e,t);if(s.length===0)return i("未发现待规范化的候选讲稿块"),{totalScanned:0,matchedCount:0,successCount:0,errorCount:0};const o=s.length;return new Promise(a=>{n("识别讲稿块",`扫描检测到 ${o} 处候选讲稿块（提示块或引用块），是否确认将其规范化为标准演讲备注？`,async()=>{var c;i(`正在批量规范化 ${o} 个讲稿块...`);let r=0,l=0;for(const u of s)try{await kw(u.id,u.cleanContent,t),r++}catch(f){console.error(`[SiYuanLiveSlides] 规范化讲稿块 ${u.id} 失败:`,f),l++}(c=t==null?void 0:t.onSuccessNotice)==null||c.call(t,"已规范化讲稿"),i(`已成功识别并规范化 ${r} 个讲稿块`),t!=null&&t.compileFn&&await t.compileFn().catch(()=>{}),a({totalScanned:o,matchedCount:o,successCount:r,errorCount:l})},()=>{a({totalScanned:o,matchedCount:o,successCount:0,errorCount:0})})})}function ww(e,t){const i=ge(!1),{triggerSaveNotice:n}=t;async function s(d){var B,A,C,L,z,N,K,_;const m=`> [!NOTE] 💡 演讲备注
${(d||"在此输入本页讲稿提词...").split(/\r?\n/).map(U=>`> ${U}`).join(`
`)}
{: custom-slides-note="true"}`,b=((B=e.latestDoc.value)==null?void 0:B.slides)||[],y=e.targetSlide.value,v=y?b.findIndex(U=>U===y):-1;let k=null;if(v!==-1&&v<b.length-1){const U=b[v+1];k=await Hi("markdown",m,U.startBlockId)}else{const U=((A=y==null?void 0:y.noteBlocks)==null?void 0:A.slice(-1)[0])||((C=y==null?void 0:y.blocks)==null?void 0:C.slice(-1)[0]),x=(U==null?void 0:U.id)||(y==null?void 0:y.startBlockId);x?k=await Hi("markdown",m,void 0,x):k=await wo("markdown",m,e.currentDocId.value)}const S=((N=(z=(L=k==null?void 0:k[0])==null?void 0:L.doOperations)==null?void 0:z[0])==null?void 0:N.id)||((K=k==null?void 0:k[0])==null?void 0:K.id);return S&&(await Fe(S,{[qe]:"true"}),Le.setBlockAttrOverride(S,{[qe]:"true"}),Gi(S,(_=e.plugin)==null?void 0:_.app)),e.plugin&&await e.plugin.compileCurrentDocument(),S}async function o(){const d=e.activeBlockId.value;if(d)if(e.isNoteBlock.value){n("取消中...");try{await Fe(d,{[qe]:"","slides-note":""}),Le.setBlockAttrOverride(d,{[qe]:"","slides-note":""}),et(d,{[qe]:"","slides-note":""}),delete e.activeBlockAttrs.value[qe],delete e.activeBlockAttrs.value["slides-note"],n("已取消备注"),ae.showMessage("已取消讲稿备注"),e.plugin&&await e.plugin.compileCurrentDocument()}catch(p){console.error("[SiYuanLiveSlides] 取消讲稿备注失败:",p),n("取消失败"),ae.showMessage("取消讲稿备注失败")}}else{n("转换中...");try{let p=e.rawSnippet.value;try{const y=await vd(d);y!=null&&y.kramdown&&(p=y.kramdown)}catch{}const b=`> [!NOTE] 💡 演讲备注
${(hr(p)||p.replace(/<[^>]+>/g,"").trim()||"在此输入本页讲稿提词...").split(/\r?\n/).map(y=>`> ${y}`).join(`
`)}
{: custom-slides-note="true"}`;await xo("markdown",b,d),await Fe(d,{[qe]:"true"}),Le.setBlockAttrOverride(d,{[qe]:"true"}),et(d,{[qe]:"true"}),e.activeBlockAttrs.value[qe]="true",e.activeBlockType.value="NodeCallout",n("已设为讲稿备注"),ae.showMessage("已转为讲稿备注提示块（不在幻灯片中渲染）"),e.plugin&&await e.plugin.compileCurrentDocument()}catch(p){console.error("[SiYuanLiveSlides] 转换讲稿备注提示块失败:",p),n("设置失败"),ae.showMessage("转为讲稿备注提示块失败")}}}async function a(){try{await s(),ae.showMessage("已在正文末尾插入讲稿备注提示块")}catch(d){ae.showMessage("插入讲稿备注块失败"),console.error(d)}}function r(){var w;const d=e.currentSlideNoteBlockId.value;if(!d){ae.showMessage("未找到本页关联的讲稿备注块");return}Gi(d,(w=e.plugin)==null?void 0:w.app)?ae.showMessage("已在编辑区定位讲稿备注块"):ae.showMessage("定位讲稿备注块失败")}async function l(){var w;if(!e.currentDocId.value)return;const d=e.targetSlide.value||{startBlockId:e.activeBlockId.value||e.currentDocId.value,blocks:e.rawSnippet.value&&e.rawSnippet.value!=="---"?[{id:e.activeBlockId.value,type:e.activeBlockType.value,content:e.rawSnippet.value,rawMarkdown:""}]:[],rawMarkdown:e.rawSnippet.value&&e.rawSnippet.value!=="---"?e.rawSnippet.value:""};ae.showMessage("正在调用思源 AI 提炼本页讲稿提词...");const p=await uc(d,Ca);if(p.notes){const m=e.currentSlideNoteBlockId.value;if(m){const b=`> [!NOTE] 💡 演讲备注
${p.notes.split(/\r?\n/).map(y=>`> ${y}`).join(`
`)}
{: custom-slides-note="true"}`;await xo("markdown",b,m),await Fe(m,{[qe]:"true"}),Le.setBlockAttrOverride(m,{[qe]:"true"}),Gi(m,(w=e.plugin)==null?void 0:w.app)}else await s(p.notes);p.isAiGenerated?ae.showMessage("思源 AI 演讲提词卡生成成功！"):ae.showMessage("未获取到思源 AI 响应，已生成预设提词卡模板",5e3),e.plugin&&await e.plugin.compileCurrentDocument()}}async function c(){var m;if(i.value)return;const d=((m=e.latestDoc.value)==null?void 0:m.slides)||[];if(d.length===0){ae.showMessage("当前文档无幻灯片页面");return}const p=d.map((b,y)=>({slide:b,idx:y})).filter(({slide:b})=>{var k;const y=Array.isArray(b.noteBlocks)&&b.noteBlocks.length>0,v=!!((k=b.notes)!=null&&k.trim());return!y&&!v});if(p.length===0){ae.showMessage("所有幻灯片页面均已存在讲稿备注块，无需追加");return}const w=p.length;ae.confirm("批量追加讲稿备注",`将在未配置讲稿的 ${w} 页末尾自动插入讲稿提示块，是否继续？`,async()=>{var y,v,k,S,B,A;if(i.value)return;i.value=!0,ae.showMessage("正在批量追加讲稿块...");let b=0;try{const z=`> [!NOTE] 💡 演讲备注
${"在此输入本页讲稿提词...".split(/\r?\n/).map(N=>`> ${N}`).join(`
`)}
{: custom-slides-note="true"}`;for(const{slide:N,idx:K}of p)try{let _=null;if(K<d.length-1){const x=d[K+1];_=await Hi("markdown",z,x.startBlockId)}else{const x=((y=N==null?void 0:N.noteBlocks)==null?void 0:y.slice(-1)[0])||((v=N==null?void 0:N.blocks)==null?void 0:v.slice(-1)[0]),q=(x==null?void 0:x.id)||(N==null?void 0:N.startBlockId);q?_=await Hi("markdown",z,void 0,q):_=await wo("markdown",z,e.currentDocId.value)}const U=((B=(S=(k=_==null?void 0:_[0])==null?void 0:k.doOperations)==null?void 0:S[0])==null?void 0:B.id)||((A=_==null?void 0:_[0])==null?void 0:A.id);U&&(await Fe(U,{[qe]:"true"}),Le.setBlockAttrOverride(U,{[qe]:"true"})),b++}catch(_){console.error(`[SiYuanLiveSlides] 为第 ${K+1} 页追加讲稿块失败:`,_)}e.plugin&&await e.plugin.compileCurrentDocument(),ae.showMessage(`已成功为 ${b} 页追加讲稿备注块`)}catch(C){console.error("[SiYuanLiveSlides] 批量追加讲稿块失败:",C),ae.showMessage("批量追加讲稿块时出现异常")}finally{i.value=!1}})}async function u(){var b;if(i.value)return;const d=((b=e.latestDoc.value)==null?void 0:b.slides)||[];if(d.length===0){ae.showMessage("当前文档无幻灯片页面");return}const p=[];for(const y of d)if(y.noteBlocks&&y.noteBlocks.length>0)for(const v of y.noteBlocks)v.id&&p.push({id:v.id,pageIndex:y.pageIndex});if(p.length===0){ae.showMessage("当前文档中没有讲稿备注块，无需删除");return}const w=new Set(p.map(y=>y.pageIndex)).size,m=p.length;ae.confirm("危险操作：批量删除所有讲稿块",`此操作将从正文中物理删除全部 ${m} 个讲稿备注块（涉及 ${w} 页），删除后无法撤销。是否确认继续？`,async()=>{if(i.value)return;i.value=!0,ae.showMessage("正在批量删除讲稿块...");let y=0;try{for(const v of p)try{await Vo(v.id),Le.clearBlockAttrOverride(v.id),y++}catch(k){console.error(`[SiYuanLiveSlides] 删除讲稿块 ${v.id} 失败:`,k)}e.activeBlockId.value&&p.some(v=>v.id===e.activeBlockId.value)&&(delete e.activeBlockAttrs.value[qe],delete e.activeBlockAttrs.value["slides-note"]),e.plugin&&await e.plugin.compileCurrentDocument(),ae.showMessage(`已成功删除全部 ${y} 个讲稿备注块`)}catch(v){console.error("[SiYuanLiveSlides] 批量删除讲稿块失败:",v),ae.showMessage("批量删除讲稿块时出现异常")}finally{i.value=!1}})}async function f(){var p;const d=e.currentDocId.value||((p=e.plugin)==null?void 0:p.currentDocId);if(!d){ae.showMessage("请先在主编辑区打开幻灯片文档");return}if(i.value){ae.showMessage("正在批量处理中，请稍候...");return}i.value=!0;try{await fc(d,{onSuccessNotice:n,compileFn:async()=>{e.plugin&&await e.plugin.compileCurrentDocument()}})}finally{i.value=!1}}return{isBatchProcessing:i,createNoteBlockOnCurrentSlide:s,onToggleNoteBlock:o,onAddNoteBlock:a,onLocateNoteBlock:r,onGenerateNotesWithAI:l,onBatchAppendNotes:c,onBatchDeleteNotes:u,onIdentifyNotesBlocks:f}}function xw(e){if(!e)return!1;const t=String(e.type||"").toLowerCase();if(t==="h"||t==="nodeheading")return!0;const i=String(e.subType||"").toLowerCase();if(/^h[1-6]$/.test(i))return!0;const n=String(e.rawMarkdown||e.markdown||"").trim();return!!/^#{1,6}\s+/.test(n)}function Sw(e){if(!e)return!1;const t=String(e.type||"").toLowerCase();return t==="i"||t==="nodelistitem"}function Cw(e){const t=[],i=n=>{var s,o,a,r,l,c,u,f,d,p,w;for(const m of n){if(!m||m.isNote||((s=m.attributes)==null?void 0:s[qe])==="true"||((o=m.attributes)==null?void 0:o["slides-note"])==="true"||((a=m.ial)==null?void 0:a[qe])==="true"||((r=m.ial)==null?void 0:r["slides-note"])==="true"||m.type==="tb"||m.type==="thematic-break"||m.type==="NodeThematicBreak"||String(m.markdown||m.rawMarkdown||"").trim()==="---"||m.slot==="slot-divider-right"||String(m.rawMarkdown||m.markdown||"").trim()==="::right::")continue;if(xw(m)){t.push({id:m.id,type:m.type,isHeading:!0,currentClicks:m.clicks||((l=m.attributes)==null?void 0:l[Ne])||((c=m.ial)==null?void 0:c[Ne]),rawBlock:m});continue}if(Sw(m)){t.push({id:m.id,type:m.type||"i",isHeading:!1,currentClicks:m.clicks||((u=m.attributes)==null?void 0:u[Ne])||((f=m.ial)==null?void 0:f[Ne]),rawBlock:m});continue}const b=m.children&&m.children.length>0?m.children:(d=m.rawNode)==null?void 0:d.children;if(Array.isArray(b)&&b.length>0){i(b);continue}t.push({id:m.id,type:m.type,isHeading:!1,currentClicks:m.clicks||((p=m.attributes)==null?void 0:p[Ne])||((w=m.ial)==null?void 0:w[Ne]),rawBlock:m})}};return i(e||[]),t}function _w(e){var s;if(e.pageIndex===1||((s=e.frontmatter)==null?void 0:s.layout)==="cover")return[];const t=Cw(e.blocks||[]);if(t.length===0)return[];let i=-1;for(let o=0;o<t.length;o++)if(!t[o].isHeading){i=o;break}if(i===-1)return[];const n=[];for(let o=i+1;o<t.length;o++){const a=t[o];!!!(a.currentClicks&&String(a.currentClicks).trim()!=="")&&a.id&&n.push({blockId:a.id,pageIndex:e.pageIndex,targetClick:"+1"})}return n}async function $w(e,t){const n=await((t==null?void 0:t.compileDocFn)||(a=>Le.compile(a)))(e).catch(()=>null);if(!n||!Array.isArray(n.slides)||n.slides.length===0)return{totalPages:0,animatedPagesCount:0,targets:[]};const s=[],o=new Set;for(const a of n.slides){const r=_w(a);r.length>0&&(s.push(...r),o.add(a.pageIndex))}return{totalPages:n.slides.length,animatedPagesCount:o.size,targets:s}}async function pc(e,t){const i=(t==null?void 0:t.showMessageFn)||ae.showMessage,n=(t==null?void 0:t.confirmFn)||ae.confirm,s=(t==null?void 0:t.setBlockAttrsFn)||Fe,o=(t==null?void 0:t.syncDomFn)||et;if(!e)return i("请先在主编辑区打开幻灯片文档"),{totalPages:0,animatedPagesCount:0,targets:[],successCount:0,errorCount:0};const a=await $w(e,t);if(a.targets.length===0)return i("未检测到需要配置顺延动效的后续块"),{...a,successCount:0,errorCount:0};const r=a.targets.length,l=a.animatedPagesCount;return new Promise(c=>{n("智能设置动效",`扫描检测到可为 ${l} 页中的 ${r} 个后续块配置顺延 (+1) 动效，是否继续？`,async()=>{var d;i(`正在批量配置 ${r} 个后续块动效...`);let u=0,f=0;for(const p of a.targets)try{await s(p.blockId,{[Ne]:p.targetClick}),Le.setBlockAttrOverride(p.blockId,{[Ne]:p.targetClick}),o(p.blockId,{[Ne]:p.targetClick}),u++}catch(w){console.error(`[SiYuanLiveSlides] 为块 ${p.blockId} 配置动效失败:`,w),f++}(d=t==null?void 0:t.onSuccessNotice)==null||d.call(t,"已配置智能动效"),i(`已成功为 ${u} 个后续块配置顺延 (+1) 动效`),t!=null&&t.compileCurrentDocFn&&await t.compileCurrentDocFn().catch(()=>{}),c({...a,successCount:u,errorCount:f})},()=>{c({...a,successCount:0,errorCount:0})})})}function Iw(e,t){const{saveAttr:i,saveAttrs:n,savePageAttr:s}=t;async function o(){(e.videoAutoplay.value?"false":"true")==="true"?(await n({[zi]:"true",[Qi]:"true"}),e.activeBlockAttrs.value[zi]="true",e.activeBlockAttrs.value[Qi]="true"):(await i(zi,"false"),e.activeBlockAttrs.value[zi]="false")}async function a(){const L=e.videoLoop.value?"false":"true";await i(xs,L)}async function r(){const L=e.videoMuted.value?"false":"true";await i(Qi,L)}async function l(){const L=e.videoControls.value?"false":"true";await i(Ss,L)}async function c(L){var U,x;const z=e.activeBlockId.value;if(!z)return;const N=e.rawSnippet.value||"",K=hi(N)||"",_=e.currentPageDividerId.value||e.currentDocId.value;if(L)if(L==="background"){const q={[Ze]:"background",[ke]:""};_&&K&&(e.pageBackground&&(e.pageBackground.value=K),await Fe(_,{[st]:K}).catch(()=>{}),Le.setBlockAttrOverride(_,{[st]:K}),et(_,{[st]:K}),e.targetSlide.value&&(e.targetSlide.value.frontmatter||(e.targetSlide.value.frontmatter={}),e.targetSlide.value.frontmatter.background=K)),await n(q)}else(L===Cs||L===_s)&&await n({[ke]:L,[Ze]:""});else{const q={[Ze]:"",[ke]:""};if(e.activeBlockAttrs.value[st]==="true"&&(q[st]=""),_&&K&&((U=e.pageBackground)==null?void 0:U.value)===K&&(e.pageBackground&&(e.pageBackground.value=""),await Fe(_,{[st]:""}).catch(()=>{}),Le.setBlockAttrOverride(_,{[st]:""}),et(_,{[st]:""}),(x=e.targetSlide.value)!=null&&x.frontmatter&&delete e.targetSlide.value.frontmatter.background),await n(q),typeof document<"u"){const O=document.querySelector(`.protyle-wysiwyg [data-node-id="${z}"]`),$=O==null?void 0:O.closest('[data-type="NodeListItem"]'),T=$==null?void 0:$.getAttribute("data-node-id");if(T&&T!==z){const P={[ke]:"",[Ze]:""};et(T,P),Le.setBlockAttrOverride(T,P),await Fe(T,P).catch(()=>{})}}}}function u(){e.elemClick.value?i(Ne,""):i(Ne,"+1")}function f(L){i(Ne,L)}function d(L){i(Xt,L)}function p(L){(e.activeBlockAttrs.value[Me]||"")===L?i(Me,""):i(Me,L)}function w(L){e.elemShikiLines.value=L,i(Ki,L)}function m(L){const z=L?L.trim():"",N=/^\d+$/.test(z)?`${z}px`:z;e.elemMaxHeight.value=N,i(jn,N)}async function b(){const L=e.currentSlideLayout.value==="three-cols-header";await i(Me,L?"col-1":"left"),ae.showMessage(L?"已将当前块设置为第 1 栏":"已将当前块设置为双栏左栏")}async function y(){const L=e.activeBlockId.value;if(!L)return;const z={[Ne]:"",[Xt]:"",[Me]:"",[Ki]:"",[jn]:"",[qe]:"","slides-note":"",[ke]:"",[bt]:"",[Ze]:"",[vt]:"",[st]:"",[Rt]:"",[zi]:"",[xs]:"",[Qi]:"",[Ss]:""};if(et(L,z),await Fe(L,z),Le.clearBlockAttrOverride(L),typeof document<"u"){const N=document.querySelector(`.protyle-wysiwyg [data-node-id="${L}"]`),K=N==null?void 0:N.closest('[data-type="NodeListItem"]'),_=K==null?void 0:K.getAttribute("data-node-id");_&&_!==L&&(et(_,z),await Fe(_,z).catch(()=>{}),Le.clearBlockAttrOverride(_))}e.activeBlockAttrs.value={},e.elemShikiLines.value="",e.elemMaxHeight.value="",e.pageBackground&&(e.pageBackground.value=""),e.pageImage.value="",ae.showMessage("已清除本块演示属性"),e.plugin&&await e.plugin.compileCurrentDocument()}async function v(){if(e.activeBlockId.value)try{await Hi("markdown","---",e.activeBlockId.value,void 0),ae.showMessage("已在上方插入分页符"),e.plugin&&e.plugin.compileCurrentDocument()}catch{ae.showMessage("插入分页符失败")}}async function k(){const L=e.activeBlockId.value||e.currentDocId.value;if(L)try{await Hi("markdown","---",void 0,L),ae.showMessage("已在下方插入分页符"),e.plugin&&e.plugin.compileCurrentDocument()}catch{ae.showMessage("插入分页符失败")}}async function S(){if(e.activeBlockId.value)try{await Vo(e.activeBlockId.value),ae.showMessage("已删除该分页符"),e.activeBlockId.value="",e.activeBlockType.value="",e.plugin&&e.plugin.compileCurrentDocument()}catch{ae.showMessage("删除失败")}}async function B(){var L,z;try{let N=null;if(typeof document<"u"){const _=e.activeBlockId.value;if(_){const U=document.querySelector(`.protyle-wysiwyg [data-node-id="${_}"]`);U&&(N=U.getAttribute("data-type")==="NodeSuperBlock"?U:U.closest('[data-type="NodeSuperBlock"]'))}if(!N){const U=e.currentPageDividerId.value||(e.activeBlockType.value==="hr"||e.activeBlockType.value==="NodeThematicBreak"?e.activeBlockId.value:"");if(U){const x=document.querySelector(`.protyle-wysiwyg [data-node-id="${U}"]`);if(x){let q=x.nextElementSibling;for(;q&&!(q.getAttribute("data-type")==="NodeThematicBreak"||(L=q.classList)!=null&&L.contains("protyle-wysiwyg__block--hr"));){const O=q.getAttribute("data-type")==="NodeSuperBlock"?q:q.querySelector('[data-type="NodeSuperBlock"]');if(O){N=O;break}q=q.nextElementSibling}}}else{const x=document.querySelector('.protyle-wysiwyg [data-type="NodeThematicBreak"], .protyle-wysiwyg .protyle-wysiwyg__block--hr'),q=Array.from(document.querySelectorAll('.protyle-wysiwyg [data-type="NodeSuperBlock"]'));for(const O of q)if(!x||O.compareDocumentPosition(x)&Node.DOCUMENT_POSITION_FOLLOWING){N=O;break}}}}const K=[];if(N){const _=Array.from(N.querySelectorAll(":scope > [data-node-id]"));for(const U of _){const x=U.getAttribute("data-node-id");x&&(K.push(x),U.removeAttribute("style"))}}else if((z=e.targetSlide.value)!=null&&z.blocks){for(const _ of e.targetSlide.value.blocks)if(_.children&&_.children.length>=2){for(const U of _.children)U.id&&K.push(U.id);break}}if(K.length>0)for(const _ of K)await Fe(_,{style:""}).catch(()=>{});await s(bt,""),ae.showMessage("已重置超级块为平均分布比例"),e.plugin&&await e.plugin.compileCurrentDocument()}catch(N){console.error("[layout-actions] resetSuperBlockWidth error:",N),ae.showMessage("重置超级块比例失败")}}async function A(){var L,z,N;try{let K=null;if(typeof document<"u"){const U=e.currentPageDividerId.value||(e.activeBlockType.value==="hr"||e.activeBlockType.value==="NodeThematicBreak"?e.activeBlockId.value:""),x=e.activeBlockId.value;let q=[];if(U){const T=document.querySelector(`.protyle-wysiwyg [data-node-id="${U}"]`);if(T){let P=T.nextElementSibling;for(;P&&!(P.getAttribute("data-type")==="NodeThematicBreak"||(L=P.classList)!=null&&L.contains("protyle-wysiwyg__block--hr"));)q.push(P),P=P.nextElementSibling}}else{const T=document.querySelector('.protyle-wysiwyg [data-type="NodeThematicBreak"], .protyle-wysiwyg .protyle-wysiwyg__block--hr'),P=Array.from(document.querySelectorAll(".protyle-wysiwyg > [data-node-id]"));for(const se of P)if(!T||se.compareDocumentPosition(T)&Node.DOCUMENT_POSITION_FOLLOWING)q.push(se);else break}const O=[];let $;for(const T of q){const P=T.getAttribute("data-type");P==="NodeHeading"&&($=T.getAttribute("data-node-id")||void 0);const se=[];P==="NodeSuperBlock"?se.push(T):se.push(...Array.from(T.querySelectorAll('[data-type="NodeSuperBlock"]')));for(const V of se){if((V.getAttribute("data-sb-layout")||"").toLowerCase()==="row")continue;const ce=V.getAttribute("data-node-id")||"";let ie=[];const re=Array.from(V.querySelectorAll('[data-type="NodeListItem"]'));if(re.length===4&&(ie=re.map(Se=>Se.getAttribute("data-node-id")).filter(Boolean)),ie.length!==4){const Se=Array.from(V.querySelectorAll(":scope > [data-node-id]"));Se.length===4&&(ie=Se.map(Ie=>Ie.getAttribute("data-node-id")).filter(Boolean))}ie.length===4&&O.push({sbId:ce,itemIds:ie,headerId:$})}}O.length>0&&(x&&(K=O.find(T=>{if(T.sbId===x||T.itemIds.includes(x))return!0;const P=document.querySelector(`.protyle-wysiwyg [data-node-id="${T.sbId}"]`),se=document.querySelector(`.protyle-wysiwyg [data-node-id="${x}"]`);return!!(P&&se&&P.contains(se))})||null),K||(K=O[0]))}if(!K&&((z=e.targetSlide.value)!=null&&z.blocks)){const U=e.targetSlide.value,x=[];for(const O of U.blocks)O.rawNode?x.push(O.rawNode):x.push({id:O.id,type:O.type,content:O.content,markdown:O.rawMarkdown,children:O.children,ial:O.attributes||O.ial||{}});const q=ip(x,e.activeBlockId.value);q&&q.items.length===4&&(K={sbId:q.superBlockNode.id,itemIds:q.items.map(O=>O.id),headerId:(N=q.headerNode)==null?void 0:N.id})}const _=e.currentPageDividerId.value||e.currentDocId.value;if(_&&(e.currentPageDividerLayout.value="clover",e.targetSlide.value&&(e.targetSlide.value.frontmatter||(e.targetSlide.value.frontmatter={}),e.targetSlide.value.frontmatter.layout="clover"),Le.setBlockAttrOverride(_,{[ke]:"clover"}),et(_,{[ke]:"clover"}),await Fe(_,{[ke]:"clover"}).catch(()=>{})),K&&K.itemIds.length>0){K.headerId&&(Le.setBlockAttrOverride(K.headerId,{[Me]:"header"}),et(K.headerId,{[Me]:"header"}),await Fe(K.headerId,{[Me]:"header"}).catch(()=>{}));const U=Math.min(4,K.itemIds.length);for(let x=0;x<U;x++){const q=K.itemIds[x],O=`col-${x+1}`;Le.setBlockAttrOverride(q,{[Me]:O}),et(q,{[Me]:O}),await Fe(q,{[Me]:O}).catch(()=>{})}}return ae.showMessage("已将本页版式设为四叶草（田字型）布局"),e.plugin&&await e.plugin.compileCurrentDocument(),!0}catch(K){return console.error("[layout-actions] applyCloverLayout error:",K),ae.showMessage("配置四叶草布局失败",4e3,"error"),!1}}async function C(){var z,N;const L=e.currentDocId.value||((z=e.plugin)==null?void 0:z.currentDocId);if(!L){ae.showMessage("请先在主编辑区打开幻灯片文档");return}if((N=t.isBatchProcessing)!=null&&N.value){ae.showMessage("正在批量处理中，请稍候...");return}t.isBatchProcessing&&(t.isBatchProcessing.value=!0);try{await pc(L,{onSuccessNotice:t.triggerSaveNotice,compileCurrentDocFn:async()=>{e.plugin&&await e.plugin.compileCurrentDocument()}})}finally{t.isBatchProcessing&&(t.isBatchProcessing.value=!1)}}return{onToggleVideoAutoplay:o,onToggleVideoLoop:a,onToggleVideoMuted:r,onToggleVideoControls:l,onImageRoleChange:c,toggleElemClick:u,onElemClickStepChange:f,onElemMotionChange:d,onElemSlotChange:p,onElemShikiLinesChange:w,onElemMaxHeightChange:m,onSetTwoColsContrast:b,onClearBlockAttrs:y,onInsertDividerBefore:v,onInsertDividerAfter:k,onDeleteCurrentBlock:S,resetSuperBlockWidth:B,applyCloverLayout:A,onAutoAnimateDocument:C}}function Mw(e){const{triggerSaveNotice:t,saveAttrs:i,saveAttr:n,savePageAttr:s,applyPageLayoutAndRatio:o,saveDocAttr:a}=mw(e),r=ww(e,{triggerSaveNotice:t}),l=Iw(e,{saveAttr:n,saveAttrs:i,savePageAttr:s,triggerSaveNotice:t,isBatchProcessing:r.isBatchProcessing});async function c(){var y;if(!e.latestDoc.value){ae.showMessage("请先在主编辑区打开幻灯片文档");return}const p=e.latestDoc.value,w=await Ei(p,(y=e.currentDocId)==null?void 0:y.value,e.plugin),m=Xl(p,{title:w});Ql(`${w}.html`,m)&&ae.showMessage(`已开始下载单文件离线 HTML 演示包 (${w}.html)`)}function u(){if(!e.latestDoc.value){ae.showMessage("请先在主编辑区打开幻灯片文档");return}ec(e.latestDoc.value)&&ae.showMessage("已唤起打印视窗，请在打印选项中选择「另存为 PDF」")}const f=ge(!1);async function d(){var p;if(f.value){ae.showMessage("正在导出图片中，请稍候...",2e3);return}if(!e.latestDoc.value){ae.showMessage("请先在主编辑区打开幻灯片文档");return}f.value=!0;try{ae.showMessage("正在启动后台沙箱并逐页导出幻灯片图片...");const w=e.latestDoc.value,m=await Ei(w,(p=e.currentDocId)==null?void 0:p.value,e.plugin),b=await oc(w,{title:m,onProgress:(y,v)=>{ae.showMessage(`正在导出幻灯片图片 (${y} / ${v})...`,2e3)}});b.success?ae.showMessage(`🎉 成功导出 ${b.total||0} 张幻灯片高清图片并已保存为 ${m}.zip！`,4e3):ae.showMessage(`导出图片失败：${b.error||"未知异常"}`)}finally{f.value=!1}}return{triggerSaveNotice:t,saveAttrs:i,saveAttr:n,savePageAttr:s,applyPageLayoutAndRatio:o,saveDocAttr:a,onToggleVideoAutoplay:l.onToggleVideoAutoplay,onToggleVideoLoop:l.onToggleVideoLoop,onToggleVideoMuted:l.onToggleVideoMuted,onToggleVideoControls:l.onToggleVideoControls,onImageRoleChange:l.onImageRoleChange,onToggleNoteBlock:r.onToggleNoteBlock,createNoteBlockOnCurrentSlide:r.createNoteBlockOnCurrentSlide,onAddNoteBlock:r.onAddNoteBlock,onLocateNoteBlock:r.onLocateNoteBlock,onGenerateNotesWithAI:r.onGenerateNotesWithAI,isBatchProcessing:r.isBatchProcessing,onBatchAppendNotes:r.onBatchAppendNotes,onBatchDeleteNotes:r.onBatchDeleteNotes,onIdentifyNotesBlocks:r.onIdentifyNotesBlocks,toggleElemClick:l.toggleElemClick,onElemClickStepChange:l.onElemClickStepChange,onElemMotionChange:l.onElemMotionChange,onElemSlotChange:l.onElemSlotChange,onElemShikiLinesChange:l.onElemShikiLinesChange,onElemMaxHeightChange:l.onElemMaxHeightChange,onSetTwoColsContrast:l.onSetTwoColsContrast,onClearBlockAttrs:l.onClearBlockAttrs,onInsertDividerBefore:l.onInsertDividerBefore,onInsertDividerAfter:l.onInsertDividerAfter,onDeleteCurrentBlock:l.onDeleteCurrentBlock,resetSuperBlockWidth:l.resetSuperBlockWidth,applyCloverLayout:l.applyCloverLayout,onAutoAnimateDocument:l.onAutoAnimateDocument,isExportingImages:f,onExportHtml:c,onExportPdf:u,onExportImages:d}}function Tw(e){const t=ye(()=>br(e.activeBlockType.value));function i(n){const{attrKey:s,fallback:o,mode:a="defined"}=n,r=l=>a==="truthy"?l:l!==void 0;return ye(()=>{if(t.value){const c=e.activeBlockAttrs.value[s];if(r(c))return c}const l=e.currentPageDividerId.value||(t.value?e.activeBlockId.value:"");if(l){const c=Le.getBlockAttrOverride(l);if(r(c==null?void 0:c[s]))return c[s]}return o()})}return{isDivider:t,resolvePageAttr:i}}function go(e){if(e.type==="h"){if(e.subType==="h1")return 1;if(e.subType==="h2")return 2;if(e.subType==="h3")return 3}const t=(e.markdown||e.content||"").trimStart();return t.startsWith("# ")?1:t.startsWith("## ")?2:t.startsWith("### ")?3:null}function Ew(e,t){for(let i=t-1;i>=0;i--){const n=e[i];if(ui(n)||(n.content||n.markdown||"").trim())return n}return null}function vo(e){const t=e.type;if(t==="c"||t==="code"||t==="t"||t==="table"||t==="s"||t==="super")return 3;if(t==="l"||t==="list"||t==="b"||t==="blockquote")return 2;const i=(e.markdown||e.content||"").trim();return i?i.includes("![")||i.includes("<img")||i.length>100?2:1:0}function ya(e,t){if(e===1)return"cover";let i=!1,n=-1;for(let r=0;r<t.length;r++){const l=t[r],c=(l.markdown||l.content||"").trim();if(c.includes("![")||c.includes("<img")||l.type==="img"){i=!0,n=r;break}}if(i)return n===0?"image-left":"image-right";let s=0,o=!1,a=!1;for(const r of t)(r.type==="i"||r.type==="l"||(r.markdown||"").trim().startsWith("- "))&&s++,r.type==="s"&&(o=!0),r.type==="b"&&(a=!0);return o||s>=3?"two-cols":a&&t.length<=2?"quote":"default"}function Aw(e,t){const i=[],n=new Set,s=6,o=6;let a=0,r=0,l=0,c=0,u=null;function f(d){const p=[];for(let w=d+1;w<e.length;w++){const m=e[w];if(ui(m))break;const b=go(m);if(b!==null&&(b===1||b===2||b===3))break;p.push(m)}return p}if(e.length>0){let d=!1,p=-1;for(let w=0;w<e.length;w++){const m=e[w];if(ui(m)){d=!0;break}if((m.content||m.markdown||"").trim()){p=w;break}}if(!d&&p>=0){const w=e[p],m=go(w);let b=m===1?"cover":"default";if(m!==1){const v=f(p);b=ya(m,v)}const y=m===1?"作为第一页起点插入分页线 (封面大章)":"作为第一页起点插入分页线";i.push({blockId:w.id,recommendedLayout:b,reason:y}),n.add(w.id)}}for(let d=0;d<e.length;d++){const p=e[d];if(ui(p)){a=0,r=0,l=0,c=0,u=null;continue}const w=Ew(e,d),m=!w||ui(w),b=go(p);if(b===1||b===2||b===3){if(!(l===1&&c===0&&u!==null&&!(u===1&&b===2))&&!m&&a>0&&!n.has(p.id)){let B=b===1?"cover":"default";{const C=f(d);B=ya(b,C)}let A=b===1?"检测到一级核心章节标题，建议作为新幻灯片封面/大章":b===2?"检测到二级分论点标题，建议开启新页":"检测到三级要点标题，建议开启新页";B==="image-right"||B==="image-left"?A+=" (推荐图文版式)":B==="two-cols"?A+=" (推荐双栏版式)":B==="quote"&&(A+=" (推荐引言版式)"),i.push({blockId:p.id,recommendedLayout:B,reason:A}),n.add(p.id),a=1,r=vo(p),l=1,c=0,u=b;continue}a++,r+=vo(p),l++,u=b;continue}const v=vo(p);if((a>=s||r+v>o&&a>0)&&!m&&a>0&&!n.has(p.id)){i.push({blockId:p.id,recommendedLayout:"default",reason:"当前页已达容量上限 (避免信息超载)，建议在此分页"}),n.add(p.id),a=1,r=v,l=0,c=1,u=null;continue}a++,r+=v,c++}return i}async function hc(e){if(!e.currentDocId&&typeof document<"u"){const o=document.querySelector(".protyle-content[data-doc-id]");e.currentDocId=(o==null?void 0:o.getAttribute("data-doc-id"))||""}if(!e.currentDocId){ae.showMessage("请先打开一篇思源笔记文档");return}const t=await mn(e.currentDocId).catch(()=>[]);if(!t||t.length===0){ae.showMessage("当前文档无内容，无需断页");return}const i=t.map(o=>({id:o.id,type:o.type,subType:o.subType,content:o.content||"",markdown:o.markdown||""})),n=Aw(i);if(n.length===0){ae.showMessage("智能分析完毕：当前文档结构合理，暂无新增分页建议");return}ae.showMessage(`智能分析完毕：发现 ${n.length} 处建议分页点，正在自动插入分页线...`);let s=0;for(const o of n)try{await Hi("markdown","---",o.blockId,void 0),await Fe(o.blockId,{"custom-slides-layout":o.recommendedLayout}),s++}catch(a){console.warn("Failed to insert divider:",a)}ae.showMessage(`已成功在 ${s} 处插入分页线并重新编译`),e.compileCurrentDocument(e.currentDocId)}async function mc(e){var o,a,r,l,c,u;if(!e.currentDocId&&typeof document<"u"){const f=document.querySelector(".protyle-content[data-doc-id]");e.currentDocId=(f==null?void 0:f.getAttribute("data-doc-id"))||""}if(!e.currentDocId){ae.showMessage("请先打开一篇思源笔记文档");return}const t=await mn(e.currentDocId).catch(()=>[]);if(!t||t.length===0){ae.showMessage("当前文档无内容");return}const i=[],n=[];for(const f of t)f.type==="tb"||f.type==="thematic-break"||f.type==="NodeThematicBreak"||((o=f.markdown)==null?void 0:o.trim())==="---"||((a=f.markdown)==null?void 0:a.trim())==="***"||f.type==="b"&&(((r=f.markdown)==null?void 0:r.trim())==="---"||((l=f.content)==null?void 0:l.trim())==="---")?i.push(f.id):((c=f.ial)!=null&&c[li]||(u=f.ial)!=null&&u[ke])&&n.push(f.id);if(i.length===0&&n.length===0){ae.showMessage("当前文档中未发现需要清除的幻灯片分页线");return}ae.showMessage(`正在清除文档中的 ${i.length} 处分页线...`);let s=0;for(const f of i)try{await Vo(f),s++}catch(d){console.warn("Failed to delete divider block:",d)}for(const f of n)try{await Fe(f,{[li]:"",[ke]:""})}catch(d){console.warn("Failed to clear slide attrs:",d)}ae.showMessage(`已成功清除文档中的 ${s} 处分页线并重新编译`),e.compileCurrentDocument(e.currentDocId)}const Bw={class:"spm-slides-inspector"},Dw={class:"spm-inspector-topbar"},Lw={class:"spm-inspector-title"},Pw={class:"slides-icon",style:{fill:"none !important"},"aria-hidden":"true",viewBox:"0 0 24 24"},Ow={class:"spm-inspector-topbar-actions"},Rw={class:"spm-target-banner"},Nw={class:"spm-target-info"},zw=["aria-label"],Hw={key:0,class:"spm-save-status"},Fw=["title"],jw={class:"spm-inspector-body"},Ww=Dt({__name:"SlidesInspectorDockView",setup(e,{expose:t}){const i=zt("plugin"),n=ge(!1);function s(Q){n.value=!1,c.value=Q.docId,i!=null&&i.compileCurrentDocument&&i.compileCurrentDocument(Q.docId)}const o=ge(""),a=ge(""),r=ge({}),l=ge(""),c=ge(""),u=ge(""),f=ge(""),d=ge(""),p=ge(""),w=ge(""),m=ge(""),b=ge(null),y=ge(""),v=ge("");function k(){var ve;const Q=o.value||c.value;Q&&typeof navigator<"u"&&(ve=navigator==null?void 0:navigator.clipboard)!=null&&ve.writeText&&navigator.clipboard.writeText(Q).then(()=>{v.value="已复制！",setTimeout(()=>{v.value=""},1500)}).catch(()=>{})}const S=ye(()=>br(a.value)),B=ye(()=>a.value==="NodeCodeBlock"),A=ge(!1),C=ye(()=>{if(A.value||ze.value)return!0;const Q=l.value||"";return!!hi(Q)}),L=ye(()=>{const Q=a.value||"";if(Q==="NodeVideo"||Q==="video")return!0;const ve=l.value||"";return!!(/<video\b/i.test(ve)||/\.mp4\b/i.test(ve))}),z=ye(()=>!o.value||o.value===c.value||a.value==="doc"||a.value==="NodeDocument"),N=ye(()=>{const Q=o.value||c.value||"";return Q.length>8?Q.slice(-8):Q||"无"}),K=ye(()=>l.value?l.value.replace(/<[^>]+>/g,"").replace(/[\r\n]+/g," ").trim().slice(0,45):""),_=ye(()=>{if(S.value)return"分页符 (---)";if(z.value)return"全局文档";if(L.value)return"视频块";let Q="内容块";switch(a.value){case"NodeHeading":Q="标题块";break;case"NodeParagraph":Q="段落块";break;case"NodeCodeBlock":Q="代码块";break;case"NodeVideo":Q="视频块";break;case"NodeList":case"NodeListItem":Q="列表项";break;case"NodeBlockquote":Q="引述块";break;case"NodeTable":Q="表格块";break;case"NodeSuperBlock":case"s":case"sb":Q="超级块";break;default:Q="内容块";break}return p.value?w.value?`${w.value.replace(/^col-(\d+)$/,"第 $1 栏")} › ${Q}`:`分栏容器 › ${Q}`:Q}),U=ye(()=>S.value?"tag-divider":z.value?"tag-doc":"tag-block"),x=ye(()=>r.value[ke]||"default"),q=ye(()=>r.value[vt]||"slide-left"),O=ge(""),$=ge(""),T=ye(()=>r.value[Tn]||"inherit"),P=ye(()=>{var Q;return fw((Q=b.value)==null?void 0:Q.slides,{activeBlockId:o.value,activeBlockType:a.value,currentTopBlockId:u.value,currentPageDividerId:f.value,activeBlockAttrs:r.value})}),se=ye(()=>{var Q;return((Q=P.value)==null?void 0:Q.notes)||""}),V=ye(()=>{var Q,ve,Ae;return((Ae=(ve=(Q=P.value)==null?void 0:Q.noteBlocks)==null?void 0:ve[0])==null?void 0:Ae.id)||""}),Y=ye(()=>{var Ge,Ke,Re,ft,ts,ki;if(S.value){const it=r.value[ke]||r.value["custom-slides-layout"];if(it)return it}const Q=r.value[Me]||r.value["custom-slides-slot"];if(Q&&(["col-1","col-2","col-3"].includes(Q)||/^col-\d+$/.test(Q)))return"cols-header";if(d.value)return d.value;const ve=f.value||(S.value?o.value:"");if(ve){const it=Le.getBlockAttrOverride(ve);if(it!=null&&it[ke])return it[ke]}if(ve&&((Ge=b.value)!=null&&Ge.slides)){const it=b.value.slides.find(Yi=>Yi.startBlockId===ve);if((Ke=it==null?void 0:it.frontmatter)!=null&&Ke.layout)return it.frontmatter.layout}if((ft=(Re=P.value)==null?void 0:Re.frontmatter)!=null&&ft.layout)return P.value.frontmatter.layout;if((ki=(ts=P.value)==null?void 0:ts.blocks)!=null&&ki.some(it=>it.slot&&(["col-1","col-2","col-3"].includes(it.slot)||/^col-\d+$/.test(it.slot))))return"cols-header";const Ae=Le.getBlockAttrOverride(c.value);return Ae!=null&&Ae[ke]?Ae[ke]:"default"}),ce=Tw({activeBlockId:o,activeBlockType:a,activeBlockAttrs:r,currentPageDividerId:f}),ie=ce.resolvePageAttr({attrKey:bt,mode:"truthy",fallback:()=>{var Q,ve;return((ve=(Q=P.value)==null?void 0:Q.frontmatter)==null?void 0:ve.layoutRatio)||""}}),re=ce.resolvePageAttr({attrKey:tn,fallback:()=>{var Q,ve;return((ve=(Q=P.value)==null?void 0:Q.frontmatter)==null?void 0:ve.mask)||""}}),Se=ce.resolvePageAttr({attrKey:ji,fallback:()=>{var Q,ve;return((ve=(Q=P.value)==null?void 0:Q.frontmatter)==null?void 0:ve.maskRatio)||""}}),Ie=ce.resolvePageAttr({attrKey:nn,fallback:()=>{var Q,ve;return((ve=(Q=P.value)==null?void 0:Q.frontmatter)==null?void 0:ve.maskStyle)||"solid"}}),_e=ce.resolvePageAttr({attrKey:sn,fallback:()=>{var Q,ve;return((ve=(Q=P.value)==null?void 0:Q.frontmatter)==null?void 0:ve.maskInitial)||"hidden"}});function fe(Q){if(!Q||(Q.getAttribute("data-sb-layout")||"").toLowerCase()!=="col")return null;const Ae=Array.from(Q.querySelectorAll(":scope > [data-node-id]"));if(Ae.length<2)return null;const Ge=Ae.length,Ke=Ae.map(ki=>{const it=ki.getAttribute("style")||"",Yi=it.match(/calc\(\s*([\d.]+)%/);if(Yi)return parseFloat(Yi[1]);const wn=it.match(/(?:^|;|\s)width:\s*([\d.]+)%/i);return wn?parseFloat(wn[1]):null});let Re="",ft=!1;if(Ke.some(ki=>ki!==null)){ft=!0;const ki=Ke.reduce((Pe,pt)=>Pe+(pt||0),0),it=Ke.filter(Pe=>Pe===null).length,Yi=it>0?Math.max(0,100-ki)/it:100/Ae.length,wn=Ke.map(Pe=>Pe!==null?Pe:Yi),ad=wn.reduce((Pe,pt)=>Pe+pt,0)||1,xn=wn.map(Pe=>Pe/ad*100);if(xn.length===2){const[Pe]=xn;if(Pe>=48&&Pe<=52)Re="1:1";else if(Pe>=31&&Pe<=35)Re="1:2";else if(Pe>=65&&Pe<=69)Re="2:1";else if(Pe>=28&&Pe<=32)Re="3:7";else if(Pe>=68&&Pe<=72)Re="7:3";else if(Pe>=38&&Pe<=42)Re="4:6";else if(Pe>=58&&Pe<=62)Re="6:4";else{const pt=Math.round(Pe);Re=`${pt}:${100-pt}`}}else if(xn.length===3){const[Pe,pt,wi]=xn;if(Pe>=31&&Pe<=35&&pt>=31&&pt<=35&&wi>=31&&wi<=35)Re="1:1:1";else if(Pe>=23&&Pe<=27&&pt>=48&&pt<=52&&wi>=23&&wi<=27)Re="1:2:1";else if(Pe>=48&&Pe<=52&&pt>=23&&pt<=27&&wi>=23&&wi<=27)Re="2:1:1";else if(Pe>=23&&Pe<=27&&pt>=23&&pt<=27&&wi>=48&&wi<=52)Re="1:1:2";else{const Sr=Math.round(Pe),Cr=Math.round(pt);Re=`${Sr}:${Cr}:${100-Sr-Cr}`}}else Re=xn.map(Pe=>Math.round(Pe)).join(":")}else ft=!1,Re=Array.from({length:Ge},()=>1).join(":");const ts=Ge>=2?"cols-header":"two-cols";return{hasSuperBlock:!0,colCount:Ge,ratio:Re,isCustomWidth:ft,recommendedLayout:ts}}function X(Q){if(!(Q!=null&&Q.blocks))return null;for(const ve of Q.blocks){const Ae=ve.rawNode;if(Ae&&at(Ae)&&ei(Ae)){const Ke=yn(Ae).length,Re=pr(Ae);return{hasSuperBlock:!0,colCount:Ke,ratio:Re||Array.from({length:Ke},()=>1).join(":"),isCustomWidth:!!Re,recommendedLayout:Ke>=2?"cols-header":"two-cols"}}}return null}const pe=ye(()=>{var Q;if(typeof document<"u"){const ve=o.value;if(ve){const Ge=document.querySelector(`.protyle-wysiwyg [data-node-id="${ve}"]`);if(Ge){const Ke=Ge.getAttribute("data-type")==="NodeSuperBlock"?Ge:Ge.closest('[data-type="NodeSuperBlock"]');if(Ke){const Re=fe(Ke);if(Re)return Re}}}const Ae=f.value||(S.value?o.value:"");if(Ae){const Ge=document.querySelector(`.protyle-wysiwyg [data-node-id="${Ae}"]`);if(Ge){let Ke=Ge.nextElementSibling;for(;Ke&&!(Ke.getAttribute("data-type")==="NodeThematicBreak"||(Q=Ke.classList)!=null&&Q.contains("protyle-wysiwyg__block--hr"));){const Re=Ke.getAttribute("data-type")==="NodeSuperBlock"?Ke:Ke.querySelector('[data-type="NodeSuperBlock"]');if(Re){const ft=fe(Re);if(ft)return ft}Ke=Ke.nextElementSibling}}}else{const Ge=document.querySelector('.protyle-wysiwyg [data-type="NodeThematicBreak"], .protyle-wysiwyg .protyle-wysiwyg__block--hr'),Ke=Array.from(document.querySelectorAll('.protyle-wysiwyg [data-type="NodeSuperBlock"]'));for(const Re of Ke)if(!Ge||Re.compareDocumentPosition(Ge)&Node.DOCUMENT_POSITION_FOLLOWING){const ft=fe(Re);if(ft)return ft}}}return X(P.value)}),E=ye(()=>{var Q;return((Q=pe.value)==null?void 0:Q.ratio)||""}),F=ye(()=>{const Q=a.value||"";if(Q==="NodeSuperBlock"||Q==="s"||Q==="sb")return!0;if(typeof document<"u"&&o.value){const ve=document.querySelector(`.protyle-wysiwyg [data-node-id="${o.value}"]`);if(ve!=null&&ve.closest('[data-type="NodeSuperBlock"]'))return!0}return!1}),g=ye(()=>{var Q;return((Q=P.value)==null?void 0:Q.pageIndex)||1}),W=ye(()=>!!(r.value[qe]||r.value["slides-note"]));function j(){if(!p.value)return!1;if(o.value===p.value||typeof document>"u")return!0;const Q=document.querySelector(`.protyle-wysiwyg [data-node-id="${p.value}"]`)||document.querySelector(`[data-node-id="${p.value}"]`);if(!Q)return!1;const ve=Q.querySelector(":scope > [data-node-id], :scope > div > [data-node-id]");return(ve==null?void 0:ve.getAttribute("data-node-id"))===o.value}const M=ye(()=>{var ve;if(r.value[Ne]!==void 0)return r.value[Ne]||"";if(p.value&&j())return m.value||"";if(p.value)return"";const Q=o.value;if(Q&&((ve=P.value)!=null&&ve.blocks)){const Ae=P.value.blocks.find(Ge=>Ge.id===Q);if(Ae!=null&&Ae.clicks)return Ae.clicks}return""}),I=ye(()=>{var ve;if(r.value[Xt])return r.value[Xt];const Q=o.value;if(Q&&((ve=P.value)!=null&&ve.blocks)){const Ae=P.value.blocks.find(Ge=>Ge.id===Q);if(Ae!=null&&Ae.motion)return typeof Ae.motion=="string"?Ae.motion:JSON.stringify(Ae.motion)}return""}),R=ye(()=>{var ve;if(r.value[Me])return r.value[Me];const Q=o.value;if(Q&&((ve=P.value)!=null&&ve.blocks)){const Ae=P.value.blocks.find(Ge=>Ge.id===Q);if(Ae!=null&&Ae.slot)return Ae.slot}return""}),G=ge(""),D=ge(""),H=ye(()=>r.value[zi]==="true"),Z=ye(()=>r.value[xs]==="true"),te=ye(()=>r.value[Qi]==="true"),ne=ye(()=>r.value[Ss]!=="false"),me=ye(()=>{var Q,ve;return((ve=(Q=b.value)==null?void 0:Q.config)==null?void 0:ve.theme)||r.value[zn]||"default"}),$e=ye(()=>{var Q,ve;return((ve=(Q=b.value)==null?void 0:Q.config)==null?void 0:ve.aspectRatio)||r.value[Hn]||"16/9"}),xe=ye(()=>{var Q,ve;return((ve=(Q=b.value)==null?void 0:Q.config)==null?void 0:ve.defaultTransition)||r.value[Fn]||"slide-left"}),De=ye(()=>{var Q,ve;return((ve=(Q=b.value)==null?void 0:Q.config)==null?void 0:ve.spacing)||r.value[Co]||"normal"}),je=ye(()=>{var Q,ve;return((ve=(Q=b.value)==null?void 0:Q.config)==null?void 0:ve.background)||r.value[ws]||""}),ze=ye(()=>{var Ke,Re;if((r.value[Ze]||r.value["slides-role"])===Ta||r.value[st]==="true")return"background";const ve=r.value[ke]||r.value["slides-layout"];if(ve==="image-left"||ve==="image-right")return ve;const Ae=l.value||"",Ge=hi(Ae);if(Ge&&((Re=(Ke=P.value)==null?void 0:Ke.frontmatter)!=null&&Re.background)){const ft=P.value.frontmatter.background;if(ft===Ge||ft.endsWith(Ge)||Ge.endsWith(ft))return"background"}return""}),le=ye(()=>!!(r.value[Ne]||r.value[Xt]||r.value[Me]||r.value[Ki]||r.value[qe]||r.value["slides-note"]||r.value[Ze]||r.value[ke]||r.value[zi]||r.value[xs]||r.value[Qi]||r.value[Ss])),{saveAttr:ue,savePageAttr:Oe,applyPageLayoutAndRatio:He,applyCloverLayout:We,resetSuperBlockWidth:lt,saveDocAttr:Et,onToggleVideoAutoplay:Zs,onToggleVideoLoop:Js,onToggleVideoMuted:es,onToggleVideoControls:Di,onImageRoleChange:qi,onToggleNoteBlock:kc,onAddNoteBlock:wc,onLocateNoteBlock:xc,onGenerateNotesWithAI:Sc,isBatchProcessing:yr,onBatchAppendNotes:Cc,onBatchDeleteNotes:_c,onIdentifyNotesBlocks:$c,onAutoAnimateDocument:Ic,toggleElemClick:Mc,onElemClickStepChange:Tc,onElemMotionChange:Ec,onElemSlotChange:Ac,onElemShikiLinesChange:Bc,onElemMaxHeightChange:Dc,onSetTwoColsContrast:Lc,onClearBlockAttrs:Pc,onInsertDividerBefore:Oc,onInsertDividerAfter:kr,onDeleteCurrentBlock:Rc,onExportHtml:Nc,onExportPdf:zc,onExportImages:Hc,isExportingImages:Fc}=Mw({activeBlockId:o,activeBlockType:a,activeBlockAttrs:r,rawSnippet:l,currentDocId:c,currentPageDividerId:f,currentPageDividerLayout:d,parentContainerId:p,parentContainerClicks:m,latestDoc:b,targetSlide:P,currentSlideNoteBlockId:V,currentSlideLayout:Y,isNoteBlock:W,elemClick:M,videoAutoplay:H,videoLoop:Z,videoMuted:te,videoControls:ne,pageBackground:O,pageImage:$,elemShikiLines:G,elemMaxHeight:D,saveStatus:y,plugin:i});async function jc(Q){if(Q==="clover"){if(!await We())return}else Oe(ke,Q)}function Wc(Q){Oe(bt,Q)}async function Uc(Q){await Oe(tn,Q),(Q==="clockwise"||Q==="counter-clockwise"||Q==="cw"||Q==="ccw")&&(!Se.value||Se.value==="1:1")&&await Oe(ji,"1:1:1:1")}function Vc(Q){Oe(ji,Q)}function Gc(Q){Oe(nn,Q)}function Kc(Q){Oe(sn,Q)}function wr(Q){if(!Q)return;const ve=Q.recommendedLayout||(Q.colCount&&Q.colCount>=2?"cols-header":"two-cols"),Ae=Q.ratio||(Q.colCount?Array(Q.colCount).fill(1).join(":"):"1:1");He(ve,Ae)}function qc(Q){Oe(bt,Q)}async function Yc(){await lt()}function Zc(Q){ue(vt,Q)}function Jc(Q){$.value=Q,ue(Rt,Q)}function Xc(Q){ue(Tn,Q==="inherit"?"":Q)}function Qc(Q){Et(zn,Q)}function ed(Q){Et(ws,Q)}function td(Q){Et(Hn,Q)}function id(Q){Et(Fn,Q)}function nd(Q){Et(Co,Q)}function xr(){i!=null&&i.openBottomPreviewTab&&i.openBottomPreviewTab()}function sd(){i!=null&&i.openPresenterTab&&i.openPresenterTab()}function od(){i&&gt("aiScript")&&hc(i)}function rd(){i&&gt("aiScript")&&mc(i)}return t({setActiveBlock(Q){o.value=Q.id,a.value=Q.type,r.value={...Q.attrs},l.value=Q.content||Q.markdown||"",u.value=Q.topBlockId||Q.id,f.value=Q.pageDividerId||"",d.value=Q.pageDividerLayout||"",p.value=Q.parentContainerId||"",w.value=Q.parentContainerSlot||"",m.value=Q.parentContainerClicks||"",Q.rootId?c.value=Q.rootId:(Q.type==="doc"||Q.type==="NodeDocument")&&Q.id&&(c.value=Q.id),O.value=Q.attrs[st]||"",$.value=Q.attrs[Rt]||"",G.value=Q.attrs[Ki]||"",D.value=Q.attrs[jn]||"",A.value=!!Q.isImage},updateDocument(Q){b.value=Q,c.value=Q.docId},openImportDialog(){n.value=!0},setCurrentDocId(Q){c.value=Q}}),(Q,ve)=>(J(),ee("div",Bw,[h("div",Dw,[h("div",Lw,[(J(),ee("svg",Pw,[...ve[2]||(ve[2]=[h("rect",{x:"2",y:"3",width:"20",height:"14",rx:"2"},null,-1),h("line",{x1:"8",y1:"21",x2:"16",y2:"21"},null,-1),h("line",{x1:"12",y1:"17",x2:"12",y2:"21"},null,-1)])])),ve[3]||(ve[3]=h("span",null,"演示配置",-1))]),h("div",Ow,[he(gt)("import")?(J(),ee("button",{key:0,class:"spm-icon-btn b3-tooltips b3-tooltips__sw","aria-label":"导入 Slidev 演示文档 (.md / .zip)",onClick:ve[0]||(ve[0]=Ae=>n.value=!0)},[oe(de,{name:"import"}),ve[4]||(ve[4]=h("span",null,"导入",-1))])):Te("",!0),h("button",{class:"spm-icon-btn is-primary b3-tooltips b3-tooltips__sw","aria-label":"在下方分屏开启幻灯片预览 (Alt+P)",onClick:xr},[oe(de,{name:"split-preview"}),ve[5]||(ve[5]=h("span",null,"分屏预览",-1))])])]),h("div",Rw,[h("div",Nw,[h("span",{class:Ce(["spm-target-tag",U.value])},we(_.value),3),h("span",{class:"spm-target-id b3-tooltips b3-tooltips__se","aria-label":v.value||"点击复制 ID: "+(o.value||c.value),onClick:k},[oe(de,{name:"copy"}),h("span",null,"#"+we(N.value),1)],8,zw)]),y.value?(J(),ee("span",Hw,"● "+we(y.value),1)):Te("",!0)]),K.value?(J(),ee("div",{key:0,class:"spm-context-quote",title:l.value},we(K.value),9,Fw)):Te("",!0),h("div",jw,[S.value?(J(),Jt(w1,{key:0,"page-layout":x.value,"page-layout-ratio":he(ie),"page-mask":he(re),"page-mask-ratio":he(Se),"page-mask-style":he(Ie),"page-mask-initial":he(_e),"detected-sb-ratio":E.value,"detected-sb-info":pe.value,"page-transition":q.value,"page-spacing":T.value,"page-image":$.value,"page-notes":se.value,"page-index":g.value,"onUpdate:pageLayout":jc,"onUpdate:pageLayoutRatio":Wc,"onUpdate:pageMask":Uc,"onUpdate:pageMaskRatio":Vc,"onUpdate:pageMaskStyle":Gc,"onUpdate:pageMaskInitial":Kc,onApplySuperBlockLayout:wr,onResetSuperblockRatio:Yc,"onUpdate:pageTransition":Zc,"onUpdate:pageSpacing":Xc,"onUpdate:pageImage":Jc,onAddNoteBlock:he(wc),onLocateNoteBlock:he(xc),onGenerateNotes:he(Sc),onBatchAppendNotes:he(Cc),onBatchDeleteNotes:he(_c),"is-batch-processing":he(yr),onInsertDividerAfter:he(kr),onDeleteDivider:he(Rc)},null,8,["page-layout","page-layout-ratio","page-mask","page-mask-ratio","page-mask-style","page-mask-initial","detected-sb-ratio","detected-sb-info","page-transition","page-spacing","page-image","page-notes","page-index","onAddNoteBlock","onLocateNoteBlock","onGenerateNotes","onBatchAppendNotes","onBatchDeleteNotes","is-batch-processing","onInsertDividerAfter","onDeleteDivider"])):o.value&&!z.value?(J(),Jt(o0,{key:1,"elem-click":M.value,"elem-motion":I.value,"elem-slot":R.value,"elem-shiki-lines":G.value,"elem-max-height":D.value,"is-code-block":B.value,"is-image":C.value,"is-video":L.value,"is-super-block":F.value,"detected-sb-info":pe.value,"video-autoplay":H.value,"video-loop":Z.value,"video-muted":te.value,"video-controls":ne.value,"has-block-attrs":le.value,"is-note":W.value,"image-role":ze.value,"current-slide-layout":Y.value,"parent-elem-click":m.value,"parent-container-slot":w.value,"parent-container-id":p.value,onToggleNote:he(kc),onToggleElemClick:he(Mc),onToggleVideoAutoplay:he(Zs),onToggleVideoLoop:he(Js),onToggleVideoMuted:he(es),onToggleVideoControls:he(Di),"onUpdate:imageRole":he(qi),"onUpdate:elemClick":he(Tc),"onUpdate:elemMotion":he(Ec),"onUpdate:elemSlot":he(Ac),"onUpdate:elemShikiLines":he(Bc),"onUpdate:elemMaxHeight":he(Dc),onApplySuperBlockLayout:wr,onApplySuperBlockRatio:qc,onInsertDividerBefore:he(Oc),onInsertDividerAfter:he(kr),onSetTwoColsContrast:he(Lc),onClearBlockAttrs:he(Pc)},null,8,["elem-click","elem-motion","elem-slot","elem-shiki-lines","elem-max-height","is-code-block","is-image","is-video","is-super-block","detected-sb-info","video-autoplay","video-loop","video-muted","video-controls","has-block-attrs","is-note","image-role","current-slide-layout","parent-elem-click","parent-container-slot","parent-container-id","onToggleNote","onToggleElemClick","onToggleVideoAutoplay","onToggleVideoLoop","onToggleVideoMuted","onToggleVideoControls","onUpdate:imageRole","onUpdate:elemClick","onUpdate:elemMotion","onUpdate:elemSlot","onUpdate:elemShikiLines","onUpdate:elemMaxHeight","onInsertDividerBefore","onInsertDividerAfter","onSetTwoColsContrast","onClearBlockAttrs"])):(J(),Jt(dk,{key:2,"doc-theme":me.value,"doc-background":je.value,"doc-aspect-ratio":$e.value,"doc-default-transition":xe.value,"doc-spacing":De.value,"is-exporting-images":he(Fc),"is-batch-processing":he(yr),"onUpdate:docTheme":Qc,"onUpdate:docBackground":ed,"onUpdate:docAspectRatio":td,"onUpdate:docDefaultTransition":id,"onUpdate:docSpacing":nd,onOpenBottomPreview:xr,onOpenPresenter:sd,onIdentifyNotes:he($c),onAutoAnimate:he(Ic),onAiAutoSplit:od,onClearDividers:rd,onExportHtml:he(Nc),onExportPdf:he(zc),onExportImages:he(Hc)},null,8,["doc-theme","doc-background","doc-aspect-ratio","doc-default-transition","doc-spacing","is-exporting-images","is-batch-processing","onIdentifyNotes","onAutoAnimate","onExportHtml","onExportPdf","onExportImages"]))]),n.value&&he(gt)("import")?(J(),Jt(uw,{key:1,onClose:ve[1]||(ve[1]=Ae=>n.value=!1),onSuccess:s})):Te("",!0)]))}}),Uw=2e3,Vw=600;function Gw(e){return!e||typeof e.closest!="function"?!1:!!e.closest(".fn__none")}function bo(e){if(!e||typeof e.isConnected=="boolean"&&!e.isConnected)return!1;if(ka(e))return!0;const t=e.firstElementChild;return!!(t&&ka(t))}function ka(e){return typeof e.getClientRects=="function"&&e.getClientRects().length>0?!0:typeof e.offsetWidth=="number"&&e.offsetWidth>0&&e.offsetHeight>0}function Kw(){const e=typeof globalThis<"u"?globalThis.IntersectionObserver:void 0;return typeof e=="function"?e:void 0}class qw{constructor(){be(this,"consumers",new Map);be(this,"seq",0);be(this,"verifyTimer",null)}register(t,i,n){if(!i)return()=>{};const s=++this.seq,o=Kw(),a={kind:t,element:i,visible:!1,measureOnDemand:!o,observer:null,onVisible:n};return o?(a.observer=new o(r=>{var u;const l=r[r.length-1];if(!l)return;const c=l.isIntersecting&&!a.visible;a.visible=l.isIntersecting,c&&((u=a.onVisible)==null||u.call(a))}),a.observer.observe(i)):a.visible=bo(i),this.consumers.set(s,a),()=>{var r;(r=a.observer)==null||r.disconnect(),this.consumers.delete(s),this.consumers.size===0&&this.stopVerifyTimer()}}clear(){var t;for(const i of this.consumers.values())(t=i.observer)==null||t.disconnect();this.consumers.clear(),this.stopVerifyTimer()}get size(){return this.consumers.size}getVisibility(){if(this.consumers.size===0)return"none";if(typeof document<"u"&&document.visibilityState==="hidden")return"hidden";for(const t of this.consumers.values())if(t.measureOnDemand?bo(t.element):this.isRecordVisible(t))return"visible";return this.ensureVerifyTimer(),"hidden"}hasVisibleConsumer(){return this.getVisibility()==="visible"}isRecordVisible(t){return t.visible?!0:!Gw(t.element)}ensureVerifyTimer(){if(this.verifyTimer!==null||typeof setTimeout!="function")return;let t=!1;for(const i of this.consumers.values())if(!i.measureOnDemand){t=!0;break}t&&(this.verifyTimer=setTimeout(()=>{var i;this.verifyTimer=null;for(const n of this.consumers.values())if(!n.visible&&bo(n.element)){n.visible=!0,(i=n.onVisible)==null||i.call(n);return}},Uw))}stopVerifyTimer(){this.verifyTimer!==null&&(clearTimeout(this.verifyTimer),this.verifyTimer=null)}}const bs=new qw,kn=new Qn;function gc(e,t,i){const n=()=>{var o;try{(o=i==null?void 0:i.flushDirtyCompile)==null||o.call(i)}catch{}},s=bs.register(e,t,n);return n(),s}let $i=null,Lt=null,ys=null;function Yw(){return Lt}function Zw(e,t){$i&&vc(),$i=ur(jg),$i.provide("plugin",t),$i.provide("sandboxBridge",kn);const i=$i.mount(e);return Lt=i,ys=gc("preview",e,t),i}function vc(e){ys&&(ys(),ys=null),$i&&($i.unmount(),$i=null,Lt=null)}function Jw(){return Lt!==null}let Ii=null,Fi=null;function Xw(e,t){return Ii&&bc(),Ii=ur(Xv),Ii.provide("plugin",t),Ii.provide("sandboxBridge",kn),Fi=Ii.mount(e),Fi}function bc(e){Ii&&(Ii.unmount(),Ii=null,Fi=null)}function Qw(e){try{const t=new BroadcastChannel("siyuan-slides-sync");t.postMessage({type:"SYNC_SLIDES",slides:e.slides||[],config:e.config||{}}),t.close()}catch{}}let Mi=null,Mt=null,ks=null;function e2(e,t){Mi&&yc(),Mi=ur(Ww),Mi.provide("plugin",t),Mi.provide("sandboxBridge",kn);const i=Mi.mount(e);return Mt=i,ks=gc("dock",e,t),i}function yc(e){ks&&(ks(),ks=null),Mi&&(Mi.unmount(),Mi=null,Mt=null)}function t2(e,t){Mt!=null&&Mt.updateDocument&&Mt.updateDocument(e),Lt!=null&&Lt.updateDocument?Lt.updateDocument(e,t):(kn.updateSlides(e.slides,e.config,e.fullMarkdown),Qw(e)),Fi!=null&&Fi.updateDocument&&Fi.updateDocument(e)}function Uo(e){Lt!=null&&Lt.navigateToBlock?Lt.navigateToBlock(e):kn.highlightElement(e)}function Xi(e){Mt!=null&&Mt.setActiveBlock&&Mt.setActiveBlock(e)}function i2(){return ai("import")?!1:Mt!=null&&Mt.openImportDialog?(Mt.openImportDialog(),!0):!1}const n2=[{id:"slides-cover",name:"幻灯片 - 封面页 (Cover)",open:!0,attrs:[{key:li,value:"true"},{key:ke,value:"cover"},{key:vt,value:"fade"}]},{id:"slides-two-cols",name:"幻灯片 - 双栏对比 (Two Columns)",open:!0,attrs:[{key:li,value:"true"},{key:ke,value:"two-cols"},{key:vt,value:"slide-left"}]},{id:"slides-fact",name:"幻灯片 - 大字报与核心指标 (Fact)",open:!0,attrs:[{key:li,value:"true"},{key:ke,value:"fact"},{key:vt,value:"zoom"}]},{id:"slides-intro",name:"幻灯片 - 章节导引与作者 (Intro)",open:!0,attrs:[{key:li,value:"true"},{key:ke,value:"intro"},{key:vt,value:"slide-up"}]},{id:"slides-quote",name:"幻灯片 - 金句与强调 (Quote)",open:!0,attrs:[{key:li,value:"true"},{key:ke,value:"quote"},{key:vt,value:"fade"}]},{id:"slides-elem-click",name:"元素 - 顺延逐步呈现 (v-click)",open:!0,attrs:[{key:Ne,value:"+1"}]},{id:"slides-elem-click-hide",name:"元素 - 隐藏直到激活 (v-click:hide)",open:!0,attrs:[{key:Ne,value:"hide"}]},{id:"slides-elem-slot-right",name:"元素 - 双栏右栏归属 (Slot: Right)",open:!0,attrs:[{key:Me,value:"right"}]},{id:"slides-shiki-lines",name:"代码 - 逐行聚光高亮 (Shiki)",open:!0,attrs:[{key:Ki,value:"1-3"}]}];class yo{getPresetTemplates(){return n2}buildScanSlidesBlocksSql(t="custom-slides-"){return`SELECT block_id, name, value FROM attributes WHERE name LIKE '${t}%' ORDER BY block_id ASC`}buildTransitionStatsSql(){return`SELECT value, count(1) as count FROM attributes WHERE name = '${vt}' GROUP BY value ORDER BY count DESC`}async batchUpdateTransitions(t,i,n,s){const o=`SELECT block_id FROM attributes WHERE name = '${vt}' AND value = '${t}'`,a=await n(o);let r=0;if(Array.isArray(a))for(const l of a){const c=l.block_id||l.blockId;c&&(await s(c,{[vt]:i}),r++)}return{updatedCount:r}}async batchUpdateLayout(t,i,n,s){const o=`SELECT block_id FROM attributes WHERE name = '${ke}' AND value = '${t}'`,a=await n(o);let r=0;if(Array.isArray(a))for(const l of a){const c=l.block_id||l.blockId;c&&(await s(c,{[ke]:i}),r++)}return{updatedCount:r}}exportTemplatesJson(){const t=this.getPresetTemplates();return JSON.stringify({templates:t,counter:t.length},null,2)}formatTransitionSummary(t){return!t||t.length===0?"全库目前暂无已设置即现转场效果的块":`全库即现转场分布统计：${t.map(n=>`${n.value}: ${n.count} 个`).join("，")}`}}function s2(e){if(e.addCommand({langKey:"slidesPresentation",langText:"即现: 在文档下方开启分屏演示预览",hotkey:"⌥P",enabled:()=>!0,execute:()=>{e.openBottomPreviewTab()}}),ai("import")||e.addCommand({langKey:"slidesImport",langText:"即现: 导入 Slidev 演示文档 (.md / .zip)",hotkey:"⌥I",enabled:()=>!0,execute:()=>{i2()||ae.showMessage("请先在右侧栏打开「即现演示配置」Dock 面板以呼起导入窗口")}}),e.addCommand({langKey:"slidesInitAttrs",langText:"即现: 初始化当前文档演示属性",hotkey:"",enabled:()=>!0,execute:async()=>{if(!e.currentDocId){const t=document.querySelector(".protyle-content[data-doc-id]");e.currentDocId=(t==null?void 0:t.getAttribute("data-doc-id"))||""}e.currentDocId&&(await Fe(e.currentDocId,{"custom-slides-theme":"default","custom-slides-aspect-ratio":"16/9","custom-slides-default-transition":"slide-left"}),ae.showMessage("已为当前文档初始化即现演示属性"),e.compileCurrentDocument(e.currentDocId))}}),ai("aiScript")||(e.addCommand({langKey:"slidesAiSplit",langText:"即现: 智能大纲断页建议与自动分页",hotkey:"",enabled:()=>!0,execute:()=>hc(e)}),e.addCommand({langKey:"slidesClearDividers",langText:"即现: 清除当前文档分页线",hotkey:"",enabled:()=>!0,execute:()=>mc(e)})),ai("aiScript")||e.addCommand({langKey:"slidesAiNotes",langText:"即现 AI: 自动为当前文档生成演讲者提词卡 (Notes)",hotkey:"",enabled:()=>!0,execute:async()=>{var l,c,u,f;if(!e.currentDocId){const d=document.querySelector(".protyle-content[data-doc-id]");e.currentDocId=(d==null?void 0:d.getAttribute("data-doc-id"))||""}if(!e.currentDocId){ae.showMessage("请先打开一篇思源笔记文档");return}ae.showMessage("正在调用思源 AI 提炼演讲者口播提词...");const t=await mn(e.currentDocId).catch(()=>[]),i={startBlockId:e.currentDocId,blocks:t.map(d=>({id:d.id,type:d.type,content:d.content||"",rawMarkdown:d.markdown||""})),rawMarkdown:""},o=`> [!NOTE] 💡 演讲备注
${(await gw(i,Ca)).split(/\r?\n/).map(d=>`> ${d}`).join(`
`)}
{: custom-slides-note="true"}`,a=await wo("markdown",o,e.currentDocId).catch(()=>null),r=((u=(c=(l=a==null?void 0:a[0])==null?void 0:l.doOperations)==null?void 0:c[0])==null?void 0:u.id)||((f=a==null?void 0:a[0])==null?void 0:f.id);r&&(await Fe(r,{"custom-slides-note":"true"}),Le.setBlockAttrOverride(r,{"custom-slides-note":"true"}),Gi(r,e.app)),ae.showMessage("已成功生成口播提词卡并插入为正文讲稿备注块"),e.compileCurrentDocument(e.currentDocId)}}),e.addCommand({langKey:"slidesIdentifyNotes",langText:"即现演示: 识别正文讲稿块并规范化",hotkey:"",enabled:()=>!0,execute:async()=>{let t=e.currentDocId;if(!t){const i=document.querySelector(".protyle-content[data-doc-id]");t=(i==null?void 0:i.getAttribute("data-doc-id"))||"",t&&(e.currentDocId=t)}if(!t){ae.showMessage("请先在主编辑区打开幻灯片文档");return}await fc(t,{compileFn:async()=>{await e.compileCurrentDocument(t)}})}}),e.addCommand({langKey:"slidesAutoAnimate",langText:"即现演示: 智能配置演示动效",hotkey:"",enabled:()=>!0,execute:async()=>{let t=e.currentDocId;if(!t){const i=document.querySelector(".protyle-content[data-doc-id]");t=(i==null?void 0:i.getAttribute("data-doc-id"))||"",t&&(e.currentDocId=t)}if(!t){ae.showMessage("请先在主编辑区打开幻灯片文档");return}await pc(t,{compileCurrentDocFn:async()=>{await e.compileCurrentDocument(t)}})}}),e.addCommand({langKey:"slidesBatchTransitions",langText:"即现协同: 统计全库转场效果分布",hotkey:"",enabled:()=>!0,execute:async()=>{const t=new yo,i=t.buildTransitionStatsSql(),n=await un(i).catch(()=>[]),s=t.formatTransitionSummary(n||[]);ae.showMessage(s)}}),e.addCommand({langKey:"slidesExportTemplates",langText:"即现协同: 复制即现预设属性模板至剪贴板",hotkey:"",enabled:()=>!0,execute:async()=>{const i=new yo().exportTemplatesJson();typeof navigator<"u"&&navigator.clipboard?(await navigator.clipboard.writeText(i),ae.showMessage("已将即现属性模板 JSON 复制至剪贴板，可直接导入属性管家")):ae.showMessage(`已生成模板数据（请在控制台查看）：
`+i)}}),e.addCommand({langKey:"slidesBatchReplaceTransition",langText:"即现协同: 批量替换全库淡入淡出转场为滑动 (fade -> slide-left)",hotkey:"",enabled:()=>!0,execute:async()=>{const i=await new yo().batchUpdateTransitions("fade","slide-left",n=>un(n).catch(()=>[]),(n,s)=>Fe(n,s));ae.showMessage(`全库批量替换完成：已将 ${i.updatedCount} 处 fade 转场更新为 slide-left`),e.compileCurrentDocument()}}),ai("presenterMode")||e.addCommand({langKey:"slidesPresenterMode",langText:"即现: 打开双屏演讲者控制台 (Presenter Mode)",hotkey:"⌥M",enabled:()=>!0,execute:()=>{e.openPresenterTab()}}),ai("proMode")||(e.addCommand({langKey:"slidesExportCliMd",langText:"即现 Pro: 导出 Slidev 标准 slides.md 文档 (下载到本地)",hotkey:"",enabled:()=>!0,execute:async()=>{if(e.latestCompiledDoc||await e.compileCurrentDocument(),!e.latestCompiledDoc){ae.showMessage("请先打开并放映一篇思源笔记文档");return}e.cliBridge.downloadSlidesMd(e.latestCompiledDoc,`slides-${e.currentDocId||"demo"}.md`)&&ae.showMessage("已生成标准 Slidev Markdown 并触发下载，可在本地使用 npx @slidev/cli 运行")}}),e.addCommand({langKey:"slidesProbeCliDevServer",langText:"即现 Pro: 检测本地 Slidev CLI DevServer 状态 (localhost:3030)",hotkey:"",enabled:()=>!0,execute:async()=>{ae.showMessage("正在探测本地 Slidev CLI DevServer (http://localhost:3030)..."),await e.cliBridge.probeServer(1500)?ae.showMessage("🟢 本地 Slidev CLI DevServer 运行正常！可直接在浏览器访问 http://localhost:3030"):ae.showMessage("⚪ 未检测到运行中的本地 Slidev CLI DevServer (端口 3030 未开启)")}}),e.addCommand({langKey:"slidesSyncToCliWorkspace",langText:"即现 Pro: 同步 slides.md 至思源工作空间存储目录",hotkey:"",enabled:()=>!0,execute:async()=>{if(e.latestCompiledDoc||await e.compileCurrentDocument(),!e.latestCompiledDoc){ae.showMessage("请先打开并放映一篇思源笔记文档");return}const t=await e.cliBridge.syncToWorkspaceFile(e.latestCompiledDoc,"/data/storage/petal/siyuan-live-slides/slides.md",So);t.success?ae.showMessage(`已成功同步最新 slides.md 至工作空间：${t.path}`):ae.showMessage(`同步失败：${t.error}`)}})),!ai("exportImage")){let t=!1;e.addCommand({langKey:"slidesExportImagesZip",langText:"即现: 逐页导出幻灯片为高清图片包 (ZIP)",hotkey:"",enabled:()=>!0,execute:async()=>{if(t){ae.showMessage("正在导出图片中，请稍候...",2e3);return}if(e.latestCompiledDoc||await e.compileCurrentDocument(),!e.latestCompiledDoc){ae.showMessage("请先打开并放映一篇思源笔记文档");return}t=!0;try{ae.showMessage("正在启动后台沙箱并逐页导出幻灯片图片...");const i=e.latestCompiledDoc,n=await Ei(i,e.currentDocId,e),s=await oc(i,{title:n,onProgress:(o,a)=>{ae.showMessage(`正在导出幻灯片图片 (${o} / ${a})...`,2e3)}});s.success?ae.showMessage(`🎉 成功导出 ${s.total||0} 张幻灯片高清图片并已保存为 ${n}.zip！`,4e3):ae.showMessage(`导出图片失败：${s.error||"未知异常"}`)}finally{t=!1}}})}}class o2{constructor(t=400){be(this,"entries",new Map);this.ttlMs=t}get(t,i=Date.now()){if(!t)return;const n=this.entries.get(t);if(n){if(i-n.at>this.ttlMs){this.entries.delete(t);return}return n.attrs}}set(t,i,n=Date.now()){!t||!i||this.entries.set(t,{attrs:i,at:n})}invalidate(t){t?this.entries.delete(t):this.entries.clear()}get size(){return this.entries.size}}function r2(e){const t=new Map;if(!(e!=null&&e.slides))return t;const i=n=>{for(const s of n||[])s!=null&&s.id&&s.ial&&t.set(s.id,s.ial)};for(const n of e.slides)i(n.blocks),i(n.noteBlocks);return t}class a2{constructor(t=150){be(this,"lastBlockId","");be(this,"lastAt",0);this.windowMs=t}shouldSkip(t,i=Date.now()){return t&&t===this.lastBlockId&&i-this.lastAt<this.windowMs?!0:(this.lastBlockId=t,this.lastAt=i,!1)}reset(){this.lastBlockId="",this.lastAt=0}}class l2{constructor(){be(this,"attrCache",new o2);be(this,"compiledIalIndex",{doc:null,map:new Map});be(this,"locatingLockUntil",0);be(this,"lockedTargetBlockId","");be(this,"lastKnownPageDividerId","");be(this,"lastKnownDocId","")}isLocatingLocked(t){return Date.now()<this.locatingLockUntil?!(t&&t===this.lockedTargetBlockId):!1}async resolveBlockAttrs(t,i){if(!t)return{};const n=Le.getBlockAttrOverride(t),s=this.getCompiledIal(i,t);if(n||s)return{...s||{},...n||{}};const o=this.attrCache.get(t);if(o)return o;const a=await Go(t).catch(()=>({}))||{};return this.attrCache.set(t,a),a}getCompiledIal(t,i){if(t)return this.compiledIalIndex.doc!==t&&(this.compiledIalIndex={doc:t,map:r2(t)}),this.compiledIalIndex.map.get(i)}invalidateAttrCache(t){this.attrCache.invalidate(t)}getActiveDocumentId(){if(typeof document>"u")return"";const t=document.querySelector(".layout__wnd--active .protyle-title[data-node-id]")||document.querySelector(".item--focus .protyle-title[data-node-id]")||document.querySelector(".protyle-title[data-node-id]"),i=t==null?void 0:t.getAttribute("data-node-id");if(i)return i;const n=document.querySelector(".protyle .protyle-title[data-node-id]"),s=n==null?void 0:n.getAttribute("data-node-id");if(s)return s;const o=document.querySelector("[data-doc-id]"),a=o==null?void 0:o.getAttribute("data-doc-id");return a||""}resolveDocIdFromElement(t,i=""){const n=t.closest(".protyle-title"),s=n==null?void 0:n.getAttribute("data-node-id");if(s)return s;const o=t.closest(".protyle"),a=o==null?void 0:o.querySelector(".protyle-title"),r=a==null?void 0:a.getAttribute("data-node-id");if(r)return r;const l=t.closest("[data-doc-id]"),c=l==null?void 0:l.getAttribute("data-doc-id");if(c)return c;const u=this.getActiveDocumentId();return u||i}async switchToDocGlobalInspector(t,i){var o;if(!t)return;let n=i||"";if(!n&&typeof document<"u"){const a=document.querySelector(`.protyle-title[data-node-id="${t}"] .protyle-title__input`)||document.querySelector(`.protyle[data-doc-id="${t}"] .protyle-title__input`)||document.querySelector(".protyle-title__input");n=((o=a==null?void 0:a.innerText)==null?void 0:o.trim())||""}const s=await this.resolveBlockAttrs(t,null);Xi({id:t,rootId:t,type:"doc",content:n,attrs:s,isDivider:!1,isCode:!1}),Uo(t)}handleBlockClickedFromSlide(t,i,n,s,o){var c,u,f,d;if(!t){Nn();const p=typeof o=="number"&&o>0?o:1,w=((c=s==null?void 0:s.slides)==null?void 0:c[p-1])||((u=s==null?void 0:s.slides)==null?void 0:u[0]);if(w){const m=w.startBlockId||"",b=((f=w.frontmatter)==null?void 0:f.layout)||"",y={"custom-slides-layout":b,...w.frontmatter};return Xi({id:m,rootId:n,type:"NodeThematicBreak",attrs:y,isDivider:!0,isCode:!1,isImage:!1,pageDividerId:m,pageDividerLayout:b}),this.resolveBlockAttrs(m,s).then(v=>{v&&Object.keys(v).length>0&&Xi({id:m,rootId:n,type:"NodeThematicBreak",attrs:{...y,...v},isDivider:!0,isCode:!1,isImage:!1,pageDividerId:m,pageDividerLayout:b})}),!0}else return this.switchToDocGlobalInspector(n),!0}this.lockedTargetBlockId=t,this.locatingLockUntil=Date.now()+500;const a=Gi(t,i),r=typeof document<"u"?document.querySelector(`.protyle-wysiwyg [data-node-id="${t}"]`)||document.querySelector(`[data-node-id="${t}"]`):null,l=(r==null?void 0:r.getAttribute("data-type"))||"";if(r)this.syncInspectorBlock(r,t,l,n,s);else{let p="",w="";if(s!=null&&s.slides){const m=s.slides.find(b=>{var y,v,k;return b.startBlockId===t||((y=b.blocks)==null?void 0:y.some(S=>S.id===t))||((v=b.allBlockIds)==null?void 0:v.includes(t))||((k=b.noteBlocks)==null?void 0:k.some(S=>S.id===t))});m!=null&&m.startBlockId&&(p=m.startBlockId),(d=m==null?void 0:m.frontmatter)!=null&&d.layout&&(w=m.frontmatter.layout)}this.resolveBlockAttrs(t,s).then(async m=>{if(p&&!w){const b=Le.getBlockAttrOverride(p);if(b!=null&&b[ke]||b!=null&&b["custom-slides-layout"])w=b[ke]||b["custom-slides-layout"]||"";else{const y=await this.resolveBlockAttrs(p,s);w=y[ke]||y["custom-slides-layout"]||"",y&&Object.keys(y).length>0&&Le.setBlockAttrOverride(p,y)}}Xi({id:t,rootId:n,type:l||"NodeParagraph",attrs:m||{},pageDividerId:p,pageDividerLayout:w})}).catch(()=>{})}return a}async syncInspectorBlock(t,i,n,s,o){var q,O,$,T,P,se,V,Y,ce;if(this.isLocatingLocked(i))return;let a=t,r=i,l=n;const c=typeof(t==null?void 0:t.closest)=="function"?t.closest('[data-type="NodeCallout"]'):null;if(c&&c!==t){const ie=c.getAttribute("data-node-id");if(ie){const re=await this.resolveBlockAttrs(ie,o),Se=Le.getBlockAttrOverride(ie)||{},Ie={...re,...Se};(Ie[qe]||Ie["slides-note"])&&(a=c,r=ie,l="NodeCallout")}}const u=a.closest(".protyle-wysiwyg > [data-node-id]")||a,f=(u==null?void 0:u.getAttribute("data-node-id"))||r,d=l==="NodeThematicBreak"||l==="tb"||l==="thematic-break"||(u==null?void 0:u.getAttribute("data-type"))==="NodeThematicBreak"||(u==null?void 0:u.getAttribute("data-type"))==="tb"||!!((q=u==null?void 0:u.classList)!=null&&q.contains("hr")),p=l==="NodeCodeBlock",w=((O=a.innerText)==null?void 0:O.trim())||"",m=await this.resolveBlockAttrs(r,o),b=Le.getBlockAttrOverride(r)||{},y={...m,...b};let v="",k="";if(d)v=r,k=y[ke]||y["custom-slides-layout"]||"";else{let ie=u.previousElementSibling;for(;ie;){const re=ie.getAttribute("data-type");if(re==="NodeThematicBreak"||re==="tb"||($=ie.classList)!=null&&$.contains("hr")){v=ie.getAttribute("data-node-id")||"";break}ie=ie.previousElementSibling}}if(o!=null&&o.slides){const ie=[r,f];let re=a.parentElement;for(;re&&!re.classList.contains("protyle-wysiwyg");){const Ie=re.getAttribute("data-node-id");Ie&&!ie.includes(Ie)&&ie.push(Ie),re=re.parentElement}const Se=o.slides.find(Ie=>{var _e,fe,X;return ie.includes(Ie.startBlockId)||((_e=Ie.blocks)==null?void 0:_e.some(pe=>ie.includes(pe.id)))||((fe=Ie.allBlockIds)==null?void 0:fe.some(pe=>ie.includes(pe)))||((X=Ie.noteBlocks)==null?void 0:X.some(pe=>ie.includes(pe.id)))});Se&&(!v&&Se.startBlockId&&(v=Se.startBlockId),!k&&((T=Se.frontmatter)!=null&&T.layout)&&(k=Se.frontmatter.layout))}if(v?(this.lastKnownDocId=s,this.lastKnownPageDividerId=v):s&&this.lastKnownDocId===s&&this.lastKnownPageDividerId&&(!u.previousElementSibling&&(((P=u.parentElement)==null?void 0:P.scrollTop)||0)===0||(v=this.lastKnownPageDividerId)),v){const ie=Le.getBlockAttrOverride(v);if(ie&&(ke in ie||"custom-slides-layout"in ie)&&(k=ie[ke]||ie["custom-slides-layout"]||""),!k&&(o!=null&&o.slides)){const re=o.slides.find(Se=>Se.startBlockId===v);(se=re==null?void 0:re.frontmatter)!=null&&se.layout&&(k=re.frontmatter.layout)}if(!k){const re=await this.resolveBlockAttrs(v,o);k=re[ke]||re["custom-slides-layout"]||"",re&&Object.keys(re).length>0&&Le.setBlockAttrOverride(v,re)}et(v,{[ke]:k||""})}else if(s){const ie=Le.getBlockAttrOverride(s);ie&&(ke in ie||"custom-slides-layout"in ie)?k=ie[ke]||ie["custom-slides-layout"]||"":!k&&((ce=(Y=(V=o==null?void 0:o.slides)==null?void 0:V[0])==null?void 0:Y.frontmatter)!=null&&ce.layout)&&(k=o.slides[0].frontmatter.layout)}const S=a.getAttribute(ke)||a.getAttribute("custom-slides-layout"),B=y[ke]||y["custom-slides-layout"]||"";S&&S!==B&&et(r,{[ke]:B});const A=a.getAttribute(Ze)||a.getAttribute("custom-slides-role"),C=y[Ze]||y["custom-slides-role"]||"";A&&A!==C&&et(r,{[Ze]:C});let L="",z="",N="";const K=a.closest('[data-type="NodeListItem"]');if(K&&K!==a){const ie=K.getAttribute("data-node-id");if(ie){L=ie;const re=await this.resolveBlockAttrs(ie,o),Se=Le.getBlockAttrOverride(ie)||{},Ie={...re,...Se};z=Ie[Me]||"",N=Ie[Ne]||"";const _e=Ie[ke]||Ie["custom-slides-layout"]||"",fe=K.getAttribute(ke)||K.getAttribute("custom-slides-layout");fe&&fe!==_e&&et(ie,{[ke]:_e});const X=Ie[Ze]||Ie["custom-slides-role"]||"",pe=K.getAttribute(Ze)||K.getAttribute("custom-slides-role");pe&&pe!==X&&et(ie,{[Ze]:X})}}const _=!!a.querySelector("img, span[data-type='img']"),U=(a.innerText||"").replace(/[\r\n\t\s]+/g," ").trim(),x=_&&U.length<=50;Xi({id:r,rootId:s,type:l,content:w,attrs:y,isDivider:d,isCode:p,isImage:x,topBlockId:f,pageDividerId:v,pageDividerLayout:k,parentContainerId:L,parentContainerSlot:z,parentContainerClicks:N})}patchThematicBreakTransactions(t){if((t==null?void 0:t.cmd)==="transactions"&&Array.isArray(t.data)){for(const i of t.data)if(Array.isArray(i==null?void 0:i.doOperations)){for(const n of i.doOperations)if((n==null?void 0:n.action)==="updateAttrs"&&n.id&&n.data){const s=n.data.old||{},o=n.data.new||{},a={};for(const r of Object.keys(s))r in o||(a[r]="");for(const[r,l]of Object.entries(o))a[r]=String(l??"");et(n.id,a),Le.setBlockAttrOverride(n.id,a)}}}}purgeStaleDomSlidesAttrs(t){var s,o,a;if(typeof document>"u"||!t)return;const i=new Map;if(Array.isArray(t.slides))for(const r of t.slides){if(r.startBlockId){const l=i.get(r.startBlockId)||{};(s=r.frontmatter)!=null&&s.layout&&(l[ke]=r.frontmatter.layout),i.set(r.startBlockId,l)}if(Array.isArray(r.blocks)){for(const l of r.blocks)if(l.id){const c=i.get(l.id)||{};(o=l.ial)!=null&&o[ke]&&(c[ke]=l.ial[ke]),(a=l.ial)!=null&&a[Ze]&&(c[Ze]=l.ial[Ze]),Object.keys(c).length>0&&i.set(l.id,c)}}}const n=Le.getAllAttrOverrides();for(const[r,l]of n.entries()){const c=i.get(r)||{};l[ke]!==void 0&&(c[ke]=l[ke]),l[Ze]!==void 0&&(c[Ze]=l[Ze]),i.set(r,c)}pw(i)}}const Si=new l2;class c2{constructor(){be(this,"state","IDLE");be(this,"inFlightDocId",null);be(this,"pendingDocs",new Set);be(this,"lastPendingDocId",null);be(this,"generation",0)}get currentState(){return this.state}get isRunning(){return this.state==="COMPILING"}get runningDocId(){return this.inFlightDocId}get pending(){return this.lastPendingDocId}get pendingList(){return Array.from(this.pendingDocs)}tryBegin(t){return this.state==="COMPILING"||this.inFlightDocId!==null?(this.pendingDocs.add(t),this.lastPendingDocId=t,null):(this.state="COMPILING",this.inFlightDocId=t,++this.generation)}isStale(t){return t!==this.generation}finishBatch(){this.state="IDLE",this.inFlightDocId=null,this.lastPendingDocId=null;const t=Array.from(this.pendingDocs);return this.pendingDocs.clear(),t}finish(){const t=this.finishBatch();return t.length>0?t[t.length-1]:null}reset(){this.state="IDLE",this.inFlightDocId=null,this.pendingDocs.clear(),this.lastPendingDocId=null,this.generation=0}}const d2=150,u2=`<symbol id="iconSlides" viewBox="0 0 1024 1024">
  <path fill="currentColor" d="M128 160h768c35.3 0 64 28.7 64 64v480c0 35.3-28.7 64-64 64H128c-35.3 0-64-28.7-64-64V224c0-35.3 28.7-64 64-64z m64 64v480h640V224H192z m128 640h384v64H320z"/>
  <path fill="currentColor" d="M416 336l256 144-256 144z"/>
</symbol>`,f2="slides-dock",ko="slides-preview-tab",wa="slides-presenter-tab",xa=Zf;class p2 extends ae.Plugin{constructor(){super(...arguments);be(this,"isMobile",!1);be(this,"currentDocId","");be(this,"previewTab",null);be(this,"latestCompiledDoc",null);be(this,"cliBridge",new mr);be(this,"debounceTimer",null);be(this,"activeCursorBlockId","");be(this,"cancelledCursorBlockId","");be(this,"compileScheduler",new c2);be(this,"dirtyDocId",null);be(this,"inspectorSyncThrottle",new a2);be(this,"onSwitchProtyleBound",this.onSwitchProtyle.bind(this));be(this,"onWsMainBound",this.onWsMain.bind(this));be(this,"onBlockClickedBound",this.onBlockClickedFromSlide.bind(this));be(this,"onEditorClickBound",this.onEditorClick.bind(this));be(this,"onSelectionChangeBound",this.onSelectionChange.bind(this));be(this,"onClickEditorContentBound",this.onClickEditorContent.bind(this));be(this,"onVisibilityChangeBound",this.onVisibilityChange.bind(this))}async onload(){const i=ae.getFrontend();this.isMobile=i==="mobile"||i==="browser-mobile",await this.loadGlobalSettings(),this.addIcons(u2),this.addTopBar({id:"slides-topbar-play",icon:"iconSlides",title:"即现演示",position:"right",callback:()=>{this.openBottomPreviewTab()}}),s2(this);const n=this;if(this.addTab({type:ko,init(s){var r;const o=this||s;n.previewTab=(o==null?void 0:o.tab)||null,Zw(o.element,n);const a=(r=o==null?void 0:o.data)==null?void 0:r.docId;a&&!n.getActiveDocumentId()&&n.compileCurrentDocument(a,{reason:"explicit"}),n.updatePreviewTabHeader()},destroy(){n.previewTab===(this==null?void 0:this.tab)&&(n.previewTab=null),vc(this.element)}}),this.addTab({type:wa,init(s){Xw((this||s).element,n)},destroy(){bc(this.element)}}),this.addDock({config:{position:"RightTop",size:{width:320,height:0},icon:"iconSlides",title:"即现演示配置"},data:{},type:f2,init(){e2(this.element,n)},destroy(){yc(this.element)}}),this.eventBus&&typeof this.eventBus.emit!="function"&&(this.eventBus.emit=(s,o)=>{try{typeof window<"u"&&window.dispatchEvent(new CustomEvent(`siyuan-event-${s}`,{detail:o}))}catch{}}),this.eventBus.on("switch-protyle",this.onSwitchProtyleBound),this.eventBus.on("ws-main",this.onWsMainBound),this.eventBus.on("slides:request-compile",()=>this.compileCurrentDocument()),this.eventBus.on("slides:block-clicked",this.onBlockClickedBound),this.eventBus.on("click-editorcontent",this.onClickEditorContentBound),typeof document<"u"&&(document.addEventListener("click",this.onEditorClickBound,!0),document.addEventListener("selectionchange",this.onSelectionChangeBound),document.addEventListener("visibilitychange",this.onVisibilityChangeBound)),typeof document<"u"){const s=()=>{const o=this.getActiveDocumentId();o&&(o!==this.currentDocId&&(this.currentDocId=o,this.updatePreviewTabHeader("",o)),this.latestCompiledDoc||this.markCompileDirty(o))};setTimeout(s,300),setTimeout(s,1e3)}}async onDataChanged(i){await this.loadGlobalSettings(),this.currentDocId&&this.markCompileDirty(this.currentDocId)}async loadGlobalSettings(){try{const i=await this.loadData(xa),n=Jf(i);return ri(n),n}catch{return ri(Ti),Ti}}async saveGlobalSettings(i){const n=Ys(),s=ri({...n,...i||{}});try{await this.saveData(xa,s)}catch(a){console.error("保存即现全局配置失败",a)}const o=this.currentDocId||this.getActiveDocumentId();return o&&this.markCompileDirty(o),s}onunload(){this.debounceTimer&&(window.clearTimeout(this.debounceTimer),this.debounceTimer=null),this.compileScheduler.reset(),this.inspectorSyncThrottle.reset(),this.dirtyDocId=null,bs.clear(),this.eventBus.off("switch-protyle",this.onSwitchProtyleBound),this.eventBus.off("ws-main",this.onWsMainBound),this.eventBus.off("click-editorcontent",this.onClickEditorContentBound),typeof document<"u"&&(document.removeEventListener("click",this.onEditorClickBound,!0),document.removeEventListener("selectionchange",this.onSelectionChangeBound),document.removeEventListener("visibilitychange",this.onVisibilityChangeBound)),kn.detach()}onVisibilityChange(){typeof document<"u"&&document.visibilityState==="visible"&&this.flushDirtyCompile()}async openBottomPreviewTab(){this.currentDocId||(this.currentDocId=this.getActiveDocumentId());const i=this.currentDocId?await this.fetchDocumentTitle(this.currentDocId):"",n=this.buildPreviewTabTitle(i);await ae.openTab({app:this.app,custom:{id:this.name+ko,title:n,icon:"iconSlides",data:{docId:this.currentDocId}},position:"bottom"}),this.currentDocId&&this.compileCurrentDocument(this.currentDocId),this.updatePreviewTabHeader(i,this.currentDocId)}async openPresenterTab(){ai("presenterMode")||(Jw()||await this.openBottomPreviewTab(),await ae.openTab({app:this.app,custom:{id:this.name+wa,title:"演讲者控制台",icon:"iconSlides",data:{}},position:"right"}))}async openStandalonePreviewWindow(){this.currentDocId||(this.currentDocId=this.getActiveDocumentId()),this.currentDocId&&!this.latestCompiledDoc&&await this.compileCurrentDocument(this.currentDocId,{reason:"explicit"});const i=ae.getFrontend();if(i==="browser-desktop"||i==="browser-mobile"){typeof window<"u"&&typeof window.open=="function"&&window.open("/plugins/siyuan-live-slides/slides-client/index.html","SlidesBigScreenWindow","width=1280,height=760,menubar=no,toolbar=no,location=no,status=no");return}let n=this.previewTab;if(!n){const s=this.currentDocId?await this.fetchDocumentTitle(this.currentDocId):"",o=this.buildPreviewTabTitle(s),a=await ae.openTab({app:this.app,custom:{id:this.name+ko,title:o,icon:"iconSlides",data:{docId:this.currentDocId}},position:"bottom"});n=this.previewTab||a}n&&(this.currentDocId&&n.model&&(n.model.data={...n.model.data||{},docId:this.currentDocId}),ae.openWindow({tab:n,width:1280,height:760}))}async onSwitchProtyle(i){var a,r,l,c,u;const n=(a=i.detail)==null?void 0:a.protyle,s=(r=n==null?void 0:n.block)==null?void 0:r.rootID,o=((u=(c=(l=n==null?void 0:n.title)==null?void 0:l.editElement)==null?void 0:c.textContent)==null?void 0:u.trim())||"";if(s&&s!==this.currentDocId){this.cancelledCursorBlockId="",this.currentDocId=s,this.activeCursorBlockId=s;const f=await Go(s).catch(()=>({}));Xi({id:s,rootId:s,type:"doc",attrs:f}),this.markCompileDirty(s),this.updatePreviewTabHeader(o,s)}}onClickEditorContent(i){var o,a;const n=i==null?void 0:i.detail;if(!n)return;const s=(a=(o=n.protyle)==null?void 0:o.block)==null?void 0:a.rootID;s&&(!this.currentDocId||this.currentDocId!==s)&&(this.currentDocId=s),n.event&&this.onEditorClick(n.event)}buildPreviewTabTitle(i){return ic(i)}async fetchDocumentTitle(i){return nc(this,i)}async updatePreviewTabHeader(i,n){return xg(this,i,n)}getActiveDocumentId(){return Si.getActiveDocumentId()}resolveDocIdFromElement(i){return Si.resolveDocIdFromElement(i,this.currentDocId)}async switchToDocGlobalInspector(i,n){i&&(this.activeCursorBlockId=i,this.currentDocId=i,await Si.switchToDocGlobalInspector(i,n))}onWsMain(i){const n=i.detail;n&&n.cmd==="transactions"&&(Si.patchThematicBreakTransactions(n),this.markCompileDirty())}markCompileDirty(i){const n=i||this.currentDocId||this.getActiveDocumentId();n&&(this.currentDocId||(this.currentDocId=n),this.dirtyDocId=n,this.scheduleDirtyCompile())}scheduleDirtyCompile(i=d2){if(this.debounceTimer&&(window.clearTimeout(this.debounceTimer),this.debounceTimer=null),!this.dirtyDocId)return;const n=bs.getVisibility();if(n==="none")return;const s=n==="visible"?i:Math.max(i,Vw);this.debounceTimer=window.setTimeout(()=>{this.debounceTimer=null;const o=this.dirtyDocId;this.dirtyDocId=null,o&&this.compileCurrentDocument(o,{reason:"auto"})},s)}flushDirtyCompile(){this.dirtyDocId&&this.scheduleDirtyCompile(0)}handleBlockClickedFromSlide(i,n){return i?(this.cancelledCursorBlockId="",this.activeCursorBlockId=i):(this.cancelledCursorBlockId=this.activeCursorBlockId,this.activeCursorBlockId=""),Si.handleBlockClickedFromSlide(i,this.app,this.currentDocId,this.latestCompiledDoc,n)}onBlockClickedFromSlide(i){const n=(i==null?void 0:i.detail)||i;n!=null&&n.blockId&&this.handleBlockClickedFromSlide(n.blockId,n.page)}onEditorClick(i){const n=i.target;if(!n)return;const s=n.closest(".protyle-title")||n.closest(".protyle-background");if(!!(s||n.closest(".protyle-content")&&!n.closest(".protyle-wysiwyg")&&!n.closest(".protyle-breadcrumb")&&!n.closest(".protyle-gutters"))){const u=this.resolveDocIdFromElement(n);if(u&&this.activeCursorBlockId!==u){const f=s||document.querySelector(`.protyle-title[data-node-id="${u}"]`)||document.querySelector(`.protyle[data-doc-id="${u}"] .protyle-title`),d=f==null?void 0:f.querySelector(".protyle-title__input"),p=((d==null?void 0:d.innerText)||(f==null?void 0:f.innerText)||"").trim();this.switchToDocGlobalInspector(u,p)}return}if(!n.closest(".protyle-wysiwyg"))return;const r=n.closest("[data-node-id]");if(!r)return;const l=r.getAttribute("data-node-id"),c=r.getAttribute("data-type")||"";l&&(this.cancelledCursorBlockId="",this.currentDocId||(this.currentDocId=this.resolveDocIdFromElement(n)||""),this.currentDocId&&!this.latestCompiledDoc&&this.markCompileDirty(this.currentDocId),l!==this.activeCursorBlockId&&(this.activeCursorBlockId=l,Uo(l)),this.syncInspectorBlock(r,l,c))}onSelectionChange(){if(typeof window>"u")return;const i=window.getSelection();if(!i||i.rangeCount===0)return;const n=i.anchorNode;if(!n)return;const s=n.nodeType===Node.ELEMENT_NODE?n:n.parentElement;if(!s)return;const o=s.closest(".protyle-title");if(!!(o||s.closest(".protyle-content")&&!s.closest(".protyle-wysiwyg"))){const u=this.resolveDocIdFromElement(s);if(u&&this.activeCursorBlockId!==u){const f=o||document.querySelector(`.protyle-title[data-node-id="${u}"]`)||document.querySelector(`.protyle[data-doc-id="${u}"] .protyle-title`),d=f==null?void 0:f.querySelector(".protyle-title__input"),p=((d==null?void 0:d.innerText)||(f==null?void 0:f.innerText)||"").trim();this.switchToDocGlobalInspector(u,p)}return}if(!s.closest(".protyle-wysiwyg"))return;const r=s.closest("[data-node-id]"),l=r==null?void 0:r.getAttribute("data-node-id"),c=(r==null?void 0:r.getAttribute("data-type"))||"";if(r&&l){if(Si.isLocatingLocked(l))return;if(this.currentDocId||(this.currentDocId=this.resolveDocIdFromElement(s)||""),this.currentDocId&&!this.latestCompiledDoc&&this.markCompileDirty(this.currentDocId),l!==this.activeCursorBlockId){if(l===this.cancelledCursorBlockId)return;this.activeCursorBlockId=l,Uo(l)}this.syncInspectorBlock(r,l,c)}}async syncInspectorBlock(i,n,s){this.inspectorSyncThrottle.shouldSkip(n)||await Si.syncInspectorBlock(i,n,s,this.currentDocId,this.latestCompiledDoc)}async compileCurrentDocument(i,n){const s=(n==null?void 0:n.reason)??"explicit";let o=i||this.currentDocId;if(!o){const r=this.getActiveDocumentId();if(r)this.currentDocId=r,o=r;else return}if(s==="auto"&&bs.getVisibility()==="none"){this.dirtyDocId=o;return}const a=this.compileScheduler.tryBegin(o);if(a!==null){this.dirtyDocId===o&&(this.dirtyDocId=null);try{const r=await Le.compile(o),l=!!this.currentDocId&&o!==this.currentDocId;!this.compileScheduler.isStale(a)&&!l&&(this.currentDocId||(this.currentDocId=o),this.latestCompiledDoc=r,t2(r,o),this.updatePreviewTabHeader("",o),this.purgeStaleDomSlidesAttrs(r))}catch(r){console.error("[SiYuanLiveSlides] Failed to compile document:",r)}finally{const r=this.compileScheduler.finishBatch(),l=r.length>0?r[0]:this.compileScheduler.finish();l&&this.markCompileDirty(l);for(let c=1;c<r.length;c++)this.markCompileDirty(r[c])}}}purgeStaleDomSlidesAttrs(i){Si.purgeStaleDomSlidesAttrs(i)}}module.exports=p2;
