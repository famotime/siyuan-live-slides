"use strict";var Za=Object.create;var Po=Object.defineProperty;var Ya=Object.getOwnPropertyDescriptor;var Ja=Object.getOwnPropertyNames;var Xa=Object.getPrototypeOf,Qa=Object.prototype.hasOwnProperty;var tc=(t,i,e)=>i in t?Po(t,i,{enumerable:!0,configurable:!0,writable:!0,value:e}):t[i]=e;var ec=(t,i,e,n)=>{if(i&&typeof i=="object"||typeof i=="function")for(let o of Ja(i))!Qa.call(t,o)&&o!==e&&Po(t,o,{get:()=>i[o],enumerable:!(n=Ya(i,o))||n.enumerable});return t};var jn=(t,i,e)=>(e=t!=null?Za(Xa(t)):{},ec(i||!t||!t.__esModule?Po(e,"default",{value:t,enumerable:!0}):e,t));var xt=(t,i,e)=>tc(t,typeof i!="symbol"?i+"":i,e);const ht=require("siyuan");async function ke(t,i){const e=await ht.fetchSyncPost(t,i);return e.code===0?e.data:null}async function ic(){return ke("/api/notebook/lsNotebooks","")}async function nc(t,i,e){return ke("/api/filetree/createDocWithMd",{notebook:t,path:i,markdown:e})}async function zr(t,i){const e=new FormData;e.append("assetsDirPath",t);for(const o of i)e.append("file[]",o);return ke("/api/asset/upload",e)}async function Ii(t,i,e,n,o){return ke("/api/block/insertBlock",{dataType:t,data:i,nextID:e,previousID:n,parentID:o})}async function Xo(t,i,e){return ke("/api/block/appendBlock",{dataType:t,data:i,parentID:e})}async function Ks(t,i,e){return ke("/api/block/updateBlock",{dataType:t,data:i,id:e})}async function Gs(t){return ke("/api/block/deleteBlock",{id:t})}async function oc(t){return ke("/api/block/getBlockKramdown",{id:t})}async function no(t){return ke("/api/block/getChildBlocks",{id:t})}async function Et(t,i){return ke("/api/attr/setBlockAttrs",{id:t,attrs:i})}async function Ye(t){return ke("/api/attr/getBlockAttrs",{id:t})}async function wn(t){return ke("/api/query/sql",{stmt:t})}async function Qo(t,i,e){const n=new FormData;return n.append("path",t),n.append("isDir",i.toString()),n.append("modTime",Math.floor(Date.now()/1e3).toString()),n.append("file",e),ke("/api/file/putFile",n)}async function Nr(t){const i="/api/ai/chatGPT";try{const e=await ke(i,{msg:t});return typeof e=="string"&&e.trim().length>0?e.trim():e&&typeof e.content=="string"&&e.content.trim().length>0?e.content.trim():null}catch{return null}}async function sc(){return ke("/api/storage/getInlineStyles","")}const Fr=/\(\(([0-9a-zA-Z-]+)(?:\s*(?:'([^']*)'|"([^"]*)"|([^\)]+?)))?\s*\)\)/g;function rc(t){const i=[];if(!t)return i;const e=new RegExp(Fr.source,"g");let n;for(;(n=e.exec(t))!==null;){const o=n[2]??n[3]??n[4];i.push({fullMatch:n[0],blockId:n[1],anchorText:o?o.trim():void 0})}return i}function lc(t,i){if(!t)return"";const e=new RegExp(Fr.source,"g");return t.replace(e,(n,o,s,l,r)=>{const a=(s??l??r??"").trim();if(i&&i[o]){const u=i[o].trim();return`<div class="slidev-block-ref" data-ref-id="${o}">${u}</div>`}const c=a||`Ref(${o.slice(0,8)})`;return`<a href="siyuan://blocks/${o}" data-ref-id="${o}" class="slidev-ref-tag">🔗 ${c}</a>`})}const xn="custom-slidev-theme",Sn="custom-slidev-aspect-ratio",Hr="custom-slidev-highlighter",_n="custom-slidev-default-transition",jr="custom-slidev-color-schema",ts="custom-slidev-spacing",Bi="custom-slidev-slide",mt="custom-slidev-layout",te="custom-slidev-transition",Ut="custom-slidev-background",Ee="custom-slidev-image",Wi="custom-slidev-notes",Vi="custom-slidev-class",fn="custom-slidev-spacing",le="custom-slidev-layout-ratio",jt="custom-slidev-click",Ve="custom-slidev-motion",Oi="custom-slidev-shiki-lines",Ct="custom-slidev-slot",ne="custom-slidev-note",qt="custom-slidev-role",Cn="custom-slidev-max-height",Ti="custom-slidev-autoplay",oo="custom-slidev-loop",Ui="custom-slidev-muted",so="custom-slidev-controls",Ur="background",ro="image-left",lo="image-right";function $n(t){return t==="cols-header"||t==="two-cols-header"||t==="three-cols-header"}function ac(t){return t.markdown&&t.markdown.trim()?t.markdown.trim():t.content&&t.content.trim()?t.content.trim():""}function cc(t){const i={};if(!t)return i;const e=t.replace(/^\{:\s*/,"").replace(/\s*\}$/,""),n=/([\w-]+)=(?:"([^"]*)"|'([^']*)'|(\S+))/g;let o;for(;(o=n.exec(e))!==null;){const s=o[1],l=o[2]??o[3]??o[4]??"";i[s]=l}return i}function dc(t){if(!t)return!1;const i=t.trim();return i.startsWith("assets/")||i.startsWith("./assets/")||i.startsWith("/assets/")}function uc(t){const i=t.trim();return i.startsWith("./assets/")?i.slice(2):i.startsWith("/assets/")?i.slice(1):i}function Ie(t,i){if(!dc(t))return t;const e=uc(t);return i!=null&&i.base64Map&&i.base64Map[e]?i.base64Map[e]:i!=null&&i.baseUrl?`${i.baseUrl.replace(/\/+$/,"")}/${e}`:`/${e}`}function fc(t,i){if(!t)return"";let e=t;return e=e.replace(/!\[(.*?)\]\(((?:\.\/|\/)?assets\/[^\s)]+)\)/g,(n,o,s)=>{const l=Ie(s,i);return`![${o}](${l})`}),e=e.replace(/(<(?:img|video|audio|source)\b[^>]*?\bsrc=["'])((?:\.\/|\/)?assets\/[^"']+)(["'][^>]*>)/gi,(n,o,s,l)=>{const r=Ie(s,i);return`${o}${r}${l}`}),e=e.replace(/(url\(\s*["']?)((?:\.\/|\/)?assets\/[^"')]+)(["']?\s*\))/gi,(n,o,s,l)=>{const r=Ie(s,i);return`${o}${r}${l}`}),e}/**
* @vue/shared v3.5.40
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/function gs(t){const i=Object.create(null);for(const e of t.split(","))i[e]=1;return e=>e in i}const Wt={},qi=[],qe=()=>{},Wr=()=>!1,yo=t=>t.charCodeAt(0)===111&&t.charCodeAt(1)===110&&(t.charCodeAt(2)>122||t.charCodeAt(2)<97),ko=t=>t.startsWith("onUpdate:"),ue=Object.assign,vs=(t,i)=>{const e=t.indexOf(i);e>-1&&t.splice(e,1)},pc=Object.prototype.hasOwnProperty,zt=(t,i)=>pc.call(t,i),$t=Array.isArray,Ki=t=>Pn(t)==="[object Map]",en=t=>Pn(t)==="[object Set]",Zs=t=>Pn(t)==="[object Date]",Bt=t=>typeof t=="function",ee=t=>typeof t=="string",Pe=t=>typeof t=="symbol",Ht=t=>t!==null&&typeof t=="object",Vr=t=>(Ht(t)||Bt(t))&&Bt(t.then)&&Bt(t.catch),qr=Object.prototype.toString,Pn=t=>qr.call(t),hc=t=>Pn(t).slice(8,-1),Kr=t=>Pn(t)==="[object Object]",bs=t=>ee(t)&&t!=="NaN"&&t[0]!=="-"&&""+parseInt(t,10)===t,pn=gs(",key,ref,ref_for,ref_key,onVnodeBeforeMount,onVnodeMounted,onVnodeBeforeUpdate,onVnodeUpdated,onVnodeBeforeUnmount,onVnodeUnmounted"),wo=t=>{const i=Object.create(null);return(e=>i[e]||(i[e]=t(e)))},mc=/-\w/g,ye=wo(t=>t.replace(mc,i=>i.slice(1).toUpperCase())),gc=/\B([A-Z])/g,yi=wo(t=>t.replace(gc,"-$1").toLowerCase()),xo=wo(t=>t.charAt(0).toUpperCase()+t.slice(1)),Oo=wo(t=>t?`on${xo(t)}`:""),Ue=(t,i)=>!Object.is(t,i),Jn=(t,...i)=>{for(let e=0;e<t.length;e++)t[e](...i)},Gr=(t,i,e,n=!1)=>{Object.defineProperty(t,i,{configurable:!0,enumerable:!1,writable:n,value:e})},So=t=>{const i=parseFloat(t);return isNaN(i)?t:i};let Ys;const _o=()=>Ys||(Ys=typeof globalThis<"u"?globalThis:typeof self<"u"?self:typeof window<"u"?window:typeof global<"u"?global:{});function In(t){if($t(t)){const i={};for(let e=0;e<t.length;e++){const n=t[e],o=ee(n)?kc(n):In(n);if(o)for(const s in o)i[s]=o[s]}return i}else if(ee(t)||Ht(t))return t}const vc=/;(?![^(]*\))/g,bc=/:([^]+)/,yc=/\/\*[^]*?\*\//g;function kc(t){const i={};return t.replace(yc,"").split(vc).forEach(e=>{if(e){const n=e.split(bc);n.length>1&&(i[n[0].trim()]=n[1].trim())}}),i}function At(t){let i="";if(ee(t))i=t;else if($t(t))for(let e=0;e<t.length;e++){const n=At(t[e]);n&&(i+=n+" ")}else if(Ht(t))for(const e in t)t[e]&&(i+=e+" ");return i.trim()}const wc="itemscope,allowfullscreen,formnovalidate,ismap,nomodule,novalidate,readonly",xc=gs(wc);function Zr(t){return!!t||t===""}function Sc(t,i){if(t.length!==i.length)return!1;let e=!0;for(let n=0;e&&n<t.length;n++)e=nn(t[n],i[n]);return e}function nn(t,i){if(t===i)return!0;let e=Zs(t),n=Zs(i);if(e||n)return e&&n?t.getTime()===i.getTime():!1;if(e=Pe(t),n=Pe(i),e||n)return t===i;if(e=$t(t),n=$t(i),e||n)return e&&n?Sc(t,i):!1;if(e=Ht(t),n=Ht(i),e||n){if(!e||!n)return!1;const o=Object.keys(t).length,s=Object.keys(i).length;if(o!==s)return!1;for(const l in t){const r=t.hasOwnProperty(l),a=i.hasOwnProperty(l);if(r&&!a||!r&&a||!nn(t[l],i[l]))return!1}}return String(t)===String(i)}function ys(t,i){return t.findIndex(e=>nn(e,i))}const Yr=t=>!!(t&&t.__v_isRef===!0),_t=t=>ee(t)?t:t==null?"":$t(t)||Ht(t)&&(t.toString===qr||!Bt(t.toString))?Yr(t)?_t(t.value):JSON.stringify(t,Jr,2):String(t),Jr=(t,i)=>Yr(i)?Jr(t,i.value):Ki(i)?{[`Map(${i.size})`]:[...i.entries()].reduce((e,[n,o],s)=>(e[Ro(n,s)+" =>"]=o,e),{})}:en(i)?{[`Set(${i.size})`]:[...i.values()].map(e=>Ro(e))}:Pe(i)?Ro(i):Ht(i)&&!$t(i)&&!Kr(i)?String(i):i,Ro=(t,i="")=>{var e;return Pe(t)?`Symbol(${(e=t.description)!=null?e:i})`:t};/**
* @vue/reactivity v3.5.40
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/let ae;class _c{constructor(i=!1){this.detached=i,this._active=!0,this._on=0,this.effects=[],this.cleanups=[],this._isPaused=!1,this._warnOnRun=!0,this.__v_skip=!0,!i&&ae&&(ae.active?(this.parent=ae,this.index=(ae.scopes||(ae.scopes=[])).push(this)-1):(this._active=!1,this._warnOnRun=!1))}get active(){return this._active}pause(){if(this._active){this._isPaused=!0;let i,e;if(this.scopes){const n=this.scopes.slice();for(i=0,e=n.length;i<e;i++)n[i].pause()}for(i=0,e=this.effects.length;i<e;i++)this.effects[i].pause()}}resume(){if(this._active&&this._isPaused){this._isPaused=!1;let i,e;if(this.scopes){const o=this.scopes.slice();for(i=0,e=o.length;i<e;i++)o[i].resume()}const n=this.effects.slice();for(i=0,e=n.length;i<e;i++)n[i].resume()}}run(i){if(this._active){const e=ae;try{return ae=this,i()}finally{ae=e}}}on(){++this._on===1&&(this.prevScope=ae,ae=this)}off(){if(this._on>0&&--this._on===0){if(ae===this)ae=this.prevScope;else{let i=ae;for(;i;){if(i.prevScope===this){i.prevScope=this.prevScope;break}i=i.prevScope}}this.prevScope=void 0}}stop(i){if(this._active){this._active=!1;let e,n;for(e=0,n=this.effects.length;e<n;e++)this.effects[e].stop();for(this.effects.length=0,e=0,n=this.cleanups.length;e<n;e++)this.cleanups[e]();if(this.cleanups.length=0,this.scopes){const o=this.scopes.slice();for(e=0,n=o.length;e<n;e++)o[e].stop(!0);this.scopes.length=0}if(!this.detached&&this.parent&&!i){const o=this.parent.scopes.pop();o&&o!==this&&(this.parent.scopes[this.index]=o,o.index=this.index)}this.parent=void 0}}}function Cc(){return ae}let Vt;const zo=new WeakSet;class Xr{constructor(i){this.fn=i,this.deps=void 0,this.depsTail=void 0,this.flags=5,this.next=void 0,this.cleanup=void 0,this.scheduler=void 0,ae&&(ae.active?ae.effects.push(this):this.flags&=-2)}pause(){this.flags|=64}resume(){this.flags&64&&(this.flags&=-65,zo.has(this)&&(zo.delete(this),this.trigger()))}notify(){this.flags&2&&!(this.flags&32)||this.flags&8||tl(this)}run(){if(!(this.flags&1))return this.fn();this.flags|=2,Js(this),el(this);const i=Vt,e=De;Vt=this,De=!0;try{return this.fn()}finally{il(this),Vt=i,De=e,this.flags&=-3}}stop(){if(this.flags&1){for(let i=this.deps;i;i=i.nextDep)xs(i);this.deps=this.depsTail=void 0,Js(this),this.onStop&&this.onStop(),this.flags&=-2}}trigger(){this.flags&64?zo.add(this):this.scheduler?this.scheduler():this.runIfDirty()}runIfDirty(){es(this)&&this.run()}get dirty(){return es(this)}}let Qr=0,hn,mn;function tl(t,i=!1){if(t.flags|=8,i){t.next=mn,mn=t;return}t.next=hn,hn=t}function ks(){Qr++}function ws(){if(--Qr>0)return;if(mn){let i=mn;for(mn=void 0;i;){const e=i.next;i.next=void 0,i.flags&=-9,i=e}}let t;for(;hn;){let i=hn;for(hn=void 0;i;){const e=i.next;if(i.next=void 0,i.flags&=-9,i.flags&1)try{i.trigger()}catch(n){t||(t=n)}i=e}}if(t)throw t}function el(t){for(let i=t.deps;i;i=i.nextDep)i.version=-1,i.prevActiveLink=i.dep.activeLink,i.dep.activeLink=i}function il(t){let i,e=t.depsTail,n=e;for(;n;){const o=n.prevDep;n.version===-1?(n===e&&(e=o),xs(n),$c(n)):i=n,n.dep.activeLink=n.prevActiveLink,n.prevActiveLink=void 0,n=o}t.deps=i,t.depsTail=e}function es(t){for(let i=t.deps;i;i=i.nextDep)if(i.dep.version!==i.version||i.dep.computed&&(nl(i.dep.computed)||i.dep.version!==i.version))return!0;return!!t._dirty}function nl(t){if(t.flags&4&&!(t.flags&16)||(t.flags&=-17,t.globalVersion===An)||(t.globalVersion=An,!t.isSSR&&t.flags&128&&(!t.deps&&!t._dirty||!es(t))))return;t.flags|=2;const i=t.dep,e=Vt,n=De;Vt=t,De=!0;try{el(t);const o=t.fn(t._value);(i.version===0||Ue(o,t._value))&&(t.flags|=128,t._value=o,i.version++)}catch(o){throw i.version++,o}finally{Vt=e,De=n,il(t),t.flags&=-3}}function xs(t,i=!1){const{dep:e,prevSub:n,nextSub:o}=t;if(n&&(n.nextSub=o,t.prevSub=void 0),o&&(o.prevSub=n,t.nextSub=void 0),e.subs===t&&(e.subs=n,!n&&e.computed)){e.computed.flags&=-5;for(let s=e.computed.deps;s;s=s.nextDep)xs(s,!0)}!i&&!--e.sc&&e.map&&e.map.delete(e.key)}function $c(t){const{prevDep:i,nextDep:e}=t;i&&(i.nextDep=e,t.prevDep=void 0),e&&(e.prevDep=i,t.nextDep=void 0)}let De=!0;const ol=[];function oi(){ol.push(De),De=!1}function si(){const t=ol.pop();De=t===void 0?!0:t}function Js(t){const{cleanup:i}=t;if(t.cleanup=void 0,i){const e=Vt;Vt=void 0;try{i()}finally{Vt=e}}}let An=0;class Ic{constructor(i,e){this.sub=i,this.dep=e,this.version=e.version,this.nextDep=this.prevDep=this.nextSub=this.prevSub=this.prevActiveLink=void 0}}class Ss{constructor(i){this.computed=i,this.version=0,this.activeLink=void 0,this.subs=void 0,this.map=void 0,this.key=void 0,this.sc=0,this.__v_skip=!0}track(i){if(!Vt||!De||Vt===this.computed)return;let e=this.activeLink;if(e===void 0||e.sub!==Vt)e=this.activeLink=new Ic(Vt,this),Vt.deps?(e.prevDep=Vt.depsTail,Vt.depsTail.nextDep=e,Vt.depsTail=e):Vt.deps=Vt.depsTail=e,sl(e);else if(e.version===-1&&(e.version=this.version,e.nextDep)){const n=e.nextDep;n.prevDep=e.prevDep,e.prevDep&&(e.prevDep.nextDep=n),e.prevDep=Vt.depsTail,e.nextDep=void 0,Vt.depsTail.nextDep=e,Vt.depsTail=e,Vt.deps===e&&(Vt.deps=n)}return e}trigger(i){this.version++,An++,this.notify(i)}notify(i){ks();try{for(let e=this.subs;e;e=e.prevSub)e.sub.notify()&&e.sub.dep.notify()}finally{ws()}}}function sl(t){if(t.dep.sc++,t.sub.flags&4){const i=t.dep.computed;if(i&&!t.dep.subs){i.flags|=20;for(let n=i.deps;n;n=n.nextDep)sl(n)}const e=t.dep.subs;e!==t&&(t.prevSub=e,e&&(e.nextSub=t)),t.dep.subs=t}}const is=new WeakMap,Mi=Symbol(""),ns=Symbol(""),Bn=Symbol("");function he(t,i,e){if(De&&Vt){let n=is.get(t);n||is.set(t,n=new Map);let o=n.get(e);o||(n.set(e,o=new Ss),o.map=n,o.key=e),o.track()}}function Qe(t,i,e,n,o,s){const l=is.get(t);if(!l){An++;return}const r=a=>{a&&a.trigger()};if(ks(),i==="clear")l.forEach(r);else{const a=$t(t),c=a&&bs(e);if(a&&e==="length"){const u=Number(n);l.forEach((m,g)=>{(g==="length"||g===Bn||!Pe(g)&&g>=u)&&r(m)})}else switch((e!==void 0||l.has(void 0))&&r(l.get(e)),c&&r(l.get(Bn)),i){case"add":a?c&&r(l.get("length")):(r(l.get(Mi)),Ki(t)&&r(l.get(ns)));break;case"delete":a||(r(l.get(Mi)),Ki(t)&&r(l.get(ns)));break;case"set":Ki(t)&&r(l.get(Mi));break}}ws()}function Hi(t){const i=Rt(t);return i===t?i:(he(i,"iterate",Bn),Be(t)?i:i.map(Oe))}function Co(t){return he(t=Rt(t),"iterate",Bn),t}function He(t,i){return ri(t)?Ji(Li(t)?Oe(i):i):Oe(i)}const Ac={__proto__:null,[Symbol.iterator](){return No(this,Symbol.iterator,t=>He(this,t))},concat(...t){return Hi(this).concat(...t.map(i=>$t(i)?Hi(i):i))},entries(){return No(this,"entries",t=>(t[1]=He(this,t[1]),t))},every(t,i){return Ze(this,"every",t,i,void 0,arguments)},filter(t,i){return Ze(this,"filter",t,i,e=>e.map(n=>He(this,n)),arguments)},find(t,i){return Ze(this,"find",t,i,e=>He(this,e),arguments)},findIndex(t,i){return Ze(this,"findIndex",t,i,void 0,arguments)},findLast(t,i){return Ze(this,"findLast",t,i,e=>He(this,e),arguments)},findLastIndex(t,i){return Ze(this,"findLastIndex",t,i,void 0,arguments)},forEach(t,i){return Ze(this,"forEach",t,i,void 0,arguments)},includes(...t){return Fo(this,"includes",t)},indexOf(...t){return Fo(this,"indexOf",t)},join(t){return Hi(this).join(t)},lastIndexOf(...t){return Fo(this,"lastIndexOf",t)},map(t,i){return Ze(this,"map",t,i,void 0,arguments)},pop(){return ln(this,"pop")},push(...t){return ln(this,"push",t)},reduce(t,...i){return Xs(this,"reduce",t,i)},reduceRight(t,...i){return Xs(this,"reduceRight",t,i)},shift(){return ln(this,"shift")},some(t,i){return Ze(this,"some",t,i,void 0,arguments)},splice(...t){return ln(this,"splice",t)},toReversed(){return Hi(this).toReversed()},toSorted(t){return Hi(this).toSorted(t)},toSpliced(...t){return Hi(this).toSpliced(...t)},unshift(...t){return ln(this,"unshift",t)},values(){return No(this,"values",t=>He(this,t))}};function No(t,i,e){const n=Co(t),o=n[i]();return n!==t&&!Be(t)&&(o._next=o.next,o.next=()=>{const s=o._next();return s.done||(s.value=e(s.value)),s}),o}const Bc=Array.prototype;function Ze(t,i,e,n,o,s){const l=Co(t),r=l!==t&&!Be(t),a=l[i];if(a!==Bc[i]){const m=a.apply(t,s);return r?Oe(m):m}let c=e;l!==t&&(r?c=function(m,g){return e.call(this,He(t,m),g,t)}:e.length>2&&(c=function(m,g){return e.call(this,m,g,t)}));const u=a.call(l,c,n);return r&&o?o(u):u}function Xs(t,i,e,n){const o=Co(t),s=o!==t&&!Be(t);let l=e,r=!1;o!==t&&(s?(r=n.length===0,l=function(c,u,m){return r&&(r=!1,c=He(t,c)),e.call(this,c,He(t,u),m,t)}):e.length>3&&(l=function(c,u,m){return e.call(this,c,u,m,t)}));const a=o[i](l,...n);return r?He(t,a):a}function Fo(t,i,e){const n=Rt(t);he(n,"iterate",Bn);const o=n[i](...e);return(o===-1||o===!1)&&$s(e[0])?(e[0]=Rt(e[0]),n[i](...e)):o}function ln(t,i,e=[]){oi(),ks();const n=Rt(t)[i].apply(t,e);return ws(),si(),n}const Tc=gs("__proto__,__v_isRef,__isVue"),rl=new Set(Object.getOwnPropertyNames(Symbol).filter(t=>t!=="arguments"&&t!=="caller").map(t=>Symbol[t]).filter(Pe));function Ec(t){Pe(t)||(t=String(t));const i=Rt(this);return he(i,"has",t),i.hasOwnProperty(t)}class ll{constructor(i=!1,e=!1){this._isReadonly=i,this._isShallow=e}get(i,e,n){if(e==="__v_skip")return i.__v_skip;const o=this._isReadonly,s=this._isShallow;if(e==="__v_isReactive")return!o;if(e==="__v_isReadonly")return o;if(e==="__v_isShallow")return s;if(e==="__v_raw")return n===(o?s?Hc:ul:s?dl:cl).get(i)||Object.getPrototypeOf(i)===Object.getPrototypeOf(n)?i:void 0;const l=$t(i);if(!o){let a;if(l&&(a=Ac[e]))return a;if(e==="hasOwnProperty")return Ec}const r=Reflect.get(i,e,Jt(i)?i:n);if((Pe(e)?rl.has(e):Tc(e))||(o||he(i,"get",e),s))return r;if(Jt(r)){const a=l&&bs(e)?r:r.value;return o&&Ht(a)?ss(a):a}return Ht(r)?o?ss(r):$o(r):r}}class al extends ll{constructor(i=!1){super(!1,i)}set(i,e,n,o){let s=i[e];const l=$t(i)&&bs(e);if(!this._isShallow){const c=ri(s);if(!Be(n)&&!ri(n)&&(s=Rt(s),n=Rt(n)),!l&&Jt(s)&&!Jt(n))return c||(s.value=n),!0}const r=l?Number(e)<i.length:zt(i,e),a=Reflect.set(i,e,n,Jt(i)?i:o);return i===Rt(o)&&a&&(r?Ue(n,s)&&Qe(i,"set",e,n):Qe(i,"add",e,n)),a}deleteProperty(i,e){const n=zt(i,e);i[e];const o=Reflect.deleteProperty(i,e);return o&&n&&Qe(i,"delete",e,void 0),o}has(i,e){const n=Reflect.has(i,e);return(!Pe(e)||!rl.has(e))&&he(i,"has",e),n}ownKeys(i){return he(i,"iterate",$t(i)?"length":Mi),Reflect.ownKeys(i)}}class Mc extends ll{constructor(i=!1){super(!0,i)}set(i,e){return!0}deleteProperty(i,e){return!0}}const Lc=new al,Dc=new Mc,Pc=new al(!0);const os=t=>t,Un=t=>Reflect.getPrototypeOf(t);function Oc(t,i,e){return function(...n){const o=this.__v_raw,s=Rt(o),l=Ki(s),r=t==="entries"||t===Symbol.iterator&&l,a=t==="keys"&&l,c=o[t](...n),u=e?os:i?Ji:Oe;return!i&&he(s,"iterate",a?ns:Mi),ue(Object.create(c),{next(){const{value:m,done:g}=c.next();return g?{value:m,done:g}:{value:r?[u(m[0]),u(m[1])]:u(m),done:g}}})}}function Wn(t){return function(...i){return t==="delete"?!1:t==="clear"?void 0:this}}function Rc(t,i){const e={get(o){const s=this.__v_raw,l=Rt(s),r=Rt(o);t||(Ue(o,r)&&he(l,"get",o),he(l,"get",r));const{has:a}=Un(l),c=i?os:t?Ji:Oe;if(a.call(l,o))return c(s.get(o));if(a.call(l,r))return c(s.get(r));s!==l&&s.get(o)},get size(){const o=this.__v_raw;return!t&&he(Rt(o),"iterate",Mi),o.size},has(o){const s=this.__v_raw,l=Rt(s),r=Rt(o);return t||(Ue(o,r)&&he(l,"has",o),he(l,"has",r)),o===r?s.has(o):s.has(o)||s.has(r)},forEach(o,s){const l=this,r=l.__v_raw,a=Rt(r),c=i?os:t?Ji:Oe;return!t&&he(a,"iterate",Mi),r.forEach((u,m)=>o.call(s,c(u),c(m),l))}};return ue(e,t?{add:Wn("add"),set:Wn("set"),delete:Wn("delete"),clear:Wn("clear")}:{add(o){const s=Rt(this),l=Un(s),r=Rt(o),a=!i&&!Be(o)&&!ri(o)?r:o;return l.has.call(s,a)||Ue(o,a)&&l.has.call(s,o)||Ue(r,a)&&l.has.call(s,r)||(s.add(a),Qe(s,"add",a,a)),this},set(o,s){!i&&!Be(s)&&!ri(s)&&(s=Rt(s));const l=Rt(this),{has:r,get:a}=Un(l);let c=r.call(l,o);c||(o=Rt(o),c=r.call(l,o));const u=a.call(l,o);return l.set(o,s),c?Ue(s,u)&&Qe(l,"set",o,s):Qe(l,"add",o,s),this},delete(o){const s=Rt(this),{has:l,get:r}=Un(s);let a=l.call(s,o);a||(o=Rt(o),a=l.call(s,o)),r&&r.call(s,o);const c=s.delete(o);return a&&Qe(s,"delete",o,void 0),c},clear(){const o=Rt(this),s=o.size!==0,l=o.clear();return s&&Qe(o,"clear",void 0,void 0),l}}),["keys","values","entries",Symbol.iterator].forEach(o=>{e[o]=Oc(o,t,i)}),e}function _s(t,i){const e=Rc(t,i);return(n,o,s)=>o==="__v_isReactive"?!t:o==="__v_isReadonly"?t:o==="__v_raw"?n:Reflect.get(zt(e,o)&&o in n?e:n,o,s)}const zc={get:_s(!1,!1)},Nc={get:_s(!1,!0)},Fc={get:_s(!0,!1)};const cl=new WeakMap,dl=new WeakMap,ul=new WeakMap,Hc=new WeakMap;function jc(t){switch(t){case"Object":case"Array":return 1;case"Map":case"Set":case"WeakMap":case"WeakSet":return 2;default:return 0}}function $o(t){return ri(t)?t:Cs(t,!1,Lc,zc,cl)}function Uc(t){return Cs(t,!1,Pc,Nc,dl)}function ss(t){return Cs(t,!0,Dc,Fc,ul)}function Cs(t,i,e,n,o){if(!Ht(t)||t.__v_raw&&!(i&&t.__v_isReactive)||t.__v_skip||!Object.isExtensible(t))return t;const s=o.get(t);if(s)return s;const l=jc(hc(t));if(l===0)return t;const r=new Proxy(t,l===2?n:e);return o.set(t,r),r}function Li(t){return ri(t)?Li(t.__v_raw):!!(t&&t.__v_isReactive)}function ri(t){return!!(t&&t.__v_isReadonly)}function Be(t){return!!(t&&t.__v_isShallow)}function $s(t){return t?!!t.__v_raw:!1}function Rt(t){const i=t&&t.__v_raw;return i?Rt(i):t}function Wc(t){return!zt(t,"__v_skip")&&Object.isExtensible(t)&&Gr(t,"__v_skip",!0),t}const Oe=t=>Ht(t)?$o(t):t,Ji=t=>Ht(t)?ss(t):t;function Jt(t){return t?t.__v_isRef===!0:!1}function vt(t){return Vc(t,!1)}function Vc(t,i){return Jt(t)?t:new qc(t,i)}class qc{constructor(i,e){this.dep=new Ss,this.__v_isRef=!0,this.__v_isShallow=!1,this._rawValue=e?i:Rt(i),this._value=e?i:Oe(i),this.__v_isShallow=e}get value(){return this.dep.track(),this._value}set value(i){const e=this._rawValue,n=this.__v_isShallow||Be(i)||ri(i);i=n?i:Rt(i),Ue(i,e)&&(this._rawValue=i,this._value=n?i:Oe(i),this.dep.trigger())}}function bt(t){return Jt(t)?t.value:t}const Kc={get:(t,i,e)=>i==="__v_raw"?t:bt(Reflect.get(t,i,e)),set:(t,i,e,n)=>{const o=t[i];return Jt(o)&&!Jt(e)?(o.value=e,!0):Reflect.set(t,i,e,n)}};function fl(t){return Li(t)?t:new Proxy(t,Kc)}class Gc{constructor(i,e,n){this.fn=i,this.setter=e,this._value=void 0,this.dep=new Ss(this),this.__v_isRef=!0,this.deps=void 0,this.depsTail=void 0,this.flags=16,this.globalVersion=An-1,this.next=void 0,this.effect=this,this.__v_isReadonly=!e,this.isSSR=n}notify(){if(this.flags|=16,!(this.flags&8)&&Vt!==this)return tl(this,!0),!0}get value(){const i=this.dep.track();return nl(this),i&&(i.version=this.dep.version),this._value}set value(i){this.setter&&this.setter(i)}}function Zc(t,i,e=!1){let n,o;return Bt(t)?n=t:(n=t.get,o=t.set),new Gc(n,o,e)}const Vn={},ao=new WeakMap;let Ai;function Yc(t,i=!1,e=Ai){if(e){let n=ao.get(e);n||ao.set(e,n=[]),n.push(t)}}function Jc(t,i,e=Wt){const{immediate:n,deep:o,once:s,scheduler:l,augmentJob:r,call:a}=e,c=A=>o?A:Be(A)||o===!1||o===0?ti(A,1):ti(A);let u,m,g,d,b=!1,f=!1;if(Jt(t)?(m=()=>t.value,b=Be(t)):Li(t)?(m=()=>c(t),b=!0):$t(t)?(f=!0,b=t.some(A=>Li(A)||Be(A)),m=()=>t.map(A=>{if(Jt(A))return A.value;if(Li(A))return c(A);if(Bt(A))return a?a(A,2):A()})):Bt(t)?i?m=a?()=>a(t,2):t:m=()=>{if(g){oi();try{g()}finally{si()}}const A=Ai;Ai=u;try{return a?a(t,3,[d]):t(d)}finally{Ai=A}}:m=qe,i&&o){const A=m,T=o===!0?1/0:o;m=()=>ti(A(),T)}const v=Cc(),k=()=>{u.stop(),v&&v.active&&vs(v.effects,u)};if(s&&i){const A=i;i=(...T)=>{const I=A(...T);return k(),I}}let S=f?new Array(t.length).fill(Vn):Vn;const x=A=>{if(!(!(u.flags&1)||!u.dirty&&!A))if(i){const T=u.run();if(A||o||b||(f?T.some((I,w)=>Ue(I,S[w])):Ue(T,S))){g&&g();const I=Ai;Ai=u;try{const w=[T,S===Vn?void 0:f&&S[0]===Vn?[]:S,d];S=T,a?a(i,3,w):i(...w)}finally{Ai=I}}}else u.run()};return r&&r(x),u=new Xr(m),u.scheduler=l?()=>l(x,!1):x,d=A=>Yc(A,!1,u),g=u.onStop=()=>{const A=ao.get(u);if(A){if(a)a(A,4);else for(const T of A)T();ao.delete(u)}},i?n?x(!0):S=u.run():l?l(x.bind(null,!0),!0):u.run(),k.pause=u.pause.bind(u),k.resume=u.resume.bind(u),k.stop=k,k}function ti(t,i=1/0,e){if(i<=0||!Ht(t)||t.__v_skip||(e=e||new Map,(e.get(t)||0)>=i))return t;if(e.set(t,i),i--,Jt(t))ti(t.value,i,e);else if($t(t))for(let n=0;n<t.length;n++)ti(t[n],i,e);else if(en(t)||Ki(t))t.forEach(n=>{ti(n,i,e)});else if(Kr(t)){for(const n in t)ti(t[n],i,e);for(const n of Object.getOwnPropertySymbols(t))Object.prototype.propertyIsEnumerable.call(t,n)&&ti(t[n],i,e)}return t}/**
* @vue/runtime-core v3.5.40
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/function On(t,i,e,n){try{return n?t(...n):t()}catch(o){Io(o,i,e)}}function Re(t,i,e,n){if(Bt(t)){const o=On(t,i,e,n);return o&&Vr(o)&&o.catch(s=>{Io(s,i,e)}),o}if($t(t)){const o=[];for(let s=0;s<t.length;s++)o.push(Re(t[s],i,e,n));return o}}function Io(t,i,e,n=!0){const o=i?i.vnode:null,{errorHandler:s,throwUnhandledErrorInProduction:l}=i&&i.appContext.config||Wt;if(i){let r=i.parent;const a=i.proxy,c=`https://vuejs.org/error-reference/#runtime-${e}`;for(;r;){const u=r.ec;if(u){for(let m=0;m<u.length;m++)if(u[m](t,a,c)===!1)return}r=r.parent}if(s){oi(),On(s,null,10,[t,a,c]),si();return}}Xc(t,e,o,n,l)}function Xc(t,i,e,n=!0,o=!1){if(o)throw t;console.error(t)}const be=[];let Fe=-1;const Gi=[];let pi=null,ji=0;const pl=Promise.resolve();let co=null;function hl(t){const i=co||pl;return t?i.then(this?t.bind(this):t):i}function Qc(t){let i=Fe+1,e=be.length;for(;i<e;){const n=i+e>>>1,o=be[n],s=Tn(o);s<t||s===t&&o.flags&2?i=n+1:e=n}return i}function Is(t){if(!(t.flags&1)){const i=Tn(t),e=be[be.length-1];!e||!(t.flags&2)&&i>=Tn(e)?be.push(t):be.splice(Qc(i),0,t),t.flags|=1,ml()}}function ml(){co||(co=pl.then(vl))}function td(t){$t(t)?Gi.push(...t):pi&&t.id===-1?pi.splice(ji+1,0,t):t.flags&1||(Gi.push(t),t.flags|=1),ml()}function Qs(t,i,e=Fe+1){for(;e<be.length;e++){const n=be[e];if(n&&n.flags&2){if(t&&n.id!==t.uid)continue;be.splice(e,1),e--,n.flags&4&&(n.flags&=-2),n(),n.flags&4||(n.flags&=-2)}}}function gl(t){if(Gi.length){const i=[...new Set(Gi)].sort((e,n)=>Tn(e)-Tn(n));if(Gi.length=0,pi){pi.push(...i);return}for(pi=i,ji=0;ji<pi.length;ji++){const e=pi[ji];e.flags&4&&(e.flags&=-2),e.flags&8||e(),e.flags&=-2}pi=null,ji=0}}const Tn=t=>t.id==null?t.flags&2?-1:1/0:t.id;function vl(t){try{for(Fe=0;Fe<be.length;Fe++){const i=be[Fe];i&&!(i.flags&8)&&(i.flags&4&&(i.flags&=-2),On(i,i.i,i.i?15:14),i.flags&4||(i.flags&=-2))}}finally{for(;Fe<be.length;Fe++){const i=be[Fe];i&&(i.flags&=-2)}Fe=-1,be.length=0,gl(),co=null,(be.length||Gi.length)&&vl()}}let de=null,bl=null;function uo(t){const i=de;return de=t,bl=t&&t.type.__scopeId||null,i}function yl(t,i=de,e){if(!i||t._n)return t;const n=(...o)=>{n._d&&ur(-1);const s=uo(i),l=ii.length;let r;try{r=t(...o)}finally{for(let a=ii.length;a>l;a--)Ls();uo(s),n._d&&ur(1)}return r};return n._n=!0,n._c=!0,n._d=!0,n}function Te(t,i){if(de===null)return t;const e=Eo(de),n=t.dirs||(t.dirs=[]);for(let o=0;o<i.length;o++){let[s,l,r,a=Wt]=i[o];s&&(Bt(s)&&(s={mounted:s,updated:s}),s.deep&&ti(l),n.push({dir:s,instance:e,value:l,oldValue:void 0,arg:r,modifiers:a}))}return t}function xi(t,i,e,n){const o=t.dirs,s=i&&i.dirs;for(let l=0;l<o.length;l++){const r=o[l];s&&(r.oldValue=s[l].value);let a=r.dir[n];a&&(oi(),Re(a,e,8,[t.el,r,t,i]),si())}}function ed(t,i){if(me){let e=me.provides;const n=me.parent&&me.parent.provides;n===e&&(e=me.provides=Object.create(n)),e[t]=i}}function ei(t,i,e=!1){const n=Qd();if(n||Yi){let o=Yi?Yi._context.provides:n?n.parent==null||n.ce?n.vnode.appContext&&n.vnode.appContext.provides:n.parent.provides:void 0;if(o&&t in o)return o[t];if(arguments.length>1)return e&&Bt(i)?i.call(n&&n.proxy):i}}const id=Symbol.for("v-scx"),nd=()=>ei(id);function Di(t,i,e){return kl(t,i,e)}function kl(t,i,e=Wt){const{immediate:n,deep:o,flush:s,once:l}=e,r=ue({},e),a=i&&n||!i&&s!=="post";let c;if(Mn){if(s==="sync"){const d=nd();c=d.__watcherHandles||(d.__watcherHandles=[])}else if(!a){const d=()=>{};return d.stop=qe,d.resume=qe,d.pause=qe,d}}const u=me;r.call=(d,b,f)=>Re(d,u,b,f);let m=!1;s==="post"?r.scheduler=d=>{we(d,u&&u.suspense)}:s!=="sync"&&(m=!0,r.scheduler=(d,b)=>{b?d():Is(d)}),r.augmentJob=d=>{i&&(d.flags|=4),m&&(d.flags|=2,u&&(d.id=u.uid,d.i=u))};const g=Jc(t,i,r);return Mn&&(c?c.push(g):a&&g()),g}function od(t,i,e){const n=this.proxy,o=ee(t)?t.includes(".")?wl(n,t):()=>n[t]:t.bind(n,n);let s;Bt(i)?s=i:(s=i.handler,e=i);const l=zn(this),r=kl(o,s.bind(n),e);return l(),r}function wl(t,i){const e=i.split(".");return()=>{let n=t;for(let o=0;o<e.length&&n;o++)n=n[e[o]];return n}}const sd=Symbol("_vte"),rd=t=>t.__isTeleport,Ho=Symbol("_leaveCb");function As(t,i){t.shapeFlag&6&&t.component?(t.transition=i,As(t.component.subTree,i)):t.shapeFlag&128?(t.ssContent.transition=i.clone(t.ssContent),t.ssFallback.transition=i.clone(t.ssFallback)):t.transition=i}function _e(t,i){return Bt(t)?ue({name:t.name},i,{setup:t}):t}function xl(t){t.ids=[t.ids[0]+t.ids[2]+++"-",0,0]}function tr(t,i){let e;return!!((e=Object.getOwnPropertyDescriptor(t,i))&&!e.configurable)}const fo=new WeakMap;function gn(t,i,e,n,o=!1){if($t(t)){t.forEach((f,v)=>gn(f,i&&($t(i)?i[v]:i),e,n,o));return}if(Zi(n)&&!o){n.shapeFlag&512&&n.type.__asyncResolved&&n.component.subTree.component&&gn(t,i,e,n.component.subTree);return}const s=n.shapeFlag&4?Eo(n.component):n.el,l=o?null:s,{i:r,r:a}=t,c=i&&i.r,u=r.refs===Wt?r.refs={}:r.refs,m=r.setupState,g=Rt(m),d=m===Wt?Wr:f=>tr(u,f)?!1:zt(g,f),b=(f,v)=>!(v&&tr(u,v));if(c!=null&&c!==a){if(er(i),ee(c))u[c]=null,d(c)&&(m[c]=null);else if(Jt(c)){const f=i;b(c,f.k)&&(c.value=null),f.k&&(u[f.k]=null)}}if(Bt(a))On(a,r,12,[l,u]);else{const f=ee(a),v=Jt(a);if(f||v){const k=()=>{if(t.f){const S=f?d(a)?m[a]:u[a]:b()||!t.k?a.value:u[t.k];if(o)$t(S)&&vs(S,s);else if($t(S))S.includes(s)||S.push(s);else if(f)u[a]=[s],d(a)&&(m[a]=u[a]);else{const x=[s];b(a,t.k)&&(a.value=x),t.k&&(u[t.k]=x)}}else f?(u[a]=l,d(a)&&(m[a]=l)):v&&(b(a,t.k)&&(a.value=l),t.k&&(u[t.k]=l))};if(l){const S=()=>{k(),fo.delete(t)};S.id=-1,fo.set(t,S),we(S,e)}else er(t),k()}}}function er(t){const i=fo.get(t);i&&(i.flags|=8,fo.delete(t))}_o().requestIdleCallback;_o().cancelIdleCallback;const Zi=t=>!!t.type.__asyncLoader,Sl=t=>t.type.__isKeepAlive;function ld(t,i){_l(t,"a",i)}function ad(t,i){_l(t,"da",i)}function _l(t,i,e=me){const n=t.__wdc||(t.__wdc=()=>{let o=e;for(;o;){if(o.isDeactivated)return;o=o.parent}return t()});if(Ao(i,n,e),e){let o=e.parent;for(;o&&o.parent;)Sl(o.parent.vnode)&&cd(n,i,e,o),o=o.parent}}function cd(t,i,e,n){const o=Ao(i,t,n,!0);Ts(()=>{vs(n[i],o)},e)}function Ao(t,i,e=me,n=!1){if(e){const o=e[t]||(e[t]=[]),s=i.__weh||(i.__weh=(...l)=>{oi();const r=zn(e),a=Re(i,e,t,l);return r(),si(),a});return n?o.unshift(s):o.push(s),s}}const ai=t=>(i,e=me)=>{(!Mn||t==="sp")&&Ao(t,(...n)=>i(...n),e)},dd=ai("bm"),Rn=ai("m"),ud=ai("bu"),fd=ai("u"),Bs=ai("bum"),Ts=ai("um"),pd=ai("sp"),hd=ai("rtg"),md=ai("rtc");function gd(t,i=me){Ao("ec",t,i)}const vd="components";function bd(t,i){return kd(vd,t,!0,i)||t}const yd=Symbol.for("v-ndc");function kd(t,i,e=!0,n=!1){const o=de||me;if(o){const s=o.type;{const r=ou(s,!1);if(r&&(r===i||r===ye(i)||r===xo(ye(i))))return s}const l=ir(o[t]||s[t],i)||ir(o.appContext[t],i);return!l&&n?s:l}}function ir(t,i){return t&&(t[i]||t[ye(i)]||t[xo(ye(i))])}function xe(t,i,e,n){let o;const s=e,l=$t(t);if(l||ee(t)){const r=l&&Li(t);let a=!1,c=!1;r&&(a=!Be(t),c=ri(t),t=Co(t)),o=new Array(t.length);for(let u=0,m=t.length;u<m;u++)o[u]=i(a?c?Ji(Oe(t[u])):Oe(t[u]):t[u],u,void 0,s)}else if(typeof t=="number"){o=new Array(t);for(let r=0;r<t;r++)o[r]=i(r+1,r,void 0,s)}else if(Ht(t))if(t[Symbol.iterator])o=Array.from(t,(r,a)=>i(r,a,void 0,s));else{const r=Object.keys(t);o=new Array(r.length);for(let a=0,c=r.length;a<c;a++){const u=r[a];o[a]=i(t[u],u,a,s)}}else o=[];return o}function qn(t,i,e={},n,o,s){if(de.ce||de.parent&&Zi(de.parent)&&de.parent.ce){const c=e,u=Object.keys(c).length>0;return i!=="default"&&(c.name=i),ot(),Le(Kt,null,[ut("slot",c,n&&n())],u?-2:64)}let l=t[i];l&&l._c&&(l._d=!1);const r=ii.length;ot();let a;try{const c=l&&Cl(l(e)),u=e.key||s||c&&c.key;a=Le(Kt,{key:(u&&!Pe(u)?u:`_${i}`)+(!c&&n?"_fb":"")},c||(n?n():[]),c&&t._===1?64:-2)}catch(c){for(let u=ii.length;u>r;u--)Ls();throw c}finally{l&&l._c&&(l._d=!0)}return a}function Cl(t){return t.some(i=>Ds(i)?!(i.type===li||i.type===Kt&&!Cl(i.children)):!0)?t:null}const rs=t=>t?Vl(t)?Eo(t):rs(t.parent):null,vn=ue(Object.create(null),{$:t=>t,$el:t=>t.vnode.el,$data:t=>t.data,$props:t=>t.props,$attrs:t=>t.attrs,$slots:t=>t.slots,$refs:t=>t.refs,$parent:t=>rs(t.parent),$root:t=>rs(t.root),$host:t=>t.ce,$emit:t=>t.emit,$options:t=>Il(t),$forceUpdate:t=>t.f||(t.f=()=>{Is(t.update)}),$nextTick:t=>t.n||(t.n=hl.bind(t.proxy)),$watch:t=>od.bind(t)}),jo=(t,i)=>t!==Wt&&!t.__isScriptSetup&&zt(t,i),wd={get({_:t},i){if(i==="__v_skip")return!0;const{ctx:e,setupState:n,data:o,props:s,accessCache:l,type:r,appContext:a}=t;if(i[0]!=="$"){const g=l[i];if(g!==void 0)switch(g){case 1:return n[i];case 2:return o[i];case 4:return e[i];case 3:return s[i]}else{if(jo(n,i))return l[i]=1,n[i];if(o!==Wt&&zt(o,i))return l[i]=2,o[i];if(zt(s,i))return l[i]=3,s[i];if(e!==Wt&&zt(e,i))return l[i]=4,e[i];ls&&(l[i]=0)}}const c=vn[i];let u,m;if(c)return i==="$attrs"&&he(t.attrs,"get",""),c(t);if((u=r.__cssModules)&&(u=u[i]))return u;if(e!==Wt&&zt(e,i))return l[i]=4,e[i];if(m=a.config.globalProperties,zt(m,i))return m[i]},set({_:t},i,e){const{data:n,setupState:o,ctx:s}=t;return jo(o,i)?(o[i]=e,!0):n!==Wt&&zt(n,i)?(n[i]=e,!0):zt(t.props,i)||i[0]==="$"&&i.slice(1)in t?!1:(s[i]=e,!0)},has({_:{data:t,setupState:i,accessCache:e,ctx:n,appContext:o,props:s,type:l}},r){let a;return!!(e[r]||t!==Wt&&r[0]!=="$"&&zt(t,r)||jo(i,r)||zt(s,r)||zt(n,r)||zt(vn,r)||zt(o.config.globalProperties,r)||(a=l.__cssModules)&&a[r])},defineProperty(t,i,e){return e.get!=null?t._.accessCache[i]=0:zt(e,"value")&&this.set(t,i,e.value,null),Reflect.defineProperty(t,i,e)}};function nr(t){return $t(t)?t.reduce((i,e)=>(i[e]=null,i),{}):t}let ls=!0;function xd(t){const i=Il(t),e=t.proxy,n=t.ctx;ls=!1,i.beforeCreate&&or(i.beforeCreate,t,"bc");const{data:o,computed:s,methods:l,watch:r,provide:a,inject:c,created:u,beforeMount:m,mounted:g,beforeUpdate:d,updated:b,activated:f,deactivated:v,beforeDestroy:k,beforeUnmount:S,destroyed:x,unmounted:A,render:T,renderTracked:I,renderTriggered:w,errorCaptured:N,serverPrefetch:F,expose:j,inheritAttrs:J,components:$,directives:O,filters:y}=i;if(c&&Sd(c,n,null),l)for(const P in l){const U=l[P];Bt(U)&&(n[P]=U.bind(e))}if(o){const P=o.call(e,e);Ht(P)&&(t.data=$o(P))}if(ls=!0,s)for(const P in s){const U=s[P],W=Bt(U)?U.bind(e,e):Bt(U.get)?U.get.bind(e,e):qe,tt=!Bt(U)&&Bt(U.set)?U.set.bind(e):qe,B=St({get:W,set:tt});Object.defineProperty(n,P,{enumerable:!0,configurable:!0,get:()=>B.value,set:M=>B.value=M})}if(r)for(const P in r)$l(r[P],n,e,P);if(a){const P=Bt(a)?a.call(e):a;Reflect.ownKeys(P).forEach(U=>{ed(U,P[U])})}u&&or(u,t,"c");function X(P,U){$t(U)?U.forEach(W=>P(W.bind(e))):U&&P(U.bind(e))}if(X(dd,m),X(Rn,g),X(ud,d),X(fd,b),X(ld,f),X(ad,v),X(gd,N),X(md,I),X(hd,w),X(Bs,S),X(Ts,A),X(pd,F),$t(j))if(j.length){const P=t.exposed||(t.exposed={});j.forEach(U=>{Object.defineProperty(P,U,{get:()=>e[U],set:W=>e[U]=W,enumerable:!0})})}else t.exposed||(t.exposed={});T&&t.render===qe&&(t.render=T),J!=null&&(t.inheritAttrs=J),$&&(t.components=$),O&&(t.directives=O),F&&xl(t)}function Sd(t,i,e=qe){$t(t)&&(t=as(t));for(const n in t){const o=t[n];let s;Ht(o)?"default"in o?s=ei(o.from||n,o.default,!0):s=ei(o.from||n):s=ei(o),Jt(s)?Object.defineProperty(i,n,{enumerable:!0,configurable:!0,get:()=>s.value,set:l=>s.value=l}):i[n]=s}}function or(t,i,e){Re($t(t)?t.map(n=>n.bind(i.proxy)):t.bind(i.proxy),i,e)}function $l(t,i,e,n){let o=n.includes(".")?wl(e,n):()=>e[n];if(ee(t)){const s=i[t];Bt(s)&&Di(o,s)}else if(Bt(t))Di(o,t.bind(e));else if(Ht(t))if($t(t))t.forEach(s=>$l(s,i,e,n));else{const s=Bt(t.handler)?t.handler.bind(e):i[t.handler];Bt(s)&&Di(o,s,t)}}function Il(t){const i=t.type,{mixins:e,extends:n}=i,{mixins:o,optionsCache:s,config:{optionMergeStrategies:l}}=t.appContext,r=s.get(i);let a;return r?a=r:!o.length&&!e&&!n?a=i:(a={},o.length&&o.forEach(c=>po(a,c,l,!0)),po(a,i,l)),Ht(i)&&s.set(i,a),a}function po(t,i,e,n=!1){const{mixins:o,extends:s}=i;s&&po(t,s,e,!0),o&&o.forEach(l=>po(t,l,e,!0));for(const l in i)if(!(n&&l==="expose")){const r=_d[l]||e&&e[l];t[l]=r?r(t[l],i[l]):i[l]}return t}const _d={data:sr,props:rr,emits:rr,methods:dn,computed:dn,beforeCreate:ve,created:ve,beforeMount:ve,mounted:ve,beforeUpdate:ve,updated:ve,beforeDestroy:ve,beforeUnmount:ve,destroyed:ve,unmounted:ve,activated:ve,deactivated:ve,errorCaptured:ve,serverPrefetch:ve,components:dn,directives:dn,watch:$d,provide:sr,inject:Cd};function sr(t,i){return i?t?function(){return ue(Bt(t)?t.call(this,this):t,Bt(i)?i.call(this,this):i)}:i:t}function Cd(t,i){return dn(as(t),as(i))}function as(t){if($t(t)){const i={};for(let e=0;e<t.length;e++)i[t[e]]=t[e];return i}return t}function ve(t,i){return t?[...new Set([].concat(t,i))]:i}function dn(t,i){return t?ue(Object.create(null),t,i):i}function rr(t,i){return t?$t(t)&&$t(i)?[...new Set([...t,...i])]:ue(Object.create(null),nr(t),nr(i??{})):i}function $d(t,i){if(!t)return i;if(!i)return t;const e=ue(Object.create(null),t);for(const n in i)e[n]=ve(t[n],i[n]);return e}function Al(){return{app:null,config:{isNativeTag:Wr,performance:!1,globalProperties:{},optionMergeStrategies:{},errorHandler:void 0,warnHandler:void 0,compilerOptions:{}},mixins:[],components:{},directives:{},provides:Object.create(null),optionsCache:new WeakMap,propsCache:new WeakMap,emitsCache:new WeakMap}}let Id=0;function Ad(t,i){return function(n,o=null){Bt(n)||(n=ue({},n)),o!=null&&!Ht(o)&&(o=null);const s=Al(),l=new WeakSet,r=[];let a=!1;const c=s.app={_uid:Id++,_component:n,_props:o,_container:null,_context:s,_instance:null,version:ru,get config(){return s.config},set config(u){},use(u,...m){return l.has(u)||(u&&Bt(u.install)?(l.add(u),u.install(c,...m)):Bt(u)&&(l.add(u),u(c,...m))),c},mixin(u){return s.mixins.includes(u)||s.mixins.push(u),c},component(u,m){return m?(s.components[u]=m,c):s.components[u]},directive(u,m){return m?(s.directives[u]=m,c):s.directives[u]},mount(u,m,g){if(!a){const d=c._ceVNode||ut(n,o);return d.appContext=s,g===!0?g="svg":g===!1&&(g=void 0),t(d,u,g),a=!0,c._container=u,u.__vue_app__=c,Eo(d.component)}},onUnmount(u){r.push(u)},unmount(){a&&(Re(r,c._instance,16),t(null,c._container),delete c._container.__vue_app__)},provide(u,m){return s.provides[u]=m,c},runWithContext(u){const m=Yi;Yi=c;try{return u()}finally{Yi=m}}};return c}}let Yi=null;const Bd=(t,i)=>i==="modelValue"||i==="model-value"?t.modelModifiers:t[`${i}Modifiers`]||t[`${ye(i)}Modifiers`]||t[`${yi(i)}Modifiers`];function Td(t,i,...e){if(t.isUnmounted)return;const n=t.vnode.props||Wt;let o=e;const s=i.startsWith("update:"),l=s&&Bd(n,i.slice(7));l&&(l.trim&&(o=e.map(u=>ee(u)?u.trim():u)),l.number&&(o=e.map(So)));let r,a=n[r=Oo(i)]||n[r=Oo(ye(i))];!a&&s&&(a=n[r=Oo(yi(i))]),a&&Re(a,t,6,o);const c=n[r+"Once"];if(c){if(!t.emitted)t.emitted={};else if(t.emitted[r])return;t.emitted[r]=!0,Re(c,t,6,o)}}const Ed=new WeakMap;function Bl(t,i,e=!1){const n=e?Ed:i.emitsCache,o=n.get(t);if(o!==void 0)return o;const s=t.emits;let l={},r=!1;if(!Bt(t)){const a=c=>{const u=Bl(c,i,!0);u&&(r=!0,ue(l,u))};!e&&i.mixins.length&&i.mixins.forEach(a),t.extends&&a(t.extends),t.mixins&&t.mixins.forEach(a)}return!s&&!r?(Ht(t)&&n.set(t,null),null):($t(s)?s.forEach(a=>l[a]=null):ue(l,s),Ht(t)&&n.set(t,l),l)}function Bo(t,i){return!t||!yo(i)?!1:(i=i.slice(2),i=i==="Once"?i:i.replace(/Once$/,""),zt(t,i[0].toLowerCase()+i.slice(1))||zt(t,yi(i))||zt(t,i))}function lr(t){const{type:i,vnode:e,proxy:n,withProxy:o,propsOptions:[s],slots:l,attrs:r,emit:a,render:c,renderCache:u,props:m,data:g,setupState:d,ctx:b,inheritAttrs:f}=t,v=uo(t);let k,S;try{if(e.shapeFlag&4){const A=o||n,T=A;k=je(c.call(T,A,u,m,d,g,b)),S=r}else{const A=i;k=je(A.length>1?A(m,{attrs:r,slots:l,emit:a}):A(m,null)),S=i.props?r:Md(r)}}catch(A){ii.length=0,Io(A,t,1),k=ut(li)}let x=k;if(S&&f!==!1){const A=Object.keys(S),{shapeFlag:T}=x;A.length&&T&7&&(s&&A.some(ko)&&(S=Ld(S,s)),x=Xi(x,S,!1,!0))}return e.dirs&&(x=Xi(x,null,!1,!0),x.dirs=x.dirs?x.dirs.concat(e.dirs):e.dirs),e.transition&&As(x,e.transition),k=x,uo(v),k}const Md=t=>{let i;for(const e in t)(e==="class"||e==="style"||yo(e))&&((i||(i={}))[e]=t[e]);return i},Ld=(t,i)=>{const e={};for(const n in t)(!ko(n)||!(n.slice(9)in i))&&(e[n]=t[n]);return e};function Dd(t,i,e){const{props:n,children:o,component:s}=t,{props:l,children:r,patchFlag:a}=i,c=s.emitsOptions;if(i.dirs||i.transition)return!0;if(e&&a>=0){if(a&1024)return!0;if(a&16)return n?ar(n,l,c):!!l;if(a&8){const u=i.dynamicProps;for(let m=0;m<u.length;m++){const g=u[m];if(Tl(l,n,g)&&!Bo(c,g))return!0}}}else return(o||r)&&(!r||!r.$stable)?!0:n===l?!1:n?l?ar(n,l,c):!0:!!l;return!1}function ar(t,i,e){const n=Object.keys(i);if(n.length!==Object.keys(t).length)return!0;for(let o=0;o<n.length;o++){const s=n[o];if(Tl(i,t,s)&&!Bo(e,s))return!0}return!1}function Tl(t,i,e){const n=t[e],o=i[e];return e==="style"&&Ht(n)&&Ht(o)?!nn(n,o):n!==o}function Pd({vnode:t,parent:i,suspense:e},n){for(;i;){const o=i.subTree;if(o.suspense&&o.suspense.activeBranch===t&&(o.suspense.vnode.el=o.el=n,t=o),o===t)(t=i.vnode).el=n,i=i.parent;else break}e&&e.activeBranch===t&&(e.vnode.el=n)}const El={},Ml=()=>Object.create(El),Ll=t=>Object.getPrototypeOf(t)===El;function Od(t,i,e,n=!1){const o={},s=Ml();t.propsDefaults=Object.create(null),Dl(t,i,o,s);for(const l in t.propsOptions[0])l in o||(o[l]=void 0);e?t.props=n?o:Uc(o):t.type.props?t.props=o:t.props=s,t.attrs=s}function Rd(t,i,e,n){const{props:o,attrs:s,vnode:{patchFlag:l}}=t,r=Rt(o),[a]=t.propsOptions;let c=!1;if((n||l>0)&&!(l&16)){if(l&8){const u=t.vnode.dynamicProps;for(let m=0;m<u.length;m++){let g=u[m];if(Bo(t.emitsOptions,g))continue;const d=i[g];if(a)if(zt(s,g))d!==s[g]&&(s[g]=d,c=!0);else{const b=ye(g);o[b]=cs(a,r,b,d,t,!1)}else d!==s[g]&&(s[g]=d,c=!0)}}}else{Dl(t,i,o,s)&&(c=!0);let u;for(const m in r)(!i||!zt(i,m)&&((u=yi(m))===m||!zt(i,u)))&&(a?e&&(e[m]!==void 0||e[u]!==void 0)&&(o[m]=cs(a,r,m,void 0,t,!0)):delete o[m]);if(s!==r)for(const m in s)(!i||!zt(i,m))&&(delete s[m],c=!0)}c&&Qe(t.attrs,"set","")}function Dl(t,i,e,n){const[o,s]=t.propsOptions;let l=!1,r;if(i)for(let a in i){if(pn(a))continue;const c=i[a];let u;o&&zt(o,u=ye(a))?!s||!s.includes(u)?e[u]=c:(r||(r={}))[u]=c:Bo(t.emitsOptions,a)||(!(a in n)||c!==n[a])&&(n[a]=c,l=!0)}if(s){const a=Rt(e),c=r||Wt;for(let u=0;u<s.length;u++){const m=s[u];e[m]=cs(o,a,m,c[m],t,!zt(c,m))}}return l}function cs(t,i,e,n,o,s){const l=t[e];if(l!=null){const r=zt(l,"default");if(r&&n===void 0){const a=l.default;if(l.type!==Function&&!l.skipFactory&&Bt(a)){const{propsDefaults:c}=o;if(e in c)n=c[e];else{const u=zn(o);n=c[e]=a.call(null,i),u()}}else n=a;o.ce&&o.ce._setProp(e,n)}l[0]&&(s&&!r?n=!1:l[1]&&(n===""||n===yi(e))&&(n=!0))}return n}const zd=new WeakMap;function Pl(t,i,e=!1){const n=e?zd:i.propsCache,o=n.get(t);if(o)return o;const s=t.props,l={},r=[];let a=!1;if(!Bt(t)){const u=m=>{a=!0;const[g,d]=Pl(m,i,!0);ue(l,g),d&&r.push(...d)};!e&&i.mixins.length&&i.mixins.forEach(u),t.extends&&u(t.extends),t.mixins&&t.mixins.forEach(u)}if(!s&&!a)return Ht(t)&&n.set(t,qi),qi;if($t(s))for(let u=0;u<s.length;u++){const m=ye(s[u]);cr(m)&&(l[m]=Wt)}else if(s)for(const u in s){const m=ye(u);if(cr(m)){const g=s[u],d=l[m]=$t(g)||Bt(g)?{type:g}:ue({},g),b=d.type;let f=!1,v=!0;if($t(b))for(let k=0;k<b.length;++k){const S=b[k],x=Bt(S)&&S.name;if(x==="Boolean"){f=!0;break}else x==="String"&&(v=!1)}else f=Bt(b)&&b.name==="Boolean";d[0]=f,d[1]=v,(f||zt(d,"default"))&&r.push(m)}}const c=[l,r];return Ht(t)&&n.set(t,c),c}function cr(t){return t[0]!=="$"&&!pn(t)}const Es=t=>t==="_"||t==="_ctx"||t==="$stable",Ms=t=>$t(t)?t.map(je):[je(t)],Nd=(t,i,e)=>{if(i._n)return i;const n=yl((...o)=>Ms(i(...o)),e);return n._c=!1,n},Ol=(t,i,e)=>{const n=t._ctx;for(const o in t){if(Es(o))continue;const s=t[o];if(Bt(s))i[o]=Nd(o,s,n);else if(s!=null){const l=Ms(s);i[o]=()=>l}}},Rl=(t,i)=>{const e=Ms(i);t.slots.default=()=>e},zl=(t,i,e)=>{for(const n in i)(e||!Es(n))&&(t[n]=i[n])},Fd=(t,i,e)=>{const n=t.slots=Ml();if(t.vnode.shapeFlag&32){const o=i._;o?(zl(n,i,e),e&&Gr(n,"_",o,!0)):Ol(i,n)}else i&&Rl(t,i)},Hd=(t,i,e)=>{const{vnode:n,slots:o}=t;let s=!0,l=Wt;if(n.shapeFlag&32){const r=i._;r?e&&r===1?s=!1:zl(o,i,e):(s=!i.$stable,Ol(i,o)),l=i}else i&&(Rl(t,i),l={default:1});if(s)for(const r in o)!Es(r)&&l[r]==null&&delete o[r]},we=qd;function jd(t){return Ud(t)}function Ud(t,i){const e=_o();e.__VUE__=!0;const{insert:n,remove:o,patchProp:s,createElement:l,createText:r,createComment:a,setText:c,setElementText:u,parentNode:m,nextSibling:g,setScopeId:d=qe,insertStaticContent:b}=t,f=(E,z,p,H=null,R=null,_=null,C=void 0,L=null,G=!!z.dynamicChildren)=>{if(E===z)return;E&&!an(E,z)&&(H=dt(E),M(E,R,_,!0),E=null),z.patchFlag===-2&&(G=!1,z.dynamicChildren=null);const{type:K,ref:q,shapeFlag:et}=z;switch(K){case To:v(E,z,p,H);break;case li:k(E,z,p,H);break;case Xn:E==null&&S(z,p,H,C);break;case Kt:$(E,z,p,H,R,_,C,L,G);break;default:et&1?T(E,z,p,H,R,_,C,L,G):et&6?O(E,z,p,H,R,_,C,L,G):(et&64||et&128)&&K.process(E,z,p,H,R,_,C,L,G,gt)}q!=null&&R?gn(q,E&&E.ref,_,z||E,!z):q==null&&E&&E.ref!=null&&gn(E.ref,null,_,E,!0)},v=(E,z,p,H)=>{if(E==null)n(z.el=r(z.children),p,H);else{const R=z.el=E.el;z.children!==E.children&&c(R,z.children)}},k=(E,z,p,H)=>{E==null?n(z.el=a(z.children||""),p,H):z.el=E.el},S=(E,z,p,H)=>{[E.el,E.anchor]=b(E.children,z,p,H,E.el,E.anchor)},x=({el:E,anchor:z},p,H)=>{let R;for(;E&&E!==z;)R=g(E),n(E,p,H),E=R;n(z,p,H)},A=({el:E,anchor:z})=>{let p;for(;E&&E!==z;)p=g(E),o(E),E=p;o(z)},T=(E,z,p,H,R,_,C,L,G)=>{if(z.type==="svg"?C="svg":z.type==="math"&&(C="mathml"),E==null)I(z,p,H,R,_,C,L,G);else{const K=E.el&&E.el._isVueCE?E.el:null;try{K&&K._beginPatch(),F(E,z,R,_,C,L,G)}finally{K&&K._endPatch()}}},I=(E,z,p,H,R,_,C,L)=>{let G,K;const{props:q,shapeFlag:et,transition:ct,dirs:at}=E;if(G=E.el=l(E.type,_,q&&q.is,q),et&8?u(G,E.children):et&16&&N(E.children,G,null,H,R,Uo(E,_),C,L),at&&xi(E,null,H,"created"),w(G,E,E.scopeId,C,H),q){for(const wt in q)wt!=="value"&&!pn(wt)&&s(G,wt,null,q[wt],_,H);"value"in q&&s(G,"value",null,q.value,_),(K=q.onVnodeBeforeMount)&&Ne(K,H,E)}at&&xi(E,null,H,"beforeMount");const pt=Wd(R,ct);pt&&ct.beforeEnter(G),n(G,z,p),((K=q&&q.onVnodeMounted)||pt||at)&&we(()=>{try{K&&Ne(K,H,E),pt&&ct.enter(G),at&&xi(E,null,H,"mounted")}finally{}},R)},w=(E,z,p,H,R)=>{if(p&&d(E,p),H)for(let _=0;_<H.length;_++)d(E,H[_]);if(R){let _=R.subTree;if(z===_||jl(_.type)&&(_.ssContent===z||_.ssFallback===z)){const C=R.vnode;w(E,C,C.scopeId,C.slotScopeIds,R.parent)}}},N=(E,z,p,H,R,_,C,L,G=0)=>{for(let K=G;K<E.length;K++){const q=E[K]=L?Xe(E[K]):je(E[K]);f(null,q,z,p,H,R,_,C,L)}},F=(E,z,p,H,R,_,C)=>{const L=z.el=E.el;let{patchFlag:G,dynamicChildren:K,dirs:q}=z;G|=E.patchFlag&16;const et=E.props||Wt,ct=z.props||Wt;let at;if(p&&Si(p,!1),(at=ct.onVnodeBeforeUpdate)&&Ne(at,p,z,E),q&&xi(z,E,p,"beforeUpdate"),p&&Si(p,!0),K&&(!E.dynamicChildren||E.dynamicChildren.length!==K.length)&&(G=0,C=!1,K=null),(et.innerHTML&&ct.innerHTML==null||et.textContent&&ct.textContent==null)&&u(L,""),K?j(E.dynamicChildren,K,L,p,H,Uo(z,R),_):C||U(E,z,L,null,p,H,Uo(z,R),_,!1),G>0){if(G&16)J(L,et,ct,p,R);else if(G&2&&et.class!==ct.class&&s(L,"class",null,ct.class,R),G&4&&s(L,"style",et.style,ct.style,R),G&8){const pt=z.dynamicProps;for(let wt=0;wt<pt.length;wt++){const kt=pt[wt],Dt=et[kt],Gt=ct[kt];(Gt!==Dt||kt==="value")&&s(L,kt,Dt,Gt,R,p)}}G&1&&E.children!==z.children&&u(L,z.children)}else!C&&K==null&&J(L,et,ct,p,R);((at=ct.onVnodeUpdated)||q)&&we(()=>{at&&Ne(at,p,z,E),q&&xi(z,E,p,"updated")},H)},j=(E,z,p,H,R,_,C)=>{for(let L=0;L<z.length;L++){const G=E[L],K=z[L],q=G.el&&(G.type===Kt||!an(G,K)||G.shapeFlag&198)?m(G.el):p;f(G,K,q,null,H,R,_,C,!0)}},J=(E,z,p,H,R)=>{if(z!==p){if(z!==Wt)for(const _ in z)!pn(_)&&!(_ in p)&&s(E,_,z[_],null,R,H);for(const _ in p){if(pn(_))continue;const C=p[_],L=z[_];C!==L&&_!=="value"&&s(E,_,L,C,R,H)}"value"in p&&s(E,"value",z.value,p.value,R)}},$=(E,z,p,H,R,_,C,L,G)=>{const K=z.el=E?E.el:r(""),q=z.anchor=E?E.anchor:r("");let{patchFlag:et,dynamicChildren:ct,slotScopeIds:at}=z;at&&(L=L?L.concat(at):at),E==null?(n(K,p,H),n(q,p,H),N(z.children||[],p,q,R,_,C,L,G)):et>0&&et&64&&ct&&E.dynamicChildren&&E.dynamicChildren.length===ct.length?(j(E.dynamicChildren,ct,p,R,_,C,L),(z.key!=null||R&&z===R.subTree)&&Nl(E,z,!0)):U(E,z,p,q,R,_,C,L,G)},O=(E,z,p,H,R,_,C,L,G)=>{z.slotScopeIds=L,E==null?z.shapeFlag&512?R.ctx.activate(z,p,H,C,G):y(z,p,H,R,_,C,G):V(E,z,G)},y=(E,z,p,H,R,_,C)=>{const L=E.component=Xd(E,H,R);if(Sl(E)&&(L.ctx.renderer=gt),tu(L,!1,C),L.asyncDep){if(R&&R.registerDep(L,X,C),!E.el){const G=L.subTree=ut(li);k(null,G,z,p),E.placeholder=G.el}}else X(L,E,z,p,R,_,C)},V=(E,z,p)=>{const H=z.component=E.component;if(Dd(E,z,p))if(H.asyncDep&&!H.asyncResolved){P(H,z,p);return}else H.next=z,H.update();else z.el=E.el,H.vnode=z},X=(E,z,p,H,R,_,C)=>{const L=()=>{if(E.isMounted){let{next:et,bu:ct,u:at,parent:pt,vnode:wt}=E;{const ie=Fl(E);if(ie){et&&(et.el=wt.el,P(E,et,C)),ie.asyncDep.then(()=>{we(()=>{E.isUnmounted||K()},R)});return}}let kt=et,Dt;Si(E,!1),et?(et.el=wt.el,P(E,et,C)):et=wt,ct&&Jn(ct),(Dt=et.props&&et.props.onVnodeBeforeUpdate)&&Ne(Dt,pt,et,wt),Si(E,!0);const Gt=lr(E),Yt=E.subTree;E.subTree=Gt,f(Yt,Gt,m(Yt.el),dt(Yt),E,R,_),et.el=Gt.el,kt===null&&Pd(E,Gt.el),at&&we(at,R),(Dt=et.props&&et.props.onVnodeUpdated)&&we(()=>Ne(Dt,pt,et,wt),R)}else{let et;const{el:ct,props:at}=z,{bm:pt,m:wt,parent:kt,root:Dt,type:Gt}=E,Yt=Zi(z);Si(E,!1),pt&&Jn(pt),!Yt&&(et=at&&at.onVnodeBeforeMount)&&Ne(et,kt,z),Si(E,!0);{Dt.ce&&Dt.ce._hasShadowRoot()&&Dt.ce._injectChildStyle(Gt,E.parent?E.parent.type:void 0);const ie=E.subTree=lr(E);f(null,ie,p,H,E,R,_),z.el=ie.el}if(wt&&we(wt,R),!Yt&&(et=at&&at.onVnodeMounted)){const ie=z;we(()=>Ne(et,kt,ie),R)}(z.shapeFlag&256||kt&&Zi(kt.vnode)&&kt.vnode.shapeFlag&256)&&E.a&&we(E.a,R),E.isMounted=!0,z=p=H=null}};E.scope.on();const G=E.effect=new Xr(L);E.scope.off();const K=E.update=G.run.bind(G),q=E.job=G.runIfDirty.bind(G);q.i=E,q.id=E.uid,G.scheduler=()=>Is(q),Si(E,!0),K()},P=(E,z,p)=>{z.component=E;const H=E.vnode.props;E.vnode=z,E.next=null,Rd(E,z.props,H,p),Hd(E,z.children,p),oi(),Qs(E),si()},U=(E,z,p,H,R,_,C,L,G=!1)=>{const K=E&&E.children,q=E?E.shapeFlag:0,et=z.children,{patchFlag:ct,shapeFlag:at}=z;if(ct>0){if(ct&128){tt(K,et,p,H,R,_,C,L,G);return}else if(ct&256){W(K,et,p,H,R,_,C,L,G);return}}at&8?(q&16&&D(K,R,_),et!==K&&u(p,et)):q&16?at&16?tt(K,et,p,H,R,_,C,L,G):D(K,R,_,!0):(q&8&&u(p,""),at&16&&N(et,p,H,R,_,C,L,G))},W=(E,z,p,H,R,_,C,L,G)=>{E=E||qi,z=z||qi;const K=E.length,q=z.length,et=Math.min(K,q);let ct;for(ct=0;ct<et;ct++){const at=z[ct]=G?Xe(z[ct]):je(z[ct]);f(E[ct],at,p,null,R,_,C,L,G)}K>q?D(E,R,_,!0,!1,et):N(z,p,H,R,_,C,L,G,et)},tt=(E,z,p,H,R,_,C,L,G)=>{let K=0;const q=z.length;let et=E.length-1,ct=q-1;for(;K<=et&&K<=ct;){const at=E[K],pt=z[K]=G?Xe(z[K]):je(z[K]);if(an(at,pt))f(at,pt,p,null,R,_,C,L,G);else break;K++}for(;K<=et&&K<=ct;){const at=E[et],pt=z[ct]=G?Xe(z[ct]):je(z[ct]);if(an(at,pt))f(at,pt,p,null,R,_,C,L,G);else break;et--,ct--}if(K>et){if(K<=ct){const at=ct+1,pt=at<q?z[at].el:H;for(;K<=ct;)f(null,z[K]=G?Xe(z[K]):je(z[K]),p,pt,R,_,C,L,G),K++}}else if(K>ct)for(;K<=et;)M(E[K],R,_,!0),K++;else{const at=K,pt=K,wt=new Map;for(K=pt;K<=ct;K++){const se=z[K]=G?Xe(z[K]):je(z[K]);se.key!=null&&wt.set(se.key,K)}let kt,Dt=0;const Gt=ct-pt+1;let Yt=!1,ie=0;const Nt=new Array(Gt);for(K=0;K<Gt;K++)Nt[K]=0;for(K=at;K<=et;K++){const se=E[K];if(Dt>=Gt){M(se,R,_,!0);continue}let Xt;if(se.key!=null)Xt=wt.get(se.key);else for(kt=pt;kt<=ct;kt++)if(Nt[kt-pt]===0&&an(se,z[kt])){Xt=kt;break}Xt===void 0?M(se,R,_,!0):(Nt[Xt-pt]=K+1,Xt>=ie?ie=Xt:Yt=!0,f(se,z[Xt],p,null,R,_,C,L,G),Dt++)}const Ge=Yt?Vd(Nt):qi;for(kt=Ge.length-1,K=Gt-1;K>=0;K--){const se=pt+K,Xt=z[se],ki=z[se+1],zi=se+1<q?ki.el||Hl(ki):H;Nt[K]===0?f(null,Xt,p,zi,R,_,C,L,G):Yt&&(kt<0||K!==Ge[kt]?B(Xt,p,zi,2):kt--)}}},B=(E,z,p,H,R=null)=>{const{el:_,type:C,transition:L,children:G,shapeFlag:K}=E;if(K&6){B(E.component.subTree,z,p,H);return}if(K&128){E.suspense.move(z,p,H);return}if(K&64){C.move(E,z,p,gt);return}if(C===Kt){n(_,z,p);for(let et=0;et<G.length;et++)B(G[et],z,p,H);n(E.anchor,z,p);return}if(C===Xn){x(E,z,p);return}if(H!==2&&K&1&&L)if(H===0)L.persisted&&!_[Ho]?n(_,z,p):(L.beforeEnter(_),n(_,z,p),we(()=>L.enter(_),R));else{const{leave:et,delayLeave:ct,afterLeave:at}=L,pt=()=>{E.ctx.isUnmounted?o(_):n(_,z,p)},wt=()=>{const kt=_._isLeaving||!!_[Ho];_._isLeaving&&_[Ho](!0),L.persisted&&!kt?pt():et(_,()=>{pt(),at&&at()})};ct?ct(_,pt,wt):wt()}else n(_,z,p)},M=(E,z,p,H=!1,R=!1)=>{const{type:_,props:C,ref:L,children:G,dynamicChildren:K,shapeFlag:q,patchFlag:et,dirs:ct,cacheIndex:at,memo:pt}=E;if(et===-2&&(R=!1),L!=null&&(oi(),gn(L,null,p,E,!0),si()),at!=null&&(z.renderCache[at]=void 0),q&256){z.ctx.deactivate(E);return}const wt=q&1&&ct,kt=!Zi(E);let Dt;if(kt&&(Dt=C&&C.onVnodeBeforeUnmount)&&Ne(Dt,z,E),q&6)Q(E.component,p,H);else{if(q&128){E.suspense.unmount(p,H);return}wt&&xi(E,null,z,"beforeUnmount"),q&64?E.type.remove(E,z,p,gt,H):K&&!K.hasOnce&&(_!==Kt||et>0&&et&64)?D(K,z,p,!1,!0):(_===Kt&&et&384||!R&&q&16)&&D(G,z,p),H&&Y(E)}const Gt=pt!=null&&at==null;(kt&&(Dt=C&&C.onVnodeUnmounted)||wt||Gt)&&we(()=>{Dt&&Ne(Dt,z,E),wt&&xi(E,null,z,"unmounted"),Gt&&(E.el=null)},p)},Y=E=>{const{type:z,el:p,anchor:H,transition:R}=E;if(z===Kt){Z(p,H);return}if(z===Xn){A(E);return}const _=()=>{o(p),R&&!R.persisted&&R.afterLeave&&R.afterLeave()};if(E.shapeFlag&1&&R&&!R.persisted){const{leave:C,delayLeave:L}=R,G=()=>C(p,_);L?L(E.el,_,G):G()}else _()},Z=(E,z)=>{let p;for(;E!==z;)p=g(E),o(E),E=p;o(z)},Q=(E,z,p)=>{const{bum:H,scope:R,job:_,subTree:C,um:L,m:G,a:K}=E;dr(G),dr(K),H&&Jn(H),R.stop(),_&&(_.flags|=8,M(C,E,z,p)),L&&we(L,z),we(()=>{E.isUnmounted=!0},z)},D=(E,z,p,H=!1,R=!1,_=0)=>{for(let C=_;C<E.length;C++)M(E[C],z,p,H,R)},dt=E=>{if(E.shapeFlag&6)return dt(E.component.subTree);if(E.shapeFlag&128)return E.suspense.next();const z=g(E.anchor||E.el),p=z&&z[sd];return p?g(p):z};let lt=!1;const rt=(E,z,p)=>{let H;E==null?z._vnode&&(M(z._vnode,null,null,!0),H=z._vnode.component):f(z._vnode||null,E,z,null,null,null,p),z._vnode=E,lt||(lt=!0,Qs(H),gl(),lt=!1)},gt={p:f,um:M,m:B,r:Y,mt:y,mc:N,pc:U,pbc:j,n:dt,o:t};return{render:rt,hydrate:void 0,createApp:Ad(rt)}}function Uo({type:t,props:i},e){return e==="svg"&&t==="foreignObject"||e==="mathml"&&t==="annotation-xml"&&i&&i.encoding&&i.encoding.includes("html")?void 0:e}function Si({effect:t,job:i},e){e?(t.flags|=32,i.flags|=4):(t.flags&=-33,i.flags&=-5)}function Wd(t,i){return(!t||t&&!t.pendingBranch)&&i&&!i.persisted}function Nl(t,i,e=!1){const n=t.children,o=i.children;if($t(n)&&$t(o))for(let s=0;s<n.length;s++){const l=n[s];let r=o[s];r.shapeFlag&1&&!r.dynamicChildren&&((r.patchFlag<=0||r.patchFlag===32)&&(r=o[s]=Xe(o[s]),r.el=l.el),!e&&r.patchFlag!==-2&&Nl(l,r)),r.type===To&&(r.patchFlag===-1&&(r=o[s]=Xe(r)),r.el=l.el),r.type===li&&!r.el&&(r.el=l.el)}}function Vd(t){const i=t.slice(),e=[0];let n,o,s,l,r;const a=t.length;for(n=0;n<a;n++){const c=t[n];if(c!==0){if(o=e[e.length-1],t[o]<c){i[n]=o,e.push(n);continue}for(s=0,l=e.length-1;s<l;)r=s+l>>1,t[e[r]]<c?s=r+1:l=r;c<t[e[s]]&&(s>0&&(i[n]=e[s-1]),e[s]=n)}}for(s=e.length,l=e[s-1];s-- >0;)e[s]=l,l=i[l];return e}function Fl(t){const i=t.subTree.component;if(i)return i.asyncDep&&!i.asyncResolved?i:Fl(i)}function dr(t){if(t)for(let i=0;i<t.length;i++)t[i].flags|=8}function Hl(t){if(t.placeholder)return t.placeholder;const i=t.component;return i?Hl(i.subTree):null}const jl=t=>t.__isSuspense;function qd(t,i){i&&i.pendingBranch?$t(t)?i.effects.push(...t):i.effects.push(t):td(t)}const Kt=Symbol.for("v-fgt"),To=Symbol.for("v-txt"),li=Symbol.for("v-cmt"),Xn=Symbol.for("v-stc"),ii=[];let Ce=null;function ot(t=!1){ii.push(Ce=t?null:[])}function Ls(){ii.pop(),Ce=ii[ii.length-1]||null}let En=1;function ur(t,i=!1){En+=t,t<0&&Ce&&i&&(Ce.hasOnce=!0)}function Ul(t){return t.dynamicChildren=En>0?Ce||qi:null,Ls(),En>0&&Ce&&Ce.push(t),t}function st(t,i,e,n,o,s){return Ul(h(t,i,e,n,o,s,!0))}function Le(t,i,e,n,o){return Ul(ut(t,i,e,n,o,!0))}function Ds(t){return t?t.__v_isVNode===!0:!1}function an(t,i){return t.type===i.type&&t.key===i.key}const Wl=({key:t})=>t??null,Qn=({ref:t,ref_key:i,ref_for:e})=>(typeof t=="number"&&(t=""+t),t!=null?ee(t)||Jt(t)||Bt(t)?{i:de,r:t,k:i,f:!!e}:t:null);function h(t,i=null,e=null,n=0,o=null,s=t===Kt?0:1,l=!1,r=!1){const a={__v_isVNode:!0,__v_skip:!0,type:t,props:i,key:i&&Wl(i),ref:i&&Qn(i),scopeId:bl,slotScopeIds:null,children:e,component:null,suspense:null,ssContent:null,ssFallback:null,dirs:null,transition:null,el:null,anchor:null,target:null,targetStart:null,targetAnchor:null,staticCount:0,shapeFlag:s,patchFlag:n,dynamicProps:o,dynamicChildren:null,appContext:null,ctx:de};return r?(ho(a,e),s&128&&t.normalize(a)):e&&(a.shapeFlag|=ee(e)?8:16),En>0&&!l&&Ce&&(a.patchFlag>0||s&6)&&a.patchFlag!==32&&Ce.push(a),a}const ut=Kd;function Kd(t,i=null,e=null,n=0,o=null,s=!1){if((!t||t===yd)&&(t=li),Ds(t)){const r=Xi(t,i,!0);return e&&ho(r,e),En>0&&!s&&Ce&&(r.shapeFlag&6?Ce[Ce.indexOf(t)]=r:Ce.push(r)),r.patchFlag=-2,r}if(su(t)&&(t=t.__vccOpts),i){i=Gd(i);let{class:r,style:a}=i;r&&!ee(r)&&(i.class=At(r)),Ht(a)&&($s(a)&&!$t(a)&&(a=ue({},a)),i.style=In(a))}const l=ee(t)?1:jl(t)?128:rd(t)?64:Ht(t)?4:Bt(t)?2:0;return h(t,i,e,n,o,l,s,!0)}function Gd(t){return t?$s(t)||Ll(t)?ue({},t):t:null}function Xi(t,i,e=!1,n=!1){const{props:o,ref:s,patchFlag:l,children:r,transition:a}=t,c=i?Zd(o||{},i):o,u={__v_isVNode:!0,__v_skip:!0,type:t.type,props:c,key:c&&Wl(c),ref:i&&i.ref?e&&s?$t(s)?s.concat(Qn(i)):[s,Qn(i)]:Qn(i):s,scopeId:t.scopeId,slotScopeIds:t.slotScopeIds,children:r,target:t.target,targetStart:t.targetStart,targetAnchor:t.targetAnchor,staticCount:t.staticCount,shapeFlag:t.shapeFlag,patchFlag:i&&t.type!==Kt?l===-1?16:l|16:l,dynamicProps:t.dynamicProps,dynamicChildren:t.dynamicChildren,appContext:t.appContext,dirs:t.dirs,transition:a,component:t.component,suspense:t.suspense,ssContent:t.ssContent&&Xi(t.ssContent),ssFallback:t.ssFallback&&Xi(t.ssFallback),placeholder:t.placeholder,el:t.el,anchor:t.anchor,ctx:t.ctx,ce:t.ce};return a&&n&&As(u,a.clone(u)),u}function Ae(t=" ",i=0){return ut(To,null,t,i)}function ge(t,i){const e=ut(Xn,null,t);return e.staticCount=i,e}function Ot(t="",i=!1){return i?(ot(),Le(li,null,t)):ut(li,null,t)}function je(t){return t==null||typeof t=="boolean"?ut(li):$t(t)?ut(Kt,null,t.slice()):Ds(t)?Xe(t):ut(To,null,String(t))}function Xe(t){return t.el===null&&t.patchFlag!==-1||t.memo?t:Xi(t)}function ho(t,i){let e=0;const{shapeFlag:n}=t;if(i==null)i=null;else if($t(i))e=16;else if(typeof i=="object")if(n&65){const o=i.default;o&&(o._c&&(o._d=!1),ho(t,o()),o._c&&(o._d=!0));return}else{e=32;const o=i._;!o&&!Ll(i)?i._ctx=de:o===3&&de&&(de.slots._===1?i._=1:(i._=2,t.patchFlag|=1024))}else if(Bt(i)){if(n&65){ho(t,{default:i});return}i={default:i,_ctx:de},e=32}else i=String(i),n&64?(e=16,i=[Ae(i)]):e=8;t.children=i,t.shapeFlag|=e}function Zd(...t){const i={};for(let e=0;e<t.length;e++){const n=t[e];for(const o in n)if(o==="class")i.class!==n.class&&(i.class=At([i.class,n.class]));else if(o==="style")i.style=In([i.style,n.style]);else if(yo(o)){const s=i[o],l=n[o];l&&s!==l&&!($t(s)&&s.includes(l))?i[o]=s?[].concat(s,l):l:l==null&&s==null&&!ko(o)&&(i[o]=l)}else o!==""&&(i[o]=n[o])}return i}function Ne(t,i,e,n=null){Re(t,i,7,[e,n])}const Yd=Al();let Jd=0;function Xd(t,i,e){const n=t.type,o=(i?i.appContext:t.appContext)||Yd,s={uid:Jd++,vnode:t,type:n,parent:i,appContext:o,root:null,next:null,subTree:null,effect:null,update:null,job:null,scope:new _c(!0),render:null,proxy:null,exposed:null,exposeProxy:null,withProxy:null,provides:i?i.provides:Object.create(o.provides),ids:i?i.ids:["",0,0],accessCache:null,renderCache:[],components:null,directives:null,propsOptions:Pl(n,o),emitsOptions:Bl(n,o),emit:null,emitted:null,propsDefaults:Wt,inheritAttrs:n.inheritAttrs,ctx:Wt,data:Wt,props:Wt,attrs:Wt,slots:Wt,refs:Wt,setupState:Wt,setupContext:null,suspense:e,suspenseId:e?e.pendingId:0,asyncDep:null,asyncResolved:!1,isMounted:!1,isUnmounted:!1,isDeactivated:!1,bc:null,c:null,bm:null,m:null,bu:null,u:null,um:null,bum:null,da:null,a:null,rtg:null,rtc:null,ec:null,sp:null};return s.ctx={_:s},s.root=i?i.root:s,s.emit=Td.bind(null,s),t.ce&&t.ce(s),s}let me=null;const Qd=()=>me||de;let mo,ds;{const t=_o(),i=(e,n)=>{let o;return(o=t[e])||(o=t[e]=[]),o.push(n),s=>{o.length>1?o.forEach(l=>l(s)):o[0](s)}};mo=i("__VUE_INSTANCE_SETTERS__",e=>me=e),ds=i("__VUE_SSR_SETTERS__",e=>Mn=e)}const zn=t=>{const i=me;return mo(t),t.scope.on(),()=>{t.scope.off(),mo(i)}},fr=()=>{me&&me.scope.off(),mo(null)};function Vl(t){return t.vnode.shapeFlag&4}let Mn=!1;function tu(t,i=!1,e=!1){i&&ds(i);const{props:n,children:o}=t.vnode,s=Vl(t);Od(t,n,s,i),Fd(t,o,e||i);const l=s?eu(t,i):void 0;return i&&ds(!1),l}function eu(t,i){const e=t.type;t.accessCache=Object.create(null),t.proxy=new Proxy(t.ctx,wd);const{setup:n}=e;if(n){oi();const o=t.setupContext=n.length>1?nu(t):null,s=zn(t),l=On(n,t,0,[t.props,o]),r=Vr(l);if(si(),s(),(r||t.sp)&&!Zi(t)&&xl(t),r){if(l.then(fr,fr),i)return l.then(a=>{pr(t,a)}).catch(a=>{Io(a,t,0)});t.asyncDep=l}else pr(t,l)}else ql(t)}function pr(t,i,e){Bt(i)?t.type.__ssrInlineRender?t.ssrRender=i:t.render=i:Ht(i)&&(t.setupState=fl(i)),ql(t)}function ql(t,i,e){const n=t.type;t.render||(t.render=n.render||qe);{const o=zn(t);oi();try{xd(t)}finally{si(),o()}}}const iu={get(t,i){return he(t,"get",""),t[i]}};function nu(t){const i=e=>{t.exposed=e||{}};return{attrs:new Proxy(t.attrs,iu),slots:t.slots,emit:t.emit,expose:i}}function Eo(t){return t.exposed?t.exposeProxy||(t.exposeProxy=new Proxy(fl(Wc(t.exposed)),{get(i,e){if(e in i)return i[e];if(e in vn)return vn[e](t)},has(i,e){return e in i||e in vn}})):t.proxy}function ou(t,i=!0){return Bt(t)?t.displayName||t.name:t.name||i&&t.__name}function su(t){return Bt(t)&&"__vccOpts"in t}const St=(t,i)=>Zc(t,i,Mn),ru="3.5.40";/**
* @vue/runtime-dom v3.5.40
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/let us;const hr=typeof window<"u"&&window.trustedTypes;if(hr)try{us=hr.createPolicy("vue",{createHTML:t=>t})}catch{}const Kl=us?t=>us.createHTML(t):t=>t,lu="http://www.w3.org/2000/svg",au="http://www.w3.org/1998/Math/MathML",Je=typeof document<"u"?document:null,mr=Je&&Je.createElement("template"),cu={insert:(t,i,e)=>{i.insertBefore(t,e||null)},remove:t=>{const i=t.parentNode;i&&i.removeChild(t)},createElement:(t,i,e,n)=>{const o=i==="svg"?Je.createElementNS(lu,t):i==="mathml"?Je.createElementNS(au,t):e?Je.createElement(t,{is:e}):Je.createElement(t);return t==="select"&&n&&n.multiple!=null&&o.setAttribute("multiple",n.multiple),o},createText:t=>Je.createTextNode(t),createComment:t=>Je.createComment(t),setText:(t,i)=>{t.nodeValue=i},setElementText:(t,i)=>{t.textContent=i},parentNode:t=>t.parentNode,nextSibling:t=>t.nextSibling,querySelector:t=>Je.querySelector(t),setScopeId(t,i){t.setAttribute(i,"")},insertStaticContent(t,i,e,n,o,s){const l=e?e.previousSibling:i.lastChild;if(o&&(o===s||o.nextSibling))for(;i.insertBefore(o.cloneNode(!0),e),!(o===s||!(o=o.nextSibling)););else{mr.innerHTML=Kl(n==="svg"?`<svg>${t}</svg>`:n==="mathml"?`<math>${t}</math>`:t);const r=mr.content;if(n==="svg"||n==="mathml"){const a=r.firstChild;for(;a.firstChild;)r.appendChild(a.firstChild);r.removeChild(a)}i.insertBefore(r,e)}return[l?l.nextSibling:i.firstChild,e?e.previousSibling:i.lastChild]}},du=Symbol("_vtc");function uu(t,i,e){const n=t[du];n&&(i=(i?[i,...n]:[...n]).join(" ")),i==null?t.removeAttribute("class"):e?t.setAttribute("class",i):t.className=i}const go=Symbol("_vod"),Gl=Symbol("_vsh"),Zl={name:"show",beforeMount(t,{value:i},{transition:e}){t[go]=t.style.display==="none"?"":t.style.display,e&&i?e.beforeEnter(t):cn(t,i)},mounted(t,{value:i},{transition:e}){e&&i&&e.enter(t)},updated(t,{value:i,oldValue:e},{transition:n}){!i!=!e&&(n?i?(n.beforeEnter(t),cn(t,!0),n.enter(t)):n.leave(t,()=>{cn(t,!1)}):cn(t,i))},beforeUnmount(t,{value:i}){cn(t,i)}};function cn(t,i){t.style.display=i?t[go]:"none",t[Gl]=!i}const fu=Symbol(""),pu=/(?:^|;)\s*display\s*:/;function hu(t,i,e){const n=t.style,o=ee(e);let s=!1;if(e&&!o){if(i)if(ee(i))for(const l of i.split(";")){const r=l.slice(0,l.indexOf(":")).trim();e[r]==null&&un(n,r,"")}else for(const l in i)e[l]==null&&un(n,l,"");for(const l in e){l==="display"&&(s=!0);const r=e[l];r!=null?gu(t,l,!ee(i)&&i?i[l]:void 0,r)||un(n,l,r):un(n,l,"")}}else if(o){if(i!==e){const l=n[fu];l&&(e+=";"+l),n.cssText=e,s=pu.test(e)}}else i&&t.removeAttribute("style");go in t&&(t[go]=s?n.display:"",t[Gl]&&(n.display="none"))}const gr=/\s*!important$/;function un(t,i,e){if($t(e))e.forEach(n=>un(t,i,n));else if(e==null&&(e=""),i.startsWith("--"))t.setProperty(i,e);else{const n=mu(t,i);gr.test(e)?t.setProperty(yi(n),e.replace(gr,""),"important"):t[n]=e}}const vr=["Webkit","Moz","ms"],Wo={};function mu(t,i){const e=Wo[i];if(e)return e;let n=ye(i);if(n!=="filter"&&n in t)return Wo[i]=n;n=xo(n);for(let o=0;o<vr.length;o++){const s=vr[o]+n;if(s in t)return Wo[i]=s}return i}function gu(t,i,e,n){return t.tagName==="TEXTAREA"&&(i==="width"||i==="height")&&ee(n)&&e===n}const br="http://www.w3.org/1999/xlink";function yr(t,i,e,n,o,s=xc(i)){n&&i.startsWith("xlink:")?e==null?t.removeAttributeNS(br,i.slice(6,i.length)):t.setAttributeNS(br,i,e):e==null||s&&!Zr(e)?t.removeAttribute(i):t.setAttribute(i,s?"":Pe(e)?String(e):e)}function kr(t,i,e,n,o){if(i==="innerHTML"||i==="textContent"){e!=null&&(t[i]=i==="innerHTML"?Kl(e):e);return}const s=t.tagName;if(i==="value"&&s!=="PROGRESS"&&!s.includes("-")){const r=s==="OPTION"?t.getAttribute("value")||"":t.value,a=e==null?t.type==="checkbox"?"on":"":String(e);(r!==a||!("_value"in t))&&(t.value=a),e==null&&t.removeAttribute(i),t._value=e;return}let l=!1;if(e===""||e==null){const r=typeof t[i];r==="boolean"?e=Zr(e):e==null&&r==="string"?(e="",l=!0):r==="number"&&(e=0,l=!0)}try{t[i]=e}catch{}l&&t.removeAttribute(o||i)}function hi(t,i,e,n){t.addEventListener(i,e,n)}function vu(t,i,e,n){t.removeEventListener(i,e,n)}const wr=Symbol("_vei");function bu(t,i,e,n,o=null){const s=t[wr]||(t[wr]={}),l=s[i];if(n&&l)l.value=n;else{const[r,a]=wu(i);if(n){const c=s[i]=_u(n,o);hi(t,r,c,a)}else l&&(vu(t,r,l,a),s[i]=void 0)}}const yu=/(Once|Passive|Capture)$/,ku=/^on:?(?:Once|Passive|Capture)$/;function wu(t){let i,e;for(;(e=t.match(yu))&&!ku.test(t);)i||(i={}),t=t.slice(0,t.length-e[1].length),i[e[1].toLowerCase()]=!0;return[t[2]===":"?t.slice(3):yi(t.slice(2)),i]}let Vo=0;const xu=Promise.resolve(),Su=()=>Vo||(xu.then(()=>Vo=0),Vo=Date.now());function _u(t,i){const e=n=>{if(!n._vts)n._vts=Date.now();else if(n._vts<=e.attached)return;const o=e.value;if($t(o)){const s=n.stopImmediatePropagation;n.stopImmediatePropagation=()=>{s.call(n),n._stopped=!0};const l=o.slice(),r=[n];for(let a=0;a<l.length&&!n._stopped;a++){const c=l[a];c&&Re(c,i,5,r)}}else Re(o,i,5,[n])};return e.value=t,e.attached=Su(),e}const xr=t=>t.charCodeAt(0)===111&&t.charCodeAt(1)===110&&t.charCodeAt(2)>96&&t.charCodeAt(2)<123,Cu=(t,i,e,n,o,s)=>{const l=o==="svg";i==="class"?uu(t,n,l):i==="style"?hu(t,e,n):yo(i)?ko(i)||bu(t,i,e,n,s):(i[0]==="."?(i=i.slice(1),!0):i[0]==="^"?(i=i.slice(1),!1):$u(t,i,n,l))?(kr(t,i,n),!t.tagName.includes("-")&&(i==="value"||i==="checked"||i==="selected")&&yr(t,i,n,l,s,i!=="value")):t._isVueCE&&(Iu(t,i)||t._def.__asyncLoader&&(/[A-Z]/.test(i)||!ee(n)))?kr(t,ye(i),n,s,i):(i==="true-value"?t._trueValue=n:i==="false-value"&&(t._falseValue=n),yr(t,i,n,l))};function $u(t,i,e,n){if(n)return!!(i==="innerHTML"||i==="textContent"||i in t&&xr(i)&&Bt(e));if(i==="spellcheck"||i==="draggable"||i==="translate"||i==="autocorrect"||i==="sandbox"&&t.tagName==="IFRAME"||i==="form"||i==="list"&&t.tagName==="INPUT"||i==="type"&&t.tagName==="TEXTAREA")return!1;if(i==="width"||i==="height"){const o=t.tagName;if(o==="IMG"||o==="VIDEO"||o==="CANVAS"||o==="SOURCE")return!1}return xr(i)&&ee(e)?!1:i in t}function Iu(t,i){const e=t._def.props;if(!e)return!1;const n=ye(i);return Array.isArray(e)?e.some(o=>ye(o)===n):Object.keys(e).some(o=>ye(o)===n)}const Qi=t=>{const i=t.props["onUpdate:modelValue"]||!1;return $t(i)?e=>Jn(i,e):i};function Au(t){t.target.composing=!0}function Sr(t){const i=t.target;i.composing&&(i.composing=!1,i.dispatchEvent(new Event("input")))}const ni=Symbol("_assign");function _r(t,i,e){return i&&(t=t.trim()),e&&(t=So(t)),t}const vo={created(t,{modifiers:{lazy:i,trim:e,number:n}},o){t[ni]=Qi(o);const s=n||o.props&&o.props.type==="number";hi(t,i?"change":"input",l=>{l.target.composing||t[ni](_r(t.value,e,s))}),(e||s)&&hi(t,"change",()=>{t.value=_r(t.value,e,s)}),i||(hi(t,"compositionstart",Au),hi(t,"compositionend",Sr),hi(t,"change",Sr))},mounted(t,{value:i}){t.value=i??""},beforeUpdate(t,{value:i,oldValue:e,modifiers:{lazy:n,trim:o,number:s}},l){if(t[ni]=Qi(l),t.composing)return;const r=(s||t.type==="number")&&!/^0\d/.test(t.value)?So(t.value):t.value,a=i??"";if(r===a)return;const c=t.getRootNode();(c instanceof Document||c instanceof ShadowRoot)&&c.activeElement===t&&t.type!=="range"&&(n&&i===e||o&&t.value.trim()===a)||(t.value=a)}},Kn={deep:!0,created(t,i,e){t[ni]=Qi(e),hi(t,"change",()=>{const n=t._modelValue,o=Ln(t),s=t.checked,l=t[ni];if($t(n)){const r=ys(n,o),a=r!==-1;if(s&&!a)l(n.concat(o));else if(!s&&a){const c=[...n];c.splice(r,1),l(c)}}else if(en(n)){const r=new Set(n);s?r.add(o):r.delete(o),l(r)}else l(Yl(t,s))})},mounted:Cr,beforeUpdate(t,i,e){t[ni]=Qi(e),Cr(t,i,e)}};function Cr(t,{value:i,oldValue:e},n){t._modelValue=i;let o;if($t(i))o=ys(i,n.props.value)>-1;else if(en(i))o=i.has(n.props.value);else{if(i===e)return;o=nn(i,Yl(t,!0))}t.checked!==o&&(t.checked=o)}const Bu={deep:!0,created(t,{value:i,modifiers:{number:e}},n){t._modelValue=i,hi(t,"change",()=>{const o=Array.prototype.filter.call(t.options,s=>s.selected).map(s=>e?So(Ln(s)):Ln(s));t[ni](t.multiple?en(t._modelValue)?new Set(o):o:o[0]),t._assigning=!0,hl(()=>{t._assigning=!1})}),t[ni]=Qi(n)},mounted(t,{value:i}){$r(t,i)},beforeUpdate(t,{value:i},e){t._modelValue=i,t[ni]=Qi(e)},updated(t,{value:i}){t._assigning||$r(t,i)}};function $r(t,i){const e=t.multiple,n=$t(i);if(!(e&&!n&&!en(i))){for(let o=0,s=t.options.length;o<s;o++){const l=t.options[o],r=Ln(l);if(e)if(n){const a=typeof r;a==="string"||a==="number"?l.selected=i.some(c=>String(c)===String(r)):l.selected=ys(i,r)>-1}else l.selected=i.has(r);else if(nn(Ln(l),i)){t.selectedIndex!==o&&(t.selectedIndex=o);return}}!e&&t.selectedIndex!==-1&&(t.selectedIndex=-1)}}function Ln(t){return"_value"in t?t._value:t.value}function Yl(t,i){const e=i?"_trueValue":"_falseValue";return e in t?t[e]:i}const Tu=["ctrl","shift","alt","meta"],Eu={stop:t=>t.stopPropagation(),prevent:t=>t.preventDefault(),self:t=>t.target!==t.currentTarget,ctrl:t=>!t.ctrlKey,shift:t=>!t.shiftKey,alt:t=>!t.altKey,meta:t=>!t.metaKey,left:t=>"button"in t&&t.button!==0,middle:t=>"button"in t&&t.button!==1,right:t=>"button"in t&&t.button!==2,exact:(t,i)=>Tu.some(e=>t[`${e}Key`]&&!i.includes(e))},Me=(t,i)=>{if(!t)return t;const e=t._withMods||(t._withMods={}),n=i.join(".");return e[n]||(e[n]=((o,...s)=>{for(let l=0;l<i.length;l++){const r=Eu[i[l]];if(r&&r(o,i))return}return t(o,...s)}))},Mu={esc:"escape",space:" ",up:"arrow-up",left:"arrow-left",right:"arrow-right",down:"arrow-down",delete:"backspace"},Lu=(t,i)=>{const e=t._withKeys||(t._withKeys={}),n=i.join(".");return e[n]||(e[n]=(o=>{if(!("key"in o))return;const s=yi(o.key);if(i.some(l=>l===s||Mu[l]===s))return t(o)}))},Du=ue({patchProp:Cu},cu);let Ir;function Pu(){return Ir||(Ir=jd(Du))}const Jl=((...t)=>{const i=Pu().createApp(...t),{mount:e}=i;return i.mount=n=>{const o=Ru(n);if(!o)return;const s=i._component;!Bt(s)&&!s.render&&!s.template&&(s.template=o.innerHTML),o.nodeType===1&&(o.textContent="");const l=e(o,!1,Ou(o));return o instanceof Element&&(o.removeAttribute("v-cloak"),o.setAttribute("data-v-app","")),l},i});function Ou(t){if(t instanceof SVGElement)return"svg";if(typeof MathMLElement=="function"&&t instanceof MathMLElement)return"mathml"}function Ru(t){return ee(t)?document.querySelector(t):t}const zu="slidev-config.json",tn={enableWebServeJump:!1,webServeUrl:"http://127.0.0.1:6806",normalizeHeadingSizes:!1},mi=$o({...tn});function Nu(t){if(!t||typeof t!="object")return{...tn};const i=t;return{enableWebServeJump:!!i.enableWebServeJump,webServeUrl:typeof i.webServeUrl=="string"&&i.webServeUrl.trim()?i.webServeUrl.trim():tn.webServeUrl,normalizeHeadingSizes:!!i.normalizeHeadingSizes}}function Ei(t){if(!t||typeof t!="object")return{...mi};const i=t;return i.enableWebServeJump!==void 0&&(mi.enableWebServeJump=!!i.enableWebServeJump),i.webServeUrl!==void 0&&(mi.webServeUrl=String(i.webServeUrl)),i.normalizeHeadingSizes!==void 0&&(mi.normalizeHeadingSizes=!!i.normalizeHeadingSizes),{...mi}}function Mo(){return{...mi}}function Xl(t,i,e){const n=(t||tn.webServeUrl).trim(),o=n.startsWith("http://")||n.startsWith("https://")?n:`http://${n}`,s=(e==null?void 0:e.r)||Math.random().toString(36).slice(2,9).padEnd(7,"0");try{const l=new URL(o);let r=l.pathname.replace(/\/+$/,"");return r.endsWith("/stage/build/desktop")||(r=r?`${r}/stage/build/desktop`:"/stage/build/desktop"),l.pathname=`${r}/`,l.searchParams.set("id",i),e!=null&&e.focus&&l.searchParams.set("focus","1"),l.searchParams.set("r",s),l.toString()}catch{const l=e!=null&&e.focus?"&focus=1":"";return`${o.replace(/\/+$/,"")}/stage/build/desktop/?id=${i}${l}&r=${s}`}}const _i={theme:"default",aspectRatio:"16/9",highlighter:"shiki",defaultTransition:"slide-left",colorSchema:"auto",spacing:"normal",normalizeHeadingSizes:!1};function Fu(t){var e,n,o,s,l,r;const i=Mo();return t?{theme:((e=t[xn])==null?void 0:e.trim())||_i.theme,aspectRatio:((n=t[Sn])==null?void 0:n.trim())||_i.aspectRatio,highlighter:((o=t[Hr])==null?void 0:o.trim())||_i.highlighter,defaultTransition:((s=t[_n])==null?void 0:s.trim())||_i.defaultTransition,colorSchema:((l=t[jr])==null?void 0:l.trim())||_i.colorSchema,spacing:((r=t[ts])==null?void 0:r.trim())||_i.spacing,normalizeHeadingSizes:i.normalizeHeadingSizes}:{..._i,normalizeHeadingSizes:i.normalizeHeadingSizes}}function bo(t){var e,n,o,s,l;const i=(e=t.ial)==null?void 0:e[Bi];return!!(i&&(i==="true"||i==="page"||i==="cover"||i==="end")||t.type==="tb"||t.type==="thematic-break"||t.type==="NodeThematicBreak"||((n=t.markdown)==null?void 0:n.trim())==="---"||((o=t.markdown)==null?void 0:o.trim())==="***"||t.type==="b"&&(((s=t.markdown)==null?void 0:s.trim())==="---"||((l=t.content)==null?void 0:l.trim())==="---"))}function Ar(t){const i={};let e="";if(!t)return{frontmatter:i,notes:e};t[mt]&&(i.layout=t[mt].trim()),t[te]&&(i.transition=t[te].trim()),t[Ut]&&(i.background=t[Ut].trim()),t[Ee]&&(i.image=t[Ee].trim()),t[Vi]&&(i.class=t[Vi].trim()),t[fn]&&(i.spacing=t[fn].trim()),t[le]&&(i.layoutRatio=t[le].trim()),t[Wi]&&(e=t[Wi].trim());for(const[n,o]of Object.entries(t))if(n.startsWith("custom-slidev-")&&![mt,le,te,Ut,Ee,Vi,fn,Wi,Bi].includes(n)){const s=n.replace(/^custom-slidev-/,"");try{i[s]=JSON.parse(o)}catch{i[s]=o}}return{frontmatter:i,notes:e}}function Hu(t){const i={};if(!t)return i;const e=t[ne]??t["slidev-note"];e!=null&&e!==""&&e!=="false"&&e!=="0"&&(i.isNote=!0);const n=t[qt]??t["slidev-role"],o=t[Ut]??t["slidev-background"];(n===Ur||o==="true"||o==="1")&&(i.isBackground=!0);const s=t[mt]??t["slidev-layout"];s===ro||s===lo?i.imageLayout=s:(n===ro||n===lo)&&(i.imageLayout=n);const l=t[jt]??t["custom-slidev-clicks"]??t["slidev-click"]??t["slidev-clicks"];if(l!=null&&(i.clicks=l.trim()),t[Ve])try{const r=JSON.parse(t[Ve]);typeof r=="object"&&r!==null?i.motion={preset:r.preset||r.type||"fade-in",...r}:i.motion={preset:String(r).trim()}}catch{i.motion={preset:t[Ve].trim()}}return t[Oi]&&(i.shikiLines=t[Oi].trim()),t[Cn]&&(i.maxHeight=t[Cn].trim()),t[Ct]&&(i.slot=t[Ct].trim()),t.style&&t.style.trim()&&(i.style=t.style.trim()),i}function bi(t,i){const e=(t||i||"").trim();if(!e)return null;const n=e.match(/!\[[\s\S]*?\]\(\s*([^\s)]+)(?:\s+(?:=["']?[^"'\s)]*["']?|["'][^"']*["']))*?\s*\)/);if(n)return n[1].trim();const o=e.match(/<img\b[^>]*?\bsrc=["']([^"']+)["']/i);if(o)return o[1].trim();const s=e.replace(/\{:[^}]*\}/g,"").trim();return/^(?:assets\/|https?:\/\/|\/|\.\.?\/)[^\s]+\.(?:png|jpe?g|gif|webp|svg|avif)(?:\?[^\s]*)?$/i.test(s)?s:null}function bn(t){if(!t)return"";const i=t.split(/\r?\n/);if(i.length===0)return"";const e=i[0],n=e.match(/^(\s*)(?:[-*+]|\d+\.)\s+(.*)$/);if(!n)return t;const o=n[1].length,s=n[2].trim(),l=e.length-n[2].length;if(i.length===1)return s;const r=[s];for(let a=1;a<i.length;a++){const c=i[a];if(!c.trim()){r.push("");continue}const u=c.match(/^(\s*)/),m=u?u[1].length:0;m>=l?r.push(c.slice(l)):m>o?r.push(c.slice(m)):r.push(c)}return r.join(`
`)}function Ri(t){if(!t)return!1;const i=(t.type||"").toLowerCase();if(i==="i"||i==="nodelistitem"||i==="l"||i==="nodelist")return!0;const e=(t.markdown||t.rawMarkdown||t.content||"").trim();return!!/^(?:[-*+]|\d+\.)\s+/.test(e)}function qo(t,i=2){if(!t||typeof t!="string")return`repeat(${i}, 1fr)`;const e=t.trim();if(!e)return`repeat(${i}, 1fr)`;if(e.includes(":")){const o=e.split(":").map(s=>parseFloat(s.trim())).filter(s=>!isNaN(s)&&s>0);if(o.length>=2)return o.map(s=>`${s}fr`).join(" ")}const n=e.split(/\s+/).filter(Boolean);return n.length>=2?n.join(" "):`repeat(${i}, 1fr)`}function yn(t){if(!t)return[];if(oe(t)&&Ke(t)&&!ci(t)){const n=on(t),o=[];for(const s of n)o.push(...yn(s));return o}const i=(t.type||"").toLowerCase();if(i==="l"||i==="nodelist"||i==="list"){if(t.children&&t.children.length>0){const l=t.children.filter(Ri);if(l.length>0)return l}const o=(t.markdown||t.content||"").trim().split(/\r?\n/),s=[];for(let l=0;l<o.length;l++)/^(?:[-*+]|\d+\.)\s+/.test(o[l])&&s.push(l);if(s.length>=2){const l=[];for(let r=0;r<s.length;r++){const a=s[r],c=r+1<s.length?s[r+1]:o.length,u=o.slice(a,c).join(`
`);l.push({id:`${t.id}-item-${r+1}`,type:"i",markdown:u,content:u,ial:{...t.ial||{}}})}return l}}return Ri(t)?[t]:[]}function Ps(t){var o;if(!t||!oe(t)||!Ke(t)||ci(t))return null;const i=on(t);if(i.length===0)return null;if(i.length===1&&oe(i[0])&&Ke(i[0])){const s=Ps(i[0]);return s?{items:s.items,nestedSuperBlocks:[i[0],...s.nestedSuperBlocks]}:null}const e=[];for(const s of i)if(oe(s)){e.push(s);const l=((o=s.children)==null?void 0:o.filter(oe))||[];e.push(...l)}const n=i.map(yn);if(n.length>=2&&n.every(s=>s.length>0)){const s=n.flat();if(s.length>=2&&s.length<=6)return{items:s,nestedSuperBlocks:e}}if(i.length===2){const s=yn(i[0]),l=yn(i[1]);if(s.length+l.length>=2&&s.length+l.length<=6&&(s.length>0||l.length>0))return{items:[...s,...l],nestedSuperBlocks:e}}return null}function ju(t){if(!t||!oe(t)||!Ke(t)||ci(t))return null;const i=Ps(t);if(!i)return null;const{items:e,nestedSuperBlocks:n}=i;if(e.length<2||e.length>6)return null;const o=Os(t)||void 0,s=e.length;return{superBlockNode:t,nestedSuperBlocks:n,count:s,layout:"cols-header",items:e,slots:e.map((l,r)=>`col-${r+1}`),ratio:o}}function Ql(t){if(!t||!oe(t)||!Ke(t)||ci(t))return null;const i=on(t);if(i.length===0)return null;const e=[];for(const n of i){const o=yn(n);if(o.length===0)return null;e.push(...o)}return e}function Uu(t){if(!t||!oe(t)||!Ke(t)||ci(t))return null;const i=Ql(t);return!i||i.length===0||i.length>=2&&i.length<=6?null:{superBlockNode:t,items:i}}function Wu(t){if(!t||!oe(t)||!Ke(t)||ci(t))return null;const i=Ps(t);if(i&&i.items.length===4)return i.items;const e=Ql(t);if(e&&e.length===4)return e;const n=on(t);return n.length===4?n:null}function Vu(t,i){if(!t||t.length===0)return null;const e=[];function n(r,a){if(oe(r)){const c=Wu(r);c&&c.length===4&&e.push({sbNode:r,items:c,topLevelIndex:a})}if(r.children&&r.children.length>0)for(const c of r.children)n(c,a)}for(let r=0;r<t.length;r++)n(t[r],r);if(e.length===0)return null;let o=null;i&&(o=e.find(r=>{if(r.sbNode.id===i||r.items.some(c=>c.id===i))return!0;const a=c=>c.id===i?!0:c.children?c.children.some(a):!1;return a(r.sbNode)})||null),o||(o=e[0]);const l=t.slice(0,o.topLevelIndex).slice().reverse().find(r=>ta(r));return{superBlockNode:o.sbNode,items:o.items,headerNode:l}}function qu(t,i,e){var u,m,g,d,b;const n=[],o=[],s=(e==null?void 0:e.tracked)||[],l=[];let r={pageTargetId:t,blocks:[]};l.push(r);for(let f=0;f<i.length;f++){const v=i[f];if(bo(v)){if(l.length===1&&r.blocks.length===0){r.pageTargetId=v.id,r.blocks.push(v);continue}r={pageTargetId:v.id,blocks:[v]},l.push(r)}else r.blocks.push(v)}function a(f){const v=[];for(const k of f)oe(k)&&v.push(k),k.children&&k.children.length>0&&v.push(...a(k.children));return v}function c(f,v,k){const S={blockId:f,attrs:v,previousAttrs:k};n.push(S),e!=null&&e.onTagChange&&e.onTagChange(S)}for(const f of l){const v=f.pageTargetId,k=i.find(I=>I.id===v),S=s.find(I=>I.pageTargetId===v);if(f.blocks.some(I=>{var w,N;return!!(ci(I)||fs(I)&&(((w=I.ial)==null?void 0:w[mt])==="image-left"||((N=I.ial)==null?void 0:N[mt])==="image-right"))})){if(S){const I=S.headerId;if(I){c(I,{[Ct]:""});const w=i.find(N=>N.id===I);w!=null&&w.ial&&(w.ial[Ct]="")}for(const w of S.itemIds){c(w,{[Ct]:""});const N=i.find(F=>F.id===w);N!=null&&N.ial&&(N.ial[Ct]="")}}continue}let A=null,T=-1;for(let I=0;I<f.blocks.length;I++){const w=f.blocks[I],N=oe(w)?[w,...a(w.children||[])]:w.children?a(w.children):[];for(const F of N){const j=ju(F);if(j){A=j,T=I;break}}if(A)break}if(A){const{superBlockNode:I,layout:w,items:N,slots:F}=A,J=f.blocks.slice(0,T).find(P=>ta(P)),$=J==null?void 0:J.id,O=((u=k==null?void 0:k.ial)==null?void 0:u[mt])||"",y=O==="clover",V=y?"clover":w;if(O!==V&&(c(v,{[mt]:V},{[mt]:O}),k&&(k.ial||(k.ial={}),k.ial[mt]=V)),J){const P=((m=J.ial)==null?void 0:m[Ct])||"";P!=="header"&&(c(J.id,{[Ct]:"header"},{[Ct]:P}),J.ial||(J.ial={}),J.ial[Ct]="header")}if(S!=null&&S.headerId&&S.headerId!==$){c(S.headerId,{[Ct]:""});const P=i.find(U=>U.id===S.headerId);P&&(P.ial||(P.ial={}),P.ial[Ct]="")}const X=[];for(let P=0;P<N.length;P++){const U=N[P],W=F[P];X.push(U.id);const tt=((g=U.ial)==null?void 0:g[Ct])||"";if(tt!==W&&(c(U.id,{[Ct]:W},{[Ct]:tt}),U.ial||(U.ial={}),U.ial[Ct]=W),U.children&&U.children.length>0)for(const B of U.children)B.ial||(B.ial={}),B.ial[Ct]!==W&&(B.ial[Ct]=W)}if(S!=null&&S.itemIds){for(const P of S.itemIds)if(!X.includes(P)){c(P,{[Ct]:""});const U=i.find(W=>W.id===P);U&&(U.ial||(U.ial={}),U.ial[Ct]="")}}o.push({superBlockId:I.id,nestedSuperBlockIds:(d=A.nestedSuperBlocks)==null?void 0:d.map(P=>P.id),pageTargetId:v,headerId:$,itemIds:X,layout:y?"clover":w})}else{let I=!1;const w=[];for(const j of f.blocks){const J=oe(j)?[j,...a(j.children||[])]:j.children?a(j.children):[];for(const $ of J){const O=Uu($);if(O){I=!0;for(const y of O.items)w.push(y.id)}}}const N=((b=k==null?void 0:k.ial)==null?void 0:b[mt])||"",F=$n(N);if(S||I&&F){c(v,{[mt]:""},{[mt]:N}),k&&(k.ial||(k.ial={}),k.ial[mt]="");const j=S==null?void 0:S.headerId;if(j){c(j,{[Ct]:""});const $=i.find(O=>O.id===j);$&&($.ial||($.ial={}),$.ial[Ct]="")}const J=new Set([...(S==null?void 0:S.itemIds)||[],...w]);for(const $ of J){c($,{[Ct]:""});const O=i.find(y=>y.id===$);O&&(O.ial||(O.ial={}),O.ial[Ct]="")}}}}return{changes:n,newTracked:o}}function oe(t){if(!t)return!1;const i=(t.type||"").toLowerCase();return i==="s"||i==="sb"||i==="nodesuperblock"}function Ke(t){if(!oe(t))return!1;const i=(t.subType||"").toLowerCase();if(i==="col"||i==="h"||i==="horizontal")return!0;if(i==="row"||i==="v"||i==="vertical")return!1;if(t.ial){const n=(t.ial["data-sb-layout"]||t.ial.layout||"").toLowerCase();if(n==="col"||n==="h")return!0;if(n==="row"||n==="v")return!1}if(t.children&&t.children.length>0){for(const n of t.children)if(n.type==="NodeSuperBlockLayoutMarker"||n.type==="layout-marker"){const o=(n.content||n.markdown||"").trim().toLowerCase();if(o==="col"||o==="h")return!0;if(o==="row"||o==="v")return!1}}const e=(t.markdown||t.content||"").trim();return/^\{\{\{col\b/i.test(e)?!0:!/^\{\{\{row\b/i.test(e)}function fs(t){return!t||Ri(t)||oe(t)||!bi(t.markdown,t.content)?!1:(t.markdown||t.content||"").replace(/!\[.*?\]\([^)]+\)/g,"").replace(/<img\b[^>]*>/gi,"").replace(/\{:[^}]*\}/g,"").trim().length<=25}function Os(t){var g;if(!t||!oe(t)||!Ke(t))return null;const i=on(t);if(!i||i.length<2)return null;const e=[];let n=!1;for(const d of i){const b=(((g=d.ial)==null?void 0:g.style)||d.style||"").trim();let f=null;if(b){const v=b.match(/calc\(\s*([\d.]+)%/i);if(v)f=parseFloat(v[1]);else{const k=b.match(/(?:^|;|\s)width:\s*([\d.]+)%/i);k&&(f=parseFloat(k[1]))}}f!==null&&!isNaN(f)&&f>0?(e.push(f),n=!0):e.push(null)}if(!n)return null;const o=i.length,s=e.reduce((d,b)=>d+(b||0),0),l=e.filter(d=>d===null).length,r=Math.max(0,100-s),a=l>0?r/l:100/o,c=e.map(d=>d!==null?d:a),u=c.reduce((d,b)=>d+b,0);if(u<=0)return null;const m=c.map(d=>d/u*100);if(m.length===2){const[d]=m;if(d>=48&&d<=52)return"1:1";if(d>=31&&d<=35)return"1:2";if(d>=65&&d<=69)return"2:1";if(d>=28&&d<=32)return"3:7";if(d>=68&&d<=72)return"7:3";if(d>=38&&d<=42)return"4:6";if(d>=58&&d<=62)return"6:4";if(d>=23&&d<=27)return"1:3";if(d>=73&&d<=77)return"3:1";const b=Math.round(d),f=100-b;return`${b}:${f}`}if(m.length===3){const[d,b,f]=m;if(d>=31&&d<=35&&b>=31&&b<=35&&f>=31&&f<=35)return"1:1:1";if(d>=23&&d<=27&&b>=48&&b<=52&&f>=23&&f<=27)return"1:2:1";if(d>=48&&d<=52&&b>=23&&b<=27&&f>=23&&f<=27)return"2:1:1";if(d>=23&&d<=27&&b>=23&&b<=27&&f>=48&&f<=52)return"1:1:2";if(d>=18&&d<=22&&b>=58&&b<=62&&f>=18&&f<=22)return"1:3:1";const v=Math.round(d),k=Math.round(b),S=100-v-k;return`${v}:${k}:${S}`}return m.map(d=>Math.round(d)).join(":")}function ci(t){if(!t||!oe(t)||!Ke(t))return null;const i=(t.children||[]).filter(s=>{const l=s.type||"";if(l==="NodeSuperBlockOpenMarker"||l==="NodeSuperBlockLayoutMarker"||l==="NodeSuperBlockCloseMarker"||l==="open-marker"||l==="layout-marker"||l==="close-marker")return!1;const r=(s.markdown||s.content||"").trim();return!(/^\{\{\{(?:col|row)?\s*$/i.test(r)||r==="}}}")});if(i.length<2)return null;const e=fs(i[0]),n=fs(i[i.length-1]),o=Os(t)||void 0;if(e&&!n){const s=bi(i[0].markdown,i[0].content);if(s)return{imageNode:i[0],imageUrl:s,layout:ro,contentNodes:i.slice(1),ratio:o}}if(!e&&n){const s=bi(i[i.length-1].markdown,i[i.length-1].content);if(s)return{imageNode:i[i.length-1],imageUrl:s,layout:lo,contentNodes:i.slice(0,i.length-1),ratio:o}}return null}function Ku(t,i){const e=[];function n(o){for(const s of o){const l=ci(s);if(l){const{imageNode:r,layout:a,ratio:c}=l;r.ial||(r.ial={});const u=r.ial[mt];if(u!==a){const g={blockId:r.id,layout:a,previousLayout:u,ratio:c};r.ial[mt]=a,e.push(g),i&&i(g)}}s.children&&s.children.length>0&&n(s.children)}}return n(t),e}function on(t){return(t.children||[]).filter(i=>{const e=i.type||"";if(e==="NodeSuperBlockOpenMarker"||e==="NodeSuperBlockLayoutMarker"||e==="NodeSuperBlockCloseMarker"||e==="open-marker"||e==="layout-marker"||e==="close-marker")return!1;const n=(i.markdown||i.content||"").trim();return!(/^\{\{\{(?:col|row)?\s*$/i.test(n)||n==="}}}")})}function ta(t){if(!t)return!1;const i=(t.type||"").toLowerCase();if(i==="h"||i==="nodeheading"||/^h[1-6]$/i.test(t.subType||""))return!0;const e=(t.markdown||t.content||"").trim();return!!/^#{1,6}\s+/.test(e)}function Ci(t,i,e){let n="",o=0;const s=/<div\b([^>]*)>/gi;for(;o<t.length;){s.lastIndex=o;let l,r=!1,a=-1,c=0;for(;(l=s.exec(t))!==null;){const k=l[1].match(/\bclass=["']([^"']*)["']/i);if(k){const S=k[1];if(typeof i=="string"?S.split(/\s+/).includes(i):i.test(S)){r=!0,a=l.index,c=l[0].length;break}}}if(!r){n+=t.slice(o);break}n+=t.slice(o,a);const u=a+c;let m=1,g=-1,d=-1;const b=/<\/?div\b[^>]*>/gi;b.lastIndex=u;let f;for(;(f=b.exec(t))!==null;)if(f[0].startsWith("</")){if(m--,m===0){g=f.index,d=f.index+f[0].length;break}}else m++;if(g!==-1&&d!==-1){const v=t.slice(u,g);n+=e(v),o=d}else n+=t.slice(a,u),o=u}return n}function Gu(t){const i=[];let e="",n=0;const o=/<div\b([^>]*)>/gi;for(;n<t.length;){o.lastIndex=n;let s,l=!1,r=-1,a=0;for(;(s=o.exec(t))!==null;){const f=s[1];if(/(?:\s@[a-zA-Z0-9_-]+=\s*["']|\s:[a-zA-Z0-9_-]+=\s*["']|\sv-[a-zA-Z0-9_.-]+|\shover:[a-zA-Z0-9_.-]+=\s*["']|\sgrid=["']~|\bclass=["'][^"']*\b(?:abs-br|slidev-icon-btn|grid\s+|grid$|grid-cols-|relative\b)\b[^"']*["']|\bstyle=["'][^"']*\bgrid-[^"']*["'])/i.test(f)){l=!0,r=s.index,a=s[0].length;break}}if(!l){e+=t.slice(n);break}e+=t.slice(n,r);const c=r+a;let u=1,m=-1,g=-1;const d=/<\/?div\b[^>]*>/gi;d.lastIndex=c;let b;for(;(b=d.exec(t))!==null;)if(b[0].startsWith("</")){if(u--,u===0){m=b.index,g=b.index+b[0].length;break}}else u++;if(m!==-1&&g!==-1){const f=t.slice(r,g),v=`__VUE_DIV_TOKEN_${i.length}__`;i.push(f),e+=v,n=g}else e+=t.slice(r,c),n=c}return{text:e,tokens:i}}function Zu(t){const i=[];let e=t.replace(/(?:^[ \t]*(`{3,}|~{3,})[^\n\r]*\r?\n[\s\S]*?\r?\n[ \t]*\1(?=[ \t]*(?:\r?\n|$)))/gm,r=>{const a=`__CODE_TOKEN_${i.length}__`;return i.push(r),a});e=e.replace(/(`+)(?:[^\n\r`]|(?!\1)`)+?\1/g,r=>{const a=`__CODE_TOKEN_${i.length}__`;return i.push(r),a});const n=[];e=e.replace(/<script\b[^>]*>[\s\S]*?<\/script>/gi,r=>{const a=`__SCRIPT_TOKEN_${n.length}__`;return n.push(r),a});const{text:o,tokens:s}=Gu(e);e=o;const l=[];e=e.replace(/<(?:[A-Z][a-zA-Z0-9_-]*|[a-z0-9_-]+:[a-z0-9_-]+|v-[a-z0-9_-]+|arrow\b|div\s+h-\d+)\b[^>]*\/>/gi,r=>{const a=`__VUE_COMP_TOKEN_${l.length}__`;return l.push(r),a}),e=e.replace(/<(v-[a-z0-9_-]+|button)\b([^>]*)>([\s\S]*?)<\/\1>/gi,r=>{const a=`__VUE_COMP_TOKEN_${l.length}__`;return l.push(r),a}),e=e.replace(/<img\b[^>]*?\bv-[a-z0-9_.-]+[^>]*\/?>/gi,r=>{const a=`__VUE_COMP_TOKEN_${l.length}__`;return l.push(r),a}),e=e.replace(/<(p|span)\b([^>]*?\bv-[a-z0-9_.-]+[^>]*)>([\s\S]*?)<\/\1>/gi,r=>{const a=`__VUE_COMP_TOKEN_${l.length}__`;return l.push(r),a}),e=e.replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi,""),e=e.replace(/<div class="terminal-bar">[\s\S]*?<\/div>/gi,""),e=e.replace(/<div class="cursor-line">[\s\S]*?<\/div>/gi,""),e=e.replace(/<span class="cursor">[\s\S]*?<\/span>/gi,""),e=e.replace(/<div class="stamp">\s*([\s\S]*?)\s*<\/div>/gi,`

*[$1]*

`),e=e.replace(/<div class="arrow">\s*([→\->]+)\s*<\/div>/gi,`

$1

`),e=e.replace(/<i>\s*[→\->]+\s*<\/i>/gi,""),e=e.replace(/<div class="prompt">\s*([\s\S]*?)\s*<\/div>/gi,(r,a)=>`
\`\`\`bash
${a.trim()}
\`\`\`
`),e=e.replace(/<p>\s*<i>\$<\/i>\s*([\s\S]*?)<\/p>/gi,(r,a)=>`
\`\`\`bash
$ ${a.trim()}
\`\`\`
`),e=e.replace(/<div class="statusline">\s*([\s\S]*?)\s*<\/div>/gi,(r,a)=>`
> ${Array.from(a.matchAll(/<span>([\s\S]*?)<\/span>/gi)).map(u=>`\`${u[1].trim()}\``).join(" | ")}
`),e=e.replace(/<div class="log-panel">\s*<pre>([\s\S]*?)<\/pre>\s*<\/div>/gi,(r,a)=>`
\`\`\`log
${a.replace(/<span[^>]*>([\s\S]*?)<\/span>/gi,"$1").trim()}
\`\`\`
`),e=Ci(e,"diff-grid",r=>{const a=Array.from(r.matchAll(/<div class="diff\s+([^"]*)">\s*<span>(.*?)<\/span>\s*<pre>([\s\S]*?)<\/pre>\s*<\/div>/gi));return a.length>0?`
`+a.map(c=>{const u=c[2].trim().toUpperCase(),m=c[3].trim();return`**${u}:**
\`\`\`yaml
${m}
\`\`\``}).join(`

`)+`
`:r}),e=Ci(e,"before-after",r=>{const a=r.match(/<div class="before">[\s\S]*?<small>(.*?)<\/small>[\s\S]*?<h2>(.*?)<\/h2>[\s\S]*?<p>(.*?)<\/p>\s*<\/div>/i),c=r.match(/<div class="after">[\s\S]*?<small>(.*?)<\/small>[\s\S]*?<h2>(.*?)<\/h2>[\s\S]*?<p>(.*?)<\/p>\s*<\/div>/i);let u=`
`;return a&&(u+=`### ${a[1]}
## ${a[2]}
${a[3]}

`),c&&(u+=`### ${c[1]}
## ${c[2]}
${c[3]}
`),u.trim()?u:r}),e=e.replace(/<ul\b[^>]*>([\s\S]*?)<\/ul>/gi,(r,a)=>{const c=Array.from(a.matchAll(/<li>\s*(?:<em>)?(\[[x ]\])(?:<\/em>)?\s*([\s\S]*?)<\/li>/gi));return c.length>0?`
`+c.map(u=>`- ${u[1]} ${u[2].trim()}`).join(`
`)+`
`:a}),e=Ci(e,"timeline",r=>{const a=Array.from(r.matchAll(/<div(?:\s+class="([^"]*)")?>\s*<time>([\s\S]*?)<\/time>\s*<b>([\s\S]*?)<\/b>\s*<span>([\s\S]*?)<\/span>\s*<\/div>/gi));return a.length>0?`

`+a.map(c=>{const u=c[1]||"";let m="-";return u.includes("warn")?m="- ⚠️":u.includes("bad")?m="- ❌":u.includes("ok")&&(m="- ✅"),`${m} **${c[2].trim()}** **${c[3].trim()}** — ${c[4].trim()}`}).join(`
`)+`

`:r}),e=Ci(e,"pipeline",r=>{const a=Array.from(r.matchAll(/<div(?:\s+class="([^"]*)")?>\s*<small>([\s\S]*?)<\/small>\s*<b>([\s\S]*?)<\/b>\s*<span>([\s\S]*?)<\/span>\s*<\/div>/gi));return a.length>0?`

`+a.map((c,u)=>{const g=(c[1]||"").includes("hot")?"⚠️ ":"";return`${u+1}. ${g}**${c[3].trim()}** (*${c[4].trim()}*)`}).join(`
`)+`

`:r}),e=Ci(e,"check-grid",r=>{const a=Array.from(r.matchAll(/<div>\s*<span class="([^"]*)"><\/span>\s*<b>([\s\S]*?)<\/b>\s*<p>([\s\S]*?)<\/p>\s*<\/div>/gi));return a.length>0?`

`+a.map(c=>`- ${(c[1]||"").includes("warn")?"⚠️":"✅"} **${c[2].trim()}**: ${c[3].trim()}`).join(`
`)+`

`:r}),e=Ci(e,"manifesto",r=>{const a=Array.from(r.matchAll(/<div>\s*<span>([\s\S]*?)<\/span>\s*<h2>([\s\S]*?)<\/h2>\s*<p>([\s\S]*?)<\/p>\s*<\/div>/gi));return a.length>0?`

`+a.map(c=>`## ${c[1].trim()} ${c[2].trim()}

${c[3].trim()}`).join(`

`)+`

`:r}),e=Ci(e,"split-note",r=>{const a=Array.from(r.matchAll(/<div>\s*<b>([\s\S]*?)<\/b>\s*<p>([\s\S]*?)<\/p>\s*<\/div>/gi));return a.length>0?`

`+a.map(c=>`> **${c[1].trim()}**: ${c[2].trim()}`).join(`
>
`)+`

`:r}),e=e.replace(/<div class="mechanism">\s*<b>([\s\S]*?)<\/b>\s*<p>([\s\S]*?)<\/p>\s*<\/div>/gi,(r,a,c)=>`

> **${a.trim()}**: ${c.trim()}

`),e=e.replace(/<pre>([\s\S]*?)<\/pre>/gi,(r,a)=>`
\`\`\`text
${a.replace(/<span[^>]*>([\s\S]*?)<\/span>/gi,"$1").trim()}
\`\`\`
`),e=e.replace(/<div class="page-head">\s*<span>([\s\S]*?)<\/span>\s*<b>([\s\S]*?)<\/b>\s*<\/div>/gi,`
### $1 ($2)
`),e=e.replace(/<h1\b[^>]*>([\s\S]*?)<\/h1>/gi,`
# $1
`),e=e.replace(/<h2\b[^>]*>([\s\S]*?)<\/h2>/gi,`
## $1
`),e=e.replace(/<h3\b[^>]*>([\s\S]*?)<\/h3>/gi,`
### $1
`),e=e.replace(/<h4\b[^>]*>([\s\S]*?)<\/h4>/gi,`
#### $1
`),e=e.replace(/<p\s+class="ok">\s*●\s*([\s\S]*?)<\/p>/gi,`
✅ **$1**
`),e=e.replace(/<p\s+class="caption">\s*([\s\S]*?)<\/p>/gi,`
> *$1*
`),e=e.replace(/<p\s+class="lead">\s*([\s\S]*?)<\/p>/gi,`
*$1*
`),e=e.replace(/<p\b([^>]*)>([\s\S]*?)<\/p>/gi,(r,a,c)=>/@|v-|:|class=/i.test(a)?r:`
${c.trim()}

`),e=e.replace(/<br\s*\/?>/gi,`
`),e=e.replace(/<hr\s*\/?>/gi,`
---
`),e=e.replace(/<b\b[^>]*>([\s\S]*?)<\/b>/gi,"**$1**"),e=e.replace(/<strong\b[^>]*>([\s\S]*?)<\/strong>/gi,"**$1**"),e=e.replace(/<i\b[^>]*>([\s\S]*?)<\/i>/gi,"*$1*"),e=e.replace(/<code\b[^>]*>([\s\S]*?)<\/code>/gi,(r,a)=>{if(a.startsWith("`")&&a.endsWith("`"))return a;if(a.includes("`")){const c=(a.match(/`+/g)||[]).reduce((m,g)=>Math.max(m,g.length),0),u="`".repeat(c+1);return`${u} ${a} ${u}`}return`\`${a}\``}),e=e.replace(/<small\b[^>]*>([\s\S]*?)<\/small>/gi,"*$1*"),e=e.replace(/\*{4}/g,"** **"),e=e.replace(/<li\b[^>]*>([\s\S]*?)<\/li>/gi,`- $1
`),e=e.replace(/<ul\b[^>]*>([\s\S]*?)<\/ul>/gi,`
$1
`),e=e.replace(/<ol\b[^>]*>([\s\S]*?)<\/ol>/gi,`
$1
`),e=e.replace(/<a\b([^>]*)href=["'](.*?)["']([^>]*)>([\s\S]*?)<\/a>/gi,(r,a,c,u,m)=>{const g=m.trim();return g.includes("<")||g.includes(`
`)?r:`[${g}](${c})`}),e=e.replace(/<blockquote\b[^>]*>([\s\S]*?)<\/blockquote>/gi,(r,a)=>`
`+a.trim().split(`
`).map(c=>`> ${c.trim()}`).join(`
`)+`
`),e=e.replace(/<span\b[^>]*data-type=["']block-ref["'][^>]*data-id=["']([0-9a-zA-Z-]+)["'][^>]*>([\s\S]*?)<\/span>/gi,(r,a,c)=>{const u=c.replace(/<[^>]+>/g,"").trim();return u?`((${a} '${u}'))`:`((${a}))`}),e=e.replace(/<span\b[^>]*data-type=["']a["'][^>]*data-href=["']([^"']+)["'][^>]*>([\s\S]*?)<\/span>/gi,(r,a,c)=>`[${c.replace(/<[^>]+>/g,"").trim()}](${a})`),e=e.replace(/<\/(?:div|section|header|footer|main|article|nav|aside)\b[^>]*>/gi,`
`),e=e.replace(/<(?:div|section|header|footer|main|article|nav|aside)\b[^>]*>/gi,""),e=e.replace(/<\/?span\b[^>]*>/gi,"");for(let r=0;r<l.length;r++)e=e.replace(`__VUE_COMP_TOKEN_${r}__`,l[r]);for(let r=0;r<s.length;r++)e=e.replace(`__VUE_DIV_TOKEN_${r}__`,s[r]);for(let r=0;r<n.length;r++)e=e.replace(`__SCRIPT_TOKEN_${r}__`,n[r]);for(let r=0;r<i.length;r++)e=e.replace(`__CODE_TOKEN_${r}__`,i[r]);return e=e.replace(/\n{3,}/g,`

`).trim(),e}function ea(t){if(!t||typeof t!="string")return"";const i=[];let e=t.replace(/`([^`]+)`/g,n=>(i.push(n),`%%INLINE_CODE_${i.length-1}%%`));return e=e.replace(/(<\/[a-zA-Z0-9_-]+>)\s*\{:[^}]*\}/g,"$1"),e=e.replace(/(\[[^\]]+\]\([^)]+\))\s*\{:\s*style=["']([^"']*)["'][^}]*\}/g,'<span style="$2">$1</span>'),e=e.replace(/(\*\*[^*]+\*\*)\s*\{:\s*style=["']([^"']*)["'][^}]*\}/g,'<span style="$2">$1</span>'),e=e.replace(/(\*[^*]+\*)\s*\{:\s*style=["']([^"']*)["'][^}]*\}/g,'<span style="$2">$1</span>'),e=e.replace(/(~~[^~]+~~)\s*\{:\s*style=["']([^"']*)["'][^}]*\}/g,'<span style="$2">$1</span>'),e=e.replace(/([\p{L}\p{N}_\-]+)\s*\{:\s*style=["']([^"']*)["'][^}]*\}/gu,'<span style="$2">$1</span>'),e=e.replace(/\{:[^}]*\}/g,""),e=e.replace(/%%INLINE_CODE_(\d+)%%/g,(n,o)=>i[parseInt(o,10)]||""),e}function Yu(t){const i=Object.entries(t).filter(([n,o])=>o!=null&&o!=="");return i.length===0?"":`---
${i.map(([n,o])=>typeof o=="string"?o.includes(":")||o.includes(`
`)||o.includes("#")?`${n}: "${o.replace(/"/g,'\\"')}"`:`${n}: ${o}`:`${n}: ${JSON.stringify(o)}`).join(`
`)}
---`}function Ju(t,i){if(!i||!t.startsWith("```"))return t;const e=t.indexOf(`
`);if(e===-1)return t;const n=t.slice(0,e).trim(),o=t.slice(e);return n.includes("{")?t:`${n} {${i}}${o}`}function ia(t,i){if(i==null)return t;const e=i.trim();return e===""||e==="+1"?`<v-click>

${t}

</v-click>`:e==="hide"?`<v-click hide>

${t}

</v-click>`:`<v-click at="${e}">

${t}

</v-click>`}function Xu(t){if(!t||!t.preset)return null;const i=t.preset.toLowerCase().trim();if(!i||i==="none")return null;let e={opacity:0},n={opacity:1};switch(i){case"slide-up":e={y:40,opacity:0},n={y:0,opacity:1};break;case"slide-down":e={y:-40,opacity:0},n={y:0,opacity:1};break;case"slide-left":e={x:40,opacity:0},n={x:0,opacity:1};break;case"slide-right":e={x:-40,opacity:0},n={x:0,opacity:1};break;case"zoom-in":case"pop":e={scale:.8,opacity:0},n={scale:1,opacity:1};break;case"bounce":e={y:40,opacity:0},n={y:0,opacity:1,transition:{type:"spring",damping:10,stiffness:100}};break;case"fade-in":default:e={opacity:0},n={opacity:1};break}t.initial&&typeof t.initial=="object"&&(e={...e,...t.initial}),t.enter&&typeof t.enter=="object"&&(n={...n,...t.enter});const o={...n.transition||{}};return typeof t.duration=="number"&&t.duration>0&&(o.duration=t.duration),typeof t.delay=="number"&&t.delay>0&&(o.delay=t.delay),Object.keys(o).length>0&&(n.transition=o),{initial:e,enter:n}}function Gn(t,i,e,n){const o=i!=null&&i.trim()!=="",s=Xu(e),l=n==null?void 0:n.trim(),r=l!==void 0&&l!=="",a=r?` style="${l.replace(/"/g,"&quot;")}" class="slide-styled-block"`:"";if(!o&&!s)return r?`<div${a}>

${t}

</div>`:t;if(o&&!s){if(r){const b=i.trim();let f="v-click";return b==="hide"?f="v-click.hide":b!==""&&b!=="+1"&&(f=`v-click="${b}"`),`<div ${f}${a}>

${t}

</div>`}return ia(t,i)}const c=JSON.stringify(s.initial).replace(/"/g,"'"),u=JSON.stringify(s.enter).replace(/"/g,"'"),m=`v-motion :initial="${c}" :enter="${u}"`;if(!o)return`<div ${m}${a}>

${t}

</div>`;const g=i.trim();let d="v-click";return g==="hide"?d="v-click.hide":g!==""&&g!=="+1"&&(d=`v-click="${g}"`),`<div ${d} ${m}${a}>

${t}

</div>`}function na(t){if(!t)return"";let i=t.trim();i=i.replace(/\{:[^}]*\}/g,"").trim(),i=i.replace(/^:::\s*[a-zA-Z0-9_-]*\s*\r?\n?/g,""),i=i.replace(/\r?\n?:::\s*$/g,"");let o=i.split(/\r?\n/).map(s=>s.trim().replace(/^>\s*/,"")).join(`
`).trim();return o=o.replace(/^\[!(?:NOTE|TIP|IMPORTANT|WARNING|CAUTION|[A-Za-z_-]+)\][^\r\n]*(?:\r?\n)?/i,"").trim(),o=o.replace(/^(?:💡|✏️|❗|⚠️|🚨|\s*)*(?:\*\*|__)?(?:演讲备注|演讲者提词|讲稿备注|演讲提词|备注|Notes?)(?:\*\*|__)?[:：]?\s*(?:\r?\n)?/i,"").trim(),o=o.replace(/^[-*+]\s+/,""),o=o.replace(/^\d+\.\s+/,""),o.trim()}function Qu(t){var n;if(t.subType&&/^h([1-6])$/i.test(t.subType))return parseInt(t.subType.slice(1),10);const e=(t.markdown||t.content||"").trim().match(/^(#{1,6})\s+/);return e?e[1].length:t.type==="h"?(n=t.ial)!=null&&n.subType&&/^h([1-6])$/i.test(t.ial.subType)?parseInt(t.ial.subType.slice(1),10):1:null}function oa(t,i=2){const e=Math.max(2,i);if(!t||t.length===0)return Array.from({length:e},()=>[]);if(t.length===1&&t[0].children&&t[0].children.length>=2){const c=t[0].children,u=Array.from({length:e},()=>[]),m=Math.min(e,c.length),g=Math.floor(c.length/m),d=c.length%m;let b=0;for(let f=0;f<m;f++){const v=g+(f<d?1:0);u[f]=c.slice(b,b+v),b+=v}return u}const n=c=>{const u=(c.slot||"").trim();if(!u)return null;if(u==="left")return 1;if(u==="center")return 2;if(u==="right")return e===2?2:e;const m=u.match(/^col-(\d+)$/i);if(m){const g=parseInt(m[1],10);if(g>=1&&g<=e)return g}return null},o=t.map(n);if(o.some(c=>c!==null)){if(o.some(d=>d!==null&&d>=2)){const d=Array.from({length:e},()=>[]);let b=1;for(const f of t){const v=n(f);v!==null&&(b=v),d[b-1].push(f)}return d}const u=t.filter(d=>n(d)===1),m=t.filter(d=>n(d)===null),g=e-1;if(m.length>=g){const d=Math.floor(m.length/g),b=m.length%g,f=[u];let v=0;for(let k=0;k<g;k++){const S=d+(k<b?1:0);f.push(m.slice(v,v+S)),v+=S}return f}else if(m.length>0){const d=[u];for(let b=0;b<g;b++)d.push(b<m.length?[m[b]]:[]);return d}else return[u,...Array.from({length:g},()=>[])]}const l=c=>{if(c.type==="h"||c.subType&&/^h[1-6]$/i.test(c.subType))return!0;const u=(c.rawMarkdown||c.content||"").trim();return/^#{1,6}\s+/.test(u)},r=t.map((c,u)=>l(c)?u:-1).filter(c=>c!==-1);if(r.length>=e){const c=Array.from({length:e},()=>[]);for(let u=0;u<e;u++){const m=r[u],g=u+1<e?r[u+1]:t.length;c[u]=t.slice(m,g)}return c}if(t.length>=e){const c=Array.from({length:e},()=>[]);let u=0;for(let m=0;m<e;m++){const g=e-m,d=t.length-u,b=Math.ceil(d/g);c[m]=t.slice(u,u+b),u+=b}return c}if(t.length>1&&t.length<e){const c=Array.from({length:e},()=>[]);for(let u=0;u<t.length;u++)c[u]=[t[u]];return c}if(t.length===1){const c=t[0],u=(c.rawMarkdown||c.content||"").trim(),m=u.split(/\r?\n/),g=[];for(let f=0;f<m.length;f++)/^[ \t]*[-*+]\s+|^[ \t]*\d+\.\s+/.test(m[f])&&g.push(f);if(g.length>=e){const f=Array.from({length:e},()=>[]);let v=0;for(let k=0;k<e;k++){const S=e-k,x=g.length-v,A=Math.ceil(x/S),T=g[v],I=v+A<g.length?g[v+A]:m.length,w=m.slice(T,I).join(`
`);f[k]=[{...c,id:k===0?c.id:`${c.id}-col${k+1}`,rawMarkdown:w,content:w}],v+=A}return f}const d=u.match(/<li[\s\S]*?<\/li>/gi);if(d&&d.length>=e){const f=Array.from({length:e},()=>[]);let v=0;for(let k=0;k<e;k++){const S=e-k,x=d.length-v,A=Math.ceil(x/S),T=`<ul>
${d.slice(v,v+A).join(`
`)}
</ul>`;f[k]=[{...c,id:k===0?c.id:`${c.id}-col${k+1}`,rawMarkdown:T,content:T}],v+=A}return f}const b=u.split(/\r?\n\s*\r?\n/).filter(f=>f.trim()!=="");if(b.length>=e){const f=Array.from({length:e},()=>[]);let v=0;for(let k=0;k<e;k++){const S=e-k,x=b.length-v,A=Math.ceil(x/S),T=b.slice(v,v+A).join(`

`);f[k]=[{...c,id:k===0?c.id:`${c.id}-col${k+1}`,rawMarkdown:T,content:T}],v+=A}return f}}const a=Array.from({length:e},()=>[]);return a[0]=t,a}function Br(t,i,e,n){var u;const o=Fu(i),s=[],l=Ar(i);let r={pageIndex:1,startBlockId:t,frontmatter:{layout:l.frontmatter.layout||"cover",...l.frontmatter},notes:"",noteBlocks:[],blocks:[],rawMarkdown:"",allBlockIds:[t]};r.frontmatter.background&&(r.frontmatter.background=Ie(r.frontmatter.background,n)),r.frontmatter.image&&(r.frontmatter.image=Ie(r.frontmatter.image,n)),s.push(r);let a=[];for(const m of e){if(bo(m)){a=[];const d=Ar(m.ial);if(s.length===1&&r.blocks.length===0){r.startBlockId=m.id,r.allBlockIds||(r.allBlockIds=[]),r.allBlockIds.includes(m.id)||r.allBlockIds.push(m.id),d.frontmatter.layout&&(r.frontmatter.layout=d.frontmatter.layout),Object.assign(r.frontmatter,d.frontmatter),!d.frontmatter.image&&l.frontmatter.image&&(r.frontmatter.image=l.frontmatter.image),!d.frontmatter.background&&l.frontmatter.background&&(r.frontmatter.background=l.frontmatter.background),r.frontmatter.background&&(r.frontmatter.background=Ie(r.frontmatter.background,n)),r.frontmatter.image&&(r.frontmatter.image=Ie(r.frontmatter.image,n));continue}r={pageIndex:s.length+1,startBlockId:m.id,frontmatter:{layout:d.frontmatter.layout||"default",...d.frontmatter},notes:"",noteBlocks:[],blocks:[],rawMarkdown:"",allBlockIds:[m.id]},r.frontmatter.background&&(r.frontmatter.background=Ie(r.frontmatter.background,n)),r.frontmatter.image&&(r.frontmatter.image=Ie(r.frontmatter.image,n)),s.push(r);continue}const g=(d,b)=>{var X,P,U,W;if(r.allBlockIds||(r.allBlockIds=[]),d.id&&!r.allBlockIds.includes(d.id)&&r.allBlockIds.push(d.id),d.children&&d.children.length>0){const tt=B=>{for(const M of B)M.id&&!r.allBlockIds.includes(M.id)&&r.allBlockIds.push(M.id),M.children&&M.children.length>0&&tt(M.children)};tt(d.children)}let f=ac(d),v=d.ial?{...d.ial}:{};const k=f.match(/\{:\s*([^}]+)\s*\}\s*$/);k&&(v={...cc(k[0]),...v},f=f.slice(0,k.index).trim()),d.type!=="c"&&!f.startsWith("```")&&(f=ea(f));let S=f.trim();if(/^\{\{\{(?:row|col)?\s*$/i.test(S)||S==="}}}")return;/^\{\{\{(?:row|col)?\s*\r?\n/i.test(S)&&/\r?\n\}\}\}$/.test(S)&&(f=S.replace(/^\{\{\{(?:row|col)?\s*\r?\n/i,"").replace(/\r?\n\}\}\}$/,"").trim(),S=f.trim());const x=Hu(v);if(f=fc(f,n),f=lc(f,n==null?void 0:n.refContentMap),d.children&&d.children.length>0){const tt=["custom-slidev-autoplay","custom-slidev-loop","custom-slidev-muted","custom-slidev-controls"],B=M=>{for(const Y of M){if(Y.ial)for(const[Z,Q]of Object.entries(Y.ial))tt.includes(Z)&&!v[Z]&&(v[Z]=Q);Y.children&&Y.children.length>0&&B(Y.children)}};B(d.children)}const A=d.type==="video"||d.type==="NodeVideo"||/<video\b/i.test(f);if(A){const tt=v["custom-slidev-autoplay"]==="true",B=v["custom-slidev-loop"]==="true",M=v["custom-slidev-muted"]==="true"||tt,Y=v["custom-slidev-controls"]==="false";f=f.replace(/<video\b([^>]*)>/gi,(Z,Q)=>{let D=Q;return Y?D=D.replace(/\bcontrols(?:="[^"]*")?/gi,"").trim():/controls/i.test(D)||(D+=" controls"),tt&&!/autoplay/i.test(D)?D+=" autoplay playsinline":!tt&&v["custom-slidev-autoplay"]==="false"&&(D=D.replace(/\bautoplay\b/gi,"").replace(/\bplaysinline\b/gi,"").trim()),B&&!/loop/i.test(D)?D+=" loop":!B&&v["custom-slidev-loop"]==="false"&&(D=D.replace(/\bloop\b/gi,"").trim()),M&&!/muted/i.test(D)?D+=" muted":!M&&v["custom-slidev-muted"]==="false"&&(D=D.replace(/\bmuted\b/gi,"").trim()),`<video ${D.trim()}>`})}if(x.isBackground){const tt=bi(f,d.content);if(tt){r.frontmatter.background=Ie(tt,n);return}}const T=ci(d);if(T){r.frontmatter.layout=T.layout,r.frontmatter.image=Ie(T.imageUrl,n),!r.frontmatter.layoutRatio&&T.ratio&&(r.frontmatter.layoutRatio=T.ratio);for(const tt of T.contentNodes)g(tt);return}if(x.imageLayout==="image-left"||x.imageLayout==="image-right"){const tt=bi(f,d.content);if(tt){r.frontmatter.layout=x.imageLayout,r.frontmatter.image=Ie(tt,n),!r.frontmatter.layoutRatio&&((X=d.ial)!=null&&X[le])&&(r.frontmatter.layoutRatio=d.ial[le]);return}}if(oe(d)&&d.children&&d.children.length>0){for(const tt of d.children)g(tt);return}const I=!!(x.slot||b!=null&&b.defaultSlot||r.frontmatter.layout==="clover"||$n(r.frontmatter.layout)||r.frontmatter.layout==="two-cols");if((d.type==="l"||d.type==="NodeList"||d.type==="list")&&d.children&&d.children.length>0&&(d.children.some(tt=>{var B,M;return((B=tt.ial)==null?void 0:B[Ct])||((M=tt.ial)==null?void 0:M[jt])})||x.slot||x.clicks||I)){for(const tt of d.children)x.slot&&(!tt.ial||!tt.ial[Ct])&&(tt.ial||(tt.ial={}),tt.ial[Ct]=x.slot),g(tt,{...b,parentClicks:x.clicks||(b==null?void 0:b.parentClicks),defaultSlot:x.slot||(b==null?void 0:b.defaultSlot)});return}const w=!!(d.children&&d.children.length>=2)||!!x.clicks||!!((P=d.children)!=null&&P.some(tt=>{var B;return(B=tt.ial)==null?void 0:B[jt]}))||!d.markdown&&!!(d.children&&d.children.length>0);if(Ri(d)&&d.children&&d.children.length>0&&(I||x.clicks||d.children.some(tt=>{var B;return(B=tt.ial)==null?void 0:B[jt]}))&&w){const tt=!!(d.children&&d.children.length>=2),B=d.children.find(lt=>!!(lt.markdown||lt.content||"").trim())||d.children[0],M=((U=B==null?void 0:B.ial)==null?void 0:U[jt])||((W=B==null?void 0:B.ial)==null?void 0:W["custom-slidev-click"]),Y=!!(!x.clicks&&tt&&M),Z=x.clicks||(Y?M:void 0)||(b==null?void 0:b.parentClicks),Q=d.id||(b==null?void 0:b.parentContainerId),D=x.slot||(b==null?void 0:b.defaultSlot);let dt=!0;for(const lt of d.children){D&&(!lt.ial||!lt.ial[Ct])&&(lt.ial||(lt.ial={}),lt.ial[Ct]=D);const rt=!!(lt.markdown||lt.content||"").trim(),gt=dt&&rt;gt&&(lt.markdown&&(lt.markdown=bn(lt.markdown)),lt.content&&(lt.content=bn(lt.content)),dt=!1);let nt=lt;gt&&Z&&tt&&(nt={...lt,ial:{...lt.ial||{}}},delete nt.ial[jt],delete nt.ial["custom-slidev-click"]),g(nt,{parentClicks:Z,parentContainerId:Q,defaultSlot:D})}return}if(x.isNote){const tt=na(f);tt&&(r.notes?r.notes+=`

`+tt:r.notes=tt),r.noteBlocks||(r.noteBlocks=[]),r.noteBlocks.push({id:d.id,type:d.type,content:tt||d.content||"",rawMarkdown:f,isNote:!0,attributes:d.ial});return}x.shikiLines&&(f=Ju(f,x.shikiLines)),S=f.trim();const N=(d.content||"").trim();if(S==="::right::"||N==="::right::"||/^<p>\s*::right::\s*<\/p>$/i.test(S)||S.startsWith("::right::")){r.blocks.push({id:d.id,type:d.type,content:"::right::",rawMarkdown:"::right::",slot:"slot-divider-right",attributes:d.ial});return}const j=Qu(d);let J=x.slot,$=x.clicks,O=x.motion,y={...d.ial||{}};if(j!==null){for(;a.length>0&&a[a.length-1].level>=j;)a.pop();const tt=a.length>0?a[a.length-1]:void 0;!J&&(tt!=null&&tt.slot)&&(J=tt.slot),!$&&(tt!=null&&tt.clicks)&&!(b!=null&&b.parentContainerId)&&($=tt.clicks),!O&&(tt!=null&&tt.motion)&&(O=tt.motion);const B={...(tt==null?void 0:tt.customAttrs)||{}};if(d.ial)for(const[M,Y]of Object.entries(d.ial))M.startsWith("custom-slidev-")&&!M.startsWith("custom-slidev-slide")&&(B[M]=Y);b!=null&&b.parentContainerId||a.push({level:j,slot:J,clicks:$,motion:O,customAttrs:B})}else{const tt=a.length>0?a[a.length-1]:void 0;tt&&(!J&&tt.slot&&tt.slot!=="header"&&(J=tt.slot),!$&&tt.clicks&&!(b!=null&&b.parentContainerId)&&($=tt.clicks),!O&&tt.motion&&(O=tt.motion),tt.customAttrs&&(y={...tt.customAttrs,...y}))}!J&&r.blocks.some(tt=>tt.slot==="slot-divider-right")&&(J="right"),!J&&(b!=null&&b.defaultSlot)&&(J=b.defaultSlot),J&&(y[Ct]=J),$&&!y[jt]&&(y[jt]=$),O&&!y[Ve]&&(y[Ve]=JSON.stringify(O)),(A||v["custom-slidev-autoplay"]||v["custom-slidev-muted"])&&(v["custom-slidev-autoplay"]&&(y["custom-slidev-autoplay"]=v["custom-slidev-autoplay"],v["custom-slidev-autoplay"]==="true"&&!v["custom-slidev-muted"]&&(y["custom-slidev-muted"]="true")),v["custom-slidev-loop"]&&(y["custom-slidev-loop"]=v["custom-slidev-loop"]),v["custom-slidev-muted"]&&(y["custom-slidev-muted"]=v["custom-slidev-muted"]),v["custom-slidev-controls"]&&(y["custom-slidev-controls"]=v["custom-slidev-controls"]));const V={id:d.id,type:d.type,content:d.content||"",rawMarkdown:f,clicks:$,parentClicks:b==null?void 0:b.parentClicks,parentContainerId:b==null?void 0:b.parentContainerId,motion:O,shikiLines:x.shikiLines,slot:J,attributes:y,rawNode:d};r.blocks.push(V)};g(m)}for(let m=0;m<s.length;m++){const g=s[m],d=[],b={...g.frontmatter};m===0&&(b.theme=o.theme,b.aspectRatio=o.aspectRatio,b.highlighter=o.highlighter,b.transition=g.frontmatter.transition||o.defaultTransition);const f=Yu(b);f&&d.push(f);const v=g.blocks.filter(T=>T.slot!=="slot-divider-right"),k=T=>T.filter(I=>!!(I.rawMarkdown||I.content||"").trim()).map(I=>{var w;return Gn(I.rawMarkdown,I.clicks,I.motion,(w=I.attributes)==null?void 0:w.style)}).join(`

`),S=T=>{const I=T.filter(j=>!!(j.rawMarkdown||j.content||"").trim());if(I.length===0)return;const w=I[0],N=(w.rawMarkdown||w.content||"").trim();(Ri(w)||/^(?:[-*+]|\d+\.)\s+/.test(N))&&(w.rawMarkdown=bn(w.rawMarkdown||w.content||""),w.content=w.rawMarkdown)},x=T=>{var j,J;if(T.length===0)return"";S(T);const I=(j=T.find($=>$.parentClicks))==null?void 0:j.parentClicks;if(!I)return T.filter($=>!!($.rawMarkdown||$.content||"").trim()).map($=>{var O;return Gn($.rawMarkdown,$.clicks,$.motion,(O=$.attributes)==null?void 0:O.style)}).join(`

`);const w=[];let N=[];const F=()=>{if(N.length===0)return;const $=N.map(O=>(O.rawMarkdown||O.content||"").trim()).filter(Boolean).join(`

`);$&&w.push(ia($,I)),N=[]};for(const $ of T){if(!($.rawMarkdown||$.content||"").trim())continue;!!($.clicks&&$.clicks.trim()!=="")?(F(),w.push(Gn($.rawMarkdown,$.clicks,$.motion,(J=$.attributes)==null?void 0:J.style))):N.push($)}return F(),w.join(`

`)},A=g.frontmatter.layout||"default";if(A==="clover"||$n(A)){let T=[];const I=v.filter($=>$.slot==="header");if(I.length>0)T=I;else if(v.length>0){const $=v.find(O=>O.type==="h"&&(!O.slot||O.slot==="default"));$&&(T=[$])}const w=v.filter($=>!T.includes($));let N=2;if(A==="clover")N=4;else if(A==="three-cols-header")N=3;else if(A==="two-cols-header")N=2;else{let $=0;for(const O of w){const y=(O.slot||"").match(/^col-(\d+)$/i);y&&($=Math.max($,parseInt(y[1],10)))}if($>=2)N=$;else if(g.frontmatter.layoutRatio){const O=g.frontmatter.layoutRatio.trim();if(O.includes(":")){const y=O.split(":").map(V=>parseFloat(V.trim())).filter(V=>!isNaN(V)&&V>0);y.length>=2&&(N=y.length)}else{const y=O.split(/\s+/).filter(Boolean);y.length>=2&&(N=y.length)}}else w.length===1&&w[0].children&&w[0].children.length>=2&&(N=Math.min(6,w[0].children.length))}const F=oa(w,N);F.forEach(($,O)=>{const y=`col-${O+1}`;for(const V of $)(!V.slot||V.slot==="default")&&(V.slot=y);S($)});const j=F.flat();if(w.length===1&&j.length>1){const $=g.blocks.findIndex(O=>O.id===w[0].id);$!==-1&&g.blocks.splice($,1,...j)}const J=k(T);if(J&&d.push(J),A==="two-cols-header"&&N===2){const $=x(F[0]||[]),O=x(F[1]||[]);$&&d.push(`::left::

${$}`),O&&d.push(`::right::

${O}`)}else F.forEach(($,O)=>{const y=x($);y&&d.push(`::col-${O+1}::

${y}`)})}else if(A==="two-cols"){const T=v.filter(F=>F.slot==="left"),I=v.filter(F=>F.slot==="right");S(T),S(I);const w=k(T.length>0?T:v.filter(F=>F.slot!=="right")),N=k(I);d.push(w),N&&d.push(`::right::

${N}`)}else for(const T of v)d.push(Gn(T.rawMarkdown,T.clicks,T.motion,(u=T.attributes)==null?void 0:u.style));g.notes&&d.push(`<!--
${g.notes}
-->`),g.rawMarkdown=d.join(`

`).trim()}const c=s.map(m=>m.rawMarkdown).filter(Boolean).join(`

---

`);return{docId:t,config:o,slides:s,fullMarkdown:c}}const ps=`/* SiYuan Note Built-in Font & Background Styles for Slidev */
:root,
html:not(.dark),
[data-theme="light"],
[data-theme-mode="light"] {
  /* 思源基础卡片与主题色 (浅色模式 daylight) */
  --b3-card-error-color: #790600;
  --b3-card-error-background: #f5d1cf;
  --b3-card-warning-color: #8a4f00;
  --b3-card-warning-background: #ffe8c8;
  --b3-card-info-color: #005599;
  --b3-card-info-background: #d6eaf9;
  --b3-card-success-color: #006b04;
  --b3-card-success-background: #d7eed8;

  --b3-theme-primary: #3575f0;
  --b3-theme-secondary: #ff9200;
  --b3-theme-error: #d23f31;
  --b3-theme-background: #ffffff;
  --b3-theme-on-background: #222222;
  --b3-theme-on-surface: #5f6368;
  --b3-theme-surface-lighter: #e0e0e0;

  /* 13 种内置文字颜色 */
  --b3-font-color1: var(--b3-card-error-color);
  --b3-font-color2: var(--b3-card-warning-color);
  --b3-font-color3: var(--b3-card-info-color);
  --b3-font-color4: var(--b3-card-success-color);
  --b3-font-color5: var(--b3-theme-on-surface);
  --b3-font-color6: var(--b3-theme-primary);
  --b3-font-color7: var(--b3-theme-secondary);
  --b3-font-color8: var(--b3-theme-error);
  --b3-font-color9: #a40074;
  --b3-font-color10: #007080;
  --b3-font-color11: #006e2a;
  --b3-font-color12: #6b5a00;
  --b3-font-color13: var(--b3-theme-background);

  /* 13 种内置背景颜色 */
  --b3-font-background1: var(--b3-card-error-background);
  --b3-font-background2: var(--b3-card-warning-background);
  --b3-font-background3: var(--b3-card-info-background);
  --b3-font-background4: var(--b3-card-success-background);
  --b3-font-background5: #e2e3e4;
  --b3-font-background6: #acd0fc;
  --b3-font-background7: #fddaab;
  --b3-font-background8: #ffb0a9;
  --b3-font-background9: #fdbfff;
  --b3-font-background10: #b1ffff;
  --b3-font-background11: #affad1;
  --b3-font-background12: #fff88f;
  --b3-font-background13: var(--b3-theme-on-background);
}

html.dark,
[data-theme="dark"],
[data-theme-mode="dark"],
.theme-dark,
.dark {
  /* 思源基础卡片与主题色 (深色模式 midnight) */
  --b3-card-error-color: rgb(243, 153, 147);
  --b3-card-error-background: #442724;
  --b3-card-warning-color: rgb(255, 213, 153);
  --b3-card-warning-background: #554636;
  --b3-card-info-color: rgb(166, 213, 250);
  --b3-card-info-background: #28405c;
  --b3-card-success-color: rgb(183, 223, 185);
  --b3-card-success-background: #425347;

  --b3-theme-primary: #3575f0;
  --b3-theme-secondary: #ff9200;
  --b3-theme-error: #d23f31;
  --b3-theme-background: #1e1e1e;
  --b3-theme-on-background: #c8ccd6;
  --b3-theme-on-surface: #8b949e;
  --b3-theme-surface-lighter: #282a2e;

  /* 13 种内置文字颜色 */
  --b3-font-color1: var(--b3-card-error-color);
  --b3-font-color2: var(--b3-card-warning-color);
  --b3-font-color3: var(--b3-card-info-color);
  --b3-font-color4: var(--b3-card-success-color);
  --b3-font-color5: var(--b3-theme-on-surface);
  --b3-font-color6: var(--b3-theme-primary);
  --b3-font-color7: var(--b3-theme-secondary);
  --b3-font-color8: var(--b3-theme-error);
  --b3-font-color9: #f47c9c;
  --b3-font-color10: #4dd0e1;
  --b3-font-color11: #10df54;
  --b3-font-color12: #ecd424;
  --b3-font-color13: var(--b3-theme-background);

  /* 13 种内置背景颜色 */
  --b3-font-background1: var(--b3-card-error-background);
  --b3-font-background2: var(--b3-card-warning-background);
  --b3-font-background3: var(--b3-card-info-background);
  --b3-font-background4: var(--b3-card-success-background);
  --b3-font-background5: #3a3f42;
  --b3-font-background6: #031840;
  --b3-font-background7: #593905;
  --b3-font-background8: #3a0c09;
  --b3-font-background9: #4d1b40;
  --b3-font-background10: #1a5459;
  --b3-font-background11: #305415;
  --b3-font-background12: #4a4712;
  --b3-font-background13: var(--b3-theme-on-background);
}

@media (prefers-color-scheme: dark) {
  :root:not([data-theme="light"]):not([data-theme-mode="light"]):not(.light) {
    --b3-card-error-color: rgb(243, 153, 147);
    --b3-card-error-background: #442724;
    --b3-card-warning-color: rgb(255, 213, 153);
    --b3-card-warning-background: #554636;
    --b3-card-info-color: rgb(166, 213, 250);
    --b3-card-info-background: #28405c;
    --b3-card-success-color: rgb(183, 223, 185);
    --b3-card-success-background: #425347;

    --b3-theme-primary: #3575f0;
    --b3-theme-secondary: #ff9200;
    --b3-theme-error: #d23f31;
    --b3-theme-background: #1e1e1e;
    --b3-theme-on-background: #c8ccd6;
    --b3-theme-on-surface: #8b949e;
    --b3-theme-surface-lighter: #282a2e;

    --b3-font-color1: var(--b3-card-error-color);
    --b3-font-color2: var(--b3-card-warning-color);
    --b3-font-color3: var(--b3-card-info-color);
    --b3-font-color4: var(--b3-card-success-color);
    --b3-font-color5: var(--b3-theme-on-surface);
    --b3-font-color6: var(--b3-theme-primary);
    --b3-font-color7: var(--b3-theme-secondary);
    --b3-font-color8: var(--b3-theme-error);
    --b3-font-color9: #f47c9c;
    --b3-font-color10: #4dd0e1;
    --b3-font-color11: #10df54;
    --b3-font-color12: #ecd424;
    --b3-font-color13: var(--b3-theme-background);

    --b3-font-background1: var(--b3-card-error-background);
    --b3-font-background2: var(--b3-card-warning-background);
    --b3-font-background3: var(--b3-card-info-background);
    --b3-font-background4: var(--b3-card-success-background);
    --b3-font-background5: #3a3f42;
    --b3-font-background6: #031840;
    --b3-font-background7: #593905;
    --b3-font-background8: #3a0c09;
    --b3-font-background9: #4d1b40;
    --b3-font-background10: #1a5459;
    --b3-font-background11: #305415;
    --b3-font-background12: #4a4712;
    --b3-font-background13: var(--b3-theme-on-background);
  }
}

/* 演示块级样式排版增强 (带背景色时赋予呼吸内边距与舒适圆角) */
.slide-styled-block {
  border-radius: 6px;
  padding: 8px 14px;
  box-sizing: border-box;
  margin: 6px 0;
  transition: background-color 0.2s ease, color 0.2s ease;
}

/* 行内带背景色文本的精美圆角与微边距 */
span[style*="background-color"],
span[style*="background:"] {
  border-radius: 3px;
  padding: 1px 5px;
  box-decoration-break: clone;
  -webkit-box-decoration-break: clone;
}
`;function tf(t){var o,s,l,r,a,c,u,m,g,d,b,f;if(!t||typeof t!="object")return"";const i=[],e=[];if(Array.isArray(t.styles))for(const v of t.styles){if(!v||!v.id)continue;const k=`--b3-inline-style-${v.id}`;(o=v.light)!=null&&o.color&&i.push(`  ${k}-color: ${v.light.color};`),(s=v.light)!=null&&s.backgroundColor&&i.push(`  ${k}-background-color: ${v.light.backgroundColor};`),(l=v.dark)!=null&&l.color&&e.push(`  ${k}-color: ${v.dark.color};`),(r=v.dark)!=null&&r.backgroundColor&&e.push(`  ${k}-background-color: ${v.dark.backgroundColor};`)}if(t.builtin&&Array.isArray(t.builtin.colors))for(const v of t.builtin.colors){if(!v||typeof v.index!="number")continue;const k=v.index;(a=v.light)!=null&&a.color&&i.push(`  --b3-font-color${k}: ${v.light.color};`),(c=v.light)!=null&&c.backgroundColor&&i.push(`  --b3-font-background${k}: ${v.light.backgroundColor};`),(u=v.dark)!=null&&u.color&&e.push(`  --b3-font-color${k}: ${v.dark.color};`),(m=v.dark)!=null&&m.backgroundColor&&e.push(`  --b3-font-background${k}: ${v.dark.backgroundColor};`)}if(t.builtin&&Array.isArray(t.builtin.styles))for(const v of t.builtin.styles){if(!v||!v.id)continue;const k=v.id;(g=v.light)!=null&&g.color&&i.push(`  --b3-card-${k}-color: ${v.light.color};`),(d=v.light)!=null&&d.backgroundColor&&i.push(`  --b3-card-${k}-background: ${v.light.backgroundColor};`),(b=v.dark)!=null&&b.color&&e.push(`  --b3-card-${k}-color: ${v.dark.color};`),(f=v.dark)!=null&&f.backgroundColor&&e.push(`  --b3-card-${k}-background: ${v.dark.backgroundColor};`)}if(i.length===0&&e.length===0)return"";const n=[];return i.length>0&&n.push(`:root, html:not(.dark), [data-theme="light"] {
${i.join(`
`)}
}`),e.length>0&&n.push(`html.dark, [data-theme="dark"], .dark {
${e.join(`
`)}
}`),n.join(`

`)}function kn(t){const i=tf(t);return i?`${ps}

/* Custom Workspace Inline Styles */
${i}`:ps}function Ko(t){const i={};if(!t||typeof t!="string")return i;const e=t.replace(/^\{:\s*/,"").replace(/\s*\}$/,""),n=/([\w-]+)=(?:"([^"]*)"|'([^']*)'|(\S+))/g;let o;for(;(o=n.exec(e))!==null;){const s=o[1],l=o[2]??o[3]??o[4]??"";i[s]=l}return i}const ef={getBlockAttrs:Ye,getChildBlocks:no,setBlockAttrs:Et,sql:wn,getBaseUrl:()=>typeof location<"u"?location.origin:"",getInlineStyles:sc};class nf{constructor(i){xt(this,"deps");xt(this,"attrOverrides",new Map);xt(this,"trackedListSuperBlocks",new Map);this.deps={...ef,...i||{}}}setBlockAttrOverride(i,e){if(!i||!e)return;const o={...this.attrOverrides.get(i)||{}};for(const[s,l]of Object.entries(e))l===""||l===null||l===void 0?delete o[s]:o[s]=String(l);Object.keys(o).length===0?this.attrOverrides.delete(i):this.attrOverrides.set(i,o)}getBlockAttrOverride(i){return this.attrOverrides.get(i)}getAllAttrOverrides(){return new Map(this.attrOverrides)}getTrackedListSuperBlocks(i){return this.trackedListSuperBlocks.get(i)||[]}clearBlockAttrOverride(i,e){if(!i)return;if(!e){this.attrOverrides.delete(i);return}const n=this.attrOverrides.get(i);n&&(delete n[e],Object.keys(n).length===0&&this.attrOverrides.delete(i))}clearAllOverrides(){this.attrOverrides.clear(),this.trackedListSuperBlocks.clear()}async compile(i){try{const e=await this.deps.getBlockAttrs(i).catch(()=>({}))||{},n=this.attrOverrides.get(i);n&&Object.assign(e,n);let o=await this.deps.getChildBlocks(i).catch(()=>[]);const s=`SELECT id, ial FROM blocks WHERE root_id = '${i}' LIMIT 99999`,l=await this.deps.sql(s).catch(()=>[])||[],r=new Map;if(Array.isArray(l))for(const x of l)x.id&&x.ial&&r.set(x.id,Ko(x.ial));const a=`SELECT block_id, name, value FROM attributes WHERE root_id = '${i}' AND type = 'b' LIMIT 99999`,c=await this.deps.sql(a).catch(()=>[])||[];if(Array.isArray(c)){for(const x of c)if(x.block_id&&x.name){let A=r.get(x.block_id);A||(A={},r.set(x.block_id,A)),A[x.name]=x.value||""}}if(!o||o.length===0){const x=`SELECT id, parent_id, root_id, type, sub_type as subType, content, markdown, ial FROM blocks WHERE root_id = '${i}' AND id != '${i}' ORDER BY created ASC LIMIT 99999`;o=await this.deps.sql(x).catch(()=>[])||[]}const u=(o||[]).map(x=>{const A=r.get(x.id)||(x.ial?Ko(x.ial):{}),T=this.attrOverrides.get(x.id);return T&&Object.assign(A,T),{id:x.id,parent_id:x.parent_id,root_id:x.root_id||i,type:x.type,subType:x.subType,content:x.content||"",markdown:x.markdown||"",ial:A,children:x.children}}),m=async(x,A=0)=>{if(!(!x||x.length===0||A>8))for(const T of x){if((oe(T)||T.type==="l"||T.type==="NodeList"||T.type==="i"||T.type==="NodeListItem"||T.type==="b"||T.type==="NodeBlockquote")&&(!T.children||T.children.length===0)){let w=await this.deps.getChildBlocks(T.id).catch(()=>[]);if(!w||w.length===0){const N=`SELECT id, parent_id, root_id, type, sub_type as subType, content, markdown, ial FROM blocks WHERE parent_id = '${T.id}' ORDER BY sort ASC, created ASC`;w=await this.deps.sql(N).catch(()=>[])||[]}if(Array.isArray(w)&&w.length>0){const N=new Set(u.map(j=>j.id)),F=w.filter(j=>j.id!==T.id&&!N.has(j.id));F.length>0&&(T.children=F.map(j=>{const J=r.get(j.id)||(j.ial?Ko(j.ial):{}),$=this.attrOverrides.get(j.id);return $&&Object.assign(J,$),{id:j.id,parent_id:j.parent_id||T.id,root_id:j.root_id||i,type:j.type,subType:j.subType,content:j.content||"",markdown:j.markdown||"",ial:J}}))}}T.children&&T.children.length>0&&await m(T.children,A+1)}};await m(u);const g=x=>{var A,T;for(const I of x)if(I.children&&I.children.length>0){g(I.children);for(const w of I.children)if(w.ial)for(const[N,F]of Object.entries(w.ial))N.startsWith("custom-slidev-")&&!((A=I.ial)!=null&&A[N])&&(I.ial||(I.ial={}),I.ial[N]=F);if(I.ial){for(const[w,N]of Object.entries(I.ial))if(w.startsWith("custom-slidev-"))for(const F of I.children)(F.type==="video"||F.type==="NodeVideo"||/<video\b/i.test(F.markdown||F.content||""))&&!((T=F.ial)!=null&&T[w])&&(F.ial||(F.ial={}),F.ial[w]=N)}}};g(u),Ku(u,x=>{const A={[mt]:x.layout};this.setBlockAttrOverride(x.blockId,A),(this.deps.setBlockAttrs||Et)(x.blockId,A).catch(I=>{console.warn("[DocumentCompiler] Failed to auto-tag superblock image layout:",I)})});const d=this.trackedListSuperBlocks.get(i)||[],b=qu(i,u,{tracked:d,onTagChange:x=>{this.setBlockAttrOverride(x.blockId,x.attrs),x.blockId===i&&Object.assign(e,x.attrs);const A=I=>{for(const w of I)w.id===x.blockId&&(w.ial||(w.ial={}),Object.assign(w.ial,x.attrs)),w.children&&w.children.length>0&&A(w.children)};A(u),(this.deps.setBlockAttrs||Et)(x.blockId,x.attrs).catch(I=>{console.warn("[DocumentCompiler] Failed to auto-tag list superblock attrs:",I)})}});this.trackedListSuperBlocks.set(i,b.newTracked);const f=new Set;for(const x of u){const A=x.markdown||x.content||"";if(A.includes("((")){const T=rc(A);for(const I of T)f.add(I.blockId)}}const v={};if(f.size>0){const x=Array.from(f).map(T=>`'${T}'`).join(","),A=await this.deps.sql(`SELECT id, content, markdown FROM blocks WHERE id IN (${x})`).catch(()=>[])||[];if(Array.isArray(A))for(const T of A)T.id&&(v[T.id]=T.markdown||T.content||"")}const k=this.deps.getBaseUrl?this.deps.getBaseUrl():"",S=Br(i,e,u,{baseUrl:k,refContentMap:v});try{const x=this.deps.getInlineStyles?await this.deps.getInlineStyles().catch(()=>null):null;S.customThemeCss=kn(x)}catch{S.customThemeCss=kn(null)}return S}catch(e){console.error("[DocumentCompilerService] Failed to compile document:",e);const n=Br(i,{},[],{});return n.customThemeCss=kn(null),n}}}const Lt=new nf;class Rs{constructor(i){xt(this,"devServerUrl","http://localhost:3030");xt(this,"isConnected",!1);xt(this,"lastSyncTime",null);i&&(this.devServerUrl=i)}getUrl(){return this.devServerUrl}setUrl(i){this.devServerUrl=i.replace(/\/+$/,"")}isServerConnected(){return this.isConnected}getLastSyncTime(){return this.lastSyncTime}async probeServer(i=1500){try{const e=new AbortController,n=setTimeout(()=>e.abort(),i),o=await fetch(this.devServerUrl,{method:"HEAD",mode:"no-cors",signal:e.signal}).catch(()=>null);return clearTimeout(n),this.isConnected=!!o,this.isConnected}catch{return this.isConnected=!1,!1}}buildStandardSlidevMarkdown(i){const e=i.config,n=["---",`theme: ${e.theme||"default"}`,`aspectRatio: "${e.aspectRatio||"16/9"}"`,`highlighter: ${e.highlighter||"shiki"}`,`transition: ${e.defaultTransition||"slide-left"}`];e.colorSchema&&e.colorSchema!=="auto"&&n.push(`colorSchema: ${e.colorSchema}`),n.push("drawings:","  persist: false","---","");const o=n.join(`
`),s=i.slides.map((r,a)=>{const c=r.frontmatter||{},u=[],m=a===0;c.layout&&c.layout!=="default"&&u.push(`layout: ${c.layout}`),c.transition&&u.push(`transition: ${c.transition}`),c.background&&u.push(`background: ${c.background}`),c.class&&u.push(`class: "${c.class}"`);let g="";u.length>0?g=m?"":`---
${u.join(`
`)}
---

`:m||(g=`---

`);let d="";if(c.layout==="two-cols"){const f=r.blocks.filter(x=>x.slot!=="right"),v=r.blocks.filter(x=>x.slot==="right"),k=f.map(x=>x.rawMarkdown||x.content||"").join(`

`),S=v.map(x=>x.rawMarkdown||x.content||"").join(`

`);d=`${k}

::right::

${S}`}else d=r.blocks.map(f=>f.rawMarkdown||f.content||"").join(`

`);let b="";return r.notes&&r.notes.trim()&&(b=`

<!--
${r.notes.trim()}
-->`),`${g}${d}${b}`}).join(`

`);let l="";return i.config.normalizeHeadingSizes&&(l=`

<style>
/* Specific Heading Normalization */
.slidev-layout:not(.cover) > :is(h1, h2, h3, h4, h5, h6):first-child {
  font-size: 1.7rem !important;
}
.two-cols-header-top :is(h1, h2, h3, h4, h5, h6),
.cols-header-top :is(h1, h2, h3, h4, h5, h6),
.layout-header-section :is(h1, h2, h3, h4, h5, h6) {
  font-size: 1.7rem !important;
}
:is(.two-cols-left, .two-cols-right, .col, .col-1, .col-2, .col-3, .three-cols-col) > :is(h1, h2, h3, h4, h5, h6):first-child {
  font-size: 1.3rem !important;
}
</style>`),`${o}${s}${l}
`}async syncToWorkspaceFile(i,e="/data/storage/petal/siyuan-slidev/slides.md",n){const o=this.buildStandardSlidevMarkdown(i);if(this.lastSyncTime=Date.now(),n)try{const s=typeof Blob<"u"?new Blob([o],{type:"text/markdown;charset=utf-8"}):Buffer.from(o,"utf-8");return await n(e,!1,s),{success:!0,path:e}}catch(s){return{success:!1,path:e,error:String(s)}}return{success:!0,path:e}}downloadSlidesMd(i,e="slides.md"){if(typeof window>"u"||typeof document>"u")return!1;const n=this.buildStandardSlidevMarkdown(i),o=new Blob([n],{type:"text/markdown;charset=utf-8"}),s=URL.createObjectURL(o),l=document.createElement("a");return l.href=s,l.download=e,document.body.appendChild(l),l.click(),document.body.removeChild(l),URL.revokeObjectURL(s),!0}}function of(){if(typeof window<"u"&&typeof window.require=="function")return window.require.bind(window);if(typeof globalThis<"u"&&typeof globalThis.require=="function")return globalThis.require.bind(globalThis);if(typeof require=="function")return require}function $e(t){const i=of();if(i)try{return i(t)}catch{try{const e=t.startsWith("node:")?t.slice(5):`node:${t}`;return i(e)}catch{}}}function zs(){var i;if(typeof window<"u"&&window.process)return window.process;const t=$e("process");return t&&t.versions?t:typeof process<"u"&&((i=process.versions)!=null&&i.node)?process:globalThis.process}function sa(){var i,e;const t=zs();if(t&&((i=t.versions)!=null&&i.node))return!0;if(typeof window<"u"&&window.siyuan){const n=$e("child_process");if(n&&typeof n.spawn=="function")return!0}return!!(typeof process<"u"&&((e=process.versions)!=null&&e.node))}function Dn(){const t=zs();if(t!=null&&t.platform)return t.platform;if(typeof process<"u"&&process.platform)return process.platform;const i=$e("os");if(i&&typeof i.platform=="function")return i.platform();if(typeof navigator<"u"){const e=navigator.userAgent.toLowerCase();if(e.includes("win"))return"win32";if(e.includes("mac"))return"darwin";if(e.includes("linux"))return"linux"}return"web"}function ra(){var n,o;const t=zs(),i={...(t==null?void 0:t.env)||{}};if(Dn()==="win32"){const s=["C:\\Program Files\\nodejs","C:\\Program Files (x86)\\nodejs",(n=t==null?void 0:t.env)!=null&&n.APPDATA?`${t.env.APPDATA}\\npm`:"",(o=t==null?void 0:t.env)!=null&&o.USERPROFILE?`${t.env.USERPROFILE}\\AppData\\Roaming\\npm`:""].filter(Boolean),l=Object.keys(i).find(c=>c.toLowerCase()==="path")||"PATH",a=(i[l]||"").split(";").filter(Boolean);for(const c of s)c&&!a.some(u=>u.toLowerCase()===c.toLowerCase())&&a.push(c);i[l]=a.join(";")}return i}function hs(t){var e,n,o;if(!t)return"";if(/^[a-zA-Z]:[/\\]/.test(t))return t.replace(/\\/g,"/");let i="";if(typeof window<"u"&&((o=(n=(e=window.siyuan)==null?void 0:e.config)==null?void 0:n.system)!=null&&o.dataDir)&&(i=window.siyuan.config.system.dataDir.replace(/\\/g,"/")),i&&t.startsWith("/data/")){const s=t.slice(6);return`${i}/${s}`.replace(/\\/g,"/")}return t}function sf(){const t=$e("os"),i=$e("path");if(t&&typeof t.tmpdir=="function"){const e=t.tmpdir();return i&&typeof i.join=="function"?i.join(e,"siyuan-slidev-pro").replace(/\\/g,"/"):`${e}/siyuan-slidev-pro`.replace(/\\/g,"/")}return"/data/storage/petal/siyuan-slidev/pro-workspace"}class Ns{constructor(i){xt(this,"runner");this.runner=i||Ns.defaultRunner}static async defaultRunner(i,e){var n;try{let o=(n=$e("child_process"))==null?void 0:n.execFile;if(!o){const a=await import("node:child_process").catch(()=>({}));o=a==null?void 0:a.execFile}if(!o)return{code:-1,stdout:"",stderr:"child_process execFile not available"};const l=Dn()==="win32",r=ra();return await new Promise(a=>{o(i,e,{timeout:5e3,shell:l,env:r},(c,u,m)=>{a({code:c?c.code||1:0,stdout:u?String(u).trim():"",stderr:m?String(m).trim():""})})})}catch(o){return{code:-1,stdout:"",stderr:String(o)}}}async detect(){const i=sa(),e=Dn();if(!i)return{hasNode:!1,hasSlidevCli:!1,platform:"browser",isDesktop:!1,error:"当前处于纯前端浏览器或移动端环境，无 Node.js 运行时支撑"};let n=!1,o,s=!1,l;try{const r=await this.runner("node",["-v"]);r.code===0&&r.stdout.startsWith("v")&&(n=!0,o=r.stdout)}catch{}if(n){try{const r=e==="win32"?"slidev.cmd":"slidev",a=await this.runner(r,["--version"]);a.code===0&&a.stdout&&(s=!0,l=a.stdout)}catch{}if(!s)try{const r=e==="win32"?"npx.cmd":"npx",a=await this.runner(r,["@slidev/cli","--version"]);a.code===0&&a.stdout&&(s=!0,l=a.stdout)}catch{}}return{hasNode:n,nodeVersion:o,hasSlidevCli:s,slidevVersion:l,platform:e,isDesktop:i}}}class rf{constructor(){xt(this,"iframe",null);xt(this,"isReady",!1);xt(this,"pageChangedHandlers",[]);xt(this,"readyHandlers",[]);xt(this,"currentState",{no:1,clicks:0,total:1});this.handleWindowMessage=this.handleWindowMessage.bind(this)}getCurrentState(){return{...this.currentState}}attach(i){this.detach(),this.iframe=i,this.isReady=!1,typeof window<"u"&&window.addEventListener("message",this.handleWindowMessage)}detach(){typeof window<"u"&&window.removeEventListener("message",this.handleWindowMessage),this.iframe=null,this.isReady=!1}postMessage(i,e){var o;if(!((o=this.iframe)!=null&&o.contentWindow))return;const n={target:"slidev",sender:"siyuan",type:i,...e};try{this.iframe.contentWindow.postMessage(n,"*")}catch(s){console.warn("[NativeSlidevBridge] postMessage error:",s)}}navigateToPage(i){this.postMessage("navigate",{no:i})}next(){this.postMessage("next")}prev(){this.postMessage("prev")}nextClick(){this.postMessage("next-click")}prevClick(){this.postMessage("prev-click")}onPageChanged(i){return this.pageChangedHandlers.push(i),()=>{this.pageChangedHandlers=this.pageChangedHandlers.filter(e=>e!==i)}}onReady(i){return this.readyHandlers.push(i),()=>{this.readyHandlers=this.readyHandlers.filter(e=>e!==i)}}handleWindowMessage(i){const e=i.data;if(!(!e||e.target!=="slidev")){if(!this.isReady){this.isReady=!0;for(const n of this.readyHandlers)n()}if(e.type==="update-state"&&e.navState){const n=e.navState;this.currentState={no:n.no??this.currentState.no,clicks:n.clicks??this.currentState.clicks,total:n.total??this.currentState.total,hasNext:n.hasNext,hasPrev:n.hasPrev};for(const o of this.pageChangedHandlers)o(this.currentState.no,this.currentState.total||1,this.currentState)}else if(e.type==="navigate"&&typeof e.no=="number"){this.currentState.no=e.no;for(const n of this.pageChangedHandlers)n(e.no,this.currentState.total||1,this.currentState)}}}}class lf{constructor(i){xt(this,"childProcess",null);xt(this,"activePort",null);xt(this,"isRunning",!1);xt(this,"defaultPort");xt(this,"maxPortRetries");xt(this,"probeTimeoutMs");xt(this,"customSpawner");xt(this,"customPortChecker");this.defaultPort=(i==null?void 0:i.defaultPort)||3030,this.maxPortRetries=(i==null?void 0:i.maxPortRetries)||20,this.probeTimeoutMs=(i==null?void 0:i.probeTimeoutMs)||1e4,this.customSpawner=i==null?void 0:i.customSpawner,this.customPortChecker=i==null?void 0:i.customPortChecker}getActivePort(){return this.activePort}getIsRunning(){return this.isRunning}async isPortAvailable(i){if(this.customPortChecker)return this.customPortChecker(i);try{let e=$e("net");return e||(e=await import("node:net").catch(()=>({}))),e!=null&&e.createServer?await new Promise(n=>{const o=e.createServer();o.once("error",()=>n(!1)),o.once("listening",()=>{o.close(()=>n(!0))}),o.listen(i,"127.0.0.1")}):!0}catch{return!0}}async allocPort(i){const e=i||this.defaultPort;for(let n=0;n<this.maxPortRetries;n++){const o=e+n;if(await this.isPortAvailable(o))return o}return e}async pollServerReady(i,e=8e3,n=300){const o=Date.now();for(;Date.now()-o<e;){try{const s=new AbortController,l=setTimeout(()=>s.abort(),n),r=await fetch(i,{method:"HEAD",mode:"no-cors",signal:s.signal}).catch(()=>null);if(clearTimeout(l),r)return!0}catch{}await new Promise(s=>setTimeout(s,n))}return!1}async startServer(i,e){var a,c;if(this.isRunning&&this.activePort)return{success:!0,port:this.activePort,url:`http://localhost:${this.activePort}?embedded=true`};const n=await this.allocPort(e);this.activePort=n;const s=Dn()==="win32"?"npx.cmd":"npx",l=hs(i),r=["@slidev/cli",l,"--port",String(n),"--no-open"];try{if(this.customSpawner)this.childProcess=this.customSpawner(s,r,{detached:!1});else{let m=(a=$e("child_process"))==null?void 0:a.spawn;if(!m){const b=await import("node:child_process").catch(()=>({}));m=b==null?void 0:b.spawn}if(!m)throw new Error("child_process spawn not available in current runtime");const g=l.includes("/")||l.includes("\\")?l.replace(/[/\\][^/\\]+$/,""):void 0,d=ra();this.childProcess=m(s,r,{cwd:g,detached:!1,shell:!0,env:{...d,FORCE_COLOR:"1"}})}this.isRunning=!0,(c=this.childProcess)!=null&&c.on&&this.childProcess.on("exit",()=>{this.isRunning=!1,this.activePort=null,this.childProcess=null});const u=`http://localhost:${n}`;return!this.customSpawner&&!await this.pollServerReady(u,this.probeTimeoutMs)?(this.stopServer(),{success:!1,port:n,url:"",error:`Slidev DevServer 启动超时 (未在 ${this.probeTimeoutMs}ms 内响应端口 ${n})`}):{success:!0,port:n,url:`${u}?embedded=true`}}catch(u){return this.stopServer(),{success:!1,port:n,url:"",error:`唤起 Slidev 进程失败: ${String(u)}`}}}stopServer(){var i;if(this.childProcess){try{if(this.childProcess.kill("SIGTERM"),Dn()==="win32"&&this.childProcess.pid&&!this.customSpawner){const n=(i=$e("child_process"))==null?void 0:i.exec;n?n(`taskkill /pid ${this.childProcess.pid} /T /F`,()=>{}):import("node:child_process").then(({exec:o})=>{var s;o(`taskkill /pid ${(s=this.childProcess)==null?void 0:s.pid} /T /F`,()=>{})}).catch(()=>{})}}catch{}this.childProcess=null}this.isRunning=!1,this.activePort=null}}class Fs{constructor(){xt(this,"iframe",null);xt(this,"isReady",!1);xt(this,"pendingMessages",[]);xt(this,"slideChangedHandlers",[]);xt(this,"blockClickedHandlers",[]);xt(this,"openInEditorHandlers",[]);xt(this,"clientReadyHandlers",[]);xt(this,"openPeekDrawerHandlers",[]);xt(this,"toggleFullscreenHandlers",[]);this.handleWindowMessage=this.handleWindowMessage.bind(this)}attach(i){this.detach(),this.iframe=i,this.isReady=!1,typeof window<"u"&&window.addEventListener("message",this.handleWindowMessage)}detach(){typeof window<"u"&&window.removeEventListener("message",this.handleWindowMessage),this.iframe=null,this.isReady=!1,this.pendingMessages=[]}postMessage(i,e){var o;const n={source:"siyuan-slidev-host",action:i,payload:e};if(!((o=this.iframe)!=null&&o.contentWindow)||!this.isReady){this.pendingMessages.push(n);return}try{this.iframe.contentWindow.postMessage(n,"*")}catch(s){console.warn("[WebSandboxBridge] postMessage error:",s)}}updateSlides(i,e,n,o){this.postMessage("UPDATE_SLIDES",{slides:i,config:e,fullMarkdown:n,customThemeCss:o})}navigatePage(i){this.postMessage("NAVIGATE_PAGE",{pageIndex:i})}highlightElement(i){this.postMessage("HIGHLIGHT_ELEMENT",{targetBlockId:i})}nextStep(){this.postMessage("NEXT_STEP",{})}prevStep(){this.postMessage("PREV_STEP",{})}freezeKeyboardNav(i){this.postMessage("FREEZE_KEYBOARD_NAV",{frozen:i})}onSlideChanged(i){return this.slideChangedHandlers.push(i),()=>{this.slideChangedHandlers=this.slideChangedHandlers.filter(e=>e!==i)}}onBlockClicked(i){return this.blockClickedHandlers.push(i),()=>{this.blockClickedHandlers=this.blockClickedHandlers.filter(e=>e!==i)}}onOpenInEditor(i){return this.openInEditorHandlers.push(i),()=>{this.openInEditorHandlers=this.openInEditorHandlers.filter(e=>e!==i)}}onOpenPeekDrawer(i){return this.openPeekDrawerHandlers.push(i),()=>{this.openPeekDrawerHandlers=this.openPeekDrawerHandlers.filter(e=>e!==i)}}onRequestToggleFullscreen(i){return this.toggleFullscreenHandlers.push(i),()=>{this.toggleFullscreenHandlers=this.toggleFullscreenHandlers.filter(e=>e!==i)}}onClientReady(i){return this.clientReadyHandlers.push(i),()=>{this.clientReadyHandlers=this.clientReadyHandlers.filter(e=>e!==i)}}handleWindowMessage(i){var n;const e=i.data;if(!(!e||e.source!=="siyuan-slidev-client"))switch(e.action){case"CLIENT_READY":for(this.isReady=!0;this.pendingMessages.length>0;){const o=this.pendingMessages.shift();o&&((n=this.iframe)!=null&&n.contentWindow)&&this.iframe.contentWindow.postMessage(o,"*")}for(const o of this.clientReadyHandlers)o();break;case"SLIDE_CHANGED":if(e.payload.currentPage!==void 0)for(const o of this.slideChangedHandlers)o(e.payload.currentPage,e.payload.totalPages||1,e.payload.currentBlockId||"");break;case"BLOCK_CLICKED":if(e.payload.clickedBlockId)for(const o of this.blockClickedHandlers)o(e.payload.clickedBlockId,e.payload.currentPage||1);break;case"OPEN_IN_EDITOR":if(e.payload.blockId||e.payload.clickedBlockId){const o=e.payload.blockId||e.payload.clickedBlockId||"";for(const s of this.openInEditorHandlers)s(o,e.payload.currentPage||1)}break;case"OPEN_PEEK_DRAWER":if(e.payload.peekType){const o=e.payload.blockId||e.payload.url||"",s={peekType:e.payload.peekType,target:o,title:e.payload.title};for(const l of this.openPeekDrawerHandlers)l(s)}break;case"REQUEST_TOGGLE_FULLSCREEN":for(const o of this.toggleFullscreenHandlers)o();break}}}const la={"snippets/external.ts":`// Inside ./snippets/external.ts
// #region snippet
export function emptyArray<T>(length: number) {
  return Array.from<T>({ length })
}
// #endregion snippet

export function sayHello() {
  console.log('Hello from snippets/external.ts')
}
`},af=`<script setup lang="ts">
import { computed, useSlots } from 'vue'

const props = defineProps({
  layoutRatio: {
    type: String,
    default: '',
  },
  cols: {
    type: [Number, String],
    default: 0,
  },
})

const slots = useSlots()

const detectedColsCount = computed(() => {
  const explicitCols = Number(props.cols)
  if (explicitCols >= 2 && explicitCols <= 6) return explicitCols
  const r = (props.layoutRatio || '').trim()
  if (r.includes(':')) {
    const parts = r.split(':').map(p => parseFloat(p.trim())).filter(n => !isNaN(n) && n > 0)
    if (parts.length >= 2) return Math.min(parts.length, 6)
  }
  const tokens = r.split(/\\s+/).filter(Boolean)
  if (tokens.length >= 2) return Math.min(tokens.length, 6)
  for (let i = 6; i >= 3; i--) {
    if (slots[\`col-\${i}\`]) return i
  }
  if (slots['col-2'] || slots['right']) return 2
  return 2
})

const gridStyle = computed(() => {
  const r = props.layoutRatio || ''
  if (r) {
    if (r.includes(':')) {
      const parts = r.split(':').map(p => parseFloat(p.trim())).filter(n => !isNaN(n) && n > 0)
      if (parts.length >= 2) {
        return { gridTemplateColumns: parts.map(n => \`\${n}fr\`).join(' ') }
      }
    }
    const tokens = r.split(/\\s+/).filter(Boolean)
    if (tokens.length >= 2) {
      return { gridTemplateColumns: tokens.join(' ') }
    }
  }
  return { gridTemplateColumns: \`repeat(\${detectedColsCount.value}, minmax(0, 1fr))\` }
})
<\/script>

<template>
  <div class="slidev-layout cols-header w-full h-full flex flex-col">
    <div class="header-section mb-4 w-full">
      <slot />
    </div>
    <div class="grid gap-6 flex-1 items-stretch" :style="gridStyle">
      <div v-if="detectedColsCount >= 1" class="col-1 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-1"><slot name="left" /></slot>
      </div>
      <div v-if="detectedColsCount >= 2" class="col-2 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-2"><slot v-if="detectedColsCount === 2" name="right" /></slot>
      </div>
      <div v-if="detectedColsCount >= 3" class="col-3 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-3" />
      </div>
      <div v-if="detectedColsCount >= 4" class="col-4 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-4" />
      </div>
      <div v-if="detectedColsCount >= 5" class="col-5 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-5" />
      </div>
      <div v-if="detectedColsCount >= 6" class="col-6 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-6" />
      </div>
    </div>
  </div>
</template>
`,cf=`<script setup lang="ts">
import { computed } from 'vue'

const props = defineProps({
  layoutRatio: {
    type: String,
    default: '',
  },
})

const gridStyle = computed(() => {
  const r = props.layoutRatio || ''
  if (!r) return {}
  if (r.includes(':')) {
    const parts = r.split(':').map(p => parseFloat(p.trim())).filter(n => !isNaN(n) && n > 0)
    if (parts.length >= 2) {
      return { gridTemplateColumns: parts.map(n => \`\${n}fr\`).join(' ') }
    }
  }
  const tokens = r.split(/\\s+/).filter(Boolean)
  if (tokens.length >= 2) {
    return { gridTemplateColumns: tokens.join(' ') }
  }
  return {}
})
<\/script>

<template>
  <div class="slidev-layout three-cols-header w-full h-full flex flex-col">
    <div class="header-section mb-4 w-full">
      <slot />
    </div>
    <div class="grid gap-6 flex-1 items-stretch" :class="gridStyle.gridTemplateColumns ? '' : 'grid-cols-3'" :style="gridStyle">
      <div class="col-1 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-1" />
      </div>
      <div class="col-2 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-2" />
      </div>
      <div class="col-3 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-3" />
      </div>
    </div>
  </div>
</template>
`,df=`<script setup lang="ts">
import { useSlots } from 'vue'

const slots = useSlots()
<\/script>

<template>
  <div class="slidev-layout clover w-full h-full flex flex-col">
    <div class="header-section mb-4 w-full">
      <slot />
    </div>
    <div class="grid grid-cols-2 grid-rows-2 gap-6 flex-1 items-stretch">
      <div class="col-1 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-1" />
      </div>
      <div class="col-2 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-2" />
      </div>
      <div class="col-3 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-3" />
      </div>
      <div class="col-4 min-w-0 h-full max-h-full overflow-hidden break-words [overflow-wrap:break-word] [word-break:break-word]">
        <slot name="col-4" />
      </div>
    </div>
  </div>
</template>
`,uf=`// Auto-generated by SiYuan Slidev Studio
export default function() {
  if (typeof window === 'undefined') return
  window.addEventListener('click', (e: MouseEvent) => {
    const target = e.target as HTMLElement | null
    if (!target || !target.closest) return

    const refEl = target.closest('[data-ref-id]')
    if (refEl) {
      const blockId = refEl.getAttribute('data-ref-id')
      if (blockId) {
        e.preventDefault()
        e.stopPropagation()
        window.parent.postMessage({
          source: 'siyuan-slidev-client',
          action: 'OPEN_PEEK_DRAWER',
          payload: { peekType: 'siyuan', blockId, title: (refEl.innerText || refEl.title || '').trim() }
        }, '*')
        return
      }
    }

    const linkEl = target.closest('a') as HTMLAnchorElement | null
    if (linkEl) {
      const href = linkEl.getAttribute('href') || ''
      if (href.startsWith('siyuan://blocks/')) {
        e.preventDefault()
        e.stopPropagation()
        const cleanBlockId = href.replace('siyuan://blocks/', '').split('?')[0]
        window.parent.postMessage({
          source: 'siyuan-slidev-client',
          action: 'OPEN_PEEK_DRAWER',
          payload: { peekType: 'siyuan', blockId: cleanBlockId, title: (linkEl.innerText || linkEl.title || '').trim() }
        }, '*')
      } else if (/^https?:\\/\\//i.test(href)) {
        e.preventDefault()
        e.stopPropagation()
        window.parent.postMessage({
          source: 'siyuan-slidev-client',
          action: 'OPEN_PEEK_DRAWER',
          payload: { peekType: 'web', url: href, title: (linkEl.innerText || linkEl.title || '').trim() }
        }, '*')
      }
    }
  }, true)
}
`,ff=`${ps}

/* Auto-generated by SiYuan Slidev Studio */
.slidev-ref-tag,
a.slidev-ref-tag {
  display: inline-flex;
  align-items: center;
  background: color-mix(in srgb, var(--slidev-theme-primary, #10b981) 12%, transparent);
  color: var(--slidev-theme-primary, #10b981);
  border-radius: 4px;
  padding: 2px 8px;
  font-size: 0.88em;
  text-decoration: none;
  border: 1px solid color-mix(in srgb, var(--slidev-theme-primary, #10b981) 25%, transparent);
  cursor: pointer;
  transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
  user-select: none;
}

.slidev-ref-tag:hover,
a.slidev-ref-tag:hover {
  background: color-mix(in srgb, var(--slidev-theme-primary, #10b981) 22%, transparent);
  color: var(--slidev-theme-primary, #10b981);
  border-color: color-mix(in srgb, var(--slidev-theme-primary, #10b981) 55%, transparent);
  transform: translateY(-1px);
  box-shadow: 0 2px 8px color-mix(in srgb, var(--slidev-theme-primary, #10b981) 20%, transparent);
}

.slidev-block-ref {
  display: block;
  padding: 10px 14px;
  background: color-mix(in srgb, var(--slidev-theme-primary, #10b981) 8%, transparent);
  border-left: 3px solid var(--slidev-theme-primary, #10b981);
  border-radius: 0 6px 6px 0;
  margin: 8px 0;
  cursor: pointer;
  transition: background 0.2s ease;
}

.slidev-block-ref:hover {
  background: color-mix(in srgb, var(--slidev-theme-primary, #10b981) 15%, transparent);
}

/* 代码块自动换行与无横向滚动条 */
pre,
pre code {
  white-space: pre-wrap !important;
  word-break: break-all !important;
  overflow-wrap: anywhere !important;
  overflow-x: hidden !important;
  overflow-y: auto !important;
  max-width: 100% !important;
  box-sizing: border-box !important;
}

/* 弱提示滚动条样式 */
* {
  scrollbar-width: thin;
}
html:not(.dark) * {
  scrollbar-color: rgba(0, 0, 0, 0.15) transparent;
}
html.dark * {
  scrollbar-color: rgba(255, 255, 255, 0.20) transparent;
}
*::-webkit-scrollbar {
  width: 4px;
  height: 4px;
}
*::-webkit-scrollbar-track {
  background: transparent;
}
html:not(.dark) *::-webkit-scrollbar-thumb {
  background: rgba(0, 0, 0, 0.15);
  border-radius: 2px;
}
html:not(.dark) *:hover::-webkit-scrollbar-thumb,
html:not(.dark) *::-webkit-scrollbar-thumb:hover {
  background: rgba(0, 0, 0, 0.35);
}
html.dark *::-webkit-scrollbar-thumb {
  background: rgba(255, 255, 255, 0.20);
  border-radius: 2px;
}
html.dark *:hover::-webkit-scrollbar-thumb,
html.dark *::-webkit-scrollbar-thumb:hover {
  background: rgba(255, 255, 255, 0.45);
}

/* 多媒体（GIF动图、静态图片、MP4视频）最大化自适应且不超出视口：顶部对齐，横向居中 */
.slidev-layout img,
.slidev-layout video {
  max-width: 100% !important;
  max-height: 100% !important;
  width: auto;
  height: auto;
  object-fit: contain !important;
}
.three-cols-header video,
.two-cols-header video,
.grid-cols-3 video,
.grid-cols-2 video,
.col-1 video,
.col-2 video,
.col-3 video {
  width: auto !important;
  height: auto !important;
  max-width: 100% !important;
  max-height: 100% !important;
  object-fit: contain !important;
  display: block !important;
  margin: 0 auto !important;
}
.slide-list-media {
  display: flex !important;
  flex-direction: column !important;
  align-items: center !important;
  justify-content: flex-start !important;
  margin-top: 4px !important;
  margin-bottom: 4px !important;
  width: 100% !important;
  max-width: 100% !important;
  height: 100% !important;
  max-height: 100% !important;
  flex: 1 1 0% !important;
  overflow: hidden !important;
}
.slide-list-media img,
.slide-list-media video,
.slide-list-media .list-item-gif {
  width: auto !important;
  height: auto !important;
  max-width: 100% !important;
  max-height: 100% !important;
  object-fit: contain !important;
  border-radius: 6px !important;
  box-shadow: 0 3px 12px rgba(0, 0, 0, 0.14) !important;
  display: block !important;
  margin: 0 auto !important;
}
.slide-video-container {
  display: flex !important;
  flex-direction: column !important;
  justify-content: flex-start !important;
  align-items: center !important;
  width: 100% !important;
  max-height: 100% !important;
  margin: 6px 0 !important;
}
.slide-video-player {
  max-width: 100% !important;
  max-height: 100% !important;
  object-fit: contain !important;
  border-radius: 8px !important;
}

/* 两栏与多栏（超级块分栏）布局：紧凑自然行距，子列表保留圆点与层级缩进 */
.cols-header ul,
.three-cols-header ul,
.two-cols-header ul,
.two-cols ul,
.col-1 ul,
.col-2 ul,
.col-3 ul,
.col-4 ul,
.col-5 ul,
.col-6 ul,
.grid-cols-2 ul,
.grid-cols-3 ul {
  list-style: disc !important;
  list-style-type: disc !important;
  padding-left: 1.25em !important;
  margin-left: 0 !important;
  margin-top: 0 !important;
  margin-bottom: 8px !important;
  flex: 0 0 auto !important;
  height: auto !important;
  display: block !important;
}
.cols-header ol,
.three-cols-header ol,
.two-cols-header ol,
.two-cols ol,
.col-1 ol,
.col-2 ol,
.col-3 ol,
.col-4 ol,
.col-5 ol,
.col-6 ol,
.grid-cols-2 ol,
.grid-cols-3 ol {
  list-style: decimal !important;
  list-style-type: decimal !important;
  padding-left: 1.25em !important;
  margin-left: 0 !important;
  margin-top: 0 !important;
  margin-bottom: 8px !important;
  flex: 0 0 auto !important;
  height: auto !important;
  display: block !important;
}
.cols-header li,
.three-cols-header li,
.two-cols-header li,
.two-cols li,
.col-1 li,
.col-2 li,
.col-3 li,
.col-4 li,
.col-5 li,
.col-6 li,
.grid-cols-2 li,
.grid-cols-3 li {
  padding-left: 0.2em !important;
  margin-left: 0 !important;
  margin-bottom: 6px !important;
  flex: 0 0 auto !important;
  height: auto !important;
  display: list-item !important;
  line-height: 1.6 !important;
}
.cols-header ul ul,
.three-cols-header ul ul,
.two-cols-header ul ul,
.two-cols ul ul,
.col-1 ul ul,
.col-2 ul ul,
.col-3 ul ul,
.col-4 ul ul,
.col-5 ul ul,
.col-6 ul ul {
  list-style: circle !important;
  list-style-type: circle !important;
  padding-left: 1.25em !important;
  margin-top: 4px !important;
  margin-bottom: 4px !important;
}

/* 列表项内嵌标题与说明排版 */
.slide-list-item-title,
li > h1,
li > h2,
li > h3,
li > h4,
li > h5,
li > h6 {
  margin-top: 2px !important;
  margin-bottom: 6px !important;
  line-height: 1.35 !important;
  font-weight: 700 !important;
}
li > h1 { font-size: 1.6rem !important; }
li > h2 { font-size: 1.4rem !important; }
li > h3 { font-size: 1.22rem !important; }
li > h4 { font-size: 1.1rem !important; }
.slide-list-item-desc,
li > p {
  margin-top: 4px !important;
  margin-bottom: 6px !important;
  font-size: 1.05rem;
  line-height: 1.55;
  opacity: 0.92;
}
`;function pf(t){var o;const i=[],e=/^[ \t]*<<<[ \t]+(?:@\/|\.\/|)([^\s#]+)(?:#[^\s]+)?/gm;let n;for(;(n=e.exec(t))!==null;){const s=(o=n[1])==null?void 0:o.trim();s&&!i.includes(s)&&i.push(s)}return i}class hf{constructor(i){xt(this,"workspacePath");xt(this,"slidesFileName");xt(this,"cliBridge",new Rs);const e=sf();!(i!=null&&i.workspacePath)||i.workspacePath.includes("/data/storage/petal/siyuan-slidev/pro-workspace")?this.workspacePath=e:this.workspacePath=i.workspacePath,this.slidesFileName=(i==null?void 0:i.slidesFileName)||"slides.md"}getWorkspacePath(){return this.workspacePath}getSlidesPath(){return`${this.workspacePath}/${this.slidesFileName}`}generatePackageJson(i="default"){const e={name:"siyuan-slidev-pro-workspace",type:"module",private:!0,scripts:{dev:"slidev --port 3030",build:"slidev build"},dependencies:{"@slidev/cli":"^53.0.0","@slidev/theme-default":"latest"}};return i&&i!=="default"&&(e.dependencies[`@slidev/theme-${i}`]="latest"),JSON.stringify(e,null,2)}buildSlidesMarkdown(i){return this.cliBridge.buildStandardSlidevMarkdown(i)}async scaffold(i,e){const n=this.buildSlidesMarkdown(i),o=this.generatePackageJson(i.config.theme),s=this.getSlidesPath(),l=`${this.workspacePath}/package.json`,r=hs(s),a=hs(l),c=pf(n);c.includes("snippets/external.ts")||c.push("snippets/external.ts");const u=new Map;for(const x of c){const A=la[x]||`// Auto-generated snippet placeholder for SiYuan Slidev
// #region snippet
// ${x}
// #endregion snippet
`;u.set(x,A)}i.slides.some(x=>{var A;return((A=x.frontmatter)==null?void 0:A.layout)==="cols-header"})&&u.set("layouts/cols-header.vue",af),i.slides.some(x=>{var A;return((A=x.frontmatter)==null?void 0:A.layout)==="three-cols-header"})&&u.set("layouts/three-cols-header.vue",cf),i.slides.some(x=>{var A;return((A=x.frontmatter)==null?void 0:A.layout)==="clover"})&&u.set("layouts/clover.vue",df),u.set("setup/root.ts",uf),u.set("styles/index.css",ff);const b=$e("fs"),f=$e("path");let v=!1;const k=f!=null&&f.dirname?f.dirname(r):"",S=/^[a-zA-Z]:[/\\]/.test(r)||r.includes("siyuan-slidev-pro");if(b&&f&&S)try{b.existsSync(k)||b.mkdirSync(k,{recursive:!0}),b.writeFileSync(a,o,"utf-8"),b.writeFileSync(r,n,"utf-8");for(const[x,A]of u.entries()){const T=f.join(k,x),I=f.dirname(T);b.existsSync(I)||b.mkdirSync(I,{recursive:!0}),b.existsSync(T)||b.writeFileSync(T,A,"utf-8")}v=!0}catch{}if(!v&&e)try{const x=typeof Blob<"u"?new Blob([n],{type:"text/markdown;charset=utf-8"}):Buffer.from(n,"utf-8"),A=typeof Blob<"u"?new Blob([o],{type:"application/json;charset=utf-8"}):Buffer.from(o,"utf-8");await e(l,!1,A),await e(s,!1,x);for(const[T,I]of u.entries()){const w=`${this.workspacePath}/${T}`,N=typeof Blob<"u"?new Blob([I],{type:"text/plain;charset=utf-8"}):Buffer.from(I,"utf-8");await e(w,!1,N).catch(()=>{})}return{success:!0,slidesPath:s,physicalSlidesPath:r,packageJsonPath:l}}catch(x){return{success:!1,slidesPath:s,physicalSlidesPath:r,packageJsonPath:l,error:String(x)}}return{success:!0,slidesPath:s,physicalSlidesPath:r,packageJsonPath:l}}}class mf{constructor(){xt(this,"mode","web-sandbox");xt(this,"webBridge");xt(this,"cliBridge");xt(this,"nativeBridge");xt(this,"processManager");xt(this,"scaffolder");xt(this,"envDetector");this.webBridge=new Fs,this.cliBridge=new Rs,this.nativeBridge=new rf,this.processManager=new lf,this.scaffolder=new hf,this.envDetector=new Ns}getMode(){return this.mode}setMode(i){this.mode=i}async startProMode(i,e){if(!(await this.envDetector.detect()).hasNode)return{success:!1,url:"",error:"当前系统未检测到 Node.js 环境，无法拉起官方 Slidev CLI，建议继续使用内置高保真引擎"};const o=await this.scaffolder.scaffold(i,e);if(!o.success)return{success:!1,url:"",error:`初始化 Slidev 临时工作空间失败: ${o.error}`};const s=o.physicalSlidesPath||o.slidesPath,l=await this.processManager.startServer(s);return l.success?(this.mode="pro-cli",{success:!0,url:l.url,port:l.port}):{success:!1,url:"",error:l.error}}stopProMode(){this.processManager.stopServer(),this.mode="web-sandbox"}destroy(){this.webBridge.detach(),this.nativeBridge.detach(),this.processManager.stopServer()}}const gf={class:"slidev-icon",style:{fill:"none !important"},viewBox:"0 0 24 24",stroke:"currentColor","stroke-width":"1.75","stroke-linecap":"round","stroke-linejoin":"round","aria-hidden":"true"},vf={key:0},bf={key:1},yf={key:2},kf={key:3},wf={key:4},xf={key:5},Sf={key:6},_f={key:7},Cf={key:8},$f={key:9},If={key:10},Af={key:11},Bf={key:12},Tf={key:13},Ef={key:14},Mf={key:15},Lf={key:16},Df={key:17},Pf={key:18},Of={key:19},Rf={key:20},zf={key:21},Nf={key:22},Ff={key:23},Hf={key:24},jf={key:25},Uf={key:26},Wf={key:27},Vf={key:28},qf={key:29},Kf={key:30},Gf={key:31},Zf={key:32},Yf={key:33},Jf={key:34},Xf={key:35},Qf={key:36},tp={key:37},ep={key:38},ip={key:39},np={key:40},op={key:41},sp={key:42},rp={key:43},lp={key:44},ap={key:45},cp={key:46},dp={key:47},up={key:48},fp={key:49},pp={key:50},hp={key:51},mp={key:52},gp={key:53},vp={key:54},bp={key:55},yp={key:56},kp={key:57},wp={key:58},xp={key:59},Sp={key:60},_p={key:61},Cp={key:62},$p={key:63},Ip={key:64},Ap=_e({__name:"SlidevIcon",props:{name:{}},setup(t){return(i,e)=>(ot(),st("svg",gf,[t.name==="fullscreen"||t.name==="maximize"?(ot(),st("g",vf,[...e[0]||(e[0]=[h("polyline",{points:"15 3 21 3 21 9"},null,-1),h("polyline",{points:"9 21 3 21 3 15"},null,-1),h("polyline",{points:"21 15 21 21 15 21"},null,-1),h("polyline",{points:"3 9 3 3 9 3"},null,-1)])])):t.name==="minimize"?(ot(),st("g",bf,[...e[1]||(e[1]=[h("polyline",{points:"4 14 10 14 10 20"},null,-1),h("polyline",{points:"20 10 14 10 14 4"},null,-1),h("line",{x1:"14",y1:"10",x2:"21",y2:"3"},null,-1),h("line",{x1:"3",y1:"21",x2:"10",y2:"14"},null,-1)])])):t.name==="close"||t.name==="x"?(ot(),st("g",yf,[...e[2]||(e[2]=[h("line",{x1:"18",y1:"6",x2:"6",y2:"18"},null,-1),h("line",{x1:"6",y1:"6",x2:"18",y2:"18"},null,-1)])])):t.name==="edit"?(ot(),st("g",kf,[...e[3]||(e[3]=[h("path",{d:"M12 20h9"},null,-1),h("path",{d:"M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z"},null,-1)])])):t.name==="eye"?(ot(),st("g",wf,[...e[4]||(e[4]=[h("path",{d:"M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"},null,-1),h("circle",{cx:"12",cy:"12",r:"3"},null,-1)])])):t.name==="external-link"||t.name==="window"?(ot(),st("g",xf,[...e[5]||(e[5]=[h("path",{d:"M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"},null,-1),h("polyline",{points:"15 3 21 3 21 9"},null,-1),h("line",{x1:"10",y1:"14",x2:"21",y2:"3"},null,-1)])])):t.name==="arrow-left"?(ot(),st("g",Sf,[...e[6]||(e[6]=[h("line",{x1:"19",y1:"12",x2:"5",y2:"12"},null,-1),h("polyline",{points:"12 19 5 12 12 5"},null,-1)])])):t.name==="arrow-right"?(ot(),st("g",_f,[...e[7]||(e[7]=[h("line",{x1:"5",y1:"12",x2:"19",y2:"12"},null,-1),h("polyline",{points:"12 5 19 12 12 19"},null,-1)])])):t.name==="plus"?(ot(),st("g",Cf,[...e[8]||(e[8]=[h("line",{x1:"12",y1:"5",x2:"12",y2:"19"},null,-1),h("line",{x1:"5",y1:"12",x2:"19",y2:"12"},null,-1)])])):t.name==="minus"?(ot(),st("g",$f,[...e[9]||(e[9]=[h("line",{x1:"5",y1:"12",x2:"19",y2:"12"},null,-1)])])):t.name==="split-preview"?(ot(),st("g",If,[...e[10]||(e[10]=[h("rect",{x:"3",y:"3",width:"18",height:"18",rx:"2"},null,-1),h("path",{d:"M12 3v18"},null,-1)])])):t.name==="import"?(ot(),st("g",Af,[...e[11]||(e[11]=[h("path",{d:"M4 17v2a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-2"},null,-1),h("polyline",{points:"7 9 12 14 17 9"},null,-1),h("line",{x1:"12",y1:"14",x2:"12",y2:"3"},null,-1)])])):t.name==="presenter"?(ot(),st("g",Bf,[...e[12]||(e[12]=[h("path",{d:"M2 3h20"},null,-1),h("path",{d:"M21 3v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V3"},null,-1),h("path",{d:"m7 21 5-5 5 5"},null,-1)])])):t.name==="video"?(ot(),st("g",Tf,[...e[13]||(e[13]=[h("polygon",{points:"23 7 16 12 23 17 23 7"},null,-1),h("rect",{x:"1",y:"5",width:"15",height:"14",rx:"2",ry:"2"},null,-1)])])):t.name==="step"?(ot(),st("g",Ef,[...e[14]||(e[14]=[h("polygon",{points:"13 2 3 14 12 14 11 22 21 10 12 10 13 2"},null,-1)])])):t.name==="motion"?(ot(),st("g",Mf,[...e[15]||(e[15]=[h("path",{d:"M5 12h14"},null,-1),h("path",{d:"m12 5 7 7-7 7"},null,-1),h("path",{d:"M5 6h4"},null,-1),h("path",{d:"M5 18h4"},null,-1)])])):t.name==="columns"?(ot(),st("g",Lf,[...e[16]||(e[16]=[h("rect",{x:"3",y:"3",width:"7",height:"18",rx:"1"},null,-1),h("rect",{x:"14",y:"3",width:"7",height:"18",rx:"1"},null,-1)])])):t.name==="code"?(ot(),st("g",Df,[...e[17]||(e[17]=[h("polyline",{points:"16 18 22 12 16 6"},null,-1),h("polyline",{points:"8 6 2 12 8 18"},null,-1)])])):t.name==="insert-above"?(ot(),st("g",Pf,[...e[18]||(e[18]=[h("line",{x1:"12",y1:"5",x2:"12",y2:"13"},null,-1),h("line",{x1:"8",y1:"9",x2:"16",y2:"9"},null,-1),h("path",{d:"M4 19h16","stroke-dasharray":"2 2"},null,-1)])])):t.name==="insert-below"?(ot(),st("g",Of,[...e[19]||(e[19]=[h("path",{d:"M4 5h16","stroke-dasharray":"2 2"},null,-1),h("line",{x1:"12",y1:"11",x2:"12",y2:"19"},null,-1),h("line",{x1:"8",y1:"15",x2:"16",y2:"15"},null,-1)])])):t.name==="broom"?(ot(),st("g",Rf,[...e[20]||(e[20]=[h("path",{d:"m18 15-6-6"},null,-1),h("path",{d:"M4 20h16"},null,-1),h("path",{d:"M6 14l8-8a2.8 2.8 0 0 1 4 4l-8 8H6v-4z"},null,-1)])])):t.name==="trash"?(ot(),st("g",zf,[...e[21]||(e[21]=[h("path",{d:"M3 6h18"},null,-1),h("path",{d:"M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"},null,-1),h("path",{d:"M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"},null,-1)])])):t.name==="ai"||t.name==="sparkles"?(ot(),st("g",Nf,[...e[22]||(e[22]=[h("path",{d:"m12 3-1.9 5.8a2 2 0 0 1-1.3 1.3L3 12l5.8 1.9a2 2 0 0 1 1.3 1.3L12 21l1.9-5.8a2 2 0 0 1 1.3-1.3L21 12l-5.8-1.9a2 2 0 0 1-1.3-1.3L12 3z"},null,-1)])])):t.name==="palette"?(ot(),st("g",Ff,[...e[23]||(e[23]=[ge('<circle cx="13.5" cy="6.5" r=".5" fill="currentColor" data-v-794a58ae></circle><circle cx="17.5" cy="10.5" r=".5" fill="currentColor" data-v-794a58ae></circle><circle cx="8.5" cy="7.5" r=".5" fill="currentColor" data-v-794a58ae></circle><circle cx="6.5" cy="12.5" r=".5" fill="currentColor" data-v-794a58ae></circle><path d="M12 2C6.5 2 2 6.5 2 12s4.5 10 10 10c.9 0 1.5-.7 1.5-1.5 0-.4-.2-.8-.4-1.1-.3-.4-.4-.8-.4-1.4 0-1.1.9-2 2-2h2.3c3.9 0 7-3.1 7-7 0-5-4.5-9-10-9z" data-v-794a58ae></path>',5)])])):t.name==="ratio"?(ot(),st("g",Hf,[...e[24]||(e[24]=[h("rect",{x:"2",y:"5",width:"20",height:"14",rx:"2"},null,-1),h("line",{x1:"2",y1:"10",x2:"22",y2:"10","stroke-dasharray":"2 2"},null,-1)])])):t.name==="transition"?(ot(),st("g",jf,[...e[25]||(e[25]=[h("path",{d:"M8 3 4 7l4 4"},null,-1),h("path",{d:"M4 7h16"},null,-1),h("path",{d:"m16 21 4-4-4-4"},null,-1),h("path",{d:"M20 17H4"},null,-1)])])):t.name==="export-html"?(ot(),st("g",Uf,[...e[26]||(e[26]=[h("polyline",{points:"16 16 12 12 8 16"},null,-1),h("line",{x1:"12",y1:"12",x2:"12",y2:"21"},null,-1),h("path",{d:"M20.4 16.3A5 5 0 0 0 18 7h-1.3A8 8 0 0 0 4 12.8a5 5 0 0 0 1.5 9.2"},null,-1)])])):t.name==="export-pdf"?(ot(),st("g",Wf,[...e[27]||(e[27]=[h("polyline",{points:"6 9 6 2 18 2 18 9"},null,-1),h("path",{d:"M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"},null,-1),h("rect",{x:"6",y:"14",width:"12",height:"8"},null,-1)])])):t.name==="pin"?(ot(),st("g",Vf,[...e[28]||(e[28]=[h("line",{x1:"12",y1:"17",x2:"12",y2:"22"},null,-1),h("path",{d:"M5 17h14v-2l-2-2V5l1-1V2H6v2l1 1v8l-2 2v2z"},null,-1)])])):t.name==="refresh"?(ot(),st("g",qf,[...e[29]||(e[29]=[h("path",{d:"M3 12a9 9 0 0 1 9-9 9.75 9.75 0 0 1 6.74 2.74L21 8"},null,-1),h("path",{d:"M21 3v5h-5"},null,-1),h("path",{d:"M21 12a9 9 0 0 1-9 9 9.75 9.75 0 0 1-6.74-2.74L3 16"},null,-1),h("path",{d:"M8 16H3v5"},null,-1)])])):t.name==="outline"?(ot(),st("g",Kf,[...e[30]||(e[30]=[h("line",{x1:"3",y1:"6",x2:"21",y2:"6"},null,-1),h("line",{x1:"3",y1:"12",x2:"21",y2:"12"},null,-1),h("line",{x1:"3",y1:"18",x2:"21",y2:"18"},null,-1)])])):t.name==="chevron-left"?(ot(),st("g",Gf,[...e[31]||(e[31]=[h("polyline",{points:"15 18 9 12 15 6"},null,-1)])])):t.name==="chevron-right"?(ot(),st("g",Zf,[...e[32]||(e[32]=[h("polyline",{points:"9 18 15 12 9 6"},null,-1)])])):t.name==="copy"?(ot(),st("g",Yf,[...e[33]||(e[33]=[h("rect",{x:"9",y:"9",width:"13",height:"13",rx:"2",ry:"2"},null,-1),h("path",{d:"M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"},null,-1)])])):t.name==="image"?(ot(),st("g",Jf,[...e[34]||(e[34]=[h("rect",{x:"3",y:"3",width:"18",height:"18",rx:"2",ry:"2"},null,-1),h("circle",{cx:"8.5",cy:"8.5",r:"1.5"},null,-1),h("polyline",{points:"21 15 16 10 5 21"},null,-1)])])):t.name==="search"?(ot(),st("g",Xf,[...e[35]||(e[35]=[h("circle",{cx:"11",cy:"11",r:"7"},null,-1),h("line",{x1:"21",y1:"21",x2:"16.65",y2:"16.65"},null,-1)])])):t.name==="settings"||t.name==="gear"?(ot(),st("g",Qf,[...e[36]||(e[36]=[h("circle",{cx:"12",cy:"12",r:"3"},null,-1),h("path",{d:"M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 1 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 1 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 1 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 1 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"},null,-1)])])):t.name==="notes"||t.name==="file-text"?(ot(),st("g",tp,[...e[37]||(e[37]=[ge('<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" data-v-794a58ae></path><polyline points="14 2 14 8 20 8" data-v-794a58ae></polyline><line x1="16" y1="13" x2="8" y2="13" data-v-794a58ae></line><line x1="16" y1="17" x2="8" y2="17" data-v-794a58ae></line><line x1="10" y1="9" x2="8" y2="9" data-v-794a58ae></line>',5)])])):t.name==="focus"||t.name==="target"?(ot(),st("g",ep,[...e[38]||(e[38]=[h("circle",{cx:"12",cy:"12",r:"3",fill:"currentColor"},null,-1),h("path",{d:"M12 2v4M12 18v4M2 12h4M18 12h4",stroke:"currentColor","stroke-width":"2","stroke-linecap":"round"},null,-1),h("circle",{cx:"12",cy:"12",r:"7",fill:"none",stroke:"currentColor","stroke-width":"1.8"},null,-1)])])):t.name==="layout-cover"||t.name==="cover"?(ot(),st("g",ip,[...e[39]||(e[39]=[h("rect",{x:"2",y:"4",width:"20",height:"16",rx:"2"},null,-1),h("line",{x1:"9",y1:"8",x2:"15",y2:"8"},null,-1),h("line",{x1:"5.5",y1:"11.5",x2:"18.5",y2:"11.5"},null,-1),h("line",{x1:"7.5",y1:"15",x2:"16.5",y2:"15"},null,-1)])])):t.name==="layout-default"||t.name==="default"?(ot(),st("g",np,[...e[40]||(e[40]=[ge('<rect x="2" y="4" width="20" height="16" rx="2" data-v-794a58ae></rect><line x1="5" y1="8" x2="11.5" y2="8" data-v-794a58ae></line><line x1="5" y1="11.5" x2="19" y2="11.5" data-v-794a58ae></line><line x1="5" y1="14.5" x2="19" y2="14.5" data-v-794a58ae></line><line x1="5" y1="17.5" x2="13.5" y2="17.5" data-v-794a58ae></line>',5)])])):t.name==="layout-two-cols"||t.name==="two-cols"?(ot(),st("g",op,[...e[41]||(e[41]=[ge('<rect x="2" y="4" width="20" height="16" rx="2" data-v-794a58ae></rect><line x1="12" y1="4" x2="12" y2="20" stroke-dasharray="2 1.5" data-v-794a58ae></line><line x1="5" y1="8" x2="9.5" y2="8" data-v-794a58ae></line><line x1="5" y1="11.5" x2="9.5" y2="11.5" data-v-794a58ae></line><line x1="5" y1="15" x2="8" y2="15" data-v-794a58ae></line><line x1="14.5" y1="8" x2="19" y2="8" data-v-794a58ae></line><line x1="14.5" y1="11.5" x2="19" y2="11.5" data-v-794a58ae></line><line x1="14.5" y1="15" x2="17.5" y2="15" data-v-794a58ae></line>',8)])])):t.name==="layout-two-cols-header"||t.name==="two-cols-header"?(ot(),st("g",sp,[...e[42]||(e[42]=[ge('<rect x="2" y="4" width="20" height="16" rx="2" data-v-794a58ae></rect><line x1="5" y1="7.5" x2="13" y2="7.5" data-v-794a58ae></line><line x1="12" y1="10.5" x2="12" y2="18.5" stroke-dasharray="1.5 1.5" data-v-794a58ae></line><line x1="5" y1="12" x2="9.5" y2="12" data-v-794a58ae></line><line x1="5" y1="15.5" x2="8.5" y2="15.5" data-v-794a58ae></line><line x1="14.5" y1="12" x2="19" y2="12" data-v-794a58ae></line><line x1="14.5" y1="15.5" x2="18" y2="15.5" data-v-794a58ae></line>',7)])])):t.name==="layout-cols-header"||t.name==="cols-header"||t.name==="layout-three-cols-header"||t.name==="three-cols-header"?(ot(),st("g",rp,[...e[43]||(e[43]=[ge('<rect x="2" y="4" width="20" height="16" rx="2" data-v-794a58ae></rect><line x1="5" y1="7.5" x2="13" y2="7.5" data-v-794a58ae></line><line x1="9.3" y1="10.5" x2="9.3" y2="18.5" stroke-dasharray="1.5 1.5" data-v-794a58ae></line><line x1="14.7" y1="10.5" x2="14.7" y2="18.5" stroke-dasharray="1.5 1.5" data-v-794a58ae></line><line x1="4.5" y1="12" x2="7.5" y2="12" data-v-794a58ae></line><line x1="4.5" y1="15.5" x2="7" y2="15.5" data-v-794a58ae></line><line x1="10.5" y1="12" x2="13.5" y2="12" data-v-794a58ae></line><line x1="10.5" y1="15.5" x2="13.5" y2="15.5" data-v-794a58ae></line><line x1="16" y1="12" x2="19.5" y2="12" data-v-794a58ae></line><line x1="16" y1="15.5" x2="18.5" y2="15.5" data-v-794a58ae></line>',10)])])):t.name==="layout-clover"||t.name==="clover"?(ot(),st("g",lp,[...e[44]||(e[44]=[ge('<rect x="2" y="4" width="20" height="16" rx="2" data-v-794a58ae></rect><line x1="5" y1="7" x2="13" y2="7" data-v-794a58ae></line><line x1="4.5" y1="13.5" x2="19.5" y2="13.5" stroke-dasharray="1.5 1.5" data-v-794a58ae></line><line x1="12" y1="9" x2="12" y2="18.5" stroke-dasharray="1.5 1.5" data-v-794a58ae></line><line x1="5" y1="11" x2="9.5" y2="11" data-v-794a58ae></line><line x1="14.5" y1="11" x2="19" y2="11" data-v-794a58ae></line><line x1="5" y1="16" x2="9.5" y2="16" data-v-794a58ae></line><line x1="14.5" y1="16" x2="19" y2="16" data-v-794a58ae></line>',8)])])):t.name==="layout-image-right"||t.name==="image-right"?(ot(),st("g",ap,[...e[45]||(e[45]=[ge('<rect x="2" y="4" width="20" height="16" rx="2" data-v-794a58ae></rect><line x1="12" y1="4" x2="12" y2="20" data-v-794a58ae></line><line x1="4.5" y1="8" x2="9.5" y2="8" data-v-794a58ae></line><line x1="4.5" y1="11.5" x2="10" y2="11.5" data-v-794a58ae></line><line x1="4.5" y1="14.5" x2="8" y2="14.5" data-v-794a58ae></line><circle cx="15.5" cy="8.5" r="1.2" data-v-794a58ae></circle><polyline points="13 17 15.5 13 18 16 19.5 14" data-v-794a58ae></polyline>',7)])])):t.name==="layout-image-left"||t.name==="image-left"?(ot(),st("g",cp,[...e[46]||(e[46]=[ge('<rect x="2" y="4" width="20" height="16" rx="2" data-v-794a58ae></rect><line x1="12" y1="4" x2="12" y2="20" data-v-794a58ae></line><circle cx="6" cy="8.5" r="1.2" data-v-794a58ae></circle><polyline points="3.5 17 6 13 8.5 16 10 14" data-v-794a58ae></polyline><line x1="14.5" y1="8" x2="19.5" y2="8" data-v-794a58ae></line><line x1="14.5" y1="11.5" x2="20" y2="11.5" data-v-794a58ae></line><line x1="14.5" y1="14.5" x2="18" y2="14.5" data-v-794a58ae></line>',7)])])):t.name==="layout-center"||t.name==="center"?(ot(),st("g",dp,[...e[47]||(e[47]=[h("rect",{x:"2",y:"4",width:"20",height:"16",rx:"2"},null,-1),h("line",{x1:"6.5",y1:"9",x2:"17.5",y2:"9"},null,-1),h("line",{x1:"5",y1:"12",x2:"19",y2:"12"},null,-1),h("line",{x1:"8",y1:"15",x2:"16",y2:"15"},null,-1)])])):t.name==="layout-fact"||t.name==="fact"?(ot(),st("g",up,[...e[48]||(e[48]=[ge('<rect x="2" y="4" width="20" height="16" rx="2" data-v-794a58ae></rect><circle cx="8" cy="9" r="1.5" data-v-794a58ae></circle><line x1="14" y1="8" x2="9" y2="14" data-v-794a58ae></line><circle cx="15" cy="13" r="1.5" data-v-794a58ae></circle><line x1="6.5" y1="17" x2="17.5" y2="17" data-v-794a58ae></line>',5)])])):t.name==="layout-intro"||t.name==="intro"?(ot(),st("g",fp,[...e[49]||(e[49]=[ge('<rect x="2" y="4" width="20" height="16" rx="2" data-v-794a58ae></rect><circle cx="7.5" cy="9.5" r="2" data-v-794a58ae></circle><path d="M4.5 16.5c0-1.8 1.3-3 3-3s3 1.2 3 3" data-v-794a58ae></path><line x1="13" y1="9" x2="18.5" y2="9" data-v-794a58ae></line><line x1="13" y1="12.5" x2="19.5" y2="12.5" data-v-794a58ae></line><line x1="13" y1="15.5" x2="17" y2="15.5" data-v-794a58ae></line>',6)])])):t.name==="layout-quote"||t.name==="quote"?(ot(),st("g",pp,[...e[50]||(e[50]=[ge('<rect x="2" y="4" width="20" height="16" rx="2" data-v-794a58ae></rect><path d="M6 7.5h2v2H6.5c0 1.2-.4 2-1.5 2.5" data-v-794a58ae></path><path d="M9.5 7.5h2v2H10c0 1.2-.4 2-1.5 2.5" data-v-794a58ae></path><line x1="6" y1="13.5" x2="18" y2="13.5" data-v-794a58ae></line><line x1="12.5" y1="16.5" x2="17.5" y2="16.5" data-v-794a58ae></line>',5)])])):t.name==="desktop"||t.name==="monitor"?(ot(),st("g",hp,[...e[51]||(e[51]=[h("rect",{x:"2",y:"3",width:"20",height:"14",rx:"2"},null,-1),h("line",{x1:"8",y1:"21",x2:"16",y2:"21"},null,-1),h("line",{x1:"12",y1:"17",x2:"12",y2:"21"},null,-1)])])):t.name==="mobile"||t.name==="smartphone"||t.name==="phone"?(ot(),st("g",mp,[...e[52]||(e[52]=[h("rect",{x:"5",y:"2",width:"14",height:"20",rx:"2",ry:"2"},null,-1),h("line",{x1:"12",y1:"18",x2:"12.01",y2:"18","stroke-width":"2","stroke-linecap":"round"},null,-1)])])):t.name==="type"||t.name==="heading"?(ot(),st("g",gp,[...e[53]||(e[53]=[h("polyline",{points:"4 7 4 4 20 4 20 7"},null,-1),h("line",{x1:"9",y1:"20",x2:"15",y2:"20"},null,-1),h("line",{x1:"12",y1:"4",x2:"12",y2:"20"},null,-1)])])):t.name==="reset"||t.name==="undo"?(ot(),st("g",vp,[...e[54]||(e[54]=[h("path",{d:"M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8"},null,-1),h("polyline",{points:"3 3 3 8 8 8"},null,-1)])])):t.name==="repeat"||t.name==="loop"?(ot(),st("g",bp,[...e[55]||(e[55]=[h("path",{d:"m17 1 4 4-4 4"},null,-1),h("path",{d:"M3 11V9a4 4 0 0 1 4-4h14"},null,-1),h("path",{d:"m7 23-4-4 4-4"},null,-1),h("path",{d:"M21 13v2a4 4 0 0 1-4 4H3"},null,-1)])])):t.name==="volume-x"||t.name==="mute"?(ot(),st("g",yp,[...e[56]||(e[56]=[h("polygon",{points:"11 5 6 9 2 9 2 15 6 15 11 19 11 5"},null,-1),h("line",{x1:"22",y1:"9",x2:"16",y2:"15"},null,-1),h("line",{x1:"16",y1:"9",x2:"22",y2:"15"},null,-1)])])):t.name==="sliders"||t.name==="controls"?(ot(),st("g",kp,[...e[57]||(e[57]=[ge('<line x1="4" y1="21" x2="4" y2="14" data-v-794a58ae></line><line x1="4" y1="10" x2="4" y2="3" data-v-794a58ae></line><line x1="12" y1="21" x2="12" y2="12" data-v-794a58ae></line><line x1="12" y1="8" x2="12" y2="3" data-v-794a58ae></line><line x1="20" y1="21" x2="20" y2="16" data-v-794a58ae></line><line x1="20" y1="12" x2="20" y2="3" data-v-794a58ae></line><line x1="1" y1="14" x2="7" y2="14" data-v-794a58ae></line><line x1="9" y1="8" x2="15" y2="8" data-v-794a58ae></line><line x1="17" y1="16" x2="23" y2="16" data-v-794a58ae></line>',9)])])):t.name==="package"||t.name==="zip"||t.name==="archive"?(ot(),st("g",wp,[...e[58]||(e[58]=[h("line",{x1:"16.5",y1:"9.4",x2:"7.5",y2:"4.21"},null,-1),h("path",{d:"M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"},null,-1),h("polyline",{points:"3.27 6.96 12 12.01 20.73 6.96"},null,-1),h("line",{x1:"12",y1:"22.08",x2:"12",y2:"12"},null,-1)])])):t.name==="folder"?(ot(),st("g",xp,[...e[59]||(e[59]=[h("path",{d:"M4 20h16a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2h-7.93a2 2 0 0 1-1.66-.9l-.82-1.2A2 2 0 0 0 7.93 3H4a2 2 0 0 0-2 2v13c0 1.1.9 2 2 2Z"},null,-1)])])):t.name==="rocket"?(ot(),st("g",Sp,[...e[60]||(e[60]=[h("path",{d:"M4.5 16.5c-1.5 1.26-2 5-2 5s3.74-.5 5-2c.71-.84.7-2.13-.09-2.91a2.18 2.18 0 0 0-2.91-.09z"},null,-1),h("path",{d:"m12 15-3-3a22 22 0 0 1 2-3.95A12.88 12.88 0 0 1 22 2c0 2.72-.78 7.5-6 11a22.35 22.35 0 0 1-4 2z"},null,-1),h("path",{d:"M9 12H4s.55-3.03 2-4c1.62-1.08 5 0 5 0"},null,-1),h("path",{d:"M12 15v5s3.03-.55 4-2c1.08-1.62 0-5 0-5"},null,-1)])])):t.name==="wand"||t.name==="magic"?(ot(),st("g",_p,[...e[61]||(e[61]=[h("path",{d:"m19 2 2 2-6 6-2-2Z"},null,-1),h("path",{d:"m13 8 2 2"},null,-1),h("path",{d:"m3 21 9-9"},null,-1)])])):t.name==="image-left"?(ot(),st("g",Cp,[...e[62]||(e[62]=[ge('<rect x="2" y="4" width="20" height="16" rx="2" data-v-794a58ae></rect><rect x="4" y="6" width="6" height="12" rx="1" data-v-794a58ae></rect><line x1="13" y1="8" x2="19" y2="8" data-v-794a58ae></line><line x1="13" y1="12" x2="19" y2="12" data-v-794a58ae></line><line x1="13" y1="16" x2="17" y2="16" data-v-794a58ae></line>',5)])])):t.name==="image-right"?(ot(),st("g",$p,[...e[63]||(e[63]=[ge('<rect x="2" y="4" width="20" height="16" rx="2" data-v-794a58ae></rect><rect x="14" y="6" width="6" height="12" rx="1" data-v-794a58ae></rect><line x1="5" y1="8" x2="11" y2="8" data-v-794a58ae></line><line x1="5" y1="12" x2="11" y2="12" data-v-794a58ae></line><line x1="5" y1="16" x2="9" y2="16" data-v-794a58ae></line>',5)])])):(ot(),st("g",Ip,[...e[64]||(e[64]=[h("rect",{x:"2",y:"3",width:"20",height:"14",rx:"2"},null,-1),h("line",{x1:"8",y1:"21",x2:"16",y2:"21"},null,-1),h("line",{x1:"12",y1:"17",x2:"12",y2:"21"},null,-1)])]))]))}}),ze=(t,i)=>{const e=t.__vccOpts||t;for(const[n,o]of i)e[n]=o;return e},ft=ze(Ap,[["__scopeId","data-v-794a58ae"]]);function Zt(t,i){var o;if(typeof document>"u"||!t)return;const e=(o=globalThis.CSS)!=null&&o.escape?globalThis.CSS.escape(t):t.replace(/"/g,'\\"'),n=document.querySelectorAll(`[data-node-id="${e}"]`);!n||n.length===0||n.forEach(s=>{for(const[l,r]of Object.entries(i))r!=null&&r!==""?s.setAttribute(l,String(r)):s.removeAttribute(l)})}function Bp(t){if(typeof document>"u")return;const i=`.protyle-wysiwyg [${mt}], .protyle-wysiwyg [${qt}], .protyle-wysiwyg [custom-slidev-layout], .protyle-wysiwyg [custom-slidev-role]`,e=document.querySelectorAll(i);!e||e.length===0||e.forEach(n=>{const o=n.getAttribute("data-node-id");if(!o){n.removeAttribute(mt),n.removeAttribute("custom-slidev-layout"),n.removeAttribute(qt),n.removeAttribute("custom-slidev-role");return}const s=t.get(o),l=(s==null?void 0:s[mt])||(s==null?void 0:s["custom-slidev-layout"])||"",r=n.getAttribute(mt)||n.getAttribute("custom-slidev-layout");r&&r!==l&&(l?n.setAttribute(mt,l):(n.removeAttribute(mt),n.removeAttribute("custom-slidev-layout")));const a=(s==null?void 0:s[qt])||(s==null?void 0:s["custom-slidev-role"])||"",c=n.getAttribute(qt)||n.getAttribute("custom-slidev-role");c&&c!==a&&(a?n.setAttribute(qt,a):(n.removeAttribute(qt),n.removeAttribute("custom-slidev-role")))})}const Tp={class:"spm-layout-picker"},Ep={class:"spm-layout-picker__grid"},Mp=["title","onClick"],Lp={class:"spm-layout-icon"},Dp={class:"spm-layout-label"},Pp=_e({__name:"LayoutPicker",props:{modelValue:{}},emits:["update:modelValue","change"],setup(t,{emit:i}){const e=t,n=i,o=[{name:"cover",label:"封面",desc:"大标题与副标题封面页"},{name:"default",label:"标准",desc:"标题在上方，内容在下方"},{name:"two-cols",label:"双栏",desc:"左右双栏对比展示"},{name:"cols-header",label:"表头多栏",desc:"顶部通栏标题，下方自适应 2~N 栏"},{name:"clover",label:"四叶草",desc:"4 项超级块 2x2 田字型四象限卡片布局"},{name:"image-right",label:"图右",desc:"左侧为内容，右侧全屏背景图"},{name:"image-left",label:"图左",desc:"左侧全屏背景图，右侧为内容"},{name:"center",label:"居中",desc:"内容全屏垂直水平居中"},{name:"fact",label:"大字报",desc:"核心数据或指标突出展示"},{name:"intro",label:"介绍",desc:"演讲者自我介绍或章节导览"},{name:"quote",label:"引言",desc:"名人名言与强调段落"}];function s(r){return e.modelValue===r||r==="cols-header"&&(e.modelValue==="two-cols-header"||e.modelValue==="three-cols-header")}function l(r){n("update:modelValue",r),n("change",r)}return(r,a)=>(ot(),st("div",Tp,[a[0]||(a[0]=h("div",{class:"spm-layout-picker__header"},"选择页面版式",-1)),h("div",Ep,[(ot(),st(Kt,null,xe(o,c=>h("div",{key:c.name,class:At(["spm-layout-item",{active:s(c.name)}]),title:c.desc,onClick:u=>l(c.name)},[h("div",Lp,[ut(ft,{name:"layout-"+c.name},null,8,["name"])]),h("span",Dp,_t(c.label),1)],10,Mp)),64))])]))}}),aa=ze(Pp,[["__scopeId","data-v-3d2599ad"]]),Op={key:0,class:"spm-transition-selector__header"},Rp={class:"spm-transition-list"},zp=["onClick"],Np={class:"spm-transition-meta"},Fp={class:"spm-transition-label"},Hp={class:"spm-transition-name"},jp={class:"spm-transition-preview-box"},Up=_e({__name:"TransitionSelector",props:{modelValue:{},hideHeader:{type:Boolean},title:{}},emits:["update:modelValue","change"],setup(t,{emit:i}){const e=i,n=[{name:"slide-left",label:"向左滑入",desc:"向左滑入 (slide-left)：页面从右侧向左平滑推入，最通用标准的横向幻灯片动效"},{name:"slide-right",label:"向右滑入",desc:"向右滑入 (slide-right)：页面从左侧向右平滑推入，适合倒序回退或逆向章节叙述"},{name:"slide-up",label:"向上推入",desc:"向上推入 (slide-up)：页面从底部向上平滑推入，适合纵向展开或纵深层级展示"},{name:"fade",label:"淡入淡出",desc:"淡入淡出 (fade)：透明度平滑渐变过度，典雅柔和，适合学术长篇与沉浸叙事"},{name:"zoom",label:"缩放进入",desc:"缩放进入 (zoom)：页面由中心向外平滑放大，富有动感冲击力，适合聚焦重点"}];function o(s){e("update:modelValue",s),e("change",s)}return(s,l)=>(ot(),st("div",{class:At(["spm-transition-selector",{"spm-transition-selector--no-header":t.hideHeader}])},[t.hideHeader?Ot("",!0):(ot(),st("div",Op,_t(t.title||"转场动效"),1)),h("div",Rp,[(ot(),st(Kt,null,xe(n,r=>h("div",{key:r.name,class:At(["spm-transition-item",{active:t.modelValue===r.name}]),onClick:a=>o(r.name)},[h("div",Np,[h("span",Fp,_t(r.label),1),h("span",Hp,"("+_t(r.name)+")",1)]),h("div",jp,[h("div",{class:At(["spm-anim-cube","anim-"+r.name])},null,2)])],10,zp)),64))])],2))}}),Hs=ze(Up,[["__scopeId","data-v-b0aa61ff"]]),Wp={class:"spm-divider-popover"},Vp={class:"spm-divider-popover__title"},qp={class:"spm-form-item"},Kp={class:"spm-popover-footer"},Gp={class:"spm-save-hint"},Zp=_e({__name:"QuickDividerPopover",props:{blockId:{},initialAttrs:{}},emits:["close","updated"],setup(t,{emit:i}){var g,d,b;const e=t,n=i,o=vt(((g=e.initialAttrs)==null?void 0:g[mt])||"default"),s=vt(((d=e.initialAttrs)==null?void 0:d[te])||"slide-left"),l=vt(((b=e.initialAttrs)==null?void 0:b[Ut])||""),r=vt("");Di(()=>e.initialAttrs,f=>{o.value=(f==null?void 0:f[mt])||"default",s.value=(f==null?void 0:f[te])||"slide-left",l.value=(f==null?void 0:f[Ut])||""},{deep:!0});async function a(f,v){if(e.blockId){r.value="正在同步...",Lt.setBlockAttrOverride(e.blockId,{[f]:v}),Zt(e.blockId,{[f]:v});try{await Et(e.blockId,{[f]:v}),r.value="已同步至块属性",n("updated",{[f]:v}),setTimeout(()=>{r.value=""},1500)}catch{r.value="同步失败"}}}function c(f){a(mt,f)}function u(f){a(te,f)}function m(){a(Ut,l.value.trim())}return(f,v)=>(ot(),st("div",Wp,[h("div",Vp,[v[4]||(v[4]=h("span",null,"幻灯片页面设置",-1)),h("button",{class:"spm-close-btn",onClick:v[0]||(v[0]=k=>n("close"))},"✕")]),ut(aa,{modelValue:o.value,"onUpdate:modelValue":v[1]||(v[1]=k=>o.value=k),onChange:c},null,8,["modelValue"]),ut(Hs,{modelValue:s.value,"onUpdate:modelValue":v[2]||(v[2]=k=>s.value=k),onChange:u},null,8,["modelValue"]),h("div",qp,[v[5]||(v[5]=h("label",{class:"spm-form-label"},"页面背景",-1)),Te(h("input",{"onUpdate:modelValue":v[3]||(v[3]=k=>l.value=k),class:"spm-input",placeholder:"assets/bg.jpg 或颜色值 (#1e1e24)",onBlur:m},null,544),[[vo,l.value]])]),h("div",Kp,[h("span",Gp,_t(r.value),1)])]))}}),Yp=ze(Zp,[["__scopeId","data-v-e4871368"]]),Jp={class:"spm-slide-inspector"},Xp={class:"spm-inspector-header"},Qp={class:"spm-inspector-list"},th=["onClick"],eh={class:"spm-card-top"},ih={class:"spm-card-badge"},nh={class:"spm-card-layout"},oh=["onClick"],sh={class:"spm-card-preview"},rh={key:0,class:"spm-card-notes",title:"演讲备忘录"},lh={class:"spm-inspector-modal-content"},ah=_e({__name:"SlideInspector",props:{slides:{},currentActivePage:{}},emits:["navigate","refresh"],setup(t,{emit:i}){const e=i,n=vt(null);function o(c){n.value=c}function s(c){const u={};return c.frontmatter.layout&&(u[mt]=c.frontmatter.layout),c.frontmatter.transition&&(u[te]=c.frontmatter.transition),c.frontmatter.background&&(u[Ut]=c.frontmatter.background),c.notes&&(u[Wi]=c.notes),u}function l(c){n.value&&(c[mt]&&(n.value.frontmatter.layout=c[mt]),c[te]&&(n.value.frontmatter.transition=c[te]),c[Ut]&&(n.value.frontmatter.background=c[Ut]),c[Wi]&&(n.value.notes=c[Wi]),e("refresh"))}function r(c){e("navigate",c)}function a(c){if(!c.blocks||c.blocks.length===0)return"(空白页)";const u=c.blocks[0],m=u.content||u.rawMarkdown||"";return m.slice(0,40)+(m.length>40?"...":"")}return(c,u)=>(ot(),st("div",Jp,[h("div",Xp,[h("span",null,"幻灯片大纲 ("+_t(t.slides.length)+" 页)",1)]),h("div",Qp,[(ot(!0),st(Kt,null,xe(t.slides,m=>(ot(),st("div",{key:m.pageIndex,class:At(["spm-card",{active:t.currentActivePage===m.pageIndex}]),onClick:g=>r(m.pageIndex)},[h("div",eh,[h("span",ih,"P"+_t(m.pageIndex),1),h("span",nh,_t(m.frontmatter.layout||"default"),1),h("button",{class:"spm-card-btn-edit",title:"配置此页版式与属性",onClick:Me(g=>o(m),["stop"])},[ut(ft,{name:"settings"})],8,oh)]),h("div",sh,_t(a(m)),1),m.notes?(ot(),st("div",rh,[ut(ft,{name:"notes",style:{"font-size":"11px","margin-right":"3px"}}),h("span",null,_t(m.notes),1)])):Ot("",!0)],10,th))),128))]),n.value?(ot(),st("div",{key:0,class:"spm-inspector-modal-mask",onClick:u[1]||(u[1]=Me(m=>n.value=null,["self"]))},[h("div",lh,[ut(Yp,{"block-id":n.value.startBlockId,"initial-attrs":s(n.value),onClose:u[0]||(u[0]=m=>n.value=null),onUpdated:l},null,8,["block-id","initial-attrs"])])])):Ot("",!0)]))}}),ch=ze(ah,[["__scopeId","data-v-68b25edd"]]),dh={class:"spm-immersion-header"},uh={class:"spm-immersion-header__left"},fh={class:"spm-immersion-title"},ph={class:"spm-immersion-header__center"},hh={class:"spm-immersion-header__actions"},mh=["aria-label"],gh={class:"spm-immersion-body"},vh=_e({__name:"ImmersionDrawerContainer",props:{visible:{type:Boolean,default:!1},isMaximized:{type:Boolean,default:!1},title:{default:"速览"},closeOnClickMask:{type:Boolean,default:!0}},emits:["update:visible","update:isMaximized","close","toggle-maximize"],setup(t,{emit:i}){const e=t,n=i;function o(){n("update:visible",!1),n("close")}function s(){e.closeOnClickMask&&o()}function l(){n("update:isMaximized",!e.isMaximized),n("toggle-maximize")}function r(a){(a.key===" "||a.key==="ArrowLeft"||a.key==="ArrowRight"||a.key==="PageUp"||a.key==="PageDown")&&a.stopPropagation(),a.key==="Escape"&&(a.preventDefault(),a.stopPropagation(),o())}return(a,c)=>Te((ot(),st("div",{class:At(["spm-immersion-container",{"is-maximized":t.isMaximized}]),onKeydown:Me(r,["stop"])},[h("div",{class:"spm-immersion-mask",onClick:s}),h("div",{class:At(["spm-immersion-drawer",{"is-maximized":t.isMaximized}])},[h("div",dh,[h("div",uh,[qn(a.$slots,"header-left",{},()=>[h("span",fh,_t(t.title),1)])]),h("div",ph,[qn(a.$slots,"header-center",{},void 0)]),h("div",hh,[qn(a.$slots,"header-actions",{},void 0),h("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":t.isMaximized?"还原抽屉宽度 (70%)":"最大化填满视口 (100%)",onClick:l},[ut(ft,{name:t.isMaximized?"minimize":"maximize"},null,8,["name"])],8,mh),h("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"关闭速览 (ESC)",onClick:o},[ut(ft,{name:"close"})])])]),h("div",gh,[qn(a.$slots,"default",{},void 0)])],2)],34)),[[Zl,t.visible]])}}),bh=ze(vh,[["__scopeId","data-v-3f1665db"]]),yh={class:"spm-protyle-drawer"},kh={class:"spm-protyle-drawer__subbar"},wh={class:"spm-protyle-drawer__nav"},xh=["title"],Sh={class:"spm-protyle-drawer__actions"},_h=["aria-label"],Ch=["aria-label"],$h=_e({__name:"ProtylePeekDrawer",props:{blockId:{},title:{},plugin:{}},emits:["external-jump"],setup(t,{emit:i}){const e=i,n=t,o=vt(n.blockId),s=vt(n.title||""),l=vt(!1),r=vt(!0),a=vt(!1),c=vt(""),u=mi,m=vt([]),g=vt(null);let d=null;Di(()=>n.blockId,w=>{w&&w!==o.value&&(o.value=w,s.value=n.title||"",m.value=[],f(w))}),Rn(()=>{o.value&&f(o.value)}),Bs(()=>{v()});async function b(w){try{const N=await wn(`SELECT id, root_id, type, content FROM blocks WHERE id = '${w}' LIMIT 1`);if(Array.isArray(N)&&N.length>0){const F=N[0];c.value=F.root_id||"";const j=F.id===F.root_id||F.type==="d";a.value=j,r.value=!j,!s.value&&F.content&&(s.value=F.content.trim().slice(0,30));return}}catch(N){console.warn("[ProtylePeekDrawer] detectBlockType query failed:",N)}a.value=!1,r.value=!0}async function f(w,N){if(!g.value||!w)return;v(),await b(w),typeof N=="boolean"&&(r.value=!a.value&&N);let F,j;r.value&&!a.value?(F=["cb-get-all","cb-get-hl","cb-get-focus"],j={background:!1,title:!1,gutter:!0,breadcrumbDocName:!0,scroll:!0}):(F=["cb-get-context","cb-get-hl"],j={background:!0,title:!0,gutter:!0,breadcrumbDocName:!0,scroll:!0});try{d=new ht.Protyle(n.plugin.app,g.value,{blockId:w,action:F,render:j}),!l.value&&d&&typeof d.disable=="function"&&d.disable()}catch(J){console.error("[ProtylePeekDrawer] Failed to instantiate Protyle:",J)}}function v(){if(d){try{typeof d.destroy=="function"&&d.destroy()}catch(w){console.warn("[ProtylePeekDrawer] Error destroying protyle:",w)}d=null}g.value&&(g.value.innerHTML="")}function k(){a.value||(r.value=!r.value,f(o.value,r.value))}function S(){l.value=!l.value,d&&(l.value?(typeof d.enable=="function"&&d.enable(),typeof d.focus=="function"&&d.focus()):typeof d.disable=="function"&&d.disable())}function x(){if(o.value)try{ht.openWindow({doc:{id:o.value},alwaysOnTop:!0})}catch(w){console.warn("[ProtylePeekDrawer] openWindow failed:",w)}}function A(){var F;if(!o.value)return;const w=Mo(),N=Xl(w.webServeUrl,o.value,{focus:!a.value});if(typeof window<"u"){const j=$e("electron");(F=j==null?void 0:j.shell)!=null&&F.openExternal?j.shell.openExternal(N).catch(()=>{window.open(N,"_blank")}):window.open(N,"_blank")}e("external-jump",N)}function T(){if(m.value.length>0){const w=m.value.pop();w&&(o.value=w.blockId,s.value=w.title,r.value=w.isFocusMode,a.value=w.isDoc,f(w.blockId,w.isFocusMode))}}function I(w){const N=w.target;if(!N)return;const F=N.closest('[data-type="block-ref"]');if(F){const J=F.getAttribute("data-id");if(J&&J!==o.value){w.preventDefault(),w.stopPropagation(),m.value.push({blockId:o.value,title:s.value||o.value,isFocusMode:r.value,isDoc:a.value}),o.value=J,s.value=F.innerText.trim()||J,f(J);return}}const j=N.closest("a");if(j&&j.href&&j.href.startsWith("siyuan://blocks/")){w.preventDefault(),w.stopPropagation();const J=j.href.replace("siyuan://blocks/","").split("?")[0];J&&J!==o.value&&(m.value.push({blockId:o.value,title:s.value||o.value,isFocusMode:r.value,isDoc:a.value}),o.value=J,s.value=j.innerText.trim()||J,f(J))}}return(w,N)=>(ot(),st("div",yh,[h("div",kh,[h("div",wh,[m.value.length>0?(ot(),st("button",{key:0,class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"返回上层引用文档或块",onClick:T},[ut(ft,{name:"arrow-left"}),N[0]||(N[0]=h("span",null,"返回",-1))])):Ot("",!0),h("span",{class:At(["spm-protyle-badge",{"is-focus":r.value&&!a.value}])},_t(r.value&&!a.value?"思源块聚焦":"思源文档速览"),3),h("span",{class:"spm-protyle-id",title:s.value||o.value},_t(s.value||o.value),9,xh)]),h("div",Sh,[a.value?Ot("",!0):(ot(),st("button",{key:0,class:At(["spm-icon-btn b3-tooltips b3-tooltips__s",{"is-primary":r.value}]),"aria-label":r.value?"当前为块聚焦模式（点击展开所属文档全文）":"当前为文档全文模式（点击切回仅聚焦当前块）",onClick:k},[ut(ft,{name:r.value?"focus":"file-text"},null,8,["name"]),h("span",null,_t(r.value?"块聚焦":"展开全文"),1)],10,_h)),h("button",{class:At(["spm-icon-btn b3-tooltips b3-tooltips__s",{"is-primary":l.value}]),"aria-label":l.value?"当前为即时编辑模式（点击切回只读）":"当前为只读速览模式（点击解锁即时编辑）",onClick:S},[ut(ft,{name:l.value?"edit":"eye"},null,8,["name"]),h("span",null,_t(l.value?"编辑中":"只读"),1)],10,Ch),h("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"在置顶独立窗口中打开 (保留完整侧边栏与插件)",onClick:x},[ut(ft,{name:"window"}),N[1]||(N[1]=h("span",null,"独立窗口",-1))]),bt(u).enableWebServeJump?(ot(),st("button",{key:1,class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"在系统默认浏览器中打开 (外跳)",onClick:A},[ut(ft,{name:"external-link"}),N[2]||(N[2]=h("span",null,"外跳",-1))])):Ot("",!0)])]),h("div",{ref_key:"mountEl",ref:g,class:At(["spm-protyle-mount",{"is-focus-mode":r.value&&!a.value}]),onClick:I},null,2)]))}}),Ih=ze($h,[["__scopeId","data-v-7e586ef3"]]),Ah={class:"spm-webview-drawer"},Bh={class:"spm-webview-toolbar"},Th={class:"spm-webview-toolbar__nav"},Eh=["disabled"],Mh=["disabled"],Lh=["aria-label"],Dh={class:"spm-webview-toolbar__address"},Ph=["aria-label"],Oh={class:"spm-webview-toolbar__actions"},Rh=["aria-label"],zh={class:"spm-zoom-controller"},Nh=["disabled"],Fh=["disabled"],Hh={key:1,class:"spm-webview-fallback"},jh=["src"],Tr="Mozilla/5.0 (iPhone; CPU iPhone OS 17_4_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.4.1 Mobile/15E148 Safari/604.1",ca="siyuan-slidev-peek-view-mode";let da="desktop";function Uh(){if(typeof window<"u"&&window.localStorage)try{const t=window.localStorage.getItem(ca);if(t==="mobile"||t==="desktop")return t}catch{}return da}function Wh(t){if(da=t,typeof window<"u"&&window.localStorage)try{window.localStorage.setItem(ca,t)}catch{}}const Vh=_e({__name:"WebviewPeekDrawer",props:{url:{},title:{},visible:{type:Boolean,default:!0}},emits:["external-jump"],setup(t,{emit:i}){const e=i,n=t,o=vt(sa()),s=vt(n.url),l=vt(n.url),r=vt(!1),a=vt(!1),c=vt(!1),u=vt(1),m=vt(!1),g=vt(Uh());let d=typeof navigator<"u"&&!navigator.userAgent.includes("iPhone")?navigator.userAgent:"";const b=St(()=>g.value==="mobile"?Tr:d||void 0),f=vt(null),v=vt(null);let k=null,S=null,x=null;Di(()=>n.url,D=>{D&&D!==s.value&&(s.value=D,l.value=D,g.value==="mobile"&&N(!1),f.value&&typeof f.value.loadURL=="function"&&f.value.loadURL(D))}),Di(()=>n.visible,D=>{if(D)W(),g.value==="mobile"&&N(!1);else if(f.value)try{typeof f.value.stop=="function"&&f.value.stop()}catch{}}),Rn(()=>{A(),v.value&&typeof ResizeObserver<"u"&&(k=new ResizeObserver(()=>{const D=f.value;if(D&&typeof D.invalidate=="function")try{D.invalidate()}catch{}}),k.observe(v.value)),S=D=>{var lt;const dt=D.message||((lt=D.error)==null?void 0:lt.message);if(typeof dt=="string"&&dt.includes("Invalid guestInstanceId"))return D.preventDefault(),D.stopImmediatePropagation(),!0},window.addEventListener("error",S,!0),x=D=>{const dt=D.reason,lt=typeof dt=="string"?dt:dt==null?void 0:dt.message;typeof lt=="string"&&lt.includes("Invalid guestInstanceId")&&D.preventDefault()},window.addEventListener("unhandledrejection",x)}),Bs(()=>{if(T(),k&&(k.disconnect(),k=null),S&&(window.removeEventListener("error",S,!0),S=null),x&&(window.removeEventListener("unhandledrejection",x),x=null),f.value)try{typeof f.value.stop=="function"&&f.value.stop()}catch{}});function A(){const D=f.value;D&&(D.addEventListener("dom-ready",I),D.addEventListener("did-start-loading",F),D.addEventListener("did-stop-loading",j),D.addEventListener("did-navigate",J),D.addEventListener("did-navigate-in-page",$),D.addEventListener("new-window",O))}function T(){const D=f.value;if(D)try{D.removeEventListener("dom-ready",I),D.removeEventListener("did-start-loading",F),D.removeEventListener("did-stop-loading",j),D.removeEventListener("did-navigate",J),D.removeEventListener("did-navigate-in-page",$),D.removeEventListener("new-window",O)}catch{}}function I(){const D=f.value;if(D&&typeof D.getUserAgent=="function"&&!d)try{const dt=D.getUserAgent();dt&&!dt.includes("iPhone")&&(d=dt)}catch{}g.value==="mobile"&&N(!1),W(),y()}function w(){const D=g.value==="mobile"?"desktop":"mobile";g.value=D,Wh(D),N(!0)}function N(D=!1){const dt=f.value;if(!dt)return;const lt=g.value==="mobile"?Tr:d;if(typeof dt.setUserAgent=="function"&&lt)try{dt.setUserAgent(lt)}catch(rt){console.warn("[WebviewPeekDrawer] setUserAgent error:",rt)}if(D&&typeof dt.reload=="function")try{dt.reload()}catch(rt){console.warn("[WebviewPeekDrawer] reload error:",rt)}}function F(){r.value=!0}function j(){if(r.value=!1,y(),f.value&&typeof f.value.getURL=="function"){const D=f.value.getURL();D&&D!=="about:blank"&&(s.value=D,l.value=D)}}function J(D){D!=null&&D.url&&(s.value=D.url,l.value=D.url),y()}function $(D){D!=null&&D.url&&(s.value=D.url,l.value=D.url),y()}function O(D){D&&D.url&&(D.preventDefault(),f.value&&typeof f.value.loadURL=="function"&&f.value.loadURL(D.url))}function y(){const D=f.value;D&&(typeof D.canGoBack=="function"&&(a.value=D.canGoBack()),typeof D.canGoForward=="function"&&(c.value=D.canGoForward()))}function V(){f.value&&typeof f.value.goBack=="function"&&f.value.goBack()}function X(){f.value&&typeof f.value.goForward=="function"&&f.value.goForward()}function P(){f.value&&typeof f.value.reload=="function"&&f.value.reload()}function U(){let D=l.value.trim();D&&(/^https?:\/\//i.test(D)||(D=`https://${D}`),s.value=D,l.value=D,f.value&&typeof f.value.loadURL=="function"&&f.value.loadURL(D))}function W(){const D=f.value;if(D&&typeof D.setZoomFactor=="function")try{D.setZoomFactor(u.value)}catch(dt){console.warn("[WebviewPeekDrawer] setZoomFactor error:",dt)}}function tt(){u.value=Math.min(2.5,Math.round((u.value+.1)*10)/10),W()}function B(){u.value=Math.max(.5,Math.round((u.value-.1)*10)/10),W()}function M(){u.value=1,W()}function Y(D){D.preventDefault(),D.deltaY<0?tt():D.deltaY>0&&B()}async function Z(){if(typeof navigator<"u"&&navigator.clipboard)try{await navigator.clipboard.writeText(s.value),m.value=!0,setTimeout(()=>{m.value=!1},2e3)}catch(D){console.warn("Copy url failed:",D)}}function Q(){var dt;const D=s.value;if(typeof window<"u"){const lt=$e("electron");(dt=lt==null?void 0:lt.shell)!=null&&dt.openExternal?lt.shell.openExternal(D).catch(()=>{window.open(D,"_blank")}):window.open(D,"_blank")}e("external-jump",D)}return(D,dt)=>{const lt=bd("webview");return ot(),st("div",Ah,[h("div",Bh,[h("div",Th,[h("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s",disabled:!a.value,"aria-label":"后退",onClick:V},[ut(ft,{name:"arrow-left"})],8,Eh),h("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s",disabled:!c.value,"aria-label":"前进",onClick:X},[ut(ft,{name:"arrow-right"})],8,Mh),h("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":r.value?"正在加载...":"刷新页面",onClick:P},[ut(ft,{name:"refresh"})],8,Lh)]),h("div",Dh,[Te(h("input",{"onUpdate:modelValue":dt[0]||(dt[0]=rt=>l.value=rt),type:"text",class:"b3-text-field spm-url-input",placeholder:"https://...",spellcheck:"false",onKeydown:Lu(U,["enter"])},null,544),[[vo,l.value]]),h("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":m.value?"已复制地址！":"复制网址",onClick:Z},[ut(ft,{name:"copy"})],8,Ph)]),h("div",Oh,[h("button",{class:At(["spm-icon-btn spm-mode-toggle b3-tooltips b3-tooltips__s",{"is-active":g.value==="mobile"}]),"aria-label":g.value==="mobile"?"当前为手机视图，点击切换为桌面视图":"当前为桌面视图，点击切换为手机视图",onClick:w},[ut(ft,{name:g.value==="mobile"?"mobile":"desktop"},null,8,["name"])],10,Rh),h("div",zh,[h("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"缩小 (Ctrl + -)",disabled:u.value<=.5,onClick:B},[ut(ft,{name:"minus"})],8,Nh),h("button",{class:"spm-zoom-badge b3-tooltips b3-tooltips__s","aria-label":"重置 100% (Ctrl + 0)",onClick:M},_t(Math.round(u.value*100))+"% ",1),h("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"放大 (Ctrl + +)",disabled:u.value>=2.5,onClick:tt},[ut(ft,{name:"plus"})],8,Fh)]),h("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"在系统默认浏览器中打开 ↗",onClick:Q},[ut(ft,{name:"external-link"}),dt[1]||(dt[1]=h("span",null,"外跳",-1))])])]),h("div",{ref_key:"containerEl",ref:v,class:At(["spm-webview-body",{"is-mobile":g.value==="mobile"}]),onWheel:Me(Y,["ctrl"])},[h("div",{class:At(["spm-webview-viewport",{"is-mobile":g.value==="mobile"}])},[o.value?(ot(),Le(lt,{key:0,ref_key:"webviewRef",ref:f,class:"spm-webview-frame",src:s.value,useragent:b.value,allowpopups:"true",partition:"persist:slidev-peek",style:{position:"absolute",top:"0",left:"0",width:"100%",height:"100%",display:"inline-flex"}},null,8,["src","useragent"])):(ot(),st("div",Hh,[h("iframe",{class:"spm-webview-fallback-frame",src:s.value,frameborder:"0",sandbox:"allow-scripts allow-same-origin allow-forms allow-popups"},null,8,jh),h("div",{class:"spm-fallback-bar"},[dt[2]||(dt[2]=h("span",null,"如页面受同源策略 (X-Frame-Options) 拦截无法显示，请",-1)),h("button",{class:"spm-icon-btn is-primary",onClick:Q}," 在新标签页中打开 ↗ ")])]))],2)],34)])}}}),qh=ze(Vh,[["__scopeId","data-v-40e35375"]]);class Kh{constructor(){xt(this,"timers",new Map)}debounce(i,e,n=150){this.cancel(i);const o=setTimeout(()=>{this.timers.delete(i),e()},n);this.timers.set(i,o)}cancel(i){this.timers.has(i)&&(clearTimeout(this.timers.get(i)),this.timers.delete(i))}cancelAll(){for(const i of this.timers.values())clearTimeout(i);this.timers.clear()}hasPending(i){return this.timers.has(i)}}class Gh{constructor(i){xt(this,"blockToPageMap",new Map);xt(this,"debounceCtrl",new Kh);xt(this,"activeBlockId","");xt(this,"activePageIndex",1);xt(this,"currentDocId","");xt(this,"bridge",null);i&&(this.bridge=i)}setBridge(i){this.bridge=i}setDocId(i){this.currentDocId=i}updateSlidesIndex(i){this.blockToPageMap.clear();for(const e of i){e.startBlockId&&this.blockToPageMap.set(e.startBlockId,e.pageIndex);for(const n of e.blocks)this.blockToPageMap.set(n.id,e.pageIndex)}}getPageByBlockId(i){return this.blockToPageMap.get(i)??null}onCursorFocusBlock(i){if(!i||i===this.activeBlockId)return;this.activeBlockId=i;let e=this.getPageByBlockId(i);!e&&(i===this.currentDocId||!this.currentDocId&&this.blockToPageMap.size>0)&&(e=1),e&&this.debounceCtrl.debounce("cursor-navigate",()=>{this.activePageIndex=e,this.bridge&&(this.bridge.navigatePage(e),this.bridge.highlightElement(i))},100)}getActiveBlockId(){return this.activeBlockId}setActiveBlockId(i){this.activeBlockId=i;const e=this.getPageByBlockId(i);e&&(this.activePageIndex=e)}getActivePageIndex(){return this.activePageIndex}destroy(){this.debounceCtrl.cancelAll(),this.blockToPageMap.clear(),this.bridge=null}}function Pi(t,i){var s,l;if(!t||typeof document>"u")return!1;const e=(s=globalThis.CSS)!=null&&s.escape?globalThis.CSS.escape(t):t.replace(/"/g,'\\"'),n=document.querySelector(`.protyle-wysiwyg [data-node-id="${e}"]`)||document.querySelector(`[data-node-id="${e}"]`);if(!n){if(i)try{return ht.openTab({app:i,doc:{id:t,action:["cb-get-hl","cb-get-focus","cb-get-context"]}}),!0}catch(r){console.warn("[SelectionMirror] openTab fallback failed:",r)}return!1}try{n.scrollIntoView({behavior:"smooth",block:"center",inline:"nearest"})}catch{n.scrollIntoView()}try{(l=n.focus)==null||l.call(n,{preventScroll:!0})}catch{}n.classList.add("protyle-wysiwyg--select");const o=n.style.outline;return n.style.outline="2px solid #3b82f6",n.style.transition="outline 0.3s ease",setTimeout(()=>{n.classList.remove("protyle-wysiwyg--select"),n.style.outline=o},1200),!0}function Zh(t){if(!t)return"";const i=t.split(`
`).map(l=>l.trim()).filter(Boolean);if(i.length===0)return"";if(!i.some(l=>/^#{1,6}\s+/.test(l)))return i.map(l=>re(l)).join("<br/>");const n=[];let o=[];const s=()=>{if(o.length>0){const l=o.map(r=>re(r)).join("<br/>");n.push(`<p class="slide-list-item-desc">${l}</p>`),o=[]}};for(const l of i){const r=l.match(/^(#{1,6})\s+(.*)$/);if(r){s();const a=r[1].length,c=r[2].trim();n.push(`<h${a} class="slide-list-item-title">${re(c)}</h${a}>`)}else o.push(l)}return s(),n.join(`
`)}function Yh(t){if(t.length===0)return"";const i=[],e=t[0],n=e.match(/^(#{1,6})\s+(.*)$/);if(n){const o=n[1].length,s=n[2].trim();i.push(`<h${o} class="slide-list-item-title">${re(s)}</h${o}>`)}else i.push(`<p class="slide-list-item-title">${re(e)}</p>`);if(t.length>1){const o=t.slice(1);let s=[];const l=()=>{if(s.length>0){const r=s.map(a=>re(a)).join("<br/>");i.push(`<p class="slide-list-item-desc">${r}</p>`),s=[]}};for(const r of o){const a=r.match(/^(#{1,6})\s+(.*)$/);if(a){l();const c=a[1].length,u=a[2].trim();i.push(`<h${c} class="slide-list-item-title">${re(u)}</h${c}>`)}else s.push(r)}l()}return i.join(`
`)+(i.length>0?`
`:"")}function ua(t,i,e){var g,d,b,f;const n=t.split(`
`);if(!n.some(v=>/^(\s*)([-*+]|\d+\.)\s+/.test(v)))return null;const s=[],l=[];let r=!1;for(let v=0;v<n.length;v++){const k=n[v];if(!k.trim())continue;const S=k.match(/^(\s*)[-*+]\s+\[([ xX])\]\s+(.*)$/);if(S){const I=S[1].length,w=Math.floor(I/2);l.push({type:"task",level:w,checked:S[2].toLowerCase()==="x",text:S[3],media:[]});continue}const x=k.match(/^(\s*)[-*+]\s+(.*)$/);if(x){const I=x[1].length,w=Math.floor(I/2);l.push({type:"unordered",level:w,text:x[2],media:[]});continue}const A=k.match(/^(\s*)\d+\.\s+(.*)$/);if(A){l.length===0&&(r=!0);const I=A[1].length,w=Math.floor(I/2);l.push({type:"ordered",level:w,text:A[2],media:[]});continue}const T=k.trim();if(!(!T||/^\{:.*?\}$/.test(T)))if(l.length>0){const I=T.match(/^!\[(.*?)\]\((.*?)\)(?:\{:?[^}]*\})?$/);if(I){const F=/\.gif(?:\?|$)/i.test(I[2])?"list-item-gif":"list-item-img";l[l.length-1].media||(l[l.length-1].media=[]),l[l.length-1].media.push(`<div class="slide-list-media"><img alt="${ce(I[1])}" src="${I[2]}" class="${F}" /></div>`);continue}if(T.match(/^<img\b[\s\S]*?\/?>$/i)){const N=T.replace(/\s+style="[^"]*"/gi,"");l[l.length-1].media||(l[l.length-1].media=[]),l[l.length-1].media.push(`<div class="slide-list-media">${N}</div>`);continue}if(/<video\b/i.test(T)){let N=T;if(!/<\/video>/i.test(N))for(;v+1<n.length&&!/<\/video>/i.test(N);)v++,N+=" "+n[v].trim();const F=((g=e==null?void 0:e.attributes)==null?void 0:g["custom-slidev-autoplay"])==="true"||/autoplay/i.test(N),j=((d=e==null?void 0:e.attributes)==null?void 0:d["custom-slidev-loop"])==="true"||/loop/i.test(N),J=((b=e==null?void 0:e.attributes)==null?void 0:b["custom-slidev-muted"])==="true"||F||/muted/i.test(N),$=((f=e==null?void 0:e.attributes)==null?void 0:f["custom-slidev-controls"])==="false",O=N.match(/\bsrc=["']([^"']+)["']/i),y=O?O[1]:"",V=['class="slide-video-player"'];$||V.push("controls"),F&&(V.push("autoplay"),V.push("playsinline")),j&&V.push("loop"),J&&V.push("muted"),V.push('preload="metadata"'),y&&V.push(`src="${y}"`);const X=N.match(/<video[^>]*>([\s\S]*?)<\/video>/i);let P=X?X[1].trim():"";!P&&y&&(P=`<source src="${y}" type="video/mp4" />您的浏览器不支持视频播放。`),l[l.length-1].media||(l[l.length-1].media=[]),l[l.length-1].media.push(`<div class="slide-list-media slide-video-container slide-media-container" data-autoplay="${F?"true":"false"}" data-muted="${J?"true":"false"}"><video ${V.join(" ")}>${P}</video></div>`);continue}l[l.length-1].text+=`
`+T}else s.push(T)}if(l.length===0)return null;const a=r?"ol":"ul",c=(i==null?void 0:i.listClassName)||(r?"pdf-list pdf-list--ordered":"pdf-list pdf-list--unordered"),u=l.map(v=>{const k=Zh(v.text),S=v.media&&v.media.length>0?`
${v.media.join(`
`)}`:"",x=v.level||0,A=x>0?` style="margin-left:${(x*1.25).toFixed(2)}em;${v.type==="unordered"?`list-style-type:${x%2===1?"circle":"square"} !important;`:""}"`:"",T=x>0?" slide-list-item--nested":"";if(v.type==="task"){const w=v.checked?' checked=""':"";return`<li class="pdf-task-item${T}"${A}><label><input type="checkbox" disabled=""${w}/> <span>${k}</span></label>${S}</li>`}return`<li${T?` class="${T.trim()}"`:""}${A}>${k}${S}</li>`}).join(`
`);return`${Yh(s)}<${a} class="${c}">
${u}
</${a}>`}function Jh(t,i,e){const n=(i==null?void 0:i.containerClassName)||"pdf-block",o=t.split(/\r?\n/),s=[];let l=[];for(let c=0;c<o.length;c++){const u=o[c],m=u.trim();if(/^#{1,6}\s+/.test(m)){l.length>0&&(s.push(l.join(`
`)),l=[]),s.push(m);continue}if(!m){l.length>0&&(s.push(l.join(`
`)),l=[]);continue}if(/^!\[.*?\]\(.*?\)$/.test(m)){l.length>0&&(s.push(l.join(`
`)),l=[]),s.push(m);continue}if(/<video\b/i.test(m)){l.length>0&&(s.push(l.join(`
`)),l=[]);let g=m;if(!/<\/video>/i.test(g))for(;c+1<o.length&&!/<\/video>/i.test(g);)c++,g+=`
`+o[c];s.push(g);continue}l.push(u)}l.length>0&&s.push(l.join(`
`));let r=!0;return s.map(c=>{var b,f,v,k;const u=c.trim();if(!u)return"";const m=u.match(/^(#{1,6})\s+(.*)$/);if(m){r=!1;const S=m[1].length;return`<h${S} class="slide-list-item-title">${re(m[2].trim())}</h${S}>`}const g=u.match(/^!\[(.*?)\]\((.*?)\)$/);if(g){const S=/\.gif(?:\?|$)/i.test(g[2]),x=(i==null?void 0:i.imageClassName)||(S?"list-item-gif":"pdf-image slide-media-img");return`<div class="${n} ${n}--image slide-media-block slide-media-container slide-list-media"><img alt="${ce(g[1])}" src="${g[2]}" class="${x}" /></div>`}if(/<video\b/i.test(u)){const S=((b=e==null?void 0:e.attributes)==null?void 0:b["custom-slidev-autoplay"])==="true"||/autoplay/i.test(u),x=((f=e==null?void 0:e.attributes)==null?void 0:f["custom-slidev-loop"])==="true"||/loop/i.test(u),A=((v=e==null?void 0:e.attributes)==null?void 0:v["custom-slidev-muted"])==="true"||S||/muted/i.test(u),T=((k=e==null?void 0:e.attributes)==null?void 0:k["custom-slidev-controls"])==="false",I=u.match(/\bsrc=["']([^"']+)["']/i),w=I?I[1]:"",N=['class="slide-video-player"'];T||N.push("controls"),S&&N.push("autoplay playsinline"),x&&N.push("loop"),A&&N.push("muted"),N.push('preload="metadata"'),w&&N.push(`src="${w}"`);const F=u.match(/<video[^>]*>([\s\S]*?)<\/video>/i);let j=F?F[1].trim():"";return!j&&w&&(j=`<source src="${w}" type="video/mp4" />您的浏览器不支持视频播放。`),`<div class="${n} ${n}--video slide-media-block slide-video-container slide-media-container" data-autoplay="${S?"true":"false"}" data-muted="${A?"true":"false"}"><video ${N.join(" ")}>${j}</video></div>`}const d=ua(u,i,e);if(d)return r=!1,d;if(r){r=!1;const S=u.split(/\r?\n/).map(I=>I.trim()).filter(Boolean);if(S.length===1)return`<p class="slide-list-item-title">${re(S[0])}</p>`;const x=S[0],T=S.slice(1).map(I=>re(I)).join("<br/>");return`<p class="slide-list-item-title">${re(x)}</p>
<p class="slide-list-item-desc">${T}</p>`}return`<p class="slide-list-item-desc">${re(u)}</p>`}).filter(Boolean).join(`
`)}function Go(t){if(!t)return!1;if(t.type==="h"||t.type==="NodeHeading")return!0;const i=(t.rawMarkdown||t.content||"").trim();return/^#{1,6}\s+/.test(i)}function Xh(t,i){var r,a,c,u,m,g,d,b;const e=((r=t.frontmatter)==null?void 0:r.layout)||"default",o=(t.blocks||[]).filter(f=>f.slot!=="slot-divider-right"),l=e==="cover"?null:o.find(Go);if(e==="two-cols"){const f=o.some(J=>J.slot==="right");let v=[],k=[];if(f)v=o.filter(J=>J.slot!=="right"),k=o.filter(J=>J.slot==="right");else{const J=Math.ceil(o.length/2);v=o.slice(0,J),k=o.slice(J)}const S=J=>{const $=J.filter(O=>!!(O.rawMarkdown||O.content||"").trim());if($.length>0){const O=$[0],y=(O.rawMarkdown||O.content||"").trim();(Ri(O)||/^(?:[-*+]|\d+\.)\s+/.test(y))&&(O.rawMarkdown=bn(O.rawMarkdown||O.content||""),O.content=O.rawMarkdown)}};S(v),S(k);const x=v.map(J=>fi(J,i)).join(`
`),A=k.map(J=>fi(J,i)).join(`
`),T="pdf-two-cols-wrapper layout-two-cols-grid",I=(a=t.frontmatter)!=null&&a.layoutClass?` ${t.frontmatter.layoutClass}`:"",w="pdf-col pdf-col--left",N="pdf-col pdf-col--right",j=`style="grid-template-columns: ${qo((c=t.frontmatter)==null?void 0:c.layoutRatio,2)};"`;return`
      <div class="${T}${I}" ${j}>
        <div class="${w}">${x}</div>
        <div class="${N}">${A}</div>
      </div>
    `}if(e==="clover"||$n(e)){const f=e==="clover";let v=[];const k=o.filter(V=>V.slot==="header");if(k.length>0)v=k;else if(o.length>0){const V=o.find(X=>X.type==="h"&&(!X.slot||X.slot==="default"));V&&(v=[V])}const S=o.filter(V=>!v.includes(V));let x=2;if(f)x=4;else if(e==="three-cols-header")x=3;else if(e==="two-cols-header")x=2;else{let V=0;for(const X of S){const P=(X.slot||"").match(/^col-(\d+)$/i);P&&(V=Math.max(V,parseInt(P[1],10)))}if(V>=2)x=V;else if((u=t.frontmatter)!=null&&u.layoutRatio){const X=t.frontmatter.layoutRatio.trim();if(X.includes(":")){const P=X.split(":").map(U=>parseFloat(U.trim())).filter(U=>!isNaN(U)&&U>0);P.length>=2&&(x=P.length)}else{const P=X.split(/\s+/).filter(Boolean);P.length>=2&&(x=P.length)}}else S.length===1&&S[0].children&&S[0].children.length>=2&&(x=Math.min(6,S[0].children.length))}const A=oa(S,x),T=S.some(V=>V.slot&&/^(?:col-\d+|left|right)$/i.test(V.slot)),I=e==="clover"||e==="two-cols-header"||e==="three-cols-header"||$n(e)&&T,w=V=>{const X=V.filter(U=>!!(U.rawMarkdown||U.content||"").trim());if(I&&X.length>0){const U=X[0],W=(U.rawMarkdown||U.content||"").trim();(Ri(U)||/^(?:[-*+]|\d+\.)\s+/.test(W))&&(U.rawMarkdown=bn(U.rawMarkdown||U.content||""),U.content=U.rawMarkdown),U.isColFirst=!0}const P=I?X.find(Go):null;return X.map(U=>fi(U,{...i,extraClassName:U===P?"slidev-col-first-heading-block":""})).join(`
`)},N=v.find(Go),F=v.map(V=>fi(V,{...i,extraClassName:V===N?"slidev-page-first-heading-block":""})).join(`
`),j=f?"repeat(2, minmax(0, 1fr))":qo((m=t.frontmatter)==null?void 0:m.layoutRatio,x),J=f?`style="grid-template-columns: ${j}; grid-template-rows: repeat(2, minmax(0, 1fr));"`:`style="grid-template-columns: ${j};"`,$=[f?"layout-clover-container":"layout-cols-header-container",x===2?"layout-two-cols-header-container":"",x===3?"layout-three-cols-header-container":"",`layout-${e}-container`,I?"has-superblock-cols":""].filter(Boolean).join(" "),O=[f?"layout-clover-grid pdf-clover-wrapper":"layout-cols-wrapper layout-cols-grid",x===2?"pdf-two-cols-wrapper layout-two-cols-grid":"",x===3?"pdf-three-cols-wrapper layout-three-cols-grid":"",I?"has-superblock-cols":""].filter(Boolean).join(" "),y=A.map((V,X)=>{const P=X+1;return`<div class="${["pdf-col",x===2&&P===1?"pdf-col--left":"",x===2&&P===2?"pdf-col--right":"",`pdf-col--${P}`,`col-${P}`].filter(Boolean).join(" ")}">${w(V)}</div>`}).join(`
`);return`
      <div class="${$}">
        <div class="layout-header-section">${F}</div>
        <div class="${O}" ${J}>
          ${y}
        </div>
      </div>
    `}if(e==="image-right"||e==="image-left"){const f=e==="image-right",v=o.map(I=>fi(I,i)).join(`
`),k=((g=t.frontmatter)==null?void 0:g.image)||((d=t.frontmatter)==null?void 0:d.background)||"",S=`<div class="pdf-image-col" style="background-image:url('${ce(k)}');background-size:cover;background-position:center;background-repeat:no-repeat;width:100%;height:100%;position:relative;overflow:hidden;"><img src="${ce(k)}" style="width:100%;height:100%;object-fit:cover;object-position:center;display:block;" onerror="this.style.display='none'" alt="Slide cover" /></div>`,x=`<div class="pdf-content-col" style="padding:48px 56px;display:flex;flex-direction:column;justify-content:flex-start;height:100%;box-sizing:border-box;overflow-y:auto;">${v}</div>`,A=f?`${x}
${S}`:`${S}
${x}`;return`
      <div class="layout-image-cols-grid" style="display:grid;grid-template-columns:${qo((b=t.frontmatter)==null?void 0:b.layoutRatio,2)};grid-template-rows:100%;width:100%;height:100%;position:absolute;top:0;left:0;right:0;bottom:0;box-sizing:border-box;">
        ${A}
      </div>
    `}return e==="fact"?`<div class="layout-fact-container">${o.map(v=>fi(v,i)).join(`
`)}</div>`:e==="cover"?`<div class="layout-cover-container">${o.map(v=>fi(v,i)).join(`
`)}</div>`:o.map(f=>fi(f,{...i,extraClassName:f===l?"slidev-page-first-heading-block":""})).join(`
`)}function ce(t){return t?t.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&#039;"):""}function Qh(t){if(!t||t.trim()===""||t.trim()==="all")return"all";const i=new Set,e=t.split("|");for(const n of e){const o=n.trim();if(o==="all")return"all";if(o.includes("-")){const[s,l]=o.split("-"),r=parseInt(s,10),a=parseInt(l,10);if(!isNaN(r)&&!isNaN(a))for(let c=Math.min(r,a);c<=Math.max(r,a);c++)i.add(c)}else{const s=parseInt(o,10);isNaN(s)||i.add(s)}}return i}const tm=new Set(["kbd","mark","sub","sup","span","a","br","b","i","u","s","del","em","strong","code","small","abbr","ruby","rt","rp","v-mark","img","video","source","picture"]);function re(t){if(!t)return"";const i=ea(t),e=[],n=i.replace(/<\/?([a-zA-Z0-9_-]+)(?:\s+[^<>]*)?\/?>/g,(s,l)=>{const r=l.toLowerCase();if(!tm.has(r)||/on\w+\s*=|javascript:/i.test(s))return s;if(r==="v-mark"){const a=s.match(/type=["']?([a-zA-Z-]+)["']?/),c=a?a[1]:"circle";return s.startsWith("</")?e.push("</mark>"):e.push(`<mark class="v-mark v-mark--${c}">`),`%%SAFE_HTML_${e.length-1}%%`}return e.push(s),`%%SAFE_HTML_${e.length-1}%%`});let o=ce(n);return o=o.replace(/\(\(([0-9a-zA-Z-]+)(?:\s*(?:&#039;([^&#]*)&#039;|&quot;([^&]*)&quot;|'([^']*)'|"([^"]*)"|([^\)]+?)))?\s*\)\)/g,(s,l,r,a,c,u,m)=>{const d=(r??a??c??u??m??"").trim()||`Ref(${l.slice(0,8)})`;return`<a href="siyuan://blocks/${l}" data-ref-id="${l}" class="slidev-ref-tag">🔗 ${d}</a>`}),o=o.replace(/\$([^$\n]+)\$/g,'<span class="katex-inline font-math"><em>$1</em></span>'),o=o.replace(/!\[(.*?)\]\((.*?)\)/g,(s,l,r)=>{const c=/\.gif(?:\?|$)/i.test(r)?"slide-inline-img list-item-gif":"slide-inline-img";return`<img alt="${l}" src="${r}" class="${c}" />`}),o=o.replace(/\[(.*?)\]\((.*?)\)/g,(s,l,r)=>{if(r.startsWith("siyuan://blocks/")){const a=r.replace("siyuan://blocks/","").split("?")[0];return`<a href="${r}" data-ref-id="${a}" class="slidev-ref-tag">🔗 ${l}</a>`}return`<a href="${r}" target="_blank" rel="noopener noreferrer" class="slidev-link">${l}</a>`}),o=o.replace(/(^|[\s(])(siyuan:\/\/blocks\/([0-9a-zA-Z-]+)(?:\?[^\s\)]*)?)/g,(s,l,r,a)=>`${l}<a href="${r}" data-ref-id="${a}" class="slidev-ref-tag">🔗 ${r}</a>`),o=o.replace(/\*\*(.*?)\*\*/g,"<strong>$1</strong>"),o=o.replace(/\*(.*?)\*/g,"<em>$1</em>"),o=o.replace(/~~(.*?)~~/g,"<del>$1</del>"),o=o.replace(/`([^`]+)`/g,"<code>$1</code>"),o=o.replace(/%%SAFE_HTML_(\d+)%%/g,(s,l)=>{const r=parseInt(l,10);return e[r]||""}),o}function em(t,i="pdf-table"){if(t.length<2)return"";const e=t.map(a=>a.trim().replace(/^\|/,"").replace(/\|$/,"").split("|").map(c=>c.trim())),n=e[0];let o=[],s=1;t.length>=2&&e[1].every(a=>/^:?-+:?$/.test(a))&&(o=e[1].map(a=>a.startsWith(":")&&a.endsWith(":")?"center":a.endsWith(":")?"right":"left"),s=2);const l=`<thead><tr>${n.map((a,c)=>`<th${o[c]?` style="text-align: ${o[c]}"`:""}>${re(a)}</th>`).join("")}</tr></thead>`,r=e.slice(s).map(a=>`<tr>${a.map((c,u)=>`<td${o[u]?` style="text-align: ${o[u]}"`:""}>${re(c)}</td>`).join("")}</tr>`).join("");return`<table class="${i}">${l}<tbody>${r}</tbody></table>`}function Zo(t){return String(t||"").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;")}function Er(t,i="ts"){if(!t)return"";if(t.trim().startsWith("//"))return`<span class="token-comment">${Zo(t)}</span>`;const e=[];function n(s,l){return e.push(`<span class="${s}">${Zo(l)}</span>`),`__TOK_${e.length-1}__`}let o=t.replace(/(['"`])(.*?)\1/g,(s,l,r)=>n("token-string",`${l}${r}${l}`));return o=o.replace(/\b(import|export|from|const|let|var|function|return|default|type|interface|class|new|async|await)\b/g,s=>n("token-keyword",s)),o=o.replace(/\b(computed|ref|number|string|boolean|void|Array)\b/g,s=>n("token-type",s)),o=o.replace(/\b(\d+)\b/g,s=>n("token-number",s)),o=Zo(o),o=o.replace(/__TOK_(\d+)__/g,(s,l)=>e[parseInt(l,10)]||""),o}function im(t,i){if(!t)return null;const e=t.frontmatter||{};if(e.hideInToc===!0||e.hideInToc==="true")return null;let n=(e.title||"").trim(),o=e.level?parseInt(e.level,10):0;if(!n){const s=t.blocks||[];for(const l of s){const a=(l.rawMarkdown||l.content||"").trim().match(/^(#{1,6})\s+(.*)$/);if(a){o||(o=a[1].length),n=a[2].trim();break}}}return n?((!o||isNaN(o))&&(o=1),{pageIndex:t.pageIndex||i,title:n,level:o}):null}function nm(t,i=1,e={}){const n=e.minDepth!==void 0?Number(e.minDepth):1,o=e.maxDepth!==void 0?Number(e.maxDepth):1/0,s=[];Array.isArray(t)&&t.forEach((c,u)=>{const m=im(c,u+1);m&&s.push(m)});const l=[];let r=null;for(const c of s){const u={...c,active:c.pageIndex===i,hasActiveChild:!1,children:[]};c.level===1||l.length===0?(l.push(u),r=u):r?(u.active&&(r.hasActiveChild=!0),r.children.push(u)):l.push(u)}function a(c,u=1){if(u>o)return[];const m=[];for(const g of c){const d=a(g.children,u+1);u>=n?m.push({...g,children:d}):m.push(...d)}return m}return a(l,1)}function om(t,i=1,e={}){const n=nm(t,i,e),o=e.columns?Number(e.columns):1,s=o>1?` style="column-count: ${o};"`:"",l=e.textSm?" text-sm":"";function r(c,u=1){if(!c||c.length===0)return"";const m=`slidev-toc-list slidev-toc-list-level-${u}`,g=c.map(d=>{const b=d.active?" slidev-toc-item-active":d.hasActiveChild?" slidev-toc-item-parent-active":"",f=d.children&&d.children.length>0?r(d.children,u+1):"";let v=re(d.title);return v.includes("LaTeX")&&(v=v.replace(/\$\\LaTeX\$/g,'<span class="font-math">L<sup>A</sup>T<sub>E</sub>X</span>')),`
        <li class="slidev-toc-item${b}" data-page="${d.pageIndex}">
          <a class="slidev-toc-link" href="javascript:void(0)">
            <span class="slidev-toc-title">${v}</span>
          </a>
          ${f}
        </li>
      `}).join("");return`<ol class="${m}">${g}</ol>`}const a=r(n,1);return`<div class="slidev-toc${l}"${s}>${a}</div>`}function fi(t,i){var x,A,T,I,w,N,F,j,J,$;let e="",n="",o="";const s=[];(x=t.motion)!=null&&x.preset&&t.motion.preset!=="none"&&(e=` slidev-motion-${t.motion.preset.toLowerCase()}`,typeof t.motion.duration=="number"&&t.motion.duration>0&&s.push(`--motion-duration:${t.motion.duration}ms`),typeof t.motion.delay=="number"&&t.motion.delay>0&&s.push(`--motion-delay:${t.motion.delay}ms`));const l=((A=t.attributes)==null?void 0:A.style)||"";l&&(s.push(l),o=" slide-styled-block"),s.length>0&&(n=` style="${ce(s.join(";"))}"`);const r=(i==null?void 0:i.containerClassName)||"pdf-block",a=i!=null&&i.extraClassName?` ${i.extraClassName}`:"",c=`${r}${e}${o}${a}`,u=(t.rawMarkdown||t.content||"").trim();if(!u)return`<div class="${c}"${n}></div>`;if(u.includes('class="slidev-block-ref"')||u.includes('class="slidev-ref-tag"'))return`<div class="${c}"${n}>${u}</div>`;if(u.startsWith("$$")&&u.endsWith("$$")){const O=u.slice(2,-2).trim();return`<div class="${c} katex-display-container"${n}><div class="katex-display font-math"><em>${ce(O)}</em></div></div>`}const m=u.match(/^(#{1,6})\s+(.*)$/);if(m){const O=m[1].length,y=re(m[2]),X=!!(t.isColFirst||t.type==="i"&&((T=i==null?void 0:i.extraClassName)!=null&&T.includes("slidev-col-first-heading-block")))?' class="slide-list-item-title"':"";return`<div class="${c}"${n}><h${O}${X}>${y}</h${O}></div>`}if(u.startsWith(":::")){const O=u.split(`
`),V=O[0].replace(/^:::\s*/,"").trim()||"info",X=O.slice(1,O[O.length-1].startsWith(":::")?-1:void 0).join(`
`),P=(i==null?void 0:i.calloutClassName)||"pdf-callout";return`<div class="${c}"${n}><div class="${P} ${P}--${V}"><div class="${P}-title">${V.toUpperCase()}</div><div class="${P}-body">${re(X)}</div></div></div>`}if(u.startsWith("<<<")){const V=`// Inside ./snippets/external.ts
export function emptyArray<T>(length: number) {
  return Array.from<T>({ length })
}`.split(`
`).map((W,tt)=>`<span class="code-line shiki-focus"><span class="line-no">${tt+1}</span><span class="line-content">${Er(W,"ts")}</span></span>`).join(`
`),X=(i==null?void 0:i.codeClassName)||"pdf-code shiki-container",P=((I=t.attrs)==null?void 0:I["custom-slidev-max-height"])||t.maxHeight||"",U=P?` style="max-height:${ce(P)};overflow-y:auto;"`:"";return`<div class="${c}"${n}><pre class="${X}"${U}><span class="lang-badge">TS</span><code>${V}</code></pre></div>`}if(u.startsWith("<style")||u.startsWith("<!-- Inline style -->")||u.startsWith(`<!--
Notes`))return"";if(u.startsWith("```")){const O=u.split(`
`),y=O[0].slice(3).trim(),V=y.match(/^([^\s{\[]+)/),X=V?V[1]:"",P=y.match(/\[([^\]]+)\]/),U=P?P[1]:"",W=y.includes("twoslash"),tt=t.shikiLines||((w=y.match(/\{([^}]+)\}/))==null?void 0:w[1])||"",B=Qh(tt),M=O.length>2?O[O.length-1]==="```"?O.slice(1,-1):O.slice(1):[u.slice(3).replace(/```$/,"")],Y=(i==null?void 0:i.codeClassName)||"pdf-code shiki-container",Z=U?`${Y} has-filename`:Y,Q=B!=="all",D=M.map((nt,E)=>{const z=E+1,H=B==="all"||B.has(z)?"code-line shiki-focus":Q?"code-line shiki-dimmed":"code-line";let _=(i==null?void 0:i.highlight)===!0?Er(nt,X):ce(nt);return W&&nt.includes("doubled.value = 2")?(_=_.replace(/(\bvalue\b)/,'<span class="twoslash-error-wavy">$1</span>'),`<span class="${H}"><span class="line-no">${z}</span><span class="line-content">${_}</span></span>
<div class="twoslash-popup-error"><span style="color:#ef4444;font-weight:bold;margin-right:4px;">✕</span> Cannot assign to 'value' because it is a read-only property.</div>`):`<span class="${H}"><span class="line-no">${z}</span><span class="line-content">${_}</span></span>`}).join(`
`),dt=X?`<span class="lang-badge">${ce(X)}</span>`:"",lt=U?`<span class="code-filename">${ce(U)}</span>`:"",rt=((N=t.attrs)==null?void 0:N["custom-slidev-max-height"])||t.maxHeight||"",gt=rt?` style="max-height:${ce(rt)};overflow-y:auto;"`:"";return`<div class="${c}"${n}><pre class="${Z}"${gt}>${lt}${dt}<code>${D}</code></pre></div>`}if(u.includes("|")&&u.split(`
`).filter(O=>O.trim().startsWith("|")).length>=2){const O=u.split(`
`).filter(V=>V.trim().startsWith("|")),y=em(O,i==null?void 0:i.tableClassName);return`<div class="${c}"${n}>${y}</div>`}if(u.startsWith("> ")){const O=(i==null?void 0:i.quoteClassName)||"pdf-quote";return`<div class="${c}"${n}><blockquote class="${O}"><p>${re(u.slice(2))}</p></blockquote></div>`}const g=/<video\b/i.test(u)||t.type==="video"||t.type==="NodeVideo",d=/^(\s*)([-*+]|\d+\.)\s+/m.test(u),b=/(?:^|\n)\s*#{1,6}\s+/.test(u);if(g&&!d&&!b&&!u.includes(`
`)){const O=((F=t.attributes)==null?void 0:F["custom-slidev-autoplay"])==="true"||/autoplay/i.test(u),y=((j=t.attributes)==null?void 0:j["custom-slidev-loop"])==="true"||/loop/i.test(u),V=((J=t.attributes)==null?void 0:J["custom-slidev-muted"])==="true"||O||/muted/i.test(u),X=(($=t.attributes)==null?void 0:$["custom-slidev-controls"])==="false",P=u.match(/\bsrc=["']([^"']+)["']/i),U=P?P[1]:"",W=['class="slide-video-player"'];X||W.push("controls"),O&&(W.push("autoplay"),W.push("playsinline")),y&&W.push("loop"),V&&W.push("muted"),W.push('preload="metadata"'),U&&W.push(`src="${U}"`);const tt=u.match(/<video[^>]*>([\s\S]*?)<\/video>/i);let B=tt?tt[1].trim():"";return!B&&U&&(B=`<source src="${U}" type="video/mp4" />您的浏览器不支持视频播放。`),`<div class="${c} ${c}--video slide-media-block slide-video-container slide-media-container" data-autoplay="${O?"true":"false"}" data-muted="${V?"true":"false"}"${n}><video ${W.join(" ")}>${B}</video></div>`}const f=u.match(/^!\[(.*?)\]\((.*?)\)$/);if(f){const O=(i==null?void 0:i.imageClassName)||"pdf-image slide-media-img";return`<div class="${c} ${c}--image slide-media-block slide-media-container"${n}><img alt="${ce(f[1])}" src="${f[2]}" class="${O}" /></div>`}const v=ua(u,i,t);if(v)return`<div class="${c} pdf-list-item"${n}>${v}</div>`;if(/<(?:Toc|toc)\b/i.test(u)&&!u.startsWith("```")){const O=u.match(/minDepth=["']?(\d+)["']?/i),y=u.match(/maxDepth=["']?(\d+)["']?/i),V=u.match(/columns=["']?(\d+)["']?/i),X=(i==null?void 0:i.allSlides)||[];return`<div class="${c}"${n}>${om(X,(i==null?void 0:i.currentPageIndex)||1,{minDepth:O?parseInt(O[1],10):1,maxDepth:y?parseInt(y[1],10):1/0,columns:V?parseInt(V[1],10):1,textSm:u.includes("text-sm")})}</div>`}if(u.includes(`
`)||b){const O=Jh(u,i,t);if(O)return`<div class="${c}"${n}>${O}</div>`}const S=!!t.isColFirst?' class="slide-list-item-title"':"";return`<div class="${c}"${n}><p${S}>${re(u)}</p></div>`}function sm(t){return`
    ${kn(t)}

    :root {
      --slide-bg: #ffffff;
      --slide-text: #1a1a1a;
      --slide-accent: #3b82f6;
      --slide-font: system-ui, -apple-system, sans-serif;
    }
    [data-theme="dark"] {
      --slide-bg: #121214;
      --slide-text: #e2e8f0;
      --slide-accent: #60a5fa;
    }

    /* 1. 默认科技主题 Default */
    [data-slidev-theme="default"],
    .slidev-theme-default {
      --slide-font: system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "PingFang SC", "Microsoft YaHei", sans-serif;
      --slide-accent: #10b981;
    }
    [data-theme="light"][data-slidev-theme="default"],
    [data-theme="light"] .slidev-theme-default {
      --slide-bg: #ffffff;
      --slide-text: #1e293b;
      --slide-accent: #059669;
    }
    [data-theme="dark"][data-slidev-theme="default"],
    [data-theme="dark"] .slidev-theme-default {
      --slide-bg: #121214;
      --slide-text: #e2e8f0;
      --slide-accent: #34d399;
    }
    .slidev-theme-default .layout-cover h1,
    .slidev-theme-default .layout-cover .slide-block h1 {
      font-size: 3.8rem !important;
      font-weight: 800 !important;
      line-height: 1.15 !important;
      letter-spacing: -0.025em !important;
      margin-bottom: 18px !important;
      background: linear-gradient(135deg, #10b981, #06b6d4) !important;
      -webkit-background-clip: text !important;
      -webkit-text-fill-color: transparent !important;
    }
    .slidev-theme-default .layout-cover h2,
    .slidev-theme-default .layout-cover .slide-block h2 {
      font-size: 1.85rem !important;
      font-weight: 600 !important;
      opacity: 0.85 !important;
      margin-bottom: 12px !important;
    }
    .slidev-theme-default .layout-cover p,
    .slidev-theme-default .layout-cover .slide-block p {
      font-size: 1.45rem !important;
      line-height: 1.5 !important;
      opacity: 0.85 !important;
    }

    /* 2. 优雅衬线主题 Seriph */
    [data-slidev-theme="seriph"],
    .slidev-theme-seriph {
      --slide-font: "PT Serif", "Charter", "Georgia", "Cambria", "Times New Roman", "Source Han Serif SC", "Noto Serif SC", "Songti SC", "SimSun", serif;
      --slide-accent: #b45309;
      letter-spacing: 0.015em;
    }
    [data-theme="light"][data-slidev-theme="seriph"],
    [data-theme="light"] .slidev-theme-seriph {
      --slide-bg: #fdfbf7;
      --slide-text: #2a2521;
      --slide-accent: #b45309;
    }
    [data-theme="dark"][data-slidev-theme="seriph"],
    [data-theme="dark"] .slidev-theme-seriph {
      --slide-bg: #1c1a17;
      --slide-text: #e8e3d9;
      --slide-accent: #f59e0b;
    }
    .slidev-theme-seriph,
    .slidev-theme-seriph .slide-content {
      font-family: var(--slide-font) !important;
      line-height: 1.72;
    }
    .slidev-theme-seriph h1,
    .slidev-theme-seriph h2,
    .slidev-theme-seriph h3 {
      font-family: var(--slide-font) !important;
      letter-spacing: 0.025em;
      font-weight: 700;
    }
    .slidev-theme-seriph .layout-cover h1 {
      background: none !important;
      -webkit-background-clip: initial !important;
      -webkit-text-fill-color: initial !important;
      color: var(--slide-accent) !important;
      font-size: 3.4rem !important;
      border-bottom: 2px solid var(--slide-accent);
      display: inline-block;
      padding-bottom: 10px;
    }

    /* 3. 极简发布会主题 Apple Basic */
    [data-slidev-theme="apple-basic"],
    .slidev-theme-apple-basic {
      --slide-font: -apple-system, "SF Pro Display", "SF Pro Text", BlinkMacSystemFont, "PingFang SC", "Helvetica Neue", sans-serif;
      --slide-accent: #0071e3;
    }
    [data-theme="light"][data-slidev-theme="apple-basic"],
    [data-theme="light"] .slidev-theme-apple-basic {
      --slide-bg: #ffffff;
      --slide-text: #1d1d1f;
      --slide-accent: #0071e3;
    }
    [data-theme="dark"][data-slidev-theme="apple-basic"],
    [data-theme="dark"] .slidev-theme-apple-basic {
      --slide-bg: #000000;
      --slide-text: #f5f5f7;
      --slide-accent: #2997ff;
    }
    .slidev-theme-apple-basic,
    .slidev-theme-apple-basic .slide-content {
      font-family: var(--slide-font) !important;
    }
    .slidev-theme-apple-basic h1,
    .slidev-theme-apple-basic h2,
    .slidev-theme-apple-basic h3 {
      letter-spacing: -0.035em;
      font-weight: 800;
    }
    .slidev-theme-apple-basic .layout-cover h1 {
      background: none !important;
      -webkit-background-clip: initial !important;
      -webkit-text-fill-color: initial !important;
      color: var(--slide-text) !important;
      font-size: 3.8rem !important;
      letter-spacing: -0.04em !important;
    }
    .slidev-theme-apple-basic .layout-cover p {
      color: #86868b !important;
      font-size: 1.35rem !important;
    }

    * { box-sizing: border-box; margin: 0; padding: 0; }
    html, body {
      width: 100%; height: 100%; overflow: hidden;
      background: #0f1115; font-family: var(--slide-font);
      display: flex; justify-content: center; align-items: center;
    }
    #app { width: 100%; height: 100%; position: relative; overflow: hidden; }
    .slide-viewport {
      position: absolute; left: 50%; top: 50%;
      background: var(--slide-bg); color: var(--slide-text);
      box-shadow: 0 10px 30px rgba(0,0,0,0.5); border-radius: 8px; overflow: hidden;
      display: flex; flex-direction: column; flex-shrink: 0;
      transform: translate(-50%, -50%) scale(var(--slidev-slide-scale, 1));
      transform-origin: center center; will-change: transform;
      transition: background 0.3s ease, color 0.3s ease, border-radius 0.2s ease, box-shadow 0.2s ease;
    }
    :fullscreen .slide-viewport, .is-fullscreen .slide-viewport {
      border-radius: 0 !important; box-shadow: none !important;
    }
    .slide-content {
      position: relative;
      width: 100%;
      height: 100%;
      min-height: 100%;
      flex: 1 1 0%;
      padding: var(--slidev-padding-y, 32px) var(--slidev-padding-x, 48px);
      display: flex;
      flex-direction: column;
      overflow: hidden;
      box-sizing: border-box;
    }

    /* 间距预设风格 */
    .slide-content.spacing-compact,
    .slide-viewport[data-spacing="compact"] .slide-content,
    [data-slidev-spacing="compact"] {
      --slidev-padding-y: 20px;
      --slidev-padding-x: 36px;
      --slidev-header-gap: 10px;
      --slidev-title-margin-bottom: 6px;
    }
    .slide-content.spacing-normal,
    .slide-viewport[data-spacing="normal"] .slide-content,
    [data-slidev-spacing="normal"] {
      --slidev-padding-y: 32px;
      --slidev-padding-x: 48px;
      --slidev-header-gap: 16px;
      --slidev-title-margin-bottom: 10px;
    }
    .slide-content.spacing-loose,
    .slide-viewport[data-spacing="loose"] .slide-content,
    [data-slidev-spacing="loose"] {
      --slidev-padding-y: 48px;
      --slidev-padding-x: 56px;
      --slidev-header-gap: 24px;
      --slidev-title-margin-bottom: 16px;
    }

    .layout-cover { justify-content: center; align-items: center; text-align: center; }
    .layout-cover h1, .layout-cover .slide-block h1 { font-size: 3.8rem !important; font-weight: 800 !important; line-height: 1.15 !important; letter-spacing: -0.025em !important; margin-bottom: 16px !important; }
    .layout-cover h2, .layout-cover .slide-block h2 { font-size: 1.85rem !important; font-weight: 600 !important; opacity: 0.85 !important; margin-bottom: 12px !important; }
    .layout-cover p, .layout-cover .slide-block p { font-size: 1.45rem !important; line-height: 1.5 !important; opacity: 0.85 !important; }
    .two-cols-left, .two-cols-right { min-width: 0; width: 100%; display: flex; flex-direction: column; box-sizing: border-box; overflow-wrap: break-word; word-break: break-word; }
    .pdf-two-cols-wrapper,
    .layout-two-cols-grid,
    .layout-cols-wrapper,
    .layout-cols-grid {
      display: grid;
      grid-template-columns: var(--slide-grid-cols, minmax(0, 1fr) minmax(0, 1fr));
      grid-template-rows: minmax(0, 1fr) !important;
      gap: 32px;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      overflow: hidden !important;
    }
    .layout-cols-header-container,
    .layout-two-cols-header-container,
    .layout-three-cols-header-container,
    .layout-clover-container {
      display: flex;
      flex-direction: column;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      overflow: hidden !important;
    }
    .layout-header-section {
      width: 100%;
      margin-bottom: var(--slidev-header-gap, 16px) !important;
      flex-shrink: 0;
    }
    .layout-header-section h1,
    .layout-header-section h2,
    .layout-header-section h3 {
      margin-bottom: var(--slidev-title-margin-bottom, 10px) !important;
    }
    .pdf-three-cols-wrapper,
    .layout-three-cols-grid {
      display: grid;
      grid-template-columns: var(--slide-grid-cols, minmax(0, 1fr) minmax(0, 1fr) minmax(0, 1fr));
      grid-template-rows: minmax(0, 1fr) !important;
      gap: 24px;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      box-sizing: border-box;
      overflow: hidden !important;
    }
    .pdf-clover-wrapper,
    .layout-clover-grid {
      display: grid;
      grid-template-columns: repeat(2, minmax(0, 1fr)) !important;
      grid-template-rows: repeat(2, minmax(0, 1fr)) !important;
      gap: 20px;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      box-sizing: border-box;
      overflow: hidden !important;
    }
    .layout-clover-grid .pdf-col {
      background: transparent !important;
      border: none !important;
      box-shadow: none !important;
    }
    .pdf-col {
      display: flex;
      flex-direction: column;
      gap: 14px;
      min-width: 0;
      width: 100%;
      max-width: 100%;
      height: 100%;
      max-height: 100%;
      min-height: 0;
      justify-content: flex-start;
      box-sizing: border-box;
      overflow: hidden;
      overflow-wrap: break-word;
      word-break: break-word;
      white-space: normal;
    }
    .pdf-col * {
      overflow-wrap: break-word;
      word-break: break-word;
      box-sizing: border-box;
    }
    /* 表头多栏内超级块子块首个列表项去圆点后居中显示标题/首行文本 (仅在存在超级块分栏时生效) */
    .has-superblock-cols .pdf-col > *:first-child .slide-list-item-title,
    .has-superblock-cols .pdf-col > *:first-child :is(h1, h2, h3, h4, h5, h6),
    .has-superblock-cols .pdf-col > *:first-child p.slide-list-item-title,
    .has-superblock-cols .pdf-col > *:first-child p:first-of-type,
    .has-superblock-cols .pdf-col > *:first-child p:first-child,
    .has-superblock-cols .pdf-col > *:first-child :is(ul, ol) > li:first-child,
    .has-superblock-cols .pdf-col > *:first-child .slide-list > .slide-list-item:first-child,
    .has-superblock-cols .pdf-col > *:first-child .pdf-list > li:first-child,
    .has-superblock-cols .slidev-col-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    .has-superblock-cols .slidev-col-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      list-style: none !important;
      list-style-type: none !important;
      text-align: center !important;
      margin-left: 0 !important;
      padding-left: 0 !important;
      width: 100% !important;
    }

    /* 彻底清除首个列表项的原生圆点 Marker (仅在存在超级块分栏时生效) */
    .has-superblock-cols .pdf-col > *:first-child :is(ul, ol) > li:first-child::marker {
      content: "" !important;
      display: none !important;
    }

    /* 确保首个列表项内部内联与块级元素居中 (仅在存在超级块分栏时生效) */
    .has-superblock-cols .pdf-col > *:first-child :is(ul, ol) > li:first-child * {
      text-align: center !important;
    }

    /* 栏内说明段落与列表项：左对齐，自然阅读排版 */
    .has-superblock-cols .pdf-col .slide-list-item-desc,
    .has-superblock-cols .pdf-col li:not(:first-child) {
      text-align: left !important;
    }

    /* 全局特定标题大小规范化 (除封面外页首首个标题按 H2 1.7rem，表头多栏内首个标题按 H3 1.3rem) */
    [data-normalize-headings="true"] .slidev-page-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .slidev-page-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .slide-content:not(.layout-cover) > :is(.pdf-block, .slide-block):first-child :is(h1, h2, h3, h4, h5, h6),
    [data-normalize-headings="true"] .slide-content:not(.layout-cover) > .layout-header-section :is(.pdf-block, .slide-block):first-child :is(h1, h2, h3, h4, h5, h6),
    [data-normalize-headings="true"] .slide-content:not(.layout-cover) > :not(.layout-cols-wrapper):not(.pdf-two-cols-wrapper):not(.layout-image-cols-grid):first-child :is(h1, h2, h3, h4, h5, h6) {
      font-size: 1.7rem !important;
      font-weight: 600 !important;
      line-height: 1.25 !important;
      margin-bottom: 10px !important;
    }

    [data-normalize-headings="true"] .has-superblock-cols .slidev-col-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .has-superblock-cols .slidev-col-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .has-superblock-cols .pdf-col > *:first-child :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      font-size: 1.3rem !important;
      font-weight: 600 !important;
      line-height: 1.3 !important;
      margin-bottom: 8px !important;
      text-align: center !important;
    }

    /* 图左与图右版式标题完全保留用户原始字号与默认排版，不进行任何固定大小规范化 */
    [data-normalize-headings="true"] :is(.layout-image-left, .layout-image-right, .image-left-content, .image-right-content) :is(h1, h2, h3, h4, h5, h6) {
      text-align: left !important;
    }
    .pdf-col pre,
    .two-cols-left pre,
    .two-cols-right pre,
    .image-right-content pre,
    .image-left-content pre {
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      overflow-x: hidden !important;
      overflow-y: auto !important;
      max-width: 100% !important;
      box-sizing: border-box !important;
    }
    .slide-content.layout-image-right, .slide-content.layout-image-left {
      padding: 0;
      display: grid;
      grid-template-columns: var(--slide-grid-cols, minmax(0, 1fr) minmax(0, 1fr));
      grid-template-rows: 100%;
      width: 100%;
      height: 100%;
      position: absolute;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      box-sizing: border-box;
    }
    .image-right-content, .image-left-content {
      padding: 44px 50px;
      display: flex;
      flex-direction: column;
      justify-content: flex-start;
      overflow-y: auto;
      width: 100%;
      height: 100%;
      box-sizing: border-box;
    }
    .image-right-img-container, .image-left-img-container {
      width: 100%;
      height: 100%;
      overflow: hidden;
      position: relative;
      background: #18181b;
      display: flex;
      align-items: center;
      justify-content: center;
    }
    .image-right-img, .image-left-img {
      width: 100%;
      height: 100%;
      object-fit: cover;
      object-position: center;
      display: block;
    }
    .slide-block { margin-bottom: 14px; line-height: 1.6; }
    .slide-block h1 { font-size: 2.2rem; margin-bottom: 12px; }
    .slide-block h2 { font-size: 1.7rem; margin-bottom: 10px; }
    .slide-block p { font-size: 1.15rem; }
    .slide-block ul, .slide-block ol, .pdf-list {
      padding-left: 28px;
      margin: 8px 0;
      display: flex;
      flex-direction: column;
      gap: 6px;
    }
    .slide-block li, .pdf-list li {
      font-size: 1.15rem;
      line-height: 1.6;
    }
    .pdf-task-item {
      list-style: none;
      margin-left: -20px;
      display: flex;
      align-items: center;
      gap: 8px;
    }
    .pdf-task-item input[type="checkbox"] {
      width: 1.15em;
      height: 1.15em;
      cursor: pointer;
    }

    /* 两栏与三栏及多栏（超级块分栏）布局：紧凑自然行距，子列表保留圆点与层级缩进 */
    .layout-two-cols ul,
    .layout-cols-header ul,
    .layout-two-cols-header ul,
    .layout-three-cols ul,
    .layout-three-cols-header ul,
    .two-cols-left ul,
    .two-cols-right ul,
    .three-cols-col ul,
    .col ul,
    .pdf-col ul,
    .layout-two-cols-grid .pdf-list,
    .layout-three-cols-grid .pdf-list,
    .layout-cols-grid .pdf-list,
    .layout-two-cols-grid .pdf-list--unordered,
    .layout-three-cols-grid .pdf-list--unordered,
    .layout-cols-grid .pdf-list--unordered {
      list-style: disc !important;
      list-style-type: disc !important;
      padding-left: 1.25em !important;
      margin-left: 0 !important;
      margin-top: 0 !important;
      margin-bottom: 8px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: block !important;
    }

    .layout-two-cols ol,
    .layout-cols-header ol,
    .layout-two-cols-header ol,
    .layout-three-cols ol,
    .layout-three-cols-header ol,
    .two-cols-left ol,
    .two-cols-right ol,
    .three-cols-col ol,
    .col ol,
    .pdf-col ol,
    .layout-two-cols-grid .pdf-list--ordered,
    .layout-three-cols-grid .pdf-list--ordered,
    .layout-cols-grid .pdf-list--ordered {
      list-style: decimal !important;
      list-style-type: decimal !important;
      padding-left: 1.25em !important;
      margin-left: 0 !important;
      margin-top: 0 !important;
      margin-bottom: 8px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: block !important;
    }

    .layout-two-cols li,
    .layout-cols-header li,
    .layout-two-cols-header li,
    .layout-three-cols li,
    .layout-three-cols-header li,
    .two-cols-left li,
    .two-cols-right li,
    .three-cols-col li,
    .col li,
    .pdf-col li,
    .pdf-col .pdf-list-item {
      padding-left: 0.2em !important;
      margin-left: 0 !important;
      margin-bottom: 6px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: list-item !important;
      line-height: 1.6 !important;
    }

    .layout-two-cols ul ul,
    .layout-three-cols ul ul,
    .three-cols-col ul ul,
    .pdf-col ul ul {
      list-style: circle !important;
      list-style-type: circle !important;
      padding-left: 1.25em !important;
      margin-top: 4px !important;
      margin-bottom: 4px !important;
    }

    /* 列表项内嵌标题与说明排版 */
    .slide-list-item-title,
    .pdf-list li > h1,
    .pdf-list li > h2,
    .pdf-list li > h3,
    .pdf-list li > h4,
    .pdf-list li > h5,
    .pdf-list li > h6,
    li > h1.slide-list-item-title,
    li > h2.slide-list-item-title,
    li > h3.slide-list-item-title,
    li > h4.slide-list-item-title {
      margin-top: 2px !important;
      margin-bottom: 6px !important;
      line-height: 1.35 !important;
      font-weight: 700 !important;
    }
    .pdf-list li > h1, li > h1.slide-list-item-title { font-size: 1.6rem !important; }
    .pdf-list li > h2, li > h2.slide-list-item-title { font-size: 1.4rem !important; }
    .pdf-list li > h3, li > h3.slide-list-item-title { font-size: 1.22rem !important; }
    .pdf-list li > h4, li > h4.slide-list-item-title { font-size: 1.1rem !important; }

    /* 全局特定标题大小规范化后置强力锁定 (防止被列表项内部字号覆盖) */
    [data-normalize-headings="true"] .slidev-page-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .slidev-page-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      font-size: 1.7rem !important;
      font-weight: 600 !important;
      line-height: 1.25 !important;
      margin-bottom: 10px !important;
    }
    [data-normalize-headings="true"] .slidev-col-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .slidev-col-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] :is(.layout-cols-wrapper, .pdf-two-cols-wrapper, .layout-cols-header-container, .layout-cols-grid) .pdf-col > *:first-child :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] :is(.two-cols-left, .two-cols-right, .pdf-col, .col) > *:first-child :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      font-size: 1.3rem !important;
      font-weight: 600 !important;
      line-height: 1.3 !important;
      margin-bottom: 8px !important;
      text-align: center !important;
    }
    .slide-list-item-desc,
    .pdf-list li > p {
      margin-top: 4px !important;
      margin-bottom: 6px !important;
      font-size: 1.05rem;
      line-height: 1.55;
      opacity: 0.92;
    }

    /* 多媒体（GIF动图、静态图片、MP4视频）全视口最大化自适应且不超出视口 */
    .slide-media-block,
    .slide-media-container,
    .slide-video-container,
    .slide-block--media,
    .slide-block--image,
    .slide-block--video,
    .slide-block:has(> img),
    .slide-block:has(> .slide-media-container),
    .slide-block:has(> p > img:only-child),
    .slide-block:has(> .slide-video-container),
    .slide-block:has(> video) {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      min-width: 0 !important;
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
      justify-content: center !important;
      width: 100% !important;
      height: 100% !important;
      max-height: 100% !important;
      overflow: hidden !important;
      margin: 4px 0 !important;
      box-sizing: border-box !important;
    }

    .two-cols-left > .slide-block,
    .two-cols-right > .slide-block,
    .three-cols-col > .slide-block,
    .pdf-col > .slide-block,
    .pdf-col .slide-block {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      max-height: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      width: 100% !important;
      height: 100% !important;
      box-sizing: border-box !important;
      overflow: hidden !important;
      margin-bottom: 0 !important;
    }

    /* 列内列表项的标题与段落文字：固定高度，不压缩 */
    .two-cols-left .slide-list-item-title,
    .two-cols-right .slide-list-item-title,
    .three-cols-col .slide-list-item-title,
    .pdf-col .slide-list-item-title,
    .two-cols-left h1, .two-cols-left h2, .two-cols-left h3, .two-cols-left h4, .two-cols-left h5, .two-cols-left h6,
    .two-cols-right h1, .two-cols-right h2, .two-cols-right h3, .two-cols-right h4, .two-cols-right h5, .two-cols-right h6,
    .three-cols-col h1, .three-cols-col h2, .three-cols-col h3, .three-cols-col h4, .three-cols-col h5, .three-cols-col h6,
    .pdf-col h1, .pdf-col h2, .pdf-col h3, .pdf-col h4, .pdf-col h5, .pdf-col h6,
    .three-cols-col .slide-list-item-desc,
    .pdf-col .slide-list-item-desc {
      flex: 0 0 auto !important;
      margin-top: 0 !important;
      margin-bottom: 6px !important;
    }

    /* 列内媒体容器：填满标题下方所有剩余垂直空间，纵向顶部对齐，横向居中，无溢出 */
    .two-cols-left .slide-list-media,
    .two-cols-right .slide-list-media,
    .three-cols-col .slide-list-media,
    .pdf-col .slide-list-media,
    .two-cols-left .slide-video-container,
    .two-cols-right .slide-video-container,
    .three-cols-col .slide-video-container,
    .pdf-col .slide-video-container,
    .two-cols-left .slide-media-container,
    .two-cols-right .slide-media-container,
    .three-cols-col .slide-media-container,
    .pdf-col .slide-media-container {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      min-width: 0 !important;
      width: 100% !important;
      height: 100% !important;
      max-height: 100% !important;
      max-width: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
      justify-content: flex-start !important;
      overflow: hidden !important;
      margin: 0 !important;
      padding: 0 !important;
      box-sizing: border-box !important;
    }

    /* 列内多媒体播放器：以 contain 模式等比缩放完整可见，绝对不超高超宽、不产生遮挡与滚动条 */
    .two-cols-left video,
    .two-cols-right video,
    .three-cols-col video,
    .pdf-col video,
    .two-cols-left img,
    .two-cols-right img,
    .three-cols-col img,
    .pdf-col img,
    .two-cols-left .slide-video-player,
    .two-cols-right .slide-video-player,
    .three-cols-col .slide-video-player,
    .pdf-col .slide-video-player,
    .layout-three-cols-grid video,
    .layout-two-cols-grid video,
    .layout-three-cols-grid img,
    .layout-two-cols-grid img {
      max-width: 100% !important;
      max-height: 100% !important;
      width: auto !important;
      height: auto !important;
      min-width: 0 !important;
      min-height: 0 !important;
      object-fit: contain !important;
      display: block !important;
      margin: 0 auto !important;
      cursor: zoom-in;
    }

    .slide-block img,
    .slide-media-img,
    .slide-media-container img,
    .slide-video-player,
    video.slide-video-player,
    .slide-block video {
      max-width: 100% !important;
      max-height: 100% !important;
      width: auto !important;
      height: auto !important;
      min-width: 0 !important;
      min-height: 0 !important;
      object-fit: contain !important;
      display: block !important;
      margin: 0 auto !important;
      border-radius: 8px;
      box-shadow: 0 4px 16px rgba(0, 0, 0, 0.16);
      background: transparent;
      outline: none;
      cursor: zoom-in;
    }

    .slide-list-media {
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
      justify-content: flex-start !important;
      width: 100% !important;
      max-width: 100% !important;
      height: 100% !important;
      max-height: 100% !important;
      flex: 1 1 0% !important;
      margin-top: 4px !important;
      margin-bottom: 4px !important;
      min-height: 0 !important;
      overflow: hidden !important;
      box-sizing: border-box !important;
    }
    .slide-list-media img,
    .slide-list-media video,
    .slide-list-media .list-item-gif,
    .slide-list-media .slide-video-player {
      max-width: 100% !important;
      max-height: 100% !important;
      width: auto !important;
      height: auto !important;
      min-width: 0 !important;
      min-height: 0 !important;
      object-fit: contain !important;
      border-radius: 6px !important;
      box-shadow: 0 3px 12px rgba(0, 0, 0, 0.14) !important;
      display: block !important;
      margin: 0 auto !important;
      cursor: zoom-in;
    }

    .slide-block:has(.slide-list-media) {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      height: 100% !important;
      max-height: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      overflow: hidden !important;
    }
    .slide-block:has(.slide-list-media) .pdf-list,
    .slide-block:has(.slide-list-media) ul,
    .slide-block:has(.slide-list-media) ol {
      display: block !important;
      flex: 1 1 auto;
      min-height: 0;
      max-height: 100%;
      overflow: visible !important;
      list-style: disc !important;
      list-style-type: disc !important;
    }
    .slide-block:has(.slide-list-media) li,
    .slide-block:has(.slide-list-media) .slide-list-item,
    .slide-block:has(.slide-list-media) .pdf-list-item,
    .slide-block:has(.slide-media-container) li,
    .slide-block:has(.slide-video-container) li,
    .layout-cols-wrapper li:has(.slide-list-media),
    .layout-cols-header-container li:has(.slide-list-media),
    .two-cols-left li:has(.slide-list-media),
    .two-cols-right li:has(.slide-list-media),
    .three-cols-col li:has(.slide-list-media),
    .pdf-col li:has(.slide-list-media),
    li:has(.slide-list-media),
    li:has(.slide-video-container),
    li:has(.slide-media-container) {
      display: list-item !important;
      list-style-type: disc !important;
      flex: 0 0 auto !important;
      height: auto !important;
      max-height: none !important;
      overflow: visible !important;
      margin-bottom: 6px !important;
    }

    .layout-two-cols .slide-media-block,
    .layout-two-cols .slide-video-container,
    .layout-two-cols .slide-media-container,
    .layout-three-cols .slide-media-block,
    .layout-three-cols .slide-video-container,
    .layout-three-cols .slide-media-container {
      max-width: 100% !important;
      max-height: 100% !important;
      width: 100% !important;
      height: 100% !important;
      min-width: 0 !important;
      min-height: 0 !important;
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
      justify-content: flex-start !important;
      overflow: hidden !important;
    }

    /* Lightbox 大图与视频灯箱模态窗口 */
    .slidev-lightbox {
      position: fixed;
      top: 0;
      left: 0;
      width: 100vw;
      height: 100vh;
      background: rgba(0, 0, 0, 0.88);
      backdrop-filter: blur(8px);
      z-index: 999999;
      display: none;
      align-items: center;
      justify-content: center;
      cursor: zoom-out;
      opacity: 0;
      transition: opacity 0.2s cubic-bezier(0.16, 1, 0.3, 1);
    }
    .slidev-lightbox.active {
      display: flex;
      opacity: 1;
    }
    .slidev-lightbox-content {
      position: relative;
      max-width: 92vw;
      max-height: 92vh;
      display: flex;
      align-items: center;
      justify-content: center;
      cursor: default;
    }
    .slidev-lightbox-img {
      max-width: 92vw;
      max-height: 92vh;
      object-fit: contain;
      border-radius: 8px;
      box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.75);
    }
    .slidev-lightbox-video {
      max-width: 92vw;
      max-height: 92vh;
      border-radius: 8px;
      box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.75);
    }
    .slidev-lightbox-close {
      position: absolute;
      top: 24px;
      right: 28px;
      width: 40px;
      height: 40px;
      background: rgba(255, 255, 255, 0.2);
      border: 1px solid rgba(255, 255, 255, 0.35);
      border-radius: 50%;
      color: #fff;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 22px;
      cursor: pointer;
      transition: background 0.2s, transform 0.2s;
      z-index: 1000000;
    }
    .slidev-lightbox-close:hover {
      background: rgba(255, 255, 255, 0.35);
      transform: scale(1.05);
    }

    img.slide-inline-img {
      max-width: 100% !important;
      max-height: min(320px, 40vh) !important;
      object-fit: contain !important;
      vertical-align: middle;
      border-radius: 4px;
    }
    kbd {
      display: inline-block;
      padding: 2px 7px;
      font-family: ui-monospace, SFMono-Regular, "SF Mono", Menlo, Consolas, "Liberation Mono", monospace;
      font-size: 0.85em;
      font-weight: 600;
      line-height: 1.25;
      color: inherit;
      background: rgba(125, 125, 125, 0.12);
      border: 1px solid rgba(125, 125, 125, 0.35);
      border-bottom-width: 2px;
      border-radius: 5px;
      box-shadow: 0 1px 2px rgba(0, 0, 0, 0.12);
      margin: 0 2px;
      vertical-align: middle;
      white-space: nowrap;
    }
    [data-theme="dark"] kbd, .theme-dark kbd {
      background: rgba(255, 255, 255, 0.1);
      border-color: rgba(255, 255, 255, 0.25);
      border-bottom-color: rgba(255, 255, 255, 0.4);
      color: #f1f5f9;
      box-shadow: 0 1px 2px rgba(0, 0, 0, 0.4);
    }
    .slide-block pre,
    pre {
      background: rgba(0, 0, 0, 0.1);
      padding: 12px;
      border-radius: 6px;
      font-family: "JetBrains Mono", Consolas, monospace;
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      overflow-x: hidden !important;
      overflow-y: auto !important;
      max-width: 100% !important;
      box-sizing: border-box !important;
    }
    .slide-block pre code,
    pre code {
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      display: block !important;
      width: 100% !important;
      box-sizing: border-box !important;
    }
    .code-line {
      display: flex !important;
      align-items: flex-start !important;
      width: 100% !important;
      box-sizing: border-box !important;
      line-height: 1.6;
    }
    .code-line .line-no {
      display: inline-block !important;
      flex-shrink: 0 !important;
      min-width: 2.2em !important;
      text-align: right !important;
      margin-right: 12px !important;
      user-select: none !important;
      opacity: 0.45 !important;
    }
    .code-line .line-content {
      flex: 1 1 0% !important;
      min-width: 0 !important;
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
    }
    /* 弱提示滚动条样式 */
    * {
      scrollbar-width: thin;
      scrollbar-color: rgba(255, 255, 255, 0.20) transparent;
    }
    *::-webkit-scrollbar {
      width: 4px;
      height: 4px;
    }
    *::-webkit-scrollbar-track {
      background: transparent;
    }
    *::-webkit-scrollbar-thumb {
      background: rgba(255, 255, 255, 0.20);
      border-radius: 2px;
      transition: background 0.2s ease;
    }
    *:hover::-webkit-scrollbar-thumb,
    *::-webkit-scrollbar-thumb:hover {
      background: rgba(255, 255, 255, 0.45);
    }
    /* Slidev Micro-motion Keyframes & Presets */
    @keyframes slidevMotionFadeIn { from { opacity: 0; } to { opacity: 1; } }
    @keyframes slidevMotionSlideUp { from { opacity: 0; transform: translateY(40px); } to { opacity: 1; transform: translateY(0); } }
    @keyframes slidevMotionSlideDown { from { opacity: 0; transform: translateY(-40px); } to { opacity: 1; transform: translateY(0); } }
    @keyframes slidevMotionSlideLeft { from { opacity: 0; transform: translateX(40px); } to { opacity: 1; transform: translateX(0); } }
    @keyframes slidevMotionSlideRight { from { opacity: 0; transform: translateX(-40px); } to { opacity: 1; transform: translateX(0); } }
    @keyframes slidevMotionZoomIn { from { opacity: 0; transform: scale(0.8); } to { opacity: 1; transform: scale(1); } }
    @keyframes slidevMotionBounce {
      0% { opacity: 0; transform: translateY(40px); }
      60% { opacity: 1; transform: translateY(-8px); }
      80% { transform: translateY(4px); }
      100% { transform: translateY(0); }
    }
    .slidev-motion-fade-in { animation: slidevMotionFadeIn var(--motion-duration, 0.4s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slidev-motion-slide-up { animation: slidevMotionSlideUp var(--motion-duration, 0.45s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slidev-motion-slide-down { animation: slidevMotionSlideDown var(--motion-duration, 0.45s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slidev-motion-slide-left { animation: slidevMotionSlideLeft var(--motion-duration, 0.45s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slidev-motion-slide-right { animation: slidevMotionSlideRight var(--motion-duration, 0.45s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slidev-motion-zoom-in, .slidev-motion-pop { animation: slidevMotionZoomIn var(--motion-duration, 0.4s) cubic-bezier(0.34, 1.56, 0.64, 1) var(--motion-delay, 0s) both; }
    .slidev-motion-bounce { animation: slidevMotionBounce var(--motion-duration, 0.6s) cubic-bezier(0.34, 1.56, 0.64, 1) var(--motion-delay, 0s) both; }
    .controls {
      position: absolute; bottom: 16px; display: flex; gap: 12px; align-items: center;
      background: rgba(24, 24, 27, 0.8); backdrop-filter: blur(8px);
      padding: 6px 18px; border-radius: 20px; color: #fff; font-size: 13px; z-index: 10;
      opacity: 0; pointer-events: auto;
      transition: opacity 0.3s cubic-bezier(0.16, 1, 0.3, 1), transform 0.3s cubic-bezier(0.16, 1, 0.3, 1);
    }
    .controls::before {
      content: ""; position: absolute; top: -20px; bottom: -16px; left: -24px; right: -24px;
    }
    .controls:hover, .controls:focus-within {
      opacity: 1; transform: translateY(-2px);
    }
    .controls button { background: transparent; border: none; color: inherit; cursor: pointer; padding: 2px 6px; }

    /* Slidev Native Icons & Interactive Buttons */
    .slidev-icon-btn {
      display: inline-flex !important; flex-direction: row !important; align-items: center !important; justify-content: center !important;
      padding: 0.35rem 0.5rem; border-radius: 0.375rem; background: transparent;
      border: 1px solid transparent; color: inherit; font-size: inherit; line-height: 1;
      cursor: pointer; opacity: 0.8; transition: all 0.2s ease; text-decoration: none;
      vertical-align: middle; user-select: none; margin: 0 4px;
    }
    .slidev-icon-btn:hover { opacity: 1; background: rgba(255, 255, 255, 0.12); border-color: rgba(255, 255, 255, 0.15); }

    /* 组件从上到下按顺序流式渲染，避免相互重叠 */
    .slide-block > div + div { margin-top: 14px; }

    /* 同一个 div 内的按钮/链接从左到右水平渲染 */
    .slide-block div:has(> .slidev-icon-btn),
    .slide-block div:has(> button),
    .slide-block [class*="abs-"],
    .slidev-btn-row {
      display: inline-flex !important;
      flex-direction: row !important;
      align-items: center !important;
      justify-content: center !important;
      flex-wrap: wrap !important;
      gap: 8px !important;
    }

    /* Position Shortcuts 适配：在组件流中保持从上到下排列，不脱离流产生重叠 */
    .slide-block .abs-br,
    .slide-block .abs-bl,
    .slide-block .abs-tr,
    .slide-block .abs-tl,
    .slide-block [class*="abs-"] {
      position: relative !important;
      bottom: auto !important;
      right: auto !important;
      top: auto !important;
      left: auto !important;
      margin: 0.75rem auto !important;
    }

    .slide-block--absolute { position: relative !important; margin-bottom: 14px !important; padding: 0 !important; background: transparent !important; }
    .slide-block--absolute:hover { background: transparent !important; }
    .mt-12 { margin-top: 3rem !important; }
    .py-1 { padding-top: 0.25rem !important; padding-bottom: 0.25rem !important; }
    .m-6 { margin: 1.5rem !important; }
    .text-xl { font-size: 1.25rem !important; }
    [hover\\:bg~="white"][hover\\:bg~="op-10"]:hover,
    [hover\\:bg="white op-10"]:hover { background: rgba(255, 255, 255, 0.1) !important; border-radius: 4px; }
    .cursor-pointer, [data-clickable] { cursor: pointer; }
    /* Slidev 规范链接排版 (继承正文颜色，虚线底边，Hover 时平滑点亮为主题色并转为实线) */
    .slide-content a:not(.slidev-ref-tag):not(.slidev-icon-btn):not(.slidev-toc-link),
    .slide-block a:not(.slidev-ref-tag):not(.slidev-icon-btn):not(.slidev-toc-link),
    a.slidev-link {
      color: inherit;
      text-decoration: none;
      border-bottom: 1px dashed currentColor;
      transition: color 0.2s cubic-bezier(0.4, 0, 0.2, 1),
                  border-color 0.2s cubic-bezier(0.4, 0, 0.2, 1),
                  border-bottom-style 0.2s cubic-bezier(0.4, 0, 0.2, 1);
      cursor: pointer;
    }
    .slide-content a:not(.slidev-ref-tag):not(.slidev-icon-btn):not(.slidev-toc-link):hover,
    .slide-block a:not(.slidev-ref-tag):not(.slidev-icon-btn):not(.slidev-toc-link):hover,
    a.slidev-link:hover {
      color: var(--slide-accent);
      border-bottom-style: solid;
      border-bottom-color: var(--slide-accent);
    }
    .slidev-ref-tag, a.slidev-ref-tag {
      display: inline-flex;
      align-items: center;
      background: color-mix(in srgb, var(--slide-accent) 12%, transparent);
      color: var(--slide-accent);
      border-radius: 4px;
      padding: 2px 8px;
      font-size: 0.88em;
      text-decoration: none;
      cursor: pointer;
      margin: 2px 4px 2px 0;
      border: 1px solid color-mix(in srgb, var(--slide-accent) 25%, transparent);
      transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
    }
    .slidev-ref-tag:hover, a.slidev-ref-tag:hover {
      background: color-mix(in srgb, var(--slide-accent) 22%, transparent);
      color: var(--slide-accent);
      border-color: color-mix(in srgb, var(--slide-accent) 55%, transparent);
      transform: translateY(-1px);
      box-shadow: 0 2px 8px color-mix(in srgb, var(--slide-accent) 20%, transparent);
    }
    .slidev-block-ref {
      display: block;
      padding: 10px 14px;
      background: color-mix(in srgb, var(--slide-accent) 8%, transparent);
      border-left: 3px solid var(--slide-accent);
      border-radius: 0 6px 6px 0;
      margin: 8px 0;
      cursor: pointer;
      transition: background 0.2s ease;
    }
    .slidev-block-ref:hover {
      background: color-mix(in srgb, var(--slide-accent) 15%, transparent);
    }`}function rm(){return`    (function() {
      const data = window.__SLIDEV_DATA__ || { slides: [] };
      const slides = data.slides || [];
      let currentIndex = 0;

      const container = document.getElementById("slide-container");
      const pageNum = document.getElementById("page-num");
      const btnPrev = document.getElementById("btn-prev");
      const btnNext = document.getElementById("btn-next");
      const btnFullscreen = document.getElementById("btn-fullscreen");

      const baseWidth = 980;
      const aspectStr = (data.config && data.config.aspectRatio) || "16/9";
      let ratioNum = 16 / 9;
      if (aspectStr === "4/3") ratioNum = 4 / 3;
      else if (aspectStr === "16/10") ratioNum = 16 / 10;
      else if (typeof aspectStr === "string" && aspectStr.includes("/")) {
        const parts = aspectStr.split("/").map(Number);
        if (parts[0] && parts[1]) ratioNum = parts[0] / parts[1];
      }
      const baseHeight = Math.ceil(baseWidth / ratioNum);
      const viewport = document.getElementById("viewport");

      function updateScale() {
        if (!viewport) return;
        const isFull = !!document.fullscreenElement;
        const padX = isFull ? 0 : 20;
        const padY = isFull ? 0 : 32;
        const availW = Math.max(100, window.innerWidth - padX);
        const availH = Math.max(100, window.innerHeight - padY);
        const scale = Math.min(availW / baseWidth, availH / baseHeight);
        viewport.style.width = baseWidth + "px";
        viewport.style.height = baseHeight + "px";
        viewport.style.transform = "translate(-50%, -50%) scale(" + scale + ")";
        viewport.style.setProperty("--slidev-slide-scale", scale);
        if (isFull) document.body.classList.add("is-fullscreen");
        else document.body.classList.remove("is-fullscreen");
      }

      window.addEventListener("resize", updateScale);
      document.addEventListener("fullscreenchange", updateScale);

      function cleanCardListItemMarkdown(rawMarkdown) {
        if (!rawMarkdown) return "";
        let cleaned = rawMarkdown.replace(/^[ 	]*[-*+]s+|^[ 	]*d+.s+/, "");
        cleaned = cleaned.replace(/
[ 	]{2,4}/g, "
");
        return cleaned.trim();
      }

      function isHeadingBlock(b) {
        if (!b) return false;
        if (b.type === "h" || b.type === "NodeHeading") return true;
        if (b.subType && /^h[1-6]$/i.test(b.subType)) return true;
        const md = (b.rawMarkdown || b.content || "").trim();
        if (/^#{1,6}s+/.test(md)) return true;
        if (/^(?:[-*+]|d+.)s+#{1,6}s+/.test(md)) return true;
        return false;
      }

      function cleanColList(blocks) {
        const valid = (blocks || []).filter(b => Boolean((b.rawMarkdown || b.content || "").trim()));
        if (valid.length === 0) return valid;
        const first = valid[0];
        const md = (first.rawMarkdown || first.content || "").trim();
        const isList = /^(?:[-*+]|d+.)s+/.test(md) || first.type === "i" || first.type === "l";
        if (isList) {
          first.rawMarkdown = cleanCardListItemMarkdown(first.rawMarkdown || first.content || "");
          first.content = first.rawMarkdown;
        }
        return valid;
      }

      function renderBlock(block, extraClass) {
        const div = document.createElement("div");
        div.className = "slide-block" + (extraClass ? " " + extraClass : "");
        if (block && block.motion && block.motion.preset && block.motion.preset !== "none") {
          div.classList.add("slidev-motion-" + block.motion.preset.toLowerCase());
          if (typeof block.motion.duration === "number" && block.motion.duration > 0) {
            div.style.setProperty("--motion-duration", block.motion.duration + "ms");
          }
          if (typeof block.motion.delay === "number" && block.motion.delay > 0) {
            div.style.setProperty("--motion-delay", block.motion.delay + "ms");
          }
        }
        const md = block.rawMarkdown || block.content || "";

        if (md.includes('class="slidev-block-ref"') || md.includes('class="slidev-ref-tag"')) {
          div.innerHTML = md;
          return div;
        }

        const CARBON_MAP = {
          'carbon:arrow-right': '<svg viewBox="0 0 32 32" width="1.2em" height="1.2em" fill="currentColor" style="display:inline-block;vertical-align:middle;"><path d="m18 6l-1.43 1.393L24.15 15H4v2h20.15l-7.58 7.573L18 26l10-10z"/></svg>',
          'carbon:arrow-left': '<svg viewBox="0 0 32 32" width="1.2em" height="1.2em" fill="currentColor" style="display:inline-block;vertical-align:middle;"><path d="m14 26l1.43-1.393L7.85 17H28v-2H7.85l7.58-7.573L14 6L4 16z"/></svg>',
          'carbon:edit': '<svg viewBox="0 0 32 32" width="1.2em" height="1.2em" fill="currentColor" style="display:inline-block;vertical-align:middle;"><path d="M2 26h28v2H2zM25.4 9c.8-.8.8-2 0-2.8l-3.6-3.6c-.8-.8-2-.8-2.8 0l-15 15V24h6.4l15-15zM20.4 4L24 7.6l-2.4 2.4l-3.6-3.6L20.4 4zM6 22v-3.6l11-11l3.6 3.6l-11 11H6z"/></svg>',
          'carbon:logo-github': '<svg viewBox="0 0 32 32" width="1.2em" height="1.2em" fill="currentColor" style="display:inline-block;vertical-align:middle;"><path fill-rule="evenodd" d="M16 2a14 14 0 0 0-4.43 27.28c.7.13 1-.3 1-.67v-2.38c-3.89.84-4.71-1.88-4.71-1.88a3.7 3.7 0 0 0-1.56-2.05c-1.27-.86.1-.85.1-.85a2.94 2.94 0 0 1 2.14 1.44a3 3 0 0 0 4.08 1.16a2.93 2.93 0 0 1 .89-1.87c-3.1-.35-6.36-1.55-6.36-6.9a5.4 5.4 0 0 1 1.44-3.75a5 5 0 0 1 .14-3.71s1.17-.38 3.85 1.43a13.3 13.3 0 0 1 7 0c2.67-1.81 3.84-1.43 3.84-1.43a5 5 0 0 1 .14 3.71a5.4 5.4 0 0 1 1.44 3.75c0 5.37-3.27 6.54-6.38 6.89a3.35 3.35 0 0 1 1.26 2.61v3.87c0 .38.26.81 1 .67A14 14 0 0 0 16 2"/></svg>'
        };

        if (/@\\w+=['"]|v-\\w+|<button|<a\\b|<carbon:|^<div/i.test(md)) {
          if (md.includes('abs-br') || md.includes('abs-bl') || md.includes('abs-tr') || md.includes('abs-tl') || md.includes('absolute')) {
            div.classList.add("slide-block--absolute");
          }
          let renderedHtml = md;
          for (const [tag, svg] of Object.entries(CARBON_MAP)) {
            const regex = new RegExp("<" + tag + "\\\\s*\\\\/?>", "gi");
            renderedHtml = renderedHtml.replace(regex, svg);
            const regexDash = new RegExp("<" + tag.replace(":", "-") + "\\\\s*\\\\/?>", "gi");
            renderedHtml = renderedHtml.replace(regexDash, svg);
          }
          div.innerHTML = renderedHtml;

          // 挂载交互事件监听
          const nextBtns = div.querySelectorAll('[\\\\@click*="nav.next"], [\\\\@click*="next"]');
          nextBtns.forEach(btn => {
            btn.style.cursor = "pointer";
            btn.addEventListener("click", (e) => {
              e.stopPropagation();
              renderSlide(currentIndex + 1);
            });
          });

          const prevBtns = div.querySelectorAll('[\\\\@click*="nav.prev"], [\\\\@click*="prev"]');
          prevBtns.forEach(btn => {
            btn.style.cursor = "pointer";
            btn.addEventListener("click", (e) => {
              e.stopPropagation();
              renderSlide(currentIndex - 1);
            });
          });

          return div;
        }

        const hasHeadingTag = /(?:^|
)s*#{1,6}s+/.test(md);
        const hMatch = md.match(/^(#{1,6})\\s+(.*)$/);

        if (hMatch) {
          const level = hMatch[1].length;
          let th = hMatch[2].trim().replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
          div.innerHTML = "<h" + level + ">" + th + "</h" + level + ">";
        }
        else if (md.startsWith("\`\`\`")) {
          const customMaxHeight = block?.attributes?.["custom-slidev-max-height"] || block?.attrs?.["custom-slidev-max-height"] || block?.maxHeight || "";
          const heightStyle = customMaxHeight ? ' style="max-height:' + customMaxHeight + ';overflow-y:auto;"' : "";
          div.innerHTML = "<pre" + heightStyle + "><code>" + md.slice(3, -3) + "</code></pre>";
        }
        else if (md.startsWith("> ")) div.innerHTML = "<blockquote><p>" + md.slice(2) + "</p></blockquote>";
        else if ((/<video\b/i.test(md) || (block && (block.type === "video" || block.type === "NodeVideo"))) && !/^(s*)([-*+]|d+.)s+/m.test(md) && !hasHeadingTag && !md.includes("
")) {
          div.classList.add("slide-video-container", "slide-media-container", "slide-media-block");
          const isAutoplay = block && block.attributes && block.attributes["custom-slidev-autoplay"] === "true";
          const isLoop = block && block.attributes && block.attributes["custom-slidev-loop"] === "true";
          const isMuted = block && block.attributes && (block.attributes["custom-slidev-muted"] === "true" || isAutoplay);
          const hideControls = block && block.attributes && block.attributes["custom-slidev-controls"] === "false";
          let videoHtml = md;
          if (hideControls) videoHtml = videoHtml.replace(/\bcontrols(?:="[^"]*")?/gi, "").trim();
          else if (!videoHtml.includes("controls")) videoHtml = videoHtml.replace("<video", "<video controls");
          if (isAutoplay && !videoHtml.includes("autoplay")) videoHtml = videoHtml.replace("<video", "<video autoplay playsinline");
          if (isLoop && !videoHtml.includes("loop")) videoHtml = videoHtml.replace("<video", "<video loop");
          if (isMuted && !videoHtml.includes("muted")) videoHtml = videoHtml.replace("<video", "<video muted");
          videoHtml = videoHtml.replace("<video", '<video class="slide-video-player"');
          div.setAttribute("data-autoplay", isAutoplay ? "true" : "false");
          div.innerHTML = videoHtml;
        }
        else if (/^(s*)([-*+]|d+.)s+/m.test(md) || (md.includes("
") && /^(s*)([-*+]|d+.)s+/m.test(md.split("
").slice(1).join("
")))) {
          div.classList.add("pdf-list-item");
          const lines = md.split("
");
          let isOrdered = false;
          const items = [];
          const leadLines = [];
          for (let i = 0; i < lines.length; i++) {
            const line = lines[i];
            const tr = line.trim();
            if (!tr || /^{:.*?}$/.test(tr)) continue;
            const um = line.match(/^(s*)[-*+]s+(.*)$/);
            const om = line.match(/^(s*)d+.s+(.*)$/);
            if (um) {
              const indent = um[1].length;
              items.push({ type: "unordered", level: Math.floor(indent / 2), text: um[2], media: [] });
              continue;
            }
            if (om) {
              if (items.length === 0) isOrdered = true;
              const indent = om[1].length;
              items.push({ type: "ordered", level: Math.floor(indent / 2), text: om[2], media: [] });
              continue;
            }
            if (items.length > 0) {
              const im = tr.match(/^![(.*?)]((.*?))(?:{:?[^}]*})?$/);
              if (im) {
                const isGif = /.gif(?:?|$)/i.test(im[2]);
                items[items.length - 1].media.push('<div class="slide-list-media"><img alt="' + im[1] + '" src="' + im[2] + '" class="' + (isGif ? 'list-item-gif' : 'list-item-img') + '" /></div>');
                continue;
              }
              const hm = tr.match(/^<img\b[sS]*?/?>$/i);
              if (hm) {
                const cleanTr = tr.replace(/s+style="[^"]*"/gi, "");
                items[items.length - 1].media.push('<div class="slide-list-media">' + cleanTr + '</div>');
                continue;
              }
              if (/<video\b/i.test(tr)) {
                let vHtml = tr;
                if (!/</video>/i.test(vHtml)) {
                  while (i + 1 < lines.length && !/</video>/i.test(vHtml)) {
                    i++;
                    vHtml += " " + lines[i].trim();
                  }
                }
                const isAutoplay = block && block.attributes && block.attributes["custom-slidev-autoplay"] === "true";
                const isLoop = block && block.attributes && block.attributes["custom-slidev-loop"] === "true";
                const isMuted = block && block.attributes && (block.attributes["custom-slidev-muted"] === "true" || isAutoplay);
                const hideControls = block && block.attributes && block.attributes["custom-slidev-controls"] === "false";
                if (hideControls) vHtml = vHtml.replace(/\bcontrols(?:="[^"]*")?/gi, "").trim();
                else if (!vHtml.includes("controls")) vHtml = vHtml.replace("<video", "<video controls");
                if (isAutoplay && !vHtml.includes("autoplay")) vHtml = vHtml.replace("<video", "<video autoplay playsinline");
                if (isLoop && !vHtml.includes("loop")) vHtml = vHtml.replace("<video", "<video loop");
                if (isMuted && !vHtml.includes("muted")) vHtml = vHtml.replace("<video", "<video muted");
                vHtml = vHtml.replace("<video", '<video class="slide-video-player"');
                items[items.length - 1].media.push('<div class="slide-list-media slide-video-container slide-media-container" data-autoplay="' + (isAutoplay ? 'true' : 'false') + '">' + vHtml + '</div>');
                continue;
              }
              items[items.length - 1].text += "
" + tr;
            } else {
              leadLines.push(tr);
            }
          }

          let leadHtml = "";
          if (leadLines.length > 0) {
            const lParts = [];
            const firstL = leadLines[0];
            const fhm = firstL.match(/^(#{1,6})s+(.*)$/);
            if (fhm) {
              const lvl = fhm[1].length;
              let th = fhm[2].trim().replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
              lParts.push('<h' + lvl + ' class="slide-list-item-title">' + th + '</h' + lvl + '>');
            } else {
              let th = firstL.trim().replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
              lParts.push('<p class="slide-list-item-title">' + th + '</p>');
            }
            if (leadLines.length > 1) {
              const dLines = leadLines.slice(1);
              let pL = [];
              const flushLeadP = () => {
                if (pL.length > 0) {
                  let txt = pL.map(l => l.replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>")).join("<br/>");
                  lParts.push('<p class="slide-list-item-desc">' + txt + '</p>');
                  pL = [];
                }
              };
              for (const l of dLines) {
                const hm = l.match(/^(#{1,6})s+(.*)$/);
                if (hm) {
                  flushLeadP();
                  const lvl = hm[1].length;
                  let th = hm[2].trim().replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
                  lParts.push('<h' + lvl + ' class="slide-list-item-title">' + th + '</h' + lvl + '>');
                } else {
                  pL.push(l);
                }
              }
              flushLeadP();
            }
            leadHtml = lParts.join("
") + "
";
          }

          const tag = isOrdered ? "ol" : "ul";
          const listCls = isOrdered ? "pdf-list pdf-list--ordered" : "pdf-list pdf-list--unordered";
          const liHtml = items.map(it => {
            const med = it.media && it.media.length ? "
" + it.media.join("
") : "";
            const lines = (it.text || "").split("
").map(l => l.trim()).filter(Boolean);
            const hasHeading = lines.some(l => /^#{1,6}s+/.test(l));
            const lvl = it.level || 0;
            const nStyle = lvl > 0 ? ' style="margin-left:' + (lvl * 1.25).toFixed(2) + 'em;' + (it.type === 'unordered' ? 'list-style-type:' + (lvl % 2 === 1 ? 'circle' : 'square') + ' !important;' : '') + '"' : "";
            const nClass = lvl > 0 ? " slide-list-item--nested" : "";
            const clsAttr = nClass ? ' class="' + nClass.trim() + '"' : "";
            if (!hasHeading) {
              let h = lines.map(l => l.replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>")).join("<br/>");
              return '<li' + clsAttr + nStyle + '>' + h + med + '</li>';
            }
            const parts = [];
            let pLines = [];
            const flushP = () => {
              if (pLines.length > 0) {
                let ph = pLines.map(l => l.replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>")).join("<br/>");
                parts.push('<p class="slide-list-item-desc">' + ph + '</p>');
                pLines = [];
              }
            };
            for (const l of lines) {
              const hm = l.match(/^(#{1,6})s+(.*)$/);
              if (hm) {
                flushP();
                const hl = hm[1].length;
                let th = hm[2].trim().replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
                parts.push('<h' + hl + ' class="slide-list-item-title">' + th + '</h' + hl + '>');
              } else {
                pLines.push(l);
              }
            }
            flushP();
            return '<li' + clsAttr + nStyle + '>' + parts.join("
") + med + '</li>';
          }).join("
");
          div.innerHTML = leadHtml + "<" + tag + " class="" + listCls + "">
" + liHtml + "
</" + tag + ">";
        }
        else {
          // 复合块（包含换行、标题或媒体）高保真解析
          const lines = md.split(/\r?
/);
          const subBlocks = [];
          let current = [];
          for (let i = 0; i < lines.length; i++) {
            const line = lines[i];
            const trimmed = line.trim();
            if (/^#{1,6}s+/.test(trimmed)) {
              if (current.length > 0) { subBlocks.push(current.join("
")); current = []; }
              subBlocks.push(trimmed);
              continue;
            }
            if (!trimmed) {
              if (current.length > 0) { subBlocks.push(current.join("
")); current = []; }
              continue;
            }
            if (/^![.*?](.*?)$/.test(trimmed)) {
              if (current.length > 0) { subBlocks.push(current.join("
")); current = []; }
              subBlocks.push(trimmed);
              continue;
            }
            if (/<video\b/i.test(trimmed)) {
              if (current.length > 0) { subBlocks.push(current.join("
")); current = []; }
              let vRaw = trimmed;
              if (!/</video>/i.test(vRaw)) {
                while (i + 1 < lines.length && !/</video>/i.test(vRaw)) {
                  i++;
                  vRaw += "
" + lines[i];
                }
              }
              subBlocks.push(vRaw);
              continue;
            }
            current.push(line);
          }
          if (current.length > 0) subBlocks.push(current.join("
"));

          if (subBlocks.length > 1 || (subBlocks.length === 1 && /^#{1,6}s+/.test(subBlocks[0].trim()))) {
            let isFirstParagraph = true;
            const htmlParts = subBlocks.map(sub => {
              const t = sub.trim();
              if (!t) return "";
              const hm = t.match(/^(#{1,6})s+(.*)$/);
              if (hm) {
                isFirstParagraph = false;
                const hl = hm[1].length;
                let th = hm[2].trim().replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
                return '<h' + hl + ' class="slide-list-item-title">' + th + '</h' + hl + '>';
              }
              const im = t.match(/^![(.*?)]((.*?))$/);
              if (im) {
                return '<div class="slide-media-block slide-media-container slide-list-media"><img alt="' + im[1] + '" src="' + im[2] + '" class="slide-media-img" /></div>';
              }
              if (/<video\b/i.test(t)) {
                return '<div class="slide-media-block slide-video-container slide-media-container">' + t + '</div>';
              }
              if (isFirstParagraph) {
                isFirstParagraph = false;
                const subLines = t.split(/\r?
/).map(l => l.trim()).filter(Boolean);
                if (subLines.length === 1) {
                  let ph = subLines[0].replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
                  return '<p class="slide-list-item-title">' + ph + '</p>';
                }
                let titleHtml = subLines[0].replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
                let descHtml = subLines.slice(1).map(l => l.replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>")).join("<br/>");
                return '<p class="slide-list-item-title">' + titleHtml + '</p>
<p class="slide-list-item-desc">' + descHtml + '</p>';
              }
              let ph = t.replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
              return '<p class="slide-list-item-desc">' + ph + '</p>';
            }).filter(Boolean);
            div.innerHTML = htmlParts.join("
");
          } else {
            const imgMatch = md.match(/!\\[(.*?)\\]\\((.*?)\\)/);
            if (imgMatch) {
              div.classList.add("slide-media-container", "slide-media-block", "slide-block--image");
              div.innerHTML = '<img alt="' + imgMatch[1] + '" src="' + imgMatch[2] + '" class="slide-media-img" />';
            } else {
              let html = md.replace(/**(.*?)**/g, "<strong>$1</strong>").replace(/\`([^\`]+)\`/g, "<code>$1</code>");
              const pCls = (block && block.isColFirst) ? ' class="slide-list-item-title"' : '';
              div.innerHTML = "<p" + pCls + ">" + html + "</p>";
            }
          }
        }
        return div;
      }

      function renderSlide(idx) {
        if (slides.length === 0) return;
        currentIndex = Math.max(0, Math.min(idx, slides.length - 1));
        const slide = slides[currentIndex];
        pageNum.textContent = (currentIndex + 1) + " / " + slides.length;

        const pageSp = slide.frontmatter?.spacing;
        const currentSpacing = (pageSp && pageSp !== "inherit") ? pageSp : (data.config?.spacing || "normal");
        container.className = "slide-content layout-" + (slide.frontmatter?.layout || "default") + " spacing-" + currentSpacing;
        if (viewport) viewport.setAttribute("data-spacing", currentSpacing);
        container.innerHTML = "";

        const z = typeof slide.frontmatter?.zoom === "number" && slide.frontmatter.zoom > 0 ? slide.frontmatter.zoom : 1;
        if (z !== 1) {
          container.style.width = (100 / z) + "%";
          container.style.height = (100 / z) + "%";
          container.style.transformOrigin = "top left";
          container.style.transform = "scale(" + z + ")";
        } else {
          container.style.width = "100%";
          container.style.height = "100%";
          container.style.transform = "none";
        }

        if (slide.frontmatter?.layout === "two-cols") {
          const leftCol = document.createElement("div");
          leftCol.className = "two-cols-left";
          const rightCol = document.createElement("div");
          rightCol.className = "two-cols-right";

          const blocks = (slide.blocks || []).filter(b => b.slot !== "slot-divider-right");
          let leftList = [];
          let rightList = [];
          for (const block of blocks) {
            if (block.slot === "right") rightList.push(block);
            else leftList.push(block);
          }
          leftList = cleanColList(leftList);
          rightList = cleanColList(rightList);
          const isCover = slide.frontmatter?.layout === "cover";
          const leftFirstH = !isCover ? leftList.find(isHeadingBlock) : null;
          const rightFirstH = !isCover ? rightList.find(isHeadingBlock) : null;
          for (const b of leftList) leftCol.appendChild(renderBlock(b, b === leftFirstH ? "slidev-col-first-heading-block" : ""));
          for (const b of rightList) rightCol.appendChild(renderBlock(b, b === rightFirstH ? "slidev-col-first-heading-block" : ""));
          container.appendChild(leftCol);
          container.appendChild(rightCol);
        } else if (slide.frontmatter?.layout === "cols-header" || slide.frontmatter?.layout === "two-cols-header" || slide.frontmatter?.layout === "three-cols-header") {
          const isCover = slide.frontmatter?.layout === "cover";
          const blocks = (slide.blocks || []).filter(b => b.slot !== "slot-divider-right");
          let headerBlocks = blocks.filter(b => b.slot === "header");
          if (headerBlocks.length === 0 && blocks.length > 0) {
            const candidate = blocks.find(b => b.type === "h" && (!b.slot || b.slot === "default"));
            if (candidate) headerBlocks = [candidate];
          }
          const rem = blocks.filter(b => !headerBlocks.includes(b));

          let targetCols = 2;
          if (slide.frontmatter?.layout === "three-cols-header") {
            targetCols = 3;
          } else if (slide.frontmatter?.layout === "two-cols-header") {
            targetCols = 2;
          } else {
            let maxCol = 0;
            for (const b of rem) {
              const m = (b.slot || "").match(/^col-(d+)$/i);
              if (m) maxCol = Math.max(maxCol, parseInt(m[1], 10));
            }
            if (maxCol >= 2) {
              targetCols = maxCol;
            } else if (slide.frontmatter?.layoutRatio) {
              const r = slide.frontmatter.layoutRatio.trim();
              if (r.includes(":")) {
                const parts = r.split(":").map(p => parseFloat(p.trim())).filter(n => !isNaN(n) && n > 0);
                if (parts.length >= 2) targetCols = parts.length;
              }
            }
          }

          const containerDiv = document.createElement("div");
          containerDiv.className = "layout-cols-header-container " + (targetCols === 2 ? "layout-two-cols-header-container" : (targetCols === 3 ? "layout-three-cols-header-container" : ""));
          const headerDiv = document.createElement("div");
          headerDiv.className = "layout-header-section";
          const gridDiv = document.createElement("div");
          gridDiv.className = "layout-cols-wrapper layout-cols-grid " + (targetCols === 2 ? "pdf-two-cols-wrapper layout-two-cols-grid" : (targetCols === 3 ? "pdf-three-cols-wrapper layout-three-cols-grid" : ""));

          const gridCols = parseRatioToGridCols(slide.frontmatter?.layoutRatio, targetCols);
          if (gridCols) gridDiv.style.gridTemplateColumns = gridCols;

          let colsList = [];
          for (let i = 0; i < targetCols; i++) colsList.push([]);
          const hasExplicitCols = rem.some(b => b.slot && (b.slot.startsWith("col-") || b.slot === "left" || b.slot === "right" || b.slot === "center"));
          if (hasExplicitCols) {
            for (const b of rem) {
              let idx = 0;
              if (b.slot === "left" || b.slot === "col-1") idx = 0;
              else if (b.slot === "center" || b.slot === "col-2") idx = 1;
              else if (b.slot === "right") idx = targetCols === 2 ? 1 : targetCols - 1;
              else {
                const m = (b.slot || "").match(/^col-(d+)$/i);
                if (m) idx = Math.min(targetCols - 1, Math.max(0, parseInt(m[1], 10) - 1));
              }
              colsList[idx].push(b);
            }
          } else {
            let cur = 0;
            for (let i = 0; i < targetCols; i++) {
              const remainingCols = targetCols - i;
              const remainingItems = rem.length - cur;
              const take = Math.ceil(remainingItems / remainingCols);
              colsList[i] = rem.slice(cur, cur + take);
              cur += take;
            }
          }

          const headerFirstH = !isCover ? headerBlocks.find(isHeadingBlock) : null;
          for (const b of headerBlocks) headerDiv.appendChild(renderBlock(b, b === headerFirstH ? "slidev-page-first-heading-block" : ""));
          containerDiv.appendChild(headerDiv);

          colsList.forEach((colBlocks, idx) => {
            const colDiv = document.createElement("div");
            colDiv.className = "pdf-col pdf-col--" + (idx + 1) + " col-" + (idx + 1) + (targetCols === 2 && idx === 0 ? " pdf-col--left" : "") + (targetCols === 2 && idx === 1 ? " pdf-col--right" : "");
            const cleaned = cleanColList(colBlocks);
            const colFirstH = !isCover ? (cleaned.find(isHeadingBlock) || cleaned[0]) : null;
            for (const b of cleaned) colDiv.appendChild(renderBlock(b, b === colFirstH ? "slidev-col-first-heading-block" : ""));
            gridDiv.appendChild(colDiv);
          });
          containerDiv.appendChild(gridDiv);
          container.appendChild(containerDiv);
        } else if (slide.frontmatter?.layout === "image-right" || slide.frontmatter?.layout === "image-left") {
          const isImageRight = slide.frontmatter?.layout === "image-right";
          const contentCol = document.createElement("div");
          contentCol.className = isImageRight ? "image-right-content" : "image-left-content";

          const isCover = slide.frontmatter?.layout === "cover";
          const pageFirstH = !isCover ? (slide.blocks || []).find(isHeadingBlock) : null;
          for (const block of (slide.blocks || [])) {
            contentCol.appendChild(renderBlock(block, block === pageFirstH ? "slidev-page-first-heading-block" : ""));
          }

          const imgCol = document.createElement("div");
          imgCol.className = isImageRight ? "image-right-img-container" : "image-left-img-container";
          const img = document.createElement("img");
          img.className = isImageRight ? "image-right-img" : "image-left-img";
          img.src = slide.frontmatter?.image || slide.frontmatter?.background || "";
          img.alt = "Slide cover";
          img.onerror = function() {
            this.src = "https://fastly.jsdelivr.net/gh/slidevjs/slidev-covers@main/static/2HmfbSpvcos.webp";
          };
          imgCol.appendChild(img);

          if (isImageRight) {
            container.appendChild(contentCol);
            container.appendChild(imgCol);
          } else {
            container.appendChild(imgCol);
            container.appendChild(contentCol);
          }
        } else {
          const isCover = slide.frontmatter?.layout === "cover";
          const validBlocks = (slide.blocks || []).filter(b => b.slot !== "slot-divider-right");
          const pageFirstH = !isCover ? validBlocks.find(isHeadingBlock) : null;
          for (const block of (slide.blocks || [])) {
            container.appendChild(renderBlock(block, block === pageFirstH ? "slidev-page-first-heading-block" : ""));
          }
        }

        function syncAutoplayVideos() {
          const doSync = () => {
            const videos = container.querySelectorAll("video");
            videos.forEach((v) => {
              const box = v.closest("[data-autoplay]");
              const isAuto = v.hasAttribute("autoplay") || v.autoplay || (box && box.getAttribute("data-autoplay") === "true");
              if (isAuto) {
                v.muted = true;
                v.defaultMuted = true;
                v.setAttribute("muted", "");
                v.playsInline = true;
                v.setAttribute("playsinline", "");
                const playFn = () => {
                  if (!v.paused) return;
                  v.muted = true;
                  v.defaultMuted = true;
                  const p = v.play();
                  if (p !== undefined) {
                    p.catch(() => {
                      v.muted = true;
                      v.defaultMuted = true;
                      setTimeout(() => { if (v.paused) v.play().catch(() => {}); }, 150);
                    });
                  }
                };
                playFn();
                if (!v.__autoplayBound) {
                  v.__autoplayBound = true;
                  v.addEventListener("loadedmetadata", playFn);
                  v.addEventListener("canplay", playFn);
                }
              }
            });
          };
          setTimeout(doSync, 60);
          setTimeout(doSync, 200);
        }
        syncAutoplayVideos();
      }

      // Lightbox 控制逻辑
      const lightbox = document.getElementById("slidev-lightbox");
      const lightboxContent = document.getElementById("lightbox-content");
      const lightboxClose = document.getElementById("lightbox-close");
      let isLightboxOpen = false;

      function openLightbox(type, src, alt) {
        if (!lightbox || !lightboxContent) return;
        lightboxContent.innerHTML = "";
        if (type === "video") {
          const v = document.createElement("video");
          v.className = "slidev-lightbox-video";
          v.src = src;
          v.controls = true;
          v.autoplay = true;
          v.playsInline = true;
          lightboxContent.appendChild(v);
        } else {
          const img = document.createElement("img");
          img.className = "slidev-lightbox-img";
          img.src = src;
          img.alt = alt || "";
          lightboxContent.appendChild(img);
        }
        lightbox.classList.add("active");
        isLightboxOpen = true;
      }

      function closeLightbox() {
        if (!lightbox) return;
        const v = lightbox.querySelector("video");
        if (v) v.pause();
        lightbox.classList.remove("active");
        if (lightboxContent) lightboxContent.innerHTML = "";
        isLightboxOpen = false;
      }

      if (lightboxClose) {
        lightboxClose.addEventListener("click", (e) => {
          e.stopPropagation();
          closeLightbox();
        });
      }
      if (lightbox) {
        lightbox.addEventListener("click", (e) => {
          if (e.target === lightbox || e.target === lightboxClose) {
            e.stopPropagation();
            closeLightbox();
          }
        });
      }

      btnPrev.addEventListener("click", () => renderSlide(currentIndex - 1));
      btnNext.addEventListener("click", () => renderSlide(currentIndex + 1));
      btnFullscreen.addEventListener("click", () => {
        if (!document.fullscreenElement) {
          document.documentElement.requestFullscreen().then(() => updateScale()).catch(() => {});
        } else {
          document.exitFullscreen().then(() => updateScale()).catch(() => {});
        }
      });

      window.addEventListener("keydown", (e) => {
        if (e.key === "Escape" || e.key === "Esc") {
          if (isLightboxOpen) {
            closeLightbox();
            e.preventDefault();
            return;
          }
        }
        if (isLightboxOpen) return;
        if (e.key === "ArrowRight" || e.key === " ") renderSlide(currentIndex + 1);
        if (e.key === "ArrowLeft") renderSlide(currentIndex - 1);
        if (e.key === "f" || e.key === "F") btnFullscreen.click();
      });

      // 监听鼠标滚轮上下翻页调度
      let lastWheelTime = 0;
      const WHEEL_COOLDOWN_MS = 280;
      const WHEEL_DELTA_THRESHOLD = 15;

      function canElementScrollY(el, deltaY) {
        let cur = el;
        while (cur && cur !== document.body && cur !== document.documentElement) {
          if (cur.classList && (cur.classList.contains("slidev-viewport") || cur.classList.contains("slidev-stage") || cur.classList.contains("slide-container"))) {
            break;
          }
          const style = window.getComputedStyle(cur);
          const overflowY = style.overflowY;
          if (overflowY === "auto" || overflowY === "scroll") {
            const maxScroll = cur.scrollHeight - cur.clientHeight;
            if (maxScroll > 2) {
              if (deltaY > 0 && cur.scrollTop < maxScroll - 1) return true;
              if (deltaY < 0 && cur.scrollTop > 1) return true;
            }
          }
          cur = cur.parentElement;
        }
        return false;
      }

      window.addEventListener("wheel", (e) => {
        if (isLightboxOpen) return;
        if (Math.abs(e.deltaY) < Math.abs(e.deltaX)) return;
        if (Math.abs(e.deltaY) < WHEEL_DELTA_THRESHOLD) return;

        const target = e.target instanceof Element ? e.target : e.target?.parentElement;
        if (target && canElementScrollY(target, e.deltaY)) return;

        e.preventDefault();
        const now = Date.now();
        if (now - lastWheelTime < WHEEL_COOLDOWN_MS) return;
        lastWheelTime = now;

        if (e.deltaY > 0) {
          renderSlide(currentIndex + 1);
        } else {
          renderSlide(currentIndex - 1);
        }
      }, { passive: false });

      document.addEventListener("click", (e) => {
        if (isLightboxOpen) {
          const target = e.target instanceof Element ? e.target : e.target?.parentElement;
          const isMediaItself = target && target.closest && target.closest(".slidev-lightbox-img, .slidev-lightbox-video");
          if (!isMediaItself) {
            e.stopPropagation();
            closeLightbox();
          }
          return;
        }
        if (e.button !== 0) return;
        const targetEl = e.target instanceof Element ? e.target : e.target?.parentElement;
        if (!targetEl || !targetEl.closest) return;

        const refEl = targetEl.closest("[data-ref-id]");
        if (refEl) {
          const id = refEl.getAttribute("data-ref-id");
          if (id) {
            window.open("siyuan://blocks/" + id, "_blank");
            return;
          }
        }

        // 媒体点击唤起 Lightbox 放大模态
        const mediaEl = targetEl.closest(".slide-content img, .slide-content video");
        if (mediaEl && !mediaEl.closest(".controls, .controls-bar, button, a")) {
          e.stopPropagation();
          const isVideo = mediaEl.tagName.toLowerCase() === "video";
          const src = isVideo ? (mediaEl.currentSrc || mediaEl.src || mediaEl.querySelector("source")?.src) : mediaEl.src;
          if (src) {
            openLightbox(isVideo ? "video" : "image", src, mediaEl.alt || "");
            return;
          }
        }

        const selection = window.getSelection ? window.getSelection().toString().trim() : "";
        if (selection.length > 0) return;

        const isComponent = targetEl.closest(
          ".slide-block, .controls-bar, .image-right-img-container, .image-left-img-container, .controls, img, video, audio, button, a, input, textarea, select, [data-clickable], [data-ref-id], .slidev-toc, .empty-state"
        );
        if (isComponent) return;

        const isLeft = e.clientX < window.innerWidth / 2;
        if (isLeft) {
          renderSlide(currentIndex - 1);
        } else {
          renderSlide(currentIndex + 1);
        }
      });

      renderSlide(0);
      updateScale();
    })();`}function fa(t,i){const e="Slidev 演示文稿";let n=t.slides;const o=JSON.stringify(n),s=JSON.stringify(t.config);return`<!DOCTYPE html>
<html lang="zh-CN">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${ce(e)}</title>
  <style>
${sm(i==null?void 0:i.customInlineStyles)}
  </style>
  <script>
    // 注入演示数据载荷
    window.__SLIDEV_DATA__ = {
      docId: ${JSON.stringify(t.docId)},
      slides: ${o},
      config: ${s}
    };
  <\/script>
</head>
<body>
  <div id="app" data-normalize-headings="${t.config.normalizeHeadingSizes?"true":"false"}">
    <div class="slide-viewport slidev-theme-${t.config.theme||"default"}" id="viewport" data-slidev-theme="${t.config.theme||"default"}">
      <div class="slide-content" id="slide-container"></div>
    </div>
    <div class="controls">
      <button id="btn-prev">◀ 上一页</button>
      <span id="page-num">1 / 1</span>
      <button id="btn-next">下一页 ▶</button>
      <button id="btn-fullscreen">全屏</button>
    </div>
    <!-- 全屏媒体灯箱 (Lightbox) 模态窗口 -->
    <div id="slidev-lightbox" class="slidev-lightbox">
      <button class="slidev-lightbox-close" id="lightbox-close" aria-label="关闭 (Esc)">✕</button>
      <div class="slidev-lightbox-content" id="lightbox-content"></div>
    </div>
  </div>

  <script>
${rm()}
  <\/script>
</body>
</html>`}function pa(t,i){if(typeof document>"u")return!1;const e=new Blob([i],{type:"text/html;charset=utf-8"}),n=URL.createObjectURL(e),o=document.createElement("a");return o.href=n,o.download=t.endsWith(".html")?t:`${t}.html`,document.body.appendChild(o),o.click(),document.body.removeChild(o),URL.revokeObjectURL(n),!0}function lm(t){switch(t){case"4:3":return"size: 12in 9in;";case"A4-landscape":return"size: 297mm 210mm;";case"A4-portrait":return"size: 210mm 297mm;";case"16:9":default:return"size: 16in 9in;"}}function am(t){const i=lm(t==null?void 0:t.pageRatio);return`
    ${kn(t==null?void 0:t.customInlineStyles)}

    @page {
      ${i}
      margin: 0;
    }
    * {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
      -webkit-print-color-adjust: exact !important;
      print-color-adjust: exact !important;
    }
    body {
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "PingFang SC", "Microsoft YaHei", sans-serif;
      background: #f8fafc;
      color: #1e293b;
    }
    .pdf-slide-page {
      width: 100vw;
      height: 100vh;
      page-break-after: always;
      break-after: page;
      padding: var(--slidev-padding-y, 36px) var(--slidev-padding-x, 56px);
      display: flex;
      flex-direction: column;
      position: relative;
      background: #ffffff;
      overflow: hidden;
    }
    .pdf-slide-page.spacing-compact {
      --slidev-padding-y: 20px;
      --slidev-padding-x: 36px;
      --slidev-header-gap: 10px;
      --slidev-title-margin-bottom: 6px;
    }
    .pdf-slide-page.spacing-normal {
      --slidev-padding-y: 36px;
      --slidev-padding-x: 56px;
      --slidev-header-gap: 16px;
      --slidev-title-margin-bottom: 10px;
    }
    .pdf-slide-page.spacing-loose {
      --slidev-padding-y: 48px;
      --slidev-padding-x: 64px;
      --slidev-header-gap: 24px;
      --slidev-title-margin-bottom: 16px;
    }
    .pdf-slide-page.theme-dark {
      background: #0f1117;
      color: #f1f5f9;
    }
    .pdf-slide-header {
      font-size: 13px;
      color: #64748b;
      margin-bottom: 24px;
      display: flex;
      justify-content: space-between;
      border-bottom: 1px solid #e2e8f0;
      padding-bottom: 8px;
    }
    .theme-dark .pdf-slide-header {
      border-bottom-color: #2e3346;
      color: #94a3b8;
    }
    .pdf-slide-body {
      flex: 1;
      display: flex;
      flex-direction: column;
      gap: 16px;
      font-size: 20px;
      line-height: 1.6;
      overflow: hidden;
    }
    .pdf-block h1 { font-size: 2.5rem; font-weight: 800; color: #2563eb; margin-bottom: 12px; }
    .pdf-block h2 { font-size: 1.9rem; font-weight: 700; color: #1d4ed8; margin-bottom: 10px; }
    .pdf-block h3 { font-size: 1.4rem; font-weight: 600; margin-bottom: 8px; }
    .pdf-block h4 { font-size: 1.2rem; font-weight: 600; margin-bottom: 6px; }
    .pdf-block p { font-size: 1.15rem; color: inherit; }
    .pdf-code,
    pre {
      background: #f1f5f9;
      padding: 14px 18px;
      border-radius: 6px;
      font-family: "JetBrains Mono", Consolas, monospace;
      font-size: 0.95rem;
      border-left: 4px solid #3b82f6;
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      max-width: 100% !important;
      box-sizing: border-box !important;
    }
    .pdf-code code,
    pre code {
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      display: block !important;
      width: 100% !important;
      box-sizing: border-box !important;
    }
    .code-line {
      display: flex !important;
      align-items: flex-start !important;
      width: 100% !important;
      box-sizing: border-box !important;
      line-height: 1.6;
    }
    .code-line .line-no {
      display: inline-block !important;
      flex-shrink: 0 !important;
      min-width: 2.2em !important;
      text-align: right !important;
      margin-right: 12px !important;
      user-select: none !important;
      opacity: 0.45 !important;
    }
    .code-line .line-content {
      flex: 1 1 0% !important;
      min-width: 0 !important;
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
    }
    .theme-dark .pdf-code {
      background: #1e1e24;
      border-left-color: #60a5fa;
    }
    .pdf-quote {
      border-left: 4px solid #10b981;
      background: rgba(16, 185, 129, 0.08);
      padding: 10px 16px;
      border-radius: 0 4px 4px 0;
      font-style: italic;
    }
    .pdf-image,
    .slide-media-img {
      max-width: 100% !important;
      max-height: 48vh !important;
      width: auto !important;
      height: auto !important;
      object-fit: contain !important;
      border-radius: 6px;
      margin: auto;
      display: block;
    }
    .slide-media-block,
    .slide-media-container,
    .slide-video-container {
      display: flex;
      flex-direction: column;
      justify-content: center;
      align-items: center;
      width: 100%;
      max-height: 48vh;
      margin: 8px 0;
      overflow: hidden;
    }
    .slide-list-media {
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: flex-start;
      margin-top: 8px;
      margin-bottom: 6px;
      max-width: 100%;
      overflow: hidden;
    }
    .slide-list-media img,
    .slide-list-media video,
    .slide-list-media .list-item-gif {
      max-width: 100% !important;
      max-height: min(280px, 36vh) !important;
      width: auto !important;
      height: auto !important;
      min-width: 0 !important;
      min-height: 0 !important;
      object-fit: contain !important;
      border-radius: 6px;
      display: block;
      margin: 0 auto !important;
    }
    .slide-video-player {
      max-width: 100% !important;
      max-height: 48vh !important;
      width: auto !important;
      height: auto !important;
      object-fit: contain !important;
      border-radius: 6px;
      background: #000;
      border: 1px solid #cbd5e1;
    }
    .pdf-two-cols-wrapper,
    .layout-two-cols-grid,
    .layout-cols-wrapper,
    .layout-cols-grid {
      display: grid;
      grid-template-columns: minmax(0, 1fr) minmax(0, 1fr);
      grid-template-rows: minmax(0, 1fr) !important;
      gap: 36px;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      overflow: hidden !important;
    }
    .layout-cols-header-container,
    .layout-two-cols-header-container,
    .layout-three-cols-header-container,
    .layout-clover-container {
      display: flex;
      flex-direction: column;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      overflow: hidden !important;
    }
    .layout-header-section {
      width: 100%;
      margin-bottom: var(--slidev-header-gap, 16px) !important;
      flex-shrink: 0;
    }
    .layout-header-section h1,
    .layout-header-section h2,
    .layout-header-section h3 {
      margin-bottom: var(--slidev-title-margin-bottom, 10px) !important;
    }
    .pdf-three-cols-wrapper,
    .layout-three-cols-grid {
      display: grid;
      grid-template-columns: minmax(0, 1fr) minmax(0, 1fr) minmax(0, 1fr);
      grid-template-rows: minmax(0, 1fr) !important;
      gap: 24px;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      box-sizing: border-box;
      overflow: hidden !important;
    }
    .pdf-clover-wrapper,
    .layout-clover-grid {
      display: grid;
      grid-template-columns: repeat(2, minmax(0, 1fr)) !important;
      grid-template-rows: repeat(2, minmax(0, 1fr)) !important;
      gap: 20px;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      box-sizing: border-box;
      overflow: hidden !important;
    }
    .layout-clover-grid .pdf-col {
      background: transparent !important;
      border: none !important;
      box-shadow: none !important;
    }
    .pdf-col {
      display: flex;
      flex-direction: column;
      gap: 14px;
      min-width: 0;
      width: 100%;
      max-width: 100%;
      height: 100%;
      max-height: 100%;
      min-height: 0;
      justify-content: flex-start;
      overflow: hidden;
      box-sizing: border-box;
      overflow-wrap: break-word;
      word-break: break-word;
      white-space: normal;
    }
    /* 表头多栏内超级块子块首个列表项去圆点后居中显示标题/首行文本 (仅在存在超级块分栏时生效) */
    .has-superblock-cols .pdf-col > *:first-child .slide-list-item-title,
    .has-superblock-cols .pdf-col > *:first-child :is(h1, h2, h3, h4, h5, h6),
    .has-superblock-cols .pdf-col > *:first-child p.slide-list-item-title,
    .has-superblock-cols .pdf-col > *:first-child p:first-of-type,
    .has-superblock-cols .pdf-col > *:first-child p:first-child,
    .has-superblock-cols .pdf-col > *:first-child :is(ul, ol) > li:first-child,
    .has-superblock-cols .pdf-col > *:first-child .slide-list > .slide-list-item:first-child,
    .has-superblock-cols .pdf-col > *:first-child .pdf-list > li:first-child,
    .has-superblock-cols .slidev-col-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    .has-superblock-cols .slidev-col-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      list-style: none !important;
      list-style-type: none !important;
      text-align: center !important;
      margin-left: 0 !important;
      padding-left: 0 !important;
      width: 100% !important;
    }

    /* 彻底清除首个列表项的原生圆点 Marker (仅在存在超级块分栏时生效) */
    .has-superblock-cols .pdf-col > *:first-child :is(ul, ol) > li:first-child::marker {
      content: "" !important;
      display: none !important;
    }

    /* 确保首个列表项内部内联与块级元素居中 (仅在存在超级块分栏时生效) */
    .has-superblock-cols .pdf-col > *:first-child :is(ul, ol) > li:first-child * {
      text-align: center !important;
    }

    /* 栏内说明段落与列表项：左对齐，自然阅读排版 */
    .has-superblock-cols .pdf-col .slide-list-item-desc,
    .has-superblock-cols .pdf-col li:not(:first-child) {
      text-align: left !important;
    }

    /* 全局特定标题大小规范化 (除封面外页首首个标题按 H2 1.7rem，表头多栏内首个标题按 H3 1.3rem) */
    [data-normalize-headings="true"] .slidev-page-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .slidev-page-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .pdf-slide:not(.layout-cover) > :is(.pdf-block, .slide-block):first-child :is(h1, h2, h3, h4, h5, h6),
    [data-normalize-headings="true"] .pdf-slide:not(.layout-cover) > .layout-header-section :is(.pdf-block, .slide-block):first-child :is(h1, h2, h3, h4, h5, h6),
    [data-normalize-headings="true"] .pdf-slide:not(.layout-cover) > :not(.layout-cols-wrapper):not(.pdf-two-cols-wrapper):not(.layout-image-cols-grid):first-child :is(h1, h2, h3, h4, h5, h6) {
      font-size: 1.7rem !important;
      font-weight: 600 !important;
      line-height: 1.25 !important;
      margin-bottom: 10px !important;
    }

    [data-normalize-headings="true"] .has-superblock-cols .slidev-col-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .has-superblock-cols .slidev-col-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .has-superblock-cols .pdf-col > *:first-child :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      font-size: 1.3rem !important;
      font-weight: 600 !important;
      line-height: 1.3 !important;
      margin-bottom: 8px !important;
      text-align: center !important;
    }

    /* 图左与图右版式标题完全保留用户原始字号与默认排版，不进行任何固定大小规范化 */
    [data-normalize-headings="true"] :is(.layout-image-left, .layout-image-right, .image-left-content, .image-right-content) :is(h1, h2, h3, h4, h5, h6) {
      text-align: left !important;
    }
    .pdf-col > .pdf-block,
    .pdf-col > .slide-block {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      max-height: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      width: 100% !important;
      height: 100% !important;
      box-sizing: border-box !important;
      overflow: hidden !important;
    }
    .pdf-col .slide-list-item-title,
    .pdf-col h1, .pdf-col h2, .pdf-col h3, .pdf-col h4, .pdf-col h5, .pdf-col h6,
    .pdf-col .slide-list-item-desc {
      flex: 0 0 auto !important;
      margin-top: 0 !important;
      margin-bottom: 6px !important;
    }
    .pdf-col .slide-list-media,
    .pdf-col .slide-video-container,
    .pdf-col .slide-media-container {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      min-width: 0 !important;
      width: 100% !important;
      height: 100% !important;
      max-height: 100% !important;
      max-width: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
      justify-content: flex-start !important;
      overflow: hidden !important;
      margin: 0 !important;
      padding: 0 !important;
      box-sizing: border-box !important;
    }
    .pdf-col li:has(.slide-list-media),
    .pdf-col li:has(.slide-media-container),
    .pdf-col li:has(.slide-video-container),
    .pdf-col li:has(img),
    .pdf-col li:has(video),
    .pdf-col .pdf-list-item:has(.slide-list-media),
    .pdf-col .pdf-list-item:has(.slide-media-container),
    .pdf-col .pdf-list-item:has(.slide-video-container),
    .pdf-col .pdf-list-item:has(img),
    .pdf-col .pdf-list-item:has(video) {
      display: list-item !important;
      list-style-type: disc !important;
      flex: 0 0 auto !important;
      height: auto !important;
      max-height: none !important;
      overflow: visible !important;
      margin-bottom: 6px !important;
    }
    .pdf-col video,
    .layout-three-cols-grid video,
    .layout-two-cols-grid video,
    .pdf-col img,
    .layout-three-cols-grid img,
    .layout-two-cols-grid img,
    .pdf-col .slide-video-player {
      max-width: 100% !important;
      max-height: 100% !important;
      width: auto !important;
      height: auto !important;
      min-width: 0 !important;
      min-height: 0 !important;
      object-fit: contain !important;
      display: block !important;
      margin: 0 auto !important;
    }
    .pdf-col * {
      overflow-wrap: break-word;
      word-break: break-word;
      box-sizing: border-box;
    }
    .pdf-col pre {
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      max-width: 100% !important;
      box-sizing: border-box !important;
    }
    .pdf-list-item {
      padding-left: 20px;
    }
    .pdf-list {
      padding-left: 24px;
      margin: 8px 0;
      display: flex;
      flex-direction: column;
      gap: 6px;
    }
    .pdf-list li {
      font-size: 1.15rem;
      line-height: 1.6;
    }
    .pdf-task-item {
      list-style: none;
      margin-left: -20px;
      display: flex;
      align-items: center;
      gap: 8px;
    }
    .pdf-task-item input[type="checkbox"] {
      width: 1.15em;
      height: 1.15em;
      cursor: pointer;
    }
    /* 两栏与三栏及多栏（超级块分栏）布局：紧凑自然行距，子列表保留圆点与层级缩进 */
    .layout-two-cols ul,
    .layout-cols-header ul,
    .layout-two-cols-header ul,
    .layout-three-cols ul,
    .layout-three-cols-header ul,
    .two-cols-left ul,
    .two-cols-right ul,
    .three-cols-col ul,
    .col ul,
    .pdf-two-cols-wrapper ul,
    .pdf-three-cols-wrapper ul,
    .pdf-col ul,
    .layout-two-cols-grid .pdf-list,
    .layout-three-cols-grid .pdf-list,
    .layout-cols-grid .pdf-list,
    .layout-two-cols-grid .pdf-list--unordered,
    .layout-three-cols-grid .pdf-list--unordered,
    .layout-cols-grid .pdf-list--unordered {
      list-style: disc !important;
      list-style-type: disc !important;
      padding-left: 1.25em !important;
      margin-left: 0 !important;
      margin-top: 0 !important;
      margin-bottom: 8px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: block !important;
    }
    .layout-two-cols ol,
    .layout-cols-header ol,
    .layout-two-cols-header ol,
    .layout-three-cols ol,
    .layout-three-cols-header ol,
    .two-cols-left ol,
    .two-cols-right ol,
    .three-cols-col ol,
    .col ol,
    .pdf-two-cols-wrapper ol,
    .pdf-three-cols-wrapper ol,
    .pdf-col ol,
    .layout-two-cols-grid .pdf-list--ordered,
    .layout-three-cols-grid .pdf-list--ordered,
    .layout-cols-grid .pdf-list--ordered {
      list-style: decimal !important;
      list-style-type: decimal !important;
      padding-left: 1.25em !important;
      margin-left: 0 !important;
      margin-top: 0 !important;
      margin-bottom: 8px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: block !important;
    }
    .layout-two-cols li,
    .layout-cols-header li,
    .layout-two-cols-header li,
    .layout-three-cols li,
    .layout-three-cols-header li,
    .two-cols-left li,
    .two-cols-right li,
    .three-cols-col li,
    .col li,
    .pdf-col li,
    .pdf-col .pdf-list-item {
      padding-left: 0.2em !important;
      margin-left: 0 !important;
      margin-bottom: 6px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: list-item !important;
      line-height: 1.6 !important;
    }
    .layout-two-cols ul ul,
    .layout-three-cols ul ul,
    .three-cols-col ul ul,
    .pdf-col ul ul {
      list-style: circle !important;
      list-style-type: circle !important;
      padding-left: 1.25em !important;
      margin-top: 4px !important;
      margin-bottom: 4px !important;
    }
    /* 列表项内嵌标题与说明排版 */
    .slide-list-item-title,
    .pdf-list li > h1,
    .pdf-list li > h2,
    .pdf-list li > h3,
    .pdf-list li > h4,
    .pdf-list li > h5,
    .pdf-list li > h6,
    li > h1.slide-list-item-title,
    li > h2.slide-list-item-title,
    li > h3.slide-list-item-title,
    li > h4.slide-list-item-title {
      margin-top: 2px !important;
      margin-bottom: 6px !important;
      line-height: 1.35 !important;
      font-weight: 700 !important;
    }
    .pdf-list li > h1, li > h1.slide-list-item-title { font-size: 1.6rem !important; }
    .pdf-list li > h2, li > h2.slide-list-item-title { font-size: 1.4rem !important; }
    .pdf-list li > h3, li > h3.slide-list-item-title { font-size: 1.22rem !important; }
    .pdf-list li > h4, li > h4.slide-list-item-title { font-size: 1.1rem !important; }

    /* 全局特定标题大小规范化后置强力锁定 (防止被列表项内部字号覆盖) */
    [data-normalize-headings="true"] .slidev-page-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .slidev-page-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      font-size: 1.7rem !important;
      font-weight: 600 !important;
      line-height: 1.25 !important;
      margin-bottom: 10px !important;
    }
    [data-normalize-headings="true"] .has-superblock-cols .slidev-col-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .has-superblock-cols .slidev-col-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .has-superblock-cols .pdf-col > *:first-child :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      font-size: 1.3rem !important;
      font-weight: 600 !important;
      line-height: 1.3 !important;
      margin-bottom: 8px !important;
      text-align: center !important;
    }
    .slide-list-item-desc,
    .pdf-list li > p {
      margin-top: 4px !important;
      margin-bottom: 6px !important;
      font-size: 1.05rem;
      line-height: 1.55;
      opacity: 0.92;
    }
    kbd {
      display: inline-block;
      padding: 2px 7px;
      font-family: ui-monospace, SFMono-Regular, "SF Mono", Menlo, Consolas, "Liberation Mono", monospace;
      font-size: 0.85em;
      font-weight: 600;
      line-height: 1.25;
      color: inherit;
      background: rgba(125, 125, 125, 0.12);
      border: 1px solid rgba(125, 125, 125, 0.35);
      border-bottom-width: 2px;
      border-radius: 5px;
      box-shadow: 0 1px 2px rgba(0, 0, 0, 0.12);
      margin: 0 2px;
      vertical-align: middle;
      white-space: nowrap;
    }
    .theme-dark kbd {
      background: rgba(255, 255, 255, 0.1);
      border-color: rgba(255, 255, 255, 0.25);
      border-bottom-color: rgba(255, 255, 255, 0.4);
      color: #f1f5f9;
      box-shadow: 0 1px 2px rgba(0, 0, 0, 0.4);
    }
    a {
      color: inherit;
      text-decoration: none;
      border-bottom: 1px dashed currentColor;
    }
    .slidev-ref-tag, a.slidev-ref-tag {
      display: inline-flex;
      align-items: center;
      background: rgba(16, 185, 129, 0.1);
      color: #059669;
      border: 1px solid rgba(16, 185, 129, 0.25);
      border-radius: 4px;
      padding: 2px 8px;
      font-size: 0.88em;
      text-decoration: none;
      margin: 2px 4px 2px 0;
    }
    .theme-dark .slidev-ref-tag, .theme-dark a.slidev-ref-tag {
      background: rgba(52, 211, 153, 0.15);
      color: #34d399;
      border-color: rgba(52, 211, 153, 0.3);
    }
    .slidev-block-ref, .pdf-block--ref {
      background: rgba(16, 185, 129, 0.06);
      border-left: 3px solid #059669;
      border-radius: 0 6px 6px 0;
      padding: 10px 14px;
      margin: 8px 0;
    }
    .theme-dark .slidev-block-ref, .theme-dark .pdf-block--ref {
      background: rgba(52, 211, 153, 0.08);
      border-left-color: #34d399;
    }
    .pdf-slide-notes {
      font-size: 14px;
      color: #059669;
      border-top: 1px dashed #cbd5e1;
      padding-top: 12px;
      margin-top: auto;
      line-height: 1.5;
    }
    .theme-dark .pdf-slide-notes {
      color: #34d399;
      border-top-color: #334155;
    }
    /* Layouts */
    .layout-cover .pdf-slide-body {
      justify-content: center;
      align-items: center;
      text-align: center;
    }
    .layout-cover h1 {
      font-size: 3.2rem;
    }
    .layout-center .pdf-slide-body {
      justify-content: center;
      align-items: center;
      text-align: center;
    }
    .layout-fact .pdf-slide-body {
      justify-content: center;
      align-items: center;
      text-align: center;
    }
    .layout-fact h1 {
      font-size: 4.5rem;
      color: #ef4444;
    }
    @media print {
      .slidev-motion-fade-in,
      .slidev-motion-slide-up,
      .slidev-motion-slide-down,
      .slidev-motion-slide-left,
      .slidev-motion-slide-right,
      .slidev-motion-zoom-in,
      .slidev-motion-pop,
      .slidev-motion-bounce {
        animation: none !important;
        opacity: 1 !important;
        transform: none !important;
      }
    }
  `}function cm(t,i){const e="Slidev 演示讲义",n="16:9",o="light",s=t.slides.map((l,r)=>{const a=l.frontmatter.layout||"default",c=l.frontmatter.spacing,u=c&&c!=="inherit"?c:t.config.spacing||"normal",m=Xh(l),g=`${r+1} / ${t.slides.length}`;return`
      <section class="pdf-slide-page layout-${a} theme-${o} spacing-${u}">
        <header class="pdf-slide-header">
          <span class="pdf-doc-title">${ce(e)}</span>
          ${`<span class="pdf-page-badge">P. ${g}</span>`}
        </header>
        <div class="pdf-slide-body">
          ${m}
        </div>
        ${l.notes?`
          <footer class="pdf-slide-notes">
            <strong>演讲备注:</strong> ${ce(l.notes)}
          </footer>
        `:""}
      </section>
    `}).join(`
`);return`<!DOCTYPE html>
<html lang="zh-CN">
<head>
  <meta charset="UTF-8">
  <title>${ce(e)} - 高保真讲义</title>
  <style>
    ${am({pageRatio:n,customInlineStyles:i==null?void 0:i.customInlineStyles})}
  </style>
</head>
<body data-normalize-headings="${t.config.normalizeHeadingSizes?"true":"false"}">
  ${s}
</body>
</html>`}function ha(t,i){var o;if(typeof window>"u"||typeof document>"u")return!1;const e=cm(t,i);try{const s=document.createElement("iframe");s.style.position="fixed",s.style.right="0",s.style.bottom="0",s.style.width="0",s.style.height="0",s.style.border="none",s.style.visibility="hidden",document.body.appendChild(s);const l=(o=s.contentWindow)==null?void 0:o.document;if(l)return l.open(),l.write(e),l.close(),setTimeout(()=>{var r,a;try{(r=s.contentWindow)==null||r.focus(),(a=s.contentWindow)==null||a.print()}finally{setTimeout(()=>{s.remove()},2e3)}},350),!0}catch(s){console.warn("[pdf-exporter] iframe 打印模式异常，降级尝试 window.open:",s)}const n=window.open("","_blank");return n?(n.document.write(e),n.document.close(),n.focus(),setTimeout(()=>{n.print(),n.close()},350),!0):!1}const dm={class:"spm-slidev-preview-tab"},um={class:"spm-slidev-tab__toolbar"},fm={class:"spm-slidev-tab__actions"},pm=["disabled"],hm={class:"spm-page-badge"},mm=["disabled"],gm=["aria-label"],vm=["aria-label"],bm=["src"],ym=_e({__name:"SlidevPreviewTab",setup(t,{expose:i}){const e=ei("plugin"),n=ei("sandboxBridge",new Fs),o=new Gh(n),s=new mf,l=vt("web-sandbox"),r=vt(3030),a=vt(null),c=vt(!1),u=vt(null),m=vt(1),g=vt(1),d=vt([]),b=vt(!1),f=vt(!1),v=vt(!1),k=vt("siyuan"),S=vt(""),x=vt(""),A=vt(""),T=vt(!1),I=vt(!1),w=vt(""),N=vt("/plugins/siyuan-slidev/slidev-client/index.html");let F=null,j=null,J=null,$=null,O=null,y=null,V=null;Rn(()=>{u.value&&(n.attach(u.value),s.nativeBridge.attach(u.value)),F=n.onSlideChanged((nt,E)=>{m.value=nt,g.value=E}),j=n.onBlockClicked((nt,E)=>{m.value=E,o.setActiveBlockId(nt),e&&typeof e.handleBlockClickedFromSlide=="function"?e.handleBlockClickedFromSlide(nt,E):Pi(nt,e==null?void 0:e.app)}),J=n.onOpenInEditor((nt,E)=>{m.value=E,o.setActiveBlockId(nt),Pi(nt,e==null?void 0:e.app)}),$=s.nativeBridge.onPageChanged((nt,E)=>{m.value=nt,g.value=E}),O=n.onOpenPeekDrawer(async nt=>{const E=Mo();if(nt.peekType==="siyuan"&&E.enableWebServeJump){let z=!1;if(V&&V.docId===nt.target)z=!0;else if(V&&V.slides&&V.slides.some(p=>{var H;return(H=p.blocks)==null?void 0:H.some(R=>R.id===nt.target)}))z=!1;else try{const p=await wn(`SELECT id, root_id, type FROM blocks WHERE id = '${nt.target}' LIMIT 1`);p&&p.length>0&&(z=p[0].type==="d"||p[0].id===p[0].root_id)}catch(p){console.warn("[SlidevPreviewTab] detect block type failed:",p)}k.value="web",T.value=!0,x.value=Xl(E.webServeUrl,nt.target,{focus:!z}),A.value=nt.title||`${z?"思源文档":"思源块"}: ${nt.target.slice(0,8)}`,f.value=!0,n.freezeKeyboardNav(!0)}else k.value=nt.peekType,nt.peekType==="siyuan"?(S.value=nt.target,A.value=nt.title||`块速览: ${nt.target.slice(0,8)}`):(T.value=!0,x.value=nt.target,A.value=nt.title||nt.target),f.value=!0,n.freezeKeyboardNav(!0)}),y=n.onRequestToggleFullscreen(()=>{dt()}),typeof document<"u"&&document.addEventListener("fullscreenchange",D)}),Ts(()=>{typeof document<"u"&&document.removeEventListener("fullscreenchange",D),O&&O(),y&&y(),F&&F(),j&&j(),J&&J(),$&&$(),n.detach(),o.destroy(),s.destroy()});async function X(){if(l.value==="web-sandbox"){if(!V){ht.showMessage("请先在主编辑区打开演示文档");return}ht.showMessage("正在探测本地 Node 环境并编排 Slidev Pro 进程...");const nt=await s.startProMode(V,Qo);if(!nt.success){ht.showMessage(`无法启动官方 Pro 模式：${nt.error}`);return}l.value="pro-cli",r.value=nt.port||3030,N.value=nt.url,u.value&&s.nativeBridge.attach(u.value),ht.showMessage(`🟢 已成功接入官方原生 Slidev 服务 (端口: ${r.value})`)}else s.stopProMode(),l.value="web-sandbox",N.value="/plugins/siyuan-slidev/slidev-client/index.html",u.value&&n.attach(u.value),ht.showMessage("已切回内置高保真沙箱")}function P(){I.value=!I.value,I.value?w.value=(V==null?void 0:V.docId)||"":(w.value="",Y())}let U=0;function W(nt){if(f.value||Math.abs(nt.deltaY)<Math.abs(nt.deltaX)||Math.abs(nt.deltaY)<15)return;const E=Date.now();E-U<280||(U=E,nt.deltaY>0?B():tt())}function tt(){if(m.value>1){const nt=m.value-1;m.value=nt,l.value==="pro-cli"?s.nativeBridge.navigateToPage(nt):n.navigatePage(nt)}}function B(){if(m.value<g.value){const nt=m.value+1;m.value=nt,l.value==="pro-cli"?s.nativeBridge.navigateToPage(nt):n.navigatePage(nt)}}function M(nt){m.value=nt,l.value==="pro-cli"?s.nativeBridge.navigateToPage(nt):n.navigatePage(nt)}function Y(){e&&typeof e.compileCurrentDocument=="function"?e.compileCurrentDocument():e!=null&&e.eventBus&&typeof e.eventBus.emit=="function"&&e.eventBus.emit("slidev:request-compile")}function Z(){f.value=!1,n.freezeKeyboardNav(!1)}function Q(){Z()}function D(){typeof document<"u"&&(c.value=!!document.fullscreenElement,n.postMessage("FULLSCREEN_CHANGED",{isFullscreen:c.value}))}function dt(){const nt=a.value||u.value;nt&&(document.fullscreenElement?document.exitFullscreen().then(()=>{n.postMessage("FULLSCREEN_CHANGED",{isFullscreen:!1})}).catch(()=>{}):nt.requestFullscreen().then(()=>{n.postMessage("FULLSCREEN_CHANGED",{isFullscreen:!0})}).catch(()=>{}))}function lt(){window.open("/plugins/siyuan-slidev/slidev-client/presenter.html","SlidevPresenter","width=1200,height=800")}function rt(){if(!V){ht.showMessage("请先在主编辑区打开幻灯片文档");return}const nt=fa(V);pa("presentation.html",nt)&&ht.showMessage("已开始下载单文件离线 HTML 演示包")}function gt(){if(!V){ht.showMessage("请先在主编辑区打开幻灯片文档");return}ha(V)&&ht.showMessage("已唤起打印视窗，请在打印选项中选择「另存为 PDF」")}return i({updateDocument(nt,E){I.value&&w.value&&E&&E!==w.value||(V=nt,I.value&&!w.value&&(w.value=nt.docId),d.value=nt.slides,g.value=nt.slides.length,o.setDocId(nt.docId),o.updateSlidesIndex(nt.slides),l.value==="pro-cli"?s.scaffolder.scaffold(nt,Qo).catch(()=>{}):n.updateSlides(nt.slides,nt.config,nt.fullMarkdown,nt.customThemeCss))},navigateToBlock(nt){o.onCursorFocusBlock(nt)},isPinned:I,pinnedDocId:w,engineMode:l,toggleEngineMode:X}),(nt,E)=>(ot(),st("div",dm,[h("div",um,[E[4]||(E[4]=h("div",{class:"spm-slidev-tab__title"},[h("svg",{class:"spm-slidev-tab__icon","aria-hidden":"true"},[h("use",{"xlink:href":"#iconSlidev"})]),h("span",null,"Slidev 演示预览")],-1)),h("div",fm,[h("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s",disabled:m.value<=1,"aria-label":"上一页",onClick:tt},[ut(ft,{name:"chevron-left"})],8,pm),h("span",hm,_t(m.value)+" / "+_t(g.value||1),1),h("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s",disabled:m.value>=g.value,"aria-label":"下一页",onClick:B},[ut(ft,{name:"chevron-right"})],8,mm),h("button",{class:At(["spm-icon-btn b3-tooltips b3-tooltips__s",{"is-primary":I.value}]),"aria-label":I.value?"已锁定当前文档（点击解除）："+w.value:"点击锁定当前文档（不随主编辑区切换）",onClick:P},[ut(ft,{name:"pin"}),h("span",null,_t(I.value?"已锁定":"跟随"),1)],10,gm),h("button",{class:At(["spm-icon-btn b3-tooltips b3-tooltips__s",{"is-primary":l.value==="pro-cli"}]),"aria-label":l.value==="pro-cli"?"当前：官方原生 Pro 模式 (localhost:"+r.value+")，点击切回沙箱":"当前：内置高保真沙箱，点击切换官方原生 Pro 模式",onClick:X},[ut(ft,{name:"rocket"}),h("span",null,_t(l.value==="pro-cli"?"Pro ("+r.value+")":"沙箱"),1)],10,vm),E[3]||(E[3]=h("span",{class:"spm-toolbar-divider"},null,-1)),h("button",{class:At(["spm-icon-btn b3-tooltips b3-tooltips__s",{"is-primary":b.value}]),"aria-label":"切换幻灯片大纲抽屉",onClick:E[0]||(E[0]=z=>b.value=!b.value)},[ut(ft,{name:"outline"})],2),h("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"双屏演讲者视图 (Presenter Mode ⌥M)",onClick:lt},[ut(ft,{name:"presenter"})]),h("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"导出单文件 HTML 演示包",onClick:rt},[ut(ft,{name:"export-html"})]),h("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"导出 16:9 PDF 演示讲义",onClick:gt},[ut(ft,{name:"export-pdf"})]),h("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"重新编译并刷新",onClick:Y},[ut(ft,{name:"refresh"})]),h("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"全屏放映",onClick:dt},[ut(ft,{name:"fullscreen"})])])]),h("div",{ref_key:"fullscreenContainerRef",ref:a,class:"spm-slidev-tab__viewport spm-slidev-fullscreen-container",onWheel:W},[h("iframe",{ref_key:"sandboxIframeRef",ref:u,class:"spm-slidev-tab__iframe",src:N.value,frameborder:"0",allow:"fullscreen; autoplay"},null,8,bm),ut(bh,{visible:f.value,"onUpdate:visible":E[1]||(E[1]=z=>f.value=z),"is-maximized":v.value,"onUpdate:isMaximized":E[2]||(E[2]=z=>v.value=z),title:A.value,onClose:Z},{default:yl(()=>[k.value==="siyuan"&&S.value?(ot(),Le(Ih,{key:0,"block-id":S.value,title:A.value,plugin:bt(e),onExternalJump:Q},null,8,["block-id","title","plugin"])):Ot("",!0),T.value?Te((ot(),Le(qh,{key:1,visible:f.value&&k.value==="web",url:x.value,title:A.value,onExternalJump:Q},null,8,["visible","url","title"])),[[Zl,k.value==="web"]]):Ot("",!0)]),_:1},8,["visible","is-maximized","title"])],544),b.value&&d.value.length>0?(ot(),Le(ch,{key:0,slides:d.value,"current-active-page":m.value,onNavigate:M,onRefresh:Y},null,8,["slides","current-active-page"])):Ot("",!0)]))}}),km=ze(ym,[["__scopeId","data-v-39753b89"]]),wm={class:"spm-section spm-section--page"},xm={class:"spm-section-header"},Sm={key:0,class:"spm-card-control",style:{"border-left":"3px solid var(--b3-theme-primary)",background:"rgba(var(--b3-theme-primary-rgb, 66, 133, 244), 0.06)",padding:"8px 12px","margin-top":"6px"}},_m={style:{display:"flex","align-items":"center","justify-content":"space-between",gap:"8px"}},Cm={style:{"font-size":"11px",display:"flex","align-items":"center",gap:"6px",flex:"1"}},$m={key:1,class:"spm-card-control"},Im={class:"spm-control-header"},Am={class:"spm-control-title-group"},Bm={class:"spm-control-title"},Tm={class:"spm-quick-chips"},Em=["onClick"],Mm={style:{display:"flex",gap:"6px","align-items":"center","margin-top":"6px"}},Lm=["value"],Dm=["aria-label"],Pm={key:1,class:"spm-icon-btn b3-tooltips b3-tooltips__w",disabled:"",style:{opacity:"0.45",cursor:"not-allowed",padding:"0 8px",height:"26px","font-size":"11px","white-space":"nowrap","flex-shrink":"0"},"aria-label":"当前页未检测到调整过列宽的横向超级块"},Om={key:0,style:{"margin-top":"6px","font-size":"11px",opacity:"0.85",display:"flex","align-items":"center",gap:"4px"}},Rm={style:{background:"rgba(125, 125, 125, 0.15)",padding:"1px 4px","border-radius":"3px","font-weight":"bold"}},zm={key:1,style:{"margin-top":"6px","font-size":"11px",opacity:"0.6",display:"flex","align-items":"center",gap:"4px"}},Nm={class:"spm-card-control"},Fm={class:"spm-control-header"},Hm={class:"spm-control-title-group"},jm={class:"spm-control-title"},Um={class:"spm-segmented-group"},Wm={class:"spm-card-control"},Vm={class:"spm-control-header"},qm={class:"spm-control-title-group"},Km={class:"spm-control-title"},Gm={class:"spm-quick-chips"},Zm=["onClick"],Ym=["value"],Jm={key:2,class:"spm-card-control"},Xm={class:"spm-control-header"},Qm={class:"spm-control-title-group"},tg={class:"spm-control-title"},eg={class:"spm-quick-chips"},ig=["onClick"],ng=["value"],og={class:"spm-card-control"},sg={class:"spm-control-header"},rg={class:"spm-control-title-group"},lg={class:"spm-control-title"},ag={key:0,class:"spm-note-status-box"},cg=["title"],dg={class:"spm-action-grid",style:{"margin-top":"6px"}},ug={key:1,class:"spm-note-empty-box"},fg={class:"spm-batch-actions-box",style:{"margin-top":"8px","border-top":"1px dashed var(--b3-border-color, #e2e8f0)","padding-top":"8px"}},pg={class:"spm-action-grid"},hg=["disabled"],mg=["disabled"],gg={class:"spm-card-control"},vg={class:"spm-action-grid"},bg=_e({__name:"PageInspectorSection",props:{pageLayout:{},pageTransition:{},pageBackground:{},pageSpacing:{},pageImage:{},pageNotes:{},pageIndex:{},pageLayoutRatio:{},detectedSbRatio:{},detectedSbInfo:{},isBatchProcessing:{type:Boolean}},emits:["update:pageLayout","update:pageTransition","update:pageBackground","update:pageSpacing","update:pageImage","update:pageLayoutRatio","applySuperBlockLayout","resetSuperblockRatio","addNoteBlock","locateNoteBlock","generateNotes","batchAppendNotes","batchDeleteNotes","insertDividerAfter","deleteDivider"],setup(t,{emit:i}){const e=t,n=i,o=St(()=>["two-cols","cols-header","two-cols-header","three-cols-header","image-left","image-right"].includes(e.pageLayout)),s=St(()=>{var b,f;if(e.pageLayout==="two-cols-header"||e.pageLayout==="two-cols"||e.pageLayout==="image-left"||e.pageLayout==="image-right")return 2;if(e.pageLayout==="three-cols-header")return 3;const g=(e.pageLayoutRatio||"").trim();if(g.includes(":")){const v=g.split(":").filter(Boolean).length;if(v>=2&&v<=6)return v}const d=(e.detectedSbRatio||"").trim();if(d.includes(":")){const v=d.split(":").filter(Boolean).length;if(v>=2&&v<=6)return v}if((b=e.detectedSbInfo)!=null&&b.colCount&&e.detectedSbInfo.colCount>=2)return Math.min(e.detectedSbInfo.colCount,6);if((f=e.detectedSbInfo)!=null&&f.slots&&Array.isArray(e.detectedSbInfo.slots)){const v=e.detectedSbInfo.slots.length;if(v>=2&&v<=6)return v}return 2}),l=St(()=>{const g=s.value;return g===3?[{label:"默认 1:1:1",value:""},{label:"1:2:1 (主中)",value:"1:2:1"},{label:"2:1:1 (主左)",value:"2:1:1"},{label:"1:1:2 (主右)",value:"1:1:2"},{label:"1:3:1",value:"1:3:1"}]:g===4?[{label:"默认 1:1:1:1",value:""},{label:"1:2:2:1",value:"1:2:2:1"},{label:"2:1:1:2",value:"2:1:1:2"}]:g===5?[{label:"默认 1:1:1:1:1",value:""}]:g===6?[{label:"默认 1:1:1:1:1:1",value:""}]:[{label:"默认 1:1",value:""},{label:"1:2",value:"1:2"},{label:"2:1",value:"2:1"},{label:"3:7",value:"3:7"},{label:"7:3",value:"7:3"},{label:"4:6",value:"4:6"},{label:"6:4",value:"6:4"}]}),r=St(()=>e.pageLayoutRatio||"");function a(){const g=s.value||2,d=Array(g).fill("1").join(":");n("update:pageLayoutRatio",d),n("resetSuperblockRatio")}const c=St(()=>{if(!e.pageNotes)return"";const g=e.pageNotes.replace(/[\r\n]+/g," ").trim();return g.length>50?g.slice(0,50)+"...":g}),u=[{label:"默认",value:""},{label:"暗黑 #1e1e24",value:"#1e1e24"},{label:"极夜 #0f172a",value:"#0f172a"},{label:"极简白 #ffffff",value:"#ffffff"}],m=[{label:"默认封面",value:"https://cover.sli.dev"},{label:"清空配图",value:""}];return(g,d)=>(ot(),st("div",wm,[h("div",xm,[h("span",null,"幻灯片页面设置"+_t(t.pageIndex?` (第 ${t.pageIndex} 页)`:""),1)]),ut(aa,{"model-value":t.pageLayout,onChange:d[0]||(d[0]=b=>g.$emit("update:pageLayout",b))},null,8,["model-value"]),!o.value&&t.pageLayout!=="clover"&&t.detectedSbRatio?(ot(),st("div",Sm,[h("div",_m,[h("div",Cm,[ut(ft,{name:"sparkles"}),h("span",null,[d[22]||(d[22]=Ae("检测到本页横向超级块列宽比例：",-1)),h("b",null,_t(t.detectedSbRatio),1)])]),h("button",{class:"spm-btn-action b3-tooltips b3-tooltips__w","aria-label":"一键将本页版式设为分栏并应用超级块列宽",style:{padding:"2px 8px",height:"26px","font-size":"11px","flex-shrink":"0",background:"var(--b3-theme-primary)",color:"#fff",display:"inline-flex","align-items":"center",gap:"4px"},onClick:d[1]||(d[1]=b=>g.$emit("applySuperBlockLayout",t.detectedSbInfo||{recommendedLayout:"two-cols",ratio:t.detectedSbRatio}))},[ut(ft,{name:"columns"}),d[23]||(d[23]=h("span",null,"设为分栏",-1))])])])):Ot("",!0),o.value?(ot(),st("div",$m,[h("div",Im,[h("div",Am,[h("div",Bm,[ut(ft,{name:"ratio"}),d[24]||(d[24]=h("span",null,"分栏比例 (Ratio)",-1))]),d[25]||(d[25]=h("span",{class:"spm-control-desc"},"设置各列横向空间占比，默认平均分配",-1))])]),h("div",Tm,[(ot(!0),st(Kt,null,xe(l.value,b=>(ot(),st("button",{key:b.value,class:At(["spm-chip",{active:r.value===b.value}]),onClick:f=>g.$emit("update:pageLayoutRatio",b.value)},_t(b.label),11,Em))),128))]),h("div",Mm,[h("input",{value:t.pageLayoutRatio||"",class:"spm-input",style:{flex:"1","min-width":"0"},placeholder:"自定义比例（如 1:2 或 30:70，留空为默认）",onInput:d[2]||(d[2]=b=>g.$emit("update:pageLayoutRatio",b.target.value)),onChange:d[3]||(d[3]=b=>g.$emit("update:pageLayoutRatio",b.target.value))},null,40,Lm),t.detectedSbRatio?(ot(),st("button",{key:0,class:"spm-icon-btn b3-tooltips b3-tooltips__w","aria-label":`从当前页思源超级块读取实际宽度比例 (${t.detectedSbRatio}) 并应用`,style:{padding:"0 8px",height:"26px","font-size":"11px","white-space":"nowrap","flex-shrink":"0"},onClick:d[4]||(d[4]=b=>g.$emit("update:pageLayoutRatio",t.detectedSbRatio))},[ut(ft,{name:"sparkles"}),d[26]||(d[26]=h("span",null,"读取",-1))],8,Dm)):(ot(),st("button",Pm,[ut(ft,{name:"sparkles"}),d[27]||(d[27]=h("span",null,"读取",-1))])),h("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__w","aria-label":"重置渲染比例为平均分布，并立即重置文档中超级块内容分布比例",style:{padding:"0 8px",height:"26px","font-size":"11px","white-space":"nowrap","flex-shrink":"0"},onClick:a},[ut(ft,{name:"reset"}),d[28]||(d[28]=h("span",null,"重置",-1))])]),t.detectedSbRatio?(ot(),st("div",Om,[ut(ft,{name:"ratio"}),d[29]||(d[29]=h("span",null,"检测到思源超级块宽度：",-1)),h("code",Rm,_t(t.detectedSbRatio),1)])):(ot(),st("div",zm,[ut(ft,{name:"ratio"}),d[30]||(d[30]=h("span",null,"未检测到调宽超级块（默认各列平均分配）",-1))]))])):Ot("",!0),ut(Hs,{"model-value":t.pageTransition,onChange:d[5]||(d[5]=b=>g.$emit("update:pageTransition",b))},null,8,["model-value"]),h("div",Nm,[h("div",Fm,[h("div",Hm,[h("div",jm,[ut(ft,{name:"ratio"}),d[31]||(d[31]=h("span",null,"页面间距 (Spacing)",-1))]),d[32]||(d[32]=h("span",{class:"spm-control-desc"},"覆盖本页内边距与顶部标题间距",-1))])]),h("div",Um,[h("button",{class:At(["spm-segmented-item",{active:!t.pageSpacing||t.pageSpacing==="inherit"}]),onClick:d[6]||(d[6]=b=>g.$emit("update:pageSpacing","inherit"))}," 继承全局 ",2),h("button",{class:At(["spm-segmented-item",{active:t.pageSpacing==="compact"}]),onClick:d[7]||(d[7]=b=>g.$emit("update:pageSpacing","compact"))}," 紧凑 ",2),h("button",{class:At(["spm-segmented-item",{active:t.pageSpacing==="normal"}]),onClick:d[8]||(d[8]=b=>g.$emit("update:pageSpacing","normal"))}," 标准 ",2),h("button",{class:At(["spm-segmented-item",{active:t.pageSpacing==="loose"}]),onClick:d[9]||(d[9]=b=>g.$emit("update:pageSpacing","loose"))}," 宽松 ",2)])]),h("div",Wm,[h("div",Vm,[h("div",qm,[h("div",Km,[ut(ft,{name:"palette"}),d[33]||(d[33]=h("span",null,"页面背景 (Background)",-1))]),d[34]||(d[34]=h("span",{class:"spm-control-desc"},"设置当前页特定底色或壁纸",-1))])]),h("div",Gm,[(ot(),st(Kt,null,xe(u,b=>h("button",{key:b.value,class:At(["spm-chip",{active:t.pageBackground===b.value}]),onClick:f=>g.$emit("update:pageBackground",b.value)},_t(b.label),11,Zm)),64))]),h("input",{value:t.pageBackground,class:"spm-input",placeholder:"自定义颜色代码或资源路径",onInput:d[10]||(d[10]=b=>g.$emit("update:pageBackground",b.target.value)),onChange:d[11]||(d[11]=b=>g.$emit("update:pageBackground",b.target.value))},null,40,Ym)]),t.pageLayout==="image-right"||t.pageLayout==="image-left"||t.pageImage?(ot(),st("div",Jm,[h("div",Xm,[h("div",Qm,[h("div",tg,[ut(ft,{name:"image"}),d[35]||(d[35]=h("span",null,"页面图片 (Image)",-1))]),d[36]||(d[36]=h("span",{class:"spm-control-desc"},"图文分栏或页面专属配图 URL / 资源路径",-1))])]),h("div",eg,[(ot(),st(Kt,null,xe(m,b=>h("button",{key:b.value,class:At(["spm-chip",{active:t.pageImage===b.value}]),onClick:f=>g.$emit("update:pageImage",b.value)},_t(b.label),11,ig)),64))]),h("input",{value:t.pageImage,class:"spm-input",placeholder:"网络图片 URL (如 https://cover.sli.dev) 或 assets/...",onInput:d[12]||(d[12]=b=>g.$emit("update:pageImage",b.target.value)),onChange:d[13]||(d[13]=b=>g.$emit("update:pageImage",b.target.value))},null,40,ng)])):Ot("",!0),h("div",og,[h("div",sg,[h("div",rg,[h("div",lg,[ut(ft,{name:"presenter"}),d[37]||(d[37]=h("span",null,"演讲者提词 (Notes)",-1))]),d[38]||(d[38]=h("span",{class:"spm-control-desc"},"正文备注块驱动 · 仅演讲者视图可见",-1))]),h("button",{class:"spm-btn-text b3-tooltips b3-tooltips__w","aria-label":"AI 自动生成本页讲稿提示块",onClick:d[14]||(d[14]=b=>g.$emit("generateNotes"))},[ut(ft,{name:"sparkles"}),d[39]||(d[39]=h("span",null,"AI 讲稿",-1))])]),t.pageNotes?(ot(),st("div",ag,[d[42]||(d[42]=h("div",{class:"spm-note-status-badge"},[h("span",{class:"spm-badge-dot"}),h("span",null,"已配置正文讲稿")],-1)),h("div",{class:"spm-note-preview-text",title:t.pageNotes},_t(c.value),9,cg),h("div",dg,[h("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"在正文编辑区定位并高亮此讲稿备注块",onClick:d[15]||(d[15]=b=>g.$emit("locateNoteBlock"))},[ut(ft,{name:"search"}),d[40]||(d[40]=h("span",null,"定位讲稿块",-1))]),h("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"在本页末尾追加新的讲稿提示块",onClick:d[16]||(d[16]=b=>g.$emit("addNoteBlock"))},[ut(ft,{name:"insert-below"}),d[41]||(d[41]=h("span",null,"追加讲稿块",-1))])])])):(ot(),st("div",ug,[d[44]||(d[44]=h("div",{class:"spm-note-empty-hint"},"本页暂无讲稿备注块",-1)),h("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s",style:{width:"100%","margin-top":"6px"},"aria-label":"在当前页末尾插入默认演讲备注提示块",onClick:d[17]||(d[17]=b=>g.$emit("addNoteBlock"))},[ut(ft,{name:"insert-below"}),d[43]||(d[43]=h("span",null,"添加讲稿备注块",-1))])])),h("div",fg,[h("div",pg,[h("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s",disabled:t.isBatchProcessing,style:In(t.isBatchProcessing?"opacity: 0.5; cursor: not-allowed;":""),"aria-label":"在所有尚未配置讲稿的页面末尾批量追加讲稿提示块",onClick:d[18]||(d[18]=b=>g.$emit("batchAppendNotes"))},[ut(ft,{name:"insert-below"}),d[45]||(d[45]=h("span",null,"全部追加",-1))],12,hg),h("button",{class:"spm-btn-action spm-btn-danger b3-tooltips b3-tooltips__s",disabled:t.isBatchProcessing,style:In(t.isBatchProcessing?"opacity: 0.5; cursor: not-allowed;":""),"aria-label":"批量物理删除正文中的全部讲稿备注块（涉及全部页）",onClick:d[19]||(d[19]=b=>g.$emit("batchDeleteNotes"))},[ut(ft,{name:"trash"}),d[46]||(d[46]=h("span",null,"全部删除",-1))],12,mg)])])]),h("div",gg,[d[49]||(d[49]=h("div",{class:"spm-control-header"},[h("div",{class:"spm-control-title-group"},[h("span",{class:"spm-control-title"},"分页快捷操作")])],-1)),h("div",vg,[h("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"在此分页符之后插入新的空白分页",onClick:d[20]||(d[20]=b=>g.$emit("insertDividerAfter"))},[ut(ft,{name:"insert-below"}),d[47]||(d[47]=h("span",null,"插入新页",-1))]),h("button",{class:"spm-btn-action spm-btn-danger b3-tooltips b3-tooltips__s","aria-label":"彻底删除当前分页符（合并前后页面）",onClick:d[21]||(d[21]=b=>g.$emit("deleteDivider"))},[ut(ft,{name:"trash"}),d[48]||(d[48]=h("span",null,"删除此页",-1))])])])]))}}),yg=ze(bg,[["__scopeId","data-v-9c927c7c"]]),kg={class:"spm-section spm-section--block"},wg={key:0,class:"spm-card-control",style:{"border-left":"3px solid var(--b3-theme-primary)"}},xg={class:"spm-control-header"},Sg={class:"spm-control-title-group"},_g={class:"spm-control-title"},Cg={style:{background:"var(--b3-theme-surface)",border:"1px solid var(--b3-theme-surface-lighter)","border-radius":"6px",padding:"10px","margin-bottom":"8px"}},$g={style:{display:"flex","align-items":"center","justify-content":"space-between","margin-bottom":"4px"}},Ig={style:{"font-size":"12px","font-weight":"500",display:"flex","align-items":"center",gap:"4px"}},Ag={key:0},Bg={key:1},Tg={style:{background:"rgba(var(--b3-theme-primary-rgb, 59, 130, 246), 0.16)",color:"var(--b3-theme-primary)",border:"1px solid rgba(var(--b3-theme-primary-rgb, 59, 130, 246), 0.3)",padding:"2px 6px","border-radius":"4px","font-weight":"bold","font-size":"12px"}},Eg={style:{"font-size":"11px",opacity:"0.75","line-height":"1.4"}},Mg={class:"spm-action-grid"},Lg={class:"spm-card-control"},Dg={class:"spm-control-header"},Pg={class:"spm-control-title-group"},Og={class:"spm-control-title"},Rg=["aria-label"],zg=["checked"],Ng={key:1,class:"spm-card-control"},Fg={class:"spm-control-header"},Hg={class:"spm-control-title-group"},jg={class:"spm-control-title"},Ug={class:"spm-quick-chips"},Wg={key:2,class:"spm-card-control"},Vg={class:"spm-control-header"},qg={class:"spm-control-title-group"},Kg={class:"spm-control-title"},Gg={class:"spm-video-settings-grid",style:{display:"grid","grid-template-columns":"1fr 1fr",gap:"8px","margin-top":"8px"}},Zg={class:"spm-toggle-item",style:{display:"flex","align-items":"center","justify-content":"space-between",padding:"4px 6px",background:"rgba(125,125,125,0.06)","border-radius":"4px"}},Yg={style:{"font-size":"11px",display:"inline-flex","align-items":"center",gap:"4px"}},Jg=["aria-label"],Xg=["checked"],Qg={class:"spm-toggle-item",style:{display:"flex","align-items":"center","justify-content":"space-between",padding:"4px 6px",background:"rgba(125,125,125,0.06)","border-radius":"4px"}},tv={style:{"font-size":"11px",display:"inline-flex","align-items":"center",gap:"4px"}},ev=["aria-label"],iv=["checked"],nv={class:"spm-toggle-item",style:{display:"flex","align-items":"center","justify-content":"space-between",padding:"4px 6px",background:"rgba(125,125,125,0.06)","border-radius":"4px"}},ov={style:{"font-size":"11px",display:"inline-flex","align-items":"center",gap:"4px"}},sv=["aria-label"],rv=["checked"],lv={class:"spm-toggle-item",style:{display:"flex","align-items":"center","justify-content":"space-between",padding:"4px 6px",background:"rgba(125,125,125,0.06)","border-radius":"4px"}},av={style:{"font-size":"11px",display:"inline-flex","align-items":"center",gap:"4px"}},cv=["aria-label"],dv=["checked"],uv={class:"spm-card-control"},fv={class:"spm-control-header"},pv={class:"spm-control-title-group"},hv={class:"spm-control-title"},mv=["aria-label"],gv=["checked"],vv={key:0,class:"spm-quick-chips"},bv=["onClick"],yv={key:1,class:"spm-inherit-tip",style:{"margin-top":"6px",padding:"4px 8px",background:"rgba(var(--b3-theme-primary-rgb, 59, 130, 246), 0.08)","border-radius":"4px","font-size":"11px",opacity:"0.85",display:"flex","align-items":"center",gap:"4px"}},kv={class:"spm-card-control"},wv={class:"spm-control-header"},xv={class:"spm-control-title-group"},Sv={class:"spm-control-title"},_v=["aria-label"],Cv=["checked"],$v={key:0,class:"spm-quick-chips"},Iv=["onClick"],Av={key:1,class:"spm-motion-details",style:{display:"flex","flex-direction":"column",gap:"4px","margin-top":"4px"}},Bv={style:{display:"flex",gap:"8px","justify-content":"space-between","font-size":"11px",opacity:"0.8"}},Tv={style:{display:"flex",gap:"6px"}},Ev=["value"],Mv=["value"],Lv={key:3,class:"spm-card-control"},Dv={class:"spm-control-header"},Pv={class:"spm-control-title-group"},Ov={class:"spm-control-title"},Rv={class:"spm-control-desc"},zv={class:"spm-segmented-group"},Nv=["onClick"],Fv={key:4,class:"spm-card-control"},Hv={class:"spm-control-header"},jv={class:"spm-control-title-group"},Uv={class:"spm-control-title"},Wv={class:"spm-quick-chips"},Vv=["onClick"],qv=["value"],Kv={key:5,class:"spm-card-control"},Gv={class:"spm-control-header"},Zv={class:"spm-control-title-group"},Yv={class:"spm-control-title"},Jv={class:"spm-quick-chips"},Xv=["onClick"],Qv=["value"],t1={class:"spm-card-control"},e1={class:"spm-action-grid"},i1=["aria-label"],n1=_e({__name:"BlockInspectorSection",props:{elemClick:{},elemMotion:{},elemSlot:{},elemShikiLines:{},elemMaxHeight:{},isCodeBlock:{type:Boolean},isImage:{type:Boolean},isVideo:{type:Boolean},videoAutoplay:{type:Boolean},videoLoop:{type:Boolean},videoMuted:{type:Boolean},videoControls:{type:Boolean},hasBlockAttrs:{type:Boolean},isNote:{type:Boolean},imageRole:{},currentSlideLayout:{},isSuperBlock:{type:Boolean},parentElemClick:{},parentContainerSlot:{},parentContainerId:{},detectedSbInfo:{}},emits:["toggleNote","toggleElemClick","update:elemClick","update:elemMotion","update:elemSlot","update:elemShikiLines","update:elemMaxHeight","applySuperBlockLayout","applySuperBlockRatio","insertDividerBefore","insertDividerAfter","setTwoColsContrast","clearBlockAttrs","update:imageRole","toggleVideoAutoplay","toggleVideoLoop","toggleVideoMuted","toggleVideoControls"],setup(t,{emit:i}){const e=t,n=St(()=>{const I=e.currentSlideLayout||"";return["col-1","col-2","col-3","col-4","col-5","col-6"].includes(e.elemSlot)?"cols-header":I}),o=St(()=>{const I=n.value;return["two-cols","cols-header","two-cols-header","three-cols-header"].includes(I)}),s=St(()=>{var w,N,F,j;if((w=e.detectedSbInfo)!=null&&w.colCount&&e.detectedSbInfo.colCount>=2)return Math.min(e.detectedSbInfo.colCount,6);const I=(N=e.elemSlot)==null?void 0:N.match(/^col-(\d+)$/);if(I){const J=parseInt(I[1],10);if(J>=2&&J<=6)return Math.max(J,3)}if(e.currentSlideLayout==="three-cols-header")return 3;if(e.currentSlideLayout==="two-cols-header"||e.currentSlideLayout==="two-cols")return 2;if((j=(F=e.detectedSbInfo)==null?void 0:F.ratio)!=null&&j.includes(":")){const J=e.detectedSbInfo.ratio.split(":").filter(Boolean);if(J.length>=2)return Math.min(J.length,6)}return 3}),l=St(()=>{const I=n.value;return I==="cols-header"?"多栏插槽归属 (Slot)":I==="three-cols-header"?"三栏插槽归属 (Slot)":I==="two-cols-header"?"带表头双栏插槽 (Slot)":"多栏插槽归属 (Slot)"}),r=St(()=>{const I=n.value;return I==="cols-header"?`在 cols-header 表头多栏（${s.value} 栏）中的内容块位置`:I==="three-cols-header"?"在 three-cols-header 版式中的内容块位置":I==="two-cols-header"?"在 two-cols-header 版式中的内容块位置":I==="two-cols"?"在 two-cols 双栏版式中的归属":"在当前分栏版式中的内容块位置"}),a=St(()=>{const I=n.value;if(I==="two-cols")return[{value:"",label:"默认 (左)"},{value:"right",label:"右栏"}];if(I==="two-cols-header")return[{value:"",label:"默认"},{value:"header",label:"表头"},{value:"left",label:"左栏"},{value:"right",label:"右栏"}];if(I==="three-cols-header")return[{value:"",label:"默认"},{value:"header",label:"表头"},{value:"col-1",label:"第 1 栏"},{value:"col-2",label:"第 2 栏"},{value:"col-3",label:"第 3 栏"}];const w=s.value,N=[{value:"",label:"默认"},{value:"header",label:"表头"}];for(let F=1;F<=w;F++)N.push({value:`col-${F}`,label:`第 ${F} 栏`});return N});function c(I){const w=e.elemSlot||"";return I?w===I||I==="col-1"&&w==="left"||I==="col-2"&&w==="center"||I==="col-3"&&w==="right"&&s.value===3||I==="col-2"&&w==="right"&&s.value===2||I==="left"&&w==="col-1"||I==="right"&&(w==="col-2"||w==="col-3"):!w||w==="default"}const u=i,m=[{label:"上浮 (slide-up)",value:"slide-up"},{label:"淡入 (fade-in)",value:"fade-in"},{label:"下沉 (slide-down)",value:"slide-down"},{label:"左滑 (slide-left)",value:"slide-left"},{label:"右滑 (slide-right)",value:"slide-right"},{label:"缩放 (zoom-in)",value:"zoom-in"},{label:"弹性 (bounce)",value:"bounce"}],g=St(()=>{if(!e.elemMotion||e.elemMotion.trim()===""||e.elemMotion.trim()==="none")return null;try{const I=JSON.parse(e.elemMotion);if(typeof I=="object"&&I!==null)return{preset:I.preset||I.type||"slide-up",duration:typeof I.duration=="number"?I.duration:0,delay:typeof I.delay=="number"?I.delay:0}}catch{}return{preset:e.elemMotion.trim(),duration:0,delay:0}}),d=St(()=>!!g.value),b=St(()=>{var I;return((I=g.value)==null?void 0:I.preset)||"slide-up"}),f=St(()=>{var I;return((I=g.value)==null?void 0:I.duration)||0}),v=St(()=>{var I;return((I=g.value)==null?void 0:I.delay)||0});function k(){d.value?u("update:elemMotion",""):u("update:elemMotion","slide-up")}function S(I){T(I,f.value,v.value)}function x(I){T(b.value,I,v.value)}function A(I){T(b.value,f.value,I)}function T(I,w,N){if(!I||I==="none"){u("update:elemMotion","");return}if(!w&&!N){u("update:elemMotion",I);return}const F={preset:I};w>0&&(F.duration=w),N>0&&(F.delay=N),u("update:elemMotion",JSON.stringify(F))}return(I,w)=>{var N,F,j,J,$,O;return ot(),st("div",kg,[w[62]||(w[62]=h("div",{class:"spm-section-header"},[h("span",null,"元素动效与排版")],-1)),t.isSuperBlock||(N=t.detectedSbInfo)!=null&&N.hasSuperBlock?(ot(),st("div",wg,[h("div",xg,[h("div",Sg,[h("div",_g,[ut(ft,{name:"ratio"}),w[24]||(w[24]=h("span",null,"超级块列宽与布局",-1))]),w[25]||(w[25]=h("span",{class:"spm-control-desc"},"读取思源超级块列宽并一键同步到幻灯片分栏",-1))])]),h("div",Cg,[h("div",$g,[h("div",Ig,[ut(ft,{name:"ratio"}),(F=t.detectedSbInfo)!=null&&F.isCustomWidth?(ot(),st("span",Ag,"已识别自定义列宽比例")):(ot(),st("span",Bg,"识别到 "+_t(((j=t.detectedSbInfo)==null?void 0:j.colCount)||2)+" 列超级块分栏",1))]),h("code",Tg,_t(((J=t.detectedSbInfo)==null?void 0:J.ratio)||"1:1"),1)]),h("div",Eg,_t(($=t.detectedSbInfo)!=null&&$.isCustomWidth?"检测到已调节子块宽度，可一键应用为当前页分栏比例。":"当前超级块子列为思源默认均宽，可在思源中拖动调节或直接应用。"),1)]),h("div",Mg,[h("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"一键将当前页版式切换为对应双栏/三栏，并写入此列宽比例",style:{background:"rgba(var(--b3-theme-primary-rgb, 59, 130, 246), 0.16)",color:"var(--b3-theme-primary)","font-weight":"500",border:"1px solid rgba(var(--b3-theme-primary-rgb, 59, 130, 246), 0.3)"},onClick:w[0]||(w[0]=y=>I.$emit("applySuperBlockLayout",t.detectedSbInfo))},[ut(ft,{name:"sparkles"}),w[26]||(w[26]=h("span",null,"应用版式与比例",-1))]),h("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"仅将提取的比值写入当前页的分栏比例属性",onClick:w[1]||(w[1]=y=>{var V;return I.$emit("applySuperBlockRatio",((V=t.detectedSbInfo)==null?void 0:V.ratio)||"1:1")})},[ut(ft,{name:"check"}),h("span",null,"应用比例 ("+_t(((O=t.detectedSbInfo)==null?void 0:O.ratio)||"1:1")+")",1)])])])):Ot("",!0),h("div",Lg,[h("div",Dg,[h("div",Pg,[h("div",Og,[ut(ft,{name:"presenter"}),w[27]||(w[27]=h("span",null,"设为讲稿备注 (slidev-note)",-1))]),w[28]||(w[28]=h("span",{class:"spm-control-desc"},"作为当前页演讲提词，不在幻灯片中渲染",-1))]),h("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":t.isNote?"取消讲稿备注":"设为讲稿备注"},[h("input",{type:"checkbox",checked:!!t.isNote,onChange:w[2]||(w[2]=y=>I.$emit("toggleNote"))},null,40,zg),w[29]||(w[29]=h("span",{class:"spm-switch-slider"},null,-1))],8,Rg)])]),t.isImage||t.imageRole?(ot(),st("div",Ng,[h("div",Fg,[h("div",Hg,[h("div",jg,[ut(ft,{name:"image"}),w[30]||(w[30]=h("span",null,"图片角色与分栏 (Image & Layout)",-1))]),w[31]||(w[31]=h("span",{class:"spm-control-desc"},"设为幻灯片背景图或图文分栏配图",-1))])]),h("div",Ug,[h("button",{class:At(["spm-chip",{active:!t.imageRole}]),onClick:w[3]||(w[3]=y=>I.$emit("update:imageRole",""))}," 普通内容 ",2),h("button",{class:At(["spm-chip",{active:t.imageRole==="background"}]),onClick:w[4]||(w[4]=y=>I.$emit("update:imageRole","background"))},[ut(ft,{name:"image"}),w[32]||(w[32]=h("span",null,"背景图",-1))],2),h("button",{class:At(["spm-chip",{active:t.imageRole==="image-left"}]),onClick:w[5]||(w[5]=y=>I.$emit("update:imageRole","image-left"))},[ut(ft,{name:"image-left"}),w[33]||(w[33]=h("span",null,"图左",-1))],2),h("button",{class:At(["spm-chip",{active:t.imageRole==="image-right"}]),onClick:w[6]||(w[6]=y=>I.$emit("update:imageRole","image-right"))},[ut(ft,{name:"image-right"}),w[34]||(w[34]=h("span",null,"图右",-1))],2)])])):Ot("",!0),t.isVideo?(ot(),st("div",Wg,[h("div",Vg,[h("div",qg,[h("div",Kg,[ut(ft,{name:"video"}),w[35]||(w[35]=h("span",null,"视频播放设置 (Video Playback)",-1))]),w[36]||(w[36]=h("span",{class:"spm-control-desc"},"配置播放器控制条、自动播放与循环",-1))])]),h("div",Gg,[h("div",Zg,[h("span",Yg,[ut(ft,{name:"sliders"}),w[37]||(w[37]=Ae(" 控制条",-1))]),h("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":t.videoControls?"关闭控制条":"开启控制条"},[h("input",{type:"checkbox",checked:!!t.videoControls,onChange:w[7]||(w[7]=y=>I.$emit("toggleVideoControls"))},null,40,Xg),w[38]||(w[38]=h("span",{class:"spm-switch-slider"},null,-1))],8,Jg)]),h("div",Qg,[h("span",tv,[ut(ft,{name:"video"}),w[39]||(w[39]=Ae(" 自动播放",-1))]),h("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":t.videoAutoplay?"关闭自动播放":"开启自动播放"},[h("input",{type:"checkbox",checked:!!t.videoAutoplay,onChange:w[8]||(w[8]=y=>I.$emit("toggleVideoAutoplay"))},null,40,iv),w[40]||(w[40]=h("span",{class:"spm-switch-slider"},null,-1))],8,ev)]),h("div",nv,[h("span",ov,[ut(ft,{name:"repeat"}),w[41]||(w[41]=Ae(" 循环播放",-1))]),h("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":t.videoLoop?"关闭循环播放":"开启循环播放"},[h("input",{type:"checkbox",checked:!!t.videoLoop,onChange:w[9]||(w[9]=y=>I.$emit("toggleVideoLoop"))},null,40,rv),w[42]||(w[42]=h("span",{class:"spm-switch-slider"},null,-1))],8,sv)]),h("div",lv,[h("span",av,[ut(ft,{name:"volume-x"}),w[43]||(w[43]=Ae(" 静音播放",-1))]),h("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":t.videoMuted?"关闭静音":"开启静音"},[h("input",{type:"checkbox",checked:!!t.videoMuted,onChange:w[10]||(w[10]=y=>I.$emit("toggleVideoMuted"))},null,40,dv),w[44]||(w[44]=h("span",{class:"spm-switch-slider"},null,-1))],8,cv)])])])):Ot("",!0),h("div",uv,[h("div",fv,[h("div",pv,[h("div",hv,[ut(ft,{name:"step"}),w[45]||(w[45]=h("span",null,"逐步呈现 (v-click)",-1))]),w[46]||(w[46]=h("span",{class:"spm-control-desc"},"放映时按步长逐个呈现",-1))]),h("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":t.elemClick?"关闭逐步呈现":"开启逐步呈现 (+1)"},[h("input",{type:"checkbox",checked:!!t.elemClick,onChange:w[11]||(w[11]=y=>I.$emit("toggleElemClick"))},null,40,gv),w[47]||(w[47]=h("span",{class:"spm-switch-slider"},null,-1))],8,mv)]),t.elemClick?(ot(),st("div",vv,[(ot(),st(Kt,null,xe(["+1","1","2","hide"],y=>h("button",{key:y,class:At(["spm-chip",{active:t.elemClick===y}]),onClick:V=>I.$emit("update:elemClick",y)},_t(y==="+1"?"顺延 (+1)":y==="hide"?"隐藏 (hide)":"第 "+y+" 步"),11,bv)),64))])):t.parentElemClick?(ot(),st("div",yv,[ut(ft,{name:"check"}),w[48]||(w[48]=h("span",null,"未单独开启逐步呈现：当前跟随整栏同时出现",-1))])):Ot("",!0)]),h("div",kv,[h("div",wv,[h("div",xv,[h("div",Sv,[ut(ft,{name:"motion"}),w[49]||(w[49]=h("span",null,"入场微动效 (v-motion)",-1))]),w[50]||(w[50]=h("span",{class:"spm-control-desc"},"为当前块添加平滑位移与渐入动画",-1))]),h("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":d.value?"关闭微动效":"开启微动效 (slide-up)"},[h("input",{type:"checkbox",checked:d.value,onChange:k},null,40,Cv),w[51]||(w[51]=h("span",{class:"spm-switch-slider"},null,-1))],8,_v)]),d.value?(ot(),st("div",$v,[(ot(),st(Kt,null,xe(m,y=>h("button",{key:y.value,class:At(["spm-chip",{active:b.value===y.value}]),onClick:V=>S(y.value)},_t(y.label),11,Iv)),64))])):Ot("",!0),d.value?(ot(),st("div",Av,[h("div",Bv,[h("span",null,"时长: "+_t(f.value?f.value+"ms":"默认 (450ms)"),1),h("span",null,"延迟: "+_t(v.value?v.value+"ms":"0ms"),1)]),h("div",Tv,[h("select",{class:"spm-select",style:{flex:"1"},value:f.value,onChange:w[12]||(w[12]=y=>x(Number(y.target.value)))},[...w[52]||(w[52]=[h("option",{value:0},"默认耗时",-1),h("option",{value:200},"极速 (200ms)",-1),h("option",{value:350},"较快 (350ms)",-1),h("option",{value:500},"平滑 (500ms)",-1),h("option",{value:800},"缓慢 (800ms)",-1)])],40,Ev),h("select",{class:"spm-select",style:{flex:"1"},value:v.value,onChange:w[13]||(w[13]=y=>A(Number(y.target.value)))},[...w[53]||(w[53]=[h("option",{value:0},"无延迟",-1),h("option",{value:150},"延迟 150ms",-1),h("option",{value:300},"延迟 300ms",-1),h("option",{value:500},"延迟 500ms",-1)])],40,Mv)])])):Ot("",!0)]),o.value||t.elemSlot?(ot(),st("div",Lv,[h("div",Dv,[h("div",Pv,[h("div",Ov,[ut(ft,{name:"columns"}),h("span",null,_t(l.value),1)]),h("span",Rv,_t(r.value),1)])]),h("div",zv,[(ot(!0),st(Kt,null,xe(a.value,y=>(ot(),st("button",{key:y.value,class:At(["spm-segmented-item",{active:c(y.value)}]),onClick:V=>I.$emit("update:elemSlot",y.value)},_t(y.label),11,Nv))),128))])])):Ot("",!0),t.isCodeBlock?(ot(),st("div",Fv,[h("div",Hv,[h("div",jv,[h("div",Uv,[ut(ft,{name:"code"}),w[54]||(w[54]=h("span",null,"代码逐行聚光 (Shiki)",-1))]),w[55]||(w[55]=h("span",{class:"spm-control-desc"},"翻页时动态聚光高亮特定行",-1))])]),h("div",Wv,[(ot(),st(Kt,null,xe(["1-3","all","1|2|3","2-5"],y=>h("button",{key:y,class:At(["spm-chip",{active:t.elemShikiLines===y}]),onClick:V=>I.$emit("update:elemShikiLines",y)},_t(y),11,Vv)),64)),t.elemShikiLines?(ot(),st("button",{key:0,class:"spm-chip spm-chip-clear",onClick:w[14]||(w[14]=y=>I.$emit("update:elemShikiLines",""))}," 清空 ")):Ot("",!0)]),h("input",{value:t.elemShikiLines,class:"spm-input",placeholder:"自定义高亮区间，如 1-3|5|all",onInput:w[15]||(w[15]=y=>I.$emit("update:elemShikiLines",y.target.value)),onChange:w[16]||(w[16]=y=>I.$emit("update:elemShikiLines",y.target.value))},null,40,qv)])):Ot("",!0),t.isCodeBlock?(ot(),st("div",Kv,[h("div",Gv,[h("div",Zv,[h("div",Yv,[ut(ft,{name:"code"}),w[56]||(w[56]=h("span",null,"代码块限高 (Max Height)",-1))]),w[57]||(w[57]=h("span",{class:"spm-control-desc"},"超出限高自动竖向滚动，弱提示滚动条",-1))])]),h("div",Jv,[(ot(),st(Kt,null,xe(["240px","320px","400px","50vh"],y=>h("button",{key:y,class:At(["spm-chip",{active:t.elemMaxHeight===y}]),onClick:V=>I.$emit("update:elemMaxHeight",y)},_t(y),11,Xv)),64)),t.elemMaxHeight?(ot(),st("button",{key:0,class:"spm-chip spm-chip-clear",onClick:w[17]||(w[17]=y=>I.$emit("update:elemMaxHeight",""))}," 自适应 ")):Ot("",!0)]),h("input",{value:t.elemMaxHeight,class:"spm-input",placeholder:"自适应高度，或输入 350px、50vh",onInput:w[18]||(w[18]=y=>I.$emit("update:elemMaxHeight",y.target.value)),onChange:w[19]||(w[19]=y=>I.$emit("update:elemMaxHeight",y.target.value))},null,40,Qv)])):Ot("",!0),h("div",t1,[w[61]||(w[61]=h("div",{class:"spm-control-header"},[h("div",{class:"spm-control-title-group"},[h("span",{class:"spm-control-title"},"快捷操作")])],-1)),h("div",e1,[h("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"在当前块上方插入幻灯片分页线 (---)",onClick:w[20]||(w[20]=y=>I.$emit("insertDividerBefore"))},[ut(ft,{name:"insert-above"}),w[58]||(w[58]=h("span",null,"上方分页",-1))]),h("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"在当前块下方插入幻灯片分页线 (---)",onClick:w[21]||(w[21]=y=>I.$emit("insertDividerAfter"))},[ut(ft,{name:"insert-below"}),w[59]||(w[59]=h("span",null,"下方分页",-1))]),h("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":n.value==="three-cols-header"?"将当前块属性设为三栏第1栏归属 (slot: col-1)":"将当前块属性设为双栏左侧归属 (slot: left)",onClick:w[22]||(w[22]=y=>I.$emit("setTwoColsContrast"))},[ut(ft,{name:"columns"}),h("span",null,_t(n.value==="three-cols-header"?"设为第1栏":"设为双栏"),1)],8,i1),t.hasBlockAttrs?(ot(),st("button",{key:0,class:"spm-btn-action spm-btn-danger b3-tooltips b3-tooltips__s","aria-label":"一键移除本块所有 custom-slidev 属性",onClick:w[23]||(w[23]=y=>I.$emit("clearBlockAttrs"))},[ut(ft,{name:"broom"}),w[60]||(w[60]=h("span",null,"清除属性",-1))])):Ot("",!0)])])])}}}),o1={class:"spm-section spm-section--doc"},s1={class:"spm-card-control"},r1={class:"spm-control-header"},l1={class:"spm-control-title-group"},a1={class:"spm-control-title"},c1={class:"spm-segmented-group"},d1=["aria-label","onClick"],u1={class:"spm-card-control"},f1={class:"spm-control-header"},p1={class:"spm-control-title-group"},h1={class:"spm-control-title"},m1={class:"spm-segmented-group"},g1={class:"spm-card-control"},v1={class:"spm-control-header"},b1={class:"spm-control-title-group"},y1={class:"spm-control-title"},k1={class:"spm-segmented-group"},w1={class:"spm-card-control"},x1={class:"spm-control-header"},S1={class:"spm-control-title-group"},_1={class:"spm-control-title"},C1={class:"spm-card-control"},$1={class:"spm-control-header"},I1={class:"spm-control-title-group"},A1={class:"spm-control-title"},B1=["aria-label"],T1=["checked"],E1={key:0,class:"spm-control-body",style:{"margin-top":"8px"}},M1=["value"],L1={class:"spm-card-control"},D1={class:"spm-control-header"},P1={class:"spm-control-title-group"},O1={class:"spm-control-title"},R1=["aria-label"],z1=["checked"],N1={class:"spm-card-control"},F1={class:"spm-action-grid"},H1=_e({__name:"DocInspectorSection",props:{docTheme:{},docAspectRatio:{},docDefaultTransition:{},docSpacing:{}},emits:["update:docTheme","update:docAspectRatio","update:docDefaultTransition","update:docSpacing","openBottomPreview","openPresenter","aiAutoSplit","exportHtml","exportPdf"],setup(t){const i=ei("plugin"),e=mi,n=[{value:"default",label:"默认 default",desc:"官方默认科技风：现代无衬线排版与清新代码语法高亮，通用汇报与技术分享首选"},{value:"seriph",label:"优雅 seriph",desc:"典雅学术衬线风：书卷学术质感、衬线字体典雅庄重，适合学术论文、人文讲座与深度阅读"},{value:"apple-basic",label:"极简 apple",desc:"苹果发布会极简风：大字号、高对比度与极致留白，适合产品发布、方案演讲与纯粹视觉呈现"}];function o(a){Ei({enableWebServeJump:a}),i&&typeof i.saveGlobalSettings=="function"&&i.saveGlobalSettings({enableWebServeJump:a})}async function s(a){var c;Ei({normalizeHeadingSizes:a}),i&&typeof i.saveGlobalSettings=="function"&&await i.saveGlobalSettings({normalizeHeadingSizes:a}),i&&typeof i.compileCurrentDocument=="function"&&i.compileCurrentDocument(i.currentDocId||((c=i.getActiveDocumentId)==null?void 0:c.call(i)))}function l(a){Ei({webServeUrl:a})}function r(a){Ei({webServeUrl:a}),i&&typeof i.saveGlobalSettings=="function"&&i.saveGlobalSettings({webServeUrl:a})}return(a,c)=>(ot(),st("div",o1,[c[39]||(c[39]=h("div",{class:"spm-section-header"},[h("span",null,"全局演示配置")],-1)),h("div",s1,[h("div",r1,[h("div",l1,[h("div",a1,[ut(ft,{name:"palette"}),c[18]||(c[18]=h("span",null,"幻灯片主题 (Theme)",-1))]),c[19]||(c[19]=h("span",{class:"spm-control-desc"},"全局 Slidev 视觉设计范式",-1))])]),h("div",c1,[(ot(),st(Kt,null,xe(n,u=>h("button",{key:u.value,class:At(["spm-segmented-item b3-tooltips b3-tooltips__s",{active:t.docTheme===u.value}]),"aria-label":u.desc,onClick:m=>a.$emit("update:docTheme",u.value)},_t(u.label),11,d1)),64))])]),h("div",u1,[h("div",f1,[h("div",p1,[h("div",h1,[ut(ft,{name:"ratio"}),c[20]||(c[20]=h("span",null,"画幅比例 (Aspect Ratio)",-1))]),c[21]||(c[21]=h("span",{class:"spm-control-desc"},"演讲屏幕投影宽高比",-1))])]),h("div",m1,[h("button",{class:At(["spm-segmented-item",{active:t.docAspectRatio==="16/9"}]),onClick:c[0]||(c[0]=u=>a.$emit("update:docAspectRatio","16/9"))}," 16 : 9 (宽屏) ",2),h("button",{class:At(["spm-segmented-item",{active:t.docAspectRatio==="4/3"}]),onClick:c[1]||(c[1]=u=>a.$emit("update:docAspectRatio","4/3"))}," 4 : 3 (标屏) ",2),h("button",{class:At(["spm-segmented-item",{active:t.docAspectRatio==="16/10"}]),onClick:c[2]||(c[2]=u=>a.$emit("update:docAspectRatio","16/10"))}," 16 : 10 ",2)])]),h("div",g1,[h("div",v1,[h("div",b1,[h("div",y1,[ut(ft,{name:"ratio"}),c[22]||(c[22]=h("span",null,"间距风格 (Spacing)",-1))]),c[23]||(c[23]=h("span",{class:"spm-control-desc"},"内边距与顶部标题下边距预设",-1))])]),h("div",k1,[h("button",{class:At(["spm-segmented-item b3-tooltips b3-tooltips__s",{active:(t.docSpacing||"normal")==="compact"}]),"aria-label":"紧凑排版：上下 20px / 左右 36px，释放垂直空间，适配图文分栏",onClick:c[3]||(c[3]=u=>a.$emit("update:docSpacing","compact"))}," 紧凑 (Compact) ",2),h("button",{class:At(["spm-segmented-item b3-tooltips b3-tooltips__s",{active:(t.docSpacing||"normal")==="normal"}]),"aria-label":"标准排版：上下 32px / 左右 48px，协调美观（推荐默认）",onClick:c[4]||(c[4]=u=>a.$emit("update:docSpacing","normal"))}," 标准 (Normal) ",2),h("button",{class:At(["spm-segmented-item b3-tooltips b3-tooltips__s",{active:(t.docSpacing||"normal")==="loose"}]),"aria-label":"宽松排版：上下 48px / 左右 56px，大留白适合极简大字",onClick:c[5]||(c[5]=u=>a.$emit("update:docSpacing","loose"))}," 宽松 (Loose) ",2)])]),h("div",w1,[h("div",x1,[h("div",S1,[h("div",_1,[ut(ft,{name:"transition"}),c[24]||(c[24]=h("span",null,"全局默认转场",-1))]),c[25]||(c[25]=h("span",{class:"spm-control-desc"},"页面切换过渡动效（未单设转场的页面将继承此动效）",-1))])]),ut(Hs,{"model-value":t.docDefaultTransition,"hide-header":!0,onChange:c[6]||(c[6]=u=>a.$emit("update:docDefaultTransition",u))},null,8,["model-value"])]),h("div",C1,[h("div",$1,[h("div",I1,[h("div",A1,[ut(ft,{name:"external-link"}),c[26]||(c[26]=h("span",null,"本地网络伺服预览 (Web Serve)",-1))]),c[27]||(c[27]=h("span",{class:"spm-control-desc"},"点击文档/块链接以 Webview 抽屉呈现，支持外跳",-1))]),h("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":bt(e).enableWebServeJump?"关闭本地网络伺服预览":"开启本地网络伺服预览"},[h("input",{type:"checkbox",checked:bt(e).enableWebServeJump,onChange:c[7]||(c[7]=u=>o(u.target.checked))},null,40,T1),c[28]||(c[28]=h("span",{class:"spm-switch-slider"},null,-1))],8,B1)]),bt(e).enableWebServeJump?(ot(),st("div",E1,[h("input",{value:bt(e).webServeUrl,class:"spm-input",placeholder:"http://127.0.0.1:6806",spellcheck:"false",onKeydown:c[8]||(c[8]=Me(()=>{},["stop"])),onKeyup:c[9]||(c[9]=Me(()=>{},["stop"])),onInput:c[10]||(c[10]=u=>l(u.target.value)),onChange:c[11]||(c[11]=u=>r(u.target.value))},null,40,M1),c[29]||(c[29]=h("span",{class:"spm-control-desc",style:{display:"block","margin-top":"4px","font-size":"11px",opacity:"0.8"}}," 默认伺服地址为 http://127.0.0.1:6806。开启后点击块链接将在 Webview 抽屉中打开，点击抽屉顶部『外跳』可在外部浏览器打开 ",-1))])):Ot("",!0)]),h("div",L1,[h("div",D1,[h("div",P1,[h("div",O1,[ut(ft,{name:"type"}),c[30]||(c[30]=h("span",null,"固定特定标题大小",-1))]),c[31]||(c[31]=h("span",{class:"spm-control-desc"},"除封面外页首标题按 H2、多栏内首标题按 H3 大小展示",-1))]),h("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":bt(e).normalizeHeadingSizes?"关闭固定特定标题大小":"开启固定特定标题大小"},[h("input",{type:"checkbox",checked:bt(e).normalizeHeadingSizes,onChange:c[12]||(c[12]=u=>s(u.target.checked))},null,40,z1),c[32]||(c[32]=h("span",{class:"spm-switch-slider"},null,-1))],8,R1)])]),h("div",N1,[c[38]||(c[38]=h("div",{class:"spm-control-header"},[h("div",{class:"spm-control-title-group"},[h("span",{class:"spm-control-title"},"演示全局操作")])],-1)),h("div",F1,[h("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"在当前文档下方开启分屏同步预览 (Alt+P)",onClick:c[13]||(c[13]=u=>a.$emit("openBottomPreview"))},[ut(ft,{name:"split-preview"}),c[33]||(c[33]=h("span",null,"分屏预览",-1))]),h("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"打开双屏演讲者控制台视窗 (Alt+M)",onClick:c[14]||(c[14]=u=>a.$emit("openPresenter"))},[ut(ft,{name:"presenter"}),c[34]||(c[34]=h("span",null,"演讲者视图",-1))]),h("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"智能分析长文本结构并给出大纲分页插入建议",onClick:c[15]||(c[15]=u=>a.$emit("aiAutoSplit"))},[ut(ft,{name:"sparkles"}),c[35]||(c[35]=h("span",null,"AI 智能分页",-1))]),h("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"打包导出离线单文件 HTML 幻灯片",onClick:c[16]||(c[16]=u=>a.$emit("exportHtml"))},[ut(ft,{name:"export-html"}),c[36]||(c[36]=h("span",null,"导出 HTML",-1))]),h("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s","aria-label":"打印生成 16:9 高清演示 PDF 讲义",onClick:c[17]||(c[17]=u=>a.$emit("exportPdf"))},[ut(ft,{name:"export-pdf"}),c[37]||(c[37]=h("span",null,"导出 PDF",-1))])])])]))}});var Zn=typeof globalThis<"u"?globalThis:typeof window<"u"?window:typeof global<"u"?global:typeof self<"u"?self:{};function j1(t){return t&&t.__esModule&&Object.prototype.hasOwnProperty.call(t,"default")?t.default:t}function Yn(t){throw new Error('Could not dynamically require "'+t+'". Please configure the dynamicRequireTargets or/and ignoreDynamicRequires option of @rollup/plugin-commonjs appropriately for this require call to work.')}var Yo={exports:{}};/*!

JSZip v3.10.1 - A JavaScript class for generating and reading zip files
<http://stuartk.com/jszip>

(c) 2009-2016 Stuart Knightley <stuart [at] stuartk.com>
Dual licenced under the MIT license or GPLv3. See https://raw.github.com/Stuk/jszip/main/LICENSE.markdown.

JSZip uses the library pako released under the MIT license :
https://github.com/nodeca/pako/blob/main/LICENSE
*/var Mr;function U1(){return Mr||(Mr=1,(function(t,i){(function(e){t.exports=e()})(function(){return(function e(n,o,s){function l(c,u){if(!o[c]){if(!n[c]){var m=typeof Yn=="function"&&Yn;if(!u&&m)return m(c,!0);if(r)return r(c,!0);var g=new Error("Cannot find module '"+c+"'");throw g.code="MODULE_NOT_FOUND",g}var d=o[c]={exports:{}};n[c][0].call(d.exports,function(b){var f=n[c][1][b];return l(f||b)},d,d.exports,e,n,o,s)}return o[c].exports}for(var r=typeof Yn=="function"&&Yn,a=0;a<s.length;a++)l(s[a]);return l})({1:[function(e,n,o){var s=e("./utils"),l=e("./support"),r="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";o.encode=function(a){for(var c,u,m,g,d,b,f,v=[],k=0,S=a.length,x=S,A=s.getTypeOf(a)!=="string";k<a.length;)x=S-k,m=A?(c=a[k++],u=k<S?a[k++]:0,k<S?a[k++]:0):(c=a.charCodeAt(k++),u=k<S?a.charCodeAt(k++):0,k<S?a.charCodeAt(k++):0),g=c>>2,d=(3&c)<<4|u>>4,b=1<x?(15&u)<<2|m>>6:64,f=2<x?63&m:64,v.push(r.charAt(g)+r.charAt(d)+r.charAt(b)+r.charAt(f));return v.join("")},o.decode=function(a){var c,u,m,g,d,b,f=0,v=0,k="data:";if(a.substr(0,k.length)===k)throw new Error("Invalid base64 input, it looks like a data url.");var S,x=3*(a=a.replace(/[^A-Za-z0-9+/=]/g,"")).length/4;if(a.charAt(a.length-1)===r.charAt(64)&&x--,a.charAt(a.length-2)===r.charAt(64)&&x--,x%1!=0)throw new Error("Invalid base64 input, bad content length.");for(S=l.uint8array?new Uint8Array(0|x):new Array(0|x);f<a.length;)c=r.indexOf(a.charAt(f++))<<2|(g=r.indexOf(a.charAt(f++)))>>4,u=(15&g)<<4|(d=r.indexOf(a.charAt(f++)))>>2,m=(3&d)<<6|(b=r.indexOf(a.charAt(f++))),S[v++]=c,d!==64&&(S[v++]=u),b!==64&&(S[v++]=m);return S}},{"./support":30,"./utils":32}],2:[function(e,n,o){var s=e("./external"),l=e("./stream/DataWorker"),r=e("./stream/Crc32Probe"),a=e("./stream/DataLengthProbe");function c(u,m,g,d,b){this.compressedSize=u,this.uncompressedSize=m,this.crc32=g,this.compression=d,this.compressedContent=b}c.prototype={getContentWorker:function(){var u=new l(s.Promise.resolve(this.compressedContent)).pipe(this.compression.uncompressWorker()).pipe(new a("data_length")),m=this;return u.on("end",function(){if(this.streamInfo.data_length!==m.uncompressedSize)throw new Error("Bug : uncompressed data size mismatch")}),u},getCompressedWorker:function(){return new l(s.Promise.resolve(this.compressedContent)).withStreamInfo("compressedSize",this.compressedSize).withStreamInfo("uncompressedSize",this.uncompressedSize).withStreamInfo("crc32",this.crc32).withStreamInfo("compression",this.compression)}},c.createWorkerFrom=function(u,m,g){return u.pipe(new r).pipe(new a("uncompressedSize")).pipe(m.compressWorker(g)).pipe(new a("compressedSize")).withStreamInfo("compression",m)},n.exports=c},{"./external":6,"./stream/Crc32Probe":25,"./stream/DataLengthProbe":26,"./stream/DataWorker":27}],3:[function(e,n,o){var s=e("./stream/GenericWorker");o.STORE={magic:"\0\0",compressWorker:function(){return new s("STORE compression")},uncompressWorker:function(){return new s("STORE decompression")}},o.DEFLATE=e("./flate")},{"./flate":7,"./stream/GenericWorker":28}],4:[function(e,n,o){var s=e("./utils"),l=(function(){for(var r,a=[],c=0;c<256;c++){r=c;for(var u=0;u<8;u++)r=1&r?3988292384^r>>>1:r>>>1;a[c]=r}return a})();n.exports=function(r,a){return r!==void 0&&r.length?s.getTypeOf(r)!=="string"?(function(c,u,m,g){var d=l,b=g+m;c^=-1;for(var f=g;f<b;f++)c=c>>>8^d[255&(c^u[f])];return-1^c})(0|a,r,r.length,0):(function(c,u,m,g){var d=l,b=g+m;c^=-1;for(var f=g;f<b;f++)c=c>>>8^d[255&(c^u.charCodeAt(f))];return-1^c})(0|a,r,r.length,0):0}},{"./utils":32}],5:[function(e,n,o){o.base64=!1,o.binary=!1,o.dir=!1,o.createFolders=!0,o.date=null,o.compression=null,o.compressionOptions=null,o.comment=null,o.unixPermissions=null,o.dosPermissions=null},{}],6:[function(e,n,o){var s=null;s=typeof Promise<"u"?Promise:e("lie"),n.exports={Promise:s}},{lie:37}],7:[function(e,n,o){var s=typeof Uint8Array<"u"&&typeof Uint16Array<"u"&&typeof Uint32Array<"u",l=e("pako"),r=e("./utils"),a=e("./stream/GenericWorker"),c=s?"uint8array":"array";function u(m,g){a.call(this,"FlateWorker/"+m),this._pako=null,this._pakoAction=m,this._pakoOptions=g,this.meta={}}o.magic="\b\0",r.inherits(u,a),u.prototype.processChunk=function(m){this.meta=m.meta,this._pako===null&&this._createPako(),this._pako.push(r.transformTo(c,m.data),!1)},u.prototype.flush=function(){a.prototype.flush.call(this),this._pako===null&&this._createPako(),this._pako.push([],!0)},u.prototype.cleanUp=function(){a.prototype.cleanUp.call(this),this._pako=null},u.prototype._createPako=function(){this._pako=new l[this._pakoAction]({raw:!0,level:this._pakoOptions.level||-1});var m=this;this._pako.onData=function(g){m.push({data:g,meta:m.meta})}},o.compressWorker=function(m){return new u("Deflate",m)},o.uncompressWorker=function(){return new u("Inflate",{})}},{"./stream/GenericWorker":28,"./utils":32,pako:38}],8:[function(e,n,o){function s(d,b){var f,v="";for(f=0;f<b;f++)v+=String.fromCharCode(255&d),d>>>=8;return v}function l(d,b,f,v,k,S){var x,A,T=d.file,I=d.compression,w=S!==c.utf8encode,N=r.transformTo("string",S(T.name)),F=r.transformTo("string",c.utf8encode(T.name)),j=T.comment,J=r.transformTo("string",S(j)),$=r.transformTo("string",c.utf8encode(j)),O=F.length!==T.name.length,y=$.length!==j.length,V="",X="",P="",U=T.dir,W=T.date,tt={crc32:0,compressedSize:0,uncompressedSize:0};b&&!f||(tt.crc32=d.crc32,tt.compressedSize=d.compressedSize,tt.uncompressedSize=d.uncompressedSize);var B=0;b&&(B|=8),w||!O&&!y||(B|=2048);var M=0,Y=0;U&&(M|=16),k==="UNIX"?(Y=798,M|=(function(Q,D){var dt=Q;return Q||(dt=D?16893:33204),(65535&dt)<<16})(T.unixPermissions,U)):(Y=20,M|=(function(Q){return 63&(Q||0)})(T.dosPermissions)),x=W.getUTCHours(),x<<=6,x|=W.getUTCMinutes(),x<<=5,x|=W.getUTCSeconds()/2,A=W.getUTCFullYear()-1980,A<<=4,A|=W.getUTCMonth()+1,A<<=5,A|=W.getUTCDate(),O&&(X=s(1,1)+s(u(N),4)+F,V+="up"+s(X.length,2)+X),y&&(P=s(1,1)+s(u(J),4)+$,V+="uc"+s(P.length,2)+P);var Z="";return Z+=`
\0`,Z+=s(B,2),Z+=I.magic,Z+=s(x,2),Z+=s(A,2),Z+=s(tt.crc32,4),Z+=s(tt.compressedSize,4),Z+=s(tt.uncompressedSize,4),Z+=s(N.length,2),Z+=s(V.length,2),{fileRecord:m.LOCAL_FILE_HEADER+Z+N+V,dirRecord:m.CENTRAL_FILE_HEADER+s(Y,2)+Z+s(J.length,2)+"\0\0\0\0"+s(M,4)+s(v,4)+N+V+J}}var r=e("../utils"),a=e("../stream/GenericWorker"),c=e("../utf8"),u=e("../crc32"),m=e("../signature");function g(d,b,f,v){a.call(this,"ZipFileWorker"),this.bytesWritten=0,this.zipComment=b,this.zipPlatform=f,this.encodeFileName=v,this.streamFiles=d,this.accumulate=!1,this.contentBuffer=[],this.dirRecords=[],this.currentSourceOffset=0,this.entriesCount=0,this.currentFile=null,this._sources=[]}r.inherits(g,a),g.prototype.push=function(d){var b=d.meta.percent||0,f=this.entriesCount,v=this._sources.length;this.accumulate?this.contentBuffer.push(d):(this.bytesWritten+=d.data.length,a.prototype.push.call(this,{data:d.data,meta:{currentFile:this.currentFile,percent:f?(b+100*(f-v-1))/f:100}}))},g.prototype.openedSource=function(d){this.currentSourceOffset=this.bytesWritten,this.currentFile=d.file.name;var b=this.streamFiles&&!d.file.dir;if(b){var f=l(d,b,!1,this.currentSourceOffset,this.zipPlatform,this.encodeFileName);this.push({data:f.fileRecord,meta:{percent:0}})}else this.accumulate=!0},g.prototype.closedSource=function(d){this.accumulate=!1;var b=this.streamFiles&&!d.file.dir,f=l(d,b,!0,this.currentSourceOffset,this.zipPlatform,this.encodeFileName);if(this.dirRecords.push(f.dirRecord),b)this.push({data:(function(v){return m.DATA_DESCRIPTOR+s(v.crc32,4)+s(v.compressedSize,4)+s(v.uncompressedSize,4)})(d),meta:{percent:100}});else for(this.push({data:f.fileRecord,meta:{percent:0}});this.contentBuffer.length;)this.push(this.contentBuffer.shift());this.currentFile=null},g.prototype.flush=function(){for(var d=this.bytesWritten,b=0;b<this.dirRecords.length;b++)this.push({data:this.dirRecords[b],meta:{percent:100}});var f=this.bytesWritten-d,v=(function(k,S,x,A,T){var I=r.transformTo("string",T(A));return m.CENTRAL_DIRECTORY_END+"\0\0\0\0"+s(k,2)+s(k,2)+s(S,4)+s(x,4)+s(I.length,2)+I})(this.dirRecords.length,f,d,this.zipComment,this.encodeFileName);this.push({data:v,meta:{percent:100}})},g.prototype.prepareNextSource=function(){this.previous=this._sources.shift(),this.openedSource(this.previous.streamInfo),this.isPaused?this.previous.pause():this.previous.resume()},g.prototype.registerPrevious=function(d){this._sources.push(d);var b=this;return d.on("data",function(f){b.processChunk(f)}),d.on("end",function(){b.closedSource(b.previous.streamInfo),b._sources.length?b.prepareNextSource():b.end()}),d.on("error",function(f){b.error(f)}),this},g.prototype.resume=function(){return!!a.prototype.resume.call(this)&&(!this.previous&&this._sources.length?(this.prepareNextSource(),!0):this.previous||this._sources.length||this.generatedError?void 0:(this.end(),!0))},g.prototype.error=function(d){var b=this._sources;if(!a.prototype.error.call(this,d))return!1;for(var f=0;f<b.length;f++)try{b[f].error(d)}catch{}return!0},g.prototype.lock=function(){a.prototype.lock.call(this);for(var d=this._sources,b=0;b<d.length;b++)d[b].lock()},n.exports=g},{"../crc32":4,"../signature":23,"../stream/GenericWorker":28,"../utf8":31,"../utils":32}],9:[function(e,n,o){var s=e("../compressions"),l=e("./ZipFileWorker");o.generateWorker=function(r,a,c){var u=new l(a.streamFiles,c,a.platform,a.encodeFileName),m=0;try{r.forEach(function(g,d){m++;var b=(function(S,x){var A=S||x,T=s[A];if(!T)throw new Error(A+" is not a valid compression method !");return T})(d.options.compression,a.compression),f=d.options.compressionOptions||a.compressionOptions||{},v=d.dir,k=d.date;d._compressWorker(b,f).withStreamInfo("file",{name:g,dir:v,date:k,comment:d.comment||"",unixPermissions:d.unixPermissions,dosPermissions:d.dosPermissions}).pipe(u)}),u.entriesCount=m}catch(g){u.error(g)}return u}},{"../compressions":3,"./ZipFileWorker":8}],10:[function(e,n,o){function s(){if(!(this instanceof s))return new s;if(arguments.length)throw new Error("The constructor with parameters has been removed in JSZip 3.0, please check the upgrade guide.");this.files=Object.create(null),this.comment=null,this.root="",this.clone=function(){var l=new s;for(var r in this)typeof this[r]!="function"&&(l[r]=this[r]);return l}}(s.prototype=e("./object")).loadAsync=e("./load"),s.support=e("./support"),s.defaults=e("./defaults"),s.version="3.10.1",s.loadAsync=function(l,r){return new s().loadAsync(l,r)},s.external=e("./external"),n.exports=s},{"./defaults":5,"./external":6,"./load":11,"./object":15,"./support":30}],11:[function(e,n,o){var s=e("./utils"),l=e("./external"),r=e("./utf8"),a=e("./zipEntries"),c=e("./stream/Crc32Probe"),u=e("./nodejsUtils");function m(g){return new l.Promise(function(d,b){var f=g.decompressed.getContentWorker().pipe(new c);f.on("error",function(v){b(v)}).on("end",function(){f.streamInfo.crc32!==g.decompressed.crc32?b(new Error("Corrupted zip : CRC32 mismatch")):d()}).resume()})}n.exports=function(g,d){var b=this;return d=s.extend(d||{},{base64:!1,checkCRC32:!1,optimizedBinaryString:!1,createFolders:!1,decodeFileName:r.utf8decode}),u.isNode&&u.isStream(g)?l.Promise.reject(new Error("JSZip can't accept a stream when loading a zip file.")):s.prepareContent("the loaded zip file",g,!0,d.optimizedBinaryString,d.base64).then(function(f){var v=new a(d);return v.load(f),v}).then(function(f){var v=[l.Promise.resolve(f)],k=f.files;if(d.checkCRC32)for(var S=0;S<k.length;S++)v.push(m(k[S]));return l.Promise.all(v)}).then(function(f){for(var v=f.shift(),k=v.files,S=0;S<k.length;S++){var x=k[S],A=x.fileNameStr,T=s.resolve(x.fileNameStr);b.file(T,x.decompressed,{binary:!0,optimizedBinaryString:!0,date:x.date,dir:x.dir,comment:x.fileCommentStr.length?x.fileCommentStr:null,unixPermissions:x.unixPermissions,dosPermissions:x.dosPermissions,createFolders:d.createFolders}),x.dir||(b.file(T).unsafeOriginalName=A)}return v.zipComment.length&&(b.comment=v.zipComment),b})}},{"./external":6,"./nodejsUtils":14,"./stream/Crc32Probe":25,"./utf8":31,"./utils":32,"./zipEntries":33}],12:[function(e,n,o){var s=e("../utils"),l=e("../stream/GenericWorker");function r(a,c){l.call(this,"Nodejs stream input adapter for "+a),this._upstreamEnded=!1,this._bindStream(c)}s.inherits(r,l),r.prototype._bindStream=function(a){var c=this;(this._stream=a).pause(),a.on("data",function(u){c.push({data:u,meta:{percent:0}})}).on("error",function(u){c.isPaused?this.generatedError=u:c.error(u)}).on("end",function(){c.isPaused?c._upstreamEnded=!0:c.end()})},r.prototype.pause=function(){return!!l.prototype.pause.call(this)&&(this._stream.pause(),!0)},r.prototype.resume=function(){return!!l.prototype.resume.call(this)&&(this._upstreamEnded?this.end():this._stream.resume(),!0)},n.exports=r},{"../stream/GenericWorker":28,"../utils":32}],13:[function(e,n,o){var s=e("readable-stream").Readable;function l(r,a,c){s.call(this,a),this._helper=r;var u=this;r.on("data",function(m,g){u.push(m)||u._helper.pause(),c&&c(g)}).on("error",function(m){u.emit("error",m)}).on("end",function(){u.push(null)})}e("../utils").inherits(l,s),l.prototype._read=function(){this._helper.resume()},n.exports=l},{"../utils":32,"readable-stream":16}],14:[function(e,n,o){n.exports={isNode:typeof Buffer<"u",newBufferFrom:function(s,l){if(Buffer.from&&Buffer.from!==Uint8Array.from)return Buffer.from(s,l);if(typeof s=="number")throw new Error('The "data" argument must not be a number');return new Buffer(s,l)},allocBuffer:function(s){if(Buffer.alloc)return Buffer.alloc(s);var l=new Buffer(s);return l.fill(0),l},isBuffer:function(s){return Buffer.isBuffer(s)},isStream:function(s){return s&&typeof s.on=="function"&&typeof s.pause=="function"&&typeof s.resume=="function"}}},{}],15:[function(e,n,o){function s(T,I,w){var N,F=r.getTypeOf(I),j=r.extend(w||{},u);j.date=j.date||new Date,j.compression!==null&&(j.compression=j.compression.toUpperCase()),typeof j.unixPermissions=="string"&&(j.unixPermissions=parseInt(j.unixPermissions,8)),j.unixPermissions&&16384&j.unixPermissions&&(j.dir=!0),j.dosPermissions&&16&j.dosPermissions&&(j.dir=!0),j.dir&&(T=k(T)),j.createFolders&&(N=v(T))&&S.call(this,N,!0);var J=F==="string"&&j.binary===!1&&j.base64===!1;w&&w.binary!==void 0||(j.binary=!J),(I instanceof m&&I.uncompressedSize===0||j.dir||!I||I.length===0)&&(j.base64=!1,j.binary=!0,I="",j.compression="STORE",F="string");var $=null;$=I instanceof m||I instanceof a?I:b.isNode&&b.isStream(I)?new f(T,I):r.prepareContent(T,I,j.binary,j.optimizedBinaryString,j.base64);var O=new g(T,$,j);this.files[T]=O}var l=e("./utf8"),r=e("./utils"),a=e("./stream/GenericWorker"),c=e("./stream/StreamHelper"),u=e("./defaults"),m=e("./compressedObject"),g=e("./zipObject"),d=e("./generate"),b=e("./nodejsUtils"),f=e("./nodejs/NodejsStreamInputAdapter"),v=function(T){T.slice(-1)==="/"&&(T=T.substring(0,T.length-1));var I=T.lastIndexOf("/");return 0<I?T.substring(0,I):""},k=function(T){return T.slice(-1)!=="/"&&(T+="/"),T},S=function(T,I){return I=I!==void 0?I:u.createFolders,T=k(T),this.files[T]||s.call(this,T,null,{dir:!0,createFolders:I}),this.files[T]};function x(T){return Object.prototype.toString.call(T)==="[object RegExp]"}var A={load:function(){throw new Error("This method has been removed in JSZip 3.0, please check the upgrade guide.")},forEach:function(T){var I,w,N;for(I in this.files)N=this.files[I],(w=I.slice(this.root.length,I.length))&&I.slice(0,this.root.length)===this.root&&T(w,N)},filter:function(T){var I=[];return this.forEach(function(w,N){T(w,N)&&I.push(N)}),I},file:function(T,I,w){if(arguments.length!==1)return T=this.root+T,s.call(this,T,I,w),this;if(x(T)){var N=T;return this.filter(function(j,J){return!J.dir&&N.test(j)})}var F=this.files[this.root+T];return F&&!F.dir?F:null},folder:function(T){if(!T)return this;if(x(T))return this.filter(function(F,j){return j.dir&&T.test(F)});var I=this.root+T,w=S.call(this,I),N=this.clone();return N.root=w.name,N},remove:function(T){T=this.root+T;var I=this.files[T];if(I||(T.slice(-1)!=="/"&&(T+="/"),I=this.files[T]),I&&!I.dir)delete this.files[T];else for(var w=this.filter(function(F,j){return j.name.slice(0,T.length)===T}),N=0;N<w.length;N++)delete this.files[w[N].name];return this},generate:function(){throw new Error("This method has been removed in JSZip 3.0, please check the upgrade guide.")},generateInternalStream:function(T){var I,w={};try{if((w=r.extend(T||{},{streamFiles:!1,compression:"STORE",compressionOptions:null,type:"",platform:"DOS",comment:null,mimeType:"application/zip",encodeFileName:l.utf8encode})).type=w.type.toLowerCase(),w.compression=w.compression.toUpperCase(),w.type==="binarystring"&&(w.type="string"),!w.type)throw new Error("No output type specified.");r.checkSupport(w.type),w.platform!=="darwin"&&w.platform!=="freebsd"&&w.platform!=="linux"&&w.platform!=="sunos"||(w.platform="UNIX"),w.platform==="win32"&&(w.platform="DOS");var N=w.comment||this.comment||"";I=d.generateWorker(this,w,N)}catch(F){(I=new a("error")).error(F)}return new c(I,w.type||"string",w.mimeType)},generateAsync:function(T,I){return this.generateInternalStream(T).accumulate(I)},generateNodeStream:function(T,I){return(T=T||{}).type||(T.type="nodebuffer"),this.generateInternalStream(T).toNodejsStream(I)}};n.exports=A},{"./compressedObject":2,"./defaults":5,"./generate":9,"./nodejs/NodejsStreamInputAdapter":12,"./nodejsUtils":14,"./stream/GenericWorker":28,"./stream/StreamHelper":29,"./utf8":31,"./utils":32,"./zipObject":35}],16:[function(e,n,o){n.exports=e("stream")},{stream:void 0}],17:[function(e,n,o){var s=e("./DataReader");function l(r){s.call(this,r);for(var a=0;a<this.data.length;a++)r[a]=255&r[a]}e("../utils").inherits(l,s),l.prototype.byteAt=function(r){return this.data[this.zero+r]},l.prototype.lastIndexOfSignature=function(r){for(var a=r.charCodeAt(0),c=r.charCodeAt(1),u=r.charCodeAt(2),m=r.charCodeAt(3),g=this.length-4;0<=g;--g)if(this.data[g]===a&&this.data[g+1]===c&&this.data[g+2]===u&&this.data[g+3]===m)return g-this.zero;return-1},l.prototype.readAndCheckSignature=function(r){var a=r.charCodeAt(0),c=r.charCodeAt(1),u=r.charCodeAt(2),m=r.charCodeAt(3),g=this.readData(4);return a===g[0]&&c===g[1]&&u===g[2]&&m===g[3]},l.prototype.readData=function(r){if(this.checkOffset(r),r===0)return[];var a=this.data.slice(this.zero+this.index,this.zero+this.index+r);return this.index+=r,a},n.exports=l},{"../utils":32,"./DataReader":18}],18:[function(e,n,o){var s=e("../utils");function l(r){this.data=r,this.length=r.length,this.index=0,this.zero=0}l.prototype={checkOffset:function(r){this.checkIndex(this.index+r)},checkIndex:function(r){if(this.length<this.zero+r||r<0)throw new Error("End of data reached (data length = "+this.length+", asked index = "+r+"). Corrupted zip ?")},setIndex:function(r){this.checkIndex(r),this.index=r},skip:function(r){this.setIndex(this.index+r)},byteAt:function(){},readInt:function(r){var a,c=0;for(this.checkOffset(r),a=this.index+r-1;a>=this.index;a--)c=(c<<8)+this.byteAt(a);return this.index+=r,c},readString:function(r){return s.transformTo("string",this.readData(r))},readData:function(){},lastIndexOfSignature:function(){},readAndCheckSignature:function(){},readDate:function(){var r=this.readInt(4);return new Date(Date.UTC(1980+(r>>25&127),(r>>21&15)-1,r>>16&31,r>>11&31,r>>5&63,(31&r)<<1))}},n.exports=l},{"../utils":32}],19:[function(e,n,o){var s=e("./Uint8ArrayReader");function l(r){s.call(this,r)}e("../utils").inherits(l,s),l.prototype.readData=function(r){this.checkOffset(r);var a=this.data.slice(this.zero+this.index,this.zero+this.index+r);return this.index+=r,a},n.exports=l},{"../utils":32,"./Uint8ArrayReader":21}],20:[function(e,n,o){var s=e("./DataReader");function l(r){s.call(this,r)}e("../utils").inherits(l,s),l.prototype.byteAt=function(r){return this.data.charCodeAt(this.zero+r)},l.prototype.lastIndexOfSignature=function(r){return this.data.lastIndexOf(r)-this.zero},l.prototype.readAndCheckSignature=function(r){return r===this.readData(4)},l.prototype.readData=function(r){this.checkOffset(r);var a=this.data.slice(this.zero+this.index,this.zero+this.index+r);return this.index+=r,a},n.exports=l},{"../utils":32,"./DataReader":18}],21:[function(e,n,o){var s=e("./ArrayReader");function l(r){s.call(this,r)}e("../utils").inherits(l,s),l.prototype.readData=function(r){if(this.checkOffset(r),r===0)return new Uint8Array(0);var a=this.data.subarray(this.zero+this.index,this.zero+this.index+r);return this.index+=r,a},n.exports=l},{"../utils":32,"./ArrayReader":17}],22:[function(e,n,o){var s=e("../utils"),l=e("../support"),r=e("./ArrayReader"),a=e("./StringReader"),c=e("./NodeBufferReader"),u=e("./Uint8ArrayReader");n.exports=function(m){var g=s.getTypeOf(m);return s.checkSupport(g),g!=="string"||l.uint8array?g==="nodebuffer"?new c(m):l.uint8array?new u(s.transformTo("uint8array",m)):new r(s.transformTo("array",m)):new a(m)}},{"../support":30,"../utils":32,"./ArrayReader":17,"./NodeBufferReader":19,"./StringReader":20,"./Uint8ArrayReader":21}],23:[function(e,n,o){o.LOCAL_FILE_HEADER="PK",o.CENTRAL_FILE_HEADER="PK",o.CENTRAL_DIRECTORY_END="PK",o.ZIP64_CENTRAL_DIRECTORY_LOCATOR="PK\x07",o.ZIP64_CENTRAL_DIRECTORY_END="PK",o.DATA_DESCRIPTOR="PK\x07\b"},{}],24:[function(e,n,o){var s=e("./GenericWorker"),l=e("../utils");function r(a){s.call(this,"ConvertWorker to "+a),this.destType=a}l.inherits(r,s),r.prototype.processChunk=function(a){this.push({data:l.transformTo(this.destType,a.data),meta:a.meta})},n.exports=r},{"../utils":32,"./GenericWorker":28}],25:[function(e,n,o){var s=e("./GenericWorker"),l=e("../crc32");function r(){s.call(this,"Crc32Probe"),this.withStreamInfo("crc32",0)}e("../utils").inherits(r,s),r.prototype.processChunk=function(a){this.streamInfo.crc32=l(a.data,this.streamInfo.crc32||0),this.push(a)},n.exports=r},{"../crc32":4,"../utils":32,"./GenericWorker":28}],26:[function(e,n,o){var s=e("../utils"),l=e("./GenericWorker");function r(a){l.call(this,"DataLengthProbe for "+a),this.propName=a,this.withStreamInfo(a,0)}s.inherits(r,l),r.prototype.processChunk=function(a){if(a){var c=this.streamInfo[this.propName]||0;this.streamInfo[this.propName]=c+a.data.length}l.prototype.processChunk.call(this,a)},n.exports=r},{"../utils":32,"./GenericWorker":28}],27:[function(e,n,o){var s=e("../utils"),l=e("./GenericWorker");function r(a){l.call(this,"DataWorker");var c=this;this.dataIsReady=!1,this.index=0,this.max=0,this.data=null,this.type="",this._tickScheduled=!1,a.then(function(u){c.dataIsReady=!0,c.data=u,c.max=u&&u.length||0,c.type=s.getTypeOf(u),c.isPaused||c._tickAndRepeat()},function(u){c.error(u)})}s.inherits(r,l),r.prototype.cleanUp=function(){l.prototype.cleanUp.call(this),this.data=null},r.prototype.resume=function(){return!!l.prototype.resume.call(this)&&(!this._tickScheduled&&this.dataIsReady&&(this._tickScheduled=!0,s.delay(this._tickAndRepeat,[],this)),!0)},r.prototype._tickAndRepeat=function(){this._tickScheduled=!1,this.isPaused||this.isFinished||(this._tick(),this.isFinished||(s.delay(this._tickAndRepeat,[],this),this._tickScheduled=!0))},r.prototype._tick=function(){if(this.isPaused||this.isFinished)return!1;var a=null,c=Math.min(this.max,this.index+16384);if(this.index>=this.max)return this.end();switch(this.type){case"string":a=this.data.substring(this.index,c);break;case"uint8array":a=this.data.subarray(this.index,c);break;case"array":case"nodebuffer":a=this.data.slice(this.index,c)}return this.index=c,this.push({data:a,meta:{percent:this.max?this.index/this.max*100:0}})},n.exports=r},{"../utils":32,"./GenericWorker":28}],28:[function(e,n,o){function s(l){this.name=l||"default",this.streamInfo={},this.generatedError=null,this.extraStreamInfo={},this.isPaused=!0,this.isFinished=!1,this.isLocked=!1,this._listeners={data:[],end:[],error:[]},this.previous=null}s.prototype={push:function(l){this.emit("data",l)},end:function(){if(this.isFinished)return!1;this.flush();try{this.emit("end"),this.cleanUp(),this.isFinished=!0}catch(l){this.emit("error",l)}return!0},error:function(l){return!this.isFinished&&(this.isPaused?this.generatedError=l:(this.isFinished=!0,this.emit("error",l),this.previous&&this.previous.error(l),this.cleanUp()),!0)},on:function(l,r){return this._listeners[l].push(r),this},cleanUp:function(){this.streamInfo=this.generatedError=this.extraStreamInfo=null,this._listeners=[]},emit:function(l,r){if(this._listeners[l])for(var a=0;a<this._listeners[l].length;a++)this._listeners[l][a].call(this,r)},pipe:function(l){return l.registerPrevious(this)},registerPrevious:function(l){if(this.isLocked)throw new Error("The stream '"+this+"' has already been used.");this.streamInfo=l.streamInfo,this.mergeStreamInfo(),this.previous=l;var r=this;return l.on("data",function(a){r.processChunk(a)}),l.on("end",function(){r.end()}),l.on("error",function(a){r.error(a)}),this},pause:function(){return!this.isPaused&&!this.isFinished&&(this.isPaused=!0,this.previous&&this.previous.pause(),!0)},resume:function(){if(!this.isPaused||this.isFinished)return!1;var l=this.isPaused=!1;return this.generatedError&&(this.error(this.generatedError),l=!0),this.previous&&this.previous.resume(),!l},flush:function(){},processChunk:function(l){this.push(l)},withStreamInfo:function(l,r){return this.extraStreamInfo[l]=r,this.mergeStreamInfo(),this},mergeStreamInfo:function(){for(var l in this.extraStreamInfo)Object.prototype.hasOwnProperty.call(this.extraStreamInfo,l)&&(this.streamInfo[l]=this.extraStreamInfo[l])},lock:function(){if(this.isLocked)throw new Error("The stream '"+this+"' has already been used.");this.isLocked=!0,this.previous&&this.previous.lock()},toString:function(){var l="Worker "+this.name;return this.previous?this.previous+" -> "+l:l}},n.exports=s},{}],29:[function(e,n,o){var s=e("../utils"),l=e("./ConvertWorker"),r=e("./GenericWorker"),a=e("../base64"),c=e("../support"),u=e("../external"),m=null;if(c.nodestream)try{m=e("../nodejs/NodejsStreamOutputAdapter")}catch{}function g(b,f){return new u.Promise(function(v,k){var S=[],x=b._internalType,A=b._outputType,T=b._mimeType;b.on("data",function(I,w){S.push(I),f&&f(w)}).on("error",function(I){S=[],k(I)}).on("end",function(){try{var I=(function(w,N,F){switch(w){case"blob":return s.newBlob(s.transformTo("arraybuffer",N),F);case"base64":return a.encode(N);default:return s.transformTo(w,N)}})(A,(function(w,N){var F,j=0,J=null,$=0;for(F=0;F<N.length;F++)$+=N[F].length;switch(w){case"string":return N.join("");case"array":return Array.prototype.concat.apply([],N);case"uint8array":for(J=new Uint8Array($),F=0;F<N.length;F++)J.set(N[F],j),j+=N[F].length;return J;case"nodebuffer":return Buffer.concat(N);default:throw new Error("concat : unsupported type '"+w+"'")}})(x,S),T);v(I)}catch(w){k(w)}S=[]}).resume()})}function d(b,f,v){var k=f;switch(f){case"blob":case"arraybuffer":k="uint8array";break;case"base64":k="string"}try{this._internalType=k,this._outputType=f,this._mimeType=v,s.checkSupport(k),this._worker=b.pipe(new l(k)),b.lock()}catch(S){this._worker=new r("error"),this._worker.error(S)}}d.prototype={accumulate:function(b){return g(this,b)},on:function(b,f){var v=this;return b==="data"?this._worker.on(b,function(k){f.call(v,k.data,k.meta)}):this._worker.on(b,function(){s.delay(f,arguments,v)}),this},resume:function(){return s.delay(this._worker.resume,[],this._worker),this},pause:function(){return this._worker.pause(),this},toNodejsStream:function(b){if(s.checkSupport("nodestream"),this._outputType!=="nodebuffer")throw new Error(this._outputType+" is not supported by this method");return new m(this,{objectMode:this._outputType!=="nodebuffer"},b)}},n.exports=d},{"../base64":1,"../external":6,"../nodejs/NodejsStreamOutputAdapter":13,"../support":30,"../utils":32,"./ConvertWorker":24,"./GenericWorker":28}],30:[function(e,n,o){if(o.base64=!0,o.array=!0,o.string=!0,o.arraybuffer=typeof ArrayBuffer<"u"&&typeof Uint8Array<"u",o.nodebuffer=typeof Buffer<"u",o.uint8array=typeof Uint8Array<"u",typeof ArrayBuffer>"u")o.blob=!1;else{var s=new ArrayBuffer(0);try{o.blob=new Blob([s],{type:"application/zip"}).size===0}catch{try{var l=new(self.BlobBuilder||self.WebKitBlobBuilder||self.MozBlobBuilder||self.MSBlobBuilder);l.append(s),o.blob=l.getBlob("application/zip").size===0}catch{o.blob=!1}}}try{o.nodestream=!!e("readable-stream").Readable}catch{o.nodestream=!1}},{"readable-stream":16}],31:[function(e,n,o){for(var s=e("./utils"),l=e("./support"),r=e("./nodejsUtils"),a=e("./stream/GenericWorker"),c=new Array(256),u=0;u<256;u++)c[u]=252<=u?6:248<=u?5:240<=u?4:224<=u?3:192<=u?2:1;c[254]=c[254]=1;function m(){a.call(this,"utf-8 decode"),this.leftOver=null}function g(){a.call(this,"utf-8 encode")}o.utf8encode=function(d){return l.nodebuffer?r.newBufferFrom(d,"utf-8"):(function(b){var f,v,k,S,x,A=b.length,T=0;for(S=0;S<A;S++)(64512&(v=b.charCodeAt(S)))==55296&&S+1<A&&(64512&(k=b.charCodeAt(S+1)))==56320&&(v=65536+(v-55296<<10)+(k-56320),S++),T+=v<128?1:v<2048?2:v<65536?3:4;for(f=l.uint8array?new Uint8Array(T):new Array(T),S=x=0;x<T;S++)(64512&(v=b.charCodeAt(S)))==55296&&S+1<A&&(64512&(k=b.charCodeAt(S+1)))==56320&&(v=65536+(v-55296<<10)+(k-56320),S++),v<128?f[x++]=v:(v<2048?f[x++]=192|v>>>6:(v<65536?f[x++]=224|v>>>12:(f[x++]=240|v>>>18,f[x++]=128|v>>>12&63),f[x++]=128|v>>>6&63),f[x++]=128|63&v);return f})(d)},o.utf8decode=function(d){return l.nodebuffer?s.transformTo("nodebuffer",d).toString("utf-8"):(function(b){var f,v,k,S,x=b.length,A=new Array(2*x);for(f=v=0;f<x;)if((k=b[f++])<128)A[v++]=k;else if(4<(S=c[k]))A[v++]=65533,f+=S-1;else{for(k&=S===2?31:S===3?15:7;1<S&&f<x;)k=k<<6|63&b[f++],S--;1<S?A[v++]=65533:k<65536?A[v++]=k:(k-=65536,A[v++]=55296|k>>10&1023,A[v++]=56320|1023&k)}return A.length!==v&&(A.subarray?A=A.subarray(0,v):A.length=v),s.applyFromCharCode(A)})(d=s.transformTo(l.uint8array?"uint8array":"array",d))},s.inherits(m,a),m.prototype.processChunk=function(d){var b=s.transformTo(l.uint8array?"uint8array":"array",d.data);if(this.leftOver&&this.leftOver.length){if(l.uint8array){var f=b;(b=new Uint8Array(f.length+this.leftOver.length)).set(this.leftOver,0),b.set(f,this.leftOver.length)}else b=this.leftOver.concat(b);this.leftOver=null}var v=(function(S,x){var A;for((x=x||S.length)>S.length&&(x=S.length),A=x-1;0<=A&&(192&S[A])==128;)A--;return A<0||A===0?x:A+c[S[A]]>x?A:x})(b),k=b;v!==b.length&&(l.uint8array?(k=b.subarray(0,v),this.leftOver=b.subarray(v,b.length)):(k=b.slice(0,v),this.leftOver=b.slice(v,b.length))),this.push({data:o.utf8decode(k),meta:d.meta})},m.prototype.flush=function(){this.leftOver&&this.leftOver.length&&(this.push({data:o.utf8decode(this.leftOver),meta:{}}),this.leftOver=null)},o.Utf8DecodeWorker=m,s.inherits(g,a),g.prototype.processChunk=function(d){this.push({data:o.utf8encode(d.data),meta:d.meta})},o.Utf8EncodeWorker=g},{"./nodejsUtils":14,"./stream/GenericWorker":28,"./support":30,"./utils":32}],32:[function(e,n,o){var s=e("./support"),l=e("./base64"),r=e("./nodejsUtils"),a=e("./external");function c(f){return f}function u(f,v){for(var k=0;k<f.length;++k)v[k]=255&f.charCodeAt(k);return v}e("setimmediate"),o.newBlob=function(f,v){o.checkSupport("blob");try{return new Blob([f],{type:v})}catch{try{var k=new(self.BlobBuilder||self.WebKitBlobBuilder||self.MozBlobBuilder||self.MSBlobBuilder);return k.append(f),k.getBlob(v)}catch{throw new Error("Bug : can't construct the Blob.")}}};var m={stringifyByChunk:function(f,v,k){var S=[],x=0,A=f.length;if(A<=k)return String.fromCharCode.apply(null,f);for(;x<A;)v==="array"||v==="nodebuffer"?S.push(String.fromCharCode.apply(null,f.slice(x,Math.min(x+k,A)))):S.push(String.fromCharCode.apply(null,f.subarray(x,Math.min(x+k,A)))),x+=k;return S.join("")},stringifyByChar:function(f){for(var v="",k=0;k<f.length;k++)v+=String.fromCharCode(f[k]);return v},applyCanBeUsed:{uint8array:(function(){try{return s.uint8array&&String.fromCharCode.apply(null,new Uint8Array(1)).length===1}catch{return!1}})(),nodebuffer:(function(){try{return s.nodebuffer&&String.fromCharCode.apply(null,r.allocBuffer(1)).length===1}catch{return!1}})()}};function g(f){var v=65536,k=o.getTypeOf(f),S=!0;if(k==="uint8array"?S=m.applyCanBeUsed.uint8array:k==="nodebuffer"&&(S=m.applyCanBeUsed.nodebuffer),S)for(;1<v;)try{return m.stringifyByChunk(f,k,v)}catch{v=Math.floor(v/2)}return m.stringifyByChar(f)}function d(f,v){for(var k=0;k<f.length;k++)v[k]=f[k];return v}o.applyFromCharCode=g;var b={};b.string={string:c,array:function(f){return u(f,new Array(f.length))},arraybuffer:function(f){return b.string.uint8array(f).buffer},uint8array:function(f){return u(f,new Uint8Array(f.length))},nodebuffer:function(f){return u(f,r.allocBuffer(f.length))}},b.array={string:g,array:c,arraybuffer:function(f){return new Uint8Array(f).buffer},uint8array:function(f){return new Uint8Array(f)},nodebuffer:function(f){return r.newBufferFrom(f)}},b.arraybuffer={string:function(f){return g(new Uint8Array(f))},array:function(f){return d(new Uint8Array(f),new Array(f.byteLength))},arraybuffer:c,uint8array:function(f){return new Uint8Array(f)},nodebuffer:function(f){return r.newBufferFrom(new Uint8Array(f))}},b.uint8array={string:g,array:function(f){return d(f,new Array(f.length))},arraybuffer:function(f){return f.buffer},uint8array:c,nodebuffer:function(f){return r.newBufferFrom(f)}},b.nodebuffer={string:g,array:function(f){return d(f,new Array(f.length))},arraybuffer:function(f){return b.nodebuffer.uint8array(f).buffer},uint8array:function(f){return d(f,new Uint8Array(f.length))},nodebuffer:c},o.transformTo=function(f,v){if(v=v||"",!f)return v;o.checkSupport(f);var k=o.getTypeOf(v);return b[k][f](v)},o.resolve=function(f){for(var v=f.split("/"),k=[],S=0;S<v.length;S++){var x=v[S];x==="."||x===""&&S!==0&&S!==v.length-1||(x===".."?k.pop():k.push(x))}return k.join("/")},o.getTypeOf=function(f){return typeof f=="string"?"string":Object.prototype.toString.call(f)==="[object Array]"?"array":s.nodebuffer&&r.isBuffer(f)?"nodebuffer":s.uint8array&&f instanceof Uint8Array?"uint8array":s.arraybuffer&&f instanceof ArrayBuffer?"arraybuffer":void 0},o.checkSupport=function(f){if(!s[f.toLowerCase()])throw new Error(f+" is not supported by this platform")},o.MAX_VALUE_16BITS=65535,o.MAX_VALUE_32BITS=-1,o.pretty=function(f){var v,k,S="";for(k=0;k<(f||"").length;k++)S+="\\x"+((v=f.charCodeAt(k))<16?"0":"")+v.toString(16).toUpperCase();return S},o.delay=function(f,v,k){setImmediate(function(){f.apply(k||null,v||[])})},o.inherits=function(f,v){function k(){}k.prototype=v.prototype,f.prototype=new k},o.extend=function(){var f,v,k={};for(f=0;f<arguments.length;f++)for(v in arguments[f])Object.prototype.hasOwnProperty.call(arguments[f],v)&&k[v]===void 0&&(k[v]=arguments[f][v]);return k},o.prepareContent=function(f,v,k,S,x){return a.Promise.resolve(v).then(function(A){return s.blob&&(A instanceof Blob||["[object File]","[object Blob]"].indexOf(Object.prototype.toString.call(A))!==-1)&&typeof FileReader<"u"?new a.Promise(function(T,I){var w=new FileReader;w.onload=function(N){T(N.target.result)},w.onerror=function(N){I(N.target.error)},w.readAsArrayBuffer(A)}):A}).then(function(A){var T=o.getTypeOf(A);return T?(T==="arraybuffer"?A=o.transformTo("uint8array",A):T==="string"&&(x?A=l.decode(A):k&&S!==!0&&(A=(function(I){return u(I,s.uint8array?new Uint8Array(I.length):new Array(I.length))})(A))),A):a.Promise.reject(new Error("Can't read the data of '"+f+"'. Is it in a supported JavaScript type (String, Blob, ArrayBuffer, etc) ?"))})}},{"./base64":1,"./external":6,"./nodejsUtils":14,"./support":30,setimmediate:54}],33:[function(e,n,o){var s=e("./reader/readerFor"),l=e("./utils"),r=e("./signature"),a=e("./zipEntry"),c=e("./support");function u(m){this.files=[],this.loadOptions=m}u.prototype={checkSignature:function(m){if(!this.reader.readAndCheckSignature(m)){this.reader.index-=4;var g=this.reader.readString(4);throw new Error("Corrupted zip or bug: unexpected signature ("+l.pretty(g)+", expected "+l.pretty(m)+")")}},isSignature:function(m,g){var d=this.reader.index;this.reader.setIndex(m);var b=this.reader.readString(4)===g;return this.reader.setIndex(d),b},readBlockEndOfCentral:function(){this.diskNumber=this.reader.readInt(2),this.diskWithCentralDirStart=this.reader.readInt(2),this.centralDirRecordsOnThisDisk=this.reader.readInt(2),this.centralDirRecords=this.reader.readInt(2),this.centralDirSize=this.reader.readInt(4),this.centralDirOffset=this.reader.readInt(4),this.zipCommentLength=this.reader.readInt(2);var m=this.reader.readData(this.zipCommentLength),g=c.uint8array?"uint8array":"array",d=l.transformTo(g,m);this.zipComment=this.loadOptions.decodeFileName(d)},readBlockZip64EndOfCentral:function(){this.zip64EndOfCentralSize=this.reader.readInt(8),this.reader.skip(4),this.diskNumber=this.reader.readInt(4),this.diskWithCentralDirStart=this.reader.readInt(4),this.centralDirRecordsOnThisDisk=this.reader.readInt(8),this.centralDirRecords=this.reader.readInt(8),this.centralDirSize=this.reader.readInt(8),this.centralDirOffset=this.reader.readInt(8),this.zip64ExtensibleData={};for(var m,g,d,b=this.zip64EndOfCentralSize-44;0<b;)m=this.reader.readInt(2),g=this.reader.readInt(4),d=this.reader.readData(g),this.zip64ExtensibleData[m]={id:m,length:g,value:d}},readBlockZip64EndOfCentralLocator:function(){if(this.diskWithZip64CentralDirStart=this.reader.readInt(4),this.relativeOffsetEndOfZip64CentralDir=this.reader.readInt(8),this.disksCount=this.reader.readInt(4),1<this.disksCount)throw new Error("Multi-volumes zip are not supported")},readLocalFiles:function(){var m,g;for(m=0;m<this.files.length;m++)g=this.files[m],this.reader.setIndex(g.localHeaderOffset),this.checkSignature(r.LOCAL_FILE_HEADER),g.readLocalPart(this.reader),g.handleUTF8(),g.processAttributes()},readCentralDir:function(){var m;for(this.reader.setIndex(this.centralDirOffset);this.reader.readAndCheckSignature(r.CENTRAL_FILE_HEADER);)(m=new a({zip64:this.zip64},this.loadOptions)).readCentralPart(this.reader),this.files.push(m);if(this.centralDirRecords!==this.files.length&&this.centralDirRecords!==0&&this.files.length===0)throw new Error("Corrupted zip or bug: expected "+this.centralDirRecords+" records in central dir, got "+this.files.length)},readEndOfCentral:function(){var m=this.reader.lastIndexOfSignature(r.CENTRAL_DIRECTORY_END);if(m<0)throw this.isSignature(0,r.LOCAL_FILE_HEADER)?new Error("Corrupted zip: can't find end of central directory"):new Error("Can't find end of central directory : is this a zip file ? If it is, see https://stuk.github.io/jszip/documentation/howto/read_zip.html");this.reader.setIndex(m);var g=m;if(this.checkSignature(r.CENTRAL_DIRECTORY_END),this.readBlockEndOfCentral(),this.diskNumber===l.MAX_VALUE_16BITS||this.diskWithCentralDirStart===l.MAX_VALUE_16BITS||this.centralDirRecordsOnThisDisk===l.MAX_VALUE_16BITS||this.centralDirRecords===l.MAX_VALUE_16BITS||this.centralDirSize===l.MAX_VALUE_32BITS||this.centralDirOffset===l.MAX_VALUE_32BITS){if(this.zip64=!0,(m=this.reader.lastIndexOfSignature(r.ZIP64_CENTRAL_DIRECTORY_LOCATOR))<0)throw new Error("Corrupted zip: can't find the ZIP64 end of central directory locator");if(this.reader.setIndex(m),this.checkSignature(r.ZIP64_CENTRAL_DIRECTORY_LOCATOR),this.readBlockZip64EndOfCentralLocator(),!this.isSignature(this.relativeOffsetEndOfZip64CentralDir,r.ZIP64_CENTRAL_DIRECTORY_END)&&(this.relativeOffsetEndOfZip64CentralDir=this.reader.lastIndexOfSignature(r.ZIP64_CENTRAL_DIRECTORY_END),this.relativeOffsetEndOfZip64CentralDir<0))throw new Error("Corrupted zip: can't find the ZIP64 end of central directory");this.reader.setIndex(this.relativeOffsetEndOfZip64CentralDir),this.checkSignature(r.ZIP64_CENTRAL_DIRECTORY_END),this.readBlockZip64EndOfCentral()}var d=this.centralDirOffset+this.centralDirSize;this.zip64&&(d+=20,d+=12+this.zip64EndOfCentralSize);var b=g-d;if(0<b)this.isSignature(g,r.CENTRAL_FILE_HEADER)||(this.reader.zero=b);else if(b<0)throw new Error("Corrupted zip: missing "+Math.abs(b)+" bytes.")},prepareReader:function(m){this.reader=s(m)},load:function(m){this.prepareReader(m),this.readEndOfCentral(),this.readCentralDir(),this.readLocalFiles()}},n.exports=u},{"./reader/readerFor":22,"./signature":23,"./support":30,"./utils":32,"./zipEntry":34}],34:[function(e,n,o){var s=e("./reader/readerFor"),l=e("./utils"),r=e("./compressedObject"),a=e("./crc32"),c=e("./utf8"),u=e("./compressions"),m=e("./support");function g(d,b){this.options=d,this.loadOptions=b}g.prototype={isEncrypted:function(){return(1&this.bitFlag)==1},useUTF8:function(){return(2048&this.bitFlag)==2048},readLocalPart:function(d){var b,f;if(d.skip(22),this.fileNameLength=d.readInt(2),f=d.readInt(2),this.fileName=d.readData(this.fileNameLength),d.skip(f),this.compressedSize===-1||this.uncompressedSize===-1)throw new Error("Bug or corrupted zip : didn't get enough information from the central directory (compressedSize === -1 || uncompressedSize === -1)");if((b=(function(v){for(var k in u)if(Object.prototype.hasOwnProperty.call(u,k)&&u[k].magic===v)return u[k];return null})(this.compressionMethod))===null)throw new Error("Corrupted zip : compression "+l.pretty(this.compressionMethod)+" unknown (inner file : "+l.transformTo("string",this.fileName)+")");this.decompressed=new r(this.compressedSize,this.uncompressedSize,this.crc32,b,d.readData(this.compressedSize))},readCentralPart:function(d){this.versionMadeBy=d.readInt(2),d.skip(2),this.bitFlag=d.readInt(2),this.compressionMethod=d.readString(2),this.date=d.readDate(),this.crc32=d.readInt(4),this.compressedSize=d.readInt(4),this.uncompressedSize=d.readInt(4);var b=d.readInt(2);if(this.extraFieldsLength=d.readInt(2),this.fileCommentLength=d.readInt(2),this.diskNumberStart=d.readInt(2),this.internalFileAttributes=d.readInt(2),this.externalFileAttributes=d.readInt(4),this.localHeaderOffset=d.readInt(4),this.isEncrypted())throw new Error("Encrypted zip are not supported");d.skip(b),this.readExtraFields(d),this.parseZIP64ExtraField(d),this.fileComment=d.readData(this.fileCommentLength)},processAttributes:function(){this.unixPermissions=null,this.dosPermissions=null;var d=this.versionMadeBy>>8;this.dir=!!(16&this.externalFileAttributes),d==0&&(this.dosPermissions=63&this.externalFileAttributes),d==3&&(this.unixPermissions=this.externalFileAttributes>>16&65535),this.dir||this.fileNameStr.slice(-1)!=="/"||(this.dir=!0)},parseZIP64ExtraField:function(){if(this.extraFields[1]){var d=s(this.extraFields[1].value);this.uncompressedSize===l.MAX_VALUE_32BITS&&(this.uncompressedSize=d.readInt(8)),this.compressedSize===l.MAX_VALUE_32BITS&&(this.compressedSize=d.readInt(8)),this.localHeaderOffset===l.MAX_VALUE_32BITS&&(this.localHeaderOffset=d.readInt(8)),this.diskNumberStart===l.MAX_VALUE_32BITS&&(this.diskNumberStart=d.readInt(4))}},readExtraFields:function(d){var b,f,v,k=d.index+this.extraFieldsLength;for(this.extraFields||(this.extraFields={});d.index+4<k;)b=d.readInt(2),f=d.readInt(2),v=d.readData(f),this.extraFields[b]={id:b,length:f,value:v};d.setIndex(k)},handleUTF8:function(){var d=m.uint8array?"uint8array":"array";if(this.useUTF8())this.fileNameStr=c.utf8decode(this.fileName),this.fileCommentStr=c.utf8decode(this.fileComment);else{var b=this.findExtraFieldUnicodePath();if(b!==null)this.fileNameStr=b;else{var f=l.transformTo(d,this.fileName);this.fileNameStr=this.loadOptions.decodeFileName(f)}var v=this.findExtraFieldUnicodeComment();if(v!==null)this.fileCommentStr=v;else{var k=l.transformTo(d,this.fileComment);this.fileCommentStr=this.loadOptions.decodeFileName(k)}}},findExtraFieldUnicodePath:function(){var d=this.extraFields[28789];if(d){var b=s(d.value);return b.readInt(1)!==1||a(this.fileName)!==b.readInt(4)?null:c.utf8decode(b.readData(d.length-5))}return null},findExtraFieldUnicodeComment:function(){var d=this.extraFields[25461];if(d){var b=s(d.value);return b.readInt(1)!==1||a(this.fileComment)!==b.readInt(4)?null:c.utf8decode(b.readData(d.length-5))}return null}},n.exports=g},{"./compressedObject":2,"./compressions":3,"./crc32":4,"./reader/readerFor":22,"./support":30,"./utf8":31,"./utils":32}],35:[function(e,n,o){function s(b,f,v){this.name=b,this.dir=v.dir,this.date=v.date,this.comment=v.comment,this.unixPermissions=v.unixPermissions,this.dosPermissions=v.dosPermissions,this._data=f,this._dataBinary=v.binary,this.options={compression:v.compression,compressionOptions:v.compressionOptions}}var l=e("./stream/StreamHelper"),r=e("./stream/DataWorker"),a=e("./utf8"),c=e("./compressedObject"),u=e("./stream/GenericWorker");s.prototype={internalStream:function(b){var f=null,v="string";try{if(!b)throw new Error("No output type specified.");var k=(v=b.toLowerCase())==="string"||v==="text";v!=="binarystring"&&v!=="text"||(v="string"),f=this._decompressWorker();var S=!this._dataBinary;S&&!k&&(f=f.pipe(new a.Utf8EncodeWorker)),!S&&k&&(f=f.pipe(new a.Utf8DecodeWorker))}catch(x){(f=new u("error")).error(x)}return new l(f,v,"")},async:function(b,f){return this.internalStream(b).accumulate(f)},nodeStream:function(b,f){return this.internalStream(b||"nodebuffer").toNodejsStream(f)},_compressWorker:function(b,f){if(this._data instanceof c&&this._data.compression.magic===b.magic)return this._data.getCompressedWorker();var v=this._decompressWorker();return this._dataBinary||(v=v.pipe(new a.Utf8EncodeWorker)),c.createWorkerFrom(v,b,f)},_decompressWorker:function(){return this._data instanceof c?this._data.getContentWorker():this._data instanceof u?this._data:new r(this._data)}};for(var m=["asText","asBinary","asNodeBuffer","asUint8Array","asArrayBuffer"],g=function(){throw new Error("This method has been removed in JSZip 3.0, please check the upgrade guide.")},d=0;d<m.length;d++)s.prototype[m[d]]=g;n.exports=s},{"./compressedObject":2,"./stream/DataWorker":27,"./stream/GenericWorker":28,"./stream/StreamHelper":29,"./utf8":31}],36:[function(e,n,o){(function(s){var l,r,a=s.MutationObserver||s.WebKitMutationObserver;if(a){var c=0,u=new a(b),m=s.document.createTextNode("");u.observe(m,{characterData:!0}),l=function(){m.data=c=++c%2}}else if(s.setImmediate||s.MessageChannel===void 0)l="document"in s&&"onreadystatechange"in s.document.createElement("script")?function(){var f=s.document.createElement("script");f.onreadystatechange=function(){b(),f.onreadystatechange=null,f.parentNode.removeChild(f),f=null},s.document.documentElement.appendChild(f)}:function(){setTimeout(b,0)};else{var g=new s.MessageChannel;g.port1.onmessage=b,l=function(){g.port2.postMessage(0)}}var d=[];function b(){var f,v;r=!0;for(var k=d.length;k;){for(v=d,d=[],f=-1;++f<k;)v[f]();k=d.length}r=!1}n.exports=function(f){d.push(f)!==1||r||l()}}).call(this,typeof Zn<"u"?Zn:typeof self<"u"?self:typeof window<"u"?window:{})},{}],37:[function(e,n,o){var s=e("immediate");function l(){}var r={},a=["REJECTED"],c=["FULFILLED"],u=["PENDING"];function m(k){if(typeof k!="function")throw new TypeError("resolver must be a function");this.state=u,this.queue=[],this.outcome=void 0,k!==l&&f(this,k)}function g(k,S,x){this.promise=k,typeof S=="function"&&(this.onFulfilled=S,this.callFulfilled=this.otherCallFulfilled),typeof x=="function"&&(this.onRejected=x,this.callRejected=this.otherCallRejected)}function d(k,S,x){s(function(){var A;try{A=S(x)}catch(T){return r.reject(k,T)}A===k?r.reject(k,new TypeError("Cannot resolve promise with itself")):r.resolve(k,A)})}function b(k){var S=k&&k.then;if(k&&(typeof k=="object"||typeof k=="function")&&typeof S=="function")return function(){S.apply(k,arguments)}}function f(k,S){var x=!1;function A(w){x||(x=!0,r.reject(k,w))}function T(w){x||(x=!0,r.resolve(k,w))}var I=v(function(){S(T,A)});I.status==="error"&&A(I.value)}function v(k,S){var x={};try{x.value=k(S),x.status="success"}catch(A){x.status="error",x.value=A}return x}(n.exports=m).prototype.finally=function(k){if(typeof k!="function")return this;var S=this.constructor;return this.then(function(x){return S.resolve(k()).then(function(){return x})},function(x){return S.resolve(k()).then(function(){throw x})})},m.prototype.catch=function(k){return this.then(null,k)},m.prototype.then=function(k,S){if(typeof k!="function"&&this.state===c||typeof S!="function"&&this.state===a)return this;var x=new this.constructor(l);return this.state!==u?d(x,this.state===c?k:S,this.outcome):this.queue.push(new g(x,k,S)),x},g.prototype.callFulfilled=function(k){r.resolve(this.promise,k)},g.prototype.otherCallFulfilled=function(k){d(this.promise,this.onFulfilled,k)},g.prototype.callRejected=function(k){r.reject(this.promise,k)},g.prototype.otherCallRejected=function(k){d(this.promise,this.onRejected,k)},r.resolve=function(k,S){var x=v(b,S);if(x.status==="error")return r.reject(k,x.value);var A=x.value;if(A)f(k,A);else{k.state=c,k.outcome=S;for(var T=-1,I=k.queue.length;++T<I;)k.queue[T].callFulfilled(S)}return k},r.reject=function(k,S){k.state=a,k.outcome=S;for(var x=-1,A=k.queue.length;++x<A;)k.queue[x].callRejected(S);return k},m.resolve=function(k){return k instanceof this?k:r.resolve(new this(l),k)},m.reject=function(k){var S=new this(l);return r.reject(S,k)},m.all=function(k){var S=this;if(Object.prototype.toString.call(k)!=="[object Array]")return this.reject(new TypeError("must be an array"));var x=k.length,A=!1;if(!x)return this.resolve([]);for(var T=new Array(x),I=0,w=-1,N=new this(l);++w<x;)F(k[w],w);return N;function F(j,J){S.resolve(j).then(function($){T[J]=$,++I!==x||A||(A=!0,r.resolve(N,T))},function($){A||(A=!0,r.reject(N,$))})}},m.race=function(k){var S=this;if(Object.prototype.toString.call(k)!=="[object Array]")return this.reject(new TypeError("must be an array"));var x=k.length,A=!1;if(!x)return this.resolve([]);for(var T=-1,I=new this(l);++T<x;)w=k[T],S.resolve(w).then(function(N){A||(A=!0,r.resolve(I,N))},function(N){A||(A=!0,r.reject(I,N))});var w;return I}},{immediate:36}],38:[function(e,n,o){var s={};(0,e("./lib/utils/common").assign)(s,e("./lib/deflate"),e("./lib/inflate"),e("./lib/zlib/constants")),n.exports=s},{"./lib/deflate":39,"./lib/inflate":40,"./lib/utils/common":41,"./lib/zlib/constants":44}],39:[function(e,n,o){var s=e("./zlib/deflate"),l=e("./utils/common"),r=e("./utils/strings"),a=e("./zlib/messages"),c=e("./zlib/zstream"),u=Object.prototype.toString,m=0,g=-1,d=0,b=8;function f(k){if(!(this instanceof f))return new f(k);this.options=l.assign({level:g,method:b,chunkSize:16384,windowBits:15,memLevel:8,strategy:d,to:""},k||{});var S=this.options;S.raw&&0<S.windowBits?S.windowBits=-S.windowBits:S.gzip&&0<S.windowBits&&S.windowBits<16&&(S.windowBits+=16),this.err=0,this.msg="",this.ended=!1,this.chunks=[],this.strm=new c,this.strm.avail_out=0;var x=s.deflateInit2(this.strm,S.level,S.method,S.windowBits,S.memLevel,S.strategy);if(x!==m)throw new Error(a[x]);if(S.header&&s.deflateSetHeader(this.strm,S.header),S.dictionary){var A;if(A=typeof S.dictionary=="string"?r.string2buf(S.dictionary):u.call(S.dictionary)==="[object ArrayBuffer]"?new Uint8Array(S.dictionary):S.dictionary,(x=s.deflateSetDictionary(this.strm,A))!==m)throw new Error(a[x]);this._dict_set=!0}}function v(k,S){var x=new f(S);if(x.push(k,!0),x.err)throw x.msg||a[x.err];return x.result}f.prototype.push=function(k,S){var x,A,T=this.strm,I=this.options.chunkSize;if(this.ended)return!1;A=S===~~S?S:S===!0?4:0,typeof k=="string"?T.input=r.string2buf(k):u.call(k)==="[object ArrayBuffer]"?T.input=new Uint8Array(k):T.input=k,T.next_in=0,T.avail_in=T.input.length;do{if(T.avail_out===0&&(T.output=new l.Buf8(I),T.next_out=0,T.avail_out=I),(x=s.deflate(T,A))!==1&&x!==m)return this.onEnd(x),!(this.ended=!0);T.avail_out!==0&&(T.avail_in!==0||A!==4&&A!==2)||(this.options.to==="string"?this.onData(r.buf2binstring(l.shrinkBuf(T.output,T.next_out))):this.onData(l.shrinkBuf(T.output,T.next_out)))}while((0<T.avail_in||T.avail_out===0)&&x!==1);return A===4?(x=s.deflateEnd(this.strm),this.onEnd(x),this.ended=!0,x===m):A!==2||(this.onEnd(m),!(T.avail_out=0))},f.prototype.onData=function(k){this.chunks.push(k)},f.prototype.onEnd=function(k){k===m&&(this.options.to==="string"?this.result=this.chunks.join(""):this.result=l.flattenChunks(this.chunks)),this.chunks=[],this.err=k,this.msg=this.strm.msg},o.Deflate=f,o.deflate=v,o.deflateRaw=function(k,S){return(S=S||{}).raw=!0,v(k,S)},o.gzip=function(k,S){return(S=S||{}).gzip=!0,v(k,S)}},{"./utils/common":41,"./utils/strings":42,"./zlib/deflate":46,"./zlib/messages":51,"./zlib/zstream":53}],40:[function(e,n,o){var s=e("./zlib/inflate"),l=e("./utils/common"),r=e("./utils/strings"),a=e("./zlib/constants"),c=e("./zlib/messages"),u=e("./zlib/zstream"),m=e("./zlib/gzheader"),g=Object.prototype.toString;function d(f){if(!(this instanceof d))return new d(f);this.options=l.assign({chunkSize:16384,windowBits:0,to:""},f||{});var v=this.options;v.raw&&0<=v.windowBits&&v.windowBits<16&&(v.windowBits=-v.windowBits,v.windowBits===0&&(v.windowBits=-15)),!(0<=v.windowBits&&v.windowBits<16)||f&&f.windowBits||(v.windowBits+=32),15<v.windowBits&&v.windowBits<48&&(15&v.windowBits)==0&&(v.windowBits|=15),this.err=0,this.msg="",this.ended=!1,this.chunks=[],this.strm=new u,this.strm.avail_out=0;var k=s.inflateInit2(this.strm,v.windowBits);if(k!==a.Z_OK)throw new Error(c[k]);this.header=new m,s.inflateGetHeader(this.strm,this.header)}function b(f,v){var k=new d(v);if(k.push(f,!0),k.err)throw k.msg||c[k.err];return k.result}d.prototype.push=function(f,v){var k,S,x,A,T,I,w=this.strm,N=this.options.chunkSize,F=this.options.dictionary,j=!1;if(this.ended)return!1;S=v===~~v?v:v===!0?a.Z_FINISH:a.Z_NO_FLUSH,typeof f=="string"?w.input=r.binstring2buf(f):g.call(f)==="[object ArrayBuffer]"?w.input=new Uint8Array(f):w.input=f,w.next_in=0,w.avail_in=w.input.length;do{if(w.avail_out===0&&(w.output=new l.Buf8(N),w.next_out=0,w.avail_out=N),(k=s.inflate(w,a.Z_NO_FLUSH))===a.Z_NEED_DICT&&F&&(I=typeof F=="string"?r.string2buf(F):g.call(F)==="[object ArrayBuffer]"?new Uint8Array(F):F,k=s.inflateSetDictionary(this.strm,I)),k===a.Z_BUF_ERROR&&j===!0&&(k=a.Z_OK,j=!1),k!==a.Z_STREAM_END&&k!==a.Z_OK)return this.onEnd(k),!(this.ended=!0);w.next_out&&(w.avail_out!==0&&k!==a.Z_STREAM_END&&(w.avail_in!==0||S!==a.Z_FINISH&&S!==a.Z_SYNC_FLUSH)||(this.options.to==="string"?(x=r.utf8border(w.output,w.next_out),A=w.next_out-x,T=r.buf2string(w.output,x),w.next_out=A,w.avail_out=N-A,A&&l.arraySet(w.output,w.output,x,A,0),this.onData(T)):this.onData(l.shrinkBuf(w.output,w.next_out)))),w.avail_in===0&&w.avail_out===0&&(j=!0)}while((0<w.avail_in||w.avail_out===0)&&k!==a.Z_STREAM_END);return k===a.Z_STREAM_END&&(S=a.Z_FINISH),S===a.Z_FINISH?(k=s.inflateEnd(this.strm),this.onEnd(k),this.ended=!0,k===a.Z_OK):S!==a.Z_SYNC_FLUSH||(this.onEnd(a.Z_OK),!(w.avail_out=0))},d.prototype.onData=function(f){this.chunks.push(f)},d.prototype.onEnd=function(f){f===a.Z_OK&&(this.options.to==="string"?this.result=this.chunks.join(""):this.result=l.flattenChunks(this.chunks)),this.chunks=[],this.err=f,this.msg=this.strm.msg},o.Inflate=d,o.inflate=b,o.inflateRaw=function(f,v){return(v=v||{}).raw=!0,b(f,v)},o.ungzip=b},{"./utils/common":41,"./utils/strings":42,"./zlib/constants":44,"./zlib/gzheader":47,"./zlib/inflate":49,"./zlib/messages":51,"./zlib/zstream":53}],41:[function(e,n,o){var s=typeof Uint8Array<"u"&&typeof Uint16Array<"u"&&typeof Int32Array<"u";o.assign=function(a){for(var c=Array.prototype.slice.call(arguments,1);c.length;){var u=c.shift();if(u){if(typeof u!="object")throw new TypeError(u+"must be non-object");for(var m in u)u.hasOwnProperty(m)&&(a[m]=u[m])}}return a},o.shrinkBuf=function(a,c){return a.length===c?a:a.subarray?a.subarray(0,c):(a.length=c,a)};var l={arraySet:function(a,c,u,m,g){if(c.subarray&&a.subarray)a.set(c.subarray(u,u+m),g);else for(var d=0;d<m;d++)a[g+d]=c[u+d]},flattenChunks:function(a){var c,u,m,g,d,b;for(c=m=0,u=a.length;c<u;c++)m+=a[c].length;for(b=new Uint8Array(m),c=g=0,u=a.length;c<u;c++)d=a[c],b.set(d,g),g+=d.length;return b}},r={arraySet:function(a,c,u,m,g){for(var d=0;d<m;d++)a[g+d]=c[u+d]},flattenChunks:function(a){return[].concat.apply([],a)}};o.setTyped=function(a){a?(o.Buf8=Uint8Array,o.Buf16=Uint16Array,o.Buf32=Int32Array,o.assign(o,l)):(o.Buf8=Array,o.Buf16=Array,o.Buf32=Array,o.assign(o,r))},o.setTyped(s)},{}],42:[function(e,n,o){var s=e("./common"),l=!0,r=!0;try{String.fromCharCode.apply(null,[0])}catch{l=!1}try{String.fromCharCode.apply(null,new Uint8Array(1))}catch{r=!1}for(var a=new s.Buf8(256),c=0;c<256;c++)a[c]=252<=c?6:248<=c?5:240<=c?4:224<=c?3:192<=c?2:1;function u(m,g){if(g<65537&&(m.subarray&&r||!m.subarray&&l))return String.fromCharCode.apply(null,s.shrinkBuf(m,g));for(var d="",b=0;b<g;b++)d+=String.fromCharCode(m[b]);return d}a[254]=a[254]=1,o.string2buf=function(m){var g,d,b,f,v,k=m.length,S=0;for(f=0;f<k;f++)(64512&(d=m.charCodeAt(f)))==55296&&f+1<k&&(64512&(b=m.charCodeAt(f+1)))==56320&&(d=65536+(d-55296<<10)+(b-56320),f++),S+=d<128?1:d<2048?2:d<65536?3:4;for(g=new s.Buf8(S),f=v=0;v<S;f++)(64512&(d=m.charCodeAt(f)))==55296&&f+1<k&&(64512&(b=m.charCodeAt(f+1)))==56320&&(d=65536+(d-55296<<10)+(b-56320),f++),d<128?g[v++]=d:(d<2048?g[v++]=192|d>>>6:(d<65536?g[v++]=224|d>>>12:(g[v++]=240|d>>>18,g[v++]=128|d>>>12&63),g[v++]=128|d>>>6&63),g[v++]=128|63&d);return g},o.buf2binstring=function(m){return u(m,m.length)},o.binstring2buf=function(m){for(var g=new s.Buf8(m.length),d=0,b=g.length;d<b;d++)g[d]=m.charCodeAt(d);return g},o.buf2string=function(m,g){var d,b,f,v,k=g||m.length,S=new Array(2*k);for(d=b=0;d<k;)if((f=m[d++])<128)S[b++]=f;else if(4<(v=a[f]))S[b++]=65533,d+=v-1;else{for(f&=v===2?31:v===3?15:7;1<v&&d<k;)f=f<<6|63&m[d++],v--;1<v?S[b++]=65533:f<65536?S[b++]=f:(f-=65536,S[b++]=55296|f>>10&1023,S[b++]=56320|1023&f)}return u(S,b)},o.utf8border=function(m,g){var d;for((g=g||m.length)>m.length&&(g=m.length),d=g-1;0<=d&&(192&m[d])==128;)d--;return d<0||d===0?g:d+a[m[d]]>g?d:g}},{"./common":41}],43:[function(e,n,o){n.exports=function(s,l,r,a){for(var c=65535&s|0,u=s>>>16&65535|0,m=0;r!==0;){for(r-=m=2e3<r?2e3:r;u=u+(c=c+l[a++]|0)|0,--m;);c%=65521,u%=65521}return c|u<<16|0}},{}],44:[function(e,n,o){n.exports={Z_NO_FLUSH:0,Z_PARTIAL_FLUSH:1,Z_SYNC_FLUSH:2,Z_FULL_FLUSH:3,Z_FINISH:4,Z_BLOCK:5,Z_TREES:6,Z_OK:0,Z_STREAM_END:1,Z_NEED_DICT:2,Z_ERRNO:-1,Z_STREAM_ERROR:-2,Z_DATA_ERROR:-3,Z_BUF_ERROR:-5,Z_NO_COMPRESSION:0,Z_BEST_SPEED:1,Z_BEST_COMPRESSION:9,Z_DEFAULT_COMPRESSION:-1,Z_FILTERED:1,Z_HUFFMAN_ONLY:2,Z_RLE:3,Z_FIXED:4,Z_DEFAULT_STRATEGY:0,Z_BINARY:0,Z_TEXT:1,Z_UNKNOWN:2,Z_DEFLATED:8}},{}],45:[function(e,n,o){var s=(function(){for(var l,r=[],a=0;a<256;a++){l=a;for(var c=0;c<8;c++)l=1&l?3988292384^l>>>1:l>>>1;r[a]=l}return r})();n.exports=function(l,r,a,c){var u=s,m=c+a;l^=-1;for(var g=c;g<m;g++)l=l>>>8^u[255&(l^r[g])];return-1^l}},{}],46:[function(e,n,o){var s,l=e("../utils/common"),r=e("./trees"),a=e("./adler32"),c=e("./crc32"),u=e("./messages"),m=0,g=4,d=0,b=-2,f=-1,v=4,k=2,S=8,x=9,A=286,T=30,I=19,w=2*A+1,N=15,F=3,j=258,J=j+F+1,$=42,O=113,y=1,V=2,X=3,P=4;function U(p,H){return p.msg=u[H],H}function W(p){return(p<<1)-(4<p?9:0)}function tt(p){for(var H=p.length;0<=--H;)p[H]=0}function B(p){var H=p.state,R=H.pending;R>p.avail_out&&(R=p.avail_out),R!==0&&(l.arraySet(p.output,H.pending_buf,H.pending_out,R,p.next_out),p.next_out+=R,H.pending_out+=R,p.total_out+=R,p.avail_out-=R,H.pending-=R,H.pending===0&&(H.pending_out=0))}function M(p,H){r._tr_flush_block(p,0<=p.block_start?p.block_start:-1,p.strstart-p.block_start,H),p.block_start=p.strstart,B(p.strm)}function Y(p,H){p.pending_buf[p.pending++]=H}function Z(p,H){p.pending_buf[p.pending++]=H>>>8&255,p.pending_buf[p.pending++]=255&H}function Q(p,H){var R,_,C=p.max_chain_length,L=p.strstart,G=p.prev_length,K=p.nice_match,q=p.strstart>p.w_size-J?p.strstart-(p.w_size-J):0,et=p.window,ct=p.w_mask,at=p.prev,pt=p.strstart+j,wt=et[L+G-1],kt=et[L+G];p.prev_length>=p.good_match&&(C>>=2),K>p.lookahead&&(K=p.lookahead);do if(et[(R=H)+G]===kt&&et[R+G-1]===wt&&et[R]===et[L]&&et[++R]===et[L+1]){L+=2,R++;do;while(et[++L]===et[++R]&&et[++L]===et[++R]&&et[++L]===et[++R]&&et[++L]===et[++R]&&et[++L]===et[++R]&&et[++L]===et[++R]&&et[++L]===et[++R]&&et[++L]===et[++R]&&L<pt);if(_=j-(pt-L),L=pt-j,G<_){if(p.match_start=H,K<=(G=_))break;wt=et[L+G-1],kt=et[L+G]}}while((H=at[H&ct])>q&&--C!=0);return G<=p.lookahead?G:p.lookahead}function D(p){var H,R,_,C,L,G,K,q,et,ct,at=p.w_size;do{if(C=p.window_size-p.lookahead-p.strstart,p.strstart>=at+(at-J)){for(l.arraySet(p.window,p.window,at,at,0),p.match_start-=at,p.strstart-=at,p.block_start-=at,H=R=p.hash_size;_=p.head[--H],p.head[H]=at<=_?_-at:0,--R;);for(H=R=at;_=p.prev[--H],p.prev[H]=at<=_?_-at:0,--R;);C+=at}if(p.strm.avail_in===0)break;if(G=p.strm,K=p.window,q=p.strstart+p.lookahead,et=C,ct=void 0,ct=G.avail_in,et<ct&&(ct=et),R=ct===0?0:(G.avail_in-=ct,l.arraySet(K,G.input,G.next_in,ct,q),G.state.wrap===1?G.adler=a(G.adler,K,ct,q):G.state.wrap===2&&(G.adler=c(G.adler,K,ct,q)),G.next_in+=ct,G.total_in+=ct,ct),p.lookahead+=R,p.lookahead+p.insert>=F)for(L=p.strstart-p.insert,p.ins_h=p.window[L],p.ins_h=(p.ins_h<<p.hash_shift^p.window[L+1])&p.hash_mask;p.insert&&(p.ins_h=(p.ins_h<<p.hash_shift^p.window[L+F-1])&p.hash_mask,p.prev[L&p.w_mask]=p.head[p.ins_h],p.head[p.ins_h]=L,L++,p.insert--,!(p.lookahead+p.insert<F)););}while(p.lookahead<J&&p.strm.avail_in!==0)}function dt(p,H){for(var R,_;;){if(p.lookahead<J){if(D(p),p.lookahead<J&&H===m)return y;if(p.lookahead===0)break}if(R=0,p.lookahead>=F&&(p.ins_h=(p.ins_h<<p.hash_shift^p.window[p.strstart+F-1])&p.hash_mask,R=p.prev[p.strstart&p.w_mask]=p.head[p.ins_h],p.head[p.ins_h]=p.strstart),R!==0&&p.strstart-R<=p.w_size-J&&(p.match_length=Q(p,R)),p.match_length>=F)if(_=r._tr_tally(p,p.strstart-p.match_start,p.match_length-F),p.lookahead-=p.match_length,p.match_length<=p.max_lazy_match&&p.lookahead>=F){for(p.match_length--;p.strstart++,p.ins_h=(p.ins_h<<p.hash_shift^p.window[p.strstart+F-1])&p.hash_mask,R=p.prev[p.strstart&p.w_mask]=p.head[p.ins_h],p.head[p.ins_h]=p.strstart,--p.match_length!=0;);p.strstart++}else p.strstart+=p.match_length,p.match_length=0,p.ins_h=p.window[p.strstart],p.ins_h=(p.ins_h<<p.hash_shift^p.window[p.strstart+1])&p.hash_mask;else _=r._tr_tally(p,0,p.window[p.strstart]),p.lookahead--,p.strstart++;if(_&&(M(p,!1),p.strm.avail_out===0))return y}return p.insert=p.strstart<F-1?p.strstart:F-1,H===g?(M(p,!0),p.strm.avail_out===0?X:P):p.last_lit&&(M(p,!1),p.strm.avail_out===0)?y:V}function lt(p,H){for(var R,_,C;;){if(p.lookahead<J){if(D(p),p.lookahead<J&&H===m)return y;if(p.lookahead===0)break}if(R=0,p.lookahead>=F&&(p.ins_h=(p.ins_h<<p.hash_shift^p.window[p.strstart+F-1])&p.hash_mask,R=p.prev[p.strstart&p.w_mask]=p.head[p.ins_h],p.head[p.ins_h]=p.strstart),p.prev_length=p.match_length,p.prev_match=p.match_start,p.match_length=F-1,R!==0&&p.prev_length<p.max_lazy_match&&p.strstart-R<=p.w_size-J&&(p.match_length=Q(p,R),p.match_length<=5&&(p.strategy===1||p.match_length===F&&4096<p.strstart-p.match_start)&&(p.match_length=F-1)),p.prev_length>=F&&p.match_length<=p.prev_length){for(C=p.strstart+p.lookahead-F,_=r._tr_tally(p,p.strstart-1-p.prev_match,p.prev_length-F),p.lookahead-=p.prev_length-1,p.prev_length-=2;++p.strstart<=C&&(p.ins_h=(p.ins_h<<p.hash_shift^p.window[p.strstart+F-1])&p.hash_mask,R=p.prev[p.strstart&p.w_mask]=p.head[p.ins_h],p.head[p.ins_h]=p.strstart),--p.prev_length!=0;);if(p.match_available=0,p.match_length=F-1,p.strstart++,_&&(M(p,!1),p.strm.avail_out===0))return y}else if(p.match_available){if((_=r._tr_tally(p,0,p.window[p.strstart-1]))&&M(p,!1),p.strstart++,p.lookahead--,p.strm.avail_out===0)return y}else p.match_available=1,p.strstart++,p.lookahead--}return p.match_available&&(_=r._tr_tally(p,0,p.window[p.strstart-1]),p.match_available=0),p.insert=p.strstart<F-1?p.strstart:F-1,H===g?(M(p,!0),p.strm.avail_out===0?X:P):p.last_lit&&(M(p,!1),p.strm.avail_out===0)?y:V}function rt(p,H,R,_,C){this.good_length=p,this.max_lazy=H,this.nice_length=R,this.max_chain=_,this.func=C}function gt(){this.strm=null,this.status=0,this.pending_buf=null,this.pending_buf_size=0,this.pending_out=0,this.pending=0,this.wrap=0,this.gzhead=null,this.gzindex=0,this.method=S,this.last_flush=-1,this.w_size=0,this.w_bits=0,this.w_mask=0,this.window=null,this.window_size=0,this.prev=null,this.head=null,this.ins_h=0,this.hash_size=0,this.hash_bits=0,this.hash_mask=0,this.hash_shift=0,this.block_start=0,this.match_length=0,this.prev_match=0,this.match_available=0,this.strstart=0,this.match_start=0,this.lookahead=0,this.prev_length=0,this.max_chain_length=0,this.max_lazy_match=0,this.level=0,this.strategy=0,this.good_match=0,this.nice_match=0,this.dyn_ltree=new l.Buf16(2*w),this.dyn_dtree=new l.Buf16(2*(2*T+1)),this.bl_tree=new l.Buf16(2*(2*I+1)),tt(this.dyn_ltree),tt(this.dyn_dtree),tt(this.bl_tree),this.l_desc=null,this.d_desc=null,this.bl_desc=null,this.bl_count=new l.Buf16(N+1),this.heap=new l.Buf16(2*A+1),tt(this.heap),this.heap_len=0,this.heap_max=0,this.depth=new l.Buf16(2*A+1),tt(this.depth),this.l_buf=0,this.lit_bufsize=0,this.last_lit=0,this.d_buf=0,this.opt_len=0,this.static_len=0,this.matches=0,this.insert=0,this.bi_buf=0,this.bi_valid=0}function nt(p){var H;return p&&p.state?(p.total_in=p.total_out=0,p.data_type=k,(H=p.state).pending=0,H.pending_out=0,H.wrap<0&&(H.wrap=-H.wrap),H.status=H.wrap?$:O,p.adler=H.wrap===2?0:1,H.last_flush=m,r._tr_init(H),d):U(p,b)}function E(p){var H=nt(p);return H===d&&(function(R){R.window_size=2*R.w_size,tt(R.head),R.max_lazy_match=s[R.level].max_lazy,R.good_match=s[R.level].good_length,R.nice_match=s[R.level].nice_length,R.max_chain_length=s[R.level].max_chain,R.strstart=0,R.block_start=0,R.lookahead=0,R.insert=0,R.match_length=R.prev_length=F-1,R.match_available=0,R.ins_h=0})(p.state),H}function z(p,H,R,_,C,L){if(!p)return b;var G=1;if(H===f&&(H=6),_<0?(G=0,_=-_):15<_&&(G=2,_-=16),C<1||x<C||R!==S||_<8||15<_||H<0||9<H||L<0||v<L)return U(p,b);_===8&&(_=9);var K=new gt;return(p.state=K).strm=p,K.wrap=G,K.gzhead=null,K.w_bits=_,K.w_size=1<<K.w_bits,K.w_mask=K.w_size-1,K.hash_bits=C+7,K.hash_size=1<<K.hash_bits,K.hash_mask=K.hash_size-1,K.hash_shift=~~((K.hash_bits+F-1)/F),K.window=new l.Buf8(2*K.w_size),K.head=new l.Buf16(K.hash_size),K.prev=new l.Buf16(K.w_size),K.lit_bufsize=1<<C+6,K.pending_buf_size=4*K.lit_bufsize,K.pending_buf=new l.Buf8(K.pending_buf_size),K.d_buf=1*K.lit_bufsize,K.l_buf=3*K.lit_bufsize,K.level=H,K.strategy=L,K.method=R,E(p)}s=[new rt(0,0,0,0,function(p,H){var R=65535;for(R>p.pending_buf_size-5&&(R=p.pending_buf_size-5);;){if(p.lookahead<=1){if(D(p),p.lookahead===0&&H===m)return y;if(p.lookahead===0)break}p.strstart+=p.lookahead,p.lookahead=0;var _=p.block_start+R;if((p.strstart===0||p.strstart>=_)&&(p.lookahead=p.strstart-_,p.strstart=_,M(p,!1),p.strm.avail_out===0)||p.strstart-p.block_start>=p.w_size-J&&(M(p,!1),p.strm.avail_out===0))return y}return p.insert=0,H===g?(M(p,!0),p.strm.avail_out===0?X:P):(p.strstart>p.block_start&&(M(p,!1),p.strm.avail_out),y)}),new rt(4,4,8,4,dt),new rt(4,5,16,8,dt),new rt(4,6,32,32,dt),new rt(4,4,16,16,lt),new rt(8,16,32,32,lt),new rt(8,16,128,128,lt),new rt(8,32,128,256,lt),new rt(32,128,258,1024,lt),new rt(32,258,258,4096,lt)],o.deflateInit=function(p,H){return z(p,H,S,15,8,0)},o.deflateInit2=z,o.deflateReset=E,o.deflateResetKeep=nt,o.deflateSetHeader=function(p,H){return p&&p.state?p.state.wrap!==2?b:(p.state.gzhead=H,d):b},o.deflate=function(p,H){var R,_,C,L;if(!p||!p.state||5<H||H<0)return p?U(p,b):b;if(_=p.state,!p.output||!p.input&&p.avail_in!==0||_.status===666&&H!==g)return U(p,p.avail_out===0?-5:b);if(_.strm=p,R=_.last_flush,_.last_flush=H,_.status===$)if(_.wrap===2)p.adler=0,Y(_,31),Y(_,139),Y(_,8),_.gzhead?(Y(_,(_.gzhead.text?1:0)+(_.gzhead.hcrc?2:0)+(_.gzhead.extra?4:0)+(_.gzhead.name?8:0)+(_.gzhead.comment?16:0)),Y(_,255&_.gzhead.time),Y(_,_.gzhead.time>>8&255),Y(_,_.gzhead.time>>16&255),Y(_,_.gzhead.time>>24&255),Y(_,_.level===9?2:2<=_.strategy||_.level<2?4:0),Y(_,255&_.gzhead.os),_.gzhead.extra&&_.gzhead.extra.length&&(Y(_,255&_.gzhead.extra.length),Y(_,_.gzhead.extra.length>>8&255)),_.gzhead.hcrc&&(p.adler=c(p.adler,_.pending_buf,_.pending,0)),_.gzindex=0,_.status=69):(Y(_,0),Y(_,0),Y(_,0),Y(_,0),Y(_,0),Y(_,_.level===9?2:2<=_.strategy||_.level<2?4:0),Y(_,3),_.status=O);else{var G=S+(_.w_bits-8<<4)<<8;G|=(2<=_.strategy||_.level<2?0:_.level<6?1:_.level===6?2:3)<<6,_.strstart!==0&&(G|=32),G+=31-G%31,_.status=O,Z(_,G),_.strstart!==0&&(Z(_,p.adler>>>16),Z(_,65535&p.adler)),p.adler=1}if(_.status===69)if(_.gzhead.extra){for(C=_.pending;_.gzindex<(65535&_.gzhead.extra.length)&&(_.pending!==_.pending_buf_size||(_.gzhead.hcrc&&_.pending>C&&(p.adler=c(p.adler,_.pending_buf,_.pending-C,C)),B(p),C=_.pending,_.pending!==_.pending_buf_size));)Y(_,255&_.gzhead.extra[_.gzindex]),_.gzindex++;_.gzhead.hcrc&&_.pending>C&&(p.adler=c(p.adler,_.pending_buf,_.pending-C,C)),_.gzindex===_.gzhead.extra.length&&(_.gzindex=0,_.status=73)}else _.status=73;if(_.status===73)if(_.gzhead.name){C=_.pending;do{if(_.pending===_.pending_buf_size&&(_.gzhead.hcrc&&_.pending>C&&(p.adler=c(p.adler,_.pending_buf,_.pending-C,C)),B(p),C=_.pending,_.pending===_.pending_buf_size)){L=1;break}L=_.gzindex<_.gzhead.name.length?255&_.gzhead.name.charCodeAt(_.gzindex++):0,Y(_,L)}while(L!==0);_.gzhead.hcrc&&_.pending>C&&(p.adler=c(p.adler,_.pending_buf,_.pending-C,C)),L===0&&(_.gzindex=0,_.status=91)}else _.status=91;if(_.status===91)if(_.gzhead.comment){C=_.pending;do{if(_.pending===_.pending_buf_size&&(_.gzhead.hcrc&&_.pending>C&&(p.adler=c(p.adler,_.pending_buf,_.pending-C,C)),B(p),C=_.pending,_.pending===_.pending_buf_size)){L=1;break}L=_.gzindex<_.gzhead.comment.length?255&_.gzhead.comment.charCodeAt(_.gzindex++):0,Y(_,L)}while(L!==0);_.gzhead.hcrc&&_.pending>C&&(p.adler=c(p.adler,_.pending_buf,_.pending-C,C)),L===0&&(_.status=103)}else _.status=103;if(_.status===103&&(_.gzhead.hcrc?(_.pending+2>_.pending_buf_size&&B(p),_.pending+2<=_.pending_buf_size&&(Y(_,255&p.adler),Y(_,p.adler>>8&255),p.adler=0,_.status=O)):_.status=O),_.pending!==0){if(B(p),p.avail_out===0)return _.last_flush=-1,d}else if(p.avail_in===0&&W(H)<=W(R)&&H!==g)return U(p,-5);if(_.status===666&&p.avail_in!==0)return U(p,-5);if(p.avail_in!==0||_.lookahead!==0||H!==m&&_.status!==666){var K=_.strategy===2?(function(q,et){for(var ct;;){if(q.lookahead===0&&(D(q),q.lookahead===0)){if(et===m)return y;break}if(q.match_length=0,ct=r._tr_tally(q,0,q.window[q.strstart]),q.lookahead--,q.strstart++,ct&&(M(q,!1),q.strm.avail_out===0))return y}return q.insert=0,et===g?(M(q,!0),q.strm.avail_out===0?X:P):q.last_lit&&(M(q,!1),q.strm.avail_out===0)?y:V})(_,H):_.strategy===3?(function(q,et){for(var ct,at,pt,wt,kt=q.window;;){if(q.lookahead<=j){if(D(q),q.lookahead<=j&&et===m)return y;if(q.lookahead===0)break}if(q.match_length=0,q.lookahead>=F&&0<q.strstart&&(at=kt[pt=q.strstart-1])===kt[++pt]&&at===kt[++pt]&&at===kt[++pt]){wt=q.strstart+j;do;while(at===kt[++pt]&&at===kt[++pt]&&at===kt[++pt]&&at===kt[++pt]&&at===kt[++pt]&&at===kt[++pt]&&at===kt[++pt]&&at===kt[++pt]&&pt<wt);q.match_length=j-(wt-pt),q.match_length>q.lookahead&&(q.match_length=q.lookahead)}if(q.match_length>=F?(ct=r._tr_tally(q,1,q.match_length-F),q.lookahead-=q.match_length,q.strstart+=q.match_length,q.match_length=0):(ct=r._tr_tally(q,0,q.window[q.strstart]),q.lookahead--,q.strstart++),ct&&(M(q,!1),q.strm.avail_out===0))return y}return q.insert=0,et===g?(M(q,!0),q.strm.avail_out===0?X:P):q.last_lit&&(M(q,!1),q.strm.avail_out===0)?y:V})(_,H):s[_.level].func(_,H);if(K!==X&&K!==P||(_.status=666),K===y||K===X)return p.avail_out===0&&(_.last_flush=-1),d;if(K===V&&(H===1?r._tr_align(_):H!==5&&(r._tr_stored_block(_,0,0,!1),H===3&&(tt(_.head),_.lookahead===0&&(_.strstart=0,_.block_start=0,_.insert=0))),B(p),p.avail_out===0))return _.last_flush=-1,d}return H!==g?d:_.wrap<=0?1:(_.wrap===2?(Y(_,255&p.adler),Y(_,p.adler>>8&255),Y(_,p.adler>>16&255),Y(_,p.adler>>24&255),Y(_,255&p.total_in),Y(_,p.total_in>>8&255),Y(_,p.total_in>>16&255),Y(_,p.total_in>>24&255)):(Z(_,p.adler>>>16),Z(_,65535&p.adler)),B(p),0<_.wrap&&(_.wrap=-_.wrap),_.pending!==0?d:1)},o.deflateEnd=function(p){var H;return p&&p.state?(H=p.state.status)!==$&&H!==69&&H!==73&&H!==91&&H!==103&&H!==O&&H!==666?U(p,b):(p.state=null,H===O?U(p,-3):d):b},o.deflateSetDictionary=function(p,H){var R,_,C,L,G,K,q,et,ct=H.length;if(!p||!p.state||(L=(R=p.state).wrap)===2||L===1&&R.status!==$||R.lookahead)return b;for(L===1&&(p.adler=a(p.adler,H,ct,0)),R.wrap=0,ct>=R.w_size&&(L===0&&(tt(R.head),R.strstart=0,R.block_start=0,R.insert=0),et=new l.Buf8(R.w_size),l.arraySet(et,H,ct-R.w_size,R.w_size,0),H=et,ct=R.w_size),G=p.avail_in,K=p.next_in,q=p.input,p.avail_in=ct,p.next_in=0,p.input=H,D(R);R.lookahead>=F;){for(_=R.strstart,C=R.lookahead-(F-1);R.ins_h=(R.ins_h<<R.hash_shift^R.window[_+F-1])&R.hash_mask,R.prev[_&R.w_mask]=R.head[R.ins_h],R.head[R.ins_h]=_,_++,--C;);R.strstart=_,R.lookahead=F-1,D(R)}return R.strstart+=R.lookahead,R.block_start=R.strstart,R.insert=R.lookahead,R.lookahead=0,R.match_length=R.prev_length=F-1,R.match_available=0,p.next_in=K,p.input=q,p.avail_in=G,R.wrap=L,d},o.deflateInfo="pako deflate (from Nodeca project)"},{"../utils/common":41,"./adler32":43,"./crc32":45,"./messages":51,"./trees":52}],47:[function(e,n,o){n.exports=function(){this.text=0,this.time=0,this.xflags=0,this.os=0,this.extra=null,this.extra_len=0,this.name="",this.comment="",this.hcrc=0,this.done=!1}},{}],48:[function(e,n,o){n.exports=function(s,l){var r,a,c,u,m,g,d,b,f,v,k,S,x,A,T,I,w,N,F,j,J,$,O,y,V;r=s.state,a=s.next_in,y=s.input,c=a+(s.avail_in-5),u=s.next_out,V=s.output,m=u-(l-s.avail_out),g=u+(s.avail_out-257),d=r.dmax,b=r.wsize,f=r.whave,v=r.wnext,k=r.window,S=r.hold,x=r.bits,A=r.lencode,T=r.distcode,I=(1<<r.lenbits)-1,w=(1<<r.distbits)-1;t:do{x<15&&(S+=y[a++]<<x,x+=8,S+=y[a++]<<x,x+=8),N=A[S&I];e:for(;;){if(S>>>=F=N>>>24,x-=F,(F=N>>>16&255)===0)V[u++]=65535&N;else{if(!(16&F)){if((64&F)==0){N=A[(65535&N)+(S&(1<<F)-1)];continue e}if(32&F){r.mode=12;break t}s.msg="invalid literal/length code",r.mode=30;break t}j=65535&N,(F&=15)&&(x<F&&(S+=y[a++]<<x,x+=8),j+=S&(1<<F)-1,S>>>=F,x-=F),x<15&&(S+=y[a++]<<x,x+=8,S+=y[a++]<<x,x+=8),N=T[S&w];i:for(;;){if(S>>>=F=N>>>24,x-=F,!(16&(F=N>>>16&255))){if((64&F)==0){N=T[(65535&N)+(S&(1<<F)-1)];continue i}s.msg="invalid distance code",r.mode=30;break t}if(J=65535&N,x<(F&=15)&&(S+=y[a++]<<x,(x+=8)<F&&(S+=y[a++]<<x,x+=8)),d<(J+=S&(1<<F)-1)){s.msg="invalid distance too far back",r.mode=30;break t}if(S>>>=F,x-=F,(F=u-m)<J){if(f<(F=J-F)&&r.sane){s.msg="invalid distance too far back",r.mode=30;break t}if(O=k,($=0)===v){if($+=b-F,F<j){for(j-=F;V[u++]=k[$++],--F;);$=u-J,O=V}}else if(v<F){if($+=b+v-F,(F-=v)<j){for(j-=F;V[u++]=k[$++],--F;);if($=0,v<j){for(j-=F=v;V[u++]=k[$++],--F;);$=u-J,O=V}}}else if($+=v-F,F<j){for(j-=F;V[u++]=k[$++],--F;);$=u-J,O=V}for(;2<j;)V[u++]=O[$++],V[u++]=O[$++],V[u++]=O[$++],j-=3;j&&(V[u++]=O[$++],1<j&&(V[u++]=O[$++]))}else{for($=u-J;V[u++]=V[$++],V[u++]=V[$++],V[u++]=V[$++],2<(j-=3););j&&(V[u++]=V[$++],1<j&&(V[u++]=V[$++]))}break}}break}}while(a<c&&u<g);a-=j=x>>3,S&=(1<<(x-=j<<3))-1,s.next_in=a,s.next_out=u,s.avail_in=a<c?c-a+5:5-(a-c),s.avail_out=u<g?g-u+257:257-(u-g),r.hold=S,r.bits=x}},{}],49:[function(e,n,o){var s=e("../utils/common"),l=e("./adler32"),r=e("./crc32"),a=e("./inffast"),c=e("./inftrees"),u=1,m=2,g=0,d=-2,b=1,f=852,v=592;function k($){return($>>>24&255)+($>>>8&65280)+((65280&$)<<8)+((255&$)<<24)}function S(){this.mode=0,this.last=!1,this.wrap=0,this.havedict=!1,this.flags=0,this.dmax=0,this.check=0,this.total=0,this.head=null,this.wbits=0,this.wsize=0,this.whave=0,this.wnext=0,this.window=null,this.hold=0,this.bits=0,this.length=0,this.offset=0,this.extra=0,this.lencode=null,this.distcode=null,this.lenbits=0,this.distbits=0,this.ncode=0,this.nlen=0,this.ndist=0,this.have=0,this.next=null,this.lens=new s.Buf16(320),this.work=new s.Buf16(288),this.lendyn=null,this.distdyn=null,this.sane=0,this.back=0,this.was=0}function x($){var O;return $&&$.state?(O=$.state,$.total_in=$.total_out=O.total=0,$.msg="",O.wrap&&($.adler=1&O.wrap),O.mode=b,O.last=0,O.havedict=0,O.dmax=32768,O.head=null,O.hold=0,O.bits=0,O.lencode=O.lendyn=new s.Buf32(f),O.distcode=O.distdyn=new s.Buf32(v),O.sane=1,O.back=-1,g):d}function A($){var O;return $&&$.state?((O=$.state).wsize=0,O.whave=0,O.wnext=0,x($)):d}function T($,O){var y,V;return $&&$.state?(V=$.state,O<0?(y=0,O=-O):(y=1+(O>>4),O<48&&(O&=15)),O&&(O<8||15<O)?d:(V.window!==null&&V.wbits!==O&&(V.window=null),V.wrap=y,V.wbits=O,A($))):d}function I($,O){var y,V;return $?(V=new S,($.state=V).window=null,(y=T($,O))!==g&&($.state=null),y):d}var w,N,F=!0;function j($){if(F){var O;for(w=new s.Buf32(512),N=new s.Buf32(32),O=0;O<144;)$.lens[O++]=8;for(;O<256;)$.lens[O++]=9;for(;O<280;)$.lens[O++]=7;for(;O<288;)$.lens[O++]=8;for(c(u,$.lens,0,288,w,0,$.work,{bits:9}),O=0;O<32;)$.lens[O++]=5;c(m,$.lens,0,32,N,0,$.work,{bits:5}),F=!1}$.lencode=w,$.lenbits=9,$.distcode=N,$.distbits=5}function J($,O,y,V){var X,P=$.state;return P.window===null&&(P.wsize=1<<P.wbits,P.wnext=0,P.whave=0,P.window=new s.Buf8(P.wsize)),V>=P.wsize?(s.arraySet(P.window,O,y-P.wsize,P.wsize,0),P.wnext=0,P.whave=P.wsize):(V<(X=P.wsize-P.wnext)&&(X=V),s.arraySet(P.window,O,y-V,X,P.wnext),(V-=X)?(s.arraySet(P.window,O,y-V,V,0),P.wnext=V,P.whave=P.wsize):(P.wnext+=X,P.wnext===P.wsize&&(P.wnext=0),P.whave<P.wsize&&(P.whave+=X))),0}o.inflateReset=A,o.inflateReset2=T,o.inflateResetKeep=x,o.inflateInit=function($){return I($,15)},o.inflateInit2=I,o.inflate=function($,O){var y,V,X,P,U,W,tt,B,M,Y,Z,Q,D,dt,lt,rt,gt,nt,E,z,p,H,R,_,C=0,L=new s.Buf8(4),G=[16,17,18,0,8,7,9,6,10,5,11,4,12,3,13,2,14,1,15];if(!$||!$.state||!$.output||!$.input&&$.avail_in!==0)return d;(y=$.state).mode===12&&(y.mode=13),U=$.next_out,X=$.output,tt=$.avail_out,P=$.next_in,V=$.input,W=$.avail_in,B=y.hold,M=y.bits,Y=W,Z=tt,H=g;t:for(;;)switch(y.mode){case b:if(y.wrap===0){y.mode=13;break}for(;M<16;){if(W===0)break t;W--,B+=V[P++]<<M,M+=8}if(2&y.wrap&&B===35615){L[y.check=0]=255&B,L[1]=B>>>8&255,y.check=r(y.check,L,2,0),M=B=0,y.mode=2;break}if(y.flags=0,y.head&&(y.head.done=!1),!(1&y.wrap)||(((255&B)<<8)+(B>>8))%31){$.msg="incorrect header check",y.mode=30;break}if((15&B)!=8){$.msg="unknown compression method",y.mode=30;break}if(M-=4,p=8+(15&(B>>>=4)),y.wbits===0)y.wbits=p;else if(p>y.wbits){$.msg="invalid window size",y.mode=30;break}y.dmax=1<<p,$.adler=y.check=1,y.mode=512&B?10:12,M=B=0;break;case 2:for(;M<16;){if(W===0)break t;W--,B+=V[P++]<<M,M+=8}if(y.flags=B,(255&y.flags)!=8){$.msg="unknown compression method",y.mode=30;break}if(57344&y.flags){$.msg="unknown header flags set",y.mode=30;break}y.head&&(y.head.text=B>>8&1),512&y.flags&&(L[0]=255&B,L[1]=B>>>8&255,y.check=r(y.check,L,2,0)),M=B=0,y.mode=3;case 3:for(;M<32;){if(W===0)break t;W--,B+=V[P++]<<M,M+=8}y.head&&(y.head.time=B),512&y.flags&&(L[0]=255&B,L[1]=B>>>8&255,L[2]=B>>>16&255,L[3]=B>>>24&255,y.check=r(y.check,L,4,0)),M=B=0,y.mode=4;case 4:for(;M<16;){if(W===0)break t;W--,B+=V[P++]<<M,M+=8}y.head&&(y.head.xflags=255&B,y.head.os=B>>8),512&y.flags&&(L[0]=255&B,L[1]=B>>>8&255,y.check=r(y.check,L,2,0)),M=B=0,y.mode=5;case 5:if(1024&y.flags){for(;M<16;){if(W===0)break t;W--,B+=V[P++]<<M,M+=8}y.length=B,y.head&&(y.head.extra_len=B),512&y.flags&&(L[0]=255&B,L[1]=B>>>8&255,y.check=r(y.check,L,2,0)),M=B=0}else y.head&&(y.head.extra=null);y.mode=6;case 6:if(1024&y.flags&&(W<(Q=y.length)&&(Q=W),Q&&(y.head&&(p=y.head.extra_len-y.length,y.head.extra||(y.head.extra=new Array(y.head.extra_len)),s.arraySet(y.head.extra,V,P,Q,p)),512&y.flags&&(y.check=r(y.check,V,Q,P)),W-=Q,P+=Q,y.length-=Q),y.length))break t;y.length=0,y.mode=7;case 7:if(2048&y.flags){if(W===0)break t;for(Q=0;p=V[P+Q++],y.head&&p&&y.length<65536&&(y.head.name+=String.fromCharCode(p)),p&&Q<W;);if(512&y.flags&&(y.check=r(y.check,V,Q,P)),W-=Q,P+=Q,p)break t}else y.head&&(y.head.name=null);y.length=0,y.mode=8;case 8:if(4096&y.flags){if(W===0)break t;for(Q=0;p=V[P+Q++],y.head&&p&&y.length<65536&&(y.head.comment+=String.fromCharCode(p)),p&&Q<W;);if(512&y.flags&&(y.check=r(y.check,V,Q,P)),W-=Q,P+=Q,p)break t}else y.head&&(y.head.comment=null);y.mode=9;case 9:if(512&y.flags){for(;M<16;){if(W===0)break t;W--,B+=V[P++]<<M,M+=8}if(B!==(65535&y.check)){$.msg="header crc mismatch",y.mode=30;break}M=B=0}y.head&&(y.head.hcrc=y.flags>>9&1,y.head.done=!0),$.adler=y.check=0,y.mode=12;break;case 10:for(;M<32;){if(W===0)break t;W--,B+=V[P++]<<M,M+=8}$.adler=y.check=k(B),M=B=0,y.mode=11;case 11:if(y.havedict===0)return $.next_out=U,$.avail_out=tt,$.next_in=P,$.avail_in=W,y.hold=B,y.bits=M,2;$.adler=y.check=1,y.mode=12;case 12:if(O===5||O===6)break t;case 13:if(y.last){B>>>=7&M,M-=7&M,y.mode=27;break}for(;M<3;){if(W===0)break t;W--,B+=V[P++]<<M,M+=8}switch(y.last=1&B,M-=1,3&(B>>>=1)){case 0:y.mode=14;break;case 1:if(j(y),y.mode=20,O!==6)break;B>>>=2,M-=2;break t;case 2:y.mode=17;break;case 3:$.msg="invalid block type",y.mode=30}B>>>=2,M-=2;break;case 14:for(B>>>=7&M,M-=7&M;M<32;){if(W===0)break t;W--,B+=V[P++]<<M,M+=8}if((65535&B)!=(B>>>16^65535)){$.msg="invalid stored block lengths",y.mode=30;break}if(y.length=65535&B,M=B=0,y.mode=15,O===6)break t;case 15:y.mode=16;case 16:if(Q=y.length){if(W<Q&&(Q=W),tt<Q&&(Q=tt),Q===0)break t;s.arraySet(X,V,P,Q,U),W-=Q,P+=Q,tt-=Q,U+=Q,y.length-=Q;break}y.mode=12;break;case 17:for(;M<14;){if(W===0)break t;W--,B+=V[P++]<<M,M+=8}if(y.nlen=257+(31&B),B>>>=5,M-=5,y.ndist=1+(31&B),B>>>=5,M-=5,y.ncode=4+(15&B),B>>>=4,M-=4,286<y.nlen||30<y.ndist){$.msg="too many length or distance symbols",y.mode=30;break}y.have=0,y.mode=18;case 18:for(;y.have<y.ncode;){for(;M<3;){if(W===0)break t;W--,B+=V[P++]<<M,M+=8}y.lens[G[y.have++]]=7&B,B>>>=3,M-=3}for(;y.have<19;)y.lens[G[y.have++]]=0;if(y.lencode=y.lendyn,y.lenbits=7,R={bits:y.lenbits},H=c(0,y.lens,0,19,y.lencode,0,y.work,R),y.lenbits=R.bits,H){$.msg="invalid code lengths set",y.mode=30;break}y.have=0,y.mode=19;case 19:for(;y.have<y.nlen+y.ndist;){for(;rt=(C=y.lencode[B&(1<<y.lenbits)-1])>>>16&255,gt=65535&C,!((lt=C>>>24)<=M);){if(W===0)break t;W--,B+=V[P++]<<M,M+=8}if(gt<16)B>>>=lt,M-=lt,y.lens[y.have++]=gt;else{if(gt===16){for(_=lt+2;M<_;){if(W===0)break t;W--,B+=V[P++]<<M,M+=8}if(B>>>=lt,M-=lt,y.have===0){$.msg="invalid bit length repeat",y.mode=30;break}p=y.lens[y.have-1],Q=3+(3&B),B>>>=2,M-=2}else if(gt===17){for(_=lt+3;M<_;){if(W===0)break t;W--,B+=V[P++]<<M,M+=8}M-=lt,p=0,Q=3+(7&(B>>>=lt)),B>>>=3,M-=3}else{for(_=lt+7;M<_;){if(W===0)break t;W--,B+=V[P++]<<M,M+=8}M-=lt,p=0,Q=11+(127&(B>>>=lt)),B>>>=7,M-=7}if(y.have+Q>y.nlen+y.ndist){$.msg="invalid bit length repeat",y.mode=30;break}for(;Q--;)y.lens[y.have++]=p}}if(y.mode===30)break;if(y.lens[256]===0){$.msg="invalid code -- missing end-of-block",y.mode=30;break}if(y.lenbits=9,R={bits:y.lenbits},H=c(u,y.lens,0,y.nlen,y.lencode,0,y.work,R),y.lenbits=R.bits,H){$.msg="invalid literal/lengths set",y.mode=30;break}if(y.distbits=6,y.distcode=y.distdyn,R={bits:y.distbits},H=c(m,y.lens,y.nlen,y.ndist,y.distcode,0,y.work,R),y.distbits=R.bits,H){$.msg="invalid distances set",y.mode=30;break}if(y.mode=20,O===6)break t;case 20:y.mode=21;case 21:if(6<=W&&258<=tt){$.next_out=U,$.avail_out=tt,$.next_in=P,$.avail_in=W,y.hold=B,y.bits=M,a($,Z),U=$.next_out,X=$.output,tt=$.avail_out,P=$.next_in,V=$.input,W=$.avail_in,B=y.hold,M=y.bits,y.mode===12&&(y.back=-1);break}for(y.back=0;rt=(C=y.lencode[B&(1<<y.lenbits)-1])>>>16&255,gt=65535&C,!((lt=C>>>24)<=M);){if(W===0)break t;W--,B+=V[P++]<<M,M+=8}if(rt&&(240&rt)==0){for(nt=lt,E=rt,z=gt;rt=(C=y.lencode[z+((B&(1<<nt+E)-1)>>nt)])>>>16&255,gt=65535&C,!(nt+(lt=C>>>24)<=M);){if(W===0)break t;W--,B+=V[P++]<<M,M+=8}B>>>=nt,M-=nt,y.back+=nt}if(B>>>=lt,M-=lt,y.back+=lt,y.length=gt,rt===0){y.mode=26;break}if(32&rt){y.back=-1,y.mode=12;break}if(64&rt){$.msg="invalid literal/length code",y.mode=30;break}y.extra=15&rt,y.mode=22;case 22:if(y.extra){for(_=y.extra;M<_;){if(W===0)break t;W--,B+=V[P++]<<M,M+=8}y.length+=B&(1<<y.extra)-1,B>>>=y.extra,M-=y.extra,y.back+=y.extra}y.was=y.length,y.mode=23;case 23:for(;rt=(C=y.distcode[B&(1<<y.distbits)-1])>>>16&255,gt=65535&C,!((lt=C>>>24)<=M);){if(W===0)break t;W--,B+=V[P++]<<M,M+=8}if((240&rt)==0){for(nt=lt,E=rt,z=gt;rt=(C=y.distcode[z+((B&(1<<nt+E)-1)>>nt)])>>>16&255,gt=65535&C,!(nt+(lt=C>>>24)<=M);){if(W===0)break t;W--,B+=V[P++]<<M,M+=8}B>>>=nt,M-=nt,y.back+=nt}if(B>>>=lt,M-=lt,y.back+=lt,64&rt){$.msg="invalid distance code",y.mode=30;break}y.offset=gt,y.extra=15&rt,y.mode=24;case 24:if(y.extra){for(_=y.extra;M<_;){if(W===0)break t;W--,B+=V[P++]<<M,M+=8}y.offset+=B&(1<<y.extra)-1,B>>>=y.extra,M-=y.extra,y.back+=y.extra}if(y.offset>y.dmax){$.msg="invalid distance too far back",y.mode=30;break}y.mode=25;case 25:if(tt===0)break t;if(Q=Z-tt,y.offset>Q){if((Q=y.offset-Q)>y.whave&&y.sane){$.msg="invalid distance too far back",y.mode=30;break}D=Q>y.wnext?(Q-=y.wnext,y.wsize-Q):y.wnext-Q,Q>y.length&&(Q=y.length),dt=y.window}else dt=X,D=U-y.offset,Q=y.length;for(tt<Q&&(Q=tt),tt-=Q,y.length-=Q;X[U++]=dt[D++],--Q;);y.length===0&&(y.mode=21);break;case 26:if(tt===0)break t;X[U++]=y.length,tt--,y.mode=21;break;case 27:if(y.wrap){for(;M<32;){if(W===0)break t;W--,B|=V[P++]<<M,M+=8}if(Z-=tt,$.total_out+=Z,y.total+=Z,Z&&($.adler=y.check=y.flags?r(y.check,X,Z,U-Z):l(y.check,X,Z,U-Z)),Z=tt,(y.flags?B:k(B))!==y.check){$.msg="incorrect data check",y.mode=30;break}M=B=0}y.mode=28;case 28:if(y.wrap&&y.flags){for(;M<32;){if(W===0)break t;W--,B+=V[P++]<<M,M+=8}if(B!==(4294967295&y.total)){$.msg="incorrect length check",y.mode=30;break}M=B=0}y.mode=29;case 29:H=1;break t;case 30:H=-3;break t;case 31:return-4;case 32:default:return d}return $.next_out=U,$.avail_out=tt,$.next_in=P,$.avail_in=W,y.hold=B,y.bits=M,(y.wsize||Z!==$.avail_out&&y.mode<30&&(y.mode<27||O!==4))&&J($,$.output,$.next_out,Z-$.avail_out)?(y.mode=31,-4):(Y-=$.avail_in,Z-=$.avail_out,$.total_in+=Y,$.total_out+=Z,y.total+=Z,y.wrap&&Z&&($.adler=y.check=y.flags?r(y.check,X,Z,$.next_out-Z):l(y.check,X,Z,$.next_out-Z)),$.data_type=y.bits+(y.last?64:0)+(y.mode===12?128:0)+(y.mode===20||y.mode===15?256:0),(Y==0&&Z===0||O===4)&&H===g&&(H=-5),H)},o.inflateEnd=function($){if(!$||!$.state)return d;var O=$.state;return O.window&&(O.window=null),$.state=null,g},o.inflateGetHeader=function($,O){var y;return $&&$.state?(2&(y=$.state).wrap)==0?d:((y.head=O).done=!1,g):d},o.inflateSetDictionary=function($,O){var y,V=O.length;return $&&$.state?(y=$.state).wrap!==0&&y.mode!==11?d:y.mode===11&&l(1,O,V,0)!==y.check?-3:J($,O,V,V)?(y.mode=31,-4):(y.havedict=1,g):d},o.inflateInfo="pako inflate (from Nodeca project)"},{"../utils/common":41,"./adler32":43,"./crc32":45,"./inffast":48,"./inftrees":50}],50:[function(e,n,o){var s=e("../utils/common"),l=[3,4,5,6,7,8,9,10,11,13,15,17,19,23,27,31,35,43,51,59,67,83,99,115,131,163,195,227,258,0,0],r=[16,16,16,16,16,16,16,16,17,17,17,17,18,18,18,18,19,19,19,19,20,20,20,20,21,21,21,21,16,72,78],a=[1,2,3,4,5,7,9,13,17,25,33,49,65,97,129,193,257,385,513,769,1025,1537,2049,3073,4097,6145,8193,12289,16385,24577,0,0],c=[16,16,16,16,17,17,18,18,19,19,20,20,21,21,22,22,23,23,24,24,25,25,26,26,27,27,28,28,29,29,64,64];n.exports=function(u,m,g,d,b,f,v,k){var S,x,A,T,I,w,N,F,j,J=k.bits,$=0,O=0,y=0,V=0,X=0,P=0,U=0,W=0,tt=0,B=0,M=null,Y=0,Z=new s.Buf16(16),Q=new s.Buf16(16),D=null,dt=0;for($=0;$<=15;$++)Z[$]=0;for(O=0;O<d;O++)Z[m[g+O]]++;for(X=J,V=15;1<=V&&Z[V]===0;V--);if(V<X&&(X=V),V===0)return b[f++]=20971520,b[f++]=20971520,k.bits=1,0;for(y=1;y<V&&Z[y]===0;y++);for(X<y&&(X=y),$=W=1;$<=15;$++)if(W<<=1,(W-=Z[$])<0)return-1;if(0<W&&(u===0||V!==1))return-1;for(Q[1]=0,$=1;$<15;$++)Q[$+1]=Q[$]+Z[$];for(O=0;O<d;O++)m[g+O]!==0&&(v[Q[m[g+O]]++]=O);if(w=u===0?(M=D=v,19):u===1?(M=l,Y-=257,D=r,dt-=257,256):(M=a,D=c,-1),$=y,I=f,U=O=B=0,A=-1,T=(tt=1<<(P=X))-1,u===1&&852<tt||u===2&&592<tt)return 1;for(;;){for(N=$-U,j=v[O]<w?(F=0,v[O]):v[O]>w?(F=D[dt+v[O]],M[Y+v[O]]):(F=96,0),S=1<<$-U,y=x=1<<P;b[I+(B>>U)+(x-=S)]=N<<24|F<<16|j|0,x!==0;);for(S=1<<$-1;B&S;)S>>=1;if(S!==0?(B&=S-1,B+=S):B=0,O++,--Z[$]==0){if($===V)break;$=m[g+v[O]]}if(X<$&&(B&T)!==A){for(U===0&&(U=X),I+=y,W=1<<(P=$-U);P+U<V&&!((W-=Z[P+U])<=0);)P++,W<<=1;if(tt+=1<<P,u===1&&852<tt||u===2&&592<tt)return 1;b[A=B&T]=X<<24|P<<16|I-f|0}}return B!==0&&(b[I+B]=$-U<<24|64<<16|0),k.bits=X,0}},{"../utils/common":41}],51:[function(e,n,o){n.exports={2:"need dictionary",1:"stream end",0:"","-1":"file error","-2":"stream error","-3":"data error","-4":"insufficient memory","-5":"buffer error","-6":"incompatible version"}},{}],52:[function(e,n,o){var s=e("../utils/common"),l=0,r=1;function a(C){for(var L=C.length;0<=--L;)C[L]=0}var c=0,u=29,m=256,g=m+1+u,d=30,b=19,f=2*g+1,v=15,k=16,S=7,x=256,A=16,T=17,I=18,w=[0,0,0,0,0,0,0,0,1,1,1,1,2,2,2,2,3,3,3,3,4,4,4,4,5,5,5,5,0],N=[0,0,0,0,1,1,2,2,3,3,4,4,5,5,6,6,7,7,8,8,9,9,10,10,11,11,12,12,13,13],F=[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,2,3,7],j=[16,17,18,0,8,7,9,6,10,5,11,4,12,3,13,2,14,1,15],J=new Array(2*(g+2));a(J);var $=new Array(2*d);a($);var O=new Array(512);a(O);var y=new Array(256);a(y);var V=new Array(u);a(V);var X,P,U,W=new Array(d);function tt(C,L,G,K,q){this.static_tree=C,this.extra_bits=L,this.extra_base=G,this.elems=K,this.max_length=q,this.has_stree=C&&C.length}function B(C,L){this.dyn_tree=C,this.max_code=0,this.stat_desc=L}function M(C){return C<256?O[C]:O[256+(C>>>7)]}function Y(C,L){C.pending_buf[C.pending++]=255&L,C.pending_buf[C.pending++]=L>>>8&255}function Z(C,L,G){C.bi_valid>k-G?(C.bi_buf|=L<<C.bi_valid&65535,Y(C,C.bi_buf),C.bi_buf=L>>k-C.bi_valid,C.bi_valid+=G-k):(C.bi_buf|=L<<C.bi_valid&65535,C.bi_valid+=G)}function Q(C,L,G){Z(C,G[2*L],G[2*L+1])}function D(C,L){for(var G=0;G|=1&C,C>>>=1,G<<=1,0<--L;);return G>>>1}function dt(C,L,G){var K,q,et=new Array(v+1),ct=0;for(K=1;K<=v;K++)et[K]=ct=ct+G[K-1]<<1;for(q=0;q<=L;q++){var at=C[2*q+1];at!==0&&(C[2*q]=D(et[at]++,at))}}function lt(C){var L;for(L=0;L<g;L++)C.dyn_ltree[2*L]=0;for(L=0;L<d;L++)C.dyn_dtree[2*L]=0;for(L=0;L<b;L++)C.bl_tree[2*L]=0;C.dyn_ltree[2*x]=1,C.opt_len=C.static_len=0,C.last_lit=C.matches=0}function rt(C){8<C.bi_valid?Y(C,C.bi_buf):0<C.bi_valid&&(C.pending_buf[C.pending++]=C.bi_buf),C.bi_buf=0,C.bi_valid=0}function gt(C,L,G,K){var q=2*L,et=2*G;return C[q]<C[et]||C[q]===C[et]&&K[L]<=K[G]}function nt(C,L,G){for(var K=C.heap[G],q=G<<1;q<=C.heap_len&&(q<C.heap_len&&gt(L,C.heap[q+1],C.heap[q],C.depth)&&q++,!gt(L,K,C.heap[q],C.depth));)C.heap[G]=C.heap[q],G=q,q<<=1;C.heap[G]=K}function E(C,L,G){var K,q,et,ct,at=0;if(C.last_lit!==0)for(;K=C.pending_buf[C.d_buf+2*at]<<8|C.pending_buf[C.d_buf+2*at+1],q=C.pending_buf[C.l_buf+at],at++,K===0?Q(C,q,L):(Q(C,(et=y[q])+m+1,L),(ct=w[et])!==0&&Z(C,q-=V[et],ct),Q(C,et=M(--K),G),(ct=N[et])!==0&&Z(C,K-=W[et],ct)),at<C.last_lit;);Q(C,x,L)}function z(C,L){var G,K,q,et=L.dyn_tree,ct=L.stat_desc.static_tree,at=L.stat_desc.has_stree,pt=L.stat_desc.elems,wt=-1;for(C.heap_len=0,C.heap_max=f,G=0;G<pt;G++)et[2*G]!==0?(C.heap[++C.heap_len]=wt=G,C.depth[G]=0):et[2*G+1]=0;for(;C.heap_len<2;)et[2*(q=C.heap[++C.heap_len]=wt<2?++wt:0)]=1,C.depth[q]=0,C.opt_len--,at&&(C.static_len-=ct[2*q+1]);for(L.max_code=wt,G=C.heap_len>>1;1<=G;G--)nt(C,et,G);for(q=pt;G=C.heap[1],C.heap[1]=C.heap[C.heap_len--],nt(C,et,1),K=C.heap[1],C.heap[--C.heap_max]=G,C.heap[--C.heap_max]=K,et[2*q]=et[2*G]+et[2*K],C.depth[q]=(C.depth[G]>=C.depth[K]?C.depth[G]:C.depth[K])+1,et[2*G+1]=et[2*K+1]=q,C.heap[1]=q++,nt(C,et,1),2<=C.heap_len;);C.heap[--C.heap_max]=C.heap[1],(function(kt,Dt){var Gt,Yt,ie,Nt,Ge,se,Xt=Dt.dyn_tree,ki=Dt.max_code,zi=Dt.stat_desc.static_tree,Lo=Dt.stat_desc.has_stree,Do=Dt.stat_desc.extra_bits,Fn=Dt.stat_desc.extra_base,wi=Dt.stat_desc.max_length,Ni=0;for(Nt=0;Nt<=v;Nt++)kt.bl_count[Nt]=0;for(Xt[2*kt.heap[kt.heap_max]+1]=0,Gt=kt.heap_max+1;Gt<f;Gt++)wi<(Nt=Xt[2*Xt[2*(Yt=kt.heap[Gt])+1]+1]+1)&&(Nt=wi,Ni++),Xt[2*Yt+1]=Nt,ki<Yt||(kt.bl_count[Nt]++,Ge=0,Fn<=Yt&&(Ge=Do[Yt-Fn]),se=Xt[2*Yt],kt.opt_len+=se*(Nt+Ge),Lo&&(kt.static_len+=se*(zi[2*Yt+1]+Ge)));if(Ni!==0){do{for(Nt=wi-1;kt.bl_count[Nt]===0;)Nt--;kt.bl_count[Nt]--,kt.bl_count[Nt+1]+=2,kt.bl_count[wi]--,Ni-=2}while(0<Ni);for(Nt=wi;Nt!==0;Nt--)for(Yt=kt.bl_count[Nt];Yt!==0;)ki<(ie=kt.heap[--Gt])||(Xt[2*ie+1]!==Nt&&(kt.opt_len+=(Nt-Xt[2*ie+1])*Xt[2*ie],Xt[2*ie+1]=Nt),Yt--)}})(C,L),dt(et,wt,C.bl_count)}function p(C,L,G){var K,q,et=-1,ct=L[1],at=0,pt=7,wt=4;for(ct===0&&(pt=138,wt=3),L[2*(G+1)+1]=65535,K=0;K<=G;K++)q=ct,ct=L[2*(K+1)+1],++at<pt&&q===ct||(at<wt?C.bl_tree[2*q]+=at:q!==0?(q!==et&&C.bl_tree[2*q]++,C.bl_tree[2*A]++):at<=10?C.bl_tree[2*T]++:C.bl_tree[2*I]++,et=q,wt=(at=0)===ct?(pt=138,3):q===ct?(pt=6,3):(pt=7,4))}function H(C,L,G){var K,q,et=-1,ct=L[1],at=0,pt=7,wt=4;for(ct===0&&(pt=138,wt=3),K=0;K<=G;K++)if(q=ct,ct=L[2*(K+1)+1],!(++at<pt&&q===ct)){if(at<wt)for(;Q(C,q,C.bl_tree),--at!=0;);else q!==0?(q!==et&&(Q(C,q,C.bl_tree),at--),Q(C,A,C.bl_tree),Z(C,at-3,2)):at<=10?(Q(C,T,C.bl_tree),Z(C,at-3,3)):(Q(C,I,C.bl_tree),Z(C,at-11,7));et=q,wt=(at=0)===ct?(pt=138,3):q===ct?(pt=6,3):(pt=7,4)}}a(W);var R=!1;function _(C,L,G,K){Z(C,(c<<1)+(K?1:0),3),(function(q,et,ct,at){rt(q),Y(q,ct),Y(q,~ct),s.arraySet(q.pending_buf,q.window,et,ct,q.pending),q.pending+=ct})(C,L,G)}o._tr_init=function(C){R||((function(){var L,G,K,q,et,ct=new Array(v+1);for(q=K=0;q<u-1;q++)for(V[q]=K,L=0;L<1<<w[q];L++)y[K++]=q;for(y[K-1]=q,q=et=0;q<16;q++)for(W[q]=et,L=0;L<1<<N[q];L++)O[et++]=q;for(et>>=7;q<d;q++)for(W[q]=et<<7,L=0;L<1<<N[q]-7;L++)O[256+et++]=q;for(G=0;G<=v;G++)ct[G]=0;for(L=0;L<=143;)J[2*L+1]=8,L++,ct[8]++;for(;L<=255;)J[2*L+1]=9,L++,ct[9]++;for(;L<=279;)J[2*L+1]=7,L++,ct[7]++;for(;L<=287;)J[2*L+1]=8,L++,ct[8]++;for(dt(J,g+1,ct),L=0;L<d;L++)$[2*L+1]=5,$[2*L]=D(L,5);X=new tt(J,w,m+1,g,v),P=new tt($,N,0,d,v),U=new tt(new Array(0),F,0,b,S)})(),R=!0),C.l_desc=new B(C.dyn_ltree,X),C.d_desc=new B(C.dyn_dtree,P),C.bl_desc=new B(C.bl_tree,U),C.bi_buf=0,C.bi_valid=0,lt(C)},o._tr_stored_block=_,o._tr_flush_block=function(C,L,G,K){var q,et,ct=0;0<C.level?(C.strm.data_type===2&&(C.strm.data_type=(function(at){var pt,wt=4093624447;for(pt=0;pt<=31;pt++,wt>>>=1)if(1&wt&&at.dyn_ltree[2*pt]!==0)return l;if(at.dyn_ltree[18]!==0||at.dyn_ltree[20]!==0||at.dyn_ltree[26]!==0)return r;for(pt=32;pt<m;pt++)if(at.dyn_ltree[2*pt]!==0)return r;return l})(C)),z(C,C.l_desc),z(C,C.d_desc),ct=(function(at){var pt;for(p(at,at.dyn_ltree,at.l_desc.max_code),p(at,at.dyn_dtree,at.d_desc.max_code),z(at,at.bl_desc),pt=b-1;3<=pt&&at.bl_tree[2*j[pt]+1]===0;pt--);return at.opt_len+=3*(pt+1)+5+5+4,pt})(C),q=C.opt_len+3+7>>>3,(et=C.static_len+3+7>>>3)<=q&&(q=et)):q=et=G+5,G+4<=q&&L!==-1?_(C,L,G,K):C.strategy===4||et===q?(Z(C,2+(K?1:0),3),E(C,J,$)):(Z(C,4+(K?1:0),3),(function(at,pt,wt,kt){var Dt;for(Z(at,pt-257,5),Z(at,wt-1,5),Z(at,kt-4,4),Dt=0;Dt<kt;Dt++)Z(at,at.bl_tree[2*j[Dt]+1],3);H(at,at.dyn_ltree,pt-1),H(at,at.dyn_dtree,wt-1)})(C,C.l_desc.max_code+1,C.d_desc.max_code+1,ct+1),E(C,C.dyn_ltree,C.dyn_dtree)),lt(C),K&&rt(C)},o._tr_tally=function(C,L,G){return C.pending_buf[C.d_buf+2*C.last_lit]=L>>>8&255,C.pending_buf[C.d_buf+2*C.last_lit+1]=255&L,C.pending_buf[C.l_buf+C.last_lit]=255&G,C.last_lit++,L===0?C.dyn_ltree[2*G]++:(C.matches++,L--,C.dyn_ltree[2*(y[G]+m+1)]++,C.dyn_dtree[2*M(L)]++),C.last_lit===C.lit_bufsize-1},o._tr_align=function(C){Z(C,2,3),Q(C,x,J),(function(L){L.bi_valid===16?(Y(L,L.bi_buf),L.bi_buf=0,L.bi_valid=0):8<=L.bi_valid&&(L.pending_buf[L.pending++]=255&L.bi_buf,L.bi_buf>>=8,L.bi_valid-=8)})(C)}},{"../utils/common":41}],53:[function(e,n,o){n.exports=function(){this.input=null,this.next_in=0,this.avail_in=0,this.total_in=0,this.output=null,this.next_out=0,this.avail_out=0,this.total_out=0,this.msg="",this.state=null,this.data_type=2,this.adler=0}},{}],54:[function(e,n,o){(function(s){(function(l,r){if(!l.setImmediate){var a,c,u,m,g=1,d={},b=!1,f=l.document,v=Object.getPrototypeOf&&Object.getPrototypeOf(l);v=v&&v.setTimeout?v:l,a={}.toString.call(l.process)==="[object process]"?function(A){process.nextTick(function(){S(A)})}:(function(){if(l.postMessage&&!l.importScripts){var A=!0,T=l.onmessage;return l.onmessage=function(){A=!1},l.postMessage("","*"),l.onmessage=T,A}})()?(m="setImmediate$"+Math.random()+"$",l.addEventListener?l.addEventListener("message",x,!1):l.attachEvent("onmessage",x),function(A){l.postMessage(m+A,"*")}):l.MessageChannel?((u=new MessageChannel).port1.onmessage=function(A){S(A.data)},function(A){u.port2.postMessage(A)}):f&&"onreadystatechange"in f.createElement("script")?(c=f.documentElement,function(A){var T=f.createElement("script");T.onreadystatechange=function(){S(A),T.onreadystatechange=null,c.removeChild(T),T=null},c.appendChild(T)}):function(A){setTimeout(S,0,A)},v.setImmediate=function(A){typeof A!="function"&&(A=new Function(""+A));for(var T=new Array(arguments.length-1),I=0;I<T.length;I++)T[I]=arguments[I+1];var w={callback:A,args:T};return d[g]=w,a(g),g++},v.clearImmediate=k}function k(A){delete d[A]}function S(A){if(b)setTimeout(S,0,A);else{var T=d[A];if(T){b=!0;try{(function(I){var w=I.callback,N=I.args;switch(N.length){case 0:w();break;case 1:w(N[0]);break;case 2:w(N[0],N[1]);break;case 3:w(N[0],N[1],N[2]);break;default:w.apply(r,N)}})(T)}finally{k(A),b=!1}}}}function x(A){A.source===l&&typeof A.data=="string"&&A.data.indexOf(m)===0&&S(+A.data.slice(m.length))}})(typeof self>"u"?s===void 0?this:s:self)}).call(this,typeof Zn<"u"?Zn:typeof self<"u"?self:typeof window<"u"?window:{})},{}]},{},[10])(10)})})(Yo)),Yo.exports}var W1=U1();const V1=j1(W1),q1=/\.(?:png|jpe?g|gif|svg|webp|avif|ico|bmp|tiff?|mp4|webm|mp3|wav|ogg)$/i,K1=/\.(?:ts|js|mjs|cjs|jsx|tsx|vue|json|css|scss|less|html|py|rs|go|java|c|cpp|h|sh|bash|yaml|yml|toml)$/i;async function G1(t){const i=await V1.loadAsync(t),e={},n=[];let o="",s="";const l=[];i.forEach((a,c)=>{!c.dir&&!a.startsWith("__MACOSX")&&!a.includes("node_modules/")&&l.push({path:a,file:c})});let r=l.find(a=>a.path.toLowerCase()==="slides.md");r||(r=l.find(a=>a.path.toLowerCase().endsWith("/slides.md"))),r||(r=l.find(a=>a.path.toLowerCase().endsWith(".md"))),r&&(o=await r.file.async("string"),s=r.path);for(const a of l){const c=a.path;if(c.toLowerCase().endsWith(".md")||K1.test(c)||c.includes("snippets/")){const u=await a.file.async("string");e[c]=u;const m=c.split("/");m.length>1&&(e[m.slice(1).join("/")]=u)}else if(q1.test(c)){const u=await a.file.async("uint8array"),m=c.split("/").pop()||c,g=typeof Blob<"u"?new Blob([u]):void 0;n.push({zipPath:c,fileName:m,data:u,blob:g})}}return{entryMarkdown:o,entryMarkdownPath:s,virtualFiles:e,assets:n}}function Z1(t,i){if(Object.keys(i).length===0)return t;function e(o){const s=o.trim().replace(/^['"]|['"]$/g,""),l=s.split("/").pop()||s;if(i[s])return i[s];const r=s.replace(/^\.?\//,"");return i[r]?i[r]:i[l]?i[l]:null}function n(o){let s=o;return s=s.replace(/!\[(.*?)\]\((.*?)\)/g,(l,r,a)=>{const c=e(a);return c?`![${r}](${c})`:l}),s=s.replace(/\bsrc=["'](.*?)["']/gi,(l,r)=>{const a=e(r);return a?`src="${a}"`:l}),s}for(const o of t.slides)if(o.rawMarkdown=n(o.rawMarkdown),o.pageAttrs["custom-slidev-background"]){const s=o.pageAttrs["custom-slidev-background"],l=e(s);l&&(o.pageAttrs["custom-slidev-background"]=l)}if(t.flattenedMarkdown=n(t.flattenedMarkdown),t.docRootAttrs["custom-slidev-background"]){const o=t.docRootAttrs["custom-slidev-background"],s=e(o);s&&(t.docRootAttrs["custom-slidev-background"]=s)}return t}function ma(t){try{if(typeof process<"u"&&typeof require<"u"){const i=require("fs");if(i.existsSync(t))return i.readFileSync(t,"utf-8")}}catch{}return null}function Y1(t,i){const e=t.match(/^[ \t]*<<<[ \t]+([^\s]+)/);if(!e)return null;const n=e[1].trim(),o=n.indexOf("#"),s=o!==-1?n.slice(0,o):n,l=o!==-1?n.slice(o+1):"",r=s.replace(/^@\//,"").replace(/^\.\//,""),a=(i==null?void 0:i.virtualFiles)||{};let c=a[s]||a[r]||a[`./${r}`]||a[`@/${r}`];if(!c&&Object.keys(a).length>0){const d=r.split("/").pop();for(const[b,f]of Object.entries(a))if(b.endsWith(`/${r}`)||d&&b.endsWith(`/${d}`)){c=f;break}}if(!c){const d=[];if(i!=null&&i.baseDir)try{const b=require("path");d.push(b.resolve(i.baseDir,r)),d.push(b.resolve(i.baseDir,s))}catch{}try{const b=require("path");d.push(b.resolve(process.cwd(),r))}catch{}for(const b of d){const f=ma(b);if(f!==null){c=f;break}}}if(!c){const d=la||{};if(c=d[s]||d[r]||d[`snippets/${r}`],!c){const b=r.split("/").pop();for(const[f,v]of Object.entries(d))if(f.endsWith(`/${r}`)||b&&f.endsWith(`/${b}`)){c=v;break}}}if(!c)return null;let u=c;if(l){const d=new RegExp(`(?:\\/\\/|\\/\\*|#)?\\s*#(?:region|REGION)\\s+${l}[^\\r\\n]*\\r?\\n([\\s\\S]*?)(?:\\/\\/|\\/\\*|#)?\\s*#(?:endregion|ENDREGION)\\s+${l}`,"i"),b=c.match(d);if(b){const f=c.match(/^(\/\/\s*Inside[^\r\n]+\r?\n)/i);u=(f?f[1]:"")+b[1].trimEnd()}}const m=r.match(/\.([a-zA-Z0-9]+)$/);return`\`\`\`${m?m[1]:""}
${u}
\`\`\``}function J1(t){let i=!1,e=!1;for(let n=0;n<t.length;n++){const o=t[n];if(o==="'"&&!e)i=!i;else if(o==='"'&&!i)e=!e;else if(o==="#"&&!i&&!e)return t.slice(0,n).trim()}return t.trim()}function to(t){const i={},e=t.split(/\r?\n/);let n=0;for(;n<e.length;){const o=e[n],s=o.trim();if(!s||s.startsWith("#")){n++;continue}const l=o.indexOf(":");if(l>0){const r=o.slice(0,l).trim();let a=o.slice(l+1).trim();if(a==="|"||a===">"){n++;const c=[];let u=-1;for(;n<e.length;){const m=e[n];if(!m.trim()){c.push(""),n++;continue}const d=m.match(/^(\s+)/),b=d?d[1].length:0;if(u===-1&&(u=b),b<u)break;c.push(m.slice(u)),n++}for(;c.length>0&&c[c.length-1]==="";)c.pop();i[r]=a===">"?c.join(" "):c.join(`
`);continue}if(a=J1(a),!a){let c=n+1;const u=[];let m=-1;for(;c<e.length;){const g=e[c],d=g.trim();if(!d||d.startsWith("#")){m!==-1&&u.push(""),c++;continue}const b=g.match(/^(\s+)/),f=b?b[1].length:0;if(m===-1)if(f>0)m=f;else break;if(f<m)break;u.push(g.slice(m)),c++}if(u.length>0){i[r]=to(u.join(`
`)),n=c;continue}}a.startsWith('"')&&a.endsWith('"')||a.startsWith("'")&&a.endsWith("'")?a=a.slice(1,-1):a==="true"?a=!0:a==="false"?a=!1:a==="null"?a=null:/^-?\d+(?:\.\d+)?$/.test(a)&&(a=Number(a)),i[r]=a}n++}return i}const X1=/^\s*```ya?ml([\s\S]*?)```/;function Lr(t){let i={},e=t.trim();const n=e.match(/^---[^\n\r]*\r?\n([\s\S]*?)\r?\n---(?=[ \t]*(?:\r?\n|$))/);if(n&&!n[1].includes("```")){const s=to(n[1]);if(Object.keys(s).length>0||!n[1].trim())return i=s,e=e.slice(n[0].length).trim(),{frontmatter:i,content:e}}if(e.startsWith("---")){const s=e.match(/^---[^\n\r]*(?:\r?\n|$)/);s&&(e=e.slice(s[0].length).trim())}const o=e.match(X1);if(o)i=to(o[1]),e=e.slice(o[0].length).trim();else{const s=e.split(/\r?\n/),l=[];let r=0;for(let a=0;a<s.length;a++){const c=s[a].trim();if(!c){if(l.length>0){r=a+1;break}continue}if(/^[a-zA-Z0-9_-]+\s*:\s*.*/.test(c)&&!c.startsWith("<")&&!c.startsWith("#"))l.push(c);else{r=a;break}}l.length>0&&(i=to(l.join(`
`)),e=s.slice(r).join(`
`).trim())}return{frontmatter:i,content:e}}function Q1(t){const i=t.split(/\r?\n/),e=[];let n=0,o=!1;function s(l){if(n>=l)return;const r=i.slice(n,l).join(`
`).trim();r&&e.push(r),n=l+1}for(let l=0;l<i.length;l++){const a=i[l].trimEnd();if(o){a.includes("-->")&&(o=!1);continue}if(a.startsWith("<!--")){a.includes("-->")||(o=!0);continue}if(a.startsWith("---")){s(l);const c=i[l+1];if(c&&c.trim()&&a.replace(/^-+/,"").trim()==="")for(n=l,l+=1;l<i.length&&i[l].trimEnd()!=="---";l++);}else if(a.trimStart().startsWith("```")){const c=a.match(/^\s*`+/),u=c?c[0].trim():"```";let m=l+1;for(;m<i.length&&!i[m].trimStart().startsWith(u);m++);m<i.length&&(l=m)}}return n<i.length&&s(i.length),e}function eo(t,i={}){const{stripNotesFromMarkdown:e=!0,cleanVClicks:n=!0,cleanShikiLines:o=!0,cleanSlots:s=!0,isolateStyleTags:l=!0,cleanHtmlToMarkdown:r=!0,wrapSuperBlocks:a=!0,virtualFiles:c={}}=i;let u=t;u&&!u.trimStart().startsWith("---")&&(u=`---

${u.trimStart()}`);const m=Q1(u),g={};let d="",b="",f=0;if(m.length>0){const j=m[0],J=Lr(j),$=Object.keys(J.frontmatter).length>0,O=J.content.length>0;$&&!O&&m.length>1?(f=1,v(J.frontmatter)):$&&v(J.frontmatter)}function v(j){d=j.title||"",j.theme&&(g[xn]=String(j.theme)),j.aspectRatio&&(g[Sn]=String(j.aspectRatio)),j.highlighter&&(g[Hr]=String(j.highlighter)),j.transition&&(g[_n]=String(j.transition)),j.colorSchema&&(g[jr]=String(j.colorSchema)),j.layout&&(g[mt]=String(j.layout)),j.background&&(g[Ut]=String(j.background)),j.image&&(g[Ee]=String(j.image)),j.class&&(g[Vi]=String(j.class));for(const[J,$]of Object.entries(j))["theme","aspectRatio","highlighter","transition","colorSchema","title","layout","background","image","class"].includes(J)||(g[`custom-slidev-${J}`]=typeof $=="object"?JSON.stringify($):String($))}const k=[];let S=0,x=0,A=0,T=0;const I=new Set,w={};let N=1;for(let j=f;j<m.length;j++){const J=m[j],{frontmatter:$,content:O}=Lr(J),y=J.match(/^\s*(?:---\s*)?src:\s*([^\n\r]+)/m),V=$.src||(y?y[1]:void 0);if(V){const rt=String(V).trim().replace(/^['"]|['"]$/g,"");let gt=c[rt]||c[rt.replace(/^\.\//,"")]||c[`pages/${rt.replace(/^.*pages\//,"")}`];if(!gt){const E=rt.replace(/^\.\//,""),z=[];if(i.baseDir)try{const p=require("path");z.push(p.resolve(i.baseDir,E)),z.push(p.resolve(i.baseDir,rt))}catch{}try{const p=require("path");z.push(p.resolve(process.cwd(),E)),z.push(p.resolve(process.cwd(),rt))}catch{}for(const p of z){const H=ma(p);if(H!==null){gt=H;break}}}const nt={};$.layout&&(nt[mt]=String($.layout)),$.transition&&(nt[te]=String($.transition)),$.background&&(nt[Ut]=String($.background)),$.image&&(nt[Ee]=String($.image)),$.class&&(nt[Vi]=String($.class));for(const[E,z]of Object.entries($))["src","layout","transition","background","image","class"].includes(E)||(nt[`custom-slidev-${E}`]=typeof z=="object"?JSON.stringify(z):String(z));if(gt){const E=eo(gt,{...i,virtualFiles:c});for(const z of E.slides){z.pageIndex=N++,z.pageAttrs={...nt,...z.pageAttrs},k.push(z);const p=z.pageAttrs[mt]||"default";w[p]=(w[p]||0)+1}continue}else{k.push({pageIndex:N++,pageAttrs:{...nt,"custom-slidev-src":rt},notes:"",rawMarkdown:`> 📄 **引入外部幻灯片页面**: \`${rt}\`
>
> *提示：如需展示该页面完整内容，请将关联子页面一同打包为 .zip 或通过本地工程导入。*`,hasVueComponent:!1,hasStyleTag:!1,assetReferences:[]});const E=nt[mt]||"default";w[E]=(w[E]||0)+1;continue}}const X={};$.layout&&(X[mt]=String($.layout)),$.transition&&(X[te]=String($.transition)),$.background&&(X[Ut]=String($.background)),$.image&&(X[Ee]=String($.image)),$.class&&(X[Vi]=String($.class));for(const[rt,gt]of Object.entries($))["layout","transition","background","image","class"].includes(rt)||(X[`custom-slidev-${rt}`]=typeof gt=="object"?JSON.stringify(gt):String(gt));let P=O;const U=[];let W=P.replace(/(?:^[ \t]*(`{3,}|~{3,})[^\n\r]*\r?\n[\s\S]*?\r?\n[ \t]*\1(?=[ \t]*(?:\r?\n|$)))/gm,rt=>{const gt=`__CODE_TOKEN_NOTE_${U.length}__`;return U.push(rt),gt});W=W.replace(/(`+)(?:[^\n\r`]|(?!\1)`)+?\1/g,rt=>{const gt=`__CODE_TOKEN_NOTE_${U.length}__`;return U.push(rt),gt});let tt="";const B=Array.from(W.matchAll(/<!--([\s\S]*?)-->/g));if(B.length>0){const rt=B[B.length-1],gt=W.slice(rt.index+rt[0].length).trim();if(!gt||!gt.replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi,"").trim()){const E=rt[1].trim();E.startsWith("TODO:")||(tt=E,S++),e&&(W=W.slice(0,rt.index).trimEnd()+W.slice(rt.index+rt[0].length))}}e&&(W=W.replace(/<!--(?![\s\S]*?TODO:)[\s\S]*?-->/g,"").trim());for(let rt=0;rt<U.length;rt++)W=W.replace(`__CODE_TOKEN_NOTE_${rt}__`,U[rt]);if(P=W,tt){for(let nt=0;nt<U.length;nt++)tt=tt.replace(`__CODE_TOKEN_NOTE_${nt}__`,U[nt]);const gt=`> [!NOTE] 💡 演讲备注
${tt.split(/\r?\n/).map(nt=>`> ${nt}`).join(`
`)}
{: custom-slidev-note="true"}`;P=P?`${P}

${gt}`:gt}let M=!1;if(/<style\b/i.test(P)){M=!0;const rt=P.match(/<style\b[^>]*>([\s\S]*?)<\/style>/gi);if(rt){for(const gt of rt){const nt=gt.replace(/<style\b[^>]*>|<\/style>/gi,"").trim();b=b?`${b}

${nt}`:nt}l&&(P=P.replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi,"").trim())}}const Y=P.match(/<v-click[^>]*>|<v-clicks[^>]*>|v-click=/g);Y&&(x+=Y.length);const Z=P.match(/```\w+\s+\{[^}]+\}/g);Z&&(A+=Z.length);const Q=P.match(/::\w+::|<template\s+#[^>]+>/g);if(Q&&(T+=Q.length),P=P.replace(/^[ \t]*<<<[ \t]+([^\n\r]+)/gm,rt=>Y1(rt,{...i,virtualFiles:c})||rt),n&&(P=P.replace(/<v-click(?:\s+at="[^"]*")?(?:\s+hide)?>\s*([\s\S]*?)\s*<\/v-click>/gi,"$1")),o&&(P=P.replace(/(^```\w+(?:[ \t]+\[[^\]]*\])?)[ \t]+\{[^}]+\}(?:[ \t]+\w+)?/gm,"$1"),P=P.replace(/^\$\$\s+\{[^}]+\}/gm,()=>"$$")),s&&(P=P.replace(/^::\w+::\s*$/gm,"")),r&&(P=Zu(P)),a){let rt=P.trim(),gt="";const nt=rt.lastIndexOf("> [!NOTE] 💡 演讲备注");if(nt!==-1&&(gt=rt.slice(nt),rt=rt.slice(0,nt).trim()),($.layout==="image-left"||$.layout==="image-right")&&$.image){const E=String($.image).trim(),z=$.layout==="image-left"?"image-left":"image-right",p=`![配图](${E})
{: custom-slidev-layout="${z}" }`;$.layout==="image-left"?rt=`{{{col

${p}

${rt}

}}}`:rt=`{{{col

${rt}

${p}

}}}`}if($.background){const z=`![背景图](${String($.background).trim()})
{: custom-slidev-role="background" }`;rt=rt?`${z}

${rt}`:z}P=gt?`${rt}

${gt}`:rt}const D=tb(P);X[Ut]&&D.push(X[Ut]),X[Ee]&&D.push(X[Ee]);for(const rt of D)I.add(rt);const dt=/<[A-Z][a-zA-Z0-9]+/.test(P),lt=X[mt]||(N===1?g[mt]||"cover":"default");w[lt]=(w[lt]||0)+1,k.push({pageIndex:N++,pageAttrs:X,notes:tt,rawMarkdown:P,hasVueComponent:dt,hasStyleTag:M,assetReferences:D})}if(!d&&k.length>0){const j=k[0].rawMarkdown.match(/^#\s+(.+)$/m);j&&(d=j[1].trim())}b&&(g["custom-slidev-custom-css"]=b);let F=k.map(j=>`---

${j.rawMarkdown}`).join(`

`);return F.trimStart().startsWith("---")||(F=`---

${F.trimStart()}`),{docTitle:d||"Slidev 演示文稿",docRootAttrs:g,slides:k,totalSlides:k.length,stats:{totalNotes:S,totalVClicks:x,totalShikiHighlights:A,totalSlots:T,discoveredAssets:Array.from(I),layoutDistribution:w},flattenedMarkdown:F,customCss:b}}function tb(t){const i=[],e=/!\[.*?\]\((.*?)\)/g;let n;for(;(n=e.exec(t))!==null;){const s=n[1].split(/\s+/)[0].trim();s&&i.push(s)}const o=/<(?:img|video|source|audio)\b[^>]*src=["'](.*?)["']/gi;for(;(n=o.exec(t))!==null;){const s=n[1].trim();s&&i.push(s)}return i}function ga(t){if(!t)return!1;const i=String(t.type||"").toLowerCase(),e=String(t.markdown||"").trim(),n=String(t.content||"").trim();return i==="tb"||i==="thematic-break"||i==="nodethematicbreak"||e==="---"||e==="***"||n==="---"||n==="***"}function eb(t){return(t.trim()||"Slidev 演示文稿").replace(/[\\/:*?"<>|]/g,"_")}async function ib(t,i,e=Et){const n=t.filter(ga);let o=0;if(n.length>=i.length)for(let s=0;s<i.length;s++){const l=i[s],r=n[s];r&&r.id&&Object.keys(l.pageAttrs||{}).length>0&&(await e(r.id,l.pageAttrs),o++)}else for(let s=1;s<i.length;s++){const l=i[s],r=n[s-1];r&&r.id&&Object.keys(l.pageAttrs||{}).length>0&&(await e(r.id,l.pageAttrs),o++)}return o}async function nb(t,i=Et){let e=!1,n=0;for(const o of t){if(ga(o)){e=!1;continue}const s=(o.markdown||o.content||"").trim();if(s==="::right::"||s.startsWith("::right::")){e=!0;continue}e&&o.id&&(await i(o.id,{[Ct]:"right"}).catch(()=>{}),n++)}return n}async function ob(t,i,e=zr){const n={};if(!i||i.length===0)return n;const o=[];for(const s of i){const l=new File([s.data],s.fileName,{type:"application/octet-stream"});o.push(l)}try{const s=await e("/data/assets",o);if(s!=null&&s.succMap)for(const[l,r]of Object.entries(s.succMap))n[l]=String(r)}catch(s){console.warn("上传本地静态资产失败，保留原路径:",s)}return Object.keys(n).length>0&&Z1(t,n),n}async function sb(t){var A;const{presentation:i,notebookId:e,docTitle:n,extractedAssets:o=[],uploadAssets:s=!0,autoPreview:l=!0,plugin:r,api:a={}}=t,c=a.uploadFn||zr,u=a.createDocFn||nc,m=a.setAttrsFn||Et,g=a.getChildBlocksFn||no,d=a.openTabFn||ht.openTab,b=a.showMessageFn||ht.showMessage;s&&o.length>0&&await ob(i,o,c);const f=eb(n),v=`/${f}`,k=await u(e,v,i.flattenedMarkdown);if(!k)throw new Error("思源内核创建文档失败，未返回有效 DocumentId");const S=((A=i.slides[0])==null?void 0:A.pageAttrs)||{};await m(k,{...S,...i.docRootAttrs});const x=await g(k).catch(()=>[]);return Array.isArray(x)&&x.length>0&&(await ib(x,i.slides,m),await nb(x,m)),b(`🎉 成功导入 Slidev 演示文档《${f}》！`),l&&r&&(r.currentDocId=k,await d({app:r.app,doc:{id:k}}),r.openBottomPreviewTab&&r.openBottomPreviewTab()),k}function rb(t){const i=vt("file"),e=vt(!1),n=vt(!1),o=vt(""),s=vt(null),l=vt(null),r=vt(""),a=vt(0),c=vt(""),u=vt([]),m=vt(null),g=vt(""),d=vt([]),b=vt(""),f=vt(!0),v=vt(!0),k=vt(!0),S=vt(!0),x=St(()=>{const X=a.value;if(X===0)return"0 B";const P=1024,U=["B","KB","MB","GB"],W=Math.floor(Math.log(X)/Math.log(P));return`${(X/P**W).toFixed(1)} ${U[W]}`}),A=St(()=>{var X;return((X=m.value)==null?void 0:X.docRootAttrs["custom-slidev-theme"])||"default"}),T=St(()=>{var X;return u.value.length>0?u.value.length:((X=m.value)==null?void 0:X.stats.discoveredAssets.length)||0}),I=St(()=>{var P;const X=((P=m.value)==null?void 0:P.stats.layoutDistribution)||{};return Object.entries(X).map(([U,W])=>({name:U,count:W}))});async function w(X=ic){try{const P=await X();P!=null&&P.notebooks&&Array.isArray(P.notebooks)&&(d.value=P.notebooks.filter(U=>!U.closed),d.value.length>0&&!b.value&&(b.value=d.value[0].id))}catch(P){console.warn("获取笔记本列表失败:",P)}}function N(){var X;(X=s.value)==null||X.click()}function F(){l.value=null,r.value="",a.value=0,m.value=null,u.value=[],o.value=""}async function j(X){o.value="",l.value=X,r.value=X.name,a.value=X.size;try{if(X.name.toLowerCase().endsWith(".zip")){const U=await X.arrayBuffer(),W=await G1(U);if(!W.entryMarkdown){o.value="未在 Zip 压缩包中找到 slides.md 或任何有效的 Markdown 入口文件";return}u.value=W.assets;const tt=eo(W.entryMarkdown,{stripNotesFromMarkdown:v.value,cleanHtmlToMarkdown:f.value,cleanSlots:!1,virtualFiles:W.virtualFiles});m.value=tt,g.value=tt.docTitle||X.name.replace(/\.zip$/i,"")}else{const U=await X.text();u.value=[];const W=X.path||"",tt=W?W.replace(/[\\/][^\\/]+$/,""):"",B=eo(U,{stripNotesFromMarkdown:v.value,cleanHtmlToMarkdown:f.value,cleanSlots:!1,baseDir:tt||void 0});m.value=B,g.value=B.docTitle||X.name.replace(/\.md$/i,"")}}catch(P){console.error("解析文件失败:",P),o.value=`解析文件失败: ${P.message||String(P)}`}}function J(){if(o.value="",!c.value.trim()){m.value=null;return}try{const X=eo(c.value,{stripNotesFromMarkdown:v.value,cleanHtmlToMarkdown:f.value,cleanSlots:!1});m.value=X,g.value=X.docTitle||"Slidev 演示文稿"}catch(X){o.value=`解析 Markdown 源码失败: ${X.message||String(X)}`}}async function $(){l.value?await j(l.value):c.value&&J()}async function O(X){const P=X.target;P.files&&P.files[0]&&await j(P.files[0])}async function y(X){var P;e.value=!1,(P=X.dataTransfer)!=null&&P.files&&X.dataTransfer.files[0]&&await j(X.dataTransfer.files[0])}async function V(X=t){if(m.value){if(!b.value&&d.value.length>0&&(b.value=d.value[0].id),!b.value){o.value="请先选择目标笔记本";return}n.value=!0,o.value="";try{return await sb({presentation:m.value,notebookId:b.value,docTitle:g.value,extractedAssets:u.value,uploadAssets:k.value,autoPreview:S.value,plugin:X})}catch(P){console.error("导入 Slidev 演示失败:",P),o.value=`导入执行失败: ${P.message||String(P)}`}finally{n.value=!1}}}return{inputMode:i,isDragging:e,isImporting:n,errorMessage:o,fileInputRef:s,selectedFile:l,selectedFileName:r,selectedFileSize:a,rawMarkdownText:c,extractedAssets:u,parsedPresentation:m,customDocTitle:g,notebooks:d,selectedNotebookId:b,optCleanHtml:f,optStripNotes:v,optUploadAssets:k,optAutoPreview:S,formattedFileSize:x,currentTheme:A,extractedAssetsCount:T,layoutChips:I,fetchNotebooks:w,triggerFileInput:N,clearFile:F,processFile:j,onFileSelected:O,onFileDrop:y,onTextChange:J,reprocessCurrentInput:$,handleConfirmImport:V}}const lb={class:"spm-import-dialog"},ab={class:"spm-tabs-header"},cb={class:"spm-dialog-body"},db={key:0,class:"spm-file-section"},ub={key:0,class:"spm-dropzone-prompt"},fb={class:"spm-dropzone-icon"},pb={key:1,class:"spm-dropzone-active"},hb={class:"spm-file-badge"},mb={class:"spm-file-size"},gb={key:1,class:"spm-text-section"},vb={key:2,class:"spm-error-banner"},bb={key:3,class:"spm-preview-card"},yb={class:"spm-preview-card__header"},kb={style:{display:"inline-flex","align-items":"center",gap:"4px"}},wb={class:"spm-config-grid"},xb={class:"spm-form-item"},Sb={class:"spm-form-item"},_b=["value"],Cb={class:"spm-stats-grid"},$b={class:"spm-stat-box"},Ib={class:"spm-stat-value"},Ab={class:"spm-stat-box"},Bb={class:"spm-stat-value"},Tb={class:"spm-stat-box"},Eb={class:"spm-stat-value"},Mb={class:"spm-stat-box"},Lb={class:"spm-stat-value"},Db={key:0,class:"spm-chips-row"},Pb={class:"spm-options-group"},Ob={class:"spm-checkbox-label"},Rb={class:"spm-checkbox-label"},zb={class:"spm-checkbox-label"},Nb={class:"spm-checkbox-label"},Fb={class:"spm-dialog-footer"},Hb=["disabled"],jb=["disabled"],Ub={key:0,style:{display:"inline-flex","align-items":"center",gap:"4px"}},Wb={key:1,style:{display:"inline-flex","align-items":"center",gap:"4px"}},Vb=_e({__name:"SlidevImportDialog",emits:["close","success"],setup(t,{emit:i}){const e=i,n=ei("plugin"),{inputMode:o,isDragging:s,isImporting:l,errorMessage:r,fileInputRef:a,selectedFileName:c,rawMarkdownText:u,extractedAssetsCount:m,parsedPresentation:g,customDocTitle:d,notebooks:b,selectedNotebookId:f,optCleanHtml:v,optStripNotes:k,optUploadAssets:S,optAutoPreview:x,formattedFileSize:A,currentTheme:T,layoutChips:I,fetchNotebooks:w,triggerFileInput:N,clearFile:F,onFileSelected:j,onFileDrop:J,onTextChange:$,reprocessCurrentInput:O,handleConfirmImport:y}=rb(n);Rn(async()=>{await w()});async function V(){const P=await y();P&&(e("success",{docId:P}),e("close"))}function X(){e("close")}return(P,U)=>(ot(),st("div",{class:"spm-modal-overlay",onClick:Me(X,["self"])},[h("div",lb,[h("div",{class:"spm-dialog-header"},[U[18]||(U[18]=h("div",{class:"spm-dialog-title"},[h("svg",{class:"spm-dialog-icon","aria-hidden":"true"},[h("use",{"xlink:href":"#iconSlidev"})]),h("span",null,"导入 Slidev 演示文档")],-1)),h("button",{class:"spm-close-btn",title:"关闭",onClick:X},"✕")]),h("div",ab,[h("button",{class:At(["spm-tab-btn",{active:bt(o)==="file"}]),onClick:U[0]||(U[0]=W=>o.value="file")},[ut(ft,{name:"package"}),U[19]||(U[19]=h("span",null,"文件 / 压缩包导入 (.zip / .md)",-1))],2),h("button",{class:At(["spm-tab-btn",{active:bt(o)==="text"}]),onClick:U[1]||(U[1]=W=>o.value="text")},[ut(ft,{name:"notes"}),U[20]||(U[20]=h("span",null,"粘贴 Markdown 源码",-1))],2)]),h("div",cb,[bt(o)==="file"?(ot(),st("div",db,[h("div",{class:At(["spm-dropzone",{dragover:bt(s),"has-file":!!bt(c)}]),onDragover:U[4]||(U[4]=Me(W=>s.value=!0,["prevent"])),onDragleave:U[5]||(U[5]=Me(W=>s.value=!1,["prevent"])),onDrop:U[6]||(U[6]=Me((...W)=>bt(J)&&bt(J)(...W),["prevent"])),onClick:U[7]||(U[7]=(...W)=>bt(N)&&bt(N)(...W))},[h("input",{ref_key:"fileInputRef",ref:a,type:"file",accept:".zip,.md",class:"spm-hidden-input",onChange:U[2]||(U[2]=(...W)=>bt(j)&&bt(j)(...W))},null,544),bt(c)?(ot(),st("div",pb,[h("span",hb,[ut(ft,{name:"notes"}),Ae(" "+_t(bt(c)),1)]),h("span",mb,"("+_t(bt(A))+")",1),h("button",{class:"spm-btn-text",onClick:U[3]||(U[3]=Me((...W)=>bt(F)&&bt(F)(...W),["stop"]))},"更换文件")])):(ot(),st("div",ub,[h("span",fb,[ut(ft,{name:"folder",style:{"font-size":"32px"}})]),U[21]||(U[21]=h("p",{class:"spm-dropzone-text"},"点击选择文件，或直接拖拽文件至此处",-1)),U[22]||(U[22]=h("p",{class:"spm-dropzone-hint"},[Ae(" 支持 Slidev 完整工程 "),h("strong",null,".zip"),Ae("（自动解包 public/ 静态素材）或单文件 "),h("strong",null,".md")],-1))]))],34)])):(ot(),st("div",gb,[Te(h("textarea",{"onUpdate:modelValue":U[8]||(U[8]=W=>Jt(u)?u.value=W:null),class:"spm-textarea spm-source-editor",rows:"8",placeholder:"在此直接粘贴包含 Frontmatter 的 Slidev slides.md 源码...",onInput:U[9]||(U[9]=(...W)=>bt($)&&bt($)(...W))},null,544),[[vo,bt(u)]])])),bt(r)?(ot(),st("div",vb," ⚠️ "+_t(bt(r)),1)):Ot("",!0),bt(g)?(ot(),st("div",bb,[h("div",yb,[h("span",kb,[ut(ft,{name:"sparkles"}),U[23]||(U[23]=Ae(" 演示解析摘要",-1))]),U[24]||(U[24]=h("span",{class:"spm-badge-success"},"预检就绪",-1))]),h("div",wb,[h("div",xb,[U[25]||(U[25]=h("label",{class:"spm-form-label"},"笔记文档标题",-1)),Te(h("input",{"onUpdate:modelValue":U[10]||(U[10]=W=>Jt(d)?d.value=W:null),class:"spm-input",placeholder:"思源新文档标题"},null,512),[[vo,bt(d)]])]),h("div",Sb,[U[26]||(U[26]=h("label",{class:"spm-form-label"},"存放目标笔记本",-1)),Te(h("select",{"onUpdate:modelValue":U[11]||(U[11]=W=>Jt(f)?f.value=W:null),class:"spm-select"},[(ot(!0),st(Kt,null,xe(bt(b),W=>(ot(),st("option",{key:W.id,value:W.id},_t(W.name),9,_b))),128))],512),[[Bu,bt(f)]])])]),h("div",Cb,[h("div",$b,[h("span",Ib,_t(bt(g).totalSlides),1),U[27]||(U[27]=h("span",{class:"spm-stat-label"},"幻灯片页数",-1))]),h("div",Ab,[h("span",Bb,_t(bt(T)),1),U[28]||(U[28]=h("span",{class:"spm-stat-label"},"演示主题",-1))]),h("div",Tb,[h("span",Eb,_t(bt(g).stats.totalNotes),1),U[29]||(U[29]=h("span",{class:"spm-stat-label"},"演讲者提词",-1))]),h("div",Mb,[h("span",Lb,_t(bt(m)),1),U[30]||(U[30]=h("span",{class:"spm-stat-label"},"关联本地素材",-1))])]),bt(I).length>0?(ot(),st("div",Db,[U[31]||(U[31]=h("span",{class:"spm-chips-label"},"页面版式分布：",-1)),(ot(!0),st(Kt,null,xe(bt(I),W=>(ot(),st("span",{key:W.name,class:"spm-chip-badge"},_t(W.name)+": "+_t(W.count),1))),128))])):Ot("",!0),h("div",Pb,[h("label",Ob,[Te(h("input",{"onUpdate:modelValue":U[12]||(U[12]=W=>Jt(v)?v.value=W:null),type:"checkbox",onChange:U[13]||(U[13]=(...W)=>bt(O)&&bt(O)(...W))},null,544),[[Kn,bt(v)]]),U[32]||(U[32]=h("span",null,"智能剥离展示型 HTML 容器为干净原生的 Markdown 笔记块",-1))]),h("label",Rb,[Te(h("input",{"onUpdate:modelValue":U[14]||(U[14]=W=>Jt(k)?k.value=W:null),type:"checkbox",onChange:U[15]||(U[15]=(...W)=>bt(O)&&bt(O)(...W))},null,544),[[Kn,bt(k)]]),U[33]||(U[33]=h("span",null,"提取演讲者提词到块属性并保持正文笔记清爽",-1))]),h("label",zb,[Te(h("input",{"onUpdate:modelValue":U[16]||(U[16]=W=>Jt(S)?S.value=W:null),type:"checkbox"},null,512),[[Kn,bt(S)]]),U[34]||(U[34]=h("span",null,"自动上传关联素材至思源资产库并重写路径 (assets/...)",-1))]),h("label",Nb,[Te(h("input",{"onUpdate:modelValue":U[17]||(U[17]=W=>Jt(x)?x.value=W:null),type:"checkbox"},null,512),[[Kn,bt(x)]]),U[35]||(U[35]=h("span",null,"导入后自动打开新文档并开启下方分屏放映预览",-1))])])])):Ot("",!0)]),h("div",Fb,[h("button",{class:"spm-btn-secondary",disabled:bt(l),onClick:X}," 取消 ",8,Hb),h("button",{class:"spm-btn-primary",disabled:!bt(g)||bt(l),onClick:V},[bt(l)?(ot(),st("span",Ub,[ut(ft,{name:"refresh"}),U[36]||(U[36]=Ae(" 正在导入生成中...",-1))])):(ot(),st("span",Wb,[ut(ft,{name:"rocket"}),U[37]||(U[37]=Ae(" 确认导入思源笔记",-1))]))],8,jb)])])]))}}),qb=ze(Vb,[["__scopeId","data-v-ce8dffdc"]]);function va(t){return t?t==="NodeThematicBreak"||t==="tb"||t==="thematic-break":!1}function Kb(t,i){var r;if(!t||t.length===0)return null;const e=i.activeBlockId||"",n=i.currentTopBlockId||e,o=i.currentPageDividerId||"",s=i.activeBlockType||"";if(va(s)&&e){let a=t.find(c=>c.startBlockId===e);if(a||(a=t.find(c=>{var u,m;return((m=(u=c.blocks)==null?void 0:u[0])==null?void 0:m.id)===e}),a)||(a=t.find(c=>{var u;return(u=c.allBlockIds)==null?void 0:u.includes(e)}),a))return a}if(o){let a=t.find(c=>c.startBlockId===o);if(a||(a=t.find(c=>{var u,m;return((m=(u=c.blocks)==null?void 0:u[0])==null?void 0:m.id)===o}),a))return a}if(e){let a=t.find(u=>u.startBlockId===e);if(a||(a=t.find(u=>{var m,g;return((m=u.blocks)==null?void 0:m.some(d=>d.id===e))||((g=u.allBlockIds)==null?void 0:g.includes(e))}),a)||n&&n!==e&&(a=t.find(u=>{var m,g;return((m=u.blocks)==null?void 0:m.some(d=>d.id===n))||((g=u.allBlockIds)==null?void 0:g.includes(n))}),a)||(a=t.find(u=>{var m;return(m=u.noteBlocks)==null?void 0:m.some(g=>g.id===e||g.id===n)}),a))return a;const c=(r=i.activeBlockAttrs)==null?void 0:r[Ct];if(c&&["col-1","col-2","col-3"].includes(c)&&(a=t.find(u=>{var m,g;return((m=u.frontmatter)==null?void 0:m.layout)==="three-cols-header"||((g=u.blocks)==null?void 0:g.some(d=>d.slot==="col-1"||d.slot==="col-2"||d.slot==="col-3"))}),a))return a}return t[0]||null}function Dr(t,i){const e=(t.blocks||[]).filter(l=>{const r=(l.content||l.rawMarkdown||"").trim();return r&&r!=="---"});if(e.length===0)return"本页暂无内容，建议过渡承接上下文。";const n=[],o=[];for(const l of e){const r=(l.content||l.rawMarkdown||"").trim();r&&(l.type==="h"||r.startsWith("#")?n.push(r.replace(/^#+\s*/,"")):o.push(r.slice(0,50)))}const s=[];return n.length>0&&s.push(`【核心重点】：${n.join("、")}`),o.length>0&&(s.push("【口播要点】："),o.slice(0,3).forEach((l,r)=>{s.push(`${r+1}. 讲解 ${l}`)})),s.push("【过渡提示】：注意观察听众反应，适时抛出互动提问。"),s.join(`
`)}async function ba(t,i){const e=t.blocks&&t.blocks.length>0?t.blocks.map(n=>(n.content||n.rawMarkdown||"").trim()).filter(n=>n&&n!=="---").join(`
`):(t.rawMarkdown||"").replace(/^---\s*$/gm,"").trim();if(i&&e){const n=`你是一位专业的演讲教练。请根据以下幻灯片内容，提炼出简短精炼的演讲口播提词卡（Notes），包含核心观点与口播要点，总字数在 150 字以内：
${e}`;try{const o=await i(n);if(o&&o.trim())return{notes:o.trim(),isAiGenerated:!0}}catch(o){return{notes:Dr(t),isAiGenerated:!1,error:(o==null?void 0:o.message)||"AI 调用异常"}}}return{notes:Dr(t),isAiGenerated:!1}}async function Gb(t,i){return(await ba(t,i)).notes}function Pr(t,i){if(!i)return!1;if(t===i||typeof document>"u")return!0;const e=document.querySelector(`.protyle-wysiwyg [data-node-id="${i}"]`)||document.querySelector(`[data-node-id="${i}"]`);if(!e)return!1;const n=e.querySelector(":scope > [data-node-id], :scope > div > [data-node-id]");return(n==null?void 0:n.getAttribute("data-node-id"))===t}function Zb(t){const i=vt(!1);let e=null;function n(B="已同步"){t.saveStatus.value=B,e&&(typeof window<"u"?window.clearTimeout(e):clearTimeout(e));const M=()=>{t.saveStatus.value=""};typeof window<"u"?e=window.setTimeout(M,1200):e=setTimeout(M,1200)}async function o(B){var Q;const M=t.activeBlockId.value||t.currentDocId.value;if(!M)return;for(const[D,dt]of Object.entries(B))t.activeBlockAttrs.value[D]=dt;Lt.setBlockAttrOverride(M,B),Zt(M,B);const Y=(Q=t.parentContainerId)==null?void 0:Q.value,Z=!!(Y&&Pr(M,Y));if(jt in B&&Z&&Y){const D=B[jt];t.parentContainerClicks&&(t.parentContainerClicks.value=D),Lt.setBlockAttrOverride(Y,{[jt]:D}),Zt(Y,{[jt]:D}),Et(Y,{[jt]:D}).catch(()=>{})}if(mt in B){const D=B[mt];t.currentPageDividerLayout.value=D,t.targetSlide.value&&(t.targetSlide.value.frontmatter||(t.targetSlide.value.frontmatter={}),t.targetSlide.value.frontmatter.layout=D)}if(le in B){const D=B[le];t.targetSlide.value&&(t.targetSlide.value.frontmatter||(t.targetSlide.value.frontmatter={}),t.targetSlide.value.frontmatter.layoutRatio=D)}n("保存中...");try{await Et(M,B),n("已同步"),t.plugin&&await t.plugin.compileCurrentDocument()}catch{n("同步失败")}}async function s(B,M){var D;const Y=t.activeBlockId.value||t.currentDocId.value;if(!Y)return;t.activeBlockAttrs.value[B]=M,Lt.setBlockAttrOverride(Y,{[B]:M}),Zt(Y,{[B]:M});const Z=(D=t.parentContainerId)==null?void 0:D.value,Q=!!(Z&&Pr(Y,Z));B===jt&&Q&&Z&&(t.parentContainerClicks&&(t.parentContainerClicks.value=M),Lt.setBlockAttrOverride(Z,{[jt]:M}),Zt(Z,{[jt]:M}),Et(Z,{[jt]:M}).catch(()=>{})),B===mt&&(t.currentPageDividerLayout.value=M,t.targetSlide.value&&(t.targetSlide.value.frontmatter||(t.targetSlide.value.frontmatter={}),t.targetSlide.value.frontmatter.layout=M)),B===le&&t.targetSlide.value&&(t.targetSlide.value.frontmatter||(t.targetSlide.value.frontmatter={}),t.targetSlide.value.frontmatter.layoutRatio=M),n("保存中...");try{await Et(Y,{[B]:M}),n("已同步"),t.plugin&&await t.plugin.compileCurrentDocument()}catch{n("同步失败")}}function l(){const B=t.activeBlockType.value==="NodeThematicBreak"||t.activeBlockType.value==="NodeThematicBreakBlock"||t.activeBlockType.value==="hr"||t.activeBlockType.value==="thematicbreak";return t.currentPageDividerId.value||(B?t.activeBlockId.value:"")||t.currentDocId.value}async function r(B,M){const Y=l();if(Y){Y===t.activeBlockId.value&&(t.activeBlockAttrs.value[B]=M),Lt.setBlockAttrOverride(Y,{[B]:M}),Zt(Y,{[B]:M}),B===mt&&(t.currentPageDividerLayout.value=M,t.targetSlide.value&&(t.targetSlide.value.frontmatter||(t.targetSlide.value.frontmatter={}),t.targetSlide.value.frontmatter.layout=M)),B===le&&t.targetSlide.value&&(t.targetSlide.value.frontmatter||(t.targetSlide.value.frontmatter={}),t.targetSlide.value.frontmatter.layoutRatio=M),n("保存中...");try{await Et(Y,{[B]:M}),n("已同步"),t.plugin&&await t.plugin.compileCurrentDocument()}catch{n("同步失败")}}}async function a(B,M){const Y=l();if(!Y)return;const Z={[mt]:B,[le]:M};Y===t.activeBlockId.value&&(t.activeBlockAttrs.value[mt]=B,t.activeBlockAttrs.value[le]=M),t.currentPageDividerLayout.value=B,Lt.setBlockAttrOverride(Y,Z),Zt(Y,Z),t.targetSlide.value&&(t.targetSlide.value.frontmatter||(t.targetSlide.value.frontmatter={}),t.targetSlide.value.frontmatter.layout=B,t.targetSlide.value.frontmatter.layoutRatio=M),n("应用排版中...");try{await Et(Y,Z),n("已应用分栏与比例"),t.plugin&&await t.plugin.compileCurrentDocument()}catch{n("应用失败")}}async function c(B,M){var Z;const Y=t.currentDocId.value||t.activeBlockId.value;if(Y){t.activeBlockAttrs.value[B]=M,Lt.setBlockAttrOverride(Y,{[B]:M}),Zt(Y,{[B]:M}),(Z=t.latestDoc.value)!=null&&Z.config&&(B===xn&&(t.latestDoc.value.config.theme=M),B===Sn&&(t.latestDoc.value.config.aspectRatio=M),B===_n&&(t.latestDoc.value.config.defaultTransition=M)),n("更新中...");try{await Et(Y,{[B]:M}),n("已更新"),t.plugin&&await t.plugin.compileCurrentDocument(Y)}catch{n("更新失败")}}}async function u(){(t.videoAutoplay.value?"false":"true")==="true"?(await o({[Ti]:"true",[Ui]:"true"}),t.activeBlockAttrs.value[Ti]="true",t.activeBlockAttrs.value[Ui]="true"):(await s(Ti,"false"),t.activeBlockAttrs.value[Ti]="false")}async function m(){const B=t.videoLoop.value?"false":"true";await s(oo,B)}async function g(){const B=t.videoMuted.value?"false":"true";await s(Ui,B)}async function d(){const B=t.videoControls.value?"false":"true";await s(so,B)}async function b(B){var D;const M=t.activeBlockId.value;if(!M)return;const Y=t.rawSnippet.value||"",Z=bi(Y)||"",Q=t.currentPageDividerId.value||t.currentDocId.value;if(B)if(B==="background"){const dt={[qt]:"background",[mt]:""};Q&&Z&&(t.pageBackground.value=Z,await Et(Q,{[Ut]:Z}).catch(()=>{}),Lt.setBlockAttrOverride(Q,{[Ut]:Z}),Zt(Q,{[Ut]:Z}),t.targetSlide.value&&(t.targetSlide.value.frontmatter||(t.targetSlide.value.frontmatter={}),t.targetSlide.value.frontmatter.background=Z)),await o(dt)}else(B===ro||B===lo)&&await o({[mt]:B,[qt]:""});else{const dt={[qt]:"",[mt]:""};if(t.activeBlockAttrs.value[Ut]==="true"&&(dt[Ut]=""),Q&&Z&&t.pageBackground.value===Z&&(t.pageBackground.value="",await Et(Q,{[Ut]:""}).catch(()=>{}),Lt.setBlockAttrOverride(Q,{[Ut]:""}),Zt(Q,{[Ut]:""}),(D=t.targetSlide.value)!=null&&D.frontmatter&&delete t.targetSlide.value.frontmatter.background),await o(dt),typeof document<"u"){const lt=document.querySelector(`.protyle-wysiwyg [data-node-id="${M}"]`),rt=lt==null?void 0:lt.closest('[data-type="NodeListItem"]'),gt=rt==null?void 0:rt.getAttribute("data-node-id");if(gt&&gt!==M){const nt={[mt]:"",[qt]:""};Zt(gt,nt),Lt.setBlockAttrOverride(gt,nt),await Et(gt,nt).catch(()=>{})}}}}async function f(B){var gt,nt,E,z,p,H,R,_;const Z=`> [!NOTE] 💡 演讲备注
${(B||"在此输入本页讲稿提词...").split(/\r?\n/).map(C=>`> ${C}`).join(`
`)}
{: custom-slidev-note="true"}`,Q=((gt=t.latestDoc.value)==null?void 0:gt.slides)||[],D=t.targetSlide.value,dt=D?Q.findIndex(C=>C===D):-1;let lt=null;if(dt!==-1&&dt<Q.length-1){const C=Q[dt+1];lt=await Ii("markdown",Z,C.startBlockId)}else{const C=((nt=D==null?void 0:D.noteBlocks)==null?void 0:nt.slice(-1)[0])||((E=D==null?void 0:D.blocks)==null?void 0:E.slice(-1)[0]),L=(C==null?void 0:C.id)||(D==null?void 0:D.startBlockId);L?lt=await Ii("markdown",Z,void 0,L):lt=await Xo("markdown",Z,t.currentDocId.value)}const rt=((H=(p=(z=lt==null?void 0:lt[0])==null?void 0:z.doOperations)==null?void 0:p[0])==null?void 0:H.id)||((R=lt==null?void 0:lt[0])==null?void 0:R.id);return rt&&(await Et(rt,{[ne]:"true"}),Lt.setBlockAttrOverride(rt,{[ne]:"true"}),Pi(rt,(_=t.plugin)==null?void 0:_.app)),t.plugin&&await t.plugin.compileCurrentDocument(),rt}async function v(){const B=t.activeBlockId.value;if(B)if(t.isNoteBlock.value){n("取消中...");try{await Et(B,{[ne]:"","slidev-note":""}),Lt.setBlockAttrOverride(B,{[ne]:"","slidev-note":""}),Zt(B,{[ne]:"","slidev-note":""}),delete t.activeBlockAttrs.value[ne],delete t.activeBlockAttrs.value["slidev-note"],n("已取消备注"),ht.showMessage("已取消讲稿备注"),t.plugin&&await t.plugin.compileCurrentDocument()}catch(M){console.error("[SiYuanSlidev] 取消讲稿备注失败:",M),n("取消失败"),ht.showMessage("取消讲稿备注失败")}}else{n("转换中...");try{let M=t.rawSnippet.value;try{const D=await oc(B);D!=null&&D.kramdown&&(M=D.kramdown)}catch{}const Q=`> [!NOTE] 💡 演讲备注
${(na(M)||M.replace(/<[^>]+>/g,"").trim()||"在此输入本页讲稿提词...").split(/\r?\n/).map(D=>`> ${D}`).join(`
`)}
{: custom-slidev-note="true"}`;await Ks("markdown",Q,B),await Et(B,{[ne]:"true"}),Lt.setBlockAttrOverride(B,{[ne]:"true"}),Zt(B,{[ne]:"true"}),t.activeBlockAttrs.value[ne]="true",t.activeBlockType.value="NodeCallout",n("已设为讲稿备注"),ht.showMessage("已转为讲稿备注提示块（不在幻灯片中渲染）"),t.plugin&&await t.plugin.compileCurrentDocument()}catch(M){console.error("[SiYuanSlidev] 转换讲稿备注提示块失败:",M),n("设置失败"),ht.showMessage("转为讲稿备注提示块失败")}}}async function k(){try{await f(),ht.showMessage("已在正文末尾插入讲稿备注提示块")}catch(B){ht.showMessage("插入讲稿备注块失败"),console.error(B)}}function S(){var Y;const B=t.currentSlideNoteBlockId.value;if(!B){ht.showMessage("未找到本页关联的讲稿备注块");return}Pi(B,(Y=t.plugin)==null?void 0:Y.app)?ht.showMessage("已在编辑区定位讲稿备注块"):ht.showMessage("定位讲稿备注块失败")}async function x(){var Y;if(!t.currentDocId.value)return;const B=t.targetSlide.value||{startBlockId:t.activeBlockId.value||t.currentDocId.value,blocks:t.rawSnippet.value&&t.rawSnippet.value!=="---"?[{id:t.activeBlockId.value,type:t.activeBlockType.value,content:t.rawSnippet.value,rawMarkdown:""}]:[],rawMarkdown:t.rawSnippet.value&&t.rawSnippet.value!=="---"?t.rawSnippet.value:""};ht.showMessage("正在调用思源 AI 提炼本页讲稿提词...");const M=await ba(B,Nr);if(M.notes){const Z=t.currentSlideNoteBlockId.value;if(Z){const Q=`> [!NOTE] 💡 演讲备注
${M.notes.split(/\r?\n/).map(D=>`> ${D}`).join(`
`)}
{: custom-slidev-note="true"}`;await Ks("markdown",Q,Z),await Et(Z,{[ne]:"true"}),Lt.setBlockAttrOverride(Z,{[ne]:"true"}),Pi(Z,(Y=t.plugin)==null?void 0:Y.app)}else await f(M.notes);M.isAiGenerated?ht.showMessage("思源 AI 演讲提词卡生成成功！"):ht.showMessage("未获取到思源 AI 响应，已生成预设提词卡模板",5e3),t.plugin&&await t.plugin.compileCurrentDocument()}}async function A(){var Z;if(i.value)return;const B=((Z=t.latestDoc.value)==null?void 0:Z.slides)||[];if(B.length===0){ht.showMessage("当前文档无幻灯片页面");return}const M=B.map((Q,D)=>({slide:Q,idx:D})).filter(({slide:Q})=>{var lt;const D=Array.isArray(Q.noteBlocks)&&Q.noteBlocks.length>0,dt=!!((lt=Q.notes)!=null&&lt.trim());return!D&&!dt});if(M.length===0){ht.showMessage("所有幻灯片页面均已存在讲稿备注块，无需追加");return}const Y=M.length;ht.confirm("批量追加讲稿备注",`将在未配置讲稿的 ${Y} 页末尾自动插入讲稿提示块，是否继续？`,async()=>{var D,dt,lt,rt,gt,nt;if(i.value)return;i.value=!0,ht.showMessage("正在批量追加讲稿块...");let Q=0;try{const p=`> [!NOTE] 💡 演讲备注
${"在此输入本页讲稿提词...".split(/\r?\n/).map(H=>`> ${H}`).join(`
`)}
{: custom-slidev-note="true"}`;for(const{slide:H,idx:R}of M)try{let _=null;if(R<B.length-1){const L=B[R+1];_=await Ii("markdown",p,L.startBlockId)}else{const L=((D=H==null?void 0:H.noteBlocks)==null?void 0:D.slice(-1)[0])||((dt=H==null?void 0:H.blocks)==null?void 0:dt.slice(-1)[0]),G=(L==null?void 0:L.id)||(H==null?void 0:H.startBlockId);G?_=await Ii("markdown",p,void 0,G):_=await Xo("markdown",p,t.currentDocId.value)}const C=((gt=(rt=(lt=_==null?void 0:_[0])==null?void 0:lt.doOperations)==null?void 0:rt[0])==null?void 0:gt.id)||((nt=_==null?void 0:_[0])==null?void 0:nt.id);C&&(await Et(C,{[ne]:"true"}),Lt.setBlockAttrOverride(C,{[ne]:"true"})),Q++}catch(_){console.error(`[SiYuanSlidev] 为第 ${R+1} 页追加讲稿块失败:`,_)}t.plugin&&await t.plugin.compileCurrentDocument(),ht.showMessage(`已成功为 ${Q} 页追加讲稿备注块`)}catch(E){console.error("[SiYuanSlidev] 批量追加讲稿块失败:",E),ht.showMessage("批量追加讲稿块时出现异常")}finally{i.value=!1}})}async function T(){var Q;if(i.value)return;const B=((Q=t.latestDoc.value)==null?void 0:Q.slides)||[];if(B.length===0){ht.showMessage("当前文档无幻灯片页面");return}const M=[];for(const D of B)if(D.noteBlocks&&D.noteBlocks.length>0)for(const dt of D.noteBlocks)dt.id&&M.push({id:dt.id,pageIndex:D.pageIndex});if(M.length===0){ht.showMessage("当前文档中没有讲稿备注块，无需删除");return}const Y=new Set(M.map(D=>D.pageIndex)).size,Z=M.length;ht.confirm("危险操作：批量删除所有讲稿块",`此操作将从正文中物理删除全部 ${Z} 个讲稿备注块（涉及 ${Y} 页），删除后无法撤销。是否确认继续？`,async()=>{if(i.value)return;i.value=!0,ht.showMessage("正在批量删除讲稿块...");let D=0;try{for(const dt of M)try{await Gs(dt.id),Lt.clearBlockAttrOverride(dt.id),D++}catch(lt){console.error(`[SiYuanSlidev] 删除讲稿块 ${dt.id} 失败:`,lt)}t.activeBlockId.value&&M.some(dt=>dt.id===t.activeBlockId.value)&&(delete t.activeBlockAttrs.value[ne],delete t.activeBlockAttrs.value["slidev-note"]),t.plugin&&await t.plugin.compileCurrentDocument(),ht.showMessage(`已成功删除全部 ${D} 个讲稿备注块`)}catch(dt){console.error("[SiYuanSlidev] 批量删除讲稿块失败:",dt),ht.showMessage("批量删除讲稿块时出现异常")}finally{i.value=!1}})}function I(){t.elemClick.value?s(jt,""):s(jt,"+1")}function w(B){s(jt,B)}function N(B){s(Ve,B)}function F(B){(t.activeBlockAttrs.value[Ct]||"")===B?s(Ct,""):s(Ct,B)}function j(B){t.elemShikiLines.value=B,s(Oi,B)}function J(B){t.elemMaxHeight.value=B,s(Cn,B)}async function $(){const B=t.currentSlideLayout.value==="three-cols-header";await s(Ct,B?"col-1":"left"),ht.showMessage(B?"已将当前块设置为第 1 栏 (col-1)":"已将当前块设置为双栏左栏 (left)")}async function O(){const B=t.activeBlockId.value;if(!B)return;const M={[jt]:"",[Ve]:"",[Ct]:"",[Oi]:"",[Cn]:"",[ne]:"","slidev-note":"",[mt]:"",[le]:"",[qt]:"",[te]:"",[Ut]:"",[Ee]:"",[Ti]:"",[oo]:"",[Ui]:"",[so]:""};if(Zt(B,M),await Et(B,M),Lt.clearBlockAttrOverride(B),typeof document<"u"){const Y=document.querySelector(`.protyle-wysiwyg [data-node-id="${B}"]`),Z=Y==null?void 0:Y.closest('[data-type="NodeListItem"]'),Q=Z==null?void 0:Z.getAttribute("data-node-id");Q&&Q!==B&&(Zt(Q,M),await Et(Q,M).catch(()=>{}),Lt.clearBlockAttrOverride(Q))}t.activeBlockAttrs.value={},t.elemShikiLines.value="",t.elemMaxHeight.value="",t.pageBackground.value="",t.pageImage.value="",ht.showMessage("已清除本块演示属性"),t.plugin&&await t.plugin.compileCurrentDocument()}async function y(){if(t.activeBlockId.value)try{await Ii("markdown","---",t.activeBlockId.value,void 0),ht.showMessage("已在上方插入分页符 (---)"),t.plugin&&t.plugin.compileCurrentDocument()}catch{ht.showMessage("插入分页符失败")}}async function V(){const B=t.activeBlockId.value||t.currentDocId.value;if(B)try{await Ii("markdown","---",void 0,B),ht.showMessage("已在下方插入分页符 (---)"),t.plugin&&t.plugin.compileCurrentDocument()}catch{ht.showMessage("插入分页符失败")}}async function X(){if(t.activeBlockId.value)try{await Gs(t.activeBlockId.value),ht.showMessage("已删除该分页符"),t.activeBlockId.value="",t.activeBlockType.value="",t.plugin&&t.plugin.compileCurrentDocument()}catch{ht.showMessage("删除失败")}}function P(){if(!t.latestDoc.value){ht.showMessage("请先在主编辑区打开幻灯片文档");return}const B=fa(t.latestDoc.value);pa("presentation.html",B)&&ht.showMessage("已开始下载单文件离线 HTML 演示包")}function U(){if(!t.latestDoc.value){ht.showMessage("请先在主编辑区打开幻灯片文档");return}ha(t.latestDoc.value)&&ht.showMessage("已唤起打印视窗，请在打印选项中选择「另存为 PDF」")}async function W(){var B,M;try{let Y=null;if(typeof document<"u"){const Q=t.activeBlockId.value;if(Q){const D=document.querySelector(`.protyle-wysiwyg [data-node-id="${Q}"]`);D&&(Y=D.getAttribute("data-type")==="NodeSuperBlock"?D:D.closest('[data-type="NodeSuperBlock"]'))}if(!Y){const D=t.currentPageDividerId.value||(t.activeBlockType.value==="hr"||t.activeBlockType.value==="NodeThematicBreak"?t.activeBlockId.value:"");if(D){const dt=document.querySelector(`.protyle-wysiwyg [data-node-id="${D}"]`);if(dt){let lt=dt.nextElementSibling;for(;lt&&!(lt.getAttribute("data-type")==="NodeThematicBreak"||(B=lt.classList)!=null&&B.contains("protyle-wysiwyg__block--hr"));){const rt=lt.getAttribute("data-type")==="NodeSuperBlock"?lt:lt.querySelector('[data-type="NodeSuperBlock"]');if(rt){Y=rt;break}lt=lt.nextElementSibling}}}else{const dt=document.querySelector('.protyle-wysiwyg [data-type="NodeThematicBreak"], .protyle-wysiwyg .protyle-wysiwyg__block--hr'),lt=Array.from(document.querySelectorAll('.protyle-wysiwyg [data-type="NodeSuperBlock"]'));for(const rt of lt)if(!dt||rt.compareDocumentPosition(dt)&Node.DOCUMENT_POSITION_FOLLOWING){Y=rt;break}}}}const Z=[];if(Y){const Q=Array.from(Y.querySelectorAll(":scope > [data-node-id]"));for(const D of Q){const dt=D.getAttribute("data-node-id");dt&&(Z.push(dt),D.removeAttribute("style"))}}else if((M=t.targetSlide.value)!=null&&M.blocks){for(const Q of t.targetSlide.value.blocks)if(Q.children&&Q.children.length>=2){for(const D of Q.children)D.id&&Z.push(D.id);break}}if(Z.length>0)for(const Q of Z)await Et(Q,{style:""}).catch(()=>{});await r(le,""),ht.showMessage("已重置超级块为平均分布比例"),t.plugin&&await t.plugin.compileCurrentDocument()}catch(Y){console.error("[useInspectorActions] resetSuperBlockWidth error:",Y),ht.showMessage("重置超级块比例失败")}}async function tt(){var B,M,Y;try{let Z=null;if(typeof document<"u"){const D=t.currentPageDividerId.value||(t.activeBlockType.value==="hr"||t.activeBlockType.value==="NodeThematicBreak"?t.activeBlockId.value:""),dt=t.activeBlockId.value;let lt=[];if(D){const nt=document.querySelector(`.protyle-wysiwyg [data-node-id="${D}"]`);if(nt){let E=nt.nextElementSibling;for(;E&&!(E.getAttribute("data-type")==="NodeThematicBreak"||(B=E.classList)!=null&&B.contains("protyle-wysiwyg__block--hr"));)lt.push(E),E=E.nextElementSibling}}else{const nt=document.querySelector('.protyle-wysiwyg [data-type="NodeThematicBreak"], .protyle-wysiwyg .protyle-wysiwyg__block--hr'),E=Array.from(document.querySelectorAll(".protyle-wysiwyg > [data-node-id]"));for(const z of E)if(!nt||z.compareDocumentPosition(nt)&Node.DOCUMENT_POSITION_FOLLOWING)lt.push(z);else break}const rt=[];let gt;for(const nt of lt){const E=nt.getAttribute("data-type");E==="NodeHeading"&&(gt=nt.getAttribute("data-node-id")||void 0);const z=[];E==="NodeSuperBlock"?z.push(nt):z.push(...Array.from(nt.querySelectorAll('[data-type="NodeSuperBlock"]')));for(const p of z){if((p.getAttribute("data-sb-layout")||"").toLowerCase()==="row")continue;const R=p.getAttribute("data-node-id")||"";let _=[];const C=Array.from(p.querySelectorAll('[data-type="NodeListItem"]'));if(C.length===4&&(_=C.map(L=>L.getAttribute("data-node-id")).filter(Boolean)),_.length!==4){const L=Array.from(p.querySelectorAll(":scope > [data-node-id]"));L.length===4&&(_=L.map(G=>G.getAttribute("data-node-id")).filter(Boolean))}_.length===4&&rt.push({sbId:R,itemIds:_,headerId:gt})}}rt.length>0&&(dt&&(Z=rt.find(nt=>{if(nt.sbId===dt||nt.itemIds.includes(dt))return!0;const E=document.querySelector(`.protyle-wysiwyg [data-node-id="${nt.sbId}"]`),z=document.querySelector(`.protyle-wysiwyg [data-node-id="${dt}"]`);return!!(E&&z&&E.contains(z))})||null),Z||(Z=rt[0]))}if(!Z&&((M=t.targetSlide.value)!=null&&M.blocks)){const D=t.targetSlide.value,dt=[];for(const rt of D.blocks)rt.rawNode?dt.push(rt.rawNode):dt.push({id:rt.id,type:rt.type,content:rt.content,markdown:rt.rawMarkdown,children:rt.children,ial:rt.attributes||rt.ial||{}});const lt=Vu(dt,t.activeBlockId.value);lt&&lt.items.length===4&&(Z={sbId:lt.superBlockNode.id,itemIds:lt.items.map(rt=>rt.id),headerId:(Y=lt.headerNode)==null?void 0:Y.id})}if(!Z||Z.itemIds.length!==4)return ht.showMessage("当前页面未找到包含 4 个组件的超级块（需包含 4 个列表项或 4 个子块）",4e3,"info"),!1;const Q=t.currentPageDividerId.value||t.currentDocId.value;Q&&(t.currentPageDividerLayout.value="clover",t.targetSlide.value&&(t.targetSlide.value.frontmatter||(t.targetSlide.value.frontmatter={}),t.targetSlide.value.frontmatter.layout="clover"),Lt.setBlockAttrOverride(Q,{[mt]:"clover"}),Zt(Q,{[mt]:"clover"}),await Et(Q,{[mt]:"clover"}).catch(()=>{})),Z.headerId&&(Lt.setBlockAttrOverride(Z.headerId,{[Ct]:"header"}),Zt(Z.headerId,{[Ct]:"header"}),await Et(Z.headerId,{[Ct]:"header"}).catch(()=>{}));for(let D=0;D<4;D++){const dt=Z.itemIds[D],lt=`col-${D+1}`;Lt.setBlockAttrOverride(dt,{[Ct]:lt}),Zt(dt,{[Ct]:lt}),await Et(dt,{[Ct]:lt}).catch(()=>{})}return ht.showMessage("已将本页版式设为四叶草（田字型）布局"),t.plugin&&await t.plugin.compileCurrentDocument(),!0}catch(Z){return console.error("[useInspectorActions] applyCloverLayout error:",Z),ht.showMessage("配置四叶草布局失败",4e3,"error"),!1}}return{triggerSaveNotice:n,saveAttrs:o,saveAttr:s,savePageAttr:r,applyPageLayoutAndRatio:a,applyCloverLayout:tt,resetSuperBlockWidth:W,saveDocAttr:c,onToggleVideoAutoplay:u,onToggleVideoLoop:m,onToggleVideoMuted:g,onToggleVideoControls:d,onImageRoleChange:b,onToggleNoteBlock:v,createNoteBlockOnCurrentSlide:f,onAddNoteBlock:k,onLocateNoteBlock:S,onGenerateNotesWithAI:x,isBatchProcessing:i,onBatchAppendNotes:A,onBatchDeleteNotes:T,toggleElemClick:I,onElemClickStepChange:w,onElemMotionChange:N,onElemSlotChange:F,onElemShikiLinesChange:j,onElemMaxHeightChange:J,onSetTwoColsContrast:$,onClearBlockAttrs:O,onInsertDividerBefore:y,onInsertDividerAfter:V,onDeleteCurrentBlock:X,onExportHtml:P,onExportPdf:U}}const Yb={class:"spm-slidev-inspector"},Jb={class:"spm-inspector-topbar"},Xb={class:"spm-inspector-title"},Qb={class:"slidev-icon",style:{fill:"none !important"},"aria-hidden":"true",viewBox:"0 0 24 24"},ty={class:"spm-inspector-topbar-actions"},ey={class:"spm-target-banner"},iy={class:"spm-target-info"},ny=["aria-label"],oy={key:0,class:"spm-save-status"},sy=["title"],ry={class:"spm-inspector-body"},ly=_e({__name:"SlidevInspectorDockView",setup(t,{expose:i}){const e=ei("plugin"),n=vt(!1);function o(it){n.value=!1,c.value=it.docId,e!=null&&e.compileCurrentDocument&&e.compileCurrentDocument(it.docId)}const s=vt(""),l=vt(""),r=vt({}),a=vt(""),c=vt(""),u=vt(""),m=vt(""),g=vt(""),d=vt(""),b=vt(""),f=vt(""),v=vt(null),k=vt(""),S=vt("");function x(){var yt;const it=s.value||c.value;it&&typeof navigator<"u"&&(yt=navigator==null?void 0:navigator.clipboard)!=null&&yt.writeText&&navigator.clipboard.writeText(it).then(()=>{S.value="已复制！",setTimeout(()=>{S.value=""},1500)}).catch(()=>{})}const A=St(()=>va(l.value)),T=St(()=>l.value==="NodeCodeBlock"),I=vt(!1),w=St(()=>{if(I.value||at.value)return!0;const it=a.value||"";return!!bi(it)}),N=St(()=>{const it=l.value||"";if(it==="NodeVideo"||it==="video")return!0;const yt=a.value||"";return!!(/<video\b/i.test(yt)||/\.mp4\b/i.test(yt))}),F=St(()=>!s.value||s.value===c.value||l.value==="doc"||l.value==="NodeDocument"),j=St(()=>{const it=s.value||c.value||"";return it.length>8?it.slice(-8):it||"无"}),J=St(()=>a.value?a.value.replace(/<[^>]+>/g,"").replace(/[\r\n]+/g," ").trim().slice(0,45):""),$=St(()=>{if(A.value)return"分页符 (---)";if(F.value)return"全局文档";if(N.value)return"视频块";let it="内容块";switch(l.value){case"NodeHeading":it="标题块";break;case"NodeParagraph":it="段落块";break;case"NodeCodeBlock":it="代码块";break;case"NodeVideo":it="视频块";break;case"NodeList":case"NodeListItem":it="列表项";break;case"NodeBlockquote":it="引述块";break;case"NodeTable":it="表格块";break;case"NodeSuperBlock":case"s":case"sb":it="超级块";break;default:it="内容块";break}return d.value?b.value?`${b.value.replace(/^col-(\d+)$/,"第 $1 栏")} › ${it}`:`分栏容器 › ${it}`:it}),O=St(()=>A.value?"tag-divider":F.value?"tag-doc":"tag-block"),y=St(()=>r.value[mt]||"default"),V=St(()=>r.value[te]||"slide-left"),X=vt(""),P=vt(""),U=St(()=>r.value[fn]||"inherit"),W=St(()=>{var it;return Kb((it=v.value)==null?void 0:it.slides,{activeBlockId:s.value,activeBlockType:l.value,currentTopBlockId:u.value,currentPageDividerId:m.value,activeBlockAttrs:r.value})}),tt=St(()=>{var it;return((it=W.value)==null?void 0:it.notes)||""}),B=St(()=>{var it,yt,It;return((It=(yt=(it=W.value)==null?void 0:it.noteBlocks)==null?void 0:yt[0])==null?void 0:It.id)||""}),M=St(()=>{var Mt,Ft,Pt,fe,Hn,di;if(A.value){const Qt=r.value[mt]||r.value["custom-slidev-layout"];if(Qt)return Qt}const it=r.value[Ct]||r.value["custom-slidev-slot"];if(it&&(["col-1","col-2","col-3"].includes(it)||/^col-\d+$/.test(it)))return"cols-header";if(g.value)return g.value;const yt=m.value||(A.value?s.value:"");if(yt){const Qt=Lt.getBlockAttrOverride(yt);if(Qt!=null&&Qt[mt])return Qt[mt]}if(yt&&((Mt=v.value)!=null&&Mt.slides)){const Qt=v.value.slides.find(Fi=>Fi.startBlockId===yt);if((Ft=Qt==null?void 0:Qt.frontmatter)!=null&&Ft.layout)return Qt.frontmatter.layout}if((fe=(Pt=W.value)==null?void 0:Pt.frontmatter)!=null&&fe.layout)return W.value.frontmatter.layout;if((di=(Hn=W.value)==null?void 0:Hn.blocks)!=null&&di.some(Qt=>Qt.slot&&(["col-1","col-2","col-3"].includes(Qt.slot)||/^col-\d+$/.test(Qt.slot))))return"cols-header";const It=Lt.getBlockAttrOverride(c.value);return It!=null&&It[mt]?It[mt]:"default"}),Y=St(()=>{var yt,It;if(A.value){const Mt=r.value[le]||r.value["custom-slidev-layout-ratio"];if(Mt)return Mt}const it=m.value||(A.value?s.value:"");if(it){const Mt=Lt.getBlockAttrOverride(it);if(Mt!=null&&Mt[le])return Mt[le]}return((It=(yt=W.value)==null?void 0:yt.frontmatter)==null?void 0:It.layoutRatio)||""});function Z(it){if(!it||(it.getAttribute("data-sb-layout")||"").toLowerCase()!=="col")return null;const It=Array.from(it.querySelectorAll(":scope > [data-node-id]"));if(It.length<2)return null;const Mt=It.length,Ft=It.map(di=>{const Qt=di.getAttribute("style")||"",Fi=Qt.match(/calc\(\s*([\d.]+)%/);if(Fi)return parseFloat(Fi[1]);const sn=Qt.match(/(?:^|;|\s)width:\s*([\d.]+)%/i);return sn?parseFloat(sn[1]):null});let Pt="",fe=!1;if(Ft.some(di=>di!==null)){fe=!0;const di=Ft.reduce((Tt,pe)=>Tt+(pe||0),0),Qt=Ft.filter(Tt=>Tt===null).length,Fi=Qt>0?Math.max(0,100-di)/Qt:100/It.length,sn=Ft.map(Tt=>Tt!==null?Tt:Fi),Ga=sn.reduce((Tt,pe)=>Tt+pe,0)||1,rn=sn.map(Tt=>Tt/Ga*100);if(rn.length===2){const[Tt]=rn;if(Tt>=48&&Tt<=52)Pt="1:1";else if(Tt>=31&&Tt<=35)Pt="1:2";else if(Tt>=65&&Tt<=69)Pt="2:1";else if(Tt>=28&&Tt<=32)Pt="3:7";else if(Tt>=68&&Tt<=72)Pt="7:3";else if(Tt>=38&&Tt<=42)Pt="4:6";else if(Tt>=58&&Tt<=62)Pt="6:4";else{const pe=Math.round(Tt);Pt=`${pe}:${100-pe}`}}else if(rn.length===3){const[Tt,pe,ui]=rn;if(Tt>=31&&Tt<=35&&pe>=31&&pe<=35&&ui>=31&&ui<=35)Pt="1:1:1";else if(Tt>=23&&Tt<=27&&pe>=48&&pe<=52&&ui>=23&&ui<=27)Pt="1:2:1";else if(Tt>=48&&Tt<=52&&pe>=23&&pe<=27&&ui>=23&&ui<=27)Pt="2:1:1";else if(Tt>=23&&Tt<=27&&pe>=23&&pe<=27&&ui>=48&&ui<=52)Pt="1:1:2";else{const Vs=Math.round(Tt),qs=Math.round(pe);Pt=`${Vs}:${qs}:${100-Vs-qs}`}}else Pt=rn.map(Tt=>Math.round(Tt)).join(":")}else fe=!1,Pt=Array.from({length:Mt},()=>1).join(":");const Hn=Mt>=2?"cols-header":"two-cols";return{hasSuperBlock:!0,colCount:Mt,ratio:Pt,isCustomWidth:fe,recommendedLayout:Hn}}function Q(it){if(!(it!=null&&it.blocks))return null;for(const yt of it.blocks){const It=yt.rawNode;if(It&&oe(It)&&Ke(It)){const Ft=on(It).length,Pt=Os(It);return{hasSuperBlock:!0,colCount:Ft,ratio:Pt||Array.from({length:Ft},()=>1).join(":"),isCustomWidth:!!Pt,recommendedLayout:Ft>=2?"cols-header":"two-cols"}}}return null}const D=St(()=>{var it;if(typeof document<"u"){const yt=s.value;if(yt){const Mt=document.querySelector(`.protyle-wysiwyg [data-node-id="${yt}"]`);if(Mt){const Ft=Mt.getAttribute("data-type")==="NodeSuperBlock"?Mt:Mt.closest('[data-type="NodeSuperBlock"]');if(Ft){const Pt=Z(Ft);if(Pt)return Pt}}}const It=m.value||(A.value?s.value:"");if(It){const Mt=document.querySelector(`.protyle-wysiwyg [data-node-id="${It}"]`);if(Mt){let Ft=Mt.nextElementSibling;for(;Ft&&!(Ft.getAttribute("data-type")==="NodeThematicBreak"||(it=Ft.classList)!=null&&it.contains("protyle-wysiwyg__block--hr"));){const Pt=Ft.getAttribute("data-type")==="NodeSuperBlock"?Ft:Ft.querySelector('[data-type="NodeSuperBlock"]');if(Pt){const fe=Z(Pt);if(fe)return fe}Ft=Ft.nextElementSibling}}}else{const Mt=document.querySelector('.protyle-wysiwyg [data-type="NodeThematicBreak"], .protyle-wysiwyg .protyle-wysiwyg__block--hr'),Ft=Array.from(document.querySelectorAll('.protyle-wysiwyg [data-type="NodeSuperBlock"]'));for(const Pt of Ft)if(!Mt||Pt.compareDocumentPosition(Mt)&Node.DOCUMENT_POSITION_FOLLOWING){const fe=Z(Pt);if(fe)return fe}}}return Q(W.value)}),dt=St(()=>{var it;return((it=D.value)==null?void 0:it.ratio)||""}),lt=St(()=>{const it=l.value||"";if(it==="NodeSuperBlock"||it==="s"||it==="sb")return!0;if(typeof document<"u"&&s.value){const yt=document.querySelector(`.protyle-wysiwyg [data-node-id="${s.value}"]`);if(yt!=null&&yt.closest('[data-type="NodeSuperBlock"]'))return!0}return!1}),rt=St(()=>{var it;return((it=W.value)==null?void 0:it.pageIndex)||1}),gt=St(()=>!!(r.value[ne]||r.value["slidev-note"]));function nt(){if(!d.value)return!1;if(s.value===d.value||typeof document>"u")return!0;const it=document.querySelector(`.protyle-wysiwyg [data-node-id="${d.value}"]`)||document.querySelector(`[data-node-id="${d.value}"]`);if(!it)return!1;const yt=it.querySelector(":scope > [data-node-id], :scope > div > [data-node-id]");return(yt==null?void 0:yt.getAttribute("data-node-id"))===s.value}const E=St(()=>{var yt;if(r.value[jt]!==void 0)return r.value[jt]||"";if(d.value&&nt())return f.value||"";if(d.value)return"";const it=s.value;if(it&&((yt=W.value)!=null&&yt.blocks)){const It=W.value.blocks.find(Mt=>Mt.id===it);if(It!=null&&It.clicks)return It.clicks}return""}),z=St(()=>{var yt;if(r.value[Ve])return r.value[Ve];const it=s.value;if(it&&((yt=W.value)!=null&&yt.blocks)){const It=W.value.blocks.find(Mt=>Mt.id===it);if(It!=null&&It.motion)return typeof It.motion=="string"?It.motion:JSON.stringify(It.motion)}return""}),p=St(()=>{var yt;if(r.value[Ct])return r.value[Ct];const it=s.value;if(it&&((yt=W.value)!=null&&yt.blocks)){const It=W.value.blocks.find(Mt=>Mt.id===it);if(It!=null&&It.slot)return It.slot}return""}),H=vt(""),R=vt(""),_=St(()=>r.value[Ti]==="true"),C=St(()=>r.value[oo]==="true"),L=St(()=>r.value[Ui]==="true"),G=St(()=>r.value[so]!=="false"),K=St(()=>{var it,yt;return((yt=(it=v.value)==null?void 0:it.config)==null?void 0:yt.theme)||r.value[xn]||"default"}),q=St(()=>{var it,yt;return((yt=(it=v.value)==null?void 0:it.config)==null?void 0:yt.aspectRatio)||r.value[Sn]||"16/9"}),et=St(()=>{var it,yt;return((yt=(it=v.value)==null?void 0:it.config)==null?void 0:yt.defaultTransition)||r.value[_n]||"slide-left"}),ct=St(()=>{var it,yt;return((yt=(it=v.value)==null?void 0:it.config)==null?void 0:yt.spacing)||r.value[ts]||"normal"}),at=St(()=>{var Ft,Pt;if((r.value[qt]||r.value["slidev-role"])===Ur||r.value[Ut]==="true")return"background";const yt=r.value[mt]||r.value["slidev-layout"];if(yt==="image-left"||yt==="image-right")return yt;const It=a.value||"",Mt=bi(It);if(Mt&&((Pt=(Ft=W.value)==null?void 0:Ft.frontmatter)!=null&&Pt.background)){const fe=W.value.frontmatter.background;if(fe===Mt||fe.endsWith(Mt)||Mt.endsWith(fe))return"background"}return""}),pt=St(()=>!!(r.value[jt]||r.value[Ve]||r.value[Ct]||r.value[Oi]||r.value[ne]||r.value["slidev-note"]||r.value[qt]||r.value[mt]||r.value[Ti]||r.value[oo]||r.value[Ui]||r.value[so])),{saveAttr:wt,savePageAttr:kt,applyPageLayoutAndRatio:Dt,applyCloverLayout:Gt,resetSuperBlockWidth:Yt,saveDocAttr:ie,onToggleVideoAutoplay:Nt,onToggleVideoLoop:Ge,onToggleVideoMuted:se,onToggleVideoControls:Xt,onImageRoleChange:ki,onToggleNoteBlock:zi,onAddNoteBlock:Lo,onLocateNoteBlock:Do,onGenerateNotesWithAI:Fn,isBatchProcessing:wi,onBatchAppendNotes:Ni,onBatchDeleteNotes:wa,toggleElemClick:xa,onElemClickStepChange:Sa,onElemMotionChange:_a,onElemSlotChange:Ca,onElemShikiLinesChange:$a,onElemMaxHeightChange:Ia,onSetTwoColsContrast:Aa,onClearBlockAttrs:Ba,onInsertDividerBefore:Ta,onInsertDividerAfter:js,onDeleteCurrentBlock:Ea,onExportHtml:Ma,onExportPdf:La}=Zb({activeBlockId:s,activeBlockType:l,activeBlockAttrs:r,rawSnippet:a,currentDocId:c,currentPageDividerId:m,currentPageDividerLayout:g,parentContainerId:d,parentContainerClicks:f,latestDoc:v,targetSlide:W,currentSlideNoteBlockId:B,currentSlideLayout:M,isNoteBlock:gt,elemClick:E,videoAutoplay:_,videoLoop:C,videoMuted:L,videoControls:G,pageBackground:X,pageImage:P,elemShikiLines:H,elemMaxHeight:R,saveStatus:k,plugin:e});async function Da(it){if(it==="clover"){if(!await Gt())return}else wt(mt,it)}function Pa(it){kt(le,it)}function Us(it){if(!it)return;const yt=it.recommendedLayout||(it.colCount&&it.colCount>=2?"cols-header":"two-cols"),It=it.ratio||(it.colCount?Array(it.colCount).fill(1).join(":"):"1:1");Dt(yt,It)}function Oa(it){kt(le,it)}async function Ra(){await Yt()}function za(it){wt(te,it)}function Na(it){X.value=it,wt(Ut,it)}function Fa(it){P.value=it,wt(Ee,it)}function Ha(it){wt(fn,it==="inherit"?"":it)}function ja(it){ie(xn,it)}function Ua(it){ie(Sn,it)}function Wa(it){ie(_n,it)}function Va(it){ie(ts,it)}function Ws(){e!=null&&e.openBottomPreviewTab&&e.openBottomPreviewTab()}function qa(){typeof window<"u"&&window.open("/plugins/siyuan-slidev/slidev-client/presenter.html","SlidevPresenter","width=1200,height=800")}function Ka(){e!=null&&e.executeCommand&&e.executeCommand("slidevAiSplit")}return i({setActiveBlock(it){s.value=it.id,l.value=it.type,r.value={...it.attrs},a.value=it.content||it.markdown||"",u.value=it.topBlockId||it.id,m.value=it.pageDividerId||"",g.value=it.pageDividerLayout||"",d.value=it.parentContainerId||"",b.value=it.parentContainerSlot||"",f.value=it.parentContainerClicks||"",it.rootId?c.value=it.rootId:(it.type==="doc"||it.type==="NodeDocument")&&it.id&&(c.value=it.id),X.value=it.attrs[Ut]||"",P.value=it.attrs[Ee]||"",H.value=it.attrs[Oi]||"",R.value=it.attrs[Cn]||"",I.value=!!it.isImage},updateDocument(it){v.value=it,c.value=it.docId},openImportDialog(){n.value=!0},setCurrentDocId(it){c.value=it}}),(it,yt)=>(ot(),st("div",Yb,[h("div",Jb,[h("div",Xb,[(ot(),st("svg",Qb,[...yt[2]||(yt[2]=[h("rect",{x:"2",y:"3",width:"20",height:"14",rx:"2"},null,-1),h("line",{x1:"8",y1:"21",x2:"16",y2:"21"},null,-1),h("line",{x1:"12",y1:"17",x2:"12",y2:"21"},null,-1)])])),yt[3]||(yt[3]=h("span",null,"演示配置",-1))]),h("div",ty,[h("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"导入 Slidev 演示文档 (.md / .zip)",onClick:yt[0]||(yt[0]=It=>n.value=!0)},[ut(ft,{name:"import"}),yt[4]||(yt[4]=h("span",null,"导入",-1))]),h("button",{class:"spm-icon-btn is-primary b3-tooltips b3-tooltips__s","aria-label":"在下方分屏开启幻灯片预览 (Alt+P)",onClick:Ws},[ut(ft,{name:"split-preview"}),yt[5]||(yt[5]=h("span",null,"分屏预览",-1))])])]),h("div",ey,[h("div",iy,[h("span",{class:At(["spm-target-tag",O.value])},_t($.value),3),h("span",{class:"spm-target-id b3-tooltips b3-tooltips__s","aria-label":S.value||"点击复制 ID: "+(s.value||c.value),onClick:x},[ut(ft,{name:"copy"}),h("span",null,"#"+_t(j.value),1)],8,ny)]),k.value?(ot(),st("span",oy,"● "+_t(k.value),1)):Ot("",!0)]),J.value?(ot(),st("div",{key:0,class:"spm-context-quote",title:a.value},_t(J.value),9,sy)):Ot("",!0),h("div",ry,[A.value?(ot(),Le(yg,{key:0,"page-layout":y.value,"page-layout-ratio":Y.value,"detected-sb-ratio":dt.value,"detected-sb-info":D.value,"page-transition":V.value,"page-background":X.value,"page-spacing":U.value,"page-image":P.value,"page-notes":tt.value,"page-index":rt.value,"onUpdate:pageLayout":Da,"onUpdate:pageLayoutRatio":Pa,onApplySuperBlockLayout:Us,onResetSuperblockRatio:Ra,"onUpdate:pageTransition":za,"onUpdate:pageBackground":Na,"onUpdate:pageSpacing":Ha,"onUpdate:pageImage":Fa,onAddNoteBlock:bt(Lo),onLocateNoteBlock:bt(Do),onGenerateNotes:bt(Fn),onBatchAppendNotes:bt(Ni),onBatchDeleteNotes:bt(wa),"is-batch-processing":bt(wi),onInsertDividerAfter:bt(js),onDeleteDivider:bt(Ea)},null,8,["page-layout","page-layout-ratio","detected-sb-ratio","detected-sb-info","page-transition","page-background","page-spacing","page-image","page-notes","page-index","onAddNoteBlock","onLocateNoteBlock","onGenerateNotes","onBatchAppendNotes","onBatchDeleteNotes","is-batch-processing","onInsertDividerAfter","onDeleteDivider"])):s.value&&!F.value?(ot(),Le(n1,{key:1,"elem-click":E.value,"elem-motion":z.value,"elem-slot":p.value,"elem-shiki-lines":H.value,"elem-max-height":R.value,"is-code-block":T.value,"is-image":w.value,"is-video":N.value,"is-super-block":lt.value,"detected-sb-info":D.value,"video-autoplay":_.value,"video-loop":C.value,"video-muted":L.value,"video-controls":G.value,"has-block-attrs":pt.value,"is-note":gt.value,"image-role":at.value,"current-slide-layout":M.value,"parent-elem-click":f.value,"parent-container-slot":b.value,"parent-container-id":d.value,onToggleNote:bt(zi),onToggleElemClick:bt(xa),onToggleVideoAutoplay:bt(Nt),onToggleVideoLoop:bt(Ge),onToggleVideoMuted:bt(se),onToggleVideoControls:bt(Xt),"onUpdate:imageRole":bt(ki),"onUpdate:elemClick":bt(Sa),"onUpdate:elemMotion":bt(_a),"onUpdate:elemSlot":bt(Ca),"onUpdate:elemShikiLines":bt($a),"onUpdate:elemMaxHeight":bt(Ia),onApplySuperBlockLayout:Us,onApplySuperBlockRatio:Oa,onInsertDividerBefore:bt(Ta),onInsertDividerAfter:bt(js),onSetTwoColsContrast:bt(Aa),onClearBlockAttrs:bt(Ba)},null,8,["elem-click","elem-motion","elem-slot","elem-shiki-lines","elem-max-height","is-code-block","is-image","is-video","is-super-block","detected-sb-info","video-autoplay","video-loop","video-muted","video-controls","has-block-attrs","is-note","image-role","current-slide-layout","parent-elem-click","parent-container-slot","parent-container-id","onToggleNote","onToggleElemClick","onToggleVideoAutoplay","onToggleVideoLoop","onToggleVideoMuted","onToggleVideoControls","onUpdate:imageRole","onUpdate:elemClick","onUpdate:elemMotion","onUpdate:elemSlot","onUpdate:elemShikiLines","onUpdate:elemMaxHeight","onInsertDividerBefore","onInsertDividerAfter","onSetTwoColsContrast","onClearBlockAttrs"])):(ot(),Le(H1,{key:2,"doc-theme":K.value,"doc-aspect-ratio":q.value,"doc-default-transition":et.value,"doc-spacing":ct.value,"onUpdate:docTheme":ja,"onUpdate:docAspectRatio":Ua,"onUpdate:docDefaultTransition":Wa,"onUpdate:docSpacing":Va,onOpenBottomPreview:Ws,onOpenPresenter:qa,onAiAutoSplit:Ka,onExportHtml:bt(Ma),onExportPdf:bt(La)},null,8,["doc-theme","doc-aspect-ratio","doc-default-transition","doc-spacing","onExportHtml","onExportPdf"]))]),n.value?(ot(),Le(qb,{key:1,onClose:yt[1]||(yt[1]=It=>n.value=!1),onSuccess:o})):Ot("",!0)]))}}),Nn=new Fs;let gi=null,We=null;function ay(t,i){gi&&ya(),gi=Jl(km),gi.provide("plugin",i),gi.provide("sandboxBridge",Nn);const e=gi.mount(t);return We=e,e}function ya(t){gi&&(gi.unmount(),gi=null,We=null)}let vi=null,Se=null;function cy(t,i){vi&&ka(),vi=Jl(ly),vi.provide("plugin",i),vi.provide("sandboxBridge",Nn);const e=vi.mount(t);return Se=e,e}function ka(t){vi&&(vi.unmount(),vi=null,Se=null)}function dy(t,i){Se!=null&&Se.updateDocument&&Se.updateDocument(t),We!=null&&We.updateDocument?We.updateDocument(t,i):Nn.updateSlides(t.slides,t.config,t.fullMarkdown)}function ms(t){We!=null&&We.navigateToBlock?We.navigateToBlock(t):Nn.highlightElement(t)}function io(t){Se!=null&&Se.setActiveBlock&&Se.setActiveBlock(t)}function uy(){return Se!=null&&Se.openImportDialog?(Se.openImportDialog(),!0):!1}function fy(t,i){const e=[];let o=0;for(let s=0;s<t.length;s++){const l=t[s];if(bo(l)){o=0;continue}const r=l.markdown||l.content||"";if(!(s===0)){if(l.type==="h"&&(l.subType==="h1"||r.startsWith("# "))){e.push({blockId:l.id,recommendedLayout:"cover",reason:"检测到一级核心章节标题，建议作为新幻灯片封面/大章"}),o=0;continue}if(l.type==="h"&&(l.subType==="h2"||r.startsWith("## "))){e.push({blockId:l.id,recommendedLayout:"default",reason:"检测到二级分论点标题，建议开启新页"}),o=0;continue}}if(o++,o>=6&&s<t.length-1){const c=t[s+1];bo(c)||(e.push({blockId:c.id,recommendedLayout:"default",reason:"当前页已达容量上限 (避免信息超载)，建议在此分页"}),o=0)}}return e}const py=[{id:"slidev-cover",name:"幻灯片 - 封面页 (Cover)",open:!0,attrs:[{key:Bi,value:"true"},{key:mt,value:"cover"},{key:te,value:"fade"}]},{id:"slidev-two-cols",name:"幻灯片 - 双栏对比 (Two Columns)",open:!0,attrs:[{key:Bi,value:"true"},{key:mt,value:"two-cols"},{key:te,value:"slide-left"}]},{id:"slidev-fact",name:"幻灯片 - 大字报与核心指标 (Fact)",open:!0,attrs:[{key:Bi,value:"true"},{key:mt,value:"fact"},{key:te,value:"zoom"}]},{id:"slidev-intro",name:"幻灯片 - 章节导引与作者 (Intro)",open:!0,attrs:[{key:Bi,value:"true"},{key:mt,value:"intro"},{key:te,value:"slide-up"}]},{id:"slidev-quote",name:"幻灯片 - 金句与强调 (Quote)",open:!0,attrs:[{key:Bi,value:"true"},{key:mt,value:"quote"},{key:te,value:"fade"}]},{id:"slidev-elem-click",name:"元素 - 顺延逐步呈现 (v-click)",open:!0,attrs:[{key:jt,value:"+1"}]},{id:"slidev-elem-click-hide",name:"元素 - 隐藏直到激活 (v-click:hide)",open:!0,attrs:[{key:jt,value:"hide"}]},{id:"slidev-elem-slot-right",name:"元素 - 双栏右栏归属 (Slot: Right)",open:!0,attrs:[{key:Ct,value:"right"}]},{id:"slidev-shiki-lines",name:"代码 - 逐行聚光高亮 (Shiki)",open:!0,attrs:[{key:Oi,value:"1-3"}]}];class Jo{getPresetTemplates(){return py}buildScanSlidevBlocksSql(i="custom-slidev-"){return`SELECT block_id, name, value FROM attributes WHERE name LIKE '${i}%' ORDER BY block_id ASC`}buildTransitionStatsSql(){return`SELECT value, count(1) as count FROM attributes WHERE name = '${te}' GROUP BY value ORDER BY count DESC`}async batchUpdateTransitions(i,e,n,o){const s=`SELECT block_id FROM attributes WHERE name = '${te}' AND value = '${i}'`,l=await n(s);let r=0;if(Array.isArray(l))for(const a of l){const c=a.block_id||a.blockId;c&&(await o(c,{[te]:e}),r++)}return{updatedCount:r}}async batchUpdateLayout(i,e,n,o){const s=`SELECT block_id FROM attributes WHERE name = 'custom-slidev-layout' AND value = '${i}'`,l=await n(s);let r=0;if(Array.isArray(l))for(const a of l){const c=a.block_id||a.blockId;c&&(await o(c,{"custom-slidev-layout":e}),r++)}return{updatedCount:r}}exportTemplatesJson(){const i=this.getPresetTemplates();return JSON.stringify({templates:i,counter:i.length},null,2)}formatTransitionSummary(i){return!i||i.length===0?"全库目前暂无已设置 Slidev 转场效果的块":`全库 Slidev 转场分布统计：${i.map(n=>`${n.value}: ${n.count} 个`).join("，")}`}}function hy(t){t.addCommand({langKey:"slidevPresentation",langText:"Slidev: 在文档下方开启分屏演示预览",hotkey:"⌥P",enabled:()=>!0,execute:()=>{t.openBottomPreviewTab()}}),t.addCommand({langKey:"slidevImport",langText:"Slidev: 导入 Slidev 演示文档 (.md / .zip)",hotkey:"⌥I",enabled:()=>!0,execute:()=>{uy()||ht.showMessage("请先在右侧栏打开「Slidev 演示配置」Dock 面板以呼起导入窗口")}}),t.addCommand({langKey:"slidevInitAttrs",langText:"Slidev: 初始化当前文档演示属性",hotkey:"",enabled:()=>!0,execute:async()=>{if(!t.currentDocId){const i=document.querySelector(".protyle-content[data-doc-id]");t.currentDocId=(i==null?void 0:i.getAttribute("data-doc-id"))||""}t.currentDocId&&(await Et(t.currentDocId,{"custom-slidev-theme":"default","custom-slidev-aspect-ratio":"16/9","custom-slidev-default-transition":"slide-left"}),ht.showMessage("已为当前文档初始化 Slidev 演示属性"),t.compileCurrentDocument(t.currentDocId))}}),t.addCommand({langKey:"slidevAiSplit",langText:"Slidev AI: 智能大纲断页建议与自动分页",hotkey:"",enabled:()=>!0,execute:async()=>{if(!t.currentDocId){const s=document.querySelector(".protyle-content[data-doc-id]");t.currentDocId=(s==null?void 0:s.getAttribute("data-doc-id"))||""}if(!t.currentDocId){ht.showMessage("请先打开一篇思源笔记文档");return}const i=await no(t.currentDocId).catch(()=>[]);if(!i||i.length===0){ht.showMessage("当前文档无内容，无需断页");return}const e=i.map(s=>({id:s.id,type:s.type,subType:s.subType,content:s.content||"",markdown:s.markdown||""})),n=fy(e);if(n.length===0){ht.showMessage("AI 分析完毕：当前文档篇幅合理，暂无分页建议");return}ht.showMessage(`AI 分析完毕：发现 ${n.length} 处建议分页点，正在自动插入分页分割线...`);let o=0;for(const s of n)try{await Ii("markdown","---",void 0,s.blockId),await Et(s.blockId,{"custom-slidev-layout":s.recommendedLayout}),o++}catch(l){console.warn("Failed to insert divider:",l)}ht.showMessage(`已成功在 ${o} 处插入分页线并重新编译`),t.compileCurrentDocument(t.currentDocId)}}),t.addCommand({langKey:"slidevAiNotes",langText:"Slidev AI: 自动为当前文档生成演讲者提词卡 (Notes)",hotkey:"",enabled:()=>!0,execute:async()=>{var a,c,u,m;if(!t.currentDocId){const g=document.querySelector(".protyle-content[data-doc-id]");t.currentDocId=(g==null?void 0:g.getAttribute("data-doc-id"))||""}if(!t.currentDocId){ht.showMessage("请先打开一篇思源笔记文档");return}ht.showMessage("正在调用思源 AI 提炼演讲者口播提词...");const i=await no(t.currentDocId).catch(()=>[]),e={startBlockId:t.currentDocId,blocks:i.map(g=>({id:g.id,type:g.type,content:g.content||"",rawMarkdown:g.markdown||""})),rawMarkdown:""},s=`> [!NOTE] 💡 演讲备注
${(await Gb(e,Nr)).split(/\r?\n/).map(g=>`> ${g}`).join(`
`)}
{: custom-slidev-note="true"}`,l=await Xo("markdown",s,t.currentDocId).catch(()=>null),r=((u=(c=(a=l==null?void 0:l[0])==null?void 0:a.doOperations)==null?void 0:c[0])==null?void 0:u.id)||((m=l==null?void 0:l[0])==null?void 0:m.id);r&&(await Et(r,{"custom-slidev-note":"true"}),Lt.setBlockAttrOverride(r,{"custom-slidev-note":"true"}),Pi(r,t.app)),ht.showMessage("已成功生成口播提词卡并插入为正文讲稿备注块"),t.compileCurrentDocument(t.currentDocId)}}),t.addCommand({langKey:"slidevBatchTransitions",langText:"Slidev 协同: 统计全库转场效果分布",hotkey:"",enabled:()=>!0,execute:async()=>{const i=new Jo,e=i.buildTransitionStatsSql(),n=await wn(e).catch(()=>[]),o=i.formatTransitionSummary(n||[]);ht.showMessage(o)}}),t.addCommand({langKey:"slidevExportTemplates",langText:"Slidev 协同: 复制 Slidev 预设属性模板至剪贴板",hotkey:"",enabled:()=>!0,execute:async()=>{const e=new Jo().exportTemplatesJson();typeof navigator<"u"&&navigator.clipboard?(await navigator.clipboard.writeText(e),ht.showMessage("已将 Slidev 属性模板 JSON 复制至剪贴板，可直接导入属性管家")):ht.showMessage(`已生成模板数据（请在控制台查看）：
`+e)}}),t.addCommand({langKey:"slidevBatchReplaceTransition",langText:"Slidev 协同: 批量替换全库淡入淡出转场为滑动 (fade -> slide-left)",hotkey:"",enabled:()=>!0,execute:async()=>{const e=await new Jo().batchUpdateTransitions("fade","slide-left",n=>wn(n).catch(()=>[]),(n,o)=>Et(n,o));ht.showMessage(`全库批量替换完成：已将 ${e.updatedCount} 处 fade 转场更新为 slide-left`),t.compileCurrentDocument()}}),t.addCommand({langKey:"slidevPresenterMode",langText:"Slidev: 打开双屏演讲者控制台 (Presenter Mode)",hotkey:"⌥M",enabled:()=>!0,execute:()=>{typeof window<"u"&&window.open("/plugins/siyuan-slidev/slidev-client/presenter.html","SlidevPresenter","width=1200,height=800")}}),t.addCommand({langKey:"slidevExportCliMd",langText:"Slidev Pro: 导出 Slidev 标准 slides.md 文档 (下载到本地)",hotkey:"",enabled:()=>!0,execute:async()=>{if(t.latestCompiledDoc||await t.compileCurrentDocument(),!t.latestCompiledDoc){ht.showMessage("请先打开并放映一篇思源笔记文档");return}t.cliBridge.downloadSlidesMd(t.latestCompiledDoc,`slides-${t.currentDocId||"demo"}.md`)&&ht.showMessage("已生成标准 Slidev Markdown 并触发下载，可在本地使用 npx @slidev/cli 运行")}}),t.addCommand({langKey:"slidevProbeCliDevServer",langText:"Slidev Pro: 检测本地 Slidev CLI DevServer 状态 (localhost:3030)",hotkey:"",enabled:()=>!0,execute:async()=>{ht.showMessage("正在探测本地 Slidev CLI DevServer (http://localhost:3030)..."),await t.cliBridge.probeServer(1500)?ht.showMessage("🟢 本地 Slidev CLI DevServer 运行正常！可直接在浏览器访问 http://localhost:3030"):ht.showMessage("⚪ 未检测到运行中的本地 Slidev CLI DevServer (端口 3030 未开启)")}}),t.addCommand({langKey:"slidevSyncToCliWorkspace",langText:"Slidev Pro: 同步 slides.md 至思源工作空间存储目录",hotkey:"",enabled:()=>!0,execute:async()=>{if(t.latestCompiledDoc||await t.compileCurrentDocument(),!t.latestCompiledDoc){ht.showMessage("请先打开并放映一篇思源笔记文档");return}const i=await t.cliBridge.syncToWorkspaceFile(t.latestCompiledDoc,"/data/storage/petal/siyuan-slidev/slides.md",Qo);i.success?ht.showMessage(`已成功同步最新 slides.md 至工作空间：${i.path}`):ht.showMessage(`同步失败：${i.error}`)}})}class my{getActiveDocumentId(){if(typeof document>"u")return"";const i=document.querySelector(".layout__wnd--active .protyle-title[data-node-id]")||document.querySelector(".item--focus .protyle-title[data-node-id]")||document.querySelector(".protyle-title[data-node-id]"),e=i==null?void 0:i.getAttribute("data-node-id");if(e)return e;const n=document.querySelector(".protyle .protyle-title[data-node-id]"),o=n==null?void 0:n.getAttribute("data-node-id");if(o)return o;const s=document.querySelector("[data-doc-id]"),l=s==null?void 0:s.getAttribute("data-doc-id");return l||""}resolveDocIdFromElement(i,e=""){const n=i.closest(".protyle-title"),o=n==null?void 0:n.getAttribute("data-node-id");if(o)return o;const s=i.closest(".protyle"),l=s==null?void 0:s.querySelector(".protyle-title"),r=l==null?void 0:l.getAttribute("data-node-id");if(r)return r;const a=i.closest("[data-doc-id]"),c=a==null?void 0:a.getAttribute("data-doc-id");if(c)return c;const u=this.getActiveDocumentId();return u||e}async switchToDocGlobalInspector(i,e){var s;if(!i)return;let n=e||"";if(!n&&typeof document<"u"){const l=document.querySelector(`.protyle-title[data-node-id="${i}"] .protyle-title__input`)||document.querySelector(`.protyle[data-doc-id="${i}"] .protyle-title__input`)||document.querySelector(".protyle-title__input");n=((s=l==null?void 0:l.innerText)==null?void 0:s.trim())||""}const o=await Ye(i).catch(()=>({}));io({id:i,rootId:i,type:"doc",content:n,attrs:o,isDivider:!1,isCode:!1}),ms(i)}handleBlockClickedFromSlide(i,e,n,o){var a;if(!i)return!1;const s=Pi(i,e),l=document.querySelector(`.protyle-wysiwyg [data-node-id="${i}"]`)||document.querySelector(`[data-node-id="${i}"]`),r=(l==null?void 0:l.getAttribute("data-type"))||"";if(l)this.syncInspectorBlock(l,i,r,n,o);else{let c="",u="";if(o!=null&&o.slides){const m=o.slides.find(g=>{var d,b,f;return g.startBlockId===i||((d=g.blocks)==null?void 0:d.some(v=>v.id===i))||((b=g.allBlockIds)==null?void 0:b.includes(i))||((f=g.noteBlocks)==null?void 0:f.some(v=>v.id===i))});m!=null&&m.startBlockId&&(c=m.startBlockId),(a=m==null?void 0:m.frontmatter)!=null&&a.layout&&(u=m.frontmatter.layout)}Ye(i).then(async m=>{if(c&&!u){const g=Lt.getBlockAttrOverride(c);if(g!=null&&g[mt]||g!=null&&g["custom-slidev-layout"])u=g[mt]||g["custom-slidev-layout"]||"";else{const d=await Ye(c).catch(()=>({}))||{};u=d[mt]||d["custom-slidev-layout"]||"",d&&Object.keys(d).length>0&&Lt.setBlockAttrOverride(c,d)}}io({id:i,rootId:n,type:r||"NodeParagraph",attrs:m||{},pageDividerId:c,pageDividerLayout:u})}).catch(()=>{})}return s}async syncInspectorBlock(i,e,n,o,s){var V,X,P,U,W,tt,B,M;let l=i,r=e,a=n;const c=i.closest('[data-type="NodeCallout"]');if(c&&c!==i){const Y=c.getAttribute("data-node-id");if(Y){const Z=await Ye(Y).catch(()=>({}))||{},Q=Lt.getBlockAttrOverride(Y)||{},D={...Z,...Q};(D[ne]||D["slidev-note"])&&(l=c,r=Y,a="NodeCallout")}}const u=l.closest(".protyle-wysiwyg > [data-node-id]")||l,m=(u==null?void 0:u.getAttribute("data-node-id"))||r,g=a==="NodeThematicBreak"||a==="tb"||a==="thematic-break"||(u==null?void 0:u.getAttribute("data-type"))==="NodeThematicBreak"||(u==null?void 0:u.getAttribute("data-type"))==="tb"||!!((V=u==null?void 0:u.classList)!=null&&V.contains("hr")),d=a==="NodeCodeBlock",b=((X=l.innerText)==null?void 0:X.trim())||"",f=await Ye(r).catch(()=>({}))||{},v=Lt.getBlockAttrOverride(r)||{},k={...f,...v};let S="",x="";if(g)S=r,x=k[mt]||k["custom-slidev-layout"]||"";else{let Y=u.previousElementSibling;for(;Y;){const Z=Y.getAttribute("data-type");if(Z==="NodeThematicBreak"||Z==="tb"||(P=Y.classList)!=null&&P.contains("hr")){S=Y.getAttribute("data-node-id")||"";break}Y=Y.previousElementSibling}}if(s!=null&&s.slides){const Y=[r,m];let Z=l.parentElement;for(;Z&&!Z.classList.contains("protyle-wysiwyg");){const D=Z.getAttribute("data-node-id");D&&!Y.includes(D)&&Y.push(D),Z=Z.parentElement}const Q=s.slides.find(D=>{var dt,lt,rt;return Y.includes(D.startBlockId)||((dt=D.blocks)==null?void 0:dt.some(gt=>Y.includes(gt.id)))||((lt=D.allBlockIds)==null?void 0:lt.some(gt=>Y.includes(gt)))||((rt=D.noteBlocks)==null?void 0:rt.some(gt=>Y.includes(gt.id)))});Q&&(!S&&Q.startBlockId&&(S=Q.startBlockId),!x&&((U=Q.frontmatter)!=null&&U.layout)&&(x=Q.frontmatter.layout))}if(S){const Y=Lt.getBlockAttrOverride(S);if(Y&&(mt in Y||"custom-slidev-layout"in Y)&&(x=Y[mt]||Y["custom-slidev-layout"]||""),!x&&(s!=null&&s.slides)){const Z=s.slides.find(Q=>Q.startBlockId===S);(W=Z==null?void 0:Z.frontmatter)!=null&&W.layout&&(x=Z.frontmatter.layout)}if(!x){const Z=await Ye(S).catch(()=>({}))||{};x=Z[mt]||Z["custom-slidev-layout"]||"",Z&&Object.keys(Z).length>0&&Lt.setBlockAttrOverride(S,Z)}Zt(S,{[mt]:x||""})}else if(o){const Y=Lt.getBlockAttrOverride(o);Y&&(mt in Y||"custom-slidev-layout"in Y)?x=Y[mt]||Y["custom-slidev-layout"]||"":!x&&((M=(B=(tt=s==null?void 0:s.slides)==null?void 0:tt[0])==null?void 0:B.frontmatter)!=null&&M.layout)&&(x=s.slides[0].frontmatter.layout)}const A=l.getAttribute(mt)||l.getAttribute("custom-slidev-layout"),T=k[mt]||k["custom-slidev-layout"]||"";A&&A!==T&&Zt(r,{[mt]:T});const I=l.getAttribute(qt)||l.getAttribute("custom-slidev-role"),w=k[qt]||k["custom-slidev-role"]||"";I&&I!==w&&Zt(r,{[qt]:w});let N="",F="",j="";const J=l.closest('[data-type="NodeListItem"]');if(J&&J!==l){const Y=J.getAttribute("data-node-id");if(Y){N=Y;const Z=await Ye(Y).catch(()=>({}))||{},Q=Lt.getBlockAttrOverride(Y)||{},D={...Z,...Q};F=D[Ct]||"",j=D[jt]||"";const dt=D[mt]||D["custom-slidev-layout"]||"",lt=J.getAttribute(mt)||J.getAttribute("custom-slidev-layout");lt&&lt!==dt&&Zt(Y,{[mt]:dt});const rt=D[qt]||D["custom-slidev-role"]||"",gt=J.getAttribute(qt)||J.getAttribute("custom-slidev-role");gt&&gt!==rt&&Zt(Y,{[qt]:rt})}}const $=!!l.querySelector("img, span[data-type='img']"),O=(l.innerText||"").replace(/[\r\n\t\s]+/g," ").trim(),y=$&&O.length<=50;io({id:r,rootId:o,type:a,content:b,attrs:k,isDivider:g,isCode:d,isImage:y,topBlockId:m,pageDividerId:S,pageDividerLayout:x,parentContainerId:N,parentContainerSlot:F,parentContainerClicks:j})}patchThematicBreakTransactions(i){if((i==null?void 0:i.cmd)==="transactions"&&Array.isArray(i.data)){for(const e of i.data)if(Array.isArray(e==null?void 0:e.doOperations)){for(const n of e.doOperations)if((n==null?void 0:n.action)==="updateAttrs"&&n.id&&n.data){const o=n.data.old||{},s=n.data.new||{},l={};for(const r of Object.keys(o))r in s||(l[r]="");for(const[r,a]of Object.entries(s))l[r]=String(a??"");Zt(n.id,l),Lt.setBlockAttrOverride(n.id,l)}}}}purgeStaleDomSlidevAttrs(i){var o,s,l;if(typeof document>"u"||!i)return;const e=new Map;if(Array.isArray(i.slides))for(const r of i.slides){if(r.startBlockId){const a=e.get(r.startBlockId)||{};(o=r.frontmatter)!=null&&o.layout&&(a[mt]=r.frontmatter.layout),e.set(r.startBlockId,a)}if(Array.isArray(r.blocks)){for(const a of r.blocks)if(a.id){const c=e.get(a.id)||{};(s=a.ial)!=null&&s[mt]&&(c[mt]=a.ial[mt]),(l=a.ial)!=null&&l[qt]&&(c[qt]=a.ial[qt]),Object.keys(c).length>0&&e.set(a.id,c)}}}const n=Lt.getAllAttrOverrides();for(const[r,a]of n.entries()){const c=e.get(r)||{};a[mt]!==void 0&&(c[mt]=a[mt]),a[qt]!==void 0&&(c[qt]=a[qt]),e.set(r,c)}Bp(e)}}const $i=new my,gy=`<symbol id="iconSlidev" viewBox="0 0 1024 1024">
  <path fill="currentColor" d="M128 160h768c35.3 0 64 28.7 64 64v480c0 35.3-28.7 64-64 64H128c-35.3 0-64-28.7-64-64V224c0-35.3 28.7-64 64-64z m64 64v480h640V224H192z m128 640h384v64H320z"/>
  <path fill="currentColor" d="M416 336l256 144-256 144z"/>
</symbol>`,vy="slidev-dock",Or="slidev-preview-tab",Rr=zu;class by extends ht.Plugin{constructor(){super(...arguments);xt(this,"isMobile",!1);xt(this,"currentDocId","");xt(this,"latestCompiledDoc",null);xt(this,"cliBridge",new Rs);xt(this,"debounceTimer",null);xt(this,"activeCursorBlockId","");xt(this,"onSwitchProtyleBound",this.onSwitchProtyle.bind(this));xt(this,"onWsMainBound",this.onWsMain.bind(this));xt(this,"onBlockClickedBound",this.onBlockClickedFromSlide.bind(this));xt(this,"onClickEditorTitleIconBound",this.onClickEditorTitleIcon.bind(this));xt(this,"onEditorClickBound",this.onEditorClick.bind(this));xt(this,"onSelectionChangeBound",this.onSelectionChange.bind(this));xt(this,"onClickEditorContentBound",this.onClickEditorContent.bind(this))}async onload(){const e=ht.getFrontend();this.isMobile=e==="mobile"||e==="browser-mobile",await this.loadGlobalSettings(),this.addIcons(gy),this.addTopBar({id:"slidev-topbar-play",icon:"iconSlidev",title:"Slidev 演示 (下方分屏)",position:"right",callback:()=>{this.openBottomPreviewTab()}}),hy(this);const n=this;if(this.addTab({type:Or,init(){ay(this.element,n)},destroy(){ya(this.element)}}),this.addDock({config:{position:"RightTop",size:{width:320,height:0},icon:"iconSlidev",title:"Slidev 演示配置"},data:{},type:vy,init(){cy(this.element,n)},destroy(){ka(this.element)}}),this.eventBus&&typeof this.eventBus.emit!="function"&&(this.eventBus.emit=(o,s)=>{try{typeof window<"u"&&window.dispatchEvent(new CustomEvent(`siyuan-event-${o}`,{detail:s}))}catch{}}),this.eventBus.on("switch-protyle",this.onSwitchProtyleBound),this.eventBus.on("ws-main",this.onWsMainBound),this.eventBus.on("slidev:request-compile",()=>this.compileCurrentDocument()),this.eventBus.on("slidev:block-clicked",this.onBlockClickedBound),this.eventBus.on("click-editortitleicon",this.onClickEditorTitleIconBound),this.eventBus.on("click-editorcontent",this.onClickEditorContentBound),typeof document<"u"&&(document.addEventListener("click",this.onEditorClickBound,!0),document.addEventListener("selectionchange",this.onSelectionChangeBound)),typeof document<"u"){const o=()=>{const s=this.getActiveDocumentId();s&&(s!==this.currentDocId&&(this.currentDocId=s),this.latestCompiledDoc||this.compileCurrentDocument(s))};setTimeout(o,300),setTimeout(o,1e3)}}async onDataChanged(e){await this.loadGlobalSettings(),this.currentDocId&&await this.compileCurrentDocument(this.currentDocId)}async loadGlobalSettings(){try{const e=await this.loadData(Rr),n=Nu(e);return Ei(n),n}catch{return Ei(tn),tn}}async saveGlobalSettings(e){const n=Mo(),o=Ei({...n,...e||{}});try{await this.saveData(Rr,o)}catch(l){console.error("保存 Slidev 全局配置失败",l)}const s=this.currentDocId||this.getActiveDocumentId();return s&&await this.compileCurrentDocument(s),o}onunload(){this.debounceTimer&&(window.clearTimeout(this.debounceTimer),this.debounceTimer=null),this.eventBus.off("switch-protyle",this.onSwitchProtyleBound),this.eventBus.off("ws-main",this.onWsMainBound),this.eventBus.off("click-editortitleicon",this.onClickEditorTitleIconBound),this.eventBus.off("click-editorcontent",this.onClickEditorContentBound),typeof document<"u"&&(document.removeEventListener("click",this.onEditorClickBound,!0),document.removeEventListener("selectionchange",this.onSelectionChangeBound)),Nn.detach()}async openBottomPreviewTab(){this.currentDocId||(this.currentDocId=this.getActiveDocumentId()),await ht.openTab({app:this.app,custom:{id:this.name+Or,title:"Slidev 演示预览",icon:"iconSlidev",data:{docId:this.currentDocId}},position:"bottom"}),this.currentDocId&&this.compileCurrentDocument(this.currentDocId)}onClickEditorTitleIcon(e){var l;const n=e.detail,o=n==null?void 0:n.menu,s=((l=n==null?void 0:n.data)==null?void 0:l.id)||this.currentDocId;!o||!s||o.addItem({icon:"iconSlidev",label:"Slidev 全局演示配置",submenu:[{label:"初始化演示属性 (custom-slidev-*)",click:async()=>{await Et(s,{"custom-slidev-theme":"default","custom-slidev-aspect-ratio":"16/9","custom-slidev-default-transition":"slide-left"}),ht.showMessage("已为当前文档初始化 Slidev 演示属性"),this.compileCurrentDocument(s)}},{type:"separator"},{label:"主题: 默认 (default)",click:async()=>{await Et(s,{"custom-slidev-theme":"default"}),ht.showMessage("已切换为 default 主题"),this.compileCurrentDocument(s)}},{label:"主题: 优雅衬线 (seriph)",click:async()=>{await Et(s,{"custom-slidev-theme":"seriph"}),ht.showMessage("已切换为 seriph 主题"),this.compileCurrentDocument(s)}},{label:"主题: 苹果极简 (apple-basic)",click:async()=>{await Et(s,{"custom-slidev-theme":"apple-basic"}),ht.showMessage("已切换为 apple-basic 主题"),this.compileCurrentDocument(s)}},{type:"separator"},{label:"画幅: 16 / 9 (宽屏)",click:async()=>{await Et(s,{"custom-slidev-aspect-ratio":"16/9"}),ht.showMessage("已切换画幅为 16/9"),this.compileCurrentDocument(s)}},{label:"画幅: 4 / 3 (标屏)",click:async()=>{await Et(s,{"custom-slidev-aspect-ratio":"4/3"}),ht.showMessage("已切换画幅为 4/3"),this.compileCurrentDocument(s)}}]})}async onSwitchProtyle(e){var s,l;const n=(s=e.detail)==null?void 0:s.protyle,o=(l=n==null?void 0:n.block)==null?void 0:l.rootID;if(o&&o!==this.currentDocId){this.currentDocId=o,this.activeCursorBlockId=o;const r=await Ye(o).catch(()=>({}));io({id:o,rootId:o,type:"doc",attrs:r}),this.compileCurrentDocument(o)}}onClickEditorContent(e){var s,l;const n=e==null?void 0:e.detail;if(!n)return;const o=(l=(s=n.protyle)==null?void 0:s.block)==null?void 0:l.rootID;o&&(!this.currentDocId||this.currentDocId!==o)&&(this.currentDocId=o),n.event&&this.onEditorClick(n.event)}getActiveDocumentId(){return $i.getActiveDocumentId()}resolveDocIdFromElement(e){return $i.resolveDocIdFromElement(e,this.currentDocId)}async switchToDocGlobalInspector(e,n){e&&(this.activeCursorBlockId=e,this.currentDocId=e,await $i.switchToDocGlobalInspector(e,n))}onWsMain(e){const n=e.detail;n&&($i.patchThematicBreakTransactions(n),this.debounceTimer&&window.clearTimeout(this.debounceTimer),this.debounceTimer=window.setTimeout(()=>{this.compileCurrentDocument()},150))}handleBlockClickedFromSlide(e,n){return e?(this.activeCursorBlockId=e,$i.handleBlockClickedFromSlide(e,this.app,this.currentDocId,this.latestCompiledDoc)):!1}onBlockClickedFromSlide(e){const n=(e==null?void 0:e.detail)||e;n!=null&&n.blockId&&this.handleBlockClickedFromSlide(n.blockId,n.page)}onEditorClick(e){const n=e.target;if(!n)return;const o=n.closest(".protyle-title")||n.closest(".protyle-background");if(!!(o||n.closest(".protyle-content")&&!n.closest(".protyle-wysiwyg")&&!n.closest(".protyle-breadcrumb")&&!n.closest(".protyle-gutters"))){const u=this.resolveDocIdFromElement(n);if(u&&this.activeCursorBlockId!==u){const m=o||document.querySelector(`.protyle-title[data-node-id="${u}"]`)||document.querySelector(`.protyle[data-doc-id="${u}"] .protyle-title`),g=m==null?void 0:m.querySelector(".protyle-title__input"),d=((g==null?void 0:g.innerText)||(m==null?void 0:m.innerText)||"").trim();this.switchToDocGlobalInspector(u,d)}return}if(!n.closest(".protyle-wysiwyg"))return;const r=n.closest("[data-node-id]");if(!r)return;const a=r.getAttribute("data-node-id"),c=r.getAttribute("data-type")||"";a&&(this.currentDocId||(this.currentDocId=this.resolveDocIdFromElement(n)||""),this.currentDocId&&!this.latestCompiledDoc&&this.compileCurrentDocument(this.currentDocId),a!==this.activeCursorBlockId&&(this.activeCursorBlockId=a,ms(a)),this.syncInspectorBlock(r,a,c))}onSelectionChange(){if(typeof window>"u")return;const e=window.getSelection();if(!e||e.rangeCount===0)return;const n=e.anchorNode;if(!n)return;const o=n.nodeType===Node.ELEMENT_NODE?n:n.parentElement;if(!o)return;const s=o.closest(".protyle-title");if(!!(s||o.closest(".protyle-content")&&!o.closest(".protyle-wysiwyg"))){const u=this.resolveDocIdFromElement(o);if(u&&this.activeCursorBlockId!==u){const m=s||document.querySelector(`.protyle-title[data-node-id="${u}"]`)||document.querySelector(`.protyle[data-doc-id="${u}"] .protyle-title`),g=m==null?void 0:m.querySelector(".protyle-title__input"),d=((g==null?void 0:g.innerText)||(m==null?void 0:m.innerText)||"").trim();this.switchToDocGlobalInspector(u,d)}return}if(!o.closest(".protyle-wysiwyg"))return;const r=o.closest("[data-node-id]"),a=r==null?void 0:r.getAttribute("data-node-id"),c=(r==null?void 0:r.getAttribute("data-type"))||"";r&&a&&(this.currentDocId||(this.currentDocId=this.resolveDocIdFromElement(o)||""),this.currentDocId&&!this.latestCompiledDoc&&this.compileCurrentDocument(this.currentDocId),a!==this.activeCursorBlockId&&(this.activeCursorBlockId=a,ms(a)),this.syncInspectorBlock(r,a,c))}async syncInspectorBlock(e,n,o){await $i.syncInspectorBlock(e,n,o,this.currentDocId,this.latestCompiledDoc)}async compileCurrentDocument(e){let n=e||this.currentDocId;if(!n){const o=this.getActiveDocumentId();if(o)this.currentDocId=o,n=o;else return}try{const o=await Lt.compile(n);this.latestCompiledDoc=o,dy(o,n),this.purgeStaleDomSlidevAttrs(o)}catch(o){console.error("[SiYuanSlidev] Failed to compile document:",o)}}purgeStaleDomSlidevAttrs(e){$i.purgeStaleDomSlidevAttrs(e)}}module.exports=by;
