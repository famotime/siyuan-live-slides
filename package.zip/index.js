"use strict";var Td=Object.defineProperty;var Ad=(e,t,o)=>t in e?Td(e,t,{enumerable:!0,configurable:!0,writable:!0,value:o}):e[t]=o;var Ie=(e,t,o)=>Ad(e,typeof t!="symbol"?t+"":t,o);const ie=require("siyuan");async function Dt(e,t){const o=await ie.fetchSyncPost(e,t);return o.code===0?o.data:null}async function Md(){return Dt("/api/notebook/lsNotebooks","")}async function Ed(e,t,o){return Dt("/api/filetree/createDocWithMd",{notebook:e,path:t,markdown:o})}async function Fa(e,t){const o=new FormData;o.append("assetsDirPath",e);for(const n of t)o.append("file[]",n);return Dt("/api/asset/upload",o)}async function mo(e,t,o,i,n){return Dt("/api/block/insertBlock",{dataType:e,data:t,nextID:o,previousID:i,parentID:n})}async function vn(e,t,o){return Dt("/api/block/appendBlock",{dataType:e,data:t,parentID:o})}async function Ms(e,t,o){return Dt("/api/block/updateBlock",{dataType:e,data:t,id:o})}async function Qs(e){return Dt("/api/block/deleteBlock",{id:e})}async function Dr(e){return Dt("/api/transactions",{reqId:Date.now(),transactions:e})}async function Bd(e){return Dt("/api/block/getBlockKramdown",{id:e})}async function Ci(e){return Dt("/api/block/getChildBlocks",{id:e})}async function Ld(e){return Dt("/api/block/getDocBlocksOrders",{id:e})}async function ze(e,t){return Dt("/api/attr/setBlockAttrs",{id:e,attrs:t})}async function er(e){return Dt("/api/attr/getBlockAttrs",{id:e})}async function ki(e){return Dt("/api/query/sql",{stmt:e})}async function ja(e,t="GET",o={},i=[],n=15e3,s="application/json"){const l=await ie.fetchSyncPost("/api/network/forwardProxy",{url:e,method:t,timeout:n,contentType:s,headers:i,payload:o});if(!l||l.code!==0){const r=(l==null?void 0:l.msg)||"思源内核代理转发请求失败";throw new Error(r)}return l.data}async function Dd(){return Dt("/api/storage/getInlineStyles","")}function Nr(e){return e.markdown&&e.markdown.trim()?e.markdown.trim():e.content&&e.content.trim()?e.content.trim():""}function Ua(e){const t={};if(!e)return t;const o=e.replace(/^\{:\s*/,"").replace(/\s*\}$/,""),i=/([\w-]+)=(?:"([^"]*)"|'([^']*)'|(\S+))/g;let n;for(;(n=i.exec(o))!==null;){const s=n[1],l=n[2]??n[3]??n[4]??"";t[s]=l}return t}const Wa=/\(\(([0-9a-zA-Z-]+)(?:\s*(?:'([^']*)'|"([^"]*)"|([^\)]+?)))?\s*\)\)/g;function Nd(e){const t=[];if(!e)return t;const o=new RegExp(Wa.source,"g");let i;for(;(i=o.exec(e))!==null;){const n=i[2]??i[3]??i[4];t.push({fullMatch:i[0],blockId:i[1],anchorText:n?n.trim():void 0})}return t}function Od(e,t){if(!e)return"";const o=new RegExp(Wa.source,"g");return e.replace(o,(i,n,s,l,r)=>{const a=(s??l??r??"").trim();if(t&&t[n]){const u=t[n].trim();return`<div class="slides-block-ref" data-ref-id="${n}">${u}</div>`}const c=a||`Ref(${n.slice(0,8)})`;return`<a href="siyuan://blocks/${n}" data-ref-id="${n}" class="slides-ref-tag">🔗 ${c}</a>`})}const Vi="custom-slides-theme",Ki="custom-slides-aspect-ratio",Gi="custom-slides-default-transition",qa="custom-slides-color-schema",Es="custom-slides-spacing",Mn="custom-slides-background",Or="custom-slides-show-unordered-list-markers",Pr="custom-slides-show-ordered-list-markers",yo="custom-slides-slide",be="custom-slides-layout",It="custom-slides-transition",dt="custom-slides-background",Kt="custom-slides-image",cs="custom-slides-notes",ci="custom-slides-class",Pi="custom-slides-spacing",bt="custom-slides-layout-ratio",di="custom-slides-mask",Xo="custom-slides-mask-ratio",ui="custom-slides-mask-style",fi="custom-slides-mask-initial",Ne="custom-slides-click",Bt="custom-slides-motion",ti="custom-slides-shiki-lines",Ae="custom-slides-slot",Fe="custom-slides-note",Ze="custom-slides-role",Yi="custom-slides-max-height",Zo="custom-slides-autoplay",En="custom-slides-loop",li="custom-slides-muted",Bn="custom-slides-controls",Va="background",Ln="image-left",Dn="image-right";function pi(e){return e==="cols-header"||e==="two-cols-header"||e==="three-cols-header"}function Pd(e,t=2){const o=t===4?[25,50,75,100]:[50,100],i=t===4?4:2;if(!e||typeof e!="string")return{steps:i,breakpoints:o};const n=e.trim();if(!n||t===4&&(n==="1:1"||n==="1"))return{steps:i,breakpoints:o};const s=n.split(":").map(h=>parseFloat(h.trim())).filter(h=>!isNaN(h)&&h>0);if(s.length===0)return{steps:i,breakpoints:o};if(s.length===1){const h=Math.min(100,Math.max(1,s[0]));return h===100?{steps:1,breakpoints:[100]}:{steps:2,breakpoints:[Math.round(h*100)/100,100]}}const l=s.every((h,d)=>d===0||h>s[d-1]),r=s[s.length-1];if(l&&(r===100||s.some(h=>h>10))){const h=s.map(d=>Math.min(100,Math.round(d*100)/100));return h[h.length-1]<100&&h.push(100),{steps:h.length,breakpoints:h}}const c=s.reduce((h,d)=>h+d,0);if(c<=0)return{steps:i,breakpoints:o};let u=0;const f=[];for(let h=0;h<s.length;h++)u+=s[h],h===s.length-1?f.push(100):f.push(Math.round(u/c*1e4)/100);return{steps:f.length,breakpoints:f}}function Ka(e){if(!e)return!1;const t=e.trim();return t.startsWith("assets/")||t.startsWith("./assets/")||t.startsWith("/assets/")}function Ga(e){const t=e.trim();return t.startsWith("./assets/")?t.slice(2):t.startsWith("/assets/")?t.slice(1):t}function Ot(e,t){if(!Ka(e))return e;const o=Ga(e);return t!=null&&t.base64Map&&t.base64Map[o]?t.base64Map[o]:t!=null&&t.baseUrl?`${t.baseUrl.replace(/\/+$/,"")}/${o}`:`/${o}`}function Rd(e,t){if(!e)return"";let o=e;return o=o.replace(/!\[(.*?)\]\(((?:\.\/|\/)?assets\/[^\s)]+)\)/g,(i,n,s)=>{const l=Ot(s,t);return`![${n}](${l})`}),o=o.replace(/(<(?:img|video|audio|source)\b[^>]*?\bsrc=["'])((?:\.\/|\/)?assets\/[^"']+)(["'][^>]*>)/gi,(i,n,s,l)=>{const r=Ot(s,t);return`${n}${r}${l}`}),o=o.replace(/(url\(\s*["']?)((?:\.\/|\/)?assets\/[^"')]+)(["']?\s*\))/gi,(i,n,s,l)=>{const r=Ot(s,t);return`${n}${r}${l}`}),o}/**
* @vue/shared v3.5.40
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/function tr(e){const t=Object.create(null);for(const o of e.split(","))t[o]=1;return o=>o in t}const Je={},hi=[],ao=()=>{},Ya=()=>!1,qn=e=>e.charCodeAt(0)===111&&e.charCodeAt(1)===110&&(e.charCodeAt(2)>122||e.charCodeAt(2)<97),Vn=e=>e.startsWith("onUpdate:"),kt=Object.assign,or=(e,t)=>{const o=e.indexOf(t);o>-1&&e.splice(o,1)},zd=Object.prototype.hasOwnProperty,Ue=(e,t)=>zd.call(e,t),Me=Array.isArray,mi=e=>on(e)==="[object Map]",_i=e=>on(e)==="[object Set]",Rr=e=>on(e)==="[object Date]",Le=e=>typeof e=="function",st=e=>typeof e=="string",Jt=e=>typeof e=="symbol",Ke=e=>e!==null&&typeof e=="object",Za=e=>(Ke(e)||Le(e))&&Le(e.then)&&Le(e.catch),Ja=Object.prototype.toString,on=e=>Ja.call(e),Hd=e=>on(e).slice(8,-1),Xa=e=>on(e)==="[object Object]",ir=e=>st(e)&&e!=="NaN"&&e[0]!=="-"&&""+parseInt(e,10)===e,Ri=tr(",key,ref,ref_for,ref_key,onVnodeBeforeMount,onVnodeMounted,onVnodeBeforeUpdate,onVnodeUpdated,onVnodeBeforeUnmount,onVnodeUnmounted"),Kn=e=>{const t=Object.create(null);return(o=>t[o]||(t[o]=e(o)))},Fd=/-\w/g,Lt=Kn(e=>e.replace(Fd,t=>t.slice(1).toUpperCase())),jd=/\B([A-Z])/g,qo=Kn(e=>e.replace(jd,"-$1").toLowerCase()),Gn=Kn(e=>e.charAt(0).toUpperCase()+e.slice(1)),ds=Kn(e=>e?`on${Gn(e)}`:""),no=(e,t)=>!Object.is(e,t),kn=(e,...t)=>{for(let o=0;o<e.length;o++)e[o](...t)},Qa=(e,t,o,i=!1)=>{Object.defineProperty(e,t,{configurable:!0,enumerable:!1,writable:i,value:o})},Yn=e=>{const t=parseFloat(e);return isNaN(t)?e:t};let zr;const Zn=()=>zr||(zr=typeof globalThis<"u"?globalThis:typeof self<"u"?self:typeof window<"u"?window:typeof global<"u"?global:{});function so(e){if(Me(e)){const t={};for(let o=0;o<e.length;o++){const i=e[o],n=st(i)?Vd(i):so(i);if(n)for(const s in n)t[s]=n[s]}return t}else if(st(e)||Ke(e))return e}const Ud=/;(?![^(]*\))/g,Wd=/:([^]+)/,qd=/\/\*[^]*?\*\//g;function Vd(e){const t={};return e.replace(qd,"").split(Ud).forEach(o=>{if(o){const i=o.split(Wd);i.length>1&&(t[i[0].trim()]=i[1].trim())}}),t}function xe(e){let t="";if(st(e))t=e;else if(Me(e))for(let o=0;o<e.length;o++){const i=xe(e[o]);i&&(t+=i+" ")}else if(Ke(e))for(const o in e)e[o]&&(t+=o+" ");return t.trim()}const Kd="itemscope,allowfullscreen,formnovalidate,ismap,nomodule,novalidate,readonly",Gd=tr(Kd);function el(e){return!!e||e===""}function Yd(e,t){if(e.length!==t.length)return!1;let o=!0;for(let i=0;o&&i<e.length;i++)o=Ii(e[i],t[i]);return o}function Ii(e,t){if(e===t)return!0;let o=Rr(e),i=Rr(t);if(o||i)return o&&i?e.getTime()===t.getTime():!1;if(o=Jt(e),i=Jt(t),o||i)return e===t;if(o=Me(e),i=Me(t),o||i)return o&&i?Yd(e,t):!1;if(o=Ke(e),i=Ke(t),o||i){if(!o||!i)return!1;const n=Object.keys(e).length,s=Object.keys(t).length;if(n!==s)return!1;for(const l in e){const r=e.hasOwnProperty(l),a=t.hasOwnProperty(l);if(r&&!a||!r&&a||!Ii(e[l],t[l]))return!1}}return String(e)===String(t)}function nr(e,t){return e.findIndex(o=>Ii(o,t))}const tl=e=>!!(e&&e.__v_isRef===!0),ve=e=>st(e)?e:e==null?"":Me(e)||Ke(e)&&(e.toString===Ja||!Le(e.toString))?tl(e)?ve(e.value):JSON.stringify(e,ol,2):String(e),ol=(e,t)=>tl(t)?ol(e,t.value):mi(t)?{[`Map(${t.size})`]:[...t.entries()].reduce((o,[i,n],s)=>(o[us(i,s)+" =>"]=n,o),{})}:_i(t)?{[`Set(${t.size})`]:[...t.values()].map(o=>us(o))}:Jt(t)?us(t):Ke(t)&&!Me(t)&&!Xa(t)?String(t):t,us=(e,t="")=>{var o;return Jt(e)?`Symbol(${(o=e.description)!=null?o:t})`:e};/**
* @vue/reactivity v3.5.40
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/let yt;class Zd{constructor(t=!1){this.detached=t,this._active=!0,this._on=0,this.effects=[],this.cleanups=[],this._isPaused=!1,this._warnOnRun=!0,this.__v_skip=!0,!t&&yt&&(yt.active?(this.parent=yt,this.index=(yt.scopes||(yt.scopes=[])).push(this)-1):(this._active=!1,this._warnOnRun=!1))}get active(){return this._active}pause(){if(this._active){this._isPaused=!0;let t,o;if(this.scopes){const i=this.scopes.slice();for(t=0,o=i.length;t<o;t++)i[t].pause()}for(t=0,o=this.effects.length;t<o;t++)this.effects[t].pause()}}resume(){if(this._active&&this._isPaused){this._isPaused=!1;let t,o;if(this.scopes){const n=this.scopes.slice();for(t=0,o=n.length;t<o;t++)n[t].resume()}const i=this.effects.slice();for(t=0,o=i.length;t<o;t++)i[t].resume()}}run(t){if(this._active){const o=yt;try{return yt=this,t()}finally{yt=o}}}on(){++this._on===1&&(this.prevScope=yt,yt=this)}off(){if(this._on>0&&--this._on===0){if(yt===this)yt=this.prevScope;else{let t=yt;for(;t;){if(t.prevScope===this){t.prevScope=this.prevScope;break}t=t.prevScope}}this.prevScope=void 0}}stop(t){if(this._active){this._active=!1;let o,i;for(o=0,i=this.effects.length;o<i;o++)this.effects[o].stop();for(this.effects.length=0,o=0,i=this.cleanups.length;o<i;o++)this.cleanups[o]();if(this.cleanups.length=0,this.scopes){const n=this.scopes.slice();for(o=0,i=n.length;o<i;o++)n[o].stop(!0);this.scopes.length=0}if(!this.detached&&this.parent&&!t){const n=this.parent.scopes.pop();n&&n!==this&&(this.parent.scopes[this.index]=n,n.index=this.index)}this.parent=void 0}}}function Jd(){return yt}let Xe;const fs=new WeakSet;class il{constructor(t){this.fn=t,this.deps=void 0,this.depsTail=void 0,this.flags=5,this.next=void 0,this.cleanup=void 0,this.scheduler=void 0,yt&&(yt.active?yt.effects.push(this):this.flags&=-2)}pause(){this.flags|=64}resume(){this.flags&64&&(this.flags&=-65,fs.has(this)&&(fs.delete(this),this.trigger()))}notify(){this.flags&2&&!(this.flags&32)||this.flags&8||sl(this)}run(){if(!(this.flags&1))return this.fn();this.flags|=2,Hr(this),rl(this);const t=Xe,o=Yt;Xe=this,Yt=!0;try{return this.fn()}finally{al(this),Xe=t,Yt=o,this.flags&=-3}}stop(){if(this.flags&1){for(let t=this.deps;t;t=t.nextDep)ar(t);this.deps=this.depsTail=void 0,Hr(this),this.onStop&&this.onStop(),this.flags&=-2}}trigger(){this.flags&64?fs.add(this):this.scheduler?this.scheduler():this.runIfDirty()}runIfDirty(){Bs(this)&&this.run()}get dirty(){return Bs(this)}}let nl=0,zi,Hi;function sl(e,t=!1){if(e.flags|=8,t){e.next=Hi,Hi=e;return}e.next=zi,zi=e}function sr(){nl++}function rr(){if(--nl>0)return;if(Hi){let t=Hi;for(Hi=void 0;t;){const o=t.next;t.next=void 0,t.flags&=-9,t=o}}let e;for(;zi;){let t=zi;for(zi=void 0;t;){const o=t.next;if(t.next=void 0,t.flags&=-9,t.flags&1)try{t.trigger()}catch(i){e||(e=i)}t=o}}if(e)throw e}function rl(e){for(let t=e.deps;t;t=t.nextDep)t.version=-1,t.prevActiveLink=t.dep.activeLink,t.dep.activeLink=t}function al(e){let t,o=e.depsTail,i=o;for(;i;){const n=i.prevDep;i.version===-1?(i===o&&(o=n),ar(i),Xd(i)):t=i,i.dep.activeLink=i.prevActiveLink,i.prevActiveLink=void 0,i=n}e.deps=t,e.depsTail=o}function Bs(e){for(let t=e.deps;t;t=t.nextDep)if(t.dep.version!==t.version||t.dep.computed&&(ll(t.dep.computed)||t.dep.version!==t.version))return!0;return!!e._dirty}function ll(e){if(e.flags&4&&!(e.flags&16)||(e.flags&=-17,e.globalVersion===Zi)||(e.globalVersion=Zi,!e.isSSR&&e.flags&128&&(!e.deps&&!e._dirty||!Bs(e))))return;e.flags|=2;const t=e.dep,o=Xe,i=Yt;Xe=e,Yt=!0;try{rl(e);const n=e.fn(e._value);(t.version===0||no(n,e._value))&&(e.flags|=128,e._value=n,t.version++)}catch(n){throw t.version++,n}finally{Xe=o,Yt=i,al(e),e.flags&=-3}}function ar(e,t=!1){const{dep:o,prevSub:i,nextSub:n}=e;if(i&&(i.nextSub=n,e.prevSub=void 0),n&&(n.prevSub=i,e.nextSub=void 0),o.subs===e&&(o.subs=i,!i&&o.computed)){o.computed.flags&=-5;for(let s=o.computed.deps;s;s=s.nextDep)ar(s,!0)}!t&&!--o.sc&&o.map&&o.map.delete(o.key)}function Xd(e){const{prevDep:t,nextDep:o}=e;t&&(t.nextDep=o,e.prevDep=void 0),o&&(o.prevDep=t,e.nextDep=void 0)}let Yt=!0;const cl=[];function _o(){cl.push(Yt),Yt=!1}function Io(){const e=cl.pop();Yt=e===void 0?!0:e}function Hr(e){const{cleanup:t}=e;if(e.cleanup=void 0,t){const o=Xe;Xe=void 0;try{t()}finally{Xe=o}}}let Zi=0;class Qd{constructor(t,o){this.sub=t,this.dep=o,this.version=o.version,this.nextDep=this.prevDep=this.nextSub=this.prevSub=this.prevActiveLink=void 0}}class lr{constructor(t){this.computed=t,this.version=0,this.activeLink=void 0,this.subs=void 0,this.map=void 0,this.key=void 0,this.sc=0,this.__v_skip=!0}track(t){if(!Xe||!Yt||Xe===this.computed)return;let o=this.activeLink;if(o===void 0||o.sub!==Xe)o=this.activeLink=new Qd(Xe,this),Xe.deps?(o.prevDep=Xe.depsTail,Xe.depsTail.nextDep=o,Xe.depsTail=o):Xe.deps=Xe.depsTail=o,dl(o);else if(o.version===-1&&(o.version=this.version,o.nextDep)){const i=o.nextDep;i.prevDep=o.prevDep,o.prevDep&&(o.prevDep.nextDep=i),o.prevDep=Xe.depsTail,o.nextDep=void 0,Xe.depsTail.nextDep=o,Xe.depsTail=o,Xe.deps===o&&(Xe.deps=i)}return o}trigger(t){this.version++,Zi++,this.notify(t)}notify(t){sr();try{for(let o=this.subs;o;o=o.prevSub)o.sub.notify()&&o.sub.dep.notify()}finally{rr()}}}function dl(e){if(e.dep.sc++,e.sub.flags&4){const t=e.dep.computed;if(t&&!e.dep.subs){t.flags|=20;for(let i=t.deps;i;i=i.nextDep)dl(i)}const o=e.dep.subs;o!==e&&(e.prevSub=o,o&&(o.nextSub=e)),e.dep.subs=e}}const Ls=new WeakMap,Qo=Symbol(""),Ds=Symbol(""),Ji=Symbol("");function Ct(e,t,o){if(Yt&&Xe){let i=Ls.get(e);i||Ls.set(e,i=new Map);let n=i.get(o);n||(i.set(o,n=new lr),n.map=i,n.key=o),n.track()}}function bo(e,t,o,i,n,s){const l=Ls.get(e);if(!l){Zi++;return}const r=a=>{a&&a.trigger()};if(sr(),t==="clear")l.forEach(r);else{const a=Me(e),c=a&&ir(o);if(a&&o==="length"){const u=Number(i);l.forEach((f,h)=>{(h==="length"||h===Ji||!Jt(h)&&h>=u)&&r(f)})}else switch((o!==void 0||l.has(void 0))&&r(l.get(o)),c&&r(l.get(Ji)),t){case"add":a?c&&r(l.get("length")):(r(l.get(Qo)),mi(e)&&r(l.get(Ds)));break;case"delete":a||(r(l.get(Qo)),mi(e)&&r(l.get(Ds)));break;case"set":mi(e)&&r(l.get(Qo));break}}rr()}function ni(e){const t=je(e);return t===e?t:(Ct(t,"iterate",Ji),Wt(e)?t:t.map(Xt))}function Jn(e){return Ct(e=je(e),"iterate",Ji),e}function oo(e,t){return $o(e)?wi(ei(e)?Xt(t):t):Xt(t)}const eu={__proto__:null,[Symbol.iterator](){return ps(this,Symbol.iterator,e=>oo(this,e))},concat(...e){return ni(this).concat(...e.map(t=>Me(t)?ni(t):t))},entries(){return ps(this,"entries",e=>(e[1]=oo(this,e[1]),e))},every(e,t){return po(this,"every",e,t,void 0,arguments)},filter(e,t){return po(this,"filter",e,t,o=>o.map(i=>oo(this,i)),arguments)},find(e,t){return po(this,"find",e,t,o=>oo(this,o),arguments)},findIndex(e,t){return po(this,"findIndex",e,t,void 0,arguments)},findLast(e,t){return po(this,"findLast",e,t,o=>oo(this,o),arguments)},findLastIndex(e,t){return po(this,"findLastIndex",e,t,void 0,arguments)},forEach(e,t){return po(this,"forEach",e,t,void 0,arguments)},includes(...e){return hs(this,"includes",e)},indexOf(...e){return hs(this,"indexOf",e)},join(e){return ni(this).join(e)},lastIndexOf(...e){return hs(this,"lastIndexOf",e)},map(e,t){return po(this,"map",e,t,void 0,arguments)},pop(){return Ei(this,"pop")},push(...e){return Ei(this,"push",e)},reduce(e,...t){return Fr(this,"reduce",e,t)},reduceRight(e,...t){return Fr(this,"reduceRight",e,t)},shift(){return Ei(this,"shift")},some(e,t){return po(this,"some",e,t,void 0,arguments)},splice(...e){return Ei(this,"splice",e)},toReversed(){return ni(this).toReversed()},toSorted(e){return ni(this).toSorted(e)},toSpliced(...e){return ni(this).toSpliced(...e)},unshift(...e){return Ei(this,"unshift",e)},values(){return ps(this,"values",e=>oo(this,e))}};function ps(e,t,o){const i=Jn(e),n=i[t]();return i!==e&&!Wt(e)&&(n._next=n.next,n.next=()=>{const s=n._next();return s.done||(s.value=o(s.value)),s}),n}const tu=Array.prototype;function po(e,t,o,i,n,s){const l=Jn(e),r=l!==e&&!Wt(e),a=l[t];if(a!==tu[t]){const f=a.apply(e,s);return r?Xt(f):f}let c=o;l!==e&&(r?c=function(f,h){return o.call(this,oo(e,f),h,e)}:o.length>2&&(c=function(f,h){return o.call(this,f,h,e)}));const u=a.call(l,c,i);return r&&n?n(u):u}function Fr(e,t,o,i){const n=Jn(e),s=n!==e&&!Wt(e);let l=o,r=!1;n!==e&&(s?(r=i.length===0,l=function(c,u,f){return r&&(r=!1,c=oo(e,c)),o.call(this,c,oo(e,u),f,e)}):o.length>3&&(l=function(c,u,f){return o.call(this,c,u,f,e)}));const a=n[t](l,...i);return r?oo(e,a):a}function hs(e,t,o){const i=je(e);Ct(i,"iterate",Ji);const n=i[t](...o);return(n===-1||n===!1)&&ur(o[0])?(o[0]=je(o[0]),i[t](...o)):n}function Ei(e,t,o=[]){_o(),sr();const i=je(e)[t].apply(e,o);return rr(),Io(),i}const ou=tr("__proto__,__v_isRef,__isVue"),ul=new Set(Object.getOwnPropertyNames(Symbol).filter(e=>e!=="arguments"&&e!=="caller").map(e=>Symbol[e]).filter(Jt));function iu(e){Jt(e)||(e=String(e));const t=je(this);return Ct(t,"has",e),t.hasOwnProperty(e)}class fl{constructor(t=!1,o=!1){this._isReadonly=t,this._isShallow=o}get(t,o,i){if(o==="__v_skip")return t.__v_skip;const n=this._isReadonly,s=this._isShallow;if(o==="__v_isReactive")return!n;if(o==="__v_isReadonly")return n;if(o==="__v_isShallow")return s;if(o==="__v_raw")return i===(n?s?pu:gl:s?ml:hl).get(t)||Object.getPrototypeOf(t)===Object.getPrototypeOf(i)?t:void 0;const l=Me(t);if(!n){let a;if(l&&(a=eu[o]))return a;if(o==="hasOwnProperty")return iu}const r=Reflect.get(t,o,ot(t)?t:i);if((Jt(o)?ul.has(o):ou(o))||(n||Ct(t,"get",o),s))return r;if(ot(r)){const a=l&&ir(o)?r:r.value;return n&&Ke(a)?Os(a):a}return Ke(r)?n?Os(r):Xn(r):r}}class pl extends fl{constructor(t=!1){super(!1,t)}set(t,o,i,n){let s=t[o];const l=Me(t)&&ir(o);if(!this._isShallow){const c=$o(s);if(!Wt(i)&&!$o(i)&&(s=je(s),i=je(i)),!l&&ot(s)&&!ot(i))return c||(s.value=i),!0}const r=l?Number(o)<t.length:Ue(t,o),a=Reflect.set(t,o,i,ot(t)?t:n);return t===je(n)&&a&&(r?no(i,s)&&bo(t,"set",o,i):bo(t,"add",o,i)),a}deleteProperty(t,o){const i=Ue(t,o);t[o];const n=Reflect.deleteProperty(t,o);return n&&i&&bo(t,"delete",o,void 0),n}has(t,o){const i=Reflect.has(t,o);return(!Jt(o)||!ul.has(o))&&Ct(t,"has",o),i}ownKeys(t){return Ct(t,"iterate",Me(t)?"length":Qo),Reflect.ownKeys(t)}}class nu extends fl{constructor(t=!1){super(!0,t)}set(t,o){return!0}deleteProperty(t,o){return!0}}const su=new pl,ru=new nu,au=new pl(!0);const Ns=e=>e,dn=e=>Reflect.getPrototypeOf(e);function lu(e,t,o){return function(...i){const n=this.__v_raw,s=je(n),l=mi(s),r=e==="entries"||e===Symbol.iterator&&l,a=e==="keys"&&l,c=n[e](...i),u=o?Ns:t?wi:Xt;return!t&&Ct(s,"iterate",a?Ds:Qo),kt(Object.create(c),{next(){const{value:f,done:h}=c.next();return h?{value:f,done:h}:{value:r?[u(f[0]),u(f[1])]:u(f),done:h}}})}}function un(e){return function(...t){return e==="delete"?!1:e==="clear"?void 0:this}}function cu(e,t){const o={get(n){const s=this.__v_raw,l=je(s),r=je(n);e||(no(n,r)&&Ct(l,"get",n),Ct(l,"get",r));const{has:a}=dn(l),c=t?Ns:e?wi:Xt;if(a.call(l,n))return c(s.get(n));if(a.call(l,r))return c(s.get(r));s!==l&&s.get(n)},get size(){const n=this.__v_raw;return!e&&Ct(je(n),"iterate",Qo),n.size},has(n){const s=this.__v_raw,l=je(s),r=je(n);return e||(no(n,r)&&Ct(l,"has",n),Ct(l,"has",r)),n===r?s.has(n):s.has(n)||s.has(r)},forEach(n,s){const l=this,r=l.__v_raw,a=je(r),c=t?Ns:e?wi:Xt;return!e&&Ct(a,"iterate",Qo),r.forEach((u,f)=>n.call(s,c(u),c(f),l))}};return kt(o,e?{add:un("add"),set:un("set"),delete:un("delete"),clear:un("clear")}:{add(n){const s=je(this),l=dn(s),r=je(n),a=!t&&!Wt(n)&&!$o(n)?r:n;return l.has.call(s,a)||no(n,a)&&l.has.call(s,n)||no(r,a)&&l.has.call(s,r)||(s.add(a),bo(s,"add",a,a)),this},set(n,s){!t&&!Wt(s)&&!$o(s)&&(s=je(s));const l=je(this),{has:r,get:a}=dn(l);let c=r.call(l,n);c||(n=je(n),c=r.call(l,n));const u=a.call(l,n);return l.set(n,s),c?no(s,u)&&bo(l,"set",n,s):bo(l,"add",n,s),this},delete(n){const s=je(this),{has:l,get:r}=dn(s);let a=l.call(s,n);a||(n=je(n),a=l.call(s,n)),r&&r.call(s,n);const c=s.delete(n);return a&&bo(s,"delete",n,void 0),c},clear(){const n=je(this),s=n.size!==0,l=n.clear();return s&&bo(n,"clear",void 0,void 0),l}}),["keys","values","entries",Symbol.iterator].forEach(n=>{o[n]=lu(n,e,t)}),o}function cr(e,t){const o=cu(e,t);return(i,n,s)=>n==="__v_isReactive"?!e:n==="__v_isReadonly"?e:n==="__v_raw"?i:Reflect.get(Ue(o,n)&&n in i?o:i,n,s)}const du={get:cr(!1,!1)},uu={get:cr(!1,!0)},fu={get:cr(!0,!1)};const hl=new WeakMap,ml=new WeakMap,gl=new WeakMap,pu=new WeakMap;function hu(e){switch(e){case"Object":case"Array":return 1;case"Map":case"Set":case"WeakMap":case"WeakSet":return 2;default:return 0}}function Xn(e){return $o(e)?e:dr(e,!1,su,du,hl)}function mu(e){return dr(e,!1,au,uu,ml)}function Os(e){return dr(e,!0,ru,fu,gl)}function dr(e,t,o,i,n){if(!Ke(e)||e.__v_raw&&!(t&&e.__v_isReactive)||e.__v_skip||!Object.isExtensible(e))return e;const s=n.get(e);if(s)return s;const l=hu(Hd(e));if(l===0)return e;const r=new Proxy(e,l===2?i:o);return n.set(e,r),r}function ei(e){return $o(e)?ei(e.__v_raw):!!(e&&e.__v_isReactive)}function $o(e){return!!(e&&e.__v_isReadonly)}function Wt(e){return!!(e&&e.__v_isShallow)}function ur(e){return e?!!e.__v_raw:!1}function je(e){const t=e&&e.__v_raw;return t?je(t):e}function gu(e){return!Ue(e,"__v_skip")&&Object.isExtensible(e)&&Qa(e,"__v_skip",!0),e}const Xt=e=>Ke(e)?Xn(e):e,wi=e=>Ke(e)?Os(e):e;function ot(e){return e?e.__v_isRef===!0:!1}function he(e){return yu(e,!1)}function yu(e,t){return ot(e)?e:new bu(e,t)}class bu{constructor(t,o){this.dep=new lr,this.__v_isRef=!0,this.__v_isShallow=!1,this._rawValue=o?t:je(t),this._value=o?t:Xt(t),this.__v_isShallow=o}get value(){return this.dep.track(),this._value}set value(t){const o=this._rawValue,i=this.__v_isShallow||Wt(t)||$o(t);t=i?t:je(t),no(t,o)&&(this._rawValue=t,this._value=i?t:Xt(t),this.dep.trigger())}}function de(e){return ot(e)?e.value:e}const vu={get:(e,t,o)=>t==="__v_raw"?e:de(Reflect.get(e,t,o)),set:(e,t,o,i)=>{const n=e[t];return ot(n)&&!ot(o)?(n.value=o,!0):Reflect.set(e,t,o,i)}};function yl(e){return ei(e)?e:new Proxy(e,vu)}class ku{constructor(t,o,i){this.fn=t,this.setter=o,this._value=void 0,this.dep=new lr(this),this.__v_isRef=!0,this.deps=void 0,this.depsTail=void 0,this.flags=16,this.globalVersion=Zi-1,this.next=void 0,this.effect=this,this.__v_isReadonly=!o,this.isSSR=i}notify(){if(this.flags|=16,!(this.flags&8)&&Xe!==this)return sl(this,!0),!0}get value(){const t=this.dep.track();return ll(this),t&&(t.version=this.dep.version),this._value}set value(t){this.setter&&this.setter(t)}}function wu(e,t,o=!1){let i,n;return Le(e)?i=e:(i=e.get,n=e.set),new ku(i,n,o)}const fn={},Nn=new WeakMap;let Yo;function xu(e,t=!1,o=Yo){if(o){let i=Nn.get(o);i||Nn.set(o,i=[]),i.push(e)}}function Su(e,t,o=Je){const{immediate:i,deep:n,once:s,scheduler:l,augmentJob:r,call:a}=o,c=I=>n?I:Wt(I)||n===!1||n===0?vo(I,1):vo(I);let u,f,h,d,b=!1,m=!1;if(ot(e)?(f=()=>e.value,b=Wt(e)):ei(e)?(f=()=>c(e),b=!0):Me(e)?(m=!0,b=e.some(I=>ei(I)||Wt(I)),f=()=>e.map(I=>{if(ot(I))return I.value;if(ei(I))return c(I);if(Le(I))return a?a(I,2):I()})):Le(e)?t?f=a?()=>a(e,2):e:f=()=>{if(h){_o();try{h()}finally{Io()}}const I=Yo;Yo=u;try{return a?a(e,3,[d]):e(d)}finally{Yo=I}}:f=ao,t&&n){const I=f,T=n===!0?1/0:n;f=()=>vo(I(),T)}const y=Jd(),g=()=>{u.stop(),y&&y.active&&or(y.effects,u)};if(s&&t){const I=t;t=(...T)=>{const w=I(...T);return g(),w}}let x=m?new Array(e.length).fill(fn):fn;const k=I=>{if(!(!(u.flags&1)||!u.dirty&&!I))if(t){const T=u.run();if(I||n||b||(m?T.some((w,C)=>no(w,x[C])):no(T,x))){h&&h();const w=Yo;Yo=u;try{const C=[T,x===fn?void 0:m&&x[0]===fn?[]:x,d];x=T,a?a(t,3,C):t(...C)}finally{Yo=w}}}else u.run()};return r&&r(k),u=new il(f),u.scheduler=l?()=>l(k,!1):k,d=I=>xu(I,!1,u),h=u.onStop=()=>{const I=Nn.get(u);if(I){if(a)a(I,4);else for(const T of I)T();Nn.delete(u)}},t?i?k(!0):x=u.run():l?l(k.bind(null,!0),!0):u.run(),g.pause=u.pause.bind(u),g.resume=u.resume.bind(u),g.stop=g,g}function vo(e,t=1/0,o){if(t<=0||!Ke(e)||e.__v_skip||(o=o||new Map,(o.get(e)||0)>=t))return e;if(o.set(e,t),t--,ot(e))vo(e.value,t,o);else if(Me(e))for(let i=0;i<e.length;i++)vo(e[i],t,o);else if(_i(e)||mi(e))e.forEach(i=>{vo(i,t,o)});else if(Xa(e)){for(const i in e)vo(e[i],t,o);for(const i of Object.getOwnPropertySymbols(e))Object.prototype.propertyIsEnumerable.call(e,i)&&vo(e[i],t,o)}return e}/**
* @vue/runtime-core v3.5.40
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/function nn(e,t,o,i){try{return i?e(...i):e()}catch(n){Qn(n,t,o)}}function Qt(e,t,o,i){if(Le(e)){const n=nn(e,t,o,i);return n&&Za(n)&&n.catch(s=>{Qn(s,t,o)}),n}if(Me(e)){const n=[];for(let s=0;s<e.length;s++)n.push(Qt(e[s],t,o,i));return n}}function Qn(e,t,o,i=!0){const n=t?t.vnode:null,{errorHandler:s,throwUnhandledErrorInProduction:l}=t&&t.appContext.config||Je;if(t){let r=t.parent;const a=t.proxy,c=`https://vuejs.org/error-reference/#runtime-${o}`;for(;r;){const u=r.ec;if(u){for(let f=0;f<u.length;f++)if(u[f](e,a,c)===!1)return}r=r.parent}if(s){_o(),nn(s,null,10,[e,a,c]),Io();return}}Cu(e,o,n,i,l)}function Cu(e,t,o,i=!0,n=!1){if(n)throw e;console.error(e)}const Et=[];let to=-1;const gi=[];let Do=null,ri=0;const bl=Promise.resolve();let On=null;function Pn(e){const t=On||bl;return e?t.then(this?e.bind(this):e):t}function _u(e){let t=to+1,o=Et.length;for(;t<o;){const i=t+o>>>1,n=Et[i],s=Xi(n);s<e||s===e&&n.flags&2?t=i+1:o=i}return t}function fr(e){if(!(e.flags&1)){const t=Xi(e),o=Et[Et.length-1];!o||!(e.flags&2)&&t>=Xi(o)?Et.push(e):Et.splice(_u(t),0,e),e.flags|=1,vl()}}function vl(){On||(On=bl.then(wl))}function Iu(e){Me(e)?gi.push(...e):Do&&e.id===-1?Do.splice(ri+1,0,e):e.flags&1||(gi.push(e),e.flags|=1),vl()}function jr(e,t,o=to+1){for(;o<Et.length;o++){const i=Et[o];if(i&&i.flags&2){if(e&&i.id!==e.uid)continue;Et.splice(o,1),o--,i.flags&4&&(i.flags&=-2),i(),i.flags&4||(i.flags&=-2)}}}function kl(e){if(gi.length){const t=[...new Set(gi)].sort((o,i)=>Xi(o)-Xi(i));if(gi.length=0,Do){Do.push(...t);return}for(Do=t,ri=0;ri<Do.length;ri++){const o=Do[ri];o.flags&4&&(o.flags&=-2),o.flags&8||o(),o.flags&=-2}Do=null,ri=0}}const Xi=e=>e.id==null?e.flags&2?-1:1/0:e.id;function wl(e){try{for(to=0;to<Et.length;to++){const t=Et[to];t&&!(t.flags&8)&&(t.flags&4&&(t.flags&=-2),nn(t,t.i,t.i?15:14),t.flags&4||(t.flags&=-2))}}finally{for(;to<Et.length;to++){const t=Et[to];t&&(t.flags&=-2)}to=-1,Et.length=0,kl(),On=null,(Et.length||gi.length)&&wl()}}let vt=null,xl=null;function Rn(e){const t=vt;return vt=e,xl=e&&e.type.__scopeId||null,t}function Sl(e,t=vt,o){if(!t||e._n)return e;const i=(...n)=>{i._d&&ea(-1);const s=Rn(t),l=xo.length;let r;try{r=e(...n)}finally{for(let a=xo.length;a>l;a--)yr();Rn(s),i._d&&ea(1)}return r};return i._n=!0,i._c=!0,i._d=!0,i}function Vt(e,t){if(vt===null)return e;const o=is(vt),i=e.dirs||(e.dirs=[]);for(let n=0;n<t.length;n++){let[s,l,r,a=Je]=t[n];s&&(Le(s)&&(s={mounted:s,updated:s}),s.deep&&vo(l),i.push({dir:s,instance:o,value:l,oldValue:void 0,arg:r,modifiers:a}))}return e}function Vo(e,t,o,i){const n=e.dirs,s=t&&t.dirs;for(let l=0;l<n.length;l++){const r=n[l];s&&(r.oldValue=s[l].value);let a=r.dir[i];a&&(_o(),Qt(a,o,8,[e.el,r,e,t]),Io())}}function $u(e,t){if(Tt){let o=Tt.provides;const i=Tt.parent&&Tt.parent.provides;i===o&&(o=Tt.provides=Object.create(i)),o[e]=t}}function Zt(e,t,o=!1){const i=If();if(i||bi){let n=bi?bi._context.provides:i?i.parent==null||i.ce?i.vnode.appContext&&i.vnode.appContext.provides:i.parent.provides:void 0;if(n&&e in n)return n[e];if(arguments.length>1)return o&&Le(t)?t.call(i&&i.proxy):t}}const Tu=Symbol.for("v-scx"),Au=()=>Zt(Tu);function Fo(e,t,o){return Cl(e,t,o)}function Cl(e,t,o=Je){const{immediate:i,deep:n,flush:s,once:l}=o,r=kt({},o),a=t&&i||!t&&s!=="post";let c;if(en){if(s==="sync"){const d=Au();c=d.__watcherHandles||(d.__watcherHandles=[])}else if(!a){const d=()=>{};return d.stop=ao,d.resume=ao,d.pause=ao,d}}const u=Tt;r.call=(d,b,m)=>Qt(d,u,b,m);let f=!1;s==="post"?r.scheduler=d=>{Nt(d,u&&u.suspense)}:s!=="sync"&&(f=!0,r.scheduler=(d,b)=>{b?d():fr(d)}),r.augmentJob=d=>{t&&(d.flags|=4),f&&(d.flags|=2,u&&(d.id=u.uid,d.i=u))};const h=Su(e,t,r);return en&&(c?c.push(h):a&&h()),h}function Mu(e,t,o){const i=this.proxy,n=st(e)?e.includes(".")?_l(i,e):()=>i[e]:e.bind(i,i);let s;Le(t)?s=t:(s=t.handler,o=t);const l=rn(this),r=Cl(n,s.bind(i),o);return l(),r}function _l(e,t){const o=t.split(".");return()=>{let i=e;for(let n=0;n<o.length&&i;n++)i=i[o[n]];return i}}const Eu=Symbol("_vte"),Bu=e=>e.__isTeleport,ms=Symbol("_leaveCb");function pr(e,t){e.shapeFlag&6&&e.component?(e.transition=t,pr(e.component.subTree,t)):e.shapeFlag&128?(e.ssContent.transition=t.clone(e.ssContent),e.ssFallback.transition=t.clone(e.ssFallback)):e.transition=t}function Ht(e,t){return Le(e)?kt({name:e.name},t,{setup:e}):e}function Il(e){e.ids=[e.ids[0]+e.ids[2]+++"-",0,0]}function Ur(e,t){let o;return!!((o=Object.getOwnPropertyDescriptor(e,t))&&!o.configurable)}const zn=new WeakMap;function Fi(e,t,o,i,n=!1){if(Me(e)){e.forEach((m,y)=>Fi(m,t&&(Me(t)?t[y]:t),o,i,n));return}if(yi(i)&&!n){i.shapeFlag&512&&i.type.__asyncResolved&&i.component.subTree.component&&Fi(e,t,o,i.component.subTree);return}const s=i.shapeFlag&4?is(i.component):i.el,l=n?null:s,{i:r,r:a}=e,c=t&&t.r,u=r.refs===Je?r.refs={}:r.refs,f=r.setupState,h=je(f),d=f===Je?Ya:m=>Ur(u,m)?!1:Ue(h,m),b=(m,y)=>!(y&&Ur(u,y));if(c!=null&&c!==a){if(Wr(t),st(c))u[c]=null,d(c)&&(f[c]=null);else if(ot(c)){const m=t;b(c,m.k)&&(c.value=null),m.k&&(u[m.k]=null)}}if(Le(a))nn(a,r,12,[l,u]);else{const m=st(a),y=ot(a);if(m||y){const g=()=>{if(e.f){const x=m?d(a)?f[a]:u[a]:b()||!e.k?a.value:u[e.k];if(n)Me(x)&&or(x,s);else if(Me(x))x.includes(s)||x.push(s);else if(m)u[a]=[s],d(a)&&(f[a]=u[a]);else{const k=[s];b(a,e.k)&&(a.value=k),e.k&&(u[e.k]=k)}}else m?(u[a]=l,d(a)&&(f[a]=l)):y&&(b(a,e.k)&&(a.value=l),e.k&&(u[e.k]=l))};if(l){const x=()=>{g(),zn.delete(e)};x.id=-1,zn.set(e,x),Nt(x,o)}else Wr(e),g()}}}function Wr(e){const t=zn.get(e);t&&(t.flags|=8,zn.delete(e))}Zn().requestIdleCallback;Zn().cancelIdleCallback;const yi=e=>!!e.type.__asyncLoader,$l=e=>e.type.__isKeepAlive;function Lu(e,t){Tl(e,"a",t)}function Du(e,t){Tl(e,"da",t)}function Tl(e,t,o=Tt){const i=e.__wdc||(e.__wdc=()=>{let n=o;for(;n;){if(n.isDeactivated)return;n=n.parent}return e()});if(es(t,i,o),o){let n=o.parent;for(;n&&n.parent;)$l(n.parent.vnode)&&Nu(i,t,o,n),n=n.parent}}function Nu(e,t,o,i){const n=es(t,e,i,!0);sn(()=>{or(i[t],n)},o)}function es(e,t,o=Tt,i=!1){if(o){const n=o[e]||(o[e]=[]),s=t.__weh||(t.__weh=(...l)=>{_o();const r=rn(o),a=Qt(t,o,e,l);return r(),Io(),a});return i?n.unshift(s):n.push(s),s}}const Ao=e=>(t,o=Tt)=>{(!en||e==="sp")&&es(e,(...i)=>t(...i),o)},Ou=Ao("bm"),oi=Ao("m"),Pu=Ao("bu"),Ru=Ao("u"),hr=Ao("bum"),sn=Ao("um"),zu=Ao("sp"),Hu=Ao("rtg"),Fu=Ao("rtc");function ju(e,t=Tt){es("ec",e,t)}const Uu="components";function Wu(e,t){return Vu(Uu,e,!0,t)||e}const qu=Symbol.for("v-ndc");function Vu(e,t,o=!0,i=!1){const n=vt||Tt;if(n){const s=n.type;{const r=Ef(s,!1);if(r&&(r===t||r===Lt(t)||r===Gn(Lt(t))))return s}const l=qr(n[e]||s[e],t)||qr(n.appContext[e],t);return!l&&i?s:l}}function qr(e,t){return e&&(e[t]||e[Lt(t)]||e[Gn(Lt(t))])}function $t(e,t,o,i){let n;const s=o,l=Me(e);if(l||st(e)){const r=l&&ei(e);let a=!1,c=!1;r&&(a=!Wt(e),c=$o(e),e=Jn(e)),n=new Array(e.length);for(let u=0,f=e.length;u<f;u++)n[u]=t(a?c?wi(Xt(e[u])):Xt(e[u]):e[u],u,void 0,s)}else if(typeof e=="number"){n=new Array(e);for(let r=0;r<e;r++)n[r]=t(r+1,r,void 0,s)}else if(Ke(e))if(e[Symbol.iterator])n=Array.from(e,(r,a)=>t(r,a,void 0,s));else{const r=Object.keys(e);n=new Array(r.length);for(let a=0,c=r.length;a<c;a++){const u=r[a];n[a]=t(e[u],u,a,s)}}else n=[];return n}function pn(e,t,o={},i,n,s){if(vt.ce||vt.parent&&yi(vt.parent)&&vt.parent.ce){const c=o,u=Object.keys(c).length>0;return t!=="default"&&(c.name=t),J(),Gt(Ve,null,[le("slot",c,i&&i())],u?-2:64)}let l=e[t];l&&l._c&&(l._d=!1);const r=xo.length;J();let a;try{const c=l&&Al(l(o)),u=o.key||s||c&&c.key;a=Gt(Ve,{key:(u&&!Jt(u)?u:`_${t}`)+(!c&&i?"_fb":"")},c||(i?i():[]),c&&e._===1?64:-2)}catch(c){for(let u=xo.length;u>r;u--)yr();throw c}finally{l&&l._c&&(l._d=!0)}return a}function Al(e){return e.some(t=>br(t)?!(t.type===To||t.type===Ve&&!Al(t.children)):!0)?e:null}const Ps=e=>e?Yl(e)?is(e):Ps(e.parent):null,ji=kt(Object.create(null),{$:e=>e,$el:e=>e.vnode.el,$data:e=>e.data,$props:e=>e.props,$attrs:e=>e.attrs,$slots:e=>e.slots,$refs:e=>e.refs,$parent:e=>Ps(e.parent),$root:e=>Ps(e.root),$host:e=>e.ce,$emit:e=>e.emit,$options:e=>El(e),$forceUpdate:e=>e.f||(e.f=()=>{fr(e.update)}),$nextTick:e=>e.n||(e.n=Pn.bind(e.proxy)),$watch:e=>Mu.bind(e)}),gs=(e,t)=>e!==Je&&!e.__isScriptSetup&&Ue(e,t),Ku={get({_:e},t){if(t==="__v_skip")return!0;const{ctx:o,setupState:i,data:n,props:s,accessCache:l,type:r,appContext:a}=e;if(t[0]!=="$"){const h=l[t];if(h!==void 0)switch(h){case 1:return i[t];case 2:return n[t];case 4:return o[t];case 3:return s[t]}else{if(gs(i,t))return l[t]=1,i[t];if(n!==Je&&Ue(n,t))return l[t]=2,n[t];if(Ue(s,t))return l[t]=3,s[t];if(o!==Je&&Ue(o,t))return l[t]=4,o[t];Rs&&(l[t]=0)}}const c=ji[t];let u,f;if(c)return t==="$attrs"&&Ct(e.attrs,"get",""),c(e);if((u=r.__cssModules)&&(u=u[t]))return u;if(o!==Je&&Ue(o,t))return l[t]=4,o[t];if(f=a.config.globalProperties,Ue(f,t))return f[t]},set({_:e},t,o){const{data:i,setupState:n,ctx:s}=e;return gs(n,t)?(n[t]=o,!0):i!==Je&&Ue(i,t)?(i[t]=o,!0):Ue(e.props,t)||t[0]==="$"&&t.slice(1)in e?!1:(s[t]=o,!0)},has({_:{data:e,setupState:t,accessCache:o,ctx:i,appContext:n,props:s,type:l}},r){let a;return!!(o[r]||e!==Je&&r[0]!=="$"&&Ue(e,r)||gs(t,r)||Ue(s,r)||Ue(i,r)||Ue(ji,r)||Ue(n.config.globalProperties,r)||(a=l.__cssModules)&&a[r])},defineProperty(e,t,o){return o.get!=null?e._.accessCache[t]=0:Ue(o,"value")&&this.set(e,t,o.value,null),Reflect.defineProperty(e,t,o)}};function Vr(e){return Me(e)?e.reduce((t,o)=>(t[o]=null,t),{}):e}let Rs=!0;function Gu(e){const t=El(e),o=e.proxy,i=e.ctx;Rs=!1,t.beforeCreate&&Kr(t.beforeCreate,e,"bc");const{data:n,computed:s,methods:l,watch:r,provide:a,inject:c,created:u,beforeMount:f,mounted:h,beforeUpdate:d,updated:b,activated:m,deactivated:y,beforeDestroy:g,beforeUnmount:x,destroyed:k,unmounted:I,render:T,renderTracked:w,renderTriggered:C,errorCaptured:L,serverPrefetch:R,expose:N,inheritAttrs:F,components:E,directives:O,filters:S}=t;if(c&&Yu(c,i,null),l)for(const _ in l){const M=l[_];Le(M)&&(i[_]=M.bind(o))}if(n){const _=n.call(o,o);Ke(_)&&(e.data=Xn(_))}if(Rs=!0,s)for(const _ in s){const M=s[_],B=Le(M)?M.bind(o,o):Le(M.get)?M.get.bind(o,o):ao,Q=!Le(M)&&Le(M.set)?M.set.bind(o):ao,q=ge({get:B,set:Q});Object.defineProperty(i,_,{enumerable:!0,configurable:!0,get:()=>q.value,set:U=>q.value=U})}if(r)for(const _ in r)Ml(r[_],i,o,_);if(a){const _=Le(a)?a.call(o):a;Reflect.ownKeys(_).forEach(M=>{$u(M,_[M])})}u&&Kr(u,e,"c");function j(_,M){Me(M)?M.forEach(B=>_(B.bind(o))):M&&_(M.bind(o))}if(j(Ou,f),j(oi,h),j(Pu,d),j(Ru,b),j(Lu,m),j(Du,y),j(ju,L),j(Fu,w),j(Hu,C),j(hr,x),j(sn,I),j(zu,R),Me(N))if(N.length){const _=e.exposed||(e.exposed={});N.forEach(M=>{Object.defineProperty(_,M,{get:()=>o[M],set:B=>o[M]=B,enumerable:!0})})}else e.exposed||(e.exposed={});T&&e.render===ao&&(e.render=T),F!=null&&(e.inheritAttrs=F),E&&(e.components=E),O&&(e.directives=O),R&&Il(e)}function Yu(e,t,o=ao){Me(e)&&(e=zs(e));for(const i in e){const n=e[i];let s;Ke(n)?"default"in n?s=Zt(n.from||i,n.default,!0):s=Zt(n.from||i):s=Zt(n),ot(s)?Object.defineProperty(t,i,{enumerable:!0,configurable:!0,get:()=>s.value,set:l=>s.value=l}):t[i]=s}}function Kr(e,t,o){Qt(Me(e)?e.map(i=>i.bind(t.proxy)):e.bind(t.proxy),t,o)}function Ml(e,t,o,i){let n=i.includes(".")?_l(o,i):()=>o[i];if(st(e)){const s=t[e];Le(s)&&Fo(n,s)}else if(Le(e))Fo(n,e.bind(o));else if(Ke(e))if(Me(e))e.forEach(s=>Ml(s,t,o,i));else{const s=Le(e.handler)?e.handler.bind(o):t[e.handler];Le(s)&&Fo(n,s,e)}}function El(e){const t=e.type,{mixins:o,extends:i}=t,{mixins:n,optionsCache:s,config:{optionMergeStrategies:l}}=e.appContext,r=s.get(t);let a;return r?a=r:!n.length&&!o&&!i?a=t:(a={},n.length&&n.forEach(c=>Hn(a,c,l,!0)),Hn(a,t,l)),Ke(t)&&s.set(t,a),a}function Hn(e,t,o,i=!1){const{mixins:n,extends:s}=t;s&&Hn(e,s,o,!0),n&&n.forEach(l=>Hn(e,l,o,!0));for(const l in t)if(!(i&&l==="expose")){const r=Zu[l]||o&&o[l];e[l]=r?r(e[l],t[l]):t[l]}return e}const Zu={data:Gr,props:Yr,emits:Yr,methods:Di,computed:Di,beforeCreate:Mt,created:Mt,beforeMount:Mt,mounted:Mt,beforeUpdate:Mt,updated:Mt,beforeDestroy:Mt,beforeUnmount:Mt,destroyed:Mt,unmounted:Mt,activated:Mt,deactivated:Mt,errorCaptured:Mt,serverPrefetch:Mt,components:Di,directives:Di,watch:Xu,provide:Gr,inject:Ju};function Gr(e,t){return t?e?function(){return kt(Le(e)?e.call(this,this):e,Le(t)?t.call(this,this):t)}:t:e}function Ju(e,t){return Di(zs(e),zs(t))}function zs(e){if(Me(e)){const t={};for(let o=0;o<e.length;o++)t[e[o]]=e[o];return t}return e}function Mt(e,t){return e?[...new Set([].concat(e,t))]:t}function Di(e,t){return e?kt(Object.create(null),e,t):t}function Yr(e,t){return e?Me(e)&&Me(t)?[...new Set([...e,...t])]:kt(Object.create(null),Vr(e),Vr(t??{})):t}function Xu(e,t){if(!e)return t;if(!t)return e;const o=kt(Object.create(null),e);for(const i in t)o[i]=Mt(e[i],t[i]);return o}function Bl(){return{app:null,config:{isNativeTag:Ya,performance:!1,globalProperties:{},optionMergeStrategies:{},errorHandler:void 0,warnHandler:void 0,compilerOptions:{}},mixins:[],components:{},directives:{},provides:Object.create(null),optionsCache:new WeakMap,propsCache:new WeakMap,emitsCache:new WeakMap}}let Qu=0;function ef(e,t){return function(i,n=null){Le(i)||(i=kt({},i)),n!=null&&!Ke(n)&&(n=null);const s=Bl(),l=new WeakSet,r=[];let a=!1;const c=s.app={_uid:Qu++,_component:i,_props:n,_container:null,_context:s,_instance:null,version:Lf,get config(){return s.config},set config(u){},use(u,...f){return l.has(u)||(u&&Le(u.install)?(l.add(u),u.install(c,...f)):Le(u)&&(l.add(u),u(c,...f))),c},mixin(u){return s.mixins.includes(u)||s.mixins.push(u),c},component(u,f){return f?(s.components[u]=f,c):s.components[u]},directive(u,f){return f?(s.directives[u]=f,c):s.directives[u]},mount(u,f,h){if(!a){const d=c._ceVNode||le(i,n);return d.appContext=s,h===!0?h="svg":h===!1&&(h=void 0),e(d,u,h),a=!0,c._container=u,u.__vue_app__=c,is(d.component)}},onUnmount(u){r.push(u)},unmount(){a&&(Qt(r,c._instance,16),e(null,c._container),delete c._container.__vue_app__)},provide(u,f){return s.provides[u]=f,c},runWithContext(u){const f=bi;bi=c;try{return u()}finally{bi=f}}};return c}}let bi=null;const tf=(e,t)=>t==="modelValue"||t==="model-value"?e.modelModifiers:e[`${t}Modifiers`]||e[`${Lt(t)}Modifiers`]||e[`${qo(t)}Modifiers`];function of(e,t,...o){if(e.isUnmounted)return;const i=e.vnode.props||Je;let n=o;const s=t.startsWith("update:"),l=s&&tf(i,t.slice(7));l&&(l.trim&&(n=o.map(u=>st(u)?u.trim():u)),l.number&&(n=o.map(Yn)));let r,a=i[r=ds(t)]||i[r=ds(Lt(t))];!a&&s&&(a=i[r=ds(qo(t))]),a&&Qt(a,e,6,n);const c=i[r+"Once"];if(c){if(!e.emitted)e.emitted={};else if(e.emitted[r])return;e.emitted[r]=!0,Qt(c,e,6,n)}}const nf=new WeakMap;function Ll(e,t,o=!1){const i=o?nf:t.emitsCache,n=i.get(e);if(n!==void 0)return n;const s=e.emits;let l={},r=!1;if(!Le(e)){const a=c=>{const u=Ll(c,t,!0);u&&(r=!0,kt(l,u))};!o&&t.mixins.length&&t.mixins.forEach(a),e.extends&&a(e.extends),e.mixins&&e.mixins.forEach(a)}return!s&&!r?(Ke(e)&&i.set(e,null),null):(Me(s)?s.forEach(a=>l[a]=null):kt(l,s),Ke(e)&&i.set(e,l),l)}function ts(e,t){return!e||!qn(t)?!1:(t=t.slice(2),t=t==="Once"?t:t.replace(/Once$/,""),Ue(e,t[0].toLowerCase()+t.slice(1))||Ue(e,qo(t))||Ue(e,t))}function Zr(e){const{type:t,vnode:o,proxy:i,withProxy:n,propsOptions:[s],slots:l,attrs:r,emit:a,render:c,renderCache:u,props:f,data:h,setupState:d,ctx:b,inheritAttrs:m}=e,y=Rn(e);let g,x;try{if(o.shapeFlag&4){const I=n||i,T=I;g=io(c.call(T,I,u,f,d,h,b)),x=r}else{const I=t;g=io(I.length>1?I(f,{attrs:r,slots:l,emit:a}):I(f,null)),x=t.props?r:sf(r)}}catch(I){xo.length=0,Qn(I,e,1),g=le(To)}let k=g;if(x&&m!==!1){const I=Object.keys(x),{shapeFlag:T}=k;I.length&&T&7&&(s&&I.some(Vn)&&(x=rf(x,s)),k=xi(k,x,!1,!0))}return o.dirs&&(k=xi(k,null,!1,!0),k.dirs=k.dirs?k.dirs.concat(o.dirs):o.dirs),o.transition&&pr(k,o.transition),g=k,Rn(y),g}const sf=e=>{let t;for(const o in e)(o==="class"||o==="style"||qn(o))&&((t||(t={}))[o]=e[o]);return t},rf=(e,t)=>{const o={};for(const i in e)(!Vn(i)||!(i.slice(9)in t))&&(o[i]=e[i]);return o};function af(e,t,o){const{props:i,children:n,component:s}=e,{props:l,children:r,patchFlag:a}=t,c=s.emitsOptions;if(t.dirs||t.transition)return!0;if(o&&a>=0){if(a&1024)return!0;if(a&16)return i?Jr(i,l,c):!!l;if(a&8){const u=t.dynamicProps;for(let f=0;f<u.length;f++){const h=u[f];if(Dl(l,i,h)&&!ts(c,h))return!0}}}else return(n||r)&&(!r||!r.$stable)?!0:i===l?!1:i?l?Jr(i,l,c):!0:!!l;return!1}function Jr(e,t,o){const i=Object.keys(t);if(i.length!==Object.keys(e).length)return!0;for(let n=0;n<i.length;n++){const s=i[n];if(Dl(t,e,s)&&!ts(o,s))return!0}return!1}function Dl(e,t,o){const i=e[o],n=t[o];return o==="style"&&Ke(i)&&Ke(n)?!Ii(i,n):i!==n}function lf({vnode:e,parent:t,suspense:o},i){for(;t;){const n=t.subTree;if(n.suspense&&n.suspense.activeBranch===e&&(n.suspense.vnode.el=n.el=i,e=n),n===e)(e=t.vnode).el=i,t=t.parent;else break}o&&o.activeBranch===e&&(o.vnode.el=i)}const Nl={},Ol=()=>Object.create(Nl),Pl=e=>Object.getPrototypeOf(e)===Nl;function cf(e,t,o,i=!1){const n={},s=Ol();e.propsDefaults=Object.create(null),Rl(e,t,n,s);for(const l in e.propsOptions[0])l in n||(n[l]=void 0);o?e.props=i?n:mu(n):e.type.props?e.props=n:e.props=s,e.attrs=s}function df(e,t,o,i){const{props:n,attrs:s,vnode:{patchFlag:l}}=e,r=je(n),[a]=e.propsOptions;let c=!1;if((i||l>0)&&!(l&16)){if(l&8){const u=e.vnode.dynamicProps;for(let f=0;f<u.length;f++){let h=u[f];if(ts(e.emitsOptions,h))continue;const d=t[h];if(a)if(Ue(s,h))d!==s[h]&&(s[h]=d,c=!0);else{const b=Lt(h);n[b]=Hs(a,r,b,d,e,!1)}else d!==s[h]&&(s[h]=d,c=!0)}}}else{Rl(e,t,n,s)&&(c=!0);let u;for(const f in r)(!t||!Ue(t,f)&&((u=qo(f))===f||!Ue(t,u)))&&(a?o&&(o[f]!==void 0||o[u]!==void 0)&&(n[f]=Hs(a,r,f,void 0,e,!0)):delete n[f]);if(s!==r)for(const f in s)(!t||!Ue(t,f))&&(delete s[f],c=!0)}c&&bo(e.attrs,"set","")}function Rl(e,t,o,i){const[n,s]=e.propsOptions;let l=!1,r;if(t)for(let a in t){if(Ri(a))continue;const c=t[a];let u;n&&Ue(n,u=Lt(a))?!s||!s.includes(u)?o[u]=c:(r||(r={}))[u]=c:ts(e.emitsOptions,a)||(!(a in i)||c!==i[a])&&(i[a]=c,l=!0)}if(s){const a=je(o),c=r||Je;for(let u=0;u<s.length;u++){const f=s[u];o[f]=Hs(n,a,f,c[f],e,!Ue(c,f))}}return l}function Hs(e,t,o,i,n,s){const l=e[o];if(l!=null){const r=Ue(l,"default");if(r&&i===void 0){const a=l.default;if(l.type!==Function&&!l.skipFactory&&Le(a)){const{propsDefaults:c}=n;if(o in c)i=c[o];else{const u=rn(n);i=c[o]=a.call(null,t),u()}}else i=a;n.ce&&n.ce._setProp(o,i)}l[0]&&(s&&!r?i=!1:l[1]&&(i===""||i===qo(o))&&(i=!0))}return i}const uf=new WeakMap;function zl(e,t,o=!1){const i=o?uf:t.propsCache,n=i.get(e);if(n)return n;const s=e.props,l={},r=[];let a=!1;if(!Le(e)){const u=f=>{a=!0;const[h,d]=zl(f,t,!0);kt(l,h),d&&r.push(...d)};!o&&t.mixins.length&&t.mixins.forEach(u),e.extends&&u(e.extends),e.mixins&&e.mixins.forEach(u)}if(!s&&!a)return Ke(e)&&i.set(e,hi),hi;if(Me(s))for(let u=0;u<s.length;u++){const f=Lt(s[u]);Xr(f)&&(l[f]=Je)}else if(s)for(const u in s){const f=Lt(u);if(Xr(f)){const h=s[u],d=l[f]=Me(h)||Le(h)?{type:h}:kt({},h),b=d.type;let m=!1,y=!0;if(Me(b))for(let g=0;g<b.length;++g){const x=b[g],k=Le(x)&&x.name;if(k==="Boolean"){m=!0;break}else k==="String"&&(y=!1)}else m=Le(b)&&b.name==="Boolean";d[0]=m,d[1]=y,(m||Ue(d,"default"))&&r.push(f)}}const c=[l,r];return Ke(e)&&i.set(e,c),c}function Xr(e){return e[0]!=="$"&&!Ri(e)}const mr=e=>e==="_"||e==="_ctx"||e==="$stable",gr=e=>Me(e)?e.map(io):[io(e)],ff=(e,t,o)=>{if(t._n)return t;const i=Sl((...n)=>gr(t(...n)),o);return i._c=!1,i},Hl=(e,t,o)=>{const i=e._ctx;for(const n in e){if(mr(n))continue;const s=e[n];if(Le(s))t[n]=ff(n,s,i);else if(s!=null){const l=gr(s);t[n]=()=>l}}},Fl=(e,t)=>{const o=gr(t);e.slots.default=()=>o},jl=(e,t,o)=>{for(const i in t)(o||!mr(i))&&(e[i]=t[i])},pf=(e,t,o)=>{const i=e.slots=Ol();if(e.vnode.shapeFlag&32){const n=t._;n?(jl(i,t,o),o&&Qa(i,"_",n,!0)):Hl(t,i)}else t&&Fl(e,t)},hf=(e,t,o)=>{const{vnode:i,slots:n}=e;let s=!0,l=Je;if(i.shapeFlag&32){const r=t._;r?o&&r===1?s=!1:jl(n,t,o):(s=!t.$stable,Hl(t,n)),l=t}else t&&(Fl(e,t),l={default:1});if(s)for(const r in n)!mr(r)&&l[r]==null&&delete n[r]},Nt=vf;function mf(e){return gf(e)}function gf(e,t){const o=Zn();o.__VUE__=!0;const{insert:i,remove:n,patchProp:s,createElement:l,createText:r,createComment:a,setText:c,setElementText:u,parentNode:f,nextSibling:h,setScopeId:d=ao,insertStaticContent:b}=e,m=(D,V,v,K=null,H=null,$=null,A=void 0,P=null,Y=!!V.dynamicChildren)=>{if(D===V)return;D&&!Bi(D,V)&&(K=$e(D),U(D,H,$,!0),D=null),V.patchFlag===-2&&(Y=!1,V.dynamicChildren=null);const{type:G,ref:Z,shapeFlag:ee}=V;switch(G){case os:y(D,V,v,K);break;case To:g(D,V,v,K);break;case wn:D==null&&x(V,v,K,A);break;case Ve:E(D,V,v,K,H,$,A,P,Y);break;default:ee&1?T(D,V,v,K,H,$,A,P,Y):ee&6?O(D,V,v,K,H,$,A,P,Y):(ee&64||ee&128)&&G.process(D,V,v,K,H,$,A,P,Y,z)}Z!=null&&H?Fi(Z,D&&D.ref,$,V||D,!V):Z==null&&D&&D.ref!=null&&Fi(D.ref,null,$,D,!0)},y=(D,V,v,K)=>{if(D==null)i(V.el=r(V.children),v,K);else{const H=V.el=D.el;V.children!==D.children&&c(H,V.children)}},g=(D,V,v,K)=>{D==null?i(V.el=a(V.children||""),v,K):V.el=D.el},x=(D,V,v,K)=>{[D.el,D.anchor]=b(D.children,V,v,K,D.el,D.anchor)},k=({el:D,anchor:V},v,K)=>{let H;for(;D&&D!==V;)H=h(D),i(D,v,K),D=H;i(V,v,K)},I=({el:D,anchor:V})=>{let v;for(;D&&D!==V;)v=h(D),n(D),D=v;n(V)},T=(D,V,v,K,H,$,A,P,Y)=>{if(V.type==="svg"?A="svg":V.type==="math"&&(A="mathml"),D==null)w(V,v,K,H,$,A,P,Y);else{const G=D.el&&D.el._isVueCE?D.el:null;try{G&&G._beginPatch(),R(D,V,H,$,A,P,Y)}finally{G&&G._endPatch()}}},w=(D,V,v,K,H,$,A,P)=>{let Y,G;const{props:Z,shapeFlag:ee,transition:ce,dirs:re}=D;if(Y=D.el=l(D.type,$,Z&&Z.is,Z),ee&8?u(Y,D.children):ee&16&&L(D.children,Y,null,K,H,ys(D,$),A,P),re&&Vo(D,null,K,"created"),C(Y,D,D.scopeId,A,K),Z){for(const _e in Z)_e!=="value"&&!Ri(_e)&&s(Y,_e,null,Z[_e],$,K);"value"in Z&&s(Y,"value",null,Z.value,$),(G=Z.onVnodeBeforeMount)&&eo(G,K,D)}re&&Vo(D,null,K,"beforeMount");const me=yf(H,ce);me&&ce.beforeEnter(Y),i(Y,V,v),((G=Z&&Z.onVnodeMounted)||me||re)&&Nt(()=>{try{G&&eo(G,K,D),me&&ce.enter(Y),re&&Vo(D,null,K,"mounted")}finally{}},H)},C=(D,V,v,K,H)=>{if(v&&d(D,v),K)for(let $=0;$<K.length;$++)d(D,K[$]);if(H){let $=H.subTree;if(V===$||Vl($.type)&&($.ssContent===V||$.ssFallback===V)){const A=H.vnode;C(D,A,A.scopeId,A.slotScopeIds,H.parent)}}},L=(D,V,v,K,H,$,A,P,Y=0)=>{for(let G=Y;G<D.length;G++){const Z=D[G]=P?go(D[G]):io(D[G]);m(null,Z,V,v,K,H,$,A,P)}},R=(D,V,v,K,H,$,A)=>{const P=V.el=D.el;let{patchFlag:Y,dynamicChildren:G,dirs:Z}=V;Y|=D.patchFlag&16;const ee=D.props||Je,ce=V.props||Je;let re;if(v&&Ko(v,!1),(re=ce.onVnodeBeforeUpdate)&&eo(re,v,V,D),Z&&Vo(V,D,v,"beforeUpdate"),v&&Ko(v,!0),G&&(!D.dynamicChildren||D.dynamicChildren.length!==G.length)&&(Y=0,A=!1,G=null),(ee.innerHTML&&ce.innerHTML==null||ee.textContent&&ce.textContent==null)&&u(P,""),G?N(D.dynamicChildren,G,P,v,K,ys(V,H),$):A||M(D,V,P,null,v,K,ys(V,H),$,!1),Y>0){if(Y&16)F(P,ee,ce,v,H);else if(Y&2&&ee.class!==ce.class&&s(P,"class",null,ce.class,H),Y&4&&s(P,"style",ee.style,ce.style,H),Y&8){const me=V.dynamicProps;for(let _e=0;_e<me.length;_e++){const we=me[_e],De=ee[we],He=ce[we];(He!==De||we==="value")&&s(P,we,De,He,H,v)}}Y&1&&D.children!==V.children&&u(P,V.children)}else!A&&G==null&&F(P,ee,ce,v,H);((re=ce.onVnodeUpdated)||Z)&&Nt(()=>{re&&eo(re,v,V,D),Z&&Vo(V,D,v,"updated")},K)},N=(D,V,v,K,H,$,A)=>{for(let P=0;P<V.length;P++){const Y=D[P],G=V[P],Z=Y.el&&(Y.type===Ve||!Bi(Y,G)||Y.shapeFlag&198)?f(Y.el):v;m(Y,G,Z,null,K,H,$,A,!0)}},F=(D,V,v,K,H)=>{if(V!==v){if(V!==Je)for(const $ in V)!Ri($)&&!($ in v)&&s(D,$,V[$],null,H,K);for(const $ in v){if(Ri($))continue;const A=v[$],P=V[$];A!==P&&$!=="value"&&s(D,$,P,A,H,K)}"value"in v&&s(D,"value",V.value,v.value,H)}},E=(D,V,v,K,H,$,A,P,Y)=>{const G=V.el=D?D.el:r(""),Z=V.anchor=D?D.anchor:r("");let{patchFlag:ee,dynamicChildren:ce,slotScopeIds:re}=V;re&&(P=P?P.concat(re):re),D==null?(i(G,v,K),i(Z,v,K),L(V.children||[],v,Z,H,$,A,P,Y)):ee>0&&ee&64&&ce&&D.dynamicChildren&&D.dynamicChildren.length===ce.length?(N(D.dynamicChildren,ce,v,H,$,A,P),(V.key!=null||H&&V===H.subTree)&&Ul(D,V,!0)):M(D,V,v,Z,H,$,A,P,Y)},O=(D,V,v,K,H,$,A,P,Y)=>{V.slotScopeIds=P,D==null?V.shapeFlag&512?H.ctx.activate(V,v,K,A,Y):S(V,v,K,H,$,A,Y):W(D,V,Y)},S=(D,V,v,K,H,$,A)=>{const P=D.component=_f(D,K,H);if($l(D)&&(P.ctx.renderer=z),$f(P,!1,A),P.asyncDep){if(H&&H.registerDep(P,j,A),!D.el){const Y=P.subTree=le(To);g(null,Y,V,v),D.placeholder=Y.el}}else j(P,D,V,v,H,$,A)},W=(D,V,v)=>{const K=V.component=D.component;if(af(D,V,v))if(K.asyncDep&&!K.asyncResolved){_(K,V,v);return}else K.next=V,K.update();else V.el=D.el,K.vnode=V},j=(D,V,v,K,H,$,A)=>{const P=()=>{if(D.isMounted){let{next:ee,bu:ce,u:re,parent:me,vnode:_e}=D;{const rt=Wl(D);if(rt){ee&&(ee.el=_e.el,_(D,ee,A)),rt.asyncDep.then(()=>{Nt(()=>{D.isUnmounted||G()},H)});return}}let we=ee,De;Ko(D,!1),ee?(ee.el=_e.el,_(D,ee,A)):ee=_e,ce&&kn(ce),(De=ee.props&&ee.props.onVnodeBeforeUpdate)&&eo(De,me,ee,_e),Ko(D,!0);const He=Zr(D),Ge=D.subTree;D.subTree=He,m(Ge,He,f(Ge.el),$e(Ge),D,H,$),ee.el=He.el,we===null&&lf(D,He.el),re&&Nt(re,H),(De=ee.props&&ee.props.onVnodeUpdated)&&Nt(()=>eo(De,me,ee,_e),H)}else{let ee;const{el:ce,props:re}=V,{bm:me,m:_e,parent:we,root:De,type:He}=D,Ge=yi(V);Ko(D,!1),me&&kn(me),!Ge&&(ee=re&&re.onVnodeBeforeMount)&&eo(ee,we,V),Ko(D,!0);{De.ce&&De.ce._hasShadowRoot()&&De.ce._injectChildStyle(He,D.parent?D.parent.type:void 0);const rt=D.subTree=Zr(D);m(null,rt,v,K,D,H,$),V.el=rt.el}if(_e&&Nt(_e,H),!Ge&&(ee=re&&re.onVnodeMounted)){const rt=V;Nt(()=>eo(ee,we,rt),H)}(V.shapeFlag&256||we&&yi(we.vnode)&&we.vnode.shapeFlag&256)&&D.a&&Nt(D.a,H),D.isMounted=!0,V=v=K=null}};D.scope.on();const Y=D.effect=new il(P);D.scope.off();const G=D.update=Y.run.bind(Y),Z=D.job=Y.runIfDirty.bind(Y);Z.i=D,Z.id=D.uid,Y.scheduler=()=>fr(Z),Ko(D,!0),G()},_=(D,V,v)=>{V.component=D;const K=D.vnode.props;D.vnode=V,D.next=null,df(D,V.props,K,v),hf(D,V.children,v),_o(),jr(D),Io()},M=(D,V,v,K,H,$,A,P,Y=!1)=>{const G=D&&D.children,Z=D?D.shapeFlag:0,ee=V.children,{patchFlag:ce,shapeFlag:re}=V;if(ce>0){if(ce&128){Q(G,ee,v,K,H,$,A,P,Y);return}else if(ce&256){B(G,ee,v,K,H,$,A,P,Y);return}}re&8?(Z&16&&Se(G,H,$),ee!==G&&u(v,ee)):Z&16?re&16?Q(G,ee,v,K,H,$,A,P,Y):Se(G,H,$,!0):(Z&8&&u(v,""),re&16&&L(ee,v,K,H,$,A,P,Y))},B=(D,V,v,K,H,$,A,P,Y)=>{D=D||hi,V=V||hi;const G=D.length,Z=V.length,ee=Math.min(G,Z);let ce;for(ce=0;ce<ee;ce++){const re=V[ce]=Y?go(V[ce]):io(V[ce]);m(D[ce],re,v,null,H,$,A,P,Y)}G>Z?Se(D,H,$,!0,!1,ee):L(V,v,K,H,$,A,P,Y,ee)},Q=(D,V,v,K,H,$,A,P,Y)=>{let G=0;const Z=V.length;let ee=D.length-1,ce=Z-1;for(;G<=ee&&G<=ce;){const re=D[G],me=V[G]=Y?go(V[G]):io(V[G]);if(Bi(re,me))m(re,me,v,null,H,$,A,P,Y);else break;G++}for(;G<=ee&&G<=ce;){const re=D[ee],me=V[ce]=Y?go(V[ce]):io(V[ce]);if(Bi(re,me))m(re,me,v,null,H,$,A,P,Y);else break;ee--,ce--}if(G>ee){if(G<=ce){const re=ce+1,me=re<Z?V[re].el:K;for(;G<=ce;)m(null,V[G]=Y?go(V[G]):io(V[G]),v,me,H,$,A,P,Y),G++}}else if(G>ce)for(;G<=ee;)U(D[G],H,$,!0),G++;else{const re=G,me=G,_e=new Map;for(G=me;G<=ce;G++){const tt=V[G]=Y?go(V[G]):io(V[G]);tt.key!=null&&_e.set(tt.key,G)}let we,De=0;const He=ce-me+1;let Ge=!1,rt=0;const Pe=new Array(He);for(G=0;G<He;G++)Pe[G]=0;for(G=re;G<=ee;G++){const tt=D[G];if(De>=He){U(tt,H,$,!0);continue}let Ye;if(tt.key!=null)Ye=_e.get(tt.key);else for(we=me;we<=ce;we++)if(Pe[we-me]===0&&Bi(tt,V[we])){Ye=we;break}Ye===void 0?U(tt,H,$,!0):(Pe[Ye-me]=G+1,Ye>=rt?rt=Ye:Ge=!0,m(tt,V[Ye],v,null,H,$,A,P,Y),De++)}const pt=Ge?bf(Pe):hi;for(we=pt.length-1,G=He-1;G>=0;G--){const tt=me+G,Ye=V[tt],fe=V[tt+1],pe=tt+1<Z?fe.el||ql(fe):K;Pe[G]===0?m(null,Ye,v,pe,H,$,A,P,Y):Ge&&(we<0||G!==pt[we]?q(Ye,v,pe,2):we--)}}},q=(D,V,v,K,H=null)=>{const{el:$,type:A,transition:P,children:Y,shapeFlag:G}=D;if(G&6){q(D.component.subTree,V,v,K);return}if(G&128){D.suspense.move(V,v,K);return}if(G&64){A.move(D,V,v,z);return}if(A===Ve){i($,V,v);for(let ee=0;ee<Y.length;ee++)q(Y[ee],V,v,K);i(D.anchor,V,v);return}if(A===wn){k(D,V,v);return}if(K!==2&&G&1&&P)if(K===0)P.persisted&&!$[ms]?i($,V,v):(P.beforeEnter($),i($,V,v),Nt(()=>P.enter($),H));else{const{leave:ee,delayLeave:ce,afterLeave:re}=P,me=()=>{D.ctx.isUnmounted?n($):i($,V,v)},_e=()=>{const we=$._isLeaving||!!$[ms];$._isLeaving&&$[ms](!0),P.persisted&&!we?me():ee($,()=>{me(),re&&re()})};ce?ce($,me,_e):_e()}else i($,V,v)},U=(D,V,v,K=!1,H=!1)=>{const{type:$,props:A,ref:P,children:Y,dynamicChildren:G,shapeFlag:Z,patchFlag:ee,dirs:ce,cacheIndex:re,memo:me}=D;if(ee===-2&&(H=!1),P!=null&&(_o(),Fi(P,null,v,D,!0),Io()),re!=null&&(V.renderCache[re]=void 0),Z&256){V.ctx.deactivate(D);return}const _e=Z&1&&ce,we=!yi(D);let De;if(we&&(De=A&&A.onVnodeBeforeUnmount)&&eo(De,V,D),Z&6)ae(D.component,v,K);else{if(Z&128){D.suspense.unmount(v,K);return}_e&&Vo(D,null,V,"beforeUnmount"),Z&64?D.type.remove(D,V,v,z,K):G&&!G.hasOnce&&($!==Ve||ee>0&&ee&64)?Se(G,V,v,!1,!0):($===Ve&&ee&384||!H&&Z&16)&&Se(Y,V,v),K&&ne(D)}const He=me!=null&&re==null;(we&&(De=A&&A.onVnodeUnmounted)||_e||He)&&Nt(()=>{De&&eo(De,V,D),_e&&Vo(D,null,V,"unmounted"),He&&(D.el=null)},v)},ne=D=>{const{type:V,el:v,anchor:K,transition:H}=D;if(V===Ve){oe(v,K);return}if(V===wn){I(D);return}const $=()=>{n(v),H&&!H.persisted&&H.afterLeave&&H.afterLeave()};if(D.shapeFlag&1&&H&&!H.persisted){const{leave:A,delayLeave:P}=H,Y=()=>A(v,$);P?P(D.el,$,Y):Y()}else $()},oe=(D,V)=>{let v;for(;D!==V;)v=h(D),n(D),D=v;n(V)},ae=(D,V,v)=>{const{bum:K,scope:H,job:$,subTree:A,um:P,m:Y,a:G}=D;Qr(Y),Qr(G),K&&kn(K),H.stop(),$&&($.flags|=8,U(A,D,V,v)),P&&Nt(P,V),Nt(()=>{D.isUnmounted=!0},V)},Se=(D,V,v,K=!1,H=!1,$=0)=>{for(let A=$;A<D.length;A++)U(D[A],V,v,K,H)},$e=D=>{if(D.shapeFlag&6)return $e(D.component.subTree);if(D.shapeFlag&128)return D.suspense.next();const V=h(D.anchor||D.el),v=V&&V[Eu];return v?h(v):V};let ke=!1;const Ce=(D,V,v)=>{let K;D==null?V._vnode&&(U(V._vnode,null,null,!0),K=V._vnode.component):m(V._vnode||null,D,V,null,null,null,v),V._vnode=D,ke||(ke=!0,jr(K),kl(),ke=!1)},z={p:m,um:U,m:q,r:ne,mt:S,mc:L,pc:M,pbc:N,n:$e,o:e};return{render:Ce,hydrate:void 0,createApp:ef(Ce)}}function ys({type:e,props:t},o){return o==="svg"&&e==="foreignObject"||o==="mathml"&&e==="annotation-xml"&&t&&t.encoding&&t.encoding.includes("html")?void 0:o}function Ko({effect:e,job:t},o){o?(e.flags|=32,t.flags|=4):(e.flags&=-33,t.flags&=-5)}function yf(e,t){return(!e||e&&!e.pendingBranch)&&t&&!t.persisted}function Ul(e,t,o=!1){const i=e.children,n=t.children;if(Me(i)&&Me(n))for(let s=0;s<i.length;s++){const l=i[s];let r=n[s];r.shapeFlag&1&&!r.dynamicChildren&&((r.patchFlag<=0||r.patchFlag===32)&&(r=n[s]=go(n[s]),r.el=l.el),!o&&r.patchFlag!==-2&&Ul(l,r)),r.type===os&&(r.patchFlag===-1&&(r=n[s]=go(r)),r.el=l.el),r.type===To&&!r.el&&(r.el=l.el)}}function bf(e){const t=e.slice(),o=[0];let i,n,s,l,r;const a=e.length;for(i=0;i<a;i++){const c=e[i];if(c!==0){if(n=o[o.length-1],e[n]<c){t[i]=n,o.push(i);continue}for(s=0,l=o.length-1;s<l;)r=s+l>>1,e[o[r]]<c?s=r+1:l=r;c<e[o[s]]&&(s>0&&(t[i]=o[s-1]),o[s]=i)}}for(s=o.length,l=o[s-1];s-- >0;)o[s]=l,l=t[l];return o}function Wl(e){const t=e.subTree.component;if(t)return t.asyncDep&&!t.asyncResolved?t:Wl(t)}function Qr(e){if(e)for(let t=0;t<e.length;t++)e[t].flags|=8}function ql(e){if(e.placeholder)return e.placeholder;const t=e.component;return t?ql(t.subTree):null}const Vl=e=>e.__isSuspense;function vf(e,t){t&&t.pendingBranch?Me(e)?t.effects.push(...e):t.effects.push(e):Iu(e)}const Ve=Symbol.for("v-fgt"),os=Symbol.for("v-txt"),To=Symbol.for("v-cmt"),wn=Symbol.for("v-stc"),xo=[];let zt=null;function J(e=!1){xo.push(zt=e?null:[])}function yr(){xo.pop(),zt=xo[xo.length-1]||null}let Qi=1;function ea(e,t=!1){Qi+=e,e<0&&zt&&t&&(zt.hasOnce=!0)}function Kl(e){return e.dynamicChildren=Qi>0?zt||hi:null,yr(),Qi>0&&zt&&zt.push(e),e}function X(e,t,o,i,n,s){return Kl(p(e,t,o,i,n,s,!0))}function Gt(e,t,o,i,n){return Kl(le(e,t,o,i,n,!0))}function br(e){return e?e.__v_isVNode===!0:!1}function Bi(e,t){return e.type===t.type&&e.key===t.key}const Gl=({key:e})=>e??null,xn=({ref:e,ref_key:t,ref_for:o})=>(typeof e=="number"&&(e=""+e),e!=null?st(e)||ot(e)||Le(e)?{i:vt,r:e,k:t,f:!!o}:e:null);function p(e,t=null,o=null,i=0,n=null,s=e===Ve?0:1,l=!1,r=!1){const a={__v_isVNode:!0,__v_skip:!0,type:e,props:t,key:t&&Gl(t),ref:t&&xn(t),scopeId:xl,slotScopeIds:null,children:o,component:null,suspense:null,ssContent:null,ssFallback:null,dirs:null,transition:null,el:null,anchor:null,target:null,targetStart:null,targetAnchor:null,staticCount:0,shapeFlag:s,patchFlag:i,dynamicProps:n,dynamicChildren:null,appContext:null,ctx:vt};return r?(Fn(a,o),s&128&&e.normalize(a)):o&&(a.shapeFlag|=st(o)?8:16),Qi>0&&!l&&zt&&(a.patchFlag>0||s&6)&&a.patchFlag!==32&&zt.push(a),a}const le=kf;function kf(e,t=null,o=null,i=0,n=null,s=!1){if((!e||e===qu)&&(e=To),br(e)){const r=xi(e,t,!0);return o&&Fn(r,o),Qi>0&&!s&&zt&&(r.shapeFlag&6?zt[zt.indexOf(e)]=r:zt.push(r)),r.patchFlag=-2,r}if(Bf(e)&&(e=e.__vccOpts),t){t=wf(t);let{class:r,style:a}=t;r&&!st(r)&&(t.class=xe(r)),Ke(a)&&(ur(a)&&!Me(a)&&(a=kt({},a)),t.style=so(a))}const l=st(e)?1:Vl(e)?128:Bu(e)?64:Ke(e)?4:Le(e)?2:0;return p(e,t,o,i,n,l,s,!0)}function wf(e){return e?ur(e)||Pl(e)?kt({},e):e:null}function xi(e,t,o=!1,i=!1){const{props:n,ref:s,patchFlag:l,children:r,transition:a}=e,c=t?xf(n||{},t):n,u={__v_isVNode:!0,__v_skip:!0,type:e.type,props:c,key:c&&Gl(c),ref:t&&t.ref?o&&s?Me(s)?s.concat(xn(t)):[s,xn(t)]:xn(t):s,scopeId:e.scopeId,slotScopeIds:e.slotScopeIds,children:r,target:e.target,targetStart:e.targetStart,targetAnchor:e.targetAnchor,staticCount:e.staticCount,shapeFlag:e.shapeFlag,patchFlag:t&&e.type!==Ve?l===-1?16:l|16:l,dynamicProps:e.dynamicProps,dynamicChildren:e.dynamicChildren,appContext:e.appContext,dirs:e.dirs,transition:a,component:e.component,suspense:e.suspense,ssContent:e.ssContent&&xi(e.ssContent),ssFallback:e.ssFallback&&xi(e.ssFallback),placeholder:e.placeholder,el:e.el,anchor:e.anchor,ctx:e.ctx,ce:e.ce};return a&&i&&pr(u,a.clone(u)),u}function _t(e=" ",t=0){return le(os,null,e,t)}function ht(e,t){const o=le(wn,null,e);return o.staticCount=t,o}function Te(e="",t=!1){return t?(J(),Gt(To,null,e)):le(To,null,e)}function io(e){return e==null||typeof e=="boolean"?le(To):Me(e)?le(Ve,null,e.slice()):br(e)?go(e):le(os,null,String(e))}function go(e){return e.el===null&&e.patchFlag!==-1||e.memo?e:xi(e)}function Fn(e,t){let o=0;const{shapeFlag:i}=e;if(t==null)t=null;else if(Me(t))o=16;else if(typeof t=="object")if(i&65){const n=t.default;n&&(n._c&&(n._d=!1),Fn(e,n()),n._c&&(n._d=!0));return}else{o=32;const n=t._;!n&&!Pl(t)?t._ctx=vt:n===3&&vt&&(vt.slots._===1?t._=1:(t._=2,e.patchFlag|=1024))}else if(Le(t)){if(i&65){Fn(e,{default:t});return}t={default:t,_ctx:vt},o=32}else t=String(t),i&64?(o=16,t=[_t(t)]):o=8;e.children=t,e.shapeFlag|=o}function xf(...e){const t={};for(let o=0;o<e.length;o++){const i=e[o];for(const n in i)if(n==="class")t.class!==i.class&&(t.class=xe([t.class,i.class]));else if(n==="style")t.style=so([t.style,i.style]);else if(qn(n)){const s=t[n],l=i[n];l&&s!==l&&!(Me(s)&&s.includes(l))?t[n]=s?[].concat(s,l):l:l==null&&s==null&&!Vn(n)&&(t[n]=l)}else n!==""&&(t[n]=i[n])}return t}function eo(e,t,o,i=null){Qt(e,t,7,[o,i])}const Sf=Bl();let Cf=0;function _f(e,t,o){const i=e.type,n=(t?t.appContext:e.appContext)||Sf,s={uid:Cf++,vnode:e,type:i,parent:t,appContext:n,root:null,next:null,subTree:null,effect:null,update:null,job:null,scope:new Zd(!0),render:null,proxy:null,exposed:null,exposeProxy:null,withProxy:null,provides:t?t.provides:Object.create(n.provides),ids:t?t.ids:["",0,0],accessCache:null,renderCache:[],components:null,directives:null,propsOptions:zl(i,n),emitsOptions:Ll(i,n),emit:null,emitted:null,propsDefaults:Je,inheritAttrs:i.inheritAttrs,ctx:Je,data:Je,props:Je,attrs:Je,slots:Je,refs:Je,setupState:Je,setupContext:null,suspense:o,suspenseId:o?o.pendingId:0,asyncDep:null,asyncResolved:!1,isMounted:!1,isUnmounted:!1,isDeactivated:!1,bc:null,c:null,bm:null,m:null,bu:null,u:null,um:null,bum:null,da:null,a:null,rtg:null,rtc:null,ec:null,sp:null};return s.ctx={_:s},s.root=t?t.root:s,s.emit=of.bind(null,s),e.ce&&e.ce(s),s}let Tt=null;const If=()=>Tt||vt;let jn,Fs;{const e=Zn(),t=(o,i)=>{let n;return(n=e[o])||(n=e[o]=[]),n.push(i),s=>{n.length>1?n.forEach(l=>l(s)):n[0](s)}};jn=t("__VUE_INSTANCE_SETTERS__",o=>Tt=o),Fs=t("__VUE_SSR_SETTERS__",o=>en=o)}const rn=e=>{const t=Tt;return jn(e),e.scope.on(),()=>{e.scope.off(),jn(t)}},ta=()=>{Tt&&Tt.scope.off(),jn(null)};function Yl(e){return e.vnode.shapeFlag&4}let en=!1;function $f(e,t=!1,o=!1){t&&Fs(t);const{props:i,children:n}=e.vnode,s=Yl(e);cf(e,i,s,t),pf(e,n,o||t);const l=s?Tf(e,t):void 0;return t&&Fs(!1),l}function Tf(e,t){const o=e.type;e.accessCache=Object.create(null),e.proxy=new Proxy(e.ctx,Ku);const{setup:i}=o;if(i){_o();const n=e.setupContext=i.length>1?Mf(e):null,s=rn(e),l=nn(i,e,0,[e.props,n]),r=Za(l);if(Io(),s(),(r||e.sp)&&!yi(e)&&Il(e),r){if(l.then(ta,ta),t)return l.then(a=>{oa(e,a)}).catch(a=>{Qn(a,e,0)});e.asyncDep=l}else oa(e,l)}else Zl(e)}function oa(e,t,o){Le(t)?e.type.__ssrInlineRender?e.ssrRender=t:e.render=t:Ke(t)&&(e.setupState=yl(t)),Zl(e)}function Zl(e,t,o){const i=e.type;e.render||(e.render=i.render||ao);{const n=rn(e);_o();try{Gu(e)}finally{Io(),n()}}}const Af={get(e,t){return Ct(e,"get",""),e[t]}};function Mf(e){const t=o=>{e.exposed=o||{}};return{attrs:new Proxy(e.attrs,Af),slots:e.slots,emit:e.emit,expose:t}}function is(e){return e.exposed?e.exposeProxy||(e.exposeProxy=new Proxy(yl(gu(e.exposed)),{get(t,o){if(o in t)return t[o];if(o in ji)return ji[o](e)},has(t,o){return o in t||o in ji}})):e.proxy}function Ef(e,t=!0){return Le(e)?e.displayName||e.name:e.name||t&&e.__name}function Bf(e){return Le(e)&&"__vccOpts"in e}const ge=(e,t)=>wu(e,t,en),Lf="3.5.40";/**
* @vue/runtime-dom v3.5.40
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/let js;const ia=typeof window<"u"&&window.trustedTypes;if(ia)try{js=ia.createPolicy("vue",{createHTML:e=>e})}catch{}const Jl=js?e=>js.createHTML(e):e=>e,Df="http://www.w3.org/2000/svg",Nf="http://www.w3.org/1998/Math/MathML",ho=typeof document<"u"?document:null,na=ho&&ho.createElement("template"),Of={insert:(e,t,o)=>{t.insertBefore(e,o||null)},remove:e=>{const t=e.parentNode;t&&t.removeChild(e)},createElement:(e,t,o,i)=>{const n=t==="svg"?ho.createElementNS(Df,e):t==="mathml"?ho.createElementNS(Nf,e):o?ho.createElement(e,{is:o}):ho.createElement(e);return e==="select"&&i&&i.multiple!=null&&n.setAttribute("multiple",i.multiple),n},createText:e=>ho.createTextNode(e),createComment:e=>ho.createComment(e),setText:(e,t)=>{e.nodeValue=t},setElementText:(e,t)=>{e.textContent=t},parentNode:e=>e.parentNode,nextSibling:e=>e.nextSibling,querySelector:e=>ho.querySelector(e),setScopeId(e,t){e.setAttribute(t,"")},insertStaticContent(e,t,o,i,n,s){const l=o?o.previousSibling:t.lastChild;if(n&&(n===s||n.nextSibling))for(;t.insertBefore(n.cloneNode(!0),o),!(n===s||!(n=n.nextSibling)););else{na.innerHTML=Jl(i==="svg"?`<svg>${e}</svg>`:i==="mathml"?`<math>${e}</math>`:e);const r=na.content;if(i==="svg"||i==="mathml"){const a=r.firstChild;for(;a.firstChild;)r.appendChild(a.firstChild);r.removeChild(a)}t.insertBefore(r,o)}return[l?l.nextSibling:t.firstChild,o?o.previousSibling:t.lastChild]}},Pf=Symbol("_vtc");function Rf(e,t,o){const i=e[Pf];i&&(t=(t?[t,...i]:[...i]).join(" ")),t==null?e.removeAttribute("class"):o?e.setAttribute("class",t):e.className=t}const Un=Symbol("_vod"),Xl=Symbol("_vsh"),Us={name:"show",beforeMount(e,{value:t},{transition:o}){e[Un]=e.style.display==="none"?"":e.style.display,o&&t?o.beforeEnter(e):Li(e,t)},mounted(e,{value:t},{transition:o}){o&&t&&o.enter(e)},updated(e,{value:t,oldValue:o},{transition:i}){!t!=!o&&(i?t?(i.beforeEnter(e),Li(e,!0),i.enter(e)):i.leave(e,()=>{Li(e,!1)}):Li(e,t))},beforeUnmount(e,{value:t}){Li(e,t)}};function Li(e,t){e.style.display=t?e[Un]:"none",e[Xl]=!t}const zf=Symbol(""),Hf=/(?:^|;)\s*display\s*:/;function Ff(e,t,o){const i=e.style,n=st(o);let s=!1;if(o&&!n){if(t)if(st(t))for(const l of t.split(";")){const r=l.slice(0,l.indexOf(":")).trim();o[r]==null&&Ni(i,r,"")}else for(const l in t)o[l]==null&&Ni(i,l,"");for(const l in o){l==="display"&&(s=!0);const r=o[l];r!=null?Uf(e,l,!st(t)&&t?t[l]:void 0,r)||Ni(i,l,r):Ni(i,l,"")}}else if(n){if(t!==o){const l=i[zf];l&&(o+=";"+l),i.cssText=o,s=Hf.test(o)}}else t&&e.removeAttribute("style");Un in e&&(e[Un]=s?i.display:"",e[Xl]&&(i.display="none"))}const sa=/\s*!important$/;function Ni(e,t,o){if(Me(o))o.forEach(i=>Ni(e,t,i));else if(o==null&&(o=""),t.startsWith("--"))e.setProperty(t,o);else{const i=jf(e,t);sa.test(o)?e.setProperty(qo(i),o.replace(sa,""),"important"):e[i]=o}}const ra=["Webkit","Moz","ms"],bs={};function jf(e,t){const o=bs[t];if(o)return o;let i=Lt(t);if(i!=="filter"&&i in e)return bs[t]=i;i=Gn(i);for(let n=0;n<ra.length;n++){const s=ra[n]+i;if(s in e)return bs[t]=s}return t}function Uf(e,t,o,i){return e.tagName==="TEXTAREA"&&(t==="width"||t==="height")&&st(i)&&o===i}const aa="http://www.w3.org/1999/xlink";function la(e,t,o,i,n,s=Gd(t)){i&&t.startsWith("xlink:")?o==null?e.removeAttributeNS(aa,t.slice(6,t.length)):e.setAttributeNS(aa,t,o):o==null||s&&!el(o)?e.removeAttribute(t):e.setAttribute(t,s?"":Jt(o)?String(o):o)}function ca(e,t,o,i,n){if(t==="innerHTML"||t==="textContent"){o!=null&&(e[t]=t==="innerHTML"?Jl(o):o);return}const s=e.tagName;if(t==="value"&&s!=="PROGRESS"&&!s.includes("-")){const r=s==="OPTION"?e.getAttribute("value")||"":e.value,a=o==null?e.type==="checkbox"?"on":"":String(o);(r!==a||!("_value"in e))&&(e.value=a),o==null&&e.removeAttribute(t),e._value=o;return}let l=!1;if(o===""||o==null){const r=typeof e[t];r==="boolean"?o=el(o):o==null&&r==="string"?(o="",l=!0):r==="number"&&(o=0,l=!0)}try{e[t]=o}catch{}l&&e.removeAttribute(n||t)}function No(e,t,o,i){e.addEventListener(t,o,i)}function Wf(e,t,o,i){e.removeEventListener(t,o,i)}const da=Symbol("_vei");function qf(e,t,o,i,n=null){const s=e[da]||(e[da]={}),l=s[t];if(i&&l)l.value=i;else{const[r,a]=Gf(t);if(i){const c=s[t]=Jf(i,n);No(e,r,c,a)}else l&&(Wf(e,r,l,a),s[t]=void 0)}}const Vf=/(Once|Passive|Capture)$/,Kf=/^on:?(?:Once|Passive|Capture)$/;function Gf(e){let t,o;for(;(o=e.match(Vf))&&!Kf.test(e);)t||(t={}),e=e.slice(0,e.length-o[1].length),t[o[1].toLowerCase()]=!0;return[e[2]===":"?e.slice(3):qo(e.slice(2)),t]}let vs=0;const Yf=Promise.resolve(),Zf=()=>vs||(Yf.then(()=>vs=0),vs=Date.now());function Jf(e,t){const o=i=>{if(!i._vts)i._vts=Date.now();else if(i._vts<=o.attached)return;const n=o.value;if(Me(n)){const s=i.stopImmediatePropagation;i.stopImmediatePropagation=()=>{s.call(i),i._stopped=!0};const l=n.slice(),r=[i];for(let a=0;a<l.length&&!i._stopped;a++){const c=l[a];c&&Qt(c,t,5,r)}}else Qt(n,t,5,[i])};return o.value=e,o.attached=Zf(),o}const ua=e=>e.charCodeAt(0)===111&&e.charCodeAt(1)===110&&e.charCodeAt(2)>96&&e.charCodeAt(2)<123,Xf=(e,t,o,i,n,s)=>{const l=n==="svg";t==="class"?Rf(e,i,l):t==="style"?Ff(e,o,i):qn(t)?Vn(t)||qf(e,t,o,i,s):(t[0]==="."?(t=t.slice(1),!0):t[0]==="^"?(t=t.slice(1),!1):Qf(e,t,i,l))?(ca(e,t,i),!e.tagName.includes("-")&&(t==="value"||t==="checked"||t==="selected")&&la(e,t,i,l,s,t!=="value")):e._isVueCE&&(ep(e,t)||e._def.__asyncLoader&&(/[A-Z]/.test(t)||!st(i)))?ca(e,Lt(t),i,s,t):(t==="true-value"?e._trueValue=i:t==="false-value"&&(e._falseValue=i),la(e,t,i,l))};function Qf(e,t,o,i){if(i)return!!(t==="innerHTML"||t==="textContent"||t in e&&ua(t)&&Le(o));if(t==="spellcheck"||t==="draggable"||t==="translate"||t==="autocorrect"||t==="sandbox"&&e.tagName==="IFRAME"||t==="form"||t==="list"&&e.tagName==="INPUT"||t==="type"&&e.tagName==="TEXTAREA")return!1;if(t==="width"||t==="height"){const n=e.tagName;if(n==="IMG"||n==="VIDEO"||n==="CANVAS"||n==="SOURCE")return!1}return ua(t)&&st(o)?!1:t in e}function ep(e,t){const o=e._def.props;if(!o)return!1;const i=Lt(t);return Array.isArray(o)?o.some(n=>Lt(n)===i):Object.keys(o).some(n=>Lt(n)===i)}const Si=e=>{const t=e.props["onUpdate:modelValue"]||!1;return Me(t)?o=>kn(t,o):t};function tp(e){e.target.composing=!0}function fa(e){const t=e.target;t.composing&&(t.composing=!1,t.dispatchEvent(new Event("input")))}const So=Symbol("_assign");function pa(e,t,o){return t&&(e=e.trim()),o&&(e=Yn(e)),e}const Ws={created(e,{modifiers:{lazy:t,trim:o,number:i}},n){e[So]=Si(n);const s=i||n.props&&n.props.type==="number";No(e,t?"change":"input",l=>{l.target.composing||e[So](pa(e.value,o,s))}),(o||s)&&No(e,"change",()=>{e.value=pa(e.value,o,s)}),t||(No(e,"compositionstart",tp),No(e,"compositionend",fa),No(e,"change",fa))},mounted(e,{value:t}){e.value=t??""},beforeUpdate(e,{value:t,oldValue:o,modifiers:{lazy:i,trim:n,number:s}},l){if(e[So]=Si(l),e.composing)return;const r=(s||e.type==="number")&&!/^0\d/.test(e.value)?Yn(e.value):e.value,a=t??"";if(r===a)return;const c=e.getRootNode();(c instanceof Document||c instanceof ShadowRoot)&&c.activeElement===e&&e.type!=="range"&&(i&&t===o||n&&e.value.trim()===a)||(e.value=a)}},hn={deep:!0,created(e,t,o){e[So]=Si(o),No(e,"change",()=>{const i=e._modelValue,n=tn(e),s=e.checked,l=e[So];if(Me(i)){const r=nr(i,n),a=r!==-1;if(s&&!a)l(i.concat(n));else if(!s&&a){const c=[...i];c.splice(r,1),l(c)}}else if(_i(i)){const r=new Set(i);s?r.add(n):r.delete(n),l(r)}else l(Ql(e,s))})},mounted:ha,beforeUpdate(e,t,o){e[So]=Si(o),ha(e,t,o)}};function ha(e,{value:t,oldValue:o},i){e._modelValue=t;let n;if(Me(t))n=nr(t,i.props.value)>-1;else if(_i(t))n=t.has(i.props.value);else{if(t===o)return;n=Ii(t,Ql(e,!0))}e.checked!==n&&(e.checked=n)}const op={deep:!0,created(e,{value:t,modifiers:{number:o}},i){e._modelValue=t,No(e,"change",()=>{const n=Array.prototype.filter.call(e.options,s=>s.selected).map(s=>o?Yn(tn(s)):tn(s));e[So](e.multiple?_i(e._modelValue)?new Set(n):n:n[0]),e._assigning=!0,Pn(()=>{e._assigning=!1})}),e[So]=Si(i)},mounted(e,{value:t}){ma(e,t)},beforeUpdate(e,{value:t},o){e._modelValue=t,e[So]=Si(o)},updated(e,{value:t}){e._assigning||ma(e,t)}};function ma(e,t){const o=e.multiple,i=Me(t);if(!(o&&!i&&!_i(t))){for(let n=0,s=e.options.length;n<s;n++){const l=e.options[n],r=tn(l);if(o)if(i){const a=typeof r;a==="string"||a==="number"?l.selected=t.some(c=>String(c)===String(r)):l.selected=nr(t,r)>-1}else l.selected=t.has(r);else if(Ii(tn(l),t)){e.selectedIndex!==n&&(e.selectedIndex=n);return}}!o&&e.selectedIndex!==-1&&(e.selectedIndex=-1)}}function tn(e){return"_value"in e?e._value:e.value}function Ql(e,t){const o=t?"_trueValue":"_falseValue";return o in e?e[o]:t}const ip=["ctrl","shift","alt","meta"],np={stop:e=>e.stopPropagation(),prevent:e=>e.preventDefault(),self:e=>e.target!==e.currentTarget,ctrl:e=>!e.ctrlKey,shift:e=>!e.shiftKey,alt:e=>!e.altKey,meta:e=>!e.metaKey,left:e=>"button"in e&&e.button!==0,middle:e=>"button"in e&&e.button!==1,right:e=>"button"in e&&e.button!==2,exact:(e,t)=>ip.some(o=>e[`${o}Key`]&&!t.includes(o))},ro=(e,t)=>{if(!e)return e;const o=e._withMods||(e._withMods={}),i=t.join(".");return o[i]||(o[i]=((n,...s)=>{for(let l=0;l<t.length;l++){const r=np[t[l]];if(r&&r(n,t))return}return e(n,...s)}))},sp={esc:"escape",space:" ",up:"arrow-up",left:"arrow-left",right:"arrow-right",down:"arrow-down",delete:"backspace"},rp=(e,t)=>{const o=e._withKeys||(e._withKeys={}),i=t.join(".");return o[i]||(o[i]=(n=>{if(!("key"in n))return;const s=qo(n.key);if(t.some(l=>l===s||sp[l]===s))return e(n)}))},ap=kt({patchProp:Xf},Of);let ga;function lp(){return ga||(ga=mf(ap))}const vr=((...e)=>{const t=lp().createApp(...e),{mount:o}=t;return t.mount=i=>{const n=dp(i);if(!n)return;const s=t._component;!Le(s)&&!s.render&&!s.template&&(s.template=n.innerHTML),n.nodeType===1&&(n.textContent="");const l=o(n,!1,cp(n));return n instanceof Element&&(n.removeAttribute("v-cloak"),n.setAttribute("data-v-app","")),l},t});function cp(e){if(e instanceof SVGElement)return"svg";if(typeof MathMLElement=="function"&&e instanceof MathMLElement)return"mathml"}function dp(e){return st(e)?document.querySelector(e):e}const gt={baseUrl:"",apiKey:"",model:"",requestTimeoutSeconds:60,temperature:.7,maxTokens:4096},up="slides-config.json",ko={enableWebServeJump:!1,webServeUrl:"http://127.0.0.1:6806",normalizeHeadingSizes:!1,showUnorderedListMarkers:!0,showOrderedListMarkers:!0,aiConfig:{...gt}},jt=Xn({...ko}),ns=he(null);function fp(e){ns.value=e}function pp(){return ns.value}function vi(e){if(!e||typeof e!="object")return{...gt};const t=e;return{baseUrl:typeof t.baseUrl=="string"?t.baseUrl.trim():gt.baseUrl,apiKey:typeof t.apiKey=="string"?t.apiKey.trim():gt.apiKey,model:typeof t.model=="string"?t.model.trim():gt.model,requestTimeoutSeconds:typeof t.requestTimeoutSeconds=="number"&&t.requestTimeoutSeconds>0?Math.floor(t.requestTimeoutSeconds):gt.requestTimeoutSeconds,temperature:typeof t.temperature=="number"&&t.temperature>=0&&t.temperature<=2?Number(t.temperature.toFixed(2)):gt.temperature,maxTokens:typeof t.maxTokens=="number"&&t.maxTokens>0?Math.floor(t.maxTokens):gt.maxTokens}}function Wn(e){return e?!!(typeof e.baseUrl=="string"&&e.baseUrl.trim()&&typeof e.apiKey=="string"&&e.apiKey.trim()&&typeof e.model=="string"&&e.model.trim()):!1}function kr(){const e=ns.value;if(e&&Wn(e))return{isManaged:!0,profileName:e.profileName,config:{baseUrl:e.baseUrl,apiKey:e.apiKey,model:e.model,requestTimeoutSeconds:e.requestTimeoutSeconds??gt.requestTimeoutSeconds,temperature:e.temperature??gt.temperature,maxTokens:e.maxTokens??gt.maxTokens,headers:e.headers}};const t=jt.aiConfig;return Wn(t)?{isManaged:!1,config:{...t}}:null}function hp(e){if(!e||typeof e!="object")return{...ko,aiConfig:{...gt}};const t=e;return{enableWebServeJump:!!t.enableWebServeJump,webServeUrl:typeof t.webServeUrl=="string"&&t.webServeUrl.trim()?t.webServeUrl.trim():ko.webServeUrl,normalizeHeadingSizes:!!t.normalizeHeadingSizes,showUnorderedListMarkers:t.showUnorderedListMarkers!==void 0?!!t.showUnorderedListMarkers:ko.showUnorderedListMarkers,showOrderedListMarkers:t.showOrderedListMarkers!==void 0?!!t.showOrderedListMarkers:ko.showOrderedListMarkers,aiConfig:vi(t.aiConfig)}}function mt(e){if(!e||typeof e!="object")return{...jt};const t=e;return t.enableWebServeJump!==void 0&&(jt.enableWebServeJump=!!t.enableWebServeJump),t.webServeUrl!==void 0&&(jt.webServeUrl=String(t.webServeUrl)),t.normalizeHeadingSizes!==void 0&&(jt.normalizeHeadingSizes=!!t.normalizeHeadingSizes),t.showUnorderedListMarkers!==void 0&&(jt.showUnorderedListMarkers=!!t.showUnorderedListMarkers),t.showOrderedListMarkers!==void 0&&(jt.showOrderedListMarkers=!!t.showOrderedListMarkers),t.aiConfig!==void 0&&(jt.aiConfig=vi(t.aiConfig)),{...jt}}function jo(){return{...jt}}function ec(e,t,o){const i=(e||ko.webServeUrl).trim(),n=i.startsWith("http://")||i.startsWith("https://")?i:`http://${i}`,s=(o==null?void 0:o.r)||Math.random().toString(36).slice(2,9).padEnd(7,"0");try{const l=new URL(n);let r=l.pathname.replace(/\/+$/,"");return r.endsWith("/stage/build/desktop")||(r=r?`${r}/stage/build/desktop`:"/stage/build/desktop"),l.pathname=`${r}/`,l.searchParams.set("id",t),o!=null&&o.focus&&l.searchParams.set("focus","1"),l.searchParams.set("r",s),l.toString()}catch{const l=o!=null&&o.focus?"&focus=1":"";return`${n.replace(/\/+$/,"")}/stage/build/desktop/?id=${t}${l}&r=${s}`}}const si={theme:"apple-basic",aspectRatio:"16/9",defaultTransition:"slide-left",colorSchema:"auto",spacing:"normal",background:"",normalizeHeadingSizes:!1,showUnorderedListMarkers:!0,showOrderedListMarkers:!0};function mp(e){var n,s,l,r,a,c;const t=jo();if(!e)return{...si,normalizeHeadingSizes:t.normalizeHeadingSizes,showUnorderedListMarkers:t.showUnorderedListMarkers,showOrderedListMarkers:t.showOrderedListMarkers};const o=e[Or]!==void 0?e[Or]!=="false":t.showUnorderedListMarkers,i=e[Pr]!==void 0?e[Pr]!=="false":t.showOrderedListMarkers;return{theme:((n=e[Vi])==null?void 0:n.trim())||si.theme,aspectRatio:((s=e[Ki])==null?void 0:s.trim())||si.aspectRatio,defaultTransition:((l=e[Gi])==null?void 0:l.trim())||si.defaultTransition,colorSchema:((r=e[qa])==null?void 0:r.trim())||si.colorSchema,spacing:((a=e[Es])==null?void 0:a.trim())||si.spacing,background:((c=e[Mn])==null?void 0:c.trim())||"",normalizeHeadingSizes:t.normalizeHeadingSizes,showUnorderedListMarkers:o,showOrderedListMarkers:i}}function wo(e){var o,i,n,s,l;const t=(o=e.ial)==null?void 0:o[yo];return!!(t&&(t==="true"||t==="page"||t==="cover"||t==="end")||e.type==="tb"||e.type==="thematic-break"||e.type==="NodeThematicBreak"||((i=e.markdown)==null?void 0:i.trim())==="---"||((n=e.markdown)==null?void 0:n.trim())==="***"||e.type==="b"&&(((s=e.markdown)==null?void 0:s.trim())==="---"||((l=e.content)==null?void 0:l.trim())==="---"))}function ya(e){const t={};let o="";if(!e)return{frontmatter:t,notes:o};e[be]&&(t.layout=e[be].trim()),e[It]&&(t.transition=e[It].trim()),e[dt]&&(t.background=e[dt].trim()),e[Kt]&&(t.image=e[Kt].trim()),e[ci]&&(t.class=e[ci].trim()),e[Pi]&&(t.spacing=e[Pi].trim()),e[bt]&&(t.layoutRatio=e[bt].trim()),e[di]&&(t.mask=e[di].trim()),e[Xo]&&(t.maskRatio=e[Xo].trim()),e[ui]&&(t.maskStyle=e[ui].trim()),e[fi]&&(t.maskInitial=e[fi].trim()),e[cs]&&(o=e[cs].trim());for(const[i,n]of Object.entries(e))if(i.startsWith("custom-slides-")&&![be,bt,di,Xo,ui,fi,It,dt,Kt,ci,Pi,cs,yo].includes(i)){const s=i.replace(/^custom-slides-/,"");try{t[s]=JSON.parse(n)}catch{t[s]=n}}return{frontmatter:t,notes:o}}function ba(e){const t={};if(!e)return t;const o=e[Fe];o!=null&&o!==""&&o!=="false"&&o!=="0"&&(t.isNote=!0);const i=e[Ze],n=e[dt];(i===Va||n==="true"||n==="1")&&(t.isBackground=!0);const s=e[be];s===Ln||s===Dn?t.imageLayout=s:(i===Ln||i===Dn)&&(t.imageLayout=i);const l=e[Ne];if(l!=null&&(t.clicks=l.trim()),e[Bt])try{const r=JSON.parse(e[Bt]);typeof r=="object"&&r!==null?t.motion={preset:r.preset||r.type||"fade-in",...r}:t.motion={preset:String(r).trim()}}catch{t.motion={preset:e[Bt].trim()}}return e[ti]&&(t.shikiLines=e[ti].trim()),e[Yi]&&(t.maxHeight=e[Yi].trim()),e[Ae]&&(t.slot=e[Ae].trim()),e.style&&e.style.trim()&&(t.style=e.style.trim()),t}function Co(e,t){const o=(e||t||"").trim();if(!o)return null;const i=o.match(/!\[[\s\S]*?\]\(\s*([^\s)]+)(?:\s+(?:=["']?[^"'\s)]*["']?|["'][^"']*["']))*?\s*\)/);if(i)return i[1].trim();const n=o.match(/<img\b[^>]*?\bsrc=["']([^"']+)["']/i);if(n)return n[1].trim();const s=o.replace(/\{:[^}]*\}/g,"").trim();return/^(?:assets\/|https?:\/\/|\/|\.\.?\/)[^\s]+\.(?:png|jpe?g|gif|webp|svg|avif)(?:\?[^\s]*)?$/i.test(s)?s:null}function Ft(e){if(!e)return"";const t=e.split(/\r?\n/);if(t.length===0)return"";const o=t[0],i=o.match(/^(\s*)(?:[-*+]|\d+\.)\s+(.*)$/);if(!i)return e;const n=i[1].length,s=i[2].trim(),l=o.length-i[2].length;if(t.length===1)return s;const r=[s];for(let a=1;a<t.length;a++){const c=t[a];if(!c.trim()){r.push("");continue}const u=c.match(/^(\s*)/),f=u?u[1].length:0;f>=l?r.push(c.slice(l)):f>n?r.push(c.slice(f)):r.push(c)}return r.join(`
`)}function Uo(e){if(!e)return!1;const t=(e.type||"").toLowerCase();if(t==="i"||t==="nodelistitem"||t==="l"||t==="nodelist")return!0;const o=(e.markdown||e.rawMarkdown||e.content||"").trim();return!!/^(?:[-*+]|\d+\.)\s+/.test(o)}function ks(e,t=2){if(!e||typeof e!="string")return`repeat(${t}, 1fr)`;const o=e.trim();if(!o)return`repeat(${t}, 1fr)`;if(o.includes(":")){const n=o.split(":").map(s=>parseFloat(s.trim())).filter(s=>!isNaN(s)&&s>0);if(n.length>=2)return n.map(s=>`${s}fr`).join(" ")}const i=o.split(/\s+/).filter(Boolean);return i.length>=2?i.join(" "):`repeat(${t}, 1fr)`}function Ui(e){if(!e)return[];if(ft(e)&&lo(e)&&!co(e)){const i=$i(e),n=[];for(const s of i)n.push(...Ui(s));return n}const t=(e.type||"").toLowerCase();if(t==="l"||t==="nodelist"||t==="list"){if(e.children&&e.children.length>0){const l=e.children.filter(Uo);if(l.length>0)return l}const n=(e.markdown||e.content||"").trim().split(/\r?\n/),s=[];for(let l=0;l<n.length;l++)/^(?:[-*+]|\d+\.)\s+/.test(n[l])&&s.push(l);if(s.length>=2){const l=[];for(let r=0;r<s.length;r++){const a=s[r],c=r+1<s.length?s[r+1]:n.length,u=n.slice(a,c).join(`
`);l.push({id:`${e.id}-item-${r+1}`,type:"i",markdown:u,content:u,ial:{...e.ial||{}}})}return l}}return Uo(e)?[e]:[]}function wr(e){var n;if(!e||!ft(e)||!lo(e)||co(e))return null;const t=$i(e);if(t.length===0)return null;if(t.length===1&&ft(t[0])&&lo(t[0])){const s=wr(t[0]);return s?{items:s.items,nestedSuperBlocks:[t[0],...s.nestedSuperBlocks]}:null}const o=[];for(const s of t)if(ft(s)){o.push(s);const l=((n=s.children)==null?void 0:n.filter(ft))||[];o.push(...l)}const i=t.map(Ui);if(i.length>=2&&i.every(s=>s.length>0)){const s=i.flat();if(s.length>=2&&s.length<=6)return{items:s,nestedSuperBlocks:o}}if(t.length===2){const s=Ui(t[0]),l=Ui(t[1]);if(s.length+l.length>=2&&s.length+l.length<=6&&(s.length>0||l.length>0))return{items:[...s,...l],nestedSuperBlocks:o}}return null}function gp(e){if(!e||!ft(e)||!lo(e)||co(e))return null;const t=wr(e);if(!t)return null;const{items:o,nestedSuperBlocks:i}=t;if(o.length<2||o.length>6)return null;const n=xr(e)||void 0,s=o.length;return{superBlockNode:e,nestedSuperBlocks:i,count:s,layout:"cols-header",items:o,slots:o.map((l,r)=>`col-${r+1}`),ratio:n}}function tc(e){if(!e||!ft(e)||!lo(e)||co(e))return null;const t=$i(e);if(t.length===0)return null;const o=[];for(const i of t){const n=Ui(i);if(n.length===0)return null;o.push(...n)}return o}function yp(e){if(!e||!ft(e)||!lo(e)||co(e))return null;const t=tc(e);return!t||t.length===0||t.length>=2&&t.length<=6?null:{superBlockNode:e,items:t}}function bp(e){if(!e||!ft(e)||!lo(e)||co(e))return null;const t=wr(e);if(t&&t.items.length===4)return t.items;const o=tc(e);if(o&&o.length===4)return o;const i=$i(e);return i.length===4?i:null}function vp(e,t){if(!e||e.length===0)return null;const o=[];function i(r,a){if(ft(r)){const c=bp(r);c&&c.length===4&&o.push({sbNode:r,items:c,topLevelIndex:a})}if(r.children&&r.children.length>0)for(const c of r.children)i(c,a)}for(let r=0;r<e.length;r++)i(e[r],r);if(o.length===0)return null;let n=null;t&&(n=o.find(r=>{if(r.sbNode.id===t||r.items.some(c=>c.id===t))return!0;const a=c=>c.id===t?!0:c.children?c.children.some(a):!1;return a(r.sbNode)})||null),n||(n=o[0]);const l=e.slice(0,n.topLevelIndex).slice().reverse().find(r=>oc(r));return{superBlockNode:n.sbNode,items:n.items,headerNode:l}}function kp(e,t,o){var u,f,h,d,b;const i=[],n=[],s=(o==null?void 0:o.tracked)||[],l=[];let r={pageTargetId:e,blocks:[]};l.push(r);for(let m=0;m<t.length;m++){const y=t[m];if(wo(y)){if(l.length===1&&r.blocks.length===0){r.pageTargetId=y.id,r.blocks.push(y);continue}r={pageTargetId:y.id,blocks:[y]},l.push(r)}else r.blocks.push(y)}function a(m){const y=[];for(const g of m)ft(g)&&y.push(g),g.children&&g.children.length>0&&y.push(...a(g.children));return y}function c(m,y,g){const x={blockId:m,attrs:y,previousAttrs:g};i.push(x),o!=null&&o.onTagChange&&o.onTagChange(x)}for(const m of l){const y=m.pageTargetId,g=t.find(w=>w.id===y),x=s.find(w=>w.pageTargetId===y);if(m.blocks.some(w=>{var C,L;return!!(co(w)||qs(w)&&(((C=w.ial)==null?void 0:C[be])==="image-left"||((L=w.ial)==null?void 0:L[be])==="image-right"))})){if(x){const w=x.headerId;if(w){c(w,{[Ae]:""});const C=t.find(L=>L.id===w);C!=null&&C.ial&&(C.ial[Ae]="")}for(const C of x.itemIds){c(C,{[Ae]:""});const L=t.find(R=>R.id===C);L!=null&&L.ial&&(L.ial[Ae]="")}}continue}let I=null,T=-1;for(let w=0;w<m.blocks.length;w++){const C=m.blocks[w],L=ft(C)?[C,...a(C.children||[])]:C.children?a(C.children):[];for(const R of L){const N=gp(R);if(N){I=N,T=w;break}}if(I)break}if(I){const{superBlockNode:w,layout:C,items:L,slots:R}=I,F=m.blocks.slice(0,T).find(_=>oc(_)),E=F==null?void 0:F.id,O=((u=g==null?void 0:g.ial)==null?void 0:u[be])||"",S=O==="clover",W=S?"clover":C;if(O!==W&&(c(y,{[be]:W},{[be]:O}),g&&(g.ial||(g.ial={}),g.ial[be]=W)),F){const _=((f=F.ial)==null?void 0:f[Ae])||"";_!=="header"&&(c(F.id,{[Ae]:"header"},{[Ae]:_}),F.ial||(F.ial={}),F.ial[Ae]="header")}if(x!=null&&x.headerId&&x.headerId!==E){c(x.headerId,{[Ae]:""});const _=t.find(M=>M.id===x.headerId);_&&(_.ial||(_.ial={}),_.ial[Ae]="")}const j=[];for(let _=0;_<L.length;_++){const M=L[_],B=R[_];j.push(M.id);const Q=((h=M.ial)==null?void 0:h[Ae])||"";if(Q!==B&&(c(M.id,{[Ae]:B},{[Ae]:Q}),M.ial||(M.ial={}),M.ial[Ae]=B),M.children&&M.children.length>0)for(const q of M.children)q.ial||(q.ial={}),q.ial[Ae]!==B&&(q.ial[Ae]=B)}if(x!=null&&x.itemIds){for(const _ of x.itemIds)if(!j.includes(_)){c(_,{[Ae]:""});const M=t.find(B=>B.id===_);M&&(M.ial||(M.ial={}),M.ial[Ae]="")}}n.push({superBlockId:w.id,nestedSuperBlockIds:(d=I.nestedSuperBlocks)==null?void 0:d.map(_=>_.id),pageTargetId:y,headerId:E,itemIds:j,layout:S?"clover":C})}else{let w=!1;const C=[];for(const N of m.blocks){const F=ft(N)?[N,...a(N.children||[])]:N.children?a(N.children):[];for(const E of F){const O=yp(E);if(O){w=!0;for(const S of O.items)C.push(S.id)}}}const L=((b=g==null?void 0:g.ial)==null?void 0:b[be])||"",R=pi(L);if(x||w&&R){c(y,{[be]:""},{[be]:L}),g&&(g.ial||(g.ial={}),g.ial[be]="");const N=x==null?void 0:x.headerId;if(N){c(N,{[Ae]:""});const E=t.find(O=>O.id===N);E&&(E.ial||(E.ial={}),E.ial[Ae]="")}const F=new Set([...(x==null?void 0:x.itemIds)||[],...C]);for(const E of F){c(E,{[Ae]:""});const O=t.find(S=>S.id===E);O&&(O.ial||(O.ial={}),O.ial[Ae]="")}}}}return{changes:i,newTracked:n}}function ft(e){if(!e)return!1;const t=(e.type||"").toLowerCase();return t==="s"||t==="sb"||t==="nodesuperblock"}function lo(e){if(!ft(e))return!1;const t=(e.subType||"").toLowerCase();if(t==="col"||t==="h"||t==="horizontal")return!0;if(t==="row"||t==="v"||t==="vertical")return!1;if(e.ial){const i=(e.ial["data-sb-layout"]||e.ial.layout||"").toLowerCase();if(i==="col"||i==="h")return!0;if(i==="row"||i==="v")return!1}if(e.children&&e.children.length>0){for(const i of e.children)if(i.type==="NodeSuperBlockLayoutMarker"||i.type==="layout-marker"){const n=(i.content||i.markdown||"").trim().toLowerCase();if(n==="col"||n==="h")return!0;if(n==="row"||n==="v")return!1}}const o=(e.markdown||e.content||"").trim();return/^\{\{\{col\b/i.test(o)?!0:!/^\{\{\{row\b/i.test(o)}function qs(e){return!e||Uo(e)||ft(e)||!Co(e.markdown,e.content)?!1:(e.markdown||e.content||"").replace(/!\[.*?\]\([^)]+\)/g,"").replace(/<img\b[^>]*>/gi,"").replace(/\{:[^}]*\}/g,"").trim().length<=25}function xr(e){var h;if(!e||!ft(e)||!lo(e))return null;const t=$i(e);if(!t||t.length<2)return null;const o=[];let i=!1;for(const d of t){const b=(((h=d.ial)==null?void 0:h.style)||d.style||"").trim();let m=null;if(b){const y=b.match(/calc\(\s*([\d.]+)%/i);if(y)m=parseFloat(y[1]);else{const g=b.match(/(?:^|;|\s)width:\s*([\d.]+)%/i);g&&(m=parseFloat(g[1]))}}m!==null&&!isNaN(m)&&m>0?(o.push(m),i=!0):o.push(null)}if(!i)return null;const n=t.length,s=o.reduce((d,b)=>d+(b||0),0),l=o.filter(d=>d===null).length,r=Math.max(0,100-s),a=l>0?r/l:100/n,c=o.map(d=>d!==null?d:a),u=c.reduce((d,b)=>d+b,0);if(u<=0)return null;const f=c.map(d=>d/u*100);if(f.length===2){const[d]=f;if(d>=48&&d<=52)return"1:1";if(d>=31&&d<=35)return"1:2";if(d>=65&&d<=69)return"2:1";if(d>=28&&d<=32)return"3:7";if(d>=68&&d<=72)return"7:3";if(d>=38&&d<=42)return"4:6";if(d>=58&&d<=62)return"6:4";if(d>=23&&d<=27)return"1:3";if(d>=73&&d<=77)return"3:1";const b=Math.round(d),m=100-b;return`${b}:${m}`}if(f.length===3){const[d,b,m]=f;if(d>=31&&d<=35&&b>=31&&b<=35&&m>=31&&m<=35)return"1:1:1";if(d>=23&&d<=27&&b>=48&&b<=52&&m>=23&&m<=27)return"1:2:1";if(d>=48&&d<=52&&b>=23&&b<=27&&m>=23&&m<=27)return"2:1:1";if(d>=23&&d<=27&&b>=23&&b<=27&&m>=48&&m<=52)return"1:1:2";if(d>=18&&d<=22&&b>=58&&b<=62&&m>=18&&m<=22)return"1:3:1";const y=Math.round(d),g=Math.round(b),x=100-y-g;return`${y}:${g}:${x}`}return f.map(d=>Math.round(d)).join(":")}function co(e){if(!e||!ft(e)||!lo(e))return null;const t=(e.children||[]).filter(s=>{const l=s.type||"";if(l==="NodeSuperBlockOpenMarker"||l==="NodeSuperBlockLayoutMarker"||l==="NodeSuperBlockCloseMarker"||l==="open-marker"||l==="layout-marker"||l==="close-marker")return!1;const r=(s.markdown||s.content||"").trim();return!(/^\{\{\{(?:col|row)?\s*$/i.test(r)||r==="}}}")});if(t.length<2)return null;const o=qs(t[0]),i=qs(t[t.length-1]),n=xr(e)||void 0;if(o&&!i){const s=Co(t[0].markdown,t[0].content);if(s)return{imageNode:t[0],imageUrl:s,layout:Ln,contentNodes:t.slice(1),ratio:n}}if(!o&&i){const s=Co(t[t.length-1].markdown,t[t.length-1].content);if(s)return{imageNode:t[t.length-1],imageUrl:s,layout:Dn,contentNodes:t.slice(0,t.length-1),ratio:n}}return null}function wp(e,t){const o=[];function i(n){for(const s of n){const l=co(s);if(l){const{imageNode:r,layout:a,ratio:c}=l;r.ial||(r.ial={});const u=r.ial[be];if(u!==a){const h={blockId:r.id,layout:a,previousLayout:u,ratio:c};r.ial[be]=a,o.push(h),t&&t(h)}}s.children&&s.children.length>0&&i(s.children)}}return i(e),o}function $i(e){return(e.children||[]).filter(t=>{const o=t.type||"";if(o==="NodeSuperBlockOpenMarker"||o==="NodeSuperBlockLayoutMarker"||o==="NodeSuperBlockCloseMarker"||o==="open-marker"||o==="layout-marker"||o==="close-marker")return!1;const i=(t.markdown||t.content||"").trim();return!(/^\{\{\{(?:col|row)?\s*$/i.test(i)||i==="}}}")})}function oc(e){if(!e)return!1;const t=(e.type||"").toLowerCase();if(t==="h"||t==="nodeheading"||/^h[1-6]$/i.test(e.subType||""))return!0;const o=(e.markdown||e.content||"").trim();return!!/^#{1,6}\s+/.test(o)}function Go(e,t,o){let i="",n=0;const s=/<div\b([^>]*)>/gi;for(;n<e.length;){s.lastIndex=n;let l,r=!1,a=-1,c=0;for(;(l=s.exec(e))!==null;){const g=l[1].match(/\bclass=["']([^"']*)["']/i);if(g){const x=g[1];if(typeof t=="string"?x.split(/\s+/).includes(t):t.test(x)){r=!0,a=l.index,c=l[0].length;break}}}if(!r){i+=e.slice(n);break}i+=e.slice(n,a);const u=a+c;let f=1,h=-1,d=-1;const b=/<\/?div\b[^>]*>/gi;b.lastIndex=u;let m;for(;(m=b.exec(e))!==null;)if(m[0].startsWith("</")){if(f--,f===0){h=m.index,d=m.index+m[0].length;break}}else f++;if(h!==-1&&d!==-1){const y=e.slice(u,h);i+=o(y),n=d}else i+=e.slice(a,u),n=u}return i}function xp(e){const t=[];let o="",i=0;const n=/<div\b([^>]*)>/gi;for(;i<e.length;){n.lastIndex=i;let s,l=!1,r=-1,a=0;for(;(s=n.exec(e))!==null;){const m=s[1];if(/(?:\s@[a-zA-Z0-9_-]+=\s*["']|\s:[a-zA-Z0-9_-]+=\s*["']|\sv-[a-zA-Z0-9_.-]+|\shover:[a-zA-Z0-9_.-]+=\s*["']|\sgrid=["']~|\bclass=["'][^"']*\b(?:abs-br|slidev-icon-btn|grid\s+|grid$|grid-cols-|relative\b)\b[^"']*["']|\bstyle=["'][^"']*\bgrid-[^"']*["'])/i.test(m)){l=!0,r=s.index,a=s[0].length;break}}if(!l){o+=e.slice(i);break}o+=e.slice(i,r);const c=r+a;let u=1,f=-1,h=-1;const d=/<\/?div\b[^>]*>/gi;d.lastIndex=c;let b;for(;(b=d.exec(e))!==null;)if(b[0].startsWith("</")){if(u--,u===0){f=b.index,h=b.index+b[0].length;break}}else u++;if(f!==-1&&h!==-1){const m=e.slice(r,h),y=`__VUE_DIV_TOKEN_${t.length}__`;t.push(m),o+=y,i=h}else o+=e.slice(r,c),i=c}return{text:o,tokens:t}}function Sp(e){const t=[];let o=e.replace(/(?:^[ \t]*(`{3,}|~{3,})[^\n\r]*\r?\n[\s\S]*?\r?\n[ \t]*\1(?=[ \t]*(?:\r?\n|$)))/gm,r=>{const a=`__CODE_TOKEN_${t.length}__`;return t.push(r),a});o=o.replace(/(`+)(?:[^\n\r`]|(?!\1)`)+?\1/g,r=>{const a=`__CODE_TOKEN_${t.length}__`;return t.push(r),a});const i=[];o=o.replace(/<script\b[^>]*>[\s\S]*?<\/script>/gi,r=>{const a=`__SCRIPT_TOKEN_${i.length}__`;return i.push(r),a});const{text:n,tokens:s}=xp(o);o=n;const l=[];o=o.replace(/<(?:[A-Z][a-zA-Z0-9_-]*|[a-z0-9_-]+:[a-z0-9_-]+|v-[a-z0-9_-]+|arrow\b|div\s+h-\d+)\b[^>]*\/>/gi,r=>{const a=`__VUE_COMP_TOKEN_${l.length}__`;return l.push(r),a}),o=o.replace(/<(v-[a-z0-9_-]+|button)\b([^>]*)>([\s\S]*?)<\/\1>/gi,r=>{const a=`__VUE_COMP_TOKEN_${l.length}__`;return l.push(r),a}),o=o.replace(/<img\b[^>]*?\bv-[a-z0-9_.-]+[^>]*\/?>/gi,r=>{const a=`__VUE_COMP_TOKEN_${l.length}__`;return l.push(r),a}),o=o.replace(/<(p|span)\b([^>]*?\bv-[a-z0-9_.-]+[^>]*)>([\s\S]*?)<\/\1>/gi,r=>{const a=`__VUE_COMP_TOKEN_${l.length}__`;return l.push(r),a}),o=o.replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi,""),o=o.replace(/<div class="terminal-bar">[\s\S]*?<\/div>/gi,""),o=o.replace(/<div class="cursor-line">[\s\S]*?<\/div>/gi,""),o=o.replace(/<span class="cursor">[\s\S]*?<\/span>/gi,""),o=o.replace(/<div class="stamp">\s*([\s\S]*?)\s*<\/div>/gi,`

*[$1]*

`),o=o.replace(/<div class="arrow">\s*([→\->]+)\s*<\/div>/gi,`

$1

`),o=o.replace(/<i>\s*[→\->]+\s*<\/i>/gi,""),o=o.replace(/<div class="prompt">\s*([\s\S]*?)\s*<\/div>/gi,(r,a)=>`
\`\`\`bash
${a.trim()}
\`\`\`
`),o=o.replace(/<p>\s*<i>\$<\/i>\s*([\s\S]*?)<\/p>/gi,(r,a)=>`
\`\`\`bash
$ ${a.trim()}
\`\`\`
`),o=o.replace(/<div class="statusline">\s*([\s\S]*?)\s*<\/div>/gi,(r,a)=>`
> ${Array.from(a.matchAll(/<span>([\s\S]*?)<\/span>/gi)).map(u=>`\`${u[1].trim()}\``).join(" | ")}
`),o=o.replace(/<div class="log-panel">\s*<pre>([\s\S]*?)<\/pre>\s*<\/div>/gi,(r,a)=>`
\`\`\`log
${a.replace(/<span[^>]*>([\s\S]*?)<\/span>/gi,"$1").trim()}
\`\`\`
`),o=Go(o,"diff-grid",r=>{const a=Array.from(r.matchAll(/<div class="diff\s+([^"]*)">\s*<span>(.*?)<\/span>\s*<pre>([\s\S]*?)<\/pre>\s*<\/div>/gi));return a.length>0?`
`+a.map(c=>{const u=c[2].trim().toUpperCase(),f=c[3].trim();return`**${u}:**
\`\`\`yaml
${f}
\`\`\``}).join(`

`)+`
`:r}),o=Go(o,"before-after",r=>{const a=r.match(/<div class="before">[\s\S]*?<small>(.*?)<\/small>[\s\S]*?<h2>(.*?)<\/h2>[\s\S]*?<p>(.*?)<\/p>\s*<\/div>/i),c=r.match(/<div class="after">[\s\S]*?<small>(.*?)<\/small>[\s\S]*?<h2>(.*?)<\/h2>[\s\S]*?<p>(.*?)<\/p>\s*<\/div>/i);let u=`
`;return a&&(u+=`### ${a[1]}
## ${a[2]}
${a[3]}

`),c&&(u+=`### ${c[1]}
## ${c[2]}
${c[3]}
`),u.trim()?u:r}),o=o.replace(/<ul\b[^>]*>([\s\S]*?)<\/ul>/gi,(r,a)=>{const c=Array.from(a.matchAll(/<li>\s*(?:<em>)?(\[[x ]\])(?:<\/em>)?\s*([\s\S]*?)<\/li>/gi));return c.length>0?`
`+c.map(u=>`- ${u[1]} ${u[2].trim()}`).join(`
`)+`
`:a}),o=Go(o,"timeline",r=>{const a=Array.from(r.matchAll(/<div(?:\s+class="([^"]*)")?>\s*<time>([\s\S]*?)<\/time>\s*<b>([\s\S]*?)<\/b>\s*<span>([\s\S]*?)<\/span>\s*<\/div>/gi));return a.length>0?`

`+a.map(c=>{const u=c[1]||"";let f="-";return u.includes("warn")?f="- ⚠️":u.includes("bad")?f="- ❌":u.includes("ok")&&(f="- ✅"),`${f} **${c[2].trim()}** **${c[3].trim()}** — ${c[4].trim()}`}).join(`
`)+`

`:r}),o=Go(o,"pipeline",r=>{const a=Array.from(r.matchAll(/<div(?:\s+class="([^"]*)")?>\s*<small>([\s\S]*?)<\/small>\s*<b>([\s\S]*?)<\/b>\s*<span>([\s\S]*?)<\/span>\s*<\/div>/gi));return a.length>0?`

`+a.map((c,u)=>{const h=(c[1]||"").includes("hot")?"⚠️ ":"";return`${u+1}. ${h}**${c[3].trim()}** (*${c[4].trim()}*)`}).join(`
`)+`

`:r}),o=Go(o,"check-grid",r=>{const a=Array.from(r.matchAll(/<div>\s*<span class="([^"]*)"><\/span>\s*<b>([\s\S]*?)<\/b>\s*<p>([\s\S]*?)<\/p>\s*<\/div>/gi));return a.length>0?`

`+a.map(c=>`- ${(c[1]||"").includes("warn")?"⚠️":"✅"} **${c[2].trim()}**: ${c[3].trim()}`).join(`
`)+`

`:r}),o=Go(o,"manifesto",r=>{const a=Array.from(r.matchAll(/<div>\s*<span>([\s\S]*?)<\/span>\s*<h2>([\s\S]*?)<\/h2>\s*<p>([\s\S]*?)<\/p>\s*<\/div>/gi));return a.length>0?`

`+a.map(c=>`## ${c[1].trim()} ${c[2].trim()}

${c[3].trim()}`).join(`

`)+`

`:r}),o=Go(o,"split-note",r=>{const a=Array.from(r.matchAll(/<div>\s*<b>([\s\S]*?)<\/b>\s*<p>([\s\S]*?)<\/p>\s*<\/div>/gi));return a.length>0?`

`+a.map(c=>`> **${c[1].trim()}**: ${c[2].trim()}`).join(`
>
`)+`

`:r}),o=o.replace(/<div class="mechanism">\s*<b>([\s\S]*?)<\/b>\s*<p>([\s\S]*?)<\/p>\s*<\/div>/gi,(r,a,c)=>`

> **${a.trim()}**: ${c.trim()}

`),o=o.replace(/<pre>([\s\S]*?)<\/pre>/gi,(r,a)=>`
\`\`\`text
${a.replace(/<span[^>]*>([\s\S]*?)<\/span>/gi,"$1").trim()}
\`\`\`
`),o=o.replace(/<div class="page-head">\s*<span>([\s\S]*?)<\/span>\s*<b>([\s\S]*?)<\/b>\s*<\/div>/gi,`
### $1 ($2)
`),o=o.replace(/<h1\b[^>]*>([\s\S]*?)<\/h1>/gi,`
# $1
`),o=o.replace(/<h2\b[^>]*>([\s\S]*?)<\/h2>/gi,`
## $1
`),o=o.replace(/<h3\b[^>]*>([\s\S]*?)<\/h3>/gi,`
### $1
`),o=o.replace(/<h4\b[^>]*>([\s\S]*?)<\/h4>/gi,`
#### $1
`),o=o.replace(/<p\s+class="ok">\s*●\s*([\s\S]*?)<\/p>/gi,`
✅ **$1**
`),o=o.replace(/<p\s+class="caption">\s*([\s\S]*?)<\/p>/gi,`
> *$1*
`),o=o.replace(/<p\s+class="lead">\s*([\s\S]*?)<\/p>/gi,`
*$1*
`),o=o.replace(/<p\b([^>]*)>([\s\S]*?)<\/p>/gi,(r,a,c)=>/@|v-|:|class=/i.test(a)?r:`
${c.trim()}

`),o=o.replace(/<br\s*\/?>/gi,`
`),o=o.replace(/<hr\s*\/?>/gi,`
---
`),o=o.replace(/<b\b[^>]*>([\s\S]*?)<\/b>/gi,"**$1**"),o=o.replace(/<strong\b[^>]*>([\s\S]*?)<\/strong>/gi,"**$1**"),o=o.replace(/<i\b[^>]*>([\s\S]*?)<\/i>/gi,"*$1*"),o=o.replace(/<code\b[^>]*>([\s\S]*?)<\/code>/gi,(r,a)=>{if(a.startsWith("`")&&a.endsWith("`"))return a;if(a.includes("`")){const c=(a.match(/`+/g)||[]).reduce((f,h)=>Math.max(f,h.length),0),u="`".repeat(c+1);return`${u} ${a} ${u}`}return`\`${a}\``}),o=o.replace(/<small\b[^>]*>([\s\S]*?)<\/small>/gi,"*$1*"),o=o.replace(/\*{4}/g,"** **"),o=o.replace(/<li\b[^>]*>([\s\S]*?)<\/li>/gi,`- $1
`),o=o.replace(/<ul\b[^>]*>([\s\S]*?)<\/ul>/gi,`
$1
`),o=o.replace(/<ol\b[^>]*>([\s\S]*?)<\/ol>/gi,`
$1
`),o=o.replace(/<a\b([^>]*)href=["'](.*?)["']([^>]*)>([\s\S]*?)<\/a>/gi,(r,a,c,u,f)=>{const h=f.trim();return h.includes("<")||h.includes(`
`)?r:`[${h}](${c})`}),o=o.replace(/<blockquote\b[^>]*>([\s\S]*?)<\/blockquote>/gi,(r,a)=>`
`+a.trim().split(`
`).map(c=>`> ${c.trim()}`).join(`
`)+`
`),o=o.replace(/<span\b[^>]*data-type=["']block-ref["'][^>]*data-id=["']([0-9a-zA-Z-]+)["'][^>]*>([\s\S]*?)<\/span>/gi,(r,a,c)=>{const u=c.replace(/<[^>]+>/g,"").trim();return u?`((${a} '${u}'))`:`((${a}))`}),o=o.replace(/<span\b[^>]*data-type=["']a["'][^>]*data-href=["']([^"']+)["'][^>]*>([\s\S]*?)<\/span>/gi,(r,a,c)=>`[${c.replace(/<[^>]+>/g,"").trim()}](${a})`),o=o.replace(/<\/(?:div|section|header|footer|main|article|nav|aside)\b[^>]*>/gi,`
`),o=o.replace(/<(?:div|section|header|footer|main|article|nav|aside)\b[^>]*>/gi,""),o=o.replace(/<\/?span\b[^>]*>/gi,"");for(let r=0;r<l.length;r++)o=o.replace(`__VUE_COMP_TOKEN_${r}__`,()=>l[r]);for(let r=0;r<s.length;r++)o=o.replace(`__VUE_DIV_TOKEN_${r}__`,()=>s[r]);for(let r=0;r<i.length;r++)o=o.replace(`__SCRIPT_TOKEN_${r}__`,()=>i[r]);for(let r=0;r<t.length;r++)o=o.replace(`__CODE_TOKEN_${r}__`,()=>t[r]);return o=o.replace(/\n{3,}/g,`

`).trim(),o}function ic(e){if(!e||typeof e!="string")return"";const t=[];let o=e.replace(/`([^`]+)`/g,i=>(t.push(i),`%%INLINE_CODE_${t.length-1}%%`));return o=o.replace(/(<\/[a-zA-Z0-9_-]+>)\s*\{:[^}]*\}/g,"$1"),o=o.replace(/(\[[^\]]+\]\([^)]+\))\s*\{:\s*style=["']([^"']*)["'][^}]*\}/g,'<span style="$2">$1</span>'),o=o.replace(/(\*\*[^*]+\*\*)\s*\{:\s*style=["']([^"']*)["'][^}]*\}/g,'<span style="$2">$1</span>'),o=o.replace(/(\*[^*]+\*)\s*\{:\s*style=["']([^"']*)["'][^}]*\}/g,'<span style="$2">$1</span>'),o=o.replace(/(~~[^~]+~~)\s*\{:\s*style=["']([^"']*)["'][^}]*\}/g,'<span style="$2">$1</span>'),o=o.replace(/([\p{L}\p{N}_\-]+)\s*\{:\s*style=["']([^"']*)["'][^}]*\}/gu,'<span style="$2">$1</span>'),o=o.replace(/\{:[^}]*\}/g,""),o=o.replace(/%%INLINE_CODE_(\d+)%%/g,(i,n)=>t[parseInt(n,10)]||""),o}function Vs(e){if(!e)return"";const t=e.trim();return t?/^\d+$/.test(t)?`${t}px`:/^(\d+(?:\.\d+)?)%$/.test(t)?`${t.slice(0,-1)}cqh`:/^(\d+(?:\.\d+)?)vh$/.test(t)?`${t.slice(0,-2)}cqh`:t:""}function Sr(e){if(!e)return"";let t=e.trim();t=t.replace(/\{:[^}]*\}/g,"").trim(),t=t.replace(/^:::\s*[a-zA-Z0-9_-]*\s*\r?\n?/g,""),t=t.replace(/\r?\n?:::\s*$/g,"");let n=t.split(/\r?\n/).map(s=>s.trim().replace(/^>\s*/,"")).join(`
`).trim();return n=n.replace(/^\[!(?:NOTE|TIP|IMPORTANT|WARNING|CAUTION|[A-Za-z_-]+)\][^\r\n]*(?:\r?\n)?/i,"").trim(),n=n.replace(/^(?:💡|✏️|❗|⚠️|🚨|\s*)*(?:\*\*|__)?(?:演讲备注|演讲者提词|讲稿备注|演讲提词|备注|Notes?)(?:\*\*|__)?[:：]?\s*(?:\r?\n)?/i,"").trim(),n=n.replace(/^[-*+]\s+/,""),n=n.replace(/^\d+\.\s+/,""),n.trim()}function Cp(e){var i;if(e.subType&&/^h([1-6])$/i.test(e.subType))return parseInt(e.subType.slice(1),10);const o=(e.markdown||e.content||"").trim().match(/^(#{1,6})\s+/);return o?o[1].length:e.type==="h"?(i=e.ial)!=null&&i.subType&&/^h([1-6])$/i.test(e.ial.subType)?parseInt(e.ial.subType.slice(1),10):1:null}function Ks(e,t=2){const o=Math.max(2,t);if(!e||e.length===0)return Array.from({length:o},()=>[]);if(e.length===1&&e[0].children&&e[0].children.length>=2){const c=e[0].children,u=Array.from({length:o},()=>[]),f=Math.min(o,c.length),h=Math.floor(c.length/f),d=c.length%f;let b=0;for(let m=0;m<f;m++){const y=h+(m<d?1:0);u[m]=c.slice(b,b+y),b+=y}return u}if(e.length===1){const c=e[0],f=(c.slot||"").trim().match(/^col-(\d+)$/i),h=f?parseInt(f[1],10):null,d=(c.rawMarkdown||c.content||"").trim(),b=d.split(/\r?\n/),m=[];for(let x=0;x<b.length;x++)/^[ \t]*[-*+]\s+|^[ \t]*\d+\.\s+/.test(b[x])&&m.push(x);if(m.length>=o){const x=Array.from({length:o},()=>[]);let k=0;for(let I=0;I<o;I++){const T=o-I,w=m.length-k,C=Math.ceil(w/T),L=m[k],R=k+C<m.length?m[k+C]:b.length,N=b.slice(L,R).join(`
`);x[I]=[{...c,id:I===0?c.id:`${c.id}-col${I+1}`,rawMarkdown:N,content:N}],k+=C}return x}const y=d.match(/<li[\s\S]*?<\/li>/gi);if(y&&y.length>=o){const x=Array.from({length:o},()=>[]);let k=0;for(let I=0;I<o;I++){const T=o-I,w=y.length-k,C=Math.ceil(w/T),L=`<ul>
${y.slice(k,k+C).join(`
`)}
</ul>`;x[I]=[{...c,id:I===0?c.id:`${c.id}-col${I+1}`,rawMarkdown:L,content:L}],k+=C}return x}const g=d.split(/\r?\n\s*\r?\n/).filter(x=>x.trim()!=="");if(g.length>=o){const x=Array.from({length:o},()=>[]);let k=0;for(let I=0;I<o;I++){const T=o-I,w=g.length-k,C=Math.ceil(w/T),L=g.slice(k,k+C).join(`

`);x[I]=[{...c,id:I===0?c.id:`${c.id}-col${I+1}`,rawMarkdown:L,content:L}],k+=C}return x}if(h&&h>=1&&h<=o){const x=Array.from({length:o},()=>[]);return x[h-1]=[c],x}return[[c],...Array.from({length:o-1},()=>[])]}const i=c=>{const u=(c.slot||"").trim();if(!u)return null;if(u==="left")return 1;if(u==="center")return 2;if(u==="right")return o===2?2:o;const f=u.match(/^col-(\d+)$/i);if(f){const h=parseInt(f[1],10);if(h>=1&&h<=o)return h}return null},n=e.map(i);if(n.some(c=>c!==null)){if(n.some(d=>d!==null&&d>=2)){const d=Array.from({length:o},()=>[]);let b=1;for(const y of e){const g=i(y);g!==null&&(b=g),d[b-1].push(y)}if(!e.some(y=>/^col-\d+$/i.test((y.slot||"").trim()))&&d[0].length===0){const y=d.filter(g=>g.length>0);if(y.length===1)return[y[0],...Array.from({length:o-1},()=>[])]}return d}const u=e.filter(d=>i(d)===1),f=e.filter(d=>i(d)===null),h=o-1;if(f.length>=h){const d=Math.floor(f.length/h),b=f.length%h,m=[u];let y=0;for(let g=0;g<h;g++){const x=d+(g<b?1:0);m.push(f.slice(y,y+x)),y+=x}return m}else if(f.length>0){const d=[u];for(let b=0;b<h;b++)d.push(b<f.length?[f[b]]:[]);return d}else return[u,...Array.from({length:h},()=>[])]}const l=c=>{if(c.type==="h"||c.subType&&/^h[1-6]$/i.test(c.subType))return!0;const u=(c.rawMarkdown||c.content||"").trim();return/^#{1,6}\s+/.test(u)},r=e.map((c,u)=>l(c)?u:-1).filter(c=>c!==-1);if(r.length>=o){const c=Array.from({length:o},()=>[]);for(let u=0;u<o;u++){const f=r[u],h=u+1<o?r[u+1]:e.length;c[u]=e.slice(f,h)}return c}if(e.length>=o){const c=Array.from({length:o},()=>[]);let u=0;for(let f=0;f<o;f++){const h=o-f,d=e.length-u,b=Math.ceil(d/h);c[f]=e.slice(u,u+b),u+=b}return c}if(e.length>1&&e.length<o){const c=Array.from({length:o},()=>[]);for(let u=0;u<e.length;u++)c[u]=[e[u]];return c}const a=Array.from({length:o},()=>[]);return a[0]=e,a}function va(e,t,o,i){const n=mp(t),s=[],l=ya(t),r=n.background?Ot(n.background,i):void 0;let a={pageIndex:1,startBlockId:e,frontmatter:{layout:l.frontmatter.layout||"cover",...l.frontmatter,...r?{background:r}:{}},notes:"",noteBlocks:[],blocks:[],rawMarkdown:"",allBlockIds:[e]};a.frontmatter.background&&(a.frontmatter.background=Ot(a.frontmatter.background,i)),a.frontmatter.image&&(a.frontmatter.image=Ot(a.frontmatter.image,i));const c=d=>{const b=[];for(let m=d;m<o.length&&!(m>d&&wo(o[m]));m++)b.push(o[m]);return b},u=d=>{let b,m,y;const g=x=>{var C;if(b)return;const k=co(x);if(k){b=k.layout,m=k.imageUrl,y=k.ratio;return}const I=Nr(x),T=x.ial?{...x.ial}:{},w=ba(T);if(w.imageLayout==="image-left"||w.imageLayout==="image-right"){const L=Co(I,x.content);if(L){b=w.imageLayout,m=L,y=(C=x.ial)==null?void 0:C[bt];return}}if(x.children&&x.children.length>0){for(const L of x.children)if(g(L),b)return}};for(const x of d)if(g(x),b)break;return{foundLayout:b,foundImage:m,foundRatio:y}},f=(d,b)=>{const{foundLayout:m,foundImage:y,foundRatio:g}=u(b);m&&(d.frontmatter.layout=m,y&&(d.frontmatter.image=Ot(y,i)),g&&!d.frontmatter.layoutRatio&&(d.frontmatter.layoutRatio=g))};f(a,c(0)),s.push(a);let h=[];for(let d=0;d<o.length;d++){const b=o[d];if(wo(b)){h=[];const y=ya(b.ial);if(s.length===1&&a.blocks.length===0){a.startBlockId=b.id,a.allBlockIds||(a.allBlockIds=[]),a.allBlockIds.includes(b.id)||a.allBlockIds.push(b.id),y.frontmatter.layout&&(a.frontmatter.layout=y.frontmatter.layout),Object.assign(a.frontmatter,y.frontmatter),delete a.frontmatter.background,!y.frontmatter.image&&l.frontmatter.image&&(a.frontmatter.image=l.frontmatter.image),r&&(a.frontmatter.background=r),a.frontmatter.background&&(a.frontmatter.background=Ot(a.frontmatter.background,i)),a.frontmatter.image&&(a.frontmatter.image=Ot(a.frontmatter.image,i)),f(a,c(d+1));continue}a={pageIndex:s.length+1,startBlockId:b.id,frontmatter:{layout:y.frontmatter.layout||"default",...y.frontmatter,...r?{background:r}:{}},notes:"",noteBlocks:[],blocks:[],rawMarkdown:"",allBlockIds:[b.id]},r||delete a.frontmatter.background,a.frontmatter.background&&(a.frontmatter.background=Ot(a.frontmatter.background,i)),a.frontmatter.image&&(a.frontmatter.image=Ot(a.frontmatter.image,i)),f(a,c(d+1)),s.push(a);continue}const m=(y,g)=>{var ne,oe,ae,Se,$e,ke,Ce;if(a.allBlockIds||(a.allBlockIds=[]),y.id&&!a.allBlockIds.includes(y.id)&&a.allBlockIds.push(y.id),y.children&&y.children.length>0){const z=se=>{for(const D of se)D.id&&!a.allBlockIds.includes(D.id)&&a.allBlockIds.push(D.id),D.children&&D.children.length>0&&z(D.children)};z(y.children)}let x=Nr(y),k=y.ial?{...y.ial}:{};const I=x.match(/\{:\s*([^}]+)\s*\}\s*$/);I&&(k={...Ua(I[0]),...k},x=x.slice(0,I.index).trim()),y.type!=="c"&&!x.startsWith("```")&&(x=ic(x));let T=x.trim();if(/^\{\{\{(?:row|col)?\s*$/i.test(T)||T==="}}}")return;/^\{\{\{(?:row|col)?\s*\r?\n/i.test(T)&&/\r?\n\}\}\}$/.test(T)&&(x=T.replace(/^\{\{\{(?:row|col)?\s*\r?\n/i,"").replace(/\r?\n\}\}\}$/,"").trim(),T=x.trim());const w=ba(k);if(x=Rd(x,i),x=Od(x,i==null?void 0:i.refContentMap),y.children&&y.children.length>0){const z=["custom-slides-autoplay","custom-slides-loop","custom-slides-muted","custom-slides-controls"],se=D=>{for(const V of D){if(V.ial)for(const[v,K]of Object.entries(V.ial))z.includes(v)&&!k[v]&&(k[v]=K);V.children&&V.children.length>0&&se(V.children)}};se(y.children)}const C=y.type==="video"||y.type==="NodeVideo"||/<video\b/i.test(x);if(C){const z=k["custom-slides-autoplay"]==="true",se=k["custom-slides-loop"]==="true",D=k["custom-slides-muted"]==="true"||z,V=k["custom-slides-controls"]==="false";x=x.replace(/<video\b([^>]*)>/gi,(v,K)=>{let H=K;return V?H=H.replace(/\bcontrols(?:="[^"]*")?/gi,"").trim():/controls/i.test(H)||(H+=" controls"),z&&!/autoplay/i.test(H)?H+=" autoplay playsinline":!z&&k["custom-slides-autoplay"]==="false"&&(H=H.replace(/\bautoplay\b/gi,"").replace(/\bplaysinline\b/gi,"").trim()),se&&!/loop/i.test(H)?H+=" loop":!se&&k["custom-slides-loop"]==="false"&&(H=H.replace(/\bloop\b/gi,"").trim()),D&&!/muted/i.test(H)?H+=" muted":!D&&k["custom-slides-muted"]==="false"&&(H=H.replace(/\bmuted\b/gi,"").trim()),`<video ${H.trim()}>`})}if(w.isBackground){const z=Co(x,y.content);if(z){a.frontmatter.background=Ot(z,i);return}}const L=co(y);if(L){a.frontmatter.layout=L.layout,a.frontmatter.image=Ot(L.imageUrl,i),!a.frontmatter.layoutRatio&&L.ratio&&(a.frontmatter.layoutRatio=L.ratio);for(const z of L.contentNodes)m(z);return}if(w.imageLayout==="image-left"||w.imageLayout==="image-right"){const z=Co(x,y.content);if(z){a.frontmatter.layout=w.imageLayout,a.frontmatter.image=Ot(z,i),!a.frontmatter.layoutRatio&&((ne=y.ial)!=null&&ne[bt])&&(a.frontmatter.layoutRatio=y.ial[bt]);return}}if(ft(y)&&y.children&&y.children.length>0){for(const z of y.children)m(z);return}const R=!!(w.slot||g!=null&&g.defaultSlot||a.frontmatter.layout==="clover"||a.frontmatter.layout==="timeline"||a.frontmatter.layout==="steps"||pi(a.frontmatter.layout)||a.frontmatter.layout==="two-cols"),N=!!(y.children&&y.children.some(z=>{var se,D;return((se=z.ial)==null?void 0:se[Ae])||((D=z.ial)==null?void 0:D[Ne])||z.children&&z.children.length>=2||z.children&&z.children.some(V=>{var v,K,H,$,A,P;return((v=V.ial)==null?void 0:v[Ne])||((K=V.ial)==null?void 0:K[Ae])||((H=V.ial)==null?void 0:H[Ze])||(($=V.ial)==null?void 0:$[be])||((A=V.ial)==null?void 0:A["custom-slides-role"])||((P=V.ial)==null?void 0:P["custom-slides-layout"])})}));if((y.type==="l"||y.type==="NodeList"||y.type==="list")&&y.children&&y.children.length>0&&(N||w.slot||w.clicks||R)){const z=/^\s*\d+\.\s+/m.test(y.markdown||"")||y.subType==="o"||y.subtype==="o";for(let se=0;se<y.children.length;se++){const D=y.children[se];w.slot&&(!D.ial||!D.ial[Ae])&&(D.ial||(D.ial={}),D.ial[Ae]=w.slot),m(D,{...g,parentClicks:w.clicks||(g==null?void 0:g.parentClicks),defaultSlot:w.slot||(g==null?void 0:g.defaultSlot),isParentListUnpacked:!0,isListItem:!0,listContext:{isOrdered:z,itemIndex:se+1}})}return}const F=!!(g!=null&&g.isParentListUnpacked),E=!!(y.children&&y.children.length>=2)||!!w.clicks||!!((oe=y.children)!=null&&oe.some(z=>{var se;return(se=z.ial)==null?void 0:se[Ne]}))||F||!y.markdown&&!!(y.children&&y.children.length>0);if(Uo(y)&&y.children&&y.children.length>0&&(R||F||w.clicks||y.children.some(z=>{var se;return(se=z.ial)==null?void 0:se[Ne]}))&&E){const z=!!(y.children&&y.children.length>=2),se=y.children.find(A=>!!(A.markdown||A.content||"").trim())||y.children[0],D=((ae=se==null?void 0:se.ial)==null?void 0:ae[Ne])||((Se=se==null?void 0:se.ial)==null?void 0:Se["custom-slides-click"]),V=!!(!w.clicks&&z&&D),v=w.clicks||(V?D:void 0)||(g==null?void 0:g.parentClicks),K=y.id||(g==null?void 0:g.parentContainerId),H=w.slot||(g==null?void 0:g.defaultSlot);let $=!0;for(const A of y.children){H&&(!A.ial||!A.ial[Ae])&&(A.ial||(A.ial={}),A.ial[Ae]=H);const P=!!(A.markdown||A.content||"").trim(),Y=$&&P;if(Y){if(!(a.frontmatter.layout==="image-right"||a.frontmatter.layout==="image-left")&&!!(a.frontmatter.layout==="clover"||a.frontmatter.layout==="timeline"||a.frontmatter.layout==="steps"||pi(a.frontmatter.layout)||a.frontmatter.layout==="two-cols")&&!!(g!=null&&g.defaultSlot||w.slot||($e=y.ial)!=null&&$e[Ae]))A.markdown&&(A.markdown=Ft(A.markdown)),A.content&&(A.content=Ft(A.content));else{const re=!!((ke=g==null?void 0:g.listContext)!=null&&ke.isOrdered),me=((Ce=g==null?void 0:g.listContext)==null?void 0:Ce.itemIndex)||1,_e=re?`${me}. `:"- ",we=De=>{if(!De)return _e.trim();const He=De.trim();return/^[-*+]\s+/.test(He)||/^\d+\.\s+/.test(He)?De:`${_e}${De}`};A.markdown&&(A.markdown=we(A.markdown)),A.content&&(A.content=we(A.content))}$=!1}let G=A;Y&&v&&z?(G={...A,ial:{...A.ial||{}}},delete G.ial[Ne],delete G.ial["custom-slides-click"]):!z&&v&&(G={...A,ial:{...A.ial||{},[Ne]:v}}),m(G,{...g,parentClicks:v,parentContainerId:K,defaultSlot:H,isListItem:!0})}return}if(w.isNote){const z=Sr(x);z&&(a.notes?a.notes+=`

`+z:a.notes=z),a.noteBlocks||(a.noteBlocks=[]),a.noteBlocks.push({id:y.id,type:y.type,content:z||y.content||"",rawMarkdown:x,isNote:!0,attributes:y.ial});return}T=x.trim();const O=(y.content||"").trim();if(T==="::right::"||O==="::right::"||/^<p>\s*::right::\s*<\/p>$/i.test(T)||T.startsWith("::right::")){a.blocks.push({id:y.id,type:y.type,content:"::right::",rawMarkdown:"::right::",slot:"slot-divider-right",attributes:y.ial});return}const W=Cp(y);let j=w.slot,_=w.clicks,M=w.motion,B={...y.ial||{}};if(W!==null){for(;h.length>0&&h[h.length-1].level>=W;)h.pop();const z=h.length>0?h[h.length-1]:void 0;!j&&(z!=null&&z.slot)&&(j=z.slot),!_&&(z!=null&&z.clicks)&&!(g!=null&&g.parentContainerId)&&(_=z.clicks),!M&&(z!=null&&z.motion)&&(M=z.motion);const se={...(z==null?void 0:z.customAttrs)||{}};if(y.ial)for(const[D,V]of Object.entries(y.ial))D.startsWith("custom-slides-")&&!D.startsWith("custom-slides-slide")&&(se[D]=V);g!=null&&g.parentContainerId||h.push({level:W,slot:j,clicks:_,motion:M,customAttrs:se})}else{const z=h.length>0?h[h.length-1]:void 0;z&&(!j&&z.slot&&z.slot!=="header"&&(j=z.slot),!_&&z.clicks&&!(g!=null&&g.parentContainerId)&&(_=z.clicks),!M&&z.motion&&(M=z.motion),z.customAttrs&&(B={...z.customAttrs,...B}))}!j&&a.blocks.some(z=>z.slot==="slot-divider-right")&&(j="right"),!j&&(g!=null&&g.defaultSlot)&&(j=g.defaultSlot),j&&(B[Ae]=j),_&&!B[Ne]&&(B[Ne]=_),M&&!B[Bt]&&(B[Bt]=JSON.stringify(M)),(C||k["custom-slides-autoplay"]||k["custom-slides-muted"])&&(k["custom-slides-autoplay"]&&(B["custom-slides-autoplay"]=k["custom-slides-autoplay"],k["custom-slides-autoplay"]==="true"&&!k["custom-slides-muted"]&&(B["custom-slides-muted"]="true")),k["custom-slides-loop"]&&(B["custom-slides-loop"]=k["custom-slides-loop"]),k["custom-slides-muted"]&&(B["custom-slides-muted"]=k["custom-slides-muted"]),k["custom-slides-controls"]&&(B["custom-slides-controls"]=k["custom-slides-controls"]));const Q=w.maxHeight?Vs(w.maxHeight):void 0,q=!!(g!=null&&g.isListItem||Uo(y)),U={id:y.id,type:y.type,content:y.content||"",rawMarkdown:x,clicks:_,parentClicks:g==null?void 0:g.parentClicks,parentContainerId:g==null?void 0:g.parentContainerId,motion:M,shikiLines:w.shikiLines,maxHeight:Q,slot:j,attributes:B,attrs:B,rawNode:y,isListItem:q};a.blocks.push(U)};m(b)}for(let d=0;d<s.length;d++){const b=s[d],m=b.blocks.filter(x=>x.slot!=="slot-divider-right"),y=x=>{const k=x.filter(C=>!!(C.rawMarkdown||C.content||"").trim());if(k.length===0)return;const I=k[0],T=(I.rawMarkdown||I.content||"").trim();(Uo(I)||/^(?:[-*+]|\d+\.)\s+/.test(T))&&(I.rawMarkdown=Ft(I.rawMarkdown||I.content||""),I.content=I.rawMarkdown)},g=b.frontmatter.layout||"default";if(g==="clover"||g==="timeline"||g==="steps"||pi(g)){let x=[];const k=m.filter(L=>L.slot==="header");if(k.length>0)x=k;else if(m.length>0){const L=m.find(R=>R.type==="h"&&(!R.slot||R.slot==="default"));L&&(x=[L])}const I=m.filter(L=>!x.includes(L));let T=2;if(g==="clover")T=4;else if(g==="timeline"||g==="steps")I.length===1&&I[0].children&&I[0].children.length>=2?T=Math.min(6,Math.max(2,I[0].children.length)):I.length>=2?T=Math.min(6,I.length):T=3;else if(g==="three-cols-header")T=3;else if(g==="two-cols-header")T=2;else{let L=0;for(const R of I){const N=(R.slot||"").match(/^col-(\d+)$/i);N&&(L=Math.max(L,parseInt(N[1],10)))}if(L>=2)T=L;else if(b.frontmatter.layoutRatio){const R=b.frontmatter.layoutRatio.trim();if(R.includes(":")){const N=R.split(":").map(F=>parseFloat(F.trim())).filter(F=>!isNaN(F)&&F>0);N.length>=2&&(T=N.length)}else{const N=R.split(/\s+/).filter(Boolean);N.length>=2&&(T=N.length)}}else I.length===1&&I[0].children&&I[0].children.length>=2&&(T=Math.min(6,I[0].children.length))}const w=Ks(I,T);w.forEach((L,R)=>{const N=`col-${R+1}`;for(const F of L)(!F.slot||F.slot==="default")&&(F.slot=N);y(L)});const C=w.flat();if(I.length===1&&C.length>1){const L=b.blocks.findIndex(R=>R.id===I[0].id);L!==-1&&b.blocks.splice(L,1,...C)}}else if(g==="two-cols"){const x=m.filter(I=>I.slot==="right"),k=m.filter(I=>!I.slot||I.slot==="default");if(x.length===0&&k.length>=2){const[,I]=Ks(k,2);for(const T of I)T.slot="right"}y(m.filter(I=>I.slot!=="right")),y(m.filter(I=>I.slot==="right"))}b.rawMarkdown=b.blocks.filter(x=>x.slot!=="slot-divider-right").map(x=>x.rawMarkdown||x.content||"").filter(Boolean).join(`

`).trim()}return{docId:e,config:n,slides:s}}const ka=`/* SiYuan Note Built-in Font & Background Styles for Slidev */
:root,
html:not(.dark),
[data-theme="light"],
[data-theme-mode="light"] {
  /* 思源基础卡片与主题色 (浅色模式 daylight) */
  --b3-card-error-color: #790600;
  --b3-card-error-background: #f5d1cf;
  --b3-card-warning-color: #8a4f00;
  --b3-card-warning-background: #ffe8c8;
  --b3-card-info-color: #005599;
  --b3-card-info-background: #d6eaf9;
  --b3-card-success-color: #006b04;
  --b3-card-success-background: #d7eed8;

  --b3-theme-primary: #3575f0;
  --b3-theme-secondary: #ff9200;
  --b3-theme-error: #d23f31;
  --b3-theme-background: #ffffff;
  --b3-theme-on-background: #222222;
  --b3-theme-on-surface: #5f6368;
  --b3-theme-surface-lighter: #e0e0e0;

  /* 13 种内置文字颜色 */
  --b3-font-color1: var(--b3-card-error-color);
  --b3-font-color2: var(--b3-card-warning-color);
  --b3-font-color3: var(--b3-card-info-color);
  --b3-font-color4: var(--b3-card-success-color);
  --b3-font-color5: var(--b3-theme-on-surface);
  --b3-font-color6: var(--b3-theme-primary);
  --b3-font-color7: var(--b3-theme-secondary);
  --b3-font-color8: var(--b3-theme-error);
  --b3-font-color9: #a40074;
  --b3-font-color10: #007080;
  --b3-font-color11: #006e2a;
  --b3-font-color12: #6b5a00;
  --b3-font-color13: var(--b3-theme-background);

  /* 13 种内置背景颜色 */
  --b3-font-background1: var(--b3-card-error-background);
  --b3-font-background2: var(--b3-card-warning-background);
  --b3-font-background3: var(--b3-card-info-background);
  --b3-font-background4: var(--b3-card-success-background);
  --b3-font-background5: #e2e3e4;
  --b3-font-background6: #acd0fc;
  --b3-font-background7: #fddaab;
  --b3-font-background8: #ffb0a9;
  --b3-font-background9: #fdbfff;
  --b3-font-background10: #b1ffff;
  --b3-font-background11: #affad1;
  --b3-font-background12: #fff88f;
  --b3-font-background13: var(--b3-theme-on-background);
}

html.dark,
[data-theme="dark"],
[data-theme-mode="dark"],
.theme-dark,
.dark {
  /* 思源基础卡片与主题色 (深色模式 midnight) */
  --b3-card-error-color: rgb(243, 153, 147);
  --b3-card-error-background: #442724;
  --b3-card-warning-color: rgb(255, 213, 153);
  --b3-card-warning-background: #554636;
  --b3-card-info-color: rgb(166, 213, 250);
  --b3-card-info-background: #28405c;
  --b3-card-success-color: rgb(183, 223, 185);
  --b3-card-success-background: #425347;

  --b3-theme-primary: #3575f0;
  --b3-theme-secondary: #ff9200;
  --b3-theme-error: #d23f31;
  --b3-theme-background: #1e1e1e;
  --b3-theme-on-background: #c8ccd6;
  --b3-theme-on-surface: #8b949e;
  --b3-theme-surface-lighter: #282a2e;

  /* 13 种内置文字颜色 */
  --b3-font-color1: var(--b3-card-error-color);
  --b3-font-color2: var(--b3-card-warning-color);
  --b3-font-color3: var(--b3-card-info-color);
  --b3-font-color4: var(--b3-card-success-color);
  --b3-font-color5: var(--b3-theme-on-surface);
  --b3-font-color6: var(--b3-theme-primary);
  --b3-font-color7: var(--b3-theme-secondary);
  --b3-font-color8: var(--b3-theme-error);
  --b3-font-color9: #f47c9c;
  --b3-font-color10: #4dd0e1;
  --b3-font-color11: #10df54;
  --b3-font-color12: #ecd424;
  --b3-font-color13: var(--b3-theme-background);

  /* 13 种内置背景颜色 */
  --b3-font-background1: var(--b3-card-error-background);
  --b3-font-background2: var(--b3-card-warning-background);
  --b3-font-background3: var(--b3-card-info-background);
  --b3-font-background4: var(--b3-card-success-background);
  --b3-font-background5: #3a3f42;
  --b3-font-background6: #031840;
  --b3-font-background7: #593905;
  --b3-font-background8: #3a0c09;
  --b3-font-background9: #4d1b40;
  --b3-font-background10: #1a5459;
  --b3-font-background11: #305415;
  --b3-font-background12: #4a4712;
  --b3-font-background13: var(--b3-theme-on-background);
}

@media (prefers-color-scheme: dark) {
  :root:not([data-theme="light"]):not([data-theme-mode="light"]):not(.light) {
    --b3-card-error-color: rgb(243, 153, 147);
    --b3-card-error-background: #442724;
    --b3-card-warning-color: rgb(255, 213, 153);
    --b3-card-warning-background: #554636;
    --b3-card-info-color: rgb(166, 213, 250);
    --b3-card-info-background: #28405c;
    --b3-card-success-color: rgb(183, 223, 185);
    --b3-card-success-background: #425347;

    --b3-theme-primary: #3575f0;
    --b3-theme-secondary: #ff9200;
    --b3-theme-error: #d23f31;
    --b3-theme-background: #1e1e1e;
    --b3-theme-on-background: #c8ccd6;
    --b3-theme-on-surface: #8b949e;
    --b3-theme-surface-lighter: #282a2e;

    --b3-font-color1: var(--b3-card-error-color);
    --b3-font-color2: var(--b3-card-warning-color);
    --b3-font-color3: var(--b3-card-info-color);
    --b3-font-color4: var(--b3-card-success-color);
    --b3-font-color5: var(--b3-theme-on-surface);
    --b3-font-color6: var(--b3-theme-primary);
    --b3-font-color7: var(--b3-theme-secondary);
    --b3-font-color8: var(--b3-theme-error);
    --b3-font-color9: #f47c9c;
    --b3-font-color10: #4dd0e1;
    --b3-font-color11: #10df54;
    --b3-font-color12: #ecd424;
    --b3-font-color13: var(--b3-theme-background);

    --b3-font-background1: var(--b3-card-error-background);
    --b3-font-background2: var(--b3-card-warning-background);
    --b3-font-background3: var(--b3-card-info-background);
    --b3-font-background4: var(--b3-card-success-background);
    --b3-font-background5: #3a3f42;
    --b3-font-background6: #031840;
    --b3-font-background7: #593905;
    --b3-font-background8: #3a0c09;
    --b3-font-background9: #4d1b40;
    --b3-font-background10: #1a5459;
    --b3-font-background11: #305415;
    --b3-font-background12: #4a4712;
    --b3-font-background13: var(--b3-theme-on-background);
  }
}

/* 演示块级样式排版增强 (带背景色时赋予呼吸内边距与舒适圆角) */
.slide-styled-block {
  border-radius: 6px;
  padding: 8px 14px;
  box-sizing: border-box;
  margin: 6px 0;
  transition: background-color 0.2s ease, color 0.2s ease;
}

/* 行内带背景色文本的精美圆角与微边距 */
span[style*="background-color"],
span[style*="background:"] {
  border-radius: 3px;
  padding: 1px 5px;
  box-decoration-break: clone;
  -webkit-box-decoration-break: clone;
}
`;function _p(e){var n,s,l,r,a,c,u,f,h,d,b,m;if(!e||typeof e!="object")return"";const t=[],o=[];if(Array.isArray(e.styles))for(const y of e.styles){if(!y||!y.id)continue;const g=`--b3-inline-style-${y.id}`;(n=y.light)!=null&&n.color&&t.push(`  ${g}-color: ${y.light.color};`),(s=y.light)!=null&&s.backgroundColor&&t.push(`  ${g}-background-color: ${y.light.backgroundColor};`),(l=y.dark)!=null&&l.color&&o.push(`  ${g}-color: ${y.dark.color};`),(r=y.dark)!=null&&r.backgroundColor&&o.push(`  ${g}-background-color: ${y.dark.backgroundColor};`)}if(e.builtin&&Array.isArray(e.builtin.colors))for(const y of e.builtin.colors){if(!y||typeof y.index!="number")continue;const g=y.index;(a=y.light)!=null&&a.color&&t.push(`  --b3-font-color${g}: ${y.light.color};`),(c=y.light)!=null&&c.backgroundColor&&t.push(`  --b3-font-background${g}: ${y.light.backgroundColor};`),(u=y.dark)!=null&&u.color&&o.push(`  --b3-font-color${g}: ${y.dark.color};`),(f=y.dark)!=null&&f.backgroundColor&&o.push(`  --b3-font-background${g}: ${y.dark.backgroundColor};`)}if(e.builtin&&Array.isArray(e.builtin.styles))for(const y of e.builtin.styles){if(!y||!y.id)continue;const g=y.id;(h=y.light)!=null&&h.color&&t.push(`  --b3-card-${g}-color: ${y.light.color};`),(d=y.light)!=null&&d.backgroundColor&&t.push(`  --b3-card-${g}-background: ${y.light.backgroundColor};`),(b=y.dark)!=null&&b.color&&o.push(`  --b3-card-${g}-color: ${y.dark.color};`),(m=y.dark)!=null&&m.backgroundColor&&o.push(`  --b3-card-${g}-background: ${y.dark.backgroundColor};`)}if(t.length===0&&o.length===0)return"";const i=[];return t.length>0&&i.push(`:root, html:not(.dark), [data-theme="light"] {
${t.join(`
`)}
}`),o.length>0&&i.push(`html.dark, [data-theme="dark"], .dark {
${o.join(`
`)}
}`),i.join(`

`)}function Wi(e){const t=_p(e);return t?`${ka}

/* Custom Workspace Inline Styles */
${t}`:ka}const ws=Ua;function Ip(e){const t=String((e==null?void 0:e.type)||"").toLowerCase();return t==="s"||t==="sb"||t==="nodesuperblock"||t==="l"||t==="nodelist"||t==="i"||t==="nodelistitem"||t==="b"||t==="nodeblockquote"}function $p(e,t){const o=new Map,i=[];if(!Array.isArray(t)||t.length===0)return{usable:!1,reason:"索引无行",leafPatch:o,rebuildRoots:i};const n=new Map;for(const s of t)s!=null&&s.id&&n.set(s.id,s);for(const s of e||[]){if(!(s!=null&&s.id))continue;const l=n.get(s.id);if(!l)continue;const r=s.content??"",a=s.markdown??"";(l.content??"")===r&&(l.markdown??"")===a||(Ip(l)?i.push(s.id):o.set(s.id,{content:r,markdown:a}))}return{usable:!0,reason:"",leafPatch:o,rebuildRoots:i}}function Tp(e){const t=String((e==null?void 0:e.type)||"").toLowerCase();return t==="h"||t==="nodeheading"}function Gs(e){return ft(e)||e.type==="l"||e.type==="NodeList"||e.type==="i"||e.type==="NodeListItem"||e.type==="b"||e.type==="NodeBlockquote"}function Ap(e,t,o,i=8,n){const s=new Map;for(const h of t)h!=null&&h.id&&s.set(h.id,h);const l=h=>({id:h.id,parent_id:h.parent_id,root_id:h.root_id||e,type:h.type,subType:h.subtype??h.subType??"",content:h.content||"",markdown:h.markdown||"",ial:o(h.id,h.ial),children:[]}),r=h=>{let d=h.parent_id,b=0;for(;d&&d!==e&&b++<16;){const m=s.get(d);if(!m||!Tp(m))return d;d=m.parent_id}return d||e},a=new Map;for(const h of t){if(!(h!=null&&h.id)||h.id===e||n&&n.size>0&&!n.has(h.id))continue;const d=r(h),b=a.get(d);b?b.push(h):a.set(d,[h])}if(n&&n.size>0)for(const h of a.values())h.sort((d,b)=>(n.get(d.id)??Number.MAX_SAFE_INTEGER)-(n.get(b.id)??Number.MAX_SAFE_INTEGER));const c=new Map,u=(h,d)=>{const b=l(h);if(c.set(b.id,b),d>=i||!Gs(b))return b;const m=a.get(b.id);return m&&m.length>0&&(b.children=m.map(y=>u(y,d+1))),b};return{topLevel:(a.get(e)||[]).map(h=>u(h,0)),byId:c}}const Mp={getBlockAttrs:er,getChildBlocks:Ci,getDocBlocksOrders:Ld,setBlockAttrs:ze,sql:ki,getBaseUrl:()=>typeof location<"u"?location.origin:"",getInlineStyles:Dd};class Ep{constructor(t){Ie(this,"deps");Ie(this,"attrOverrides",new Map);Ie(this,"trackedListSuperBlocks",new Map);Ie(this,"fallbackWarnedDocId","");this.deps={...Mp,...t||{}}}setBlockAttrOverride(t,o){if(!t||!o)return;const n={...this.attrOverrides.get(t)||{}};for(const[s,l]of Object.entries(o))l===""||l===null||l===void 0?delete n[s]:n[s]=String(l);Object.keys(n).length===0?this.attrOverrides.delete(t):this.attrOverrides.set(t,n)}getBlockAttrOverride(t){return this.attrOverrides.get(t)}getAllAttrOverrides(){return new Map(this.attrOverrides)}getTrackedListSuperBlocks(t){return this.trackedListSuperBlocks.get(t)||[]}clearBlockAttrOverride(t,o){if(!t)return;if(!o){this.attrOverrides.delete(t);return}const i=this.attrOverrides.get(t);i&&(delete i[o],Object.keys(i).length===0&&this.attrOverrides.delete(t))}clearAllOverrides(){this.attrOverrides.clear(),this.trackedListSuperBlocks.clear()}async compile(t){try{const o=await this.deps.getBlockAttrs(t).catch(()=>({}))||{},i=this.attrOverrides.get(t);i&&Object.assign(o,i);const n=await this.deps.getChildBlocks(t).catch(()=>[])||[],s=this.deps.getDocBlocksOrders?await this.deps.getDocBlocksOrders(t).catch(()=>[])||[]:[],l=new Map;for(let j=0;j<s.length;j++)s[j]&&l.set(s[j],j);const r=l.size>0,a=`SELECT id, parent_id, root_id, type, subtype, content, markdown, ial, sort, created FROM blocks WHERE root_id = '${t}' AND id != '${t}' ORDER BY sort ASC, created ASC LIMIT 99999`,c=await this.deps.sql(a).catch(()=>[])||[],u=$p(n,c),f=new Map;if(Array.isArray(c))for(const j of c)j.id&&j.ial&&f.set(j.id,ws(j.ial));const h=`SELECT block_id, name, value FROM attributes WHERE root_id = '${t}' AND type = 'b' LIMIT 99999`,d=await this.deps.sql(h).catch(()=>[])||[];if(Array.isArray(d)){for(const j of d)if(j.block_id&&j.name){let _=f.get(j.block_id);_||(_={},f.set(j.block_id,_)),_[j.name]=j.value||""}}const b=(j,_)=>{const M={...f.get(j)||(_?ws(_):{})},B=this.attrOverrides.get(j);return B&&Object.assign(M,B),M},m=Array.isArray(c)&&c.length>0?Ap(t,c,b,8,l):null,y=n.map(j=>j.id).filter(Boolean),g=j=>({id:j.id,parent_id:j.parent_id,root_id:j.root_id||t,type:j.type,subType:j.subType,content:j.content||"",markdown:j.markdown||"",ial:b(j.id,j.ial),children:j.children}),x=async(j,_=0)=>{if(!j||_>8||!Gs(j))return;const M=await this.deps.getChildBlocks(j.id).catch(()=>[])||[];if(!(!Array.isArray(M)||M.length===0)){j.children=M.filter(B=>B==null?void 0:B.id).map(B=>({id:B.id,parent_id:j.id,root_id:t,type:B.type,subType:B.subType,content:B.content||"",markdown:B.markdown||"",ial:b(B.id,B.ial),children:[]}));for(const B of j.children)await x(B,_+1)}},k=new Map;for(const j of c)j!=null&&j.id&&k.set(j.id,j);const I=y.every(j=>{const _=k.get(j);return!_||!!_.type});let T=[],w=!1;if(m&&u.usable&&r&&I){this.fallbackWarnedDocId="";for(const[_,M]of u.leafPatch){const B=m.byId.get(_);B&&(B.content=M.content,B.markdown=M.markdown)}const j=new Map;for(const _ of n)_!=null&&_.id&&j.set(_.id,_);for(const _ of u.rebuildRoots){const M=m.byId.get(_),B=j.get(_);M&&B&&(M.content=B.content||"",M.markdown=B.markdown||""),await x(M)}for(const _ of n){if(!(_!=null&&_.id)||m.byId.has(_.id))continue;const M=g(_);await x(M),m.byId.set(M.id,M),m.topLevel.push(M)}T=m.topLevel.filter(_=>l.has(_.id)).sort((_,M)=>(l.get(_.id)??0)-(l.get(M.id)??0))}else y.length>0?(w=!0,this.fallbackWarnedDocId!==t&&(this.fallbackWarnedDocId=t,console.warn(`[DocumentCompiler] 索引结构不可用，回退逐容器查询（较慢）doc=${t} 实时顶层=${y.length} 索引行=${c.length} 文档序=${s.length} 原因=${u.reason||"缺少实时文档序"}`)),T=n.map(j=>g(j))):m&&(T=m.topLevel);const C=async(j,_=0)=>{if(!(!j||j.length===0||_>8))for(const M of j){if(Gs(M)&&(!M.children||M.children.length===0)){let Q=await this.deps.getChildBlocks(M.id).catch(()=>[]);if(!Q||Q.length===0){const q=`SELECT id, parent_id, root_id, type, subtype as subType, content, markdown, ial FROM blocks WHERE parent_id = '${M.id}' ORDER BY sort ASC, created ASC`;Q=await this.deps.sql(q).catch(()=>[])||[]}if(Array.isArray(Q)&&Q.length>0){const q=new Set(T.map(ne=>ne.id)),U=Q.filter(ne=>ne.id!==M.id&&!q.has(ne.id));U.length>0&&(M.children=U.map(ne=>{const oe=f.get(ne.id)||(ne.ial?ws(ne.ial):{}),ae=this.attrOverrides.get(ne.id);return ae&&Object.assign(oe,ae),{id:ne.id,parent_id:ne.parent_id||M.id,root_id:ne.root_id||t,type:ne.type,subType:ne.subType,content:ne.content||"",markdown:ne.markdown||"",ial:oe}}))}}M.children&&M.children.length>0&&await C(M.children,_+1)}};w&&await C(T);const L=j=>{var _,M;for(const B of j)if(B.children&&B.children.length>0){L(B.children);for(const Q of B.children)if(Q.ial)for(const[q,U]of Object.entries(Q.ial))q.startsWith("custom-slides-")&&!((_=B.ial)!=null&&_[q])&&(B.ial||(B.ial={}),B.ial[q]=U);if(B.ial){for(const[Q,q]of Object.entries(B.ial))if(Q.startsWith("custom-slides-"))for(const U of B.children)(U.type==="video"||U.type==="NodeVideo"||/<video\b/i.test(U.markdown||U.content||""))&&!((M=U.ial)!=null&&M[Q])&&(U.ial||(U.ial={}),U.ial[Q]=q)}}};L(T),wp(T,j=>{const _={[be]:j.layout};this.setBlockAttrOverride(j.blockId,_),(this.deps.setBlockAttrs||ze)(j.blockId,_).catch(B=>{console.warn("[DocumentCompiler] Failed to auto-tag superblock image layout:",B)})});const R=this.trackedListSuperBlocks.get(t)||[],N=kp(t,T,{tracked:R,onTagChange:j=>{this.setBlockAttrOverride(j.blockId,j.attrs),j.blockId===t&&Object.assign(o,j.attrs);const _=B=>{for(const Q of B)Q.id===j.blockId&&(Q.ial||(Q.ial={}),Object.assign(Q.ial,j.attrs)),Q.children&&Q.children.length>0&&_(Q.children)};_(T),(this.deps.setBlockAttrs||ze)(j.blockId,j.attrs).catch(B=>{console.warn("[DocumentCompiler] Failed to auto-tag list superblock attrs:",B)})}});this.trackedListSuperBlocks.set(t,N.newTracked);const F=new Set,E=j=>{for(const _ of j){const M=_.markdown||_.content||"";if(M.includes("((")){const B=Nd(M);for(const Q of B)F.add(Q.blockId)}_.children&&_.children.length>0&&E(_.children)}};E(T);const O={};if(F.size>0){const j=Array.from(F).map(M=>`'${M}'`).join(","),_=await this.deps.sql(`SELECT id, content, markdown FROM blocks WHERE id IN (${j})`).catch(()=>[])||[];if(Array.isArray(_))for(const M of _)M.id&&(O[M.id]=M.markdown||M.content||"")}const S=this.deps.getBaseUrl?this.deps.getBaseUrl():"",W=va(t,o,T,{baseUrl:S,refContentMap:O});try{const j=this.deps.getInlineStyles?await this.deps.getInlineStyles().catch(()=>null):null;W.customThemeCss=Wi(j)}catch{W.customThemeCss=Wi(null)}return W}catch(o){console.error("[DocumentCompilerService] Failed to compile document:",o);const i=va(t,{},[],{});return i.customThemeCss=Wi(null),i}}}const Ee=new Ep,nc={presenterMode:!0,exportHtml:!1,exportPdf:!1,exportImage:!1,import:!1,aiScript:!0,smartSplit:!0,smartAnimation:!0,speakerNotesBlocks:!0,layouts:{"two-cols":!0,"cols-header":!0,clover:!1,timeline:!1,"image-right":!0,"image-left":!0,cover:!0,fact:!1,quote:!0,intro:!1,center:!0}};function qt(e){return nc[e]===!1}function ct(e){return!qt(e)}function Bp(e){var o;return e==="default"?!0:((o=nc.layouts)==null?void 0:o[e])!==!1}const wa=["white","snow","ivory","ghostwhite","floralwhite","aliceblue","whitesmoke","seashell","beige","oldlace","linen","antiquewhite","lightyellow","lightcyan","papayawhip","blanchedalmond","cornsilk","lavender","lavenderblush","lemonchiffon","honeydew","mintcream","azure","mistyrose","wheat","lightgoldenrodyellow","palegoldenrod","gainsboro","lightgrey","lightgray","silver","pink","lightpink","peachpuff","navajowhite","moccasin","bisque","khaki","palegreen","lightgreen","lightblue","powderblue","paleturquoise","lightsteelblue","thistle","yellow","cyan","aqua"],xa=["black","transparent","navy","darkblue","midnightblue","darkslategray","darkslategrey","maroon","darkred","darkgreen","indigo","darkslateblue","dimgray","dimgrey","purple","brown","olive","teal","blue","darkviolet","darkmagenta","darkcyan","darkolivegreen","saddlebrown","sienna","firebrick","crimson","mediumblue","rebeccapurple"];function Cr(e,t,o){return .299*e+.587*t+.114*o}function Sa(e){let t=e.startsWith("#")?e.slice(1):e;if((t.length===3||t.length===4)&&(t=t.slice(0,3).split("").map(o=>o+o).join("")),t.length>=6){const o=parseInt(t.substring(0,2),16),i=parseInt(t.substring(2,4),16),n=parseInt(t.substring(4,6),16);if(!isNaN(o)&&!isNaN(i)&&!isNaN(n))return Cr(o,i,n)}return null}function Ca(e){const t=e.match(/rgba?\s*\(\s*(\d+(?:\.\d+)?)\s*[,\s]\s*(\d+(?:\.\d+)?)\s*[,\s]\s*(\d+(?:\.\d+)?)(?:\s*[,/]\s*([0-9.]+%?))?/i);if(!t)return null;const o=Number(t[1]),i=Number(t[2]),n=Number(t[3]);if(isNaN(o)||isNaN(i)||isNaN(n))return null;if(t[4]!==void 0){const s=t[4].endsWith("%")?parseFloat(t[4])/100:parseFloat(t[4]);if(!isNaN(s)&&s<=.05)return null}return Cr(o,i,n)}function _a(e){const t=e.match(/hsla?\s*\(\s*([0-9.]+)(?:deg)?\s*[,\s]\s*([0-9.]+)%\s*[,\s]\s*([0-9.]+)%(?:\s*[,/]\s*([0-9.]+%?))?/i);if(!t)return null;if(t[4]!==void 0){const a=t[4].endsWith("%")?parseFloat(t[4])/100:parseFloat(t[4]);if(!isNaN(a)&&a<=.05)return null}const o=(Number(t[1])%360+360)%360/360,i=Math.max(0,Math.min(1,Number(t[2])/100)),n=Math.max(0,Math.min(1,Number(t[3])/100));let s,l,r;if(i===0)s=l=r=n*255;else{const a=n<.5?n*(1+i):n+i-n*i,c=2*n-a,u=f=>{let h=f;return h<0&&(h+=1),h>1&&(h-=1),h<1/6?c+(a-c)*6*h:h<1/2?a:h<2/3?c+(a-c)*(2/3-h)*6:c};s=u(o+1/3)*255,l=u(o)*255,r=u(o-1/3)*255}return Cr(s,l,r)}function sc(e){if(!e||typeof e!="string")return null;const t=e.trim().toLowerCase();if(!t||/^(?:https?:\/\/|\/|data:|assets\/|\.\/assets\/|url\s*\()/i.test(t))return null;if(wa.includes(t))return!0;if(xa.includes(t))return!1;if(t.startsWith("#")){const o=Sa(t);return o===null?null:o>140}if(/^rgba?\s*\(/i.test(t)){const o=Ca(t);return o===null?null:o>140}if(/^hsla?\s*\(/i.test(t)){const o=_a(t);return o===null?null:o>140}if(/(?:linear|radial|conic)-gradient\s*\(/i.test(t)){const o=[],i=t.match(/#(?:[0-9a-f]{8}|[0-9a-f]{6}|[0-9a-f]{4}|[0-9a-f]{3})\b/gi);if(i)for(const a of i){const c=Sa(a);c!==null&&o.push(c)}const n=t.match(/rgba?\s*\([^)]+\)/gi);if(n)for(const a of n){const c=Ca(a);c!==null&&o.push(c)}const s=t.match(/hsla?\s*\([^)]+\)/gi);if(s)for(const a of s){const c=_a(a);c!==null&&o.push(c)}const r=t.replace(/#[0-9a-f]+|rgba?\([^)]+\)|hsla?\([^)]+\)/gi," ").match(/\b[a-z]+\b/gi);if(r)for(const a of r)a!=="transparent"&&(wa.includes(a)?o.push(240):xa.includes(a)&&o.push(20));if(o.length>0)return o.reduce((c,u)=>c+u,0)/o.length>140;if(/\btransparent\b/.test(t))return!1}return null}function Wo(){var e,t,o,i,n,s,l,r,a,c,u,f,h;if(typeof window<"u"){const d=(o=(t=(e=window.siyuan)==null?void 0:e.config)==null?void 0:t.appearance)==null?void 0:o.mode;if(d===0)return"light";if(d===1)return"dark"}if(typeof document<"u"){const d=(i=document.documentElement)==null?void 0:i.getAttribute("data-theme-mode");if(d==="light"||d==="dark")return d;const b=(n=document.body)==null?void 0:n.getAttribute("data-theme-mode");if(b==="light"||b==="dark")return b;if((l=(s=document.documentElement)==null?void 0:s.classList)!=null&&l.contains("theme--dark")||(a=(r=document.body)==null?void 0:r.classList)!=null&&a.contains("theme--dark"))return"dark";if((u=(c=document.documentElement)==null?void 0:c.classList)!=null&&u.contains("theme--light")||(h=(f=document.body)==null?void 0:f.classList)!=null&&h.contains("theme--light"))return"light"}if(typeof window<"u"&&typeof window.matchMedia=="function"){if(window.matchMedia("(prefers-color-scheme: light)").matches)return"light";if(window.matchMedia("(prefers-color-scheme: dark)").matches)return"dark"}return"light"}function _r(e,t){return e==="light"?"light":e==="dark"?"dark":t==="light"||t==="dark"?t:Wo()}function rc(e){if(typeof MutationObserver>"u"||typeof document>"u")return()=>{};let t=Wo();const o=()=>{const n=Wo();n!==t&&(t=n,e(n))},i=new MutationObserver(o);return document.documentElement&&i.observe(document.documentElement,{attributes:!0,attributeFilter:["data-theme-mode","class"]}),document.body&&i.observe(document.body,{attributes:!0,attributeFilter:["data-theme-mode","class"]}),()=>i.disconnect()}class ss{constructor(){Ie(this,"iframe",null);Ie(this,"isReady",!1);Ie(this,"pendingMessages",[]);Ie(this,"slideChangedHandlers",[]);Ie(this,"blockClickedHandlers",[]);Ie(this,"openInEditorHandlers",[]);Ie(this,"clientReadyHandlers",[]);Ie(this,"openPeekDrawerHandlers",[]);Ie(this,"toggleFullscreenHandlers",[]);Ie(this,"openPresenterHandlers",[]);Ie(this,"captureProgressHandlers",[]);Ie(this,"capturePageDoneHandlers",[]);Ie(this,"captureCompleteHandlers",[]);Ie(this,"captureErrorHandlers",[]);this.handleWindowMessage=this.handleWindowMessage.bind(this)}attach(t){this.detach(),this.iframe=t,this.isReady=!1,typeof window<"u"&&window.addEventListener("message",this.handleWindowMessage)}detach(){typeof window<"u"&&window.removeEventListener("message",this.handleWindowMessage),this.iframe=null,this.isReady=!1,this.pendingMessages=[]}resetReady(){this.isReady=!1}postMessage(t,o){var n;const i={source:"siyuan-slides-host",action:t,payload:o};if(!((n=this.iframe)!=null&&n.contentWindow)||!this.isReady){if(t==="UPDATE_SLIDES"||t==="NAVIGATE_PAGE"){const s=this.pendingMessages.findIndex(l=>l.action===t);s!==-1?this.pendingMessages[s]=i:this.pendingMessages.push(i)}else this.pendingMessages.length>=50&&this.pendingMessages.shift(),this.pendingMessages.push(i);return}try{this.iframe.contentWindow.postMessage(i,"*")}catch(s){console.warn("[WebSandboxBridge] postMessage error:",s)}}updateSlides(t,o,i){const n=o?{...o,hostThemeMode:o.hostThemeMode||Wo()}:void 0;this.postMessage("UPDATE_SLIDES",{slides:t,config:n,customThemeCss:i})}navigatePage(t,o){const i={pageIndex:t};typeof o=="number"&&(i.step=o),this.postMessage("NAVIGATE_PAGE",i)}highlightElement(t){this.postMessage("HIGHLIGHT_ELEMENT",{targetBlockId:t})}nextStep(){this.postMessage("NEXT_STEP",{})}prevStep(){this.postMessage("PREV_STEP",{})}freezeKeyboardNav(t){this.postMessage("FREEZE_KEYBOARD_NAV",{frozen:t})}toggleOverview(){this.postMessage("TOGGLE_OVERVIEW",{})}startImageExport(t){this.postMessage("START_IMAGE_EXPORT",{captureOptions:t})}cancelImageExport(){this.postMessage("CANCEL_IMAGE_EXPORT",{})}onCaptureProgress(t){return this.captureProgressHandlers.push(t),()=>{this.captureProgressHandlers=this.captureProgressHandlers.filter(o=>o!==t)}}onCapturePageDone(t){return this.capturePageDoneHandlers.push(t),()=>{this.capturePageDoneHandlers=this.capturePageDoneHandlers.filter(o=>o!==t)}}onCaptureComplete(t){return this.captureCompleteHandlers.push(t),()=>{this.captureCompleteHandlers=this.captureCompleteHandlers.filter(o=>o!==t)}}onCaptureError(t){return this.captureErrorHandlers.push(t),()=>{this.captureErrorHandlers=this.captureErrorHandlers.filter(o=>o!==t)}}onSlideChanged(t){return this.slideChangedHandlers.push(t),()=>{this.slideChangedHandlers=this.slideChangedHandlers.filter(o=>o!==t)}}onBlockClicked(t){return this.blockClickedHandlers.push(t),()=>{this.blockClickedHandlers=this.blockClickedHandlers.filter(o=>o!==t)}}onOpenInEditor(t){return this.openInEditorHandlers.push(t),()=>{this.openInEditorHandlers=this.openInEditorHandlers.filter(o=>o!==t)}}onOpenPeekDrawer(t){return this.openPeekDrawerHandlers.push(t),()=>{this.openPeekDrawerHandlers=this.openPeekDrawerHandlers.filter(o=>o!==t)}}onRequestToggleFullscreen(t){return this.toggleFullscreenHandlers.push(t),()=>{this.toggleFullscreenHandlers=this.toggleFullscreenHandlers.filter(o=>o!==t)}}onOpenPresenter(t){return this.openPresenterHandlers.push(t),()=>{this.openPresenterHandlers=this.openPresenterHandlers.filter(o=>o!==t)}}onClientReady(t){return this.clientReadyHandlers.push(t),()=>{this.clientReadyHandlers=this.clientReadyHandlers.filter(o=>o!==t)}}handleWindowMessage(t){var i,n;const o=t.data;if(!(!o||o.source!=="siyuan-slides-client")&&!((i=this.iframe)!=null&&i.contentWindow&&t.source&&t.source!==this.iframe.contentWindow))switch(o.action){case"CLIENT_READY":for(this.isReady=!0;this.pendingMessages.length>0;){const s=this.pendingMessages.shift();s&&((n=this.iframe)!=null&&n.contentWindow)&&this.iframe.contentWindow.postMessage(s,"*")}for(const s of this.clientReadyHandlers)s();break;case"SLIDE_CHANGED":if(o.payload.currentPage!==void 0)for(const s of this.slideChangedHandlers)o.payload.currentStep!==void 0||o.payload.maxStep!==void 0?s(o.payload.currentPage,o.payload.totalPages||1,o.payload.currentBlockId||"",o.payload.currentStep,o.payload.maxStep):s(o.payload.currentPage,o.payload.totalPages||1,o.payload.currentBlockId||"");break;case"BLOCK_CLICKED":if(o.payload.clickedBlockId)for(const s of this.blockClickedHandlers)s(o.payload.clickedBlockId,o.payload.currentPage||1);break;case"OPEN_IN_EDITOR":if(o.payload.blockId||o.payload.clickedBlockId){const s=o.payload.blockId||o.payload.clickedBlockId||"";for(const l of this.openInEditorHandlers)l(s,o.payload.currentPage||1)}break;case"OPEN_PEEK_DRAWER":if(o.payload.peekType){const s=o.payload.blockId||o.payload.url||"",l={peekType:o.payload.peekType,target:s,title:o.payload.title};for(const r of this.openPeekDrawerHandlers)r(l)}break;case"REQUEST_TOGGLE_FULLSCREEN":for(const s of this.toggleFullscreenHandlers)s();break;case"OPEN_PRESENTER":for(const s of this.openPresenterHandlers)s();break;case"CAPTURE_PROGRESS":if(o.payload.captureProgress)for(const s of this.captureProgressHandlers)s(o.payload.captureProgress);break;case"CAPTURE_PAGE_DONE":if(o.payload.captureResult)for(const s of this.capturePageDoneHandlers)s(o.payload.captureResult);break;case"CAPTURE_COMPLETE":for(const s of this.captureCompleteHandlers)s({total:o.payload.totalPages||0});break;case"CAPTURE_ERROR":for(const s of this.captureErrorHandlers)s(o.payload.captureError||"未知沙箱截图异常");break}}}const Lp={class:"slides-icon",style:{fill:"none !important"},viewBox:"0 0 24 24",stroke:"currentColor","stroke-width":"1.75","stroke-linecap":"round","stroke-linejoin":"round","aria-hidden":"true"},Dp={key:0},Np={key:1},Op={key:2},Pp={key:3},Rp={key:4},zp={key:5},Hp={key:6},Fp={key:7},jp={key:8},Up={key:9},Wp={key:10},qp={key:11},Vp={key:12},Kp={key:13},Gp={key:14},Yp={key:15},Zp={key:16},Jp={key:17},Xp={key:18},Qp={key:19},eh={key:20},th={key:21},oh={key:22},ih={key:23},nh={key:24},sh={key:25},rh={key:26},ah={key:27},lh={key:28},ch={key:29},dh={key:30},uh={key:31},fh={key:32},ph={key:33},hh={key:34},mh={key:35},gh={key:36},yh={key:37},bh={key:38},vh={key:39},kh={key:40},wh={key:41},xh={key:42},Sh={key:43},Ch={key:44},_h={key:45},Ih={key:46},$h={key:47},Th={key:48},Ah={key:49},Mh={key:50},Eh={key:51},Bh={key:52},Lh={key:53},Dh={key:54},Nh={key:55},Oh={key:56},Ph={key:57},Rh={key:58},zh={key:59},Hh={key:60},Fh={key:61},jh={key:62},Uh={key:63},Wh={key:64},qh={key:65},Vh={key:66},Kh={key:67},Gh={key:68},Yh={key:69},Zh={key:70},Jh={key:71},Xh={key:72},Qh={key:73},em={key:74},tm=Ht({__name:"SlidesIcon",props:{name:{}},setup(e){return(t,o)=>(J(),X("svg",Lp,[e.name==="fullscreen"||e.name==="maximize"?(J(),X("g",Dp,[...o[0]||(o[0]=[p("polyline",{points:"15 3 21 3 21 9"},null,-1),p("polyline",{points:"9 21 3 21 3 15"},null,-1),p("polyline",{points:"21 15 21 21 15 21"},null,-1),p("polyline",{points:"3 9 3 3 9 3"},null,-1)])])):e.name==="minimize"?(J(),X("g",Np,[...o[1]||(o[1]=[p("polyline",{points:"4 14 10 14 10 20"},null,-1),p("polyline",{points:"20 10 14 10 14 4"},null,-1),p("line",{x1:"14",y1:"10",x2:"21",y2:"3"},null,-1),p("line",{x1:"3",y1:"21",x2:"10",y2:"14"},null,-1)])])):e.name==="close"||e.name==="x"?(J(),X("g",Op,[...o[2]||(o[2]=[p("line",{x1:"18",y1:"6",x2:"6",y2:"18"},null,-1),p("line",{x1:"6",y1:"6",x2:"18",y2:"18"},null,-1)])])):e.name==="edit"?(J(),X("g",Pp,[...o[3]||(o[3]=[p("path",{d:"M12 20h9"},null,-1),p("path",{d:"M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z"},null,-1)])])):e.name==="eye"?(J(),X("g",Rp,[...o[4]||(o[4]=[p("path",{d:"M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"},null,-1),p("circle",{cx:"12",cy:"12",r:"3"},null,-1)])])):e.name==="external-link"||e.name==="window"?(J(),X("g",zp,[...o[5]||(o[5]=[p("path",{d:"M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"},null,-1),p("polyline",{points:"15 3 21 3 21 9"},null,-1),p("line",{x1:"10",y1:"14",x2:"21",y2:"3"},null,-1)])])):e.name==="arrow-left"?(J(),X("g",Hp,[...o[6]||(o[6]=[p("line",{x1:"19",y1:"12",x2:"5",y2:"12"},null,-1),p("polyline",{points:"12 19 5 12 12 5"},null,-1)])])):e.name==="arrow-right"?(J(),X("g",Fp,[...o[7]||(o[7]=[p("line",{x1:"5",y1:"12",x2:"19",y2:"12"},null,-1),p("polyline",{points:"12 5 19 12 12 19"},null,-1)])])):e.name==="plus"?(J(),X("g",jp,[...o[8]||(o[8]=[p("line",{x1:"12",y1:"5",x2:"12",y2:"19"},null,-1),p("line",{x1:"5",y1:"12",x2:"19",y2:"12"},null,-1)])])):e.name==="minus"?(J(),X("g",Up,[...o[9]||(o[9]=[p("line",{x1:"5",y1:"12",x2:"19",y2:"12"},null,-1)])])):e.name==="split-preview"?(J(),X("g",Wp,[...o[10]||(o[10]=[p("rect",{x:"3",y:"3",width:"18",height:"18",rx:"2"},null,-1),p("path",{d:"M12 3v18"},null,-1)])])):e.name==="import"?(J(),X("g",qp,[...o[11]||(o[11]=[p("path",{d:"M4 17v2a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-2"},null,-1),p("polyline",{points:"7 9 12 14 17 9"},null,-1),p("line",{x1:"12",y1:"14",x2:"12",y2:"3"},null,-1)])])):e.name==="presenter"?(J(),X("g",Vp,[...o[12]||(o[12]=[p("path",{d:"M2 3h20"},null,-1),p("path",{d:"M21 3v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V3"},null,-1),p("path",{d:"m7 21 5-5 5 5"},null,-1)])])):e.name==="video"?(J(),X("g",Kp,[...o[13]||(o[13]=[p("polygon",{points:"23 7 16 12 23 17 23 7"},null,-1),p("rect",{x:"1",y:"5",width:"15",height:"14",rx:"2",ry:"2"},null,-1)])])):e.name==="step"?(J(),X("g",Gp,[...o[14]||(o[14]=[p("polygon",{points:"13 2 3 14 12 14 11 22 21 10 12 10 13 2"},null,-1)])])):e.name==="motion"?(J(),X("g",Yp,[...o[15]||(o[15]=[p("path",{d:"M5 12h14"},null,-1),p("path",{d:"m12 5 7 7-7 7"},null,-1),p("path",{d:"M5 6h4"},null,-1),p("path",{d:"M5 18h4"},null,-1)])])):e.name==="columns"?(J(),X("g",Zp,[...o[16]||(o[16]=[p("rect",{x:"3",y:"3",width:"7",height:"18",rx:"1"},null,-1),p("rect",{x:"14",y:"3",width:"7",height:"18",rx:"1"},null,-1)])])):e.name==="layout-grid"||e.name==="grid-2x2"||e.name==="grid"||e.name==="overview"?(J(),X("g",Jp,[...o[17]||(o[17]=[p("rect",{x:"3",y:"3",width:"7",height:"7",rx:"1"},null,-1),p("rect",{x:"14",y:"3",width:"7",height:"7",rx:"1"},null,-1),p("rect",{x:"14",y:"14",width:"7",height:"7",rx:"1"},null,-1),p("rect",{x:"3",y:"14",width:"7",height:"7",rx:"1"},null,-1)])])):e.name==="code"?(J(),X("g",Xp,[...o[18]||(o[18]=[p("polyline",{points:"16 18 22 12 16 6"},null,-1),p("polyline",{points:"8 6 2 12 8 18"},null,-1)])])):e.name==="list"?(J(),X("g",Qp,[...o[19]||(o[19]=[ht('<line x1="8" y1="6" x2="21" y2="6" data-v-730eaece></line><line x1="8" y1="12" x2="21" y2="12" data-v-730eaece></line><line x1="8" y1="18" x2="21" y2="18" data-v-730eaece></line><line x1="3" y1="6" x2="3.01" y2="6" data-v-730eaece></line><line x1="3" y1="12" x2="3.01" y2="12" data-v-730eaece></line><line x1="3" y1="18" x2="3.01" y2="18" data-v-730eaece></line>',6)])])):e.name==="insert-above"?(J(),X("g",eh,[...o[20]||(o[20]=[p("line",{x1:"12",y1:"5",x2:"12",y2:"13"},null,-1),p("line",{x1:"8",y1:"9",x2:"16",y2:"9"},null,-1),p("path",{d:"M4 19h16","stroke-dasharray":"2 2"},null,-1)])])):e.name==="insert-below"?(J(),X("g",th,[...o[21]||(o[21]=[p("path",{d:"M4 5h16","stroke-dasharray":"2 2"},null,-1),p("line",{x1:"12",y1:"11",x2:"12",y2:"19"},null,-1),p("line",{x1:"8",y1:"15",x2:"16",y2:"15"},null,-1)])])):e.name==="broom"?(J(),X("g",oh,[...o[22]||(o[22]=[p("path",{d:"m18 15-6-6"},null,-1),p("path",{d:"M4 20h16"},null,-1),p("path",{d:"M6 14l8-8a2.8 2.8 0 0 1 4 4l-8 8H6v-4z"},null,-1)])])):e.name==="trash"?(J(),X("g",ih,[...o[23]||(o[23]=[p("path",{d:"M3 6h18"},null,-1),p("path",{d:"M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"},null,-1),p("path",{d:"M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"},null,-1)])])):e.name==="ai"||e.name==="sparkles"?(J(),X("g",nh,[...o[24]||(o[24]=[p("path",{d:"m12 3-1.9 5.8a2 2 0 0 1-1.3 1.3L3 12l5.8 1.9a2 2 0 0 1 1.3 1.3L12 21l1.9-5.8a2 2 0 0 1 1.3-1.3L21 12l-5.8-1.9a2 2 0 0 1-1.3-1.3L12 3z"},null,-1)])])):e.name==="palette"?(J(),X("g",sh,[...o[25]||(o[25]=[ht('<circle cx="13.5" cy="6.5" r=".5" fill="currentColor" data-v-730eaece></circle><circle cx="17.5" cy="10.5" r=".5" fill="currentColor" data-v-730eaece></circle><circle cx="8.5" cy="7.5" r=".5" fill="currentColor" data-v-730eaece></circle><circle cx="6.5" cy="12.5" r=".5" fill="currentColor" data-v-730eaece></circle><path d="M12 2C6.5 2 2 6.5 2 12s4.5 10 10 10c.9 0 1.5-.7 1.5-1.5 0-.4-.2-.8-.4-1.1-.3-.4-.4-.8-.4-1.4 0-1.1.9-2 2-2h2.3c3.9 0 7-3.1 7-7 0-5-4.5-9-10-9z" data-v-730eaece></path>',5)])])):e.name==="ratio"?(J(),X("g",rh,[...o[26]||(o[26]=[p("rect",{x:"2",y:"5",width:"20",height:"14",rx:"2"},null,-1),p("line",{x1:"2",y1:"10",x2:"22",y2:"10","stroke-dasharray":"2 2"},null,-1)])])):e.name==="transition"?(J(),X("g",ah,[...o[27]||(o[27]=[p("path",{d:"M8 3 4 7l4 4"},null,-1),p("path",{d:"M4 7h16"},null,-1),p("path",{d:"m16 21 4-4-4-4"},null,-1),p("path",{d:"M20 17H4"},null,-1)])])):e.name==="export-html"?(J(),X("g",lh,[...o[28]||(o[28]=[p("polyline",{points:"16 16 12 12 8 16"},null,-1),p("line",{x1:"12",y1:"12",x2:"12",y2:"21"},null,-1),p("path",{d:"M20.4 16.3A5 5 0 0 0 18 7h-1.3A8 8 0 0 0 4 12.8a5 5 0 0 0 1.5 9.2"},null,-1)])])):e.name==="export-pdf"?(J(),X("g",ch,[...o[29]||(o[29]=[p("polyline",{points:"6 9 6 2 18 2 18 9"},null,-1),p("path",{d:"M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"},null,-1),p("rect",{x:"6",y:"14",width:"12",height:"8"},null,-1)])])):e.name==="pin"?(J(),X("g",dh,[...o[30]||(o[30]=[p("line",{x1:"12",y1:"17",x2:"12",y2:"22"},null,-1),p("path",{d:"M5 17h14v-2l-2-2V5l1-1V2H6v2l1 1v8l-2 2v2z"},null,-1)])])):e.name==="refresh"?(J(),X("g",uh,[...o[31]||(o[31]=[p("path",{d:"M3 12a9 9 0 0 1 9-9 9.75 9.75 0 0 1 6.74 2.74L21 8"},null,-1),p("path",{d:"M21 3v5h-5"},null,-1),p("path",{d:"M21 12a9 9 0 0 1-9 9 9.75 9.75 0 0 1-6.74-2.74L3 16"},null,-1),p("path",{d:"M8 16H3v5"},null,-1)])])):e.name==="alert"||e.name==="warning"?(J(),X("g",fh,[...o[32]||(o[32]=[p("path",{d:"M10.29 3.86 1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"},null,-1),p("line",{x1:"12",y1:"9",x2:"12",y2:"13"},null,-1),p("line",{x1:"12",y1:"17",x2:"12.01",y2:"17"},null,-1)])])):e.name==="chevron-left"?(J(),X("g",ph,[...o[33]||(o[33]=[p("polyline",{points:"15 18 9 12 15 6"},null,-1)])])):e.name==="chevron-right"?(J(),X("g",hh,[...o[34]||(o[34]=[p("polyline",{points:"9 18 15 12 9 6"},null,-1)])])):e.name==="chevron-down"?(J(),X("g",mh,[...o[35]||(o[35]=[p("polyline",{points:"6 9 12 15 18 9"},null,-1)])])):e.name==="chevrons-left"?(J(),X("g",gh,[...o[36]||(o[36]=[p("polyline",{points:"11 17 6 12 11 7"},null,-1),p("polyline",{points:"18 17 13 12 18 7"},null,-1)])])):e.name==="chevrons-right"?(J(),X("g",yh,[...o[37]||(o[37]=[p("polyline",{points:"13 17 18 12 13 7"},null,-1),p("polyline",{points:"6 17 11 12 6 7"},null,-1)])])):e.name==="play"?(J(),X("g",bh,[...o[38]||(o[38]=[p("polygon",{points:"6 3 20 12 6 21 6 3"},null,-1)])])):e.name==="pause"?(J(),X("g",vh,[...o[39]||(o[39]=[p("line",{x1:"10",y1:"4",x2:"10",y2:"20"},null,-1),p("line",{x1:"14",y1:"4",x2:"14",y2:"20"},null,-1)])])):e.name==="clock"?(J(),X("g",kh,[...o[40]||(o[40]=[p("circle",{cx:"12",cy:"12",r:"10"},null,-1),p("polyline",{points:"12 6 12 12 16 14"},null,-1)])])):e.name==="copy"?(J(),X("g",wh,[...o[41]||(o[41]=[p("rect",{x:"9",y:"9",width:"13",height:"13",rx:"2",ry:"2"},null,-1),p("path",{d:"M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"},null,-1)])])):e.name==="image"||e.name==="export-image"?(J(),X("g",xh,[...o[42]||(o[42]=[p("rect",{x:"3",y:"3",width:"18",height:"18",rx:"2",ry:"2"},null,-1),p("circle",{cx:"8.5",cy:"8.5",r:"1.5"},null,-1),p("polyline",{points:"21 15 16 10 5 21"},null,-1)])])):e.name==="search"?(J(),X("g",Sh,[...o[43]||(o[43]=[p("circle",{cx:"11",cy:"11",r:"7"},null,-1),p("line",{x1:"21",y1:"21",x2:"16.65",y2:"16.65"},null,-1)])])):e.name==="settings"||e.name==="gear"?(J(),X("g",Ch,[...o[44]||(o[44]=[p("circle",{cx:"12",cy:"12",r:"3"},null,-1),p("path",{d:"M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 1 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 1 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 1 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 1 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"},null,-1)])])):e.name==="notes"||e.name==="file-text"?(J(),X("g",_h,[...o[45]||(o[45]=[ht('<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" data-v-730eaece></path><polyline points="14 2 14 8 20 8" data-v-730eaece></polyline><line x1="16" y1="13" x2="8" y2="13" data-v-730eaece></line><line x1="16" y1="17" x2="8" y2="17" data-v-730eaece></line><line x1="10" y1="9" x2="8" y2="9" data-v-730eaece></line>',5)])])):e.name==="focus"||e.name==="target"?(J(),X("g",Ih,[...o[46]||(o[46]=[p("circle",{cx:"12",cy:"12",r:"3",fill:"currentColor"},null,-1),p("path",{d:"M12 2v4M12 18v4M2 12h4M18 12h4",stroke:"currentColor","stroke-width":"2","stroke-linecap":"round"},null,-1),p("circle",{cx:"12",cy:"12",r:"7",fill:"none",stroke:"currentColor","stroke-width":"1.8"},null,-1)])])):e.name==="layout-cover"||e.name==="cover"?(J(),X("g",$h,[...o[47]||(o[47]=[p("rect",{x:"2",y:"4",width:"20",height:"16",rx:"2"},null,-1),p("line",{x1:"6",y1:"9",x2:"18",y2:"9","stroke-width":"2.2"},null,-1),p("line",{x1:"8",y1:"13",x2:"16",y2:"13","stroke-width":"1.2",opacity:"0.8"},null,-1),p("line",{x1:"9.5",y1:"16.5",x2:"14.5",y2:"16.5","stroke-width":"1",opacity:"0.6"},null,-1)])])):e.name==="layout-default"||e.name==="default"?(J(),X("g",Th,[...o[48]||(o[48]=[ht('<rect x="2" y="4" width="20" height="16" rx="2" data-v-730eaece></rect><line x1="5" y1="7.5" x2="12" y2="7.5" stroke-width="1.8" data-v-730eaece></line><line x1="5" y1="11" x2="19" y2="11" stroke-width="1.2" data-v-730eaece></line><line x1="5" y1="14" x2="19" y2="14" stroke-width="1.2" data-v-730eaece></line><line x1="5" y1="17" x2="14" y2="17" stroke-width="1.2" opacity="0.75" data-v-730eaece></line>',5)])])):e.name==="layout-two-cols"||e.name==="two-cols"?(J(),X("g",Ah,[...o[49]||(o[49]=[ht('<rect x="2" y="4" width="20" height="16" rx="2" data-v-730eaece></rect><line x1="12" y1="4" x2="12" y2="20" stroke-dasharray="2 1.5" data-v-730eaece></line><line x1="5" y1="8" x2="9.5" y2="8" stroke-width="1.5" data-v-730eaece></line><line x1="5" y1="11.5" x2="9.5" y2="11.5" data-v-730eaece></line><line x1="5" y1="15" x2="8" y2="15" data-v-730eaece></line><line x1="14.5" y1="8" x2="19" y2="8" stroke-width="1.5" data-v-730eaece></line><line x1="14.5" y1="11.5" x2="19" y2="11.5" data-v-730eaece></line><line x1="14.5" y1="15" x2="17.5" y2="15" data-v-730eaece></line>',8)])])):e.name==="layout-two-cols-header"||e.name==="two-cols-header"?(J(),X("g",Mh,[...o[50]||(o[50]=[ht('<rect x="2" y="4" width="20" height="16" rx="2" data-v-730eaece></rect><line x1="5" y1="7.5" x2="13" y2="7.5" stroke-width="1.8" data-v-730eaece></line><line x1="12" y1="10.5" x2="12" y2="18.5" stroke-dasharray="1.5 1.5" data-v-730eaece></line><line x1="5" y1="12" x2="9.5" y2="12" data-v-730eaece></line><line x1="5" y1="15.5" x2="8.5" y2="15.5" data-v-730eaece></line><line x1="14.5" y1="12" x2="19" y2="12" data-v-730eaece></line><line x1="14.5" y1="15.5" x2="18" y2="15.5" data-v-730eaece></line>',7)])])):e.name==="layout-cols-header"||e.name==="cols-header"||e.name==="layout-three-cols-header"||e.name==="three-cols-header"?(J(),X("g",Eh,[...o[51]||(o[51]=[ht('<rect x="2" y="4" width="20" height="16" rx="2" data-v-730eaece></rect><line x1="5" y1="7.5" x2="14" y2="7.5" stroke-width="1.8" data-v-730eaece></line><line x1="9.3" y1="10.5" x2="9.3" y2="18.5" stroke-dasharray="1.5 1.5" data-v-730eaece></line><line x1="14.7" y1="10.5" x2="14.7" y2="18.5" stroke-dasharray="1.5 1.5" data-v-730eaece></line><line x1="4.5" y1="12" x2="7.5" y2="12" data-v-730eaece></line><line x1="4.5" y1="15.5" x2="7" y2="15.5" data-v-730eaece></line><line x1="10.5" y1="12" x2="13.5" y2="12" data-v-730eaece></line><line x1="10.5" y1="15.5" x2="13.5" y2="15.5" data-v-730eaece></line><line x1="16" y1="12" x2="19.5" y2="12" data-v-730eaece></line><line x1="16" y1="15.5" x2="18.5" y2="15.5" data-v-730eaece></line>',10)])])):e.name==="layout-clover"||e.name==="clover"?(J(),X("g",Bh,[...o[52]||(o[52]=[ht('<rect x="2" y="4" width="20" height="16" rx="2" data-v-730eaece></rect><line x1="5" y1="7" x2="13" y2="7" stroke-width="1.6" data-v-730eaece></line><line x1="4.5" y1="13.5" x2="19.5" y2="13.5" stroke-dasharray="1.5 1.5" data-v-730eaece></line><line x1="12" y1="9" x2="12" y2="18.5" stroke-dasharray="1.5 1.5" data-v-730eaece></line><line x1="5" y1="11" x2="9.5" y2="11" data-v-730eaece></line><line x1="14.5" y1="11" x2="19" y2="11" data-v-730eaece></line><line x1="5" y1="16" x2="9.5" y2="16" data-v-730eaece></line><line x1="14.5" y1="16" x2="19" y2="16" data-v-730eaece></line>',8)])])):e.name==="layout-timeline"||e.name==="timeline"||e.name==="layout-steps"||e.name==="steps"?(J(),X("g",Lh,[...o[53]||(o[53]=[ht('<rect x="2" y="4" width="20" height="16" rx="2" data-v-730eaece></rect><line x1="5" y1="7" x2="12" y2="7" stroke-width="1.6" data-v-730eaece></line><line x1="6" y1="11.5" x2="18" y2="11.5" stroke-width="1.2" opacity="0.65" data-v-730eaece></line><circle cx="6" cy="11.5" r="1.8" fill="currentColor" data-v-730eaece></circle><line x1="4.5" y1="15.5" x2="7.5" y2="15.5" stroke-width="1.2" data-v-730eaece></line><circle cx="12" cy="11.5" r="1.8" fill="currentColor" data-v-730eaece></circle><line x1="10.5" y1="15.5" x2="13.5" y2="15.5" stroke-width="1.2" data-v-730eaece></line><circle cx="18" cy="11.5" r="1.8" fill="currentColor" data-v-730eaece></circle><line x1="16.5" y1="15.5" x2="19.5" y2="15.5" stroke-width="1.2" data-v-730eaece></line>',9)])])):e.name==="layout-image-right"||e.name==="image-right"?(J(),X("g",Dh,[...o[54]||(o[54]=[ht('<rect x="2" y="4" width="20" height="16" rx="2" data-v-730eaece></rect><line x1="12" y1="4" x2="12" y2="20" data-v-730eaece></line><line x1="4.5" y1="8" x2="9.5" y2="8" stroke-width="1.5" data-v-730eaece></line><line x1="4.5" y1="11.5" x2="10" y2="11.5" data-v-730eaece></line><line x1="4.5" y1="14.5" x2="8" y2="14.5" data-v-730eaece></line><circle cx="15.5" cy="8.5" r="1.2" data-v-730eaece></circle><polyline points="13 17 15.5 13 18 16 19.5 14" data-v-730eaece></polyline>',7)])])):e.name==="layout-image-left"||e.name==="image-left"?(J(),X("g",Nh,[...o[55]||(o[55]=[ht('<rect x="2" y="4" width="20" height="16" rx="2" data-v-730eaece></rect><line x1="12" y1="4" x2="12" y2="20" data-v-730eaece></line><circle cx="6" cy="8.5" r="1.2" data-v-730eaece></circle><polyline points="3.5 17 6 13 8.5 16 10 14" data-v-730eaece></polyline><line x1="14.5" y1="8" x2="19.5" y2="8" stroke-width="1.5" data-v-730eaece></line><line x1="14.5" y1="11.5" x2="20" y2="11.5" data-v-730eaece></line><line x1="14.5" y1="14.5" x2="18" y2="14.5" data-v-730eaece></line>',7)])])):e.name==="layout-center"||e.name==="center"?(J(),X("g",Oh,[...o[56]||(o[56]=[p("rect",{x:"2",y:"4",width:"20",height:"16",rx:"2"},null,-1),p("line",{x1:"7",y1:"10",x2:"17",y2:"10","stroke-width":"1.8"},null,-1),p("line",{x1:"5.5",y1:"13.5",x2:"18.5",y2:"13.5","stroke-width":"1.2"},null,-1),p("line",{x1:"8",y1:"16.5",x2:"16",y2:"16.5","stroke-width":"1",opacity:"0.8"},null,-1)])])):e.name==="layout-fact"||e.name==="fact"?(J(),X("g",Ph,[...o[57]||(o[57]=[ht('<rect x="2" y="4" width="20" height="16" rx="2" data-v-730eaece></rect><circle cx="8" cy="9" r="1.6" stroke-width="1.5" data-v-730eaece></circle><line x1="15" y1="7.5" x2="9" y2="14.5" stroke-width="1.8" data-v-730eaece></line><circle cx="16" cy="13" r="1.6" stroke-width="1.5" data-v-730eaece></circle><line x1="6" y1="17.5" x2="18" y2="17.5" stroke-width="1.2" opacity="0.85" data-v-730eaece></line>',5)])])):e.name==="layout-intro"||e.name==="intro"?(J(),X("g",Rh,[...o[58]||(o[58]=[ht('<rect x="2" y="4" width="20" height="16" rx="2" data-v-730eaece></rect><circle cx="7.5" cy="10" r="2.5" stroke-width="1.5" data-v-730eaece></circle><path d="M4 17c0-2 1.5-3.2 3.5-3.2s3.5 1.2 3.5 3.2" stroke-width="1.2" data-v-730eaece></path><line x1="13.5" y1="8.5" x2="19" y2="8.5" stroke-width="1.8" data-v-730eaece></line><line x1="13.5" y1="12" x2="19.5" y2="12" stroke-width="1.2" data-v-730eaece></line><line x1="13.5" y1="15.5" x2="17.5" y2="15.5" stroke-width="1.2" opacity="0.8" data-v-730eaece></line>',6)])])):e.name==="layout-quote"||e.name==="quote"?(J(),X("g",zh,[...o[59]||(o[59]=[ht('<rect x="2" y="4" width="20" height="16" rx="2" data-v-730eaece></rect><path d="M5.5 8h2v2H6c0 1.2-.3 1.8-1.2 2.3" stroke-width="1.4" data-v-730eaece></path><path d="M8.5 8h2v2H9c0 1.2-.3 1.8-1.2 2.3" stroke-width="1.4" data-v-730eaece></path><line x1="6" y1="13" x2="18" y2="13" stroke-width="1.5" data-v-730eaece></line><line x1="12.5" y1="16.5" x2="17.5" y2="16.5" stroke-width="1.2" opacity="0.8" data-v-730eaece></line>',5)])])):e.name==="desktop"||e.name==="monitor"?(J(),X("g",Hh,[...o[60]||(o[60]=[p("rect",{x:"2",y:"3",width:"20",height:"14",rx:"2"},null,-1),p("line",{x1:"8",y1:"21",x2:"16",y2:"21"},null,-1),p("line",{x1:"12",y1:"17",x2:"12",y2:"21"},null,-1)])])):e.name==="mobile"||e.name==="smartphone"||e.name==="phone"?(J(),X("g",Fh,[...o[61]||(o[61]=[p("rect",{x:"5",y:"2",width:"14",height:"20",rx:"2",ry:"2"},null,-1),p("line",{x1:"12",y1:"18",x2:"12.01",y2:"18","stroke-width":"2","stroke-linecap":"round"},null,-1)])])):e.name==="type"||e.name==="heading"?(J(),X("g",jh,[...o[62]||(o[62]=[p("polyline",{points:"4 7 4 4 20 4 20 7"},null,-1),p("line",{x1:"9",y1:"20",x2:"15",y2:"20"},null,-1),p("line",{x1:"12",y1:"4",x2:"12",y2:"20"},null,-1)])])):e.name==="reset"||e.name==="undo"?(J(),X("g",Uh,[...o[63]||(o[63]=[p("path",{d:"M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8"},null,-1),p("polyline",{points:"3 3 3 8 8 8"},null,-1)])])):e.name==="repeat"||e.name==="loop"?(J(),X("g",Wh,[...o[64]||(o[64]=[p("path",{d:"m17 1 4 4-4 4"},null,-1),p("path",{d:"M3 11V9a4 4 0 0 1 4-4h14"},null,-1),p("path",{d:"m7 23-4-4 4-4"},null,-1),p("path",{d:"M21 13v2a4 4 0 0 1-4 4H3"},null,-1)])])):e.name==="volume-x"||e.name==="mute"?(J(),X("g",qh,[...o[65]||(o[65]=[p("polygon",{points:"11 5 6 9 2 9 2 15 6 15 11 19 11 5"},null,-1),p("line",{x1:"22",y1:"9",x2:"16",y2:"15"},null,-1),p("line",{x1:"16",y1:"9",x2:"22",y2:"15"},null,-1)])])):e.name==="sliders"||e.name==="controls"?(J(),X("g",Vh,[...o[66]||(o[66]=[ht('<line x1="4" y1="21" x2="4" y2="14" data-v-730eaece></line><line x1="4" y1="10" x2="4" y2="3" data-v-730eaece></line><line x1="12" y1="21" x2="12" y2="12" data-v-730eaece></line><line x1="12" y1="8" x2="12" y2="3" data-v-730eaece></line><line x1="20" y1="21" x2="20" y2="16" data-v-730eaece></line><line x1="20" y1="12" x2="20" y2="3" data-v-730eaece></line><line x1="1" y1="14" x2="7" y2="14" data-v-730eaece></line><line x1="9" y1="8" x2="15" y2="8" data-v-730eaece></line><line x1="17" y1="16" x2="23" y2="16" data-v-730eaece></line>',9)])])):e.name==="package"||e.name==="zip"||e.name==="archive"?(J(),X("g",Kh,[...o[67]||(o[67]=[p("line",{x1:"16.5",y1:"9.4",x2:"7.5",y2:"4.21"},null,-1),p("path",{d:"M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"},null,-1),p("polyline",{points:"3.27 6.96 12 12.01 20.73 6.96"},null,-1),p("line",{x1:"12",y1:"22.08",x2:"12",y2:"12"},null,-1)])])):e.name==="folder"?(J(),X("g",Gh,[...o[68]||(o[68]=[p("path",{d:"M4 20h16a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2h-7.93a2 2 0 0 1-1.66-.9l-.82-1.2A2 2 0 0 0 7.93 3H4a2 2 0 0 0-2 2v13c0 1.1.9 2 2 2Z"},null,-1)])])):e.name==="rocket"?(J(),X("g",Yh,[...o[69]||(o[69]=[p("path",{d:"M4.5 16.5c-1.5 1.26-2 5-2 5s3.74-.5 5-2c.71-.84.7-2.13-.09-2.91a2.18 2.18 0 0 0-2.91-.09z"},null,-1),p("path",{d:"m12 15-3-3a22 22 0 0 1 2-3.95A12.88 12.88 0 0 1 22 2c0 2.72-.78 7.5-6 11a22.35 22.35 0 0 1-4 2z"},null,-1),p("path",{d:"M9 12H4s.55-3.03 2-4c1.62-1.08 5 0 5 0"},null,-1),p("path",{d:"M12 15v5s3.03-.55 4-2c1.08-1.62 0-5 0-5"},null,-1)])])):e.name==="wand"||e.name==="magic"?(J(),X("g",Zh,[...o[70]||(o[70]=[p("path",{d:"m19 2 2 2-6 6-2-2Z"},null,-1),p("path",{d:"m13 8 2 2"},null,-1),p("path",{d:"m3 21 9-9"},null,-1)])])):e.name==="image-left"?(J(),X("g",Jh,[...o[71]||(o[71]=[ht('<rect x="2" y="4" width="20" height="16" rx="2" data-v-730eaece></rect><rect x="4" y="6" width="6" height="12" rx="1" data-v-730eaece></rect><line x1="13" y1="8" x2="19" y2="8" data-v-730eaece></line><line x1="13" y1="12" x2="19" y2="12" data-v-730eaece></line><line x1="13" y1="16" x2="17" y2="16" data-v-730eaece></line>',5)])])):e.name==="image-right"?(J(),X("g",Xh,[...o[72]||(o[72]=[ht('<rect x="2" y="4" width="20" height="16" rx="2" data-v-730eaece></rect><rect x="14" y="6" width="6" height="12" rx="1" data-v-730eaece></rect><line x1="5" y1="8" x2="11" y2="8" data-v-730eaece></line><line x1="5" y1="12" x2="11" y2="12" data-v-730eaece></line><line x1="5" y1="16" x2="9" y2="16" data-v-730eaece></line>',5)])])):e.name==="help"||e.name==="question"||e.name==="info"?(J(),X("g",Qh,[...o[73]||(o[73]=[p("circle",{cx:"12",cy:"12",r:"10"},null,-1),p("path",{d:"M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"},null,-1),p("line",{x1:"12",y1:"17",x2:"12.01",y2:"17"},null,-1)])])):(J(),X("g",em,[...o[74]||(o[74]=[p("rect",{x:"2",y:"3",width:"20",height:"14",rx:"2"},null,-1),p("line",{x1:"8",y1:"21",x2:"16",y2:"21"},null,-1),p("line",{x1:"12",y1:"17",x2:"12",y2:"21"},null,-1)])]))]))}}),uo=(e,t)=>{const o=e.__vccOpts||e;for(const[i,n]of t)o[i]=n;return o},ue=uo(tm,[["__scopeId","data-v-730eaece"]]),om={class:"spm-immersion-header"},im={class:"spm-immersion-header__left"},nm={class:"spm-immersion-title"},sm={class:"spm-immersion-header__center"},rm={class:"spm-immersion-header__actions"},am=["aria-label"],lm={class:"spm-immersion-body"},cm=Ht({__name:"ImmersionDrawerContainer",props:{visible:{type:Boolean,default:!1},isMaximized:{type:Boolean,default:!1},title:{default:"速览"},closeOnClickMask:{type:Boolean,default:!0}},emits:["update:visible","update:isMaximized","close","toggle-maximize"],setup(e,{emit:t}){const o=e,i=t;function n(){i("update:visible",!1),i("close")}function s(){o.closeOnClickMask&&n()}function l(){i("update:isMaximized",!o.isMaximized),i("toggle-maximize")}function r(a){(a.key===" "||a.key==="ArrowLeft"||a.key==="ArrowRight"||a.key==="PageUp"||a.key==="PageDown")&&a.stopPropagation(),a.key==="Escape"&&(a.preventDefault(),a.stopPropagation(),n())}return(a,c)=>Vt((J(),X("div",{class:xe(["spm-immersion-container",{"is-maximized":e.isMaximized}]),onKeydown:ro(r,["stop"])},[p("div",{class:"spm-immersion-mask",onClick:s}),p("div",{class:xe(["spm-immersion-drawer",{"is-maximized":e.isMaximized}])},[p("div",om,[p("div",im,[pn(a.$slots,"header-left",{},()=>[p("span",nm,ve(e.title),1)])]),p("div",sm,[pn(a.$slots,"header-center",{},void 0)]),p("div",rm,[pn(a.$slots,"header-actions",{},void 0),p("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":e.isMaximized?"还原抽屉宽度 (70%)":"最大化填满视口 (100%)",onClick:l},[le(ue,{name:e.isMaximized?"minimize":"maximize"},null,8,["name"])],8,am),p("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"关闭速览 (ESC)",onClick:n},[le(ue,{name:"close"})])])]),p("div",lm,[pn(a.$slots,"default",{},void 0)])],2)],34)),[[Us,e.visible]])}}),dm=uo(cm,[["__scopeId","data-v-1359fecb"]]);function um(){if(typeof window<"u"&&typeof window.require=="function")return window.require.bind(window);if(typeof globalThis<"u"&&typeof globalThis.require=="function")return globalThis.require.bind(globalThis);if(typeof require=="function")return require}function an(e){const t=um();if(t)try{return t(e)}catch{try{const o=e.startsWith("node:")?e.slice(5):`node:${e}`;return t(o)}catch{}}}function fm(){var t;if(typeof window<"u"&&window.process)return window.process;const e=an("process");return e&&e.versions?e:typeof process<"u"&&((t=process.versions)!=null&&t.node)?process:globalThis.process}function pm(){var t,o;const e=fm();if(e&&((t=e.versions)!=null&&t.node))return!0;if(typeof window<"u"&&window.siyuan){const i=an("child_process");if(i&&typeof i.spawn=="function")return!0}return!!(typeof process<"u"&&((o=process.versions)!=null&&o.node))}function hm(){if(typeof window>"u"||!window.location)return!1;try{return new URLSearchParams(window.location.search).get("remote")==="1"}catch{return!1}}const mm={class:"spm-protyle-drawer"},gm={class:"spm-protyle-drawer__subbar"},ym={class:"spm-protyle-drawer__nav"},bm=["title"],vm={class:"spm-protyle-drawer__actions"},km=["aria-label"],wm=["aria-label"],xm=Ht({__name:"ProtylePeekDrawer",props:{blockId:{},title:{},plugin:{}},emits:["external-jump"],setup(e,{emit:t}){const o=t,i=e,n=he(i.blockId),s=he(i.title||""),l=he(!1),r=he(!0),a=he(!1),c=he(""),u=jt,f=he([]),h=he(null);let d=null;Fo(()=>i.blockId,C=>{C&&C!==n.value&&(n.value=C,s.value=i.title||"",f.value=[],m(C))}),oi(()=>{n.value&&m(n.value)}),hr(()=>{y()});async function b(C){try{const L=await ki(`SELECT id, root_id, type, content FROM blocks WHERE id = '${C}' LIMIT 1`);if(Array.isArray(L)&&L.length>0){const R=L[0];c.value=R.root_id||"";const N=R.id===R.root_id||R.type==="d";a.value=N,r.value=!N,!s.value&&R.content&&(s.value=R.content.trim().slice(0,30));return}}catch(L){console.warn("[ProtylePeekDrawer] detectBlockType query failed:",L)}a.value=!1,r.value=!0}async function m(C,L){if(!h.value||!C)return;y(),await b(C),typeof L=="boolean"&&(r.value=!a.value&&L);let R,N;r.value&&!a.value?(R=["cb-get-all","cb-get-hl","cb-get-focus"],N={background:!1,title:!1,gutter:!0,breadcrumbDocName:!0,scroll:!0}):(R=["cb-get-context","cb-get-hl"],N={background:!0,title:!0,gutter:!0,breadcrumbDocName:!0,scroll:!0});try{d=new ie.Protyle(i.plugin.app,h.value,{blockId:C,action:R,render:N}),!l.value&&d&&typeof d.disable=="function"&&d.disable()}catch(F){console.error("[ProtylePeekDrawer] Failed to instantiate Protyle:",F)}}function y(){if(d){try{typeof d.destroy=="function"&&d.destroy()}catch(C){console.warn("[ProtylePeekDrawer] Error destroying protyle:",C)}d=null}h.value&&(h.value.innerHTML="")}function g(){a.value||(r.value=!r.value,m(n.value,r.value))}function x(){l.value=!l.value,d&&(l.value?(typeof d.enable=="function"&&d.enable(),typeof d.focus=="function"&&d.focus()):typeof d.disable=="function"&&d.disable())}function k(){if(n.value)try{ie.openWindow({doc:{id:n.value},alwaysOnTop:!0})}catch(C){console.warn("[ProtylePeekDrawer] openWindow failed:",C)}}function I(){var R;if(!n.value)return;const C=jo(),L=ec(C.webServeUrl,n.value,{focus:!a.value});if(typeof window<"u"){const N=an("electron");(R=N==null?void 0:N.shell)!=null&&R.openExternal?N.shell.openExternal(L).catch(()=>{window.open(L,"_blank")}):window.open(L,"_blank")}o("external-jump",L)}function T(){if(f.value.length>0){const C=f.value.pop();C&&(n.value=C.blockId,s.value=C.title,r.value=C.isFocusMode,a.value=C.isDoc,m(C.blockId,C.isFocusMode))}}function w(C){const L=C.target;if(!L)return;const R=L.closest('[data-type="block-ref"]');if(R){const F=R.getAttribute("data-id");if(F&&F!==n.value){C.preventDefault(),C.stopPropagation(),f.value.push({blockId:n.value,title:s.value||n.value,isFocusMode:r.value,isDoc:a.value}),n.value=F,s.value=R.innerText.trim()||F,m(F);return}}const N=L.closest("a");if(N&&N.href&&N.href.startsWith("siyuan://blocks/")){C.preventDefault(),C.stopPropagation();const F=N.href.replace("siyuan://blocks/","").split("?")[0];F&&F!==n.value&&(f.value.push({blockId:n.value,title:s.value||n.value,isFocusMode:r.value,isDoc:a.value}),n.value=F,s.value=N.innerText.trim()||F,m(F))}}return(C,L)=>(J(),X("div",mm,[p("div",gm,[p("div",ym,[f.value.length>0?(J(),X("button",{key:0,class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"返回上层引用文档或块",onClick:T},[le(ue,{name:"arrow-left"}),L[0]||(L[0]=p("span",null,"返回",-1))])):Te("",!0),p("span",{class:xe(["spm-protyle-badge",{"is-focus":r.value&&!a.value}])},ve(r.value&&!a.value?"思源块聚焦":"思源文档速览"),3),p("span",{class:"spm-protyle-id",title:s.value||n.value},ve(s.value||n.value),9,bm)]),p("div",vm,[a.value?Te("",!0):(J(),X("button",{key:0,class:xe(["spm-icon-btn b3-tooltips b3-tooltips__s",{"is-primary":r.value}]),"aria-label":r.value?"当前为块聚焦模式（点击展开所属文档全文）":"当前为文档全文模式（点击切回仅聚焦当前块）",onClick:g},[le(ue,{name:r.value?"focus":"file-text"},null,8,["name"]),p("span",null,ve(r.value?"块聚焦":"展开全文"),1)],10,km)),p("button",{class:xe(["spm-icon-btn b3-tooltips b3-tooltips__s",{"is-primary":l.value}]),"aria-label":l.value?"当前为即时编辑模式（点击切回只读）":"当前为只读速览模式（点击解锁即时编辑）",onClick:x},[le(ue,{name:l.value?"edit":"eye"},null,8,["name"]),p("span",null,ve(l.value?"编辑中":"只读"),1)],10,wm),p("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"在置顶独立窗口中打开 (保留完整侧边栏与插件)",onClick:k},[le(ue,{name:"window"}),L[1]||(L[1]=p("span",null,"独立窗口",-1))]),de(u).enableWebServeJump?(J(),X("button",{key:1,class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"在系统默认浏览器中打开 (外跳)",onClick:I},[le(ue,{name:"external-link"}),L[2]||(L[2]=p("span",null,"外跳",-1))])):Te("",!0)])]),p("div",{ref_key:"mountEl",ref:h,class:xe(["spm-protyle-mount",{"is-focus-mode":r.value&&!a.value}]),onClick:w},null,2)]))}}),Sm=uo(xm,[["__scopeId","data-v-0d6e2df3"]]),Cm=/^(https?|file|data|blob|mailto|tel|ftp|ftps|siyuan|about|chrome|ws|wss):/i,_m=/\.(html?|xhtml|pdf|png|jpe?g|gif|svg|webp|avif|ico|mp4|webm|mov|mp3|wav|m4a|ogg|json|md|markdown|txt|csv|zip|tar|gz|7z|rar|js|mjs|css|xml|yaml|yml|toml|ipynb|docx?|xlsx?|pptx?)$/i;function Ia(e){let t=e||"";try{t=decodeURIComponent(t)}catch{}t=t.replace(/\\/g,"/");const o=/(?:^|\/)data\/assets\/(.+)$/i.exec(t);if(o)return`/assets/${o[1]}`;const i=/(?:^|\/)data\/plugins\/(.+)$/i.exec(t);return i?`/plugins/${i[1]}`:null}function ac(e){const t=(e||"").replace(/^file:\/\//i,"");let o=t;try{o=decodeURIComponent(t)}catch{}if(o.startsWith("/"))return/^\/([a-zA-Z]:[\\/])/.exec(o)?o.slice(1):o;const i=o.indexOf("/");return i>=0?o.slice(i):o}function Im(e){const t=e.split(/[/?#]/)[0];return!t||_m.test(t)?!1:/^(localhost|\d{1,3}(\.\d{1,3}){3})(:\d+)?$/i.test(t)?!0:/^[a-z0-9-]+(\.[a-z0-9-]+)+(:\d+)?$/i.test(t)}function $m(e){const t=e.indexOf("#"),o=t>=0?e.slice(t):"",i=t>=0?e.slice(0,t):e,n=i.indexOf("?"),s=n>=0?i.slice(0,n):i,l=n>=0?i.slice(n+1):"";if(!/^\/?assets\/.+\.html?$/i.test(s))return e;const r=new URLSearchParams(l);return r.get("iframe")==="true"||r.get("download")==="true"?e:(r.set("iframe","true"),`${s}?${r.toString()}${o}`)}function lc(e){const t=Tm(e);return t.external||!t.url?t:{url:$m(t.url),external:!1}}function Tm(e){const t=(e||"").trim();if(!t)return{url:"",external:!1};if(/^https?:\/\//i.test(t))return{url:t,external:!1};if(t.startsWith("//"))return{url:`https:${t}`,external:!1};if(/^(siyuan|data|blob|about):/i.test(t))return{url:t,external:!1};if(Ka(t))return{url:`/${Ga(t)}`,external:!1};if(/^file:/i.test(t)){const i=Ia(ac(t));return i?{url:i,external:!1}:{url:t,external:!0}}if(/^[a-zA-Z]:[\\/]/.test(t)||t.startsWith("\\\\")){const i=Ia(t);return i?{url:i,external:!1}:{url:t,external:!0}}return Cm.test(t)?{url:t,external:!0}:Im(t)?{url:`https://${t}`,external:!1}:{url:`/${t.replace(/^(?:\.{1,2}\/)+/,"").replace(/^\/+/,"")}`,external:!1}}const Am={class:"spm-webview-drawer"},Mm={class:"spm-webview-toolbar"},Em={class:"spm-webview-toolbar__nav"},Bm=["disabled"],Lm=["disabled"],Dm=["aria-label"],Nm={class:"spm-webview-toolbar__address"},Om=["aria-label"],Pm={class:"spm-webview-toolbar__actions"},Rm=["aria-label"],zm={class:"spm-zoom-controller"},Hm=["disabled"],Fm=["disabled"],jm={key:1,class:"spm-webview-fallback"},Um=["src"],Wm={key:2,class:"spm-load-error"},qm={class:"spm-load-error__code"},Vm={class:"spm-load-error__code-num"},Km={class:"spm-load-error__url"},Gm={class:"spm-load-error__hint"},Ym={class:"spm-load-error__actions"},$a="Mozilla/5.0 (iPhone; CPU iPhone OS 17_4_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.4.1 Mobile/15E148 Safari/604.1",cc="siyuan-slides-peek-view-mode";let dc="desktop";function Zm(){if(typeof window<"u"&&window.localStorage)try{const e=window.localStorage.getItem(cc);if(e==="mobile"||e==="desktop")return e}catch{}return dc}function Jm(e){if(dc=e,typeof window<"u"&&window.localStorage)try{window.localStorage.setItem(cc,e)}catch{}}function Xm(e){switch((e||"").toUpperCase()){case"ERR_PROXY_CONNECTION_FAILED":return"无法连接到代理服务器：请在思源「设置 → 网络代理」中填写公司代理地址，或切换为「使用系统代理」。";case"ERR_TUNNEL_CONNECTION_FAILED":return"HTTPS 代理隧道建立失败：请将思源「网络代理」的类型设为 HTTPS 并确认地址正确。";case"ERR_MANDATORY_PROXY_CONFIGURATION_FAILED":return"强制代理配置获取失败：公司 PAC 脚本不可用，请在思源「网络代理」中改为手动填写代理地址。";case"ERR_NAME_NOT_RESOLVED":case"ERR_NAME_RESOLUTION_FAILED":return"域名解析失败：内网环境访问外网通常需要配置代理或 DNS。";case"ERR_INTERNET_DISCONNECTED":return"当前网络不可用：请检查网络连接。";case"ERR_CONNECTION_TIMED_OUT":case"ERR_TIMED_OUT":return"连接超时：该地址可能需要通过代理才能访问。";case"ERR_CONNECTION_REFUSED":return"连接被拒绝：目标服务未在监听，或思源本地内核尚未启动。";case"ERR_CERT_AUTHORITY_INVALID":case"ERR_CERT_COMMON_NAME_INVALID":case"ERR_CERT_DATE_INVALID":return"证书校验失败：若公司网络使用 TLS 拦截，需将根证书导入思源所用系统的证书库。";default:return"若处于公司内网，请优先检查思源「设置 → 网络代理」是否已配置为可用代理（支持「使用系统代理」）。"}}const Qm=Ht({__name:"WebviewPeekDrawer",props:{url:{},title:{},visible:{type:Boolean,default:!0}},emits:["external-jump"],setup(e,{emit:t}){const o=t,i=e,n=he(pm()&&!hm()),s=he(i.url),l=he(i.url),r=i.url,a=he(!1),c=he(null),u=he(!1),f=he(!1),h=he(1),d=he(!1),b=he(Zm());let m=typeof navigator<"u"&&!navigator.userAgent.includes("iPhone")?navigator.userAgent:"";const y=ge(()=>b.value==="mobile"?$a:m||void 0),g=he(null),x=he(null);let k=null,I=null,T=null;Fo(()=>i.url,z=>{z&&z!==s.value&&(s.value=z,l.value=z,b.value==="mobile"&&N(!1),g.value&&typeof g.value.loadURL=="function"&&g.value.loadURL(z))}),Fo(()=>i.visible,z=>{if(z)ne(),b.value==="mobile"&&N(!1);else if(g.value)try{typeof g.value.stop=="function"&&g.value.stop()}catch{}}),oi(()=>{w(),x.value&&typeof ResizeObserver<"u"&&(k=new ResizeObserver(()=>{const z=g.value;if(z&&typeof z.invalidate=="function")try{z.invalidate()}catch{}}),k.observe(x.value)),I=z=>{var D;const se=z.message||((D=z.error)==null?void 0:D.message);if(typeof se=="string"&&se.includes("Invalid guestInstanceId"))return z.preventDefault(),z.stopImmediatePropagation(),!0},window.addEventListener("error",I,!0),T=z=>{const se=z.reason,D=typeof se=="string"?se:se==null?void 0:se.message;typeof D=="string"&&D.includes("Invalid guestInstanceId")&&z.preventDefault()},window.addEventListener("unhandledrejection",T)}),hr(()=>{if(C(),k&&(k.disconnect(),k=null),I&&(window.removeEventListener("error",I,!0),I=null),T&&(window.removeEventListener("unhandledrejection",T),T=null),g.value)try{typeof g.value.stop=="function"&&g.value.stop()}catch{}});function w(){const z=g.value;z&&(z.addEventListener("dom-ready",L),z.addEventListener("did-start-loading",F),z.addEventListener("did-stop-loading",S),z.addEventListener("did-navigate",W),z.addEventListener("did-navigate-in-page",j),z.addEventListener("new-window",_),z.addEventListener("did-fail-load",E),z.addEventListener("did-fail-provisional-load",E))}function C(){const z=g.value;if(z)try{z.removeEventListener("dom-ready",L),z.removeEventListener("did-start-loading",F),z.removeEventListener("did-stop-loading",S),z.removeEventListener("did-navigate",W),z.removeEventListener("did-navigate-in-page",j),z.removeEventListener("new-window",_),z.removeEventListener("did-fail-load",E),z.removeEventListener("did-fail-provisional-load",E)}catch{}}function L(){const z=g.value;if(z&&typeof z.getUserAgent=="function"&&!m)try{const se=z.getUserAgent();se&&!se.includes("iPhone")&&(m=se)}catch{}b.value==="mobile"&&N(!1),ne(),M()}function R(){const z=b.value==="mobile"?"desktop":"mobile";b.value=z,Jm(z),N(!0)}function N(z=!1){const se=g.value;if(!se)return;const D=b.value==="mobile"?$a:m;if(typeof se.setUserAgent=="function"&&D)try{se.setUserAgent(D)}catch(V){console.warn("[WebviewPeekDrawer] setUserAgent error:",V)}if(z&&typeof se.reload=="function")try{se.reload()}catch(V){console.warn("[WebviewPeekDrawer] reload error:",V)}}function F(){a.value=!0,c.value=null}function E(z){if(z&&z.isMainFrame===!1||z&&Number(z.errorCode)===-3)return;const se=String((z==null?void 0:z.errorDescription)||"ERR_FAILED");c.value={errorCode:Number((z==null?void 0:z.errorCode)??0),description:se,validatedURL:String((z==null?void 0:z.validatedURL)||s.value),hint:Xm(se)},a.value=!1}function O(){c.value=null,q()}function S(){if(a.value=!1,M(),g.value&&typeof g.value.getURL=="function"){const z=g.value.getURL();z&&z!=="about:blank"&&(s.value=z,l.value=z)}}function W(z){z!=null&&z.url&&(s.value=z.url,l.value=z.url),M()}function j(z){z!=null&&z.url&&(s.value=z.url,l.value=z.url),M()}function _(z){z&&z.url&&(z.preventDefault(),g.value&&typeof g.value.loadURL=="function"&&g.value.loadURL(z.url))}function M(){const z=g.value;z&&(typeof z.canGoBack=="function"&&(u.value=z.canGoBack()),typeof z.canGoForward=="function"&&(f.value=z.canGoForward()))}function B(){g.value&&typeof g.value.goBack=="function"&&g.value.goBack()}function Q(){g.value&&typeof g.value.goForward=="function"&&g.value.goForward()}function q(){g.value&&typeof g.value.reload=="function"&&g.value.reload()}function U(){const z=lc(l.value);if(z.url){if(z.external){s.value=z.url,Ce();return}s.value=z.url,l.value=z.url,g.value&&typeof g.value.loadURL=="function"&&g.value.loadURL(z.url)}}function ne(){const z=g.value;if(z&&typeof z.setZoomFactor=="function")try{z.setZoomFactor(h.value)}catch(se){console.warn("[WebviewPeekDrawer] setZoomFactor error:",se)}}function oe(){h.value=Math.min(2.5,Math.round((h.value+.1)*10)/10),ne()}function ae(){h.value=Math.max(.5,Math.round((h.value-.1)*10)/10),ne()}function Se(){h.value=1,ne()}function $e(z){z.preventDefault(),z.deltaY<0?oe():z.deltaY>0&&ae()}async function ke(){if(typeof navigator<"u"&&navigator.clipboard)try{await navigator.clipboard.writeText(s.value),d.value=!0,setTimeout(()=>{d.value=!1},2e3)}catch(z){console.warn("Copy url failed:",z)}}function Ce(){var se;const z=s.value;if(typeof window<"u"){const D=an("electron");(se=D==null?void 0:D.shell)!=null&&se.openExternal?D.shell.openExternal(z).catch(()=>{window.open(z,"_blank")}):window.open(z,"_blank")}o("external-jump",z)}return(z,se)=>{const D=Wu("webview");return J(),X("div",Am,[p("div",Mm,[p("div",Em,[p("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s",disabled:!u.value,"aria-label":"后退",onClick:B},[le(ue,{name:"arrow-left"})],8,Bm),p("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s",disabled:!f.value,"aria-label":"前进",onClick:Q},[le(ue,{name:"arrow-right"})],8,Lm),p("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":a.value?"正在加载...":"刷新页面",onClick:q},[le(ue,{name:"refresh"})],8,Dm)]),p("div",Nm,[Vt(p("input",{"onUpdate:modelValue":se[0]||(se[0]=V=>l.value=V),type:"text",class:"b3-text-field spm-url-input",placeholder:"https://...",spellcheck:"false",onKeydown:rp(U,["enter"])},null,544),[[Ws,l.value]]),p("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":d.value?"已复制地址！":"复制网址",onClick:ke},[le(ue,{name:"copy"})],8,Om)]),p("div",Pm,[p("button",{class:xe(["spm-icon-btn spm-mode-toggle b3-tooltips b3-tooltips__s",{"is-active":b.value==="mobile"}]),"aria-label":b.value==="mobile"?"当前为手机视图，点击切换为桌面视图":"当前为桌面视图，点击切换为手机视图",onClick:R},[le(ue,{name:b.value==="mobile"?"mobile":"desktop"},null,8,["name"])],10,Rm),p("div",zm,[p("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"缩小 (Ctrl + -)",disabled:h.value<=.5,onClick:ae},[le(ue,{name:"minus"})],8,Hm),p("button",{class:"spm-zoom-badge b3-tooltips b3-tooltips__s","aria-label":"重置 100% (Ctrl + 0)",onClick:Se},ve(Math.round(h.value*100))+"% ",1),p("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"放大 (Ctrl + +)",disabled:h.value>=2.5,onClick:oe},[le(ue,{name:"plus"})],8,Fm)]),p("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"在系统默认浏览器中打开 ↗",onClick:Ce},[le(ue,{name:"external-link"}),se[1]||(se[1]=p("span",null,"外跳",-1))])])]),p("div",{ref_key:"containerEl",ref:x,class:xe(["spm-webview-body",{"is-mobile":b.value==="mobile"}]),onWheel:ro($e,["ctrl"])},[p("div",{class:xe(["spm-webview-viewport",{"is-mobile":b.value==="mobile"}])},[n.value?(J(),Gt(D,{key:0,ref_key:"webviewRef",ref:g,class:"spm-webview-frame",src:de(r),useragent:y.value,allowpopups:"true",style:{position:"absolute",top:"0",left:"0",width:"100%",height:"100%",display:"inline-flex"}},null,8,["src","useragent"])):(J(),X("div",jm,[p("iframe",{class:"spm-webview-fallback-frame",src:s.value,frameborder:"0",sandbox:"allow-scripts allow-same-origin allow-forms allow-popups"},null,8,Um),p("div",{class:"spm-fallback-bar"},[se[2]||(se[2]=p("span",null,"如页面受同源策略 (X-Frame-Options) 拦截无法显示，请",-1)),p("button",{class:"spm-icon-btn is-primary",onClick:Ce}," 在新标签页中打开 ↗ ")])])),c.value?(J(),X("div",Wm,[le(ue,{name:"alert",class:"spm-load-error__icon"}),se[5]||(se[5]=p("div",{class:"spm-load-error__title"},"页面加载失败",-1)),p("div",qm,[_t(ve(c.value.description)+" ",1),p("span",Vm,"("+ve(c.value.errorCode)+")",1)]),p("div",Km,ve(c.value.validatedURL),1),p("p",Gm,ve(c.value.hint),1),p("div",Ym,[p("button",{class:"spm-icon-btn","aria-label":"重试",onClick:O},[le(ue,{name:"refresh"}),se[3]||(se[3]=p("span",null,"重试",-1))]),p("button",{class:"spm-icon-btn is-primary","aria-label":"用系统浏览器打开",onClick:Ce},[le(ue,{name:"external-link"}),se[4]||(se[4]=p("span",null,"用系统浏览器打开 ↗",-1))])])])):Te("",!0)],2)],34)])}}}),eg=uo(Qm,[["__scopeId","data-v-6e363f73"]]);class tg{constructor(){Ie(this,"timers",new Map)}debounce(t,o,i=150){this.cancel(t);const n=setTimeout(()=>{this.timers.delete(t),o()},i);this.timers.set(t,n)}cancel(t){this.timers.has(t)&&(clearTimeout(this.timers.get(t)),this.timers.delete(t))}cancelAll(){for(const t of this.timers.values())clearTimeout(t);this.timers.clear()}hasPending(t){return this.timers.has(t)}}class og{constructor(t){Ie(this,"blockToPageMap",new Map);Ie(this,"debounceCtrl",new tg);Ie(this,"activeBlockId","");Ie(this,"activePageIndex",1);Ie(this,"currentDocId","");Ie(this,"bridge",null);t&&(this.bridge=t)}setBridge(t){this.bridge=t}setDocId(t){this.currentDocId=t,t&&this.blockToPageMap.delete(t)}updateSlidesIndex(t){this.blockToPageMap.clear();for(const o of t){o.startBlockId&&o.startBlockId!==this.currentDocId&&this.blockToPageMap.set(o.startBlockId,o.pageIndex);for(const i of o.blocks)this.blockToPageMap.set(i.id,o.pageIndex)}}getPageByBlockId(t){return this.blockToPageMap.get(t)??null}onCursorFocusBlock(t){if(!t||t===this.activeBlockId)return;if(this.activeBlockId=t,t===this.currentDocId){this.debounceCtrl.cancel("cursor-navigate");return}const o=this.getPageByBlockId(t);if(!o){this.debounceCtrl.cancel("cursor-navigate");return}this.debounceCtrl.debounce("cursor-navigate",()=>{this.activePageIndex=o,this.bridge&&(this.bridge.navigatePage(o),this.bridge.highlightElement(t))},100)}getActiveBlockId(){return this.activeBlockId}setActiveBlockId(t){this.activeBlockId=t,t||this.debounceCtrl.cancel("cursor-navigate");const o=this.getPageByBlockId(t);o&&(this.activePageIndex=o)}getActivePageIndex(){return this.activePageIndex}destroy(){this.debounceCtrl.cancelAll(),this.blockToPageMap.clear(),this.bridge=null}}let Rt=null,Sn=null,Cn="";function qi(){var e,t;if(Sn&&(clearTimeout(Sn),Sn=null),Rt){try{Rt.classList.remove("protyle-wysiwyg--select"),Cn?Rt.style.outline=Cn:typeof((e=Rt.style)==null?void 0:e.removeProperty)=="function"?Rt.style.removeProperty("outline"):Rt.style&&(Rt.style.outline=""),typeof((t=Rt.style)==null?void 0:t.removeProperty)=="function"?Rt.style.removeProperty("transition"):Rt.style&&(Rt.style.transition="")}catch(o){console.warn("[SelectionMirror] clear activeHighlightEl failed:",o)}Rt=null,Cn=""}if(typeof document<"u"&&typeof document.querySelectorAll=="function")try{document.querySelectorAll(".protyle-wysiwyg [data-node-id].protyle-wysiwyg--select, .protyle-wysiwyg [data-node-id][style*='outline']").forEach(i=>{var s,l;i.classList.remove("protyle-wysiwyg--select");const n=((s=i.style)==null?void 0:s.outline)||"";(n.includes("#3b82f6")||n.includes("rgb(59, 130, 246)")||n.includes("59, 130, 246"))&&(typeof((l=i.style)==null?void 0:l.removeProperty)=="function"?(i.style.removeProperty("outline"),i.style.removeProperty("transition")):i.style&&(i.style.outline="",i.style.transition=""))})}catch{}}function zo(e,t){var l,r,a,c;if(!e||typeof document>"u")return qi(),!1;qi();const o=(l=globalThis.CSS)!=null&&l.escape?globalThis.CSS.escape(e):e.replace(/"/g,'\\"'),i=document.querySelector(`.protyle-wysiwyg [data-node-id="${o}"]`)||document.querySelector(`[data-node-id="${o}"]`);if(!i){if(t)try{return ie.openTab({app:t,doc:{id:e,action:["cb-get-hl","cb-get-focus","cb-get-context"]}}),!0}catch(u){console.warn("[SelectionMirror] openTab fallback failed:",u)}return!1}try{i.scrollIntoView({behavior:"smooth",block:"center",inline:"nearest"})}catch{(r=i.scrollIntoView)==null||r.call(i)}try{(a=i.focus)==null||a.call(i,{preventScroll:!0})}catch{}const n=((c=i.style)==null?void 0:c.outline)||"";return Cn=n.includes("#3b82f6")||n.includes("rgb(59, 130, 246)")||n.includes("59, 130, 246")?"":n,i.classList.add("protyle-wysiwyg--select"),i.style&&(i.style.outline="2px solid #3b82f6",i.style.transition="outline 0.2s ease"),Rt=i,Sn=setTimeout(()=>{qi()},500),!0}function Ta(e){var i,n,s;const t=typeof document<"u"?document:null,o=e||t;if(!o&&!t)return!1;try{const l=(typeof(o==null?void 0:o.querySelectorAll)=="function"?o.querySelectorAll(".protyle-wysiwyg--select"):null)||(typeof(t==null?void 0:t.querySelectorAll)=="function"?t.querySelectorAll(".protyle-wysiwyg--select"):[]);if(l&&l.length>1){const r=new Set;for(let a=0;a<l.length;a++){const c=l[a],u=typeof c.closest=="function"?c.closest("[data-node-id]"):c,f=(i=u==null?void 0:u.getAttribute)==null?void 0:i.call(u,"data-node-id");f?r.add(f):r.add(`elem-${a}`)}if(r.size>1)return!0}}catch{}try{const l=typeof window<"u"?window:globalThis.window,r=typeof(l==null?void 0:l.getSelection)=="function"?l.getSelection():null;if(r&&r.rangeCount>0&&!r.isCollapsed&&typeof r.getRangeAt=="function"){const a=r.getRangeAt(0);if(a){const c=a.startContainer,u=a.endContainer;if(c&&u&&c!==u){const f=c.nodeType===1?c:c.parentElement,h=u.nodeType===1?u:u.parentElement,d=typeof(f==null?void 0:f.closest)=="function"?f.closest("[data-node-id]"):null,b=typeof(h==null?void 0:h.closest)=="function"?h.closest("[data-node-id]"):null,m=(n=d==null?void 0:d.getAttribute)==null?void 0:n.call(d,"data-node-id"),y=(s=b==null?void 0:b.getAttribute)==null?void 0:s.call(b,"data-node-id");if(m&&y&&m!==y)return!0}}}}catch{}return!1}function ig(e){if(!e)return"";const t=e.split(`
`).map(l=>l.trim()).filter(Boolean);if(t.length===0)return"";if(!t.some(l=>/^#{1,6}\s+/.test(l)))return t.map(l=>ut(l)).join("<br/>");const i=[];let n=[];const s=()=>{if(n.length>0){const l=n.map(r=>ut(r)).join("<br/>");i.push(`<p class="slide-list-item-desc">${l}</p>`),n=[]}};for(const l of t){const r=l.match(/^(#{1,6})\s+(.*)$/);if(r){s();const a=r[1].length,c=r[2].trim();i.push(`<h${a} class="slide-list-item-title">${ut(c)}</h${a}>`)}else n.push(l)}return s(),i.join(`
`)}function ng(e){if(e.length===0)return"";const t=[],o=e[0],i=o.match(/^(#{1,6})\s+(.*)$/);if(i){const n=i[1].length,s=i[2].trim();t.push(`<h${n} class="slide-list-item-title">${ut(s)}</h${n}>`)}else t.push(`<p class="slide-list-item-title">${ut(o)}</p>`);if(e.length>1){const n=e.slice(1);let s=[];const l=()=>{if(s.length>0){const r=s.map(a=>ut(a)).join("<br/>");t.push(`<p class="slide-list-item-desc">${r}</p>`),s=[]}};for(const r of n){const a=r.match(/^(#{1,6})\s+(.*)$/);if(a){l();const c=a[1].length,u=a[2].trim();t.push(`<h${c} class="slide-list-item-title">${ut(u)}</h${c}>`)}else s.push(r)}l()}return t.join(`
`)+(t.length>0?`
`:"")}function uc(e,t,o){var h,d,b,m;const i=e.split(`
`);if(!i.some(y=>/^(\s*)([-*+]|\d+\.)\s+/.test(y)))return(o!=null&&o.isListItem||(o==null?void 0:o.type)==="i")&&!(o!=null&&o.isColFirst)?`<ul class="slide-list slide-list--unordered">
<li class="slide-list-item">${ut(e)}</li>
</ul>`:null;const s=[],l=[];let r=!1;for(let y=0;y<i.length;y++){const g=i[y];if(!g.trim())continue;const x=g.match(/^(\s*)[-*+]\s+\[([ xX])\]\s+(.*)$/);if(x){const w=x[1].length,C=Math.floor(w/2);l.push({type:"task",level:C,checked:x[2].toLowerCase()==="x",text:x[3],media:[]});continue}const k=g.match(/^(\s*)[-*+]\s+(.*)$/);if(k){const w=k[1].length,C=Math.floor(w/2);l.push({type:"unordered",level:C,text:k[2],media:[]});continue}const I=g.match(/^(\s*)\d+\.\s+(.*)$/);if(I){l.length===0&&(r=!0);const w=I[1].length,C=Math.floor(w/2);l.push({type:"ordered",level:C,text:I[2],media:[]});continue}const T=g.trim();if(!(!T||/^\{:.*?\}$/.test(T)))if(l.length>0){const w=T.match(/^!\[(.*?)\]\((.*?)\)(?:\{:?[^}]*\})?$/);if(w){const R=/\.gif(?:\?|$)/i.test(w[2])?"list-item-gif":"list-item-img";l[l.length-1].media||(l[l.length-1].media=[]),l[l.length-1].media.push(`<div class="slide-list-media"><img alt="${nt(w[1])}" src="${w[2]}" class="${R}" /></div>`);continue}if(T.match(/^<img\b[\s\S]*?\/?>$/i)){const L=T.replace(/\s+style="[^"]*"/gi,"");l[l.length-1].media||(l[l.length-1].media=[]),l[l.length-1].media.push(`<div class="slide-list-media">${L}</div>`);continue}if(/<video\b/i.test(T)){let L=T;if(!/<\/video>/i.test(L))for(;y+1<i.length&&!/<\/video>/i.test(L);)y++,L+=" "+i[y].trim();const R=((h=o==null?void 0:o.attributes)==null?void 0:h["custom-slides-autoplay"])==="true"||/autoplay/i.test(L),N=((d=o==null?void 0:o.attributes)==null?void 0:d["custom-slides-loop"])==="true"||/loop/i.test(L),F=((b=o==null?void 0:o.attributes)==null?void 0:b["custom-slides-muted"])==="true"||R||/muted/i.test(L),E=((m=o==null?void 0:o.attributes)==null?void 0:m["custom-slides-controls"])==="false",O=L.match(/\bsrc=["']([^"']+)["']/i),S=O?O[1]:"",W=['class="slide-video-player"'];E||W.push("controls"),R&&(W.push("autoplay"),W.push("playsinline")),N&&W.push("loop"),F&&W.push("muted"),W.push('preload="metadata"'),S&&W.push(`src="${S}"`);const j=L.match(/<video[^>]*>([\s\S]*?)<\/video>/i);let _=j?j[1].trim():"";!_&&S&&(_=`<source src="${S}" type="video/mp4" />您的浏览器不支持视频播放。`),l[l.length-1].media||(l[l.length-1].media=[]),l[l.length-1].media.push(`<div class="slide-list-media slide-video-container slide-media-container" data-autoplay="${R?"true":"false"}" data-muted="${F?"true":"false"}"><video ${W.join(" ")}>${_}</video></div>`);continue}l[l.length-1].text+=`
`+T}else s.push(T)}if(l.length===0)return null;const a=r?"ol":"ul",c=(t==null?void 0:t.listClassName)||(r?"pdf-list pdf-list--ordered":"pdf-list pdf-list--unordered"),u=l.map(y=>{const g=ig(y.text),x=y.media&&y.media.length>0?`
${y.media.join(`
`)}`:"",k=y.level||0,I=k>0?` style="margin-left:${(k*1.25).toFixed(2)}em;${y.type==="unordered"?`list-style-type:${k%2===1?"circle":"square"} !important;`:""}"`:"",T=k>0?" slide-list-item--nested":"";if(y.type==="task"){const C=y.checked?' checked=""':"";return`<li class="pdf-task-item${T}"${I}><label><input type="checkbox" disabled=""${C}/> <span>${g}</span></label>${x}</li>`}return`<li${T?` class="${T.trim()}"`:""}${I}>${g}${x}</li>`}).join(`
`);return`${ng(s)}<${a} class="${c}">
${u}
</${a}>`}function sg(e,t,o){const i=(t==null?void 0:t.containerClassName)||"pdf-block",n=e.split(/\r?\n/),s=[];let l=[];for(let c=0;c<n.length;c++){const u=n[c],f=u.trim();if(/^#{1,6}\s+/.test(f)){l.length>0&&(s.push(l.join(`
`)),l=[]),s.push(f);continue}if(!f){l.length>0&&(s.push(l.join(`
`)),l=[]);continue}if(/^!\[.*?\]\(.*?\)$/.test(f)){l.length>0&&(s.push(l.join(`
`)),l=[]),s.push(f);continue}if(/<video\b/i.test(f)){l.length>0&&(s.push(l.join(`
`)),l=[]);let h=f;if(!/<\/video>/i.test(h))for(;c+1<n.length&&!/<\/video>/i.test(h);)c++,h+=`
`+n[c];s.push(h);continue}l.push(u)}l.length>0&&s.push(l.join(`
`));let r=!0;return s.map(c=>{var b,m,y,g;const u=c.trim();if(!u)return"";const f=u.match(/^(#{1,6})\s+(.*)$/);if(f){r=!1;const x=f[1].length;return`<h${x} class="slide-list-item-title">${ut(f[2].trim())}</h${x}>`}const h=u.match(/^!\[(.*?)\]\((.*?)\)$/);if(h){const x=/\.gif(?:\?|$)/i.test(h[2]),k=(t==null?void 0:t.imageClassName)||(x?"list-item-gif":"pdf-image slide-media-img");return`<div class="${i} ${i}--image slide-media-block slide-media-container slide-list-media"><img alt="${nt(h[1])}" src="${h[2]}" class="${k}" /></div>`}if(/<video\b/i.test(u)){const x=((b=o==null?void 0:o.attributes)==null?void 0:b["custom-slides-autoplay"])==="true"||/autoplay/i.test(u),k=((m=o==null?void 0:o.attributes)==null?void 0:m["custom-slides-loop"])==="true"||/loop/i.test(u),I=((y=o==null?void 0:o.attributes)==null?void 0:y["custom-slides-muted"])==="true"||x||/muted/i.test(u),T=((g=o==null?void 0:o.attributes)==null?void 0:g["custom-slides-controls"])==="false",w=u.match(/\bsrc=["']([^"']+)["']/i),C=w?w[1]:"",L=['class="slide-video-player"'];T||L.push("controls"),x&&L.push("autoplay playsinline"),k&&L.push("loop"),I&&L.push("muted"),L.push('preload="metadata"'),C&&L.push(`src="${C}"`);const R=u.match(/<video[^>]*>([\s\S]*?)<\/video>/i);let N=R?R[1].trim():"";return!N&&C&&(N=`<source src="${C}" type="video/mp4" />您的浏览器不支持视频播放。`),`<div class="${i} ${i}--video slide-media-block slide-video-container slide-media-container" data-autoplay="${x?"true":"false"}" data-muted="${I?"true":"false"}"><video ${L.join(" ")}>${N}</video></div>`}const d=uc(u,t,o);if(d)return r=!1,d;if(r){r=!1;const x=u.split(/\r?\n/).map(w=>w.trim()).filter(Boolean);if(x.length===1)return`<p class="slide-list-item-title">${ut(x[0])}</p>`;const k=x[0],T=x.slice(1).map(w=>ut(w)).join("<br/>");return`<p class="slide-list-item-title">${ut(k)}</p>
<p class="slide-list-item-desc">${T}</p>`}return`<p class="slide-list-item-desc">${ut(u)}</p>`}).filter(Boolean).join(`
`)}function mn(e){if(!e)return!1;if(e.type==="h"||e.type==="NodeHeading")return!0;const t=(e.rawMarkdown||e.content||"").trim();return/^#{1,6}\s+/.test(t)}function fc(e,t){var r,a,c,u,f,h,d,b,m,y,g,x;const o=((r=e.frontmatter)==null?void 0:r.layout)||"default",n=(e.blocks||[]).filter(k=>k.slot!=="slot-divider-right"),l=o==="cover"?null:n.find(mn);if(o==="two-cols"){const k=n.some(W=>W.slot==="right");let I=[],T=[];if(k)I=n.filter(W=>W.slot!=="right"),T=n.filter(W=>W.slot==="right");else{const W=Math.ceil(n.length/2);I=n.slice(0,W),T=n.slice(W)}const w=W=>{const j=W.filter(_=>!!(_.rawMarkdown||_.content||"").trim());if(j.length>0){const _=j[0],M=(_.rawMarkdown||_.content||"").trim();(Uo(_)||/^(?:[-*+]|\d+\.)\s+/.test(M))&&(_.rawMarkdown=Ft(_.rawMarkdown||_.content||""),_.content=_.rawMarkdown)}};w(I),w(T);const C=I.map(W=>St(W,t)).join(`
`),L=T.map(W=>St(W,t)).join(`
`),R=(t==null?void 0:t.twoColsWrapperClass)||"pdf-two-cols-wrapper layout-two-cols-grid",N=(a=e.frontmatter)!=null&&a.layoutClass?` ${e.frontmatter.layoutClass}`:"",F=(t==null?void 0:t.leftColClass)||"pdf-col pdf-col--left",E=(t==null?void 0:t.rightColClass)||"pdf-col pdf-col--right",S=`style="grid-template-columns: ${ks((c=e.frontmatter)==null?void 0:c.layoutRatio,2)};"`;return`
      <div class="${R}${N}" ${S}>
        <div class="${F}">${C}</div>
        <div class="${E}">${L}</div>
      </div>
    `}if(o==="clover"||pi(o)){const k=o==="clover";let I=[];const T=n.filter(B=>B.slot==="header");if(T.length>0)I=T;else if(n.length>0){const B=n.find(Q=>Q.type==="h"&&(!Q.slot||Q.slot==="default"));B&&(I=[B])}const w=n.filter(B=>!I.includes(B));let C=2;if(k)C=4;else if(o==="three-cols-header")C=3;else if(o==="two-cols-header")C=2;else{let B=0;for(const Q of w){const q=(Q.slot||"").match(/^col-(\d+)$/i);q&&(B=Math.max(B,parseInt(q[1],10)))}if(B>=2)C=B;else if((u=e.frontmatter)!=null&&u.layoutRatio){const Q=e.frontmatter.layoutRatio.trim();if(Q.includes(":")){const q=Q.split(":").map(U=>parseFloat(U.trim())).filter(U=>!isNaN(U)&&U>0);q.length>=2&&(C=q.length)}else{const q=Q.split(/\s+/).filter(Boolean);q.length>=2&&(C=q.length)}}else w.length===1&&w[0].children&&w[0].children.length>=2&&(C=Math.min(6,w[0].children.length))}const L=Ks(w,C),R=w.some(B=>B.slot&&/^(?:col-\d+|left|right)$/i.test(B.slot)),N=o==="clover"||o==="two-cols-header"||o==="three-cols-header"||pi(o)&&R,F=B=>{const Q=B.filter(U=>!!(U.rawMarkdown||U.content||"").trim());if(N&&Q.length>0){const U=Q[0],ne=(U.rawMarkdown||U.content||"").trim();(Uo(U)||/^(?:[-*+]|\d+\.)\s+/.test(ne))&&(U.rawMarkdown=Ft(U.rawMarkdown||U.content||""),U.content=U.rawMarkdown),U.isColFirst=!0}const q=N?Q.find(mn):null;return Q.map(U=>St(U,{...t,extraClassName:U===q?"slides-col-first-heading-block":""})).join(`
`)},E=I.find(mn),O=I.map(B=>St(B,{...t,extraClassName:B===E?"slides-page-first-heading-block":""})).join(`
`),S=k?"repeat(2, minmax(0, 1fr))":ks((f=e.frontmatter)==null?void 0:f.layoutRatio,C),W=k?`style="grid-template-columns: ${S}; grid-template-rows: repeat(2, minmax(0, 1fr));"`:`style="grid-template-columns: ${S};"`,j=[k?"layout-clover-container":"layout-cols-header-container",C===2?"layout-two-cols-header-container":"",C===3?"layout-three-cols-header-container":"",`layout-${o}-container`,N?"has-superblock-cols":""].filter(Boolean).join(" "),_=[k?"layout-clover-grid pdf-clover-wrapper":"layout-cols-wrapper layout-cols-grid",C===2?"pdf-two-cols-wrapper layout-two-cols-grid":"",C===3?"pdf-three-cols-wrapper layout-three-cols-grid":"",N?"has-superblock-cols":""].filter(Boolean).join(" "),M=L.map((B,Q)=>{const q=Q+1;return`<div class="${["pdf-col",C===2&&q===1?"pdf-col--left":"",C===2&&q===2?"pdf-col--right":"",`pdf-col--${q}`,`col-${q}`].filter(Boolean).join(" ")}">${F(B)}</div>`}).join(`
`);return`
      <div class="${j}">
        <div class="layout-header-section">${O}</div>
        <div class="${_}" ${W}>
          ${M}
        </div>
      </div>
    `}if(o==="image-right"||o==="image-left"){const k=o==="image-right",I=n.map(N=>St(N,t)).join(`
`),T=((h=e.frontmatter)==null?void 0:h.image)||((d=e.frontmatter)==null?void 0:d.background)||"",w=`<div class="pdf-image-col" style="background-image:url('${nt(T)}');background-size:cover;background-position:center;background-repeat:no-repeat;width:100%;height:100%;position:relative;overflow:hidden;"><img src="${nt(T)}" style="width:100%;height:100%;object-fit:cover;object-position:center;display:block;" onerror="this.style.display='none'" alt="Slide cover" /></div>`,C=`<div class="pdf-content-col" style="padding:48px 56px;display:flex;flex-direction:column;justify-content:flex-start;height:100%;box-sizing:border-box;overflow-y:auto;">${I}</div>`,L=k?`${C}
${w}`:`${w}
${C}`;return`
      <div class="layout-image-cols-grid" style="display:grid;grid-template-columns:${ks((b=e.frontmatter)==null?void 0:b.layoutRatio,2)};grid-template-rows:100%;width:100%;height:100%;position:absolute;top:0;left:0;right:0;bottom:0;box-sizing:border-box;">
        ${L}
      </div>
    `}if(o==="fact"){const k=n.filter(S=>!!(S.rawMarkdown||S.content||"").trim());let I=[];const T=k.filter(S=>S.slot==="header"),w=k.length>=2&&mn(k[0]),C=k.length>=2&&(k[1].type==="l"||((m=k[1].children)==null?void 0:m.length)||/^(\s*)(?:[-*+]|\d+\.)\s+/m.test(k[1].rawMarkdown||""));T.length>0?I=T:w&&(C||k.length>=3)&&(I=[k[0]]);const L=k.filter(S=>!I.includes(S)),R=I.map(S=>St(S,{...t,extraClassName:"slides-page-first-heading-block"})).join(`
`),N=[],F=[];if(L.length===1&&L[0].children&&L[0].children.length>=1)for(const S of L[0].children)F.push((S.rawMarkdown||S.content||"").trim());else if(L.length===1){const S=(L[0].rawMarkdown||L[0].content||"").trim().split(/\r?\n/);if(S.some(j=>/^(\s*)(?:[-*+]|\d+\.)\s+/.test(j)))for(const j of S)/^(\s*)(?:[-*+]|\d+\.)\s+/.test(j)&&F.push(j.trim())}if(F.length>0)for(const S of F){const W=Ft(S).trim(),j=W.match(/^([^\n:：]+?)(?:\s*[:：]\s*)([\s\S]+)$/);if(j)N.push({value:j[1].trim(),label:j[2].trim()});else{const _=W.split(/\r?\n/);N.push({value:_[0].trim(),label:_.slice(1).join(`
`).trim()})}}else if(L.length>=2){if(L.every(W=>/[:：]/.test(Ft(W.rawMarkdown||W.content||""))))for(const W of L){const j=Ft(W.rawMarkdown||W.content||"").trim(),_=j.match(/^([^\n:：]+?)(?:\s*[:：]\s*)([\s\S]+)$/);_?N.push({value:_[1].trim(),label:_[2].trim()}):N.push({value:j,label:""})}else if(L.length%2===0)for(let W=0;W<L.length;W+=2)N.push({value:Ft(L[W].rawMarkdown||L[W].content||"").trim(),label:Ft(L[W+1].rawMarkdown||L[W+1].content||"").trim()})}if(N.length===0&&L.length>0){const S=Ft(L[0].rawMarkdown||L[0].content||"").trim(),W=S.match(/^([^\n:：]+?)(?:\s*[:：]\s*)([\s\S]+)$/);if(W)N.push({value:W[1].trim(),label:W[2].trim()});else{const j=L.slice(1).map(_=>Ft(_.rawMarkdown||_.content||"").trim()).join(`
`);N.push({value:S,label:j})}}const E=Math.max(1,Math.min(4,N.length)),O=N.map(S=>{const W=St({id:"val",type:"p",rawMarkdown:S.value,content:S.value},t),j=S.label?St({id:"lbl",type:"p",rawMarkdown:S.label,content:S.label},t):"";return`
        <div class="fact-stat-card">
          <div class="fact-value-wrapper fact-value-box">${W}</div>
          ${j?`<div class="fact-divider-line"></div><div class="fact-label-wrapper fact-label-box">${j}</div>`:""}
        </div>
      `}).join(`
`);return`
      <div class="layout-fact-container layout-fact-cols-${E}">
        <div class="fact-hero-glow" aria-hidden="true"></div>
        ${R?`<div class="layout-header-section">${R}</div>`:""}
        <div class="fact-content-box fact-stats-grid fact-stats-grid--cols-${E}">
          ${O}
        </div>
      </div>
    `}if(o==="timeline"||o==="steps"){let k=[];const I=n.filter(N=>N.slot==="header");if(I.length>0)k=I;else if(n.length>0){const N=n.find(F=>F.type==="h"&&(!F.slot||F.slot==="default"));N&&(k=[N])}const T=n.filter(N=>!k.includes(N)),w=k.map(N=>St(N,{...t,extraClassName:"slides-page-first-heading-block"})).join(`
`);let C=[];if(T.length===1&&T[0].children&&T[0].children.length>=2)C=T[0].children;else if(T.length>=2)C=T;else if(T.length===1){const F=(T[0].rawMarkdown||T[0].content||"").trim().split(`
`).filter(E=>/^(\s*)([-*+]|\d+\.)\s+/.test(E));F.length>=2?C=F.map((E,O)=>({id:`${T[0].id}-step-${O}`,type:"p",rawMarkdown:E.replace(/^(\s*)([-*+]|\d+\.)\s+/,"").trim(),content:E.replace(/^(\s*)([-*+]|\d+\.)\s+/,"").trim()})):C=T}const L=Math.max(1,Math.min(6,C.length)),R=C.map((N,F)=>{const E=F+1,O=St(N,t);return`
        <div class="timeline-step-item" style="--step-index: ${E};">
          <div class="timeline-node-container">
            <div class="timeline-node-badge">${E}</div>
            ${E<C.length?'<div class="timeline-connector-line"></div>':""}
          </div>
          <div class="timeline-step-content">${O}</div>
        </div>
      `}).join(`
`);return`
      <div class="layout-timeline-container layout-steps-container">
        ${w?`<div class="layout-header-section">${w}</div>`:""}
        <div class="timeline-track-wrapper" style="--timeline-steps: ${L};">
          ${R}
        </div>
      </div>
    `}if(o==="quote"){const k=n.filter(L=>!!(L.rawMarkdown||L.content||"").trim());let I=k,T=null;if(k.length>=2){const L=k[k.length-1],R=(L.rawMarkdown||L.content||"").trim();(/^(?:—|--|——|-)\s*/.test(R)||((y=L.ial)==null?void 0:y["custom-slides-role"])==="author")&&(T=L,I=k.slice(0,-1))}const w=I.map(L=>St(L,{...t,extraClassName:"quote-body"})).join(`
`),C=T?St(T,{...t,extraClassName:"quote-author"}):"";return`
      <div class="layout-quote-container">
        <div class="quote-watermark-icon" aria-hidden="true">“</div>
        <div class="quote-content-body">
          <div class="quote-text">${w}</div>
          ${C?`<div class="quote-footer">${C}</div>`:""}
        </div>
      </div>
    `}if(o==="intro"){const k=((g=e.frontmatter)==null?void 0:g.image)||((x=e.frontmatter)==null?void 0:x.background)||"",T=n.filter(C=>{const L=(C.rawMarkdown||C.content||"").trim();return!(k&&L.includes(k))}).map(C=>St(C,t)).join(`
`);return`
      <div class="layout-intro-container">
        <div class="intro-avatar-col">${k?`<div class="intro-avatar-box"><img class="intro-avatar-img" src="${nt(k)}" alt="Avatar" onerror="this.style.display='none'" /></div>`:'<div class="intro-avatar-box intro-avatar-box--placeholder"><svg class="intro-avatar-svg" viewBox="0 0 24 24" fill="currentColor"><path d="M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z"/></svg></div>'}</div>
        <div class="intro-info-col">${T}</div>
      </div>
    `}return o==="center"?`<div class="layout-center-container">${n.map(I=>St(I,t)).join(`
`)}</div>`:o==="cover"?`<div class="layout-cover-container">${n.map(I=>St(I,t)).join(`
`)}</div>`:n.map(k=>St(k,{...t,extraClassName:k===l?"slides-page-first-heading-block":""})).join(`
`)}function nt(e){return e?e.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&#039;"):""}function rg(e){if(!e||e.trim()===""||e.trim()==="all")return"all";const t=new Set,o=e.split("|");for(const i of o){const n=i.trim();if(n==="all")return"all";if(n.includes("-")){const[s,l]=n.split("-"),r=parseInt(s,10),a=parseInt(l,10);if(!isNaN(r)&&!isNaN(a))for(let c=Math.min(r,a);c<=Math.max(r,a);c++)t.add(c)}else{const s=parseInt(n,10);isNaN(s)||t.add(s)}}return t}const ag=new Set(["kbd","mark","sub","sup","span","a","br","b","i","u","s","del","em","strong","code","small","abbr","ruby","rt","rp","v-mark","img","video","source","picture"]);function ut(e){if(!e)return"";const t=ic(e),o=[],i=t.replace(/<\/?([a-zA-Z0-9_-]+)(?:\s+[^<>]*)?\/?>/g,(s,l)=>{const r=l.toLowerCase();if(!ag.has(r)||/on\w+\s*=|javascript:/i.test(s))return s;if(r==="v-mark"){const a=s.match(/type=["']?([a-zA-Z-]+)["']?/),c=a?a[1]:"circle";return s.startsWith("</")?o.push("</mark>"):o.push(`<mark class="v-mark v-mark--${c}">`),`%%SAFE_HTML_${o.length-1}%%`}return o.push(s),`%%SAFE_HTML_${o.length-1}%%`});let n=nt(i);return n=n.replace(/\(\(([0-9a-zA-Z-]+)(?:\s*(?:&#039;([^&#]*)&#039;|&quot;([^&]*)&quot;|'([^']*)'|"([^"]*)"|([^\)]+?)))?\s*\)\)/g,(s,l,r,a,c,u,f)=>{const d=(r??a??c??u??f??"").trim()||`Ref(${l.slice(0,8)})`;return`<a href="siyuan://blocks/${l}" data-ref-id="${l}" class="slides-ref-tag">🔗 ${d}</a>`}),n=n.replace(/\$([^$\n]+)\$/g,'<span class="katex-inline font-math"><em>$1</em></span>'),n=n.replace(/!\[(.*?)\]\((.*?)\)/g,(s,l,r)=>{const c=/\.gif(?:\?|$)/i.test(r)?"slide-inline-img list-item-gif":"slide-inline-img";return`<img alt="${l}" src="${r}" class="${c}" />`}),n=n.replace(/\[(.*?)\]\((.*?)\)/g,(s,l,r)=>{if(r.startsWith("siyuan://blocks/")){const a=r.replace("siyuan://blocks/","").split("?")[0];return`<a href="${r}" data-ref-id="${a}" class="slides-ref-tag">🔗 ${l}</a>`}return`<a href="${r}" target="_blank" rel="noopener noreferrer" class="slides-link">${l}</a>`}),n=n.replace(/(^|[\s(])(siyuan:\/\/blocks\/([0-9a-zA-Z-]+)(?:\?[^\s\)]*)?)/g,(s,l,r,a)=>`${l}<a href="${r}" data-ref-id="${a}" class="slides-ref-tag">🔗 ${r}</a>`),n=n.replace(/\*\*(.*?)\*\*/g,"<strong>$1</strong>"),n=n.replace(/\*(.*?)\*/g,"<em>$1</em>"),n=n.replace(/~~(.*?)~~/g,"<del>$1</del>"),n=n.replace(/`([^`]+)`/g,"<code>$1</code>"),n=n.replace(/%%SAFE_HTML_(\d+)%%/g,(s,l)=>{const r=parseInt(l,10);return o[r]||""}),n}function lg(e,t="pdf-table"){if(e.length<2)return"";const o=e.map(a=>a.trim().replace(/^\|/,"").replace(/\|$/,"").split("|").map(c=>c.trim())),i=o[0];let n=[],s=1;e.length>=2&&o[1].every(a=>/^:?-+:?$/.test(a))&&(n=o[1].map(a=>a.startsWith(":")&&a.endsWith(":")?"center":a.endsWith(":")?"right":"left"),s=2);const l=`<thead><tr>${i.map((a,c)=>`<th${n[c]?` style="text-align: ${n[c]}"`:""}>${ut(a)}</th>`).join("")}</tr></thead>`,r=o.slice(s).map(a=>`<tr>${a.map((c,u)=>`<td${n[u]?` style="text-align: ${n[u]}"`:""}>${ut(c)}</td>`).join("")}</tr>`).join("");return`<table class="${t}">${l}<tbody>${r}</tbody></table>`}function xs(e){return String(e||"").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;")}function Aa(e,t="ts"){if(!e)return"";if(e.trim().startsWith("//"))return`<span class="token-comment">${xs(e)}</span>`;const o=[];function i(s,l){return o.push(`<span class="${s}">${xs(l)}</span>`),`__TOK_${o.length-1}__`}let n=e.replace(/(['"`])(.*?)\1/g,(s,l,r)=>i("token-string",`${l}${r}${l}`));return n=n.replace(/\b(import|export|from|const|let|var|function|return|default|type|interface|class|new|async|await)\b/g,s=>i("token-keyword",s)),n=n.replace(/\b(computed|ref|number|string|boolean|void|Array)\b/g,s=>i("token-type",s)),n=n.replace(/\b(\d+)\b/g,s=>i("token-number",s)),n=xs(n),n=n.replace(/__TOK_(\d+)__/g,(s,l)=>o[parseInt(l,10)]||""),n}function cg(e,t){if(!e)return null;const o=e.frontmatter||{};if(o.hideInToc===!0||o.hideInToc==="true")return null;let i=(o.title||"").trim(),n=o.level?parseInt(o.level,10):0;if(!i){const s=e.blocks||[];for(const l of s){const a=(l.rawMarkdown||l.content||"").trim().match(/^(#{1,6})\s+(.*)$/);if(a){n||(n=a[1].length),i=a[2].trim();break}}}return i?((!n||isNaN(n))&&(n=1),{pageIndex:e.pageIndex||t,title:i,level:n}):null}function dg(e,t=1,o={}){const i=o.minDepth!==void 0?Number(o.minDepth):1,n=o.maxDepth!==void 0?Number(o.maxDepth):1/0,s=[];Array.isArray(e)&&e.forEach((c,u)=>{const f=cg(c,u+1);f&&s.push(f)});const l=[];let r=null;for(const c of s){const u={...c,active:c.pageIndex===t,hasActiveChild:!1,children:[]};c.level===1||l.length===0?(l.push(u),r=u):r?(u.active&&(r.hasActiveChild=!0),r.children.push(u)):l.push(u)}function a(c,u=1){if(u>n)return[];const f=[];for(const h of c){const d=a(h.children,u+1);u>=i?f.push({...h,children:d}):f.push(...d)}return f}return a(l,1)}function ug(e,t=1,o={}){const i=dg(e,t,o),n=o.columns?Number(o.columns):1,s=n>1?` style="column-count: ${n};"`:"",l=o.textSm?" text-sm":"";function r(c,u=1){if(!c||c.length===0)return"";const f=`slides-toc-list slides-toc-list-level-${u}`,h=c.map(d=>{const b=d.active?" slides-toc-item-active":d.hasActiveChild?" slides-toc-item-parent-active":"",m=d.children&&d.children.length>0?r(d.children,u+1):"";let y=ut(d.title);return y.includes("LaTeX")&&(y=y.replace(/\$\\LaTeX\$/g,'<span class="font-math">L<sup>A</sup>T<sub>E</sub>X</span>')),`
        <li class="slides-toc-item${b}" data-page="${d.pageIndex}">
          <a class="slides-toc-link" href="javascript:void(0)">
            <span class="slides-toc-title">${y}</span>
          </a>
          ${m}
        </li>
      `}).join("");return`<ol class="${f}">${h}</ol>`}const a=r(i,1);return`<div class="slides-toc${l}"${s}>${a}</div>`}function St(e,t){var T,w,C,L,R,N,F,E,O,S,W,j;let o="",i="",n="";const s=[];(T=e.motion)!=null&&T.preset&&e.motion.preset!=="none"&&(o=` slides-motion-${e.motion.preset.toLowerCase()}`,typeof e.motion.duration=="number"&&e.motion.duration>0&&s.push(`--motion-duration:${e.motion.duration}ms`),typeof e.motion.delay=="number"&&e.motion.delay>0&&s.push(`--motion-delay:${e.motion.delay}ms`));const l=((w=e.attributes)==null?void 0:w.style)||"";l&&(s.push(l),n=" slide-styled-block"),s.length>0&&(i=` style="${nt(s.join(";"))}"`);const r=(t==null?void 0:t.containerClassName)||"pdf-block",a=t!=null&&t.extraClassName?` ${t.extraClassName}`:"",c=t!=null&&t.blockClassResolver?t.blockClassResolver(e):"",u=c?` ${c}`:"",f=`${r}${o}${n}${a}${u}`,h=(e.rawMarkdown||e.content||"").trim();if(!h)return`<div class="${f}"${i}></div>`;if(h.includes('class="slides-block-ref"')||h.includes('class="slides-ref-tag"'))return`<div class="${f}"${i}>${h}</div>`;if(h.startsWith("$$")&&h.endsWith("$$")){const _=h.slice(2,-2).trim();return`<div class="${f} katex-display-container"${i}><div class="katex-display font-math"><em>${nt(_)}</em></div></div>`}const d=h.match(/^(#{1,6})\s+(.*)$/);if(d){const _=d[1].length,M=ut(d[2]),Q=!!(e.isColFirst||e.type==="i"&&((C=t==null?void 0:t.extraClassName)!=null&&C.includes("slides-col-first-heading-block")))?' class="slide-list-item-title"':"";return`<div class="${f}"${i}><h${_}${Q}>${M}</h${_}></div>`}if(h.startsWith(":::")){const _=h.split(`
`),B=_[0].replace(/^:::\s*/,"").trim()||"info",Q=_.slice(1,_[_.length-1].startsWith(":::")?-1:void 0).join(`
`),q=(t==null?void 0:t.calloutClassName)||"pdf-callout";return`<div class="${f}"${i}><div class="${q} ${q}--${B}"><div class="${q}-title">${B.toUpperCase()}</div><div class="${q}-body">${ut(Q)}</div></div></div>`}if(h.startsWith("<<<")){const B=`// Inside ./snippets/external.ts
export function emptyArray<T>(length: number) {
  return Array.from<T>({ length })
}`.split(`
`).map((oe,ae)=>`<span class="code-line shiki-focus"><span class="line-no">${ae+1}</span><span class="line-content">${Aa(oe,"ts")}</span></span>`).join(`
`),Q=(t==null?void 0:t.codeClassName)||"pdf-code shiki-container",q=((L=e.attrs)==null?void 0:L["custom-slides-max-height"])||((R=e.attributes)==null?void 0:R["custom-slides-max-height"])||e.maxHeight||"",U=Vs(String(q||"")),ne=U?` style="max-height:${nt(U)};overflow-y:auto;"`:"";return`<div class="${f}"${i}><pre class="${Q}"${ne}><span class="lang-badge">TS</span><code>${B}</code></pre></div>`}if(h.startsWith("<style")||h.startsWith("<!-- Inline style -->")||h.startsWith(`<!--
Notes`))return"";if(h.startsWith("```")){const _=h.split(`
`),M=_[0].slice(3).trim(),B=M.match(/^([^\s{\[]+)/),Q=B?B[1]:"",q=M.match(/\[([^\]]+)\]/),U=q?q[1]:"",ne=M.includes("twoslash"),oe=e.shikiLines||((N=M.match(/\{([^}]+)\}/))==null?void 0:N[1])||"",ae=rg(oe),Se=_.length>2?_[_.length-1]==="```"?_.slice(1,-1):_.slice(1):[h.slice(3).replace(/```$/,"")],$e=(t==null?void 0:t.codeClassName)||"pdf-code shiki-container",ke=U?`${$e} has-filename`:$e,Ce=ae!=="all",z=Se.map((H,$)=>{const A=$+1,Y=ae==="all"||ae.has(A)?"code-line shiki-focus":Ce?"code-line shiki-dimmed":"code-line";let Z=(t==null?void 0:t.highlight)===!0?Aa(H,Q):nt(H);return ne&&H.includes("doubled.value = 2")?(Z=Z.replace(/(\bvalue\b)/,'<span class="twoslash-error-wavy">$1</span>'),`<span class="${Y}"><span class="line-no">${A}</span><span class="line-content">${Z}</span></span>
<div class="twoslash-popup-error"><span style="color:#ef4444;font-weight:bold;margin-right:4px;">✕</span> Cannot assign to 'value' because it is a read-only property.</div>`):`<span class="${Y}"><span class="line-no">${A}</span><span class="line-content">${Z}</span></span>`}).join(`
`),se=Q?`<span class="lang-badge">${nt(Q)}</span>`:"",D=U?`<span class="code-filename">${nt(U)}</span>`:"",V=((F=e.attrs)==null?void 0:F["custom-slides-max-height"])||((E=e.attributes)==null?void 0:E["custom-slides-max-height"])||e.maxHeight||"",v=Vs(String(V||"")),K=v?` style="max-height:${nt(v)};overflow-y:auto;"`:"";return`<div class="${f}"${i}><pre class="${ke}"${K}>${D}${se}<code>${z}</code></pre></div>`}if(h.includes("|")&&h.split(`
`).filter(_=>_.trim().startsWith("|")).length>=2){const _=h.split(`
`).filter(B=>B.trim().startsWith("|")),M=lg(_,t==null?void 0:t.tableClassName);return`<div class="${f}"${i}>${M}</div>`}if(h.startsWith("> ")){const _=(t==null?void 0:t.quoteClassName)||"pdf-quote";return`<div class="${f}"${i}><blockquote class="${_}"><p>${ut(h.slice(2))}</p></blockquote></div>`}const b=/<video\b/i.test(h)||e.type==="video"||e.type==="NodeVideo",m=/^(\s*)([-*+]|\d+\.)\s+/m.test(h),y=/(?:^|\n)\s*#{1,6}\s+/.test(h);if(b&&!m&&!y&&!h.includes(`
`)){const _=((O=e.attributes)==null?void 0:O["custom-slides-autoplay"])==="true"||/autoplay/i.test(h),M=((S=e.attributes)==null?void 0:S["custom-slides-loop"])==="true"||/loop/i.test(h),B=((W=e.attributes)==null?void 0:W["custom-slides-muted"])==="true"||_||/muted/i.test(h),Q=((j=e.attributes)==null?void 0:j["custom-slides-controls"])==="false",q=h.match(/\bsrc=["']([^"']+)["']/i),U=q?q[1]:"",ne=['class="slide-video-player"'];Q||ne.push("controls"),_&&(ne.push("autoplay"),ne.push("playsinline")),M&&ne.push("loop"),B&&ne.push("muted"),ne.push('preload="auto"'),U&&ne.push(`src="${U}"`);const oe=h.match(/<video[^>]*>([\s\S]*?)<\/video>/i);let ae=oe?oe[1].trim():"";return!ae&&U&&(ae=`<source src="${U}" type="video/mp4" />您的浏览器不支持视频播放。`),`<div class="${f} ${f}--video slide-media-block slide-video-container slide-media-container" data-autoplay="${_?"true":"false"}" data-muted="${B?"true":"false"}"${i}><video ${ne.join(" ")}>${ae}</video></div>`}const g=h.match(/^!\[(.*?)\]\((.*?)\)$/);if(g){const _=(t==null?void 0:t.imageClassName)||"pdf-image slide-media-img";return`<div class="${f} ${f}--image slide-media-block slide-media-container"${i}><img alt="${nt(g[1])}" src="${g[2]}" class="${_}" /></div>`}const x=uc(h,t,e);if(x)return`<div class="${f} pdf-list-item"${i}>${x}</div>`;if(/<(?:Toc|toc)\b/i.test(h)&&!h.startsWith("```")){const _=h.match(/minDepth=["']?(\d+)["']?/i),M=h.match(/maxDepth=["']?(\d+)["']?/i),B=h.match(/columns=["']?(\d+)["']?/i),Q=(t==null?void 0:t.allSlides)||[];return`<div class="${f}"${i}>${ug(Q,(t==null?void 0:t.currentPageIndex)||1,{minDepth:_?parseInt(_[1],10):1,maxDepth:M?parseInt(M[1],10):1/0,columns:B?parseInt(B[1],10):1,textSm:h.includes("text-sm")})}</div>`}if(h.includes(`
`)||y){const _=sg(h,t,e);if(_)return`<div class="${f}"${i}>${_}</div>`}const I=!!e.isColFirst?' class="slide-list-item-title"':"";return`<div class="${f}"${i}><p${I}>${ut(h)}</p></div>`}function fg(e){return`
    ${Wi(e)}

    :root {
      --slide-bg: #ffffff;
      --slide-text: #1a1a1a;
      --slide-accent: #3b82f6;
      --slide-font: system-ui, -apple-system, sans-serif;
    }
    [data-theme="dark"] {
      --slide-bg: #121214;
      --slide-text: #e2e8f0;
      --slide-accent: #60a5fa;
    }

    /* 1. 默认科技主题 Default (Modern Tech / Digital Geek) */
    [data-slides-theme="tech"],
    .slides-theme-tech {
      --slide-font: system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "PingFang SC", "Microsoft YaHei", sans-serif;
      --slide-accent: #10b981;
      --slide-accent-secondary: #06b6d4;
    }
    [data-theme="light"][data-slides-theme="tech"],
    [data-theme="light"] .slides-theme-tech,
    .slide-viewport[data-theme="light"].slides-theme-tech,
    .slide-viewport[data-theme="light"] {
      --slide-bg: #f8fafc;
      --slide-text: #0f172a;
      --slide-text-secondary: #475569;
      --slide-code-bg: #f1f5f9;
      --slide-code-border: rgba(15, 23, 42, 0.12);
      --slide-accent: #059669;
      --slide-accent-secondary: #0284c7;
      --slide-card-bg: rgba(255, 255, 255, 0.85);
      --slide-card-border: rgba(148, 163, 184, 0.35);
      --slide-card-shadow: 0 4px 14px rgba(15, 23, 42, 0.06);
    }
    [data-theme="dark"][data-slides-theme="tech"],
    [data-theme="dark"] .slides-theme-tech,
    .slide-viewport[data-theme="dark"].slides-theme-tech,
    .slide-viewport:not([data-theme="light"]) {
      --slide-bg: #090d16;
      --slide-text: #f1f5f9;
      --slide-text-secondary: #94a3b8;
      --slide-code-bg: #0f172a;
      --slide-code-border: rgba(56, 189, 248, 0.22);
      --slide-accent: #10b981;
      --slide-accent-secondary: #38bdf8;
      --slide-card-bg: rgba(15, 23, 42, 0.7);
      --slide-card-border: rgba(56, 189, 248, 0.2);
      --slide-card-shadow: 0 6px 20px rgba(0, 0, 0, 0.35);
    }
    /* 单页为 light 时高特异性覆盖，即使外层是 dark 也强制生效 */
    [data-theme="dark"] .slide-viewport[data-theme="light"],
    .slide-viewport[data-theme="light"] {
      color: var(--slide-text) !important;
    }
    [data-theme="dark"] .slide-viewport[data-theme="light"].slides-theme-tech,
    .slide-viewport[data-theme="light"].slides-theme-tech {
      --slide-text: #0f172a !important;
      --slide-text-secondary: #475569 !important;
      --slide-accent: #059669 !important;
    }
    [data-theme="dark"] .slide-viewport[data-theme="light"].slides-theme-seriph,
    .slide-viewport[data-theme="light"].slides-theme-seriph {
      --slide-text: #231f1d !important;
      --slide-text-secondary: #57534e !important;
      --slide-accent: #b45309 !important;
    }
    [data-theme="dark"] .slide-viewport[data-theme="light"].slides-theme-apple-basic,
    .slide-viewport[data-theme="light"].slides-theme-apple-basic {
      --slide-text: #000000 !important;
      --slide-text-secondary: #6e6e73 !important;
      --slide-accent: #0071e3 !important;
    }
    /* 单页为 dark 时高特异性覆盖，即使外层是 light 也强制生效 */
    [data-theme="light"] .slide-viewport[data-theme="dark"],
    .slide-viewport[data-theme="dark"] {
      color: var(--slide-text) !important;
    }
    [data-theme="light"] .slide-viewport[data-theme="dark"].slides-theme-tech,
    .slide-viewport[data-theme="dark"].slides-theme-tech {
      --slide-text: #f1f5f9 !important;
      --slide-text-secondary: #94a3b8 !important;
      --slide-accent: #10b981 !important;
    }
    [data-theme="light"] .slide-viewport[data-theme="dark"].slides-theme-seriph,
    .slide-viewport[data-theme="dark"].slides-theme-seriph {
      --slide-text: #f5f2eb !important;
      --slide-text-secondary: #a8a29e !important;
      --slide-accent: #f59e0b !important;
    }
    [data-theme="light"] .slide-viewport[data-theme="dark"].slides-theme-apple-basic,
    .slide-viewport[data-theme="dark"].slides-theme-apple-basic {
      --slide-text: #ffffff !important;
      --slide-text-secondary: #86868b !important;
      --slide-accent: #2997ff !important;
    }
    .slides-theme-tech .layout-cover h1,
    .slides-theme-tech .layout-cover .slide-block h1 {
      font-size: 3.8rem !important;
      font-weight: 800 !important;
      line-height: 1.15 !important;
      letter-spacing: -0.025em !important;
      margin-bottom: 18px !important;
      background: linear-gradient(135deg, var(--slide-accent), var(--slide-accent-secondary)) !important;
      -webkit-background-clip: text !important;
      -webkit-text-fill-color: transparent !important;
    }
    .slides-theme-tech .layout-cover h2,
    .slides-theme-tech .layout-cover .slide-block h2 {
      font-size: 1.85rem !important;
      font-weight: 600 !important;
      color: var(--slide-text-secondary) !important;
      margin-bottom: 12px !important;
    }
    .slides-theme-tech .layout-cover p,
    .slides-theme-tech .layout-cover .slide-block p {
      font-size: 1.45rem !important;
      line-height: 1.5 !important;
      color: var(--slide-text-secondary) !important;
    }
    /* 默认科技风：内容页顶部标题带 Accent 垂直指示条与柔和横向高亮底衬 */
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h1,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h2,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h3,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h1,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h2,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h3,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h1,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h2,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h3,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h1,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h2,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h3,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) > .slide-block:first-child h1,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) > .slide-block:first-child h2,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) > .slide-block:first-child h3,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h1,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h2,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h3,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .slide-block:first-child h1,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .slide-block:first-child h2,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .slide-block:first-child h3,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .slide-block:first-child h1,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .slide-block:first-child h2,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .slide-block:first-child h3,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-left-content > .slide-block:first-child h1,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-left-content > .slide-block:first-child h2,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-left-content > .slide-block:first-child h3,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-right-content > .slide-block:first-child h1,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-right-content > .slide-block:first-child h2,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-right-content > .slide-block:first-child h3,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .slide-block:first-child h1,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .slide-block:first-child h2,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .slide-block:first-child h3,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .slide-block:first-child h1,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .slide-block:first-child h2,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .slide-block:first-child h3 {
      color: var(--slide-accent);
      border-left: 4px solid var(--slide-accent);
      padding: 4px 14px;
      padding-left: 14px;
      background: linear-gradient(90deg, color-mix(in srgb, var(--slide-accent) 13%, transparent), transparent 76%);
      border-radius: 0 6px 6px 0;
      letter-spacing: -0.015em;
    }
    .slides-theme-tech blockquote {
      border-left: 3px solid var(--slide-accent) !important;
      background: color-mix(in srgb, var(--slide-accent) 8%, transparent) !important;
      border-radius: 4px;
      padding: 12px 18px !important;
    }
    .slides-theme-tech pre {
      border: 1px solid var(--slide-code-border) !important;
      box-shadow: 0 4px 16px rgba(0, 0, 0, 0.18) !important;
      border-radius: 8px !important;
    }

    /* 2. 优雅衬线主题 Seriph (典雅学术书卷风) */
    [data-slides-theme="seriph"],
    .slides-theme-seriph {
      --slide-font: "PT Serif", "Charter", "Georgia", "Cambria", "Times New Roman", "Source Han Serif SC", "Noto Serif SC", "Songti SC", "SimSun", serif;
      --slide-accent: #b45309;
      --slide-accent-secondary: #9a3412;
      letter-spacing: 0.02em;
    }
    [data-theme="light"][data-slides-theme="seriph"],
    [data-theme="light"] .slides-theme-seriph {
      --slide-bg: #fcfbf7;
      --slide-text: #231f1d;
      --slide-text-secondary: #57534e;
      --slide-code-bg: #f5f0e6;
      --slide-code-border: rgba(180, 83, 9, 0.2);
      --slide-accent: #b45309;
      --slide-accent-secondary: #9a3412;
      --slide-card-bg: rgba(255, 255, 255, 0.75);
      --slide-card-border: rgba(180, 83, 9, 0.25);
      --slide-card-shadow: 0 2px 10px rgba(41, 37, 36, 0.04);
    }
    [data-theme="dark"][data-slides-theme="seriph"],
    [data-theme="dark"] .slides-theme-seriph {
      --slide-bg: #171513;
      --slide-text: #f5f2eb;
      --slide-text-secondary: #a8a29e;
      --slide-code-bg: #24201c;
      --slide-code-border: rgba(245, 158, 11, 0.22);
      --slide-accent: #f59e0b;
      --slide-accent-secondary: #fb923c;
      --slide-card-bg: rgba(32, 28, 24, 0.8);
      --slide-card-border: rgba(245, 158, 11, 0.22);
      --slide-card-shadow: 0 4px 16px rgba(0, 0, 0, 0.4);
    }
    .slides-theme-seriph,
    .slides-theme-seriph .slide-content {
      font-family: var(--slide-font) !important;
      line-height: 1.75;
    }
    .slides-theme-seriph h1,
    .slides-theme-seriph h2,
    .slides-theme-seriph h3 {
      font-family: var(--slide-font) !important;
      letter-spacing: 0.025em;
      font-weight: 700;
    }
    .slides-theme-seriph .layout-cover h1 {
      background: none !important;
      -webkit-background-clip: initial !important;
      -webkit-text-fill-color: initial !important;
      color: var(--slide-accent) !important;
      font-size: 3.4rem !important;
      font-weight: 700 !important;
      border-bottom: 2px solid var(--slide-accent);
      display: inline-block;
      padding-bottom: 10px;
      margin-bottom: 24px;
    }
    .slides-theme-seriph .layout-cover p {
      font-style: italic;
      color: var(--slide-text-secondary);
    }
    /* 优雅衬线风：内容页顶部标题学术双线眉批 */
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h1,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h2,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h3,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h1,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h2,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h3,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h1,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h2,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h3,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h1,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h2,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h3,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) > .slide-block:first-child h1,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) > .slide-block:first-child h2,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) > .slide-block:first-child h3,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h1,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h2,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h3,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .slide-block:first-child h1,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .slide-block:first-child h2,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .slide-block:first-child h3,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .slide-block:first-child h1,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .slide-block:first-child h2,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .slide-block:first-child h3,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-left-content > .slide-block:first-child h1,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-left-content > .slide-block:first-child h2,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-left-content > .slide-block:first-child h3,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-right-content > .slide-block:first-child h1,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-right-content > .slide-block:first-child h2,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-right-content > .slide-block:first-child h3,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .slide-block:first-child h1,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .slide-block:first-child h2,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .slide-block:first-child h3,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .slide-block:first-child h1,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .slide-block:first-child h2,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .slide-block:first-child h3 {
      display: block;
      position: relative;
      color: var(--slide-accent);
      border-bottom: 1.5px solid color-mix(in srgb, var(--slide-accent) 45%, transparent);
      padding-bottom: 10px;
      margin-bottom: 14px;
    }
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h1::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h2::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h3::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h1::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h2::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h3::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h1::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h2::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h3::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h1::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h2::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h3::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) > .slide-block:first-child h1::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) > .slide-block:first-child h2::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) > .slide-block:first-child h3::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h1::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h2::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h3::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .slide-block:first-child h1::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .slide-block:first-child h2::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .slide-block:first-child h3::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .slide-block:first-child h1::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .slide-block:first-child h2::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .slide-block:first-child h3::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-left-content > .slide-block:first-child h1::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-left-content > .slide-block:first-child h2::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-left-content > .slide-block:first-child h3::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-right-content > .slide-block:first-child h1::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-right-content > .slide-block:first-child h2::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-right-content > .slide-block:first-child h3::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .slide-block:first-child h1::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .slide-block:first-child h2::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .slide-block:first-child h3::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .slide-block:first-child h1::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .slide-block:first-child h2::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .slide-block:first-child h3::after {
      content: "";
      position: absolute;
      left: 0;
      right: 0;
      bottom: 3px;
      height: 1.5px;
      pointer-events: none;
      background: linear-gradient(90deg, var(--slide-accent) 0%, color-mix(in srgb, var(--slide-accent) 35%, transparent) 50%, transparent 92%);
    }
    .slides-theme-seriph blockquote {
      position: relative;
      font-style: italic;
      border-left: 2px solid var(--slide-accent) !important;
      background: color-mix(in srgb, var(--slide-accent) 6%, transparent) !important;
      padding: 14px 20px 14px 28px !important;
      border-radius: 4px;
      margin: 12px 0 !important;
    }
    .slides-theme-seriph blockquote::before {
      content: "“";
      position: absolute;
      left: 8px;
      top: 6px;
      font-size: 2rem;
      line-height: 1;
      color: var(--slide-accent);
      opacity: 0.6;
      font-family: Georgia, serif;
    }
    .slides-theme-seriph pre {
      border: 1px solid var(--slide-code-border) !important;
      border-radius: 4px !important;
      box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08) !important;
    }

    /* 3. 极简发布会主题 Apple Basic (苹果 Keynote / 瑞士纯粹主义) */
    [data-slides-theme="apple-basic"],
    .slides-theme-apple-basic {
      --slide-font: -apple-system, "SF Pro Display", "SF Pro Text", BlinkMacSystemFont, "PingFang SC", "Helvetica Neue", sans-serif;
      --slide-accent: #0071e3;
      --slide-accent-secondary: #0077ed;
      letter-spacing: -0.025em;
    }
    [data-theme="light"][data-slides-theme="apple-basic"],
    [data-theme="light"] .slides-theme-apple-basic {
      --slide-bg: #ffffff;
      --slide-text: #000000;
      --slide-text-secondary: #6e6e73;
      --slide-code-bg: #f5f5f7;
      --slide-code-border: transparent;
      --slide-accent: #0071e3;
      --slide-accent-secondary: #0077ed;
      --slide-card-bg: #f5f5f7;
      --slide-card-border: transparent;
      --slide-card-shadow: none;
    }
    [data-theme="dark"][data-slides-theme="apple-basic"],
    [data-theme="dark"] .slides-theme-apple-basic {
      --slide-bg: #000000;
      --slide-text: #ffffff;
      --slide-text-secondary: #86868b;
      --slide-code-bg: #161617;
      --slide-code-border: transparent;
      --slide-accent: #2997ff;
      --slide-accent-secondary: #64d2ff;
      --slide-card-bg: #161617;
      --slide-card-border: transparent;
      --slide-card-shadow: none;
    }
    .slides-theme-apple-basic,
    .slides-theme-apple-basic .slide-content {
      font-family: var(--slide-font) !important;
    }
    .slides-theme-apple-basic h1,
    .slides-theme-apple-basic h2,
    .slides-theme-apple-basic h3 {
      letter-spacing: -0.035em;
      font-weight: 800;
    }
    .slides-theme-apple-basic .layout-cover h1 {
      background: none !important;
      -webkit-background-clip: initial !important;
      -webkit-text-fill-color: initial !important;
      color: var(--slide-text) !important;
      font-size: 4rem !important;
      font-weight: 800 !important;
      letter-spacing: -0.045em !important;
      margin-bottom: 12px;
    }
    .slides-theme-apple-basic .layout-cover p {
      color: var(--slide-text-secondary) !important;
      font-size: 1.35rem !important;
      font-weight: 500 !important;
      opacity: 1 !important;
    }
    /* 极简发布会风：彻底去装饰化，高字重、紧凑字距与充沛留白 */
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h1,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h2,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h3,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h1,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h2,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h3,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h1,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h2,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h3,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h1,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h2,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h3,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) > .slide-block:first-child h1,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) > .slide-block:first-child h2,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) > .slide-block:first-child h3,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h1,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h2,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h3,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .slide-block:first-child h1,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .slide-block:first-child h2,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .slide-block:first-child h3,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .slide-block:first-child h1,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .slide-block:first-child h2,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .slide-block:first-child h3,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-left-content > .slide-block:first-child h1,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-left-content > .slide-block:first-child h2,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-left-content > .slide-block:first-child h3,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-right-content > .slide-block:first-child h1,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-right-content > .slide-block:first-child h2,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-right-content > .slide-block:first-child h3,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .slide-block:first-child h1,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .slide-block:first-child h2,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .slide-block:first-child h3,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .slide-block:first-child h1,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .slide-block:first-child h2,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .slide-block:first-child h3 {
      border: none !important;
      background: none !important;
      padding: 0 !important;
      margin-bottom: 16px !important;
      letter-spacing: -0.04em !important;
      font-weight: 800 !important;
    }
    .slides-theme-apple-basic pre {
      border-radius: 16px !important;
      border: none !important;
      background: var(--slide-code-bg) !important;
      box-shadow: none !important;
    }
    .slides-theme-apple-basic blockquote {
      border-left: none !important;
      background: var(--slide-card-bg) !important;
      border-radius: 14px !important;
      padding: 18px 24px !important;
      font-size: 1.15rem !important;
      color: var(--slide-text) !important;
    }

    /* 复杂背景防穿透文字保护 (Text Scrim & Backdrop Protection) */
    .slide-viewport[style*="background-image"] .slide-content h1,
    .slide-viewport[style*="background-image"] .slide-content h2,
    .slide-viewport[style*="background-image"] .slide-content h3,
    .slide-viewport[style*="background-image"] .slide-content p,
    .slide-viewport[style*="background-image"] .slide-content li {
      text-shadow: 0 1px 3px rgba(0, 0, 0, 0.75), 0 2px 8px rgba(0, 0, 0, 0.45);
    }
    [data-theme="light"].slide-viewport[style*="background-image"] .slide-content h1,
    [data-theme="light"].slide-viewport[style*="background-image"] .slide-content h2,
    [data-theme="light"].slide-viewport[style*="background-image"] .slide-content h3,
    [data-theme="light"].slide-viewport[style*="background-image"] .slide-content p,
    [data-theme="light"].slide-viewport[style*="background-image"] .slide-content li {
      text-shadow: 0 1px 3px rgba(255, 255, 255, 0.85);
    }
    .slide-viewport[style*="background-image"] .layout-cols-grid > div,
    .slide-viewport[style*="background-image"] .layout-two-cols-grid > div,
    .slide-viewport[style*="background-image"] .layout-three-cols-grid > div,
    .slide-viewport[style*="background-image"] .two-cols-left,
    .slide-viewport[style*="background-image"] .two-cols-right,
    .slide-viewport[style*="background-image"] .pdf-col {
      backdrop-filter: blur(8px);
      -webkit-backdrop-filter: blur(8px);
    }

    /* 封面页在背景图或显式设置文字颜色时，禁用透明渐变镂空，避免与 text-shadow 叠加成浮雕黑芯并遵循主题及实际文字色 */
    .slide-viewport[style*="background-image"] .layout-cover h1,
    .slide-viewport[style*="background-image"] .layout-cover .slide-block h1,
    .slides-overview-canvas[style*="background-image"].layout-cover h1,
    .slides-overview-canvas[style*="background-image"].layout-cover .slide-block h1,
    .slides-overview-canvas[style*="background-image"] .layout-cover h1,
    .slides-overview-canvas[style*="background-image"] .layout-cover .slide-block h1,
    .slides-theme-tech .layout-cover .slide-block[style^="color:"] h1,
    .slides-theme-tech .layout-cover .slide-block[style*=" color:"] h1,
    .slides-theme-tech .layout-cover .slide-block[style*=";color:"] h1,
    .slides-theme-tech .layout-cover h1[style^="color:"],
    .slides-theme-tech .layout-cover h1[style*=" color:"],
    .slides-theme-tech .layout-cover h1[style*=";color:"] {
      background: none !important;
      -webkit-background-clip: initial !important;
      -webkit-text-fill-color: initial !important;
    }
    .layout-cover h1 span[style^="color:"],
    .layout-cover h1 span[style*=" color:"],
    .layout-cover h1 span[style*=";color:"],
    .layout-cover h1 font[color] {
      -webkit-background-clip: initial !important;
      -webkit-text-fill-color: currentColor !important;
    }
    /* 当内容页存在背景图时，顶部标题回退至高对比正文字色并配合局部半透明底衬，同时保留主题装饰 */
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h1,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h2,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h3,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h1,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h2,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h3,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h1,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h2,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h3,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h1,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h2,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h3,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) > .slide-block:first-child h1,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) > .slide-block:first-child h2,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) > .slide-block:first-child h3,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h1,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h2,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h3,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .slide-block:first-child h1,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .slide-block:first-child h2,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .slide-block:first-child h3,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .slide-block:first-child h1,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .slide-block:first-child h2,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .slide-block:first-child h3,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-left-content > .slide-block:first-child h1,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-left-content > .slide-block:first-child h2,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-left-content > .slide-block:first-child h3,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-right-content > .slide-block:first-child h1,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-right-content > .slide-block:first-child h2,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-right-content > .slide-block:first-child h3,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .slide-block:first-child h1,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .slide-block:first-child h2,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .slide-block:first-child h3,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .slide-block:first-child h1,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .slide-block:first-child h2,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .slide-block:first-child h3 {
      color: var(--slide-text);
    }
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h1,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h2,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h3,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h1,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h2,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h3,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h1,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h2,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h3,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h1,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h2,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h3,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) > .slide-block:first-child h1,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) > .slide-block:first-child h2,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) > .slide-block:first-child h3,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h1,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h2,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h3,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .slide-block:first-child h1,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .slide-block:first-child h2,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .slide-block:first-child h3,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .slide-block:first-child h1,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .slide-block:first-child h2,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .slide-block:first-child h3,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-left-content > .slide-block:first-child h1,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-left-content > .slide-block:first-child h2,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-left-content > .slide-block:first-child h3,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-right-content > .slide-block:first-child h1,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-right-content > .slide-block:first-child h2,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-right-content > .slide-block:first-child h3,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .slide-block:first-child h1,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .slide-block:first-child h2,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .slide-block:first-child h3,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .slide-block:first-child h1,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .slide-block:first-child h2,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .slide-block:first-child h3 {
      background: linear-gradient(90deg, color-mix(in srgb, var(--slide-bg) 42%, transparent), transparent 82%);
    }
    /* 用户显式块级前景色优先于主题及背景图默认回退色 */
    .slide-viewport .slide-block[style^="color:"] h1,
    .slide-viewport .slide-block[style*=" color:"] h1,
    .slide-viewport .slide-block[style*=";color:"] h1,
    .slide-viewport .slide-block[style^="color:"] h2,
    .slide-viewport .slide-block[style*=" color:"] h2,
    .slide-viewport .slide-block[style*=";color:"] h2,
    .slide-viewport .slide-block[style^="color:"] h3,
    .slide-viewport .slide-block[style*=" color:"] h3,
    .slide-viewport .slide-block[style*=";color:"] h3 {
      color: inherit !important;
    }

    * { box-sizing: border-box; margin: 0; padding: 0; }
    html, body {
      width: 100%; height: 100%; overflow: hidden;
      background: #0f1115; font-family: var(--slide-font);
      display: flex; justify-content: center; align-items: center;
    }
    #app { width: 100%; height: 100%; position: relative; overflow: hidden; }
    .slide-viewport {
      position: absolute; left: 50%; top: 50%;
      background: var(--slide-bg); color: var(--slide-text);
      box-shadow: 0 10px 30px rgba(0,0,0,0.5); border-radius: 8px; overflow: hidden;
      display: flex; flex-direction: column; flex-shrink: 0;
      transform: translate(-50%, -50%) scale(var(--slides-slide-scale, 1));
      transform-origin: center center; will-change: transform;
      transition: background 0.3s ease, color 0.3s ease, border-radius 0.2s ease, box-shadow 0.2s ease;
      container-type: size;
    }
    :fullscreen .slide-viewport, .is-fullscreen .slide-viewport {
      border-radius: 0 !important; box-shadow: none !important;
    }
    .slide-content {
      position: relative;
      width: 100%;
      height: 100%;
      min-height: 100%;
      flex: 1 1 0%;
      padding: var(--slides-padding-y, 32px) var(--slides-padding-x, 48px);
      display: flex;
      flex-direction: column;
      overflow: hidden;
      box-sizing: border-box;
    }

    /* 间距预设风格 */
    .slide-content.spacing-compact,
    .slide-viewport[data-spacing="compact"] .slide-content,
    [data-slides-spacing="compact"] {
      --slides-padding-y: 16px;
      --slides-padding-x: 28px;
      --slides-block-gap: 8px;
      --slides-list-gap: 4px;
      --slides-cols-gap: 20px;
      --slides-title-margin-bottom: 8px;
      --slides-header-gap: 10px;
      --slides-line-height: 1.45;
    }
    .slide-content.spacing-normal,
    .slide-viewport[data-spacing="normal"] .slide-content,
    [data-slides-spacing="normal"] {
      --slides-padding-y: 32px;
      --slides-padding-x: 48px;
      --slides-block-gap: 14px;
      --slides-list-gap: 6px;
      --slides-cols-gap: 32px;
      --slides-title-margin-bottom: 12px;
      --slides-header-gap: 16px;
      --slides-line-height: 1.6;
    }
    .slide-content.spacing-loose,
    .slide-viewport[data-spacing="loose"] .slide-content,
    [data-slides-spacing="loose"] {
      --slides-padding-y: 52px;
      --slides-padding-x: 72px;
      --slides-block-gap: 22px;
      --slides-list-gap: 10px;
      --slides-cols-gap: 44px;
      --slides-title-margin-bottom: 18px;
      --slides-header-gap: 24px;
      --slides-line-height: 1.75;
    }

    /* Cover, Center, Fact, Quote, Intro 版式样式全链路对齐 */
    .layout-cover,
    .layout-center,
    .layout-fact,
    .layout-cover-container,
    .layout-center-container,
    .layout-fact-container {
      display: flex;
      flex-direction: column;
      justify-content: center;
      align-items: center;
      text-align: center;
      width: 100%;
      height: 100%;
      min-height: 0;
      box-sizing: border-box;
      flex: 1;
    }

    .layout-cover h1, .layout-cover .slide-block h1, .layout-cover-container h1 { font-size: 3.8rem !important; font-weight: 800 !important; line-height: 1.15 !important; letter-spacing: -0.025em !important; margin-bottom: 16px !important; }
    .layout-cover h2, .layout-cover .slide-block h2, .layout-cover-container h2 { font-size: 1.85rem !important; font-weight: 600 !important; opacity: 0.85 !important; margin-bottom: 12px !important; }
    .layout-cover p, .layout-cover .slide-block p, .layout-cover-container p { font-size: 1.45rem !important; line-height: 1.5 !important; opacity: 0.85 !important; }

    /* Center 版式：保持标准字阶梯但全屏绝对居中对齐 */
    .layout-center-container { padding: 40px 60px; }
    .layout-center-container h1, .layout-center h1 { font-size: 2.8rem !important; font-weight: 700 !important; margin-bottom: 16px !important; }
    .layout-center-container p, .layout-center p { font-size: 1.35rem !important; line-height: 1.6 !important; max-width: 800px; margin-left: auto; margin-right: auto; }

    /* Fact 大字报版式：震撼巨型数字看板与径向光晕氛围 (支持单大数字与多指标列表冒号分割) */
    .layout-fact,
    .layout-fact-container {
      position: relative;
      display: flex;
      flex-direction: column;
      justify-content: center;
      align-items: center;
      text-align: center;
      width: 100%;
      height: 100%;
      box-sizing: border-box;
      padding: 36px 48px;
      overflow: hidden;
    }
    .fact-hero-glow {
      position: absolute;
      top: 50%;
      left: 50%;
      width: 650px;
      height: 650px;
      transform: translate(-50%, -50%);
      background: radial-gradient(circle, rgba(var(--b3-theme-primary-rgb, 66, 133, 244), 0.28) 0%, rgba(var(--b3-theme-primary-rgb, 66, 133, 244), 0.08) 45%, transparent 70%);
      pointer-events: none;
      filter: blur(32px);
      z-index: 0;
    }
    .layout-fact-container .layout-header-section {
      position: relative;
      z-index: 1;
      width: 100%;
      margin-bottom: 24px;
      text-align: center;
    }
    .fact-content-box,
    .fact-stats-grid {
      position: relative;
      z-index: 1;
      display: grid;
      width: 100%;
      max-width: 1080px;
      margin: 0 auto;
      gap: 36px;
      justify-content: center;
      align-items: center;
    }
    .fact-stats-grid--cols-1 {
      grid-template-columns: 1fr;
      max-width: 860px;
    }
    .fact-stats-grid--cols-2 {
      grid-template-columns: repeat(2, minmax(0, 1fr));
      gap: 48px;
    }
    .fact-stats-grid--cols-3 {
      grid-template-columns: repeat(3, minmax(0, 1fr));
      gap: 32px;
    }
    .fact-stats-grid--cols-4 {
      grid-template-columns: repeat(4, minmax(0, 1fr));
      gap: 24px;
    }
    .fact-stat-card {
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      text-align: center;
      width: 100%;
      box-sizing: border-box;
      padding: 12px 16px;
      position: relative;
    }
    .fact-value-wrapper,
    .fact-value-box,
    .fact-value-text {
      font-weight: 900 !important;
      line-height: 1.05 !important;
      letter-spacing: -0.02em !important;
      color: var(--slide-accent, #3b82f6) !important;
      background: linear-gradient(135deg, var(--slide-accent, #3b82f6), #60a5fa, #93c5fd) !important;
      -webkit-background-clip: text !important;
      -webkit-text-fill-color: transparent !important;
      filter: drop-shadow(0 4px 24px rgba(var(--b3-theme-primary-rgb, 66, 133, 244), 0.42));
      margin-bottom: 8px !important;
      text-align: center !important;
      word-break: break-word;
    }
    .fact-stats-grid--cols-1 .fact-value-wrapper,
    .fact-stats-grid--cols-1 .fact-value-box,
    .fact-stats-grid--cols-1 .fact-value-text,
    .layout-fact-cols-1 .fact-value-wrapper {
      font-size: clamp(5.5rem, 12vw, 8.5rem) !important;
    }
    .fact-stats-grid--cols-2 .fact-value-wrapper,
    .fact-stats-grid--cols-2 .fact-value-box,
    .fact-stats-grid--cols-2 .fact-value-text,
    .layout-fact-cols-2 .fact-value-wrapper {
      font-size: clamp(4.2rem, 7.5vw, 6.2rem) !important;
    }
    .fact-stats-grid--cols-3 .fact-value-wrapper,
    .fact-stats-grid--cols-3 .fact-value-box,
    .fact-stats-grid--cols-3 .fact-value-text,
    .layout-fact-cols-3 .fact-value-wrapper {
      font-size: clamp(3.4rem, 5.5vw, 4.8rem) !important;
    }
    .fact-stats-grid--cols-4 .fact-value-wrapper,
    .fact-stats-grid--cols-4 .fact-value-box,
    .fact-stats-grid--cols-4 .fact-value-text,
    .layout-fact-cols-4 .fact-value-wrapper {
      font-size: clamp(2.8rem, 4.5vw, 3.8rem) !important;
    }
    .fact-value-box :is(h1, h2, h3, h4, p, span, div),
    .fact-value-wrapper :is(h1, h2, h3, h4, p, span, div) {
      font-size: inherit !important;
      font-weight: inherit !important;
      line-height: inherit !important;
      letter-spacing: inherit !important;
      color: inherit !important;
      background: inherit !important;
      -webkit-background-clip: text !important;
      -webkit-text-fill-color: transparent !important;
      margin: 0 !important;
      text-align: center !important;
    }
    .fact-divider-line {
      width: 60px;
      height: 3px;
      border-radius: 2px;
      background: var(--slide-accent, #3b82f6);
      margin: 12px auto 14px;
      opacity: 0.8;
      box-shadow: 0 2px 8px rgba(var(--b3-theme-primary-rgb, 66, 133, 244), 0.5);
    }
    .fact-label-wrapper,
    .fact-label-box,
    .fact-label-text {
      font-size: 1.25rem !important;
      font-weight: 500 !important;
      line-height: 1.5 !important;
      letter-spacing: normal !important;
      color: var(--b3-theme-on-surface, #e2e8f0) !important;
      background: none !important;
      -webkit-background-clip: border-box !important;
      -webkit-text-fill-color: initial !important;
      filter: none !important;
      opacity: 0.88 !important;
      max-width: 480px;
      margin: 0 auto;
      text-align: center !important;
    }
    .fact-stats-grid--cols-1 .fact-label-wrapper,
    .fact-stats-grid--cols-1 .fact-label-box,
    .fact-stats-grid--cols-1 .fact-label-text {
      font-size: 1.6rem !important;
      max-width: 720px;
    }
    .fact-label-box :is(h1, h2, h3, h4, p, span, div, li),
    .fact-label-wrapper :is(h1, h2, h3, h4, p, span, div, li) {
      font-size: inherit !important;
      font-weight: inherit !important;
      line-height: inherit !important;
      letter-spacing: normal !important;
      color: inherit !important;
      background: none !important;
      -webkit-background-clip: border-box !important;
      -webkit-text-fill-color: initial !important;
      filter: none !important;
      opacity: inherit !important;
      margin: 0 !important;
      text-align: center !important;
    }

    /* Timeline / Steps 时间线与步骤流程版式 */
    .layout-timeline-container,
    .layout-steps-container,
    .slide-content-wrapper.layout-timeline,
    .slide-content-wrapper.layout-steps {
      display: flex;
      flex-direction: column;
      width: 100%;
      height: 100%;
      box-sizing: border-box;
      padding: 32px 56px;
      overflow: hidden;
      flex: 1;
    }
    .timeline-track-wrapper {
      display: flex;
      flex-direction: row;
      align-items: flex-start;
      justify-content: space-between;
      width: 100%;
      flex: 1;
      gap: 24px;
      margin-top: auto;
      margin-bottom: auto;
      padding: 24px 0 36px;
      position: relative;
    }
    .timeline-step-item {
      display: flex;
      flex-direction: column;
      align-items: center;
      flex: 1;
      min-width: 0;
      position: relative;
      text-align: center;
    }
    .timeline-node-container {
      position: relative;
      display: flex;
      align-items: center;
      justify-content: center;
      width: 100%;
      margin-bottom: 24px;
    }
    .timeline-node-badge {
      width: 48px;
      height: 48px;
      border-radius: 50%;
      background: var(--slide-accent, var(--b3-theme-primary));
      color: #ffffff;
      font-size: 1.35rem;
      font-weight: 800;
      display: flex;
      align-items: center;
      justify-content: center;
      box-shadow: 0 4px 16px rgba(var(--b3-theme-primary-rgb, 66, 133, 244), 0.4);
      z-index: 2;
      flex-shrink: 0;
      transition: all 0.2s ease;
    }
    .timeline-connector-line {
      position: absolute;
      top: 50%;
      left: 50%;
      width: 100%;
      height: 3px;
      background: linear-gradient(90deg, var(--slide-accent, #3b82f6), rgba(125, 125, 125, 0.25));
      transform: translateY(-50%);
      z-index: 1;
    }
    .timeline-step-content {
      width: 100%;
      padding: 16px;
      background: rgba(125, 125, 125, 0.05);
      border: 1px solid rgba(125, 125, 125, 0.12);
      border-radius: 12px;
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.04);
      box-sizing: border-box;
      display: flex;
      flex-direction: column;
      align-items: center;
      backdrop-filter: blur(6px);
    }
    .timeline-step-content h1,
    .timeline-step-content h2,
    .timeline-step-content h3,
    .timeline-step-content h4 {
      font-size: 1.35rem !important;
      font-weight: 700 !important;
      margin-bottom: 8px !important;
      color: var(--b3-theme-on-surface);
    }
    .timeline-step-content p,
    .timeline-step-content li {
      font-size: 1.05rem !important;
      line-height: 1.55 !important;
      opacity: 0.85;
      margin-bottom: 4px;
    }
    .timeline-step-content ul {
      padding-left: 0;
      list-style: none;
    }

    /* Quote 引言版式：居中大字、衬线字体、水印双引号与右对齐出处 */
    .layout-quote,
    .layout-quote-container {
      display: flex;
      flex-direction: column;
      justify-content: center;
      align-items: center;
      width: 100%;
      height: 100%;
      position: relative;
      box-sizing: border-box;
      padding: 48px 72px;
      overflow: hidden;
      flex: 1;
    }
    .quote-watermark-icon {
      position: absolute;
      top: 10%;
      left: 8%;
      font-size: 16rem;
      line-height: 1;
      font-family: Georgia, serif;
      opacity: 0.08;
      pointer-events: none;
      user-select: none;
      color: currentColor;
    }
    .quote-content-body {
      position: relative;
      z-index: 1;
      max-width: 850px;
      width: 100%;
      text-align: center;
    }
    .quote-text,
    .layout-quote-container .quote-body {
      font-size: 2.2rem !important;
      font-style: italic !important;
      line-height: 1.6 !important;
      font-family: var(--slides-font-serif, "Noto Serif SC", Georgia, serif) !important;
      letter-spacing: 0.01em;
      margin-bottom: 24px !important;
    }
    .quote-text p,
    .layout-quote-container .quote-body p {
      font-size: inherit !important;
      font-style: inherit !important;
      line-height: inherit !important;
    }
    .quote-footer,
    .quote-author {
      font-size: 1.25rem !important;
      opacity: 0.75 !important;
      text-align: right !important;
      font-style: normal !important;
      letter-spacing: 0.05em;
    }

    /* Intro 个人/章节介绍版式：头像配图与右侧个人履历卡片 */
    .layout-intro,
    .layout-intro-container {
      display: flex;
      flex-direction: row;
      align-items: center;
      justify-content: center;
      gap: 56px;
      width: 100%;
      height: 100%;
      box-sizing: border-box;
      padding: 40px 64px;
      overflow: hidden;
      flex: 1;
    }
    .intro-avatar-col {
      flex-shrink: 0;
      display: flex;
      align-items: center;
      justify-content: center;
    }
    .intro-avatar-box {
      width: 240px;
      height: 240px;
      border-radius: 50%;
      overflow: hidden;
      box-shadow: 0 16px 36px rgba(0, 0, 0, 0.16);
      border: 4px solid rgba(var(--b3-theme-primary-rgb, 66, 133, 244), 0.35);
      background: rgba(125, 125, 125, 0.08);
      display: flex;
      align-items: center;
      justify-content: center;
    }
    .intro-avatar-img {
      width: 100%;
      height: 100%;
      object-fit: cover;
      display: block;
    }
    .intro-avatar-svg {
      width: 120px;
      height: 120px;
      opacity: 0.35;
      fill: currentColor;
    }
    .intro-info-col {
      flex: 1;
      min-width: 0;
      display: flex;
      flex-direction: column;
      justify-content: center;
    }
    .intro-info-col h1 {
      font-size: 3rem !important;
      font-weight: 800 !important;
      line-height: 1.2 !important;
      margin-bottom: 8px !important;
    }
    .intro-info-col h2, .intro-info-col h3 {
      font-size: 1.5rem !important;
      font-weight: 600 !important;
      color: var(--slide-accent) !important;
      margin-bottom: 16px !important;
    }
    .intro-info-col p {
      font-size: 1.25rem !important;
      line-height: 1.6 !important;
      opacity: 0.9 !important;
    }
    .intro-info-col ul {
      margin-top: 12px;
      padding-left: 20px;
    }
    .intro-info-col li {
      font-size: 1.15rem !important;
      line-height: 1.6 !important;
      margin-bottom: 6px;
      opacity: 0.9 !important;
    }
    .two-cols-left, .two-cols-right { min-width: 0; width: 100%; display: flex; flex-direction: column; box-sizing: border-box; overflow-wrap: break-word; word-break: break-word; }
    .pdf-two-cols-wrapper,
    .layout-two-cols-grid,
    .layout-cols-wrapper,
    .layout-cols-grid {
      display: grid;
      grid-template-columns: var(--slide-grid-cols, minmax(0, 1fr) minmax(0, 1fr));
      grid-template-rows: minmax(0, 1fr) !important;
      gap: var(--slides-cols-gap, 32px);
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      overflow: hidden !important;
    }
    .layout-cols-header-container,
    .layout-two-cols-header-container,
    .layout-three-cols-header-container,
    .layout-clover-container {
      display: flex;
      flex-direction: column;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      overflow: hidden !important;
    }
    .layout-header-section {
      width: 100%;
      margin-bottom: var(--slides-header-gap, 16px) !important;
      flex-shrink: 0;
    }
    .layout-header-section h1,
    .layout-header-section h2,
    .layout-header-section h3 {
      margin-bottom: var(--slides-title-margin-bottom, 10px) !important;
    }
    .pdf-three-cols-wrapper,
    .layout-three-cols-grid {
      display: grid;
      grid-template-columns: var(--slide-grid-cols, minmax(0, 1fr) minmax(0, 1fr) minmax(0, 1fr));
      grid-template-rows: minmax(0, 1fr) !important;
      gap: calc(var(--slides-cols-gap, 32px) * 0.75);
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      box-sizing: border-box;
      overflow: hidden !important;
    }
    .pdf-clover-wrapper,
    .layout-clover-grid {
      display: grid;
      grid-template-columns: repeat(2, minmax(0, 1fr)) !important;
      grid-template-rows: repeat(2, minmax(0, 1fr)) !important;
      gap: calc(var(--slides-cols-gap, 32px) * 0.625);
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      box-sizing: border-box;
      overflow: hidden !important;
    }
    .layout-clover-grid .pdf-col {
      background: transparent !important;
      border: none !important;
      box-shadow: none !important;
    }
    .pdf-col {
      display: flex;
      flex-direction: column;
      gap: var(--slides-block-gap, 14px);
      min-width: 0;
      width: 100%;
      max-width: 100%;
      height: 100%;
      max-height: 100%;
      min-height: 0;
      justify-content: flex-start;
      box-sizing: border-box;
      overflow: hidden;
      overflow-wrap: break-word;
      word-break: break-word;
      white-space: normal;
    }
    .pdf-col * {
      overflow-wrap: break-word;
      word-break: break-word;
      box-sizing: border-box;
    }
    /* 表头多栏内超级块子块首个列表项去圆点后居中显示标题/首行文本 (仅在存在超级块分栏时生效) */
    .has-superblock-cols .pdf-col > *:first-child .slide-list-item-title,
    .has-superblock-cols .pdf-col > *:first-child :is(h1, h2, h3, h4, h5, h6),
    .has-superblock-cols .pdf-col > *:first-child p.slide-list-item-title,
    .has-superblock-cols .pdf-col > *:first-child p:first-of-type,
    .has-superblock-cols .pdf-col > *:first-child p:first-child,
    .has-superblock-cols .pdf-col > *:first-child :is(ul, ol) > li:first-child,
    .has-superblock-cols .pdf-col > *:first-child .slide-list > .slide-list-item:first-child,
    .has-superblock-cols .pdf-col > *:first-child .pdf-list > li:first-child,
    .has-superblock-cols .slides-col-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    .has-superblock-cols .slides-col-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      list-style: none !important;
      list-style-type: none !important;
      text-align: center !important;
      margin-left: 0 !important;
      padding-left: 0 !important;
      width: 100% !important;
    }

    /* 彻底清除首个列表项的原生圆点 Marker (仅在存在超级块分栏时生效) */
    .has-superblock-cols .pdf-col > *:first-child :is(ul, ol) > li:first-child::marker {
      content: "" !important;
      display: none !important;
    }

    /* 确保首个列表项内部内联与块级元素居中 (仅在存在超级块分栏时生效) */
    .has-superblock-cols .pdf-col > *:first-child :is(ul, ol) > li:first-child * {
      text-align: center !important;
    }

    /* 栏内说明段落与列表项：左对齐，自然阅读排版 */
    .has-superblock-cols .pdf-col .slide-list-item-desc,
    .has-superblock-cols .pdf-col li:not(:first-child) {
      text-align: left !important;
    }

    /* 全局特定标题大小规范化 (除封面外页首首个标题按 H2 1.7rem，表头多栏内首个标题按 H3 1.3rem) */
    [data-normalize-headings="true"] .slides-page-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .slides-page-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .slide-content:not(.layout-cover) > :is(.pdf-block, .slide-block):first-child :is(h1, h2, h3, h4, h5, h6),
    [data-normalize-headings="true"] .slide-content:not(.layout-cover) > .layout-header-section :is(.pdf-block, .slide-block):first-child :is(h1, h2, h3, h4, h5, h6),
    [data-normalize-headings="true"] .slide-content:not(.layout-cover) > :not(.layout-cols-wrapper):not(.pdf-two-cols-wrapper):not(.layout-image-cols-grid):first-child :is(h1, h2, h3, h4, h5, h6) {
      font-size: 1.7rem !important;
      font-weight: 600 !important;
      line-height: 1.25 !important;
      margin-bottom: var(--slides-title-margin-bottom, 10px) !important;
    }

    [data-normalize-headings="true"] .has-superblock-cols .slides-col-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .has-superblock-cols .slides-col-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .has-superblock-cols .pdf-col > *:first-child :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      font-size: 1.3rem !important;
      font-weight: 600 !important;
      line-height: 1.3 !important;
      margin-bottom: 8px !important;
      text-align: center !important;
    }

    /* 图左与图右版式标题完全保留用户原始字号与默认排版，不进行任何固定大小规范化 */
    [data-normalize-headings="true"] :is(.layout-image-left, .layout-image-right, .image-left-content, .image-right-content) :is(h1, h2, h3, h4, h5, h6) {
      text-align: left !important;
    }
    .pdf-col pre,
    .two-cols-left pre,
    .two-cols-right pre,
    .image-right-content pre,
    .image-left-content pre {
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      overflow-x: hidden !important;
      overflow-y: auto !important;
      max-width: 100% !important;
      box-sizing: border-box !important;
    }
    .slide-content.layout-image-right, .slide-content.layout-image-left {
      padding: 0;
      display: grid;
      grid-template-columns: var(--slide-grid-cols, minmax(0, 1fr) minmax(0, 1fr));
      grid-template-rows: 100%;
      width: 100%;
      height: 100%;
      position: absolute;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      box-sizing: border-box;
    }
    .image-right-content, .image-left-content {
      padding: var(--slides-padding-y, 32px) var(--slides-padding-x, 48px);
      display: flex;
      flex-direction: column;
      justify-content: flex-start;
      overflow-y: auto;
      width: 100%;
      height: 100%;
      box-sizing: border-box;
    }
    .image-right-img-container, .image-left-img-container {
      width: 100%;
      height: 100%;
      overflow: hidden;
      position: relative;
      background: #18181b;
      display: flex;
      align-items: center;
      justify-content: center;
    }
    .image-right-img, .image-left-img {
      width: 100%;
      height: 100%;
      object-fit: cover;
      object-position: center;
      display: block;
    }
    .slide-block { margin-bottom: var(--slides-block-gap, 14px); line-height: var(--slides-line-height, 1.6); }
    .slide-block h1 { font-size: 2.2rem; margin-bottom: var(--slides-title-margin-bottom, 12px); }
    .slide-block h2 { font-size: 1.7rem; margin-bottom: calc(var(--slides-title-margin-bottom, 10px) * 0.85); }
    .slide-block p { font-size: 1.15rem; line-height: var(--slides-line-height, 1.6); }
    .slide-block ul, .slide-block ol, .pdf-list {
      padding-left: 28px;
      margin: calc(var(--slides-block-gap, 14px) * 0.6) 0;
      display: flex;
      flex-direction: column;
      gap: var(--slides-list-gap, 6px);
    }
    .slide-block li, .pdf-list li {
      font-size: 1.15rem;
      line-height: var(--slides-line-height, 1.6);
    }
    .pdf-task-item {
      list-style: none;
      margin-left: -20px;
      display: flex;
      align-items: center;
      gap: 8px;
    }
    .pdf-task-item input[type="checkbox"] {
      width: 1.15em;
      height: 1.15em;
      cursor: pointer;
    }

    /* 两栏与三栏及多栏（超级块分栏）布局：紧凑自然行距，子列表保留圆点与层级缩进 */
    .layout-two-cols ul,
    .layout-cols-header ul,
    .layout-two-cols-header ul,
    .layout-three-cols ul,
    .layout-three-cols-header ul,
    .two-cols-left ul,
    .two-cols-right ul,
    .three-cols-col ul,
    .col ul,
    .pdf-col ul,
    .layout-two-cols-grid .pdf-list,
    .layout-three-cols-grid .pdf-list,
    .layout-cols-grid .pdf-list,
    .layout-two-cols-grid .pdf-list--unordered,
    .layout-three-cols-grid .pdf-list--unordered,
    .layout-cols-grid .pdf-list--unordered {
      list-style: disc !important;
      list-style-type: disc !important;
      padding-left: 1.25em !important;
      margin-left: 0 !important;
      margin-top: 0 !important;
      margin-bottom: 8px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: block !important;
    }

    .layout-two-cols ol,
    .layout-cols-header ol,
    .layout-two-cols-header ol,
    .layout-three-cols ol,
    .layout-three-cols-header ol,
    .two-cols-left ol,
    .two-cols-right ol,
    .three-cols-col ol,
    .col ol,
    .pdf-col ol,
    .layout-two-cols-grid .pdf-list--ordered,
    .layout-three-cols-grid .pdf-list--ordered,
    .layout-cols-grid .pdf-list--ordered {
      list-style: decimal !important;
      list-style-type: decimal !important;
      padding-left: 1.25em !important;
      margin-left: 0 !important;
      margin-top: 0 !important;
      margin-bottom: 8px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: block !important;
    }

    .layout-two-cols li,
    .layout-cols-header li,
    .layout-two-cols-header li,
    .layout-three-cols li,
    .layout-three-cols-header li,
    .two-cols-left li,
    .two-cols-right li,
    .three-cols-col li,
    .col li,
    .pdf-col li,
    .pdf-col .pdf-list-item {
      padding-left: 0.2em !important;
      margin-left: 0 !important;
      margin-bottom: var(--slides-list-gap, 6px) !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: list-item !important;
      line-height: var(--slides-line-height, 1.6) !important;
    }

    .layout-two-cols ul ul,
    .layout-three-cols ul ul,
    .three-cols-col ul ul,
    .pdf-col ul ul {
      list-style: circle !important;
      list-style-type: circle !important;
      padding-left: 1.25em !important;
      margin-top: 4px !important;
      margin-bottom: 4px !important;
    }

    /* 列表项内嵌标题与说明排版 */
    .slide-list-item-title,
    .pdf-list li > h1,
    .pdf-list li > h2,
    .pdf-list li > h3,
    .pdf-list li > h4,
    .pdf-list li > h5,
    .pdf-list li > h6,
    li > h1.slide-list-item-title,
    li > h2.slide-list-item-title,
    li > h3.slide-list-item-title,
    li > h4.slide-list-item-title {
      margin-top: 2px !important;
      margin-bottom: 6px !important;
      line-height: 1.35 !important;
      font-weight: 700 !important;
    }
    .pdf-list li > h1, li > h1.slide-list-item-title { font-size: 1.6rem !important; }
    .pdf-list li > h2, li > h2.slide-list-item-title { font-size: 1.4rem !important; }
    .pdf-list li > h3, li > h3.slide-list-item-title { font-size: 1.22rem !important; }
    .pdf-list li > h4, li > h4.slide-list-item-title { font-size: 1.1rem !important; }

    /* 全局特定标题大小规范化后置强力锁定 (防止被列表项内部字号覆盖) */
    [data-normalize-headings="true"] .slides-page-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .slides-page-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      font-size: 1.7rem !important;
      font-weight: 600 !important;
      line-height: 1.25 !important;
      margin-bottom: 10px !important;
    }
    [data-normalize-headings="true"] .slides-col-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .slides-col-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] :is(.layout-cols-wrapper, .pdf-two-cols-wrapper, .layout-cols-header-container, .layout-cols-grid) .pdf-col > *:first-child :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] :is(.two-cols-left, .two-cols-right, .pdf-col, .col) > *:first-child :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      font-size: 1.3rem !important;
      font-weight: 600 !important;
      line-height: 1.3 !important;
      margin-bottom: 8px !important;
      text-align: center !important;
    }
    /* 基础列表项前缀样式 */
    .slide-block ul,
    .slide-list--unordered,
    .pdf-list--unordered {
      list-style: disc !important;
      list-style-type: disc !important;
    }
    .slide-block ol,
    .slide-list--ordered,
    .pdf-list--ordered {
      list-style: decimal !important;
      list-style-type: decimal !important;
    }
    .slide-block li,
    .slide-list-item,
    .pdf-list-item,
    .pdf-list li {
      display: list-item !important;
    }

    /* 隐藏无序列表前缀标记 */
    [data-hide-unordered-markers="true"] :is(ul, .slide-list, .slide-list--unordered, .pdf-list, .pdf-list--unordered),
    [data-hide-unordered-markers="true"] :is(ul, .slide-list, .slide-list--unordered, .pdf-list, .pdf-list--unordered) > li,
    [data-hide-unordered-markers="true"] li.slide-list-item,
    [data-hide-unordered-markers="true"] ul > li {
      list-style: none !important;
      list-style-type: none !important;
      padding-left: 0 !important;
      margin-left: 0 !important;
    }
    [data-hide-unordered-markers="true"] :is(ul, .slide-list, .slide-list--unordered, .pdf-list, .pdf-list--unordered) > li::marker,
    [data-hide-unordered-markers="true"] li.slide-list-item::marker {
      content: "" !important;
      display: none !important;
    }

    /* 隐藏有序列表前缀标记 */
    [data-hide-ordered-markers="true"] :is(ol, .slide-list, .slide-list--ordered, .pdf-list, .pdf-list--ordered),
    [data-hide-ordered-markers="true"] :is(ol, .slide-list, .slide-list--ordered, .pdf-list, .pdf-list--ordered) > li,
    [data-hide-ordered-markers="true"] li.slide-list-item,
    [data-hide-ordered-markers="true"] ol > li {
      list-style: none !important;
      list-style-type: none !important;
      padding-left: 0 !important;
      margin-left: 0 !important;
    }
    [data-hide-ordered-markers="true"] :is(ol, .slide-list, .slide-list--ordered, .pdf-list, .pdf-list--ordered) > li::marker,
    [data-hide-ordered-markers="true"] li.slide-list-item::marker {
      content: "" !important;
      display: none !important;
    }

    .slide-list-item-desc,
    .pdf-list li > p {
      margin-top: 4px !important;
      margin-bottom: 6px !important;
      font-size: 1.05rem;
      line-height: 1.55;
      opacity: 0.92;
    }

    /* 多媒体（GIF动图、静态图片、MP4视频）全视口最大化自适应且不超出视口 */
    .slide-media-block,
    .slide-media-container,
    .slide-video-container,
    .slide-block--media,
    .slide-block--image,
    .slide-block--video,
    .slide-block:has(> img),
    .slide-block:has(> .slide-media-container),
    .slide-block:has(> p > img:only-child),
    .slide-block:has(> .slide-video-container),
    .slide-block:has(> video) {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      min-width: 0 !important;
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
      justify-content: center !important;
      width: 100% !important;
      height: 100% !important;
      max-height: 100% !important;
      overflow: hidden !important;
      margin: 4px 0 !important;
      box-sizing: border-box !important;
    }

    .two-cols-left > .slide-block,
    .two-cols-right > .slide-block,
    .three-cols-col > .slide-block,
    .pdf-col > .slide-block,
    .pdf-col .slide-block {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      max-height: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      width: 100% !important;
      height: 100% !important;
      box-sizing: border-box !important;
      overflow: hidden !important;
      margin-bottom: 0 !important;
    }

    /* 列内列表项的标题与段落文字：固定高度，不压缩 */
    .two-cols-left .slide-list-item-title,
    .two-cols-right .slide-list-item-title,
    .three-cols-col .slide-list-item-title,
    .pdf-col .slide-list-item-title,
    .two-cols-left h1, .two-cols-left h2, .two-cols-left h3, .two-cols-left h4, .two-cols-left h5, .two-cols-left h6,
    .two-cols-right h1, .two-cols-right h2, .two-cols-right h3, .two-cols-right h4, .two-cols-right h5, .two-cols-right h6,
    .three-cols-col h1, .three-cols-col h2, .three-cols-col h3, .three-cols-col h4, .three-cols-col h5, .three-cols-col h6,
    .pdf-col h1, .pdf-col h2, .pdf-col h3, .pdf-col h4, .pdf-col h5, .pdf-col h6,
    .three-cols-col .slide-list-item-desc,
    .pdf-col .slide-list-item-desc {
      flex: 0 0 auto !important;
      margin-top: 0 !important;
      margin-bottom: 6px !important;
    }

    /* 列内媒体容器：填满标题下方所有剩余垂直空间，纵向顶部对齐，横向居中，无溢出 */
    .two-cols-left .slide-list-media,
    .two-cols-right .slide-list-media,
    .three-cols-col .slide-list-media,
    .pdf-col .slide-list-media,
    .two-cols-left .slide-video-container,
    .two-cols-right .slide-video-container,
    .three-cols-col .slide-video-container,
    .pdf-col .slide-video-container,
    .two-cols-left .slide-media-container,
    .two-cols-right .slide-media-container,
    .three-cols-col .slide-media-container,
    .pdf-col .slide-media-container {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      min-width: 0 !important;
      width: 100% !important;
      height: 100% !important;
      max-height: 100% !important;
      max-width: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
      justify-content: flex-start !important;
      overflow: hidden !important;
      margin: 0 !important;
      padding: 0 !important;
      box-sizing: border-box !important;
    }

    /* 列内多媒体播放器：以 contain 模式等比缩放完整可见，绝对不超高超宽、不产生遮挡与滚动条 */
    .two-cols-left video,
    .two-cols-right video,
    .three-cols-col video,
    .pdf-col video,
    .two-cols-left img,
    .two-cols-right img,
    .three-cols-col img,
    .pdf-col img,
    .two-cols-left .slide-video-player,
    .two-cols-right .slide-video-player,
    .three-cols-col .slide-video-player,
    .pdf-col .slide-video-player,
    .layout-three-cols-grid video,
    .layout-two-cols-grid video,
    .layout-three-cols-grid img,
    .layout-two-cols-grid img {
      max-width: 100% !important;
      max-height: 100% !important;
      width: auto !important;
      height: auto !important;
      min-width: 0 !important;
      min-height: 0 !important;
      object-fit: contain !important;
      display: block !important;
      margin: 0 auto !important;
      cursor: zoom-in;
    }

    .slide-block img,
    .slide-media-img,
    .slide-media-container img,
    .slide-video-player,
    video.slide-video-player,
    .slide-block video {
      max-width: 100% !important;
      max-height: 100% !important;
      width: auto !important;
      height: auto !important;
      min-width: 0 !important;
      min-height: 0 !important;
      object-fit: contain !important;
      display: block !important;
      margin: 0 auto !important;
      border-radius: 8px;
      box-shadow: 0 4px 16px rgba(0, 0, 0, 0.16);
      background: transparent;
      outline: none;
      cursor: zoom-in;
    }

    .slide-list-media {
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
      justify-content: flex-start !important;
      width: 100% !important;
      max-width: 100% !important;
      height: 100% !important;
      max-height: 100% !important;
      flex: 1 1 0% !important;
      margin-top: 4px !important;
      margin-bottom: 4px !important;
      min-height: 0 !important;
      overflow: hidden !important;
      box-sizing: border-box !important;
    }
    .slide-list-media img,
    .slide-list-media video,
    .slide-list-media .list-item-gif,
    .slide-list-media .slide-video-player {
      max-width: 100% !important;
      max-height: 100% !important;
      width: auto !important;
      height: auto !important;
      min-width: 0 !important;
      min-height: 0 !important;
      object-fit: contain !important;
      border-radius: 6px !important;
      box-shadow: 0 3px 12px rgba(0, 0, 0, 0.14) !important;
      display: block !important;
      margin: 0 auto !important;
      cursor: zoom-in;
    }

    .slide-block:has(.slide-list-media) {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      height: 100% !important;
      max-height: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      overflow: hidden !important;
    }
    .slide-block:has(.slide-list-media) .pdf-list,
    .slide-block:has(.slide-list-media) ul,
    .slide-block:has(.slide-list-media) ol {
      display: block !important;
      flex: 1 1 auto;
      min-height: 0;
      max-height: 100%;
      overflow: visible !important;
      list-style: disc !important;
      list-style-type: disc !important;
    }
    .slide-block:has(.slide-list-media) li,
    .slide-block:has(.slide-list-media) .slide-list-item,
    .slide-block:has(.slide-list-media) .pdf-list-item,
    .slide-block:has(.slide-media-container) li,
    .slide-block:has(.slide-video-container) li,
    .layout-cols-wrapper li:has(.slide-list-media),
    .layout-cols-header-container li:has(.slide-list-media),
    .two-cols-left li:has(.slide-list-media),
    .two-cols-right li:has(.slide-list-media),
    .three-cols-col li:has(.slide-list-media),
    .pdf-col li:has(.slide-list-media),
    li:has(.slide-list-media),
    li:has(.slide-video-container),
    li:has(.slide-media-container) {
      display: list-item !important;
      list-style-type: disc !important;
      flex: 0 0 auto !important;
      height: auto !important;
      max-height: none !important;
      overflow: visible !important;
      margin-bottom: 6px !important;
    }

    .layout-two-cols .slide-media-block,
    .layout-two-cols .slide-video-container,
    .layout-two-cols .slide-media-container,
    .layout-three-cols .slide-media-block,
    .layout-three-cols .slide-video-container,
    .layout-three-cols .slide-media-container {
      max-width: 100% !important;
      max-height: 100% !important;
      width: 100% !important;
      height: 100% !important;
      min-width: 0 !important;
      min-height: 0 !important;
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
      justify-content: flex-start !important;
      overflow: hidden !important;
    }

    /* Lightbox 大图与视频灯箱模态窗口 */
    .slides-lightbox {
      position: fixed;
      top: 0;
      left: 0;
      width: 100vw;
      height: 100vh;
      background: rgba(0, 0, 0, 0.88);
      backdrop-filter: blur(8px);
      z-index: 999999;
      display: none;
      align-items: center;
      justify-content: center;
      cursor: zoom-out;
      opacity: 0;
      transition: opacity 0.2s cubic-bezier(0.16, 1, 0.3, 1);
    }
    .slides-lightbox.active {
      display: flex;
      opacity: 1;
    }
    .slides-lightbox-content {
      position: relative;
      max-width: 92vw;
      max-height: 92vh;
      display: flex;
      align-items: center;
      justify-content: center;
      cursor: default;
    }
    .slides-lightbox-img {
      max-width: 92vw;
      max-height: 92vh;
      object-fit: contain;
      border-radius: 8px;
      box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.75);
      user-select: none;
      -webkit-user-drag: none;
      touch-action: none;
    }
    .slides-lightbox-video {
      max-width: 92vw;
      max-height: 92vh;
      border-radius: 8px;
      box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.75);
    }
    .slides-lightbox-close {
      position: absolute;
      top: 24px;
      right: 28px;
      width: 40px;
      height: 40px;
      background: rgba(255, 255, 255, 0.2);
      border: 1px solid rgba(255, 255, 255, 0.35);
      border-radius: 50%;
      color: #fff;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 22px;
      cursor: pointer;
      transition: background 0.2s, transform 0.2s;
      z-index: 1000000;
    }
    .slides-lightbox-close:hover {
      background: rgba(255, 255, 255, 0.35);
      transform: scale(1.05);
    }

    img.slide-inline-img {
      max-width: 100% !important;
      max-height: min(320px, 40vh) !important;
      object-fit: contain !important;
      vertical-align: middle;
      border-radius: 4px;
    }
    kbd {
      display: inline-block;
      padding: 2px 7px;
      font-family: ui-monospace, SFMono-Regular, "SF Mono", Menlo, Consolas, "Liberation Mono", monospace;
      font-size: 0.85em;
      font-weight: 600;
      line-height: 1.25;
      color: inherit;
      background: rgba(125, 125, 125, 0.12);
      border: 1px solid rgba(125, 125, 125, 0.35);
      border-bottom-width: 2px;
      border-radius: 5px;
      box-shadow: 0 1px 2px rgba(0, 0, 0, 0.12);
      margin: 0 2px;
      vertical-align: middle;
      white-space: nowrap;
    }
    [data-theme="dark"] kbd, .theme-dark kbd {
      background: rgba(255, 255, 255, 0.1);
      border-color: rgba(255, 255, 255, 0.25);
      border-bottom-color: rgba(255, 255, 255, 0.4);
      color: #f1f5f9;
      box-shadow: 0 1px 2px rgba(0, 0, 0, 0.4);
    }
    .slide-block pre,
    pre {
      background: rgba(0, 0, 0, 0.1);
      padding: 12px;
      border-radius: 6px;
      font-family: "JetBrains Mono", Consolas, monospace;
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      overflow-x: hidden !important;
      overflow-y: auto !important;
      max-width: 100% !important;
      box-sizing: border-box !important;
    }
    .slide-block pre code,
    pre code {
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      display: block !important;
      width: 100% !important;
      box-sizing: border-box !important;
    }
    .code-line {
      display: flex !important;
      align-items: flex-start !important;
      width: 100% !important;
      box-sizing: border-box !important;
      line-height: 1.6;
    }
    .code-line .line-no {
      display: inline-block !important;
      flex-shrink: 0 !important;
      min-width: 2.2em !important;
      text-align: right !important;
      margin-right: 12px !important;
      user-select: none !important;
      opacity: 0.45 !important;
    }
    .code-line .line-content {
      flex: 1 1 0% !important;
      min-width: 0 !important;
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
    }
    /* 弱提示滚动条样式 */
    * {
      scrollbar-width: thin;
      scrollbar-color: rgba(255, 255, 255, 0.20) transparent;
    }
    *::-webkit-scrollbar {
      width: 4px;
      height: 4px;
    }
    *::-webkit-scrollbar-track {
      background: transparent;
    }
    *::-webkit-scrollbar-thumb {
      background: rgba(255, 255, 255, 0.20);
      border-radius: 2px;
      transition: background 0.2s ease;
    }
    *:hover::-webkit-scrollbar-thumb,
    *::-webkit-scrollbar-thumb:hover {
      background: rgba(255, 255, 255, 0.45);
    }
    /* Slidev Micro-motion Keyframes & Presets */
    @keyframes slidesMotionFadeIn { from { opacity: 0; } to { opacity: 1; } }
    @keyframes slidesMotionSlideUp { from { opacity: 0; transform: translateY(40px); } to { opacity: 1; transform: translateY(0); } }
    @keyframes slidesMotionSlideDown { from { opacity: 0; transform: translateY(-40px); } to { opacity: 1; transform: translateY(0); } }
    @keyframes slidesMotionSlideLeft { from { opacity: 0; transform: translateX(40px); } to { opacity: 1; transform: translateX(0); } }
    @keyframes slidesMotionSlideRight { from { opacity: 0; transform: translateX(-40px); } to { opacity: 1; transform: translateX(0); } }
    @keyframes slidesMotionZoomIn { from { opacity: 0; transform: scale(0.8); } to { opacity: 1; transform: scale(1); } }
    @keyframes slidesMotionBounce {
      0% { opacity: 0; transform: translateY(40px); }
      60% { opacity: 1; transform: translateY(-8px); }
      80% { transform: translateY(4px); }
      100% { transform: translateY(0); }
    }
    .slides-motion-fade-in { animation: slidesMotionFadeIn var(--motion-duration, 0.4s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slides-motion-slide-up { animation: slidesMotionSlideUp var(--motion-duration, 0.45s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slides-motion-slide-down { animation: slidesMotionSlideDown var(--motion-duration, 0.45s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slides-motion-slide-left { animation: slidesMotionSlideLeft var(--motion-duration, 0.45s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slides-motion-slide-right { animation: slidesMotionSlideRight var(--motion-duration, 0.45s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slides-motion-zoom-in, .slides-motion-pop { animation: slidesMotionZoomIn var(--motion-duration, 0.4s) cubic-bezier(0.34, 1.56, 0.64, 1) var(--motion-delay, 0s) both; }
    .slides-motion-bounce { animation: slidesMotionBounce var(--motion-duration, 0.6s) cubic-bezier(0.34, 1.56, 0.64, 1) var(--motion-delay, 0s) both; }
    .controls {
      position: absolute; bottom: 16px; display: flex; gap: 12px; align-items: center;
      background: rgba(24, 24, 27, 0.8); backdrop-filter: blur(8px);
      padding: 6px 18px; border-radius: 20px; color: #fff; font-size: 13px; z-index: 10;
      opacity: 0; pointer-events: auto;
      transition: opacity 0.3s cubic-bezier(0.16, 1, 0.3, 1), transform 0.3s cubic-bezier(0.16, 1, 0.3, 1);
    }
    .controls::before {
      content: ""; position: absolute; top: -20px; bottom: -16px; left: -24px; right: -24px;
    }
    .controls:hover, .controls:focus-within {
      opacity: 1; transform: translateY(-2px);
    }
    .controls button { background: transparent; border: none; color: inherit; cursor: pointer; padding: 2px 6px; }

    /* Slidev Native Icons & Interactive Buttons */
    .slidev-icon-btn {
      display: inline-flex !important; flex-direction: row !important; align-items: center !important; justify-content: center !important;
      padding: 0.35rem 0.5rem; border-radius: 0.375rem; background: transparent;
      border: 1px solid transparent; color: inherit; font-size: inherit; line-height: 1;
      cursor: pointer; opacity: 0.8; transition: all 0.2s ease; text-decoration: none;
      vertical-align: middle; user-select: none; margin: 0 4px;
    }
    .slidev-icon-btn:hover { opacity: 1; background: rgba(255, 255, 255, 0.12); border-color: rgba(255, 255, 255, 0.15); }

    /* 组件从上到下按顺序流式渲染，避免相互重叠 */
    .slide-block > div + div { margin-top: 14px; }

    /* 同一个 div 内的按钮/链接从左到右水平渲染 */
    .slide-block div:has(> .slidev-icon-btn),
    .slide-block div:has(> button),
    .slide-block [class*="abs-"],
    .slides-btn-row {
      display: inline-flex !important;
      flex-direction: row !important;
      align-items: center !important;
      justify-content: center !important;
      flex-wrap: wrap !important;
      gap: 8px !important;
    }

    /* Position Shortcuts 适配：在组件流中保持从上到下排列，不脱离流产生重叠 */
    .slide-block .abs-br,
    .slide-block .abs-bl,
    .slide-block .abs-tr,
    .slide-block .abs-tl,
    .slide-block [class*="abs-"] {
      position: relative !important;
      bottom: auto !important;
      right: auto !important;
      top: auto !important;
      left: auto !important;
      margin: 0.75rem auto !important;
    }

    .slide-block--absolute { position: relative !important; margin-bottom: 14px !important; padding: 0 !important; background: transparent !important; }
    .slide-block--absolute:hover { background: transparent !important; }
    .mt-12 { margin-top: 3rem !important; }
    .py-1 { padding-top: 0.25rem !important; padding-bottom: 0.25rem !important; }
    .m-6 { margin: 1.5rem !important; }
    .text-xl { font-size: 1.25rem !important; }
    [hover\\:bg~="white"][hover\\:bg~="op-10"]:hover,
    [hover\\:bg="white op-10"]:hover { background: rgba(255, 255, 255, 0.1) !important; border-radius: 4px; }
    .cursor-pointer, [data-clickable] { cursor: pointer; }
    /* Slidev 规范链接排版 (继承正文颜色，虚线底边，Hover 时平滑点亮为主题色并转为实线) */
    .slide-content a:not(.slides-ref-tag):not(.slidev-icon-btn):not(.slides-toc-link),
    .slide-block a:not(.slides-ref-tag):not(.slidev-icon-btn):not(.slides-toc-link),
    a.slides-link {
      color: inherit;
      text-decoration: none;
      border-bottom: 1px dashed currentColor;
      transition: color 0.2s cubic-bezier(0.4, 0, 0.2, 1),
                  border-color 0.2s cubic-bezier(0.4, 0, 0.2, 1),
                  border-bottom-style 0.2s cubic-bezier(0.4, 0, 0.2, 1);
      cursor: pointer;
    }
    .slide-content a:not(.slides-ref-tag):not(.slidev-icon-btn):not(.slides-toc-link):hover,
    .slide-block a:not(.slides-ref-tag):not(.slidev-icon-btn):not(.slides-toc-link):hover,
    a.slides-link:hover {
      color: var(--slide-accent);
      border-bottom-style: solid;
      border-bottom-color: var(--slide-accent);
    }
    .slides-ref-tag, a.slides-ref-tag {
      display: inline-flex;
      align-items: center;
      background: color-mix(in srgb, var(--slide-accent) 12%, transparent);
      color: var(--slide-accent);
      border-radius: 4px;
      padding: 2px 8px;
      font-size: 0.88em;
      text-decoration: none;
      cursor: pointer;
      margin: 2px 4px 2px 0;
      border: 1px solid color-mix(in srgb, var(--slide-accent) 25%, transparent);
      transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
    }
    .slides-ref-tag:hover, a.slides-ref-tag:hover {
      background: color-mix(in srgb, var(--slide-accent) 22%, transparent);
      color: var(--slide-accent);
      border-color: color-mix(in srgb, var(--slide-accent) 55%, transparent);
      transform: translateY(-1px);
      box-shadow: 0 2px 8px color-mix(in srgb, var(--slide-accent) 20%, transparent);
    }
    .slides-block-ref {
      display: block;
      padding: 10px 14px;
      background: color-mix(in srgb, var(--slide-accent) 8%, transparent);
      border-left: 3px solid var(--slide-accent);
      border-radius: 0 6px 6px 0;
      margin: 8px 0;
      cursor: pointer;
      transition: background 0.2s ease;
    }
    .slides-block-ref:hover {
      background: color-mix(in srgb, var(--slide-accent) 15%, transparent);
    }

    /* 页面动态蒙版 (Dynamic Mask) GPU 合成器硬件加速体系 */
    .slides-mask-body-container {
      position: relative;
      width: 100%;
      height: 100%;
      min-height: 0;
      flex: 1;
      display: flex;
      flex-direction: column;
      overflow: hidden !important;
      contain: layout paint;
      isolation: isolate;
    }
    .slides-mask-body-container--has-mask {
      overflow: hidden !important;
      /* 向左右、向下突破父容器内边距，完全贴合幻灯片视口边缘 */
      margin-left: calc(-1 * var(--slides-padding-x, 48px)) !important;
      margin-right: calc(-1 * var(--slides-padding-x, 48px)) !important;
      margin-bottom: calc(-1 * var(--slides-padding-y, 32px)) !important;
      padding-left: var(--slides-padding-x, 48px) !important;
      padding-right: var(--slides-padding-x, 48px) !important;
      padding-bottom: var(--slides-padding-y, 32px) !important;
      width: calc(100% + 2 * var(--slides-padding-x, 48px)) !important;
      box-sizing: border-box !important;
    }
    /* 无标题且首个元素即为蒙版正文容器时，向上同步扩展至顶部边缘 */
    .slide-content-wrapper > .slides-mask-body-container--has-mask:first-child,
    .slide-content > .slides-mask-body-container--has-mask:first-child {
      margin-top: calc(-1 * var(--slides-padding-y, 32px)) !important;
      padding-top: var(--slides-padding-y, 32px) !important;
    }
    /* 针对全屏零内边距特殊布局（如 image-right/image-left），重置内边距变量避免越界 */
    .slide-content-wrapper.layout-image-right,
    .slide-content-wrapper.layout-image-left,
    .slide-content.layout-image-right,
    .slide-content.layout-image-left {
      --slides-padding-x: 0px !important;
      --slides-padding-y: 0px !important;
    }
    /* 蒙版运动总图层：纯 GPU Compositor 硬件加速 translate3d */
    .slides-mask-layer {
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      pointer-events: none;
      z-index: 50;
      will-change: transform, opacity;
      transform: translate3d(0, 0, 0);
      backface-visibility: hidden;
      transition: transform 0.42s cubic-bezier(0.2, 0, 0, 1),
                  opacity 0.42s cubic-bezier(0.2, 0, 0, 1);
    }
    /* 蒙版内部遮罩层：纯色或磨砂玻璃 */
    .slides-mask-overlay {
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      pointer-events: none;
    }
    .slides-mask-layer--solid .slides-mask-overlay,
    .slides-mask-overlay--solid {
      background: var(--slide-bg, #ffffff);
    }
    [data-theme="dark"] .slides-mask-layer--solid .slides-mask-overlay,
    [data-theme="dark"] .slides-mask-overlay--solid {
      background: var(--slide-bg, #121214);
    }
    .slides-mask-layer--blur .slides-mask-overlay,
    .slides-mask-overlay--blur {
      backdrop-filter: blur(30px) saturate(180%);
      -webkit-backdrop-filter: blur(30px) saturate(180%);
      background: color-mix(in srgb, var(--slide-bg, #ffffff) 90%, transparent);
    }
    [data-theme="dark"] .slides-mask-layer--blur .slides-mask-overlay,
    [data-theme="dark"] .slides-mask-overlay--blur {
      background: color-mix(in srgb, var(--slide-bg, #121214) 90%, transparent);
    }
    /* 动态展露分界提示线：物理内嵌于蒙版边缘，相对坐标永为 0，绝对物理同步 */
    .slides-mask-divider-line {
      position: absolute;
      pointer-events: none;
      z-index: 51;
      opacity: 0;
      transition: opacity 0.3s ease;
    }
    .slides-mask-layer--down .slides-mask-divider-line,
    .slides-mask-divider-line--down {
      top: 0;
      left: 0;
      right: 0;
      height: 2.5px;
      transform: translateY(-50%);
      background: linear-gradient(90deg, transparent 0%, var(--slide-accent, #3b82f6) 6%, var(--slide-accent, #3b82f6) 94%, transparent 100%);
      box-shadow: 0 0 10px var(--slide-accent, #3b82f6), 0 0 4px var(--slide-accent, #3b82f6);
    }
    .slides-mask-layer--right .slides-mask-divider-line,
    .slides-mask-divider-line--right {
      top: 0;
      bottom: 0;
      left: 0;
      width: 2.5px;
      transform: translateX(-50%);
      background: linear-gradient(180deg, transparent 0%, var(--slide-accent, #3b82f6) 6%, var(--slide-accent, #3b82f6) 94%, transparent 100%);
      box-shadow: 0 0 10px var(--slide-accent, #3b82f6), 0 0 4px var(--slide-accent, #3b82f6);
    }
    .slides-mask-layer--clockwise,
    .slides-mask-layer--counter-clockwise,
    .slides-mask-layer--cw,
    .slides-mask-layer--ccw,
    .slides-mask-layer--clock {
      transform: none !important;
    }
    .slides-mask-layer--clockwise .slides-mask-divider-line,
    .slides-mask-layer--counter-clockwise .slides-mask-divider-line,
    .slides-mask-layer--cw .slides-mask-divider-line,
    .slides-mask-layer--ccw .slides-mask-divider-line,
    .slides-mask-layer--clock .slides-mask-divider-line,
    .slides-mask-divider-line--clock,
    .slides-mask-divider-line--clockwise,
    .slides-mask-divider-line--counter-clockwise {
      top: 50%;
      left: 50%;
      right: auto;
      bottom: auto;
      width: 55%;
      height: 2.5px;
      transform-origin: 0% 50%;
      transform: translateY(-50%) rotate(-180deg);
      background: linear-gradient(90deg, var(--slide-accent, #3b82f6) 0%, var(--slide-accent, #3b82f6) 75%, transparent 100%);
      box-shadow: 0 0 10px var(--slide-accent, #3b82f6), 0 0 4px var(--slide-accent, #3b82f6);
      transition: transform 0.42s cubic-bezier(0.2, 0, 0, 1), opacity 0.3s ease;
      will-change: transform, opacity;
    }
    .slides-mask-layer--counter-clockwise .slides-mask-divider-line,
    .slides-mask-divider-line--counter-clockwise {
      transform: translateY(-50%) rotate(-90deg);
    }`}function pg(){return`    (function() {
      const data = window.__SLIDES_DATA__ || { slides: [] };
      const slides = data.slides || [];
      let currentIndex = 0;

      const container = document.getElementById("slide-container");
      const pageNum = document.getElementById("page-num");
      const btnPrev = document.getElementById("btn-prev");
      const btnNext = document.getElementById("btn-next");
      const btnFullscreen = document.getElementById("btn-fullscreen");

      // 「数字+回车」跳页输入角标：右下角悬浮显示，独立于缩放视口
      const jumpBadge = document.createElement("div");
      jumpBadge.className = "jump-page-indicator";
      jumpBadge.style.display = "none";
      document.body.appendChild(jumpBadge);
      const jumpStyle = document.createElement("style");
      jumpStyle.textContent = ".jump-page-indicator{position:fixed;right:16px;bottom:16px;z-index:1000;min-width:40px;padding:4px 12px;border-radius:18px;background:rgba(24,24,27,0.8);backdrop-filter:blur(12px);-webkit-backdrop-filter:blur(12px);border:1px solid rgba(255,255,255,0.12);color:#f4f4f5;font-size:14px;font-variant-numeric:tabular-nums;text-align:center;pointer-events:none;box-shadow:0 4px 16px rgba(0,0,0,0.35);}.jump-page-indicator.is-invalid{background:rgba(153,27,27,0.85);border-color:rgba(248,113,113,0.5);color:#fecaca;animation:jump-indicator-shake 0.4s ease;}@keyframes jump-indicator-shake{0%,100%{transform:translateX(0);}25%{transform:translateX(-4px);}50%{transform:translateX(4px);}75%{transform:translateX(-2px);}}";
      document.head.appendChild(jumpStyle);

`}function hg(){return`      // ========= 缩略图总览层（o 键呼出，方向键/数字+回车/点选跳页） =========
      const OVERVIEW_CARD_W = 236;
      let overviewOpen = false;
      let overviewFocus = 1;
      let overviewBuilt = false;
      let overviewObserver = null;
      const overviewOverlay = document.createElement("div");
      overviewOverlay.className = "slides-overview";
      overviewOverlay.style.display = "none";
      const overviewGrid = document.createElement("div");
      overviewGrid.className = "slides-overview-grid";
      const overviewHint = document.createElement("div");
      overviewHint.className = "slides-overview-hint";
      overviewHint.textContent = "← → ↑ ↓ 移动 · Enter 跳转 · 数字直达 · Esc / O 关闭";
      overviewOverlay.appendChild(overviewGrid);
      overviewOverlay.appendChild(overviewHint);
      document.body.appendChild(overviewOverlay);
      overviewOverlay.addEventListener("click", (e) => {
        if (e.target === overviewOverlay) closeOverview();
      });
      const overviewStyle = document.createElement("style");
      overviewStyle.textContent = ".slides-overview{position:fixed;inset:0;z-index:900;overflow-y:auto;background:rgba(13,16,22,0.88);backdrop-filter:blur(18px);-webkit-backdrop-filter:blur(18px);padding:36px 44px 20px;box-sizing:border-box;}.slides-overview-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(236px,1fr));gap:18px;max-width:1440px;margin:0 auto;}.slides-overview-card{cursor:pointer;border-radius:10px;border:2px solid rgba(255,255,255,0.12);background:rgba(255,255,255,0.04);overflow:hidden;transition:border-color 0.15s ease,transform 0.15s ease,box-shadow 0.15s ease;}.slides-overview-card:hover{border-color:rgba(255,255,255,0.38);transform:translateY(-2px);}.slides-overview-card.is-active{border-color:var(--slide-accent,#3b82f6);box-shadow:0 0 0 1px var(--slide-accent,#3b82f6),0 8px 24px rgba(0,0,0,0.4);}.slides-overview-canvas-box{position:relative;overflow:hidden;background:var(--slide-bg,#ffffff);}.slides-overview-canvas{position:absolute;top:0;left:0;transform-origin:top left;pointer-events:none;}.slides-overview-canvas *{scrollbar-width:none;}.slides-overview-caption{display:flex;align-items:center;gap:8px;padding:6px 10px;font-size:12px;color:rgba(255,255,255,0.72);border-top:1px solid rgba(255,255,255,0.08);background:rgba(13,16,22,0.6);}.slides-overview-page-no{flex-shrink:0;font-variant-numeric:tabular-nums;font-weight:600;color:#f4f4f5;background:rgba(255,255,255,0.16);border-radius:8px;padding:0 7px;line-height:18px;}.slides-overview-page-no.is-current{background:var(--slide-accent,#10b981);color:#0b1210;}.slides-overview-title{white-space:nowrap;overflow:hidden;text-overflow:ellipsis;user-select:none;}.slides-overview-hint{text-align:center;margin:18px 0 8px;font-size:12px;color:rgba(255,255,255,0.45);user-select:none;}";
      document.head.appendChild(overviewStyle);

      const baseWidth = 980;
      const aspectStr = (data.config && data.config.aspectRatio) || "16/9";
      let ratioNum = 16 / 9;
      if (aspectStr === "4/3") ratioNum = 4 / 3;
      else if (aspectStr === "16/10") ratioNum = 16 / 10;
      else if (typeof aspectStr === "string" && aspectStr.includes("/")) {
        const parts = aspectStr.split("/").map(Number);
        if (parts[0] && parts[1]) ratioNum = parts[0] / parts[1];
      }
      const baseHeight = Math.ceil(baseWidth / ratioNum);
      const viewport = document.getElementById("viewport");

`}function mg(){return`      function updateScale() {
        if (!viewport) return;
        const isFull = !!document.fullscreenElement;
        const padX = isFull ? 0 : 20;
        const padY = isFull ? 0 : 32;
        const availW = Math.max(100, window.innerWidth - padX);
        const availH = Math.max(100, window.innerHeight - padY);
        const scale = Math.min(availW / baseWidth, availH / baseHeight);
        viewport.style.width = baseWidth + "px";
        viewport.style.height = baseHeight + "px";
        viewport.style.transform = "translate(-50%, -50%) scale(" + scale + ")";
        viewport.style.setProperty("--slides-slide-scale", scale);
        if (isFull) document.body.classList.add("is-fullscreen");
        else document.body.classList.remove("is-fullscreen");
      }

      window.addEventListener("resize", updateScale);
      document.addEventListener("fullscreenchange", updateScale);

      function parseMaskRatio(ratioStr, defaultSteps) {
        var defSteps = (defaultSteps === 4) ? 4 : 2;
        var defBps = (defaultSteps === 4) ? [25, 50, 75, 100] : [50, 100];
        if (!ratioStr || typeof ratioStr !== "string") {
          return { steps: defSteps, breakpoints: defBps };
        }
        var clean = ratioStr.trim();
        if (!clean || (defaultSteps === 4 && (clean === "1:1" || clean === "1"))) return { steps: defSteps, breakpoints: defBps };
        var parts = clean.split(":").map(function(p) { return parseFloat(p.trim()); }).filter(function(n) { return !isNaN(n) && n > 0; });
        if (parts.length === 0) return { steps: defSteps, breakpoints: defBps };
        if (parts.length === 1) {
          var val = Math.min(100, Math.max(1, parts[0]));
          if (val === 100) return { steps: 1, breakpoints: [100] };
          return { steps: 2, breakpoints: [Math.round(val * 100) / 100, 100] };
        }
        var isMonotonic = parts.every(function(val, idx) { return idx === 0 || val > parts[idx - 1]; });
        var maxVal = parts[parts.length - 1];
        if (isMonotonic && (maxVal === 100 || parts.some(function(p) { return p > 10; }))) {
          var bps = parts.map(function(p) { return Math.min(100, Math.round(p * 100) / 100); });
          if (bps[bps.length - 1] < 100) bps.push(100);
          return { steps: bps.length, breakpoints: bps };
        }
        var totalWeight = parts.reduce(function(acc, cur) { return acc + cur; }, 0);
        if (totalWeight <= 0) return { steps: defSteps, breakpoints: defBps };
        var accumulated = 0;
        var bps = [];
        for (var i = 0; i < parts.length; i++) {
          accumulated += parts[i];
          if (i === parts.length - 1) {
            bps.push(100);
          } else {
            bps.push(Math.round((accumulated / totalWeight) * 10000) / 100);
          }
        }
        return { steps: bps.length, breakpoints: bps };
      }

      let currentMaskStep = 0;
      let currentMaskConfig = null;
      let maskLayerEl = null;
      let maskOverlayEl = null;
      let maskDividerEl = null;

      function updateMaskVisual() {
        if (!currentMaskConfig || !maskLayerEl) return;
        const p = (currentMaskStep <= 0)
          ? (currentMaskConfig.isInitialRevealed ? currentMaskConfig.breakpoints[0] : 0)
          : (currentMaskStep >= currentMaskConfig.totalSteps
              ? 100
              : currentMaskConfig.breakpoints[currentMaskConfig.isInitialRevealed ? currentMaskStep : (currentMaskStep - 1)]);

        if (currentMaskConfig.isClock) {
          const isCw = currentMaskConfig.direction === "clockwise" || currentMaskConfig.direction === "cw";
          const sweepDeg = Math.min(360, Math.max(0, (p / 100) * 360));
          const needleAngle = isCw ? (-180 + sweepDeg) : (-90 - sweepDeg);

          if (maskOverlayEl) {
            let maskGrad = "";
            if (sweepDeg <= 0) {
              maskGrad = "conic-gradient(from 0deg at 50% 50%, #000 0deg, #000 360deg)";
            } else if (sweepDeg >= 360) {
              maskGrad = "conic-gradient(from 0deg at 50% 50%, transparent 0deg, transparent 360deg)";
            } else if (isCw) {
              maskGrad = "conic-gradient(from 270deg at 50% 50%, transparent 0deg, transparent " + sweepDeg + "deg, #000 " + sweepDeg + "deg, #000 360deg)";
            } else {
              const remDeg = 360 - sweepDeg;
              maskGrad = "conic-gradient(from 0deg at 50% 50%, #000 0deg, #000 " + remDeg + "deg, transparent " + remDeg + "deg, transparent 360deg)";
            }
            maskOverlayEl.style.webkitMaskImage = maskGrad;
            maskOverlayEl.style.maskImage = maskGrad;
          }

          if (maskDividerEl) {
            maskDividerEl.style.transform = "translateY(-50%) rotate(" + needleAngle + "deg)";
            maskDividerEl.style.opacity = (p <= 0 || p >= 100) ? "0" : "1";
          }

          if (p >= 100) {
            maskLayerEl.style.opacity = "0";
            maskLayerEl.style.pointerEvents = "none";
          } else {
            maskLayerEl.style.opacity = "1";
            maskLayerEl.style.pointerEvents = "none";
          }
          return;
        }

        const isDown = currentMaskConfig.direction === "down";
        if (p >= 100) {
          maskLayerEl.style.transform = isDown ? "translate3d(0, 100%, 0)" : "translate3d(100%, 0, 0)";
          maskLayerEl.style.opacity = "0";
          maskLayerEl.style.pointerEvents = "none";
          if (maskDividerEl) maskDividerEl.style.opacity = "0";
        } else {
          maskLayerEl.style.transform = isDown ? ("translate3d(0, " + p + "%, 0)") : ("translate3d(" + p + "%, 0, 0)");
          maskLayerEl.style.opacity = "1";
          maskLayerEl.style.pointerEvents = "none";
          if (maskDividerEl) {
            maskDividerEl.style.opacity = (p <= 0) ? "0" : "1";
          }
        }
      }

      function goNext() {
        if (currentMaskConfig && currentMaskStep < currentMaskConfig.totalSteps) {
          currentMaskStep++;
          updateMaskVisual();
          return;
        }
        renderSlide(currentIndex + 1);
      }

      function goPrev() {
        if (currentMaskConfig && currentMaskStep > (currentMaskConfig.isInitialRevealed ? 1 : 0)) {
          currentMaskStep--;
          updateMaskVisual();
          return;
        }
        // FSM-9 优化：回退至上一页时传递 backward 方向，使上一页遮罩处于完全展开状态
        renderSlide(currentIndex - 1, "backward");
      }

`}function gg(){return`      function cleanCardListItemMarkdown(rawMarkdown) {
        if (!rawMarkdown) return "";
        let cleaned = rawMarkdown.replace(/^[ \\t]*[-*+]\\s+|^[ \\t]*\\d+\\.\\s+/, "");
        cleaned = cleaned.replace(/\\n[ \\t]{2,4}/g, "\\n");
        return cleaned.trim();
      }

      function isHeadingBlock(b) {
        if (!b) return false;
        if (b.type === "h" || b.type === "NodeHeading") return true;
        if (b.subType && /^h[1-6]$/i.test(b.subType)) return true;
        const md = (b.rawMarkdown || b.content || "").trim();
        if (/^#{1,6}\\s+/.test(md)) return true;
        if (/^(?:[-*+]|\\d+\\.)\\s+#{1,6}\\s+/.test(md)) return true;
        return false;
      }

      function cleanColList(blocks) {
        const valid = (blocks || []).filter(b => Boolean((b.rawMarkdown || b.content || "").trim()));
        if (valid.length === 0) return valid;
        const first = valid[0];
        const md = (first.rawMarkdown || first.content || "").trim();
        const isList = /^(?:[-*+]|\\d+\\.)\\s+/.test(md) || first.type === "i" || first.type === "l";
        if (isList) {
          first.rawMarkdown = cleanCardListItemMarkdown(first.rawMarkdown || first.content || "");
          first.content = first.rawMarkdown;
        }
        return valid;
      }

      function renderBlock(block, extraClass) {
        const div = document.createElement("div");
        div.className = "slide-block" + (extraClass ? " " + extraClass : "");
        if (block && block.motion && block.motion.preset && block.motion.preset !== "none") {
          div.classList.add("slides-motion-" + block.motion.preset.toLowerCase());
          if (typeof block.motion.duration === "number" && block.motion.duration > 0) {
            div.style.setProperty("--motion-duration", block.motion.duration + "ms");
          }
          if (typeof block.motion.delay === "number" && block.motion.delay > 0) {
            div.style.setProperty("--motion-delay", block.motion.delay + "ms");
          }
        }
        const md = block.rawMarkdown || block.content || "";

        if (md.includes('class="slides-block-ref"') || md.includes('class="slides-ref-tag"')) {
          div.innerHTML = md;
          return div;
        }

        const CARBON_MAP = {
          'carbon:arrow-right': '<svg viewBox="0 0 32 32" width="1.2em" height="1.2em" fill="currentColor" style="display:inline-block;vertical-align:middle;"><path d="m18 6l-1.43 1.393L24.15 15H4v2h20.15l-7.58 7.573L18 26l10-10z"/></svg>',
          'carbon:arrow-left': '<svg viewBox="0 0 32 32" width="1.2em" height="1.2em" fill="currentColor" style="display:inline-block;vertical-align:middle;"><path d="m14 26l1.43-1.393L7.85 17H28v-2H7.85l7.58-7.573L14 6L4 16z"/></svg>',
          'carbon:edit': '<svg viewBox="0 0 32 32" width="1.2em" height="1.2em" fill="currentColor" style="display:inline-block;vertical-align:middle;"><path d="M2 26h28v2H2zM25.4 9c.8-.8.8-2 0-2.8l-3.6-3.6c-.8-.8-2-.8-2.8 0l-15 15V24h6.4l15-15zM20.4 4L24 7.6l-2.4 2.4l-3.6-3.6L20.4 4zM6 22v-3.6l11-11l3.6 3.6l-11 11H6z"/></svg>',
          'carbon:logo-github': '<svg viewBox="0 0 32 32" width="1.2em" height="1.2em" fill="currentColor" style="display:inline-block;vertical-align:middle;"><path fill-rule="evenodd" d="M16 2a14 14 0 0 0-4.43 27.28c.7.13 1-.3 1-.67v-2.38c-3.89.84-4.71-1.88-4.71-1.88a3.7 3.7 0 0 0-1.56-2.05c-1.27-.86.1-.85.1-.85a2.94 2.94 0 0 1 2.14 1.44a3 3 0 0 0 4.08 1.16a2.93 2.93 0 0 1 .89-1.87c-3.1-.35-6.36-1.55-6.36-6.9a5.4 5.4 0 0 1 1.44-3.75a5 5 0 0 1 .14-3.71s1.17-.38 3.85 1.43a13.3 13.3 0 0 1 7 0c2.67-1.81 3.84-1.43 3.84-1.43a5 5 0 0 1 .14 3.71a5.4 5.4 0 0 1 1.44 3.75c0 5.37-3.27 6.54-6.38 6.89a3.35 3.35 0 0 1 1.26 2.61v3.87c0 .38.26.81 1 .67A14 14 0 0 0 16 2"/></svg>'
        };

        if (/@\\w+=['"]|v-\\w+|<button|<a\\b|<carbon:|^<div/i.test(md)) {
          if (md.includes('abs-br') || md.includes('abs-bl') || md.includes('abs-tr') || md.includes('abs-tl') || md.includes('absolute')) {
            div.classList.add("slide-block--absolute");
          }
          let renderedHtml = md;
          for (const [tag, svg] of Object.entries(CARBON_MAP)) {
            const regex = new RegExp("<" + tag + "\\\\s*\\\\/?>", "gi");
            renderedHtml = renderedHtml.replace(regex, svg);
            const regexDash = new RegExp("<" + tag.replace(":", "-") + "\\\\s*\\\\/?>", "gi");
            renderedHtml = renderedHtml.replace(regexDash, svg);
          }
          div.innerHTML = renderedHtml;

          // 挂载交互事件监听
          const allInteractive = div.querySelectorAll("*");
          allInteractive.forEach(btn => {
            let hasNext = false;
            let hasPrev = false;
            for (let i = 0; i < btn.attributes.length; i++) {
              const a = btn.attributes[i];
              const attrName = a.name.toLowerCase();
              if (attrName.indexOf("@click") !== -1 || attrName.indexOf("v-on:click") !== -1) {
                if (a.value.indexOf("next") !== -1) hasNext = true;
                if (a.value.indexOf("prev") !== -1) hasPrev = true;
              }
            }
            if (hasNext) {
              btn.style.cursor = "pointer";
              btn.addEventListener("click", (e) => {
                e.stopPropagation();
                renderSlide(currentIndex + 1);
              });
            } else if (hasPrev) {
              btn.style.cursor = "pointer";
              btn.addEventListener("click", (e) => {
                e.stopPropagation();
                renderSlide(currentIndex - 1);
              });
            }
          });

          return div;
        }

        const hasHeadingTag = /(?:^|\\n)\\s*#{1,6}\\s+/.test(md);
        const hMatch = md.match(/^(#{1,6})\\s+(.*)$/);

        if (hMatch) {
          const level = hMatch[1].length;
          let th = hMatch[2].trim().replace(/\\*\\*(.*?)\\*\\*/g, "<strong>$1</strong>").replace(/\\x60([^\\x60]+)\\x60/g, "<code>$1</code>");
          div.innerHTML = "<h" + level + ">" + th + "</h" + level + ">";
        }
        else if (md.startsWith("\\x60\\x60\\x60")) {
          var rawMaxH = block?.attributes?.["custom-slides-max-height"] || block?.attrs?.["custom-slides-max-height"] || block?.maxHeight || "";
          var customMaxHeight = "";
          if (rawMaxH) {
            var sMaxH = String(rawMaxH).trim();
            if (/^\\d+$/.test(sMaxH)) customMaxHeight = sMaxH + "px";
            else if (/^(\\d+(?:\\.\\d+)?)%$/.test(sMaxH)) customMaxHeight = sMaxH.replace("%", "cqh");
            else if (/^(\\d+(?:\\.\\d+)?)vh$/.test(sMaxH)) customMaxHeight = sMaxH.replace("vh", "cqh");
            else customMaxHeight = sMaxH;
          }
          const heightStyle = customMaxHeight ? ' style="max-height:' + customMaxHeight + ';overflow-y:auto;"' : "";
          div.innerHTML = "<pre" + heightStyle + "><code>" + md.slice(3, -3) + "</code></pre>";
        }
        else if (md.startsWith("> ")) div.innerHTML = "<blockquote><p>" + md.slice(2) + "</p></blockquote>";
        else if ((/<video\\b/i.test(md) || (block && (block.type === "video" || block.type === "NodeVideo"))) && !/^(\\s*)([-*+]|\\d+\\.)\\s+/m.test(md) && !hasHeadingTag && !md.includes("\\n")) {
          div.classList.add("slide-video-container", "slide-media-container", "slide-media-block");
          const isAutoplay = block && block.attributes && block.attributes["custom-slides-autoplay"] === "true";
          const isLoop = block && block.attributes && block.attributes["custom-slides-loop"] === "true";
          const isMuted = block && block.attributes && (block.attributes["custom-slides-muted"] === "true" || isAutoplay);
          const hideControls = block && block.attributes && block.attributes["custom-slides-controls"] === "false";
          let videoHtml = md;
          if (hideControls) videoHtml = videoHtml.replace(/\\bcontrols(?:="[^"]*")?/gi, "").trim();
          else if (!videoHtml.includes("controls")) videoHtml = videoHtml.replace("<video", "<video controls");
          if (isAutoplay && !videoHtml.includes("autoplay")) videoHtml = videoHtml.replace("<video", "<video autoplay playsinline");
          if (isLoop && !videoHtml.includes("loop")) videoHtml = videoHtml.replace("<video", "<video loop");
          if (isMuted && !videoHtml.includes("muted")) videoHtml = videoHtml.replace("<video", "<video muted");
          videoHtml = videoHtml.replace("<video", '<video class="slide-video-player"');
          div.setAttribute("data-autoplay", isAutoplay ? "true" : "false");
          div.innerHTML = videoHtml;
        }
        else if (
          /^(\\s*)([-*+]|\\d+\\.)\\s+/m.test(md) ||
          (md.includes("\\n") && /^(\\s*)([-*+]|\\d+\\.)\\s+/m.test(md.split("\\n").slice(1).join("\\n"))) ||
          ((block && (block.isListItem || block.type === "i")) && !block.isColFirst)
        ) {
          div.classList.add("pdf-list-item");
          const lines = md.split("\\n");
          let isOrdered = false;
          const items = [];
          const leadLines = [];
          for (let i = 0; i < lines.length; i++) {
            const line = lines[i];
            const tr = line.trim();
            if (!tr || /^\\{:.*?\\}$/.test(tr)) continue;
            const um = line.match(/^(\\s*)[-*+]\\s+(.*)$/);
            const om = line.match(/^(\\s*)\\d+\\.\\s+(.*)$/);
            if (um) {
              const indent = um[1].length;
              items.push({ type: "unordered", level: Math.floor(indent / 2), text: um[2], media: [] });
              continue;
            }
            if (om) {
              if (items.length === 0) isOrdered = true;
              const indent = om[1].length;
              items.push({ type: "ordered", level: Math.floor(indent / 2), text: om[2], media: [] });
              continue;
            }
            if (items.length > 0) {
              const im = tr.match(/^!\\[(.*?)\\]\\((.*?)\\)(?:\\{:?[^}]*\\})?$/);
              if (im) {
                const isGif = /\\.gif(?:\\?|$)/i.test(im[2]);
                items[items.length - 1].media.push('<div class="slide-list-media"><img alt="' + im[1] + '" src="' + im[2] + '" class="' + (isGif ? 'list-item-gif' : 'list-item-img') + '" /></div>');
                continue;
              }
              const hm = tr.match(/^<img\\b[\\s\\S]*?\\/?>$/i);
              if (hm) {
                const cleanTr = tr.replace(/\\s+style="[^"]*"/gi, "");
                items[items.length - 1].media.push('<div class="slide-list-media">' + cleanTr + '</div>');
                continue;
              }
              if (/<video\\b/i.test(tr)) {
                let vHtml = tr;
                if (!/<\\/video>/i.test(vHtml)) {
                  while (i + 1 < lines.length && !/<\\/video>/i.test(vHtml)) {
                    i++;
                    vHtml += " " + lines[i].trim();
                  }
                }
                const isAutoplay = block && block.attributes && block.attributes["custom-slides-autoplay"] === "true";
                const isLoop = block && block.attributes && block.attributes["custom-slides-loop"] === "true";
                const isMuted = block && block.attributes && (block.attributes["custom-slides-muted"] === "true" || isAutoplay);
                const hideControls = block && block.attributes && block.attributes["custom-slides-controls"] === "false";
                if (hideControls) vHtml = vHtml.replace(/\\bcontrols(?:="[^"]*")?/gi, "").trim();
                else if (!vHtml.includes("controls")) vHtml = vHtml.replace("<video", "<video controls");
                if (isAutoplay && !vHtml.includes("autoplay")) vHtml = vHtml.replace("<video", "<video autoplay playsinline");
                if (isLoop && !vHtml.includes("loop")) vHtml = vHtml.replace("<video", "<video loop");
                if (isMuted && !vHtml.includes("muted")) vHtml = vHtml.replace("<video", "<video muted");
                vHtml = vHtml.replace("<video", '<video class="slide-video-player"');
                items[items.length - 1].media.push('<div class="slide-list-media slide-video-container slide-media-container" data-autoplay="' + (isAutoplay ? 'true' : 'false') + '">' + vHtml + '</div>');
                continue;
              }
              items[items.length - 1].text += "\\n" + tr;
            } else {
              leadLines.push(tr);
            }
          }

          if (items.length === 0 && (block && (block.isListItem || block.type === "i")) && !block.isColFirst) {
            items.push({ type: "unordered", level: 0, text: md, media: [] });
            leadLines.length = 0;
          }

          let leadHtml = "";
          if (leadLines.length > 0) {
            const lParts = [];
            const firstL = leadLines[0];
            const fhm = firstL.match(/^(#{1,6})\\s+(.*)$/);
            if (fhm) {
              const lvl = fhm[1].length;
              let th = fhm[2].trim().replace(/\\*\\*(.*?)\\*\\*/g, "<strong>$1</strong>").replace(/\\x60([^\\x60]+)\\x60/g, "<code>$1</code>");
              lParts.push('<h' + lvl + ' class="slide-list-item-title">' + th + '</h' + lvl + '>');
            } else {
              let th = firstL.trim().replace(/\\*\\*(.*?)\\*\\*/g, "<strong>$1</strong>").replace(/\\x60([^\\x60]+)\\x60/g, "<code>$1</code>");
              lParts.push('<p class="slide-list-item-title">' + th + '</p>');
            }
            if (leadLines.length > 1) {
              const dLines = leadLines.slice(1);
              let pL = [];
              const flushLeadP = () => {
                if (pL.length > 0) {
                  let txt = pL.map(l => l.replace(/\\*\\*(.*?)\\*\\*/g, "<strong>$1</strong>").replace(/\\x60([^\\x60]+)\\x60/g, "<code>$1</code>")).join("<br/>");
                  lParts.push('<p class="slide-list-item-desc">' + txt + '</p>');
                  pL = [];
                }
              };
              for (const l of dLines) {
                const hm = l.match(/^(#{1,6})\\s+(.*)$/);
                if (hm) {
                  flushLeadP();
                  const lvl = hm[1].length;
                  let th = hm[2].trim().replace(/\\*\\*(.*?)\\*\\*/g, "<strong>$1</strong>").replace(/\\x60([^\\x60]+)\\x60/g, "<code>$1</code>");
                  lParts.push('<h' + lvl + ' class="slide-list-item-title">' + th + '</h' + lvl + '>');
                } else {
                  pL.push(l);
                }
              }
              flushLeadP();
            }
            leadHtml = lParts.join("\\n") + "\\n";
          }

          const tag = isOrdered ? "ol" : "ul";
          const listCls = isOrdered ? "pdf-list pdf-list--ordered" : "pdf-list pdf-list--unordered";
          const liHtml = items.map(it => {
            const med = it.media && it.media.length ? "\\n" + it.media.join("\\n") : "";
            const lines = (it.text || "").split("\\n").map(l => l.trim()).filter(Boolean);
            const hasHeading = lines.some(l => /^#{1,6}\\s+/.test(l));
            const lvl = it.level || 0;
            const nStyle = lvl > 0 ? ' style="margin-left:' + (lvl * 1.25).toFixed(2) + 'em;' + (it.type === 'unordered' ? 'list-style-type:' + (lvl % 2 === 1 ? 'circle' : 'square') + ' !important;' : '') + '"' : "";
            const nClass = lvl > 0 ? " slide-list-item--nested" : "";
            const clsAttr = nClass ? ' class="' + nClass.trim() + '"' : "";
            if (!hasHeading) {
              let h = lines.map(l => l.replace(/\\*\\*(.*?)\\*\\*/g, "<strong>$1</strong>").replace(/\\x60([^\\x60]+)\\x60/g, "<code>$1</code>")).join("<br/>");
              return '<li' + clsAttr + nStyle + '>' + h + med + '</li>';
            }
            const parts = [];
            let pLines = [];
            const flushP = () => {
              if (pLines.length > 0) {
                let ph = pLines.map(l => l.replace(/\\*\\*(.*?)\\*\\*/g, "<strong>$1</strong>").replace(/\\x60([^\\x60]+)\\x60/g, "<code>$1</code>")).join("<br/>");
                parts.push('<p class="slide-list-item-desc">' + ph + '</p>');
                pLines = [];
              }
            };
            for (const l of lines) {
              const hm = l.match(/^(#{1,6})\\s+(.*)$/);
              if (hm) {
                flushP();
                const hl = hm[1].length;
                let th = hm[2].trim().replace(/\\*\\*(.*?)\\*\\*/g, "<strong>$1</strong>").replace(/\\x60([^\\x60]+)\\x60/g, "<code>$1</code>");
                parts.push('<h' + hl + ' class="slide-list-item-title">' + th + '</h' + hl + '>');
              } else {
                pLines.push(l);
              }
            }
            flushP();
            return '<li' + clsAttr + nStyle + '>' + parts.join("\\n") + med + '</li>';
          }).join("\\n");
          div.innerHTML = leadHtml + '<' + tag + ' class="' + listCls + '">\\n' + liHtml + '\\n</' + tag + '>';
        }
        else {
          // 复合块（包含换行、标题或媒体）高保真解析
          const lines = md.split(/\\r?\\n/);
          const subBlocks = [];
          let current = [];
          for (let i = 0; i < lines.length; i++) {
            const line = lines[i];
            const trimmed = line.trim();
            if (/^#{1,6}\\s+/.test(trimmed)) {
              if (current.length > 0) { subBlocks.push(current.join("\\n")); current = []; }
              subBlocks.push(trimmed);
              continue;
            }
            if (!trimmed) {
              if (current.length > 0) { subBlocks.push(current.join("\\n")); current = []; }
              continue;
            }
            if (/^!\\[.*?\\]\\(.*?\\)$/.test(trimmed)) {
              if (current.length > 0) { subBlocks.push(current.join("\\n")); current = []; }
              subBlocks.push(trimmed);
              continue;
            }
            if (/<video\\b/i.test(trimmed)) {
              if (current.length > 0) { subBlocks.push(current.join("\\n")); current = []; }
              let vRaw = trimmed;
              if (!/<\\/video>/i.test(vRaw)) {
                while (i + 1 < lines.length && !/<\\/video>/i.test(vRaw)) {
                  i++;
                  vRaw += "\\n" + lines[i];
                }
              }
              subBlocks.push(vRaw);
              continue;
            }
            current.push(line);
          }
          if (current.length > 0) subBlocks.push(current.join("\\n"));

          if (subBlocks.length > 1 || (subBlocks.length === 1 && /^#{1,6}\\s+/.test(subBlocks[0].trim()))) {
            let isFirstParagraph = true;
            const htmlParts = subBlocks.map(sub => {
              const t = sub.trim();
              if (!t) return "";
              const hm = t.match(/^(#{1,6})\\s+(.*)$/);
              if (hm) {
                isFirstParagraph = false;
                const hl = hm[1].length;
                let th = hm[2].trim().replace(/\\*\\*(.*?)\\*\\*/g, "<strong>$1</strong>").replace(/\\x60([^\\x60]+)\\x60/g, "<code>$1</code>");
                return '<h' + hl + ' class="slide-list-item-title">' + th + '</h' + hl + '>';
              }
              const im = t.match(/^!\\[(.*?)\\]\\((.*?)\\)$/);
              if (im) {
                return '<div class="slide-media-block slide-media-container slide-list-media"><img alt="' + im[1] + '" src="' + im[2] + '" class="slide-media-img" /></div>';
              }
              if (/<video\\b/i.test(t)) {
                return '<div class="slide-media-block slide-video-container slide-media-container">' + t + '</div>';
              }
              if (isFirstParagraph) {
                isFirstParagraph = false;
                const subLines = t.split(/\\r?\\n/).map(l => l.trim()).filter(Boolean);
                if (subLines.length === 1) {
                  let ph = subLines[0].replace(/\\*\\*(.*?)\\*\\*/g, "<strong>$1</strong>").replace(/\\x60([^\\x60]+)\\x60/g, "<code>$1</code>");
                  return '<p class="slide-list-item-title">' + ph + '</p>';
                }
                let titleHtml = subLines[0].replace(/\\*\\*(.*?)\\*\\*/g, "<strong>$1</strong>").replace(/\\x60([^\\x60]+)\\x60/g, "<code>$1</code>");
                let descHtml = subLines.slice(1).map(l => l.replace(/\\*\\*(.*?)\\*\\*/g, "<strong>$1</strong>").replace(/\\x60([^\\x60]+)\\x60/g, "<code>$1</code>")).join("<br/>");
                return '<p class="slide-list-item-title">' + titleHtml + '</p>\\n<p class="slide-list-item-desc">' + descHtml + '</p>';
              }
              let ph = t.replace(/\\*\\*(.*?)\\*\\*/g, "<strong>$1</strong>").replace(/\\x60([^\\x60]+)\\x60/g, "<code>$1</code>");
              return '<p class="slide-list-item-desc">' + ph + '</p>';
            }).filter(Boolean);
            div.innerHTML = htmlParts.join("\\n");
          } else {
            const imgMatch = md.match(/^!\\[(.*?)\\]\\((.*?)\\)$/);
            if (imgMatch) {
              div.classList.add("slide-media-container", "slide-media-block", "slide-block--image");
              div.innerHTML = '<img alt="' + imgMatch[1] + '" src="' + imgMatch[2] + '" class="slide-media-img" />';
            } else {
              let html = md.replace(/\\*\\*(.*?)\\*\\*/g, "<strong>$1</strong>").replace(/\\x60([^\\x60]+)\\x60/g, "<code>$1</code>");
              const pCls = (block && block.isColFirst) ? ' class="slide-list-item-title"' : '';
              div.innerHTML = "<p" + pCls + ">" + html + "</p>";
            }
          }
        }
        return div;
      }
`}function yg(){return`      function renderSlide(idx, direction) {
        if (slides.length === 0) return;
        currentIndex = Math.max(0, Math.min(idx, slides.length - 1));
        const slide = slides[currentIndex];
        pageNum.textContent = (currentIndex + 1) + " / " + slides.length;

        const pageSp = slide.frontmatter?.spacing;
        const currentSpacing = (pageSp && pageSp !== "inherit") ? pageSp : (data.config?.spacing || "normal");
        container.className = "slide-content layout-" + (slide.frontmatter?.layout || "default") + " spacing-" + currentSpacing;
        if (viewport) viewport.setAttribute("data-spacing", currentSpacing);
        container.innerHTML = "";

        const z = typeof slide.frontmatter?.zoom === "number" && slide.frontmatter.zoom > 0 ? slide.frontmatter.zoom : 1;
        if (z !== 1) {
          container.style.width = (100 / z) + "%";
          container.style.height = (100 / z) + "%";
          container.style.transformOrigin = "top left";
          container.style.transform = "scale(" + z + ")";
        } else {
          container.style.width = "100%";
          container.style.height = "100%";
          container.style.transform = "none";
        }

        function isLightColor(colorStr) {
          if (!colorStr || typeof colorStr !== 'string') return null;
          const s = colorStr.trim().toLowerCase();
          if (!s) return null;
          if (/^(?:https?:\\/\\/|\\/|data:|assets\\/|\\.\\/assets\\/|url\\s*\\()/i.test(s)) return null;
          const lightNamed = ['white', 'snow', 'ivory', 'ghostwhite', 'floralwhite', 'aliceblue', 'whitesmoke', 'seashell', 'beige', 'oldlace', 'linen', 'antiquewhite', 'lightyellow', 'lightcyan', 'papayawhip', 'blanchedalmond', 'cornsilk', 'lavender', 'lavenderblush', 'lemonchiffon', 'honeydew', 'mintcream', 'azure', 'mistyrose', 'wheat', 'lightgoldenrodyellow', 'palegoldenrod', 'gainsboro', 'lightgrey', 'lightgray', 'silver', 'pink', 'lightpink', 'peachpuff', 'navajowhite', 'moccasin', 'bisque', 'khaki', 'palegreen', 'lightgreen', 'lightblue', 'powderblue', 'paleturquoise', 'lightsteelblue', 'thistle', 'yellow', 'cyan', 'aqua'];
          const darkNamed = ['black', 'transparent', 'navy', 'darkblue', 'midnightblue', 'darkslategray', 'darkslategrey', 'maroon', 'darkred', 'darkgreen', 'indigo', 'darkslateblue', 'dimgray', 'dimgrey', 'purple', 'brown', 'olive', 'teal', 'blue', 'darkviolet', 'darkmagenta', 'darkcyan', 'darkolivegreen', 'saddlebrown', 'sienna', 'firebrick', 'crimson', 'mediumblue', 'rebeccapurple'];
          if (lightNamed.includes(s)) return true;
          if (darkNamed.includes(s)) return false;

          function calcLum(r, g, b) {
            return 0.299 * r + 0.587 * g + 0.114 * b;
          }
          function parseHexLum(hexRaw) {
            let hex = hexRaw.startsWith('#') ? hexRaw.slice(1) : hexRaw;
            if (hex.length === 3 || hex.length === 4) hex = hex.slice(0, 3).split('').map(c => c + c).join('');
            if (hex.length >= 6) {
              const r = parseInt(hex.substring(0, 2), 16);
              const g = parseInt(hex.substring(2, 4), 16);
              const b = parseInt(hex.substring(4, 6), 16);
              if (!isNaN(r) && !isNaN(g) && !isNaN(b)) return calcLum(r, g, b);
            }
            return null;
          }
          function parseRgbLum(rgbStr) {
            const m = rgbStr.match(/rgba?\\s*\\(\\s*(\\d+(?:\\.\\d+)?)\\s*[,\\s]\\s*(\\d+(?:\\.\\d+)?)\\s*[,\\s]\\s*(\\d+(?:\\.\\d+)?)(?:\\s*[,\\/]\\s*([0-9.]+%?))?/i);
            if (!m) return null;
            const r = Number(m[1]), g = Number(m[2]), b = Number(m[3]);
            if (isNaN(r) || isNaN(g) || isNaN(b)) return null;
            if (m[4] !== undefined) {
              const a = m[4].endsWith('%') ? parseFloat(m[4]) / 100 : parseFloat(m[4]);
              if (!isNaN(a) && a <= 0.05) return null;
            }
            return calcLum(r, g, b);
          }
          function parseHslLum(hslStr) {
            const m = hslStr.match(/hsla?\\s*\\(\\s*([0-9.]+)(?:deg)?\\s*[,\\s]\\s*([0-9.]+)%\\s*[,\\s]\\s*([0-9.]+)%(?:\\s*[,\\/]\\s*([0-9.]+%?))?/i);
            if (!m) return null;
            if (m[4] !== undefined) {
              const a = m[4].endsWith('%') ? parseFloat(m[4]) / 100 : parseFloat(m[4]);
              if (!isNaN(a) && a <= 0.05) return null;
            }
            const h = (((Number(m[1]) % 360) + 360) % 360) / 360;
            const sat = Math.max(0, Math.min(1, Number(m[2]) / 100));
            const lig = Math.max(0, Math.min(1, Number(m[3]) / 100));
            let r, g, b;
            if (sat === 0) {
              r = g = b = lig * 255;
            } else {
              const q = lig < 0.5 ? lig * (1 + sat) : lig + sat - lig * sat;
              const p = 2 * lig - q;
              const hue2rgb = (t) => {
                let tt = t;
                if (tt < 0) tt += 1;
                if (tt > 1) tt -= 1;
                if (tt < 1 / 6) return p + (q - p) * 6 * tt;
                if (tt < 1 / 2) return q;
                if (tt < 2 / 3) return p + (q - p) * (2 / 3 - tt) * 6;
                return p;
              };
              r = hue2rgb(h + 1 / 3) * 255;
              g = hue2rgb(h) * 255;
              b = hue2rgb(h - 1 / 3) * 255;
            }
            return calcLum(r, g, b);
          }

          if (s.startsWith('#')) {
            const lum = parseHexLum(s);
            return lum === null ? null : lum > 140;
          }
          if (/^rgba?\\s*\\(/i.test(s)) {
            const lum = parseRgbLum(s);
            return lum === null ? null : lum > 140;
          }
          if (/^hsla?\\s*\\(/i.test(s)) {
            const lum = parseHslLum(s);
            return lum === null ? null : lum > 140;
          }
          if (/(?:linear|radial|conic)-gradient\\s*\\(/i.test(s)) {
            const luminances = [];
            const hexMatches = s.match(/#(?:[0-9a-f]{8}|[0-9a-f]{6}|[0-9a-f]{4}|[0-9a-f]{3})\\b/gi);
            if (hexMatches) {
              for (const h of hexMatches) {
                const lum = parseHexLum(h);
                if (lum !== null) luminances.push(lum);
              }
            }
            const rgbMatches = s.match(/rgba?\\s*\\([^)]+\\)/gi);
            if (rgbMatches) {
              for (const r of rgbMatches) {
                const lum = parseRgbLum(r);
                if (lum !== null) luminances.push(lum);
              }
            }
            const hslMatches = s.match(/hsla?\\s*\\([^)]+\\)/gi);
            if (hslMatches) {
              for (const h of hslMatches) {
                const lum = parseHslLum(h);
                if (lum !== null) luminances.push(lum);
              }
            }
            const stripped = s.replace(/#[0-9a-f]+|rgba?\\([^)]+\\)|hsla?\\([^)]+\\)/gi, ' ');
            const wordMatches = stripped.match(/\\b[a-z]+\\b/gi);
            if (wordMatches) {
              for (const w of wordMatches) {
                if (w === 'transparent') continue;
                if (lightNamed.includes(w)) luminances.push(240);
                else if (darkNamed.includes(w)) luminances.push(20);
              }
            }
            if (luminances.length > 0) {
              const avg = luminances.reduce((acc, v) => acc + v, 0) / luminances.length;
              return avg > 140;
            }
            if (/\\btransparent\\b/.test(s)) return false;
          }
          return null;
        }

        const slideBg = slide.frontmatter?.background || (data.config && data.config.background);
        const isLightBg = isLightColor(slideBg);
        const curTheme = data.config?.theme || "default";
        if (slideBg) {
          if (/^(http|\\/|data:|assets\\/)/.test(slideBg)) {
            container.style.backgroundImage = 'url("' + slideBg + '")';
            container.style.backgroundSize = "cover";
            container.style.backgroundPosition = "center";
          } else {
            container.style.backgroundImage = "none";
            container.style.background = slideBg;
          }
        } else {
          container.style.backgroundImage = "none";
          container.style.background = "";
        }
        if (isLightBg === true) {
          if (viewport) viewport.setAttribute("data-theme", "light");
          const textColor = curTheme === "apple-basic" ? "#000000" : (curTheme === "seriph" ? "#231f1d" : "#0f172a");
          container.style.color = textColor;
          container.style.setProperty("--slide-text", textColor);
        } else if (isLightBg === false) {
          if (viewport) viewport.setAttribute("data-theme", "dark");
          const textColor = curTheme === "apple-basic" ? "#ffffff" : (curTheme === "seriph" ? "#f5f2eb" : "#f1f5f9");
          container.style.color = textColor;
          container.style.setProperty("--slide-text", textColor);
        } else {
          const fallbackSchema = (data.config?.colorSchema === "light" || data.config?.colorSchema === "dark")
            ? data.config.colorSchema
            : (data.config?.hostThemeMode || null);
          if (viewport) {
            if (fallbackSchema === "light" || fallbackSchema === "dark") {
              viewport.setAttribute("data-theme", fallbackSchema);
            } else {
              viewport.removeAttribute("data-theme");
            }
          }
          container.style.color = "";
          container.style.removeProperty("--slide-text");
        }

        maskOverlayEl = null;
        maskDividerEl = null;
        const maskDir = slide.frontmatter?.mask;
        const isClock = maskDir === "clockwise" || maskDir === "counter-clockwise" || maskDir === "cw" || maskDir === "ccw";
        if (maskDir === "down" || maskDir === "right" || isClock) {
          const isClover = slide.frontmatter?.layout === "clover";
          const ratioInfo = parseMaskRatio(slide.frontmatter.maskRatio, (isClock || isClover) ? 4 : 2);
          const isInitRev = slide.frontmatter.maskInitial === "revealed";
          currentMaskConfig = {
            direction: isClock ? ((maskDir === "cw" || maskDir === "clockwise") ? "clockwise" : "counter-clockwise") : maskDir,
            isClock: isClock,
            totalSteps: isInitRev ? Math.max(0, ratioInfo.steps - 1) : ratioInfo.steps,
            rawSteps: ratioInfo.steps,
            breakpoints: ratioInfo.breakpoints,
            isInitialRevealed: isInitRev,
            style: slide.frontmatter.maskStyle || "solid",
          };
          // FSM-9 优化：后退进入历史页时，遮罩与逐步呈现处于全部揭开完成状态，避免上一页重新变为全黑遮盖
          currentMaskStep = (direction === "backward") ? currentMaskConfig.totalSteps : 0;
        } else {
          currentMaskConfig = null;
          currentMaskStep = 0;
        }

        function createMaskElements() {
          if (!currentMaskConfig) return null;
          const layer = document.createElement("div");
          layer.className = "slides-mask-layer slides-mask-layer--" + currentMaskConfig.style + " slides-mask-layer--" + currentMaskConfig.direction + (currentMaskConfig.isClock ? " slides-mask-layer--clock" : "");
          const overlay = document.createElement("div");
          overlay.className = "slides-mask-overlay";
          const divider = document.createElement("div");
          divider.className = "slides-mask-divider-line" + (currentMaskConfig.isClock ? " slides-mask-divider-line--clock" : "");
          divider.style.opacity = "0";
          if (currentMaskConfig.isClock) {
            const isCw = currentMaskConfig.direction === "clockwise" || currentMaskConfig.direction === "cw";
            divider.style.transform = isCw ? "translateY(-50%) rotate(-180deg)" : "translateY(-50%) rotate(-90deg)";
          }
          layer.appendChild(overlay);
          layer.appendChild(divider);
          maskLayerEl = layer;
          maskOverlayEl = overlay;
          maskDividerEl = divider;
          return { layer, overlay, divider };
        }

        if (slide.frontmatter?.layout === "two-cols") {
          const bodyWrap = document.createElement("div");
          bodyWrap.className = "slides-mask-body-container" + (currentMaskConfig ? " slides-mask-body-container--has-mask" : "");
          bodyWrap.style.display = "flex";
          bodyWrap.style.flexDirection = "row";
          bodyWrap.style.gap = "2rem";
          bodyWrap.style.width = "100%";
          bodyWrap.style.height = "100%";

          const leftCol = document.createElement("div");
          leftCol.className = "two-cols-left";
          const rightCol = document.createElement("div");
          rightCol.className = "two-cols-right";

          const blocks = (slide.blocks || []).filter(b => b.slot !== "slot-divider-right");
          let leftList = [];
          let rightList = [];
          for (const block of blocks) {
            if (block.slot === "right") rightList.push(block);
            else leftList.push(block);
          }
          leftList = cleanColList(leftList);
          rightList = cleanColList(rightList);
          const isCover = slide.frontmatter?.layout === "cover";
          const leftFirstH = !isCover ? leftList.find(isHeadingBlock) : null;
          const rightFirstH = !isCover ? rightList.find(isHeadingBlock) : null;
          for (const b of leftList) leftCol.appendChild(renderBlock(b, b === leftFirstH ? "slides-col-first-heading-block" : ""));
          for (const b of rightList) rightCol.appendChild(renderBlock(b, b === rightFirstH ? "slides-col-first-heading-block" : ""));
          bodyWrap.appendChild(leftCol);
          bodyWrap.appendChild(rightCol);

          const maskEls = createMaskElements();
          if (maskEls) {
            bodyWrap.appendChild(maskEls.layer);
          }
          container.appendChild(bodyWrap);
        } else if (slide.frontmatter?.layout === "cols-header" || slide.frontmatter?.layout === "two-cols-header" || slide.frontmatter?.layout === "three-cols-header" || slide.frontmatter?.layout === "clover") {
          const isCover = slide.frontmatter?.layout === "cover";
          const isClover = slide.frontmatter?.layout === "clover";
          const blocks = (slide.blocks || []).filter(b => b.slot !== "slot-divider-right");
          let headerBlocks = blocks.filter(b => b.slot === "header");
          if (headerBlocks.length === 0 && blocks.length > 0) {
            const candidate = blocks.find(b => b.type === "h" && (!b.slot || b.slot === "default"));
            if (candidate) headerBlocks = [candidate];
          }
          const rem = blocks.filter(b => !headerBlocks.includes(b));

          let targetCols = isClover ? 4 : 2;
          if (isClover) {
            targetCols = 4;
          } else if (slide.frontmatter?.layout === "three-cols-header") {
            targetCols = 3;
          } else if (slide.frontmatter?.layout === "two-cols-header") {
            targetCols = 2;
          } else {
            let maxCol = 0;
            for (const b of rem) {
              const m = (b.slot || "").match(/^col-(d+)$/i);
              if (m) maxCol = Math.max(maxCol, parseInt(m[1], 10));
            }
            if (maxCol >= 2) {
              targetCols = maxCol;
            } else if (slide.frontmatter?.layoutRatio) {
              const r = slide.frontmatter.layoutRatio.trim();
              if (r.includes(":")) {
                const parts = r.split(":").map(p => parseFloat(p.trim())).filter(n => !isNaN(n) && n > 0);
                if (parts.length >= 2) targetCols = parts.length;
              }
            }
          }

          const hasColSlots = rem.some(b => b.slot && /^col-d+$/i.test(b.slot));
          const isSuperBlockCols = isClover || hasColSlots;

          const containerDiv = document.createElement("div");
          containerDiv.className = (isClover ? "layout-clover-container" : ("layout-cols-header-container " + (targetCols === 2 ? "layout-two-cols-header-container" : (targetCols === 3 ? "layout-three-cols-header-container" : "")))) + (isSuperBlockCols ? " has-superblock-cols" : "");
          const headerDiv = document.createElement("div");
          headerDiv.className = "layout-header-section";
          const gridDiv = document.createElement("div");
          gridDiv.className = (isClover ? "layout-clover-grid pdf-clover-wrapper" : ("layout-cols-wrapper layout-cols-grid " + (targetCols === 2 ? "pdf-two-cols-wrapper layout-two-cols-grid" : (targetCols === 3 ? "pdf-three-cols-wrapper layout-three-cols-grid" : "")))) + (isSuperBlockCols ? " has-superblock-cols" : "") + (currentMaskConfig ? " slides-mask-body-container slides-mask-body-container--has-mask" : "");

          const gridCols = isClover ? "repeat(2, minmax(0, 1fr))" : parseRatioToGridCols(slide.frontmatter?.layoutRatio, targetCols);
          if (gridCols) gridDiv.style.gridTemplateColumns = gridCols;
          if (isClover) gridDiv.style.gridTemplateRows = "repeat(2, minmax(0, 1fr))";

          let colsList = [];
          for (let i = 0; i < targetCols; i++) colsList.push([]);
          const hasExplicitCols = rem.some(b => b.slot && (b.slot.startsWith("col-") || b.slot === "left" || b.slot === "right" || b.slot === "center"));
          if (hasExplicitCols && rem.length > 1) {
            for (const b of rem) {
              let idx = 0;
              if (b.slot === "left" || b.slot === "col-1") idx = 0;
              else if (b.slot === "center" || b.slot === "col-2") idx = 1;
              else if (b.slot === "right") idx = targetCols === 2 ? 1 : targetCols - 1;
              else {
                const m = (b.slot || "").match(/^col-(d+)$/i);
                if (m) idx = Math.min(targetCols - 1, Math.max(0, parseInt(m[1], 10) - 1));
              }
              colsList[idx].push(b);
            }
            const hasExplicitColN = rem.some(b => /^col-d+$/i.test((b.slot || "").trim()));
            if (!hasExplicitColN && colsList[0].length === 0) {
              const nonEmptyCols = colsList.filter(c => c.length > 0);
              if (nonEmptyCols.length === 1) {
                colsList = [nonEmptyCols[0], ...Array.from({ length: targetCols - 1 }, () => [])];
              }
            }
          } else if (rem.length === 1) {
            colsList[0] = [rem[0]];
          } else {
            let cur = 0;
            for (let i = 0; i < targetCols; i++) {
              const remainingCols = targetCols - i;
              const remainingItems = rem.length - cur;
              const take = Math.ceil(remainingItems / remainingCols);
              colsList[i] = rem.slice(cur, cur + take);
              cur += take;
            }
          }

          const headerFirstH = !isCover ? headerBlocks.find(isHeadingBlock) : null;
          for (const b of headerBlocks) headerDiv.appendChild(renderBlock(b, b === headerFirstH ? "slides-page-first-heading-block" : ""));
          containerDiv.appendChild(headerDiv);

          colsList.forEach((colBlocks, idx) => {
            const colDiv = document.createElement("div");
            colDiv.className = "pdf-col pdf-col--" + (idx + 1) + " col-" + (idx + 1) + (targetCols === 2 && idx === 0 ? " pdf-col--left" : "") + (targetCols === 2 && idx === 1 ? " pdf-col--right" : "");
            const cleaned = cleanColList(colBlocks);
            const colFirstH = !isCover ? (cleaned.find(isHeadingBlock) || cleaned[0]) : null;
            for (const b of cleaned) colDiv.appendChild(renderBlock(b, b === colFirstH ? "slides-col-first-heading-block" : ""));
            gridDiv.appendChild(colDiv);
          });

          const maskEls = createMaskElements();
          if (maskEls) {
            gridDiv.appendChild(maskEls.layer);
          }

          containerDiv.appendChild(gridDiv);
          container.appendChild(containerDiv);
        } else if (slide.frontmatter?.layout === "image-right" || slide.frontmatter?.layout === "image-left") {
          const isImageRight = slide.frontmatter?.layout === "image-right";
          const isCover = slide.frontmatter?.layout === "cover";
          const allBlocks = slide.blocks || [];
          const pageFirstH = !isCover ? allBlocks.find(isHeadingBlock) : null;

          if (pageFirstH) {
            container.appendChild(renderBlock(pageFirstH, "slides-page-first-heading-block"));
          }

          const bodyWrap = document.createElement("div");
          bodyWrap.className = "slides-mask-body-container" + (currentMaskConfig ? " slides-mask-body-container--has-mask" : "");
          bodyWrap.style.display = "flex";
          bodyWrap.style.flexDirection = isImageRight ? "row" : "row-reverse";
          bodyWrap.style.gap = "2rem";
          bodyWrap.style.width = "100%";
          bodyWrap.style.height = "100%";
          bodyWrap.style.minHeight = "0";
          bodyWrap.style.flex = "1";

          const contentCol = document.createElement("div");
          contentCol.className = isImageRight ? "image-right-content" : "image-left-content";

          for (const block of allBlocks) {
            if (block === pageFirstH) continue;
            contentCol.appendChild(renderBlock(block, ""));
          }

          const imgCol = document.createElement("div");
          imgCol.className = isImageRight ? "image-right-img-container" : "image-left-img-container";
          const img = document.createElement("img");
          img.className = isImageRight ? "image-right-img" : "image-left-img";
          img.src = slide.frontmatter?.image || slide.frontmatter?.background || "";
          img.alt = "Slide cover";
          img.onerror = function() {
            this.src = "https://fastly.jsdelivr.net/gh/slidevjs/slidev-covers@main/static/2HmfbSpvcos.webp";
          };
          imgCol.appendChild(img);

          bodyWrap.appendChild(contentCol);
          bodyWrap.appendChild(imgCol);

          const maskEls = createMaskElements();
          if (maskEls) {
            bodyWrap.appendChild(maskEls.layer);
          }
          container.appendChild(bodyWrap);
        } else if (slide.frontmatter?.layout === "fact") {
          const validBlocks = (slide.blocks || []).filter(b => b.slot !== "slot-divider-right" && (b.rawMarkdown || b.content || "").trim());
          let headerBlocks = [];
          const explicitHeader = validBlocks.filter(b => b.slot === "header");
          const isFirstH = validBlocks.length >= 2 && isHeadingBlock(validBlocks[0]);
          const hasSubsequentList = validBlocks.length >= 2 && (validBlocks[1].type === "l" || (validBlocks[1].children && validBlocks[1].children.length > 0) || /^(s*)(?:[-*+]|d+.)s+/m.test(validBlocks[1].rawMarkdown || ""));

          if (explicitHeader.length > 0) {
            headerBlocks = explicitHeader;
          } else if (isFirstH && (hasSubsequentList || validBlocks.length >= 3)) {
            headerBlocks = [validBlocks[0]];
          }

          const rem = validBlocks.filter(b => !headerBlocks.includes(b));
          let cards = [];

          const rawLines = [];
          if (rem.length === 1 && rem[0].children && rem[0].children.length >= 1) {
            for (const c of rem[0].children) rawLines.push((c.rawMarkdown || c.content || "").trim());
          } else if (rem.length === 1) {
            const lines = (rem[0].rawMarkdown || rem[0].content || "").trim().split(/[\\r\\n]+/);
            for (const line of lines) {
              if (/^[\\s]*(?:[-*+]|\\d+\\.)[\\s]+/.test(line)) rawLines.push(line.trim());
            }
          }

          if (rawLines.length > 0) {
            cards = rawLines.map((line) => {
              const cl = cleanCardListItemMarkdown(line).trim();
              const m = cl.match(/^([^\\n:：]+?)(?:[\\s]*[:：][\\s]*)([\\s\\S]+)$/);
              return m ? { val: m[1].trim(), lbl: m[2].trim() } : { val: cl, lbl: "" };
            });
          } else if (rem.length >= 2 && rem.length % 2 === 0) {
            for (let i = 0; i < rem.length; i += 2) {
              cards.push({
                val: cleanCardListItemMarkdown(rem[i].rawMarkdown || rem[i].content || "").trim(),
                lbl: cleanCardListItemMarkdown(rem[i + 1].rawMarkdown || rem[i + 1].content || "").trim(),
              });
            }
          } else if (rem.length > 0) {
            const firstCl = cleanCardListItemMarkdown(rem[0].rawMarkdown || rem[0].content || "").trim();
            const m = firstCl.match(/^([^\\n:：]+?)(?:[\\s]*[:：][\\s]*)([\\s\\S]+)$/);
            if (m) cards.push({ val: m[1].trim(), lbl: m[2].trim() });
            else cards.push({ val: firstCl, lbl: rem.slice(1).map(b => cleanCardListItemMarkdown(b.rawMarkdown || b.content || "").trim()).join("\\n") });
          }

          const colsCount = Math.max(1, Math.min(4, cards.length));
          const factContainer = document.createElement("div");
          factContainer.className = "layout-fact-container layout-fact-cols-" + colsCount;
          factContainer.style.setProperty("--fact-cols", String(colsCount));

          const glow = document.createElement("div");
          glow.className = "fact-hero-glow";
          glow.setAttribute("aria-hidden", "true");
          factContainer.appendChild(glow);

          if (headerBlocks.length > 0) {
            const headerDiv = document.createElement("div");
            headerDiv.className = "layout-header-section";
            for (const hb of headerBlocks) {
              headerDiv.appendChild(renderBlock(hb, "slides-page-first-heading-block"));
            }
            factContainer.appendChild(headerDiv);
          }

          const box = document.createElement("div");
          box.className = "fact-content-box fact-stats-grid fact-stats-grid--cols-" + colsCount;

          cards.forEach((c) => {
            const cardEl = document.createElement("div");
            cardEl.className = "fact-stat-card";

            const valWrap = document.createElement("div");
            valWrap.className = "fact-value-wrapper fact-value-box";
            const valText = document.createElement("div");
            valText.className = "fact-value-text";
            valText.textContent = c.val;
            valWrap.appendChild(valText);
            cardEl.appendChild(valWrap);

            if (c.lbl) {
              const divLine = document.createElement("div");
              divLine.className = "fact-divider-line";
              cardEl.appendChild(divLine);

              const lblWrap = document.createElement("div");
              lblWrap.className = "fact-label-wrapper fact-label-box";
              const lblText = document.createElement("div");
              lblText.className = "fact-label-text";
              lblText.textContent = c.lbl;
              lblWrap.appendChild(lblText);
              cardEl.appendChild(lblWrap);
            }

            box.appendChild(cardEl);
          });

          factContainer.appendChild(box);
          container.appendChild(factContainer);
        } else if (slide.frontmatter?.layout === "timeline" || slide.frontmatter?.layout === "steps") {
          const blocks = (slide.blocks || []).filter(b => b.slot !== "slot-divider-right");
          let headerBlocks = blocks.filter(b => b.slot === "header");
          if (headerBlocks.length === 0 && blocks.length > 0) {
            const candidate = blocks.find(b => b.type === "h" && (!b.slot || b.slot === "default"));
            if (candidate) headerBlocks = [candidate];
          }
          const rem = blocks.filter(b => !headerBlocks.includes(b));

          const tlContainer = document.createElement("div");
          tlContainer.className = "layout-timeline-container layout-steps-container";

          if (headerBlocks.length > 0) {
            const headerDiv = document.createElement("div");
            headerDiv.className = "layout-header-section";
            for (const hb of headerBlocks) {
              headerDiv.appendChild(renderBlock(hb, "slides-page-first-heading-block"));
            }
            tlContainer.appendChild(headerDiv);
          }

          let stepItems = rem;
          if (rem.length === 1 && rem[0].children && rem[0].children.length >= 2) {
            stepItems = rem[0].children;
          }

          const track = document.createElement("div");
          track.className = "timeline-track-wrapper";
          track.style.setProperty("--timeline-steps", String(Math.max(1, Math.min(6, stepItems.length))));

          stepItems.forEach((item, idx) => {
            const stepNum = idx + 1;
            const itemEl = document.createElement("div");
            itemEl.className = "timeline-step-item";
            itemEl.style.setProperty("--step-index", String(stepNum));

            const nodeContainer = document.createElement("div");
            nodeContainer.className = "timeline-node-container";

            const badge = document.createElement("div");
            badge.className = "timeline-node-badge";
            badge.textContent = String(stepNum);
            nodeContainer.appendChild(badge);

            if (idx < stepItems.length - 1) {
              const line = document.createElement("div");
              line.className = "timeline-connector-line";
              nodeContainer.appendChild(line);
            }
            itemEl.appendChild(nodeContainer);

            const contentEl = document.createElement("div");
            contentEl.className = "timeline-step-content";
            contentEl.appendChild(renderBlock(item, ""));
            itemEl.appendChild(contentEl);

            track.appendChild(itemEl);
          });

          tlContainer.appendChild(track);
          container.appendChild(tlContainer);
        } else {
          const isCover = slide.frontmatter?.layout === "cover";
          const validBlocks = (slide.blocks || []).filter(b => b.slot !== "slot-divider-right");
          const pageFirstH = !isCover ? validBlocks.find(isHeadingBlock) : null;

          if (pageFirstH) {
            container.appendChild(renderBlock(pageFirstH, "slides-page-first-heading-block"));
          }

          const bodyWrap = document.createElement("div");
          bodyWrap.className = "slides-mask-body-container" + (currentMaskConfig ? " slides-mask-body-container--has-mask" : "");

          for (const block of validBlocks) {
            if (block === pageFirstH) continue;
            bodyWrap.appendChild(renderBlock(block, ""));
          }

          const maskEls = createMaskElements();
          if (maskEls) {
            bodyWrap.appendChild(maskEls.layer);
          }
          container.appendChild(bodyWrap);
        }

        updateMaskVisual();
        if (currentMaskConfig && maskLayerEl) {
          requestAnimationFrame(() => {
            if (maskLayerEl) void maskLayerEl.offsetHeight;
          });
        }

        function syncAutoplayVideos() {
          const doSync = () => {
            const videos = container.querySelectorAll("video");
            videos.forEach((v) => {
              const box = v.closest("[data-autoplay]");
              const isAuto = v.hasAttribute("autoplay") || v.autoplay || (box && box.getAttribute("data-autoplay") === "true");
              if (isAuto) {
                v.muted = true;
                v.defaultMuted = true;
                v.setAttribute("muted", "");
                v.playsInline = true;
                v.setAttribute("playsinline", "");
                const playFn = () => {
                  if (!v.paused) return;
                  v.muted = true;
                  v.defaultMuted = true;
                  const p = v.play();
                  if (p !== undefined) {
                    p.catch(() => {
                      v.muted = true;
                      v.defaultMuted = true;
                      setTimeout(() => { if (v.paused) v.play().catch(() => {}); }, 150);
                    });
                  }
                };
                playFn();
                if (!v.__autoplayBound) {
                  v.__autoplayBound = true;
                  v.addEventListener("loadedmetadata", playFn);
                  v.addEventListener("canplay", playFn);
                }
              }
            });
          };
          setTimeout(doSync, 60);
          setTimeout(doSync, 200);
        }
        syncAutoplayVideos();
      }

      // Lightbox 控制逻辑
      const lightbox = document.getElementById("slides-lightbox");
      const lightboxContent = document.getElementById("lightbox-content");
      const lightboxClose = document.getElementById("lightbox-close");
      let isLightboxOpen = false;

`}function bg(){return`      let lightboxScale = 1.0;
      let lightboxTranslateX = 0;
      let lightboxTranslateY = 0;
      let isLightboxDragging = false;
      let lightboxDragStartX = 0;
      let lightboxDragStartY = 0;
      let lightboxInitialTx = 0;
      let lightboxInitialTy = 0;
      let lightboxHasMoved = false;
      let lightboxMediaType = "";

      function updateLightboxImgTransform(animate) {
        if (!lightboxContent) return;
        const img = lightboxContent.querySelector(".slides-lightbox-img");
        if (!img) return;
        img.style.transformOrigin = "center center";
        img.style.transform = "translate(" + lightboxTranslateX + "px, " + lightboxTranslateY + "px) scale(" + lightboxScale + ")";
        img.style.transition = animate ? "transform 0.12s cubic-bezier(0.16, 1, 0.3, 1)" : "none";
        img.style.cursor = lightboxScale > 1.0 ? (isLightboxDragging ? "grabbing" : "grab") : "zoom-in";
      }

      function resetLightboxZoom() {
        lightboxScale = 1.0;
        lightboxTranslateX = 0;
        lightboxTranslateY = 0;
        isLightboxDragging = false;
        lightboxHasMoved = false;
        updateLightboxImgTransform(false);
      }

      function openLightbox(type, src, alt) {
        if (!lightbox || !lightboxContent) return;
        lightboxContent.innerHTML = "";
        lightboxMediaType = type;
        resetLightboxZoom();
        if (type === "video") {
          const v = document.createElement("video");
          v.className = "slides-lightbox-video";
          v.src = src;
          v.controls = true;
          v.autoplay = true;
          v.playsInline = true;
          lightboxContent.appendChild(v);
        } else {
          const img = document.createElement("img");
          img.className = "slides-lightbox-img";
          img.src = src;
          img.alt = alt || "";
          lightboxContent.appendChild(img);
          updateLightboxImgTransform(false);
        }
        lightbox.classList.add("active");
        isLightboxOpen = true;
      }

      function closeLightbox() {
        if (!lightbox) return;
        const v = lightbox.querySelector("video");
        if (v) v.pause();
        lightbox.classList.remove("active");
        if (lightboxContent) lightboxContent.innerHTML = "";
        isLightboxOpen = false;
        lightboxMediaType = "";
        resetLightboxZoom();
      }

      function handleLightboxWheel(e) {
        if (!lightboxContent || lightboxMediaType !== "image") return;
        const img = lightboxContent.querySelector(".slides-lightbox-img");
        if (!img) return;
        e.preventDefault();
        e.stopPropagation();
        if (Math.abs(e.deltaY) < 1) return;

        const factor = e.deltaY < 0 ? 1.2 : 1 / 1.2;
        const currentScale = lightboxScale;
        let nextScale = currentScale * factor;

        if (nextScale <= 1.02) {
          resetLightboxZoom();
          return;
        }
        if (nextScale > 5.0) {
          nextScale = 5.0;
        }

        const rect = img.getBoundingClientRect();
        const currentCenterX = rect.left + rect.width / 2;
        const currentCenterY = rect.top + rect.height / 2;
        const origCenterX = currentCenterX - lightboxTranslateX;
        const origCenterY = currentCenterY - lightboxTranslateY;

        const nextTx = (e.clientX - origCenterX) * (1 - nextScale / currentScale) + lightboxTranslateX * (nextScale / currentScale);
        const nextTy = (e.clientY - origCenterY) * (1 - nextScale / currentScale) + lightboxTranslateY * (nextScale / currentScale);

        lightboxTranslateX = Math.round(nextTx * 10) / 10;
        lightboxTranslateY = Math.round(nextTy * 10) / 10;
        lightboxScale = Math.round(nextScale * 1000) / 1000;
        updateLightboxImgTransform(true);
      }

      if (lightboxContent) {
        lightboxContent.addEventListener("pointerdown", (e) => {
          if (e.button !== 0 || lightboxMediaType !== "image" || lightboxScale <= 1.0) return;
          const img = lightboxContent.querySelector(".slides-lightbox-img");
          if (!img || (e.target !== img && !img.contains(e.target))) return;
          e.preventDefault();
          e.stopPropagation();
          isLightboxDragging = true;
          lightboxDragStartX = e.clientX;
          lightboxDragStartY = e.clientY;
          lightboxInitialTx = lightboxTranslateX;
          lightboxInitialTy = lightboxTranslateY;
          lightboxHasMoved = false;
          if (img.setPointerCapture) {
            try { img.setPointerCapture(e.pointerId); } catch (_) {}
          }
          updateLightboxImgTransform(false);
        });

        window.addEventListener("pointermove", (e) => {
          if (!isLightboxDragging || lightboxMediaType !== "image") return;
          e.preventDefault();
          e.stopPropagation();
          const dx = e.clientX - lightboxDragStartX;
          const dy = e.clientY - lightboxDragStartY;
          if (Math.abs(dx) > 3 || Math.abs(dy) > 3) {
            lightboxHasMoved = true;
          }
          lightboxTranslateX = Math.round((lightboxInitialTx + dx) * 10) / 10;
          lightboxTranslateY = Math.round((lightboxInitialTy + dy) * 10) / 10;
          updateLightboxImgTransform(false);
        });

        const onLightboxPointerEnd = (e) => {
          if (!isLightboxDragging) return;
          isLightboxDragging = false;
          const img = lightboxContent ? lightboxContent.querySelector(".slides-lightbox-img") : null;
          if (img && img.releasePointerCapture) {
            try { img.releasePointerCapture(e.pointerId); } catch (_) {}
          }
          updateLightboxImgTransform(false);
        };
        window.addEventListener("pointerup", onLightboxPointerEnd);
        window.addEventListener("pointercancel", onLightboxPointerEnd);

        lightboxContent.addEventListener("dblclick", (e) => {
          if (lightboxMediaType !== "image") return;
          const img = lightboxContent.querySelector(".slides-lightbox-img");
          if (!img || (e.target !== img && !img.contains(e.target))) return;
          e.preventDefault();
          e.stopPropagation();
          if (lightboxScale > 1.05 || lightboxTranslateX !== 0 || lightboxTranslateY !== 0) {
            resetLightboxZoom();
          } else {
            const targetScale = 2.0;
            const rect = img.getBoundingClientRect();
            const currentCenterX = rect.left + rect.width / 2;
            const currentCenterY = rect.top + rect.height / 2;
            const origCenterX = currentCenterX - lightboxTranslateX;
            const origCenterY = currentCenterY - lightboxTranslateY;
            lightboxTranslateX = Math.round(((e.clientX - origCenterX) * (1 - targetScale / 1.0)) * 10) / 10;
            lightboxTranslateY = Math.round(((e.clientY - origCenterY) * (1 - targetScale / 1.0)) * 10) / 10;
            lightboxScale = targetScale;
            updateLightboxImgTransform(true);
          }
        });
      }

      if (lightboxClose) {
        lightboxClose.addEventListener("click", (e) => {
          e.stopPropagation();
          closeLightbox();
        });
      }
      if (lightbox) {
        lightbox.addEventListener("click", (e) => {
          if (e.target === lightbox || e.target === lightboxClose) {
            if (lightboxHasMoved) {
              lightboxHasMoved = false;
              return;
            }
            e.stopPropagation();
            closeLightbox();
          }
        });
      }

      btnPrev.addEventListener("click", () => goPrev());
      btnNext.addEventListener("click", () => goNext());
      btnFullscreen.addEventListener("click", () => {
        if (!document.fullscreenElement) {
          document.documentElement.requestFullscreen().then(() => updateScale()).catch(() => {});
        } else {
          document.exitFullscreen().then(() => updateScale()).catch(() => {});
        }
      });

      // 「数字+回车」跳页输入状态：数字缓冲实时回显，Esc/超时清空，越界红色抖动提示
      let jumpDisplay = "";
      let jumpInvalid = false;
      let jumpIdleTimer = null;
      let jumpFlashTimer = null;

`}function vg(){return`      function hideJumpIndicator() {
        jumpDisplay = "";
        jumpInvalid = false;
        jumpBadge.style.display = "none";
        jumpBadge.classList.remove("is-invalid");
        if (jumpIdleTimer) { clearTimeout(jumpIdleTimer); jumpIdleTimer = null; }
        if (jumpFlashTimer) { clearTimeout(jumpFlashTimer); jumpFlashTimer = null; }
      }

      function renderJumpBadge() {
        jumpBadge.textContent = jumpDisplay;
        jumpBadge.style.display = jumpDisplay ? "block" : "none";
        jumpBadge.classList.toggle("is-invalid", jumpInvalid);
      }

      function armJumpIdleTimer() {
        if (jumpIdleTimer) clearTimeout(jumpIdleTimer);
        jumpIdleTimer = setTimeout(hideJumpIndicator, 1500);
      }

      function flashJumpInvalid() {
        if (jumpIdleTimer) { clearTimeout(jumpIdleTimer); jumpIdleTimer = null; }
        jumpInvalid = true;
        renderJumpBadge();
        if (jumpFlashTimer) clearTimeout(jumpFlashTimer);
        jumpFlashTimer = setTimeout(hideJumpIndicator, 500);
      }

      function isEditableKeyTarget(t) {
        if (!t || !t.tagName) return false;
        return t.tagName === "INPUT" || t.tagName === "TEXTAREA" || t.tagName === "SELECT" || t.isContentEditable === true;
      }

`}function kg(){return`      function getSlideOverviewTitle(slide) {
        const fm = slide?.frontmatter || {};
        if (fm.title) return String(fm.title);
        const blocks = slide?.blocks || [];
        for (const b of blocks) {
          if (b.type === "h" || /^h[1-6]$/i.test(b.subType || "")) {
            const md = (b.rawMarkdown || b.content || "").trim();
            return md.replace(/^#{1,6}s+/, "").replace(/[*_\`]/g, "").slice(0, 40);
          }
        }
        return "";
      }

      // 把任意一页渲染为静态缩略图：复用 renderBlock 与主渲染同名版式类，导出样式自动生效
      function buildOverviewThumbInto(canvas, slide) {
        const fm = slide.frontmatter || {};
        const layout = fm.layout || "default";
        const blocks = (slide.blocks || []).filter((b) => b.slot !== "slot-divider-right");
        let headerBlocks = blocks.filter((b) => b.slot === "header");
        if (headerBlocks.length === 0 && blocks.length > 0) {
          const candidate = blocks.find((b) => b.type === "h" && (!b.slot || b.slot === "default"));
          if (candidate) headerBlocks = [candidate];
        }
        const rem = blocks.filter((b) => !headerBlocks.includes(b));
        let bodyEl = null;

        if (layout === "cols-header" || layout === "two-cols-header" || layout === "three-cols-header" || layout === "clover") {
          const isClover = layout === "clover";
          let targetCols = isClover ? 4 : 2;
          if (layout === "three-cols-header") targetCols = 3;
          else if (layout === "two-cols-header") targetCols = 2;
          else if (!isClover) {
            let maxCol = 0;
            for (const b of rem) {
              const m = (b.slot || "").match(/^col-(d+)$/i);
              if (m) maxCol = Math.max(maxCol, parseInt(m[1], 10));
            }
            if (maxCol >= 2) targetCols = maxCol;
            else if (fm.layoutRatio) {
              const r = String(fm.layoutRatio).trim();
              if (r.includes(":")) {
                const parts = r.split(":").map((p) => parseFloat(p.trim())).filter((n) => !isNaN(n) && n > 0);
                if (parts.length >= 2) targetCols = parts.length;
              }
            }
          }
          const hasColSlots = rem.some((b) => b.slot && /^col-d+$/i.test(b.slot));
          const containerDiv = document.createElement("div");
          containerDiv.className = (isClover ? "layout-clover-container" : ("layout-cols-header-container " + (targetCols === 2 ? "layout-two-cols-header-container" : (targetCols === 3 ? "layout-three-cols-header-container" : "")))) + (hasColSlots || isClover ? " has-superblock-cols" : "");
          const headerDiv = document.createElement("div");
          headerDiv.className = "layout-header-section";
          for (const b of headerBlocks) headerDiv.appendChild(renderBlock(b, ""));
          containerDiv.appendChild(headerDiv);
          const gridDiv = document.createElement("div");
          gridDiv.className = (isClover ? "layout-clover-grid pdf-clover-wrapper" : ("layout-cols-wrapper layout-cols-grid " + (targetCols === 2 ? "pdf-two-cols-wrapper layout-two-cols-grid" : (targetCols === 3 ? "pdf-three-cols-wrapper layout-three-cols-grid" : "")))) + (hasColSlots || isClover ? " has-superblock-cols" : "");
          const gridCols = isClover ? "repeat(2, minmax(0, 1fr))" : parseRatioToGridCols(fm.layoutRatio, targetCols);
          if (gridCols) gridDiv.style.gridTemplateColumns = gridCols;
          if (isClover) gridDiv.style.gridTemplateRows = "repeat(2, minmax(0, 1fr))";
          let colsList = [];
          for (let i = 0; i < targetCols; i++) colsList.push([]);
          const hasExplicitCols = rem.some((b) => b.slot && (b.slot.startsWith("col-") || b.slot === "left" || b.slot === "right" || b.slot === "center"));
          if (hasExplicitCols && rem.length > 1) {
            for (const b of rem) {
              let idx = 0;
              if (b.slot === "left" || b.slot === "col-1") idx = 0;
              else if (b.slot === "center" || b.slot === "col-2") idx = 1;
              else if (b.slot === "right") idx = targetCols === 2 ? 1 : targetCols - 1;
              else {
                const m = (b.slot || "").match(/^col-(d+)$/i);
                if (m) idx = Math.min(targetCols - 1, Math.max(0, parseInt(m[1], 10) - 1));
              }
              colsList[idx].push(b);
            }
            const hasExplicitColN = rem.some(b => /^col-d+$/i.test((b.slot || "").trim()));
            if (!hasExplicitColN && colsList[0].length === 0) {
              const nonEmptyCols = colsList.filter(c => c.length > 0);
              if (nonEmptyCols.length === 1) {
                colsList = [nonEmptyCols[0], ...Array.from({ length: targetCols - 1 }, () => [])];
              }
            }
          } else if (rem.length === 1) {
            colsList[0] = [rem[0]];
          } else {
            let cur = 0;
            for (let i = 0; i < targetCols; i++) {
              const remainingCols = targetCols - i;
              const remainingItems = rem.length - cur;
              const take = Math.ceil(remainingItems / remainingCols);
              colsList[i] = rem.slice(cur, cur + take);
              cur += take;
            }
          }
          colsList.forEach((colBlocks, idx) => {
            const colDiv = document.createElement("div");
            colDiv.className = "pdf-col pdf-col--" + (idx + 1) + " col-" + (idx + 1) + (targetCols === 2 && idx === 0 ? " pdf-col--left" : "") + (targetCols === 2 && idx === 1 ? " pdf-col--right" : "");
            const cleaned = cleanColList(colBlocks);
            for (const b of cleaned) colDiv.appendChild(renderBlock(b, ""));
            gridDiv.appendChild(colDiv);
          });
          containerDiv.appendChild(gridDiv);
          bodyEl = containerDiv;
        } else if (layout === "two-cols") {
          bodyEl = document.createElement("div");
          bodyEl.style.display = "flex";
          bodyEl.style.flexDirection = "row";
          bodyEl.style.gap = "2rem";
          bodyEl.style.width = "100%";
          bodyEl.style.flex = "1";
          bodyEl.style.minHeight = "0";
          let leftList = [];
          let rightList = [];
          for (const b of blocks) {
            if (b.slot === "right") rightList.push(b);
            else leftList.push(b);
          }
          const leftCol = document.createElement("div");
          leftCol.className = "two-cols-left";
          const rightCol = document.createElement("div");
          rightCol.className = "two-cols-right";
          for (const b of cleanColList(leftList)) leftCol.appendChild(renderBlock(b, ""));
          for (const b of cleanColList(rightList)) rightCol.appendChild(renderBlock(b, ""));
          bodyEl.appendChild(leftCol);
          bodyEl.appendChild(rightCol);
        } else if (layout === "image-right" || layout === "image-left") {
          const isImageRight = layout === "image-right";
          bodyEl = document.createElement("div");
          bodyEl.style.display = "flex";
          bodyEl.style.flexDirection = isImageRight ? "row" : "row-reverse";
          bodyEl.style.gap = "2rem";
          bodyEl.style.width = "100%";
          bodyEl.style.flex = "1";
          bodyEl.style.minHeight = "0";
          const contentCol = document.createElement("div");
          contentCol.className = isImageRight ? "image-right-content" : "image-left-content";
          for (const b of blocks) contentCol.appendChild(renderBlock(b, ""));
          const imgCol = document.createElement("div");
          imgCol.className = isImageRight ? "image-right-img-container" : "image-left-img-container";
          const url = fm.image || fm.background || "";
          if (url) {
            const img = document.createElement("img");
            img.className = isImageRight ? "image-right-img" : "image-left-img";
            img.src = url;
            img.alt = "Slide cover";
            imgCol.appendChild(img);
          }
          bodyEl.appendChild(contentCol);
          bodyEl.appendChild(imgCol);
        } else if (layout === "fact") {
          bodyEl = document.createElement("div");
          bodyEl.className = "layout-fact-container";
          const glow = document.createElement("div");
          glow.className = "fact-hero-glow";
          bodyEl.appendChild(glow);
          const box = document.createElement("div");
          box.className = "fact-content-box fact-stats-grid";

          const rawLines = [];
          if (blocks.length === 1 && blocks[0].children && blocks[0].children.length >= 1) {
            for (const c of blocks[0].children) rawLines.push((c.rawMarkdown || c.content || "").trim());
          } else if (blocks.length === 1) {
            const lines = (blocks[0].rawMarkdown || blocks[0].content || "").trim().split(/[\\r\\n]+/);
            for (const line of lines) {
              if (/^[\\s]*(?:[-*+]|\\d+\\.)[\\s]+/.test(line)) rawLines.push(line.trim());
            }
          }

          let cards = [];
          if (rawLines.length > 0) {
            cards = rawLines.map((line) => {
              const cl = cleanCardListItemMarkdown(line).trim();
              const m = cl.match(/^([^\\n:：]+?)(?:[\\s]*[:：][\\s]*)([\\s\\S]+)$/);
              return m ? { val: m[1].trim(), lbl: m[2].trim() } : { val: cl, lbl: "" };
            });
          } else if (blocks.length >= 2 && blocks.length % 2 === 0) {
            for (let i = 0; i < blocks.length; i += 2) {
              cards.push({
                val: cleanCardListItemMarkdown(blocks[i].rawMarkdown || blocks[i].content || "").trim(),
                lbl: cleanCardListItemMarkdown(blocks[i + 1].rawMarkdown || blocks[i + 1].content || "").trim(),
              });
            }
          } else if (blocks.length > 0) {
            const firstCl = cleanCardListItemMarkdown(blocks[0].rawMarkdown || blocks[0].content || "").trim();
            const m = firstCl.match(/^([^\\n:：]+?)(?:[\\s]*[:：][\\s]*)([\\s\\S]+)$/);
            if (m) cards.push({ val: m[1].trim(), lbl: m[2].trim() });
            else cards.push({ val: firstCl, lbl: blocks.slice(1).map((b) => cleanCardListItemMarkdown(b.rawMarkdown || b.content || "").trim()).join("\\n") });
          }

          const cCount = Math.max(1, Math.min(4, cards.length));
          bodyEl.className += " layout-fact-cols-" + cCount;
          box.className += " fact-stats-grid--cols-" + cCount;

          cards.forEach((c) => {
            const cardEl = document.createElement("div");
            cardEl.className = "fact-stat-card";
            const vWrap = document.createElement("div");
            vWrap.className = "fact-value-wrapper fact-value-box";
            vWrap.textContent = c.val;
            cardEl.appendChild(vWrap);
            if (c.lbl) {
              const divLine = document.createElement("div");
              divLine.className = "fact-divider-line";
              cardEl.appendChild(divLine);
              const lWrap = document.createElement("div");
              lWrap.className = "fact-label-wrapper fact-label-box";
              lWrap.textContent = c.lbl;
              cardEl.appendChild(lWrap);
            }
            box.appendChild(cardEl);
          });
          bodyEl.appendChild(box);
        } else if (layout === "timeline" || layout === "steps") {
          bodyEl = document.createElement("div");
          bodyEl.className = "layout-timeline-container";
          const track = document.createElement("div");
          track.className = "timeline-track-wrapper";
          let stepItems = blocks;
          if (blocks.length === 1 && blocks[0].children && blocks[0].children.length >= 2) {
            stepItems = blocks[0].children;
          }
          stepItems.forEach((item, idx) => {
            const stepEl = document.createElement("div");
            stepEl.className = "timeline-step-item";
            const node = document.createElement("div");
            node.className = "timeline-node-container";
            const badge = document.createElement("div");
            badge.className = "timeline-node-badge";
            badge.textContent = String(idx + 1);
            node.appendChild(badge);
            stepEl.appendChild(node);
            const content = document.createElement("div");
            content.className = "timeline-step-content";
            content.appendChild(renderBlock(item, ""));
            stepEl.appendChild(content);
            track.appendChild(stepEl);
          });
          bodyEl.appendChild(track);
        } else {
          bodyEl = document.createElement("div");
          for (const b of blocks) bodyEl.appendChild(renderBlock(b, ""));
        }
        canvas.appendChild(bodyEl);
      }

      function buildOverviewCards() {
        if (overviewBuilt) return;
        overviewBuilt = true;
        const scale = OVERVIEW_CARD_W / baseWidth;
        const canvasH = Math.round(baseHeight * scale);
        slides.forEach((slide, idx) => {
          const card = document.createElement("div");
          card.className = "slides-overview-card";
          card.dataset.idx = String(idx);
          const box = document.createElement("div");
          box.className = "slides-overview-canvas-box";
          box.style.height = canvasH + "px";
          const fm = slide.frontmatter || {};
          const spacing = (fm.spacing && fm.spacing !== "inherit") ? fm.spacing : ((data.config && data.config.spacing) || "normal");
          const canvas = document.createElement("div");
          canvas.className = "slides-overview-canvas slide-content layout-" + (fm.layout || "default") + " spacing-" + spacing;
          canvas.style.width = baseWidth + "px";
          canvas.style.height = baseHeight + "px";
          canvas.style.transform = "scale(" + scale + ")";
          const bg = fm.background || (data.config && data.config.background);
          if (bg) {
            if (/^(http|\\/|data:|assets\\/)/.test(bg)) {
              canvas.style.backgroundImage = 'url("' + bg + '")';
              canvas.style.backgroundSize = "cover";
              canvas.style.backgroundPosition = "center";
            } else {
              canvas.style.background = bg;
            }
          }
          box.appendChild(canvas);
          const caption = document.createElement("div");
          caption.className = "slides-overview-caption";
          const pageNo = document.createElement("span");
          pageNo.className = "slides-overview-page-no";
          pageNo.textContent = String(idx + 1);
          caption.appendChild(pageNo);
          const title = getSlideOverviewTitle(slide);
          if (title) {
            const titleEl = document.createElement("span");
            titleEl.className = "slides-overview-title";
            titleEl.textContent = title;
            caption.appendChild(titleEl);
          }
          card.appendChild(box);
          card.appendChild(caption);
          card.addEventListener("click", (e) => {
            e.stopPropagation();
            goFromOverview(idx + 1);
          });
          overviewGrid.appendChild(card);
        });
        updateOverviewCurrentMark();
      }

      function renderOverviewThumb(card) {
        if (!card || card.dataset.rendered === "1") return;
        const idx = Number(card.dataset.idx);
        const slide = slides[idx];
        const canvas = card.querySelector(".slides-overview-canvas");
        if (slide && canvas) buildOverviewThumbInto(canvas, slide);
        card.dataset.rendered = "1";
      }

      function ensureOverviewObserver() {
        if (overviewObserver || typeof window.IntersectionObserver !== "function") return;
        overviewObserver = new IntersectionObserver((entries) => {
          for (const en of entries) {
            if (!en.isIntersecting) continue;
            overviewObserver.unobserve(en.target);
            renderOverviewThumb(en.target);
          }
        }, { rootMargin: "240px" });
      }

      function observeOverviewCards() {
        if (!overviewObserver) return;
        const cards = overviewGrid.children;
        for (let i = 0; i < cards.length; i++) {
          if (cards[i].dataset.rendered !== "1") overviewObserver.observe(cards[i]);
        }
      }

      function updateOverviewCurrentMark() {
        const cards = overviewGrid.children;
        for (let i = 0; i < cards.length; i++) {
          const pageNo = cards[i].querySelector(".slides-overview-page-no");
          if (pageNo) pageNo.classList.toggle("is-current", i === currentIndex);
        }
      }

      function setOverviewFocus(page) {
        const total = slides.length || 1;
        overviewFocus = Math.min(Math.max(1, page), total);
        const cards = overviewGrid.children;
        for (let i = 0; i < cards.length; i++) {
          cards[i].classList.toggle("is-active", i + 1 === overviewFocus);
        }
        const el = cards[overviewFocus - 1];
        if (el && el.scrollIntoView) el.scrollIntoView({ block: "nearest", behavior: "smooth" });
      }

      function getOverviewCols() {
        if (!overviewGrid || !overviewGrid.clientWidth) return 1;
        return Math.max(1, Math.round(overviewGrid.clientWidth / (OVERVIEW_CARD_W + 18)));
      }

      function goFromOverview(page) {
        const p = parseInt(page, 10);
        if (isNaN(p) || p < 1 || p > slides.length) return;
        closeOverview();
        renderSlide(p - 1);
        updateOverviewCurrentMark();
      }

      function openOverview() {
        if (slides.length === 0) return;
        buildOverviewCards();
        overviewOpen = true;
        overviewOverlay.style.display = "block";
        ensureOverviewObserver();
        if (overviewObserver) {
          observeOverviewCards();
        } else {
          const cards = overviewGrid.children;
          for (let i = 0; i < cards.length; i++) renderOverviewThumb(cards[i]);
        }
        setOverviewFocus(currentIndex + 1);
      }

      function closeOverview() {
        overviewOpen = false;
        overviewOverlay.style.display = "none";
        hideJumpIndicator();
        if (overviewObserver) {
          const cards = overviewGrid.children;
          for (let i = 0; i < cards.length; i++) overviewObserver.unobserve(cards[i]);
        }
      }

      function toggleOverview() {
        if (overviewOpen) closeOverview();
        else openOverview();
      }

      // 总览打开期间接管全部按键：修复上游总览中空格/PGUP/PGDN 仍会翻页的漏洞
      function handleOverviewKeyDown(e) {
        if (e.ctrlKey || e.metaKey || e.altKey) return;
        if (e.isComposing || isEditableKeyTarget(e.target)) return;
        if (/^[0-9]$/.test(e.key)) {
          if (!jumpInvalid && jumpDisplay.length < 4) {
            jumpDisplay += e.key;
            const p = parseInt(jumpDisplay, 10);
            if (!isNaN(p) && p >= 1 && p <= slides.length) setOverviewFocus(p);
            renderJumpBadge();
            armJumpIdleTimer();
          }
          e.preventDefault();
          return;
        }
        if (e.key === "Enter" && jumpDisplay) {
          if (!jumpInvalid) {
            const page = parseInt(jumpDisplay, 10);
            if (!isNaN(page) && page >= 1 && page <= slides.length) {
              goFromOverview(page);
            } else {
              flashJumpInvalid();
            }
          }
          e.preventDefault();
          return;
        }
        if ((e.key === "Escape" || e.key === "Esc") && (jumpDisplay || jumpInvalid)) {
          hideJumpIndicator();
          e.preventDefault();
          return;
        }
        if (e.key === "ArrowRight") {
          e.preventDefault();
          setOverviewFocus(overviewFocus + 1);
          return;
        }
        if (e.key === "ArrowLeft") {
          e.preventDefault();
          setOverviewFocus(overviewFocus - 1);
          return;
        }
        if (e.key === "ArrowDown" || e.key === "PageDown") {
          e.preventDefault();
          setOverviewFocus(overviewFocus + getOverviewCols());
          return;
        }
        if (e.key === "ArrowUp" || e.key === "PageUp") {
          e.preventDefault();
          setOverviewFocus(overviewFocus - getOverviewCols());
          return;
        }
        if (e.key === " ") {
          e.preventDefault();
          return;
        }
        if (e.key === "Enter") {
          e.preventDefault();
          goFromOverview(overviewFocus);
          return;
        }
        if (e.key === "Escape" || e.key === "Esc" || e.key === "o" || e.key === "O") {
          e.preventDefault();
          closeOverview();
        }
      }

      window.addEventListener("keydown", (e) => {
        if (e.key === "Escape" || e.key === "Esc") {
          if (isLightboxOpen) {
            closeLightbox();
            e.preventDefault();
            return;
          }
        }
        if (isLightboxOpen) return;
        // 总览打开期间全部按键由总览层接管
        if (overviewOpen) {
          handleOverviewKeyDown(e);
          return;
        }
        // 「数字+回车」跳页：可输入元素、修饰键、IME 组合输入中不拦截
        if (!e.ctrlKey && !e.metaKey && !e.altKey && !e.isComposing && !isEditableKeyTarget(e.target)) {
          if (/^[0-9]$/.test(e.key)) {
            if (!jumpInvalid && jumpDisplay.length < 4) {
              jumpDisplay += e.key;
              renderJumpBadge();
              armJumpIdleTimer();
            }
            e.preventDefault();
            return;
          }
          if (e.key === "Enter" && jumpDisplay) {
            if (!jumpInvalid) {
              const page = parseInt(jumpDisplay, 10);
              if (!isNaN(page) && page >= 1 && page <= slides.length) {
                hideJumpIndicator();
                renderSlide(page - 1);
              } else {
                flashJumpInvalid();
              }
            }
            e.preventDefault();
            return;
          }
          if ((e.key === "Escape" || e.key === "Esc") && (jumpDisplay || jumpInvalid)) {
            hideJumpIndicator();
            e.preventDefault();
            return;
          }
          if (e.key === "o" || e.key === "O") {
            e.preventDefault();
            toggleOverview();
            return;
          }
        }
        if (e.key === "ArrowRight" || e.key === " " || e.key === "ArrowDown") goNext();
        if (e.key === "ArrowLeft" || e.key === "ArrowUp") goPrev();
        if (e.key === "f" || e.key === "F") btnFullscreen.click();
      });

      // 监听鼠标滚轮上下翻页调度
      let lastWheelTime = 0;
      const WHEEL_COOLDOWN_MS = 280;
      const WHEEL_DELTA_THRESHOLD = 15;

`}function wg(){return`      function canElementScrollY(el, deltaY) {
        let cur = el;
        while (cur && cur !== document.body && cur !== document.documentElement) {
          if (cur.classList && (cur.classList.contains("slides-viewport") || cur.classList.contains("slides-stage") || cur.classList.contains("slide-container"))) {
            break;
          }
          const style = window.getComputedStyle(cur);
          const overflowY = style.overflowY;
          if (overflowY === "auto" || overflowY === "scroll") {
            const maxScroll = cur.scrollHeight - cur.clientHeight;
            if (maxScroll > 2) {
              if (deltaY > 0 && cur.scrollTop < maxScroll - 1) return true;
              if (deltaY < 0 && cur.scrollTop > 1) return true;
            }
          }
          cur = cur.parentElement;
        }
        return false;
      }

      window.addEventListener("wheel", (e) => {
        if (isLightboxOpen) {
          if (typeof handleLightboxWheel === "function") {
            handleLightboxWheel(e);
          }
          return;
        }
        // 总览打开时滚轮交给总览列表原生滚动，不触发翻页
        if (overviewOpen) return;
        if (Math.abs(e.deltaY) < Math.abs(e.deltaX)) return;
        if (Math.abs(e.deltaY) < WHEEL_DELTA_THRESHOLD) return;

        const target = e.target instanceof Element ? e.target : e.target?.parentElement;
        if (target && canElementScrollY(target, e.deltaY)) return;

        e.preventDefault();
        const now = Date.now();
        if (now - lastWheelTime < WHEEL_COOLDOWN_MS) return;
        lastWheelTime = now;

        if (e.deltaY > 0) {
          goNext();
        } else {
          goPrev();
        }
      }, { passive: false });

      document.addEventListener("click", (e) => {
        if (isLightboxOpen) {
          if (typeof lightboxHasMoved !== "undefined" && lightboxHasMoved) {
            lightboxHasMoved = false;
            e.stopPropagation();
            return;
          }
          const target = e.target instanceof Element ? e.target : e.target?.parentElement;
          const isMediaItself = target && target.closest && target.closest(".slides-lightbox-img, .slides-lightbox-video");
          if (!isMediaItself) {
            e.stopPropagation();
            closeLightbox();
          }
          return;
        }
        // 总览打开时空白点击由总览层自身处理，不触发底层翻页
        if (overviewOpen) return;
        if (e.button !== 0) return;
        const targetEl = e.target instanceof Element ? e.target : e.target?.parentElement;
        if (!targetEl || !targetEl.closest) return;

        const hasPendingMask = currentMaskConfig && (currentMaskStep < currentMaskConfig.totalSteps);
        if (hasPendingMask) {
          const isBottomControls = targetEl.closest(".controls-bar, .controls, .slides-toc");
          if (isBottomControls) return;
          e.preventDefault();
          e.stopPropagation();
          goNext();
          return;
        }

        const refEl = targetEl.closest("[data-ref-id]");
        if (refEl) {
          const id = refEl.getAttribute("data-ref-id");
          if (id) {
            window.open("siyuan://blocks/" + id, "_blank");
            return;
          }
        }

        // 媒体点击唤起 Lightbox 放大模态
        const mediaEl = targetEl.closest(".slide-content img, .slide-content video");
        if (mediaEl && !mediaEl.closest(".controls, .controls-bar, button, a")) {
          e.stopPropagation();
          const isVideo = mediaEl.tagName.toLowerCase() === "video";
          const src = isVideo ? (mediaEl.currentSrc || mediaEl.src || mediaEl.querySelector("source")?.src) : mediaEl.src;
          if (src) {
            openLightbox(isVideo ? "video" : "image", src, mediaEl.alt || "");
            return;
          }
        }

        const selection = window.getSelection ? window.getSelection().toString().trim() : "";
        if (selection.length > 0) return;

        const isComponent = targetEl.closest(
          ".slide-block, .controls-bar, .image-right-img-container, .image-left-img-container, .controls, img, video, audio, button, a, input, textarea, select, [data-clickable], [data-ref-id], .slides-toc, .empty-state"
        );
        if (isComponent) return;

        const isLeft = e.clientX < window.innerWidth / 2;
        if (isLeft) {
          goPrev();
        } else {
          goNext();
        }
      });

      renderSlide(0);
      updateScale();
    })();`}function xg(){return[pg(),hg(),mg(),gg(),yg(),bg(),vg(),kg(),wg()].join("")}function Sg(e,t=!1){var l;const o=new Set,i=r=>{if(!r||typeof r!="string")return;const a=r.trim();!a||a.startsWith("data:")||(a.includes("/assets/")||a.startsWith("assets/")||a.startsWith("./assets/")||a.startsWith("/assets/")||t&&/^https?:\/\//i.test(a))&&o.add(a)},n=r=>{if(!r||typeof r!="string")return;const a=/!\[.*?\]\((.+?)\)/g;let c;for(;(c=a.exec(r))!==null;)c[1]&&i(c[1]);const u=/<(?:img|video|audio|source)\b[^>]*?\bsrc=["'](.*?)["']/gi;for(;(c=u.exec(r))!==null;)c[1]&&i(c[1]);const f=/url\(\s*["']?(.*?)["']?\s*\)/gi;for(;(c=f.exec(r))!==null;)c[1]&&i(c[1])},s=r=>{if(r&&(r.rawMarkdown&&n(r.rawMarkdown),r.content&&n(r.content),Array.isArray(r.children)))for(const a of r.children)s(a)};(l=e.config)!=null&&l.background&&i(e.config.background);for(const r of e.slides||[]){if(r.frontmatter)for(const a of Object.values(r.frontmatter))typeof a=="string"&&i(a);if(r.rawMarkdown&&n(r.rawMarkdown),Array.isArray(r.blocks))for(const a of r.blocks)s(a);if(Array.isArray(r.noteBlocks))for(const a of r.noteBlocks)s(a);r.notes&&n(r.notes)}try{const r=JSON.stringify(e),a=/(?:https?:\/\/[^\s"'<>\)\\]+)?(?:\.\/|\/)?assets\/[^\s"'<>\)\\]+/g,c=r.match(a);if(c)for(const u of c)i(u);if(t){const u=/https?:\/\/[^\s"'<>\)\\]+\.(?:png|jpe?g|gif|webp|svg|avif|ico|bmp)(?:\?[^\s"'<>\)\\]*)?/gi,f=r.match(u);if(f)for(const h of f)i(h)}}catch{}return Array.from(o)}async function Ys(e){if(typeof FileReader<"u")return new Promise((n,s)=>{const l=new FileReader;l.onloadend=()=>{typeof l.result=="string"?n(l.result):s(new Error("Failed to convert blob to data URL"))},l.onerror=()=>s(l.error||new Error("FileReader error")),l.readAsDataURL(e)});const t=await e.arrayBuffer(),o=Buffer.from(t);return`data:${e.type||"image/png"};base64,${o.toString("base64")}`}async function Ma(e){if(typeof e=="string")return e.startsWith("data:")?e:`data:image/png;base64,${e}`;if(e instanceof ArrayBuffer){const t=new Blob([e]);return Ys(t)}return e instanceof Blob?Ys(e):""}async function Cg(e,t){var l,r;const o=Sg(e,t==null?void 0:t.includeRemote);if(o.length===0)return{};const i={},n=typeof window<"u"&&((r=(l=window.siyuan)==null?void 0:l.config)==null?void 0:r.apiToken)||"",s=n?{Authorization:`Token ${n}`}:{};for(const a of o){let c="",u=!1;const f=a.indexOf("/assets/");f!==-1?(c=a.slice(f+1),u=!0):a.startsWith("assets/")?(c=a,u=!0):a.startsWith("./assets/")?(c=a.slice(2),u=!0):a.startsWith("/assets/")&&(c=a.slice(1),u=!0);try{let h=null;if(t!=null&&t.fetcher){const d=await t.fetcher(a).catch(()=>null);if(d)h=await Ma(d);else if(c&&c!==a){const b=await t.fetcher(`/${c}`).catch(()=>null);b&&(h=await Ma(b))}}else if(typeof fetch<"u"){const d=[];(a.startsWith("http://")||a.startsWith("https://"))&&d.push({url:a,headers:u?s:void 0}),u&&c&&(d.push({url:`/${c}`,headers:s}),d.push({url:`./${c}`,headers:s}),d.push({url:c,headers:s})),u||d.push({url:a});for(const b of d)try{const m=await fetch(b.url,{credentials:"include",headers:b.headers});if(m.ok){const y=await m.blob();if(h=await Ys(y),h)break}}catch{}}if(h){const d=[a];c&&d.push(`/${c}`,`./${c}`,c);for(const b of d){i[b]=h;try{i[decodeURI(b)]=h,i[encodeURI(b)]=h}catch{}}}}catch(h){console.warn(`[single-html-exporter] Failed to inline asset "${a}":`,h)}}return i}function _g(e,t){const o=(t==null?void 0:t.title)||"即现文稿";let i=e.slides,n={...e.config},s=e.customThemeCss;if(t!=null&&t.inlineAssetBase64Map&&Object.keys(t.inlineAssetBase64Map).length>0){const c=t.inlineAssetBase64Map,u=Object.entries(c).sort((d,b)=>b[0].length-d[0].length),f=d=>{if(!d||typeof d!="string")return d;let b=d;for(const[m,y]of u)b.includes(m)&&(b=b.split(m).join(y));return b},h=d=>{const b=f(d.rawMarkdown||""),m=f(d.content||""),y=Array.isArray(d.children)?d.children.map(g=>h(g)):d.children;return{...d,rawMarkdown:b,content:m,children:y}};n.background&&typeof n.background=="string"&&(n.background=f(n.background)),s&&(s=f(s)),i=(e.slides||[]).map(d=>{const b=f(d.rawMarkdown||""),m=(d.blocks||[]).map(h),y=Array.isArray(d.noteBlocks)?d.noteBlocks.map(h):d.noteBlocks,g=f(d.notes||"");let x=d.frontmatter?{...d.frontmatter}:d.frontmatter;if(x)for(const[k,I]of Object.entries(x))typeof I=="string"&&(x[k]=f(I));return{...d,rawMarkdown:b,blocks:m,noteBlocks:y,notes:g,frontmatter:x}})}const l=_r(n.colorSchema),r=JSON.stringify(i),a=JSON.stringify({...n,hostThemeMode:n.hostThemeMode||l});return`<!DOCTYPE html>
<html lang="zh-CN">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${nt(o)}</title>
  <style>
${fg(t==null?void 0:t.customInlineStyles)}
  </style>
  <script>
    // 注入演示数据载荷
    window.__SLIDES_DATA__ = {
      docId: ${JSON.stringify(e.docId)},
      slides: ${r},
      config: ${a}
    };
  <\/script>
</head>
<body>
  <div id="app" data-theme="${l}" data-normalize-headings="${n.normalizeHeadingSizes?"true":"false"}" data-hide-unordered-markers="${n.showUnorderedListMarkers===!1?"true":"false"}" data-hide-ordered-markers="${n.showOrderedListMarkers===!1?"true":"false"}">
    <div class="slide-viewport slides-theme-${n.theme||"apple-basic"}" id="viewport" data-theme="${l}" data-slides-theme="${n.theme||"apple-basic"}">
      <div class="slide-content" id="slide-container"></div>
    </div>
    <div class="controls">
      <button id="btn-prev">◀ 上一页</button>
      <span id="page-num">1 / 1</span>
      <button id="btn-next">下一页 ▶</button>
      <button id="btn-fullscreen">全屏</button>
    </div>
    <!-- 全屏媒体灯箱 (Lightbox) 模态窗口 -->
    <div id="slides-lightbox" class="slides-lightbox">
      <button class="slides-lightbox-close" id="lightbox-close" aria-label="关闭 (Esc)">✕</button>
      <div class="slides-lightbox-content" id="lightbox-content"></div>
    </div>
  </div>

  <script>
${xg()}
  <\/script>
</body>
</html>`}async function pc(e,t){let o=t==null?void 0:t.inlineAssetBase64Map;return(!o||Object.keys(o).length===0)&&(o=await Cg(e,t)),_g(e,{...t,inlineAssetBase64Map:o})}function hc(e,t){if(typeof document>"u")return!1;const o=new Blob([t],{type:"text/html;charset=utf-8"}),i=URL.createObjectURL(o),n=document.createElement("a");return n.href=i,n.download=e.endsWith(".html")?e:`${e}.html`,document.body.appendChild(n),n.click(),document.body.removeChild(n),URL.revokeObjectURL(i),!0}function Ig(e){switch(e){case"4:3":return"size: 12in 9in;";case"A4-landscape":return"size: 297mm 210mm;";case"A4-portrait":return"size: 210mm 297mm;";case"16:9":default:return"size: 16in 9in;"}}function $g(e){const t=Ig(e==null?void 0:e.pageRatio);return`
    ${Wi(e==null?void 0:e.customInlineStyles)}

    @page {
      ${t}
      margin: 0;
    }
    * {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
      -webkit-print-color-adjust: exact !important;
      print-color-adjust: exact !important;
    }
    body {
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "PingFang SC", "Microsoft YaHei", sans-serif;
      background: #f8fafc;
      color: #1e293b;
    }
    .pdf-slide-page {
      width: 100vw;
      height: 100vh;
      page-break-after: always;
      break-after: page;
      padding: var(--slides-padding-y, 36px) var(--slides-padding-x, 56px);
      display: flex;
      flex-direction: column;
      position: relative;
      background: #ffffff;
      overflow: hidden;
      container-type: size;
    }
    .pdf-slide-page.spacing-compact {
      --slides-padding-y: 16px;
      --slides-padding-x: 28px;
      --slides-block-gap: 8px;
      --slides-list-gap: 4px;
      --slides-cols-gap: 20px;
      --slides-title-margin-bottom: 8px;
      --slides-header-gap: 10px;
      --slides-line-height: 1.45;
    }
    .pdf-slide-page.spacing-normal {
      --slides-padding-y: 32px;
      --slides-padding-x: 48px;
      --slides-block-gap: 14px;
      --slides-list-gap: 6px;
      --slides-cols-gap: 32px;
      --slides-title-margin-bottom: 12px;
      --slides-header-gap: 16px;
      --slides-line-height: 1.6;
    }
    .pdf-slide-page.spacing-loose {
      --slides-padding-y: 52px;
      --slides-padding-x: 72px;
      --slides-block-gap: 22px;
      --slides-list-gap: 10px;
      --slides-cols-gap: 44px;
      --slides-title-margin-bottom: 18px;
      --slides-header-gap: 24px;
      --slides-line-height: 1.75;
    }
    .pdf-slide-page.theme-dark {
      background: #0f1117;
      color: #f1f5f9;
    }

    /* 1. 默认科技主题 Default (Modern Tech) */
    .pdf-slide-page.slides-theme-tech {
      font-family: system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "PingFang SC", "Microsoft YaHei", sans-serif;
    }
    .pdf-slide-page.slides-theme-tech.theme-light {
      background: #f8fafc;
      color: #0f172a;
    }
    .pdf-slide-page.slides-theme-tech.theme-dark {
      background: #090d16;
      color: #f1f5f9;
    }
    .slides-theme-tech .pdf-block h1 { color: #059669; }
    .theme-dark.slides-theme-tech .pdf-block h1 { color: #10b981; }
    .slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h1,
    .slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h2,
    .slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h3,
    .slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h1,
    .slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h2,
    .slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h3,
    .slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h1,
    .slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h2,
    .slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h3,
    .slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h1,
    .slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h2,
    .slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h3,
    .slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h1,
    .slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h2,
    .slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h3,
    .slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h1,
    .slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h2,
    .slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h3,
    .slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .pdf-block:first-child h1,
    .slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .pdf-block:first-child h2,
    .slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .pdf-block:first-child h3,
    .slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .pdf-block:first-child h1,
    .slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .pdf-block:first-child h2,
    .slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .pdf-block:first-child h3,
    .slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .pdf-block:first-child h1,
    .slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .pdf-block:first-child h2,
    .slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .pdf-block:first-child h3,
    .slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .pdf-block:first-child h1,
    .slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .pdf-block:first-child h2,
    .slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .pdf-block:first-child h3 {
      color: #059669;
      border-left: 4px solid #059669;
      padding: 4px 14px;
      padding-left: 14px;
      background: linear-gradient(90deg, rgba(5, 150, 105, 0.13), transparent 76%);
      border-radius: 0 6px 6px 0;
      letter-spacing: -0.015em;
    }
    .theme-dark.slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h1,
    .theme-dark.slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h2,
    .theme-dark.slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h3,
    .theme-dark.slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h1,
    .theme-dark.slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h2,
    .theme-dark.slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h3,
    .theme-dark.slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h1,
    .theme-dark.slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h2,
    .theme-dark.slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h3,
    .theme-dark.slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h1,
    .theme-dark.slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h2,
    .theme-dark.slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h3,
    .theme-dark.slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h1,
    .theme-dark.slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h2,
    .theme-dark.slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h3,
    .theme-dark.slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h1,
    .theme-dark.slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h2,
    .theme-dark.slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h3,
    .theme-dark.slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .pdf-block:first-child h1,
    .theme-dark.slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .pdf-block:first-child h2,
    .theme-dark.slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .pdf-block:first-child h3,
    .theme-dark.slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .pdf-block:first-child h1,
    .theme-dark.slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .pdf-block:first-child h2,
    .theme-dark.slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .pdf-block:first-child h3,
    .theme-dark.slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .pdf-block:first-child h1,
    .theme-dark.slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .pdf-block:first-child h2,
    .theme-dark.slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .pdf-block:first-child h3,
    .theme-dark.slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .pdf-block:first-child h1,
    .theme-dark.slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .pdf-block:first-child h2,
    .theme-dark.slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .pdf-block:first-child h3 {
      color: #10b981;
      border-left-color: #10b981;
      background: linear-gradient(90deg, rgba(16, 185, 129, 0.14), transparent 76%);
    }

    /* 2. 优雅衬线主题 Seriph (Editorial Academic) */
    .pdf-slide-page.slides-theme-seriph {
      font-family: "PT Serif", "Charter", "Georgia", "Cambria", "Times New Roman", "Source Han Serif SC", "Noto Serif SC", "Songti SC", "SimSun", serif;
      letter-spacing: 0.015em;
    }
    .pdf-slide-page.slides-theme-seriph.theme-light {
      background: #fcfbf7;
      color: #231f1d;
    }
    .pdf-slide-page.slides-theme-seriph.theme-dark {
      background: #171513;
      color: #f5f2eb;
    }
    .slides-theme-seriph .pdf-block h1 { color: #b45309; }
    .theme-dark.slides-theme-seriph .pdf-block h1 { color: #f59e0b; }
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h1,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h2,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h3,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h1,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h2,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h3,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h1,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h2,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h3,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h1,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h2,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h3,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h1,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h2,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h3,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h1,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h2,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h3,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .pdf-block:first-child h1,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .pdf-block:first-child h2,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .pdf-block:first-child h3,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .pdf-block:first-child h1,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .pdf-block:first-child h2,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .pdf-block:first-child h3,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .pdf-block:first-child h1,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .pdf-block:first-child h2,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .pdf-block:first-child h3,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .pdf-block:first-child h1,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .pdf-block:first-child h2,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .pdf-block:first-child h3 {
      display: block;
      position: relative;
      color: #b45309;
      border-bottom: 1.5px solid rgba(180, 83, 9, 0.45);
      padding-bottom: 10px;
      margin-bottom: 14px;
    }
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h1::after,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h2::after,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h3::after,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h1::after,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h2::after,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h3::after,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h1::after,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h2::after,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h3::after,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h1::after,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h2::after,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h3::after,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h1::after,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h2::after,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h3::after,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h1::after,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h2::after,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h3::after,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .pdf-block:first-child h1::after,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .pdf-block:first-child h2::after,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .pdf-block:first-child h3::after,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .pdf-block:first-child h1::after,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .pdf-block:first-child h2::after,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .pdf-block:first-child h3::after,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .pdf-block:first-child h1::after,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .pdf-block:first-child h2::after,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .pdf-block:first-child h3::after,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .pdf-block:first-child h1::after,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .pdf-block:first-child h2::after,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .pdf-block:first-child h3::after {
      content: "";
      position: absolute;
      left: 0;
      right: 0;
      bottom: 3px;
      height: 1.5px;
      pointer-events: none;
      background: linear-gradient(90deg, #b45309 0%, rgba(180, 83, 9, 0.35) 50%, transparent 92%);
    }
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h1,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h2,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h3,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h1,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h2,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h3,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h1,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h2,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h3,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h1,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h2,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h3,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h1,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h2,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h3,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h1,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h2,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h3,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .pdf-block:first-child h1,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .pdf-block:first-child h2,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .pdf-block:first-child h3,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .pdf-block:first-child h1,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .pdf-block:first-child h2,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .pdf-block:first-child h3,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .pdf-block:first-child h1,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .pdf-block:first-child h2,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .pdf-block:first-child h3,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .pdf-block:first-child h1,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .pdf-block:first-child h2,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .pdf-block:first-child h3 {
      color: #f59e0b;
      border-bottom-color: rgba(245, 158, 11, 0.45);
    }
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h1::after,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h2::after,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h3::after,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h1::after,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h2::after,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h3::after,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h1::after,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h2::after,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h3::after,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h1::after,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h2::after,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h3::after,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h1::after,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h2::after,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h3::after,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h1::after,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h2::after,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h3::after,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .pdf-block:first-child h1::after,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .pdf-block:first-child h2::after,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .pdf-block:first-child h3::after,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .pdf-block:first-child h1::after,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .pdf-block:first-child h2::after,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .pdf-block:first-child h3::after,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .pdf-block:first-child h1::after,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .pdf-block:first-child h2::after,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .pdf-block:first-child h3::after,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .pdf-block:first-child h1::after,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .pdf-block:first-child h2::after,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .pdf-block:first-child h3::after {
      background: linear-gradient(90deg, #f59e0b 0%, rgba(245, 158, 11, 0.35) 50%, transparent 92%);
    }

    /* 3. 极简发布会主题 Apple Basic (Swiss Minimal) */
    .pdf-slide-page.slides-theme-apple-basic {
      font-family: -apple-system, "SF Pro Display", "SF Pro Text", BlinkMacSystemFont, "PingFang SC", "Helvetica Neue", sans-serif;
      letter-spacing: -0.025em;
    }
    .pdf-slide-page.slides-theme-apple-basic.theme-light {
      background: #ffffff;
      color: #000000;
    }
    .pdf-slide-page.slides-theme-apple-basic.theme-dark {
      background: #000000;
      color: #ffffff;
    }
    .slides-theme-apple-basic .pdf-block h1 {
      color: #000000;
      font-weight: 800;
      letter-spacing: -0.035em;
    }
    .theme-dark.slides-theme-apple-basic .pdf-block h1 {
      color: #ffffff;
      font-weight: 800;
      letter-spacing: -0.035em;
    }
    .slides-theme-apple-basic:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h1,
    .slides-theme-apple-basic:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h2,
    .slides-theme-apple-basic:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h3,
    .slides-theme-apple-basic:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h1,
    .slides-theme-apple-basic:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h2,
    .slides-theme-apple-basic:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h3,
    .slides-theme-apple-basic:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h1,
    .slides-theme-apple-basic:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h2,
    .slides-theme-apple-basic:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h3,
    .slides-theme-apple-basic:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h1,
    .slides-theme-apple-basic:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h2,
    .slides-theme-apple-basic:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h3,
    .slides-theme-apple-basic:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h1,
    .slides-theme-apple-basic:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h2,
    .slides-theme-apple-basic:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h3,
    .slides-theme-apple-basic:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h1,
    .slides-theme-apple-basic:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h2,
    .slides-theme-apple-basic:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h3,
    .slides-theme-apple-basic:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .pdf-block:first-child h1,
    .slides-theme-apple-basic:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .pdf-block:first-child h2,
    .slides-theme-apple-basic:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .pdf-block:first-child h3,
    .slides-theme-apple-basic:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .pdf-block:first-child h1,
    .slides-theme-apple-basic:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .pdf-block:first-child h2,
    .slides-theme-apple-basic:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .pdf-block:first-child h3,
    .slides-theme-apple-basic:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .pdf-block:first-child h1,
    .slides-theme-apple-basic:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .pdf-block:first-child h2,
    .slides-theme-apple-basic:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .pdf-block:first-child h3,
    .slides-theme-apple-basic:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .pdf-block:first-child h1,
    .slides-theme-apple-basic:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .pdf-block:first-child h2,
    .slides-theme-apple-basic:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .pdf-block:first-child h3 {
      border: none !important;
      background: none !important;
      padding: 0 !important;
      margin-bottom: 16px !important;
      letter-spacing: -0.04em !important;
      font-weight: 800 !important;
    }
    /* 页面存在背景图时，内容页顶部标题回退高对比文字与局部衬底，保留用户块级前景色 */
    .pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h1,
    .pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h2,
    .pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h3,
    .pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h1,
    .pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h2,
    .pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h3,
    .pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h1,
    .pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h2,
    .pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h3,
    .pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h1,
    .pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h2,
    .pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h3,
    .pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h1,
    .pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h2,
    .pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h3,
    .pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h1,
    .pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h2,
    .pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h3,
    .pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .pdf-block:first-child h1,
    .pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .pdf-block:first-child h2,
    .pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .pdf-block:first-child h3,
    .pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .pdf-block:first-child h1,
    .pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .pdf-block:first-child h2,
    .pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .pdf-block:first-child h3,
    .pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .pdf-block:first-child h1,
    .pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .pdf-block:first-child h2,
    .pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .pdf-block:first-child h3,
    .pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .pdf-block:first-child h1,
    .pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .pdf-block:first-child h2,
    .pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .pdf-block:first-child h3 {
      color: #0f172a;
      text-shadow: 0 1px 3px rgba(255, 255, 255, 0.85);
    }
    .pdf-slide-page.theme-dark[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h1,
    .pdf-slide-page.theme-dark[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h2,
    .pdf-slide-page.theme-dark[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h3,
    .pdf-slide-page.theme-dark[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h1,
    .pdf-slide-page.theme-dark[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h2,
    .pdf-slide-page.theme-dark[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h3,
    .pdf-slide-page.theme-dark[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .pdf-block:first-child h1,
    .pdf-slide-page.theme-dark[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .pdf-block:first-child h2,
    .pdf-slide-page.theme-dark[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .pdf-block:first-child h3,
    .pdf-slide-page.theme-dark[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .pdf-block:first-child h1,
    .pdf-slide-page.theme-dark[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .pdf-block:first-child h2,
    .pdf-slide-page.theme-dark[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .pdf-block:first-child h3 {
      color: #f8fafc;
      text-shadow: 0 1px 3px rgba(0, 0, 0, 0.75);
    }
    .slides-theme-tech.pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h1,
    .slides-theme-tech.pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h2,
    .slides-theme-tech.pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h3,
    .slides-theme-tech.pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h1,
    .slides-theme-tech.pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h2,
    .slides-theme-tech.pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h3 {
      background: linear-gradient(90deg, rgba(255, 255, 255, 0.55), transparent 82%);
    }
    .slides-theme-tech.theme-dark.pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h1,
    .slides-theme-tech.theme-dark.pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h2,
    .slides-theme-tech.theme-dark.pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h3,
    .slides-theme-tech.theme-dark.pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h1,
    .slides-theme-tech.theme-dark.pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h2,
    .slides-theme-tech.theme-dark.pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h3 {
      background: linear-gradient(90deg, rgba(15, 23, 42, 0.42), transparent 82%);
    }
    .pdf-slide-page .pdf-block[style^="color:"] h1,
    .pdf-slide-page .pdf-block[style*=" color:"] h1,
    .pdf-slide-page .pdf-block[style*=";color:"] h1,
    .pdf-slide-page .pdf-block[style^="color:"] h2,
    .pdf-slide-page .pdf-block[style*=" color:"] h2,
    .pdf-slide-page .pdf-block[style*=";color:"] h2,
    .pdf-slide-page .pdf-block[style^="color:"] h3,
    .pdf-slide-page .pdf-block[style*=" color:"] h3,
    .pdf-slide-page .pdf-block[style*=";color:"] h3 {
      color: inherit !important;
    }
    .slides-theme-apple-basic .pdf-code,
    .slides-theme-apple-basic pre {
      border-radius: 14px !important;
      border-left: none !important;
    }
    .pdf-slide-header {
      font-size: 13px;
      color: #64748b;
      margin-bottom: 24px;
      display: flex;
      justify-content: space-between;
      border-bottom: 1px solid #e2e8f0;
      padding-bottom: 8px;
    }
    .theme-dark .pdf-slide-header {
      border-bottom-color: #2e3346;
      color: #94a3b8;
    }
    .pdf-slide-body {
      flex: 1;
      display: flex;
      flex-direction: column;
      gap: 16px;
      font-size: 20px;
      line-height: 1.6;
      overflow: hidden;
    }
    .pdf-block h1 { font-size: 2.5rem; font-weight: 800; color: #2563eb; margin-bottom: 12px; }
    .pdf-block h2 { font-size: 1.9rem; font-weight: 700; color: #1d4ed8; margin-bottom: 10px; }
    .pdf-block h3 { font-size: 1.4rem; font-weight: 600; margin-bottom: 8px; }
    .pdf-block h4 { font-size: 1.2rem; font-weight: 600; margin-bottom: 6px; }
    .pdf-block p { font-size: 1.15rem; color: inherit; }
    .pdf-code,
    pre {
      background: #f1f5f9;
      padding: 14px 18px;
      border-radius: 6px;
      font-family: "JetBrains Mono", Consolas, monospace;
      font-size: 0.95rem;
      border-left: 4px solid #3b82f6;
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      max-width: 100% !important;
      box-sizing: border-box !important;
    }
    .pdf-code code,
    pre code {
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      display: block !important;
      width: 100% !important;
      box-sizing: border-box !important;
    }
    .code-line {
      display: flex !important;
      align-items: flex-start !important;
      width: 100% !important;
      box-sizing: border-box !important;
      line-height: 1.6;
    }
    .code-line .line-no {
      display: inline-block !important;
      flex-shrink: 0 !important;
      min-width: 2.2em !important;
      text-align: right !important;
      margin-right: 12px !important;
      user-select: none !important;
      opacity: 0.45 !important;
    }
    .code-line .line-content {
      flex: 1 1 0% !important;
      min-width: 0 !important;
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
    }
    .theme-dark .pdf-code {
      background: #1e1e24;
      border-left-color: #60a5fa;
    }
    .pdf-quote {
      border-left: 4px solid #10b981;
      background: rgba(16, 185, 129, 0.08);
      padding: 10px 16px;
      border-radius: 0 4px 4px 0;
      font-style: italic;
    }
    .pdf-image,
    .slide-media-img {
      max-width: 100% !important;
      max-height: 48vh !important;
      width: auto !important;
      height: auto !important;
      object-fit: contain !important;
      border-radius: 6px;
      margin: auto;
      display: block;
    }
    .slide-media-block,
    .slide-media-container,
    .slide-video-container {
      display: flex;
      flex-direction: column;
      justify-content: center;
      align-items: center;
      width: 100%;
      max-height: 48vh;
      margin: 8px 0;
      overflow: hidden;
    }
    .slide-list-media {
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: flex-start;
      margin-top: 8px;
      margin-bottom: 6px;
      max-width: 100%;
      overflow: hidden;
    }
    .slide-list-media img,
    .slide-list-media video,
    .slide-list-media .list-item-gif {
      max-width: 100% !important;
      max-height: min(280px, 36vh) !important;
      width: auto !important;
      height: auto !important;
      min-width: 0 !important;
      min-height: 0 !important;
      object-fit: contain !important;
      border-radius: 6px;
      display: block;
      margin: 0 auto !important;
    }
    .slide-video-player {
      max-width: 100% !important;
      max-height: 48vh !important;
      width: auto !important;
      height: auto !important;
      object-fit: contain !important;
      border-radius: 6px;
      background: #000;
      border: 1px solid #cbd5e1;
    }
    .pdf-two-cols-wrapper,
    .layout-two-cols-grid,
    .layout-cols-wrapper,
    .layout-cols-grid {
      display: grid;
      grid-template-columns: minmax(0, 1fr) minmax(0, 1fr);
      grid-template-rows: minmax(0, 1fr) !important;
      gap: var(--slides-cols-gap, 32px);
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      overflow: hidden !important;
    }
    .layout-cols-header-container,
    .layout-two-cols-header-container,
    .layout-three-cols-header-container,
    .layout-clover-container {
      display: flex;
      flex-direction: column;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      overflow: hidden !important;
    }
    .layout-header-section {
      width: 100%;
      margin-bottom: var(--slides-header-gap, 16px) !important;
      flex-shrink: 0;
    }
    .layout-header-section h1,
    .layout-header-section h2,
    .layout-header-section h3 {
      margin-bottom: var(--slides-title-margin-bottom, 10px) !important;
    }
    .pdf-three-cols-wrapper,
    .layout-three-cols-grid {
      display: grid;
      grid-template-columns: minmax(0, 1fr) minmax(0, 1fr) minmax(0, 1fr);
      grid-template-rows: minmax(0, 1fr) !important;
      gap: calc(var(--slides-cols-gap, 32px) * 0.75);
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      box-sizing: border-box;
      overflow: hidden !important;
    }
    .pdf-clover-wrapper,
    .layout-clover-grid {
      display: grid;
      grid-template-columns: repeat(2, minmax(0, 1fr)) !important;
      grid-template-rows: repeat(2, minmax(0, 1fr)) !important;
      gap: calc(var(--slides-cols-gap, 32px) * 0.625);
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      box-sizing: border-box;
      overflow: hidden !important;
    }
    .layout-clover-grid .pdf-col {
      background: transparent !important;
      border: none !important;
      box-shadow: none !important;
    }
    .pdf-col {
      display: flex;
      flex-direction: column;
      gap: var(--slides-block-gap, 14px);
      min-width: 0;
      width: 100%;
      max-width: 100%;
      height: 100%;
      max-height: 100%;
      min-height: 0;
      justify-content: flex-start;
      overflow: hidden;
      box-sizing: border-box;
      overflow-wrap: break-word;
      word-break: break-word;
      white-space: normal;
    }
    /* 表头多栏内超级块子块首个列表项去圆点后居中显示标题/首行文本 (仅在存在超级块分栏时生效) */
    .has-superblock-cols .pdf-col > *:first-child .slide-list-item-title,
    .has-superblock-cols .pdf-col > *:first-child :is(h1, h2, h3, h4, h5, h6),
    .has-superblock-cols .pdf-col > *:first-child p.slide-list-item-title,
    .has-superblock-cols .pdf-col > *:first-child p:first-of-type,
    .has-superblock-cols .pdf-col > *:first-child p:first-child,
    .has-superblock-cols .pdf-col > *:first-child :is(ul, ol) > li:first-child,
    .has-superblock-cols .pdf-col > *:first-child .slide-list > .slide-list-item:first-child,
    .has-superblock-cols .pdf-col > *:first-child .pdf-list > li:first-child,
    .has-superblock-cols .slides-col-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    .has-superblock-cols .slides-col-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      list-style: none !important;
      list-style-type: none !important;
      text-align: center !important;
      margin-left: 0 !important;
      padding-left: 0 !important;
      width: 100% !important;
    }

    /* 彻底清除首个列表项的原生圆点 Marker (仅在存在超级块分栏时生效) */
    .has-superblock-cols .pdf-col > *:first-child :is(ul, ol) > li:first-child::marker {
      content: "" !important;
      display: none !important;
    }

    /* 确保首个列表项内部内联与块级元素居中 (仅在存在超级块分栏时生效) */
    .has-superblock-cols .pdf-col > *:first-child :is(ul, ol) > li:first-child * {
      text-align: center !important;
    }

    /* 栏内说明段落与列表项：左对齐，自然阅读排版 */
    .has-superblock-cols .pdf-col .slide-list-item-desc,
    .has-superblock-cols .pdf-col li:not(:first-child) {
      text-align: left !important;
    }

    /* 全局特定标题大小规范化 (除封面外页首首个标题按 H2 1.7rem，表头多栏内首个标题按 H3 1.3rem) */
    [data-normalize-headings="true"] .slides-page-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .slides-page-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .pdf-slide:not(.layout-cover) > :is(.pdf-block, .slide-block):first-child :is(h1, h2, h3, h4, h5, h6),
    [data-normalize-headings="true"] .pdf-slide:not(.layout-cover) > .layout-header-section :is(.pdf-block, .slide-block):first-child :is(h1, h2, h3, h4, h5, h6),
    [data-normalize-headings="true"] .pdf-slide:not(.layout-cover) > :not(.layout-cols-wrapper):not(.pdf-two-cols-wrapper):not(.layout-image-cols-grid):first-child :is(h1, h2, h3, h4, h5, h6) {
      font-size: 1.7rem !important;
      font-weight: 600 !important;
      line-height: 1.25 !important;
      margin-bottom: var(--slides-title-margin-bottom, 10px) !important;
    }

    [data-normalize-headings="true"] .has-superblock-cols .slides-col-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .has-superblock-cols .slides-col-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .has-superblock-cols .pdf-col > *:first-child :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      font-size: 1.3rem !important;
      font-weight: 600 !important;
      line-height: 1.3 !important;
      margin-bottom: 8px !important;
      text-align: center !important;
    }

    /* 图左与图右版式标题完全保留用户原始字号与默认排版，不进行任何固定大小规范化 */
    [data-normalize-headings="true"] :is(.layout-image-left, .layout-image-right, .image-left-content, .image-right-content) :is(h1, h2, h3, h4, h5, h6) {
      text-align: left !important;
    }
    .pdf-col > .pdf-block,
    .pdf-col > .slide-block {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      max-height: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      width: 100% !important;
      height: 100% !important;
      box-sizing: border-box !important;
      overflow: hidden !important;
    }
    .pdf-col .slide-list-item-title,
    .pdf-col h1, .pdf-col h2, .pdf-col h3, .pdf-col h4, .pdf-col h5, .pdf-col h6,
    .pdf-col .slide-list-item-desc {
      flex: 0 0 auto !important;
      margin-top: 0 !important;
      margin-bottom: 6px !important;
    }
    .pdf-col .slide-list-media,
    .pdf-col .slide-video-container,
    .pdf-col .slide-media-container {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      min-width: 0 !important;
      width: 100% !important;
      height: 100% !important;
      max-height: 100% !important;
      max-width: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
      justify-content: flex-start !important;
      overflow: hidden !important;
      margin: 0 !important;
      padding: 0 !important;
      box-sizing: border-box !important;
    }
    .pdf-col li:has(.slide-list-media),
    .pdf-col li:has(.slide-media-container),
    .pdf-col li:has(.slide-video-container),
    .pdf-col li:has(img),
    .pdf-col li:has(video),
    .pdf-col .pdf-list-item:has(.slide-list-media),
    .pdf-col .pdf-list-item:has(.slide-media-container),
    .pdf-col .pdf-list-item:has(.slide-video-container),
    .pdf-col .pdf-list-item:has(img),
    .pdf-col .pdf-list-item:has(video) {
      display: list-item !important;
      list-style-type: disc !important;
      flex: 0 0 auto !important;
      height: auto !important;
      max-height: none !important;
      overflow: visible !important;
      margin-bottom: 6px !important;
    }
    .pdf-col video,
    .layout-three-cols-grid video,
    .layout-two-cols-grid video,
    .pdf-col img,
    .layout-three-cols-grid img,
    .layout-two-cols-grid img,
    .pdf-col .slide-video-player {
      max-width: 100% !important;
      max-height: 100% !important;
      width: auto !important;
      height: auto !important;
      min-width: 0 !important;
      min-height: 0 !important;
      object-fit: contain !important;
      display: block !important;
      margin: 0 auto !important;
    }
    .pdf-col * {
      overflow-wrap: break-word;
      word-break: break-word;
      box-sizing: border-box;
    }
    .pdf-col pre {
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      max-width: 100% !important;
      box-sizing: border-box !important;
    }
    .pdf-list-item {
      padding-left: 20px;
    }
    .pdf-list {
      padding-left: 24px;
      margin: calc(var(--slides-block-gap, 14px) * 0.6) 0;
      display: flex;
      flex-direction: column;
      gap: var(--slides-list-gap, 6px);
    }
    .pdf-list li {
      font-size: 1.15rem;
      line-height: var(--slides-line-height, 1.6);
    }
    .pdf-task-item {
      list-style: none;
      margin-left: -20px;
      display: flex;
      align-items: center;
      gap: 8px;
    }
    .pdf-task-item input[type="checkbox"] {
      width: 1.15em;
      height: 1.15em;
      cursor: pointer;
    }
    /* 两栏与三栏及多栏（超级块分栏）布局：紧凑自然行距，子列表保留圆点与层级缩进 */
    .layout-two-cols ul,
    .layout-cols-header ul,
    .layout-two-cols-header ul,
    .layout-three-cols ul,
    .layout-three-cols-header ul,
    .two-cols-left ul,
    .two-cols-right ul,
    .three-cols-col ul,
    .col ul,
    .pdf-two-cols-wrapper ul,
    .pdf-three-cols-wrapper ul,
    .pdf-col ul,
    .layout-two-cols-grid .pdf-list,
    .layout-three-cols-grid .pdf-list,
    .layout-cols-grid .pdf-list,
    .layout-two-cols-grid .pdf-list--unordered,
    .layout-three-cols-grid .pdf-list--unordered,
    .layout-cols-grid .pdf-list--unordered {
      list-style: disc !important;
      list-style-type: disc !important;
      padding-left: 1.25em !important;
      margin-left: 0 !important;
      margin-top: 0 !important;
      margin-bottom: 8px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: block !important;
    }
    .layout-two-cols ol,
    .layout-cols-header ol,
    .layout-two-cols-header ol,
    .layout-three-cols ol,
    .layout-three-cols-header ol,
    .two-cols-left ol,
    .two-cols-right ol,
    .three-cols-col ol,
    .col ol,
    .pdf-two-cols-wrapper ol,
    .pdf-three-cols-wrapper ol,
    .pdf-col ol,
    .layout-two-cols-grid .pdf-list--ordered,
    .layout-three-cols-grid .pdf-list--ordered,
    .layout-cols-grid .pdf-list--ordered {
      list-style: decimal !important;
      list-style-type: decimal !important;
      padding-left: 1.25em !important;
      margin-left: 0 !important;
      margin-top: 0 !important;
      margin-bottom: 8px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: block !important;
    }
    .layout-two-cols li,
    .layout-cols-header li,
    .layout-two-cols-header li,
    .layout-three-cols li,
    .layout-three-cols-header li,
    .two-cols-left li,
    .two-cols-right li,
    .three-cols-col li,
    .col li,
    .pdf-col li,
    .pdf-col .pdf-list-item {
      padding-left: 0.2em !important;
      margin-left: 0 !important;
      margin-bottom: var(--slides-list-gap, 6px) !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: list-item !important;
      line-height: var(--slides-line-height, 1.6) !important;
    }
    .layout-two-cols ul ul,
    .layout-three-cols ul ul,
    .three-cols-col ul ul,
    .pdf-col ul ul {
      list-style: circle !important;
      list-style-type: circle !important;
      padding-left: 1.25em !important;
      margin-top: 4px !important;
      margin-bottom: 4px !important;
    }
    /* 列表项内嵌标题与说明排版 */
    .slide-list-item-title,
    .pdf-list li > h1,
    .pdf-list li > h2,
    .pdf-list li > h3,
    .pdf-list li > h4,
    .pdf-list li > h5,
    .pdf-list li > h6,
    li > h1.slide-list-item-title,
    li > h2.slide-list-item-title,
    li > h3.slide-list-item-title,
    li > h4.slide-list-item-title {
      margin-top: 2px !important;
      margin-bottom: 6px !important;
      line-height: 1.35 !important;
      font-weight: 700 !important;
    }
    .pdf-list li > h1, li > h1.slide-list-item-title { font-size: 1.6rem !important; }
    .pdf-list li > h2, li > h2.slide-list-item-title { font-size: 1.4rem !important; }
    .pdf-list li > h3, li > h3.slide-list-item-title { font-size: 1.22rem !important; }
    .pdf-list li > h4, li > h4.slide-list-item-title { font-size: 1.1rem !important; }

    /* 全局特定标题大小规范化后置强力锁定 (防止被列表项内部字号覆盖) */
    [data-normalize-headings="true"] .slides-page-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .slides-page-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      font-size: 1.7rem !important;
      font-weight: 600 !important;
      line-height: 1.25 !important;
      margin-bottom: 10px !important;
    }
    [data-normalize-headings="true"] .has-superblock-cols .slides-col-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .has-superblock-cols .slides-col-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .has-superblock-cols .pdf-col > *:first-child :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      font-size: 1.3rem !important;
      font-weight: 600 !important;
      line-height: 1.3 !important;
      margin-bottom: 8px !important;
      text-align: center !important;
    }
    /* 基础列表项前缀样式 */
    .slide-block ul,
    .slide-list--unordered,
    .pdf-list--unordered {
      list-style: disc !important;
      list-style-type: disc !important;
    }
    .slide-block ol,
    .slide-list--ordered,
    .pdf-list--ordered {
      list-style: decimal !important;
      list-style-type: decimal !important;
    }
    .slide-block li,
    .slide-list-item,
    .pdf-list-item,
    .pdf-list li {
      display: list-item !important;
    }

    /* 隐藏无序列表前缀标记 */
    [data-hide-unordered-markers="true"] :is(ul, .slide-list, .slide-list--unordered, .pdf-list, .pdf-list--unordered),
    [data-hide-unordered-markers="true"] :is(ul, .slide-list, .slide-list--unordered, .pdf-list, .pdf-list--unordered) > li,
    [data-hide-unordered-markers="true"] li.slide-list-item,
    [data-hide-unordered-markers="true"] ul > li {
      list-style: none !important;
      list-style-type: none !important;
      padding-left: 0 !important;
      margin-left: 0 !important;
    }
    [data-hide-unordered-markers="true"] :is(ul, .slide-list, .slide-list--unordered, .pdf-list, .pdf-list--unordered) > li::marker,
    [data-hide-unordered-markers="true"] li.slide-list-item::marker {
      content: "" !important;
      display: none !important;
    }

    /* 隐藏有序列表前缀标记 */
    [data-hide-ordered-markers="true"] :is(ol, .slide-list, .slide-list--ordered, .pdf-list, .pdf-list--ordered),
    [data-hide-ordered-markers="true"] :is(ol, .slide-list, .slide-list--ordered, .pdf-list, .pdf-list--ordered) > li,
    [data-hide-ordered-markers="true"] li.slide-list-item,
    [data-hide-ordered-markers="true"] ol > li {
      list-style: none !important;
      list-style-type: none !important;
      padding-left: 0 !important;
      margin-left: 0 !important;
    }
    [data-hide-ordered-markers="true"] :is(ol, .slide-list, .slide-list--ordered, .pdf-list, .pdf-list--ordered) > li::marker,
    [data-hide-ordered-markers="true"] li.slide-list-item::marker {
      content: "" !important;
      display: none !important;
    }

    .slide-list-item-desc,
    .pdf-list li > p {
      margin-top: 4px !important;
      margin-bottom: 6px !important;
      font-size: 1.05rem;
      line-height: 1.55;
      opacity: 0.92;
    }
    kbd {
      display: inline-block;
      padding: 2px 7px;
      font-family: ui-monospace, SFMono-Regular, "SF Mono", Menlo, Consolas, "Liberation Mono", monospace;
      font-size: 0.85em;
      font-weight: 600;
      line-height: 1.25;
      color: inherit;
      background: rgba(125, 125, 125, 0.12);
      border: 1px solid rgba(125, 125, 125, 0.35);
      border-bottom-width: 2px;
      border-radius: 5px;
      box-shadow: 0 1px 2px rgba(0, 0, 0, 0.12);
      margin: 0 2px;
      vertical-align: middle;
      white-space: nowrap;
    }
    .theme-dark kbd {
      background: rgba(255, 255, 255, 0.1);
      border-color: rgba(255, 255, 255, 0.25);
      border-bottom-color: rgba(255, 255, 255, 0.4);
      color: #f1f5f9;
      box-shadow: 0 1px 2px rgba(0, 0, 0, 0.4);
    }
    a {
      color: inherit;
      text-decoration: none;
      border-bottom: 1px dashed currentColor;
    }
    .slides-ref-tag, a.slides-ref-tag {
      display: inline-flex;
      align-items: center;
      background: rgba(16, 185, 129, 0.1);
      color: #059669;
      border: 1px solid rgba(16, 185, 129, 0.25);
      border-radius: 4px;
      padding: 2px 8px;
      font-size: 0.88em;
      text-decoration: none;
      margin: 2px 4px 2px 0;
    }
    .theme-dark .slides-ref-tag, .theme-dark a.slides-ref-tag {
      background: rgba(52, 211, 153, 0.15);
      color: #34d399;
      border-color: rgba(52, 211, 153, 0.3);
    }
    .slides-block-ref, .pdf-block--ref {
      background: rgba(16, 185, 129, 0.06);
      border-left: 3px solid #059669;
      border-radius: 0 6px 6px 0;
      padding: 10px 14px;
      margin: 8px 0;
    }
    .theme-dark .slides-block-ref, .theme-dark .pdf-block--ref {
      background: rgba(52, 211, 153, 0.08);
      border-left-color: #34d399;
    }
    .pdf-slide-notes {
      font-size: 14px;
      color: #059669;
      border-top: 1px dashed #cbd5e1;
      padding-top: 12px;
      margin-top: auto;
      line-height: 1.5;
    }
    .theme-dark .pdf-slide-notes {
      color: #34d399;
      border-top-color: #334155;
    }
    /* Layouts */
    .layout-cover .pdf-slide-body,
    .layout-center .pdf-slide-body,
    .layout-fact .pdf-slide-body,
    .layout-cover-container,
    .layout-center-container,
    .layout-fact-container {
      justify-content: center;
      align-items: center;
      text-align: center;
      width: 100%;
      height: 100%;
      display: flex;
      flex-direction: column;
    }
    .layout-cover h1,
    .layout-cover-container h1 {
      font-size: 3.2rem;
      font-weight: 800;
      margin-bottom: 16px;
    }
    .layout-center-container h1,
    .layout-center h1 {
      font-size: 2.6rem;
      font-weight: 700;
    }
    .layout-fact .fact-hero-glow,
    .layout-fact-container .fact-hero-glow {
      position: absolute;
      top: 50%;
      left: 50%;
      width: 600px;
      height: 600px;
      transform: translate(-50%, -50%);
      background: radial-gradient(circle, rgba(var(--b3-theme-primary-rgb, 66, 133, 244), 0.22) 0%, rgba(var(--b3-theme-primary-rgb, 66, 133, 244), 0.05) 45%, transparent 70%);
      pointer-events: none;
      filter: blur(28px);
      z-index: 0;
    }
    .layout-fact .fact-stats-grid,
    .layout-fact-container .fact-stats-grid {
      position: relative;
      z-index: 1;
      display: grid;
      width: 100%;
      gap: 32px;
      justify-content: center;
      align-items: center;
    }
    .layout-fact-container .fact-stats-grid--cols-1 { grid-template-columns: 1fr; max-width: 800px; }
    .layout-fact-container .fact-stats-grid--cols-2 { grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 48px; }
    .layout-fact-container .fact-stats-grid--cols-3 { grid-template-columns: repeat(3, minmax(0, 1fr)); gap: 28px; }
    .layout-fact-container .fact-stats-grid--cols-4 { grid-template-columns: repeat(4, minmax(0, 1fr)); gap: 20px; }
    .layout-fact .fact-stat-card,
    .layout-fact-container .fact-stat-card {
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      text-align: center;
      width: 100%;
      box-sizing: border-box;
      padding: 10px 14px;
    }
    .layout-fact .fact-value,
    .layout-fact-container .fact-value,
    .layout-fact .fact-value-wrapper,
    .layout-fact-container .fact-value-wrapper,
    .layout-fact .fact-value-box,
    .layout-fact-container .fact-value-box {
      font-weight: 900 !important;
      color: var(--slide-accent, #3b82f6) !important;
      line-height: 1.05 !important;
      margin-bottom: 8px;
    }
    .layout-fact-cols-1 .fact-value-wrapper,
    .fact-stats-grid--cols-1 .fact-value-wrapper { font-size: 5.5rem !important; }
    .layout-fact-cols-2 .fact-value-wrapper,
    .fact-stats-grid--cols-2 .fact-value-wrapper { font-size: 4.2rem !important; }
    .layout-fact-cols-3 .fact-value-wrapper,
    .fact-stats-grid--cols-3 .fact-value-wrapper { font-size: 3.4rem !important; }
    .layout-fact-cols-4 .fact-value-wrapper,
    .fact-stats-grid--cols-4 .fact-value-wrapper { font-size: 2.8rem !important; }
    .layout-fact .fact-value-box :is(h1, h2, h3, h4, p, span),
    .layout-fact-container .fact-value-box :is(h1, h2, h3, h4, p, span),
    .layout-fact .fact-value-wrapper :is(h1, h2, h3, h4, p, span),
    .layout-fact-container .fact-value-wrapper :is(h1, h2, h3, h4, p, span) {
      font-size: inherit !important;
      font-weight: inherit !important;
      line-height: inherit !important;
      color: inherit !important;
      margin: 0 !important;
    }
    .layout-fact .fact-divider-line,
    .layout-fact-container .fact-divider-line {
      width: 50px;
      height: 3px;
      background: var(--slide-accent, #3b82f6);
      margin: 10px auto 12px;
      opacity: 0.8;
    }
    .layout-fact .fact-label,
    .layout-fact-container .fact-label,
    .layout-fact .fact-label-wrapper,
    .layout-fact-container .fact-label-wrapper,
    .layout-fact .fact-label-box,
    .layout-fact-container .fact-label-box {
      font-size: 1.25rem !important;
      font-weight: 500 !important;
      opacity: 0.88;
      line-height: 1.4 !important;
      max-width: 440px;
      margin: 0 auto;
      text-align: center !important;
    }
    .fact-stats-grid--cols-1 .fact-label-wrapper,
    .layout-fact-cols-1 .fact-label-wrapper { font-size: 1.55rem !important; max-width: 680px; }
    .layout-fact .fact-label-box :is(h1, h2, h3, h4, p, span, li),
    .layout-fact-container .fact-label-box :is(h1, h2, h3, h4, p, span, li),
    .layout-fact .fact-label-wrapper :is(h1, h2, h3, h4, p, span, li),
    .layout-fact-container .fact-label-wrapper :is(h1, h2, h3, h4, p, span, li) {
      font-size: inherit !important;
      font-weight: inherit !important;
      line-height: inherit !important;
      color: inherit !important;
      opacity: inherit !important;
      margin: 0 !important;
      text-align: center !important;
    }

    /* Timeline / Steps 时间线 (PDF 导出) */
    .layout-timeline-container,
    .layout-steps-container {
      display: flex;
      flex-direction: column;
      width: 100%;
      height: 100%;
      box-sizing: border-box;
      padding: 28px 48px;
    }
    .timeline-track-wrapper {
      display: flex;
      flex-direction: row;
      align-items: flex-start;
      justify-content: space-between;
      width: 100%;
      gap: 20px;
      margin: auto 0;
      position: relative;
    }
    .timeline-step-item {
      display: flex;
      flex-direction: column;
      align-items: center;
      flex: 1;
      text-align: center;
      position: relative;
    }
    .timeline-node-container {
      position: relative;
      display: flex;
      align-items: center;
      justify-content: center;
      width: 100%;
      margin-bottom: 18px;
    }
    .timeline-node-badge {
      width: 40px;
      height: 40px;
      border-radius: 50%;
      background: var(--slide-accent, #3b82f6);
      color: #ffffff;
      font-size: 1.2rem;
      font-weight: 800;
      display: flex;
      align-items: center;
      justify-content: center;
      z-index: 2;
    }
    .timeline-connector-line {
      position: absolute;
      top: 50%;
      left: 50%;
      width: 100%;
      height: 2px;
      background: #94a3b8;
      transform: translateY(-50%);
      z-index: 1;
    }
    .timeline-step-content {
      width: 100%;
      padding: 12px;
      border: 1px solid #cbd5e1;
      border-radius: 8px;
      box-sizing: border-box;
    }
    .timeline-step-content h1,
    .timeline-step-content h2,
    .timeline-step-content h3 {
      font-size: 1.2rem !important;
      font-weight: 700 !important;
      margin-bottom: 6px !important;
    }
    .timeline-step-content p,
    .timeline-step-content li {
      font-size: 1rem !important;
      line-height: 1.4 !important;
    }

    /* Quote 版式 (PDF 导出) */
    .layout-quote,
    .layout-quote-container {
      display: flex;
      flex-direction: column;
      justify-content: center;
      align-items: center;
      width: 100%;
      height: 100%;
      position: relative;
      padding: 40px 60px;
      box-sizing: border-box;
    }
    .layout-quote .quote-watermark-icon,
    .layout-quote-container .quote-watermark-icon {
      position: absolute;
      top: 10%;
      left: 6%;
      font-size: 14rem;
      line-height: 1;
      font-family: Georgia, serif;
      opacity: 0.08;
      color: currentColor;
    }
    .layout-quote .quote-content-body,
    .layout-quote-container .quote-content-body {
      max-width: 800px;
      width: 100%;
      text-align: center;
      position: relative;
      z-index: 1;
    }
    .quote-text,
    .layout-quote-container .quote-body {
      font-size: 2rem !important;
      font-style: italic !important;
      line-height: 1.6 !important;
      margin-bottom: 20px;
    }
    .quote-footer,
    .quote-author {
      font-size: 1.2rem;
      opacity: 0.75;
      text-align: right;
    }

    /* Intro 版式 (PDF 导出) */
    .layout-intro,
    .layout-intro-container {
      display: flex;
      flex-direction: row;
      align-items: center;
      justify-content: center;
      gap: 48px;
      width: 100%;
      height: 100%;
      box-sizing: border-box;
      padding: 36px 54px;
    }
    .intro-avatar-col {
      flex-shrink: 0;
    }
    .intro-avatar-box {
      width: 220px;
      height: 220px;
      border-radius: 50%;
      overflow: hidden;
      border: 3px solid rgba(66, 133, 244, 0.35);
      background: rgba(125, 125, 125, 0.08);
      display: flex;
      align-items: center;
      justify-content: center;
    }
    .intro-avatar-img {
      width: 100%;
      height: 100%;
      object-fit: cover;
      display: block;
    }
    .intro-avatar-svg {
      width: 100px;
      height: 100px;
      opacity: 0.35;
      fill: currentColor;
    }
    .intro-info-col {
      flex: 1;
      display: flex;
      flex-direction: column;
      justify-content: center;
    }
    .intro-info-col h1 {
      font-size: 2.6rem;
      font-weight: 800;
      margin-bottom: 8px;
    }
    .intro-info-col h2, .intro-info-col h3 {
      font-size: 1.35rem;
      font-weight: 600;
      color: var(--slide-accent, #3b82f6);
      margin-bottom: 14px;
    }
    .intro-info-col p {
      font-size: 1.15rem;
      line-height: 1.5;
      opacity: 0.9;
    }
    @media print {
      .slides-motion-fade-in,
      .slides-motion-slide-up,
      .slides-motion-slide-down,
      .slides-motion-slide-left,
      .slides-motion-slide-right,
      .slides-motion-zoom-in,
      .slides-motion-pop,
      .slides-motion-bounce {
        animation: none !important;
        opacity: 1 !important;
        transform: none !important;
      }
      /* PDF 打印讲义下禁用动态蒙版遮挡，保证内容 100% 完整可见 */
      .slides-mask-layer,
      .slides-mask-overlay,
      .slides-mask-divider-line {
        display: none !important;
        opacity: 0 !important;
        mask: none !important;
        -webkit-mask: none !important;
      }
      .slides-mask-body-container {
        clip-path: none !important;
        -webkit-clip-path: none !important;
        overflow: visible !important;
      }
    }
  `}function Tg(e,t){const o="即现讲义",i="16:9",n=_r(e.config.colorSchema),s=e.config.theme||"apple-basic",l=e.slides.map((r,a)=>{const c=r.frontmatter.layout||"default",u=r.frontmatter.spacing,f=u&&u!=="inherit"?u:e.config.spacing||"normal",h=fc(r),d=`${a+1} / ${e.slides.length}`,b=r.frontmatter.background||e.config.background,m=sc(b),y=m===!0?"light":m===!1?"dark":n,g=b&&!/^(http|\/|data:|assets\/)/.test(b)?`background: ${nt(b)};`:"";return`
      <section class="pdf-slide-page layout-${c} theme-${y} spacing-${f} slides-theme-${s}" data-slides-theme="${s}" style="${g}">
        <header class="pdf-slide-header">
          <span class="pdf-doc-title">${nt(o)}</span>
          ${`<span class="pdf-page-badge">P. ${d}</span>`}
        </header>
        <div class="pdf-slide-body">
          ${h}
        </div>
        ${r.notes?`
          <footer class="pdf-slide-notes">
            <strong>演讲备注:</strong> ${nt(r.notes)}
          </footer>
        `:""}
      </section>
    `}).join(`
`);return`<!DOCTYPE html>
<html lang="zh-CN">
<head>
  <meta charset="UTF-8">
  <title>${nt(o)} - 高保真讲义</title>
  <style>
    ${$g({pageRatio:i,customInlineStyles:t==null?void 0:t.customInlineStyles})}
  </style>
</head>
<body data-normalize-headings="${e.config.normalizeHeadingSizes?"true":"false"}" data-hide-unordered-markers="${e.config.showUnorderedListMarkers===!1?"true":"false"}" data-hide-ordered-markers="${e.config.showOrderedListMarkers===!1?"true":"false"}">
  ${l}
</body>
</html>`}function mc(e,t){var n;if(typeof window>"u"||typeof document>"u")return!1;const o=Tg(e,t);try{const s=document.createElement("iframe");s.style.position="fixed",s.style.right="0",s.style.bottom="0",s.style.width="0",s.style.height="0",s.style.border="none",s.style.visibility="hidden",document.body.appendChild(s);const l=(n=s.contentWindow)==null?void 0:n.document;if(l)return l.open(),l.write(o),l.close(),setTimeout(()=>{var r,a;try{(r=s.contentWindow)==null||r.focus(),(a=s.contentWindow)==null||a.print()}finally{setTimeout(()=>{s.remove()},2e3)}},350),!0}catch(s){console.warn("[pdf-exporter] iframe 打印模式异常，降级尝试 window.open:",s)}const i=window.open("","_blank");return i?(i.document.write(o),i.document.close(),i.focus(),setTimeout(()=>{i.print(),i.close()},350),!0):!1}var gn=typeof globalThis<"u"?globalThis:typeof window<"u"?window:typeof global<"u"?global:typeof self<"u"?self:{};function Ag(e){return e&&e.__esModule&&Object.prototype.hasOwnProperty.call(e,"default")?e.default:e}function yn(e){throw new Error('Could not dynamically require "'+e+'". Please configure the dynamicRequireTargets or/and ignoreDynamicRequires option of @rollup/plugin-commonjs appropriately for this require call to work.')}var Ss={exports:{}};/*!

JSZip v3.10.1 - A JavaScript class for generating and reading zip files
<http://stuartk.com/jszip>

(c) 2009-2016 Stuart Knightley <stuart [at] stuartk.com>
Dual licenced under the MIT license or GPLv3. See https://raw.github.com/Stuk/jszip/main/LICENSE.markdown.

JSZip uses the library pako released under the MIT license :
https://github.com/nodeca/pako/blob/main/LICENSE
*/var Ea;function Mg(){return Ea||(Ea=1,(function(e,t){(function(o){e.exports=o()})(function(){return(function o(i,n,s){function l(c,u){if(!n[c]){if(!i[c]){var f=typeof yn=="function"&&yn;if(!u&&f)return f(c,!0);if(r)return r(c,!0);var h=new Error("Cannot find module '"+c+"'");throw h.code="MODULE_NOT_FOUND",h}var d=n[c]={exports:{}};i[c][0].call(d.exports,function(b){var m=i[c][1][b];return l(m||b)},d,d.exports,o,i,n,s)}return n[c].exports}for(var r=typeof yn=="function"&&yn,a=0;a<s.length;a++)l(s[a]);return l})({1:[function(o,i,n){var s=o("./utils"),l=o("./support"),r="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";n.encode=function(a){for(var c,u,f,h,d,b,m,y=[],g=0,x=a.length,k=x,I=s.getTypeOf(a)!=="string";g<a.length;)k=x-g,f=I?(c=a[g++],u=g<x?a[g++]:0,g<x?a[g++]:0):(c=a.charCodeAt(g++),u=g<x?a.charCodeAt(g++):0,g<x?a.charCodeAt(g++):0),h=c>>2,d=(3&c)<<4|u>>4,b=1<k?(15&u)<<2|f>>6:64,m=2<k?63&f:64,y.push(r.charAt(h)+r.charAt(d)+r.charAt(b)+r.charAt(m));return y.join("")},n.decode=function(a){var c,u,f,h,d,b,m=0,y=0,g="data:";if(a.substr(0,g.length)===g)throw new Error("Invalid base64 input, it looks like a data url.");var x,k=3*(a=a.replace(/[^A-Za-z0-9+/=]/g,"")).length/4;if(a.charAt(a.length-1)===r.charAt(64)&&k--,a.charAt(a.length-2)===r.charAt(64)&&k--,k%1!=0)throw new Error("Invalid base64 input, bad content length.");for(x=l.uint8array?new Uint8Array(0|k):new Array(0|k);m<a.length;)c=r.indexOf(a.charAt(m++))<<2|(h=r.indexOf(a.charAt(m++)))>>4,u=(15&h)<<4|(d=r.indexOf(a.charAt(m++)))>>2,f=(3&d)<<6|(b=r.indexOf(a.charAt(m++))),x[y++]=c,d!==64&&(x[y++]=u),b!==64&&(x[y++]=f);return x}},{"./support":30,"./utils":32}],2:[function(o,i,n){var s=o("./external"),l=o("./stream/DataWorker"),r=o("./stream/Crc32Probe"),a=o("./stream/DataLengthProbe");function c(u,f,h,d,b){this.compressedSize=u,this.uncompressedSize=f,this.crc32=h,this.compression=d,this.compressedContent=b}c.prototype={getContentWorker:function(){var u=new l(s.Promise.resolve(this.compressedContent)).pipe(this.compression.uncompressWorker()).pipe(new a("data_length")),f=this;return u.on("end",function(){if(this.streamInfo.data_length!==f.uncompressedSize)throw new Error("Bug : uncompressed data size mismatch")}),u},getCompressedWorker:function(){return new l(s.Promise.resolve(this.compressedContent)).withStreamInfo("compressedSize",this.compressedSize).withStreamInfo("uncompressedSize",this.uncompressedSize).withStreamInfo("crc32",this.crc32).withStreamInfo("compression",this.compression)}},c.createWorkerFrom=function(u,f,h){return u.pipe(new r).pipe(new a("uncompressedSize")).pipe(f.compressWorker(h)).pipe(new a("compressedSize")).withStreamInfo("compression",f)},i.exports=c},{"./external":6,"./stream/Crc32Probe":25,"./stream/DataLengthProbe":26,"./stream/DataWorker":27}],3:[function(o,i,n){var s=o("./stream/GenericWorker");n.STORE={magic:"\0\0",compressWorker:function(){return new s("STORE compression")},uncompressWorker:function(){return new s("STORE decompression")}},n.DEFLATE=o("./flate")},{"./flate":7,"./stream/GenericWorker":28}],4:[function(o,i,n){var s=o("./utils"),l=(function(){for(var r,a=[],c=0;c<256;c++){r=c;for(var u=0;u<8;u++)r=1&r?3988292384^r>>>1:r>>>1;a[c]=r}return a})();i.exports=function(r,a){return r!==void 0&&r.length?s.getTypeOf(r)!=="string"?(function(c,u,f,h){var d=l,b=h+f;c^=-1;for(var m=h;m<b;m++)c=c>>>8^d[255&(c^u[m])];return-1^c})(0|a,r,r.length,0):(function(c,u,f,h){var d=l,b=h+f;c^=-1;for(var m=h;m<b;m++)c=c>>>8^d[255&(c^u.charCodeAt(m))];return-1^c})(0|a,r,r.length,0):0}},{"./utils":32}],5:[function(o,i,n){n.base64=!1,n.binary=!1,n.dir=!1,n.createFolders=!0,n.date=null,n.compression=null,n.compressionOptions=null,n.comment=null,n.unixPermissions=null,n.dosPermissions=null},{}],6:[function(o,i,n){var s=null;s=typeof Promise<"u"?Promise:o("lie"),i.exports={Promise:s}},{lie:37}],7:[function(o,i,n){var s=typeof Uint8Array<"u"&&typeof Uint16Array<"u"&&typeof Uint32Array<"u",l=o("pako"),r=o("./utils"),a=o("./stream/GenericWorker"),c=s?"uint8array":"array";function u(f,h){a.call(this,"FlateWorker/"+f),this._pako=null,this._pakoAction=f,this._pakoOptions=h,this.meta={}}n.magic="\b\0",r.inherits(u,a),u.prototype.processChunk=function(f){this.meta=f.meta,this._pako===null&&this._createPako(),this._pako.push(r.transformTo(c,f.data),!1)},u.prototype.flush=function(){a.prototype.flush.call(this),this._pako===null&&this._createPako(),this._pako.push([],!0)},u.prototype.cleanUp=function(){a.prototype.cleanUp.call(this),this._pako=null},u.prototype._createPako=function(){this._pako=new l[this._pakoAction]({raw:!0,level:this._pakoOptions.level||-1});var f=this;this._pako.onData=function(h){f.push({data:h,meta:f.meta})}},n.compressWorker=function(f){return new u("Deflate",f)},n.uncompressWorker=function(){return new u("Inflate",{})}},{"./stream/GenericWorker":28,"./utils":32,pako:38}],8:[function(o,i,n){function s(d,b){var m,y="";for(m=0;m<b;m++)y+=String.fromCharCode(255&d),d>>>=8;return y}function l(d,b,m,y,g,x){var k,I,T=d.file,w=d.compression,C=x!==c.utf8encode,L=r.transformTo("string",x(T.name)),R=r.transformTo("string",c.utf8encode(T.name)),N=T.comment,F=r.transformTo("string",x(N)),E=r.transformTo("string",c.utf8encode(N)),O=R.length!==T.name.length,S=E.length!==N.length,W="",j="",_="",M=T.dir,B=T.date,Q={crc32:0,compressedSize:0,uncompressedSize:0};b&&!m||(Q.crc32=d.crc32,Q.compressedSize=d.compressedSize,Q.uncompressedSize=d.uncompressedSize);var q=0;b&&(q|=8),C||!O&&!S||(q|=2048);var U=0,ne=0;M&&(U|=16),g==="UNIX"?(ne=798,U|=(function(ae,Se){var $e=ae;return ae||($e=Se?16893:33204),(65535&$e)<<16})(T.unixPermissions,M)):(ne=20,U|=(function(ae){return 63&(ae||0)})(T.dosPermissions)),k=B.getUTCHours(),k<<=6,k|=B.getUTCMinutes(),k<<=5,k|=B.getUTCSeconds()/2,I=B.getUTCFullYear()-1980,I<<=4,I|=B.getUTCMonth()+1,I<<=5,I|=B.getUTCDate(),O&&(j=s(1,1)+s(u(L),4)+R,W+="up"+s(j.length,2)+j),S&&(_=s(1,1)+s(u(F),4)+E,W+="uc"+s(_.length,2)+_);var oe="";return oe+=`
\0`,oe+=s(q,2),oe+=w.magic,oe+=s(k,2),oe+=s(I,2),oe+=s(Q.crc32,4),oe+=s(Q.compressedSize,4),oe+=s(Q.uncompressedSize,4),oe+=s(L.length,2),oe+=s(W.length,2),{fileRecord:f.LOCAL_FILE_HEADER+oe+L+W,dirRecord:f.CENTRAL_FILE_HEADER+s(ne,2)+oe+s(F.length,2)+"\0\0\0\0"+s(U,4)+s(y,4)+L+W+F}}var r=o("../utils"),a=o("../stream/GenericWorker"),c=o("../utf8"),u=o("../crc32"),f=o("../signature");function h(d,b,m,y){a.call(this,"ZipFileWorker"),this.bytesWritten=0,this.zipComment=b,this.zipPlatform=m,this.encodeFileName=y,this.streamFiles=d,this.accumulate=!1,this.contentBuffer=[],this.dirRecords=[],this.currentSourceOffset=0,this.entriesCount=0,this.currentFile=null,this._sources=[]}r.inherits(h,a),h.prototype.push=function(d){var b=d.meta.percent||0,m=this.entriesCount,y=this._sources.length;this.accumulate?this.contentBuffer.push(d):(this.bytesWritten+=d.data.length,a.prototype.push.call(this,{data:d.data,meta:{currentFile:this.currentFile,percent:m?(b+100*(m-y-1))/m:100}}))},h.prototype.openedSource=function(d){this.currentSourceOffset=this.bytesWritten,this.currentFile=d.file.name;var b=this.streamFiles&&!d.file.dir;if(b){var m=l(d,b,!1,this.currentSourceOffset,this.zipPlatform,this.encodeFileName);this.push({data:m.fileRecord,meta:{percent:0}})}else this.accumulate=!0},h.prototype.closedSource=function(d){this.accumulate=!1;var b=this.streamFiles&&!d.file.dir,m=l(d,b,!0,this.currentSourceOffset,this.zipPlatform,this.encodeFileName);if(this.dirRecords.push(m.dirRecord),b)this.push({data:(function(y){return f.DATA_DESCRIPTOR+s(y.crc32,4)+s(y.compressedSize,4)+s(y.uncompressedSize,4)})(d),meta:{percent:100}});else for(this.push({data:m.fileRecord,meta:{percent:0}});this.contentBuffer.length;)this.push(this.contentBuffer.shift());this.currentFile=null},h.prototype.flush=function(){for(var d=this.bytesWritten,b=0;b<this.dirRecords.length;b++)this.push({data:this.dirRecords[b],meta:{percent:100}});var m=this.bytesWritten-d,y=(function(g,x,k,I,T){var w=r.transformTo("string",T(I));return f.CENTRAL_DIRECTORY_END+"\0\0\0\0"+s(g,2)+s(g,2)+s(x,4)+s(k,4)+s(w.length,2)+w})(this.dirRecords.length,m,d,this.zipComment,this.encodeFileName);this.push({data:y,meta:{percent:100}})},h.prototype.prepareNextSource=function(){this.previous=this._sources.shift(),this.openedSource(this.previous.streamInfo),this.isPaused?this.previous.pause():this.previous.resume()},h.prototype.registerPrevious=function(d){this._sources.push(d);var b=this;return d.on("data",function(m){b.processChunk(m)}),d.on("end",function(){b.closedSource(b.previous.streamInfo),b._sources.length?b.prepareNextSource():b.end()}),d.on("error",function(m){b.error(m)}),this},h.prototype.resume=function(){return!!a.prototype.resume.call(this)&&(!this.previous&&this._sources.length?(this.prepareNextSource(),!0):this.previous||this._sources.length||this.generatedError?void 0:(this.end(),!0))},h.prototype.error=function(d){var b=this._sources;if(!a.prototype.error.call(this,d))return!1;for(var m=0;m<b.length;m++)try{b[m].error(d)}catch{}return!0},h.prototype.lock=function(){a.prototype.lock.call(this);for(var d=this._sources,b=0;b<d.length;b++)d[b].lock()},i.exports=h},{"../crc32":4,"../signature":23,"../stream/GenericWorker":28,"../utf8":31,"../utils":32}],9:[function(o,i,n){var s=o("../compressions"),l=o("./ZipFileWorker");n.generateWorker=function(r,a,c){var u=new l(a.streamFiles,c,a.platform,a.encodeFileName),f=0;try{r.forEach(function(h,d){f++;var b=(function(x,k){var I=x||k,T=s[I];if(!T)throw new Error(I+" is not a valid compression method !");return T})(d.options.compression,a.compression),m=d.options.compressionOptions||a.compressionOptions||{},y=d.dir,g=d.date;d._compressWorker(b,m).withStreamInfo("file",{name:h,dir:y,date:g,comment:d.comment||"",unixPermissions:d.unixPermissions,dosPermissions:d.dosPermissions}).pipe(u)}),u.entriesCount=f}catch(h){u.error(h)}return u}},{"../compressions":3,"./ZipFileWorker":8}],10:[function(o,i,n){function s(){if(!(this instanceof s))return new s;if(arguments.length)throw new Error("The constructor with parameters has been removed in JSZip 3.0, please check the upgrade guide.");this.files=Object.create(null),this.comment=null,this.root="",this.clone=function(){var l=new s;for(var r in this)typeof this[r]!="function"&&(l[r]=this[r]);return l}}(s.prototype=o("./object")).loadAsync=o("./load"),s.support=o("./support"),s.defaults=o("./defaults"),s.version="3.10.1",s.loadAsync=function(l,r){return new s().loadAsync(l,r)},s.external=o("./external"),i.exports=s},{"./defaults":5,"./external":6,"./load":11,"./object":15,"./support":30}],11:[function(o,i,n){var s=o("./utils"),l=o("./external"),r=o("./utf8"),a=o("./zipEntries"),c=o("./stream/Crc32Probe"),u=o("./nodejsUtils");function f(h){return new l.Promise(function(d,b){var m=h.decompressed.getContentWorker().pipe(new c);m.on("error",function(y){b(y)}).on("end",function(){m.streamInfo.crc32!==h.decompressed.crc32?b(new Error("Corrupted zip : CRC32 mismatch")):d()}).resume()})}i.exports=function(h,d){var b=this;return d=s.extend(d||{},{base64:!1,checkCRC32:!1,optimizedBinaryString:!1,createFolders:!1,decodeFileName:r.utf8decode}),u.isNode&&u.isStream(h)?l.Promise.reject(new Error("JSZip can't accept a stream when loading a zip file.")):s.prepareContent("the loaded zip file",h,!0,d.optimizedBinaryString,d.base64).then(function(m){var y=new a(d);return y.load(m),y}).then(function(m){var y=[l.Promise.resolve(m)],g=m.files;if(d.checkCRC32)for(var x=0;x<g.length;x++)y.push(f(g[x]));return l.Promise.all(y)}).then(function(m){for(var y=m.shift(),g=y.files,x=0;x<g.length;x++){var k=g[x],I=k.fileNameStr,T=s.resolve(k.fileNameStr);b.file(T,k.decompressed,{binary:!0,optimizedBinaryString:!0,date:k.date,dir:k.dir,comment:k.fileCommentStr.length?k.fileCommentStr:null,unixPermissions:k.unixPermissions,dosPermissions:k.dosPermissions,createFolders:d.createFolders}),k.dir||(b.file(T).unsafeOriginalName=I)}return y.zipComment.length&&(b.comment=y.zipComment),b})}},{"./external":6,"./nodejsUtils":14,"./stream/Crc32Probe":25,"./utf8":31,"./utils":32,"./zipEntries":33}],12:[function(o,i,n){var s=o("../utils"),l=o("../stream/GenericWorker");function r(a,c){l.call(this,"Nodejs stream input adapter for "+a),this._upstreamEnded=!1,this._bindStream(c)}s.inherits(r,l),r.prototype._bindStream=function(a){var c=this;(this._stream=a).pause(),a.on("data",function(u){c.push({data:u,meta:{percent:0}})}).on("error",function(u){c.isPaused?this.generatedError=u:c.error(u)}).on("end",function(){c.isPaused?c._upstreamEnded=!0:c.end()})},r.prototype.pause=function(){return!!l.prototype.pause.call(this)&&(this._stream.pause(),!0)},r.prototype.resume=function(){return!!l.prototype.resume.call(this)&&(this._upstreamEnded?this.end():this._stream.resume(),!0)},i.exports=r},{"../stream/GenericWorker":28,"../utils":32}],13:[function(o,i,n){var s=o("readable-stream").Readable;function l(r,a,c){s.call(this,a),this._helper=r;var u=this;r.on("data",function(f,h){u.push(f)||u._helper.pause(),c&&c(h)}).on("error",function(f){u.emit("error",f)}).on("end",function(){u.push(null)})}o("../utils").inherits(l,s),l.prototype._read=function(){this._helper.resume()},i.exports=l},{"../utils":32,"readable-stream":16}],14:[function(o,i,n){i.exports={isNode:typeof Buffer<"u",newBufferFrom:function(s,l){if(Buffer.from&&Buffer.from!==Uint8Array.from)return Buffer.from(s,l);if(typeof s=="number")throw new Error('The "data" argument must not be a number');return new Buffer(s,l)},allocBuffer:function(s){if(Buffer.alloc)return Buffer.alloc(s);var l=new Buffer(s);return l.fill(0),l},isBuffer:function(s){return Buffer.isBuffer(s)},isStream:function(s){return s&&typeof s.on=="function"&&typeof s.pause=="function"&&typeof s.resume=="function"}}},{}],15:[function(o,i,n){function s(T,w,C){var L,R=r.getTypeOf(w),N=r.extend(C||{},u);N.date=N.date||new Date,N.compression!==null&&(N.compression=N.compression.toUpperCase()),typeof N.unixPermissions=="string"&&(N.unixPermissions=parseInt(N.unixPermissions,8)),N.unixPermissions&&16384&N.unixPermissions&&(N.dir=!0),N.dosPermissions&&16&N.dosPermissions&&(N.dir=!0),N.dir&&(T=g(T)),N.createFolders&&(L=y(T))&&x.call(this,L,!0);var F=R==="string"&&N.binary===!1&&N.base64===!1;C&&C.binary!==void 0||(N.binary=!F),(w instanceof f&&w.uncompressedSize===0||N.dir||!w||w.length===0)&&(N.base64=!1,N.binary=!0,w="",N.compression="STORE",R="string");var E=null;E=w instanceof f||w instanceof a?w:b.isNode&&b.isStream(w)?new m(T,w):r.prepareContent(T,w,N.binary,N.optimizedBinaryString,N.base64);var O=new h(T,E,N);this.files[T]=O}var l=o("./utf8"),r=o("./utils"),a=o("./stream/GenericWorker"),c=o("./stream/StreamHelper"),u=o("./defaults"),f=o("./compressedObject"),h=o("./zipObject"),d=o("./generate"),b=o("./nodejsUtils"),m=o("./nodejs/NodejsStreamInputAdapter"),y=function(T){T.slice(-1)==="/"&&(T=T.substring(0,T.length-1));var w=T.lastIndexOf("/");return 0<w?T.substring(0,w):""},g=function(T){return T.slice(-1)!=="/"&&(T+="/"),T},x=function(T,w){return w=w!==void 0?w:u.createFolders,T=g(T),this.files[T]||s.call(this,T,null,{dir:!0,createFolders:w}),this.files[T]};function k(T){return Object.prototype.toString.call(T)==="[object RegExp]"}var I={load:function(){throw new Error("This method has been removed in JSZip 3.0, please check the upgrade guide.")},forEach:function(T){var w,C,L;for(w in this.files)L=this.files[w],(C=w.slice(this.root.length,w.length))&&w.slice(0,this.root.length)===this.root&&T(C,L)},filter:function(T){var w=[];return this.forEach(function(C,L){T(C,L)&&w.push(L)}),w},file:function(T,w,C){if(arguments.length!==1)return T=this.root+T,s.call(this,T,w,C),this;if(k(T)){var L=T;return this.filter(function(N,F){return!F.dir&&L.test(N)})}var R=this.files[this.root+T];return R&&!R.dir?R:null},folder:function(T){if(!T)return this;if(k(T))return this.filter(function(R,N){return N.dir&&T.test(R)});var w=this.root+T,C=x.call(this,w),L=this.clone();return L.root=C.name,L},remove:function(T){T=this.root+T;var w=this.files[T];if(w||(T.slice(-1)!=="/"&&(T+="/"),w=this.files[T]),w&&!w.dir)delete this.files[T];else for(var C=this.filter(function(R,N){return N.name.slice(0,T.length)===T}),L=0;L<C.length;L++)delete this.files[C[L].name];return this},generate:function(){throw new Error("This method has been removed in JSZip 3.0, please check the upgrade guide.")},generateInternalStream:function(T){var w,C={};try{if((C=r.extend(T||{},{streamFiles:!1,compression:"STORE",compressionOptions:null,type:"",platform:"DOS",comment:null,mimeType:"application/zip",encodeFileName:l.utf8encode})).type=C.type.toLowerCase(),C.compression=C.compression.toUpperCase(),C.type==="binarystring"&&(C.type="string"),!C.type)throw new Error("No output type specified.");r.checkSupport(C.type),C.platform!=="darwin"&&C.platform!=="freebsd"&&C.platform!=="linux"&&C.platform!=="sunos"||(C.platform="UNIX"),C.platform==="win32"&&(C.platform="DOS");var L=C.comment||this.comment||"";w=d.generateWorker(this,C,L)}catch(R){(w=new a("error")).error(R)}return new c(w,C.type||"string",C.mimeType)},generateAsync:function(T,w){return this.generateInternalStream(T).accumulate(w)},generateNodeStream:function(T,w){return(T=T||{}).type||(T.type="nodebuffer"),this.generateInternalStream(T).toNodejsStream(w)}};i.exports=I},{"./compressedObject":2,"./defaults":5,"./generate":9,"./nodejs/NodejsStreamInputAdapter":12,"./nodejsUtils":14,"./stream/GenericWorker":28,"./stream/StreamHelper":29,"./utf8":31,"./utils":32,"./zipObject":35}],16:[function(o,i,n){i.exports=o("stream")},{stream:void 0}],17:[function(o,i,n){var s=o("./DataReader");function l(r){s.call(this,r);for(var a=0;a<this.data.length;a++)r[a]=255&r[a]}o("../utils").inherits(l,s),l.prototype.byteAt=function(r){return this.data[this.zero+r]},l.prototype.lastIndexOfSignature=function(r){for(var a=r.charCodeAt(0),c=r.charCodeAt(1),u=r.charCodeAt(2),f=r.charCodeAt(3),h=this.length-4;0<=h;--h)if(this.data[h]===a&&this.data[h+1]===c&&this.data[h+2]===u&&this.data[h+3]===f)return h-this.zero;return-1},l.prototype.readAndCheckSignature=function(r){var a=r.charCodeAt(0),c=r.charCodeAt(1),u=r.charCodeAt(2),f=r.charCodeAt(3),h=this.readData(4);return a===h[0]&&c===h[1]&&u===h[2]&&f===h[3]},l.prototype.readData=function(r){if(this.checkOffset(r),r===0)return[];var a=this.data.slice(this.zero+this.index,this.zero+this.index+r);return this.index+=r,a},i.exports=l},{"../utils":32,"./DataReader":18}],18:[function(o,i,n){var s=o("../utils");function l(r){this.data=r,this.length=r.length,this.index=0,this.zero=0}l.prototype={checkOffset:function(r){this.checkIndex(this.index+r)},checkIndex:function(r){if(this.length<this.zero+r||r<0)throw new Error("End of data reached (data length = "+this.length+", asked index = "+r+"). Corrupted zip ?")},setIndex:function(r){this.checkIndex(r),this.index=r},skip:function(r){this.setIndex(this.index+r)},byteAt:function(){},readInt:function(r){var a,c=0;for(this.checkOffset(r),a=this.index+r-1;a>=this.index;a--)c=(c<<8)+this.byteAt(a);return this.index+=r,c},readString:function(r){return s.transformTo("string",this.readData(r))},readData:function(){},lastIndexOfSignature:function(){},readAndCheckSignature:function(){},readDate:function(){var r=this.readInt(4);return new Date(Date.UTC(1980+(r>>25&127),(r>>21&15)-1,r>>16&31,r>>11&31,r>>5&63,(31&r)<<1))}},i.exports=l},{"../utils":32}],19:[function(o,i,n){var s=o("./Uint8ArrayReader");function l(r){s.call(this,r)}o("../utils").inherits(l,s),l.prototype.readData=function(r){this.checkOffset(r);var a=this.data.slice(this.zero+this.index,this.zero+this.index+r);return this.index+=r,a},i.exports=l},{"../utils":32,"./Uint8ArrayReader":21}],20:[function(o,i,n){var s=o("./DataReader");function l(r){s.call(this,r)}o("../utils").inherits(l,s),l.prototype.byteAt=function(r){return this.data.charCodeAt(this.zero+r)},l.prototype.lastIndexOfSignature=function(r){return this.data.lastIndexOf(r)-this.zero},l.prototype.readAndCheckSignature=function(r){return r===this.readData(4)},l.prototype.readData=function(r){this.checkOffset(r);var a=this.data.slice(this.zero+this.index,this.zero+this.index+r);return this.index+=r,a},i.exports=l},{"../utils":32,"./DataReader":18}],21:[function(o,i,n){var s=o("./ArrayReader");function l(r){s.call(this,r)}o("../utils").inherits(l,s),l.prototype.readData=function(r){if(this.checkOffset(r),r===0)return new Uint8Array(0);var a=this.data.subarray(this.zero+this.index,this.zero+this.index+r);return this.index+=r,a},i.exports=l},{"../utils":32,"./ArrayReader":17}],22:[function(o,i,n){var s=o("../utils"),l=o("../support"),r=o("./ArrayReader"),a=o("./StringReader"),c=o("./NodeBufferReader"),u=o("./Uint8ArrayReader");i.exports=function(f){var h=s.getTypeOf(f);return s.checkSupport(h),h!=="string"||l.uint8array?h==="nodebuffer"?new c(f):l.uint8array?new u(s.transformTo("uint8array",f)):new r(s.transformTo("array",f)):new a(f)}},{"../support":30,"../utils":32,"./ArrayReader":17,"./NodeBufferReader":19,"./StringReader":20,"./Uint8ArrayReader":21}],23:[function(o,i,n){n.LOCAL_FILE_HEADER="PK",n.CENTRAL_FILE_HEADER="PK",n.CENTRAL_DIRECTORY_END="PK",n.ZIP64_CENTRAL_DIRECTORY_LOCATOR="PK\x07",n.ZIP64_CENTRAL_DIRECTORY_END="PK",n.DATA_DESCRIPTOR="PK\x07\b"},{}],24:[function(o,i,n){var s=o("./GenericWorker"),l=o("../utils");function r(a){s.call(this,"ConvertWorker to "+a),this.destType=a}l.inherits(r,s),r.prototype.processChunk=function(a){this.push({data:l.transformTo(this.destType,a.data),meta:a.meta})},i.exports=r},{"../utils":32,"./GenericWorker":28}],25:[function(o,i,n){var s=o("./GenericWorker"),l=o("../crc32");function r(){s.call(this,"Crc32Probe"),this.withStreamInfo("crc32",0)}o("../utils").inherits(r,s),r.prototype.processChunk=function(a){this.streamInfo.crc32=l(a.data,this.streamInfo.crc32||0),this.push(a)},i.exports=r},{"../crc32":4,"../utils":32,"./GenericWorker":28}],26:[function(o,i,n){var s=o("../utils"),l=o("./GenericWorker");function r(a){l.call(this,"DataLengthProbe for "+a),this.propName=a,this.withStreamInfo(a,0)}s.inherits(r,l),r.prototype.processChunk=function(a){if(a){var c=this.streamInfo[this.propName]||0;this.streamInfo[this.propName]=c+a.data.length}l.prototype.processChunk.call(this,a)},i.exports=r},{"../utils":32,"./GenericWorker":28}],27:[function(o,i,n){var s=o("../utils"),l=o("./GenericWorker");function r(a){l.call(this,"DataWorker");var c=this;this.dataIsReady=!1,this.index=0,this.max=0,this.data=null,this.type="",this._tickScheduled=!1,a.then(function(u){c.dataIsReady=!0,c.data=u,c.max=u&&u.length||0,c.type=s.getTypeOf(u),c.isPaused||c._tickAndRepeat()},function(u){c.error(u)})}s.inherits(r,l),r.prototype.cleanUp=function(){l.prototype.cleanUp.call(this),this.data=null},r.prototype.resume=function(){return!!l.prototype.resume.call(this)&&(!this._tickScheduled&&this.dataIsReady&&(this._tickScheduled=!0,s.delay(this._tickAndRepeat,[],this)),!0)},r.prototype._tickAndRepeat=function(){this._tickScheduled=!1,this.isPaused||this.isFinished||(this._tick(),this.isFinished||(s.delay(this._tickAndRepeat,[],this),this._tickScheduled=!0))},r.prototype._tick=function(){if(this.isPaused||this.isFinished)return!1;var a=null,c=Math.min(this.max,this.index+16384);if(this.index>=this.max)return this.end();switch(this.type){case"string":a=this.data.substring(this.index,c);break;case"uint8array":a=this.data.subarray(this.index,c);break;case"array":case"nodebuffer":a=this.data.slice(this.index,c)}return this.index=c,this.push({data:a,meta:{percent:this.max?this.index/this.max*100:0}})},i.exports=r},{"../utils":32,"./GenericWorker":28}],28:[function(o,i,n){function s(l){this.name=l||"default",this.streamInfo={},this.generatedError=null,this.extraStreamInfo={},this.isPaused=!0,this.isFinished=!1,this.isLocked=!1,this._listeners={data:[],end:[],error:[]},this.previous=null}s.prototype={push:function(l){this.emit("data",l)},end:function(){if(this.isFinished)return!1;this.flush();try{this.emit("end"),this.cleanUp(),this.isFinished=!0}catch(l){this.emit("error",l)}return!0},error:function(l){return!this.isFinished&&(this.isPaused?this.generatedError=l:(this.isFinished=!0,this.emit("error",l),this.previous&&this.previous.error(l),this.cleanUp()),!0)},on:function(l,r){return this._listeners[l].push(r),this},cleanUp:function(){this.streamInfo=this.generatedError=this.extraStreamInfo=null,this._listeners=[]},emit:function(l,r){if(this._listeners[l])for(var a=0;a<this._listeners[l].length;a++)this._listeners[l][a].call(this,r)},pipe:function(l){return l.registerPrevious(this)},registerPrevious:function(l){if(this.isLocked)throw new Error("The stream '"+this+"' has already been used.");this.streamInfo=l.streamInfo,this.mergeStreamInfo(),this.previous=l;var r=this;return l.on("data",function(a){r.processChunk(a)}),l.on("end",function(){r.end()}),l.on("error",function(a){r.error(a)}),this},pause:function(){return!this.isPaused&&!this.isFinished&&(this.isPaused=!0,this.previous&&this.previous.pause(),!0)},resume:function(){if(!this.isPaused||this.isFinished)return!1;var l=this.isPaused=!1;return this.generatedError&&(this.error(this.generatedError),l=!0),this.previous&&this.previous.resume(),!l},flush:function(){},processChunk:function(l){this.push(l)},withStreamInfo:function(l,r){return this.extraStreamInfo[l]=r,this.mergeStreamInfo(),this},mergeStreamInfo:function(){for(var l in this.extraStreamInfo)Object.prototype.hasOwnProperty.call(this.extraStreamInfo,l)&&(this.streamInfo[l]=this.extraStreamInfo[l])},lock:function(){if(this.isLocked)throw new Error("The stream '"+this+"' has already been used.");this.isLocked=!0,this.previous&&this.previous.lock()},toString:function(){var l="Worker "+this.name;return this.previous?this.previous+" -> "+l:l}},i.exports=s},{}],29:[function(o,i,n){var s=o("../utils"),l=o("./ConvertWorker"),r=o("./GenericWorker"),a=o("../base64"),c=o("../support"),u=o("../external"),f=null;if(c.nodestream)try{f=o("../nodejs/NodejsStreamOutputAdapter")}catch{}function h(b,m){return new u.Promise(function(y,g){var x=[],k=b._internalType,I=b._outputType,T=b._mimeType;b.on("data",function(w,C){x.push(w),m&&m(C)}).on("error",function(w){x=[],g(w)}).on("end",function(){try{var w=(function(C,L,R){switch(C){case"blob":return s.newBlob(s.transformTo("arraybuffer",L),R);case"base64":return a.encode(L);default:return s.transformTo(C,L)}})(I,(function(C,L){var R,N=0,F=null,E=0;for(R=0;R<L.length;R++)E+=L[R].length;switch(C){case"string":return L.join("");case"array":return Array.prototype.concat.apply([],L);case"uint8array":for(F=new Uint8Array(E),R=0;R<L.length;R++)F.set(L[R],N),N+=L[R].length;return F;case"nodebuffer":return Buffer.concat(L);default:throw new Error("concat : unsupported type '"+C+"'")}})(k,x),T);y(w)}catch(C){g(C)}x=[]}).resume()})}function d(b,m,y){var g=m;switch(m){case"blob":case"arraybuffer":g="uint8array";break;case"base64":g="string"}try{this._internalType=g,this._outputType=m,this._mimeType=y,s.checkSupport(g),this._worker=b.pipe(new l(g)),b.lock()}catch(x){this._worker=new r("error"),this._worker.error(x)}}d.prototype={accumulate:function(b){return h(this,b)},on:function(b,m){var y=this;return b==="data"?this._worker.on(b,function(g){m.call(y,g.data,g.meta)}):this._worker.on(b,function(){s.delay(m,arguments,y)}),this},resume:function(){return s.delay(this._worker.resume,[],this._worker),this},pause:function(){return this._worker.pause(),this},toNodejsStream:function(b){if(s.checkSupport("nodestream"),this._outputType!=="nodebuffer")throw new Error(this._outputType+" is not supported by this method");return new f(this,{objectMode:this._outputType!=="nodebuffer"},b)}},i.exports=d},{"../base64":1,"../external":6,"../nodejs/NodejsStreamOutputAdapter":13,"../support":30,"../utils":32,"./ConvertWorker":24,"./GenericWorker":28}],30:[function(o,i,n){if(n.base64=!0,n.array=!0,n.string=!0,n.arraybuffer=typeof ArrayBuffer<"u"&&typeof Uint8Array<"u",n.nodebuffer=typeof Buffer<"u",n.uint8array=typeof Uint8Array<"u",typeof ArrayBuffer>"u")n.blob=!1;else{var s=new ArrayBuffer(0);try{n.blob=new Blob([s],{type:"application/zip"}).size===0}catch{try{var l=new(self.BlobBuilder||self.WebKitBlobBuilder||self.MozBlobBuilder||self.MSBlobBuilder);l.append(s),n.blob=l.getBlob("application/zip").size===0}catch{n.blob=!1}}}try{n.nodestream=!!o("readable-stream").Readable}catch{n.nodestream=!1}},{"readable-stream":16}],31:[function(o,i,n){for(var s=o("./utils"),l=o("./support"),r=o("./nodejsUtils"),a=o("./stream/GenericWorker"),c=new Array(256),u=0;u<256;u++)c[u]=252<=u?6:248<=u?5:240<=u?4:224<=u?3:192<=u?2:1;c[254]=c[254]=1;function f(){a.call(this,"utf-8 decode"),this.leftOver=null}function h(){a.call(this,"utf-8 encode")}n.utf8encode=function(d){return l.nodebuffer?r.newBufferFrom(d,"utf-8"):(function(b){var m,y,g,x,k,I=b.length,T=0;for(x=0;x<I;x++)(64512&(y=b.charCodeAt(x)))==55296&&x+1<I&&(64512&(g=b.charCodeAt(x+1)))==56320&&(y=65536+(y-55296<<10)+(g-56320),x++),T+=y<128?1:y<2048?2:y<65536?3:4;for(m=l.uint8array?new Uint8Array(T):new Array(T),x=k=0;k<T;x++)(64512&(y=b.charCodeAt(x)))==55296&&x+1<I&&(64512&(g=b.charCodeAt(x+1)))==56320&&(y=65536+(y-55296<<10)+(g-56320),x++),y<128?m[k++]=y:(y<2048?m[k++]=192|y>>>6:(y<65536?m[k++]=224|y>>>12:(m[k++]=240|y>>>18,m[k++]=128|y>>>12&63),m[k++]=128|y>>>6&63),m[k++]=128|63&y);return m})(d)},n.utf8decode=function(d){return l.nodebuffer?s.transformTo("nodebuffer",d).toString("utf-8"):(function(b){var m,y,g,x,k=b.length,I=new Array(2*k);for(m=y=0;m<k;)if((g=b[m++])<128)I[y++]=g;else if(4<(x=c[g]))I[y++]=65533,m+=x-1;else{for(g&=x===2?31:x===3?15:7;1<x&&m<k;)g=g<<6|63&b[m++],x--;1<x?I[y++]=65533:g<65536?I[y++]=g:(g-=65536,I[y++]=55296|g>>10&1023,I[y++]=56320|1023&g)}return I.length!==y&&(I.subarray?I=I.subarray(0,y):I.length=y),s.applyFromCharCode(I)})(d=s.transformTo(l.uint8array?"uint8array":"array",d))},s.inherits(f,a),f.prototype.processChunk=function(d){var b=s.transformTo(l.uint8array?"uint8array":"array",d.data);if(this.leftOver&&this.leftOver.length){if(l.uint8array){var m=b;(b=new Uint8Array(m.length+this.leftOver.length)).set(this.leftOver,0),b.set(m,this.leftOver.length)}else b=this.leftOver.concat(b);this.leftOver=null}var y=(function(x,k){var I;for((k=k||x.length)>x.length&&(k=x.length),I=k-1;0<=I&&(192&x[I])==128;)I--;return I<0||I===0?k:I+c[x[I]]>k?I:k})(b),g=b;y!==b.length&&(l.uint8array?(g=b.subarray(0,y),this.leftOver=b.subarray(y,b.length)):(g=b.slice(0,y),this.leftOver=b.slice(y,b.length))),this.push({data:n.utf8decode(g),meta:d.meta})},f.prototype.flush=function(){this.leftOver&&this.leftOver.length&&(this.push({data:n.utf8decode(this.leftOver),meta:{}}),this.leftOver=null)},n.Utf8DecodeWorker=f,s.inherits(h,a),h.prototype.processChunk=function(d){this.push({data:n.utf8encode(d.data),meta:d.meta})},n.Utf8EncodeWorker=h},{"./nodejsUtils":14,"./stream/GenericWorker":28,"./support":30,"./utils":32}],32:[function(o,i,n){var s=o("./support"),l=o("./base64"),r=o("./nodejsUtils"),a=o("./external");function c(m){return m}function u(m,y){for(var g=0;g<m.length;++g)y[g]=255&m.charCodeAt(g);return y}o("setimmediate"),n.newBlob=function(m,y){n.checkSupport("blob");try{return new Blob([m],{type:y})}catch{try{var g=new(self.BlobBuilder||self.WebKitBlobBuilder||self.MozBlobBuilder||self.MSBlobBuilder);return g.append(m),g.getBlob(y)}catch{throw new Error("Bug : can't construct the Blob.")}}};var f={stringifyByChunk:function(m,y,g){var x=[],k=0,I=m.length;if(I<=g)return String.fromCharCode.apply(null,m);for(;k<I;)y==="array"||y==="nodebuffer"?x.push(String.fromCharCode.apply(null,m.slice(k,Math.min(k+g,I)))):x.push(String.fromCharCode.apply(null,m.subarray(k,Math.min(k+g,I)))),k+=g;return x.join("")},stringifyByChar:function(m){for(var y="",g=0;g<m.length;g++)y+=String.fromCharCode(m[g]);return y},applyCanBeUsed:{uint8array:(function(){try{return s.uint8array&&String.fromCharCode.apply(null,new Uint8Array(1)).length===1}catch{return!1}})(),nodebuffer:(function(){try{return s.nodebuffer&&String.fromCharCode.apply(null,r.allocBuffer(1)).length===1}catch{return!1}})()}};function h(m){var y=65536,g=n.getTypeOf(m),x=!0;if(g==="uint8array"?x=f.applyCanBeUsed.uint8array:g==="nodebuffer"&&(x=f.applyCanBeUsed.nodebuffer),x)for(;1<y;)try{return f.stringifyByChunk(m,g,y)}catch{y=Math.floor(y/2)}return f.stringifyByChar(m)}function d(m,y){for(var g=0;g<m.length;g++)y[g]=m[g];return y}n.applyFromCharCode=h;var b={};b.string={string:c,array:function(m){return u(m,new Array(m.length))},arraybuffer:function(m){return b.string.uint8array(m).buffer},uint8array:function(m){return u(m,new Uint8Array(m.length))},nodebuffer:function(m){return u(m,r.allocBuffer(m.length))}},b.array={string:h,array:c,arraybuffer:function(m){return new Uint8Array(m).buffer},uint8array:function(m){return new Uint8Array(m)},nodebuffer:function(m){return r.newBufferFrom(m)}},b.arraybuffer={string:function(m){return h(new Uint8Array(m))},array:function(m){return d(new Uint8Array(m),new Array(m.byteLength))},arraybuffer:c,uint8array:function(m){return new Uint8Array(m)},nodebuffer:function(m){return r.newBufferFrom(new Uint8Array(m))}},b.uint8array={string:h,array:function(m){return d(m,new Array(m.length))},arraybuffer:function(m){return m.buffer},uint8array:c,nodebuffer:function(m){return r.newBufferFrom(m)}},b.nodebuffer={string:h,array:function(m){return d(m,new Array(m.length))},arraybuffer:function(m){return b.nodebuffer.uint8array(m).buffer},uint8array:function(m){return d(m,new Uint8Array(m.length))},nodebuffer:c},n.transformTo=function(m,y){if(y=y||"",!m)return y;n.checkSupport(m);var g=n.getTypeOf(y);return b[g][m](y)},n.resolve=function(m){for(var y=m.split("/"),g=[],x=0;x<y.length;x++){var k=y[x];k==="."||k===""&&x!==0&&x!==y.length-1||(k===".."?g.pop():g.push(k))}return g.join("/")},n.getTypeOf=function(m){return typeof m=="string"?"string":Object.prototype.toString.call(m)==="[object Array]"?"array":s.nodebuffer&&r.isBuffer(m)?"nodebuffer":s.uint8array&&m instanceof Uint8Array?"uint8array":s.arraybuffer&&m instanceof ArrayBuffer?"arraybuffer":void 0},n.checkSupport=function(m){if(!s[m.toLowerCase()])throw new Error(m+" is not supported by this platform")},n.MAX_VALUE_16BITS=65535,n.MAX_VALUE_32BITS=-1,n.pretty=function(m){var y,g,x="";for(g=0;g<(m||"").length;g++)x+="\\x"+((y=m.charCodeAt(g))<16?"0":"")+y.toString(16).toUpperCase();return x},n.delay=function(m,y,g){setImmediate(function(){m.apply(g||null,y||[])})},n.inherits=function(m,y){function g(){}g.prototype=y.prototype,m.prototype=new g},n.extend=function(){var m,y,g={};for(m=0;m<arguments.length;m++)for(y in arguments[m])Object.prototype.hasOwnProperty.call(arguments[m],y)&&g[y]===void 0&&(g[y]=arguments[m][y]);return g},n.prepareContent=function(m,y,g,x,k){return a.Promise.resolve(y).then(function(I){return s.blob&&(I instanceof Blob||["[object File]","[object Blob]"].indexOf(Object.prototype.toString.call(I))!==-1)&&typeof FileReader<"u"?new a.Promise(function(T,w){var C=new FileReader;C.onload=function(L){T(L.target.result)},C.onerror=function(L){w(L.target.error)},C.readAsArrayBuffer(I)}):I}).then(function(I){var T=n.getTypeOf(I);return T?(T==="arraybuffer"?I=n.transformTo("uint8array",I):T==="string"&&(k?I=l.decode(I):g&&x!==!0&&(I=(function(w){return u(w,s.uint8array?new Uint8Array(w.length):new Array(w.length))})(I))),I):a.Promise.reject(new Error("Can't read the data of '"+m+"'. Is it in a supported JavaScript type (String, Blob, ArrayBuffer, etc) ?"))})}},{"./base64":1,"./external":6,"./nodejsUtils":14,"./support":30,setimmediate:54}],33:[function(o,i,n){var s=o("./reader/readerFor"),l=o("./utils"),r=o("./signature"),a=o("./zipEntry"),c=o("./support");function u(f){this.files=[],this.loadOptions=f}u.prototype={checkSignature:function(f){if(!this.reader.readAndCheckSignature(f)){this.reader.index-=4;var h=this.reader.readString(4);throw new Error("Corrupted zip or bug: unexpected signature ("+l.pretty(h)+", expected "+l.pretty(f)+")")}},isSignature:function(f,h){var d=this.reader.index;this.reader.setIndex(f);var b=this.reader.readString(4)===h;return this.reader.setIndex(d),b},readBlockEndOfCentral:function(){this.diskNumber=this.reader.readInt(2),this.diskWithCentralDirStart=this.reader.readInt(2),this.centralDirRecordsOnThisDisk=this.reader.readInt(2),this.centralDirRecords=this.reader.readInt(2),this.centralDirSize=this.reader.readInt(4),this.centralDirOffset=this.reader.readInt(4),this.zipCommentLength=this.reader.readInt(2);var f=this.reader.readData(this.zipCommentLength),h=c.uint8array?"uint8array":"array",d=l.transformTo(h,f);this.zipComment=this.loadOptions.decodeFileName(d)},readBlockZip64EndOfCentral:function(){this.zip64EndOfCentralSize=this.reader.readInt(8),this.reader.skip(4),this.diskNumber=this.reader.readInt(4),this.diskWithCentralDirStart=this.reader.readInt(4),this.centralDirRecordsOnThisDisk=this.reader.readInt(8),this.centralDirRecords=this.reader.readInt(8),this.centralDirSize=this.reader.readInt(8),this.centralDirOffset=this.reader.readInt(8),this.zip64ExtensibleData={};for(var f,h,d,b=this.zip64EndOfCentralSize-44;0<b;)f=this.reader.readInt(2),h=this.reader.readInt(4),d=this.reader.readData(h),this.zip64ExtensibleData[f]={id:f,length:h,value:d}},readBlockZip64EndOfCentralLocator:function(){if(this.diskWithZip64CentralDirStart=this.reader.readInt(4),this.relativeOffsetEndOfZip64CentralDir=this.reader.readInt(8),this.disksCount=this.reader.readInt(4),1<this.disksCount)throw new Error("Multi-volumes zip are not supported")},readLocalFiles:function(){var f,h;for(f=0;f<this.files.length;f++)h=this.files[f],this.reader.setIndex(h.localHeaderOffset),this.checkSignature(r.LOCAL_FILE_HEADER),h.readLocalPart(this.reader),h.handleUTF8(),h.processAttributes()},readCentralDir:function(){var f;for(this.reader.setIndex(this.centralDirOffset);this.reader.readAndCheckSignature(r.CENTRAL_FILE_HEADER);)(f=new a({zip64:this.zip64},this.loadOptions)).readCentralPart(this.reader),this.files.push(f);if(this.centralDirRecords!==this.files.length&&this.centralDirRecords!==0&&this.files.length===0)throw new Error("Corrupted zip or bug: expected "+this.centralDirRecords+" records in central dir, got "+this.files.length)},readEndOfCentral:function(){var f=this.reader.lastIndexOfSignature(r.CENTRAL_DIRECTORY_END);if(f<0)throw this.isSignature(0,r.LOCAL_FILE_HEADER)?new Error("Corrupted zip: can't find end of central directory"):new Error("Can't find end of central directory : is this a zip file ? If it is, see https://stuk.github.io/jszip/documentation/howto/read_zip.html");this.reader.setIndex(f);var h=f;if(this.checkSignature(r.CENTRAL_DIRECTORY_END),this.readBlockEndOfCentral(),this.diskNumber===l.MAX_VALUE_16BITS||this.diskWithCentralDirStart===l.MAX_VALUE_16BITS||this.centralDirRecordsOnThisDisk===l.MAX_VALUE_16BITS||this.centralDirRecords===l.MAX_VALUE_16BITS||this.centralDirSize===l.MAX_VALUE_32BITS||this.centralDirOffset===l.MAX_VALUE_32BITS){if(this.zip64=!0,(f=this.reader.lastIndexOfSignature(r.ZIP64_CENTRAL_DIRECTORY_LOCATOR))<0)throw new Error("Corrupted zip: can't find the ZIP64 end of central directory locator");if(this.reader.setIndex(f),this.checkSignature(r.ZIP64_CENTRAL_DIRECTORY_LOCATOR),this.readBlockZip64EndOfCentralLocator(),!this.isSignature(this.relativeOffsetEndOfZip64CentralDir,r.ZIP64_CENTRAL_DIRECTORY_END)&&(this.relativeOffsetEndOfZip64CentralDir=this.reader.lastIndexOfSignature(r.ZIP64_CENTRAL_DIRECTORY_END),this.relativeOffsetEndOfZip64CentralDir<0))throw new Error("Corrupted zip: can't find the ZIP64 end of central directory");this.reader.setIndex(this.relativeOffsetEndOfZip64CentralDir),this.checkSignature(r.ZIP64_CENTRAL_DIRECTORY_END),this.readBlockZip64EndOfCentral()}var d=this.centralDirOffset+this.centralDirSize;this.zip64&&(d+=20,d+=12+this.zip64EndOfCentralSize);var b=h-d;if(0<b)this.isSignature(h,r.CENTRAL_FILE_HEADER)||(this.reader.zero=b);else if(b<0)throw new Error("Corrupted zip: missing "+Math.abs(b)+" bytes.")},prepareReader:function(f){this.reader=s(f)},load:function(f){this.prepareReader(f),this.readEndOfCentral(),this.readCentralDir(),this.readLocalFiles()}},i.exports=u},{"./reader/readerFor":22,"./signature":23,"./support":30,"./utils":32,"./zipEntry":34}],34:[function(o,i,n){var s=o("./reader/readerFor"),l=o("./utils"),r=o("./compressedObject"),a=o("./crc32"),c=o("./utf8"),u=o("./compressions"),f=o("./support");function h(d,b){this.options=d,this.loadOptions=b}h.prototype={isEncrypted:function(){return(1&this.bitFlag)==1},useUTF8:function(){return(2048&this.bitFlag)==2048},readLocalPart:function(d){var b,m;if(d.skip(22),this.fileNameLength=d.readInt(2),m=d.readInt(2),this.fileName=d.readData(this.fileNameLength),d.skip(m),this.compressedSize===-1||this.uncompressedSize===-1)throw new Error("Bug or corrupted zip : didn't get enough information from the central directory (compressedSize === -1 || uncompressedSize === -1)");if((b=(function(y){for(var g in u)if(Object.prototype.hasOwnProperty.call(u,g)&&u[g].magic===y)return u[g];return null})(this.compressionMethod))===null)throw new Error("Corrupted zip : compression "+l.pretty(this.compressionMethod)+" unknown (inner file : "+l.transformTo("string",this.fileName)+")");this.decompressed=new r(this.compressedSize,this.uncompressedSize,this.crc32,b,d.readData(this.compressedSize))},readCentralPart:function(d){this.versionMadeBy=d.readInt(2),d.skip(2),this.bitFlag=d.readInt(2),this.compressionMethod=d.readString(2),this.date=d.readDate(),this.crc32=d.readInt(4),this.compressedSize=d.readInt(4),this.uncompressedSize=d.readInt(4);var b=d.readInt(2);if(this.extraFieldsLength=d.readInt(2),this.fileCommentLength=d.readInt(2),this.diskNumberStart=d.readInt(2),this.internalFileAttributes=d.readInt(2),this.externalFileAttributes=d.readInt(4),this.localHeaderOffset=d.readInt(4),this.isEncrypted())throw new Error("Encrypted zip are not supported");d.skip(b),this.readExtraFields(d),this.parseZIP64ExtraField(d),this.fileComment=d.readData(this.fileCommentLength)},processAttributes:function(){this.unixPermissions=null,this.dosPermissions=null;var d=this.versionMadeBy>>8;this.dir=!!(16&this.externalFileAttributes),d==0&&(this.dosPermissions=63&this.externalFileAttributes),d==3&&(this.unixPermissions=this.externalFileAttributes>>16&65535),this.dir||this.fileNameStr.slice(-1)!=="/"||(this.dir=!0)},parseZIP64ExtraField:function(){if(this.extraFields[1]){var d=s(this.extraFields[1].value);this.uncompressedSize===l.MAX_VALUE_32BITS&&(this.uncompressedSize=d.readInt(8)),this.compressedSize===l.MAX_VALUE_32BITS&&(this.compressedSize=d.readInt(8)),this.localHeaderOffset===l.MAX_VALUE_32BITS&&(this.localHeaderOffset=d.readInt(8)),this.diskNumberStart===l.MAX_VALUE_32BITS&&(this.diskNumberStart=d.readInt(4))}},readExtraFields:function(d){var b,m,y,g=d.index+this.extraFieldsLength;for(this.extraFields||(this.extraFields={});d.index+4<g;)b=d.readInt(2),m=d.readInt(2),y=d.readData(m),this.extraFields[b]={id:b,length:m,value:y};d.setIndex(g)},handleUTF8:function(){var d=f.uint8array?"uint8array":"array";if(this.useUTF8())this.fileNameStr=c.utf8decode(this.fileName),this.fileCommentStr=c.utf8decode(this.fileComment);else{var b=this.findExtraFieldUnicodePath();if(b!==null)this.fileNameStr=b;else{var m=l.transformTo(d,this.fileName);this.fileNameStr=this.loadOptions.decodeFileName(m)}var y=this.findExtraFieldUnicodeComment();if(y!==null)this.fileCommentStr=y;else{var g=l.transformTo(d,this.fileComment);this.fileCommentStr=this.loadOptions.decodeFileName(g)}}},findExtraFieldUnicodePath:function(){var d=this.extraFields[28789];if(d){var b=s(d.value);return b.readInt(1)!==1||a(this.fileName)!==b.readInt(4)?null:c.utf8decode(b.readData(d.length-5))}return null},findExtraFieldUnicodeComment:function(){var d=this.extraFields[25461];if(d){var b=s(d.value);return b.readInt(1)!==1||a(this.fileComment)!==b.readInt(4)?null:c.utf8decode(b.readData(d.length-5))}return null}},i.exports=h},{"./compressedObject":2,"./compressions":3,"./crc32":4,"./reader/readerFor":22,"./support":30,"./utf8":31,"./utils":32}],35:[function(o,i,n){function s(b,m,y){this.name=b,this.dir=y.dir,this.date=y.date,this.comment=y.comment,this.unixPermissions=y.unixPermissions,this.dosPermissions=y.dosPermissions,this._data=m,this._dataBinary=y.binary,this.options={compression:y.compression,compressionOptions:y.compressionOptions}}var l=o("./stream/StreamHelper"),r=o("./stream/DataWorker"),a=o("./utf8"),c=o("./compressedObject"),u=o("./stream/GenericWorker");s.prototype={internalStream:function(b){var m=null,y="string";try{if(!b)throw new Error("No output type specified.");var g=(y=b.toLowerCase())==="string"||y==="text";y!=="binarystring"&&y!=="text"||(y="string"),m=this._decompressWorker();var x=!this._dataBinary;x&&!g&&(m=m.pipe(new a.Utf8EncodeWorker)),!x&&g&&(m=m.pipe(new a.Utf8DecodeWorker))}catch(k){(m=new u("error")).error(k)}return new l(m,y,"")},async:function(b,m){return this.internalStream(b).accumulate(m)},nodeStream:function(b,m){return this.internalStream(b||"nodebuffer").toNodejsStream(m)},_compressWorker:function(b,m){if(this._data instanceof c&&this._data.compression.magic===b.magic)return this._data.getCompressedWorker();var y=this._decompressWorker();return this._dataBinary||(y=y.pipe(new a.Utf8EncodeWorker)),c.createWorkerFrom(y,b,m)},_decompressWorker:function(){return this._data instanceof c?this._data.getContentWorker():this._data instanceof u?this._data:new r(this._data)}};for(var f=["asText","asBinary","asNodeBuffer","asUint8Array","asArrayBuffer"],h=function(){throw new Error("This method has been removed in JSZip 3.0, please check the upgrade guide.")},d=0;d<f.length;d++)s.prototype[f[d]]=h;i.exports=s},{"./compressedObject":2,"./stream/DataWorker":27,"./stream/GenericWorker":28,"./stream/StreamHelper":29,"./utf8":31}],36:[function(o,i,n){(function(s){var l,r,a=s.MutationObserver||s.WebKitMutationObserver;if(a){var c=0,u=new a(b),f=s.document.createTextNode("");u.observe(f,{characterData:!0}),l=function(){f.data=c=++c%2}}else if(s.setImmediate||s.MessageChannel===void 0)l="document"in s&&"onreadystatechange"in s.document.createElement("script")?function(){var m=s.document.createElement("script");m.onreadystatechange=function(){b(),m.onreadystatechange=null,m.parentNode.removeChild(m),m=null},s.document.documentElement.appendChild(m)}:function(){setTimeout(b,0)};else{var h=new s.MessageChannel;h.port1.onmessage=b,l=function(){h.port2.postMessage(0)}}var d=[];function b(){var m,y;r=!0;for(var g=d.length;g;){for(y=d,d=[],m=-1;++m<g;)y[m]();g=d.length}r=!1}i.exports=function(m){d.push(m)!==1||r||l()}}).call(this,typeof gn<"u"?gn:typeof self<"u"?self:typeof window<"u"?window:{})},{}],37:[function(o,i,n){var s=o("immediate");function l(){}var r={},a=["REJECTED"],c=["FULFILLED"],u=["PENDING"];function f(g){if(typeof g!="function")throw new TypeError("resolver must be a function");this.state=u,this.queue=[],this.outcome=void 0,g!==l&&m(this,g)}function h(g,x,k){this.promise=g,typeof x=="function"&&(this.onFulfilled=x,this.callFulfilled=this.otherCallFulfilled),typeof k=="function"&&(this.onRejected=k,this.callRejected=this.otherCallRejected)}function d(g,x,k){s(function(){var I;try{I=x(k)}catch(T){return r.reject(g,T)}I===g?r.reject(g,new TypeError("Cannot resolve promise with itself")):r.resolve(g,I)})}function b(g){var x=g&&g.then;if(g&&(typeof g=="object"||typeof g=="function")&&typeof x=="function")return function(){x.apply(g,arguments)}}function m(g,x){var k=!1;function I(C){k||(k=!0,r.reject(g,C))}function T(C){k||(k=!0,r.resolve(g,C))}var w=y(function(){x(T,I)});w.status==="error"&&I(w.value)}function y(g,x){var k={};try{k.value=g(x),k.status="success"}catch(I){k.status="error",k.value=I}return k}(i.exports=f).prototype.finally=function(g){if(typeof g!="function")return this;var x=this.constructor;return this.then(function(k){return x.resolve(g()).then(function(){return k})},function(k){return x.resolve(g()).then(function(){throw k})})},f.prototype.catch=function(g){return this.then(null,g)},f.prototype.then=function(g,x){if(typeof g!="function"&&this.state===c||typeof x!="function"&&this.state===a)return this;var k=new this.constructor(l);return this.state!==u?d(k,this.state===c?g:x,this.outcome):this.queue.push(new h(k,g,x)),k},h.prototype.callFulfilled=function(g){r.resolve(this.promise,g)},h.prototype.otherCallFulfilled=function(g){d(this.promise,this.onFulfilled,g)},h.prototype.callRejected=function(g){r.reject(this.promise,g)},h.prototype.otherCallRejected=function(g){d(this.promise,this.onRejected,g)},r.resolve=function(g,x){var k=y(b,x);if(k.status==="error")return r.reject(g,k.value);var I=k.value;if(I)m(g,I);else{g.state=c,g.outcome=x;for(var T=-1,w=g.queue.length;++T<w;)g.queue[T].callFulfilled(x)}return g},r.reject=function(g,x){g.state=a,g.outcome=x;for(var k=-1,I=g.queue.length;++k<I;)g.queue[k].callRejected(x);return g},f.resolve=function(g){return g instanceof this?g:r.resolve(new this(l),g)},f.reject=function(g){var x=new this(l);return r.reject(x,g)},f.all=function(g){var x=this;if(Object.prototype.toString.call(g)!=="[object Array]")return this.reject(new TypeError("must be an array"));var k=g.length,I=!1;if(!k)return this.resolve([]);for(var T=new Array(k),w=0,C=-1,L=new this(l);++C<k;)R(g[C],C);return L;function R(N,F){x.resolve(N).then(function(E){T[F]=E,++w!==k||I||(I=!0,r.resolve(L,T))},function(E){I||(I=!0,r.reject(L,E))})}},f.race=function(g){var x=this;if(Object.prototype.toString.call(g)!=="[object Array]")return this.reject(new TypeError("must be an array"));var k=g.length,I=!1;if(!k)return this.resolve([]);for(var T=-1,w=new this(l);++T<k;)C=g[T],x.resolve(C).then(function(L){I||(I=!0,r.resolve(w,L))},function(L){I||(I=!0,r.reject(w,L))});var C;return w}},{immediate:36}],38:[function(o,i,n){var s={};(0,o("./lib/utils/common").assign)(s,o("./lib/deflate"),o("./lib/inflate"),o("./lib/zlib/constants")),i.exports=s},{"./lib/deflate":39,"./lib/inflate":40,"./lib/utils/common":41,"./lib/zlib/constants":44}],39:[function(o,i,n){var s=o("./zlib/deflate"),l=o("./utils/common"),r=o("./utils/strings"),a=o("./zlib/messages"),c=o("./zlib/zstream"),u=Object.prototype.toString,f=0,h=-1,d=0,b=8;function m(g){if(!(this instanceof m))return new m(g);this.options=l.assign({level:h,method:b,chunkSize:16384,windowBits:15,memLevel:8,strategy:d,to:""},g||{});var x=this.options;x.raw&&0<x.windowBits?x.windowBits=-x.windowBits:x.gzip&&0<x.windowBits&&x.windowBits<16&&(x.windowBits+=16),this.err=0,this.msg="",this.ended=!1,this.chunks=[],this.strm=new c,this.strm.avail_out=0;var k=s.deflateInit2(this.strm,x.level,x.method,x.windowBits,x.memLevel,x.strategy);if(k!==f)throw new Error(a[k]);if(x.header&&s.deflateSetHeader(this.strm,x.header),x.dictionary){var I;if(I=typeof x.dictionary=="string"?r.string2buf(x.dictionary):u.call(x.dictionary)==="[object ArrayBuffer]"?new Uint8Array(x.dictionary):x.dictionary,(k=s.deflateSetDictionary(this.strm,I))!==f)throw new Error(a[k]);this._dict_set=!0}}function y(g,x){var k=new m(x);if(k.push(g,!0),k.err)throw k.msg||a[k.err];return k.result}m.prototype.push=function(g,x){var k,I,T=this.strm,w=this.options.chunkSize;if(this.ended)return!1;I=x===~~x?x:x===!0?4:0,typeof g=="string"?T.input=r.string2buf(g):u.call(g)==="[object ArrayBuffer]"?T.input=new Uint8Array(g):T.input=g,T.next_in=0,T.avail_in=T.input.length;do{if(T.avail_out===0&&(T.output=new l.Buf8(w),T.next_out=0,T.avail_out=w),(k=s.deflate(T,I))!==1&&k!==f)return this.onEnd(k),!(this.ended=!0);T.avail_out!==0&&(T.avail_in!==0||I!==4&&I!==2)||(this.options.to==="string"?this.onData(r.buf2binstring(l.shrinkBuf(T.output,T.next_out))):this.onData(l.shrinkBuf(T.output,T.next_out)))}while((0<T.avail_in||T.avail_out===0)&&k!==1);return I===4?(k=s.deflateEnd(this.strm),this.onEnd(k),this.ended=!0,k===f):I!==2||(this.onEnd(f),!(T.avail_out=0))},m.prototype.onData=function(g){this.chunks.push(g)},m.prototype.onEnd=function(g){g===f&&(this.options.to==="string"?this.result=this.chunks.join(""):this.result=l.flattenChunks(this.chunks)),this.chunks=[],this.err=g,this.msg=this.strm.msg},n.Deflate=m,n.deflate=y,n.deflateRaw=function(g,x){return(x=x||{}).raw=!0,y(g,x)},n.gzip=function(g,x){return(x=x||{}).gzip=!0,y(g,x)}},{"./utils/common":41,"./utils/strings":42,"./zlib/deflate":46,"./zlib/messages":51,"./zlib/zstream":53}],40:[function(o,i,n){var s=o("./zlib/inflate"),l=o("./utils/common"),r=o("./utils/strings"),a=o("./zlib/constants"),c=o("./zlib/messages"),u=o("./zlib/zstream"),f=o("./zlib/gzheader"),h=Object.prototype.toString;function d(m){if(!(this instanceof d))return new d(m);this.options=l.assign({chunkSize:16384,windowBits:0,to:""},m||{});var y=this.options;y.raw&&0<=y.windowBits&&y.windowBits<16&&(y.windowBits=-y.windowBits,y.windowBits===0&&(y.windowBits=-15)),!(0<=y.windowBits&&y.windowBits<16)||m&&m.windowBits||(y.windowBits+=32),15<y.windowBits&&y.windowBits<48&&(15&y.windowBits)==0&&(y.windowBits|=15),this.err=0,this.msg="",this.ended=!1,this.chunks=[],this.strm=new u,this.strm.avail_out=0;var g=s.inflateInit2(this.strm,y.windowBits);if(g!==a.Z_OK)throw new Error(c[g]);this.header=new f,s.inflateGetHeader(this.strm,this.header)}function b(m,y){var g=new d(y);if(g.push(m,!0),g.err)throw g.msg||c[g.err];return g.result}d.prototype.push=function(m,y){var g,x,k,I,T,w,C=this.strm,L=this.options.chunkSize,R=this.options.dictionary,N=!1;if(this.ended)return!1;x=y===~~y?y:y===!0?a.Z_FINISH:a.Z_NO_FLUSH,typeof m=="string"?C.input=r.binstring2buf(m):h.call(m)==="[object ArrayBuffer]"?C.input=new Uint8Array(m):C.input=m,C.next_in=0,C.avail_in=C.input.length;do{if(C.avail_out===0&&(C.output=new l.Buf8(L),C.next_out=0,C.avail_out=L),(g=s.inflate(C,a.Z_NO_FLUSH))===a.Z_NEED_DICT&&R&&(w=typeof R=="string"?r.string2buf(R):h.call(R)==="[object ArrayBuffer]"?new Uint8Array(R):R,g=s.inflateSetDictionary(this.strm,w)),g===a.Z_BUF_ERROR&&N===!0&&(g=a.Z_OK,N=!1),g!==a.Z_STREAM_END&&g!==a.Z_OK)return this.onEnd(g),!(this.ended=!0);C.next_out&&(C.avail_out!==0&&g!==a.Z_STREAM_END&&(C.avail_in!==0||x!==a.Z_FINISH&&x!==a.Z_SYNC_FLUSH)||(this.options.to==="string"?(k=r.utf8border(C.output,C.next_out),I=C.next_out-k,T=r.buf2string(C.output,k),C.next_out=I,C.avail_out=L-I,I&&l.arraySet(C.output,C.output,k,I,0),this.onData(T)):this.onData(l.shrinkBuf(C.output,C.next_out)))),C.avail_in===0&&C.avail_out===0&&(N=!0)}while((0<C.avail_in||C.avail_out===0)&&g!==a.Z_STREAM_END);return g===a.Z_STREAM_END&&(x=a.Z_FINISH),x===a.Z_FINISH?(g=s.inflateEnd(this.strm),this.onEnd(g),this.ended=!0,g===a.Z_OK):x!==a.Z_SYNC_FLUSH||(this.onEnd(a.Z_OK),!(C.avail_out=0))},d.prototype.onData=function(m){this.chunks.push(m)},d.prototype.onEnd=function(m){m===a.Z_OK&&(this.options.to==="string"?this.result=this.chunks.join(""):this.result=l.flattenChunks(this.chunks)),this.chunks=[],this.err=m,this.msg=this.strm.msg},n.Inflate=d,n.inflate=b,n.inflateRaw=function(m,y){return(y=y||{}).raw=!0,b(m,y)},n.ungzip=b},{"./utils/common":41,"./utils/strings":42,"./zlib/constants":44,"./zlib/gzheader":47,"./zlib/inflate":49,"./zlib/messages":51,"./zlib/zstream":53}],41:[function(o,i,n){var s=typeof Uint8Array<"u"&&typeof Uint16Array<"u"&&typeof Int32Array<"u";n.assign=function(a){for(var c=Array.prototype.slice.call(arguments,1);c.length;){var u=c.shift();if(u){if(typeof u!="object")throw new TypeError(u+"must be non-object");for(var f in u)u.hasOwnProperty(f)&&(a[f]=u[f])}}return a},n.shrinkBuf=function(a,c){return a.length===c?a:a.subarray?a.subarray(0,c):(a.length=c,a)};var l={arraySet:function(a,c,u,f,h){if(c.subarray&&a.subarray)a.set(c.subarray(u,u+f),h);else for(var d=0;d<f;d++)a[h+d]=c[u+d]},flattenChunks:function(a){var c,u,f,h,d,b;for(c=f=0,u=a.length;c<u;c++)f+=a[c].length;for(b=new Uint8Array(f),c=h=0,u=a.length;c<u;c++)d=a[c],b.set(d,h),h+=d.length;return b}},r={arraySet:function(a,c,u,f,h){for(var d=0;d<f;d++)a[h+d]=c[u+d]},flattenChunks:function(a){return[].concat.apply([],a)}};n.setTyped=function(a){a?(n.Buf8=Uint8Array,n.Buf16=Uint16Array,n.Buf32=Int32Array,n.assign(n,l)):(n.Buf8=Array,n.Buf16=Array,n.Buf32=Array,n.assign(n,r))},n.setTyped(s)},{}],42:[function(o,i,n){var s=o("./common"),l=!0,r=!0;try{String.fromCharCode.apply(null,[0])}catch{l=!1}try{String.fromCharCode.apply(null,new Uint8Array(1))}catch{r=!1}for(var a=new s.Buf8(256),c=0;c<256;c++)a[c]=252<=c?6:248<=c?5:240<=c?4:224<=c?3:192<=c?2:1;function u(f,h){if(h<65537&&(f.subarray&&r||!f.subarray&&l))return String.fromCharCode.apply(null,s.shrinkBuf(f,h));for(var d="",b=0;b<h;b++)d+=String.fromCharCode(f[b]);return d}a[254]=a[254]=1,n.string2buf=function(f){var h,d,b,m,y,g=f.length,x=0;for(m=0;m<g;m++)(64512&(d=f.charCodeAt(m)))==55296&&m+1<g&&(64512&(b=f.charCodeAt(m+1)))==56320&&(d=65536+(d-55296<<10)+(b-56320),m++),x+=d<128?1:d<2048?2:d<65536?3:4;for(h=new s.Buf8(x),m=y=0;y<x;m++)(64512&(d=f.charCodeAt(m)))==55296&&m+1<g&&(64512&(b=f.charCodeAt(m+1)))==56320&&(d=65536+(d-55296<<10)+(b-56320),m++),d<128?h[y++]=d:(d<2048?h[y++]=192|d>>>6:(d<65536?h[y++]=224|d>>>12:(h[y++]=240|d>>>18,h[y++]=128|d>>>12&63),h[y++]=128|d>>>6&63),h[y++]=128|63&d);return h},n.buf2binstring=function(f){return u(f,f.length)},n.binstring2buf=function(f){for(var h=new s.Buf8(f.length),d=0,b=h.length;d<b;d++)h[d]=f.charCodeAt(d);return h},n.buf2string=function(f,h){var d,b,m,y,g=h||f.length,x=new Array(2*g);for(d=b=0;d<g;)if((m=f[d++])<128)x[b++]=m;else if(4<(y=a[m]))x[b++]=65533,d+=y-1;else{for(m&=y===2?31:y===3?15:7;1<y&&d<g;)m=m<<6|63&f[d++],y--;1<y?x[b++]=65533:m<65536?x[b++]=m:(m-=65536,x[b++]=55296|m>>10&1023,x[b++]=56320|1023&m)}return u(x,b)},n.utf8border=function(f,h){var d;for((h=h||f.length)>f.length&&(h=f.length),d=h-1;0<=d&&(192&f[d])==128;)d--;return d<0||d===0?h:d+a[f[d]]>h?d:h}},{"./common":41}],43:[function(o,i,n){i.exports=function(s,l,r,a){for(var c=65535&s|0,u=s>>>16&65535|0,f=0;r!==0;){for(r-=f=2e3<r?2e3:r;u=u+(c=c+l[a++]|0)|0,--f;);c%=65521,u%=65521}return c|u<<16|0}},{}],44:[function(o,i,n){i.exports={Z_NO_FLUSH:0,Z_PARTIAL_FLUSH:1,Z_SYNC_FLUSH:2,Z_FULL_FLUSH:3,Z_FINISH:4,Z_BLOCK:5,Z_TREES:6,Z_OK:0,Z_STREAM_END:1,Z_NEED_DICT:2,Z_ERRNO:-1,Z_STREAM_ERROR:-2,Z_DATA_ERROR:-3,Z_BUF_ERROR:-5,Z_NO_COMPRESSION:0,Z_BEST_SPEED:1,Z_BEST_COMPRESSION:9,Z_DEFAULT_COMPRESSION:-1,Z_FILTERED:1,Z_HUFFMAN_ONLY:2,Z_RLE:3,Z_FIXED:4,Z_DEFAULT_STRATEGY:0,Z_BINARY:0,Z_TEXT:1,Z_UNKNOWN:2,Z_DEFLATED:8}},{}],45:[function(o,i,n){var s=(function(){for(var l,r=[],a=0;a<256;a++){l=a;for(var c=0;c<8;c++)l=1&l?3988292384^l>>>1:l>>>1;r[a]=l}return r})();i.exports=function(l,r,a,c){var u=s,f=c+a;l^=-1;for(var h=c;h<f;h++)l=l>>>8^u[255&(l^r[h])];return-1^l}},{}],46:[function(o,i,n){var s,l=o("../utils/common"),r=o("./trees"),a=o("./adler32"),c=o("./crc32"),u=o("./messages"),f=0,h=4,d=0,b=-2,m=-1,y=4,g=2,x=8,k=9,I=286,T=30,w=19,C=2*I+1,L=15,R=3,N=258,F=N+R+1,E=42,O=113,S=1,W=2,j=3,_=4;function M(v,K){return v.msg=u[K],K}function B(v){return(v<<1)-(4<v?9:0)}function Q(v){for(var K=v.length;0<=--K;)v[K]=0}function q(v){var K=v.state,H=K.pending;H>v.avail_out&&(H=v.avail_out),H!==0&&(l.arraySet(v.output,K.pending_buf,K.pending_out,H,v.next_out),v.next_out+=H,K.pending_out+=H,v.total_out+=H,v.avail_out-=H,K.pending-=H,K.pending===0&&(K.pending_out=0))}function U(v,K){r._tr_flush_block(v,0<=v.block_start?v.block_start:-1,v.strstart-v.block_start,K),v.block_start=v.strstart,q(v.strm)}function ne(v,K){v.pending_buf[v.pending++]=K}function oe(v,K){v.pending_buf[v.pending++]=K>>>8&255,v.pending_buf[v.pending++]=255&K}function ae(v,K){var H,$,A=v.max_chain_length,P=v.strstart,Y=v.prev_length,G=v.nice_match,Z=v.strstart>v.w_size-F?v.strstart-(v.w_size-F):0,ee=v.window,ce=v.w_mask,re=v.prev,me=v.strstart+N,_e=ee[P+Y-1],we=ee[P+Y];v.prev_length>=v.good_match&&(A>>=2),G>v.lookahead&&(G=v.lookahead);do if(ee[(H=K)+Y]===we&&ee[H+Y-1]===_e&&ee[H]===ee[P]&&ee[++H]===ee[P+1]){P+=2,H++;do;while(ee[++P]===ee[++H]&&ee[++P]===ee[++H]&&ee[++P]===ee[++H]&&ee[++P]===ee[++H]&&ee[++P]===ee[++H]&&ee[++P]===ee[++H]&&ee[++P]===ee[++H]&&ee[++P]===ee[++H]&&P<me);if($=N-(me-P),P=me-N,Y<$){if(v.match_start=K,G<=(Y=$))break;_e=ee[P+Y-1],we=ee[P+Y]}}while((K=re[K&ce])>Z&&--A!=0);return Y<=v.lookahead?Y:v.lookahead}function Se(v){var K,H,$,A,P,Y,G,Z,ee,ce,re=v.w_size;do{if(A=v.window_size-v.lookahead-v.strstart,v.strstart>=re+(re-F)){for(l.arraySet(v.window,v.window,re,re,0),v.match_start-=re,v.strstart-=re,v.block_start-=re,K=H=v.hash_size;$=v.head[--K],v.head[K]=re<=$?$-re:0,--H;);for(K=H=re;$=v.prev[--K],v.prev[K]=re<=$?$-re:0,--H;);A+=re}if(v.strm.avail_in===0)break;if(Y=v.strm,G=v.window,Z=v.strstart+v.lookahead,ee=A,ce=void 0,ce=Y.avail_in,ee<ce&&(ce=ee),H=ce===0?0:(Y.avail_in-=ce,l.arraySet(G,Y.input,Y.next_in,ce,Z),Y.state.wrap===1?Y.adler=a(Y.adler,G,ce,Z):Y.state.wrap===2&&(Y.adler=c(Y.adler,G,ce,Z)),Y.next_in+=ce,Y.total_in+=ce,ce),v.lookahead+=H,v.lookahead+v.insert>=R)for(P=v.strstart-v.insert,v.ins_h=v.window[P],v.ins_h=(v.ins_h<<v.hash_shift^v.window[P+1])&v.hash_mask;v.insert&&(v.ins_h=(v.ins_h<<v.hash_shift^v.window[P+R-1])&v.hash_mask,v.prev[P&v.w_mask]=v.head[v.ins_h],v.head[v.ins_h]=P,P++,v.insert--,!(v.lookahead+v.insert<R)););}while(v.lookahead<F&&v.strm.avail_in!==0)}function $e(v,K){for(var H,$;;){if(v.lookahead<F){if(Se(v),v.lookahead<F&&K===f)return S;if(v.lookahead===0)break}if(H=0,v.lookahead>=R&&(v.ins_h=(v.ins_h<<v.hash_shift^v.window[v.strstart+R-1])&v.hash_mask,H=v.prev[v.strstart&v.w_mask]=v.head[v.ins_h],v.head[v.ins_h]=v.strstart),H!==0&&v.strstart-H<=v.w_size-F&&(v.match_length=ae(v,H)),v.match_length>=R)if($=r._tr_tally(v,v.strstart-v.match_start,v.match_length-R),v.lookahead-=v.match_length,v.match_length<=v.max_lazy_match&&v.lookahead>=R){for(v.match_length--;v.strstart++,v.ins_h=(v.ins_h<<v.hash_shift^v.window[v.strstart+R-1])&v.hash_mask,H=v.prev[v.strstart&v.w_mask]=v.head[v.ins_h],v.head[v.ins_h]=v.strstart,--v.match_length!=0;);v.strstart++}else v.strstart+=v.match_length,v.match_length=0,v.ins_h=v.window[v.strstart],v.ins_h=(v.ins_h<<v.hash_shift^v.window[v.strstart+1])&v.hash_mask;else $=r._tr_tally(v,0,v.window[v.strstart]),v.lookahead--,v.strstart++;if($&&(U(v,!1),v.strm.avail_out===0))return S}return v.insert=v.strstart<R-1?v.strstart:R-1,K===h?(U(v,!0),v.strm.avail_out===0?j:_):v.last_lit&&(U(v,!1),v.strm.avail_out===0)?S:W}function ke(v,K){for(var H,$,A;;){if(v.lookahead<F){if(Se(v),v.lookahead<F&&K===f)return S;if(v.lookahead===0)break}if(H=0,v.lookahead>=R&&(v.ins_h=(v.ins_h<<v.hash_shift^v.window[v.strstart+R-1])&v.hash_mask,H=v.prev[v.strstart&v.w_mask]=v.head[v.ins_h],v.head[v.ins_h]=v.strstart),v.prev_length=v.match_length,v.prev_match=v.match_start,v.match_length=R-1,H!==0&&v.prev_length<v.max_lazy_match&&v.strstart-H<=v.w_size-F&&(v.match_length=ae(v,H),v.match_length<=5&&(v.strategy===1||v.match_length===R&&4096<v.strstart-v.match_start)&&(v.match_length=R-1)),v.prev_length>=R&&v.match_length<=v.prev_length){for(A=v.strstart+v.lookahead-R,$=r._tr_tally(v,v.strstart-1-v.prev_match,v.prev_length-R),v.lookahead-=v.prev_length-1,v.prev_length-=2;++v.strstart<=A&&(v.ins_h=(v.ins_h<<v.hash_shift^v.window[v.strstart+R-1])&v.hash_mask,H=v.prev[v.strstart&v.w_mask]=v.head[v.ins_h],v.head[v.ins_h]=v.strstart),--v.prev_length!=0;);if(v.match_available=0,v.match_length=R-1,v.strstart++,$&&(U(v,!1),v.strm.avail_out===0))return S}else if(v.match_available){if(($=r._tr_tally(v,0,v.window[v.strstart-1]))&&U(v,!1),v.strstart++,v.lookahead--,v.strm.avail_out===0)return S}else v.match_available=1,v.strstart++,v.lookahead--}return v.match_available&&($=r._tr_tally(v,0,v.window[v.strstart-1]),v.match_available=0),v.insert=v.strstart<R-1?v.strstart:R-1,K===h?(U(v,!0),v.strm.avail_out===0?j:_):v.last_lit&&(U(v,!1),v.strm.avail_out===0)?S:W}function Ce(v,K,H,$,A){this.good_length=v,this.max_lazy=K,this.nice_length=H,this.max_chain=$,this.func=A}function z(){this.strm=null,this.status=0,this.pending_buf=null,this.pending_buf_size=0,this.pending_out=0,this.pending=0,this.wrap=0,this.gzhead=null,this.gzindex=0,this.method=x,this.last_flush=-1,this.w_size=0,this.w_bits=0,this.w_mask=0,this.window=null,this.window_size=0,this.prev=null,this.head=null,this.ins_h=0,this.hash_size=0,this.hash_bits=0,this.hash_mask=0,this.hash_shift=0,this.block_start=0,this.match_length=0,this.prev_match=0,this.match_available=0,this.strstart=0,this.match_start=0,this.lookahead=0,this.prev_length=0,this.max_chain_length=0,this.max_lazy_match=0,this.level=0,this.strategy=0,this.good_match=0,this.nice_match=0,this.dyn_ltree=new l.Buf16(2*C),this.dyn_dtree=new l.Buf16(2*(2*T+1)),this.bl_tree=new l.Buf16(2*(2*w+1)),Q(this.dyn_ltree),Q(this.dyn_dtree),Q(this.bl_tree),this.l_desc=null,this.d_desc=null,this.bl_desc=null,this.bl_count=new l.Buf16(L+1),this.heap=new l.Buf16(2*I+1),Q(this.heap),this.heap_len=0,this.heap_max=0,this.depth=new l.Buf16(2*I+1),Q(this.depth),this.l_buf=0,this.lit_bufsize=0,this.last_lit=0,this.d_buf=0,this.opt_len=0,this.static_len=0,this.matches=0,this.insert=0,this.bi_buf=0,this.bi_valid=0}function se(v){var K;return v&&v.state?(v.total_in=v.total_out=0,v.data_type=g,(K=v.state).pending=0,K.pending_out=0,K.wrap<0&&(K.wrap=-K.wrap),K.status=K.wrap?E:O,v.adler=K.wrap===2?0:1,K.last_flush=f,r._tr_init(K),d):M(v,b)}function D(v){var K=se(v);return K===d&&(function(H){H.window_size=2*H.w_size,Q(H.head),H.max_lazy_match=s[H.level].max_lazy,H.good_match=s[H.level].good_length,H.nice_match=s[H.level].nice_length,H.max_chain_length=s[H.level].max_chain,H.strstart=0,H.block_start=0,H.lookahead=0,H.insert=0,H.match_length=H.prev_length=R-1,H.match_available=0,H.ins_h=0})(v.state),K}function V(v,K,H,$,A,P){if(!v)return b;var Y=1;if(K===m&&(K=6),$<0?(Y=0,$=-$):15<$&&(Y=2,$-=16),A<1||k<A||H!==x||$<8||15<$||K<0||9<K||P<0||y<P)return M(v,b);$===8&&($=9);var G=new z;return(v.state=G).strm=v,G.wrap=Y,G.gzhead=null,G.w_bits=$,G.w_size=1<<G.w_bits,G.w_mask=G.w_size-1,G.hash_bits=A+7,G.hash_size=1<<G.hash_bits,G.hash_mask=G.hash_size-1,G.hash_shift=~~((G.hash_bits+R-1)/R),G.window=new l.Buf8(2*G.w_size),G.head=new l.Buf16(G.hash_size),G.prev=new l.Buf16(G.w_size),G.lit_bufsize=1<<A+6,G.pending_buf_size=4*G.lit_bufsize,G.pending_buf=new l.Buf8(G.pending_buf_size),G.d_buf=1*G.lit_bufsize,G.l_buf=3*G.lit_bufsize,G.level=K,G.strategy=P,G.method=H,D(v)}s=[new Ce(0,0,0,0,function(v,K){var H=65535;for(H>v.pending_buf_size-5&&(H=v.pending_buf_size-5);;){if(v.lookahead<=1){if(Se(v),v.lookahead===0&&K===f)return S;if(v.lookahead===0)break}v.strstart+=v.lookahead,v.lookahead=0;var $=v.block_start+H;if((v.strstart===0||v.strstart>=$)&&(v.lookahead=v.strstart-$,v.strstart=$,U(v,!1),v.strm.avail_out===0)||v.strstart-v.block_start>=v.w_size-F&&(U(v,!1),v.strm.avail_out===0))return S}return v.insert=0,K===h?(U(v,!0),v.strm.avail_out===0?j:_):(v.strstart>v.block_start&&(U(v,!1),v.strm.avail_out),S)}),new Ce(4,4,8,4,$e),new Ce(4,5,16,8,$e),new Ce(4,6,32,32,$e),new Ce(4,4,16,16,ke),new Ce(8,16,32,32,ke),new Ce(8,16,128,128,ke),new Ce(8,32,128,256,ke),new Ce(32,128,258,1024,ke),new Ce(32,258,258,4096,ke)],n.deflateInit=function(v,K){return V(v,K,x,15,8,0)},n.deflateInit2=V,n.deflateReset=D,n.deflateResetKeep=se,n.deflateSetHeader=function(v,K){return v&&v.state?v.state.wrap!==2?b:(v.state.gzhead=K,d):b},n.deflate=function(v,K){var H,$,A,P;if(!v||!v.state||5<K||K<0)return v?M(v,b):b;if($=v.state,!v.output||!v.input&&v.avail_in!==0||$.status===666&&K!==h)return M(v,v.avail_out===0?-5:b);if($.strm=v,H=$.last_flush,$.last_flush=K,$.status===E)if($.wrap===2)v.adler=0,ne($,31),ne($,139),ne($,8),$.gzhead?(ne($,($.gzhead.text?1:0)+($.gzhead.hcrc?2:0)+($.gzhead.extra?4:0)+($.gzhead.name?8:0)+($.gzhead.comment?16:0)),ne($,255&$.gzhead.time),ne($,$.gzhead.time>>8&255),ne($,$.gzhead.time>>16&255),ne($,$.gzhead.time>>24&255),ne($,$.level===9?2:2<=$.strategy||$.level<2?4:0),ne($,255&$.gzhead.os),$.gzhead.extra&&$.gzhead.extra.length&&(ne($,255&$.gzhead.extra.length),ne($,$.gzhead.extra.length>>8&255)),$.gzhead.hcrc&&(v.adler=c(v.adler,$.pending_buf,$.pending,0)),$.gzindex=0,$.status=69):(ne($,0),ne($,0),ne($,0),ne($,0),ne($,0),ne($,$.level===9?2:2<=$.strategy||$.level<2?4:0),ne($,3),$.status=O);else{var Y=x+($.w_bits-8<<4)<<8;Y|=(2<=$.strategy||$.level<2?0:$.level<6?1:$.level===6?2:3)<<6,$.strstart!==0&&(Y|=32),Y+=31-Y%31,$.status=O,oe($,Y),$.strstart!==0&&(oe($,v.adler>>>16),oe($,65535&v.adler)),v.adler=1}if($.status===69)if($.gzhead.extra){for(A=$.pending;$.gzindex<(65535&$.gzhead.extra.length)&&($.pending!==$.pending_buf_size||($.gzhead.hcrc&&$.pending>A&&(v.adler=c(v.adler,$.pending_buf,$.pending-A,A)),q(v),A=$.pending,$.pending!==$.pending_buf_size));)ne($,255&$.gzhead.extra[$.gzindex]),$.gzindex++;$.gzhead.hcrc&&$.pending>A&&(v.adler=c(v.adler,$.pending_buf,$.pending-A,A)),$.gzindex===$.gzhead.extra.length&&($.gzindex=0,$.status=73)}else $.status=73;if($.status===73)if($.gzhead.name){A=$.pending;do{if($.pending===$.pending_buf_size&&($.gzhead.hcrc&&$.pending>A&&(v.adler=c(v.adler,$.pending_buf,$.pending-A,A)),q(v),A=$.pending,$.pending===$.pending_buf_size)){P=1;break}P=$.gzindex<$.gzhead.name.length?255&$.gzhead.name.charCodeAt($.gzindex++):0,ne($,P)}while(P!==0);$.gzhead.hcrc&&$.pending>A&&(v.adler=c(v.adler,$.pending_buf,$.pending-A,A)),P===0&&($.gzindex=0,$.status=91)}else $.status=91;if($.status===91)if($.gzhead.comment){A=$.pending;do{if($.pending===$.pending_buf_size&&($.gzhead.hcrc&&$.pending>A&&(v.adler=c(v.adler,$.pending_buf,$.pending-A,A)),q(v),A=$.pending,$.pending===$.pending_buf_size)){P=1;break}P=$.gzindex<$.gzhead.comment.length?255&$.gzhead.comment.charCodeAt($.gzindex++):0,ne($,P)}while(P!==0);$.gzhead.hcrc&&$.pending>A&&(v.adler=c(v.adler,$.pending_buf,$.pending-A,A)),P===0&&($.status=103)}else $.status=103;if($.status===103&&($.gzhead.hcrc?($.pending+2>$.pending_buf_size&&q(v),$.pending+2<=$.pending_buf_size&&(ne($,255&v.adler),ne($,v.adler>>8&255),v.adler=0,$.status=O)):$.status=O),$.pending!==0){if(q(v),v.avail_out===0)return $.last_flush=-1,d}else if(v.avail_in===0&&B(K)<=B(H)&&K!==h)return M(v,-5);if($.status===666&&v.avail_in!==0)return M(v,-5);if(v.avail_in!==0||$.lookahead!==0||K!==f&&$.status!==666){var G=$.strategy===2?(function(Z,ee){for(var ce;;){if(Z.lookahead===0&&(Se(Z),Z.lookahead===0)){if(ee===f)return S;break}if(Z.match_length=0,ce=r._tr_tally(Z,0,Z.window[Z.strstart]),Z.lookahead--,Z.strstart++,ce&&(U(Z,!1),Z.strm.avail_out===0))return S}return Z.insert=0,ee===h?(U(Z,!0),Z.strm.avail_out===0?j:_):Z.last_lit&&(U(Z,!1),Z.strm.avail_out===0)?S:W})($,K):$.strategy===3?(function(Z,ee){for(var ce,re,me,_e,we=Z.window;;){if(Z.lookahead<=N){if(Se(Z),Z.lookahead<=N&&ee===f)return S;if(Z.lookahead===0)break}if(Z.match_length=0,Z.lookahead>=R&&0<Z.strstart&&(re=we[me=Z.strstart-1])===we[++me]&&re===we[++me]&&re===we[++me]){_e=Z.strstart+N;do;while(re===we[++me]&&re===we[++me]&&re===we[++me]&&re===we[++me]&&re===we[++me]&&re===we[++me]&&re===we[++me]&&re===we[++me]&&me<_e);Z.match_length=N-(_e-me),Z.match_length>Z.lookahead&&(Z.match_length=Z.lookahead)}if(Z.match_length>=R?(ce=r._tr_tally(Z,1,Z.match_length-R),Z.lookahead-=Z.match_length,Z.strstart+=Z.match_length,Z.match_length=0):(ce=r._tr_tally(Z,0,Z.window[Z.strstart]),Z.lookahead--,Z.strstart++),ce&&(U(Z,!1),Z.strm.avail_out===0))return S}return Z.insert=0,ee===h?(U(Z,!0),Z.strm.avail_out===0?j:_):Z.last_lit&&(U(Z,!1),Z.strm.avail_out===0)?S:W})($,K):s[$.level].func($,K);if(G!==j&&G!==_||($.status=666),G===S||G===j)return v.avail_out===0&&($.last_flush=-1),d;if(G===W&&(K===1?r._tr_align($):K!==5&&(r._tr_stored_block($,0,0,!1),K===3&&(Q($.head),$.lookahead===0&&($.strstart=0,$.block_start=0,$.insert=0))),q(v),v.avail_out===0))return $.last_flush=-1,d}return K!==h?d:$.wrap<=0?1:($.wrap===2?(ne($,255&v.adler),ne($,v.adler>>8&255),ne($,v.adler>>16&255),ne($,v.adler>>24&255),ne($,255&v.total_in),ne($,v.total_in>>8&255),ne($,v.total_in>>16&255),ne($,v.total_in>>24&255)):(oe($,v.adler>>>16),oe($,65535&v.adler)),q(v),0<$.wrap&&($.wrap=-$.wrap),$.pending!==0?d:1)},n.deflateEnd=function(v){var K;return v&&v.state?(K=v.state.status)!==E&&K!==69&&K!==73&&K!==91&&K!==103&&K!==O&&K!==666?M(v,b):(v.state=null,K===O?M(v,-3):d):b},n.deflateSetDictionary=function(v,K){var H,$,A,P,Y,G,Z,ee,ce=K.length;if(!v||!v.state||(P=(H=v.state).wrap)===2||P===1&&H.status!==E||H.lookahead)return b;for(P===1&&(v.adler=a(v.adler,K,ce,0)),H.wrap=0,ce>=H.w_size&&(P===0&&(Q(H.head),H.strstart=0,H.block_start=0,H.insert=0),ee=new l.Buf8(H.w_size),l.arraySet(ee,K,ce-H.w_size,H.w_size,0),K=ee,ce=H.w_size),Y=v.avail_in,G=v.next_in,Z=v.input,v.avail_in=ce,v.next_in=0,v.input=K,Se(H);H.lookahead>=R;){for($=H.strstart,A=H.lookahead-(R-1);H.ins_h=(H.ins_h<<H.hash_shift^H.window[$+R-1])&H.hash_mask,H.prev[$&H.w_mask]=H.head[H.ins_h],H.head[H.ins_h]=$,$++,--A;);H.strstart=$,H.lookahead=R-1,Se(H)}return H.strstart+=H.lookahead,H.block_start=H.strstart,H.insert=H.lookahead,H.lookahead=0,H.match_length=H.prev_length=R-1,H.match_available=0,v.next_in=G,v.input=Z,v.avail_in=Y,H.wrap=P,d},n.deflateInfo="pako deflate (from Nodeca project)"},{"../utils/common":41,"./adler32":43,"./crc32":45,"./messages":51,"./trees":52}],47:[function(o,i,n){i.exports=function(){this.text=0,this.time=0,this.xflags=0,this.os=0,this.extra=null,this.extra_len=0,this.name="",this.comment="",this.hcrc=0,this.done=!1}},{}],48:[function(o,i,n){i.exports=function(s,l){var r,a,c,u,f,h,d,b,m,y,g,x,k,I,T,w,C,L,R,N,F,E,O,S,W;r=s.state,a=s.next_in,S=s.input,c=a+(s.avail_in-5),u=s.next_out,W=s.output,f=u-(l-s.avail_out),h=u+(s.avail_out-257),d=r.dmax,b=r.wsize,m=r.whave,y=r.wnext,g=r.window,x=r.hold,k=r.bits,I=r.lencode,T=r.distcode,w=(1<<r.lenbits)-1,C=(1<<r.distbits)-1;e:do{k<15&&(x+=S[a++]<<k,k+=8,x+=S[a++]<<k,k+=8),L=I[x&w];t:for(;;){if(x>>>=R=L>>>24,k-=R,(R=L>>>16&255)===0)W[u++]=65535&L;else{if(!(16&R)){if((64&R)==0){L=I[(65535&L)+(x&(1<<R)-1)];continue t}if(32&R){r.mode=12;break e}s.msg="invalid literal/length code",r.mode=30;break e}N=65535&L,(R&=15)&&(k<R&&(x+=S[a++]<<k,k+=8),N+=x&(1<<R)-1,x>>>=R,k-=R),k<15&&(x+=S[a++]<<k,k+=8,x+=S[a++]<<k,k+=8),L=T[x&C];o:for(;;){if(x>>>=R=L>>>24,k-=R,!(16&(R=L>>>16&255))){if((64&R)==0){L=T[(65535&L)+(x&(1<<R)-1)];continue o}s.msg="invalid distance code",r.mode=30;break e}if(F=65535&L,k<(R&=15)&&(x+=S[a++]<<k,(k+=8)<R&&(x+=S[a++]<<k,k+=8)),d<(F+=x&(1<<R)-1)){s.msg="invalid distance too far back",r.mode=30;break e}if(x>>>=R,k-=R,(R=u-f)<F){if(m<(R=F-R)&&r.sane){s.msg="invalid distance too far back",r.mode=30;break e}if(O=g,(E=0)===y){if(E+=b-R,R<N){for(N-=R;W[u++]=g[E++],--R;);E=u-F,O=W}}else if(y<R){if(E+=b+y-R,(R-=y)<N){for(N-=R;W[u++]=g[E++],--R;);if(E=0,y<N){for(N-=R=y;W[u++]=g[E++],--R;);E=u-F,O=W}}}else if(E+=y-R,R<N){for(N-=R;W[u++]=g[E++],--R;);E=u-F,O=W}for(;2<N;)W[u++]=O[E++],W[u++]=O[E++],W[u++]=O[E++],N-=3;N&&(W[u++]=O[E++],1<N&&(W[u++]=O[E++]))}else{for(E=u-F;W[u++]=W[E++],W[u++]=W[E++],W[u++]=W[E++],2<(N-=3););N&&(W[u++]=W[E++],1<N&&(W[u++]=W[E++]))}break}}break}}while(a<c&&u<h);a-=N=k>>3,x&=(1<<(k-=N<<3))-1,s.next_in=a,s.next_out=u,s.avail_in=a<c?c-a+5:5-(a-c),s.avail_out=u<h?h-u+257:257-(u-h),r.hold=x,r.bits=k}},{}],49:[function(o,i,n){var s=o("../utils/common"),l=o("./adler32"),r=o("./crc32"),a=o("./inffast"),c=o("./inftrees"),u=1,f=2,h=0,d=-2,b=1,m=852,y=592;function g(E){return(E>>>24&255)+(E>>>8&65280)+((65280&E)<<8)+((255&E)<<24)}function x(){this.mode=0,this.last=!1,this.wrap=0,this.havedict=!1,this.flags=0,this.dmax=0,this.check=0,this.total=0,this.head=null,this.wbits=0,this.wsize=0,this.whave=0,this.wnext=0,this.window=null,this.hold=0,this.bits=0,this.length=0,this.offset=0,this.extra=0,this.lencode=null,this.distcode=null,this.lenbits=0,this.distbits=0,this.ncode=0,this.nlen=0,this.ndist=0,this.have=0,this.next=null,this.lens=new s.Buf16(320),this.work=new s.Buf16(288),this.lendyn=null,this.distdyn=null,this.sane=0,this.back=0,this.was=0}function k(E){var O;return E&&E.state?(O=E.state,E.total_in=E.total_out=O.total=0,E.msg="",O.wrap&&(E.adler=1&O.wrap),O.mode=b,O.last=0,O.havedict=0,O.dmax=32768,O.head=null,O.hold=0,O.bits=0,O.lencode=O.lendyn=new s.Buf32(m),O.distcode=O.distdyn=new s.Buf32(y),O.sane=1,O.back=-1,h):d}function I(E){var O;return E&&E.state?((O=E.state).wsize=0,O.whave=0,O.wnext=0,k(E)):d}function T(E,O){var S,W;return E&&E.state?(W=E.state,O<0?(S=0,O=-O):(S=1+(O>>4),O<48&&(O&=15)),O&&(O<8||15<O)?d:(W.window!==null&&W.wbits!==O&&(W.window=null),W.wrap=S,W.wbits=O,I(E))):d}function w(E,O){var S,W;return E?(W=new x,(E.state=W).window=null,(S=T(E,O))!==h&&(E.state=null),S):d}var C,L,R=!0;function N(E){if(R){var O;for(C=new s.Buf32(512),L=new s.Buf32(32),O=0;O<144;)E.lens[O++]=8;for(;O<256;)E.lens[O++]=9;for(;O<280;)E.lens[O++]=7;for(;O<288;)E.lens[O++]=8;for(c(u,E.lens,0,288,C,0,E.work,{bits:9}),O=0;O<32;)E.lens[O++]=5;c(f,E.lens,0,32,L,0,E.work,{bits:5}),R=!1}E.lencode=C,E.lenbits=9,E.distcode=L,E.distbits=5}function F(E,O,S,W){var j,_=E.state;return _.window===null&&(_.wsize=1<<_.wbits,_.wnext=0,_.whave=0,_.window=new s.Buf8(_.wsize)),W>=_.wsize?(s.arraySet(_.window,O,S-_.wsize,_.wsize,0),_.wnext=0,_.whave=_.wsize):(W<(j=_.wsize-_.wnext)&&(j=W),s.arraySet(_.window,O,S-W,j,_.wnext),(W-=j)?(s.arraySet(_.window,O,S-W,W,0),_.wnext=W,_.whave=_.wsize):(_.wnext+=j,_.wnext===_.wsize&&(_.wnext=0),_.whave<_.wsize&&(_.whave+=j))),0}n.inflateReset=I,n.inflateReset2=T,n.inflateResetKeep=k,n.inflateInit=function(E){return w(E,15)},n.inflateInit2=w,n.inflate=function(E,O){var S,W,j,_,M,B,Q,q,U,ne,oe,ae,Se,$e,ke,Ce,z,se,D,V,v,K,H,$,A=0,P=new s.Buf8(4),Y=[16,17,18,0,8,7,9,6,10,5,11,4,12,3,13,2,14,1,15];if(!E||!E.state||!E.output||!E.input&&E.avail_in!==0)return d;(S=E.state).mode===12&&(S.mode=13),M=E.next_out,j=E.output,Q=E.avail_out,_=E.next_in,W=E.input,B=E.avail_in,q=S.hold,U=S.bits,ne=B,oe=Q,K=h;e:for(;;)switch(S.mode){case b:if(S.wrap===0){S.mode=13;break}for(;U<16;){if(B===0)break e;B--,q+=W[_++]<<U,U+=8}if(2&S.wrap&&q===35615){P[S.check=0]=255&q,P[1]=q>>>8&255,S.check=r(S.check,P,2,0),U=q=0,S.mode=2;break}if(S.flags=0,S.head&&(S.head.done=!1),!(1&S.wrap)||(((255&q)<<8)+(q>>8))%31){E.msg="incorrect header check",S.mode=30;break}if((15&q)!=8){E.msg="unknown compression method",S.mode=30;break}if(U-=4,v=8+(15&(q>>>=4)),S.wbits===0)S.wbits=v;else if(v>S.wbits){E.msg="invalid window size",S.mode=30;break}S.dmax=1<<v,E.adler=S.check=1,S.mode=512&q?10:12,U=q=0;break;case 2:for(;U<16;){if(B===0)break e;B--,q+=W[_++]<<U,U+=8}if(S.flags=q,(255&S.flags)!=8){E.msg="unknown compression method",S.mode=30;break}if(57344&S.flags){E.msg="unknown header flags set",S.mode=30;break}S.head&&(S.head.text=q>>8&1),512&S.flags&&(P[0]=255&q,P[1]=q>>>8&255,S.check=r(S.check,P,2,0)),U=q=0,S.mode=3;case 3:for(;U<32;){if(B===0)break e;B--,q+=W[_++]<<U,U+=8}S.head&&(S.head.time=q),512&S.flags&&(P[0]=255&q,P[1]=q>>>8&255,P[2]=q>>>16&255,P[3]=q>>>24&255,S.check=r(S.check,P,4,0)),U=q=0,S.mode=4;case 4:for(;U<16;){if(B===0)break e;B--,q+=W[_++]<<U,U+=8}S.head&&(S.head.xflags=255&q,S.head.os=q>>8),512&S.flags&&(P[0]=255&q,P[1]=q>>>8&255,S.check=r(S.check,P,2,0)),U=q=0,S.mode=5;case 5:if(1024&S.flags){for(;U<16;){if(B===0)break e;B--,q+=W[_++]<<U,U+=8}S.length=q,S.head&&(S.head.extra_len=q),512&S.flags&&(P[0]=255&q,P[1]=q>>>8&255,S.check=r(S.check,P,2,0)),U=q=0}else S.head&&(S.head.extra=null);S.mode=6;case 6:if(1024&S.flags&&(B<(ae=S.length)&&(ae=B),ae&&(S.head&&(v=S.head.extra_len-S.length,S.head.extra||(S.head.extra=new Array(S.head.extra_len)),s.arraySet(S.head.extra,W,_,ae,v)),512&S.flags&&(S.check=r(S.check,W,ae,_)),B-=ae,_+=ae,S.length-=ae),S.length))break e;S.length=0,S.mode=7;case 7:if(2048&S.flags){if(B===0)break e;for(ae=0;v=W[_+ae++],S.head&&v&&S.length<65536&&(S.head.name+=String.fromCharCode(v)),v&&ae<B;);if(512&S.flags&&(S.check=r(S.check,W,ae,_)),B-=ae,_+=ae,v)break e}else S.head&&(S.head.name=null);S.length=0,S.mode=8;case 8:if(4096&S.flags){if(B===0)break e;for(ae=0;v=W[_+ae++],S.head&&v&&S.length<65536&&(S.head.comment+=String.fromCharCode(v)),v&&ae<B;);if(512&S.flags&&(S.check=r(S.check,W,ae,_)),B-=ae,_+=ae,v)break e}else S.head&&(S.head.comment=null);S.mode=9;case 9:if(512&S.flags){for(;U<16;){if(B===0)break e;B--,q+=W[_++]<<U,U+=8}if(q!==(65535&S.check)){E.msg="header crc mismatch",S.mode=30;break}U=q=0}S.head&&(S.head.hcrc=S.flags>>9&1,S.head.done=!0),E.adler=S.check=0,S.mode=12;break;case 10:for(;U<32;){if(B===0)break e;B--,q+=W[_++]<<U,U+=8}E.adler=S.check=g(q),U=q=0,S.mode=11;case 11:if(S.havedict===0)return E.next_out=M,E.avail_out=Q,E.next_in=_,E.avail_in=B,S.hold=q,S.bits=U,2;E.adler=S.check=1,S.mode=12;case 12:if(O===5||O===6)break e;case 13:if(S.last){q>>>=7&U,U-=7&U,S.mode=27;break}for(;U<3;){if(B===0)break e;B--,q+=W[_++]<<U,U+=8}switch(S.last=1&q,U-=1,3&(q>>>=1)){case 0:S.mode=14;break;case 1:if(N(S),S.mode=20,O!==6)break;q>>>=2,U-=2;break e;case 2:S.mode=17;break;case 3:E.msg="invalid block type",S.mode=30}q>>>=2,U-=2;break;case 14:for(q>>>=7&U,U-=7&U;U<32;){if(B===0)break e;B--,q+=W[_++]<<U,U+=8}if((65535&q)!=(q>>>16^65535)){E.msg="invalid stored block lengths",S.mode=30;break}if(S.length=65535&q,U=q=0,S.mode=15,O===6)break e;case 15:S.mode=16;case 16:if(ae=S.length){if(B<ae&&(ae=B),Q<ae&&(ae=Q),ae===0)break e;s.arraySet(j,W,_,ae,M),B-=ae,_+=ae,Q-=ae,M+=ae,S.length-=ae;break}S.mode=12;break;case 17:for(;U<14;){if(B===0)break e;B--,q+=W[_++]<<U,U+=8}if(S.nlen=257+(31&q),q>>>=5,U-=5,S.ndist=1+(31&q),q>>>=5,U-=5,S.ncode=4+(15&q),q>>>=4,U-=4,286<S.nlen||30<S.ndist){E.msg="too many length or distance symbols",S.mode=30;break}S.have=0,S.mode=18;case 18:for(;S.have<S.ncode;){for(;U<3;){if(B===0)break e;B--,q+=W[_++]<<U,U+=8}S.lens[Y[S.have++]]=7&q,q>>>=3,U-=3}for(;S.have<19;)S.lens[Y[S.have++]]=0;if(S.lencode=S.lendyn,S.lenbits=7,H={bits:S.lenbits},K=c(0,S.lens,0,19,S.lencode,0,S.work,H),S.lenbits=H.bits,K){E.msg="invalid code lengths set",S.mode=30;break}S.have=0,S.mode=19;case 19:for(;S.have<S.nlen+S.ndist;){for(;Ce=(A=S.lencode[q&(1<<S.lenbits)-1])>>>16&255,z=65535&A,!((ke=A>>>24)<=U);){if(B===0)break e;B--,q+=W[_++]<<U,U+=8}if(z<16)q>>>=ke,U-=ke,S.lens[S.have++]=z;else{if(z===16){for($=ke+2;U<$;){if(B===0)break e;B--,q+=W[_++]<<U,U+=8}if(q>>>=ke,U-=ke,S.have===0){E.msg="invalid bit length repeat",S.mode=30;break}v=S.lens[S.have-1],ae=3+(3&q),q>>>=2,U-=2}else if(z===17){for($=ke+3;U<$;){if(B===0)break e;B--,q+=W[_++]<<U,U+=8}U-=ke,v=0,ae=3+(7&(q>>>=ke)),q>>>=3,U-=3}else{for($=ke+7;U<$;){if(B===0)break e;B--,q+=W[_++]<<U,U+=8}U-=ke,v=0,ae=11+(127&(q>>>=ke)),q>>>=7,U-=7}if(S.have+ae>S.nlen+S.ndist){E.msg="invalid bit length repeat",S.mode=30;break}for(;ae--;)S.lens[S.have++]=v}}if(S.mode===30)break;if(S.lens[256]===0){E.msg="invalid code -- missing end-of-block",S.mode=30;break}if(S.lenbits=9,H={bits:S.lenbits},K=c(u,S.lens,0,S.nlen,S.lencode,0,S.work,H),S.lenbits=H.bits,K){E.msg="invalid literal/lengths set",S.mode=30;break}if(S.distbits=6,S.distcode=S.distdyn,H={bits:S.distbits},K=c(f,S.lens,S.nlen,S.ndist,S.distcode,0,S.work,H),S.distbits=H.bits,K){E.msg="invalid distances set",S.mode=30;break}if(S.mode=20,O===6)break e;case 20:S.mode=21;case 21:if(6<=B&&258<=Q){E.next_out=M,E.avail_out=Q,E.next_in=_,E.avail_in=B,S.hold=q,S.bits=U,a(E,oe),M=E.next_out,j=E.output,Q=E.avail_out,_=E.next_in,W=E.input,B=E.avail_in,q=S.hold,U=S.bits,S.mode===12&&(S.back=-1);break}for(S.back=0;Ce=(A=S.lencode[q&(1<<S.lenbits)-1])>>>16&255,z=65535&A,!((ke=A>>>24)<=U);){if(B===0)break e;B--,q+=W[_++]<<U,U+=8}if(Ce&&(240&Ce)==0){for(se=ke,D=Ce,V=z;Ce=(A=S.lencode[V+((q&(1<<se+D)-1)>>se)])>>>16&255,z=65535&A,!(se+(ke=A>>>24)<=U);){if(B===0)break e;B--,q+=W[_++]<<U,U+=8}q>>>=se,U-=se,S.back+=se}if(q>>>=ke,U-=ke,S.back+=ke,S.length=z,Ce===0){S.mode=26;break}if(32&Ce){S.back=-1,S.mode=12;break}if(64&Ce){E.msg="invalid literal/length code",S.mode=30;break}S.extra=15&Ce,S.mode=22;case 22:if(S.extra){for($=S.extra;U<$;){if(B===0)break e;B--,q+=W[_++]<<U,U+=8}S.length+=q&(1<<S.extra)-1,q>>>=S.extra,U-=S.extra,S.back+=S.extra}S.was=S.length,S.mode=23;case 23:for(;Ce=(A=S.distcode[q&(1<<S.distbits)-1])>>>16&255,z=65535&A,!((ke=A>>>24)<=U);){if(B===0)break e;B--,q+=W[_++]<<U,U+=8}if((240&Ce)==0){for(se=ke,D=Ce,V=z;Ce=(A=S.distcode[V+((q&(1<<se+D)-1)>>se)])>>>16&255,z=65535&A,!(se+(ke=A>>>24)<=U);){if(B===0)break e;B--,q+=W[_++]<<U,U+=8}q>>>=se,U-=se,S.back+=se}if(q>>>=ke,U-=ke,S.back+=ke,64&Ce){E.msg="invalid distance code",S.mode=30;break}S.offset=z,S.extra=15&Ce,S.mode=24;case 24:if(S.extra){for($=S.extra;U<$;){if(B===0)break e;B--,q+=W[_++]<<U,U+=8}S.offset+=q&(1<<S.extra)-1,q>>>=S.extra,U-=S.extra,S.back+=S.extra}if(S.offset>S.dmax){E.msg="invalid distance too far back",S.mode=30;break}S.mode=25;case 25:if(Q===0)break e;if(ae=oe-Q,S.offset>ae){if((ae=S.offset-ae)>S.whave&&S.sane){E.msg="invalid distance too far back",S.mode=30;break}Se=ae>S.wnext?(ae-=S.wnext,S.wsize-ae):S.wnext-ae,ae>S.length&&(ae=S.length),$e=S.window}else $e=j,Se=M-S.offset,ae=S.length;for(Q<ae&&(ae=Q),Q-=ae,S.length-=ae;j[M++]=$e[Se++],--ae;);S.length===0&&(S.mode=21);break;case 26:if(Q===0)break e;j[M++]=S.length,Q--,S.mode=21;break;case 27:if(S.wrap){for(;U<32;){if(B===0)break e;B--,q|=W[_++]<<U,U+=8}if(oe-=Q,E.total_out+=oe,S.total+=oe,oe&&(E.adler=S.check=S.flags?r(S.check,j,oe,M-oe):l(S.check,j,oe,M-oe)),oe=Q,(S.flags?q:g(q))!==S.check){E.msg="incorrect data check",S.mode=30;break}U=q=0}S.mode=28;case 28:if(S.wrap&&S.flags){for(;U<32;){if(B===0)break e;B--,q+=W[_++]<<U,U+=8}if(q!==(4294967295&S.total)){E.msg="incorrect length check",S.mode=30;break}U=q=0}S.mode=29;case 29:K=1;break e;case 30:K=-3;break e;case 31:return-4;case 32:default:return d}return E.next_out=M,E.avail_out=Q,E.next_in=_,E.avail_in=B,S.hold=q,S.bits=U,(S.wsize||oe!==E.avail_out&&S.mode<30&&(S.mode<27||O!==4))&&F(E,E.output,E.next_out,oe-E.avail_out)?(S.mode=31,-4):(ne-=E.avail_in,oe-=E.avail_out,E.total_in+=ne,E.total_out+=oe,S.total+=oe,S.wrap&&oe&&(E.adler=S.check=S.flags?r(S.check,j,oe,E.next_out-oe):l(S.check,j,oe,E.next_out-oe)),E.data_type=S.bits+(S.last?64:0)+(S.mode===12?128:0)+(S.mode===20||S.mode===15?256:0),(ne==0&&oe===0||O===4)&&K===h&&(K=-5),K)},n.inflateEnd=function(E){if(!E||!E.state)return d;var O=E.state;return O.window&&(O.window=null),E.state=null,h},n.inflateGetHeader=function(E,O){var S;return E&&E.state?(2&(S=E.state).wrap)==0?d:((S.head=O).done=!1,h):d},n.inflateSetDictionary=function(E,O){var S,W=O.length;return E&&E.state?(S=E.state).wrap!==0&&S.mode!==11?d:S.mode===11&&l(1,O,W,0)!==S.check?-3:F(E,O,W,W)?(S.mode=31,-4):(S.havedict=1,h):d},n.inflateInfo="pako inflate (from Nodeca project)"},{"../utils/common":41,"./adler32":43,"./crc32":45,"./inffast":48,"./inftrees":50}],50:[function(o,i,n){var s=o("../utils/common"),l=[3,4,5,6,7,8,9,10,11,13,15,17,19,23,27,31,35,43,51,59,67,83,99,115,131,163,195,227,258,0,0],r=[16,16,16,16,16,16,16,16,17,17,17,17,18,18,18,18,19,19,19,19,20,20,20,20,21,21,21,21,16,72,78],a=[1,2,3,4,5,7,9,13,17,25,33,49,65,97,129,193,257,385,513,769,1025,1537,2049,3073,4097,6145,8193,12289,16385,24577,0,0],c=[16,16,16,16,17,17,18,18,19,19,20,20,21,21,22,22,23,23,24,24,25,25,26,26,27,27,28,28,29,29,64,64];i.exports=function(u,f,h,d,b,m,y,g){var x,k,I,T,w,C,L,R,N,F=g.bits,E=0,O=0,S=0,W=0,j=0,_=0,M=0,B=0,Q=0,q=0,U=null,ne=0,oe=new s.Buf16(16),ae=new s.Buf16(16),Se=null,$e=0;for(E=0;E<=15;E++)oe[E]=0;for(O=0;O<d;O++)oe[f[h+O]]++;for(j=F,W=15;1<=W&&oe[W]===0;W--);if(W<j&&(j=W),W===0)return b[m++]=20971520,b[m++]=20971520,g.bits=1,0;for(S=1;S<W&&oe[S]===0;S++);for(j<S&&(j=S),E=B=1;E<=15;E++)if(B<<=1,(B-=oe[E])<0)return-1;if(0<B&&(u===0||W!==1))return-1;for(ae[1]=0,E=1;E<15;E++)ae[E+1]=ae[E]+oe[E];for(O=0;O<d;O++)f[h+O]!==0&&(y[ae[f[h+O]]++]=O);if(C=u===0?(U=Se=y,19):u===1?(U=l,ne-=257,Se=r,$e-=257,256):(U=a,Se=c,-1),E=S,w=m,M=O=q=0,I=-1,T=(Q=1<<(_=j))-1,u===1&&852<Q||u===2&&592<Q)return 1;for(;;){for(L=E-M,N=y[O]<C?(R=0,y[O]):y[O]>C?(R=Se[$e+y[O]],U[ne+y[O]]):(R=96,0),x=1<<E-M,S=k=1<<_;b[w+(q>>M)+(k-=x)]=L<<24|R<<16|N|0,k!==0;);for(x=1<<E-1;q&x;)x>>=1;if(x!==0?(q&=x-1,q+=x):q=0,O++,--oe[E]==0){if(E===W)break;E=f[h+y[O]]}if(j<E&&(q&T)!==I){for(M===0&&(M=j),w+=S,B=1<<(_=E-M);_+M<W&&!((B-=oe[_+M])<=0);)_++,B<<=1;if(Q+=1<<_,u===1&&852<Q||u===2&&592<Q)return 1;b[I=q&T]=j<<24|_<<16|w-m|0}}return q!==0&&(b[w+q]=E-M<<24|64<<16|0),g.bits=j,0}},{"../utils/common":41}],51:[function(o,i,n){i.exports={2:"need dictionary",1:"stream end",0:"","-1":"file error","-2":"stream error","-3":"data error","-4":"insufficient memory","-5":"buffer error","-6":"incompatible version"}},{}],52:[function(o,i,n){var s=o("../utils/common"),l=0,r=1;function a(A){for(var P=A.length;0<=--P;)A[P]=0}var c=0,u=29,f=256,h=f+1+u,d=30,b=19,m=2*h+1,y=15,g=16,x=7,k=256,I=16,T=17,w=18,C=[0,0,0,0,0,0,0,0,1,1,1,1,2,2,2,2,3,3,3,3,4,4,4,4,5,5,5,5,0],L=[0,0,0,0,1,1,2,2,3,3,4,4,5,5,6,6,7,7,8,8,9,9,10,10,11,11,12,12,13,13],R=[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,2,3,7],N=[16,17,18,0,8,7,9,6,10,5,11,4,12,3,13,2,14,1,15],F=new Array(2*(h+2));a(F);var E=new Array(2*d);a(E);var O=new Array(512);a(O);var S=new Array(256);a(S);var W=new Array(u);a(W);var j,_,M,B=new Array(d);function Q(A,P,Y,G,Z){this.static_tree=A,this.extra_bits=P,this.extra_base=Y,this.elems=G,this.max_length=Z,this.has_stree=A&&A.length}function q(A,P){this.dyn_tree=A,this.max_code=0,this.stat_desc=P}function U(A){return A<256?O[A]:O[256+(A>>>7)]}function ne(A,P){A.pending_buf[A.pending++]=255&P,A.pending_buf[A.pending++]=P>>>8&255}function oe(A,P,Y){A.bi_valid>g-Y?(A.bi_buf|=P<<A.bi_valid&65535,ne(A,A.bi_buf),A.bi_buf=P>>g-A.bi_valid,A.bi_valid+=Y-g):(A.bi_buf|=P<<A.bi_valid&65535,A.bi_valid+=Y)}function ae(A,P,Y){oe(A,Y[2*P],Y[2*P+1])}function Se(A,P){for(var Y=0;Y|=1&A,A>>>=1,Y<<=1,0<--P;);return Y>>>1}function $e(A,P,Y){var G,Z,ee=new Array(y+1),ce=0;for(G=1;G<=y;G++)ee[G]=ce=ce+Y[G-1]<<1;for(Z=0;Z<=P;Z++){var re=A[2*Z+1];re!==0&&(A[2*Z]=Se(ee[re]++,re))}}function ke(A){var P;for(P=0;P<h;P++)A.dyn_ltree[2*P]=0;for(P=0;P<d;P++)A.dyn_dtree[2*P]=0;for(P=0;P<b;P++)A.bl_tree[2*P]=0;A.dyn_ltree[2*k]=1,A.opt_len=A.static_len=0,A.last_lit=A.matches=0}function Ce(A){8<A.bi_valid?ne(A,A.bi_buf):0<A.bi_valid&&(A.pending_buf[A.pending++]=A.bi_buf),A.bi_buf=0,A.bi_valid=0}function z(A,P,Y,G){var Z=2*P,ee=2*Y;return A[Z]<A[ee]||A[Z]===A[ee]&&G[P]<=G[Y]}function se(A,P,Y){for(var G=A.heap[Y],Z=Y<<1;Z<=A.heap_len&&(Z<A.heap_len&&z(P,A.heap[Z+1],A.heap[Z],A.depth)&&Z++,!z(P,G,A.heap[Z],A.depth));)A.heap[Y]=A.heap[Z],Y=Z,Z<<=1;A.heap[Y]=G}function D(A,P,Y){var G,Z,ee,ce,re=0;if(A.last_lit!==0)for(;G=A.pending_buf[A.d_buf+2*re]<<8|A.pending_buf[A.d_buf+2*re+1],Z=A.pending_buf[A.l_buf+re],re++,G===0?ae(A,Z,P):(ae(A,(ee=S[Z])+f+1,P),(ce=C[ee])!==0&&oe(A,Z-=W[ee],ce),ae(A,ee=U(--G),Y),(ce=L[ee])!==0&&oe(A,G-=B[ee],ce)),re<A.last_lit;);ae(A,k,P)}function V(A,P){var Y,G,Z,ee=P.dyn_tree,ce=P.stat_desc.static_tree,re=P.stat_desc.has_stree,me=P.stat_desc.elems,_e=-1;for(A.heap_len=0,A.heap_max=m,Y=0;Y<me;Y++)ee[2*Y]!==0?(A.heap[++A.heap_len]=_e=Y,A.depth[Y]=0):ee[2*Y+1]=0;for(;A.heap_len<2;)ee[2*(Z=A.heap[++A.heap_len]=_e<2?++_e:0)]=1,A.depth[Z]=0,A.opt_len--,re&&(A.static_len-=ce[2*Z+1]);for(P.max_code=_e,Y=A.heap_len>>1;1<=Y;Y--)se(A,ee,Y);for(Z=me;Y=A.heap[1],A.heap[1]=A.heap[A.heap_len--],se(A,ee,1),G=A.heap[1],A.heap[--A.heap_max]=Y,A.heap[--A.heap_max]=G,ee[2*Z]=ee[2*Y]+ee[2*G],A.depth[Z]=(A.depth[Y]>=A.depth[G]?A.depth[Y]:A.depth[G])+1,ee[2*Y+1]=ee[2*G+1]=Z,A.heap[1]=Z++,se(A,ee,1),2<=A.heap_len;);A.heap[--A.heap_max]=A.heap[1],(function(we,De){var He,Ge,rt,Pe,pt,tt,Ye=De.dyn_tree,fe=De.max_code,pe=De.stat_desc.static_tree,Qe=De.stat_desc.has_stree,at=De.stat_desc.extra_bits,At=De.stat_desc.extra_base,lt=De.stat_desc.max_length,fo=0;for(Pe=0;Pe<=y;Pe++)we.bl_count[Pe]=0;for(Ye[2*we.heap[we.heap_max]+1]=0,He=we.heap_max+1;He<m;He++)lt<(Pe=Ye[2*Ye[2*(Ge=we.heap[He])+1]+1]+1)&&(Pe=lt,fo++),Ye[2*Ge+1]=Pe,fe<Ge||(we.bl_count[Pe]++,pt=0,At<=Ge&&(pt=at[Ge-At]),tt=Ye[2*Ge],we.opt_len+=tt*(Pe+pt),Qe&&(we.static_len+=tt*(pe[2*Ge+1]+pt)));if(fo!==0){do{for(Pe=lt-1;we.bl_count[Pe]===0;)Pe--;we.bl_count[Pe]--,we.bl_count[Pe+1]+=2,we.bl_count[lt]--,fo-=2}while(0<fo);for(Pe=lt;Pe!==0;Pe--)for(Ge=we.bl_count[Pe];Ge!==0;)fe<(rt=we.heap[--He])||(Ye[2*rt+1]!==Pe&&(we.opt_len+=(Pe-Ye[2*rt+1])*Ye[2*rt],Ye[2*rt+1]=Pe),Ge--)}})(A,P),$e(ee,_e,A.bl_count)}function v(A,P,Y){var G,Z,ee=-1,ce=P[1],re=0,me=7,_e=4;for(ce===0&&(me=138,_e=3),P[2*(Y+1)+1]=65535,G=0;G<=Y;G++)Z=ce,ce=P[2*(G+1)+1],++re<me&&Z===ce||(re<_e?A.bl_tree[2*Z]+=re:Z!==0?(Z!==ee&&A.bl_tree[2*Z]++,A.bl_tree[2*I]++):re<=10?A.bl_tree[2*T]++:A.bl_tree[2*w]++,ee=Z,_e=(re=0)===ce?(me=138,3):Z===ce?(me=6,3):(me=7,4))}function K(A,P,Y){var G,Z,ee=-1,ce=P[1],re=0,me=7,_e=4;for(ce===0&&(me=138,_e=3),G=0;G<=Y;G++)if(Z=ce,ce=P[2*(G+1)+1],!(++re<me&&Z===ce)){if(re<_e)for(;ae(A,Z,A.bl_tree),--re!=0;);else Z!==0?(Z!==ee&&(ae(A,Z,A.bl_tree),re--),ae(A,I,A.bl_tree),oe(A,re-3,2)):re<=10?(ae(A,T,A.bl_tree),oe(A,re-3,3)):(ae(A,w,A.bl_tree),oe(A,re-11,7));ee=Z,_e=(re=0)===ce?(me=138,3):Z===ce?(me=6,3):(me=7,4)}}a(B);var H=!1;function $(A,P,Y,G){oe(A,(c<<1)+(G?1:0),3),(function(Z,ee,ce,re){Ce(Z),ne(Z,ce),ne(Z,~ce),s.arraySet(Z.pending_buf,Z.window,ee,ce,Z.pending),Z.pending+=ce})(A,P,Y)}n._tr_init=function(A){H||((function(){var P,Y,G,Z,ee,ce=new Array(y+1);for(Z=G=0;Z<u-1;Z++)for(W[Z]=G,P=0;P<1<<C[Z];P++)S[G++]=Z;for(S[G-1]=Z,Z=ee=0;Z<16;Z++)for(B[Z]=ee,P=0;P<1<<L[Z];P++)O[ee++]=Z;for(ee>>=7;Z<d;Z++)for(B[Z]=ee<<7,P=0;P<1<<L[Z]-7;P++)O[256+ee++]=Z;for(Y=0;Y<=y;Y++)ce[Y]=0;for(P=0;P<=143;)F[2*P+1]=8,P++,ce[8]++;for(;P<=255;)F[2*P+1]=9,P++,ce[9]++;for(;P<=279;)F[2*P+1]=7,P++,ce[7]++;for(;P<=287;)F[2*P+1]=8,P++,ce[8]++;for($e(F,h+1,ce),P=0;P<d;P++)E[2*P+1]=5,E[2*P]=Se(P,5);j=new Q(F,C,f+1,h,y),_=new Q(E,L,0,d,y),M=new Q(new Array(0),R,0,b,x)})(),H=!0),A.l_desc=new q(A.dyn_ltree,j),A.d_desc=new q(A.dyn_dtree,_),A.bl_desc=new q(A.bl_tree,M),A.bi_buf=0,A.bi_valid=0,ke(A)},n._tr_stored_block=$,n._tr_flush_block=function(A,P,Y,G){var Z,ee,ce=0;0<A.level?(A.strm.data_type===2&&(A.strm.data_type=(function(re){var me,_e=4093624447;for(me=0;me<=31;me++,_e>>>=1)if(1&_e&&re.dyn_ltree[2*me]!==0)return l;if(re.dyn_ltree[18]!==0||re.dyn_ltree[20]!==0||re.dyn_ltree[26]!==0)return r;for(me=32;me<f;me++)if(re.dyn_ltree[2*me]!==0)return r;return l})(A)),V(A,A.l_desc),V(A,A.d_desc),ce=(function(re){var me;for(v(re,re.dyn_ltree,re.l_desc.max_code),v(re,re.dyn_dtree,re.d_desc.max_code),V(re,re.bl_desc),me=b-1;3<=me&&re.bl_tree[2*N[me]+1]===0;me--);return re.opt_len+=3*(me+1)+5+5+4,me})(A),Z=A.opt_len+3+7>>>3,(ee=A.static_len+3+7>>>3)<=Z&&(Z=ee)):Z=ee=Y+5,Y+4<=Z&&P!==-1?$(A,P,Y,G):A.strategy===4||ee===Z?(oe(A,2+(G?1:0),3),D(A,F,E)):(oe(A,4+(G?1:0),3),(function(re,me,_e,we){var De;for(oe(re,me-257,5),oe(re,_e-1,5),oe(re,we-4,4),De=0;De<we;De++)oe(re,re.bl_tree[2*N[De]+1],3);K(re,re.dyn_ltree,me-1),K(re,re.dyn_dtree,_e-1)})(A,A.l_desc.max_code+1,A.d_desc.max_code+1,ce+1),D(A,A.dyn_ltree,A.dyn_dtree)),ke(A),G&&Ce(A)},n._tr_tally=function(A,P,Y){return A.pending_buf[A.d_buf+2*A.last_lit]=P>>>8&255,A.pending_buf[A.d_buf+2*A.last_lit+1]=255&P,A.pending_buf[A.l_buf+A.last_lit]=255&Y,A.last_lit++,P===0?A.dyn_ltree[2*Y]++:(A.matches++,P--,A.dyn_ltree[2*(S[Y]+f+1)]++,A.dyn_dtree[2*U(P)]++),A.last_lit===A.lit_bufsize-1},n._tr_align=function(A){oe(A,2,3),ae(A,k,F),(function(P){P.bi_valid===16?(ne(P,P.bi_buf),P.bi_buf=0,P.bi_valid=0):8<=P.bi_valid&&(P.pending_buf[P.pending++]=255&P.bi_buf,P.bi_buf>>=8,P.bi_valid-=8)})(A)}},{"../utils/common":41}],53:[function(o,i,n){i.exports=function(){this.input=null,this.next_in=0,this.avail_in=0,this.total_in=0,this.output=null,this.next_out=0,this.avail_out=0,this.total_out=0,this.msg="",this.state=null,this.data_type=2,this.adler=0}},{}],54:[function(o,i,n){(function(s){(function(l,r){if(!l.setImmediate){var a,c,u,f,h=1,d={},b=!1,m=l.document,y=Object.getPrototypeOf&&Object.getPrototypeOf(l);y=y&&y.setTimeout?y:l,a={}.toString.call(l.process)==="[object process]"?function(I){process.nextTick(function(){x(I)})}:(function(){if(l.postMessage&&!l.importScripts){var I=!0,T=l.onmessage;return l.onmessage=function(){I=!1},l.postMessage("","*"),l.onmessage=T,I}})()?(f="setImmediate$"+Math.random()+"$",l.addEventListener?l.addEventListener("message",k,!1):l.attachEvent("onmessage",k),function(I){l.postMessage(f+I,"*")}):l.MessageChannel?((u=new MessageChannel).port1.onmessage=function(I){x(I.data)},function(I){u.port2.postMessage(I)}):m&&"onreadystatechange"in m.createElement("script")?(c=m.documentElement,function(I){var T=m.createElement("script");T.onreadystatechange=function(){x(I),T.onreadystatechange=null,c.removeChild(T),T=null},c.appendChild(T)}):function(I){setTimeout(x,0,I)},y.setImmediate=function(I){typeof I!="function"&&(I=new Function(""+I));for(var T=new Array(arguments.length-1),w=0;w<T.length;w++)T[w]=arguments[w+1];var C={callback:I,args:T};return d[h]=C,a(h),h++},y.clearImmediate=g}function g(I){delete d[I]}function x(I){if(b)setTimeout(x,0,I);else{var T=d[I];if(T){b=!0;try{(function(w){var C=w.callback,L=w.args;switch(L.length){case 0:C();break;case 1:C(L[0]);break;case 2:C(L[0],L[1]);break;case 3:C(L[0],L[1],L[2]);break;default:C.apply(r,L)}})(T)}finally{g(I),b=!1}}}}function k(I){I.source===l&&typeof I.data=="string"&&I.data.indexOf(f)===0&&x(+I.data.slice(f.length))}})(typeof self>"u"?s===void 0?this:s:self)}).call(this,typeof gn<"u"?gn:typeof self<"u"?self:typeof window<"u"?window:{})},{}]},{},[10])(10)})})(Ss)),Ss.exports}var Eg=Mg();const gc=Ag(Eg);function yc(e){const t=(e||"").trim();return t?`即现（${t}）`:"即现"}async function bc(e,t){var o,i,n;if(!t)return"";if(typeof document<"u"){const s=document.querySelector(`.protyle-title[data-node-id="${t}"] .protyle-title__input`)||document.querySelector(`.protyle[data-doc-id="${t}"] .protyle-title__input`)||(e.getActiveDocumentId()===t?document.querySelector(".layout__wnd--active .protyle-title__input"):null)||document.querySelector(".protyle-title__input"),l=((s==null?void 0:s.innerText)||(s==null?void 0:s.textContent)||"").trim();if(l)return l}if(e.latestCompiledDoc&&e.latestCompiledDoc.docId===t){const s=(o=e.latestCompiledDoc.slides)==null?void 0:o[0],l=(i=s==null?void 0:s.blocks)==null?void 0:i.find(r=>r.type==="h"||r.type==="NodeHeading");if(l!=null&&l.content)return l.content.trim()}try{const s=await ki(`SELECT content FROM blocks WHERE id = '${t}' AND type = 'd' LIMIT 1`).catch(()=>[]);if(Array.isArray(s)&&s.length>0&&((n=s[0])!=null&&n.content))return String(s[0].content).trim()}catch{}return""}async function Bg(e,t,o){var c,u,f;const i=M2(),n=!!((c=i==null?void 0:i.isPinned)!=null&&c.value),s=String(((u=i==null?void 0:i.pinnedDocId)==null?void 0:u.value)||"");if(n&&s&&o&&o!==s)return;const l=o||(n&&s?s:e.currentDocId||e.getActiveDocumentId());let r=(t||"").trim();!r&&l&&(r=typeof e.fetchDocumentTitle=="function"?await e.fetchDocumentTitle(l):await bc(e,l));const a=yc(r);if(e.previewTab&&typeof e.previewTab.updateTitle=="function"){e.previewTab.updateTitle(a),e.previewTab.headElement&&e.previewTab.headElement.setAttribute("title",a);return}if(typeof document<"u"){const h=Array.from(document.querySelectorAll('.layout-tab-bar .item[data-type="tab-header"]'));for(const d of h){const b=d.querySelector(".item__text"),m=((f=b==null?void 0:b.textContent)==null?void 0:f.trim())||"";if(m.includes("Slidev 演示预览")||m.startsWith("即现")){b&&(b.textContent=a),d.setAttribute("title",a);break}}}}function Oi(e){return(e||"").replace(/[/\\?%*:|"<>]/g,"_").replace(/_+/g,"_").trim().replace(/^_+|_+$/g,"")||"presentation"}async function Ho(e,t,o){var n,s;const i=t||(e==null?void 0:e.docId)||"";if(o&&typeof o.fetchDocumentTitle=="function"&&i)try{const l=await o.fetchDocumentTitle(i);if(l&&l.trim())return Oi(l)}catch{}if(typeof document<"u")try{const l=(i?document.querySelector(`.protyle-title[data-node-id="${i}"] .protyle-title__input`):null)||(i?document.querySelector(`.protyle[data-doc-id="${i}"] .protyle-title__input`):null)||document.querySelector(".layout__wnd--active .protyle-title__input")||document.querySelector(".protyle-title__input"),r=((l==null?void 0:l.innerText)||(l==null?void 0:l.textContent)||"").trim();if(r)return Oi(r)}catch{}if((n=e==null?void 0:e.config)!=null&&n.title&&e.config.title.trim()&&e.config.title.trim().toLowerCase()!=="presentation")return Oi(e.config.title);if(e!=null&&e.slides&&e.slides.length>0){const r=(s=e.slides[0].blocks)==null?void 0:s.find(c=>c.type==="h"||c.type==="NodeHeading"),a=((r==null?void 0:r.content)||"").replace(/^#+\s*/,"").trim();if(a)return Oi(a)}return"presentation"}function Lg(e,t){if(typeof document>"u")return!1;const o=URL.createObjectURL(t),i=document.createElement("a");return i.href=o,i.download=e,document.body.appendChild(i),i.click(),document.body.removeChild(i),URL.revokeObjectURL(o),!0}function Ba(e,t){if(typeof document>"u")return!1;const o=document.createElement("a");return o.href=t,o.download=e,document.body.appendChild(o),o.click(),document.body.removeChild(o),!0}async function Dg(e){if(typeof navigator>"u"||!navigator.clipboard||typeof ClipboardItem>"u")return!1;try{const o=await(await fetch(e)).blob();return await navigator.clipboard.write([new ClipboardItem({[o.type||"image/png"]:o})]),!0}catch(t){return console.warn("[image-exporter] 复制图像至剪贴板失败:",t),!1}}async function Zs(e,t){return new Promise(o=>{let i=[],n=null;const s=()=>{n&&(clearTimeout(n),n=null),i.forEach(a=>a()),i=[]};n=setTimeout(()=>{s(),o({success:!1,error:"单页截图超时（沙箱无响应）"})},2e4);const l=e.onCapturePageDone(a=>{s(),o({success:!0,dataUrl:a.dataUrl})});i.push(l);const r=e.onCaptureError(a=>{s(),o({success:!1,error:a})});i.push(r),e.startImageExport({mode:"current",scale:(t==null?void 0:t.scale)||2,format:(t==null?void 0:t.format)||"png"})})}async function vc(e,t){const o=[],i=Oi((t==null?void 0:t.title)||"presentation");return new Promise(n=>{let s=[],l=null;const r=()=>{l&&(clearTimeout(l),l=null),s.forEach(d=>d()),s=[]},a=()=>{l&&clearTimeout(l),l=setTimeout(()=>{r(),n({success:!1,error:"幻灯片逐页导出超时（沙箱无响应）"})},35e3)};a();const c=e.onCaptureProgress(d=>{var b;a(),(b=t==null?void 0:t.onProgress)==null||b.call(t,d.current,d.total,d.pageIndex)});s.push(c);const u=e.onCapturePageDone(d=>{a(),(d.mode==="all"||!d.mode)&&o.push({pageIndex:d.pageIndex,dataUrl:d.dataUrl})});s.push(u);const f=async()=>{r();try{if(o.length===0){n({success:!1,error:"未采集到幻灯片图像数据"});return}const d=new gc,b=(t==null?void 0:t.format)==="jpeg"?"jpg":"png";for(const g of o){const x=String(g.pageIndex).padStart(2,"0"),k=g.dataUrl.split(",")[1];d.file(`slide-${x}.${b}`,k,{base64:!0})}const m=await d.generateAsync({type:"blob",compression:"DEFLATE"}),y=Lg(`${i}.zip`,m);n({success:y,total:o.length})}catch(d){n({success:!1,error:(d==null?void 0:d.message)||String(d)})}};s.push(e.onCaptureComplete(f));const h=e.onCaptureError(d=>{r(),n({success:!1,error:d})});s.push(h),e.startImageExport({mode:"all",scale:(t==null?void 0:t.scale)||2,format:(t==null?void 0:t.format)||"png"})})}async function kc(e,t){if(typeof document>"u")return{success:!1,error:"环境不支持 DOM 沙箱挂载"};const o=document.createElement("iframe");o.style.position="fixed",o.style.left="-9999px",o.style.top="-9999px",o.style.width="1920px",o.style.height="1080px",o.style.opacity="0",o.style.pointerEvents="none",o.src="/plugins/siyuan-live-slides/slides-client/index.html?headless=true",document.body.appendChild(o);const i=new ss;i.attach(o);try{if(await new Promise((n,s)=>{const l=setTimeout(()=>s(new Error("静默后台沙箱加载超时")),12e3);i.onClientReady(()=>{clearTimeout(l),n()})}),i.updateSlides(e.slides,e.config),await new Promise(n=>setTimeout(n,250)),(t==null?void 0:t.mode)==="current"){const n=await Zs(i,t);return{success:n.success,total:1,error:n.error}}else{const n=(t==null?void 0:t.title)||await Ho(e,e.docId);return await vc(i,{...t,title:n})}}catch(n){return{success:!1,error:(n==null?void 0:n.message)||String(n)}}finally{i.detach(),o.remove()}}const Ng=1500,Og=500,Pg=4,Rg=new Set(["INPUT","TEXTAREA","SELECT"]);function wc(e){const t=e;return!t||!t.tagName?!1:Rg.has(t.tagName)||t.isContentEditable===!0}function zg(e){let t="",o=!1,i=null,n=null;function s(){e.onStateChange&&e.onStateChange({display:t,invalid:o})}function l(){i&&(clearTimeout(i),i=null),n&&(clearTimeout(n),n=null)}function r(){l(),t="",o=!1,s()}function a(){i&&clearTimeout(i),i=setTimeout(r,Ng)}function c(){i&&(clearTimeout(i),i=null),o=!0,s(),n&&clearTimeout(n),n=setTimeout(r,Og)}function u(f){if(e.isEnabled&&!e.isEnabled()||wc(f.target)||f.isComposing||f.ctrlKey||f.metaKey||f.altKey)return!1;if(/^[0-9]$/.test(f.key))return o||t.length>=Pg||(t+=f.key,s(),a()),!0;if(f.key==="Enter"){if(!t||o)return!1;const d=parseInt(t,10),b=e.getTotalPages();return!isNaN(d)&&d>=1&&b>0&&d<=b?(r(),e.onJump(d),!0):(c(),!0)}return f.key==="Escape"&&(t||o)?(r(),!0):!1}return{handleKeydown:u,getState:()=>({display:t,invalid:o}),clear:r}}const Hg={class:"spm-slides-tab__toolbar"},Fg={class:"spm-slides-tab__nav"},jg=["disabled"],Ug={class:"spm-page-badge"},Wg=["disabled"],qg=["aria-label"],Vg={class:"spm-slides-tab__tools"},Kg={key:3,class:"spm-export-image-dropdown",style:{position:"relative",display:"inline-flex","align-items":"center"}},Gg={key:0,class:"b3-menu b3-menu--context",style:{position:"absolute",top:"calc(100% + 4px)",right:"0","z-index":"100","min-width":"190px","box-shadow":"var(--b3-point-shadow)","border-radius":"4px",background:"var(--b3-theme-surface)"}},Yg=["src"],Zg=Ht({__name:"SlidesPreviewTab",setup(e,{expose:t}){const o=Zt("plugin"),i=Zt("sandboxBridge",new ss),n=new og(i),s=he(null),l=he(!1),r=he(null),a=he(1),c=he(1),u=he(!1),f=he(!1),h=he(!1),d=he("siyuan"),b=he(""),m=he(""),y=he(""),g=he(!1),x=he(!1),k=he(""),I=he(""),T=he(!1),w=zg({getTotalPages:()=>c.value,isEnabled:()=>!f.value,onJump:$=>R($),onStateChange:$=>{I.value=$.display,T.value=$.invalid}});function C($){if($.key==="o"||$.key==="O"){if(f.value||$.isComposing||$.ctrlKey||$.metaKey||$.altKey||wc($.target))return;$.preventDefault(),L();return}w.handleKeydown($)&&$.preventDefault()}function L(){var $;i.toggleOverview(),($=r.value)==null||$.focus()}function R($){var A;a.value=$,i.navigatePage($),(A=r.value)==null||A.focus()}const N=he("/plugins/siyuan-live-slides/slides-client/index.html");let F=null,E=null,O=null,S=null,W=null,j=null,_=null,M=null;oi(()=>{r.value&&i.attach(r.value),F=i.onSlideChanged(($,A)=>{a.value=$,c.value=A}),E=i.onBlockClicked(($,A)=>{a.value=A,n.setActiveBlockId($),$||qi(),o&&typeof o.handleBlockClickedFromSlide=="function"?o.handleBlockClickedFromSlide($,A):$&&zo($,o==null?void 0:o.app)}),O=i.onOpenInEditor(($,A)=>{a.value=A,n.setActiveBlockId($),zo($,o==null?void 0:o.app)}),S=i.onOpenPeekDrawer(async $=>{const A=jo();if($.peekType==="siyuan"&&A.enableWebServeJump){let P=!1;if(M&&M.docId===$.target)P=!0;else if(M&&M.slides&&M.slides.some(Y=>{var G;return(G=Y.blocks)==null?void 0:G.some(Z=>Z.id===$.target)}))P=!1;else try{const Y=await ki(`SELECT id, root_id, type FROM blocks WHERE id = '${$.target}' LIMIT 1`);Y&&Y.length>0&&(P=Y[0].type==="d"||Y[0].id===Y[0].root_id)}catch(Y){console.warn("[SlidesPreviewTab] detect block type failed:",Y)}d.value="web",g.value=!0,m.value=ec(A.webServeUrl,$.target,{focus:!P}),y.value=$.title||`${P?"思源文档":"思源块"}: ${$.target.slice(0,8)}`,f.value=!0,i.freezeKeyboardNav(!0)}else{if(d.value=$.peekType,$.peekType==="siyuan")b.value=$.target,y.value=$.title||`块速览: ${$.target.slice(0,8)}`;else{const P=lc($.target);if(P.external){$e($.target);return}g.value=!0,m.value=P.url,y.value=$.title||P.url}f.value=!0,i.freezeKeyboardNav(!0)}}),W=i.onRequestToggleFullscreen(()=>{Ce()}),j=i.onOpenPresenter(()=>{z()}),typeof document<"u"&&document.addEventListener("fullscreenchange",ke),_=rc($=>{M&&i.updateSlides(M.slides,{...M.config,hostThemeMode:$},M.customThemeCss)})}),sn(()=>{_&&(_(),_=null),typeof document<"u"&&document.removeEventListener("fullscreenchange",ke),S&&S(),W&&W(),j&&j(),F&&F(),E&&E(),O&&O(),i.detach(),w.clear(),n.destroy()});function B(){x.value=!x.value,x.value?(k.value=(M==null?void 0:M.docId)||"",o&&typeof o.updatePreviewTabHeader=="function"&&o.updatePreviewTabHeader("",k.value)):(k.value="",oe(),o&&typeof o.updatePreviewTabHeader=="function"&&o.updatePreviewTabHeader())}let Q=0;function q($){if(f.value||Math.abs($.deltaY)<Math.abs($.deltaX)||Math.abs($.deltaY)<15)return;const A=Date.now();A-Q<280||(Q=A,$.deltaY>0?ne():U())}function U(){if(a.value>1){const $=a.value-1;a.value=$,i.navigatePage($)}}function ne(){if(a.value<c.value){const $=a.value+1;a.value=$,i.navigatePage($)}}function oe(){o&&typeof o.compileCurrentDocument=="function"?o.compileCurrentDocument():o!=null&&o.eventBus&&typeof o.eventBus.emit=="function"&&o.eventBus.emit("slides:request-compile")}function ae(){f.value=!1,i.freezeKeyboardNav(!1)}function Se(){ae()}function $e($){var G,Z;const A=/^file:/i.test($),P=A||/^[a-zA-Z]:[\\/]/.test($),Y=an("electron");if(P&&typeof((G=Y==null?void 0:Y.shell)==null?void 0:G.openPath)=="function"){Y.shell.openPath(A?ac($):$),ie.showMessage("本地文件不在思源工作区内，已交由系统默认浏览器打开");return}typeof((Z=Y==null?void 0:Y.shell)==null?void 0:Z.openExternal)=="function"?Y.shell.openExternal($).catch(()=>{typeof window<"u"&&window.open($,"_blank")}):typeof window<"u"&&window.open($,"_blank"),ie.showMessage("该地址无法在速览抽屉内加载，已交由系统默认浏览器打开")}function ke(){typeof document<"u"&&(l.value=!!document.fullscreenElement,i.postMessage("FULLSCREEN_CHANGED",{isFullscreen:l.value}))}function Ce(){const $=s.value||r.value;$&&(document.fullscreenElement?document.exitFullscreen().then(()=>{i.postMessage("FULLSCREEN_CHANGED",{isFullscreen:!1})}).catch(()=>{}):$.requestFullscreen().then(()=>{i.postMessage("FULLSCREEN_CHANGED",{isFullscreen:!0})}).catch(()=>{}))}function z(){o&&typeof o.openPresenterTab=="function"&&o.openPresenterTab()}async function se(){if(!M){ie.showMessage("请先在主编辑区打开幻灯片文档");return}const $=await Ho(M,o==null?void 0:o.currentDocId,o);ie.showMessage("正在导出单文件离线 HTML（内联媒体资源中...）",2e3);const A=await pc(M,{title:$});hc(`${$}.html`,A)&&ie.showMessage(`已开始下载单文件离线 HTML 演示包 (${$}.html)`)}function D(){if(!M){ie.showMessage("请先在主编辑区打开幻灯片文档");return}mc(M)&&ie.showMessage("已唤起打印视窗，请在打印选项中选择「另存为 PDF」")}const V=he(!1);async function v(){if(V.value){ie.showMessage("正在逐页导出幻灯片图片中，请稍候...",2e3);return}if(!M){ie.showMessage("请先在主编辑区打开幻灯片文档");return}V.value=!0;try{ie.showMessage("正在逐页导出幻灯片图片...",2e3);const $=await Ho(M,o==null?void 0:o.currentDocId,o),A=await vc(i,{title:$,onProgress:(P,Y)=>{ie.showMessage(`正在导出幻灯片图片 (${P} / ${Y})...`,1500)}});A.success?ie.showMessage(`🎉 成功导出 ${A.total||0} 张高清图片并保存为 ${$}.zip！`,4e3):ie.showMessage(`导出图片失败：${A.error||"未知异常"}`)}finally{V.value=!1}}async function K(){if(!M){ie.showMessage("请先在主编辑区打开幻灯片文档");return}ie.showMessage("正在导出当前幻灯片图片...",1500);const $=await Zs(i);if($.success&&$.dataUrl){const A=await Ho(M,o==null?void 0:o.currentDocId,o),P=a.value||1,G=(c.value||1)>1?`${A}-${P}.png`:`${A}.png`;Ba(G,$.dataUrl),ie.showMessage(`已下载当前页高清图片 (${G})`)}else ie.showMessage(`导出当前页图片失败：${$.error||"未知异常"}`)}async function H(){if(!M){ie.showMessage("请先在主编辑区打开幻灯片文档");return}ie.showMessage("正在复制当前幻灯片截图到剪贴板...",1500);const $=await Zs(i);if($.success&&$.dataUrl)if(await Dg($.dataUrl))ie.showMessage(`已成功将第 ${a.value||1} 页幻灯片复制到剪贴板！`);else{const P=await Ho(M,o==null?void 0:o.currentDocId,o),Y=a.value||1,Z=(c.value||1)>1?`${P}-${Y}.png`:`${P}.png`;Ba(Z,$.dataUrl),ie.showMessage(`剪贴板权限不可用，已自动下载为 ${Z}`)}else ie.showMessage(`复制失败：${$.error||"未知异常"}`)}return t({updateDocument($,A){x.value&&k.value&&A&&A!==k.value||(M=$,x.value&&!k.value&&(k.value=$.docId),c.value=$.slides.length,n.setDocId($.docId),n.updateSlidesIndex($.slides),i.updateSlides($.slides,{...$.config,hostThemeMode:Wo()},$.customThemeCss),o&&typeof o.updatePreviewTabHeader=="function"&&o.updatePreviewTabHeader("",$.docId))},navigateToBlock($){n.onCursorFocusBlock($)},isPinned:x,pinnedDocId:k}),($,A)=>(J(),X("div",{class:"spm-slides-preview-tab",onKeydown:C},[p("div",Hg,[p("div",Fg,[p("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s",disabled:a.value<=1,"aria-label":"上一页",onClick:U},[le(ue,{name:"chevron-left"})],8,jg),p("span",Ug,ve(a.value)+" / "+ve(c.value||1),1),p("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s",disabled:a.value>=c.value,"aria-label":"下一页",onClick:ne},[le(ue,{name:"chevron-right"})],8,Wg),p("button",{class:xe(["spm-icon-btn b3-tooltips b3-tooltips__s",{"is-primary":x.value}]),"aria-label":x.value?"已锁定当前文档（点击解除）："+k.value:"点击锁定当前文档（不随主编辑区切换）",onClick:B},[le(ue,{name:"pin"}),p("span",null,ve(x.value?"已锁定":"跟随"),1)],10,qg)]),p("div",Vg,[p("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"缩略图总览 (O)",onClick:L},[le(ue,{name:"layout-grid"})]),de(ct)("presenterMode")?(J(),X("button",{key:0,class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"双屏演讲者视图 (Presenter Mode ⌥M)",onClick:z},[le(ue,{name:"presenter"})])):Te("",!0),de(ct)("exportHtml")?(J(),X("button",{key:1,class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"导出单文件 HTML 演示包",onClick:se},[le(ue,{name:"export-html"})])):Te("",!0),de(ct)("exportPdf")?(J(),X("button",{key:2,class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"导出 16:9 PDF 演示讲义",onClick:D},[le(ue,{name:"export-pdf"})])):Te("",!0),de(ct)("exportImage")?(J(),X("div",Kg,[p("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"导出幻灯片为图片包 (ZIP)",onClick:v},[le(ue,{name:"export-image"})]),p("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s",style:{padding:"2px 2px","margin-left":"-4px"},"aria-label":"更多图片导出选项",onClick:A[0]||(A[0]=ro(P=>u.value=!u.value,["stop"]))},[le(ue,{name:"chevron-down"})]),u.value?(J(),X("div",Gg,[p("button",{class:"b3-menu__item",onClick:A[1]||(A[1]=P=>{v(),u.value=!1})},[...A[6]||(A[6]=[p("span",{class:"b3-menu__label"},"📦 导出全篇为图片包 (ZIP)",-1)])]),p("button",{class:"b3-menu__item",onClick:A[2]||(A[2]=P=>{K(),u.value=!1})},[...A[7]||(A[7]=[p("span",{class:"b3-menu__label"},"🖼️ 导出当前页为图片 (PNG)",-1)])]),p("button",{class:"b3-menu__item",onClick:A[3]||(A[3]=P=>{H(),u.value=!1})},[...A[8]||(A[8]=[p("span",{class:"b3-menu__label"},"📋 复制当前页至剪贴板",-1)])])])):Te("",!0)])):Te("",!0),p("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"重新编译并刷新",onClick:oe},[le(ue,{name:"refresh"})]),p("button",{class:"spm-icon-btn is-primary spm-btn-fullscreen b3-tooltips b3-tooltips__s","aria-label":"全屏放映",onClick:Ce},[le(ue,{name:"fullscreen"}),A[9]||(A[9]=p("span",{class:"spm-btn-fullscreen__label"},"全屏放映",-1))])])]),p("div",{ref_key:"fullscreenContainerRef",ref:s,class:"spm-slides-tab__viewport spm-slides-fullscreen-container",onWheel:q},[p("iframe",{ref_key:"sandboxIframeRef",ref:r,class:"spm-slides-tab__iframe",src:N.value,frameborder:"0",allow:"fullscreen; autoplay"},null,8,Yg),le(dm,{visible:f.value,"onUpdate:visible":A[4]||(A[4]=P=>f.value=P),"is-maximized":h.value,"onUpdate:isMaximized":A[5]||(A[5]=P=>h.value=P),title:y.value,onClose:ae},{default:Sl(()=>[d.value==="siyuan"&&b.value?(J(),Gt(Sm,{key:0,"block-id":b.value,title:y.value,plugin:de(o),onExternalJump:Se},null,8,["block-id","title","plugin"])):Te("",!0),g.value?Vt((J(),Gt(eg,{key:1,visible:f.value&&d.value==="web",url:m.value,title:y.value,onExternalJump:Se},null,8,["visible","url","title"])),[[Us,d.value==="web"]]):Te("",!0)]),_:1},8,["visible","is-maximized","title"]),Vt(p("div",{class:xe(["spm-jump-badge",{"is-invalid":T.value}])},ve(I.value),3),[[Us,I.value]])],544)],32))}}),Jg=uo(Zg,[["__scopeId","data-v-7d559c8a"]]);function xc(e){if(!e||e.length===0)return{maxStep:0,blockMap:new Map,idMap:new Map};const t=new Map,o=new Map,i=new Map;let n=0;const s=(r,a)=>{t.set(r,a);const c=r.id||r.blockId;c&&o.set(c,a)},l=e.filter(r=>r.slot!=="slot-divider-right");for(const r of l){if(r.parentContainerId&&r.parentClicks&&r.parentClicks.trim()!==""&&!i.has(r.parentContainerId)){const f=String(r.parentClicks).trim();if(/^\d+$/.test(f)){const h=parseInt(f,10);n=Math.max(n,h),i.set(r.parentContainerId,h)}else n+=1,i.set(r.parentContainerId,n)}if(!!!(r.clicks&&String(r.clicks).trim()!=="")){if(r.parentContainerId&&i.has(r.parentContainerId)){const f=i.get(r.parentContainerId);s(r,{type:"step",step:f})}else s(r,{type:"always"});continue}const c=String(r.clicks).trim();if(!c){n+=1,s(r,{type:"step",step:n});continue}if(c.startsWith("[")&&c.endsWith("]"))try{const f=JSON.parse(c);if(Array.isArray(f)&&f.length>=2){const h=Math.min(Number(f[0]),Number(f[1])),d=Math.max(Number(f[0]),Number(f[1]));if(!isNaN(h)&&!isNaN(d)){n=Math.max(n,d),s(r,{type:"range",min:h,max:d});continue}}}catch{}if(c.toLowerCase()==="hide"){n+=1,s(r,{type:"hide",step:n});continue}if(/^\+\d+$/.test(c)||c==="true"){const f=c==="true"?1:parseInt(c.slice(1),10)||1;n+=f,s(r,{type:"step",step:n});continue}if(/^-\d+$/.test(c)){const f=parseInt(c.slice(1),10)||1;n=Math.max(1,n-f),s(r,{type:"step",step:n});continue}if(/^\d+$/.test(c)){const f=parseInt(c,10);if(!isNaN(f)){n=Math.max(n,f),s(r,{type:"step",step:f});continue}}const u=parseInt(c,10);!isNaN(u)&&u>0?(n=Math.max(n,u),s(r,{type:"step",step:u})):(n+=1,s(r,{type:"step",step:n}))}return{maxStep:n,blockMap:t,idMap:o}}function Xg(e,t,o){if(!e)return"v-click-visible";const i=e.id||e.blockId,n=o.blockMap.get(e)||(i?o.idMap.get(i):null);return!n||n.type==="always"?"v-click-visible":n.type==="range"?t>=n.min&&t<=n.max?"v-click-visible":"v-click-hidden":n.type==="hide"?t<n.step?"v-click-visible":"v-click-hidden":n.type==="step"?t>=n.step?"v-click-visible":"v-click-hidden":"v-click-visible"}const Js=980;function Qg(e){if(!e)return 0;const o=xc(e.blocks||[]).maxStep||0,i=e.frontmatter||{},n=i.mask;if(n!=="down"&&n!=="right")return o;const s=Pd(i.maskRatio),r=i.maskInitial==="revealed"?Math.max(0,s.steps-1):s.steps;return Math.max(o,r)}function ey(e,t=Js){const o=(e||"16/9").trim();let i=16/9;if(o==="4/3"||o==="4:3")i=4/3;else if(o==="16/10"||o==="16:10")i=16/10;else if(o.includes("/")||o.includes(":")){const s=o.includes("/")?"/":":",l=o.split(s).map(r=>parseFloat(r.trim()));l.length===2&&l[0]>0&&l[1]>0&&!isNaN(l[0])&&!isNaN(l[1])&&(i=l[0]/l[1])}else{const s=parseFloat(o);!isNaN(s)&&s>.2&&s<5&&(i=s)}const n=Math.ceil(t/i);return{baseWidth:t,baseHeight:n,ratio:i}}function La(e,t,o=Js,i=552,n=16){const s=o>0?o:Js,l=i>0?i:552,r=Math.max(0,e-n),a=Math.max(0,t-n);if(r<=0||a<=0)return{scale:.36,boxWidth:Math.round(s*.36),boxHeight:Math.round(l*.36)};const c=Math.min(r/s,a/l),u=Math.max(.08,Math.min(1.5,Number(c.toFixed(4))));return{scale:u,boxWidth:Math.max(1,Math.round(s*u)),boxHeight:Math.max(1,Math.round(l*u))}}function ty(e){return{...e,frontmatter:{...e.frontmatter||{}},blocks:Array.isArray(e.blocks)?e.blocks.map(t=>({...t,attrs:t.attrs?{...t.attrs}:void 0,attributes:t.attributes?{...t.attributes}:void 0,motion:t.motion?{...t.motion}:void 0,children:Array.isArray(t.children)?t.children.map(o=>({...o,attrs:o.attrs?{...o.attrs}:void 0,attributes:o.attributes?{...o.attributes}:void 0})):void 0})):[]}}function Da(e,t){if(!e)return"";const o=ty(e),i=o.frontmatter||{},n=i.layout||"default",s=(t==null?void 0:t.config)||{};(n==="image-right"||n==="image-left")&&!i.image&&!i.background&&s.image&&(i.image=s.image);const l=typeof(t==null?void 0:t.currentStep)=="number",r=l?Math.max(0,t.currentStep):0,a=l?xc(o.blocks||[]):null,u=fc(o,{containerClassName:"slide-block",leftColClass:"pdf-col pdf-col--left two-cols-left",rightColClass:"pdf-col pdf-col--right two-cols-right",allSlides:(t==null?void 0:t.allSlides)||[],currentPageIndex:(t==null?void 0:t.pageIndex)||o.pageIndex||1,highlight:!0,blockClassResolver:a?k=>{if(Xg(k,r,a)==="v-click-hidden")return"presenter-v-click-pending";if(r>0){const T=k.id||k.blockId,w=a.blockMap.get(k)||(T?a.idMap.get(T):void 0);if((w==null?void 0:w.type)==="step"&&w.step===r||(w==null?void 0:w.type)==="range"&&w.min===r)return"presenter-v-click-active"}return""}:void 0}).replace(/<video\b([^>]*)>/gi,(k,I)=>{let T=I.replace(/\bcontrols\b/gi,"").trim();return/\bmuted\b/i.test(T)||(T+=" muted"),`<video ${T.trim()}>`}),f=i.spacing,h=f&&f!=="inherit"?f:s.spacing||"normal",d=["slide-content",`layout-${n}`,`spacing-${h}`,i.class||"",i.layoutClass||""].filter(Boolean).join(" "),b=[],m=(i.background||s.background||"").trim();if(m)if(/^(?:https?:\/\/|\/|data:|assets\/|\.\/assets\/)/i.test(m)){const k=m.startsWith("assets/")?`/${m}`:m.startsWith("./assets/")?m.slice(1):m;b.push(`background-image:url('${nt(k)}');background-size:cover;background-position:center;background-repeat:no-repeat;`)}else b.push(`background:${nt(m)};`);const y=typeof i.zoom=="number"?i.zoom:typeof i.zoom=="string"?parseFloat(i.zoom):1,g=!isNaN(y)&&y>0?y:1;g!==1&&b.push(`width:${(100/g).toFixed(2)}%;height:${(100/g).toFixed(2)}%;transform-origin:top left;transform:scale(${g});`);const x=b.length>0?` style="${b.join("")}"`:"";return`<div class="${nt(d)}"${x}>${u}</div>`}const oy={class:"presenter-header"},iy={class:"presenter-title-area"},ny={class:"presenter-brand"},sy={class:"header-pills"},ry={class:"pill pill-page"},ay={key:0,class:"pill pill-step"},ly={class:"header-toolbar"},cy={class:"timer-capsule"},dy={class:"timer-digits"},uy={class:"timer-actions"},fy=["aria-label"],py={class:"wall-clock b3-tooltips b3-tooltips__sw","aria-label":"系统当前时间"},hy={key:0,class:"presenter-grid"},my={class:"slide-panels"},gy={class:"panel-box current-slide-panel"},yy={class:"panel-header"},by={class:"panel-header-left"},vy={class:"panel-page-num"},ky={class:"panel-header-meta"},wy={key:0,class:"panel-step-pill"},xy={class:"panel-layout-pill"},Sy=["aria-label"],Cy=["data-theme","data-slides-theme","data-normalize-headings","data-hide-unordered-markers","data-hide-ordered-markers","innerHTML"],_y={key:1,class:"panel-fallback"},Iy=["aria-label"],$y={class:"panel-header"},Ty={class:"panel-header-left"},Ay={key:0,class:"panel-page-num"},My={class:"panel-header-meta"},Ey={key:0,class:"panel-end-pill"},By={key:1,class:"panel-layout-pill"},Ly=["aria-label"],Dy=["data-theme","data-slides-theme","data-normalize-headings","data-hide-unordered-markers","data-hide-ordered-markers","innerHTML"],Ny={key:1,class:"panel-fallback"},Oy={class:"notes-panel"},Py={class:"panel-header"},Ry={class:"panel-header-left"},zy={class:"notes-size-controls"},Hy=["disabled"],Fy={class:"notes-size-value"},jy=["disabled"],Uy={key:1,class:"presenter-empty"},Wy={class:"empty-icon-wrap"},qy={class:"empty-actions"},Vy={class:"presenter-actions"},Ky={class:"nav-btn-group"},Gy=["disabled"],Yy=["disabled"],Zy={class:"actions-center"},Jy={class:"center-meta"},Xy={class:"progress-pill"},Qy={class:"nav-btn-group"},eb=["aria-label"],tb={class:"step-dots-text"},ob=["disabled"],ib=["disabled"],nb=280,sb=15,rb=Ht({__name:"SlidesPresenterTab",setup(e,{expose:t}){const o=Zt("plugin"),i=Zt("sandboxBridge",new ss),n=he([]),s=he({}),l=he(1),r=he(0),a=he(0),c=he(0),u=ge(()=>n.value.length||a.value),f=he(null),h=he(null),d=he({width:0,height:0}),b=he({width:0,height:0}),m=he(Wo()),y=ge(()=>{var fe;return ey((fe=s.value)==null?void 0:fe.aspectRatio)}),g=ge(()=>{var fe;return((fe=s.value)==null?void 0:fe.theme)||"apple-basic"}),x=ge(()=>{var fe;return _r((fe=s.value)==null?void 0:fe.colorSchema,m.value)}),k=ge(()=>{var fe;return!!((fe=s.value)!=null&&fe.normalizeHeadingSizes)}),I=ge(()=>{var fe;return((fe=s.value)==null?void 0:fe.showUnorderedListMarkers)===!1}),T=ge(()=>{var fe;return((fe=s.value)==null?void 0:fe.showOrderedListMarkers)===!1}),w=ge(()=>La(d.value.width,d.value.height,y.value.baseWidth,y.value.baseHeight,14)),C=ge(()=>La(b.value.width,b.value.height,y.value.baseWidth,y.value.baseHeight,14));function L(){f.value&&(d.value={width:f.value.clientWidth,height:f.value.clientHeight}),h.value&&(b.value={width:h.value.clientWidth,height:h.value.clientHeight})}let R=null;function N(){typeof window>"u"||typeof window.ResizeObserver!="function"||(R||(R=new window.ResizeObserver(()=>{L()})),R.disconnect(),f.value&&R.observe(f.value),h.value&&R.observe(h.value))}Fo([f,h,u],()=>{Pn(()=>{N(),L()})},{flush:"post"});const F=he(0),E=he(!0);let O=null,S=Date.now(),W=0;const j=ge(()=>{const fe=String(Math.floor(F.value/60)).padStart(2,"0"),pe=String(F.value%60).padStart(2,"0");return`${fe}:${pe}`});function _(){if(E.value){const fe=W+(Date.now()-S);F.value=Math.floor(fe/1e3)}}function M(){E.value?(W+=Date.now()-S,E.value=!1):(S=Date.now(),E.value=!0,_())}function B(){S=Date.now(),W=0,F.value=0}const Q=he("");let q=null;function U(){const fe=new Date,pe=String(fe.getHours()).padStart(2,"0"),Qe=String(fe.getMinutes()).padStart(2,"0");Q.value=`${pe}:${Qe}`}const ne=ge(()=>n.value.length===0?null:n.value[l.value-1]||null),oe=ge(()=>l.value>=n.value.length?null:n.value[l.value]||null);function ae(fe){var At;const pe=fe==null?void 0:fe.frontmatter;if((pe==null?void 0:pe.colorSchema)==="light")return"light";if((pe==null?void 0:pe.colorSchema)==="dark")return"dark";if(typeof(pe==null?void 0:pe.class)=="string"){const lt=pe.class.split(/\s+/);if(lt.includes("light"))return"light";if(lt.includes("dark"))return"dark"}const Qe=(pe==null?void 0:pe.background)||((At=s.value)==null?void 0:At.background),at=sc(Qe);return at===!0?"light":at===!1?"dark":x.value}const Se=ge(()=>ae(ne.value)),$e=ge(()=>ae(oe.value)),ke=ge(()=>ne.value?Qg(ne.value):c.value),Ce=ge(()=>l.value>1||r.value>0),z=ge(()=>l.value<u.value||r.value<ke.value),se=ge(()=>Da(ne.value,{config:s.value,allSlides:n.value,pageIndex:l.value,currentStep:r.value})),D=ge(()=>Da(oe.value,{config:s.value,allSlides:n.value,pageIndex:l.value+1})),V=ge(()=>{var pe;if(!ne.value)return"无内容";const fe=(pe=ne.value.blocks)==null?void 0:pe[0];return(fe==null?void 0:fe.content)||(fe==null?void 0:fe.rawMarkdown)||`第 ${l.value} 页`});function v(fe){return(fe||[]).slice(1).map(pe=>(pe.content||pe.rawMarkdown||"").trim()).filter(pe=>pe&&!/^(image\s+)?assets\/\S*$/i.test(pe)&&!/^!\[[^\]]*\]\(assets\/[^)]*\)$/.test(pe)).join(" | ").slice(0,120)}const K=ge(()=>{var fe;return v((fe=ne.value)==null?void 0:fe.blocks)}),H=ge(()=>{var pe;if(!oe.value)return"演示结束";const fe=(pe=oe.value.blocks)==null?void 0:pe[0];return(fe==null?void 0:fe.content)||(fe==null?void 0:fe.rawMarkdown)||`第 ${l.value+1} 页`}),$=ge(()=>oe.value?v(oe.value.blocks):"这是最后一页"),A=ge(()=>{var fe;return((fe=ne.value)==null?void 0:fe.notes)||""}),P=he(20);function Y(){P.value<36&&(P.value+=2)}function G(){P.value>14&&(P.value-=2)}const Z=ge(()=>u.value<=1?100:Math.round(l.value/u.value*100));let ee=null;try{ee=new BroadcastChannel("siyuan-slides-sync"),ee.onmessage=fe=>{const pe=fe.data;if(pe&&(pe.type==="SYNC_PAGE"&&typeof pe.page=="number"&&(l.value=pe.page,r.value=typeof pe.step=="number"?Math.max(0,pe.step):0,typeof pe.maxStep=="number"&&(c.value=Math.max(0,pe.maxStep))),pe.type==="SYNC_SLIDES"&&Array.isArray(pe.slides)&&(n.value=pe.slides,pe.config&&typeof pe.config=="object"&&(s.value=pe.config)),pe.type==="REQUEST_SYNC"&&n.value.length>0))try{ee==null||ee.postMessage({type:"SYNC_SLIDES",slides:JSON.parse(JSON.stringify(n.value)),config:JSON.parse(JSON.stringify(s.value||{}))}),ee==null||ee.postMessage({type:"SYNC_PAGE",page:l.value,step:r.value,maxStep:ke.value})}catch{}}}catch{ee=null}function ce(fe,pe=0){const Qe=Number(fe)||1,at=Math.max(0,Number(pe)||0);i.navigatePage(Qe,at);try{ee==null||ee.postMessage({type:"SYNC_PAGE",page:Qe,step:at,maxStep:ke.value})}catch{}}function re(){if(r.value<ke.value){r.value++,ce(l.value,r.value);return}l.value<u.value&&(l.value++,r.value=0,ce(l.value,0))}function me(){if(r.value>0){r.value--,ce(l.value,r.value);return}l.value>1&&(l.value--,r.value=0,ce(l.value,0))}function _e(){l.value<u.value&&(l.value++,r.value=0,ce(l.value,0))}function we(){l.value>1&&(l.value--,r.value=0,ce(l.value,0))}function De(){l.value=1,r.value=0,B(),ce(1,0)}function He(){const fe=o;typeof(fe==null?void 0:fe.openBottomPreviewTab)=="function"&&fe.openBottomPreviewTab()}function Ge(){const fe=o;typeof(fe==null?void 0:fe.openStandalonePreviewWindow)=="function"&&fe.openStandalonePreviewWindow()}function rt(fe){var pe,Qe;if(!(fe.key===" "&&((Qe=(pe=fe.target)==null?void 0:pe.closest)!=null&&Qe.call(pe,"button")))){if(fe.shiftKey&&fe.key==="ArrowRight"||fe.key==="ArrowDown"){fe.preventDefault(),_e();return}if(fe.shiftKey&&fe.key==="ArrowLeft"||fe.key==="ArrowUp"){fe.preventDefault(),we();return}fe.key==="ArrowRight"||fe.key===" "||fe.key==="PageDown"?(fe.preventDefault(),re()):(fe.key==="ArrowLeft"||fe.key==="PageUp")&&(fe.preventDefault(),me())}}let Pe=0;function pt(fe){var at,At;if(Math.abs(fe.deltaY)<sb)return;const pe=(At=(at=fe.target)==null?void 0:at.closest)==null?void 0:At.call(at,".notes-content");if(pe){const lt=pe.scrollHeight-pe.clientHeight;if(lt>2&&(fe.deltaY>0&&pe.scrollTop<lt-1||fe.deltaY<0&&pe.scrollTop>1))return}const Qe=Date.now();Qe-Pe<nb||(Pe=Qe,fe.deltaY>0?re():me())}let tt=null,Ye=null;return oi(()=>{var pe;m.value=Wo(),Ye=rc(Qe=>{m.value=Qe}),S=Date.now(),W=0,O=window.setInterval(_,500),typeof document<"u"&&document.addEventListener("visibilitychange",_),U(),q=window.setInterval(U,1e3),tt=i.onSlideChanged((Qe,at,At,lt,fo)=>{l.value=Qe,at>0&&(a.value=at),typeof lt=="number"&&(r.value=Math.max(0,lt)),typeof fo=="number"&&(c.value=Math.max(0,fo))});try{ee==null||ee.postMessage({type:"REQUEST_SYNC"})}catch{}const fe=o==null?void 0:o.latestCompiledDoc;(pe=fe==null?void 0:fe.slides)!=null&&pe.length&&(n.value=fe.slides,fe.config&&(s.value=fe.config)),typeof window<"u"&&window.addEventListener("resize",L),Pn(()=>{N(),L()})}),sn(()=>{Ye&&(Ye(),Ye=null),O&&(window.clearInterval(O),O=null),typeof document<"u"&&document.removeEventListener("visibilitychange",_),q&&(window.clearInterval(q),q=null),tt&&tt(),typeof window<"u"&&window.removeEventListener("resize",L),R&&(R.disconnect(),R=null);try{ee==null||ee.close()}catch{}ee=null}),t({updateDocument(fe){var pe;(pe=fe==null?void 0:fe.slides)!=null&&pe.length&&(n.value=fe.slides),fe!=null&&fe.config&&(s.value=fe.config)}}),(fe,pe)=>{var Qe,at,At;return J(),X("div",{class:"spm-presenter-tab",tabindex:"0",onKeydown:rt,onWheel:pt},[p("header",oy,[p("div",iy,[p("div",ny,[le(ue,{name:"presenter",class:"brand-icon"}),pe[1]||(pe[1]=p("span",{class:"title-name"},"演讲者控制台",-1))]),p("div",sy,[p("span",ry,"P."+ve(l.value)+" / "+ve(u.value||1),1),ke.value>0?(J(),X("span",ay,[le(ue,{name:"step",class:"pill-icon"}),_t(" 步进 "+ve(r.value)+" / "+ve(ke.value),1)])):Te("",!0)])]),p("div",ly,[p("button",{class:"btn-tool b3-tooltips b3-tooltips__s","aria-label":"弹出大屏放映独立窗口 (16:9)",onClick:Ge},[le(ue,{name:"window"}),pe[2]||(pe[2]=p("span",{class:"btn-tool-label"},"独立放映",-1))]),p("div",cy,[le(ue,{name:"clock",class:"timer-icon"}),p("span",dy,ve(j.value),1),p("div",uy,[p("button",{class:"timer-btn b3-tooltips b3-tooltips__s","aria-label":E.value?"暂停计时":"继续计时",onClick:M},[le(ue,{name:E.value?"pause":"play"},null,8,["name"])],8,fy),p("button",{class:"timer-btn b3-tooltips b3-tooltips__s","aria-label":"重置计时",onClick:B},[le(ue,{name:"reset"})])])]),p("div",py,[p("span",null,ve(Q.value),1)])])]),u.value>0?(J(),X("main",hy,[p("section",my,[p("div",gy,[p("div",yy,[p("div",by,[pe[3]||(pe[3]=p("span",{class:"panel-tag is-current"},"当前放映",-1)),p("span",vy,"P."+ve(l.value),1)]),p("div",ky,[ke.value>0?(J(),X("span",wy," 步进 "+ve(r.value)+" / "+ve(ke.value),1)):Te("",!0),p("span",xy,ve(((at=(Qe=ne.value)==null?void 0:Qe.frontmatter)==null?void 0:at.layout)||"default"),1)])]),p("div",{ref_key:"currentPreviewRef",ref:f,class:"panel-preview","aria-label":V.value},[ne.value?(J(),X("div",{key:0,class:"presenter-thumb-box",style:so({width:w.value.boxWidth+"px",height:w.value.boxHeight+"px"})},[p("div",{class:xe(["presenter-thumb-viewport slide-viewport","slides-theme-"+g.value]),"data-theme":Se.value,"data-slides-theme":g.value,"data-normalize-headings":k.value?"true":"false","data-hide-unordered-markers":I.value?"true":"false","data-hide-ordered-markers":T.value?"true":"false",style:so({width:y.value.baseWidth+"px",height:y.value.baseHeight+"px",transform:"scale("+w.value.scale+")"}),innerHTML:se.value},null,14,Cy)],4)):(J(),X("div",_y,[p("h2",null,ve(V.value),1),p("p",null,ve(K.value),1)]))],8,Sy)]),p("div",{class:xe(["panel-box next-slide-panel",{"is-clickable":!!oe.value,"b3-tooltips b3-tooltips__n":!!oe.value}]),"aria-label":oe.value?"点击直接跳至下一页":"",onClick:pe[0]||(pe[0]=lt=>oe.value&&_e())},[p("div",$y,[p("div",Ty,[pe[4]||(pe[4]=p("span",{class:"panel-tag"},"下一页预告",-1)),l.value<u.value?(J(),X("span",Ay,"P."+ve(l.value+1),1)):Te("",!0)]),p("div",My,[l.value>=u.value?(J(),X("span",Ey,"已到尾页")):oe.value?(J(),X("span",By,ve(((At=oe.value.frontmatter)==null?void 0:At.layout)||"default"),1)):Te("",!0)])]),p("div",{ref_key:"nextPreviewRef",ref:h,class:"panel-preview panel-preview--dim","aria-label":H.value},[oe.value?(J(),X("div",{key:0,class:"presenter-thumb-box",style:so({width:C.value.boxWidth+"px",height:C.value.boxHeight+"px"})},[p("div",{class:xe(["presenter-thumb-viewport slide-viewport","slides-theme-"+g.value]),"data-theme":$e.value,"data-slides-theme":g.value,"data-normalize-headings":k.value?"true":"false","data-hide-unordered-markers":I.value?"true":"false","data-hide-ordered-markers":T.value?"true":"false",style:so({width:y.value.baseWidth+"px",height:y.value.baseHeight+"px",transform:"scale("+C.value.scale+")"}),innerHTML:D.value},null,14,Dy)],4)):(J(),X("div",Ny,[p("h2",null,ve(H.value),1),p("p",null,ve($.value),1)]))],8,Ly)],10,Iy)]),p("section",Oy,[p("div",Py,[p("div",Ry,[le(ue,{name:"notes",class:"panel-title-icon"}),pe[5]||(pe[5]=p("span",null,"讲稿备忘",-1))]),p("div",zy,[p("button",{class:"notes-btn b3-tooltips b3-tooltips__w","aria-label":"减小字体",disabled:P.value<=14,onClick:G},[le(ue,{name:"minus"})],8,Hy),p("span",Fy,ve(P.value)+"px",1),p("button",{class:"notes-btn b3-tooltips b3-tooltips__w","aria-label":"增大字体",disabled:P.value>=36,onClick:Y},[le(ue,{name:"plus"})],8,jy)])]),p("div",{class:xe(["notes-content",{"is-empty":!A.value}]),style:so({fontSize:P.value+"px"})},ve(A.value||"（本页未设置演讲者备忘录）"),7)])])):(J(),X("main",Uy,[p("div",Wy,[le(ue,{name:"refresh",class:"empty-icon"})]),pe[8]||(pe[8]=p("h2",null,"等待大屏放映数据",-1)),pe[9]||(pe[9]=p("p",null,"未检测到活跃的幻灯片数据，请先开启大屏放映端。",-1)),p("div",qy,[p("button",{class:"btn-empty-action b3-tooltips b3-tooltips__n","aria-label":"在思源中打开底部演示预览页签",onClick:He},[le(ue,{name:"presenter"}),pe[6]||(pe[6]=p("span",null,"打开大屏放映页签",-1))]),p("button",{class:"btn-empty-action btn-empty-action--popout b3-tooltips b3-tooltips__n","aria-label":"将放映端弹出为独立窗口 (16:9)",onClick:Ge},[le(ue,{name:"window"}),pe[7]||(pe[7]=p("span",null,"弹出独立放映窗口",-1))])])])),p("footer",Vy,[p("div",Ky,[p("button",{class:"btn-nav btn-nav--slide b3-tooltips b3-tooltips__ne",disabled:l.value<=1,"aria-label":"快速返回上一页 (Shift + ←)",onClick:we},[le(ue,{name:"chevrons-left"}),pe[10]||(pe[10]=p("span",null,"上一页",-1))],8,Gy),p("button",{class:"btn-nav btn-nav--step b3-tooltips b3-tooltips__n",disabled:!Ce.value,"aria-label":"回退一步 (←)",onClick:me},[le(ue,{name:"chevron-left"}),pe[11]||(pe[11]=p("span",null,"上一步",-1))],8,Yy)]),p("div",Zy,[p("div",Jy,[p("span",Xy,ve(Z.value)+"%",1)]),p("button",{class:"btn-restart b3-tooltips b3-tooltips__n","aria-label":"从第一页重新放映 (Home)",onClick:De},[le(ue,{name:"reset"}),pe[12]||(pe[12]=p("span",null,"重头放映",-1))])]),p("div",Qy,[ke.value>0?(J(),X("div",{key:0,class:"step-dots-bar b3-tooltips b3-tooltips__n","aria-label":`步进进度: ${r.value} / ${ke.value}`},[(J(!0),X(Ve,null,$t(ke.value,lt=>(J(),X("span",{key:lt,class:xe(["step-dot",{"is-active":lt<=r.value}])},null,2))),128)),p("span",tb,ve(r.value)+"/"+ve(ke.value),1)],8,eb)):Te("",!0),p("button",{class:"btn-nav btn-nav--step btn-nav--primary b3-tooltips b3-tooltips__n",disabled:!z.value,"aria-label":"触发下一步骤或进入下一页 (Space / →)",onClick:re},[pe[13]||(pe[13]=p("span",null,"下一步",-1)),le(ue,{name:"chevron-right"})],8,ob),p("button",{class:"btn-nav btn-nav--slide b3-tooltips b3-tooltips__nw",disabled:l.value>=u.value,"aria-label":"跳过本页剩余步骤，直接进入下一页 (Shift + →)",onClick:_e},[pe[14]||(pe[14]=p("span",null,"下一页",-1)),le(ue,{name:"chevrons-right"})],8,ib)])])],32)}}}),ab=uo(rb,[["__scopeId","data-v-7dc01574"]]),lb={class:"spm-layout-picker"},cb={class:"spm-layout-group__title"},db={class:"spm-layout-picker__grid"},ub=["title","onClick"],fb={class:"spm-layout-icon"},pb={class:"spm-layout-label"},hb=Ht({__name:"LayoutPicker",props:{modelValue:{}},emits:["update:modelValue","change"],setup(e,{emit:t}){const o=e,i=t,n=[{id:"columns",title:"内容分栏",items:[{name:"default",label:"标准",desc:"标题在上，内容自适应流式排版"},{name:"two-cols",label:"双栏",desc:"左右双栏对比展示，支持比例调节"},{name:"cols-header",label:"表头多栏",desc:"顶部通栏标题，下方自适应 2~N 栏"},{name:"clover",label:"四叶草",desc:"2x2 田字型四象限卡片布局"},{name:"timeline",label:"时间线",desc:"步骤流程、里程碑演进或时间轴"}]},{id:"visuals",title:"图文排版",items:[{name:"image-right",label:"图右",desc:"左侧文字内容，右侧全屏背景图"},{name:"image-left",label:"图左",desc:"左侧全屏背景图，右侧文字内容"}]},{id:"focus",title:"聚焦与强调",items:[{name:"cover",label:"封面",desc:"全屏居中大标题与副标题封面页"},{name:"fact",label:"大字报",desc:"核心数据或指标突出展示 (KPI看板)"},{name:"quote",label:"引言",desc:"名人名言、金句与右对齐出处"},{name:"intro",label:"介绍",desc:"演讲者头像与个人履历名片"},{name:"center",label:"居中",desc:"内容全屏垂直水平居中"}]}],s=ge(()=>n.map(a=>({...a,items:a.items.filter(c=>Bp(c.name))})).filter(a=>a.items.length>0));function l(a){return o.modelValue===a||a==="cols-header"&&(o.modelValue==="two-cols-header"||o.modelValue==="three-cols-header")||a==="timeline"&&o.modelValue==="steps"}function r(a){i("update:modelValue",a),i("change",a)}return(a,c)=>(J(),X("div",lb,[c[0]||(c[0]=p("div",{class:"spm-layout-picker__header"},"选择页面版式",-1)),(J(!0),X(Ve,null,$t(s.value,u=>(J(),X("div",{key:u.id,class:"spm-layout-group"},[p("div",cb,[p("span",null,ve(u.title),1)]),p("div",db,[(J(!0),X(Ve,null,$t(u.items,f=>(J(),X("div",{key:f.name,class:xe(["spm-layout-item",{active:l(f.name)}]),title:`${f.label}：${f.desc}`,onClick:h=>r(f.name)},[p("div",fb,[le(ue,{name:"layout-"+f.name},null,8,["name"])]),p("span",pb,ve(f.label),1)],10,ub))),128))])]))),128))]))}}),mb=uo(hb,[["__scopeId","data-v-2c17e7cf"]]),gb={key:0,class:"spm-transition-selector__header"},yb={class:"spm-transition-list"},bb=["onClick"],vb={class:"spm-transition-meta"},kb={class:"spm-transition-label"},wb={class:"spm-transition-preview-box"},xb=Ht({__name:"TransitionSelector",props:{modelValue:{},hideHeader:{type:Boolean},title:{}},emits:["update:modelValue","change"],setup(e,{emit:t}){const o=t,i=[{name:"slide-left",label:"向左滑入",desc:"向左滑入：页面从右侧向左平滑推入，最通用标准的横向幻灯片动效"},{name:"slide-right",label:"向右滑入",desc:"向右滑入：页面从左侧向右平滑推入，适合倒序回退或逆向章节叙述"},{name:"slide-up",label:"向上推入",desc:"向上推入：页面从底部向上平滑推入，适合纵向展开或纵深层级展示"},{name:"fade",label:"淡入淡出",desc:"淡入淡出：透明度平滑渐变过度，典雅柔和，适合学术长篇与沉浸叙事"},{name:"zoom",label:"缩放进入",desc:"缩放进入：页面由中心向外平滑放大，富有动感冲击力，适合聚焦重点"}];function n(s){o("update:modelValue",s),o("change",s)}return(s,l)=>(J(),X("div",{class:xe(["spm-transition-selector",{"spm-transition-selector--no-header":e.hideHeader}])},[e.hideHeader?Te("",!0):(J(),X("div",gb,ve(e.title||"转场动效"),1)),p("div",yb,[(J(),X(Ve,null,$t(i,r=>p("div",{key:r.name,class:xe(["spm-transition-item",{active:e.modelValue===r.name}]),onClick:a=>n(r.name)},[p("div",vb,[p("span",kb,ve(r.label),1)]),p("div",wb,[p("div",{class:xe(["spm-anim-cube","anim-"+r.name])},null,2)])],10,bb)),64))])],2))}}),Sc=uo(xb,[["__scopeId","data-v-b5051f69"]]),Sb={class:"spm-section spm-section--page"},Cb={class:"spm-section-header"},_b={key:0,class:"spm-card-control",style:{"border-left":"3px solid var(--b3-theme-primary)",background:"rgba(var(--b3-theme-primary-rgb, 66, 133, 244), 0.06)",padding:"8px 12px","margin-top":"6px"}},Ib={style:{display:"flex","align-items":"center","justify-content":"space-between",gap:"8px"}},$b={style:{"font-size":"11px",display:"flex","align-items":"center",gap:"6px",flex:"1"}},Tb={key:1,class:"spm-card-control"},Ab={class:"spm-control-header"},Mb={class:"spm-control-title-group"},Eb={class:"spm-control-title b3-tooltips b3-tooltips__se","aria-label":"设置各列横向空间占比，默认平均分配"},Bb={class:"spm-quick-chips"},Lb=["onClick"],Db={style:{display:"flex",gap:"6px","align-items":"center","margin-top":"6px"}},Nb=["value"],Ob=["aria-label"],Pb={key:1,class:"spm-icon-btn b3-tooltips b3-tooltips__sw",disabled:"",style:{opacity:"0.45",cursor:"not-allowed",padding:"0 8px",height:"26px","font-size":"11px","white-space":"nowrap","flex-shrink":"0"},"aria-label":"当前页未检测到调整过列宽的横向超级块"},Rb={key:0,style:{"margin-top":"6px","font-size":"11px",opacity:"0.85",display:"flex","align-items":"center",gap:"4px"}},zb={style:{background:"rgba(125, 125, 125, 0.15)",padding:"1px 4px","border-radius":"3px","font-weight":"bold"}},Hb={key:1,style:{"margin-top":"6px","font-size":"11px",opacity:"0.6",display:"flex","align-items":"center",gap:"4px"}},Fb={class:"spm-card-control"},jb={class:"spm-control-header"},Ub={class:"spm-control-title-group"},Wb={class:"spm-control-title b3-tooltips b3-tooltips__se","aria-label":"覆盖本页内衬、内容间隙与正文行距"},qb={class:"spm-segmented-group"},Vb={class:"spm-card-control"},Kb={class:"spm-control-header"},Gb={class:"spm-control-title-group"},Yb={class:"spm-control-title b3-tooltips b3-tooltips__se","aria-label":"随着点击操作分段展露正文内容"},Zb={class:"spm-segmented-group"},Jb={key:0,style:{"margin-top":"10px",display:"flex","flex-direction":"column",gap:"8px"}},Xb={style:{display:"flex","align-items":"center","justify-content":"space-between"}},Qb=["aria-label"],ev={class:"spm-quick-chips"},tv=["onClick"],ov=["value"],iv={style:{"font-size":"10.5px",opacity:"0.6","line-height":"1.35","margin-top":"-2px"}},nv={style:{display:"flex",gap:"8px","margin-top":"2px"}},sv={style:{flex:"1"}},rv={class:"spm-segmented-group"},av={style:{flex:"1"}},lv={class:"spm-segmented-group"},cv={key:2,class:"spm-card-control"},dv={class:"spm-control-header"},uv={class:"spm-control-title-group"},fv=["aria-label"],pv={class:"spm-quick-chips"},hv=["onClick"],mv=["value","placeholder"],gv={class:"spm-card-control"},yv={class:"spm-control-header"},bv={class:"spm-control-title-group"},vv={class:"spm-control-title b3-tooltips b3-tooltips__se","aria-label":"正文备注块驱动 · 仅演讲者视图可见"},kv={key:0,class:"spm-notes-header-actions"},wv=["disabled"],xv={key:0,class:"spm-btn-spinner"},Sv={key:0,class:"spm-note-loading-box"},Cv={key:1,class:"spm-note-status-box"},_v=["title"],Iv={class:"spm-action-grid",style:{"margin-top":"6px"}},$v={key:2,class:"spm-note-empty-box"},Tv={class:"spm-card-control"},Av={class:"spm-action-grid"},Mv=["disabled","aria-label"],Ev=Ht({__name:"PageInspectorSection",props:{pageLayout:{},pageTransition:{},pageSpacing:{},pageImage:{},pageNotes:{},pageIndex:{},pageLayoutRatio:{},pageMask:{},pageMaskRatio:{},pageMaskStyle:{},pageMaskInitial:{},detectedSbRatio:{},detectedSbInfo:{},canConvertToSuperBlock:{type:Boolean},isGeneratingNotes:{type:Boolean}},emits:["update:pageLayout","update:pageTransition","update:pageSpacing","update:pageImage","update:pageLayoutRatio","update:pageMask","update:pageMaskRatio","update:pageMaskStyle","update:pageMaskInitial","applySuperBlockLayout","resetSuperblockRatio","addNoteBlock","locateNoteBlock","generateNotes","openSetting","insertDividerAfter","deleteDivider","convertToSuperBlock"],setup(e,{emit:t}){const o=e,i=t,n=[{label:"1:1 (2步)",value:"1:1"},{label:"1:1:1 (3步)",value:"1:1:1"},{label:"1:2:1 (非等宽)",value:"1:2:1"},{label:"1:1:1:1 (4步)",value:"1:1:1:1"}],s=ge(()=>{const x=o.pageMask;return x==="clockwise"||x==="counter-clockwise"||x==="cw"||x==="ccw"}),l=ge(()=>s.value?"1:1:1:1":"1:1"),r=ge(()=>o.pageMaskRatio||l.value);function a(x){i("update:pageMask",x),(!o.pageMaskRatio||o.pageMaskRatio==="1:1")&&i("update:pageMaskRatio","1:1:1:1")}function c(x){i("update:pageMask",x),(!o.pageMaskRatio||o.pageMaskRatio==="1:1:1:1")&&i("update:pageMaskRatio","1:1")}const u=ge(()=>o.pageMask==="clockwise"||o.pageMask==="counter-clockwise"||o.pageMask==="cw"||o.pageMask==="ccw"?`时钟走时规则：
• 顺时针：左上 → 右上 → 右下 → 左下
• 逆时针：左上 → 左下 → 右下 → 右上
• 每次点击时针旋转 90° 并扇形扫开 1/4 象限，全部揭开后翻页`:`输入规则：
• 权重比例（项数决定步数）：如 1:1 (2步等分)、1:1:1 (3步等分)、1:2:1 (按权重累计分段)
• 绝对百分比：如 25:75:100 或 30:80 (指定每步展开的累计百分比)
• 每次点击或按空格/向右键展露下一段，全部揭开后翻页`),f=ge(()=>["two-cols","cols-header","two-cols-header","three-cols-header","image-left","image-right"].includes(o.pageLayout)),h=ge(()=>{var I,T;if(o.pageLayout==="two-cols-header"||o.pageLayout==="two-cols"||o.pageLayout==="image-left"||o.pageLayout==="image-right")return 2;if(o.pageLayout==="three-cols-header")return 3;const x=(o.pageLayoutRatio||"").trim();if(x.includes(":")){const w=x.split(":").filter(Boolean).length;if(w>=2&&w<=6)return w}const k=(o.detectedSbRatio||"").trim();if(k.includes(":")){const w=k.split(":").filter(Boolean).length;if(w>=2&&w<=6)return w}if((I=o.detectedSbInfo)!=null&&I.colCount&&o.detectedSbInfo.colCount>=2)return Math.min(o.detectedSbInfo.colCount,6);if((T=o.detectedSbInfo)!=null&&T.slots&&Array.isArray(o.detectedSbInfo.slots)){const w=o.detectedSbInfo.slots.length;if(w>=2&&w<=6)return w}return 2}),d=ge(()=>{const x=h.value;return x===3?[{label:"默认 1:1:1",value:""},{label:"1:2:1 (主中)",value:"1:2:1"},{label:"2:1:1 (主左)",value:"2:1:1"},{label:"1:1:2 (主右)",value:"1:1:2"},{label:"1:3:1",value:"1:3:1"}]:x===4?[{label:"默认 1:1:1:1",value:""},{label:"1:2:2:1",value:"1:2:2:1"},{label:"2:1:1:2",value:"2:1:1:2"}]:x===5?[{label:"默认 1:1:1:1:1",value:""}]:x===6?[{label:"默认 1:1:1:1:1:1",value:""}]:[{label:"默认 1:1",value:""},{label:"1:2",value:"1:2"},{label:"2:1",value:"2:1"},{label:"3:7",value:"3:7"},{label:"7:3",value:"7:3"},{label:"4:6",value:"4:6"},{label:"6:4",value:"6:4"}]}),b=ge(()=>o.pageLayoutRatio||"");function m(){const x=h.value||2,k=Array(x).fill("1").join(":");i("update:pageLayoutRatio",k),i("resetSuperblockRatio")}const y=ge(()=>{if(!o.pageNotes)return"";const x=o.pageNotes.replace(/[\r\n]+/g," ").trim();return x.length>50?x.slice(0,50)+"...":x}),g=[{label:"默认封面",value:"https://images.unsplash.com/photo-1506744038136-46273834b3fb?auto=format&fit=crop&w=1920&q=80"},{label:"清空配图",value:""}];return(x,k)=>(J(),X("div",Sb,[p("div",Cb,[p("span",null,"幻灯片页面设置"+ve(e.pageIndex?` (第 ${e.pageIndex} 页)`:""),1)]),le(mb,{"model-value":e.pageLayout,onChange:k[0]||(k[0]=I=>x.$emit("update:pageLayout",I))},null,8,["model-value"]),!f.value&&e.pageLayout!=="clover"&&e.detectedSbRatio?(J(),X("div",_b,[p("div",Ib,[p("div",$b,[le(ue,{name:"sparkles"}),p("span",null,[k[31]||(k[31]=_t("检测到本页横向超级块列宽比例：",-1)),p("b",null,ve(e.detectedSbRatio),1)])]),p("button",{class:"spm-btn-action b3-tooltips b3-tooltips__sw","aria-label":"一键应用超级块列宽并设为分栏",style:{padding:"2px 8px",height:"26px","font-size":"11px","flex-shrink":"0",background:"var(--b3-theme-primary)",color:"#fff",display:"inline-flex","align-items":"center",gap:"4px"},onClick:k[1]||(k[1]=I=>x.$emit("applySuperBlockLayout",e.detectedSbInfo||{recommendedLayout:"two-cols",ratio:e.detectedSbRatio}))},[le(ue,{name:"columns"}),k[32]||(k[32]=p("span",null,"设为分栏",-1))])])])):Te("",!0),f.value?(J(),X("div",Tb,[p("div",Ab,[p("div",Mb,[p("div",Eb,[le(ue,{name:"ratio"}),k[33]||(k[33]=p("span",null,"分栏比例",-1))])])]),p("div",Bb,[(J(!0),X(Ve,null,$t(d.value,I=>(J(),X("button",{key:I.value,class:xe(["spm-chip",{active:b.value===I.value}]),onClick:T=>x.$emit("update:pageLayoutRatio",I.value)},ve(I.label),11,Lb))),128))]),p("div",Db,[p("input",{value:e.pageLayoutRatio||"",class:"spm-input",style:{flex:"1","min-width":"0"},placeholder:"自定义比例（如 1:2 或 30:70，留空为默认）",onInput:k[2]||(k[2]=I=>x.$emit("update:pageLayoutRatio",I.target.value)),onChange:k[3]||(k[3]=I=>x.$emit("update:pageLayoutRatio",I.target.value))},null,40,Nb),e.detectedSbRatio?(J(),X("button",{key:0,class:"spm-icon-btn b3-tooltips b3-tooltips__sw","aria-label":`读取超级块列宽比例 (${e.detectedSbRatio}) 并应用`,style:{padding:"0 8px",height:"26px","font-size":"11px","white-space":"nowrap","flex-shrink":"0"},onClick:k[4]||(k[4]=I=>x.$emit("update:pageLayoutRatio",e.detectedSbRatio))},[le(ue,{name:"sparkles"}),k[34]||(k[34]=p("span",null,"读取",-1))],8,Ob)):(J(),X("button",Pb,[le(ue,{name:"sparkles"}),k[35]||(k[35]=p("span",null,"读取",-1))])),p("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__sw","aria-label":"重置为等宽平均分布",style:{padding:"0 8px",height:"26px","font-size":"11px","white-space":"nowrap","flex-shrink":"0"},onClick:m},[le(ue,{name:"reset"}),k[36]||(k[36]=p("span",null,"重置",-1))])]),e.detectedSbRatio?(J(),X("div",Rb,[le(ue,{name:"ratio"}),k[37]||(k[37]=p("span",null,"检测到思源超级块宽度：",-1)),p("code",zb,ve(e.detectedSbRatio),1)])):(J(),X("div",Hb,[le(ue,{name:"ratio"}),k[38]||(k[38]=p("span",null,"未检测到调宽超级块（默认各列平均分配）",-1))]))])):Te("",!0),p("div",Fb,[p("div",jb,[p("div",Ub,[p("div",Wb,[le(ue,{name:"ratio"}),k[39]||(k[39]=p("span",null,"页面间距",-1))])])]),p("div",qb,[p("button",{class:xe(["spm-segmented-item",{active:!e.pageSpacing||e.pageSpacing==="inherit"}]),onClick:k[5]||(k[5]=I=>x.$emit("update:pageSpacing","inherit"))}," 继承全局 ",2),p("button",{class:xe(["spm-segmented-item b3-tooltips b3-tooltips__s",{active:e.pageSpacing==="compact"}]),"aria-label":"紧凑排版：外衬 16/28px，块距 8px，行高 1.45",onClick:k[6]||(k[6]=I=>x.$emit("update:pageSpacing","compact"))}," 紧凑 ",2),p("button",{class:xe(["spm-segmented-item b3-tooltips b3-tooltips__s",{active:e.pageSpacing==="normal"}]),"aria-label":"标准排版：外衬 32/48px，块距 14px，行高 1.60",onClick:k[7]||(k[7]=I=>x.$emit("update:pageSpacing","normal"))}," 标准 ",2),p("button",{class:xe(["spm-segmented-item b3-tooltips b3-tooltips__sw",{active:e.pageSpacing==="loose"}]),"aria-label":"宽松排版：外衬 52/72px，块距 22px，行高 1.75",onClick:k[8]||(k[8]=I=>x.$emit("update:pageSpacing","loose"))}," 宽松 ",2)])]),le(Sc,{"model-value":e.pageTransition,onChange:k[9]||(k[9]=I=>x.$emit("update:pageTransition",I))},null,8,["model-value"]),p("div",Vb,[p("div",Kb,[p("div",Gb,[p("div",Yb,[le(ue,{name:"sparkles"}),k[40]||(k[40]=p("span",null,"页面动态蒙版",-1))])])]),p("div",Zb,[p("button",{class:xe(["spm-segmented-item",{active:!e.pageMask}]),onClick:k[10]||(k[10]=I=>x.$emit("update:pageMask",""))}," 关闭 ",2),p("button",{class:xe(["spm-segmented-item",{active:e.pageMask==="down"}]),onClick:k[11]||(k[11]=I=>c("down"))}," 从上至下 ",2),p("button",{class:xe(["spm-segmented-item",{active:e.pageMask==="right"}]),onClick:k[12]||(k[12]=I=>c("right"))}," 从左至右 ",2),p("button",{class:xe(["spm-segmented-item",{active:e.pageMask==="clockwise"||e.pageMask==="cw"}]),onClick:k[13]||(k[13]=I=>a("clockwise"))}," 顺时针 ↻ ",2),p("button",{class:xe(["spm-segmented-item",{active:e.pageMask==="counter-clockwise"||e.pageMask==="ccw"}]),onClick:k[14]||(k[14]=I=>a("counter-clockwise"))}," 逆时针 ↺ ",2)]),e.pageMask?(J(),X("div",Jb,[p("div",Xb,[k[42]||(k[42]=p("div",{style:{"font-size":"11px",opacity:"0.85","font-weight":"500"}},"展露比例 / 断点",-1)),p("span",{class:"b3-tooltips b3-tooltips__sw","aria-label":u.value,style:{cursor:"help",opacity:"0.75",display:"inline-flex","align-items":"center",gap:"3px","font-size":"11px"}},[le(ue,{name:"help"}),k[41]||(k[41]=p("span",null,"输入规则",-1))],8,Qb)]),p("div",ev,[(J(),X(Ve,null,$t(n,I=>p("button",{key:I.value,class:xe(["spm-chip",{active:r.value===I.value}]),onClick:T=>x.$emit("update:pageMaskRatio",I.value)},ve(I.label),11,tv)),64))]),p("input",{value:r.value,class:"spm-input",style:{width:"100%"},placeholder:"自定义比例或断点（如 1:2:1 或 25:75:100）",onInput:k[15]||(k[15]=I=>x.$emit("update:pageMaskRatio",I.target.value)),onChange:k[16]||(k[16]=I=>x.$emit("update:pageMaskRatio",I.target.value))},null,40,ov),p("div",iv,ve(e.pageMask==="clockwise"||e.pageMask==="counter-clockwise"||e.pageMask==="cw"||e.pageMask==="ccw"?"时钟走时蒙版：默认 4 步旋转展露（1:1:1:1，每步 25% 扇形面积）":"提示：支持权重比（如 1:2:1）或绝对断点（如 25:75:100），冒号项数决定点击步数"),1),p("div",nv,[p("div",sv,[k[43]||(k[43]=p("div",{style:{"font-size":"11px",opacity:"0.85","margin-bottom":"4px"}},"遮盖质感",-1)),p("div",rv,[p("button",{class:xe(["spm-segmented-item",{active:!e.pageMaskStyle||e.pageMaskStyle==="solid"}]),onClick:k[17]||(k[17]=I=>x.$emit("update:pageMaskStyle","solid"))}," 背景同色 ",2),p("button",{class:xe(["spm-segmented-item",{active:e.pageMaskStyle==="blur"}]),onClick:k[18]||(k[18]=I=>x.$emit("update:pageMaskStyle","blur"))}," 磨砂毛玻璃 ",2)])]),p("div",av,[k[44]||(k[44]=p("div",{style:{"font-size":"11px",opacity:"0.85","margin-bottom":"4px"}},"初始展露",-1)),p("div",lv,[p("button",{class:xe(["spm-segmented-item",{active:!e.pageMaskInitial||e.pageMaskInitial==="hidden"}]),onClick:k[19]||(k[19]=I=>x.$emit("update:pageMaskInitial","hidden"))}," 完全遮盖 ",2),p("button",{class:xe(["spm-segmented-item",{active:e.pageMaskInitial==="revealed"}]),onClick:k[20]||(k[20]=I=>x.$emit("update:pageMaskInitial","revealed"))}," 首段可见 ",2)])])])])):Te("",!0)]),e.pageLayout==="image-right"||e.pageLayout==="image-left"||e.pageLayout==="intro"||e.pageImage?(J(),X("div",cv,[p("div",dv,[p("div",uv,[p("div",{class:"spm-control-title b3-tooltips b3-tooltips__se","aria-label":e.pageLayout==="intro"?"演讲者个人头像或形象照 URL / 资源路径":"图文分栏或页面专属配图 URL / 资源路径"},[le(ue,{name:"image"}),p("span",null,ve(e.pageLayout==="intro"?"头像与配图":"页面图片"),1)],8,fv)])]),p("div",pv,[(J(),X(Ve,null,$t(g,I=>p("button",{key:I.value,class:xe(["spm-chip",{active:e.pageImage===I.value}]),onClick:T=>x.$emit("update:pageImage",I.value)},ve(I.label),11,hv)),64))]),p("input",{value:e.pageImage,class:"spm-input",placeholder:e.pageLayout==="intro"?"头像图片 URL 或思源本地图片路径 (如 assets/...)":"网络图片 URL 或思源本地资源路径 (如 assets/...)",onInput:k[21]||(k[21]=I=>x.$emit("update:pageImage",I.target.value)),onChange:k[22]||(k[22]=I=>x.$emit("update:pageImage",I.target.value))},null,40,mv)])):Te("",!0),p("div",gv,[p("div",yv,[p("div",bv,[p("div",vv,[le(ue,{name:"presenter"}),k[45]||(k[45]=p("span",null,"演讲者提词",-1))])]),de(ct)("aiScript")?(J(),X("div",kv,[p("button",{type:"button",class:xe(["spm-btn-primary b3-tooltips b3-tooltips__s",{"is-loading":e.isGeneratingNotes}]),disabled:e.isGeneratingNotes,"aria-label":"AI 自动生成本页讲稿提示块",onClick:k[23]||(k[23]=I=>x.$emit("generateNotes"))},[e.isGeneratingNotes?(J(),X("span",xv)):(J(),Gt(ue,{key:1,name:"sparkles"})),p("span",null,ve(e.isGeneratingNotes?"提炼中...":"AI 讲稿"),1)],10,wv),p("button",{type:"button",class:"spm-btn-icon b3-tooltips b3-tooltips__w","aria-label":"打开 AI 讲稿服务配置",onClick:k[24]||(k[24]=I=>x.$emit("openSetting"))},[le(ue,{name:"settings"})])])):Te("",!0)]),e.isGeneratingNotes?(J(),X("div",Sv,[...k[46]||(k[46]=[p("div",{class:"spm-loading-spinner"},null,-1),p("div",{class:"spm-loading-text"},[p("span",{class:"spm-loading-title"},"AI 正在提炼本页演讲提词..."),p("span",{class:"spm-loading-desc"},"根据幻灯片上下文智能编写口播要点，请稍候")],-1)])])):e.pageNotes?(J(),X("div",Cv,[k[49]||(k[49]=p("div",{class:"spm-note-status-badge"},[p("span",{class:"spm-badge-dot"}),p("span",null,"已配置正文讲稿")],-1)),p("div",{class:"spm-note-preview-text",title:e.pageNotes},ve(y.value),9,_v),p("div",Iv,[p("button",{class:"spm-btn-action b3-tooltips b3-tooltips__se","aria-label":"在正文编辑区定位并高亮此讲稿备注块",onClick:k[25]||(k[25]=I=>x.$emit("locateNoteBlock"))},[le(ue,{name:"search"}),k[47]||(k[47]=p("span",null,"定位讲稿块",-1))]),p("button",{class:"spm-btn-action b3-tooltips b3-tooltips__sw","aria-label":"在本页末尾追加新的讲稿提示块",onClick:k[26]||(k[26]=I=>x.$emit("addNoteBlock"))},[le(ue,{name:"insert-below"}),k[48]||(k[48]=p("span",null,"追加讲稿块",-1))])])])):(J(),X("div",$v,[k[51]||(k[51]=p("div",{class:"spm-note-empty-hint"},"本页暂无讲稿备注块",-1)),p("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s",style:{width:"100%","margin-top":"6px"},"aria-label":"在当前页末尾插入默认演讲备注提示块",onClick:k[27]||(k[27]=I=>x.$emit("addNoteBlock"))},[le(ue,{name:"insert-below"}),k[50]||(k[50]=p("span",null,"添加讲稿备注块",-1))])]))]),p("div",Tv,[k[55]||(k[55]=p("div",{class:"spm-control-header"},[p("div",{class:"spm-control-title-group"},[p("span",{class:"spm-control-title"},"快捷操作")])],-1)),p("div",Av,[p("button",{class:"spm-btn-action b3-tooltips b3-tooltips__se","aria-label":"在此分页符之后插入新的空白分页",onClick:k[28]||(k[28]=I=>x.$emit("insertDividerAfter"))},[le(ue,{name:"insert-below"}),k[52]||(k[52]=p("span",null,"插入新页",-1))]),p("button",{class:"spm-btn-action spm-btn-danger b3-tooltips b3-tooltips__sw","aria-label":"彻底删除当前分页符（合并前后页面）",onClick:k[29]||(k[29]=I=>x.$emit("deleteDivider"))},[le(ue,{name:"trash"}),k[53]||(k[53]=p("span",null,"删除此页",-1))]),p("button",{class:xe(["spm-btn-action b3-tooltips b3-tooltips__s",{"is-disabled":!e.canConvertToSuperBlock}]),style:{"grid-column":"1 / -1"},disabled:!e.canConvertToSuperBlock,"aria-label":e.canConvertToSuperBlock?"将当前选中的多个块或列表项合并为横向超级块":"请在编辑区选中多个块，或选中一个列表/列表项",onClick:k[30]||(k[30]=I=>x.$emit("convertToSuperBlock"))},[le(ue,{name:"columns"}),k[54]||(k[54]=p("span",null,"转为超级块",-1))],10,Mv)])])]))}}),Bv=uo(Ev,[["__scopeId","data-v-d619d441"]]),Lv={class:"spm-section spm-section--block"},Dv={key:0,class:"spm-card-control",style:{"border-left":"3px solid var(--b3-theme-primary)"}},Nv={class:"spm-control-header"},Ov={class:"spm-control-title-group"},Pv={class:"spm-control-title b3-tooltips b3-tooltips__se","aria-label":"读取思源超级块列宽并一键同步到幻灯片分栏"},Rv={style:{background:"var(--b3-theme-surface)",border:"1px solid var(--b3-theme-surface-lighter)","border-radius":"6px",padding:"10px","margin-bottom":"8px"}},zv={style:{display:"flex","align-items":"center","justify-content":"space-between","margin-bottom":"4px"}},Hv={style:{"font-size":"12px","font-weight":"500",display:"flex","align-items":"center",gap:"4px"}},Fv={key:0},jv={key:1},Uv={style:{background:"rgba(var(--b3-theme-primary-rgb, 59, 130, 246), 0.16)",color:"var(--b3-theme-primary)",border:"1px solid rgba(var(--b3-theme-primary-rgb, 59, 130, 246), 0.3)",padding:"2px 6px","border-radius":"4px","font-weight":"bold","font-size":"12px"}},Wv={style:{"font-size":"11px",opacity:"0.75","line-height":"1.4"}},qv={class:"spm-action-grid"},Vv={key:1,class:"spm-card-control"},Kv={class:"spm-control-header"},Gv={class:"spm-control-title-group"},Yv={class:"spm-control-title b3-tooltips b3-tooltips__se","aria-label":"设为幻灯片背景图或图文分栏配图"},Zv={class:"spm-quick-chips"},Jv={key:2,class:"spm-card-control"},Xv={class:"spm-control-header"},Qv={class:"spm-control-title-group"},e1={class:"spm-control-title b3-tooltips b3-tooltips__se","aria-label":"配置播放器控制条、自动播放与循环"},t1={class:"spm-video-settings-grid",style:{display:"grid","grid-template-columns":"1fr 1fr",gap:"8px","margin-top":"8px"}},o1={class:"spm-toggle-item",style:{display:"flex","align-items":"center","justify-content":"space-between",padding:"4px 6px",background:"rgba(125,125,125,0.06)","border-radius":"4px"}},i1={style:{"font-size":"11px",display:"inline-flex","align-items":"center",gap:"4px"}},n1=["aria-label"],s1=["checked"],r1={class:"spm-toggle-item",style:{display:"flex","align-items":"center","justify-content":"space-between",padding:"4px 6px",background:"rgba(125,125,125,0.06)","border-radius":"4px"}},a1={style:{"font-size":"11px",display:"inline-flex","align-items":"center",gap:"4px"}},l1=["aria-label"],c1=["checked"],d1={class:"spm-toggle-item",style:{display:"flex","align-items":"center","justify-content":"space-between",padding:"4px 6px",background:"rgba(125,125,125,0.06)","border-radius":"4px"}},u1={style:{"font-size":"11px",display:"inline-flex","align-items":"center",gap:"4px"}},f1=["aria-label"],p1=["checked"],h1={class:"spm-toggle-item",style:{display:"flex","align-items":"center","justify-content":"space-between",padding:"4px 6px",background:"rgba(125,125,125,0.06)","border-radius":"4px"}},m1={style:{"font-size":"11px",display:"inline-flex","align-items":"center",gap:"4px"}},g1=["aria-label"],y1=["checked"],b1={class:"spm-card-control"},v1={class:"spm-control-header"},k1={class:"spm-control-title-group"},w1={class:"spm-control-title b3-tooltips b3-tooltips__se","aria-label":"放映时按步长逐个呈现"},x1=["aria-label"],S1=["checked"],C1={key:0,class:"spm-quick-chips"},_1=["onClick"],I1={key:1,class:"spm-inherit-tip",style:{"margin-top":"6px",padding:"4px 8px",background:"rgba(var(--b3-theme-primary-rgb, 59, 130, 246), 0.08)","border-radius":"4px","font-size":"11px",opacity:"0.85",display:"flex","align-items":"center",gap:"4px"}},$1={class:"spm-card-control"},T1={class:"spm-control-header"},A1={class:"spm-control-title-group"},M1={class:"spm-control-title b3-tooltips b3-tooltips__se","aria-label":"为当前块添加平滑位移与渐入动画"},E1=["aria-label"],B1=["checked"],L1={key:0,class:"spm-quick-chips"},D1=["onClick"],N1={key:1,class:"spm-motion-details",style:{display:"flex","flex-direction":"column",gap:"4px","margin-top":"4px"}},O1={style:{display:"flex",gap:"8px","justify-content":"space-between","font-size":"11px",opacity:"0.8"}},P1={style:{display:"flex",gap:"6px"}},R1=["value"],z1=["value"],H1={key:3,class:"spm-card-control"},F1={class:"spm-control-header"},j1={class:"spm-control-title-group"},U1=["aria-label"],W1={class:"spm-segmented-group"},q1=["onClick"],V1={key:4,class:"spm-card-control"},K1={class:"spm-control-header"},G1={class:"spm-control-title-group"},Y1={class:"spm-control-title b3-tooltips b3-tooltips__se","aria-label":"翻页时动态聚光高亮特定行"},Z1={class:"spm-quick-chips"},J1=["onClick"],X1=["value"],Q1={key:5,class:"spm-card-control"},e0={class:"spm-control-header"},t0={class:"spm-control-title-group"},o0={class:"spm-control-title b3-tooltips b3-tooltips__se","aria-label":"超出限高自动竖向滚动，弱提示滚动条"},i0={class:"spm-quick-chips"},n0=["onClick"],s0=["value"],r0={class:"spm-card-control"},a0={class:"spm-action-grid"},l0=["aria-label"],c0=["disabled","aria-label"],d0=["disabled","aria-label"],u0=Ht({__name:"BlockInspectorSection",props:{elemClick:{},elemMotion:{},elemSlot:{},elemShikiLines:{},elemMaxHeight:{},isCodeBlock:{type:Boolean},isImage:{type:Boolean},isVideo:{type:Boolean},videoAutoplay:{type:Boolean},videoLoop:{type:Boolean},videoMuted:{type:Boolean},videoControls:{type:Boolean},hasBlockAttrs:{type:Boolean},isNote:{type:Boolean},imageRole:{},currentSlideLayout:{},isSuperBlock:{type:Boolean},parentElemClick:{},parentContainerSlot:{},parentContainerId:{},detectedSbInfo:{},canConvertToSuperBlock:{type:Boolean}},emits:["toggleNote","toggleElemClick","update:elemClick","update:elemMotion","update:elemSlot","update:elemShikiLines","update:elemMaxHeight","applySuperBlockLayout","applySuperBlockRatio","insertDividerBefore","insertDividerAfter","setTwoColsContrast","clearBlockAttrs","convertToSuperBlock","update:imageRole","toggleVideoAutoplay","toggleVideoLoop","toggleVideoMuted","toggleVideoControls"],setup(e,{emit:t}){const o=e,i=ge(()=>{const w=o.currentSlideLayout||"";return["col-1","col-2","col-3","col-4","col-5","col-6"].includes(o.elemSlot)?"cols-header":w}),n=ge(()=>{const w=i.value;return["two-cols","cols-header","two-cols-header","three-cols-header"].includes(w)}),s=ge(()=>{var C,L,R,N;if((C=o.detectedSbInfo)!=null&&C.colCount&&o.detectedSbInfo.colCount>=2)return Math.min(o.detectedSbInfo.colCount,6);const w=(L=o.elemSlot)==null?void 0:L.match(/^col-(\d+)$/);if(w){const F=parseInt(w[1],10);if(F>=2&&F<=6)return Math.max(F,3)}if(o.currentSlideLayout==="three-cols-header")return 3;if(o.currentSlideLayout==="two-cols-header"||o.currentSlideLayout==="two-cols")return 2;if((N=(R=o.detectedSbInfo)==null?void 0:R.ratio)!=null&&N.includes(":")){const F=o.detectedSbInfo.ratio.split(":").filter(Boolean);if(F.length>=2)return Math.min(F.length,6)}return 3}),l=ge(()=>{const w=i.value;return w==="cols-header"?"多栏插槽归属":w==="three-cols-header"?"三栏插槽归属":w==="two-cols-header"?"带表头双栏插槽":"多栏插槽归属"}),r=ge(()=>{const w=i.value;return w==="cols-header"?`在 cols-header 表头多栏（${s.value} 栏）中的内容块位置`:w==="three-cols-header"?"在 three-cols-header 版式中的内容块位置":w==="two-cols-header"?"在 two-cols-header 版式中的内容块位置":w==="two-cols"?"在 two-cols 双栏版式中的归属":"在当前分栏版式中的内容块位置"}),a=ge(()=>{const w=i.value;if(w==="two-cols")return[{value:"",label:"默认 (左)"},{value:"right",label:"右栏"}];if(w==="two-cols-header")return[{value:"",label:"默认"},{value:"header",label:"表头"},{value:"left",label:"左栏"},{value:"right",label:"右栏"}];if(w==="three-cols-header")return[{value:"",label:"默认"},{value:"header",label:"表头"},{value:"col-1",label:"第 1 栏"},{value:"col-2",label:"第 2 栏"},{value:"col-3",label:"第 3 栏"}];const C=s.value,L=[{value:"",label:"默认"},{value:"header",label:"表头"}];for(let R=1;R<=C;R++)L.push({value:`col-${R}`,label:`第 ${R} 栏`});return L});function c(w){const C=o.elemSlot||"";return w?C===w||w==="col-1"&&C==="left"||w==="col-2"&&C==="center"||w==="col-3"&&C==="right"&&s.value===3||w==="col-2"&&C==="right"&&s.value===2||w==="left"&&C==="col-1"||w==="right"&&(C==="col-2"||C==="col-3"):!C||C==="default"}const u=t,f=[{label:"上浮",value:"slide-up"},{label:"淡入",value:"fade-in"},{label:"下沉",value:"slide-down"},{label:"左滑",value:"slide-left"},{label:"右滑",value:"slide-right"},{label:"缩放",value:"zoom-in"},{label:"弹性",value:"bounce"}],h=ge(()=>{if(!o.elemMotion||o.elemMotion.trim()===""||o.elemMotion.trim()==="none")return null;try{const w=JSON.parse(o.elemMotion);if(typeof w=="object"&&w!==null)return{preset:w.preset||w.type||"slide-up",duration:typeof w.duration=="number"?w.duration:0,delay:typeof w.delay=="number"?w.delay:0}}catch{}return{preset:o.elemMotion.trim(),duration:0,delay:0}}),d=ge(()=>!!h.value),b=ge(()=>{var w;return((w=h.value)==null?void 0:w.preset)||"slide-up"}),m=ge(()=>{var w;return((w=h.value)==null?void 0:w.duration)||0}),y=ge(()=>{var w;return((w=h.value)==null?void 0:w.delay)||0});function g(){d.value?u("update:elemMotion",""):u("update:elemMotion","slide-up")}function x(w){T(w,m.value,y.value)}function k(w){T(b.value,w,y.value)}function I(w){T(b.value,m.value,w)}function T(w,C,L){if(!w||w==="none"){u("update:elemMotion","");return}if(!C&&!L){u("update:elemMotion",w);return}const R={preset:w};C>0&&(R.duration=C),L>0&&(R.delay=L),u("update:elemMotion",JSON.stringify(R))}return(w,C)=>{var L,R,N,F,E,O;return J(),X("div",Lv,[C[53]||(C[53]=p("div",{class:"spm-section-header"},[p("span",null,"元素动效与排版")],-1)),e.isSuperBlock||(L=e.detectedSbInfo)!=null&&L.hasSuperBlock?(J(),X("div",Dv,[p("div",Nv,[p("div",Ov,[p("div",Pv,[le(ue,{name:"ratio"}),C[24]||(C[24]=p("span",null,"超级块列宽与布局",-1))])])]),p("div",Rv,[p("div",zv,[p("div",Hv,[le(ue,{name:"ratio"}),(R=e.detectedSbInfo)!=null&&R.isCustomWidth?(J(),X("span",Fv,"已识别自定义列宽比例")):(J(),X("span",jv,"识别到 "+ve(((N=e.detectedSbInfo)==null?void 0:N.colCount)||2)+" 列超级块分栏",1))]),p("code",Uv,ve(((F=e.detectedSbInfo)==null?void 0:F.ratio)||"1:1"),1)]),p("div",Wv,ve((E=e.detectedSbInfo)!=null&&E.isCustomWidth?"检测到已调节子块宽度，可一键应用为当前页分栏比例。":"当前超级块子列为思源默认均宽，可在思源中拖动调节或直接应用。"),1)]),p("div",qv,[p("button",{class:"spm-btn-action b3-tooltips b3-tooltips__se","aria-label":"一键将当前页版式切换为对应双栏/三栏，并写入此列宽比例",style:{background:"rgba(var(--b3-theme-primary-rgb, 59, 130, 246), 0.16)",color:"var(--b3-theme-primary)","font-weight":"500",border:"1px solid rgba(var(--b3-theme-primary-rgb, 59, 130, 246), 0.3)"},onClick:C[0]||(C[0]=S=>w.$emit("applySuperBlockLayout",e.detectedSbInfo))},[le(ue,{name:"sparkles"}),C[25]||(C[25]=p("span",null,"应用版式与比例",-1))]),p("button",{class:"spm-btn-action b3-tooltips b3-tooltips__sw","aria-label":"仅将提取的比值写入当前页的分栏比例属性",onClick:C[1]||(C[1]=S=>{var W;return w.$emit("applySuperBlockRatio",((W=e.detectedSbInfo)==null?void 0:W.ratio)||"1:1")})},[le(ue,{name:"check"}),p("span",null,"应用比例 ("+ve(((O=e.detectedSbInfo)==null?void 0:O.ratio)||"1:1")+")",1)])])])):Te("",!0),e.isImage||e.imageRole?(J(),X("div",Vv,[p("div",Kv,[p("div",Gv,[p("div",Yv,[le(ue,{name:"image"}),C[26]||(C[26]=p("span",null,"图片角色与分栏",-1))])])]),p("div",Zv,[p("button",{class:xe(["spm-chip",{active:!e.imageRole}]),onClick:C[2]||(C[2]=S=>w.$emit("update:imageRole",""))}," 普通内容 ",2),p("button",{class:xe(["spm-chip",{active:e.imageRole==="background"}]),onClick:C[3]||(C[3]=S=>w.$emit("update:imageRole","background"))},[le(ue,{name:"image"}),C[27]||(C[27]=p("span",null,"背景图",-1))],2),p("button",{class:xe(["spm-chip",{active:e.imageRole==="image-left"}]),onClick:C[4]||(C[4]=S=>w.$emit("update:imageRole","image-left"))},[le(ue,{name:"image-left"}),C[28]||(C[28]=p("span",null,"图左",-1))],2),p("button",{class:xe(["spm-chip",{active:e.imageRole==="image-right"}]),onClick:C[5]||(C[5]=S=>w.$emit("update:imageRole","image-right"))},[le(ue,{name:"image-right"}),C[29]||(C[29]=p("span",null,"图右",-1))],2)])])):Te("",!0),e.isVideo?(J(),X("div",Jv,[p("div",Xv,[p("div",Qv,[p("div",e1,[le(ue,{name:"video"}),C[30]||(C[30]=p("span",null,"视频播放设置",-1))])])]),p("div",t1,[p("div",o1,[p("span",i1,[le(ue,{name:"sliders"}),C[31]||(C[31]=_t(" 控制条",-1))]),p("label",{class:"spm-switch b3-tooltips b3-tooltips__se","aria-label":e.videoControls?"关闭控制条":"开启控制条"},[p("input",{type:"checkbox",checked:!!e.videoControls,onChange:C[6]||(C[6]=S=>w.$emit("toggleVideoControls"))},null,40,s1),C[32]||(C[32]=p("span",{class:"spm-switch-slider"},null,-1))],8,n1)]),p("div",r1,[p("span",a1,[le(ue,{name:"video"}),C[33]||(C[33]=_t(" 自动播放",-1))]),p("label",{class:"spm-switch b3-tooltips b3-tooltips__sw","aria-label":e.videoAutoplay?"关闭自动播放":"开启自动播放"},[p("input",{type:"checkbox",checked:!!e.videoAutoplay,onChange:C[7]||(C[7]=S=>w.$emit("toggleVideoAutoplay"))},null,40,c1),C[34]||(C[34]=p("span",{class:"spm-switch-slider"},null,-1))],8,l1)]),p("div",d1,[p("span",u1,[le(ue,{name:"repeat"}),C[35]||(C[35]=_t(" 循环播放",-1))]),p("label",{class:"spm-switch b3-tooltips b3-tooltips__se","aria-label":e.videoLoop?"关闭循环播放":"开启循环播放"},[p("input",{type:"checkbox",checked:!!e.videoLoop,onChange:C[8]||(C[8]=S=>w.$emit("toggleVideoLoop"))},null,40,p1),C[36]||(C[36]=p("span",{class:"spm-switch-slider"},null,-1))],8,f1)]),p("div",h1,[p("span",m1,[le(ue,{name:"volume-x"}),C[37]||(C[37]=_t(" 静音播放",-1))]),p("label",{class:"spm-switch b3-tooltips b3-tooltips__sw","aria-label":e.videoMuted?"关闭静音":"开启静音"},[p("input",{type:"checkbox",checked:!!e.videoMuted,onChange:C[9]||(C[9]=S=>w.$emit("toggleVideoMuted"))},null,40,y1),C[38]||(C[38]=p("span",{class:"spm-switch-slider"},null,-1))],8,g1)])])])):Te("",!0),p("div",b1,[p("div",v1,[p("div",k1,[p("div",w1,[le(ue,{name:"step"}),C[39]||(C[39]=p("span",null,"逐步呈现",-1))])]),p("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":e.elemClick?"关闭逐步呈现":"开启逐步呈现 (+1)"},[p("input",{type:"checkbox",checked:!!e.elemClick,onChange:C[10]||(C[10]=S=>w.$emit("toggleElemClick"))},null,40,S1),C[40]||(C[40]=p("span",{class:"spm-switch-slider"},null,-1))],8,x1)]),e.elemClick?(J(),X("div",C1,[(J(),X(Ve,null,$t(["+1","1","2","hide"],S=>p("button",{key:S,class:xe(["spm-chip",{active:e.elemClick===S}]),onClick:W=>w.$emit("update:elemClick",S)},ve(S==="+1"?"顺延 (+1)":S==="hide"?"隐藏":"第 "+S+" 步"),11,_1)),64))])):e.parentElemClick?(J(),X("div",I1,[le(ue,{name:"check"}),C[41]||(C[41]=p("span",null,"未单独开启逐步呈现：当前跟随整栏同时出现",-1))])):Te("",!0)]),p("div",$1,[p("div",T1,[p("div",A1,[p("div",M1,[le(ue,{name:"motion"}),C[42]||(C[42]=p("span",null,"入场微动效",-1))])]),p("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":d.value?"关闭微动效":"开启微动效"},[p("input",{type:"checkbox",checked:d.value,onChange:g},null,40,B1),C[43]||(C[43]=p("span",{class:"spm-switch-slider"},null,-1))],8,E1)]),d.value?(J(),X("div",L1,[(J(),X(Ve,null,$t(f,S=>p("button",{key:S.value,class:xe(["spm-chip",{active:b.value===S.value}]),onClick:W=>x(S.value)},ve(S.label),11,D1)),64))])):Te("",!0),d.value?(J(),X("div",N1,[p("div",O1,[p("span",null,"时长: "+ve(m.value?m.value+"ms":"默认 (450ms)"),1),p("span",null,"延迟: "+ve(y.value?y.value+"ms":"0ms"),1)]),p("div",P1,[p("select",{class:"spm-select",style:{flex:"1"},value:m.value,onChange:C[11]||(C[11]=S=>k(Number(S.target.value)))},[...C[44]||(C[44]=[p("option",{value:0},"默认耗时",-1),p("option",{value:200},"极速 (200ms)",-1),p("option",{value:350},"较快 (350ms)",-1),p("option",{value:500},"平滑 (500ms)",-1),p("option",{value:800},"缓慢 (800ms)",-1)])],40,R1),p("select",{class:"spm-select",style:{flex:"1"},value:y.value,onChange:C[12]||(C[12]=S=>I(Number(S.target.value)))},[...C[45]||(C[45]=[p("option",{value:0},"无延迟",-1),p("option",{value:150},"延迟 150ms",-1),p("option",{value:300},"延迟 300ms",-1),p("option",{value:500},"延迟 500ms",-1)])],40,z1)])])):Te("",!0)]),n.value||e.elemSlot?(J(),X("div",H1,[p("div",F1,[p("div",j1,[p("div",{class:"spm-control-title b3-tooltips b3-tooltips__se","aria-label":r.value},[le(ue,{name:"columns"}),p("span",null,ve(l.value),1)],8,U1)])]),p("div",W1,[(J(!0),X(Ve,null,$t(a.value,S=>(J(),X("button",{key:S.value,class:xe(["spm-segmented-item",{active:c(S.value)}]),onClick:W=>w.$emit("update:elemSlot",S.value)},ve(S.label),11,q1))),128))])])):Te("",!0),e.isCodeBlock?(J(),X("div",V1,[p("div",K1,[p("div",G1,[p("div",Y1,[le(ue,{name:"code"}),C[46]||(C[46]=p("span",null,"代码逐行聚光",-1))])])]),p("div",Z1,[(J(),X(Ve,null,$t(["1-3","all","1|2|3","2-5"],S=>p("button",{key:S,class:xe(["spm-chip",{active:e.elemShikiLines===S}]),onClick:W=>w.$emit("update:elemShikiLines",S)},ve(S),11,J1)),64)),e.elemShikiLines?(J(),X("button",{key:0,class:"spm-chip spm-chip-clear",onClick:C[13]||(C[13]=S=>w.$emit("update:elemShikiLines",""))}," 清空 ")):Te("",!0)]),p("input",{value:e.elemShikiLines,class:"spm-input",placeholder:"自定义高亮区间，如 1-3|5|all",onInput:C[14]||(C[14]=S=>w.$emit("update:elemShikiLines",S.target.value)),onChange:C[15]||(C[15]=S=>w.$emit("update:elemShikiLines",S.target.value))},null,40,X1)])):Te("",!0),e.isCodeBlock?(J(),X("div",Q1,[p("div",e0,[p("div",t0,[p("div",o0,[le(ue,{name:"code"}),C[47]||(C[47]=p("span",null,"代码块限高",-1))])])]),p("div",i0,[(J(),X(Ve,null,$t(["240px","320px","400px","50%"],S=>p("button",{key:S,class:xe(["spm-chip",{active:e.elemMaxHeight===S||S==="50%"&&(e.elemMaxHeight==="50vh"||e.elemMaxHeight==="50%")}]),onClick:W=>w.$emit("update:elemMaxHeight",S)},ve(S),11,n0)),64)),e.elemMaxHeight?(J(),X("button",{key:0,class:"spm-chip spm-chip-clear",onClick:C[16]||(C[16]=S=>w.$emit("update:elemMaxHeight",""))}," 自适应 ")):Te("",!0)]),p("input",{value:e.elemMaxHeight,class:"spm-input",placeholder:"自适应高度，或输入 350px、50%",onInput:C[17]||(C[17]=S=>w.$emit("update:elemMaxHeight",S.target.value)),onChange:C[18]||(C[18]=S=>w.$emit("update:elemMaxHeight",S.target.value))},null,40,s0)])):Te("",!0),p("div",r0,[C[52]||(C[52]=p("div",{class:"spm-control-header"},[p("div",{class:"spm-control-title-group"},[p("span",{class:"spm-control-title"},"快捷操作")])],-1)),p("div",a0,[p("button",{class:"spm-btn-action b3-tooltips b3-tooltips__se","aria-label":"在当前块上方插入幻灯片分页线 (---)",onClick:C[19]||(C[19]=S=>w.$emit("insertDividerBefore"))},[le(ue,{name:"insert-above"}),C[48]||(C[48]=p("span",null,"上方分页",-1))]),p("button",{class:"spm-btn-action b3-tooltips b3-tooltips__sw","aria-label":"在当前块下方插入幻灯片分页线 (---)",onClick:C[20]||(C[20]=S=>w.$emit("insertDividerAfter"))},[le(ue,{name:"insert-below"}),C[49]||(C[49]=p("span",null,"下方分页",-1))]),p("button",{class:xe(["spm-btn-action b3-tooltips b3-tooltips__se",{"spm-btn-action--active":!!e.isNote}]),"aria-label":e.isNote?"取消当前块的演示讲稿备注":"将当前块设为演示讲稿备注",onClick:C[21]||(C[21]=S=>w.$emit("toggleNote"))},[le(ue,{name:"presenter"}),p("span",null,ve(e.isNote?"取消备注":"设为备注"),1)],10,l0),p("button",{class:xe(["spm-btn-action spm-btn-danger b3-tooltips b3-tooltips__sw",{"is-disabled":!e.hasBlockAttrs}]),disabled:!e.hasBlockAttrs,"aria-label":e.hasBlockAttrs?"一键移除本块所有 custom-slides 演示属性":"当前块无演示属性",onClick:C[22]||(C[22]=S=>w.$emit("clearBlockAttrs"))},[le(ue,{name:"broom"}),C[50]||(C[50]=p("span",null,"清除属性",-1))],10,c0),p("button",{class:xe(["spm-btn-action b3-tooltips b3-tooltips__s",{"is-disabled":!e.canConvertToSuperBlock}]),style:{"grid-column":"1 / -1"},disabled:!e.canConvertToSuperBlock,"aria-label":e.canConvertToSuperBlock?"将当前选中的多个块或列表项合并为横向超级块":"请在编辑区选中多个块，或选中一个列表/列表项",onClick:C[23]||(C[23]=S=>w.$emit("convertToSuperBlock"))},[le(ue,{name:"columns"}),C[51]||(C[51]=p("span",null,"转为超级块",-1))],10,d0)])])])}}}),f0={class:"spm-section spm-section--doc"},p0={class:"spm-card-control"},h0={class:"spm-control-header"},m0={class:"spm-control-title-group"},g0={class:"spm-control-title b3-tooltips b3-tooltips__se","aria-label":"全局幻灯片视觉设计范式"},y0={class:"spm-theme-card-grid"},b0=["aria-label","onClick"],v0={key:0,class:"spm-bg-swatch-check"},k0={class:"spm-theme-card-label"},w0={class:"spm-card-control"},x0={class:"spm-control-header"},S0={class:"spm-control-title-group"},C0={class:"spm-control-title b3-tooltips b3-tooltips__se","aria-label":"全篇幻灯片统一底色、微渐变或壁纸"},_0={class:"spm-bg-swatch-grid"},I0=["aria-label","onClick"],$0={key:0,class:"spm-bg-swatch-check"},T0={class:"spm-bg-swatch-label"},A0={class:"spm-bg-input-row"},M0=["value"],E0={class:"spm-card-control"},B0={class:"spm-control-header"},L0={class:"spm-control-title-group"},D0={class:"spm-control-title b3-tooltips b3-tooltips__se","aria-label":"演讲屏幕投影宽高比"},N0={class:"spm-segmented-group"},O0={class:"spm-card-control"},P0={class:"spm-control-header"},R0={class:"spm-control-title-group"},z0={class:"spm-control-title b3-tooltips b3-tooltips__se","aria-label":"内衬、内容间隙与正文行距预设"},H0={class:"spm-segmented-group"},F0={class:"spm-card-control"},j0={class:"spm-control-header"},U0={class:"spm-control-title-group"},W0={class:"spm-control-title b3-tooltips b3-tooltips__se","aria-label":"页面切换过渡动效（未单设转场的页面将继承此动效）"},q0={class:"spm-card-control"},V0={class:"spm-action-grid"},K0=["disabled"],G0=["disabled"],Y0=["disabled"],Z0=["disabled"],J0=["disabled"],X0=["aria-expanded"],Q0={class:"spm-advanced-toggle-label"},ek={key:0,class:"spm-advanced-content"},tk={class:"spm-card-control"},ok={class:"spm-control-header"},ik={class:"spm-control-title-group"},nk={class:"spm-control-title b3-tooltips b3-tooltips__se","aria-label":"点击文档/块链接以 Webview 抽屉呈现，支持外跳"},sk=["aria-label"],rk=["checked"],ak={key:0,class:"spm-control-body",style:{"margin-top":"8px"}},lk=["value"],ck={class:"spm-card-control"},dk={class:"spm-control-header"},uk={class:"spm-control-title-group"},fk={class:"spm-control-title b3-tooltips b3-tooltips__se","aria-label":"除封面外页首标题按 H2、多栏内首标题按 H3 大小展示"},pk=["aria-label"],hk=["checked"],mk={class:"spm-card-control"},gk={class:"spm-control-header"},yk={class:"spm-control-title-group"},bk={class:"spm-control-title b3-tooltips b3-tooltips__se","aria-label":"分别控制正文中无序列表圆点与有序列表数字序号的呈现"},vk={class:"spm-list-markers-toggles",style:{display:"flex",gap:"8px","margin-top":"8px"}},kk={class:"spm-marker-toggle-item",style:{flex:"1",display:"flex","align-items":"center","justify-content":"space-between",padding:"6px 10px",background:"var(--b3-theme-surface)",border:"1px solid var(--b3-border-color)","border-radius":"4px"}},wk=["aria-label"],xk=["checked"],Sk={class:"spm-marker-toggle-item",style:{flex:"1",display:"flex","align-items":"center","justify-content":"space-between",padding:"6px 10px",background:"var(--b3-theme-surface)",border:"1px solid var(--b3-border-color)","border-radius":"4px"}},Ck=["aria-label"],_k=["checked"],Ik={class:"spm-card-control"},$k={class:"spm-control-header"},Tk={class:"spm-control-title-group"},Ak={class:"spm-control-title b3-tooltips b3-tooltips__se","aria-label":"提炼演讲口播提词卡，支持 API 旋钮接管调度"},Mk={key:0,class:"api-switch-managed-tip",style:{"margin-top":"8px","background-color":"var(--b3-theme-primary-light, rgba(63, 81, 181, 0.08))",border:"1px solid var(--b3-theme-primary, rgba(63, 81, 181, 0.2))","border-radius":"6px",padding:"8px 10px","font-size":"11px","line-height":"1.4",color:"var(--b3-theme-on-background)"}},Ek={class:"spm-control-body",style:{"margin-top":"8px",display:"flex","flex-direction":"column",gap:"6px"}},Bk={style:{display:"flex","align-items":"center","justify-content":"space-between",gap:"8px"}},Lk=["value","disabled"],Dk={style:{display:"flex","align-items":"center","justify-content":"space-between",gap:"8px"}},Nk=["value","disabled"],Ok={style:{display:"flex","align-items":"center","justify-content":"space-between",gap:"8px"}},Pk=["value","disabled"],Rk=Ht({__name:"DocInspectorSection",props:{docTheme:{},docBackground:{},docAspectRatio:{},docDefaultTransition:{},docSpacing:{},isBatchProcessing:{type:Boolean}},emits:["update:docTheme","update:docBackground","update:docAspectRatio","update:docDefaultTransition","update:docSpacing","openBottomPreview","openPresenter","addOrIdentifyNotes","clearNotes","autoAnimate","clearAnimations","aiAutoSplit","clearDividers","exportHtml","exportPdf","openSetting"],setup(e,{emit:t}){const o=Zt("plugin"),i=jt,n=ns,s=he(!1);function l(){I("openSetting")}async function r(T){const w=i.aiConfig,C=vi({...w,model:T});mt({aiConfig:C}),o&&typeof o.saveGlobalSettings=="function"&&await o.saveGlobalSettings({aiConfig:C}),u(C)}async function a(T){const w=i.aiConfig,C=vi({...w,baseUrl:T});mt({aiConfig:C}),o&&typeof o.saveGlobalSettings=="function"&&await o.saveGlobalSettings({aiConfig:C}),u(C)}async function c(T){const w=i.aiConfig,C=vi({...w,apiKey:T});mt({aiConfig:C}),o&&typeof o.saveGlobalSettings=="function"&&await o.saveGlobalSettings({aiConfig:C}),u(C)}function u(T){typeof window<"u"&&window.siyuanApiSwitch&&(o!=null&&o.name)&&window.siyuanApiSwitch.updateLocalConfig(o.name,{provider:"custom",baseUrl:T.baseUrl,apiKey:T.apiKey,model:T.model,requestTimeoutSeconds:T.requestTimeoutSeconds,temperature:T.temperature,maxTokens:T.maxTokens})}const f=[{value:"apple-basic",label:"极简 apple",desc:"苹果发布会极简风：大字号、高对比度与极致留白，适合产品发布、方案演讲与纯粹视觉呈现"},{value:"tech",label:"科技 tech",desc:"科技风：现代无衬线排版、Emerald 绿青双色指示与清新代码语法高亮，通用汇报与技术分享首选"},{value:"seriph",label:"优雅 seriph",desc:"典雅学术衬线风：书卷学术质感、衬线字体典雅庄重，适合学术论文、人文讲座与深度阅读"}];function h(T){mt({enableWebServeJump:T}),o&&typeof o.saveGlobalSettings=="function"&&o.saveGlobalSettings({enableWebServeJump:T})}async function d(T){var w;mt({normalizeHeadingSizes:T}),o&&typeof o.saveGlobalSettings=="function"&&await o.saveGlobalSettings({normalizeHeadingSizes:T}),o&&typeof o.compileCurrentDocument=="function"&&o.compileCurrentDocument(o.currentDocId||((w=o.getActiveDocumentId)==null?void 0:w.call(o)))}async function b(T){var w;mt({showUnorderedListMarkers:T}),o&&typeof o.saveGlobalSettings=="function"&&await o.saveGlobalSettings({showUnorderedListMarkers:T}),o&&typeof o.compileCurrentDocument=="function"&&o.compileCurrentDocument(o.currentDocId||((w=o.getActiveDocumentId)==null?void 0:w.call(o)))}async function m(T){var w;mt({showOrderedListMarkers:T}),o&&typeof o.saveGlobalSettings=="function"&&await o.saveGlobalSettings({showOrderedListMarkers:T}),o&&typeof o.compileCurrentDocument=="function"&&o.compileCurrentDocument(o.currentDocId||((w=o.getActiveDocumentId)==null?void 0:w.call(o)))}function y(T){mt({webServeUrl:T})}function g(T){mt({webServeUrl:T}),o&&typeof o.saveGlobalSettings=="function"&&o.saveGlobalSettings({webServeUrl:T})}const x=[{label:"默认",value:"",mode:"auto",desc:"跟随当前幻灯片主题与明暗模式自适应底色"},{label:"极简白",value:"#ffffff",mode:"light",desc:"纯净高对比白底 (#ffffff)，自动切换深色文字"},{label:"暖羊皮",value:"#f5efe6",mode:"light",desc:"温润护眼米棕纸张底 (#f5efe6)，自动切换深色文字"},{label:"晴空薄荷",value:"linear-gradient(135deg, #e0f2fe 0%, #dcfce7 100%)",mode:"light",desc:"清透天蓝至薄荷微渐变，自动切换深色文字"},{label:"晨曦微光",value:"linear-gradient(135deg, #fef3c7 0%, #fce7f3 100%)",mode:"light",desc:"柔和暖金至淡樱微渐变，自动切换深色文字"},{label:"曜石炭黑",value:"#18181b",mode:"dark",desc:"中性深炭黑 (#18181b)，区别于默认深海蓝底"},{label:"松墨深绿",value:"#0d2621",mode:"dark",desc:"沉稳森林墨绿 (#0d2621)，自动切换浅色文字"},{label:"极光紫青",value:"linear-gradient(135deg, #1e1b4b 0%, #0f3d4c 100%)",mode:"dark",desc:"深邃靛紫至极光青渐变，自动切换浅色文字"},{label:"深空靛蓝",value:"linear-gradient(135deg, #172554 0%, #312e81 100%)",mode:"dark",desc:"科技深空蓝至暮色紫渐变，自动切换浅色文字"}];function k(T){const w=(T||"").trim();return w?/^(?:https?:\/\/|\/|data:|assets\/|\.\/assets\/)/i.test(w)?{backgroundImage:`url("${w.startsWith("assets/")?`/${w}`:w.startsWith("./assets/")?w.slice(1):w}")`,backgroundSize:"cover",backgroundPosition:"center"}:{background:w}:{background:"linear-gradient(135deg, #f8fafc 50%, #090d16 50%)"}}const I=t;return(T,w)=>(J(),X("div",f0,[w[65]||(w[65]=p("div",{class:"spm-section-header"},[p("span",null,"全局演示配置")],-1)),p("div",p0,[p("div",h0,[p("div",m0,[p("div",g0,[le(ue,{name:"palette"}),w[32]||(w[32]=p("span",null,"幻灯片主题",-1))])])]),p("div",y0,[(J(),X(Ve,null,$t(f,(C,L)=>p("button",{key:C.value,type:"button",class:xe(["spm-theme-card b3-tooltips",["is-"+C.value,L===0?"b3-tooltips__ne":L===f.length-1?"b3-tooltips__nw":"b3-tooltips__n",{active:e.docTheme===C.value}]]),"aria-label":C.desc,onClick:R=>T.$emit("update:docTheme",C.value)},[p("span",{class:xe(["spm-theme-card-preview","theme-preview--"+C.value]),"aria-hidden":"true"},[w[33]||(w[33]=ht('<span class="spm-theme-card-canvas"><span class="spm-theme-card-title">Aa</span><span class="spm-theme-card-lines"><span class="spm-theme-card-line is-primary"></span><span class="spm-theme-card-line is-secondary"></span></span></span>',1)),e.docTheme===C.value?(J(),X("span",v0,"✓")):Te("",!0)],2),p("span",k0,ve(C.label),1)],10,b0)),64))])]),p("div",w0,[p("div",x0,[p("div",S0,[p("div",C0,[le(ue,{name:"palette"}),w[34]||(w[34]=p("span",null,"演示背景",-1))])])]),p("div",_0,[(J(),X(Ve,null,$t(x,C=>p("button",{key:C.value||"__default__",type:"button",class:xe(["spm-bg-swatch b3-tooltips b3-tooltips__n",{active:(e.docBackground||"")===C.value,"is-default":!C.value}]),"aria-label":C.desc,onClick:L=>T.$emit("update:docBackground",C.value)},[p("span",{class:"spm-bg-swatch-preview",style:so(k(C.value))},[p("span",{class:xe(["spm-bg-swatch-aa","is-"+C.mode])},"Aa",2),(e.docBackground||"")===C.value?(J(),X("span",$0,"✓")):Te("",!0)],4),p("span",T0,ve(C.label),1)],10,I0)),64))]),p("div",A0,[p("span",{class:"spm-bg-input-preview",style:so(k(e.docBackground||"")),"aria-hidden":"true"},null,4),p("input",{value:e.docBackground||"",class:"spm-input spm-bg-input",placeholder:"自定义：#hex / gradient / assets/...",onInput:w[0]||(w[0]=C=>T.$emit("update:docBackground",C.target.value)),onChange:w[1]||(w[1]=C=>T.$emit("update:docBackground",C.target.value))},null,40,M0),e.docBackground?(J(),X("button",{key:0,type:"button",class:"spm-bg-input-clear b3-tooltips b3-tooltips__nw","aria-label":"清除并恢复默认背景",onClick:w[2]||(w[2]=C=>T.$emit("update:docBackground",""))}," ✕ ")):Te("",!0)])]),p("div",E0,[p("div",B0,[p("div",L0,[p("div",D0,[le(ue,{name:"ratio"}),w[35]||(w[35]=p("span",null,"画幅比例",-1))])])]),p("div",N0,[p("button",{class:xe(["spm-segmented-item",{active:e.docAspectRatio==="16/9"}]),onClick:w[3]||(w[3]=C=>T.$emit("update:docAspectRatio","16/9"))}," 16 : 9 (宽屏) ",2),p("button",{class:xe(["spm-segmented-item",{active:e.docAspectRatio==="4/3"}]),onClick:w[4]||(w[4]=C=>T.$emit("update:docAspectRatio","4/3"))}," 4 : 3 (标屏) ",2),p("button",{class:xe(["spm-segmented-item",{active:e.docAspectRatio==="16/10"}]),onClick:w[5]||(w[5]=C=>T.$emit("update:docAspectRatio","16/10"))}," 16 : 10 ",2)])]),p("div",O0,[p("div",P0,[p("div",R0,[p("div",z0,[le(ue,{name:"ratio"}),w[36]||(w[36]=p("span",null,"间距风格",-1))])])]),p("div",H0,[p("button",{class:xe(["spm-segmented-item b3-tooltips b3-tooltips__se",{active:(e.docSpacing||"normal")==="compact"}]),"aria-label":"紧凑排版：外衬 16/28px，块距 8px，行高 1.45",onClick:w[6]||(w[6]=C=>T.$emit("update:docSpacing","compact"))}," 紧凑 ",2),p("button",{class:xe(["spm-segmented-item b3-tooltips b3-tooltips__s",{active:(e.docSpacing||"normal")==="normal"}]),"aria-label":"标准排版：外衬 32/48px，块距 14px，行高 1.60（推荐默认）",onClick:w[7]||(w[7]=C=>T.$emit("update:docSpacing","normal"))}," 标准 ",2),p("button",{class:xe(["spm-segmented-item b3-tooltips b3-tooltips__sw",{active:(e.docSpacing||"normal")==="loose"}]),"aria-label":"宽松排版：外衬 52/72px，块距 22px，行高 1.75",onClick:w[8]||(w[8]=C=>T.$emit("update:docSpacing","loose"))}," 宽松 ",2)])]),p("div",F0,[p("div",j0,[p("div",U0,[p("div",W0,[le(ue,{name:"transition"}),w[37]||(w[37]=p("span",null,"全局默认转场",-1))])])]),le(Sc,{"model-value":e.docDefaultTransition,"hide-header":!0,onChange:w[9]||(w[9]=C=>T.$emit("update:docDefaultTransition",C))},null,8,["model-value"])]),p("div",q0,[w[48]||(w[48]=p("div",{class:"spm-control-header"},[p("div",{class:"spm-control-title-group"},[p("span",{class:"spm-control-title"},"演示全局操作")])],-1)),p("div",V0,[p("button",{class:"spm-btn-action b3-tooltips b3-tooltips__se","aria-label":"在当前文档下方开启分屏同步预览 (Alt+P)",onClick:w[10]||(w[10]=C=>T.$emit("openBottomPreview"))},[le(ue,{name:"split-preview"}),w[38]||(w[38]=p("span",null,"分屏预览",-1))]),de(ct)("presenterMode")?(J(),X("button",{key:0,class:"spm-btn-action b3-tooltips b3-tooltips__sw","aria-label":"打开双屏演讲者控制台视窗 (Alt+M)",onClick:w[11]||(w[11]=C=>T.$emit("openPresenter"))},[le(ue,{name:"presenter"}),w[39]||(w[39]=p("span",null,"演讲者视图",-1))])):Te("",!0),de(ct)("smartSplit")&&de(ct)("aiScript")?(J(),X("button",{key:1,class:"spm-btn-action b3-tooltips b3-tooltips__se","aria-label":"智能分析长文本大纲与篇幅，自动插入分页线",onClick:w[12]||(w[12]=C=>T.$emit("aiAutoSplit"))},[le(ue,{name:"sparkles"}),w[40]||(w[40]=p("span",null,"智能分页",-1))])):Te("",!0),de(ct)("smartSplit")&&de(ct)("aiScript")?(J(),X("button",{key:2,class:"spm-btn-action spm-btn-danger b3-tooltips b3-tooltips__sw","aria-label":"一键清除当前文档中的所有幻灯片分页线（需二次确认）",disabled:e.isBatchProcessing,onClick:w[13]||(w[13]=C=>T.$emit("clearDividers"))},[le(ue,{name:"trash"}),w[41]||(w[41]=p("span",null,"清除分页",-1))],8,K0)):Te("",!0),de(ct)("smartAnimation")?(J(),X("button",{key:3,class:"spm-btn-action b3-tooltips b3-tooltips__se","aria-label":"自动为正文各页标题及首块之外的后续内容块配置顺延 (+1) 逐步呈现动效",disabled:e.isBatchProcessing,onClick:w[14]||(w[14]=C=>T.$emit("autoAnimate"))},[le(ue,{name:"step"}),w[42]||(w[42]=p("span",null,"智能动效",-1))],8,G0)):Te("",!0),de(ct)("smartAnimation")?(J(),X("button",{key:4,class:"spm-btn-action spm-btn-danger b3-tooltips b3-tooltips__sw","aria-label":"清除所有页面内容块的逐步显现与入场微动效配置（需二次确认）",disabled:e.isBatchProcessing,onClick:w[15]||(w[15]=C=>T.$emit("clearAnimations"))},[le(ue,{name:"trash"}),w[43]||(w[43]=p("span",null,"清除动效",-1))],8,Y0)):Te("",!0),de(ct)("speakerNotesBlocks")?(J(),X("button",{key:5,class:"spm-btn-action b3-tooltips b3-tooltips__se","aria-label":"识别已有候选讲稿并为空白页新增默认讲稿块（不会重复添加）",disabled:e.isBatchProcessing,onClick:w[16]||(w[16]=C=>T.$emit("addOrIdentifyNotes"))},[le(ue,{name:"notes"}),w[44]||(w[44]=p("span",null,"增加讲稿块",-1))],8,Z0)):Te("",!0),de(ct)("speakerNotesBlocks")?(J(),X("button",{key:6,class:"spm-btn-action spm-btn-danger b3-tooltips b3-tooltips__sw","aria-label":"物理删除文档中所有页面的全部讲稿备注块（需二次确认）",disabled:e.isBatchProcessing,onClick:w[17]||(w[17]=C=>T.$emit("clearNotes"))},[le(ue,{name:"trash"}),w[45]||(w[45]=p("span",null,"清除讲稿块",-1))],8,J0)):Te("",!0),de(ct)("exportHtml")?(J(),X("button",{key:7,class:"spm-btn-action b3-tooltips b3-tooltips__se","aria-label":"打包导出离线单文件 HTML 幻灯片",onClick:w[18]||(w[18]=C=>T.$emit("exportHtml"))},[le(ue,{name:"export-html"}),w[46]||(w[46]=p("span",null,"导出 HTML",-1))])):Te("",!0),de(ct)("exportPdf")?(J(),X("button",{key:8,class:"spm-btn-action b3-tooltips b3-tooltips__sw","aria-label":"打印生成 16:9 高清演示 PDF 讲义",onClick:w[19]||(w[19]=C=>T.$emit("exportPdf"))},[le(ue,{name:"export-pdf"}),w[47]||(w[47]=p("span",null,"导出 PDF",-1))])):Te("",!0)])]),p("div",{class:xe(["spm-advanced-menu",{"is-expanded":s.value}])},[p("button",{type:"button",class:"spm-advanced-toggle","aria-expanded":s.value,onClick:w[20]||(w[20]=C=>s.value=!s.value)},[p("span",Q0,[le(ue,{name:"settings"}),w[49]||(w[49]=p("span",null,"高级设置",-1))]),le(ue,{name:"chevron-right",class:"spm-advanced-chevron"})],8,X0),s.value?(J(),X("div",ek,[p("div",tk,[p("div",ok,[p("div",ik,[p("div",nk,[le(ue,{name:"external-link"}),w[50]||(w[50]=p("span",null,"本地网络伺服预览",-1))])]),p("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":de(i).enableWebServeJump?"关闭本地网络伺服预览":"开启本地网络伺服预览"},[p("input",{type:"checkbox",checked:de(i).enableWebServeJump,onChange:w[21]||(w[21]=C=>h(C.target.checked))},null,40,rk),w[51]||(w[51]=p("span",{class:"spm-switch-slider"},null,-1))],8,sk)]),de(i).enableWebServeJump?(J(),X("div",ak,[p("input",{value:de(i).webServeUrl,class:"spm-input",placeholder:"http://127.0.0.1:6806",spellcheck:"false",onKeydown:w[22]||(w[22]=ro(()=>{},["stop"])),onKeyup:w[23]||(w[23]=ro(()=>{},["stop"])),onInput:w[24]||(w[24]=C=>y(C.target.value)),onChange:w[25]||(w[25]=C=>g(C.target.value))},null,40,lk)])):Te("",!0)]),p("div",ck,[p("div",dk,[p("div",uk,[p("div",fk,[le(ue,{name:"type"}),w[52]||(w[52]=p("span",null,"固定特定标题大小",-1))])]),p("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":de(i).normalizeHeadingSizes?"关闭固定特定标题大小":"开启固定特定标题大小"},[p("input",{type:"checkbox",checked:de(i).normalizeHeadingSizes,onChange:w[26]||(w[26]=C=>d(C.target.checked))},null,40,hk),w[53]||(w[53]=p("span",{class:"spm-switch-slider"},null,-1))],8,pk)])]),p("div",mk,[p("div",gk,[p("div",yk,[p("div",bk,[le(ue,{name:"list"}),w[54]||(w[54]=p("span",null,"列表前缀标记",-1))])])]),p("div",vk,[p("div",kk,[w[56]||(w[56]=p("span",{style:{"font-size":"12px",color:"var(--b3-theme-on-surface)"}},"无序圆点",-1)),p("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":de(i).showUnorderedListMarkers?"关闭无序列表圆点显示":"开启无序列表圆点显示"},[p("input",{type:"checkbox",checked:de(i).showUnorderedListMarkers,onChange:w[27]||(w[27]=C=>b(C.target.checked))},null,40,xk),w[55]||(w[55]=p("span",{class:"spm-switch-slider"},null,-1))],8,wk)]),p("div",Sk,[w[58]||(w[58]=p("span",{style:{"font-size":"12px",color:"var(--b3-theme-on-surface)"}},"有序序号",-1)),p("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":de(i).showOrderedListMarkers?"关闭有序列表序号显示":"开启有序列表序号显示"},[p("input",{type:"checkbox",checked:de(i).showOrderedListMarkers,onChange:w[28]||(w[28]=C=>m(C.target.checked))},null,40,_k),w[57]||(w[57]=p("span",{class:"spm-switch-slider"},null,-1))],8,Ck)])])]),p("div",Ik,[p("div",$k,[p("div",Tk,[p("div",Ak,[le(ue,{name:"sparkles"}),w[59]||(w[59]=p("span",null,"AI 演讲提词服务",-1))])]),p("button",{type:"button",class:"spm-btn-icon b3-tooltips b3-tooltips__w","aria-label":"打开完整设置弹窗",onClick:l},[le(ue,{name:"settings"})])]),de(n)?(J(),X("div",Mk,[w[60]||(w[60]=_t(" 💡 通用 AI API 已由 ",-1)),w[61]||(w[61]=p("strong",null,"API 旋钮 (siyuan-api-switch)",-1)),_t(" 接管 (Profile: "+ve(de(n).profileName||"未命名")+")。相关输入框已置灰只读。 ",1)])):Te("",!0),p("div",Ek,[p("div",Bk,[w[62]||(w[62]=p("span",{style:{"font-size":"12px","min-width":"60px",color:"var(--b3-theme-on-surface)"}},"模型:",-1)),p("input",{value:de(n)?de(n).model:de(i).aiConfig.model,class:"spm-input",disabled:!!de(n),placeholder:"例如 deepseek-chat",onChange:w[29]||(w[29]=C=>r(C.target.value))},null,40,Lk)]),p("div",Dk,[w[63]||(w[63]=p("span",{style:{"font-size":"12px","min-width":"60px",color:"var(--b3-theme-on-surface)"}},"Base URL:",-1)),p("input",{value:de(n)?de(n).baseUrl:de(i).aiConfig.baseUrl,class:"spm-input",disabled:!!de(n),placeholder:"https://api.openai.com/v1",onChange:w[30]||(w[30]=C=>a(C.target.value))},null,40,Nk)]),p("div",Ok,[w[64]||(w[64]=p("span",{style:{"font-size":"12px","min-width":"60px",color:"var(--b3-theme-on-surface)"}},"API Key:",-1)),p("input",{value:de(n)?de(n).apiKey:de(i).aiConfig.apiKey,type:"password",class:"spm-input",disabled:!!de(n),placeholder:"sk-...",onChange:w[31]||(w[31]=C=>c(C.target.value))},null,40,Pk)])])])])):Te("",!0)],2)]))}}),zk=/\.(?:png|jpe?g|gif|svg|webp|avif|ico|bmp|tiff?|mp4|webm|mp3|wav|ogg)$/i,Hk=/\.(?:ts|js|mjs|cjs|jsx|tsx|vue|json|css|scss|less|html|py|rs|go|java|c|cpp|h|sh|bash|yaml|yml|toml)$/i;async function Fk(e){const t=await gc.loadAsync(e),o={},i=[];let n="",s="";const l=[];t.forEach((a,c)=>{!c.dir&&!a.startsWith("__MACOSX")&&!a.includes("node_modules/")&&l.push({path:a,file:c})});let r=l.find(a=>a.path.toLowerCase()==="slides.md");r||(r=l.find(a=>a.path.toLowerCase().endsWith("/slides.md"))),r||(r=l.find(a=>a.path.toLowerCase().endsWith(".md"))),r&&(n=await r.file.async("string"),s=r.path);for(const a of l){const c=a.path;if(c.toLowerCase().endsWith(".md")||Hk.test(c)||c.includes("snippets/")){const u=await a.file.async("string");o[c]=u;const f=c.split("/");f.length>1&&(o[f.slice(1).join("/")]=u)}else if(zk.test(c)){const u=await a.file.async("uint8array"),f=c.split("/").pop()||c,h=typeof Blob<"u"?new Blob([u]):void 0;i.push({zipPath:c,fileName:f,data:u,blob:h})}}return{entryMarkdown:n,entryMarkdownPath:s,virtualFiles:o,assets:i}}function jk(e,t){if(Object.keys(t).length===0)return e;function o(n){const s=n.trim().replace(/^['"]|['"]$/g,""),l=s.split("/").pop()||s;if(t[s])return t[s];const r=s.replace(/^\.?\//,"");return t[r]?t[r]:t[l]?t[l]:null}function i(n){let s=n;return s=s.replace(/!\[(.*?)\]\((.*?)\)/g,(l,r,a)=>{const c=o(a);return c?`![${r}](${c})`:l}),s=s.replace(/\bsrc=["'](.*?)["']/gi,(l,r)=>{const a=o(r);return a?`src="${a}"`:l}),s}for(const n of e.slides)if(n.rawMarkdown=i(n.rawMarkdown),n.pageAttrs["custom-slides-background"]){const s=n.pageAttrs["custom-slides-background"],l=o(s);l&&(n.pageAttrs["custom-slides-background"]=l)}if(e.flattenedMarkdown=i(e.flattenedMarkdown),e.docRootAttrs["custom-slides-background"]){const n=e.docRootAttrs["custom-slides-background"],s=o(n);s&&(e.docRootAttrs["custom-slides-background"]=s)}return e}const Uk={"snippets/external.ts":`// Inside ./snippets/external.ts
// #region snippet
export function emptyArray<T>(length: number) {
  return Array.from<T>({ length })
}
// #endregion snippet

export function sayHello() {
  console.log('Hello from snippets/external.ts')
}
`};function Cc(e){try{if(typeof process<"u"&&typeof require<"u"){const t=require("fs");if(t.existsSync(e))return t.readFileSync(e,"utf-8")}}catch{}return null}function Wk(e,t){const o=e.match(/^[ \t]*<<<[ \t]+([^\s]+)/);if(!o)return null;const i=o[1].trim(),n=i.indexOf("#"),s=n!==-1?i.slice(0,n):i,l=n!==-1?i.slice(n+1):"",r=s.replace(/^@\//,"").replace(/^\.\//,""),a=(t==null?void 0:t.virtualFiles)||{};let c=a[s]||a[r]||a[`./${r}`]||a[`@/${r}`];if(!c&&Object.keys(a).length>0){const d=r.split("/").pop();for(const[b,m]of Object.entries(a))if(b.endsWith(`/${r}`)||d&&b.endsWith(`/${d}`)){c=m;break}}if(!c){const d=[];if(t!=null&&t.baseDir)try{const b=require("path");d.push(b.resolve(t.baseDir,r)),d.push(b.resolve(t.baseDir,s))}catch{}try{const b=require("path");d.push(b.resolve(process.cwd(),r))}catch{}for(const b of d){const m=Cc(b);if(m!==null){c=m;break}}}if(!c){const d=Uk||{};if(c=d[s]||d[r]||d[`snippets/${r}`],!c){const b=r.split("/").pop();for(const[m,y]of Object.entries(d))if(m.endsWith(`/${r}`)||b&&m.endsWith(`/${b}`)){c=y;break}}}if(!c)return null;let u=c;if(l){const d=new RegExp(`(?:\\/\\/|\\/\\*|#)?\\s*#(?:region|REGION)\\s+${l}[^\\r\\n]*\\r?\\n([\\s\\S]*?)(?:\\/\\/|\\/\\*|#)?\\s*#(?:endregion|ENDREGION)\\s+${l}`,"i"),b=c.match(d);if(b){const m=c.match(/^(\/\/\s*Inside[^\r\n]+\r?\n)/i);u=(m?m[1]:"")+b[1].trimEnd()}}const f=r.match(/\.([a-zA-Z0-9]+)$/);return`\`\`\`${f?f[1]:""}
${u}
\`\`\``}function qk(e){let t=!1,o=!1;for(let i=0;i<e.length;i++){const n=e[i];if(n==="'"&&!o)t=!t;else if(n==='"'&&!t)o=!o;else if(n==="#"&&!t&&!o)return e.slice(0,i).trim()}return e.trim()}function _n(e){const t={},o=e.split(/\r?\n/);let i=0;for(;i<o.length;){const n=o[i],s=n.trim();if(!s||s.startsWith("#")){i++;continue}const l=n.indexOf(":");if(l>0){const r=n.slice(0,l).trim();let a=n.slice(l+1).trim();if(a==="|"||a===">"){i++;const c=[];let u=-1;for(;i<o.length;){const f=o[i];if(!f.trim()){c.push(""),i++;continue}const d=f.match(/^(\s+)/),b=d?d[1].length:0;if(u===-1&&(u=b),b<u)break;c.push(f.slice(u)),i++}for(;c.length>0&&c[c.length-1]==="";)c.pop();t[r]=a===">"?c.join(" "):c.join(`
`);continue}if(a=qk(a),!a){let c=i+1;const u=[];let f=-1;for(;c<o.length;){const h=o[c],d=h.trim();if(!d||d.startsWith("#")){f!==-1&&u.push(""),c++;continue}const b=h.match(/^(\s+)/),m=b?b[1].length:0;if(f===-1)if(m>0)f=m;else break;if(m<f)break;u.push(h.slice(f)),c++}if(u.length>0){t[r]=_n(u.join(`
`)),i=c;continue}}a.startsWith('"')&&a.endsWith('"')||a.startsWith("'")&&a.endsWith("'")?a=a.slice(1,-1):a==="true"?a=!0:a==="false"?a=!1:a==="null"?a=null:/^-?\d+(?:\.\d+)?$/.test(a)&&(a=Number(a)),t[r]=a}i++}return t}const Vk=/^\s*```ya?ml([\s\S]*?)```/;function Na(e){let t={},o=e.trim();const i=o.match(/^---[^\n\r]*\r?\n([\s\S]*?)\r?\n---(?=[ \t]*(?:\r?\n|$))/);if(i&&!i[1].includes("```")){const s=_n(i[1]);if(Object.keys(s).length>0||!i[1].trim())return t=s,o=o.slice(i[0].length).trim(),{frontmatter:t,content:o}}if(o.startsWith("---")){const s=o.match(/^---[^\n\r]*(?:\r?\n|$)/);s&&(o=o.slice(s[0].length).trim())}const n=o.match(Vk);if(n)t=_n(n[1]),o=o.slice(n[0].length).trim();else{const s=o.split(/\r?\n/),l=[];let r=0;for(let a=0;a<s.length;a++){const c=s[a].trim();if(!c){if(l.length>0){r=a+1;break}continue}if(/^[a-zA-Z0-9_-]+\s*:\s*.*/.test(c)&&!c.startsWith("<")&&!c.startsWith("#"))l.push(c);else{r=a;break}}l.length>0&&(t=_n(l.join(`
`)),o=s.slice(r).join(`
`).trim())}return{frontmatter:t,content:o}}function Kk(e){const t=e.split(/\r?\n/),o=[];let i=0,n=!1;function s(l){if(i>=l)return;const r=t.slice(i,l).join(`
`).trim();r&&o.push(r),i=l+1}for(let l=0;l<t.length;l++){const a=t[l].trimEnd();if(n){a.includes("-->")&&(n=!1);continue}if(a.startsWith("<!--")){a.includes("-->")||(n=!0);continue}if(a.startsWith("---")){s(l);const c=t[l+1];let u=!1,f=-1;const h=c?c.trim():"";if(a.replace(/^-+/,"").trim()===""&&h.length>0){for(let d=l+1;d<t.length;d++){const b=t[d].trimEnd();if(b.startsWith("```"))break;if(b==="---"){f=d;break}}f!==-1&&f-l<=60&&t.slice(l+1,f).some(m=>{const y=m.trim();return y.length>0&&!y.startsWith("#")&&/^[a-zA-Z0-9_$-]+\s*:\s*.*/.test(y)})&&(u=!0)}u&&f!==-1&&(i=l,l=f)}else if(a.trimStart().startsWith("```")){const c=a.match(/^\s*`+/),u=c?c[0].trim():"```";let f=l+1;for(;f<t.length&&!t[f].trimStart().startsWith(u);f++);f<t.length&&(l=f)}}return i<t.length&&s(t.length),o}function In(e,t={}){const{stripNotesFromMarkdown:o=!0,cleanVClicks:i=!0,cleanShikiLines:n=!0,cleanSlots:s=!0,isolateStyleTags:l=!0,cleanHtmlToMarkdown:r=!0,wrapSuperBlocks:a=!0,virtualFiles:c={}}=t;let u=e;u&&!u.trimStart().startsWith("---")&&(u=`---

${u.trimStart()}`);const f=Kk(u),h={};let d="",b="",m=0;if(f.length>0){const F=f[0],E=Na(F),O=Object.keys(E.frontmatter).length>0,S=E.content.length>0;O&&!S&&f.length>1?(m=1,g(E.frontmatter)):O&&g(E.frontmatter)}function y(F,E,O){const S=String(F);S==="two-cols-header"?E[be]="cols-header":S==="three-cols-header"?(E[be]="cols-header",!O.layoutRatio&&!O["layout-ratio"]&&(E[bt]="1:1:1")):E[be]=S}function g(F){d=F.title||"",F.theme&&(h[Vi]=String(F.theme)),F.aspectRatio&&(h[Ki]=String(F.aspectRatio)),F.transition&&(h[Gi]=String(F.transition)),F.colorSchema&&(h[qa]=String(F.colorSchema)),F.layout&&y(F.layout,h,F),F.background&&(h[dt]=String(F.background)),F.image&&(h[Kt]=String(F.image)),F.class&&(h[ci]=String(F.class));for(const[E,O]of Object.entries(F))["theme","aspectRatio","highlighter","transition","colorSchema","title","layout","background","image","class"].includes(E)||(h[`custom-slides-${E}`]=typeof O=="object"?JSON.stringify(O):String(O))}const x=[];let k=0,I=0,T=0,w=0;const C=new Set,L={};let R=1;for(let F=m;F<f.length;F++){const E=f[F],{frontmatter:O,content:S}=Na(E),W=E.match(/^\s*(?:---\s*)?src:\s*([^\n\r]+)/m),j=O.src||(W?W[1]:void 0);if(j){const z=String(j).trim().replace(/^['"]|['"]$/g,"");let se=c[z]||c[z.replace(/^\.\//,"")]||c[`pages/${z.replace(/^.*pages\//,"")}`];if(!se){const V=z.replace(/^\.\//,""),v=[];if(t.baseDir)try{const K=require("path");v.push(K.resolve(t.baseDir,V)),v.push(K.resolve(t.baseDir,z))}catch{}try{const K=require("path");v.push(K.resolve(process.cwd(),V)),v.push(K.resolve(process.cwd(),z))}catch{}for(const K of v){const H=Cc(K);if(H!==null){se=H;break}}}const D={};O.layout&&y(O.layout,D,O),O.transition&&(D[It]=String(O.transition)),O.background&&(D[dt]=String(O.background)),O.image&&(D[Kt]=String(O.image)),O.class&&(D[ci]=String(O.class));for(const[V,v]of Object.entries(O))["src","layout","transition","background","image","class"].includes(V)||(D[`custom-slides-${V}`]=typeof v=="object"?JSON.stringify(v):String(v));if(se){const V=In(se,{...t,virtualFiles:c});for(const v of V.slides){v.pageIndex=R++,v.pageAttrs={...D,...v.pageAttrs},x.push(v);const K=v.pageAttrs[be]||"default";L[K]=(L[K]||0)+1}continue}else{x.push({pageIndex:R++,pageAttrs:{...D,"custom-slides-src":z},notes:"",rawMarkdown:`> 📄 **引入外部幻灯片页面**: \`${z}\`
>
> *提示：如需展示该页面完整内容，请将关联子页面一同打包为 .zip 或通过本地工程导入。*`,hasVueComponent:!1,hasStyleTag:!1,assetReferences:[]});const V=D[be]||"default";L[V]=(L[V]||0)+1;continue}}const _={};O.layout&&y(O.layout,_,O),O.transition&&(_[It]=String(O.transition)),O.background&&(_[dt]=String(O.background)),O.image&&(_[Kt]=String(O.image)),O.class&&(_[ci]=String(O.class)),O.mask&&(_[di]=String(O.mask)),(O.maskRatio||O["mask-ratio"])&&(_[Xo]=String(O.maskRatio||O["mask-ratio"])),(O.maskStyle||O["mask-style"])&&(_[ui]=String(O.maskStyle||O["mask-style"])),(O.maskInitial||O["mask-initial"])&&(_[fi]=String(O.maskInitial||O["mask-initial"]));for(const[z,se]of Object.entries(O))["layout","transition","background","image","class","mask","maskRatio","mask-ratio","maskStyle","mask-style","maskInitial","mask-initial"].includes(z)||(_[`custom-slides-${z}`]=typeof se=="object"?JSON.stringify(se):String(se));let M=S;const B=[];let Q=M.replace(/(?:^[ \t]*(`{3,}|~{3,})[^\n\r]*\r?\n[\s\S]*?\r?\n[ \t]*\1(?=[ \t]*(?:\r?\n|$)))/gm,z=>{const se=`__CODE_TOKEN_NOTE_${B.length}__`;return B.push(z),se});Q=Q.replace(/(`+)(?:[^\n\r`]|(?!\1)`)+?\1/g,z=>{const se=`__CODE_TOKEN_NOTE_${B.length}__`;return B.push(z),se});let q="";const U=Array.from(Q.matchAll(/<!--([\s\S]*?)-->/g));if(U.length>0){const z=U[U.length-1],se=Q.slice(z.index+z[0].length).trim();if(!se||!se.replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi,"").trim()){const V=z[1].trim();V.startsWith("TODO:")||(q=V,k++),o&&(Q=Q.slice(0,z.index).trimEnd()+Q.slice(z.index+z[0].length))}}o&&(Q=Q.replace(/<!--(?![\s\S]*?TODO:)[\s\S]*?-->/g,"").trim());for(let z=0;z<B.length;z++)Q=Q.replace(`__CODE_TOKEN_NOTE_${z}__`,()=>B[z]);if(M=Q,q){for(let D=0;D<B.length;D++)q=q.replace(`__CODE_TOKEN_NOTE_${D}__`,()=>B[D]);const se=`> [!NOTE] 💡 演讲备注
${q.split(/\r?\n/).map(D=>`> ${D}`).join(`
`)}
{: custom-slides-note="true"}`;M=M?`${M}

${se}`:se}let ne=!1;if(/<style\b/i.test(M)){ne=!0;const z=M.match(/<style\b[^>]*>([\s\S]*?)<\/style>/gi);if(z){for(const se of z){const D=se.replace(/<style\b[^>]*>|<\/style>/gi,"").trim();b=b?`${b}

${D}`:D}l&&(M=M.replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi,"").trim())}}const oe=M.match(/<v-click[^>]*>|<v-clicks[^>]*>|v-click=/g);oe&&(I+=oe.length);const ae=M.match(/```\w+\s+\{[^}]+\}/g);ae&&(T+=ae.length);const Se=M.match(/::\w+::|<template\s+#[^>]+>/g);if(Se&&(w+=Se.length),M=M.replace(/^[ \t]*<<<[ \t]+([^\n\r]+)/gm,z=>Wk(z,{...t,virtualFiles:c})||z),i&&(M=M.replace(/<v-click(?:\s+at="[^"]*")?(?:\s+hide)?>\s*([\s\S]*?)\s*<\/v-click>/gi,"$1")),n&&(M=M.replace(/(^```\w+(?:[ \t]+\[[^\]]*\])?)[ \t]+\{[^}]+\}(?:[ \t]+\w+)?/gm,"$1"),M=M.replace(/^\$\$\s+\{[^}]+\}/gm,()=>"$$")),s&&(M=M.replace(/^::\w+::\s*$/gm,"")),r&&(M=Sp(M)),a){let z=M.trim(),se="";const D=z.lastIndexOf("> [!NOTE] 💡 演讲备注");if(D!==-1&&(se=z.slice(D),z=z.slice(0,D).trim()),(O.layout==="image-left"||O.layout==="image-right")&&O.image){const V=String(O.image).trim(),v=O.layout==="image-left"?"image-left":"image-right",K=`![配图](${V})
{: custom-slides-layout="${v}" }`;O.layout==="image-left"?z=`{{{col

${K}

${z}

}}}`:z=`{{{col

${z}

${K}

}}}`}if(O.background){const v=`![背景图](${String(O.background).trim()})
{: custom-slides-role="background" }`;z=z?`${v}

${z}`:v}M=se?`${z}

${se}`:z}const $e=Gk(M);_[dt]&&$e.push(_[dt]),_[Kt]&&$e.push(_[Kt]);for(const z of $e)C.add(z);const ke=/<[A-Z][a-zA-Z0-9]+/.test(M),Ce=_[be]||(R===1?h[be]||"cover":"default");L[Ce]=(L[Ce]||0)+1,x.push({pageIndex:R++,pageAttrs:_,notes:q,rawMarkdown:M,hasVueComponent:ke,hasStyleTag:ne,assetReferences:$e})}if(!d&&x.length>0){const F=x[0].rawMarkdown.match(/^#\s+(.+)$/m);F&&(d=F[1].trim())}b&&(h["custom-slides-custom-css"]=b);let N=x.map(F=>`---

${F.rawMarkdown}`).join(`

`);return N.trimStart().startsWith("---")||(N=`---

${N.trimStart()}`),{docTitle:d||"Slidev 演示文稿",docRootAttrs:h,slides:x,totalSlides:x.length,stats:{totalNotes:k,totalVClicks:I,totalShikiHighlights:T,totalSlots:w,discoveredAssets:Array.from(C),layoutDistribution:L},flattenedMarkdown:N,customCss:b}}function Gk(e){const t=[],o=/!\[.*?\]\((.*?)\)/g;let i;for(;(i=o.exec(e))!==null;){const s=i[1].split(/\s+/)[0].trim();s&&t.push(s)}const n=/<(?:img|video|source|audio)\b[^>]*src=["'](.*?)["']/gi;for(;(i=n.exec(e))!==null;){const s=i[1].trim();s&&t.push(s)}return t}function _c(e){if(!e)return!1;const t=String(e.type||"").toLowerCase(),o=String(e.markdown||"").trim(),i=String(e.content||"").trim();return t==="tb"||t==="thematic-break"||t==="nodethematicbreak"||o==="---"||o==="***"||i==="---"||i==="***"}function Yk(e){return(e.trim()||"Slidev 演示文稿").replace(/[\\/:*?"<>|]/g,"_")}async function Zk(e,t,o=ze){const i=e.filter(_c);let n=0;if(i.length>=t.length)for(let s=0;s<t.length;s++){const l=t[s],r=i[s];r&&r.id&&Object.keys(l.pageAttrs||{}).length>0&&(await o(r.id,l.pageAttrs),n++)}else for(let s=1;s<t.length;s++){const l=t[s],r=i[s-1];r&&r.id&&Object.keys(l.pageAttrs||{}).length>0&&(await o(r.id,l.pageAttrs),n++)}return n}async function Jk(e,t=ze){let o=!1,i=0;for(const n of e){if(_c(n)){o=!1;continue}const s=(n.markdown||n.content||"").trim();if(s==="::right::"||s.startsWith("::right::")){o=!0;continue}o&&n.id&&(await t(n.id,{[Ae]:"right"}).catch(()=>{}),i++)}return i}async function Xk(e,t,o=Fa){const i={};if(!t||t.length===0)return i;const n=[];for(const s of t){const l=new File([s.data],s.fileName,{type:"application/octet-stream"});n.push(l)}try{const s=await o("/data/assets",n);if(s!=null&&s.succMap)for(const[l,r]of Object.entries(s.succMap))i[l]=String(r)}catch(s){console.warn("上传本地静态资产失败，保留原路径:",s)}return Object.keys(i).length>0&&jk(e,i),i}async function Qk(e){var x;const{presentation:t,notebookId:o,docTitle:i,extractedAssets:n=[],uploadAssets:s=!0,autoPreview:l=!0,plugin:r,api:a={}}=e,c=a.uploadFn||Fa,u=a.createDocFn||Ed,f=a.setAttrsFn||ze,h=a.getChildBlocksFn||Ci,d=a.openTabFn||ie.openTab,b=a.showMessageFn||ie.showMessage;s&&n.length>0&&await Xk(t,n,c);const m=Yk(i),y=`/${m}`,g=await u(o,y,t.flattenedMarkdown);if(!g)throw new Error("思源内核创建文档失败，未返回有效 DocumentId");try{const k=((x=t.slides[0])==null?void 0:x.pageAttrs)||{};await f(g,{...k,...t.docRootAttrs});const I=await h(g).catch(()=>[]);Array.isArray(I)&&I.length>0&&(await Zk(I,t.slides,f),await Jk(I,f))}catch(k){console.warn("[SlidesImport] 版式属性回填阶段遇到警告:",k),b(`⚠️ 文档已创建(${m})，但部分版式属性回填未完全完成: ${k.message||String(k)}`,6e3)}return b(`🎉 成功导入 Slidev 演示文档《${m}》！`),l&&r&&(r.currentDocId=g,await d({app:r.app,doc:{id:g}}),r.openBottomPreviewTab&&r.openBottomPreviewTab()),g}function ew(e){const t=he("file"),o=he(!1),i=he(!1),n=he(""),s=he(null),l=he(null),r=he(""),a=he(0),c=he(""),u=he([]),f=he(null),h=he(""),d=he([]),b=he(""),m=he(!0),y=he(!0),g=he(!0),x=he(!0),k=ge(()=>{const _=a.value;if(_===0)return"0 B";const M=1024,B=["B","KB","MB","GB"],Q=Math.floor(Math.log(_)/Math.log(M));return`${(_/M**Q).toFixed(1)} ${B[Q]}`}),I=ge(()=>{var _;return((_=f.value)==null?void 0:_.docRootAttrs["custom-slides-theme"])||"default"}),T=ge(()=>{var _;return u.value.length>0?u.value.length:((_=f.value)==null?void 0:_.stats.discoveredAssets.length)||0}),w=ge(()=>{var M;const _=((M=f.value)==null?void 0:M.stats.layoutDistribution)||{};return Object.entries(_).map(([B,Q])=>({name:B,count:Q}))});async function C(_=Md){try{const M=await _();M!=null&&M.notebooks&&Array.isArray(M.notebooks)&&(d.value=M.notebooks.filter(B=>!B.closed),d.value.length>0&&!b.value&&(b.value=d.value[0].id))}catch(M){console.warn("获取笔记本列表失败:",M)}}function L(){var _;(_=s.value)==null||_.click()}function R(){l.value=null,r.value="",a.value=0,f.value=null,u.value=[],n.value=""}let N=0;async function F(_){const M=++N;n.value="",l.value=_,r.value=_.name,a.value=_.size;try{if(_.name.toLowerCase().endsWith(".zip")){const Q=await _.arrayBuffer();if(M!==N)return;const q=await Fk(Q);if(M!==N)return;if(!q.entryMarkdown){n.value="未在 Zip 压缩包中找到 slides.md 或任何有效的 Markdown 入口文件";return}u.value=q.assets;const U=In(q.entryMarkdown,{stripNotesFromMarkdown:y.value,cleanHtmlToMarkdown:m.value,cleanSlots:!1,virtualFiles:q.virtualFiles});if(M!==N)return;f.value=U,h.value=U.docTitle||_.name.replace(/\.zip$/i,"")}else{const Q=await _.text();if(M!==N)return;u.value=[];const q=_.path||"",U=q?q.replace(/[\\/][^\\/]+$/,""):"",ne=In(Q,{stripNotesFromMarkdown:y.value,cleanHtmlToMarkdown:m.value,cleanSlots:!1,baseDir:U||void 0});if(M!==N)return;f.value=ne,h.value=ne.docTitle||_.name.replace(/\.md$/i,"")}}catch(B){if(M!==N)return;console.error("解析文件失败:",B),n.value=`解析文件失败: ${B.message||String(B)}`}}function E(){if(n.value="",!c.value.trim()){f.value=null;return}try{const _=In(c.value,{stripNotesFromMarkdown:y.value,cleanHtmlToMarkdown:m.value,cleanSlots:!1});f.value=_,h.value=_.docTitle||"Slidev 演示文稿"}catch(_){n.value=`解析 Markdown 源码失败: ${_.message||String(_)}`}}async function O(){l.value?await F(l.value):c.value&&E()}async function S(_){const M=_.target;M.files&&M.files[0]&&await F(M.files[0])}async function W(_){var M;o.value=!1,(M=_.dataTransfer)!=null&&M.files&&_.dataTransfer.files[0]&&await F(_.dataTransfer.files[0])}async function j(_=e){if(f.value){if(!b.value&&d.value.length>0&&(b.value=d.value[0].id),!b.value){n.value="请先选择目标笔记本";return}i.value=!0,n.value="";try{return await Qk({presentation:f.value,notebookId:b.value,docTitle:h.value,extractedAssets:u.value,uploadAssets:g.value,autoPreview:x.value,plugin:_})}catch(M){console.error("导入 Slidev 演示失败:",M),n.value=`导入执行失败: ${M.message||String(M)}`}finally{i.value=!1}}}return{inputMode:t,isDragging:o,isImporting:i,errorMessage:n,fileInputRef:s,selectedFile:l,selectedFileName:r,selectedFileSize:a,rawMarkdownText:c,extractedAssets:u,parsedPresentation:f,customDocTitle:h,notebooks:d,selectedNotebookId:b,optCleanHtml:m,optStripNotes:y,optUploadAssets:g,optAutoPreview:x,formattedFileSize:k,currentTheme:I,extractedAssetsCount:T,layoutChips:w,fetchNotebooks:C,triggerFileInput:L,clearFile:R,processFile:F,onFileSelected:S,onFileDrop:W,onTextChange:E,reprocessCurrentInput:O,handleConfirmImport:j}}const tw={class:"spm-import-dialog"},ow={class:"spm-tabs-header"},iw={class:"spm-dialog-body"},nw={key:0,class:"spm-file-section"},sw={key:0,class:"spm-dropzone-prompt"},rw={class:"spm-dropzone-icon"},aw={key:1,class:"spm-dropzone-active"},lw={class:"spm-file-badge"},cw={class:"spm-file-size"},dw={key:1,class:"spm-text-section"},uw={key:2,class:"spm-error-banner"},fw={key:3,class:"spm-preview-card"},pw={class:"spm-preview-card__header"},hw={style:{display:"inline-flex","align-items":"center",gap:"4px"}},mw={class:"spm-config-grid"},gw={class:"spm-form-item"},yw={class:"spm-form-item"},bw=["value"],vw={class:"spm-stats-grid"},kw={class:"spm-stat-box"},ww={class:"spm-stat-value"},xw={class:"spm-stat-box"},Sw={class:"spm-stat-value"},Cw={class:"spm-stat-box"},_w={class:"spm-stat-value"},Iw={class:"spm-stat-box"},$w={class:"spm-stat-value"},Tw={key:0,class:"spm-chips-row"},Aw={class:"spm-options-group"},Mw={class:"spm-checkbox-label"},Ew={class:"spm-checkbox-label"},Bw={class:"spm-checkbox-label"},Lw={class:"spm-checkbox-label"},Dw={class:"spm-dialog-footer"},Nw=["disabled"],Ow=["disabled"],Pw={key:0,style:{display:"inline-flex","align-items":"center",gap:"4px"}},Rw={key:1,style:{display:"inline-flex","align-items":"center",gap:"4px"}},zw=Ht({__name:"SlidesImportDialog",emits:["close","success"],setup(e,{emit:t}){const o=t,i=Zt("plugin"),{inputMode:n,isDragging:s,isImporting:l,errorMessage:r,fileInputRef:a,selectedFileName:c,rawMarkdownText:u,extractedAssetsCount:f,parsedPresentation:h,customDocTitle:d,notebooks:b,selectedNotebookId:m,optCleanHtml:y,optStripNotes:g,optUploadAssets:x,optAutoPreview:k,formattedFileSize:I,currentTheme:T,layoutChips:w,fetchNotebooks:C,triggerFileInput:L,clearFile:R,onFileSelected:N,onFileDrop:F,onTextChange:E,reprocessCurrentInput:O,handleConfirmImport:S}=ew(i);oi(async()=>{await C()});async function W(){const _=await S();_&&(o("success",{docId:_}),o("close"))}function j(){o("close")}return(_,M)=>(J(),X("div",{class:"spm-modal-overlay",onClick:ro(j,["self"])},[p("div",tw,[p("div",{class:"spm-dialog-header"},[M[18]||(M[18]=p("div",{class:"spm-dialog-title"},[p("svg",{class:"spm-dialog-icon","aria-hidden":"true"},[p("use",{"xlink:href":"#iconSlides"})]),p("span",null,"导入 Slidev 演示文档")],-1)),p("button",{class:"spm-close-btn",title:"关闭",onClick:j},"✕")]),p("div",ow,[p("button",{class:xe(["spm-tab-btn",{active:de(n)==="file"}]),onClick:M[0]||(M[0]=B=>n.value="file")},[le(ue,{name:"package"}),M[19]||(M[19]=p("span",null,"文件 / 压缩包导入 (.zip / .md)",-1))],2),p("button",{class:xe(["spm-tab-btn",{active:de(n)==="text"}]),onClick:M[1]||(M[1]=B=>n.value="text")},[le(ue,{name:"notes"}),M[20]||(M[20]=p("span",null,"粘贴 Markdown 源码",-1))],2)]),p("div",iw,[de(n)==="file"?(J(),X("div",nw,[p("div",{class:xe(["spm-dropzone",{dragover:de(s),"has-file":!!de(c)}]),onDragover:M[4]||(M[4]=ro(B=>s.value=!0,["prevent"])),onDragleave:M[5]||(M[5]=ro(B=>s.value=!1,["prevent"])),onDrop:M[6]||(M[6]=ro((...B)=>de(F)&&de(F)(...B),["prevent"])),onClick:M[7]||(M[7]=(...B)=>de(L)&&de(L)(...B))},[p("input",{ref_key:"fileInputRef",ref:a,type:"file",accept:".zip,.md",class:"spm-hidden-input",onChange:M[2]||(M[2]=(...B)=>de(N)&&de(N)(...B))},null,544),de(c)?(J(),X("div",aw,[p("span",lw,[le(ue,{name:"notes"}),_t(" "+ve(de(c)),1)]),p("span",cw,"("+ve(de(I))+")",1),p("button",{class:"spm-btn-text",onClick:M[3]||(M[3]=ro((...B)=>de(R)&&de(R)(...B),["stop"]))},"更换文件")])):(J(),X("div",sw,[p("span",rw,[le(ue,{name:"folder",style:{"font-size":"32px"}})]),M[21]||(M[21]=p("p",{class:"spm-dropzone-text"},"点击选择文件，或直接拖拽文件至此处",-1)),M[22]||(M[22]=p("p",{class:"spm-dropzone-hint"},[_t(" 支持 Slidev 完整工程 "),p("strong",null,".zip"),_t("（自动解包 public/ 静态素材）或单文件 "),p("strong",null,".md")],-1))]))],34)])):(J(),X("div",dw,[Vt(p("textarea",{"onUpdate:modelValue":M[8]||(M[8]=B=>ot(u)?u.value=B:null),class:"spm-textarea spm-source-editor",rows:"8",placeholder:"在此直接粘贴包含 Frontmatter 的 Slidev slides.md 源码...",onInput:M[9]||(M[9]=(...B)=>de(E)&&de(E)(...B))},null,544),[[Ws,de(u)]])])),de(r)?(J(),X("div",uw," ⚠️ "+ve(de(r)),1)):Te("",!0),de(h)?(J(),X("div",fw,[p("div",pw,[p("span",hw,[le(ue,{name:"sparkles"}),M[23]||(M[23]=_t(" 演示解析摘要",-1))]),M[24]||(M[24]=p("span",{class:"spm-badge-success"},"预检就绪",-1))]),p("div",mw,[p("div",gw,[M[25]||(M[25]=p("label",{class:"spm-form-label"},"笔记文档标题",-1)),Vt(p("input",{"onUpdate:modelValue":M[10]||(M[10]=B=>ot(d)?d.value=B:null),class:"spm-input",placeholder:"思源新文档标题"},null,512),[[Ws,de(d)]])]),p("div",yw,[M[26]||(M[26]=p("label",{class:"spm-form-label"},"存放目标笔记本",-1)),Vt(p("select",{"onUpdate:modelValue":M[11]||(M[11]=B=>ot(m)?m.value=B:null),class:"spm-select"},[(J(!0),X(Ve,null,$t(de(b),B=>(J(),X("option",{key:B.id,value:B.id},ve(B.name),9,bw))),128))],512),[[op,de(m)]])])]),p("div",vw,[p("div",kw,[p("span",ww,ve(de(h).totalSlides),1),M[27]||(M[27]=p("span",{class:"spm-stat-label"},"幻灯片页数",-1))]),p("div",xw,[p("span",Sw,ve(de(T)),1),M[28]||(M[28]=p("span",{class:"spm-stat-label"},"演示主题",-1))]),p("div",Cw,[p("span",_w,ve(de(h).stats.totalNotes),1),M[29]||(M[29]=p("span",{class:"spm-stat-label"},"演讲者提词",-1))]),p("div",Iw,[p("span",$w,ve(de(f)),1),M[30]||(M[30]=p("span",{class:"spm-stat-label"},"关联本地素材",-1))])]),de(w).length>0?(J(),X("div",Tw,[M[31]||(M[31]=p("span",{class:"spm-chips-label"},"页面版式分布：",-1)),(J(!0),X(Ve,null,$t(de(w),B=>(J(),X("span",{key:B.name,class:"spm-chip-badge"},ve(B.name)+": "+ve(B.count),1))),128))])):Te("",!0),p("div",Aw,[p("label",Mw,[Vt(p("input",{"onUpdate:modelValue":M[12]||(M[12]=B=>ot(y)?y.value=B:null),type:"checkbox",onChange:M[13]||(M[13]=(...B)=>de(O)&&de(O)(...B))},null,544),[[hn,de(y)]]),M[32]||(M[32]=p("span",null,"智能剥离展示型 HTML 容器为干净原生的 Markdown 笔记块",-1))]),p("label",Ew,[Vt(p("input",{"onUpdate:modelValue":M[14]||(M[14]=B=>ot(g)?g.value=B:null),type:"checkbox",onChange:M[15]||(M[15]=(...B)=>de(O)&&de(O)(...B))},null,544),[[hn,de(g)]]),M[33]||(M[33]=p("span",null,"提取演讲者提词到块属性并保持正文笔记清爽",-1))]),p("label",Bw,[Vt(p("input",{"onUpdate:modelValue":M[16]||(M[16]=B=>ot(x)?x.value=B:null),type:"checkbox"},null,512),[[hn,de(x)]]),M[34]||(M[34]=p("span",null,"自动上传关联素材至思源资产库并重写路径 (assets/...)",-1))]),p("label",Lw,[Vt(p("input",{"onUpdate:modelValue":M[17]||(M[17]=B=>ot(k)?k.value=B:null),type:"checkbox"},null,512),[[hn,de(k)]]),M[35]||(M[35]=p("span",null,"导入后自动打开新文档并开启下方分屏放映预览",-1))])])])):Te("",!0)]),p("div",Dw,[p("button",{class:"spm-btn-secondary",disabled:de(l),onClick:j}," 取消 ",8,Nw),p("button",{class:"spm-btn-primary",disabled:!de(h)||de(l),onClick:W},[de(l)?(J(),X("span",Pw,[le(ue,{name:"refresh"}),M[36]||(M[36]=_t(" 正在导入生成中...",-1))])):(J(),X("span",Rw,[le(ue,{name:"rocket"}),M[37]||(M[37]=_t(" 确认导入思源笔记",-1))]))],8,Ow)])])]))}}),Hw=uo(zw,[["__scopeId","data-v-c56a3d7e"]]);function Ir(e){return e?e==="NodeThematicBreak"||e==="tb"||e==="thematic-break":!1}function Ic(e,t){var r;if(!e||e.length===0)return null;const o=t.activeBlockId||"",i=t.currentTopBlockId||o,n=t.currentPageDividerId||"",s=t.activeBlockType||"";if(Ir(s)&&o){let a=e.find(c=>c.startBlockId===o);if(a||(a=e.find(c=>{var u,f;return((f=(u=c.blocks)==null?void 0:u[0])==null?void 0:f.id)===o}),a)||(a=e.find(c=>{var u;return(u=c.allBlockIds)==null?void 0:u.includes(o)}),a))return a}if(n){let a=e.find(c=>c.startBlockId===n);if(a||(a=e.find(c=>{var u,f;return((f=(u=c.blocks)==null?void 0:u[0])==null?void 0:f.id)===n}),a))return a}if(o){let a=e.find(u=>u.startBlockId===o);if(a||(a=e.find(u=>{var f,h;return((f=u.blocks)==null?void 0:f.some(d=>d.id===o))||((h=u.allBlockIds)==null?void 0:h.includes(o))}),a)||i&&i!==o&&(a=e.find(u=>{var f,h;return((f=u.blocks)==null?void 0:f.some(d=>d.id===i))||((h=u.allBlockIds)==null?void 0:h.includes(i))}),a)||(a=e.find(u=>{var f;return(f=u.noteBlocks)==null?void 0:f.some(h=>h.id===o||h.id===i)}),a))return a;const c=(r=t.activeBlockAttrs)==null?void 0:r[Ae];if(c&&["col-1","col-2","col-3"].includes(c)&&(a=e.find(u=>{var f,h;return((f=u.frontmatter)==null?void 0:f.layout)==="three-cols-header"||((h=u.blocks)==null?void 0:h.some(d=>d.slot==="col-1"||d.slot==="col-2"||d.slot==="col-3"))}),a))return a}return e[0]||null}function Cs(){var s;if(typeof window<"u"&&typeof((s=window.Lute)==null?void 0:s.NewNodeID)=="function")return window.Lute.NewNodeID();const e=new Date,t=l=>l.toString().padStart(2,"0"),o=`${e.getFullYear()}${t(e.getMonth()+1)}${t(e.getDate())}${t(e.getHours())}${t(e.getMinutes())}${t(e.getSeconds())}`,i="0123456789abcdefghijklmnopqrstuvwxyz";let n="";for(let l=0;l<7;l++)n+=i[Math.floor(Math.random()*i.length)];return`${o}-${n}`}function $c(){return typeof document>"u"?null:document.querySelector(".layout__wnd--active .protyle-wysiwyg")||document.querySelector(".protyle:not(.fn__none) .protyle-wysiwyg")||document.querySelector(".protyle-wysiwyg")}function Fw(e,t){var l;if(typeof document>"u")return!1;const o=$c();if(!o)return!1;const i=Array.from(o.querySelectorAll(".protyle-wysiwyg--select[data-node-id]"));if(i.length>=2)return!0;const n=((l=i[0])==null?void 0:l.getAttribute("data-node-id"))||e,s=t==="NodeList"||t==="l"||t==="list";if(n){const r=o.querySelector(`[data-node-id="${n}"]`);if(r){const a=(s||r.getAttribute("data-type")==="NodeList"||r.classList.contains("list"))&&r.getAttribute("data-type")==="NodeList"?r:r.closest('[data-type="NodeList"], .list');if(a&&a.querySelectorAll(":scope > [data-type='NodeListItem'], :scope > .li").length>=2)return!0}}return!1}async function jw(e){const t=$c();if(!t)return{success:!1,error:"未找到主编辑区"};const o=Array.from(t.querySelectorAll(".protyle-wysiwyg--select[data-node-id]"));let i=!1,n=null,s=[];if(o.length>=2){const k=o[0].closest('[data-type="NodeList"], .list');if(k){const I=new Set;let T=!0;for(const w of o){const C=w.getAttribute("data-type")==="NodeListItem"||w.classList.contains("li")?w:w.closest('[data-type="NodeListItem"], .li');if(!C||C.closest('[data-type="NodeList"], .list')!==k){T=!1;break}I.add(C)}T&&I.size>=2&&(i=!0,n=k,s=Array.from(k.querySelectorAll(":scope > [data-type='NodeListItem'], :scope > .li")).filter(w=>I.has(w)))}}let l=!1;if(!i){const k=(o.length===1?o[0]:null)||(e.activeBlockId?t.querySelector(`[data-node-id="${e.activeBlockId}"]`):null);if(k){const I=k.getAttribute("data-type")==="NodeList"||k.classList.contains("list")?k:k.closest('[data-type="NodeList"], .list');if(I){const T=Array.from(I.querySelectorAll(":scope > [data-type='NodeListItem'], :scope > .li"));T.length>=2&&(l=!0,n=I,s=T)}}}if(i||l){if(!n||s.length<2)return{success:!1,error:"选中的列表项不足 2 项，无法合并为横向超级块"};const k=Array.from(n.querySelectorAll(":scope > [data-type='NodeListItem'], :scope > .li")),I=s.length===k.length,T=n.getAttribute("data-subtype")||"u",w=n.getAttribute("data-node-id")||"",C=n.parentElement,L=(C==null?void 0:C.getAttribute("data-node-id"))||e.currentDocId;let R=n.previousElementSibling;for(;R&&!R.getAttribute("data-node-id");)R=R.previousElementSibling;const N=(R==null?void 0:R.getAttribute("data-node-id"))||"";let F=n.nextElementSibling;for(;F&&!F.getAttribute("data-node-id");)F=F.nextElementSibling;const E=(F==null?void 0:F.getAttribute("data-node-id"))||"",O=Cs(),S=s.map(_=>({li:_,liId:_.getAttribute("data-node-id")||"",newListId:Cs()})),W=[],j=[];if(I){W.push({action:"insert",id:O,data:`<div data-node-id="${O}" data-type="NodeSuperBlock" class="sb" data-sb-layout="col"><div class="protyle-attr" contenteditable="false">&#x200B;</div></div>`,parentID:L,previousID:N||void 0,nextID:N?void 0:E||void 0});for(let _=0;_<S.length;_++){const{liId:M,newListId:B}=S[_];W.push({action:"insert",id:B,data:`<div data-node-id="${B}" data-type="NodeList" data-subtype="${T}" class="list"><div class="protyle-attr" contenteditable="false">&#x200B;</div></div>`,parentID:O,previousID:_===0?void 0:S[_-1].newListId}),W.push({action:"move",id:M,parentID:B})}w&&W.push({action:"delete",id:w}),w&&j.push({action:"insert",id:w,data:n.outerHTML,parentID:L,previousID:N||void 0,nextID:N?void 0:E||void 0});for(let _=0;_<S.length;_++)j.push({action:"move",id:S[_].liId,parentID:w,previousID:_===0?void 0:S[_-1].liId});for(const{newListId:_}of S)j.push({action:"delete",id:_});j.push({action:"delete",id:O})}else{W.push({action:"insert",id:O,data:`<div data-node-id="${O}" data-type="NodeSuperBlock" class="sb" data-sb-layout="col"><div class="protyle-attr" contenteditable="false">&#x200B;</div></div>`,parentID:L,previousID:w});for(let _=0;_<S.length;_++){const{liId:M,newListId:B}=S[_];W.push({action:"insert",id:B,data:`<div data-node-id="${B}" data-type="NodeList" data-subtype="${T}" class="list"><div class="protyle-attr" contenteditable="false">&#x200B;</div></div>`,parentID:O,previousID:_===0?void 0:S[_-1].newListId}),W.push({action:"move",id:M,parentID:B})}for(let _=0;_<S.length;_++)j.push({action:"move",id:S[_].liId,parentID:w});for(const{newListId:_}of S)j.push({action:"delete",id:_});j.push({action:"delete",id:O})}return await Dr([{doOperations:W,undoOperations:j}]),t.querySelectorAll(".protyle-wysiwyg--select").forEach(_=>_.classList.remove("protyle-wysiwyg--select")),{success:!0,colCount:S.length,superBlockId:O}}const r=o.filter(k=>{let I=k.parentElement;for(;I&&I!==t;){if(o.includes(I))return!1;I=I.parentElement}return!0});if(r.length<2)return{success:!1,error:"请在编辑区选中多个块，或选中一个包含多个列表项的列表"};const a=r[0],c=r[r.length-1],u=a.parentElement,f=(u==null?void 0:u.getAttribute("data-node-id"))||e.currentDocId;let h=a.previousElementSibling;for(;h&&!h.getAttribute("data-node-id");)h=h.previousElementSibling;const d=(h==null?void 0:h.getAttribute("data-node-id"))||"";let b=c.nextElementSibling;for(;b&&!b.getAttribute("data-node-id");)b=b.nextElementSibling;const m=(b==null?void 0:b.getAttribute("data-node-id"))||"",y=Cs(),g=[],x=[];g.push({action:"insert",id:y,data:`<div data-node-id="${y}" data-type="NodeSuperBlock" class="sb" data-sb-layout="col"><div class="protyle-attr" contenteditable="false">&#x200B;</div></div>`,parentID:f,previousID:d||void 0,nextID:d?void 0:m||void 0});for(let k=0;k<r.length;k++){const I=r[k].getAttribute("data-node-id");g.push({action:"move",id:I,parentID:y,previousID:k===0?void 0:r[k-1].getAttribute("data-node-id")})}for(let k=0;k<r.length;k++){const I=r[k].getAttribute("data-node-id");x.push({action:"move",id:I,parentID:f,previousID:k===0?d||void 0:r[k-1].getAttribute("data-node-id")})}return x.push({action:"delete",id:y}),await Dr([{doOperations:g,undoOperations:x}]),t.querySelectorAll(".protyle-wysiwyg--select").forEach(k=>k.classList.remove("protyle-wysiwyg--select")),{success:!0,colCount:r.length,superBlockId:y}}function et(e,t){var n;if(typeof document>"u"||!e)return;const o=(n=globalThis.CSS)!=null&&n.escape?globalThis.CSS.escape(e):e.replace(/"/g,'\\"'),i=document.querySelectorAll(`[data-node-id="${o}"]`);!i||i.length===0||i.forEach(s=>{for(const[l,r]of Object.entries(t))r!=null&&r!==""?s.setAttribute(l,String(r)):s.removeAttribute(l)})}function Uw(e){if(typeof document>"u")return;const t=`.protyle-wysiwyg [${be}], .protyle-wysiwyg [${Ze}], .protyle-wysiwyg [custom-slides-layout], .protyle-wysiwyg [custom-slides-role]`,o=document.querySelectorAll(t);!o||o.length===0||o.forEach(i=>{const n=i.getAttribute("data-node-id");if(!n){i.removeAttribute(be),i.removeAttribute("custom-slides-layout"),i.removeAttribute(Ze),i.removeAttribute("custom-slides-role");return}const s=e.get(n),l=(s==null?void 0:s[be])||(s==null?void 0:s["custom-slides-layout"])||"",r=i.getAttribute(be)||i.getAttribute("custom-slides-layout");r&&r!==l&&(l?i.setAttribute(be,l):(i.removeAttribute(be),i.removeAttribute("custom-slides-layout")));const a=(s==null?void 0:s[Ze])||(s==null?void 0:s["custom-slides-role"])||"",c=i.getAttribute(Ze)||i.getAttribute("custom-slides-role");c&&c!==a&&(a?i.setAttribute(Ze,a):(i.removeAttribute(Ze),i.removeAttribute("custom-slides-role")))})}function Ww(e,t){if(!t)return!1;if(e===t||typeof document>"u")return!0;const o=document.querySelector(`.protyle-wysiwyg [data-node-id="${t}"]`)||document.querySelector(`[data-node-id="${t}"]`);if(!o)return!1;const i=o.querySelector(":scope > [data-node-id], :scope > div > [data-node-id]");return(i==null?void 0:i.getAttribute("data-node-id"))===e}function qw(e){let t=null;function o(c="已同步"){e.saveStatus.value=c,t&&(typeof window<"u"?window.clearTimeout(t):clearTimeout(t));const u=()=>{e.saveStatus.value=""};typeof window<"u"?t=window.setTimeout(u,1200):t=setTimeout(u,1200)}async function i(c){var d;const u=e.activeBlockId.value||e.currentDocId.value;if(!u)return;for(const[b,m]of Object.entries(c))e.activeBlockAttrs.value[b]=m;Ee.setBlockAttrOverride(u,c),et(u,c);const f=(d=e.parentContainerId)==null?void 0:d.value,h=!!(f&&Ww(u,f));if(Ne in c&&h&&f){const b=c[Ne];e.parentContainerClicks&&(e.parentContainerClicks.value=b),Ee.setBlockAttrOverride(f,{[Ne]:b}),et(f,{[Ne]:b}),ze(f,{[Ne]:b}).catch(()=>{})}if(be in c){const b=c[be];e.currentPageDividerLayout.value=b,e.targetSlide.value&&(e.targetSlide.value.frontmatter||(e.targetSlide.value.frontmatter={}),e.targetSlide.value.frontmatter.layout=b)}if(bt in c){const b=c[bt];e.targetSlide.value&&(e.targetSlide.value.frontmatter||(e.targetSlide.value.frontmatter={}),e.targetSlide.value.frontmatter.layoutRatio=b)}o("保存中...");try{await ze(u,c),o("已同步"),e.plugin&&await e.plugin.compileCurrentDocument()}catch{o("同步失败")}}async function n(c,u){await i({[c]:u})}function s(){var u;return(e.activeBlockType.value==="NodeThematicBreak"||e.activeBlockType.value==="NodeThematicBreakBlock"||e.activeBlockType.value==="hr"||e.activeBlockType.value==="thematicbreak")&&e.activeBlockId.value?e.activeBlockId.value:e.currentPageDividerId.value?e.currentPageDividerId.value:(u=e.targetSlide.value)!=null&&u.startBlockId&&e.targetSlide.value.startBlockId!==e.currentDocId.value?e.targetSlide.value.startBlockId:e.currentDocId.value}async function l(c,u){const f=s();if(f){f===e.activeBlockId.value&&(e.activeBlockAttrs.value[c]=u),Ee.setBlockAttrOverride(f,{[c]:u}),et(f,{[c]:u}),c===be&&(e.currentPageDividerLayout.value=u,e.targetSlide.value&&(e.targetSlide.value.frontmatter||(e.targetSlide.value.frontmatter={}),e.targetSlide.value.frontmatter.layout=u)),c===bt&&e.targetSlide.value&&(e.targetSlide.value.frontmatter||(e.targetSlide.value.frontmatter={}),e.targetSlide.value.frontmatter.layoutRatio=u),o("保存中...");try{await ze(f,{[c]:u}),o("已同步"),e.plugin&&await e.plugin.compileCurrentDocument()}catch{o("同步失败")}}}async function r(c,u){const f=s();if(!f)return;const h={[be]:c,[bt]:u};f===e.activeBlockId.value&&(e.activeBlockAttrs.value[be]=c,e.activeBlockAttrs.value[bt]=u),e.currentPageDividerLayout.value=c,Ee.setBlockAttrOverride(f,h),et(f,h),e.targetSlide.value&&(e.targetSlide.value.frontmatter||(e.targetSlide.value.frontmatter={}),e.targetSlide.value.frontmatter.layout=c,e.targetSlide.value.frontmatter.layoutRatio=u),o("应用排版中...");try{await ze(f,h),o("已应用分栏与比例"),e.plugin&&await e.plugin.compileCurrentDocument()}catch{o("应用失败")}}async function a(c,u){var h;const f=e.currentDocId.value||e.activeBlockId.value;if(f){e.activeBlockAttrs.value[c]=u,Ee.setBlockAttrOverride(f,{[c]:u}),et(f,{[c]:u}),(h=e.latestDoc.value)!=null&&h.config&&(c===Vi&&(e.latestDoc.value.config.theme=u),c===Ki&&(e.latestDoc.value.config.aspectRatio=u),c===Gi&&(e.latestDoc.value.config.defaultTransition=u),c===Mn&&(e.latestDoc.value.config.background=u)),o("更新中...");try{await ze(f,{[c]:u}),o("已更新"),e.plugin&&await e.plugin.compileCurrentDocument(f)}catch{o("更新失败")}}}return{triggerSaveNotice:o,saveAttrs:i,saveAttr:n,getPageTargetBlockId:s,savePageAttr:l,applyPageLayoutAndRatio:r,saveDocAttr:a}}function Vw(e){const t=(e||"").trim().toLowerCase();return t==="anthropic"||t==="anthropic-messages"?"anthropic-messages":t==="openai-responses"?"openai-responses":t==="systemone"||t==="system-one"||t==="jev"||t==="typesafe"?"systemone":"openai"}function Kw(e){const t=[{"content-type":"application/json"},{Authorization:`Bearer ${e.apiKey.trim()}`},{Accept:"application/json"}];if(e.headers&&typeof e.headers=="object")for(const[o,i]of Object.entries(e.headers))o&&i!==void 0&&i!==null&&t.push({[o]:String(i)});return t}function Gw(e){var i,n;if(!e||typeof e!="object")return null;const t=(i=e.choices)==null?void 0:i[0];if(!t)return null;const o=((n=t.message)==null?void 0:n.content)??t.text;return typeof o=="string"&&o.trim().length>0?o.trim():null}async function Yw(e,t,o){const i=t.baseUrl.replace(/\/+$/,""),n=i.endsWith("/chat/completions")?i:`${i}/chat/completions`,s={model:t.model,messages:e,max_tokens:t.maxTokens??4096,temperature:t.temperature??.7},l=Math.max(1,t.requestTimeoutSeconds||60)*1e3,r=Kw(t),a=await ja(n,"POST",s,r,l,"application/json");if(!a||a.status<200||a.status>=300){const f=typeof(a==null?void 0:a.body)=="string"?a.body.slice(0,200):"";throw new Error(`AI 请求失败 (HTTP ${(a==null?void 0:a.status)??"未知"})${f?`: ${f}`:""}`)}let c;try{c=typeof a.body=="string"?JSON.parse(a.body||"{}"):a.body}catch{throw new Error("AI 接口返回了非法的 JSON 响应")}const u=Gw(c);if(!u)throw new Error("AI 接口未返回有效的文本内容");return u}async function rs(e){const t=kr();if(!t)return null;try{return await Yw([{role:"system",content:"你是一位专业的幻灯片演讲教练与内容设计专家。请根据用户提供的幻灯片内容提供精炼、准确的输出。"},{role:"user",content:e}],t.config)}catch(o){throw console.warn("[LiveSlides AI] request failed:",(o==null?void 0:o.message)||o),o}}async function Zw(e){var r,a;if(!Wn(e))return{success:!1,message:"配置不完整：请先补充 Base URL、API Key 和 Model"};const t=Date.now(),o=e.baseUrl.trim().replace(/\/+$/,""),i=e.apiKey.trim(),n=e.model.trim(),s=Vw(e.protocol),l=Math.max(5,e.requestTimeoutSeconds||15);try{const c={displayName:"Live Slides AI",apiKey:i,baseURL:o,protocol:s,requestTimeout:l,headers:e.headers||{},models:[]},u=await ie.fetchSyncPost("/api/ai/testModel",{providerConfig:c,model:n});if(u&&u.code===0&&((r=u.data)!=null&&r.matched)&&!((a=u.data)!=null&&a.msg)){const f=Date.now()-t;return{success:!0,message:`测试成功（耗时 ${f}ms）：已通过思源内核验证模型并完成对话测试`,elapsed:f}}}catch{}try{let c,u,f;if(s==="anthropic-messages"?(c=/\/v1$/i.test(o)?`${o}/messages`:`${o}/v1/messages`,u=[{"content-type":"application/json"},{"anthropic-version":"2023-06-01"}],i&&u.push({"x-api-key":i}),f={model:n,max_tokens:1,messages:[{role:"user",content:"hi"}]}):s==="openai-responses"?(c=/\/responses$/i.test(o)?o:`${o}/responses`,u=[{"content-type":"application/json"}],i&&u.push({Authorization:`Bearer ${i}`}),f={model:n,max_output_tokens:16,stream:!1,input:"hi"}):(c=/\/chat\/completions$/i.test(o)?o:`${o}/chat/completions`,u=[{"content-type":"application/json"}],i&&u.push({Authorization:`Bearer ${i}`}),f={model:n,max_tokens:1,stream:!1,messages:[{role:"user",content:"hi"}]}),e.headers&&typeof e.headers=="object")for(const[g,x]of Object.entries(e.headers))g&&x!==void 0&&x!==null&&u.push({[g]:String(x)});const h=await ja(c,"POST",f,u,l*1e3,"application/json"),d=Date.now()-t,b=(h==null?void 0:h.status)??0,m=typeof(h==null?void 0:h.body)=="string"?h.body:"";if(b>=200&&b<300)return{success:!0,message:`连接成功（耗时 ${d}ms），服务商响应正常`,elapsed:d};const y=m.slice(0,160);return b===401||b===403?{success:!1,message:`鉴权失败 (HTTP ${b})：请检查 API Key 是否有效${y?` (${y})`:""}`,elapsed:d}:b===404?{success:!1,message:"端点未找到 (HTTP 404)：请检查 API 基础地址 (Base URL) 是否正确（OpenAI 兼容地址通常需以 /v1 结尾）",elapsed:d}:b===429?{success:!1,message:"请求被限流或余额不足 (HTTP 429)：请检查服务商账户额度与频率限制",elapsed:d}:b===400?{success:!1,message:`请求参数错误 (HTTP 400)：模型「${n}」可能不存在或不可用 (${y})`,elapsed:d}:b>=500?{success:!1,message:`服务商服务器错误 (HTTP ${b})：${y}`,elapsed:d}:{success:!1,message:`服务响应异常 (HTTP ${b})：${y||"请检查配置或网络"}`,elapsed:d}}catch(c){const u=Date.now()-t;return{success:!1,message:`网络或思源内核代理请求失败: ${(c==null?void 0:c.message)||c}`,elapsed:u}}}function Tc(e){var i,n;if(!e)return"";const t=[],o=(e.content||e.rawMarkdown||e.markdown||((i=e.rawNode)==null?void 0:i.content)||((n=e.rawNode)==null?void 0:n.markdown)||"").trim();if(o&&o!=="---"){const s=o.replace(/\{:\s*[^}]+\s*\}\s*$/g,"").trim();s&&s!=="---"&&t.push(s)}if(Array.isArray(e.children)&&e.children.length>0)for(const s of e.children){const l=Tc(s);l&&t.push(l)}return t.join(`
`)}function Ac(e){if(!e)return"";const t=[];if(Array.isArray(e.blocks)&&e.blocks.length>0)for(const i of e.blocks){if(i.slot==="slot-divider-right"||i.content==="::right::"||i.isNote)continue;const n=Tc(i);n&&t.push(n)}let o=t.join(`

`).trim();if(!o&&e.rawMarkdown&&(o=e.rawMarkdown.replace(/^---\s*$/gm,"").trim()),!o&&e.frontmatter){const i=[];e.frontmatter.title&&i.push(`幻灯片标题: ${e.frontmatter.title}`),e.frontmatter.description&&i.push(`幻灯片描述: ${e.frontmatter.description}`),e.frontmatter.layout&&e.frontmatter.layout!=="default"&&i.push(`版式布局: ${e.frontmatter.layout}`),e.frontmatter.image&&i.push(`页面配图: ${e.frontmatter.image}`),i.length>0&&(o=i.join(`
`))}return o}async function Mc(e,t=rs){const o=Ac(e);if(!o)return{notes:"",isAiGenerated:!1,error:"当前幻灯片尚未填写正文内容，请先输入幻灯片标题或段落后再调用 AI 提炼"};if(t){const i=`你是一位专业的演讲教练。请根据以下幻灯片内容，提炼出简短精炼的演讲口播提词卡（Notes），包含核心观点与口播要点，总字数在 150 字以内：
${o}`;try{const n=await t(i);return n&&n.trim()?{notes:n.trim(),isAiGenerated:!0}:{notes:"",isAiGenerated:!1,error:"AI 服务未配置或未返回可用提词内容"}}catch(n){return{notes:"",isAiGenerated:!1,error:(n==null?void 0:n.message)||"AI 调用异常"}}}return{notes:"",isAiGenerated:!1,error:"未配置 AI 提词服务"}}async function Jw(e,t=rs){const o=await Mc(e,t);if(o.error)throw new Error(o.error);return o.notes}function Xw(e){if(!e)return!1;const t=String(e.type||"").toLowerCase();return!!(t==="callout"||t==="nodecallout"||t==="b"||t==="nodeblockquote"||String(e.markdown||"").trim().startsWith(">"))}function Qw(e,t){if(!((t==null?void 0:t[Fe])==="true"))return!1;const i=(e||"").trim();return/^>\s*\[!NOTE\]\s*(?:💡\s*)?(?:演讲备注|讲稿备注)/i.test(i)}async function Ec(e,t){const i=await((t==null?void 0:t.getChildBlocksFn)||Ci)(e).catch(()=>[]);if(!Array.isArray(i)||i.length===0)return[];const n=[];let s=[];for(const r of i){if(wo({...r,ial:{...r.ial||{},...Ee.getBlockAttrOverride(r.id)||{}}})){if(n.length===0&&s.length===0)continue;n.push(s),s=[];continue}s.push(r)}n.push(s);const l=[];for(let r=0;r<n.length;r++){const a=n[r];if(!a||a.length===0)continue;let c=null;for(let b=a.length-1;b>=0;b--){const m=a[b];if(!((m.type==="p"||m.type==="NodeParagraph")&&!(m.content||"").trim()&&!(m.markdown||"").trim())){c=m;break}}if(!c||!Xw(c))continue;const u=Ee.getBlockAttrOverride(c.id)||{};let f={...c.ial||{},...u};if(!f[Fe]&&(t!=null&&t.getBlockAttrsFn)){const b=await t.getBlockAttrsFn(c.id).catch(()=>({}));f={...f,...b,...u}}let h=c.markdown||c.content||"";if(t!=null&&t.getBlockKramdownFn)try{const b=await t.getBlockKramdownFn(c.id);b!=null&&b.kramdown&&(h=b.kramdown)}catch{}if(Qw(h,f))continue;const d=Sr(h)||h.replace(/<[^>]+>/g,"").trim();l.push({id:c.id,pageIndex:r+1,type:c.type,sourceMarkdown:h,cleanContent:d||"在此输入本页讲稿提词..."})}return l}async function Bc(e,t,o){const i=(o==null?void 0:o.updateBlockFn)||Ms,n=(o==null?void 0:o.setBlockAttrsFn)||ze,s=(o==null?void 0:o.syncDomFn)||et,r=`> [!NOTE] 💡 演讲备注
${t.split(/\r?\n/).map(a=>`> ${a}`).join(`
`)}
{: ${Fe}="true"}`;await i("markdown",r,e),await n(e,{[Fe]:"true"}),Ee.setBlockAttrOverride(e,{[Fe]:"true"}),s(e,{[Fe]:"true"})}async function Lc(e,t){const o=(t==null?void 0:t.showMessageFn)||ie.showMessage,i=(t==null?void 0:t.confirmFn)||ie.confirm;if(!e)return o("请先在主编辑区打开幻灯片文档"),{totalScanned:0,matchedCount:0,successCount:0,errorCount:0};const n=await Ec(e,t);if(n.length===0)return o("未发现待规范化的候选讲稿块"),{totalScanned:0,matchedCount:0,successCount:0,errorCount:0};const s=n.length;return new Promise(l=>{i("识别讲稿块",`扫描检测到 ${s} 处候选讲稿块（提示块或引用块），是否确认将其规范化为标准演讲备注？`,async()=>{var c;o(`正在批量规范化 ${s} 个讲稿块...`);let r=0,a=0;for(const u of n)try{await Bc(u.id,u.cleanContent,t),r++}catch(f){console.error(`[SiYuanLiveSlides] 规范化讲稿块 ${u.id} 失败:`,f),a++}(c=t==null?void 0:t.onSuccessNotice)==null||c.call(t,"已规范化讲稿"),o(`已成功识别并规范化 ${r} 个讲稿块`),t!=null&&t.compileFn&&await t.compileFn().catch(()=>{}),l({totalScanned:s,matchedCount:s,successCount:r,errorCount:a})},()=>{l({totalScanned:s,matchedCount:s,successCount:0,errorCount:0})})})}function e2(e,t){const o=he(!1),i=he(!1),{triggerSaveNotice:n}=t;async function s(g){var N,F,E,O,S,W,j,_;const I=`> [!NOTE] 💡 演讲备注
${(g||"在此输入本页讲稿提词...").split(/\r?\n/).map(M=>`> ${M}`).join(`
`)}
{: custom-slides-note="true"}`,T=((N=e.latestDoc.value)==null?void 0:N.slides)||[],w=e.targetSlide.value,C=w?T.findIndex(M=>M===w):-1;let L=null;if(C!==-1&&C<T.length-1){const M=T[C+1];L=await mo("markdown",I,M.startBlockId)}else{const M=((F=w==null?void 0:w.noteBlocks)==null?void 0:F.slice(-1)[0])||((E=w==null?void 0:w.blocks)==null?void 0:E.slice(-1)[0]),B=(M==null?void 0:M.id)||(w==null?void 0:w.startBlockId);B?L=await mo("markdown",I,void 0,B):L=await vn("markdown",I,e.currentDocId.value)}const R=((W=(S=(O=L==null?void 0:L[0])==null?void 0:O.doOperations)==null?void 0:S[0])==null?void 0:W.id)||((j=L==null?void 0:L[0])==null?void 0:j.id);return R&&(await ze(R,{[Fe]:"true"}),Ee.setBlockAttrOverride(R,{[Fe]:"true"}),zo(R,(_=e.plugin)==null?void 0:_.app)),e.plugin&&await e.plugin.compileCurrentDocument(),R}async function l(){const g=e.activeBlockId.value;if(g)if(e.isNoteBlock.value){n("取消中...");try{await ze(g,{[Fe]:""}),Ee.setBlockAttrOverride(g,{[Fe]:""}),et(g,{[Fe]:""}),delete e.activeBlockAttrs.value[Fe],n("已取消备注"),ie.showMessage("已取消讲稿备注"),e.plugin&&await e.plugin.compileCurrentDocument()}catch(x){console.error("[SiYuanLiveSlides] 取消讲稿备注失败:",x),n("取消失败"),ie.showMessage("取消讲稿备注失败")}}else{n("转换中...");try{let x=e.rawSnippet.value;try{const w=await Bd(g);w!=null&&w.kramdown&&(x=w.kramdown)}catch{}const T=`> [!NOTE] 💡 演讲备注
${(Sr(x)||x.replace(/<[^>]+>/g,"").trim()||"在此输入本页讲稿提词...").split(/\r?\n/).map(w=>`> ${w}`).join(`
`)}
{: custom-slides-note="true"}`;await Ms("markdown",T,g),await ze(g,{[Fe]:"true"}),Ee.setBlockAttrOverride(g,{[Fe]:"true"}),et(g,{[Fe]:"true"}),e.activeBlockAttrs.value[Fe]="true",e.activeBlockType.value="NodeCallout",n("已设为讲稿备注"),ie.showMessage("已转为讲稿备注提示块（不在幻灯片中渲染）"),e.plugin&&await e.plugin.compileCurrentDocument()}catch(x){console.error("[SiYuanLiveSlides] 转换讲稿备注提示块失败:",x),n("设置失败"),ie.showMessage("转为讲稿备注提示块失败")}}}async function r(){try{await s(),ie.showMessage("已在正文末尾插入讲稿备注提示块")}catch(g){ie.showMessage("插入讲稿备注块失败"),console.error(g)}}function a(){var k;const g=e.currentSlideNoteBlockId.value;if(!g){ie.showMessage("未找到本页关联的讲稿备注块");return}zo(g,(k=e.plugin)==null?void 0:k.app)?ie.showMessage("已在编辑区定位讲稿备注块"):ie.showMessage("定位讲稿备注块失败")}async function c(){var w,C,L,R,N,F,E,O,S,W,j;const g=e.currentDocId.value||((w=e.plugin)==null?void 0:w.currentDocId)||"";if(!g){ie.showMessage("未检测到当前文档，请先在编辑器中打开幻灯片文档",5e3,"error");return}if(!kr()){ie.showMessage("未配置 AI 提词服务，请前往高级设置填写 API 配置或通过「API 旋钮 (siyuan-api-switch)」接管",6e3,"error");return}if(i.value)return;const{slides:k}=await f();let I=e.targetSlide.value;!I&&k.length>0&&(I=Ic(k,{activeBlockId:e.activeBlockId.value,activeBlockType:e.activeBlockType.value,currentPageDividerId:e.currentPageDividerId.value,activeBlockAttrs:e.activeBlockAttrs.value}));const T=Ac(I);if(!I||!T){ie.showMessage("当前幻灯片无有效正文内容，请先输入标题或段落后再提炼讲稿",5e3,"info");return}i.value=!0;try{ie.showMessage("正在调用 AI 提炼本页讲稿提词...");const _=await Mc(I,rs);if(_.error){ie.showMessage(`AI 提炼提词卡失败：${_.error}`,6e3,"error");return}if(_.notes){const M=((L=(C=I.noteBlocks)==null?void 0:C[0])==null?void 0:L.id)||e.currentSlideNoteBlockId.value;if(M){const B=`> [!NOTE] 💡 演讲备注
${_.notes.split(/\r?\n/).map(Q=>`> ${Q}`).join(`
`)}
{: custom-slides-note="true"}`;await Ms("markdown",B,M),await ze(M,{[Fe]:"true"}),Ee.setBlockAttrOverride(M,{[Fe]:"true"}),zo(M,(R=e.plugin)==null?void 0:R.app)}else{const B=k.findIndex(Q=>Q===I);if(B!==-1){const q=`> [!NOTE] 💡 演讲备注
${_.notes.split(/\r?\n/).map(oe=>`> ${oe}`).join(`
`)}
{: custom-slides-note="true"}`;let U=null;if(B<k.length-1){const oe=k[B+1];U=await mo("markdown",q,oe.startBlockId)}else{const oe=((N=I.noteBlocks)==null?void 0:N.slice(-1)[0])||((F=I.blocks)==null?void 0:F.slice(-1)[0]),ae=(oe==null?void 0:oe.id)||I.startBlockId;ae?U=await mo("markdown",q,void 0,ae):U=await vn("markdown",q,g)}const ne=((S=(O=(E=U==null?void 0:U[0])==null?void 0:E.doOperations)==null?void 0:O[0])==null?void 0:S.id)||((W=U==null?void 0:U[0])==null?void 0:W.id);ne&&(await ze(ne,{[Fe]:"true"}),Ee.setBlockAttrOverride(ne,{[Fe]:"true"}),zo(ne,(j=e.plugin)==null?void 0:j.app))}else await s(_.notes)}ie.showMessage("AI 演讲提词卡生成成功！"),e.plugin&&await e.plugin.compileCurrentDocument()}}catch(_){ie.showMessage(`AI 提炼提词卡异常：${(_==null?void 0:_.message)||_}`,6e3,"error")}finally{i.value=!1}}const u=`> [!NOTE] 💡 演讲备注
${"在此输入本页讲稿提词...".split(/\r?\n/).map(k=>`> ${k}`).join(`
`)}
{: custom-slides-note="true"}`;async function f(){var I,T;const g=e.currentDocId.value||((I=e.plugin)==null?void 0:I.currentDocId)||"",x=(T=e.latestDoc.value)==null?void 0:T.slides;if(Array.isArray(x)&&x.length>0)return{docId:g,slides:x};if(!g)return{docId:"",slides:[]};const k=await Ee.compile(g).catch(()=>null);return{docId:g,slides:(k==null?void 0:k.slides)||[]}}async function h(g,x,k,I){var C,L,R,N,F,E;let T=null;if(x<k.length-1){const O=k[x+1];T=await mo("markdown",u,O.startBlockId)}else{const O=((C=g==null?void 0:g.noteBlocks)==null?void 0:C.slice(-1)[0])||((L=g==null?void 0:g.blocks)==null?void 0:L.slice(-1)[0]),S=(O==null?void 0:O.id)||(g==null?void 0:g.startBlockId);S?T=await mo("markdown",u,void 0,S):T=await vn("markdown",u,I||e.currentDocId.value)}const w=((F=(N=(R=T==null?void 0:T[0])==null?void 0:R.doOperations)==null?void 0:N[0])==null?void 0:F.id)||((E=T==null?void 0:T[0])==null?void 0:E.id);w&&(await ze(w,{[Fe]:"true"}),Ee.setBlockAttrOverride(w,{[Fe]:"true"}))}async function d(){if(o.value)return;const{docId:g,slides:x}=await f();if(x.length===0){ie.showMessage("当前文档无幻灯片页面");return}const k=x.map((T,w)=>({slide:T,idx:w})).filter(({slide:T})=>{var L;const w=Array.isArray(T.noteBlocks)&&T.noteBlocks.length>0,C=!!((L=T.notes)!=null&&L.trim());return!w&&!C});if(k.length===0){ie.showMessage("所有幻灯片页面均已存在讲稿备注块，无需追加");return}const I=k.length;ie.confirm("批量追加讲稿备注",`将在未配置讲稿的 ${I} 页末尾自动插入讲稿提示块，是否继续？`,async()=>{if(o.value)return;o.value=!0,ie.showMessage("正在批量追加讲稿块...");let T=0;try{for(const{slide:w,idx:C}of k)try{await h(w,C,x,g),T++}catch(L){console.error(`[SiYuanLiveSlides] 为第 ${C+1} 页追加讲稿块失败:`,L)}e.plugin&&await e.plugin.compileCurrentDocument(),ie.showMessage(`已成功为 ${T} 页追加讲稿备注块`)}catch(w){console.error("[SiYuanLiveSlides] 批量追加讲稿块失败:",w),ie.showMessage("批量追加讲稿块时出现异常")}finally{o.value=!1}})}async function b(){if(o.value)return;const{slides:g}=await f();if(g.length===0){ie.showMessage("当前文档无幻灯片页面");return}const x=[];for(const T of g)if(T.noteBlocks&&T.noteBlocks.length>0)for(const w of T.noteBlocks)w.id&&x.push({id:w.id,pageIndex:T.pageIndex});if(x.length===0){ie.showMessage("当前文档中没有讲稿备注块，无需删除");return}const k=new Set(x.map(T=>T.pageIndex)).size,I=x.length;ie.confirm("危险操作：批量删除所有讲稿块",`此操作将从正文中物理删除全部 ${I} 个讲稿备注块（涉及 ${k} 页），删除后无法撤销。是否确认继续？`,async()=>{if(o.value)return;o.value=!0,ie.showMessage("正在批量删除讲稿块...");let T=0;try{for(const w of x)try{await Qs(w.id),Ee.clearBlockAttrOverride(w.id),T++}catch(C){console.error(`[SiYuanLiveSlides] 删除讲稿块 ${w.id} 失败:`,C)}e.activeBlockId.value&&x.some(w=>w.id===e.activeBlockId.value)&&delete e.activeBlockAttrs.value[Fe],e.plugin&&await e.plugin.compileCurrentDocument(),ie.showMessage(`已成功删除全部 ${T} 个讲稿备注块`)}catch(w){console.error("[SiYuanLiveSlides] 批量删除讲稿块失败:",w),ie.showMessage("批量删除讲稿块时出现异常")}finally{o.value=!1}})}async function m(){var x;const g=e.currentDocId.value||((x=e.plugin)==null?void 0:x.currentDocId);if(!g){ie.showMessage("请先在主编辑区打开幻灯片文档");return}if(o.value){ie.showMessage("正在批量处理中，请稍候...");return}o.value=!0;try{await Lc(g,{onSuccessNotice:n,compileFn:async()=>{e.plugin&&await e.plugin.compileCurrentDocument()}})}finally{o.value=!1}}async function y(){if(o.value){ie.showMessage("正在批量处理中，请稍候...");return}const{docId:g,slides:x}=await f();if(!g){ie.showMessage("请先在主编辑区打开幻灯片文档");return}if(x.length===0){ie.showMessage("当前文档无幻灯片页面");return}const k=await Ec(g),I=new Set(k.map(C=>C.pageIndex)),T=x.map((C,L)=>({slide:C,idx:L})).filter(({slide:C,idx:L})=>{var E;const R=Array.isArray(C.noteBlocks)&&C.noteBlocks.length>0,N=!!((E=C.notes)!=null&&E.trim()),F=C.pageIndex??L+1;return!R&&!N&&!I.has(F)});if(k.length===0&&T.length===0){ie.showMessage("所有幻灯片页面均已存在讲稿备注块，无需重复操作");return}let w="";k.length>0&&T.length>0?w=`扫描检测到 ${k.length} 处已有候选讲稿待规范化，另有 ${T.length} 页暂无讲稿将新增默认讲稿块，是否继续？`:k.length>0?w=`扫描检测到 ${k.length} 处已有候选讲稿块（提示块或引用块），是否规范化为标准演讲备注？`:w=`将在未配置讲稿的 ${T.length} 页末尾自动增加默认讲稿提示块，是否继续？`,ie.confirm("增加讲稿块",w,async()=>{if(o.value)return;o.value=!0,ie.showMessage("正在处理讲稿块...");let C=0,L=0;try{for(const R of k)try{await Bc(R.id,R.cleanContent),C++}catch(N){console.error(`[SiYuanLiveSlides] 规范化讲稿块 ${R.id} 失败:`,N)}for(const{slide:R,idx:N}of T)try{await h(R,N,x,g),L++}catch(F){console.error(`[SiYuanLiveSlides] 为第 ${N+1} 页增加讲稿块失败:`,F)}e.plugin&&await e.plugin.compileCurrentDocument(),n("已更新讲稿"),C>0&&L>0?ie.showMessage(`已规范化 ${C} 处现有讲稿，并为 ${L} 页新增讲稿块`):C>0?ie.showMessage(`已成功识别并规范化 ${C} 个讲稿块`):ie.showMessage(`已成功为 ${L} 页增加讲稿备注块`)}catch(R){console.error("[SiYuanLiveSlides] 增加讲稿块失败:",R),ie.showMessage("增加讲稿块时出现异常")}finally{o.value=!1}})}return{isBatchProcessing:o,isGeneratingNotes:i,createNoteBlockOnCurrentSlide:s,onToggleNoteBlock:l,onAddNoteBlock:r,onLocateNoteBlock:a,onGenerateNotesWithAI:c,onBatchAppendNotes:d,onBatchDeleteNotes:b,onIdentifyNotesBlocks:m,onAddOrIdentifyNotesBlocks:y}}function t2(e){if(!e)return!1;const t=String(e.type||"").toLowerCase();if(t==="h"||t==="nodeheading")return!0;const o=String(e.subType||"").toLowerCase();if(/^h[1-6]$/.test(o))return!0;const i=String(e.rawMarkdown||e.markdown||"").trim();return!!/^#{1,6}\s+/.test(i)}function o2(e){if(!e)return!1;const t=String(e.type||"").toLowerCase();return t==="i"||t==="nodelistitem"}function i2(e){const t=[],o=i=>{var n,s,l,r,a,c,u,f,h;for(const d of i){if(!d||d.isNote||((n=d.attributes)==null?void 0:n[Fe])==="true"||((s=d.ial)==null?void 0:s[Fe])==="true"||d.type==="tb"||d.type==="thematic-break"||d.type==="NodeThematicBreak"||String(d.markdown||d.rawMarkdown||"").trim()==="---"||d.slot==="slot-divider-right"||String(d.rawMarkdown||d.markdown||"").trim()==="::right::")continue;if(t2(d)){t.push({id:d.id,type:d.type,isHeading:!0,currentClicks:d.clicks||((l=d.attributes)==null?void 0:l[Ne])||((r=d.ial)==null?void 0:r[Ne]),rawBlock:d});continue}if(o2(d)){t.push({id:d.id,type:d.type||"i",isHeading:!1,currentClicks:d.clicks||((a=d.attributes)==null?void 0:a[Ne])||((c=d.ial)==null?void 0:c[Ne]),rawBlock:d});continue}const b=d.children&&d.children.length>0?d.children:(u=d.rawNode)==null?void 0:u.children;if(Array.isArray(b)&&b.length>0){o(b);continue}t.push({id:d.id,type:d.type,isHeading:!1,currentClicks:d.clicks||((f=d.attributes)==null?void 0:f[Ne])||((h=d.ial)==null?void 0:h[Ne]),rawBlock:d})}};return o(e||[]),t}function n2(e){var n;if(e.pageIndex===1||((n=e.frontmatter)==null?void 0:n.layout)==="cover")return[];const t=i2(e.blocks||[]);if(t.length===0)return[];let o=-1;for(let s=0;s<t.length;s++)if(!t[s].isHeading){o=s;break}if(o===-1)return[];const i=[];for(let s=o+1;s<t.length;s++){const l=t[s];!!!(l.currentClicks&&String(l.currentClicks).trim()!=="")&&l.id&&i.push({blockId:l.id,pageIndex:e.pageIndex,targetClick:"+1"})}return i}async function s2(e,t){const i=await((t==null?void 0:t.compileDocFn)||(l=>Ee.compile(l)))(e).catch(()=>null);if(!i||!Array.isArray(i.slides)||i.slides.length===0)return{totalPages:0,animatedPagesCount:0,targets:[]};const n=[],s=new Set;for(const l of i.slides){const r=n2(l);r.length>0&&(n.push(...r),s.add(l.pageIndex))}return{totalPages:i.slides.length,animatedPagesCount:s.size,targets:n}}async function Dc(e,t){const o=(t==null?void 0:t.showMessageFn)||ie.showMessage,i=(t==null?void 0:t.confirmFn)||ie.confirm,n=(t==null?void 0:t.setBlockAttrsFn)||ze,s=(t==null?void 0:t.syncDomFn)||et;if(!e)return o("请先在主编辑区打开幻灯片文档"),{totalPages:0,animatedPagesCount:0,targets:[],successCount:0,errorCount:0};const l=await s2(e,t);if(l.targets.length===0)return o("未检测到需要配置顺延动效的后续块"),{...l,successCount:0,errorCount:0};const r=l.targets.length,a=l.animatedPagesCount;return new Promise(c=>{i("智能设置动效",`扫描检测到可为 ${a} 页中的 ${r} 个后续块配置顺延 (+1) 动效，是否继续？`,async()=>{var h;o(`正在批量配置 ${r} 个后续块动效...`);let u=0,f=0;for(const d of l.targets)try{await n(d.blockId,{[Ne]:d.targetClick}),Ee.setBlockAttrOverride(d.blockId,{[Ne]:d.targetClick}),s(d.blockId,{[Ne]:d.targetClick}),u++}catch(b){console.error(`[SiYuanLiveSlides] 为块 ${d.blockId} 配置动效失败:`,b),f++}(h=t==null?void 0:t.onSuccessNotice)==null||h.call(t,"已配置智能动效"),o(`已成功为 ${u} 个后续块配置顺延 (+1) 动效`),t!=null&&t.compileCurrentDocFn&&await t.compileCurrentDocFn().catch(()=>{}),c({...l,successCount:u,errorCount:f})},()=>{c({...l,successCount:0,errorCount:0})})})}async function r2(e,t){const i=await((t==null?void 0:t.compileDocFn)||(a=>Ee.compile(a)))(e).catch(()=>null);if(!i||!Array.isArray(i.slides)||i.slides.length===0)return{totalPages:0,affectedPagesCount:0,targets:[]};const n=[],s=new Set,l=new Set,r=(a,c)=>{var u,f,h,d,b;for(const m of a){if(!m)continue;if(m.id&&!s.has(m.id)){const g=Ee.getBlockAttrOverride(m.id),x=(g==null?void 0:g[Ne])??m.clicks??((u=m.attributes)==null?void 0:u[Ne])??((f=m.ial)==null?void 0:f[Ne]),k=(g==null?void 0:g[Bt])??m.motion??((h=m.attributes)==null?void 0:h[Bt])??((d=m.ial)==null?void 0:d[Bt]),I=!!(x&&String(x).trim()!==""),T=!!(k&&String(k).trim()!=="");(I||T)&&(s.add(m.id),n.push({blockId:m.id,pageIndex:c,hasClick:I,hasMotion:T}),l.add(c))}const y=m.children&&m.children.length>0?m.children:(b=m.rawNode)==null?void 0:b.children;Array.isArray(y)&&y.length>0&&r(y,c)}};for(const a of i.slides)r(a.blocks||[],a.pageIndex);return{totalPages:i.slides.length,affectedPagesCount:l.size,targets:n}}async function a2(e,t){const o=(t==null?void 0:t.showMessageFn)||ie.showMessage,i=(t==null?void 0:t.confirmFn)||ie.confirm,n=(t==null?void 0:t.setBlockAttrsFn)||ze,s=(t==null?void 0:t.syncDomFn)||et;if(!e)return o("请先在主编辑区打开幻灯片文档"),{totalPages:0,affectedPagesCount:0,targets:[],successCount:0,errorCount:0};const l=await r2(e,t);if(l.targets.length===0)return o("当前文档未检测到已配置的页面动效，无需清除"),{...l,successCount:0,errorCount:0};const r=l.targets.length,a=l.affectedPagesCount;return new Promise(c=>{i("危险操作：清除所有页面动效",`此操作将清除 ${a} 页中全部 ${r} 个内容块的逐步显现（v-click）与入场微动效（v-motion）配置，清除后无法撤销。是否确认继续？`,async()=>{var d;o(`正在清除 ${r} 个内容块的动效配置...`);let u=0,f=0;const h={[Ne]:"",[Bt]:""};for(const b of l.targets)try{await n(b.blockId,h),Ee.setBlockAttrOverride(b.blockId,h),s(b.blockId,h),u++}catch(m){console.error(`[SiYuanLiveSlides] 清除块 ${b.blockId} 动效失败:`,m),f++}(d=t==null?void 0:t.onSuccessNotice)==null||d.call(t,"已清除动效"),o(`已成功清除 ${u} 个内容块的动效配置`),t!=null&&t.compileCurrentDocFn&&await t.compileCurrentDocFn().catch(()=>{}),c({...l,successCount:u,errorCount:f})},()=>{c({...l,successCount:0,errorCount:0})})})}function l2(e,t){const{saveAttr:o,saveAttrs:i,savePageAttr:n}=t;async function s(){(e.videoAutoplay.value?"false":"true")==="true"?(await i({[Zo]:"true",[li]:"true"}),e.activeBlockAttrs.value[Zo]="true",e.activeBlockAttrs.value[li]="true"):(await o(Zo,"false"),e.activeBlockAttrs.value[Zo]="false")}async function l(){const N=e.videoLoop.value?"false":"true";await o(En,N)}async function r(){const N=e.videoMuted.value?"false":"true";await o(li,N)}async function a(){const N=e.videoControls.value?"false":"true";await o(Bn,N)}async function c(N){var W,j;const F=e.activeBlockId.value;if(!F)return;const E=e.rawSnippet.value||"",O=Co(E)||"",S=e.currentPageDividerId.value||e.currentDocId.value;if(N)if(N==="background"){const _={[Ze]:"background",[be]:""};S&&O&&(e.pageBackground&&(e.pageBackground.value=O),await ze(S,{[dt]:O}).catch(()=>{}),Ee.setBlockAttrOverride(S,{[dt]:O}),et(S,{[dt]:O}),e.targetSlide.value&&(e.targetSlide.value.frontmatter||(e.targetSlide.value.frontmatter={}),e.targetSlide.value.frontmatter.background=O)),await i(_)}else(N===Ln||N===Dn)&&await i({[be]:N,[Ze]:""});else{const _={[Ze]:"",[be]:""};if(e.activeBlockAttrs.value[dt]==="true"&&(_[dt]=""),S&&O&&((W=e.pageBackground)==null?void 0:W.value)===O&&(e.pageBackground&&(e.pageBackground.value=""),await ze(S,{[dt]:""}).catch(()=>{}),Ee.setBlockAttrOverride(S,{[dt]:""}),et(S,{[dt]:""}),(j=e.targetSlide.value)!=null&&j.frontmatter&&delete e.targetSlide.value.frontmatter.background),await i(_),typeof document<"u"){const M=document.querySelector(`.protyle-wysiwyg [data-node-id="${F}"]`),B=M==null?void 0:M.closest('[data-type="NodeListItem"]'),Q=B==null?void 0:B.getAttribute("data-node-id");if(Q&&Q!==F){const q={[be]:"",[Ze]:""};et(Q,q),Ee.setBlockAttrOverride(Q,q),await ze(Q,q).catch(()=>{})}}}}function u(){e.elemClick.value?o(Ne,""):o(Ne,"+1")}function f(N){o(Ne,N)}function h(N){o(Bt,N)}function d(N){(e.activeBlockAttrs.value[Ae]||"")===N?o(Ae,""):o(Ae,N)}function b(N){e.elemShikiLines.value=N,o(ti,N)}function m(N){const F=N?N.trim():"",E=/^\d+$/.test(F)?`${F}px`:F;e.elemMaxHeight.value=E,o(Yi,E)}async function y(){const N=e.currentSlideLayout.value==="three-cols-header";await o(Ae,N?"col-1":"left"),ie.showMessage(N?"已将当前块设置为第 1 栏":"已将当前块设置为双栏左栏")}async function g(){const N=e.activeBlockId.value;N&&ie.confirm("清除块演示属性","确定要清除当前块的所有演示属性（包含动画、插槽、备注等）吗？此操作无法撤销。",async()=>{const F={[Ne]:"",[Bt]:"",[Ae]:"",[ti]:"",[Yi]:"",[Fe]:"",[be]:"",[bt]:"",[Ze]:"",[It]:"",[dt]:"",[Kt]:"",[Zo]:"",[En]:"",[li]:"",[Bn]:""};if(et(N,F),await ze(N,F),Ee.clearBlockAttrOverride(N),typeof document<"u"){const E=document.querySelector(`.protyle-wysiwyg [data-node-id="${N}"]`),O=E==null?void 0:E.closest('[data-type="NodeListItem"]'),S=O==null?void 0:O.getAttribute("data-node-id");S&&S!==N&&(et(S,F),await ze(S,F).catch(()=>{}),Ee.clearBlockAttrOverride(S))}e.activeBlockAttrs.value={},e.elemShikiLines.value="",e.elemMaxHeight.value="",e.pageBackground&&(e.pageBackground.value=""),e.pageImage.value="",ie.showMessage("已清除本块演示属性"),e.plugin&&await e.plugin.compileCurrentDocument()})}async function x(){if(e.activeBlockId.value)try{await mo("markdown","---",e.activeBlockId.value,void 0),ie.showMessage("已在上方插入分页符"),e.plugin&&e.plugin.compileCurrentDocument()}catch{ie.showMessage("插入分页符失败")}}async function k(){const N=e.activeBlockId.value||e.currentDocId.value;if(N)try{await mo("markdown","---",void 0,N),ie.showMessage("已在下方插入分页符"),e.plugin&&e.plugin.compileCurrentDocument()}catch{ie.showMessage("插入分页符失败")}}async function I(){if(e.activeBlockId.value)try{await Qs(e.activeBlockId.value),ie.showMessage("已删除该分页符"),e.activeBlockId.value="",e.activeBlockType.value="",e.plugin&&e.plugin.compileCurrentDocument()}catch{ie.showMessage("删除失败")}}async function T(){var N,F;try{let E=null;if(typeof document<"u"){const S=e.activeBlockId.value;if(S){const W=document.querySelector(`.protyle-wysiwyg [data-node-id="${S}"]`);W&&(E=W.getAttribute("data-type")==="NodeSuperBlock"?W:W.closest('[data-type="NodeSuperBlock"]'))}if(!E){const W=e.currentPageDividerId.value||(e.activeBlockType.value==="hr"||e.activeBlockType.value==="NodeThematicBreak"?e.activeBlockId.value:"");if(W){const j=document.querySelector(`.protyle-wysiwyg [data-node-id="${W}"]`);if(j){let _=j.nextElementSibling;for(;_&&!(_.getAttribute("data-type")==="NodeThematicBreak"||(N=_.classList)!=null&&N.contains("protyle-wysiwyg__block--hr"));){const M=_.getAttribute("data-type")==="NodeSuperBlock"?_:_.querySelector('[data-type="NodeSuperBlock"]');if(M){E=M;break}_=_.nextElementSibling}}}else{const j=document.querySelector('.protyle-wysiwyg [data-type="NodeThematicBreak"], .protyle-wysiwyg .protyle-wysiwyg__block--hr'),_=Array.from(document.querySelectorAll('.protyle-wysiwyg [data-type="NodeSuperBlock"]'));for(const M of _)if(!j||M.compareDocumentPosition(j)&Node.DOCUMENT_POSITION_FOLLOWING){E=M;break}}}}const O=[];if(E){const S=Array.from(E.querySelectorAll(":scope > [data-node-id]"));for(const W of S){const j=W.getAttribute("data-node-id");j&&(O.push(j),W.removeAttribute("style"))}}else if((F=e.targetSlide.value)!=null&&F.blocks){for(const S of e.targetSlide.value.blocks)if(S.children&&S.children.length>=2){for(const W of S.children)W.id&&O.push(W.id);break}}if(O.length>0)for(const S of O)await ze(S,{style:""}).catch(()=>{});await n(bt,""),ie.showMessage("已重置超级块为平均分布比例"),e.plugin&&await e.plugin.compileCurrentDocument()}catch(E){console.error("[layout-actions] resetSuperBlockWidth error:",E),ie.showMessage("重置超级块比例失败")}}async function w(){var N,F,E;try{let O=null;if(typeof document<"u"){const W=e.currentPageDividerId.value||(e.activeBlockType.value==="hr"||e.activeBlockType.value==="NodeThematicBreak"?e.activeBlockId.value:""),j=e.activeBlockId.value;let _=[];if(W){const Q=document.querySelector(`.protyle-wysiwyg [data-node-id="${W}"]`);if(Q){let q=Q.nextElementSibling;for(;q&&!(q.getAttribute("data-type")==="NodeThematicBreak"||(N=q.classList)!=null&&N.contains("protyle-wysiwyg__block--hr"));)_.push(q),q=q.nextElementSibling}}else{const Q=document.querySelector('.protyle-wysiwyg [data-type="NodeThematicBreak"], .protyle-wysiwyg .protyle-wysiwyg__block--hr'),q=Array.from(document.querySelectorAll(".protyle-wysiwyg > [data-node-id]"));for(const U of q)if(!Q||U.compareDocumentPosition(Q)&Node.DOCUMENT_POSITION_FOLLOWING)_.push(U);else break}const M=[];let B;for(const Q of _){const q=Q.getAttribute("data-type");q==="NodeHeading"&&(B=Q.getAttribute("data-node-id")||void 0);const U=[];q==="NodeSuperBlock"?U.push(Q):U.push(...Array.from(Q.querySelectorAll('[data-type="NodeSuperBlock"]')));for(const ne of U){if((ne.getAttribute("data-sb-layout")||"").toLowerCase()==="row")continue;const ae=ne.getAttribute("data-node-id")||"";let Se=[];const $e=Array.from(ne.querySelectorAll('[data-type="NodeListItem"]'));if($e.length===4&&(Se=$e.map(ke=>ke.getAttribute("data-node-id")).filter(Boolean)),Se.length!==4){const ke=Array.from(ne.querySelectorAll(":scope > [data-node-id]"));ke.length===4&&(Se=ke.map(Ce=>Ce.getAttribute("data-node-id")).filter(Boolean))}Se.length===4&&M.push({sbId:ae,itemIds:Se,headerId:B})}}M.length>0&&(j&&(O=M.find(Q=>{if(Q.sbId===j||Q.itemIds.includes(j))return!0;const q=document.querySelector(`.protyle-wysiwyg [data-node-id="${Q.sbId}"]`),U=document.querySelector(`.protyle-wysiwyg [data-node-id="${j}"]`);return!!(q&&U&&q.contains(U))})||null),O||(O=M[0]))}if(!O&&((F=e.targetSlide.value)!=null&&F.blocks)){const W=e.targetSlide.value,j=[];for(const M of W.blocks)M.rawNode?j.push(M.rawNode):j.push({id:M.id,type:M.type,content:M.content,markdown:M.rawMarkdown,children:M.children,ial:M.attributes||M.ial||{}});const _=vp(j,e.activeBlockId.value);_&&_.items.length===4&&(O={sbId:_.superBlockNode.id,itemIds:_.items.map(M=>M.id),headerId:(E=_.headerNode)==null?void 0:E.id})}const S=e.currentPageDividerId.value||e.currentDocId.value;if(S&&(e.currentPageDividerLayout.value="clover",e.targetSlide.value&&(e.targetSlide.value.frontmatter||(e.targetSlide.value.frontmatter={}),e.targetSlide.value.frontmatter.layout="clover"),Ee.setBlockAttrOverride(S,{[be]:"clover"}),et(S,{[be]:"clover"}),await ze(S,{[be]:"clover"}).catch(()=>{})),O&&O.itemIds.length>0){O.headerId&&(Ee.setBlockAttrOverride(O.headerId,{[Ae]:"header"}),et(O.headerId,{[Ae]:"header"}),await ze(O.headerId,{[Ae]:"header"}).catch(()=>{}));const W=Math.min(4,O.itemIds.length);for(let j=0;j<W;j++){const _=O.itemIds[j],M=`col-${j+1}`;Ee.setBlockAttrOverride(_,{[Ae]:M}),et(_,{[Ae]:M}),await ze(_,{[Ae]:M}).catch(()=>{})}}return ie.showMessage("已将本页版式设为四叶草（田字型）布局"),e.plugin&&await e.plugin.compileCurrentDocument(),!0}catch(O){return console.error("[layout-actions] applyCloverLayout error:",O),ie.showMessage("配置四叶草布局失败",4e3,"error"),!1}}async function C(){var F,E;const N=e.currentDocId.value||((F=e.plugin)==null?void 0:F.currentDocId);if(!N){ie.showMessage("请先在主编辑区打开幻灯片文档");return}if((E=t.isBatchProcessing)!=null&&E.value){ie.showMessage("正在批量处理中，请稍候...");return}t.isBatchProcessing&&(t.isBatchProcessing.value=!0);try{await Dc(N,{onSuccessNotice:t.triggerSaveNotice,compileCurrentDocFn:async()=>{e.plugin&&await e.plugin.compileCurrentDocument()}})}finally{t.isBatchProcessing&&(t.isBatchProcessing.value=!1)}}async function L(){var F,E;const N=e.currentDocId.value||((F=e.plugin)==null?void 0:F.currentDocId);if(!N){ie.showMessage("请先在主编辑区打开幻灯片文档");return}if((E=t.isBatchProcessing)!=null&&E.value){ie.showMessage("正在批量处理中，请稍候...");return}t.isBatchProcessing&&(t.isBatchProcessing.value=!0);try{const O=await a2(N,{onSuccessNotice:t.triggerSaveNotice,compileCurrentDocFn:async()=>{e.plugin&&await e.plugin.compileCurrentDocument()}});O.successCount>0&&e.activeBlockId.value&&O.targets.some(S=>S.blockId===e.activeBlockId.value)&&(delete e.activeBlockAttrs.value[Ne],delete e.activeBlockAttrs.value[Bt])}finally{t.isBatchProcessing&&(t.isBatchProcessing.value=!1)}}async function R(){var E,O,S,W;const N=await jw({currentDocId:((E=e.currentDocId)==null?void 0:E.value)||"",activeBlockId:((O=e.activeBlockId)==null?void 0:O.value)||""});if(!N.success){ie.showMessage(N.error||"合并为横向超级块失败");return}const F=`🎉 已成功合并为横向超级块 (${N.colCount||2} 列)`;ie.showMessage(F),t.triggerSaveNotice&&t.triggerSaveNotice(F),(S=e.plugin)!=null&&S.compileCurrentDocument&&await e.plugin.compileCurrentDocument((W=e.currentDocId)==null?void 0:W.value)}return{onToggleVideoAutoplay:s,onToggleVideoLoop:l,onToggleVideoMuted:r,onToggleVideoControls:a,onImageRoleChange:c,toggleElemClick:u,onElemClickStepChange:f,onElemMotionChange:h,onElemSlotChange:d,onElemShikiLinesChange:b,onElemMaxHeightChange:m,onSetTwoColsContrast:y,onClearBlockAttrs:g,onInsertDividerBefore:x,onInsertDividerAfter:k,onDeleteCurrentBlock:I,onConvertToSuperBlock:R,resetSuperBlockWidth:T,applyCloverLayout:w,onAutoAnimateDocument:C,onClearAnimationsDocument:L}}function c2(e){const{triggerSaveNotice:t,saveAttrs:o,saveAttr:i,savePageAttr:n,applyPageLayoutAndRatio:s,saveDocAttr:l}=qw(e),r=e2(e,{triggerSaveNotice:t}),a=l2(e,{saveAttr:i,saveAttrs:o,savePageAttr:n,triggerSaveNotice:t,isBatchProcessing:r.isBatchProcessing});async function c(){var g;if(!e.latestDoc.value){ie.showMessage("请先在主编辑区打开幻灯片文档");return}const d=e.latestDoc.value,b=await Ho(d,(g=e.currentDocId)==null?void 0:g.value,e.plugin);ie.showMessage("正在导出单文件离线 HTML（内联媒体资源中...）",2e3);const m=await pc(d,{title:b});hc(`${b}.html`,m)&&ie.showMessage(`已开始下载单文件离线 HTML 演示包 (${b}.html)`)}function u(){if(!e.latestDoc.value){ie.showMessage("请先在主编辑区打开幻灯片文档");return}mc(e.latestDoc.value)&&ie.showMessage("已唤起打印视窗，请在打印选项中选择「另存为 PDF」")}const f=he(!1);async function h(){var d;if(f.value){ie.showMessage("正在导出图片中，请稍候...",2e3);return}if(!e.latestDoc.value){ie.showMessage("请先在主编辑区打开幻灯片文档");return}f.value=!0;try{ie.showMessage("正在启动后台沙箱并逐页导出幻灯片图片...");const b=e.latestDoc.value,m=await Ho(b,(d=e.currentDocId)==null?void 0:d.value,e.plugin),y=await kc(b,{title:m,onProgress:(g,x)=>{ie.showMessage(`正在导出幻灯片图片 (${g} / ${x})...`,2e3)}});y.success?ie.showMessage(`🎉 成功导出 ${y.total||0} 张幻灯片高清图片并已保存为 ${m}.zip！`,4e3):ie.showMessage(`导出图片失败：${y.error||"未知异常"}`)}finally{f.value=!1}}return{triggerSaveNotice:t,saveAttrs:o,saveAttr:i,savePageAttr:n,applyPageLayoutAndRatio:s,saveDocAttr:l,onToggleVideoAutoplay:a.onToggleVideoAutoplay,onToggleVideoLoop:a.onToggleVideoLoop,onToggleVideoMuted:a.onToggleVideoMuted,onToggleVideoControls:a.onToggleVideoControls,onImageRoleChange:a.onImageRoleChange,onToggleNoteBlock:r.onToggleNoteBlock,createNoteBlockOnCurrentSlide:r.createNoteBlockOnCurrentSlide,onAddNoteBlock:r.onAddNoteBlock,onLocateNoteBlock:r.onLocateNoteBlock,onGenerateNotesWithAI:r.onGenerateNotesWithAI,isGeneratingNotes:r.isGeneratingNotes,isBatchProcessing:r.isBatchProcessing,onBatchAppendNotes:r.onBatchAppendNotes,onBatchDeleteNotes:r.onBatchDeleteNotes,onIdentifyNotesBlocks:r.onIdentifyNotesBlocks,onAddOrIdentifyNotesBlocks:r.onAddOrIdentifyNotesBlocks,toggleElemClick:a.toggleElemClick,onElemClickStepChange:a.onElemClickStepChange,onElemMotionChange:a.onElemMotionChange,onElemSlotChange:a.onElemSlotChange,onElemShikiLinesChange:a.onElemShikiLinesChange,onElemMaxHeightChange:a.onElemMaxHeightChange,onSetTwoColsContrast:a.onSetTwoColsContrast,onClearBlockAttrs:a.onClearBlockAttrs,onInsertDividerBefore:a.onInsertDividerBefore,onInsertDividerAfter:a.onInsertDividerAfter,onDeleteCurrentBlock:a.onDeleteCurrentBlock,onConvertToSuperBlock:a.onConvertToSuperBlock,resetSuperBlockWidth:a.resetSuperBlockWidth,applyCloverLayout:a.applyCloverLayout,onAutoAnimateDocument:a.onAutoAnimateDocument,onClearAnimationsDocument:a.onClearAnimationsDocument,isExportingImages:f,onExportHtml:c,onExportPdf:u,onExportImages:h}}function d2(e){const t=ge(()=>Ir(e.activeBlockType.value));function o(i){const{attrKey:n,fallback:s,mode:l="defined"}=i,r=a=>l==="truthy"?a:a!==void 0;return ge(()=>{if(t.value){const c=e.activeBlockAttrs.value[n];if(r(c))return c}const a=e.currentPageDividerId.value||(t.value?e.activeBlockId.value:"");if(a){const c=Ee.getBlockAttrOverride(a);if(r(c==null?void 0:c[n]))return c[n]}return s()})}return{isDivider:t,resolvePageAttr:o}}function _s(e){if(e.type==="h"){if(e.subType==="h1")return 1;if(e.subType==="h2")return 2;if(e.subType==="h3")return 3}const t=(e.markdown||e.content||"").trimStart();return t.startsWith("# ")?1:t.startsWith("## ")?2:t.startsWith("### ")?3:null}function u2(e,t){for(let o=t-1;o>=0;o--){const i=e[o];if(wo(i)||(i.content||i.markdown||"").trim())return i}return null}function Is(e){const t=e.type;if(t==="c"||t==="code"||t==="t"||t==="table"||t==="s"||t==="super")return 3;if(t==="l"||t==="list"||t==="b"||t==="blockquote")return 2;const o=(e.markdown||e.content||"").trim();return o?o.includes("![")||o.includes("<img")||o.length>100?2:1:0}function Oa(e,t){if(e===1)return"cover";let o=!1,i=-1;for(let r=0;r<t.length;r++){const a=t[r],c=(a.markdown||a.content||"").trim();if(c.includes("![")||c.includes("<img")||a.type==="img"){o=!0,i=r;break}}if(o)return i===0?"image-left":"image-right";let n=0,s=!1,l=!1;for(const r of t)(r.type==="i"||r.type==="l"||(r.markdown||"").trim().startsWith("- "))&&n++,r.type==="s"&&(s=!0),r.type==="b"&&(l=!0);return s||n>=3?"two-cols":l&&t.length<=2?"quote":"default"}function f2(e,t){const o=[],i=new Set,n=6,s=6;let l=0,r=0,a=0,c=0,u=null;function f(h){const d=[];for(let b=h+1;b<e.length;b++){const m=e[b];if(wo(m))break;const y=_s(m);if(y!==null&&(y===1||y===2||y===3))break;d.push(m)}return d}if(e.length>0){let h=!1,d=-1;for(let b=0;b<e.length;b++){const m=e[b];if(wo(m)){h=!0;break}if((m.content||m.markdown||"").trim()){d=b;break}}if(!h&&d>=0){const b=e[d],m=_s(b);let y=m===1?"cover":"default";if(m!==1){const x=f(d);y=Oa(m,x)}const g=m===1?"作为第一页起点插入分页线 (封面大章)":"作为第一页起点插入分页线";o.push({blockId:b.id,recommendedLayout:y,reason:g}),i.add(b.id)}}for(let h=0;h<e.length;h++){const d=e[h];if(wo(d)){l=0,r=0,a=0,c=0,u=null;continue}const b=u2(e,h),m=!b||wo(b),y=_s(d);if(y===1||y===2||y===3){if(!(a===1&&c===0&&u!==null&&!(u===1&&y===2))&&!m&&l>0&&!i.has(d.id)){let T=y===1?"cover":"default";{const C=f(h);T=Oa(y,C)}let w=y===1?"检测到一级核心章节标题，建议作为新幻灯片封面/大章":y===2?"检测到二级分论点标题，建议开启新页":"检测到三级要点标题，建议开启新页";T==="image-right"||T==="image-left"?w+=" (推荐图文版式)":T==="two-cols"?w+=" (推荐双栏版式)":T==="quote"&&(w+=" (推荐引言版式)"),o.push({blockId:d.id,recommendedLayout:T,reason:w}),i.add(d.id),l=1,r=Is(d),a=1,c=0,u=y;continue}l++,r+=Is(d),a++,u=y;continue}const x=Is(d);if((l>=n||r+x>s&&l>0)&&!m&&l>0&&!i.has(d.id)){o.push({blockId:d.id,recommendedLayout:"default",reason:"当前页已达容量上限 (避免信息超载)，建议在此分页"}),i.add(d.id),l=1,r=x,a=0,c=1,u=null;continue}l++,r+=x,c++}return o}async function Nc(e){if(!e.currentDocId&&typeof document<"u"){const s=document.querySelector(".protyle-content[data-doc-id]");e.currentDocId=(s==null?void 0:s.getAttribute("data-doc-id"))||""}if(!e.currentDocId){ie.showMessage("请先打开一篇思源笔记文档");return}const t=await Ci(e.currentDocId).catch(()=>[]);if(!t||t.length===0){ie.showMessage("当前文档无内容，无需断页");return}const o=t.map(s=>({id:s.id,type:s.type,subType:s.subType,content:s.content||"",markdown:s.markdown||""})),i=f2(o);if(i.length===0){ie.showMessage("智能分析完毕：当前文档结构合理，暂无新增分页建议");return}ie.showMessage(`智能分析完毕：发现 ${i.length} 处建议分页点，正在自动插入分页线...`);let n=0;for(const s of i)try{await mo("markdown","---",s.blockId,void 0),await ze(s.blockId,{"custom-slides-layout":s.recommendedLayout}),n++}catch(l){console.warn("Failed to insert divider:",l)}ie.showMessage(`已成功在 ${n} 处插入分页线并重新编译`),e.compileCurrentDocument(e.currentDocId)}async function Oc(e){var s,l,r,a,c,u;if(!e.currentDocId&&typeof document<"u"){const f=document.querySelector(".protyle-content[data-doc-id]");e.currentDocId=(f==null?void 0:f.getAttribute("data-doc-id"))||""}if(!e.currentDocId){ie.showMessage("请先打开一篇思源笔记文档");return}const t=await Ci(e.currentDocId).catch(()=>[]);if(!t||t.length===0){ie.showMessage("当前文档无内容");return}const o=[],i=[];for(const f of t)f.type==="tb"||f.type==="thematic-break"||f.type==="NodeThematicBreak"||((s=f.markdown)==null?void 0:s.trim())==="---"||((l=f.markdown)==null?void 0:l.trim())==="***"||f.type==="b"&&(((r=f.markdown)==null?void 0:r.trim())==="---"||((a=f.content)==null?void 0:a.trim())==="---")?o.push(f.id):((c=f.ial)!=null&&c[yo]||(u=f.ial)!=null&&u[be])&&i.push(f.id);if(o.length===0&&i.length===0){ie.showMessage("当前文档中未发现需要清除的幻灯片分页线");return}const n=o.length;return new Promise(f=>{ie.confirm("危险操作：清除所有分页线",`此操作将从正文中彻底删除全部 ${n} 处幻灯片分页线（全篇将合并为单页），删除后无法撤销。是否确认继续？`,async()=>{ie.showMessage(`正在清除文档中的 ${n} 处分页线...`);let h=0;for(const d of o)try{await Qs(d),h++}catch(b){console.warn("Failed to delete divider block:",b)}for(const d of i)try{await ze(d,{[yo]:"",[be]:""})}catch(b){console.warn("Failed to clear slide attrs:",b)}ie.showMessage(`已成功清除文档中的 ${h} 处分页线并重新编译`),await e.compileCurrentDocument(e.currentDocId),f()},()=>{f()})})}const p2={class:"spm-slides-inspector"},h2={class:"spm-inspector-topbar"},m2={class:"spm-inspector-title"},g2={class:"slides-icon",style:{fill:"none !important"},"aria-hidden":"true",viewBox:"0 0 24 24"},y2={class:"spm-inspector-topbar-actions"},b2={class:"spm-target-banner"},v2={class:"spm-target-info"},k2=["aria-label"],w2={key:0,class:"spm-save-status"},x2=["title"],S2={class:"spm-inspector-body"},C2=Ht({__name:"SlidesInspectorDockView",setup(e,{expose:t}){const o=Zt("plugin"),i=he(!1);function n(te){i.value=!1,c.value=te.docId,o!=null&&o.compileCurrentDocument&&o.compileCurrentDocument(te.docId)}const s=he(""),l=he(""),r=he({}),a=he(""),c=he(""),u=he(""),f=he(""),h=he(""),d=he(""),b=he(""),m=he(""),y=he(null),g=he(""),x=he("");function k(){var ye;const te=s.value||c.value;te&&typeof navigator<"u"&&(ye=navigator==null?void 0:navigator.clipboard)!=null&&ye.writeText&&navigator.clipboard.writeText(te).then(()=>{x.value="已复制！",setTimeout(()=>{x.value=""},1500)}).catch(()=>{})}const I=ge(()=>Ir(l.value)),T=ge(()=>l.value==="NodeCodeBlock"),w=he(!1),C=ge(()=>{if(w.value||Ge.value)return!0;const te=a.value||"";return!!Co(te)}),L=ge(()=>{const te=l.value||"";if(te==="NodeVideo"||te==="video")return!0;const ye=a.value||"";return!!(/<video\b/i.test(ye)||/\.mp4\b/i.test(ye))}),R=ge(()=>!s.value||s.value===c.value||l.value==="doc"||l.value==="NodeDocument"),N=ge(()=>{const te=s.value||c.value||"";return te.length>8?te.slice(-8):te||"无"}),F=ge(()=>a.value?a.value.replace(/<[^>]+>/g,"").replace(/[\r\n]+/g," ").trim().slice(0,45):""),E=ge(()=>{if(I.value)return"分页符 (---)";if(R.value)return"全局文档";if(L.value)return"视频块";let te="内容块";switch(l.value){case"NodeHeading":te="标题块";break;case"NodeParagraph":te="段落块";break;case"NodeCodeBlock":te="代码块";break;case"NodeVideo":te="视频块";break;case"NodeList":case"NodeListItem":te="列表项";break;case"NodeBlockquote":te="引述块";break;case"NodeTable":te="表格块";break;case"NodeSuperBlock":case"s":case"sb":te="超级块";break;default:te="内容块";break}return d.value?b.value?`${b.value.replace(/^col-(\d+)$/,"第 $1 栏")} › ${te}`:`分栏容器 › ${te}`:te}),O=ge(()=>I.value?"tag-divider":R.value?"tag-doc":"tag-block"),S=ge(()=>r.value[be]||"default"),W=ge(()=>r.value[It]||"slide-left"),j=he(""),_=he(""),M=ge(()=>r.value[Pi]||"inherit"),B=ge(()=>{var te;return Ic((te=y.value)==null?void 0:te.slides,{activeBlockId:s.value,activeBlockType:l.value,currentTopBlockId:u.value,currentPageDividerId:f.value,activeBlockAttrs:r.value})}),Q=ge(()=>{var te;return((te=B.value)==null?void 0:te.notes)||""}),q=ge(()=>{var te,ye,Be;return((Be=(ye=(te=B.value)==null?void 0:te.noteBlocks)==null?void 0:ye[0])==null?void 0:Be.id)||""}),U=ge(()=>{var We,qe,Re,wt,cn,Eo;if(I.value){const it=r.value[be]||r.value["custom-slides-layout"];if(it)return it}const te=r.value[Ae]||r.value["custom-slides-slot"];if(te&&(["col-1","col-2","col-3"].includes(te)||/^col-\d+$/.test(te)))return"cols-header";if(h.value)return h.value;const ye=f.value||(I.value?s.value:"");if(ye){const it=Ee.getBlockAttrOverride(ye);if(it!=null&&it[be])return it[be]}if(ye&&((We=y.value)!=null&&We.slides)){const it=y.value.slides.find(ii=>ii.startBlockId===ye);if((qe=it==null?void 0:it.frontmatter)!=null&&qe.layout)return it.frontmatter.layout}if((wt=(Re=B.value)==null?void 0:Re.frontmatter)!=null&&wt.layout)return B.value.frontmatter.layout;if((Eo=(cn=B.value)==null?void 0:cn.blocks)!=null&&Eo.some(it=>it.slot&&(["col-1","col-2","col-3"].includes(it.slot)||/^col-\d+$/.test(it.slot))))return"cols-header";const Be=Ee.getBlockAttrOverride(c.value);return Be!=null&&Be[be]?Be[be]:"default"}),ne=d2({activeBlockId:s,activeBlockType:l,activeBlockAttrs:r,currentPageDividerId:f}),oe=ne.resolvePageAttr({attrKey:bt,mode:"truthy",fallback:()=>{var te,ye;return((ye=(te=B.value)==null?void 0:te.frontmatter)==null?void 0:ye.layoutRatio)||""}}),ae=ne.resolvePageAttr({attrKey:di,fallback:()=>{var te,ye;return((ye=(te=B.value)==null?void 0:te.frontmatter)==null?void 0:ye.mask)||""}}),Se=ne.resolvePageAttr({attrKey:Xo,fallback:()=>{var te,ye;return((ye=(te=B.value)==null?void 0:te.frontmatter)==null?void 0:ye.maskRatio)||""}}),$e=ne.resolvePageAttr({attrKey:ui,fallback:()=>{var te,ye;return((ye=(te=B.value)==null?void 0:te.frontmatter)==null?void 0:ye.maskStyle)||"solid"}}),ke=ne.resolvePageAttr({attrKey:fi,fallback:()=>{var te,ye;return((ye=(te=B.value)==null?void 0:te.frontmatter)==null?void 0:ye.maskInitial)||"hidden"}});function Ce(te){if(!te||(te.getAttribute("data-sb-layout")||"").toLowerCase()!=="col")return null;const Be=Array.from(te.querySelectorAll(":scope > [data-node-id]"));if(Be.length<2)return null;const We=Be.length,qe=Be.map(Eo=>{const it=Eo.getAttribute("style")||"",ii=it.match(/calc\(\s*([\d.]+)%/);if(ii)return parseFloat(ii[1]);const Ai=it.match(/(?:^|;|\s)width:\s*([\d.]+)%/i);return Ai?parseFloat(Ai[1]):null});let Re="",wt=!1;if(qe.some(Eo=>Eo!==null)){wt=!0;const Eo=qe.reduce((Oe,xt)=>Oe+(xt||0),0),it=qe.filter(Oe=>Oe===null).length,ii=it>0?Math.max(0,100-Eo)/it:100/Be.length,Ai=qe.map(Oe=>Oe!==null?Oe:ii),$d=Ai.reduce((Oe,xt)=>Oe+xt,0)||1,Mi=Ai.map(Oe=>Oe/$d*100);if(Mi.length===2){const[Oe]=Mi;if(Oe>=48&&Oe<=52)Re="1:1";else if(Oe>=31&&Oe<=35)Re="1:2";else if(Oe>=65&&Oe<=69)Re="2:1";else if(Oe>=28&&Oe<=32)Re="3:7";else if(Oe>=68&&Oe<=72)Re="7:3";else if(Oe>=38&&Oe<=42)Re="4:6";else if(Oe>=58&&Oe<=62)Re="6:4";else{const xt=Math.round(Oe);Re=`${xt}:${100-xt}`}}else if(Mi.length===3){const[Oe,xt,Bo]=Mi;if(Oe>=31&&Oe<=35&&xt>=31&&xt<=35&&Bo>=31&&Bo<=35)Re="1:1:1";else if(Oe>=23&&Oe<=27&&xt>=48&&xt<=52&&Bo>=23&&Bo<=27)Re="1:2:1";else if(Oe>=48&&Oe<=52&&xt>=23&&xt<=27&&Bo>=23&&Bo<=27)Re="2:1:1";else if(Oe>=23&&Oe<=27&&xt>=23&&xt<=27&&Bo>=48&&Bo<=52)Re="1:1:2";else{const Br=Math.round(Oe),Lr=Math.round(xt);Re=`${Br}:${Lr}:${100-Br-Lr}`}}else Re=Mi.map(Oe=>Math.round(Oe)).join(":")}else wt=!1,Re=Array.from({length:We},()=>1).join(":");const cn=We>=2?"cols-header":"two-cols";return{hasSuperBlock:!0,colCount:We,ratio:Re,isCustomWidth:wt,recommendedLayout:cn}}function z(te){if(!(te!=null&&te.blocks))return null;for(const ye of te.blocks){const Be=ye.rawNode;if(Be&&ft(Be)&&lo(Be)){const qe=$i(Be).length,Re=xr(Be);return{hasSuperBlock:!0,colCount:qe,ratio:Re||Array.from({length:qe},()=>1).join(":"),isCustomWidth:!!Re,recommendedLayout:qe>=2?"cols-header":"two-cols"}}}return null}const se=ge(()=>{var te;if(typeof document<"u"){const ye=s.value;if(ye){const We=document.querySelector(`.protyle-wysiwyg [data-node-id="${ye}"]`);if(We){const qe=We.getAttribute("data-type")==="NodeSuperBlock"?We:We.closest('[data-type="NodeSuperBlock"]');if(qe){const Re=Ce(qe);if(Re)return Re}}}const Be=f.value||(I.value?s.value:"");if(Be){const We=document.querySelector(`.protyle-wysiwyg [data-node-id="${Be}"]`);if(We){let qe=We.nextElementSibling;for(;qe&&!(qe.getAttribute("data-type")==="NodeThematicBreak"||(te=qe.classList)!=null&&te.contains("protyle-wysiwyg__block--hr"));){const Re=qe.getAttribute("data-type")==="NodeSuperBlock"?qe:qe.querySelector('[data-type="NodeSuperBlock"]');if(Re){const wt=Ce(Re);if(wt)return wt}qe=qe.nextElementSibling}}}else{const We=document.querySelector('.protyle-wysiwyg [data-type="NodeThematicBreak"], .protyle-wysiwyg .protyle-wysiwyg__block--hr'),qe=Array.from(document.querySelectorAll('.protyle-wysiwyg [data-type="NodeSuperBlock"]'));for(const Re of qe)if(!We||Re.compareDocumentPosition(We)&Node.DOCUMENT_POSITION_FOLLOWING){const wt=Ce(Re);if(wt)return wt}}}return z(B.value)}),D=ge(()=>{var te;return((te=se.value)==null?void 0:te.ratio)||""}),V=ge(()=>{const te=l.value||"";if(te==="NodeSuperBlock"||te==="s"||te==="sb")return!0;if(typeof document<"u"&&s.value){const ye=document.querySelector(`.protyle-wysiwyg [data-node-id="${s.value}"]`);if(ye!=null&&ye.closest('[data-type="NodeSuperBlock"]'))return!0}return!1}),v=ge(()=>{var te;return((te=B.value)==null?void 0:te.pageIndex)||1}),K=ge(()=>!!r.value[Fe]);function H(){if(!d.value)return!1;if(s.value===d.value||typeof document>"u")return!0;const te=document.querySelector(`.protyle-wysiwyg [data-node-id="${d.value}"]`)||document.querySelector(`[data-node-id="${d.value}"]`);if(!te)return!1;const ye=te.querySelector(":scope > [data-node-id], :scope > div > [data-node-id]");return(ye==null?void 0:ye.getAttribute("data-node-id"))===s.value}const $=ge(()=>{var ye;if(r.value[Ne]!==void 0)return r.value[Ne]||"";if(d.value&&H())return m.value||"";if(d.value)return"";const te=s.value;if(te&&((ye=B.value)!=null&&ye.blocks)){const Be=B.value.blocks.find(We=>We.id===te);if(Be!=null&&Be.clicks)return Be.clicks}return""}),A=ge(()=>{var ye;if(r.value[Bt])return r.value[Bt];const te=s.value;if(te&&((ye=B.value)!=null&&ye.blocks)){const Be=B.value.blocks.find(We=>We.id===te);if(Be!=null&&Be.motion)return typeof Be.motion=="string"?Be.motion:JSON.stringify(Be.motion)}return""}),P=ge(()=>{var ye;if(r.value[Ae])return r.value[Ae];const te=s.value;if(te&&((ye=B.value)!=null&&ye.blocks)){const Be=B.value.blocks.find(We=>We.id===te);if(Be!=null&&Be.slot)return Be.slot}return""}),Y=he(""),G=he(""),Z=ge(()=>r.value[Zo]==="true"),ee=ge(()=>r.value[En]==="true"),ce=ge(()=>r.value[li]==="true"),re=ge(()=>r.value[Bn]!=="false"),me=ge(()=>{var te,ye;return((ye=(te=y.value)==null?void 0:te.config)==null?void 0:ye.theme)||r.value[Vi]||"apple-basic"}),_e=ge(()=>{var te,ye;return((ye=(te=y.value)==null?void 0:te.config)==null?void 0:ye.aspectRatio)||r.value[Ki]||"16/9"}),we=ge(()=>{var te,ye;return((ye=(te=y.value)==null?void 0:te.config)==null?void 0:ye.defaultTransition)||r.value[Gi]||"slide-left"}),De=ge(()=>{var te,ye;return((ye=(te=y.value)==null?void 0:te.config)==null?void 0:ye.spacing)||r.value[Es]||"normal"}),He=ge(()=>{var te,ye;return((ye=(te=y.value)==null?void 0:te.config)==null?void 0:ye.background)||r.value[Mn]||""}),Ge=ge(()=>{var qe,Re;if((r.value[Ze]||r.value["slides-role"])===Va||r.value[dt]==="true")return"background";const ye=r.value[be]||r.value["slides-layout"];if(ye==="image-left"||ye==="image-right")return ye;const Be=a.value||"",We=Co(Be);if(We&&((Re=(qe=B.value)==null?void 0:qe.frontmatter)!=null&&Re.background)){const wt=B.value.frontmatter.background;if(wt===We||wt.endsWith(We)||We.endsWith(wt))return"background"}return""}),rt=ge(()=>!!(r.value[Ne]||r.value[Bt]||r.value[Ae]||r.value[ti]||r.value[Fe]||r.value["slides-note"]||r.value[Ze]||r.value[be]||r.value[Zo]||r.value[En]||r.value[li]||r.value[Bn])),{saveAttr:Pe,savePageAttr:pt,applyPageLayoutAndRatio:tt,applyCloverLayout:Ye,resetSuperBlockWidth:fe,saveDocAttr:pe,onToggleVideoAutoplay:Qe,onToggleVideoLoop:at,onToggleVideoMuted:At,onToggleVideoControls:lt,onImageRoleChange:fo,onToggleNoteBlock:Fc,onAddNoteBlock:jc,onLocateNoteBlock:Uc,onGenerateNotesWithAI:Wc,isGeneratingNotes:qc,isBatchProcessing:ln,onBatchDeleteNotes:Vc,onAddOrIdentifyNotesBlocks:Kc,onAutoAnimateDocument:Gc,onClearAnimationsDocument:Yc,toggleElemClick:Zc,onElemClickStepChange:Jc,onElemMotionChange:Xc,onElemSlotChange:Qc,onElemShikiLinesChange:ed,onElemMaxHeightChange:td,onSetTwoColsContrast:od,onClearBlockAttrs:id,onInsertDividerBefore:nd,onInsertDividerAfter:$r,onDeleteCurrentBlock:sd,onConvertToSuperBlock:Tr,onExportHtml:rd,onExportPdf:ad}=c2({activeBlockId:s,activeBlockType:l,activeBlockAttrs:r,rawSnippet:a,currentDocId:c,currentPageDividerId:f,currentPageDividerLayout:h,parentContainerId:d,parentContainerClicks:m,latestDoc:y,targetSlide:B,currentSlideNoteBlockId:q,currentSlideLayout:U,isNoteBlock:K,elemClick:$,videoAutoplay:Z,videoLoop:ee,videoMuted:ce,videoControls:re,pageBackground:j,pageImage:_,elemShikiLines:Y,elemMaxHeight:G,saveStatus:g,plugin:o}),as=he(!1);function Mo(){as.value=Fw(s.value,l.value)}oi(()=>{typeof document<"u"&&(document.addEventListener("selectionchange",Mo),document.addEventListener("mouseup",Mo),document.addEventListener("keyup",Mo)),Mo()}),sn(()=>{typeof document<"u"&&(document.removeEventListener("selectionchange",Mo),document.removeEventListener("mouseup",Mo),document.removeEventListener("keyup",Mo))}),Fo([s,l],()=>{Mo()});async function ld(te){if(te==="clover"){if(!await Ye())return}else pt(be,te)}function cd(te){pt(bt,te)}async function dd(te){await pt(di,te),(te==="clockwise"||te==="counter-clockwise"||te==="cw"||te==="ccw")&&(!Se.value||Se.value==="1:1")&&await pt(Xo,"1:1:1:1")}function ud(te){pt(Xo,te)}function fd(te){pt(ui,te)}function pd(te){pt(fi,te)}function Ar(te){if(!te)return;const ye=te.recommendedLayout||(te.colCount&&te.colCount>=2?"cols-header":"two-cols"),Be=te.ratio||(te.colCount?Array(te.colCount).fill(1).join(":"):"1:1");tt(ye,Be)}function hd(te){pt(bt,te)}async function md(){await fe()}function gd(te){Pe(It,te)}function yd(te){_.value=te,Pe(Kt,te)}function bd(te){Pe(Pi,te==="inherit"?"":te)}function vd(te){pe(Vi,te)}function kd(te){pe(Mn,te)}function wd(te){pe(Ki,te)}function xd(te){pe(Gi,te)}function Sd(te){pe(Es,te)}function Mr(){o!=null&&o.openBottomPreviewTab&&o.openBottomPreviewTab()}function Cd(){o!=null&&o.openPresenterTab&&o.openPresenterTab()}let ls=!1;function Er(){if(!ls){ls=!0;try{o&&typeof o.openSetting=="function"?o.openSetting():o&&o.setting&&typeof o.setting.open=="function"&&o.setting.open(o.name||"siyuan-live-slides")}finally{setTimeout(()=>{ls=!1},500)}}}function _d(){o&&ct("aiScript")&&Nc(o)}async function Id(){if(o&&ct("aiScript")){if(ln.value)return;ln.value=!0;try{await Oc(o)}finally{ln.value=!1}}}return t({setActiveBlock(te){s.value=te.id,l.value=te.type,r.value={...te.attrs},a.value=te.content||te.markdown||"",u.value=te.topBlockId||te.id,f.value=te.pageDividerId||"",h.value=te.pageDividerLayout||"",d.value=te.parentContainerId||"",b.value=te.parentContainerSlot||"",m.value=te.parentContainerClicks||"",te.rootId?c.value=te.rootId:(te.type==="doc"||te.type==="NodeDocument")&&te.id&&(c.value=te.id),j.value=te.attrs[dt]||"",_.value=te.attrs[Kt]||"",Y.value=te.attrs[ti]||"",G.value=te.attrs[Yi]||"",w.value=!!te.isImage},updateDocument(te){y.value=te,c.value=te.docId},openImportDialog(){i.value=!0},setCurrentDocId(te){c.value=te}}),(te,ye)=>(J(),X("div",p2,[p("div",h2,[p("div",m2,[(J(),X("svg",g2,[...ye[2]||(ye[2]=[p("rect",{x:"2",y:"3",width:"20",height:"14",rx:"2"},null,-1),p("line",{x1:"8",y1:"21",x2:"16",y2:"21"},null,-1),p("line",{x1:"12",y1:"17",x2:"12",y2:"21"},null,-1)])])),ye[3]||(ye[3]=p("span",null,"演示配置",-1))]),p("div",y2,[de(ct)("import")?(J(),X("button",{key:0,class:"spm-icon-btn b3-tooltips b3-tooltips__sw","aria-label":"导入 Slidev 演示文档 (.md / .zip)",onClick:ye[0]||(ye[0]=Be=>i.value=!0)},[le(ue,{name:"import"}),ye[4]||(ye[4]=p("span",null,"导入",-1))])):Te("",!0),p("button",{class:"spm-icon-btn is-primary b3-tooltips b3-tooltips__sw","aria-label":"在下方分屏开启幻灯片预览 (Alt+P)",onClick:Mr},[le(ue,{name:"split-preview"}),ye[5]||(ye[5]=p("span",null,"分屏预览",-1))])])]),p("div",b2,[p("div",v2,[p("span",{class:xe(["spm-target-tag",O.value])},ve(E.value),3),p("span",{class:"spm-target-id b3-tooltips b3-tooltips__se","aria-label":x.value||"点击复制 ID: "+(s.value||c.value),onClick:k},[le(ue,{name:"copy"}),p("span",null,"#"+ve(N.value),1)],8,k2)]),g.value?(J(),X("span",w2,"● "+ve(g.value),1)):Te("",!0)]),F.value?(J(),X("div",{key:0,class:"spm-context-quote",title:a.value},ve(F.value),9,x2)):Te("",!0),p("div",S2,[I.value?(J(),Gt(Bv,{key:0,"page-layout":S.value,"page-layout-ratio":de(oe),"page-mask":de(ae),"page-mask-ratio":de(Se),"page-mask-style":de($e),"page-mask-initial":de(ke),"detected-sb-ratio":D.value,"detected-sb-info":se.value,"page-transition":W.value,"page-spacing":M.value,"page-image":_.value,"page-notes":Q.value,"page-index":v.value,"is-generating-notes":de(qc),"can-convert-to-super-block":as.value,"onUpdate:pageLayout":ld,"onUpdate:pageLayoutRatio":cd,"onUpdate:pageMask":dd,"onUpdate:pageMaskRatio":ud,"onUpdate:pageMaskStyle":fd,"onUpdate:pageMaskInitial":pd,onApplySuperBlockLayout:Ar,onResetSuperblockRatio:md,"onUpdate:pageTransition":gd,"onUpdate:pageSpacing":bd,"onUpdate:pageImage":yd,onAddNoteBlock:de(jc),onLocateNoteBlock:de(Uc),onGenerateNotes:de(Wc),onOpenSetting:Er,onInsertDividerAfter:de($r),onDeleteDivider:de(sd),onConvertToSuperBlock:de(Tr)},null,8,["page-layout","page-layout-ratio","page-mask","page-mask-ratio","page-mask-style","page-mask-initial","detected-sb-ratio","detected-sb-info","page-transition","page-spacing","page-image","page-notes","page-index","is-generating-notes","can-convert-to-super-block","onAddNoteBlock","onLocateNoteBlock","onGenerateNotes","onInsertDividerAfter","onDeleteDivider","onConvertToSuperBlock"])):s.value&&!R.value?(J(),Gt(u0,{key:1,"elem-click":$.value,"elem-motion":A.value,"elem-slot":P.value,"elem-shiki-lines":Y.value,"elem-max-height":G.value,"is-code-block":T.value,"is-image":C.value,"is-video":L.value,"is-super-block":V.value,"detected-sb-info":se.value,"video-autoplay":Z.value,"video-loop":ee.value,"video-muted":ce.value,"video-controls":re.value,"has-block-attrs":rt.value,"is-note":K.value,"image-role":Ge.value,"current-slide-layout":U.value,"parent-elem-click":m.value,"parent-container-slot":b.value,"parent-container-id":d.value,"can-convert-to-super-block":as.value,onToggleNote:de(Fc),onToggleElemClick:de(Zc),onToggleVideoAutoplay:de(Qe),onToggleVideoLoop:de(at),onToggleVideoMuted:de(At),onToggleVideoControls:de(lt),"onUpdate:imageRole":de(fo),"onUpdate:elemClick":de(Jc),"onUpdate:elemMotion":de(Xc),"onUpdate:elemSlot":de(Qc),"onUpdate:elemShikiLines":de(ed),"onUpdate:elemMaxHeight":de(td),onApplySuperBlockLayout:Ar,onApplySuperBlockRatio:hd,onInsertDividerBefore:de(nd),onInsertDividerAfter:de($r),onSetTwoColsContrast:de(od),onClearBlockAttrs:de(id),onConvertToSuperBlock:de(Tr)},null,8,["elem-click","elem-motion","elem-slot","elem-shiki-lines","elem-max-height","is-code-block","is-image","is-video","is-super-block","detected-sb-info","video-autoplay","video-loop","video-muted","video-controls","has-block-attrs","is-note","image-role","current-slide-layout","parent-elem-click","parent-container-slot","parent-container-id","can-convert-to-super-block","onToggleNote","onToggleElemClick","onToggleVideoAutoplay","onToggleVideoLoop","onToggleVideoMuted","onToggleVideoControls","onUpdate:imageRole","onUpdate:elemClick","onUpdate:elemMotion","onUpdate:elemSlot","onUpdate:elemShikiLines","onUpdate:elemMaxHeight","onInsertDividerBefore","onInsertDividerAfter","onSetTwoColsContrast","onClearBlockAttrs","onConvertToSuperBlock"])):(J(),Gt(Rk,{key:2,"doc-theme":me.value,"doc-background":He.value,"doc-aspect-ratio":_e.value,"doc-default-transition":we.value,"doc-spacing":De.value,"is-batch-processing":de(ln),"onUpdate:docTheme":vd,"onUpdate:docBackground":kd,"onUpdate:docAspectRatio":wd,"onUpdate:docDefaultTransition":xd,"onUpdate:docSpacing":Sd,onOpenBottomPreview:Mr,onOpenPresenter:Cd,onAddOrIdentifyNotes:de(Kc),onClearNotes:de(Vc),onAutoAnimate:de(Gc),onClearAnimations:de(Yc),onAiAutoSplit:_d,onClearDividers:Id,onExportHtml:de(rd),onExportPdf:de(ad),onOpenSetting:Er},null,8,["doc-theme","doc-background","doc-aspect-ratio","doc-default-transition","doc-spacing","is-batch-processing","onAddOrIdentifyNotes","onClearNotes","onAutoAnimate","onClearAnimations","onExportHtml","onExportPdf"]))]),i.value&&de(ct)("import")?(J(),Gt(Hw,{key:1,onClose:ye[1]||(ye[1]=Be=>i.value=!1),onSuccess:n})):Te("",!0)]))}}),_2=2e3,I2=600;function $2(e){return!e||typeof e.closest!="function"?!1:!!e.closest(".fn__none")}function $s(e){if(!e||typeof e.isConnected=="boolean"&&!e.isConnected)return!1;if(Pa(e))return!0;const t=e.firstElementChild;return!!(t&&Pa(t))}function Pa(e){return typeof e.getClientRects=="function"&&e.getClientRects().length>0?!0:typeof e.offsetWidth=="number"&&e.offsetWidth>0&&e.offsetHeight>0}function T2(){const e=typeof globalThis<"u"?globalThis.IntersectionObserver:void 0;return typeof e=="function"?e:void 0}class A2{constructor(){Ie(this,"consumers",new Map);Ie(this,"seq",0);Ie(this,"verifyTimer",null)}register(t,o,i){if(!o)return()=>{};const n=++this.seq,s=T2(),l={kind:t,element:o,visible:!1,measureOnDemand:!s,observer:null,onVisible:i};return s?(l.observer=new s(r=>{var u;const a=r[r.length-1];if(!a)return;const c=a.isIntersecting&&!l.visible;l.visible=a.isIntersecting,c&&((u=l.onVisible)==null||u.call(l))}),l.observer.observe(o)):l.visible=$s(o),this.consumers.set(n,l),()=>{var r;(r=l.observer)==null||r.disconnect(),this.consumers.delete(n),this.consumers.size===0&&this.stopVerifyTimer()}}clear(){var t;for(const o of this.consumers.values())(t=o.observer)==null||t.disconnect();this.consumers.clear(),this.stopVerifyTimer()}get size(){return this.consumers.size}getVisibility(){if(this.consumers.size===0)return"none";if(typeof document<"u"&&document.visibilityState==="hidden")return"hidden";for(const t of this.consumers.values())if(t.measureOnDemand?$s(t.element):this.isRecordVisible(t))return"visible";return this.ensureVerifyTimer(),"hidden"}hasVisibleConsumer(){return this.getVisibility()==="visible"}isRecordVisible(t){return t.visible?!0:!$2(t.element)}ensureVerifyTimer(){if(this.verifyTimer!==null||typeof setTimeout!="function")return;let t=!1;for(const o of this.consumers.values())if(!o.measureOnDemand){t=!0;break}t&&(this.verifyTimer=setTimeout(()=>{var o;this.verifyTimer=null;for(const i of this.consumers.values())if(!i.visible&&$s(i.element)){i.visible=!0,(o=i.onVisible)==null||o.call(i);return}},_2))}stopVerifyTimer(){this.verifyTimer!==null&&(clearTimeout(this.verifyTimer),this.verifyTimer=null)}}const $n=new A2,Ti=new ss;function Pc(e,t,o){const i=()=>{var s;try{(s=o==null?void 0:o.flushDirtyCompile)==null||s.call(o)}catch{}},n=$n.register(e,t,i);return i(),n}let Oo=null,Ut=null,Tn=null;function M2(){return Ut}function E2(e,t){Oo&&Rc(),Oo=vr(Jg),Oo.provide("plugin",t),Oo.provide("sandboxBridge",Ti);const o=Oo.mount(e);return Ut=o,Tn=Pc("preview",e,t),o}function Rc(e){Tn&&(Tn(),Tn=null),Oo&&(Oo.unmount(),Oo=null,Ut=null)}function B2(){return Ut!==null}let Po=null,Jo=null;function L2(e,t){return Po&&zc(),Po=vr(ab),Po.provide("plugin",t),Po.provide("sandboxBridge",Ti),Jo=Po.mount(e),Jo}function zc(e){Po&&(Po.unmount(),Po=null,Jo=null)}function D2(e){var t;try{const o=new BroadcastChannel("siyuan-slides-sync");o.postMessage({type:"SYNC_SLIDES",slides:e.slides||[],config:{...e.config||{},hostThemeMode:((t=e.config)==null?void 0:t.hostThemeMode)||Wo()}}),o.close()}catch{}}let Ro=null,Pt=null,An=null;function N2(e,t){Ro&&Hc(),Ro=vr(C2),Ro.provide("plugin",t),Ro.provide("sandboxBridge",Ti);const o=Ro.mount(e);return Pt=o,An=Pc("dock",e,t),o}function Hc(e){An&&(An(),An=null),Ro&&(Ro.unmount(),Ro=null,Pt=null)}function O2(e,t){Pt!=null&&Pt.updateDocument&&Pt.updateDocument(e),Ut!=null&&Ut.updateDocument?Ut.updateDocument(e,t):(Ti.updateSlides(e.slides,e.config),D2(e)),Jo!=null&&Jo.updateDocument&&Jo.updateDocument(e)}function Xs(e){Ut!=null&&Ut.navigateToBlock?Ut.navigateToBlock(e):Ti.highlightElement(e)}function ai(e){Pt!=null&&Pt.setActiveBlock&&Pt.setActiveBlock(e)}function P2(){return qt("import")?!1:Pt!=null&&Pt.openImportDialog?(Pt.openImportDialog(),!0):!1}const R2=[{id:"slides-cover",name:"幻灯片 - 封面页 (Cover)",open:!0,attrs:[{key:yo,value:"true"},{key:be,value:"cover"},{key:It,value:"fade"}]},{id:"slides-two-cols",name:"幻灯片 - 双栏对比 (Two Columns)",open:!0,attrs:[{key:yo,value:"true"},{key:be,value:"two-cols"},{key:It,value:"slide-left"}]},{id:"slides-fact",name:"幻灯片 - 大字报与核心指标 (Fact)",open:!0,attrs:[{key:yo,value:"true"},{key:be,value:"fact"},{key:It,value:"zoom"}]},{id:"slides-intro",name:"幻灯片 - 章节导引与作者 (Intro)",open:!0,attrs:[{key:yo,value:"true"},{key:be,value:"intro"},{key:It,value:"slide-up"}]},{id:"slides-quote",name:"幻灯片 - 金句与强调 (Quote)",open:!0,attrs:[{key:yo,value:"true"},{key:be,value:"quote"},{key:It,value:"fade"}]},{id:"slides-elem-click",name:"元素 - 顺延逐步呈现 (v-click)",open:!0,attrs:[{key:Ne,value:"+1"}]},{id:"slides-elem-click-hide",name:"元素 - 隐藏直到激活 (v-click:hide)",open:!0,attrs:[{key:Ne,value:"hide"}]},{id:"slides-elem-slot-right",name:"元素 - 双栏右栏归属 (Slot: Right)",open:!0,attrs:[{key:Ae,value:"right"}]},{id:"slides-shiki-lines",name:"代码 - 逐行聚光高亮 (Shiki)",open:!0,attrs:[{key:ti,value:"1-3"}]}];class Ts{getPresetTemplates(){return R2}buildScanSlidesBlocksSql(t="custom-slides-"){return`SELECT block_id, name, value FROM attributes WHERE name LIKE '${t}%' ORDER BY block_id ASC`}buildTransitionStatsSql(){return`SELECT value, count(1) as count FROM attributes WHERE name = '${It}' GROUP BY value ORDER BY count DESC`}async batchUpdateTransitions(t,o,i,n){const s=`SELECT block_id FROM attributes WHERE name = '${It}' AND value = '${t}'`,l=await i(s);let r=0;if(Array.isArray(l))for(const a of l){const c=a.block_id||a.blockId;c&&(await n(c,{[It]:o}),r++)}return{updatedCount:r}}async batchUpdateLayout(t,o,i,n){const s=`SELECT block_id FROM attributes WHERE name = '${be}' AND value = '${t}'`,l=await i(s);let r=0;if(Array.isArray(l))for(const a of l){const c=a.block_id||a.blockId;c&&(await n(c,{[be]:o}),r++)}return{updatedCount:r}}exportTemplatesJson(){const t=this.getPresetTemplates();return JSON.stringify({templates:t,counter:t.length},null,2)}formatTransitionSummary(t){return!t||t.length===0?"全库目前暂无已设置即现转场效果的块":`全库即现转场分布统计：${t.map(i=>`${i.value}: ${i.count} 个`).join("，")}`}}function z2(e){if(e.addCommand({langKey:"slidesPresentation",langText:"即现: 在文档下方开启分屏演示预览",hotkey:"⌥P",enabled:()=>!0,execute:()=>{e.openBottomPreviewTab()}}),qt("import")||e.addCommand({langKey:"slidesImport",langText:"即现: 导入 Slidev 演示文档 (.md / .zip)",hotkey:"⌥I",enabled:()=>!0,execute:()=>{P2()||ie.showMessage("请先在右侧栏打开「即现配置」Dock 面板以呼起导入窗口")}}),e.addCommand({langKey:"slidesInitAttrs",langText:"即现: 初始化当前文档演示属性",hotkey:"",enabled:()=>!0,execute:async()=>{if(!e.currentDocId){const t=document.querySelector(".protyle-content[data-doc-id]");e.currentDocId=(t==null?void 0:t.getAttribute("data-doc-id"))||""}e.currentDocId&&(await ze(e.currentDocId,{"custom-slides-theme":"default","custom-slides-aspect-ratio":"16/9","custom-slides-default-transition":"slide-left"}),ie.showMessage("已为当前文档初始化即现属性"),e.compileCurrentDocument(e.currentDocId))}}),!qt("smartSplit")&&!qt("aiScript")&&(e.addCommand({langKey:"slidesAiSplit",langText:"即现: 智能大纲断页建议与自动分页",hotkey:"",enabled:()=>!0,execute:()=>Nc(e)}),e.addCommand({langKey:"slidesClearDividers",langText:"即现: 清除当前文档分页线",hotkey:"",enabled:()=>!0,execute:()=>Oc(e)})),qt("aiScript")||e.addCommand({langKey:"slidesAiNotes",langText:"即现 AI: 自动为当前文档生成演讲者提词卡 (Notes)",hotkey:"",enabled:()=>!0,execute:async()=>{var n,s,l,r;if(!e.currentDocId){const a=document.querySelector(".protyle-content[data-doc-id]");e.currentDocId=(a==null?void 0:a.getAttribute("data-doc-id"))||""}if(!e.currentDocId){ie.showMessage("请先打开一篇思源笔记文档");return}if(!kr()){ie.showMessage("未配置 AI 提词服务，请前往设置填写 API 配置或通过「API 旋钮 (siyuan-api-switch)」接管",6e3,"error");return}ie.showMessage("正在调用 AI 提炼演讲者口播提词...");const o=await Ci(e.currentDocId).catch(()=>[]),i={pageIndex:1,startBlockId:e.currentDocId,frontmatter:{},notes:"",blocks:o.map(a=>({id:a.id,type:a.type,content:a.content||"",rawMarkdown:a.markdown||""})),rawMarkdown:""};try{const a=await Jw(i,rs);if(!a){ie.showMessage("AI 未返回可用的提词内容",5e3,"error");return}const u=`> [!NOTE] 💡 演讲备注
${a.split(/\r?\n/).map(d=>`> ${d}`).join(`
`)}
{: custom-slides-note="true"}`,f=await vn("markdown",u,e.currentDocId).catch(()=>null),h=((l=(s=(n=f==null?void 0:f[0])==null?void 0:n.doOperations)==null?void 0:s[0])==null?void 0:l.id)||((r=f==null?void 0:f[0])==null?void 0:r.id);h&&(await ze(h,{"custom-slides-note":"true"}),Ee.setBlockAttrOverride(h,{"custom-slides-note":"true"}),zo(h,e.app)),ie.showMessage("已成功生成口播提词卡并插入为正文讲稿备注块"),e.compileCurrentDocument(e.currentDocId)}catch(a){ie.showMessage(`AI 提词生成失败: ${(a==null?void 0:a.message)||a}`,6e3,"error")}}}),qt("speakerNotesBlocks")||e.addCommand({langKey:"slidesIdentifyNotes",langText:"即现: 识别正文讲稿块并规范化",hotkey:"",enabled:()=>!0,execute:async()=>{let t=e.currentDocId;if(!t){const o=document.querySelector(".protyle-content[data-doc-id]");t=(o==null?void 0:o.getAttribute("data-doc-id"))||"",t&&(e.currentDocId=t)}if(!t){ie.showMessage("请先在主编辑区打开幻灯片文档");return}await Lc(t,{compileFn:async()=>{await e.compileCurrentDocument(t)}})}}),qt("smartAnimation")||e.addCommand({langKey:"slidesAutoAnimate",langText:"即现: 智能配置演示动效",hotkey:"",enabled:()=>!0,execute:async()=>{let t=e.currentDocId;if(!t){const o=document.querySelector(".protyle-content[data-doc-id]");t=(o==null?void 0:o.getAttribute("data-doc-id"))||"",t&&(e.currentDocId=t)}if(!t){ie.showMessage("请先在主编辑区打开幻灯片文档");return}await Dc(t,{compileCurrentDocFn:async()=>{await e.compileCurrentDocument(t)}})}}),e.addCommand({langKey:"slidesBatchTransitions",langText:"即现协同: 统计全库转场效果分布",hotkey:"",enabled:()=>!0,execute:async()=>{const t=new Ts,o=t.buildTransitionStatsSql(),i=await ki(o).catch(()=>[]),n=t.formatTransitionSummary(i||[]);ie.showMessage(n)}}),e.addCommand({langKey:"slidesExportTemplates",langText:"即现协同: 复制即现预设属性模板至剪贴板",hotkey:"",enabled:()=>!0,execute:async()=>{const o=new Ts().exportTemplatesJson();typeof navigator<"u"&&navigator.clipboard?(await navigator.clipboard.writeText(o),ie.showMessage("已将即现属性模板 JSON 复制至剪贴板，可直接导入属性管家")):ie.showMessage(`已生成模板数据（请在控制台查看）：
`+o)}}),e.addCommand({langKey:"slidesBatchReplaceTransition",langText:"即现协同: 批量替换全库淡入淡出转场为滑动 (fade -> slide-left)",hotkey:"",enabled:()=>!0,execute:async()=>{const o=await new Ts().batchUpdateTransitions("fade","slide-left",i=>ki(i).catch(()=>[]),(i,n)=>ze(i,n));ie.showMessage(`全库批量替换完成：已将 ${o.updatedCount} 处 fade 转场更新为 slide-left`),e.compileCurrentDocument()}}),qt("presenterMode")||e.addCommand({langKey:"slidesPresenterMode",langText:"即现: 打开双屏演讲者控制台 (Presenter Mode)",hotkey:"⌥M",enabled:()=>!0,execute:()=>{e.openPresenterTab()}}),!qt("exportImage")){let t=!1;e.addCommand({langKey:"slidesExportImagesZip",langText:"即现: 逐页导出幻灯片为高清图片包 (ZIP)",hotkey:"",enabled:()=>!0,execute:async()=>{if(t){ie.showMessage("正在导出图片中，请稍候...",2e3);return}if(e.latestCompiledDoc||await e.compileCurrentDocument(),!e.latestCompiledDoc){ie.showMessage("请先打开并放映一篇思源笔记文档");return}t=!0;try{ie.showMessage("正在启动后台沙箱并逐页导出幻灯片图片...");const o=e.latestCompiledDoc,i=await Ho(o,e.currentDocId,e),n=await kc(o,{title:i,onProgress:(s,l)=>{ie.showMessage(`正在导出幻灯片图片 (${s} / ${l})...`,2e3)}});n.success?ie.showMessage(`🎉 成功导出 ${n.total||0} 张幻灯片高清图片并已保存为 ${i}.zip！`,4e3):ie.showMessage(`导出图片失败：${n.error||"未知异常"}`)}finally{t=!1}}})}}class H2{constructor(t=400){Ie(this,"entries",new Map);this.ttlMs=t}get(t,o=Date.now()){if(!t)return;const i=this.entries.get(t);if(i){if(o-i.at>this.ttlMs){this.entries.delete(t);return}return i.attrs}}set(t,o,i=Date.now()){!t||!o||this.entries.set(t,{attrs:o,at:i})}invalidate(t){t?this.entries.delete(t):this.entries.clear()}get size(){return this.entries.size}}function F2(e){const t=new Map;if(!(e!=null&&e.slides))return t;const o=i=>{for(const n of i||[])n!=null&&n.id&&n.ial&&t.set(n.id,n.ial)};for(const i of e.slides)o(i.blocks),o(i.noteBlocks);return t}class j2{constructor(t=150){Ie(this,"lastBlockId","");Ie(this,"lastAt",0);this.windowMs=t}shouldSkip(t,o=Date.now()){return t&&t===this.lastBlockId&&o-this.lastAt<this.windowMs?!0:(this.lastBlockId=t,this.lastAt=o,!1)}reset(){this.lastBlockId="",this.lastAt=0}}class U2{constructor(){Ie(this,"attrCache",new H2);Ie(this,"compiledIalIndex",{doc:null,map:new Map});Ie(this,"locatingLockUntil",0);Ie(this,"lockedTargetBlockId","");Ie(this,"lastKnownPageDividerId","");Ie(this,"lastKnownDocId","")}isLocatingLocked(t){return Date.now()<this.locatingLockUntil?!(t&&t===this.lockedTargetBlockId):!1}async resolveBlockAttrs(t,o){if(!t)return{};const i=Ee.getBlockAttrOverride(t),n=this.getCompiledIal(o,t);if(i||n)return{...n||{},...i||{}};const s=this.attrCache.get(t);if(s)return s;const l=await er(t).catch(()=>({}))||{};return this.attrCache.set(t,l),l}getCompiledIal(t,o){if(t)return this.compiledIalIndex.doc!==t&&(this.compiledIalIndex={doc:t,map:F2(t)}),this.compiledIalIndex.map.get(o)}invalidateAttrCache(t){this.attrCache.invalidate(t)}getActiveDocumentId(){if(typeof document>"u")return"";const t=document.querySelector(".layout__wnd--active .protyle-title[data-node-id]")||document.querySelector(".item--focus .protyle-title[data-node-id]")||document.querySelector(".protyle-title[data-node-id]"),o=t==null?void 0:t.getAttribute("data-node-id");if(o)return o;const i=document.querySelector(".protyle .protyle-title[data-node-id]"),n=i==null?void 0:i.getAttribute("data-node-id");if(n)return n;const s=document.querySelector("[data-doc-id]"),l=s==null?void 0:s.getAttribute("data-doc-id");return l||""}resolveDocIdFromElement(t,o=""){const i=t.closest(".protyle-title"),n=i==null?void 0:i.getAttribute("data-node-id");if(n)return n;const s=t.closest(".protyle"),l=s==null?void 0:s.querySelector(".protyle-title"),r=l==null?void 0:l.getAttribute("data-node-id");if(r)return r;const a=t.closest("[data-doc-id]"),c=a==null?void 0:a.getAttribute("data-doc-id");if(c)return c;const u=this.getActiveDocumentId();return u||o}async switchToDocGlobalInspector(t,o){var s;if(!t)return;let i=o||"";if(!i&&typeof document<"u"){const l=document.querySelector(`.protyle-title[data-node-id="${t}"] .protyle-title__input`)||document.querySelector(`.protyle[data-doc-id="${t}"] .protyle-title__input`)||document.querySelector(".protyle-title__input");i=((s=l==null?void 0:l.innerText)==null?void 0:s.trim())||""}const n=await this.resolveBlockAttrs(t,null);ai({id:t,rootId:t,type:"doc",content:i,attrs:n,isDivider:!1,isCode:!1}),Xs(t)}handleBlockClickedFromSlide(t,o,i,n,s){var c,u,f,h;if(!t){qi();const d=typeof s=="number"&&s>0?s:1,b=((c=n==null?void 0:n.slides)==null?void 0:c[d-1])||((u=n==null?void 0:n.slides)==null?void 0:u[0]);if(b){const m=b.startBlockId||"",y=((f=b.frontmatter)==null?void 0:f.layout)||"",g={"custom-slides-layout":y,...b.frontmatter};return ai({id:m,rootId:i,type:"NodeThematicBreak",attrs:g,isDivider:!0,isCode:!1,isImage:!1,pageDividerId:m,pageDividerLayout:y}),this.resolveBlockAttrs(m,n).then(x=>{x&&Object.keys(x).length>0&&ai({id:m,rootId:i,type:"NodeThematicBreak",attrs:{...g,...x},isDivider:!0,isCode:!1,isImage:!1,pageDividerId:m,pageDividerLayout:y})}),!0}else return this.switchToDocGlobalInspector(i),!0}this.lockedTargetBlockId=t,this.locatingLockUntil=Date.now()+500;const l=zo(t,o),r=typeof document<"u"?document.querySelector(`.protyle-wysiwyg [data-node-id="${t}"]`)||document.querySelector(`[data-node-id="${t}"]`):null,a=(r==null?void 0:r.getAttribute("data-type"))||"";if(r)this.syncInspectorBlock(r,t,a,i,n);else{let d="",b="";if(n!=null&&n.slides){const m=n.slides.find(y=>{var g,x,k;return y.startBlockId===t||((g=y.blocks)==null?void 0:g.some(I=>I.id===t))||((x=y.allBlockIds)==null?void 0:x.includes(t))||((k=y.noteBlocks)==null?void 0:k.some(I=>I.id===t))});m!=null&&m.startBlockId&&(d=m.startBlockId),(h=m==null?void 0:m.frontmatter)!=null&&h.layout&&(b=m.frontmatter.layout)}this.resolveBlockAttrs(t,n).then(async m=>{if(d&&!b){const y=Ee.getBlockAttrOverride(d);if(y!=null&&y[be]||y!=null&&y["custom-slides-layout"])b=y[be]||y["custom-slides-layout"]||"";else{const g=await this.resolveBlockAttrs(d,n);b=g[be]||g["custom-slides-layout"]||"",g&&Object.keys(g).length>0&&Ee.setBlockAttrOverride(d,g)}}ai({id:t,rootId:i,type:a||"NodeParagraph",attrs:m||{},pageDividerId:d,pageDividerLayout:b})}).catch(()=>{})}return l}async syncInspectorBlock(t,o,i,n,s){var W,j,_,M,B,Q,q,U,ne;if(this.isLocatingLocked(o))return;let l=t,r=o,a=i;const c=typeof(t==null?void 0:t.closest)=="function"?t.closest('[data-type="NodeCallout"]'):null;if(c&&c!==t){const oe=c.getAttribute("data-node-id");if(oe){const ae=await this.resolveBlockAttrs(oe,s),Se=Ee.getBlockAttrOverride(oe)||{};({...ae,...Se})[Fe]&&(l=c,r=oe,a="NodeCallout")}}const u=l.closest(".protyle-wysiwyg > [data-node-id]")||l,f=(u==null?void 0:u.getAttribute("data-node-id"))||r,h=a==="NodeThematicBreak"||a==="tb"||a==="thematic-break"||(u==null?void 0:u.getAttribute("data-type"))==="NodeThematicBreak"||(u==null?void 0:u.getAttribute("data-type"))==="tb"||!!((W=u==null?void 0:u.classList)!=null&&W.contains("hr")),d=a==="NodeCodeBlock",b=((j=l.innerText)==null?void 0:j.trim())||"",m=await this.resolveBlockAttrs(r,s),y=Ee.getBlockAttrOverride(r)||{},g={...m,...y};let x="",k="";if(h)x=r,k=g[be]||g["custom-slides-layout"]||"";else{let oe=u.previousElementSibling;for(;oe;){const ae=oe.getAttribute("data-type");if(ae==="NodeThematicBreak"||ae==="tb"||(_=oe.classList)!=null&&_.contains("hr")){x=oe.getAttribute("data-node-id")||"";break}oe=oe.previousElementSibling}}if(s!=null&&s.slides){const oe=[r,f];let ae=l.parentElement;for(;ae&&!ae.classList.contains("protyle-wysiwyg");){const $e=ae.getAttribute("data-node-id");$e&&!oe.includes($e)&&oe.push($e),ae=ae.parentElement}const Se=s.slides.find($e=>{var ke,Ce,z;return oe.includes($e.startBlockId)||((ke=$e.blocks)==null?void 0:ke.some(se=>oe.includes(se.id)))||((Ce=$e.allBlockIds)==null?void 0:Ce.some(se=>oe.includes(se)))||((z=$e.noteBlocks)==null?void 0:z.some(se=>oe.includes(se.id)))});Se&&(!x&&Se.startBlockId&&(x=Se.startBlockId),!k&&((M=Se.frontmatter)!=null&&M.layout)&&(k=Se.frontmatter.layout))}if(x?(this.lastKnownDocId=n,this.lastKnownPageDividerId=x):n&&this.lastKnownDocId===n&&this.lastKnownPageDividerId&&(!u.previousElementSibling&&(((B=u.parentElement)==null?void 0:B.scrollTop)||0)===0||(x=this.lastKnownPageDividerId)),x){const oe=Ee.getBlockAttrOverride(x);if(oe&&(be in oe||"custom-slides-layout"in oe)&&(k=oe[be]||oe["custom-slides-layout"]||""),!k&&(s!=null&&s.slides)){const ae=s.slides.find(Se=>Se.startBlockId===x);(Q=ae==null?void 0:ae.frontmatter)!=null&&Q.layout&&(k=ae.frontmatter.layout)}if(!k){const ae=await this.resolveBlockAttrs(x,s);k=ae[be]||ae["custom-slides-layout"]||"",ae&&Object.keys(ae).length>0&&Ee.setBlockAttrOverride(x,ae)}et(x,{[be]:k||""})}else if(n){const oe=Ee.getBlockAttrOverride(n);oe&&(be in oe||"custom-slides-layout"in oe)?k=oe[be]||oe["custom-slides-layout"]||"":!k&&((ne=(U=(q=s==null?void 0:s.slides)==null?void 0:q[0])==null?void 0:U.frontmatter)!=null&&ne.layout)&&(k=s.slides[0].frontmatter.layout)}const I=l.getAttribute(be)||l.getAttribute("custom-slides-layout"),T=g[be]||g["custom-slides-layout"]||"";I&&I!==T&&et(r,{[be]:T});const w=l.getAttribute(Ze)||l.getAttribute("custom-slides-role"),C=g[Ze]||g["custom-slides-role"]||"";w&&w!==C&&et(r,{[Ze]:C});let L="",R="",N="";const F=l.closest('[data-type="NodeListItem"]');if(F&&F!==l){const oe=F.getAttribute("data-node-id");if(oe){L=oe;const ae=await this.resolveBlockAttrs(oe,s),Se=Ee.getBlockAttrOverride(oe)||{},$e={...ae,...Se};R=$e[Ae]||"",N=$e[Ne]||"";const ke=$e[be]||$e["custom-slides-layout"]||"",Ce=F.getAttribute(be)||F.getAttribute("custom-slides-layout");Ce&&Ce!==ke&&et(oe,{[be]:ke});const z=$e[Ze]||$e["custom-slides-role"]||"",se=F.getAttribute(Ze)||F.getAttribute("custom-slides-role");se&&se!==z&&et(oe,{[Ze]:z})}}const E=!!l.querySelector("img, span[data-type='img']"),O=(l.innerText||"").replace(/[\r\n\t\s]+/g," ").trim(),S=E&&O.length<=50;ai({id:r,rootId:n,type:a,content:b,attrs:g,isDivider:h,isCode:d,isImage:S,topBlockId:f,pageDividerId:x,pageDividerLayout:k,parentContainerId:L,parentContainerSlot:R,parentContainerClicks:N})}patchThematicBreakTransactions(t){if((t==null?void 0:t.cmd)==="transactions"&&Array.isArray(t.data)){for(const o of t.data)if(Array.isArray(o==null?void 0:o.doOperations)){for(const i of o.doOperations)if((i==null?void 0:i.action)==="updateAttrs"&&i.id&&i.data){const n=i.data.old||{},s=i.data.new||{},l={};for(const r of Object.keys(n))r in s||(l[r]="");for(const[r,a]of Object.entries(s))l[r]=String(a??"");et(i.id,l),Ee.setBlockAttrOverride(i.id,l)}}}}purgeStaleDomSlidesAttrs(t){var n,s,l;if(typeof document>"u"||!t)return;const o=new Map;if(Array.isArray(t.slides))for(const r of t.slides){if(r.startBlockId){const a=o.get(r.startBlockId)||{};(n=r.frontmatter)!=null&&n.layout&&(a[be]=r.frontmatter.layout),o.set(r.startBlockId,a)}if(Array.isArray(r.blocks)){for(const a of r.blocks)if(a.id){const c=o.get(a.id)||{};(s=a.ial)!=null&&s[be]&&(c[be]=a.ial[be]),(l=a.ial)!=null&&l[Ze]&&(c[Ze]=a.ial[Ze]),Object.keys(c).length>0&&o.set(a.id,c)}}}const i=Ee.getAllAttrOverrides();for(const[r,a]of i.entries()){const c=o.get(r)||{};a[be]!==void 0&&(c[be]=a[be]),a[Ze]!==void 0&&(c[Ze]=a[Ze]),o.set(r,c)}Uw(o)}}const Lo=new U2;class W2{constructor(){Ie(this,"state","IDLE");Ie(this,"inFlightDocId",null);Ie(this,"pendingDocs",new Set);Ie(this,"lastPendingDocId",null);Ie(this,"generation",0)}get currentState(){return this.state}get isRunning(){return this.state==="COMPILING"}get runningDocId(){return this.inFlightDocId}get pending(){return this.lastPendingDocId}get pendingList(){return Array.from(this.pendingDocs)}tryBegin(t){return this.state==="COMPILING"||this.inFlightDocId!==null?(this.pendingDocs.add(t),this.lastPendingDocId=t,null):(this.state="COMPILING",this.inFlightDocId=t,++this.generation)}isStale(t){return t!==this.generation}finishBatch(){this.state="IDLE",this.inFlightDocId=null,this.lastPendingDocId=null;const t=Array.from(this.pendingDocs);return this.pendingDocs.clear(),t}finish(){const t=this.finishBatch();return t.length>0?t[t.length-1]:null}reset(){this.state="IDLE",this.inFlightDocId=null,this.pendingDocs.clear(),this.lastPendingDocId=null,this.generation=0}}function q2(e){if(!e||typeof e.closest!="function")return;e.classList.remove("fn__flex-center","fn__size200"),e.style.width="100%",e.style.height="auto",e.style.minHeight="0",e.style.flex="none",e.style.alignSelf="stretch";const t=e.parentElement,o=e.closest(".config-item, .config__item, .b3-label")||t,i=(o==null?void 0:o.querySelector(":scope > .fn__flex-1, :scope > .fn__block, :scope .config-name, :scope .fn__flex-1"))||(o==null?void 0:o.querySelector(".config-name, .fn__flex-1")),n=o==null?void 0:o.querySelector(".fn__space");o instanceof HTMLElement&&(o.classList.add("slides-settings__host-item"),o.style.height="auto",o.style.minHeight="0",o.style.alignItems="stretch",o.style.flexDirection="column"),t instanceof HTMLElement&&t!==o&&(t.classList.add("slides-settings__host-block"),t.style.width="100%",t.style.height="auto",t.style.minHeight="0"),i instanceof HTMLElement&&(i.classList.add("slides-settings__host-title"),i.style.overflow="visible",i.style.minHeight="0",i.style.textAlign="left"),n instanceof HTMLElement&&(n.style.display="none")}function V2(e){if(!e||typeof e.closest!="function")return;e.classList.remove("fn__flex-center","fn__size200","fn__block");const t=e.matches(".b3-switch")?e:e.querySelector(".b3-switch");t&&t.classList.remove("fn__flex-center","fn__size200","fn__block");const o=e.closest(".config-item, .config__item, .b3-label")||e.parentElement,i=o==null?void 0:o.querySelector(":scope > .fn__flex-1, .config-name");o instanceof HTMLElement&&(o.classList.add("slides-settings__host-row"),o.style.height="auto",o.style.minHeight="0",o.style.alignItems="center"),i instanceof HTMLElement&&(i.classList.add("slides-settings__host-title"),i.style.overflow="visible",i.style.minHeight="0",i.style.textAlign="left")}function K2(e,t,o){if(!e||typeof e.open!="function")return;const i=e.open.bind(e),n=()=>{t.forEach(s=>q2(s)),o.forEach(s=>V2(s))};e.open=(s=>{i(s),n(),typeof setTimeout=="function"&&setTimeout(()=>{n()},0)})}function bn(e){const t=document.createElement("div");return t.className="slides-settings__switch-wrap",t.style.cssText="display: inline-flex; align-items: center; justify-content: flex-end;",t.appendChild(e),t}const Ra='<svg class="slides-settings__api-key-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M2.25 12s3.75-6.75 9.75-6.75S21.75 12 21.75 12 18 18.75 12 18.75 2.25 12Z"/><circle cx="12" cy="12" r="3.25"/></svg>',G2='<svg class="slides-settings__api-key-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M3 3l18 18"/><path d="M10.7 5.52A10.56 10.56 0 0 1 12 5.25c6 0 9.75 6.75 9.75 6.75a18.78 18.78 0 0 1-4.02 4.85M6.68 6.69C4.04 8.42 2.25 12 2.25 12s3.75 6.75 9.75 6.75c1.85 0 3.47-.64 4.85-1.55M9.88 9.88A3 3 0 0 0 9 12a3 3 0 0 0 3 3c.8 0 1.53-.31 2.07-.82"/></svg>';function Y2(e){const t=new ie.Setting({width:"680px"}),o=jo();let i=pp();const n=document.createElement("div");n.className="slides-settings__ai-panel",n.style.cssText="display: flex; flex-direction: column; gap: 12px; width: 100%; text-align: left; box-sizing: border-box;";const s=document.createElement("div");s.className="slides-settings__tip-container",s.style.cssText="width: 100%; text-align: left;",n.appendChild(s);function l(_){var M,B;if(s.innerHTML="",_){const Q=document.createElement("div");Q.className="api-switch-managed-tip",Q.style.cssText=`
        background-color: var(--b3-theme-primary-light, rgba(63, 81, 181, 0.08));
        border: 1px solid var(--b3-theme-primary, rgba(63, 81, 181, 0.2));
        border-radius: 6px;
        padding: 8px 12px;
        font-size: 12px;
        line-height: 1.5;
        color: var(--b3-theme-on-background);
        text-align: left;
      `;const q=((B=(M=window.siyuan)==null?void 0:M.config)==null?void 0:B.lang)==="en_US",U=_.profileName||(q?"Unnamed":"未命名");Q.innerHTML=q?`💡 General AI API is managed by <strong>API Switch (siyuan-api-switch)</strong> (Profile: ${U}). Related inputs are read-only. Please configure in the API Switch panel.`:`💡 通用 AI API 已由 <strong>API 旋钮 (siyuan-api-switch)</strong> 接管 (Profile: ${U})。相关输入框已置灰只读，如需修改请前往 API 旋钮面板。`,s.appendChild(Q)}}l(i);function r(_,M,B){const Q=document.createElement("div");Q.className="slides-settings__field-row",Q.style.cssText="display: flex; flex-direction: column; gap: 4px; width: 100%; text-align: left;";const q=document.createElement("div");q.className="slides-settings__field-main",q.style.cssText="display: flex; align-items: center; justify-content: space-between; gap: 16px; width: 100%;";const U=document.createElement("span");if(U.className="slides-settings__field-label",U.style.cssText="font-size: 13px; font-weight: 500; min-width: 160px; color: var(--b3-theme-on-background); text-align: left; flex-shrink: 0;",U.textContent=_,q.appendChild(U),q.appendChild(M),Q.appendChild(q),B){const ne=document.createElement("span");ne.className="slides-settings__field-desc",ne.style.cssText="font-size: 11px; color: var(--b3-theme-on-surface); line-height: 1.4; text-align: left;",ne.textContent=B,Q.appendChild(ne)}return Q}const a=document.createElement("input");a.className="b3-text-field fn__flex-1",a.placeholder="https://api.openai.com/v1",a.dataset.settingKey="ai-base-url",a.value=i?i.baseUrl:o.aiConfig.baseUrl,a.disabled=!!i,a.addEventListener("change",async()=>{const _=a.value.trim();await j({baseUrl:_})});const c=document.createElement("div");c.className="slides-settings__api-key-wrap",c.style.cssText="position: relative; display: flex; align-items: center; width: 100%; flex: 1;";const u=document.createElement("input");u.className="b3-text-field slides-settings__api-key-input fn__flex-1",u.type="password",u.placeholder="sk-...",u.dataset.settingKey="ai-api-key",u.style.cssText="width: 100%; padding-right: 36px; box-sizing: border-box;",u.value=i?i.apiKey:o.aiConfig.apiKey,u.disabled=!!i,u.addEventListener("change",async()=>{const _=u.value.trim();await j({apiKey:_})});let f=!1;const h=document.createElement("button");h.className="slides-settings__api-key-toggle",h.type="button",h.innerHTML=Ra,h.title="显示 API Key",typeof h.setAttribute=="function"&&h.setAttribute("aria-label","显示 API Key"),h.disabled=!!i,h.addEventListener("click",()=>{f=!f,u.type=f?"text":"password",h.innerHTML=f?G2:Ra,h.title=f?"隐藏 API Key":"显示 API Key",typeof h.setAttribute=="function"&&h.setAttribute("aria-label",f?"隐藏 API Key":"显示 API Key")}),c.appendChild(u),c.appendChild(h);const d=document.createElement("input");d.className="b3-text-field fn__flex-1",d.placeholder="gpt-4o-mini / deepseek-chat",d.dataset.settingKey="ai-model",d.value=i?i.model:o.aiConfig.model,d.disabled=!!i,d.addEventListener("change",async()=>{const _=d.value.trim();await j({model:_})});const b=document.createElement("details");b.style.cssText="margin-top: 4px; font-size: 12px;";const m=document.createElement("summary");m.style.cssText="cursor: pointer; color: var(--b3-theme-primary); font-weight: 500; padding: 4px 0;",m.textContent="高级模型参数 (超时/采样温度/Token)",b.appendChild(m);const y=document.createElement("div");y.className="slides-settings__advanced-body",y.style.cssText="display: flex; flex-direction: column; gap: 8px; padding-top: 8px; text-align: left; width: 100%;";const g=document.createElement("input");g.className="b3-text-field fn__flex-1",g.type="number",g.dataset.settingKey="ai-timeout",g.value=String((i==null?void 0:i.requestTimeoutSeconds)??o.aiConfig.requestTimeoutSeconds??gt.requestTimeoutSeconds),g.disabled=!!i,g.addEventListener("change",async()=>{const _=Number.parseInt(g.value,10)||gt.requestTimeoutSeconds;await j({requestTimeoutSeconds:_})});const x=document.createElement("input");x.className="b3-text-field fn__flex-1",x.type="number",x.step="0.1",x.dataset.settingKey="ai-temperature",x.value=String((i==null?void 0:i.temperature)??o.aiConfig.temperature??gt.temperature),x.disabled=!!i,x.addEventListener("change",async()=>{const _=Number.parseFloat(x.value)||gt.temperature;await j({temperature:_})});const k=document.createElement("input");k.className="b3-text-field fn__flex-1",k.type="number",k.dataset.settingKey="ai-max-tokens",k.value=String((i==null?void 0:i.maxTokens)??o.aiConfig.maxTokens??gt.maxTokens),k.disabled=!!i,k.addEventListener("change",async()=>{const _=Number.parseInt(k.value,10)||gt.maxTokens;await j({maxTokens:_})}),y.appendChild(r("请求超时时间 (秒)",g)),y.appendChild(r("采样温度 (Temperature)",x,"范围 0.0 - 2.0，数值越高越富有创意")),y.appendChild(r("单次最大输出 Token",k)),b.appendChild(y);const I=document.createElement("div");I.className="slides-settings__test-row",I.style.cssText="display: flex; align-items: center; gap: 12px; margin-top: 8px; text-align: left; width: 100%;";const T=document.createElement("button");T.className="b3-button b3-button--outline",T.type="button",T.textContent="测试连接";const w=document.createElement("span");w.className="slides-settings__test-status",w.style.cssText="font-size: 12px; color: var(--b3-theme-on-surface); flex: 1; word-break: break-all; text-align: left;",T.addEventListener("click",async()=>{const _=i||{baseUrl:a.value.trim(),apiKey:u.value.trim(),model:d.value.trim(),requestTimeoutSeconds:Number.parseInt(g.value,10)||15,temperature:Number.parseFloat(x.value)||.7,maxTokens:10};if(!Wn(_)){w.style.color="var(--b3-theme-error, #f44336)",w.textContent="请先填写完整的 Base URL、API Key 与 Model";return}T.disabled=!0,w.style.color="var(--b3-theme-primary)",w.textContent="正在发起测试请求...";const M=await Zw(_);T.disabled=!1,M.success?(w.style.color="var(--b3-theme-primary, #4caf50)",w.textContent=M.message):(w.style.color="var(--b3-theme-error, #f44336)",w.textContent=M.message)}),I.appendChild(T),I.appendChild(w),n.appendChild(r("API 基础地址 (Base URL)",a)),n.appendChild(r("API 鉴权密钥 (API Key)",c)),n.appendChild(r("模型名称 (Model)",d)),n.appendChild(b),n.appendChild(I),t.addItem({title:"AI 演讲提词服务",direction:"row",description:"配置兼容 OpenAI API 的大模型服务，用于提炼演讲口播提词卡 (Notes)。支持被「API 旋钮」集中调度接管。",actionElement:n});const C=document.createElement("input");C.className="b3-switch fn__flex-center",C.type="checkbox",C.checked=o.enableWebServeJump,C.addEventListener("change",async()=>{const _=C.checked;L.disabled=!_,mt({enableWebServeJump:_}),await e.saveGlobalSettings({enableWebServeJump:_})});const L=document.createElement("input");L.className="b3-text-field fn__size200",L.value=o.webServeUrl,L.placeholder="http://127.0.0.1:6806",L.disabled=!o.enableWebServeJump,L.addEventListener("change",async()=>{const _=L.value.trim()||ko.webServeUrl;mt({webServeUrl:_}),await e.saveGlobalSettings({webServeUrl:_})});const R=bn(C);t.addItem({title:"启用网络伺服链接外跳",description:"开启后，幻灯片中的思源块引用链接可以点击以外部网络伺服抽屉呈现",actionElement:R}),t.addItem({title:"伺服主机地址",description:"思源笔记桌面端 WebServe 伺服地址 (如 http://127.0.0.1:6806)",actionElement:L});const N=document.createElement("input");N.className="b3-switch fn__flex-center",N.type="checkbox",N.checked=o.normalizeHeadingSizes,N.addEventListener("change",async()=>{const _=N.checked;mt({normalizeHeadingSizes:_}),await e.saveGlobalSettings({normalizeHeadingSizes:_})});const F=document.createElement("input");F.className="b3-switch fn__flex-center",F.type="checkbox",F.checked=o.showUnorderedListMarkers,F.addEventListener("change",async()=>{const _=F.checked;mt({showUnorderedListMarkers:_}),await e.saveGlobalSettings({showUnorderedListMarkers:_})});const E=document.createElement("input");E.className="b3-switch fn__flex-center",E.type="checkbox",E.checked=o.showOrderedListMarkers,E.addEventListener("change",async()=>{const _=E.checked;mt({showOrderedListMarkers:_}),await e.saveGlobalSettings({showOrderedListMarkers:_})});const O=bn(N),S=bn(F),W=bn(E);t.addItem({title:"固定特定标题大小",description:"开启后限制正文大标题在幻灯片中不超出安全展示画幅",actionElement:O}),t.addItem({title:"无序列表圆点前缀标记",description:"开启后在无序列表项前展示圆点前缀标记",actionElement:S}),t.addItem({title:"有序列表数字序号标记",description:"开启后在有序列表项前展示数字序号标记",actionElement:W}),K2(t,[n],[R,L,O,S,W]);async function j(_){const M=jo().aiConfig,B=vi({...M,..._});mt({aiConfig:B}),await e.saveGlobalSettings({aiConfig:B}),window.siyuanApiSwitch&&window.siyuanApiSwitch.updateLocalConfig(e.name,{provider:"custom",baseUrl:B.baseUrl,apiKey:B.apiKey,model:B.model,requestTimeoutSeconds:B.requestTimeoutSeconds,temperature:B.temperature,maxTokens:B.maxTokens})}return t.updateManagedConfig=_=>{i=_,l(_);const M=!!_,B=jo().aiConfig;a.disabled=M,u.disabled=M,h.disabled=M,d.disabled=M,g.disabled=M,x.disabled=M,k.disabled=M,a.value=_?_.baseUrl:B.baseUrl,u.value=_?_.apiKey:B.apiKey,d.value=_?_.model:B.model,g.value=String((_==null?void 0:_.requestTimeoutSeconds)??B.requestTimeoutSeconds),x.value=String((_==null?void 0:_.temperature)??B.temperature),k.value=String((_==null?void 0:_.maxTokens)??B.maxTokens),w.textContent=""},t}const Z2=150,J2=`<symbol id="iconSlides" viewBox="0 0 1024 1024">
  <path fill="currentColor" d="M128 160h768c35.3 0 64 28.7 64 64v480c0 35.3-28.7 64-64 64H128c-35.3 0-64-28.7-64-64V224c0-35.3 28.7-64 64-64z m64 64v480h640V224H192z m128 640h384v64H320z"/>
  <path fill="currentColor" d="M416 336l256 144-256 144z"/>
</symbol>`,X2="slides-dock",As="slides-preview-tab",za="slides-presenter-tab",Ha=up;class Q2 extends ie.Plugin{constructor(){super(...arguments);Ie(this,"isMobile",!1);Ie(this,"currentDocId","");Ie(this,"previewTab",null);Ie(this,"latestCompiledDoc",null);Ie(this,"setting",null);Ie(this,"debounceTimer",null);Ie(this,"activeCursorBlockId","");Ie(this,"cancelledCursorBlockId","");Ie(this,"compileScheduler",new W2);Ie(this,"dirtyDocId",null);Ie(this,"inspectorSyncThrottle",new j2);Ie(this,"onSwitchProtyleBound",this.onSwitchProtyle.bind(this));Ie(this,"onWsMainBound",this.onWsMain.bind(this));Ie(this,"onBlockClickedBound",this.onBlockClickedFromSlide.bind(this));Ie(this,"onEditorClickBound",this.onEditorClick.bind(this));Ie(this,"onSelectionChangeBound",this.onSelectionChange.bind(this));Ie(this,"onClickEditorContentBound",this.onClickEditorContent.bind(this));Ie(this,"onVisibilityChangeBound",this.onVisibilityChange.bind(this));Ie(this,"isOpeningSetting",!1)}async onload(){const o=ie.getFrontend();this.isMobile=o==="mobile"||o==="browser-mobile",await this.loadGlobalSettings(),this.initApiSwitchSync(),this.addIcons(J2),this.addTopBar({id:"slides-topbar-play",icon:"iconSlides",title:"即现",position:"right",callback:()=>{this.openBottomPreviewTab()}}),z2(this);const i=this;if(this.addTab({type:As,init(n){var r;const s=this||n;i.previewTab=(s==null?void 0:s.tab)||null,E2(s.element,i);const l=(r=s==null?void 0:s.data)==null?void 0:r.docId;l&&!i.getActiveDocumentId()&&i.compileCurrentDocument(l,{reason:"explicit"}),i.updatePreviewTabHeader()},destroy(){i.previewTab===(this==null?void 0:this.tab)&&(i.previewTab=null),Rc(this.element)}}),this.addTab({type:za,init(n){L2((this||n).element,i)},destroy(){zc(this.element)}}),this.addDock({config:{position:"RightTop",size:{width:320,height:0},icon:"iconSlides",title:"即现配置"},data:{},type:X2,init(){N2(this.element,i)},destroy(){Hc(this.element)}}),this.eventBus&&typeof this.eventBus.emit!="function"&&(this.eventBus.emit=(n,s)=>{try{typeof window<"u"&&window.dispatchEvent(new CustomEvent(`siyuan-event-${n}`,{detail:s}))}catch{}}),this.eventBus.on("switch-protyle",this.onSwitchProtyleBound),this.eventBus.on("ws-main",this.onWsMainBound),this.eventBus.on("slides:request-compile",()=>this.compileCurrentDocument()),this.eventBus.on("slides:block-clicked",this.onBlockClickedBound),this.eventBus.on("click-editorcontent",this.onClickEditorContentBound),typeof document<"u"&&(document.addEventListener("click",this.onEditorClickBound,!0),document.addEventListener("selectionchange",this.onSelectionChangeBound),document.addEventListener("visibilitychange",this.onVisibilityChangeBound)),typeof document<"u"){const n=()=>{const s=this.getActiveDocumentId();s&&(s!==this.currentDocId&&(this.currentDocId=s,this.updatePreviewTabHeader("",s)),this.latestCompiledDoc||this.markCompileDirty(s))};setTimeout(n,300),setTimeout(n,1e3)}}async onDataChanged(o){await this.loadGlobalSettings(),this.currentDocId&&this.markCompileDirty(this.currentDocId)}async loadGlobalSettings(){try{const o=await this.loadData(Ha),i=hp(o);return mt(i),i}catch{return mt(ko),ko}}async saveGlobalSettings(o){const i=jo(),n=mt({...i,...o||{}});try{await this.saveData(Ha,n)}catch(l){console.error("保存即现全局配置失败",l)}const s=this.currentDocId||this.getActiveDocumentId();return s&&this.markCompileDirty(s),n}openSetting(){if(!this.isOpeningSetting){this.isOpeningSetting=!0;try{this.setting=Y2(this),this.setting.open(this.name)}finally{setTimeout(()=>{this.isOpeningSetting=!1},500)}}}initApiSwitchSync(){const o=s=>{if(fp(s),this.setting){const l=this.setting.updateManagedConfig;typeof l=="function"&&l(s)}},i=()=>{const s=jo().aiConfig;return{provider:"custom",baseUrl:s.baseUrl,apiKey:s.apiKey,model:s.model,requestTimeoutSeconds:s.requestTimeoutSeconds,temperature:s.temperature,maxTokens:s.maxTokens}},n=()=>{window.siyuanApiSwitch&&window.siyuanApiSwitch.register(this.name,this.displayName||"即现 (SiYuan Live Slides)",o,i())};window.siyuanApiSwitch?n():window.addEventListener("siyuan-api-switch:ready",()=>{n()},{once:!0})}onunload(){window.siyuanApiSwitch&&window.siyuanApiSwitch.unregister(this.name),this.debounceTimer&&(window.clearTimeout(this.debounceTimer),this.debounceTimer=null),this.compileScheduler.reset(),this.inspectorSyncThrottle.reset(),this.dirtyDocId=null,$n.clear(),this.eventBus.off("switch-protyle",this.onSwitchProtyleBound),this.eventBus.off("ws-main",this.onWsMainBound),this.eventBus.off("click-editorcontent",this.onClickEditorContentBound),typeof document<"u"&&(document.removeEventListener("click",this.onEditorClickBound,!0),document.removeEventListener("selectionchange",this.onSelectionChangeBound),document.removeEventListener("visibilitychange",this.onVisibilityChangeBound)),Ti.detach()}onVisibilityChange(){typeof document<"u"&&document.visibilityState==="visible"&&this.flushDirtyCompile()}async openBottomPreviewTab(){this.currentDocId||(this.currentDocId=this.getActiveDocumentId());const o=this.currentDocId?await this.fetchDocumentTitle(this.currentDocId):"",i=this.buildPreviewTabTitle(o);await ie.openTab({app:this.app,custom:{id:this.name+As,title:i,icon:"iconSlides",data:{docId:this.currentDocId}},position:"bottom"}),this.currentDocId&&this.compileCurrentDocument(this.currentDocId),this.updatePreviewTabHeader(o,this.currentDocId)}async openPresenterTab(){qt("presenterMode")||(B2()||await this.openBottomPreviewTab(),await ie.openTab({app:this.app,custom:{id:this.name+za,title:"演讲者控制台",icon:"iconSlides",data:{}},position:"right"}))}async openStandalonePreviewWindow(){this.currentDocId||(this.currentDocId=this.getActiveDocumentId()),this.currentDocId&&!this.latestCompiledDoc&&await this.compileCurrentDocument(this.currentDocId,{reason:"explicit"});const o=ie.getFrontend();if(o==="browser-desktop"||o==="browser-mobile"){typeof window<"u"&&typeof window.open=="function"&&window.open("/plugins/siyuan-live-slides/slides-client/index.html","SlidesBigScreenWindow","width=1280,height=760,menubar=no,toolbar=no,location=no,status=no");return}let i=this.previewTab;if(!i){const n=this.currentDocId?await this.fetchDocumentTitle(this.currentDocId):"",s=this.buildPreviewTabTitle(n),l=await ie.openTab({app:this.app,custom:{id:this.name+As,title:s,icon:"iconSlides",data:{docId:this.currentDocId}},position:"bottom"});i=this.previewTab||l}i&&(this.currentDocId&&i.model&&(i.model.data={...i.model.data||{},docId:this.currentDocId}),ie.openWindow({tab:i,width:1280,height:760}))}async onSwitchProtyle(o){var l,r,a,c,u;const i=(l=o.detail)==null?void 0:l.protyle,n=(r=i==null?void 0:i.block)==null?void 0:r.rootID,s=((u=(c=(a=i==null?void 0:i.title)==null?void 0:a.editElement)==null?void 0:c.textContent)==null?void 0:u.trim())||"";if(n&&n!==this.currentDocId){this.cancelledCursorBlockId="",this.currentDocId=n,this.activeCursorBlockId=n;const f=await er(n).catch(()=>({}));ai({id:n,rootId:n,type:"doc",attrs:f}),this.markCompileDirty(n),this.updatePreviewTabHeader(s,n)}}onClickEditorContent(o){var s,l;const i=o==null?void 0:o.detail;if(!i)return;const n=(l=(s=i.protyle)==null?void 0:s.block)==null?void 0:l.rootID;n&&(!this.currentDocId||this.currentDocId!==n)&&(this.currentDocId=n),i.event&&this.onEditorClick(i.event)}buildPreviewTabTitle(o){return yc(o)}async fetchDocumentTitle(o){return bc(this,o)}async updatePreviewTabHeader(o,i){return Bg(this,o,i)}getActiveDocumentId(){return Lo.getActiveDocumentId()}resolveDocIdFromElement(o){return Lo.resolveDocIdFromElement(o,this.currentDocId)}async switchToDocGlobalInspector(o,i){o&&(this.activeCursorBlockId=o,this.currentDocId=o,await Lo.switchToDocGlobalInspector(o,i))}onWsMain(o){const i=o.detail;i&&i.cmd==="transactions"&&(Lo.patchThematicBreakTransactions(i),this.markCompileDirty())}markCompileDirty(o){const i=o||this.currentDocId||this.getActiveDocumentId();i&&(this.currentDocId||(this.currentDocId=i),this.dirtyDocId=i,this.scheduleDirtyCompile())}scheduleDirtyCompile(o=Z2){if(this.debounceTimer&&(window.clearTimeout(this.debounceTimer),this.debounceTimer=null),!this.dirtyDocId)return;const i=$n.getVisibility();if(i==="none")return;const n=i==="visible"?o:Math.max(o,I2);this.debounceTimer=window.setTimeout(()=>{this.debounceTimer=null;const s=this.dirtyDocId;this.dirtyDocId=null,s&&this.compileCurrentDocument(s,{reason:"auto"})},n)}flushDirtyCompile(){this.dirtyDocId&&this.scheduleDirtyCompile(0)}handleBlockClickedFromSlide(o,i){return o?(this.cancelledCursorBlockId="",this.activeCursorBlockId=o):(this.cancelledCursorBlockId=this.activeCursorBlockId,this.activeCursorBlockId=""),Lo.handleBlockClickedFromSlide(o,this.app,this.currentDocId,this.latestCompiledDoc,i)}onBlockClickedFromSlide(o){const i=(o==null?void 0:o.detail)||o;i!=null&&i.blockId&&this.handleBlockClickedFromSlide(i.blockId,i.page)}onEditorClick(o){var f,h;const i=o.target;if(!i)return;const n=((f=i.closest)==null?void 0:f.call(i,".protyle"))||((h=i.closest)==null?void 0:h.call(i,".protyle-wysiwyg"));if(Ta(n))return;const s=i.closest(".protyle-title")||i.closest(".protyle-background");if(!!s){const d=this.resolveDocIdFromElement(i);if(d&&this.activeCursorBlockId!==d){const b=s||document.querySelector(`.protyle-title[data-node-id="${d}"]`)||document.querySelector(`.protyle[data-doc-id="${d}"] .protyle-title`),m=b==null?void 0:b.querySelector(".protyle-title__input"),y=((m==null?void 0:m.innerText)||(b==null?void 0:b.innerText)||"").trim();this.switchToDocGlobalInspector(d,y)}return}if(!i.closest(".protyle-wysiwyg"))return;const a=i.closest("[data-node-id]");if(!a)return;const c=a.getAttribute("data-node-id"),u=a.getAttribute("data-type")||"";c&&(this.cancelledCursorBlockId="",this.currentDocId||(this.currentDocId=this.resolveDocIdFromElement(i)||""),this.currentDocId&&!this.latestCompiledDoc&&this.markCompileDirty(this.currentDocId),c!==this.activeCursorBlockId&&(this.activeCursorBlockId=c,Xs(c)),this.syncInspectorBlock(a,c,u))}onSelectionChange(){var f,h;if(typeof window>"u")return;const o=window.getSelection();if(!o||o.rangeCount===0)return;const i=o.anchorNode;if(!i)return;const n=i.nodeType===Node.ELEMENT_NODE?i:i.parentElement;if(!n)return;const s=((f=n.closest)==null?void 0:f.call(n,".protyle"))||((h=n.closest)==null?void 0:h.call(n,".protyle-wysiwyg"));if(Ta(s))return;const l=n.closest(".protyle-title")||n.closest(".protyle-background");if(!!l){const d=this.resolveDocIdFromElement(n);if(d&&this.activeCursorBlockId!==d){const b=l||document.querySelector(`.protyle-title[data-node-id="${d}"]`)||document.querySelector(`.protyle[data-doc-id="${d}"] .protyle-title`),m=b==null?void 0:b.querySelector(".protyle-title__input"),y=((m==null?void 0:m.innerText)||(b==null?void 0:b.innerText)||"").trim();this.switchToDocGlobalInspector(d,y)}return}if(!n.closest(".protyle-wysiwyg"))return;const a=n.closest("[data-node-id]"),c=a==null?void 0:a.getAttribute("data-node-id"),u=(a==null?void 0:a.getAttribute("data-type"))||"";if(a&&c){if(Lo.isLocatingLocked(c))return;if(this.currentDocId||(this.currentDocId=this.resolveDocIdFromElement(n)||""),this.currentDocId&&!this.latestCompiledDoc&&this.markCompileDirty(this.currentDocId),c!==this.activeCursorBlockId){if(c===this.cancelledCursorBlockId)return;this.activeCursorBlockId=c,Xs(c)}this.syncInspectorBlock(a,c,u)}}async syncInspectorBlock(o,i,n){this.inspectorSyncThrottle.shouldSkip(i)||await Lo.syncInspectorBlock(o,i,n,this.currentDocId,this.latestCompiledDoc)}async compileCurrentDocument(o,i){const n=(i==null?void 0:i.reason)??"explicit";let s=o||this.currentDocId;if(!s){const r=this.getActiveDocumentId();if(r)this.currentDocId=r,s=r;else return}if(n==="auto"&&$n.getVisibility()==="none"){this.dirtyDocId=s;return}const l=this.compileScheduler.tryBegin(s);if(l!==null){this.dirtyDocId===s&&(this.dirtyDocId=null);try{const r=await Ee.compile(s),a=!!this.currentDocId&&s!==this.currentDocId;!this.compileScheduler.isStale(l)&&!a&&(this.currentDocId||(this.currentDocId=s),this.latestCompiledDoc=r,O2(r,s),this.updatePreviewTabHeader("",s),this.purgeStaleDomSlidesAttrs(r))}catch(r){console.error("[SiYuanLiveSlides] Failed to compile document:",r)}finally{const r=this.compileScheduler.finishBatch(),a=r.length>0?r[0]:this.compileScheduler.finish();a&&this.markCompileDirty(a);for(let c=1;c<r.length;c++)this.markCompileDirty(r[c])}}}purgeStaleDomSlidesAttrs(o){Lo.purgeStaleDomSlidesAttrs(o)}}module.exports=Q2;
