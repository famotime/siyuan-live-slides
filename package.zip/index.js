"use strict";var $d=Object.defineProperty;var Td=(e,t,o)=>t in e?$d(e,t,{enumerable:!0,configurable:!0,writable:!0,value:o}):e[t]=o;var Ie=(e,t,o)=>Td(e,typeof t!="symbol"?t+"":t,o);const ie=require("siyuan");async function Bt(e,t){const o=await ie.fetchSyncPost(e,t);return o.code===0?o.data:null}async function Ad(){return Bt("/api/notebook/lsNotebooks","")}async function Md(e,t,o){return Bt("/api/filetree/createDocWithMd",{notebook:e,path:t,markdown:o})}async function Fl(e,t){const o=new FormData;o.append("assetsDirPath",e);for(const n of t)o.append("file[]",n);return Bt("/api/asset/upload",o)}async function fo(e,t,o,i,n){return Bt("/api/block/insertBlock",{dataType:e,data:t,nextID:o,previousID:i,parentID:n})}async function bn(e,t,o){return Bt("/api/block/appendBlock",{dataType:e,data:t,parentID:o})}async function Ms(e,t,o){return Bt("/api/block/updateBlock",{dataType:e,data:t,id:o})}async function Qs(e){return Bt("/api/block/deleteBlock",{id:e})}async function Dr(e){return Bt("/api/transactions",{reqId:Date.now(),transactions:e})}async function Ed(e){return Bt("/api/block/getBlockKramdown",{id:e})}async function Si(e){return Bt("/api/block/getChildBlocks",{id:e})}async function Bd(e){return Bt("/api/block/getDocBlocksOrders",{id:e})}async function ze(e,t){return Bt("/api/attr/setBlockAttrs",{id:e,attrs:t})}async function er(e){return Bt("/api/attr/getBlockAttrs",{id:e})}async function vi(e){return Bt("/api/query/sql",{stmt:e})}async function jl(e,t="GET",o={},i=[],n=15e3,s="application/json"){const l=await ie.fetchSyncPost("/api/network/forwardProxy",{url:e,method:t,timeout:n,contentType:s,headers:i,payload:o});if(!l||l.code!==0){const r=(l==null?void 0:l.msg)||"思源内核代理转发请求失败";throw new Error(r)}return l.data}async function Ld(){return Bt("/api/storage/getInlineStyles","")}function Or(e){return e.markdown&&e.markdown.trim()?e.markdown.trim():e.content&&e.content.trim()?e.content.trim():""}function Ul(e){const t={};if(!e)return t;const o=e.replace(/^\{:\s*/,"").replace(/\s*\}$/,""),i=/([\w-]+)=(?:"([^"]*)"|'([^']*)'|(\S+))/g;let n;for(;(n=i.exec(o))!==null;){const s=n[1],l=n[2]??n[3]??n[4]??"";t[s]=l}return t}const Wl=/\(\(([0-9a-zA-Z-]+)(?:\s*(?:'([^']*)'|"([^"]*)"|([^\)]+?)))?\s*\)\)/g;function Dd(e){const t=[];if(!e)return t;const o=new RegExp(Wl.source,"g");let i;for(;(i=o.exec(e))!==null;){const n=i[2]??i[3]??i[4];t.push({fullMatch:i[0],blockId:i[1],anchorText:n?n.trim():void 0})}return t}function Od(e,t){if(!e)return"";const o=new RegExp(Wl.source,"g");return e.replace(o,(i,n,s,l,r)=>{const a=(s??l??r??"").trim();if(t&&t[n]){const u=t[n].trim();return`<div class="slides-block-ref" data-ref-id="${n}">${u}</div>`}const c=a||`Ref(${n.slice(0,8)})`;return`<a href="siyuan://blocks/${n}" data-ref-id="${n}" class="slides-ref-tag">🔗 ${c}</a>`})}const Vi="custom-slides-theme",Ki="custom-slides-aspect-ratio",Gi="custom-slides-default-transition",ql="custom-slides-color-schema",Es="custom-slides-spacing",An="custom-slides-background",Nr="custom-slides-show-unordered-list-markers",Pr="custom-slides-show-ordered-list-markers",po="custom-slides-slide",be="custom-slides-layout",_t="custom-slides-transition",ct="custom-slides-background",Wt="custom-slides-image",as="custom-slides-notes",ai="custom-slides-class",Ni="custom-slides-spacing",yt="custom-slides-layout-ratio",ci="custom-slides-mask",Jo="custom-slides-mask-ratio",di="custom-slides-mask-style",ui="custom-slides-mask-initial",Oe="custom-slides-click",Mt="custom-slides-motion",ei="custom-slides-shiki-lines",Te="custom-slides-slot",Fe="custom-slides-note",Ye="custom-slides-role",Yi="custom-slides-max-height",Yo="custom-slides-autoplay",Mn="custom-slides-loop",li="custom-slides-muted",En="custom-slides-controls",Vl="background",Bn="image-left",Ln="image-right";function fi(e){return e==="cols-header"||e==="two-cols-header"||e==="three-cols-header"}function Nd(e,t=2){const o=t===4?[25,50,75,100]:[50,100],i=t===4?4:2;if(!e||typeof e!="string")return{steps:i,breakpoints:o};const n=e.trim();if(!n||t===4&&(n==="1:1"||n==="1"))return{steps:i,breakpoints:o};const s=n.split(":").map(p=>parseFloat(p.trim())).filter(p=>!isNaN(p)&&p>0);if(s.length===0)return{steps:i,breakpoints:o};if(s.length===1){const p=Math.min(100,Math.max(1,s[0]));return p===100?{steps:1,breakpoints:[100]}:{steps:2,breakpoints:[Math.round(p*100)/100,100]}}const l=s.every((p,d)=>d===0||p>s[d-1]),r=s[s.length-1];if(l&&(r===100||s.some(p=>p>10))){const p=s.map(d=>Math.min(100,Math.round(d*100)/100));return p[p.length-1]<100&&p.push(100),{steps:p.length,breakpoints:p}}const c=s.reduce((p,d)=>p+d,0);if(c<=0)return{steps:i,breakpoints:o};let u=0;const f=[];for(let p=0;p<s.length;p++)u+=s[p],p===s.length-1?f.push(100):f.push(Math.round(u/c*1e4)/100);return{steps:f.length,breakpoints:f}}function Kl(e){if(!e)return!1;const t=e.trim();return t.startsWith("assets/")||t.startsWith("./assets/")||t.startsWith("/assets/")}function Gl(e){const t=e.trim();return t.startsWith("./assets/")?t.slice(2):t.startsWith("/assets/")?t.slice(1):t}function Dt(e,t){if(!Kl(e))return e;const o=Gl(e);return t!=null&&t.base64Map&&t.base64Map[o]?t.base64Map[o]:t!=null&&t.baseUrl?`${t.baseUrl.replace(/\/+$/,"")}/${o}`:`/${o}`}function Pd(e,t){if(!e)return"";let o=e;return o=o.replace(/!\[(.*?)\]\(((?:\.\/|\/)?assets\/[^\s)]+)\)/g,(i,n,s)=>{const l=Dt(s,t);return`![${n}](${l})`}),o=o.replace(/(<(?:img|video|audio|source)\b[^>]*?\bsrc=["'])((?:\.\/|\/)?assets\/[^"']+)(["'][^>]*>)/gi,(i,n,s,l)=>{const r=Dt(s,t);return`${n}${r}${l}`}),o=o.replace(/(url\(\s*["']?)((?:\.\/|\/)?assets\/[^"')]+)(["']?\s*\))/gi,(i,n,s,l)=>{const r=Dt(s,t);return`${n}${r}${l}`}),o}/**
* @vue/shared v3.5.40
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/function tr(e){const t=Object.create(null);for(const o of e.split(","))t[o]=1;return o=>o in t}const Ze={},hi=[],no=()=>{},Yl=()=>!1,Wn=e=>e.charCodeAt(0)===111&&e.charCodeAt(1)===110&&(e.charCodeAt(2)>122||e.charCodeAt(2)<97),qn=e=>e.startsWith("onUpdate:"),vt=Object.assign,or=(e,t)=>{const o=e.indexOf(t);o>-1&&e.splice(o,1)},Rd=Object.prototype.hasOwnProperty,Ue=(e,t)=>Rd.call(e,t),Me=Array.isArray,pi=e=>on(e)==="[object Map]",_i=e=>on(e)==="[object Set]",Rr=e=>on(e)==="[object Date]",Le=e=>typeof e=="function",nt=e=>typeof e=="string",Gt=e=>typeof e=="symbol",Ve=e=>e!==null&&typeof e=="object",Zl=e=>(Ve(e)||Le(e))&&Le(e.then)&&Le(e.catch),Jl=Object.prototype.toString,on=e=>Jl.call(e),zd=e=>on(e).slice(8,-1),Xl=e=>on(e)==="[object Object]",ir=e=>nt(e)&&e!=="NaN"&&e[0]!=="-"&&""+parseInt(e,10)===e,Pi=tr(",key,ref,ref_for,ref_key,onVnodeBeforeMount,onVnodeMounted,onVnodeBeforeUpdate,onVnodeUpdated,onVnodeBeforeUnmount,onVnodeUnmounted"),Vn=e=>{const t=Object.create(null);return(o=>t[o]||(t[o]=e(o)))},Hd=/-\w/g,Et=Vn(e=>e.replace(Hd,t=>t.slice(1).toUpperCase())),Fd=/\B([A-Z])/g,Wo=Vn(e=>e.replace(Fd,"-$1").toLowerCase()),Kn=Vn(e=>e.charAt(0).toUpperCase()+e.slice(1)),cs=Vn(e=>e?`on${Kn(e)}`:""),to=(e,t)=>!Object.is(e,t),vn=(e,...t)=>{for(let o=0;o<e.length;o++)e[o](...t)},Ql=(e,t,o,i=!1)=>{Object.defineProperty(e,t,{configurable:!0,enumerable:!1,writable:i,value:o})},Gn=e=>{const t=parseFloat(e);return isNaN(t)?e:t};let zr;const Yn=()=>zr||(zr=typeof globalThis<"u"?globalThis:typeof self<"u"?self:typeof window<"u"?window:typeof global<"u"?global:{});function oo(e){if(Me(e)){const t={};for(let o=0;o<e.length;o++){const i=e[o],n=nt(i)?qd(i):oo(i);if(n)for(const s in n)t[s]=n[s]}return t}else if(nt(e)||Ve(e))return e}const jd=/;(?![^(]*\))/g,Ud=/:([^]+)/,Wd=/\/\*[^]*?\*\//g;function qd(e){const t={};return e.replace(Wd,"").split(jd).forEach(o=>{if(o){const i=o.split(Ud);i.length>1&&(t[i[0].trim()]=i[1].trim())}}),t}function xe(e){let t="";if(nt(e))t=e;else if(Me(e))for(let o=0;o<e.length;o++){const i=xe(e[o]);i&&(t+=i+" ")}else if(Ve(e))for(const o in e)e[o]&&(t+=o+" ");return t.trim()}const Vd="itemscope,allowfullscreen,formnovalidate,ismap,nomodule,novalidate,readonly",Kd=tr(Vd);function ea(e){return!!e||e===""}function Gd(e,t){if(e.length!==t.length)return!1;let o=!0;for(let i=0;o&&i<e.length;i++)o=Ci(e[i],t[i]);return o}function Ci(e,t){if(e===t)return!0;let o=Rr(e),i=Rr(t);if(o||i)return o&&i?e.getTime()===t.getTime():!1;if(o=Gt(e),i=Gt(t),o||i)return e===t;if(o=Me(e),i=Me(t),o||i)return o&&i?Gd(e,t):!1;if(o=Ve(e),i=Ve(t),o||i){if(!o||!i)return!1;const n=Object.keys(e).length,s=Object.keys(t).length;if(n!==s)return!1;for(const l in e){const r=e.hasOwnProperty(l),a=t.hasOwnProperty(l);if(r&&!a||!r&&a||!Ci(e[l],t[l]))return!1}}return String(e)===String(t)}function nr(e,t){return e.findIndex(o=>Ci(o,t))}const ta=e=>!!(e&&e.__v_isRef===!0),ve=e=>nt(e)?e:e==null?"":Me(e)||Ve(e)&&(e.toString===Jl||!Le(e.toString))?ta(e)?ve(e.value):JSON.stringify(e,oa,2):String(e),oa=(e,t)=>ta(t)?oa(e,t.value):pi(t)?{[`Map(${t.size})`]:[...t.entries()].reduce((o,[i,n],s)=>(o[ds(i,s)+" =>"]=n,o),{})}:_i(t)?{[`Set(${t.size})`]:[...t.values()].map(o=>ds(o))}:Gt(t)?ds(t):Ve(t)&&!Me(t)&&!Xl(t)?String(t):t,ds=(e,t="")=>{var o;return Gt(e)?`Symbol(${(o=e.description)!=null?o:t})`:e};/**
* @vue/reactivity v3.5.40
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/let gt;class Yd{constructor(t=!1){this.detached=t,this._active=!0,this._on=0,this.effects=[],this.cleanups=[],this._isPaused=!1,this._warnOnRun=!0,this.__v_skip=!0,!t&&gt&&(gt.active?(this.parent=gt,this.index=(gt.scopes||(gt.scopes=[])).push(this)-1):(this._active=!1,this._warnOnRun=!1))}get active(){return this._active}pause(){if(this._active){this._isPaused=!0;let t,o;if(this.scopes){const i=this.scopes.slice();for(t=0,o=i.length;t<o;t++)i[t].pause()}for(t=0,o=this.effects.length;t<o;t++)this.effects[t].pause()}}resume(){if(this._active&&this._isPaused){this._isPaused=!1;let t,o;if(this.scopes){const n=this.scopes.slice();for(t=0,o=n.length;t<o;t++)n[t].resume()}const i=this.effects.slice();for(t=0,o=i.length;t<o;t++)i[t].resume()}}run(t){if(this._active){const o=gt;try{return gt=this,t()}finally{gt=o}}}on(){++this._on===1&&(this.prevScope=gt,gt=this)}off(){if(this._on>0&&--this._on===0){if(gt===this)gt=this.prevScope;else{let t=gt;for(;t;){if(t.prevScope===this){t.prevScope=this.prevScope;break}t=t.prevScope}}this.prevScope=void 0}}stop(t){if(this._active){this._active=!1;let o,i;for(o=0,i=this.effects.length;o<i;o++)this.effects[o].stop();for(this.effects.length=0,o=0,i=this.cleanups.length;o<i;o++)this.cleanups[o]();if(this.cleanups.length=0,this.scopes){const n=this.scopes.slice();for(o=0,i=n.length;o<i;o++)n[o].stop(!0);this.scopes.length=0}if(!this.detached&&this.parent&&!t){const n=this.parent.scopes.pop();n&&n!==this&&(this.parent.scopes[this.index]=n,n.index=this.index)}this.parent=void 0}}}function Zd(){return gt}let Xe;const us=new WeakSet;class ia{constructor(t){this.fn=t,this.deps=void 0,this.depsTail=void 0,this.flags=5,this.next=void 0,this.cleanup=void 0,this.scheduler=void 0,gt&&(gt.active?gt.effects.push(this):this.flags&=-2)}pause(){this.flags|=64}resume(){this.flags&64&&(this.flags&=-65,us.has(this)&&(us.delete(this),this.trigger()))}notify(){this.flags&2&&!(this.flags&32)||this.flags&8||sa(this)}run(){if(!(this.flags&1))return this.fn();this.flags|=2,Hr(this),ra(this);const t=Xe,o=Vt;Xe=this,Vt=!0;try{return this.fn()}finally{la(this),Xe=t,Vt=o,this.flags&=-3}}stop(){if(this.flags&1){for(let t=this.deps;t;t=t.nextDep)lr(t);this.deps=this.depsTail=void 0,Hr(this),this.onStop&&this.onStop(),this.flags&=-2}}trigger(){this.flags&64?us.add(this):this.scheduler?this.scheduler():this.runIfDirty()}runIfDirty(){Bs(this)&&this.run()}get dirty(){return Bs(this)}}let na=0,Ri,zi;function sa(e,t=!1){if(e.flags|=8,t){e.next=zi,zi=e;return}e.next=Ri,Ri=e}function sr(){na++}function rr(){if(--na>0)return;if(zi){let t=zi;for(zi=void 0;t;){const o=t.next;t.next=void 0,t.flags&=-9,t=o}}let e;for(;Ri;){let t=Ri;for(Ri=void 0;t;){const o=t.next;if(t.next=void 0,t.flags&=-9,t.flags&1)try{t.trigger()}catch(i){e||(e=i)}t=o}}if(e)throw e}function ra(e){for(let t=e.deps;t;t=t.nextDep)t.version=-1,t.prevActiveLink=t.dep.activeLink,t.dep.activeLink=t}function la(e){let t,o=e.depsTail,i=o;for(;i;){const n=i.prevDep;i.version===-1?(i===o&&(o=n),lr(i),Jd(i)):t=i,i.dep.activeLink=i.prevActiveLink,i.prevActiveLink=void 0,i=n}e.deps=t,e.depsTail=o}function Bs(e){for(let t=e.deps;t;t=t.nextDep)if(t.dep.version!==t.version||t.dep.computed&&(aa(t.dep.computed)||t.dep.version!==t.version))return!0;return!!e._dirty}function aa(e){if(e.flags&4&&!(e.flags&16)||(e.flags&=-17,e.globalVersion===Zi)||(e.globalVersion=Zi,!e.isSSR&&e.flags&128&&(!e.deps&&!e._dirty||!Bs(e))))return;e.flags|=2;const t=e.dep,o=Xe,i=Vt;Xe=e,Vt=!0;try{ra(e);const n=e.fn(e._value);(t.version===0||to(n,e._value))&&(e.flags|=128,e._value=n,t.version++)}catch(n){throw t.version++,n}finally{Xe=o,Vt=i,la(e),e.flags&=-3}}function lr(e,t=!1){const{dep:o,prevSub:i,nextSub:n}=e;if(i&&(i.nextSub=n,e.prevSub=void 0),n&&(n.prevSub=i,e.nextSub=void 0),o.subs===e&&(o.subs=i,!i&&o.computed)){o.computed.flags&=-5;for(let s=o.computed.deps;s;s=s.nextDep)lr(s,!0)}!t&&!--o.sc&&o.map&&o.map.delete(o.key)}function Jd(e){const{prevDep:t,nextDep:o}=e;t&&(t.nextDep=o,e.prevDep=void 0),o&&(o.prevDep=t,e.nextDep=void 0)}let Vt=!0;const ca=[];function xo(){ca.push(Vt),Vt=!1}function So(){const e=ca.pop();Vt=e===void 0?!0:e}function Hr(e){const{cleanup:t}=e;if(e.cleanup=void 0,t){const o=Xe;Xe=void 0;try{t()}finally{Xe=o}}}let Zi=0;class Xd{constructor(t,o){this.sub=t,this.dep=o,this.version=o.version,this.nextDep=this.prevDep=this.nextSub=this.prevSub=this.prevActiveLink=void 0}}class ar{constructor(t){this.computed=t,this.version=0,this.activeLink=void 0,this.subs=void 0,this.map=void 0,this.key=void 0,this.sc=0,this.__v_skip=!0}track(t){if(!Xe||!Vt||Xe===this.computed)return;let o=this.activeLink;if(o===void 0||o.sub!==Xe)o=this.activeLink=new Xd(Xe,this),Xe.deps?(o.prevDep=Xe.depsTail,Xe.depsTail.nextDep=o,Xe.depsTail=o):Xe.deps=Xe.depsTail=o,da(o);else if(o.version===-1&&(o.version=this.version,o.nextDep)){const i=o.nextDep;i.prevDep=o.prevDep,o.prevDep&&(o.prevDep.nextDep=i),o.prevDep=Xe.depsTail,o.nextDep=void 0,Xe.depsTail.nextDep=o,Xe.depsTail=o,Xe.deps===o&&(Xe.deps=i)}return o}trigger(t){this.version++,Zi++,this.notify(t)}notify(t){sr();try{for(let o=this.subs;o;o=o.prevSub)o.sub.notify()&&o.sub.dep.notify()}finally{rr()}}}function da(e){if(e.dep.sc++,e.sub.flags&4){const t=e.dep.computed;if(t&&!e.dep.subs){t.flags|=20;for(let i=t.deps;i;i=i.nextDep)da(i)}const o=e.dep.subs;o!==e&&(e.prevSub=o,o&&(o.nextSub=e)),e.dep.subs=e}}const Ls=new WeakMap,Xo=Symbol(""),Ds=Symbol(""),Ji=Symbol("");function xt(e,t,o){if(Vt&&Xe){let i=Ls.get(e);i||Ls.set(e,i=new Map);let n=i.get(o);n||(i.set(o,n=new ar),n.map=i,n.key=o),n.track()}}function mo(e,t,o,i,n,s){const l=Ls.get(e);if(!l){Zi++;return}const r=a=>{a&&a.trigger()};if(sr(),t==="clear")l.forEach(r);else{const a=Me(e),c=a&&ir(o);if(a&&o==="length"){const u=Number(i);l.forEach((f,p)=>{(p==="length"||p===Ji||!Gt(p)&&p>=u)&&r(f)})}else switch((o!==void 0||l.has(void 0))&&r(l.get(o)),c&&r(l.get(Ji)),t){case"add":a?c&&r(l.get("length")):(r(l.get(Xo)),pi(e)&&r(l.get(Ds)));break;case"delete":a||(r(l.get(Xo)),pi(e)&&r(l.get(Ds)));break;case"set":pi(e)&&r(l.get(Xo));break}}rr()}function ii(e){const t=je(e);return t===e?t:(xt(t,"iterate",Ji),jt(e)?t:t.map(Yt))}function Zn(e){return xt(e=je(e),"iterate",Ji),e}function Qt(e,t){return _o(e)?ki(Qo(e)?Yt(t):t):Yt(t)}const Qd={__proto__:null,[Symbol.iterator](){return fs(this,Symbol.iterator,e=>Qt(this,e))},concat(...e){return ii(this).concat(...e.map(t=>Me(t)?ii(t):t))},entries(){return fs(this,"entries",e=>(e[1]=Qt(this,e[1]),e))},every(e,t){return co(this,"every",e,t,void 0,arguments)},filter(e,t){return co(this,"filter",e,t,o=>o.map(i=>Qt(this,i)),arguments)},find(e,t){return co(this,"find",e,t,o=>Qt(this,o),arguments)},findIndex(e,t){return co(this,"findIndex",e,t,void 0,arguments)},findLast(e,t){return co(this,"findLast",e,t,o=>Qt(this,o),arguments)},findLastIndex(e,t){return co(this,"findLastIndex",e,t,void 0,arguments)},forEach(e,t){return co(this,"forEach",e,t,void 0,arguments)},includes(...e){return hs(this,"includes",e)},indexOf(...e){return hs(this,"indexOf",e)},join(e){return ii(this).join(e)},lastIndexOf(...e){return hs(this,"lastIndexOf",e)},map(e,t){return co(this,"map",e,t,void 0,arguments)},pop(){return Mi(this,"pop")},push(...e){return Mi(this,"push",e)},reduce(e,...t){return Fr(this,"reduce",e,t)},reduceRight(e,...t){return Fr(this,"reduceRight",e,t)},shift(){return Mi(this,"shift")},some(e,t){return co(this,"some",e,t,void 0,arguments)},splice(...e){return Mi(this,"splice",e)},toReversed(){return ii(this).toReversed()},toSorted(e){return ii(this).toSorted(e)},toSpliced(...e){return ii(this).toSpliced(...e)},unshift(...e){return Mi(this,"unshift",e)},values(){return fs(this,"values",e=>Qt(this,e))}};function fs(e,t,o){const i=Zn(e),n=i[t]();return i!==e&&!jt(e)&&(n._next=n.next,n.next=()=>{const s=n._next();return s.done||(s.value=o(s.value)),s}),n}const eu=Array.prototype;function co(e,t,o,i,n,s){const l=Zn(e),r=l!==e&&!jt(e),a=l[t];if(a!==eu[t]){const f=a.apply(e,s);return r?Yt(f):f}let c=o;l!==e&&(r?c=function(f,p){return o.call(this,Qt(e,f),p,e)}:o.length>2&&(c=function(f,p){return o.call(this,f,p,e)}));const u=a.call(l,c,i);return r&&n?n(u):u}function Fr(e,t,o,i){const n=Zn(e),s=n!==e&&!jt(e);let l=o,r=!1;n!==e&&(s?(r=i.length===0,l=function(c,u,f){return r&&(r=!1,c=Qt(e,c)),o.call(this,c,Qt(e,u),f,e)}):o.length>3&&(l=function(c,u,f){return o.call(this,c,u,f,e)}));const a=n[t](l,...i);return r?Qt(e,a):a}function hs(e,t,o){const i=je(e);xt(i,"iterate",Ji);const n=i[t](...o);return(n===-1||n===!1)&&ur(o[0])?(o[0]=je(o[0]),i[t](...o)):n}function Mi(e,t,o=[]){xo(),sr();const i=je(e)[t].apply(e,o);return rr(),So(),i}const tu=tr("__proto__,__v_isRef,__isVue"),ua=new Set(Object.getOwnPropertyNames(Symbol).filter(e=>e!=="arguments"&&e!=="caller").map(e=>Symbol[e]).filter(Gt));function ou(e){Gt(e)||(e=String(e));const t=je(this);return xt(t,"has",e),t.hasOwnProperty(e)}class fa{constructor(t=!1,o=!1){this._isReadonly=t,this._isShallow=o}get(t,o,i){if(o==="__v_skip")return t.__v_skip;const n=this._isReadonly,s=this._isShallow;if(o==="__v_isReactive")return!n;if(o==="__v_isReadonly")return n;if(o==="__v_isShallow")return s;if(o==="__v_raw")return i===(n?s?fu:ga:s?ma:pa).get(t)||Object.getPrototypeOf(t)===Object.getPrototypeOf(i)?t:void 0;const l=Me(t);if(!n){let a;if(l&&(a=Qd[o]))return a;if(o==="hasOwnProperty")return ou}const r=Reflect.get(t,o,ot(t)?t:i);if((Gt(o)?ua.has(o):tu(o))||(n||xt(t,"get",o),s))return r;if(ot(r)){const a=l&&ir(o)?r:r.value;return n&&Ve(a)?Ns(a):a}return Ve(r)?n?Ns(r):Jn(r):r}}class ha extends fa{constructor(t=!1){super(!1,t)}set(t,o,i,n){let s=t[o];const l=Me(t)&&ir(o);if(!this._isShallow){const c=_o(s);if(!jt(i)&&!_o(i)&&(s=je(s),i=je(i)),!l&&ot(s)&&!ot(i))return c||(s.value=i),!0}const r=l?Number(o)<t.length:Ue(t,o),a=Reflect.set(t,o,i,ot(t)?t:n);return t===je(n)&&a&&(r?to(i,s)&&mo(t,"set",o,i):mo(t,"add",o,i)),a}deleteProperty(t,o){const i=Ue(t,o);t[o];const n=Reflect.deleteProperty(t,o);return n&&i&&mo(t,"delete",o,void 0),n}has(t,o){const i=Reflect.has(t,o);return(!Gt(o)||!ua.has(o))&&xt(t,"has",o),i}ownKeys(t){return xt(t,"iterate",Me(t)?"length":Xo),Reflect.ownKeys(t)}}class iu extends fa{constructor(t=!1){super(!0,t)}set(t,o){return!0}deleteProperty(t,o){return!0}}const nu=new ha,su=new iu,ru=new ha(!0);const Os=e=>e,dn=e=>Reflect.getPrototypeOf(e);function lu(e,t,o){return function(...i){const n=this.__v_raw,s=je(n),l=pi(s),r=e==="entries"||e===Symbol.iterator&&l,a=e==="keys"&&l,c=n[e](...i),u=o?Os:t?ki:Yt;return!t&&xt(s,"iterate",a?Ds:Xo),vt(Object.create(c),{next(){const{value:f,done:p}=c.next();return p?{value:f,done:p}:{value:r?[u(f[0]),u(f[1])]:u(f),done:p}}})}}function un(e){return function(...t){return e==="delete"?!1:e==="clear"?void 0:this}}function au(e,t){const o={get(n){const s=this.__v_raw,l=je(s),r=je(n);e||(to(n,r)&&xt(l,"get",n),xt(l,"get",r));const{has:a}=dn(l),c=t?Os:e?ki:Yt;if(a.call(l,n))return c(s.get(n));if(a.call(l,r))return c(s.get(r));s!==l&&s.get(n)},get size(){const n=this.__v_raw;return!e&&xt(je(n),"iterate",Xo),n.size},has(n){const s=this.__v_raw,l=je(s),r=je(n);return e||(to(n,r)&&xt(l,"has",n),xt(l,"has",r)),n===r?s.has(n):s.has(n)||s.has(r)},forEach(n,s){const l=this,r=l.__v_raw,a=je(r),c=t?Os:e?ki:Yt;return!e&&xt(a,"iterate",Xo),r.forEach((u,f)=>n.call(s,c(u),c(f),l))}};return vt(o,e?{add:un("add"),set:un("set"),delete:un("delete"),clear:un("clear")}:{add(n){const s=je(this),l=dn(s),r=je(n),a=!t&&!jt(n)&&!_o(n)?r:n;return l.has.call(s,a)||to(n,a)&&l.has.call(s,n)||to(r,a)&&l.has.call(s,r)||(s.add(a),mo(s,"add",a,a)),this},set(n,s){!t&&!jt(s)&&!_o(s)&&(s=je(s));const l=je(this),{has:r,get:a}=dn(l);let c=r.call(l,n);c||(n=je(n),c=r.call(l,n));const u=a.call(l,n);return l.set(n,s),c?to(s,u)&&mo(l,"set",n,s):mo(l,"add",n,s),this},delete(n){const s=je(this),{has:l,get:r}=dn(s);let a=l.call(s,n);a||(n=je(n),a=l.call(s,n)),r&&r.call(s,n);const c=s.delete(n);return a&&mo(s,"delete",n,void 0),c},clear(){const n=je(this),s=n.size!==0,l=n.clear();return s&&mo(n,"clear",void 0,void 0),l}}),["keys","values","entries",Symbol.iterator].forEach(n=>{o[n]=lu(n,e,t)}),o}function cr(e,t){const o=au(e,t);return(i,n,s)=>n==="__v_isReactive"?!e:n==="__v_isReadonly"?e:n==="__v_raw"?i:Reflect.get(Ue(o,n)&&n in i?o:i,n,s)}const cu={get:cr(!1,!1)},du={get:cr(!1,!0)},uu={get:cr(!0,!1)};const pa=new WeakMap,ma=new WeakMap,ga=new WeakMap,fu=new WeakMap;function hu(e){switch(e){case"Object":case"Array":return 1;case"Map":case"Set":case"WeakMap":case"WeakSet":return 2;default:return 0}}function Jn(e){return _o(e)?e:dr(e,!1,nu,cu,pa)}function pu(e){return dr(e,!1,ru,du,ma)}function Ns(e){return dr(e,!0,su,uu,ga)}function dr(e,t,o,i,n){if(!Ve(e)||e.__v_raw&&!(t&&e.__v_isReactive)||e.__v_skip||!Object.isExtensible(e))return e;const s=n.get(e);if(s)return s;const l=hu(zd(e));if(l===0)return e;const r=new Proxy(e,l===2?i:o);return n.set(e,r),r}function Qo(e){return _o(e)?Qo(e.__v_raw):!!(e&&e.__v_isReactive)}function _o(e){return!!(e&&e.__v_isReadonly)}function jt(e){return!!(e&&e.__v_isShallow)}function ur(e){return e?!!e.__v_raw:!1}function je(e){const t=e&&e.__v_raw;return t?je(t):e}function mu(e){return!Ue(e,"__v_skip")&&Object.isExtensible(e)&&Ql(e,"__v_skip",!0),e}const Yt=e=>Ve(e)?Jn(e):e,ki=e=>Ve(e)?Ns(e):e;function ot(e){return e?e.__v_isRef===!0:!1}function pe(e){return gu(e,!1)}function gu(e,t){return ot(e)?e:new yu(e,t)}class yu{constructor(t,o){this.dep=new ar,this.__v_isRef=!0,this.__v_isShallow=!1,this._rawValue=o?t:je(t),this._value=o?t:Yt(t),this.__v_isShallow=o}get value(){return this.dep.track(),this._value}set value(t){const o=this._rawValue,i=this.__v_isShallow||jt(t)||_o(t);t=i?t:je(t),to(t,o)&&(this._rawValue=t,this._value=i?t:Yt(t),this.dep.trigger())}}function ue(e){return ot(e)?e.value:e}const bu={get:(e,t,o)=>t==="__v_raw"?e:ue(Reflect.get(e,t,o)),set:(e,t,o,i)=>{const n=e[t];return ot(n)&&!ot(o)?(n.value=o,!0):Reflect.set(e,t,o,i)}};function ya(e){return Qo(e)?e:new Proxy(e,bu)}class vu{constructor(t,o,i){this.fn=t,this.setter=o,this._value=void 0,this.dep=new ar(this),this.__v_isRef=!0,this.deps=void 0,this.depsTail=void 0,this.flags=16,this.globalVersion=Zi-1,this.next=void 0,this.effect=this,this.__v_isReadonly=!o,this.isSSR=i}notify(){if(this.flags|=16,!(this.flags&8)&&Xe!==this)return sa(this,!0),!0}get value(){const t=this.dep.track();return aa(this),t&&(t.version=this.dep.version),this._value}set value(t){this.setter&&this.setter(t)}}function ku(e,t,o=!1){let i,n;return Le(e)?i=e:(i=e.get,n=e.set),new vu(i,n,o)}const fn={},Dn=new WeakMap;let Go;function wu(e,t=!1,o=Go){if(o){let i=Dn.get(o);i||Dn.set(o,i=[]),i.push(e)}}function xu(e,t,o=Ze){const{immediate:i,deep:n,once:s,scheduler:l,augmentJob:r,call:a}=o,c=$=>n?$:jt($)||n===!1||n===0?go($,1):go($);let u,f,p,d,b=!1,m=!1;if(ot(e)?(f=()=>e.value,b=jt(e)):Qo(e)?(f=()=>c(e),b=!0):Me(e)?(m=!0,b=e.some($=>Qo($)||jt($)),f=()=>e.map($=>{if(ot($))return $.value;if(Qo($))return c($);if(Le($))return a?a($,2):$()})):Le(e)?t?f=a?()=>a(e,2):e:f=()=>{if(p){xo();try{p()}finally{So()}}const $=Go;Go=u;try{return a?a(e,3,[d]):e(d)}finally{Go=$}}:f=no,t&&n){const $=f,A=n===!0?1/0:n;f=()=>go($(),A)}const g=Zd(),y=()=>{u.stop(),g&&g.active&&or(g.effects,u)};if(s&&t){const $=t;t=(...A)=>{const w=$(...A);return y(),w}}let k=m?new Array(e.length).fill(fn):fn;const x=$=>{if(!(!(u.flags&1)||!u.dirty&&!$))if(t){const A=u.run();if($||n||b||(m?A.some((w,_)=>to(w,k[_])):to(A,k))){p&&p();const w=Go;Go=u;try{const _=[A,k===fn?void 0:m&&k[0]===fn?[]:k,d];k=A,a?a(t,3,_):t(..._)}finally{Go=w}}}else u.run()};return r&&r(x),u=new ia(f),u.scheduler=l?()=>l(x,!1):x,d=$=>wu($,!1,u),p=u.onStop=()=>{const $=Dn.get(u);if($){if(a)a($,4);else for(const A of $)A();Dn.delete(u)}},t?i?x(!0):k=u.run():l?l(x.bind(null,!0),!0):u.run(),y.pause=u.pause.bind(u),y.resume=u.resume.bind(u),y.stop=y,y}function go(e,t=1/0,o){if(t<=0||!Ve(e)||e.__v_skip||(o=o||new Map,(o.get(e)||0)>=t))return e;if(o.set(e,t),t--,ot(e))go(e.value,t,o);else if(Me(e))for(let i=0;i<e.length;i++)go(e[i],t,o);else if(_i(e)||pi(e))e.forEach(i=>{go(i,t,o)});else if(Xl(e)){for(const i in e)go(e[i],t,o);for(const i of Object.getOwnPropertySymbols(e))Object.prototype.propertyIsEnumerable.call(e,i)&&go(e[i],t,o)}return e}/**
* @vue/runtime-core v3.5.40
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/function nn(e,t,o,i){try{return i?e(...i):e()}catch(n){Xn(n,t,o)}}function Zt(e,t,o,i){if(Le(e)){const n=nn(e,t,o,i);return n&&Zl(n)&&n.catch(s=>{Xn(s,t,o)}),n}if(Me(e)){const n=[];for(let s=0;s<e.length;s++)n.push(Zt(e[s],t,o,i));return n}}function Xn(e,t,o,i=!0){const n=t?t.vnode:null,{errorHandler:s,throwUnhandledErrorInProduction:l}=t&&t.appContext.config||Ze;if(t){let r=t.parent;const a=t.proxy,c=`https://vuejs.org/error-reference/#runtime-${o}`;for(;r;){const u=r.ec;if(u){for(let f=0;f<u.length;f++)if(u[f](e,a,c)===!1)return}r=r.parent}if(s){xo(),nn(s,null,10,[e,a,c]),So();return}}Su(e,o,n,i,l)}function Su(e,t,o,i=!0,n=!1){if(n)throw e;console.error(e)}const Tt=[];let Xt=-1;const mi=[];let Bo=null,si=0;const ba=Promise.resolve();let On=null;function Nn(e){const t=On||ba;return e?t.then(this?e.bind(this):e):t}function _u(e){let t=Xt+1,o=Tt.length;for(;t<o;){const i=t+o>>>1,n=Tt[i],s=Xi(n);s<e||s===e&&n.flags&2?t=i+1:o=i}return t}function fr(e){if(!(e.flags&1)){const t=Xi(e),o=Tt[Tt.length-1];!o||!(e.flags&2)&&t>=Xi(o)?Tt.push(e):Tt.splice(_u(t),0,e),e.flags|=1,va()}}function va(){On||(On=ba.then(wa))}function Cu(e){Me(e)?mi.push(...e):Bo&&e.id===-1?Bo.splice(si+1,0,e):e.flags&1||(mi.push(e),e.flags|=1),va()}function jr(e,t,o=Xt+1){for(;o<Tt.length;o++){const i=Tt[o];if(i&&i.flags&2){if(e&&i.id!==e.uid)continue;Tt.splice(o,1),o--,i.flags&4&&(i.flags&=-2),i(),i.flags&4||(i.flags&=-2)}}}function ka(e){if(mi.length){const t=[...new Set(mi)].sort((o,i)=>Xi(o)-Xi(i));if(mi.length=0,Bo){Bo.push(...t);return}for(Bo=t,si=0;si<Bo.length;si++){const o=Bo[si];o.flags&4&&(o.flags&=-2),o.flags&8||o(),o.flags&=-2}Bo=null,si=0}}const Xi=e=>e.id==null?e.flags&2?-1:1/0:e.id;function wa(e){try{for(Xt=0;Xt<Tt.length;Xt++){const t=Tt[Xt];t&&!(t.flags&8)&&(t.flags&4&&(t.flags&=-2),nn(t,t.i,t.i?15:14),t.flags&4||(t.flags&=-2))}}finally{for(;Xt<Tt.length;Xt++){const t=Tt[Xt];t&&(t.flags&=-2)}Xt=-1,Tt.length=0,ka(),On=null,(Tt.length||mi.length)&&wa()}}let bt=null,xa=null;function Pn(e){const t=bt;return bt=e,xa=e&&e.type.__scopeId||null,t}function Sa(e,t=bt,o){if(!t||e._n)return e;const i=(...n)=>{i._d&&el(-1);const s=Pn(t),l=vo.length;let r;try{r=e(...n)}finally{for(let a=vo.length;a>l;a--)yr();Pn(s),i._d&&el(1)}return r};return i._n=!0,i._c=!0,i._d=!0,i}function Ut(e,t){if(bt===null)return e;const o=os(bt),i=e.dirs||(e.dirs=[]);for(let n=0;n<t.length;n++){let[s,l,r,a=Ze]=t[n];s&&(Le(s)&&(s={mounted:s,updated:s}),s.deep&&go(l),i.push({dir:s,instance:o,value:l,oldValue:void 0,arg:r,modifiers:a}))}return e}function qo(e,t,o,i){const n=e.dirs,s=t&&t.dirs;for(let l=0;l<n.length;l++){const r=n[l];s&&(r.oldValue=s[l].value);let a=r.dir[i];a&&(xo(),Zt(a,o,8,[e.el,r,e,t]),So())}}function Iu(e,t){if(Ct){let o=Ct.provides;const i=Ct.parent&&Ct.parent.provides;i===o&&(o=Ct.provides=Object.create(i)),o[e]=t}}function Kt(e,t,o=!1){const i=Cf();if(i||yi){let n=yi?yi._context.provides:i?i.parent==null||i.ce?i.vnode.appContext&&i.vnode.appContext.provides:i.parent.provides:void 0;if(n&&e in n)return n[e];if(arguments.length>1)return o&&Le(t)?t.call(i&&i.proxy):t}}const $u=Symbol.for("v-scx"),Tu=()=>Kt($u);function Ho(e,t,o){return _a(e,t,o)}function _a(e,t,o=Ze){const{immediate:i,deep:n,flush:s,once:l}=o,r=vt({},o),a=t&&i||!t&&s!=="post";let c;if(en){if(s==="sync"){const d=Tu();c=d.__watcherHandles||(d.__watcherHandles=[])}else if(!a){const d=()=>{};return d.stop=no,d.resume=no,d.pause=no,d}}const u=Ct;r.call=(d,b,m)=>Zt(d,u,b,m);let f=!1;s==="post"?r.scheduler=d=>{Lt(d,u&&u.suspense)}:s!=="sync"&&(f=!0,r.scheduler=(d,b)=>{b?d():fr(d)}),r.augmentJob=d=>{t&&(d.flags|=4),f&&(d.flags|=2,u&&(d.id=u.uid,d.i=u))};const p=xu(e,t,r);return en&&(c?c.push(p):a&&p()),p}function Au(e,t,o){const i=this.proxy,n=nt(e)?e.includes(".")?Ca(i,e):()=>i[e]:e.bind(i,i);let s;Le(t)?s=t:(s=t.handler,o=t);const l=rn(this),r=_a(n,s.bind(i),o);return l(),r}function Ca(e,t){const o=t.split(".");return()=>{let i=e;for(let n=0;n<o.length&&i;n++)i=i[o[n]];return i}}const Mu=Symbol("_vte"),Eu=e=>e.__isTeleport,ps=Symbol("_leaveCb");function hr(e,t){e.shapeFlag&6&&e.component?(e.transition=t,hr(e.component.subTree,t)):e.shapeFlag&128?(e.ssContent.transition=t.clone(e.ssContent),e.ssFallback.transition=t.clone(e.ssFallback)):e.transition=t}function zt(e,t){return Le(e)?vt({name:e.name},t,{setup:e}):e}function Ia(e){e.ids=[e.ids[0]+e.ids[2]+++"-",0,0]}function Ur(e,t){let o;return!!((o=Object.getOwnPropertyDescriptor(e,t))&&!o.configurable)}const Rn=new WeakMap;function Hi(e,t,o,i,n=!1){if(Me(e)){e.forEach((m,g)=>Hi(m,t&&(Me(t)?t[g]:t),o,i,n));return}if(gi(i)&&!n){i.shapeFlag&512&&i.type.__asyncResolved&&i.component.subTree.component&&Hi(e,t,o,i.component.subTree);return}const s=i.shapeFlag&4?os(i.component):i.el,l=n?null:s,{i:r,r:a}=e,c=t&&t.r,u=r.refs===Ze?r.refs={}:r.refs,f=r.setupState,p=je(f),d=f===Ze?Yl:m=>Ur(u,m)?!1:Ue(p,m),b=(m,g)=>!(g&&Ur(u,g));if(c!=null&&c!==a){if(Wr(t),nt(c))u[c]=null,d(c)&&(f[c]=null);else if(ot(c)){const m=t;b(c,m.k)&&(c.value=null),m.k&&(u[m.k]=null)}}if(Le(a))nn(a,r,12,[l,u]);else{const m=nt(a),g=ot(a);if(m||g){const y=()=>{if(e.f){const k=m?d(a)?f[a]:u[a]:b()||!e.k?a.value:u[e.k];if(n)Me(k)&&or(k,s);else if(Me(k))k.includes(s)||k.push(s);else if(m)u[a]=[s],d(a)&&(f[a]=u[a]);else{const x=[s];b(a,e.k)&&(a.value=x),e.k&&(u[e.k]=x)}}else m?(u[a]=l,d(a)&&(f[a]=l)):g&&(b(a,e.k)&&(a.value=l),e.k&&(u[e.k]=l))};if(l){const k=()=>{y(),Rn.delete(e)};k.id=-1,Rn.set(e,k),Lt(k,o)}else Wr(e),y()}}}function Wr(e){const t=Rn.get(e);t&&(t.flags|=8,Rn.delete(e))}Yn().requestIdleCallback;Yn().cancelIdleCallback;const gi=e=>!!e.type.__asyncLoader,$a=e=>e.type.__isKeepAlive;function Bu(e,t){Ta(e,"a",t)}function Lu(e,t){Ta(e,"da",t)}function Ta(e,t,o=Ct){const i=e.__wdc||(e.__wdc=()=>{let n=o;for(;n;){if(n.isDeactivated)return;n=n.parent}return e()});if(Qn(t,i,o),o){let n=o.parent;for(;n&&n.parent;)$a(n.parent.vnode)&&Du(i,t,o,n),n=n.parent}}function Du(e,t,o,i){const n=Qn(t,e,i,!0);sn(()=>{or(i[t],n)},o)}function Qn(e,t,o=Ct,i=!1){if(o){const n=o[e]||(o[e]=[]),s=t.__weh||(t.__weh=(...l)=>{xo();const r=rn(o),a=Zt(t,o,e,l);return r(),So(),a});return i?n.unshift(s):n.push(s),s}}const Io=e=>(t,o=Ct)=>{(!en||e==="sp")&&Qn(e,(...i)=>t(...i),o)},Ou=Io("bm"),ti=Io("m"),Nu=Io("bu"),Pu=Io("u"),pr=Io("bum"),sn=Io("um"),Ru=Io("sp"),zu=Io("rtg"),Hu=Io("rtc");function Fu(e,t=Ct){Qn("ec",e,t)}const ju="components";function Uu(e,t){return qu(ju,e,!0,t)||e}const Wu=Symbol.for("v-ndc");function qu(e,t,o=!0,i=!1){const n=bt||Ct;if(n){const s=n.type;{const r=Mf(s,!1);if(r&&(r===t||r===Et(t)||r===Kn(Et(t))))return s}const l=qr(n[e]||s[e],t)||qr(n.appContext[e],t);return!l&&i?s:l}}function qr(e,t){return e&&(e[t]||e[Et(t)]||e[Kn(Et(t))])}function At(e,t,o,i){let n;const s=o,l=Me(e);if(l||nt(e)){const r=l&&Qo(e);let a=!1,c=!1;r&&(a=!jt(e),c=_o(e),e=Zn(e)),n=new Array(e.length);for(let u=0,f=e.length;u<f;u++)n[u]=t(a?c?ki(Yt(e[u])):Yt(e[u]):e[u],u,void 0,s)}else if(typeof e=="number"){n=new Array(e);for(let r=0;r<e;r++)n[r]=t(r+1,r,void 0,s)}else if(Ve(e))if(e[Symbol.iterator])n=Array.from(e,(r,a)=>t(r,a,void 0,s));else{const r=Object.keys(e);n=new Array(r.length);for(let a=0,c=r.length;a<c;a++){const u=r[a];n[a]=t(e[u],u,a,s)}}else n=[];return n}function hn(e,t,o={},i,n,s){if(bt.ce||bt.parent&&gi(bt.parent)&&bt.parent.ce){const c=o,u=Object.keys(c).length>0;return t!=="default"&&(c.name=t),J(),qt(Je,null,[le("slot",c,i&&i())],u?-2:64)}let l=e[t];l&&l._c&&(l._d=!1);const r=vo.length;J();let a;try{const c=l&&Aa(l(o)),u=o.key||s||c&&c.key;a=qt(Je,{key:(u&&!Gt(u)?u:`_${t}`)+(!c&&i?"_fb":"")},c||(i?i():[]),c&&e._===1?64:-2)}catch(c){for(let u=vo.length;u>r;u--)yr();throw c}finally{l&&l._c&&(l._d=!0)}return a}function Aa(e){return e.some(t=>br(t)?!(t.type===Co||t.type===Je&&!Aa(t.children)):!0)?e:null}const Ps=e=>e?Ya(e)?os(e):Ps(e.parent):null,Fi=vt(Object.create(null),{$:e=>e,$el:e=>e.vnode.el,$data:e=>e.data,$props:e=>e.props,$attrs:e=>e.attrs,$slots:e=>e.slots,$refs:e=>e.refs,$parent:e=>Ps(e.parent),$root:e=>Ps(e.root),$host:e=>e.ce,$emit:e=>e.emit,$options:e=>Ea(e),$forceUpdate:e=>e.f||(e.f=()=>{fr(e.update)}),$nextTick:e=>e.n||(e.n=Nn.bind(e.proxy)),$watch:e=>Au.bind(e)}),ms=(e,t)=>e!==Ze&&!e.__isScriptSetup&&Ue(e,t),Vu={get({_:e},t){if(t==="__v_skip")return!0;const{ctx:o,setupState:i,data:n,props:s,accessCache:l,type:r,appContext:a}=e;if(t[0]!=="$"){const p=l[t];if(p!==void 0)switch(p){case 1:return i[t];case 2:return n[t];case 4:return o[t];case 3:return s[t]}else{if(ms(i,t))return l[t]=1,i[t];if(n!==Ze&&Ue(n,t))return l[t]=2,n[t];if(Ue(s,t))return l[t]=3,s[t];if(o!==Ze&&Ue(o,t))return l[t]=4,o[t];Rs&&(l[t]=0)}}const c=Fi[t];let u,f;if(c)return t==="$attrs"&&xt(e.attrs,"get",""),c(e);if((u=r.__cssModules)&&(u=u[t]))return u;if(o!==Ze&&Ue(o,t))return l[t]=4,o[t];if(f=a.config.globalProperties,Ue(f,t))return f[t]},set({_:e},t,o){const{data:i,setupState:n,ctx:s}=e;return ms(n,t)?(n[t]=o,!0):i!==Ze&&Ue(i,t)?(i[t]=o,!0):Ue(e.props,t)||t[0]==="$"&&t.slice(1)in e?!1:(s[t]=o,!0)},has({_:{data:e,setupState:t,accessCache:o,ctx:i,appContext:n,props:s,type:l}},r){let a;return!!(o[r]||e!==Ze&&r[0]!=="$"&&Ue(e,r)||ms(t,r)||Ue(s,r)||Ue(i,r)||Ue(Fi,r)||Ue(n.config.globalProperties,r)||(a=l.__cssModules)&&a[r])},defineProperty(e,t,o){return o.get!=null?e._.accessCache[t]=0:Ue(o,"value")&&this.set(e,t,o.value,null),Reflect.defineProperty(e,t,o)}};function Vr(e){return Me(e)?e.reduce((t,o)=>(t[o]=null,t),{}):e}let Rs=!0;function Ku(e){const t=Ea(e),o=e.proxy,i=e.ctx;Rs=!1,t.beforeCreate&&Kr(t.beforeCreate,e,"bc");const{data:n,computed:s,methods:l,watch:r,provide:a,inject:c,created:u,beforeMount:f,mounted:p,beforeUpdate:d,updated:b,activated:m,deactivated:g,beforeDestroy:y,beforeUnmount:k,destroyed:x,unmounted:$,render:A,renderTracked:w,renderTriggered:_,errorCaptured:O,serverPrefetch:H,expose:P,inheritAttrs:F,components:E,directives:D,filters:S}=t;if(c&&Gu(c,i,null),l)for(const C in l){const M=l[C];Le(M)&&(i[C]=M.bind(o))}if(n){const C=n.call(o,o);Ve(C)&&(e.data=Jn(C))}if(Rs=!0,s)for(const C in s){const M=s[C],B=Le(M)?M.bind(o,o):Le(M.get)?M.get.bind(o,o):no,te=!Le(M)&&Le(M.set)?M.set.bind(o):no,V=ye({get:B,set:te});Object.defineProperty(i,C,{enumerable:!0,configurable:!0,get:()=>V.value,set:K=>V.value=K})}if(r)for(const C in r)Ma(r[C],i,o,C);if(a){const C=Le(a)?a.call(o):a;Reflect.ownKeys(C).forEach(M=>{Iu(M,C[M])})}u&&Kr(u,e,"c");function j(C,M){Me(M)?M.forEach(B=>C(B.bind(o))):M&&C(M.bind(o))}if(j(Ou,f),j(ti,p),j(Nu,d),j(Pu,b),j(Bu,m),j(Lu,g),j(Fu,O),j(Hu,w),j(zu,_),j(pr,k),j(sn,$),j(Ru,H),Me(P))if(P.length){const C=e.exposed||(e.exposed={});P.forEach(M=>{Object.defineProperty(C,M,{get:()=>o[M],set:B=>o[M]=B,enumerable:!0})})}else e.exposed||(e.exposed={});A&&e.render===no&&(e.render=A),F!=null&&(e.inheritAttrs=F),E&&(e.components=E),D&&(e.directives=D),H&&Ia(e)}function Gu(e,t,o=no){Me(e)&&(e=zs(e));for(const i in e){const n=e[i];let s;Ve(n)?"default"in n?s=Kt(n.from||i,n.default,!0):s=Kt(n.from||i):s=Kt(n),ot(s)?Object.defineProperty(t,i,{enumerable:!0,configurable:!0,get:()=>s.value,set:l=>s.value=l}):t[i]=s}}function Kr(e,t,o){Zt(Me(e)?e.map(i=>i.bind(t.proxy)):e.bind(t.proxy),t,o)}function Ma(e,t,o,i){let n=i.includes(".")?Ca(o,i):()=>o[i];if(nt(e)){const s=t[e];Le(s)&&Ho(n,s)}else if(Le(e))Ho(n,e.bind(o));else if(Ve(e))if(Me(e))e.forEach(s=>Ma(s,t,o,i));else{const s=Le(e.handler)?e.handler.bind(o):t[e.handler];Le(s)&&Ho(n,s,e)}}function Ea(e){const t=e.type,{mixins:o,extends:i}=t,{mixins:n,optionsCache:s,config:{optionMergeStrategies:l}}=e.appContext,r=s.get(t);let a;return r?a=r:!n.length&&!o&&!i?a=t:(a={},n.length&&n.forEach(c=>zn(a,c,l,!0)),zn(a,t,l)),Ve(t)&&s.set(t,a),a}function zn(e,t,o,i=!1){const{mixins:n,extends:s}=t;s&&zn(e,s,o,!0),n&&n.forEach(l=>zn(e,l,o,!0));for(const l in t)if(!(i&&l==="expose")){const r=Yu[l]||o&&o[l];e[l]=r?r(e[l],t[l]):t[l]}return e}const Yu={data:Gr,props:Yr,emits:Yr,methods:Li,computed:Li,beforeCreate:$t,created:$t,beforeMount:$t,mounted:$t,beforeUpdate:$t,updated:$t,beforeDestroy:$t,beforeUnmount:$t,destroyed:$t,unmounted:$t,activated:$t,deactivated:$t,errorCaptured:$t,serverPrefetch:$t,components:Li,directives:Li,watch:Ju,provide:Gr,inject:Zu};function Gr(e,t){return t?e?function(){return vt(Le(e)?e.call(this,this):e,Le(t)?t.call(this,this):t)}:t:e}function Zu(e,t){return Li(zs(e),zs(t))}function zs(e){if(Me(e)){const t={};for(let o=0;o<e.length;o++)t[e[o]]=e[o];return t}return e}function $t(e,t){return e?[...new Set([].concat(e,t))]:t}function Li(e,t){return e?vt(Object.create(null),e,t):t}function Yr(e,t){return e?Me(e)&&Me(t)?[...new Set([...e,...t])]:vt(Object.create(null),Vr(e),Vr(t??{})):t}function Ju(e,t){if(!e)return t;if(!t)return e;const o=vt(Object.create(null),e);for(const i in t)o[i]=$t(e[i],t[i]);return o}function Ba(){return{app:null,config:{isNativeTag:Yl,performance:!1,globalProperties:{},optionMergeStrategies:{},errorHandler:void 0,warnHandler:void 0,compilerOptions:{}},mixins:[],components:{},directives:{},provides:Object.create(null),optionsCache:new WeakMap,propsCache:new WeakMap,emitsCache:new WeakMap}}let Xu=0;function Qu(e,t){return function(i,n=null){Le(i)||(i=vt({},i)),n!=null&&!Ve(n)&&(n=null);const s=Ba(),l=new WeakSet,r=[];let a=!1;const c=s.app={_uid:Xu++,_component:i,_props:n,_container:null,_context:s,_instance:null,version:Bf,get config(){return s.config},set config(u){},use(u,...f){return l.has(u)||(u&&Le(u.install)?(l.add(u),u.install(c,...f)):Le(u)&&(l.add(u),u(c,...f))),c},mixin(u){return s.mixins.includes(u)||s.mixins.push(u),c},component(u,f){return f?(s.components[u]=f,c):s.components[u]},directive(u,f){return f?(s.directives[u]=f,c):s.directives[u]},mount(u,f,p){if(!a){const d=c._ceVNode||le(i,n);return d.appContext=s,p===!0?p="svg":p===!1&&(p=void 0),e(d,u,p),a=!0,c._container=u,u.__vue_app__=c,os(d.component)}},onUnmount(u){r.push(u)},unmount(){a&&(Zt(r,c._instance,16),e(null,c._container),delete c._container.__vue_app__)},provide(u,f){return s.provides[u]=f,c},runWithContext(u){const f=yi;yi=c;try{return u()}finally{yi=f}}};return c}}let yi=null;const ef=(e,t)=>t==="modelValue"||t==="model-value"?e.modelModifiers:e[`${t}Modifiers`]||e[`${Et(t)}Modifiers`]||e[`${Wo(t)}Modifiers`];function tf(e,t,...o){if(e.isUnmounted)return;const i=e.vnode.props||Ze;let n=o;const s=t.startsWith("update:"),l=s&&ef(i,t.slice(7));l&&(l.trim&&(n=o.map(u=>nt(u)?u.trim():u)),l.number&&(n=o.map(Gn)));let r,a=i[r=cs(t)]||i[r=cs(Et(t))];!a&&s&&(a=i[r=cs(Wo(t))]),a&&Zt(a,e,6,n);const c=i[r+"Once"];if(c){if(!e.emitted)e.emitted={};else if(e.emitted[r])return;e.emitted[r]=!0,Zt(c,e,6,n)}}const of=new WeakMap;function La(e,t,o=!1){const i=o?of:t.emitsCache,n=i.get(e);if(n!==void 0)return n;const s=e.emits;let l={},r=!1;if(!Le(e)){const a=c=>{const u=La(c,t,!0);u&&(r=!0,vt(l,u))};!o&&t.mixins.length&&t.mixins.forEach(a),e.extends&&a(e.extends),e.mixins&&e.mixins.forEach(a)}return!s&&!r?(Ve(e)&&i.set(e,null),null):(Me(s)?s.forEach(a=>l[a]=null):vt(l,s),Ve(e)&&i.set(e,l),l)}function es(e,t){return!e||!Wn(t)?!1:(t=t.slice(2),t=t==="Once"?t:t.replace(/Once$/,""),Ue(e,t[0].toLowerCase()+t.slice(1))||Ue(e,Wo(t))||Ue(e,t))}function Zr(e){const{type:t,vnode:o,proxy:i,withProxy:n,propsOptions:[s],slots:l,attrs:r,emit:a,render:c,renderCache:u,props:f,data:p,setupState:d,ctx:b,inheritAttrs:m}=e,g=Pn(e);let y,k;try{if(o.shapeFlag&4){const $=n||i,A=$;y=eo(c.call(A,$,u,f,d,p,b)),k=r}else{const $=t;y=eo($.length>1?$(f,{attrs:r,slots:l,emit:a}):$(f,null)),k=t.props?r:nf(r)}}catch($){vo.length=0,Xn($,e,1),y=le(Co)}let x=y;if(k&&m!==!1){const $=Object.keys(k),{shapeFlag:A}=x;$.length&&A&7&&(s&&$.some(qn)&&(k=sf(k,s)),x=wi(x,k,!1,!0))}return o.dirs&&(x=wi(x,null,!1,!0),x.dirs=x.dirs?x.dirs.concat(o.dirs):o.dirs),o.transition&&hr(x,o.transition),y=x,Pn(g),y}const nf=e=>{let t;for(const o in e)(o==="class"||o==="style"||Wn(o))&&((t||(t={}))[o]=e[o]);return t},sf=(e,t)=>{const o={};for(const i in e)(!qn(i)||!(i.slice(9)in t))&&(o[i]=e[i]);return o};function rf(e,t,o){const{props:i,children:n,component:s}=e,{props:l,children:r,patchFlag:a}=t,c=s.emitsOptions;if(t.dirs||t.transition)return!0;if(o&&a>=0){if(a&1024)return!0;if(a&16)return i?Jr(i,l,c):!!l;if(a&8){const u=t.dynamicProps;for(let f=0;f<u.length;f++){const p=u[f];if(Da(l,i,p)&&!es(c,p))return!0}}}else return(n||r)&&(!r||!r.$stable)?!0:i===l?!1:i?l?Jr(i,l,c):!0:!!l;return!1}function Jr(e,t,o){const i=Object.keys(t);if(i.length!==Object.keys(e).length)return!0;for(let n=0;n<i.length;n++){const s=i[n];if(Da(t,e,s)&&!es(o,s))return!0}return!1}function Da(e,t,o){const i=e[o],n=t[o];return o==="style"&&Ve(i)&&Ve(n)?!Ci(i,n):i!==n}function lf({vnode:e,parent:t,suspense:o},i){for(;t;){const n=t.subTree;if(n.suspense&&n.suspense.activeBranch===e&&(n.suspense.vnode.el=n.el=i,e=n),n===e)(e=t.vnode).el=i,t=t.parent;else break}o&&o.activeBranch===e&&(o.vnode.el=i)}const Oa={},Na=()=>Object.create(Oa),Pa=e=>Object.getPrototypeOf(e)===Oa;function af(e,t,o,i=!1){const n={},s=Na();e.propsDefaults=Object.create(null),Ra(e,t,n,s);for(const l in e.propsOptions[0])l in n||(n[l]=void 0);o?e.props=i?n:pu(n):e.type.props?e.props=n:e.props=s,e.attrs=s}function cf(e,t,o,i){const{props:n,attrs:s,vnode:{patchFlag:l}}=e,r=je(n),[a]=e.propsOptions;let c=!1;if((i||l>0)&&!(l&16)){if(l&8){const u=e.vnode.dynamicProps;for(let f=0;f<u.length;f++){let p=u[f];if(es(e.emitsOptions,p))continue;const d=t[p];if(a)if(Ue(s,p))d!==s[p]&&(s[p]=d,c=!0);else{const b=Et(p);n[b]=Hs(a,r,b,d,e,!1)}else d!==s[p]&&(s[p]=d,c=!0)}}}else{Ra(e,t,n,s)&&(c=!0);let u;for(const f in r)(!t||!Ue(t,f)&&((u=Wo(f))===f||!Ue(t,u)))&&(a?o&&(o[f]!==void 0||o[u]!==void 0)&&(n[f]=Hs(a,r,f,void 0,e,!0)):delete n[f]);if(s!==r)for(const f in s)(!t||!Ue(t,f))&&(delete s[f],c=!0)}c&&mo(e.attrs,"set","")}function Ra(e,t,o,i){const[n,s]=e.propsOptions;let l=!1,r;if(t)for(let a in t){if(Pi(a))continue;const c=t[a];let u;n&&Ue(n,u=Et(a))?!s||!s.includes(u)?o[u]=c:(r||(r={}))[u]=c:es(e.emitsOptions,a)||(!(a in i)||c!==i[a])&&(i[a]=c,l=!0)}if(s){const a=je(o),c=r||Ze;for(let u=0;u<s.length;u++){const f=s[u];o[f]=Hs(n,a,f,c[f],e,!Ue(c,f))}}return l}function Hs(e,t,o,i,n,s){const l=e[o];if(l!=null){const r=Ue(l,"default");if(r&&i===void 0){const a=l.default;if(l.type!==Function&&!l.skipFactory&&Le(a)){const{propsDefaults:c}=n;if(o in c)i=c[o];else{const u=rn(n);i=c[o]=a.call(null,t),u()}}else i=a;n.ce&&n.ce._setProp(o,i)}l[0]&&(s&&!r?i=!1:l[1]&&(i===""||i===Wo(o))&&(i=!0))}return i}const df=new WeakMap;function za(e,t,o=!1){const i=o?df:t.propsCache,n=i.get(e);if(n)return n;const s=e.props,l={},r=[];let a=!1;if(!Le(e)){const u=f=>{a=!0;const[p,d]=za(f,t,!0);vt(l,p),d&&r.push(...d)};!o&&t.mixins.length&&t.mixins.forEach(u),e.extends&&u(e.extends),e.mixins&&e.mixins.forEach(u)}if(!s&&!a)return Ve(e)&&i.set(e,hi),hi;if(Me(s))for(let u=0;u<s.length;u++){const f=Et(s[u]);Xr(f)&&(l[f]=Ze)}else if(s)for(const u in s){const f=Et(u);if(Xr(f)){const p=s[u],d=l[f]=Me(p)||Le(p)?{type:p}:vt({},p),b=d.type;let m=!1,g=!0;if(Me(b))for(let y=0;y<b.length;++y){const k=b[y],x=Le(k)&&k.name;if(x==="Boolean"){m=!0;break}else x==="String"&&(g=!1)}else m=Le(b)&&b.name==="Boolean";d[0]=m,d[1]=g,(m||Ue(d,"default"))&&r.push(f)}}const c=[l,r];return Ve(e)&&i.set(e,c),c}function Xr(e){return e[0]!=="$"&&!Pi(e)}const mr=e=>e==="_"||e==="_ctx"||e==="$stable",gr=e=>Me(e)?e.map(eo):[eo(e)],uf=(e,t,o)=>{if(t._n)return t;const i=Sa((...n)=>gr(t(...n)),o);return i._c=!1,i},Ha=(e,t,o)=>{const i=e._ctx;for(const n in e){if(mr(n))continue;const s=e[n];if(Le(s))t[n]=uf(n,s,i);else if(s!=null){const l=gr(s);t[n]=()=>l}}},Fa=(e,t)=>{const o=gr(t);e.slots.default=()=>o},ja=(e,t,o)=>{for(const i in t)(o||!mr(i))&&(e[i]=t[i])},ff=(e,t,o)=>{const i=e.slots=Na();if(e.vnode.shapeFlag&32){const n=t._;n?(ja(i,t,o),o&&Ql(i,"_",n,!0)):Ha(t,i)}else t&&Fa(e,t)},hf=(e,t,o)=>{const{vnode:i,slots:n}=e;let s=!0,l=Ze;if(i.shapeFlag&32){const r=t._;r?o&&r===1?s=!1:ja(n,t,o):(s=!t.$stable,Ha(t,n)),l=t}else t&&(Fa(e,t),l={default:1});if(s)for(const r in n)!mr(r)&&l[r]==null&&delete n[r]},Lt=bf;function pf(e){return mf(e)}function mf(e,t){const o=Yn();o.__VUE__=!0;const{insert:i,remove:n,patchProp:s,createElement:l,createText:r,createComment:a,setText:c,setElementText:u,parentNode:f,nextSibling:p,setScopeId:d=no,insertStaticContent:b}=e,m=(L,U,v,W=null,z=null,I=null,T=void 0,N=null,Y=!!U.dynamicChildren)=>{if(L===U)return;L&&!Ei(L,U)&&(W=$e(L),K(L,z,I,!0),L=null),U.patchFlag===-2&&(Y=!1,U.dynamicChildren=null);const{type:G,ref:Z,shapeFlag:Q}=U;switch(G){case ts:g(L,U,v,W);break;case Co:y(L,U,v,W);break;case kn:L==null&&k(U,v,W,T);break;case Je:E(L,U,v,W,z,I,T,N,Y);break;default:Q&1?A(L,U,v,W,z,I,T,N,Y):Q&6?D(L,U,v,W,z,I,T,N,Y):(Q&64||Q&128)&&G.process(L,U,v,W,z,I,T,N,Y,R)}Z!=null&&z?Hi(Z,L&&L.ref,I,U||L,!U):Z==null&&L&&L.ref!=null&&Hi(L.ref,null,I,L,!0)},g=(L,U,v,W)=>{if(L==null)i(U.el=r(U.children),v,W);else{const z=U.el=L.el;U.children!==L.children&&c(z,U.children)}},y=(L,U,v,W)=>{L==null?i(U.el=a(U.children||""),v,W):U.el=L.el},k=(L,U,v,W)=>{[L.el,L.anchor]=b(L.children,U,v,W,L.el,L.anchor)},x=({el:L,anchor:U},v,W)=>{let z;for(;L&&L!==U;)z=p(L),i(L,v,W),L=z;i(U,v,W)},$=({el:L,anchor:U})=>{let v;for(;L&&L!==U;)v=p(L),n(L),L=v;n(U)},A=(L,U,v,W,z,I,T,N,Y)=>{if(U.type==="svg"?T="svg":U.type==="math"&&(T="mathml"),L==null)w(U,v,W,z,I,T,N,Y);else{const G=L.el&&L.el._isVueCE?L.el:null;try{G&&G._beginPatch(),H(L,U,z,I,T,N,Y)}finally{G&&G._endPatch()}}},w=(L,U,v,W,z,I,T,N)=>{let Y,G;const{props:Z,shapeFlag:Q,transition:ce,dirs:se}=L;if(Y=L.el=l(L.type,I,Z&&Z.is,Z),Q&8?u(Y,L.children):Q&16&&O(L.children,Y,null,W,z,gs(L,I),T,N),se&&qo(L,null,W,"created"),_(Y,L,L.scopeId,T,W),Z){for(const Ce in Z)Ce!=="value"&&!Pi(Ce)&&s(Y,Ce,null,Z[Ce],I,W);"value"in Z&&s(Y,"value",null,Z.value,I),(G=Z.onVnodeBeforeMount)&&Jt(G,W,L)}se&&qo(L,null,W,"beforeMount");const me=gf(z,ce);me&&ce.beforeEnter(Y),i(Y,U,v),((G=Z&&Z.onVnodeMounted)||me||se)&&Lt(()=>{try{G&&Jt(G,W,L),me&&ce.enter(Y),se&&qo(L,null,W,"mounted")}finally{}},z)},_=(L,U,v,W,z)=>{if(v&&d(L,v),W)for(let I=0;I<W.length;I++)d(L,W[I]);if(z){let I=z.subTree;if(U===I||Va(I.type)&&(I.ssContent===U||I.ssFallback===U)){const T=z.vnode;_(L,T,T.scopeId,T.slotScopeIds,z.parent)}}},O=(L,U,v,W,z,I,T,N,Y=0)=>{for(let G=Y;G<L.length;G++){const Z=L[G]=N?ho(L[G]):eo(L[G]);m(null,Z,U,v,W,z,I,T,N)}},H=(L,U,v,W,z,I,T)=>{const N=U.el=L.el;let{patchFlag:Y,dynamicChildren:G,dirs:Z}=U;Y|=L.patchFlag&16;const Q=L.props||Ze,ce=U.props||Ze;let se;if(v&&Vo(v,!1),(se=ce.onVnodeBeforeUpdate)&&Jt(se,v,U,L),Z&&qo(U,L,v,"beforeUpdate"),v&&Vo(v,!0),G&&(!L.dynamicChildren||L.dynamicChildren.length!==G.length)&&(Y=0,T=!1,G=null),(Q.innerHTML&&ce.innerHTML==null||Q.textContent&&ce.textContent==null)&&u(N,""),G?P(L.dynamicChildren,G,N,v,W,gs(U,z),I):T||M(L,U,N,null,v,W,gs(U,z),I,!1),Y>0){if(Y&16)F(N,Q,ce,v,z);else if(Y&2&&Q.class!==ce.class&&s(N,"class",null,ce.class,z),Y&4&&s(N,"style",Q.style,ce.style,z),Y&8){const me=U.dynamicProps;for(let Ce=0;Ce<me.length;Ce++){const we=me[Ce],De=Q[we],He=ce[we];(He!==De||we==="value")&&s(N,we,De,He,z,v)}}Y&1&&L.children!==U.children&&u(N,U.children)}else!T&&G==null&&F(N,Q,ce,v,z);((se=ce.onVnodeUpdated)||Z)&&Lt(()=>{se&&Jt(se,v,U,L),Z&&qo(U,L,v,"updated")},W)},P=(L,U,v,W,z,I,T)=>{for(let N=0;N<U.length;N++){const Y=L[N],G=U[N],Z=Y.el&&(Y.type===Je||!Ei(Y,G)||Y.shapeFlag&198)?f(Y.el):v;m(Y,G,Z,null,W,z,I,T,!0)}},F=(L,U,v,W,z)=>{if(U!==v){if(U!==Ze)for(const I in U)!Pi(I)&&!(I in v)&&s(L,I,U[I],null,z,W);for(const I in v){if(Pi(I))continue;const T=v[I],N=U[I];T!==N&&I!=="value"&&s(L,I,N,T,z,W)}"value"in v&&s(L,"value",U.value,v.value,z)}},E=(L,U,v,W,z,I,T,N,Y)=>{const G=U.el=L?L.el:r(""),Z=U.anchor=L?L.anchor:r("");let{patchFlag:Q,dynamicChildren:ce,slotScopeIds:se}=U;se&&(N=N?N.concat(se):se),L==null?(i(G,v,W),i(Z,v,W),O(U.children||[],v,Z,z,I,T,N,Y)):Q>0&&Q&64&&ce&&L.dynamicChildren&&L.dynamicChildren.length===ce.length?(P(L.dynamicChildren,ce,v,z,I,T,N),(U.key!=null||z&&U===z.subTree)&&Ua(L,U,!0)):M(L,U,v,Z,z,I,T,N,Y)},D=(L,U,v,W,z,I,T,N,Y)=>{U.slotScopeIds=N,L==null?U.shapeFlag&512?z.ctx.activate(U,v,W,T,Y):S(U,v,W,z,I,T,Y):q(L,U,Y)},S=(L,U,v,W,z,I,T)=>{const N=L.component=_f(L,W,z);if($a(L)&&(N.ctx.renderer=R),If(N,!1,T),N.asyncDep){if(z&&z.registerDep(N,j,T),!L.el){const Y=N.subTree=le(Co);y(null,Y,U,v),L.placeholder=Y.el}}else j(N,L,U,v,z,I,T)},q=(L,U,v)=>{const W=U.component=L.component;if(rf(L,U,v))if(W.asyncDep&&!W.asyncResolved){C(W,U,v);return}else W.next=U,W.update();else U.el=L.el,W.vnode=U},j=(L,U,v,W,z,I,T)=>{const N=()=>{if(L.isMounted){let{next:Q,bu:ce,u:se,parent:me,vnode:Ce}=L;{const rt=Wa(L);if(rt){Q&&(Q.el=Ce.el,C(L,Q,T)),rt.asyncDep.then(()=>{Lt(()=>{L.isUnmounted||G()},z)});return}}let we=Q,De;Vo(L,!1),Q?(Q.el=Ce.el,C(L,Q,T)):Q=Ce,ce&&vn(ce),(De=Q.props&&Q.props.onVnodeBeforeUpdate)&&Jt(De,me,Q,Ce),Vo(L,!0);const He=Zr(L),Ke=L.subTree;L.subTree=He,m(Ke,He,f(Ke.el),$e(Ke),L,z,I),Q.el=He.el,we===null&&lf(L,He.el),se&&Lt(se,z),(De=Q.props&&Q.props.onVnodeUpdated)&&Lt(()=>Jt(De,me,Q,Ce),z)}else{let Q;const{el:ce,props:se}=U,{bm:me,m:Ce,parent:we,root:De,type:He}=L,Ke=gi(U);Vo(L,!1),me&&vn(me),!Ke&&(Q=se&&se.onVnodeBeforeMount)&&Jt(Q,we,U),Vo(L,!0);{De.ce&&De.ce._hasShadowRoot()&&De.ce._injectChildStyle(He,L.parent?L.parent.type:void 0);const rt=L.subTree=Zr(L);m(null,rt,v,W,L,z,I),U.el=rt.el}if(Ce&&Lt(Ce,z),!Ke&&(Q=se&&se.onVnodeMounted)){const rt=U;Lt(()=>Jt(Q,we,rt),z)}(U.shapeFlag&256||we&&gi(we.vnode)&&we.vnode.shapeFlag&256)&&L.a&&Lt(L.a,z),L.isMounted=!0,U=v=W=null}};L.scope.on();const Y=L.effect=new ia(N);L.scope.off();const G=L.update=Y.run.bind(Y),Z=L.job=Y.runIfDirty.bind(Y);Z.i=L,Z.id=L.uid,Y.scheduler=()=>fr(Z),Vo(L,!0),G()},C=(L,U,v)=>{U.component=L;const W=L.vnode.props;L.vnode=U,L.next=null,cf(L,U.props,W,v),hf(L,U.children,v),xo(),jr(L),So()},M=(L,U,v,W,z,I,T,N,Y=!1)=>{const G=L&&L.children,Z=L?L.shapeFlag:0,Q=U.children,{patchFlag:ce,shapeFlag:se}=U;if(ce>0){if(ce&128){te(G,Q,v,W,z,I,T,N,Y);return}else if(ce&256){B(G,Q,v,W,z,I,T,N,Y);return}}se&8?(Z&16&&Se(G,z,I),Q!==G&&u(v,Q)):Z&16?se&16?te(G,Q,v,W,z,I,T,N,Y):Se(G,z,I,!0):(Z&8&&u(v,""),se&16&&O(Q,v,W,z,I,T,N,Y))},B=(L,U,v,W,z,I,T,N,Y)=>{L=L||hi,U=U||hi;const G=L.length,Z=U.length,Q=Math.min(G,Z);let ce;for(ce=0;ce<Q;ce++){const se=U[ce]=Y?ho(U[ce]):eo(U[ce]);m(L[ce],se,v,null,z,I,T,N,Y)}G>Z?Se(L,z,I,!0,!1,Q):O(U,v,W,z,I,T,N,Y,Q)},te=(L,U,v,W,z,I,T,N,Y)=>{let G=0;const Z=U.length;let Q=L.length-1,ce=Z-1;for(;G<=Q&&G<=ce;){const se=L[G],me=U[G]=Y?ho(U[G]):eo(U[G]);if(Ei(se,me))m(se,me,v,null,z,I,T,N,Y);else break;G++}for(;G<=Q&&G<=ce;){const se=L[Q],me=U[ce]=Y?ho(U[ce]):eo(U[ce]);if(Ei(se,me))m(se,me,v,null,z,I,T,N,Y);else break;Q--,ce--}if(G>Q){if(G<=ce){const se=ce+1,me=se<Z?U[se].el:W;for(;G<=ce;)m(null,U[G]=Y?ho(U[G]):eo(U[G]),v,me,z,I,T,N,Y),G++}}else if(G>ce)for(;G<=Q;)K(L[G],z,I,!0),G++;else{const se=G,me=G,Ce=new Map;for(G=me;G<=ce;G++){const tt=U[G]=Y?ho(U[G]):eo(U[G]);tt.key!=null&&Ce.set(tt.key,G)}let we,De=0;const He=ce-me+1;let Ke=!1,rt=0;const Pe=new Array(He);for(G=0;G<He;G++)Pe[G]=0;for(G=se;G<=Q;G++){const tt=L[G];if(De>=He){K(tt,z,I,!0);continue}let Ge;if(tt.key!=null)Ge=Ce.get(tt.key);else for(we=me;we<=ce;we++)if(Pe[we-me]===0&&Ei(tt,U[we])){Ge=we;break}Ge===void 0?K(tt,z,I,!0):(Pe[Ge-me]=G+1,Ge>=rt?rt=Ge:Ke=!0,m(tt,U[Ge],v,null,z,I,T,N,Y),De++)}const ft=Ke?yf(Pe):hi;for(we=ft.length-1,G=He-1;G>=0;G--){const tt=me+G,Ge=U[tt],fe=U[tt+1],he=tt+1<Z?fe.el||qa(fe):W;Pe[G]===0?m(null,Ge,v,he,z,I,T,N,Y):Ke&&(we<0||G!==ft[we]?V(Ge,v,he,2):we--)}}},V=(L,U,v,W,z=null)=>{const{el:I,type:T,transition:N,children:Y,shapeFlag:G}=L;if(G&6){V(L.component.subTree,U,v,W);return}if(G&128){L.suspense.move(U,v,W);return}if(G&64){T.move(L,U,v,R);return}if(T===Je){i(I,U,v);for(let Q=0;Q<Y.length;Q++)V(Y[Q],U,v,W);i(L.anchor,U,v);return}if(T===kn){x(L,U,v);return}if(W!==2&&G&1&&N)if(W===0)N.persisted&&!I[ps]?i(I,U,v):(N.beforeEnter(I),i(I,U,v),Lt(()=>N.enter(I),z));else{const{leave:Q,delayLeave:ce,afterLeave:se}=N,me=()=>{L.ctx.isUnmounted?n(I):i(I,U,v)},Ce=()=>{const we=I._isLeaving||!!I[ps];I._isLeaving&&I[ps](!0),N.persisted&&!we?me():Q(I,()=>{me(),se&&se()})};ce?ce(I,me,Ce):Ce()}else i(I,U,v)},K=(L,U,v,W=!1,z=!1)=>{const{type:I,props:T,ref:N,children:Y,dynamicChildren:G,shapeFlag:Z,patchFlag:Q,dirs:ce,cacheIndex:se,memo:me}=L;if(Q===-2&&(z=!1),N!=null&&(xo(),Hi(N,null,v,L,!0),So()),se!=null&&(U.renderCache[se]=void 0),Z&256){U.ctx.deactivate(L);return}const Ce=Z&1&&ce,we=!gi(L);let De;if(we&&(De=T&&T.onVnodeBeforeUnmount)&&Jt(De,U,L),Z&6)re(L.component,v,W);else{if(Z&128){L.suspense.unmount(v,W);return}Ce&&qo(L,null,U,"beforeUnmount"),Z&64?L.type.remove(L,U,v,R,W):G&&!G.hasOnce&&(I!==Je||Q>0&&Q&64)?Se(G,U,v,!1,!0):(I===Je&&Q&384||!z&&Z&16)&&Se(Y,U,v),W&&ae(L)}const He=me!=null&&se==null;(we&&(De=T&&T.onVnodeUnmounted)||Ce||He)&&Lt(()=>{De&&Jt(De,U,L),Ce&&qo(L,null,U,"unmounted"),He&&(L.el=null)},v)},ae=L=>{const{type:U,el:v,anchor:W,transition:z}=L;if(U===Je){oe(v,W);return}if(U===kn){$(L);return}const I=()=>{n(v),z&&!z.persisted&&z.afterLeave&&z.afterLeave()};if(L.shapeFlag&1&&z&&!z.persisted){const{leave:T,delayLeave:N}=z,Y=()=>T(v,I);N?N(L.el,I,Y):Y()}else I()},oe=(L,U)=>{let v;for(;L!==U;)v=p(L),n(L),L=v;n(U)},re=(L,U,v)=>{const{bum:W,scope:z,job:I,subTree:T,um:N,m:Y,a:G}=L;Qr(Y),Qr(G),W&&vn(W),z.stop(),I&&(I.flags|=8,K(T,L,U,v)),N&&Lt(N,U),Lt(()=>{L.isUnmounted=!0},U)},Se=(L,U,v,W=!1,z=!1,I=0)=>{for(let T=I;T<L.length;T++)K(L[T],U,v,W,z)},$e=L=>{if(L.shapeFlag&6)return $e(L.component.subTree);if(L.shapeFlag&128)return L.suspense.next();const U=p(L.anchor||L.el),v=U&&U[Mu];return v?p(v):U};let ke=!1;const _e=(L,U,v)=>{let W;L==null?U._vnode&&(K(U._vnode,null,null,!0),W=U._vnode.component):m(U._vnode||null,L,U,null,null,null,v),U._vnode=L,ke||(ke=!0,jr(W),ka(),ke=!1)},R={p:m,um:K,m:V,r:ae,mt:S,mc:O,pc:M,pbc:P,n:$e,o:e};return{render:_e,hydrate:void 0,createApp:Qu(_e)}}function gs({type:e,props:t},o){return o==="svg"&&e==="foreignObject"||o==="mathml"&&e==="annotation-xml"&&t&&t.encoding&&t.encoding.includes("html")?void 0:o}function Vo({effect:e,job:t},o){o?(e.flags|=32,t.flags|=4):(e.flags&=-33,t.flags&=-5)}function gf(e,t){return(!e||e&&!e.pendingBranch)&&t&&!t.persisted}function Ua(e,t,o=!1){const i=e.children,n=t.children;if(Me(i)&&Me(n))for(let s=0;s<i.length;s++){const l=i[s];let r=n[s];r.shapeFlag&1&&!r.dynamicChildren&&((r.patchFlag<=0||r.patchFlag===32)&&(r=n[s]=ho(n[s]),r.el=l.el),!o&&r.patchFlag!==-2&&Ua(l,r)),r.type===ts&&(r.patchFlag===-1&&(r=n[s]=ho(r)),r.el=l.el),r.type===Co&&!r.el&&(r.el=l.el)}}function yf(e){const t=e.slice(),o=[0];let i,n,s,l,r;const a=e.length;for(i=0;i<a;i++){const c=e[i];if(c!==0){if(n=o[o.length-1],e[n]<c){t[i]=n,o.push(i);continue}for(s=0,l=o.length-1;s<l;)r=s+l>>1,e[o[r]]<c?s=r+1:l=r;c<e[o[s]]&&(s>0&&(t[i]=o[s-1]),o[s]=i)}}for(s=o.length,l=o[s-1];s-- >0;)o[s]=l,l=t[l];return o}function Wa(e){const t=e.subTree.component;if(t)return t.asyncDep&&!t.asyncResolved?t:Wa(t)}function Qr(e){if(e)for(let t=0;t<e.length;t++)e[t].flags|=8}function qa(e){if(e.placeholder)return e.placeholder;const t=e.component;return t?qa(t.subTree):null}const Va=e=>e.__isSuspense;function bf(e,t){t&&t.pendingBranch?Me(e)?t.effects.push(...e):t.effects.push(e):Cu(e)}const Je=Symbol.for("v-fgt"),ts=Symbol.for("v-txt"),Co=Symbol.for("v-cmt"),kn=Symbol.for("v-stc"),vo=[];let Rt=null;function J(e=!1){vo.push(Rt=e?null:[])}function yr(){vo.pop(),Rt=vo[vo.length-1]||null}let Qi=1;function el(e,t=!1){Qi+=e,e<0&&Rt&&t&&(Rt.hasOnce=!0)}function Ka(e){return e.dynamicChildren=Qi>0?Rt||hi:null,yr(),Qi>0&&Rt&&Rt.push(e),e}function X(e,t,o,i,n,s){return Ka(h(e,t,o,i,n,s,!0))}function qt(e,t,o,i,n){return Ka(le(e,t,o,i,n,!0))}function br(e){return e?e.__v_isVNode===!0:!1}function Ei(e,t){return e.type===t.type&&e.key===t.key}const Ga=({key:e})=>e??null,wn=({ref:e,ref_key:t,ref_for:o})=>(typeof e=="number"&&(e=""+e),e!=null?nt(e)||ot(e)||Le(e)?{i:bt,r:e,k:t,f:!!o}:e:null);function h(e,t=null,o=null,i=0,n=null,s=e===Je?0:1,l=!1,r=!1){const a={__v_isVNode:!0,__v_skip:!0,type:e,props:t,key:t&&Ga(t),ref:t&&wn(t),scopeId:xa,slotScopeIds:null,children:o,component:null,suspense:null,ssContent:null,ssFallback:null,dirs:null,transition:null,el:null,anchor:null,target:null,targetStart:null,targetAnchor:null,staticCount:0,shapeFlag:s,patchFlag:i,dynamicProps:n,dynamicChildren:null,appContext:null,ctx:bt};return r?(Hn(a,o),s&128&&e.normalize(a)):o&&(a.shapeFlag|=nt(o)?8:16),Qi>0&&!l&&Rt&&(a.patchFlag>0||s&6)&&a.patchFlag!==32&&Rt.push(a),a}const le=vf;function vf(e,t=null,o=null,i=0,n=null,s=!1){if((!e||e===Wu)&&(e=Co),br(e)){const r=wi(e,t,!0);return o&&Hn(r,o),Qi>0&&!s&&Rt&&(r.shapeFlag&6?Rt[Rt.indexOf(e)]=r:Rt.push(r)),r.patchFlag=-2,r}if(Ef(e)&&(e=e.__vccOpts),t){t=kf(t);let{class:r,style:a}=t;r&&!nt(r)&&(t.class=xe(r)),Ve(a)&&(ur(a)&&!Me(a)&&(a=vt({},a)),t.style=oo(a))}const l=nt(e)?1:Va(e)?128:Eu(e)?64:Ve(e)?4:Le(e)?2:0;return h(e,t,o,i,n,l,s,!0)}function kf(e){return e?ur(e)||Pa(e)?vt({},e):e:null}function wi(e,t,o=!1,i=!1){const{props:n,ref:s,patchFlag:l,children:r,transition:a}=e,c=t?wf(n||{},t):n,u={__v_isVNode:!0,__v_skip:!0,type:e.type,props:c,key:c&&Ga(c),ref:t&&t.ref?o&&s?Me(s)?s.concat(wn(t)):[s,wn(t)]:wn(t):s,scopeId:e.scopeId,slotScopeIds:e.slotScopeIds,children:r,target:e.target,targetStart:e.targetStart,targetAnchor:e.targetAnchor,staticCount:e.staticCount,shapeFlag:e.shapeFlag,patchFlag:t&&e.type!==Je?l===-1?16:l|16:l,dynamicProps:e.dynamicProps,dynamicChildren:e.dynamicChildren,appContext:e.appContext,dirs:e.dirs,transition:a,component:e.component,suspense:e.suspense,ssContent:e.ssContent&&wi(e.ssContent),ssFallback:e.ssFallback&&wi(e.ssFallback),placeholder:e.placeholder,el:e.el,anchor:e.anchor,ctx:e.ctx,ce:e.ce};return a&&i&&hr(u,a.clone(u)),u}function St(e=" ",t=0){return le(ts,null,e,t)}function mt(e,t){const o=le(kn,null,e);return o.staticCount=t,o}function Ae(e="",t=!1){return t?(J(),qt(Co,null,e)):le(Co,null,e)}function eo(e){return e==null||typeof e=="boolean"?le(Co):Me(e)?le(Je,null,e.slice()):br(e)?ho(e):le(ts,null,String(e))}function ho(e){return e.el===null&&e.patchFlag!==-1||e.memo?e:wi(e)}function Hn(e,t){let o=0;const{shapeFlag:i}=e;if(t==null)t=null;else if(Me(t))o=16;else if(typeof t=="object")if(i&65){const n=t.default;n&&(n._c&&(n._d=!1),Hn(e,n()),n._c&&(n._d=!0));return}else{o=32;const n=t._;!n&&!Pa(t)?t._ctx=bt:n===3&&bt&&(bt.slots._===1?t._=1:(t._=2,e.patchFlag|=1024))}else if(Le(t)){if(i&65){Hn(e,{default:t});return}t={default:t,_ctx:bt},o=32}else t=String(t),i&64?(o=16,t=[St(t)]):o=8;e.children=t,e.shapeFlag|=o}function wf(...e){const t={};for(let o=0;o<e.length;o++){const i=e[o];for(const n in i)if(n==="class")t.class!==i.class&&(t.class=xe([t.class,i.class]));else if(n==="style")t.style=oo([t.style,i.style]);else if(Wn(n)){const s=t[n],l=i[n];l&&s!==l&&!(Me(s)&&s.includes(l))?t[n]=s?[].concat(s,l):l:l==null&&s==null&&!qn(n)&&(t[n]=l)}else n!==""&&(t[n]=i[n])}return t}function Jt(e,t,o,i=null){Zt(e,t,7,[o,i])}const xf=Ba();let Sf=0;function _f(e,t,o){const i=e.type,n=(t?t.appContext:e.appContext)||xf,s={uid:Sf++,vnode:e,type:i,parent:t,appContext:n,root:null,next:null,subTree:null,effect:null,update:null,job:null,scope:new Yd(!0),render:null,proxy:null,exposed:null,exposeProxy:null,withProxy:null,provides:t?t.provides:Object.create(n.provides),ids:t?t.ids:["",0,0],accessCache:null,renderCache:[],components:null,directives:null,propsOptions:za(i,n),emitsOptions:La(i,n),emit:null,emitted:null,propsDefaults:Ze,inheritAttrs:i.inheritAttrs,ctx:Ze,data:Ze,props:Ze,attrs:Ze,slots:Ze,refs:Ze,setupState:Ze,setupContext:null,suspense:o,suspenseId:o?o.pendingId:0,asyncDep:null,asyncResolved:!1,isMounted:!1,isUnmounted:!1,isDeactivated:!1,bc:null,c:null,bm:null,m:null,bu:null,u:null,um:null,bum:null,da:null,a:null,rtg:null,rtc:null,ec:null,sp:null};return s.ctx={_:s},s.root=t?t.root:s,s.emit=tf.bind(null,s),e.ce&&e.ce(s),s}let Ct=null;const Cf=()=>Ct||bt;let Fn,Fs;{const e=Yn(),t=(o,i)=>{let n;return(n=e[o])||(n=e[o]=[]),n.push(i),s=>{n.length>1?n.forEach(l=>l(s)):n[0](s)}};Fn=t("__VUE_INSTANCE_SETTERS__",o=>Ct=o),Fs=t("__VUE_SSR_SETTERS__",o=>en=o)}const rn=e=>{const t=Ct;return Fn(e),e.scope.on(),()=>{e.scope.off(),Fn(t)}},tl=()=>{Ct&&Ct.scope.off(),Fn(null)};function Ya(e){return e.vnode.shapeFlag&4}let en=!1;function If(e,t=!1,o=!1){t&&Fs(t);const{props:i,children:n}=e.vnode,s=Ya(e);af(e,i,s,t),ff(e,n,o||t);const l=s?$f(e,t):void 0;return t&&Fs(!1),l}function $f(e,t){const o=e.type;e.accessCache=Object.create(null),e.proxy=new Proxy(e.ctx,Vu);const{setup:i}=o;if(i){xo();const n=e.setupContext=i.length>1?Af(e):null,s=rn(e),l=nn(i,e,0,[e.props,n]),r=Zl(l);if(So(),s(),(r||e.sp)&&!gi(e)&&Ia(e),r){if(l.then(tl,tl),t)return l.then(a=>{ol(e,a)}).catch(a=>{Xn(a,e,0)});e.asyncDep=l}else ol(e,l)}else Za(e)}function ol(e,t,o){Le(t)?e.type.__ssrInlineRender?e.ssrRender=t:e.render=t:Ve(t)&&(e.setupState=ya(t)),Za(e)}function Za(e,t,o){const i=e.type;e.render||(e.render=i.render||no);{const n=rn(e);xo();try{Ku(e)}finally{So(),n()}}}const Tf={get(e,t){return xt(e,"get",""),e[t]}};function Af(e){const t=o=>{e.exposed=o||{}};return{attrs:new Proxy(e.attrs,Tf),slots:e.slots,emit:e.emit,expose:t}}function os(e){return e.exposed?e.exposeProxy||(e.exposeProxy=new Proxy(ya(mu(e.exposed)),{get(t,o){if(o in t)return t[o];if(o in Fi)return Fi[o](e)},has(t,o){return o in t||o in Fi}})):e.proxy}function Mf(e,t=!0){return Le(e)?e.displayName||e.name:e.name||t&&e.__name}function Ef(e){return Le(e)&&"__vccOpts"in e}const ye=(e,t)=>ku(e,t,en),Bf="3.5.40";/**
* @vue/runtime-dom v3.5.40
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/let js;const il=typeof window<"u"&&window.trustedTypes;if(il)try{js=il.createPolicy("vue",{createHTML:e=>e})}catch{}const Ja=js?e=>js.createHTML(e):e=>e,Lf="http://www.w3.org/2000/svg",Df="http://www.w3.org/1998/Math/MathML",uo=typeof document<"u"?document:null,nl=uo&&uo.createElement("template"),Of={insert:(e,t,o)=>{t.insertBefore(e,o||null)},remove:e=>{const t=e.parentNode;t&&t.removeChild(e)},createElement:(e,t,o,i)=>{const n=t==="svg"?uo.createElementNS(Lf,e):t==="mathml"?uo.createElementNS(Df,e):o?uo.createElement(e,{is:o}):uo.createElement(e);return e==="select"&&i&&i.multiple!=null&&n.setAttribute("multiple",i.multiple),n},createText:e=>uo.createTextNode(e),createComment:e=>uo.createComment(e),setText:(e,t)=>{e.nodeValue=t},setElementText:(e,t)=>{e.textContent=t},parentNode:e=>e.parentNode,nextSibling:e=>e.nextSibling,querySelector:e=>uo.querySelector(e),setScopeId(e,t){e.setAttribute(t,"")},insertStaticContent(e,t,o,i,n,s){const l=o?o.previousSibling:t.lastChild;if(n&&(n===s||n.nextSibling))for(;t.insertBefore(n.cloneNode(!0),o),!(n===s||!(n=n.nextSibling)););else{nl.innerHTML=Ja(i==="svg"?`<svg>${e}</svg>`:i==="mathml"?`<math>${e}</math>`:e);const r=nl.content;if(i==="svg"||i==="mathml"){const a=r.firstChild;for(;a.firstChild;)r.appendChild(a.firstChild);r.removeChild(a)}t.insertBefore(r,o)}return[l?l.nextSibling:t.firstChild,o?o.previousSibling:t.lastChild]}},Nf=Symbol("_vtc");function Pf(e,t,o){const i=e[Nf];i&&(t=(t?[t,...i]:[...i]).join(" ")),t==null?e.removeAttribute("class"):o?e.setAttribute("class",t):e.className=t}const jn=Symbol("_vod"),Xa=Symbol("_vsh"),Us={name:"show",beforeMount(e,{value:t},{transition:o}){e[jn]=e.style.display==="none"?"":e.style.display,o&&t?o.beforeEnter(e):Bi(e,t)},mounted(e,{value:t},{transition:o}){o&&t&&o.enter(e)},updated(e,{value:t,oldValue:o},{transition:i}){!t!=!o&&(i?t?(i.beforeEnter(e),Bi(e,!0),i.enter(e)):i.leave(e,()=>{Bi(e,!1)}):Bi(e,t))},beforeUnmount(e,{value:t}){Bi(e,t)}};function Bi(e,t){e.style.display=t?e[jn]:"none",e[Xa]=!t}const Rf=Symbol(""),zf=/(?:^|;)\s*display\s*:/;function Hf(e,t,o){const i=e.style,n=nt(o);let s=!1;if(o&&!n){if(t)if(nt(t))for(const l of t.split(";")){const r=l.slice(0,l.indexOf(":")).trim();o[r]==null&&Di(i,r,"")}else for(const l in t)o[l]==null&&Di(i,l,"");for(const l in o){l==="display"&&(s=!0);const r=o[l];r!=null?jf(e,l,!nt(t)&&t?t[l]:void 0,r)||Di(i,l,r):Di(i,l,"")}}else if(n){if(t!==o){const l=i[Rf];l&&(o+=";"+l),i.cssText=o,s=zf.test(o)}}else t&&e.removeAttribute("style");jn in e&&(e[jn]=s?i.display:"",e[Xa]&&(i.display="none"))}const sl=/\s*!important$/;function Di(e,t,o){if(Me(o))o.forEach(i=>Di(e,t,i));else if(o==null&&(o=""),t.startsWith("--"))e.setProperty(t,o);else{const i=Ff(e,t);sl.test(o)?e.setProperty(Wo(i),o.replace(sl,""),"important"):e[i]=o}}const rl=["Webkit","Moz","ms"],ys={};function Ff(e,t){const o=ys[t];if(o)return o;let i=Et(t);if(i!=="filter"&&i in e)return ys[t]=i;i=Kn(i);for(let n=0;n<rl.length;n++){const s=rl[n]+i;if(s in e)return ys[t]=s}return t}function jf(e,t,o,i){return e.tagName==="TEXTAREA"&&(t==="width"||t==="height")&&nt(i)&&o===i}const ll="http://www.w3.org/1999/xlink";function al(e,t,o,i,n,s=Kd(t)){i&&t.startsWith("xlink:")?o==null?e.removeAttributeNS(ll,t.slice(6,t.length)):e.setAttributeNS(ll,t,o):o==null||s&&!ea(o)?e.removeAttribute(t):e.setAttribute(t,s?"":Gt(o)?String(o):o)}function cl(e,t,o,i,n){if(t==="innerHTML"||t==="textContent"){o!=null&&(e[t]=t==="innerHTML"?Ja(o):o);return}const s=e.tagName;if(t==="value"&&s!=="PROGRESS"&&!s.includes("-")){const r=s==="OPTION"?e.getAttribute("value")||"":e.value,a=o==null?e.type==="checkbox"?"on":"":String(o);(r!==a||!("_value"in e))&&(e.value=a),o==null&&e.removeAttribute(t),e._value=o;return}let l=!1;if(o===""||o==null){const r=typeof e[t];r==="boolean"?o=ea(o):o==null&&r==="string"?(o="",l=!0):r==="number"&&(o=0,l=!0)}try{e[t]=o}catch{}l&&e.removeAttribute(n||t)}function Lo(e,t,o,i){e.addEventListener(t,o,i)}function Uf(e,t,o,i){e.removeEventListener(t,o,i)}const dl=Symbol("_vei");function Wf(e,t,o,i,n=null){const s=e[dl]||(e[dl]={}),l=s[t];if(i&&l)l.value=i;else{const[r,a]=Kf(t);if(i){const c=s[t]=Zf(i,n);Lo(e,r,c,a)}else l&&(Uf(e,r,l,a),s[t]=void 0)}}const qf=/(Once|Passive|Capture)$/,Vf=/^on:?(?:Once|Passive|Capture)$/;function Kf(e){let t,o;for(;(o=e.match(qf))&&!Vf.test(e);)t||(t={}),e=e.slice(0,e.length-o[1].length),t[o[1].toLowerCase()]=!0;return[e[2]===":"?e.slice(3):Wo(e.slice(2)),t]}let bs=0;const Gf=Promise.resolve(),Yf=()=>bs||(Gf.then(()=>bs=0),bs=Date.now());function Zf(e,t){const o=i=>{if(!i._vts)i._vts=Date.now();else if(i._vts<=o.attached)return;const n=o.value;if(Me(n)){const s=i.stopImmediatePropagation;i.stopImmediatePropagation=()=>{s.call(i),i._stopped=!0};const l=n.slice(),r=[i];for(let a=0;a<l.length&&!i._stopped;a++){const c=l[a];c&&Zt(c,t,5,r)}}else Zt(n,t,5,[i])};return o.value=e,o.attached=Yf(),o}const ul=e=>e.charCodeAt(0)===111&&e.charCodeAt(1)===110&&e.charCodeAt(2)>96&&e.charCodeAt(2)<123,Jf=(e,t,o,i,n,s)=>{const l=n==="svg";t==="class"?Pf(e,i,l):t==="style"?Hf(e,o,i):Wn(t)?qn(t)||Wf(e,t,o,i,s):(t[0]==="."?(t=t.slice(1),!0):t[0]==="^"?(t=t.slice(1),!1):Xf(e,t,i,l))?(cl(e,t,i),!e.tagName.includes("-")&&(t==="value"||t==="checked"||t==="selected")&&al(e,t,i,l,s,t!=="value")):e._isVueCE&&(Qf(e,t)||e._def.__asyncLoader&&(/[A-Z]/.test(t)||!nt(i)))?cl(e,Et(t),i,s,t):(t==="true-value"?e._trueValue=i:t==="false-value"&&(e._falseValue=i),al(e,t,i,l))};function Xf(e,t,o,i){if(i)return!!(t==="innerHTML"||t==="textContent"||t in e&&ul(t)&&Le(o));if(t==="spellcheck"||t==="draggable"||t==="translate"||t==="autocorrect"||t==="sandbox"&&e.tagName==="IFRAME"||t==="form"||t==="list"&&e.tagName==="INPUT"||t==="type"&&e.tagName==="TEXTAREA")return!1;if(t==="width"||t==="height"){const n=e.tagName;if(n==="IMG"||n==="VIDEO"||n==="CANVAS"||n==="SOURCE")return!1}return ul(t)&&nt(o)?!1:t in e}function Qf(e,t){const o=e._def.props;if(!o)return!1;const i=Et(t);return Array.isArray(o)?o.some(n=>Et(n)===i):Object.keys(o).some(n=>Et(n)===i)}const xi=e=>{const t=e.props["onUpdate:modelValue"]||!1;return Me(t)?o=>vn(t,o):t};function eh(e){e.target.composing=!0}function fl(e){const t=e.target;t.composing&&(t.composing=!1,t.dispatchEvent(new Event("input")))}const ko=Symbol("_assign");function hl(e,t,o){return t&&(e=e.trim()),o&&(e=Gn(e)),e}const Ws={created(e,{modifiers:{lazy:t,trim:o,number:i}},n){e[ko]=xi(n);const s=i||n.props&&n.props.type==="number";Lo(e,t?"change":"input",l=>{l.target.composing||e[ko](hl(e.value,o,s))}),(o||s)&&Lo(e,"change",()=>{e.value=hl(e.value,o,s)}),t||(Lo(e,"compositionstart",eh),Lo(e,"compositionend",fl),Lo(e,"change",fl))},mounted(e,{value:t}){e.value=t??""},beforeUpdate(e,{value:t,oldValue:o,modifiers:{lazy:i,trim:n,number:s}},l){if(e[ko]=xi(l),e.composing)return;const r=(s||e.type==="number")&&!/^0\d/.test(e.value)?Gn(e.value):e.value,a=t??"";if(r===a)return;const c=e.getRootNode();(c instanceof Document||c instanceof ShadowRoot)&&c.activeElement===e&&e.type!=="range"&&(i&&t===o||n&&e.value.trim()===a)||(e.value=a)}},pn={deep:!0,created(e,t,o){e[ko]=xi(o),Lo(e,"change",()=>{const i=e._modelValue,n=tn(e),s=e.checked,l=e[ko];if(Me(i)){const r=nr(i,n),a=r!==-1;if(s&&!a)l(i.concat(n));else if(!s&&a){const c=[...i];c.splice(r,1),l(c)}}else if(_i(i)){const r=new Set(i);s?r.add(n):r.delete(n),l(r)}else l(Qa(e,s))})},mounted:pl,beforeUpdate(e,t,o){e[ko]=xi(o),pl(e,t,o)}};function pl(e,{value:t,oldValue:o},i){e._modelValue=t;let n;if(Me(t))n=nr(t,i.props.value)>-1;else if(_i(t))n=t.has(i.props.value);else{if(t===o)return;n=Ci(t,Qa(e,!0))}e.checked!==n&&(e.checked=n)}const th={deep:!0,created(e,{value:t,modifiers:{number:o}},i){e._modelValue=t,Lo(e,"change",()=>{const n=Array.prototype.filter.call(e.options,s=>s.selected).map(s=>o?Gn(tn(s)):tn(s));e[ko](e.multiple?_i(e._modelValue)?new Set(n):n:n[0]),e._assigning=!0,Nn(()=>{e._assigning=!1})}),e[ko]=xi(i)},mounted(e,{value:t}){ml(e,t)},beforeUpdate(e,{value:t},o){e._modelValue=t,e[ko]=xi(o)},updated(e,{value:t}){e._assigning||ml(e,t)}};function ml(e,t){const o=e.multiple,i=Me(t);if(!(o&&!i&&!_i(t))){for(let n=0,s=e.options.length;n<s;n++){const l=e.options[n],r=tn(l);if(o)if(i){const a=typeof r;a==="string"||a==="number"?l.selected=t.some(c=>String(c)===String(r)):l.selected=nr(t,r)>-1}else l.selected=t.has(r);else if(Ci(tn(l),t)){e.selectedIndex!==n&&(e.selectedIndex=n);return}}!o&&e.selectedIndex!==-1&&(e.selectedIndex=-1)}}function tn(e){return"_value"in e?e._value:e.value}function Qa(e,t){const o=t?"_trueValue":"_falseValue";return o in e?e[o]:t}const oh=["ctrl","shift","alt","meta"],ih={stop:e=>e.stopPropagation(),prevent:e=>e.preventDefault(),self:e=>e.target!==e.currentTarget,ctrl:e=>!e.ctrlKey,shift:e=>!e.shiftKey,alt:e=>!e.altKey,meta:e=>!e.metaKey,left:e=>"button"in e&&e.button!==0,middle:e=>"button"in e&&e.button!==1,right:e=>"button"in e&&e.button!==2,exact:(e,t)=>oh.some(o=>e[`${o}Key`]&&!t.includes(o))},io=(e,t)=>{if(!e)return e;const o=e._withMods||(e._withMods={}),i=t.join(".");return o[i]||(o[i]=((n,...s)=>{for(let l=0;l<t.length;l++){const r=ih[t[l]];if(r&&r(n,t))return}return e(n,...s)}))},nh={esc:"escape",space:" ",up:"arrow-up",left:"arrow-left",right:"arrow-right",down:"arrow-down",delete:"backspace"},sh=(e,t)=>{const o=e._withKeys||(e._withKeys={}),i=t.join(".");return o[i]||(o[i]=(n=>{if(!("key"in n))return;const s=Wo(n.key);if(t.some(l=>l===s||nh[l]===s))return e(n)}))},rh=vt({patchProp:Jf},Of);let gl;function lh(){return gl||(gl=pf(rh))}const vr=((...e)=>{const t=lh().createApp(...e),{mount:o}=t;return t.mount=i=>{const n=ch(i);if(!n)return;const s=t._component;!Le(s)&&!s.render&&!s.template&&(s.template=n.innerHTML),n.nodeType===1&&(n.textContent="");const l=o(n,!1,ah(n));return n instanceof Element&&(n.removeAttribute("v-cloak"),n.setAttribute("data-v-app","")),l},t});function ah(e){if(e instanceof SVGElement)return"svg";if(typeof MathMLElement=="function"&&e instanceof MathMLElement)return"mathml"}function ch(e){return nt(e)?document.querySelector(e):e}const pt={baseUrl:"",apiKey:"",model:"",requestTimeoutSeconds:60,temperature:.7,maxTokens:4096},dh="slides-config.json",yo={enableWebServeJump:!1,webServeUrl:"http://127.0.0.1:6806",normalizeHeadingSizes:!1,showUnorderedListMarkers:!0,showOrderedListMarkers:!0,aiConfig:{...pt}},Ht=Jn({...yo}),is=pe(null);function uh(e){is.value=e}function fh(){return is.value}function bi(e){if(!e||typeof e!="object")return{...pt};const t=e;return{baseUrl:typeof t.baseUrl=="string"?t.baseUrl.trim():pt.baseUrl,apiKey:typeof t.apiKey=="string"?t.apiKey.trim():pt.apiKey,model:typeof t.model=="string"?t.model.trim():pt.model,requestTimeoutSeconds:typeof t.requestTimeoutSeconds=="number"&&t.requestTimeoutSeconds>0?Math.floor(t.requestTimeoutSeconds):pt.requestTimeoutSeconds,temperature:typeof t.temperature=="number"&&t.temperature>=0&&t.temperature<=2?Number(t.temperature.toFixed(2)):pt.temperature,maxTokens:typeof t.maxTokens=="number"&&t.maxTokens>0?Math.floor(t.maxTokens):pt.maxTokens}}function Un(e){return e?!!(typeof e.baseUrl=="string"&&e.baseUrl.trim()&&typeof e.apiKey=="string"&&e.apiKey.trim()&&typeof e.model=="string"&&e.model.trim()):!1}function kr(){const e=is.value;if(e&&Un(e))return{isManaged:!0,profileName:e.profileName,config:{baseUrl:e.baseUrl,apiKey:e.apiKey,model:e.model,requestTimeoutSeconds:e.requestTimeoutSeconds??pt.requestTimeoutSeconds,temperature:e.temperature??pt.temperature,maxTokens:e.maxTokens??pt.maxTokens,headers:e.headers}};const t=Ht.aiConfig;return Un(t)?{isManaged:!1,config:{...t}}:null}function hh(e){if(!e||typeof e!="object")return{...yo,aiConfig:{...pt}};const t=e;return{enableWebServeJump:!!t.enableWebServeJump,webServeUrl:typeof t.webServeUrl=="string"&&t.webServeUrl.trim()?t.webServeUrl.trim():yo.webServeUrl,normalizeHeadingSizes:!!t.normalizeHeadingSizes,showUnorderedListMarkers:t.showUnorderedListMarkers!==void 0?!!t.showUnorderedListMarkers:yo.showUnorderedListMarkers,showOrderedListMarkers:t.showOrderedListMarkers!==void 0?!!t.showOrderedListMarkers:yo.showOrderedListMarkers,aiConfig:bi(t.aiConfig)}}function ht(e){if(!e||typeof e!="object")return{...Ht};const t=e;return t.enableWebServeJump!==void 0&&(Ht.enableWebServeJump=!!t.enableWebServeJump),t.webServeUrl!==void 0&&(Ht.webServeUrl=String(t.webServeUrl)),t.normalizeHeadingSizes!==void 0&&(Ht.normalizeHeadingSizes=!!t.normalizeHeadingSizes),t.showUnorderedListMarkers!==void 0&&(Ht.showUnorderedListMarkers=!!t.showUnorderedListMarkers),t.showOrderedListMarkers!==void 0&&(Ht.showOrderedListMarkers=!!t.showOrderedListMarkers),t.aiConfig!==void 0&&(Ht.aiConfig=bi(t.aiConfig)),{...Ht}}function Fo(){return{...Ht}}function ec(e,t,o){const i=(e||yo.webServeUrl).trim(),n=i.startsWith("http://")||i.startsWith("https://")?i:`http://${i}`,s=(o==null?void 0:o.r)||Math.random().toString(36).slice(2,9).padEnd(7,"0");try{const l=new URL(n);let r=l.pathname.replace(/\/+$/,"");return r.endsWith("/stage/build/desktop")||(r=r?`${r}/stage/build/desktop`:"/stage/build/desktop"),l.pathname=`${r}/`,l.searchParams.set("id",t),o!=null&&o.focus&&l.searchParams.set("focus","1"),l.searchParams.set("r",s),l.toString()}catch{const l=o!=null&&o.focus?"&focus=1":"";return`${n.replace(/\/+$/,"")}/stage/build/desktop/?id=${t}${l}&r=${s}`}}const ni={theme:"apple-basic",aspectRatio:"16/9",defaultTransition:"slide-left",colorSchema:"auto",spacing:"normal",background:"",normalizeHeadingSizes:!1,showUnorderedListMarkers:!0,showOrderedListMarkers:!0};function ph(e){var n,s,l,r,a,c;const t=Fo();if(!e)return{...ni,normalizeHeadingSizes:t.normalizeHeadingSizes,showUnorderedListMarkers:t.showUnorderedListMarkers,showOrderedListMarkers:t.showOrderedListMarkers};const o=e[Nr]!==void 0?e[Nr]!=="false":t.showUnorderedListMarkers,i=e[Pr]!==void 0?e[Pr]!=="false":t.showOrderedListMarkers;return{theme:((n=e[Vi])==null?void 0:n.trim())||ni.theme,aspectRatio:((s=e[Ki])==null?void 0:s.trim())||ni.aspectRatio,defaultTransition:((l=e[Gi])==null?void 0:l.trim())||ni.defaultTransition,colorSchema:((r=e[ql])==null?void 0:r.trim())||ni.colorSchema,spacing:((a=e[Es])==null?void 0:a.trim())||ni.spacing,background:((c=e[An])==null?void 0:c.trim())||"",normalizeHeadingSizes:t.normalizeHeadingSizes,showUnorderedListMarkers:o,showOrderedListMarkers:i}}function bo(e){var o,i,n,s,l;const t=(o=e.ial)==null?void 0:o[po];return!!(t&&(t==="true"||t==="page"||t==="cover"||t==="end")||e.type==="tb"||e.type==="thematic-break"||e.type==="NodeThematicBreak"||((i=e.markdown)==null?void 0:i.trim())==="---"||((n=e.markdown)==null?void 0:n.trim())==="***"||e.type==="b"&&(((s=e.markdown)==null?void 0:s.trim())==="---"||((l=e.content)==null?void 0:l.trim())==="---"))}function yl(e){const t={};let o="";if(!e)return{frontmatter:t,notes:o};e[be]&&(t.layout=e[be].trim()),e[_t]&&(t.transition=e[_t].trim()),e[ct]&&(t.background=e[ct].trim()),e[Wt]&&(t.image=e[Wt].trim()),e[ai]&&(t.class=e[ai].trim()),e[Ni]&&(t.spacing=e[Ni].trim()),e[yt]&&(t.layoutRatio=e[yt].trim()),e[ci]&&(t.mask=e[ci].trim()),e[Jo]&&(t.maskRatio=e[Jo].trim()),e[di]&&(t.maskStyle=e[di].trim()),e[ui]&&(t.maskInitial=e[ui].trim()),e[as]&&(o=e[as].trim());for(const[i,n]of Object.entries(e))if(i.startsWith("custom-slides-")&&![be,yt,ci,Jo,di,ui,_t,ct,Wt,ai,Ni,as,po].includes(i)){const s=i.replace(/^custom-slides-/,"");try{t[s]=JSON.parse(n)}catch{t[s]=n}}return{frontmatter:t,notes:o}}function bl(e){const t={};if(!e)return t;const o=e[Fe];o!=null&&o!==""&&o!=="false"&&o!=="0"&&(t.isNote=!0);const i=e[Ye],n=e[ct];(i===Vl||n==="true"||n==="1")&&(t.isBackground=!0);const s=e[be];s===Bn||s===Ln?t.imageLayout=s:(i===Bn||i===Ln)&&(t.imageLayout=i);const l=e[Oe];if(l!=null&&(t.clicks=l.trim()),e[Mt])try{const r=JSON.parse(e[Mt]);typeof r=="object"&&r!==null?t.motion={preset:r.preset||r.type||"fade-in",...r}:t.motion={preset:String(r).trim()}}catch{t.motion={preset:e[Mt].trim()}}return e[ei]&&(t.shikiLines=e[ei].trim()),e[Yi]&&(t.maxHeight=e[Yi].trim()),e[Te]&&(t.slot=e[Te].trim()),e.style&&e.style.trim()&&(t.style=e.style.trim()),t}function wo(e,t){const o=(e||t||"").trim();if(!o)return null;const i=o.match(/!\[[\s\S]*?\]\(\s*([^\s)]+)(?:\s+(?:=["']?[^"'\s)]*["']?|["'][^"']*["']))*?\s*\)/);if(i)return i[1].trim();const n=o.match(/<img\b[^>]*?\bsrc=["']([^"']+)["']/i);if(n)return n[1].trim();const s=o.replace(/\{:[^}]*\}/g,"").trim();return/^(?:assets\/|https?:\/\/|\/|\.\.?\/)[^\s]+\.(?:png|jpe?g|gif|webp|svg|avif)(?:\?[^\s]*)?$/i.test(s)?s:null}function ji(e){if(!e)return"";const t=e.split(/\r?\n/);if(t.length===0)return"";const o=t[0],i=o.match(/^(\s*)(?:[-*+]|\d+\.)\s+(.*)$/);if(!i)return e;const n=i[1].length,s=i[2].trim(),l=o.length-i[2].length;if(t.length===1)return s;const r=[s];for(let a=1;a<t.length;a++){const c=t[a];if(!c.trim()){r.push("");continue}const u=c.match(/^(\s*)/),f=u?u[1].length:0;f>=l?r.push(c.slice(l)):f>n?r.push(c.slice(f)):r.push(c)}return r.join(`
`)}function jo(e){if(!e)return!1;const t=(e.type||"").toLowerCase();if(t==="i"||t==="nodelistitem"||t==="l"||t==="nodelist")return!0;const o=(e.markdown||e.rawMarkdown||e.content||"").trim();return!!/^(?:[-*+]|\d+\.)\s+/.test(o)}function vs(e,t=2){if(!e||typeof e!="string")return`repeat(${t}, 1fr)`;const o=e.trim();if(!o)return`repeat(${t}, 1fr)`;if(o.includes(":")){const n=o.split(":").map(s=>parseFloat(s.trim())).filter(s=>!isNaN(s)&&s>0);if(n.length>=2)return n.map(s=>`${s}fr`).join(" ")}const i=o.split(/\s+/).filter(Boolean);return i.length>=2?i.join(" "):`repeat(${t}, 1fr)`}function Ui(e){if(!e)return[];if(ut(e)&&so(e)&&!ro(e)){const i=Ii(e),n=[];for(const s of i)n.push(...Ui(s));return n}const t=(e.type||"").toLowerCase();if(t==="l"||t==="nodelist"||t==="list"){if(e.children&&e.children.length>0){const l=e.children.filter(jo);if(l.length>0)return l}const n=(e.markdown||e.content||"").trim().split(/\r?\n/),s=[];for(let l=0;l<n.length;l++)/^(?:[-*+]|\d+\.)\s+/.test(n[l])&&s.push(l);if(s.length>=2){const l=[];for(let r=0;r<s.length;r++){const a=s[r],c=r+1<s.length?s[r+1]:n.length,u=n.slice(a,c).join(`
`);l.push({id:`${e.id}-item-${r+1}`,type:"i",markdown:u,content:u,ial:{...e.ial||{}}})}return l}}return jo(e)?[e]:[]}function wr(e){var n;if(!e||!ut(e)||!so(e)||ro(e))return null;const t=Ii(e);if(t.length===0)return null;if(t.length===1&&ut(t[0])&&so(t[0])){const s=wr(t[0]);return s?{items:s.items,nestedSuperBlocks:[t[0],...s.nestedSuperBlocks]}:null}const o=[];for(const s of t)if(ut(s)){o.push(s);const l=((n=s.children)==null?void 0:n.filter(ut))||[];o.push(...l)}const i=t.map(Ui);if(i.length>=2&&i.every(s=>s.length>0)){const s=i.flat();if(s.length>=2&&s.length<=6)return{items:s,nestedSuperBlocks:o}}if(t.length===2){const s=Ui(t[0]),l=Ui(t[1]);if(s.length+l.length>=2&&s.length+l.length<=6&&(s.length>0||l.length>0))return{items:[...s,...l],nestedSuperBlocks:o}}return null}function mh(e){if(!e||!ut(e)||!so(e)||ro(e))return null;const t=wr(e);if(!t)return null;const{items:o,nestedSuperBlocks:i}=t;if(o.length<2||o.length>6)return null;const n=xr(e)||void 0,s=o.length;return{superBlockNode:e,nestedSuperBlocks:i,count:s,layout:"cols-header",items:o,slots:o.map((l,r)=>`col-${r+1}`),ratio:n}}function tc(e){if(!e||!ut(e)||!so(e)||ro(e))return null;const t=Ii(e);if(t.length===0)return null;const o=[];for(const i of t){const n=Ui(i);if(n.length===0)return null;o.push(...n)}return o}function gh(e){if(!e||!ut(e)||!so(e)||ro(e))return null;const t=tc(e);return!t||t.length===0||t.length>=2&&t.length<=6?null:{superBlockNode:e,items:t}}function yh(e){if(!e||!ut(e)||!so(e)||ro(e))return null;const t=wr(e);if(t&&t.items.length===4)return t.items;const o=tc(e);if(o&&o.length===4)return o;const i=Ii(e);return i.length===4?i:null}function bh(e,t){if(!e||e.length===0)return null;const o=[];function i(r,a){if(ut(r)){const c=yh(r);c&&c.length===4&&o.push({sbNode:r,items:c,topLevelIndex:a})}if(r.children&&r.children.length>0)for(const c of r.children)i(c,a)}for(let r=0;r<e.length;r++)i(e[r],r);if(o.length===0)return null;let n=null;t&&(n=o.find(r=>{if(r.sbNode.id===t||r.items.some(c=>c.id===t))return!0;const a=c=>c.id===t?!0:c.children?c.children.some(a):!1;return a(r.sbNode)})||null),n||(n=o[0]);const l=e.slice(0,n.topLevelIndex).slice().reverse().find(r=>oc(r));return{superBlockNode:n.sbNode,items:n.items,headerNode:l}}function vh(e,t,o){var u,f,p,d,b;const i=[],n=[],s=(o==null?void 0:o.tracked)||[],l=[];let r={pageTargetId:e,blocks:[]};l.push(r);for(let m=0;m<t.length;m++){const g=t[m];if(bo(g)){if(l.length===1&&r.blocks.length===0){r.pageTargetId=g.id,r.blocks.push(g);continue}r={pageTargetId:g.id,blocks:[g]},l.push(r)}else r.blocks.push(g)}function a(m){const g=[];for(const y of m)ut(y)&&g.push(y),y.children&&y.children.length>0&&g.push(...a(y.children));return g}function c(m,g,y){const k={blockId:m,attrs:g,previousAttrs:y};i.push(k),o!=null&&o.onTagChange&&o.onTagChange(k)}for(const m of l){const g=m.pageTargetId,y=t.find(w=>w.id===g),k=s.find(w=>w.pageTargetId===g);if(m.blocks.some(w=>{var _,O;return!!(ro(w)||qs(w)&&(((_=w.ial)==null?void 0:_[be])==="image-left"||((O=w.ial)==null?void 0:O[be])==="image-right"))})){if(k){const w=k.headerId;if(w){c(w,{[Te]:""});const _=t.find(O=>O.id===w);_!=null&&_.ial&&(_.ial[Te]="")}for(const _ of k.itemIds){c(_,{[Te]:""});const O=t.find(H=>H.id===_);O!=null&&O.ial&&(O.ial[Te]="")}}continue}let $=null,A=-1;for(let w=0;w<m.blocks.length;w++){const _=m.blocks[w],O=ut(_)?[_,...a(_.children||[])]:_.children?a(_.children):[];for(const H of O){const P=mh(H);if(P){$=P,A=w;break}}if($)break}if($){const{superBlockNode:w,layout:_,items:O,slots:H}=$,F=m.blocks.slice(0,A).find(C=>oc(C)),E=F==null?void 0:F.id,D=((u=y==null?void 0:y.ial)==null?void 0:u[be])||"",S=D==="clover",q=S?"clover":_;if(D!==q&&(c(g,{[be]:q},{[be]:D}),y&&(y.ial||(y.ial={}),y.ial[be]=q)),F){const C=((f=F.ial)==null?void 0:f[Te])||"";C!=="header"&&(c(F.id,{[Te]:"header"},{[Te]:C}),F.ial||(F.ial={}),F.ial[Te]="header")}if(k!=null&&k.headerId&&k.headerId!==E){c(k.headerId,{[Te]:""});const C=t.find(M=>M.id===k.headerId);C&&(C.ial||(C.ial={}),C.ial[Te]="")}const j=[];for(let C=0;C<O.length;C++){const M=O[C],B=H[C];j.push(M.id);const te=((p=M.ial)==null?void 0:p[Te])||"";if(te!==B&&(c(M.id,{[Te]:B},{[Te]:te}),M.ial||(M.ial={}),M.ial[Te]=B),M.children&&M.children.length>0)for(const V of M.children)V.ial||(V.ial={}),V.ial[Te]!==B&&(V.ial[Te]=B)}if(k!=null&&k.itemIds){for(const C of k.itemIds)if(!j.includes(C)){c(C,{[Te]:""});const M=t.find(B=>B.id===C);M&&(M.ial||(M.ial={}),M.ial[Te]="")}}n.push({superBlockId:w.id,nestedSuperBlockIds:(d=$.nestedSuperBlocks)==null?void 0:d.map(C=>C.id),pageTargetId:g,headerId:E,itemIds:j,layout:S?"clover":_})}else{let w=!1;const _=[];for(const P of m.blocks){const F=ut(P)?[P,...a(P.children||[])]:P.children?a(P.children):[];for(const E of F){const D=gh(E);if(D){w=!0;for(const S of D.items)_.push(S.id)}}}const O=((b=y==null?void 0:y.ial)==null?void 0:b[be])||"",H=fi(O);if(k||w&&H){c(g,{[be]:""},{[be]:O}),y&&(y.ial||(y.ial={}),y.ial[be]="");const P=k==null?void 0:k.headerId;if(P){c(P,{[Te]:""});const E=t.find(D=>D.id===P);E&&(E.ial||(E.ial={}),E.ial[Te]="")}const F=new Set([...(k==null?void 0:k.itemIds)||[],..._]);for(const E of F){c(E,{[Te]:""});const D=t.find(S=>S.id===E);D&&(D.ial||(D.ial={}),D.ial[Te]="")}}}}return{changes:i,newTracked:n}}function ut(e){if(!e)return!1;const t=(e.type||"").toLowerCase();return t==="s"||t==="sb"||t==="nodesuperblock"}function so(e){if(!ut(e))return!1;const t=(e.subType||"").toLowerCase();if(t==="col"||t==="h"||t==="horizontal")return!0;if(t==="row"||t==="v"||t==="vertical")return!1;if(e.ial){const i=(e.ial["data-sb-layout"]||e.ial.layout||"").toLowerCase();if(i==="col"||i==="h")return!0;if(i==="row"||i==="v")return!1}if(e.children&&e.children.length>0){for(const i of e.children)if(i.type==="NodeSuperBlockLayoutMarker"||i.type==="layout-marker"){const n=(i.content||i.markdown||"").trim().toLowerCase();if(n==="col"||n==="h")return!0;if(n==="row"||n==="v")return!1}}const o=(e.markdown||e.content||"").trim();return/^\{\{\{col\b/i.test(o)?!0:!/^\{\{\{row\b/i.test(o)}function qs(e){return!e||jo(e)||ut(e)||!wo(e.markdown,e.content)?!1:(e.markdown||e.content||"").replace(/!\[.*?\]\([^)]+\)/g,"").replace(/<img\b[^>]*>/gi,"").replace(/\{:[^}]*\}/g,"").trim().length<=25}function xr(e){var p;if(!e||!ut(e)||!so(e))return null;const t=Ii(e);if(!t||t.length<2)return null;const o=[];let i=!1;for(const d of t){const b=(((p=d.ial)==null?void 0:p.style)||d.style||"").trim();let m=null;if(b){const g=b.match(/calc\(\s*([\d.]+)%/i);if(g)m=parseFloat(g[1]);else{const y=b.match(/(?:^|;|\s)width:\s*([\d.]+)%/i);y&&(m=parseFloat(y[1]))}}m!==null&&!isNaN(m)&&m>0?(o.push(m),i=!0):o.push(null)}if(!i)return null;const n=t.length,s=o.reduce((d,b)=>d+(b||0),0),l=o.filter(d=>d===null).length,r=Math.max(0,100-s),a=l>0?r/l:100/n,c=o.map(d=>d!==null?d:a),u=c.reduce((d,b)=>d+b,0);if(u<=0)return null;const f=c.map(d=>d/u*100);if(f.length===2){const[d]=f;if(d>=48&&d<=52)return"1:1";if(d>=31&&d<=35)return"1:2";if(d>=65&&d<=69)return"2:1";if(d>=28&&d<=32)return"3:7";if(d>=68&&d<=72)return"7:3";if(d>=38&&d<=42)return"4:6";if(d>=58&&d<=62)return"6:4";if(d>=23&&d<=27)return"1:3";if(d>=73&&d<=77)return"3:1";const b=Math.round(d),m=100-b;return`${b}:${m}`}if(f.length===3){const[d,b,m]=f;if(d>=31&&d<=35&&b>=31&&b<=35&&m>=31&&m<=35)return"1:1:1";if(d>=23&&d<=27&&b>=48&&b<=52&&m>=23&&m<=27)return"1:2:1";if(d>=48&&d<=52&&b>=23&&b<=27&&m>=23&&m<=27)return"2:1:1";if(d>=23&&d<=27&&b>=23&&b<=27&&m>=48&&m<=52)return"1:1:2";if(d>=18&&d<=22&&b>=58&&b<=62&&m>=18&&m<=22)return"1:3:1";const g=Math.round(d),y=Math.round(b),k=100-g-y;return`${g}:${y}:${k}`}return f.map(d=>Math.round(d)).join(":")}function ro(e){if(!e||!ut(e)||!so(e))return null;const t=(e.children||[]).filter(s=>{const l=s.type||"";if(l==="NodeSuperBlockOpenMarker"||l==="NodeSuperBlockLayoutMarker"||l==="NodeSuperBlockCloseMarker"||l==="open-marker"||l==="layout-marker"||l==="close-marker")return!1;const r=(s.markdown||s.content||"").trim();return!(/^\{\{\{(?:col|row)?\s*$/i.test(r)||r==="}}}")});if(t.length<2)return null;const o=qs(t[0]),i=qs(t[t.length-1]),n=xr(e)||void 0;if(o&&!i){const s=wo(t[0].markdown,t[0].content);if(s)return{imageNode:t[0],imageUrl:s,layout:Bn,contentNodes:t.slice(1),ratio:n}}if(!o&&i){const s=wo(t[t.length-1].markdown,t[t.length-1].content);if(s)return{imageNode:t[t.length-1],imageUrl:s,layout:Ln,contentNodes:t.slice(0,t.length-1),ratio:n}}return null}function kh(e,t){const o=[];function i(n){for(const s of n){const l=ro(s);if(l){const{imageNode:r,layout:a,ratio:c}=l;r.ial||(r.ial={});const u=r.ial[be];if(u!==a){const p={blockId:r.id,layout:a,previousLayout:u,ratio:c};r.ial[be]=a,o.push(p),t&&t(p)}}s.children&&s.children.length>0&&i(s.children)}}return i(e),o}function Ii(e){return(e.children||[]).filter(t=>{const o=t.type||"";if(o==="NodeSuperBlockOpenMarker"||o==="NodeSuperBlockLayoutMarker"||o==="NodeSuperBlockCloseMarker"||o==="open-marker"||o==="layout-marker"||o==="close-marker")return!1;const i=(t.markdown||t.content||"").trim();return!(/^\{\{\{(?:col|row)?\s*$/i.test(i)||i==="}}}")})}function oc(e){if(!e)return!1;const t=(e.type||"").toLowerCase();if(t==="h"||t==="nodeheading"||/^h[1-6]$/i.test(e.subType||""))return!0;const o=(e.markdown||e.content||"").trim();return!!/^#{1,6}\s+/.test(o)}function Ko(e,t,o){let i="",n=0;const s=/<div\b([^>]*)>/gi;for(;n<e.length;){s.lastIndex=n;let l,r=!1,a=-1,c=0;for(;(l=s.exec(e))!==null;){const y=l[1].match(/\bclass=["']([^"']*)["']/i);if(y){const k=y[1];if(typeof t=="string"?k.split(/\s+/).includes(t):t.test(k)){r=!0,a=l.index,c=l[0].length;break}}}if(!r){i+=e.slice(n);break}i+=e.slice(n,a);const u=a+c;let f=1,p=-1,d=-1;const b=/<\/?div\b[^>]*>/gi;b.lastIndex=u;let m;for(;(m=b.exec(e))!==null;)if(m[0].startsWith("</")){if(f--,f===0){p=m.index,d=m.index+m[0].length;break}}else f++;if(p!==-1&&d!==-1){const g=e.slice(u,p);i+=o(g),n=d}else i+=e.slice(a,u),n=u}return i}function wh(e){const t=[];let o="",i=0;const n=/<div\b([^>]*)>/gi;for(;i<e.length;){n.lastIndex=i;let s,l=!1,r=-1,a=0;for(;(s=n.exec(e))!==null;){const m=s[1];if(/(?:\s@[a-zA-Z0-9_-]+=\s*["']|\s:[a-zA-Z0-9_-]+=\s*["']|\sv-[a-zA-Z0-9_.-]+|\shover:[a-zA-Z0-9_.-]+=\s*["']|\sgrid=["']~|\bclass=["'][^"']*\b(?:abs-br|slidev-icon-btn|grid\s+|grid$|grid-cols-|relative\b)\b[^"']*["']|\bstyle=["'][^"']*\bgrid-[^"']*["'])/i.test(m)){l=!0,r=s.index,a=s[0].length;break}}if(!l){o+=e.slice(i);break}o+=e.slice(i,r);const c=r+a;let u=1,f=-1,p=-1;const d=/<\/?div\b[^>]*>/gi;d.lastIndex=c;let b;for(;(b=d.exec(e))!==null;)if(b[0].startsWith("</")){if(u--,u===0){f=b.index,p=b.index+b[0].length;break}}else u++;if(f!==-1&&p!==-1){const m=e.slice(r,p),g=`__VUE_DIV_TOKEN_${t.length}__`;t.push(m),o+=g,i=p}else o+=e.slice(r,c),i=c}return{text:o,tokens:t}}function xh(e){const t=[];let o=e.replace(/(?:^[ \t]*(`{3,}|~{3,})[^\n\r]*\r?\n[\s\S]*?\r?\n[ \t]*\1(?=[ \t]*(?:\r?\n|$)))/gm,r=>{const a=`__CODE_TOKEN_${t.length}__`;return t.push(r),a});o=o.replace(/(`+)(?:[^\n\r`]|(?!\1)`)+?\1/g,r=>{const a=`__CODE_TOKEN_${t.length}__`;return t.push(r),a});const i=[];o=o.replace(/<script\b[^>]*>[\s\S]*?<\/script>/gi,r=>{const a=`__SCRIPT_TOKEN_${i.length}__`;return i.push(r),a});const{text:n,tokens:s}=wh(o);o=n;const l=[];o=o.replace(/<(?:[A-Z][a-zA-Z0-9_-]*|[a-z0-9_-]+:[a-z0-9_-]+|v-[a-z0-9_-]+|arrow\b|div\s+h-\d+)\b[^>]*\/>/gi,r=>{const a=`__VUE_COMP_TOKEN_${l.length}__`;return l.push(r),a}),o=o.replace(/<(v-[a-z0-9_-]+|button)\b([^>]*)>([\s\S]*?)<\/\1>/gi,r=>{const a=`__VUE_COMP_TOKEN_${l.length}__`;return l.push(r),a}),o=o.replace(/<img\b[^>]*?\bv-[a-z0-9_.-]+[^>]*\/?>/gi,r=>{const a=`__VUE_COMP_TOKEN_${l.length}__`;return l.push(r),a}),o=o.replace(/<(p|span)\b([^>]*?\bv-[a-z0-9_.-]+[^>]*)>([\s\S]*?)<\/\1>/gi,r=>{const a=`__VUE_COMP_TOKEN_${l.length}__`;return l.push(r),a}),o=o.replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi,""),o=o.replace(/<div class="terminal-bar">[\s\S]*?<\/div>/gi,""),o=o.replace(/<div class="cursor-line">[\s\S]*?<\/div>/gi,""),o=o.replace(/<span class="cursor">[\s\S]*?<\/span>/gi,""),o=o.replace(/<div class="stamp">\s*([\s\S]*?)\s*<\/div>/gi,`

*[$1]*

`),o=o.replace(/<div class="arrow">\s*([→\->]+)\s*<\/div>/gi,`

$1

`),o=o.replace(/<i>\s*[→\->]+\s*<\/i>/gi,""),o=o.replace(/<div class="prompt">\s*([\s\S]*?)\s*<\/div>/gi,(r,a)=>`
\`\`\`bash
${a.trim()}
\`\`\`
`),o=o.replace(/<p>\s*<i>\$<\/i>\s*([\s\S]*?)<\/p>/gi,(r,a)=>`
\`\`\`bash
$ ${a.trim()}
\`\`\`
`),o=o.replace(/<div class="statusline">\s*([\s\S]*?)\s*<\/div>/gi,(r,a)=>`
> ${Array.from(a.matchAll(/<span>([\s\S]*?)<\/span>/gi)).map(u=>`\`${u[1].trim()}\``).join(" | ")}
`),o=o.replace(/<div class="log-panel">\s*<pre>([\s\S]*?)<\/pre>\s*<\/div>/gi,(r,a)=>`
\`\`\`log
${a.replace(/<span[^>]*>([\s\S]*?)<\/span>/gi,"$1").trim()}
\`\`\`
`),o=Ko(o,"diff-grid",r=>{const a=Array.from(r.matchAll(/<div class="diff\s+([^"]*)">\s*<span>(.*?)<\/span>\s*<pre>([\s\S]*?)<\/pre>\s*<\/div>/gi));return a.length>0?`
`+a.map(c=>{const u=c[2].trim().toUpperCase(),f=c[3].trim();return`**${u}:**
\`\`\`yaml
${f}
\`\`\``}).join(`

`)+`
`:r}),o=Ko(o,"before-after",r=>{const a=r.match(/<div class="before">[\s\S]*?<small>(.*?)<\/small>[\s\S]*?<h2>(.*?)<\/h2>[\s\S]*?<p>(.*?)<\/p>\s*<\/div>/i),c=r.match(/<div class="after">[\s\S]*?<small>(.*?)<\/small>[\s\S]*?<h2>(.*?)<\/h2>[\s\S]*?<p>(.*?)<\/p>\s*<\/div>/i);let u=`
`;return a&&(u+=`### ${a[1]}
## ${a[2]}
${a[3]}

`),c&&(u+=`### ${c[1]}
## ${c[2]}
${c[3]}
`),u.trim()?u:r}),o=o.replace(/<ul\b[^>]*>([\s\S]*?)<\/ul>/gi,(r,a)=>{const c=Array.from(a.matchAll(/<li>\s*(?:<em>)?(\[[x ]\])(?:<\/em>)?\s*([\s\S]*?)<\/li>/gi));return c.length>0?`
`+c.map(u=>`- ${u[1]} ${u[2].trim()}`).join(`
`)+`
`:a}),o=Ko(o,"timeline",r=>{const a=Array.from(r.matchAll(/<div(?:\s+class="([^"]*)")?>\s*<time>([\s\S]*?)<\/time>\s*<b>([\s\S]*?)<\/b>\s*<span>([\s\S]*?)<\/span>\s*<\/div>/gi));return a.length>0?`

`+a.map(c=>{const u=c[1]||"";let f="-";return u.includes("warn")?f="- ⚠️":u.includes("bad")?f="- ❌":u.includes("ok")&&(f="- ✅"),`${f} **${c[2].trim()}** **${c[3].trim()}** — ${c[4].trim()}`}).join(`
`)+`

`:r}),o=Ko(o,"pipeline",r=>{const a=Array.from(r.matchAll(/<div(?:\s+class="([^"]*)")?>\s*<small>([\s\S]*?)<\/small>\s*<b>([\s\S]*?)<\/b>\s*<span>([\s\S]*?)<\/span>\s*<\/div>/gi));return a.length>0?`

`+a.map((c,u)=>{const p=(c[1]||"").includes("hot")?"⚠️ ":"";return`${u+1}. ${p}**${c[3].trim()}** (*${c[4].trim()}*)`}).join(`
`)+`

`:r}),o=Ko(o,"check-grid",r=>{const a=Array.from(r.matchAll(/<div>\s*<span class="([^"]*)"><\/span>\s*<b>([\s\S]*?)<\/b>\s*<p>([\s\S]*?)<\/p>\s*<\/div>/gi));return a.length>0?`

`+a.map(c=>`- ${(c[1]||"").includes("warn")?"⚠️":"✅"} **${c[2].trim()}**: ${c[3].trim()}`).join(`
`)+`

`:r}),o=Ko(o,"manifesto",r=>{const a=Array.from(r.matchAll(/<div>\s*<span>([\s\S]*?)<\/span>\s*<h2>([\s\S]*?)<\/h2>\s*<p>([\s\S]*?)<\/p>\s*<\/div>/gi));return a.length>0?`

`+a.map(c=>`## ${c[1].trim()} ${c[2].trim()}

${c[3].trim()}`).join(`

`)+`

`:r}),o=Ko(o,"split-note",r=>{const a=Array.from(r.matchAll(/<div>\s*<b>([\s\S]*?)<\/b>\s*<p>([\s\S]*?)<\/p>\s*<\/div>/gi));return a.length>0?`

`+a.map(c=>`> **${c[1].trim()}**: ${c[2].trim()}`).join(`
>
`)+`

`:r}),o=o.replace(/<div class="mechanism">\s*<b>([\s\S]*?)<\/b>\s*<p>([\s\S]*?)<\/p>\s*<\/div>/gi,(r,a,c)=>`

> **${a.trim()}**: ${c.trim()}

`),o=o.replace(/<pre>([\s\S]*?)<\/pre>/gi,(r,a)=>`
\`\`\`text
${a.replace(/<span[^>]*>([\s\S]*?)<\/span>/gi,"$1").trim()}
\`\`\`
`),o=o.replace(/<div class="page-head">\s*<span>([\s\S]*?)<\/span>\s*<b>([\s\S]*?)<\/b>\s*<\/div>/gi,`
### $1 ($2)
`),o=o.replace(/<h1\b[^>]*>([\s\S]*?)<\/h1>/gi,`
# $1
`),o=o.replace(/<h2\b[^>]*>([\s\S]*?)<\/h2>/gi,`
## $1
`),o=o.replace(/<h3\b[^>]*>([\s\S]*?)<\/h3>/gi,`
### $1
`),o=o.replace(/<h4\b[^>]*>([\s\S]*?)<\/h4>/gi,`
#### $1
`),o=o.replace(/<p\s+class="ok">\s*●\s*([\s\S]*?)<\/p>/gi,`
✅ **$1**
`),o=o.replace(/<p\s+class="caption">\s*([\s\S]*?)<\/p>/gi,`
> *$1*
`),o=o.replace(/<p\s+class="lead">\s*([\s\S]*?)<\/p>/gi,`
*$1*
`),o=o.replace(/<p\b([^>]*)>([\s\S]*?)<\/p>/gi,(r,a,c)=>/@|v-|:|class=/i.test(a)?r:`
${c.trim()}

`),o=o.replace(/<br\s*\/?>/gi,`
`),o=o.replace(/<hr\s*\/?>/gi,`
---
`),o=o.replace(/<b\b[^>]*>([\s\S]*?)<\/b>/gi,"**$1**"),o=o.replace(/<strong\b[^>]*>([\s\S]*?)<\/strong>/gi,"**$1**"),o=o.replace(/<i\b[^>]*>([\s\S]*?)<\/i>/gi,"*$1*"),o=o.replace(/<code\b[^>]*>([\s\S]*?)<\/code>/gi,(r,a)=>{if(a.startsWith("`")&&a.endsWith("`"))return a;if(a.includes("`")){const c=(a.match(/`+/g)||[]).reduce((f,p)=>Math.max(f,p.length),0),u="`".repeat(c+1);return`${u} ${a} ${u}`}return`\`${a}\``}),o=o.replace(/<small\b[^>]*>([\s\S]*?)<\/small>/gi,"*$1*"),o=o.replace(/\*{4}/g,"** **"),o=o.replace(/<li\b[^>]*>([\s\S]*?)<\/li>/gi,`- $1
`),o=o.replace(/<ul\b[^>]*>([\s\S]*?)<\/ul>/gi,`
$1
`),o=o.replace(/<ol\b[^>]*>([\s\S]*?)<\/ol>/gi,`
$1
`),o=o.replace(/<a\b([^>]*)href=["'](.*?)["']([^>]*)>([\s\S]*?)<\/a>/gi,(r,a,c,u,f)=>{const p=f.trim();return p.includes("<")||p.includes(`
`)?r:`[${p}](${c})`}),o=o.replace(/<blockquote\b[^>]*>([\s\S]*?)<\/blockquote>/gi,(r,a)=>`
`+a.trim().split(`
`).map(c=>`> ${c.trim()}`).join(`
`)+`
`),o=o.replace(/<span\b[^>]*data-type=["']block-ref["'][^>]*data-id=["']([0-9a-zA-Z-]+)["'][^>]*>([\s\S]*?)<\/span>/gi,(r,a,c)=>{const u=c.replace(/<[^>]+>/g,"").trim();return u?`((${a} '${u}'))`:`((${a}))`}),o=o.replace(/<span\b[^>]*data-type=["']a["'][^>]*data-href=["']([^"']+)["'][^>]*>([\s\S]*?)<\/span>/gi,(r,a,c)=>`[${c.replace(/<[^>]+>/g,"").trim()}](${a})`),o=o.replace(/<\/(?:div|section|header|footer|main|article|nav|aside)\b[^>]*>/gi,`
`),o=o.replace(/<(?:div|section|header|footer|main|article|nav|aside)\b[^>]*>/gi,""),o=o.replace(/<\/?span\b[^>]*>/gi,"");for(let r=0;r<l.length;r++)o=o.replace(`__VUE_COMP_TOKEN_${r}__`,()=>l[r]);for(let r=0;r<s.length;r++)o=o.replace(`__VUE_DIV_TOKEN_${r}__`,()=>s[r]);for(let r=0;r<i.length;r++)o=o.replace(`__SCRIPT_TOKEN_${r}__`,()=>i[r]);for(let r=0;r<t.length;r++)o=o.replace(`__CODE_TOKEN_${r}__`,()=>t[r]);return o=o.replace(/\n{3,}/g,`

`).trim(),o}function ic(e){if(!e||typeof e!="string")return"";const t=[];let o=e.replace(/`([^`]+)`/g,i=>(t.push(i),`%%INLINE_CODE_${t.length-1}%%`));return o=o.replace(/(<\/[a-zA-Z0-9_-]+>)\s*\{:[^}]*\}/g,"$1"),o=o.replace(/(\[[^\]]+\]\([^)]+\))\s*\{:\s*style=["']([^"']*)["'][^}]*\}/g,'<span style="$2">$1</span>'),o=o.replace(/(\*\*[^*]+\*\*)\s*\{:\s*style=["']([^"']*)["'][^}]*\}/g,'<span style="$2">$1</span>'),o=o.replace(/(\*[^*]+\*)\s*\{:\s*style=["']([^"']*)["'][^}]*\}/g,'<span style="$2">$1</span>'),o=o.replace(/(~~[^~]+~~)\s*\{:\s*style=["']([^"']*)["'][^}]*\}/g,'<span style="$2">$1</span>'),o=o.replace(/([\p{L}\p{N}_\-]+)\s*\{:\s*style=["']([^"']*)["'][^}]*\}/gu,'<span style="$2">$1</span>'),o=o.replace(/\{:[^}]*\}/g,""),o=o.replace(/%%INLINE_CODE_(\d+)%%/g,(i,n)=>t[parseInt(n,10)]||""),o}function Vs(e){if(!e)return"";const t=e.trim();return t?/^\d+$/.test(t)?`${t}px`:/^(\d+(?:\.\d+)?)%$/.test(t)?`${t.slice(0,-1)}cqh`:/^(\d+(?:\.\d+)?)vh$/.test(t)?`${t.slice(0,-2)}cqh`:t:""}function Sr(e){if(!e)return"";let t=e.trim();t=t.replace(/\{:[^}]*\}/g,"").trim(),t=t.replace(/^:::\s*[a-zA-Z0-9_-]*\s*\r?\n?/g,""),t=t.replace(/\r?\n?:::\s*$/g,"");let n=t.split(/\r?\n/).map(s=>s.trim().replace(/^>\s*/,"")).join(`
`).trim();return n=n.replace(/^\[!(?:NOTE|TIP|IMPORTANT|WARNING|CAUTION|[A-Za-z_-]+)\][^\r\n]*(?:\r?\n)?/i,"").trim(),n=n.replace(/^(?:💡|✏️|❗|⚠️|🚨|\s*)*(?:\*\*|__)?(?:演讲备注|演讲者提词|讲稿备注|演讲提词|备注|Notes?)(?:\*\*|__)?[:：]?\s*(?:\r?\n)?/i,"").trim(),n=n.replace(/^[-*+]\s+/,""),n=n.replace(/^\d+\.\s+/,""),n.trim()}function Sh(e){var i;if(e.subType&&/^h([1-6])$/i.test(e.subType))return parseInt(e.subType.slice(1),10);const o=(e.markdown||e.content||"").trim().match(/^(#{1,6})\s+/);return o?o[1].length:e.type==="h"?(i=e.ial)!=null&&i.subType&&/^h([1-6])$/i.test(e.ial.subType)?parseInt(e.ial.subType.slice(1),10):1:null}function Ks(e,t=2){const o=Math.max(2,t);if(!e||e.length===0)return Array.from({length:o},()=>[]);if(e.length===1&&e[0].children&&e[0].children.length>=2){const c=e[0].children,u=Array.from({length:o},()=>[]),f=Math.min(o,c.length),p=Math.floor(c.length/f),d=c.length%f;let b=0;for(let m=0;m<f;m++){const g=p+(m<d?1:0);u[m]=c.slice(b,b+g),b+=g}return u}if(e.length===1){const c=e[0],f=(c.slot||"").trim().match(/^col-(\d+)$/i),p=f?parseInt(f[1],10):null,d=(c.rawMarkdown||c.content||"").trim(),b=d.split(/\r?\n/),m=[];for(let k=0;k<b.length;k++)/^[ \t]*[-*+]\s+|^[ \t]*\d+\.\s+/.test(b[k])&&m.push(k);if(m.length>=o){const k=Array.from({length:o},()=>[]);let x=0;for(let $=0;$<o;$++){const A=o-$,w=m.length-x,_=Math.ceil(w/A),O=m[x],H=x+_<m.length?m[x+_]:b.length,P=b.slice(O,H).join(`
`);k[$]=[{...c,id:$===0?c.id:`${c.id}-col${$+1}`,rawMarkdown:P,content:P}],x+=_}return k}const g=d.match(/<li[\s\S]*?<\/li>/gi);if(g&&g.length>=o){const k=Array.from({length:o},()=>[]);let x=0;for(let $=0;$<o;$++){const A=o-$,w=g.length-x,_=Math.ceil(w/A),O=`<ul>
${g.slice(x,x+_).join(`
`)}
</ul>`;k[$]=[{...c,id:$===0?c.id:`${c.id}-col${$+1}`,rawMarkdown:O,content:O}],x+=_}return k}const y=d.split(/\r?\n\s*\r?\n/).filter(k=>k.trim()!=="");if(y.length>=o){const k=Array.from({length:o},()=>[]);let x=0;for(let $=0;$<o;$++){const A=o-$,w=y.length-x,_=Math.ceil(w/A),O=y.slice(x,x+_).join(`

`);k[$]=[{...c,id:$===0?c.id:`${c.id}-col${$+1}`,rawMarkdown:O,content:O}],x+=_}return k}if(p&&p>=1&&p<=o){const k=Array.from({length:o},()=>[]);return k[p-1]=[c],k}return[[c],...Array.from({length:o-1},()=>[])]}const i=c=>{const u=(c.slot||"").trim();if(!u)return null;if(u==="left")return 1;if(u==="center")return 2;if(u==="right")return o===2?2:o;const f=u.match(/^col-(\d+)$/i);if(f){const p=parseInt(f[1],10);if(p>=1&&p<=o)return p}return null},n=e.map(i);if(n.some(c=>c!==null)){if(n.some(d=>d!==null&&d>=2)){const d=Array.from({length:o},()=>[]);let b=1;for(const g of e){const y=i(g);y!==null&&(b=y),d[b-1].push(g)}if(!e.some(g=>/^col-\d+$/i.test((g.slot||"").trim()))&&d[0].length===0){const g=d.filter(y=>y.length>0);if(g.length===1)return[g[0],...Array.from({length:o-1},()=>[])]}return d}const u=e.filter(d=>i(d)===1),f=e.filter(d=>i(d)===null),p=o-1;if(f.length>=p){const d=Math.floor(f.length/p),b=f.length%p,m=[u];let g=0;for(let y=0;y<p;y++){const k=d+(y<b?1:0);m.push(f.slice(g,g+k)),g+=k}return m}else if(f.length>0){const d=[u];for(let b=0;b<p;b++)d.push(b<f.length?[f[b]]:[]);return d}else return[u,...Array.from({length:p},()=>[])]}const l=c=>{if(c.type==="h"||c.subType&&/^h[1-6]$/i.test(c.subType))return!0;const u=(c.rawMarkdown||c.content||"").trim();return/^#{1,6}\s+/.test(u)},r=e.map((c,u)=>l(c)?u:-1).filter(c=>c!==-1);if(r.length>=o){const c=Array.from({length:o},()=>[]);for(let u=0;u<o;u++){const f=r[u],p=u+1<o?r[u+1]:e.length;c[u]=e.slice(f,p)}return c}if(e.length>=o){const c=Array.from({length:o},()=>[]);let u=0;for(let f=0;f<o;f++){const p=o-f,d=e.length-u,b=Math.ceil(d/p);c[f]=e.slice(u,u+b),u+=b}return c}if(e.length>1&&e.length<o){const c=Array.from({length:o},()=>[]);for(let u=0;u<e.length;u++)c[u]=[e[u]];return c}const a=Array.from({length:o},()=>[]);return a[0]=e,a}function vl(e,t,o,i){const n=ph(t),s=[],l=yl(t),r=n.background?Dt(n.background,i):void 0;let a={pageIndex:1,startBlockId:e,frontmatter:{layout:l.frontmatter.layout||"cover",...l.frontmatter,...r?{background:r}:{}},notes:"",noteBlocks:[],blocks:[],rawMarkdown:"",allBlockIds:[e]};a.frontmatter.background&&(a.frontmatter.background=Dt(a.frontmatter.background,i)),a.frontmatter.image&&(a.frontmatter.image=Dt(a.frontmatter.image,i));const c=d=>{const b=[];for(let m=d;m<o.length&&!(m>d&&bo(o[m]));m++)b.push(o[m]);return b},u=d=>{let b,m,g;const y=k=>{var _;if(b)return;const x=ro(k);if(x){b=x.layout,m=x.imageUrl,g=x.ratio;return}const $=Or(k),A=k.ial?{...k.ial}:{},w=bl(A);if(w.imageLayout==="image-left"||w.imageLayout==="image-right"){const O=wo($,k.content);if(O){b=w.imageLayout,m=O,g=(_=k.ial)==null?void 0:_[yt];return}}if(k.children&&k.children.length>0){for(const O of k.children)if(y(O),b)return}};for(const k of d)if(y(k),b)break;return{foundLayout:b,foundImage:m,foundRatio:g}},f=(d,b)=>{const{foundLayout:m,foundImage:g,foundRatio:y}=u(b);m&&(d.frontmatter.layout=m,g&&(d.frontmatter.image=Dt(g,i)),y&&!d.frontmatter.layoutRatio&&(d.frontmatter.layoutRatio=y))};f(a,c(0)),s.push(a);let p=[];for(let d=0;d<o.length;d++){const b=o[d];if(bo(b)){p=[];const g=yl(b.ial);if(s.length===1&&a.blocks.length===0){a.startBlockId=b.id,a.allBlockIds||(a.allBlockIds=[]),a.allBlockIds.includes(b.id)||a.allBlockIds.push(b.id),g.frontmatter.layout&&(a.frontmatter.layout=g.frontmatter.layout),Object.assign(a.frontmatter,g.frontmatter),delete a.frontmatter.background,!g.frontmatter.image&&l.frontmatter.image&&(a.frontmatter.image=l.frontmatter.image),r&&(a.frontmatter.background=r),a.frontmatter.background&&(a.frontmatter.background=Dt(a.frontmatter.background,i)),a.frontmatter.image&&(a.frontmatter.image=Dt(a.frontmatter.image,i)),f(a,c(d+1));continue}a={pageIndex:s.length+1,startBlockId:b.id,frontmatter:{layout:g.frontmatter.layout||"default",...g.frontmatter,...r?{background:r}:{}},notes:"",noteBlocks:[],blocks:[],rawMarkdown:"",allBlockIds:[b.id]},r||delete a.frontmatter.background,a.frontmatter.background&&(a.frontmatter.background=Dt(a.frontmatter.background,i)),a.frontmatter.image&&(a.frontmatter.image=Dt(a.frontmatter.image,i)),f(a,c(d+1)),s.push(a);continue}const m=(g,y)=>{var ae,oe,re,Se,$e,ke,_e;if(a.allBlockIds||(a.allBlockIds=[]),g.id&&!a.allBlockIds.includes(g.id)&&a.allBlockIds.push(g.id),g.children&&g.children.length>0){const R=ne=>{for(const L of ne)L.id&&!a.allBlockIds.includes(L.id)&&a.allBlockIds.push(L.id),L.children&&L.children.length>0&&R(L.children)};R(g.children)}let k=Or(g),x=g.ial?{...g.ial}:{};const $=k.match(/\{:\s*([^}]+)\s*\}\s*$/);$&&(x={...Ul($[0]),...x},k=k.slice(0,$.index).trim()),g.type!=="c"&&!k.startsWith("```")&&(k=ic(k));let A=k.trim();if(/^\{\{\{(?:row|col)?\s*$/i.test(A)||A==="}}}")return;/^\{\{\{(?:row|col)?\s*\r?\n/i.test(A)&&/\r?\n\}\}\}$/.test(A)&&(k=A.replace(/^\{\{\{(?:row|col)?\s*\r?\n/i,"").replace(/\r?\n\}\}\}$/,"").trim(),A=k.trim());const w=bl(x);if(k=Pd(k,i),k=Od(k,i==null?void 0:i.refContentMap),g.children&&g.children.length>0){const R=["custom-slides-autoplay","custom-slides-loop","custom-slides-muted","custom-slides-controls"],ne=L=>{for(const U of L){if(U.ial)for(const[v,W]of Object.entries(U.ial))R.includes(v)&&!x[v]&&(x[v]=W);U.children&&U.children.length>0&&ne(U.children)}};ne(g.children)}const _=g.type==="video"||g.type==="NodeVideo"||/<video\b/i.test(k);if(_){const R=x["custom-slides-autoplay"]==="true",ne=x["custom-slides-loop"]==="true",L=x["custom-slides-muted"]==="true"||R,U=x["custom-slides-controls"]==="false";k=k.replace(/<video\b([^>]*)>/gi,(v,W)=>{let z=W;return U?z=z.replace(/\bcontrols(?:="[^"]*")?/gi,"").trim():/controls/i.test(z)||(z+=" controls"),R&&!/autoplay/i.test(z)?z+=" autoplay playsinline":!R&&x["custom-slides-autoplay"]==="false"&&(z=z.replace(/\bautoplay\b/gi,"").replace(/\bplaysinline\b/gi,"").trim()),ne&&!/loop/i.test(z)?z+=" loop":!ne&&x["custom-slides-loop"]==="false"&&(z=z.replace(/\bloop\b/gi,"").trim()),L&&!/muted/i.test(z)?z+=" muted":!L&&x["custom-slides-muted"]==="false"&&(z=z.replace(/\bmuted\b/gi,"").trim()),`<video ${z.trim()}>`})}if(w.isBackground){const R=wo(k,g.content);if(R){a.frontmatter.background=Dt(R,i);return}}const O=ro(g);if(O){a.frontmatter.layout=O.layout,a.frontmatter.image=Dt(O.imageUrl,i),!a.frontmatter.layoutRatio&&O.ratio&&(a.frontmatter.layoutRatio=O.ratio);for(const R of O.contentNodes)m(R);return}if(w.imageLayout==="image-left"||w.imageLayout==="image-right"){const R=wo(k,g.content);if(R){a.frontmatter.layout=w.imageLayout,a.frontmatter.image=Dt(R,i),!a.frontmatter.layoutRatio&&((ae=g.ial)!=null&&ae[yt])&&(a.frontmatter.layoutRatio=g.ial[yt]);return}}if(ut(g)&&g.children&&g.children.length>0){for(const R of g.children)m(R);return}const H=!!(w.slot||y!=null&&y.defaultSlot||a.frontmatter.layout==="clover"||fi(a.frontmatter.layout)||a.frontmatter.layout==="two-cols"),P=!!(g.children&&g.children.some(R=>{var ne,L;return((ne=R.ial)==null?void 0:ne[Te])||((L=R.ial)==null?void 0:L[Oe])||R.children&&R.children.length>=2||R.children&&R.children.some(U=>{var v,W,z,I,T,N;return((v=U.ial)==null?void 0:v[Oe])||((W=U.ial)==null?void 0:W[Te])||((z=U.ial)==null?void 0:z[Ye])||((I=U.ial)==null?void 0:I[be])||((T=U.ial)==null?void 0:T["custom-slides-role"])||((N=U.ial)==null?void 0:N["custom-slides-layout"])})}));if((g.type==="l"||g.type==="NodeList"||g.type==="list")&&g.children&&g.children.length>0&&(P||w.slot||w.clicks||H)){const R=/^\s*\d+\.\s+/m.test(g.markdown||"")||g.subType==="o"||g.subtype==="o";for(let ne=0;ne<g.children.length;ne++){const L=g.children[ne];w.slot&&(!L.ial||!L.ial[Te])&&(L.ial||(L.ial={}),L.ial[Te]=w.slot),m(L,{...y,parentClicks:w.clicks||(y==null?void 0:y.parentClicks),defaultSlot:w.slot||(y==null?void 0:y.defaultSlot),isParentListUnpacked:!0,isListItem:!0,listContext:{isOrdered:R,itemIndex:ne+1}})}return}const F=!!(y!=null&&y.isParentListUnpacked),E=!!(g.children&&g.children.length>=2)||!!w.clicks||!!((oe=g.children)!=null&&oe.some(R=>{var ne;return(ne=R.ial)==null?void 0:ne[Oe]}))||F||!g.markdown&&!!(g.children&&g.children.length>0);if(jo(g)&&g.children&&g.children.length>0&&(H||F||w.clicks||g.children.some(R=>{var ne;return(ne=R.ial)==null?void 0:ne[Oe]}))&&E){const R=!!(g.children&&g.children.length>=2),ne=g.children.find(T=>!!(T.markdown||T.content||"").trim())||g.children[0],L=((re=ne==null?void 0:ne.ial)==null?void 0:re[Oe])||((Se=ne==null?void 0:ne.ial)==null?void 0:Se["custom-slides-click"]),U=!!(!w.clicks&&R&&L),v=w.clicks||(U?L:void 0)||(y==null?void 0:y.parentClicks),W=g.id||(y==null?void 0:y.parentContainerId),z=w.slot||(y==null?void 0:y.defaultSlot);let I=!0;for(const T of g.children){z&&(!T.ial||!T.ial[Te])&&(T.ial||(T.ial={}),T.ial[Te]=z);const N=!!(T.markdown||T.content||"").trim(),Y=I&&N;if(Y){if(!(a.frontmatter.layout==="image-right"||a.frontmatter.layout==="image-left")&&!!(a.frontmatter.layout==="clover"||fi(a.frontmatter.layout)||a.frontmatter.layout==="two-cols")&&!!(y!=null&&y.defaultSlot||w.slot||($e=g.ial)!=null&&$e[Te]))T.markdown&&(T.markdown=ji(T.markdown)),T.content&&(T.content=ji(T.content));else{const se=!!((ke=y==null?void 0:y.listContext)!=null&&ke.isOrdered),me=((_e=y==null?void 0:y.listContext)==null?void 0:_e.itemIndex)||1,Ce=se?`${me}. `:"- ",we=De=>{if(!De)return Ce.trim();const He=De.trim();return/^[-*+]\s+/.test(He)||/^\d+\.\s+/.test(He)?De:`${Ce}${De}`};T.markdown&&(T.markdown=we(T.markdown)),T.content&&(T.content=we(T.content))}I=!1}let G=T;Y&&v&&R?(G={...T,ial:{...T.ial||{}}},delete G.ial[Oe],delete G.ial["custom-slides-click"]):!R&&v&&(G={...T,ial:{...T.ial||{},[Oe]:v}}),m(G,{...y,parentClicks:v,parentContainerId:W,defaultSlot:z,isListItem:!0})}return}if(w.isNote){const R=Sr(k);R&&(a.notes?a.notes+=`

`+R:a.notes=R),a.noteBlocks||(a.noteBlocks=[]),a.noteBlocks.push({id:g.id,type:g.type,content:R||g.content||"",rawMarkdown:k,isNote:!0,attributes:g.ial});return}A=k.trim();const D=(g.content||"").trim();if(A==="::right::"||D==="::right::"||/^<p>\s*::right::\s*<\/p>$/i.test(A)||A.startsWith("::right::")){a.blocks.push({id:g.id,type:g.type,content:"::right::",rawMarkdown:"::right::",slot:"slot-divider-right",attributes:g.ial});return}const q=Sh(g);let j=w.slot,C=w.clicks,M=w.motion,B={...g.ial||{}};if(q!==null){for(;p.length>0&&p[p.length-1].level>=q;)p.pop();const R=p.length>0?p[p.length-1]:void 0;!j&&(R!=null&&R.slot)&&(j=R.slot),!C&&(R!=null&&R.clicks)&&!(y!=null&&y.parentContainerId)&&(C=R.clicks),!M&&(R!=null&&R.motion)&&(M=R.motion);const ne={...(R==null?void 0:R.customAttrs)||{}};if(g.ial)for(const[L,U]of Object.entries(g.ial))L.startsWith("custom-slides-")&&!L.startsWith("custom-slides-slide")&&(ne[L]=U);y!=null&&y.parentContainerId||p.push({level:q,slot:j,clicks:C,motion:M,customAttrs:ne})}else{const R=p.length>0?p[p.length-1]:void 0;R&&(!j&&R.slot&&R.slot!=="header"&&(j=R.slot),!C&&R.clicks&&!(y!=null&&y.parentContainerId)&&(C=R.clicks),!M&&R.motion&&(M=R.motion),R.customAttrs&&(B={...R.customAttrs,...B}))}!j&&a.blocks.some(R=>R.slot==="slot-divider-right")&&(j="right"),!j&&(y!=null&&y.defaultSlot)&&(j=y.defaultSlot),j&&(B[Te]=j),C&&!B[Oe]&&(B[Oe]=C),M&&!B[Mt]&&(B[Mt]=JSON.stringify(M)),(_||x["custom-slides-autoplay"]||x["custom-slides-muted"])&&(x["custom-slides-autoplay"]&&(B["custom-slides-autoplay"]=x["custom-slides-autoplay"],x["custom-slides-autoplay"]==="true"&&!x["custom-slides-muted"]&&(B["custom-slides-muted"]="true")),x["custom-slides-loop"]&&(B["custom-slides-loop"]=x["custom-slides-loop"]),x["custom-slides-muted"]&&(B["custom-slides-muted"]=x["custom-slides-muted"]),x["custom-slides-controls"]&&(B["custom-slides-controls"]=x["custom-slides-controls"]));const te=w.maxHeight?Vs(w.maxHeight):void 0,V=!!(y!=null&&y.isListItem||jo(g)),K={id:g.id,type:g.type,content:g.content||"",rawMarkdown:k,clicks:C,parentClicks:y==null?void 0:y.parentClicks,parentContainerId:y==null?void 0:y.parentContainerId,motion:M,shikiLines:w.shikiLines,maxHeight:te,slot:j,attributes:B,attrs:B,rawNode:g,isListItem:V};a.blocks.push(K)};m(b)}for(let d=0;d<s.length;d++){const b=s[d],m=b.blocks.filter(k=>k.slot!=="slot-divider-right"),g=k=>{const x=k.filter(_=>!!(_.rawMarkdown||_.content||"").trim());if(x.length===0)return;const $=x[0],A=($.rawMarkdown||$.content||"").trim();(jo($)||/^(?:[-*+]|\d+\.)\s+/.test(A))&&($.rawMarkdown=ji($.rawMarkdown||$.content||""),$.content=$.rawMarkdown)},y=b.frontmatter.layout||"default";if(y==="clover"||fi(y)){let k=[];const x=m.filter(O=>O.slot==="header");if(x.length>0)k=x;else if(m.length>0){const O=m.find(H=>H.type==="h"&&(!H.slot||H.slot==="default"));O&&(k=[O])}const $=m.filter(O=>!k.includes(O));let A=2;if(y==="clover")A=4;else if(y==="three-cols-header")A=3;else if(y==="two-cols-header")A=2;else{let O=0;for(const H of $){const P=(H.slot||"").match(/^col-(\d+)$/i);P&&(O=Math.max(O,parseInt(P[1],10)))}if(O>=2)A=O;else if(b.frontmatter.layoutRatio){const H=b.frontmatter.layoutRatio.trim();if(H.includes(":")){const P=H.split(":").map(F=>parseFloat(F.trim())).filter(F=>!isNaN(F)&&F>0);P.length>=2&&(A=P.length)}else{const P=H.split(/\s+/).filter(Boolean);P.length>=2&&(A=P.length)}}else $.length===1&&$[0].children&&$[0].children.length>=2&&(A=Math.min(6,$[0].children.length))}const w=Ks($,A);w.forEach((O,H)=>{const P=`col-${H+1}`;for(const F of O)(!F.slot||F.slot==="default")&&(F.slot=P);g(O)});const _=w.flat();if($.length===1&&_.length>1){const O=b.blocks.findIndex(H=>H.id===$[0].id);O!==-1&&b.blocks.splice(O,1,..._)}}else if(y==="two-cols"){const k=m.filter($=>$.slot==="right"),x=m.filter($=>!$.slot||$.slot==="default");if(k.length===0&&x.length>=2){const[,$]=Ks(x,2);for(const A of $)A.slot="right"}g(m.filter($=>$.slot!=="right")),g(m.filter($=>$.slot==="right"))}b.rawMarkdown=b.blocks.filter(k=>k.slot!=="slot-divider-right").map(k=>k.rawMarkdown||k.content||"").filter(Boolean).join(`

`).trim()}return{docId:e,config:n,slides:s}}const kl=`/* SiYuan Note Built-in Font & Background Styles for Slidev */
:root,
html:not(.dark),
[data-theme="light"],
[data-theme-mode="light"] {
  /* 思源基础卡片与主题色 (浅色模式 daylight) */
  --b3-card-error-color: #790600;
  --b3-card-error-background: #f5d1cf;
  --b3-card-warning-color: #8a4f00;
  --b3-card-warning-background: #ffe8c8;
  --b3-card-info-color: #005599;
  --b3-card-info-background: #d6eaf9;
  --b3-card-success-color: #006b04;
  --b3-card-success-background: #d7eed8;

  --b3-theme-primary: #3575f0;
  --b3-theme-secondary: #ff9200;
  --b3-theme-error: #d23f31;
  --b3-theme-background: #ffffff;
  --b3-theme-on-background: #222222;
  --b3-theme-on-surface: #5f6368;
  --b3-theme-surface-lighter: #e0e0e0;

  /* 13 种内置文字颜色 */
  --b3-font-color1: var(--b3-card-error-color);
  --b3-font-color2: var(--b3-card-warning-color);
  --b3-font-color3: var(--b3-card-info-color);
  --b3-font-color4: var(--b3-card-success-color);
  --b3-font-color5: var(--b3-theme-on-surface);
  --b3-font-color6: var(--b3-theme-primary);
  --b3-font-color7: var(--b3-theme-secondary);
  --b3-font-color8: var(--b3-theme-error);
  --b3-font-color9: #a40074;
  --b3-font-color10: #007080;
  --b3-font-color11: #006e2a;
  --b3-font-color12: #6b5a00;
  --b3-font-color13: var(--b3-theme-background);

  /* 13 种内置背景颜色 */
  --b3-font-background1: var(--b3-card-error-background);
  --b3-font-background2: var(--b3-card-warning-background);
  --b3-font-background3: var(--b3-card-info-background);
  --b3-font-background4: var(--b3-card-success-background);
  --b3-font-background5: #e2e3e4;
  --b3-font-background6: #acd0fc;
  --b3-font-background7: #fddaab;
  --b3-font-background8: #ffb0a9;
  --b3-font-background9: #fdbfff;
  --b3-font-background10: #b1ffff;
  --b3-font-background11: #affad1;
  --b3-font-background12: #fff88f;
  --b3-font-background13: var(--b3-theme-on-background);
}

html.dark,
[data-theme="dark"],
[data-theme-mode="dark"],
.theme-dark,
.dark {
  /* 思源基础卡片与主题色 (深色模式 midnight) */
  --b3-card-error-color: rgb(243, 153, 147);
  --b3-card-error-background: #442724;
  --b3-card-warning-color: rgb(255, 213, 153);
  --b3-card-warning-background: #554636;
  --b3-card-info-color: rgb(166, 213, 250);
  --b3-card-info-background: #28405c;
  --b3-card-success-color: rgb(183, 223, 185);
  --b3-card-success-background: #425347;

  --b3-theme-primary: #3575f0;
  --b3-theme-secondary: #ff9200;
  --b3-theme-error: #d23f31;
  --b3-theme-background: #1e1e1e;
  --b3-theme-on-background: #c8ccd6;
  --b3-theme-on-surface: #8b949e;
  --b3-theme-surface-lighter: #282a2e;

  /* 13 种内置文字颜色 */
  --b3-font-color1: var(--b3-card-error-color);
  --b3-font-color2: var(--b3-card-warning-color);
  --b3-font-color3: var(--b3-card-info-color);
  --b3-font-color4: var(--b3-card-success-color);
  --b3-font-color5: var(--b3-theme-on-surface);
  --b3-font-color6: var(--b3-theme-primary);
  --b3-font-color7: var(--b3-theme-secondary);
  --b3-font-color8: var(--b3-theme-error);
  --b3-font-color9: #f47c9c;
  --b3-font-color10: #4dd0e1;
  --b3-font-color11: #10df54;
  --b3-font-color12: #ecd424;
  --b3-font-color13: var(--b3-theme-background);

  /* 13 种内置背景颜色 */
  --b3-font-background1: var(--b3-card-error-background);
  --b3-font-background2: var(--b3-card-warning-background);
  --b3-font-background3: var(--b3-card-info-background);
  --b3-font-background4: var(--b3-card-success-background);
  --b3-font-background5: #3a3f42;
  --b3-font-background6: #031840;
  --b3-font-background7: #593905;
  --b3-font-background8: #3a0c09;
  --b3-font-background9: #4d1b40;
  --b3-font-background10: #1a5459;
  --b3-font-background11: #305415;
  --b3-font-background12: #4a4712;
  --b3-font-background13: var(--b3-theme-on-background);
}

@media (prefers-color-scheme: dark) {
  :root:not([data-theme="light"]):not([data-theme-mode="light"]):not(.light) {
    --b3-card-error-color: rgb(243, 153, 147);
    --b3-card-error-background: #442724;
    --b3-card-warning-color: rgb(255, 213, 153);
    --b3-card-warning-background: #554636;
    --b3-card-info-color: rgb(166, 213, 250);
    --b3-card-info-background: #28405c;
    --b3-card-success-color: rgb(183, 223, 185);
    --b3-card-success-background: #425347;

    --b3-theme-primary: #3575f0;
    --b3-theme-secondary: #ff9200;
    --b3-theme-error: #d23f31;
    --b3-theme-background: #1e1e1e;
    --b3-theme-on-background: #c8ccd6;
    --b3-theme-on-surface: #8b949e;
    --b3-theme-surface-lighter: #282a2e;

    --b3-font-color1: var(--b3-card-error-color);
    --b3-font-color2: var(--b3-card-warning-color);
    --b3-font-color3: var(--b3-card-info-color);
    --b3-font-color4: var(--b3-card-success-color);
    --b3-font-color5: var(--b3-theme-on-surface);
    --b3-font-color6: var(--b3-theme-primary);
    --b3-font-color7: var(--b3-theme-secondary);
    --b3-font-color8: var(--b3-theme-error);
    --b3-font-color9: #f47c9c;
    --b3-font-color10: #4dd0e1;
    --b3-font-color11: #10df54;
    --b3-font-color12: #ecd424;
    --b3-font-color13: var(--b3-theme-background);

    --b3-font-background1: var(--b3-card-error-background);
    --b3-font-background2: var(--b3-card-warning-background);
    --b3-font-background3: var(--b3-card-info-background);
    --b3-font-background4: var(--b3-card-success-background);
    --b3-font-background5: #3a3f42;
    --b3-font-background6: #031840;
    --b3-font-background7: #593905;
    --b3-font-background8: #3a0c09;
    --b3-font-background9: #4d1b40;
    --b3-font-background10: #1a5459;
    --b3-font-background11: #305415;
    --b3-font-background12: #4a4712;
    --b3-font-background13: var(--b3-theme-on-background);
  }
}

/* 演示块级样式排版增强 (带背景色时赋予呼吸内边距与舒适圆角) */
.slide-styled-block {
  border-radius: 6px;
  padding: 8px 14px;
  box-sizing: border-box;
  margin: 6px 0;
  transition: background-color 0.2s ease, color 0.2s ease;
}

/* 行内带背景色文本的精美圆角与微边距 */
span[style*="background-color"],
span[style*="background:"] {
  border-radius: 3px;
  padding: 1px 5px;
  box-decoration-break: clone;
  -webkit-box-decoration-break: clone;
}
`;function _h(e){var n,s,l,r,a,c,u,f,p,d,b,m;if(!e||typeof e!="object")return"";const t=[],o=[];if(Array.isArray(e.styles))for(const g of e.styles){if(!g||!g.id)continue;const y=`--b3-inline-style-${g.id}`;(n=g.light)!=null&&n.color&&t.push(`  ${y}-color: ${g.light.color};`),(s=g.light)!=null&&s.backgroundColor&&t.push(`  ${y}-background-color: ${g.light.backgroundColor};`),(l=g.dark)!=null&&l.color&&o.push(`  ${y}-color: ${g.dark.color};`),(r=g.dark)!=null&&r.backgroundColor&&o.push(`  ${y}-background-color: ${g.dark.backgroundColor};`)}if(e.builtin&&Array.isArray(e.builtin.colors))for(const g of e.builtin.colors){if(!g||typeof g.index!="number")continue;const y=g.index;(a=g.light)!=null&&a.color&&t.push(`  --b3-font-color${y}: ${g.light.color};`),(c=g.light)!=null&&c.backgroundColor&&t.push(`  --b3-font-background${y}: ${g.light.backgroundColor};`),(u=g.dark)!=null&&u.color&&o.push(`  --b3-font-color${y}: ${g.dark.color};`),(f=g.dark)!=null&&f.backgroundColor&&o.push(`  --b3-font-background${y}: ${g.dark.backgroundColor};`)}if(e.builtin&&Array.isArray(e.builtin.styles))for(const g of e.builtin.styles){if(!g||!g.id)continue;const y=g.id;(p=g.light)!=null&&p.color&&t.push(`  --b3-card-${y}-color: ${g.light.color};`),(d=g.light)!=null&&d.backgroundColor&&t.push(`  --b3-card-${y}-background: ${g.light.backgroundColor};`),(b=g.dark)!=null&&b.color&&o.push(`  --b3-card-${y}-color: ${g.dark.color};`),(m=g.dark)!=null&&m.backgroundColor&&o.push(`  --b3-card-${y}-background: ${g.dark.backgroundColor};`)}if(t.length===0&&o.length===0)return"";const i=[];return t.length>0&&i.push(`:root, html:not(.dark), [data-theme="light"] {
${t.join(`
`)}
}`),o.length>0&&i.push(`html.dark, [data-theme="dark"], .dark {
${o.join(`
`)}
}`),i.join(`

`)}function Wi(e){const t=_h(e);return t?`${kl}

/* Custom Workspace Inline Styles */
${t}`:kl}const ks=Ul;function Ch(e){const t=String((e==null?void 0:e.type)||"").toLowerCase();return t==="s"||t==="sb"||t==="nodesuperblock"||t==="l"||t==="nodelist"||t==="i"||t==="nodelistitem"||t==="b"||t==="nodeblockquote"}function Ih(e,t){const o=new Map,i=[];if(!Array.isArray(t)||t.length===0)return{usable:!1,reason:"索引无行",leafPatch:o,rebuildRoots:i};const n=new Map;for(const s of t)s!=null&&s.id&&n.set(s.id,s);for(const s of e||[]){if(!(s!=null&&s.id))continue;const l=n.get(s.id);if(!l)continue;const r=s.content??"",a=s.markdown??"";(l.content??"")===r&&(l.markdown??"")===a||(Ch(l)?i.push(s.id):o.set(s.id,{content:r,markdown:a}))}return{usable:!0,reason:"",leafPatch:o,rebuildRoots:i}}function $h(e){const t=String((e==null?void 0:e.type)||"").toLowerCase();return t==="h"||t==="nodeheading"}function Gs(e){return ut(e)||e.type==="l"||e.type==="NodeList"||e.type==="i"||e.type==="NodeListItem"||e.type==="b"||e.type==="NodeBlockquote"}function Th(e,t,o,i=8,n){const s=new Map;for(const p of t)p!=null&&p.id&&s.set(p.id,p);const l=p=>({id:p.id,parent_id:p.parent_id,root_id:p.root_id||e,type:p.type,subType:p.subtype??p.subType??"",content:p.content||"",markdown:p.markdown||"",ial:o(p.id,p.ial),children:[]}),r=p=>{let d=p.parent_id,b=0;for(;d&&d!==e&&b++<16;){const m=s.get(d);if(!m||!$h(m))return d;d=m.parent_id}return d||e},a=new Map;for(const p of t){if(!(p!=null&&p.id)||p.id===e||n&&n.size>0&&!n.has(p.id))continue;const d=r(p),b=a.get(d);b?b.push(p):a.set(d,[p])}if(n&&n.size>0)for(const p of a.values())p.sort((d,b)=>(n.get(d.id)??Number.MAX_SAFE_INTEGER)-(n.get(b.id)??Number.MAX_SAFE_INTEGER));const c=new Map,u=(p,d)=>{const b=l(p);if(c.set(b.id,b),d>=i||!Gs(b))return b;const m=a.get(b.id);return m&&m.length>0&&(b.children=m.map(g=>u(g,d+1))),b};return{topLevel:(a.get(e)||[]).map(p=>u(p,0)),byId:c}}const Ah={getBlockAttrs:er,getChildBlocks:Si,getDocBlocksOrders:Bd,setBlockAttrs:ze,sql:vi,getBaseUrl:()=>typeof location<"u"?location.origin:"",getInlineStyles:Ld};class Mh{constructor(t){Ie(this,"deps");Ie(this,"attrOverrides",new Map);Ie(this,"trackedListSuperBlocks",new Map);Ie(this,"fallbackWarnedDocId","");this.deps={...Ah,...t||{}}}setBlockAttrOverride(t,o){if(!t||!o)return;const n={...this.attrOverrides.get(t)||{}};for(const[s,l]of Object.entries(o))l===""||l===null||l===void 0?delete n[s]:n[s]=String(l);Object.keys(n).length===0?this.attrOverrides.delete(t):this.attrOverrides.set(t,n)}getBlockAttrOverride(t){return this.attrOverrides.get(t)}getAllAttrOverrides(){return new Map(this.attrOverrides)}getTrackedListSuperBlocks(t){return this.trackedListSuperBlocks.get(t)||[]}clearBlockAttrOverride(t,o){if(!t)return;if(!o){this.attrOverrides.delete(t);return}const i=this.attrOverrides.get(t);i&&(delete i[o],Object.keys(i).length===0&&this.attrOverrides.delete(t))}clearAllOverrides(){this.attrOverrides.clear(),this.trackedListSuperBlocks.clear()}async compile(t){try{const o=await this.deps.getBlockAttrs(t).catch(()=>({}))||{},i=this.attrOverrides.get(t);i&&Object.assign(o,i);const n=await this.deps.getChildBlocks(t).catch(()=>[])||[],s=this.deps.getDocBlocksOrders?await this.deps.getDocBlocksOrders(t).catch(()=>[])||[]:[],l=new Map;for(let j=0;j<s.length;j++)s[j]&&l.set(s[j],j);const r=l.size>0,a=`SELECT id, parent_id, root_id, type, subtype, content, markdown, ial, sort, created FROM blocks WHERE root_id = '${t}' AND id != '${t}' ORDER BY sort ASC, created ASC LIMIT 99999`,c=await this.deps.sql(a).catch(()=>[])||[],u=Ih(n,c),f=new Map;if(Array.isArray(c))for(const j of c)j.id&&j.ial&&f.set(j.id,ks(j.ial));const p=`SELECT block_id, name, value FROM attributes WHERE root_id = '${t}' AND type = 'b' LIMIT 99999`,d=await this.deps.sql(p).catch(()=>[])||[];if(Array.isArray(d)){for(const j of d)if(j.block_id&&j.name){let C=f.get(j.block_id);C||(C={},f.set(j.block_id,C)),C[j.name]=j.value||""}}const b=(j,C)=>{const M={...f.get(j)||(C?ks(C):{})},B=this.attrOverrides.get(j);return B&&Object.assign(M,B),M},m=Array.isArray(c)&&c.length>0?Th(t,c,b,8,l):null,g=n.map(j=>j.id).filter(Boolean),y=j=>({id:j.id,parent_id:j.parent_id,root_id:j.root_id||t,type:j.type,subType:j.subType,content:j.content||"",markdown:j.markdown||"",ial:b(j.id,j.ial),children:j.children}),k=async(j,C=0)=>{if(!j||C>8||!Gs(j))return;const M=await this.deps.getChildBlocks(j.id).catch(()=>[])||[];if(!(!Array.isArray(M)||M.length===0)){j.children=M.filter(B=>B==null?void 0:B.id).map(B=>({id:B.id,parent_id:j.id,root_id:t,type:B.type,subType:B.subType,content:B.content||"",markdown:B.markdown||"",ial:b(B.id,B.ial),children:[]}));for(const B of j.children)await k(B,C+1)}},x=new Map;for(const j of c)j!=null&&j.id&&x.set(j.id,j);const $=g.every(j=>{const C=x.get(j);return!C||!!C.type});let A=[],w=!1;if(m&&u.usable&&r&&$){this.fallbackWarnedDocId="";for(const[C,M]of u.leafPatch){const B=m.byId.get(C);B&&(B.content=M.content,B.markdown=M.markdown)}const j=new Map;for(const C of n)C!=null&&C.id&&j.set(C.id,C);for(const C of u.rebuildRoots){const M=m.byId.get(C),B=j.get(C);M&&B&&(M.content=B.content||"",M.markdown=B.markdown||""),await k(M)}for(const C of n){if(!(C!=null&&C.id)||m.byId.has(C.id))continue;const M=y(C);await k(M),m.byId.set(M.id,M),m.topLevel.push(M)}A=m.topLevel.filter(C=>l.has(C.id)).sort((C,M)=>(l.get(C.id)??0)-(l.get(M.id)??0))}else g.length>0?(w=!0,this.fallbackWarnedDocId!==t&&(this.fallbackWarnedDocId=t,console.warn(`[DocumentCompiler] 索引结构不可用，回退逐容器查询（较慢）doc=${t} 实时顶层=${g.length} 索引行=${c.length} 文档序=${s.length} 原因=${u.reason||"缺少实时文档序"}`)),A=n.map(j=>y(j))):m&&(A=m.topLevel);const _=async(j,C=0)=>{if(!(!j||j.length===0||C>8))for(const M of j){if(Gs(M)&&(!M.children||M.children.length===0)){let te=await this.deps.getChildBlocks(M.id).catch(()=>[]);if(!te||te.length===0){const V=`SELECT id, parent_id, root_id, type, subtype as subType, content, markdown, ial FROM blocks WHERE parent_id = '${M.id}' ORDER BY sort ASC, created ASC`;te=await this.deps.sql(V).catch(()=>[])||[]}if(Array.isArray(te)&&te.length>0){const V=new Set(A.map(ae=>ae.id)),K=te.filter(ae=>ae.id!==M.id&&!V.has(ae.id));K.length>0&&(M.children=K.map(ae=>{const oe=f.get(ae.id)||(ae.ial?ks(ae.ial):{}),re=this.attrOverrides.get(ae.id);return re&&Object.assign(oe,re),{id:ae.id,parent_id:ae.parent_id||M.id,root_id:ae.root_id||t,type:ae.type,subType:ae.subType,content:ae.content||"",markdown:ae.markdown||"",ial:oe}}))}}M.children&&M.children.length>0&&await _(M.children,C+1)}};w&&await _(A);const O=j=>{var C,M;for(const B of j)if(B.children&&B.children.length>0){O(B.children);for(const te of B.children)if(te.ial)for(const[V,K]of Object.entries(te.ial))V.startsWith("custom-slides-")&&!((C=B.ial)!=null&&C[V])&&(B.ial||(B.ial={}),B.ial[V]=K);if(B.ial){for(const[te,V]of Object.entries(B.ial))if(te.startsWith("custom-slides-"))for(const K of B.children)(K.type==="video"||K.type==="NodeVideo"||/<video\b/i.test(K.markdown||K.content||""))&&!((M=K.ial)!=null&&M[te])&&(K.ial||(K.ial={}),K.ial[te]=V)}}};O(A),kh(A,j=>{const C={[be]:j.layout};this.setBlockAttrOverride(j.blockId,C),(this.deps.setBlockAttrs||ze)(j.blockId,C).catch(B=>{console.warn("[DocumentCompiler] Failed to auto-tag superblock image layout:",B)})});const H=this.trackedListSuperBlocks.get(t)||[],P=vh(t,A,{tracked:H,onTagChange:j=>{this.setBlockAttrOverride(j.blockId,j.attrs),j.blockId===t&&Object.assign(o,j.attrs);const C=B=>{for(const te of B)te.id===j.blockId&&(te.ial||(te.ial={}),Object.assign(te.ial,j.attrs)),te.children&&te.children.length>0&&C(te.children)};C(A),(this.deps.setBlockAttrs||ze)(j.blockId,j.attrs).catch(B=>{console.warn("[DocumentCompiler] Failed to auto-tag list superblock attrs:",B)})}});this.trackedListSuperBlocks.set(t,P.newTracked);const F=new Set,E=j=>{for(const C of j){const M=C.markdown||C.content||"";if(M.includes("((")){const B=Dd(M);for(const te of B)F.add(te.blockId)}C.children&&C.children.length>0&&E(C.children)}};E(A);const D={};if(F.size>0){const j=Array.from(F).map(M=>`'${M}'`).join(","),C=await this.deps.sql(`SELECT id, content, markdown FROM blocks WHERE id IN (${j})`).catch(()=>[])||[];if(Array.isArray(C))for(const M of C)M.id&&(D[M.id]=M.markdown||M.content||"")}const S=this.deps.getBaseUrl?this.deps.getBaseUrl():"",q=vl(t,o,A,{baseUrl:S,refContentMap:D});try{const j=this.deps.getInlineStyles?await this.deps.getInlineStyles().catch(()=>null):null;q.customThemeCss=Wi(j)}catch{q.customThemeCss=Wi(null)}return q}catch(o){console.error("[DocumentCompilerService] Failed to compile document:",o);const i=vl(t,{},[],{});return i.customThemeCss=Wi(null),i}}}const Ee=new Mh,Eh={presenterMode:!0,exportHtml:!1,exportPdf:!1,exportImage:!1,import:!1,aiScript:!0};function Do(e){return Eh[e]===!1}function Ot(e){return!Do(e)}const wl=["white","snow","ivory","ghostwhite","floralwhite","aliceblue","whitesmoke","seashell","beige","oldlace","linen","antiquewhite","lightyellow","lightcyan","papayawhip","blanchedalmond","cornsilk","lavender","lavenderblush","lemonchiffon","honeydew","mintcream","azure","mistyrose","wheat","lightgoldenrodyellow","palegoldenrod","gainsboro","lightgrey","lightgray","silver","pink","lightpink","peachpuff","navajowhite","moccasin","bisque","khaki","palegreen","lightgreen","lightblue","powderblue","paleturquoise","lightsteelblue","thistle","yellow","cyan","aqua"],xl=["black","transparent","navy","darkblue","midnightblue","darkslategray","darkslategrey","maroon","darkred","darkgreen","indigo","darkslateblue","dimgray","dimgrey","purple","brown","olive","teal","blue","darkviolet","darkmagenta","darkcyan","darkolivegreen","saddlebrown","sienna","firebrick","crimson","mediumblue","rebeccapurple"];function _r(e,t,o){return .299*e+.587*t+.114*o}function Sl(e){let t=e.startsWith("#")?e.slice(1):e;if((t.length===3||t.length===4)&&(t=t.slice(0,3).split("").map(o=>o+o).join("")),t.length>=6){const o=parseInt(t.substring(0,2),16),i=parseInt(t.substring(2,4),16),n=parseInt(t.substring(4,6),16);if(!isNaN(o)&&!isNaN(i)&&!isNaN(n))return _r(o,i,n)}return null}function _l(e){const t=e.match(/rgba?\s*\(\s*(\d+(?:\.\d+)?)\s*[,\s]\s*(\d+(?:\.\d+)?)\s*[,\s]\s*(\d+(?:\.\d+)?)(?:\s*[,/]\s*([0-9.]+%?))?/i);if(!t)return null;const o=Number(t[1]),i=Number(t[2]),n=Number(t[3]);if(isNaN(o)||isNaN(i)||isNaN(n))return null;if(t[4]!==void 0){const s=t[4].endsWith("%")?parseFloat(t[4])/100:parseFloat(t[4]);if(!isNaN(s)&&s<=.05)return null}return _r(o,i,n)}function Cl(e){const t=e.match(/hsla?\s*\(\s*([0-9.]+)(?:deg)?\s*[,\s]\s*([0-9.]+)%\s*[,\s]\s*([0-9.]+)%(?:\s*[,/]\s*([0-9.]+%?))?/i);if(!t)return null;if(t[4]!==void 0){const a=t[4].endsWith("%")?parseFloat(t[4])/100:parseFloat(t[4]);if(!isNaN(a)&&a<=.05)return null}const o=(Number(t[1])%360+360)%360/360,i=Math.max(0,Math.min(1,Number(t[2])/100)),n=Math.max(0,Math.min(1,Number(t[3])/100));let s,l,r;if(i===0)s=l=r=n*255;else{const a=n<.5?n*(1+i):n+i-n*i,c=2*n-a,u=f=>{let p=f;return p<0&&(p+=1),p>1&&(p-=1),p<1/6?c+(a-c)*6*p:p<1/2?a:p<2/3?c+(a-c)*(2/3-p)*6:c};s=u(o+1/3)*255,l=u(o)*255,r=u(o-1/3)*255}return _r(s,l,r)}function nc(e){if(!e||typeof e!="string")return null;const t=e.trim().toLowerCase();if(!t||/^(?:https?:\/\/|\/|data:|assets\/|\.\/assets\/|url\s*\()/i.test(t))return null;if(wl.includes(t))return!0;if(xl.includes(t))return!1;if(t.startsWith("#")){const o=Sl(t);return o===null?null:o>140}if(/^rgba?\s*\(/i.test(t)){const o=_l(t);return o===null?null:o>140}if(/^hsla?\s*\(/i.test(t)){const o=Cl(t);return o===null?null:o>140}if(/(?:linear|radial|conic)-gradient\s*\(/i.test(t)){const o=[],i=t.match(/#(?:[0-9a-f]{8}|[0-9a-f]{6}|[0-9a-f]{4}|[0-9a-f]{3})\b/gi);if(i)for(const a of i){const c=Sl(a);c!==null&&o.push(c)}const n=t.match(/rgba?\s*\([^)]+\)/gi);if(n)for(const a of n){const c=_l(a);c!==null&&o.push(c)}const s=t.match(/hsla?\s*\([^)]+\)/gi);if(s)for(const a of s){const c=Cl(a);c!==null&&o.push(c)}const r=t.replace(/#[0-9a-f]+|rgba?\([^)]+\)|hsla?\([^)]+\)/gi," ").match(/\b[a-z]+\b/gi);if(r)for(const a of r)a!=="transparent"&&(wl.includes(a)?o.push(240):xl.includes(a)&&o.push(20));if(o.length>0)return o.reduce((c,u)=>c+u,0)/o.length>140;if(/\btransparent\b/.test(t))return!1}return null}function Uo(){var e,t,o,i,n,s,l,r,a,c,u,f,p;if(typeof window<"u"){const d=(o=(t=(e=window.siyuan)==null?void 0:e.config)==null?void 0:t.appearance)==null?void 0:o.mode;if(d===0)return"light";if(d===1)return"dark"}if(typeof document<"u"){const d=(i=document.documentElement)==null?void 0:i.getAttribute("data-theme-mode");if(d==="light"||d==="dark")return d;const b=(n=document.body)==null?void 0:n.getAttribute("data-theme-mode");if(b==="light"||b==="dark")return b;if((l=(s=document.documentElement)==null?void 0:s.classList)!=null&&l.contains("theme--dark")||(a=(r=document.body)==null?void 0:r.classList)!=null&&a.contains("theme--dark"))return"dark";if((u=(c=document.documentElement)==null?void 0:c.classList)!=null&&u.contains("theme--light")||(p=(f=document.body)==null?void 0:f.classList)!=null&&p.contains("theme--light"))return"light"}if(typeof window<"u"&&typeof window.matchMedia=="function"){if(window.matchMedia("(prefers-color-scheme: light)").matches)return"light";if(window.matchMedia("(prefers-color-scheme: dark)").matches)return"dark"}return"light"}function Cr(e,t){return e==="light"?"light":e==="dark"?"dark":t==="light"||t==="dark"?t:Uo()}function sc(e){if(typeof MutationObserver>"u"||typeof document>"u")return()=>{};let t=Uo();const o=()=>{const n=Uo();n!==t&&(t=n,e(n))},i=new MutationObserver(o);return document.documentElement&&i.observe(document.documentElement,{attributes:!0,attributeFilter:["data-theme-mode","class"]}),document.body&&i.observe(document.body,{attributes:!0,attributeFilter:["data-theme-mode","class"]}),()=>i.disconnect()}class ns{constructor(){Ie(this,"iframe",null);Ie(this,"isReady",!1);Ie(this,"pendingMessages",[]);Ie(this,"slideChangedHandlers",[]);Ie(this,"blockClickedHandlers",[]);Ie(this,"openInEditorHandlers",[]);Ie(this,"clientReadyHandlers",[]);Ie(this,"openPeekDrawerHandlers",[]);Ie(this,"toggleFullscreenHandlers",[]);Ie(this,"openPresenterHandlers",[]);Ie(this,"captureProgressHandlers",[]);Ie(this,"capturePageDoneHandlers",[]);Ie(this,"captureCompleteHandlers",[]);Ie(this,"captureErrorHandlers",[]);this.handleWindowMessage=this.handleWindowMessage.bind(this)}attach(t){this.detach(),this.iframe=t,this.isReady=!1,typeof window<"u"&&window.addEventListener("message",this.handleWindowMessage)}detach(){typeof window<"u"&&window.removeEventListener("message",this.handleWindowMessage),this.iframe=null,this.isReady=!1,this.pendingMessages=[]}resetReady(){this.isReady=!1}postMessage(t,o){var n;const i={source:"siyuan-slides-host",action:t,payload:o};if(!((n=this.iframe)!=null&&n.contentWindow)||!this.isReady){if(t==="UPDATE_SLIDES"||t==="NAVIGATE_PAGE"){const s=this.pendingMessages.findIndex(l=>l.action===t);s!==-1?this.pendingMessages[s]=i:this.pendingMessages.push(i)}else this.pendingMessages.length>=50&&this.pendingMessages.shift(),this.pendingMessages.push(i);return}try{this.iframe.contentWindow.postMessage(i,"*")}catch(s){console.warn("[WebSandboxBridge] postMessage error:",s)}}updateSlides(t,o,i){const n=o?{...o,hostThemeMode:o.hostThemeMode||Uo()}:void 0;this.postMessage("UPDATE_SLIDES",{slides:t,config:n,customThemeCss:i})}navigatePage(t,o){const i={pageIndex:t};typeof o=="number"&&(i.step=o),this.postMessage("NAVIGATE_PAGE",i)}highlightElement(t){this.postMessage("HIGHLIGHT_ELEMENT",{targetBlockId:t})}nextStep(){this.postMessage("NEXT_STEP",{})}prevStep(){this.postMessage("PREV_STEP",{})}freezeKeyboardNav(t){this.postMessage("FREEZE_KEYBOARD_NAV",{frozen:t})}toggleOverview(){this.postMessage("TOGGLE_OVERVIEW",{})}startImageExport(t){this.postMessage("START_IMAGE_EXPORT",{captureOptions:t})}cancelImageExport(){this.postMessage("CANCEL_IMAGE_EXPORT",{})}onCaptureProgress(t){return this.captureProgressHandlers.push(t),()=>{this.captureProgressHandlers=this.captureProgressHandlers.filter(o=>o!==t)}}onCapturePageDone(t){return this.capturePageDoneHandlers.push(t),()=>{this.capturePageDoneHandlers=this.capturePageDoneHandlers.filter(o=>o!==t)}}onCaptureComplete(t){return this.captureCompleteHandlers.push(t),()=>{this.captureCompleteHandlers=this.captureCompleteHandlers.filter(o=>o!==t)}}onCaptureError(t){return this.captureErrorHandlers.push(t),()=>{this.captureErrorHandlers=this.captureErrorHandlers.filter(o=>o!==t)}}onSlideChanged(t){return this.slideChangedHandlers.push(t),()=>{this.slideChangedHandlers=this.slideChangedHandlers.filter(o=>o!==t)}}onBlockClicked(t){return this.blockClickedHandlers.push(t),()=>{this.blockClickedHandlers=this.blockClickedHandlers.filter(o=>o!==t)}}onOpenInEditor(t){return this.openInEditorHandlers.push(t),()=>{this.openInEditorHandlers=this.openInEditorHandlers.filter(o=>o!==t)}}onOpenPeekDrawer(t){return this.openPeekDrawerHandlers.push(t),()=>{this.openPeekDrawerHandlers=this.openPeekDrawerHandlers.filter(o=>o!==t)}}onRequestToggleFullscreen(t){return this.toggleFullscreenHandlers.push(t),()=>{this.toggleFullscreenHandlers=this.toggleFullscreenHandlers.filter(o=>o!==t)}}onOpenPresenter(t){return this.openPresenterHandlers.push(t),()=>{this.openPresenterHandlers=this.openPresenterHandlers.filter(o=>o!==t)}}onClientReady(t){return this.clientReadyHandlers.push(t),()=>{this.clientReadyHandlers=this.clientReadyHandlers.filter(o=>o!==t)}}handleWindowMessage(t){var i,n;const o=t.data;if(!(!o||o.source!=="siyuan-slides-client")&&!((i=this.iframe)!=null&&i.contentWindow&&t.source&&t.source!==this.iframe.contentWindow))switch(o.action){case"CLIENT_READY":for(this.isReady=!0;this.pendingMessages.length>0;){const s=this.pendingMessages.shift();s&&((n=this.iframe)!=null&&n.contentWindow)&&this.iframe.contentWindow.postMessage(s,"*")}for(const s of this.clientReadyHandlers)s();break;case"SLIDE_CHANGED":if(o.payload.currentPage!==void 0)for(const s of this.slideChangedHandlers)o.payload.currentStep!==void 0||o.payload.maxStep!==void 0?s(o.payload.currentPage,o.payload.totalPages||1,o.payload.currentBlockId||"",o.payload.currentStep,o.payload.maxStep):s(o.payload.currentPage,o.payload.totalPages||1,o.payload.currentBlockId||"");break;case"BLOCK_CLICKED":if(o.payload.clickedBlockId)for(const s of this.blockClickedHandlers)s(o.payload.clickedBlockId,o.payload.currentPage||1);break;case"OPEN_IN_EDITOR":if(o.payload.blockId||o.payload.clickedBlockId){const s=o.payload.blockId||o.payload.clickedBlockId||"";for(const l of this.openInEditorHandlers)l(s,o.payload.currentPage||1)}break;case"OPEN_PEEK_DRAWER":if(o.payload.peekType){const s=o.payload.blockId||o.payload.url||"",l={peekType:o.payload.peekType,target:s,title:o.payload.title};for(const r of this.openPeekDrawerHandlers)r(l)}break;case"REQUEST_TOGGLE_FULLSCREEN":for(const s of this.toggleFullscreenHandlers)s();break;case"OPEN_PRESENTER":for(const s of this.openPresenterHandlers)s();break;case"CAPTURE_PROGRESS":if(o.payload.captureProgress)for(const s of this.captureProgressHandlers)s(o.payload.captureProgress);break;case"CAPTURE_PAGE_DONE":if(o.payload.captureResult)for(const s of this.capturePageDoneHandlers)s(o.payload.captureResult);break;case"CAPTURE_COMPLETE":for(const s of this.captureCompleteHandlers)s({total:o.payload.totalPages||0});break;case"CAPTURE_ERROR":for(const s of this.captureErrorHandlers)s(o.payload.captureError||"未知沙箱截图异常");break}}}const Bh={class:"slides-icon",style:{fill:"none !important"},viewBox:"0 0 24 24",stroke:"currentColor","stroke-width":"1.75","stroke-linecap":"round","stroke-linejoin":"round","aria-hidden":"true"},Lh={key:0},Dh={key:1},Oh={key:2},Nh={key:3},Ph={key:4},Rh={key:5},zh={key:6},Hh={key:7},Fh={key:8},jh={key:9},Uh={key:10},Wh={key:11},qh={key:12},Vh={key:13},Kh={key:14},Gh={key:15},Yh={key:16},Zh={key:17},Jh={key:18},Xh={key:19},Qh={key:20},ep={key:21},tp={key:22},op={key:23},ip={key:24},np={key:25},sp={key:26},rp={key:27},lp={key:28},ap={key:29},cp={key:30},dp={key:31},up={key:32},fp={key:33},hp={key:34},pp={key:35},mp={key:36},gp={key:37},yp={key:38},bp={key:39},vp={key:40},kp={key:41},wp={key:42},xp={key:43},Sp={key:44},_p={key:45},Cp={key:46},Ip={key:47},$p={key:48},Tp={key:49},Ap={key:50},Mp={key:51},Ep={key:52},Bp={key:53},Lp={key:54},Dp={key:55},Op={key:56},Np={key:57},Pp={key:58},Rp={key:59},zp={key:60},Hp={key:61},Fp={key:62},jp={key:63},Up={key:64},Wp={key:65},qp={key:66},Vp={key:67},Kp={key:68},Gp={key:69},Yp={key:70},Zp={key:71},Jp={key:72},Xp={key:73},Qp=zt({__name:"SlidesIcon",props:{name:{}},setup(e){return(t,o)=>(J(),X("svg",Bh,[e.name==="fullscreen"||e.name==="maximize"?(J(),X("g",Lh,[...o[0]||(o[0]=[h("polyline",{points:"15 3 21 3 21 9"},null,-1),h("polyline",{points:"9 21 3 21 3 15"},null,-1),h("polyline",{points:"21 15 21 21 15 21"},null,-1),h("polyline",{points:"3 9 3 3 9 3"},null,-1)])])):e.name==="minimize"?(J(),X("g",Dh,[...o[1]||(o[1]=[h("polyline",{points:"4 14 10 14 10 20"},null,-1),h("polyline",{points:"20 10 14 10 14 4"},null,-1),h("line",{x1:"14",y1:"10",x2:"21",y2:"3"},null,-1),h("line",{x1:"3",y1:"21",x2:"10",y2:"14"},null,-1)])])):e.name==="close"||e.name==="x"?(J(),X("g",Oh,[...o[2]||(o[2]=[h("line",{x1:"18",y1:"6",x2:"6",y2:"18"},null,-1),h("line",{x1:"6",y1:"6",x2:"18",y2:"18"},null,-1)])])):e.name==="edit"?(J(),X("g",Nh,[...o[3]||(o[3]=[h("path",{d:"M12 20h9"},null,-1),h("path",{d:"M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z"},null,-1)])])):e.name==="eye"?(J(),X("g",Ph,[...o[4]||(o[4]=[h("path",{d:"M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"},null,-1),h("circle",{cx:"12",cy:"12",r:"3"},null,-1)])])):e.name==="external-link"||e.name==="window"?(J(),X("g",Rh,[...o[5]||(o[5]=[h("path",{d:"M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"},null,-1),h("polyline",{points:"15 3 21 3 21 9"},null,-1),h("line",{x1:"10",y1:"14",x2:"21",y2:"3"},null,-1)])])):e.name==="arrow-left"?(J(),X("g",zh,[...o[6]||(o[6]=[h("line",{x1:"19",y1:"12",x2:"5",y2:"12"},null,-1),h("polyline",{points:"12 19 5 12 12 5"},null,-1)])])):e.name==="arrow-right"?(J(),X("g",Hh,[...o[7]||(o[7]=[h("line",{x1:"5",y1:"12",x2:"19",y2:"12"},null,-1),h("polyline",{points:"12 5 19 12 12 19"},null,-1)])])):e.name==="plus"?(J(),X("g",Fh,[...o[8]||(o[8]=[h("line",{x1:"12",y1:"5",x2:"12",y2:"19"},null,-1),h("line",{x1:"5",y1:"12",x2:"19",y2:"12"},null,-1)])])):e.name==="minus"?(J(),X("g",jh,[...o[9]||(o[9]=[h("line",{x1:"5",y1:"12",x2:"19",y2:"12"},null,-1)])])):e.name==="split-preview"?(J(),X("g",Uh,[...o[10]||(o[10]=[h("rect",{x:"3",y:"3",width:"18",height:"18",rx:"2"},null,-1),h("path",{d:"M12 3v18"},null,-1)])])):e.name==="import"?(J(),X("g",Wh,[...o[11]||(o[11]=[h("path",{d:"M4 17v2a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-2"},null,-1),h("polyline",{points:"7 9 12 14 17 9"},null,-1),h("line",{x1:"12",y1:"14",x2:"12",y2:"3"},null,-1)])])):e.name==="presenter"?(J(),X("g",qh,[...o[12]||(o[12]=[h("path",{d:"M2 3h20"},null,-1),h("path",{d:"M21 3v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V3"},null,-1),h("path",{d:"m7 21 5-5 5 5"},null,-1)])])):e.name==="video"?(J(),X("g",Vh,[...o[13]||(o[13]=[h("polygon",{points:"23 7 16 12 23 17 23 7"},null,-1),h("rect",{x:"1",y:"5",width:"15",height:"14",rx:"2",ry:"2"},null,-1)])])):e.name==="step"?(J(),X("g",Kh,[...o[14]||(o[14]=[h("polygon",{points:"13 2 3 14 12 14 11 22 21 10 12 10 13 2"},null,-1)])])):e.name==="motion"?(J(),X("g",Gh,[...o[15]||(o[15]=[h("path",{d:"M5 12h14"},null,-1),h("path",{d:"m12 5 7 7-7 7"},null,-1),h("path",{d:"M5 6h4"},null,-1),h("path",{d:"M5 18h4"},null,-1)])])):e.name==="columns"?(J(),X("g",Yh,[...o[16]||(o[16]=[h("rect",{x:"3",y:"3",width:"7",height:"18",rx:"1"},null,-1),h("rect",{x:"14",y:"3",width:"7",height:"18",rx:"1"},null,-1)])])):e.name==="layout-grid"||e.name==="grid-2x2"||e.name==="grid"||e.name==="overview"?(J(),X("g",Zh,[...o[17]||(o[17]=[h("rect",{x:"3",y:"3",width:"7",height:"7",rx:"1"},null,-1),h("rect",{x:"14",y:"3",width:"7",height:"7",rx:"1"},null,-1),h("rect",{x:"14",y:"14",width:"7",height:"7",rx:"1"},null,-1),h("rect",{x:"3",y:"14",width:"7",height:"7",rx:"1"},null,-1)])])):e.name==="code"?(J(),X("g",Jh,[...o[18]||(o[18]=[h("polyline",{points:"16 18 22 12 16 6"},null,-1),h("polyline",{points:"8 6 2 12 8 18"},null,-1)])])):e.name==="list"?(J(),X("g",Xh,[...o[19]||(o[19]=[mt('<line x1="8" y1="6" x2="21" y2="6" data-v-144f3270></line><line x1="8" y1="12" x2="21" y2="12" data-v-144f3270></line><line x1="8" y1="18" x2="21" y2="18" data-v-144f3270></line><line x1="3" y1="6" x2="3.01" y2="6" data-v-144f3270></line><line x1="3" y1="12" x2="3.01" y2="12" data-v-144f3270></line><line x1="3" y1="18" x2="3.01" y2="18" data-v-144f3270></line>',6)])])):e.name==="insert-above"?(J(),X("g",Qh,[...o[20]||(o[20]=[h("line",{x1:"12",y1:"5",x2:"12",y2:"13"},null,-1),h("line",{x1:"8",y1:"9",x2:"16",y2:"9"},null,-1),h("path",{d:"M4 19h16","stroke-dasharray":"2 2"},null,-1)])])):e.name==="insert-below"?(J(),X("g",ep,[...o[21]||(o[21]=[h("path",{d:"M4 5h16","stroke-dasharray":"2 2"},null,-1),h("line",{x1:"12",y1:"11",x2:"12",y2:"19"},null,-1),h("line",{x1:"8",y1:"15",x2:"16",y2:"15"},null,-1)])])):e.name==="broom"?(J(),X("g",tp,[...o[22]||(o[22]=[h("path",{d:"m18 15-6-6"},null,-1),h("path",{d:"M4 20h16"},null,-1),h("path",{d:"M6 14l8-8a2.8 2.8 0 0 1 4 4l-8 8H6v-4z"},null,-1)])])):e.name==="trash"?(J(),X("g",op,[...o[23]||(o[23]=[h("path",{d:"M3 6h18"},null,-1),h("path",{d:"M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"},null,-1),h("path",{d:"M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"},null,-1)])])):e.name==="ai"||e.name==="sparkles"?(J(),X("g",ip,[...o[24]||(o[24]=[h("path",{d:"m12 3-1.9 5.8a2 2 0 0 1-1.3 1.3L3 12l5.8 1.9a2 2 0 0 1 1.3 1.3L12 21l1.9-5.8a2 2 0 0 1 1.3-1.3L21 12l-5.8-1.9a2 2 0 0 1-1.3-1.3L12 3z"},null,-1)])])):e.name==="palette"?(J(),X("g",np,[...o[25]||(o[25]=[mt('<circle cx="13.5" cy="6.5" r=".5" fill="currentColor" data-v-144f3270></circle><circle cx="17.5" cy="10.5" r=".5" fill="currentColor" data-v-144f3270></circle><circle cx="8.5" cy="7.5" r=".5" fill="currentColor" data-v-144f3270></circle><circle cx="6.5" cy="12.5" r=".5" fill="currentColor" data-v-144f3270></circle><path d="M12 2C6.5 2 2 6.5 2 12s4.5 10 10 10c.9 0 1.5-.7 1.5-1.5 0-.4-.2-.8-.4-1.1-.3-.4-.4-.8-.4-1.4 0-1.1.9-2 2-2h2.3c3.9 0 7-3.1 7-7 0-5-4.5-9-10-9z" data-v-144f3270></path>',5)])])):e.name==="ratio"?(J(),X("g",sp,[...o[26]||(o[26]=[h("rect",{x:"2",y:"5",width:"20",height:"14",rx:"2"},null,-1),h("line",{x1:"2",y1:"10",x2:"22",y2:"10","stroke-dasharray":"2 2"},null,-1)])])):e.name==="transition"?(J(),X("g",rp,[...o[27]||(o[27]=[h("path",{d:"M8 3 4 7l4 4"},null,-1),h("path",{d:"M4 7h16"},null,-1),h("path",{d:"m16 21 4-4-4-4"},null,-1),h("path",{d:"M20 17H4"},null,-1)])])):e.name==="export-html"?(J(),X("g",lp,[...o[28]||(o[28]=[h("polyline",{points:"16 16 12 12 8 16"},null,-1),h("line",{x1:"12",y1:"12",x2:"12",y2:"21"},null,-1),h("path",{d:"M20.4 16.3A5 5 0 0 0 18 7h-1.3A8 8 0 0 0 4 12.8a5 5 0 0 0 1.5 9.2"},null,-1)])])):e.name==="export-pdf"?(J(),X("g",ap,[...o[29]||(o[29]=[h("polyline",{points:"6 9 6 2 18 2 18 9"},null,-1),h("path",{d:"M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"},null,-1),h("rect",{x:"6",y:"14",width:"12",height:"8"},null,-1)])])):e.name==="pin"?(J(),X("g",cp,[...o[30]||(o[30]=[h("line",{x1:"12",y1:"17",x2:"12",y2:"22"},null,-1),h("path",{d:"M5 17h14v-2l-2-2V5l1-1V2H6v2l1 1v8l-2 2v2z"},null,-1)])])):e.name==="refresh"?(J(),X("g",dp,[...o[31]||(o[31]=[h("path",{d:"M3 12a9 9 0 0 1 9-9 9.75 9.75 0 0 1 6.74 2.74L21 8"},null,-1),h("path",{d:"M21 3v5h-5"},null,-1),h("path",{d:"M21 12a9 9 0 0 1-9 9 9.75 9.75 0 0 1-6.74-2.74L3 16"},null,-1),h("path",{d:"M8 16H3v5"},null,-1)])])):e.name==="alert"||e.name==="warning"?(J(),X("g",up,[...o[32]||(o[32]=[h("path",{d:"M10.29 3.86 1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"},null,-1),h("line",{x1:"12",y1:"9",x2:"12",y2:"13"},null,-1),h("line",{x1:"12",y1:"17",x2:"12.01",y2:"17"},null,-1)])])):e.name==="chevron-left"?(J(),X("g",fp,[...o[33]||(o[33]=[h("polyline",{points:"15 18 9 12 15 6"},null,-1)])])):e.name==="chevron-right"?(J(),X("g",hp,[...o[34]||(o[34]=[h("polyline",{points:"9 18 15 12 9 6"},null,-1)])])):e.name==="chevron-down"?(J(),X("g",pp,[...o[35]||(o[35]=[h("polyline",{points:"6 9 12 15 18 9"},null,-1)])])):e.name==="chevrons-left"?(J(),X("g",mp,[...o[36]||(o[36]=[h("polyline",{points:"11 17 6 12 11 7"},null,-1),h("polyline",{points:"18 17 13 12 18 7"},null,-1)])])):e.name==="chevrons-right"?(J(),X("g",gp,[...o[37]||(o[37]=[h("polyline",{points:"13 17 18 12 13 7"},null,-1),h("polyline",{points:"6 17 11 12 6 7"},null,-1)])])):e.name==="play"?(J(),X("g",yp,[...o[38]||(o[38]=[h("polygon",{points:"6 3 20 12 6 21 6 3"},null,-1)])])):e.name==="pause"?(J(),X("g",bp,[...o[39]||(o[39]=[h("line",{x1:"10",y1:"4",x2:"10",y2:"20"},null,-1),h("line",{x1:"14",y1:"4",x2:"14",y2:"20"},null,-1)])])):e.name==="clock"?(J(),X("g",vp,[...o[40]||(o[40]=[h("circle",{cx:"12",cy:"12",r:"10"},null,-1),h("polyline",{points:"12 6 12 12 16 14"},null,-1)])])):e.name==="copy"?(J(),X("g",kp,[...o[41]||(o[41]=[h("rect",{x:"9",y:"9",width:"13",height:"13",rx:"2",ry:"2"},null,-1),h("path",{d:"M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"},null,-1)])])):e.name==="image"||e.name==="export-image"?(J(),X("g",wp,[...o[42]||(o[42]=[h("rect",{x:"3",y:"3",width:"18",height:"18",rx:"2",ry:"2"},null,-1),h("circle",{cx:"8.5",cy:"8.5",r:"1.5"},null,-1),h("polyline",{points:"21 15 16 10 5 21"},null,-1)])])):e.name==="search"?(J(),X("g",xp,[...o[43]||(o[43]=[h("circle",{cx:"11",cy:"11",r:"7"},null,-1),h("line",{x1:"21",y1:"21",x2:"16.65",y2:"16.65"},null,-1)])])):e.name==="settings"||e.name==="gear"?(J(),X("g",Sp,[...o[44]||(o[44]=[h("circle",{cx:"12",cy:"12",r:"3"},null,-1),h("path",{d:"M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 1 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 1 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 1 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 1 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"},null,-1)])])):e.name==="notes"||e.name==="file-text"?(J(),X("g",_p,[...o[45]||(o[45]=[mt('<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" data-v-144f3270></path><polyline points="14 2 14 8 20 8" data-v-144f3270></polyline><line x1="16" y1="13" x2="8" y2="13" data-v-144f3270></line><line x1="16" y1="17" x2="8" y2="17" data-v-144f3270></line><line x1="10" y1="9" x2="8" y2="9" data-v-144f3270></line>',5)])])):e.name==="focus"||e.name==="target"?(J(),X("g",Cp,[...o[46]||(o[46]=[h("circle",{cx:"12",cy:"12",r:"3",fill:"currentColor"},null,-1),h("path",{d:"M12 2v4M12 18v4M2 12h4M18 12h4",stroke:"currentColor","stroke-width":"2","stroke-linecap":"round"},null,-1),h("circle",{cx:"12",cy:"12",r:"7",fill:"none",stroke:"currentColor","stroke-width":"1.8"},null,-1)])])):e.name==="layout-cover"||e.name==="cover"?(J(),X("g",Ip,[...o[47]||(o[47]=[h("rect",{x:"2",y:"4",width:"20",height:"16",rx:"2"},null,-1),h("line",{x1:"9",y1:"8",x2:"15",y2:"8"},null,-1),h("line",{x1:"5.5",y1:"11.5",x2:"18.5",y2:"11.5"},null,-1),h("line",{x1:"7.5",y1:"15",x2:"16.5",y2:"15"},null,-1)])])):e.name==="layout-default"||e.name==="default"?(J(),X("g",$p,[...o[48]||(o[48]=[mt('<rect x="2" y="4" width="20" height="16" rx="2" data-v-144f3270></rect><line x1="5" y1="8" x2="11.5" y2="8" data-v-144f3270></line><line x1="5" y1="11.5" x2="19" y2="11.5" data-v-144f3270></line><line x1="5" y1="14.5" x2="19" y2="14.5" data-v-144f3270></line><line x1="5" y1="17.5" x2="13.5" y2="17.5" data-v-144f3270></line>',5)])])):e.name==="layout-two-cols"||e.name==="two-cols"?(J(),X("g",Tp,[...o[49]||(o[49]=[mt('<rect x="2" y="4" width="20" height="16" rx="2" data-v-144f3270></rect><line x1="12" y1="4" x2="12" y2="20" stroke-dasharray="2 1.5" data-v-144f3270></line><line x1="5" y1="8" x2="9.5" y2="8" data-v-144f3270></line><line x1="5" y1="11.5" x2="9.5" y2="11.5" data-v-144f3270></line><line x1="5" y1="15" x2="8" y2="15" data-v-144f3270></line><line x1="14.5" y1="8" x2="19" y2="8" data-v-144f3270></line><line x1="14.5" y1="11.5" x2="19" y2="11.5" data-v-144f3270></line><line x1="14.5" y1="15" x2="17.5" y2="15" data-v-144f3270></line>',8)])])):e.name==="layout-two-cols-header"||e.name==="two-cols-header"?(J(),X("g",Ap,[...o[50]||(o[50]=[mt('<rect x="2" y="4" width="20" height="16" rx="2" data-v-144f3270></rect><line x1="5" y1="7.5" x2="13" y2="7.5" data-v-144f3270></line><line x1="12" y1="10.5" x2="12" y2="18.5" stroke-dasharray="1.5 1.5" data-v-144f3270></line><line x1="5" y1="12" x2="9.5" y2="12" data-v-144f3270></line><line x1="5" y1="15.5" x2="8.5" y2="15.5" data-v-144f3270></line><line x1="14.5" y1="12" x2="19" y2="12" data-v-144f3270></line><line x1="14.5" y1="15.5" x2="18" y2="15.5" data-v-144f3270></line>',7)])])):e.name==="layout-cols-header"||e.name==="cols-header"||e.name==="layout-three-cols-header"||e.name==="three-cols-header"?(J(),X("g",Mp,[...o[51]||(o[51]=[mt('<rect x="2" y="4" width="20" height="16" rx="2" data-v-144f3270></rect><line x1="5" y1="7.5" x2="13" y2="7.5" data-v-144f3270></line><line x1="9.3" y1="10.5" x2="9.3" y2="18.5" stroke-dasharray="1.5 1.5" data-v-144f3270></line><line x1="14.7" y1="10.5" x2="14.7" y2="18.5" stroke-dasharray="1.5 1.5" data-v-144f3270></line><line x1="4.5" y1="12" x2="7.5" y2="12" data-v-144f3270></line><line x1="4.5" y1="15.5" x2="7" y2="15.5" data-v-144f3270></line><line x1="10.5" y1="12" x2="13.5" y2="12" data-v-144f3270></line><line x1="10.5" y1="15.5" x2="13.5" y2="15.5" data-v-144f3270></line><line x1="16" y1="12" x2="19.5" y2="12" data-v-144f3270></line><line x1="16" y1="15.5" x2="18.5" y2="15.5" data-v-144f3270></line>',10)])])):e.name==="layout-clover"||e.name==="clover"?(J(),X("g",Ep,[...o[52]||(o[52]=[mt('<rect x="2" y="4" width="20" height="16" rx="2" data-v-144f3270></rect><line x1="5" y1="7" x2="13" y2="7" data-v-144f3270></line><line x1="4.5" y1="13.5" x2="19.5" y2="13.5" stroke-dasharray="1.5 1.5" data-v-144f3270></line><line x1="12" y1="9" x2="12" y2="18.5" stroke-dasharray="1.5 1.5" data-v-144f3270></line><line x1="5" y1="11" x2="9.5" y2="11" data-v-144f3270></line><line x1="14.5" y1="11" x2="19" y2="11" data-v-144f3270></line><line x1="5" y1="16" x2="9.5" y2="16" data-v-144f3270></line><line x1="14.5" y1="16" x2="19" y2="16" data-v-144f3270></line>',8)])])):e.name==="layout-image-right"||e.name==="image-right"?(J(),X("g",Bp,[...o[53]||(o[53]=[mt('<rect x="2" y="4" width="20" height="16" rx="2" data-v-144f3270></rect><line x1="12" y1="4" x2="12" y2="20" data-v-144f3270></line><line x1="4.5" y1="8" x2="9.5" y2="8" data-v-144f3270></line><line x1="4.5" y1="11.5" x2="10" y2="11.5" data-v-144f3270></line><line x1="4.5" y1="14.5" x2="8" y2="14.5" data-v-144f3270></line><circle cx="15.5" cy="8.5" r="1.2" data-v-144f3270></circle><polyline points="13 17 15.5 13 18 16 19.5 14" data-v-144f3270></polyline>',7)])])):e.name==="layout-image-left"||e.name==="image-left"?(J(),X("g",Lp,[...o[54]||(o[54]=[mt('<rect x="2" y="4" width="20" height="16" rx="2" data-v-144f3270></rect><line x1="12" y1="4" x2="12" y2="20" data-v-144f3270></line><circle cx="6" cy="8.5" r="1.2" data-v-144f3270></circle><polyline points="3.5 17 6 13 8.5 16 10 14" data-v-144f3270></polyline><line x1="14.5" y1="8" x2="19.5" y2="8" data-v-144f3270></line><line x1="14.5" y1="11.5" x2="20" y2="11.5" data-v-144f3270></line><line x1="14.5" y1="14.5" x2="18" y2="14.5" data-v-144f3270></line>',7)])])):e.name==="layout-center"||e.name==="center"?(J(),X("g",Dp,[...o[55]||(o[55]=[h("rect",{x:"2",y:"4",width:"20",height:"16",rx:"2"},null,-1),h("line",{x1:"6.5",y1:"9",x2:"17.5",y2:"9"},null,-1),h("line",{x1:"5",y1:"12",x2:"19",y2:"12"},null,-1),h("line",{x1:"8",y1:"15",x2:"16",y2:"15"},null,-1)])])):e.name==="layout-fact"||e.name==="fact"?(J(),X("g",Op,[...o[56]||(o[56]=[mt('<rect x="2" y="4" width="20" height="16" rx="2" data-v-144f3270></rect><circle cx="8" cy="9" r="1.5" data-v-144f3270></circle><line x1="14" y1="8" x2="9" y2="14" data-v-144f3270></line><circle cx="15" cy="13" r="1.5" data-v-144f3270></circle><line x1="6.5" y1="17" x2="17.5" y2="17" data-v-144f3270></line>',5)])])):e.name==="layout-intro"||e.name==="intro"?(J(),X("g",Np,[...o[57]||(o[57]=[mt('<rect x="2" y="4" width="20" height="16" rx="2" data-v-144f3270></rect><circle cx="7.5" cy="9.5" r="2" data-v-144f3270></circle><path d="M4.5 16.5c0-1.8 1.3-3 3-3s3 1.2 3 3" data-v-144f3270></path><line x1="13" y1="9" x2="18.5" y2="9" data-v-144f3270></line><line x1="13" y1="12.5" x2="19.5" y2="12.5" data-v-144f3270></line><line x1="13" y1="15.5" x2="17" y2="15.5" data-v-144f3270></line>',6)])])):e.name==="layout-quote"||e.name==="quote"?(J(),X("g",Pp,[...o[58]||(o[58]=[mt('<rect x="2" y="4" width="20" height="16" rx="2" data-v-144f3270></rect><path d="M6 7.5h2v2H6.5c0 1.2-.4 2-1.5 2.5" data-v-144f3270></path><path d="M9.5 7.5h2v2H10c0 1.2-.4 2-1.5 2.5" data-v-144f3270></path><line x1="6" y1="13.5" x2="18" y2="13.5" data-v-144f3270></line><line x1="12.5" y1="16.5" x2="17.5" y2="16.5" data-v-144f3270></line>',5)])])):e.name==="desktop"||e.name==="monitor"?(J(),X("g",Rp,[...o[59]||(o[59]=[h("rect",{x:"2",y:"3",width:"20",height:"14",rx:"2"},null,-1),h("line",{x1:"8",y1:"21",x2:"16",y2:"21"},null,-1),h("line",{x1:"12",y1:"17",x2:"12",y2:"21"},null,-1)])])):e.name==="mobile"||e.name==="smartphone"||e.name==="phone"?(J(),X("g",zp,[...o[60]||(o[60]=[h("rect",{x:"5",y:"2",width:"14",height:"20",rx:"2",ry:"2"},null,-1),h("line",{x1:"12",y1:"18",x2:"12.01",y2:"18","stroke-width":"2","stroke-linecap":"round"},null,-1)])])):e.name==="type"||e.name==="heading"?(J(),X("g",Hp,[...o[61]||(o[61]=[h("polyline",{points:"4 7 4 4 20 4 20 7"},null,-1),h("line",{x1:"9",y1:"20",x2:"15",y2:"20"},null,-1),h("line",{x1:"12",y1:"4",x2:"12",y2:"20"},null,-1)])])):e.name==="reset"||e.name==="undo"?(J(),X("g",Fp,[...o[62]||(o[62]=[h("path",{d:"M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8"},null,-1),h("polyline",{points:"3 3 3 8 8 8"},null,-1)])])):e.name==="repeat"||e.name==="loop"?(J(),X("g",jp,[...o[63]||(o[63]=[h("path",{d:"m17 1 4 4-4 4"},null,-1),h("path",{d:"M3 11V9a4 4 0 0 1 4-4h14"},null,-1),h("path",{d:"m7 23-4-4 4-4"},null,-1),h("path",{d:"M21 13v2a4 4 0 0 1-4 4H3"},null,-1)])])):e.name==="volume-x"||e.name==="mute"?(J(),X("g",Up,[...o[64]||(o[64]=[h("polygon",{points:"11 5 6 9 2 9 2 15 6 15 11 19 11 5"},null,-1),h("line",{x1:"22",y1:"9",x2:"16",y2:"15"},null,-1),h("line",{x1:"16",y1:"9",x2:"22",y2:"15"},null,-1)])])):e.name==="sliders"||e.name==="controls"?(J(),X("g",Wp,[...o[65]||(o[65]=[mt('<line x1="4" y1="21" x2="4" y2="14" data-v-144f3270></line><line x1="4" y1="10" x2="4" y2="3" data-v-144f3270></line><line x1="12" y1="21" x2="12" y2="12" data-v-144f3270></line><line x1="12" y1="8" x2="12" y2="3" data-v-144f3270></line><line x1="20" y1="21" x2="20" y2="16" data-v-144f3270></line><line x1="20" y1="12" x2="20" y2="3" data-v-144f3270></line><line x1="1" y1="14" x2="7" y2="14" data-v-144f3270></line><line x1="9" y1="8" x2="15" y2="8" data-v-144f3270></line><line x1="17" y1="16" x2="23" y2="16" data-v-144f3270></line>',9)])])):e.name==="package"||e.name==="zip"||e.name==="archive"?(J(),X("g",qp,[...o[66]||(o[66]=[h("line",{x1:"16.5",y1:"9.4",x2:"7.5",y2:"4.21"},null,-1),h("path",{d:"M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"},null,-1),h("polyline",{points:"3.27 6.96 12 12.01 20.73 6.96"},null,-1),h("line",{x1:"12",y1:"22.08",x2:"12",y2:"12"},null,-1)])])):e.name==="folder"?(J(),X("g",Vp,[...o[67]||(o[67]=[h("path",{d:"M4 20h16a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2h-7.93a2 2 0 0 1-1.66-.9l-.82-1.2A2 2 0 0 0 7.93 3H4a2 2 0 0 0-2 2v13c0 1.1.9 2 2 2Z"},null,-1)])])):e.name==="rocket"?(J(),X("g",Kp,[...o[68]||(o[68]=[h("path",{d:"M4.5 16.5c-1.5 1.26-2 5-2 5s3.74-.5 5-2c.71-.84.7-2.13-.09-2.91a2.18 2.18 0 0 0-2.91-.09z"},null,-1),h("path",{d:"m12 15-3-3a22 22 0 0 1 2-3.95A12.88 12.88 0 0 1 22 2c0 2.72-.78 7.5-6 11a22.35 22.35 0 0 1-4 2z"},null,-1),h("path",{d:"M9 12H4s.55-3.03 2-4c1.62-1.08 5 0 5 0"},null,-1),h("path",{d:"M12 15v5s3.03-.55 4-2c1.08-1.62 0-5 0-5"},null,-1)])])):e.name==="wand"||e.name==="magic"?(J(),X("g",Gp,[...o[69]||(o[69]=[h("path",{d:"m19 2 2 2-6 6-2-2Z"},null,-1),h("path",{d:"m13 8 2 2"},null,-1),h("path",{d:"m3 21 9-9"},null,-1)])])):e.name==="image-left"?(J(),X("g",Yp,[...o[70]||(o[70]=[mt('<rect x="2" y="4" width="20" height="16" rx="2" data-v-144f3270></rect><rect x="4" y="6" width="6" height="12" rx="1" data-v-144f3270></rect><line x1="13" y1="8" x2="19" y2="8" data-v-144f3270></line><line x1="13" y1="12" x2="19" y2="12" data-v-144f3270></line><line x1="13" y1="16" x2="17" y2="16" data-v-144f3270></line>',5)])])):e.name==="image-right"?(J(),X("g",Zp,[...o[71]||(o[71]=[mt('<rect x="2" y="4" width="20" height="16" rx="2" data-v-144f3270></rect><rect x="14" y="6" width="6" height="12" rx="1" data-v-144f3270></rect><line x1="5" y1="8" x2="11" y2="8" data-v-144f3270></line><line x1="5" y1="12" x2="11" y2="12" data-v-144f3270></line><line x1="5" y1="16" x2="9" y2="16" data-v-144f3270></line>',5)])])):e.name==="help"||e.name==="question"||e.name==="info"?(J(),X("g",Jp,[...o[72]||(o[72]=[h("circle",{cx:"12",cy:"12",r:"10"},null,-1),h("path",{d:"M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"},null,-1),h("line",{x1:"12",y1:"17",x2:"12.01",y2:"17"},null,-1)])])):(J(),X("g",Xp,[...o[73]||(o[73]=[h("rect",{x:"2",y:"3",width:"20",height:"14",rx:"2"},null,-1),h("line",{x1:"8",y1:"21",x2:"16",y2:"21"},null,-1),h("line",{x1:"12",y1:"17",x2:"12",y2:"21"},null,-1)])]))]))}}),lo=(e,t)=>{const o=e.__vccOpts||e;for(const[i,n]of t)o[i]=n;return o},de=lo(Qp,[["__scopeId","data-v-144f3270"]]),em={class:"spm-immersion-header"},tm={class:"spm-immersion-header__left"},om={class:"spm-immersion-title"},im={class:"spm-immersion-header__center"},nm={class:"spm-immersion-header__actions"},sm=["aria-label"],rm={class:"spm-immersion-body"},lm=zt({__name:"ImmersionDrawerContainer",props:{visible:{type:Boolean,default:!1},isMaximized:{type:Boolean,default:!1},title:{default:"速览"},closeOnClickMask:{type:Boolean,default:!0}},emits:["update:visible","update:isMaximized","close","toggle-maximize"],setup(e,{emit:t}){const o=e,i=t;function n(){i("update:visible",!1),i("close")}function s(){o.closeOnClickMask&&n()}function l(){i("update:isMaximized",!o.isMaximized),i("toggle-maximize")}function r(a){(a.key===" "||a.key==="ArrowLeft"||a.key==="ArrowRight"||a.key==="PageUp"||a.key==="PageDown")&&a.stopPropagation(),a.key==="Escape"&&(a.preventDefault(),a.stopPropagation(),n())}return(a,c)=>Ut((J(),X("div",{class:xe(["spm-immersion-container",{"is-maximized":e.isMaximized}]),onKeydown:io(r,["stop"])},[h("div",{class:"spm-immersion-mask",onClick:s}),h("div",{class:xe(["spm-immersion-drawer",{"is-maximized":e.isMaximized}])},[h("div",em,[h("div",tm,[hn(a.$slots,"header-left",{},()=>[h("span",om,ve(e.title),1)])]),h("div",im,[hn(a.$slots,"header-center",{},void 0)]),h("div",nm,[hn(a.$slots,"header-actions",{},void 0),h("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":e.isMaximized?"还原抽屉宽度 (70%)":"最大化填满视口 (100%)",onClick:l},[le(de,{name:e.isMaximized?"minimize":"maximize"},null,8,["name"])],8,sm),h("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"关闭速览 (ESC)",onClick:n},[le(de,{name:"close"})])])]),h("div",rm,[hn(a.$slots,"default",{},void 0)])],2)],34)),[[Us,e.visible]])}}),am=lo(lm,[["__scopeId","data-v-1359fecb"]]);function cm(){if(typeof window<"u"&&typeof window.require=="function")return window.require.bind(window);if(typeof globalThis<"u"&&typeof globalThis.require=="function")return globalThis.require.bind(globalThis);if(typeof require=="function")return require}function ln(e){const t=cm();if(t)try{return t(e)}catch{try{const o=e.startsWith("node:")?e.slice(5):`node:${e}`;return t(o)}catch{}}}function dm(){var t;if(typeof window<"u"&&window.process)return window.process;const e=ln("process");return e&&e.versions?e:typeof process<"u"&&((t=process.versions)!=null&&t.node)?process:globalThis.process}function um(){var t,o;const e=dm();if(e&&((t=e.versions)!=null&&t.node))return!0;if(typeof window<"u"&&window.siyuan){const i=ln("child_process");if(i&&typeof i.spawn=="function")return!0}return!!(typeof process<"u"&&((o=process.versions)!=null&&o.node))}function fm(){if(typeof window>"u"||!window.location)return!1;try{return new URLSearchParams(window.location.search).get("remote")==="1"}catch{return!1}}const hm={class:"spm-protyle-drawer"},pm={class:"spm-protyle-drawer__subbar"},mm={class:"spm-protyle-drawer__nav"},gm=["title"],ym={class:"spm-protyle-drawer__actions"},bm=["aria-label"],vm=["aria-label"],km=zt({__name:"ProtylePeekDrawer",props:{blockId:{},title:{},plugin:{}},emits:["external-jump"],setup(e,{emit:t}){const o=t,i=e,n=pe(i.blockId),s=pe(i.title||""),l=pe(!1),r=pe(!0),a=pe(!1),c=pe(""),u=Ht,f=pe([]),p=pe(null);let d=null;Ho(()=>i.blockId,_=>{_&&_!==n.value&&(n.value=_,s.value=i.title||"",f.value=[],m(_))}),ti(()=>{n.value&&m(n.value)}),pr(()=>{g()});async function b(_){try{const O=await vi(`SELECT id, root_id, type, content FROM blocks WHERE id = '${_}' LIMIT 1`);if(Array.isArray(O)&&O.length>0){const H=O[0];c.value=H.root_id||"";const P=H.id===H.root_id||H.type==="d";a.value=P,r.value=!P,!s.value&&H.content&&(s.value=H.content.trim().slice(0,30));return}}catch(O){console.warn("[ProtylePeekDrawer] detectBlockType query failed:",O)}a.value=!1,r.value=!0}async function m(_,O){if(!p.value||!_)return;g(),await b(_),typeof O=="boolean"&&(r.value=!a.value&&O);let H,P;r.value&&!a.value?(H=["cb-get-all","cb-get-hl","cb-get-focus"],P={background:!1,title:!1,gutter:!0,breadcrumbDocName:!0,scroll:!0}):(H=["cb-get-context","cb-get-hl"],P={background:!0,title:!0,gutter:!0,breadcrumbDocName:!0,scroll:!0});try{d=new ie.Protyle(i.plugin.app,p.value,{blockId:_,action:H,render:P}),!l.value&&d&&typeof d.disable=="function"&&d.disable()}catch(F){console.error("[ProtylePeekDrawer] Failed to instantiate Protyle:",F)}}function g(){if(d){try{typeof d.destroy=="function"&&d.destroy()}catch(_){console.warn("[ProtylePeekDrawer] Error destroying protyle:",_)}d=null}p.value&&(p.value.innerHTML="")}function y(){a.value||(r.value=!r.value,m(n.value,r.value))}function k(){l.value=!l.value,d&&(l.value?(typeof d.enable=="function"&&d.enable(),typeof d.focus=="function"&&d.focus()):typeof d.disable=="function"&&d.disable())}function x(){if(n.value)try{ie.openWindow({doc:{id:n.value},alwaysOnTop:!0})}catch(_){console.warn("[ProtylePeekDrawer] openWindow failed:",_)}}function $(){var H;if(!n.value)return;const _=Fo(),O=ec(_.webServeUrl,n.value,{focus:!a.value});if(typeof window<"u"){const P=ln("electron");(H=P==null?void 0:P.shell)!=null&&H.openExternal?P.shell.openExternal(O).catch(()=>{window.open(O,"_blank")}):window.open(O,"_blank")}o("external-jump",O)}function A(){if(f.value.length>0){const _=f.value.pop();_&&(n.value=_.blockId,s.value=_.title,r.value=_.isFocusMode,a.value=_.isDoc,m(_.blockId,_.isFocusMode))}}function w(_){const O=_.target;if(!O)return;const H=O.closest('[data-type="block-ref"]');if(H){const F=H.getAttribute("data-id");if(F&&F!==n.value){_.preventDefault(),_.stopPropagation(),f.value.push({blockId:n.value,title:s.value||n.value,isFocusMode:r.value,isDoc:a.value}),n.value=F,s.value=H.innerText.trim()||F,m(F);return}}const P=O.closest("a");if(P&&P.href&&P.href.startsWith("siyuan://blocks/")){_.preventDefault(),_.stopPropagation();const F=P.href.replace("siyuan://blocks/","").split("?")[0];F&&F!==n.value&&(f.value.push({blockId:n.value,title:s.value||n.value,isFocusMode:r.value,isDoc:a.value}),n.value=F,s.value=P.innerText.trim()||F,m(F))}}return(_,O)=>(J(),X("div",hm,[h("div",pm,[h("div",mm,[f.value.length>0?(J(),X("button",{key:0,class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"返回上层引用文档或块",onClick:A},[le(de,{name:"arrow-left"}),O[0]||(O[0]=h("span",null,"返回",-1))])):Ae("",!0),h("span",{class:xe(["spm-protyle-badge",{"is-focus":r.value&&!a.value}])},ve(r.value&&!a.value?"思源块聚焦":"思源文档速览"),3),h("span",{class:"spm-protyle-id",title:s.value||n.value},ve(s.value||n.value),9,gm)]),h("div",ym,[a.value?Ae("",!0):(J(),X("button",{key:0,class:xe(["spm-icon-btn b3-tooltips b3-tooltips__s",{"is-primary":r.value}]),"aria-label":r.value?"当前为块聚焦模式（点击展开所属文档全文）":"当前为文档全文模式（点击切回仅聚焦当前块）",onClick:y},[le(de,{name:r.value?"focus":"file-text"},null,8,["name"]),h("span",null,ve(r.value?"块聚焦":"展开全文"),1)],10,bm)),h("button",{class:xe(["spm-icon-btn b3-tooltips b3-tooltips__s",{"is-primary":l.value}]),"aria-label":l.value?"当前为即时编辑模式（点击切回只读）":"当前为只读速览模式（点击解锁即时编辑）",onClick:k},[le(de,{name:l.value?"edit":"eye"},null,8,["name"]),h("span",null,ve(l.value?"编辑中":"只读"),1)],10,vm),h("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"在置顶独立窗口中打开 (保留完整侧边栏与插件)",onClick:x},[le(de,{name:"window"}),O[1]||(O[1]=h("span",null,"独立窗口",-1))]),ue(u).enableWebServeJump?(J(),X("button",{key:1,class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"在系统默认浏览器中打开 (外跳)",onClick:$},[le(de,{name:"external-link"}),O[2]||(O[2]=h("span",null,"外跳",-1))])):Ae("",!0)])]),h("div",{ref_key:"mountEl",ref:p,class:xe(["spm-protyle-mount",{"is-focus-mode":r.value&&!a.value}]),onClick:w},null,2)]))}}),wm=lo(km,[["__scopeId","data-v-0d6e2df3"]]),xm=/^(https?|file|data|blob|mailto|tel|ftp|ftps|siyuan|about|chrome|ws|wss):/i,Sm=/\.(html?|xhtml|pdf|png|jpe?g|gif|svg|webp|avif|ico|mp4|webm|mov|mp3|wav|m4a|ogg|json|md|markdown|txt|csv|zip|tar|gz|7z|rar|js|mjs|css|xml|yaml|yml|toml|ipynb|docx?|xlsx?|pptx?)$/i;function Il(e){let t=e||"";try{t=decodeURIComponent(t)}catch{}t=t.replace(/\\/g,"/");const o=/(?:^|\/)data\/assets\/(.+)$/i.exec(t);if(o)return`/assets/${o[1]}`;const i=/(?:^|\/)data\/plugins\/(.+)$/i.exec(t);return i?`/plugins/${i[1]}`:null}function rc(e){const t=(e||"").replace(/^file:\/\//i,"");let o=t;try{o=decodeURIComponent(t)}catch{}if(o.startsWith("/"))return/^\/([a-zA-Z]:[\\/])/.exec(o)?o.slice(1):o;const i=o.indexOf("/");return i>=0?o.slice(i):o}function _m(e){const t=e.split(/[/?#]/)[0];return!t||Sm.test(t)?!1:/^(localhost|\d{1,3}(\.\d{1,3}){3})(:\d+)?$/i.test(t)?!0:/^[a-z0-9-]+(\.[a-z0-9-]+)+(:\d+)?$/i.test(t)}function Cm(e){const t=e.indexOf("#"),o=t>=0?e.slice(t):"",i=t>=0?e.slice(0,t):e,n=i.indexOf("?"),s=n>=0?i.slice(0,n):i,l=n>=0?i.slice(n+1):"";if(!/^\/?assets\/.+\.html?$/i.test(s))return e;const r=new URLSearchParams(l);return r.get("iframe")==="true"||r.get("download")==="true"?e:(r.set("iframe","true"),`${s}?${r.toString()}${o}`)}function lc(e){const t=Im(e);return t.external||!t.url?t:{url:Cm(t.url),external:!1}}function Im(e){const t=(e||"").trim();if(!t)return{url:"",external:!1};if(/^https?:\/\//i.test(t))return{url:t,external:!1};if(t.startsWith("//"))return{url:`https:${t}`,external:!1};if(/^(siyuan|data|blob|about):/i.test(t))return{url:t,external:!1};if(Kl(t))return{url:`/${Gl(t)}`,external:!1};if(/^file:/i.test(t)){const i=Il(rc(t));return i?{url:i,external:!1}:{url:t,external:!0}}if(/^[a-zA-Z]:[\\/]/.test(t)||t.startsWith("\\\\")){const i=Il(t);return i?{url:i,external:!1}:{url:t,external:!0}}return xm.test(t)?{url:t,external:!0}:_m(t)?{url:`https://${t}`,external:!1}:{url:`/${t.replace(/^(?:\.{1,2}\/)+/,"").replace(/^\/+/,"")}`,external:!1}}const $m={class:"spm-webview-drawer"},Tm={class:"spm-webview-toolbar"},Am={class:"spm-webview-toolbar__nav"},Mm=["disabled"],Em=["disabled"],Bm=["aria-label"],Lm={class:"spm-webview-toolbar__address"},Dm=["aria-label"],Om={class:"spm-webview-toolbar__actions"},Nm=["aria-label"],Pm={class:"spm-zoom-controller"},Rm=["disabled"],zm=["disabled"],Hm={key:1,class:"spm-webview-fallback"},Fm=["src"],jm={key:2,class:"spm-load-error"},Um={class:"spm-load-error__code"},Wm={class:"spm-load-error__code-num"},qm={class:"spm-load-error__url"},Vm={class:"spm-load-error__hint"},Km={class:"spm-load-error__actions"},$l="Mozilla/5.0 (iPhone; CPU iPhone OS 17_4_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.4.1 Mobile/15E148 Safari/604.1",ac="siyuan-slides-peek-view-mode";let cc="desktop";function Gm(){if(typeof window<"u"&&window.localStorage)try{const e=window.localStorage.getItem(ac);if(e==="mobile"||e==="desktop")return e}catch{}return cc}function Ym(e){if(cc=e,typeof window<"u"&&window.localStorage)try{window.localStorage.setItem(ac,e)}catch{}}function Zm(e){switch((e||"").toUpperCase()){case"ERR_PROXY_CONNECTION_FAILED":return"无法连接到代理服务器：请在思源「设置 → 网络代理」中填写公司代理地址，或切换为「使用系统代理」。";case"ERR_TUNNEL_CONNECTION_FAILED":return"HTTPS 代理隧道建立失败：请将思源「网络代理」的类型设为 HTTPS 并确认地址正确。";case"ERR_MANDATORY_PROXY_CONFIGURATION_FAILED":return"强制代理配置获取失败：公司 PAC 脚本不可用，请在思源「网络代理」中改为手动填写代理地址。";case"ERR_NAME_NOT_RESOLVED":case"ERR_NAME_RESOLUTION_FAILED":return"域名解析失败：内网环境访问外网通常需要配置代理或 DNS。";case"ERR_INTERNET_DISCONNECTED":return"当前网络不可用：请检查网络连接。";case"ERR_CONNECTION_TIMED_OUT":case"ERR_TIMED_OUT":return"连接超时：该地址可能需要通过代理才能访问。";case"ERR_CONNECTION_REFUSED":return"连接被拒绝：目标服务未在监听，或思源本地内核尚未启动。";case"ERR_CERT_AUTHORITY_INVALID":case"ERR_CERT_COMMON_NAME_INVALID":case"ERR_CERT_DATE_INVALID":return"证书校验失败：若公司网络使用 TLS 拦截，需将根证书导入思源所用系统的证书库。";default:return"若处于公司内网，请优先检查思源「设置 → 网络代理」是否已配置为可用代理（支持「使用系统代理」）。"}}const Jm=zt({__name:"WebviewPeekDrawer",props:{url:{},title:{},visible:{type:Boolean,default:!0}},emits:["external-jump"],setup(e,{emit:t}){const o=t,i=e,n=pe(um()&&!fm()),s=pe(i.url),l=pe(i.url),r=i.url,a=pe(!1),c=pe(null),u=pe(!1),f=pe(!1),p=pe(1),d=pe(!1),b=pe(Gm());let m=typeof navigator<"u"&&!navigator.userAgent.includes("iPhone")?navigator.userAgent:"";const g=ye(()=>b.value==="mobile"?$l:m||void 0),y=pe(null),k=pe(null);let x=null,$=null,A=null;Ho(()=>i.url,R=>{R&&R!==s.value&&(s.value=R,l.value=R,b.value==="mobile"&&P(!1),y.value&&typeof y.value.loadURL=="function"&&y.value.loadURL(R))}),Ho(()=>i.visible,R=>{if(R)ae(),b.value==="mobile"&&P(!1);else if(y.value)try{typeof y.value.stop=="function"&&y.value.stop()}catch{}}),ti(()=>{w(),k.value&&typeof ResizeObserver<"u"&&(x=new ResizeObserver(()=>{const R=y.value;if(R&&typeof R.invalidate=="function")try{R.invalidate()}catch{}}),x.observe(k.value)),$=R=>{var L;const ne=R.message||((L=R.error)==null?void 0:L.message);if(typeof ne=="string"&&ne.includes("Invalid guestInstanceId"))return R.preventDefault(),R.stopImmediatePropagation(),!0},window.addEventListener("error",$,!0),A=R=>{const ne=R.reason,L=typeof ne=="string"?ne:ne==null?void 0:ne.message;typeof L=="string"&&L.includes("Invalid guestInstanceId")&&R.preventDefault()},window.addEventListener("unhandledrejection",A)}),pr(()=>{if(_(),x&&(x.disconnect(),x=null),$&&(window.removeEventListener("error",$,!0),$=null),A&&(window.removeEventListener("unhandledrejection",A),A=null),y.value)try{typeof y.value.stop=="function"&&y.value.stop()}catch{}});function w(){const R=y.value;R&&(R.addEventListener("dom-ready",O),R.addEventListener("did-start-loading",F),R.addEventListener("did-stop-loading",S),R.addEventListener("did-navigate",q),R.addEventListener("did-navigate-in-page",j),R.addEventListener("new-window",C),R.addEventListener("did-fail-load",E),R.addEventListener("did-fail-provisional-load",E))}function _(){const R=y.value;if(R)try{R.removeEventListener("dom-ready",O),R.removeEventListener("did-start-loading",F),R.removeEventListener("did-stop-loading",S),R.removeEventListener("did-navigate",q),R.removeEventListener("did-navigate-in-page",j),R.removeEventListener("new-window",C),R.removeEventListener("did-fail-load",E),R.removeEventListener("did-fail-provisional-load",E)}catch{}}function O(){const R=y.value;if(R&&typeof R.getUserAgent=="function"&&!m)try{const ne=R.getUserAgent();ne&&!ne.includes("iPhone")&&(m=ne)}catch{}b.value==="mobile"&&P(!1),ae(),M()}function H(){const R=b.value==="mobile"?"desktop":"mobile";b.value=R,Ym(R),P(!0)}function P(R=!1){const ne=y.value;if(!ne)return;const L=b.value==="mobile"?$l:m;if(typeof ne.setUserAgent=="function"&&L)try{ne.setUserAgent(L)}catch(U){console.warn("[WebviewPeekDrawer] setUserAgent error:",U)}if(R&&typeof ne.reload=="function")try{ne.reload()}catch(U){console.warn("[WebviewPeekDrawer] reload error:",U)}}function F(){a.value=!0,c.value=null}function E(R){if(R&&R.isMainFrame===!1||R&&Number(R.errorCode)===-3)return;const ne=String((R==null?void 0:R.errorDescription)||"ERR_FAILED");c.value={errorCode:Number((R==null?void 0:R.errorCode)??0),description:ne,validatedURL:String((R==null?void 0:R.validatedURL)||s.value),hint:Zm(ne)},a.value=!1}function D(){c.value=null,V()}function S(){if(a.value=!1,M(),y.value&&typeof y.value.getURL=="function"){const R=y.value.getURL();R&&R!=="about:blank"&&(s.value=R,l.value=R)}}function q(R){R!=null&&R.url&&(s.value=R.url,l.value=R.url),M()}function j(R){R!=null&&R.url&&(s.value=R.url,l.value=R.url),M()}function C(R){R&&R.url&&(R.preventDefault(),y.value&&typeof y.value.loadURL=="function"&&y.value.loadURL(R.url))}function M(){const R=y.value;R&&(typeof R.canGoBack=="function"&&(u.value=R.canGoBack()),typeof R.canGoForward=="function"&&(f.value=R.canGoForward()))}function B(){y.value&&typeof y.value.goBack=="function"&&y.value.goBack()}function te(){y.value&&typeof y.value.goForward=="function"&&y.value.goForward()}function V(){y.value&&typeof y.value.reload=="function"&&y.value.reload()}function K(){const R=lc(l.value);if(R.url){if(R.external){s.value=R.url,_e();return}s.value=R.url,l.value=R.url,y.value&&typeof y.value.loadURL=="function"&&y.value.loadURL(R.url)}}function ae(){const R=y.value;if(R&&typeof R.setZoomFactor=="function")try{R.setZoomFactor(p.value)}catch(ne){console.warn("[WebviewPeekDrawer] setZoomFactor error:",ne)}}function oe(){p.value=Math.min(2.5,Math.round((p.value+.1)*10)/10),ae()}function re(){p.value=Math.max(.5,Math.round((p.value-.1)*10)/10),ae()}function Se(){p.value=1,ae()}function $e(R){R.preventDefault(),R.deltaY<0?oe():R.deltaY>0&&re()}async function ke(){if(typeof navigator<"u"&&navigator.clipboard)try{await navigator.clipboard.writeText(s.value),d.value=!0,setTimeout(()=>{d.value=!1},2e3)}catch(R){console.warn("Copy url failed:",R)}}function _e(){var ne;const R=s.value;if(typeof window<"u"){const L=ln("electron");(ne=L==null?void 0:L.shell)!=null&&ne.openExternal?L.shell.openExternal(R).catch(()=>{window.open(R,"_blank")}):window.open(R,"_blank")}o("external-jump",R)}return(R,ne)=>{const L=Uu("webview");return J(),X("div",$m,[h("div",Tm,[h("div",Am,[h("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s",disabled:!u.value,"aria-label":"后退",onClick:B},[le(de,{name:"arrow-left"})],8,Mm),h("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s",disabled:!f.value,"aria-label":"前进",onClick:te},[le(de,{name:"arrow-right"})],8,Em),h("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":a.value?"正在加载...":"刷新页面",onClick:V},[le(de,{name:"refresh"})],8,Bm)]),h("div",Lm,[Ut(h("input",{"onUpdate:modelValue":ne[0]||(ne[0]=U=>l.value=U),type:"text",class:"b3-text-field spm-url-input",placeholder:"https://...",spellcheck:"false",onKeydown:sh(K,["enter"])},null,544),[[Ws,l.value]]),h("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":d.value?"已复制地址！":"复制网址",onClick:ke},[le(de,{name:"copy"})],8,Dm)]),h("div",Om,[h("button",{class:xe(["spm-icon-btn spm-mode-toggle b3-tooltips b3-tooltips__s",{"is-active":b.value==="mobile"}]),"aria-label":b.value==="mobile"?"当前为手机视图，点击切换为桌面视图":"当前为桌面视图，点击切换为手机视图",onClick:H},[le(de,{name:b.value==="mobile"?"mobile":"desktop"},null,8,["name"])],10,Nm),h("div",Pm,[h("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"缩小 (Ctrl + -)",disabled:p.value<=.5,onClick:re},[le(de,{name:"minus"})],8,Rm),h("button",{class:"spm-zoom-badge b3-tooltips b3-tooltips__s","aria-label":"重置 100% (Ctrl + 0)",onClick:Se},ve(Math.round(p.value*100))+"% ",1),h("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"放大 (Ctrl + +)",disabled:p.value>=2.5,onClick:oe},[le(de,{name:"plus"})],8,zm)]),h("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"在系统默认浏览器中打开 ↗",onClick:_e},[le(de,{name:"external-link"}),ne[1]||(ne[1]=h("span",null,"外跳",-1))])])]),h("div",{ref_key:"containerEl",ref:k,class:xe(["spm-webview-body",{"is-mobile":b.value==="mobile"}]),onWheel:io($e,["ctrl"])},[h("div",{class:xe(["spm-webview-viewport",{"is-mobile":b.value==="mobile"}])},[n.value?(J(),qt(L,{key:0,ref_key:"webviewRef",ref:y,class:"spm-webview-frame",src:ue(r),useragent:g.value,allowpopups:"true",style:{position:"absolute",top:"0",left:"0",width:"100%",height:"100%",display:"inline-flex"}},null,8,["src","useragent"])):(J(),X("div",Hm,[h("iframe",{class:"spm-webview-fallback-frame",src:s.value,frameborder:"0",sandbox:"allow-scripts allow-same-origin allow-forms allow-popups"},null,8,Fm),h("div",{class:"spm-fallback-bar"},[ne[2]||(ne[2]=h("span",null,"如页面受同源策略 (X-Frame-Options) 拦截无法显示，请",-1)),h("button",{class:"spm-icon-btn is-primary",onClick:_e}," 在新标签页中打开 ↗ ")])])),c.value?(J(),X("div",jm,[le(de,{name:"alert",class:"spm-load-error__icon"}),ne[5]||(ne[5]=h("div",{class:"spm-load-error__title"},"页面加载失败",-1)),h("div",Um,[St(ve(c.value.description)+" ",1),h("span",Wm,"("+ve(c.value.errorCode)+")",1)]),h("div",qm,ve(c.value.validatedURL),1),h("p",Vm,ve(c.value.hint),1),h("div",Km,[h("button",{class:"spm-icon-btn","aria-label":"重试",onClick:D},[le(de,{name:"refresh"}),ne[3]||(ne[3]=h("span",null,"重试",-1))]),h("button",{class:"spm-icon-btn is-primary","aria-label":"用系统浏览器打开",onClick:_e},[le(de,{name:"external-link"}),ne[4]||(ne[4]=h("span",null,"用系统浏览器打开 ↗",-1))])])])):Ae("",!0)],2)],34)])}}}),Xm=lo(Jm,[["__scopeId","data-v-6e363f73"]]);class Qm{constructor(){Ie(this,"timers",new Map)}debounce(t,o,i=150){this.cancel(t);const n=setTimeout(()=>{this.timers.delete(t),o()},i);this.timers.set(t,n)}cancel(t){this.timers.has(t)&&(clearTimeout(this.timers.get(t)),this.timers.delete(t))}cancelAll(){for(const t of this.timers.values())clearTimeout(t);this.timers.clear()}hasPending(t){return this.timers.has(t)}}class eg{constructor(t){Ie(this,"blockToPageMap",new Map);Ie(this,"debounceCtrl",new Qm);Ie(this,"activeBlockId","");Ie(this,"activePageIndex",1);Ie(this,"currentDocId","");Ie(this,"bridge",null);t&&(this.bridge=t)}setBridge(t){this.bridge=t}setDocId(t){this.currentDocId=t,t&&this.blockToPageMap.delete(t)}updateSlidesIndex(t){this.blockToPageMap.clear();for(const o of t){o.startBlockId&&o.startBlockId!==this.currentDocId&&this.blockToPageMap.set(o.startBlockId,o.pageIndex);for(const i of o.blocks)this.blockToPageMap.set(i.id,o.pageIndex)}}getPageByBlockId(t){return this.blockToPageMap.get(t)??null}onCursorFocusBlock(t){if(!t||t===this.activeBlockId)return;if(this.activeBlockId=t,t===this.currentDocId){this.debounceCtrl.cancel("cursor-navigate");return}const o=this.getPageByBlockId(t);if(!o){this.debounceCtrl.cancel("cursor-navigate");return}this.debounceCtrl.debounce("cursor-navigate",()=>{this.activePageIndex=o,this.bridge&&(this.bridge.navigatePage(o),this.bridge.highlightElement(t))},100)}getActiveBlockId(){return this.activeBlockId}setActiveBlockId(t){this.activeBlockId=t,t||this.debounceCtrl.cancel("cursor-navigate");const o=this.getPageByBlockId(t);o&&(this.activePageIndex=o)}getActivePageIndex(){return this.activePageIndex}destroy(){this.debounceCtrl.cancelAll(),this.blockToPageMap.clear(),this.bridge=null}}let Pt=null,xn=null,Sn="";function qi(){var e,t;if(xn&&(clearTimeout(xn),xn=null),Pt){try{Pt.classList.remove("protyle-wysiwyg--select"),Sn?Pt.style.outline=Sn:typeof((e=Pt.style)==null?void 0:e.removeProperty)=="function"?Pt.style.removeProperty("outline"):Pt.style&&(Pt.style.outline=""),typeof((t=Pt.style)==null?void 0:t.removeProperty)=="function"?Pt.style.removeProperty("transition"):Pt.style&&(Pt.style.transition="")}catch(o){console.warn("[SelectionMirror] clear activeHighlightEl failed:",o)}Pt=null,Sn=""}if(typeof document<"u"&&typeof document.querySelectorAll=="function")try{document.querySelectorAll(".protyle-wysiwyg [data-node-id].protyle-wysiwyg--select, .protyle-wysiwyg [data-node-id][style*='outline']").forEach(i=>{var s,l;i.classList.remove("protyle-wysiwyg--select");const n=((s=i.style)==null?void 0:s.outline)||"";(n.includes("#3b82f6")||n.includes("rgb(59, 130, 246)")||n.includes("59, 130, 246"))&&(typeof((l=i.style)==null?void 0:l.removeProperty)=="function"?(i.style.removeProperty("outline"),i.style.removeProperty("transition")):i.style&&(i.style.outline="",i.style.transition=""))})}catch{}}function Ro(e,t){var l,r,a,c;if(!e||typeof document>"u")return qi(),!1;qi();const o=(l=globalThis.CSS)!=null&&l.escape?globalThis.CSS.escape(e):e.replace(/"/g,'\\"'),i=document.querySelector(`.protyle-wysiwyg [data-node-id="${o}"]`)||document.querySelector(`[data-node-id="${o}"]`);if(!i){if(t)try{return ie.openTab({app:t,doc:{id:e,action:["cb-get-hl","cb-get-focus","cb-get-context"]}}),!0}catch(u){console.warn("[SelectionMirror] openTab fallback failed:",u)}return!1}try{i.scrollIntoView({behavior:"smooth",block:"center",inline:"nearest"})}catch{(r=i.scrollIntoView)==null||r.call(i)}try{(a=i.focus)==null||a.call(i,{preventScroll:!0})}catch{}const n=((c=i.style)==null?void 0:c.outline)||"";return Sn=n.includes("#3b82f6")||n.includes("rgb(59, 130, 246)")||n.includes("59, 130, 246")?"":n,i.classList.add("protyle-wysiwyg--select"),i.style&&(i.style.outline="2px solid #3b82f6",i.style.transition="outline 0.2s ease"),Pt=i,xn=setTimeout(()=>{qi()},500),!0}function Tl(e){var i,n,s;const t=typeof document<"u"?document:null,o=e||t;if(!o&&!t)return!1;try{const l=(typeof(o==null?void 0:o.querySelectorAll)=="function"?o.querySelectorAll(".protyle-wysiwyg--select"):null)||(typeof(t==null?void 0:t.querySelectorAll)=="function"?t.querySelectorAll(".protyle-wysiwyg--select"):[]);if(l&&l.length>1){const r=new Set;for(let a=0;a<l.length;a++){const c=l[a],u=typeof c.closest=="function"?c.closest("[data-node-id]"):c,f=(i=u==null?void 0:u.getAttribute)==null?void 0:i.call(u,"data-node-id");f?r.add(f):r.add(`elem-${a}`)}if(r.size>1)return!0}}catch{}try{const l=typeof window<"u"?window:globalThis.window,r=typeof(l==null?void 0:l.getSelection)=="function"?l.getSelection():null;if(r&&r.rangeCount>0&&!r.isCollapsed&&typeof r.getRangeAt=="function"){const a=r.getRangeAt(0);if(a){const c=a.startContainer,u=a.endContainer;if(c&&u&&c!==u){const f=c.nodeType===1?c:c.parentElement,p=u.nodeType===1?u:u.parentElement,d=typeof(f==null?void 0:f.closest)=="function"?f.closest("[data-node-id]"):null,b=typeof(p==null?void 0:p.closest)=="function"?p.closest("[data-node-id]"):null,m=(n=d==null?void 0:d.getAttribute)==null?void 0:n.call(d,"data-node-id"),g=(s=b==null?void 0:b.getAttribute)==null?void 0:s.call(b,"data-node-id");if(m&&g&&m!==g)return!0}}}}catch{}return!1}function tg(e){if(!e)return"";const t=e.split(`
`).map(l=>l.trim()).filter(Boolean);if(t.length===0)return"";if(!t.some(l=>/^#{1,6}\s+/.test(l)))return t.map(l=>dt(l)).join("<br/>");const i=[];let n=[];const s=()=>{if(n.length>0){const l=n.map(r=>dt(r)).join("<br/>");i.push(`<p class="slide-list-item-desc">${l}</p>`),n=[]}};for(const l of t){const r=l.match(/^(#{1,6})\s+(.*)$/);if(r){s();const a=r[1].length,c=r[2].trim();i.push(`<h${a} class="slide-list-item-title">${dt(c)}</h${a}>`)}else n.push(l)}return s(),i.join(`
`)}function og(e){if(e.length===0)return"";const t=[],o=e[0],i=o.match(/^(#{1,6})\s+(.*)$/);if(i){const n=i[1].length,s=i[2].trim();t.push(`<h${n} class="slide-list-item-title">${dt(s)}</h${n}>`)}else t.push(`<p class="slide-list-item-title">${dt(o)}</p>`);if(e.length>1){const n=e.slice(1);let s=[];const l=()=>{if(s.length>0){const r=s.map(a=>dt(a)).join("<br/>");t.push(`<p class="slide-list-item-desc">${r}</p>`),s=[]}};for(const r of n){const a=r.match(/^(#{1,6})\s+(.*)$/);if(a){l();const c=a[1].length,u=a[2].trim();t.push(`<h${c} class="slide-list-item-title">${dt(u)}</h${c}>`)}else s.push(r)}l()}return t.join(`
`)+(t.length>0?`
`:"")}function dc(e,t,o){var p,d,b,m;const i=e.split(`
`);if(!i.some(g=>/^(\s*)([-*+]|\d+\.)\s+/.test(g)))return(o!=null&&o.isListItem||(o==null?void 0:o.type)==="i")&&!(o!=null&&o.isColFirst)?`<ul class="slide-list slide-list--unordered">
<li class="slide-list-item">${dt(e)}</li>
</ul>`:null;const s=[],l=[];let r=!1;for(let g=0;g<i.length;g++){const y=i[g];if(!y.trim())continue;const k=y.match(/^(\s*)[-*+]\s+\[([ xX])\]\s+(.*)$/);if(k){const w=k[1].length,_=Math.floor(w/2);l.push({type:"task",level:_,checked:k[2].toLowerCase()==="x",text:k[3],media:[]});continue}const x=y.match(/^(\s*)[-*+]\s+(.*)$/);if(x){const w=x[1].length,_=Math.floor(w/2);l.push({type:"unordered",level:_,text:x[2],media:[]});continue}const $=y.match(/^(\s*)\d+\.\s+(.*)$/);if($){l.length===0&&(r=!0);const w=$[1].length,_=Math.floor(w/2);l.push({type:"ordered",level:_,text:$[2],media:[]});continue}const A=y.trim();if(!(!A||/^\{:.*?\}$/.test(A)))if(l.length>0){const w=A.match(/^!\[(.*?)\]\((.*?)\)(?:\{:?[^}]*\})?$/);if(w){const H=/\.gif(?:\?|$)/i.test(w[2])?"list-item-gif":"list-item-img";l[l.length-1].media||(l[l.length-1].media=[]),l[l.length-1].media.push(`<div class="slide-list-media"><img alt="${st(w[1])}" src="${w[2]}" class="${H}" /></div>`);continue}if(A.match(/^<img\b[\s\S]*?\/?>$/i)){const O=A.replace(/\s+style="[^"]*"/gi,"");l[l.length-1].media||(l[l.length-1].media=[]),l[l.length-1].media.push(`<div class="slide-list-media">${O}</div>`);continue}if(/<video\b/i.test(A)){let O=A;if(!/<\/video>/i.test(O))for(;g+1<i.length&&!/<\/video>/i.test(O);)g++,O+=" "+i[g].trim();const H=((p=o==null?void 0:o.attributes)==null?void 0:p["custom-slides-autoplay"])==="true"||/autoplay/i.test(O),P=((d=o==null?void 0:o.attributes)==null?void 0:d["custom-slides-loop"])==="true"||/loop/i.test(O),F=((b=o==null?void 0:o.attributes)==null?void 0:b["custom-slides-muted"])==="true"||H||/muted/i.test(O),E=((m=o==null?void 0:o.attributes)==null?void 0:m["custom-slides-controls"])==="false",D=O.match(/\bsrc=["']([^"']+)["']/i),S=D?D[1]:"",q=['class="slide-video-player"'];E||q.push("controls"),H&&(q.push("autoplay"),q.push("playsinline")),P&&q.push("loop"),F&&q.push("muted"),q.push('preload="metadata"'),S&&q.push(`src="${S}"`);const j=O.match(/<video[^>]*>([\s\S]*?)<\/video>/i);let C=j?j[1].trim():"";!C&&S&&(C=`<source src="${S}" type="video/mp4" />您的浏览器不支持视频播放。`),l[l.length-1].media||(l[l.length-1].media=[]),l[l.length-1].media.push(`<div class="slide-list-media slide-video-container slide-media-container" data-autoplay="${H?"true":"false"}" data-muted="${F?"true":"false"}"><video ${q.join(" ")}>${C}</video></div>`);continue}l[l.length-1].text+=`
`+A}else s.push(A)}if(l.length===0)return null;const a=r?"ol":"ul",c=(t==null?void 0:t.listClassName)||(r?"pdf-list pdf-list--ordered":"pdf-list pdf-list--unordered"),u=l.map(g=>{const y=tg(g.text),k=g.media&&g.media.length>0?`
${g.media.join(`
`)}`:"",x=g.level||0,$=x>0?` style="margin-left:${(x*1.25).toFixed(2)}em;${g.type==="unordered"?`list-style-type:${x%2===1?"circle":"square"} !important;`:""}"`:"",A=x>0?" slide-list-item--nested":"";if(g.type==="task"){const _=g.checked?' checked=""':"";return`<li class="pdf-task-item${A}"${$}><label><input type="checkbox" disabled=""${_}/> <span>${y}</span></label>${k}</li>`}return`<li${A?` class="${A.trim()}"`:""}${$}>${y}${k}</li>`}).join(`
`);return`${og(s)}<${a} class="${c}">
${u}
</${a}>`}function ig(e,t,o){const i=(t==null?void 0:t.containerClassName)||"pdf-block",n=e.split(/\r?\n/),s=[];let l=[];for(let c=0;c<n.length;c++){const u=n[c],f=u.trim();if(/^#{1,6}\s+/.test(f)){l.length>0&&(s.push(l.join(`
`)),l=[]),s.push(f);continue}if(!f){l.length>0&&(s.push(l.join(`
`)),l=[]);continue}if(/^!\[.*?\]\(.*?\)$/.test(f)){l.length>0&&(s.push(l.join(`
`)),l=[]),s.push(f);continue}if(/<video\b/i.test(f)){l.length>0&&(s.push(l.join(`
`)),l=[]);let p=f;if(!/<\/video>/i.test(p))for(;c+1<n.length&&!/<\/video>/i.test(p);)c++,p+=`
`+n[c];s.push(p);continue}l.push(u)}l.length>0&&s.push(l.join(`
`));let r=!0;return s.map(c=>{var b,m,g,y;const u=c.trim();if(!u)return"";const f=u.match(/^(#{1,6})\s+(.*)$/);if(f){r=!1;const k=f[1].length;return`<h${k} class="slide-list-item-title">${dt(f[2].trim())}</h${k}>`}const p=u.match(/^!\[(.*?)\]\((.*?)\)$/);if(p){const k=/\.gif(?:\?|$)/i.test(p[2]),x=(t==null?void 0:t.imageClassName)||(k?"list-item-gif":"pdf-image slide-media-img");return`<div class="${i} ${i}--image slide-media-block slide-media-container slide-list-media"><img alt="${st(p[1])}" src="${p[2]}" class="${x}" /></div>`}if(/<video\b/i.test(u)){const k=((b=o==null?void 0:o.attributes)==null?void 0:b["custom-slides-autoplay"])==="true"||/autoplay/i.test(u),x=((m=o==null?void 0:o.attributes)==null?void 0:m["custom-slides-loop"])==="true"||/loop/i.test(u),$=((g=o==null?void 0:o.attributes)==null?void 0:g["custom-slides-muted"])==="true"||k||/muted/i.test(u),A=((y=o==null?void 0:o.attributes)==null?void 0:y["custom-slides-controls"])==="false",w=u.match(/\bsrc=["']([^"']+)["']/i),_=w?w[1]:"",O=['class="slide-video-player"'];A||O.push("controls"),k&&O.push("autoplay playsinline"),x&&O.push("loop"),$&&O.push("muted"),O.push('preload="metadata"'),_&&O.push(`src="${_}"`);const H=u.match(/<video[^>]*>([\s\S]*?)<\/video>/i);let P=H?H[1].trim():"";return!P&&_&&(P=`<source src="${_}" type="video/mp4" />您的浏览器不支持视频播放。`),`<div class="${i} ${i}--video slide-media-block slide-video-container slide-media-container" data-autoplay="${k?"true":"false"}" data-muted="${$?"true":"false"}"><video ${O.join(" ")}>${P}</video></div>`}const d=dc(u,t,o);if(d)return r=!1,d;if(r){r=!1;const k=u.split(/\r?\n/).map(w=>w.trim()).filter(Boolean);if(k.length===1)return`<p class="slide-list-item-title">${dt(k[0])}</p>`;const x=k[0],A=k.slice(1).map(w=>dt(w)).join("<br/>");return`<p class="slide-list-item-title">${dt(x)}</p>
<p class="slide-list-item-desc">${A}</p>`}return`<p class="slide-list-item-desc">${dt(u)}</p>`}).filter(Boolean).join(`
`)}function ws(e){if(!e)return!1;if(e.type==="h"||e.type==="NodeHeading")return!0;const t=(e.rawMarkdown||e.content||"").trim();return/^#{1,6}\s+/.test(t)}function uc(e,t){var r,a,c,u,f,p,d,b;const o=((r=e.frontmatter)==null?void 0:r.layout)||"default",n=(e.blocks||[]).filter(m=>m.slot!=="slot-divider-right"),l=o==="cover"?null:n.find(ws);if(o==="two-cols"){const m=n.some(F=>F.slot==="right");let g=[],y=[];if(m)g=n.filter(F=>F.slot!=="right"),y=n.filter(F=>F.slot==="right");else{const F=Math.ceil(n.length/2);g=n.slice(0,F),y=n.slice(F)}const k=F=>{const E=F.filter(D=>!!(D.rawMarkdown||D.content||"").trim());if(E.length>0){const D=E[0],S=(D.rawMarkdown||D.content||"").trim();(jo(D)||/^(?:[-*+]|\d+\.)\s+/.test(S))&&(D.rawMarkdown=ji(D.rawMarkdown||D.content||""),D.content=D.rawMarkdown)}};k(g),k(y);const x=g.map(F=>Mo(F,t)).join(`
`),$=y.map(F=>Mo(F,t)).join(`
`),A=(t==null?void 0:t.twoColsWrapperClass)||"pdf-two-cols-wrapper layout-two-cols-grid",w=(a=e.frontmatter)!=null&&a.layoutClass?` ${e.frontmatter.layoutClass}`:"",_=(t==null?void 0:t.leftColClass)||"pdf-col pdf-col--left",O=(t==null?void 0:t.rightColClass)||"pdf-col pdf-col--right",P=`style="grid-template-columns: ${vs((c=e.frontmatter)==null?void 0:c.layoutRatio,2)};"`;return`
      <div class="${A}${w}" ${P}>
        <div class="${_}">${x}</div>
        <div class="${O}">${$}</div>
      </div>
    `}if(o==="clover"||fi(o)){const m=o==="clover";let g=[];const y=n.filter(q=>q.slot==="header");if(y.length>0)g=y;else if(n.length>0){const q=n.find(j=>j.type==="h"&&(!j.slot||j.slot==="default"));q&&(g=[q])}const k=n.filter(q=>!g.includes(q));let x=2;if(m)x=4;else if(o==="three-cols-header")x=3;else if(o==="two-cols-header")x=2;else{let q=0;for(const j of k){const C=(j.slot||"").match(/^col-(\d+)$/i);C&&(q=Math.max(q,parseInt(C[1],10)))}if(q>=2)x=q;else if((u=e.frontmatter)!=null&&u.layoutRatio){const j=e.frontmatter.layoutRatio.trim();if(j.includes(":")){const C=j.split(":").map(M=>parseFloat(M.trim())).filter(M=>!isNaN(M)&&M>0);C.length>=2&&(x=C.length)}else{const C=j.split(/\s+/).filter(Boolean);C.length>=2&&(x=C.length)}}else k.length===1&&k[0].children&&k[0].children.length>=2&&(x=Math.min(6,k[0].children.length))}const $=Ks(k,x),A=k.some(q=>q.slot&&/^(?:col-\d+|left|right)$/i.test(q.slot)),w=o==="clover"||o==="two-cols-header"||o==="three-cols-header"||fi(o)&&A,_=q=>{const j=q.filter(M=>!!(M.rawMarkdown||M.content||"").trim());if(w&&j.length>0){const M=j[0],B=(M.rawMarkdown||M.content||"").trim();(jo(M)||/^(?:[-*+]|\d+\.)\s+/.test(B))&&(M.rawMarkdown=ji(M.rawMarkdown||M.content||""),M.content=M.rawMarkdown),M.isColFirst=!0}const C=w?j.find(ws):null;return j.map(M=>Mo(M,{...t,extraClassName:M===C?"slides-col-first-heading-block":""})).join(`
`)},O=g.find(ws),H=g.map(q=>Mo(q,{...t,extraClassName:q===O?"slides-page-first-heading-block":""})).join(`
`),P=m?"repeat(2, minmax(0, 1fr))":vs((f=e.frontmatter)==null?void 0:f.layoutRatio,x),F=m?`style="grid-template-columns: ${P}; grid-template-rows: repeat(2, minmax(0, 1fr));"`:`style="grid-template-columns: ${P};"`,E=[m?"layout-clover-container":"layout-cols-header-container",x===2?"layout-two-cols-header-container":"",x===3?"layout-three-cols-header-container":"",`layout-${o}-container`,w?"has-superblock-cols":""].filter(Boolean).join(" "),D=[m?"layout-clover-grid pdf-clover-wrapper":"layout-cols-wrapper layout-cols-grid",x===2?"pdf-two-cols-wrapper layout-two-cols-grid":"",x===3?"pdf-three-cols-wrapper layout-three-cols-grid":"",w?"has-superblock-cols":""].filter(Boolean).join(" "),S=$.map((q,j)=>{const C=j+1;return`<div class="${["pdf-col",x===2&&C===1?"pdf-col--left":"",x===2&&C===2?"pdf-col--right":"",`pdf-col--${C}`,`col-${C}`].filter(Boolean).join(" ")}">${_(q)}</div>`}).join(`
`);return`
      <div class="${E}">
        <div class="layout-header-section">${H}</div>
        <div class="${D}" ${F}>
          ${S}
        </div>
      </div>
    `}if(o==="image-right"||o==="image-left"){const m=o==="image-right",g=n.map(w=>Mo(w,t)).join(`
`),y=((p=e.frontmatter)==null?void 0:p.image)||((d=e.frontmatter)==null?void 0:d.background)||"",k=`<div class="pdf-image-col" style="background-image:url('${st(y)}');background-size:cover;background-position:center;background-repeat:no-repeat;width:100%;height:100%;position:relative;overflow:hidden;"><img src="${st(y)}" style="width:100%;height:100%;object-fit:cover;object-position:center;display:block;" onerror="this.style.display='none'" alt="Slide cover" /></div>`,x=`<div class="pdf-content-col" style="padding:48px 56px;display:flex;flex-direction:column;justify-content:flex-start;height:100%;box-sizing:border-box;overflow-y:auto;">${g}</div>`,$=m?`${x}
${k}`:`${k}
${x}`;return`
      <div class="layout-image-cols-grid" style="display:grid;grid-template-columns:${vs((b=e.frontmatter)==null?void 0:b.layoutRatio,2)};grid-template-rows:100%;width:100%;height:100%;position:absolute;top:0;left:0;right:0;bottom:0;box-sizing:border-box;">
        ${$}
      </div>
    `}return o==="fact"?`<div class="layout-fact-container">${n.map(g=>Mo(g,t)).join(`
`)}</div>`:o==="cover"?`<div class="layout-cover-container">${n.map(g=>Mo(g,t)).join(`
`)}</div>`:n.map(m=>Mo(m,{...t,extraClassName:m===l?"slides-page-first-heading-block":""})).join(`
`)}function st(e){return e?e.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&#039;"):""}function ng(e){if(!e||e.trim()===""||e.trim()==="all")return"all";const t=new Set,o=e.split("|");for(const i of o){const n=i.trim();if(n==="all")return"all";if(n.includes("-")){const[s,l]=n.split("-"),r=parseInt(s,10),a=parseInt(l,10);if(!isNaN(r)&&!isNaN(a))for(let c=Math.min(r,a);c<=Math.max(r,a);c++)t.add(c)}else{const s=parseInt(n,10);isNaN(s)||t.add(s)}}return t}const sg=new Set(["kbd","mark","sub","sup","span","a","br","b","i","u","s","del","em","strong","code","small","abbr","ruby","rt","rp","v-mark","img","video","source","picture"]);function dt(e){if(!e)return"";const t=ic(e),o=[],i=t.replace(/<\/?([a-zA-Z0-9_-]+)(?:\s+[^<>]*)?\/?>/g,(s,l)=>{const r=l.toLowerCase();if(!sg.has(r)||/on\w+\s*=|javascript:/i.test(s))return s;if(r==="v-mark"){const a=s.match(/type=["']?([a-zA-Z-]+)["']?/),c=a?a[1]:"circle";return s.startsWith("</")?o.push("</mark>"):o.push(`<mark class="v-mark v-mark--${c}">`),`%%SAFE_HTML_${o.length-1}%%`}return o.push(s),`%%SAFE_HTML_${o.length-1}%%`});let n=st(i);return n=n.replace(/\(\(([0-9a-zA-Z-]+)(?:\s*(?:&#039;([^&#]*)&#039;|&quot;([^&]*)&quot;|'([^']*)'|"([^"]*)"|([^\)]+?)))?\s*\)\)/g,(s,l,r,a,c,u,f)=>{const d=(r??a??c??u??f??"").trim()||`Ref(${l.slice(0,8)})`;return`<a href="siyuan://blocks/${l}" data-ref-id="${l}" class="slides-ref-tag">🔗 ${d}</a>`}),n=n.replace(/\$([^$\n]+)\$/g,'<span class="katex-inline font-math"><em>$1</em></span>'),n=n.replace(/!\[(.*?)\]\((.*?)\)/g,(s,l,r)=>{const c=/\.gif(?:\?|$)/i.test(r)?"slide-inline-img list-item-gif":"slide-inline-img";return`<img alt="${l}" src="${r}" class="${c}" />`}),n=n.replace(/\[(.*?)\]\((.*?)\)/g,(s,l,r)=>{if(r.startsWith("siyuan://blocks/")){const a=r.replace("siyuan://blocks/","").split("?")[0];return`<a href="${r}" data-ref-id="${a}" class="slides-ref-tag">🔗 ${l}</a>`}return`<a href="${r}" target="_blank" rel="noopener noreferrer" class="slides-link">${l}</a>`}),n=n.replace(/(^|[\s(])(siyuan:\/\/blocks\/([0-9a-zA-Z-]+)(?:\?[^\s\)]*)?)/g,(s,l,r,a)=>`${l}<a href="${r}" data-ref-id="${a}" class="slides-ref-tag">🔗 ${r}</a>`),n=n.replace(/\*\*(.*?)\*\*/g,"<strong>$1</strong>"),n=n.replace(/\*(.*?)\*/g,"<em>$1</em>"),n=n.replace(/~~(.*?)~~/g,"<del>$1</del>"),n=n.replace(/`([^`]+)`/g,"<code>$1</code>"),n=n.replace(/%%SAFE_HTML_(\d+)%%/g,(s,l)=>{const r=parseInt(l,10);return o[r]||""}),n}function rg(e,t="pdf-table"){if(e.length<2)return"";const o=e.map(a=>a.trim().replace(/^\|/,"").replace(/\|$/,"").split("|").map(c=>c.trim())),i=o[0];let n=[],s=1;e.length>=2&&o[1].every(a=>/^:?-+:?$/.test(a))&&(n=o[1].map(a=>a.startsWith(":")&&a.endsWith(":")?"center":a.endsWith(":")?"right":"left"),s=2);const l=`<thead><tr>${i.map((a,c)=>`<th${n[c]?` style="text-align: ${n[c]}"`:""}>${dt(a)}</th>`).join("")}</tr></thead>`,r=o.slice(s).map(a=>`<tr>${a.map((c,u)=>`<td${n[u]?` style="text-align: ${n[u]}"`:""}>${dt(c)}</td>`).join("")}</tr>`).join("");return`<table class="${t}">${l}<tbody>${r}</tbody></table>`}function xs(e){return String(e||"").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;")}function Al(e,t="ts"){if(!e)return"";if(e.trim().startsWith("//"))return`<span class="token-comment">${xs(e)}</span>`;const o=[];function i(s,l){return o.push(`<span class="${s}">${xs(l)}</span>`),`__TOK_${o.length-1}__`}let n=e.replace(/(['"`])(.*?)\1/g,(s,l,r)=>i("token-string",`${l}${r}${l}`));return n=n.replace(/\b(import|export|from|const|let|var|function|return|default|type|interface|class|new|async|await)\b/g,s=>i("token-keyword",s)),n=n.replace(/\b(computed|ref|number|string|boolean|void|Array)\b/g,s=>i("token-type",s)),n=n.replace(/\b(\d+)\b/g,s=>i("token-number",s)),n=xs(n),n=n.replace(/__TOK_(\d+)__/g,(s,l)=>o[parseInt(l,10)]||""),n}function lg(e,t){if(!e)return null;const o=e.frontmatter||{};if(o.hideInToc===!0||o.hideInToc==="true")return null;let i=(o.title||"").trim(),n=o.level?parseInt(o.level,10):0;if(!i){const s=e.blocks||[];for(const l of s){const a=(l.rawMarkdown||l.content||"").trim().match(/^(#{1,6})\s+(.*)$/);if(a){n||(n=a[1].length),i=a[2].trim();break}}}return i?((!n||isNaN(n))&&(n=1),{pageIndex:e.pageIndex||t,title:i,level:n}):null}function ag(e,t=1,o={}){const i=o.minDepth!==void 0?Number(o.minDepth):1,n=o.maxDepth!==void 0?Number(o.maxDepth):1/0,s=[];Array.isArray(e)&&e.forEach((c,u)=>{const f=lg(c,u+1);f&&s.push(f)});const l=[];let r=null;for(const c of s){const u={...c,active:c.pageIndex===t,hasActiveChild:!1,children:[]};c.level===1||l.length===0?(l.push(u),r=u):r?(u.active&&(r.hasActiveChild=!0),r.children.push(u)):l.push(u)}function a(c,u=1){if(u>n)return[];const f=[];for(const p of c){const d=a(p.children,u+1);u>=i?f.push({...p,children:d}):f.push(...d)}return f}return a(l,1)}function cg(e,t=1,o={}){const i=ag(e,t,o),n=o.columns?Number(o.columns):1,s=n>1?` style="column-count: ${n};"`:"",l=o.textSm?" text-sm":"";function r(c,u=1){if(!c||c.length===0)return"";const f=`slides-toc-list slides-toc-list-level-${u}`,p=c.map(d=>{const b=d.active?" slides-toc-item-active":d.hasActiveChild?" slides-toc-item-parent-active":"",m=d.children&&d.children.length>0?r(d.children,u+1):"";let g=dt(d.title);return g.includes("LaTeX")&&(g=g.replace(/\$\\LaTeX\$/g,'<span class="font-math">L<sup>A</sup>T<sub>E</sub>X</span>')),`
        <li class="slides-toc-item${b}" data-page="${d.pageIndex}">
          <a class="slides-toc-link" href="javascript:void(0)">
            <span class="slides-toc-title">${g}</span>
          </a>
          ${m}
        </li>
      `}).join("");return`<ol class="${f}">${p}</ol>`}const a=r(i,1);return`<div class="slides-toc${l}"${s}>${a}</div>`}function Mo(e,t){var A,w,_,O,H,P,F,E,D,S,q,j;let o="",i="",n="";const s=[];(A=e.motion)!=null&&A.preset&&e.motion.preset!=="none"&&(o=` slides-motion-${e.motion.preset.toLowerCase()}`,typeof e.motion.duration=="number"&&e.motion.duration>0&&s.push(`--motion-duration:${e.motion.duration}ms`),typeof e.motion.delay=="number"&&e.motion.delay>0&&s.push(`--motion-delay:${e.motion.delay}ms`));const l=((w=e.attributes)==null?void 0:w.style)||"";l&&(s.push(l),n=" slide-styled-block"),s.length>0&&(i=` style="${st(s.join(";"))}"`);const r=(t==null?void 0:t.containerClassName)||"pdf-block",a=t!=null&&t.extraClassName?` ${t.extraClassName}`:"",c=t!=null&&t.blockClassResolver?t.blockClassResolver(e):"",u=c?` ${c}`:"",f=`${r}${o}${n}${a}${u}`,p=(e.rawMarkdown||e.content||"").trim();if(!p)return`<div class="${f}"${i}></div>`;if(p.includes('class="slides-block-ref"')||p.includes('class="slides-ref-tag"'))return`<div class="${f}"${i}>${p}</div>`;if(p.startsWith("$$")&&p.endsWith("$$")){const C=p.slice(2,-2).trim();return`<div class="${f} katex-display-container"${i}><div class="katex-display font-math"><em>${st(C)}</em></div></div>`}const d=p.match(/^(#{1,6})\s+(.*)$/);if(d){const C=d[1].length,M=dt(d[2]),te=!!(e.isColFirst||e.type==="i"&&((_=t==null?void 0:t.extraClassName)!=null&&_.includes("slides-col-first-heading-block")))?' class="slide-list-item-title"':"";return`<div class="${f}"${i}><h${C}${te}>${M}</h${C}></div>`}if(p.startsWith(":::")){const C=p.split(`
`),B=C[0].replace(/^:::\s*/,"").trim()||"info",te=C.slice(1,C[C.length-1].startsWith(":::")?-1:void 0).join(`
`),V=(t==null?void 0:t.calloutClassName)||"pdf-callout";return`<div class="${f}"${i}><div class="${V} ${V}--${B}"><div class="${V}-title">${B.toUpperCase()}</div><div class="${V}-body">${dt(te)}</div></div></div>`}if(p.startsWith("<<<")){const B=`// Inside ./snippets/external.ts
export function emptyArray<T>(length: number) {
  return Array.from<T>({ length })
}`.split(`
`).map((oe,re)=>`<span class="code-line shiki-focus"><span class="line-no">${re+1}</span><span class="line-content">${Al(oe,"ts")}</span></span>`).join(`
`),te=(t==null?void 0:t.codeClassName)||"pdf-code shiki-container",V=((O=e.attrs)==null?void 0:O["custom-slides-max-height"])||((H=e.attributes)==null?void 0:H["custom-slides-max-height"])||e.maxHeight||"",K=Vs(String(V||"")),ae=K?` style="max-height:${st(K)};overflow-y:auto;"`:"";return`<div class="${f}"${i}><pre class="${te}"${ae}><span class="lang-badge">TS</span><code>${B}</code></pre></div>`}if(p.startsWith("<style")||p.startsWith("<!-- Inline style -->")||p.startsWith(`<!--
Notes`))return"";if(p.startsWith("```")){const C=p.split(`
`),M=C[0].slice(3).trim(),B=M.match(/^([^\s{\[]+)/),te=B?B[1]:"",V=M.match(/\[([^\]]+)\]/),K=V?V[1]:"",ae=M.includes("twoslash"),oe=e.shikiLines||((P=M.match(/\{([^}]+)\}/))==null?void 0:P[1])||"",re=ng(oe),Se=C.length>2?C[C.length-1]==="```"?C.slice(1,-1):C.slice(1):[p.slice(3).replace(/```$/,"")],$e=(t==null?void 0:t.codeClassName)||"pdf-code shiki-container",ke=K?`${$e} has-filename`:$e,_e=re!=="all",R=Se.map((z,I)=>{const T=I+1,Y=re==="all"||re.has(T)?"code-line shiki-focus":_e?"code-line shiki-dimmed":"code-line";let Z=(t==null?void 0:t.highlight)===!0?Al(z,te):st(z);return ae&&z.includes("doubled.value = 2")?(Z=Z.replace(/(\bvalue\b)/,'<span class="twoslash-error-wavy">$1</span>'),`<span class="${Y}"><span class="line-no">${T}</span><span class="line-content">${Z}</span></span>
<div class="twoslash-popup-error"><span style="color:#ef4444;font-weight:bold;margin-right:4px;">✕</span> Cannot assign to 'value' because it is a read-only property.</div>`):`<span class="${Y}"><span class="line-no">${T}</span><span class="line-content">${Z}</span></span>`}).join(`
`),ne=te?`<span class="lang-badge">${st(te)}</span>`:"",L=K?`<span class="code-filename">${st(K)}</span>`:"",U=((F=e.attrs)==null?void 0:F["custom-slides-max-height"])||((E=e.attributes)==null?void 0:E["custom-slides-max-height"])||e.maxHeight||"",v=Vs(String(U||"")),W=v?` style="max-height:${st(v)};overflow-y:auto;"`:"";return`<div class="${f}"${i}><pre class="${ke}"${W}>${L}${ne}<code>${R}</code></pre></div>`}if(p.includes("|")&&p.split(`
`).filter(C=>C.trim().startsWith("|")).length>=2){const C=p.split(`
`).filter(B=>B.trim().startsWith("|")),M=rg(C,t==null?void 0:t.tableClassName);return`<div class="${f}"${i}>${M}</div>`}if(p.startsWith("> ")){const C=(t==null?void 0:t.quoteClassName)||"pdf-quote";return`<div class="${f}"${i}><blockquote class="${C}"><p>${dt(p.slice(2))}</p></blockquote></div>`}const b=/<video\b/i.test(p)||e.type==="video"||e.type==="NodeVideo",m=/^(\s*)([-*+]|\d+\.)\s+/m.test(p),g=/(?:^|\n)\s*#{1,6}\s+/.test(p);if(b&&!m&&!g&&!p.includes(`
`)){const C=((D=e.attributes)==null?void 0:D["custom-slides-autoplay"])==="true"||/autoplay/i.test(p),M=((S=e.attributes)==null?void 0:S["custom-slides-loop"])==="true"||/loop/i.test(p),B=((q=e.attributes)==null?void 0:q["custom-slides-muted"])==="true"||C||/muted/i.test(p),te=((j=e.attributes)==null?void 0:j["custom-slides-controls"])==="false",V=p.match(/\bsrc=["']([^"']+)["']/i),K=V?V[1]:"",ae=['class="slide-video-player"'];te||ae.push("controls"),C&&(ae.push("autoplay"),ae.push("playsinline")),M&&ae.push("loop"),B&&ae.push("muted"),ae.push('preload="auto"'),K&&ae.push(`src="${K}"`);const oe=p.match(/<video[^>]*>([\s\S]*?)<\/video>/i);let re=oe?oe[1].trim():"";return!re&&K&&(re=`<source src="${K}" type="video/mp4" />您的浏览器不支持视频播放。`),`<div class="${f} ${f}--video slide-media-block slide-video-container slide-media-container" data-autoplay="${C?"true":"false"}" data-muted="${B?"true":"false"}"${i}><video ${ae.join(" ")}>${re}</video></div>`}const y=p.match(/^!\[(.*?)\]\((.*?)\)$/);if(y){const C=(t==null?void 0:t.imageClassName)||"pdf-image slide-media-img";return`<div class="${f} ${f}--image slide-media-block slide-media-container"${i}><img alt="${st(y[1])}" src="${y[2]}" class="${C}" /></div>`}const k=dc(p,t,e);if(k)return`<div class="${f} pdf-list-item"${i}>${k}</div>`;if(/<(?:Toc|toc)\b/i.test(p)&&!p.startsWith("```")){const C=p.match(/minDepth=["']?(\d+)["']?/i),M=p.match(/maxDepth=["']?(\d+)["']?/i),B=p.match(/columns=["']?(\d+)["']?/i),te=(t==null?void 0:t.allSlides)||[];return`<div class="${f}"${i}>${cg(te,(t==null?void 0:t.currentPageIndex)||1,{minDepth:C?parseInt(C[1],10):1,maxDepth:M?parseInt(M[1],10):1/0,columns:B?parseInt(B[1],10):1,textSm:p.includes("text-sm")})}</div>`}if(p.includes(`
`)||g){const C=ig(p,t,e);if(C)return`<div class="${f}"${i}>${C}</div>`}const $=!!e.isColFirst?' class="slide-list-item-title"':"";return`<div class="${f}"${i}><p${$}>${dt(p)}</p></div>`}function dg(e){return`
    ${Wi(e)}

    :root {
      --slide-bg: #ffffff;
      --slide-text: #1a1a1a;
      --slide-accent: #3b82f6;
      --slide-font: system-ui, -apple-system, sans-serif;
    }
    [data-theme="dark"] {
      --slide-bg: #121214;
      --slide-text: #e2e8f0;
      --slide-accent: #60a5fa;
    }

    /* 1. 默认科技主题 Default (Modern Tech / Digital Geek) */
    [data-slides-theme="tech"],
    .slides-theme-tech {
      --slide-font: system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "PingFang SC", "Microsoft YaHei", sans-serif;
      --slide-accent: #10b981;
      --slide-accent-secondary: #06b6d4;
    }
    [data-theme="light"][data-slides-theme="tech"],
    [data-theme="light"] .slides-theme-tech,
    .slide-viewport[data-theme="light"].slides-theme-tech,
    .slide-viewport[data-theme="light"] {
      --slide-bg: #f8fafc;
      --slide-text: #0f172a;
      --slide-text-secondary: #475569;
      --slide-code-bg: #f1f5f9;
      --slide-code-border: rgba(15, 23, 42, 0.12);
      --slide-accent: #059669;
      --slide-accent-secondary: #0284c7;
      --slide-card-bg: rgba(255, 255, 255, 0.85);
      --slide-card-border: rgba(148, 163, 184, 0.35);
      --slide-card-shadow: 0 4px 14px rgba(15, 23, 42, 0.06);
    }
    [data-theme="dark"][data-slides-theme="tech"],
    [data-theme="dark"] .slides-theme-tech,
    .slide-viewport[data-theme="dark"].slides-theme-tech,
    .slide-viewport:not([data-theme="light"]) {
      --slide-bg: #090d16;
      --slide-text: #f1f5f9;
      --slide-text-secondary: #94a3b8;
      --slide-code-bg: #0f172a;
      --slide-code-border: rgba(56, 189, 248, 0.22);
      --slide-accent: #10b981;
      --slide-accent-secondary: #38bdf8;
      --slide-card-bg: rgba(15, 23, 42, 0.7);
      --slide-card-border: rgba(56, 189, 248, 0.2);
      --slide-card-shadow: 0 6px 20px rgba(0, 0, 0, 0.35);
    }
    /* 单页为 light 时高特异性覆盖，即使外层是 dark 也强制生效 */
    [data-theme="dark"] .slide-viewport[data-theme="light"],
    .slide-viewport[data-theme="light"] {
      color: var(--slide-text) !important;
    }
    [data-theme="dark"] .slide-viewport[data-theme="light"].slides-theme-tech,
    .slide-viewport[data-theme="light"].slides-theme-tech {
      --slide-text: #0f172a !important;
      --slide-text-secondary: #475569 !important;
      --slide-accent: #059669 !important;
    }
    [data-theme="dark"] .slide-viewport[data-theme="light"].slides-theme-seriph,
    .slide-viewport[data-theme="light"].slides-theme-seriph {
      --slide-text: #231f1d !important;
      --slide-text-secondary: #57534e !important;
      --slide-accent: #b45309 !important;
    }
    [data-theme="dark"] .slide-viewport[data-theme="light"].slides-theme-apple-basic,
    .slide-viewport[data-theme="light"].slides-theme-apple-basic {
      --slide-text: #000000 !important;
      --slide-text-secondary: #6e6e73 !important;
      --slide-accent: #0071e3 !important;
    }
    /* 单页为 dark 时高特异性覆盖，即使外层是 light 也强制生效 */
    [data-theme="light"] .slide-viewport[data-theme="dark"],
    .slide-viewport[data-theme="dark"] {
      color: var(--slide-text) !important;
    }
    [data-theme="light"] .slide-viewport[data-theme="dark"].slides-theme-tech,
    .slide-viewport[data-theme="dark"].slides-theme-tech {
      --slide-text: #f1f5f9 !important;
      --slide-text-secondary: #94a3b8 !important;
      --slide-accent: #10b981 !important;
    }
    [data-theme="light"] .slide-viewport[data-theme="dark"].slides-theme-seriph,
    .slide-viewport[data-theme="dark"].slides-theme-seriph {
      --slide-text: #f5f2eb !important;
      --slide-text-secondary: #a8a29e !important;
      --slide-accent: #f59e0b !important;
    }
    [data-theme="light"] .slide-viewport[data-theme="dark"].slides-theme-apple-basic,
    .slide-viewport[data-theme="dark"].slides-theme-apple-basic {
      --slide-text: #ffffff !important;
      --slide-text-secondary: #86868b !important;
      --slide-accent: #2997ff !important;
    }
    .slides-theme-tech .layout-cover h1,
    .slides-theme-tech .layout-cover .slide-block h1 {
      font-size: 3.8rem !important;
      font-weight: 800 !important;
      line-height: 1.15 !important;
      letter-spacing: -0.025em !important;
      margin-bottom: 18px !important;
      background: linear-gradient(135deg, var(--slide-accent), var(--slide-accent-secondary)) !important;
      -webkit-background-clip: text !important;
      -webkit-text-fill-color: transparent !important;
    }
    .slides-theme-tech .layout-cover h2,
    .slides-theme-tech .layout-cover .slide-block h2 {
      font-size: 1.85rem !important;
      font-weight: 600 !important;
      color: var(--slide-text-secondary) !important;
      margin-bottom: 12px !important;
    }
    .slides-theme-tech .layout-cover p,
    .slides-theme-tech .layout-cover .slide-block p {
      font-size: 1.45rem !important;
      line-height: 1.5 !important;
      color: var(--slide-text-secondary) !important;
    }
    /* 默认科技风：内容页顶部标题带 Accent 垂直指示条与柔和横向高亮底衬 */
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h1,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h2,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h3,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h1,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h2,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h3,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h1,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h2,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h3,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h1,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h2,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h3,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) > .slide-block:first-child h1,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) > .slide-block:first-child h2,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) > .slide-block:first-child h3,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h1,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h2,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h3,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .slide-block:first-child h1,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .slide-block:first-child h2,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .slide-block:first-child h3,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .slide-block:first-child h1,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .slide-block:first-child h2,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .slide-block:first-child h3,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-left-content > .slide-block:first-child h1,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-left-content > .slide-block:first-child h2,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-left-content > .slide-block:first-child h3,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-right-content > .slide-block:first-child h1,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-right-content > .slide-block:first-child h2,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-right-content > .slide-block:first-child h3,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .slide-block:first-child h1,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .slide-block:first-child h2,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .slide-block:first-child h3,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .slide-block:first-child h1,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .slide-block:first-child h2,
    .slides-theme-tech .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .slide-block:first-child h3 {
      color: var(--slide-accent);
      border-left: 4px solid var(--slide-accent);
      padding: 4px 14px;
      padding-left: 14px;
      background: linear-gradient(90deg, color-mix(in srgb, var(--slide-accent) 13%, transparent), transparent 76%);
      border-radius: 0 6px 6px 0;
      letter-spacing: -0.015em;
    }
    .slides-theme-tech blockquote {
      border-left: 3px solid var(--slide-accent) !important;
      background: color-mix(in srgb, var(--slide-accent) 8%, transparent) !important;
      border-radius: 4px;
      padding: 12px 18px !important;
    }
    .slides-theme-tech pre {
      border: 1px solid var(--slide-code-border) !important;
      box-shadow: 0 4px 16px rgba(0, 0, 0, 0.18) !important;
      border-radius: 8px !important;
    }

    /* 2. 优雅衬线主题 Seriph (典雅学术书卷风) */
    [data-slides-theme="seriph"],
    .slides-theme-seriph {
      --slide-font: "PT Serif", "Charter", "Georgia", "Cambria", "Times New Roman", "Source Han Serif SC", "Noto Serif SC", "Songti SC", "SimSun", serif;
      --slide-accent: #b45309;
      --slide-accent-secondary: #9a3412;
      letter-spacing: 0.02em;
    }
    [data-theme="light"][data-slides-theme="seriph"],
    [data-theme="light"] .slides-theme-seriph {
      --slide-bg: #fcfbf7;
      --slide-text: #231f1d;
      --slide-text-secondary: #57534e;
      --slide-code-bg: #f5f0e6;
      --slide-code-border: rgba(180, 83, 9, 0.2);
      --slide-accent: #b45309;
      --slide-accent-secondary: #9a3412;
      --slide-card-bg: rgba(255, 255, 255, 0.75);
      --slide-card-border: rgba(180, 83, 9, 0.25);
      --slide-card-shadow: 0 2px 10px rgba(41, 37, 36, 0.04);
    }
    [data-theme="dark"][data-slides-theme="seriph"],
    [data-theme="dark"] .slides-theme-seriph {
      --slide-bg: #171513;
      --slide-text: #f5f2eb;
      --slide-text-secondary: #a8a29e;
      --slide-code-bg: #24201c;
      --slide-code-border: rgba(245, 158, 11, 0.22);
      --slide-accent: #f59e0b;
      --slide-accent-secondary: #fb923c;
      --slide-card-bg: rgba(32, 28, 24, 0.8);
      --slide-card-border: rgba(245, 158, 11, 0.22);
      --slide-card-shadow: 0 4px 16px rgba(0, 0, 0, 0.4);
    }
    .slides-theme-seriph,
    .slides-theme-seriph .slide-content {
      font-family: var(--slide-font) !important;
      line-height: 1.75;
    }
    .slides-theme-seriph h1,
    .slides-theme-seriph h2,
    .slides-theme-seriph h3 {
      font-family: var(--slide-font) !important;
      letter-spacing: 0.025em;
      font-weight: 700;
    }
    .slides-theme-seriph .layout-cover h1 {
      background: none !important;
      -webkit-background-clip: initial !important;
      -webkit-text-fill-color: initial !important;
      color: var(--slide-accent) !important;
      font-size: 3.4rem !important;
      font-weight: 700 !important;
      border-bottom: 2px solid var(--slide-accent);
      display: inline-block;
      padding-bottom: 10px;
      margin-bottom: 24px;
    }
    .slides-theme-seriph .layout-cover p {
      font-style: italic;
      color: var(--slide-text-secondary);
    }
    /* 优雅衬线风：内容页顶部标题学术双线眉批 */
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h1,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h2,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h3,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h1,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h2,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h3,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h1,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h2,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h3,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h1,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h2,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h3,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) > .slide-block:first-child h1,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) > .slide-block:first-child h2,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) > .slide-block:first-child h3,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h1,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h2,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h3,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .slide-block:first-child h1,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .slide-block:first-child h2,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .slide-block:first-child h3,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .slide-block:first-child h1,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .slide-block:first-child h2,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .slide-block:first-child h3,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-left-content > .slide-block:first-child h1,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-left-content > .slide-block:first-child h2,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-left-content > .slide-block:first-child h3,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-right-content > .slide-block:first-child h1,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-right-content > .slide-block:first-child h2,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-right-content > .slide-block:first-child h3,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .slide-block:first-child h1,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .slide-block:first-child h2,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .slide-block:first-child h3,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .slide-block:first-child h1,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .slide-block:first-child h2,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .slide-block:first-child h3 {
      display: block;
      position: relative;
      color: var(--slide-accent);
      border-bottom: 1.5px solid color-mix(in srgb, var(--slide-accent) 45%, transparent);
      padding-bottom: 10px;
      margin-bottom: 14px;
    }
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h1::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h2::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h3::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h1::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h2::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h3::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h1::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h2::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h3::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h1::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h2::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h3::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) > .slide-block:first-child h1::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) > .slide-block:first-child h2::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) > .slide-block:first-child h3::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h1::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h2::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h3::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .slide-block:first-child h1::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .slide-block:first-child h2::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .slide-block:first-child h3::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .slide-block:first-child h1::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .slide-block:first-child h2::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .slide-block:first-child h3::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-left-content > .slide-block:first-child h1::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-left-content > .slide-block:first-child h2::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-left-content > .slide-block:first-child h3::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-right-content > .slide-block:first-child h1::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-right-content > .slide-block:first-child h2::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-right-content > .slide-block:first-child h3::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .slide-block:first-child h1::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .slide-block:first-child h2::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .slide-block:first-child h3::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .slide-block:first-child h1::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .slide-block:first-child h2::after,
    .slides-theme-seriph .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .slide-block:first-child h3::after {
      content: "";
      position: absolute;
      left: 0;
      right: 0;
      bottom: 3px;
      height: 1.5px;
      pointer-events: none;
      background: linear-gradient(90deg, var(--slide-accent) 0%, color-mix(in srgb, var(--slide-accent) 35%, transparent) 50%, transparent 92%);
    }
    .slides-theme-seriph blockquote {
      position: relative;
      font-style: italic;
      border-left: 2px solid var(--slide-accent) !important;
      background: color-mix(in srgb, var(--slide-accent) 6%, transparent) !important;
      padding: 14px 20px 14px 28px !important;
      border-radius: 4px;
      margin: 12px 0 !important;
    }
    .slides-theme-seriph blockquote::before {
      content: "“";
      position: absolute;
      left: 8px;
      top: 6px;
      font-size: 2rem;
      line-height: 1;
      color: var(--slide-accent);
      opacity: 0.6;
      font-family: Georgia, serif;
    }
    .slides-theme-seriph pre {
      border: 1px solid var(--slide-code-border) !important;
      border-radius: 4px !important;
      box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08) !important;
    }

    /* 3. 极简发布会主题 Apple Basic (苹果 Keynote / 瑞士纯粹主义) */
    [data-slides-theme="apple-basic"],
    .slides-theme-apple-basic {
      --slide-font: -apple-system, "SF Pro Display", "SF Pro Text", BlinkMacSystemFont, "PingFang SC", "Helvetica Neue", sans-serif;
      --slide-accent: #0071e3;
      --slide-accent-secondary: #0077ed;
      letter-spacing: -0.025em;
    }
    [data-theme="light"][data-slides-theme="apple-basic"],
    [data-theme="light"] .slides-theme-apple-basic {
      --slide-bg: #ffffff;
      --slide-text: #000000;
      --slide-text-secondary: #6e6e73;
      --slide-code-bg: #f5f5f7;
      --slide-code-border: transparent;
      --slide-accent: #0071e3;
      --slide-accent-secondary: #0077ed;
      --slide-card-bg: #f5f5f7;
      --slide-card-border: transparent;
      --slide-card-shadow: none;
    }
    [data-theme="dark"][data-slides-theme="apple-basic"],
    [data-theme="dark"] .slides-theme-apple-basic {
      --slide-bg: #000000;
      --slide-text: #ffffff;
      --slide-text-secondary: #86868b;
      --slide-code-bg: #161617;
      --slide-code-border: transparent;
      --slide-accent: #2997ff;
      --slide-accent-secondary: #64d2ff;
      --slide-card-bg: #161617;
      --slide-card-border: transparent;
      --slide-card-shadow: none;
    }
    .slides-theme-apple-basic,
    .slides-theme-apple-basic .slide-content {
      font-family: var(--slide-font) !important;
    }
    .slides-theme-apple-basic h1,
    .slides-theme-apple-basic h2,
    .slides-theme-apple-basic h3 {
      letter-spacing: -0.035em;
      font-weight: 800;
    }
    .slides-theme-apple-basic .layout-cover h1 {
      background: none !important;
      -webkit-background-clip: initial !important;
      -webkit-text-fill-color: initial !important;
      color: var(--slide-text) !important;
      font-size: 4rem !important;
      font-weight: 800 !important;
      letter-spacing: -0.045em !important;
      margin-bottom: 12px;
    }
    .slides-theme-apple-basic .layout-cover p {
      color: var(--slide-text-secondary) !important;
      font-size: 1.35rem !important;
      font-weight: 500 !important;
      opacity: 1 !important;
    }
    /* 极简发布会风：彻底去装饰化，高字重、紧凑字距与充沛留白 */
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h1,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h2,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h3,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h1,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h2,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h3,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h1,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h2,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h3,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h1,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h2,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h3,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) > .slide-block:first-child h1,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) > .slide-block:first-child h2,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) > .slide-block:first-child h3,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h1,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h2,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h3,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .slide-block:first-child h1,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .slide-block:first-child h2,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .slide-block:first-child h3,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .slide-block:first-child h1,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .slide-block:first-child h2,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .slide-block:first-child h3,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-left-content > .slide-block:first-child h1,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-left-content > .slide-block:first-child h2,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-left-content > .slide-block:first-child h3,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-right-content > .slide-block:first-child h1,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-right-content > .slide-block:first-child h2,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-right-content > .slide-block:first-child h3,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .slide-block:first-child h1,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .slide-block:first-child h2,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .slide-block:first-child h3,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .slide-block:first-child h1,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .slide-block:first-child h2,
    .slides-theme-apple-basic .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .slide-block:first-child h3 {
      border: none !important;
      background: none !important;
      padding: 0 !important;
      margin-bottom: 16px !important;
      letter-spacing: -0.04em !important;
      font-weight: 800 !important;
    }
    .slides-theme-apple-basic pre {
      border-radius: 16px !important;
      border: none !important;
      background: var(--slide-code-bg) !important;
      box-shadow: none !important;
    }
    .slides-theme-apple-basic blockquote {
      border-left: none !important;
      background: var(--slide-card-bg) !important;
      border-radius: 14px !important;
      padding: 18px 24px !important;
      font-size: 1.15rem !important;
      color: var(--slide-text) !important;
    }

    /* 复杂背景防穿透文字保护 (Text Scrim & Backdrop Protection) */
    .slide-viewport[style*="background-image"] .slide-content h1,
    .slide-viewport[style*="background-image"] .slide-content h2,
    .slide-viewport[style*="background-image"] .slide-content h3,
    .slide-viewport[style*="background-image"] .slide-content p,
    .slide-viewport[style*="background-image"] .slide-content li {
      text-shadow: 0 1px 3px rgba(0, 0, 0, 0.75), 0 2px 8px rgba(0, 0, 0, 0.45);
    }
    [data-theme="light"].slide-viewport[style*="background-image"] .slide-content h1,
    [data-theme="light"].slide-viewport[style*="background-image"] .slide-content h2,
    [data-theme="light"].slide-viewport[style*="background-image"] .slide-content h3,
    [data-theme="light"].slide-viewport[style*="background-image"] .slide-content p,
    [data-theme="light"].slide-viewport[style*="background-image"] .slide-content li {
      text-shadow: 0 1px 3px rgba(255, 255, 255, 0.85);
    }
    .slide-viewport[style*="background-image"] .layout-cols-grid > div,
    .slide-viewport[style*="background-image"] .layout-two-cols-grid > div,
    .slide-viewport[style*="background-image"] .layout-three-cols-grid > div,
    .slide-viewport[style*="background-image"] .two-cols-left,
    .slide-viewport[style*="background-image"] .two-cols-right,
    .slide-viewport[style*="background-image"] .pdf-col {
      backdrop-filter: blur(8px);
      -webkit-backdrop-filter: blur(8px);
    }

    /* 封面页在背景图或显式设置文字颜色时，禁用透明渐变镂空，避免与 text-shadow 叠加成浮雕黑芯并遵循主题及实际文字色 */
    .slide-viewport[style*="background-image"] .layout-cover h1,
    .slide-viewport[style*="background-image"] .layout-cover .slide-block h1,
    .slides-overview-canvas[style*="background-image"].layout-cover h1,
    .slides-overview-canvas[style*="background-image"].layout-cover .slide-block h1,
    .slides-overview-canvas[style*="background-image"] .layout-cover h1,
    .slides-overview-canvas[style*="background-image"] .layout-cover .slide-block h1,
    .slides-theme-tech .layout-cover .slide-block[style^="color:"] h1,
    .slides-theme-tech .layout-cover .slide-block[style*=" color:"] h1,
    .slides-theme-tech .layout-cover .slide-block[style*=";color:"] h1,
    .slides-theme-tech .layout-cover h1[style^="color:"],
    .slides-theme-tech .layout-cover h1[style*=" color:"],
    .slides-theme-tech .layout-cover h1[style*=";color:"] {
      background: none !important;
      -webkit-background-clip: initial !important;
      -webkit-text-fill-color: initial !important;
    }
    .layout-cover h1 span[style^="color:"],
    .layout-cover h1 span[style*=" color:"],
    .layout-cover h1 span[style*=";color:"],
    .layout-cover h1 font[color] {
      -webkit-background-clip: initial !important;
      -webkit-text-fill-color: currentColor !important;
    }
    /* 当内容页存在背景图时，顶部标题回退至高对比正文字色并配合局部半透明底衬，同时保留主题装饰 */
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h1,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h2,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h3,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h1,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h2,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h3,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h1,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h2,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h3,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h1,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h2,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h3,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) > .slide-block:first-child h1,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) > .slide-block:first-child h2,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) > .slide-block:first-child h3,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h1,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h2,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h3,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .slide-block:first-child h1,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .slide-block:first-child h2,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .slide-block:first-child h3,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .slide-block:first-child h1,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .slide-block:first-child h2,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .slide-block:first-child h3,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-left-content > .slide-block:first-child h1,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-left-content > .slide-block:first-child h2,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-left-content > .slide-block:first-child h3,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-right-content > .slide-block:first-child h1,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-right-content > .slide-block:first-child h2,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-right-content > .slide-block:first-child h3,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .slide-block:first-child h1,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .slide-block:first-child h2,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .slide-block:first-child h3,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .slide-block:first-child h1,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .slide-block:first-child h2,
    .slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .slide-block:first-child h3 {
      color: var(--slide-text);
    }
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h1,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h2,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h3,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h1,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h2,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h3,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h1,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h2,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h3,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h1,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h2,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h3,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) > .slide-block:first-child h1,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) > .slide-block:first-child h2,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) > .slide-block:first-child h3,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h1,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h2,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h3,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .slide-block:first-child h1,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .slide-block:first-child h2,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .slide-block:first-child h3,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .slide-block:first-child h1,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .slide-block:first-child h2,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .slide-block:first-child h3,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-left-content > .slide-block:first-child h1,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-left-content > .slide-block:first-child h2,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-left-content > .slide-block:first-child h3,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-right-content > .slide-block:first-child h1,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-right-content > .slide-block:first-child h2,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .image-right-content > .slide-block:first-child h3,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .slide-block:first-child h1,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .slide-block:first-child h2,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .slide-block:first-child h3,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .slide-block:first-child h1,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .slide-block:first-child h2,
    .slides-theme-tech.slide-viewport[style*="background-image"] .slide-content:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .slide-block:first-child h3 {
      background: linear-gradient(90deg, color-mix(in srgb, var(--slide-bg) 42%, transparent), transparent 82%);
    }
    /* 用户显式块级前景色优先于主题及背景图默认回退色 */
    .slide-viewport .slide-block[style^="color:"] h1,
    .slide-viewport .slide-block[style*=" color:"] h1,
    .slide-viewport .slide-block[style*=";color:"] h1,
    .slide-viewport .slide-block[style^="color:"] h2,
    .slide-viewport .slide-block[style*=" color:"] h2,
    .slide-viewport .slide-block[style*=";color:"] h2,
    .slide-viewport .slide-block[style^="color:"] h3,
    .slide-viewport .slide-block[style*=" color:"] h3,
    .slide-viewport .slide-block[style*=";color:"] h3 {
      color: inherit !important;
    }

    * { box-sizing: border-box; margin: 0; padding: 0; }
    html, body {
      width: 100%; height: 100%; overflow: hidden;
      background: #0f1115; font-family: var(--slide-font);
      display: flex; justify-content: center; align-items: center;
    }
    #app { width: 100%; height: 100%; position: relative; overflow: hidden; }
    .slide-viewport {
      position: absolute; left: 50%; top: 50%;
      background: var(--slide-bg); color: var(--slide-text);
      box-shadow: 0 10px 30px rgba(0,0,0,0.5); border-radius: 8px; overflow: hidden;
      display: flex; flex-direction: column; flex-shrink: 0;
      transform: translate(-50%, -50%) scale(var(--slides-slide-scale, 1));
      transform-origin: center center; will-change: transform;
      transition: background 0.3s ease, color 0.3s ease, border-radius 0.2s ease, box-shadow 0.2s ease;
      container-type: size;
    }
    :fullscreen .slide-viewport, .is-fullscreen .slide-viewport {
      border-radius: 0 !important; box-shadow: none !important;
    }
    .slide-content {
      position: relative;
      width: 100%;
      height: 100%;
      min-height: 100%;
      flex: 1 1 0%;
      padding: var(--slides-padding-y, 32px) var(--slides-padding-x, 48px);
      display: flex;
      flex-direction: column;
      overflow: hidden;
      box-sizing: border-box;
    }

    /* 间距预设风格 */
    .slide-content.spacing-compact,
    .slide-viewport[data-spacing="compact"] .slide-content,
    [data-slides-spacing="compact"] {
      --slides-padding-y: 16px;
      --slides-padding-x: 28px;
      --slides-block-gap: 8px;
      --slides-list-gap: 4px;
      --slides-cols-gap: 20px;
      --slides-title-margin-bottom: 8px;
      --slides-header-gap: 10px;
      --slides-line-height: 1.45;
    }
    .slide-content.spacing-normal,
    .slide-viewport[data-spacing="normal"] .slide-content,
    [data-slides-spacing="normal"] {
      --slides-padding-y: 32px;
      --slides-padding-x: 48px;
      --slides-block-gap: 14px;
      --slides-list-gap: 6px;
      --slides-cols-gap: 32px;
      --slides-title-margin-bottom: 12px;
      --slides-header-gap: 16px;
      --slides-line-height: 1.6;
    }
    .slide-content.spacing-loose,
    .slide-viewport[data-spacing="loose"] .slide-content,
    [data-slides-spacing="loose"] {
      --slides-padding-y: 52px;
      --slides-padding-x: 72px;
      --slides-block-gap: 22px;
      --slides-list-gap: 10px;
      --slides-cols-gap: 44px;
      --slides-title-margin-bottom: 18px;
      --slides-header-gap: 24px;
      --slides-line-height: 1.75;
    }

    .layout-cover { justify-content: center; align-items: center; text-align: center; }
    .layout-cover h1, .layout-cover .slide-block h1 { font-size: 3.8rem !important; font-weight: 800 !important; line-height: 1.15 !important; letter-spacing: -0.025em !important; margin-bottom: 16px !important; }
    .layout-cover h2, .layout-cover .slide-block h2 { font-size: 1.85rem !important; font-weight: 600 !important; opacity: 0.85 !important; margin-bottom: 12px !important; }
    .layout-cover p, .layout-cover .slide-block p { font-size: 1.45rem !important; line-height: 1.5 !important; opacity: 0.85 !important; }
    .two-cols-left, .two-cols-right { min-width: 0; width: 100%; display: flex; flex-direction: column; box-sizing: border-box; overflow-wrap: break-word; word-break: break-word; }
    .pdf-two-cols-wrapper,
    .layout-two-cols-grid,
    .layout-cols-wrapper,
    .layout-cols-grid {
      display: grid;
      grid-template-columns: var(--slide-grid-cols, minmax(0, 1fr) minmax(0, 1fr));
      grid-template-rows: minmax(0, 1fr) !important;
      gap: var(--slides-cols-gap, 32px);
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      overflow: hidden !important;
    }
    .layout-cols-header-container,
    .layout-two-cols-header-container,
    .layout-three-cols-header-container,
    .layout-clover-container {
      display: flex;
      flex-direction: column;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      overflow: hidden !important;
    }
    .layout-header-section {
      width: 100%;
      margin-bottom: var(--slides-header-gap, 16px) !important;
      flex-shrink: 0;
    }
    .layout-header-section h1,
    .layout-header-section h2,
    .layout-header-section h3 {
      margin-bottom: var(--slides-title-margin-bottom, 10px) !important;
    }
    .pdf-three-cols-wrapper,
    .layout-three-cols-grid {
      display: grid;
      grid-template-columns: var(--slide-grid-cols, minmax(0, 1fr) minmax(0, 1fr) minmax(0, 1fr));
      grid-template-rows: minmax(0, 1fr) !important;
      gap: calc(var(--slides-cols-gap, 32px) * 0.75);
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      box-sizing: border-box;
      overflow: hidden !important;
    }
    .pdf-clover-wrapper,
    .layout-clover-grid {
      display: grid;
      grid-template-columns: repeat(2, minmax(0, 1fr)) !important;
      grid-template-rows: repeat(2, minmax(0, 1fr)) !important;
      gap: calc(var(--slides-cols-gap, 32px) * 0.625);
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      box-sizing: border-box;
      overflow: hidden !important;
    }
    .layout-clover-grid .pdf-col {
      background: transparent !important;
      border: none !important;
      box-shadow: none !important;
    }
    .pdf-col {
      display: flex;
      flex-direction: column;
      gap: var(--slides-block-gap, 14px);
      min-width: 0;
      width: 100%;
      max-width: 100%;
      height: 100%;
      max-height: 100%;
      min-height: 0;
      justify-content: flex-start;
      box-sizing: border-box;
      overflow: hidden;
      overflow-wrap: break-word;
      word-break: break-word;
      white-space: normal;
    }
    .pdf-col * {
      overflow-wrap: break-word;
      word-break: break-word;
      box-sizing: border-box;
    }
    /* 表头多栏内超级块子块首个列表项去圆点后居中显示标题/首行文本 (仅在存在超级块分栏时生效) */
    .has-superblock-cols .pdf-col > *:first-child .slide-list-item-title,
    .has-superblock-cols .pdf-col > *:first-child :is(h1, h2, h3, h4, h5, h6),
    .has-superblock-cols .pdf-col > *:first-child p.slide-list-item-title,
    .has-superblock-cols .pdf-col > *:first-child p:first-of-type,
    .has-superblock-cols .pdf-col > *:first-child p:first-child,
    .has-superblock-cols .pdf-col > *:first-child :is(ul, ol) > li:first-child,
    .has-superblock-cols .pdf-col > *:first-child .slide-list > .slide-list-item:first-child,
    .has-superblock-cols .pdf-col > *:first-child .pdf-list > li:first-child,
    .has-superblock-cols .slides-col-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    .has-superblock-cols .slides-col-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      list-style: none !important;
      list-style-type: none !important;
      text-align: center !important;
      margin-left: 0 !important;
      padding-left: 0 !important;
      width: 100% !important;
    }

    /* 彻底清除首个列表项的原生圆点 Marker (仅在存在超级块分栏时生效) */
    .has-superblock-cols .pdf-col > *:first-child :is(ul, ol) > li:first-child::marker {
      content: "" !important;
      display: none !important;
    }

    /* 确保首个列表项内部内联与块级元素居中 (仅在存在超级块分栏时生效) */
    .has-superblock-cols .pdf-col > *:first-child :is(ul, ol) > li:first-child * {
      text-align: center !important;
    }

    /* 栏内说明段落与列表项：左对齐，自然阅读排版 */
    .has-superblock-cols .pdf-col .slide-list-item-desc,
    .has-superblock-cols .pdf-col li:not(:first-child) {
      text-align: left !important;
    }

    /* 全局特定标题大小规范化 (除封面外页首首个标题按 H2 1.7rem，表头多栏内首个标题按 H3 1.3rem) */
    [data-normalize-headings="true"] .slides-page-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .slides-page-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .slide-content:not(.layout-cover) > :is(.pdf-block, .slide-block):first-child :is(h1, h2, h3, h4, h5, h6),
    [data-normalize-headings="true"] .slide-content:not(.layout-cover) > .layout-header-section :is(.pdf-block, .slide-block):first-child :is(h1, h2, h3, h4, h5, h6),
    [data-normalize-headings="true"] .slide-content:not(.layout-cover) > :not(.layout-cols-wrapper):not(.pdf-two-cols-wrapper):not(.layout-image-cols-grid):first-child :is(h1, h2, h3, h4, h5, h6) {
      font-size: 1.7rem !important;
      font-weight: 600 !important;
      line-height: 1.25 !important;
      margin-bottom: var(--slides-title-margin-bottom, 10px) !important;
    }

    [data-normalize-headings="true"] .has-superblock-cols .slides-col-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .has-superblock-cols .slides-col-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .has-superblock-cols .pdf-col > *:first-child :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      font-size: 1.3rem !important;
      font-weight: 600 !important;
      line-height: 1.3 !important;
      margin-bottom: 8px !important;
      text-align: center !important;
    }

    /* 图左与图右版式标题完全保留用户原始字号与默认排版，不进行任何固定大小规范化 */
    [data-normalize-headings="true"] :is(.layout-image-left, .layout-image-right, .image-left-content, .image-right-content) :is(h1, h2, h3, h4, h5, h6) {
      text-align: left !important;
    }
    .pdf-col pre,
    .two-cols-left pre,
    .two-cols-right pre,
    .image-right-content pre,
    .image-left-content pre {
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      overflow-x: hidden !important;
      overflow-y: auto !important;
      max-width: 100% !important;
      box-sizing: border-box !important;
    }
    .slide-content.layout-image-right, .slide-content.layout-image-left {
      padding: 0;
      display: grid;
      grid-template-columns: var(--slide-grid-cols, minmax(0, 1fr) minmax(0, 1fr));
      grid-template-rows: 100%;
      width: 100%;
      height: 100%;
      position: absolute;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      box-sizing: border-box;
    }
    .image-right-content, .image-left-content {
      padding: var(--slides-padding-y, 32px) var(--slides-padding-x, 48px);
      display: flex;
      flex-direction: column;
      justify-content: flex-start;
      overflow-y: auto;
      width: 100%;
      height: 100%;
      box-sizing: border-box;
    }
    .image-right-img-container, .image-left-img-container {
      width: 100%;
      height: 100%;
      overflow: hidden;
      position: relative;
      background: #18181b;
      display: flex;
      align-items: center;
      justify-content: center;
    }
    .image-right-img, .image-left-img {
      width: 100%;
      height: 100%;
      object-fit: cover;
      object-position: center;
      display: block;
    }
    .slide-block { margin-bottom: var(--slides-block-gap, 14px); line-height: var(--slides-line-height, 1.6); }
    .slide-block h1 { font-size: 2.2rem; margin-bottom: var(--slides-title-margin-bottom, 12px); }
    .slide-block h2 { font-size: 1.7rem; margin-bottom: calc(var(--slides-title-margin-bottom, 10px) * 0.85); }
    .slide-block p { font-size: 1.15rem; line-height: var(--slides-line-height, 1.6); }
    .slide-block ul, .slide-block ol, .pdf-list {
      padding-left: 28px;
      margin: calc(var(--slides-block-gap, 14px) * 0.6) 0;
      display: flex;
      flex-direction: column;
      gap: var(--slides-list-gap, 6px);
    }
    .slide-block li, .pdf-list li {
      font-size: 1.15rem;
      line-height: var(--slides-line-height, 1.6);
    }
    .pdf-task-item {
      list-style: none;
      margin-left: -20px;
      display: flex;
      align-items: center;
      gap: 8px;
    }
    .pdf-task-item input[type="checkbox"] {
      width: 1.15em;
      height: 1.15em;
      cursor: pointer;
    }

    /* 两栏与三栏及多栏（超级块分栏）布局：紧凑自然行距，子列表保留圆点与层级缩进 */
    .layout-two-cols ul,
    .layout-cols-header ul,
    .layout-two-cols-header ul,
    .layout-three-cols ul,
    .layout-three-cols-header ul,
    .two-cols-left ul,
    .two-cols-right ul,
    .three-cols-col ul,
    .col ul,
    .pdf-col ul,
    .layout-two-cols-grid .pdf-list,
    .layout-three-cols-grid .pdf-list,
    .layout-cols-grid .pdf-list,
    .layout-two-cols-grid .pdf-list--unordered,
    .layout-three-cols-grid .pdf-list--unordered,
    .layout-cols-grid .pdf-list--unordered {
      list-style: disc !important;
      list-style-type: disc !important;
      padding-left: 1.25em !important;
      margin-left: 0 !important;
      margin-top: 0 !important;
      margin-bottom: 8px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: block !important;
    }

    .layout-two-cols ol,
    .layout-cols-header ol,
    .layout-two-cols-header ol,
    .layout-three-cols ol,
    .layout-three-cols-header ol,
    .two-cols-left ol,
    .two-cols-right ol,
    .three-cols-col ol,
    .col ol,
    .pdf-col ol,
    .layout-two-cols-grid .pdf-list--ordered,
    .layout-three-cols-grid .pdf-list--ordered,
    .layout-cols-grid .pdf-list--ordered {
      list-style: decimal !important;
      list-style-type: decimal !important;
      padding-left: 1.25em !important;
      margin-left: 0 !important;
      margin-top: 0 !important;
      margin-bottom: 8px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: block !important;
    }

    .layout-two-cols li,
    .layout-cols-header li,
    .layout-two-cols-header li,
    .layout-three-cols li,
    .layout-three-cols-header li,
    .two-cols-left li,
    .two-cols-right li,
    .three-cols-col li,
    .col li,
    .pdf-col li,
    .pdf-col .pdf-list-item {
      padding-left: 0.2em !important;
      margin-left: 0 !important;
      margin-bottom: var(--slides-list-gap, 6px) !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: list-item !important;
      line-height: var(--slides-line-height, 1.6) !important;
    }

    .layout-two-cols ul ul,
    .layout-three-cols ul ul,
    .three-cols-col ul ul,
    .pdf-col ul ul {
      list-style: circle !important;
      list-style-type: circle !important;
      padding-left: 1.25em !important;
      margin-top: 4px !important;
      margin-bottom: 4px !important;
    }

    /* 列表项内嵌标题与说明排版 */
    .slide-list-item-title,
    .pdf-list li > h1,
    .pdf-list li > h2,
    .pdf-list li > h3,
    .pdf-list li > h4,
    .pdf-list li > h5,
    .pdf-list li > h6,
    li > h1.slide-list-item-title,
    li > h2.slide-list-item-title,
    li > h3.slide-list-item-title,
    li > h4.slide-list-item-title {
      margin-top: 2px !important;
      margin-bottom: 6px !important;
      line-height: 1.35 !important;
      font-weight: 700 !important;
    }
    .pdf-list li > h1, li > h1.slide-list-item-title { font-size: 1.6rem !important; }
    .pdf-list li > h2, li > h2.slide-list-item-title { font-size: 1.4rem !important; }
    .pdf-list li > h3, li > h3.slide-list-item-title { font-size: 1.22rem !important; }
    .pdf-list li > h4, li > h4.slide-list-item-title { font-size: 1.1rem !important; }

    /* 全局特定标题大小规范化后置强力锁定 (防止被列表项内部字号覆盖) */
    [data-normalize-headings="true"] .slides-page-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .slides-page-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      font-size: 1.7rem !important;
      font-weight: 600 !important;
      line-height: 1.25 !important;
      margin-bottom: 10px !important;
    }
    [data-normalize-headings="true"] .slides-col-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .slides-col-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] :is(.layout-cols-wrapper, .pdf-two-cols-wrapper, .layout-cols-header-container, .layout-cols-grid) .pdf-col > *:first-child :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] :is(.two-cols-left, .two-cols-right, .pdf-col, .col) > *:first-child :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      font-size: 1.3rem !important;
      font-weight: 600 !important;
      line-height: 1.3 !important;
      margin-bottom: 8px !important;
      text-align: center !important;
    }
    /* 基础列表项前缀样式 */
    .slide-block ul,
    .slide-list--unordered,
    .pdf-list--unordered {
      list-style: disc !important;
      list-style-type: disc !important;
    }
    .slide-block ol,
    .slide-list--ordered,
    .pdf-list--ordered {
      list-style: decimal !important;
      list-style-type: decimal !important;
    }
    .slide-block li,
    .slide-list-item,
    .pdf-list-item,
    .pdf-list li {
      display: list-item !important;
    }

    /* 隐藏无序列表前缀标记 */
    [data-hide-unordered-markers="true"] :is(ul, .slide-list, .slide-list--unordered, .pdf-list, .pdf-list--unordered),
    [data-hide-unordered-markers="true"] :is(ul, .slide-list, .slide-list--unordered, .pdf-list, .pdf-list--unordered) > li,
    [data-hide-unordered-markers="true"] li.slide-list-item,
    [data-hide-unordered-markers="true"] ul > li {
      list-style: none !important;
      list-style-type: none !important;
      padding-left: 0 !important;
      margin-left: 0 !important;
    }
    [data-hide-unordered-markers="true"] :is(ul, .slide-list, .slide-list--unordered, .pdf-list, .pdf-list--unordered) > li::marker,
    [data-hide-unordered-markers="true"] li.slide-list-item::marker {
      content: "" !important;
      display: none !important;
    }

    /* 隐藏有序列表前缀标记 */
    [data-hide-ordered-markers="true"] :is(ol, .slide-list, .slide-list--ordered, .pdf-list, .pdf-list--ordered),
    [data-hide-ordered-markers="true"] :is(ol, .slide-list, .slide-list--ordered, .pdf-list, .pdf-list--ordered) > li,
    [data-hide-ordered-markers="true"] li.slide-list-item,
    [data-hide-ordered-markers="true"] ol > li {
      list-style: none !important;
      list-style-type: none !important;
      padding-left: 0 !important;
      margin-left: 0 !important;
    }
    [data-hide-ordered-markers="true"] :is(ol, .slide-list, .slide-list--ordered, .pdf-list, .pdf-list--ordered) > li::marker,
    [data-hide-ordered-markers="true"] li.slide-list-item::marker {
      content: "" !important;
      display: none !important;
    }

    .slide-list-item-desc,
    .pdf-list li > p {
      margin-top: 4px !important;
      margin-bottom: 6px !important;
      font-size: 1.05rem;
      line-height: 1.55;
      opacity: 0.92;
    }

    /* 多媒体（GIF动图、静态图片、MP4视频）全视口最大化自适应且不超出视口 */
    .slide-media-block,
    .slide-media-container,
    .slide-video-container,
    .slide-block--media,
    .slide-block--image,
    .slide-block--video,
    .slide-block:has(> img),
    .slide-block:has(> .slide-media-container),
    .slide-block:has(> p > img:only-child),
    .slide-block:has(> .slide-video-container),
    .slide-block:has(> video) {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      min-width: 0 !important;
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
      justify-content: center !important;
      width: 100% !important;
      height: 100% !important;
      max-height: 100% !important;
      overflow: hidden !important;
      margin: 4px 0 !important;
      box-sizing: border-box !important;
    }

    .two-cols-left > .slide-block,
    .two-cols-right > .slide-block,
    .three-cols-col > .slide-block,
    .pdf-col > .slide-block,
    .pdf-col .slide-block {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      max-height: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      width: 100% !important;
      height: 100% !important;
      box-sizing: border-box !important;
      overflow: hidden !important;
      margin-bottom: 0 !important;
    }

    /* 列内列表项的标题与段落文字：固定高度，不压缩 */
    .two-cols-left .slide-list-item-title,
    .two-cols-right .slide-list-item-title,
    .three-cols-col .slide-list-item-title,
    .pdf-col .slide-list-item-title,
    .two-cols-left h1, .two-cols-left h2, .two-cols-left h3, .two-cols-left h4, .two-cols-left h5, .two-cols-left h6,
    .two-cols-right h1, .two-cols-right h2, .two-cols-right h3, .two-cols-right h4, .two-cols-right h5, .two-cols-right h6,
    .three-cols-col h1, .three-cols-col h2, .three-cols-col h3, .three-cols-col h4, .three-cols-col h5, .three-cols-col h6,
    .pdf-col h1, .pdf-col h2, .pdf-col h3, .pdf-col h4, .pdf-col h5, .pdf-col h6,
    .three-cols-col .slide-list-item-desc,
    .pdf-col .slide-list-item-desc {
      flex: 0 0 auto !important;
      margin-top: 0 !important;
      margin-bottom: 6px !important;
    }

    /* 列内媒体容器：填满标题下方所有剩余垂直空间，纵向顶部对齐，横向居中，无溢出 */
    .two-cols-left .slide-list-media,
    .two-cols-right .slide-list-media,
    .three-cols-col .slide-list-media,
    .pdf-col .slide-list-media,
    .two-cols-left .slide-video-container,
    .two-cols-right .slide-video-container,
    .three-cols-col .slide-video-container,
    .pdf-col .slide-video-container,
    .two-cols-left .slide-media-container,
    .two-cols-right .slide-media-container,
    .three-cols-col .slide-media-container,
    .pdf-col .slide-media-container {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      min-width: 0 !important;
      width: 100% !important;
      height: 100% !important;
      max-height: 100% !important;
      max-width: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
      justify-content: flex-start !important;
      overflow: hidden !important;
      margin: 0 !important;
      padding: 0 !important;
      box-sizing: border-box !important;
    }

    /* 列内多媒体播放器：以 contain 模式等比缩放完整可见，绝对不超高超宽、不产生遮挡与滚动条 */
    .two-cols-left video,
    .two-cols-right video,
    .three-cols-col video,
    .pdf-col video,
    .two-cols-left img,
    .two-cols-right img,
    .three-cols-col img,
    .pdf-col img,
    .two-cols-left .slide-video-player,
    .two-cols-right .slide-video-player,
    .three-cols-col .slide-video-player,
    .pdf-col .slide-video-player,
    .layout-three-cols-grid video,
    .layout-two-cols-grid video,
    .layout-three-cols-grid img,
    .layout-two-cols-grid img {
      max-width: 100% !important;
      max-height: 100% !important;
      width: auto !important;
      height: auto !important;
      min-width: 0 !important;
      min-height: 0 !important;
      object-fit: contain !important;
      display: block !important;
      margin: 0 auto !important;
      cursor: zoom-in;
    }

    .slide-block img,
    .slide-media-img,
    .slide-media-container img,
    .slide-video-player,
    video.slide-video-player,
    .slide-block video {
      max-width: 100% !important;
      max-height: 100% !important;
      width: auto !important;
      height: auto !important;
      min-width: 0 !important;
      min-height: 0 !important;
      object-fit: contain !important;
      display: block !important;
      margin: 0 auto !important;
      border-radius: 8px;
      box-shadow: 0 4px 16px rgba(0, 0, 0, 0.16);
      background: transparent;
      outline: none;
      cursor: zoom-in;
    }

    .slide-list-media {
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
      justify-content: flex-start !important;
      width: 100% !important;
      max-width: 100% !important;
      height: 100% !important;
      max-height: 100% !important;
      flex: 1 1 0% !important;
      margin-top: 4px !important;
      margin-bottom: 4px !important;
      min-height: 0 !important;
      overflow: hidden !important;
      box-sizing: border-box !important;
    }
    .slide-list-media img,
    .slide-list-media video,
    .slide-list-media .list-item-gif,
    .slide-list-media .slide-video-player {
      max-width: 100% !important;
      max-height: 100% !important;
      width: auto !important;
      height: auto !important;
      min-width: 0 !important;
      min-height: 0 !important;
      object-fit: contain !important;
      border-radius: 6px !important;
      box-shadow: 0 3px 12px rgba(0, 0, 0, 0.14) !important;
      display: block !important;
      margin: 0 auto !important;
      cursor: zoom-in;
    }

    .slide-block:has(.slide-list-media) {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      height: 100% !important;
      max-height: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      overflow: hidden !important;
    }
    .slide-block:has(.slide-list-media) .pdf-list,
    .slide-block:has(.slide-list-media) ul,
    .slide-block:has(.slide-list-media) ol {
      display: block !important;
      flex: 1 1 auto;
      min-height: 0;
      max-height: 100%;
      overflow: visible !important;
      list-style: disc !important;
      list-style-type: disc !important;
    }
    .slide-block:has(.slide-list-media) li,
    .slide-block:has(.slide-list-media) .slide-list-item,
    .slide-block:has(.slide-list-media) .pdf-list-item,
    .slide-block:has(.slide-media-container) li,
    .slide-block:has(.slide-video-container) li,
    .layout-cols-wrapper li:has(.slide-list-media),
    .layout-cols-header-container li:has(.slide-list-media),
    .two-cols-left li:has(.slide-list-media),
    .two-cols-right li:has(.slide-list-media),
    .three-cols-col li:has(.slide-list-media),
    .pdf-col li:has(.slide-list-media),
    li:has(.slide-list-media),
    li:has(.slide-video-container),
    li:has(.slide-media-container) {
      display: list-item !important;
      list-style-type: disc !important;
      flex: 0 0 auto !important;
      height: auto !important;
      max-height: none !important;
      overflow: visible !important;
      margin-bottom: 6px !important;
    }

    .layout-two-cols .slide-media-block,
    .layout-two-cols .slide-video-container,
    .layout-two-cols .slide-media-container,
    .layout-three-cols .slide-media-block,
    .layout-three-cols .slide-video-container,
    .layout-three-cols .slide-media-container {
      max-width: 100% !important;
      max-height: 100% !important;
      width: 100% !important;
      height: 100% !important;
      min-width: 0 !important;
      min-height: 0 !important;
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
      justify-content: flex-start !important;
      overflow: hidden !important;
    }

    /* Lightbox 大图与视频灯箱模态窗口 */
    .slides-lightbox {
      position: fixed;
      top: 0;
      left: 0;
      width: 100vw;
      height: 100vh;
      background: rgba(0, 0, 0, 0.88);
      backdrop-filter: blur(8px);
      z-index: 999999;
      display: none;
      align-items: center;
      justify-content: center;
      cursor: zoom-out;
      opacity: 0;
      transition: opacity 0.2s cubic-bezier(0.16, 1, 0.3, 1);
    }
    .slides-lightbox.active {
      display: flex;
      opacity: 1;
    }
    .slides-lightbox-content {
      position: relative;
      max-width: 92vw;
      max-height: 92vh;
      display: flex;
      align-items: center;
      justify-content: center;
      cursor: default;
    }
    .slides-lightbox-img {
      max-width: 92vw;
      max-height: 92vh;
      object-fit: contain;
      border-radius: 8px;
      box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.75);
      user-select: none;
      -webkit-user-drag: none;
      touch-action: none;
    }
    .slides-lightbox-video {
      max-width: 92vw;
      max-height: 92vh;
      border-radius: 8px;
      box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.75);
    }
    .slides-lightbox-close {
      position: absolute;
      top: 24px;
      right: 28px;
      width: 40px;
      height: 40px;
      background: rgba(255, 255, 255, 0.2);
      border: 1px solid rgba(255, 255, 255, 0.35);
      border-radius: 50%;
      color: #fff;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 22px;
      cursor: pointer;
      transition: background 0.2s, transform 0.2s;
      z-index: 1000000;
    }
    .slides-lightbox-close:hover {
      background: rgba(255, 255, 255, 0.35);
      transform: scale(1.05);
    }

    img.slide-inline-img {
      max-width: 100% !important;
      max-height: min(320px, 40vh) !important;
      object-fit: contain !important;
      vertical-align: middle;
      border-radius: 4px;
    }
    kbd {
      display: inline-block;
      padding: 2px 7px;
      font-family: ui-monospace, SFMono-Regular, "SF Mono", Menlo, Consolas, "Liberation Mono", monospace;
      font-size: 0.85em;
      font-weight: 600;
      line-height: 1.25;
      color: inherit;
      background: rgba(125, 125, 125, 0.12);
      border: 1px solid rgba(125, 125, 125, 0.35);
      border-bottom-width: 2px;
      border-radius: 5px;
      box-shadow: 0 1px 2px rgba(0, 0, 0, 0.12);
      margin: 0 2px;
      vertical-align: middle;
      white-space: nowrap;
    }
    [data-theme="dark"] kbd, .theme-dark kbd {
      background: rgba(255, 255, 255, 0.1);
      border-color: rgba(255, 255, 255, 0.25);
      border-bottom-color: rgba(255, 255, 255, 0.4);
      color: #f1f5f9;
      box-shadow: 0 1px 2px rgba(0, 0, 0, 0.4);
    }
    .slide-block pre,
    pre {
      background: rgba(0, 0, 0, 0.1);
      padding: 12px;
      border-radius: 6px;
      font-family: "JetBrains Mono", Consolas, monospace;
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      overflow-x: hidden !important;
      overflow-y: auto !important;
      max-width: 100% !important;
      box-sizing: border-box !important;
    }
    .slide-block pre code,
    pre code {
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      display: block !important;
      width: 100% !important;
      box-sizing: border-box !important;
    }
    .code-line {
      display: flex !important;
      align-items: flex-start !important;
      width: 100% !important;
      box-sizing: border-box !important;
      line-height: 1.6;
    }
    .code-line .line-no {
      display: inline-block !important;
      flex-shrink: 0 !important;
      min-width: 2.2em !important;
      text-align: right !important;
      margin-right: 12px !important;
      user-select: none !important;
      opacity: 0.45 !important;
    }
    .code-line .line-content {
      flex: 1 1 0% !important;
      min-width: 0 !important;
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
    }
    /* 弱提示滚动条样式 */
    * {
      scrollbar-width: thin;
      scrollbar-color: rgba(255, 255, 255, 0.20) transparent;
    }
    *::-webkit-scrollbar {
      width: 4px;
      height: 4px;
    }
    *::-webkit-scrollbar-track {
      background: transparent;
    }
    *::-webkit-scrollbar-thumb {
      background: rgba(255, 255, 255, 0.20);
      border-radius: 2px;
      transition: background 0.2s ease;
    }
    *:hover::-webkit-scrollbar-thumb,
    *::-webkit-scrollbar-thumb:hover {
      background: rgba(255, 255, 255, 0.45);
    }
    /* Slidev Micro-motion Keyframes & Presets */
    @keyframes slidesMotionFadeIn { from { opacity: 0; } to { opacity: 1; } }
    @keyframes slidesMotionSlideUp { from { opacity: 0; transform: translateY(40px); } to { opacity: 1; transform: translateY(0); } }
    @keyframes slidesMotionSlideDown { from { opacity: 0; transform: translateY(-40px); } to { opacity: 1; transform: translateY(0); } }
    @keyframes slidesMotionSlideLeft { from { opacity: 0; transform: translateX(40px); } to { opacity: 1; transform: translateX(0); } }
    @keyframes slidesMotionSlideRight { from { opacity: 0; transform: translateX(-40px); } to { opacity: 1; transform: translateX(0); } }
    @keyframes slidesMotionZoomIn { from { opacity: 0; transform: scale(0.8); } to { opacity: 1; transform: scale(1); } }
    @keyframes slidesMotionBounce {
      0% { opacity: 0; transform: translateY(40px); }
      60% { opacity: 1; transform: translateY(-8px); }
      80% { transform: translateY(4px); }
      100% { transform: translateY(0); }
    }
    .slides-motion-fade-in { animation: slidesMotionFadeIn var(--motion-duration, 0.4s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slides-motion-slide-up { animation: slidesMotionSlideUp var(--motion-duration, 0.45s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slides-motion-slide-down { animation: slidesMotionSlideDown var(--motion-duration, 0.45s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slides-motion-slide-left { animation: slidesMotionSlideLeft var(--motion-duration, 0.45s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slides-motion-slide-right { animation: slidesMotionSlideRight var(--motion-duration, 0.45s) cubic-bezier(0.16, 1, 0.3, 1) var(--motion-delay, 0s) both; }
    .slides-motion-zoom-in, .slides-motion-pop { animation: slidesMotionZoomIn var(--motion-duration, 0.4s) cubic-bezier(0.34, 1.56, 0.64, 1) var(--motion-delay, 0s) both; }
    .slides-motion-bounce { animation: slidesMotionBounce var(--motion-duration, 0.6s) cubic-bezier(0.34, 1.56, 0.64, 1) var(--motion-delay, 0s) both; }
    .controls {
      position: absolute; bottom: 16px; display: flex; gap: 12px; align-items: center;
      background: rgba(24, 24, 27, 0.8); backdrop-filter: blur(8px);
      padding: 6px 18px; border-radius: 20px; color: #fff; font-size: 13px; z-index: 10;
      opacity: 0; pointer-events: auto;
      transition: opacity 0.3s cubic-bezier(0.16, 1, 0.3, 1), transform 0.3s cubic-bezier(0.16, 1, 0.3, 1);
    }
    .controls::before {
      content: ""; position: absolute; top: -20px; bottom: -16px; left: -24px; right: -24px;
    }
    .controls:hover, .controls:focus-within {
      opacity: 1; transform: translateY(-2px);
    }
    .controls button { background: transparent; border: none; color: inherit; cursor: pointer; padding: 2px 6px; }

    /* Slidev Native Icons & Interactive Buttons */
    .slidev-icon-btn {
      display: inline-flex !important; flex-direction: row !important; align-items: center !important; justify-content: center !important;
      padding: 0.35rem 0.5rem; border-radius: 0.375rem; background: transparent;
      border: 1px solid transparent; color: inherit; font-size: inherit; line-height: 1;
      cursor: pointer; opacity: 0.8; transition: all 0.2s ease; text-decoration: none;
      vertical-align: middle; user-select: none; margin: 0 4px;
    }
    .slidev-icon-btn:hover { opacity: 1; background: rgba(255, 255, 255, 0.12); border-color: rgba(255, 255, 255, 0.15); }

    /* 组件从上到下按顺序流式渲染，避免相互重叠 */
    .slide-block > div + div { margin-top: 14px; }

    /* 同一个 div 内的按钮/链接从左到右水平渲染 */
    .slide-block div:has(> .slidev-icon-btn),
    .slide-block div:has(> button),
    .slide-block [class*="abs-"],
    .slides-btn-row {
      display: inline-flex !important;
      flex-direction: row !important;
      align-items: center !important;
      justify-content: center !important;
      flex-wrap: wrap !important;
      gap: 8px !important;
    }

    /* Position Shortcuts 适配：在组件流中保持从上到下排列，不脱离流产生重叠 */
    .slide-block .abs-br,
    .slide-block .abs-bl,
    .slide-block .abs-tr,
    .slide-block .abs-tl,
    .slide-block [class*="abs-"] {
      position: relative !important;
      bottom: auto !important;
      right: auto !important;
      top: auto !important;
      left: auto !important;
      margin: 0.75rem auto !important;
    }

    .slide-block--absolute { position: relative !important; margin-bottom: 14px !important; padding: 0 !important; background: transparent !important; }
    .slide-block--absolute:hover { background: transparent !important; }
    .mt-12 { margin-top: 3rem !important; }
    .py-1 { padding-top: 0.25rem !important; padding-bottom: 0.25rem !important; }
    .m-6 { margin: 1.5rem !important; }
    .text-xl { font-size: 1.25rem !important; }
    [hover\\:bg~="white"][hover\\:bg~="op-10"]:hover,
    [hover\\:bg="white op-10"]:hover { background: rgba(255, 255, 255, 0.1) !important; border-radius: 4px; }
    .cursor-pointer, [data-clickable] { cursor: pointer; }
    /* Slidev 规范链接排版 (继承正文颜色，虚线底边，Hover 时平滑点亮为主题色并转为实线) */
    .slide-content a:not(.slides-ref-tag):not(.slidev-icon-btn):not(.slides-toc-link),
    .slide-block a:not(.slides-ref-tag):not(.slidev-icon-btn):not(.slides-toc-link),
    a.slides-link {
      color: inherit;
      text-decoration: none;
      border-bottom: 1px dashed currentColor;
      transition: color 0.2s cubic-bezier(0.4, 0, 0.2, 1),
                  border-color 0.2s cubic-bezier(0.4, 0, 0.2, 1),
                  border-bottom-style 0.2s cubic-bezier(0.4, 0, 0.2, 1);
      cursor: pointer;
    }
    .slide-content a:not(.slides-ref-tag):not(.slidev-icon-btn):not(.slides-toc-link):hover,
    .slide-block a:not(.slides-ref-tag):not(.slidev-icon-btn):not(.slides-toc-link):hover,
    a.slides-link:hover {
      color: var(--slide-accent);
      border-bottom-style: solid;
      border-bottom-color: var(--slide-accent);
    }
    .slides-ref-tag, a.slides-ref-tag {
      display: inline-flex;
      align-items: center;
      background: color-mix(in srgb, var(--slide-accent) 12%, transparent);
      color: var(--slide-accent);
      border-radius: 4px;
      padding: 2px 8px;
      font-size: 0.88em;
      text-decoration: none;
      cursor: pointer;
      margin: 2px 4px 2px 0;
      border: 1px solid color-mix(in srgb, var(--slide-accent) 25%, transparent);
      transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
    }
    .slides-ref-tag:hover, a.slides-ref-tag:hover {
      background: color-mix(in srgb, var(--slide-accent) 22%, transparent);
      color: var(--slide-accent);
      border-color: color-mix(in srgb, var(--slide-accent) 55%, transparent);
      transform: translateY(-1px);
      box-shadow: 0 2px 8px color-mix(in srgb, var(--slide-accent) 20%, transparent);
    }
    .slides-block-ref {
      display: block;
      padding: 10px 14px;
      background: color-mix(in srgb, var(--slide-accent) 8%, transparent);
      border-left: 3px solid var(--slide-accent);
      border-radius: 0 6px 6px 0;
      margin: 8px 0;
      cursor: pointer;
      transition: background 0.2s ease;
    }
    .slides-block-ref:hover {
      background: color-mix(in srgb, var(--slide-accent) 15%, transparent);
    }

    /* 页面动态蒙版 (Dynamic Mask) GPU 合成器硬件加速体系 */
    .slides-mask-body-container {
      position: relative;
      width: 100%;
      height: 100%;
      min-height: 0;
      flex: 1;
      display: flex;
      flex-direction: column;
      overflow: hidden !important;
      contain: layout paint;
      isolation: isolate;
    }
    .slides-mask-body-container--has-mask {
      overflow: hidden !important;
      /* 向左右、向下突破父容器内边距，完全贴合幻灯片视口边缘 */
      margin-left: calc(-1 * var(--slides-padding-x, 48px)) !important;
      margin-right: calc(-1 * var(--slides-padding-x, 48px)) !important;
      margin-bottom: calc(-1 * var(--slides-padding-y, 32px)) !important;
      padding-left: var(--slides-padding-x, 48px) !important;
      padding-right: var(--slides-padding-x, 48px) !important;
      padding-bottom: var(--slides-padding-y, 32px) !important;
      width: calc(100% + 2 * var(--slides-padding-x, 48px)) !important;
      box-sizing: border-box !important;
    }
    /* 无标题且首个元素即为蒙版正文容器时，向上同步扩展至顶部边缘 */
    .slide-content-wrapper > .slides-mask-body-container--has-mask:first-child,
    .slide-content > .slides-mask-body-container--has-mask:first-child {
      margin-top: calc(-1 * var(--slides-padding-y, 32px)) !important;
      padding-top: var(--slides-padding-y, 32px) !important;
    }
    /* 针对全屏零内边距特殊布局（如 image-right/image-left），重置内边距变量避免越界 */
    .slide-content-wrapper.layout-image-right,
    .slide-content-wrapper.layout-image-left,
    .slide-content.layout-image-right,
    .slide-content.layout-image-left {
      --slides-padding-x: 0px !important;
      --slides-padding-y: 0px !important;
    }
    /* 蒙版运动总图层：纯 GPU Compositor 硬件加速 translate3d */
    .slides-mask-layer {
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      pointer-events: none;
      z-index: 50;
      will-change: transform, opacity;
      transform: translate3d(0, 0, 0);
      backface-visibility: hidden;
      transition: transform 0.42s cubic-bezier(0.2, 0, 0, 1),
                  opacity 0.42s cubic-bezier(0.2, 0, 0, 1);
    }
    /* 蒙版内部遮罩层：纯色或磨砂玻璃 */
    .slides-mask-overlay {
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      pointer-events: none;
    }
    .slides-mask-layer--solid .slides-mask-overlay,
    .slides-mask-overlay--solid {
      background: var(--slide-bg, #ffffff);
    }
    [data-theme="dark"] .slides-mask-layer--solid .slides-mask-overlay,
    [data-theme="dark"] .slides-mask-overlay--solid {
      background: var(--slide-bg, #121214);
    }
    .slides-mask-layer--blur .slides-mask-overlay,
    .slides-mask-overlay--blur {
      backdrop-filter: blur(30px) saturate(180%);
      -webkit-backdrop-filter: blur(30px) saturate(180%);
      background: color-mix(in srgb, var(--slide-bg, #ffffff) 90%, transparent);
    }
    [data-theme="dark"] .slides-mask-layer--blur .slides-mask-overlay,
    [data-theme="dark"] .slides-mask-overlay--blur {
      background: color-mix(in srgb, var(--slide-bg, #121214) 90%, transparent);
    }
    /* 动态展露分界提示线：物理内嵌于蒙版边缘，相对坐标永为 0，绝对物理同步 */
    .slides-mask-divider-line {
      position: absolute;
      pointer-events: none;
      z-index: 51;
      opacity: 0;
      transition: opacity 0.3s ease;
    }
    .slides-mask-layer--down .slides-mask-divider-line,
    .slides-mask-divider-line--down {
      top: 0;
      left: 0;
      right: 0;
      height: 2.5px;
      transform: translateY(-50%);
      background: linear-gradient(90deg, transparent 0%, var(--slide-accent, #3b82f6) 6%, var(--slide-accent, #3b82f6) 94%, transparent 100%);
      box-shadow: 0 0 10px var(--slide-accent, #3b82f6), 0 0 4px var(--slide-accent, #3b82f6);
    }
    .slides-mask-layer--right .slides-mask-divider-line,
    .slides-mask-divider-line--right {
      top: 0;
      bottom: 0;
      left: 0;
      width: 2.5px;
      transform: translateX(-50%);
      background: linear-gradient(180deg, transparent 0%, var(--slide-accent, #3b82f6) 6%, var(--slide-accent, #3b82f6) 94%, transparent 100%);
      box-shadow: 0 0 10px var(--slide-accent, #3b82f6), 0 0 4px var(--slide-accent, #3b82f6);
    }
    .slides-mask-layer--clockwise,
    .slides-mask-layer--counter-clockwise,
    .slides-mask-layer--cw,
    .slides-mask-layer--ccw,
    .slides-mask-layer--clock {
      transform: none !important;
    }
    .slides-mask-layer--clockwise .slides-mask-divider-line,
    .slides-mask-layer--counter-clockwise .slides-mask-divider-line,
    .slides-mask-layer--cw .slides-mask-divider-line,
    .slides-mask-layer--ccw .slides-mask-divider-line,
    .slides-mask-layer--clock .slides-mask-divider-line,
    .slides-mask-divider-line--clock,
    .slides-mask-divider-line--clockwise,
    .slides-mask-divider-line--counter-clockwise {
      top: 50%;
      left: 50%;
      right: auto;
      bottom: auto;
      width: 55%;
      height: 2.5px;
      transform-origin: 0% 50%;
      transform: translateY(-50%) rotate(-180deg);
      background: linear-gradient(90deg, var(--slide-accent, #3b82f6) 0%, var(--slide-accent, #3b82f6) 75%, transparent 100%);
      box-shadow: 0 0 10px var(--slide-accent, #3b82f6), 0 0 4px var(--slide-accent, #3b82f6);
      transition: transform 0.42s cubic-bezier(0.2, 0, 0, 1), opacity 0.3s ease;
      will-change: transform, opacity;
    }
    .slides-mask-layer--counter-clockwise .slides-mask-divider-line,
    .slides-mask-divider-line--counter-clockwise {
      transform: translateY(-50%) rotate(-90deg);
    }`}function ug(){return`    (function() {
      const data = window.__SLIDES_DATA__ || { slides: [] };
      const slides = data.slides || [];
      let currentIndex = 0;

      const container = document.getElementById("slide-container");
      const pageNum = document.getElementById("page-num");
      const btnPrev = document.getElementById("btn-prev");
      const btnNext = document.getElementById("btn-next");
      const btnFullscreen = document.getElementById("btn-fullscreen");

      // 「数字+回车」跳页输入角标：右下角悬浮显示，独立于缩放视口
      const jumpBadge = document.createElement("div");
      jumpBadge.className = "jump-page-indicator";
      jumpBadge.style.display = "none";
      document.body.appendChild(jumpBadge);
      const jumpStyle = document.createElement("style");
      jumpStyle.textContent = ".jump-page-indicator{position:fixed;right:16px;bottom:16px;z-index:1000;min-width:40px;padding:4px 12px;border-radius:18px;background:rgba(24,24,27,0.8);backdrop-filter:blur(12px);-webkit-backdrop-filter:blur(12px);border:1px solid rgba(255,255,255,0.12);color:#f4f4f5;font-size:14px;font-variant-numeric:tabular-nums;text-align:center;pointer-events:none;box-shadow:0 4px 16px rgba(0,0,0,0.35);}.jump-page-indicator.is-invalid{background:rgba(153,27,27,0.85);border-color:rgba(248,113,113,0.5);color:#fecaca;animation:jump-indicator-shake 0.4s ease;}@keyframes jump-indicator-shake{0%,100%{transform:translateX(0);}25%{transform:translateX(-4px);}50%{transform:translateX(4px);}75%{transform:translateX(-2px);}}";
      document.head.appendChild(jumpStyle);

`}function fg(){return`      // ========= 缩略图总览层（o 键呼出，方向键/数字+回车/点选跳页） =========
      const OVERVIEW_CARD_W = 236;
      let overviewOpen = false;
      let overviewFocus = 1;
      let overviewBuilt = false;
      let overviewObserver = null;
      const overviewOverlay = document.createElement("div");
      overviewOverlay.className = "slides-overview";
      overviewOverlay.style.display = "none";
      const overviewGrid = document.createElement("div");
      overviewGrid.className = "slides-overview-grid";
      const overviewHint = document.createElement("div");
      overviewHint.className = "slides-overview-hint";
      overviewHint.textContent = "← → ↑ ↓ 移动 · Enter 跳转 · 数字直达 · Esc / O 关闭";
      overviewOverlay.appendChild(overviewGrid);
      overviewOverlay.appendChild(overviewHint);
      document.body.appendChild(overviewOverlay);
      overviewOverlay.addEventListener("click", (e) => {
        if (e.target === overviewOverlay) closeOverview();
      });
      const overviewStyle = document.createElement("style");
      overviewStyle.textContent = ".slides-overview{position:fixed;inset:0;z-index:900;overflow-y:auto;background:rgba(13,16,22,0.88);backdrop-filter:blur(18px);-webkit-backdrop-filter:blur(18px);padding:36px 44px 20px;box-sizing:border-box;}.slides-overview-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(236px,1fr));gap:18px;max-width:1440px;margin:0 auto;}.slides-overview-card{cursor:pointer;border-radius:10px;border:2px solid rgba(255,255,255,0.12);background:rgba(255,255,255,0.04);overflow:hidden;transition:border-color 0.15s ease,transform 0.15s ease,box-shadow 0.15s ease;}.slides-overview-card:hover{border-color:rgba(255,255,255,0.38);transform:translateY(-2px);}.slides-overview-card.is-active{border-color:var(--slide-accent,#3b82f6);box-shadow:0 0 0 1px var(--slide-accent,#3b82f6),0 8px 24px rgba(0,0,0,0.4);}.slides-overview-canvas-box{position:relative;overflow:hidden;background:var(--slide-bg,#ffffff);}.slides-overview-canvas{position:absolute;top:0;left:0;transform-origin:top left;pointer-events:none;}.slides-overview-canvas *{scrollbar-width:none;}.slides-overview-caption{display:flex;align-items:center;gap:8px;padding:6px 10px;font-size:12px;color:rgba(255,255,255,0.72);border-top:1px solid rgba(255,255,255,0.08);background:rgba(13,16,22,0.6);}.slides-overview-page-no{flex-shrink:0;font-variant-numeric:tabular-nums;font-weight:600;color:#f4f4f5;background:rgba(255,255,255,0.16);border-radius:8px;padding:0 7px;line-height:18px;}.slides-overview-page-no.is-current{background:var(--slide-accent,#10b981);color:#0b1210;}.slides-overview-title{white-space:nowrap;overflow:hidden;text-overflow:ellipsis;user-select:none;}.slides-overview-hint{text-align:center;margin:18px 0 8px;font-size:12px;color:rgba(255,255,255,0.45);user-select:none;}";
      document.head.appendChild(overviewStyle);

      const baseWidth = 980;
      const aspectStr = (data.config && data.config.aspectRatio) || "16/9";
      let ratioNum = 16 / 9;
      if (aspectStr === "4/3") ratioNum = 4 / 3;
      else if (aspectStr === "16/10") ratioNum = 16 / 10;
      else if (typeof aspectStr === "string" && aspectStr.includes("/")) {
        const parts = aspectStr.split("/").map(Number);
        if (parts[0] && parts[1]) ratioNum = parts[0] / parts[1];
      }
      const baseHeight = Math.ceil(baseWidth / ratioNum);
      const viewport = document.getElementById("viewport");

`}function hg(){return`      function updateScale() {
        if (!viewport) return;
        const isFull = !!document.fullscreenElement;
        const padX = isFull ? 0 : 20;
        const padY = isFull ? 0 : 32;
        const availW = Math.max(100, window.innerWidth - padX);
        const availH = Math.max(100, window.innerHeight - padY);
        const scale = Math.min(availW / baseWidth, availH / baseHeight);
        viewport.style.width = baseWidth + "px";
        viewport.style.height = baseHeight + "px";
        viewport.style.transform = "translate(-50%, -50%) scale(" + scale + ")";
        viewport.style.setProperty("--slides-slide-scale", scale);
        if (isFull) document.body.classList.add("is-fullscreen");
        else document.body.classList.remove("is-fullscreen");
      }

      window.addEventListener("resize", updateScale);
      document.addEventListener("fullscreenchange", updateScale);

      function parseMaskRatio(ratioStr, defaultSteps) {
        var defSteps = (defaultSteps === 4) ? 4 : 2;
        var defBps = (defaultSteps === 4) ? [25, 50, 75, 100] : [50, 100];
        if (!ratioStr || typeof ratioStr !== "string") {
          return { steps: defSteps, breakpoints: defBps };
        }
        var clean = ratioStr.trim();
        if (!clean || (defaultSteps === 4 && (clean === "1:1" || clean === "1"))) return { steps: defSteps, breakpoints: defBps };
        var parts = clean.split(":").map(function(p) { return parseFloat(p.trim()); }).filter(function(n) { return !isNaN(n) && n > 0; });
        if (parts.length === 0) return { steps: defSteps, breakpoints: defBps };
        if (parts.length === 1) {
          var val = Math.min(100, Math.max(1, parts[0]));
          if (val === 100) return { steps: 1, breakpoints: [100] };
          return { steps: 2, breakpoints: [Math.round(val * 100) / 100, 100] };
        }
        var isMonotonic = parts.every(function(val, idx) { return idx === 0 || val > parts[idx - 1]; });
        var maxVal = parts[parts.length - 1];
        if (isMonotonic && (maxVal === 100 || parts.some(function(p) { return p > 10; }))) {
          var bps = parts.map(function(p) { return Math.min(100, Math.round(p * 100) / 100); });
          if (bps[bps.length - 1] < 100) bps.push(100);
          return { steps: bps.length, breakpoints: bps };
        }
        var totalWeight = parts.reduce(function(acc, cur) { return acc + cur; }, 0);
        if (totalWeight <= 0) return { steps: defSteps, breakpoints: defBps };
        var accumulated = 0;
        var bps = [];
        for (var i = 0; i < parts.length; i++) {
          accumulated += parts[i];
          if (i === parts.length - 1) {
            bps.push(100);
          } else {
            bps.push(Math.round((accumulated / totalWeight) * 10000) / 100);
          }
        }
        return { steps: bps.length, breakpoints: bps };
      }

      let currentMaskStep = 0;
      let currentMaskConfig = null;
      let maskLayerEl = null;
      let maskOverlayEl = null;
      let maskDividerEl = null;

      function updateMaskVisual() {
        if (!currentMaskConfig || !maskLayerEl) return;
        const p = (currentMaskStep <= 0)
          ? (currentMaskConfig.isInitialRevealed ? currentMaskConfig.breakpoints[0] : 0)
          : (currentMaskStep >= currentMaskConfig.totalSteps
              ? 100
              : currentMaskConfig.breakpoints[currentMaskConfig.isInitialRevealed ? currentMaskStep : (currentMaskStep - 1)]);

        if (currentMaskConfig.isClock) {
          const isCw = currentMaskConfig.direction === "clockwise" || currentMaskConfig.direction === "cw";
          const sweepDeg = Math.min(360, Math.max(0, (p / 100) * 360));
          const needleAngle = isCw ? (-180 + sweepDeg) : (-90 - sweepDeg);

          if (maskOverlayEl) {
            let maskGrad = "";
            if (sweepDeg <= 0) {
              maskGrad = "conic-gradient(from 0deg at 50% 50%, #000 0deg, #000 360deg)";
            } else if (sweepDeg >= 360) {
              maskGrad = "conic-gradient(from 0deg at 50% 50%, transparent 0deg, transparent 360deg)";
            } else if (isCw) {
              maskGrad = "conic-gradient(from 270deg at 50% 50%, transparent 0deg, transparent " + sweepDeg + "deg, #000 " + sweepDeg + "deg, #000 360deg)";
            } else {
              const remDeg = 360 - sweepDeg;
              maskGrad = "conic-gradient(from 0deg at 50% 50%, #000 0deg, #000 " + remDeg + "deg, transparent " + remDeg + "deg, transparent 360deg)";
            }
            maskOverlayEl.style.webkitMaskImage = maskGrad;
            maskOverlayEl.style.maskImage = maskGrad;
          }

          if (maskDividerEl) {
            maskDividerEl.style.transform = "translateY(-50%) rotate(" + needleAngle + "deg)";
            maskDividerEl.style.opacity = (p <= 0 || p >= 100) ? "0" : "1";
          }

          if (p >= 100) {
            maskLayerEl.style.opacity = "0";
            maskLayerEl.style.pointerEvents = "none";
          } else {
            maskLayerEl.style.opacity = "1";
            maskLayerEl.style.pointerEvents = "none";
          }
          return;
        }

        const isDown = currentMaskConfig.direction === "down";
        if (p >= 100) {
          maskLayerEl.style.transform = isDown ? "translate3d(0, 100%, 0)" : "translate3d(100%, 0, 0)";
          maskLayerEl.style.opacity = "0";
          maskLayerEl.style.pointerEvents = "none";
          if (maskDividerEl) maskDividerEl.style.opacity = "0";
        } else {
          maskLayerEl.style.transform = isDown ? ("translate3d(0, " + p + "%, 0)") : ("translate3d(" + p + "%, 0, 0)");
          maskLayerEl.style.opacity = "1";
          maskLayerEl.style.pointerEvents = "none";
          if (maskDividerEl) {
            maskDividerEl.style.opacity = (p <= 0) ? "0" : "1";
          }
        }
      }

      function goNext() {
        if (currentMaskConfig && currentMaskStep < currentMaskConfig.totalSteps) {
          currentMaskStep++;
          updateMaskVisual();
          return;
        }
        renderSlide(currentIndex + 1);
      }

      function goPrev() {
        if (currentMaskConfig && currentMaskStep > (currentMaskConfig.isInitialRevealed ? 1 : 0)) {
          currentMaskStep--;
          updateMaskVisual();
          return;
        }
        // FSM-9 优化：回退至上一页时传递 backward 方向，使上一页遮罩处于完全展开状态
        renderSlide(currentIndex - 1, "backward");
      }

`}function pg(){return`      function cleanCardListItemMarkdown(rawMarkdown) {
        if (!rawMarkdown) return "";
        let cleaned = rawMarkdown.replace(/^[ \\t]*[-*+]\\s+|^[ \\t]*\\d+\\.\\s+/, "");
        cleaned = cleaned.replace(/\\n[ \\t]{2,4}/g, "\\n");
        return cleaned.trim();
      }

      function isHeadingBlock(b) {
        if (!b) return false;
        if (b.type === "h" || b.type === "NodeHeading") return true;
        if (b.subType && /^h[1-6]$/i.test(b.subType)) return true;
        const md = (b.rawMarkdown || b.content || "").trim();
        if (/^#{1,6}\\s+/.test(md)) return true;
        if (/^(?:[-*+]|\\d+\\.)\\s+#{1,6}\\s+/.test(md)) return true;
        return false;
      }

      function cleanColList(blocks) {
        const valid = (blocks || []).filter(b => Boolean((b.rawMarkdown || b.content || "").trim()));
        if (valid.length === 0) return valid;
        const first = valid[0];
        const md = (first.rawMarkdown || first.content || "").trim();
        const isList = /^(?:[-*+]|\\d+\\.)\\s+/.test(md) || first.type === "i" || first.type === "l";
        if (isList) {
          first.rawMarkdown = cleanCardListItemMarkdown(first.rawMarkdown || first.content || "");
          first.content = first.rawMarkdown;
        }
        return valid;
      }

      function renderBlock(block, extraClass) {
        const div = document.createElement("div");
        div.className = "slide-block" + (extraClass ? " " + extraClass : "");
        if (block && block.motion && block.motion.preset && block.motion.preset !== "none") {
          div.classList.add("slides-motion-" + block.motion.preset.toLowerCase());
          if (typeof block.motion.duration === "number" && block.motion.duration > 0) {
            div.style.setProperty("--motion-duration", block.motion.duration + "ms");
          }
          if (typeof block.motion.delay === "number" && block.motion.delay > 0) {
            div.style.setProperty("--motion-delay", block.motion.delay + "ms");
          }
        }
        const md = block.rawMarkdown || block.content || "";

        if (md.includes('class="slides-block-ref"') || md.includes('class="slides-ref-tag"')) {
          div.innerHTML = md;
          return div;
        }

        const CARBON_MAP = {
          'carbon:arrow-right': '<svg viewBox="0 0 32 32" width="1.2em" height="1.2em" fill="currentColor" style="display:inline-block;vertical-align:middle;"><path d="m18 6l-1.43 1.393L24.15 15H4v2h20.15l-7.58 7.573L18 26l10-10z"/></svg>',
          'carbon:arrow-left': '<svg viewBox="0 0 32 32" width="1.2em" height="1.2em" fill="currentColor" style="display:inline-block;vertical-align:middle;"><path d="m14 26l1.43-1.393L7.85 17H28v-2H7.85l7.58-7.573L14 6L4 16z"/></svg>',
          'carbon:edit': '<svg viewBox="0 0 32 32" width="1.2em" height="1.2em" fill="currentColor" style="display:inline-block;vertical-align:middle;"><path d="M2 26h28v2H2zM25.4 9c.8-.8.8-2 0-2.8l-3.6-3.6c-.8-.8-2-.8-2.8 0l-15 15V24h6.4l15-15zM20.4 4L24 7.6l-2.4 2.4l-3.6-3.6L20.4 4zM6 22v-3.6l11-11l3.6 3.6l-11 11H6z"/></svg>',
          'carbon:logo-github': '<svg viewBox="0 0 32 32" width="1.2em" height="1.2em" fill="currentColor" style="display:inline-block;vertical-align:middle;"><path fill-rule="evenodd" d="M16 2a14 14 0 0 0-4.43 27.28c.7.13 1-.3 1-.67v-2.38c-3.89.84-4.71-1.88-4.71-1.88a3.7 3.7 0 0 0-1.56-2.05c-1.27-.86.1-.85.1-.85a2.94 2.94 0 0 1 2.14 1.44a3 3 0 0 0 4.08 1.16a2.93 2.93 0 0 1 .89-1.87c-3.1-.35-6.36-1.55-6.36-6.9a5.4 5.4 0 0 1 1.44-3.75a5 5 0 0 1 .14-3.71s1.17-.38 3.85 1.43a13.3 13.3 0 0 1 7 0c2.67-1.81 3.84-1.43 3.84-1.43a5 5 0 0 1 .14 3.71a5.4 5.4 0 0 1 1.44 3.75c0 5.37-3.27 6.54-6.38 6.89a3.35 3.35 0 0 1 1.26 2.61v3.87c0 .38.26.81 1 .67A14 14 0 0 0 16 2"/></svg>'
        };

        if (/@\\w+=['"]|v-\\w+|<button|<a\\b|<carbon:|^<div/i.test(md)) {
          if (md.includes('abs-br') || md.includes('abs-bl') || md.includes('abs-tr') || md.includes('abs-tl') || md.includes('absolute')) {
            div.classList.add("slide-block--absolute");
          }
          let renderedHtml = md;
          for (const [tag, svg] of Object.entries(CARBON_MAP)) {
            const regex = new RegExp("<" + tag + "\\\\s*\\\\/?>", "gi");
            renderedHtml = renderedHtml.replace(regex, svg);
            const regexDash = new RegExp("<" + tag.replace(":", "-") + "\\\\s*\\\\/?>", "gi");
            renderedHtml = renderedHtml.replace(regexDash, svg);
          }
          div.innerHTML = renderedHtml;

          // 挂载交互事件监听
          const allInteractive = div.querySelectorAll("*");
          allInteractive.forEach(btn => {
            let hasNext = false;
            let hasPrev = false;
            for (let i = 0; i < btn.attributes.length; i++) {
              const a = btn.attributes[i];
              const attrName = a.name.toLowerCase();
              if (attrName.indexOf("@click") !== -1 || attrName.indexOf("v-on:click") !== -1) {
                if (a.value.indexOf("next") !== -1) hasNext = true;
                if (a.value.indexOf("prev") !== -1) hasPrev = true;
              }
            }
            if (hasNext) {
              btn.style.cursor = "pointer";
              btn.addEventListener("click", (e) => {
                e.stopPropagation();
                renderSlide(currentIndex + 1);
              });
            } else if (hasPrev) {
              btn.style.cursor = "pointer";
              btn.addEventListener("click", (e) => {
                e.stopPropagation();
                renderSlide(currentIndex - 1);
              });
            }
          });

          return div;
        }

        const hasHeadingTag = /(?:^|\\n)\\s*#{1,6}\\s+/.test(md);
        const hMatch = md.match(/^(#{1,6})\\s+(.*)$/);

        if (hMatch) {
          const level = hMatch[1].length;
          let th = hMatch[2].trim().replace(/\\*\\*(.*?)\\*\\*/g, "<strong>$1</strong>").replace(/\\x60([^\\x60]+)\\x60/g, "<code>$1</code>");
          div.innerHTML = "<h" + level + ">" + th + "</h" + level + ">";
        }
        else if (md.startsWith("\\x60\\x60\\x60")) {
          var rawMaxH = block?.attributes?.["custom-slides-max-height"] || block?.attrs?.["custom-slides-max-height"] || block?.maxHeight || "";
          var customMaxHeight = "";
          if (rawMaxH) {
            var sMaxH = String(rawMaxH).trim();
            if (/^\\d+$/.test(sMaxH)) customMaxHeight = sMaxH + "px";
            else if (/^(\\d+(?:\\.\\d+)?)%$/.test(sMaxH)) customMaxHeight = sMaxH.replace("%", "cqh");
            else if (/^(\\d+(?:\\.\\d+)?)vh$/.test(sMaxH)) customMaxHeight = sMaxH.replace("vh", "cqh");
            else customMaxHeight = sMaxH;
          }
          const heightStyle = customMaxHeight ? ' style="max-height:' + customMaxHeight + ';overflow-y:auto;"' : "";
          div.innerHTML = "<pre" + heightStyle + "><code>" + md.slice(3, -3) + "</code></pre>";
        }
        else if (md.startsWith("> ")) div.innerHTML = "<blockquote><p>" + md.slice(2) + "</p></blockquote>";
        else if ((/<video\\b/i.test(md) || (block && (block.type === "video" || block.type === "NodeVideo"))) && !/^(\\s*)([-*+]|\\d+\\.)\\s+/m.test(md) && !hasHeadingTag && !md.includes("\\n")) {
          div.classList.add("slide-video-container", "slide-media-container", "slide-media-block");
          const isAutoplay = block && block.attributes && block.attributes["custom-slides-autoplay"] === "true";
          const isLoop = block && block.attributes && block.attributes["custom-slides-loop"] === "true";
          const isMuted = block && block.attributes && (block.attributes["custom-slides-muted"] === "true" || isAutoplay);
          const hideControls = block && block.attributes && block.attributes["custom-slides-controls"] === "false";
          let videoHtml = md;
          if (hideControls) videoHtml = videoHtml.replace(/\\bcontrols(?:="[^"]*")?/gi, "").trim();
          else if (!videoHtml.includes("controls")) videoHtml = videoHtml.replace("<video", "<video controls");
          if (isAutoplay && !videoHtml.includes("autoplay")) videoHtml = videoHtml.replace("<video", "<video autoplay playsinline");
          if (isLoop && !videoHtml.includes("loop")) videoHtml = videoHtml.replace("<video", "<video loop");
          if (isMuted && !videoHtml.includes("muted")) videoHtml = videoHtml.replace("<video", "<video muted");
          videoHtml = videoHtml.replace("<video", '<video class="slide-video-player"');
          div.setAttribute("data-autoplay", isAutoplay ? "true" : "false");
          div.innerHTML = videoHtml;
        }
        else if (
          /^(\\s*)([-*+]|\\d+\\.)\\s+/m.test(md) ||
          (md.includes("\\n") && /^(\\s*)([-*+]|\\d+\\.)\\s+/m.test(md.split("\\n").slice(1).join("\\n"))) ||
          ((block && (block.isListItem || block.type === "i")) && !block.isColFirst)
        ) {
          div.classList.add("pdf-list-item");
          const lines = md.split("\\n");
          let isOrdered = false;
          const items = [];
          const leadLines = [];
          for (let i = 0; i < lines.length; i++) {
            const line = lines[i];
            const tr = line.trim();
            if (!tr || /^\\{:.*?\\}$/.test(tr)) continue;
            const um = line.match(/^(\\s*)[-*+]\\s+(.*)$/);
            const om = line.match(/^(\\s*)\\d+\\.\\s+(.*)$/);
            if (um) {
              const indent = um[1].length;
              items.push({ type: "unordered", level: Math.floor(indent / 2), text: um[2], media: [] });
              continue;
            }
            if (om) {
              if (items.length === 0) isOrdered = true;
              const indent = om[1].length;
              items.push({ type: "ordered", level: Math.floor(indent / 2), text: om[2], media: [] });
              continue;
            }
            if (items.length > 0) {
              const im = tr.match(/^!\\[(.*?)\\]\\((.*?)\\)(?:\\{:?[^}]*\\})?$/);
              if (im) {
                const isGif = /\\.gif(?:\\?|$)/i.test(im[2]);
                items[items.length - 1].media.push('<div class="slide-list-media"><img alt="' + im[1] + '" src="' + im[2] + '" class="' + (isGif ? 'list-item-gif' : 'list-item-img') + '" /></div>');
                continue;
              }
              const hm = tr.match(/^<img\\b[\\s\\S]*?\\/?>$/i);
              if (hm) {
                const cleanTr = tr.replace(/\\s+style="[^"]*"/gi, "");
                items[items.length - 1].media.push('<div class="slide-list-media">' + cleanTr + '</div>');
                continue;
              }
              if (/<video\\b/i.test(tr)) {
                let vHtml = tr;
                if (!/<\\/video>/i.test(vHtml)) {
                  while (i + 1 < lines.length && !/<\\/video>/i.test(vHtml)) {
                    i++;
                    vHtml += " " + lines[i].trim();
                  }
                }
                const isAutoplay = block && block.attributes && block.attributes["custom-slides-autoplay"] === "true";
                const isLoop = block && block.attributes && block.attributes["custom-slides-loop"] === "true";
                const isMuted = block && block.attributes && (block.attributes["custom-slides-muted"] === "true" || isAutoplay);
                const hideControls = block && block.attributes && block.attributes["custom-slides-controls"] === "false";
                if (hideControls) vHtml = vHtml.replace(/\\bcontrols(?:="[^"]*")?/gi, "").trim();
                else if (!vHtml.includes("controls")) vHtml = vHtml.replace("<video", "<video controls");
                if (isAutoplay && !vHtml.includes("autoplay")) vHtml = vHtml.replace("<video", "<video autoplay playsinline");
                if (isLoop && !vHtml.includes("loop")) vHtml = vHtml.replace("<video", "<video loop");
                if (isMuted && !vHtml.includes("muted")) vHtml = vHtml.replace("<video", "<video muted");
                vHtml = vHtml.replace("<video", '<video class="slide-video-player"');
                items[items.length - 1].media.push('<div class="slide-list-media slide-video-container slide-media-container" data-autoplay="' + (isAutoplay ? 'true' : 'false') + '">' + vHtml + '</div>');
                continue;
              }
              items[items.length - 1].text += "\\n" + tr;
            } else {
              leadLines.push(tr);
            }
          }

          if (items.length === 0 && (block && (block.isListItem || block.type === "i")) && !block.isColFirst) {
            items.push({ type: "unordered", level: 0, text: md, media: [] });
            leadLines.length = 0;
          }

          let leadHtml = "";
          if (leadLines.length > 0) {
            const lParts = [];
            const firstL = leadLines[0];
            const fhm = firstL.match(/^(#{1,6})\\s+(.*)$/);
            if (fhm) {
              const lvl = fhm[1].length;
              let th = fhm[2].trim().replace(/\\*\\*(.*?)\\*\\*/g, "<strong>$1</strong>").replace(/\\x60([^\\x60]+)\\x60/g, "<code>$1</code>");
              lParts.push('<h' + lvl + ' class="slide-list-item-title">' + th + '</h' + lvl + '>');
            } else {
              let th = firstL.trim().replace(/\\*\\*(.*?)\\*\\*/g, "<strong>$1</strong>").replace(/\\x60([^\\x60]+)\\x60/g, "<code>$1</code>");
              lParts.push('<p class="slide-list-item-title">' + th + '</p>');
            }
            if (leadLines.length > 1) {
              const dLines = leadLines.slice(1);
              let pL = [];
              const flushLeadP = () => {
                if (pL.length > 0) {
                  let txt = pL.map(l => l.replace(/\\*\\*(.*?)\\*\\*/g, "<strong>$1</strong>").replace(/\\x60([^\\x60]+)\\x60/g, "<code>$1</code>")).join("<br/>");
                  lParts.push('<p class="slide-list-item-desc">' + txt + '</p>');
                  pL = [];
                }
              };
              for (const l of dLines) {
                const hm = l.match(/^(#{1,6})\\s+(.*)$/);
                if (hm) {
                  flushLeadP();
                  const lvl = hm[1].length;
                  let th = hm[2].trim().replace(/\\*\\*(.*?)\\*\\*/g, "<strong>$1</strong>").replace(/\\x60([^\\x60]+)\\x60/g, "<code>$1</code>");
                  lParts.push('<h' + lvl + ' class="slide-list-item-title">' + th + '</h' + lvl + '>');
                } else {
                  pL.push(l);
                }
              }
              flushLeadP();
            }
            leadHtml = lParts.join("\\n") + "\\n";
          }

          const tag = isOrdered ? "ol" : "ul";
          const listCls = isOrdered ? "pdf-list pdf-list--ordered" : "pdf-list pdf-list--unordered";
          const liHtml = items.map(it => {
            const med = it.media && it.media.length ? "\\n" + it.media.join("\\n") : "";
            const lines = (it.text || "").split("\\n").map(l => l.trim()).filter(Boolean);
            const hasHeading = lines.some(l => /^#{1,6}\\s+/.test(l));
            const lvl = it.level || 0;
            const nStyle = lvl > 0 ? ' style="margin-left:' + (lvl * 1.25).toFixed(2) + 'em;' + (it.type === 'unordered' ? 'list-style-type:' + (lvl % 2 === 1 ? 'circle' : 'square') + ' !important;' : '') + '"' : "";
            const nClass = lvl > 0 ? " slide-list-item--nested" : "";
            const clsAttr = nClass ? ' class="' + nClass.trim() + '"' : "";
            if (!hasHeading) {
              let h = lines.map(l => l.replace(/\\*\\*(.*?)\\*\\*/g, "<strong>$1</strong>").replace(/\\x60([^\\x60]+)\\x60/g, "<code>$1</code>")).join("<br/>");
              return '<li' + clsAttr + nStyle + '>' + h + med + '</li>';
            }
            const parts = [];
            let pLines = [];
            const flushP = () => {
              if (pLines.length > 0) {
                let ph = pLines.map(l => l.replace(/\\*\\*(.*?)\\*\\*/g, "<strong>$1</strong>").replace(/\\x60([^\\x60]+)\\x60/g, "<code>$1</code>")).join("<br/>");
                parts.push('<p class="slide-list-item-desc">' + ph + '</p>');
                pLines = [];
              }
            };
            for (const l of lines) {
              const hm = l.match(/^(#{1,6})\\s+(.*)$/);
              if (hm) {
                flushP();
                const hl = hm[1].length;
                let th = hm[2].trim().replace(/\\*\\*(.*?)\\*\\*/g, "<strong>$1</strong>").replace(/\\x60([^\\x60]+)\\x60/g, "<code>$1</code>");
                parts.push('<h' + hl + ' class="slide-list-item-title">' + th + '</h' + hl + '>');
              } else {
                pLines.push(l);
              }
            }
            flushP();
            return '<li' + clsAttr + nStyle + '>' + parts.join("\\n") + med + '</li>';
          }).join("\\n");
          div.innerHTML = leadHtml + '<' + tag + ' class="' + listCls + '">\\n' + liHtml + '\\n</' + tag + '>';
        }
        else {
          // 复合块（包含换行、标题或媒体）高保真解析
          const lines = md.split(/\\r?\\n/);
          const subBlocks = [];
          let current = [];
          for (let i = 0; i < lines.length; i++) {
            const line = lines[i];
            const trimmed = line.trim();
            if (/^#{1,6}\\s+/.test(trimmed)) {
              if (current.length > 0) { subBlocks.push(current.join("\\n")); current = []; }
              subBlocks.push(trimmed);
              continue;
            }
            if (!trimmed) {
              if (current.length > 0) { subBlocks.push(current.join("\\n")); current = []; }
              continue;
            }
            if (/^!\\[.*?\\]\\(.*?\\)$/.test(trimmed)) {
              if (current.length > 0) { subBlocks.push(current.join("\\n")); current = []; }
              subBlocks.push(trimmed);
              continue;
            }
            if (/<video\\b/i.test(trimmed)) {
              if (current.length > 0) { subBlocks.push(current.join("\\n")); current = []; }
              let vRaw = trimmed;
              if (!/<\\/video>/i.test(vRaw)) {
                while (i + 1 < lines.length && !/<\\/video>/i.test(vRaw)) {
                  i++;
                  vRaw += "\\n" + lines[i];
                }
              }
              subBlocks.push(vRaw);
              continue;
            }
            current.push(line);
          }
          if (current.length > 0) subBlocks.push(current.join("\\n"));

          if (subBlocks.length > 1 || (subBlocks.length === 1 && /^#{1,6}\\s+/.test(subBlocks[0].trim()))) {
            let isFirstParagraph = true;
            const htmlParts = subBlocks.map(sub => {
              const t = sub.trim();
              if (!t) return "";
              const hm = t.match(/^(#{1,6})\\s+(.*)$/);
              if (hm) {
                isFirstParagraph = false;
                const hl = hm[1].length;
                let th = hm[2].trim().replace(/\\*\\*(.*?)\\*\\*/g, "<strong>$1</strong>").replace(/\\x60([^\\x60]+)\\x60/g, "<code>$1</code>");
                return '<h' + hl + ' class="slide-list-item-title">' + th + '</h' + hl + '>';
              }
              const im = t.match(/^!\\[(.*?)\\]\\((.*?)\\)$/);
              if (im) {
                return '<div class="slide-media-block slide-media-container slide-list-media"><img alt="' + im[1] + '" src="' + im[2] + '" class="slide-media-img" /></div>';
              }
              if (/<video\\b/i.test(t)) {
                return '<div class="slide-media-block slide-video-container slide-media-container">' + t + '</div>';
              }
              if (isFirstParagraph) {
                isFirstParagraph = false;
                const subLines = t.split(/\\r?\\n/).map(l => l.trim()).filter(Boolean);
                if (subLines.length === 1) {
                  let ph = subLines[0].replace(/\\*\\*(.*?)\\*\\*/g, "<strong>$1</strong>").replace(/\\x60([^\\x60]+)\\x60/g, "<code>$1</code>");
                  return '<p class="slide-list-item-title">' + ph + '</p>';
                }
                let titleHtml = subLines[0].replace(/\\*\\*(.*?)\\*\\*/g, "<strong>$1</strong>").replace(/\\x60([^\\x60]+)\\x60/g, "<code>$1</code>");
                let descHtml = subLines.slice(1).map(l => l.replace(/\\*\\*(.*?)\\*\\*/g, "<strong>$1</strong>").replace(/\\x60([^\\x60]+)\\x60/g, "<code>$1</code>")).join("<br/>");
                return '<p class="slide-list-item-title">' + titleHtml + '</p>\\n<p class="slide-list-item-desc">' + descHtml + '</p>';
              }
              let ph = t.replace(/\\*\\*(.*?)\\*\\*/g, "<strong>$1</strong>").replace(/\\x60([^\\x60]+)\\x60/g, "<code>$1</code>");
              return '<p class="slide-list-item-desc">' + ph + '</p>';
            }).filter(Boolean);
            div.innerHTML = htmlParts.join("\\n");
          } else {
            const imgMatch = md.match(/^!\\[(.*?)\\]\\((.*?)\\)$/);
            if (imgMatch) {
              div.classList.add("slide-media-container", "slide-media-block", "slide-block--image");
              div.innerHTML = '<img alt="' + imgMatch[1] + '" src="' + imgMatch[2] + '" class="slide-media-img" />';
            } else {
              let html = md.replace(/\\*\\*(.*?)\\*\\*/g, "<strong>$1</strong>").replace(/\\x60([^\\x60]+)\\x60/g, "<code>$1</code>");
              const pCls = (block && block.isColFirst) ? ' class="slide-list-item-title"' : '';
              div.innerHTML = "<p" + pCls + ">" + html + "</p>";
            }
          }
        }
        return div;
      }
`}function mg(){return`      function renderSlide(idx, direction) {
        if (slides.length === 0) return;
        currentIndex = Math.max(0, Math.min(idx, slides.length - 1));
        const slide = slides[currentIndex];
        pageNum.textContent = (currentIndex + 1) + " / " + slides.length;

        const pageSp = slide.frontmatter?.spacing;
        const currentSpacing = (pageSp && pageSp !== "inherit") ? pageSp : (data.config?.spacing || "normal");
        container.className = "slide-content layout-" + (slide.frontmatter?.layout || "default") + " spacing-" + currentSpacing;
        if (viewport) viewport.setAttribute("data-spacing", currentSpacing);
        container.innerHTML = "";

        const z = typeof slide.frontmatter?.zoom === "number" && slide.frontmatter.zoom > 0 ? slide.frontmatter.zoom : 1;
        if (z !== 1) {
          container.style.width = (100 / z) + "%";
          container.style.height = (100 / z) + "%";
          container.style.transformOrigin = "top left";
          container.style.transform = "scale(" + z + ")";
        } else {
          container.style.width = "100%";
          container.style.height = "100%";
          container.style.transform = "none";
        }

        function isLightColor(colorStr) {
          if (!colorStr || typeof colorStr !== 'string') return null;
          const s = colorStr.trim().toLowerCase();
          if (!s) return null;
          if (/^(?:https?:\\/\\/|\\/|data:|assets\\/|\\.\\/assets\\/|url\\s*\\()/i.test(s)) return null;
          const lightNamed = ['white', 'snow', 'ivory', 'ghostwhite', 'floralwhite', 'aliceblue', 'whitesmoke', 'seashell', 'beige', 'oldlace', 'linen', 'antiquewhite', 'lightyellow', 'lightcyan', 'papayawhip', 'blanchedalmond', 'cornsilk', 'lavender', 'lavenderblush', 'lemonchiffon', 'honeydew', 'mintcream', 'azure', 'mistyrose', 'wheat', 'lightgoldenrodyellow', 'palegoldenrod', 'gainsboro', 'lightgrey', 'lightgray', 'silver', 'pink', 'lightpink', 'peachpuff', 'navajowhite', 'moccasin', 'bisque', 'khaki', 'palegreen', 'lightgreen', 'lightblue', 'powderblue', 'paleturquoise', 'lightsteelblue', 'thistle', 'yellow', 'cyan', 'aqua'];
          const darkNamed = ['black', 'transparent', 'navy', 'darkblue', 'midnightblue', 'darkslategray', 'darkslategrey', 'maroon', 'darkred', 'darkgreen', 'indigo', 'darkslateblue', 'dimgray', 'dimgrey', 'purple', 'brown', 'olive', 'teal', 'blue', 'darkviolet', 'darkmagenta', 'darkcyan', 'darkolivegreen', 'saddlebrown', 'sienna', 'firebrick', 'crimson', 'mediumblue', 'rebeccapurple'];
          if (lightNamed.includes(s)) return true;
          if (darkNamed.includes(s)) return false;

          function calcLum(r, g, b) {
            return 0.299 * r + 0.587 * g + 0.114 * b;
          }
          function parseHexLum(hexRaw) {
            let hex = hexRaw.startsWith('#') ? hexRaw.slice(1) : hexRaw;
            if (hex.length === 3 || hex.length === 4) hex = hex.slice(0, 3).split('').map(c => c + c).join('');
            if (hex.length >= 6) {
              const r = parseInt(hex.substring(0, 2), 16);
              const g = parseInt(hex.substring(2, 4), 16);
              const b = parseInt(hex.substring(4, 6), 16);
              if (!isNaN(r) && !isNaN(g) && !isNaN(b)) return calcLum(r, g, b);
            }
            return null;
          }
          function parseRgbLum(rgbStr) {
            const m = rgbStr.match(/rgba?\\s*\\(\\s*(\\d+(?:\\.\\d+)?)\\s*[,\\s]\\s*(\\d+(?:\\.\\d+)?)\\s*[,\\s]\\s*(\\d+(?:\\.\\d+)?)(?:\\s*[,\\/]\\s*([0-9.]+%?))?/i);
            if (!m) return null;
            const r = Number(m[1]), g = Number(m[2]), b = Number(m[3]);
            if (isNaN(r) || isNaN(g) || isNaN(b)) return null;
            if (m[4] !== undefined) {
              const a = m[4].endsWith('%') ? parseFloat(m[4]) / 100 : parseFloat(m[4]);
              if (!isNaN(a) && a <= 0.05) return null;
            }
            return calcLum(r, g, b);
          }
          function parseHslLum(hslStr) {
            const m = hslStr.match(/hsla?\\s*\\(\\s*([0-9.]+)(?:deg)?\\s*[,\\s]\\s*([0-9.]+)%\\s*[,\\s]\\s*([0-9.]+)%(?:\\s*[,\\/]\\s*([0-9.]+%?))?/i);
            if (!m) return null;
            if (m[4] !== undefined) {
              const a = m[4].endsWith('%') ? parseFloat(m[4]) / 100 : parseFloat(m[4]);
              if (!isNaN(a) && a <= 0.05) return null;
            }
            const h = (((Number(m[1]) % 360) + 360) % 360) / 360;
            const sat = Math.max(0, Math.min(1, Number(m[2]) / 100));
            const lig = Math.max(0, Math.min(1, Number(m[3]) / 100));
            let r, g, b;
            if (sat === 0) {
              r = g = b = lig * 255;
            } else {
              const q = lig < 0.5 ? lig * (1 + sat) : lig + sat - lig * sat;
              const p = 2 * lig - q;
              const hue2rgb = (t) => {
                let tt = t;
                if (tt < 0) tt += 1;
                if (tt > 1) tt -= 1;
                if (tt < 1 / 6) return p + (q - p) * 6 * tt;
                if (tt < 1 / 2) return q;
                if (tt < 2 / 3) return p + (q - p) * (2 / 3 - tt) * 6;
                return p;
              };
              r = hue2rgb(h + 1 / 3) * 255;
              g = hue2rgb(h) * 255;
              b = hue2rgb(h - 1 / 3) * 255;
            }
            return calcLum(r, g, b);
          }

          if (s.startsWith('#')) {
            const lum = parseHexLum(s);
            return lum === null ? null : lum > 140;
          }
          if (/^rgba?\\s*\\(/i.test(s)) {
            const lum = parseRgbLum(s);
            return lum === null ? null : lum > 140;
          }
          if (/^hsla?\\s*\\(/i.test(s)) {
            const lum = parseHslLum(s);
            return lum === null ? null : lum > 140;
          }
          if (/(?:linear|radial|conic)-gradient\\s*\\(/i.test(s)) {
            const luminances = [];
            const hexMatches = s.match(/#(?:[0-9a-f]{8}|[0-9a-f]{6}|[0-9a-f]{4}|[0-9a-f]{3})\\b/gi);
            if (hexMatches) {
              for (const h of hexMatches) {
                const lum = parseHexLum(h);
                if (lum !== null) luminances.push(lum);
              }
            }
            const rgbMatches = s.match(/rgba?\\s*\\([^)]+\\)/gi);
            if (rgbMatches) {
              for (const r of rgbMatches) {
                const lum = parseRgbLum(r);
                if (lum !== null) luminances.push(lum);
              }
            }
            const hslMatches = s.match(/hsla?\\s*\\([^)]+\\)/gi);
            if (hslMatches) {
              for (const h of hslMatches) {
                const lum = parseHslLum(h);
                if (lum !== null) luminances.push(lum);
              }
            }
            const stripped = s.replace(/#[0-9a-f]+|rgba?\\([^)]+\\)|hsla?\\([^)]+\\)/gi, ' ');
            const wordMatches = stripped.match(/\\b[a-z]+\\b/gi);
            if (wordMatches) {
              for (const w of wordMatches) {
                if (w === 'transparent') continue;
                if (lightNamed.includes(w)) luminances.push(240);
                else if (darkNamed.includes(w)) luminances.push(20);
              }
            }
            if (luminances.length > 0) {
              const avg = luminances.reduce((acc, v) => acc + v, 0) / luminances.length;
              return avg > 140;
            }
            if (/\\btransparent\\b/.test(s)) return false;
          }
          return null;
        }

        const slideBg = slide.frontmatter?.background || (data.config && data.config.background);
        const isLightBg = isLightColor(slideBg);
        const curTheme = data.config?.theme || "default";
        if (slideBg) {
          if (/^(http|\\/|data:|assets\\/)/.test(slideBg)) {
            container.style.backgroundImage = 'url("' + slideBg + '")';
            container.style.backgroundSize = "cover";
            container.style.backgroundPosition = "center";
          } else {
            container.style.backgroundImage = "none";
            container.style.background = slideBg;
          }
        } else {
          container.style.backgroundImage = "none";
          container.style.background = "";
        }
        if (isLightBg === true) {
          if (viewport) viewport.setAttribute("data-theme", "light");
          const textColor = curTheme === "apple-basic" ? "#000000" : (curTheme === "seriph" ? "#231f1d" : "#0f172a");
          container.style.color = textColor;
          container.style.setProperty("--slide-text", textColor);
        } else if (isLightBg === false) {
          if (viewport) viewport.setAttribute("data-theme", "dark");
          const textColor = curTheme === "apple-basic" ? "#ffffff" : (curTheme === "seriph" ? "#f5f2eb" : "#f1f5f9");
          container.style.color = textColor;
          container.style.setProperty("--slide-text", textColor);
        } else {
          const fallbackSchema = (data.config?.colorSchema === "light" || data.config?.colorSchema === "dark")
            ? data.config.colorSchema
            : (data.config?.hostThemeMode || null);
          if (viewport) {
            if (fallbackSchema === "light" || fallbackSchema === "dark") {
              viewport.setAttribute("data-theme", fallbackSchema);
            } else {
              viewport.removeAttribute("data-theme");
            }
          }
          container.style.color = "";
          container.style.removeProperty("--slide-text");
        }

        maskOverlayEl = null;
        maskDividerEl = null;
        const maskDir = slide.frontmatter?.mask;
        const isClock = maskDir === "clockwise" || maskDir === "counter-clockwise" || maskDir === "cw" || maskDir === "ccw";
        if (maskDir === "down" || maskDir === "right" || isClock) {
          const isClover = slide.frontmatter?.layout === "clover";
          const ratioInfo = parseMaskRatio(slide.frontmatter.maskRatio, (isClock || isClover) ? 4 : 2);
          const isInitRev = slide.frontmatter.maskInitial === "revealed";
          currentMaskConfig = {
            direction: isClock ? ((maskDir === "cw" || maskDir === "clockwise") ? "clockwise" : "counter-clockwise") : maskDir,
            isClock: isClock,
            totalSteps: isInitRev ? Math.max(0, ratioInfo.steps - 1) : ratioInfo.steps,
            rawSteps: ratioInfo.steps,
            breakpoints: ratioInfo.breakpoints,
            isInitialRevealed: isInitRev,
            style: slide.frontmatter.maskStyle || "solid",
          };
          // FSM-9 优化：后退进入历史页时，遮罩与逐步呈现处于全部揭开完成状态，避免上一页重新变为全黑遮盖
          currentMaskStep = (direction === "backward") ? currentMaskConfig.totalSteps : 0;
        } else {
          currentMaskConfig = null;
          currentMaskStep = 0;
        }

        function createMaskElements() {
          if (!currentMaskConfig) return null;
          const layer = document.createElement("div");
          layer.className = "slides-mask-layer slides-mask-layer--" + currentMaskConfig.style + " slides-mask-layer--" + currentMaskConfig.direction + (currentMaskConfig.isClock ? " slides-mask-layer--clock" : "");
          const overlay = document.createElement("div");
          overlay.className = "slides-mask-overlay";
          const divider = document.createElement("div");
          divider.className = "slides-mask-divider-line" + (currentMaskConfig.isClock ? " slides-mask-divider-line--clock" : "");
          divider.style.opacity = "0";
          if (currentMaskConfig.isClock) {
            const isCw = currentMaskConfig.direction === "clockwise" || currentMaskConfig.direction === "cw";
            divider.style.transform = isCw ? "translateY(-50%) rotate(-180deg)" : "translateY(-50%) rotate(-90deg)";
          }
          layer.appendChild(overlay);
          layer.appendChild(divider);
          maskLayerEl = layer;
          maskOverlayEl = overlay;
          maskDividerEl = divider;
          return { layer, overlay, divider };
        }

        if (slide.frontmatter?.layout === "two-cols") {
          const bodyWrap = document.createElement("div");
          bodyWrap.className = "slides-mask-body-container" + (currentMaskConfig ? " slides-mask-body-container--has-mask" : "");
          bodyWrap.style.display = "flex";
          bodyWrap.style.flexDirection = "row";
          bodyWrap.style.gap = "2rem";
          bodyWrap.style.width = "100%";
          bodyWrap.style.height = "100%";

          const leftCol = document.createElement("div");
          leftCol.className = "two-cols-left";
          const rightCol = document.createElement("div");
          rightCol.className = "two-cols-right";

          const blocks = (slide.blocks || []).filter(b => b.slot !== "slot-divider-right");
          let leftList = [];
          let rightList = [];
          for (const block of blocks) {
            if (block.slot === "right") rightList.push(block);
            else leftList.push(block);
          }
          leftList = cleanColList(leftList);
          rightList = cleanColList(rightList);
          const isCover = slide.frontmatter?.layout === "cover";
          const leftFirstH = !isCover ? leftList.find(isHeadingBlock) : null;
          const rightFirstH = !isCover ? rightList.find(isHeadingBlock) : null;
          for (const b of leftList) leftCol.appendChild(renderBlock(b, b === leftFirstH ? "slides-col-first-heading-block" : ""));
          for (const b of rightList) rightCol.appendChild(renderBlock(b, b === rightFirstH ? "slides-col-first-heading-block" : ""));
          bodyWrap.appendChild(leftCol);
          bodyWrap.appendChild(rightCol);

          const maskEls = createMaskElements();
          if (maskEls) {
            bodyWrap.appendChild(maskEls.layer);
          }
          container.appendChild(bodyWrap);
        } else if (slide.frontmatter?.layout === "cols-header" || slide.frontmatter?.layout === "two-cols-header" || slide.frontmatter?.layout === "three-cols-header" || slide.frontmatter?.layout === "clover") {
          const isCover = slide.frontmatter?.layout === "cover";
          const isClover = slide.frontmatter?.layout === "clover";
          const blocks = (slide.blocks || []).filter(b => b.slot !== "slot-divider-right");
          let headerBlocks = blocks.filter(b => b.slot === "header");
          if (headerBlocks.length === 0 && blocks.length > 0) {
            const candidate = blocks.find(b => b.type === "h" && (!b.slot || b.slot === "default"));
            if (candidate) headerBlocks = [candidate];
          }
          const rem = blocks.filter(b => !headerBlocks.includes(b));

          let targetCols = isClover ? 4 : 2;
          if (isClover) {
            targetCols = 4;
          } else if (slide.frontmatter?.layout === "three-cols-header") {
            targetCols = 3;
          } else if (slide.frontmatter?.layout === "two-cols-header") {
            targetCols = 2;
          } else {
            let maxCol = 0;
            for (const b of rem) {
              const m = (b.slot || "").match(/^col-(d+)$/i);
              if (m) maxCol = Math.max(maxCol, parseInt(m[1], 10));
            }
            if (maxCol >= 2) {
              targetCols = maxCol;
            } else if (slide.frontmatter?.layoutRatio) {
              const r = slide.frontmatter.layoutRatio.trim();
              if (r.includes(":")) {
                const parts = r.split(":").map(p => parseFloat(p.trim())).filter(n => !isNaN(n) && n > 0);
                if (parts.length >= 2) targetCols = parts.length;
              }
            }
          }

          const hasColSlots = rem.some(b => b.slot && /^col-d+$/i.test(b.slot));
          const isSuperBlockCols = isClover || hasColSlots;

          const containerDiv = document.createElement("div");
          containerDiv.className = (isClover ? "layout-clover-container" : ("layout-cols-header-container " + (targetCols === 2 ? "layout-two-cols-header-container" : (targetCols === 3 ? "layout-three-cols-header-container" : "")))) + (isSuperBlockCols ? " has-superblock-cols" : "");
          const headerDiv = document.createElement("div");
          headerDiv.className = "layout-header-section";
          const gridDiv = document.createElement("div");
          gridDiv.className = (isClover ? "layout-clover-grid pdf-clover-wrapper" : ("layout-cols-wrapper layout-cols-grid " + (targetCols === 2 ? "pdf-two-cols-wrapper layout-two-cols-grid" : (targetCols === 3 ? "pdf-three-cols-wrapper layout-three-cols-grid" : "")))) + (isSuperBlockCols ? " has-superblock-cols" : "") + (currentMaskConfig ? " slides-mask-body-container slides-mask-body-container--has-mask" : "");

          const gridCols = isClover ? "repeat(2, minmax(0, 1fr))" : parseRatioToGridCols(slide.frontmatter?.layoutRatio, targetCols);
          if (gridCols) gridDiv.style.gridTemplateColumns = gridCols;
          if (isClover) gridDiv.style.gridTemplateRows = "repeat(2, minmax(0, 1fr))";

          let colsList = [];
          for (let i = 0; i < targetCols; i++) colsList.push([]);
          const hasExplicitCols = rem.some(b => b.slot && (b.slot.startsWith("col-") || b.slot === "left" || b.slot === "right" || b.slot === "center"));
          if (hasExplicitCols && rem.length > 1) {
            for (const b of rem) {
              let idx = 0;
              if (b.slot === "left" || b.slot === "col-1") idx = 0;
              else if (b.slot === "center" || b.slot === "col-2") idx = 1;
              else if (b.slot === "right") idx = targetCols === 2 ? 1 : targetCols - 1;
              else {
                const m = (b.slot || "").match(/^col-(d+)$/i);
                if (m) idx = Math.min(targetCols - 1, Math.max(0, parseInt(m[1], 10) - 1));
              }
              colsList[idx].push(b);
            }
            const hasExplicitColN = rem.some(b => /^col-d+$/i.test((b.slot || "").trim()));
            if (!hasExplicitColN && colsList[0].length === 0) {
              const nonEmptyCols = colsList.filter(c => c.length > 0);
              if (nonEmptyCols.length === 1) {
                colsList = [nonEmptyCols[0], ...Array.from({ length: targetCols - 1 }, () => [])];
              }
            }
          } else if (rem.length === 1) {
            colsList[0] = [rem[0]];
          } else {
            let cur = 0;
            for (let i = 0; i < targetCols; i++) {
              const remainingCols = targetCols - i;
              const remainingItems = rem.length - cur;
              const take = Math.ceil(remainingItems / remainingCols);
              colsList[i] = rem.slice(cur, cur + take);
              cur += take;
            }
          }

          const headerFirstH = !isCover ? headerBlocks.find(isHeadingBlock) : null;
          for (const b of headerBlocks) headerDiv.appendChild(renderBlock(b, b === headerFirstH ? "slides-page-first-heading-block" : ""));
          containerDiv.appendChild(headerDiv);

          colsList.forEach((colBlocks, idx) => {
            const colDiv = document.createElement("div");
            colDiv.className = "pdf-col pdf-col--" + (idx + 1) + " col-" + (idx + 1) + (targetCols === 2 && idx === 0 ? " pdf-col--left" : "") + (targetCols === 2 && idx === 1 ? " pdf-col--right" : "");
            const cleaned = cleanColList(colBlocks);
            const colFirstH = !isCover ? (cleaned.find(isHeadingBlock) || cleaned[0]) : null;
            for (const b of cleaned) colDiv.appendChild(renderBlock(b, b === colFirstH ? "slides-col-first-heading-block" : ""));
            gridDiv.appendChild(colDiv);
          });

          const maskEls = createMaskElements();
          if (maskEls) {
            gridDiv.appendChild(maskEls.layer);
          }

          containerDiv.appendChild(gridDiv);
          container.appendChild(containerDiv);
        } else if (slide.frontmatter?.layout === "image-right" || slide.frontmatter?.layout === "image-left") {
          const isImageRight = slide.frontmatter?.layout === "image-right";
          const isCover = slide.frontmatter?.layout === "cover";
          const allBlocks = slide.blocks || [];
          const pageFirstH = !isCover ? allBlocks.find(isHeadingBlock) : null;

          if (pageFirstH) {
            container.appendChild(renderBlock(pageFirstH, "slides-page-first-heading-block"));
          }

          const bodyWrap = document.createElement("div");
          bodyWrap.className = "slides-mask-body-container" + (currentMaskConfig ? " slides-mask-body-container--has-mask" : "");
          bodyWrap.style.display = "flex";
          bodyWrap.style.flexDirection = isImageRight ? "row" : "row-reverse";
          bodyWrap.style.gap = "2rem";
          bodyWrap.style.width = "100%";
          bodyWrap.style.height = "100%";
          bodyWrap.style.minHeight = "0";
          bodyWrap.style.flex = "1";

          const contentCol = document.createElement("div");
          contentCol.className = isImageRight ? "image-right-content" : "image-left-content";

          for (const block of allBlocks) {
            if (block === pageFirstH) continue;
            contentCol.appendChild(renderBlock(block, ""));
          }

          const imgCol = document.createElement("div");
          imgCol.className = isImageRight ? "image-right-img-container" : "image-left-img-container";
          const img = document.createElement("img");
          img.className = isImageRight ? "image-right-img" : "image-left-img";
          img.src = slide.frontmatter?.image || slide.frontmatter?.background || "";
          img.alt = "Slide cover";
          img.onerror = function() {
            this.src = "https://fastly.jsdelivr.net/gh/slidevjs/slidev-covers@main/static/2HmfbSpvcos.webp";
          };
          imgCol.appendChild(img);

          bodyWrap.appendChild(contentCol);
          bodyWrap.appendChild(imgCol);

          const maskEls = createMaskElements();
          if (maskEls) {
            bodyWrap.appendChild(maskEls.layer);
          }
          container.appendChild(bodyWrap);
        } else {
          const isCover = slide.frontmatter?.layout === "cover";
          const validBlocks = (slide.blocks || []).filter(b => b.slot !== "slot-divider-right");
          const pageFirstH = !isCover ? validBlocks.find(isHeadingBlock) : null;

          if (pageFirstH) {
            container.appendChild(renderBlock(pageFirstH, "slides-page-first-heading-block"));
          }

          const bodyWrap = document.createElement("div");
          bodyWrap.className = "slides-mask-body-container" + (currentMaskConfig ? " slides-mask-body-container--has-mask" : "");

          for (const block of validBlocks) {
            if (block === pageFirstH) continue;
            bodyWrap.appendChild(renderBlock(block, ""));
          }

          const maskEls = createMaskElements();
          if (maskEls) {
            bodyWrap.appendChild(maskEls.layer);
          }
          container.appendChild(bodyWrap);
        }

        updateMaskVisual();
        if (currentMaskConfig && maskLayerEl) {
          requestAnimationFrame(() => {
            if (maskLayerEl) void maskLayerEl.offsetHeight;
          });
        }

        function syncAutoplayVideos() {
          const doSync = () => {
            const videos = container.querySelectorAll("video");
            videos.forEach((v) => {
              const box = v.closest("[data-autoplay]");
              const isAuto = v.hasAttribute("autoplay") || v.autoplay || (box && box.getAttribute("data-autoplay") === "true");
              if (isAuto) {
                v.muted = true;
                v.defaultMuted = true;
                v.setAttribute("muted", "");
                v.playsInline = true;
                v.setAttribute("playsinline", "");
                const playFn = () => {
                  if (!v.paused) return;
                  v.muted = true;
                  v.defaultMuted = true;
                  const p = v.play();
                  if (p !== undefined) {
                    p.catch(() => {
                      v.muted = true;
                      v.defaultMuted = true;
                      setTimeout(() => { if (v.paused) v.play().catch(() => {}); }, 150);
                    });
                  }
                };
                playFn();
                if (!v.__autoplayBound) {
                  v.__autoplayBound = true;
                  v.addEventListener("loadedmetadata", playFn);
                  v.addEventListener("canplay", playFn);
                }
              }
            });
          };
          setTimeout(doSync, 60);
          setTimeout(doSync, 200);
        }
        syncAutoplayVideos();
      }

      // Lightbox 控制逻辑
      const lightbox = document.getElementById("slides-lightbox");
      const lightboxContent = document.getElementById("lightbox-content");
      const lightboxClose = document.getElementById("lightbox-close");
      let isLightboxOpen = false;

`}function gg(){return`      let lightboxScale = 1.0;
      let lightboxTranslateX = 0;
      let lightboxTranslateY = 0;
      let isLightboxDragging = false;
      let lightboxDragStartX = 0;
      let lightboxDragStartY = 0;
      let lightboxInitialTx = 0;
      let lightboxInitialTy = 0;
      let lightboxHasMoved = false;
      let lightboxMediaType = "";

      function updateLightboxImgTransform(animate) {
        if (!lightboxContent) return;
        const img = lightboxContent.querySelector(".slides-lightbox-img");
        if (!img) return;
        img.style.transformOrigin = "center center";
        img.style.transform = "translate(" + lightboxTranslateX + "px, " + lightboxTranslateY + "px) scale(" + lightboxScale + ")";
        img.style.transition = animate ? "transform 0.12s cubic-bezier(0.16, 1, 0.3, 1)" : "none";
        img.style.cursor = lightboxScale > 1.0 ? (isLightboxDragging ? "grabbing" : "grab") : "zoom-in";
      }

      function resetLightboxZoom() {
        lightboxScale = 1.0;
        lightboxTranslateX = 0;
        lightboxTranslateY = 0;
        isLightboxDragging = false;
        lightboxHasMoved = false;
        updateLightboxImgTransform(false);
      }

      function openLightbox(type, src, alt) {
        if (!lightbox || !lightboxContent) return;
        lightboxContent.innerHTML = "";
        lightboxMediaType = type;
        resetLightboxZoom();
        if (type === "video") {
          const v = document.createElement("video");
          v.className = "slides-lightbox-video";
          v.src = src;
          v.controls = true;
          v.autoplay = true;
          v.playsInline = true;
          lightboxContent.appendChild(v);
        } else {
          const img = document.createElement("img");
          img.className = "slides-lightbox-img";
          img.src = src;
          img.alt = alt || "";
          lightboxContent.appendChild(img);
          updateLightboxImgTransform(false);
        }
        lightbox.classList.add("active");
        isLightboxOpen = true;
      }

      function closeLightbox() {
        if (!lightbox) return;
        const v = lightbox.querySelector("video");
        if (v) v.pause();
        lightbox.classList.remove("active");
        if (lightboxContent) lightboxContent.innerHTML = "";
        isLightboxOpen = false;
        lightboxMediaType = "";
        resetLightboxZoom();
      }

      function handleLightboxWheel(e) {
        if (!lightboxContent || lightboxMediaType !== "image") return;
        const img = lightboxContent.querySelector(".slides-lightbox-img");
        if (!img) return;
        e.preventDefault();
        e.stopPropagation();
        if (Math.abs(e.deltaY) < 1) return;

        const factor = e.deltaY < 0 ? 1.2 : 1 / 1.2;
        const currentScale = lightboxScale;
        let nextScale = currentScale * factor;

        if (nextScale <= 1.02) {
          resetLightboxZoom();
          return;
        }
        if (nextScale > 5.0) {
          nextScale = 5.0;
        }

        const rect = img.getBoundingClientRect();
        const currentCenterX = rect.left + rect.width / 2;
        const currentCenterY = rect.top + rect.height / 2;
        const origCenterX = currentCenterX - lightboxTranslateX;
        const origCenterY = currentCenterY - lightboxTranslateY;

        const nextTx = (e.clientX - origCenterX) * (1 - nextScale / currentScale) + lightboxTranslateX * (nextScale / currentScale);
        const nextTy = (e.clientY - origCenterY) * (1 - nextScale / currentScale) + lightboxTranslateY * (nextScale / currentScale);

        lightboxTranslateX = Math.round(nextTx * 10) / 10;
        lightboxTranslateY = Math.round(nextTy * 10) / 10;
        lightboxScale = Math.round(nextScale * 1000) / 1000;
        updateLightboxImgTransform(true);
      }

      if (lightboxContent) {
        lightboxContent.addEventListener("pointerdown", (e) => {
          if (e.button !== 0 || lightboxMediaType !== "image" || lightboxScale <= 1.0) return;
          const img = lightboxContent.querySelector(".slides-lightbox-img");
          if (!img || (e.target !== img && !img.contains(e.target))) return;
          e.preventDefault();
          e.stopPropagation();
          isLightboxDragging = true;
          lightboxDragStartX = e.clientX;
          lightboxDragStartY = e.clientY;
          lightboxInitialTx = lightboxTranslateX;
          lightboxInitialTy = lightboxTranslateY;
          lightboxHasMoved = false;
          if (img.setPointerCapture) {
            try { img.setPointerCapture(e.pointerId); } catch (_) {}
          }
          updateLightboxImgTransform(false);
        });

        window.addEventListener("pointermove", (e) => {
          if (!isLightboxDragging || lightboxMediaType !== "image") return;
          e.preventDefault();
          e.stopPropagation();
          const dx = e.clientX - lightboxDragStartX;
          const dy = e.clientY - lightboxDragStartY;
          if (Math.abs(dx) > 3 || Math.abs(dy) > 3) {
            lightboxHasMoved = true;
          }
          lightboxTranslateX = Math.round((lightboxInitialTx + dx) * 10) / 10;
          lightboxTranslateY = Math.round((lightboxInitialTy + dy) * 10) / 10;
          updateLightboxImgTransform(false);
        });

        const onLightboxPointerEnd = (e) => {
          if (!isLightboxDragging) return;
          isLightboxDragging = false;
          const img = lightboxContent ? lightboxContent.querySelector(".slides-lightbox-img") : null;
          if (img && img.releasePointerCapture) {
            try { img.releasePointerCapture(e.pointerId); } catch (_) {}
          }
          updateLightboxImgTransform(false);
        };
        window.addEventListener("pointerup", onLightboxPointerEnd);
        window.addEventListener("pointercancel", onLightboxPointerEnd);

        lightboxContent.addEventListener("dblclick", (e) => {
          if (lightboxMediaType !== "image") return;
          const img = lightboxContent.querySelector(".slides-lightbox-img");
          if (!img || (e.target !== img && !img.contains(e.target))) return;
          e.preventDefault();
          e.stopPropagation();
          if (lightboxScale > 1.05 || lightboxTranslateX !== 0 || lightboxTranslateY !== 0) {
            resetLightboxZoom();
          } else {
            const targetScale = 2.0;
            const rect = img.getBoundingClientRect();
            const currentCenterX = rect.left + rect.width / 2;
            const currentCenterY = rect.top + rect.height / 2;
            const origCenterX = currentCenterX - lightboxTranslateX;
            const origCenterY = currentCenterY - lightboxTranslateY;
            lightboxTranslateX = Math.round(((e.clientX - origCenterX) * (1 - targetScale / 1.0)) * 10) / 10;
            lightboxTranslateY = Math.round(((e.clientY - origCenterY) * (1 - targetScale / 1.0)) * 10) / 10;
            lightboxScale = targetScale;
            updateLightboxImgTransform(true);
          }
        });
      }

      if (lightboxClose) {
        lightboxClose.addEventListener("click", (e) => {
          e.stopPropagation();
          closeLightbox();
        });
      }
      if (lightbox) {
        lightbox.addEventListener("click", (e) => {
          if (e.target === lightbox || e.target === lightboxClose) {
            if (lightboxHasMoved) {
              lightboxHasMoved = false;
              return;
            }
            e.stopPropagation();
            closeLightbox();
          }
        });
      }

      btnPrev.addEventListener("click", () => goPrev());
      btnNext.addEventListener("click", () => goNext());
      btnFullscreen.addEventListener("click", () => {
        if (!document.fullscreenElement) {
          document.documentElement.requestFullscreen().then(() => updateScale()).catch(() => {});
        } else {
          document.exitFullscreen().then(() => updateScale()).catch(() => {});
        }
      });

      // 「数字+回车」跳页输入状态：数字缓冲实时回显，Esc/超时清空，越界红色抖动提示
      let jumpDisplay = "";
      let jumpInvalid = false;
      let jumpIdleTimer = null;
      let jumpFlashTimer = null;

`}function yg(){return`      function hideJumpIndicator() {
        jumpDisplay = "";
        jumpInvalid = false;
        jumpBadge.style.display = "none";
        jumpBadge.classList.remove("is-invalid");
        if (jumpIdleTimer) { clearTimeout(jumpIdleTimer); jumpIdleTimer = null; }
        if (jumpFlashTimer) { clearTimeout(jumpFlashTimer); jumpFlashTimer = null; }
      }

      function renderJumpBadge() {
        jumpBadge.textContent = jumpDisplay;
        jumpBadge.style.display = jumpDisplay ? "block" : "none";
        jumpBadge.classList.toggle("is-invalid", jumpInvalid);
      }

      function armJumpIdleTimer() {
        if (jumpIdleTimer) clearTimeout(jumpIdleTimer);
        jumpIdleTimer = setTimeout(hideJumpIndicator, 1500);
      }

      function flashJumpInvalid() {
        if (jumpIdleTimer) { clearTimeout(jumpIdleTimer); jumpIdleTimer = null; }
        jumpInvalid = true;
        renderJumpBadge();
        if (jumpFlashTimer) clearTimeout(jumpFlashTimer);
        jumpFlashTimer = setTimeout(hideJumpIndicator, 500);
      }

      function isEditableKeyTarget(t) {
        if (!t || !t.tagName) return false;
        return t.tagName === "INPUT" || t.tagName === "TEXTAREA" || t.tagName === "SELECT" || t.isContentEditable === true;
      }

`}function bg(){return`      function getSlideOverviewTitle(slide) {
        const fm = slide?.frontmatter || {};
        if (fm.title) return String(fm.title);
        const blocks = slide?.blocks || [];
        for (const b of blocks) {
          if (b.type === "h" || /^h[1-6]$/i.test(b.subType || "")) {
            const md = (b.rawMarkdown || b.content || "").trim();
            return md.replace(/^#{1,6}s+/, "").replace(/[*_\`]/g, "").slice(0, 40);
          }
        }
        return "";
      }

      // 把任意一页渲染为静态缩略图：复用 renderBlock 与主渲染同名版式类，导出样式自动生效
      function buildOverviewThumbInto(canvas, slide) {
        const fm = slide.frontmatter || {};
        const layout = fm.layout || "default";
        const blocks = (slide.blocks || []).filter((b) => b.slot !== "slot-divider-right");
        let headerBlocks = blocks.filter((b) => b.slot === "header");
        if (headerBlocks.length === 0 && blocks.length > 0) {
          const candidate = blocks.find((b) => b.type === "h" && (!b.slot || b.slot === "default"));
          if (candidate) headerBlocks = [candidate];
        }
        const rem = blocks.filter((b) => !headerBlocks.includes(b));
        let bodyEl = null;

        if (layout === "cols-header" || layout === "two-cols-header" || layout === "three-cols-header" || layout === "clover") {
          const isClover = layout === "clover";
          let targetCols = isClover ? 4 : 2;
          if (layout === "three-cols-header") targetCols = 3;
          else if (layout === "two-cols-header") targetCols = 2;
          else if (!isClover) {
            let maxCol = 0;
            for (const b of rem) {
              const m = (b.slot || "").match(/^col-(d+)$/i);
              if (m) maxCol = Math.max(maxCol, parseInt(m[1], 10));
            }
            if (maxCol >= 2) targetCols = maxCol;
            else if (fm.layoutRatio) {
              const r = String(fm.layoutRatio).trim();
              if (r.includes(":")) {
                const parts = r.split(":").map((p) => parseFloat(p.trim())).filter((n) => !isNaN(n) && n > 0);
                if (parts.length >= 2) targetCols = parts.length;
              }
            }
          }
          const hasColSlots = rem.some((b) => b.slot && /^col-d+$/i.test(b.slot));
          const containerDiv = document.createElement("div");
          containerDiv.className = (isClover ? "layout-clover-container" : ("layout-cols-header-container " + (targetCols === 2 ? "layout-two-cols-header-container" : (targetCols === 3 ? "layout-three-cols-header-container" : "")))) + (hasColSlots || isClover ? " has-superblock-cols" : "");
          const headerDiv = document.createElement("div");
          headerDiv.className = "layout-header-section";
          for (const b of headerBlocks) headerDiv.appendChild(renderBlock(b, ""));
          containerDiv.appendChild(headerDiv);
          const gridDiv = document.createElement("div");
          gridDiv.className = (isClover ? "layout-clover-grid pdf-clover-wrapper" : ("layout-cols-wrapper layout-cols-grid " + (targetCols === 2 ? "pdf-two-cols-wrapper layout-two-cols-grid" : (targetCols === 3 ? "pdf-three-cols-wrapper layout-three-cols-grid" : "")))) + (hasColSlots || isClover ? " has-superblock-cols" : "");
          const gridCols = isClover ? "repeat(2, minmax(0, 1fr))" : parseRatioToGridCols(fm.layoutRatio, targetCols);
          if (gridCols) gridDiv.style.gridTemplateColumns = gridCols;
          if (isClover) gridDiv.style.gridTemplateRows = "repeat(2, minmax(0, 1fr))";
          let colsList = [];
          for (let i = 0; i < targetCols; i++) colsList.push([]);
          const hasExplicitCols = rem.some((b) => b.slot && (b.slot.startsWith("col-") || b.slot === "left" || b.slot === "right" || b.slot === "center"));
          if (hasExplicitCols && rem.length > 1) {
            for (const b of rem) {
              let idx = 0;
              if (b.slot === "left" || b.slot === "col-1") idx = 0;
              else if (b.slot === "center" || b.slot === "col-2") idx = 1;
              else if (b.slot === "right") idx = targetCols === 2 ? 1 : targetCols - 1;
              else {
                const m = (b.slot || "").match(/^col-(d+)$/i);
                if (m) idx = Math.min(targetCols - 1, Math.max(0, parseInt(m[1], 10) - 1));
              }
              colsList[idx].push(b);
            }
            const hasExplicitColN = rem.some(b => /^col-d+$/i.test((b.slot || "").trim()));
            if (!hasExplicitColN && colsList[0].length === 0) {
              const nonEmptyCols = colsList.filter(c => c.length > 0);
              if (nonEmptyCols.length === 1) {
                colsList = [nonEmptyCols[0], ...Array.from({ length: targetCols - 1 }, () => [])];
              }
            }
          } else if (rem.length === 1) {
            colsList[0] = [rem[0]];
          } else {
            let cur = 0;
            for (let i = 0; i < targetCols; i++) {
              const remainingCols = targetCols - i;
              const remainingItems = rem.length - cur;
              const take = Math.ceil(remainingItems / remainingCols);
              colsList[i] = rem.slice(cur, cur + take);
              cur += take;
            }
          }
          colsList.forEach((colBlocks, idx) => {
            const colDiv = document.createElement("div");
            colDiv.className = "pdf-col pdf-col--" + (idx + 1) + " col-" + (idx + 1) + (targetCols === 2 && idx === 0 ? " pdf-col--left" : "") + (targetCols === 2 && idx === 1 ? " pdf-col--right" : "");
            const cleaned = cleanColList(colBlocks);
            for (const b of cleaned) colDiv.appendChild(renderBlock(b, ""));
            gridDiv.appendChild(colDiv);
          });
          containerDiv.appendChild(gridDiv);
          bodyEl = containerDiv;
        } else if (layout === "two-cols") {
          bodyEl = document.createElement("div");
          bodyEl.style.display = "flex";
          bodyEl.style.flexDirection = "row";
          bodyEl.style.gap = "2rem";
          bodyEl.style.width = "100%";
          bodyEl.style.flex = "1";
          bodyEl.style.minHeight = "0";
          let leftList = [];
          let rightList = [];
          for (const b of blocks) {
            if (b.slot === "right") rightList.push(b);
            else leftList.push(b);
          }
          const leftCol = document.createElement("div");
          leftCol.className = "two-cols-left";
          const rightCol = document.createElement("div");
          rightCol.className = "two-cols-right";
          for (const b of cleanColList(leftList)) leftCol.appendChild(renderBlock(b, ""));
          for (const b of cleanColList(rightList)) rightCol.appendChild(renderBlock(b, ""));
          bodyEl.appendChild(leftCol);
          bodyEl.appendChild(rightCol);
        } else if (layout === "image-right" || layout === "image-left") {
          const isImageRight = layout === "image-right";
          bodyEl = document.createElement("div");
          bodyEl.style.display = "flex";
          bodyEl.style.flexDirection = isImageRight ? "row" : "row-reverse";
          bodyEl.style.gap = "2rem";
          bodyEl.style.width = "100%";
          bodyEl.style.flex = "1";
          bodyEl.style.minHeight = "0";
          const contentCol = document.createElement("div");
          contentCol.className = isImageRight ? "image-right-content" : "image-left-content";
          for (const b of blocks) contentCol.appendChild(renderBlock(b, ""));
          const imgCol = document.createElement("div");
          imgCol.className = isImageRight ? "image-right-img-container" : "image-left-img-container";
          const url = fm.image || fm.background || "";
          if (url) {
            const img = document.createElement("img");
            img.className = isImageRight ? "image-right-img" : "image-left-img";
            img.src = url;
            img.alt = "Slide cover";
            imgCol.appendChild(img);
          }
          bodyEl.appendChild(contentCol);
          bodyEl.appendChild(imgCol);
        } else {
          bodyEl = document.createElement("div");
          for (const b of blocks) bodyEl.appendChild(renderBlock(b, ""));
        }
        canvas.appendChild(bodyEl);
      }

      function buildOverviewCards() {
        if (overviewBuilt) return;
        overviewBuilt = true;
        const scale = OVERVIEW_CARD_W / baseWidth;
        const canvasH = Math.round(baseHeight * scale);
        slides.forEach((slide, idx) => {
          const card = document.createElement("div");
          card.className = "slides-overview-card";
          card.dataset.idx = String(idx);
          const box = document.createElement("div");
          box.className = "slides-overview-canvas-box";
          box.style.height = canvasH + "px";
          const fm = slide.frontmatter || {};
          const spacing = (fm.spacing && fm.spacing !== "inherit") ? fm.spacing : ((data.config && data.config.spacing) || "normal");
          const canvas = document.createElement("div");
          canvas.className = "slides-overview-canvas slide-content layout-" + (fm.layout || "default") + " spacing-" + spacing;
          canvas.style.width = baseWidth + "px";
          canvas.style.height = baseHeight + "px";
          canvas.style.transform = "scale(" + scale + ")";
          const bg = fm.background || (data.config && data.config.background);
          if (bg) {
            if (/^(http|\\/|data:|assets\\/)/.test(bg)) {
              canvas.style.backgroundImage = 'url("' + bg + '")';
              canvas.style.backgroundSize = "cover";
              canvas.style.backgroundPosition = "center";
            } else {
              canvas.style.background = bg;
            }
          }
          box.appendChild(canvas);
          const caption = document.createElement("div");
          caption.className = "slides-overview-caption";
          const pageNo = document.createElement("span");
          pageNo.className = "slides-overview-page-no";
          pageNo.textContent = String(idx + 1);
          caption.appendChild(pageNo);
          const title = getSlideOverviewTitle(slide);
          if (title) {
            const titleEl = document.createElement("span");
            titleEl.className = "slides-overview-title";
            titleEl.textContent = title;
            caption.appendChild(titleEl);
          }
          card.appendChild(box);
          card.appendChild(caption);
          card.addEventListener("click", (e) => {
            e.stopPropagation();
            goFromOverview(idx + 1);
          });
          overviewGrid.appendChild(card);
        });
        updateOverviewCurrentMark();
      }

      function renderOverviewThumb(card) {
        if (!card || card.dataset.rendered === "1") return;
        const idx = Number(card.dataset.idx);
        const slide = slides[idx];
        const canvas = card.querySelector(".slides-overview-canvas");
        if (slide && canvas) buildOverviewThumbInto(canvas, slide);
        card.dataset.rendered = "1";
      }

      function ensureOverviewObserver() {
        if (overviewObserver || typeof window.IntersectionObserver !== "function") return;
        overviewObserver = new IntersectionObserver((entries) => {
          for (const en of entries) {
            if (!en.isIntersecting) continue;
            overviewObserver.unobserve(en.target);
            renderOverviewThumb(en.target);
          }
        }, { rootMargin: "240px" });
      }

      function observeOverviewCards() {
        if (!overviewObserver) return;
        const cards = overviewGrid.children;
        for (let i = 0; i < cards.length; i++) {
          if (cards[i].dataset.rendered !== "1") overviewObserver.observe(cards[i]);
        }
      }

      function updateOverviewCurrentMark() {
        const cards = overviewGrid.children;
        for (let i = 0; i < cards.length; i++) {
          const pageNo = cards[i].querySelector(".slides-overview-page-no");
          if (pageNo) pageNo.classList.toggle("is-current", i === currentIndex);
        }
      }

      function setOverviewFocus(page) {
        const total = slides.length || 1;
        overviewFocus = Math.min(Math.max(1, page), total);
        const cards = overviewGrid.children;
        for (let i = 0; i < cards.length; i++) {
          cards[i].classList.toggle("is-active", i + 1 === overviewFocus);
        }
        const el = cards[overviewFocus - 1];
        if (el && el.scrollIntoView) el.scrollIntoView({ block: "nearest", behavior: "smooth" });
      }

      function getOverviewCols() {
        if (!overviewGrid || !overviewGrid.clientWidth) return 1;
        return Math.max(1, Math.round(overviewGrid.clientWidth / (OVERVIEW_CARD_W + 18)));
      }

      function goFromOverview(page) {
        const p = parseInt(page, 10);
        if (isNaN(p) || p < 1 || p > slides.length) return;
        closeOverview();
        renderSlide(p - 1);
        updateOverviewCurrentMark();
      }

      function openOverview() {
        if (slides.length === 0) return;
        buildOverviewCards();
        overviewOpen = true;
        overviewOverlay.style.display = "block";
        ensureOverviewObserver();
        if (overviewObserver) {
          observeOverviewCards();
        } else {
          const cards = overviewGrid.children;
          for (let i = 0; i < cards.length; i++) renderOverviewThumb(cards[i]);
        }
        setOverviewFocus(currentIndex + 1);
      }

      function closeOverview() {
        overviewOpen = false;
        overviewOverlay.style.display = "none";
        hideJumpIndicator();
        if (overviewObserver) {
          const cards = overviewGrid.children;
          for (let i = 0; i < cards.length; i++) overviewObserver.unobserve(cards[i]);
        }
      }

      function toggleOverview() {
        if (overviewOpen) closeOverview();
        else openOverview();
      }

      // 总览打开期间接管全部按键：修复上游总览中空格/PGUP/PGDN 仍会翻页的漏洞
      function handleOverviewKeyDown(e) {
        if (e.ctrlKey || e.metaKey || e.altKey) return;
        if (e.isComposing || isEditableKeyTarget(e.target)) return;
        if (/^[0-9]$/.test(e.key)) {
          if (!jumpInvalid && jumpDisplay.length < 4) {
            jumpDisplay += e.key;
            const p = parseInt(jumpDisplay, 10);
            if (!isNaN(p) && p >= 1 && p <= slides.length) setOverviewFocus(p);
            renderJumpBadge();
            armJumpIdleTimer();
          }
          e.preventDefault();
          return;
        }
        if (e.key === "Enter" && jumpDisplay) {
          if (!jumpInvalid) {
            const page = parseInt(jumpDisplay, 10);
            if (!isNaN(page) && page >= 1 && page <= slides.length) {
              goFromOverview(page);
            } else {
              flashJumpInvalid();
            }
          }
          e.preventDefault();
          return;
        }
        if ((e.key === "Escape" || e.key === "Esc") && (jumpDisplay || jumpInvalid)) {
          hideJumpIndicator();
          e.preventDefault();
          return;
        }
        if (e.key === "ArrowRight") {
          e.preventDefault();
          setOverviewFocus(overviewFocus + 1);
          return;
        }
        if (e.key === "ArrowLeft") {
          e.preventDefault();
          setOverviewFocus(overviewFocus - 1);
          return;
        }
        if (e.key === "ArrowDown" || e.key === "PageDown") {
          e.preventDefault();
          setOverviewFocus(overviewFocus + getOverviewCols());
          return;
        }
        if (e.key === "ArrowUp" || e.key === "PageUp") {
          e.preventDefault();
          setOverviewFocus(overviewFocus - getOverviewCols());
          return;
        }
        if (e.key === " ") {
          e.preventDefault();
          return;
        }
        if (e.key === "Enter") {
          e.preventDefault();
          goFromOverview(overviewFocus);
          return;
        }
        if (e.key === "Escape" || e.key === "Esc" || e.key === "o" || e.key === "O") {
          e.preventDefault();
          closeOverview();
        }
      }

      window.addEventListener("keydown", (e) => {
        if (e.key === "Escape" || e.key === "Esc") {
          if (isLightboxOpen) {
            closeLightbox();
            e.preventDefault();
            return;
          }
        }
        if (isLightboxOpen) return;
        // 总览打开期间全部按键由总览层接管
        if (overviewOpen) {
          handleOverviewKeyDown(e);
          return;
        }
        // 「数字+回车」跳页：可输入元素、修饰键、IME 组合输入中不拦截
        if (!e.ctrlKey && !e.metaKey && !e.altKey && !e.isComposing && !isEditableKeyTarget(e.target)) {
          if (/^[0-9]$/.test(e.key)) {
            if (!jumpInvalid && jumpDisplay.length < 4) {
              jumpDisplay += e.key;
              renderJumpBadge();
              armJumpIdleTimer();
            }
            e.preventDefault();
            return;
          }
          if (e.key === "Enter" && jumpDisplay) {
            if (!jumpInvalid) {
              const page = parseInt(jumpDisplay, 10);
              if (!isNaN(page) && page >= 1 && page <= slides.length) {
                hideJumpIndicator();
                renderSlide(page - 1);
              } else {
                flashJumpInvalid();
              }
            }
            e.preventDefault();
            return;
          }
          if ((e.key === "Escape" || e.key === "Esc") && (jumpDisplay || jumpInvalid)) {
            hideJumpIndicator();
            e.preventDefault();
            return;
          }
          if (e.key === "o" || e.key === "O") {
            e.preventDefault();
            toggleOverview();
            return;
          }
        }
        if (e.key === "ArrowRight" || e.key === " " || e.key === "ArrowDown") goNext();
        if (e.key === "ArrowLeft" || e.key === "ArrowUp") goPrev();
        if (e.key === "f" || e.key === "F") btnFullscreen.click();
      });

      // 监听鼠标滚轮上下翻页调度
      let lastWheelTime = 0;
      const WHEEL_COOLDOWN_MS = 280;
      const WHEEL_DELTA_THRESHOLD = 15;

`}function vg(){return`      function canElementScrollY(el, deltaY) {
        let cur = el;
        while (cur && cur !== document.body && cur !== document.documentElement) {
          if (cur.classList && (cur.classList.contains("slides-viewport") || cur.classList.contains("slides-stage") || cur.classList.contains("slide-container"))) {
            break;
          }
          const style = window.getComputedStyle(cur);
          const overflowY = style.overflowY;
          if (overflowY === "auto" || overflowY === "scroll") {
            const maxScroll = cur.scrollHeight - cur.clientHeight;
            if (maxScroll > 2) {
              if (deltaY > 0 && cur.scrollTop < maxScroll - 1) return true;
              if (deltaY < 0 && cur.scrollTop > 1) return true;
            }
          }
          cur = cur.parentElement;
        }
        return false;
      }

      window.addEventListener("wheel", (e) => {
        if (isLightboxOpen) {
          if (typeof handleLightboxWheel === "function") {
            handleLightboxWheel(e);
          }
          return;
        }
        // 总览打开时滚轮交给总览列表原生滚动，不触发翻页
        if (overviewOpen) return;
        if (Math.abs(e.deltaY) < Math.abs(e.deltaX)) return;
        if (Math.abs(e.deltaY) < WHEEL_DELTA_THRESHOLD) return;

        const target = e.target instanceof Element ? e.target : e.target?.parentElement;
        if (target && canElementScrollY(target, e.deltaY)) return;

        e.preventDefault();
        const now = Date.now();
        if (now - lastWheelTime < WHEEL_COOLDOWN_MS) return;
        lastWheelTime = now;

        if (e.deltaY > 0) {
          goNext();
        } else {
          goPrev();
        }
      }, { passive: false });

      document.addEventListener("click", (e) => {
        if (isLightboxOpen) {
          if (typeof lightboxHasMoved !== "undefined" && lightboxHasMoved) {
            lightboxHasMoved = false;
            e.stopPropagation();
            return;
          }
          const target = e.target instanceof Element ? e.target : e.target?.parentElement;
          const isMediaItself = target && target.closest && target.closest(".slides-lightbox-img, .slides-lightbox-video");
          if (!isMediaItself) {
            e.stopPropagation();
            closeLightbox();
          }
          return;
        }
        // 总览打开时空白点击由总览层自身处理，不触发底层翻页
        if (overviewOpen) return;
        if (e.button !== 0) return;
        const targetEl = e.target instanceof Element ? e.target : e.target?.parentElement;
        if (!targetEl || !targetEl.closest) return;

        const hasPendingMask = currentMaskConfig && (currentMaskStep < currentMaskConfig.totalSteps);
        if (hasPendingMask) {
          const isBottomControls = targetEl.closest(".controls-bar, .controls, .slides-toc");
          if (isBottomControls) return;
          e.preventDefault();
          e.stopPropagation();
          goNext();
          return;
        }

        const refEl = targetEl.closest("[data-ref-id]");
        if (refEl) {
          const id = refEl.getAttribute("data-ref-id");
          if (id) {
            window.open("siyuan://blocks/" + id, "_blank");
            return;
          }
        }

        // 媒体点击唤起 Lightbox 放大模态
        const mediaEl = targetEl.closest(".slide-content img, .slide-content video");
        if (mediaEl && !mediaEl.closest(".controls, .controls-bar, button, a")) {
          e.stopPropagation();
          const isVideo = mediaEl.tagName.toLowerCase() === "video";
          const src = isVideo ? (mediaEl.currentSrc || mediaEl.src || mediaEl.querySelector("source")?.src) : mediaEl.src;
          if (src) {
            openLightbox(isVideo ? "video" : "image", src, mediaEl.alt || "");
            return;
          }
        }

        const selection = window.getSelection ? window.getSelection().toString().trim() : "";
        if (selection.length > 0) return;

        const isComponent = targetEl.closest(
          ".slide-block, .controls-bar, .image-right-img-container, .image-left-img-container, .controls, img, video, audio, button, a, input, textarea, select, [data-clickable], [data-ref-id], .slides-toc, .empty-state"
        );
        if (isComponent) return;

        const isLeft = e.clientX < window.innerWidth / 2;
        if (isLeft) {
          goPrev();
        } else {
          goNext();
        }
      });

      renderSlide(0);
      updateScale();
    })();`}function kg(){return[ug(),fg(),hg(),pg(),mg(),gg(),yg(),bg(),vg()].join("")}function wg(e,t=!1){var l;const o=new Set,i=r=>{if(!r||typeof r!="string")return;const a=r.trim();!a||a.startsWith("data:")||(a.includes("/assets/")||a.startsWith("assets/")||a.startsWith("./assets/")||a.startsWith("/assets/")||t&&/^https?:\/\//i.test(a))&&o.add(a)},n=r=>{if(!r||typeof r!="string")return;const a=/!\[.*?\]\((.+?)\)/g;let c;for(;(c=a.exec(r))!==null;)c[1]&&i(c[1]);const u=/<(?:img|video|audio|source)\b[^>]*?\bsrc=["'](.*?)["']/gi;for(;(c=u.exec(r))!==null;)c[1]&&i(c[1]);const f=/url\(\s*["']?(.*?)["']?\s*\)/gi;for(;(c=f.exec(r))!==null;)c[1]&&i(c[1])},s=r=>{if(r&&(r.rawMarkdown&&n(r.rawMarkdown),r.content&&n(r.content),Array.isArray(r.children)))for(const a of r.children)s(a)};(l=e.config)!=null&&l.background&&i(e.config.background);for(const r of e.slides||[]){if(r.frontmatter)for(const a of Object.values(r.frontmatter))typeof a=="string"&&i(a);if(r.rawMarkdown&&n(r.rawMarkdown),Array.isArray(r.blocks))for(const a of r.blocks)s(a);if(Array.isArray(r.noteBlocks))for(const a of r.noteBlocks)s(a);r.notes&&n(r.notes)}try{const r=JSON.stringify(e),a=/(?:https?:\/\/[^\s"'<>\)\\]+)?(?:\.\/|\/)?assets\/[^\s"'<>\)\\]+/g,c=r.match(a);if(c)for(const u of c)i(u);if(t){const u=/https?:\/\/[^\s"'<>\)\\]+\.(?:png|jpe?g|gif|webp|svg|avif|ico|bmp)(?:\?[^\s"'<>\)\\]*)?/gi,f=r.match(u);if(f)for(const p of f)i(p)}}catch{}return Array.from(o)}async function Ys(e){if(typeof FileReader<"u")return new Promise((n,s)=>{const l=new FileReader;l.onloadend=()=>{typeof l.result=="string"?n(l.result):s(new Error("Failed to convert blob to data URL"))},l.onerror=()=>s(l.error||new Error("FileReader error")),l.readAsDataURL(e)});const t=await e.arrayBuffer(),o=Buffer.from(t);return`data:${e.type||"image/png"};base64,${o.toString("base64")}`}async function Ml(e){if(typeof e=="string")return e.startsWith("data:")?e:`data:image/png;base64,${e}`;if(e instanceof ArrayBuffer){const t=new Blob([e]);return Ys(t)}return e instanceof Blob?Ys(e):""}async function xg(e,t){var l,r;const o=wg(e,t==null?void 0:t.includeRemote);if(o.length===0)return{};const i={},n=typeof window<"u"&&((r=(l=window.siyuan)==null?void 0:l.config)==null?void 0:r.apiToken)||"",s=n?{Authorization:`Token ${n}`}:{};for(const a of o){let c="",u=!1;const f=a.indexOf("/assets/");f!==-1?(c=a.slice(f+1),u=!0):a.startsWith("assets/")?(c=a,u=!0):a.startsWith("./assets/")?(c=a.slice(2),u=!0):a.startsWith("/assets/")&&(c=a.slice(1),u=!0);try{let p=null;if(t!=null&&t.fetcher){const d=await t.fetcher(a).catch(()=>null);if(d)p=await Ml(d);else if(c&&c!==a){const b=await t.fetcher(`/${c}`).catch(()=>null);b&&(p=await Ml(b))}}else if(typeof fetch<"u"){const d=[];(a.startsWith("http://")||a.startsWith("https://"))&&d.push({url:a,headers:u?s:void 0}),u&&c&&(d.push({url:`/${c}`,headers:s}),d.push({url:`./${c}`,headers:s}),d.push({url:c,headers:s})),u||d.push({url:a});for(const b of d)try{const m=await fetch(b.url,{credentials:"include",headers:b.headers});if(m.ok){const g=await m.blob();if(p=await Ys(g),p)break}}catch{}}if(p){const d=[a];c&&d.push(`/${c}`,`./${c}`,c);for(const b of d){i[b]=p;try{i[decodeURI(b)]=p,i[encodeURI(b)]=p}catch{}}}}catch(p){console.warn(`[single-html-exporter] Failed to inline asset "${a}":`,p)}}return i}function Sg(e,t){const o=(t==null?void 0:t.title)||"即现文稿";let i=e.slides,n={...e.config},s=e.customThemeCss;if(t!=null&&t.inlineAssetBase64Map&&Object.keys(t.inlineAssetBase64Map).length>0){const c=t.inlineAssetBase64Map,u=Object.entries(c).sort((d,b)=>b[0].length-d[0].length),f=d=>{if(!d||typeof d!="string")return d;let b=d;for(const[m,g]of u)b.includes(m)&&(b=b.split(m).join(g));return b},p=d=>{const b=f(d.rawMarkdown||""),m=f(d.content||""),g=Array.isArray(d.children)?d.children.map(y=>p(y)):d.children;return{...d,rawMarkdown:b,content:m,children:g}};n.background&&typeof n.background=="string"&&(n.background=f(n.background)),s&&(s=f(s)),i=(e.slides||[]).map(d=>{const b=f(d.rawMarkdown||""),m=(d.blocks||[]).map(p),g=Array.isArray(d.noteBlocks)?d.noteBlocks.map(p):d.noteBlocks,y=f(d.notes||"");let k=d.frontmatter?{...d.frontmatter}:d.frontmatter;if(k)for(const[x,$]of Object.entries(k))typeof $=="string"&&(k[x]=f($));return{...d,rawMarkdown:b,blocks:m,noteBlocks:g,notes:y,frontmatter:k}})}const l=Cr(n.colorSchema),r=JSON.stringify(i),a=JSON.stringify({...n,hostThemeMode:n.hostThemeMode||l});return`<!DOCTYPE html>
<html lang="zh-CN">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${st(o)}</title>
  <style>
${dg(t==null?void 0:t.customInlineStyles)}
  </style>
  <script>
    // 注入演示数据载荷
    window.__SLIDES_DATA__ = {
      docId: ${JSON.stringify(e.docId)},
      slides: ${r},
      config: ${a}
    };
  <\/script>
</head>
<body>
  <div id="app" data-theme="${l}" data-normalize-headings="${n.normalizeHeadingSizes?"true":"false"}" data-hide-unordered-markers="${n.showUnorderedListMarkers===!1?"true":"false"}" data-hide-ordered-markers="${n.showOrderedListMarkers===!1?"true":"false"}">
    <div class="slide-viewport slides-theme-${n.theme||"apple-basic"}" id="viewport" data-theme="${l}" data-slides-theme="${n.theme||"apple-basic"}">
      <div class="slide-content" id="slide-container"></div>
    </div>
    <div class="controls">
      <button id="btn-prev">◀ 上一页</button>
      <span id="page-num">1 / 1</span>
      <button id="btn-next">下一页 ▶</button>
      <button id="btn-fullscreen">全屏</button>
    </div>
    <!-- 全屏媒体灯箱 (Lightbox) 模态窗口 -->
    <div id="slides-lightbox" class="slides-lightbox">
      <button class="slides-lightbox-close" id="lightbox-close" aria-label="关闭 (Esc)">✕</button>
      <div class="slides-lightbox-content" id="lightbox-content"></div>
    </div>
  </div>

  <script>
${kg()}
  <\/script>
</body>
</html>`}async function fc(e,t){let o=t==null?void 0:t.inlineAssetBase64Map;return(!o||Object.keys(o).length===0)&&(o=await xg(e,t)),Sg(e,{...t,inlineAssetBase64Map:o})}function hc(e,t){if(typeof document>"u")return!1;const o=new Blob([t],{type:"text/html;charset=utf-8"}),i=URL.createObjectURL(o),n=document.createElement("a");return n.href=i,n.download=e.endsWith(".html")?e:`${e}.html`,document.body.appendChild(n),n.click(),document.body.removeChild(n),URL.revokeObjectURL(i),!0}function _g(e){switch(e){case"4:3":return"size: 12in 9in;";case"A4-landscape":return"size: 297mm 210mm;";case"A4-portrait":return"size: 210mm 297mm;";case"16:9":default:return"size: 16in 9in;"}}function Cg(e){const t=_g(e==null?void 0:e.pageRatio);return`
    ${Wi(e==null?void 0:e.customInlineStyles)}

    @page {
      ${t}
      margin: 0;
    }
    * {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
      -webkit-print-color-adjust: exact !important;
      print-color-adjust: exact !important;
    }
    body {
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "PingFang SC", "Microsoft YaHei", sans-serif;
      background: #f8fafc;
      color: #1e293b;
    }
    .pdf-slide-page {
      width: 100vw;
      height: 100vh;
      page-break-after: always;
      break-after: page;
      padding: var(--slides-padding-y, 36px) var(--slides-padding-x, 56px);
      display: flex;
      flex-direction: column;
      position: relative;
      background: #ffffff;
      overflow: hidden;
      container-type: size;
    }
    .pdf-slide-page.spacing-compact {
      --slides-padding-y: 16px;
      --slides-padding-x: 28px;
      --slides-block-gap: 8px;
      --slides-list-gap: 4px;
      --slides-cols-gap: 20px;
      --slides-title-margin-bottom: 8px;
      --slides-header-gap: 10px;
      --slides-line-height: 1.45;
    }
    .pdf-slide-page.spacing-normal {
      --slides-padding-y: 32px;
      --slides-padding-x: 48px;
      --slides-block-gap: 14px;
      --slides-list-gap: 6px;
      --slides-cols-gap: 32px;
      --slides-title-margin-bottom: 12px;
      --slides-header-gap: 16px;
      --slides-line-height: 1.6;
    }
    .pdf-slide-page.spacing-loose {
      --slides-padding-y: 52px;
      --slides-padding-x: 72px;
      --slides-block-gap: 22px;
      --slides-list-gap: 10px;
      --slides-cols-gap: 44px;
      --slides-title-margin-bottom: 18px;
      --slides-header-gap: 24px;
      --slides-line-height: 1.75;
    }
    .pdf-slide-page.theme-dark {
      background: #0f1117;
      color: #f1f5f9;
    }

    /* 1. 默认科技主题 Default (Modern Tech) */
    .pdf-slide-page.slides-theme-tech {
      font-family: system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "PingFang SC", "Microsoft YaHei", sans-serif;
    }
    .pdf-slide-page.slides-theme-tech.theme-light {
      background: #f8fafc;
      color: #0f172a;
    }
    .pdf-slide-page.slides-theme-tech.theme-dark {
      background: #090d16;
      color: #f1f5f9;
    }
    .slides-theme-tech .pdf-block h1 { color: #059669; }
    .theme-dark.slides-theme-tech .pdf-block h1 { color: #10b981; }
    .slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h1,
    .slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h2,
    .slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h3,
    .slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h1,
    .slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h2,
    .slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h3,
    .slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h1,
    .slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h2,
    .slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h3,
    .slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h1,
    .slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h2,
    .slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h3,
    .slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h1,
    .slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h2,
    .slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h3,
    .slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h1,
    .slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h2,
    .slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h3,
    .slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .pdf-block:first-child h1,
    .slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .pdf-block:first-child h2,
    .slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .pdf-block:first-child h3,
    .slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .pdf-block:first-child h1,
    .slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .pdf-block:first-child h2,
    .slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .pdf-block:first-child h3,
    .slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .pdf-block:first-child h1,
    .slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .pdf-block:first-child h2,
    .slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .pdf-block:first-child h3,
    .slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .pdf-block:first-child h1,
    .slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .pdf-block:first-child h2,
    .slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .pdf-block:first-child h3 {
      color: #059669;
      border-left: 4px solid #059669;
      padding: 4px 14px;
      padding-left: 14px;
      background: linear-gradient(90deg, rgba(5, 150, 105, 0.13), transparent 76%);
      border-radius: 0 6px 6px 0;
      letter-spacing: -0.015em;
    }
    .theme-dark.slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h1,
    .theme-dark.slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h2,
    .theme-dark.slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h3,
    .theme-dark.slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h1,
    .theme-dark.slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h2,
    .theme-dark.slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h3,
    .theme-dark.slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h1,
    .theme-dark.slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h2,
    .theme-dark.slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h3,
    .theme-dark.slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h1,
    .theme-dark.slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h2,
    .theme-dark.slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h3,
    .theme-dark.slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h1,
    .theme-dark.slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h2,
    .theme-dark.slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h3,
    .theme-dark.slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h1,
    .theme-dark.slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h2,
    .theme-dark.slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h3,
    .theme-dark.slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .pdf-block:first-child h1,
    .theme-dark.slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .pdf-block:first-child h2,
    .theme-dark.slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .pdf-block:first-child h3,
    .theme-dark.slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .pdf-block:first-child h1,
    .theme-dark.slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .pdf-block:first-child h2,
    .theme-dark.slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .pdf-block:first-child h3,
    .theme-dark.slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .pdf-block:first-child h1,
    .theme-dark.slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .pdf-block:first-child h2,
    .theme-dark.slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .pdf-block:first-child h3,
    .theme-dark.slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .pdf-block:first-child h1,
    .theme-dark.slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .pdf-block:first-child h2,
    .theme-dark.slides-theme-tech:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .pdf-block:first-child h3 {
      color: #10b981;
      border-left-color: #10b981;
      background: linear-gradient(90deg, rgba(16, 185, 129, 0.14), transparent 76%);
    }

    /* 2. 优雅衬线主题 Seriph (Editorial Academic) */
    .pdf-slide-page.slides-theme-seriph {
      font-family: "PT Serif", "Charter", "Georgia", "Cambria", "Times New Roman", "Source Han Serif SC", "Noto Serif SC", "Songti SC", "SimSun", serif;
      letter-spacing: 0.015em;
    }
    .pdf-slide-page.slides-theme-seriph.theme-light {
      background: #fcfbf7;
      color: #231f1d;
    }
    .pdf-slide-page.slides-theme-seriph.theme-dark {
      background: #171513;
      color: #f5f2eb;
    }
    .slides-theme-seriph .pdf-block h1 { color: #b45309; }
    .theme-dark.slides-theme-seriph .pdf-block h1 { color: #f59e0b; }
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h1,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h2,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h3,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h1,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h2,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h3,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h1,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h2,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h3,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h1,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h2,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h3,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h1,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h2,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h3,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h1,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h2,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h3,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .pdf-block:first-child h1,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .pdf-block:first-child h2,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .pdf-block:first-child h3,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .pdf-block:first-child h1,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .pdf-block:first-child h2,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .pdf-block:first-child h3,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .pdf-block:first-child h1,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .pdf-block:first-child h2,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .pdf-block:first-child h3,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .pdf-block:first-child h1,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .pdf-block:first-child h2,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .pdf-block:first-child h3 {
      display: block;
      position: relative;
      color: #b45309;
      border-bottom: 1.5px solid rgba(180, 83, 9, 0.45);
      padding-bottom: 10px;
      margin-bottom: 14px;
    }
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h1::after,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h2::after,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h3::after,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h1::after,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h2::after,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h3::after,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h1::after,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h2::after,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h3::after,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h1::after,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h2::after,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h3::after,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h1::after,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h2::after,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h3::after,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h1::after,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h2::after,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h3::after,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .pdf-block:first-child h1::after,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .pdf-block:first-child h2::after,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .pdf-block:first-child h3::after,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .pdf-block:first-child h1::after,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .pdf-block:first-child h2::after,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .pdf-block:first-child h3::after,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .pdf-block:first-child h1::after,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .pdf-block:first-child h2::after,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .pdf-block:first-child h3::after,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .pdf-block:first-child h1::after,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .pdf-block:first-child h2::after,
    .slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .pdf-block:first-child h3::after {
      content: "";
      position: absolute;
      left: 0;
      right: 0;
      bottom: 3px;
      height: 1.5px;
      pointer-events: none;
      background: linear-gradient(90deg, #b45309 0%, rgba(180, 83, 9, 0.35) 50%, transparent 92%);
    }
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h1,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h2,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h3,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h1,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h2,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h3,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h1,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h2,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h3,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h1,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h2,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h3,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h1,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h2,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h3,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h1,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h2,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h3,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .pdf-block:first-child h1,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .pdf-block:first-child h2,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .pdf-block:first-child h3,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .pdf-block:first-child h1,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .pdf-block:first-child h2,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .pdf-block:first-child h3,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .pdf-block:first-child h1,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .pdf-block:first-child h2,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .pdf-block:first-child h3,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .pdf-block:first-child h1,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .pdf-block:first-child h2,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .pdf-block:first-child h3 {
      color: #f59e0b;
      border-bottom-color: rgba(245, 158, 11, 0.45);
    }
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h1::after,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h2::after,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h3::after,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h1::after,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h2::after,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h3::after,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h1::after,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h2::after,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h3::after,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h1::after,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h2::after,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h3::after,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h1::after,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h2::after,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h3::after,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h1::after,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h2::after,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h3::after,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .pdf-block:first-child h1::after,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .pdf-block:first-child h2::after,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .pdf-block:first-child h3::after,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .pdf-block:first-child h1::after,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .pdf-block:first-child h2::after,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .pdf-block:first-child h3::after,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .pdf-block:first-child h1::after,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .pdf-block:first-child h2::after,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .pdf-block:first-child h3::after,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .pdf-block:first-child h1::after,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .pdf-block:first-child h2::after,
    .theme-dark.slides-theme-seriph:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .pdf-block:first-child h3::after {
      background: linear-gradient(90deg, #f59e0b 0%, rgba(245, 158, 11, 0.35) 50%, transparent 92%);
    }

    /* 3. 极简发布会主题 Apple Basic (Swiss Minimal) */
    .pdf-slide-page.slides-theme-apple-basic {
      font-family: -apple-system, "SF Pro Display", "SF Pro Text", BlinkMacSystemFont, "PingFang SC", "Helvetica Neue", sans-serif;
      letter-spacing: -0.025em;
    }
    .pdf-slide-page.slides-theme-apple-basic.theme-light {
      background: #ffffff;
      color: #000000;
    }
    .pdf-slide-page.slides-theme-apple-basic.theme-dark {
      background: #000000;
      color: #ffffff;
    }
    .slides-theme-apple-basic .pdf-block h1 {
      color: #000000;
      font-weight: 800;
      letter-spacing: -0.035em;
    }
    .theme-dark.slides-theme-apple-basic .pdf-block h1 {
      color: #ffffff;
      font-weight: 800;
      letter-spacing: -0.035em;
    }
    .slides-theme-apple-basic:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h1,
    .slides-theme-apple-basic:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h2,
    .slides-theme-apple-basic:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h3,
    .slides-theme-apple-basic:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h1,
    .slides-theme-apple-basic:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h2,
    .slides-theme-apple-basic:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h3,
    .slides-theme-apple-basic:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h1,
    .slides-theme-apple-basic:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h2,
    .slides-theme-apple-basic:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h3,
    .slides-theme-apple-basic:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h1,
    .slides-theme-apple-basic:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h2,
    .slides-theme-apple-basic:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h3,
    .slides-theme-apple-basic:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h1,
    .slides-theme-apple-basic:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h2,
    .slides-theme-apple-basic:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h3,
    .slides-theme-apple-basic:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h1,
    .slides-theme-apple-basic:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h2,
    .slides-theme-apple-basic:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h3,
    .slides-theme-apple-basic:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .pdf-block:first-child h1,
    .slides-theme-apple-basic:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .pdf-block:first-child h2,
    .slides-theme-apple-basic:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .pdf-block:first-child h3,
    .slides-theme-apple-basic:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .pdf-block:first-child h1,
    .slides-theme-apple-basic:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .pdf-block:first-child h2,
    .slides-theme-apple-basic:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .pdf-block:first-child h3,
    .slides-theme-apple-basic:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .pdf-block:first-child h1,
    .slides-theme-apple-basic:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .pdf-block:first-child h2,
    .slides-theme-apple-basic:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .pdf-block:first-child h3,
    .slides-theme-apple-basic:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .pdf-block:first-child h1,
    .slides-theme-apple-basic:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .pdf-block:first-child h2,
    .slides-theme-apple-basic:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .pdf-block:first-child h3 {
      border: none !important;
      background: none !important;
      padding: 0 !important;
      margin-bottom: 16px !important;
      letter-spacing: -0.04em !important;
      font-weight: 800 !important;
    }
    /* 页面存在背景图时，内容页顶部标题回退高对比文字与局部衬底，保留用户块级前景色 */
    .pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h1,
    .pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h2,
    .pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h3,
    .pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h1,
    .pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h2,
    .pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .cols-header-top h3,
    .pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h1,
    .pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h2,
    .pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-header-top h3,
    .pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h1,
    .pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h2,
    .pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .three-cols-header-top h3,
    .pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h1,
    .pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h2,
    .pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h3,
    .pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h1,
    .pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h2,
    .pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-page-first-heading-block h3,
    .pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .pdf-block:first-child h1,
    .pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .pdf-block:first-child h2,
    .pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .pdf-block:first-child h3,
    .pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .pdf-block:first-child h1,
    .pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .pdf-block:first-child h2,
    .pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .two-cols-left > .pdf-block:first-child h3,
    .pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .pdf-block:first-child h1,
    .pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .pdf-block:first-child h2,
    .pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .pdf-block:first-child h3,
    .pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .pdf-block:first-child h1,
    .pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .pdf-block:first-child h2,
    .pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .slides-mask-body-container > .pdf-block:first-child h3 {
      color: #0f172a;
      text-shadow: 0 1px 3px rgba(255, 255, 255, 0.85);
    }
    .pdf-slide-page.theme-dark[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h1,
    .pdf-slide-page.theme-dark[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h2,
    .pdf-slide-page.theme-dark[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h3,
    .pdf-slide-page.theme-dark[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h1,
    .pdf-slide-page.theme-dark[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h2,
    .pdf-slide-page.theme-dark[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h3,
    .pdf-slide-page.theme-dark[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .pdf-block:first-child h1,
    .pdf-slide-page.theme-dark[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .pdf-block:first-child h2,
    .pdf-slide-page.theme-dark[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-col--left > .pdf-block:first-child h3,
    .pdf-slide-page.theme-dark[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .pdf-block:first-child h1,
    .pdf-slide-page.theme-dark[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .pdf-block:first-child h2,
    .pdf-slide-page.theme-dark[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-content-col > .pdf-block:first-child h3 {
      color: #f8fafc;
      text-shadow: 0 1px 3px rgba(0, 0, 0, 0.75);
    }
    .slides-theme-tech.pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h1,
    .slides-theme-tech.pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h2,
    .slides-theme-tech.pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h3,
    .slides-theme-tech.pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h1,
    .slides-theme-tech.pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h2,
    .slides-theme-tech.pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h3 {
      background: linear-gradient(90deg, rgba(255, 255, 255, 0.55), transparent 82%);
    }
    .slides-theme-tech.theme-dark.pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h1,
    .slides-theme-tech.theme-dark.pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h2,
    .slides-theme-tech.theme-dark.pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .layout-header-section h3,
    .slides-theme-tech.theme-dark.pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h1,
    .slides-theme-tech.theme-dark.pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h2,
    .slides-theme-tech.theme-dark.pdf-slide-page[style*="background-image"]:not(.layout-cover):not(.layout-center):not(.layout-fact) .pdf-slide-body > .pdf-block:first-child h3 {
      background: linear-gradient(90deg, rgba(15, 23, 42, 0.42), transparent 82%);
    }
    .pdf-slide-page .pdf-block[style^="color:"] h1,
    .pdf-slide-page .pdf-block[style*=" color:"] h1,
    .pdf-slide-page .pdf-block[style*=";color:"] h1,
    .pdf-slide-page .pdf-block[style^="color:"] h2,
    .pdf-slide-page .pdf-block[style*=" color:"] h2,
    .pdf-slide-page .pdf-block[style*=";color:"] h2,
    .pdf-slide-page .pdf-block[style^="color:"] h3,
    .pdf-slide-page .pdf-block[style*=" color:"] h3,
    .pdf-slide-page .pdf-block[style*=";color:"] h3 {
      color: inherit !important;
    }
    .slides-theme-apple-basic .pdf-code,
    .slides-theme-apple-basic pre {
      border-radius: 14px !important;
      border-left: none !important;
    }
    .pdf-slide-header {
      font-size: 13px;
      color: #64748b;
      margin-bottom: 24px;
      display: flex;
      justify-content: space-between;
      border-bottom: 1px solid #e2e8f0;
      padding-bottom: 8px;
    }
    .theme-dark .pdf-slide-header {
      border-bottom-color: #2e3346;
      color: #94a3b8;
    }
    .pdf-slide-body {
      flex: 1;
      display: flex;
      flex-direction: column;
      gap: 16px;
      font-size: 20px;
      line-height: 1.6;
      overflow: hidden;
    }
    .pdf-block h1 { font-size: 2.5rem; font-weight: 800; color: #2563eb; margin-bottom: 12px; }
    .pdf-block h2 { font-size: 1.9rem; font-weight: 700; color: #1d4ed8; margin-bottom: 10px; }
    .pdf-block h3 { font-size: 1.4rem; font-weight: 600; margin-bottom: 8px; }
    .pdf-block h4 { font-size: 1.2rem; font-weight: 600; margin-bottom: 6px; }
    .pdf-block p { font-size: 1.15rem; color: inherit; }
    .pdf-code,
    pre {
      background: #f1f5f9;
      padding: 14px 18px;
      border-radius: 6px;
      font-family: "JetBrains Mono", Consolas, monospace;
      font-size: 0.95rem;
      border-left: 4px solid #3b82f6;
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      max-width: 100% !important;
      box-sizing: border-box !important;
    }
    .pdf-code code,
    pre code {
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      display: block !important;
      width: 100% !important;
      box-sizing: border-box !important;
    }
    .code-line {
      display: flex !important;
      align-items: flex-start !important;
      width: 100% !important;
      box-sizing: border-box !important;
      line-height: 1.6;
    }
    .code-line .line-no {
      display: inline-block !important;
      flex-shrink: 0 !important;
      min-width: 2.2em !important;
      text-align: right !important;
      margin-right: 12px !important;
      user-select: none !important;
      opacity: 0.45 !important;
    }
    .code-line .line-content {
      flex: 1 1 0% !important;
      min-width: 0 !important;
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
    }
    .theme-dark .pdf-code {
      background: #1e1e24;
      border-left-color: #60a5fa;
    }
    .pdf-quote {
      border-left: 4px solid #10b981;
      background: rgba(16, 185, 129, 0.08);
      padding: 10px 16px;
      border-radius: 0 4px 4px 0;
      font-style: italic;
    }
    .pdf-image,
    .slide-media-img {
      max-width: 100% !important;
      max-height: 48vh !important;
      width: auto !important;
      height: auto !important;
      object-fit: contain !important;
      border-radius: 6px;
      margin: auto;
      display: block;
    }
    .slide-media-block,
    .slide-media-container,
    .slide-video-container {
      display: flex;
      flex-direction: column;
      justify-content: center;
      align-items: center;
      width: 100%;
      max-height: 48vh;
      margin: 8px 0;
      overflow: hidden;
    }
    .slide-list-media {
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: flex-start;
      margin-top: 8px;
      margin-bottom: 6px;
      max-width: 100%;
      overflow: hidden;
    }
    .slide-list-media img,
    .slide-list-media video,
    .slide-list-media .list-item-gif {
      max-width: 100% !important;
      max-height: min(280px, 36vh) !important;
      width: auto !important;
      height: auto !important;
      min-width: 0 !important;
      min-height: 0 !important;
      object-fit: contain !important;
      border-radius: 6px;
      display: block;
      margin: 0 auto !important;
    }
    .slide-video-player {
      max-width: 100% !important;
      max-height: 48vh !important;
      width: auto !important;
      height: auto !important;
      object-fit: contain !important;
      border-radius: 6px;
      background: #000;
      border: 1px solid #cbd5e1;
    }
    .pdf-two-cols-wrapper,
    .layout-two-cols-grid,
    .layout-cols-wrapper,
    .layout-cols-grid {
      display: grid;
      grid-template-columns: minmax(0, 1fr) minmax(0, 1fr);
      grid-template-rows: minmax(0, 1fr) !important;
      gap: var(--slides-cols-gap, 32px);
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      overflow: hidden !important;
    }
    .layout-cols-header-container,
    .layout-two-cols-header-container,
    .layout-three-cols-header-container,
    .layout-clover-container {
      display: flex;
      flex-direction: column;
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      overflow: hidden !important;
    }
    .layout-header-section {
      width: 100%;
      margin-bottom: var(--slides-header-gap, 16px) !important;
      flex-shrink: 0;
    }
    .layout-header-section h1,
    .layout-header-section h2,
    .layout-header-section h3 {
      margin-bottom: var(--slides-title-margin-bottom, 10px) !important;
    }
    .pdf-three-cols-wrapper,
    .layout-three-cols-grid {
      display: grid;
      grid-template-columns: minmax(0, 1fr) minmax(0, 1fr) minmax(0, 1fr);
      grid-template-rows: minmax(0, 1fr) !important;
      gap: calc(var(--slides-cols-gap, 32px) * 0.75);
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      box-sizing: border-box;
      overflow: hidden !important;
    }
    .pdf-clover-wrapper,
    .layout-clover-grid {
      display: grid;
      grid-template-columns: repeat(2, minmax(0, 1fr)) !important;
      grid-template-rows: repeat(2, minmax(0, 1fr)) !important;
      gap: calc(var(--slides-cols-gap, 32px) * 0.625);
      width: 100%;
      height: 100%;
      min-height: 0 !important;
      max-height: 100% !important;
      flex: 1 1 0%;
      align-items: stretch;
      box-sizing: border-box;
      overflow: hidden !important;
    }
    .layout-clover-grid .pdf-col {
      background: transparent !important;
      border: none !important;
      box-shadow: none !important;
    }
    .pdf-col {
      display: flex;
      flex-direction: column;
      gap: var(--slides-block-gap, 14px);
      min-width: 0;
      width: 100%;
      max-width: 100%;
      height: 100%;
      max-height: 100%;
      min-height: 0;
      justify-content: flex-start;
      overflow: hidden;
      box-sizing: border-box;
      overflow-wrap: break-word;
      word-break: break-word;
      white-space: normal;
    }
    /* 表头多栏内超级块子块首个列表项去圆点后居中显示标题/首行文本 (仅在存在超级块分栏时生效) */
    .has-superblock-cols .pdf-col > *:first-child .slide-list-item-title,
    .has-superblock-cols .pdf-col > *:first-child :is(h1, h2, h3, h4, h5, h6),
    .has-superblock-cols .pdf-col > *:first-child p.slide-list-item-title,
    .has-superblock-cols .pdf-col > *:first-child p:first-of-type,
    .has-superblock-cols .pdf-col > *:first-child p:first-child,
    .has-superblock-cols .pdf-col > *:first-child :is(ul, ol) > li:first-child,
    .has-superblock-cols .pdf-col > *:first-child .slide-list > .slide-list-item:first-child,
    .has-superblock-cols .pdf-col > *:first-child .pdf-list > li:first-child,
    .has-superblock-cols .slides-col-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    .has-superblock-cols .slides-col-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      list-style: none !important;
      list-style-type: none !important;
      text-align: center !important;
      margin-left: 0 !important;
      padding-left: 0 !important;
      width: 100% !important;
    }

    /* 彻底清除首个列表项的原生圆点 Marker (仅在存在超级块分栏时生效) */
    .has-superblock-cols .pdf-col > *:first-child :is(ul, ol) > li:first-child::marker {
      content: "" !important;
      display: none !important;
    }

    /* 确保首个列表项内部内联与块级元素居中 (仅在存在超级块分栏时生效) */
    .has-superblock-cols .pdf-col > *:first-child :is(ul, ol) > li:first-child * {
      text-align: center !important;
    }

    /* 栏内说明段落与列表项：左对齐，自然阅读排版 */
    .has-superblock-cols .pdf-col .slide-list-item-desc,
    .has-superblock-cols .pdf-col li:not(:first-child) {
      text-align: left !important;
    }

    /* 全局特定标题大小规范化 (除封面外页首首个标题按 H2 1.7rem，表头多栏内首个标题按 H3 1.3rem) */
    [data-normalize-headings="true"] .slides-page-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .slides-page-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .pdf-slide:not(.layout-cover) > :is(.pdf-block, .slide-block):first-child :is(h1, h2, h3, h4, h5, h6),
    [data-normalize-headings="true"] .pdf-slide:not(.layout-cover) > .layout-header-section :is(.pdf-block, .slide-block):first-child :is(h1, h2, h3, h4, h5, h6),
    [data-normalize-headings="true"] .pdf-slide:not(.layout-cover) > :not(.layout-cols-wrapper):not(.pdf-two-cols-wrapper):not(.layout-image-cols-grid):first-child :is(h1, h2, h3, h4, h5, h6) {
      font-size: 1.7rem !important;
      font-weight: 600 !important;
      line-height: 1.25 !important;
      margin-bottom: var(--slides-title-margin-bottom, 10px) !important;
    }

    [data-normalize-headings="true"] .has-superblock-cols .slides-col-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .has-superblock-cols .slides-col-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .has-superblock-cols .pdf-col > *:first-child :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      font-size: 1.3rem !important;
      font-weight: 600 !important;
      line-height: 1.3 !important;
      margin-bottom: 8px !important;
      text-align: center !important;
    }

    /* 图左与图右版式标题完全保留用户原始字号与默认排版，不进行任何固定大小规范化 */
    [data-normalize-headings="true"] :is(.layout-image-left, .layout-image-right, .image-left-content, .image-right-content) :is(h1, h2, h3, h4, h5, h6) {
      text-align: left !important;
    }
    .pdf-col > .pdf-block,
    .pdf-col > .slide-block {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      max-height: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      width: 100% !important;
      height: 100% !important;
      box-sizing: border-box !important;
      overflow: hidden !important;
    }
    .pdf-col .slide-list-item-title,
    .pdf-col h1, .pdf-col h2, .pdf-col h3, .pdf-col h4, .pdf-col h5, .pdf-col h6,
    .pdf-col .slide-list-item-desc {
      flex: 0 0 auto !important;
      margin-top: 0 !important;
      margin-bottom: 6px !important;
    }
    .pdf-col .slide-list-media,
    .pdf-col .slide-video-container,
    .pdf-col .slide-media-container {
      flex: 1 1 0% !important;
      min-height: 0 !important;
      min-width: 0 !important;
      width: 100% !important;
      height: 100% !important;
      max-height: 100% !important;
      max-width: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
      justify-content: flex-start !important;
      overflow: hidden !important;
      margin: 0 !important;
      padding: 0 !important;
      box-sizing: border-box !important;
    }
    .pdf-col li:has(.slide-list-media),
    .pdf-col li:has(.slide-media-container),
    .pdf-col li:has(.slide-video-container),
    .pdf-col li:has(img),
    .pdf-col li:has(video),
    .pdf-col .pdf-list-item:has(.slide-list-media),
    .pdf-col .pdf-list-item:has(.slide-media-container),
    .pdf-col .pdf-list-item:has(.slide-video-container),
    .pdf-col .pdf-list-item:has(img),
    .pdf-col .pdf-list-item:has(video) {
      display: list-item !important;
      list-style-type: disc !important;
      flex: 0 0 auto !important;
      height: auto !important;
      max-height: none !important;
      overflow: visible !important;
      margin-bottom: 6px !important;
    }
    .pdf-col video,
    .layout-three-cols-grid video,
    .layout-two-cols-grid video,
    .pdf-col img,
    .layout-three-cols-grid img,
    .layout-two-cols-grid img,
    .pdf-col .slide-video-player {
      max-width: 100% !important;
      max-height: 100% !important;
      width: auto !important;
      height: auto !important;
      min-width: 0 !important;
      min-height: 0 !important;
      object-fit: contain !important;
      display: block !important;
      margin: 0 auto !important;
    }
    .pdf-col * {
      overflow-wrap: break-word;
      word-break: break-word;
      box-sizing: border-box;
    }
    .pdf-col pre {
      white-space: pre-wrap !important;
      word-break: break-all !important;
      overflow-wrap: anywhere !important;
      max-width: 100% !important;
      box-sizing: border-box !important;
    }
    .pdf-list-item {
      padding-left: 20px;
    }
    .pdf-list {
      padding-left: 24px;
      margin: calc(var(--slides-block-gap, 14px) * 0.6) 0;
      display: flex;
      flex-direction: column;
      gap: var(--slides-list-gap, 6px);
    }
    .pdf-list li {
      font-size: 1.15rem;
      line-height: var(--slides-line-height, 1.6);
    }
    .pdf-task-item {
      list-style: none;
      margin-left: -20px;
      display: flex;
      align-items: center;
      gap: 8px;
    }
    .pdf-task-item input[type="checkbox"] {
      width: 1.15em;
      height: 1.15em;
      cursor: pointer;
    }
    /* 两栏与三栏及多栏（超级块分栏）布局：紧凑自然行距，子列表保留圆点与层级缩进 */
    .layout-two-cols ul,
    .layout-cols-header ul,
    .layout-two-cols-header ul,
    .layout-three-cols ul,
    .layout-three-cols-header ul,
    .two-cols-left ul,
    .two-cols-right ul,
    .three-cols-col ul,
    .col ul,
    .pdf-two-cols-wrapper ul,
    .pdf-three-cols-wrapper ul,
    .pdf-col ul,
    .layout-two-cols-grid .pdf-list,
    .layout-three-cols-grid .pdf-list,
    .layout-cols-grid .pdf-list,
    .layout-two-cols-grid .pdf-list--unordered,
    .layout-three-cols-grid .pdf-list--unordered,
    .layout-cols-grid .pdf-list--unordered {
      list-style: disc !important;
      list-style-type: disc !important;
      padding-left: 1.25em !important;
      margin-left: 0 !important;
      margin-top: 0 !important;
      margin-bottom: 8px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: block !important;
    }
    .layout-two-cols ol,
    .layout-cols-header ol,
    .layout-two-cols-header ol,
    .layout-three-cols ol,
    .layout-three-cols-header ol,
    .two-cols-left ol,
    .two-cols-right ol,
    .three-cols-col ol,
    .col ol,
    .pdf-two-cols-wrapper ol,
    .pdf-three-cols-wrapper ol,
    .pdf-col ol,
    .layout-two-cols-grid .pdf-list--ordered,
    .layout-three-cols-grid .pdf-list--ordered,
    .layout-cols-grid .pdf-list--ordered {
      list-style: decimal !important;
      list-style-type: decimal !important;
      padding-left: 1.25em !important;
      margin-left: 0 !important;
      margin-top: 0 !important;
      margin-bottom: 8px !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: block !important;
    }
    .layout-two-cols li,
    .layout-cols-header li,
    .layout-two-cols-header li,
    .layout-three-cols li,
    .layout-three-cols-header li,
    .two-cols-left li,
    .two-cols-right li,
    .three-cols-col li,
    .col li,
    .pdf-col li,
    .pdf-col .pdf-list-item {
      padding-left: 0.2em !important;
      margin-left: 0 !important;
      margin-bottom: var(--slides-list-gap, 6px) !important;
      flex: 0 0 auto !important;
      height: auto !important;
      display: list-item !important;
      line-height: var(--slides-line-height, 1.6) !important;
    }
    .layout-two-cols ul ul,
    .layout-three-cols ul ul,
    .three-cols-col ul ul,
    .pdf-col ul ul {
      list-style: circle !important;
      list-style-type: circle !important;
      padding-left: 1.25em !important;
      margin-top: 4px !important;
      margin-bottom: 4px !important;
    }
    /* 列表项内嵌标题与说明排版 */
    .slide-list-item-title,
    .pdf-list li > h1,
    .pdf-list li > h2,
    .pdf-list li > h3,
    .pdf-list li > h4,
    .pdf-list li > h5,
    .pdf-list li > h6,
    li > h1.slide-list-item-title,
    li > h2.slide-list-item-title,
    li > h3.slide-list-item-title,
    li > h4.slide-list-item-title {
      margin-top: 2px !important;
      margin-bottom: 6px !important;
      line-height: 1.35 !important;
      font-weight: 700 !important;
    }
    .pdf-list li > h1, li > h1.slide-list-item-title { font-size: 1.6rem !important; }
    .pdf-list li > h2, li > h2.slide-list-item-title { font-size: 1.4rem !important; }
    .pdf-list li > h3, li > h3.slide-list-item-title { font-size: 1.22rem !important; }
    .pdf-list li > h4, li > h4.slide-list-item-title { font-size: 1.1rem !important; }

    /* 全局特定标题大小规范化后置强力锁定 (防止被列表项内部字号覆盖) */
    [data-normalize-headings="true"] .slides-page-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .slides-page-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      font-size: 1.7rem !important;
      font-weight: 600 !important;
      line-height: 1.25 !important;
      margin-bottom: 10px !important;
    }
    [data-normalize-headings="true"] .has-superblock-cols .slides-col-first-heading-block :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .has-superblock-cols .slides-col-first-heading-block:is(h1, h2, h3, h4, h5, h6, .slide-list-item-title),
    [data-normalize-headings="true"] .has-superblock-cols .pdf-col > *:first-child :is(h1, h2, h3, h4, h5, h6, .slide-list-item-title) {
      font-size: 1.3rem !important;
      font-weight: 600 !important;
      line-height: 1.3 !important;
      margin-bottom: 8px !important;
      text-align: center !important;
    }
    /* 基础列表项前缀样式 */
    .slide-block ul,
    .slide-list--unordered,
    .pdf-list--unordered {
      list-style: disc !important;
      list-style-type: disc !important;
    }
    .slide-block ol,
    .slide-list--ordered,
    .pdf-list--ordered {
      list-style: decimal !important;
      list-style-type: decimal !important;
    }
    .slide-block li,
    .slide-list-item,
    .pdf-list-item,
    .pdf-list li {
      display: list-item !important;
    }

    /* 隐藏无序列表前缀标记 */
    [data-hide-unordered-markers="true"] :is(ul, .slide-list, .slide-list--unordered, .pdf-list, .pdf-list--unordered),
    [data-hide-unordered-markers="true"] :is(ul, .slide-list, .slide-list--unordered, .pdf-list, .pdf-list--unordered) > li,
    [data-hide-unordered-markers="true"] li.slide-list-item,
    [data-hide-unordered-markers="true"] ul > li {
      list-style: none !important;
      list-style-type: none !important;
      padding-left: 0 !important;
      margin-left: 0 !important;
    }
    [data-hide-unordered-markers="true"] :is(ul, .slide-list, .slide-list--unordered, .pdf-list, .pdf-list--unordered) > li::marker,
    [data-hide-unordered-markers="true"] li.slide-list-item::marker {
      content: "" !important;
      display: none !important;
    }

    /* 隐藏有序列表前缀标记 */
    [data-hide-ordered-markers="true"] :is(ol, .slide-list, .slide-list--ordered, .pdf-list, .pdf-list--ordered),
    [data-hide-ordered-markers="true"] :is(ol, .slide-list, .slide-list--ordered, .pdf-list, .pdf-list--ordered) > li,
    [data-hide-ordered-markers="true"] li.slide-list-item,
    [data-hide-ordered-markers="true"] ol > li {
      list-style: none !important;
      list-style-type: none !important;
      padding-left: 0 !important;
      margin-left: 0 !important;
    }
    [data-hide-ordered-markers="true"] :is(ol, .slide-list, .slide-list--ordered, .pdf-list, .pdf-list--ordered) > li::marker,
    [data-hide-ordered-markers="true"] li.slide-list-item::marker {
      content: "" !important;
      display: none !important;
    }

    .slide-list-item-desc,
    .pdf-list li > p {
      margin-top: 4px !important;
      margin-bottom: 6px !important;
      font-size: 1.05rem;
      line-height: 1.55;
      opacity: 0.92;
    }
    kbd {
      display: inline-block;
      padding: 2px 7px;
      font-family: ui-monospace, SFMono-Regular, "SF Mono", Menlo, Consolas, "Liberation Mono", monospace;
      font-size: 0.85em;
      font-weight: 600;
      line-height: 1.25;
      color: inherit;
      background: rgba(125, 125, 125, 0.12);
      border: 1px solid rgba(125, 125, 125, 0.35);
      border-bottom-width: 2px;
      border-radius: 5px;
      box-shadow: 0 1px 2px rgba(0, 0, 0, 0.12);
      margin: 0 2px;
      vertical-align: middle;
      white-space: nowrap;
    }
    .theme-dark kbd {
      background: rgba(255, 255, 255, 0.1);
      border-color: rgba(255, 255, 255, 0.25);
      border-bottom-color: rgba(255, 255, 255, 0.4);
      color: #f1f5f9;
      box-shadow: 0 1px 2px rgba(0, 0, 0, 0.4);
    }
    a {
      color: inherit;
      text-decoration: none;
      border-bottom: 1px dashed currentColor;
    }
    .slides-ref-tag, a.slides-ref-tag {
      display: inline-flex;
      align-items: center;
      background: rgba(16, 185, 129, 0.1);
      color: #059669;
      border: 1px solid rgba(16, 185, 129, 0.25);
      border-radius: 4px;
      padding: 2px 8px;
      font-size: 0.88em;
      text-decoration: none;
      margin: 2px 4px 2px 0;
    }
    .theme-dark .slides-ref-tag, .theme-dark a.slides-ref-tag {
      background: rgba(52, 211, 153, 0.15);
      color: #34d399;
      border-color: rgba(52, 211, 153, 0.3);
    }
    .slides-block-ref, .pdf-block--ref {
      background: rgba(16, 185, 129, 0.06);
      border-left: 3px solid #059669;
      border-radius: 0 6px 6px 0;
      padding: 10px 14px;
      margin: 8px 0;
    }
    .theme-dark .slides-block-ref, .theme-dark .pdf-block--ref {
      background: rgba(52, 211, 153, 0.08);
      border-left-color: #34d399;
    }
    .pdf-slide-notes {
      font-size: 14px;
      color: #059669;
      border-top: 1px dashed #cbd5e1;
      padding-top: 12px;
      margin-top: auto;
      line-height: 1.5;
    }
    .theme-dark .pdf-slide-notes {
      color: #34d399;
      border-top-color: #334155;
    }
    /* Layouts */
    .layout-cover .pdf-slide-body {
      justify-content: center;
      align-items: center;
      text-align: center;
    }
    .layout-cover h1 {
      font-size: 3.2rem;
    }
    .layout-center .pdf-slide-body {
      justify-content: center;
      align-items: center;
      text-align: center;
    }
    .layout-fact .pdf-slide-body {
      justify-content: center;
      align-items: center;
      text-align: center;
    }
    .layout-fact h1 {
      font-size: 4.5rem;
      color: #ef4444;
    }
    @media print {
      .slides-motion-fade-in,
      .slides-motion-slide-up,
      .slides-motion-slide-down,
      .slides-motion-slide-left,
      .slides-motion-slide-right,
      .slides-motion-zoom-in,
      .slides-motion-pop,
      .slides-motion-bounce {
        animation: none !important;
        opacity: 1 !important;
        transform: none !important;
      }
      /* PDF 打印讲义下禁用动态蒙版遮挡，保证内容 100% 完整可见 */
      .slides-mask-layer,
      .slides-mask-overlay,
      .slides-mask-divider-line {
        display: none !important;
        opacity: 0 !important;
        mask: none !important;
        -webkit-mask: none !important;
      }
      .slides-mask-body-container {
        clip-path: none !important;
        -webkit-clip-path: none !important;
        overflow: visible !important;
      }
    }
  `}function Ig(e,t){const o="即现讲义",i="16:9",n=Cr(e.config.colorSchema),s=e.config.theme||"apple-basic",l=e.slides.map((r,a)=>{const c=r.frontmatter.layout||"default",u=r.frontmatter.spacing,f=u&&u!=="inherit"?u:e.config.spacing||"normal",p=uc(r),d=`${a+1} / ${e.slides.length}`,b=r.frontmatter.background||e.config.background,m=nc(b),g=m===!0?"light":m===!1?"dark":n,y=b&&!/^(http|\/|data:|assets\/)/.test(b)?`background: ${st(b)};`:"";return`
      <section class="pdf-slide-page layout-${c} theme-${g} spacing-${f} slides-theme-${s}" data-slides-theme="${s}" style="${y}">
        <header class="pdf-slide-header">
          <span class="pdf-doc-title">${st(o)}</span>
          ${`<span class="pdf-page-badge">P. ${d}</span>`}
        </header>
        <div class="pdf-slide-body">
          ${p}
        </div>
        ${r.notes?`
          <footer class="pdf-slide-notes">
            <strong>演讲备注:</strong> ${st(r.notes)}
          </footer>
        `:""}
      </section>
    `}).join(`
`);return`<!DOCTYPE html>
<html lang="zh-CN">
<head>
  <meta charset="UTF-8">
  <title>${st(o)} - 高保真讲义</title>
  <style>
    ${Cg({pageRatio:i,customInlineStyles:t==null?void 0:t.customInlineStyles})}
  </style>
</head>
<body data-normalize-headings="${e.config.normalizeHeadingSizes?"true":"false"}" data-hide-unordered-markers="${e.config.showUnorderedListMarkers===!1?"true":"false"}" data-hide-ordered-markers="${e.config.showOrderedListMarkers===!1?"true":"false"}">
  ${l}
</body>
</html>`}function pc(e,t){var n;if(typeof window>"u"||typeof document>"u")return!1;const o=Ig(e,t);try{const s=document.createElement("iframe");s.style.position="fixed",s.style.right="0",s.style.bottom="0",s.style.width="0",s.style.height="0",s.style.border="none",s.style.visibility="hidden",document.body.appendChild(s);const l=(n=s.contentWindow)==null?void 0:n.document;if(l)return l.open(),l.write(o),l.close(),setTimeout(()=>{var r,a;try{(r=s.contentWindow)==null||r.focus(),(a=s.contentWindow)==null||a.print()}finally{setTimeout(()=>{s.remove()},2e3)}},350),!0}catch(s){console.warn("[pdf-exporter] iframe 打印模式异常，降级尝试 window.open:",s)}const i=window.open("","_blank");return i?(i.document.write(o),i.document.close(),i.focus(),setTimeout(()=>{i.print(),i.close()},350),!0):!1}var mn=typeof globalThis<"u"?globalThis:typeof window<"u"?window:typeof global<"u"?global:typeof self<"u"?self:{};function $g(e){return e&&e.__esModule&&Object.prototype.hasOwnProperty.call(e,"default")?e.default:e}function gn(e){throw new Error('Could not dynamically require "'+e+'". Please configure the dynamicRequireTargets or/and ignoreDynamicRequires option of @rollup/plugin-commonjs appropriately for this require call to work.')}var Ss={exports:{}};/*!

JSZip v3.10.1 - A JavaScript class for generating and reading zip files
<http://stuartk.com/jszip>

(c) 2009-2016 Stuart Knightley <stuart [at] stuartk.com>
Dual licenced under the MIT license or GPLv3. See https://raw.github.com/Stuk/jszip/main/LICENSE.markdown.

JSZip uses the library pako released under the MIT license :
https://github.com/nodeca/pako/blob/main/LICENSE
*/var El;function Tg(){return El||(El=1,(function(e,t){(function(o){e.exports=o()})(function(){return(function o(i,n,s){function l(c,u){if(!n[c]){if(!i[c]){var f=typeof gn=="function"&&gn;if(!u&&f)return f(c,!0);if(r)return r(c,!0);var p=new Error("Cannot find module '"+c+"'");throw p.code="MODULE_NOT_FOUND",p}var d=n[c]={exports:{}};i[c][0].call(d.exports,function(b){var m=i[c][1][b];return l(m||b)},d,d.exports,o,i,n,s)}return n[c].exports}for(var r=typeof gn=="function"&&gn,a=0;a<s.length;a++)l(s[a]);return l})({1:[function(o,i,n){var s=o("./utils"),l=o("./support"),r="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";n.encode=function(a){for(var c,u,f,p,d,b,m,g=[],y=0,k=a.length,x=k,$=s.getTypeOf(a)!=="string";y<a.length;)x=k-y,f=$?(c=a[y++],u=y<k?a[y++]:0,y<k?a[y++]:0):(c=a.charCodeAt(y++),u=y<k?a.charCodeAt(y++):0,y<k?a.charCodeAt(y++):0),p=c>>2,d=(3&c)<<4|u>>4,b=1<x?(15&u)<<2|f>>6:64,m=2<x?63&f:64,g.push(r.charAt(p)+r.charAt(d)+r.charAt(b)+r.charAt(m));return g.join("")},n.decode=function(a){var c,u,f,p,d,b,m=0,g=0,y="data:";if(a.substr(0,y.length)===y)throw new Error("Invalid base64 input, it looks like a data url.");var k,x=3*(a=a.replace(/[^A-Za-z0-9+/=]/g,"")).length/4;if(a.charAt(a.length-1)===r.charAt(64)&&x--,a.charAt(a.length-2)===r.charAt(64)&&x--,x%1!=0)throw new Error("Invalid base64 input, bad content length.");for(k=l.uint8array?new Uint8Array(0|x):new Array(0|x);m<a.length;)c=r.indexOf(a.charAt(m++))<<2|(p=r.indexOf(a.charAt(m++)))>>4,u=(15&p)<<4|(d=r.indexOf(a.charAt(m++)))>>2,f=(3&d)<<6|(b=r.indexOf(a.charAt(m++))),k[g++]=c,d!==64&&(k[g++]=u),b!==64&&(k[g++]=f);return k}},{"./support":30,"./utils":32}],2:[function(o,i,n){var s=o("./external"),l=o("./stream/DataWorker"),r=o("./stream/Crc32Probe"),a=o("./stream/DataLengthProbe");function c(u,f,p,d,b){this.compressedSize=u,this.uncompressedSize=f,this.crc32=p,this.compression=d,this.compressedContent=b}c.prototype={getContentWorker:function(){var u=new l(s.Promise.resolve(this.compressedContent)).pipe(this.compression.uncompressWorker()).pipe(new a("data_length")),f=this;return u.on("end",function(){if(this.streamInfo.data_length!==f.uncompressedSize)throw new Error("Bug : uncompressed data size mismatch")}),u},getCompressedWorker:function(){return new l(s.Promise.resolve(this.compressedContent)).withStreamInfo("compressedSize",this.compressedSize).withStreamInfo("uncompressedSize",this.uncompressedSize).withStreamInfo("crc32",this.crc32).withStreamInfo("compression",this.compression)}},c.createWorkerFrom=function(u,f,p){return u.pipe(new r).pipe(new a("uncompressedSize")).pipe(f.compressWorker(p)).pipe(new a("compressedSize")).withStreamInfo("compression",f)},i.exports=c},{"./external":6,"./stream/Crc32Probe":25,"./stream/DataLengthProbe":26,"./stream/DataWorker":27}],3:[function(o,i,n){var s=o("./stream/GenericWorker");n.STORE={magic:"\0\0",compressWorker:function(){return new s("STORE compression")},uncompressWorker:function(){return new s("STORE decompression")}},n.DEFLATE=o("./flate")},{"./flate":7,"./stream/GenericWorker":28}],4:[function(o,i,n){var s=o("./utils"),l=(function(){for(var r,a=[],c=0;c<256;c++){r=c;for(var u=0;u<8;u++)r=1&r?3988292384^r>>>1:r>>>1;a[c]=r}return a})();i.exports=function(r,a){return r!==void 0&&r.length?s.getTypeOf(r)!=="string"?(function(c,u,f,p){var d=l,b=p+f;c^=-1;for(var m=p;m<b;m++)c=c>>>8^d[255&(c^u[m])];return-1^c})(0|a,r,r.length,0):(function(c,u,f,p){var d=l,b=p+f;c^=-1;for(var m=p;m<b;m++)c=c>>>8^d[255&(c^u.charCodeAt(m))];return-1^c})(0|a,r,r.length,0):0}},{"./utils":32}],5:[function(o,i,n){n.base64=!1,n.binary=!1,n.dir=!1,n.createFolders=!0,n.date=null,n.compression=null,n.compressionOptions=null,n.comment=null,n.unixPermissions=null,n.dosPermissions=null},{}],6:[function(o,i,n){var s=null;s=typeof Promise<"u"?Promise:o("lie"),i.exports={Promise:s}},{lie:37}],7:[function(o,i,n){var s=typeof Uint8Array<"u"&&typeof Uint16Array<"u"&&typeof Uint32Array<"u",l=o("pako"),r=o("./utils"),a=o("./stream/GenericWorker"),c=s?"uint8array":"array";function u(f,p){a.call(this,"FlateWorker/"+f),this._pako=null,this._pakoAction=f,this._pakoOptions=p,this.meta={}}n.magic="\b\0",r.inherits(u,a),u.prototype.processChunk=function(f){this.meta=f.meta,this._pako===null&&this._createPako(),this._pako.push(r.transformTo(c,f.data),!1)},u.prototype.flush=function(){a.prototype.flush.call(this),this._pako===null&&this._createPako(),this._pako.push([],!0)},u.prototype.cleanUp=function(){a.prototype.cleanUp.call(this),this._pako=null},u.prototype._createPako=function(){this._pako=new l[this._pakoAction]({raw:!0,level:this._pakoOptions.level||-1});var f=this;this._pako.onData=function(p){f.push({data:p,meta:f.meta})}},n.compressWorker=function(f){return new u("Deflate",f)},n.uncompressWorker=function(){return new u("Inflate",{})}},{"./stream/GenericWorker":28,"./utils":32,pako:38}],8:[function(o,i,n){function s(d,b){var m,g="";for(m=0;m<b;m++)g+=String.fromCharCode(255&d),d>>>=8;return g}function l(d,b,m,g,y,k){var x,$,A=d.file,w=d.compression,_=k!==c.utf8encode,O=r.transformTo("string",k(A.name)),H=r.transformTo("string",c.utf8encode(A.name)),P=A.comment,F=r.transformTo("string",k(P)),E=r.transformTo("string",c.utf8encode(P)),D=H.length!==A.name.length,S=E.length!==P.length,q="",j="",C="",M=A.dir,B=A.date,te={crc32:0,compressedSize:0,uncompressedSize:0};b&&!m||(te.crc32=d.crc32,te.compressedSize=d.compressedSize,te.uncompressedSize=d.uncompressedSize);var V=0;b&&(V|=8),_||!D&&!S||(V|=2048);var K=0,ae=0;M&&(K|=16),y==="UNIX"?(ae=798,K|=(function(re,Se){var $e=re;return re||($e=Se?16893:33204),(65535&$e)<<16})(A.unixPermissions,M)):(ae=20,K|=(function(re){return 63&(re||0)})(A.dosPermissions)),x=B.getUTCHours(),x<<=6,x|=B.getUTCMinutes(),x<<=5,x|=B.getUTCSeconds()/2,$=B.getUTCFullYear()-1980,$<<=4,$|=B.getUTCMonth()+1,$<<=5,$|=B.getUTCDate(),D&&(j=s(1,1)+s(u(O),4)+H,q+="up"+s(j.length,2)+j),S&&(C=s(1,1)+s(u(F),4)+E,q+="uc"+s(C.length,2)+C);var oe="";return oe+=`
\0`,oe+=s(V,2),oe+=w.magic,oe+=s(x,2),oe+=s($,2),oe+=s(te.crc32,4),oe+=s(te.compressedSize,4),oe+=s(te.uncompressedSize,4),oe+=s(O.length,2),oe+=s(q.length,2),{fileRecord:f.LOCAL_FILE_HEADER+oe+O+q,dirRecord:f.CENTRAL_FILE_HEADER+s(ae,2)+oe+s(F.length,2)+"\0\0\0\0"+s(K,4)+s(g,4)+O+q+F}}var r=o("../utils"),a=o("../stream/GenericWorker"),c=o("../utf8"),u=o("../crc32"),f=o("../signature");function p(d,b,m,g){a.call(this,"ZipFileWorker"),this.bytesWritten=0,this.zipComment=b,this.zipPlatform=m,this.encodeFileName=g,this.streamFiles=d,this.accumulate=!1,this.contentBuffer=[],this.dirRecords=[],this.currentSourceOffset=0,this.entriesCount=0,this.currentFile=null,this._sources=[]}r.inherits(p,a),p.prototype.push=function(d){var b=d.meta.percent||0,m=this.entriesCount,g=this._sources.length;this.accumulate?this.contentBuffer.push(d):(this.bytesWritten+=d.data.length,a.prototype.push.call(this,{data:d.data,meta:{currentFile:this.currentFile,percent:m?(b+100*(m-g-1))/m:100}}))},p.prototype.openedSource=function(d){this.currentSourceOffset=this.bytesWritten,this.currentFile=d.file.name;var b=this.streamFiles&&!d.file.dir;if(b){var m=l(d,b,!1,this.currentSourceOffset,this.zipPlatform,this.encodeFileName);this.push({data:m.fileRecord,meta:{percent:0}})}else this.accumulate=!0},p.prototype.closedSource=function(d){this.accumulate=!1;var b=this.streamFiles&&!d.file.dir,m=l(d,b,!0,this.currentSourceOffset,this.zipPlatform,this.encodeFileName);if(this.dirRecords.push(m.dirRecord),b)this.push({data:(function(g){return f.DATA_DESCRIPTOR+s(g.crc32,4)+s(g.compressedSize,4)+s(g.uncompressedSize,4)})(d),meta:{percent:100}});else for(this.push({data:m.fileRecord,meta:{percent:0}});this.contentBuffer.length;)this.push(this.contentBuffer.shift());this.currentFile=null},p.prototype.flush=function(){for(var d=this.bytesWritten,b=0;b<this.dirRecords.length;b++)this.push({data:this.dirRecords[b],meta:{percent:100}});var m=this.bytesWritten-d,g=(function(y,k,x,$,A){var w=r.transformTo("string",A($));return f.CENTRAL_DIRECTORY_END+"\0\0\0\0"+s(y,2)+s(y,2)+s(k,4)+s(x,4)+s(w.length,2)+w})(this.dirRecords.length,m,d,this.zipComment,this.encodeFileName);this.push({data:g,meta:{percent:100}})},p.prototype.prepareNextSource=function(){this.previous=this._sources.shift(),this.openedSource(this.previous.streamInfo),this.isPaused?this.previous.pause():this.previous.resume()},p.prototype.registerPrevious=function(d){this._sources.push(d);var b=this;return d.on("data",function(m){b.processChunk(m)}),d.on("end",function(){b.closedSource(b.previous.streamInfo),b._sources.length?b.prepareNextSource():b.end()}),d.on("error",function(m){b.error(m)}),this},p.prototype.resume=function(){return!!a.prototype.resume.call(this)&&(!this.previous&&this._sources.length?(this.prepareNextSource(),!0):this.previous||this._sources.length||this.generatedError?void 0:(this.end(),!0))},p.prototype.error=function(d){var b=this._sources;if(!a.prototype.error.call(this,d))return!1;for(var m=0;m<b.length;m++)try{b[m].error(d)}catch{}return!0},p.prototype.lock=function(){a.prototype.lock.call(this);for(var d=this._sources,b=0;b<d.length;b++)d[b].lock()},i.exports=p},{"../crc32":4,"../signature":23,"../stream/GenericWorker":28,"../utf8":31,"../utils":32}],9:[function(o,i,n){var s=o("../compressions"),l=o("./ZipFileWorker");n.generateWorker=function(r,a,c){var u=new l(a.streamFiles,c,a.platform,a.encodeFileName),f=0;try{r.forEach(function(p,d){f++;var b=(function(k,x){var $=k||x,A=s[$];if(!A)throw new Error($+" is not a valid compression method !");return A})(d.options.compression,a.compression),m=d.options.compressionOptions||a.compressionOptions||{},g=d.dir,y=d.date;d._compressWorker(b,m).withStreamInfo("file",{name:p,dir:g,date:y,comment:d.comment||"",unixPermissions:d.unixPermissions,dosPermissions:d.dosPermissions}).pipe(u)}),u.entriesCount=f}catch(p){u.error(p)}return u}},{"../compressions":3,"./ZipFileWorker":8}],10:[function(o,i,n){function s(){if(!(this instanceof s))return new s;if(arguments.length)throw new Error("The constructor with parameters has been removed in JSZip 3.0, please check the upgrade guide.");this.files=Object.create(null),this.comment=null,this.root="",this.clone=function(){var l=new s;for(var r in this)typeof this[r]!="function"&&(l[r]=this[r]);return l}}(s.prototype=o("./object")).loadAsync=o("./load"),s.support=o("./support"),s.defaults=o("./defaults"),s.version="3.10.1",s.loadAsync=function(l,r){return new s().loadAsync(l,r)},s.external=o("./external"),i.exports=s},{"./defaults":5,"./external":6,"./load":11,"./object":15,"./support":30}],11:[function(o,i,n){var s=o("./utils"),l=o("./external"),r=o("./utf8"),a=o("./zipEntries"),c=o("./stream/Crc32Probe"),u=o("./nodejsUtils");function f(p){return new l.Promise(function(d,b){var m=p.decompressed.getContentWorker().pipe(new c);m.on("error",function(g){b(g)}).on("end",function(){m.streamInfo.crc32!==p.decompressed.crc32?b(new Error("Corrupted zip : CRC32 mismatch")):d()}).resume()})}i.exports=function(p,d){var b=this;return d=s.extend(d||{},{base64:!1,checkCRC32:!1,optimizedBinaryString:!1,createFolders:!1,decodeFileName:r.utf8decode}),u.isNode&&u.isStream(p)?l.Promise.reject(new Error("JSZip can't accept a stream when loading a zip file.")):s.prepareContent("the loaded zip file",p,!0,d.optimizedBinaryString,d.base64).then(function(m){var g=new a(d);return g.load(m),g}).then(function(m){var g=[l.Promise.resolve(m)],y=m.files;if(d.checkCRC32)for(var k=0;k<y.length;k++)g.push(f(y[k]));return l.Promise.all(g)}).then(function(m){for(var g=m.shift(),y=g.files,k=0;k<y.length;k++){var x=y[k],$=x.fileNameStr,A=s.resolve(x.fileNameStr);b.file(A,x.decompressed,{binary:!0,optimizedBinaryString:!0,date:x.date,dir:x.dir,comment:x.fileCommentStr.length?x.fileCommentStr:null,unixPermissions:x.unixPermissions,dosPermissions:x.dosPermissions,createFolders:d.createFolders}),x.dir||(b.file(A).unsafeOriginalName=$)}return g.zipComment.length&&(b.comment=g.zipComment),b})}},{"./external":6,"./nodejsUtils":14,"./stream/Crc32Probe":25,"./utf8":31,"./utils":32,"./zipEntries":33}],12:[function(o,i,n){var s=o("../utils"),l=o("../stream/GenericWorker");function r(a,c){l.call(this,"Nodejs stream input adapter for "+a),this._upstreamEnded=!1,this._bindStream(c)}s.inherits(r,l),r.prototype._bindStream=function(a){var c=this;(this._stream=a).pause(),a.on("data",function(u){c.push({data:u,meta:{percent:0}})}).on("error",function(u){c.isPaused?this.generatedError=u:c.error(u)}).on("end",function(){c.isPaused?c._upstreamEnded=!0:c.end()})},r.prototype.pause=function(){return!!l.prototype.pause.call(this)&&(this._stream.pause(),!0)},r.prototype.resume=function(){return!!l.prototype.resume.call(this)&&(this._upstreamEnded?this.end():this._stream.resume(),!0)},i.exports=r},{"../stream/GenericWorker":28,"../utils":32}],13:[function(o,i,n){var s=o("readable-stream").Readable;function l(r,a,c){s.call(this,a),this._helper=r;var u=this;r.on("data",function(f,p){u.push(f)||u._helper.pause(),c&&c(p)}).on("error",function(f){u.emit("error",f)}).on("end",function(){u.push(null)})}o("../utils").inherits(l,s),l.prototype._read=function(){this._helper.resume()},i.exports=l},{"../utils":32,"readable-stream":16}],14:[function(o,i,n){i.exports={isNode:typeof Buffer<"u",newBufferFrom:function(s,l){if(Buffer.from&&Buffer.from!==Uint8Array.from)return Buffer.from(s,l);if(typeof s=="number")throw new Error('The "data" argument must not be a number');return new Buffer(s,l)},allocBuffer:function(s){if(Buffer.alloc)return Buffer.alloc(s);var l=new Buffer(s);return l.fill(0),l},isBuffer:function(s){return Buffer.isBuffer(s)},isStream:function(s){return s&&typeof s.on=="function"&&typeof s.pause=="function"&&typeof s.resume=="function"}}},{}],15:[function(o,i,n){function s(A,w,_){var O,H=r.getTypeOf(w),P=r.extend(_||{},u);P.date=P.date||new Date,P.compression!==null&&(P.compression=P.compression.toUpperCase()),typeof P.unixPermissions=="string"&&(P.unixPermissions=parseInt(P.unixPermissions,8)),P.unixPermissions&&16384&P.unixPermissions&&(P.dir=!0),P.dosPermissions&&16&P.dosPermissions&&(P.dir=!0),P.dir&&(A=y(A)),P.createFolders&&(O=g(A))&&k.call(this,O,!0);var F=H==="string"&&P.binary===!1&&P.base64===!1;_&&_.binary!==void 0||(P.binary=!F),(w instanceof f&&w.uncompressedSize===0||P.dir||!w||w.length===0)&&(P.base64=!1,P.binary=!0,w="",P.compression="STORE",H="string");var E=null;E=w instanceof f||w instanceof a?w:b.isNode&&b.isStream(w)?new m(A,w):r.prepareContent(A,w,P.binary,P.optimizedBinaryString,P.base64);var D=new p(A,E,P);this.files[A]=D}var l=o("./utf8"),r=o("./utils"),a=o("./stream/GenericWorker"),c=o("./stream/StreamHelper"),u=o("./defaults"),f=o("./compressedObject"),p=o("./zipObject"),d=o("./generate"),b=o("./nodejsUtils"),m=o("./nodejs/NodejsStreamInputAdapter"),g=function(A){A.slice(-1)==="/"&&(A=A.substring(0,A.length-1));var w=A.lastIndexOf("/");return 0<w?A.substring(0,w):""},y=function(A){return A.slice(-1)!=="/"&&(A+="/"),A},k=function(A,w){return w=w!==void 0?w:u.createFolders,A=y(A),this.files[A]||s.call(this,A,null,{dir:!0,createFolders:w}),this.files[A]};function x(A){return Object.prototype.toString.call(A)==="[object RegExp]"}var $={load:function(){throw new Error("This method has been removed in JSZip 3.0, please check the upgrade guide.")},forEach:function(A){var w,_,O;for(w in this.files)O=this.files[w],(_=w.slice(this.root.length,w.length))&&w.slice(0,this.root.length)===this.root&&A(_,O)},filter:function(A){var w=[];return this.forEach(function(_,O){A(_,O)&&w.push(O)}),w},file:function(A,w,_){if(arguments.length!==1)return A=this.root+A,s.call(this,A,w,_),this;if(x(A)){var O=A;return this.filter(function(P,F){return!F.dir&&O.test(P)})}var H=this.files[this.root+A];return H&&!H.dir?H:null},folder:function(A){if(!A)return this;if(x(A))return this.filter(function(H,P){return P.dir&&A.test(H)});var w=this.root+A,_=k.call(this,w),O=this.clone();return O.root=_.name,O},remove:function(A){A=this.root+A;var w=this.files[A];if(w||(A.slice(-1)!=="/"&&(A+="/"),w=this.files[A]),w&&!w.dir)delete this.files[A];else for(var _=this.filter(function(H,P){return P.name.slice(0,A.length)===A}),O=0;O<_.length;O++)delete this.files[_[O].name];return this},generate:function(){throw new Error("This method has been removed in JSZip 3.0, please check the upgrade guide.")},generateInternalStream:function(A){var w,_={};try{if((_=r.extend(A||{},{streamFiles:!1,compression:"STORE",compressionOptions:null,type:"",platform:"DOS",comment:null,mimeType:"application/zip",encodeFileName:l.utf8encode})).type=_.type.toLowerCase(),_.compression=_.compression.toUpperCase(),_.type==="binarystring"&&(_.type="string"),!_.type)throw new Error("No output type specified.");r.checkSupport(_.type),_.platform!=="darwin"&&_.platform!=="freebsd"&&_.platform!=="linux"&&_.platform!=="sunos"||(_.platform="UNIX"),_.platform==="win32"&&(_.platform="DOS");var O=_.comment||this.comment||"";w=d.generateWorker(this,_,O)}catch(H){(w=new a("error")).error(H)}return new c(w,_.type||"string",_.mimeType)},generateAsync:function(A,w){return this.generateInternalStream(A).accumulate(w)},generateNodeStream:function(A,w){return(A=A||{}).type||(A.type="nodebuffer"),this.generateInternalStream(A).toNodejsStream(w)}};i.exports=$},{"./compressedObject":2,"./defaults":5,"./generate":9,"./nodejs/NodejsStreamInputAdapter":12,"./nodejsUtils":14,"./stream/GenericWorker":28,"./stream/StreamHelper":29,"./utf8":31,"./utils":32,"./zipObject":35}],16:[function(o,i,n){i.exports=o("stream")},{stream:void 0}],17:[function(o,i,n){var s=o("./DataReader");function l(r){s.call(this,r);for(var a=0;a<this.data.length;a++)r[a]=255&r[a]}o("../utils").inherits(l,s),l.prototype.byteAt=function(r){return this.data[this.zero+r]},l.prototype.lastIndexOfSignature=function(r){for(var a=r.charCodeAt(0),c=r.charCodeAt(1),u=r.charCodeAt(2),f=r.charCodeAt(3),p=this.length-4;0<=p;--p)if(this.data[p]===a&&this.data[p+1]===c&&this.data[p+2]===u&&this.data[p+3]===f)return p-this.zero;return-1},l.prototype.readAndCheckSignature=function(r){var a=r.charCodeAt(0),c=r.charCodeAt(1),u=r.charCodeAt(2),f=r.charCodeAt(3),p=this.readData(4);return a===p[0]&&c===p[1]&&u===p[2]&&f===p[3]},l.prototype.readData=function(r){if(this.checkOffset(r),r===0)return[];var a=this.data.slice(this.zero+this.index,this.zero+this.index+r);return this.index+=r,a},i.exports=l},{"../utils":32,"./DataReader":18}],18:[function(o,i,n){var s=o("../utils");function l(r){this.data=r,this.length=r.length,this.index=0,this.zero=0}l.prototype={checkOffset:function(r){this.checkIndex(this.index+r)},checkIndex:function(r){if(this.length<this.zero+r||r<0)throw new Error("End of data reached (data length = "+this.length+", asked index = "+r+"). Corrupted zip ?")},setIndex:function(r){this.checkIndex(r),this.index=r},skip:function(r){this.setIndex(this.index+r)},byteAt:function(){},readInt:function(r){var a,c=0;for(this.checkOffset(r),a=this.index+r-1;a>=this.index;a--)c=(c<<8)+this.byteAt(a);return this.index+=r,c},readString:function(r){return s.transformTo("string",this.readData(r))},readData:function(){},lastIndexOfSignature:function(){},readAndCheckSignature:function(){},readDate:function(){var r=this.readInt(4);return new Date(Date.UTC(1980+(r>>25&127),(r>>21&15)-1,r>>16&31,r>>11&31,r>>5&63,(31&r)<<1))}},i.exports=l},{"../utils":32}],19:[function(o,i,n){var s=o("./Uint8ArrayReader");function l(r){s.call(this,r)}o("../utils").inherits(l,s),l.prototype.readData=function(r){this.checkOffset(r);var a=this.data.slice(this.zero+this.index,this.zero+this.index+r);return this.index+=r,a},i.exports=l},{"../utils":32,"./Uint8ArrayReader":21}],20:[function(o,i,n){var s=o("./DataReader");function l(r){s.call(this,r)}o("../utils").inherits(l,s),l.prototype.byteAt=function(r){return this.data.charCodeAt(this.zero+r)},l.prototype.lastIndexOfSignature=function(r){return this.data.lastIndexOf(r)-this.zero},l.prototype.readAndCheckSignature=function(r){return r===this.readData(4)},l.prototype.readData=function(r){this.checkOffset(r);var a=this.data.slice(this.zero+this.index,this.zero+this.index+r);return this.index+=r,a},i.exports=l},{"../utils":32,"./DataReader":18}],21:[function(o,i,n){var s=o("./ArrayReader");function l(r){s.call(this,r)}o("../utils").inherits(l,s),l.prototype.readData=function(r){if(this.checkOffset(r),r===0)return new Uint8Array(0);var a=this.data.subarray(this.zero+this.index,this.zero+this.index+r);return this.index+=r,a},i.exports=l},{"../utils":32,"./ArrayReader":17}],22:[function(o,i,n){var s=o("../utils"),l=o("../support"),r=o("./ArrayReader"),a=o("./StringReader"),c=o("./NodeBufferReader"),u=o("./Uint8ArrayReader");i.exports=function(f){var p=s.getTypeOf(f);return s.checkSupport(p),p!=="string"||l.uint8array?p==="nodebuffer"?new c(f):l.uint8array?new u(s.transformTo("uint8array",f)):new r(s.transformTo("array",f)):new a(f)}},{"../support":30,"../utils":32,"./ArrayReader":17,"./NodeBufferReader":19,"./StringReader":20,"./Uint8ArrayReader":21}],23:[function(o,i,n){n.LOCAL_FILE_HEADER="PK",n.CENTRAL_FILE_HEADER="PK",n.CENTRAL_DIRECTORY_END="PK",n.ZIP64_CENTRAL_DIRECTORY_LOCATOR="PK\x07",n.ZIP64_CENTRAL_DIRECTORY_END="PK",n.DATA_DESCRIPTOR="PK\x07\b"},{}],24:[function(o,i,n){var s=o("./GenericWorker"),l=o("../utils");function r(a){s.call(this,"ConvertWorker to "+a),this.destType=a}l.inherits(r,s),r.prototype.processChunk=function(a){this.push({data:l.transformTo(this.destType,a.data),meta:a.meta})},i.exports=r},{"../utils":32,"./GenericWorker":28}],25:[function(o,i,n){var s=o("./GenericWorker"),l=o("../crc32");function r(){s.call(this,"Crc32Probe"),this.withStreamInfo("crc32",0)}o("../utils").inherits(r,s),r.prototype.processChunk=function(a){this.streamInfo.crc32=l(a.data,this.streamInfo.crc32||0),this.push(a)},i.exports=r},{"../crc32":4,"../utils":32,"./GenericWorker":28}],26:[function(o,i,n){var s=o("../utils"),l=o("./GenericWorker");function r(a){l.call(this,"DataLengthProbe for "+a),this.propName=a,this.withStreamInfo(a,0)}s.inherits(r,l),r.prototype.processChunk=function(a){if(a){var c=this.streamInfo[this.propName]||0;this.streamInfo[this.propName]=c+a.data.length}l.prototype.processChunk.call(this,a)},i.exports=r},{"../utils":32,"./GenericWorker":28}],27:[function(o,i,n){var s=o("../utils"),l=o("./GenericWorker");function r(a){l.call(this,"DataWorker");var c=this;this.dataIsReady=!1,this.index=0,this.max=0,this.data=null,this.type="",this._tickScheduled=!1,a.then(function(u){c.dataIsReady=!0,c.data=u,c.max=u&&u.length||0,c.type=s.getTypeOf(u),c.isPaused||c._tickAndRepeat()},function(u){c.error(u)})}s.inherits(r,l),r.prototype.cleanUp=function(){l.prototype.cleanUp.call(this),this.data=null},r.prototype.resume=function(){return!!l.prototype.resume.call(this)&&(!this._tickScheduled&&this.dataIsReady&&(this._tickScheduled=!0,s.delay(this._tickAndRepeat,[],this)),!0)},r.prototype._tickAndRepeat=function(){this._tickScheduled=!1,this.isPaused||this.isFinished||(this._tick(),this.isFinished||(s.delay(this._tickAndRepeat,[],this),this._tickScheduled=!0))},r.prototype._tick=function(){if(this.isPaused||this.isFinished)return!1;var a=null,c=Math.min(this.max,this.index+16384);if(this.index>=this.max)return this.end();switch(this.type){case"string":a=this.data.substring(this.index,c);break;case"uint8array":a=this.data.subarray(this.index,c);break;case"array":case"nodebuffer":a=this.data.slice(this.index,c)}return this.index=c,this.push({data:a,meta:{percent:this.max?this.index/this.max*100:0}})},i.exports=r},{"../utils":32,"./GenericWorker":28}],28:[function(o,i,n){function s(l){this.name=l||"default",this.streamInfo={},this.generatedError=null,this.extraStreamInfo={},this.isPaused=!0,this.isFinished=!1,this.isLocked=!1,this._listeners={data:[],end:[],error:[]},this.previous=null}s.prototype={push:function(l){this.emit("data",l)},end:function(){if(this.isFinished)return!1;this.flush();try{this.emit("end"),this.cleanUp(),this.isFinished=!0}catch(l){this.emit("error",l)}return!0},error:function(l){return!this.isFinished&&(this.isPaused?this.generatedError=l:(this.isFinished=!0,this.emit("error",l),this.previous&&this.previous.error(l),this.cleanUp()),!0)},on:function(l,r){return this._listeners[l].push(r),this},cleanUp:function(){this.streamInfo=this.generatedError=this.extraStreamInfo=null,this._listeners=[]},emit:function(l,r){if(this._listeners[l])for(var a=0;a<this._listeners[l].length;a++)this._listeners[l][a].call(this,r)},pipe:function(l){return l.registerPrevious(this)},registerPrevious:function(l){if(this.isLocked)throw new Error("The stream '"+this+"' has already been used.");this.streamInfo=l.streamInfo,this.mergeStreamInfo(),this.previous=l;var r=this;return l.on("data",function(a){r.processChunk(a)}),l.on("end",function(){r.end()}),l.on("error",function(a){r.error(a)}),this},pause:function(){return!this.isPaused&&!this.isFinished&&(this.isPaused=!0,this.previous&&this.previous.pause(),!0)},resume:function(){if(!this.isPaused||this.isFinished)return!1;var l=this.isPaused=!1;return this.generatedError&&(this.error(this.generatedError),l=!0),this.previous&&this.previous.resume(),!l},flush:function(){},processChunk:function(l){this.push(l)},withStreamInfo:function(l,r){return this.extraStreamInfo[l]=r,this.mergeStreamInfo(),this},mergeStreamInfo:function(){for(var l in this.extraStreamInfo)Object.prototype.hasOwnProperty.call(this.extraStreamInfo,l)&&(this.streamInfo[l]=this.extraStreamInfo[l])},lock:function(){if(this.isLocked)throw new Error("The stream '"+this+"' has already been used.");this.isLocked=!0,this.previous&&this.previous.lock()},toString:function(){var l="Worker "+this.name;return this.previous?this.previous+" -> "+l:l}},i.exports=s},{}],29:[function(o,i,n){var s=o("../utils"),l=o("./ConvertWorker"),r=o("./GenericWorker"),a=o("../base64"),c=o("../support"),u=o("../external"),f=null;if(c.nodestream)try{f=o("../nodejs/NodejsStreamOutputAdapter")}catch{}function p(b,m){return new u.Promise(function(g,y){var k=[],x=b._internalType,$=b._outputType,A=b._mimeType;b.on("data",function(w,_){k.push(w),m&&m(_)}).on("error",function(w){k=[],y(w)}).on("end",function(){try{var w=(function(_,O,H){switch(_){case"blob":return s.newBlob(s.transformTo("arraybuffer",O),H);case"base64":return a.encode(O);default:return s.transformTo(_,O)}})($,(function(_,O){var H,P=0,F=null,E=0;for(H=0;H<O.length;H++)E+=O[H].length;switch(_){case"string":return O.join("");case"array":return Array.prototype.concat.apply([],O);case"uint8array":for(F=new Uint8Array(E),H=0;H<O.length;H++)F.set(O[H],P),P+=O[H].length;return F;case"nodebuffer":return Buffer.concat(O);default:throw new Error("concat : unsupported type '"+_+"'")}})(x,k),A);g(w)}catch(_){y(_)}k=[]}).resume()})}function d(b,m,g){var y=m;switch(m){case"blob":case"arraybuffer":y="uint8array";break;case"base64":y="string"}try{this._internalType=y,this._outputType=m,this._mimeType=g,s.checkSupport(y),this._worker=b.pipe(new l(y)),b.lock()}catch(k){this._worker=new r("error"),this._worker.error(k)}}d.prototype={accumulate:function(b){return p(this,b)},on:function(b,m){var g=this;return b==="data"?this._worker.on(b,function(y){m.call(g,y.data,y.meta)}):this._worker.on(b,function(){s.delay(m,arguments,g)}),this},resume:function(){return s.delay(this._worker.resume,[],this._worker),this},pause:function(){return this._worker.pause(),this},toNodejsStream:function(b){if(s.checkSupport("nodestream"),this._outputType!=="nodebuffer")throw new Error(this._outputType+" is not supported by this method");return new f(this,{objectMode:this._outputType!=="nodebuffer"},b)}},i.exports=d},{"../base64":1,"../external":6,"../nodejs/NodejsStreamOutputAdapter":13,"../support":30,"../utils":32,"./ConvertWorker":24,"./GenericWorker":28}],30:[function(o,i,n){if(n.base64=!0,n.array=!0,n.string=!0,n.arraybuffer=typeof ArrayBuffer<"u"&&typeof Uint8Array<"u",n.nodebuffer=typeof Buffer<"u",n.uint8array=typeof Uint8Array<"u",typeof ArrayBuffer>"u")n.blob=!1;else{var s=new ArrayBuffer(0);try{n.blob=new Blob([s],{type:"application/zip"}).size===0}catch{try{var l=new(self.BlobBuilder||self.WebKitBlobBuilder||self.MozBlobBuilder||self.MSBlobBuilder);l.append(s),n.blob=l.getBlob("application/zip").size===0}catch{n.blob=!1}}}try{n.nodestream=!!o("readable-stream").Readable}catch{n.nodestream=!1}},{"readable-stream":16}],31:[function(o,i,n){for(var s=o("./utils"),l=o("./support"),r=o("./nodejsUtils"),a=o("./stream/GenericWorker"),c=new Array(256),u=0;u<256;u++)c[u]=252<=u?6:248<=u?5:240<=u?4:224<=u?3:192<=u?2:1;c[254]=c[254]=1;function f(){a.call(this,"utf-8 decode"),this.leftOver=null}function p(){a.call(this,"utf-8 encode")}n.utf8encode=function(d){return l.nodebuffer?r.newBufferFrom(d,"utf-8"):(function(b){var m,g,y,k,x,$=b.length,A=0;for(k=0;k<$;k++)(64512&(g=b.charCodeAt(k)))==55296&&k+1<$&&(64512&(y=b.charCodeAt(k+1)))==56320&&(g=65536+(g-55296<<10)+(y-56320),k++),A+=g<128?1:g<2048?2:g<65536?3:4;for(m=l.uint8array?new Uint8Array(A):new Array(A),k=x=0;x<A;k++)(64512&(g=b.charCodeAt(k)))==55296&&k+1<$&&(64512&(y=b.charCodeAt(k+1)))==56320&&(g=65536+(g-55296<<10)+(y-56320),k++),g<128?m[x++]=g:(g<2048?m[x++]=192|g>>>6:(g<65536?m[x++]=224|g>>>12:(m[x++]=240|g>>>18,m[x++]=128|g>>>12&63),m[x++]=128|g>>>6&63),m[x++]=128|63&g);return m})(d)},n.utf8decode=function(d){return l.nodebuffer?s.transformTo("nodebuffer",d).toString("utf-8"):(function(b){var m,g,y,k,x=b.length,$=new Array(2*x);for(m=g=0;m<x;)if((y=b[m++])<128)$[g++]=y;else if(4<(k=c[y]))$[g++]=65533,m+=k-1;else{for(y&=k===2?31:k===3?15:7;1<k&&m<x;)y=y<<6|63&b[m++],k--;1<k?$[g++]=65533:y<65536?$[g++]=y:(y-=65536,$[g++]=55296|y>>10&1023,$[g++]=56320|1023&y)}return $.length!==g&&($.subarray?$=$.subarray(0,g):$.length=g),s.applyFromCharCode($)})(d=s.transformTo(l.uint8array?"uint8array":"array",d))},s.inherits(f,a),f.prototype.processChunk=function(d){var b=s.transformTo(l.uint8array?"uint8array":"array",d.data);if(this.leftOver&&this.leftOver.length){if(l.uint8array){var m=b;(b=new Uint8Array(m.length+this.leftOver.length)).set(this.leftOver,0),b.set(m,this.leftOver.length)}else b=this.leftOver.concat(b);this.leftOver=null}var g=(function(k,x){var $;for((x=x||k.length)>k.length&&(x=k.length),$=x-1;0<=$&&(192&k[$])==128;)$--;return $<0||$===0?x:$+c[k[$]]>x?$:x})(b),y=b;g!==b.length&&(l.uint8array?(y=b.subarray(0,g),this.leftOver=b.subarray(g,b.length)):(y=b.slice(0,g),this.leftOver=b.slice(g,b.length))),this.push({data:n.utf8decode(y),meta:d.meta})},f.prototype.flush=function(){this.leftOver&&this.leftOver.length&&(this.push({data:n.utf8decode(this.leftOver),meta:{}}),this.leftOver=null)},n.Utf8DecodeWorker=f,s.inherits(p,a),p.prototype.processChunk=function(d){this.push({data:n.utf8encode(d.data),meta:d.meta})},n.Utf8EncodeWorker=p},{"./nodejsUtils":14,"./stream/GenericWorker":28,"./support":30,"./utils":32}],32:[function(o,i,n){var s=o("./support"),l=o("./base64"),r=o("./nodejsUtils"),a=o("./external");function c(m){return m}function u(m,g){for(var y=0;y<m.length;++y)g[y]=255&m.charCodeAt(y);return g}o("setimmediate"),n.newBlob=function(m,g){n.checkSupport("blob");try{return new Blob([m],{type:g})}catch{try{var y=new(self.BlobBuilder||self.WebKitBlobBuilder||self.MozBlobBuilder||self.MSBlobBuilder);return y.append(m),y.getBlob(g)}catch{throw new Error("Bug : can't construct the Blob.")}}};var f={stringifyByChunk:function(m,g,y){var k=[],x=0,$=m.length;if($<=y)return String.fromCharCode.apply(null,m);for(;x<$;)g==="array"||g==="nodebuffer"?k.push(String.fromCharCode.apply(null,m.slice(x,Math.min(x+y,$)))):k.push(String.fromCharCode.apply(null,m.subarray(x,Math.min(x+y,$)))),x+=y;return k.join("")},stringifyByChar:function(m){for(var g="",y=0;y<m.length;y++)g+=String.fromCharCode(m[y]);return g},applyCanBeUsed:{uint8array:(function(){try{return s.uint8array&&String.fromCharCode.apply(null,new Uint8Array(1)).length===1}catch{return!1}})(),nodebuffer:(function(){try{return s.nodebuffer&&String.fromCharCode.apply(null,r.allocBuffer(1)).length===1}catch{return!1}})()}};function p(m){var g=65536,y=n.getTypeOf(m),k=!0;if(y==="uint8array"?k=f.applyCanBeUsed.uint8array:y==="nodebuffer"&&(k=f.applyCanBeUsed.nodebuffer),k)for(;1<g;)try{return f.stringifyByChunk(m,y,g)}catch{g=Math.floor(g/2)}return f.stringifyByChar(m)}function d(m,g){for(var y=0;y<m.length;y++)g[y]=m[y];return g}n.applyFromCharCode=p;var b={};b.string={string:c,array:function(m){return u(m,new Array(m.length))},arraybuffer:function(m){return b.string.uint8array(m).buffer},uint8array:function(m){return u(m,new Uint8Array(m.length))},nodebuffer:function(m){return u(m,r.allocBuffer(m.length))}},b.array={string:p,array:c,arraybuffer:function(m){return new Uint8Array(m).buffer},uint8array:function(m){return new Uint8Array(m)},nodebuffer:function(m){return r.newBufferFrom(m)}},b.arraybuffer={string:function(m){return p(new Uint8Array(m))},array:function(m){return d(new Uint8Array(m),new Array(m.byteLength))},arraybuffer:c,uint8array:function(m){return new Uint8Array(m)},nodebuffer:function(m){return r.newBufferFrom(new Uint8Array(m))}},b.uint8array={string:p,array:function(m){return d(m,new Array(m.length))},arraybuffer:function(m){return m.buffer},uint8array:c,nodebuffer:function(m){return r.newBufferFrom(m)}},b.nodebuffer={string:p,array:function(m){return d(m,new Array(m.length))},arraybuffer:function(m){return b.nodebuffer.uint8array(m).buffer},uint8array:function(m){return d(m,new Uint8Array(m.length))},nodebuffer:c},n.transformTo=function(m,g){if(g=g||"",!m)return g;n.checkSupport(m);var y=n.getTypeOf(g);return b[y][m](g)},n.resolve=function(m){for(var g=m.split("/"),y=[],k=0;k<g.length;k++){var x=g[k];x==="."||x===""&&k!==0&&k!==g.length-1||(x===".."?y.pop():y.push(x))}return y.join("/")},n.getTypeOf=function(m){return typeof m=="string"?"string":Object.prototype.toString.call(m)==="[object Array]"?"array":s.nodebuffer&&r.isBuffer(m)?"nodebuffer":s.uint8array&&m instanceof Uint8Array?"uint8array":s.arraybuffer&&m instanceof ArrayBuffer?"arraybuffer":void 0},n.checkSupport=function(m){if(!s[m.toLowerCase()])throw new Error(m+" is not supported by this platform")},n.MAX_VALUE_16BITS=65535,n.MAX_VALUE_32BITS=-1,n.pretty=function(m){var g,y,k="";for(y=0;y<(m||"").length;y++)k+="\\x"+((g=m.charCodeAt(y))<16?"0":"")+g.toString(16).toUpperCase();return k},n.delay=function(m,g,y){setImmediate(function(){m.apply(y||null,g||[])})},n.inherits=function(m,g){function y(){}y.prototype=g.prototype,m.prototype=new y},n.extend=function(){var m,g,y={};for(m=0;m<arguments.length;m++)for(g in arguments[m])Object.prototype.hasOwnProperty.call(arguments[m],g)&&y[g]===void 0&&(y[g]=arguments[m][g]);return y},n.prepareContent=function(m,g,y,k,x){return a.Promise.resolve(g).then(function($){return s.blob&&($ instanceof Blob||["[object File]","[object Blob]"].indexOf(Object.prototype.toString.call($))!==-1)&&typeof FileReader<"u"?new a.Promise(function(A,w){var _=new FileReader;_.onload=function(O){A(O.target.result)},_.onerror=function(O){w(O.target.error)},_.readAsArrayBuffer($)}):$}).then(function($){var A=n.getTypeOf($);return A?(A==="arraybuffer"?$=n.transformTo("uint8array",$):A==="string"&&(x?$=l.decode($):y&&k!==!0&&($=(function(w){return u(w,s.uint8array?new Uint8Array(w.length):new Array(w.length))})($))),$):a.Promise.reject(new Error("Can't read the data of '"+m+"'. Is it in a supported JavaScript type (String, Blob, ArrayBuffer, etc) ?"))})}},{"./base64":1,"./external":6,"./nodejsUtils":14,"./support":30,setimmediate:54}],33:[function(o,i,n){var s=o("./reader/readerFor"),l=o("./utils"),r=o("./signature"),a=o("./zipEntry"),c=o("./support");function u(f){this.files=[],this.loadOptions=f}u.prototype={checkSignature:function(f){if(!this.reader.readAndCheckSignature(f)){this.reader.index-=4;var p=this.reader.readString(4);throw new Error("Corrupted zip or bug: unexpected signature ("+l.pretty(p)+", expected "+l.pretty(f)+")")}},isSignature:function(f,p){var d=this.reader.index;this.reader.setIndex(f);var b=this.reader.readString(4)===p;return this.reader.setIndex(d),b},readBlockEndOfCentral:function(){this.diskNumber=this.reader.readInt(2),this.diskWithCentralDirStart=this.reader.readInt(2),this.centralDirRecordsOnThisDisk=this.reader.readInt(2),this.centralDirRecords=this.reader.readInt(2),this.centralDirSize=this.reader.readInt(4),this.centralDirOffset=this.reader.readInt(4),this.zipCommentLength=this.reader.readInt(2);var f=this.reader.readData(this.zipCommentLength),p=c.uint8array?"uint8array":"array",d=l.transformTo(p,f);this.zipComment=this.loadOptions.decodeFileName(d)},readBlockZip64EndOfCentral:function(){this.zip64EndOfCentralSize=this.reader.readInt(8),this.reader.skip(4),this.diskNumber=this.reader.readInt(4),this.diskWithCentralDirStart=this.reader.readInt(4),this.centralDirRecordsOnThisDisk=this.reader.readInt(8),this.centralDirRecords=this.reader.readInt(8),this.centralDirSize=this.reader.readInt(8),this.centralDirOffset=this.reader.readInt(8),this.zip64ExtensibleData={};for(var f,p,d,b=this.zip64EndOfCentralSize-44;0<b;)f=this.reader.readInt(2),p=this.reader.readInt(4),d=this.reader.readData(p),this.zip64ExtensibleData[f]={id:f,length:p,value:d}},readBlockZip64EndOfCentralLocator:function(){if(this.diskWithZip64CentralDirStart=this.reader.readInt(4),this.relativeOffsetEndOfZip64CentralDir=this.reader.readInt(8),this.disksCount=this.reader.readInt(4),1<this.disksCount)throw new Error("Multi-volumes zip are not supported")},readLocalFiles:function(){var f,p;for(f=0;f<this.files.length;f++)p=this.files[f],this.reader.setIndex(p.localHeaderOffset),this.checkSignature(r.LOCAL_FILE_HEADER),p.readLocalPart(this.reader),p.handleUTF8(),p.processAttributes()},readCentralDir:function(){var f;for(this.reader.setIndex(this.centralDirOffset);this.reader.readAndCheckSignature(r.CENTRAL_FILE_HEADER);)(f=new a({zip64:this.zip64},this.loadOptions)).readCentralPart(this.reader),this.files.push(f);if(this.centralDirRecords!==this.files.length&&this.centralDirRecords!==0&&this.files.length===0)throw new Error("Corrupted zip or bug: expected "+this.centralDirRecords+" records in central dir, got "+this.files.length)},readEndOfCentral:function(){var f=this.reader.lastIndexOfSignature(r.CENTRAL_DIRECTORY_END);if(f<0)throw this.isSignature(0,r.LOCAL_FILE_HEADER)?new Error("Corrupted zip: can't find end of central directory"):new Error("Can't find end of central directory : is this a zip file ? If it is, see https://stuk.github.io/jszip/documentation/howto/read_zip.html");this.reader.setIndex(f);var p=f;if(this.checkSignature(r.CENTRAL_DIRECTORY_END),this.readBlockEndOfCentral(),this.diskNumber===l.MAX_VALUE_16BITS||this.diskWithCentralDirStart===l.MAX_VALUE_16BITS||this.centralDirRecordsOnThisDisk===l.MAX_VALUE_16BITS||this.centralDirRecords===l.MAX_VALUE_16BITS||this.centralDirSize===l.MAX_VALUE_32BITS||this.centralDirOffset===l.MAX_VALUE_32BITS){if(this.zip64=!0,(f=this.reader.lastIndexOfSignature(r.ZIP64_CENTRAL_DIRECTORY_LOCATOR))<0)throw new Error("Corrupted zip: can't find the ZIP64 end of central directory locator");if(this.reader.setIndex(f),this.checkSignature(r.ZIP64_CENTRAL_DIRECTORY_LOCATOR),this.readBlockZip64EndOfCentralLocator(),!this.isSignature(this.relativeOffsetEndOfZip64CentralDir,r.ZIP64_CENTRAL_DIRECTORY_END)&&(this.relativeOffsetEndOfZip64CentralDir=this.reader.lastIndexOfSignature(r.ZIP64_CENTRAL_DIRECTORY_END),this.relativeOffsetEndOfZip64CentralDir<0))throw new Error("Corrupted zip: can't find the ZIP64 end of central directory");this.reader.setIndex(this.relativeOffsetEndOfZip64CentralDir),this.checkSignature(r.ZIP64_CENTRAL_DIRECTORY_END),this.readBlockZip64EndOfCentral()}var d=this.centralDirOffset+this.centralDirSize;this.zip64&&(d+=20,d+=12+this.zip64EndOfCentralSize);var b=p-d;if(0<b)this.isSignature(p,r.CENTRAL_FILE_HEADER)||(this.reader.zero=b);else if(b<0)throw new Error("Corrupted zip: missing "+Math.abs(b)+" bytes.")},prepareReader:function(f){this.reader=s(f)},load:function(f){this.prepareReader(f),this.readEndOfCentral(),this.readCentralDir(),this.readLocalFiles()}},i.exports=u},{"./reader/readerFor":22,"./signature":23,"./support":30,"./utils":32,"./zipEntry":34}],34:[function(o,i,n){var s=o("./reader/readerFor"),l=o("./utils"),r=o("./compressedObject"),a=o("./crc32"),c=o("./utf8"),u=o("./compressions"),f=o("./support");function p(d,b){this.options=d,this.loadOptions=b}p.prototype={isEncrypted:function(){return(1&this.bitFlag)==1},useUTF8:function(){return(2048&this.bitFlag)==2048},readLocalPart:function(d){var b,m;if(d.skip(22),this.fileNameLength=d.readInt(2),m=d.readInt(2),this.fileName=d.readData(this.fileNameLength),d.skip(m),this.compressedSize===-1||this.uncompressedSize===-1)throw new Error("Bug or corrupted zip : didn't get enough information from the central directory (compressedSize === -1 || uncompressedSize === -1)");if((b=(function(g){for(var y in u)if(Object.prototype.hasOwnProperty.call(u,y)&&u[y].magic===g)return u[y];return null})(this.compressionMethod))===null)throw new Error("Corrupted zip : compression "+l.pretty(this.compressionMethod)+" unknown (inner file : "+l.transformTo("string",this.fileName)+")");this.decompressed=new r(this.compressedSize,this.uncompressedSize,this.crc32,b,d.readData(this.compressedSize))},readCentralPart:function(d){this.versionMadeBy=d.readInt(2),d.skip(2),this.bitFlag=d.readInt(2),this.compressionMethod=d.readString(2),this.date=d.readDate(),this.crc32=d.readInt(4),this.compressedSize=d.readInt(4),this.uncompressedSize=d.readInt(4);var b=d.readInt(2);if(this.extraFieldsLength=d.readInt(2),this.fileCommentLength=d.readInt(2),this.diskNumberStart=d.readInt(2),this.internalFileAttributes=d.readInt(2),this.externalFileAttributes=d.readInt(4),this.localHeaderOffset=d.readInt(4),this.isEncrypted())throw new Error("Encrypted zip are not supported");d.skip(b),this.readExtraFields(d),this.parseZIP64ExtraField(d),this.fileComment=d.readData(this.fileCommentLength)},processAttributes:function(){this.unixPermissions=null,this.dosPermissions=null;var d=this.versionMadeBy>>8;this.dir=!!(16&this.externalFileAttributes),d==0&&(this.dosPermissions=63&this.externalFileAttributes),d==3&&(this.unixPermissions=this.externalFileAttributes>>16&65535),this.dir||this.fileNameStr.slice(-1)!=="/"||(this.dir=!0)},parseZIP64ExtraField:function(){if(this.extraFields[1]){var d=s(this.extraFields[1].value);this.uncompressedSize===l.MAX_VALUE_32BITS&&(this.uncompressedSize=d.readInt(8)),this.compressedSize===l.MAX_VALUE_32BITS&&(this.compressedSize=d.readInt(8)),this.localHeaderOffset===l.MAX_VALUE_32BITS&&(this.localHeaderOffset=d.readInt(8)),this.diskNumberStart===l.MAX_VALUE_32BITS&&(this.diskNumberStart=d.readInt(4))}},readExtraFields:function(d){var b,m,g,y=d.index+this.extraFieldsLength;for(this.extraFields||(this.extraFields={});d.index+4<y;)b=d.readInt(2),m=d.readInt(2),g=d.readData(m),this.extraFields[b]={id:b,length:m,value:g};d.setIndex(y)},handleUTF8:function(){var d=f.uint8array?"uint8array":"array";if(this.useUTF8())this.fileNameStr=c.utf8decode(this.fileName),this.fileCommentStr=c.utf8decode(this.fileComment);else{var b=this.findExtraFieldUnicodePath();if(b!==null)this.fileNameStr=b;else{var m=l.transformTo(d,this.fileName);this.fileNameStr=this.loadOptions.decodeFileName(m)}var g=this.findExtraFieldUnicodeComment();if(g!==null)this.fileCommentStr=g;else{var y=l.transformTo(d,this.fileComment);this.fileCommentStr=this.loadOptions.decodeFileName(y)}}},findExtraFieldUnicodePath:function(){var d=this.extraFields[28789];if(d){var b=s(d.value);return b.readInt(1)!==1||a(this.fileName)!==b.readInt(4)?null:c.utf8decode(b.readData(d.length-5))}return null},findExtraFieldUnicodeComment:function(){var d=this.extraFields[25461];if(d){var b=s(d.value);return b.readInt(1)!==1||a(this.fileComment)!==b.readInt(4)?null:c.utf8decode(b.readData(d.length-5))}return null}},i.exports=p},{"./compressedObject":2,"./compressions":3,"./crc32":4,"./reader/readerFor":22,"./support":30,"./utf8":31,"./utils":32}],35:[function(o,i,n){function s(b,m,g){this.name=b,this.dir=g.dir,this.date=g.date,this.comment=g.comment,this.unixPermissions=g.unixPermissions,this.dosPermissions=g.dosPermissions,this._data=m,this._dataBinary=g.binary,this.options={compression:g.compression,compressionOptions:g.compressionOptions}}var l=o("./stream/StreamHelper"),r=o("./stream/DataWorker"),a=o("./utf8"),c=o("./compressedObject"),u=o("./stream/GenericWorker");s.prototype={internalStream:function(b){var m=null,g="string";try{if(!b)throw new Error("No output type specified.");var y=(g=b.toLowerCase())==="string"||g==="text";g!=="binarystring"&&g!=="text"||(g="string"),m=this._decompressWorker();var k=!this._dataBinary;k&&!y&&(m=m.pipe(new a.Utf8EncodeWorker)),!k&&y&&(m=m.pipe(new a.Utf8DecodeWorker))}catch(x){(m=new u("error")).error(x)}return new l(m,g,"")},async:function(b,m){return this.internalStream(b).accumulate(m)},nodeStream:function(b,m){return this.internalStream(b||"nodebuffer").toNodejsStream(m)},_compressWorker:function(b,m){if(this._data instanceof c&&this._data.compression.magic===b.magic)return this._data.getCompressedWorker();var g=this._decompressWorker();return this._dataBinary||(g=g.pipe(new a.Utf8EncodeWorker)),c.createWorkerFrom(g,b,m)},_decompressWorker:function(){return this._data instanceof c?this._data.getContentWorker():this._data instanceof u?this._data:new r(this._data)}};for(var f=["asText","asBinary","asNodeBuffer","asUint8Array","asArrayBuffer"],p=function(){throw new Error("This method has been removed in JSZip 3.0, please check the upgrade guide.")},d=0;d<f.length;d++)s.prototype[f[d]]=p;i.exports=s},{"./compressedObject":2,"./stream/DataWorker":27,"./stream/GenericWorker":28,"./stream/StreamHelper":29,"./utf8":31}],36:[function(o,i,n){(function(s){var l,r,a=s.MutationObserver||s.WebKitMutationObserver;if(a){var c=0,u=new a(b),f=s.document.createTextNode("");u.observe(f,{characterData:!0}),l=function(){f.data=c=++c%2}}else if(s.setImmediate||s.MessageChannel===void 0)l="document"in s&&"onreadystatechange"in s.document.createElement("script")?function(){var m=s.document.createElement("script");m.onreadystatechange=function(){b(),m.onreadystatechange=null,m.parentNode.removeChild(m),m=null},s.document.documentElement.appendChild(m)}:function(){setTimeout(b,0)};else{var p=new s.MessageChannel;p.port1.onmessage=b,l=function(){p.port2.postMessage(0)}}var d=[];function b(){var m,g;r=!0;for(var y=d.length;y;){for(g=d,d=[],m=-1;++m<y;)g[m]();y=d.length}r=!1}i.exports=function(m){d.push(m)!==1||r||l()}}).call(this,typeof mn<"u"?mn:typeof self<"u"?self:typeof window<"u"?window:{})},{}],37:[function(o,i,n){var s=o("immediate");function l(){}var r={},a=["REJECTED"],c=["FULFILLED"],u=["PENDING"];function f(y){if(typeof y!="function")throw new TypeError("resolver must be a function");this.state=u,this.queue=[],this.outcome=void 0,y!==l&&m(this,y)}function p(y,k,x){this.promise=y,typeof k=="function"&&(this.onFulfilled=k,this.callFulfilled=this.otherCallFulfilled),typeof x=="function"&&(this.onRejected=x,this.callRejected=this.otherCallRejected)}function d(y,k,x){s(function(){var $;try{$=k(x)}catch(A){return r.reject(y,A)}$===y?r.reject(y,new TypeError("Cannot resolve promise with itself")):r.resolve(y,$)})}function b(y){var k=y&&y.then;if(y&&(typeof y=="object"||typeof y=="function")&&typeof k=="function")return function(){k.apply(y,arguments)}}function m(y,k){var x=!1;function $(_){x||(x=!0,r.reject(y,_))}function A(_){x||(x=!0,r.resolve(y,_))}var w=g(function(){k(A,$)});w.status==="error"&&$(w.value)}function g(y,k){var x={};try{x.value=y(k),x.status="success"}catch($){x.status="error",x.value=$}return x}(i.exports=f).prototype.finally=function(y){if(typeof y!="function")return this;var k=this.constructor;return this.then(function(x){return k.resolve(y()).then(function(){return x})},function(x){return k.resolve(y()).then(function(){throw x})})},f.prototype.catch=function(y){return this.then(null,y)},f.prototype.then=function(y,k){if(typeof y!="function"&&this.state===c||typeof k!="function"&&this.state===a)return this;var x=new this.constructor(l);return this.state!==u?d(x,this.state===c?y:k,this.outcome):this.queue.push(new p(x,y,k)),x},p.prototype.callFulfilled=function(y){r.resolve(this.promise,y)},p.prototype.otherCallFulfilled=function(y){d(this.promise,this.onFulfilled,y)},p.prototype.callRejected=function(y){r.reject(this.promise,y)},p.prototype.otherCallRejected=function(y){d(this.promise,this.onRejected,y)},r.resolve=function(y,k){var x=g(b,k);if(x.status==="error")return r.reject(y,x.value);var $=x.value;if($)m(y,$);else{y.state=c,y.outcome=k;for(var A=-1,w=y.queue.length;++A<w;)y.queue[A].callFulfilled(k)}return y},r.reject=function(y,k){y.state=a,y.outcome=k;for(var x=-1,$=y.queue.length;++x<$;)y.queue[x].callRejected(k);return y},f.resolve=function(y){return y instanceof this?y:r.resolve(new this(l),y)},f.reject=function(y){var k=new this(l);return r.reject(k,y)},f.all=function(y){var k=this;if(Object.prototype.toString.call(y)!=="[object Array]")return this.reject(new TypeError("must be an array"));var x=y.length,$=!1;if(!x)return this.resolve([]);for(var A=new Array(x),w=0,_=-1,O=new this(l);++_<x;)H(y[_],_);return O;function H(P,F){k.resolve(P).then(function(E){A[F]=E,++w!==x||$||($=!0,r.resolve(O,A))},function(E){$||($=!0,r.reject(O,E))})}},f.race=function(y){var k=this;if(Object.prototype.toString.call(y)!=="[object Array]")return this.reject(new TypeError("must be an array"));var x=y.length,$=!1;if(!x)return this.resolve([]);for(var A=-1,w=new this(l);++A<x;)_=y[A],k.resolve(_).then(function(O){$||($=!0,r.resolve(w,O))},function(O){$||($=!0,r.reject(w,O))});var _;return w}},{immediate:36}],38:[function(o,i,n){var s={};(0,o("./lib/utils/common").assign)(s,o("./lib/deflate"),o("./lib/inflate"),o("./lib/zlib/constants")),i.exports=s},{"./lib/deflate":39,"./lib/inflate":40,"./lib/utils/common":41,"./lib/zlib/constants":44}],39:[function(o,i,n){var s=o("./zlib/deflate"),l=o("./utils/common"),r=o("./utils/strings"),a=o("./zlib/messages"),c=o("./zlib/zstream"),u=Object.prototype.toString,f=0,p=-1,d=0,b=8;function m(y){if(!(this instanceof m))return new m(y);this.options=l.assign({level:p,method:b,chunkSize:16384,windowBits:15,memLevel:8,strategy:d,to:""},y||{});var k=this.options;k.raw&&0<k.windowBits?k.windowBits=-k.windowBits:k.gzip&&0<k.windowBits&&k.windowBits<16&&(k.windowBits+=16),this.err=0,this.msg="",this.ended=!1,this.chunks=[],this.strm=new c,this.strm.avail_out=0;var x=s.deflateInit2(this.strm,k.level,k.method,k.windowBits,k.memLevel,k.strategy);if(x!==f)throw new Error(a[x]);if(k.header&&s.deflateSetHeader(this.strm,k.header),k.dictionary){var $;if($=typeof k.dictionary=="string"?r.string2buf(k.dictionary):u.call(k.dictionary)==="[object ArrayBuffer]"?new Uint8Array(k.dictionary):k.dictionary,(x=s.deflateSetDictionary(this.strm,$))!==f)throw new Error(a[x]);this._dict_set=!0}}function g(y,k){var x=new m(k);if(x.push(y,!0),x.err)throw x.msg||a[x.err];return x.result}m.prototype.push=function(y,k){var x,$,A=this.strm,w=this.options.chunkSize;if(this.ended)return!1;$=k===~~k?k:k===!0?4:0,typeof y=="string"?A.input=r.string2buf(y):u.call(y)==="[object ArrayBuffer]"?A.input=new Uint8Array(y):A.input=y,A.next_in=0,A.avail_in=A.input.length;do{if(A.avail_out===0&&(A.output=new l.Buf8(w),A.next_out=0,A.avail_out=w),(x=s.deflate(A,$))!==1&&x!==f)return this.onEnd(x),!(this.ended=!0);A.avail_out!==0&&(A.avail_in!==0||$!==4&&$!==2)||(this.options.to==="string"?this.onData(r.buf2binstring(l.shrinkBuf(A.output,A.next_out))):this.onData(l.shrinkBuf(A.output,A.next_out)))}while((0<A.avail_in||A.avail_out===0)&&x!==1);return $===4?(x=s.deflateEnd(this.strm),this.onEnd(x),this.ended=!0,x===f):$!==2||(this.onEnd(f),!(A.avail_out=0))},m.prototype.onData=function(y){this.chunks.push(y)},m.prototype.onEnd=function(y){y===f&&(this.options.to==="string"?this.result=this.chunks.join(""):this.result=l.flattenChunks(this.chunks)),this.chunks=[],this.err=y,this.msg=this.strm.msg},n.Deflate=m,n.deflate=g,n.deflateRaw=function(y,k){return(k=k||{}).raw=!0,g(y,k)},n.gzip=function(y,k){return(k=k||{}).gzip=!0,g(y,k)}},{"./utils/common":41,"./utils/strings":42,"./zlib/deflate":46,"./zlib/messages":51,"./zlib/zstream":53}],40:[function(o,i,n){var s=o("./zlib/inflate"),l=o("./utils/common"),r=o("./utils/strings"),a=o("./zlib/constants"),c=o("./zlib/messages"),u=o("./zlib/zstream"),f=o("./zlib/gzheader"),p=Object.prototype.toString;function d(m){if(!(this instanceof d))return new d(m);this.options=l.assign({chunkSize:16384,windowBits:0,to:""},m||{});var g=this.options;g.raw&&0<=g.windowBits&&g.windowBits<16&&(g.windowBits=-g.windowBits,g.windowBits===0&&(g.windowBits=-15)),!(0<=g.windowBits&&g.windowBits<16)||m&&m.windowBits||(g.windowBits+=32),15<g.windowBits&&g.windowBits<48&&(15&g.windowBits)==0&&(g.windowBits|=15),this.err=0,this.msg="",this.ended=!1,this.chunks=[],this.strm=new u,this.strm.avail_out=0;var y=s.inflateInit2(this.strm,g.windowBits);if(y!==a.Z_OK)throw new Error(c[y]);this.header=new f,s.inflateGetHeader(this.strm,this.header)}function b(m,g){var y=new d(g);if(y.push(m,!0),y.err)throw y.msg||c[y.err];return y.result}d.prototype.push=function(m,g){var y,k,x,$,A,w,_=this.strm,O=this.options.chunkSize,H=this.options.dictionary,P=!1;if(this.ended)return!1;k=g===~~g?g:g===!0?a.Z_FINISH:a.Z_NO_FLUSH,typeof m=="string"?_.input=r.binstring2buf(m):p.call(m)==="[object ArrayBuffer]"?_.input=new Uint8Array(m):_.input=m,_.next_in=0,_.avail_in=_.input.length;do{if(_.avail_out===0&&(_.output=new l.Buf8(O),_.next_out=0,_.avail_out=O),(y=s.inflate(_,a.Z_NO_FLUSH))===a.Z_NEED_DICT&&H&&(w=typeof H=="string"?r.string2buf(H):p.call(H)==="[object ArrayBuffer]"?new Uint8Array(H):H,y=s.inflateSetDictionary(this.strm,w)),y===a.Z_BUF_ERROR&&P===!0&&(y=a.Z_OK,P=!1),y!==a.Z_STREAM_END&&y!==a.Z_OK)return this.onEnd(y),!(this.ended=!0);_.next_out&&(_.avail_out!==0&&y!==a.Z_STREAM_END&&(_.avail_in!==0||k!==a.Z_FINISH&&k!==a.Z_SYNC_FLUSH)||(this.options.to==="string"?(x=r.utf8border(_.output,_.next_out),$=_.next_out-x,A=r.buf2string(_.output,x),_.next_out=$,_.avail_out=O-$,$&&l.arraySet(_.output,_.output,x,$,0),this.onData(A)):this.onData(l.shrinkBuf(_.output,_.next_out)))),_.avail_in===0&&_.avail_out===0&&(P=!0)}while((0<_.avail_in||_.avail_out===0)&&y!==a.Z_STREAM_END);return y===a.Z_STREAM_END&&(k=a.Z_FINISH),k===a.Z_FINISH?(y=s.inflateEnd(this.strm),this.onEnd(y),this.ended=!0,y===a.Z_OK):k!==a.Z_SYNC_FLUSH||(this.onEnd(a.Z_OK),!(_.avail_out=0))},d.prototype.onData=function(m){this.chunks.push(m)},d.prototype.onEnd=function(m){m===a.Z_OK&&(this.options.to==="string"?this.result=this.chunks.join(""):this.result=l.flattenChunks(this.chunks)),this.chunks=[],this.err=m,this.msg=this.strm.msg},n.Inflate=d,n.inflate=b,n.inflateRaw=function(m,g){return(g=g||{}).raw=!0,b(m,g)},n.ungzip=b},{"./utils/common":41,"./utils/strings":42,"./zlib/constants":44,"./zlib/gzheader":47,"./zlib/inflate":49,"./zlib/messages":51,"./zlib/zstream":53}],41:[function(o,i,n){var s=typeof Uint8Array<"u"&&typeof Uint16Array<"u"&&typeof Int32Array<"u";n.assign=function(a){for(var c=Array.prototype.slice.call(arguments,1);c.length;){var u=c.shift();if(u){if(typeof u!="object")throw new TypeError(u+"must be non-object");for(var f in u)u.hasOwnProperty(f)&&(a[f]=u[f])}}return a},n.shrinkBuf=function(a,c){return a.length===c?a:a.subarray?a.subarray(0,c):(a.length=c,a)};var l={arraySet:function(a,c,u,f,p){if(c.subarray&&a.subarray)a.set(c.subarray(u,u+f),p);else for(var d=0;d<f;d++)a[p+d]=c[u+d]},flattenChunks:function(a){var c,u,f,p,d,b;for(c=f=0,u=a.length;c<u;c++)f+=a[c].length;for(b=new Uint8Array(f),c=p=0,u=a.length;c<u;c++)d=a[c],b.set(d,p),p+=d.length;return b}},r={arraySet:function(a,c,u,f,p){for(var d=0;d<f;d++)a[p+d]=c[u+d]},flattenChunks:function(a){return[].concat.apply([],a)}};n.setTyped=function(a){a?(n.Buf8=Uint8Array,n.Buf16=Uint16Array,n.Buf32=Int32Array,n.assign(n,l)):(n.Buf8=Array,n.Buf16=Array,n.Buf32=Array,n.assign(n,r))},n.setTyped(s)},{}],42:[function(o,i,n){var s=o("./common"),l=!0,r=!0;try{String.fromCharCode.apply(null,[0])}catch{l=!1}try{String.fromCharCode.apply(null,new Uint8Array(1))}catch{r=!1}for(var a=new s.Buf8(256),c=0;c<256;c++)a[c]=252<=c?6:248<=c?5:240<=c?4:224<=c?3:192<=c?2:1;function u(f,p){if(p<65537&&(f.subarray&&r||!f.subarray&&l))return String.fromCharCode.apply(null,s.shrinkBuf(f,p));for(var d="",b=0;b<p;b++)d+=String.fromCharCode(f[b]);return d}a[254]=a[254]=1,n.string2buf=function(f){var p,d,b,m,g,y=f.length,k=0;for(m=0;m<y;m++)(64512&(d=f.charCodeAt(m)))==55296&&m+1<y&&(64512&(b=f.charCodeAt(m+1)))==56320&&(d=65536+(d-55296<<10)+(b-56320),m++),k+=d<128?1:d<2048?2:d<65536?3:4;for(p=new s.Buf8(k),m=g=0;g<k;m++)(64512&(d=f.charCodeAt(m)))==55296&&m+1<y&&(64512&(b=f.charCodeAt(m+1)))==56320&&(d=65536+(d-55296<<10)+(b-56320),m++),d<128?p[g++]=d:(d<2048?p[g++]=192|d>>>6:(d<65536?p[g++]=224|d>>>12:(p[g++]=240|d>>>18,p[g++]=128|d>>>12&63),p[g++]=128|d>>>6&63),p[g++]=128|63&d);return p},n.buf2binstring=function(f){return u(f,f.length)},n.binstring2buf=function(f){for(var p=new s.Buf8(f.length),d=0,b=p.length;d<b;d++)p[d]=f.charCodeAt(d);return p},n.buf2string=function(f,p){var d,b,m,g,y=p||f.length,k=new Array(2*y);for(d=b=0;d<y;)if((m=f[d++])<128)k[b++]=m;else if(4<(g=a[m]))k[b++]=65533,d+=g-1;else{for(m&=g===2?31:g===3?15:7;1<g&&d<y;)m=m<<6|63&f[d++],g--;1<g?k[b++]=65533:m<65536?k[b++]=m:(m-=65536,k[b++]=55296|m>>10&1023,k[b++]=56320|1023&m)}return u(k,b)},n.utf8border=function(f,p){var d;for((p=p||f.length)>f.length&&(p=f.length),d=p-1;0<=d&&(192&f[d])==128;)d--;return d<0||d===0?p:d+a[f[d]]>p?d:p}},{"./common":41}],43:[function(o,i,n){i.exports=function(s,l,r,a){for(var c=65535&s|0,u=s>>>16&65535|0,f=0;r!==0;){for(r-=f=2e3<r?2e3:r;u=u+(c=c+l[a++]|0)|0,--f;);c%=65521,u%=65521}return c|u<<16|0}},{}],44:[function(o,i,n){i.exports={Z_NO_FLUSH:0,Z_PARTIAL_FLUSH:1,Z_SYNC_FLUSH:2,Z_FULL_FLUSH:3,Z_FINISH:4,Z_BLOCK:5,Z_TREES:6,Z_OK:0,Z_STREAM_END:1,Z_NEED_DICT:2,Z_ERRNO:-1,Z_STREAM_ERROR:-2,Z_DATA_ERROR:-3,Z_BUF_ERROR:-5,Z_NO_COMPRESSION:0,Z_BEST_SPEED:1,Z_BEST_COMPRESSION:9,Z_DEFAULT_COMPRESSION:-1,Z_FILTERED:1,Z_HUFFMAN_ONLY:2,Z_RLE:3,Z_FIXED:4,Z_DEFAULT_STRATEGY:0,Z_BINARY:0,Z_TEXT:1,Z_UNKNOWN:2,Z_DEFLATED:8}},{}],45:[function(o,i,n){var s=(function(){for(var l,r=[],a=0;a<256;a++){l=a;for(var c=0;c<8;c++)l=1&l?3988292384^l>>>1:l>>>1;r[a]=l}return r})();i.exports=function(l,r,a,c){var u=s,f=c+a;l^=-1;for(var p=c;p<f;p++)l=l>>>8^u[255&(l^r[p])];return-1^l}},{}],46:[function(o,i,n){var s,l=o("../utils/common"),r=o("./trees"),a=o("./adler32"),c=o("./crc32"),u=o("./messages"),f=0,p=4,d=0,b=-2,m=-1,g=4,y=2,k=8,x=9,$=286,A=30,w=19,_=2*$+1,O=15,H=3,P=258,F=P+H+1,E=42,D=113,S=1,q=2,j=3,C=4;function M(v,W){return v.msg=u[W],W}function B(v){return(v<<1)-(4<v?9:0)}function te(v){for(var W=v.length;0<=--W;)v[W]=0}function V(v){var W=v.state,z=W.pending;z>v.avail_out&&(z=v.avail_out),z!==0&&(l.arraySet(v.output,W.pending_buf,W.pending_out,z,v.next_out),v.next_out+=z,W.pending_out+=z,v.total_out+=z,v.avail_out-=z,W.pending-=z,W.pending===0&&(W.pending_out=0))}function K(v,W){r._tr_flush_block(v,0<=v.block_start?v.block_start:-1,v.strstart-v.block_start,W),v.block_start=v.strstart,V(v.strm)}function ae(v,W){v.pending_buf[v.pending++]=W}function oe(v,W){v.pending_buf[v.pending++]=W>>>8&255,v.pending_buf[v.pending++]=255&W}function re(v,W){var z,I,T=v.max_chain_length,N=v.strstart,Y=v.prev_length,G=v.nice_match,Z=v.strstart>v.w_size-F?v.strstart-(v.w_size-F):0,Q=v.window,ce=v.w_mask,se=v.prev,me=v.strstart+P,Ce=Q[N+Y-1],we=Q[N+Y];v.prev_length>=v.good_match&&(T>>=2),G>v.lookahead&&(G=v.lookahead);do if(Q[(z=W)+Y]===we&&Q[z+Y-1]===Ce&&Q[z]===Q[N]&&Q[++z]===Q[N+1]){N+=2,z++;do;while(Q[++N]===Q[++z]&&Q[++N]===Q[++z]&&Q[++N]===Q[++z]&&Q[++N]===Q[++z]&&Q[++N]===Q[++z]&&Q[++N]===Q[++z]&&Q[++N]===Q[++z]&&Q[++N]===Q[++z]&&N<me);if(I=P-(me-N),N=me-P,Y<I){if(v.match_start=W,G<=(Y=I))break;Ce=Q[N+Y-1],we=Q[N+Y]}}while((W=se[W&ce])>Z&&--T!=0);return Y<=v.lookahead?Y:v.lookahead}function Se(v){var W,z,I,T,N,Y,G,Z,Q,ce,se=v.w_size;do{if(T=v.window_size-v.lookahead-v.strstart,v.strstart>=se+(se-F)){for(l.arraySet(v.window,v.window,se,se,0),v.match_start-=se,v.strstart-=se,v.block_start-=se,W=z=v.hash_size;I=v.head[--W],v.head[W]=se<=I?I-se:0,--z;);for(W=z=se;I=v.prev[--W],v.prev[W]=se<=I?I-se:0,--z;);T+=se}if(v.strm.avail_in===0)break;if(Y=v.strm,G=v.window,Z=v.strstart+v.lookahead,Q=T,ce=void 0,ce=Y.avail_in,Q<ce&&(ce=Q),z=ce===0?0:(Y.avail_in-=ce,l.arraySet(G,Y.input,Y.next_in,ce,Z),Y.state.wrap===1?Y.adler=a(Y.adler,G,ce,Z):Y.state.wrap===2&&(Y.adler=c(Y.adler,G,ce,Z)),Y.next_in+=ce,Y.total_in+=ce,ce),v.lookahead+=z,v.lookahead+v.insert>=H)for(N=v.strstart-v.insert,v.ins_h=v.window[N],v.ins_h=(v.ins_h<<v.hash_shift^v.window[N+1])&v.hash_mask;v.insert&&(v.ins_h=(v.ins_h<<v.hash_shift^v.window[N+H-1])&v.hash_mask,v.prev[N&v.w_mask]=v.head[v.ins_h],v.head[v.ins_h]=N,N++,v.insert--,!(v.lookahead+v.insert<H)););}while(v.lookahead<F&&v.strm.avail_in!==0)}function $e(v,W){for(var z,I;;){if(v.lookahead<F){if(Se(v),v.lookahead<F&&W===f)return S;if(v.lookahead===0)break}if(z=0,v.lookahead>=H&&(v.ins_h=(v.ins_h<<v.hash_shift^v.window[v.strstart+H-1])&v.hash_mask,z=v.prev[v.strstart&v.w_mask]=v.head[v.ins_h],v.head[v.ins_h]=v.strstart),z!==0&&v.strstart-z<=v.w_size-F&&(v.match_length=re(v,z)),v.match_length>=H)if(I=r._tr_tally(v,v.strstart-v.match_start,v.match_length-H),v.lookahead-=v.match_length,v.match_length<=v.max_lazy_match&&v.lookahead>=H){for(v.match_length--;v.strstart++,v.ins_h=(v.ins_h<<v.hash_shift^v.window[v.strstart+H-1])&v.hash_mask,z=v.prev[v.strstart&v.w_mask]=v.head[v.ins_h],v.head[v.ins_h]=v.strstart,--v.match_length!=0;);v.strstart++}else v.strstart+=v.match_length,v.match_length=0,v.ins_h=v.window[v.strstart],v.ins_h=(v.ins_h<<v.hash_shift^v.window[v.strstart+1])&v.hash_mask;else I=r._tr_tally(v,0,v.window[v.strstart]),v.lookahead--,v.strstart++;if(I&&(K(v,!1),v.strm.avail_out===0))return S}return v.insert=v.strstart<H-1?v.strstart:H-1,W===p?(K(v,!0),v.strm.avail_out===0?j:C):v.last_lit&&(K(v,!1),v.strm.avail_out===0)?S:q}function ke(v,W){for(var z,I,T;;){if(v.lookahead<F){if(Se(v),v.lookahead<F&&W===f)return S;if(v.lookahead===0)break}if(z=0,v.lookahead>=H&&(v.ins_h=(v.ins_h<<v.hash_shift^v.window[v.strstart+H-1])&v.hash_mask,z=v.prev[v.strstart&v.w_mask]=v.head[v.ins_h],v.head[v.ins_h]=v.strstart),v.prev_length=v.match_length,v.prev_match=v.match_start,v.match_length=H-1,z!==0&&v.prev_length<v.max_lazy_match&&v.strstart-z<=v.w_size-F&&(v.match_length=re(v,z),v.match_length<=5&&(v.strategy===1||v.match_length===H&&4096<v.strstart-v.match_start)&&(v.match_length=H-1)),v.prev_length>=H&&v.match_length<=v.prev_length){for(T=v.strstart+v.lookahead-H,I=r._tr_tally(v,v.strstart-1-v.prev_match,v.prev_length-H),v.lookahead-=v.prev_length-1,v.prev_length-=2;++v.strstart<=T&&(v.ins_h=(v.ins_h<<v.hash_shift^v.window[v.strstart+H-1])&v.hash_mask,z=v.prev[v.strstart&v.w_mask]=v.head[v.ins_h],v.head[v.ins_h]=v.strstart),--v.prev_length!=0;);if(v.match_available=0,v.match_length=H-1,v.strstart++,I&&(K(v,!1),v.strm.avail_out===0))return S}else if(v.match_available){if((I=r._tr_tally(v,0,v.window[v.strstart-1]))&&K(v,!1),v.strstart++,v.lookahead--,v.strm.avail_out===0)return S}else v.match_available=1,v.strstart++,v.lookahead--}return v.match_available&&(I=r._tr_tally(v,0,v.window[v.strstart-1]),v.match_available=0),v.insert=v.strstart<H-1?v.strstart:H-1,W===p?(K(v,!0),v.strm.avail_out===0?j:C):v.last_lit&&(K(v,!1),v.strm.avail_out===0)?S:q}function _e(v,W,z,I,T){this.good_length=v,this.max_lazy=W,this.nice_length=z,this.max_chain=I,this.func=T}function R(){this.strm=null,this.status=0,this.pending_buf=null,this.pending_buf_size=0,this.pending_out=0,this.pending=0,this.wrap=0,this.gzhead=null,this.gzindex=0,this.method=k,this.last_flush=-1,this.w_size=0,this.w_bits=0,this.w_mask=0,this.window=null,this.window_size=0,this.prev=null,this.head=null,this.ins_h=0,this.hash_size=0,this.hash_bits=0,this.hash_mask=0,this.hash_shift=0,this.block_start=0,this.match_length=0,this.prev_match=0,this.match_available=0,this.strstart=0,this.match_start=0,this.lookahead=0,this.prev_length=0,this.max_chain_length=0,this.max_lazy_match=0,this.level=0,this.strategy=0,this.good_match=0,this.nice_match=0,this.dyn_ltree=new l.Buf16(2*_),this.dyn_dtree=new l.Buf16(2*(2*A+1)),this.bl_tree=new l.Buf16(2*(2*w+1)),te(this.dyn_ltree),te(this.dyn_dtree),te(this.bl_tree),this.l_desc=null,this.d_desc=null,this.bl_desc=null,this.bl_count=new l.Buf16(O+1),this.heap=new l.Buf16(2*$+1),te(this.heap),this.heap_len=0,this.heap_max=0,this.depth=new l.Buf16(2*$+1),te(this.depth),this.l_buf=0,this.lit_bufsize=0,this.last_lit=0,this.d_buf=0,this.opt_len=0,this.static_len=0,this.matches=0,this.insert=0,this.bi_buf=0,this.bi_valid=0}function ne(v){var W;return v&&v.state?(v.total_in=v.total_out=0,v.data_type=y,(W=v.state).pending=0,W.pending_out=0,W.wrap<0&&(W.wrap=-W.wrap),W.status=W.wrap?E:D,v.adler=W.wrap===2?0:1,W.last_flush=f,r._tr_init(W),d):M(v,b)}function L(v){var W=ne(v);return W===d&&(function(z){z.window_size=2*z.w_size,te(z.head),z.max_lazy_match=s[z.level].max_lazy,z.good_match=s[z.level].good_length,z.nice_match=s[z.level].nice_length,z.max_chain_length=s[z.level].max_chain,z.strstart=0,z.block_start=0,z.lookahead=0,z.insert=0,z.match_length=z.prev_length=H-1,z.match_available=0,z.ins_h=0})(v.state),W}function U(v,W,z,I,T,N){if(!v)return b;var Y=1;if(W===m&&(W=6),I<0?(Y=0,I=-I):15<I&&(Y=2,I-=16),T<1||x<T||z!==k||I<8||15<I||W<0||9<W||N<0||g<N)return M(v,b);I===8&&(I=9);var G=new R;return(v.state=G).strm=v,G.wrap=Y,G.gzhead=null,G.w_bits=I,G.w_size=1<<G.w_bits,G.w_mask=G.w_size-1,G.hash_bits=T+7,G.hash_size=1<<G.hash_bits,G.hash_mask=G.hash_size-1,G.hash_shift=~~((G.hash_bits+H-1)/H),G.window=new l.Buf8(2*G.w_size),G.head=new l.Buf16(G.hash_size),G.prev=new l.Buf16(G.w_size),G.lit_bufsize=1<<T+6,G.pending_buf_size=4*G.lit_bufsize,G.pending_buf=new l.Buf8(G.pending_buf_size),G.d_buf=1*G.lit_bufsize,G.l_buf=3*G.lit_bufsize,G.level=W,G.strategy=N,G.method=z,L(v)}s=[new _e(0,0,0,0,function(v,W){var z=65535;for(z>v.pending_buf_size-5&&(z=v.pending_buf_size-5);;){if(v.lookahead<=1){if(Se(v),v.lookahead===0&&W===f)return S;if(v.lookahead===0)break}v.strstart+=v.lookahead,v.lookahead=0;var I=v.block_start+z;if((v.strstart===0||v.strstart>=I)&&(v.lookahead=v.strstart-I,v.strstart=I,K(v,!1),v.strm.avail_out===0)||v.strstart-v.block_start>=v.w_size-F&&(K(v,!1),v.strm.avail_out===0))return S}return v.insert=0,W===p?(K(v,!0),v.strm.avail_out===0?j:C):(v.strstart>v.block_start&&(K(v,!1),v.strm.avail_out),S)}),new _e(4,4,8,4,$e),new _e(4,5,16,8,$e),new _e(4,6,32,32,$e),new _e(4,4,16,16,ke),new _e(8,16,32,32,ke),new _e(8,16,128,128,ke),new _e(8,32,128,256,ke),new _e(32,128,258,1024,ke),new _e(32,258,258,4096,ke)],n.deflateInit=function(v,W){return U(v,W,k,15,8,0)},n.deflateInit2=U,n.deflateReset=L,n.deflateResetKeep=ne,n.deflateSetHeader=function(v,W){return v&&v.state?v.state.wrap!==2?b:(v.state.gzhead=W,d):b},n.deflate=function(v,W){var z,I,T,N;if(!v||!v.state||5<W||W<0)return v?M(v,b):b;if(I=v.state,!v.output||!v.input&&v.avail_in!==0||I.status===666&&W!==p)return M(v,v.avail_out===0?-5:b);if(I.strm=v,z=I.last_flush,I.last_flush=W,I.status===E)if(I.wrap===2)v.adler=0,ae(I,31),ae(I,139),ae(I,8),I.gzhead?(ae(I,(I.gzhead.text?1:0)+(I.gzhead.hcrc?2:0)+(I.gzhead.extra?4:0)+(I.gzhead.name?8:0)+(I.gzhead.comment?16:0)),ae(I,255&I.gzhead.time),ae(I,I.gzhead.time>>8&255),ae(I,I.gzhead.time>>16&255),ae(I,I.gzhead.time>>24&255),ae(I,I.level===9?2:2<=I.strategy||I.level<2?4:0),ae(I,255&I.gzhead.os),I.gzhead.extra&&I.gzhead.extra.length&&(ae(I,255&I.gzhead.extra.length),ae(I,I.gzhead.extra.length>>8&255)),I.gzhead.hcrc&&(v.adler=c(v.adler,I.pending_buf,I.pending,0)),I.gzindex=0,I.status=69):(ae(I,0),ae(I,0),ae(I,0),ae(I,0),ae(I,0),ae(I,I.level===9?2:2<=I.strategy||I.level<2?4:0),ae(I,3),I.status=D);else{var Y=k+(I.w_bits-8<<4)<<8;Y|=(2<=I.strategy||I.level<2?0:I.level<6?1:I.level===6?2:3)<<6,I.strstart!==0&&(Y|=32),Y+=31-Y%31,I.status=D,oe(I,Y),I.strstart!==0&&(oe(I,v.adler>>>16),oe(I,65535&v.adler)),v.adler=1}if(I.status===69)if(I.gzhead.extra){for(T=I.pending;I.gzindex<(65535&I.gzhead.extra.length)&&(I.pending!==I.pending_buf_size||(I.gzhead.hcrc&&I.pending>T&&(v.adler=c(v.adler,I.pending_buf,I.pending-T,T)),V(v),T=I.pending,I.pending!==I.pending_buf_size));)ae(I,255&I.gzhead.extra[I.gzindex]),I.gzindex++;I.gzhead.hcrc&&I.pending>T&&(v.adler=c(v.adler,I.pending_buf,I.pending-T,T)),I.gzindex===I.gzhead.extra.length&&(I.gzindex=0,I.status=73)}else I.status=73;if(I.status===73)if(I.gzhead.name){T=I.pending;do{if(I.pending===I.pending_buf_size&&(I.gzhead.hcrc&&I.pending>T&&(v.adler=c(v.adler,I.pending_buf,I.pending-T,T)),V(v),T=I.pending,I.pending===I.pending_buf_size)){N=1;break}N=I.gzindex<I.gzhead.name.length?255&I.gzhead.name.charCodeAt(I.gzindex++):0,ae(I,N)}while(N!==0);I.gzhead.hcrc&&I.pending>T&&(v.adler=c(v.adler,I.pending_buf,I.pending-T,T)),N===0&&(I.gzindex=0,I.status=91)}else I.status=91;if(I.status===91)if(I.gzhead.comment){T=I.pending;do{if(I.pending===I.pending_buf_size&&(I.gzhead.hcrc&&I.pending>T&&(v.adler=c(v.adler,I.pending_buf,I.pending-T,T)),V(v),T=I.pending,I.pending===I.pending_buf_size)){N=1;break}N=I.gzindex<I.gzhead.comment.length?255&I.gzhead.comment.charCodeAt(I.gzindex++):0,ae(I,N)}while(N!==0);I.gzhead.hcrc&&I.pending>T&&(v.adler=c(v.adler,I.pending_buf,I.pending-T,T)),N===0&&(I.status=103)}else I.status=103;if(I.status===103&&(I.gzhead.hcrc?(I.pending+2>I.pending_buf_size&&V(v),I.pending+2<=I.pending_buf_size&&(ae(I,255&v.adler),ae(I,v.adler>>8&255),v.adler=0,I.status=D)):I.status=D),I.pending!==0){if(V(v),v.avail_out===0)return I.last_flush=-1,d}else if(v.avail_in===0&&B(W)<=B(z)&&W!==p)return M(v,-5);if(I.status===666&&v.avail_in!==0)return M(v,-5);if(v.avail_in!==0||I.lookahead!==0||W!==f&&I.status!==666){var G=I.strategy===2?(function(Z,Q){for(var ce;;){if(Z.lookahead===0&&(Se(Z),Z.lookahead===0)){if(Q===f)return S;break}if(Z.match_length=0,ce=r._tr_tally(Z,0,Z.window[Z.strstart]),Z.lookahead--,Z.strstart++,ce&&(K(Z,!1),Z.strm.avail_out===0))return S}return Z.insert=0,Q===p?(K(Z,!0),Z.strm.avail_out===0?j:C):Z.last_lit&&(K(Z,!1),Z.strm.avail_out===0)?S:q})(I,W):I.strategy===3?(function(Z,Q){for(var ce,se,me,Ce,we=Z.window;;){if(Z.lookahead<=P){if(Se(Z),Z.lookahead<=P&&Q===f)return S;if(Z.lookahead===0)break}if(Z.match_length=0,Z.lookahead>=H&&0<Z.strstart&&(se=we[me=Z.strstart-1])===we[++me]&&se===we[++me]&&se===we[++me]){Ce=Z.strstart+P;do;while(se===we[++me]&&se===we[++me]&&se===we[++me]&&se===we[++me]&&se===we[++me]&&se===we[++me]&&se===we[++me]&&se===we[++me]&&me<Ce);Z.match_length=P-(Ce-me),Z.match_length>Z.lookahead&&(Z.match_length=Z.lookahead)}if(Z.match_length>=H?(ce=r._tr_tally(Z,1,Z.match_length-H),Z.lookahead-=Z.match_length,Z.strstart+=Z.match_length,Z.match_length=0):(ce=r._tr_tally(Z,0,Z.window[Z.strstart]),Z.lookahead--,Z.strstart++),ce&&(K(Z,!1),Z.strm.avail_out===0))return S}return Z.insert=0,Q===p?(K(Z,!0),Z.strm.avail_out===0?j:C):Z.last_lit&&(K(Z,!1),Z.strm.avail_out===0)?S:q})(I,W):s[I.level].func(I,W);if(G!==j&&G!==C||(I.status=666),G===S||G===j)return v.avail_out===0&&(I.last_flush=-1),d;if(G===q&&(W===1?r._tr_align(I):W!==5&&(r._tr_stored_block(I,0,0,!1),W===3&&(te(I.head),I.lookahead===0&&(I.strstart=0,I.block_start=0,I.insert=0))),V(v),v.avail_out===0))return I.last_flush=-1,d}return W!==p?d:I.wrap<=0?1:(I.wrap===2?(ae(I,255&v.adler),ae(I,v.adler>>8&255),ae(I,v.adler>>16&255),ae(I,v.adler>>24&255),ae(I,255&v.total_in),ae(I,v.total_in>>8&255),ae(I,v.total_in>>16&255),ae(I,v.total_in>>24&255)):(oe(I,v.adler>>>16),oe(I,65535&v.adler)),V(v),0<I.wrap&&(I.wrap=-I.wrap),I.pending!==0?d:1)},n.deflateEnd=function(v){var W;return v&&v.state?(W=v.state.status)!==E&&W!==69&&W!==73&&W!==91&&W!==103&&W!==D&&W!==666?M(v,b):(v.state=null,W===D?M(v,-3):d):b},n.deflateSetDictionary=function(v,W){var z,I,T,N,Y,G,Z,Q,ce=W.length;if(!v||!v.state||(N=(z=v.state).wrap)===2||N===1&&z.status!==E||z.lookahead)return b;for(N===1&&(v.adler=a(v.adler,W,ce,0)),z.wrap=0,ce>=z.w_size&&(N===0&&(te(z.head),z.strstart=0,z.block_start=0,z.insert=0),Q=new l.Buf8(z.w_size),l.arraySet(Q,W,ce-z.w_size,z.w_size,0),W=Q,ce=z.w_size),Y=v.avail_in,G=v.next_in,Z=v.input,v.avail_in=ce,v.next_in=0,v.input=W,Se(z);z.lookahead>=H;){for(I=z.strstart,T=z.lookahead-(H-1);z.ins_h=(z.ins_h<<z.hash_shift^z.window[I+H-1])&z.hash_mask,z.prev[I&z.w_mask]=z.head[z.ins_h],z.head[z.ins_h]=I,I++,--T;);z.strstart=I,z.lookahead=H-1,Se(z)}return z.strstart+=z.lookahead,z.block_start=z.strstart,z.insert=z.lookahead,z.lookahead=0,z.match_length=z.prev_length=H-1,z.match_available=0,v.next_in=G,v.input=Z,v.avail_in=Y,z.wrap=N,d},n.deflateInfo="pako deflate (from Nodeca project)"},{"../utils/common":41,"./adler32":43,"./crc32":45,"./messages":51,"./trees":52}],47:[function(o,i,n){i.exports=function(){this.text=0,this.time=0,this.xflags=0,this.os=0,this.extra=null,this.extra_len=0,this.name="",this.comment="",this.hcrc=0,this.done=!1}},{}],48:[function(o,i,n){i.exports=function(s,l){var r,a,c,u,f,p,d,b,m,g,y,k,x,$,A,w,_,O,H,P,F,E,D,S,q;r=s.state,a=s.next_in,S=s.input,c=a+(s.avail_in-5),u=s.next_out,q=s.output,f=u-(l-s.avail_out),p=u+(s.avail_out-257),d=r.dmax,b=r.wsize,m=r.whave,g=r.wnext,y=r.window,k=r.hold,x=r.bits,$=r.lencode,A=r.distcode,w=(1<<r.lenbits)-1,_=(1<<r.distbits)-1;e:do{x<15&&(k+=S[a++]<<x,x+=8,k+=S[a++]<<x,x+=8),O=$[k&w];t:for(;;){if(k>>>=H=O>>>24,x-=H,(H=O>>>16&255)===0)q[u++]=65535&O;else{if(!(16&H)){if((64&H)==0){O=$[(65535&O)+(k&(1<<H)-1)];continue t}if(32&H){r.mode=12;break e}s.msg="invalid literal/length code",r.mode=30;break e}P=65535&O,(H&=15)&&(x<H&&(k+=S[a++]<<x,x+=8),P+=k&(1<<H)-1,k>>>=H,x-=H),x<15&&(k+=S[a++]<<x,x+=8,k+=S[a++]<<x,x+=8),O=A[k&_];o:for(;;){if(k>>>=H=O>>>24,x-=H,!(16&(H=O>>>16&255))){if((64&H)==0){O=A[(65535&O)+(k&(1<<H)-1)];continue o}s.msg="invalid distance code",r.mode=30;break e}if(F=65535&O,x<(H&=15)&&(k+=S[a++]<<x,(x+=8)<H&&(k+=S[a++]<<x,x+=8)),d<(F+=k&(1<<H)-1)){s.msg="invalid distance too far back",r.mode=30;break e}if(k>>>=H,x-=H,(H=u-f)<F){if(m<(H=F-H)&&r.sane){s.msg="invalid distance too far back",r.mode=30;break e}if(D=y,(E=0)===g){if(E+=b-H,H<P){for(P-=H;q[u++]=y[E++],--H;);E=u-F,D=q}}else if(g<H){if(E+=b+g-H,(H-=g)<P){for(P-=H;q[u++]=y[E++],--H;);if(E=0,g<P){for(P-=H=g;q[u++]=y[E++],--H;);E=u-F,D=q}}}else if(E+=g-H,H<P){for(P-=H;q[u++]=y[E++],--H;);E=u-F,D=q}for(;2<P;)q[u++]=D[E++],q[u++]=D[E++],q[u++]=D[E++],P-=3;P&&(q[u++]=D[E++],1<P&&(q[u++]=D[E++]))}else{for(E=u-F;q[u++]=q[E++],q[u++]=q[E++],q[u++]=q[E++],2<(P-=3););P&&(q[u++]=q[E++],1<P&&(q[u++]=q[E++]))}break}}break}}while(a<c&&u<p);a-=P=x>>3,k&=(1<<(x-=P<<3))-1,s.next_in=a,s.next_out=u,s.avail_in=a<c?c-a+5:5-(a-c),s.avail_out=u<p?p-u+257:257-(u-p),r.hold=k,r.bits=x}},{}],49:[function(o,i,n){var s=o("../utils/common"),l=o("./adler32"),r=o("./crc32"),a=o("./inffast"),c=o("./inftrees"),u=1,f=2,p=0,d=-2,b=1,m=852,g=592;function y(E){return(E>>>24&255)+(E>>>8&65280)+((65280&E)<<8)+((255&E)<<24)}function k(){this.mode=0,this.last=!1,this.wrap=0,this.havedict=!1,this.flags=0,this.dmax=0,this.check=0,this.total=0,this.head=null,this.wbits=0,this.wsize=0,this.whave=0,this.wnext=0,this.window=null,this.hold=0,this.bits=0,this.length=0,this.offset=0,this.extra=0,this.lencode=null,this.distcode=null,this.lenbits=0,this.distbits=0,this.ncode=0,this.nlen=0,this.ndist=0,this.have=0,this.next=null,this.lens=new s.Buf16(320),this.work=new s.Buf16(288),this.lendyn=null,this.distdyn=null,this.sane=0,this.back=0,this.was=0}function x(E){var D;return E&&E.state?(D=E.state,E.total_in=E.total_out=D.total=0,E.msg="",D.wrap&&(E.adler=1&D.wrap),D.mode=b,D.last=0,D.havedict=0,D.dmax=32768,D.head=null,D.hold=0,D.bits=0,D.lencode=D.lendyn=new s.Buf32(m),D.distcode=D.distdyn=new s.Buf32(g),D.sane=1,D.back=-1,p):d}function $(E){var D;return E&&E.state?((D=E.state).wsize=0,D.whave=0,D.wnext=0,x(E)):d}function A(E,D){var S,q;return E&&E.state?(q=E.state,D<0?(S=0,D=-D):(S=1+(D>>4),D<48&&(D&=15)),D&&(D<8||15<D)?d:(q.window!==null&&q.wbits!==D&&(q.window=null),q.wrap=S,q.wbits=D,$(E))):d}function w(E,D){var S,q;return E?(q=new k,(E.state=q).window=null,(S=A(E,D))!==p&&(E.state=null),S):d}var _,O,H=!0;function P(E){if(H){var D;for(_=new s.Buf32(512),O=new s.Buf32(32),D=0;D<144;)E.lens[D++]=8;for(;D<256;)E.lens[D++]=9;for(;D<280;)E.lens[D++]=7;for(;D<288;)E.lens[D++]=8;for(c(u,E.lens,0,288,_,0,E.work,{bits:9}),D=0;D<32;)E.lens[D++]=5;c(f,E.lens,0,32,O,0,E.work,{bits:5}),H=!1}E.lencode=_,E.lenbits=9,E.distcode=O,E.distbits=5}function F(E,D,S,q){var j,C=E.state;return C.window===null&&(C.wsize=1<<C.wbits,C.wnext=0,C.whave=0,C.window=new s.Buf8(C.wsize)),q>=C.wsize?(s.arraySet(C.window,D,S-C.wsize,C.wsize,0),C.wnext=0,C.whave=C.wsize):(q<(j=C.wsize-C.wnext)&&(j=q),s.arraySet(C.window,D,S-q,j,C.wnext),(q-=j)?(s.arraySet(C.window,D,S-q,q,0),C.wnext=q,C.whave=C.wsize):(C.wnext+=j,C.wnext===C.wsize&&(C.wnext=0),C.whave<C.wsize&&(C.whave+=j))),0}n.inflateReset=$,n.inflateReset2=A,n.inflateResetKeep=x,n.inflateInit=function(E){return w(E,15)},n.inflateInit2=w,n.inflate=function(E,D){var S,q,j,C,M,B,te,V,K,ae,oe,re,Se,$e,ke,_e,R,ne,L,U,v,W,z,I,T=0,N=new s.Buf8(4),Y=[16,17,18,0,8,7,9,6,10,5,11,4,12,3,13,2,14,1,15];if(!E||!E.state||!E.output||!E.input&&E.avail_in!==0)return d;(S=E.state).mode===12&&(S.mode=13),M=E.next_out,j=E.output,te=E.avail_out,C=E.next_in,q=E.input,B=E.avail_in,V=S.hold,K=S.bits,ae=B,oe=te,W=p;e:for(;;)switch(S.mode){case b:if(S.wrap===0){S.mode=13;break}for(;K<16;){if(B===0)break e;B--,V+=q[C++]<<K,K+=8}if(2&S.wrap&&V===35615){N[S.check=0]=255&V,N[1]=V>>>8&255,S.check=r(S.check,N,2,0),K=V=0,S.mode=2;break}if(S.flags=0,S.head&&(S.head.done=!1),!(1&S.wrap)||(((255&V)<<8)+(V>>8))%31){E.msg="incorrect header check",S.mode=30;break}if((15&V)!=8){E.msg="unknown compression method",S.mode=30;break}if(K-=4,v=8+(15&(V>>>=4)),S.wbits===0)S.wbits=v;else if(v>S.wbits){E.msg="invalid window size",S.mode=30;break}S.dmax=1<<v,E.adler=S.check=1,S.mode=512&V?10:12,K=V=0;break;case 2:for(;K<16;){if(B===0)break e;B--,V+=q[C++]<<K,K+=8}if(S.flags=V,(255&S.flags)!=8){E.msg="unknown compression method",S.mode=30;break}if(57344&S.flags){E.msg="unknown header flags set",S.mode=30;break}S.head&&(S.head.text=V>>8&1),512&S.flags&&(N[0]=255&V,N[1]=V>>>8&255,S.check=r(S.check,N,2,0)),K=V=0,S.mode=3;case 3:for(;K<32;){if(B===0)break e;B--,V+=q[C++]<<K,K+=8}S.head&&(S.head.time=V),512&S.flags&&(N[0]=255&V,N[1]=V>>>8&255,N[2]=V>>>16&255,N[3]=V>>>24&255,S.check=r(S.check,N,4,0)),K=V=0,S.mode=4;case 4:for(;K<16;){if(B===0)break e;B--,V+=q[C++]<<K,K+=8}S.head&&(S.head.xflags=255&V,S.head.os=V>>8),512&S.flags&&(N[0]=255&V,N[1]=V>>>8&255,S.check=r(S.check,N,2,0)),K=V=0,S.mode=5;case 5:if(1024&S.flags){for(;K<16;){if(B===0)break e;B--,V+=q[C++]<<K,K+=8}S.length=V,S.head&&(S.head.extra_len=V),512&S.flags&&(N[0]=255&V,N[1]=V>>>8&255,S.check=r(S.check,N,2,0)),K=V=0}else S.head&&(S.head.extra=null);S.mode=6;case 6:if(1024&S.flags&&(B<(re=S.length)&&(re=B),re&&(S.head&&(v=S.head.extra_len-S.length,S.head.extra||(S.head.extra=new Array(S.head.extra_len)),s.arraySet(S.head.extra,q,C,re,v)),512&S.flags&&(S.check=r(S.check,q,re,C)),B-=re,C+=re,S.length-=re),S.length))break e;S.length=0,S.mode=7;case 7:if(2048&S.flags){if(B===0)break e;for(re=0;v=q[C+re++],S.head&&v&&S.length<65536&&(S.head.name+=String.fromCharCode(v)),v&&re<B;);if(512&S.flags&&(S.check=r(S.check,q,re,C)),B-=re,C+=re,v)break e}else S.head&&(S.head.name=null);S.length=0,S.mode=8;case 8:if(4096&S.flags){if(B===0)break e;for(re=0;v=q[C+re++],S.head&&v&&S.length<65536&&(S.head.comment+=String.fromCharCode(v)),v&&re<B;);if(512&S.flags&&(S.check=r(S.check,q,re,C)),B-=re,C+=re,v)break e}else S.head&&(S.head.comment=null);S.mode=9;case 9:if(512&S.flags){for(;K<16;){if(B===0)break e;B--,V+=q[C++]<<K,K+=8}if(V!==(65535&S.check)){E.msg="header crc mismatch",S.mode=30;break}K=V=0}S.head&&(S.head.hcrc=S.flags>>9&1,S.head.done=!0),E.adler=S.check=0,S.mode=12;break;case 10:for(;K<32;){if(B===0)break e;B--,V+=q[C++]<<K,K+=8}E.adler=S.check=y(V),K=V=0,S.mode=11;case 11:if(S.havedict===0)return E.next_out=M,E.avail_out=te,E.next_in=C,E.avail_in=B,S.hold=V,S.bits=K,2;E.adler=S.check=1,S.mode=12;case 12:if(D===5||D===6)break e;case 13:if(S.last){V>>>=7&K,K-=7&K,S.mode=27;break}for(;K<3;){if(B===0)break e;B--,V+=q[C++]<<K,K+=8}switch(S.last=1&V,K-=1,3&(V>>>=1)){case 0:S.mode=14;break;case 1:if(P(S),S.mode=20,D!==6)break;V>>>=2,K-=2;break e;case 2:S.mode=17;break;case 3:E.msg="invalid block type",S.mode=30}V>>>=2,K-=2;break;case 14:for(V>>>=7&K,K-=7&K;K<32;){if(B===0)break e;B--,V+=q[C++]<<K,K+=8}if((65535&V)!=(V>>>16^65535)){E.msg="invalid stored block lengths",S.mode=30;break}if(S.length=65535&V,K=V=0,S.mode=15,D===6)break e;case 15:S.mode=16;case 16:if(re=S.length){if(B<re&&(re=B),te<re&&(re=te),re===0)break e;s.arraySet(j,q,C,re,M),B-=re,C+=re,te-=re,M+=re,S.length-=re;break}S.mode=12;break;case 17:for(;K<14;){if(B===0)break e;B--,V+=q[C++]<<K,K+=8}if(S.nlen=257+(31&V),V>>>=5,K-=5,S.ndist=1+(31&V),V>>>=5,K-=5,S.ncode=4+(15&V),V>>>=4,K-=4,286<S.nlen||30<S.ndist){E.msg="too many length or distance symbols",S.mode=30;break}S.have=0,S.mode=18;case 18:for(;S.have<S.ncode;){for(;K<3;){if(B===0)break e;B--,V+=q[C++]<<K,K+=8}S.lens[Y[S.have++]]=7&V,V>>>=3,K-=3}for(;S.have<19;)S.lens[Y[S.have++]]=0;if(S.lencode=S.lendyn,S.lenbits=7,z={bits:S.lenbits},W=c(0,S.lens,0,19,S.lencode,0,S.work,z),S.lenbits=z.bits,W){E.msg="invalid code lengths set",S.mode=30;break}S.have=0,S.mode=19;case 19:for(;S.have<S.nlen+S.ndist;){for(;_e=(T=S.lencode[V&(1<<S.lenbits)-1])>>>16&255,R=65535&T,!((ke=T>>>24)<=K);){if(B===0)break e;B--,V+=q[C++]<<K,K+=8}if(R<16)V>>>=ke,K-=ke,S.lens[S.have++]=R;else{if(R===16){for(I=ke+2;K<I;){if(B===0)break e;B--,V+=q[C++]<<K,K+=8}if(V>>>=ke,K-=ke,S.have===0){E.msg="invalid bit length repeat",S.mode=30;break}v=S.lens[S.have-1],re=3+(3&V),V>>>=2,K-=2}else if(R===17){for(I=ke+3;K<I;){if(B===0)break e;B--,V+=q[C++]<<K,K+=8}K-=ke,v=0,re=3+(7&(V>>>=ke)),V>>>=3,K-=3}else{for(I=ke+7;K<I;){if(B===0)break e;B--,V+=q[C++]<<K,K+=8}K-=ke,v=0,re=11+(127&(V>>>=ke)),V>>>=7,K-=7}if(S.have+re>S.nlen+S.ndist){E.msg="invalid bit length repeat",S.mode=30;break}for(;re--;)S.lens[S.have++]=v}}if(S.mode===30)break;if(S.lens[256]===0){E.msg="invalid code -- missing end-of-block",S.mode=30;break}if(S.lenbits=9,z={bits:S.lenbits},W=c(u,S.lens,0,S.nlen,S.lencode,0,S.work,z),S.lenbits=z.bits,W){E.msg="invalid literal/lengths set",S.mode=30;break}if(S.distbits=6,S.distcode=S.distdyn,z={bits:S.distbits},W=c(f,S.lens,S.nlen,S.ndist,S.distcode,0,S.work,z),S.distbits=z.bits,W){E.msg="invalid distances set",S.mode=30;break}if(S.mode=20,D===6)break e;case 20:S.mode=21;case 21:if(6<=B&&258<=te){E.next_out=M,E.avail_out=te,E.next_in=C,E.avail_in=B,S.hold=V,S.bits=K,a(E,oe),M=E.next_out,j=E.output,te=E.avail_out,C=E.next_in,q=E.input,B=E.avail_in,V=S.hold,K=S.bits,S.mode===12&&(S.back=-1);break}for(S.back=0;_e=(T=S.lencode[V&(1<<S.lenbits)-1])>>>16&255,R=65535&T,!((ke=T>>>24)<=K);){if(B===0)break e;B--,V+=q[C++]<<K,K+=8}if(_e&&(240&_e)==0){for(ne=ke,L=_e,U=R;_e=(T=S.lencode[U+((V&(1<<ne+L)-1)>>ne)])>>>16&255,R=65535&T,!(ne+(ke=T>>>24)<=K);){if(B===0)break e;B--,V+=q[C++]<<K,K+=8}V>>>=ne,K-=ne,S.back+=ne}if(V>>>=ke,K-=ke,S.back+=ke,S.length=R,_e===0){S.mode=26;break}if(32&_e){S.back=-1,S.mode=12;break}if(64&_e){E.msg="invalid literal/length code",S.mode=30;break}S.extra=15&_e,S.mode=22;case 22:if(S.extra){for(I=S.extra;K<I;){if(B===0)break e;B--,V+=q[C++]<<K,K+=8}S.length+=V&(1<<S.extra)-1,V>>>=S.extra,K-=S.extra,S.back+=S.extra}S.was=S.length,S.mode=23;case 23:for(;_e=(T=S.distcode[V&(1<<S.distbits)-1])>>>16&255,R=65535&T,!((ke=T>>>24)<=K);){if(B===0)break e;B--,V+=q[C++]<<K,K+=8}if((240&_e)==0){for(ne=ke,L=_e,U=R;_e=(T=S.distcode[U+((V&(1<<ne+L)-1)>>ne)])>>>16&255,R=65535&T,!(ne+(ke=T>>>24)<=K);){if(B===0)break e;B--,V+=q[C++]<<K,K+=8}V>>>=ne,K-=ne,S.back+=ne}if(V>>>=ke,K-=ke,S.back+=ke,64&_e){E.msg="invalid distance code",S.mode=30;break}S.offset=R,S.extra=15&_e,S.mode=24;case 24:if(S.extra){for(I=S.extra;K<I;){if(B===0)break e;B--,V+=q[C++]<<K,K+=8}S.offset+=V&(1<<S.extra)-1,V>>>=S.extra,K-=S.extra,S.back+=S.extra}if(S.offset>S.dmax){E.msg="invalid distance too far back",S.mode=30;break}S.mode=25;case 25:if(te===0)break e;if(re=oe-te,S.offset>re){if((re=S.offset-re)>S.whave&&S.sane){E.msg="invalid distance too far back",S.mode=30;break}Se=re>S.wnext?(re-=S.wnext,S.wsize-re):S.wnext-re,re>S.length&&(re=S.length),$e=S.window}else $e=j,Se=M-S.offset,re=S.length;for(te<re&&(re=te),te-=re,S.length-=re;j[M++]=$e[Se++],--re;);S.length===0&&(S.mode=21);break;case 26:if(te===0)break e;j[M++]=S.length,te--,S.mode=21;break;case 27:if(S.wrap){for(;K<32;){if(B===0)break e;B--,V|=q[C++]<<K,K+=8}if(oe-=te,E.total_out+=oe,S.total+=oe,oe&&(E.adler=S.check=S.flags?r(S.check,j,oe,M-oe):l(S.check,j,oe,M-oe)),oe=te,(S.flags?V:y(V))!==S.check){E.msg="incorrect data check",S.mode=30;break}K=V=0}S.mode=28;case 28:if(S.wrap&&S.flags){for(;K<32;){if(B===0)break e;B--,V+=q[C++]<<K,K+=8}if(V!==(4294967295&S.total)){E.msg="incorrect length check",S.mode=30;break}K=V=0}S.mode=29;case 29:W=1;break e;case 30:W=-3;break e;case 31:return-4;case 32:default:return d}return E.next_out=M,E.avail_out=te,E.next_in=C,E.avail_in=B,S.hold=V,S.bits=K,(S.wsize||oe!==E.avail_out&&S.mode<30&&(S.mode<27||D!==4))&&F(E,E.output,E.next_out,oe-E.avail_out)?(S.mode=31,-4):(ae-=E.avail_in,oe-=E.avail_out,E.total_in+=ae,E.total_out+=oe,S.total+=oe,S.wrap&&oe&&(E.adler=S.check=S.flags?r(S.check,j,oe,E.next_out-oe):l(S.check,j,oe,E.next_out-oe)),E.data_type=S.bits+(S.last?64:0)+(S.mode===12?128:0)+(S.mode===20||S.mode===15?256:0),(ae==0&&oe===0||D===4)&&W===p&&(W=-5),W)},n.inflateEnd=function(E){if(!E||!E.state)return d;var D=E.state;return D.window&&(D.window=null),E.state=null,p},n.inflateGetHeader=function(E,D){var S;return E&&E.state?(2&(S=E.state).wrap)==0?d:((S.head=D).done=!1,p):d},n.inflateSetDictionary=function(E,D){var S,q=D.length;return E&&E.state?(S=E.state).wrap!==0&&S.mode!==11?d:S.mode===11&&l(1,D,q,0)!==S.check?-3:F(E,D,q,q)?(S.mode=31,-4):(S.havedict=1,p):d},n.inflateInfo="pako inflate (from Nodeca project)"},{"../utils/common":41,"./adler32":43,"./crc32":45,"./inffast":48,"./inftrees":50}],50:[function(o,i,n){var s=o("../utils/common"),l=[3,4,5,6,7,8,9,10,11,13,15,17,19,23,27,31,35,43,51,59,67,83,99,115,131,163,195,227,258,0,0],r=[16,16,16,16,16,16,16,16,17,17,17,17,18,18,18,18,19,19,19,19,20,20,20,20,21,21,21,21,16,72,78],a=[1,2,3,4,5,7,9,13,17,25,33,49,65,97,129,193,257,385,513,769,1025,1537,2049,3073,4097,6145,8193,12289,16385,24577,0,0],c=[16,16,16,16,17,17,18,18,19,19,20,20,21,21,22,22,23,23,24,24,25,25,26,26,27,27,28,28,29,29,64,64];i.exports=function(u,f,p,d,b,m,g,y){var k,x,$,A,w,_,O,H,P,F=y.bits,E=0,D=0,S=0,q=0,j=0,C=0,M=0,B=0,te=0,V=0,K=null,ae=0,oe=new s.Buf16(16),re=new s.Buf16(16),Se=null,$e=0;for(E=0;E<=15;E++)oe[E]=0;for(D=0;D<d;D++)oe[f[p+D]]++;for(j=F,q=15;1<=q&&oe[q]===0;q--);if(q<j&&(j=q),q===0)return b[m++]=20971520,b[m++]=20971520,y.bits=1,0;for(S=1;S<q&&oe[S]===0;S++);for(j<S&&(j=S),E=B=1;E<=15;E++)if(B<<=1,(B-=oe[E])<0)return-1;if(0<B&&(u===0||q!==1))return-1;for(re[1]=0,E=1;E<15;E++)re[E+1]=re[E]+oe[E];for(D=0;D<d;D++)f[p+D]!==0&&(g[re[f[p+D]]++]=D);if(_=u===0?(K=Se=g,19):u===1?(K=l,ae-=257,Se=r,$e-=257,256):(K=a,Se=c,-1),E=S,w=m,M=D=V=0,$=-1,A=(te=1<<(C=j))-1,u===1&&852<te||u===2&&592<te)return 1;for(;;){for(O=E-M,P=g[D]<_?(H=0,g[D]):g[D]>_?(H=Se[$e+g[D]],K[ae+g[D]]):(H=96,0),k=1<<E-M,S=x=1<<C;b[w+(V>>M)+(x-=k)]=O<<24|H<<16|P|0,x!==0;);for(k=1<<E-1;V&k;)k>>=1;if(k!==0?(V&=k-1,V+=k):V=0,D++,--oe[E]==0){if(E===q)break;E=f[p+g[D]]}if(j<E&&(V&A)!==$){for(M===0&&(M=j),w+=S,B=1<<(C=E-M);C+M<q&&!((B-=oe[C+M])<=0);)C++,B<<=1;if(te+=1<<C,u===1&&852<te||u===2&&592<te)return 1;b[$=V&A]=j<<24|C<<16|w-m|0}}return V!==0&&(b[w+V]=E-M<<24|64<<16|0),y.bits=j,0}},{"../utils/common":41}],51:[function(o,i,n){i.exports={2:"need dictionary",1:"stream end",0:"","-1":"file error","-2":"stream error","-3":"data error","-4":"insufficient memory","-5":"buffer error","-6":"incompatible version"}},{}],52:[function(o,i,n){var s=o("../utils/common"),l=0,r=1;function a(T){for(var N=T.length;0<=--N;)T[N]=0}var c=0,u=29,f=256,p=f+1+u,d=30,b=19,m=2*p+1,g=15,y=16,k=7,x=256,$=16,A=17,w=18,_=[0,0,0,0,0,0,0,0,1,1,1,1,2,2,2,2,3,3,3,3,4,4,4,4,5,5,5,5,0],O=[0,0,0,0,1,1,2,2,3,3,4,4,5,5,6,6,7,7,8,8,9,9,10,10,11,11,12,12,13,13],H=[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,2,3,7],P=[16,17,18,0,8,7,9,6,10,5,11,4,12,3,13,2,14,1,15],F=new Array(2*(p+2));a(F);var E=new Array(2*d);a(E);var D=new Array(512);a(D);var S=new Array(256);a(S);var q=new Array(u);a(q);var j,C,M,B=new Array(d);function te(T,N,Y,G,Z){this.static_tree=T,this.extra_bits=N,this.extra_base=Y,this.elems=G,this.max_length=Z,this.has_stree=T&&T.length}function V(T,N){this.dyn_tree=T,this.max_code=0,this.stat_desc=N}function K(T){return T<256?D[T]:D[256+(T>>>7)]}function ae(T,N){T.pending_buf[T.pending++]=255&N,T.pending_buf[T.pending++]=N>>>8&255}function oe(T,N,Y){T.bi_valid>y-Y?(T.bi_buf|=N<<T.bi_valid&65535,ae(T,T.bi_buf),T.bi_buf=N>>y-T.bi_valid,T.bi_valid+=Y-y):(T.bi_buf|=N<<T.bi_valid&65535,T.bi_valid+=Y)}function re(T,N,Y){oe(T,Y[2*N],Y[2*N+1])}function Se(T,N){for(var Y=0;Y|=1&T,T>>>=1,Y<<=1,0<--N;);return Y>>>1}function $e(T,N,Y){var G,Z,Q=new Array(g+1),ce=0;for(G=1;G<=g;G++)Q[G]=ce=ce+Y[G-1]<<1;for(Z=0;Z<=N;Z++){var se=T[2*Z+1];se!==0&&(T[2*Z]=Se(Q[se]++,se))}}function ke(T){var N;for(N=0;N<p;N++)T.dyn_ltree[2*N]=0;for(N=0;N<d;N++)T.dyn_dtree[2*N]=0;for(N=0;N<b;N++)T.bl_tree[2*N]=0;T.dyn_ltree[2*x]=1,T.opt_len=T.static_len=0,T.last_lit=T.matches=0}function _e(T){8<T.bi_valid?ae(T,T.bi_buf):0<T.bi_valid&&(T.pending_buf[T.pending++]=T.bi_buf),T.bi_buf=0,T.bi_valid=0}function R(T,N,Y,G){var Z=2*N,Q=2*Y;return T[Z]<T[Q]||T[Z]===T[Q]&&G[N]<=G[Y]}function ne(T,N,Y){for(var G=T.heap[Y],Z=Y<<1;Z<=T.heap_len&&(Z<T.heap_len&&R(N,T.heap[Z+1],T.heap[Z],T.depth)&&Z++,!R(N,G,T.heap[Z],T.depth));)T.heap[Y]=T.heap[Z],Y=Z,Z<<=1;T.heap[Y]=G}function L(T,N,Y){var G,Z,Q,ce,se=0;if(T.last_lit!==0)for(;G=T.pending_buf[T.d_buf+2*se]<<8|T.pending_buf[T.d_buf+2*se+1],Z=T.pending_buf[T.l_buf+se],se++,G===0?re(T,Z,N):(re(T,(Q=S[Z])+f+1,N),(ce=_[Q])!==0&&oe(T,Z-=q[Q],ce),re(T,Q=K(--G),Y),(ce=O[Q])!==0&&oe(T,G-=B[Q],ce)),se<T.last_lit;);re(T,x,N)}function U(T,N){var Y,G,Z,Q=N.dyn_tree,ce=N.stat_desc.static_tree,se=N.stat_desc.has_stree,me=N.stat_desc.elems,Ce=-1;for(T.heap_len=0,T.heap_max=m,Y=0;Y<me;Y++)Q[2*Y]!==0?(T.heap[++T.heap_len]=Ce=Y,T.depth[Y]=0):Q[2*Y+1]=0;for(;T.heap_len<2;)Q[2*(Z=T.heap[++T.heap_len]=Ce<2?++Ce:0)]=1,T.depth[Z]=0,T.opt_len--,se&&(T.static_len-=ce[2*Z+1]);for(N.max_code=Ce,Y=T.heap_len>>1;1<=Y;Y--)ne(T,Q,Y);for(Z=me;Y=T.heap[1],T.heap[1]=T.heap[T.heap_len--],ne(T,Q,1),G=T.heap[1],T.heap[--T.heap_max]=Y,T.heap[--T.heap_max]=G,Q[2*Z]=Q[2*Y]+Q[2*G],T.depth[Z]=(T.depth[Y]>=T.depth[G]?T.depth[Y]:T.depth[G])+1,Q[2*Y+1]=Q[2*G+1]=Z,T.heap[1]=Z++,ne(T,Q,1),2<=T.heap_len;);T.heap[--T.heap_max]=T.heap[1],(function(we,De){var He,Ke,rt,Pe,ft,tt,Ge=De.dyn_tree,fe=De.max_code,he=De.stat_desc.static_tree,Qe=De.stat_desc.has_stree,lt=De.stat_desc.extra_bits,It=De.stat_desc.extra_base,at=De.stat_desc.max_length,ao=0;for(Pe=0;Pe<=g;Pe++)we.bl_count[Pe]=0;for(Ge[2*we.heap[we.heap_max]+1]=0,He=we.heap_max+1;He<m;He++)at<(Pe=Ge[2*Ge[2*(Ke=we.heap[He])+1]+1]+1)&&(Pe=at,ao++),Ge[2*Ke+1]=Pe,fe<Ke||(we.bl_count[Pe]++,ft=0,It<=Ke&&(ft=lt[Ke-It]),tt=Ge[2*Ke],we.opt_len+=tt*(Pe+ft),Qe&&(we.static_len+=tt*(he[2*Ke+1]+ft)));if(ao!==0){do{for(Pe=at-1;we.bl_count[Pe]===0;)Pe--;we.bl_count[Pe]--,we.bl_count[Pe+1]+=2,we.bl_count[at]--,ao-=2}while(0<ao);for(Pe=at;Pe!==0;Pe--)for(Ke=we.bl_count[Pe];Ke!==0;)fe<(rt=we.heap[--He])||(Ge[2*rt+1]!==Pe&&(we.opt_len+=(Pe-Ge[2*rt+1])*Ge[2*rt],Ge[2*rt+1]=Pe),Ke--)}})(T,N),$e(Q,Ce,T.bl_count)}function v(T,N,Y){var G,Z,Q=-1,ce=N[1],se=0,me=7,Ce=4;for(ce===0&&(me=138,Ce=3),N[2*(Y+1)+1]=65535,G=0;G<=Y;G++)Z=ce,ce=N[2*(G+1)+1],++se<me&&Z===ce||(se<Ce?T.bl_tree[2*Z]+=se:Z!==0?(Z!==Q&&T.bl_tree[2*Z]++,T.bl_tree[2*$]++):se<=10?T.bl_tree[2*A]++:T.bl_tree[2*w]++,Q=Z,Ce=(se=0)===ce?(me=138,3):Z===ce?(me=6,3):(me=7,4))}function W(T,N,Y){var G,Z,Q=-1,ce=N[1],se=0,me=7,Ce=4;for(ce===0&&(me=138,Ce=3),G=0;G<=Y;G++)if(Z=ce,ce=N[2*(G+1)+1],!(++se<me&&Z===ce)){if(se<Ce)for(;re(T,Z,T.bl_tree),--se!=0;);else Z!==0?(Z!==Q&&(re(T,Z,T.bl_tree),se--),re(T,$,T.bl_tree),oe(T,se-3,2)):se<=10?(re(T,A,T.bl_tree),oe(T,se-3,3)):(re(T,w,T.bl_tree),oe(T,se-11,7));Q=Z,Ce=(se=0)===ce?(me=138,3):Z===ce?(me=6,3):(me=7,4)}}a(B);var z=!1;function I(T,N,Y,G){oe(T,(c<<1)+(G?1:0),3),(function(Z,Q,ce,se){_e(Z),ae(Z,ce),ae(Z,~ce),s.arraySet(Z.pending_buf,Z.window,Q,ce,Z.pending),Z.pending+=ce})(T,N,Y)}n._tr_init=function(T){z||((function(){var N,Y,G,Z,Q,ce=new Array(g+1);for(Z=G=0;Z<u-1;Z++)for(q[Z]=G,N=0;N<1<<_[Z];N++)S[G++]=Z;for(S[G-1]=Z,Z=Q=0;Z<16;Z++)for(B[Z]=Q,N=0;N<1<<O[Z];N++)D[Q++]=Z;for(Q>>=7;Z<d;Z++)for(B[Z]=Q<<7,N=0;N<1<<O[Z]-7;N++)D[256+Q++]=Z;for(Y=0;Y<=g;Y++)ce[Y]=0;for(N=0;N<=143;)F[2*N+1]=8,N++,ce[8]++;for(;N<=255;)F[2*N+1]=9,N++,ce[9]++;for(;N<=279;)F[2*N+1]=7,N++,ce[7]++;for(;N<=287;)F[2*N+1]=8,N++,ce[8]++;for($e(F,p+1,ce),N=0;N<d;N++)E[2*N+1]=5,E[2*N]=Se(N,5);j=new te(F,_,f+1,p,g),C=new te(E,O,0,d,g),M=new te(new Array(0),H,0,b,k)})(),z=!0),T.l_desc=new V(T.dyn_ltree,j),T.d_desc=new V(T.dyn_dtree,C),T.bl_desc=new V(T.bl_tree,M),T.bi_buf=0,T.bi_valid=0,ke(T)},n._tr_stored_block=I,n._tr_flush_block=function(T,N,Y,G){var Z,Q,ce=0;0<T.level?(T.strm.data_type===2&&(T.strm.data_type=(function(se){var me,Ce=4093624447;for(me=0;me<=31;me++,Ce>>>=1)if(1&Ce&&se.dyn_ltree[2*me]!==0)return l;if(se.dyn_ltree[18]!==0||se.dyn_ltree[20]!==0||se.dyn_ltree[26]!==0)return r;for(me=32;me<f;me++)if(se.dyn_ltree[2*me]!==0)return r;return l})(T)),U(T,T.l_desc),U(T,T.d_desc),ce=(function(se){var me;for(v(se,se.dyn_ltree,se.l_desc.max_code),v(se,se.dyn_dtree,se.d_desc.max_code),U(se,se.bl_desc),me=b-1;3<=me&&se.bl_tree[2*P[me]+1]===0;me--);return se.opt_len+=3*(me+1)+5+5+4,me})(T),Z=T.opt_len+3+7>>>3,(Q=T.static_len+3+7>>>3)<=Z&&(Z=Q)):Z=Q=Y+5,Y+4<=Z&&N!==-1?I(T,N,Y,G):T.strategy===4||Q===Z?(oe(T,2+(G?1:0),3),L(T,F,E)):(oe(T,4+(G?1:0),3),(function(se,me,Ce,we){var De;for(oe(se,me-257,5),oe(se,Ce-1,5),oe(se,we-4,4),De=0;De<we;De++)oe(se,se.bl_tree[2*P[De]+1],3);W(se,se.dyn_ltree,me-1),W(se,se.dyn_dtree,Ce-1)})(T,T.l_desc.max_code+1,T.d_desc.max_code+1,ce+1),L(T,T.dyn_ltree,T.dyn_dtree)),ke(T),G&&_e(T)},n._tr_tally=function(T,N,Y){return T.pending_buf[T.d_buf+2*T.last_lit]=N>>>8&255,T.pending_buf[T.d_buf+2*T.last_lit+1]=255&N,T.pending_buf[T.l_buf+T.last_lit]=255&Y,T.last_lit++,N===0?T.dyn_ltree[2*Y]++:(T.matches++,N--,T.dyn_ltree[2*(S[Y]+f+1)]++,T.dyn_dtree[2*K(N)]++),T.last_lit===T.lit_bufsize-1},n._tr_align=function(T){oe(T,2,3),re(T,x,F),(function(N){N.bi_valid===16?(ae(N,N.bi_buf),N.bi_buf=0,N.bi_valid=0):8<=N.bi_valid&&(N.pending_buf[N.pending++]=255&N.bi_buf,N.bi_buf>>=8,N.bi_valid-=8)})(T)}},{"../utils/common":41}],53:[function(o,i,n){i.exports=function(){this.input=null,this.next_in=0,this.avail_in=0,this.total_in=0,this.output=null,this.next_out=0,this.avail_out=0,this.total_out=0,this.msg="",this.state=null,this.data_type=2,this.adler=0}},{}],54:[function(o,i,n){(function(s){(function(l,r){if(!l.setImmediate){var a,c,u,f,p=1,d={},b=!1,m=l.document,g=Object.getPrototypeOf&&Object.getPrototypeOf(l);g=g&&g.setTimeout?g:l,a={}.toString.call(l.process)==="[object process]"?function($){process.nextTick(function(){k($)})}:(function(){if(l.postMessage&&!l.importScripts){var $=!0,A=l.onmessage;return l.onmessage=function(){$=!1},l.postMessage("","*"),l.onmessage=A,$}})()?(f="setImmediate$"+Math.random()+"$",l.addEventListener?l.addEventListener("message",x,!1):l.attachEvent("onmessage",x),function($){l.postMessage(f+$,"*")}):l.MessageChannel?((u=new MessageChannel).port1.onmessage=function($){k($.data)},function($){u.port2.postMessage($)}):m&&"onreadystatechange"in m.createElement("script")?(c=m.documentElement,function($){var A=m.createElement("script");A.onreadystatechange=function(){k($),A.onreadystatechange=null,c.removeChild(A),A=null},c.appendChild(A)}):function($){setTimeout(k,0,$)},g.setImmediate=function($){typeof $!="function"&&($=new Function(""+$));for(var A=new Array(arguments.length-1),w=0;w<A.length;w++)A[w]=arguments[w+1];var _={callback:$,args:A};return d[p]=_,a(p),p++},g.clearImmediate=y}function y($){delete d[$]}function k($){if(b)setTimeout(k,0,$);else{var A=d[$];if(A){b=!0;try{(function(w){var _=w.callback,O=w.args;switch(O.length){case 0:_();break;case 1:_(O[0]);break;case 2:_(O[0],O[1]);break;case 3:_(O[0],O[1],O[2]);break;default:_.apply(r,O)}})(A)}finally{y($),b=!1}}}}function x($){$.source===l&&typeof $.data=="string"&&$.data.indexOf(f)===0&&k(+$.data.slice(f.length))}})(typeof self>"u"?s===void 0?this:s:self)}).call(this,typeof mn<"u"?mn:typeof self<"u"?self:typeof window<"u"?window:{})},{}]},{},[10])(10)})})(Ss)),Ss.exports}var Ag=Tg();const mc=$g(Ag);function gc(e){const t=(e||"").trim();return t?`即现（${t}）`:"即现"}async function yc(e,t){var o,i,n;if(!t)return"";if(typeof document<"u"){const s=document.querySelector(`.protyle-title[data-node-id="${t}"] .protyle-title__input`)||document.querySelector(`.protyle[data-doc-id="${t}"] .protyle-title__input`)||(e.getActiveDocumentId()===t?document.querySelector(".layout__wnd--active .protyle-title__input"):null)||document.querySelector(".protyle-title__input"),l=((s==null?void 0:s.innerText)||(s==null?void 0:s.textContent)||"").trim();if(l)return l}if(e.latestCompiledDoc&&e.latestCompiledDoc.docId===t){const s=(o=e.latestCompiledDoc.slides)==null?void 0:o[0],l=(i=s==null?void 0:s.blocks)==null?void 0:i.find(r=>r.type==="h"||r.type==="NodeHeading");if(l!=null&&l.content)return l.content.trim()}try{const s=await vi(`SELECT content FROM blocks WHERE id = '${t}' AND type = 'd' LIMIT 1`).catch(()=>[]);if(Array.isArray(s)&&s.length>0&&((n=s[0])!=null&&n.content))return String(s[0].content).trim()}catch{}return""}async function Mg(e,t,o){var c,u,f;const i=$2(),n=!!((c=i==null?void 0:i.isPinned)!=null&&c.value),s=String(((u=i==null?void 0:i.pinnedDocId)==null?void 0:u.value)||"");if(n&&s&&o&&o!==s)return;const l=o||(n&&s?s:e.currentDocId||e.getActiveDocumentId());let r=(t||"").trim();!r&&l&&(r=typeof e.fetchDocumentTitle=="function"?await e.fetchDocumentTitle(l):await yc(e,l));const a=gc(r);if(e.previewTab&&typeof e.previewTab.updateTitle=="function"){e.previewTab.updateTitle(a),e.previewTab.headElement&&e.previewTab.headElement.setAttribute("title",a);return}if(typeof document<"u"){const p=Array.from(document.querySelectorAll('.layout-tab-bar .item[data-type="tab-header"]'));for(const d of p){const b=d.querySelector(".item__text"),m=((f=b==null?void 0:b.textContent)==null?void 0:f.trim())||"";if(m.includes("Slidev 演示预览")||m.startsWith("即现")){b&&(b.textContent=a),d.setAttribute("title",a);break}}}}function Oi(e){return(e||"").replace(/[/\\?%*:|"<>]/g,"_").replace(/_+/g,"_").trim().replace(/^_+|_+$/g,"")||"presentation"}async function zo(e,t,o){var n,s;const i=t||(e==null?void 0:e.docId)||"";if(o&&typeof o.fetchDocumentTitle=="function"&&i)try{const l=await o.fetchDocumentTitle(i);if(l&&l.trim())return Oi(l)}catch{}if(typeof document<"u")try{const l=(i?document.querySelector(`.protyle-title[data-node-id="${i}"] .protyle-title__input`):null)||(i?document.querySelector(`.protyle[data-doc-id="${i}"] .protyle-title__input`):null)||document.querySelector(".layout__wnd--active .protyle-title__input")||document.querySelector(".protyle-title__input"),r=((l==null?void 0:l.innerText)||(l==null?void 0:l.textContent)||"").trim();if(r)return Oi(r)}catch{}if((n=e==null?void 0:e.config)!=null&&n.title&&e.config.title.trim()&&e.config.title.trim().toLowerCase()!=="presentation")return Oi(e.config.title);if(e!=null&&e.slides&&e.slides.length>0){const r=(s=e.slides[0].blocks)==null?void 0:s.find(c=>c.type==="h"||c.type==="NodeHeading"),a=((r==null?void 0:r.content)||"").replace(/^#+\s*/,"").trim();if(a)return Oi(a)}return"presentation"}function Eg(e,t){if(typeof document>"u")return!1;const o=URL.createObjectURL(t),i=document.createElement("a");return i.href=o,i.download=e,document.body.appendChild(i),i.click(),document.body.removeChild(i),URL.revokeObjectURL(o),!0}function Bl(e,t){if(typeof document>"u")return!1;const o=document.createElement("a");return o.href=t,o.download=e,document.body.appendChild(o),o.click(),document.body.removeChild(o),!0}async function Bg(e){if(typeof navigator>"u"||!navigator.clipboard||typeof ClipboardItem>"u")return!1;try{const o=await(await fetch(e)).blob();return await navigator.clipboard.write([new ClipboardItem({[o.type||"image/png"]:o})]),!0}catch(t){return console.warn("[image-exporter] 复制图像至剪贴板失败:",t),!1}}async function Zs(e,t){return new Promise(o=>{let i=[],n=null;const s=()=>{n&&(clearTimeout(n),n=null),i.forEach(a=>a()),i=[]};n=setTimeout(()=>{s(),o({success:!1,error:"单页截图超时（沙箱无响应）"})},2e4);const l=e.onCapturePageDone(a=>{s(),o({success:!0,dataUrl:a.dataUrl})});i.push(l);const r=e.onCaptureError(a=>{s(),o({success:!1,error:a})});i.push(r),e.startImageExport({mode:"current",scale:(t==null?void 0:t.scale)||2,format:(t==null?void 0:t.format)||"png"})})}async function bc(e,t){const o=[],i=Oi((t==null?void 0:t.title)||"presentation");return new Promise(n=>{let s=[],l=null;const r=()=>{l&&(clearTimeout(l),l=null),s.forEach(d=>d()),s=[]},a=()=>{l&&clearTimeout(l),l=setTimeout(()=>{r(),n({success:!1,error:"幻灯片逐页导出超时（沙箱无响应）"})},35e3)};a();const c=e.onCaptureProgress(d=>{var b;a(),(b=t==null?void 0:t.onProgress)==null||b.call(t,d.current,d.total,d.pageIndex)});s.push(c);const u=e.onCapturePageDone(d=>{a(),(d.mode==="all"||!d.mode)&&o.push({pageIndex:d.pageIndex,dataUrl:d.dataUrl})});s.push(u);const f=async()=>{r();try{if(o.length===0){n({success:!1,error:"未采集到幻灯片图像数据"});return}const d=new mc,b=(t==null?void 0:t.format)==="jpeg"?"jpg":"png";for(const y of o){const k=String(y.pageIndex).padStart(2,"0"),x=y.dataUrl.split(",")[1];d.file(`slide-${k}.${b}`,x,{base64:!0})}const m=await d.generateAsync({type:"blob",compression:"DEFLATE"}),g=Eg(`${i}.zip`,m);n({success:g,total:o.length})}catch(d){n({success:!1,error:(d==null?void 0:d.message)||String(d)})}};s.push(e.onCaptureComplete(f));const p=e.onCaptureError(d=>{r(),n({success:!1,error:d})});s.push(p),e.startImageExport({mode:"all",scale:(t==null?void 0:t.scale)||2,format:(t==null?void 0:t.format)||"png"})})}async function vc(e,t){if(typeof document>"u")return{success:!1,error:"环境不支持 DOM 沙箱挂载"};const o=document.createElement("iframe");o.style.position="fixed",o.style.left="-9999px",o.style.top="-9999px",o.style.width="1920px",o.style.height="1080px",o.style.opacity="0",o.style.pointerEvents="none",o.src="/plugins/siyuan-live-slides/slides-client/index.html?headless=true",document.body.appendChild(o);const i=new ns;i.attach(o);try{if(await new Promise((n,s)=>{const l=setTimeout(()=>s(new Error("静默后台沙箱加载超时")),12e3);i.onClientReady(()=>{clearTimeout(l),n()})}),i.updateSlides(e.slides,e.config),await new Promise(n=>setTimeout(n,250)),(t==null?void 0:t.mode)==="current"){const n=await Zs(i,t);return{success:n.success,total:1,error:n.error}}else{const n=(t==null?void 0:t.title)||await zo(e,e.docId);return await bc(i,{...t,title:n})}}catch(n){return{success:!1,error:(n==null?void 0:n.message)||String(n)}}finally{i.detach(),o.remove()}}const Lg=1500,Dg=500,Og=4,Ng=new Set(["INPUT","TEXTAREA","SELECT"]);function kc(e){const t=e;return!t||!t.tagName?!1:Ng.has(t.tagName)||t.isContentEditable===!0}function Pg(e){let t="",o=!1,i=null,n=null;function s(){e.onStateChange&&e.onStateChange({display:t,invalid:o})}function l(){i&&(clearTimeout(i),i=null),n&&(clearTimeout(n),n=null)}function r(){l(),t="",o=!1,s()}function a(){i&&clearTimeout(i),i=setTimeout(r,Lg)}function c(){i&&(clearTimeout(i),i=null),o=!0,s(),n&&clearTimeout(n),n=setTimeout(r,Dg)}function u(f){if(e.isEnabled&&!e.isEnabled()||kc(f.target)||f.isComposing||f.ctrlKey||f.metaKey||f.altKey)return!1;if(/^[0-9]$/.test(f.key))return o||t.length>=Og||(t+=f.key,s(),a()),!0;if(f.key==="Enter"){if(!t||o)return!1;const d=parseInt(t,10),b=e.getTotalPages();return!isNaN(d)&&d>=1&&b>0&&d<=b?(r(),e.onJump(d),!0):(c(),!0)}return f.key==="Escape"&&(t||o)?(r(),!0):!1}return{handleKeydown:u,getState:()=>({display:t,invalid:o}),clear:r}}const Rg={class:"spm-slides-tab__toolbar"},zg={class:"spm-slides-tab__nav"},Hg=["disabled"],Fg={class:"spm-page-badge"},jg=["disabled"],Ug=["aria-label"],Wg={class:"spm-slides-tab__tools"},qg={key:3,class:"spm-export-image-dropdown",style:{position:"relative",display:"inline-flex","align-items":"center"}},Vg={key:0,class:"b3-menu b3-menu--context",style:{position:"absolute",top:"calc(100% + 4px)",right:"0","z-index":"100","min-width":"190px","box-shadow":"var(--b3-point-shadow)","border-radius":"4px",background:"var(--b3-theme-surface)"}},Kg=["src"],Gg=zt({__name:"SlidesPreviewTab",setup(e,{expose:t}){const o=Kt("plugin"),i=Kt("sandboxBridge",new ns),n=new eg(i),s=pe(null),l=pe(!1),r=pe(null),a=pe(1),c=pe(1),u=pe(!1),f=pe(!1),p=pe(!1),d=pe("siyuan"),b=pe(""),m=pe(""),g=pe(""),y=pe(!1),k=pe(!1),x=pe(""),$=pe(""),A=pe(!1),w=Pg({getTotalPages:()=>c.value,isEnabled:()=>!f.value,onJump:I=>H(I),onStateChange:I=>{$.value=I.display,A.value=I.invalid}});function _(I){if(I.key==="o"||I.key==="O"){if(f.value||I.isComposing||I.ctrlKey||I.metaKey||I.altKey||kc(I.target))return;I.preventDefault(),O();return}w.handleKeydown(I)&&I.preventDefault()}function O(){var I;i.toggleOverview(),(I=r.value)==null||I.focus()}function H(I){var T;a.value=I,i.navigatePage(I),(T=r.value)==null||T.focus()}const P=pe("/plugins/siyuan-live-slides/slides-client/index.html");let F=null,E=null,D=null,S=null,q=null,j=null,C=null,M=null;ti(()=>{r.value&&i.attach(r.value),F=i.onSlideChanged((I,T)=>{a.value=I,c.value=T}),E=i.onBlockClicked((I,T)=>{a.value=T,n.setActiveBlockId(I),I||qi(),o&&typeof o.handleBlockClickedFromSlide=="function"?o.handleBlockClickedFromSlide(I,T):I&&Ro(I,o==null?void 0:o.app)}),D=i.onOpenInEditor((I,T)=>{a.value=T,n.setActiveBlockId(I),Ro(I,o==null?void 0:o.app)}),S=i.onOpenPeekDrawer(async I=>{const T=Fo();if(I.peekType==="siyuan"&&T.enableWebServeJump){let N=!1;if(M&&M.docId===I.target)N=!0;else if(M&&M.slides&&M.slides.some(Y=>{var G;return(G=Y.blocks)==null?void 0:G.some(Z=>Z.id===I.target)}))N=!1;else try{const Y=await vi(`SELECT id, root_id, type FROM blocks WHERE id = '${I.target}' LIMIT 1`);Y&&Y.length>0&&(N=Y[0].type==="d"||Y[0].id===Y[0].root_id)}catch(Y){console.warn("[SlidesPreviewTab] detect block type failed:",Y)}d.value="web",y.value=!0,m.value=ec(T.webServeUrl,I.target,{focus:!N}),g.value=I.title||`${N?"思源文档":"思源块"}: ${I.target.slice(0,8)}`,f.value=!0,i.freezeKeyboardNav(!0)}else{if(d.value=I.peekType,I.peekType==="siyuan")b.value=I.target,g.value=I.title||`块速览: ${I.target.slice(0,8)}`;else{const N=lc(I.target);if(N.external){$e(I.target);return}y.value=!0,m.value=N.url,g.value=I.title||N.url}f.value=!0,i.freezeKeyboardNav(!0)}}),q=i.onRequestToggleFullscreen(()=>{_e()}),j=i.onOpenPresenter(()=>{R()}),typeof document<"u"&&document.addEventListener("fullscreenchange",ke),C=sc(I=>{M&&i.updateSlides(M.slides,{...M.config,hostThemeMode:I},M.customThemeCss)})}),sn(()=>{C&&(C(),C=null),typeof document<"u"&&document.removeEventListener("fullscreenchange",ke),S&&S(),q&&q(),j&&j(),F&&F(),E&&E(),D&&D(),i.detach(),w.clear(),n.destroy()});function B(){k.value=!k.value,k.value?(x.value=(M==null?void 0:M.docId)||"",o&&typeof o.updatePreviewTabHeader=="function"&&o.updatePreviewTabHeader("",x.value)):(x.value="",oe(),o&&typeof o.updatePreviewTabHeader=="function"&&o.updatePreviewTabHeader())}let te=0;function V(I){if(f.value||Math.abs(I.deltaY)<Math.abs(I.deltaX)||Math.abs(I.deltaY)<15)return;const T=Date.now();T-te<280||(te=T,I.deltaY>0?ae():K())}function K(){if(a.value>1){const I=a.value-1;a.value=I,i.navigatePage(I)}}function ae(){if(a.value<c.value){const I=a.value+1;a.value=I,i.navigatePage(I)}}function oe(){o&&typeof o.compileCurrentDocument=="function"?o.compileCurrentDocument():o!=null&&o.eventBus&&typeof o.eventBus.emit=="function"&&o.eventBus.emit("slides:request-compile")}function re(){f.value=!1,i.freezeKeyboardNav(!1)}function Se(){re()}function $e(I){var G,Z;const T=/^file:/i.test(I),N=T||/^[a-zA-Z]:[\\/]/.test(I),Y=ln("electron");if(N&&typeof((G=Y==null?void 0:Y.shell)==null?void 0:G.openPath)=="function"){Y.shell.openPath(T?rc(I):I),ie.showMessage("本地文件不在思源工作区内，已交由系统默认浏览器打开");return}typeof((Z=Y==null?void 0:Y.shell)==null?void 0:Z.openExternal)=="function"?Y.shell.openExternal(I).catch(()=>{typeof window<"u"&&window.open(I,"_blank")}):typeof window<"u"&&window.open(I,"_blank"),ie.showMessage("该地址无法在速览抽屉内加载，已交由系统默认浏览器打开")}function ke(){typeof document<"u"&&(l.value=!!document.fullscreenElement,i.postMessage("FULLSCREEN_CHANGED",{isFullscreen:l.value}))}function _e(){const I=s.value||r.value;I&&(document.fullscreenElement?document.exitFullscreen().then(()=>{i.postMessage("FULLSCREEN_CHANGED",{isFullscreen:!1})}).catch(()=>{}):I.requestFullscreen().then(()=>{i.postMessage("FULLSCREEN_CHANGED",{isFullscreen:!0})}).catch(()=>{}))}function R(){o&&typeof o.openPresenterTab=="function"&&o.openPresenterTab()}async function ne(){if(!M){ie.showMessage("请先在主编辑区打开幻灯片文档");return}const I=await zo(M,o==null?void 0:o.currentDocId,o);ie.showMessage("正在导出单文件离线 HTML（内联媒体资源中...）",2e3);const T=await fc(M,{title:I});hc(`${I}.html`,T)&&ie.showMessage(`已开始下载单文件离线 HTML 演示包 (${I}.html)`)}function L(){if(!M){ie.showMessage("请先在主编辑区打开幻灯片文档");return}pc(M)&&ie.showMessage("已唤起打印视窗，请在打印选项中选择「另存为 PDF」")}const U=pe(!1);async function v(){if(U.value){ie.showMessage("正在逐页导出幻灯片图片中，请稍候...",2e3);return}if(!M){ie.showMessage("请先在主编辑区打开幻灯片文档");return}U.value=!0;try{ie.showMessage("正在逐页导出幻灯片图片...",2e3);const I=await zo(M,o==null?void 0:o.currentDocId,o),T=await bc(i,{title:I,onProgress:(N,Y)=>{ie.showMessage(`正在导出幻灯片图片 (${N} / ${Y})...`,1500)}});T.success?ie.showMessage(`🎉 成功导出 ${T.total||0} 张高清图片并保存为 ${I}.zip！`,4e3):ie.showMessage(`导出图片失败：${T.error||"未知异常"}`)}finally{U.value=!1}}async function W(){if(!M){ie.showMessage("请先在主编辑区打开幻灯片文档");return}ie.showMessage("正在导出当前幻灯片图片...",1500);const I=await Zs(i);if(I.success&&I.dataUrl){const T=await zo(M,o==null?void 0:o.currentDocId,o),N=a.value||1,G=(c.value||1)>1?`${T}-${N}.png`:`${T}.png`;Bl(G,I.dataUrl),ie.showMessage(`已下载当前页高清图片 (${G})`)}else ie.showMessage(`导出当前页图片失败：${I.error||"未知异常"}`)}async function z(){if(!M){ie.showMessage("请先在主编辑区打开幻灯片文档");return}ie.showMessage("正在复制当前幻灯片截图到剪贴板...",1500);const I=await Zs(i);if(I.success&&I.dataUrl)if(await Bg(I.dataUrl))ie.showMessage(`已成功将第 ${a.value||1} 页幻灯片复制到剪贴板！`);else{const N=await zo(M,o==null?void 0:o.currentDocId,o),Y=a.value||1,Z=(c.value||1)>1?`${N}-${Y}.png`:`${N}.png`;Bl(Z,I.dataUrl),ie.showMessage(`剪贴板权限不可用，已自动下载为 ${Z}`)}else ie.showMessage(`复制失败：${I.error||"未知异常"}`)}return t({updateDocument(I,T){k.value&&x.value&&T&&T!==x.value||(M=I,k.value&&!x.value&&(x.value=I.docId),c.value=I.slides.length,n.setDocId(I.docId),n.updateSlidesIndex(I.slides),i.updateSlides(I.slides,{...I.config,hostThemeMode:Uo()},I.customThemeCss),o&&typeof o.updatePreviewTabHeader=="function"&&o.updatePreviewTabHeader("",I.docId))},navigateToBlock(I){n.onCursorFocusBlock(I)},isPinned:k,pinnedDocId:x}),(I,T)=>(J(),X("div",{class:"spm-slides-preview-tab",onKeydown:_},[h("div",Rg,[h("div",zg,[h("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s",disabled:a.value<=1,"aria-label":"上一页",onClick:K},[le(de,{name:"chevron-left"})],8,Hg),h("span",Fg,ve(a.value)+" / "+ve(c.value||1),1),h("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s",disabled:a.value>=c.value,"aria-label":"下一页",onClick:ae},[le(de,{name:"chevron-right"})],8,jg),h("button",{class:xe(["spm-icon-btn b3-tooltips b3-tooltips__s",{"is-primary":k.value}]),"aria-label":k.value?"已锁定当前文档（点击解除）："+x.value:"点击锁定当前文档（不随主编辑区切换）",onClick:B},[le(de,{name:"pin"}),h("span",null,ve(k.value?"已锁定":"跟随"),1)],10,Ug)]),h("div",Wg,[h("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"缩略图总览 (O)",onClick:O},[le(de,{name:"layout-grid"})]),ue(Ot)("presenterMode")?(J(),X("button",{key:0,class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"双屏演讲者视图 (Presenter Mode ⌥M)",onClick:R},[le(de,{name:"presenter"})])):Ae("",!0),ue(Ot)("exportHtml")?(J(),X("button",{key:1,class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"导出单文件 HTML 演示包",onClick:ne},[le(de,{name:"export-html"})])):Ae("",!0),ue(Ot)("exportPdf")?(J(),X("button",{key:2,class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"导出 16:9 PDF 演示讲义",onClick:L},[le(de,{name:"export-pdf"})])):Ae("",!0),ue(Ot)("exportImage")?(J(),X("div",qg,[h("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"导出幻灯片为图片包 (ZIP)",onClick:v},[le(de,{name:"export-image"})]),h("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s",style:{padding:"2px 2px","margin-left":"-4px"},"aria-label":"更多图片导出选项",onClick:T[0]||(T[0]=io(N=>u.value=!u.value,["stop"]))},[le(de,{name:"chevron-down"})]),u.value?(J(),X("div",Vg,[h("button",{class:"b3-menu__item",onClick:T[1]||(T[1]=N=>{v(),u.value=!1})},[...T[6]||(T[6]=[h("span",{class:"b3-menu__label"},"📦 导出全篇为图片包 (ZIP)",-1)])]),h("button",{class:"b3-menu__item",onClick:T[2]||(T[2]=N=>{W(),u.value=!1})},[...T[7]||(T[7]=[h("span",{class:"b3-menu__label"},"🖼️ 导出当前页为图片 (PNG)",-1)])]),h("button",{class:"b3-menu__item",onClick:T[3]||(T[3]=N=>{z(),u.value=!1})},[...T[8]||(T[8]=[h("span",{class:"b3-menu__label"},"📋 复制当前页至剪贴板",-1)])])])):Ae("",!0)])):Ae("",!0),h("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__s","aria-label":"重新编译并刷新",onClick:oe},[le(de,{name:"refresh"})]),h("button",{class:"spm-icon-btn is-primary spm-btn-fullscreen b3-tooltips b3-tooltips__s","aria-label":"全屏放映",onClick:_e},[le(de,{name:"fullscreen"}),T[9]||(T[9]=h("span",{class:"spm-btn-fullscreen__label"},"全屏放映",-1))])])]),h("div",{ref_key:"fullscreenContainerRef",ref:s,class:"spm-slides-tab__viewport spm-slides-fullscreen-container",onWheel:V},[h("iframe",{ref_key:"sandboxIframeRef",ref:r,class:"spm-slides-tab__iframe",src:P.value,frameborder:"0",allow:"fullscreen; autoplay"},null,8,Kg),le(am,{visible:f.value,"onUpdate:visible":T[4]||(T[4]=N=>f.value=N),"is-maximized":p.value,"onUpdate:isMaximized":T[5]||(T[5]=N=>p.value=N),title:g.value,onClose:re},{default:Sa(()=>[d.value==="siyuan"&&b.value?(J(),qt(wm,{key:0,"block-id":b.value,title:g.value,plugin:ue(o),onExternalJump:Se},null,8,["block-id","title","plugin"])):Ae("",!0),y.value?Ut((J(),qt(Xm,{key:1,visible:f.value&&d.value==="web",url:m.value,title:g.value,onExternalJump:Se},null,8,["visible","url","title"])),[[Us,d.value==="web"]]):Ae("",!0)]),_:1},8,["visible","is-maximized","title"]),Ut(h("div",{class:xe(["spm-jump-badge",{"is-invalid":A.value}])},ve($.value),3),[[Us,$.value]])],544)],32))}}),Yg=lo(Gg,[["__scopeId","data-v-7d559c8a"]]);function wc(e){if(!e||e.length===0)return{maxStep:0,blockMap:new Map,idMap:new Map};const t=new Map,o=new Map,i=new Map;let n=0;const s=(r,a)=>{t.set(r,a);const c=r.id||r.blockId;c&&o.set(c,a)},l=e.filter(r=>r.slot!=="slot-divider-right");for(const r of l){if(r.parentContainerId&&r.parentClicks&&r.parentClicks.trim()!==""&&!i.has(r.parentContainerId)){const f=String(r.parentClicks).trim();if(/^\d+$/.test(f)){const p=parseInt(f,10);n=Math.max(n,p),i.set(r.parentContainerId,p)}else n+=1,i.set(r.parentContainerId,n)}if(!!!(r.clicks&&String(r.clicks).trim()!=="")){if(r.parentContainerId&&i.has(r.parentContainerId)){const f=i.get(r.parentContainerId);s(r,{type:"step",step:f})}else s(r,{type:"always"});continue}const c=String(r.clicks).trim();if(!c){n+=1,s(r,{type:"step",step:n});continue}if(c.startsWith("[")&&c.endsWith("]"))try{const f=JSON.parse(c);if(Array.isArray(f)&&f.length>=2){const p=Math.min(Number(f[0]),Number(f[1])),d=Math.max(Number(f[0]),Number(f[1]));if(!isNaN(p)&&!isNaN(d)){n=Math.max(n,d),s(r,{type:"range",min:p,max:d});continue}}}catch{}if(c.toLowerCase()==="hide"){n+=1,s(r,{type:"hide",step:n});continue}if(/^\+\d+$/.test(c)||c==="true"){const f=c==="true"?1:parseInt(c.slice(1),10)||1;n+=f,s(r,{type:"step",step:n});continue}if(/^-\d+$/.test(c)){const f=parseInt(c.slice(1),10)||1;n=Math.max(1,n-f),s(r,{type:"step",step:n});continue}if(/^\d+$/.test(c)){const f=parseInt(c,10);if(!isNaN(f)){n=Math.max(n,f),s(r,{type:"step",step:f});continue}}const u=parseInt(c,10);!isNaN(u)&&u>0?(n=Math.max(n,u),s(r,{type:"step",step:u})):(n+=1,s(r,{type:"step",step:n}))}return{maxStep:n,blockMap:t,idMap:o}}function Zg(e,t,o){if(!e)return"v-click-visible";const i=e.id||e.blockId,n=o.blockMap.get(e)||(i?o.idMap.get(i):null);return!n||n.type==="always"?"v-click-visible":n.type==="range"?t>=n.min&&t<=n.max?"v-click-visible":"v-click-hidden":n.type==="hide"?t<n.step?"v-click-visible":"v-click-hidden":n.type==="step"?t>=n.step?"v-click-visible":"v-click-hidden":"v-click-visible"}const Js=980;function Jg(e){if(!e)return 0;const o=wc(e.blocks||[]).maxStep||0,i=e.frontmatter||{},n=i.mask;if(n!=="down"&&n!=="right")return o;const s=Nd(i.maskRatio),r=i.maskInitial==="revealed"?Math.max(0,s.steps-1):s.steps;return Math.max(o,r)}function Xg(e,t=Js){const o=(e||"16/9").trim();let i=16/9;if(o==="4/3"||o==="4:3")i=4/3;else if(o==="16/10"||o==="16:10")i=16/10;else if(o.includes("/")||o.includes(":")){const s=o.includes("/")?"/":":",l=o.split(s).map(r=>parseFloat(r.trim()));l.length===2&&l[0]>0&&l[1]>0&&!isNaN(l[0])&&!isNaN(l[1])&&(i=l[0]/l[1])}else{const s=parseFloat(o);!isNaN(s)&&s>.2&&s<5&&(i=s)}const n=Math.ceil(t/i);return{baseWidth:t,baseHeight:n,ratio:i}}function Ll(e,t,o=Js,i=552,n=16){const s=o>0?o:Js,l=i>0?i:552,r=Math.max(0,e-n),a=Math.max(0,t-n);if(r<=0||a<=0)return{scale:.36,boxWidth:Math.round(s*.36),boxHeight:Math.round(l*.36)};const c=Math.min(r/s,a/l),u=Math.max(.08,Math.min(1.5,Number(c.toFixed(4))));return{scale:u,boxWidth:Math.max(1,Math.round(s*u)),boxHeight:Math.max(1,Math.round(l*u))}}function Qg(e){return{...e,frontmatter:{...e.frontmatter||{}},blocks:Array.isArray(e.blocks)?e.blocks.map(t=>({...t,attrs:t.attrs?{...t.attrs}:void 0,attributes:t.attributes?{...t.attributes}:void 0,motion:t.motion?{...t.motion}:void 0,children:Array.isArray(t.children)?t.children.map(o=>({...o,attrs:o.attrs?{...o.attrs}:void 0,attributes:o.attributes?{...o.attributes}:void 0})):void 0})):[]}}function Dl(e,t){if(!e)return"";const o=Qg(e),i=o.frontmatter||{},n=i.layout||"default",s=(t==null?void 0:t.config)||{};(n==="image-right"||n==="image-left")&&!i.image&&!i.background&&s.image&&(i.image=s.image);const l=typeof(t==null?void 0:t.currentStep)=="number",r=l?Math.max(0,t.currentStep):0,a=l?wc(o.blocks||[]):null,u=uc(o,{containerClassName:"slide-block",leftColClass:"pdf-col pdf-col--left two-cols-left",rightColClass:"pdf-col pdf-col--right two-cols-right",allSlides:(t==null?void 0:t.allSlides)||[],currentPageIndex:(t==null?void 0:t.pageIndex)||o.pageIndex||1,highlight:!0,blockClassResolver:a?x=>{if(Zg(x,r,a)==="v-click-hidden")return"presenter-v-click-pending";if(r>0){const A=x.id||x.blockId,w=a.blockMap.get(x)||(A?a.idMap.get(A):void 0);if((w==null?void 0:w.type)==="step"&&w.step===r||(w==null?void 0:w.type)==="range"&&w.min===r)return"presenter-v-click-active"}return""}:void 0}).replace(/<video\b([^>]*)>/gi,(x,$)=>{let A=$.replace(/\bcontrols\b/gi,"").trim();return/\bmuted\b/i.test(A)||(A+=" muted"),`<video ${A.trim()}>`}),f=i.spacing,p=f&&f!=="inherit"?f:s.spacing||"normal",d=["slide-content",`layout-${n}`,`spacing-${p}`,i.class||"",i.layoutClass||""].filter(Boolean).join(" "),b=[],m=(i.background||s.background||"").trim();if(m)if(/^(?:https?:\/\/|\/|data:|assets\/|\.\/assets\/)/i.test(m)){const x=m.startsWith("assets/")?`/${m}`:m.startsWith("./assets/")?m.slice(1):m;b.push(`background-image:url('${st(x)}');background-size:cover;background-position:center;background-repeat:no-repeat;`)}else b.push(`background:${st(m)};`);const g=typeof i.zoom=="number"?i.zoom:typeof i.zoom=="string"?parseFloat(i.zoom):1,y=!isNaN(g)&&g>0?g:1;y!==1&&b.push(`width:${(100/y).toFixed(2)}%;height:${(100/y).toFixed(2)}%;transform-origin:top left;transform:scale(${y});`);const k=b.length>0?` style="${b.join("")}"`:"";return`<div class="${st(d)}"${k}>${u}</div>`}const ey={class:"presenter-header"},ty={class:"presenter-title-area"},oy={class:"presenter-brand"},iy={class:"header-pills"},ny={class:"pill pill-page"},sy={key:0,class:"pill pill-step"},ry={class:"header-toolbar"},ly={class:"timer-capsule"},ay={class:"timer-digits"},cy={class:"timer-actions"},dy=["aria-label"],uy={class:"wall-clock b3-tooltips b3-tooltips__sw","aria-label":"系统当前时间"},fy={key:0,class:"presenter-grid"},hy={class:"slide-panels"},py={class:"panel-box current-slide-panel"},my={class:"panel-header"},gy={class:"panel-header-left"},yy={class:"panel-page-num"},by={class:"panel-header-meta"},vy={key:0,class:"panel-step-pill"},ky={class:"panel-layout-pill"},wy=["aria-label"],xy=["data-theme","data-slides-theme","data-normalize-headings","data-hide-unordered-markers","data-hide-ordered-markers","innerHTML"],Sy={key:1,class:"panel-fallback"},_y=["aria-label"],Cy={class:"panel-header"},Iy={class:"panel-header-left"},$y={key:0,class:"panel-page-num"},Ty={class:"panel-header-meta"},Ay={key:0,class:"panel-end-pill"},My={key:1,class:"panel-layout-pill"},Ey=["aria-label"],By=["data-theme","data-slides-theme","data-normalize-headings","data-hide-unordered-markers","data-hide-ordered-markers","innerHTML"],Ly={key:1,class:"panel-fallback"},Dy={class:"notes-panel"},Oy={class:"panel-header"},Ny={class:"panel-header-left"},Py={class:"notes-size-controls"},Ry=["disabled"],zy={class:"notes-size-value"},Hy=["disabled"],Fy={key:1,class:"presenter-empty"},jy={class:"empty-icon-wrap"},Uy={class:"empty-actions"},Wy={class:"presenter-actions"},qy={class:"nav-btn-group"},Vy=["disabled"],Ky=["disabled"],Gy={class:"actions-center"},Yy={class:"center-meta"},Zy={class:"progress-pill"},Jy={class:"nav-btn-group"},Xy=["aria-label"],Qy={class:"step-dots-text"},eb=["disabled"],tb=["disabled"],ob=280,ib=15,nb=zt({__name:"SlidesPresenterTab",setup(e,{expose:t}){const o=Kt("plugin"),i=Kt("sandboxBridge",new ns),n=pe([]),s=pe({}),l=pe(1),r=pe(0),a=pe(0),c=pe(0),u=ye(()=>n.value.length||a.value),f=pe(null),p=pe(null),d=pe({width:0,height:0}),b=pe({width:0,height:0}),m=pe(Uo()),g=ye(()=>{var fe;return Xg((fe=s.value)==null?void 0:fe.aspectRatio)}),y=ye(()=>{var fe;return((fe=s.value)==null?void 0:fe.theme)||"apple-basic"}),k=ye(()=>{var fe;return Cr((fe=s.value)==null?void 0:fe.colorSchema,m.value)}),x=ye(()=>{var fe;return!!((fe=s.value)!=null&&fe.normalizeHeadingSizes)}),$=ye(()=>{var fe;return((fe=s.value)==null?void 0:fe.showUnorderedListMarkers)===!1}),A=ye(()=>{var fe;return((fe=s.value)==null?void 0:fe.showOrderedListMarkers)===!1}),w=ye(()=>Ll(d.value.width,d.value.height,g.value.baseWidth,g.value.baseHeight,14)),_=ye(()=>Ll(b.value.width,b.value.height,g.value.baseWidth,g.value.baseHeight,14));function O(){f.value&&(d.value={width:f.value.clientWidth,height:f.value.clientHeight}),p.value&&(b.value={width:p.value.clientWidth,height:p.value.clientHeight})}let H=null;function P(){typeof window>"u"||typeof window.ResizeObserver!="function"||(H||(H=new window.ResizeObserver(()=>{O()})),H.disconnect(),f.value&&H.observe(f.value),p.value&&H.observe(p.value))}Ho([f,p,u],()=>{Nn(()=>{P(),O()})},{flush:"post"});const F=pe(0),E=pe(!0);let D=null,S=Date.now(),q=0;const j=ye(()=>{const fe=String(Math.floor(F.value/60)).padStart(2,"0"),he=String(F.value%60).padStart(2,"0");return`${fe}:${he}`});function C(){if(E.value){const fe=q+(Date.now()-S);F.value=Math.floor(fe/1e3)}}function M(){E.value?(q+=Date.now()-S,E.value=!1):(S=Date.now(),E.value=!0,C())}function B(){S=Date.now(),q=0,F.value=0}const te=pe("");let V=null;function K(){const fe=new Date,he=String(fe.getHours()).padStart(2,"0"),Qe=String(fe.getMinutes()).padStart(2,"0");te.value=`${he}:${Qe}`}const ae=ye(()=>n.value.length===0?null:n.value[l.value-1]||null),oe=ye(()=>l.value>=n.value.length?null:n.value[l.value]||null);function re(fe){var It;const he=fe==null?void 0:fe.frontmatter;if((he==null?void 0:he.colorSchema)==="light")return"light";if((he==null?void 0:he.colorSchema)==="dark")return"dark";if(typeof(he==null?void 0:he.class)=="string"){const at=he.class.split(/\s+/);if(at.includes("light"))return"light";if(at.includes("dark"))return"dark"}const Qe=(he==null?void 0:he.background)||((It=s.value)==null?void 0:It.background),lt=nc(Qe);return lt===!0?"light":lt===!1?"dark":k.value}const Se=ye(()=>re(ae.value)),$e=ye(()=>re(oe.value)),ke=ye(()=>ae.value?Jg(ae.value):c.value),_e=ye(()=>l.value>1||r.value>0),R=ye(()=>l.value<u.value||r.value<ke.value),ne=ye(()=>Dl(ae.value,{config:s.value,allSlides:n.value,pageIndex:l.value,currentStep:r.value})),L=ye(()=>Dl(oe.value,{config:s.value,allSlides:n.value,pageIndex:l.value+1})),U=ye(()=>{var he;if(!ae.value)return"无内容";const fe=(he=ae.value.blocks)==null?void 0:he[0];return(fe==null?void 0:fe.content)||(fe==null?void 0:fe.rawMarkdown)||`第 ${l.value} 页`});function v(fe){return(fe||[]).slice(1).map(he=>(he.content||he.rawMarkdown||"").trim()).filter(he=>he&&!/^(image\s+)?assets\/\S*$/i.test(he)&&!/^!\[[^\]]*\]\(assets\/[^)]*\)$/.test(he)).join(" | ").slice(0,120)}const W=ye(()=>{var fe;return v((fe=ae.value)==null?void 0:fe.blocks)}),z=ye(()=>{var he;if(!oe.value)return"演示结束";const fe=(he=oe.value.blocks)==null?void 0:he[0];return(fe==null?void 0:fe.content)||(fe==null?void 0:fe.rawMarkdown)||`第 ${l.value+1} 页`}),I=ye(()=>oe.value?v(oe.value.blocks):"这是最后一页"),T=ye(()=>{var fe;return((fe=ae.value)==null?void 0:fe.notes)||""}),N=pe(20);function Y(){N.value<36&&(N.value+=2)}function G(){N.value>14&&(N.value-=2)}const Z=ye(()=>u.value<=1?100:Math.round(l.value/u.value*100));let Q=null;try{Q=new BroadcastChannel("siyuan-slides-sync"),Q.onmessage=fe=>{const he=fe.data;if(he&&(he.type==="SYNC_PAGE"&&typeof he.page=="number"&&(l.value=he.page,r.value=typeof he.step=="number"?Math.max(0,he.step):0,typeof he.maxStep=="number"&&(c.value=Math.max(0,he.maxStep))),he.type==="SYNC_SLIDES"&&Array.isArray(he.slides)&&(n.value=he.slides,he.config&&typeof he.config=="object"&&(s.value=he.config)),he.type==="REQUEST_SYNC"&&n.value.length>0))try{Q==null||Q.postMessage({type:"SYNC_SLIDES",slides:JSON.parse(JSON.stringify(n.value)),config:JSON.parse(JSON.stringify(s.value||{}))}),Q==null||Q.postMessage({type:"SYNC_PAGE",page:l.value,step:r.value,maxStep:ke.value})}catch{}}}catch{Q=null}function ce(fe,he=0){const Qe=Number(fe)||1,lt=Math.max(0,Number(he)||0);i.navigatePage(Qe,lt);try{Q==null||Q.postMessage({type:"SYNC_PAGE",page:Qe,step:lt,maxStep:ke.value})}catch{}}function se(){if(r.value<ke.value){r.value++,ce(l.value,r.value);return}l.value<u.value&&(l.value++,r.value=0,ce(l.value,0))}function me(){if(r.value>0){r.value--,ce(l.value,r.value);return}l.value>1&&(l.value--,r.value=0,ce(l.value,0))}function Ce(){l.value<u.value&&(l.value++,r.value=0,ce(l.value,0))}function we(){l.value>1&&(l.value--,r.value=0,ce(l.value,0))}function De(){l.value=1,r.value=0,B(),ce(1,0)}function He(){const fe=o;typeof(fe==null?void 0:fe.openBottomPreviewTab)=="function"&&fe.openBottomPreviewTab()}function Ke(){const fe=o;typeof(fe==null?void 0:fe.openStandalonePreviewWindow)=="function"&&fe.openStandalonePreviewWindow()}function rt(fe){var he,Qe;if(!(fe.key===" "&&((Qe=(he=fe.target)==null?void 0:he.closest)!=null&&Qe.call(he,"button")))){if(fe.shiftKey&&fe.key==="ArrowRight"||fe.key==="ArrowDown"){fe.preventDefault(),Ce();return}if(fe.shiftKey&&fe.key==="ArrowLeft"||fe.key==="ArrowUp"){fe.preventDefault(),we();return}fe.key==="ArrowRight"||fe.key===" "||fe.key==="PageDown"?(fe.preventDefault(),se()):(fe.key==="ArrowLeft"||fe.key==="PageUp")&&(fe.preventDefault(),me())}}let Pe=0;function ft(fe){var lt,It;if(Math.abs(fe.deltaY)<ib)return;const he=(It=(lt=fe.target)==null?void 0:lt.closest)==null?void 0:It.call(lt,".notes-content");if(he){const at=he.scrollHeight-he.clientHeight;if(at>2&&(fe.deltaY>0&&he.scrollTop<at-1||fe.deltaY<0&&he.scrollTop>1))return}const Qe=Date.now();Qe-Pe<ob||(Pe=Qe,fe.deltaY>0?se():me())}let tt=null,Ge=null;return ti(()=>{var he;m.value=Uo(),Ge=sc(Qe=>{m.value=Qe}),S=Date.now(),q=0,D=window.setInterval(C,500),typeof document<"u"&&document.addEventListener("visibilitychange",C),K(),V=window.setInterval(K,1e3),tt=i.onSlideChanged((Qe,lt,It,at,ao)=>{l.value=Qe,lt>0&&(a.value=lt),typeof at=="number"&&(r.value=Math.max(0,at)),typeof ao=="number"&&(c.value=Math.max(0,ao))});try{Q==null||Q.postMessage({type:"REQUEST_SYNC"})}catch{}const fe=o==null?void 0:o.latestCompiledDoc;(he=fe==null?void 0:fe.slides)!=null&&he.length&&(n.value=fe.slides,fe.config&&(s.value=fe.config)),typeof window<"u"&&window.addEventListener("resize",O),Nn(()=>{P(),O()})}),sn(()=>{Ge&&(Ge(),Ge=null),D&&(window.clearInterval(D),D=null),typeof document<"u"&&document.removeEventListener("visibilitychange",C),V&&(window.clearInterval(V),V=null),tt&&tt(),typeof window<"u"&&window.removeEventListener("resize",O),H&&(H.disconnect(),H=null);try{Q==null||Q.close()}catch{}Q=null}),t({updateDocument(fe){var he;(he=fe==null?void 0:fe.slides)!=null&&he.length&&(n.value=fe.slides),fe!=null&&fe.config&&(s.value=fe.config)}}),(fe,he)=>{var Qe,lt,It;return J(),X("div",{class:"spm-presenter-tab",tabindex:"0",onKeydown:rt,onWheel:ft},[h("header",ey,[h("div",ty,[h("div",oy,[le(de,{name:"presenter",class:"brand-icon"}),he[1]||(he[1]=h("span",{class:"title-name"},"演讲者控制台",-1))]),h("div",iy,[h("span",ny,"P."+ve(l.value)+" / "+ve(u.value||1),1),ke.value>0?(J(),X("span",sy,[le(de,{name:"step",class:"pill-icon"}),St(" 步进 "+ve(r.value)+" / "+ve(ke.value),1)])):Ae("",!0)])]),h("div",ry,[h("button",{class:"btn-tool b3-tooltips b3-tooltips__s","aria-label":"弹出大屏放映独立窗口 (16:9)",onClick:Ke},[le(de,{name:"window"}),he[2]||(he[2]=h("span",{class:"btn-tool-label"},"独立放映",-1))]),h("div",ly,[le(de,{name:"clock",class:"timer-icon"}),h("span",ay,ve(j.value),1),h("div",cy,[h("button",{class:"timer-btn b3-tooltips b3-tooltips__s","aria-label":E.value?"暂停计时":"继续计时",onClick:M},[le(de,{name:E.value?"pause":"play"},null,8,["name"])],8,dy),h("button",{class:"timer-btn b3-tooltips b3-tooltips__s","aria-label":"重置计时",onClick:B},[le(de,{name:"reset"})])])]),h("div",uy,[h("span",null,ve(te.value),1)])])]),u.value>0?(J(),X("main",fy,[h("section",hy,[h("div",py,[h("div",my,[h("div",gy,[he[3]||(he[3]=h("span",{class:"panel-tag is-current"},"当前放映",-1)),h("span",yy,"P."+ve(l.value),1)]),h("div",by,[ke.value>0?(J(),X("span",vy," 步进 "+ve(r.value)+" / "+ve(ke.value),1)):Ae("",!0),h("span",ky,ve(((lt=(Qe=ae.value)==null?void 0:Qe.frontmatter)==null?void 0:lt.layout)||"default"),1)])]),h("div",{ref_key:"currentPreviewRef",ref:f,class:"panel-preview","aria-label":U.value},[ae.value?(J(),X("div",{key:0,class:"presenter-thumb-box",style:oo({width:w.value.boxWidth+"px",height:w.value.boxHeight+"px"})},[h("div",{class:xe(["presenter-thumb-viewport slide-viewport","slides-theme-"+y.value]),"data-theme":Se.value,"data-slides-theme":y.value,"data-normalize-headings":x.value?"true":"false","data-hide-unordered-markers":$.value?"true":"false","data-hide-ordered-markers":A.value?"true":"false",style:oo({width:g.value.baseWidth+"px",height:g.value.baseHeight+"px",transform:"scale("+w.value.scale+")"}),innerHTML:ne.value},null,14,xy)],4)):(J(),X("div",Sy,[h("h2",null,ve(U.value),1),h("p",null,ve(W.value),1)]))],8,wy)]),h("div",{class:xe(["panel-box next-slide-panel",{"is-clickable":!!oe.value,"b3-tooltips b3-tooltips__n":!!oe.value}]),"aria-label":oe.value?"点击直接跳至下一页":"",onClick:he[0]||(he[0]=at=>oe.value&&Ce())},[h("div",Cy,[h("div",Iy,[he[4]||(he[4]=h("span",{class:"panel-tag"},"下一页预告",-1)),l.value<u.value?(J(),X("span",$y,"P."+ve(l.value+1),1)):Ae("",!0)]),h("div",Ty,[l.value>=u.value?(J(),X("span",Ay,"已到尾页")):oe.value?(J(),X("span",My,ve(((It=oe.value.frontmatter)==null?void 0:It.layout)||"default"),1)):Ae("",!0)])]),h("div",{ref_key:"nextPreviewRef",ref:p,class:"panel-preview panel-preview--dim","aria-label":z.value},[oe.value?(J(),X("div",{key:0,class:"presenter-thumb-box",style:oo({width:_.value.boxWidth+"px",height:_.value.boxHeight+"px"})},[h("div",{class:xe(["presenter-thumb-viewport slide-viewport","slides-theme-"+y.value]),"data-theme":$e.value,"data-slides-theme":y.value,"data-normalize-headings":x.value?"true":"false","data-hide-unordered-markers":$.value?"true":"false","data-hide-ordered-markers":A.value?"true":"false",style:oo({width:g.value.baseWidth+"px",height:g.value.baseHeight+"px",transform:"scale("+_.value.scale+")"}),innerHTML:L.value},null,14,By)],4)):(J(),X("div",Ly,[h("h2",null,ve(z.value),1),h("p",null,ve(I.value),1)]))],8,Ey)],10,_y)]),h("section",Dy,[h("div",Oy,[h("div",Ny,[le(de,{name:"notes",class:"panel-title-icon"}),he[5]||(he[5]=h("span",null,"讲稿备忘",-1))]),h("div",Py,[h("button",{class:"notes-btn b3-tooltips b3-tooltips__w","aria-label":"减小字体",disabled:N.value<=14,onClick:G},[le(de,{name:"minus"})],8,Ry),h("span",zy,ve(N.value)+"px",1),h("button",{class:"notes-btn b3-tooltips b3-tooltips__w","aria-label":"增大字体",disabled:N.value>=36,onClick:Y},[le(de,{name:"plus"})],8,Hy)])]),h("div",{class:xe(["notes-content",{"is-empty":!T.value}]),style:oo({fontSize:N.value+"px"})},ve(T.value||"（本页未设置演讲者备忘录）"),7)])])):(J(),X("main",Fy,[h("div",jy,[le(de,{name:"refresh",class:"empty-icon"})]),he[8]||(he[8]=h("h2",null,"等待大屏放映数据",-1)),he[9]||(he[9]=h("p",null,"未检测到活跃的幻灯片数据，请先开启大屏放映端。",-1)),h("div",Uy,[h("button",{class:"btn-empty-action b3-tooltips b3-tooltips__n","aria-label":"在思源中打开底部演示预览页签",onClick:He},[le(de,{name:"presenter"}),he[6]||(he[6]=h("span",null,"打开大屏放映页签",-1))]),h("button",{class:"btn-empty-action btn-empty-action--popout b3-tooltips b3-tooltips__n","aria-label":"将放映端弹出为独立窗口 (16:9)",onClick:Ke},[le(de,{name:"window"}),he[7]||(he[7]=h("span",null,"弹出独立放映窗口",-1))])])])),h("footer",Wy,[h("div",qy,[h("button",{class:"btn-nav btn-nav--slide b3-tooltips b3-tooltips__ne",disabled:l.value<=1,"aria-label":"快速返回上一页 (Shift + ←)",onClick:we},[le(de,{name:"chevrons-left"}),he[10]||(he[10]=h("span",null,"上一页",-1))],8,Vy),h("button",{class:"btn-nav btn-nav--step b3-tooltips b3-tooltips__n",disabled:!_e.value,"aria-label":"回退一步 (←)",onClick:me},[le(de,{name:"chevron-left"}),he[11]||(he[11]=h("span",null,"上一步",-1))],8,Ky)]),h("div",Gy,[h("div",Yy,[h("span",Zy,ve(Z.value)+"%",1)]),h("button",{class:"btn-restart b3-tooltips b3-tooltips__n","aria-label":"从第一页重新放映 (Home)",onClick:De},[le(de,{name:"reset"}),he[12]||(he[12]=h("span",null,"重头放映",-1))])]),h("div",Jy,[ke.value>0?(J(),X("div",{key:0,class:"step-dots-bar b3-tooltips b3-tooltips__n","aria-label":`步进进度: ${r.value} / ${ke.value}`},[(J(!0),X(Je,null,At(ke.value,at=>(J(),X("span",{key:at,class:xe(["step-dot",{"is-active":at<=r.value}])},null,2))),128)),h("span",Qy,ve(r.value)+"/"+ve(ke.value),1)],8,Xy)):Ae("",!0),h("button",{class:"btn-nav btn-nav--step btn-nav--primary b3-tooltips b3-tooltips__n",disabled:!R.value,"aria-label":"触发下一步骤或进入下一页 (Space / →)",onClick:se},[he[13]||(he[13]=h("span",null,"下一步",-1)),le(de,{name:"chevron-right"})],8,eb),h("button",{class:"btn-nav btn-nav--slide b3-tooltips b3-tooltips__nw",disabled:l.value>=u.value,"aria-label":"跳过本页剩余步骤，直接进入下一页 (Shift + →)",onClick:Ce},[he[14]||(he[14]=h("span",null,"下一页",-1)),le(de,{name:"chevrons-right"})],8,tb)])])],32)}}}),sb=lo(nb,[["__scopeId","data-v-bb574b10"]]),rb={class:"spm-layout-picker"},lb={class:"spm-layout-picker__grid"},ab=["title","onClick"],cb={class:"spm-layout-icon"},db={class:"spm-layout-label"},ub=zt({__name:"LayoutPicker",props:{modelValue:{}},emits:["update:modelValue","change"],setup(e,{emit:t}){const o=e,i=t,n=[{name:"cover",label:"封面",desc:"大标题与副标题封面页"},{name:"default",label:"标准",desc:"标题在上方，内容在下方"},{name:"two-cols",label:"双栏",desc:"左右双栏对比展示"},{name:"cols-header",label:"表头多栏",desc:"顶部通栏标题，下方自适应 2~N 栏"},{name:"clover",label:"四叶草",desc:"2x2 田字型四象限卡片布局"},{name:"image-right",label:"图右",desc:"左侧为内容，右侧全屏背景图"},{name:"image-left",label:"图左",desc:"左侧全屏背景图，右侧为内容"},{name:"center",label:"居中",desc:"内容全屏垂直水平居中"},{name:"fact",label:"大字报",desc:"核心数据或指标突出展示"},{name:"intro",label:"介绍",desc:"演讲者自我介绍或章节导览"},{name:"quote",label:"引言",desc:"名人名言与强调段落"}];function s(r){return o.modelValue===r||r==="cols-header"&&(o.modelValue==="two-cols-header"||o.modelValue==="three-cols-header")}function l(r){i("update:modelValue",r),i("change",r)}return(r,a)=>(J(),X("div",rb,[a[0]||(a[0]=h("div",{class:"spm-layout-picker__header"},"选择页面版式",-1)),h("div",lb,[(J(),X(Je,null,At(n,c=>h("div",{key:c.name,class:xe(["spm-layout-item",{active:s(c.name)}]),title:c.desc,onClick:u=>l(c.name)},[h("div",cb,[le(de,{name:"layout-"+c.name},null,8,["name"])]),h("span",db,ve(c.label),1)],10,ab)),64))])]))}}),fb=lo(ub,[["__scopeId","data-v-96c8a248"]]),hb={key:0,class:"spm-transition-selector__header"},pb={class:"spm-transition-list"},mb=["onClick"],gb={class:"spm-transition-meta"},yb={class:"spm-transition-label"},bb={class:"spm-transition-preview-box"},vb=zt({__name:"TransitionSelector",props:{modelValue:{},hideHeader:{type:Boolean},title:{}},emits:["update:modelValue","change"],setup(e,{emit:t}){const o=t,i=[{name:"slide-left",label:"向左滑入",desc:"向左滑入：页面从右侧向左平滑推入，最通用标准的横向幻灯片动效"},{name:"slide-right",label:"向右滑入",desc:"向右滑入：页面从左侧向右平滑推入，适合倒序回退或逆向章节叙述"},{name:"slide-up",label:"向上推入",desc:"向上推入：页面从底部向上平滑推入，适合纵向展开或纵深层级展示"},{name:"fade",label:"淡入淡出",desc:"淡入淡出：透明度平滑渐变过度，典雅柔和，适合学术长篇与沉浸叙事"},{name:"zoom",label:"缩放进入",desc:"缩放进入：页面由中心向外平滑放大，富有动感冲击力，适合聚焦重点"}];function n(s){o("update:modelValue",s),o("change",s)}return(s,l)=>(J(),X("div",{class:xe(["spm-transition-selector",{"spm-transition-selector--no-header":e.hideHeader}])},[e.hideHeader?Ae("",!0):(J(),X("div",hb,ve(e.title||"转场动效"),1)),h("div",pb,[(J(),X(Je,null,At(i,r=>h("div",{key:r.name,class:xe(["spm-transition-item",{active:e.modelValue===r.name}]),onClick:a=>n(r.name)},[h("div",gb,[h("span",yb,ve(r.label),1)]),h("div",bb,[h("div",{class:xe(["spm-anim-cube","anim-"+r.name])},null,2)])],10,mb)),64))])],2))}}),xc=lo(vb,[["__scopeId","data-v-b5051f69"]]),kb={class:"spm-section spm-section--page"},wb={class:"spm-section-header"},xb={key:0,class:"spm-card-control",style:{"border-left":"3px solid var(--b3-theme-primary)",background:"rgba(var(--b3-theme-primary-rgb, 66, 133, 244), 0.06)",padding:"8px 12px","margin-top":"6px"}},Sb={style:{display:"flex","align-items":"center","justify-content":"space-between",gap:"8px"}},_b={style:{"font-size":"11px",display:"flex","align-items":"center",gap:"6px",flex:"1"}},Cb={key:1,class:"spm-card-control"},Ib={class:"spm-control-header"},$b={class:"spm-control-title-group"},Tb={class:"spm-control-title b3-tooltips b3-tooltips__se","aria-label":"设置各列横向空间占比，默认平均分配"},Ab={class:"spm-quick-chips"},Mb=["onClick"],Eb={style:{display:"flex",gap:"6px","align-items":"center","margin-top":"6px"}},Bb=["value"],Lb=["aria-label"],Db={key:1,class:"spm-icon-btn b3-tooltips b3-tooltips__sw",disabled:"",style:{opacity:"0.45",cursor:"not-allowed",padding:"0 8px",height:"26px","font-size":"11px","white-space":"nowrap","flex-shrink":"0"},"aria-label":"当前页未检测到调整过列宽的横向超级块"},Ob={key:0,style:{"margin-top":"6px","font-size":"11px",opacity:"0.85",display:"flex","align-items":"center",gap:"4px"}},Nb={style:{background:"rgba(125, 125, 125, 0.15)",padding:"1px 4px","border-radius":"3px","font-weight":"bold"}},Pb={key:1,style:{"margin-top":"6px","font-size":"11px",opacity:"0.6",display:"flex","align-items":"center",gap:"4px"}},Rb={class:"spm-card-control"},zb={class:"spm-control-header"},Hb={class:"spm-control-title-group"},Fb={class:"spm-control-title b3-tooltips b3-tooltips__se","aria-label":"覆盖本页内衬、内容间隙与正文行距"},jb={class:"spm-segmented-group"},Ub={class:"spm-card-control"},Wb={class:"spm-control-header"},qb={class:"spm-control-title-group"},Vb={class:"spm-control-title b3-tooltips b3-tooltips__se","aria-label":"随着点击操作分段展露正文内容"},Kb={class:"spm-segmented-group"},Gb={key:0,style:{"margin-top":"10px",display:"flex","flex-direction":"column",gap:"8px"}},Yb={style:{display:"flex","align-items":"center","justify-content":"space-between"}},Zb=["aria-label"],Jb={class:"spm-quick-chips"},Xb=["onClick"],Qb=["value"],ev={style:{"font-size":"10.5px",opacity:"0.6","line-height":"1.35","margin-top":"-2px"}},tv={style:{display:"flex",gap:"8px","margin-top":"2px"}},ov={style:{flex:"1"}},iv={class:"spm-segmented-group"},nv={style:{flex:"1"}},sv={class:"spm-segmented-group"},rv={key:2,class:"spm-card-control"},lv={class:"spm-control-header"},av={class:"spm-control-title-group"},cv={class:"spm-control-title b3-tooltips b3-tooltips__se","aria-label":"图文分栏或页面专属配图 URL / 资源路径"},dv={class:"spm-quick-chips"},uv=["onClick"],fv=["value"],hv={class:"spm-card-control"},pv={class:"spm-control-header"},mv={class:"spm-control-title-group"},gv={class:"spm-control-title b3-tooltips b3-tooltips__se","aria-label":"正文备注块驱动 · 仅演讲者视图可见"},yv={key:0,class:"spm-notes-header-actions"},bv=["disabled"],vv={key:0,class:"spm-btn-spinner"},kv={key:0,class:"spm-note-loading-box"},wv={key:1,class:"spm-note-status-box"},xv=["title"],Sv={class:"spm-action-grid",style:{"margin-top":"6px"}},_v={key:2,class:"spm-note-empty-box"},Cv={class:"spm-card-control"},Iv={class:"spm-action-grid"},$v=["disabled","aria-label"],Tv=zt({__name:"PageInspectorSection",props:{pageLayout:{},pageTransition:{},pageSpacing:{},pageImage:{},pageNotes:{},pageIndex:{},pageLayoutRatio:{},pageMask:{},pageMaskRatio:{},pageMaskStyle:{},pageMaskInitial:{},detectedSbRatio:{},detectedSbInfo:{},canConvertToSuperBlock:{type:Boolean},isGeneratingNotes:{type:Boolean}},emits:["update:pageLayout","update:pageTransition","update:pageSpacing","update:pageImage","update:pageLayoutRatio","update:pageMask","update:pageMaskRatio","update:pageMaskStyle","update:pageMaskInitial","applySuperBlockLayout","resetSuperblockRatio","addNoteBlock","locateNoteBlock","generateNotes","openSetting","insertDividerAfter","deleteDivider","convertToSuperBlock"],setup(e,{emit:t}){const o=e,i=t,n=[{label:"1:1 (2步)",value:"1:1"},{label:"1:1:1 (3步)",value:"1:1:1"},{label:"1:2:1 (非等宽)",value:"1:2:1"},{label:"1:1:1:1 (4步)",value:"1:1:1:1"}],s=ye(()=>{const k=o.pageMask;return k==="clockwise"||k==="counter-clockwise"||k==="cw"||k==="ccw"}),l=ye(()=>s.value?"1:1:1:1":"1:1"),r=ye(()=>o.pageMaskRatio||l.value);function a(k){i("update:pageMask",k),(!o.pageMaskRatio||o.pageMaskRatio==="1:1")&&i("update:pageMaskRatio","1:1:1:1")}function c(k){i("update:pageMask",k),(!o.pageMaskRatio||o.pageMaskRatio==="1:1:1:1")&&i("update:pageMaskRatio","1:1")}const u=ye(()=>o.pageMask==="clockwise"||o.pageMask==="counter-clockwise"||o.pageMask==="cw"||o.pageMask==="ccw"?`时钟走时规则：
• 顺时针：左上 → 右上 → 右下 → 左下
• 逆时针：左上 → 左下 → 右下 → 右上
• 每次点击时针旋转 90° 并扇形扫开 1/4 象限，全部揭开后翻页`:`输入规则：
• 权重比例（项数决定步数）：如 1:1 (2步等分)、1:1:1 (3步等分)、1:2:1 (按权重累计分段)
• 绝对百分比：如 25:75:100 或 30:80 (指定每步展开的累计百分比)
• 每次点击或按空格/向右键展露下一段，全部揭开后翻页`),f=ye(()=>["two-cols","cols-header","two-cols-header","three-cols-header","image-left","image-right"].includes(o.pageLayout)),p=ye(()=>{var $,A;if(o.pageLayout==="two-cols-header"||o.pageLayout==="two-cols"||o.pageLayout==="image-left"||o.pageLayout==="image-right")return 2;if(o.pageLayout==="three-cols-header")return 3;const k=(o.pageLayoutRatio||"").trim();if(k.includes(":")){const w=k.split(":").filter(Boolean).length;if(w>=2&&w<=6)return w}const x=(o.detectedSbRatio||"").trim();if(x.includes(":")){const w=x.split(":").filter(Boolean).length;if(w>=2&&w<=6)return w}if(($=o.detectedSbInfo)!=null&&$.colCount&&o.detectedSbInfo.colCount>=2)return Math.min(o.detectedSbInfo.colCount,6);if((A=o.detectedSbInfo)!=null&&A.slots&&Array.isArray(o.detectedSbInfo.slots)){const w=o.detectedSbInfo.slots.length;if(w>=2&&w<=6)return w}return 2}),d=ye(()=>{const k=p.value;return k===3?[{label:"默认 1:1:1",value:""},{label:"1:2:1 (主中)",value:"1:2:1"},{label:"2:1:1 (主左)",value:"2:1:1"},{label:"1:1:2 (主右)",value:"1:1:2"},{label:"1:3:1",value:"1:3:1"}]:k===4?[{label:"默认 1:1:1:1",value:""},{label:"1:2:2:1",value:"1:2:2:1"},{label:"2:1:1:2",value:"2:1:1:2"}]:k===5?[{label:"默认 1:1:1:1:1",value:""}]:k===6?[{label:"默认 1:1:1:1:1:1",value:""}]:[{label:"默认 1:1",value:""},{label:"1:2",value:"1:2"},{label:"2:1",value:"2:1"},{label:"3:7",value:"3:7"},{label:"7:3",value:"7:3"},{label:"4:6",value:"4:6"},{label:"6:4",value:"6:4"}]}),b=ye(()=>o.pageLayoutRatio||"");function m(){const k=p.value||2,x=Array(k).fill("1").join(":");i("update:pageLayoutRatio",x),i("resetSuperblockRatio")}const g=ye(()=>{if(!o.pageNotes)return"";const k=o.pageNotes.replace(/[\r\n]+/g," ").trim();return k.length>50?k.slice(0,50)+"...":k}),y=[{label:"默认封面",value:"https://images.unsplash.com/photo-1506744038136-46273834b3fb?auto=format&fit=crop&w=1920&q=80"},{label:"清空配图",value:""}];return(k,x)=>(J(),X("div",kb,[h("div",wb,[h("span",null,"幻灯片页面设置"+ve(e.pageIndex?` (第 ${e.pageIndex} 页)`:""),1)]),le(fb,{"model-value":e.pageLayout,onChange:x[0]||(x[0]=$=>k.$emit("update:pageLayout",$))},null,8,["model-value"]),!f.value&&e.pageLayout!=="clover"&&e.detectedSbRatio?(J(),X("div",xb,[h("div",Sb,[h("div",_b,[le(de,{name:"sparkles"}),h("span",null,[x[31]||(x[31]=St("检测到本页横向超级块列宽比例：",-1)),h("b",null,ve(e.detectedSbRatio),1)])]),h("button",{class:"spm-btn-action b3-tooltips b3-tooltips__sw","aria-label":"一键应用超级块列宽并设为分栏",style:{padding:"2px 8px",height:"26px","font-size":"11px","flex-shrink":"0",background:"var(--b3-theme-primary)",color:"#fff",display:"inline-flex","align-items":"center",gap:"4px"},onClick:x[1]||(x[1]=$=>k.$emit("applySuperBlockLayout",e.detectedSbInfo||{recommendedLayout:"two-cols",ratio:e.detectedSbRatio}))},[le(de,{name:"columns"}),x[32]||(x[32]=h("span",null,"设为分栏",-1))])])])):Ae("",!0),f.value?(J(),X("div",Cb,[h("div",Ib,[h("div",$b,[h("div",Tb,[le(de,{name:"ratio"}),x[33]||(x[33]=h("span",null,"分栏比例",-1))])])]),h("div",Ab,[(J(!0),X(Je,null,At(d.value,$=>(J(),X("button",{key:$.value,class:xe(["spm-chip",{active:b.value===$.value}]),onClick:A=>k.$emit("update:pageLayoutRatio",$.value)},ve($.label),11,Mb))),128))]),h("div",Eb,[h("input",{value:e.pageLayoutRatio||"",class:"spm-input",style:{flex:"1","min-width":"0"},placeholder:"自定义比例（如 1:2 或 30:70，留空为默认）",onInput:x[2]||(x[2]=$=>k.$emit("update:pageLayoutRatio",$.target.value)),onChange:x[3]||(x[3]=$=>k.$emit("update:pageLayoutRatio",$.target.value))},null,40,Bb),e.detectedSbRatio?(J(),X("button",{key:0,class:"spm-icon-btn b3-tooltips b3-tooltips__sw","aria-label":`读取超级块列宽比例 (${e.detectedSbRatio}) 并应用`,style:{padding:"0 8px",height:"26px","font-size":"11px","white-space":"nowrap","flex-shrink":"0"},onClick:x[4]||(x[4]=$=>k.$emit("update:pageLayoutRatio",e.detectedSbRatio))},[le(de,{name:"sparkles"}),x[34]||(x[34]=h("span",null,"读取",-1))],8,Lb)):(J(),X("button",Db,[le(de,{name:"sparkles"}),x[35]||(x[35]=h("span",null,"读取",-1))])),h("button",{class:"spm-icon-btn b3-tooltips b3-tooltips__sw","aria-label":"重置为等宽平均分布",style:{padding:"0 8px",height:"26px","font-size":"11px","white-space":"nowrap","flex-shrink":"0"},onClick:m},[le(de,{name:"reset"}),x[36]||(x[36]=h("span",null,"重置",-1))])]),e.detectedSbRatio?(J(),X("div",Ob,[le(de,{name:"ratio"}),x[37]||(x[37]=h("span",null,"检测到思源超级块宽度：",-1)),h("code",Nb,ve(e.detectedSbRatio),1)])):(J(),X("div",Pb,[le(de,{name:"ratio"}),x[38]||(x[38]=h("span",null,"未检测到调宽超级块（默认各列平均分配）",-1))]))])):Ae("",!0),h("div",Rb,[h("div",zb,[h("div",Hb,[h("div",Fb,[le(de,{name:"ratio"}),x[39]||(x[39]=h("span",null,"页面间距",-1))])])]),h("div",jb,[h("button",{class:xe(["spm-segmented-item",{active:!e.pageSpacing||e.pageSpacing==="inherit"}]),onClick:x[5]||(x[5]=$=>k.$emit("update:pageSpacing","inherit"))}," 继承全局 ",2),h("button",{class:xe(["spm-segmented-item b3-tooltips b3-tooltips__s",{active:e.pageSpacing==="compact"}]),"aria-label":"紧凑排版：外衬 16/28px，块距 8px，行高 1.45",onClick:x[6]||(x[6]=$=>k.$emit("update:pageSpacing","compact"))}," 紧凑 ",2),h("button",{class:xe(["spm-segmented-item b3-tooltips b3-tooltips__s",{active:e.pageSpacing==="normal"}]),"aria-label":"标准排版：外衬 32/48px，块距 14px，行高 1.60",onClick:x[7]||(x[7]=$=>k.$emit("update:pageSpacing","normal"))}," 标准 ",2),h("button",{class:xe(["spm-segmented-item b3-tooltips b3-tooltips__sw",{active:e.pageSpacing==="loose"}]),"aria-label":"宽松排版：外衬 52/72px，块距 22px，行高 1.75",onClick:x[8]||(x[8]=$=>k.$emit("update:pageSpacing","loose"))}," 宽松 ",2)])]),le(xc,{"model-value":e.pageTransition,onChange:x[9]||(x[9]=$=>k.$emit("update:pageTransition",$))},null,8,["model-value"]),h("div",Ub,[h("div",Wb,[h("div",qb,[h("div",Vb,[le(de,{name:"sparkles"}),x[40]||(x[40]=h("span",null,"页面动态蒙版",-1))])])]),h("div",Kb,[h("button",{class:xe(["spm-segmented-item",{active:!e.pageMask}]),onClick:x[10]||(x[10]=$=>k.$emit("update:pageMask",""))}," 关闭 ",2),h("button",{class:xe(["spm-segmented-item",{active:e.pageMask==="down"}]),onClick:x[11]||(x[11]=$=>c("down"))}," 从上至下 ",2),h("button",{class:xe(["spm-segmented-item",{active:e.pageMask==="right"}]),onClick:x[12]||(x[12]=$=>c("right"))}," 从左至右 ",2),h("button",{class:xe(["spm-segmented-item",{active:e.pageMask==="clockwise"||e.pageMask==="cw"}]),onClick:x[13]||(x[13]=$=>a("clockwise"))}," 顺时针 ↻ ",2),h("button",{class:xe(["spm-segmented-item",{active:e.pageMask==="counter-clockwise"||e.pageMask==="ccw"}]),onClick:x[14]||(x[14]=$=>a("counter-clockwise"))}," 逆时针 ↺ ",2)]),e.pageMask?(J(),X("div",Gb,[h("div",Yb,[x[42]||(x[42]=h("div",{style:{"font-size":"11px",opacity:"0.85","font-weight":"500"}},"展露比例 / 断点",-1)),h("span",{class:"b3-tooltips b3-tooltips__sw","aria-label":u.value,style:{cursor:"help",opacity:"0.75",display:"inline-flex","align-items":"center",gap:"3px","font-size":"11px"}},[le(de,{name:"help"}),x[41]||(x[41]=h("span",null,"输入规则",-1))],8,Zb)]),h("div",Jb,[(J(),X(Je,null,At(n,$=>h("button",{key:$.value,class:xe(["spm-chip",{active:r.value===$.value}]),onClick:A=>k.$emit("update:pageMaskRatio",$.value)},ve($.label),11,Xb)),64))]),h("input",{value:r.value,class:"spm-input",style:{width:"100%"},placeholder:"自定义比例或断点（如 1:2:1 或 25:75:100）",onInput:x[15]||(x[15]=$=>k.$emit("update:pageMaskRatio",$.target.value)),onChange:x[16]||(x[16]=$=>k.$emit("update:pageMaskRatio",$.target.value))},null,40,Qb),h("div",ev,ve(e.pageMask==="clockwise"||e.pageMask==="counter-clockwise"||e.pageMask==="cw"||e.pageMask==="ccw"?"时钟走时蒙版：默认 4 步旋转展露（1:1:1:1，每步 25% 扇形面积）":"提示：支持权重比（如 1:2:1）或绝对断点（如 25:75:100），冒号项数决定点击步数"),1),h("div",tv,[h("div",ov,[x[43]||(x[43]=h("div",{style:{"font-size":"11px",opacity:"0.85","margin-bottom":"4px"}},"遮盖质感",-1)),h("div",iv,[h("button",{class:xe(["spm-segmented-item",{active:!e.pageMaskStyle||e.pageMaskStyle==="solid"}]),onClick:x[17]||(x[17]=$=>k.$emit("update:pageMaskStyle","solid"))}," 背景同色 ",2),h("button",{class:xe(["spm-segmented-item",{active:e.pageMaskStyle==="blur"}]),onClick:x[18]||(x[18]=$=>k.$emit("update:pageMaskStyle","blur"))}," 磨砂毛玻璃 ",2)])]),h("div",nv,[x[44]||(x[44]=h("div",{style:{"font-size":"11px",opacity:"0.85","margin-bottom":"4px"}},"初始展露",-1)),h("div",sv,[h("button",{class:xe(["spm-segmented-item",{active:!e.pageMaskInitial||e.pageMaskInitial==="hidden"}]),onClick:x[19]||(x[19]=$=>k.$emit("update:pageMaskInitial","hidden"))}," 完全遮盖 ",2),h("button",{class:xe(["spm-segmented-item",{active:e.pageMaskInitial==="revealed"}]),onClick:x[20]||(x[20]=$=>k.$emit("update:pageMaskInitial","revealed"))}," 首段可见 ",2)])])])])):Ae("",!0)]),e.pageLayout==="image-right"||e.pageLayout==="image-left"||e.pageImage?(J(),X("div",rv,[h("div",lv,[h("div",av,[h("div",cv,[le(de,{name:"image"}),x[45]||(x[45]=h("span",null,"页面图片",-1))])])]),h("div",dv,[(J(),X(Je,null,At(y,$=>h("button",{key:$.value,class:xe(["spm-chip",{active:e.pageImage===$.value}]),onClick:A=>k.$emit("update:pageImage",$.value)},ve($.label),11,uv)),64))]),h("input",{value:e.pageImage,class:"spm-input",placeholder:"网络图片 URL 或思源本地资源路径 (如 assets/...)",onInput:x[21]||(x[21]=$=>k.$emit("update:pageImage",$.target.value)),onChange:x[22]||(x[22]=$=>k.$emit("update:pageImage",$.target.value))},null,40,fv)])):Ae("",!0),h("div",hv,[h("div",pv,[h("div",mv,[h("div",gv,[le(de,{name:"presenter"}),x[46]||(x[46]=h("span",null,"演讲者提词",-1))])]),ue(Ot)("aiScript")?(J(),X("div",yv,[h("button",{type:"button",class:xe(["spm-btn-primary b3-tooltips b3-tooltips__s",{"is-loading":e.isGeneratingNotes}]),disabled:e.isGeneratingNotes,"aria-label":"AI 自动生成本页讲稿提示块",onClick:x[23]||(x[23]=$=>k.$emit("generateNotes"))},[e.isGeneratingNotes?(J(),X("span",vv)):(J(),qt(de,{key:1,name:"sparkles"})),h("span",null,ve(e.isGeneratingNotes?"提炼中...":"AI 讲稿"),1)],10,bv),h("button",{type:"button",class:"spm-btn-icon b3-tooltips b3-tooltips__w","aria-label":"打开 AI 讲稿服务配置",onClick:x[24]||(x[24]=$=>k.$emit("openSetting"))},[le(de,{name:"settings"})])])):Ae("",!0)]),e.isGeneratingNotes?(J(),X("div",kv,[...x[47]||(x[47]=[h("div",{class:"spm-loading-spinner"},null,-1),h("div",{class:"spm-loading-text"},[h("span",{class:"spm-loading-title"},"AI 正在提炼本页演讲提词..."),h("span",{class:"spm-loading-desc"},"根据幻灯片上下文智能编写口播要点，请稍候")],-1)])])):e.pageNotes?(J(),X("div",wv,[x[50]||(x[50]=h("div",{class:"spm-note-status-badge"},[h("span",{class:"spm-badge-dot"}),h("span",null,"已配置正文讲稿")],-1)),h("div",{class:"spm-note-preview-text",title:e.pageNotes},ve(g.value),9,xv),h("div",Sv,[h("button",{class:"spm-btn-action b3-tooltips b3-tooltips__se","aria-label":"在正文编辑区定位并高亮此讲稿备注块",onClick:x[25]||(x[25]=$=>k.$emit("locateNoteBlock"))},[le(de,{name:"search"}),x[48]||(x[48]=h("span",null,"定位讲稿块",-1))]),h("button",{class:"spm-btn-action b3-tooltips b3-tooltips__sw","aria-label":"在本页末尾追加新的讲稿提示块",onClick:x[26]||(x[26]=$=>k.$emit("addNoteBlock"))},[le(de,{name:"insert-below"}),x[49]||(x[49]=h("span",null,"追加讲稿块",-1))])])])):(J(),X("div",_v,[x[52]||(x[52]=h("div",{class:"spm-note-empty-hint"},"本页暂无讲稿备注块",-1)),h("button",{class:"spm-btn-action b3-tooltips b3-tooltips__s",style:{width:"100%","margin-top":"6px"},"aria-label":"在当前页末尾插入默认演讲备注提示块",onClick:x[27]||(x[27]=$=>k.$emit("addNoteBlock"))},[le(de,{name:"insert-below"}),x[51]||(x[51]=h("span",null,"添加讲稿备注块",-1))])]))]),h("div",Cv,[x[56]||(x[56]=h("div",{class:"spm-control-header"},[h("div",{class:"spm-control-title-group"},[h("span",{class:"spm-control-title"},"快捷操作")])],-1)),h("div",Iv,[h("button",{class:"spm-btn-action b3-tooltips b3-tooltips__se","aria-label":"在此分页符之后插入新的空白分页",onClick:x[28]||(x[28]=$=>k.$emit("insertDividerAfter"))},[le(de,{name:"insert-below"}),x[53]||(x[53]=h("span",null,"插入新页",-1))]),h("button",{class:"spm-btn-action spm-btn-danger b3-tooltips b3-tooltips__sw","aria-label":"彻底删除当前分页符（合并前后页面）",onClick:x[29]||(x[29]=$=>k.$emit("deleteDivider"))},[le(de,{name:"trash"}),x[54]||(x[54]=h("span",null,"删除此页",-1))]),h("button",{class:xe(["spm-btn-action b3-tooltips b3-tooltips__s",{"is-disabled":!e.canConvertToSuperBlock}]),style:{"grid-column":"1 / -1"},disabled:!e.canConvertToSuperBlock,"aria-label":e.canConvertToSuperBlock?"将当前选中的多个块或列表项合并为横向超级块":"请在编辑区选中多个块，或选中一个列表/列表项",onClick:x[30]||(x[30]=$=>k.$emit("convertToSuperBlock"))},[le(de,{name:"columns"}),x[55]||(x[55]=h("span",null,"转为超级块",-1))],10,$v)])])]))}}),Av=lo(Tv,[["__scopeId","data-v-d91274ad"]]),Mv={class:"spm-section spm-section--block"},Ev={key:0,class:"spm-card-control",style:{"border-left":"3px solid var(--b3-theme-primary)"}},Bv={class:"spm-control-header"},Lv={class:"spm-control-title-group"},Dv={class:"spm-control-title b3-tooltips b3-tooltips__se","aria-label":"读取思源超级块列宽并一键同步到幻灯片分栏"},Ov={style:{background:"var(--b3-theme-surface)",border:"1px solid var(--b3-theme-surface-lighter)","border-radius":"6px",padding:"10px","margin-bottom":"8px"}},Nv={style:{display:"flex","align-items":"center","justify-content":"space-between","margin-bottom":"4px"}},Pv={style:{"font-size":"12px","font-weight":"500",display:"flex","align-items":"center",gap:"4px"}},Rv={key:0},zv={key:1},Hv={style:{background:"rgba(var(--b3-theme-primary-rgb, 59, 130, 246), 0.16)",color:"var(--b3-theme-primary)",border:"1px solid rgba(var(--b3-theme-primary-rgb, 59, 130, 246), 0.3)",padding:"2px 6px","border-radius":"4px","font-weight":"bold","font-size":"12px"}},Fv={style:{"font-size":"11px",opacity:"0.75","line-height":"1.4"}},jv={class:"spm-action-grid"},Uv={key:1,class:"spm-card-control"},Wv={class:"spm-control-header"},qv={class:"spm-control-title-group"},Vv={class:"spm-control-title b3-tooltips b3-tooltips__se","aria-label":"设为幻灯片背景图或图文分栏配图"},Kv={class:"spm-quick-chips"},Gv={key:2,class:"spm-card-control"},Yv={class:"spm-control-header"},Zv={class:"spm-control-title-group"},Jv={class:"spm-control-title b3-tooltips b3-tooltips__se","aria-label":"配置播放器控制条、自动播放与循环"},Xv={class:"spm-video-settings-grid",style:{display:"grid","grid-template-columns":"1fr 1fr",gap:"8px","margin-top":"8px"}},Qv={class:"spm-toggle-item",style:{display:"flex","align-items":"center","justify-content":"space-between",padding:"4px 6px",background:"rgba(125,125,125,0.06)","border-radius":"4px"}},e1={style:{"font-size":"11px",display:"inline-flex","align-items":"center",gap:"4px"}},t1=["aria-label"],o1=["checked"],i1={class:"spm-toggle-item",style:{display:"flex","align-items":"center","justify-content":"space-between",padding:"4px 6px",background:"rgba(125,125,125,0.06)","border-radius":"4px"}},n1={style:{"font-size":"11px",display:"inline-flex","align-items":"center",gap:"4px"}},s1=["aria-label"],r1=["checked"],l1={class:"spm-toggle-item",style:{display:"flex","align-items":"center","justify-content":"space-between",padding:"4px 6px",background:"rgba(125,125,125,0.06)","border-radius":"4px"}},a1={style:{"font-size":"11px",display:"inline-flex","align-items":"center",gap:"4px"}},c1=["aria-label"],d1=["checked"],u1={class:"spm-toggle-item",style:{display:"flex","align-items":"center","justify-content":"space-between",padding:"4px 6px",background:"rgba(125,125,125,0.06)","border-radius":"4px"}},f1={style:{"font-size":"11px",display:"inline-flex","align-items":"center",gap:"4px"}},h1=["aria-label"],p1=["checked"],m1={class:"spm-card-control"},g1={class:"spm-control-header"},y1={class:"spm-control-title-group"},b1={class:"spm-control-title b3-tooltips b3-tooltips__se","aria-label":"放映时按步长逐个呈现"},v1=["aria-label"],k1=["checked"],w1={key:0,class:"spm-quick-chips"},x1=["onClick"],S1={key:1,class:"spm-inherit-tip",style:{"margin-top":"6px",padding:"4px 8px",background:"rgba(var(--b3-theme-primary-rgb, 59, 130, 246), 0.08)","border-radius":"4px","font-size":"11px",opacity:"0.85",display:"flex","align-items":"center",gap:"4px"}},_1={class:"spm-card-control"},C1={class:"spm-control-header"},I1={class:"spm-control-title-group"},$1={class:"spm-control-title b3-tooltips b3-tooltips__se","aria-label":"为当前块添加平滑位移与渐入动画"},T1=["aria-label"],A1=["checked"],M1={key:0,class:"spm-quick-chips"},E1=["onClick"],B1={key:1,class:"spm-motion-details",style:{display:"flex","flex-direction":"column",gap:"4px","margin-top":"4px"}},L1={style:{display:"flex",gap:"8px","justify-content":"space-between","font-size":"11px",opacity:"0.8"}},D1={style:{display:"flex",gap:"6px"}},O1=["value"],N1=["value"],P1={key:3,class:"spm-card-control"},R1={class:"spm-control-header"},z1={class:"spm-control-title-group"},H1=["aria-label"],F1={class:"spm-segmented-group"},j1=["onClick"],U1={key:4,class:"spm-card-control"},W1={class:"spm-control-header"},q1={class:"spm-control-title-group"},V1={class:"spm-control-title b3-tooltips b3-tooltips__se","aria-label":"翻页时动态聚光高亮特定行"},K1={class:"spm-quick-chips"},G1=["onClick"],Y1=["value"],Z1={key:5,class:"spm-card-control"},J1={class:"spm-control-header"},X1={class:"spm-control-title-group"},Q1={class:"spm-control-title b3-tooltips b3-tooltips__se","aria-label":"超出限高自动竖向滚动，弱提示滚动条"},e0={class:"spm-quick-chips"},t0=["onClick"],o0=["value"],i0={class:"spm-card-control"},n0={class:"spm-action-grid"},s0=["aria-label"],r0=["disabled","aria-label"],l0=["disabled","aria-label"],a0=zt({__name:"BlockInspectorSection",props:{elemClick:{},elemMotion:{},elemSlot:{},elemShikiLines:{},elemMaxHeight:{},isCodeBlock:{type:Boolean},isImage:{type:Boolean},isVideo:{type:Boolean},videoAutoplay:{type:Boolean},videoLoop:{type:Boolean},videoMuted:{type:Boolean},videoControls:{type:Boolean},hasBlockAttrs:{type:Boolean},isNote:{type:Boolean},imageRole:{},currentSlideLayout:{},isSuperBlock:{type:Boolean},parentElemClick:{},parentContainerSlot:{},parentContainerId:{},detectedSbInfo:{},canConvertToSuperBlock:{type:Boolean}},emits:["toggleNote","toggleElemClick","update:elemClick","update:elemMotion","update:elemSlot","update:elemShikiLines","update:elemMaxHeight","applySuperBlockLayout","applySuperBlockRatio","insertDividerBefore","insertDividerAfter","setTwoColsContrast","clearBlockAttrs","convertToSuperBlock","update:imageRole","toggleVideoAutoplay","toggleVideoLoop","toggleVideoMuted","toggleVideoControls"],setup(e,{emit:t}){const o=e,i=ye(()=>{const w=o.currentSlideLayout||"";return["col-1","col-2","col-3","col-4","col-5","col-6"].includes(o.elemSlot)?"cols-header":w}),n=ye(()=>{const w=i.value;return["two-cols","cols-header","two-cols-header","three-cols-header"].includes(w)}),s=ye(()=>{var _,O,H,P;if((_=o.detectedSbInfo)!=null&&_.colCount&&o.detectedSbInfo.colCount>=2)return Math.min(o.detectedSbInfo.colCount,6);const w=(O=o.elemSlot)==null?void 0:O.match(/^col-(\d+)$/);if(w){const F=parseInt(w[1],10);if(F>=2&&F<=6)return Math.max(F,3)}if(o.currentSlideLayout==="three-cols-header")return 3;if(o.currentSlideLayout==="two-cols-header"||o.currentSlideLayout==="two-cols")return 2;if((P=(H=o.detectedSbInfo)==null?void 0:H.ratio)!=null&&P.includes(":")){const F=o.detectedSbInfo.ratio.split(":").filter(Boolean);if(F.length>=2)return Math.min(F.length,6)}return 3}),l=ye(()=>{const w=i.value;return w==="cols-header"?"多栏插槽归属":w==="three-cols-header"?"三栏插槽归属":w==="two-cols-header"?"带表头双栏插槽":"多栏插槽归属"}),r=ye(()=>{const w=i.value;return w==="cols-header"?`在 cols-header 表头多栏（${s.value} 栏）中的内容块位置`:w==="three-cols-header"?"在 three-cols-header 版式中的内容块位置":w==="two-cols-header"?"在 two-cols-header 版式中的内容块位置":w==="two-cols"?"在 two-cols 双栏版式中的归属":"在当前分栏版式中的内容块位置"}),a=ye(()=>{const w=i.value;if(w==="two-cols")return[{value:"",label:"默认 (左)"},{value:"right",label:"右栏"}];if(w==="two-cols-header")return[{value:"",label:"默认"},{value:"header",label:"表头"},{value:"left",label:"左栏"},{value:"right",label:"右栏"}];if(w==="three-cols-header")return[{value:"",label:"默认"},{value:"header",label:"表头"},{value:"col-1",label:"第 1 栏"},{value:"col-2",label:"第 2 栏"},{value:"col-3",label:"第 3 栏"}];const _=s.value,O=[{value:"",label:"默认"},{value:"header",label:"表头"}];for(let H=1;H<=_;H++)O.push({value:`col-${H}`,label:`第 ${H} 栏`});return O});function c(w){const _=o.elemSlot||"";return w?_===w||w==="col-1"&&_==="left"||w==="col-2"&&_==="center"||w==="col-3"&&_==="right"&&s.value===3||w==="col-2"&&_==="right"&&s.value===2||w==="left"&&_==="col-1"||w==="right"&&(_==="col-2"||_==="col-3"):!_||_==="default"}const u=t,f=[{label:"上浮",value:"slide-up"},{label:"淡入",value:"fade-in"},{label:"下沉",value:"slide-down"},{label:"左滑",value:"slide-left"},{label:"右滑",value:"slide-right"},{label:"缩放",value:"zoom-in"},{label:"弹性",value:"bounce"}],p=ye(()=>{if(!o.elemMotion||o.elemMotion.trim()===""||o.elemMotion.trim()==="none")return null;try{const w=JSON.parse(o.elemMotion);if(typeof w=="object"&&w!==null)return{preset:w.preset||w.type||"slide-up",duration:typeof w.duration=="number"?w.duration:0,delay:typeof w.delay=="number"?w.delay:0}}catch{}return{preset:o.elemMotion.trim(),duration:0,delay:0}}),d=ye(()=>!!p.value),b=ye(()=>{var w;return((w=p.value)==null?void 0:w.preset)||"slide-up"}),m=ye(()=>{var w;return((w=p.value)==null?void 0:w.duration)||0}),g=ye(()=>{var w;return((w=p.value)==null?void 0:w.delay)||0});function y(){d.value?u("update:elemMotion",""):u("update:elemMotion","slide-up")}function k(w){A(w,m.value,g.value)}function x(w){A(b.value,w,g.value)}function $(w){A(b.value,m.value,w)}function A(w,_,O){if(!w||w==="none"){u("update:elemMotion","");return}if(!_&&!O){u("update:elemMotion",w);return}const H={preset:w};_>0&&(H.duration=_),O>0&&(H.delay=O),u("update:elemMotion",JSON.stringify(H))}return(w,_)=>{var O,H,P,F,E,D;return J(),X("div",Mv,[_[53]||(_[53]=h("div",{class:"spm-section-header"},[h("span",null,"元素动效与排版")],-1)),e.isSuperBlock||(O=e.detectedSbInfo)!=null&&O.hasSuperBlock?(J(),X("div",Ev,[h("div",Bv,[h("div",Lv,[h("div",Dv,[le(de,{name:"ratio"}),_[24]||(_[24]=h("span",null,"超级块列宽与布局",-1))])])]),h("div",Ov,[h("div",Nv,[h("div",Pv,[le(de,{name:"ratio"}),(H=e.detectedSbInfo)!=null&&H.isCustomWidth?(J(),X("span",Rv,"已识别自定义列宽比例")):(J(),X("span",zv,"识别到 "+ve(((P=e.detectedSbInfo)==null?void 0:P.colCount)||2)+" 列超级块分栏",1))]),h("code",Hv,ve(((F=e.detectedSbInfo)==null?void 0:F.ratio)||"1:1"),1)]),h("div",Fv,ve((E=e.detectedSbInfo)!=null&&E.isCustomWidth?"检测到已调节子块宽度，可一键应用为当前页分栏比例。":"当前超级块子列为思源默认均宽，可在思源中拖动调节或直接应用。"),1)]),h("div",jv,[h("button",{class:"spm-btn-action b3-tooltips b3-tooltips__se","aria-label":"一键将当前页版式切换为对应双栏/三栏，并写入此列宽比例",style:{background:"rgba(var(--b3-theme-primary-rgb, 59, 130, 246), 0.16)",color:"var(--b3-theme-primary)","font-weight":"500",border:"1px solid rgba(var(--b3-theme-primary-rgb, 59, 130, 246), 0.3)"},onClick:_[0]||(_[0]=S=>w.$emit("applySuperBlockLayout",e.detectedSbInfo))},[le(de,{name:"sparkles"}),_[25]||(_[25]=h("span",null,"应用版式与比例",-1))]),h("button",{class:"spm-btn-action b3-tooltips b3-tooltips__sw","aria-label":"仅将提取的比值写入当前页的分栏比例属性",onClick:_[1]||(_[1]=S=>{var q;return w.$emit("applySuperBlockRatio",((q=e.detectedSbInfo)==null?void 0:q.ratio)||"1:1")})},[le(de,{name:"check"}),h("span",null,"应用比例 ("+ve(((D=e.detectedSbInfo)==null?void 0:D.ratio)||"1:1")+")",1)])])])):Ae("",!0),e.isImage||e.imageRole?(J(),X("div",Uv,[h("div",Wv,[h("div",qv,[h("div",Vv,[le(de,{name:"image"}),_[26]||(_[26]=h("span",null,"图片角色与分栏",-1))])])]),h("div",Kv,[h("button",{class:xe(["spm-chip",{active:!e.imageRole}]),onClick:_[2]||(_[2]=S=>w.$emit("update:imageRole",""))}," 普通内容 ",2),h("button",{class:xe(["spm-chip",{active:e.imageRole==="background"}]),onClick:_[3]||(_[3]=S=>w.$emit("update:imageRole","background"))},[le(de,{name:"image"}),_[27]||(_[27]=h("span",null,"背景图",-1))],2),h("button",{class:xe(["spm-chip",{active:e.imageRole==="image-left"}]),onClick:_[4]||(_[4]=S=>w.$emit("update:imageRole","image-left"))},[le(de,{name:"image-left"}),_[28]||(_[28]=h("span",null,"图左",-1))],2),h("button",{class:xe(["spm-chip",{active:e.imageRole==="image-right"}]),onClick:_[5]||(_[5]=S=>w.$emit("update:imageRole","image-right"))},[le(de,{name:"image-right"}),_[29]||(_[29]=h("span",null,"图右",-1))],2)])])):Ae("",!0),e.isVideo?(J(),X("div",Gv,[h("div",Yv,[h("div",Zv,[h("div",Jv,[le(de,{name:"video"}),_[30]||(_[30]=h("span",null,"视频播放设置",-1))])])]),h("div",Xv,[h("div",Qv,[h("span",e1,[le(de,{name:"sliders"}),_[31]||(_[31]=St(" 控制条",-1))]),h("label",{class:"spm-switch b3-tooltips b3-tooltips__se","aria-label":e.videoControls?"关闭控制条":"开启控制条"},[h("input",{type:"checkbox",checked:!!e.videoControls,onChange:_[6]||(_[6]=S=>w.$emit("toggleVideoControls"))},null,40,o1),_[32]||(_[32]=h("span",{class:"spm-switch-slider"},null,-1))],8,t1)]),h("div",i1,[h("span",n1,[le(de,{name:"video"}),_[33]||(_[33]=St(" 自动播放",-1))]),h("label",{class:"spm-switch b3-tooltips b3-tooltips__sw","aria-label":e.videoAutoplay?"关闭自动播放":"开启自动播放"},[h("input",{type:"checkbox",checked:!!e.videoAutoplay,onChange:_[7]||(_[7]=S=>w.$emit("toggleVideoAutoplay"))},null,40,r1),_[34]||(_[34]=h("span",{class:"spm-switch-slider"},null,-1))],8,s1)]),h("div",l1,[h("span",a1,[le(de,{name:"repeat"}),_[35]||(_[35]=St(" 循环播放",-1))]),h("label",{class:"spm-switch b3-tooltips b3-tooltips__se","aria-label":e.videoLoop?"关闭循环播放":"开启循环播放"},[h("input",{type:"checkbox",checked:!!e.videoLoop,onChange:_[8]||(_[8]=S=>w.$emit("toggleVideoLoop"))},null,40,d1),_[36]||(_[36]=h("span",{class:"spm-switch-slider"},null,-1))],8,c1)]),h("div",u1,[h("span",f1,[le(de,{name:"volume-x"}),_[37]||(_[37]=St(" 静音播放",-1))]),h("label",{class:"spm-switch b3-tooltips b3-tooltips__sw","aria-label":e.videoMuted?"关闭静音":"开启静音"},[h("input",{type:"checkbox",checked:!!e.videoMuted,onChange:_[9]||(_[9]=S=>w.$emit("toggleVideoMuted"))},null,40,p1),_[38]||(_[38]=h("span",{class:"spm-switch-slider"},null,-1))],8,h1)])])])):Ae("",!0),h("div",m1,[h("div",g1,[h("div",y1,[h("div",b1,[le(de,{name:"step"}),_[39]||(_[39]=h("span",null,"逐步呈现",-1))])]),h("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":e.elemClick?"关闭逐步呈现":"开启逐步呈现 (+1)"},[h("input",{type:"checkbox",checked:!!e.elemClick,onChange:_[10]||(_[10]=S=>w.$emit("toggleElemClick"))},null,40,k1),_[40]||(_[40]=h("span",{class:"spm-switch-slider"},null,-1))],8,v1)]),e.elemClick?(J(),X("div",w1,[(J(),X(Je,null,At(["+1","1","2","hide"],S=>h("button",{key:S,class:xe(["spm-chip",{active:e.elemClick===S}]),onClick:q=>w.$emit("update:elemClick",S)},ve(S==="+1"?"顺延 (+1)":S==="hide"?"隐藏":"第 "+S+" 步"),11,x1)),64))])):e.parentElemClick?(J(),X("div",S1,[le(de,{name:"check"}),_[41]||(_[41]=h("span",null,"未单独开启逐步呈现：当前跟随整栏同时出现",-1))])):Ae("",!0)]),h("div",_1,[h("div",C1,[h("div",I1,[h("div",$1,[le(de,{name:"motion"}),_[42]||(_[42]=h("span",null,"入场微动效",-1))])]),h("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":d.value?"关闭微动效":"开启微动效"},[h("input",{type:"checkbox",checked:d.value,onChange:y},null,40,A1),_[43]||(_[43]=h("span",{class:"spm-switch-slider"},null,-1))],8,T1)]),d.value?(J(),X("div",M1,[(J(),X(Je,null,At(f,S=>h("button",{key:S.value,class:xe(["spm-chip",{active:b.value===S.value}]),onClick:q=>k(S.value)},ve(S.label),11,E1)),64))])):Ae("",!0),d.value?(J(),X("div",B1,[h("div",L1,[h("span",null,"时长: "+ve(m.value?m.value+"ms":"默认 (450ms)"),1),h("span",null,"延迟: "+ve(g.value?g.value+"ms":"0ms"),1)]),h("div",D1,[h("select",{class:"spm-select",style:{flex:"1"},value:m.value,onChange:_[11]||(_[11]=S=>x(Number(S.target.value)))},[..._[44]||(_[44]=[h("option",{value:0},"默认耗时",-1),h("option",{value:200},"极速 (200ms)",-1),h("option",{value:350},"较快 (350ms)",-1),h("option",{value:500},"平滑 (500ms)",-1),h("option",{value:800},"缓慢 (800ms)",-1)])],40,O1),h("select",{class:"spm-select",style:{flex:"1"},value:g.value,onChange:_[12]||(_[12]=S=>$(Number(S.target.value)))},[..._[45]||(_[45]=[h("option",{value:0},"无延迟",-1),h("option",{value:150},"延迟 150ms",-1),h("option",{value:300},"延迟 300ms",-1),h("option",{value:500},"延迟 500ms",-1)])],40,N1)])])):Ae("",!0)]),n.value||e.elemSlot?(J(),X("div",P1,[h("div",R1,[h("div",z1,[h("div",{class:"spm-control-title b3-tooltips b3-tooltips__se","aria-label":r.value},[le(de,{name:"columns"}),h("span",null,ve(l.value),1)],8,H1)])]),h("div",F1,[(J(!0),X(Je,null,At(a.value,S=>(J(),X("button",{key:S.value,class:xe(["spm-segmented-item",{active:c(S.value)}]),onClick:q=>w.$emit("update:elemSlot",S.value)},ve(S.label),11,j1))),128))])])):Ae("",!0),e.isCodeBlock?(J(),X("div",U1,[h("div",W1,[h("div",q1,[h("div",V1,[le(de,{name:"code"}),_[46]||(_[46]=h("span",null,"代码逐行聚光",-1))])])]),h("div",K1,[(J(),X(Je,null,At(["1-3","all","1|2|3","2-5"],S=>h("button",{key:S,class:xe(["spm-chip",{active:e.elemShikiLines===S}]),onClick:q=>w.$emit("update:elemShikiLines",S)},ve(S),11,G1)),64)),e.elemShikiLines?(J(),X("button",{key:0,class:"spm-chip spm-chip-clear",onClick:_[13]||(_[13]=S=>w.$emit("update:elemShikiLines",""))}," 清空 ")):Ae("",!0)]),h("input",{value:e.elemShikiLines,class:"spm-input",placeholder:"自定义高亮区间，如 1-3|5|all",onInput:_[14]||(_[14]=S=>w.$emit("update:elemShikiLines",S.target.value)),onChange:_[15]||(_[15]=S=>w.$emit("update:elemShikiLines",S.target.value))},null,40,Y1)])):Ae("",!0),e.isCodeBlock?(J(),X("div",Z1,[h("div",J1,[h("div",X1,[h("div",Q1,[le(de,{name:"code"}),_[47]||(_[47]=h("span",null,"代码块限高",-1))])])]),h("div",e0,[(J(),X(Je,null,At(["240px","320px","400px","50%"],S=>h("button",{key:S,class:xe(["spm-chip",{active:e.elemMaxHeight===S||S==="50%"&&(e.elemMaxHeight==="50vh"||e.elemMaxHeight==="50%")}]),onClick:q=>w.$emit("update:elemMaxHeight",S)},ve(S),11,t0)),64)),e.elemMaxHeight?(J(),X("button",{key:0,class:"spm-chip spm-chip-clear",onClick:_[16]||(_[16]=S=>w.$emit("update:elemMaxHeight",""))}," 自适应 ")):Ae("",!0)]),h("input",{value:e.elemMaxHeight,class:"spm-input",placeholder:"自适应高度，或输入 350px、50%",onInput:_[17]||(_[17]=S=>w.$emit("update:elemMaxHeight",S.target.value)),onChange:_[18]||(_[18]=S=>w.$emit("update:elemMaxHeight",S.target.value))},null,40,o0)])):Ae("",!0),h("div",i0,[_[52]||(_[52]=h("div",{class:"spm-control-header"},[h("div",{class:"spm-control-title-group"},[h("span",{class:"spm-control-title"},"快捷操作")])],-1)),h("div",n0,[h("button",{class:"spm-btn-action b3-tooltips b3-tooltips__se","aria-label":"在当前块上方插入幻灯片分页线 (---)",onClick:_[19]||(_[19]=S=>w.$emit("insertDividerBefore"))},[le(de,{name:"insert-above"}),_[48]||(_[48]=h("span",null,"上方分页",-1))]),h("button",{class:"spm-btn-action b3-tooltips b3-tooltips__sw","aria-label":"在当前块下方插入幻灯片分页线 (---)",onClick:_[20]||(_[20]=S=>w.$emit("insertDividerAfter"))},[le(de,{name:"insert-below"}),_[49]||(_[49]=h("span",null,"下方分页",-1))]),h("button",{class:xe(["spm-btn-action b3-tooltips b3-tooltips__se",{"spm-btn-action--active":!!e.isNote}]),"aria-label":e.isNote?"取消当前块的演示讲稿备注":"将当前块设为演示讲稿备注",onClick:_[21]||(_[21]=S=>w.$emit("toggleNote"))},[le(de,{name:"presenter"}),h("span",null,ve(e.isNote?"取消备注":"设为备注"),1)],10,s0),h("button",{class:xe(["spm-btn-action spm-btn-danger b3-tooltips b3-tooltips__sw",{"is-disabled":!e.hasBlockAttrs}]),disabled:!e.hasBlockAttrs,"aria-label":e.hasBlockAttrs?"一键移除本块所有 custom-slides 演示属性":"当前块无演示属性",onClick:_[22]||(_[22]=S=>w.$emit("clearBlockAttrs"))},[le(de,{name:"broom"}),_[50]||(_[50]=h("span",null,"清除属性",-1))],10,r0),h("button",{class:xe(["spm-btn-action b3-tooltips b3-tooltips__s",{"is-disabled":!e.canConvertToSuperBlock}]),style:{"grid-column":"1 / -1"},disabled:!e.canConvertToSuperBlock,"aria-label":e.canConvertToSuperBlock?"将当前选中的多个块或列表项合并为横向超级块":"请在编辑区选中多个块，或选中一个列表/列表项",onClick:_[23]||(_[23]=S=>w.$emit("convertToSuperBlock"))},[le(de,{name:"columns"}),_[51]||(_[51]=h("span",null,"转为超级块",-1))],10,l0)])])])}}}),c0={class:"spm-section spm-section--doc"},d0={class:"spm-card-control"},u0={class:"spm-control-header"},f0={class:"spm-control-title-group"},h0={class:"spm-control-title b3-tooltips b3-tooltips__se","aria-label":"全局幻灯片视觉设计范式"},p0={class:"spm-theme-card-grid"},m0=["aria-label","onClick"],g0={key:0,class:"spm-bg-swatch-check"},y0={class:"spm-theme-card-label"},b0={class:"spm-card-control"},v0={class:"spm-control-header"},k0={class:"spm-control-title-group"},w0={class:"spm-control-title b3-tooltips b3-tooltips__se","aria-label":"全篇幻灯片统一底色、微渐变或壁纸"},x0={class:"spm-bg-swatch-grid"},S0=["aria-label","onClick"],_0={key:0,class:"spm-bg-swatch-check"},C0={class:"spm-bg-swatch-label"},I0={class:"spm-bg-input-row"},$0=["value"],T0={class:"spm-card-control"},A0={class:"spm-control-header"},M0={class:"spm-control-title-group"},E0={class:"spm-control-title b3-tooltips b3-tooltips__se","aria-label":"演讲屏幕投影宽高比"},B0={class:"spm-segmented-group"},L0={class:"spm-card-control"},D0={class:"spm-control-header"},O0={class:"spm-control-title-group"},N0={class:"spm-control-title b3-tooltips b3-tooltips__se","aria-label":"内衬、内容间隙与正文行距预设"},P0={class:"spm-segmented-group"},R0={class:"spm-card-control"},z0={class:"spm-control-header"},H0={class:"spm-control-title-group"},F0={class:"spm-control-title b3-tooltips b3-tooltips__se","aria-label":"页面切换过渡动效（未单设转场的页面将继承此动效）"},j0={class:"spm-card-control"},U0={class:"spm-action-grid"},W0=["disabled"],q0=["disabled"],V0=["disabled"],K0=["disabled"],G0=["disabled"],Y0=["aria-expanded"],Z0={class:"spm-advanced-toggle-label"},J0={key:0,class:"spm-advanced-content"},X0={class:"spm-card-control"},Q0={class:"spm-control-header"},ek={class:"spm-control-title-group"},tk={class:"spm-control-title b3-tooltips b3-tooltips__se","aria-label":"点击文档/块链接以 Webview 抽屉呈现，支持外跳"},ok=["aria-label"],ik=["checked"],nk={key:0,class:"spm-control-body",style:{"margin-top":"8px"}},sk=["value"],rk={class:"spm-card-control"},lk={class:"spm-control-header"},ak={class:"spm-control-title-group"},ck={class:"spm-control-title b3-tooltips b3-tooltips__se","aria-label":"除封面外页首标题按 H2、多栏内首标题按 H3 大小展示"},dk=["aria-label"],uk=["checked"],fk={class:"spm-card-control"},hk={class:"spm-control-header"},pk={class:"spm-control-title-group"},mk={class:"spm-control-title b3-tooltips b3-tooltips__se","aria-label":"分别控制正文中无序列表圆点与有序列表数字序号的呈现"},gk={class:"spm-list-markers-toggles",style:{display:"flex",gap:"8px","margin-top":"8px"}},yk={class:"spm-marker-toggle-item",style:{flex:"1",display:"flex","align-items":"center","justify-content":"space-between",padding:"6px 10px",background:"var(--b3-theme-surface)",border:"1px solid var(--b3-border-color)","border-radius":"4px"}},bk=["aria-label"],vk=["checked"],kk={class:"spm-marker-toggle-item",style:{flex:"1",display:"flex","align-items":"center","justify-content":"space-between",padding:"6px 10px",background:"var(--b3-theme-surface)",border:"1px solid var(--b3-border-color)","border-radius":"4px"}},wk=["aria-label"],xk=["checked"],Sk={class:"spm-card-control"},_k={class:"spm-control-header"},Ck={class:"spm-control-title-group"},Ik={class:"spm-control-title b3-tooltips b3-tooltips__se","aria-label":"提炼演讲口播提词卡，支持 API 旋钮接管调度"},$k={key:0,class:"api-switch-managed-tip",style:{"margin-top":"8px","background-color":"var(--b3-theme-primary-light, rgba(63, 81, 181, 0.08))",border:"1px solid var(--b3-theme-primary, rgba(63, 81, 181, 0.2))","border-radius":"6px",padding:"8px 10px","font-size":"11px","line-height":"1.4",color:"var(--b3-theme-on-background)"}},Tk={class:"spm-control-body",style:{"margin-top":"8px",display:"flex","flex-direction":"column",gap:"6px"}},Ak={style:{display:"flex","align-items":"center","justify-content":"space-between",gap:"8px"}},Mk=["value","disabled"],Ek={style:{display:"flex","align-items":"center","justify-content":"space-between",gap:"8px"}},Bk=["value","disabled"],Lk={style:{display:"flex","align-items":"center","justify-content":"space-between",gap:"8px"}},Dk=["value","disabled"],Ok=zt({__name:"DocInspectorSection",props:{docTheme:{},docBackground:{},docAspectRatio:{},docDefaultTransition:{},docSpacing:{},isBatchProcessing:{type:Boolean}},emits:["update:docTheme","update:docBackground","update:docAspectRatio","update:docDefaultTransition","update:docSpacing","openBottomPreview","openPresenter","addOrIdentifyNotes","clearNotes","autoAnimate","clearAnimations","aiAutoSplit","clearDividers","exportHtml","exportPdf","openSetting"],setup(e,{emit:t}){const o=Kt("plugin"),i=Ht,n=is,s=pe(!1);function l(){$("openSetting")}async function r(A){const w=i.aiConfig,_=bi({...w,model:A});ht({aiConfig:_}),o&&typeof o.saveGlobalSettings=="function"&&await o.saveGlobalSettings({aiConfig:_}),u(_)}async function a(A){const w=i.aiConfig,_=bi({...w,baseUrl:A});ht({aiConfig:_}),o&&typeof o.saveGlobalSettings=="function"&&await o.saveGlobalSettings({aiConfig:_}),u(_)}async function c(A){const w=i.aiConfig,_=bi({...w,apiKey:A});ht({aiConfig:_}),o&&typeof o.saveGlobalSettings=="function"&&await o.saveGlobalSettings({aiConfig:_}),u(_)}function u(A){typeof window<"u"&&window.siyuanApiSwitch&&(o!=null&&o.name)&&window.siyuanApiSwitch.updateLocalConfig(o.name,{provider:"custom",baseUrl:A.baseUrl,apiKey:A.apiKey,model:A.model,requestTimeoutSeconds:A.requestTimeoutSeconds,temperature:A.temperature,maxTokens:A.maxTokens})}const f=[{value:"apple-basic",label:"极简 apple",desc:"苹果发布会极简风：大字号、高对比度与极致留白，适合产品发布、方案演讲与纯粹视觉呈现"},{value:"tech",label:"科技 tech",desc:"科技风：现代无衬线排版、Emerald 绿青双色指示与清新代码语法高亮，通用汇报与技术分享首选"},{value:"seriph",label:"优雅 seriph",desc:"典雅学术衬线风：书卷学术质感、衬线字体典雅庄重，适合学术论文、人文讲座与深度阅读"}];function p(A){ht({enableWebServeJump:A}),o&&typeof o.saveGlobalSettings=="function"&&o.saveGlobalSettings({enableWebServeJump:A})}async function d(A){var w;ht({normalizeHeadingSizes:A}),o&&typeof o.saveGlobalSettings=="function"&&await o.saveGlobalSettings({normalizeHeadingSizes:A}),o&&typeof o.compileCurrentDocument=="function"&&o.compileCurrentDocument(o.currentDocId||((w=o.getActiveDocumentId)==null?void 0:w.call(o)))}async function b(A){var w;ht({showUnorderedListMarkers:A}),o&&typeof o.saveGlobalSettings=="function"&&await o.saveGlobalSettings({showUnorderedListMarkers:A}),o&&typeof o.compileCurrentDocument=="function"&&o.compileCurrentDocument(o.currentDocId||((w=o.getActiveDocumentId)==null?void 0:w.call(o)))}async function m(A){var w;ht({showOrderedListMarkers:A}),o&&typeof o.saveGlobalSettings=="function"&&await o.saveGlobalSettings({showOrderedListMarkers:A}),o&&typeof o.compileCurrentDocument=="function"&&o.compileCurrentDocument(o.currentDocId||((w=o.getActiveDocumentId)==null?void 0:w.call(o)))}function g(A){ht({webServeUrl:A})}function y(A){ht({webServeUrl:A}),o&&typeof o.saveGlobalSettings=="function"&&o.saveGlobalSettings({webServeUrl:A})}const k=[{label:"默认",value:"",mode:"auto",desc:"跟随当前幻灯片主题与明暗模式自适应底色"},{label:"极简白",value:"#ffffff",mode:"light",desc:"纯净高对比白底 (#ffffff)，自动切换深色文字"},{label:"暖羊皮",value:"#f5efe6",mode:"light",desc:"温润护眼米棕纸张底 (#f5efe6)，自动切换深色文字"},{label:"晴空薄荷",value:"linear-gradient(135deg, #e0f2fe 0%, #dcfce7 100%)",mode:"light",desc:"清透天蓝至薄荷微渐变，自动切换深色文字"},{label:"晨曦微光",value:"linear-gradient(135deg, #fef3c7 0%, #fce7f3 100%)",mode:"light",desc:"柔和暖金至淡樱微渐变，自动切换深色文字"},{label:"曜石炭黑",value:"#18181b",mode:"dark",desc:"中性深炭黑 (#18181b)，区别于默认深海蓝底"},{label:"松墨深绿",value:"#0d2621",mode:"dark",desc:"沉稳森林墨绿 (#0d2621)，自动切换浅色文字"},{label:"极光紫青",value:"linear-gradient(135deg, #1e1b4b 0%, #0f3d4c 100%)",mode:"dark",desc:"深邃靛紫至极光青渐变，自动切换浅色文字"},{label:"深空靛蓝",value:"linear-gradient(135deg, #172554 0%, #312e81 100%)",mode:"dark",desc:"科技深空蓝至暮色紫渐变，自动切换浅色文字"}];function x(A){const w=(A||"").trim();return w?/^(?:https?:\/\/|\/|data:|assets\/|\.\/assets\/)/i.test(w)?{backgroundImage:`url("${w.startsWith("assets/")?`/${w}`:w.startsWith("./assets/")?w.slice(1):w}")`,backgroundSize:"cover",backgroundPosition:"center"}:{background:w}:{background:"linear-gradient(135deg, #f8fafc 50%, #090d16 50%)"}}const $=t;return(A,w)=>(J(),X("div",c0,[w[65]||(w[65]=h("div",{class:"spm-section-header"},[h("span",null,"全局演示配置")],-1)),h("div",d0,[h("div",u0,[h("div",f0,[h("div",h0,[le(de,{name:"palette"}),w[32]||(w[32]=h("span",null,"幻灯片主题",-1))])])]),h("div",p0,[(J(),X(Je,null,At(f,(_,O)=>h("button",{key:_.value,type:"button",class:xe(["spm-theme-card b3-tooltips",["is-"+_.value,O===0?"b3-tooltips__ne":O===f.length-1?"b3-tooltips__nw":"b3-tooltips__n",{active:e.docTheme===_.value}]]),"aria-label":_.desc,onClick:H=>A.$emit("update:docTheme",_.value)},[h("span",{class:xe(["spm-theme-card-preview","theme-preview--"+_.value]),"aria-hidden":"true"},[w[33]||(w[33]=mt('<span class="spm-theme-card-canvas"><span class="spm-theme-card-title">Aa</span><span class="spm-theme-card-lines"><span class="spm-theme-card-line is-primary"></span><span class="spm-theme-card-line is-secondary"></span></span></span>',1)),e.docTheme===_.value?(J(),X("span",g0,"✓")):Ae("",!0)],2),h("span",y0,ve(_.label),1)],10,m0)),64))])]),h("div",b0,[h("div",v0,[h("div",k0,[h("div",w0,[le(de,{name:"palette"}),w[34]||(w[34]=h("span",null,"演示背景",-1))])])]),h("div",x0,[(J(),X(Je,null,At(k,_=>h("button",{key:_.value||"__default__",type:"button",class:xe(["spm-bg-swatch b3-tooltips b3-tooltips__n",{active:(e.docBackground||"")===_.value,"is-default":!_.value}]),"aria-label":_.desc,onClick:O=>A.$emit("update:docBackground",_.value)},[h("span",{class:"spm-bg-swatch-preview",style:oo(x(_.value))},[h("span",{class:xe(["spm-bg-swatch-aa","is-"+_.mode])},"Aa",2),(e.docBackground||"")===_.value?(J(),X("span",_0,"✓")):Ae("",!0)],4),h("span",C0,ve(_.label),1)],10,S0)),64))]),h("div",I0,[h("span",{class:"spm-bg-input-preview",style:oo(x(e.docBackground||"")),"aria-hidden":"true"},null,4),h("input",{value:e.docBackground||"",class:"spm-input spm-bg-input",placeholder:"自定义：#hex / gradient / assets/...",onInput:w[0]||(w[0]=_=>A.$emit("update:docBackground",_.target.value)),onChange:w[1]||(w[1]=_=>A.$emit("update:docBackground",_.target.value))},null,40,$0),e.docBackground?(J(),X("button",{key:0,type:"button",class:"spm-bg-input-clear b3-tooltips b3-tooltips__nw","aria-label":"清除并恢复默认背景",onClick:w[2]||(w[2]=_=>A.$emit("update:docBackground",""))}," ✕ ")):Ae("",!0)])]),h("div",T0,[h("div",A0,[h("div",M0,[h("div",E0,[le(de,{name:"ratio"}),w[35]||(w[35]=h("span",null,"画幅比例",-1))])])]),h("div",B0,[h("button",{class:xe(["spm-segmented-item",{active:e.docAspectRatio==="16/9"}]),onClick:w[3]||(w[3]=_=>A.$emit("update:docAspectRatio","16/9"))}," 16 : 9 (宽屏) ",2),h("button",{class:xe(["spm-segmented-item",{active:e.docAspectRatio==="4/3"}]),onClick:w[4]||(w[4]=_=>A.$emit("update:docAspectRatio","4/3"))}," 4 : 3 (标屏) ",2),h("button",{class:xe(["spm-segmented-item",{active:e.docAspectRatio==="16/10"}]),onClick:w[5]||(w[5]=_=>A.$emit("update:docAspectRatio","16/10"))}," 16 : 10 ",2)])]),h("div",L0,[h("div",D0,[h("div",O0,[h("div",N0,[le(de,{name:"ratio"}),w[36]||(w[36]=h("span",null,"间距风格",-1))])])]),h("div",P0,[h("button",{class:xe(["spm-segmented-item b3-tooltips b3-tooltips__se",{active:(e.docSpacing||"normal")==="compact"}]),"aria-label":"紧凑排版：外衬 16/28px，块距 8px，行高 1.45",onClick:w[6]||(w[6]=_=>A.$emit("update:docSpacing","compact"))}," 紧凑 ",2),h("button",{class:xe(["spm-segmented-item b3-tooltips b3-tooltips__s",{active:(e.docSpacing||"normal")==="normal"}]),"aria-label":"标准排版：外衬 32/48px，块距 14px，行高 1.60（推荐默认）",onClick:w[7]||(w[7]=_=>A.$emit("update:docSpacing","normal"))}," 标准 ",2),h("button",{class:xe(["spm-segmented-item b3-tooltips b3-tooltips__sw",{active:(e.docSpacing||"normal")==="loose"}]),"aria-label":"宽松排版：外衬 52/72px，块距 22px，行高 1.75",onClick:w[8]||(w[8]=_=>A.$emit("update:docSpacing","loose"))}," 宽松 ",2)])]),h("div",R0,[h("div",z0,[h("div",H0,[h("div",F0,[le(de,{name:"transition"}),w[37]||(w[37]=h("span",null,"全局默认转场",-1))])])]),le(xc,{"model-value":e.docDefaultTransition,"hide-header":!0,onChange:w[9]||(w[9]=_=>A.$emit("update:docDefaultTransition",_))},null,8,["model-value"])]),h("div",j0,[w[48]||(w[48]=h("div",{class:"spm-control-header"},[h("div",{class:"spm-control-title-group"},[h("span",{class:"spm-control-title"},"演示全局操作")])],-1)),h("div",U0,[h("button",{class:"spm-btn-action b3-tooltips b3-tooltips__se","aria-label":"在当前文档下方开启分屏同步预览 (Alt+P)",onClick:w[10]||(w[10]=_=>A.$emit("openBottomPreview"))},[le(de,{name:"split-preview"}),w[38]||(w[38]=h("span",null,"分屏预览",-1))]),ue(Ot)("presenterMode")?(J(),X("button",{key:0,class:"spm-btn-action b3-tooltips b3-tooltips__sw","aria-label":"打开双屏演讲者控制台视窗 (Alt+M)",onClick:w[11]||(w[11]=_=>A.$emit("openPresenter"))},[le(de,{name:"presenter"}),w[39]||(w[39]=h("span",null,"演讲者视图",-1))])):Ae("",!0),ue(Ot)("aiScript")?(J(),X("button",{key:1,class:"spm-btn-action b3-tooltips b3-tooltips__se","aria-label":"智能分析长文本大纲与篇幅，自动插入分页线",onClick:w[12]||(w[12]=_=>A.$emit("aiAutoSplit"))},[le(de,{name:"sparkles"}),w[40]||(w[40]=h("span",null,"智能分页",-1))])):Ae("",!0),ue(Ot)("aiScript")?(J(),X("button",{key:2,class:"spm-btn-action spm-btn-danger b3-tooltips b3-tooltips__sw","aria-label":"一键清除当前文档中的所有幻灯片分页线（需二次确认）",disabled:e.isBatchProcessing,onClick:w[13]||(w[13]=_=>A.$emit("clearDividers"))},[le(de,{name:"trash"}),w[41]||(w[41]=h("span",null,"清除分页",-1))],8,W0)):Ae("",!0),h("button",{class:"spm-btn-action b3-tooltips b3-tooltips__se","aria-label":"自动为正文各页标题及首块之外的后续内容块配置顺延 (+1) 逐步呈现动效",disabled:e.isBatchProcessing,onClick:w[14]||(w[14]=_=>A.$emit("autoAnimate"))},[le(de,{name:"step"}),w[42]||(w[42]=h("span",null,"智能动效",-1))],8,q0),h("button",{class:"spm-btn-action spm-btn-danger b3-tooltips b3-tooltips__sw","aria-label":"清除所有页面内容块的逐步显现与入场微动效配置（需二次确认）",disabled:e.isBatchProcessing,onClick:w[15]||(w[15]=_=>A.$emit("clearAnimations"))},[le(de,{name:"trash"}),w[43]||(w[43]=h("span",null,"清除动效",-1))],8,V0),h("button",{class:"spm-btn-action b3-tooltips b3-tooltips__se","aria-label":"识别已有候选讲稿并为空白页新增默认讲稿块（不会重复添加）",disabled:e.isBatchProcessing,onClick:w[16]||(w[16]=_=>A.$emit("addOrIdentifyNotes"))},[le(de,{name:"notes"}),w[44]||(w[44]=h("span",null,"增加讲稿块",-1))],8,K0),h("button",{class:"spm-btn-action spm-btn-danger b3-tooltips b3-tooltips__sw","aria-label":"物理删除文档中所有页面的全部讲稿备注块（需二次确认）",disabled:e.isBatchProcessing,onClick:w[17]||(w[17]=_=>A.$emit("clearNotes"))},[le(de,{name:"trash"}),w[45]||(w[45]=h("span",null,"清除讲稿块",-1))],8,G0),ue(Ot)("exportHtml")?(J(),X("button",{key:3,class:"spm-btn-action b3-tooltips b3-tooltips__se","aria-label":"打包导出离线单文件 HTML 幻灯片",onClick:w[18]||(w[18]=_=>A.$emit("exportHtml"))},[le(de,{name:"export-html"}),w[46]||(w[46]=h("span",null,"导出 HTML",-1))])):Ae("",!0),ue(Ot)("exportPdf")?(J(),X("button",{key:4,class:"spm-btn-action b3-tooltips b3-tooltips__sw","aria-label":"打印生成 16:9 高清演示 PDF 讲义",onClick:w[19]||(w[19]=_=>A.$emit("exportPdf"))},[le(de,{name:"export-pdf"}),w[47]||(w[47]=h("span",null,"导出 PDF",-1))])):Ae("",!0)])]),h("div",{class:xe(["spm-advanced-menu",{"is-expanded":s.value}])},[h("button",{type:"button",class:"spm-advanced-toggle","aria-expanded":s.value,onClick:w[20]||(w[20]=_=>s.value=!s.value)},[h("span",Z0,[le(de,{name:"settings"}),w[49]||(w[49]=h("span",null,"高级设置",-1))]),le(de,{name:"chevron-right",class:"spm-advanced-chevron"})],8,Y0),s.value?(J(),X("div",J0,[h("div",X0,[h("div",Q0,[h("div",ek,[h("div",tk,[le(de,{name:"external-link"}),w[50]||(w[50]=h("span",null,"本地网络伺服预览",-1))])]),h("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":ue(i).enableWebServeJump?"关闭本地网络伺服预览":"开启本地网络伺服预览"},[h("input",{type:"checkbox",checked:ue(i).enableWebServeJump,onChange:w[21]||(w[21]=_=>p(_.target.checked))},null,40,ik),w[51]||(w[51]=h("span",{class:"spm-switch-slider"},null,-1))],8,ok)]),ue(i).enableWebServeJump?(J(),X("div",nk,[h("input",{value:ue(i).webServeUrl,class:"spm-input",placeholder:"http://127.0.0.1:6806",spellcheck:"false",onKeydown:w[22]||(w[22]=io(()=>{},["stop"])),onKeyup:w[23]||(w[23]=io(()=>{},["stop"])),onInput:w[24]||(w[24]=_=>g(_.target.value)),onChange:w[25]||(w[25]=_=>y(_.target.value))},null,40,sk)])):Ae("",!0)]),h("div",rk,[h("div",lk,[h("div",ak,[h("div",ck,[le(de,{name:"type"}),w[52]||(w[52]=h("span",null,"固定特定标题大小",-1))])]),h("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":ue(i).normalizeHeadingSizes?"关闭固定特定标题大小":"开启固定特定标题大小"},[h("input",{type:"checkbox",checked:ue(i).normalizeHeadingSizes,onChange:w[26]||(w[26]=_=>d(_.target.checked))},null,40,uk),w[53]||(w[53]=h("span",{class:"spm-switch-slider"},null,-1))],8,dk)])]),h("div",fk,[h("div",hk,[h("div",pk,[h("div",mk,[le(de,{name:"list"}),w[54]||(w[54]=h("span",null,"列表前缀标记",-1))])])]),h("div",gk,[h("div",yk,[w[56]||(w[56]=h("span",{style:{"font-size":"12px",color:"var(--b3-theme-on-surface)"}},"无序圆点",-1)),h("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":ue(i).showUnorderedListMarkers?"关闭无序列表圆点显示":"开启无序列表圆点显示"},[h("input",{type:"checkbox",checked:ue(i).showUnorderedListMarkers,onChange:w[27]||(w[27]=_=>b(_.target.checked))},null,40,vk),w[55]||(w[55]=h("span",{class:"spm-switch-slider"},null,-1))],8,bk)]),h("div",kk,[w[58]||(w[58]=h("span",{style:{"font-size":"12px",color:"var(--b3-theme-on-surface)"}},"有序序号",-1)),h("label",{class:"spm-switch b3-tooltips b3-tooltips__w","aria-label":ue(i).showOrderedListMarkers?"关闭有序列表序号显示":"开启有序列表序号显示"},[h("input",{type:"checkbox",checked:ue(i).showOrderedListMarkers,onChange:w[28]||(w[28]=_=>m(_.target.checked))},null,40,xk),w[57]||(w[57]=h("span",{class:"spm-switch-slider"},null,-1))],8,wk)])])]),h("div",Sk,[h("div",_k,[h("div",Ck,[h("div",Ik,[le(de,{name:"sparkles"}),w[59]||(w[59]=h("span",null,"AI 演讲提词服务",-1))])]),h("button",{type:"button",class:"spm-btn-icon b3-tooltips b3-tooltips__w","aria-label":"打开完整设置弹窗",onClick:l},[le(de,{name:"settings"})])]),ue(n)?(J(),X("div",$k,[w[60]||(w[60]=St(" 💡 通用 AI API 已由 ",-1)),w[61]||(w[61]=h("strong",null,"API 旋钮 (siyuan-api-switch)",-1)),St(" 接管 (Profile: "+ve(ue(n).profileName||"未命名")+")。相关输入框已置灰只读。 ",1)])):Ae("",!0),h("div",Tk,[h("div",Ak,[w[62]||(w[62]=h("span",{style:{"font-size":"12px","min-width":"60px",color:"var(--b3-theme-on-surface)"}},"模型:",-1)),h("input",{value:ue(n)?ue(n).model:ue(i).aiConfig.model,class:"spm-input",disabled:!!ue(n),placeholder:"例如 deepseek-chat",onChange:w[29]||(w[29]=_=>r(_.target.value))},null,40,Mk)]),h("div",Ek,[w[63]||(w[63]=h("span",{style:{"font-size":"12px","min-width":"60px",color:"var(--b3-theme-on-surface)"}},"Base URL:",-1)),h("input",{value:ue(n)?ue(n).baseUrl:ue(i).aiConfig.baseUrl,class:"spm-input",disabled:!!ue(n),placeholder:"https://api.openai.com/v1",onChange:w[30]||(w[30]=_=>a(_.target.value))},null,40,Bk)]),h("div",Lk,[w[64]||(w[64]=h("span",{style:{"font-size":"12px","min-width":"60px",color:"var(--b3-theme-on-surface)"}},"API Key:",-1)),h("input",{value:ue(n)?ue(n).apiKey:ue(i).aiConfig.apiKey,type:"password",class:"spm-input",disabled:!!ue(n),placeholder:"sk-...",onChange:w[31]||(w[31]=_=>c(_.target.value))},null,40,Dk)])])])])):Ae("",!0)],2)]))}}),Nk=/\.(?:png|jpe?g|gif|svg|webp|avif|ico|bmp|tiff?|mp4|webm|mp3|wav|ogg)$/i,Pk=/\.(?:ts|js|mjs|cjs|jsx|tsx|vue|json|css|scss|less|html|py|rs|go|java|c|cpp|h|sh|bash|yaml|yml|toml)$/i;async function Rk(e){const t=await mc.loadAsync(e),o={},i=[];let n="",s="";const l=[];t.forEach((a,c)=>{!c.dir&&!a.startsWith("__MACOSX")&&!a.includes("node_modules/")&&l.push({path:a,file:c})});let r=l.find(a=>a.path.toLowerCase()==="slides.md");r||(r=l.find(a=>a.path.toLowerCase().endsWith("/slides.md"))),r||(r=l.find(a=>a.path.toLowerCase().endsWith(".md"))),r&&(n=await r.file.async("string"),s=r.path);for(const a of l){const c=a.path;if(c.toLowerCase().endsWith(".md")||Pk.test(c)||c.includes("snippets/")){const u=await a.file.async("string");o[c]=u;const f=c.split("/");f.length>1&&(o[f.slice(1).join("/")]=u)}else if(Nk.test(c)){const u=await a.file.async("uint8array"),f=c.split("/").pop()||c,p=typeof Blob<"u"?new Blob([u]):void 0;i.push({zipPath:c,fileName:f,data:u,blob:p})}}return{entryMarkdown:n,entryMarkdownPath:s,virtualFiles:o,assets:i}}function zk(e,t){if(Object.keys(t).length===0)return e;function o(n){const s=n.trim().replace(/^['"]|['"]$/g,""),l=s.split("/").pop()||s;if(t[s])return t[s];const r=s.replace(/^\.?\//,"");return t[r]?t[r]:t[l]?t[l]:null}function i(n){let s=n;return s=s.replace(/!\[(.*?)\]\((.*?)\)/g,(l,r,a)=>{const c=o(a);return c?`![${r}](${c})`:l}),s=s.replace(/\bsrc=["'](.*?)["']/gi,(l,r)=>{const a=o(r);return a?`src="${a}"`:l}),s}for(const n of e.slides)if(n.rawMarkdown=i(n.rawMarkdown),n.pageAttrs["custom-slides-background"]){const s=n.pageAttrs["custom-slides-background"],l=o(s);l&&(n.pageAttrs["custom-slides-background"]=l)}if(e.flattenedMarkdown=i(e.flattenedMarkdown),e.docRootAttrs["custom-slides-background"]){const n=e.docRootAttrs["custom-slides-background"],s=o(n);s&&(e.docRootAttrs["custom-slides-background"]=s)}return e}const Hk={"snippets/external.ts":`// Inside ./snippets/external.ts
// #region snippet
export function emptyArray<T>(length: number) {
  return Array.from<T>({ length })
}
// #endregion snippet

export function sayHello() {
  console.log('Hello from snippets/external.ts')
}
`};function Sc(e){try{if(typeof process<"u"&&typeof require<"u"){const t=require("fs");if(t.existsSync(e))return t.readFileSync(e,"utf-8")}}catch{}return null}function Fk(e,t){const o=e.match(/^[ \t]*<<<[ \t]+([^\s]+)/);if(!o)return null;const i=o[1].trim(),n=i.indexOf("#"),s=n!==-1?i.slice(0,n):i,l=n!==-1?i.slice(n+1):"",r=s.replace(/^@\//,"").replace(/^\.\//,""),a=(t==null?void 0:t.virtualFiles)||{};let c=a[s]||a[r]||a[`./${r}`]||a[`@/${r}`];if(!c&&Object.keys(a).length>0){const d=r.split("/").pop();for(const[b,m]of Object.entries(a))if(b.endsWith(`/${r}`)||d&&b.endsWith(`/${d}`)){c=m;break}}if(!c){const d=[];if(t!=null&&t.baseDir)try{const b=require("path");d.push(b.resolve(t.baseDir,r)),d.push(b.resolve(t.baseDir,s))}catch{}try{const b=require("path");d.push(b.resolve(process.cwd(),r))}catch{}for(const b of d){const m=Sc(b);if(m!==null){c=m;break}}}if(!c){const d=Hk||{};if(c=d[s]||d[r]||d[`snippets/${r}`],!c){const b=r.split("/").pop();for(const[m,g]of Object.entries(d))if(m.endsWith(`/${r}`)||b&&m.endsWith(`/${b}`)){c=g;break}}}if(!c)return null;let u=c;if(l){const d=new RegExp(`(?:\\/\\/|\\/\\*|#)?\\s*#(?:region|REGION)\\s+${l}[^\\r\\n]*\\r?\\n([\\s\\S]*?)(?:\\/\\/|\\/\\*|#)?\\s*#(?:endregion|ENDREGION)\\s+${l}`,"i"),b=c.match(d);if(b){const m=c.match(/^(\/\/\s*Inside[^\r\n]+\r?\n)/i);u=(m?m[1]:"")+b[1].trimEnd()}}const f=r.match(/\.([a-zA-Z0-9]+)$/);return`\`\`\`${f?f[1]:""}
${u}
\`\`\``}function jk(e){let t=!1,o=!1;for(let i=0;i<e.length;i++){const n=e[i];if(n==="'"&&!o)t=!t;else if(n==='"'&&!t)o=!o;else if(n==="#"&&!t&&!o)return e.slice(0,i).trim()}return e.trim()}function _n(e){const t={},o=e.split(/\r?\n/);let i=0;for(;i<o.length;){const n=o[i],s=n.trim();if(!s||s.startsWith("#")){i++;continue}const l=n.indexOf(":");if(l>0){const r=n.slice(0,l).trim();let a=n.slice(l+1).trim();if(a==="|"||a===">"){i++;const c=[];let u=-1;for(;i<o.length;){const f=o[i];if(!f.trim()){c.push(""),i++;continue}const d=f.match(/^(\s+)/),b=d?d[1].length:0;if(u===-1&&(u=b),b<u)break;c.push(f.slice(u)),i++}for(;c.length>0&&c[c.length-1]==="";)c.pop();t[r]=a===">"?c.join(" "):c.join(`
`);continue}if(a=jk(a),!a){let c=i+1;const u=[];let f=-1;for(;c<o.length;){const p=o[c],d=p.trim();if(!d||d.startsWith("#")){f!==-1&&u.push(""),c++;continue}const b=p.match(/^(\s+)/),m=b?b[1].length:0;if(f===-1)if(m>0)f=m;else break;if(m<f)break;u.push(p.slice(f)),c++}if(u.length>0){t[r]=_n(u.join(`
`)),i=c;continue}}a.startsWith('"')&&a.endsWith('"')||a.startsWith("'")&&a.endsWith("'")?a=a.slice(1,-1):a==="true"?a=!0:a==="false"?a=!1:a==="null"?a=null:/^-?\d+(?:\.\d+)?$/.test(a)&&(a=Number(a)),t[r]=a}i++}return t}const Uk=/^\s*```ya?ml([\s\S]*?)```/;function Ol(e){let t={},o=e.trim();const i=o.match(/^---[^\n\r]*\r?\n([\s\S]*?)\r?\n---(?=[ \t]*(?:\r?\n|$))/);if(i&&!i[1].includes("```")){const s=_n(i[1]);if(Object.keys(s).length>0||!i[1].trim())return t=s,o=o.slice(i[0].length).trim(),{frontmatter:t,content:o}}if(o.startsWith("---")){const s=o.match(/^---[^\n\r]*(?:\r?\n|$)/);s&&(o=o.slice(s[0].length).trim())}const n=o.match(Uk);if(n)t=_n(n[1]),o=o.slice(n[0].length).trim();else{const s=o.split(/\r?\n/),l=[];let r=0;for(let a=0;a<s.length;a++){const c=s[a].trim();if(!c){if(l.length>0){r=a+1;break}continue}if(/^[a-zA-Z0-9_-]+\s*:\s*.*/.test(c)&&!c.startsWith("<")&&!c.startsWith("#"))l.push(c);else{r=a;break}}l.length>0&&(t=_n(l.join(`
`)),o=s.slice(r).join(`
`).trim())}return{frontmatter:t,content:o}}function Wk(e){const t=e.split(/\r?\n/),o=[];let i=0,n=!1;function s(l){if(i>=l)return;const r=t.slice(i,l).join(`
`).trim();r&&o.push(r),i=l+1}for(let l=0;l<t.length;l++){const a=t[l].trimEnd();if(n){a.includes("-->")&&(n=!1);continue}if(a.startsWith("<!--")){a.includes("-->")||(n=!0);continue}if(a.startsWith("---")){s(l);const c=t[l+1];let u=!1,f=-1;const p=c?c.trim():"";if(a.replace(/^-+/,"").trim()===""&&p.length>0){for(let d=l+1;d<t.length;d++){const b=t[d].trimEnd();if(b.startsWith("```"))break;if(b==="---"){f=d;break}}f!==-1&&f-l<=60&&t.slice(l+1,f).some(m=>{const g=m.trim();return g.length>0&&!g.startsWith("#")&&/^[a-zA-Z0-9_$-]+\s*:\s*.*/.test(g)})&&(u=!0)}u&&f!==-1&&(i=l,l=f)}else if(a.trimStart().startsWith("```")){const c=a.match(/^\s*`+/),u=c?c[0].trim():"```";let f=l+1;for(;f<t.length&&!t[f].trimStart().startsWith(u);f++);f<t.length&&(l=f)}}return i<t.length&&s(t.length),o}function Cn(e,t={}){const{stripNotesFromMarkdown:o=!0,cleanVClicks:i=!0,cleanShikiLines:n=!0,cleanSlots:s=!0,isolateStyleTags:l=!0,cleanHtmlToMarkdown:r=!0,wrapSuperBlocks:a=!0,virtualFiles:c={}}=t;let u=e;u&&!u.trimStart().startsWith("---")&&(u=`---

${u.trimStart()}`);const f=Wk(u),p={};let d="",b="",m=0;if(f.length>0){const F=f[0],E=Ol(F),D=Object.keys(E.frontmatter).length>0,S=E.content.length>0;D&&!S&&f.length>1?(m=1,y(E.frontmatter)):D&&y(E.frontmatter)}function g(F,E,D){const S=String(F);S==="two-cols-header"?E[be]="cols-header":S==="three-cols-header"?(E[be]="cols-header",!D.layoutRatio&&!D["layout-ratio"]&&(E[yt]="1:1:1")):E[be]=S}function y(F){d=F.title||"",F.theme&&(p[Vi]=String(F.theme)),F.aspectRatio&&(p[Ki]=String(F.aspectRatio)),F.transition&&(p[Gi]=String(F.transition)),F.colorSchema&&(p[ql]=String(F.colorSchema)),F.layout&&g(F.layout,p,F),F.background&&(p[ct]=String(F.background)),F.image&&(p[Wt]=String(F.image)),F.class&&(p[ai]=String(F.class));for(const[E,D]of Object.entries(F))["theme","aspectRatio","highlighter","transition","colorSchema","title","layout","background","image","class"].includes(E)||(p[`custom-slides-${E}`]=typeof D=="object"?JSON.stringify(D):String(D))}const k=[];let x=0,$=0,A=0,w=0;const _=new Set,O={};let H=1;for(let F=m;F<f.length;F++){const E=f[F],{frontmatter:D,content:S}=Ol(E),q=E.match(/^\s*(?:---\s*)?src:\s*([^\n\r]+)/m),j=D.src||(q?q[1]:void 0);if(j){const R=String(j).trim().replace(/^['"]|['"]$/g,"");let ne=c[R]||c[R.replace(/^\.\//,"")]||c[`pages/${R.replace(/^.*pages\//,"")}`];if(!ne){const U=R.replace(/^\.\//,""),v=[];if(t.baseDir)try{const W=require("path");v.push(W.resolve(t.baseDir,U)),v.push(W.resolve(t.baseDir,R))}catch{}try{const W=require("path");v.push(W.resolve(process.cwd(),U)),v.push(W.resolve(process.cwd(),R))}catch{}for(const W of v){const z=Sc(W);if(z!==null){ne=z;break}}}const L={};D.layout&&g(D.layout,L,D),D.transition&&(L[_t]=String(D.transition)),D.background&&(L[ct]=String(D.background)),D.image&&(L[Wt]=String(D.image)),D.class&&(L[ai]=String(D.class));for(const[U,v]of Object.entries(D))["src","layout","transition","background","image","class"].includes(U)||(L[`custom-slides-${U}`]=typeof v=="object"?JSON.stringify(v):String(v));if(ne){const U=Cn(ne,{...t,virtualFiles:c});for(const v of U.slides){v.pageIndex=H++,v.pageAttrs={...L,...v.pageAttrs},k.push(v);const W=v.pageAttrs[be]||"default";O[W]=(O[W]||0)+1}continue}else{k.push({pageIndex:H++,pageAttrs:{...L,"custom-slides-src":R},notes:"",rawMarkdown:`> 📄 **引入外部幻灯片页面**: \`${R}\`
>
> *提示：如需展示该页面完整内容，请将关联子页面一同打包为 .zip 或通过本地工程导入。*`,hasVueComponent:!1,hasStyleTag:!1,assetReferences:[]});const U=L[be]||"default";O[U]=(O[U]||0)+1;continue}}const C={};D.layout&&g(D.layout,C,D),D.transition&&(C[_t]=String(D.transition)),D.background&&(C[ct]=String(D.background)),D.image&&(C[Wt]=String(D.image)),D.class&&(C[ai]=String(D.class)),D.mask&&(C[ci]=String(D.mask)),(D.maskRatio||D["mask-ratio"])&&(C[Jo]=String(D.maskRatio||D["mask-ratio"])),(D.maskStyle||D["mask-style"])&&(C[di]=String(D.maskStyle||D["mask-style"])),(D.maskInitial||D["mask-initial"])&&(C[ui]=String(D.maskInitial||D["mask-initial"]));for(const[R,ne]of Object.entries(D))["layout","transition","background","image","class","mask","maskRatio","mask-ratio","maskStyle","mask-style","maskInitial","mask-initial"].includes(R)||(C[`custom-slides-${R}`]=typeof ne=="object"?JSON.stringify(ne):String(ne));let M=S;const B=[];let te=M.replace(/(?:^[ \t]*(`{3,}|~{3,})[^\n\r]*\r?\n[\s\S]*?\r?\n[ \t]*\1(?=[ \t]*(?:\r?\n|$)))/gm,R=>{const ne=`__CODE_TOKEN_NOTE_${B.length}__`;return B.push(R),ne});te=te.replace(/(`+)(?:[^\n\r`]|(?!\1)`)+?\1/g,R=>{const ne=`__CODE_TOKEN_NOTE_${B.length}__`;return B.push(R),ne});let V="";const K=Array.from(te.matchAll(/<!--([\s\S]*?)-->/g));if(K.length>0){const R=K[K.length-1],ne=te.slice(R.index+R[0].length).trim();if(!ne||!ne.replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi,"").trim()){const U=R[1].trim();U.startsWith("TODO:")||(V=U,x++),o&&(te=te.slice(0,R.index).trimEnd()+te.slice(R.index+R[0].length))}}o&&(te=te.replace(/<!--(?![\s\S]*?TODO:)[\s\S]*?-->/g,"").trim());for(let R=0;R<B.length;R++)te=te.replace(`__CODE_TOKEN_NOTE_${R}__`,()=>B[R]);if(M=te,V){for(let L=0;L<B.length;L++)V=V.replace(`__CODE_TOKEN_NOTE_${L}__`,()=>B[L]);const ne=`> [!NOTE] 💡 演讲备注
${V.split(/\r?\n/).map(L=>`> ${L}`).join(`
`)}
{: custom-slides-note="true"}`;M=M?`${M}

${ne}`:ne}let ae=!1;if(/<style\b/i.test(M)){ae=!0;const R=M.match(/<style\b[^>]*>([\s\S]*?)<\/style>/gi);if(R){for(const ne of R){const L=ne.replace(/<style\b[^>]*>|<\/style>/gi,"").trim();b=b?`${b}

${L}`:L}l&&(M=M.replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi,"").trim())}}const oe=M.match(/<v-click[^>]*>|<v-clicks[^>]*>|v-click=/g);oe&&($+=oe.length);const re=M.match(/```\w+\s+\{[^}]+\}/g);re&&(A+=re.length);const Se=M.match(/::\w+::|<template\s+#[^>]+>/g);if(Se&&(w+=Se.length),M=M.replace(/^[ \t]*<<<[ \t]+([^\n\r]+)/gm,R=>Fk(R,{...t,virtualFiles:c})||R),i&&(M=M.replace(/<v-click(?:\s+at="[^"]*")?(?:\s+hide)?>\s*([\s\S]*?)\s*<\/v-click>/gi,"$1")),n&&(M=M.replace(/(^```\w+(?:[ \t]+\[[^\]]*\])?)[ \t]+\{[^}]+\}(?:[ \t]+\w+)?/gm,"$1"),M=M.replace(/^\$\$\s+\{[^}]+\}/gm,()=>"$$")),s&&(M=M.replace(/^::\w+::\s*$/gm,"")),r&&(M=xh(M)),a){let R=M.trim(),ne="";const L=R.lastIndexOf("> [!NOTE] 💡 演讲备注");if(L!==-1&&(ne=R.slice(L),R=R.slice(0,L).trim()),(D.layout==="image-left"||D.layout==="image-right")&&D.image){const U=String(D.image).trim(),v=D.layout==="image-left"?"image-left":"image-right",W=`![配图](${U})
{: custom-slides-layout="${v}" }`;D.layout==="image-left"?R=`{{{col

${W}

${R}

}}}`:R=`{{{col

${R}

${W}

}}}`}if(D.background){const v=`![背景图](${String(D.background).trim()})
{: custom-slides-role="background" }`;R=R?`${v}

${R}`:v}M=ne?`${R}

${ne}`:R}const $e=qk(M);C[ct]&&$e.push(C[ct]),C[Wt]&&$e.push(C[Wt]);for(const R of $e)_.add(R);const ke=/<[A-Z][a-zA-Z0-9]+/.test(M),_e=C[be]||(H===1?p[be]||"cover":"default");O[_e]=(O[_e]||0)+1,k.push({pageIndex:H++,pageAttrs:C,notes:V,rawMarkdown:M,hasVueComponent:ke,hasStyleTag:ae,assetReferences:$e})}if(!d&&k.length>0){const F=k[0].rawMarkdown.match(/^#\s+(.+)$/m);F&&(d=F[1].trim())}b&&(p["custom-slides-custom-css"]=b);let P=k.map(F=>`---

${F.rawMarkdown}`).join(`

`);return P.trimStart().startsWith("---")||(P=`---

${P.trimStart()}`),{docTitle:d||"Slidev 演示文稿",docRootAttrs:p,slides:k,totalSlides:k.length,stats:{totalNotes:x,totalVClicks:$,totalShikiHighlights:A,totalSlots:w,discoveredAssets:Array.from(_),layoutDistribution:O},flattenedMarkdown:P,customCss:b}}function qk(e){const t=[],o=/!\[.*?\]\((.*?)\)/g;let i;for(;(i=o.exec(e))!==null;){const s=i[1].split(/\s+/)[0].trim();s&&t.push(s)}const n=/<(?:img|video|source|audio)\b[^>]*src=["'](.*?)["']/gi;for(;(i=n.exec(e))!==null;){const s=i[1].trim();s&&t.push(s)}return t}function _c(e){if(!e)return!1;const t=String(e.type||"").toLowerCase(),o=String(e.markdown||"").trim(),i=String(e.content||"").trim();return t==="tb"||t==="thematic-break"||t==="nodethematicbreak"||o==="---"||o==="***"||i==="---"||i==="***"}function Vk(e){return(e.trim()||"Slidev 演示文稿").replace(/[\\/:*?"<>|]/g,"_")}async function Kk(e,t,o=ze){const i=e.filter(_c);let n=0;if(i.length>=t.length)for(let s=0;s<t.length;s++){const l=t[s],r=i[s];r&&r.id&&Object.keys(l.pageAttrs||{}).length>0&&(await o(r.id,l.pageAttrs),n++)}else for(let s=1;s<t.length;s++){const l=t[s],r=i[s-1];r&&r.id&&Object.keys(l.pageAttrs||{}).length>0&&(await o(r.id,l.pageAttrs),n++)}return n}async function Gk(e,t=ze){let o=!1,i=0;for(const n of e){if(_c(n)){o=!1;continue}const s=(n.markdown||n.content||"").trim();if(s==="::right::"||s.startsWith("::right::")){o=!0;continue}o&&n.id&&(await t(n.id,{[Te]:"right"}).catch(()=>{}),i++)}return i}async function Yk(e,t,o=Fl){const i={};if(!t||t.length===0)return i;const n=[];for(const s of t){const l=new File([s.data],s.fileName,{type:"application/octet-stream"});n.push(l)}try{const s=await o("/data/assets",n);if(s!=null&&s.succMap)for(const[l,r]of Object.entries(s.succMap))i[l]=String(r)}catch(s){console.warn("上传本地静态资产失败，保留原路径:",s)}return Object.keys(i).length>0&&zk(e,i),i}async function Zk(e){var k;const{presentation:t,notebookId:o,docTitle:i,extractedAssets:n=[],uploadAssets:s=!0,autoPreview:l=!0,plugin:r,api:a={}}=e,c=a.uploadFn||Fl,u=a.createDocFn||Md,f=a.setAttrsFn||ze,p=a.getChildBlocksFn||Si,d=a.openTabFn||ie.openTab,b=a.showMessageFn||ie.showMessage;s&&n.length>0&&await Yk(t,n,c);const m=Vk(i),g=`/${m}`,y=await u(o,g,t.flattenedMarkdown);if(!y)throw new Error("思源内核创建文档失败，未返回有效 DocumentId");try{const x=((k=t.slides[0])==null?void 0:k.pageAttrs)||{};await f(y,{...x,...t.docRootAttrs});const $=await p(y).catch(()=>[]);Array.isArray($)&&$.length>0&&(await Kk($,t.slides,f),await Gk($,f))}catch(x){console.warn("[SlidesImport] 版式属性回填阶段遇到警告:",x),b(`⚠️ 文档已创建(${m})，但部分版式属性回填未完全完成: ${x.message||String(x)}`,6e3)}return b(`🎉 成功导入 Slidev 演示文档《${m}》！`),l&&r&&(r.currentDocId=y,await d({app:r.app,doc:{id:y}}),r.openBottomPreviewTab&&r.openBottomPreviewTab()),y}function Jk(e){const t=pe("file"),o=pe(!1),i=pe(!1),n=pe(""),s=pe(null),l=pe(null),r=pe(""),a=pe(0),c=pe(""),u=pe([]),f=pe(null),p=pe(""),d=pe([]),b=pe(""),m=pe(!0),g=pe(!0),y=pe(!0),k=pe(!0),x=ye(()=>{const C=a.value;if(C===0)return"0 B";const M=1024,B=["B","KB","MB","GB"],te=Math.floor(Math.log(C)/Math.log(M));return`${(C/M**te).toFixed(1)} ${B[te]}`}),$=ye(()=>{var C;return((C=f.value)==null?void 0:C.docRootAttrs["custom-slides-theme"])||"default"}),A=ye(()=>{var C;return u.value.length>0?u.value.length:((C=f.value)==null?void 0:C.stats.discoveredAssets.length)||0}),w=ye(()=>{var M;const C=((M=f.value)==null?void 0:M.stats.layoutDistribution)||{};return Object.entries(C).map(([B,te])=>({name:B,count:te}))});async function _(C=Ad){try{const M=await C();M!=null&&M.notebooks&&Array.isArray(M.notebooks)&&(d.value=M.notebooks.filter(B=>!B.closed),d.value.length>0&&!b.value&&(b.value=d.value[0].id))}catch(M){console.warn("获取笔记本列表失败:",M)}}function O(){var C;(C=s.value)==null||C.click()}function H(){l.value=null,r.value="",a.value=0,f.value=null,u.value=[],n.value=""}let P=0;async function F(C){const M=++P;n.value="",l.value=C,r.value=C.name,a.value=C.size;try{if(C.name.toLowerCase().endsWith(".zip")){const te=await C.arrayBuffer();if(M!==P)return;const V=await Rk(te);if(M!==P)return;if(!V.entryMarkdown){n.value="未在 Zip 压缩包中找到 slides.md 或任何有效的 Markdown 入口文件";return}u.value=V.assets;const K=Cn(V.entryMarkdown,{stripNotesFromMarkdown:g.value,cleanHtmlToMarkdown:m.value,cleanSlots:!1,virtualFiles:V.virtualFiles});if(M!==P)return;f.value=K,p.value=K.docTitle||C.name.replace(/\.zip$/i,"")}else{const te=await C.text();if(M!==P)return;u.value=[];const V=C.path||"",K=V?V.replace(/[\\/][^\\/]+$/,""):"",ae=Cn(te,{stripNotesFromMarkdown:g.value,cleanHtmlToMarkdown:m.value,cleanSlots:!1,baseDir:K||void 0});if(M!==P)return;f.value=ae,p.value=ae.docTitle||C.name.replace(/\.md$/i,"")}}catch(B){if(M!==P)return;console.error("解析文件失败:",B),n.value=`解析文件失败: ${B.message||String(B)}`}}function E(){if(n.value="",!c.value.trim()){f.value=null;return}try{const C=Cn(c.value,{stripNotesFromMarkdown:g.value,cleanHtmlToMarkdown:m.value,cleanSlots:!1});f.value=C,p.value=C.docTitle||"Slidev 演示文稿"}catch(C){n.value=`解析 Markdown 源码失败: ${C.message||String(C)}`}}async function D(){l.value?await F(l.value):c.value&&E()}async function S(C){const M=C.target;M.files&&M.files[0]&&await F(M.files[0])}async function q(C){var M;o.value=!1,(M=C.dataTransfer)!=null&&M.files&&C.dataTransfer.files[0]&&await F(C.dataTransfer.files[0])}async function j(C=e){if(f.value){if(!b.value&&d.value.length>0&&(b.value=d.value[0].id),!b.value){n.value="请先选择目标笔记本";return}i.value=!0,n.value="";try{return await Zk({presentation:f.value,notebookId:b.value,docTitle:p.value,extractedAssets:u.value,uploadAssets:y.value,autoPreview:k.value,plugin:C})}catch(M){console.error("导入 Slidev 演示失败:",M),n.value=`导入执行失败: ${M.message||String(M)}`}finally{i.value=!1}}}return{inputMode:t,isDragging:o,isImporting:i,errorMessage:n,fileInputRef:s,selectedFile:l,selectedFileName:r,selectedFileSize:a,rawMarkdownText:c,extractedAssets:u,parsedPresentation:f,customDocTitle:p,notebooks:d,selectedNotebookId:b,optCleanHtml:m,optStripNotes:g,optUploadAssets:y,optAutoPreview:k,formattedFileSize:x,currentTheme:$,extractedAssetsCount:A,layoutChips:w,fetchNotebooks:_,triggerFileInput:O,clearFile:H,processFile:F,onFileSelected:S,onFileDrop:q,onTextChange:E,reprocessCurrentInput:D,handleConfirmImport:j}}const Xk={class:"spm-import-dialog"},Qk={class:"spm-tabs-header"},ew={class:"spm-dialog-body"},tw={key:0,class:"spm-file-section"},ow={key:0,class:"spm-dropzone-prompt"},iw={class:"spm-dropzone-icon"},nw={key:1,class:"spm-dropzone-active"},sw={class:"spm-file-badge"},rw={class:"spm-file-size"},lw={key:1,class:"spm-text-section"},aw={key:2,class:"spm-error-banner"},cw={key:3,class:"spm-preview-card"},dw={class:"spm-preview-card__header"},uw={style:{display:"inline-flex","align-items":"center",gap:"4px"}},fw={class:"spm-config-grid"},hw={class:"spm-form-item"},pw={class:"spm-form-item"},mw=["value"],gw={class:"spm-stats-grid"},yw={class:"spm-stat-box"},bw={class:"spm-stat-value"},vw={class:"spm-stat-box"},kw={class:"spm-stat-value"},ww={class:"spm-stat-box"},xw={class:"spm-stat-value"},Sw={class:"spm-stat-box"},_w={class:"spm-stat-value"},Cw={key:0,class:"spm-chips-row"},Iw={class:"spm-options-group"},$w={class:"spm-checkbox-label"},Tw={class:"spm-checkbox-label"},Aw={class:"spm-checkbox-label"},Mw={class:"spm-checkbox-label"},Ew={class:"spm-dialog-footer"},Bw=["disabled"],Lw=["disabled"],Dw={key:0,style:{display:"inline-flex","align-items":"center",gap:"4px"}},Ow={key:1,style:{display:"inline-flex","align-items":"center",gap:"4px"}},Nw=zt({__name:"SlidesImportDialog",emits:["close","success"],setup(e,{emit:t}){const o=t,i=Kt("plugin"),{inputMode:n,isDragging:s,isImporting:l,errorMessage:r,fileInputRef:a,selectedFileName:c,rawMarkdownText:u,extractedAssetsCount:f,parsedPresentation:p,customDocTitle:d,notebooks:b,selectedNotebookId:m,optCleanHtml:g,optStripNotes:y,optUploadAssets:k,optAutoPreview:x,formattedFileSize:$,currentTheme:A,layoutChips:w,fetchNotebooks:_,triggerFileInput:O,clearFile:H,onFileSelected:P,onFileDrop:F,onTextChange:E,reprocessCurrentInput:D,handleConfirmImport:S}=Jk(i);ti(async()=>{await _()});async function q(){const C=await S();C&&(o("success",{docId:C}),o("close"))}function j(){o("close")}return(C,M)=>(J(),X("div",{class:"spm-modal-overlay",onClick:io(j,["self"])},[h("div",Xk,[h("div",{class:"spm-dialog-header"},[M[18]||(M[18]=h("div",{class:"spm-dialog-title"},[h("svg",{class:"spm-dialog-icon","aria-hidden":"true"},[h("use",{"xlink:href":"#iconSlides"})]),h("span",null,"导入 Slidev 演示文档")],-1)),h("button",{class:"spm-close-btn",title:"关闭",onClick:j},"✕")]),h("div",Qk,[h("button",{class:xe(["spm-tab-btn",{active:ue(n)==="file"}]),onClick:M[0]||(M[0]=B=>n.value="file")},[le(de,{name:"package"}),M[19]||(M[19]=h("span",null,"文件 / 压缩包导入 (.zip / .md)",-1))],2),h("button",{class:xe(["spm-tab-btn",{active:ue(n)==="text"}]),onClick:M[1]||(M[1]=B=>n.value="text")},[le(de,{name:"notes"}),M[20]||(M[20]=h("span",null,"粘贴 Markdown 源码",-1))],2)]),h("div",ew,[ue(n)==="file"?(J(),X("div",tw,[h("div",{class:xe(["spm-dropzone",{dragover:ue(s),"has-file":!!ue(c)}]),onDragover:M[4]||(M[4]=io(B=>s.value=!0,["prevent"])),onDragleave:M[5]||(M[5]=io(B=>s.value=!1,["prevent"])),onDrop:M[6]||(M[6]=io((...B)=>ue(F)&&ue(F)(...B),["prevent"])),onClick:M[7]||(M[7]=(...B)=>ue(O)&&ue(O)(...B))},[h("input",{ref_key:"fileInputRef",ref:a,type:"file",accept:".zip,.md",class:"spm-hidden-input",onChange:M[2]||(M[2]=(...B)=>ue(P)&&ue(P)(...B))},null,544),ue(c)?(J(),X("div",nw,[h("span",sw,[le(de,{name:"notes"}),St(" "+ve(ue(c)),1)]),h("span",rw,"("+ve(ue($))+")",1),h("button",{class:"spm-btn-text",onClick:M[3]||(M[3]=io((...B)=>ue(H)&&ue(H)(...B),["stop"]))},"更换文件")])):(J(),X("div",ow,[h("span",iw,[le(de,{name:"folder",style:{"font-size":"32px"}})]),M[21]||(M[21]=h("p",{class:"spm-dropzone-text"},"点击选择文件，或直接拖拽文件至此处",-1)),M[22]||(M[22]=h("p",{class:"spm-dropzone-hint"},[St(" 支持 Slidev 完整工程 "),h("strong",null,".zip"),St("（自动解包 public/ 静态素材）或单文件 "),h("strong",null,".md")],-1))]))],34)])):(J(),X("div",lw,[Ut(h("textarea",{"onUpdate:modelValue":M[8]||(M[8]=B=>ot(u)?u.value=B:null),class:"spm-textarea spm-source-editor",rows:"8",placeholder:"在此直接粘贴包含 Frontmatter 的 Slidev slides.md 源码...",onInput:M[9]||(M[9]=(...B)=>ue(E)&&ue(E)(...B))},null,544),[[Ws,ue(u)]])])),ue(r)?(J(),X("div",aw," ⚠️ "+ve(ue(r)),1)):Ae("",!0),ue(p)?(J(),X("div",cw,[h("div",dw,[h("span",uw,[le(de,{name:"sparkles"}),M[23]||(M[23]=St(" 演示解析摘要",-1))]),M[24]||(M[24]=h("span",{class:"spm-badge-success"},"预检就绪",-1))]),h("div",fw,[h("div",hw,[M[25]||(M[25]=h("label",{class:"spm-form-label"},"笔记文档标题",-1)),Ut(h("input",{"onUpdate:modelValue":M[10]||(M[10]=B=>ot(d)?d.value=B:null),class:"spm-input",placeholder:"思源新文档标题"},null,512),[[Ws,ue(d)]])]),h("div",pw,[M[26]||(M[26]=h("label",{class:"spm-form-label"},"存放目标笔记本",-1)),Ut(h("select",{"onUpdate:modelValue":M[11]||(M[11]=B=>ot(m)?m.value=B:null),class:"spm-select"},[(J(!0),X(Je,null,At(ue(b),B=>(J(),X("option",{key:B.id,value:B.id},ve(B.name),9,mw))),128))],512),[[th,ue(m)]])])]),h("div",gw,[h("div",yw,[h("span",bw,ve(ue(p).totalSlides),1),M[27]||(M[27]=h("span",{class:"spm-stat-label"},"幻灯片页数",-1))]),h("div",vw,[h("span",kw,ve(ue(A)),1),M[28]||(M[28]=h("span",{class:"spm-stat-label"},"演示主题",-1))]),h("div",ww,[h("span",xw,ve(ue(p).stats.totalNotes),1),M[29]||(M[29]=h("span",{class:"spm-stat-label"},"演讲者提词",-1))]),h("div",Sw,[h("span",_w,ve(ue(f)),1),M[30]||(M[30]=h("span",{class:"spm-stat-label"},"关联本地素材",-1))])]),ue(w).length>0?(J(),X("div",Cw,[M[31]||(M[31]=h("span",{class:"spm-chips-label"},"页面版式分布：",-1)),(J(!0),X(Je,null,At(ue(w),B=>(J(),X("span",{key:B.name,class:"spm-chip-badge"},ve(B.name)+": "+ve(B.count),1))),128))])):Ae("",!0),h("div",Iw,[h("label",$w,[Ut(h("input",{"onUpdate:modelValue":M[12]||(M[12]=B=>ot(g)?g.value=B:null),type:"checkbox",onChange:M[13]||(M[13]=(...B)=>ue(D)&&ue(D)(...B))},null,544),[[pn,ue(g)]]),M[32]||(M[32]=h("span",null,"智能剥离展示型 HTML 容器为干净原生的 Markdown 笔记块",-1))]),h("label",Tw,[Ut(h("input",{"onUpdate:modelValue":M[14]||(M[14]=B=>ot(y)?y.value=B:null),type:"checkbox",onChange:M[15]||(M[15]=(...B)=>ue(D)&&ue(D)(...B))},null,544),[[pn,ue(y)]]),M[33]||(M[33]=h("span",null,"提取演讲者提词到块属性并保持正文笔记清爽",-1))]),h("label",Aw,[Ut(h("input",{"onUpdate:modelValue":M[16]||(M[16]=B=>ot(k)?k.value=B:null),type:"checkbox"},null,512),[[pn,ue(k)]]),M[34]||(M[34]=h("span",null,"自动上传关联素材至思源资产库并重写路径 (assets/...)",-1))]),h("label",Mw,[Ut(h("input",{"onUpdate:modelValue":M[17]||(M[17]=B=>ot(x)?x.value=B:null),type:"checkbox"},null,512),[[pn,ue(x)]]),M[35]||(M[35]=h("span",null,"导入后自动打开新文档并开启下方分屏放映预览",-1))])])])):Ae("",!0)]),h("div",Ew,[h("button",{class:"spm-btn-secondary",disabled:ue(l),onClick:j}," 取消 ",8,Bw),h("button",{class:"spm-btn-primary",disabled:!ue(p)||ue(l),onClick:q},[ue(l)?(J(),X("span",Dw,[le(de,{name:"refresh"}),M[36]||(M[36]=St(" 正在导入生成中...",-1))])):(J(),X("span",Ow,[le(de,{name:"rocket"}),M[37]||(M[37]=St(" 确认导入思源笔记",-1))]))],8,Lw)])])]))}}),Pw=lo(Nw,[["__scopeId","data-v-c56a3d7e"]]);function Ir(e){return e?e==="NodeThematicBreak"||e==="tb"||e==="thematic-break":!1}function Cc(e,t){var r;if(!e||e.length===0)return null;const o=t.activeBlockId||"",i=t.currentTopBlockId||o,n=t.currentPageDividerId||"",s=t.activeBlockType||"";if(Ir(s)&&o){let a=e.find(c=>c.startBlockId===o);if(a||(a=e.find(c=>{var u,f;return((f=(u=c.blocks)==null?void 0:u[0])==null?void 0:f.id)===o}),a)||(a=e.find(c=>{var u;return(u=c.allBlockIds)==null?void 0:u.includes(o)}),a))return a}if(n){let a=e.find(c=>c.startBlockId===n);if(a||(a=e.find(c=>{var u,f;return((f=(u=c.blocks)==null?void 0:u[0])==null?void 0:f.id)===n}),a))return a}if(o){let a=e.find(u=>u.startBlockId===o);if(a||(a=e.find(u=>{var f,p;return((f=u.blocks)==null?void 0:f.some(d=>d.id===o))||((p=u.allBlockIds)==null?void 0:p.includes(o))}),a)||i&&i!==o&&(a=e.find(u=>{var f,p;return((f=u.blocks)==null?void 0:f.some(d=>d.id===i))||((p=u.allBlockIds)==null?void 0:p.includes(i))}),a)||(a=e.find(u=>{var f;return(f=u.noteBlocks)==null?void 0:f.some(p=>p.id===o||p.id===i)}),a))return a;const c=(r=t.activeBlockAttrs)==null?void 0:r[Te];if(c&&["col-1","col-2","col-3"].includes(c)&&(a=e.find(u=>{var f,p;return((f=u.frontmatter)==null?void 0:f.layout)==="three-cols-header"||((p=u.blocks)==null?void 0:p.some(d=>d.slot==="col-1"||d.slot==="col-2"||d.slot==="col-3"))}),a))return a}return e[0]||null}function _s(){var s;if(typeof window<"u"&&typeof((s=window.Lute)==null?void 0:s.NewNodeID)=="function")return window.Lute.NewNodeID();const e=new Date,t=l=>l.toString().padStart(2,"0"),o=`${e.getFullYear()}${t(e.getMonth()+1)}${t(e.getDate())}${t(e.getHours())}${t(e.getMinutes())}${t(e.getSeconds())}`,i="0123456789abcdefghijklmnopqrstuvwxyz";let n="";for(let l=0;l<7;l++)n+=i[Math.floor(Math.random()*i.length)];return`${o}-${n}`}function Ic(){return typeof document>"u"?null:document.querySelector(".layout__wnd--active .protyle-wysiwyg")||document.querySelector(".protyle:not(.fn__none) .protyle-wysiwyg")||document.querySelector(".protyle-wysiwyg")}function Rw(e,t){var l;if(typeof document>"u")return!1;const o=Ic();if(!o)return!1;const i=Array.from(o.querySelectorAll(".protyle-wysiwyg--select[data-node-id]"));if(i.length>=2)return!0;const n=((l=i[0])==null?void 0:l.getAttribute("data-node-id"))||e,s=t==="NodeList"||t==="l"||t==="list";if(n){const r=o.querySelector(`[data-node-id="${n}"]`);if(r){const a=(s||r.getAttribute("data-type")==="NodeList"||r.classList.contains("list"))&&r.getAttribute("data-type")==="NodeList"?r:r.closest('[data-type="NodeList"], .list');if(a&&a.querySelectorAll(":scope > [data-type='NodeListItem'], :scope > .li").length>=2)return!0}}return!1}async function zw(e){const t=Ic();if(!t)return{success:!1,error:"未找到主编辑区"};const o=Array.from(t.querySelectorAll(".protyle-wysiwyg--select[data-node-id]"));let i=!1,n=null,s=[];if(o.length>=2){const x=o[0].closest('[data-type="NodeList"], .list');if(x){const $=new Set;let A=!0;for(const w of o){const _=w.getAttribute("data-type")==="NodeListItem"||w.classList.contains("li")?w:w.closest('[data-type="NodeListItem"], .li');if(!_||_.closest('[data-type="NodeList"], .list')!==x){A=!1;break}$.add(_)}A&&$.size>=2&&(i=!0,n=x,s=Array.from(x.querySelectorAll(":scope > [data-type='NodeListItem'], :scope > .li")).filter(w=>$.has(w)))}}let l=!1;if(!i){const x=(o.length===1?o[0]:null)||(e.activeBlockId?t.querySelector(`[data-node-id="${e.activeBlockId}"]`):null);if(x){const $=x.getAttribute("data-type")==="NodeList"||x.classList.contains("list")?x:x.closest('[data-type="NodeList"], .list');if($){const A=Array.from($.querySelectorAll(":scope > [data-type='NodeListItem'], :scope > .li"));A.length>=2&&(l=!0,n=$,s=A)}}}if(i||l){if(!n||s.length<2)return{success:!1,error:"选中的列表项不足 2 项，无法合并为横向超级块"};const x=Array.from(n.querySelectorAll(":scope > [data-type='NodeListItem'], :scope > .li")),$=s.length===x.length,A=n.getAttribute("data-subtype")||"u",w=n.getAttribute("data-node-id")||"",_=n.parentElement,O=(_==null?void 0:_.getAttribute("data-node-id"))||e.currentDocId;let H=n.previousElementSibling;for(;H&&!H.getAttribute("data-node-id");)H=H.previousElementSibling;const P=(H==null?void 0:H.getAttribute("data-node-id"))||"";let F=n.nextElementSibling;for(;F&&!F.getAttribute("data-node-id");)F=F.nextElementSibling;const E=(F==null?void 0:F.getAttribute("data-node-id"))||"",D=_s(),S=s.map(C=>({li:C,liId:C.getAttribute("data-node-id")||"",newListId:_s()})),q=[],j=[];if($){q.push({action:"insert",id:D,data:`<div data-node-id="${D}" data-type="NodeSuperBlock" class="sb" data-sb-layout="col"><div class="protyle-attr" contenteditable="false">&#x200B;</div></div>`,parentID:O,previousID:P||void 0,nextID:P?void 0:E||void 0});for(let C=0;C<S.length;C++){const{liId:M,newListId:B}=S[C];q.push({action:"insert",id:B,data:`<div data-node-id="${B}" data-type="NodeList" data-subtype="${A}" class="list"><div class="protyle-attr" contenteditable="false">&#x200B;</div></div>`,parentID:D,previousID:C===0?void 0:S[C-1].newListId}),q.push({action:"move",id:M,parentID:B})}w&&q.push({action:"delete",id:w}),w&&j.push({action:"insert",id:w,data:n.outerHTML,parentID:O,previousID:P||void 0,nextID:P?void 0:E||void 0});for(let C=0;C<S.length;C++)j.push({action:"move",id:S[C].liId,parentID:w,previousID:C===0?void 0:S[C-1].liId});for(const{newListId:C}of S)j.push({action:"delete",id:C});j.push({action:"delete",id:D})}else{q.push({action:"insert",id:D,data:`<div data-node-id="${D}" data-type="NodeSuperBlock" class="sb" data-sb-layout="col"><div class="protyle-attr" contenteditable="false">&#x200B;</div></div>`,parentID:O,previousID:w});for(let C=0;C<S.length;C++){const{liId:M,newListId:B}=S[C];q.push({action:"insert",id:B,data:`<div data-node-id="${B}" data-type="NodeList" data-subtype="${A}" class="list"><div class="protyle-attr" contenteditable="false">&#x200B;</div></div>`,parentID:D,previousID:C===0?void 0:S[C-1].newListId}),q.push({action:"move",id:M,parentID:B})}for(let C=0;C<S.length;C++)j.push({action:"move",id:S[C].liId,parentID:w});for(const{newListId:C}of S)j.push({action:"delete",id:C});j.push({action:"delete",id:D})}return await Dr([{doOperations:q,undoOperations:j}]),t.querySelectorAll(".protyle-wysiwyg--select").forEach(C=>C.classList.remove("protyle-wysiwyg--select")),{success:!0,colCount:S.length,superBlockId:D}}const r=o.filter(x=>{let $=x.parentElement;for(;$&&$!==t;){if(o.includes($))return!1;$=$.parentElement}return!0});if(r.length<2)return{success:!1,error:"请在编辑区选中多个块，或选中一个包含多个列表项的列表"};const a=r[0],c=r[r.length-1],u=a.parentElement,f=(u==null?void 0:u.getAttribute("data-node-id"))||e.currentDocId;let p=a.previousElementSibling;for(;p&&!p.getAttribute("data-node-id");)p=p.previousElementSibling;const d=(p==null?void 0:p.getAttribute("data-node-id"))||"";let b=c.nextElementSibling;for(;b&&!b.getAttribute("data-node-id");)b=b.nextElementSibling;const m=(b==null?void 0:b.getAttribute("data-node-id"))||"",g=_s(),y=[],k=[];y.push({action:"insert",id:g,data:`<div data-node-id="${g}" data-type="NodeSuperBlock" class="sb" data-sb-layout="col"><div class="protyle-attr" contenteditable="false">&#x200B;</div></div>`,parentID:f,previousID:d||void 0,nextID:d?void 0:m||void 0});for(let x=0;x<r.length;x++){const $=r[x].getAttribute("data-node-id");y.push({action:"move",id:$,parentID:g,previousID:x===0?void 0:r[x-1].getAttribute("data-node-id")})}for(let x=0;x<r.length;x++){const $=r[x].getAttribute("data-node-id");k.push({action:"move",id:$,parentID:f,previousID:x===0?d||void 0:r[x-1].getAttribute("data-node-id")})}return k.push({action:"delete",id:g}),await Dr([{doOperations:y,undoOperations:k}]),t.querySelectorAll(".protyle-wysiwyg--select").forEach(x=>x.classList.remove("protyle-wysiwyg--select")),{success:!0,colCount:r.length,superBlockId:g}}function et(e,t){var n;if(typeof document>"u"||!e)return;const o=(n=globalThis.CSS)!=null&&n.escape?globalThis.CSS.escape(e):e.replace(/"/g,'\\"'),i=document.querySelectorAll(`[data-node-id="${o}"]`);!i||i.length===0||i.forEach(s=>{for(const[l,r]of Object.entries(t))r!=null&&r!==""?s.setAttribute(l,String(r)):s.removeAttribute(l)})}function Hw(e){if(typeof document>"u")return;const t=`.protyle-wysiwyg [${be}], .protyle-wysiwyg [${Ye}], .protyle-wysiwyg [custom-slides-layout], .protyle-wysiwyg [custom-slides-role]`,o=document.querySelectorAll(t);!o||o.length===0||o.forEach(i=>{const n=i.getAttribute("data-node-id");if(!n){i.removeAttribute(be),i.removeAttribute("custom-slides-layout"),i.removeAttribute(Ye),i.removeAttribute("custom-slides-role");return}const s=e.get(n),l=(s==null?void 0:s[be])||(s==null?void 0:s["custom-slides-layout"])||"",r=i.getAttribute(be)||i.getAttribute("custom-slides-layout");r&&r!==l&&(l?i.setAttribute(be,l):(i.removeAttribute(be),i.removeAttribute("custom-slides-layout")));const a=(s==null?void 0:s[Ye])||(s==null?void 0:s["custom-slides-role"])||"",c=i.getAttribute(Ye)||i.getAttribute("custom-slides-role");c&&c!==a&&(a?i.setAttribute(Ye,a):(i.removeAttribute(Ye),i.removeAttribute("custom-slides-role")))})}function Fw(e,t){if(!t)return!1;if(e===t||typeof document>"u")return!0;const o=document.querySelector(`.protyle-wysiwyg [data-node-id="${t}"]`)||document.querySelector(`[data-node-id="${t}"]`);if(!o)return!1;const i=o.querySelector(":scope > [data-node-id], :scope > div > [data-node-id]");return(i==null?void 0:i.getAttribute("data-node-id"))===e}function jw(e){let t=null;function o(c="已同步"){e.saveStatus.value=c,t&&(typeof window<"u"?window.clearTimeout(t):clearTimeout(t));const u=()=>{e.saveStatus.value=""};typeof window<"u"?t=window.setTimeout(u,1200):t=setTimeout(u,1200)}async function i(c){var d;const u=e.activeBlockId.value||e.currentDocId.value;if(!u)return;for(const[b,m]of Object.entries(c))e.activeBlockAttrs.value[b]=m;Ee.setBlockAttrOverride(u,c),et(u,c);const f=(d=e.parentContainerId)==null?void 0:d.value,p=!!(f&&Fw(u,f));if(Oe in c&&p&&f){const b=c[Oe];e.parentContainerClicks&&(e.parentContainerClicks.value=b),Ee.setBlockAttrOverride(f,{[Oe]:b}),et(f,{[Oe]:b}),ze(f,{[Oe]:b}).catch(()=>{})}if(be in c){const b=c[be];e.currentPageDividerLayout.value=b,e.targetSlide.value&&(e.targetSlide.value.frontmatter||(e.targetSlide.value.frontmatter={}),e.targetSlide.value.frontmatter.layout=b)}if(yt in c){const b=c[yt];e.targetSlide.value&&(e.targetSlide.value.frontmatter||(e.targetSlide.value.frontmatter={}),e.targetSlide.value.frontmatter.layoutRatio=b)}o("保存中...");try{await ze(u,c),o("已同步"),e.plugin&&await e.plugin.compileCurrentDocument()}catch{o("同步失败")}}async function n(c,u){await i({[c]:u})}function s(){var u;return(e.activeBlockType.value==="NodeThematicBreak"||e.activeBlockType.value==="NodeThematicBreakBlock"||e.activeBlockType.value==="hr"||e.activeBlockType.value==="thematicbreak")&&e.activeBlockId.value?e.activeBlockId.value:e.currentPageDividerId.value?e.currentPageDividerId.value:(u=e.targetSlide.value)!=null&&u.startBlockId&&e.targetSlide.value.startBlockId!==e.currentDocId.value?e.targetSlide.value.startBlockId:e.currentDocId.value}async function l(c,u){const f=s();if(f){f===e.activeBlockId.value&&(e.activeBlockAttrs.value[c]=u),Ee.setBlockAttrOverride(f,{[c]:u}),et(f,{[c]:u}),c===be&&(e.currentPageDividerLayout.value=u,e.targetSlide.value&&(e.targetSlide.value.frontmatter||(e.targetSlide.value.frontmatter={}),e.targetSlide.value.frontmatter.layout=u)),c===yt&&e.targetSlide.value&&(e.targetSlide.value.frontmatter||(e.targetSlide.value.frontmatter={}),e.targetSlide.value.frontmatter.layoutRatio=u),o("保存中...");try{await ze(f,{[c]:u}),o("已同步"),e.plugin&&await e.plugin.compileCurrentDocument()}catch{o("同步失败")}}}async function r(c,u){const f=s();if(!f)return;const p={[be]:c,[yt]:u};f===e.activeBlockId.value&&(e.activeBlockAttrs.value[be]=c,e.activeBlockAttrs.value[yt]=u),e.currentPageDividerLayout.value=c,Ee.setBlockAttrOverride(f,p),et(f,p),e.targetSlide.value&&(e.targetSlide.value.frontmatter||(e.targetSlide.value.frontmatter={}),e.targetSlide.value.frontmatter.layout=c,e.targetSlide.value.frontmatter.layoutRatio=u),o("应用排版中...");try{await ze(f,p),o("已应用分栏与比例"),e.plugin&&await e.plugin.compileCurrentDocument()}catch{o("应用失败")}}async function a(c,u){var p;const f=e.currentDocId.value||e.activeBlockId.value;if(f){e.activeBlockAttrs.value[c]=u,Ee.setBlockAttrOverride(f,{[c]:u}),et(f,{[c]:u}),(p=e.latestDoc.value)!=null&&p.config&&(c===Vi&&(e.latestDoc.value.config.theme=u),c===Ki&&(e.latestDoc.value.config.aspectRatio=u),c===Gi&&(e.latestDoc.value.config.defaultTransition=u),c===An&&(e.latestDoc.value.config.background=u)),o("更新中...");try{await ze(f,{[c]:u}),o("已更新"),e.plugin&&await e.plugin.compileCurrentDocument(f)}catch{o("更新失败")}}}return{triggerSaveNotice:o,saveAttrs:i,saveAttr:n,getPageTargetBlockId:s,savePageAttr:l,applyPageLayoutAndRatio:r,saveDocAttr:a}}function Uw(e){const t=(e||"").trim().toLowerCase();return t==="anthropic"||t==="anthropic-messages"?"anthropic-messages":t==="openai-responses"?"openai-responses":t==="systemone"||t==="system-one"||t==="jev"||t==="typesafe"?"systemone":"openai"}function Ww(e){const t=[{"content-type":"application/json"},{Authorization:`Bearer ${e.apiKey.trim()}`},{Accept:"application/json"}];if(e.headers&&typeof e.headers=="object")for(const[o,i]of Object.entries(e.headers))o&&i!==void 0&&i!==null&&t.push({[o]:String(i)});return t}function qw(e){var i,n;if(!e||typeof e!="object")return null;const t=(i=e.choices)==null?void 0:i[0];if(!t)return null;const o=((n=t.message)==null?void 0:n.content)??t.text;return typeof o=="string"&&o.trim().length>0?o.trim():null}async function Vw(e,t,o){const i=t.baseUrl.replace(/\/+$/,""),n=i.endsWith("/chat/completions")?i:`${i}/chat/completions`,s={model:t.model,messages:e,max_tokens:t.maxTokens??4096,temperature:t.temperature??.7},l=Math.max(1,t.requestTimeoutSeconds||60)*1e3,r=Ww(t),a=await jl(n,"POST",s,r,l,"application/json");if(!a||a.status<200||a.status>=300){const f=typeof(a==null?void 0:a.body)=="string"?a.body.slice(0,200):"";throw new Error(`AI 请求失败 (HTTP ${(a==null?void 0:a.status)??"未知"})${f?`: ${f}`:""}`)}let c;try{c=typeof a.body=="string"?JSON.parse(a.body||"{}"):a.body}catch{throw new Error("AI 接口返回了非法的 JSON 响应")}const u=qw(c);if(!u)throw new Error("AI 接口未返回有效的文本内容");return u}async function ss(e){const t=kr();if(!t)return null;try{return await Vw([{role:"system",content:"你是一位专业的幻灯片演讲教练与内容设计专家。请根据用户提供的幻灯片内容提供精炼、准确的输出。"},{role:"user",content:e}],t.config)}catch(o){throw console.warn("[LiveSlides AI] request failed:",(o==null?void 0:o.message)||o),o}}async function Kw(e){var r,a;if(!Un(e))return{success:!1,message:"配置不完整：请先补充 Base URL、API Key 和 Model"};const t=Date.now(),o=e.baseUrl.trim().replace(/\/+$/,""),i=e.apiKey.trim(),n=e.model.trim(),s=Uw(e.protocol),l=Math.max(5,e.requestTimeoutSeconds||15);try{const c={displayName:"Live Slides AI",apiKey:i,baseURL:o,protocol:s,requestTimeout:l,headers:e.headers||{},models:[]},u=await ie.fetchSyncPost("/api/ai/testModel",{providerConfig:c,model:n});if(u&&u.code===0&&((r=u.data)!=null&&r.matched)&&!((a=u.data)!=null&&a.msg)){const f=Date.now()-t;return{success:!0,message:`测试成功（耗时 ${f}ms）：已通过思源内核验证模型并完成对话测试`,elapsed:f}}}catch{}try{let c,u,f;if(s==="anthropic-messages"?(c=/\/v1$/i.test(o)?`${o}/messages`:`${o}/v1/messages`,u=[{"content-type":"application/json"},{"anthropic-version":"2023-06-01"}],i&&u.push({"x-api-key":i}),f={model:n,max_tokens:1,messages:[{role:"user",content:"hi"}]}):s==="openai-responses"?(c=/\/responses$/i.test(o)?o:`${o}/responses`,u=[{"content-type":"application/json"}],i&&u.push({Authorization:`Bearer ${i}`}),f={model:n,max_output_tokens:16,stream:!1,input:"hi"}):(c=/\/chat\/completions$/i.test(o)?o:`${o}/chat/completions`,u=[{"content-type":"application/json"}],i&&u.push({Authorization:`Bearer ${i}`}),f={model:n,max_tokens:1,stream:!1,messages:[{role:"user",content:"hi"}]}),e.headers&&typeof e.headers=="object")for(const[y,k]of Object.entries(e.headers))y&&k!==void 0&&k!==null&&u.push({[y]:String(k)});const p=await jl(c,"POST",f,u,l*1e3,"application/json"),d=Date.now()-t,b=(p==null?void 0:p.status)??0,m=typeof(p==null?void 0:p.body)=="string"?p.body:"";if(b>=200&&b<300)return{success:!0,message:`连接成功（耗时 ${d}ms），服务商响应正常`,elapsed:d};const g=m.slice(0,160);return b===401||b===403?{success:!1,message:`鉴权失败 (HTTP ${b})：请检查 API Key 是否有效${g?` (${g})`:""}`,elapsed:d}:b===404?{success:!1,message:"端点未找到 (HTTP 404)：请检查 API 基础地址 (Base URL) 是否正确（OpenAI 兼容地址通常需以 /v1 结尾）",elapsed:d}:b===429?{success:!1,message:"请求被限流或余额不足 (HTTP 429)：请检查服务商账户额度与频率限制",elapsed:d}:b===400?{success:!1,message:`请求参数错误 (HTTP 400)：模型「${n}」可能不存在或不可用 (${g})`,elapsed:d}:b>=500?{success:!1,message:`服务商服务器错误 (HTTP ${b})：${g}`,elapsed:d}:{success:!1,message:`服务响应异常 (HTTP ${b})：${g||"请检查配置或网络"}`,elapsed:d}}catch(c){const u=Date.now()-t;return{success:!1,message:`网络或思源内核代理请求失败: ${(c==null?void 0:c.message)||c}`,elapsed:u}}}function $c(e){var i,n;if(!e)return"";const t=[],o=(e.content||e.rawMarkdown||e.markdown||((i=e.rawNode)==null?void 0:i.content)||((n=e.rawNode)==null?void 0:n.markdown)||"").trim();if(o&&o!=="---"){const s=o.replace(/\{:\s*[^}]+\s*\}\s*$/g,"").trim();s&&s!=="---"&&t.push(s)}if(Array.isArray(e.children)&&e.children.length>0)for(const s of e.children){const l=$c(s);l&&t.push(l)}return t.join(`
`)}function Tc(e){if(!e)return"";const t=[];if(Array.isArray(e.blocks)&&e.blocks.length>0)for(const i of e.blocks){if(i.slot==="slot-divider-right"||i.content==="::right::"||i.isNote)continue;const n=$c(i);n&&t.push(n)}let o=t.join(`

`).trim();if(!o&&e.rawMarkdown&&(o=e.rawMarkdown.replace(/^---\s*$/gm,"").trim()),!o&&e.frontmatter){const i=[];e.frontmatter.title&&i.push(`幻灯片标题: ${e.frontmatter.title}`),e.frontmatter.description&&i.push(`幻灯片描述: ${e.frontmatter.description}`),e.frontmatter.layout&&e.frontmatter.layout!=="default"&&i.push(`版式布局: ${e.frontmatter.layout}`),e.frontmatter.image&&i.push(`页面配图: ${e.frontmatter.image}`),i.length>0&&(o=i.join(`
`))}return o}async function Ac(e,t=ss){const o=Tc(e);if(!o)return{notes:"",isAiGenerated:!1,error:"当前幻灯片尚未填写正文内容，请先输入幻灯片标题或段落后再调用 AI 提炼"};if(t){const i=`你是一位专业的演讲教练。请根据以下幻灯片内容，提炼出简短精炼的演讲口播提词卡（Notes），包含核心观点与口播要点，总字数在 150 字以内：
${o}`;try{const n=await t(i);return n&&n.trim()?{notes:n.trim(),isAiGenerated:!0}:{notes:"",isAiGenerated:!1,error:"AI 服务未配置或未返回可用提词内容"}}catch(n){return{notes:"",isAiGenerated:!1,error:(n==null?void 0:n.message)||"AI 调用异常"}}}return{notes:"",isAiGenerated:!1,error:"未配置 AI 提词服务"}}async function Gw(e,t=ss){const o=await Ac(e,t);if(o.error)throw new Error(o.error);return o.notes}function Yw(e){if(!e)return!1;const t=String(e.type||"").toLowerCase();return!!(t==="callout"||t==="nodecallout"||t==="b"||t==="nodeblockquote"||String(e.markdown||"").trim().startsWith(">"))}function Zw(e,t){if(!((t==null?void 0:t[Fe])==="true"))return!1;const i=(e||"").trim();return/^>\s*\[!NOTE\]\s*(?:💡\s*)?(?:演讲备注|讲稿备注)/i.test(i)}async function Mc(e,t){const i=await((t==null?void 0:t.getChildBlocksFn)||Si)(e).catch(()=>[]);if(!Array.isArray(i)||i.length===0)return[];const n=[];let s=[];for(const r of i){if(bo({...r,ial:{...r.ial||{},...Ee.getBlockAttrOverride(r.id)||{}}})){if(n.length===0&&s.length===0)continue;n.push(s),s=[];continue}s.push(r)}n.push(s);const l=[];for(let r=0;r<n.length;r++){const a=n[r];if(!a||a.length===0)continue;let c=null;for(let b=a.length-1;b>=0;b--){const m=a[b];if(!((m.type==="p"||m.type==="NodeParagraph")&&!(m.content||"").trim()&&!(m.markdown||"").trim())){c=m;break}}if(!c||!Yw(c))continue;const u=Ee.getBlockAttrOverride(c.id)||{};let f={...c.ial||{},...u};if(!f[Fe]&&(t!=null&&t.getBlockAttrsFn)){const b=await t.getBlockAttrsFn(c.id).catch(()=>({}));f={...f,...b,...u}}let p=c.markdown||c.content||"";if(t!=null&&t.getBlockKramdownFn)try{const b=await t.getBlockKramdownFn(c.id);b!=null&&b.kramdown&&(p=b.kramdown)}catch{}if(Zw(p,f))continue;const d=Sr(p)||p.replace(/<[^>]+>/g,"").trim();l.push({id:c.id,pageIndex:r+1,type:c.type,sourceMarkdown:p,cleanContent:d||"在此输入本页讲稿提词..."})}return l}async function Ec(e,t,o){const i=(o==null?void 0:o.updateBlockFn)||Ms,n=(o==null?void 0:o.setBlockAttrsFn)||ze,s=(o==null?void 0:o.syncDomFn)||et,r=`> [!NOTE] 💡 演讲备注
${t.split(/\r?\n/).map(a=>`> ${a}`).join(`
`)}
{: ${Fe}="true"}`;await i("markdown",r,e),await n(e,{[Fe]:"true"}),Ee.setBlockAttrOverride(e,{[Fe]:"true"}),s(e,{[Fe]:"true"})}async function Bc(e,t){const o=(t==null?void 0:t.showMessageFn)||ie.showMessage,i=(t==null?void 0:t.confirmFn)||ie.confirm;if(!e)return o("请先在主编辑区打开幻灯片文档"),{totalScanned:0,matchedCount:0,successCount:0,errorCount:0};const n=await Mc(e,t);if(n.length===0)return o("未发现待规范化的候选讲稿块"),{totalScanned:0,matchedCount:0,successCount:0,errorCount:0};const s=n.length;return new Promise(l=>{i("识别讲稿块",`扫描检测到 ${s} 处候选讲稿块（提示块或引用块），是否确认将其规范化为标准演讲备注？`,async()=>{var c;o(`正在批量规范化 ${s} 个讲稿块...`);let r=0,a=0;for(const u of n)try{await Ec(u.id,u.cleanContent,t),r++}catch(f){console.error(`[SiYuanLiveSlides] 规范化讲稿块 ${u.id} 失败:`,f),a++}(c=t==null?void 0:t.onSuccessNotice)==null||c.call(t,"已规范化讲稿"),o(`已成功识别并规范化 ${r} 个讲稿块`),t!=null&&t.compileFn&&await t.compileFn().catch(()=>{}),l({totalScanned:s,matchedCount:s,successCount:r,errorCount:a})},()=>{l({totalScanned:s,matchedCount:s,successCount:0,errorCount:0})})})}function Jw(e,t){const o=pe(!1),i=pe(!1),{triggerSaveNotice:n}=t;async function s(y){var P,F,E,D,S,q,j,C;const $=`> [!NOTE] 💡 演讲备注
${(y||"在此输入本页讲稿提词...").split(/\r?\n/).map(M=>`> ${M}`).join(`
`)}
{: custom-slides-note="true"}`,A=((P=e.latestDoc.value)==null?void 0:P.slides)||[],w=e.targetSlide.value,_=w?A.findIndex(M=>M===w):-1;let O=null;if(_!==-1&&_<A.length-1){const M=A[_+1];O=await fo("markdown",$,M.startBlockId)}else{const M=((F=w==null?void 0:w.noteBlocks)==null?void 0:F.slice(-1)[0])||((E=w==null?void 0:w.blocks)==null?void 0:E.slice(-1)[0]),B=(M==null?void 0:M.id)||(w==null?void 0:w.startBlockId);B?O=await fo("markdown",$,void 0,B):O=await bn("markdown",$,e.currentDocId.value)}const H=((q=(S=(D=O==null?void 0:O[0])==null?void 0:D.doOperations)==null?void 0:S[0])==null?void 0:q.id)||((j=O==null?void 0:O[0])==null?void 0:j.id);return H&&(await ze(H,{[Fe]:"true"}),Ee.setBlockAttrOverride(H,{[Fe]:"true"}),Ro(H,(C=e.plugin)==null?void 0:C.app)),e.plugin&&await e.plugin.compileCurrentDocument(),H}async function l(){const y=e.activeBlockId.value;if(y)if(e.isNoteBlock.value){n("取消中...");try{await ze(y,{[Fe]:""}),Ee.setBlockAttrOverride(y,{[Fe]:""}),et(y,{[Fe]:""}),delete e.activeBlockAttrs.value[Fe],n("已取消备注"),ie.showMessage("已取消讲稿备注"),e.plugin&&await e.plugin.compileCurrentDocument()}catch(k){console.error("[SiYuanLiveSlides] 取消讲稿备注失败:",k),n("取消失败"),ie.showMessage("取消讲稿备注失败")}}else{n("转换中...");try{let k=e.rawSnippet.value;try{const w=await Ed(y);w!=null&&w.kramdown&&(k=w.kramdown)}catch{}const A=`> [!NOTE] 💡 演讲备注
${(Sr(k)||k.replace(/<[^>]+>/g,"").trim()||"在此输入本页讲稿提词...").split(/\r?\n/).map(w=>`> ${w}`).join(`
`)}
{: custom-slides-note="true"}`;await Ms("markdown",A,y),await ze(y,{[Fe]:"true"}),Ee.setBlockAttrOverride(y,{[Fe]:"true"}),et(y,{[Fe]:"true"}),e.activeBlockAttrs.value[Fe]="true",e.activeBlockType.value="NodeCallout",n("已设为讲稿备注"),ie.showMessage("已转为讲稿备注提示块（不在幻灯片中渲染）"),e.plugin&&await e.plugin.compileCurrentDocument()}catch(k){console.error("[SiYuanLiveSlides] 转换讲稿备注提示块失败:",k),n("设置失败"),ie.showMessage("转为讲稿备注提示块失败")}}}async function r(){try{await s(),ie.showMessage("已在正文末尾插入讲稿备注提示块")}catch(y){ie.showMessage("插入讲稿备注块失败"),console.error(y)}}function a(){var x;const y=e.currentSlideNoteBlockId.value;if(!y){ie.showMessage("未找到本页关联的讲稿备注块");return}Ro(y,(x=e.plugin)==null?void 0:x.app)?ie.showMessage("已在编辑区定位讲稿备注块"):ie.showMessage("定位讲稿备注块失败")}async function c(){var w,_,O,H,P,F,E,D,S,q,j;const y=e.currentDocId.value||((w=e.plugin)==null?void 0:w.currentDocId)||"";if(!y){ie.showMessage("未检测到当前文档，请先在编辑器中打开幻灯片文档",5e3,"error");return}if(!kr()){ie.showMessage("未配置 AI 提词服务，请前往高级设置填写 API 配置或通过「API 旋钮 (siyuan-api-switch)」接管",6e3,"error");return}if(i.value)return;const{slides:x}=await f();let $=e.targetSlide.value;!$&&x.length>0&&($=Cc(x,{activeBlockId:e.activeBlockId.value,activeBlockType:e.activeBlockType.value,currentPageDividerId:e.currentPageDividerId.value,activeBlockAttrs:e.activeBlockAttrs.value}));const A=Tc($);if(!$||!A){ie.showMessage("当前幻灯片无有效正文内容，请先输入标题或段落后再提炼讲稿",5e3,"info");return}i.value=!0;try{ie.showMessage("正在调用 AI 提炼本页讲稿提词...");const C=await Ac($,ss);if(C.error){ie.showMessage(`AI 提炼提词卡失败：${C.error}`,6e3,"error");return}if(C.notes){const M=((O=(_=$.noteBlocks)==null?void 0:_[0])==null?void 0:O.id)||e.currentSlideNoteBlockId.value;if(M){const B=`> [!NOTE] 💡 演讲备注
${C.notes.split(/\r?\n/).map(te=>`> ${te}`).join(`
`)}
{: custom-slides-note="true"}`;await Ms("markdown",B,M),await ze(M,{[Fe]:"true"}),Ee.setBlockAttrOverride(M,{[Fe]:"true"}),Ro(M,(H=e.plugin)==null?void 0:H.app)}else{const B=x.findIndex(te=>te===$);if(B!==-1){const V=`> [!NOTE] 💡 演讲备注
${C.notes.split(/\r?\n/).map(oe=>`> ${oe}`).join(`
`)}
{: custom-slides-note="true"}`;let K=null;if(B<x.length-1){const oe=x[B+1];K=await fo("markdown",V,oe.startBlockId)}else{const oe=((P=$.noteBlocks)==null?void 0:P.slice(-1)[0])||((F=$.blocks)==null?void 0:F.slice(-1)[0]),re=(oe==null?void 0:oe.id)||$.startBlockId;re?K=await fo("markdown",V,void 0,re):K=await bn("markdown",V,y)}const ae=((S=(D=(E=K==null?void 0:K[0])==null?void 0:E.doOperations)==null?void 0:D[0])==null?void 0:S.id)||((q=K==null?void 0:K[0])==null?void 0:q.id);ae&&(await ze(ae,{[Fe]:"true"}),Ee.setBlockAttrOverride(ae,{[Fe]:"true"}),Ro(ae,(j=e.plugin)==null?void 0:j.app))}else await s(C.notes)}ie.showMessage("AI 演讲提词卡生成成功！"),e.plugin&&await e.plugin.compileCurrentDocument()}}catch(C){ie.showMessage(`AI 提炼提词卡异常：${(C==null?void 0:C.message)||C}`,6e3,"error")}finally{i.value=!1}}const u=`> [!NOTE] 💡 演讲备注
${"在此输入本页讲稿提词...".split(/\r?\n/).map(x=>`> ${x}`).join(`
`)}
{: custom-slides-note="true"}`;async function f(){var $,A;const y=e.currentDocId.value||(($=e.plugin)==null?void 0:$.currentDocId)||"",k=(A=e.latestDoc.value)==null?void 0:A.slides;if(Array.isArray(k)&&k.length>0)return{docId:y,slides:k};if(!y)return{docId:"",slides:[]};const x=await Ee.compile(y).catch(()=>null);return{docId:y,slides:(x==null?void 0:x.slides)||[]}}async function p(y,k,x,$){var _,O,H,P,F,E;let A=null;if(k<x.length-1){const D=x[k+1];A=await fo("markdown",u,D.startBlockId)}else{const D=((_=y==null?void 0:y.noteBlocks)==null?void 0:_.slice(-1)[0])||((O=y==null?void 0:y.blocks)==null?void 0:O.slice(-1)[0]),S=(D==null?void 0:D.id)||(y==null?void 0:y.startBlockId);S?A=await fo("markdown",u,void 0,S):A=await bn("markdown",u,$||e.currentDocId.value)}const w=((F=(P=(H=A==null?void 0:A[0])==null?void 0:H.doOperations)==null?void 0:P[0])==null?void 0:F.id)||((E=A==null?void 0:A[0])==null?void 0:E.id);w&&(await ze(w,{[Fe]:"true"}),Ee.setBlockAttrOverride(w,{[Fe]:"true"}))}async function d(){if(o.value)return;const{docId:y,slides:k}=await f();if(k.length===0){ie.showMessage("当前文档无幻灯片页面");return}const x=k.map((A,w)=>({slide:A,idx:w})).filter(({slide:A})=>{var O;const w=Array.isArray(A.noteBlocks)&&A.noteBlocks.length>0,_=!!((O=A.notes)!=null&&O.trim());return!w&&!_});if(x.length===0){ie.showMessage("所有幻灯片页面均已存在讲稿备注块，无需追加");return}const $=x.length;ie.confirm("批量追加讲稿备注",`将在未配置讲稿的 ${$} 页末尾自动插入讲稿提示块，是否继续？`,async()=>{if(o.value)return;o.value=!0,ie.showMessage("正在批量追加讲稿块...");let A=0;try{for(const{slide:w,idx:_}of x)try{await p(w,_,k,y),A++}catch(O){console.error(`[SiYuanLiveSlides] 为第 ${_+1} 页追加讲稿块失败:`,O)}e.plugin&&await e.plugin.compileCurrentDocument(),ie.showMessage(`已成功为 ${A} 页追加讲稿备注块`)}catch(w){console.error("[SiYuanLiveSlides] 批量追加讲稿块失败:",w),ie.showMessage("批量追加讲稿块时出现异常")}finally{o.value=!1}})}async function b(){if(o.value)return;const{slides:y}=await f();if(y.length===0){ie.showMessage("当前文档无幻灯片页面");return}const k=[];for(const A of y)if(A.noteBlocks&&A.noteBlocks.length>0)for(const w of A.noteBlocks)w.id&&k.push({id:w.id,pageIndex:A.pageIndex});if(k.length===0){ie.showMessage("当前文档中没有讲稿备注块，无需删除");return}const x=new Set(k.map(A=>A.pageIndex)).size,$=k.length;ie.confirm("危险操作：批量删除所有讲稿块",`此操作将从正文中物理删除全部 ${$} 个讲稿备注块（涉及 ${x} 页），删除后无法撤销。是否确认继续？`,async()=>{if(o.value)return;o.value=!0,ie.showMessage("正在批量删除讲稿块...");let A=0;try{for(const w of k)try{await Qs(w.id),Ee.clearBlockAttrOverride(w.id),A++}catch(_){console.error(`[SiYuanLiveSlides] 删除讲稿块 ${w.id} 失败:`,_)}e.activeBlockId.value&&k.some(w=>w.id===e.activeBlockId.value)&&delete e.activeBlockAttrs.value[Fe],e.plugin&&await e.plugin.compileCurrentDocument(),ie.showMessage(`已成功删除全部 ${A} 个讲稿备注块`)}catch(w){console.error("[SiYuanLiveSlides] 批量删除讲稿块失败:",w),ie.showMessage("批量删除讲稿块时出现异常")}finally{o.value=!1}})}async function m(){var k;const y=e.currentDocId.value||((k=e.plugin)==null?void 0:k.currentDocId);if(!y){ie.showMessage("请先在主编辑区打开幻灯片文档");return}if(o.value){ie.showMessage("正在批量处理中，请稍候...");return}o.value=!0;try{await Bc(y,{onSuccessNotice:n,compileFn:async()=>{e.plugin&&await e.plugin.compileCurrentDocument()}})}finally{o.value=!1}}async function g(){if(o.value){ie.showMessage("正在批量处理中，请稍候...");return}const{docId:y,slides:k}=await f();if(!y){ie.showMessage("请先在主编辑区打开幻灯片文档");return}if(k.length===0){ie.showMessage("当前文档无幻灯片页面");return}const x=await Mc(y),$=new Set(x.map(_=>_.pageIndex)),A=k.map((_,O)=>({slide:_,idx:O})).filter(({slide:_,idx:O})=>{var E;const H=Array.isArray(_.noteBlocks)&&_.noteBlocks.length>0,P=!!((E=_.notes)!=null&&E.trim()),F=_.pageIndex??O+1;return!H&&!P&&!$.has(F)});if(x.length===0&&A.length===0){ie.showMessage("所有幻灯片页面均已存在讲稿备注块，无需重复操作");return}let w="";x.length>0&&A.length>0?w=`扫描检测到 ${x.length} 处已有候选讲稿待规范化，另有 ${A.length} 页暂无讲稿将新增默认讲稿块，是否继续？`:x.length>0?w=`扫描检测到 ${x.length} 处已有候选讲稿块（提示块或引用块），是否规范化为标准演讲备注？`:w=`将在未配置讲稿的 ${A.length} 页末尾自动增加默认讲稿提示块，是否继续？`,ie.confirm("增加讲稿块",w,async()=>{if(o.value)return;o.value=!0,ie.showMessage("正在处理讲稿块...");let _=0,O=0;try{for(const H of x)try{await Ec(H.id,H.cleanContent),_++}catch(P){console.error(`[SiYuanLiveSlides] 规范化讲稿块 ${H.id} 失败:`,P)}for(const{slide:H,idx:P}of A)try{await p(H,P,k,y),O++}catch(F){console.error(`[SiYuanLiveSlides] 为第 ${P+1} 页增加讲稿块失败:`,F)}e.plugin&&await e.plugin.compileCurrentDocument(),n("已更新讲稿"),_>0&&O>0?ie.showMessage(`已规范化 ${_} 处现有讲稿，并为 ${O} 页新增讲稿块`):_>0?ie.showMessage(`已成功识别并规范化 ${_} 个讲稿块`):ie.showMessage(`已成功为 ${O} 页增加讲稿备注块`)}catch(H){console.error("[SiYuanLiveSlides] 增加讲稿块失败:",H),ie.showMessage("增加讲稿块时出现异常")}finally{o.value=!1}})}return{isBatchProcessing:o,isGeneratingNotes:i,createNoteBlockOnCurrentSlide:s,onToggleNoteBlock:l,onAddNoteBlock:r,onLocateNoteBlock:a,onGenerateNotesWithAI:c,onBatchAppendNotes:d,onBatchDeleteNotes:b,onIdentifyNotesBlocks:m,onAddOrIdentifyNotesBlocks:g}}function Xw(e){if(!e)return!1;const t=String(e.type||"").toLowerCase();if(t==="h"||t==="nodeheading")return!0;const o=String(e.subType||"").toLowerCase();if(/^h[1-6]$/.test(o))return!0;const i=String(e.rawMarkdown||e.markdown||"").trim();return!!/^#{1,6}\s+/.test(i)}function Qw(e){if(!e)return!1;const t=String(e.type||"").toLowerCase();return t==="i"||t==="nodelistitem"}function e2(e){const t=[],o=i=>{var n,s,l,r,a,c,u,f,p;for(const d of i){if(!d||d.isNote||((n=d.attributes)==null?void 0:n[Fe])==="true"||((s=d.ial)==null?void 0:s[Fe])==="true"||d.type==="tb"||d.type==="thematic-break"||d.type==="NodeThematicBreak"||String(d.markdown||d.rawMarkdown||"").trim()==="---"||d.slot==="slot-divider-right"||String(d.rawMarkdown||d.markdown||"").trim()==="::right::")continue;if(Xw(d)){t.push({id:d.id,type:d.type,isHeading:!0,currentClicks:d.clicks||((l=d.attributes)==null?void 0:l[Oe])||((r=d.ial)==null?void 0:r[Oe]),rawBlock:d});continue}if(Qw(d)){t.push({id:d.id,type:d.type||"i",isHeading:!1,currentClicks:d.clicks||((a=d.attributes)==null?void 0:a[Oe])||((c=d.ial)==null?void 0:c[Oe]),rawBlock:d});continue}const b=d.children&&d.children.length>0?d.children:(u=d.rawNode)==null?void 0:u.children;if(Array.isArray(b)&&b.length>0){o(b);continue}t.push({id:d.id,type:d.type,isHeading:!1,currentClicks:d.clicks||((f=d.attributes)==null?void 0:f[Oe])||((p=d.ial)==null?void 0:p[Oe]),rawBlock:d})}};return o(e||[]),t}function t2(e){var n;if(e.pageIndex===1||((n=e.frontmatter)==null?void 0:n.layout)==="cover")return[];const t=e2(e.blocks||[]);if(t.length===0)return[];let o=-1;for(let s=0;s<t.length;s++)if(!t[s].isHeading){o=s;break}if(o===-1)return[];const i=[];for(let s=o+1;s<t.length;s++){const l=t[s];!!!(l.currentClicks&&String(l.currentClicks).trim()!=="")&&l.id&&i.push({blockId:l.id,pageIndex:e.pageIndex,targetClick:"+1"})}return i}async function o2(e,t){const i=await((t==null?void 0:t.compileDocFn)||(l=>Ee.compile(l)))(e).catch(()=>null);if(!i||!Array.isArray(i.slides)||i.slides.length===0)return{totalPages:0,animatedPagesCount:0,targets:[]};const n=[],s=new Set;for(const l of i.slides){const r=t2(l);r.length>0&&(n.push(...r),s.add(l.pageIndex))}return{totalPages:i.slides.length,animatedPagesCount:s.size,targets:n}}async function Lc(e,t){const o=(t==null?void 0:t.showMessageFn)||ie.showMessage,i=(t==null?void 0:t.confirmFn)||ie.confirm,n=(t==null?void 0:t.setBlockAttrsFn)||ze,s=(t==null?void 0:t.syncDomFn)||et;if(!e)return o("请先在主编辑区打开幻灯片文档"),{totalPages:0,animatedPagesCount:0,targets:[],successCount:0,errorCount:0};const l=await o2(e,t);if(l.targets.length===0)return o("未检测到需要配置顺延动效的后续块"),{...l,successCount:0,errorCount:0};const r=l.targets.length,a=l.animatedPagesCount;return new Promise(c=>{i("智能设置动效",`扫描检测到可为 ${a} 页中的 ${r} 个后续块配置顺延 (+1) 动效，是否继续？`,async()=>{var p;o(`正在批量配置 ${r} 个后续块动效...`);let u=0,f=0;for(const d of l.targets)try{await n(d.blockId,{[Oe]:d.targetClick}),Ee.setBlockAttrOverride(d.blockId,{[Oe]:d.targetClick}),s(d.blockId,{[Oe]:d.targetClick}),u++}catch(b){console.error(`[SiYuanLiveSlides] 为块 ${d.blockId} 配置动效失败:`,b),f++}(p=t==null?void 0:t.onSuccessNotice)==null||p.call(t,"已配置智能动效"),o(`已成功为 ${u} 个后续块配置顺延 (+1) 动效`),t!=null&&t.compileCurrentDocFn&&await t.compileCurrentDocFn().catch(()=>{}),c({...l,successCount:u,errorCount:f})},()=>{c({...l,successCount:0,errorCount:0})})})}async function i2(e,t){const i=await((t==null?void 0:t.compileDocFn)||(a=>Ee.compile(a)))(e).catch(()=>null);if(!i||!Array.isArray(i.slides)||i.slides.length===0)return{totalPages:0,affectedPagesCount:0,targets:[]};const n=[],s=new Set,l=new Set,r=(a,c)=>{var u,f,p,d,b;for(const m of a){if(!m)continue;if(m.id&&!s.has(m.id)){const y=Ee.getBlockAttrOverride(m.id),k=(y==null?void 0:y[Oe])??m.clicks??((u=m.attributes)==null?void 0:u[Oe])??((f=m.ial)==null?void 0:f[Oe]),x=(y==null?void 0:y[Mt])??m.motion??((p=m.attributes)==null?void 0:p[Mt])??((d=m.ial)==null?void 0:d[Mt]),$=!!(k&&String(k).trim()!==""),A=!!(x&&String(x).trim()!=="");($||A)&&(s.add(m.id),n.push({blockId:m.id,pageIndex:c,hasClick:$,hasMotion:A}),l.add(c))}const g=m.children&&m.children.length>0?m.children:(b=m.rawNode)==null?void 0:b.children;Array.isArray(g)&&g.length>0&&r(g,c)}};for(const a of i.slides)r(a.blocks||[],a.pageIndex);return{totalPages:i.slides.length,affectedPagesCount:l.size,targets:n}}async function n2(e,t){const o=(t==null?void 0:t.showMessageFn)||ie.showMessage,i=(t==null?void 0:t.confirmFn)||ie.confirm,n=(t==null?void 0:t.setBlockAttrsFn)||ze,s=(t==null?void 0:t.syncDomFn)||et;if(!e)return o("请先在主编辑区打开幻灯片文档"),{totalPages:0,affectedPagesCount:0,targets:[],successCount:0,errorCount:0};const l=await i2(e,t);if(l.targets.length===0)return o("当前文档未检测到已配置的页面动效，无需清除"),{...l,successCount:0,errorCount:0};const r=l.targets.length,a=l.affectedPagesCount;return new Promise(c=>{i("危险操作：清除所有页面动效",`此操作将清除 ${a} 页中全部 ${r} 个内容块的逐步显现（v-click）与入场微动效（v-motion）配置，清除后无法撤销。是否确认继续？`,async()=>{var d;o(`正在清除 ${r} 个内容块的动效配置...`);let u=0,f=0;const p={[Oe]:"",[Mt]:""};for(const b of l.targets)try{await n(b.blockId,p),Ee.setBlockAttrOverride(b.blockId,p),s(b.blockId,p),u++}catch(m){console.error(`[SiYuanLiveSlides] 清除块 ${b.blockId} 动效失败:`,m),f++}(d=t==null?void 0:t.onSuccessNotice)==null||d.call(t,"已清除动效"),o(`已成功清除 ${u} 个内容块的动效配置`),t!=null&&t.compileCurrentDocFn&&await t.compileCurrentDocFn().catch(()=>{}),c({...l,successCount:u,errorCount:f})},()=>{c({...l,successCount:0,errorCount:0})})})}function s2(e,t){const{saveAttr:o,saveAttrs:i,savePageAttr:n}=t;async function s(){(e.videoAutoplay.value?"false":"true")==="true"?(await i({[Yo]:"true",[li]:"true"}),e.activeBlockAttrs.value[Yo]="true",e.activeBlockAttrs.value[li]="true"):(await o(Yo,"false"),e.activeBlockAttrs.value[Yo]="false")}async function l(){const P=e.videoLoop.value?"false":"true";await o(Mn,P)}async function r(){const P=e.videoMuted.value?"false":"true";await o(li,P)}async function a(){const P=e.videoControls.value?"false":"true";await o(En,P)}async function c(P){var q,j;const F=e.activeBlockId.value;if(!F)return;const E=e.rawSnippet.value||"",D=wo(E)||"",S=e.currentPageDividerId.value||e.currentDocId.value;if(P)if(P==="background"){const C={[Ye]:"background",[be]:""};S&&D&&(e.pageBackground&&(e.pageBackground.value=D),await ze(S,{[ct]:D}).catch(()=>{}),Ee.setBlockAttrOverride(S,{[ct]:D}),et(S,{[ct]:D}),e.targetSlide.value&&(e.targetSlide.value.frontmatter||(e.targetSlide.value.frontmatter={}),e.targetSlide.value.frontmatter.background=D)),await i(C)}else(P===Bn||P===Ln)&&await i({[be]:P,[Ye]:""});else{const C={[Ye]:"",[be]:""};if(e.activeBlockAttrs.value[ct]==="true"&&(C[ct]=""),S&&D&&((q=e.pageBackground)==null?void 0:q.value)===D&&(e.pageBackground&&(e.pageBackground.value=""),await ze(S,{[ct]:""}).catch(()=>{}),Ee.setBlockAttrOverride(S,{[ct]:""}),et(S,{[ct]:""}),(j=e.targetSlide.value)!=null&&j.frontmatter&&delete e.targetSlide.value.frontmatter.background),await i(C),typeof document<"u"){const M=document.querySelector(`.protyle-wysiwyg [data-node-id="${F}"]`),B=M==null?void 0:M.closest('[data-type="NodeListItem"]'),te=B==null?void 0:B.getAttribute("data-node-id");if(te&&te!==F){const V={[be]:"",[Ye]:""};et(te,V),Ee.setBlockAttrOverride(te,V),await ze(te,V).catch(()=>{})}}}}function u(){e.elemClick.value?o(Oe,""):o(Oe,"+1")}function f(P){o(Oe,P)}function p(P){o(Mt,P)}function d(P){(e.activeBlockAttrs.value[Te]||"")===P?o(Te,""):o(Te,P)}function b(P){e.elemShikiLines.value=P,o(ei,P)}function m(P){const F=P?P.trim():"",E=/^\d+$/.test(F)?`${F}px`:F;e.elemMaxHeight.value=E,o(Yi,E)}async function g(){const P=e.currentSlideLayout.value==="three-cols-header";await o(Te,P?"col-1":"left"),ie.showMessage(P?"已将当前块设置为第 1 栏":"已将当前块设置为双栏左栏")}async function y(){const P=e.activeBlockId.value;P&&ie.confirm("清除块演示属性","确定要清除当前块的所有演示属性（包含动画、插槽、备注等）吗？此操作无法撤销。",async()=>{const F={[Oe]:"",[Mt]:"",[Te]:"",[ei]:"",[Yi]:"",[Fe]:"",[be]:"",[yt]:"",[Ye]:"",[_t]:"",[ct]:"",[Wt]:"",[Yo]:"",[Mn]:"",[li]:"",[En]:""};if(et(P,F),await ze(P,F),Ee.clearBlockAttrOverride(P),typeof document<"u"){const E=document.querySelector(`.protyle-wysiwyg [data-node-id="${P}"]`),D=E==null?void 0:E.closest('[data-type="NodeListItem"]'),S=D==null?void 0:D.getAttribute("data-node-id");S&&S!==P&&(et(S,F),await ze(S,F).catch(()=>{}),Ee.clearBlockAttrOverride(S))}e.activeBlockAttrs.value={},e.elemShikiLines.value="",e.elemMaxHeight.value="",e.pageBackground&&(e.pageBackground.value=""),e.pageImage.value="",ie.showMessage("已清除本块演示属性"),e.plugin&&await e.plugin.compileCurrentDocument()})}async function k(){if(e.activeBlockId.value)try{await fo("markdown","---",e.activeBlockId.value,void 0),ie.showMessage("已在上方插入分页符"),e.plugin&&e.plugin.compileCurrentDocument()}catch{ie.showMessage("插入分页符失败")}}async function x(){const P=e.activeBlockId.value||e.currentDocId.value;if(P)try{await fo("markdown","---",void 0,P),ie.showMessage("已在下方插入分页符"),e.plugin&&e.plugin.compileCurrentDocument()}catch{ie.showMessage("插入分页符失败")}}async function $(){if(e.activeBlockId.value)try{await Qs(e.activeBlockId.value),ie.showMessage("已删除该分页符"),e.activeBlockId.value="",e.activeBlockType.value="",e.plugin&&e.plugin.compileCurrentDocument()}catch{ie.showMessage("删除失败")}}async function A(){var P,F;try{let E=null;if(typeof document<"u"){const S=e.activeBlockId.value;if(S){const q=document.querySelector(`.protyle-wysiwyg [data-node-id="${S}"]`);q&&(E=q.getAttribute("data-type")==="NodeSuperBlock"?q:q.closest('[data-type="NodeSuperBlock"]'))}if(!E){const q=e.currentPageDividerId.value||(e.activeBlockType.value==="hr"||e.activeBlockType.value==="NodeThematicBreak"?e.activeBlockId.value:"");if(q){const j=document.querySelector(`.protyle-wysiwyg [data-node-id="${q}"]`);if(j){let C=j.nextElementSibling;for(;C&&!(C.getAttribute("data-type")==="NodeThematicBreak"||(P=C.classList)!=null&&P.contains("protyle-wysiwyg__block--hr"));){const M=C.getAttribute("data-type")==="NodeSuperBlock"?C:C.querySelector('[data-type="NodeSuperBlock"]');if(M){E=M;break}C=C.nextElementSibling}}}else{const j=document.querySelector('.protyle-wysiwyg [data-type="NodeThematicBreak"], .protyle-wysiwyg .protyle-wysiwyg__block--hr'),C=Array.from(document.querySelectorAll('.protyle-wysiwyg [data-type="NodeSuperBlock"]'));for(const M of C)if(!j||M.compareDocumentPosition(j)&Node.DOCUMENT_POSITION_FOLLOWING){E=M;break}}}}const D=[];if(E){const S=Array.from(E.querySelectorAll(":scope > [data-node-id]"));for(const q of S){const j=q.getAttribute("data-node-id");j&&(D.push(j),q.removeAttribute("style"))}}else if((F=e.targetSlide.value)!=null&&F.blocks){for(const S of e.targetSlide.value.blocks)if(S.children&&S.children.length>=2){for(const q of S.children)q.id&&D.push(q.id);break}}if(D.length>0)for(const S of D)await ze(S,{style:""}).catch(()=>{});await n(yt,""),ie.showMessage("已重置超级块为平均分布比例"),e.plugin&&await e.plugin.compileCurrentDocument()}catch(E){console.error("[layout-actions] resetSuperBlockWidth error:",E),ie.showMessage("重置超级块比例失败")}}async function w(){var P,F,E;try{let D=null;if(typeof document<"u"){const q=e.currentPageDividerId.value||(e.activeBlockType.value==="hr"||e.activeBlockType.value==="NodeThematicBreak"?e.activeBlockId.value:""),j=e.activeBlockId.value;let C=[];if(q){const te=document.querySelector(`.protyle-wysiwyg [data-node-id="${q}"]`);if(te){let V=te.nextElementSibling;for(;V&&!(V.getAttribute("data-type")==="NodeThematicBreak"||(P=V.classList)!=null&&P.contains("protyle-wysiwyg__block--hr"));)C.push(V),V=V.nextElementSibling}}else{const te=document.querySelector('.protyle-wysiwyg [data-type="NodeThematicBreak"], .protyle-wysiwyg .protyle-wysiwyg__block--hr'),V=Array.from(document.querySelectorAll(".protyle-wysiwyg > [data-node-id]"));for(const K of V)if(!te||K.compareDocumentPosition(te)&Node.DOCUMENT_POSITION_FOLLOWING)C.push(K);else break}const M=[];let B;for(const te of C){const V=te.getAttribute("data-type");V==="NodeHeading"&&(B=te.getAttribute("data-node-id")||void 0);const K=[];V==="NodeSuperBlock"?K.push(te):K.push(...Array.from(te.querySelectorAll('[data-type="NodeSuperBlock"]')));for(const ae of K){if((ae.getAttribute("data-sb-layout")||"").toLowerCase()==="row")continue;const re=ae.getAttribute("data-node-id")||"";let Se=[];const $e=Array.from(ae.querySelectorAll('[data-type="NodeListItem"]'));if($e.length===4&&(Se=$e.map(ke=>ke.getAttribute("data-node-id")).filter(Boolean)),Se.length!==4){const ke=Array.from(ae.querySelectorAll(":scope > [data-node-id]"));ke.length===4&&(Se=ke.map(_e=>_e.getAttribute("data-node-id")).filter(Boolean))}Se.length===4&&M.push({sbId:re,itemIds:Se,headerId:B})}}M.length>0&&(j&&(D=M.find(te=>{if(te.sbId===j||te.itemIds.includes(j))return!0;const V=document.querySelector(`.protyle-wysiwyg [data-node-id="${te.sbId}"]`),K=document.querySelector(`.protyle-wysiwyg [data-node-id="${j}"]`);return!!(V&&K&&V.contains(K))})||null),D||(D=M[0]))}if(!D&&((F=e.targetSlide.value)!=null&&F.blocks)){const q=e.targetSlide.value,j=[];for(const M of q.blocks)M.rawNode?j.push(M.rawNode):j.push({id:M.id,type:M.type,content:M.content,markdown:M.rawMarkdown,children:M.children,ial:M.attributes||M.ial||{}});const C=bh(j,e.activeBlockId.value);C&&C.items.length===4&&(D={sbId:C.superBlockNode.id,itemIds:C.items.map(M=>M.id),headerId:(E=C.headerNode)==null?void 0:E.id})}const S=e.currentPageDividerId.value||e.currentDocId.value;if(S&&(e.currentPageDividerLayout.value="clover",e.targetSlide.value&&(e.targetSlide.value.frontmatter||(e.targetSlide.value.frontmatter={}),e.targetSlide.value.frontmatter.layout="clover"),Ee.setBlockAttrOverride(S,{[be]:"clover"}),et(S,{[be]:"clover"}),await ze(S,{[be]:"clover"}).catch(()=>{})),D&&D.itemIds.length>0){D.headerId&&(Ee.setBlockAttrOverride(D.headerId,{[Te]:"header"}),et(D.headerId,{[Te]:"header"}),await ze(D.headerId,{[Te]:"header"}).catch(()=>{}));const q=Math.min(4,D.itemIds.length);for(let j=0;j<q;j++){const C=D.itemIds[j],M=`col-${j+1}`;Ee.setBlockAttrOverride(C,{[Te]:M}),et(C,{[Te]:M}),await ze(C,{[Te]:M}).catch(()=>{})}}return ie.showMessage("已将本页版式设为四叶草（田字型）布局"),e.plugin&&await e.plugin.compileCurrentDocument(),!0}catch(D){return console.error("[layout-actions] applyCloverLayout error:",D),ie.showMessage("配置四叶草布局失败",4e3,"error"),!1}}async function _(){var F,E;const P=e.currentDocId.value||((F=e.plugin)==null?void 0:F.currentDocId);if(!P){ie.showMessage("请先在主编辑区打开幻灯片文档");return}if((E=t.isBatchProcessing)!=null&&E.value){ie.showMessage("正在批量处理中，请稍候...");return}t.isBatchProcessing&&(t.isBatchProcessing.value=!0);try{await Lc(P,{onSuccessNotice:t.triggerSaveNotice,compileCurrentDocFn:async()=>{e.plugin&&await e.plugin.compileCurrentDocument()}})}finally{t.isBatchProcessing&&(t.isBatchProcessing.value=!1)}}async function O(){var F,E;const P=e.currentDocId.value||((F=e.plugin)==null?void 0:F.currentDocId);if(!P){ie.showMessage("请先在主编辑区打开幻灯片文档");return}if((E=t.isBatchProcessing)!=null&&E.value){ie.showMessage("正在批量处理中，请稍候...");return}t.isBatchProcessing&&(t.isBatchProcessing.value=!0);try{const D=await n2(P,{onSuccessNotice:t.triggerSaveNotice,compileCurrentDocFn:async()=>{e.plugin&&await e.plugin.compileCurrentDocument()}});D.successCount>0&&e.activeBlockId.value&&D.targets.some(S=>S.blockId===e.activeBlockId.value)&&(delete e.activeBlockAttrs.value[Oe],delete e.activeBlockAttrs.value[Mt])}finally{t.isBatchProcessing&&(t.isBatchProcessing.value=!1)}}async function H(){var E,D,S,q;const P=await zw({currentDocId:((E=e.currentDocId)==null?void 0:E.value)||"",activeBlockId:((D=e.activeBlockId)==null?void 0:D.value)||""});if(!P.success){ie.showMessage(P.error||"合并为横向超级块失败");return}const F=`🎉 已成功合并为横向超级块 (${P.colCount||2} 列)`;ie.showMessage(F),t.triggerSaveNotice&&t.triggerSaveNotice(F),(S=e.plugin)!=null&&S.compileCurrentDocument&&await e.plugin.compileCurrentDocument((q=e.currentDocId)==null?void 0:q.value)}return{onToggleVideoAutoplay:s,onToggleVideoLoop:l,onToggleVideoMuted:r,onToggleVideoControls:a,onImageRoleChange:c,toggleElemClick:u,onElemClickStepChange:f,onElemMotionChange:p,onElemSlotChange:d,onElemShikiLinesChange:b,onElemMaxHeightChange:m,onSetTwoColsContrast:g,onClearBlockAttrs:y,onInsertDividerBefore:k,onInsertDividerAfter:x,onDeleteCurrentBlock:$,onConvertToSuperBlock:H,resetSuperBlockWidth:A,applyCloverLayout:w,onAutoAnimateDocument:_,onClearAnimationsDocument:O}}function r2(e){const{triggerSaveNotice:t,saveAttrs:o,saveAttr:i,savePageAttr:n,applyPageLayoutAndRatio:s,saveDocAttr:l}=jw(e),r=Jw(e,{triggerSaveNotice:t}),a=s2(e,{saveAttr:i,saveAttrs:o,savePageAttr:n,triggerSaveNotice:t,isBatchProcessing:r.isBatchProcessing});async function c(){var y;if(!e.latestDoc.value){ie.showMessage("请先在主编辑区打开幻灯片文档");return}const d=e.latestDoc.value,b=await zo(d,(y=e.currentDocId)==null?void 0:y.value,e.plugin);ie.showMessage("正在导出单文件离线 HTML（内联媒体资源中...）",2e3);const m=await fc(d,{title:b});hc(`${b}.html`,m)&&ie.showMessage(`已开始下载单文件离线 HTML 演示包 (${b}.html)`)}function u(){if(!e.latestDoc.value){ie.showMessage("请先在主编辑区打开幻灯片文档");return}pc(e.latestDoc.value)&&ie.showMessage("已唤起打印视窗，请在打印选项中选择「另存为 PDF」")}const f=pe(!1);async function p(){var d;if(f.value){ie.showMessage("正在导出图片中，请稍候...",2e3);return}if(!e.latestDoc.value){ie.showMessage("请先在主编辑区打开幻灯片文档");return}f.value=!0;try{ie.showMessage("正在启动后台沙箱并逐页导出幻灯片图片...");const b=e.latestDoc.value,m=await zo(b,(d=e.currentDocId)==null?void 0:d.value,e.plugin),g=await vc(b,{title:m,onProgress:(y,k)=>{ie.showMessage(`正在导出幻灯片图片 (${y} / ${k})...`,2e3)}});g.success?ie.showMessage(`🎉 成功导出 ${g.total||0} 张幻灯片高清图片并已保存为 ${m}.zip！`,4e3):ie.showMessage(`导出图片失败：${g.error||"未知异常"}`)}finally{f.value=!1}}return{triggerSaveNotice:t,saveAttrs:o,saveAttr:i,savePageAttr:n,applyPageLayoutAndRatio:s,saveDocAttr:l,onToggleVideoAutoplay:a.onToggleVideoAutoplay,onToggleVideoLoop:a.onToggleVideoLoop,onToggleVideoMuted:a.onToggleVideoMuted,onToggleVideoControls:a.onToggleVideoControls,onImageRoleChange:a.onImageRoleChange,onToggleNoteBlock:r.onToggleNoteBlock,createNoteBlockOnCurrentSlide:r.createNoteBlockOnCurrentSlide,onAddNoteBlock:r.onAddNoteBlock,onLocateNoteBlock:r.onLocateNoteBlock,onGenerateNotesWithAI:r.onGenerateNotesWithAI,isGeneratingNotes:r.isGeneratingNotes,isBatchProcessing:r.isBatchProcessing,onBatchAppendNotes:r.onBatchAppendNotes,onBatchDeleteNotes:r.onBatchDeleteNotes,onIdentifyNotesBlocks:r.onIdentifyNotesBlocks,onAddOrIdentifyNotesBlocks:r.onAddOrIdentifyNotesBlocks,toggleElemClick:a.toggleElemClick,onElemClickStepChange:a.onElemClickStepChange,onElemMotionChange:a.onElemMotionChange,onElemSlotChange:a.onElemSlotChange,onElemShikiLinesChange:a.onElemShikiLinesChange,onElemMaxHeightChange:a.onElemMaxHeightChange,onSetTwoColsContrast:a.onSetTwoColsContrast,onClearBlockAttrs:a.onClearBlockAttrs,onInsertDividerBefore:a.onInsertDividerBefore,onInsertDividerAfter:a.onInsertDividerAfter,onDeleteCurrentBlock:a.onDeleteCurrentBlock,onConvertToSuperBlock:a.onConvertToSuperBlock,resetSuperBlockWidth:a.resetSuperBlockWidth,applyCloverLayout:a.applyCloverLayout,onAutoAnimateDocument:a.onAutoAnimateDocument,onClearAnimationsDocument:a.onClearAnimationsDocument,isExportingImages:f,onExportHtml:c,onExportPdf:u,onExportImages:p}}function l2(e){const t=ye(()=>Ir(e.activeBlockType.value));function o(i){const{attrKey:n,fallback:s,mode:l="defined"}=i,r=a=>l==="truthy"?a:a!==void 0;return ye(()=>{if(t.value){const c=e.activeBlockAttrs.value[n];if(r(c))return c}const a=e.currentPageDividerId.value||(t.value?e.activeBlockId.value:"");if(a){const c=Ee.getBlockAttrOverride(a);if(r(c==null?void 0:c[n]))return c[n]}return s()})}return{isDivider:t,resolvePageAttr:o}}function Cs(e){if(e.type==="h"){if(e.subType==="h1")return 1;if(e.subType==="h2")return 2;if(e.subType==="h3")return 3}const t=(e.markdown||e.content||"").trimStart();return t.startsWith("# ")?1:t.startsWith("## ")?2:t.startsWith("### ")?3:null}function a2(e,t){for(let o=t-1;o>=0;o--){const i=e[o];if(bo(i)||(i.content||i.markdown||"").trim())return i}return null}function Is(e){const t=e.type;if(t==="c"||t==="code"||t==="t"||t==="table"||t==="s"||t==="super")return 3;if(t==="l"||t==="list"||t==="b"||t==="blockquote")return 2;const o=(e.markdown||e.content||"").trim();return o?o.includes("![")||o.includes("<img")||o.length>100?2:1:0}function Nl(e,t){if(e===1)return"cover";let o=!1,i=-1;for(let r=0;r<t.length;r++){const a=t[r],c=(a.markdown||a.content||"").trim();if(c.includes("![")||c.includes("<img")||a.type==="img"){o=!0,i=r;break}}if(o)return i===0?"image-left":"image-right";let n=0,s=!1,l=!1;for(const r of t)(r.type==="i"||r.type==="l"||(r.markdown||"").trim().startsWith("- "))&&n++,r.type==="s"&&(s=!0),r.type==="b"&&(l=!0);return s||n>=3?"two-cols":l&&t.length<=2?"quote":"default"}function c2(e,t){const o=[],i=new Set,n=6,s=6;let l=0,r=0,a=0,c=0,u=null;function f(p){const d=[];for(let b=p+1;b<e.length;b++){const m=e[b];if(bo(m))break;const g=Cs(m);if(g!==null&&(g===1||g===2||g===3))break;d.push(m)}return d}if(e.length>0){let p=!1,d=-1;for(let b=0;b<e.length;b++){const m=e[b];if(bo(m)){p=!0;break}if((m.content||m.markdown||"").trim()){d=b;break}}if(!p&&d>=0){const b=e[d],m=Cs(b);let g=m===1?"cover":"default";if(m!==1){const k=f(d);g=Nl(m,k)}const y=m===1?"作为第一页起点插入分页线 (封面大章)":"作为第一页起点插入分页线";o.push({blockId:b.id,recommendedLayout:g,reason:y}),i.add(b.id)}}for(let p=0;p<e.length;p++){const d=e[p];if(bo(d)){l=0,r=0,a=0,c=0,u=null;continue}const b=a2(e,p),m=!b||bo(b),g=Cs(d);if(g===1||g===2||g===3){if(!(a===1&&c===0&&u!==null&&!(u===1&&g===2))&&!m&&l>0&&!i.has(d.id)){let A=g===1?"cover":"default";{const _=f(p);A=Nl(g,_)}let w=g===1?"检测到一级核心章节标题，建议作为新幻灯片封面/大章":g===2?"检测到二级分论点标题，建议开启新页":"检测到三级要点标题，建议开启新页";A==="image-right"||A==="image-left"?w+=" (推荐图文版式)":A==="two-cols"?w+=" (推荐双栏版式)":A==="quote"&&(w+=" (推荐引言版式)"),o.push({blockId:d.id,recommendedLayout:A,reason:w}),i.add(d.id),l=1,r=Is(d),a=1,c=0,u=g;continue}l++,r+=Is(d),a++,u=g;continue}const k=Is(d);if((l>=n||r+k>s&&l>0)&&!m&&l>0&&!i.has(d.id)){o.push({blockId:d.id,recommendedLayout:"default",reason:"当前页已达容量上限 (避免信息超载)，建议在此分页"}),i.add(d.id),l=1,r=k,a=0,c=1,u=null;continue}l++,r+=k,c++}return o}async function Dc(e){if(!e.currentDocId&&typeof document<"u"){const s=document.querySelector(".protyle-content[data-doc-id]");e.currentDocId=(s==null?void 0:s.getAttribute("data-doc-id"))||""}if(!e.currentDocId){ie.showMessage("请先打开一篇思源笔记文档");return}const t=await Si(e.currentDocId).catch(()=>[]);if(!t||t.length===0){ie.showMessage("当前文档无内容，无需断页");return}const o=t.map(s=>({id:s.id,type:s.type,subType:s.subType,content:s.content||"",markdown:s.markdown||""})),i=c2(o);if(i.length===0){ie.showMessage("智能分析完毕：当前文档结构合理，暂无新增分页建议");return}ie.showMessage(`智能分析完毕：发现 ${i.length} 处建议分页点，正在自动插入分页线...`);let n=0;for(const s of i)try{await fo("markdown","---",s.blockId,void 0),await ze(s.blockId,{"custom-slides-layout":s.recommendedLayout}),n++}catch(l){console.warn("Failed to insert divider:",l)}ie.showMessage(`已成功在 ${n} 处插入分页线并重新编译`),e.compileCurrentDocument(e.currentDocId)}async function Oc(e){var s,l,r,a,c,u;if(!e.currentDocId&&typeof document<"u"){const f=document.querySelector(".protyle-content[data-doc-id]");e.currentDocId=(f==null?void 0:f.getAttribute("data-doc-id"))||""}if(!e.currentDocId){ie.showMessage("请先打开一篇思源笔记文档");return}const t=await Si(e.currentDocId).catch(()=>[]);if(!t||t.length===0){ie.showMessage("当前文档无内容");return}const o=[],i=[];for(const f of t)f.type==="tb"||f.type==="thematic-break"||f.type==="NodeThematicBreak"||((s=f.markdown)==null?void 0:s.trim())==="---"||((l=f.markdown)==null?void 0:l.trim())==="***"||f.type==="b"&&(((r=f.markdown)==null?void 0:r.trim())==="---"||((a=f.content)==null?void 0:a.trim())==="---")?o.push(f.id):((c=f.ial)!=null&&c[po]||(u=f.ial)!=null&&u[be])&&i.push(f.id);if(o.length===0&&i.length===0){ie.showMessage("当前文档中未发现需要清除的幻灯片分页线");return}const n=o.length;return new Promise(f=>{ie.confirm("危险操作：清除所有分页线",`此操作将从正文中彻底删除全部 ${n} 处幻灯片分页线（全篇将合并为单页），删除后无法撤销。是否确认继续？`,async()=>{ie.showMessage(`正在清除文档中的 ${n} 处分页线...`);let p=0;for(const d of o)try{await Qs(d),p++}catch(b){console.warn("Failed to delete divider block:",b)}for(const d of i)try{await ze(d,{[po]:"",[be]:""})}catch(b){console.warn("Failed to clear slide attrs:",b)}ie.showMessage(`已成功清除文档中的 ${p} 处分页线并重新编译`),await e.compileCurrentDocument(e.currentDocId),f()},()=>{f()})})}const d2={class:"spm-slides-inspector"},u2={class:"spm-inspector-topbar"},f2={class:"spm-inspector-title"},h2={class:"slides-icon",style:{fill:"none !important"},"aria-hidden":"true",viewBox:"0 0 24 24"},p2={class:"spm-inspector-topbar-actions"},m2={class:"spm-target-banner"},g2={class:"spm-target-info"},y2=["aria-label"],b2={key:0,class:"spm-save-status"},v2=["title"],k2={class:"spm-inspector-body"},w2=zt({__name:"SlidesInspectorDockView",setup(e,{expose:t}){const o=Kt("plugin"),i=pe(!1);function n(ee){i.value=!1,c.value=ee.docId,o!=null&&o.compileCurrentDocument&&o.compileCurrentDocument(ee.docId)}const s=pe(""),l=pe(""),r=pe({}),a=pe(""),c=pe(""),u=pe(""),f=pe(""),p=pe(""),d=pe(""),b=pe(""),m=pe(""),g=pe(null),y=pe(""),k=pe("");function x(){var ge;const ee=s.value||c.value;ee&&typeof navigator<"u"&&(ge=navigator==null?void 0:navigator.clipboard)!=null&&ge.writeText&&navigator.clipboard.writeText(ee).then(()=>{k.value="已复制！",setTimeout(()=>{k.value=""},1500)}).catch(()=>{})}const $=ye(()=>Ir(l.value)),A=ye(()=>l.value==="NodeCodeBlock"),w=pe(!1),_=ye(()=>{if(w.value||Ke.value)return!0;const ee=a.value||"";return!!wo(ee)}),O=ye(()=>{const ee=l.value||"";if(ee==="NodeVideo"||ee==="video")return!0;const ge=a.value||"";return!!(/<video\b/i.test(ge)||/\.mp4\b/i.test(ge))}),H=ye(()=>!s.value||s.value===c.value||l.value==="doc"||l.value==="NodeDocument"),P=ye(()=>{const ee=s.value||c.value||"";return ee.length>8?ee.slice(-8):ee||"无"}),F=ye(()=>a.value?a.value.replace(/<[^>]+>/g,"").replace(/[\r\n]+/g," ").trim().slice(0,45):""),E=ye(()=>{if($.value)return"分页符 (---)";if(H.value)return"全局文档";if(O.value)return"视频块";let ee="内容块";switch(l.value){case"NodeHeading":ee="标题块";break;case"NodeParagraph":ee="段落块";break;case"NodeCodeBlock":ee="代码块";break;case"NodeVideo":ee="视频块";break;case"NodeList":case"NodeListItem":ee="列表项";break;case"NodeBlockquote":ee="引述块";break;case"NodeTable":ee="表格块";break;case"NodeSuperBlock":case"s":case"sb":ee="超级块";break;default:ee="内容块";break}return d.value?b.value?`${b.value.replace(/^col-(\d+)$/,"第 $1 栏")} › ${ee}`:`分栏容器 › ${ee}`:ee}),D=ye(()=>$.value?"tag-divider":H.value?"tag-doc":"tag-block"),S=ye(()=>r.value[be]||"default"),q=ye(()=>r.value[_t]||"slide-left"),j=pe(""),C=pe(""),M=ye(()=>r.value[Ni]||"inherit"),B=ye(()=>{var ee;return Cc((ee=g.value)==null?void 0:ee.slides,{activeBlockId:s.value,activeBlockType:l.value,currentTopBlockId:u.value,currentPageDividerId:f.value,activeBlockAttrs:r.value})}),te=ye(()=>{var ee;return((ee=B.value)==null?void 0:ee.notes)||""}),V=ye(()=>{var ee,ge,Be;return((Be=(ge=(ee=B.value)==null?void 0:ee.noteBlocks)==null?void 0:ge[0])==null?void 0:Be.id)||""}),K=ye(()=>{var We,qe,Re,kt,cn,To;if($.value){const it=r.value[be]||r.value["custom-slides-layout"];if(it)return it}const ee=r.value[Te]||r.value["custom-slides-slot"];if(ee&&(["col-1","col-2","col-3"].includes(ee)||/^col-\d+$/.test(ee)))return"cols-header";if(p.value)return p.value;const ge=f.value||($.value?s.value:"");if(ge){const it=Ee.getBlockAttrOverride(ge);if(it!=null&&it[be])return it[be]}if(ge&&((We=g.value)!=null&&We.slides)){const it=g.value.slides.find(oi=>oi.startBlockId===ge);if((qe=it==null?void 0:it.frontmatter)!=null&&qe.layout)return it.frontmatter.layout}if((kt=(Re=B.value)==null?void 0:Re.frontmatter)!=null&&kt.layout)return B.value.frontmatter.layout;if((To=(cn=B.value)==null?void 0:cn.blocks)!=null&&To.some(it=>it.slot&&(["col-1","col-2","col-3"].includes(it.slot)||/^col-\d+$/.test(it.slot))))return"cols-header";const Be=Ee.getBlockAttrOverride(c.value);return Be!=null&&Be[be]?Be[be]:"default"}),ae=l2({activeBlockId:s,activeBlockType:l,activeBlockAttrs:r,currentPageDividerId:f}),oe=ae.resolvePageAttr({attrKey:yt,mode:"truthy",fallback:()=>{var ee,ge;return((ge=(ee=B.value)==null?void 0:ee.frontmatter)==null?void 0:ge.layoutRatio)||""}}),re=ae.resolvePageAttr({attrKey:ci,fallback:()=>{var ee,ge;return((ge=(ee=B.value)==null?void 0:ee.frontmatter)==null?void 0:ge.mask)||""}}),Se=ae.resolvePageAttr({attrKey:Jo,fallback:()=>{var ee,ge;return((ge=(ee=B.value)==null?void 0:ee.frontmatter)==null?void 0:ge.maskRatio)||""}}),$e=ae.resolvePageAttr({attrKey:di,fallback:()=>{var ee,ge;return((ge=(ee=B.value)==null?void 0:ee.frontmatter)==null?void 0:ge.maskStyle)||"solid"}}),ke=ae.resolvePageAttr({attrKey:ui,fallback:()=>{var ee,ge;return((ge=(ee=B.value)==null?void 0:ee.frontmatter)==null?void 0:ge.maskInitial)||"hidden"}});function _e(ee){if(!ee||(ee.getAttribute("data-sb-layout")||"").toLowerCase()!=="col")return null;const Be=Array.from(ee.querySelectorAll(":scope > [data-node-id]"));if(Be.length<2)return null;const We=Be.length,qe=Be.map(To=>{const it=To.getAttribute("style")||"",oi=it.match(/calc\(\s*([\d.]+)%/);if(oi)return parseFloat(oi[1]);const Ti=it.match(/(?:^|;|\s)width:\s*([\d.]+)%/i);return Ti?parseFloat(Ti[1]):null});let Re="",kt=!1;if(qe.some(To=>To!==null)){kt=!0;const To=qe.reduce((Ne,wt)=>Ne+(wt||0),0),it=qe.filter(Ne=>Ne===null).length,oi=it>0?Math.max(0,100-To)/it:100/Be.length,Ti=qe.map(Ne=>Ne!==null?Ne:oi),Id=Ti.reduce((Ne,wt)=>Ne+wt,0)||1,Ai=Ti.map(Ne=>Ne/Id*100);if(Ai.length===2){const[Ne]=Ai;if(Ne>=48&&Ne<=52)Re="1:1";else if(Ne>=31&&Ne<=35)Re="1:2";else if(Ne>=65&&Ne<=69)Re="2:1";else if(Ne>=28&&Ne<=32)Re="3:7";else if(Ne>=68&&Ne<=72)Re="7:3";else if(Ne>=38&&Ne<=42)Re="4:6";else if(Ne>=58&&Ne<=62)Re="6:4";else{const wt=Math.round(Ne);Re=`${wt}:${100-wt}`}}else if(Ai.length===3){const[Ne,wt,Ao]=Ai;if(Ne>=31&&Ne<=35&&wt>=31&&wt<=35&&Ao>=31&&Ao<=35)Re="1:1:1";else if(Ne>=23&&Ne<=27&&wt>=48&&wt<=52&&Ao>=23&&Ao<=27)Re="1:2:1";else if(Ne>=48&&Ne<=52&&wt>=23&&wt<=27&&Ao>=23&&Ao<=27)Re="2:1:1";else if(Ne>=23&&Ne<=27&&wt>=23&&wt<=27&&Ao>=48&&Ao<=52)Re="1:1:2";else{const Br=Math.round(Ne),Lr=Math.round(wt);Re=`${Br}:${Lr}:${100-Br-Lr}`}}else Re=Ai.map(Ne=>Math.round(Ne)).join(":")}else kt=!1,Re=Array.from({length:We},()=>1).join(":");const cn=We>=2?"cols-header":"two-cols";return{hasSuperBlock:!0,colCount:We,ratio:Re,isCustomWidth:kt,recommendedLayout:cn}}function R(ee){if(!(ee!=null&&ee.blocks))return null;for(const ge of ee.blocks){const Be=ge.rawNode;if(Be&&ut(Be)&&so(Be)){const qe=Ii(Be).length,Re=xr(Be);return{hasSuperBlock:!0,colCount:qe,ratio:Re||Array.from({length:qe},()=>1).join(":"),isCustomWidth:!!Re,recommendedLayout:qe>=2?"cols-header":"two-cols"}}}return null}const ne=ye(()=>{var ee;if(typeof document<"u"){const ge=s.value;if(ge){const We=document.querySelector(`.protyle-wysiwyg [data-node-id="${ge}"]`);if(We){const qe=We.getAttribute("data-type")==="NodeSuperBlock"?We:We.closest('[data-type="NodeSuperBlock"]');if(qe){const Re=_e(qe);if(Re)return Re}}}const Be=f.value||($.value?s.value:"");if(Be){const We=document.querySelector(`.protyle-wysiwyg [data-node-id="${Be}"]`);if(We){let qe=We.nextElementSibling;for(;qe&&!(qe.getAttribute("data-type")==="NodeThematicBreak"||(ee=qe.classList)!=null&&ee.contains("protyle-wysiwyg__block--hr"));){const Re=qe.getAttribute("data-type")==="NodeSuperBlock"?qe:qe.querySelector('[data-type="NodeSuperBlock"]');if(Re){const kt=_e(Re);if(kt)return kt}qe=qe.nextElementSibling}}}else{const We=document.querySelector('.protyle-wysiwyg [data-type="NodeThematicBreak"], .protyle-wysiwyg .protyle-wysiwyg__block--hr'),qe=Array.from(document.querySelectorAll('.protyle-wysiwyg [data-type="NodeSuperBlock"]'));for(const Re of qe)if(!We||Re.compareDocumentPosition(We)&Node.DOCUMENT_POSITION_FOLLOWING){const kt=_e(Re);if(kt)return kt}}}return R(B.value)}),L=ye(()=>{var ee;return((ee=ne.value)==null?void 0:ee.ratio)||""}),U=ye(()=>{const ee=l.value||"";if(ee==="NodeSuperBlock"||ee==="s"||ee==="sb")return!0;if(typeof document<"u"&&s.value){const ge=document.querySelector(`.protyle-wysiwyg [data-node-id="${s.value}"]`);if(ge!=null&&ge.closest('[data-type="NodeSuperBlock"]'))return!0}return!1}),v=ye(()=>{var ee;return((ee=B.value)==null?void 0:ee.pageIndex)||1}),W=ye(()=>!!r.value[Fe]);function z(){if(!d.value)return!1;if(s.value===d.value||typeof document>"u")return!0;const ee=document.querySelector(`.protyle-wysiwyg [data-node-id="${d.value}"]`)||document.querySelector(`[data-node-id="${d.value}"]`);if(!ee)return!1;const ge=ee.querySelector(":scope > [data-node-id], :scope > div > [data-node-id]");return(ge==null?void 0:ge.getAttribute("data-node-id"))===s.value}const I=ye(()=>{var ge;if(r.value[Oe]!==void 0)return r.value[Oe]||"";if(d.value&&z())return m.value||"";if(d.value)return"";const ee=s.value;if(ee&&((ge=B.value)!=null&&ge.blocks)){const Be=B.value.blocks.find(We=>We.id===ee);if(Be!=null&&Be.clicks)return Be.clicks}return""}),T=ye(()=>{var ge;if(r.value[Mt])return r.value[Mt];const ee=s.value;if(ee&&((ge=B.value)!=null&&ge.blocks)){const Be=B.value.blocks.find(We=>We.id===ee);if(Be!=null&&Be.motion)return typeof Be.motion=="string"?Be.motion:JSON.stringify(Be.motion)}return""}),N=ye(()=>{var ge;if(r.value[Te])return r.value[Te];const ee=s.value;if(ee&&((ge=B.value)!=null&&ge.blocks)){const Be=B.value.blocks.find(We=>We.id===ee);if(Be!=null&&Be.slot)return Be.slot}return""}),Y=pe(""),G=pe(""),Z=ye(()=>r.value[Yo]==="true"),Q=ye(()=>r.value[Mn]==="true"),ce=ye(()=>r.value[li]==="true"),se=ye(()=>r.value[En]!=="false"),me=ye(()=>{var ee,ge;return((ge=(ee=g.value)==null?void 0:ee.config)==null?void 0:ge.theme)||r.value[Vi]||"apple-basic"}),Ce=ye(()=>{var ee,ge;return((ge=(ee=g.value)==null?void 0:ee.config)==null?void 0:ge.aspectRatio)||r.value[Ki]||"16/9"}),we=ye(()=>{var ee,ge;return((ge=(ee=g.value)==null?void 0:ee.config)==null?void 0:ge.defaultTransition)||r.value[Gi]||"slide-left"}),De=ye(()=>{var ee,ge;return((ge=(ee=g.value)==null?void 0:ee.config)==null?void 0:ge.spacing)||r.value[Es]||"normal"}),He=ye(()=>{var ee,ge;return((ge=(ee=g.value)==null?void 0:ee.config)==null?void 0:ge.background)||r.value[An]||""}),Ke=ye(()=>{var qe,Re;if((r.value[Ye]||r.value["slides-role"])===Vl||r.value[ct]==="true")return"background";const ge=r.value[be]||r.value["slides-layout"];if(ge==="image-left"||ge==="image-right")return ge;const Be=a.value||"",We=wo(Be);if(We&&((Re=(qe=B.value)==null?void 0:qe.frontmatter)!=null&&Re.background)){const kt=B.value.frontmatter.background;if(kt===We||kt.endsWith(We)||We.endsWith(kt))return"background"}return""}),rt=ye(()=>!!(r.value[Oe]||r.value[Mt]||r.value[Te]||r.value[ei]||r.value[Fe]||r.value["slides-note"]||r.value[Ye]||r.value[be]||r.value[Yo]||r.value[Mn]||r.value[li]||r.value[En])),{saveAttr:Pe,savePageAttr:ft,applyPageLayoutAndRatio:tt,applyCloverLayout:Ge,resetSuperBlockWidth:fe,saveDocAttr:he,onToggleVideoAutoplay:Qe,onToggleVideoLoop:lt,onToggleVideoMuted:It,onToggleVideoControls:at,onImageRoleChange:ao,onToggleNoteBlock:Hc,onAddNoteBlock:Fc,onLocateNoteBlock:jc,onGenerateNotesWithAI:Uc,isGeneratingNotes:Wc,isBatchProcessing:an,onBatchDeleteNotes:qc,onAddOrIdentifyNotesBlocks:Vc,onAutoAnimateDocument:Kc,onClearAnimationsDocument:Gc,toggleElemClick:Yc,onElemClickStepChange:Zc,onElemMotionChange:Jc,onElemSlotChange:Xc,onElemShikiLinesChange:Qc,onElemMaxHeightChange:ed,onSetTwoColsContrast:td,onClearBlockAttrs:od,onInsertDividerBefore:id,onInsertDividerAfter:$r,onDeleteCurrentBlock:nd,onConvertToSuperBlock:Tr,onExportHtml:sd,onExportPdf:rd}=r2({activeBlockId:s,activeBlockType:l,activeBlockAttrs:r,rawSnippet:a,currentDocId:c,currentPageDividerId:f,currentPageDividerLayout:p,parentContainerId:d,parentContainerClicks:m,latestDoc:g,targetSlide:B,currentSlideNoteBlockId:V,currentSlideLayout:K,isNoteBlock:W,elemClick:I,videoAutoplay:Z,videoLoop:Q,videoMuted:ce,videoControls:se,pageBackground:j,pageImage:C,elemShikiLines:Y,elemMaxHeight:G,saveStatus:y,plugin:o}),rs=pe(!1);function $o(){rs.value=Rw(s.value,l.value)}ti(()=>{typeof document<"u"&&(document.addEventListener("selectionchange",$o),document.addEventListener("mouseup",$o),document.addEventListener("keyup",$o)),$o()}),sn(()=>{typeof document<"u"&&(document.removeEventListener("selectionchange",$o),document.removeEventListener("mouseup",$o),document.removeEventListener("keyup",$o))}),Ho([s,l],()=>{$o()});async function ld(ee){if(ee==="clover"){if(!await Ge())return}else ft(be,ee)}function ad(ee){ft(yt,ee)}async function cd(ee){await ft(ci,ee),(ee==="clockwise"||ee==="counter-clockwise"||ee==="cw"||ee==="ccw")&&(!Se.value||Se.value==="1:1")&&await ft(Jo,"1:1:1:1")}function dd(ee){ft(Jo,ee)}function ud(ee){ft(di,ee)}function fd(ee){ft(ui,ee)}function Ar(ee){if(!ee)return;const ge=ee.recommendedLayout||(ee.colCount&&ee.colCount>=2?"cols-header":"two-cols"),Be=ee.ratio||(ee.colCount?Array(ee.colCount).fill(1).join(":"):"1:1");tt(ge,Be)}function hd(ee){ft(yt,ee)}async function pd(){await fe()}function md(ee){Pe(_t,ee)}function gd(ee){C.value=ee,Pe(Wt,ee)}function yd(ee){Pe(Ni,ee==="inherit"?"":ee)}function bd(ee){he(Vi,ee)}function vd(ee){he(An,ee)}function kd(ee){he(Ki,ee)}function wd(ee){he(Gi,ee)}function xd(ee){he(Es,ee)}function Mr(){o!=null&&o.openBottomPreviewTab&&o.openBottomPreviewTab()}function Sd(){o!=null&&o.openPresenterTab&&o.openPresenterTab()}let ls=!1;function Er(){if(!ls){ls=!0;try{o&&typeof o.openSetting=="function"?o.openSetting():o&&o.setting&&typeof o.setting.open=="function"&&o.setting.open(o.name||"siyuan-live-slides")}finally{setTimeout(()=>{ls=!1},500)}}}function _d(){o&&Ot("aiScript")&&Dc(o)}async function Cd(){if(o&&Ot("aiScript")){if(an.value)return;an.value=!0;try{await Oc(o)}finally{an.value=!1}}}return t({setActiveBlock(ee){s.value=ee.id,l.value=ee.type,r.value={...ee.attrs},a.value=ee.content||ee.markdown||"",u.value=ee.topBlockId||ee.id,f.value=ee.pageDividerId||"",p.value=ee.pageDividerLayout||"",d.value=ee.parentContainerId||"",b.value=ee.parentContainerSlot||"",m.value=ee.parentContainerClicks||"",ee.rootId?c.value=ee.rootId:(ee.type==="doc"||ee.type==="NodeDocument")&&ee.id&&(c.value=ee.id),j.value=ee.attrs[ct]||"",C.value=ee.attrs[Wt]||"",Y.value=ee.attrs[ei]||"",G.value=ee.attrs[Yi]||"",w.value=!!ee.isImage},updateDocument(ee){g.value=ee,c.value=ee.docId},openImportDialog(){i.value=!0},setCurrentDocId(ee){c.value=ee}}),(ee,ge)=>(J(),X("div",d2,[h("div",u2,[h("div",f2,[(J(),X("svg",h2,[...ge[2]||(ge[2]=[h("rect",{x:"2",y:"3",width:"20",height:"14",rx:"2"},null,-1),h("line",{x1:"8",y1:"21",x2:"16",y2:"21"},null,-1),h("line",{x1:"12",y1:"17",x2:"12",y2:"21"},null,-1)])])),ge[3]||(ge[3]=h("span",null,"演示配置",-1))]),h("div",p2,[ue(Ot)("import")?(J(),X("button",{key:0,class:"spm-icon-btn b3-tooltips b3-tooltips__sw","aria-label":"导入 Slidev 演示文档 (.md / .zip)",onClick:ge[0]||(ge[0]=Be=>i.value=!0)},[le(de,{name:"import"}),ge[4]||(ge[4]=h("span",null,"导入",-1))])):Ae("",!0),h("button",{class:"spm-icon-btn is-primary b3-tooltips b3-tooltips__sw","aria-label":"在下方分屏开启幻灯片预览 (Alt+P)",onClick:Mr},[le(de,{name:"split-preview"}),ge[5]||(ge[5]=h("span",null,"分屏预览",-1))])])]),h("div",m2,[h("div",g2,[h("span",{class:xe(["spm-target-tag",D.value])},ve(E.value),3),h("span",{class:"spm-target-id b3-tooltips b3-tooltips__se","aria-label":k.value||"点击复制 ID: "+(s.value||c.value),onClick:x},[le(de,{name:"copy"}),h("span",null,"#"+ve(P.value),1)],8,y2)]),y.value?(J(),X("span",b2,"● "+ve(y.value),1)):Ae("",!0)]),F.value?(J(),X("div",{key:0,class:"spm-context-quote",title:a.value},ve(F.value),9,v2)):Ae("",!0),h("div",k2,[$.value?(J(),qt(Av,{key:0,"page-layout":S.value,"page-layout-ratio":ue(oe),"page-mask":ue(re),"page-mask-ratio":ue(Se),"page-mask-style":ue($e),"page-mask-initial":ue(ke),"detected-sb-ratio":L.value,"detected-sb-info":ne.value,"page-transition":q.value,"page-spacing":M.value,"page-image":C.value,"page-notes":te.value,"page-index":v.value,"is-generating-notes":ue(Wc),"can-convert-to-super-block":rs.value,"onUpdate:pageLayout":ld,"onUpdate:pageLayoutRatio":ad,"onUpdate:pageMask":cd,"onUpdate:pageMaskRatio":dd,"onUpdate:pageMaskStyle":ud,"onUpdate:pageMaskInitial":fd,onApplySuperBlockLayout:Ar,onResetSuperblockRatio:pd,"onUpdate:pageTransition":md,"onUpdate:pageSpacing":yd,"onUpdate:pageImage":gd,onAddNoteBlock:ue(Fc),onLocateNoteBlock:ue(jc),onGenerateNotes:ue(Uc),onOpenSetting:Er,onInsertDividerAfter:ue($r),onDeleteDivider:ue(nd),onConvertToSuperBlock:ue(Tr)},null,8,["page-layout","page-layout-ratio","page-mask","page-mask-ratio","page-mask-style","page-mask-initial","detected-sb-ratio","detected-sb-info","page-transition","page-spacing","page-image","page-notes","page-index","is-generating-notes","can-convert-to-super-block","onAddNoteBlock","onLocateNoteBlock","onGenerateNotes","onInsertDividerAfter","onDeleteDivider","onConvertToSuperBlock"])):s.value&&!H.value?(J(),qt(a0,{key:1,"elem-click":I.value,"elem-motion":T.value,"elem-slot":N.value,"elem-shiki-lines":Y.value,"elem-max-height":G.value,"is-code-block":A.value,"is-image":_.value,"is-video":O.value,"is-super-block":U.value,"detected-sb-info":ne.value,"video-autoplay":Z.value,"video-loop":Q.value,"video-muted":ce.value,"video-controls":se.value,"has-block-attrs":rt.value,"is-note":W.value,"image-role":Ke.value,"current-slide-layout":K.value,"parent-elem-click":m.value,"parent-container-slot":b.value,"parent-container-id":d.value,"can-convert-to-super-block":rs.value,onToggleNote:ue(Hc),onToggleElemClick:ue(Yc),onToggleVideoAutoplay:ue(Qe),onToggleVideoLoop:ue(lt),onToggleVideoMuted:ue(It),onToggleVideoControls:ue(at),"onUpdate:imageRole":ue(ao),"onUpdate:elemClick":ue(Zc),"onUpdate:elemMotion":ue(Jc),"onUpdate:elemSlot":ue(Xc),"onUpdate:elemShikiLines":ue(Qc),"onUpdate:elemMaxHeight":ue(ed),onApplySuperBlockLayout:Ar,onApplySuperBlockRatio:hd,onInsertDividerBefore:ue(id),onInsertDividerAfter:ue($r),onSetTwoColsContrast:ue(td),onClearBlockAttrs:ue(od),onConvertToSuperBlock:ue(Tr)},null,8,["elem-click","elem-motion","elem-slot","elem-shiki-lines","elem-max-height","is-code-block","is-image","is-video","is-super-block","detected-sb-info","video-autoplay","video-loop","video-muted","video-controls","has-block-attrs","is-note","image-role","current-slide-layout","parent-elem-click","parent-container-slot","parent-container-id","can-convert-to-super-block","onToggleNote","onToggleElemClick","onToggleVideoAutoplay","onToggleVideoLoop","onToggleVideoMuted","onToggleVideoControls","onUpdate:imageRole","onUpdate:elemClick","onUpdate:elemMotion","onUpdate:elemSlot","onUpdate:elemShikiLines","onUpdate:elemMaxHeight","onInsertDividerBefore","onInsertDividerAfter","onSetTwoColsContrast","onClearBlockAttrs","onConvertToSuperBlock"])):(J(),qt(Ok,{key:2,"doc-theme":me.value,"doc-background":He.value,"doc-aspect-ratio":Ce.value,"doc-default-transition":we.value,"doc-spacing":De.value,"is-batch-processing":ue(an),"onUpdate:docTheme":bd,"onUpdate:docBackground":vd,"onUpdate:docAspectRatio":kd,"onUpdate:docDefaultTransition":wd,"onUpdate:docSpacing":xd,onOpenBottomPreview:Mr,onOpenPresenter:Sd,onAddOrIdentifyNotes:ue(Vc),onClearNotes:ue(qc),onAutoAnimate:ue(Kc),onClearAnimations:ue(Gc),onAiAutoSplit:_d,onClearDividers:Cd,onExportHtml:ue(sd),onExportPdf:ue(rd),onOpenSetting:Er},null,8,["doc-theme","doc-background","doc-aspect-ratio","doc-default-transition","doc-spacing","is-batch-processing","onAddOrIdentifyNotes","onClearNotes","onAutoAnimate","onClearAnimations","onExportHtml","onExportPdf"]))]),i.value&&ue(Ot)("import")?(J(),qt(Pw,{key:1,onClose:ge[1]||(ge[1]=Be=>i.value=!1),onSuccess:n})):Ae("",!0)]))}}),x2=2e3,S2=600;function _2(e){return!e||typeof e.closest!="function"?!1:!!e.closest(".fn__none")}function $s(e){if(!e||typeof e.isConnected=="boolean"&&!e.isConnected)return!1;if(Pl(e))return!0;const t=e.firstElementChild;return!!(t&&Pl(t))}function Pl(e){return typeof e.getClientRects=="function"&&e.getClientRects().length>0?!0:typeof e.offsetWidth=="number"&&e.offsetWidth>0&&e.offsetHeight>0}function C2(){const e=typeof globalThis<"u"?globalThis.IntersectionObserver:void 0;return typeof e=="function"?e:void 0}class I2{constructor(){Ie(this,"consumers",new Map);Ie(this,"seq",0);Ie(this,"verifyTimer",null)}register(t,o,i){if(!o)return()=>{};const n=++this.seq,s=C2(),l={kind:t,element:o,visible:!1,measureOnDemand:!s,observer:null,onVisible:i};return s?(l.observer=new s(r=>{var u;const a=r[r.length-1];if(!a)return;const c=a.isIntersecting&&!l.visible;l.visible=a.isIntersecting,c&&((u=l.onVisible)==null||u.call(l))}),l.observer.observe(o)):l.visible=$s(o),this.consumers.set(n,l),()=>{var r;(r=l.observer)==null||r.disconnect(),this.consumers.delete(n),this.consumers.size===0&&this.stopVerifyTimer()}}clear(){var t;for(const o of this.consumers.values())(t=o.observer)==null||t.disconnect();this.consumers.clear(),this.stopVerifyTimer()}get size(){return this.consumers.size}getVisibility(){if(this.consumers.size===0)return"none";if(typeof document<"u"&&document.visibilityState==="hidden")return"hidden";for(const t of this.consumers.values())if(t.measureOnDemand?$s(t.element):this.isRecordVisible(t))return"visible";return this.ensureVerifyTimer(),"hidden"}hasVisibleConsumer(){return this.getVisibility()==="visible"}isRecordVisible(t){return t.visible?!0:!_2(t.element)}ensureVerifyTimer(){if(this.verifyTimer!==null||typeof setTimeout!="function")return;let t=!1;for(const o of this.consumers.values())if(!o.measureOnDemand){t=!0;break}t&&(this.verifyTimer=setTimeout(()=>{var o;this.verifyTimer=null;for(const i of this.consumers.values())if(!i.visible&&$s(i.element)){i.visible=!0,(o=i.onVisible)==null||o.call(i);return}},x2))}stopVerifyTimer(){this.verifyTimer!==null&&(clearTimeout(this.verifyTimer),this.verifyTimer=null)}}const In=new I2,$i=new ns;function Nc(e,t,o){const i=()=>{var s;try{(s=o==null?void 0:o.flushDirtyCompile)==null||s.call(o)}catch{}},n=In.register(e,t,i);return i(),n}let Oo=null,Ft=null,$n=null;function $2(){return Ft}function T2(e,t){Oo&&Pc(),Oo=vr(Yg),Oo.provide("plugin",t),Oo.provide("sandboxBridge",$i);const o=Oo.mount(e);return Ft=o,$n=Nc("preview",e,t),o}function Pc(e){$n&&($n(),$n=null),Oo&&(Oo.unmount(),Oo=null,Ft=null)}function A2(){return Ft!==null}let No=null,Zo=null;function M2(e,t){return No&&Rc(),No=vr(sb),No.provide("plugin",t),No.provide("sandboxBridge",$i),Zo=No.mount(e),Zo}function Rc(e){No&&(No.unmount(),No=null,Zo=null)}function E2(e){var t;try{const o=new BroadcastChannel("siyuan-slides-sync");o.postMessage({type:"SYNC_SLIDES",slides:e.slides||[],config:{...e.config||{},hostThemeMode:((t=e.config)==null?void 0:t.hostThemeMode)||Uo()}}),o.close()}catch{}}let Po=null,Nt=null,Tn=null;function B2(e,t){Po&&zc(),Po=vr(w2),Po.provide("plugin",t),Po.provide("sandboxBridge",$i);const o=Po.mount(e);return Nt=o,Tn=Nc("dock",e,t),o}function zc(e){Tn&&(Tn(),Tn=null),Po&&(Po.unmount(),Po=null,Nt=null)}function L2(e,t){Nt!=null&&Nt.updateDocument&&Nt.updateDocument(e),Ft!=null&&Ft.updateDocument?Ft.updateDocument(e,t):($i.updateSlides(e.slides,e.config),E2(e)),Zo!=null&&Zo.updateDocument&&Zo.updateDocument(e)}function Xs(e){Ft!=null&&Ft.navigateToBlock?Ft.navigateToBlock(e):$i.highlightElement(e)}function ri(e){Nt!=null&&Nt.setActiveBlock&&Nt.setActiveBlock(e)}function D2(){return Do("import")?!1:Nt!=null&&Nt.openImportDialog?(Nt.openImportDialog(),!0):!1}const O2=[{id:"slides-cover",name:"幻灯片 - 封面页 (Cover)",open:!0,attrs:[{key:po,value:"true"},{key:be,value:"cover"},{key:_t,value:"fade"}]},{id:"slides-two-cols",name:"幻灯片 - 双栏对比 (Two Columns)",open:!0,attrs:[{key:po,value:"true"},{key:be,value:"two-cols"},{key:_t,value:"slide-left"}]},{id:"slides-fact",name:"幻灯片 - 大字报与核心指标 (Fact)",open:!0,attrs:[{key:po,value:"true"},{key:be,value:"fact"},{key:_t,value:"zoom"}]},{id:"slides-intro",name:"幻灯片 - 章节导引与作者 (Intro)",open:!0,attrs:[{key:po,value:"true"},{key:be,value:"intro"},{key:_t,value:"slide-up"}]},{id:"slides-quote",name:"幻灯片 - 金句与强调 (Quote)",open:!0,attrs:[{key:po,value:"true"},{key:be,value:"quote"},{key:_t,value:"fade"}]},{id:"slides-elem-click",name:"元素 - 顺延逐步呈现 (v-click)",open:!0,attrs:[{key:Oe,value:"+1"}]},{id:"slides-elem-click-hide",name:"元素 - 隐藏直到激活 (v-click:hide)",open:!0,attrs:[{key:Oe,value:"hide"}]},{id:"slides-elem-slot-right",name:"元素 - 双栏右栏归属 (Slot: Right)",open:!0,attrs:[{key:Te,value:"right"}]},{id:"slides-shiki-lines",name:"代码 - 逐行聚光高亮 (Shiki)",open:!0,attrs:[{key:ei,value:"1-3"}]}];class Ts{getPresetTemplates(){return O2}buildScanSlidesBlocksSql(t="custom-slides-"){return`SELECT block_id, name, value FROM attributes WHERE name LIKE '${t}%' ORDER BY block_id ASC`}buildTransitionStatsSql(){return`SELECT value, count(1) as count FROM attributes WHERE name = '${_t}' GROUP BY value ORDER BY count DESC`}async batchUpdateTransitions(t,o,i,n){const s=`SELECT block_id FROM attributes WHERE name = '${_t}' AND value = '${t}'`,l=await i(s);let r=0;if(Array.isArray(l))for(const a of l){const c=a.block_id||a.blockId;c&&(await n(c,{[_t]:o}),r++)}return{updatedCount:r}}async batchUpdateLayout(t,o,i,n){const s=`SELECT block_id FROM attributes WHERE name = '${be}' AND value = '${t}'`,l=await i(s);let r=0;if(Array.isArray(l))for(const a of l){const c=a.block_id||a.blockId;c&&(await n(c,{[be]:o}),r++)}return{updatedCount:r}}exportTemplatesJson(){const t=this.getPresetTemplates();return JSON.stringify({templates:t,counter:t.length},null,2)}formatTransitionSummary(t){return!t||t.length===0?"全库目前暂无已设置即现转场效果的块":`全库即现转场分布统计：${t.map(i=>`${i.value}: ${i.count} 个`).join("，")}`}}function N2(e){if(e.addCommand({langKey:"slidesPresentation",langText:"即现: 在文档下方开启分屏演示预览",hotkey:"⌥P",enabled:()=>!0,execute:()=>{e.openBottomPreviewTab()}}),Do("import")||e.addCommand({langKey:"slidesImport",langText:"即现: 导入 Slidev 演示文档 (.md / .zip)",hotkey:"⌥I",enabled:()=>!0,execute:()=>{D2()||ie.showMessage("请先在右侧栏打开「即现配置」Dock 面板以呼起导入窗口")}}),e.addCommand({langKey:"slidesInitAttrs",langText:"即现: 初始化当前文档演示属性",hotkey:"",enabled:()=>!0,execute:async()=>{if(!e.currentDocId){const t=document.querySelector(".protyle-content[data-doc-id]");e.currentDocId=(t==null?void 0:t.getAttribute("data-doc-id"))||""}e.currentDocId&&(await ze(e.currentDocId,{"custom-slides-theme":"default","custom-slides-aspect-ratio":"16/9","custom-slides-default-transition":"slide-left"}),ie.showMessage("已为当前文档初始化即现属性"),e.compileCurrentDocument(e.currentDocId))}}),Do("aiScript")||(e.addCommand({langKey:"slidesAiSplit",langText:"即现: 智能大纲断页建议与自动分页",hotkey:"",enabled:()=>!0,execute:()=>Dc(e)}),e.addCommand({langKey:"slidesClearDividers",langText:"即现: 清除当前文档分页线",hotkey:"",enabled:()=>!0,execute:()=>Oc(e)})),Do("aiScript")||e.addCommand({langKey:"slidesAiNotes",langText:"即现 AI: 自动为当前文档生成演讲者提词卡 (Notes)",hotkey:"",enabled:()=>!0,execute:async()=>{var n,s,l,r;if(!e.currentDocId){const a=document.querySelector(".protyle-content[data-doc-id]");e.currentDocId=(a==null?void 0:a.getAttribute("data-doc-id"))||""}if(!e.currentDocId){ie.showMessage("请先打开一篇思源笔记文档");return}if(!kr()){ie.showMessage("未配置 AI 提词服务，请前往设置填写 API 配置或通过「API 旋钮 (siyuan-api-switch)」接管",6e3,"error");return}ie.showMessage("正在调用 AI 提炼演讲者口播提词...");const o=await Si(e.currentDocId).catch(()=>[]),i={pageIndex:1,startBlockId:e.currentDocId,frontmatter:{},notes:"",blocks:o.map(a=>({id:a.id,type:a.type,content:a.content||"",rawMarkdown:a.markdown||""})),rawMarkdown:""};try{const a=await Gw(i,ss);if(!a){ie.showMessage("AI 未返回可用的提词内容",5e3,"error");return}const u=`> [!NOTE] 💡 演讲备注
${a.split(/\r?\n/).map(d=>`> ${d}`).join(`
`)}
{: custom-slides-note="true"}`,f=await bn("markdown",u,e.currentDocId).catch(()=>null),p=((l=(s=(n=f==null?void 0:f[0])==null?void 0:n.doOperations)==null?void 0:s[0])==null?void 0:l.id)||((r=f==null?void 0:f[0])==null?void 0:r.id);p&&(await ze(p,{"custom-slides-note":"true"}),Ee.setBlockAttrOverride(p,{"custom-slides-note":"true"}),Ro(p,e.app)),ie.showMessage("已成功生成口播提词卡并插入为正文讲稿备注块"),e.compileCurrentDocument(e.currentDocId)}catch(a){ie.showMessage(`AI 提词生成失败: ${(a==null?void 0:a.message)||a}`,6e3,"error")}}}),e.addCommand({langKey:"slidesIdentifyNotes",langText:"即现: 识别正文讲稿块并规范化",hotkey:"",enabled:()=>!0,execute:async()=>{let t=e.currentDocId;if(!t){const o=document.querySelector(".protyle-content[data-doc-id]");t=(o==null?void 0:o.getAttribute("data-doc-id"))||"",t&&(e.currentDocId=t)}if(!t){ie.showMessage("请先在主编辑区打开幻灯片文档");return}await Bc(t,{compileFn:async()=>{await e.compileCurrentDocument(t)}})}}),e.addCommand({langKey:"slidesAutoAnimate",langText:"即现: 智能配置演示动效",hotkey:"",enabled:()=>!0,execute:async()=>{let t=e.currentDocId;if(!t){const o=document.querySelector(".protyle-content[data-doc-id]");t=(o==null?void 0:o.getAttribute("data-doc-id"))||"",t&&(e.currentDocId=t)}if(!t){ie.showMessage("请先在主编辑区打开幻灯片文档");return}await Lc(t,{compileCurrentDocFn:async()=>{await e.compileCurrentDocument(t)}})}}),e.addCommand({langKey:"slidesBatchTransitions",langText:"即现协同: 统计全库转场效果分布",hotkey:"",enabled:()=>!0,execute:async()=>{const t=new Ts,o=t.buildTransitionStatsSql(),i=await vi(o).catch(()=>[]),n=t.formatTransitionSummary(i||[]);ie.showMessage(n)}}),e.addCommand({langKey:"slidesExportTemplates",langText:"即现协同: 复制即现预设属性模板至剪贴板",hotkey:"",enabled:()=>!0,execute:async()=>{const o=new Ts().exportTemplatesJson();typeof navigator<"u"&&navigator.clipboard?(await navigator.clipboard.writeText(o),ie.showMessage("已将即现属性模板 JSON 复制至剪贴板，可直接导入属性管家")):ie.showMessage(`已生成模板数据（请在控制台查看）：
`+o)}}),e.addCommand({langKey:"slidesBatchReplaceTransition",langText:"即现协同: 批量替换全库淡入淡出转场为滑动 (fade -> slide-left)",hotkey:"",enabled:()=>!0,execute:async()=>{const o=await new Ts().batchUpdateTransitions("fade","slide-left",i=>vi(i).catch(()=>[]),(i,n)=>ze(i,n));ie.showMessage(`全库批量替换完成：已将 ${o.updatedCount} 处 fade 转场更新为 slide-left`),e.compileCurrentDocument()}}),Do("presenterMode")||e.addCommand({langKey:"slidesPresenterMode",langText:"即现: 打开双屏演讲者控制台 (Presenter Mode)",hotkey:"⌥M",enabled:()=>!0,execute:()=>{e.openPresenterTab()}}),!Do("exportImage")){let t=!1;e.addCommand({langKey:"slidesExportImagesZip",langText:"即现: 逐页导出幻灯片为高清图片包 (ZIP)",hotkey:"",enabled:()=>!0,execute:async()=>{if(t){ie.showMessage("正在导出图片中，请稍候...",2e3);return}if(e.latestCompiledDoc||await e.compileCurrentDocument(),!e.latestCompiledDoc){ie.showMessage("请先打开并放映一篇思源笔记文档");return}t=!0;try{ie.showMessage("正在启动后台沙箱并逐页导出幻灯片图片...");const o=e.latestCompiledDoc,i=await zo(o,e.currentDocId,e),n=await vc(o,{title:i,onProgress:(s,l)=>{ie.showMessage(`正在导出幻灯片图片 (${s} / ${l})...`,2e3)}});n.success?ie.showMessage(`🎉 成功导出 ${n.total||0} 张幻灯片高清图片并已保存为 ${i}.zip！`,4e3):ie.showMessage(`导出图片失败：${n.error||"未知异常"}`)}finally{t=!1}}})}}class P2{constructor(t=400){Ie(this,"entries",new Map);this.ttlMs=t}get(t,o=Date.now()){if(!t)return;const i=this.entries.get(t);if(i){if(o-i.at>this.ttlMs){this.entries.delete(t);return}return i.attrs}}set(t,o,i=Date.now()){!t||!o||this.entries.set(t,{attrs:o,at:i})}invalidate(t){t?this.entries.delete(t):this.entries.clear()}get size(){return this.entries.size}}function R2(e){const t=new Map;if(!(e!=null&&e.slides))return t;const o=i=>{for(const n of i||[])n!=null&&n.id&&n.ial&&t.set(n.id,n.ial)};for(const i of e.slides)o(i.blocks),o(i.noteBlocks);return t}class z2{constructor(t=150){Ie(this,"lastBlockId","");Ie(this,"lastAt",0);this.windowMs=t}shouldSkip(t,o=Date.now()){return t&&t===this.lastBlockId&&o-this.lastAt<this.windowMs?!0:(this.lastBlockId=t,this.lastAt=o,!1)}reset(){this.lastBlockId="",this.lastAt=0}}class H2{constructor(){Ie(this,"attrCache",new P2);Ie(this,"compiledIalIndex",{doc:null,map:new Map});Ie(this,"locatingLockUntil",0);Ie(this,"lockedTargetBlockId","");Ie(this,"lastKnownPageDividerId","");Ie(this,"lastKnownDocId","")}isLocatingLocked(t){return Date.now()<this.locatingLockUntil?!(t&&t===this.lockedTargetBlockId):!1}async resolveBlockAttrs(t,o){if(!t)return{};const i=Ee.getBlockAttrOverride(t),n=this.getCompiledIal(o,t);if(i||n)return{...n||{},...i||{}};const s=this.attrCache.get(t);if(s)return s;const l=await er(t).catch(()=>({}))||{};return this.attrCache.set(t,l),l}getCompiledIal(t,o){if(t)return this.compiledIalIndex.doc!==t&&(this.compiledIalIndex={doc:t,map:R2(t)}),this.compiledIalIndex.map.get(o)}invalidateAttrCache(t){this.attrCache.invalidate(t)}getActiveDocumentId(){if(typeof document>"u")return"";const t=document.querySelector(".layout__wnd--active .protyle-title[data-node-id]")||document.querySelector(".item--focus .protyle-title[data-node-id]")||document.querySelector(".protyle-title[data-node-id]"),o=t==null?void 0:t.getAttribute("data-node-id");if(o)return o;const i=document.querySelector(".protyle .protyle-title[data-node-id]"),n=i==null?void 0:i.getAttribute("data-node-id");if(n)return n;const s=document.querySelector("[data-doc-id]"),l=s==null?void 0:s.getAttribute("data-doc-id");return l||""}resolveDocIdFromElement(t,o=""){const i=t.closest(".protyle-title"),n=i==null?void 0:i.getAttribute("data-node-id");if(n)return n;const s=t.closest(".protyle"),l=s==null?void 0:s.querySelector(".protyle-title"),r=l==null?void 0:l.getAttribute("data-node-id");if(r)return r;const a=t.closest("[data-doc-id]"),c=a==null?void 0:a.getAttribute("data-doc-id");if(c)return c;const u=this.getActiveDocumentId();return u||o}async switchToDocGlobalInspector(t,o){var s;if(!t)return;let i=o||"";if(!i&&typeof document<"u"){const l=document.querySelector(`.protyle-title[data-node-id="${t}"] .protyle-title__input`)||document.querySelector(`.protyle[data-doc-id="${t}"] .protyle-title__input`)||document.querySelector(".protyle-title__input");i=((s=l==null?void 0:l.innerText)==null?void 0:s.trim())||""}const n=await this.resolveBlockAttrs(t,null);ri({id:t,rootId:t,type:"doc",content:i,attrs:n,isDivider:!1,isCode:!1}),Xs(t)}handleBlockClickedFromSlide(t,o,i,n,s){var c,u,f,p;if(!t){qi();const d=typeof s=="number"&&s>0?s:1,b=((c=n==null?void 0:n.slides)==null?void 0:c[d-1])||((u=n==null?void 0:n.slides)==null?void 0:u[0]);if(b){const m=b.startBlockId||"",g=((f=b.frontmatter)==null?void 0:f.layout)||"",y={"custom-slides-layout":g,...b.frontmatter};return ri({id:m,rootId:i,type:"NodeThematicBreak",attrs:y,isDivider:!0,isCode:!1,isImage:!1,pageDividerId:m,pageDividerLayout:g}),this.resolveBlockAttrs(m,n).then(k=>{k&&Object.keys(k).length>0&&ri({id:m,rootId:i,type:"NodeThematicBreak",attrs:{...y,...k},isDivider:!0,isCode:!1,isImage:!1,pageDividerId:m,pageDividerLayout:g})}),!0}else return this.switchToDocGlobalInspector(i),!0}this.lockedTargetBlockId=t,this.locatingLockUntil=Date.now()+500;const l=Ro(t,o),r=typeof document<"u"?document.querySelector(`.protyle-wysiwyg [data-node-id="${t}"]`)||document.querySelector(`[data-node-id="${t}"]`):null,a=(r==null?void 0:r.getAttribute("data-type"))||"";if(r)this.syncInspectorBlock(r,t,a,i,n);else{let d="",b="";if(n!=null&&n.slides){const m=n.slides.find(g=>{var y,k,x;return g.startBlockId===t||((y=g.blocks)==null?void 0:y.some($=>$.id===t))||((k=g.allBlockIds)==null?void 0:k.includes(t))||((x=g.noteBlocks)==null?void 0:x.some($=>$.id===t))});m!=null&&m.startBlockId&&(d=m.startBlockId),(p=m==null?void 0:m.frontmatter)!=null&&p.layout&&(b=m.frontmatter.layout)}this.resolveBlockAttrs(t,n).then(async m=>{if(d&&!b){const g=Ee.getBlockAttrOverride(d);if(g!=null&&g[be]||g!=null&&g["custom-slides-layout"])b=g[be]||g["custom-slides-layout"]||"";else{const y=await this.resolveBlockAttrs(d,n);b=y[be]||y["custom-slides-layout"]||"",y&&Object.keys(y).length>0&&Ee.setBlockAttrOverride(d,y)}}ri({id:t,rootId:i,type:a||"NodeParagraph",attrs:m||{},pageDividerId:d,pageDividerLayout:b})}).catch(()=>{})}return l}async syncInspectorBlock(t,o,i,n,s){var q,j,C,M,B,te,V,K,ae;if(this.isLocatingLocked(o))return;let l=t,r=o,a=i;const c=typeof(t==null?void 0:t.closest)=="function"?t.closest('[data-type="NodeCallout"]'):null;if(c&&c!==t){const oe=c.getAttribute("data-node-id");if(oe){const re=await this.resolveBlockAttrs(oe,s),Se=Ee.getBlockAttrOverride(oe)||{};({...re,...Se})[Fe]&&(l=c,r=oe,a="NodeCallout")}}const u=l.closest(".protyle-wysiwyg > [data-node-id]")||l,f=(u==null?void 0:u.getAttribute("data-node-id"))||r,p=a==="NodeThematicBreak"||a==="tb"||a==="thematic-break"||(u==null?void 0:u.getAttribute("data-type"))==="NodeThematicBreak"||(u==null?void 0:u.getAttribute("data-type"))==="tb"||!!((q=u==null?void 0:u.classList)!=null&&q.contains("hr")),d=a==="NodeCodeBlock",b=((j=l.innerText)==null?void 0:j.trim())||"",m=await this.resolveBlockAttrs(r,s),g=Ee.getBlockAttrOverride(r)||{},y={...m,...g};let k="",x="";if(p)k=r,x=y[be]||y["custom-slides-layout"]||"";else{let oe=u.previousElementSibling;for(;oe;){const re=oe.getAttribute("data-type");if(re==="NodeThematicBreak"||re==="tb"||(C=oe.classList)!=null&&C.contains("hr")){k=oe.getAttribute("data-node-id")||"";break}oe=oe.previousElementSibling}}if(s!=null&&s.slides){const oe=[r,f];let re=l.parentElement;for(;re&&!re.classList.contains("protyle-wysiwyg");){const $e=re.getAttribute("data-node-id");$e&&!oe.includes($e)&&oe.push($e),re=re.parentElement}const Se=s.slides.find($e=>{var ke,_e,R;return oe.includes($e.startBlockId)||((ke=$e.blocks)==null?void 0:ke.some(ne=>oe.includes(ne.id)))||((_e=$e.allBlockIds)==null?void 0:_e.some(ne=>oe.includes(ne)))||((R=$e.noteBlocks)==null?void 0:R.some(ne=>oe.includes(ne.id)))});Se&&(!k&&Se.startBlockId&&(k=Se.startBlockId),!x&&((M=Se.frontmatter)!=null&&M.layout)&&(x=Se.frontmatter.layout))}if(k?(this.lastKnownDocId=n,this.lastKnownPageDividerId=k):n&&this.lastKnownDocId===n&&this.lastKnownPageDividerId&&(!u.previousElementSibling&&(((B=u.parentElement)==null?void 0:B.scrollTop)||0)===0||(k=this.lastKnownPageDividerId)),k){const oe=Ee.getBlockAttrOverride(k);if(oe&&(be in oe||"custom-slides-layout"in oe)&&(x=oe[be]||oe["custom-slides-layout"]||""),!x&&(s!=null&&s.slides)){const re=s.slides.find(Se=>Se.startBlockId===k);(te=re==null?void 0:re.frontmatter)!=null&&te.layout&&(x=re.frontmatter.layout)}if(!x){const re=await this.resolveBlockAttrs(k,s);x=re[be]||re["custom-slides-layout"]||"",re&&Object.keys(re).length>0&&Ee.setBlockAttrOverride(k,re)}et(k,{[be]:x||""})}else if(n){const oe=Ee.getBlockAttrOverride(n);oe&&(be in oe||"custom-slides-layout"in oe)?x=oe[be]||oe["custom-slides-layout"]||"":!x&&((ae=(K=(V=s==null?void 0:s.slides)==null?void 0:V[0])==null?void 0:K.frontmatter)!=null&&ae.layout)&&(x=s.slides[0].frontmatter.layout)}const $=l.getAttribute(be)||l.getAttribute("custom-slides-layout"),A=y[be]||y["custom-slides-layout"]||"";$&&$!==A&&et(r,{[be]:A});const w=l.getAttribute(Ye)||l.getAttribute("custom-slides-role"),_=y[Ye]||y["custom-slides-role"]||"";w&&w!==_&&et(r,{[Ye]:_});let O="",H="",P="";const F=l.closest('[data-type="NodeListItem"]');if(F&&F!==l){const oe=F.getAttribute("data-node-id");if(oe){O=oe;const re=await this.resolveBlockAttrs(oe,s),Se=Ee.getBlockAttrOverride(oe)||{},$e={...re,...Se};H=$e[Te]||"",P=$e[Oe]||"";const ke=$e[be]||$e["custom-slides-layout"]||"",_e=F.getAttribute(be)||F.getAttribute("custom-slides-layout");_e&&_e!==ke&&et(oe,{[be]:ke});const R=$e[Ye]||$e["custom-slides-role"]||"",ne=F.getAttribute(Ye)||F.getAttribute("custom-slides-role");ne&&ne!==R&&et(oe,{[Ye]:R})}}const E=!!l.querySelector("img, span[data-type='img']"),D=(l.innerText||"").replace(/[\r\n\t\s]+/g," ").trim(),S=E&&D.length<=50;ri({id:r,rootId:n,type:a,content:b,attrs:y,isDivider:p,isCode:d,isImage:S,topBlockId:f,pageDividerId:k,pageDividerLayout:x,parentContainerId:O,parentContainerSlot:H,parentContainerClicks:P})}patchThematicBreakTransactions(t){if((t==null?void 0:t.cmd)==="transactions"&&Array.isArray(t.data)){for(const o of t.data)if(Array.isArray(o==null?void 0:o.doOperations)){for(const i of o.doOperations)if((i==null?void 0:i.action)==="updateAttrs"&&i.id&&i.data){const n=i.data.old||{},s=i.data.new||{},l={};for(const r of Object.keys(n))r in s||(l[r]="");for(const[r,a]of Object.entries(s))l[r]=String(a??"");et(i.id,l),Ee.setBlockAttrOverride(i.id,l)}}}}purgeStaleDomSlidesAttrs(t){var n,s,l;if(typeof document>"u"||!t)return;const o=new Map;if(Array.isArray(t.slides))for(const r of t.slides){if(r.startBlockId){const a=o.get(r.startBlockId)||{};(n=r.frontmatter)!=null&&n.layout&&(a[be]=r.frontmatter.layout),o.set(r.startBlockId,a)}if(Array.isArray(r.blocks)){for(const a of r.blocks)if(a.id){const c=o.get(a.id)||{};(s=a.ial)!=null&&s[be]&&(c[be]=a.ial[be]),(l=a.ial)!=null&&l[Ye]&&(c[Ye]=a.ial[Ye]),Object.keys(c).length>0&&o.set(a.id,c)}}}const i=Ee.getAllAttrOverrides();for(const[r,a]of i.entries()){const c=o.get(r)||{};a[be]!==void 0&&(c[be]=a[be]),a[Ye]!==void 0&&(c[Ye]=a[Ye]),o.set(r,c)}Hw(o)}}const Eo=new H2;class F2{constructor(){Ie(this,"state","IDLE");Ie(this,"inFlightDocId",null);Ie(this,"pendingDocs",new Set);Ie(this,"lastPendingDocId",null);Ie(this,"generation",0)}get currentState(){return this.state}get isRunning(){return this.state==="COMPILING"}get runningDocId(){return this.inFlightDocId}get pending(){return this.lastPendingDocId}get pendingList(){return Array.from(this.pendingDocs)}tryBegin(t){return this.state==="COMPILING"||this.inFlightDocId!==null?(this.pendingDocs.add(t),this.lastPendingDocId=t,null):(this.state="COMPILING",this.inFlightDocId=t,++this.generation)}isStale(t){return t!==this.generation}finishBatch(){this.state="IDLE",this.inFlightDocId=null,this.lastPendingDocId=null;const t=Array.from(this.pendingDocs);return this.pendingDocs.clear(),t}finish(){const t=this.finishBatch();return t.length>0?t[t.length-1]:null}reset(){this.state="IDLE",this.inFlightDocId=null,this.pendingDocs.clear(),this.lastPendingDocId=null,this.generation=0}}function j2(e){if(!e||typeof e.closest!="function")return;e.classList.remove("fn__flex-center","fn__size200"),e.style.width="100%",e.style.height="auto",e.style.minHeight="0",e.style.flex="none",e.style.alignSelf="stretch";const t=e.parentElement,o=e.closest(".config-item, .config__item, .b3-label")||t,i=(o==null?void 0:o.querySelector(":scope > .fn__flex-1, :scope > .fn__block, :scope .config-name, :scope .fn__flex-1"))||(o==null?void 0:o.querySelector(".config-name, .fn__flex-1")),n=o==null?void 0:o.querySelector(".fn__space");o instanceof HTMLElement&&(o.classList.add("slides-settings__host-item"),o.style.height="auto",o.style.minHeight="0",o.style.alignItems="stretch",o.style.flexDirection="column"),t instanceof HTMLElement&&t!==o&&(t.classList.add("slides-settings__host-block"),t.style.width="100%",t.style.height="auto",t.style.minHeight="0"),i instanceof HTMLElement&&(i.classList.add("slides-settings__host-title"),i.style.overflow="visible",i.style.minHeight="0",i.style.textAlign="left"),n instanceof HTMLElement&&(n.style.display="none")}function U2(e){if(!e||typeof e.closest!="function")return;e.classList.remove("fn__flex-center","fn__size200","fn__block");const t=e.matches(".b3-switch")?e:e.querySelector(".b3-switch");t&&t.classList.remove("fn__flex-center","fn__size200","fn__block");const o=e.closest(".config-item, .config__item, .b3-label")||e.parentElement,i=o==null?void 0:o.querySelector(":scope > .fn__flex-1, .config-name");o instanceof HTMLElement&&(o.classList.add("slides-settings__host-row"),o.style.height="auto",o.style.minHeight="0",o.style.alignItems="center"),i instanceof HTMLElement&&(i.classList.add("slides-settings__host-title"),i.style.overflow="visible",i.style.minHeight="0",i.style.textAlign="left")}function W2(e,t,o){if(!e||typeof e.open!="function")return;const i=e.open.bind(e),n=()=>{t.forEach(s=>j2(s)),o.forEach(s=>U2(s))};e.open=(s=>{i(s),n(),typeof setTimeout=="function"&&setTimeout(()=>{n()},0)})}function yn(e){const t=document.createElement("div");return t.className="slides-settings__switch-wrap",t.style.cssText="display: inline-flex; align-items: center; justify-content: flex-end;",t.appendChild(e),t}const Rl='<svg class="slides-settings__api-key-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M2.25 12s3.75-6.75 9.75-6.75S21.75 12 21.75 12 18 18.75 12 18.75 2.25 12Z"/><circle cx="12" cy="12" r="3.25"/></svg>',q2='<svg class="slides-settings__api-key-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M3 3l18 18"/><path d="M10.7 5.52A10.56 10.56 0 0 1 12 5.25c6 0 9.75 6.75 9.75 6.75a18.78 18.78 0 0 1-4.02 4.85M6.68 6.69C4.04 8.42 2.25 12 2.25 12s3.75 6.75 9.75 6.75c1.85 0 3.47-.64 4.85-1.55M9.88 9.88A3 3 0 0 0 9 12a3 3 0 0 0 3 3c.8 0 1.53-.31 2.07-.82"/></svg>';function V2(e){const t=new ie.Setting({width:"680px"}),o=Fo();let i=fh();const n=document.createElement("div");n.className="slides-settings__ai-panel",n.style.cssText="display: flex; flex-direction: column; gap: 12px; width: 100%; text-align: left; box-sizing: border-box;";const s=document.createElement("div");s.className="slides-settings__tip-container",s.style.cssText="width: 100%; text-align: left;",n.appendChild(s);function l(C){var M,B;if(s.innerHTML="",C){const te=document.createElement("div");te.className="api-switch-managed-tip",te.style.cssText=`
        background-color: var(--b3-theme-primary-light, rgba(63, 81, 181, 0.08));
        border: 1px solid var(--b3-theme-primary, rgba(63, 81, 181, 0.2));
        border-radius: 6px;
        padding: 8px 12px;
        font-size: 12px;
        line-height: 1.5;
        color: var(--b3-theme-on-background);
        text-align: left;
      `;const V=((B=(M=window.siyuan)==null?void 0:M.config)==null?void 0:B.lang)==="en_US",K=C.profileName||(V?"Unnamed":"未命名");te.innerHTML=V?`💡 General AI API is managed by <strong>API Switch (siyuan-api-switch)</strong> (Profile: ${K}). Related inputs are read-only. Please configure in the API Switch panel.`:`💡 通用 AI API 已由 <strong>API 旋钮 (siyuan-api-switch)</strong> 接管 (Profile: ${K})。相关输入框已置灰只读，如需修改请前往 API 旋钮面板。`,s.appendChild(te)}}l(i);function r(C,M,B){const te=document.createElement("div");te.className="slides-settings__field-row",te.style.cssText="display: flex; flex-direction: column; gap: 4px; width: 100%; text-align: left;";const V=document.createElement("div");V.className="slides-settings__field-main",V.style.cssText="display: flex; align-items: center; justify-content: space-between; gap: 16px; width: 100%;";const K=document.createElement("span");if(K.className="slides-settings__field-label",K.style.cssText="font-size: 13px; font-weight: 500; min-width: 160px; color: var(--b3-theme-on-background); text-align: left; flex-shrink: 0;",K.textContent=C,V.appendChild(K),V.appendChild(M),te.appendChild(V),B){const ae=document.createElement("span");ae.className="slides-settings__field-desc",ae.style.cssText="font-size: 11px; color: var(--b3-theme-on-surface); line-height: 1.4; text-align: left;",ae.textContent=B,te.appendChild(ae)}return te}const a=document.createElement("input");a.className="b3-text-field fn__flex-1",a.placeholder="https://api.openai.com/v1",a.dataset.settingKey="ai-base-url",a.value=i?i.baseUrl:o.aiConfig.baseUrl,a.disabled=!!i,a.addEventListener("change",async()=>{const C=a.value.trim();await j({baseUrl:C})});const c=document.createElement("div");c.className="slides-settings__api-key-wrap",c.style.cssText="position: relative; display: flex; align-items: center; width: 100%; flex: 1;";const u=document.createElement("input");u.className="b3-text-field slides-settings__api-key-input fn__flex-1",u.type="password",u.placeholder="sk-...",u.dataset.settingKey="ai-api-key",u.style.cssText="width: 100%; padding-right: 36px; box-sizing: border-box;",u.value=i?i.apiKey:o.aiConfig.apiKey,u.disabled=!!i,u.addEventListener("change",async()=>{const C=u.value.trim();await j({apiKey:C})});let f=!1;const p=document.createElement("button");p.className="slides-settings__api-key-toggle",p.type="button",p.innerHTML=Rl,p.title="显示 API Key",typeof p.setAttribute=="function"&&p.setAttribute("aria-label","显示 API Key"),p.disabled=!!i,p.addEventListener("click",()=>{f=!f,u.type=f?"text":"password",p.innerHTML=f?q2:Rl,p.title=f?"隐藏 API Key":"显示 API Key",typeof p.setAttribute=="function"&&p.setAttribute("aria-label",f?"隐藏 API Key":"显示 API Key")}),c.appendChild(u),c.appendChild(p);const d=document.createElement("input");d.className="b3-text-field fn__flex-1",d.placeholder="gpt-4o-mini / deepseek-chat",d.dataset.settingKey="ai-model",d.value=i?i.model:o.aiConfig.model,d.disabled=!!i,d.addEventListener("change",async()=>{const C=d.value.trim();await j({model:C})});const b=document.createElement("details");b.style.cssText="margin-top: 4px; font-size: 12px;";const m=document.createElement("summary");m.style.cssText="cursor: pointer; color: var(--b3-theme-primary); font-weight: 500; padding: 4px 0;",m.textContent="高级模型参数 (超时/采样温度/Token)",b.appendChild(m);const g=document.createElement("div");g.className="slides-settings__advanced-body",g.style.cssText="display: flex; flex-direction: column; gap: 8px; padding-top: 8px; text-align: left; width: 100%;";const y=document.createElement("input");y.className="b3-text-field fn__flex-1",y.type="number",y.dataset.settingKey="ai-timeout",y.value=String((i==null?void 0:i.requestTimeoutSeconds)??o.aiConfig.requestTimeoutSeconds??pt.requestTimeoutSeconds),y.disabled=!!i,y.addEventListener("change",async()=>{const C=Number.parseInt(y.value,10)||pt.requestTimeoutSeconds;await j({requestTimeoutSeconds:C})});const k=document.createElement("input");k.className="b3-text-field fn__flex-1",k.type="number",k.step="0.1",k.dataset.settingKey="ai-temperature",k.value=String((i==null?void 0:i.temperature)??o.aiConfig.temperature??pt.temperature),k.disabled=!!i,k.addEventListener("change",async()=>{const C=Number.parseFloat(k.value)||pt.temperature;await j({temperature:C})});const x=document.createElement("input");x.className="b3-text-field fn__flex-1",x.type="number",x.dataset.settingKey="ai-max-tokens",x.value=String((i==null?void 0:i.maxTokens)??o.aiConfig.maxTokens??pt.maxTokens),x.disabled=!!i,x.addEventListener("change",async()=>{const C=Number.parseInt(x.value,10)||pt.maxTokens;await j({maxTokens:C})}),g.appendChild(r("请求超时时间 (秒)",y)),g.appendChild(r("采样温度 (Temperature)",k,"范围 0.0 - 2.0，数值越高越富有创意")),g.appendChild(r("单次最大输出 Token",x)),b.appendChild(g);const $=document.createElement("div");$.className="slides-settings__test-row",$.style.cssText="display: flex; align-items: center; gap: 12px; margin-top: 8px; text-align: left; width: 100%;";const A=document.createElement("button");A.className="b3-button b3-button--outline",A.type="button",A.textContent="测试连接";const w=document.createElement("span");w.className="slides-settings__test-status",w.style.cssText="font-size: 12px; color: var(--b3-theme-on-surface); flex: 1; word-break: break-all; text-align: left;",A.addEventListener("click",async()=>{const C=i||{baseUrl:a.value.trim(),apiKey:u.value.trim(),model:d.value.trim(),requestTimeoutSeconds:Number.parseInt(y.value,10)||15,temperature:Number.parseFloat(k.value)||.7,maxTokens:10};if(!Un(C)){w.style.color="var(--b3-theme-error, #f44336)",w.textContent="请先填写完整的 Base URL、API Key 与 Model";return}A.disabled=!0,w.style.color="var(--b3-theme-primary)",w.textContent="正在发起测试请求...";const M=await Kw(C);A.disabled=!1,M.success?(w.style.color="var(--b3-theme-primary, #4caf50)",w.textContent=M.message):(w.style.color="var(--b3-theme-error, #f44336)",w.textContent=M.message)}),$.appendChild(A),$.appendChild(w),n.appendChild(r("API 基础地址 (Base URL)",a)),n.appendChild(r("API 鉴权密钥 (API Key)",c)),n.appendChild(r("模型名称 (Model)",d)),n.appendChild(b),n.appendChild($),t.addItem({title:"AI 演讲提词服务",direction:"row",description:"配置兼容 OpenAI API 的大模型服务，用于提炼演讲口播提词卡 (Notes)。支持被「API 旋钮」集中调度接管。",actionElement:n});const _=document.createElement("input");_.className="b3-switch fn__flex-center",_.type="checkbox",_.checked=o.enableWebServeJump,_.addEventListener("change",async()=>{const C=_.checked;O.disabled=!C,ht({enableWebServeJump:C}),await e.saveGlobalSettings({enableWebServeJump:C})});const O=document.createElement("input");O.className="b3-text-field fn__size200",O.value=o.webServeUrl,O.placeholder="http://127.0.0.1:6806",O.disabled=!o.enableWebServeJump,O.addEventListener("change",async()=>{const C=O.value.trim()||yo.webServeUrl;ht({webServeUrl:C}),await e.saveGlobalSettings({webServeUrl:C})});const H=yn(_);t.addItem({title:"启用网络伺服链接外跳",description:"开启后，幻灯片中的思源块引用链接可以点击以外部网络伺服抽屉呈现",actionElement:H}),t.addItem({title:"伺服主机地址",description:"思源笔记桌面端 WebServe 伺服地址 (如 http://127.0.0.1:6806)",actionElement:O});const P=document.createElement("input");P.className="b3-switch fn__flex-center",P.type="checkbox",P.checked=o.normalizeHeadingSizes,P.addEventListener("change",async()=>{const C=P.checked;ht({normalizeHeadingSizes:C}),await e.saveGlobalSettings({normalizeHeadingSizes:C})});const F=document.createElement("input");F.className="b3-switch fn__flex-center",F.type="checkbox",F.checked=o.showUnorderedListMarkers,F.addEventListener("change",async()=>{const C=F.checked;ht({showUnorderedListMarkers:C}),await e.saveGlobalSettings({showUnorderedListMarkers:C})});const E=document.createElement("input");E.className="b3-switch fn__flex-center",E.type="checkbox",E.checked=o.showOrderedListMarkers,E.addEventListener("change",async()=>{const C=E.checked;ht({showOrderedListMarkers:C}),await e.saveGlobalSettings({showOrderedListMarkers:C})});const D=yn(P),S=yn(F),q=yn(E);t.addItem({title:"固定特定标题大小",description:"开启后限制正文大标题在幻灯片中不超出安全展示画幅",actionElement:D}),t.addItem({title:"无序列表圆点前缀标记",description:"开启后在无序列表项前展示圆点前缀标记",actionElement:S}),t.addItem({title:"有序列表数字序号标记",description:"开启后在有序列表项前展示数字序号标记",actionElement:q}),W2(t,[n],[H,O,D,S,q]);async function j(C){const M=Fo().aiConfig,B=bi({...M,...C});ht({aiConfig:B}),await e.saveGlobalSettings({aiConfig:B}),window.siyuanApiSwitch&&window.siyuanApiSwitch.updateLocalConfig(e.name,{provider:"custom",baseUrl:B.baseUrl,apiKey:B.apiKey,model:B.model,requestTimeoutSeconds:B.requestTimeoutSeconds,temperature:B.temperature,maxTokens:B.maxTokens})}return t.updateManagedConfig=C=>{i=C,l(C);const M=!!C,B=Fo().aiConfig;a.disabled=M,u.disabled=M,p.disabled=M,d.disabled=M,y.disabled=M,k.disabled=M,x.disabled=M,a.value=C?C.baseUrl:B.baseUrl,u.value=C?C.apiKey:B.apiKey,d.value=C?C.model:B.model,y.value=String((C==null?void 0:C.requestTimeoutSeconds)??B.requestTimeoutSeconds),k.value=String((C==null?void 0:C.temperature)??B.temperature),x.value=String((C==null?void 0:C.maxTokens)??B.maxTokens),w.textContent=""},t}const K2=150,G2=`<symbol id="iconSlides" viewBox="0 0 1024 1024">
  <path fill="currentColor" d="M128 160h768c35.3 0 64 28.7 64 64v480c0 35.3-28.7 64-64 64H128c-35.3 0-64-28.7-64-64V224c0-35.3 28.7-64 64-64z m64 64v480h640V224H192z m128 640h384v64H320z"/>
  <path fill="currentColor" d="M416 336l256 144-256 144z"/>
</symbol>`,Y2="slides-dock",As="slides-preview-tab",zl="slides-presenter-tab",Hl=dh;class Z2 extends ie.Plugin{constructor(){super(...arguments);Ie(this,"isMobile",!1);Ie(this,"currentDocId","");Ie(this,"previewTab",null);Ie(this,"latestCompiledDoc",null);Ie(this,"setting",null);Ie(this,"debounceTimer",null);Ie(this,"activeCursorBlockId","");Ie(this,"cancelledCursorBlockId","");Ie(this,"compileScheduler",new F2);Ie(this,"dirtyDocId",null);Ie(this,"inspectorSyncThrottle",new z2);Ie(this,"onSwitchProtyleBound",this.onSwitchProtyle.bind(this));Ie(this,"onWsMainBound",this.onWsMain.bind(this));Ie(this,"onBlockClickedBound",this.onBlockClickedFromSlide.bind(this));Ie(this,"onEditorClickBound",this.onEditorClick.bind(this));Ie(this,"onSelectionChangeBound",this.onSelectionChange.bind(this));Ie(this,"onClickEditorContentBound",this.onClickEditorContent.bind(this));Ie(this,"onVisibilityChangeBound",this.onVisibilityChange.bind(this));Ie(this,"isOpeningSetting",!1)}async onload(){const o=ie.getFrontend();this.isMobile=o==="mobile"||o==="browser-mobile",await this.loadGlobalSettings(),this.initApiSwitchSync(),this.addIcons(G2),this.addTopBar({id:"slides-topbar-play",icon:"iconSlides",title:"即现",position:"right",callback:()=>{this.openBottomPreviewTab()}}),N2(this);const i=this;if(this.addTab({type:As,init(n){var r;const s=this||n;i.previewTab=(s==null?void 0:s.tab)||null,T2(s.element,i);const l=(r=s==null?void 0:s.data)==null?void 0:r.docId;l&&!i.getActiveDocumentId()&&i.compileCurrentDocument(l,{reason:"explicit"}),i.updatePreviewTabHeader()},destroy(){i.previewTab===(this==null?void 0:this.tab)&&(i.previewTab=null),Pc(this.element)}}),this.addTab({type:zl,init(n){M2((this||n).element,i)},destroy(){Rc(this.element)}}),this.addDock({config:{position:"RightTop",size:{width:320,height:0},icon:"iconSlides",title:"即现配置"},data:{},type:Y2,init(){B2(this.element,i)},destroy(){zc(this.element)}}),this.eventBus&&typeof this.eventBus.emit!="function"&&(this.eventBus.emit=(n,s)=>{try{typeof window<"u"&&window.dispatchEvent(new CustomEvent(`siyuan-event-${n}`,{detail:s}))}catch{}}),this.eventBus.on("switch-protyle",this.onSwitchProtyleBound),this.eventBus.on("ws-main",this.onWsMainBound),this.eventBus.on("slides:request-compile",()=>this.compileCurrentDocument()),this.eventBus.on("slides:block-clicked",this.onBlockClickedBound),this.eventBus.on("click-editorcontent",this.onClickEditorContentBound),typeof document<"u"&&(document.addEventListener("click",this.onEditorClickBound,!0),document.addEventListener("selectionchange",this.onSelectionChangeBound),document.addEventListener("visibilitychange",this.onVisibilityChangeBound)),typeof document<"u"){const n=()=>{const s=this.getActiveDocumentId();s&&(s!==this.currentDocId&&(this.currentDocId=s,this.updatePreviewTabHeader("",s)),this.latestCompiledDoc||this.markCompileDirty(s))};setTimeout(n,300),setTimeout(n,1e3)}}async onDataChanged(o){await this.loadGlobalSettings(),this.currentDocId&&this.markCompileDirty(this.currentDocId)}async loadGlobalSettings(){try{const o=await this.loadData(Hl),i=hh(o);return ht(i),i}catch{return ht(yo),yo}}async saveGlobalSettings(o){const i=Fo(),n=ht({...i,...o||{}});try{await this.saveData(Hl,n)}catch(l){console.error("保存即现全局配置失败",l)}const s=this.currentDocId||this.getActiveDocumentId();return s&&this.markCompileDirty(s),n}openSetting(){if(!this.isOpeningSetting){this.isOpeningSetting=!0;try{this.setting=V2(this),this.setting.open(this.name)}finally{setTimeout(()=>{this.isOpeningSetting=!1},500)}}}initApiSwitchSync(){const o=s=>{if(uh(s),this.setting){const l=this.setting.updateManagedConfig;typeof l=="function"&&l(s)}},i=()=>{const s=Fo().aiConfig;return{provider:"custom",baseUrl:s.baseUrl,apiKey:s.apiKey,model:s.model,requestTimeoutSeconds:s.requestTimeoutSeconds,temperature:s.temperature,maxTokens:s.maxTokens}},n=()=>{window.siyuanApiSwitch&&window.siyuanApiSwitch.register(this.name,this.displayName||"即现 (SiYuan Live Slides)",o,i())};window.siyuanApiSwitch?n():window.addEventListener("siyuan-api-switch:ready",()=>{n()},{once:!0})}onunload(){window.siyuanApiSwitch&&window.siyuanApiSwitch.unregister(this.name),this.debounceTimer&&(window.clearTimeout(this.debounceTimer),this.debounceTimer=null),this.compileScheduler.reset(),this.inspectorSyncThrottle.reset(),this.dirtyDocId=null,In.clear(),this.eventBus.off("switch-protyle",this.onSwitchProtyleBound),this.eventBus.off("ws-main",this.onWsMainBound),this.eventBus.off("click-editorcontent",this.onClickEditorContentBound),typeof document<"u"&&(document.removeEventListener("click",this.onEditorClickBound,!0),document.removeEventListener("selectionchange",this.onSelectionChangeBound),document.removeEventListener("visibilitychange",this.onVisibilityChangeBound)),$i.detach()}onVisibilityChange(){typeof document<"u"&&document.visibilityState==="visible"&&this.flushDirtyCompile()}async openBottomPreviewTab(){this.currentDocId||(this.currentDocId=this.getActiveDocumentId());const o=this.currentDocId?await this.fetchDocumentTitle(this.currentDocId):"",i=this.buildPreviewTabTitle(o);await ie.openTab({app:this.app,custom:{id:this.name+As,title:i,icon:"iconSlides",data:{docId:this.currentDocId}},position:"bottom"}),this.currentDocId&&this.compileCurrentDocument(this.currentDocId),this.updatePreviewTabHeader(o,this.currentDocId)}async openPresenterTab(){Do("presenterMode")||(A2()||await this.openBottomPreviewTab(),await ie.openTab({app:this.app,custom:{id:this.name+zl,title:"演讲者控制台",icon:"iconSlides",data:{}},position:"right"}))}async openStandalonePreviewWindow(){this.currentDocId||(this.currentDocId=this.getActiveDocumentId()),this.currentDocId&&!this.latestCompiledDoc&&await this.compileCurrentDocument(this.currentDocId,{reason:"explicit"});const o=ie.getFrontend();if(o==="browser-desktop"||o==="browser-mobile"){typeof window<"u"&&typeof window.open=="function"&&window.open("/plugins/siyuan-live-slides/slides-client/index.html","SlidesBigScreenWindow","width=1280,height=760,menubar=no,toolbar=no,location=no,status=no");return}let i=this.previewTab;if(!i){const n=this.currentDocId?await this.fetchDocumentTitle(this.currentDocId):"",s=this.buildPreviewTabTitle(n),l=await ie.openTab({app:this.app,custom:{id:this.name+As,title:s,icon:"iconSlides",data:{docId:this.currentDocId}},position:"bottom"});i=this.previewTab||l}i&&(this.currentDocId&&i.model&&(i.model.data={...i.model.data||{},docId:this.currentDocId}),ie.openWindow({tab:i,width:1280,height:760}))}async onSwitchProtyle(o){var l,r,a,c,u;const i=(l=o.detail)==null?void 0:l.protyle,n=(r=i==null?void 0:i.block)==null?void 0:r.rootID,s=((u=(c=(a=i==null?void 0:i.title)==null?void 0:a.editElement)==null?void 0:c.textContent)==null?void 0:u.trim())||"";if(n&&n!==this.currentDocId){this.cancelledCursorBlockId="",this.currentDocId=n,this.activeCursorBlockId=n;const f=await er(n).catch(()=>({}));ri({id:n,rootId:n,type:"doc",attrs:f}),this.markCompileDirty(n),this.updatePreviewTabHeader(s,n)}}onClickEditorContent(o){var s,l;const i=o==null?void 0:o.detail;if(!i)return;const n=(l=(s=i.protyle)==null?void 0:s.block)==null?void 0:l.rootID;n&&(!this.currentDocId||this.currentDocId!==n)&&(this.currentDocId=n),i.event&&this.onEditorClick(i.event)}buildPreviewTabTitle(o){return gc(o)}async fetchDocumentTitle(o){return yc(this,o)}async updatePreviewTabHeader(o,i){return Mg(this,o,i)}getActiveDocumentId(){return Eo.getActiveDocumentId()}resolveDocIdFromElement(o){return Eo.resolveDocIdFromElement(o,this.currentDocId)}async switchToDocGlobalInspector(o,i){o&&(this.activeCursorBlockId=o,this.currentDocId=o,await Eo.switchToDocGlobalInspector(o,i))}onWsMain(o){const i=o.detail;i&&i.cmd==="transactions"&&(Eo.patchThematicBreakTransactions(i),this.markCompileDirty())}markCompileDirty(o){const i=o||this.currentDocId||this.getActiveDocumentId();i&&(this.currentDocId||(this.currentDocId=i),this.dirtyDocId=i,this.scheduleDirtyCompile())}scheduleDirtyCompile(o=K2){if(this.debounceTimer&&(window.clearTimeout(this.debounceTimer),this.debounceTimer=null),!this.dirtyDocId)return;const i=In.getVisibility();if(i==="none")return;const n=i==="visible"?o:Math.max(o,S2);this.debounceTimer=window.setTimeout(()=>{this.debounceTimer=null;const s=this.dirtyDocId;this.dirtyDocId=null,s&&this.compileCurrentDocument(s,{reason:"auto"})},n)}flushDirtyCompile(){this.dirtyDocId&&this.scheduleDirtyCompile(0)}handleBlockClickedFromSlide(o,i){return o?(this.cancelledCursorBlockId="",this.activeCursorBlockId=o):(this.cancelledCursorBlockId=this.activeCursorBlockId,this.activeCursorBlockId=""),Eo.handleBlockClickedFromSlide(o,this.app,this.currentDocId,this.latestCompiledDoc,i)}onBlockClickedFromSlide(o){const i=(o==null?void 0:o.detail)||o;i!=null&&i.blockId&&this.handleBlockClickedFromSlide(i.blockId,i.page)}onEditorClick(o){var f,p;const i=o.target;if(!i)return;const n=((f=i.closest)==null?void 0:f.call(i,".protyle"))||((p=i.closest)==null?void 0:p.call(i,".protyle-wysiwyg"));if(Tl(n))return;const s=i.closest(".protyle-title")||i.closest(".protyle-background");if(!!s){const d=this.resolveDocIdFromElement(i);if(d&&this.activeCursorBlockId!==d){const b=s||document.querySelector(`.protyle-title[data-node-id="${d}"]`)||document.querySelector(`.protyle[data-doc-id="${d}"] .protyle-title`),m=b==null?void 0:b.querySelector(".protyle-title__input"),g=((m==null?void 0:m.innerText)||(b==null?void 0:b.innerText)||"").trim();this.switchToDocGlobalInspector(d,g)}return}if(!i.closest(".protyle-wysiwyg"))return;const a=i.closest("[data-node-id]");if(!a)return;const c=a.getAttribute("data-node-id"),u=a.getAttribute("data-type")||"";c&&(this.cancelledCursorBlockId="",this.currentDocId||(this.currentDocId=this.resolveDocIdFromElement(i)||""),this.currentDocId&&!this.latestCompiledDoc&&this.markCompileDirty(this.currentDocId),c!==this.activeCursorBlockId&&(this.activeCursorBlockId=c,Xs(c)),this.syncInspectorBlock(a,c,u))}onSelectionChange(){var f,p;if(typeof window>"u")return;const o=window.getSelection();if(!o||o.rangeCount===0)return;const i=o.anchorNode;if(!i)return;const n=i.nodeType===Node.ELEMENT_NODE?i:i.parentElement;if(!n)return;const s=((f=n.closest)==null?void 0:f.call(n,".protyle"))||((p=n.closest)==null?void 0:p.call(n,".protyle-wysiwyg"));if(Tl(s))return;const l=n.closest(".protyle-title")||n.closest(".protyle-background");if(!!l){const d=this.resolveDocIdFromElement(n);if(d&&this.activeCursorBlockId!==d){const b=l||document.querySelector(`.protyle-title[data-node-id="${d}"]`)||document.querySelector(`.protyle[data-doc-id="${d}"] .protyle-title`),m=b==null?void 0:b.querySelector(".protyle-title__input"),g=((m==null?void 0:m.innerText)||(b==null?void 0:b.innerText)||"").trim();this.switchToDocGlobalInspector(d,g)}return}if(!n.closest(".protyle-wysiwyg"))return;const a=n.closest("[data-node-id]"),c=a==null?void 0:a.getAttribute("data-node-id"),u=(a==null?void 0:a.getAttribute("data-type"))||"";if(a&&c){if(Eo.isLocatingLocked(c))return;if(this.currentDocId||(this.currentDocId=this.resolveDocIdFromElement(n)||""),this.currentDocId&&!this.latestCompiledDoc&&this.markCompileDirty(this.currentDocId),c!==this.activeCursorBlockId){if(c===this.cancelledCursorBlockId)return;this.activeCursorBlockId=c,Xs(c)}this.syncInspectorBlock(a,c,u)}}async syncInspectorBlock(o,i,n){this.inspectorSyncThrottle.shouldSkip(i)||await Eo.syncInspectorBlock(o,i,n,this.currentDocId,this.latestCompiledDoc)}async compileCurrentDocument(o,i){const n=(i==null?void 0:i.reason)??"explicit";let s=o||this.currentDocId;if(!s){const r=this.getActiveDocumentId();if(r)this.currentDocId=r,s=r;else return}if(n==="auto"&&In.getVisibility()==="none"){this.dirtyDocId=s;return}const l=this.compileScheduler.tryBegin(s);if(l!==null){this.dirtyDocId===s&&(this.dirtyDocId=null);try{const r=await Ee.compile(s),a=!!this.currentDocId&&s!==this.currentDocId;!this.compileScheduler.isStale(l)&&!a&&(this.currentDocId||(this.currentDocId=s),this.latestCompiledDoc=r,L2(r,s),this.updatePreviewTabHeader("",s),this.purgeStaleDomSlidesAttrs(r))}catch(r){console.error("[SiYuanLiveSlides] Failed to compile document:",r)}finally{const r=this.compileScheduler.finishBatch(),a=r.length>0?r[0]:this.compileScheduler.finish();a&&this.markCompileDirty(a);for(let c=1;c<r.length;c++)this.markCompileDirty(r[c])}}}purgeStaleDomSlidesAttrs(o){Eo.purgeStaleDomSlidesAttrs(o)}}module.exports=Z2;
